target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v74 = load i64, ptr %slot1, align 8
  %op75 = add i64 %v74, 32
  store i64 %op75, ptr %slot3, align 8
  %mem76 = alloca i8, i64 40, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot4, align 8
  %mem78 = alloca i8, i64 8, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot5, align 8
  %mem80 = alloca i8, i64 8, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot6, align 8
  %mem82 = alloca i8, i64 312, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot7, align 8
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot8, align 8
  %mem86 = alloca i8, i64 8, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot9, align 8
  %mem88 = alloca i8, i64 8, align 8
  %ptr89 = ptrtoint ptr %mem88 to i64
  store i64 %ptr89, ptr %slot10, align 8
  %mem90 = alloca i8, i64 8, align 8
  %ptr91 = ptrtoint ptr %mem90 to i64
  store i64 %ptr91, ptr %slot11, align 8
  %mem92 = alloca i8, i64 8, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot12, align 8
  %v94 = load i64, ptr %slot9, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 0, ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot2, align 8
  %v97 = load i64, ptr %slot8, align 8
  %p98 = inttoptr i64 %v97 to ptr
  store i64 %v96, ptr %p98, align 8, !alias.scope !3, !noalias !4
  %v99 = load i64, ptr %slot1, align 8
  %p100 = inttoptr i64 %v99 to ptr
  %call101 = call ptr @myl_qbe_heap(ptr %p100) nomerge, !dbg !110
  %calladdr102 = ptrtoint ptr %call101 to i64
  store i64 %calladdr102, ptr %slot13, align 8
  %v103 = load i64, ptr %slot1, align 8
  %p104 = inttoptr i64 %v103 to ptr
  %call105 = call i64 @myl_qbe_region_mark(ptr %p104) nomerge, !dbg !110
  store i64 %call105, ptr %slot14, align 8
  %v106 = load i64, ptr %slot5, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i32 0, ptr %p107, align 4, !alias.scope !3, !noalias !4
  %v108 = load i64, ptr %slot6, align 8
  %p109 = inttoptr i64 %v108 to ptr
  store i32 0, ptr %p109, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v110 = load i64, ptr %slot8, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld112, ptr %slot15, align 8
  %v113 = load i64, ptr %slot15, align 8
  %v114 = load i64, ptr %slot11, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 %v113, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot11, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot16, align 8
  %v119 = load i64, ptr %slot16, align 8
  %op120 = add i64 %v119, 256
  store i64 %op120, ptr %slot17, align 8
  %v121 = load i64, ptr %slot17, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !4, !noalias !3
  store i64 %ld123, ptr %slot18, align 8
  %v124 = load i64, ptr %slot18, align 8
  %v125 = load i64, ptr %slot11, align 8
  %p126 = inttoptr i64 %v125 to ptr
  store i64 %v124, ptr %p126, align 8, !alias.scope !3, !noalias !4
  %v127 = load i64, ptr %slot11, align 8
  %p128 = inttoptr i64 %v127 to ptr
  %ld129 = load i64, ptr %p128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld129, ptr %slot19, align 8
  %v130 = load i64, ptr %slot19, align 8
  %v131 = load i64, ptr %slot9, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i64 %v130, ptr %p132, align 8, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot8, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot20, align 8
  %v136 = load i64, ptr %slot20, align 8
  %v137 = load i64, ptr %slot11, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot11, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot21, align 8
  %v142 = load i64, ptr %slot21, align 8
  %op143 = add i64 %v142, 264
  store i64 %op143, ptr %slot22, align 8
  %v144 = load i64, ptr %slot22, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !4, !noalias !3
  store i64 %ld146, ptr %slot23, align 8
  %v147 = load i64, ptr %slot23, align 8
  %v148 = load i64, ptr %slot11, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i64 %v147, ptr %p149, align 8, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot12, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 1, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot12, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot24, align 8
  %v155 = load i64, ptr %slot11, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld157, ptr %slot25, align 8
  %v158 = load i64, ptr %slot25, align 8
  %v159 = load i64, ptr %slot24, align 8
  %ovpair161 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v158, i64 %v159)
  %op160 = extractvalue { i64, i1 } %ovpair161, 0
  %ov162 = extractvalue { i64, i1 } %ovpair161, 1
  store i64 %op160, ptr %slot26, align 8
  %cv163 = zext i1 %ov162 to i64
  store i64 %cv163, ptr %slot27, align 8
  %v164 = load i64, ptr %slot27, align 8
  %cond165 = icmp ne i64 %v164, 0
  br i1 %cond165, label %bb_overflow31, label %bb_checked31
bb_overflow31:
  %v166 = load i64, ptr %slot1, align 8
  %p167 = inttoptr i64 %v166 to ptr
  %v168 = load i64, ptr %slot25, align 8
  %v169 = load i64, ptr %slot24, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p167, i64 1, i64 %v168, i64 %v169, i64 64) nomerge, !dbg !112
  unreachable
bb_checked31:
  %v170 = load i64, ptr %slot26, align 8
  %v171 = load i64, ptr %slot11, align 8
  %p172 = inttoptr i64 %v171 to ptr
  store i64 %v170, ptr %p172, align 8, !alias.scope !3, !noalias !4
  %v173 = load i64, ptr %slot11, align 8
  %p174 = inttoptr i64 %v173 to ptr
  %ld175 = load i64, ptr %p174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld175, ptr %slot28, align 8
  %v176 = load i64, ptr %slot28, align 8
  %v177 = load i64, ptr %slot10, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i64 %v176, ptr %p178, align 8, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot10, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld181, ptr %slot29, align 8
  %v182 = load i64, ptr %slot29, align 8
  %v183 = load i64, ptr %slot11, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 %v182, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot12, align 8
  %p186 = inttoptr i64 %v185 to ptr
  store i64 0, ptr %p186, align 8, !alias.scope !3, !noalias !4
  %v187 = load i64, ptr %slot12, align 8
  %p188 = inttoptr i64 %v187 to ptr
  %ld189 = load i64, ptr %p188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld189, ptr %slot30, align 8
  %v190 = load i64, ptr %slot11, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i64, ptr %p191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld192, ptr %slot31, align 8
  %v193 = load i64, ptr %slot31, align 8
  %v194 = load i64, ptr %slot30, align 8
  %cmp195 = icmp slt i64 %v193, %v194
  %cv196 = zext i1 %cmp195 to i64
  store i64 %cv196, ptr %slot32, align 8
  %v197 = load i64, ptr %slot32, align 8
  %v198 = load i64, ptr %slot11, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i64 %v197, ptr %p199, align 8, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot11, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i64, ptr %p201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld202, ptr %slot33, align 8
  %v203 = load i64, ptr %slot33, align 8
  %cond204 = icmp ne i64 %v203, 0
  br i1 %cond204, label %bb_next39, label %bb_i17
bb_next39:
  %v205 = load i64, ptr %slot9, align 8
  %p206 = inttoptr i64 %v205 to ptr
  %ld207 = load i64, ptr %p206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld207, ptr %slot34, align 8
  %v208 = load i64, ptr %slot34, align 8
  %op209 = add i64 %v208, 0
  store i64 %op209, ptr %slot35, align 8
  %v210 = load i64, ptr %slot35, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i64, ptr %p211, align 8, !alias.scope !6, !noalias !7
  store i64 %ld212, ptr %slot36, align 8
  %v213 = load i64, ptr %slot36, align 8
  %v214 = load i64, ptr %slot11, align 8
  %p215 = inttoptr i64 %v214 to ptr
  store i64 %v213, ptr %p215, align 8, !alias.scope !3, !noalias !4
  %v216 = load i64, ptr %slot11, align 8
  %p217 = inttoptr i64 %v216 to ptr
  %ld218 = load i64, ptr %p217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld218, ptr %slot37, align 8
  %v219 = load i64, ptr %slot37, align 8
  %cmp220 = icmp ugt i64 %v219, 9223372036854775807
  %cv221 = zext i1 %cmp220 to i64
  store i64 %cv221, ptr %slot38, align 8
  %v222 = load i64, ptr %slot38, align 8
  %cond223 = icmp ne i64 %v222, 0
  br i1 %cond223, label %bb_cast_overflow44, label %bb_cast_ok44
bb_cast_overflow44:
  %v224 = load i64, ptr %slot1, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %v226 = load i64, ptr %slot37, align 8
  call void @myl_qbe_fail_cast(ptr %p225, i64 %v226, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok44:
  %v227 = load i64, ptr %slot37, align 8
  %v228 = load i64, ptr %slot11, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i64 %v227, ptr %p229, align 8, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot10, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot39, align 8
  %v233 = load i64, ptr %slot39, align 8
  %v234 = load i64, ptr %slot12, align 8
  %p235 = inttoptr i64 %v234 to ptr
  store i64 %v233, ptr %p235, align 8, !alias.scope !3, !noalias !4
  %v236 = load i64, ptr %slot12, align 8
  %p237 = inttoptr i64 %v236 to ptr
  %ld238 = load i64, ptr %p237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld238, ptr %slot40, align 8
  %v239 = load i64, ptr %slot11, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %ld241 = load i64, ptr %p240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld241, ptr %slot41, align 8
  %v242 = load i64, ptr %slot41, align 8
  %v243 = load i64, ptr %slot40, align 8
  %ovpair245 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v242, i64 %v243)
  %op244 = extractvalue { i64, i1 } %ovpair245, 0
  %ov246 = extractvalue { i64, i1 } %ovpair245, 1
  store i64 %op244, ptr %slot42, align 8
  %v247 = load i64, ptr %slot41, align 8
  %v248 = load i64, ptr %slot42, align 8
  %op249 = xor i64 %v247, %v248
  store i64 %op249, ptr %slot43, align 8
  %v250 = load i64, ptr %slot40, align 8
  %v251 = load i64, ptr %slot42, align 8
  %op252 = xor i64 %v250, %v251
  store i64 %op252, ptr %slot44, align 8
  %v253 = load i64, ptr %slot43, align 8
  %v254 = load i64, ptr %slot44, align 8
  %op255 = and i64 %v253, %v254
  store i64 %op255, ptr %slot45, align 8
  %cv256 = zext i1 %ov246 to i64
  store i64 %cv256, ptr %slot46, align 8
  %v257 = load i64, ptr %slot46, align 8
  %cond258 = icmp ne i64 %v257, 0
  br i1 %cond258, label %bb_overflow48, label %bb_checked48
bb_overflow48:
  %v259 = load i64, ptr %slot1, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %v261 = load i64, ptr %slot41, align 8
  %v262 = load i64, ptr %slot40, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p260, i64 0, i64 %v261, i64 %v262, i64 64) nomerge, !dbg !116
  unreachable
bb_checked48:
  %v263 = load i64, ptr %slot42, align 8
  %v264 = load i64, ptr %slot11, align 8
  %p265 = inttoptr i64 %v264 to ptr
  store i64 %v263, ptr %p265, align 8, !alias.scope !3, !noalias !4
  %v266 = load i64, ptr %slot11, align 8
  %p267 = inttoptr i64 %v266 to ptr
  %ld268 = load i64, ptr %p267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld268, ptr %slot47, align 8
  %v269 = load i64, ptr %slot47, align 8
  %v270 = load i64, ptr %slot10, align 8
  %p271 = inttoptr i64 %v270 to ptr
  store i64 %v269, ptr %p271, align 8, !alias.scope !3, !noalias !4
  br label %bb_i17
bb_i17:
  %v272 = load i64, ptr %slot10, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %ld274 = load i64, ptr %p273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld274, ptr %slot48, align 8
  %v275 = load i64, ptr %slot48, align 8
  %v276 = load i64, ptr %slot11, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i64 %v275, ptr %p277, align 8, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot9, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld280, ptr %slot49, align 8
  %v281 = load i64, ptr %slot11, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld283, ptr %slot50, align 8
  %v284 = load i64, ptr %slot49, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !6, !noalias !7
  store i64 %ld286, ptr %slot51, align 8
  %v287 = load i64, ptr %slot50, align 8
  %v288 = load i64, ptr %slot51, align 8
  %cmp289 = icmp ult i64 %v287, %v288
  %cv290 = zext i1 %cmp289 to i64
  store i64 %cv290, ptr %slot52, align 8
  %v291 = load i64, ptr %slot52, align 8
  %cond292 = icmp ne i64 %v291, 0
  br i1 %cond292, label %bb_success60, label %bb_failed60
bb_failed60:
  %v293 = load i64, ptr %slot1, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %v295 = load i64, ptr %slot50, align 8
  %v296 = load i64, ptr %slot51, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p294, i64 %v295, i64 %v296) nomerge, !dbg !118
  unreachable
bb_success60:
  %v297 = load i64, ptr %slot49, align 8
  %op298 = add i64 %v297, 32
  store i64 %op298, ptr %slot53, align 8
  %v299 = load i64, ptr %slot53, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !6, !noalias !7
  store i64 %ld301, ptr %slot54, align 8
  %v302 = load i64, ptr %slot50, align 8
  %op303 = mul i64 %v302, 40
  store i64 %op303, ptr %slot55, align 8
  %v304 = load i64, ptr %slot54, align 8
  %v305 = load i64, ptr %slot55, align 8
  %op306 = add i64 %v304, %v305
  store i64 %op306, ptr %slot56, align 8
  %v307 = load i64, ptr %slot56, align 8
  %v308 = load i64, ptr %slot11, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 %v307, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot11, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %ld312 = load i64, ptr %p311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld312, ptr %slot57, align 8
  %v313 = load i64, ptr %slot11, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld315, ptr %slot58, align 8
  store i32 0, ptr %slot59, align 8
  %v316 = load i64, ptr %slot5, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %ld318 = load i32, ptr %p317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld318, ptr %slot60, align 8
  %v319 = load i32, ptr %slot60, align 8
  %op320 = and i32 %v319, 24
  store i32 %op320, ptr %slot60, align 8
  %v321 = load i32, ptr %slot60, align 8
  %cmp322 = icmp eq i32 %v321, 0
  %cv323 = zext i1 %cmp322 to i32
  store i32 %cv323, ptr %slot61, align 8
  %v324 = load i32, ptr %slot59, align 8
  %v325 = load i32, ptr %slot61, align 8
  %op326 = and i32 %v324, %v325
  store i32 %op326, ptr %slot62, align 8
  %v327 = load i32, ptr %slot62, align 8
  %cv328 = zext i32 %v327 to i64
  %cond329 = icmp ne i64 %cv328, 0
  br i1 %cond329, label %bb_rctake67, label %bb_rccopy67
bb_rctake67:
  %v330 = load i64, ptr %slot7, align 8
  store i64 %v330, ptr %slot63, align 8
  %v331 = load i64, ptr %slot14, align 8
  store i64 %v331, ptr %slot64, align 8
  %v332 = load i64, ptr %slot13, align 8
  %v333 = load i64, ptr %slot63, align 8
  %v334 = load i64, ptr %slot58, align 8
  %v335 = load i64, ptr %slot64, align 8
  %cv336 = trunc i64 %v335 to i32
  %call337 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v332, i64 %v333, i64 %v334, i32 %cv336) nomerge, !dbg !120
  store i32 %call337, ptr %slot65, align 8
  %v338 = load i32, ptr %slot65, align 8
  %cv339 = zext i32 %v338 to i64
  %cond340 = icmp ne i64 %cv339, 0
  br i1 %cond340, label %bb_rcsuccess77, label %bb_rcfailure77
bb_rcfailure77:
  %v341 = load i64, ptr %slot13, align 8
  %p342 = inttoptr i64 %v341 to ptr
  %call343 = call i32 @myl_rc_take_failure(ptr %p342) nomerge, !dbg !120
  store i32 %call343, ptr %slot66, align 8
  %v344 = load i64, ptr %slot1, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %v346 = load i32, ptr %slot66, align 8
  %call347 = call i32 @myl_qbe_rc_status(ptr %p345, i32 %v346) nomerge, !dbg !120
  store i32 %call347, ptr %slot67, align 8
  br label %bb_failure
bb_rcsuccess77:
  %v348 = load i64, ptr %slot6, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i32 1, ptr %p349, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared67
bb_rccopy67:
  %v350 = load i64, ptr %slot7, align 8
  store i64 %v350, ptr %slot68, align 8
  %v351 = load i64, ptr %slot14, align 8
  store i64 %v351, ptr %slot69, align 8
  %v352 = load i64, ptr %slot13, align 8
  %v353 = load i64, ptr %slot68, align 8
  %v354 = load i64, ptr %slot58, align 8
  %v355 = load i64, ptr %slot69, align 8
  %cv356 = trunc i64 %v355 to i32
  %call357 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v352, i64 %v353, i64 %v354, i32 %cv356) nomerge, !dbg !120
  store i32 %call357, ptr %slot70, align 8
  %v358 = load i32, ptr %slot70, align 8
  %cv359 = zext i32 %v358 to i64
  %cond360 = icmp ne i64 %cv359, 0
  br i1 %cond360, label %bb_rcsuccess86, label %bb_rcfailure86
bb_rcfailure86:
  %v361 = load i64, ptr %slot13, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %call363 = call i32 @myl_rc_take_failure(ptr %p362) nomerge, !dbg !120
  store i32 %call363, ptr %slot71, align 8
  %v364 = load i64, ptr %slot1, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %v366 = load i32, ptr %slot71, align 8
  %call367 = call i32 @myl_qbe_rc_status(ptr %p365, i32 %v366) nomerge, !dbg !120
  store i32 %call367, ptr %slot72, align 8
  br label %bb_failure
bb_rcsuccess86:
  %v368 = load i64, ptr %slot6, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i32 1, ptr %p369, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared67
bb_rcprepared67:
  %v370 = load i64, ptr %slot7, align 8
  store i64 %v370, ptr %slot73, align 8
  %v371 = load i64, ptr %slot6, align 8
  %p372 = inttoptr i64 %v371 to ptr
  store i32 0, ptr %p372, align 4, !alias.scope !3, !noalias !4
  %v373 = load i64, ptr %slot73, align 8
  %p374 = inttoptr i64 %v373 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p374, i64 40, i1 false)
  ret void
bb_failure:
  %v375 = load i64, ptr %slot4, align 8
  %p376 = inttoptr i64 %v375 to ptr
  call void @llvm.memset.p0.i64(ptr %p376, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v377 = load i64, ptr %slot4, align 8
  %p378 = inttoptr i64 %v377 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p378, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v379 = load i64, ptr %slot4, align 8
  %p380 = inttoptr i64 %v379 to ptr
  call void @llvm.memset.p0.i64(ptr %p380, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v381 = load i64, ptr %slot4, align 8
  %p382 = inttoptr i64 %v381 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p382, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4", linkageName: "myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 6640661139337974429, i64 0, !"myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!112 = !DILocation(line: 7, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!114 = !DILocation(line: 14, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!116 = !DILocation(line: 16, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!118 = !DILocation(line: 19, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!120 = !DILocation(line: 20, column: 0, scope: !121)
