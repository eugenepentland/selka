target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %callresult338 = alloca [24 x i8], align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %callresult430 = alloca [24 x i8], align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i32, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %callresult523 = alloca [24 x i8], align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %callresult615 = alloca [24 x i8], align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %callresult710 = alloca [24 x i8], align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i32, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %callresult802 = alloca [24 x i8], align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i32, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i32, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i32, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i32, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %callresult894 = alloca [24 x i8], align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i32, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i32, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i32, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i32, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i32, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i32, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i32, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %callresult986 = alloca [24 x i8], align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i32, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %callresult1078 = alloca [24 x i8], align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i32, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i32, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i32, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i32, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i32, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i32, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i32, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i32, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i32, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %callresult1170 = alloca [24 x i8], align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i32, align 8
  %slot1176 = alloca i32, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i32, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i32, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i32, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i32, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i32, align 8
  %slot1201 = alloca i32, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i32, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i32, align 8
  %slot1207 = alloca i32, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i32, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i32, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i32, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i32, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i32, align 8
  %slot1225 = alloca i32, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i32, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i32, align 8
  %slot1231 = alloca i32, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i32, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i32, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i32, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i32, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i32, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i32, align 8
  %slot1255 = alloca i32, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %callresult1262 = alloca [24 x i8], align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i32, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i32, align 8
  %slot1268 = alloca i32, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i32, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i32, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i32, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i32, align 8
  %slot1287 = alloca i32, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i32, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i32, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i32, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i32, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i32, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i32, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i32, align 8
  %slot1317 = alloca i32, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i32, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i32, align 8
  %slot1323 = alloca i32, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i32, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i32, align 8
  %slot1329 = alloca i32, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i32, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i32, align 8
  %slot1335 = alloca i32, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i32, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i32, align 8
  %slot1341 = alloca i32, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i32, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i32, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i64, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %callresult1371 = alloca [24 x i8], align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i32, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i32, align 8
  %slot1377 = alloca i32, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i32, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i32, align 8
  %slot1390 = alloca i32, align 8
  %slot1391 = alloca i32, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i32, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i32, align 8
  %slot1396 = alloca i32, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i32, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i32, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i32, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i32, align 8
  %slot1414 = alloca i32, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i32, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i32, align 8
  %slot1420 = alloca i32, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i32, align 8
  %slot1424 = alloca i64, align 8
  %slot1425 = alloca i32, align 8
  %slot1426 = alloca i32, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i32, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i32, align 8
  %slot1432 = alloca i32, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i32, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i32, align 8
  %slot1438 = alloca i32, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i32, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i32, align 8
  %slot1444 = alloca i32, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i32, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i32, align 8
  %slot1450 = alloca i32, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i32, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i32, align 8
  %slot1456 = alloca i32, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1459 = load i64, ptr %slot1, align 8
  %op1460 = add i64 %v1459, 32
  store i64 %op1460, ptr %slot4, align 8
  %mem1461 = alloca i8, i64 24, align 8
  %ptr1462 = ptrtoint ptr %mem1461 to i64
  store i64 %ptr1462, ptr %slot5, align 8
  %mem1463 = alloca i8, i64 8, align 8
  %ptr1464 = ptrtoint ptr %mem1463 to i64
  store i64 %ptr1464, ptr %slot6, align 8
  %mem1465 = alloca i8, i64 8, align 8
  %ptr1466 = ptrtoint ptr %mem1465 to i64
  store i64 %ptr1466, ptr %slot7, align 8
  %mem1467 = alloca i8, i64 8, align 8
  %ptr1468 = ptrtoint ptr %mem1467 to i64
  store i64 %ptr1468, ptr %slot8, align 8
  %mem1469 = alloca i8, i64 8, align 8
  %ptr1470 = ptrtoint ptr %mem1469 to i64
  store i64 %ptr1470, ptr %slot9, align 8
  %mem1471 = alloca i8, i64 8, align 8
  %ptr1472 = ptrtoint ptr %mem1471 to i64
  store i64 %ptr1472, ptr %slot10, align 8
  %mem1473 = alloca i8, i64 8, align 8
  %ptr1474 = ptrtoint ptr %mem1473 to i64
  store i64 %ptr1474, ptr %slot11, align 8
  %mem1475 = alloca i8, i64 8, align 8
  %ptr1476 = ptrtoint ptr %mem1475 to i64
  store i64 %ptr1476, ptr %slot12, align 8
  %mem1477 = alloca i8, i64 8, align 8
  %ptr1478 = ptrtoint ptr %mem1477 to i64
  store i64 %ptr1478, ptr %slot13, align 8
  %mem1479 = alloca i8, i64 8, align 8
  %ptr1480 = ptrtoint ptr %mem1479 to i64
  store i64 %ptr1480, ptr %slot14, align 8
  %mem1481 = alloca i8, i64 8, align 8
  %ptr1482 = ptrtoint ptr %mem1481 to i64
  store i64 %ptr1482, ptr %slot15, align 8
  %mem1483 = alloca i8, i64 8, align 8
  %ptr1484 = ptrtoint ptr %mem1483 to i64
  store i64 %ptr1484, ptr %slot16, align 8
  %mem1485 = alloca i8, i64 8, align 8
  %ptr1486 = ptrtoint ptr %mem1485 to i64
  store i64 %ptr1486, ptr %slot17, align 8
  %mem1487 = alloca i8, i64 8, align 8
  %ptr1488 = ptrtoint ptr %mem1487 to i64
  store i64 %ptr1488, ptr %slot18, align 8
  %mem1489 = alloca i8, i64 8, align 8
  %ptr1490 = ptrtoint ptr %mem1489 to i64
  store i64 %ptr1490, ptr %slot19, align 8
  %mem1491 = alloca i8, i64 8, align 8
  %ptr1492 = ptrtoint ptr %mem1491 to i64
  store i64 %ptr1492, ptr %slot20, align 8
  %mem1493 = alloca i8, i64 8, align 8
  %ptr1494 = ptrtoint ptr %mem1493 to i64
  store i64 %ptr1494, ptr %slot21, align 8
  %mem1495 = alloca i8, i64 8, align 8
  %ptr1496 = ptrtoint ptr %mem1495 to i64
  store i64 %ptr1496, ptr %slot22, align 8
  %mem1497 = alloca i8, i64 8, align 8
  %ptr1498 = ptrtoint ptr %mem1497 to i64
  store i64 %ptr1498, ptr %slot23, align 8
  %mem1499 = alloca i8, i64 8, align 8
  %ptr1500 = ptrtoint ptr %mem1499 to i64
  store i64 %ptr1500, ptr %slot24, align 8
  %mem1501 = alloca i8, i64 8, align 8
  %ptr1502 = ptrtoint ptr %mem1501 to i64
  store i64 %ptr1502, ptr %slot25, align 8
  %mem1503 = alloca i8, i64 8, align 8
  %ptr1504 = ptrtoint ptr %mem1503 to i64
  store i64 %ptr1504, ptr %slot26, align 8
  %mem1505 = alloca i8, i64 8, align 8
  %ptr1506 = ptrtoint ptr %mem1505 to i64
  store i64 %ptr1506, ptr %slot27, align 8
  %mem1507 = alloca i8, i64 8, align 8
  %ptr1508 = ptrtoint ptr %mem1507 to i64
  store i64 %ptr1508, ptr %slot28, align 8
  %mem1509 = alloca i8, i64 8, align 8
  %ptr1510 = ptrtoint ptr %mem1509 to i64
  store i64 %ptr1510, ptr %slot29, align 8
  %mem1511 = alloca i8, i64 304, align 8
  %ptr1512 = ptrtoint ptr %mem1511 to i64
  store i64 %ptr1512, ptr %slot30, align 8
  %mem1513 = alloca i8, i64 304, align 8
  %ptr1514 = ptrtoint ptr %mem1513 to i64
  store i64 %ptr1514, ptr %slot31, align 8
  %mem1515 = alloca i8, i64 8, align 8
  %ptr1516 = ptrtoint ptr %mem1515 to i64
  store i64 %ptr1516, ptr %slot32, align 8
  %mem1517 = alloca i8, i64 8, align 8
  %ptr1518 = ptrtoint ptr %mem1517 to i64
  store i64 %ptr1518, ptr %slot33, align 8
  %mem1519 = alloca i8, i64 8, align 8
  %ptr1520 = ptrtoint ptr %mem1519 to i64
  store i64 %ptr1520, ptr %slot34, align 8
  %mem1521 = alloca i8, i64 8, align 8
  %ptr1522 = ptrtoint ptr %mem1521 to i64
  store i64 %ptr1522, ptr %slot35, align 8
  %mem1523 = alloca i8, i64 72, align 8
  %ptr1524 = ptrtoint ptr %mem1523 to i64
  store i64 %ptr1524, ptr %slot36, align 8
  %mem1525 = alloca i8, i64 56, align 8
  %ptr1526 = ptrtoint ptr %mem1525 to i64
  store i64 %ptr1526, ptr %slot37, align 8
  %mem1527 = alloca i8, i64 56, align 8
  %ptr1528 = ptrtoint ptr %mem1527 to i64
  store i64 %ptr1528, ptr %slot38, align 8
  %mem1529 = alloca i8, i64 8, align 8
  %ptr1530 = ptrtoint ptr %mem1529 to i64
  store i64 %ptr1530, ptr %slot39, align 8
  %mem1531 = alloca i8, i64 56, align 8
  %ptr1532 = ptrtoint ptr %mem1531 to i64
  store i64 %ptr1532, ptr %slot40, align 8
  %mem1533 = alloca i8, i64 56, align 8
  %ptr1534 = ptrtoint ptr %mem1533 to i64
  store i64 %ptr1534, ptr %slot41, align 8
  %mem1535 = alloca i8, i64 64, align 8
  %ptr1536 = ptrtoint ptr %mem1535 to i64
  store i64 %ptr1536, ptr %slot42, align 8
  %mem1537 = alloca i8, i64 104, align 8
  %ptr1538 = ptrtoint ptr %mem1537 to i64
  store i64 %ptr1538, ptr %slot43, align 8
  %mem1539 = alloca i8, i64 56, align 8
  %ptr1540 = ptrtoint ptr %mem1539 to i64
  store i64 %ptr1540, ptr %slot44, align 8
  %mem1541 = alloca i8, i64 48, align 8
  %ptr1542 = ptrtoint ptr %mem1541 to i64
  store i64 %ptr1542, ptr %slot45, align 8
  %mem1543 = alloca i8, i64 64, align 8
  %ptr1544 = ptrtoint ptr %mem1543 to i64
  store i64 %ptr1544, ptr %slot46, align 8
  %mem1545 = alloca i8, i64 8, align 8
  %ptr1546 = ptrtoint ptr %mem1545 to i64
  store i64 %ptr1546, ptr %slot47, align 8
  %mem1547 = alloca i8, i64 8, align 8
  %ptr1548 = ptrtoint ptr %mem1547 to i64
  store i64 %ptr1548, ptr %slot48, align 8
  %mem1549 = alloca i8, i64 8, align 8
  %ptr1550 = ptrtoint ptr %mem1549 to i64
  store i64 %ptr1550, ptr %slot49, align 8
  %mem1551 = alloca i8, i64 8, align 8
  %ptr1552 = ptrtoint ptr %mem1551 to i64
  store i64 %ptr1552, ptr %slot50, align 8
  %mem1553 = alloca i8, i64 8, align 8
  %ptr1554 = ptrtoint ptr %mem1553 to i64
  store i64 %ptr1554, ptr %slot51, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1555 = alloca i8, i64 8, align 8
  %ptr1556 = ptrtoint ptr %mem1555 to i64
  store i64 %ptr1556, ptr %slot52, align 8
  %v1557 = load i64, ptr %slot1, align 8
  %op1558 = add i64 %v1557, 64
  store i64 %op1558, ptr %slot53, align 8
  %v1559 = load i64, ptr %slot53, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %ld1561 = load i64, ptr %p1560, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1561, ptr %slot54, align 8
  %stack1562 = call ptr @llvm.stacksave()
  %stackaddr1563 = ptrtoint ptr %stack1562 to i64
  %v1564 = load i64, ptr %slot54, align 8
  %cmp1565 = icmp ult i64 %stackaddr1563, %v1564
  %cv1566 = zext i1 %cmp1565 to i64
  store i64 %cv1566, ptr %slot55, align 8
  %v1567 = load i64, ptr %slot55, align 8
  %cond1568 = icmp ne i64 %v1567, 0
  br i1 %cond1568, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1569 = load i64, ptr %slot1, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  call void @myl_qbe_fail_frame(ptr %p1570) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1571 = load i64, ptr %slot34, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i64 0, ptr %p1572, align 8, !alias.scope !3, !noalias !4
  %v1573 = load i64, ptr %slot2, align 8
  %v1574 = load i64, ptr %slot32, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i64 %v1573, ptr %p1575, align 8, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot3, align 8
  %v1577 = load i64, ptr %slot33, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  store i64 %v1576, ptr %p1578, align 8, !alias.scope !3, !noalias !4
  %v1579 = load i64, ptr %slot1, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  %call1581 = call ptr @myl_qbe_heap(ptr %p1580) nomerge, !dbg !112
  %calladdr1582 = ptrtoint ptr %call1581 to i64
  store i64 %calladdr1582, ptr %slot56, align 8
  %v1583 = load i64, ptr %slot1, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %call1585 = call i64 @myl_qbe_region_mark(ptr %p1584) nomerge, !dbg !112
  store i64 %call1585, ptr %slot57, align 8
  %v1586 = load i64, ptr %slot6, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  store i32 0, ptr %p1587, align 4, !alias.scope !3, !noalias !4
  %v1588 = load i64, ptr %slot7, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  store i32 0, ptr %p1589, align 4, !alias.scope !3, !noalias !4
  %v1590 = load i64, ptr %slot8, align 8
  %p1591 = inttoptr i64 %v1590 to ptr
  store i32 0, ptr %p1591, align 4, !alias.scope !3, !noalias !4
  %v1592 = load i64, ptr %slot9, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  store i32 0, ptr %p1593, align 4, !alias.scope !3, !noalias !4
  %v1594 = load i64, ptr %slot10, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  store i32 0, ptr %p1595, align 4, !alias.scope !3, !noalias !4
  %v1596 = load i64, ptr %slot11, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  store i32 0, ptr %p1597, align 4, !alias.scope !3, !noalias !4
  %v1598 = load i64, ptr %slot12, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  store i32 0, ptr %p1599, align 4, !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot13, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  store i32 0, ptr %p1601, align 4, !alias.scope !3, !noalias !4
  %v1602 = load i64, ptr %slot14, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  store i32 0, ptr %p1603, align 4, !alias.scope !3, !noalias !4
  %v1604 = load i64, ptr %slot15, align 8
  %p1605 = inttoptr i64 %v1604 to ptr
  store i32 0, ptr %p1605, align 4, !alias.scope !3, !noalias !4
  %v1606 = load i64, ptr %slot16, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  store i32 0, ptr %p1607, align 4, !alias.scope !3, !noalias !4
  %v1608 = load i64, ptr %slot17, align 8
  %p1609 = inttoptr i64 %v1608 to ptr
  store i32 0, ptr %p1609, align 4, !alias.scope !3, !noalias !4
  %v1610 = load i64, ptr %slot18, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  store i32 0, ptr %p1611, align 4, !alias.scope !3, !noalias !4
  %v1612 = load i64, ptr %slot19, align 8
  %p1613 = inttoptr i64 %v1612 to ptr
  store i32 0, ptr %p1613, align 4, !alias.scope !3, !noalias !4
  %v1614 = load i64, ptr %slot20, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i32 0, ptr %p1615, align 4, !alias.scope !3, !noalias !4
  %v1616 = load i64, ptr %slot21, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  store i32 0, ptr %p1617, align 4, !alias.scope !3, !noalias !4
  %v1618 = load i64, ptr %slot22, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i32 0, ptr %p1619, align 4, !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot23, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  store i32 0, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot24, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 0, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot25, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i32 0, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot26, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  store i32 0, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  %v1628 = load i64, ptr %slot27, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i32 0, ptr %p1629, align 4, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot28, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i32 0, ptr %p1631, align 4, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot29, align 8
  %p1633 = inttoptr i64 %v1632 to ptr
  store i32 0, ptr %p1633, align 4, !alias.scope !3, !noalias !4
  %v1634 = load i64, ptr %slot7, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  store i32 2, ptr %p1635, align 4, !alias.scope !3, !noalias !4
  %v1636 = load i64, ptr %slot9, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  store i32 2, ptr %p1637, align 4, !alias.scope !3, !noalias !4
  %v1638 = load i64, ptr %slot11, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 2, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot13, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  store i32 2, ptr %p1641, align 4, !alias.scope !3, !noalias !4
  %v1642 = load i64, ptr %slot15, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  store i32 2, ptr %p1643, align 4, !alias.scope !3, !noalias !4
  %v1644 = load i64, ptr %slot17, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  store i32 2, ptr %p1645, align 4, !alias.scope !3, !noalias !4
  %v1646 = load i64, ptr %slot19, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  store i32 2, ptr %p1647, align 4, !alias.scope !3, !noalias !4
  %v1648 = load i64, ptr %slot21, align 8
  %p1649 = inttoptr i64 %v1648 to ptr
  store i32 2, ptr %p1649, align 4, !alias.scope !3, !noalias !4
  %v1650 = load i64, ptr %slot23, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  store i32 2, ptr %p1651, align 4, !alias.scope !3, !noalias !4
  %v1652 = load i64, ptr %slot25, align 8
  %p1653 = inttoptr i64 %v1652 to ptr
  store i32 2, ptr %p1653, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1654 = load i64, ptr %slot32, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  %ld1656 = load i64, ptr %p1655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1656, ptr %slot58, align 8
  %v1657 = load i64, ptr %slot58, align 8
  %v1658 = load i64, ptr %slot47, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  store i64 %v1657, ptr %p1659, align 8, !alias.scope !3, !noalias !4
  %v1660 = load i64, ptr %slot47, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  %ld1662 = load i64, ptr %p1661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1662, ptr %slot59, align 8
  %v1663 = load i64, ptr %slot59, align 8
  %op1664 = add i64 %v1663, 0
  store i64 %op1664, ptr %slot60, align 8
  %v1665 = load i64, ptr %slot60, align 8
  %v1666 = load i64, ptr %slot47, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i64 %v1665, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  %v1668 = load i64, ptr %slot26, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  %ld1670 = load i32, ptr %p1669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1670, ptr %slot61, align 8
  %v1671 = load i32, ptr %slot61, align 8
  %cv1672 = zext i32 %v1671 to i64
  %cond1673 = icmp ne i64 %cv1672, 0
  br i1 %cond1673, label %bb_rcslotdrop24, label %bb_rcslotdone24
bb_rcslotdrop24:
  %v1674 = load i64, ptr %slot26, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i32 0, ptr %p1675, align 4, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot30, align 8
  store i64 %v1676, ptr %slot62, align 8
  %v1677 = load i64, ptr %slot27, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  %ld1679 = load i32, ptr %p1678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1679, ptr %slot63, align 8
  %v1680 = load i32, ptr %slot63, align 8
  %op1681 = and i32 %v1680, 28
  store i32 %op1681, ptr %slot64, align 8
  %v1682 = load i32, ptr %slot64, align 8
  %cv1683 = zext i32 %v1682 to i64
  %cond1684 = icmp ne i64 %cv1683, 0
  br i1 %cond1684, label %bb_rcslotrole24, label %bb_rcslotowner24
bb_rcslotrole24:
  %v1685 = load i64, ptr %slot56, align 8
  store i64 %v1685, ptr %slot65, align 8
  %v1686 = load i64, ptr %slot65, align 8
  %v1687 = load i64, ptr %slot62, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1686, i64 %v1687) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotowner24:
  %v1688 = load i64, ptr %slot56, align 8
  store i64 %v1688, ptr %slot66, align 8
  %v1689 = load i64, ptr %slot66, align 8
  %v1690 = load i64, ptr %slot62, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1689, i64 %v1690) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotdone24:
  %v1691 = load i64, ptr %slot47, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %ld1693 = load i64, ptr %p1692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1693, ptr %slot67, align 8
  %v1694 = load i64, ptr %slot67, align 8
  %op1695 = add i64 %v1694, 0
  store i64 %op1695, ptr %slot68, align 8
  %v1696 = load i64, ptr %slot68, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  %ld1698 = load i64, ptr %p1697, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1698, ptr %slot69, align 8
  %v1699 = load i64, ptr %slot69, align 8
  %v1700 = load i64, ptr %slot47, align 8
  %p1701 = inttoptr i64 %v1700 to ptr
  store i64 %v1699, ptr %p1701, align 8, !alias.scope !3, !noalias !4
  %v1702 = load i64, ptr %slot26, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  %ld1704 = load i32, ptr %p1703, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1704, ptr %slot70, align 8
  %v1705 = load i32, ptr %slot70, align 8
  %cv1706 = zext i32 %v1705 to i64
  %cond1707 = icmp ne i64 %cv1706, 0
  br i1 %cond1707, label %bb_rcslotdrop36, label %bb_rcslotdone36
bb_rcslotdrop36:
  %v1708 = load i64, ptr %slot26, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  store i32 0, ptr %p1709, align 4, !alias.scope !3, !noalias !4
  %v1710 = load i64, ptr %slot30, align 8
  store i64 %v1710, ptr %slot71, align 8
  %v1711 = load i64, ptr %slot27, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %ld1713 = load i32, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1713, ptr %slot72, align 8
  %v1714 = load i32, ptr %slot72, align 8
  %op1715 = and i32 %v1714, 28
  store i32 %op1715, ptr %slot73, align 8
  %v1716 = load i32, ptr %slot73, align 8
  %cv1717 = zext i32 %v1716 to i64
  %cond1718 = icmp ne i64 %cv1717, 0
  br i1 %cond1718, label %bb_rcslotrole36, label %bb_rcslotowner36
bb_rcslotrole36:
  %v1719 = load i64, ptr %slot56, align 8
  store i64 %v1719, ptr %slot74, align 8
  %v1720 = load i64, ptr %slot74, align 8
  %v1721 = load i64, ptr %slot71, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v1720, i64 %v1721) nomerge, !dbg !116
  br label %bb_rcslotdone36
bb_rcslotowner36:
  %v1722 = load i64, ptr %slot56, align 8
  store i64 %v1722, ptr %slot75, align 8
  %v1723 = load i64, ptr %slot75, align 8
  %v1724 = load i64, ptr %slot71, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v1723, i64 %v1724) nomerge, !dbg !116
  br label %bb_rcslotdone36
bb_rcslotdone36:
  %v1725 = load i64, ptr %slot47, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  %ld1727 = load i64, ptr %p1726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1727, ptr %slot76, align 8
  %v1728 = load i64, ptr %slot76, align 8
  %v1729 = load i64, ptr %slot34, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i64 %v1728, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot33, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %ld1733 = load i64, ptr %p1732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1733, ptr %slot77, align 8
  %v1734 = load i64, ptr %slot77, align 8
  %v1735 = load i64, ptr %slot47, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  store i64 %v1734, ptr %p1736, align 8, !alias.scope !3, !noalias !4
  %v1737 = load i64, ptr %slot47, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  %ld1739 = load i64, ptr %p1738, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1739, ptr %slot78, align 8
  %v1740 = load i64, ptr %slot78, align 8
  %v1741 = load i64, ptr %slot35, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i64 %v1740, ptr %p1742, align 8, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot35, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %ld1745 = load i64, ptr %p1744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1745, ptr %slot79, align 8
  %v1746 = load i64, ptr %slot79, align 8
  %v1747 = load i64, ptr %slot47, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i64 %v1746, ptr %p1748, align 8, !alias.scope !3, !noalias !4
  %v1749 = load i64, ptr %slot48, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  store i64 0, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  %v1751 = load i64, ptr %slot48, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  %ld1753 = load i64, ptr %p1752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1753, ptr %slot80, align 8
  %v1754 = load i64, ptr %slot47, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  %ld1756 = load i64, ptr %p1755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1756, ptr %slot81, align 8
  %v1757 = load i64, ptr %slot81, align 8
  %v1758 = load i64, ptr %slot80, align 8
  %cmp1759 = icmp slt i64 %v1757, %v1758
  %cv1760 = zext i1 %cmp1759 to i64
  store i64 %cv1760, ptr %slot82, align 8
  %v1761 = load i64, ptr %slot82, align 8
  %v1762 = load i64, ptr %slot47, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  store i64 %v1761, ptr %p1763, align 8, !alias.scope !3, !noalias !4
  %v1764 = load i64, ptr %slot47, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  %ld1766 = load i64, ptr %p1765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1766, ptr %slot83, align 8
  %v1767 = load i64, ptr %slot83, align 8
  %cond1768 = icmp ne i64 %v1767, 0
  br i1 %cond1768, label %bb_next51, label %bb_i15
bb_next51:
  %v1769 = load i64, ptr %slot34, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  %ld1771 = load i64, ptr %p1770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1771, ptr %slot84, align 8
  %v1772 = load i64, ptr %slot84, align 8
  %op1773 = add i64 %v1772, 0
  store i64 %op1773, ptr %slot85, align 8
  %v1774 = load i64, ptr %slot85, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  %ld1776 = load i64, ptr %p1775, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1776, ptr %slot86, align 8
  %v1777 = load i64, ptr %slot86, align 8
  %v1778 = load i64, ptr %slot47, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i64 %v1777, ptr %p1779, align 8, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot47, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i64, ptr %p1781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1782, ptr %slot87, align 8
  %v1783 = load i64, ptr %slot87, align 8
  %cmp1784 = icmp ugt i64 %v1783, 9223372036854775807
  %cv1785 = zext i1 %cmp1784 to i64
  store i64 %cv1785, ptr %slot88, align 8
  %v1786 = load i64, ptr %slot88, align 8
  %cond1787 = icmp ne i64 %v1786, 0
  br i1 %cond1787, label %bb_cast_overflow56, label %bb_cast_ok56
bb_cast_overflow56:
  %v1788 = load i64, ptr %slot1, align 8
  %p1789 = inttoptr i64 %v1788 to ptr
  %v1790 = load i64, ptr %slot87, align 8
  call void @myl_qbe_fail_cast(ptr %p1789, i64 %v1790, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok56:
  %v1791 = load i64, ptr %slot87, align 8
  %v1792 = load i64, ptr %slot47, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  store i64 %v1791, ptr %p1793, align 8, !alias.scope !3, !noalias !4
  %v1794 = load i64, ptr %slot35, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  %ld1796 = load i64, ptr %p1795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1796, ptr %slot89, align 8
  %v1797 = load i64, ptr %slot89, align 8
  %v1798 = load i64, ptr %slot48, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  store i64 %v1797, ptr %p1799, align 8, !alias.scope !3, !noalias !4
  %v1800 = load i64, ptr %slot48, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %ld1802 = load i64, ptr %p1801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1802, ptr %slot90, align 8
  %v1803 = load i64, ptr %slot47, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %ld1805 = load i64, ptr %p1804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1805, ptr %slot91, align 8
  %v1806 = load i64, ptr %slot91, align 8
  %v1807 = load i64, ptr %slot90, align 8
  %ovpair1809 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1806, i64 %v1807)
  %op1808 = extractvalue { i64, i1 } %ovpair1809, 0
  %ov1810 = extractvalue { i64, i1 } %ovpair1809, 1
  store i64 %op1808, ptr %slot92, align 8
  %v1811 = load i64, ptr %slot91, align 8
  %v1812 = load i64, ptr %slot92, align 8
  %op1813 = xor i64 %v1811, %v1812
  store i64 %op1813, ptr %slot93, align 8
  %v1814 = load i64, ptr %slot90, align 8
  %v1815 = load i64, ptr %slot92, align 8
  %op1816 = xor i64 %v1814, %v1815
  store i64 %op1816, ptr %slot94, align 8
  %v1817 = load i64, ptr %slot93, align 8
  %v1818 = load i64, ptr %slot94, align 8
  %op1819 = and i64 %v1817, %v1818
  store i64 %op1819, ptr %slot95, align 8
  %cv1820 = zext i1 %ov1810 to i64
  store i64 %cv1820, ptr %slot96, align 8
  %v1821 = load i64, ptr %slot96, align 8
  %cond1822 = icmp ne i64 %v1821, 0
  br i1 %cond1822, label %bb_overflow60, label %bb_checked60
bb_overflow60:
  %v1823 = load i64, ptr %slot1, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  %v1825 = load i64, ptr %slot91, align 8
  %v1826 = load i64, ptr %slot90, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1824, i64 0, i64 %v1825, i64 %v1826, i64 64) nomerge, !dbg !120
  unreachable
bb_checked60:
  %v1827 = load i64, ptr %slot92, align 8
  %v1828 = load i64, ptr %slot47, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  store i64 %v1827, ptr %p1829, align 8, !alias.scope !3, !noalias !4
  %v1830 = load i64, ptr %slot47, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  %ld1832 = load i64, ptr %p1831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1832, ptr %slot97, align 8
  %v1833 = load i64, ptr %slot97, align 8
  %v1834 = load i64, ptr %slot35, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  store i64 %v1833, ptr %p1835, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v1836 = load i64, ptr %slot35, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %ld1838 = load i64, ptr %p1837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1838, ptr %slot98, align 8
  %v1839 = load i64, ptr %slot98, align 8
  %v1840 = load i64, ptr %slot47, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  store i64 %v1839, ptr %p1841, align 8, !alias.scope !3, !noalias !4
  %v1842 = load i64, ptr %slot34, align 8
  %p1843 = inttoptr i64 %v1842 to ptr
  %ld1844 = load i64, ptr %p1843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1844, ptr %slot99, align 8
  %v1845 = load i64, ptr %slot47, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  %ld1847 = load i64, ptr %p1846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1847, ptr %slot100, align 8
  %v1848 = load i64, ptr %slot99, align 8
  %p1849 = inttoptr i64 %v1848 to ptr
  %ld1850 = load i64, ptr %p1849, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1850, ptr %slot101, align 8
  %v1851 = load i64, ptr %slot100, align 8
  %v1852 = load i64, ptr %slot101, align 8
  %cmp1853 = icmp ult i64 %v1851, %v1852
  %cv1854 = zext i1 %cmp1853 to i64
  store i64 %cv1854, ptr %slot102, align 8
  %v1855 = load i64, ptr %slot102, align 8
  %cond1856 = icmp ne i64 %v1855, 0
  br i1 %cond1856, label %bb_success72, label %bb_failed72
bb_failed72:
  %v1857 = load i64, ptr %slot1, align 8
  %p1858 = inttoptr i64 %v1857 to ptr
  %v1859 = load i64, ptr %slot100, align 8
  %v1860 = load i64, ptr %slot101, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1858, i64 %v1859, i64 %v1860) nomerge, !dbg !122
  unreachable
bb_success72:
  %v1861 = load i64, ptr %slot99, align 8
  %op1862 = add i64 %v1861, 32
  store i64 %op1862, ptr %slot103, align 8
  %v1863 = load i64, ptr %slot103, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  %ld1865 = load i64, ptr %p1864, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1865, ptr %slot104, align 8
  %v1866 = load i64, ptr %slot100, align 8
  %op1867 = mul i64 %v1866, 112
  store i64 %op1867, ptr %slot105, align 8
  %v1868 = load i64, ptr %slot104, align 8
  %v1869 = load i64, ptr %slot105, align 8
  %op1870 = add i64 %v1868, %v1869
  store i64 %op1870, ptr %slot106, align 8
  %v1871 = load i64, ptr %slot106, align 8
  %v1872 = load i64, ptr %slot47, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  store i64 %v1871, ptr %p1873, align 8, !alias.scope !3, !noalias !4
  %v1874 = load i64, ptr %slot47, align 8
  %p1875 = inttoptr i64 %v1874 to ptr
  %ld1876 = load i64, ptr %p1875, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1876, ptr %slot107, align 8
  %v1877 = load i64, ptr %slot31, align 8
  store i64 %v1877, ptr %slot108, align 8
  %v1878 = load i64, ptr %slot56, align 8
  %v1879 = load i64, ptr %slot108, align 8
  %v1880 = load i64, ptr %slot107, align 8
  %call1881 = call i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_loan(i64 %v1878, i64 %v1879, i64 %v1880) nomerge, !dbg !122
  store i32 %call1881, ptr %slot109, align 8
  %v1882 = load i32, ptr %slot109, align 8
  %cv1883 = zext i32 %v1882 to i64
  %cond1884 = icmp ne i64 %cv1883, 0
  br i1 %cond1884, label %bb_rcsuccess80, label %bb_rcfailure80
bb_rcfailure80:
  %v1885 = load i64, ptr %slot56, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  %call1887 = call i32 @myl_rc_take_failure(ptr %p1886) nomerge, !dbg !122
  store i32 %call1887, ptr %slot110, align 8
  %v1888 = load i64, ptr %slot1, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  %v1890 = load i32, ptr %slot110, align 8
  %call1891 = call i32 @myl_qbe_rc_status(ptr %p1889, i32 %v1890) nomerge, !dbg !122
  store i32 %call1891, ptr %slot111, align 8
  br label %bb_failure
bb_rcsuccess80:
  %v1892 = load i64, ptr %slot29, align 8
  %p1893 = inttoptr i64 %v1892 to ptr
  store i32 2, ptr %p1893, align 4, !alias.scope !3, !noalias !4
  %v1894 = load i64, ptr %slot29, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  store i32 16, ptr %p1895, align 4, !alias.scope !3, !noalias !4
  %v1896 = load i64, ptr %slot28, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  store i32 1, ptr %p1897, align 4, !alias.scope !3, !noalias !4
  %v1898 = load i64, ptr %slot30, align 8
  store i64 %v1898, ptr %slot112, align 8
  %v1899 = load i64, ptr %slot31, align 8
  store i64 %v1899, ptr %slot113, align 8
  %v1900 = load i64, ptr %slot113, align 8
  %v1901 = load i64, ptr %slot112, align 8
  %p1902 = inttoptr i64 %v1900 to ptr
  %p1903 = inttoptr i64 %v1901 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1903, ptr %p1902, i64 112, i1 false), !alias.scope !3, !noalias !4
  %v1904 = load i64, ptr %slot27, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  store i32 2, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  %v1906 = load i64, ptr %slot29, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  %ld1908 = load i32, ptr %p1907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1908, ptr %slot114, align 8
  %v1909 = load i32, ptr %slot114, align 8
  %v1910 = load i64, ptr %slot27, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i32 %v1909, ptr %p1911, align 4, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot28, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  store i32 0, ptr %p1913, align 4, !alias.scope !3, !noalias !4
  %v1914 = load i64, ptr %slot26, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i32 1, ptr %p1915, align 4, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot112, align 8
  %v1917 = load i64, ptr %slot47, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  store i64 %v1916, ptr %p1918, align 8, !alias.scope !3, !noalias !4
  %v1919 = load i64, ptr %slot47, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i64, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1921, ptr %slot115, align 8
  %v1922 = load i64, ptr %slot115, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %ld1924 = load i32, ptr %p1923, align 4, !alias.scope !3, !noalias !4
  %ext1925 = zext i32 %ld1924 to i64
  store i64 %ext1925, ptr %slot116, align 8
  %v1926 = load i64, ptr %slot116, align 8
  %cmp1927 = icmp eq i64 %v1926, 0
  %cv1928 = zext i1 %cmp1927 to i64
  store i64 %cv1928, ptr %slot117, align 8
  %v1929 = load i64, ptr %slot117, align 8
  %cond1930 = icmp ne i64 %v1929, 0
  br i1 %cond1930, label %bb_rcarm96, label %bb_rcarmnext96
bb_rcarm96:
  %v1931 = load i64, ptr %slot31, align 8
  store i64 %v1931, ptr %slot118, align 8
  %v1932 = load i64, ptr %slot115, align 8
  %op1933 = add i64 %v1932, 8
  store i64 %op1933, ptr %slot119, align 8
  %v1934 = load i64, ptr %slot57, align 8
  store i64 %v1934, ptr %slot120, align 8
  %v1935 = load i64, ptr %slot56, align 8
  %v1936 = load i64, ptr %slot118, align 8
  %v1937 = load i64, ptr %slot119, align 8
  %v1938 = load i64, ptr %slot120, align 8
  %cv1939 = trunc i64 %v1938 to i32
  %call1940 = call i32 @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_retain(i64 %v1935, i64 %v1936, i64 %v1937, i32 %cv1939) nomerge, !dbg !124
  store i32 %call1940, ptr %slot121, align 8
  %v1941 = load i32, ptr %slot121, align 8
  %cv1942 = zext i32 %v1941 to i64
  %cond1943 = icmp ne i64 %cv1942, 0
  br i1 %cond1943, label %bb_rcsuccess101, label %bb_rcfailure101
bb_rcfailure101:
  %v1944 = load i64, ptr %slot56, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  %call1946 = call i32 @myl_rc_take_failure(ptr %p1945) nomerge, !dbg !124
  store i32 %call1946, ptr %slot122, align 8
  %v1947 = load i64, ptr %slot1, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  %v1949 = load i32, ptr %slot122, align 8
  %call1950 = call i32 @myl_qbe_rc_status(ptr %p1948, i32 %v1949) nomerge, !dbg !124
  store i32 %call1950, ptr %slot123, align 8
  br label %bb_failure
bb_rcsuccess101:
  %v1951 = load i64, ptr %slot29, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  store i32 2, ptr %p1952, align 4, !alias.scope !3, !noalias !4
  %v1953 = load i64, ptr %slot28, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i32 1, ptr %p1954, align 4, !alias.scope !3, !noalias !4
  %v1955 = load i64, ptr %slot6, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  %ld1957 = load i32, ptr %p1956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1957, ptr %slot124, align 8
  %v1958 = load i32, ptr %slot124, align 8
  %cv1959 = zext i32 %v1958 to i64
  %cond1960 = icmp ne i64 %cv1959, 0
  br i1 %cond1960, label %bb_rcslotdrop108, label %bb_rcslotdone108
bb_rcslotdrop108:
  %v1961 = load i64, ptr %slot6, align 8
  %p1962 = inttoptr i64 %v1961 to ptr
  store i32 0, ptr %p1962, align 4, !alias.scope !3, !noalias !4
  %v1963 = load i64, ptr %slot36, align 8
  store i64 %v1963, ptr %slot125, align 8
  %v1964 = load i64, ptr %slot7, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %ld1966 = load i32, ptr %p1965, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1966, ptr %slot126, align 8
  %v1967 = load i32, ptr %slot126, align 8
  %op1968 = and i32 %v1967, 28
  store i32 %op1968, ptr %slot127, align 8
  %v1969 = load i32, ptr %slot127, align 8
  %cv1970 = zext i32 %v1969 to i64
  %cond1971 = icmp ne i64 %cv1970, 0
  br i1 %cond1971, label %bb_rcslotrole108, label %bb_rcslotowner108
bb_rcslotrole108:
  %v1972 = load i64, ptr %slot56, align 8
  store i64 %v1972, ptr %slot128, align 8
  %v1973 = load i64, ptr %slot128, align 8
  %v1974 = load i64, ptr %slot125, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v1973, i64 %v1974) nomerge, !dbg !124
  br label %bb_rcslotdone108
bb_rcslotowner108:
  %v1975 = load i64, ptr %slot56, align 8
  store i64 %v1975, ptr %slot129, align 8
  %v1976 = load i64, ptr %slot129, align 8
  %v1977 = load i64, ptr %slot125, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v1976, i64 %v1977) nomerge, !dbg !124
  br label %bb_rcslotdone108
bb_rcslotdone108:
  %v1978 = load i64, ptr %slot118, align 8
  %v1979 = load i64, ptr %slot36, align 8
  %p1980 = inttoptr i64 %v1978 to ptr
  %p1981 = inttoptr i64 %v1979 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1981, ptr %p1980, i64 72, i1 false), !alias.scope !3, !noalias !4
  %v1982 = load i64, ptr %slot28, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  store i32 0, ptr %p1983, align 4, !alias.scope !3, !noalias !4
  %v1984 = load i64, ptr %slot36, align 8
  store i64 %v1984, ptr %slot130, align 8
  %v1985 = load i64, ptr %slot7, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  store i32 2, ptr %p1986, align 4, !alias.scope !3, !noalias !4
  %v1987 = load i64, ptr %slot6, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  store i32 1, ptr %p1988, align 4, !alias.scope !3, !noalias !4
  %v1989 = load i64, ptr %slot26, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  %ld1991 = load i32, ptr %p1990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1991, ptr %slot131, align 8
  %v1992 = load i32, ptr %slot131, align 8
  %cv1993 = zext i32 %v1992 to i64
  %cond1994 = icmp ne i64 %cv1993, 0
  br i1 %cond1994, label %bb_rcslotdrop121, label %bb_rcslotdone121
bb_rcslotdrop121:
  %v1995 = load i64, ptr %slot26, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i32 0, ptr %p1996, align 4, !alias.scope !3, !noalias !4
  %v1997 = load i64, ptr %slot30, align 8
  store i64 %v1997, ptr %slot132, align 8
  %v1998 = load i64, ptr %slot27, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  %ld2000 = load i32, ptr %p1999, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2000, ptr %slot133, align 8
  %v2001 = load i32, ptr %slot133, align 8
  %op2002 = and i32 %v2001, 28
  store i32 %op2002, ptr %slot134, align 8
  %v2003 = load i32, ptr %slot134, align 8
  %cv2004 = zext i32 %v2003 to i64
  %cond2005 = icmp ne i64 %cv2004, 0
  br i1 %cond2005, label %bb_rcslotrole121, label %bb_rcslotowner121
bb_rcslotrole121:
  %v2006 = load i64, ptr %slot56, align 8
  store i64 %v2006, ptr %slot135, align 8
  %v2007 = load i64, ptr %slot135, align 8
  %v2008 = load i64, ptr %slot132, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2007, i64 %v2008) nomerge, !dbg !124
  br label %bb_rcslotdone121
bb_rcslotowner121:
  %v2009 = load i64, ptr %slot56, align 8
  store i64 %v2009, ptr %slot136, align 8
  %v2010 = load i64, ptr %slot136, align 8
  %v2011 = load i64, ptr %slot132, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2010, i64 %v2011) nomerge, !dbg !124
  br label %bb_rcslotdone121
bb_rcslotdone121:
  br label %bb_i18
bb_rcarmnext96:
  %v2012 = load i64, ptr %slot116, align 8
  %cmp2013 = icmp eq i64 %v2012, 1
  %cv2014 = zext i1 %cmp2013 to i64
  store i64 %cv2014, ptr %slot137, align 8
  %v2015 = load i64, ptr %slot137, align 8
  %cond2016 = icmp ne i64 %v2015, 0
  br i1 %cond2016, label %bb_rcarm128, label %bb_rcarmnext128
bb_rcarm128:
  %v2017 = load i64, ptr %slot31, align 8
  store i64 %v2017, ptr %slot138, align 8
  %v2018 = load i64, ptr %slot115, align 8
  %op2019 = add i64 %v2018, 8
  store i64 %op2019, ptr %slot139, align 8
  %v2020 = load i64, ptr %slot57, align 8
  store i64 %v2020, ptr %slot140, align 8
  %v2021 = load i64, ptr %slot56, align 8
  %v2022 = load i64, ptr %slot138, align 8
  %v2023 = load i64, ptr %slot139, align 8
  %v2024 = load i64, ptr %slot140, align 8
  %cv2025 = trunc i64 %v2024 to i32
  %call2026 = call i32 @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_retain(i64 %v2021, i64 %v2022, i64 %v2023, i32 %cv2025) nomerge, !dbg !124
  store i32 %call2026, ptr %slot141, align 8
  %v2027 = load i32, ptr %slot141, align 8
  %cv2028 = zext i32 %v2027 to i64
  %cond2029 = icmp ne i64 %cv2028, 0
  br i1 %cond2029, label %bb_rcsuccess133, label %bb_rcfailure133
bb_rcfailure133:
  %v2030 = load i64, ptr %slot56, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  %call2032 = call i32 @myl_rc_take_failure(ptr %p2031) nomerge, !dbg !124
  store i32 %call2032, ptr %slot142, align 8
  %v2033 = load i64, ptr %slot1, align 8
  %p2034 = inttoptr i64 %v2033 to ptr
  %v2035 = load i32, ptr %slot142, align 8
  %call2036 = call i32 @myl_qbe_rc_status(ptr %p2034, i32 %v2035) nomerge, !dbg !124
  store i32 %call2036, ptr %slot143, align 8
  br label %bb_failure
bb_rcsuccess133:
  %v2037 = load i64, ptr %slot29, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  store i32 2, ptr %p2038, align 4, !alias.scope !3, !noalias !4
  %v2039 = load i64, ptr %slot28, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  store i32 1, ptr %p2040, align 4, !alias.scope !3, !noalias !4
  %v2041 = load i64, ptr %slot8, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  %ld2043 = load i32, ptr %p2042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2043, ptr %slot144, align 8
  %v2044 = load i32, ptr %slot144, align 8
  %cv2045 = zext i32 %v2044 to i64
  %cond2046 = icmp ne i64 %cv2045, 0
  br i1 %cond2046, label %bb_rcslotdrop140, label %bb_rcslotdone140
bb_rcslotdrop140:
  %v2047 = load i64, ptr %slot8, align 8
  %p2048 = inttoptr i64 %v2047 to ptr
  store i32 0, ptr %p2048, align 4, !alias.scope !3, !noalias !4
  %v2049 = load i64, ptr %slot37, align 8
  store i64 %v2049, ptr %slot145, align 8
  %v2050 = load i64, ptr %slot9, align 8
  %p2051 = inttoptr i64 %v2050 to ptr
  %ld2052 = load i32, ptr %p2051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2052, ptr %slot146, align 8
  %v2053 = load i32, ptr %slot146, align 8
  %op2054 = and i32 %v2053, 28
  store i32 %op2054, ptr %slot147, align 8
  %v2055 = load i32, ptr %slot147, align 8
  %cv2056 = zext i32 %v2055 to i64
  %cond2057 = icmp ne i64 %cv2056, 0
  br i1 %cond2057, label %bb_rcslotrole140, label %bb_rcslotowner140
bb_rcslotrole140:
  %v2058 = load i64, ptr %slot56, align 8
  store i64 %v2058, ptr %slot148, align 8
  %v2059 = load i64, ptr %slot148, align 8
  %v2060 = load i64, ptr %slot145, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v2059, i64 %v2060) nomerge, !dbg !124
  br label %bb_rcslotdone140
bb_rcslotowner140:
  %v2061 = load i64, ptr %slot56, align 8
  store i64 %v2061, ptr %slot149, align 8
  %v2062 = load i64, ptr %slot149, align 8
  %v2063 = load i64, ptr %slot145, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v2062, i64 %v2063) nomerge, !dbg !124
  br label %bb_rcslotdone140
bb_rcslotdone140:
  %v2064 = load i64, ptr %slot138, align 8
  %v2065 = load i64, ptr %slot37, align 8
  %p2066 = inttoptr i64 %v2064 to ptr
  %p2067 = inttoptr i64 %v2065 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2067, ptr %p2066, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2068 = load i64, ptr %slot28, align 8
  %p2069 = inttoptr i64 %v2068 to ptr
  store i32 0, ptr %p2069, align 4, !alias.scope !3, !noalias !4
  %v2070 = load i64, ptr %slot37, align 8
  store i64 %v2070, ptr %slot150, align 8
  %v2071 = load i64, ptr %slot9, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  store i32 2, ptr %p2072, align 4, !alias.scope !3, !noalias !4
  %v2073 = load i64, ptr %slot8, align 8
  %p2074 = inttoptr i64 %v2073 to ptr
  store i32 1, ptr %p2074, align 4, !alias.scope !3, !noalias !4
  %v2075 = load i64, ptr %slot26, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %ld2077 = load i32, ptr %p2076, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2077, ptr %slot151, align 8
  %v2078 = load i32, ptr %slot151, align 8
  %cv2079 = zext i32 %v2078 to i64
  %cond2080 = icmp ne i64 %cv2079, 0
  br i1 %cond2080, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v2081 = load i64, ptr %slot26, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i32 0, ptr %p2082, align 4, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot30, align 8
  store i64 %v2083, ptr %slot152, align 8
  %v2084 = load i64, ptr %slot27, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  %ld2086 = load i32, ptr %p2085, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2086, ptr %slot153, align 8
  %v2087 = load i32, ptr %slot153, align 8
  %op2088 = and i32 %v2087, 28
  store i32 %op2088, ptr %slot154, align 8
  %v2089 = load i32, ptr %slot154, align 8
  %cv2090 = zext i32 %v2089 to i64
  %cond2091 = icmp ne i64 %cv2090, 0
  br i1 %cond2091, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v2092 = load i64, ptr %slot56, align 8
  store i64 %v2092, ptr %slot155, align 8
  %v2093 = load i64, ptr %slot155, align 8
  %v2094 = load i64, ptr %slot152, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2093, i64 %v2094) nomerge, !dbg !124
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v2095 = load i64, ptr %slot56, align 8
  store i64 %v2095, ptr %slot156, align 8
  %v2096 = load i64, ptr %slot156, align 8
  %v2097 = load i64, ptr %slot152, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2096, i64 %v2097) nomerge, !dbg !124
  br label %bb_rcslotdone153
bb_rcslotdone153:
  br label %bb_i22
bb_rcarmnext128:
  %v2098 = load i64, ptr %slot116, align 8
  %cmp2099 = icmp eq i64 %v2098, 2
  %cv2100 = zext i1 %cmp2099 to i64
  store i64 %cv2100, ptr %slot157, align 8
  %v2101 = load i64, ptr %slot157, align 8
  %cond2102 = icmp ne i64 %v2101, 0
  br i1 %cond2102, label %bb_rcarm160, label %bb_rcarmnext160
bb_rcarm160:
  %v2103 = load i64, ptr %slot26, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  %ld2105 = load i32, ptr %p2104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2105, ptr %slot158, align 8
  %v2106 = load i32, ptr %slot158, align 8
  %cv2107 = zext i32 %v2106 to i64
  %cond2108 = icmp ne i64 %cv2107, 0
  br i1 %cond2108, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v2109 = load i64, ptr %slot26, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  store i32 0, ptr %p2110, align 4, !alias.scope !3, !noalias !4
  %v2111 = load i64, ptr %slot30, align 8
  store i64 %v2111, ptr %slot159, align 8
  %v2112 = load i64, ptr %slot27, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  %ld2114 = load i32, ptr %p2113, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2114, ptr %slot160, align 8
  %v2115 = load i32, ptr %slot160, align 8
  %op2116 = and i32 %v2115, 28
  store i32 %op2116, ptr %slot161, align 8
  %v2117 = load i32, ptr %slot161, align 8
  %cv2118 = zext i32 %v2117 to i64
  %cond2119 = icmp ne i64 %cv2118, 0
  br i1 %cond2119, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v2120 = load i64, ptr %slot56, align 8
  store i64 %v2120, ptr %slot162, align 8
  %v2121 = load i64, ptr %slot162, align 8
  %v2122 = load i64, ptr %slot159, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2121, i64 %v2122) nomerge, !dbg !124
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v2123 = load i64, ptr %slot56, align 8
  store i64 %v2123, ptr %slot163, align 8
  %v2124 = load i64, ptr %slot163, align 8
  %v2125 = load i64, ptr %slot159, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2124, i64 %v2125) nomerge, !dbg !124
  br label %bb_rcslotdone163
bb_rcslotdone163:
  br label %bb_i26
bb_rcarmnext160:
  %v2126 = load i64, ptr %slot116, align 8
  %cmp2127 = icmp eq i64 %v2126, 3
  %cv2128 = zext i1 %cmp2127 to i64
  store i64 %cv2128, ptr %slot164, align 8
  %v2129 = load i64, ptr %slot164, align 8
  %cond2130 = icmp ne i64 %v2129, 0
  br i1 %cond2130, label %bb_rcarm170, label %bb_rcarmnext170
bb_rcarm170:
  %v2131 = load i64, ptr %slot31, align 8
  store i64 %v2131, ptr %slot165, align 8
  %v2132 = load i64, ptr %slot115, align 8
  %op2133 = add i64 %v2132, 8
  store i64 %op2133, ptr %slot166, align 8
  %v2134 = load i64, ptr %slot57, align 8
  store i64 %v2134, ptr %slot167, align 8
  %v2135 = load i64, ptr %slot56, align 8
  %v2136 = load i64, ptr %slot165, align 8
  %v2137 = load i64, ptr %slot166, align 8
  %v2138 = load i64, ptr %slot167, align 8
  %cv2139 = trunc i64 %v2138 to i32
  %call2140 = call i32 @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_retain(i64 %v2135, i64 %v2136, i64 %v2137, i32 %cv2139) nomerge, !dbg !124
  store i32 %call2140, ptr %slot168, align 8
  %v2141 = load i32, ptr %slot168, align 8
  %cv2142 = zext i32 %v2141 to i64
  %cond2143 = icmp ne i64 %cv2142, 0
  br i1 %cond2143, label %bb_rcsuccess175, label %bb_rcfailure175
bb_rcfailure175:
  %v2144 = load i64, ptr %slot56, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  %call2146 = call i32 @myl_rc_take_failure(ptr %p2145) nomerge, !dbg !124
  store i32 %call2146, ptr %slot169, align 8
  %v2147 = load i64, ptr %slot1, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  %v2149 = load i32, ptr %slot169, align 8
  %call2150 = call i32 @myl_qbe_rc_status(ptr %p2148, i32 %v2149) nomerge, !dbg !124
  store i32 %call2150, ptr %slot170, align 8
  br label %bb_failure
bb_rcsuccess175:
  %v2151 = load i64, ptr %slot29, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i32 2, ptr %p2152, align 4, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot28, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  store i32 1, ptr %p2154, align 4, !alias.scope !3, !noalias !4
  %v2155 = load i64, ptr %slot10, align 8
  %p2156 = inttoptr i64 %v2155 to ptr
  %ld2157 = load i32, ptr %p2156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2157, ptr %slot171, align 8
  %v2158 = load i32, ptr %slot171, align 8
  %cv2159 = zext i32 %v2158 to i64
  %cond2160 = icmp ne i64 %cv2159, 0
  br i1 %cond2160, label %bb_rcslotdrop182, label %bb_rcslotdone182
bb_rcslotdrop182:
  %v2161 = load i64, ptr %slot10, align 8
  %p2162 = inttoptr i64 %v2161 to ptr
  store i32 0, ptr %p2162, align 4, !alias.scope !3, !noalias !4
  %v2163 = load i64, ptr %slot38, align 8
  store i64 %v2163, ptr %slot172, align 8
  %v2164 = load i64, ptr %slot11, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  %ld2166 = load i32, ptr %p2165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2166, ptr %slot173, align 8
  %v2167 = load i32, ptr %slot173, align 8
  %op2168 = and i32 %v2167, 28
  store i32 %op2168, ptr %slot174, align 8
  %v2169 = load i32, ptr %slot174, align 8
  %cv2170 = zext i32 %v2169 to i64
  %cond2171 = icmp ne i64 %cv2170, 0
  br i1 %cond2171, label %bb_rcslotrole182, label %bb_rcslotowner182
bb_rcslotrole182:
  %v2172 = load i64, ptr %slot56, align 8
  store i64 %v2172, ptr %slot175, align 8
  %v2173 = load i64, ptr %slot175, align 8
  %v2174 = load i64, ptr %slot172, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v2173, i64 %v2174) nomerge, !dbg !124
  br label %bb_rcslotdone182
bb_rcslotowner182:
  %v2175 = load i64, ptr %slot56, align 8
  store i64 %v2175, ptr %slot176, align 8
  %v2176 = load i64, ptr %slot176, align 8
  %v2177 = load i64, ptr %slot172, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v2176, i64 %v2177) nomerge, !dbg !124
  br label %bb_rcslotdone182
bb_rcslotdone182:
  %v2178 = load i64, ptr %slot165, align 8
  %v2179 = load i64, ptr %slot38, align 8
  %p2180 = inttoptr i64 %v2178 to ptr
  %p2181 = inttoptr i64 %v2179 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2181, ptr %p2180, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot28, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i32 0, ptr %p2183, align 4, !alias.scope !3, !noalias !4
  %v2184 = load i64, ptr %slot38, align 8
  store i64 %v2184, ptr %slot177, align 8
  %v2185 = load i64, ptr %slot11, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  store i32 2, ptr %p2186, align 4, !alias.scope !3, !noalias !4
  %v2187 = load i64, ptr %slot10, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  store i32 1, ptr %p2188, align 4, !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot26, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  %ld2191 = load i32, ptr %p2190, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2191, ptr %slot178, align 8
  %v2192 = load i32, ptr %slot178, align 8
  %cv2193 = zext i32 %v2192 to i64
  %cond2194 = icmp ne i64 %cv2193, 0
  br i1 %cond2194, label %bb_rcslotdrop195, label %bb_rcslotdone195
bb_rcslotdrop195:
  %v2195 = load i64, ptr %slot26, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  store i32 0, ptr %p2196, align 4, !alias.scope !3, !noalias !4
  %v2197 = load i64, ptr %slot30, align 8
  store i64 %v2197, ptr %slot179, align 8
  %v2198 = load i64, ptr %slot27, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  %ld2200 = load i32, ptr %p2199, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2200, ptr %slot180, align 8
  %v2201 = load i32, ptr %slot180, align 8
  %op2202 = and i32 %v2201, 28
  store i32 %op2202, ptr %slot181, align 8
  %v2203 = load i32, ptr %slot181, align 8
  %cv2204 = zext i32 %v2203 to i64
  %cond2205 = icmp ne i64 %cv2204, 0
  br i1 %cond2205, label %bb_rcslotrole195, label %bb_rcslotowner195
bb_rcslotrole195:
  %v2206 = load i64, ptr %slot56, align 8
  store i64 %v2206, ptr %slot182, align 8
  %v2207 = load i64, ptr %slot182, align 8
  %v2208 = load i64, ptr %slot179, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2207, i64 %v2208) nomerge, !dbg !124
  br label %bb_rcslotdone195
bb_rcslotowner195:
  %v2209 = load i64, ptr %slot56, align 8
  store i64 %v2209, ptr %slot183, align 8
  %v2210 = load i64, ptr %slot183, align 8
  %v2211 = load i64, ptr %slot179, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2210, i64 %v2211) nomerge, !dbg !124
  br label %bb_rcslotdone195
bb_rcslotdone195:
  br label %bb_i30
bb_rcarmnext170:
  %v2212 = load i64, ptr %slot116, align 8
  %cmp2213 = icmp eq i64 %v2212, 4
  %cv2214 = zext i1 %cmp2213 to i64
  store i64 %cv2214, ptr %slot184, align 8
  %v2215 = load i64, ptr %slot184, align 8
  %cond2216 = icmp ne i64 %v2215, 0
  br i1 %cond2216, label %bb_rcarm202, label %bb_rcarmnext202
bb_rcarm202:
  %v2217 = load i64, ptr %slot31, align 8
  store i64 %v2217, ptr %slot185, align 8
  %v2218 = load i64, ptr %slot115, align 8
  %op2219 = add i64 %v2218, 8
  store i64 %op2219, ptr %slot186, align 8
  %v2220 = load i64, ptr %slot57, align 8
  store i64 %v2220, ptr %slot187, align 8
  %v2221 = load i64, ptr %slot186, align 8
  %v2222 = load i64, ptr %slot185, align 8
  %p2223 = inttoptr i64 %v2221 to ptr
  %p2224 = inttoptr i64 %v2222 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2224, ptr %p2223, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2225 = load i64, ptr %slot29, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  store i32 0, ptr %p2226, align 4, !alias.scope !3, !noalias !4
  %v2227 = load i64, ptr %slot28, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  store i32 1, ptr %p2228, align 4, !alias.scope !3, !noalias !4
  %v2229 = load i64, ptr %slot185, align 8
  %v2230 = load i64, ptr %slot39, align 8
  %p2231 = inttoptr i64 %v2229 to ptr
  %p2232 = inttoptr i64 %v2230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2232, ptr %p2231, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2233 = load i64, ptr %slot28, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  store i32 0, ptr %p2234, align 4, !alias.scope !3, !noalias !4
  %v2235 = load i64, ptr %slot26, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %ld2237 = load i32, ptr %p2236, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2237, ptr %slot188, align 8
  %v2238 = load i32, ptr %slot188, align 8
  %cv2239 = zext i32 %v2238 to i64
  %cond2240 = icmp ne i64 %cv2239, 0
  br i1 %cond2240, label %bb_rcslotdrop211, label %bb_rcslotdone211
bb_rcslotdrop211:
  %v2241 = load i64, ptr %slot26, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  store i32 0, ptr %p2242, align 4, !alias.scope !3, !noalias !4
  %v2243 = load i64, ptr %slot30, align 8
  store i64 %v2243, ptr %slot189, align 8
  %v2244 = load i64, ptr %slot27, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  %ld2246 = load i32, ptr %p2245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2246, ptr %slot190, align 8
  %v2247 = load i32, ptr %slot190, align 8
  %op2248 = and i32 %v2247, 28
  store i32 %op2248, ptr %slot191, align 8
  %v2249 = load i32, ptr %slot191, align 8
  %cv2250 = zext i32 %v2249 to i64
  %cond2251 = icmp ne i64 %cv2250, 0
  br i1 %cond2251, label %bb_rcslotrole211, label %bb_rcslotowner211
bb_rcslotrole211:
  %v2252 = load i64, ptr %slot56, align 8
  store i64 %v2252, ptr %slot192, align 8
  %v2253 = load i64, ptr %slot192, align 8
  %v2254 = load i64, ptr %slot189, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2253, i64 %v2254) nomerge, !dbg !124
  br label %bb_rcslotdone211
bb_rcslotowner211:
  %v2255 = load i64, ptr %slot56, align 8
  store i64 %v2255, ptr %slot193, align 8
  %v2256 = load i64, ptr %slot193, align 8
  %v2257 = load i64, ptr %slot189, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2256, i64 %v2257) nomerge, !dbg !124
  br label %bb_rcslotdone211
bb_rcslotdone211:
  br label %bb_i34
bb_rcarmnext202:
  %v2258 = load i64, ptr %slot116, align 8
  %cmp2259 = icmp eq i64 %v2258, 5
  %cv2260 = zext i1 %cmp2259 to i64
  store i64 %cv2260, ptr %slot194, align 8
  %v2261 = load i64, ptr %slot194, align 8
  %cond2262 = icmp ne i64 %v2261, 0
  br i1 %cond2262, label %bb_rcarm218, label %bb_rcarmnext218
bb_rcarm218:
  %v2263 = load i64, ptr %slot31, align 8
  store i64 %v2263, ptr %slot195, align 8
  %v2264 = load i64, ptr %slot115, align 8
  %op2265 = add i64 %v2264, 8
  store i64 %op2265, ptr %slot196, align 8
  %v2266 = load i64, ptr %slot57, align 8
  store i64 %v2266, ptr %slot197, align 8
  %v2267 = load i64, ptr %slot56, align 8
  %v2268 = load i64, ptr %slot195, align 8
  %v2269 = load i64, ptr %slot196, align 8
  %v2270 = load i64, ptr %slot197, align 8
  %cv2271 = trunc i64 %v2270 to i32
  %call2272 = call i32 @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_retain(i64 %v2267, i64 %v2268, i64 %v2269, i32 %cv2271) nomerge, !dbg !124
  store i32 %call2272, ptr %slot198, align 8
  %v2273 = load i32, ptr %slot198, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcsuccess223, label %bb_rcfailure223
bb_rcfailure223:
  %v2276 = load i64, ptr %slot56, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %call2278 = call i32 @myl_rc_take_failure(ptr %p2277) nomerge, !dbg !124
  store i32 %call2278, ptr %slot199, align 8
  %v2279 = load i64, ptr %slot1, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  %v2281 = load i32, ptr %slot199, align 8
  %call2282 = call i32 @myl_qbe_rc_status(ptr %p2280, i32 %v2281) nomerge, !dbg !124
  store i32 %call2282, ptr %slot200, align 8
  br label %bb_failure
bb_rcsuccess223:
  %v2283 = load i64, ptr %slot29, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  store i32 2, ptr %p2284, align 4, !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot28, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  store i32 1, ptr %p2286, align 4, !alias.scope !3, !noalias !4
  %v2287 = load i64, ptr %slot12, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  %ld2289 = load i32, ptr %p2288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2289, ptr %slot201, align 8
  %v2290 = load i32, ptr %slot201, align 8
  %cv2291 = zext i32 %v2290 to i64
  %cond2292 = icmp ne i64 %cv2291, 0
  br i1 %cond2292, label %bb_rcslotdrop230, label %bb_rcslotdone230
bb_rcslotdrop230:
  %v2293 = load i64, ptr %slot12, align 8
  %p2294 = inttoptr i64 %v2293 to ptr
  store i32 0, ptr %p2294, align 4, !alias.scope !3, !noalias !4
  %v2295 = load i64, ptr %slot40, align 8
  store i64 %v2295, ptr %slot202, align 8
  %v2296 = load i64, ptr %slot13, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  %ld2298 = load i32, ptr %p2297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2298, ptr %slot203, align 8
  %v2299 = load i32, ptr %slot203, align 8
  %op2300 = and i32 %v2299, 28
  store i32 %op2300, ptr %slot204, align 8
  %v2301 = load i32, ptr %slot204, align 8
  %cv2302 = zext i32 %v2301 to i64
  %cond2303 = icmp ne i64 %cv2302, 0
  br i1 %cond2303, label %bb_rcslotrole230, label %bb_rcslotowner230
bb_rcslotrole230:
  %v2304 = load i64, ptr %slot56, align 8
  store i64 %v2304, ptr %slot205, align 8
  %v2305 = load i64, ptr %slot205, align 8
  %v2306 = load i64, ptr %slot202, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v2305, i64 %v2306) nomerge, !dbg !124
  br label %bb_rcslotdone230
bb_rcslotowner230:
  %v2307 = load i64, ptr %slot56, align 8
  store i64 %v2307, ptr %slot206, align 8
  %v2308 = load i64, ptr %slot206, align 8
  %v2309 = load i64, ptr %slot202, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v2308, i64 %v2309) nomerge, !dbg !124
  br label %bb_rcslotdone230
bb_rcslotdone230:
  %v2310 = load i64, ptr %slot195, align 8
  %v2311 = load i64, ptr %slot40, align 8
  %p2312 = inttoptr i64 %v2310 to ptr
  %p2313 = inttoptr i64 %v2311 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2313, ptr %p2312, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2314 = load i64, ptr %slot28, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  store i32 0, ptr %p2315, align 4, !alias.scope !3, !noalias !4
  %v2316 = load i64, ptr %slot40, align 8
  store i64 %v2316, ptr %slot207, align 8
  %v2317 = load i64, ptr %slot13, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  store i32 2, ptr %p2318, align 4, !alias.scope !3, !noalias !4
  %v2319 = load i64, ptr %slot12, align 8
  %p2320 = inttoptr i64 %v2319 to ptr
  store i32 1, ptr %p2320, align 4, !alias.scope !3, !noalias !4
  %v2321 = load i64, ptr %slot26, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  %ld2323 = load i32, ptr %p2322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2323, ptr %slot208, align 8
  %v2324 = load i32, ptr %slot208, align 8
  %cv2325 = zext i32 %v2324 to i64
  %cond2326 = icmp ne i64 %cv2325, 0
  br i1 %cond2326, label %bb_rcslotdrop243, label %bb_rcslotdone243
bb_rcslotdrop243:
  %v2327 = load i64, ptr %slot26, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  store i32 0, ptr %p2328, align 4, !alias.scope !3, !noalias !4
  %v2329 = load i64, ptr %slot30, align 8
  store i64 %v2329, ptr %slot209, align 8
  %v2330 = load i64, ptr %slot27, align 8
  %p2331 = inttoptr i64 %v2330 to ptr
  %ld2332 = load i32, ptr %p2331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2332, ptr %slot210, align 8
  %v2333 = load i32, ptr %slot210, align 8
  %op2334 = and i32 %v2333, 28
  store i32 %op2334, ptr %slot211, align 8
  %v2335 = load i32, ptr %slot211, align 8
  %cv2336 = zext i32 %v2335 to i64
  %cond2337 = icmp ne i64 %cv2336, 0
  br i1 %cond2337, label %bb_rcslotrole243, label %bb_rcslotowner243
bb_rcslotrole243:
  %v2338 = load i64, ptr %slot56, align 8
  store i64 %v2338, ptr %slot212, align 8
  %v2339 = load i64, ptr %slot212, align 8
  %v2340 = load i64, ptr %slot209, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2339, i64 %v2340) nomerge, !dbg !124
  br label %bb_rcslotdone243
bb_rcslotowner243:
  %v2341 = load i64, ptr %slot56, align 8
  store i64 %v2341, ptr %slot213, align 8
  %v2342 = load i64, ptr %slot213, align 8
  %v2343 = load i64, ptr %slot209, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2342, i64 %v2343) nomerge, !dbg !124
  br label %bb_rcslotdone243
bb_rcslotdone243:
  br label %bb_i39
bb_rcarmnext218:
  %v2344 = load i64, ptr %slot116, align 8
  %cmp2345 = icmp eq i64 %v2344, 6
  %cv2346 = zext i1 %cmp2345 to i64
  store i64 %cv2346, ptr %slot214, align 8
  %v2347 = load i64, ptr %slot214, align 8
  %cond2348 = icmp ne i64 %v2347, 0
  br i1 %cond2348, label %bb_rcarm250, label %bb_rcarmnext250
bb_rcarm250:
  %v2349 = load i64, ptr %slot31, align 8
  store i64 %v2349, ptr %slot215, align 8
  %v2350 = load i64, ptr %slot115, align 8
  %op2351 = add i64 %v2350, 8
  store i64 %op2351, ptr %slot216, align 8
  %v2352 = load i64, ptr %slot57, align 8
  store i64 %v2352, ptr %slot217, align 8
  %v2353 = load i64, ptr %slot56, align 8
  %v2354 = load i64, ptr %slot215, align 8
  %v2355 = load i64, ptr %slot216, align 8
  %v2356 = load i64, ptr %slot217, align 8
  %cv2357 = trunc i64 %v2356 to i32
  %call2358 = call i32 @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_retain(i64 %v2353, i64 %v2354, i64 %v2355, i32 %cv2357) nomerge, !dbg !124
  store i32 %call2358, ptr %slot218, align 8
  %v2359 = load i32, ptr %slot218, align 8
  %cv2360 = zext i32 %v2359 to i64
  %cond2361 = icmp ne i64 %cv2360, 0
  br i1 %cond2361, label %bb_rcsuccess255, label %bb_rcfailure255
bb_rcfailure255:
  %v2362 = load i64, ptr %slot56, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  %call2364 = call i32 @myl_rc_take_failure(ptr %p2363) nomerge, !dbg !124
  store i32 %call2364, ptr %slot219, align 8
  %v2365 = load i64, ptr %slot1, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %v2367 = load i32, ptr %slot219, align 8
  %call2368 = call i32 @myl_qbe_rc_status(ptr %p2366, i32 %v2367) nomerge, !dbg !124
  store i32 %call2368, ptr %slot220, align 8
  br label %bb_failure
bb_rcsuccess255:
  %v2369 = load i64, ptr %slot29, align 8
  %p2370 = inttoptr i64 %v2369 to ptr
  store i32 2, ptr %p2370, align 4, !alias.scope !3, !noalias !4
  %v2371 = load i64, ptr %slot28, align 8
  %p2372 = inttoptr i64 %v2371 to ptr
  store i32 1, ptr %p2372, align 4, !alias.scope !3, !noalias !4
  %v2373 = load i64, ptr %slot14, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  %ld2375 = load i32, ptr %p2374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2375, ptr %slot221, align 8
  %v2376 = load i32, ptr %slot221, align 8
  %cv2377 = zext i32 %v2376 to i64
  %cond2378 = icmp ne i64 %cv2377, 0
  br i1 %cond2378, label %bb_rcslotdrop262, label %bb_rcslotdone262
bb_rcslotdrop262:
  %v2379 = load i64, ptr %slot14, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  store i32 0, ptr %p2380, align 4, !alias.scope !3, !noalias !4
  %v2381 = load i64, ptr %slot41, align 8
  store i64 %v2381, ptr %slot222, align 8
  %v2382 = load i64, ptr %slot15, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  %ld2384 = load i32, ptr %p2383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2384, ptr %slot223, align 8
  %v2385 = load i32, ptr %slot223, align 8
  %op2386 = and i32 %v2385, 28
  store i32 %op2386, ptr %slot224, align 8
  %v2387 = load i32, ptr %slot224, align 8
  %cv2388 = zext i32 %v2387 to i64
  %cond2389 = icmp ne i64 %cv2388, 0
  br i1 %cond2389, label %bb_rcslotrole262, label %bb_rcslotowner262
bb_rcslotrole262:
  %v2390 = load i64, ptr %slot56, align 8
  store i64 %v2390, ptr %slot225, align 8
  %v2391 = load i64, ptr %slot225, align 8
  %v2392 = load i64, ptr %slot222, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v2391, i64 %v2392) nomerge, !dbg !124
  br label %bb_rcslotdone262
bb_rcslotowner262:
  %v2393 = load i64, ptr %slot56, align 8
  store i64 %v2393, ptr %slot226, align 8
  %v2394 = load i64, ptr %slot226, align 8
  %v2395 = load i64, ptr %slot222, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v2394, i64 %v2395) nomerge, !dbg !124
  br label %bb_rcslotdone262
bb_rcslotdone262:
  %v2396 = load i64, ptr %slot215, align 8
  %v2397 = load i64, ptr %slot41, align 8
  %p2398 = inttoptr i64 %v2396 to ptr
  %p2399 = inttoptr i64 %v2397 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2399, ptr %p2398, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot28, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  store i32 0, ptr %p2401, align 4, !alias.scope !3, !noalias !4
  %v2402 = load i64, ptr %slot41, align 8
  store i64 %v2402, ptr %slot227, align 8
  %v2403 = load i64, ptr %slot15, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  store i32 2, ptr %p2404, align 4, !alias.scope !3, !noalias !4
  %v2405 = load i64, ptr %slot14, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  store i32 1, ptr %p2406, align 4, !alias.scope !3, !noalias !4
  %v2407 = load i64, ptr %slot26, align 8
  %p2408 = inttoptr i64 %v2407 to ptr
  %ld2409 = load i32, ptr %p2408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2409, ptr %slot228, align 8
  %v2410 = load i32, ptr %slot228, align 8
  %cv2411 = zext i32 %v2410 to i64
  %cond2412 = icmp ne i64 %cv2411, 0
  br i1 %cond2412, label %bb_rcslotdrop275, label %bb_rcslotdone275
bb_rcslotdrop275:
  %v2413 = load i64, ptr %slot26, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  store i32 0, ptr %p2414, align 4, !alias.scope !3, !noalias !4
  %v2415 = load i64, ptr %slot30, align 8
  store i64 %v2415, ptr %slot229, align 8
  %v2416 = load i64, ptr %slot27, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  %ld2418 = load i32, ptr %p2417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2418, ptr %slot230, align 8
  %v2419 = load i32, ptr %slot230, align 8
  %op2420 = and i32 %v2419, 28
  store i32 %op2420, ptr %slot231, align 8
  %v2421 = load i32, ptr %slot231, align 8
  %cv2422 = zext i32 %v2421 to i64
  %cond2423 = icmp ne i64 %cv2422, 0
  br i1 %cond2423, label %bb_rcslotrole275, label %bb_rcslotowner275
bb_rcslotrole275:
  %v2424 = load i64, ptr %slot56, align 8
  store i64 %v2424, ptr %slot232, align 8
  %v2425 = load i64, ptr %slot232, align 8
  %v2426 = load i64, ptr %slot229, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2425, i64 %v2426) nomerge, !dbg !124
  br label %bb_rcslotdone275
bb_rcslotowner275:
  %v2427 = load i64, ptr %slot56, align 8
  store i64 %v2427, ptr %slot233, align 8
  %v2428 = load i64, ptr %slot233, align 8
  %v2429 = load i64, ptr %slot229, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2428, i64 %v2429) nomerge, !dbg !124
  br label %bb_rcslotdone275
bb_rcslotdone275:
  br label %bb_i43
bb_rcarmnext250:
  %v2430 = load i64, ptr %slot116, align 8
  %cmp2431 = icmp eq i64 %v2430, 7
  %cv2432 = zext i1 %cmp2431 to i64
  store i64 %cv2432, ptr %slot234, align 8
  %v2433 = load i64, ptr %slot234, align 8
  %cond2434 = icmp ne i64 %v2433, 0
  br i1 %cond2434, label %bb_rcarm282, label %bb_rcarmnext282
bb_rcarm282:
  %v2435 = load i64, ptr %slot31, align 8
  store i64 %v2435, ptr %slot235, align 8
  %v2436 = load i64, ptr %slot115, align 8
  %op2437 = add i64 %v2436, 8
  store i64 %op2437, ptr %slot236, align 8
  %v2438 = load i64, ptr %slot57, align 8
  store i64 %v2438, ptr %slot237, align 8
  %v2439 = load i64, ptr %slot56, align 8
  %v2440 = load i64, ptr %slot235, align 8
  %v2441 = load i64, ptr %slot236, align 8
  %v2442 = load i64, ptr %slot237, align 8
  %cv2443 = trunc i64 %v2442 to i32
  %call2444 = call i32 @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_retain(i64 %v2439, i64 %v2440, i64 %v2441, i32 %cv2443) nomerge, !dbg !124
  store i32 %call2444, ptr %slot238, align 8
  %v2445 = load i32, ptr %slot238, align 8
  %cv2446 = zext i32 %v2445 to i64
  %cond2447 = icmp ne i64 %cv2446, 0
  br i1 %cond2447, label %bb_rcsuccess287, label %bb_rcfailure287
bb_rcfailure287:
  %v2448 = load i64, ptr %slot56, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  %call2450 = call i32 @myl_rc_take_failure(ptr %p2449) nomerge, !dbg !124
  store i32 %call2450, ptr %slot239, align 8
  %v2451 = load i64, ptr %slot1, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  %v2453 = load i32, ptr %slot239, align 8
  %call2454 = call i32 @myl_qbe_rc_status(ptr %p2452, i32 %v2453) nomerge, !dbg !124
  store i32 %call2454, ptr %slot240, align 8
  br label %bb_failure
bb_rcsuccess287:
  %v2455 = load i64, ptr %slot29, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  store i32 2, ptr %p2456, align 4, !alias.scope !3, !noalias !4
  %v2457 = load i64, ptr %slot28, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  store i32 1, ptr %p2458, align 4, !alias.scope !3, !noalias !4
  %v2459 = load i64, ptr %slot16, align 8
  %p2460 = inttoptr i64 %v2459 to ptr
  %ld2461 = load i32, ptr %p2460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2461, ptr %slot241, align 8
  %v2462 = load i32, ptr %slot241, align 8
  %cv2463 = zext i32 %v2462 to i64
  %cond2464 = icmp ne i64 %cv2463, 0
  br i1 %cond2464, label %bb_rcslotdrop294, label %bb_rcslotdone294
bb_rcslotdrop294:
  %v2465 = load i64, ptr %slot16, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  store i32 0, ptr %p2466, align 4, !alias.scope !3, !noalias !4
  %v2467 = load i64, ptr %slot42, align 8
  store i64 %v2467, ptr %slot242, align 8
  %v2468 = load i64, ptr %slot17, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  %ld2470 = load i32, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2470, ptr %slot243, align 8
  %v2471 = load i32, ptr %slot243, align 8
  %op2472 = and i32 %v2471, 28
  store i32 %op2472, ptr %slot244, align 8
  %v2473 = load i32, ptr %slot244, align 8
  %cv2474 = zext i32 %v2473 to i64
  %cond2475 = icmp ne i64 %cv2474, 0
  br i1 %cond2475, label %bb_rcslotrole294, label %bb_rcslotowner294
bb_rcslotrole294:
  %v2476 = load i64, ptr %slot56, align 8
  store i64 %v2476, ptr %slot245, align 8
  %v2477 = load i64, ptr %slot245, align 8
  %v2478 = load i64, ptr %slot242, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v2477, i64 %v2478) nomerge, !dbg !124
  br label %bb_rcslotdone294
bb_rcslotowner294:
  %v2479 = load i64, ptr %slot56, align 8
  store i64 %v2479, ptr %slot246, align 8
  %v2480 = load i64, ptr %slot246, align 8
  %v2481 = load i64, ptr %slot242, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v2480, i64 %v2481) nomerge, !dbg !124
  br label %bb_rcslotdone294
bb_rcslotdone294:
  %v2482 = load i64, ptr %slot235, align 8
  %v2483 = load i64, ptr %slot42, align 8
  %p2484 = inttoptr i64 %v2482 to ptr
  %p2485 = inttoptr i64 %v2483 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2485, ptr %p2484, i64 64, i1 false), !alias.scope !3, !noalias !4
  %v2486 = load i64, ptr %slot28, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  store i32 0, ptr %p2487, align 4, !alias.scope !3, !noalias !4
  %v2488 = load i64, ptr %slot42, align 8
  store i64 %v2488, ptr %slot247, align 8
  %v2489 = load i64, ptr %slot17, align 8
  %p2490 = inttoptr i64 %v2489 to ptr
  store i32 2, ptr %p2490, align 4, !alias.scope !3, !noalias !4
  %v2491 = load i64, ptr %slot16, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  store i32 1, ptr %p2492, align 4, !alias.scope !3, !noalias !4
  %v2493 = load i64, ptr %slot26, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  %ld2495 = load i32, ptr %p2494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2495, ptr %slot248, align 8
  %v2496 = load i32, ptr %slot248, align 8
  %cv2497 = zext i32 %v2496 to i64
  %cond2498 = icmp ne i64 %cv2497, 0
  br i1 %cond2498, label %bb_rcslotdrop307, label %bb_rcslotdone307
bb_rcslotdrop307:
  %v2499 = load i64, ptr %slot26, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  store i32 0, ptr %p2500, align 4, !alias.scope !3, !noalias !4
  %v2501 = load i64, ptr %slot30, align 8
  store i64 %v2501, ptr %slot249, align 8
  %v2502 = load i64, ptr %slot27, align 8
  %p2503 = inttoptr i64 %v2502 to ptr
  %ld2504 = load i32, ptr %p2503, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2504, ptr %slot250, align 8
  %v2505 = load i32, ptr %slot250, align 8
  %op2506 = and i32 %v2505, 28
  store i32 %op2506, ptr %slot251, align 8
  %v2507 = load i32, ptr %slot251, align 8
  %cv2508 = zext i32 %v2507 to i64
  %cond2509 = icmp ne i64 %cv2508, 0
  br i1 %cond2509, label %bb_rcslotrole307, label %bb_rcslotowner307
bb_rcslotrole307:
  %v2510 = load i64, ptr %slot56, align 8
  store i64 %v2510, ptr %slot252, align 8
  %v2511 = load i64, ptr %slot252, align 8
  %v2512 = load i64, ptr %slot249, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2511, i64 %v2512) nomerge, !dbg !124
  br label %bb_rcslotdone307
bb_rcslotowner307:
  %v2513 = load i64, ptr %slot56, align 8
  store i64 %v2513, ptr %slot253, align 8
  %v2514 = load i64, ptr %slot253, align 8
  %v2515 = load i64, ptr %slot249, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2514, i64 %v2515) nomerge, !dbg !124
  br label %bb_rcslotdone307
bb_rcslotdone307:
  br label %bb_i47
bb_rcarmnext282:
  %v2516 = load i64, ptr %slot116, align 8
  %cmp2517 = icmp eq i64 %v2516, 8
  %cv2518 = zext i1 %cmp2517 to i64
  store i64 %cv2518, ptr %slot254, align 8
  %v2519 = load i64, ptr %slot254, align 8
  %cond2520 = icmp ne i64 %v2519, 0
  br i1 %cond2520, label %bb_rcarm314, label %bb_rcarmnext314
bb_rcarm314:
  %v2521 = load i64, ptr %slot31, align 8
  store i64 %v2521, ptr %slot255, align 8
  %v2522 = load i64, ptr %slot115, align 8
  %op2523 = add i64 %v2522, 8
  store i64 %op2523, ptr %slot256, align 8
  %v2524 = load i64, ptr %slot57, align 8
  store i64 %v2524, ptr %slot257, align 8
  %v2525 = load i64, ptr %slot56, align 8
  %v2526 = load i64, ptr %slot255, align 8
  %v2527 = load i64, ptr %slot256, align 8
  %v2528 = load i64, ptr %slot257, align 8
  %cv2529 = trunc i64 %v2528 to i32
  %call2530 = call i32 @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_retain(i64 %v2525, i64 %v2526, i64 %v2527, i32 %cv2529) nomerge, !dbg !124
  store i32 %call2530, ptr %slot258, align 8
  %v2531 = load i32, ptr %slot258, align 8
  %cv2532 = zext i32 %v2531 to i64
  %cond2533 = icmp ne i64 %cv2532, 0
  br i1 %cond2533, label %bb_rcsuccess319, label %bb_rcfailure319
bb_rcfailure319:
  %v2534 = load i64, ptr %slot56, align 8
  %p2535 = inttoptr i64 %v2534 to ptr
  %call2536 = call i32 @myl_rc_take_failure(ptr %p2535) nomerge, !dbg !124
  store i32 %call2536, ptr %slot259, align 8
  %v2537 = load i64, ptr %slot1, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  %v2539 = load i32, ptr %slot259, align 8
  %call2540 = call i32 @myl_qbe_rc_status(ptr %p2538, i32 %v2539) nomerge, !dbg !124
  store i32 %call2540, ptr %slot260, align 8
  br label %bb_failure
bb_rcsuccess319:
  %v2541 = load i64, ptr %slot29, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  store i32 2, ptr %p2542, align 4, !alias.scope !3, !noalias !4
  %v2543 = load i64, ptr %slot28, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  store i32 1, ptr %p2544, align 4, !alias.scope !3, !noalias !4
  %v2545 = load i64, ptr %slot18, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  %ld2547 = load i32, ptr %p2546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2547, ptr %slot261, align 8
  %v2548 = load i32, ptr %slot261, align 8
  %cv2549 = zext i32 %v2548 to i64
  %cond2550 = icmp ne i64 %cv2549, 0
  br i1 %cond2550, label %bb_rcslotdrop326, label %bb_rcslotdone326
bb_rcslotdrop326:
  %v2551 = load i64, ptr %slot18, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  store i32 0, ptr %p2552, align 4, !alias.scope !3, !noalias !4
  %v2553 = load i64, ptr %slot43, align 8
  store i64 %v2553, ptr %slot262, align 8
  %v2554 = load i64, ptr %slot19, align 8
  %p2555 = inttoptr i64 %v2554 to ptr
  %ld2556 = load i32, ptr %p2555, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2556, ptr %slot263, align 8
  %v2557 = load i32, ptr %slot263, align 8
  %op2558 = and i32 %v2557, 28
  store i32 %op2558, ptr %slot264, align 8
  %v2559 = load i32, ptr %slot264, align 8
  %cv2560 = zext i32 %v2559 to i64
  %cond2561 = icmp ne i64 %cv2560, 0
  br i1 %cond2561, label %bb_rcslotrole326, label %bb_rcslotowner326
bb_rcslotrole326:
  %v2562 = load i64, ptr %slot56, align 8
  store i64 %v2562, ptr %slot265, align 8
  %v2563 = load i64, ptr %slot265, align 8
  %v2564 = load i64, ptr %slot262, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v2563, i64 %v2564) nomerge, !dbg !124
  br label %bb_rcslotdone326
bb_rcslotowner326:
  %v2565 = load i64, ptr %slot56, align 8
  store i64 %v2565, ptr %slot266, align 8
  %v2566 = load i64, ptr %slot266, align 8
  %v2567 = load i64, ptr %slot262, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v2566, i64 %v2567) nomerge, !dbg !124
  br label %bb_rcslotdone326
bb_rcslotdone326:
  %v2568 = load i64, ptr %slot255, align 8
  %v2569 = load i64, ptr %slot43, align 8
  %p2570 = inttoptr i64 %v2568 to ptr
  %p2571 = inttoptr i64 %v2569 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2571, ptr %p2570, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v2572 = load i64, ptr %slot28, align 8
  %p2573 = inttoptr i64 %v2572 to ptr
  store i32 0, ptr %p2573, align 4, !alias.scope !3, !noalias !4
  %v2574 = load i64, ptr %slot43, align 8
  store i64 %v2574, ptr %slot267, align 8
  %v2575 = load i64, ptr %slot19, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  store i32 2, ptr %p2576, align 4, !alias.scope !3, !noalias !4
  %v2577 = load i64, ptr %slot18, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  store i32 1, ptr %p2578, align 4, !alias.scope !3, !noalias !4
  %v2579 = load i64, ptr %slot26, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  %ld2581 = load i32, ptr %p2580, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2581, ptr %slot268, align 8
  %v2582 = load i32, ptr %slot268, align 8
  %cv2583 = zext i32 %v2582 to i64
  %cond2584 = icmp ne i64 %cv2583, 0
  br i1 %cond2584, label %bb_rcslotdrop339, label %bb_rcslotdone339
bb_rcslotdrop339:
  %v2585 = load i64, ptr %slot26, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  store i32 0, ptr %p2586, align 4, !alias.scope !3, !noalias !4
  %v2587 = load i64, ptr %slot30, align 8
  store i64 %v2587, ptr %slot269, align 8
  %v2588 = load i64, ptr %slot27, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  %ld2590 = load i32, ptr %p2589, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2590, ptr %slot270, align 8
  %v2591 = load i32, ptr %slot270, align 8
  %op2592 = and i32 %v2591, 28
  store i32 %op2592, ptr %slot271, align 8
  %v2593 = load i32, ptr %slot271, align 8
  %cv2594 = zext i32 %v2593 to i64
  %cond2595 = icmp ne i64 %cv2594, 0
  br i1 %cond2595, label %bb_rcslotrole339, label %bb_rcslotowner339
bb_rcslotrole339:
  %v2596 = load i64, ptr %slot56, align 8
  store i64 %v2596, ptr %slot272, align 8
  %v2597 = load i64, ptr %slot272, align 8
  %v2598 = load i64, ptr %slot269, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2597, i64 %v2598) nomerge, !dbg !124
  br label %bb_rcslotdone339
bb_rcslotowner339:
  %v2599 = load i64, ptr %slot56, align 8
  store i64 %v2599, ptr %slot273, align 8
  %v2600 = load i64, ptr %slot273, align 8
  %v2601 = load i64, ptr %slot269, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2600, i64 %v2601) nomerge, !dbg !124
  br label %bb_rcslotdone339
bb_rcslotdone339:
  br label %bb_i51
bb_rcarmnext314:
  %v2602 = load i64, ptr %slot116, align 8
  %cmp2603 = icmp eq i64 %v2602, 9
  %cv2604 = zext i1 %cmp2603 to i64
  store i64 %cv2604, ptr %slot274, align 8
  %v2605 = load i64, ptr %slot274, align 8
  %cond2606 = icmp ne i64 %v2605, 0
  br i1 %cond2606, label %bb_rcarm346, label %bb_rcarmnext346
bb_rcarm346:
  %v2607 = load i64, ptr %slot31, align 8
  store i64 %v2607, ptr %slot275, align 8
  %v2608 = load i64, ptr %slot115, align 8
  %op2609 = add i64 %v2608, 8
  store i64 %op2609, ptr %slot276, align 8
  %v2610 = load i64, ptr %slot57, align 8
  store i64 %v2610, ptr %slot277, align 8
  %v2611 = load i64, ptr %slot56, align 8
  %v2612 = load i64, ptr %slot275, align 8
  %v2613 = load i64, ptr %slot276, align 8
  %v2614 = load i64, ptr %slot277, align 8
  %cv2615 = trunc i64 %v2614 to i32
  %call2616 = call i32 @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_retain(i64 %v2611, i64 %v2612, i64 %v2613, i32 %cv2615) nomerge, !dbg !124
  store i32 %call2616, ptr %slot278, align 8
  %v2617 = load i32, ptr %slot278, align 8
  %cv2618 = zext i32 %v2617 to i64
  %cond2619 = icmp ne i64 %cv2618, 0
  br i1 %cond2619, label %bb_rcsuccess351, label %bb_rcfailure351
bb_rcfailure351:
  %v2620 = load i64, ptr %slot56, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  %call2622 = call i32 @myl_rc_take_failure(ptr %p2621) nomerge, !dbg !124
  store i32 %call2622, ptr %slot279, align 8
  %v2623 = load i64, ptr %slot1, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  %v2625 = load i32, ptr %slot279, align 8
  %call2626 = call i32 @myl_qbe_rc_status(ptr %p2624, i32 %v2625) nomerge, !dbg !124
  store i32 %call2626, ptr %slot280, align 8
  br label %bb_failure
bb_rcsuccess351:
  %v2627 = load i64, ptr %slot29, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  store i32 2, ptr %p2628, align 4, !alias.scope !3, !noalias !4
  %v2629 = load i64, ptr %slot28, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  store i32 1, ptr %p2630, align 4, !alias.scope !3, !noalias !4
  %v2631 = load i64, ptr %slot20, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  %ld2633 = load i32, ptr %p2632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2633, ptr %slot281, align 8
  %v2634 = load i32, ptr %slot281, align 8
  %cv2635 = zext i32 %v2634 to i64
  %cond2636 = icmp ne i64 %cv2635, 0
  br i1 %cond2636, label %bb_rcslotdrop358, label %bb_rcslotdone358
bb_rcslotdrop358:
  %v2637 = load i64, ptr %slot20, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i32 0, ptr %p2638, align 4, !alias.scope !3, !noalias !4
  %v2639 = load i64, ptr %slot44, align 8
  store i64 %v2639, ptr %slot282, align 8
  %v2640 = load i64, ptr %slot21, align 8
  %p2641 = inttoptr i64 %v2640 to ptr
  %ld2642 = load i32, ptr %p2641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2642, ptr %slot283, align 8
  %v2643 = load i32, ptr %slot283, align 8
  %op2644 = and i32 %v2643, 28
  store i32 %op2644, ptr %slot284, align 8
  %v2645 = load i32, ptr %slot284, align 8
  %cv2646 = zext i32 %v2645 to i64
  %cond2647 = icmp ne i64 %cv2646, 0
  br i1 %cond2647, label %bb_rcslotrole358, label %bb_rcslotowner358
bb_rcslotrole358:
  %v2648 = load i64, ptr %slot56, align 8
  store i64 %v2648, ptr %slot285, align 8
  %v2649 = load i64, ptr %slot285, align 8
  %v2650 = load i64, ptr %slot282, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v2649, i64 %v2650) nomerge, !dbg !124
  br label %bb_rcslotdone358
bb_rcslotowner358:
  %v2651 = load i64, ptr %slot56, align 8
  store i64 %v2651, ptr %slot286, align 8
  %v2652 = load i64, ptr %slot286, align 8
  %v2653 = load i64, ptr %slot282, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v2652, i64 %v2653) nomerge, !dbg !124
  br label %bb_rcslotdone358
bb_rcslotdone358:
  %v2654 = load i64, ptr %slot275, align 8
  %v2655 = load i64, ptr %slot44, align 8
  %p2656 = inttoptr i64 %v2654 to ptr
  %p2657 = inttoptr i64 %v2655 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2657, ptr %p2656, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v2658 = load i64, ptr %slot28, align 8
  %p2659 = inttoptr i64 %v2658 to ptr
  store i32 0, ptr %p2659, align 4, !alias.scope !3, !noalias !4
  %v2660 = load i64, ptr %slot44, align 8
  store i64 %v2660, ptr %slot287, align 8
  %v2661 = load i64, ptr %slot21, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  store i32 2, ptr %p2662, align 4, !alias.scope !3, !noalias !4
  %v2663 = load i64, ptr %slot20, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  store i32 1, ptr %p2664, align 4, !alias.scope !3, !noalias !4
  %v2665 = load i64, ptr %slot26, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  %ld2667 = load i32, ptr %p2666, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2667, ptr %slot288, align 8
  %v2668 = load i32, ptr %slot288, align 8
  %cv2669 = zext i32 %v2668 to i64
  %cond2670 = icmp ne i64 %cv2669, 0
  br i1 %cond2670, label %bb_rcslotdrop371, label %bb_rcslotdone371
bb_rcslotdrop371:
  %v2671 = load i64, ptr %slot26, align 8
  %p2672 = inttoptr i64 %v2671 to ptr
  store i32 0, ptr %p2672, align 4, !alias.scope !3, !noalias !4
  %v2673 = load i64, ptr %slot30, align 8
  store i64 %v2673, ptr %slot289, align 8
  %v2674 = load i64, ptr %slot27, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  %ld2676 = load i32, ptr %p2675, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2676, ptr %slot290, align 8
  %v2677 = load i32, ptr %slot290, align 8
  %op2678 = and i32 %v2677, 28
  store i32 %op2678, ptr %slot291, align 8
  %v2679 = load i32, ptr %slot291, align 8
  %cv2680 = zext i32 %v2679 to i64
  %cond2681 = icmp ne i64 %cv2680, 0
  br i1 %cond2681, label %bb_rcslotrole371, label %bb_rcslotowner371
bb_rcslotrole371:
  %v2682 = load i64, ptr %slot56, align 8
  store i64 %v2682, ptr %slot292, align 8
  %v2683 = load i64, ptr %slot292, align 8
  %v2684 = load i64, ptr %slot289, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2683, i64 %v2684) nomerge, !dbg !124
  br label %bb_rcslotdone371
bb_rcslotowner371:
  %v2685 = load i64, ptr %slot56, align 8
  store i64 %v2685, ptr %slot293, align 8
  %v2686 = load i64, ptr %slot293, align 8
  %v2687 = load i64, ptr %slot289, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2686, i64 %v2687) nomerge, !dbg !124
  br label %bb_rcslotdone371
bb_rcslotdone371:
  br label %bb_i55
bb_rcarmnext346:
  %v2688 = load i64, ptr %slot116, align 8
  %cmp2689 = icmp eq i64 %v2688, 10
  %cv2690 = zext i1 %cmp2689 to i64
  store i64 %cv2690, ptr %slot294, align 8
  %v2691 = load i64, ptr %slot294, align 8
  %cond2692 = icmp ne i64 %v2691, 0
  br i1 %cond2692, label %bb_rcarm378, label %bb_rcarmnext378
bb_rcarm378:
  %v2693 = load i64, ptr %slot31, align 8
  store i64 %v2693, ptr %slot295, align 8
  %v2694 = load i64, ptr %slot115, align 8
  %op2695 = add i64 %v2694, 8
  store i64 %op2695, ptr %slot296, align 8
  %v2696 = load i64, ptr %slot57, align 8
  store i64 %v2696, ptr %slot297, align 8
  %v2697 = load i64, ptr %slot56, align 8
  %v2698 = load i64, ptr %slot295, align 8
  %v2699 = load i64, ptr %slot296, align 8
  %v2700 = load i64, ptr %slot297, align 8
  %cv2701 = trunc i64 %v2700 to i32
  %call2702 = call i32 @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_retain(i64 %v2697, i64 %v2698, i64 %v2699, i32 %cv2701) nomerge, !dbg !124
  store i32 %call2702, ptr %slot298, align 8
  %v2703 = load i32, ptr %slot298, align 8
  %cv2704 = zext i32 %v2703 to i64
  %cond2705 = icmp ne i64 %cv2704, 0
  br i1 %cond2705, label %bb_rcsuccess383, label %bb_rcfailure383
bb_rcfailure383:
  %v2706 = load i64, ptr %slot56, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  %call2708 = call i32 @myl_rc_take_failure(ptr %p2707) nomerge, !dbg !124
  store i32 %call2708, ptr %slot299, align 8
  %v2709 = load i64, ptr %slot1, align 8
  %p2710 = inttoptr i64 %v2709 to ptr
  %v2711 = load i32, ptr %slot299, align 8
  %call2712 = call i32 @myl_qbe_rc_status(ptr %p2710, i32 %v2711) nomerge, !dbg !124
  store i32 %call2712, ptr %slot300, align 8
  br label %bb_failure
bb_rcsuccess383:
  %v2713 = load i64, ptr %slot29, align 8
  %p2714 = inttoptr i64 %v2713 to ptr
  store i32 2, ptr %p2714, align 4, !alias.scope !3, !noalias !4
  %v2715 = load i64, ptr %slot28, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  store i32 1, ptr %p2716, align 4, !alias.scope !3, !noalias !4
  %v2717 = load i64, ptr %slot22, align 8
  %p2718 = inttoptr i64 %v2717 to ptr
  %ld2719 = load i32, ptr %p2718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2719, ptr %slot301, align 8
  %v2720 = load i32, ptr %slot301, align 8
  %cv2721 = zext i32 %v2720 to i64
  %cond2722 = icmp ne i64 %cv2721, 0
  br i1 %cond2722, label %bb_rcslotdrop390, label %bb_rcslotdone390
bb_rcslotdrop390:
  %v2723 = load i64, ptr %slot22, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  store i32 0, ptr %p2724, align 4, !alias.scope !3, !noalias !4
  %v2725 = load i64, ptr %slot45, align 8
  store i64 %v2725, ptr %slot302, align 8
  %v2726 = load i64, ptr %slot23, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  %ld2728 = load i32, ptr %p2727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2728, ptr %slot303, align 8
  %v2729 = load i32, ptr %slot303, align 8
  %op2730 = and i32 %v2729, 28
  store i32 %op2730, ptr %slot304, align 8
  %v2731 = load i32, ptr %slot304, align 8
  %cv2732 = zext i32 %v2731 to i64
  %cond2733 = icmp ne i64 %cv2732, 0
  br i1 %cond2733, label %bb_rcslotrole390, label %bb_rcslotowner390
bb_rcslotrole390:
  %v2734 = load i64, ptr %slot56, align 8
  store i64 %v2734, ptr %slot305, align 8
  %v2735 = load i64, ptr %slot305, align 8
  %v2736 = load i64, ptr %slot302, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v2735, i64 %v2736) nomerge, !dbg !124
  br label %bb_rcslotdone390
bb_rcslotowner390:
  %v2737 = load i64, ptr %slot56, align 8
  store i64 %v2737, ptr %slot306, align 8
  %v2738 = load i64, ptr %slot306, align 8
  %v2739 = load i64, ptr %slot302, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v2738, i64 %v2739) nomerge, !dbg !124
  br label %bb_rcslotdone390
bb_rcslotdone390:
  %v2740 = load i64, ptr %slot295, align 8
  %v2741 = load i64, ptr %slot45, align 8
  %p2742 = inttoptr i64 %v2740 to ptr
  %p2743 = inttoptr i64 %v2741 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2743, ptr %p2742, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v2744 = load i64, ptr %slot28, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  store i32 0, ptr %p2745, align 4, !alias.scope !3, !noalias !4
  %v2746 = load i64, ptr %slot45, align 8
  store i64 %v2746, ptr %slot307, align 8
  %v2747 = load i64, ptr %slot23, align 8
  %p2748 = inttoptr i64 %v2747 to ptr
  store i32 2, ptr %p2748, align 4, !alias.scope !3, !noalias !4
  %v2749 = load i64, ptr %slot22, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  store i32 1, ptr %p2750, align 4, !alias.scope !3, !noalias !4
  %v2751 = load i64, ptr %slot26, align 8
  %p2752 = inttoptr i64 %v2751 to ptr
  %ld2753 = load i32, ptr %p2752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2753, ptr %slot308, align 8
  %v2754 = load i32, ptr %slot308, align 8
  %cv2755 = zext i32 %v2754 to i64
  %cond2756 = icmp ne i64 %cv2755, 0
  br i1 %cond2756, label %bb_rcslotdrop403, label %bb_rcslotdone403
bb_rcslotdrop403:
  %v2757 = load i64, ptr %slot26, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  store i32 0, ptr %p2758, align 4, !alias.scope !3, !noalias !4
  %v2759 = load i64, ptr %slot30, align 8
  store i64 %v2759, ptr %slot309, align 8
  %v2760 = load i64, ptr %slot27, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  %ld2762 = load i32, ptr %p2761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2762, ptr %slot310, align 8
  %v2763 = load i32, ptr %slot310, align 8
  %op2764 = and i32 %v2763, 28
  store i32 %op2764, ptr %slot311, align 8
  %v2765 = load i32, ptr %slot311, align 8
  %cv2766 = zext i32 %v2765 to i64
  %cond2767 = icmp ne i64 %cv2766, 0
  br i1 %cond2767, label %bb_rcslotrole403, label %bb_rcslotowner403
bb_rcslotrole403:
  %v2768 = load i64, ptr %slot56, align 8
  store i64 %v2768, ptr %slot312, align 8
  %v2769 = load i64, ptr %slot312, align 8
  %v2770 = load i64, ptr %slot309, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2769, i64 %v2770) nomerge, !dbg !124
  br label %bb_rcslotdone403
bb_rcslotowner403:
  %v2771 = load i64, ptr %slot56, align 8
  store i64 %v2771, ptr %slot313, align 8
  %v2772 = load i64, ptr %slot313, align 8
  %v2773 = load i64, ptr %slot309, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2772, i64 %v2773) nomerge, !dbg !124
  br label %bb_rcslotdone403
bb_rcslotdone403:
  br label %bb_i59
bb_rcarmnext378:
  %v2774 = load i64, ptr %slot116, align 8
  %cmp2775 = icmp eq i64 %v2774, 11
  %cv2776 = zext i1 %cmp2775 to i64
  store i64 %cv2776, ptr %slot314, align 8
  %v2777 = load i64, ptr %slot314, align 8
  %cond2778 = icmp ne i64 %v2777, 0
  br i1 %cond2778, label %bb_rcarm410, label %bb_rcarmnext410
bb_rcarm410:
  %v2779 = load i64, ptr %slot31, align 8
  store i64 %v2779, ptr %slot315, align 8
  %v2780 = load i64, ptr %slot115, align 8
  %op2781 = add i64 %v2780, 8
  store i64 %op2781, ptr %slot316, align 8
  %v2782 = load i64, ptr %slot57, align 8
  store i64 %v2782, ptr %slot317, align 8
  %v2783 = load i64, ptr %slot56, align 8
  %v2784 = load i64, ptr %slot315, align 8
  %v2785 = load i64, ptr %slot316, align 8
  %v2786 = load i64, ptr %slot317, align 8
  %cv2787 = trunc i64 %v2786 to i32
  %call2788 = call i32 @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_retain(i64 %v2783, i64 %v2784, i64 %v2785, i32 %cv2787) nomerge, !dbg !124
  store i32 %call2788, ptr %slot318, align 8
  %v2789 = load i32, ptr %slot318, align 8
  %cv2790 = zext i32 %v2789 to i64
  %cond2791 = icmp ne i64 %cv2790, 0
  br i1 %cond2791, label %bb_rcsuccess415, label %bb_rcfailure415
bb_rcfailure415:
  %v2792 = load i64, ptr %slot56, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  %call2794 = call i32 @myl_rc_take_failure(ptr %p2793) nomerge, !dbg !124
  store i32 %call2794, ptr %slot319, align 8
  %v2795 = load i64, ptr %slot1, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  %v2797 = load i32, ptr %slot319, align 8
  %call2798 = call i32 @myl_qbe_rc_status(ptr %p2796, i32 %v2797) nomerge, !dbg !124
  store i32 %call2798, ptr %slot320, align 8
  br label %bb_failure
bb_rcsuccess415:
  %v2799 = load i64, ptr %slot29, align 8
  %p2800 = inttoptr i64 %v2799 to ptr
  store i32 2, ptr %p2800, align 4, !alias.scope !3, !noalias !4
  %v2801 = load i64, ptr %slot28, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  store i32 1, ptr %p2802, align 4, !alias.scope !3, !noalias !4
  %v2803 = load i64, ptr %slot24, align 8
  %p2804 = inttoptr i64 %v2803 to ptr
  %ld2805 = load i32, ptr %p2804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2805, ptr %slot321, align 8
  %v2806 = load i32, ptr %slot321, align 8
  %cv2807 = zext i32 %v2806 to i64
  %cond2808 = icmp ne i64 %cv2807, 0
  br i1 %cond2808, label %bb_rcslotdrop422, label %bb_rcslotdone422
bb_rcslotdrop422:
  %v2809 = load i64, ptr %slot24, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  store i32 0, ptr %p2810, align 4, !alias.scope !3, !noalias !4
  %v2811 = load i64, ptr %slot46, align 8
  store i64 %v2811, ptr %slot322, align 8
  %v2812 = load i64, ptr %slot25, align 8
  %p2813 = inttoptr i64 %v2812 to ptr
  %ld2814 = load i32, ptr %p2813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2814, ptr %slot323, align 8
  %v2815 = load i32, ptr %slot323, align 8
  %op2816 = and i32 %v2815, 28
  store i32 %op2816, ptr %slot324, align 8
  %v2817 = load i32, ptr %slot324, align 8
  %cv2818 = zext i32 %v2817 to i64
  %cond2819 = icmp ne i64 %cv2818, 0
  br i1 %cond2819, label %bb_rcslotrole422, label %bb_rcslotowner422
bb_rcslotrole422:
  %v2820 = load i64, ptr %slot56, align 8
  store i64 %v2820, ptr %slot325, align 8
  %v2821 = load i64, ptr %slot325, align 8
  %v2822 = load i64, ptr %slot322, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v2821, i64 %v2822) nomerge, !dbg !124
  br label %bb_rcslotdone422
bb_rcslotowner422:
  %v2823 = load i64, ptr %slot56, align 8
  store i64 %v2823, ptr %slot326, align 8
  %v2824 = load i64, ptr %slot326, align 8
  %v2825 = load i64, ptr %slot322, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v2824, i64 %v2825) nomerge, !dbg !124
  br label %bb_rcslotdone422
bb_rcslotdone422:
  %v2826 = load i64, ptr %slot315, align 8
  %v2827 = load i64, ptr %slot46, align 8
  %p2828 = inttoptr i64 %v2826 to ptr
  %p2829 = inttoptr i64 %v2827 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2829, ptr %p2828, i64 64, i1 false), !alias.scope !3, !noalias !4
  %v2830 = load i64, ptr %slot28, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  store i32 0, ptr %p2831, align 4, !alias.scope !3, !noalias !4
  %v2832 = load i64, ptr %slot46, align 8
  store i64 %v2832, ptr %slot327, align 8
  %v2833 = load i64, ptr %slot25, align 8
  %p2834 = inttoptr i64 %v2833 to ptr
  store i32 2, ptr %p2834, align 4, !alias.scope !3, !noalias !4
  %v2835 = load i64, ptr %slot24, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  store i32 1, ptr %p2836, align 4, !alias.scope !3, !noalias !4
  %v2837 = load i64, ptr %slot26, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  %ld2839 = load i32, ptr %p2838, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2839, ptr %slot328, align 8
  %v2840 = load i32, ptr %slot328, align 8
  %cv2841 = zext i32 %v2840 to i64
  %cond2842 = icmp ne i64 %cv2841, 0
  br i1 %cond2842, label %bb_rcslotdrop435, label %bb_rcslotdone435
bb_rcslotdrop435:
  %v2843 = load i64, ptr %slot26, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  store i32 0, ptr %p2844, align 4, !alias.scope !3, !noalias !4
  %v2845 = load i64, ptr %slot30, align 8
  store i64 %v2845, ptr %slot329, align 8
  %v2846 = load i64, ptr %slot27, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  %ld2848 = load i32, ptr %p2847, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2848, ptr %slot330, align 8
  %v2849 = load i32, ptr %slot330, align 8
  %op2850 = and i32 %v2849, 28
  store i32 %op2850, ptr %slot331, align 8
  %v2851 = load i32, ptr %slot331, align 8
  %cv2852 = zext i32 %v2851 to i64
  %cond2853 = icmp ne i64 %cv2852, 0
  br i1 %cond2853, label %bb_rcslotrole435, label %bb_rcslotowner435
bb_rcslotrole435:
  %v2854 = load i64, ptr %slot56, align 8
  store i64 %v2854, ptr %slot332, align 8
  %v2855 = load i64, ptr %slot332, align 8
  %v2856 = load i64, ptr %slot329, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v2855, i64 %v2856) nomerge, !dbg !124
  br label %bb_rcslotdone435
bb_rcslotowner435:
  %v2857 = load i64, ptr %slot56, align 8
  store i64 %v2857, ptr %slot333, align 8
  %v2858 = load i64, ptr %slot333, align 8
  %v2859 = load i64, ptr %slot329, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v2858, i64 %v2859) nomerge, !dbg !124
  br label %bb_rcslotdone435
bb_rcslotdone435:
  br label %bb_i63
bb_rcarmnext410:
  br label %bb_failure
bb_i18:
  %v2860 = load i64, ptr %slot32, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  %ld2862 = load i64, ptr %p2861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2862, ptr %slot334, align 8
  %v2863 = load i64, ptr %slot334, align 8
  %v2864 = load i64, ptr %slot47, align 8
  %p2865 = inttoptr i64 %v2864 to ptr
  store i64 %v2863, ptr %p2865, align 8, !alias.scope !3, !noalias !4
  %v2866 = load i64, ptr %slot36, align 8
  %v2867 = load i64, ptr %slot48, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  store i64 %v2866, ptr %p2868, align 8, !alias.scope !3, !noalias !4
  %v2869 = load i64, ptr %slot47, align 8
  %p2870 = inttoptr i64 %v2869 to ptr
  %ld2871 = load i64, ptr %p2870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2871, ptr %slot335, align 8
  %v2872 = load i64, ptr %slot48, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  %ld2874 = load i64, ptr %p2873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2874, ptr %slot336, align 8
  %v2875 = load i64, ptr %slot1, align 8
  %v2876 = load i64, ptr %slot335, align 8
  %v2877 = load i64, ptr %slot336, align 8
  call void @myl_f_706a365e4bc67d4dbe31048a4b9bb57e9686317829d7947d70f33e26eb76ce88(ptr sret([24 x i8]) align 8 %callresult338, i64 %v2875, i64 %v2876, i64 %v2877) nomerge, !dbg !126
  %addr2878 = ptrtoint ptr %callresult338 to i64
  store i64 %addr2878, ptr %slot337, align 8
  %v2879 = load i64, ptr %slot337, align 8
  %v2880 = load i64, ptr %slot47, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  store i64 %v2879, ptr %p2881, align 8, !alias.scope !3, !noalias !4
  %v2882 = load i64, ptr %slot47, align 8
  %p2883 = inttoptr i64 %v2882 to ptr
  %ld2884 = load i64, ptr %p2883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2884, ptr %slot339, align 8
  %v2885 = load i64, ptr %slot31, align 8
  store i64 %v2885, ptr %slot340, align 8
  %v2886 = load i64, ptr %slot339, align 8
  %v2887 = load i64, ptr %slot340, align 8
  %p2888 = inttoptr i64 %v2886 to ptr
  %p2889 = inttoptr i64 %v2887 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2889, ptr %p2888, i64 24, i1 false)
  %v2890 = load i64, ptr %slot29, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  store i32 2, ptr %p2891, align 4, !alias.scope !3, !noalias !4
  %v2892 = load i64, ptr %slot28, align 8
  %p2893 = inttoptr i64 %v2892 to ptr
  store i32 1, ptr %p2893, align 4, !alias.scope !3, !noalias !4
  %v2894 = load i64, ptr %slot26, align 8
  %p2895 = inttoptr i64 %v2894 to ptr
  %ld2896 = load i32, ptr %p2895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2896, ptr %slot341, align 8
  %v2897 = load i32, ptr %slot341, align 8
  %cv2898 = zext i32 %v2897 to i64
  %cond2899 = icmp ne i64 %cv2898, 0
  br i1 %cond2899, label %bb_rcslotdrop452, label %bb_rcslotdone452
bb_rcslotdrop452:
  %v2900 = load i64, ptr %slot26, align 8
  %p2901 = inttoptr i64 %v2900 to ptr
  store i32 0, ptr %p2901, align 4, !alias.scope !3, !noalias !4
  %v2902 = load i64, ptr %slot30, align 8
  store i64 %v2902, ptr %slot342, align 8
  %v2903 = load i64, ptr %slot27, align 8
  %p2904 = inttoptr i64 %v2903 to ptr
  %ld2905 = load i32, ptr %p2904, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2905, ptr %slot343, align 8
  %v2906 = load i32, ptr %slot343, align 8
  %op2907 = and i32 %v2906, 28
  store i32 %op2907, ptr %slot344, align 8
  %v2908 = load i32, ptr %slot344, align 8
  %cv2909 = zext i32 %v2908 to i64
  %cond2910 = icmp ne i64 %cv2909, 0
  br i1 %cond2910, label %bb_rcslotrole452, label %bb_rcslotowner452
bb_rcslotrole452:
  %v2911 = load i64, ptr %slot56, align 8
  store i64 %v2911, ptr %slot345, align 8
  %v2912 = load i64, ptr %slot345, align 8
  %v2913 = load i64, ptr %slot342, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2912, i64 %v2913) nomerge, !dbg !126
  br label %bb_rcslotdone452
bb_rcslotowner452:
  %v2914 = load i64, ptr %slot56, align 8
  store i64 %v2914, ptr %slot346, align 8
  %v2915 = load i64, ptr %slot346, align 8
  %v2916 = load i64, ptr %slot342, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2915, i64 %v2916) nomerge, !dbg !126
  br label %bb_rcslotdone452
bb_rcslotdone452:
  %v2917 = load i64, ptr %slot30, align 8
  store i64 %v2917, ptr %slot347, align 8
  %v2918 = load i64, ptr %slot31, align 8
  store i64 %v2918, ptr %slot348, align 8
  %v2919 = load i64, ptr %slot348, align 8
  %v2920 = load i64, ptr %slot347, align 8
  %p2921 = inttoptr i64 %v2919 to ptr
  %p2922 = inttoptr i64 %v2920 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2922, ptr %p2921, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2923 = load i64, ptr %slot27, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  store i32 2, ptr %p2924, align 4, !alias.scope !3, !noalias !4
  %v2925 = load i64, ptr %slot29, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  %ld2927 = load i32, ptr %p2926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2927, ptr %slot349, align 8
  %v2928 = load i32, ptr %slot349, align 8
  %v2929 = load i64, ptr %slot27, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  store i32 %v2928, ptr %p2930, align 4, !alias.scope !3, !noalias !4
  %v2931 = load i64, ptr %slot28, align 8
  %p2932 = inttoptr i64 %v2931 to ptr
  store i32 0, ptr %p2932, align 4, !alias.scope !3, !noalias !4
  %v2933 = load i64, ptr %slot26, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  store i32 1, ptr %p2934, align 4, !alias.scope !3, !noalias !4
  %v2935 = load i64, ptr %slot347, align 8
  %v2936 = load i64, ptr %slot47, align 8
  %p2937 = inttoptr i64 %v2936 to ptr
  store i64 %v2935, ptr %p2937, align 8, !alias.scope !3, !noalias !4
  %v2938 = load i64, ptr %slot47, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  %ld2940 = load i64, ptr %p2939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2940, ptr %slot350, align 8
  %v2941 = load i64, ptr %slot350, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  %ld2943 = load i32, ptr %p2942, align 4, !alias.scope !3, !noalias !4
  %ext2944 = zext i32 %ld2943 to i64
  store i64 %ext2944, ptr %slot351, align 8
  %v2945 = load i64, ptr %slot351, align 8
  %cmp2946 = icmp eq i64 %v2945, 1
  %cv2947 = zext i1 %cmp2946 to i64
  store i64 %cv2947, ptr %slot352, align 8
  %v2948 = load i64, ptr %slot352, align 8
  %cond2949 = icmp ne i64 %v2948, 0
  br i1 %cond2949, label %bb_errtrace478, label %bb_errtraced478
bb_errtrace478:
  %p2950 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2950, i64 8589934613) "call-inline-cost"="0", !dbg !128
  br label %bb_errtraced478
bb_errtraced478:
  %v2951 = load i64, ptr %slot47, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %ld2953 = load i64, ptr %p2952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2953, ptr %slot353, align 8
  %v2954 = load i64, ptr %slot31, align 8
  store i64 %v2954, ptr %slot354, align 8
  %v2955 = load i64, ptr %slot57, align 8
  store i64 %v2955, ptr %slot355, align 8
  %v2956 = load i64, ptr %slot56, align 8
  %v2957 = load i64, ptr %slot354, align 8
  %v2958 = load i64, ptr %slot353, align 8
  %v2959 = load i64, ptr %slot355, align 8
  %cv2960 = trunc i64 %v2959 to i32
  %call2961 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v2956, i64 %v2957, i64 %v2958, i32 %cv2960) nomerge, !dbg !128
  store i32 %call2961, ptr %slot356, align 8
  %v2962 = load i32, ptr %slot356, align 8
  %cv2963 = zext i32 %v2962 to i64
  %cond2964 = icmp ne i64 %cv2963, 0
  br i1 %cond2964, label %bb_rcsuccess483, label %bb_rcfailure483
bb_rcfailure483:
  %v2965 = load i64, ptr %slot56, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  %call2967 = call i32 @myl_rc_take_failure(ptr %p2966) nomerge, !dbg !128
  store i32 %call2967, ptr %slot357, align 8
  %v2968 = load i64, ptr %slot1, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  %v2970 = load i32, ptr %slot357, align 8
  %call2971 = call i32 @myl_qbe_rc_status(ptr %p2969, i32 %v2970) nomerge, !dbg !128
  store i32 %call2971, ptr %slot358, align 8
  br label %bb_failure
bb_rcsuccess483:
  %v2972 = load i64, ptr %slot26, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  store i32 0, ptr %p2973, align 4, !alias.scope !3, !noalias !4
  %v2974 = load i64, ptr %slot29, align 8
  %p2975 = inttoptr i64 %v2974 to ptr
  store i32 2, ptr %p2975, align 4, !alias.scope !3, !noalias !4
  %v2976 = load i64, ptr %slot28, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  store i32 1, ptr %p2977, align 4, !alias.scope !3, !noalias !4
  %v2978 = load i64, ptr %slot31, align 8
  store i64 %v2978, ptr %slot359, align 8
  %v2979 = load i64, ptr %slot28, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  store i32 0, ptr %p2980, align 4, !alias.scope !3, !noalias !4
  %v2981 = load i64, ptr %slot26, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  %ld2983 = load i32, ptr %p2982, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2983, ptr %slot360, align 8
  %v2984 = load i32, ptr %slot360, align 8
  %cv2985 = zext i32 %v2984 to i64
  %cond2986 = icmp ne i64 %cv2985, 0
  br i1 %cond2986, label %bb_rcslotdrop493, label %bb_rcslotdone493
bb_rcslotdrop493:
  %v2987 = load i64, ptr %slot26, align 8
  %p2988 = inttoptr i64 %v2987 to ptr
  store i32 0, ptr %p2988, align 4, !alias.scope !3, !noalias !4
  %v2989 = load i64, ptr %slot30, align 8
  store i64 %v2989, ptr %slot361, align 8
  %v2990 = load i64, ptr %slot27, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  %ld2992 = load i32, ptr %p2991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2992, ptr %slot362, align 8
  %v2993 = load i32, ptr %slot362, align 8
  %op2994 = and i32 %v2993, 28
  store i32 %op2994, ptr %slot363, align 8
  %v2995 = load i32, ptr %slot363, align 8
  %cv2996 = zext i32 %v2995 to i64
  %cond2997 = icmp ne i64 %cv2996, 0
  br i1 %cond2997, label %bb_rcslotrole493, label %bb_rcslotowner493
bb_rcslotrole493:
  %v2998 = load i64, ptr %slot56, align 8
  store i64 %v2998, ptr %slot364, align 8
  %v2999 = load i64, ptr %slot364, align 8
  %v3000 = load i64, ptr %slot361, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2999, i64 %v3000) nomerge, !dbg !128
  br label %bb_rcslotdone493
bb_rcslotowner493:
  %v3001 = load i64, ptr %slot56, align 8
  store i64 %v3001, ptr %slot365, align 8
  %v3002 = load i64, ptr %slot365, align 8
  %v3003 = load i64, ptr %slot361, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3002, i64 %v3003) nomerge, !dbg !128
  br label %bb_rcslotdone493
bb_rcslotdone493:
  %v3004 = load i64, ptr %slot24, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  %ld3006 = load i32, ptr %p3005, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3006, ptr %slot366, align 8
  %v3007 = load i32, ptr %slot366, align 8
  %cv3008 = zext i32 %v3007 to i64
  %cond3009 = icmp ne i64 %cv3008, 0
  br i1 %cond3009, label %bb_rcslotdrop502, label %bb_rcslotdone502
bb_rcslotdrop502:
  %v3010 = load i64, ptr %slot24, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  store i32 0, ptr %p3011, align 4, !alias.scope !3, !noalias !4
  %v3012 = load i64, ptr %slot46, align 8
  store i64 %v3012, ptr %slot367, align 8
  %v3013 = load i64, ptr %slot25, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  %ld3015 = load i32, ptr %p3014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3015, ptr %slot368, align 8
  %v3016 = load i32, ptr %slot368, align 8
  %op3017 = and i32 %v3016, 28
  store i32 %op3017, ptr %slot369, align 8
  %v3018 = load i32, ptr %slot369, align 8
  %cv3019 = zext i32 %v3018 to i64
  %cond3020 = icmp ne i64 %cv3019, 0
  br i1 %cond3020, label %bb_rcslotrole502, label %bb_rcslotowner502
bb_rcslotrole502:
  %v3021 = load i64, ptr %slot56, align 8
  store i64 %v3021, ptr %slot370, align 8
  %v3022 = load i64, ptr %slot370, align 8
  %v3023 = load i64, ptr %slot367, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v3022, i64 %v3023) nomerge, !dbg !128
  br label %bb_rcslotdone502
bb_rcslotowner502:
  %v3024 = load i64, ptr %slot56, align 8
  store i64 %v3024, ptr %slot371, align 8
  %v3025 = load i64, ptr %slot371, align 8
  %v3026 = load i64, ptr %slot367, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v3025, i64 %v3026) nomerge, !dbg !128
  br label %bb_rcslotdone502
bb_rcslotdone502:
  %v3027 = load i64, ptr %slot22, align 8
  %p3028 = inttoptr i64 %v3027 to ptr
  %ld3029 = load i32, ptr %p3028, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3029, ptr %slot372, align 8
  %v3030 = load i32, ptr %slot372, align 8
  %cv3031 = zext i32 %v3030 to i64
  %cond3032 = icmp ne i64 %cv3031, 0
  br i1 %cond3032, label %bb_rcslotdrop511, label %bb_rcslotdone511
bb_rcslotdrop511:
  %v3033 = load i64, ptr %slot22, align 8
  %p3034 = inttoptr i64 %v3033 to ptr
  store i32 0, ptr %p3034, align 4, !alias.scope !3, !noalias !4
  %v3035 = load i64, ptr %slot45, align 8
  store i64 %v3035, ptr %slot373, align 8
  %v3036 = load i64, ptr %slot23, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  %ld3038 = load i32, ptr %p3037, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3038, ptr %slot374, align 8
  %v3039 = load i32, ptr %slot374, align 8
  %op3040 = and i32 %v3039, 28
  store i32 %op3040, ptr %slot375, align 8
  %v3041 = load i32, ptr %slot375, align 8
  %cv3042 = zext i32 %v3041 to i64
  %cond3043 = icmp ne i64 %cv3042, 0
  br i1 %cond3043, label %bb_rcslotrole511, label %bb_rcslotowner511
bb_rcslotrole511:
  %v3044 = load i64, ptr %slot56, align 8
  store i64 %v3044, ptr %slot376, align 8
  %v3045 = load i64, ptr %slot376, align 8
  %v3046 = load i64, ptr %slot373, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v3045, i64 %v3046) nomerge, !dbg !128
  br label %bb_rcslotdone511
bb_rcslotowner511:
  %v3047 = load i64, ptr %slot56, align 8
  store i64 %v3047, ptr %slot377, align 8
  %v3048 = load i64, ptr %slot377, align 8
  %v3049 = load i64, ptr %slot373, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v3048, i64 %v3049) nomerge, !dbg !128
  br label %bb_rcslotdone511
bb_rcslotdone511:
  %v3050 = load i64, ptr %slot20, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %ld3052 = load i32, ptr %p3051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3052, ptr %slot378, align 8
  %v3053 = load i32, ptr %slot378, align 8
  %cv3054 = zext i32 %v3053 to i64
  %cond3055 = icmp ne i64 %cv3054, 0
  br i1 %cond3055, label %bb_rcslotdrop520, label %bb_rcslotdone520
bb_rcslotdrop520:
  %v3056 = load i64, ptr %slot20, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i32 0, ptr %p3057, align 4, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot44, align 8
  store i64 %v3058, ptr %slot379, align 8
  %v3059 = load i64, ptr %slot21, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  %ld3061 = load i32, ptr %p3060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3061, ptr %slot380, align 8
  %v3062 = load i32, ptr %slot380, align 8
  %op3063 = and i32 %v3062, 28
  store i32 %op3063, ptr %slot381, align 8
  %v3064 = load i32, ptr %slot381, align 8
  %cv3065 = zext i32 %v3064 to i64
  %cond3066 = icmp ne i64 %cv3065, 0
  br i1 %cond3066, label %bb_rcslotrole520, label %bb_rcslotowner520
bb_rcslotrole520:
  %v3067 = load i64, ptr %slot56, align 8
  store i64 %v3067, ptr %slot382, align 8
  %v3068 = load i64, ptr %slot382, align 8
  %v3069 = load i64, ptr %slot379, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v3068, i64 %v3069) nomerge, !dbg !128
  br label %bb_rcslotdone520
bb_rcslotowner520:
  %v3070 = load i64, ptr %slot56, align 8
  store i64 %v3070, ptr %slot383, align 8
  %v3071 = load i64, ptr %slot383, align 8
  %v3072 = load i64, ptr %slot379, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v3071, i64 %v3072) nomerge, !dbg !128
  br label %bb_rcslotdone520
bb_rcslotdone520:
  %v3073 = load i64, ptr %slot18, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  %ld3075 = load i32, ptr %p3074, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3075, ptr %slot384, align 8
  %v3076 = load i32, ptr %slot384, align 8
  %cv3077 = zext i32 %v3076 to i64
  %cond3078 = icmp ne i64 %cv3077, 0
  br i1 %cond3078, label %bb_rcslotdrop529, label %bb_rcslotdone529
bb_rcslotdrop529:
  %v3079 = load i64, ptr %slot18, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  store i32 0, ptr %p3080, align 4, !alias.scope !3, !noalias !4
  %v3081 = load i64, ptr %slot43, align 8
  store i64 %v3081, ptr %slot385, align 8
  %v3082 = load i64, ptr %slot19, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  %ld3084 = load i32, ptr %p3083, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3084, ptr %slot386, align 8
  %v3085 = load i32, ptr %slot386, align 8
  %op3086 = and i32 %v3085, 28
  store i32 %op3086, ptr %slot387, align 8
  %v3087 = load i32, ptr %slot387, align 8
  %cv3088 = zext i32 %v3087 to i64
  %cond3089 = icmp ne i64 %cv3088, 0
  br i1 %cond3089, label %bb_rcslotrole529, label %bb_rcslotowner529
bb_rcslotrole529:
  %v3090 = load i64, ptr %slot56, align 8
  store i64 %v3090, ptr %slot388, align 8
  %v3091 = load i64, ptr %slot388, align 8
  %v3092 = load i64, ptr %slot385, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v3091, i64 %v3092) nomerge, !dbg !128
  br label %bb_rcslotdone529
bb_rcslotowner529:
  %v3093 = load i64, ptr %slot56, align 8
  store i64 %v3093, ptr %slot389, align 8
  %v3094 = load i64, ptr %slot389, align 8
  %v3095 = load i64, ptr %slot385, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v3094, i64 %v3095) nomerge, !dbg !128
  br label %bb_rcslotdone529
bb_rcslotdone529:
  %v3096 = load i64, ptr %slot16, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  %ld3098 = load i32, ptr %p3097, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3098, ptr %slot390, align 8
  %v3099 = load i32, ptr %slot390, align 8
  %cv3100 = zext i32 %v3099 to i64
  %cond3101 = icmp ne i64 %cv3100, 0
  br i1 %cond3101, label %bb_rcslotdrop538, label %bb_rcslotdone538
bb_rcslotdrop538:
  %v3102 = load i64, ptr %slot16, align 8
  %p3103 = inttoptr i64 %v3102 to ptr
  store i32 0, ptr %p3103, align 4, !alias.scope !3, !noalias !4
  %v3104 = load i64, ptr %slot42, align 8
  store i64 %v3104, ptr %slot391, align 8
  %v3105 = load i64, ptr %slot17, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  %ld3107 = load i32, ptr %p3106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3107, ptr %slot392, align 8
  %v3108 = load i32, ptr %slot392, align 8
  %op3109 = and i32 %v3108, 28
  store i32 %op3109, ptr %slot393, align 8
  %v3110 = load i32, ptr %slot393, align 8
  %cv3111 = zext i32 %v3110 to i64
  %cond3112 = icmp ne i64 %cv3111, 0
  br i1 %cond3112, label %bb_rcslotrole538, label %bb_rcslotowner538
bb_rcslotrole538:
  %v3113 = load i64, ptr %slot56, align 8
  store i64 %v3113, ptr %slot394, align 8
  %v3114 = load i64, ptr %slot394, align 8
  %v3115 = load i64, ptr %slot391, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v3114, i64 %v3115) nomerge, !dbg !128
  br label %bb_rcslotdone538
bb_rcslotowner538:
  %v3116 = load i64, ptr %slot56, align 8
  store i64 %v3116, ptr %slot395, align 8
  %v3117 = load i64, ptr %slot395, align 8
  %v3118 = load i64, ptr %slot391, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v3117, i64 %v3118) nomerge, !dbg !128
  br label %bb_rcslotdone538
bb_rcslotdone538:
  %v3119 = load i64, ptr %slot14, align 8
  %p3120 = inttoptr i64 %v3119 to ptr
  %ld3121 = load i32, ptr %p3120, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3121, ptr %slot396, align 8
  %v3122 = load i32, ptr %slot396, align 8
  %cv3123 = zext i32 %v3122 to i64
  %cond3124 = icmp ne i64 %cv3123, 0
  br i1 %cond3124, label %bb_rcslotdrop547, label %bb_rcslotdone547
bb_rcslotdrop547:
  %v3125 = load i64, ptr %slot14, align 8
  %p3126 = inttoptr i64 %v3125 to ptr
  store i32 0, ptr %p3126, align 4, !alias.scope !3, !noalias !4
  %v3127 = load i64, ptr %slot41, align 8
  store i64 %v3127, ptr %slot397, align 8
  %v3128 = load i64, ptr %slot15, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  %ld3130 = load i32, ptr %p3129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3130, ptr %slot398, align 8
  %v3131 = load i32, ptr %slot398, align 8
  %op3132 = and i32 %v3131, 28
  store i32 %op3132, ptr %slot399, align 8
  %v3133 = load i32, ptr %slot399, align 8
  %cv3134 = zext i32 %v3133 to i64
  %cond3135 = icmp ne i64 %cv3134, 0
  br i1 %cond3135, label %bb_rcslotrole547, label %bb_rcslotowner547
bb_rcslotrole547:
  %v3136 = load i64, ptr %slot56, align 8
  store i64 %v3136, ptr %slot400, align 8
  %v3137 = load i64, ptr %slot400, align 8
  %v3138 = load i64, ptr %slot397, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v3137, i64 %v3138) nomerge, !dbg !128
  br label %bb_rcslotdone547
bb_rcslotowner547:
  %v3139 = load i64, ptr %slot56, align 8
  store i64 %v3139, ptr %slot401, align 8
  %v3140 = load i64, ptr %slot401, align 8
  %v3141 = load i64, ptr %slot397, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v3140, i64 %v3141) nomerge, !dbg !128
  br label %bb_rcslotdone547
bb_rcslotdone547:
  %v3142 = load i64, ptr %slot12, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %ld3144 = load i32, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3144, ptr %slot402, align 8
  %v3145 = load i32, ptr %slot402, align 8
  %cv3146 = zext i32 %v3145 to i64
  %cond3147 = icmp ne i64 %cv3146, 0
  br i1 %cond3147, label %bb_rcslotdrop556, label %bb_rcslotdone556
bb_rcslotdrop556:
  %v3148 = load i64, ptr %slot12, align 8
  %p3149 = inttoptr i64 %v3148 to ptr
  store i32 0, ptr %p3149, align 4, !alias.scope !3, !noalias !4
  %v3150 = load i64, ptr %slot40, align 8
  store i64 %v3150, ptr %slot403, align 8
  %v3151 = load i64, ptr %slot13, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %ld3153 = load i32, ptr %p3152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3153, ptr %slot404, align 8
  %v3154 = load i32, ptr %slot404, align 8
  %op3155 = and i32 %v3154, 28
  store i32 %op3155, ptr %slot405, align 8
  %v3156 = load i32, ptr %slot405, align 8
  %cv3157 = zext i32 %v3156 to i64
  %cond3158 = icmp ne i64 %cv3157, 0
  br i1 %cond3158, label %bb_rcslotrole556, label %bb_rcslotowner556
bb_rcslotrole556:
  %v3159 = load i64, ptr %slot56, align 8
  store i64 %v3159, ptr %slot406, align 8
  %v3160 = load i64, ptr %slot406, align 8
  %v3161 = load i64, ptr %slot403, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v3160, i64 %v3161) nomerge, !dbg !128
  br label %bb_rcslotdone556
bb_rcslotowner556:
  %v3162 = load i64, ptr %slot56, align 8
  store i64 %v3162, ptr %slot407, align 8
  %v3163 = load i64, ptr %slot407, align 8
  %v3164 = load i64, ptr %slot403, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v3163, i64 %v3164) nomerge, !dbg !128
  br label %bb_rcslotdone556
bb_rcslotdone556:
  %v3165 = load i64, ptr %slot10, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %ld3167 = load i32, ptr %p3166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3167, ptr %slot408, align 8
  %v3168 = load i32, ptr %slot408, align 8
  %cv3169 = zext i32 %v3168 to i64
  %cond3170 = icmp ne i64 %cv3169, 0
  br i1 %cond3170, label %bb_rcslotdrop565, label %bb_rcslotdone565
bb_rcslotdrop565:
  %v3171 = load i64, ptr %slot10, align 8
  %p3172 = inttoptr i64 %v3171 to ptr
  store i32 0, ptr %p3172, align 4, !alias.scope !3, !noalias !4
  %v3173 = load i64, ptr %slot38, align 8
  store i64 %v3173, ptr %slot409, align 8
  %v3174 = load i64, ptr %slot11, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  %ld3176 = load i32, ptr %p3175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3176, ptr %slot410, align 8
  %v3177 = load i32, ptr %slot410, align 8
  %op3178 = and i32 %v3177, 28
  store i32 %op3178, ptr %slot411, align 8
  %v3179 = load i32, ptr %slot411, align 8
  %cv3180 = zext i32 %v3179 to i64
  %cond3181 = icmp ne i64 %cv3180, 0
  br i1 %cond3181, label %bb_rcslotrole565, label %bb_rcslotowner565
bb_rcslotrole565:
  %v3182 = load i64, ptr %slot56, align 8
  store i64 %v3182, ptr %slot412, align 8
  %v3183 = load i64, ptr %slot412, align 8
  %v3184 = load i64, ptr %slot409, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v3183, i64 %v3184) nomerge, !dbg !128
  br label %bb_rcslotdone565
bb_rcslotowner565:
  %v3185 = load i64, ptr %slot56, align 8
  store i64 %v3185, ptr %slot413, align 8
  %v3186 = load i64, ptr %slot413, align 8
  %v3187 = load i64, ptr %slot409, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v3186, i64 %v3187) nomerge, !dbg !128
  br label %bb_rcslotdone565
bb_rcslotdone565:
  %v3188 = load i64, ptr %slot8, align 8
  %p3189 = inttoptr i64 %v3188 to ptr
  %ld3190 = load i32, ptr %p3189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3190, ptr %slot414, align 8
  %v3191 = load i32, ptr %slot414, align 8
  %cv3192 = zext i32 %v3191 to i64
  %cond3193 = icmp ne i64 %cv3192, 0
  br i1 %cond3193, label %bb_rcslotdrop574, label %bb_rcslotdone574
bb_rcslotdrop574:
  %v3194 = load i64, ptr %slot8, align 8
  %p3195 = inttoptr i64 %v3194 to ptr
  store i32 0, ptr %p3195, align 4, !alias.scope !3, !noalias !4
  %v3196 = load i64, ptr %slot37, align 8
  store i64 %v3196, ptr %slot415, align 8
  %v3197 = load i64, ptr %slot9, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  %ld3199 = load i32, ptr %p3198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3199, ptr %slot416, align 8
  %v3200 = load i32, ptr %slot416, align 8
  %op3201 = and i32 %v3200, 28
  store i32 %op3201, ptr %slot417, align 8
  %v3202 = load i32, ptr %slot417, align 8
  %cv3203 = zext i32 %v3202 to i64
  %cond3204 = icmp ne i64 %cv3203, 0
  br i1 %cond3204, label %bb_rcslotrole574, label %bb_rcslotowner574
bb_rcslotrole574:
  %v3205 = load i64, ptr %slot56, align 8
  store i64 %v3205, ptr %slot418, align 8
  %v3206 = load i64, ptr %slot418, align 8
  %v3207 = load i64, ptr %slot415, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v3206, i64 %v3207) nomerge, !dbg !128
  br label %bb_rcslotdone574
bb_rcslotowner574:
  %v3208 = load i64, ptr %slot56, align 8
  store i64 %v3208, ptr %slot419, align 8
  %v3209 = load i64, ptr %slot419, align 8
  %v3210 = load i64, ptr %slot415, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v3209, i64 %v3210) nomerge, !dbg !128
  br label %bb_rcslotdone574
bb_rcslotdone574:
  %v3211 = load i64, ptr %slot6, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %ld3213 = load i32, ptr %p3212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3213, ptr %slot420, align 8
  %v3214 = load i32, ptr %slot420, align 8
  %cv3215 = zext i32 %v3214 to i64
  %cond3216 = icmp ne i64 %cv3215, 0
  br i1 %cond3216, label %bb_rcslotdrop583, label %bb_rcslotdone583
bb_rcslotdrop583:
  %v3217 = load i64, ptr %slot6, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  store i32 0, ptr %p3218, align 4, !alias.scope !3, !noalias !4
  %v3219 = load i64, ptr %slot36, align 8
  store i64 %v3219, ptr %slot421, align 8
  %v3220 = load i64, ptr %slot7, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  %ld3222 = load i32, ptr %p3221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3222, ptr %slot422, align 8
  %v3223 = load i32, ptr %slot422, align 8
  %op3224 = and i32 %v3223, 28
  store i32 %op3224, ptr %slot423, align 8
  %v3225 = load i32, ptr %slot423, align 8
  %cv3226 = zext i32 %v3225 to i64
  %cond3227 = icmp ne i64 %cv3226, 0
  br i1 %cond3227, label %bb_rcslotrole583, label %bb_rcslotowner583
bb_rcslotrole583:
  %v3228 = load i64, ptr %slot56, align 8
  store i64 %v3228, ptr %slot424, align 8
  %v3229 = load i64, ptr %slot424, align 8
  %v3230 = load i64, ptr %slot421, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v3229, i64 %v3230) nomerge, !dbg !128
  br label %bb_rcslotdone583
bb_rcslotowner583:
  %v3231 = load i64, ptr %slot56, align 8
  store i64 %v3231, ptr %slot425, align 8
  %v3232 = load i64, ptr %slot425, align 8
  %v3233 = load i64, ptr %slot421, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v3232, i64 %v3233) nomerge, !dbg !128
  br label %bb_rcslotdone583
bb_rcslotdone583:
  %v3234 = load i64, ptr %slot359, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3235, i64 24, i1 false)
  ret void
bb_i22:
  %v3236 = load i64, ptr %slot32, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  %ld3238 = load i64, ptr %p3237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3238, ptr %slot426, align 8
  %v3239 = load i64, ptr %slot426, align 8
  %v3240 = load i64, ptr %slot47, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  store i64 %v3239, ptr %p3241, align 8, !alias.scope !3, !noalias !4
  %v3242 = load i64, ptr %slot37, align 8
  %v3243 = load i64, ptr %slot48, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  store i64 %v3242, ptr %p3244, align 8, !alias.scope !3, !noalias !4
  %v3245 = load i64, ptr %slot47, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  %ld3247 = load i64, ptr %p3246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3247, ptr %slot427, align 8
  %v3248 = load i64, ptr %slot48, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %ld3250 = load i64, ptr %p3249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3250, ptr %slot428, align 8
  %v3251 = load i64, ptr %slot1, align 8
  %v3252 = load i64, ptr %slot427, align 8
  %v3253 = load i64, ptr %slot428, align 8
  call void @myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44(ptr sret([24 x i8]) align 8 %callresult430, i64 %v3251, i64 %v3252, i64 %v3253) nomerge, !dbg !130
  %addr3254 = ptrtoint ptr %callresult430 to i64
  store i64 %addr3254, ptr %slot429, align 8
  %v3255 = load i64, ptr %slot429, align 8
  %v3256 = load i64, ptr %slot47, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  store i64 %v3255, ptr %p3257, align 8, !alias.scope !3, !noalias !4
  %v3258 = load i64, ptr %slot47, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  %ld3260 = load i64, ptr %p3259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3260, ptr %slot431, align 8
  %v3261 = load i64, ptr %slot31, align 8
  store i64 %v3261, ptr %slot432, align 8
  %v3262 = load i64, ptr %slot431, align 8
  %v3263 = load i64, ptr %slot432, align 8
  %p3264 = inttoptr i64 %v3262 to ptr
  %p3265 = inttoptr i64 %v3263 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3265, ptr %p3264, i64 24, i1 false)
  %v3266 = load i64, ptr %slot29, align 8
  %p3267 = inttoptr i64 %v3266 to ptr
  store i32 2, ptr %p3267, align 4, !alias.scope !3, !noalias !4
  %v3268 = load i64, ptr %slot28, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  store i32 1, ptr %p3269, align 4, !alias.scope !3, !noalias !4
  %v3270 = load i64, ptr %slot26, align 8
  %p3271 = inttoptr i64 %v3270 to ptr
  %ld3272 = load i32, ptr %p3271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3272, ptr %slot433, align 8
  %v3273 = load i32, ptr %slot433, align 8
  %cv3274 = zext i32 %v3273 to i64
  %cond3275 = icmp ne i64 %cv3274, 0
  br i1 %cond3275, label %bb_rcslotdrop646, label %bb_rcslotdone646
bb_rcslotdrop646:
  %v3276 = load i64, ptr %slot26, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  store i32 0, ptr %p3277, align 4, !alias.scope !3, !noalias !4
  %v3278 = load i64, ptr %slot30, align 8
  store i64 %v3278, ptr %slot434, align 8
  %v3279 = load i64, ptr %slot27, align 8
  %p3280 = inttoptr i64 %v3279 to ptr
  %ld3281 = load i32, ptr %p3280, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3281, ptr %slot435, align 8
  %v3282 = load i32, ptr %slot435, align 8
  %op3283 = and i32 %v3282, 28
  store i32 %op3283, ptr %slot436, align 8
  %v3284 = load i32, ptr %slot436, align 8
  %cv3285 = zext i32 %v3284 to i64
  %cond3286 = icmp ne i64 %cv3285, 0
  br i1 %cond3286, label %bb_rcslotrole646, label %bb_rcslotowner646
bb_rcslotrole646:
  %v3287 = load i64, ptr %slot56, align 8
  store i64 %v3287, ptr %slot437, align 8
  %v3288 = load i64, ptr %slot437, align 8
  %v3289 = load i64, ptr %slot434, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3288, i64 %v3289) nomerge, !dbg !130
  br label %bb_rcslotdone646
bb_rcslotowner646:
  %v3290 = load i64, ptr %slot56, align 8
  store i64 %v3290, ptr %slot438, align 8
  %v3291 = load i64, ptr %slot438, align 8
  %v3292 = load i64, ptr %slot434, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3291, i64 %v3292) nomerge, !dbg !130
  br label %bb_rcslotdone646
bb_rcslotdone646:
  %v3293 = load i64, ptr %slot30, align 8
  store i64 %v3293, ptr %slot439, align 8
  %v3294 = load i64, ptr %slot31, align 8
  store i64 %v3294, ptr %slot440, align 8
  %v3295 = load i64, ptr %slot440, align 8
  %v3296 = load i64, ptr %slot439, align 8
  %p3297 = inttoptr i64 %v3295 to ptr
  %p3298 = inttoptr i64 %v3296 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3298, ptr %p3297, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3299 = load i64, ptr %slot27, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  store i32 2, ptr %p3300, align 4, !alias.scope !3, !noalias !4
  %v3301 = load i64, ptr %slot29, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  %ld3303 = load i32, ptr %p3302, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3303, ptr %slot441, align 8
  %v3304 = load i32, ptr %slot441, align 8
  %v3305 = load i64, ptr %slot27, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  store i32 %v3304, ptr %p3306, align 4, !alias.scope !3, !noalias !4
  %v3307 = load i64, ptr %slot28, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  store i32 0, ptr %p3308, align 4, !alias.scope !3, !noalias !4
  %v3309 = load i64, ptr %slot26, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  store i32 1, ptr %p3310, align 4, !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot439, align 8
  %v3312 = load i64, ptr %slot47, align 8
  %p3313 = inttoptr i64 %v3312 to ptr
  store i64 %v3311, ptr %p3313, align 8, !alias.scope !3, !noalias !4
  %v3314 = load i64, ptr %slot47, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  %ld3316 = load i64, ptr %p3315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3316, ptr %slot442, align 8
  %v3317 = load i64, ptr %slot442, align 8
  %p3318 = inttoptr i64 %v3317 to ptr
  %ld3319 = load i32, ptr %p3318, align 4, !alias.scope !3, !noalias !4
  %ext3320 = zext i32 %ld3319 to i64
  store i64 %ext3320, ptr %slot443, align 8
  %v3321 = load i64, ptr %slot443, align 8
  %cmp3322 = icmp eq i64 %v3321, 1
  %cv3323 = zext i1 %cmp3322 to i64
  store i64 %cv3323, ptr %slot444, align 8
  %v3324 = load i64, ptr %slot444, align 8
  %cond3325 = icmp ne i64 %v3324, 0
  br i1 %cond3325, label %bb_errtrace672, label %bb_errtraced672
bb_errtrace672:
  %p3326 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3326, i64 8589934617) "call-inline-cost"="0", !dbg !132
  br label %bb_errtraced672
bb_errtraced672:
  %v3327 = load i64, ptr %slot47, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  %ld3329 = load i64, ptr %p3328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3329, ptr %slot445, align 8
  %v3330 = load i64, ptr %slot31, align 8
  store i64 %v3330, ptr %slot446, align 8
  %v3331 = load i64, ptr %slot57, align 8
  store i64 %v3331, ptr %slot447, align 8
  %v3332 = load i64, ptr %slot56, align 8
  %v3333 = load i64, ptr %slot446, align 8
  %v3334 = load i64, ptr %slot445, align 8
  %v3335 = load i64, ptr %slot447, align 8
  %cv3336 = trunc i64 %v3335 to i32
  %call3337 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v3332, i64 %v3333, i64 %v3334, i32 %cv3336) nomerge, !dbg !132
  store i32 %call3337, ptr %slot448, align 8
  %v3338 = load i32, ptr %slot448, align 8
  %cv3339 = zext i32 %v3338 to i64
  %cond3340 = icmp ne i64 %cv3339, 0
  br i1 %cond3340, label %bb_rcsuccess677, label %bb_rcfailure677
bb_rcfailure677:
  %v3341 = load i64, ptr %slot56, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %call3343 = call i32 @myl_rc_take_failure(ptr %p3342) nomerge, !dbg !132
  store i32 %call3343, ptr %slot449, align 8
  %v3344 = load i64, ptr %slot1, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  %v3346 = load i32, ptr %slot449, align 8
  %call3347 = call i32 @myl_qbe_rc_status(ptr %p3345, i32 %v3346) nomerge, !dbg !132
  store i32 %call3347, ptr %slot450, align 8
  br label %bb_failure
bb_rcsuccess677:
  %v3348 = load i64, ptr %slot26, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  store i32 0, ptr %p3349, align 4, !alias.scope !3, !noalias !4
  %v3350 = load i64, ptr %slot29, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  store i32 2, ptr %p3351, align 4, !alias.scope !3, !noalias !4
  %v3352 = load i64, ptr %slot28, align 8
  %p3353 = inttoptr i64 %v3352 to ptr
  store i32 1, ptr %p3353, align 4, !alias.scope !3, !noalias !4
  %v3354 = load i64, ptr %slot31, align 8
  store i64 %v3354, ptr %slot451, align 8
  %v3355 = load i64, ptr %slot28, align 8
  %p3356 = inttoptr i64 %v3355 to ptr
  store i32 0, ptr %p3356, align 4, !alias.scope !3, !noalias !4
  %v3357 = load i64, ptr %slot26, align 8
  %p3358 = inttoptr i64 %v3357 to ptr
  %ld3359 = load i32, ptr %p3358, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3359, ptr %slot452, align 8
  %v3360 = load i32, ptr %slot452, align 8
  %cv3361 = zext i32 %v3360 to i64
  %cond3362 = icmp ne i64 %cv3361, 0
  br i1 %cond3362, label %bb_rcslotdrop687, label %bb_rcslotdone687
bb_rcslotdrop687:
  %v3363 = load i64, ptr %slot26, align 8
  %p3364 = inttoptr i64 %v3363 to ptr
  store i32 0, ptr %p3364, align 4, !alias.scope !3, !noalias !4
  %v3365 = load i64, ptr %slot30, align 8
  store i64 %v3365, ptr %slot453, align 8
  %v3366 = load i64, ptr %slot27, align 8
  %p3367 = inttoptr i64 %v3366 to ptr
  %ld3368 = load i32, ptr %p3367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3368, ptr %slot454, align 8
  %v3369 = load i32, ptr %slot454, align 8
  %op3370 = and i32 %v3369, 28
  store i32 %op3370, ptr %slot455, align 8
  %v3371 = load i32, ptr %slot455, align 8
  %cv3372 = zext i32 %v3371 to i64
  %cond3373 = icmp ne i64 %cv3372, 0
  br i1 %cond3373, label %bb_rcslotrole687, label %bb_rcslotowner687
bb_rcslotrole687:
  %v3374 = load i64, ptr %slot56, align 8
  store i64 %v3374, ptr %slot456, align 8
  %v3375 = load i64, ptr %slot456, align 8
  %v3376 = load i64, ptr %slot453, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v3375, i64 %v3376) nomerge, !dbg !132
  br label %bb_rcslotdone687
bb_rcslotowner687:
  %v3377 = load i64, ptr %slot56, align 8
  store i64 %v3377, ptr %slot457, align 8
  %v3378 = load i64, ptr %slot457, align 8
  %v3379 = load i64, ptr %slot453, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3378, i64 %v3379) nomerge, !dbg !132
  br label %bb_rcslotdone687
bb_rcslotdone687:
  %v3380 = load i64, ptr %slot24, align 8
  %p3381 = inttoptr i64 %v3380 to ptr
  %ld3382 = load i32, ptr %p3381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3382, ptr %slot458, align 8
  %v3383 = load i32, ptr %slot458, align 8
  %cv3384 = zext i32 %v3383 to i64
  %cond3385 = icmp ne i64 %cv3384, 0
  br i1 %cond3385, label %bb_rcslotdrop696, label %bb_rcslotdone696
bb_rcslotdrop696:
  %v3386 = load i64, ptr %slot24, align 8
  %p3387 = inttoptr i64 %v3386 to ptr
  store i32 0, ptr %p3387, align 4, !alias.scope !3, !noalias !4
  %v3388 = load i64, ptr %slot46, align 8
  store i64 %v3388, ptr %slot459, align 8
  %v3389 = load i64, ptr %slot25, align 8
  %p3390 = inttoptr i64 %v3389 to ptr
  %ld3391 = load i32, ptr %p3390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3391, ptr %slot460, align 8
  %v3392 = load i32, ptr %slot460, align 8
  %op3393 = and i32 %v3392, 28
  store i32 %op3393, ptr %slot461, align 8
  %v3394 = load i32, ptr %slot461, align 8
  %cv3395 = zext i32 %v3394 to i64
  %cond3396 = icmp ne i64 %cv3395, 0
  br i1 %cond3396, label %bb_rcslotrole696, label %bb_rcslotowner696
bb_rcslotrole696:
  %v3397 = load i64, ptr %slot56, align 8
  store i64 %v3397, ptr %slot462, align 8
  %v3398 = load i64, ptr %slot462, align 8
  %v3399 = load i64, ptr %slot459, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v3398, i64 %v3399) nomerge, !dbg !132
  br label %bb_rcslotdone696
bb_rcslotowner696:
  %v3400 = load i64, ptr %slot56, align 8
  store i64 %v3400, ptr %slot463, align 8
  %v3401 = load i64, ptr %slot463, align 8
  %v3402 = load i64, ptr %slot459, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v3401, i64 %v3402) nomerge, !dbg !132
  br label %bb_rcslotdone696
bb_rcslotdone696:
  %v3403 = load i64, ptr %slot22, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  %ld3405 = load i32, ptr %p3404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3405, ptr %slot464, align 8
  %v3406 = load i32, ptr %slot464, align 8
  %cv3407 = zext i32 %v3406 to i64
  %cond3408 = icmp ne i64 %cv3407, 0
  br i1 %cond3408, label %bb_rcslotdrop705, label %bb_rcslotdone705
bb_rcslotdrop705:
  %v3409 = load i64, ptr %slot22, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  store i32 0, ptr %p3410, align 4, !alias.scope !3, !noalias !4
  %v3411 = load i64, ptr %slot45, align 8
  store i64 %v3411, ptr %slot465, align 8
  %v3412 = load i64, ptr %slot23, align 8
  %p3413 = inttoptr i64 %v3412 to ptr
  %ld3414 = load i32, ptr %p3413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3414, ptr %slot466, align 8
  %v3415 = load i32, ptr %slot466, align 8
  %op3416 = and i32 %v3415, 28
  store i32 %op3416, ptr %slot467, align 8
  %v3417 = load i32, ptr %slot467, align 8
  %cv3418 = zext i32 %v3417 to i64
  %cond3419 = icmp ne i64 %cv3418, 0
  br i1 %cond3419, label %bb_rcslotrole705, label %bb_rcslotowner705
bb_rcslotrole705:
  %v3420 = load i64, ptr %slot56, align 8
  store i64 %v3420, ptr %slot468, align 8
  %v3421 = load i64, ptr %slot468, align 8
  %v3422 = load i64, ptr %slot465, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v3421, i64 %v3422) nomerge, !dbg !132
  br label %bb_rcslotdone705
bb_rcslotowner705:
  %v3423 = load i64, ptr %slot56, align 8
  store i64 %v3423, ptr %slot469, align 8
  %v3424 = load i64, ptr %slot469, align 8
  %v3425 = load i64, ptr %slot465, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v3424, i64 %v3425) nomerge, !dbg !132
  br label %bb_rcslotdone705
bb_rcslotdone705:
  %v3426 = load i64, ptr %slot20, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  %ld3428 = load i32, ptr %p3427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3428, ptr %slot470, align 8
  %v3429 = load i32, ptr %slot470, align 8
  %cv3430 = zext i32 %v3429 to i64
  %cond3431 = icmp ne i64 %cv3430, 0
  br i1 %cond3431, label %bb_rcslotdrop714, label %bb_rcslotdone714
bb_rcslotdrop714:
  %v3432 = load i64, ptr %slot20, align 8
  %p3433 = inttoptr i64 %v3432 to ptr
  store i32 0, ptr %p3433, align 4, !alias.scope !3, !noalias !4
  %v3434 = load i64, ptr %slot44, align 8
  store i64 %v3434, ptr %slot471, align 8
  %v3435 = load i64, ptr %slot21, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  %ld3437 = load i32, ptr %p3436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3437, ptr %slot472, align 8
  %v3438 = load i32, ptr %slot472, align 8
  %op3439 = and i32 %v3438, 28
  store i32 %op3439, ptr %slot473, align 8
  %v3440 = load i32, ptr %slot473, align 8
  %cv3441 = zext i32 %v3440 to i64
  %cond3442 = icmp ne i64 %cv3441, 0
  br i1 %cond3442, label %bb_rcslotrole714, label %bb_rcslotowner714
bb_rcslotrole714:
  %v3443 = load i64, ptr %slot56, align 8
  store i64 %v3443, ptr %slot474, align 8
  %v3444 = load i64, ptr %slot474, align 8
  %v3445 = load i64, ptr %slot471, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v3444, i64 %v3445) nomerge, !dbg !132
  br label %bb_rcslotdone714
bb_rcslotowner714:
  %v3446 = load i64, ptr %slot56, align 8
  store i64 %v3446, ptr %slot475, align 8
  %v3447 = load i64, ptr %slot475, align 8
  %v3448 = load i64, ptr %slot471, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v3447, i64 %v3448) nomerge, !dbg !132
  br label %bb_rcslotdone714
bb_rcslotdone714:
  %v3449 = load i64, ptr %slot18, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  %ld3451 = load i32, ptr %p3450, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3451, ptr %slot476, align 8
  %v3452 = load i32, ptr %slot476, align 8
  %cv3453 = zext i32 %v3452 to i64
  %cond3454 = icmp ne i64 %cv3453, 0
  br i1 %cond3454, label %bb_rcslotdrop723, label %bb_rcslotdone723
bb_rcslotdrop723:
  %v3455 = load i64, ptr %slot18, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i32 0, ptr %p3456, align 4, !alias.scope !3, !noalias !4
  %v3457 = load i64, ptr %slot43, align 8
  store i64 %v3457, ptr %slot477, align 8
  %v3458 = load i64, ptr %slot19, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  %ld3460 = load i32, ptr %p3459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3460, ptr %slot478, align 8
  %v3461 = load i32, ptr %slot478, align 8
  %op3462 = and i32 %v3461, 28
  store i32 %op3462, ptr %slot479, align 8
  %v3463 = load i32, ptr %slot479, align 8
  %cv3464 = zext i32 %v3463 to i64
  %cond3465 = icmp ne i64 %cv3464, 0
  br i1 %cond3465, label %bb_rcslotrole723, label %bb_rcslotowner723
bb_rcslotrole723:
  %v3466 = load i64, ptr %slot56, align 8
  store i64 %v3466, ptr %slot480, align 8
  %v3467 = load i64, ptr %slot480, align 8
  %v3468 = load i64, ptr %slot477, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v3467, i64 %v3468) nomerge, !dbg !132
  br label %bb_rcslotdone723
bb_rcslotowner723:
  %v3469 = load i64, ptr %slot56, align 8
  store i64 %v3469, ptr %slot481, align 8
  %v3470 = load i64, ptr %slot481, align 8
  %v3471 = load i64, ptr %slot477, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v3470, i64 %v3471) nomerge, !dbg !132
  br label %bb_rcslotdone723
bb_rcslotdone723:
  %v3472 = load i64, ptr %slot16, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %ld3474 = load i32, ptr %p3473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3474, ptr %slot482, align 8
  %v3475 = load i32, ptr %slot482, align 8
  %cv3476 = zext i32 %v3475 to i64
  %cond3477 = icmp ne i64 %cv3476, 0
  br i1 %cond3477, label %bb_rcslotdrop732, label %bb_rcslotdone732
bb_rcslotdrop732:
  %v3478 = load i64, ptr %slot16, align 8
  %p3479 = inttoptr i64 %v3478 to ptr
  store i32 0, ptr %p3479, align 4, !alias.scope !3, !noalias !4
  %v3480 = load i64, ptr %slot42, align 8
  store i64 %v3480, ptr %slot483, align 8
  %v3481 = load i64, ptr %slot17, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  %ld3483 = load i32, ptr %p3482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3483, ptr %slot484, align 8
  %v3484 = load i32, ptr %slot484, align 8
  %op3485 = and i32 %v3484, 28
  store i32 %op3485, ptr %slot485, align 8
  %v3486 = load i32, ptr %slot485, align 8
  %cv3487 = zext i32 %v3486 to i64
  %cond3488 = icmp ne i64 %cv3487, 0
  br i1 %cond3488, label %bb_rcslotrole732, label %bb_rcslotowner732
bb_rcslotrole732:
  %v3489 = load i64, ptr %slot56, align 8
  store i64 %v3489, ptr %slot486, align 8
  %v3490 = load i64, ptr %slot486, align 8
  %v3491 = load i64, ptr %slot483, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v3490, i64 %v3491) nomerge, !dbg !132
  br label %bb_rcslotdone732
bb_rcslotowner732:
  %v3492 = load i64, ptr %slot56, align 8
  store i64 %v3492, ptr %slot487, align 8
  %v3493 = load i64, ptr %slot487, align 8
  %v3494 = load i64, ptr %slot483, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v3493, i64 %v3494) nomerge, !dbg !132
  br label %bb_rcslotdone732
bb_rcslotdone732:
  %v3495 = load i64, ptr %slot14, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  %ld3497 = load i32, ptr %p3496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3497, ptr %slot488, align 8
  %v3498 = load i32, ptr %slot488, align 8
  %cv3499 = zext i32 %v3498 to i64
  %cond3500 = icmp ne i64 %cv3499, 0
  br i1 %cond3500, label %bb_rcslotdrop741, label %bb_rcslotdone741
bb_rcslotdrop741:
  %v3501 = load i64, ptr %slot14, align 8
  %p3502 = inttoptr i64 %v3501 to ptr
  store i32 0, ptr %p3502, align 4, !alias.scope !3, !noalias !4
  %v3503 = load i64, ptr %slot41, align 8
  store i64 %v3503, ptr %slot489, align 8
  %v3504 = load i64, ptr %slot15, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  %ld3506 = load i32, ptr %p3505, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3506, ptr %slot490, align 8
  %v3507 = load i32, ptr %slot490, align 8
  %op3508 = and i32 %v3507, 28
  store i32 %op3508, ptr %slot491, align 8
  %v3509 = load i32, ptr %slot491, align 8
  %cv3510 = zext i32 %v3509 to i64
  %cond3511 = icmp ne i64 %cv3510, 0
  br i1 %cond3511, label %bb_rcslotrole741, label %bb_rcslotowner741
bb_rcslotrole741:
  %v3512 = load i64, ptr %slot56, align 8
  store i64 %v3512, ptr %slot492, align 8
  %v3513 = load i64, ptr %slot492, align 8
  %v3514 = load i64, ptr %slot489, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v3513, i64 %v3514) nomerge, !dbg !132
  br label %bb_rcslotdone741
bb_rcslotowner741:
  %v3515 = load i64, ptr %slot56, align 8
  store i64 %v3515, ptr %slot493, align 8
  %v3516 = load i64, ptr %slot493, align 8
  %v3517 = load i64, ptr %slot489, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v3516, i64 %v3517) nomerge, !dbg !132
  br label %bb_rcslotdone741
bb_rcslotdone741:
  %v3518 = load i64, ptr %slot12, align 8
  %p3519 = inttoptr i64 %v3518 to ptr
  %ld3520 = load i32, ptr %p3519, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3520, ptr %slot494, align 8
  %v3521 = load i32, ptr %slot494, align 8
  %cv3522 = zext i32 %v3521 to i64
  %cond3523 = icmp ne i64 %cv3522, 0
  br i1 %cond3523, label %bb_rcslotdrop750, label %bb_rcslotdone750
bb_rcslotdrop750:
  %v3524 = load i64, ptr %slot12, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  store i32 0, ptr %p3525, align 4, !alias.scope !3, !noalias !4
  %v3526 = load i64, ptr %slot40, align 8
  store i64 %v3526, ptr %slot495, align 8
  %v3527 = load i64, ptr %slot13, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  %ld3529 = load i32, ptr %p3528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3529, ptr %slot496, align 8
  %v3530 = load i32, ptr %slot496, align 8
  %op3531 = and i32 %v3530, 28
  store i32 %op3531, ptr %slot497, align 8
  %v3532 = load i32, ptr %slot497, align 8
  %cv3533 = zext i32 %v3532 to i64
  %cond3534 = icmp ne i64 %cv3533, 0
  br i1 %cond3534, label %bb_rcslotrole750, label %bb_rcslotowner750
bb_rcslotrole750:
  %v3535 = load i64, ptr %slot56, align 8
  store i64 %v3535, ptr %slot498, align 8
  %v3536 = load i64, ptr %slot498, align 8
  %v3537 = load i64, ptr %slot495, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v3536, i64 %v3537) nomerge, !dbg !132
  br label %bb_rcslotdone750
bb_rcslotowner750:
  %v3538 = load i64, ptr %slot56, align 8
  store i64 %v3538, ptr %slot499, align 8
  %v3539 = load i64, ptr %slot499, align 8
  %v3540 = load i64, ptr %slot495, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v3539, i64 %v3540) nomerge, !dbg !132
  br label %bb_rcslotdone750
bb_rcslotdone750:
  %v3541 = load i64, ptr %slot10, align 8
  %p3542 = inttoptr i64 %v3541 to ptr
  %ld3543 = load i32, ptr %p3542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3543, ptr %slot500, align 8
  %v3544 = load i32, ptr %slot500, align 8
  %cv3545 = zext i32 %v3544 to i64
  %cond3546 = icmp ne i64 %cv3545, 0
  br i1 %cond3546, label %bb_rcslotdrop759, label %bb_rcslotdone759
bb_rcslotdrop759:
  %v3547 = load i64, ptr %slot10, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  store i32 0, ptr %p3548, align 4, !alias.scope !3, !noalias !4
  %v3549 = load i64, ptr %slot38, align 8
  store i64 %v3549, ptr %slot501, align 8
  %v3550 = load i64, ptr %slot11, align 8
  %p3551 = inttoptr i64 %v3550 to ptr
  %ld3552 = load i32, ptr %p3551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3552, ptr %slot502, align 8
  %v3553 = load i32, ptr %slot502, align 8
  %op3554 = and i32 %v3553, 28
  store i32 %op3554, ptr %slot503, align 8
  %v3555 = load i32, ptr %slot503, align 8
  %cv3556 = zext i32 %v3555 to i64
  %cond3557 = icmp ne i64 %cv3556, 0
  br i1 %cond3557, label %bb_rcslotrole759, label %bb_rcslotowner759
bb_rcslotrole759:
  %v3558 = load i64, ptr %slot56, align 8
  store i64 %v3558, ptr %slot504, align 8
  %v3559 = load i64, ptr %slot504, align 8
  %v3560 = load i64, ptr %slot501, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v3559, i64 %v3560) nomerge, !dbg !132
  br label %bb_rcslotdone759
bb_rcslotowner759:
  %v3561 = load i64, ptr %slot56, align 8
  store i64 %v3561, ptr %slot505, align 8
  %v3562 = load i64, ptr %slot505, align 8
  %v3563 = load i64, ptr %slot501, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v3562, i64 %v3563) nomerge, !dbg !132
  br label %bb_rcslotdone759
bb_rcslotdone759:
  %v3564 = load i64, ptr %slot8, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  %ld3566 = load i32, ptr %p3565, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3566, ptr %slot506, align 8
  %v3567 = load i32, ptr %slot506, align 8
  %cv3568 = zext i32 %v3567 to i64
  %cond3569 = icmp ne i64 %cv3568, 0
  br i1 %cond3569, label %bb_rcslotdrop768, label %bb_rcslotdone768
bb_rcslotdrop768:
  %v3570 = load i64, ptr %slot8, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  store i32 0, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  %v3572 = load i64, ptr %slot37, align 8
  store i64 %v3572, ptr %slot507, align 8
  %v3573 = load i64, ptr %slot9, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  %ld3575 = load i32, ptr %p3574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3575, ptr %slot508, align 8
  %v3576 = load i32, ptr %slot508, align 8
  %op3577 = and i32 %v3576, 28
  store i32 %op3577, ptr %slot509, align 8
  %v3578 = load i32, ptr %slot509, align 8
  %cv3579 = zext i32 %v3578 to i64
  %cond3580 = icmp ne i64 %cv3579, 0
  br i1 %cond3580, label %bb_rcslotrole768, label %bb_rcslotowner768
bb_rcslotrole768:
  %v3581 = load i64, ptr %slot56, align 8
  store i64 %v3581, ptr %slot510, align 8
  %v3582 = load i64, ptr %slot510, align 8
  %v3583 = load i64, ptr %slot507, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v3582, i64 %v3583) nomerge, !dbg !132
  br label %bb_rcslotdone768
bb_rcslotowner768:
  %v3584 = load i64, ptr %slot56, align 8
  store i64 %v3584, ptr %slot511, align 8
  %v3585 = load i64, ptr %slot511, align 8
  %v3586 = load i64, ptr %slot507, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v3585, i64 %v3586) nomerge, !dbg !132
  br label %bb_rcslotdone768
bb_rcslotdone768:
  %v3587 = load i64, ptr %slot6, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  %ld3589 = load i32, ptr %p3588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3589, ptr %slot512, align 8
  %v3590 = load i32, ptr %slot512, align 8
  %cv3591 = zext i32 %v3590 to i64
  %cond3592 = icmp ne i64 %cv3591, 0
  br i1 %cond3592, label %bb_rcslotdrop777, label %bb_rcslotdone777
bb_rcslotdrop777:
  %v3593 = load i64, ptr %slot6, align 8
  %p3594 = inttoptr i64 %v3593 to ptr
  store i32 0, ptr %p3594, align 4, !alias.scope !3, !noalias !4
  %v3595 = load i64, ptr %slot36, align 8
  store i64 %v3595, ptr %slot513, align 8
  %v3596 = load i64, ptr %slot7, align 8
  %p3597 = inttoptr i64 %v3596 to ptr
  %ld3598 = load i32, ptr %p3597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3598, ptr %slot514, align 8
  %v3599 = load i32, ptr %slot514, align 8
  %op3600 = and i32 %v3599, 28
  store i32 %op3600, ptr %slot515, align 8
  %v3601 = load i32, ptr %slot515, align 8
  %cv3602 = zext i32 %v3601 to i64
  %cond3603 = icmp ne i64 %cv3602, 0
  br i1 %cond3603, label %bb_rcslotrole777, label %bb_rcslotowner777
bb_rcslotrole777:
  %v3604 = load i64, ptr %slot56, align 8
  store i64 %v3604, ptr %slot516, align 8
  %v3605 = load i64, ptr %slot516, align 8
  %v3606 = load i64, ptr %slot513, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v3605, i64 %v3606) nomerge, !dbg !132
  br label %bb_rcslotdone777
bb_rcslotowner777:
  %v3607 = load i64, ptr %slot56, align 8
  store i64 %v3607, ptr %slot517, align 8
  %v3608 = load i64, ptr %slot517, align 8
  %v3609 = load i64, ptr %slot513, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v3608, i64 %v3609) nomerge, !dbg !132
  br label %bb_rcslotdone777
bb_rcslotdone777:
  %v3610 = load i64, ptr %slot451, align 8
  %p3611 = inttoptr i64 %v3610 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3611, i64 24, i1 false)
  ret void
bb_i26:
  %v3612 = load i64, ptr %slot32, align 8
  %p3613 = inttoptr i64 %v3612 to ptr
  %ld3614 = load i64, ptr %p3613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3614, ptr %slot518, align 8
  %v3615 = load i64, ptr %slot518, align 8
  %v3616 = load i64, ptr %slot47, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  store i64 %v3615, ptr %p3617, align 8, !alias.scope !3, !noalias !4
  %v3618 = load i64, ptr %slot33, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  %ld3620 = load i64, ptr %p3619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3620, ptr %slot519, align 8
  %v3621 = load i64, ptr %slot519, align 8
  %v3622 = load i64, ptr %slot48, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  store i64 %v3621, ptr %p3623, align 8, !alias.scope !3, !noalias !4
  %v3624 = load i64, ptr %slot47, align 8
  %p3625 = inttoptr i64 %v3624 to ptr
  %ld3626 = load i64, ptr %p3625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3626, ptr %slot520, align 8
  %v3627 = load i64, ptr %slot48, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  %ld3629 = load i64, ptr %p3628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3629, ptr %slot521, align 8
  %v3630 = load i64, ptr %slot1, align 8
  %v3631 = load i64, ptr %slot520, align 8
  %v3632 = load i64, ptr %slot521, align 8
  call void @myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394(ptr sret([24 x i8]) align 8 %callresult523, i64 %v3630, i64 %v3631, i64 %v3632) nomerge, !dbg !134
  %addr3633 = ptrtoint ptr %callresult523 to i64
  store i64 %addr3633, ptr %slot522, align 8
  %v3634 = load i64, ptr %slot522, align 8
  %v3635 = load i64, ptr %slot47, align 8
  %p3636 = inttoptr i64 %v3635 to ptr
  store i64 %v3634, ptr %p3636, align 8, !alias.scope !3, !noalias !4
  %v3637 = load i64, ptr %slot47, align 8
  %p3638 = inttoptr i64 %v3637 to ptr
  %ld3639 = load i64, ptr %p3638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3639, ptr %slot524, align 8
  %v3640 = load i64, ptr %slot31, align 8
  store i64 %v3640, ptr %slot525, align 8
  %v3641 = load i64, ptr %slot524, align 8
  %v3642 = load i64, ptr %slot525, align 8
  %p3643 = inttoptr i64 %v3641 to ptr
  %p3644 = inttoptr i64 %v3642 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3644, ptr %p3643, i64 24, i1 false)
  %v3645 = load i64, ptr %slot29, align 8
  %p3646 = inttoptr i64 %v3645 to ptr
  store i32 2, ptr %p3646, align 4, !alias.scope !3, !noalias !4
  %v3647 = load i64, ptr %slot28, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  store i32 1, ptr %p3648, align 4, !alias.scope !3, !noalias !4
  %v3649 = load i64, ptr %slot26, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  %ld3651 = load i32, ptr %p3650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3651, ptr %slot526, align 8
  %v3652 = load i32, ptr %slot526, align 8
  %cv3653 = zext i32 %v3652 to i64
  %cond3654 = icmp ne i64 %cv3653, 0
  br i1 %cond3654, label %bb_rcslotdrop841, label %bb_rcslotdone841
bb_rcslotdrop841:
  %v3655 = load i64, ptr %slot26, align 8
  %p3656 = inttoptr i64 %v3655 to ptr
  store i32 0, ptr %p3656, align 4, !alias.scope !3, !noalias !4
  %v3657 = load i64, ptr %slot30, align 8
  store i64 %v3657, ptr %slot527, align 8
  %v3658 = load i64, ptr %slot27, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  %ld3660 = load i32, ptr %p3659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3660, ptr %slot528, align 8
  %v3661 = load i32, ptr %slot528, align 8
  %op3662 = and i32 %v3661, 28
  store i32 %op3662, ptr %slot529, align 8
  %v3663 = load i32, ptr %slot529, align 8
  %cv3664 = zext i32 %v3663 to i64
  %cond3665 = icmp ne i64 %cv3664, 0
  br i1 %cond3665, label %bb_rcslotrole841, label %bb_rcslotowner841
bb_rcslotrole841:
  %v3666 = load i64, ptr %slot56, align 8
  store i64 %v3666, ptr %slot530, align 8
  %v3667 = load i64, ptr %slot530, align 8
  %v3668 = load i64, ptr %slot527, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3667, i64 %v3668) nomerge, !dbg !134
  br label %bb_rcslotdone841
bb_rcslotowner841:
  %v3669 = load i64, ptr %slot56, align 8
  store i64 %v3669, ptr %slot531, align 8
  %v3670 = load i64, ptr %slot531, align 8
  %v3671 = load i64, ptr %slot527, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3670, i64 %v3671) nomerge, !dbg !134
  br label %bb_rcslotdone841
bb_rcslotdone841:
  %v3672 = load i64, ptr %slot30, align 8
  store i64 %v3672, ptr %slot532, align 8
  %v3673 = load i64, ptr %slot31, align 8
  store i64 %v3673, ptr %slot533, align 8
  %v3674 = load i64, ptr %slot533, align 8
  %v3675 = load i64, ptr %slot532, align 8
  %p3676 = inttoptr i64 %v3674 to ptr
  %p3677 = inttoptr i64 %v3675 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3677, ptr %p3676, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3678 = load i64, ptr %slot27, align 8
  %p3679 = inttoptr i64 %v3678 to ptr
  store i32 2, ptr %p3679, align 4, !alias.scope !3, !noalias !4
  %v3680 = load i64, ptr %slot29, align 8
  %p3681 = inttoptr i64 %v3680 to ptr
  %ld3682 = load i32, ptr %p3681, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3682, ptr %slot534, align 8
  %v3683 = load i32, ptr %slot534, align 8
  %v3684 = load i64, ptr %slot27, align 8
  %p3685 = inttoptr i64 %v3684 to ptr
  store i32 %v3683, ptr %p3685, align 4, !alias.scope !3, !noalias !4
  %v3686 = load i64, ptr %slot28, align 8
  %p3687 = inttoptr i64 %v3686 to ptr
  store i32 0, ptr %p3687, align 4, !alias.scope !3, !noalias !4
  %v3688 = load i64, ptr %slot26, align 8
  %p3689 = inttoptr i64 %v3688 to ptr
  store i32 1, ptr %p3689, align 4, !alias.scope !3, !noalias !4
  %v3690 = load i64, ptr %slot532, align 8
  %v3691 = load i64, ptr %slot47, align 8
  %p3692 = inttoptr i64 %v3691 to ptr
  store i64 %v3690, ptr %p3692, align 8, !alias.scope !3, !noalias !4
  %v3693 = load i64, ptr %slot47, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  %ld3695 = load i64, ptr %p3694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3695, ptr %slot535, align 8
  %v3696 = load i64, ptr %slot535, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  %ld3698 = load i32, ptr %p3697, align 4, !alias.scope !3, !noalias !4
  %ext3699 = zext i32 %ld3698 to i64
  store i64 %ext3699, ptr %slot536, align 8
  %v3700 = load i64, ptr %slot536, align 8
  %cmp3701 = icmp eq i64 %v3700, 1
  %cv3702 = zext i1 %cmp3701 to i64
  store i64 %cv3702, ptr %slot537, align 8
  %v3703 = load i64, ptr %slot537, align 8
  %cond3704 = icmp ne i64 %v3703, 0
  br i1 %cond3704, label %bb_errtrace858, label %bb_errtraced858
bb_errtrace858:
  %p3705 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3705, i64 8589934621) "call-inline-cost"="0", !dbg !136
  br label %bb_errtraced858
bb_errtraced858:
  %v3706 = load i64, ptr %slot47, align 8
  %p3707 = inttoptr i64 %v3706 to ptr
  %ld3708 = load i64, ptr %p3707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3708, ptr %slot538, align 8
  %v3709 = load i64, ptr %slot31, align 8
  store i64 %v3709, ptr %slot539, align 8
  %v3710 = load i64, ptr %slot57, align 8
  store i64 %v3710, ptr %slot540, align 8
  %v3711 = load i64, ptr %slot56, align 8
  %v3712 = load i64, ptr %slot539, align 8
  %v3713 = load i64, ptr %slot538, align 8
  %v3714 = load i64, ptr %slot540, align 8
  %cv3715 = trunc i64 %v3714 to i32
  %call3716 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v3711, i64 %v3712, i64 %v3713, i32 %cv3715) nomerge, !dbg !136
  store i32 %call3716, ptr %slot541, align 8
  %v3717 = load i32, ptr %slot541, align 8
  %cv3718 = zext i32 %v3717 to i64
  %cond3719 = icmp ne i64 %cv3718, 0
  br i1 %cond3719, label %bb_rcsuccess863, label %bb_rcfailure863
bb_rcfailure863:
  %v3720 = load i64, ptr %slot56, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  %call3722 = call i32 @myl_rc_take_failure(ptr %p3721) nomerge, !dbg !136
  store i32 %call3722, ptr %slot542, align 8
  %v3723 = load i64, ptr %slot1, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %v3725 = load i32, ptr %slot542, align 8
  %call3726 = call i32 @myl_qbe_rc_status(ptr %p3724, i32 %v3725) nomerge, !dbg !136
  store i32 %call3726, ptr %slot543, align 8
  br label %bb_failure
bb_rcsuccess863:
  %v3727 = load i64, ptr %slot26, align 8
  %p3728 = inttoptr i64 %v3727 to ptr
  store i32 0, ptr %p3728, align 4, !alias.scope !3, !noalias !4
  %v3729 = load i64, ptr %slot29, align 8
  %p3730 = inttoptr i64 %v3729 to ptr
  store i32 2, ptr %p3730, align 4, !alias.scope !3, !noalias !4
  %v3731 = load i64, ptr %slot28, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  store i32 1, ptr %p3732, align 4, !alias.scope !3, !noalias !4
  %v3733 = load i64, ptr %slot31, align 8
  store i64 %v3733, ptr %slot544, align 8
  %v3734 = load i64, ptr %slot28, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  store i32 0, ptr %p3735, align 4, !alias.scope !3, !noalias !4
  %v3736 = load i64, ptr %slot26, align 8
  %p3737 = inttoptr i64 %v3736 to ptr
  %ld3738 = load i32, ptr %p3737, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3738, ptr %slot545, align 8
  %v3739 = load i32, ptr %slot545, align 8
  %cv3740 = zext i32 %v3739 to i64
  %cond3741 = icmp ne i64 %cv3740, 0
  br i1 %cond3741, label %bb_rcslotdrop873, label %bb_rcslotdone873
bb_rcslotdrop873:
  %v3742 = load i64, ptr %slot26, align 8
  %p3743 = inttoptr i64 %v3742 to ptr
  store i32 0, ptr %p3743, align 4, !alias.scope !3, !noalias !4
  %v3744 = load i64, ptr %slot30, align 8
  store i64 %v3744, ptr %slot546, align 8
  %v3745 = load i64, ptr %slot27, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  %ld3747 = load i32, ptr %p3746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3747, ptr %slot547, align 8
  %v3748 = load i32, ptr %slot547, align 8
  %op3749 = and i32 %v3748, 28
  store i32 %op3749, ptr %slot548, align 8
  %v3750 = load i32, ptr %slot548, align 8
  %cv3751 = zext i32 %v3750 to i64
  %cond3752 = icmp ne i64 %cv3751, 0
  br i1 %cond3752, label %bb_rcslotrole873, label %bb_rcslotowner873
bb_rcslotrole873:
  %v3753 = load i64, ptr %slot56, align 8
  store i64 %v3753, ptr %slot549, align 8
  %v3754 = load i64, ptr %slot549, align 8
  %v3755 = load i64, ptr %slot546, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v3754, i64 %v3755) nomerge, !dbg !136
  br label %bb_rcslotdone873
bb_rcslotowner873:
  %v3756 = load i64, ptr %slot56, align 8
  store i64 %v3756, ptr %slot550, align 8
  %v3757 = load i64, ptr %slot550, align 8
  %v3758 = load i64, ptr %slot546, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3757, i64 %v3758) nomerge, !dbg !136
  br label %bb_rcslotdone873
bb_rcslotdone873:
  %v3759 = load i64, ptr %slot24, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  %ld3761 = load i32, ptr %p3760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3761, ptr %slot551, align 8
  %v3762 = load i32, ptr %slot551, align 8
  %cv3763 = zext i32 %v3762 to i64
  %cond3764 = icmp ne i64 %cv3763, 0
  br i1 %cond3764, label %bb_rcslotdrop882, label %bb_rcslotdone882
bb_rcslotdrop882:
  %v3765 = load i64, ptr %slot24, align 8
  %p3766 = inttoptr i64 %v3765 to ptr
  store i32 0, ptr %p3766, align 4, !alias.scope !3, !noalias !4
  %v3767 = load i64, ptr %slot46, align 8
  store i64 %v3767, ptr %slot552, align 8
  %v3768 = load i64, ptr %slot25, align 8
  %p3769 = inttoptr i64 %v3768 to ptr
  %ld3770 = load i32, ptr %p3769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3770, ptr %slot553, align 8
  %v3771 = load i32, ptr %slot553, align 8
  %op3772 = and i32 %v3771, 28
  store i32 %op3772, ptr %slot554, align 8
  %v3773 = load i32, ptr %slot554, align 8
  %cv3774 = zext i32 %v3773 to i64
  %cond3775 = icmp ne i64 %cv3774, 0
  br i1 %cond3775, label %bb_rcslotrole882, label %bb_rcslotowner882
bb_rcslotrole882:
  %v3776 = load i64, ptr %slot56, align 8
  store i64 %v3776, ptr %slot555, align 8
  %v3777 = load i64, ptr %slot555, align 8
  %v3778 = load i64, ptr %slot552, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v3777, i64 %v3778) nomerge, !dbg !136
  br label %bb_rcslotdone882
bb_rcslotowner882:
  %v3779 = load i64, ptr %slot56, align 8
  store i64 %v3779, ptr %slot556, align 8
  %v3780 = load i64, ptr %slot556, align 8
  %v3781 = load i64, ptr %slot552, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v3780, i64 %v3781) nomerge, !dbg !136
  br label %bb_rcslotdone882
bb_rcslotdone882:
  %v3782 = load i64, ptr %slot22, align 8
  %p3783 = inttoptr i64 %v3782 to ptr
  %ld3784 = load i32, ptr %p3783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3784, ptr %slot557, align 8
  %v3785 = load i32, ptr %slot557, align 8
  %cv3786 = zext i32 %v3785 to i64
  %cond3787 = icmp ne i64 %cv3786, 0
  br i1 %cond3787, label %bb_rcslotdrop891, label %bb_rcslotdone891
bb_rcslotdrop891:
  %v3788 = load i64, ptr %slot22, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  store i32 0, ptr %p3789, align 4, !alias.scope !3, !noalias !4
  %v3790 = load i64, ptr %slot45, align 8
  store i64 %v3790, ptr %slot558, align 8
  %v3791 = load i64, ptr %slot23, align 8
  %p3792 = inttoptr i64 %v3791 to ptr
  %ld3793 = load i32, ptr %p3792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3793, ptr %slot559, align 8
  %v3794 = load i32, ptr %slot559, align 8
  %op3795 = and i32 %v3794, 28
  store i32 %op3795, ptr %slot560, align 8
  %v3796 = load i32, ptr %slot560, align 8
  %cv3797 = zext i32 %v3796 to i64
  %cond3798 = icmp ne i64 %cv3797, 0
  br i1 %cond3798, label %bb_rcslotrole891, label %bb_rcslotowner891
bb_rcslotrole891:
  %v3799 = load i64, ptr %slot56, align 8
  store i64 %v3799, ptr %slot561, align 8
  %v3800 = load i64, ptr %slot561, align 8
  %v3801 = load i64, ptr %slot558, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v3800, i64 %v3801) nomerge, !dbg !136
  br label %bb_rcslotdone891
bb_rcslotowner891:
  %v3802 = load i64, ptr %slot56, align 8
  store i64 %v3802, ptr %slot562, align 8
  %v3803 = load i64, ptr %slot562, align 8
  %v3804 = load i64, ptr %slot558, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v3803, i64 %v3804) nomerge, !dbg !136
  br label %bb_rcslotdone891
bb_rcslotdone891:
  %v3805 = load i64, ptr %slot20, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %ld3807 = load i32, ptr %p3806, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3807, ptr %slot563, align 8
  %v3808 = load i32, ptr %slot563, align 8
  %cv3809 = zext i32 %v3808 to i64
  %cond3810 = icmp ne i64 %cv3809, 0
  br i1 %cond3810, label %bb_rcslotdrop900, label %bb_rcslotdone900
bb_rcslotdrop900:
  %v3811 = load i64, ptr %slot20, align 8
  %p3812 = inttoptr i64 %v3811 to ptr
  store i32 0, ptr %p3812, align 4, !alias.scope !3, !noalias !4
  %v3813 = load i64, ptr %slot44, align 8
  store i64 %v3813, ptr %slot564, align 8
  %v3814 = load i64, ptr %slot21, align 8
  %p3815 = inttoptr i64 %v3814 to ptr
  %ld3816 = load i32, ptr %p3815, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3816, ptr %slot565, align 8
  %v3817 = load i32, ptr %slot565, align 8
  %op3818 = and i32 %v3817, 28
  store i32 %op3818, ptr %slot566, align 8
  %v3819 = load i32, ptr %slot566, align 8
  %cv3820 = zext i32 %v3819 to i64
  %cond3821 = icmp ne i64 %cv3820, 0
  br i1 %cond3821, label %bb_rcslotrole900, label %bb_rcslotowner900
bb_rcslotrole900:
  %v3822 = load i64, ptr %slot56, align 8
  store i64 %v3822, ptr %slot567, align 8
  %v3823 = load i64, ptr %slot567, align 8
  %v3824 = load i64, ptr %slot564, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v3823, i64 %v3824) nomerge, !dbg !136
  br label %bb_rcslotdone900
bb_rcslotowner900:
  %v3825 = load i64, ptr %slot56, align 8
  store i64 %v3825, ptr %slot568, align 8
  %v3826 = load i64, ptr %slot568, align 8
  %v3827 = load i64, ptr %slot564, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v3826, i64 %v3827) nomerge, !dbg !136
  br label %bb_rcslotdone900
bb_rcslotdone900:
  %v3828 = load i64, ptr %slot18, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  %ld3830 = load i32, ptr %p3829, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3830, ptr %slot569, align 8
  %v3831 = load i32, ptr %slot569, align 8
  %cv3832 = zext i32 %v3831 to i64
  %cond3833 = icmp ne i64 %cv3832, 0
  br i1 %cond3833, label %bb_rcslotdrop909, label %bb_rcslotdone909
bb_rcslotdrop909:
  %v3834 = load i64, ptr %slot18, align 8
  %p3835 = inttoptr i64 %v3834 to ptr
  store i32 0, ptr %p3835, align 4, !alias.scope !3, !noalias !4
  %v3836 = load i64, ptr %slot43, align 8
  store i64 %v3836, ptr %slot570, align 8
  %v3837 = load i64, ptr %slot19, align 8
  %p3838 = inttoptr i64 %v3837 to ptr
  %ld3839 = load i32, ptr %p3838, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3839, ptr %slot571, align 8
  %v3840 = load i32, ptr %slot571, align 8
  %op3841 = and i32 %v3840, 28
  store i32 %op3841, ptr %slot572, align 8
  %v3842 = load i32, ptr %slot572, align 8
  %cv3843 = zext i32 %v3842 to i64
  %cond3844 = icmp ne i64 %cv3843, 0
  br i1 %cond3844, label %bb_rcslotrole909, label %bb_rcslotowner909
bb_rcslotrole909:
  %v3845 = load i64, ptr %slot56, align 8
  store i64 %v3845, ptr %slot573, align 8
  %v3846 = load i64, ptr %slot573, align 8
  %v3847 = load i64, ptr %slot570, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v3846, i64 %v3847) nomerge, !dbg !136
  br label %bb_rcslotdone909
bb_rcslotowner909:
  %v3848 = load i64, ptr %slot56, align 8
  store i64 %v3848, ptr %slot574, align 8
  %v3849 = load i64, ptr %slot574, align 8
  %v3850 = load i64, ptr %slot570, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v3849, i64 %v3850) nomerge, !dbg !136
  br label %bb_rcslotdone909
bb_rcslotdone909:
  %v3851 = load i64, ptr %slot16, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  %ld3853 = load i32, ptr %p3852, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3853, ptr %slot575, align 8
  %v3854 = load i32, ptr %slot575, align 8
  %cv3855 = zext i32 %v3854 to i64
  %cond3856 = icmp ne i64 %cv3855, 0
  br i1 %cond3856, label %bb_rcslotdrop918, label %bb_rcslotdone918
bb_rcslotdrop918:
  %v3857 = load i64, ptr %slot16, align 8
  %p3858 = inttoptr i64 %v3857 to ptr
  store i32 0, ptr %p3858, align 4, !alias.scope !3, !noalias !4
  %v3859 = load i64, ptr %slot42, align 8
  store i64 %v3859, ptr %slot576, align 8
  %v3860 = load i64, ptr %slot17, align 8
  %p3861 = inttoptr i64 %v3860 to ptr
  %ld3862 = load i32, ptr %p3861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3862, ptr %slot577, align 8
  %v3863 = load i32, ptr %slot577, align 8
  %op3864 = and i32 %v3863, 28
  store i32 %op3864, ptr %slot578, align 8
  %v3865 = load i32, ptr %slot578, align 8
  %cv3866 = zext i32 %v3865 to i64
  %cond3867 = icmp ne i64 %cv3866, 0
  br i1 %cond3867, label %bb_rcslotrole918, label %bb_rcslotowner918
bb_rcslotrole918:
  %v3868 = load i64, ptr %slot56, align 8
  store i64 %v3868, ptr %slot579, align 8
  %v3869 = load i64, ptr %slot579, align 8
  %v3870 = load i64, ptr %slot576, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v3869, i64 %v3870) nomerge, !dbg !136
  br label %bb_rcslotdone918
bb_rcslotowner918:
  %v3871 = load i64, ptr %slot56, align 8
  store i64 %v3871, ptr %slot580, align 8
  %v3872 = load i64, ptr %slot580, align 8
  %v3873 = load i64, ptr %slot576, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v3872, i64 %v3873) nomerge, !dbg !136
  br label %bb_rcslotdone918
bb_rcslotdone918:
  %v3874 = load i64, ptr %slot14, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  %ld3876 = load i32, ptr %p3875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3876, ptr %slot581, align 8
  %v3877 = load i32, ptr %slot581, align 8
  %cv3878 = zext i32 %v3877 to i64
  %cond3879 = icmp ne i64 %cv3878, 0
  br i1 %cond3879, label %bb_rcslotdrop927, label %bb_rcslotdone927
bb_rcslotdrop927:
  %v3880 = load i64, ptr %slot14, align 8
  %p3881 = inttoptr i64 %v3880 to ptr
  store i32 0, ptr %p3881, align 4, !alias.scope !3, !noalias !4
  %v3882 = load i64, ptr %slot41, align 8
  store i64 %v3882, ptr %slot582, align 8
  %v3883 = load i64, ptr %slot15, align 8
  %p3884 = inttoptr i64 %v3883 to ptr
  %ld3885 = load i32, ptr %p3884, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3885, ptr %slot583, align 8
  %v3886 = load i32, ptr %slot583, align 8
  %op3887 = and i32 %v3886, 28
  store i32 %op3887, ptr %slot584, align 8
  %v3888 = load i32, ptr %slot584, align 8
  %cv3889 = zext i32 %v3888 to i64
  %cond3890 = icmp ne i64 %cv3889, 0
  br i1 %cond3890, label %bb_rcslotrole927, label %bb_rcslotowner927
bb_rcslotrole927:
  %v3891 = load i64, ptr %slot56, align 8
  store i64 %v3891, ptr %slot585, align 8
  %v3892 = load i64, ptr %slot585, align 8
  %v3893 = load i64, ptr %slot582, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v3892, i64 %v3893) nomerge, !dbg !136
  br label %bb_rcslotdone927
bb_rcslotowner927:
  %v3894 = load i64, ptr %slot56, align 8
  store i64 %v3894, ptr %slot586, align 8
  %v3895 = load i64, ptr %slot586, align 8
  %v3896 = load i64, ptr %slot582, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v3895, i64 %v3896) nomerge, !dbg !136
  br label %bb_rcslotdone927
bb_rcslotdone927:
  %v3897 = load i64, ptr %slot12, align 8
  %p3898 = inttoptr i64 %v3897 to ptr
  %ld3899 = load i32, ptr %p3898, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3899, ptr %slot587, align 8
  %v3900 = load i32, ptr %slot587, align 8
  %cv3901 = zext i32 %v3900 to i64
  %cond3902 = icmp ne i64 %cv3901, 0
  br i1 %cond3902, label %bb_rcslotdrop936, label %bb_rcslotdone936
bb_rcslotdrop936:
  %v3903 = load i64, ptr %slot12, align 8
  %p3904 = inttoptr i64 %v3903 to ptr
  store i32 0, ptr %p3904, align 4, !alias.scope !3, !noalias !4
  %v3905 = load i64, ptr %slot40, align 8
  store i64 %v3905, ptr %slot588, align 8
  %v3906 = load i64, ptr %slot13, align 8
  %p3907 = inttoptr i64 %v3906 to ptr
  %ld3908 = load i32, ptr %p3907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3908, ptr %slot589, align 8
  %v3909 = load i32, ptr %slot589, align 8
  %op3910 = and i32 %v3909, 28
  store i32 %op3910, ptr %slot590, align 8
  %v3911 = load i32, ptr %slot590, align 8
  %cv3912 = zext i32 %v3911 to i64
  %cond3913 = icmp ne i64 %cv3912, 0
  br i1 %cond3913, label %bb_rcslotrole936, label %bb_rcslotowner936
bb_rcslotrole936:
  %v3914 = load i64, ptr %slot56, align 8
  store i64 %v3914, ptr %slot591, align 8
  %v3915 = load i64, ptr %slot591, align 8
  %v3916 = load i64, ptr %slot588, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v3915, i64 %v3916) nomerge, !dbg !136
  br label %bb_rcslotdone936
bb_rcslotowner936:
  %v3917 = load i64, ptr %slot56, align 8
  store i64 %v3917, ptr %slot592, align 8
  %v3918 = load i64, ptr %slot592, align 8
  %v3919 = load i64, ptr %slot588, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v3918, i64 %v3919) nomerge, !dbg !136
  br label %bb_rcslotdone936
bb_rcslotdone936:
  %v3920 = load i64, ptr %slot10, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  %ld3922 = load i32, ptr %p3921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3922, ptr %slot593, align 8
  %v3923 = load i32, ptr %slot593, align 8
  %cv3924 = zext i32 %v3923 to i64
  %cond3925 = icmp ne i64 %cv3924, 0
  br i1 %cond3925, label %bb_rcslotdrop945, label %bb_rcslotdone945
bb_rcslotdrop945:
  %v3926 = load i64, ptr %slot10, align 8
  %p3927 = inttoptr i64 %v3926 to ptr
  store i32 0, ptr %p3927, align 4, !alias.scope !3, !noalias !4
  %v3928 = load i64, ptr %slot38, align 8
  store i64 %v3928, ptr %slot594, align 8
  %v3929 = load i64, ptr %slot11, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  %ld3931 = load i32, ptr %p3930, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3931, ptr %slot595, align 8
  %v3932 = load i32, ptr %slot595, align 8
  %op3933 = and i32 %v3932, 28
  store i32 %op3933, ptr %slot596, align 8
  %v3934 = load i32, ptr %slot596, align 8
  %cv3935 = zext i32 %v3934 to i64
  %cond3936 = icmp ne i64 %cv3935, 0
  br i1 %cond3936, label %bb_rcslotrole945, label %bb_rcslotowner945
bb_rcslotrole945:
  %v3937 = load i64, ptr %slot56, align 8
  store i64 %v3937, ptr %slot597, align 8
  %v3938 = load i64, ptr %slot597, align 8
  %v3939 = load i64, ptr %slot594, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v3938, i64 %v3939) nomerge, !dbg !136
  br label %bb_rcslotdone945
bb_rcslotowner945:
  %v3940 = load i64, ptr %slot56, align 8
  store i64 %v3940, ptr %slot598, align 8
  %v3941 = load i64, ptr %slot598, align 8
  %v3942 = load i64, ptr %slot594, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v3941, i64 %v3942) nomerge, !dbg !136
  br label %bb_rcslotdone945
bb_rcslotdone945:
  %v3943 = load i64, ptr %slot8, align 8
  %p3944 = inttoptr i64 %v3943 to ptr
  %ld3945 = load i32, ptr %p3944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3945, ptr %slot599, align 8
  %v3946 = load i32, ptr %slot599, align 8
  %cv3947 = zext i32 %v3946 to i64
  %cond3948 = icmp ne i64 %cv3947, 0
  br i1 %cond3948, label %bb_rcslotdrop954, label %bb_rcslotdone954
bb_rcslotdrop954:
  %v3949 = load i64, ptr %slot8, align 8
  %p3950 = inttoptr i64 %v3949 to ptr
  store i32 0, ptr %p3950, align 4, !alias.scope !3, !noalias !4
  %v3951 = load i64, ptr %slot37, align 8
  store i64 %v3951, ptr %slot600, align 8
  %v3952 = load i64, ptr %slot9, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  %ld3954 = load i32, ptr %p3953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3954, ptr %slot601, align 8
  %v3955 = load i32, ptr %slot601, align 8
  %op3956 = and i32 %v3955, 28
  store i32 %op3956, ptr %slot602, align 8
  %v3957 = load i32, ptr %slot602, align 8
  %cv3958 = zext i32 %v3957 to i64
  %cond3959 = icmp ne i64 %cv3958, 0
  br i1 %cond3959, label %bb_rcslotrole954, label %bb_rcslotowner954
bb_rcslotrole954:
  %v3960 = load i64, ptr %slot56, align 8
  store i64 %v3960, ptr %slot603, align 8
  %v3961 = load i64, ptr %slot603, align 8
  %v3962 = load i64, ptr %slot600, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v3961, i64 %v3962) nomerge, !dbg !136
  br label %bb_rcslotdone954
bb_rcslotowner954:
  %v3963 = load i64, ptr %slot56, align 8
  store i64 %v3963, ptr %slot604, align 8
  %v3964 = load i64, ptr %slot604, align 8
  %v3965 = load i64, ptr %slot600, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v3964, i64 %v3965) nomerge, !dbg !136
  br label %bb_rcslotdone954
bb_rcslotdone954:
  %v3966 = load i64, ptr %slot6, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  %ld3968 = load i32, ptr %p3967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3968, ptr %slot605, align 8
  %v3969 = load i32, ptr %slot605, align 8
  %cv3970 = zext i32 %v3969 to i64
  %cond3971 = icmp ne i64 %cv3970, 0
  br i1 %cond3971, label %bb_rcslotdrop963, label %bb_rcslotdone963
bb_rcslotdrop963:
  %v3972 = load i64, ptr %slot6, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  store i32 0, ptr %p3973, align 4, !alias.scope !3, !noalias !4
  %v3974 = load i64, ptr %slot36, align 8
  store i64 %v3974, ptr %slot606, align 8
  %v3975 = load i64, ptr %slot7, align 8
  %p3976 = inttoptr i64 %v3975 to ptr
  %ld3977 = load i32, ptr %p3976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3977, ptr %slot607, align 8
  %v3978 = load i32, ptr %slot607, align 8
  %op3979 = and i32 %v3978, 28
  store i32 %op3979, ptr %slot608, align 8
  %v3980 = load i32, ptr %slot608, align 8
  %cv3981 = zext i32 %v3980 to i64
  %cond3982 = icmp ne i64 %cv3981, 0
  br i1 %cond3982, label %bb_rcslotrole963, label %bb_rcslotowner963
bb_rcslotrole963:
  %v3983 = load i64, ptr %slot56, align 8
  store i64 %v3983, ptr %slot609, align 8
  %v3984 = load i64, ptr %slot609, align 8
  %v3985 = load i64, ptr %slot606, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v3984, i64 %v3985) nomerge, !dbg !136
  br label %bb_rcslotdone963
bb_rcslotowner963:
  %v3986 = load i64, ptr %slot56, align 8
  store i64 %v3986, ptr %slot610, align 8
  %v3987 = load i64, ptr %slot610, align 8
  %v3988 = load i64, ptr %slot606, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v3987, i64 %v3988) nomerge, !dbg !136
  br label %bb_rcslotdone963
bb_rcslotdone963:
  %v3989 = load i64, ptr %slot544, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3990, i64 24, i1 false)
  ret void
bb_i30:
  %v3991 = load i64, ptr %slot32, align 8
  %p3992 = inttoptr i64 %v3991 to ptr
  %ld3993 = load i64, ptr %p3992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3993, ptr %slot611, align 8
  %v3994 = load i64, ptr %slot611, align 8
  %v3995 = load i64, ptr %slot47, align 8
  %p3996 = inttoptr i64 %v3995 to ptr
  store i64 %v3994, ptr %p3996, align 8, !alias.scope !3, !noalias !4
  %v3997 = load i64, ptr %slot38, align 8
  %v3998 = load i64, ptr %slot48, align 8
  %p3999 = inttoptr i64 %v3998 to ptr
  store i64 %v3997, ptr %p3999, align 8, !alias.scope !3, !noalias !4
  %v4000 = load i64, ptr %slot47, align 8
  %p4001 = inttoptr i64 %v4000 to ptr
  %ld4002 = load i64, ptr %p4001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4002, ptr %slot612, align 8
  %v4003 = load i64, ptr %slot48, align 8
  %p4004 = inttoptr i64 %v4003 to ptr
  %ld4005 = load i64, ptr %p4004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4005, ptr %slot613, align 8
  %v4006 = load i64, ptr %slot1, align 8
  %v4007 = load i64, ptr %slot612, align 8
  %v4008 = load i64, ptr %slot613, align 8
  call void @myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342(ptr sret([24 x i8]) align 8 %callresult615, i64 %v4006, i64 %v4007, i64 %v4008) nomerge, !dbg !138
  %addr4009 = ptrtoint ptr %callresult615 to i64
  store i64 %addr4009, ptr %slot614, align 8
  %v4010 = load i64, ptr %slot614, align 8
  %v4011 = load i64, ptr %slot47, align 8
  %p4012 = inttoptr i64 %v4011 to ptr
  store i64 %v4010, ptr %p4012, align 8, !alias.scope !3, !noalias !4
  %v4013 = load i64, ptr %slot47, align 8
  %p4014 = inttoptr i64 %v4013 to ptr
  %ld4015 = load i64, ptr %p4014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4015, ptr %slot616, align 8
  %v4016 = load i64, ptr %slot31, align 8
  store i64 %v4016, ptr %slot617, align 8
  %v4017 = load i64, ptr %slot616, align 8
  %v4018 = load i64, ptr %slot617, align 8
  %p4019 = inttoptr i64 %v4017 to ptr
  %p4020 = inttoptr i64 %v4018 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4020, ptr %p4019, i64 24, i1 false)
  %v4021 = load i64, ptr %slot29, align 8
  %p4022 = inttoptr i64 %v4021 to ptr
  store i32 2, ptr %p4022, align 4, !alias.scope !3, !noalias !4
  %v4023 = load i64, ptr %slot28, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  store i32 1, ptr %p4024, align 4, !alias.scope !3, !noalias !4
  %v4025 = load i64, ptr %slot26, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  %ld4027 = load i32, ptr %p4026, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4027, ptr %slot618, align 8
  %v4028 = load i32, ptr %slot618, align 8
  %cv4029 = zext i32 %v4028 to i64
  %cond4030 = icmp ne i64 %cv4029, 0
  br i1 %cond4030, label %bb_rcslotdrop1026, label %bb_rcslotdone1026
bb_rcslotdrop1026:
  %v4031 = load i64, ptr %slot26, align 8
  %p4032 = inttoptr i64 %v4031 to ptr
  store i32 0, ptr %p4032, align 4, !alias.scope !3, !noalias !4
  %v4033 = load i64, ptr %slot30, align 8
  store i64 %v4033, ptr %slot619, align 8
  %v4034 = load i64, ptr %slot27, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  %ld4036 = load i32, ptr %p4035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4036, ptr %slot620, align 8
  %v4037 = load i32, ptr %slot620, align 8
  %op4038 = and i32 %v4037, 28
  store i32 %op4038, ptr %slot621, align 8
  %v4039 = load i32, ptr %slot621, align 8
  %cv4040 = zext i32 %v4039 to i64
  %cond4041 = icmp ne i64 %cv4040, 0
  br i1 %cond4041, label %bb_rcslotrole1026, label %bb_rcslotowner1026
bb_rcslotrole1026:
  %v4042 = load i64, ptr %slot56, align 8
  store i64 %v4042, ptr %slot622, align 8
  %v4043 = load i64, ptr %slot622, align 8
  %v4044 = load i64, ptr %slot619, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v4043, i64 %v4044) nomerge, !dbg !138
  br label %bb_rcslotdone1026
bb_rcslotowner1026:
  %v4045 = load i64, ptr %slot56, align 8
  store i64 %v4045, ptr %slot623, align 8
  %v4046 = load i64, ptr %slot623, align 8
  %v4047 = load i64, ptr %slot619, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v4046, i64 %v4047) nomerge, !dbg !138
  br label %bb_rcslotdone1026
bb_rcslotdone1026:
  %v4048 = load i64, ptr %slot30, align 8
  store i64 %v4048, ptr %slot624, align 8
  %v4049 = load i64, ptr %slot31, align 8
  store i64 %v4049, ptr %slot625, align 8
  %v4050 = load i64, ptr %slot625, align 8
  %v4051 = load i64, ptr %slot624, align 8
  %p4052 = inttoptr i64 %v4050 to ptr
  %p4053 = inttoptr i64 %v4051 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4053, ptr %p4052, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4054 = load i64, ptr %slot27, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  store i32 2, ptr %p4055, align 4, !alias.scope !3, !noalias !4
  %v4056 = load i64, ptr %slot29, align 8
  %p4057 = inttoptr i64 %v4056 to ptr
  %ld4058 = load i32, ptr %p4057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4058, ptr %slot626, align 8
  %v4059 = load i32, ptr %slot626, align 8
  %v4060 = load i64, ptr %slot27, align 8
  %p4061 = inttoptr i64 %v4060 to ptr
  store i32 %v4059, ptr %p4061, align 4, !alias.scope !3, !noalias !4
  %v4062 = load i64, ptr %slot28, align 8
  %p4063 = inttoptr i64 %v4062 to ptr
  store i32 0, ptr %p4063, align 4, !alias.scope !3, !noalias !4
  %v4064 = load i64, ptr %slot26, align 8
  %p4065 = inttoptr i64 %v4064 to ptr
  store i32 1, ptr %p4065, align 4, !alias.scope !3, !noalias !4
  %v4066 = load i64, ptr %slot624, align 8
  %v4067 = load i64, ptr %slot47, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  store i64 %v4066, ptr %p4068, align 8, !alias.scope !3, !noalias !4
  %v4069 = load i64, ptr %slot47, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  %ld4071 = load i64, ptr %p4070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4071, ptr %slot627, align 8
  %v4072 = load i64, ptr %slot627, align 8
  %p4073 = inttoptr i64 %v4072 to ptr
  %ld4074 = load i32, ptr %p4073, align 4, !alias.scope !3, !noalias !4
  %ext4075 = zext i32 %ld4074 to i64
  store i64 %ext4075, ptr %slot628, align 8
  %v4076 = load i64, ptr %slot628, align 8
  %cmp4077 = icmp eq i64 %v4076, 1
  %cv4078 = zext i1 %cmp4077 to i64
  store i64 %cv4078, ptr %slot629, align 8
  %v4079 = load i64, ptr %slot629, align 8
  %cond4080 = icmp ne i64 %v4079, 0
  br i1 %cond4080, label %bb_errtrace1052, label %bb_errtraced1052
bb_errtrace1052:
  %p4081 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p4081, i64 8589934625) "call-inline-cost"="0", !dbg !140
  br label %bb_errtraced1052
bb_errtraced1052:
  %v4082 = load i64, ptr %slot47, align 8
  %p4083 = inttoptr i64 %v4082 to ptr
  %ld4084 = load i64, ptr %p4083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4084, ptr %slot630, align 8
  %v4085 = load i64, ptr %slot31, align 8
  store i64 %v4085, ptr %slot631, align 8
  %v4086 = load i64, ptr %slot57, align 8
  store i64 %v4086, ptr %slot632, align 8
  %v4087 = load i64, ptr %slot56, align 8
  %v4088 = load i64, ptr %slot631, align 8
  %v4089 = load i64, ptr %slot630, align 8
  %v4090 = load i64, ptr %slot632, align 8
  %cv4091 = trunc i64 %v4090 to i32
  %call4092 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v4087, i64 %v4088, i64 %v4089, i32 %cv4091) nomerge, !dbg !140
  store i32 %call4092, ptr %slot633, align 8
  %v4093 = load i32, ptr %slot633, align 8
  %cv4094 = zext i32 %v4093 to i64
  %cond4095 = icmp ne i64 %cv4094, 0
  br i1 %cond4095, label %bb_rcsuccess1057, label %bb_rcfailure1057
bb_rcfailure1057:
  %v4096 = load i64, ptr %slot56, align 8
  %p4097 = inttoptr i64 %v4096 to ptr
  %call4098 = call i32 @myl_rc_take_failure(ptr %p4097) nomerge, !dbg !140
  store i32 %call4098, ptr %slot634, align 8
  %v4099 = load i64, ptr %slot1, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  %v4101 = load i32, ptr %slot634, align 8
  %call4102 = call i32 @myl_qbe_rc_status(ptr %p4100, i32 %v4101) nomerge, !dbg !140
  store i32 %call4102, ptr %slot635, align 8
  br label %bb_failure
bb_rcsuccess1057:
  %v4103 = load i64, ptr %slot26, align 8
  %p4104 = inttoptr i64 %v4103 to ptr
  store i32 0, ptr %p4104, align 4, !alias.scope !3, !noalias !4
  %v4105 = load i64, ptr %slot29, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  store i32 2, ptr %p4106, align 4, !alias.scope !3, !noalias !4
  %v4107 = load i64, ptr %slot28, align 8
  %p4108 = inttoptr i64 %v4107 to ptr
  store i32 1, ptr %p4108, align 4, !alias.scope !3, !noalias !4
  %v4109 = load i64, ptr %slot31, align 8
  store i64 %v4109, ptr %slot636, align 8
  %v4110 = load i64, ptr %slot28, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  store i32 0, ptr %p4111, align 4, !alias.scope !3, !noalias !4
  %v4112 = load i64, ptr %slot26, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  %ld4114 = load i32, ptr %p4113, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4114, ptr %slot637, align 8
  %v4115 = load i32, ptr %slot637, align 8
  %cv4116 = zext i32 %v4115 to i64
  %cond4117 = icmp ne i64 %cv4116, 0
  br i1 %cond4117, label %bb_rcslotdrop1067, label %bb_rcslotdone1067
bb_rcslotdrop1067:
  %v4118 = load i64, ptr %slot26, align 8
  %p4119 = inttoptr i64 %v4118 to ptr
  store i32 0, ptr %p4119, align 4, !alias.scope !3, !noalias !4
  %v4120 = load i64, ptr %slot30, align 8
  store i64 %v4120, ptr %slot638, align 8
  %v4121 = load i64, ptr %slot27, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  %ld4123 = load i32, ptr %p4122, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4123, ptr %slot639, align 8
  %v4124 = load i32, ptr %slot639, align 8
  %op4125 = and i32 %v4124, 28
  store i32 %op4125, ptr %slot640, align 8
  %v4126 = load i32, ptr %slot640, align 8
  %cv4127 = zext i32 %v4126 to i64
  %cond4128 = icmp ne i64 %cv4127, 0
  br i1 %cond4128, label %bb_rcslotrole1067, label %bb_rcslotowner1067
bb_rcslotrole1067:
  %v4129 = load i64, ptr %slot56, align 8
  store i64 %v4129, ptr %slot641, align 8
  %v4130 = load i64, ptr %slot641, align 8
  %v4131 = load i64, ptr %slot638, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4130, i64 %v4131) nomerge, !dbg !140
  br label %bb_rcslotdone1067
bb_rcslotowner1067:
  %v4132 = load i64, ptr %slot56, align 8
  store i64 %v4132, ptr %slot642, align 8
  %v4133 = load i64, ptr %slot642, align 8
  %v4134 = load i64, ptr %slot638, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4133, i64 %v4134) nomerge, !dbg !140
  br label %bb_rcslotdone1067
bb_rcslotdone1067:
  %v4135 = load i64, ptr %slot24, align 8
  %p4136 = inttoptr i64 %v4135 to ptr
  %ld4137 = load i32, ptr %p4136, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4137, ptr %slot643, align 8
  %v4138 = load i32, ptr %slot643, align 8
  %cv4139 = zext i32 %v4138 to i64
  %cond4140 = icmp ne i64 %cv4139, 0
  br i1 %cond4140, label %bb_rcslotdrop1076, label %bb_rcslotdone1076
bb_rcslotdrop1076:
  %v4141 = load i64, ptr %slot24, align 8
  %p4142 = inttoptr i64 %v4141 to ptr
  store i32 0, ptr %p4142, align 4, !alias.scope !3, !noalias !4
  %v4143 = load i64, ptr %slot46, align 8
  store i64 %v4143, ptr %slot644, align 8
  %v4144 = load i64, ptr %slot25, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  %ld4146 = load i32, ptr %p4145, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4146, ptr %slot645, align 8
  %v4147 = load i32, ptr %slot645, align 8
  %op4148 = and i32 %v4147, 28
  store i32 %op4148, ptr %slot646, align 8
  %v4149 = load i32, ptr %slot646, align 8
  %cv4150 = zext i32 %v4149 to i64
  %cond4151 = icmp ne i64 %cv4150, 0
  br i1 %cond4151, label %bb_rcslotrole1076, label %bb_rcslotowner1076
bb_rcslotrole1076:
  %v4152 = load i64, ptr %slot56, align 8
  store i64 %v4152, ptr %slot647, align 8
  %v4153 = load i64, ptr %slot647, align 8
  %v4154 = load i64, ptr %slot644, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v4153, i64 %v4154) nomerge, !dbg !140
  br label %bb_rcslotdone1076
bb_rcslotowner1076:
  %v4155 = load i64, ptr %slot56, align 8
  store i64 %v4155, ptr %slot648, align 8
  %v4156 = load i64, ptr %slot648, align 8
  %v4157 = load i64, ptr %slot644, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v4156, i64 %v4157) nomerge, !dbg !140
  br label %bb_rcslotdone1076
bb_rcslotdone1076:
  %v4158 = load i64, ptr %slot22, align 8
  %p4159 = inttoptr i64 %v4158 to ptr
  %ld4160 = load i32, ptr %p4159, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4160, ptr %slot649, align 8
  %v4161 = load i32, ptr %slot649, align 8
  %cv4162 = zext i32 %v4161 to i64
  %cond4163 = icmp ne i64 %cv4162, 0
  br i1 %cond4163, label %bb_rcslotdrop1085, label %bb_rcslotdone1085
bb_rcslotdrop1085:
  %v4164 = load i64, ptr %slot22, align 8
  %p4165 = inttoptr i64 %v4164 to ptr
  store i32 0, ptr %p4165, align 4, !alias.scope !3, !noalias !4
  %v4166 = load i64, ptr %slot45, align 8
  store i64 %v4166, ptr %slot650, align 8
  %v4167 = load i64, ptr %slot23, align 8
  %p4168 = inttoptr i64 %v4167 to ptr
  %ld4169 = load i32, ptr %p4168, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4169, ptr %slot651, align 8
  %v4170 = load i32, ptr %slot651, align 8
  %op4171 = and i32 %v4170, 28
  store i32 %op4171, ptr %slot652, align 8
  %v4172 = load i32, ptr %slot652, align 8
  %cv4173 = zext i32 %v4172 to i64
  %cond4174 = icmp ne i64 %cv4173, 0
  br i1 %cond4174, label %bb_rcslotrole1085, label %bb_rcslotowner1085
bb_rcslotrole1085:
  %v4175 = load i64, ptr %slot56, align 8
  store i64 %v4175, ptr %slot653, align 8
  %v4176 = load i64, ptr %slot653, align 8
  %v4177 = load i64, ptr %slot650, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v4176, i64 %v4177) nomerge, !dbg !140
  br label %bb_rcslotdone1085
bb_rcslotowner1085:
  %v4178 = load i64, ptr %slot56, align 8
  store i64 %v4178, ptr %slot654, align 8
  %v4179 = load i64, ptr %slot654, align 8
  %v4180 = load i64, ptr %slot650, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v4179, i64 %v4180) nomerge, !dbg !140
  br label %bb_rcslotdone1085
bb_rcslotdone1085:
  %v4181 = load i64, ptr %slot20, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  %ld4183 = load i32, ptr %p4182, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4183, ptr %slot655, align 8
  %v4184 = load i32, ptr %slot655, align 8
  %cv4185 = zext i32 %v4184 to i64
  %cond4186 = icmp ne i64 %cv4185, 0
  br i1 %cond4186, label %bb_rcslotdrop1094, label %bb_rcslotdone1094
bb_rcslotdrop1094:
  %v4187 = load i64, ptr %slot20, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  store i32 0, ptr %p4188, align 4, !alias.scope !3, !noalias !4
  %v4189 = load i64, ptr %slot44, align 8
  store i64 %v4189, ptr %slot656, align 8
  %v4190 = load i64, ptr %slot21, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  %ld4192 = load i32, ptr %p4191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4192, ptr %slot657, align 8
  %v4193 = load i32, ptr %slot657, align 8
  %op4194 = and i32 %v4193, 28
  store i32 %op4194, ptr %slot658, align 8
  %v4195 = load i32, ptr %slot658, align 8
  %cv4196 = zext i32 %v4195 to i64
  %cond4197 = icmp ne i64 %cv4196, 0
  br i1 %cond4197, label %bb_rcslotrole1094, label %bb_rcslotowner1094
bb_rcslotrole1094:
  %v4198 = load i64, ptr %slot56, align 8
  store i64 %v4198, ptr %slot659, align 8
  %v4199 = load i64, ptr %slot659, align 8
  %v4200 = load i64, ptr %slot656, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v4199, i64 %v4200) nomerge, !dbg !140
  br label %bb_rcslotdone1094
bb_rcslotowner1094:
  %v4201 = load i64, ptr %slot56, align 8
  store i64 %v4201, ptr %slot660, align 8
  %v4202 = load i64, ptr %slot660, align 8
  %v4203 = load i64, ptr %slot656, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v4202, i64 %v4203) nomerge, !dbg !140
  br label %bb_rcslotdone1094
bb_rcslotdone1094:
  %v4204 = load i64, ptr %slot18, align 8
  %p4205 = inttoptr i64 %v4204 to ptr
  %ld4206 = load i32, ptr %p4205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4206, ptr %slot661, align 8
  %v4207 = load i32, ptr %slot661, align 8
  %cv4208 = zext i32 %v4207 to i64
  %cond4209 = icmp ne i64 %cv4208, 0
  br i1 %cond4209, label %bb_rcslotdrop1103, label %bb_rcslotdone1103
bb_rcslotdrop1103:
  %v4210 = load i64, ptr %slot18, align 8
  %p4211 = inttoptr i64 %v4210 to ptr
  store i32 0, ptr %p4211, align 4, !alias.scope !3, !noalias !4
  %v4212 = load i64, ptr %slot43, align 8
  store i64 %v4212, ptr %slot662, align 8
  %v4213 = load i64, ptr %slot19, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  %ld4215 = load i32, ptr %p4214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4215, ptr %slot663, align 8
  %v4216 = load i32, ptr %slot663, align 8
  %op4217 = and i32 %v4216, 28
  store i32 %op4217, ptr %slot664, align 8
  %v4218 = load i32, ptr %slot664, align 8
  %cv4219 = zext i32 %v4218 to i64
  %cond4220 = icmp ne i64 %cv4219, 0
  br i1 %cond4220, label %bb_rcslotrole1103, label %bb_rcslotowner1103
bb_rcslotrole1103:
  %v4221 = load i64, ptr %slot56, align 8
  store i64 %v4221, ptr %slot665, align 8
  %v4222 = load i64, ptr %slot665, align 8
  %v4223 = load i64, ptr %slot662, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v4222, i64 %v4223) nomerge, !dbg !140
  br label %bb_rcslotdone1103
bb_rcslotowner1103:
  %v4224 = load i64, ptr %slot56, align 8
  store i64 %v4224, ptr %slot666, align 8
  %v4225 = load i64, ptr %slot666, align 8
  %v4226 = load i64, ptr %slot662, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v4225, i64 %v4226) nomerge, !dbg !140
  br label %bb_rcslotdone1103
bb_rcslotdone1103:
  %v4227 = load i64, ptr %slot16, align 8
  %p4228 = inttoptr i64 %v4227 to ptr
  %ld4229 = load i32, ptr %p4228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4229, ptr %slot667, align 8
  %v4230 = load i32, ptr %slot667, align 8
  %cv4231 = zext i32 %v4230 to i64
  %cond4232 = icmp ne i64 %cv4231, 0
  br i1 %cond4232, label %bb_rcslotdrop1112, label %bb_rcslotdone1112
bb_rcslotdrop1112:
  %v4233 = load i64, ptr %slot16, align 8
  %p4234 = inttoptr i64 %v4233 to ptr
  store i32 0, ptr %p4234, align 4, !alias.scope !3, !noalias !4
  %v4235 = load i64, ptr %slot42, align 8
  store i64 %v4235, ptr %slot668, align 8
  %v4236 = load i64, ptr %slot17, align 8
  %p4237 = inttoptr i64 %v4236 to ptr
  %ld4238 = load i32, ptr %p4237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4238, ptr %slot669, align 8
  %v4239 = load i32, ptr %slot669, align 8
  %op4240 = and i32 %v4239, 28
  store i32 %op4240, ptr %slot670, align 8
  %v4241 = load i32, ptr %slot670, align 8
  %cv4242 = zext i32 %v4241 to i64
  %cond4243 = icmp ne i64 %cv4242, 0
  br i1 %cond4243, label %bb_rcslotrole1112, label %bb_rcslotowner1112
bb_rcslotrole1112:
  %v4244 = load i64, ptr %slot56, align 8
  store i64 %v4244, ptr %slot671, align 8
  %v4245 = load i64, ptr %slot671, align 8
  %v4246 = load i64, ptr %slot668, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v4245, i64 %v4246) nomerge, !dbg !140
  br label %bb_rcslotdone1112
bb_rcslotowner1112:
  %v4247 = load i64, ptr %slot56, align 8
  store i64 %v4247, ptr %slot672, align 8
  %v4248 = load i64, ptr %slot672, align 8
  %v4249 = load i64, ptr %slot668, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v4248, i64 %v4249) nomerge, !dbg !140
  br label %bb_rcslotdone1112
bb_rcslotdone1112:
  %v4250 = load i64, ptr %slot14, align 8
  %p4251 = inttoptr i64 %v4250 to ptr
  %ld4252 = load i32, ptr %p4251, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4252, ptr %slot673, align 8
  %v4253 = load i32, ptr %slot673, align 8
  %cv4254 = zext i32 %v4253 to i64
  %cond4255 = icmp ne i64 %cv4254, 0
  br i1 %cond4255, label %bb_rcslotdrop1121, label %bb_rcslotdone1121
bb_rcslotdrop1121:
  %v4256 = load i64, ptr %slot14, align 8
  %p4257 = inttoptr i64 %v4256 to ptr
  store i32 0, ptr %p4257, align 4, !alias.scope !3, !noalias !4
  %v4258 = load i64, ptr %slot41, align 8
  store i64 %v4258, ptr %slot674, align 8
  %v4259 = load i64, ptr %slot15, align 8
  %p4260 = inttoptr i64 %v4259 to ptr
  %ld4261 = load i32, ptr %p4260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4261, ptr %slot675, align 8
  %v4262 = load i32, ptr %slot675, align 8
  %op4263 = and i32 %v4262, 28
  store i32 %op4263, ptr %slot676, align 8
  %v4264 = load i32, ptr %slot676, align 8
  %cv4265 = zext i32 %v4264 to i64
  %cond4266 = icmp ne i64 %cv4265, 0
  br i1 %cond4266, label %bb_rcslotrole1121, label %bb_rcslotowner1121
bb_rcslotrole1121:
  %v4267 = load i64, ptr %slot56, align 8
  store i64 %v4267, ptr %slot677, align 8
  %v4268 = load i64, ptr %slot677, align 8
  %v4269 = load i64, ptr %slot674, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v4268, i64 %v4269) nomerge, !dbg !140
  br label %bb_rcslotdone1121
bb_rcslotowner1121:
  %v4270 = load i64, ptr %slot56, align 8
  store i64 %v4270, ptr %slot678, align 8
  %v4271 = load i64, ptr %slot678, align 8
  %v4272 = load i64, ptr %slot674, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v4271, i64 %v4272) nomerge, !dbg !140
  br label %bb_rcslotdone1121
bb_rcslotdone1121:
  %v4273 = load i64, ptr %slot12, align 8
  %p4274 = inttoptr i64 %v4273 to ptr
  %ld4275 = load i32, ptr %p4274, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4275, ptr %slot679, align 8
  %v4276 = load i32, ptr %slot679, align 8
  %cv4277 = zext i32 %v4276 to i64
  %cond4278 = icmp ne i64 %cv4277, 0
  br i1 %cond4278, label %bb_rcslotdrop1130, label %bb_rcslotdone1130
bb_rcslotdrop1130:
  %v4279 = load i64, ptr %slot12, align 8
  %p4280 = inttoptr i64 %v4279 to ptr
  store i32 0, ptr %p4280, align 4, !alias.scope !3, !noalias !4
  %v4281 = load i64, ptr %slot40, align 8
  store i64 %v4281, ptr %slot680, align 8
  %v4282 = load i64, ptr %slot13, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  %ld4284 = load i32, ptr %p4283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4284, ptr %slot681, align 8
  %v4285 = load i32, ptr %slot681, align 8
  %op4286 = and i32 %v4285, 28
  store i32 %op4286, ptr %slot682, align 8
  %v4287 = load i32, ptr %slot682, align 8
  %cv4288 = zext i32 %v4287 to i64
  %cond4289 = icmp ne i64 %cv4288, 0
  br i1 %cond4289, label %bb_rcslotrole1130, label %bb_rcslotowner1130
bb_rcslotrole1130:
  %v4290 = load i64, ptr %slot56, align 8
  store i64 %v4290, ptr %slot683, align 8
  %v4291 = load i64, ptr %slot683, align 8
  %v4292 = load i64, ptr %slot680, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v4291, i64 %v4292) nomerge, !dbg !140
  br label %bb_rcslotdone1130
bb_rcslotowner1130:
  %v4293 = load i64, ptr %slot56, align 8
  store i64 %v4293, ptr %slot684, align 8
  %v4294 = load i64, ptr %slot684, align 8
  %v4295 = load i64, ptr %slot680, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v4294, i64 %v4295) nomerge, !dbg !140
  br label %bb_rcslotdone1130
bb_rcslotdone1130:
  %v4296 = load i64, ptr %slot10, align 8
  %p4297 = inttoptr i64 %v4296 to ptr
  %ld4298 = load i32, ptr %p4297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4298, ptr %slot685, align 8
  %v4299 = load i32, ptr %slot685, align 8
  %cv4300 = zext i32 %v4299 to i64
  %cond4301 = icmp ne i64 %cv4300, 0
  br i1 %cond4301, label %bb_rcslotdrop1139, label %bb_rcslotdone1139
bb_rcslotdrop1139:
  %v4302 = load i64, ptr %slot10, align 8
  %p4303 = inttoptr i64 %v4302 to ptr
  store i32 0, ptr %p4303, align 4, !alias.scope !3, !noalias !4
  %v4304 = load i64, ptr %slot38, align 8
  store i64 %v4304, ptr %slot686, align 8
  %v4305 = load i64, ptr %slot11, align 8
  %p4306 = inttoptr i64 %v4305 to ptr
  %ld4307 = load i32, ptr %p4306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4307, ptr %slot687, align 8
  %v4308 = load i32, ptr %slot687, align 8
  %op4309 = and i32 %v4308, 28
  store i32 %op4309, ptr %slot688, align 8
  %v4310 = load i32, ptr %slot688, align 8
  %cv4311 = zext i32 %v4310 to i64
  %cond4312 = icmp ne i64 %cv4311, 0
  br i1 %cond4312, label %bb_rcslotrole1139, label %bb_rcslotowner1139
bb_rcslotrole1139:
  %v4313 = load i64, ptr %slot56, align 8
  store i64 %v4313, ptr %slot689, align 8
  %v4314 = load i64, ptr %slot689, align 8
  %v4315 = load i64, ptr %slot686, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v4314, i64 %v4315) nomerge, !dbg !140
  br label %bb_rcslotdone1139
bb_rcslotowner1139:
  %v4316 = load i64, ptr %slot56, align 8
  store i64 %v4316, ptr %slot690, align 8
  %v4317 = load i64, ptr %slot690, align 8
  %v4318 = load i64, ptr %slot686, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v4317, i64 %v4318) nomerge, !dbg !140
  br label %bb_rcslotdone1139
bb_rcslotdone1139:
  %v4319 = load i64, ptr %slot8, align 8
  %p4320 = inttoptr i64 %v4319 to ptr
  %ld4321 = load i32, ptr %p4320, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4321, ptr %slot691, align 8
  %v4322 = load i32, ptr %slot691, align 8
  %cv4323 = zext i32 %v4322 to i64
  %cond4324 = icmp ne i64 %cv4323, 0
  br i1 %cond4324, label %bb_rcslotdrop1148, label %bb_rcslotdone1148
bb_rcslotdrop1148:
  %v4325 = load i64, ptr %slot8, align 8
  %p4326 = inttoptr i64 %v4325 to ptr
  store i32 0, ptr %p4326, align 4, !alias.scope !3, !noalias !4
  %v4327 = load i64, ptr %slot37, align 8
  store i64 %v4327, ptr %slot692, align 8
  %v4328 = load i64, ptr %slot9, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  %ld4330 = load i32, ptr %p4329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4330, ptr %slot693, align 8
  %v4331 = load i32, ptr %slot693, align 8
  %op4332 = and i32 %v4331, 28
  store i32 %op4332, ptr %slot694, align 8
  %v4333 = load i32, ptr %slot694, align 8
  %cv4334 = zext i32 %v4333 to i64
  %cond4335 = icmp ne i64 %cv4334, 0
  br i1 %cond4335, label %bb_rcslotrole1148, label %bb_rcslotowner1148
bb_rcslotrole1148:
  %v4336 = load i64, ptr %slot56, align 8
  store i64 %v4336, ptr %slot695, align 8
  %v4337 = load i64, ptr %slot695, align 8
  %v4338 = load i64, ptr %slot692, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v4337, i64 %v4338) nomerge, !dbg !140
  br label %bb_rcslotdone1148
bb_rcslotowner1148:
  %v4339 = load i64, ptr %slot56, align 8
  store i64 %v4339, ptr %slot696, align 8
  %v4340 = load i64, ptr %slot696, align 8
  %v4341 = load i64, ptr %slot692, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v4340, i64 %v4341) nomerge, !dbg !140
  br label %bb_rcslotdone1148
bb_rcslotdone1148:
  %v4342 = load i64, ptr %slot6, align 8
  %p4343 = inttoptr i64 %v4342 to ptr
  %ld4344 = load i32, ptr %p4343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4344, ptr %slot697, align 8
  %v4345 = load i32, ptr %slot697, align 8
  %cv4346 = zext i32 %v4345 to i64
  %cond4347 = icmp ne i64 %cv4346, 0
  br i1 %cond4347, label %bb_rcslotdrop1157, label %bb_rcslotdone1157
bb_rcslotdrop1157:
  %v4348 = load i64, ptr %slot6, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  store i32 0, ptr %p4349, align 4, !alias.scope !3, !noalias !4
  %v4350 = load i64, ptr %slot36, align 8
  store i64 %v4350, ptr %slot698, align 8
  %v4351 = load i64, ptr %slot7, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  %ld4353 = load i32, ptr %p4352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4353, ptr %slot699, align 8
  %v4354 = load i32, ptr %slot699, align 8
  %op4355 = and i32 %v4354, 28
  store i32 %op4355, ptr %slot700, align 8
  %v4356 = load i32, ptr %slot700, align 8
  %cv4357 = zext i32 %v4356 to i64
  %cond4358 = icmp ne i64 %cv4357, 0
  br i1 %cond4358, label %bb_rcslotrole1157, label %bb_rcslotowner1157
bb_rcslotrole1157:
  %v4359 = load i64, ptr %slot56, align 8
  store i64 %v4359, ptr %slot701, align 8
  %v4360 = load i64, ptr %slot701, align 8
  %v4361 = load i64, ptr %slot698, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v4360, i64 %v4361) nomerge, !dbg !140
  br label %bb_rcslotdone1157
bb_rcslotowner1157:
  %v4362 = load i64, ptr %slot56, align 8
  store i64 %v4362, ptr %slot702, align 8
  %v4363 = load i64, ptr %slot702, align 8
  %v4364 = load i64, ptr %slot698, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v4363, i64 %v4364) nomerge, !dbg !140
  br label %bb_rcslotdone1157
bb_rcslotdone1157:
  %v4365 = load i64, ptr %slot636, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4366, i64 24, i1 false)
  ret void
bb_i34:
  %v4367 = load i64, ptr %slot32, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  %ld4369 = load i64, ptr %p4368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4369, ptr %slot703, align 8
  %v4370 = load i64, ptr %slot703, align 8
  %v4371 = load i64, ptr %slot47, align 8
  %p4372 = inttoptr i64 %v4371 to ptr
  store i64 %v4370, ptr %p4372, align 8, !alias.scope !3, !noalias !4
  %v4373 = load i64, ptr %slot39, align 8
  %v4374 = load i64, ptr %slot48, align 8
  %p4375 = inttoptr i64 %v4374 to ptr
  store i64 %v4373, ptr %p4375, align 8, !alias.scope !3, !noalias !4
  %v4376 = load i64, ptr %slot48, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %ld4378 = load i64, ptr %p4377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4378, ptr %slot704, align 8
  %v4379 = load i64, ptr %slot704, align 8
  %op4380 = add i64 %v4379, 0
  store i64 %op4380, ptr %slot705, align 8
  %v4381 = load i64, ptr %slot705, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  %ld4383 = load i64, ptr %p4382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4383, ptr %slot706, align 8
  %v4384 = load i64, ptr %slot706, align 8
  %v4385 = load i64, ptr %slot48, align 8
  %p4386 = inttoptr i64 %v4385 to ptr
  store i64 %v4384, ptr %p4386, align 8, !alias.scope !3, !noalias !4
  %v4387 = load i64, ptr %slot47, align 8
  %p4388 = inttoptr i64 %v4387 to ptr
  %ld4389 = load i64, ptr %p4388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4389, ptr %slot707, align 8
  %v4390 = load i64, ptr %slot48, align 8
  %p4391 = inttoptr i64 %v4390 to ptr
  %ld4392 = load i64, ptr %p4391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4392, ptr %slot708, align 8
  %v4393 = load i64, ptr %slot1, align 8
  %v4394 = load i64, ptr %slot707, align 8
  %v4395 = load i64, ptr %slot708, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult710, i64 %v4393, i64 %v4394, i64 %v4395) nomerge, !dbg !142
  %addr4396 = ptrtoint ptr %callresult710 to i64
  store i64 %addr4396, ptr %slot709, align 8
  %v4397 = load i64, ptr %slot709, align 8
  %v4398 = load i64, ptr %slot47, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  store i64 %v4397, ptr %p4399, align 8, !alias.scope !3, !noalias !4
  %v4400 = load i64, ptr %slot47, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  %ld4402 = load i64, ptr %p4401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4402, ptr %slot711, align 8
  %v4403 = load i64, ptr %slot31, align 8
  store i64 %v4403, ptr %slot712, align 8
  %v4404 = load i64, ptr %slot711, align 8
  %v4405 = load i64, ptr %slot712, align 8
  %p4406 = inttoptr i64 %v4404 to ptr
  %p4407 = inttoptr i64 %v4405 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4407, ptr %p4406, i64 24, i1 false)
  %v4408 = load i64, ptr %slot29, align 8
  %p4409 = inttoptr i64 %v4408 to ptr
  store i32 2, ptr %p4409, align 4, !alias.scope !3, !noalias !4
  %v4410 = load i64, ptr %slot28, align 8
  %p4411 = inttoptr i64 %v4410 to ptr
  store i32 1, ptr %p4411, align 4, !alias.scope !3, !noalias !4
  %v4412 = load i64, ptr %slot26, align 8
  %p4413 = inttoptr i64 %v4412 to ptr
  %ld4414 = load i32, ptr %p4413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4414, ptr %slot713, align 8
  %v4415 = load i32, ptr %slot713, align 8
  %cv4416 = zext i32 %v4415 to i64
  %cond4417 = icmp ne i64 %cv4416, 0
  br i1 %cond4417, label %bb_rcslotdrop1223, label %bb_rcslotdone1223
bb_rcslotdrop1223:
  %v4418 = load i64, ptr %slot26, align 8
  %p4419 = inttoptr i64 %v4418 to ptr
  store i32 0, ptr %p4419, align 4, !alias.scope !3, !noalias !4
  %v4420 = load i64, ptr %slot30, align 8
  store i64 %v4420, ptr %slot714, align 8
  %v4421 = load i64, ptr %slot27, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  %ld4423 = load i32, ptr %p4422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4423, ptr %slot715, align 8
  %v4424 = load i32, ptr %slot715, align 8
  %op4425 = and i32 %v4424, 28
  store i32 %op4425, ptr %slot716, align 8
  %v4426 = load i32, ptr %slot716, align 8
  %cv4427 = zext i32 %v4426 to i64
  %cond4428 = icmp ne i64 %cv4427, 0
  br i1 %cond4428, label %bb_rcslotrole1223, label %bb_rcslotowner1223
bb_rcslotrole1223:
  %v4429 = load i64, ptr %slot56, align 8
  store i64 %v4429, ptr %slot717, align 8
  %v4430 = load i64, ptr %slot717, align 8
  %v4431 = load i64, ptr %slot714, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v4430, i64 %v4431) nomerge, !dbg !142
  br label %bb_rcslotdone1223
bb_rcslotowner1223:
  %v4432 = load i64, ptr %slot56, align 8
  store i64 %v4432, ptr %slot718, align 8
  %v4433 = load i64, ptr %slot718, align 8
  %v4434 = load i64, ptr %slot714, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v4433, i64 %v4434) nomerge, !dbg !142
  br label %bb_rcslotdone1223
bb_rcslotdone1223:
  %v4435 = load i64, ptr %slot30, align 8
  store i64 %v4435, ptr %slot719, align 8
  %v4436 = load i64, ptr %slot31, align 8
  store i64 %v4436, ptr %slot720, align 8
  %v4437 = load i64, ptr %slot720, align 8
  %v4438 = load i64, ptr %slot719, align 8
  %p4439 = inttoptr i64 %v4437 to ptr
  %p4440 = inttoptr i64 %v4438 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4440, ptr %p4439, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4441 = load i64, ptr %slot27, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  store i32 2, ptr %p4442, align 4, !alias.scope !3, !noalias !4
  %v4443 = load i64, ptr %slot29, align 8
  %p4444 = inttoptr i64 %v4443 to ptr
  %ld4445 = load i32, ptr %p4444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4445, ptr %slot721, align 8
  %v4446 = load i32, ptr %slot721, align 8
  %v4447 = load i64, ptr %slot27, align 8
  %p4448 = inttoptr i64 %v4447 to ptr
  store i32 %v4446, ptr %p4448, align 4, !alias.scope !3, !noalias !4
  %v4449 = load i64, ptr %slot28, align 8
  %p4450 = inttoptr i64 %v4449 to ptr
  store i32 0, ptr %p4450, align 4, !alias.scope !3, !noalias !4
  %v4451 = load i64, ptr %slot26, align 8
  %p4452 = inttoptr i64 %v4451 to ptr
  store i32 1, ptr %p4452, align 4, !alias.scope !3, !noalias !4
  %v4453 = load i64, ptr %slot719, align 8
  %v4454 = load i64, ptr %slot47, align 8
  %p4455 = inttoptr i64 %v4454 to ptr
  store i64 %v4453, ptr %p4455, align 8, !alias.scope !3, !noalias !4
  %v4456 = load i64, ptr %slot47, align 8
  %p4457 = inttoptr i64 %v4456 to ptr
  %ld4458 = load i64, ptr %p4457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4458, ptr %slot722, align 8
  %v4459 = load i64, ptr %slot722, align 8
  %p4460 = inttoptr i64 %v4459 to ptr
  %ld4461 = load i32, ptr %p4460, align 4, !alias.scope !3, !noalias !4
  %ext4462 = zext i32 %ld4461 to i64
  store i64 %ext4462, ptr %slot723, align 8
  %v4463 = load i64, ptr %slot723, align 8
  %cmp4464 = icmp eq i64 %v4463, 1
  %cv4465 = zext i1 %cmp4464 to i64
  store i64 %cv4465, ptr %slot724, align 8
  %v4466 = load i64, ptr %slot724, align 8
  %cond4467 = icmp ne i64 %v4466, 0
  br i1 %cond4467, label %bb_errtrace1240, label %bb_errtraced1240
bb_errtrace1240:
  %p4468 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p4468, i64 8589934630) "call-inline-cost"="0", !dbg !144
  br label %bb_errtraced1240
bb_errtraced1240:
  %v4469 = load i64, ptr %slot47, align 8
  %p4470 = inttoptr i64 %v4469 to ptr
  %ld4471 = load i64, ptr %p4470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4471, ptr %slot725, align 8
  %v4472 = load i64, ptr %slot31, align 8
  store i64 %v4472, ptr %slot726, align 8
  %v4473 = load i64, ptr %slot57, align 8
  store i64 %v4473, ptr %slot727, align 8
  %v4474 = load i64, ptr %slot56, align 8
  %v4475 = load i64, ptr %slot726, align 8
  %v4476 = load i64, ptr %slot725, align 8
  %v4477 = load i64, ptr %slot727, align 8
  %cv4478 = trunc i64 %v4477 to i32
  %call4479 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v4474, i64 %v4475, i64 %v4476, i32 %cv4478) nomerge, !dbg !144
  store i32 %call4479, ptr %slot728, align 8
  %v4480 = load i32, ptr %slot728, align 8
  %cv4481 = zext i32 %v4480 to i64
  %cond4482 = icmp ne i64 %cv4481, 0
  br i1 %cond4482, label %bb_rcsuccess1245, label %bb_rcfailure1245
bb_rcfailure1245:
  %v4483 = load i64, ptr %slot56, align 8
  %p4484 = inttoptr i64 %v4483 to ptr
  %call4485 = call i32 @myl_rc_take_failure(ptr %p4484) nomerge, !dbg !144
  store i32 %call4485, ptr %slot729, align 8
  %v4486 = load i64, ptr %slot1, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  %v4488 = load i32, ptr %slot729, align 8
  %call4489 = call i32 @myl_qbe_rc_status(ptr %p4487, i32 %v4488) nomerge, !dbg !144
  store i32 %call4489, ptr %slot730, align 8
  br label %bb_failure
bb_rcsuccess1245:
  %v4490 = load i64, ptr %slot26, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  store i32 0, ptr %p4491, align 4, !alias.scope !3, !noalias !4
  %v4492 = load i64, ptr %slot29, align 8
  %p4493 = inttoptr i64 %v4492 to ptr
  store i32 2, ptr %p4493, align 4, !alias.scope !3, !noalias !4
  %v4494 = load i64, ptr %slot28, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  store i32 1, ptr %p4495, align 4, !alias.scope !3, !noalias !4
  %v4496 = load i64, ptr %slot31, align 8
  store i64 %v4496, ptr %slot731, align 8
  %v4497 = load i64, ptr %slot28, align 8
  %p4498 = inttoptr i64 %v4497 to ptr
  store i32 0, ptr %p4498, align 4, !alias.scope !3, !noalias !4
  %v4499 = load i64, ptr %slot26, align 8
  %p4500 = inttoptr i64 %v4499 to ptr
  %ld4501 = load i32, ptr %p4500, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4501, ptr %slot732, align 8
  %v4502 = load i32, ptr %slot732, align 8
  %cv4503 = zext i32 %v4502 to i64
  %cond4504 = icmp ne i64 %cv4503, 0
  br i1 %cond4504, label %bb_rcslotdrop1255, label %bb_rcslotdone1255
bb_rcslotdrop1255:
  %v4505 = load i64, ptr %slot26, align 8
  %p4506 = inttoptr i64 %v4505 to ptr
  store i32 0, ptr %p4506, align 4, !alias.scope !3, !noalias !4
  %v4507 = load i64, ptr %slot30, align 8
  store i64 %v4507, ptr %slot733, align 8
  %v4508 = load i64, ptr %slot27, align 8
  %p4509 = inttoptr i64 %v4508 to ptr
  %ld4510 = load i32, ptr %p4509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4510, ptr %slot734, align 8
  %v4511 = load i32, ptr %slot734, align 8
  %op4512 = and i32 %v4511, 28
  store i32 %op4512, ptr %slot735, align 8
  %v4513 = load i32, ptr %slot735, align 8
  %cv4514 = zext i32 %v4513 to i64
  %cond4515 = icmp ne i64 %cv4514, 0
  br i1 %cond4515, label %bb_rcslotrole1255, label %bb_rcslotowner1255
bb_rcslotrole1255:
  %v4516 = load i64, ptr %slot56, align 8
  store i64 %v4516, ptr %slot736, align 8
  %v4517 = load i64, ptr %slot736, align 8
  %v4518 = load i64, ptr %slot733, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4517, i64 %v4518) nomerge, !dbg !144
  br label %bb_rcslotdone1255
bb_rcslotowner1255:
  %v4519 = load i64, ptr %slot56, align 8
  store i64 %v4519, ptr %slot737, align 8
  %v4520 = load i64, ptr %slot737, align 8
  %v4521 = load i64, ptr %slot733, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4520, i64 %v4521) nomerge, !dbg !144
  br label %bb_rcslotdone1255
bb_rcslotdone1255:
  %v4522 = load i64, ptr %slot24, align 8
  %p4523 = inttoptr i64 %v4522 to ptr
  %ld4524 = load i32, ptr %p4523, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4524, ptr %slot738, align 8
  %v4525 = load i32, ptr %slot738, align 8
  %cv4526 = zext i32 %v4525 to i64
  %cond4527 = icmp ne i64 %cv4526, 0
  br i1 %cond4527, label %bb_rcslotdrop1264, label %bb_rcslotdone1264
bb_rcslotdrop1264:
  %v4528 = load i64, ptr %slot24, align 8
  %p4529 = inttoptr i64 %v4528 to ptr
  store i32 0, ptr %p4529, align 4, !alias.scope !3, !noalias !4
  %v4530 = load i64, ptr %slot46, align 8
  store i64 %v4530, ptr %slot739, align 8
  %v4531 = load i64, ptr %slot25, align 8
  %p4532 = inttoptr i64 %v4531 to ptr
  %ld4533 = load i32, ptr %p4532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4533, ptr %slot740, align 8
  %v4534 = load i32, ptr %slot740, align 8
  %op4535 = and i32 %v4534, 28
  store i32 %op4535, ptr %slot741, align 8
  %v4536 = load i32, ptr %slot741, align 8
  %cv4537 = zext i32 %v4536 to i64
  %cond4538 = icmp ne i64 %cv4537, 0
  br i1 %cond4538, label %bb_rcslotrole1264, label %bb_rcslotowner1264
bb_rcslotrole1264:
  %v4539 = load i64, ptr %slot56, align 8
  store i64 %v4539, ptr %slot742, align 8
  %v4540 = load i64, ptr %slot742, align 8
  %v4541 = load i64, ptr %slot739, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v4540, i64 %v4541) nomerge, !dbg !144
  br label %bb_rcslotdone1264
bb_rcslotowner1264:
  %v4542 = load i64, ptr %slot56, align 8
  store i64 %v4542, ptr %slot743, align 8
  %v4543 = load i64, ptr %slot743, align 8
  %v4544 = load i64, ptr %slot739, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v4543, i64 %v4544) nomerge, !dbg !144
  br label %bb_rcslotdone1264
bb_rcslotdone1264:
  %v4545 = load i64, ptr %slot22, align 8
  %p4546 = inttoptr i64 %v4545 to ptr
  %ld4547 = load i32, ptr %p4546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4547, ptr %slot744, align 8
  %v4548 = load i32, ptr %slot744, align 8
  %cv4549 = zext i32 %v4548 to i64
  %cond4550 = icmp ne i64 %cv4549, 0
  br i1 %cond4550, label %bb_rcslotdrop1273, label %bb_rcslotdone1273
bb_rcslotdrop1273:
  %v4551 = load i64, ptr %slot22, align 8
  %p4552 = inttoptr i64 %v4551 to ptr
  store i32 0, ptr %p4552, align 4, !alias.scope !3, !noalias !4
  %v4553 = load i64, ptr %slot45, align 8
  store i64 %v4553, ptr %slot745, align 8
  %v4554 = load i64, ptr %slot23, align 8
  %p4555 = inttoptr i64 %v4554 to ptr
  %ld4556 = load i32, ptr %p4555, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4556, ptr %slot746, align 8
  %v4557 = load i32, ptr %slot746, align 8
  %op4558 = and i32 %v4557, 28
  store i32 %op4558, ptr %slot747, align 8
  %v4559 = load i32, ptr %slot747, align 8
  %cv4560 = zext i32 %v4559 to i64
  %cond4561 = icmp ne i64 %cv4560, 0
  br i1 %cond4561, label %bb_rcslotrole1273, label %bb_rcslotowner1273
bb_rcslotrole1273:
  %v4562 = load i64, ptr %slot56, align 8
  store i64 %v4562, ptr %slot748, align 8
  %v4563 = load i64, ptr %slot748, align 8
  %v4564 = load i64, ptr %slot745, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v4563, i64 %v4564) nomerge, !dbg !144
  br label %bb_rcslotdone1273
bb_rcslotowner1273:
  %v4565 = load i64, ptr %slot56, align 8
  store i64 %v4565, ptr %slot749, align 8
  %v4566 = load i64, ptr %slot749, align 8
  %v4567 = load i64, ptr %slot745, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v4566, i64 %v4567) nomerge, !dbg !144
  br label %bb_rcslotdone1273
bb_rcslotdone1273:
  %v4568 = load i64, ptr %slot20, align 8
  %p4569 = inttoptr i64 %v4568 to ptr
  %ld4570 = load i32, ptr %p4569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4570, ptr %slot750, align 8
  %v4571 = load i32, ptr %slot750, align 8
  %cv4572 = zext i32 %v4571 to i64
  %cond4573 = icmp ne i64 %cv4572, 0
  br i1 %cond4573, label %bb_rcslotdrop1282, label %bb_rcslotdone1282
bb_rcslotdrop1282:
  %v4574 = load i64, ptr %slot20, align 8
  %p4575 = inttoptr i64 %v4574 to ptr
  store i32 0, ptr %p4575, align 4, !alias.scope !3, !noalias !4
  %v4576 = load i64, ptr %slot44, align 8
  store i64 %v4576, ptr %slot751, align 8
  %v4577 = load i64, ptr %slot21, align 8
  %p4578 = inttoptr i64 %v4577 to ptr
  %ld4579 = load i32, ptr %p4578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4579, ptr %slot752, align 8
  %v4580 = load i32, ptr %slot752, align 8
  %op4581 = and i32 %v4580, 28
  store i32 %op4581, ptr %slot753, align 8
  %v4582 = load i32, ptr %slot753, align 8
  %cv4583 = zext i32 %v4582 to i64
  %cond4584 = icmp ne i64 %cv4583, 0
  br i1 %cond4584, label %bb_rcslotrole1282, label %bb_rcslotowner1282
bb_rcslotrole1282:
  %v4585 = load i64, ptr %slot56, align 8
  store i64 %v4585, ptr %slot754, align 8
  %v4586 = load i64, ptr %slot754, align 8
  %v4587 = load i64, ptr %slot751, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v4586, i64 %v4587) nomerge, !dbg !144
  br label %bb_rcslotdone1282
bb_rcslotowner1282:
  %v4588 = load i64, ptr %slot56, align 8
  store i64 %v4588, ptr %slot755, align 8
  %v4589 = load i64, ptr %slot755, align 8
  %v4590 = load i64, ptr %slot751, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v4589, i64 %v4590) nomerge, !dbg !144
  br label %bb_rcslotdone1282
bb_rcslotdone1282:
  %v4591 = load i64, ptr %slot18, align 8
  %p4592 = inttoptr i64 %v4591 to ptr
  %ld4593 = load i32, ptr %p4592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4593, ptr %slot756, align 8
  %v4594 = load i32, ptr %slot756, align 8
  %cv4595 = zext i32 %v4594 to i64
  %cond4596 = icmp ne i64 %cv4595, 0
  br i1 %cond4596, label %bb_rcslotdrop1291, label %bb_rcslotdone1291
bb_rcslotdrop1291:
  %v4597 = load i64, ptr %slot18, align 8
  %p4598 = inttoptr i64 %v4597 to ptr
  store i32 0, ptr %p4598, align 4, !alias.scope !3, !noalias !4
  %v4599 = load i64, ptr %slot43, align 8
  store i64 %v4599, ptr %slot757, align 8
  %v4600 = load i64, ptr %slot19, align 8
  %p4601 = inttoptr i64 %v4600 to ptr
  %ld4602 = load i32, ptr %p4601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4602, ptr %slot758, align 8
  %v4603 = load i32, ptr %slot758, align 8
  %op4604 = and i32 %v4603, 28
  store i32 %op4604, ptr %slot759, align 8
  %v4605 = load i32, ptr %slot759, align 8
  %cv4606 = zext i32 %v4605 to i64
  %cond4607 = icmp ne i64 %cv4606, 0
  br i1 %cond4607, label %bb_rcslotrole1291, label %bb_rcslotowner1291
bb_rcslotrole1291:
  %v4608 = load i64, ptr %slot56, align 8
  store i64 %v4608, ptr %slot760, align 8
  %v4609 = load i64, ptr %slot760, align 8
  %v4610 = load i64, ptr %slot757, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v4609, i64 %v4610) nomerge, !dbg !144
  br label %bb_rcslotdone1291
bb_rcslotowner1291:
  %v4611 = load i64, ptr %slot56, align 8
  store i64 %v4611, ptr %slot761, align 8
  %v4612 = load i64, ptr %slot761, align 8
  %v4613 = load i64, ptr %slot757, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v4612, i64 %v4613) nomerge, !dbg !144
  br label %bb_rcslotdone1291
bb_rcslotdone1291:
  %v4614 = load i64, ptr %slot16, align 8
  %p4615 = inttoptr i64 %v4614 to ptr
  %ld4616 = load i32, ptr %p4615, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4616, ptr %slot762, align 8
  %v4617 = load i32, ptr %slot762, align 8
  %cv4618 = zext i32 %v4617 to i64
  %cond4619 = icmp ne i64 %cv4618, 0
  br i1 %cond4619, label %bb_rcslotdrop1300, label %bb_rcslotdone1300
bb_rcslotdrop1300:
  %v4620 = load i64, ptr %slot16, align 8
  %p4621 = inttoptr i64 %v4620 to ptr
  store i32 0, ptr %p4621, align 4, !alias.scope !3, !noalias !4
  %v4622 = load i64, ptr %slot42, align 8
  store i64 %v4622, ptr %slot763, align 8
  %v4623 = load i64, ptr %slot17, align 8
  %p4624 = inttoptr i64 %v4623 to ptr
  %ld4625 = load i32, ptr %p4624, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4625, ptr %slot764, align 8
  %v4626 = load i32, ptr %slot764, align 8
  %op4627 = and i32 %v4626, 28
  store i32 %op4627, ptr %slot765, align 8
  %v4628 = load i32, ptr %slot765, align 8
  %cv4629 = zext i32 %v4628 to i64
  %cond4630 = icmp ne i64 %cv4629, 0
  br i1 %cond4630, label %bb_rcslotrole1300, label %bb_rcslotowner1300
bb_rcslotrole1300:
  %v4631 = load i64, ptr %slot56, align 8
  store i64 %v4631, ptr %slot766, align 8
  %v4632 = load i64, ptr %slot766, align 8
  %v4633 = load i64, ptr %slot763, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v4632, i64 %v4633) nomerge, !dbg !144
  br label %bb_rcslotdone1300
bb_rcslotowner1300:
  %v4634 = load i64, ptr %slot56, align 8
  store i64 %v4634, ptr %slot767, align 8
  %v4635 = load i64, ptr %slot767, align 8
  %v4636 = load i64, ptr %slot763, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v4635, i64 %v4636) nomerge, !dbg !144
  br label %bb_rcslotdone1300
bb_rcslotdone1300:
  %v4637 = load i64, ptr %slot14, align 8
  %p4638 = inttoptr i64 %v4637 to ptr
  %ld4639 = load i32, ptr %p4638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4639, ptr %slot768, align 8
  %v4640 = load i32, ptr %slot768, align 8
  %cv4641 = zext i32 %v4640 to i64
  %cond4642 = icmp ne i64 %cv4641, 0
  br i1 %cond4642, label %bb_rcslotdrop1309, label %bb_rcslotdone1309
bb_rcslotdrop1309:
  %v4643 = load i64, ptr %slot14, align 8
  %p4644 = inttoptr i64 %v4643 to ptr
  store i32 0, ptr %p4644, align 4, !alias.scope !3, !noalias !4
  %v4645 = load i64, ptr %slot41, align 8
  store i64 %v4645, ptr %slot769, align 8
  %v4646 = load i64, ptr %slot15, align 8
  %p4647 = inttoptr i64 %v4646 to ptr
  %ld4648 = load i32, ptr %p4647, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4648, ptr %slot770, align 8
  %v4649 = load i32, ptr %slot770, align 8
  %op4650 = and i32 %v4649, 28
  store i32 %op4650, ptr %slot771, align 8
  %v4651 = load i32, ptr %slot771, align 8
  %cv4652 = zext i32 %v4651 to i64
  %cond4653 = icmp ne i64 %cv4652, 0
  br i1 %cond4653, label %bb_rcslotrole1309, label %bb_rcslotowner1309
bb_rcslotrole1309:
  %v4654 = load i64, ptr %slot56, align 8
  store i64 %v4654, ptr %slot772, align 8
  %v4655 = load i64, ptr %slot772, align 8
  %v4656 = load i64, ptr %slot769, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v4655, i64 %v4656) nomerge, !dbg !144
  br label %bb_rcslotdone1309
bb_rcslotowner1309:
  %v4657 = load i64, ptr %slot56, align 8
  store i64 %v4657, ptr %slot773, align 8
  %v4658 = load i64, ptr %slot773, align 8
  %v4659 = load i64, ptr %slot769, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v4658, i64 %v4659) nomerge, !dbg !144
  br label %bb_rcslotdone1309
bb_rcslotdone1309:
  %v4660 = load i64, ptr %slot12, align 8
  %p4661 = inttoptr i64 %v4660 to ptr
  %ld4662 = load i32, ptr %p4661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4662, ptr %slot774, align 8
  %v4663 = load i32, ptr %slot774, align 8
  %cv4664 = zext i32 %v4663 to i64
  %cond4665 = icmp ne i64 %cv4664, 0
  br i1 %cond4665, label %bb_rcslotdrop1318, label %bb_rcslotdone1318
bb_rcslotdrop1318:
  %v4666 = load i64, ptr %slot12, align 8
  %p4667 = inttoptr i64 %v4666 to ptr
  store i32 0, ptr %p4667, align 4, !alias.scope !3, !noalias !4
  %v4668 = load i64, ptr %slot40, align 8
  store i64 %v4668, ptr %slot775, align 8
  %v4669 = load i64, ptr %slot13, align 8
  %p4670 = inttoptr i64 %v4669 to ptr
  %ld4671 = load i32, ptr %p4670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4671, ptr %slot776, align 8
  %v4672 = load i32, ptr %slot776, align 8
  %op4673 = and i32 %v4672, 28
  store i32 %op4673, ptr %slot777, align 8
  %v4674 = load i32, ptr %slot777, align 8
  %cv4675 = zext i32 %v4674 to i64
  %cond4676 = icmp ne i64 %cv4675, 0
  br i1 %cond4676, label %bb_rcslotrole1318, label %bb_rcslotowner1318
bb_rcslotrole1318:
  %v4677 = load i64, ptr %slot56, align 8
  store i64 %v4677, ptr %slot778, align 8
  %v4678 = load i64, ptr %slot778, align 8
  %v4679 = load i64, ptr %slot775, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v4678, i64 %v4679) nomerge, !dbg !144
  br label %bb_rcslotdone1318
bb_rcslotowner1318:
  %v4680 = load i64, ptr %slot56, align 8
  store i64 %v4680, ptr %slot779, align 8
  %v4681 = load i64, ptr %slot779, align 8
  %v4682 = load i64, ptr %slot775, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v4681, i64 %v4682) nomerge, !dbg !144
  br label %bb_rcslotdone1318
bb_rcslotdone1318:
  %v4683 = load i64, ptr %slot10, align 8
  %p4684 = inttoptr i64 %v4683 to ptr
  %ld4685 = load i32, ptr %p4684, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4685, ptr %slot780, align 8
  %v4686 = load i32, ptr %slot780, align 8
  %cv4687 = zext i32 %v4686 to i64
  %cond4688 = icmp ne i64 %cv4687, 0
  br i1 %cond4688, label %bb_rcslotdrop1327, label %bb_rcslotdone1327
bb_rcslotdrop1327:
  %v4689 = load i64, ptr %slot10, align 8
  %p4690 = inttoptr i64 %v4689 to ptr
  store i32 0, ptr %p4690, align 4, !alias.scope !3, !noalias !4
  %v4691 = load i64, ptr %slot38, align 8
  store i64 %v4691, ptr %slot781, align 8
  %v4692 = load i64, ptr %slot11, align 8
  %p4693 = inttoptr i64 %v4692 to ptr
  %ld4694 = load i32, ptr %p4693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4694, ptr %slot782, align 8
  %v4695 = load i32, ptr %slot782, align 8
  %op4696 = and i32 %v4695, 28
  store i32 %op4696, ptr %slot783, align 8
  %v4697 = load i32, ptr %slot783, align 8
  %cv4698 = zext i32 %v4697 to i64
  %cond4699 = icmp ne i64 %cv4698, 0
  br i1 %cond4699, label %bb_rcslotrole1327, label %bb_rcslotowner1327
bb_rcslotrole1327:
  %v4700 = load i64, ptr %slot56, align 8
  store i64 %v4700, ptr %slot784, align 8
  %v4701 = load i64, ptr %slot784, align 8
  %v4702 = load i64, ptr %slot781, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v4701, i64 %v4702) nomerge, !dbg !144
  br label %bb_rcslotdone1327
bb_rcslotowner1327:
  %v4703 = load i64, ptr %slot56, align 8
  store i64 %v4703, ptr %slot785, align 8
  %v4704 = load i64, ptr %slot785, align 8
  %v4705 = load i64, ptr %slot781, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v4704, i64 %v4705) nomerge, !dbg !144
  br label %bb_rcslotdone1327
bb_rcslotdone1327:
  %v4706 = load i64, ptr %slot8, align 8
  %p4707 = inttoptr i64 %v4706 to ptr
  %ld4708 = load i32, ptr %p4707, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4708, ptr %slot786, align 8
  %v4709 = load i32, ptr %slot786, align 8
  %cv4710 = zext i32 %v4709 to i64
  %cond4711 = icmp ne i64 %cv4710, 0
  br i1 %cond4711, label %bb_rcslotdrop1336, label %bb_rcslotdone1336
bb_rcslotdrop1336:
  %v4712 = load i64, ptr %slot8, align 8
  %p4713 = inttoptr i64 %v4712 to ptr
  store i32 0, ptr %p4713, align 4, !alias.scope !3, !noalias !4
  %v4714 = load i64, ptr %slot37, align 8
  store i64 %v4714, ptr %slot787, align 8
  %v4715 = load i64, ptr %slot9, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  %ld4717 = load i32, ptr %p4716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4717, ptr %slot788, align 8
  %v4718 = load i32, ptr %slot788, align 8
  %op4719 = and i32 %v4718, 28
  store i32 %op4719, ptr %slot789, align 8
  %v4720 = load i32, ptr %slot789, align 8
  %cv4721 = zext i32 %v4720 to i64
  %cond4722 = icmp ne i64 %cv4721, 0
  br i1 %cond4722, label %bb_rcslotrole1336, label %bb_rcslotowner1336
bb_rcslotrole1336:
  %v4723 = load i64, ptr %slot56, align 8
  store i64 %v4723, ptr %slot790, align 8
  %v4724 = load i64, ptr %slot790, align 8
  %v4725 = load i64, ptr %slot787, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v4724, i64 %v4725) nomerge, !dbg !144
  br label %bb_rcslotdone1336
bb_rcslotowner1336:
  %v4726 = load i64, ptr %slot56, align 8
  store i64 %v4726, ptr %slot791, align 8
  %v4727 = load i64, ptr %slot791, align 8
  %v4728 = load i64, ptr %slot787, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v4727, i64 %v4728) nomerge, !dbg !144
  br label %bb_rcslotdone1336
bb_rcslotdone1336:
  %v4729 = load i64, ptr %slot6, align 8
  %p4730 = inttoptr i64 %v4729 to ptr
  %ld4731 = load i32, ptr %p4730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4731, ptr %slot792, align 8
  %v4732 = load i32, ptr %slot792, align 8
  %cv4733 = zext i32 %v4732 to i64
  %cond4734 = icmp ne i64 %cv4733, 0
  br i1 %cond4734, label %bb_rcslotdrop1345, label %bb_rcslotdone1345
bb_rcslotdrop1345:
  %v4735 = load i64, ptr %slot6, align 8
  %p4736 = inttoptr i64 %v4735 to ptr
  store i32 0, ptr %p4736, align 4, !alias.scope !3, !noalias !4
  %v4737 = load i64, ptr %slot36, align 8
  store i64 %v4737, ptr %slot793, align 8
  %v4738 = load i64, ptr %slot7, align 8
  %p4739 = inttoptr i64 %v4738 to ptr
  %ld4740 = load i32, ptr %p4739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4740, ptr %slot794, align 8
  %v4741 = load i32, ptr %slot794, align 8
  %op4742 = and i32 %v4741, 28
  store i32 %op4742, ptr %slot795, align 8
  %v4743 = load i32, ptr %slot795, align 8
  %cv4744 = zext i32 %v4743 to i64
  %cond4745 = icmp ne i64 %cv4744, 0
  br i1 %cond4745, label %bb_rcslotrole1345, label %bb_rcslotowner1345
bb_rcslotrole1345:
  %v4746 = load i64, ptr %slot56, align 8
  store i64 %v4746, ptr %slot796, align 8
  %v4747 = load i64, ptr %slot796, align 8
  %v4748 = load i64, ptr %slot793, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v4747, i64 %v4748) nomerge, !dbg !144
  br label %bb_rcslotdone1345
bb_rcslotowner1345:
  %v4749 = load i64, ptr %slot56, align 8
  store i64 %v4749, ptr %slot797, align 8
  %v4750 = load i64, ptr %slot797, align 8
  %v4751 = load i64, ptr %slot793, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v4750, i64 %v4751) nomerge, !dbg !144
  br label %bb_rcslotdone1345
bb_rcslotdone1345:
  %v4752 = load i64, ptr %slot731, align 8
  %p4753 = inttoptr i64 %v4752 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4753, i64 24, i1 false)
  ret void
bb_i39:
  %v4754 = load i64, ptr %slot32, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  %ld4756 = load i64, ptr %p4755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4756, ptr %slot798, align 8
  %v4757 = load i64, ptr %slot798, align 8
  %v4758 = load i64, ptr %slot47, align 8
  %p4759 = inttoptr i64 %v4758 to ptr
  store i64 %v4757, ptr %p4759, align 8, !alias.scope !3, !noalias !4
  %v4760 = load i64, ptr %slot40, align 8
  %v4761 = load i64, ptr %slot48, align 8
  %p4762 = inttoptr i64 %v4761 to ptr
  store i64 %v4760, ptr %p4762, align 8, !alias.scope !3, !noalias !4
  %v4763 = load i64, ptr %slot47, align 8
  %p4764 = inttoptr i64 %v4763 to ptr
  %ld4765 = load i64, ptr %p4764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4765, ptr %slot799, align 8
  %v4766 = load i64, ptr %slot48, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  %ld4768 = load i64, ptr %p4767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4768, ptr %slot800, align 8
  %v4769 = load i64, ptr %slot1, align 8
  %v4770 = load i64, ptr %slot799, align 8
  %v4771 = load i64, ptr %slot800, align 8
  call void @myl_f_00df54ab2bd506d79f963e712b9a3f7789de5e5322e1a9bddad68090e51670b0(ptr sret([24 x i8]) align 8 %callresult802, i64 %v4769, i64 %v4770, i64 %v4771) nomerge, !dbg !146
  %addr4772 = ptrtoint ptr %callresult802 to i64
  store i64 %addr4772, ptr %slot801, align 8
  %v4773 = load i64, ptr %slot801, align 8
  %v4774 = load i64, ptr %slot47, align 8
  %p4775 = inttoptr i64 %v4774 to ptr
  store i64 %v4773, ptr %p4775, align 8, !alias.scope !3, !noalias !4
  %v4776 = load i64, ptr %slot47, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %ld4778 = load i64, ptr %p4777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4778, ptr %slot803, align 8
  %v4779 = load i64, ptr %slot31, align 8
  store i64 %v4779, ptr %slot804, align 8
  %v4780 = load i64, ptr %slot803, align 8
  %v4781 = load i64, ptr %slot804, align 8
  %p4782 = inttoptr i64 %v4780 to ptr
  %p4783 = inttoptr i64 %v4781 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4783, ptr %p4782, i64 24, i1 false)
  %v4784 = load i64, ptr %slot29, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  store i32 2, ptr %p4785, align 4, !alias.scope !3, !noalias !4
  %v4786 = load i64, ptr %slot28, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  store i32 1, ptr %p4787, align 4, !alias.scope !3, !noalias !4
  %v4788 = load i64, ptr %slot26, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  %ld4790 = load i32, ptr %p4789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4790, ptr %slot805, align 8
  %v4791 = load i32, ptr %slot805, align 8
  %cv4792 = zext i32 %v4791 to i64
  %cond4793 = icmp ne i64 %cv4792, 0
  br i1 %cond4793, label %bb_rcslotdrop1408, label %bb_rcslotdone1408
bb_rcslotdrop1408:
  %v4794 = load i64, ptr %slot26, align 8
  %p4795 = inttoptr i64 %v4794 to ptr
  store i32 0, ptr %p4795, align 4, !alias.scope !3, !noalias !4
  %v4796 = load i64, ptr %slot30, align 8
  store i64 %v4796, ptr %slot806, align 8
  %v4797 = load i64, ptr %slot27, align 8
  %p4798 = inttoptr i64 %v4797 to ptr
  %ld4799 = load i32, ptr %p4798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4799, ptr %slot807, align 8
  %v4800 = load i32, ptr %slot807, align 8
  %op4801 = and i32 %v4800, 28
  store i32 %op4801, ptr %slot808, align 8
  %v4802 = load i32, ptr %slot808, align 8
  %cv4803 = zext i32 %v4802 to i64
  %cond4804 = icmp ne i64 %cv4803, 0
  br i1 %cond4804, label %bb_rcslotrole1408, label %bb_rcslotowner1408
bb_rcslotrole1408:
  %v4805 = load i64, ptr %slot56, align 8
  store i64 %v4805, ptr %slot809, align 8
  %v4806 = load i64, ptr %slot809, align 8
  %v4807 = load i64, ptr %slot806, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v4806, i64 %v4807) nomerge, !dbg !146
  br label %bb_rcslotdone1408
bb_rcslotowner1408:
  %v4808 = load i64, ptr %slot56, align 8
  store i64 %v4808, ptr %slot810, align 8
  %v4809 = load i64, ptr %slot810, align 8
  %v4810 = load i64, ptr %slot806, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v4809, i64 %v4810) nomerge, !dbg !146
  br label %bb_rcslotdone1408
bb_rcslotdone1408:
  %v4811 = load i64, ptr %slot30, align 8
  store i64 %v4811, ptr %slot811, align 8
  %v4812 = load i64, ptr %slot31, align 8
  store i64 %v4812, ptr %slot812, align 8
  %v4813 = load i64, ptr %slot812, align 8
  %v4814 = load i64, ptr %slot811, align 8
  %p4815 = inttoptr i64 %v4813 to ptr
  %p4816 = inttoptr i64 %v4814 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4816, ptr %p4815, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4817 = load i64, ptr %slot27, align 8
  %p4818 = inttoptr i64 %v4817 to ptr
  store i32 2, ptr %p4818, align 4, !alias.scope !3, !noalias !4
  %v4819 = load i64, ptr %slot29, align 8
  %p4820 = inttoptr i64 %v4819 to ptr
  %ld4821 = load i32, ptr %p4820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4821, ptr %slot813, align 8
  %v4822 = load i32, ptr %slot813, align 8
  %v4823 = load i64, ptr %slot27, align 8
  %p4824 = inttoptr i64 %v4823 to ptr
  store i32 %v4822, ptr %p4824, align 4, !alias.scope !3, !noalias !4
  %v4825 = load i64, ptr %slot28, align 8
  %p4826 = inttoptr i64 %v4825 to ptr
  store i32 0, ptr %p4826, align 4, !alias.scope !3, !noalias !4
  %v4827 = load i64, ptr %slot26, align 8
  %p4828 = inttoptr i64 %v4827 to ptr
  store i32 1, ptr %p4828, align 4, !alias.scope !3, !noalias !4
  %v4829 = load i64, ptr %slot811, align 8
  %v4830 = load i64, ptr %slot47, align 8
  %p4831 = inttoptr i64 %v4830 to ptr
  store i64 %v4829, ptr %p4831, align 8, !alias.scope !3, !noalias !4
  %v4832 = load i64, ptr %slot47, align 8
  %p4833 = inttoptr i64 %v4832 to ptr
  %ld4834 = load i64, ptr %p4833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4834, ptr %slot814, align 8
  %v4835 = load i64, ptr %slot814, align 8
  %p4836 = inttoptr i64 %v4835 to ptr
  %ld4837 = load i32, ptr %p4836, align 4, !alias.scope !3, !noalias !4
  %ext4838 = zext i32 %ld4837 to i64
  store i64 %ext4838, ptr %slot815, align 8
  %v4839 = load i64, ptr %slot815, align 8
  %cmp4840 = icmp eq i64 %v4839, 1
  %cv4841 = zext i1 %cmp4840 to i64
  store i64 %cv4841, ptr %slot816, align 8
  %v4842 = load i64, ptr %slot816, align 8
  %cond4843 = icmp ne i64 %v4842, 0
  br i1 %cond4843, label %bb_errtrace1434, label %bb_errtraced1434
bb_errtrace1434:
  %p4844 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p4844, i64 8589934634) "call-inline-cost"="0", !dbg !148
  br label %bb_errtraced1434
bb_errtraced1434:
  %v4845 = load i64, ptr %slot47, align 8
  %p4846 = inttoptr i64 %v4845 to ptr
  %ld4847 = load i64, ptr %p4846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4847, ptr %slot817, align 8
  %v4848 = load i64, ptr %slot31, align 8
  store i64 %v4848, ptr %slot818, align 8
  %v4849 = load i64, ptr %slot57, align 8
  store i64 %v4849, ptr %slot819, align 8
  %v4850 = load i64, ptr %slot56, align 8
  %v4851 = load i64, ptr %slot818, align 8
  %v4852 = load i64, ptr %slot817, align 8
  %v4853 = load i64, ptr %slot819, align 8
  %cv4854 = trunc i64 %v4853 to i32
  %call4855 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v4850, i64 %v4851, i64 %v4852, i32 %cv4854) nomerge, !dbg !148
  store i32 %call4855, ptr %slot820, align 8
  %v4856 = load i32, ptr %slot820, align 8
  %cv4857 = zext i32 %v4856 to i64
  %cond4858 = icmp ne i64 %cv4857, 0
  br i1 %cond4858, label %bb_rcsuccess1439, label %bb_rcfailure1439
bb_rcfailure1439:
  %v4859 = load i64, ptr %slot56, align 8
  %p4860 = inttoptr i64 %v4859 to ptr
  %call4861 = call i32 @myl_rc_take_failure(ptr %p4860) nomerge, !dbg !148
  store i32 %call4861, ptr %slot821, align 8
  %v4862 = load i64, ptr %slot1, align 8
  %p4863 = inttoptr i64 %v4862 to ptr
  %v4864 = load i32, ptr %slot821, align 8
  %call4865 = call i32 @myl_qbe_rc_status(ptr %p4863, i32 %v4864) nomerge, !dbg !148
  store i32 %call4865, ptr %slot822, align 8
  br label %bb_failure
bb_rcsuccess1439:
  %v4866 = load i64, ptr %slot26, align 8
  %p4867 = inttoptr i64 %v4866 to ptr
  store i32 0, ptr %p4867, align 4, !alias.scope !3, !noalias !4
  %v4868 = load i64, ptr %slot29, align 8
  %p4869 = inttoptr i64 %v4868 to ptr
  store i32 2, ptr %p4869, align 4, !alias.scope !3, !noalias !4
  %v4870 = load i64, ptr %slot28, align 8
  %p4871 = inttoptr i64 %v4870 to ptr
  store i32 1, ptr %p4871, align 4, !alias.scope !3, !noalias !4
  %v4872 = load i64, ptr %slot31, align 8
  store i64 %v4872, ptr %slot823, align 8
  %v4873 = load i64, ptr %slot28, align 8
  %p4874 = inttoptr i64 %v4873 to ptr
  store i32 0, ptr %p4874, align 4, !alias.scope !3, !noalias !4
  %v4875 = load i64, ptr %slot26, align 8
  %p4876 = inttoptr i64 %v4875 to ptr
  %ld4877 = load i32, ptr %p4876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4877, ptr %slot824, align 8
  %v4878 = load i32, ptr %slot824, align 8
  %cv4879 = zext i32 %v4878 to i64
  %cond4880 = icmp ne i64 %cv4879, 0
  br i1 %cond4880, label %bb_rcslotdrop1449, label %bb_rcslotdone1449
bb_rcslotdrop1449:
  %v4881 = load i64, ptr %slot26, align 8
  %p4882 = inttoptr i64 %v4881 to ptr
  store i32 0, ptr %p4882, align 4, !alias.scope !3, !noalias !4
  %v4883 = load i64, ptr %slot30, align 8
  store i64 %v4883, ptr %slot825, align 8
  %v4884 = load i64, ptr %slot27, align 8
  %p4885 = inttoptr i64 %v4884 to ptr
  %ld4886 = load i32, ptr %p4885, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4886, ptr %slot826, align 8
  %v4887 = load i32, ptr %slot826, align 8
  %op4888 = and i32 %v4887, 28
  store i32 %op4888, ptr %slot827, align 8
  %v4889 = load i32, ptr %slot827, align 8
  %cv4890 = zext i32 %v4889 to i64
  %cond4891 = icmp ne i64 %cv4890, 0
  br i1 %cond4891, label %bb_rcslotrole1449, label %bb_rcslotowner1449
bb_rcslotrole1449:
  %v4892 = load i64, ptr %slot56, align 8
  store i64 %v4892, ptr %slot828, align 8
  %v4893 = load i64, ptr %slot828, align 8
  %v4894 = load i64, ptr %slot825, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v4893, i64 %v4894) nomerge, !dbg !148
  br label %bb_rcslotdone1449
bb_rcslotowner1449:
  %v4895 = load i64, ptr %slot56, align 8
  store i64 %v4895, ptr %slot829, align 8
  %v4896 = load i64, ptr %slot829, align 8
  %v4897 = load i64, ptr %slot825, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v4896, i64 %v4897) nomerge, !dbg !148
  br label %bb_rcslotdone1449
bb_rcslotdone1449:
  %v4898 = load i64, ptr %slot24, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  %ld4900 = load i32, ptr %p4899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4900, ptr %slot830, align 8
  %v4901 = load i32, ptr %slot830, align 8
  %cv4902 = zext i32 %v4901 to i64
  %cond4903 = icmp ne i64 %cv4902, 0
  br i1 %cond4903, label %bb_rcslotdrop1458, label %bb_rcslotdone1458
bb_rcslotdrop1458:
  %v4904 = load i64, ptr %slot24, align 8
  %p4905 = inttoptr i64 %v4904 to ptr
  store i32 0, ptr %p4905, align 4, !alias.scope !3, !noalias !4
  %v4906 = load i64, ptr %slot46, align 8
  store i64 %v4906, ptr %slot831, align 8
  %v4907 = load i64, ptr %slot25, align 8
  %p4908 = inttoptr i64 %v4907 to ptr
  %ld4909 = load i32, ptr %p4908, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4909, ptr %slot832, align 8
  %v4910 = load i32, ptr %slot832, align 8
  %op4911 = and i32 %v4910, 28
  store i32 %op4911, ptr %slot833, align 8
  %v4912 = load i32, ptr %slot833, align 8
  %cv4913 = zext i32 %v4912 to i64
  %cond4914 = icmp ne i64 %cv4913, 0
  br i1 %cond4914, label %bb_rcslotrole1458, label %bb_rcslotowner1458
bb_rcslotrole1458:
  %v4915 = load i64, ptr %slot56, align 8
  store i64 %v4915, ptr %slot834, align 8
  %v4916 = load i64, ptr %slot834, align 8
  %v4917 = load i64, ptr %slot831, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v4916, i64 %v4917) nomerge, !dbg !148
  br label %bb_rcslotdone1458
bb_rcslotowner1458:
  %v4918 = load i64, ptr %slot56, align 8
  store i64 %v4918, ptr %slot835, align 8
  %v4919 = load i64, ptr %slot835, align 8
  %v4920 = load i64, ptr %slot831, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v4919, i64 %v4920) nomerge, !dbg !148
  br label %bb_rcslotdone1458
bb_rcslotdone1458:
  %v4921 = load i64, ptr %slot22, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  %ld4923 = load i32, ptr %p4922, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4923, ptr %slot836, align 8
  %v4924 = load i32, ptr %slot836, align 8
  %cv4925 = zext i32 %v4924 to i64
  %cond4926 = icmp ne i64 %cv4925, 0
  br i1 %cond4926, label %bb_rcslotdrop1467, label %bb_rcslotdone1467
bb_rcslotdrop1467:
  %v4927 = load i64, ptr %slot22, align 8
  %p4928 = inttoptr i64 %v4927 to ptr
  store i32 0, ptr %p4928, align 4, !alias.scope !3, !noalias !4
  %v4929 = load i64, ptr %slot45, align 8
  store i64 %v4929, ptr %slot837, align 8
  %v4930 = load i64, ptr %slot23, align 8
  %p4931 = inttoptr i64 %v4930 to ptr
  %ld4932 = load i32, ptr %p4931, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4932, ptr %slot838, align 8
  %v4933 = load i32, ptr %slot838, align 8
  %op4934 = and i32 %v4933, 28
  store i32 %op4934, ptr %slot839, align 8
  %v4935 = load i32, ptr %slot839, align 8
  %cv4936 = zext i32 %v4935 to i64
  %cond4937 = icmp ne i64 %cv4936, 0
  br i1 %cond4937, label %bb_rcslotrole1467, label %bb_rcslotowner1467
bb_rcslotrole1467:
  %v4938 = load i64, ptr %slot56, align 8
  store i64 %v4938, ptr %slot840, align 8
  %v4939 = load i64, ptr %slot840, align 8
  %v4940 = load i64, ptr %slot837, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v4939, i64 %v4940) nomerge, !dbg !148
  br label %bb_rcslotdone1467
bb_rcslotowner1467:
  %v4941 = load i64, ptr %slot56, align 8
  store i64 %v4941, ptr %slot841, align 8
  %v4942 = load i64, ptr %slot841, align 8
  %v4943 = load i64, ptr %slot837, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v4942, i64 %v4943) nomerge, !dbg !148
  br label %bb_rcslotdone1467
bb_rcslotdone1467:
  %v4944 = load i64, ptr %slot20, align 8
  %p4945 = inttoptr i64 %v4944 to ptr
  %ld4946 = load i32, ptr %p4945, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4946, ptr %slot842, align 8
  %v4947 = load i32, ptr %slot842, align 8
  %cv4948 = zext i32 %v4947 to i64
  %cond4949 = icmp ne i64 %cv4948, 0
  br i1 %cond4949, label %bb_rcslotdrop1476, label %bb_rcslotdone1476
bb_rcslotdrop1476:
  %v4950 = load i64, ptr %slot20, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  store i32 0, ptr %p4951, align 4, !alias.scope !3, !noalias !4
  %v4952 = load i64, ptr %slot44, align 8
  store i64 %v4952, ptr %slot843, align 8
  %v4953 = load i64, ptr %slot21, align 8
  %p4954 = inttoptr i64 %v4953 to ptr
  %ld4955 = load i32, ptr %p4954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4955, ptr %slot844, align 8
  %v4956 = load i32, ptr %slot844, align 8
  %op4957 = and i32 %v4956, 28
  store i32 %op4957, ptr %slot845, align 8
  %v4958 = load i32, ptr %slot845, align 8
  %cv4959 = zext i32 %v4958 to i64
  %cond4960 = icmp ne i64 %cv4959, 0
  br i1 %cond4960, label %bb_rcslotrole1476, label %bb_rcslotowner1476
bb_rcslotrole1476:
  %v4961 = load i64, ptr %slot56, align 8
  store i64 %v4961, ptr %slot846, align 8
  %v4962 = load i64, ptr %slot846, align 8
  %v4963 = load i64, ptr %slot843, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v4962, i64 %v4963) nomerge, !dbg !148
  br label %bb_rcslotdone1476
bb_rcslotowner1476:
  %v4964 = load i64, ptr %slot56, align 8
  store i64 %v4964, ptr %slot847, align 8
  %v4965 = load i64, ptr %slot847, align 8
  %v4966 = load i64, ptr %slot843, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v4965, i64 %v4966) nomerge, !dbg !148
  br label %bb_rcslotdone1476
bb_rcslotdone1476:
  %v4967 = load i64, ptr %slot18, align 8
  %p4968 = inttoptr i64 %v4967 to ptr
  %ld4969 = load i32, ptr %p4968, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4969, ptr %slot848, align 8
  %v4970 = load i32, ptr %slot848, align 8
  %cv4971 = zext i32 %v4970 to i64
  %cond4972 = icmp ne i64 %cv4971, 0
  br i1 %cond4972, label %bb_rcslotdrop1485, label %bb_rcslotdone1485
bb_rcslotdrop1485:
  %v4973 = load i64, ptr %slot18, align 8
  %p4974 = inttoptr i64 %v4973 to ptr
  store i32 0, ptr %p4974, align 4, !alias.scope !3, !noalias !4
  %v4975 = load i64, ptr %slot43, align 8
  store i64 %v4975, ptr %slot849, align 8
  %v4976 = load i64, ptr %slot19, align 8
  %p4977 = inttoptr i64 %v4976 to ptr
  %ld4978 = load i32, ptr %p4977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4978, ptr %slot850, align 8
  %v4979 = load i32, ptr %slot850, align 8
  %op4980 = and i32 %v4979, 28
  store i32 %op4980, ptr %slot851, align 8
  %v4981 = load i32, ptr %slot851, align 8
  %cv4982 = zext i32 %v4981 to i64
  %cond4983 = icmp ne i64 %cv4982, 0
  br i1 %cond4983, label %bb_rcslotrole1485, label %bb_rcslotowner1485
bb_rcslotrole1485:
  %v4984 = load i64, ptr %slot56, align 8
  store i64 %v4984, ptr %slot852, align 8
  %v4985 = load i64, ptr %slot852, align 8
  %v4986 = load i64, ptr %slot849, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v4985, i64 %v4986) nomerge, !dbg !148
  br label %bb_rcslotdone1485
bb_rcslotowner1485:
  %v4987 = load i64, ptr %slot56, align 8
  store i64 %v4987, ptr %slot853, align 8
  %v4988 = load i64, ptr %slot853, align 8
  %v4989 = load i64, ptr %slot849, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v4988, i64 %v4989) nomerge, !dbg !148
  br label %bb_rcslotdone1485
bb_rcslotdone1485:
  %v4990 = load i64, ptr %slot16, align 8
  %p4991 = inttoptr i64 %v4990 to ptr
  %ld4992 = load i32, ptr %p4991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4992, ptr %slot854, align 8
  %v4993 = load i32, ptr %slot854, align 8
  %cv4994 = zext i32 %v4993 to i64
  %cond4995 = icmp ne i64 %cv4994, 0
  br i1 %cond4995, label %bb_rcslotdrop1494, label %bb_rcslotdone1494
bb_rcslotdrop1494:
  %v4996 = load i64, ptr %slot16, align 8
  %p4997 = inttoptr i64 %v4996 to ptr
  store i32 0, ptr %p4997, align 4, !alias.scope !3, !noalias !4
  %v4998 = load i64, ptr %slot42, align 8
  store i64 %v4998, ptr %slot855, align 8
  %v4999 = load i64, ptr %slot17, align 8
  %p5000 = inttoptr i64 %v4999 to ptr
  %ld5001 = load i32, ptr %p5000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5001, ptr %slot856, align 8
  %v5002 = load i32, ptr %slot856, align 8
  %op5003 = and i32 %v5002, 28
  store i32 %op5003, ptr %slot857, align 8
  %v5004 = load i32, ptr %slot857, align 8
  %cv5005 = zext i32 %v5004 to i64
  %cond5006 = icmp ne i64 %cv5005, 0
  br i1 %cond5006, label %bb_rcslotrole1494, label %bb_rcslotowner1494
bb_rcslotrole1494:
  %v5007 = load i64, ptr %slot56, align 8
  store i64 %v5007, ptr %slot858, align 8
  %v5008 = load i64, ptr %slot858, align 8
  %v5009 = load i64, ptr %slot855, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v5008, i64 %v5009) nomerge, !dbg !148
  br label %bb_rcslotdone1494
bb_rcslotowner1494:
  %v5010 = load i64, ptr %slot56, align 8
  store i64 %v5010, ptr %slot859, align 8
  %v5011 = load i64, ptr %slot859, align 8
  %v5012 = load i64, ptr %slot855, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v5011, i64 %v5012) nomerge, !dbg !148
  br label %bb_rcslotdone1494
bb_rcslotdone1494:
  %v5013 = load i64, ptr %slot14, align 8
  %p5014 = inttoptr i64 %v5013 to ptr
  %ld5015 = load i32, ptr %p5014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5015, ptr %slot860, align 8
  %v5016 = load i32, ptr %slot860, align 8
  %cv5017 = zext i32 %v5016 to i64
  %cond5018 = icmp ne i64 %cv5017, 0
  br i1 %cond5018, label %bb_rcslotdrop1503, label %bb_rcslotdone1503
bb_rcslotdrop1503:
  %v5019 = load i64, ptr %slot14, align 8
  %p5020 = inttoptr i64 %v5019 to ptr
  store i32 0, ptr %p5020, align 4, !alias.scope !3, !noalias !4
  %v5021 = load i64, ptr %slot41, align 8
  store i64 %v5021, ptr %slot861, align 8
  %v5022 = load i64, ptr %slot15, align 8
  %p5023 = inttoptr i64 %v5022 to ptr
  %ld5024 = load i32, ptr %p5023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5024, ptr %slot862, align 8
  %v5025 = load i32, ptr %slot862, align 8
  %op5026 = and i32 %v5025, 28
  store i32 %op5026, ptr %slot863, align 8
  %v5027 = load i32, ptr %slot863, align 8
  %cv5028 = zext i32 %v5027 to i64
  %cond5029 = icmp ne i64 %cv5028, 0
  br i1 %cond5029, label %bb_rcslotrole1503, label %bb_rcslotowner1503
bb_rcslotrole1503:
  %v5030 = load i64, ptr %slot56, align 8
  store i64 %v5030, ptr %slot864, align 8
  %v5031 = load i64, ptr %slot864, align 8
  %v5032 = load i64, ptr %slot861, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v5031, i64 %v5032) nomerge, !dbg !148
  br label %bb_rcslotdone1503
bb_rcslotowner1503:
  %v5033 = load i64, ptr %slot56, align 8
  store i64 %v5033, ptr %slot865, align 8
  %v5034 = load i64, ptr %slot865, align 8
  %v5035 = load i64, ptr %slot861, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v5034, i64 %v5035) nomerge, !dbg !148
  br label %bb_rcslotdone1503
bb_rcslotdone1503:
  %v5036 = load i64, ptr %slot12, align 8
  %p5037 = inttoptr i64 %v5036 to ptr
  %ld5038 = load i32, ptr %p5037, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5038, ptr %slot866, align 8
  %v5039 = load i32, ptr %slot866, align 8
  %cv5040 = zext i32 %v5039 to i64
  %cond5041 = icmp ne i64 %cv5040, 0
  br i1 %cond5041, label %bb_rcslotdrop1512, label %bb_rcslotdone1512
bb_rcslotdrop1512:
  %v5042 = load i64, ptr %slot12, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  store i32 0, ptr %p5043, align 4, !alias.scope !3, !noalias !4
  %v5044 = load i64, ptr %slot40, align 8
  store i64 %v5044, ptr %slot867, align 8
  %v5045 = load i64, ptr %slot13, align 8
  %p5046 = inttoptr i64 %v5045 to ptr
  %ld5047 = load i32, ptr %p5046, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5047, ptr %slot868, align 8
  %v5048 = load i32, ptr %slot868, align 8
  %op5049 = and i32 %v5048, 28
  store i32 %op5049, ptr %slot869, align 8
  %v5050 = load i32, ptr %slot869, align 8
  %cv5051 = zext i32 %v5050 to i64
  %cond5052 = icmp ne i64 %cv5051, 0
  br i1 %cond5052, label %bb_rcslotrole1512, label %bb_rcslotowner1512
bb_rcslotrole1512:
  %v5053 = load i64, ptr %slot56, align 8
  store i64 %v5053, ptr %slot870, align 8
  %v5054 = load i64, ptr %slot870, align 8
  %v5055 = load i64, ptr %slot867, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v5054, i64 %v5055) nomerge, !dbg !148
  br label %bb_rcslotdone1512
bb_rcslotowner1512:
  %v5056 = load i64, ptr %slot56, align 8
  store i64 %v5056, ptr %slot871, align 8
  %v5057 = load i64, ptr %slot871, align 8
  %v5058 = load i64, ptr %slot867, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v5057, i64 %v5058) nomerge, !dbg !148
  br label %bb_rcslotdone1512
bb_rcslotdone1512:
  %v5059 = load i64, ptr %slot10, align 8
  %p5060 = inttoptr i64 %v5059 to ptr
  %ld5061 = load i32, ptr %p5060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5061, ptr %slot872, align 8
  %v5062 = load i32, ptr %slot872, align 8
  %cv5063 = zext i32 %v5062 to i64
  %cond5064 = icmp ne i64 %cv5063, 0
  br i1 %cond5064, label %bb_rcslotdrop1521, label %bb_rcslotdone1521
bb_rcslotdrop1521:
  %v5065 = load i64, ptr %slot10, align 8
  %p5066 = inttoptr i64 %v5065 to ptr
  store i32 0, ptr %p5066, align 4, !alias.scope !3, !noalias !4
  %v5067 = load i64, ptr %slot38, align 8
  store i64 %v5067, ptr %slot873, align 8
  %v5068 = load i64, ptr %slot11, align 8
  %p5069 = inttoptr i64 %v5068 to ptr
  %ld5070 = load i32, ptr %p5069, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5070, ptr %slot874, align 8
  %v5071 = load i32, ptr %slot874, align 8
  %op5072 = and i32 %v5071, 28
  store i32 %op5072, ptr %slot875, align 8
  %v5073 = load i32, ptr %slot875, align 8
  %cv5074 = zext i32 %v5073 to i64
  %cond5075 = icmp ne i64 %cv5074, 0
  br i1 %cond5075, label %bb_rcslotrole1521, label %bb_rcslotowner1521
bb_rcslotrole1521:
  %v5076 = load i64, ptr %slot56, align 8
  store i64 %v5076, ptr %slot876, align 8
  %v5077 = load i64, ptr %slot876, align 8
  %v5078 = load i64, ptr %slot873, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v5077, i64 %v5078) nomerge, !dbg !148
  br label %bb_rcslotdone1521
bb_rcslotowner1521:
  %v5079 = load i64, ptr %slot56, align 8
  store i64 %v5079, ptr %slot877, align 8
  %v5080 = load i64, ptr %slot877, align 8
  %v5081 = load i64, ptr %slot873, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v5080, i64 %v5081) nomerge, !dbg !148
  br label %bb_rcslotdone1521
bb_rcslotdone1521:
  %v5082 = load i64, ptr %slot8, align 8
  %p5083 = inttoptr i64 %v5082 to ptr
  %ld5084 = load i32, ptr %p5083, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5084, ptr %slot878, align 8
  %v5085 = load i32, ptr %slot878, align 8
  %cv5086 = zext i32 %v5085 to i64
  %cond5087 = icmp ne i64 %cv5086, 0
  br i1 %cond5087, label %bb_rcslotdrop1530, label %bb_rcslotdone1530
bb_rcslotdrop1530:
  %v5088 = load i64, ptr %slot8, align 8
  %p5089 = inttoptr i64 %v5088 to ptr
  store i32 0, ptr %p5089, align 4, !alias.scope !3, !noalias !4
  %v5090 = load i64, ptr %slot37, align 8
  store i64 %v5090, ptr %slot879, align 8
  %v5091 = load i64, ptr %slot9, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  %ld5093 = load i32, ptr %p5092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5093, ptr %slot880, align 8
  %v5094 = load i32, ptr %slot880, align 8
  %op5095 = and i32 %v5094, 28
  store i32 %op5095, ptr %slot881, align 8
  %v5096 = load i32, ptr %slot881, align 8
  %cv5097 = zext i32 %v5096 to i64
  %cond5098 = icmp ne i64 %cv5097, 0
  br i1 %cond5098, label %bb_rcslotrole1530, label %bb_rcslotowner1530
bb_rcslotrole1530:
  %v5099 = load i64, ptr %slot56, align 8
  store i64 %v5099, ptr %slot882, align 8
  %v5100 = load i64, ptr %slot882, align 8
  %v5101 = load i64, ptr %slot879, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v5100, i64 %v5101) nomerge, !dbg !148
  br label %bb_rcslotdone1530
bb_rcslotowner1530:
  %v5102 = load i64, ptr %slot56, align 8
  store i64 %v5102, ptr %slot883, align 8
  %v5103 = load i64, ptr %slot883, align 8
  %v5104 = load i64, ptr %slot879, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v5103, i64 %v5104) nomerge, !dbg !148
  br label %bb_rcslotdone1530
bb_rcslotdone1530:
  %v5105 = load i64, ptr %slot6, align 8
  %p5106 = inttoptr i64 %v5105 to ptr
  %ld5107 = load i32, ptr %p5106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5107, ptr %slot884, align 8
  %v5108 = load i32, ptr %slot884, align 8
  %cv5109 = zext i32 %v5108 to i64
  %cond5110 = icmp ne i64 %cv5109, 0
  br i1 %cond5110, label %bb_rcslotdrop1539, label %bb_rcslotdone1539
bb_rcslotdrop1539:
  %v5111 = load i64, ptr %slot6, align 8
  %p5112 = inttoptr i64 %v5111 to ptr
  store i32 0, ptr %p5112, align 4, !alias.scope !3, !noalias !4
  %v5113 = load i64, ptr %slot36, align 8
  store i64 %v5113, ptr %slot885, align 8
  %v5114 = load i64, ptr %slot7, align 8
  %p5115 = inttoptr i64 %v5114 to ptr
  %ld5116 = load i32, ptr %p5115, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5116, ptr %slot886, align 8
  %v5117 = load i32, ptr %slot886, align 8
  %op5118 = and i32 %v5117, 28
  store i32 %op5118, ptr %slot887, align 8
  %v5119 = load i32, ptr %slot887, align 8
  %cv5120 = zext i32 %v5119 to i64
  %cond5121 = icmp ne i64 %cv5120, 0
  br i1 %cond5121, label %bb_rcslotrole1539, label %bb_rcslotowner1539
bb_rcslotrole1539:
  %v5122 = load i64, ptr %slot56, align 8
  store i64 %v5122, ptr %slot888, align 8
  %v5123 = load i64, ptr %slot888, align 8
  %v5124 = load i64, ptr %slot885, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v5123, i64 %v5124) nomerge, !dbg !148
  br label %bb_rcslotdone1539
bb_rcslotowner1539:
  %v5125 = load i64, ptr %slot56, align 8
  store i64 %v5125, ptr %slot889, align 8
  %v5126 = load i64, ptr %slot889, align 8
  %v5127 = load i64, ptr %slot885, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v5126, i64 %v5127) nomerge, !dbg !148
  br label %bb_rcslotdone1539
bb_rcslotdone1539:
  %v5128 = load i64, ptr %slot823, align 8
  %p5129 = inttoptr i64 %v5128 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5129, i64 24, i1 false)
  ret void
bb_i43:
  %v5130 = load i64, ptr %slot32, align 8
  %p5131 = inttoptr i64 %v5130 to ptr
  %ld5132 = load i64, ptr %p5131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5132, ptr %slot890, align 8
  %v5133 = load i64, ptr %slot890, align 8
  %v5134 = load i64, ptr %slot47, align 8
  %p5135 = inttoptr i64 %v5134 to ptr
  store i64 %v5133, ptr %p5135, align 8, !alias.scope !3, !noalias !4
  %v5136 = load i64, ptr %slot41, align 8
  %v5137 = load i64, ptr %slot48, align 8
  %p5138 = inttoptr i64 %v5137 to ptr
  store i64 %v5136, ptr %p5138, align 8, !alias.scope !3, !noalias !4
  %v5139 = load i64, ptr %slot47, align 8
  %p5140 = inttoptr i64 %v5139 to ptr
  %ld5141 = load i64, ptr %p5140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5141, ptr %slot891, align 8
  %v5142 = load i64, ptr %slot48, align 8
  %p5143 = inttoptr i64 %v5142 to ptr
  %ld5144 = load i64, ptr %p5143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5144, ptr %slot892, align 8
  %v5145 = load i64, ptr %slot1, align 8
  %v5146 = load i64, ptr %slot891, align 8
  %v5147 = load i64, ptr %slot892, align 8
  call void @myl_f_efefaf187dbda74c0fc83883b6acb4fd651afe0399c3994d07d1373d88b055ca(ptr sret([24 x i8]) align 8 %callresult894, i64 %v5145, i64 %v5146, i64 %v5147) nomerge, !dbg !150
  %addr5148 = ptrtoint ptr %callresult894 to i64
  store i64 %addr5148, ptr %slot893, align 8
  %v5149 = load i64, ptr %slot893, align 8
  %v5150 = load i64, ptr %slot47, align 8
  %p5151 = inttoptr i64 %v5150 to ptr
  store i64 %v5149, ptr %p5151, align 8, !alias.scope !3, !noalias !4
  %v5152 = load i64, ptr %slot47, align 8
  %p5153 = inttoptr i64 %v5152 to ptr
  %ld5154 = load i64, ptr %p5153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5154, ptr %slot895, align 8
  %v5155 = load i64, ptr %slot31, align 8
  store i64 %v5155, ptr %slot896, align 8
  %v5156 = load i64, ptr %slot895, align 8
  %v5157 = load i64, ptr %slot896, align 8
  %p5158 = inttoptr i64 %v5156 to ptr
  %p5159 = inttoptr i64 %v5157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5159, ptr %p5158, i64 24, i1 false)
  %v5160 = load i64, ptr %slot29, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  store i32 2, ptr %p5161, align 4, !alias.scope !3, !noalias !4
  %v5162 = load i64, ptr %slot28, align 8
  %p5163 = inttoptr i64 %v5162 to ptr
  store i32 1, ptr %p5163, align 4, !alias.scope !3, !noalias !4
  %v5164 = load i64, ptr %slot26, align 8
  %p5165 = inttoptr i64 %v5164 to ptr
  %ld5166 = load i32, ptr %p5165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5166, ptr %slot897, align 8
  %v5167 = load i32, ptr %slot897, align 8
  %cv5168 = zext i32 %v5167 to i64
  %cond5169 = icmp ne i64 %cv5168, 0
  br i1 %cond5169, label %bb_rcslotdrop1602, label %bb_rcslotdone1602
bb_rcslotdrop1602:
  %v5170 = load i64, ptr %slot26, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  store i32 0, ptr %p5171, align 4, !alias.scope !3, !noalias !4
  %v5172 = load i64, ptr %slot30, align 8
  store i64 %v5172, ptr %slot898, align 8
  %v5173 = load i64, ptr %slot27, align 8
  %p5174 = inttoptr i64 %v5173 to ptr
  %ld5175 = load i32, ptr %p5174, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5175, ptr %slot899, align 8
  %v5176 = load i32, ptr %slot899, align 8
  %op5177 = and i32 %v5176, 28
  store i32 %op5177, ptr %slot900, align 8
  %v5178 = load i32, ptr %slot900, align 8
  %cv5179 = zext i32 %v5178 to i64
  %cond5180 = icmp ne i64 %cv5179, 0
  br i1 %cond5180, label %bb_rcslotrole1602, label %bb_rcslotowner1602
bb_rcslotrole1602:
  %v5181 = load i64, ptr %slot56, align 8
  store i64 %v5181, ptr %slot901, align 8
  %v5182 = load i64, ptr %slot901, align 8
  %v5183 = load i64, ptr %slot898, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v5182, i64 %v5183) nomerge, !dbg !150
  br label %bb_rcslotdone1602
bb_rcslotowner1602:
  %v5184 = load i64, ptr %slot56, align 8
  store i64 %v5184, ptr %slot902, align 8
  %v5185 = load i64, ptr %slot902, align 8
  %v5186 = load i64, ptr %slot898, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v5185, i64 %v5186) nomerge, !dbg !150
  br label %bb_rcslotdone1602
bb_rcslotdone1602:
  %v5187 = load i64, ptr %slot30, align 8
  store i64 %v5187, ptr %slot903, align 8
  %v5188 = load i64, ptr %slot31, align 8
  store i64 %v5188, ptr %slot904, align 8
  %v5189 = load i64, ptr %slot904, align 8
  %v5190 = load i64, ptr %slot903, align 8
  %p5191 = inttoptr i64 %v5189 to ptr
  %p5192 = inttoptr i64 %v5190 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5192, ptr %p5191, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5193 = load i64, ptr %slot27, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  store i32 2, ptr %p5194, align 4, !alias.scope !3, !noalias !4
  %v5195 = load i64, ptr %slot29, align 8
  %p5196 = inttoptr i64 %v5195 to ptr
  %ld5197 = load i32, ptr %p5196, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5197, ptr %slot905, align 8
  %v5198 = load i32, ptr %slot905, align 8
  %v5199 = load i64, ptr %slot27, align 8
  %p5200 = inttoptr i64 %v5199 to ptr
  store i32 %v5198, ptr %p5200, align 4, !alias.scope !3, !noalias !4
  %v5201 = load i64, ptr %slot28, align 8
  %p5202 = inttoptr i64 %v5201 to ptr
  store i32 0, ptr %p5202, align 4, !alias.scope !3, !noalias !4
  %v5203 = load i64, ptr %slot26, align 8
  %p5204 = inttoptr i64 %v5203 to ptr
  store i32 1, ptr %p5204, align 4, !alias.scope !3, !noalias !4
  %v5205 = load i64, ptr %slot903, align 8
  %v5206 = load i64, ptr %slot47, align 8
  %p5207 = inttoptr i64 %v5206 to ptr
  store i64 %v5205, ptr %p5207, align 8, !alias.scope !3, !noalias !4
  %v5208 = load i64, ptr %slot47, align 8
  %p5209 = inttoptr i64 %v5208 to ptr
  %ld5210 = load i64, ptr %p5209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5210, ptr %slot906, align 8
  %v5211 = load i64, ptr %slot906, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  %ld5213 = load i32, ptr %p5212, align 4, !alias.scope !3, !noalias !4
  %ext5214 = zext i32 %ld5213 to i64
  store i64 %ext5214, ptr %slot907, align 8
  %v5215 = load i64, ptr %slot907, align 8
  %cmp5216 = icmp eq i64 %v5215, 1
  %cv5217 = zext i1 %cmp5216 to i64
  store i64 %cv5217, ptr %slot908, align 8
  %v5218 = load i64, ptr %slot908, align 8
  %cond5219 = icmp ne i64 %v5218, 0
  br i1 %cond5219, label %bb_errtrace1628, label %bb_errtraced1628
bb_errtrace1628:
  %p5220 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p5220, i64 8589934638) "call-inline-cost"="0", !dbg !152
  br label %bb_errtraced1628
bb_errtraced1628:
  %v5221 = load i64, ptr %slot47, align 8
  %p5222 = inttoptr i64 %v5221 to ptr
  %ld5223 = load i64, ptr %p5222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5223, ptr %slot909, align 8
  %v5224 = load i64, ptr %slot31, align 8
  store i64 %v5224, ptr %slot910, align 8
  %v5225 = load i64, ptr %slot57, align 8
  store i64 %v5225, ptr %slot911, align 8
  %v5226 = load i64, ptr %slot56, align 8
  %v5227 = load i64, ptr %slot910, align 8
  %v5228 = load i64, ptr %slot909, align 8
  %v5229 = load i64, ptr %slot911, align 8
  %cv5230 = trunc i64 %v5229 to i32
  %call5231 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v5226, i64 %v5227, i64 %v5228, i32 %cv5230) nomerge, !dbg !152
  store i32 %call5231, ptr %slot912, align 8
  %v5232 = load i32, ptr %slot912, align 8
  %cv5233 = zext i32 %v5232 to i64
  %cond5234 = icmp ne i64 %cv5233, 0
  br i1 %cond5234, label %bb_rcsuccess1633, label %bb_rcfailure1633
bb_rcfailure1633:
  %v5235 = load i64, ptr %slot56, align 8
  %p5236 = inttoptr i64 %v5235 to ptr
  %call5237 = call i32 @myl_rc_take_failure(ptr %p5236) nomerge, !dbg !152
  store i32 %call5237, ptr %slot913, align 8
  %v5238 = load i64, ptr %slot1, align 8
  %p5239 = inttoptr i64 %v5238 to ptr
  %v5240 = load i32, ptr %slot913, align 8
  %call5241 = call i32 @myl_qbe_rc_status(ptr %p5239, i32 %v5240) nomerge, !dbg !152
  store i32 %call5241, ptr %slot914, align 8
  br label %bb_failure
bb_rcsuccess1633:
  %v5242 = load i64, ptr %slot26, align 8
  %p5243 = inttoptr i64 %v5242 to ptr
  store i32 0, ptr %p5243, align 4, !alias.scope !3, !noalias !4
  %v5244 = load i64, ptr %slot29, align 8
  %p5245 = inttoptr i64 %v5244 to ptr
  store i32 2, ptr %p5245, align 4, !alias.scope !3, !noalias !4
  %v5246 = load i64, ptr %slot28, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  store i32 1, ptr %p5247, align 4, !alias.scope !3, !noalias !4
  %v5248 = load i64, ptr %slot31, align 8
  store i64 %v5248, ptr %slot915, align 8
  %v5249 = load i64, ptr %slot28, align 8
  %p5250 = inttoptr i64 %v5249 to ptr
  store i32 0, ptr %p5250, align 4, !alias.scope !3, !noalias !4
  %v5251 = load i64, ptr %slot26, align 8
  %p5252 = inttoptr i64 %v5251 to ptr
  %ld5253 = load i32, ptr %p5252, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5253, ptr %slot916, align 8
  %v5254 = load i32, ptr %slot916, align 8
  %cv5255 = zext i32 %v5254 to i64
  %cond5256 = icmp ne i64 %cv5255, 0
  br i1 %cond5256, label %bb_rcslotdrop1643, label %bb_rcslotdone1643
bb_rcslotdrop1643:
  %v5257 = load i64, ptr %slot26, align 8
  %p5258 = inttoptr i64 %v5257 to ptr
  store i32 0, ptr %p5258, align 4, !alias.scope !3, !noalias !4
  %v5259 = load i64, ptr %slot30, align 8
  store i64 %v5259, ptr %slot917, align 8
  %v5260 = load i64, ptr %slot27, align 8
  %p5261 = inttoptr i64 %v5260 to ptr
  %ld5262 = load i32, ptr %p5261, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5262, ptr %slot918, align 8
  %v5263 = load i32, ptr %slot918, align 8
  %op5264 = and i32 %v5263, 28
  store i32 %op5264, ptr %slot919, align 8
  %v5265 = load i32, ptr %slot919, align 8
  %cv5266 = zext i32 %v5265 to i64
  %cond5267 = icmp ne i64 %cv5266, 0
  br i1 %cond5267, label %bb_rcslotrole1643, label %bb_rcslotowner1643
bb_rcslotrole1643:
  %v5268 = load i64, ptr %slot56, align 8
  store i64 %v5268, ptr %slot920, align 8
  %v5269 = load i64, ptr %slot920, align 8
  %v5270 = load i64, ptr %slot917, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v5269, i64 %v5270) nomerge, !dbg !152
  br label %bb_rcslotdone1643
bb_rcslotowner1643:
  %v5271 = load i64, ptr %slot56, align 8
  store i64 %v5271, ptr %slot921, align 8
  %v5272 = load i64, ptr %slot921, align 8
  %v5273 = load i64, ptr %slot917, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v5272, i64 %v5273) nomerge, !dbg !152
  br label %bb_rcslotdone1643
bb_rcslotdone1643:
  %v5274 = load i64, ptr %slot24, align 8
  %p5275 = inttoptr i64 %v5274 to ptr
  %ld5276 = load i32, ptr %p5275, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5276, ptr %slot922, align 8
  %v5277 = load i32, ptr %slot922, align 8
  %cv5278 = zext i32 %v5277 to i64
  %cond5279 = icmp ne i64 %cv5278, 0
  br i1 %cond5279, label %bb_rcslotdrop1652, label %bb_rcslotdone1652
bb_rcslotdrop1652:
  %v5280 = load i64, ptr %slot24, align 8
  %p5281 = inttoptr i64 %v5280 to ptr
  store i32 0, ptr %p5281, align 4, !alias.scope !3, !noalias !4
  %v5282 = load i64, ptr %slot46, align 8
  store i64 %v5282, ptr %slot923, align 8
  %v5283 = load i64, ptr %slot25, align 8
  %p5284 = inttoptr i64 %v5283 to ptr
  %ld5285 = load i32, ptr %p5284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5285, ptr %slot924, align 8
  %v5286 = load i32, ptr %slot924, align 8
  %op5287 = and i32 %v5286, 28
  store i32 %op5287, ptr %slot925, align 8
  %v5288 = load i32, ptr %slot925, align 8
  %cv5289 = zext i32 %v5288 to i64
  %cond5290 = icmp ne i64 %cv5289, 0
  br i1 %cond5290, label %bb_rcslotrole1652, label %bb_rcslotowner1652
bb_rcslotrole1652:
  %v5291 = load i64, ptr %slot56, align 8
  store i64 %v5291, ptr %slot926, align 8
  %v5292 = load i64, ptr %slot926, align 8
  %v5293 = load i64, ptr %slot923, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v5292, i64 %v5293) nomerge, !dbg !152
  br label %bb_rcslotdone1652
bb_rcslotowner1652:
  %v5294 = load i64, ptr %slot56, align 8
  store i64 %v5294, ptr %slot927, align 8
  %v5295 = load i64, ptr %slot927, align 8
  %v5296 = load i64, ptr %slot923, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v5295, i64 %v5296) nomerge, !dbg !152
  br label %bb_rcslotdone1652
bb_rcslotdone1652:
  %v5297 = load i64, ptr %slot22, align 8
  %p5298 = inttoptr i64 %v5297 to ptr
  %ld5299 = load i32, ptr %p5298, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5299, ptr %slot928, align 8
  %v5300 = load i32, ptr %slot928, align 8
  %cv5301 = zext i32 %v5300 to i64
  %cond5302 = icmp ne i64 %cv5301, 0
  br i1 %cond5302, label %bb_rcslotdrop1661, label %bb_rcslotdone1661
bb_rcslotdrop1661:
  %v5303 = load i64, ptr %slot22, align 8
  %p5304 = inttoptr i64 %v5303 to ptr
  store i32 0, ptr %p5304, align 4, !alias.scope !3, !noalias !4
  %v5305 = load i64, ptr %slot45, align 8
  store i64 %v5305, ptr %slot929, align 8
  %v5306 = load i64, ptr %slot23, align 8
  %p5307 = inttoptr i64 %v5306 to ptr
  %ld5308 = load i32, ptr %p5307, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5308, ptr %slot930, align 8
  %v5309 = load i32, ptr %slot930, align 8
  %op5310 = and i32 %v5309, 28
  store i32 %op5310, ptr %slot931, align 8
  %v5311 = load i32, ptr %slot931, align 8
  %cv5312 = zext i32 %v5311 to i64
  %cond5313 = icmp ne i64 %cv5312, 0
  br i1 %cond5313, label %bb_rcslotrole1661, label %bb_rcslotowner1661
bb_rcslotrole1661:
  %v5314 = load i64, ptr %slot56, align 8
  store i64 %v5314, ptr %slot932, align 8
  %v5315 = load i64, ptr %slot932, align 8
  %v5316 = load i64, ptr %slot929, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v5315, i64 %v5316) nomerge, !dbg !152
  br label %bb_rcslotdone1661
bb_rcslotowner1661:
  %v5317 = load i64, ptr %slot56, align 8
  store i64 %v5317, ptr %slot933, align 8
  %v5318 = load i64, ptr %slot933, align 8
  %v5319 = load i64, ptr %slot929, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v5318, i64 %v5319) nomerge, !dbg !152
  br label %bb_rcslotdone1661
bb_rcslotdone1661:
  %v5320 = load i64, ptr %slot20, align 8
  %p5321 = inttoptr i64 %v5320 to ptr
  %ld5322 = load i32, ptr %p5321, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5322, ptr %slot934, align 8
  %v5323 = load i32, ptr %slot934, align 8
  %cv5324 = zext i32 %v5323 to i64
  %cond5325 = icmp ne i64 %cv5324, 0
  br i1 %cond5325, label %bb_rcslotdrop1670, label %bb_rcslotdone1670
bb_rcslotdrop1670:
  %v5326 = load i64, ptr %slot20, align 8
  %p5327 = inttoptr i64 %v5326 to ptr
  store i32 0, ptr %p5327, align 4, !alias.scope !3, !noalias !4
  %v5328 = load i64, ptr %slot44, align 8
  store i64 %v5328, ptr %slot935, align 8
  %v5329 = load i64, ptr %slot21, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  %ld5331 = load i32, ptr %p5330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5331, ptr %slot936, align 8
  %v5332 = load i32, ptr %slot936, align 8
  %op5333 = and i32 %v5332, 28
  store i32 %op5333, ptr %slot937, align 8
  %v5334 = load i32, ptr %slot937, align 8
  %cv5335 = zext i32 %v5334 to i64
  %cond5336 = icmp ne i64 %cv5335, 0
  br i1 %cond5336, label %bb_rcslotrole1670, label %bb_rcslotowner1670
bb_rcslotrole1670:
  %v5337 = load i64, ptr %slot56, align 8
  store i64 %v5337, ptr %slot938, align 8
  %v5338 = load i64, ptr %slot938, align 8
  %v5339 = load i64, ptr %slot935, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v5338, i64 %v5339) nomerge, !dbg !152
  br label %bb_rcslotdone1670
bb_rcslotowner1670:
  %v5340 = load i64, ptr %slot56, align 8
  store i64 %v5340, ptr %slot939, align 8
  %v5341 = load i64, ptr %slot939, align 8
  %v5342 = load i64, ptr %slot935, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v5341, i64 %v5342) nomerge, !dbg !152
  br label %bb_rcslotdone1670
bb_rcslotdone1670:
  %v5343 = load i64, ptr %slot18, align 8
  %p5344 = inttoptr i64 %v5343 to ptr
  %ld5345 = load i32, ptr %p5344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5345, ptr %slot940, align 8
  %v5346 = load i32, ptr %slot940, align 8
  %cv5347 = zext i32 %v5346 to i64
  %cond5348 = icmp ne i64 %cv5347, 0
  br i1 %cond5348, label %bb_rcslotdrop1679, label %bb_rcslotdone1679
bb_rcslotdrop1679:
  %v5349 = load i64, ptr %slot18, align 8
  %p5350 = inttoptr i64 %v5349 to ptr
  store i32 0, ptr %p5350, align 4, !alias.scope !3, !noalias !4
  %v5351 = load i64, ptr %slot43, align 8
  store i64 %v5351, ptr %slot941, align 8
  %v5352 = load i64, ptr %slot19, align 8
  %p5353 = inttoptr i64 %v5352 to ptr
  %ld5354 = load i32, ptr %p5353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5354, ptr %slot942, align 8
  %v5355 = load i32, ptr %slot942, align 8
  %op5356 = and i32 %v5355, 28
  store i32 %op5356, ptr %slot943, align 8
  %v5357 = load i32, ptr %slot943, align 8
  %cv5358 = zext i32 %v5357 to i64
  %cond5359 = icmp ne i64 %cv5358, 0
  br i1 %cond5359, label %bb_rcslotrole1679, label %bb_rcslotowner1679
bb_rcslotrole1679:
  %v5360 = load i64, ptr %slot56, align 8
  store i64 %v5360, ptr %slot944, align 8
  %v5361 = load i64, ptr %slot944, align 8
  %v5362 = load i64, ptr %slot941, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v5361, i64 %v5362) nomerge, !dbg !152
  br label %bb_rcslotdone1679
bb_rcslotowner1679:
  %v5363 = load i64, ptr %slot56, align 8
  store i64 %v5363, ptr %slot945, align 8
  %v5364 = load i64, ptr %slot945, align 8
  %v5365 = load i64, ptr %slot941, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v5364, i64 %v5365) nomerge, !dbg !152
  br label %bb_rcslotdone1679
bb_rcslotdone1679:
  %v5366 = load i64, ptr %slot16, align 8
  %p5367 = inttoptr i64 %v5366 to ptr
  %ld5368 = load i32, ptr %p5367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5368, ptr %slot946, align 8
  %v5369 = load i32, ptr %slot946, align 8
  %cv5370 = zext i32 %v5369 to i64
  %cond5371 = icmp ne i64 %cv5370, 0
  br i1 %cond5371, label %bb_rcslotdrop1688, label %bb_rcslotdone1688
bb_rcslotdrop1688:
  %v5372 = load i64, ptr %slot16, align 8
  %p5373 = inttoptr i64 %v5372 to ptr
  store i32 0, ptr %p5373, align 4, !alias.scope !3, !noalias !4
  %v5374 = load i64, ptr %slot42, align 8
  store i64 %v5374, ptr %slot947, align 8
  %v5375 = load i64, ptr %slot17, align 8
  %p5376 = inttoptr i64 %v5375 to ptr
  %ld5377 = load i32, ptr %p5376, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5377, ptr %slot948, align 8
  %v5378 = load i32, ptr %slot948, align 8
  %op5379 = and i32 %v5378, 28
  store i32 %op5379, ptr %slot949, align 8
  %v5380 = load i32, ptr %slot949, align 8
  %cv5381 = zext i32 %v5380 to i64
  %cond5382 = icmp ne i64 %cv5381, 0
  br i1 %cond5382, label %bb_rcslotrole1688, label %bb_rcslotowner1688
bb_rcslotrole1688:
  %v5383 = load i64, ptr %slot56, align 8
  store i64 %v5383, ptr %slot950, align 8
  %v5384 = load i64, ptr %slot950, align 8
  %v5385 = load i64, ptr %slot947, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v5384, i64 %v5385) nomerge, !dbg !152
  br label %bb_rcslotdone1688
bb_rcslotowner1688:
  %v5386 = load i64, ptr %slot56, align 8
  store i64 %v5386, ptr %slot951, align 8
  %v5387 = load i64, ptr %slot951, align 8
  %v5388 = load i64, ptr %slot947, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v5387, i64 %v5388) nomerge, !dbg !152
  br label %bb_rcslotdone1688
bb_rcslotdone1688:
  %v5389 = load i64, ptr %slot14, align 8
  %p5390 = inttoptr i64 %v5389 to ptr
  %ld5391 = load i32, ptr %p5390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5391, ptr %slot952, align 8
  %v5392 = load i32, ptr %slot952, align 8
  %cv5393 = zext i32 %v5392 to i64
  %cond5394 = icmp ne i64 %cv5393, 0
  br i1 %cond5394, label %bb_rcslotdrop1697, label %bb_rcslotdone1697
bb_rcslotdrop1697:
  %v5395 = load i64, ptr %slot14, align 8
  %p5396 = inttoptr i64 %v5395 to ptr
  store i32 0, ptr %p5396, align 4, !alias.scope !3, !noalias !4
  %v5397 = load i64, ptr %slot41, align 8
  store i64 %v5397, ptr %slot953, align 8
  %v5398 = load i64, ptr %slot15, align 8
  %p5399 = inttoptr i64 %v5398 to ptr
  %ld5400 = load i32, ptr %p5399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5400, ptr %slot954, align 8
  %v5401 = load i32, ptr %slot954, align 8
  %op5402 = and i32 %v5401, 28
  store i32 %op5402, ptr %slot955, align 8
  %v5403 = load i32, ptr %slot955, align 8
  %cv5404 = zext i32 %v5403 to i64
  %cond5405 = icmp ne i64 %cv5404, 0
  br i1 %cond5405, label %bb_rcslotrole1697, label %bb_rcslotowner1697
bb_rcslotrole1697:
  %v5406 = load i64, ptr %slot56, align 8
  store i64 %v5406, ptr %slot956, align 8
  %v5407 = load i64, ptr %slot956, align 8
  %v5408 = load i64, ptr %slot953, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v5407, i64 %v5408) nomerge, !dbg !152
  br label %bb_rcslotdone1697
bb_rcslotowner1697:
  %v5409 = load i64, ptr %slot56, align 8
  store i64 %v5409, ptr %slot957, align 8
  %v5410 = load i64, ptr %slot957, align 8
  %v5411 = load i64, ptr %slot953, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v5410, i64 %v5411) nomerge, !dbg !152
  br label %bb_rcslotdone1697
bb_rcslotdone1697:
  %v5412 = load i64, ptr %slot12, align 8
  %p5413 = inttoptr i64 %v5412 to ptr
  %ld5414 = load i32, ptr %p5413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5414, ptr %slot958, align 8
  %v5415 = load i32, ptr %slot958, align 8
  %cv5416 = zext i32 %v5415 to i64
  %cond5417 = icmp ne i64 %cv5416, 0
  br i1 %cond5417, label %bb_rcslotdrop1706, label %bb_rcslotdone1706
bb_rcslotdrop1706:
  %v5418 = load i64, ptr %slot12, align 8
  %p5419 = inttoptr i64 %v5418 to ptr
  store i32 0, ptr %p5419, align 4, !alias.scope !3, !noalias !4
  %v5420 = load i64, ptr %slot40, align 8
  store i64 %v5420, ptr %slot959, align 8
  %v5421 = load i64, ptr %slot13, align 8
  %p5422 = inttoptr i64 %v5421 to ptr
  %ld5423 = load i32, ptr %p5422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5423, ptr %slot960, align 8
  %v5424 = load i32, ptr %slot960, align 8
  %op5425 = and i32 %v5424, 28
  store i32 %op5425, ptr %slot961, align 8
  %v5426 = load i32, ptr %slot961, align 8
  %cv5427 = zext i32 %v5426 to i64
  %cond5428 = icmp ne i64 %cv5427, 0
  br i1 %cond5428, label %bb_rcslotrole1706, label %bb_rcslotowner1706
bb_rcslotrole1706:
  %v5429 = load i64, ptr %slot56, align 8
  store i64 %v5429, ptr %slot962, align 8
  %v5430 = load i64, ptr %slot962, align 8
  %v5431 = load i64, ptr %slot959, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v5430, i64 %v5431) nomerge, !dbg !152
  br label %bb_rcslotdone1706
bb_rcslotowner1706:
  %v5432 = load i64, ptr %slot56, align 8
  store i64 %v5432, ptr %slot963, align 8
  %v5433 = load i64, ptr %slot963, align 8
  %v5434 = load i64, ptr %slot959, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v5433, i64 %v5434) nomerge, !dbg !152
  br label %bb_rcslotdone1706
bb_rcslotdone1706:
  %v5435 = load i64, ptr %slot10, align 8
  %p5436 = inttoptr i64 %v5435 to ptr
  %ld5437 = load i32, ptr %p5436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5437, ptr %slot964, align 8
  %v5438 = load i32, ptr %slot964, align 8
  %cv5439 = zext i32 %v5438 to i64
  %cond5440 = icmp ne i64 %cv5439, 0
  br i1 %cond5440, label %bb_rcslotdrop1715, label %bb_rcslotdone1715
bb_rcslotdrop1715:
  %v5441 = load i64, ptr %slot10, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  store i32 0, ptr %p5442, align 4, !alias.scope !3, !noalias !4
  %v5443 = load i64, ptr %slot38, align 8
  store i64 %v5443, ptr %slot965, align 8
  %v5444 = load i64, ptr %slot11, align 8
  %p5445 = inttoptr i64 %v5444 to ptr
  %ld5446 = load i32, ptr %p5445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5446, ptr %slot966, align 8
  %v5447 = load i32, ptr %slot966, align 8
  %op5448 = and i32 %v5447, 28
  store i32 %op5448, ptr %slot967, align 8
  %v5449 = load i32, ptr %slot967, align 8
  %cv5450 = zext i32 %v5449 to i64
  %cond5451 = icmp ne i64 %cv5450, 0
  br i1 %cond5451, label %bb_rcslotrole1715, label %bb_rcslotowner1715
bb_rcslotrole1715:
  %v5452 = load i64, ptr %slot56, align 8
  store i64 %v5452, ptr %slot968, align 8
  %v5453 = load i64, ptr %slot968, align 8
  %v5454 = load i64, ptr %slot965, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v5453, i64 %v5454) nomerge, !dbg !152
  br label %bb_rcslotdone1715
bb_rcslotowner1715:
  %v5455 = load i64, ptr %slot56, align 8
  store i64 %v5455, ptr %slot969, align 8
  %v5456 = load i64, ptr %slot969, align 8
  %v5457 = load i64, ptr %slot965, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v5456, i64 %v5457) nomerge, !dbg !152
  br label %bb_rcslotdone1715
bb_rcslotdone1715:
  %v5458 = load i64, ptr %slot8, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  %ld5460 = load i32, ptr %p5459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5460, ptr %slot970, align 8
  %v5461 = load i32, ptr %slot970, align 8
  %cv5462 = zext i32 %v5461 to i64
  %cond5463 = icmp ne i64 %cv5462, 0
  br i1 %cond5463, label %bb_rcslotdrop1724, label %bb_rcslotdone1724
bb_rcslotdrop1724:
  %v5464 = load i64, ptr %slot8, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i32 0, ptr %p5465, align 4, !alias.scope !3, !noalias !4
  %v5466 = load i64, ptr %slot37, align 8
  store i64 %v5466, ptr %slot971, align 8
  %v5467 = load i64, ptr %slot9, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  %ld5469 = load i32, ptr %p5468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5469, ptr %slot972, align 8
  %v5470 = load i32, ptr %slot972, align 8
  %op5471 = and i32 %v5470, 28
  store i32 %op5471, ptr %slot973, align 8
  %v5472 = load i32, ptr %slot973, align 8
  %cv5473 = zext i32 %v5472 to i64
  %cond5474 = icmp ne i64 %cv5473, 0
  br i1 %cond5474, label %bb_rcslotrole1724, label %bb_rcslotowner1724
bb_rcslotrole1724:
  %v5475 = load i64, ptr %slot56, align 8
  store i64 %v5475, ptr %slot974, align 8
  %v5476 = load i64, ptr %slot974, align 8
  %v5477 = load i64, ptr %slot971, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v5476, i64 %v5477) nomerge, !dbg !152
  br label %bb_rcslotdone1724
bb_rcslotowner1724:
  %v5478 = load i64, ptr %slot56, align 8
  store i64 %v5478, ptr %slot975, align 8
  %v5479 = load i64, ptr %slot975, align 8
  %v5480 = load i64, ptr %slot971, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v5479, i64 %v5480) nomerge, !dbg !152
  br label %bb_rcslotdone1724
bb_rcslotdone1724:
  %v5481 = load i64, ptr %slot6, align 8
  %p5482 = inttoptr i64 %v5481 to ptr
  %ld5483 = load i32, ptr %p5482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5483, ptr %slot976, align 8
  %v5484 = load i32, ptr %slot976, align 8
  %cv5485 = zext i32 %v5484 to i64
  %cond5486 = icmp ne i64 %cv5485, 0
  br i1 %cond5486, label %bb_rcslotdrop1733, label %bb_rcslotdone1733
bb_rcslotdrop1733:
  %v5487 = load i64, ptr %slot6, align 8
  %p5488 = inttoptr i64 %v5487 to ptr
  store i32 0, ptr %p5488, align 4, !alias.scope !3, !noalias !4
  %v5489 = load i64, ptr %slot36, align 8
  store i64 %v5489, ptr %slot977, align 8
  %v5490 = load i64, ptr %slot7, align 8
  %p5491 = inttoptr i64 %v5490 to ptr
  %ld5492 = load i32, ptr %p5491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5492, ptr %slot978, align 8
  %v5493 = load i32, ptr %slot978, align 8
  %op5494 = and i32 %v5493, 28
  store i32 %op5494, ptr %slot979, align 8
  %v5495 = load i32, ptr %slot979, align 8
  %cv5496 = zext i32 %v5495 to i64
  %cond5497 = icmp ne i64 %cv5496, 0
  br i1 %cond5497, label %bb_rcslotrole1733, label %bb_rcslotowner1733
bb_rcslotrole1733:
  %v5498 = load i64, ptr %slot56, align 8
  store i64 %v5498, ptr %slot980, align 8
  %v5499 = load i64, ptr %slot980, align 8
  %v5500 = load i64, ptr %slot977, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v5499, i64 %v5500) nomerge, !dbg !152
  br label %bb_rcslotdone1733
bb_rcslotowner1733:
  %v5501 = load i64, ptr %slot56, align 8
  store i64 %v5501, ptr %slot981, align 8
  %v5502 = load i64, ptr %slot981, align 8
  %v5503 = load i64, ptr %slot977, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v5502, i64 %v5503) nomerge, !dbg !152
  br label %bb_rcslotdone1733
bb_rcslotdone1733:
  %v5504 = load i64, ptr %slot915, align 8
  %p5505 = inttoptr i64 %v5504 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5505, i64 24, i1 false)
  ret void
bb_i47:
  %v5506 = load i64, ptr %slot32, align 8
  %p5507 = inttoptr i64 %v5506 to ptr
  %ld5508 = load i64, ptr %p5507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5508, ptr %slot982, align 8
  %v5509 = load i64, ptr %slot982, align 8
  %v5510 = load i64, ptr %slot47, align 8
  %p5511 = inttoptr i64 %v5510 to ptr
  store i64 %v5509, ptr %p5511, align 8, !alias.scope !3, !noalias !4
  %v5512 = load i64, ptr %slot42, align 8
  %v5513 = load i64, ptr %slot48, align 8
  %p5514 = inttoptr i64 %v5513 to ptr
  store i64 %v5512, ptr %p5514, align 8, !alias.scope !3, !noalias !4
  %v5515 = load i64, ptr %slot47, align 8
  %p5516 = inttoptr i64 %v5515 to ptr
  %ld5517 = load i64, ptr %p5516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5517, ptr %slot983, align 8
  %v5518 = load i64, ptr %slot48, align 8
  %p5519 = inttoptr i64 %v5518 to ptr
  %ld5520 = load i64, ptr %p5519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5520, ptr %slot984, align 8
  %v5521 = load i64, ptr %slot1, align 8
  %v5522 = load i64, ptr %slot983, align 8
  %v5523 = load i64, ptr %slot984, align 8
  call void @myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b(ptr sret([24 x i8]) align 8 %callresult986, i64 %v5521, i64 %v5522, i64 %v5523) nomerge, !dbg !154
  %addr5524 = ptrtoint ptr %callresult986 to i64
  store i64 %addr5524, ptr %slot985, align 8
  %v5525 = load i64, ptr %slot985, align 8
  %v5526 = load i64, ptr %slot47, align 8
  %p5527 = inttoptr i64 %v5526 to ptr
  store i64 %v5525, ptr %p5527, align 8, !alias.scope !3, !noalias !4
  %v5528 = load i64, ptr %slot47, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  %ld5530 = load i64, ptr %p5529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5530, ptr %slot987, align 8
  %v5531 = load i64, ptr %slot31, align 8
  store i64 %v5531, ptr %slot988, align 8
  %v5532 = load i64, ptr %slot987, align 8
  %v5533 = load i64, ptr %slot988, align 8
  %p5534 = inttoptr i64 %v5532 to ptr
  %p5535 = inttoptr i64 %v5533 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5535, ptr %p5534, i64 24, i1 false)
  %v5536 = load i64, ptr %slot29, align 8
  %p5537 = inttoptr i64 %v5536 to ptr
  store i32 2, ptr %p5537, align 4, !alias.scope !3, !noalias !4
  %v5538 = load i64, ptr %slot28, align 8
  %p5539 = inttoptr i64 %v5538 to ptr
  store i32 1, ptr %p5539, align 4, !alias.scope !3, !noalias !4
  %v5540 = load i64, ptr %slot26, align 8
  %p5541 = inttoptr i64 %v5540 to ptr
  %ld5542 = load i32, ptr %p5541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5542, ptr %slot989, align 8
  %v5543 = load i32, ptr %slot989, align 8
  %cv5544 = zext i32 %v5543 to i64
  %cond5545 = icmp ne i64 %cv5544, 0
  br i1 %cond5545, label %bb_rcslotdrop1796, label %bb_rcslotdone1796
bb_rcslotdrop1796:
  %v5546 = load i64, ptr %slot26, align 8
  %p5547 = inttoptr i64 %v5546 to ptr
  store i32 0, ptr %p5547, align 4, !alias.scope !3, !noalias !4
  %v5548 = load i64, ptr %slot30, align 8
  store i64 %v5548, ptr %slot990, align 8
  %v5549 = load i64, ptr %slot27, align 8
  %p5550 = inttoptr i64 %v5549 to ptr
  %ld5551 = load i32, ptr %p5550, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5551, ptr %slot991, align 8
  %v5552 = load i32, ptr %slot991, align 8
  %op5553 = and i32 %v5552, 28
  store i32 %op5553, ptr %slot992, align 8
  %v5554 = load i32, ptr %slot992, align 8
  %cv5555 = zext i32 %v5554 to i64
  %cond5556 = icmp ne i64 %cv5555, 0
  br i1 %cond5556, label %bb_rcslotrole1796, label %bb_rcslotowner1796
bb_rcslotrole1796:
  %v5557 = load i64, ptr %slot56, align 8
  store i64 %v5557, ptr %slot993, align 8
  %v5558 = load i64, ptr %slot993, align 8
  %v5559 = load i64, ptr %slot990, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v5558, i64 %v5559) nomerge, !dbg !154
  br label %bb_rcslotdone1796
bb_rcslotowner1796:
  %v5560 = load i64, ptr %slot56, align 8
  store i64 %v5560, ptr %slot994, align 8
  %v5561 = load i64, ptr %slot994, align 8
  %v5562 = load i64, ptr %slot990, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v5561, i64 %v5562) nomerge, !dbg !154
  br label %bb_rcslotdone1796
bb_rcslotdone1796:
  %v5563 = load i64, ptr %slot30, align 8
  store i64 %v5563, ptr %slot995, align 8
  %v5564 = load i64, ptr %slot31, align 8
  store i64 %v5564, ptr %slot996, align 8
  %v5565 = load i64, ptr %slot996, align 8
  %v5566 = load i64, ptr %slot995, align 8
  %p5567 = inttoptr i64 %v5565 to ptr
  %p5568 = inttoptr i64 %v5566 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5568, ptr %p5567, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5569 = load i64, ptr %slot27, align 8
  %p5570 = inttoptr i64 %v5569 to ptr
  store i32 2, ptr %p5570, align 4, !alias.scope !3, !noalias !4
  %v5571 = load i64, ptr %slot29, align 8
  %p5572 = inttoptr i64 %v5571 to ptr
  %ld5573 = load i32, ptr %p5572, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5573, ptr %slot997, align 8
  %v5574 = load i32, ptr %slot997, align 8
  %v5575 = load i64, ptr %slot27, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  store i32 %v5574, ptr %p5576, align 4, !alias.scope !3, !noalias !4
  %v5577 = load i64, ptr %slot28, align 8
  %p5578 = inttoptr i64 %v5577 to ptr
  store i32 0, ptr %p5578, align 4, !alias.scope !3, !noalias !4
  %v5579 = load i64, ptr %slot26, align 8
  %p5580 = inttoptr i64 %v5579 to ptr
  store i32 1, ptr %p5580, align 4, !alias.scope !3, !noalias !4
  %v5581 = load i64, ptr %slot995, align 8
  %v5582 = load i64, ptr %slot47, align 8
  %p5583 = inttoptr i64 %v5582 to ptr
  store i64 %v5581, ptr %p5583, align 8, !alias.scope !3, !noalias !4
  %v5584 = load i64, ptr %slot47, align 8
  %p5585 = inttoptr i64 %v5584 to ptr
  %ld5586 = load i64, ptr %p5585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5586, ptr %slot998, align 8
  %v5587 = load i64, ptr %slot998, align 8
  %p5588 = inttoptr i64 %v5587 to ptr
  %ld5589 = load i32, ptr %p5588, align 4, !alias.scope !3, !noalias !4
  %ext5590 = zext i32 %ld5589 to i64
  store i64 %ext5590, ptr %slot999, align 8
  %v5591 = load i64, ptr %slot999, align 8
  %cmp5592 = icmp eq i64 %v5591, 1
  %cv5593 = zext i1 %cmp5592 to i64
  store i64 %cv5593, ptr %slot1000, align 8
  %v5594 = load i64, ptr %slot1000, align 8
  %cond5595 = icmp ne i64 %v5594, 0
  br i1 %cond5595, label %bb_errtrace1822, label %bb_errtraced1822
bb_errtrace1822:
  %p5596 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p5596, i64 8589934642) "call-inline-cost"="0", !dbg !156
  br label %bb_errtraced1822
bb_errtraced1822:
  %v5597 = load i64, ptr %slot47, align 8
  %p5598 = inttoptr i64 %v5597 to ptr
  %ld5599 = load i64, ptr %p5598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5599, ptr %slot1001, align 8
  %v5600 = load i64, ptr %slot31, align 8
  store i64 %v5600, ptr %slot1002, align 8
  %v5601 = load i64, ptr %slot57, align 8
  store i64 %v5601, ptr %slot1003, align 8
  %v5602 = load i64, ptr %slot56, align 8
  %v5603 = load i64, ptr %slot1002, align 8
  %v5604 = load i64, ptr %slot1001, align 8
  %v5605 = load i64, ptr %slot1003, align 8
  %cv5606 = trunc i64 %v5605 to i32
  %call5607 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v5602, i64 %v5603, i64 %v5604, i32 %cv5606) nomerge, !dbg !156
  store i32 %call5607, ptr %slot1004, align 8
  %v5608 = load i32, ptr %slot1004, align 8
  %cv5609 = zext i32 %v5608 to i64
  %cond5610 = icmp ne i64 %cv5609, 0
  br i1 %cond5610, label %bb_rcsuccess1827, label %bb_rcfailure1827
bb_rcfailure1827:
  %v5611 = load i64, ptr %slot56, align 8
  %p5612 = inttoptr i64 %v5611 to ptr
  %call5613 = call i32 @myl_rc_take_failure(ptr %p5612) nomerge, !dbg !156
  store i32 %call5613, ptr %slot1005, align 8
  %v5614 = load i64, ptr %slot1, align 8
  %p5615 = inttoptr i64 %v5614 to ptr
  %v5616 = load i32, ptr %slot1005, align 8
  %call5617 = call i32 @myl_qbe_rc_status(ptr %p5615, i32 %v5616) nomerge, !dbg !156
  store i32 %call5617, ptr %slot1006, align 8
  br label %bb_failure
bb_rcsuccess1827:
  %v5618 = load i64, ptr %slot26, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  store i32 0, ptr %p5619, align 4, !alias.scope !3, !noalias !4
  %v5620 = load i64, ptr %slot29, align 8
  %p5621 = inttoptr i64 %v5620 to ptr
  store i32 2, ptr %p5621, align 4, !alias.scope !3, !noalias !4
  %v5622 = load i64, ptr %slot28, align 8
  %p5623 = inttoptr i64 %v5622 to ptr
  store i32 1, ptr %p5623, align 4, !alias.scope !3, !noalias !4
  %v5624 = load i64, ptr %slot31, align 8
  store i64 %v5624, ptr %slot1007, align 8
  %v5625 = load i64, ptr %slot28, align 8
  %p5626 = inttoptr i64 %v5625 to ptr
  store i32 0, ptr %p5626, align 4, !alias.scope !3, !noalias !4
  %v5627 = load i64, ptr %slot26, align 8
  %p5628 = inttoptr i64 %v5627 to ptr
  %ld5629 = load i32, ptr %p5628, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5629, ptr %slot1008, align 8
  %v5630 = load i32, ptr %slot1008, align 8
  %cv5631 = zext i32 %v5630 to i64
  %cond5632 = icmp ne i64 %cv5631, 0
  br i1 %cond5632, label %bb_rcslotdrop1837, label %bb_rcslotdone1837
bb_rcslotdrop1837:
  %v5633 = load i64, ptr %slot26, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  store i32 0, ptr %p5634, align 4, !alias.scope !3, !noalias !4
  %v5635 = load i64, ptr %slot30, align 8
  store i64 %v5635, ptr %slot1009, align 8
  %v5636 = load i64, ptr %slot27, align 8
  %p5637 = inttoptr i64 %v5636 to ptr
  %ld5638 = load i32, ptr %p5637, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5638, ptr %slot1010, align 8
  %v5639 = load i32, ptr %slot1010, align 8
  %op5640 = and i32 %v5639, 28
  store i32 %op5640, ptr %slot1011, align 8
  %v5641 = load i32, ptr %slot1011, align 8
  %cv5642 = zext i32 %v5641 to i64
  %cond5643 = icmp ne i64 %cv5642, 0
  br i1 %cond5643, label %bb_rcslotrole1837, label %bb_rcslotowner1837
bb_rcslotrole1837:
  %v5644 = load i64, ptr %slot56, align 8
  store i64 %v5644, ptr %slot1012, align 8
  %v5645 = load i64, ptr %slot1012, align 8
  %v5646 = load i64, ptr %slot1009, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v5645, i64 %v5646) nomerge, !dbg !156
  br label %bb_rcslotdone1837
bb_rcslotowner1837:
  %v5647 = load i64, ptr %slot56, align 8
  store i64 %v5647, ptr %slot1013, align 8
  %v5648 = load i64, ptr %slot1013, align 8
  %v5649 = load i64, ptr %slot1009, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v5648, i64 %v5649) nomerge, !dbg !156
  br label %bb_rcslotdone1837
bb_rcslotdone1837:
  %v5650 = load i64, ptr %slot24, align 8
  %p5651 = inttoptr i64 %v5650 to ptr
  %ld5652 = load i32, ptr %p5651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5652, ptr %slot1014, align 8
  %v5653 = load i32, ptr %slot1014, align 8
  %cv5654 = zext i32 %v5653 to i64
  %cond5655 = icmp ne i64 %cv5654, 0
  br i1 %cond5655, label %bb_rcslotdrop1846, label %bb_rcslotdone1846
bb_rcslotdrop1846:
  %v5656 = load i64, ptr %slot24, align 8
  %p5657 = inttoptr i64 %v5656 to ptr
  store i32 0, ptr %p5657, align 4, !alias.scope !3, !noalias !4
  %v5658 = load i64, ptr %slot46, align 8
  store i64 %v5658, ptr %slot1015, align 8
  %v5659 = load i64, ptr %slot25, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  %ld5661 = load i32, ptr %p5660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5661, ptr %slot1016, align 8
  %v5662 = load i32, ptr %slot1016, align 8
  %op5663 = and i32 %v5662, 28
  store i32 %op5663, ptr %slot1017, align 8
  %v5664 = load i32, ptr %slot1017, align 8
  %cv5665 = zext i32 %v5664 to i64
  %cond5666 = icmp ne i64 %cv5665, 0
  br i1 %cond5666, label %bb_rcslotrole1846, label %bb_rcslotowner1846
bb_rcslotrole1846:
  %v5667 = load i64, ptr %slot56, align 8
  store i64 %v5667, ptr %slot1018, align 8
  %v5668 = load i64, ptr %slot1018, align 8
  %v5669 = load i64, ptr %slot1015, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v5668, i64 %v5669) nomerge, !dbg !156
  br label %bb_rcslotdone1846
bb_rcslotowner1846:
  %v5670 = load i64, ptr %slot56, align 8
  store i64 %v5670, ptr %slot1019, align 8
  %v5671 = load i64, ptr %slot1019, align 8
  %v5672 = load i64, ptr %slot1015, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v5671, i64 %v5672) nomerge, !dbg !156
  br label %bb_rcslotdone1846
bb_rcslotdone1846:
  %v5673 = load i64, ptr %slot22, align 8
  %p5674 = inttoptr i64 %v5673 to ptr
  %ld5675 = load i32, ptr %p5674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5675, ptr %slot1020, align 8
  %v5676 = load i32, ptr %slot1020, align 8
  %cv5677 = zext i32 %v5676 to i64
  %cond5678 = icmp ne i64 %cv5677, 0
  br i1 %cond5678, label %bb_rcslotdrop1855, label %bb_rcslotdone1855
bb_rcslotdrop1855:
  %v5679 = load i64, ptr %slot22, align 8
  %p5680 = inttoptr i64 %v5679 to ptr
  store i32 0, ptr %p5680, align 4, !alias.scope !3, !noalias !4
  %v5681 = load i64, ptr %slot45, align 8
  store i64 %v5681, ptr %slot1021, align 8
  %v5682 = load i64, ptr %slot23, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  %ld5684 = load i32, ptr %p5683, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5684, ptr %slot1022, align 8
  %v5685 = load i32, ptr %slot1022, align 8
  %op5686 = and i32 %v5685, 28
  store i32 %op5686, ptr %slot1023, align 8
  %v5687 = load i32, ptr %slot1023, align 8
  %cv5688 = zext i32 %v5687 to i64
  %cond5689 = icmp ne i64 %cv5688, 0
  br i1 %cond5689, label %bb_rcslotrole1855, label %bb_rcslotowner1855
bb_rcslotrole1855:
  %v5690 = load i64, ptr %slot56, align 8
  store i64 %v5690, ptr %slot1024, align 8
  %v5691 = load i64, ptr %slot1024, align 8
  %v5692 = load i64, ptr %slot1021, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v5691, i64 %v5692) nomerge, !dbg !156
  br label %bb_rcslotdone1855
bb_rcslotowner1855:
  %v5693 = load i64, ptr %slot56, align 8
  store i64 %v5693, ptr %slot1025, align 8
  %v5694 = load i64, ptr %slot1025, align 8
  %v5695 = load i64, ptr %slot1021, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v5694, i64 %v5695) nomerge, !dbg !156
  br label %bb_rcslotdone1855
bb_rcslotdone1855:
  %v5696 = load i64, ptr %slot20, align 8
  %p5697 = inttoptr i64 %v5696 to ptr
  %ld5698 = load i32, ptr %p5697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5698, ptr %slot1026, align 8
  %v5699 = load i32, ptr %slot1026, align 8
  %cv5700 = zext i32 %v5699 to i64
  %cond5701 = icmp ne i64 %cv5700, 0
  br i1 %cond5701, label %bb_rcslotdrop1864, label %bb_rcslotdone1864
bb_rcslotdrop1864:
  %v5702 = load i64, ptr %slot20, align 8
  %p5703 = inttoptr i64 %v5702 to ptr
  store i32 0, ptr %p5703, align 4, !alias.scope !3, !noalias !4
  %v5704 = load i64, ptr %slot44, align 8
  store i64 %v5704, ptr %slot1027, align 8
  %v5705 = load i64, ptr %slot21, align 8
  %p5706 = inttoptr i64 %v5705 to ptr
  %ld5707 = load i32, ptr %p5706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5707, ptr %slot1028, align 8
  %v5708 = load i32, ptr %slot1028, align 8
  %op5709 = and i32 %v5708, 28
  store i32 %op5709, ptr %slot1029, align 8
  %v5710 = load i32, ptr %slot1029, align 8
  %cv5711 = zext i32 %v5710 to i64
  %cond5712 = icmp ne i64 %cv5711, 0
  br i1 %cond5712, label %bb_rcslotrole1864, label %bb_rcslotowner1864
bb_rcslotrole1864:
  %v5713 = load i64, ptr %slot56, align 8
  store i64 %v5713, ptr %slot1030, align 8
  %v5714 = load i64, ptr %slot1030, align 8
  %v5715 = load i64, ptr %slot1027, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v5714, i64 %v5715) nomerge, !dbg !156
  br label %bb_rcslotdone1864
bb_rcslotowner1864:
  %v5716 = load i64, ptr %slot56, align 8
  store i64 %v5716, ptr %slot1031, align 8
  %v5717 = load i64, ptr %slot1031, align 8
  %v5718 = load i64, ptr %slot1027, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v5717, i64 %v5718) nomerge, !dbg !156
  br label %bb_rcslotdone1864
bb_rcslotdone1864:
  %v5719 = load i64, ptr %slot18, align 8
  %p5720 = inttoptr i64 %v5719 to ptr
  %ld5721 = load i32, ptr %p5720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5721, ptr %slot1032, align 8
  %v5722 = load i32, ptr %slot1032, align 8
  %cv5723 = zext i32 %v5722 to i64
  %cond5724 = icmp ne i64 %cv5723, 0
  br i1 %cond5724, label %bb_rcslotdrop1873, label %bb_rcslotdone1873
bb_rcslotdrop1873:
  %v5725 = load i64, ptr %slot18, align 8
  %p5726 = inttoptr i64 %v5725 to ptr
  store i32 0, ptr %p5726, align 4, !alias.scope !3, !noalias !4
  %v5727 = load i64, ptr %slot43, align 8
  store i64 %v5727, ptr %slot1033, align 8
  %v5728 = load i64, ptr %slot19, align 8
  %p5729 = inttoptr i64 %v5728 to ptr
  %ld5730 = load i32, ptr %p5729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5730, ptr %slot1034, align 8
  %v5731 = load i32, ptr %slot1034, align 8
  %op5732 = and i32 %v5731, 28
  store i32 %op5732, ptr %slot1035, align 8
  %v5733 = load i32, ptr %slot1035, align 8
  %cv5734 = zext i32 %v5733 to i64
  %cond5735 = icmp ne i64 %cv5734, 0
  br i1 %cond5735, label %bb_rcslotrole1873, label %bb_rcslotowner1873
bb_rcslotrole1873:
  %v5736 = load i64, ptr %slot56, align 8
  store i64 %v5736, ptr %slot1036, align 8
  %v5737 = load i64, ptr %slot1036, align 8
  %v5738 = load i64, ptr %slot1033, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v5737, i64 %v5738) nomerge, !dbg !156
  br label %bb_rcslotdone1873
bb_rcslotowner1873:
  %v5739 = load i64, ptr %slot56, align 8
  store i64 %v5739, ptr %slot1037, align 8
  %v5740 = load i64, ptr %slot1037, align 8
  %v5741 = load i64, ptr %slot1033, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v5740, i64 %v5741) nomerge, !dbg !156
  br label %bb_rcslotdone1873
bb_rcslotdone1873:
  %v5742 = load i64, ptr %slot16, align 8
  %p5743 = inttoptr i64 %v5742 to ptr
  %ld5744 = load i32, ptr %p5743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5744, ptr %slot1038, align 8
  %v5745 = load i32, ptr %slot1038, align 8
  %cv5746 = zext i32 %v5745 to i64
  %cond5747 = icmp ne i64 %cv5746, 0
  br i1 %cond5747, label %bb_rcslotdrop1882, label %bb_rcslotdone1882
bb_rcslotdrop1882:
  %v5748 = load i64, ptr %slot16, align 8
  %p5749 = inttoptr i64 %v5748 to ptr
  store i32 0, ptr %p5749, align 4, !alias.scope !3, !noalias !4
  %v5750 = load i64, ptr %slot42, align 8
  store i64 %v5750, ptr %slot1039, align 8
  %v5751 = load i64, ptr %slot17, align 8
  %p5752 = inttoptr i64 %v5751 to ptr
  %ld5753 = load i32, ptr %p5752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5753, ptr %slot1040, align 8
  %v5754 = load i32, ptr %slot1040, align 8
  %op5755 = and i32 %v5754, 28
  store i32 %op5755, ptr %slot1041, align 8
  %v5756 = load i32, ptr %slot1041, align 8
  %cv5757 = zext i32 %v5756 to i64
  %cond5758 = icmp ne i64 %cv5757, 0
  br i1 %cond5758, label %bb_rcslotrole1882, label %bb_rcslotowner1882
bb_rcslotrole1882:
  %v5759 = load i64, ptr %slot56, align 8
  store i64 %v5759, ptr %slot1042, align 8
  %v5760 = load i64, ptr %slot1042, align 8
  %v5761 = load i64, ptr %slot1039, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v5760, i64 %v5761) nomerge, !dbg !156
  br label %bb_rcslotdone1882
bb_rcslotowner1882:
  %v5762 = load i64, ptr %slot56, align 8
  store i64 %v5762, ptr %slot1043, align 8
  %v5763 = load i64, ptr %slot1043, align 8
  %v5764 = load i64, ptr %slot1039, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v5763, i64 %v5764) nomerge, !dbg !156
  br label %bb_rcslotdone1882
bb_rcslotdone1882:
  %v5765 = load i64, ptr %slot14, align 8
  %p5766 = inttoptr i64 %v5765 to ptr
  %ld5767 = load i32, ptr %p5766, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5767, ptr %slot1044, align 8
  %v5768 = load i32, ptr %slot1044, align 8
  %cv5769 = zext i32 %v5768 to i64
  %cond5770 = icmp ne i64 %cv5769, 0
  br i1 %cond5770, label %bb_rcslotdrop1891, label %bb_rcslotdone1891
bb_rcslotdrop1891:
  %v5771 = load i64, ptr %slot14, align 8
  %p5772 = inttoptr i64 %v5771 to ptr
  store i32 0, ptr %p5772, align 4, !alias.scope !3, !noalias !4
  %v5773 = load i64, ptr %slot41, align 8
  store i64 %v5773, ptr %slot1045, align 8
  %v5774 = load i64, ptr %slot15, align 8
  %p5775 = inttoptr i64 %v5774 to ptr
  %ld5776 = load i32, ptr %p5775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5776, ptr %slot1046, align 8
  %v5777 = load i32, ptr %slot1046, align 8
  %op5778 = and i32 %v5777, 28
  store i32 %op5778, ptr %slot1047, align 8
  %v5779 = load i32, ptr %slot1047, align 8
  %cv5780 = zext i32 %v5779 to i64
  %cond5781 = icmp ne i64 %cv5780, 0
  br i1 %cond5781, label %bb_rcslotrole1891, label %bb_rcslotowner1891
bb_rcslotrole1891:
  %v5782 = load i64, ptr %slot56, align 8
  store i64 %v5782, ptr %slot1048, align 8
  %v5783 = load i64, ptr %slot1048, align 8
  %v5784 = load i64, ptr %slot1045, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v5783, i64 %v5784) nomerge, !dbg !156
  br label %bb_rcslotdone1891
bb_rcslotowner1891:
  %v5785 = load i64, ptr %slot56, align 8
  store i64 %v5785, ptr %slot1049, align 8
  %v5786 = load i64, ptr %slot1049, align 8
  %v5787 = load i64, ptr %slot1045, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v5786, i64 %v5787) nomerge, !dbg !156
  br label %bb_rcslotdone1891
bb_rcslotdone1891:
  %v5788 = load i64, ptr %slot12, align 8
  %p5789 = inttoptr i64 %v5788 to ptr
  %ld5790 = load i32, ptr %p5789, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5790, ptr %slot1050, align 8
  %v5791 = load i32, ptr %slot1050, align 8
  %cv5792 = zext i32 %v5791 to i64
  %cond5793 = icmp ne i64 %cv5792, 0
  br i1 %cond5793, label %bb_rcslotdrop1900, label %bb_rcslotdone1900
bb_rcslotdrop1900:
  %v5794 = load i64, ptr %slot12, align 8
  %p5795 = inttoptr i64 %v5794 to ptr
  store i32 0, ptr %p5795, align 4, !alias.scope !3, !noalias !4
  %v5796 = load i64, ptr %slot40, align 8
  store i64 %v5796, ptr %slot1051, align 8
  %v5797 = load i64, ptr %slot13, align 8
  %p5798 = inttoptr i64 %v5797 to ptr
  %ld5799 = load i32, ptr %p5798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5799, ptr %slot1052, align 8
  %v5800 = load i32, ptr %slot1052, align 8
  %op5801 = and i32 %v5800, 28
  store i32 %op5801, ptr %slot1053, align 8
  %v5802 = load i32, ptr %slot1053, align 8
  %cv5803 = zext i32 %v5802 to i64
  %cond5804 = icmp ne i64 %cv5803, 0
  br i1 %cond5804, label %bb_rcslotrole1900, label %bb_rcslotowner1900
bb_rcslotrole1900:
  %v5805 = load i64, ptr %slot56, align 8
  store i64 %v5805, ptr %slot1054, align 8
  %v5806 = load i64, ptr %slot1054, align 8
  %v5807 = load i64, ptr %slot1051, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v5806, i64 %v5807) nomerge, !dbg !156
  br label %bb_rcslotdone1900
bb_rcslotowner1900:
  %v5808 = load i64, ptr %slot56, align 8
  store i64 %v5808, ptr %slot1055, align 8
  %v5809 = load i64, ptr %slot1055, align 8
  %v5810 = load i64, ptr %slot1051, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v5809, i64 %v5810) nomerge, !dbg !156
  br label %bb_rcslotdone1900
bb_rcslotdone1900:
  %v5811 = load i64, ptr %slot10, align 8
  %p5812 = inttoptr i64 %v5811 to ptr
  %ld5813 = load i32, ptr %p5812, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5813, ptr %slot1056, align 8
  %v5814 = load i32, ptr %slot1056, align 8
  %cv5815 = zext i32 %v5814 to i64
  %cond5816 = icmp ne i64 %cv5815, 0
  br i1 %cond5816, label %bb_rcslotdrop1909, label %bb_rcslotdone1909
bb_rcslotdrop1909:
  %v5817 = load i64, ptr %slot10, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  store i32 0, ptr %p5818, align 4, !alias.scope !3, !noalias !4
  %v5819 = load i64, ptr %slot38, align 8
  store i64 %v5819, ptr %slot1057, align 8
  %v5820 = load i64, ptr %slot11, align 8
  %p5821 = inttoptr i64 %v5820 to ptr
  %ld5822 = load i32, ptr %p5821, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5822, ptr %slot1058, align 8
  %v5823 = load i32, ptr %slot1058, align 8
  %op5824 = and i32 %v5823, 28
  store i32 %op5824, ptr %slot1059, align 8
  %v5825 = load i32, ptr %slot1059, align 8
  %cv5826 = zext i32 %v5825 to i64
  %cond5827 = icmp ne i64 %cv5826, 0
  br i1 %cond5827, label %bb_rcslotrole1909, label %bb_rcslotowner1909
bb_rcslotrole1909:
  %v5828 = load i64, ptr %slot56, align 8
  store i64 %v5828, ptr %slot1060, align 8
  %v5829 = load i64, ptr %slot1060, align 8
  %v5830 = load i64, ptr %slot1057, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v5829, i64 %v5830) nomerge, !dbg !156
  br label %bb_rcslotdone1909
bb_rcslotowner1909:
  %v5831 = load i64, ptr %slot56, align 8
  store i64 %v5831, ptr %slot1061, align 8
  %v5832 = load i64, ptr %slot1061, align 8
  %v5833 = load i64, ptr %slot1057, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v5832, i64 %v5833) nomerge, !dbg !156
  br label %bb_rcslotdone1909
bb_rcslotdone1909:
  %v5834 = load i64, ptr %slot8, align 8
  %p5835 = inttoptr i64 %v5834 to ptr
  %ld5836 = load i32, ptr %p5835, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5836, ptr %slot1062, align 8
  %v5837 = load i32, ptr %slot1062, align 8
  %cv5838 = zext i32 %v5837 to i64
  %cond5839 = icmp ne i64 %cv5838, 0
  br i1 %cond5839, label %bb_rcslotdrop1918, label %bb_rcslotdone1918
bb_rcslotdrop1918:
  %v5840 = load i64, ptr %slot8, align 8
  %p5841 = inttoptr i64 %v5840 to ptr
  store i32 0, ptr %p5841, align 4, !alias.scope !3, !noalias !4
  %v5842 = load i64, ptr %slot37, align 8
  store i64 %v5842, ptr %slot1063, align 8
  %v5843 = load i64, ptr %slot9, align 8
  %p5844 = inttoptr i64 %v5843 to ptr
  %ld5845 = load i32, ptr %p5844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5845, ptr %slot1064, align 8
  %v5846 = load i32, ptr %slot1064, align 8
  %op5847 = and i32 %v5846, 28
  store i32 %op5847, ptr %slot1065, align 8
  %v5848 = load i32, ptr %slot1065, align 8
  %cv5849 = zext i32 %v5848 to i64
  %cond5850 = icmp ne i64 %cv5849, 0
  br i1 %cond5850, label %bb_rcslotrole1918, label %bb_rcslotowner1918
bb_rcslotrole1918:
  %v5851 = load i64, ptr %slot56, align 8
  store i64 %v5851, ptr %slot1066, align 8
  %v5852 = load i64, ptr %slot1066, align 8
  %v5853 = load i64, ptr %slot1063, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v5852, i64 %v5853) nomerge, !dbg !156
  br label %bb_rcslotdone1918
bb_rcslotowner1918:
  %v5854 = load i64, ptr %slot56, align 8
  store i64 %v5854, ptr %slot1067, align 8
  %v5855 = load i64, ptr %slot1067, align 8
  %v5856 = load i64, ptr %slot1063, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v5855, i64 %v5856) nomerge, !dbg !156
  br label %bb_rcslotdone1918
bb_rcslotdone1918:
  %v5857 = load i64, ptr %slot6, align 8
  %p5858 = inttoptr i64 %v5857 to ptr
  %ld5859 = load i32, ptr %p5858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5859, ptr %slot1068, align 8
  %v5860 = load i32, ptr %slot1068, align 8
  %cv5861 = zext i32 %v5860 to i64
  %cond5862 = icmp ne i64 %cv5861, 0
  br i1 %cond5862, label %bb_rcslotdrop1927, label %bb_rcslotdone1927
bb_rcslotdrop1927:
  %v5863 = load i64, ptr %slot6, align 8
  %p5864 = inttoptr i64 %v5863 to ptr
  store i32 0, ptr %p5864, align 4, !alias.scope !3, !noalias !4
  %v5865 = load i64, ptr %slot36, align 8
  store i64 %v5865, ptr %slot1069, align 8
  %v5866 = load i64, ptr %slot7, align 8
  %p5867 = inttoptr i64 %v5866 to ptr
  %ld5868 = load i32, ptr %p5867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5868, ptr %slot1070, align 8
  %v5869 = load i32, ptr %slot1070, align 8
  %op5870 = and i32 %v5869, 28
  store i32 %op5870, ptr %slot1071, align 8
  %v5871 = load i32, ptr %slot1071, align 8
  %cv5872 = zext i32 %v5871 to i64
  %cond5873 = icmp ne i64 %cv5872, 0
  br i1 %cond5873, label %bb_rcslotrole1927, label %bb_rcslotowner1927
bb_rcslotrole1927:
  %v5874 = load i64, ptr %slot56, align 8
  store i64 %v5874, ptr %slot1072, align 8
  %v5875 = load i64, ptr %slot1072, align 8
  %v5876 = load i64, ptr %slot1069, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v5875, i64 %v5876) nomerge, !dbg !156
  br label %bb_rcslotdone1927
bb_rcslotowner1927:
  %v5877 = load i64, ptr %slot56, align 8
  store i64 %v5877, ptr %slot1073, align 8
  %v5878 = load i64, ptr %slot1073, align 8
  %v5879 = load i64, ptr %slot1069, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v5878, i64 %v5879) nomerge, !dbg !156
  br label %bb_rcslotdone1927
bb_rcslotdone1927:
  %v5880 = load i64, ptr %slot1007, align 8
  %p5881 = inttoptr i64 %v5880 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5881, i64 24, i1 false)
  ret void
bb_i51:
  %v5882 = load i64, ptr %slot32, align 8
  %p5883 = inttoptr i64 %v5882 to ptr
  %ld5884 = load i64, ptr %p5883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5884, ptr %slot1074, align 8
  %v5885 = load i64, ptr %slot1074, align 8
  %v5886 = load i64, ptr %slot47, align 8
  %p5887 = inttoptr i64 %v5886 to ptr
  store i64 %v5885, ptr %p5887, align 8, !alias.scope !3, !noalias !4
  %v5888 = load i64, ptr %slot43, align 8
  %v5889 = load i64, ptr %slot48, align 8
  %p5890 = inttoptr i64 %v5889 to ptr
  store i64 %v5888, ptr %p5890, align 8, !alias.scope !3, !noalias !4
  %v5891 = load i64, ptr %slot47, align 8
  %p5892 = inttoptr i64 %v5891 to ptr
  %ld5893 = load i64, ptr %p5892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5893, ptr %slot1075, align 8
  %v5894 = load i64, ptr %slot48, align 8
  %p5895 = inttoptr i64 %v5894 to ptr
  %ld5896 = load i64, ptr %p5895, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5896, ptr %slot1076, align 8
  %v5897 = load i64, ptr %slot1, align 8
  %v5898 = load i64, ptr %slot1075, align 8
  %v5899 = load i64, ptr %slot1076, align 8
  call void @myl_f_fe7a9b911e5976d536198547c07832bc757732c7fb0f639f1c35b8e4259d7e1e(ptr sret([24 x i8]) align 8 %callresult1078, i64 %v5897, i64 %v5898, i64 %v5899) nomerge, !dbg !158
  %addr5900 = ptrtoint ptr %callresult1078 to i64
  store i64 %addr5900, ptr %slot1077, align 8
  %v5901 = load i64, ptr %slot1077, align 8
  %v5902 = load i64, ptr %slot47, align 8
  %p5903 = inttoptr i64 %v5902 to ptr
  store i64 %v5901, ptr %p5903, align 8, !alias.scope !3, !noalias !4
  %v5904 = load i64, ptr %slot47, align 8
  %p5905 = inttoptr i64 %v5904 to ptr
  %ld5906 = load i64, ptr %p5905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5906, ptr %slot1079, align 8
  %v5907 = load i64, ptr %slot31, align 8
  store i64 %v5907, ptr %slot1080, align 8
  %v5908 = load i64, ptr %slot1079, align 8
  %v5909 = load i64, ptr %slot1080, align 8
  %p5910 = inttoptr i64 %v5908 to ptr
  %p5911 = inttoptr i64 %v5909 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5911, ptr %p5910, i64 24, i1 false)
  %v5912 = load i64, ptr %slot29, align 8
  %p5913 = inttoptr i64 %v5912 to ptr
  store i32 2, ptr %p5913, align 4, !alias.scope !3, !noalias !4
  %v5914 = load i64, ptr %slot28, align 8
  %p5915 = inttoptr i64 %v5914 to ptr
  store i32 1, ptr %p5915, align 4, !alias.scope !3, !noalias !4
  %v5916 = load i64, ptr %slot26, align 8
  %p5917 = inttoptr i64 %v5916 to ptr
  %ld5918 = load i32, ptr %p5917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5918, ptr %slot1081, align 8
  %v5919 = load i32, ptr %slot1081, align 8
  %cv5920 = zext i32 %v5919 to i64
  %cond5921 = icmp ne i64 %cv5920, 0
  br i1 %cond5921, label %bb_rcslotdrop1990, label %bb_rcslotdone1990
bb_rcslotdrop1990:
  %v5922 = load i64, ptr %slot26, align 8
  %p5923 = inttoptr i64 %v5922 to ptr
  store i32 0, ptr %p5923, align 4, !alias.scope !3, !noalias !4
  %v5924 = load i64, ptr %slot30, align 8
  store i64 %v5924, ptr %slot1082, align 8
  %v5925 = load i64, ptr %slot27, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  %ld5927 = load i32, ptr %p5926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5927, ptr %slot1083, align 8
  %v5928 = load i32, ptr %slot1083, align 8
  %op5929 = and i32 %v5928, 28
  store i32 %op5929, ptr %slot1084, align 8
  %v5930 = load i32, ptr %slot1084, align 8
  %cv5931 = zext i32 %v5930 to i64
  %cond5932 = icmp ne i64 %cv5931, 0
  br i1 %cond5932, label %bb_rcslotrole1990, label %bb_rcslotowner1990
bb_rcslotrole1990:
  %v5933 = load i64, ptr %slot56, align 8
  store i64 %v5933, ptr %slot1085, align 8
  %v5934 = load i64, ptr %slot1085, align 8
  %v5935 = load i64, ptr %slot1082, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v5934, i64 %v5935) nomerge, !dbg !158
  br label %bb_rcslotdone1990
bb_rcslotowner1990:
  %v5936 = load i64, ptr %slot56, align 8
  store i64 %v5936, ptr %slot1086, align 8
  %v5937 = load i64, ptr %slot1086, align 8
  %v5938 = load i64, ptr %slot1082, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v5937, i64 %v5938) nomerge, !dbg !158
  br label %bb_rcslotdone1990
bb_rcslotdone1990:
  %v5939 = load i64, ptr %slot30, align 8
  store i64 %v5939, ptr %slot1087, align 8
  %v5940 = load i64, ptr %slot31, align 8
  store i64 %v5940, ptr %slot1088, align 8
  %v5941 = load i64, ptr %slot1088, align 8
  %v5942 = load i64, ptr %slot1087, align 8
  %p5943 = inttoptr i64 %v5941 to ptr
  %p5944 = inttoptr i64 %v5942 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5944, ptr %p5943, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v5945 = load i64, ptr %slot27, align 8
  %p5946 = inttoptr i64 %v5945 to ptr
  store i32 2, ptr %p5946, align 4, !alias.scope !3, !noalias !4
  %v5947 = load i64, ptr %slot29, align 8
  %p5948 = inttoptr i64 %v5947 to ptr
  %ld5949 = load i32, ptr %p5948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5949, ptr %slot1089, align 8
  %v5950 = load i32, ptr %slot1089, align 8
  %v5951 = load i64, ptr %slot27, align 8
  %p5952 = inttoptr i64 %v5951 to ptr
  store i32 %v5950, ptr %p5952, align 4, !alias.scope !3, !noalias !4
  %v5953 = load i64, ptr %slot28, align 8
  %p5954 = inttoptr i64 %v5953 to ptr
  store i32 0, ptr %p5954, align 4, !alias.scope !3, !noalias !4
  %v5955 = load i64, ptr %slot26, align 8
  %p5956 = inttoptr i64 %v5955 to ptr
  store i32 1, ptr %p5956, align 4, !alias.scope !3, !noalias !4
  %v5957 = load i64, ptr %slot1087, align 8
  %v5958 = load i64, ptr %slot47, align 8
  %p5959 = inttoptr i64 %v5958 to ptr
  store i64 %v5957, ptr %p5959, align 8, !alias.scope !3, !noalias !4
  %v5960 = load i64, ptr %slot47, align 8
  %p5961 = inttoptr i64 %v5960 to ptr
  %ld5962 = load i64, ptr %p5961, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5962, ptr %slot1090, align 8
  %v5963 = load i64, ptr %slot1090, align 8
  %p5964 = inttoptr i64 %v5963 to ptr
  %ld5965 = load i32, ptr %p5964, align 4, !alias.scope !3, !noalias !4
  %ext5966 = zext i32 %ld5965 to i64
  store i64 %ext5966, ptr %slot1091, align 8
  %v5967 = load i64, ptr %slot1091, align 8
  %cmp5968 = icmp eq i64 %v5967, 1
  %cv5969 = zext i1 %cmp5968 to i64
  store i64 %cv5969, ptr %slot1092, align 8
  %v5970 = load i64, ptr %slot1092, align 8
  %cond5971 = icmp ne i64 %v5970, 0
  br i1 %cond5971, label %bb_errtrace2016, label %bb_errtraced2016
bb_errtrace2016:
  %p5972 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p5972, i64 8589934646) "call-inline-cost"="0", !dbg !160
  br label %bb_errtraced2016
bb_errtraced2016:
  %v5973 = load i64, ptr %slot47, align 8
  %p5974 = inttoptr i64 %v5973 to ptr
  %ld5975 = load i64, ptr %p5974, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5975, ptr %slot1093, align 8
  %v5976 = load i64, ptr %slot31, align 8
  store i64 %v5976, ptr %slot1094, align 8
  %v5977 = load i64, ptr %slot57, align 8
  store i64 %v5977, ptr %slot1095, align 8
  %v5978 = load i64, ptr %slot56, align 8
  %v5979 = load i64, ptr %slot1094, align 8
  %v5980 = load i64, ptr %slot1093, align 8
  %v5981 = load i64, ptr %slot1095, align 8
  %cv5982 = trunc i64 %v5981 to i32
  %call5983 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v5978, i64 %v5979, i64 %v5980, i32 %cv5982) nomerge, !dbg !160
  store i32 %call5983, ptr %slot1096, align 8
  %v5984 = load i32, ptr %slot1096, align 8
  %cv5985 = zext i32 %v5984 to i64
  %cond5986 = icmp ne i64 %cv5985, 0
  br i1 %cond5986, label %bb_rcsuccess2021, label %bb_rcfailure2021
bb_rcfailure2021:
  %v5987 = load i64, ptr %slot56, align 8
  %p5988 = inttoptr i64 %v5987 to ptr
  %call5989 = call i32 @myl_rc_take_failure(ptr %p5988) nomerge, !dbg !160
  store i32 %call5989, ptr %slot1097, align 8
  %v5990 = load i64, ptr %slot1, align 8
  %p5991 = inttoptr i64 %v5990 to ptr
  %v5992 = load i32, ptr %slot1097, align 8
  %call5993 = call i32 @myl_qbe_rc_status(ptr %p5991, i32 %v5992) nomerge, !dbg !160
  store i32 %call5993, ptr %slot1098, align 8
  br label %bb_failure
bb_rcsuccess2021:
  %v5994 = load i64, ptr %slot26, align 8
  %p5995 = inttoptr i64 %v5994 to ptr
  store i32 0, ptr %p5995, align 4, !alias.scope !3, !noalias !4
  %v5996 = load i64, ptr %slot29, align 8
  %p5997 = inttoptr i64 %v5996 to ptr
  store i32 2, ptr %p5997, align 4, !alias.scope !3, !noalias !4
  %v5998 = load i64, ptr %slot28, align 8
  %p5999 = inttoptr i64 %v5998 to ptr
  store i32 1, ptr %p5999, align 4, !alias.scope !3, !noalias !4
  %v6000 = load i64, ptr %slot31, align 8
  store i64 %v6000, ptr %slot1099, align 8
  %v6001 = load i64, ptr %slot28, align 8
  %p6002 = inttoptr i64 %v6001 to ptr
  store i32 0, ptr %p6002, align 4, !alias.scope !3, !noalias !4
  %v6003 = load i64, ptr %slot26, align 8
  %p6004 = inttoptr i64 %v6003 to ptr
  %ld6005 = load i32, ptr %p6004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6005, ptr %slot1100, align 8
  %v6006 = load i32, ptr %slot1100, align 8
  %cv6007 = zext i32 %v6006 to i64
  %cond6008 = icmp ne i64 %cv6007, 0
  br i1 %cond6008, label %bb_rcslotdrop2031, label %bb_rcslotdone2031
bb_rcslotdrop2031:
  %v6009 = load i64, ptr %slot26, align 8
  %p6010 = inttoptr i64 %v6009 to ptr
  store i32 0, ptr %p6010, align 4, !alias.scope !3, !noalias !4
  %v6011 = load i64, ptr %slot30, align 8
  store i64 %v6011, ptr %slot1101, align 8
  %v6012 = load i64, ptr %slot27, align 8
  %p6013 = inttoptr i64 %v6012 to ptr
  %ld6014 = load i32, ptr %p6013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6014, ptr %slot1102, align 8
  %v6015 = load i32, ptr %slot1102, align 8
  %op6016 = and i32 %v6015, 28
  store i32 %op6016, ptr %slot1103, align 8
  %v6017 = load i32, ptr %slot1103, align 8
  %cv6018 = zext i32 %v6017 to i64
  %cond6019 = icmp ne i64 %cv6018, 0
  br i1 %cond6019, label %bb_rcslotrole2031, label %bb_rcslotowner2031
bb_rcslotrole2031:
  %v6020 = load i64, ptr %slot56, align 8
  store i64 %v6020, ptr %slot1104, align 8
  %v6021 = load i64, ptr %slot1104, align 8
  %v6022 = load i64, ptr %slot1101, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v6021, i64 %v6022) nomerge, !dbg !160
  br label %bb_rcslotdone2031
bb_rcslotowner2031:
  %v6023 = load i64, ptr %slot56, align 8
  store i64 %v6023, ptr %slot1105, align 8
  %v6024 = load i64, ptr %slot1105, align 8
  %v6025 = load i64, ptr %slot1101, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v6024, i64 %v6025) nomerge, !dbg !160
  br label %bb_rcslotdone2031
bb_rcslotdone2031:
  %v6026 = load i64, ptr %slot24, align 8
  %p6027 = inttoptr i64 %v6026 to ptr
  %ld6028 = load i32, ptr %p6027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6028, ptr %slot1106, align 8
  %v6029 = load i32, ptr %slot1106, align 8
  %cv6030 = zext i32 %v6029 to i64
  %cond6031 = icmp ne i64 %cv6030, 0
  br i1 %cond6031, label %bb_rcslotdrop2040, label %bb_rcslotdone2040
bb_rcslotdrop2040:
  %v6032 = load i64, ptr %slot24, align 8
  %p6033 = inttoptr i64 %v6032 to ptr
  store i32 0, ptr %p6033, align 4, !alias.scope !3, !noalias !4
  %v6034 = load i64, ptr %slot46, align 8
  store i64 %v6034, ptr %slot1107, align 8
  %v6035 = load i64, ptr %slot25, align 8
  %p6036 = inttoptr i64 %v6035 to ptr
  %ld6037 = load i32, ptr %p6036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6037, ptr %slot1108, align 8
  %v6038 = load i32, ptr %slot1108, align 8
  %op6039 = and i32 %v6038, 28
  store i32 %op6039, ptr %slot1109, align 8
  %v6040 = load i32, ptr %slot1109, align 8
  %cv6041 = zext i32 %v6040 to i64
  %cond6042 = icmp ne i64 %cv6041, 0
  br i1 %cond6042, label %bb_rcslotrole2040, label %bb_rcslotowner2040
bb_rcslotrole2040:
  %v6043 = load i64, ptr %slot56, align 8
  store i64 %v6043, ptr %slot1110, align 8
  %v6044 = load i64, ptr %slot1110, align 8
  %v6045 = load i64, ptr %slot1107, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v6044, i64 %v6045) nomerge, !dbg !160
  br label %bb_rcslotdone2040
bb_rcslotowner2040:
  %v6046 = load i64, ptr %slot56, align 8
  store i64 %v6046, ptr %slot1111, align 8
  %v6047 = load i64, ptr %slot1111, align 8
  %v6048 = load i64, ptr %slot1107, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v6047, i64 %v6048) nomerge, !dbg !160
  br label %bb_rcslotdone2040
bb_rcslotdone2040:
  %v6049 = load i64, ptr %slot22, align 8
  %p6050 = inttoptr i64 %v6049 to ptr
  %ld6051 = load i32, ptr %p6050, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6051, ptr %slot1112, align 8
  %v6052 = load i32, ptr %slot1112, align 8
  %cv6053 = zext i32 %v6052 to i64
  %cond6054 = icmp ne i64 %cv6053, 0
  br i1 %cond6054, label %bb_rcslotdrop2049, label %bb_rcslotdone2049
bb_rcslotdrop2049:
  %v6055 = load i64, ptr %slot22, align 8
  %p6056 = inttoptr i64 %v6055 to ptr
  store i32 0, ptr %p6056, align 4, !alias.scope !3, !noalias !4
  %v6057 = load i64, ptr %slot45, align 8
  store i64 %v6057, ptr %slot1113, align 8
  %v6058 = load i64, ptr %slot23, align 8
  %p6059 = inttoptr i64 %v6058 to ptr
  %ld6060 = load i32, ptr %p6059, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6060, ptr %slot1114, align 8
  %v6061 = load i32, ptr %slot1114, align 8
  %op6062 = and i32 %v6061, 28
  store i32 %op6062, ptr %slot1115, align 8
  %v6063 = load i32, ptr %slot1115, align 8
  %cv6064 = zext i32 %v6063 to i64
  %cond6065 = icmp ne i64 %cv6064, 0
  br i1 %cond6065, label %bb_rcslotrole2049, label %bb_rcslotowner2049
bb_rcslotrole2049:
  %v6066 = load i64, ptr %slot56, align 8
  store i64 %v6066, ptr %slot1116, align 8
  %v6067 = load i64, ptr %slot1116, align 8
  %v6068 = load i64, ptr %slot1113, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v6067, i64 %v6068) nomerge, !dbg !160
  br label %bb_rcslotdone2049
bb_rcslotowner2049:
  %v6069 = load i64, ptr %slot56, align 8
  store i64 %v6069, ptr %slot1117, align 8
  %v6070 = load i64, ptr %slot1117, align 8
  %v6071 = load i64, ptr %slot1113, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v6070, i64 %v6071) nomerge, !dbg !160
  br label %bb_rcslotdone2049
bb_rcslotdone2049:
  %v6072 = load i64, ptr %slot20, align 8
  %p6073 = inttoptr i64 %v6072 to ptr
  %ld6074 = load i32, ptr %p6073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6074, ptr %slot1118, align 8
  %v6075 = load i32, ptr %slot1118, align 8
  %cv6076 = zext i32 %v6075 to i64
  %cond6077 = icmp ne i64 %cv6076, 0
  br i1 %cond6077, label %bb_rcslotdrop2058, label %bb_rcslotdone2058
bb_rcslotdrop2058:
  %v6078 = load i64, ptr %slot20, align 8
  %p6079 = inttoptr i64 %v6078 to ptr
  store i32 0, ptr %p6079, align 4, !alias.scope !3, !noalias !4
  %v6080 = load i64, ptr %slot44, align 8
  store i64 %v6080, ptr %slot1119, align 8
  %v6081 = load i64, ptr %slot21, align 8
  %p6082 = inttoptr i64 %v6081 to ptr
  %ld6083 = load i32, ptr %p6082, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6083, ptr %slot1120, align 8
  %v6084 = load i32, ptr %slot1120, align 8
  %op6085 = and i32 %v6084, 28
  store i32 %op6085, ptr %slot1121, align 8
  %v6086 = load i32, ptr %slot1121, align 8
  %cv6087 = zext i32 %v6086 to i64
  %cond6088 = icmp ne i64 %cv6087, 0
  br i1 %cond6088, label %bb_rcslotrole2058, label %bb_rcslotowner2058
bb_rcslotrole2058:
  %v6089 = load i64, ptr %slot56, align 8
  store i64 %v6089, ptr %slot1122, align 8
  %v6090 = load i64, ptr %slot1122, align 8
  %v6091 = load i64, ptr %slot1119, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v6090, i64 %v6091) nomerge, !dbg !160
  br label %bb_rcslotdone2058
bb_rcslotowner2058:
  %v6092 = load i64, ptr %slot56, align 8
  store i64 %v6092, ptr %slot1123, align 8
  %v6093 = load i64, ptr %slot1123, align 8
  %v6094 = load i64, ptr %slot1119, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v6093, i64 %v6094) nomerge, !dbg !160
  br label %bb_rcslotdone2058
bb_rcslotdone2058:
  %v6095 = load i64, ptr %slot18, align 8
  %p6096 = inttoptr i64 %v6095 to ptr
  %ld6097 = load i32, ptr %p6096, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6097, ptr %slot1124, align 8
  %v6098 = load i32, ptr %slot1124, align 8
  %cv6099 = zext i32 %v6098 to i64
  %cond6100 = icmp ne i64 %cv6099, 0
  br i1 %cond6100, label %bb_rcslotdrop2067, label %bb_rcslotdone2067
bb_rcslotdrop2067:
  %v6101 = load i64, ptr %slot18, align 8
  %p6102 = inttoptr i64 %v6101 to ptr
  store i32 0, ptr %p6102, align 4, !alias.scope !3, !noalias !4
  %v6103 = load i64, ptr %slot43, align 8
  store i64 %v6103, ptr %slot1125, align 8
  %v6104 = load i64, ptr %slot19, align 8
  %p6105 = inttoptr i64 %v6104 to ptr
  %ld6106 = load i32, ptr %p6105, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6106, ptr %slot1126, align 8
  %v6107 = load i32, ptr %slot1126, align 8
  %op6108 = and i32 %v6107, 28
  store i32 %op6108, ptr %slot1127, align 8
  %v6109 = load i32, ptr %slot1127, align 8
  %cv6110 = zext i32 %v6109 to i64
  %cond6111 = icmp ne i64 %cv6110, 0
  br i1 %cond6111, label %bb_rcslotrole2067, label %bb_rcslotowner2067
bb_rcslotrole2067:
  %v6112 = load i64, ptr %slot56, align 8
  store i64 %v6112, ptr %slot1128, align 8
  %v6113 = load i64, ptr %slot1128, align 8
  %v6114 = load i64, ptr %slot1125, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v6113, i64 %v6114) nomerge, !dbg !160
  br label %bb_rcslotdone2067
bb_rcslotowner2067:
  %v6115 = load i64, ptr %slot56, align 8
  store i64 %v6115, ptr %slot1129, align 8
  %v6116 = load i64, ptr %slot1129, align 8
  %v6117 = load i64, ptr %slot1125, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v6116, i64 %v6117) nomerge, !dbg !160
  br label %bb_rcslotdone2067
bb_rcslotdone2067:
  %v6118 = load i64, ptr %slot16, align 8
  %p6119 = inttoptr i64 %v6118 to ptr
  %ld6120 = load i32, ptr %p6119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6120, ptr %slot1130, align 8
  %v6121 = load i32, ptr %slot1130, align 8
  %cv6122 = zext i32 %v6121 to i64
  %cond6123 = icmp ne i64 %cv6122, 0
  br i1 %cond6123, label %bb_rcslotdrop2076, label %bb_rcslotdone2076
bb_rcslotdrop2076:
  %v6124 = load i64, ptr %slot16, align 8
  %p6125 = inttoptr i64 %v6124 to ptr
  store i32 0, ptr %p6125, align 4, !alias.scope !3, !noalias !4
  %v6126 = load i64, ptr %slot42, align 8
  store i64 %v6126, ptr %slot1131, align 8
  %v6127 = load i64, ptr %slot17, align 8
  %p6128 = inttoptr i64 %v6127 to ptr
  %ld6129 = load i32, ptr %p6128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6129, ptr %slot1132, align 8
  %v6130 = load i32, ptr %slot1132, align 8
  %op6131 = and i32 %v6130, 28
  store i32 %op6131, ptr %slot1133, align 8
  %v6132 = load i32, ptr %slot1133, align 8
  %cv6133 = zext i32 %v6132 to i64
  %cond6134 = icmp ne i64 %cv6133, 0
  br i1 %cond6134, label %bb_rcslotrole2076, label %bb_rcslotowner2076
bb_rcslotrole2076:
  %v6135 = load i64, ptr %slot56, align 8
  store i64 %v6135, ptr %slot1134, align 8
  %v6136 = load i64, ptr %slot1134, align 8
  %v6137 = load i64, ptr %slot1131, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v6136, i64 %v6137) nomerge, !dbg !160
  br label %bb_rcslotdone2076
bb_rcslotowner2076:
  %v6138 = load i64, ptr %slot56, align 8
  store i64 %v6138, ptr %slot1135, align 8
  %v6139 = load i64, ptr %slot1135, align 8
  %v6140 = load i64, ptr %slot1131, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v6139, i64 %v6140) nomerge, !dbg !160
  br label %bb_rcslotdone2076
bb_rcslotdone2076:
  %v6141 = load i64, ptr %slot14, align 8
  %p6142 = inttoptr i64 %v6141 to ptr
  %ld6143 = load i32, ptr %p6142, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6143, ptr %slot1136, align 8
  %v6144 = load i32, ptr %slot1136, align 8
  %cv6145 = zext i32 %v6144 to i64
  %cond6146 = icmp ne i64 %cv6145, 0
  br i1 %cond6146, label %bb_rcslotdrop2085, label %bb_rcslotdone2085
bb_rcslotdrop2085:
  %v6147 = load i64, ptr %slot14, align 8
  %p6148 = inttoptr i64 %v6147 to ptr
  store i32 0, ptr %p6148, align 4, !alias.scope !3, !noalias !4
  %v6149 = load i64, ptr %slot41, align 8
  store i64 %v6149, ptr %slot1137, align 8
  %v6150 = load i64, ptr %slot15, align 8
  %p6151 = inttoptr i64 %v6150 to ptr
  %ld6152 = load i32, ptr %p6151, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6152, ptr %slot1138, align 8
  %v6153 = load i32, ptr %slot1138, align 8
  %op6154 = and i32 %v6153, 28
  store i32 %op6154, ptr %slot1139, align 8
  %v6155 = load i32, ptr %slot1139, align 8
  %cv6156 = zext i32 %v6155 to i64
  %cond6157 = icmp ne i64 %cv6156, 0
  br i1 %cond6157, label %bb_rcslotrole2085, label %bb_rcslotowner2085
bb_rcslotrole2085:
  %v6158 = load i64, ptr %slot56, align 8
  store i64 %v6158, ptr %slot1140, align 8
  %v6159 = load i64, ptr %slot1140, align 8
  %v6160 = load i64, ptr %slot1137, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v6159, i64 %v6160) nomerge, !dbg !160
  br label %bb_rcslotdone2085
bb_rcslotowner2085:
  %v6161 = load i64, ptr %slot56, align 8
  store i64 %v6161, ptr %slot1141, align 8
  %v6162 = load i64, ptr %slot1141, align 8
  %v6163 = load i64, ptr %slot1137, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v6162, i64 %v6163) nomerge, !dbg !160
  br label %bb_rcslotdone2085
bb_rcslotdone2085:
  %v6164 = load i64, ptr %slot12, align 8
  %p6165 = inttoptr i64 %v6164 to ptr
  %ld6166 = load i32, ptr %p6165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6166, ptr %slot1142, align 8
  %v6167 = load i32, ptr %slot1142, align 8
  %cv6168 = zext i32 %v6167 to i64
  %cond6169 = icmp ne i64 %cv6168, 0
  br i1 %cond6169, label %bb_rcslotdrop2094, label %bb_rcslotdone2094
bb_rcslotdrop2094:
  %v6170 = load i64, ptr %slot12, align 8
  %p6171 = inttoptr i64 %v6170 to ptr
  store i32 0, ptr %p6171, align 4, !alias.scope !3, !noalias !4
  %v6172 = load i64, ptr %slot40, align 8
  store i64 %v6172, ptr %slot1143, align 8
  %v6173 = load i64, ptr %slot13, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  %ld6175 = load i32, ptr %p6174, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6175, ptr %slot1144, align 8
  %v6176 = load i32, ptr %slot1144, align 8
  %op6177 = and i32 %v6176, 28
  store i32 %op6177, ptr %slot1145, align 8
  %v6178 = load i32, ptr %slot1145, align 8
  %cv6179 = zext i32 %v6178 to i64
  %cond6180 = icmp ne i64 %cv6179, 0
  br i1 %cond6180, label %bb_rcslotrole2094, label %bb_rcslotowner2094
bb_rcslotrole2094:
  %v6181 = load i64, ptr %slot56, align 8
  store i64 %v6181, ptr %slot1146, align 8
  %v6182 = load i64, ptr %slot1146, align 8
  %v6183 = load i64, ptr %slot1143, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v6182, i64 %v6183) nomerge, !dbg !160
  br label %bb_rcslotdone2094
bb_rcslotowner2094:
  %v6184 = load i64, ptr %slot56, align 8
  store i64 %v6184, ptr %slot1147, align 8
  %v6185 = load i64, ptr %slot1147, align 8
  %v6186 = load i64, ptr %slot1143, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v6185, i64 %v6186) nomerge, !dbg !160
  br label %bb_rcslotdone2094
bb_rcslotdone2094:
  %v6187 = load i64, ptr %slot10, align 8
  %p6188 = inttoptr i64 %v6187 to ptr
  %ld6189 = load i32, ptr %p6188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6189, ptr %slot1148, align 8
  %v6190 = load i32, ptr %slot1148, align 8
  %cv6191 = zext i32 %v6190 to i64
  %cond6192 = icmp ne i64 %cv6191, 0
  br i1 %cond6192, label %bb_rcslotdrop2103, label %bb_rcslotdone2103
bb_rcslotdrop2103:
  %v6193 = load i64, ptr %slot10, align 8
  %p6194 = inttoptr i64 %v6193 to ptr
  store i32 0, ptr %p6194, align 4, !alias.scope !3, !noalias !4
  %v6195 = load i64, ptr %slot38, align 8
  store i64 %v6195, ptr %slot1149, align 8
  %v6196 = load i64, ptr %slot11, align 8
  %p6197 = inttoptr i64 %v6196 to ptr
  %ld6198 = load i32, ptr %p6197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6198, ptr %slot1150, align 8
  %v6199 = load i32, ptr %slot1150, align 8
  %op6200 = and i32 %v6199, 28
  store i32 %op6200, ptr %slot1151, align 8
  %v6201 = load i32, ptr %slot1151, align 8
  %cv6202 = zext i32 %v6201 to i64
  %cond6203 = icmp ne i64 %cv6202, 0
  br i1 %cond6203, label %bb_rcslotrole2103, label %bb_rcslotowner2103
bb_rcslotrole2103:
  %v6204 = load i64, ptr %slot56, align 8
  store i64 %v6204, ptr %slot1152, align 8
  %v6205 = load i64, ptr %slot1152, align 8
  %v6206 = load i64, ptr %slot1149, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v6205, i64 %v6206) nomerge, !dbg !160
  br label %bb_rcslotdone2103
bb_rcslotowner2103:
  %v6207 = load i64, ptr %slot56, align 8
  store i64 %v6207, ptr %slot1153, align 8
  %v6208 = load i64, ptr %slot1153, align 8
  %v6209 = load i64, ptr %slot1149, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v6208, i64 %v6209) nomerge, !dbg !160
  br label %bb_rcslotdone2103
bb_rcslotdone2103:
  %v6210 = load i64, ptr %slot8, align 8
  %p6211 = inttoptr i64 %v6210 to ptr
  %ld6212 = load i32, ptr %p6211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6212, ptr %slot1154, align 8
  %v6213 = load i32, ptr %slot1154, align 8
  %cv6214 = zext i32 %v6213 to i64
  %cond6215 = icmp ne i64 %cv6214, 0
  br i1 %cond6215, label %bb_rcslotdrop2112, label %bb_rcslotdone2112
bb_rcslotdrop2112:
  %v6216 = load i64, ptr %slot8, align 8
  %p6217 = inttoptr i64 %v6216 to ptr
  store i32 0, ptr %p6217, align 4, !alias.scope !3, !noalias !4
  %v6218 = load i64, ptr %slot37, align 8
  store i64 %v6218, ptr %slot1155, align 8
  %v6219 = load i64, ptr %slot9, align 8
  %p6220 = inttoptr i64 %v6219 to ptr
  %ld6221 = load i32, ptr %p6220, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6221, ptr %slot1156, align 8
  %v6222 = load i32, ptr %slot1156, align 8
  %op6223 = and i32 %v6222, 28
  store i32 %op6223, ptr %slot1157, align 8
  %v6224 = load i32, ptr %slot1157, align 8
  %cv6225 = zext i32 %v6224 to i64
  %cond6226 = icmp ne i64 %cv6225, 0
  br i1 %cond6226, label %bb_rcslotrole2112, label %bb_rcslotowner2112
bb_rcslotrole2112:
  %v6227 = load i64, ptr %slot56, align 8
  store i64 %v6227, ptr %slot1158, align 8
  %v6228 = load i64, ptr %slot1158, align 8
  %v6229 = load i64, ptr %slot1155, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v6228, i64 %v6229) nomerge, !dbg !160
  br label %bb_rcslotdone2112
bb_rcslotowner2112:
  %v6230 = load i64, ptr %slot56, align 8
  store i64 %v6230, ptr %slot1159, align 8
  %v6231 = load i64, ptr %slot1159, align 8
  %v6232 = load i64, ptr %slot1155, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v6231, i64 %v6232) nomerge, !dbg !160
  br label %bb_rcslotdone2112
bb_rcslotdone2112:
  %v6233 = load i64, ptr %slot6, align 8
  %p6234 = inttoptr i64 %v6233 to ptr
  %ld6235 = load i32, ptr %p6234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6235, ptr %slot1160, align 8
  %v6236 = load i32, ptr %slot1160, align 8
  %cv6237 = zext i32 %v6236 to i64
  %cond6238 = icmp ne i64 %cv6237, 0
  br i1 %cond6238, label %bb_rcslotdrop2121, label %bb_rcslotdone2121
bb_rcslotdrop2121:
  %v6239 = load i64, ptr %slot6, align 8
  %p6240 = inttoptr i64 %v6239 to ptr
  store i32 0, ptr %p6240, align 4, !alias.scope !3, !noalias !4
  %v6241 = load i64, ptr %slot36, align 8
  store i64 %v6241, ptr %slot1161, align 8
  %v6242 = load i64, ptr %slot7, align 8
  %p6243 = inttoptr i64 %v6242 to ptr
  %ld6244 = load i32, ptr %p6243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6244, ptr %slot1162, align 8
  %v6245 = load i32, ptr %slot1162, align 8
  %op6246 = and i32 %v6245, 28
  store i32 %op6246, ptr %slot1163, align 8
  %v6247 = load i32, ptr %slot1163, align 8
  %cv6248 = zext i32 %v6247 to i64
  %cond6249 = icmp ne i64 %cv6248, 0
  br i1 %cond6249, label %bb_rcslotrole2121, label %bb_rcslotowner2121
bb_rcslotrole2121:
  %v6250 = load i64, ptr %slot56, align 8
  store i64 %v6250, ptr %slot1164, align 8
  %v6251 = load i64, ptr %slot1164, align 8
  %v6252 = load i64, ptr %slot1161, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v6251, i64 %v6252) nomerge, !dbg !160
  br label %bb_rcslotdone2121
bb_rcslotowner2121:
  %v6253 = load i64, ptr %slot56, align 8
  store i64 %v6253, ptr %slot1165, align 8
  %v6254 = load i64, ptr %slot1165, align 8
  %v6255 = load i64, ptr %slot1161, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v6254, i64 %v6255) nomerge, !dbg !160
  br label %bb_rcslotdone2121
bb_rcslotdone2121:
  %v6256 = load i64, ptr %slot1099, align 8
  %p6257 = inttoptr i64 %v6256 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6257, i64 24, i1 false)
  ret void
bb_i55:
  %v6258 = load i64, ptr %slot32, align 8
  %p6259 = inttoptr i64 %v6258 to ptr
  %ld6260 = load i64, ptr %p6259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6260, ptr %slot1166, align 8
  %v6261 = load i64, ptr %slot1166, align 8
  %v6262 = load i64, ptr %slot47, align 8
  %p6263 = inttoptr i64 %v6262 to ptr
  store i64 %v6261, ptr %p6263, align 8, !alias.scope !3, !noalias !4
  %v6264 = load i64, ptr %slot44, align 8
  %v6265 = load i64, ptr %slot48, align 8
  %p6266 = inttoptr i64 %v6265 to ptr
  store i64 %v6264, ptr %p6266, align 8, !alias.scope !3, !noalias !4
  %v6267 = load i64, ptr %slot47, align 8
  %p6268 = inttoptr i64 %v6267 to ptr
  %ld6269 = load i64, ptr %p6268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6269, ptr %slot1167, align 8
  %v6270 = load i64, ptr %slot48, align 8
  %p6271 = inttoptr i64 %v6270 to ptr
  %ld6272 = load i64, ptr %p6271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6272, ptr %slot1168, align 8
  %v6273 = load i64, ptr %slot1, align 8
  %v6274 = load i64, ptr %slot1167, align 8
  %v6275 = load i64, ptr %slot1168, align 8
  call void @myl_f_3dd24b2b8167f92811eb1aa75d06c05872b9880d7f900833ae7f6f032a592152(ptr sret([24 x i8]) align 8 %callresult1170, i64 %v6273, i64 %v6274, i64 %v6275) nomerge, !dbg !162
  %addr6276 = ptrtoint ptr %callresult1170 to i64
  store i64 %addr6276, ptr %slot1169, align 8
  %v6277 = load i64, ptr %slot1169, align 8
  %v6278 = load i64, ptr %slot47, align 8
  %p6279 = inttoptr i64 %v6278 to ptr
  store i64 %v6277, ptr %p6279, align 8, !alias.scope !3, !noalias !4
  %v6280 = load i64, ptr %slot47, align 8
  %p6281 = inttoptr i64 %v6280 to ptr
  %ld6282 = load i64, ptr %p6281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6282, ptr %slot1171, align 8
  %v6283 = load i64, ptr %slot31, align 8
  store i64 %v6283, ptr %slot1172, align 8
  %v6284 = load i64, ptr %slot1171, align 8
  %v6285 = load i64, ptr %slot1172, align 8
  %p6286 = inttoptr i64 %v6284 to ptr
  %p6287 = inttoptr i64 %v6285 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6287, ptr %p6286, i64 24, i1 false)
  %v6288 = load i64, ptr %slot29, align 8
  %p6289 = inttoptr i64 %v6288 to ptr
  store i32 2, ptr %p6289, align 4, !alias.scope !3, !noalias !4
  %v6290 = load i64, ptr %slot28, align 8
  %p6291 = inttoptr i64 %v6290 to ptr
  store i32 1, ptr %p6291, align 4, !alias.scope !3, !noalias !4
  %v6292 = load i64, ptr %slot26, align 8
  %p6293 = inttoptr i64 %v6292 to ptr
  %ld6294 = load i32, ptr %p6293, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6294, ptr %slot1173, align 8
  %v6295 = load i32, ptr %slot1173, align 8
  %cv6296 = zext i32 %v6295 to i64
  %cond6297 = icmp ne i64 %cv6296, 0
  br i1 %cond6297, label %bb_rcslotdrop2184, label %bb_rcslotdone2184
bb_rcslotdrop2184:
  %v6298 = load i64, ptr %slot26, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  store i32 0, ptr %p6299, align 4, !alias.scope !3, !noalias !4
  %v6300 = load i64, ptr %slot30, align 8
  store i64 %v6300, ptr %slot1174, align 8
  %v6301 = load i64, ptr %slot27, align 8
  %p6302 = inttoptr i64 %v6301 to ptr
  %ld6303 = load i32, ptr %p6302, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6303, ptr %slot1175, align 8
  %v6304 = load i32, ptr %slot1175, align 8
  %op6305 = and i32 %v6304, 28
  store i32 %op6305, ptr %slot1176, align 8
  %v6306 = load i32, ptr %slot1176, align 8
  %cv6307 = zext i32 %v6306 to i64
  %cond6308 = icmp ne i64 %cv6307, 0
  br i1 %cond6308, label %bb_rcslotrole2184, label %bb_rcslotowner2184
bb_rcslotrole2184:
  %v6309 = load i64, ptr %slot56, align 8
  store i64 %v6309, ptr %slot1177, align 8
  %v6310 = load i64, ptr %slot1177, align 8
  %v6311 = load i64, ptr %slot1174, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v6310, i64 %v6311) nomerge, !dbg !162
  br label %bb_rcslotdone2184
bb_rcslotowner2184:
  %v6312 = load i64, ptr %slot56, align 8
  store i64 %v6312, ptr %slot1178, align 8
  %v6313 = load i64, ptr %slot1178, align 8
  %v6314 = load i64, ptr %slot1174, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v6313, i64 %v6314) nomerge, !dbg !162
  br label %bb_rcslotdone2184
bb_rcslotdone2184:
  %v6315 = load i64, ptr %slot30, align 8
  store i64 %v6315, ptr %slot1179, align 8
  %v6316 = load i64, ptr %slot31, align 8
  store i64 %v6316, ptr %slot1180, align 8
  %v6317 = load i64, ptr %slot1180, align 8
  %v6318 = load i64, ptr %slot1179, align 8
  %p6319 = inttoptr i64 %v6317 to ptr
  %p6320 = inttoptr i64 %v6318 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6320, ptr %p6319, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6321 = load i64, ptr %slot27, align 8
  %p6322 = inttoptr i64 %v6321 to ptr
  store i32 2, ptr %p6322, align 4, !alias.scope !3, !noalias !4
  %v6323 = load i64, ptr %slot29, align 8
  %p6324 = inttoptr i64 %v6323 to ptr
  %ld6325 = load i32, ptr %p6324, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6325, ptr %slot1181, align 8
  %v6326 = load i32, ptr %slot1181, align 8
  %v6327 = load i64, ptr %slot27, align 8
  %p6328 = inttoptr i64 %v6327 to ptr
  store i32 %v6326, ptr %p6328, align 4, !alias.scope !3, !noalias !4
  %v6329 = load i64, ptr %slot28, align 8
  %p6330 = inttoptr i64 %v6329 to ptr
  store i32 0, ptr %p6330, align 4, !alias.scope !3, !noalias !4
  %v6331 = load i64, ptr %slot26, align 8
  %p6332 = inttoptr i64 %v6331 to ptr
  store i32 1, ptr %p6332, align 4, !alias.scope !3, !noalias !4
  %v6333 = load i64, ptr %slot1179, align 8
  %v6334 = load i64, ptr %slot47, align 8
  %p6335 = inttoptr i64 %v6334 to ptr
  store i64 %v6333, ptr %p6335, align 8, !alias.scope !3, !noalias !4
  %v6336 = load i64, ptr %slot47, align 8
  %p6337 = inttoptr i64 %v6336 to ptr
  %ld6338 = load i64, ptr %p6337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6338, ptr %slot1182, align 8
  %v6339 = load i64, ptr %slot1182, align 8
  %p6340 = inttoptr i64 %v6339 to ptr
  %ld6341 = load i32, ptr %p6340, align 4, !alias.scope !3, !noalias !4
  %ext6342 = zext i32 %ld6341 to i64
  store i64 %ext6342, ptr %slot1183, align 8
  %v6343 = load i64, ptr %slot1183, align 8
  %cmp6344 = icmp eq i64 %v6343, 1
  %cv6345 = zext i1 %cmp6344 to i64
  store i64 %cv6345, ptr %slot1184, align 8
  %v6346 = load i64, ptr %slot1184, align 8
  %cond6347 = icmp ne i64 %v6346, 0
  br i1 %cond6347, label %bb_errtrace2210, label %bb_errtraced2210
bb_errtrace2210:
  %p6348 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p6348, i64 8589934650) "call-inline-cost"="0", !dbg !164
  br label %bb_errtraced2210
bb_errtraced2210:
  %v6349 = load i64, ptr %slot47, align 8
  %p6350 = inttoptr i64 %v6349 to ptr
  %ld6351 = load i64, ptr %p6350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6351, ptr %slot1185, align 8
  %v6352 = load i64, ptr %slot31, align 8
  store i64 %v6352, ptr %slot1186, align 8
  %v6353 = load i64, ptr %slot57, align 8
  store i64 %v6353, ptr %slot1187, align 8
  %v6354 = load i64, ptr %slot56, align 8
  %v6355 = load i64, ptr %slot1186, align 8
  %v6356 = load i64, ptr %slot1185, align 8
  %v6357 = load i64, ptr %slot1187, align 8
  %cv6358 = trunc i64 %v6357 to i32
  %call6359 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v6354, i64 %v6355, i64 %v6356, i32 %cv6358) nomerge, !dbg !164
  store i32 %call6359, ptr %slot1188, align 8
  %v6360 = load i32, ptr %slot1188, align 8
  %cv6361 = zext i32 %v6360 to i64
  %cond6362 = icmp ne i64 %cv6361, 0
  br i1 %cond6362, label %bb_rcsuccess2215, label %bb_rcfailure2215
bb_rcfailure2215:
  %v6363 = load i64, ptr %slot56, align 8
  %p6364 = inttoptr i64 %v6363 to ptr
  %call6365 = call i32 @myl_rc_take_failure(ptr %p6364) nomerge, !dbg !164
  store i32 %call6365, ptr %slot1189, align 8
  %v6366 = load i64, ptr %slot1, align 8
  %p6367 = inttoptr i64 %v6366 to ptr
  %v6368 = load i32, ptr %slot1189, align 8
  %call6369 = call i32 @myl_qbe_rc_status(ptr %p6367, i32 %v6368) nomerge, !dbg !164
  store i32 %call6369, ptr %slot1190, align 8
  br label %bb_failure
bb_rcsuccess2215:
  %v6370 = load i64, ptr %slot26, align 8
  %p6371 = inttoptr i64 %v6370 to ptr
  store i32 0, ptr %p6371, align 4, !alias.scope !3, !noalias !4
  %v6372 = load i64, ptr %slot29, align 8
  %p6373 = inttoptr i64 %v6372 to ptr
  store i32 2, ptr %p6373, align 4, !alias.scope !3, !noalias !4
  %v6374 = load i64, ptr %slot28, align 8
  %p6375 = inttoptr i64 %v6374 to ptr
  store i32 1, ptr %p6375, align 4, !alias.scope !3, !noalias !4
  %v6376 = load i64, ptr %slot31, align 8
  store i64 %v6376, ptr %slot1191, align 8
  %v6377 = load i64, ptr %slot28, align 8
  %p6378 = inttoptr i64 %v6377 to ptr
  store i32 0, ptr %p6378, align 4, !alias.scope !3, !noalias !4
  %v6379 = load i64, ptr %slot26, align 8
  %p6380 = inttoptr i64 %v6379 to ptr
  %ld6381 = load i32, ptr %p6380, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6381, ptr %slot1192, align 8
  %v6382 = load i32, ptr %slot1192, align 8
  %cv6383 = zext i32 %v6382 to i64
  %cond6384 = icmp ne i64 %cv6383, 0
  br i1 %cond6384, label %bb_rcslotdrop2225, label %bb_rcslotdone2225
bb_rcslotdrop2225:
  %v6385 = load i64, ptr %slot26, align 8
  %p6386 = inttoptr i64 %v6385 to ptr
  store i32 0, ptr %p6386, align 4, !alias.scope !3, !noalias !4
  %v6387 = load i64, ptr %slot30, align 8
  store i64 %v6387, ptr %slot1193, align 8
  %v6388 = load i64, ptr %slot27, align 8
  %p6389 = inttoptr i64 %v6388 to ptr
  %ld6390 = load i32, ptr %p6389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6390, ptr %slot1194, align 8
  %v6391 = load i32, ptr %slot1194, align 8
  %op6392 = and i32 %v6391, 28
  store i32 %op6392, ptr %slot1195, align 8
  %v6393 = load i32, ptr %slot1195, align 8
  %cv6394 = zext i32 %v6393 to i64
  %cond6395 = icmp ne i64 %cv6394, 0
  br i1 %cond6395, label %bb_rcslotrole2225, label %bb_rcslotowner2225
bb_rcslotrole2225:
  %v6396 = load i64, ptr %slot56, align 8
  store i64 %v6396, ptr %slot1196, align 8
  %v6397 = load i64, ptr %slot1196, align 8
  %v6398 = load i64, ptr %slot1193, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v6397, i64 %v6398) nomerge, !dbg !164
  br label %bb_rcslotdone2225
bb_rcslotowner2225:
  %v6399 = load i64, ptr %slot56, align 8
  store i64 %v6399, ptr %slot1197, align 8
  %v6400 = load i64, ptr %slot1197, align 8
  %v6401 = load i64, ptr %slot1193, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v6400, i64 %v6401) nomerge, !dbg !164
  br label %bb_rcslotdone2225
bb_rcslotdone2225:
  %v6402 = load i64, ptr %slot24, align 8
  %p6403 = inttoptr i64 %v6402 to ptr
  %ld6404 = load i32, ptr %p6403, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6404, ptr %slot1198, align 8
  %v6405 = load i32, ptr %slot1198, align 8
  %cv6406 = zext i32 %v6405 to i64
  %cond6407 = icmp ne i64 %cv6406, 0
  br i1 %cond6407, label %bb_rcslotdrop2234, label %bb_rcslotdone2234
bb_rcslotdrop2234:
  %v6408 = load i64, ptr %slot24, align 8
  %p6409 = inttoptr i64 %v6408 to ptr
  store i32 0, ptr %p6409, align 4, !alias.scope !3, !noalias !4
  %v6410 = load i64, ptr %slot46, align 8
  store i64 %v6410, ptr %slot1199, align 8
  %v6411 = load i64, ptr %slot25, align 8
  %p6412 = inttoptr i64 %v6411 to ptr
  %ld6413 = load i32, ptr %p6412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6413, ptr %slot1200, align 8
  %v6414 = load i32, ptr %slot1200, align 8
  %op6415 = and i32 %v6414, 28
  store i32 %op6415, ptr %slot1201, align 8
  %v6416 = load i32, ptr %slot1201, align 8
  %cv6417 = zext i32 %v6416 to i64
  %cond6418 = icmp ne i64 %cv6417, 0
  br i1 %cond6418, label %bb_rcslotrole2234, label %bb_rcslotowner2234
bb_rcslotrole2234:
  %v6419 = load i64, ptr %slot56, align 8
  store i64 %v6419, ptr %slot1202, align 8
  %v6420 = load i64, ptr %slot1202, align 8
  %v6421 = load i64, ptr %slot1199, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v6420, i64 %v6421) nomerge, !dbg !164
  br label %bb_rcslotdone2234
bb_rcslotowner2234:
  %v6422 = load i64, ptr %slot56, align 8
  store i64 %v6422, ptr %slot1203, align 8
  %v6423 = load i64, ptr %slot1203, align 8
  %v6424 = load i64, ptr %slot1199, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v6423, i64 %v6424) nomerge, !dbg !164
  br label %bb_rcslotdone2234
bb_rcslotdone2234:
  %v6425 = load i64, ptr %slot22, align 8
  %p6426 = inttoptr i64 %v6425 to ptr
  %ld6427 = load i32, ptr %p6426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6427, ptr %slot1204, align 8
  %v6428 = load i32, ptr %slot1204, align 8
  %cv6429 = zext i32 %v6428 to i64
  %cond6430 = icmp ne i64 %cv6429, 0
  br i1 %cond6430, label %bb_rcslotdrop2243, label %bb_rcslotdone2243
bb_rcslotdrop2243:
  %v6431 = load i64, ptr %slot22, align 8
  %p6432 = inttoptr i64 %v6431 to ptr
  store i32 0, ptr %p6432, align 4, !alias.scope !3, !noalias !4
  %v6433 = load i64, ptr %slot45, align 8
  store i64 %v6433, ptr %slot1205, align 8
  %v6434 = load i64, ptr %slot23, align 8
  %p6435 = inttoptr i64 %v6434 to ptr
  %ld6436 = load i32, ptr %p6435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6436, ptr %slot1206, align 8
  %v6437 = load i32, ptr %slot1206, align 8
  %op6438 = and i32 %v6437, 28
  store i32 %op6438, ptr %slot1207, align 8
  %v6439 = load i32, ptr %slot1207, align 8
  %cv6440 = zext i32 %v6439 to i64
  %cond6441 = icmp ne i64 %cv6440, 0
  br i1 %cond6441, label %bb_rcslotrole2243, label %bb_rcslotowner2243
bb_rcslotrole2243:
  %v6442 = load i64, ptr %slot56, align 8
  store i64 %v6442, ptr %slot1208, align 8
  %v6443 = load i64, ptr %slot1208, align 8
  %v6444 = load i64, ptr %slot1205, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v6443, i64 %v6444) nomerge, !dbg !164
  br label %bb_rcslotdone2243
bb_rcslotowner2243:
  %v6445 = load i64, ptr %slot56, align 8
  store i64 %v6445, ptr %slot1209, align 8
  %v6446 = load i64, ptr %slot1209, align 8
  %v6447 = load i64, ptr %slot1205, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v6446, i64 %v6447) nomerge, !dbg !164
  br label %bb_rcslotdone2243
bb_rcslotdone2243:
  %v6448 = load i64, ptr %slot20, align 8
  %p6449 = inttoptr i64 %v6448 to ptr
  %ld6450 = load i32, ptr %p6449, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6450, ptr %slot1210, align 8
  %v6451 = load i32, ptr %slot1210, align 8
  %cv6452 = zext i32 %v6451 to i64
  %cond6453 = icmp ne i64 %cv6452, 0
  br i1 %cond6453, label %bb_rcslotdrop2252, label %bb_rcslotdone2252
bb_rcslotdrop2252:
  %v6454 = load i64, ptr %slot20, align 8
  %p6455 = inttoptr i64 %v6454 to ptr
  store i32 0, ptr %p6455, align 4, !alias.scope !3, !noalias !4
  %v6456 = load i64, ptr %slot44, align 8
  store i64 %v6456, ptr %slot1211, align 8
  %v6457 = load i64, ptr %slot21, align 8
  %p6458 = inttoptr i64 %v6457 to ptr
  %ld6459 = load i32, ptr %p6458, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6459, ptr %slot1212, align 8
  %v6460 = load i32, ptr %slot1212, align 8
  %op6461 = and i32 %v6460, 28
  store i32 %op6461, ptr %slot1213, align 8
  %v6462 = load i32, ptr %slot1213, align 8
  %cv6463 = zext i32 %v6462 to i64
  %cond6464 = icmp ne i64 %cv6463, 0
  br i1 %cond6464, label %bb_rcslotrole2252, label %bb_rcslotowner2252
bb_rcslotrole2252:
  %v6465 = load i64, ptr %slot56, align 8
  store i64 %v6465, ptr %slot1214, align 8
  %v6466 = load i64, ptr %slot1214, align 8
  %v6467 = load i64, ptr %slot1211, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v6466, i64 %v6467) nomerge, !dbg !164
  br label %bb_rcslotdone2252
bb_rcslotowner2252:
  %v6468 = load i64, ptr %slot56, align 8
  store i64 %v6468, ptr %slot1215, align 8
  %v6469 = load i64, ptr %slot1215, align 8
  %v6470 = load i64, ptr %slot1211, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v6469, i64 %v6470) nomerge, !dbg !164
  br label %bb_rcslotdone2252
bb_rcslotdone2252:
  %v6471 = load i64, ptr %slot18, align 8
  %p6472 = inttoptr i64 %v6471 to ptr
  %ld6473 = load i32, ptr %p6472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6473, ptr %slot1216, align 8
  %v6474 = load i32, ptr %slot1216, align 8
  %cv6475 = zext i32 %v6474 to i64
  %cond6476 = icmp ne i64 %cv6475, 0
  br i1 %cond6476, label %bb_rcslotdrop2261, label %bb_rcslotdone2261
bb_rcslotdrop2261:
  %v6477 = load i64, ptr %slot18, align 8
  %p6478 = inttoptr i64 %v6477 to ptr
  store i32 0, ptr %p6478, align 4, !alias.scope !3, !noalias !4
  %v6479 = load i64, ptr %slot43, align 8
  store i64 %v6479, ptr %slot1217, align 8
  %v6480 = load i64, ptr %slot19, align 8
  %p6481 = inttoptr i64 %v6480 to ptr
  %ld6482 = load i32, ptr %p6481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6482, ptr %slot1218, align 8
  %v6483 = load i32, ptr %slot1218, align 8
  %op6484 = and i32 %v6483, 28
  store i32 %op6484, ptr %slot1219, align 8
  %v6485 = load i32, ptr %slot1219, align 8
  %cv6486 = zext i32 %v6485 to i64
  %cond6487 = icmp ne i64 %cv6486, 0
  br i1 %cond6487, label %bb_rcslotrole2261, label %bb_rcslotowner2261
bb_rcslotrole2261:
  %v6488 = load i64, ptr %slot56, align 8
  store i64 %v6488, ptr %slot1220, align 8
  %v6489 = load i64, ptr %slot1220, align 8
  %v6490 = load i64, ptr %slot1217, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v6489, i64 %v6490) nomerge, !dbg !164
  br label %bb_rcslotdone2261
bb_rcslotowner2261:
  %v6491 = load i64, ptr %slot56, align 8
  store i64 %v6491, ptr %slot1221, align 8
  %v6492 = load i64, ptr %slot1221, align 8
  %v6493 = load i64, ptr %slot1217, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v6492, i64 %v6493) nomerge, !dbg !164
  br label %bb_rcslotdone2261
bb_rcslotdone2261:
  %v6494 = load i64, ptr %slot16, align 8
  %p6495 = inttoptr i64 %v6494 to ptr
  %ld6496 = load i32, ptr %p6495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6496, ptr %slot1222, align 8
  %v6497 = load i32, ptr %slot1222, align 8
  %cv6498 = zext i32 %v6497 to i64
  %cond6499 = icmp ne i64 %cv6498, 0
  br i1 %cond6499, label %bb_rcslotdrop2270, label %bb_rcslotdone2270
bb_rcslotdrop2270:
  %v6500 = load i64, ptr %slot16, align 8
  %p6501 = inttoptr i64 %v6500 to ptr
  store i32 0, ptr %p6501, align 4, !alias.scope !3, !noalias !4
  %v6502 = load i64, ptr %slot42, align 8
  store i64 %v6502, ptr %slot1223, align 8
  %v6503 = load i64, ptr %slot17, align 8
  %p6504 = inttoptr i64 %v6503 to ptr
  %ld6505 = load i32, ptr %p6504, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6505, ptr %slot1224, align 8
  %v6506 = load i32, ptr %slot1224, align 8
  %op6507 = and i32 %v6506, 28
  store i32 %op6507, ptr %slot1225, align 8
  %v6508 = load i32, ptr %slot1225, align 8
  %cv6509 = zext i32 %v6508 to i64
  %cond6510 = icmp ne i64 %cv6509, 0
  br i1 %cond6510, label %bb_rcslotrole2270, label %bb_rcslotowner2270
bb_rcslotrole2270:
  %v6511 = load i64, ptr %slot56, align 8
  store i64 %v6511, ptr %slot1226, align 8
  %v6512 = load i64, ptr %slot1226, align 8
  %v6513 = load i64, ptr %slot1223, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v6512, i64 %v6513) nomerge, !dbg !164
  br label %bb_rcslotdone2270
bb_rcslotowner2270:
  %v6514 = load i64, ptr %slot56, align 8
  store i64 %v6514, ptr %slot1227, align 8
  %v6515 = load i64, ptr %slot1227, align 8
  %v6516 = load i64, ptr %slot1223, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v6515, i64 %v6516) nomerge, !dbg !164
  br label %bb_rcslotdone2270
bb_rcslotdone2270:
  %v6517 = load i64, ptr %slot14, align 8
  %p6518 = inttoptr i64 %v6517 to ptr
  %ld6519 = load i32, ptr %p6518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6519, ptr %slot1228, align 8
  %v6520 = load i32, ptr %slot1228, align 8
  %cv6521 = zext i32 %v6520 to i64
  %cond6522 = icmp ne i64 %cv6521, 0
  br i1 %cond6522, label %bb_rcslotdrop2279, label %bb_rcslotdone2279
bb_rcslotdrop2279:
  %v6523 = load i64, ptr %slot14, align 8
  %p6524 = inttoptr i64 %v6523 to ptr
  store i32 0, ptr %p6524, align 4, !alias.scope !3, !noalias !4
  %v6525 = load i64, ptr %slot41, align 8
  store i64 %v6525, ptr %slot1229, align 8
  %v6526 = load i64, ptr %slot15, align 8
  %p6527 = inttoptr i64 %v6526 to ptr
  %ld6528 = load i32, ptr %p6527, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6528, ptr %slot1230, align 8
  %v6529 = load i32, ptr %slot1230, align 8
  %op6530 = and i32 %v6529, 28
  store i32 %op6530, ptr %slot1231, align 8
  %v6531 = load i32, ptr %slot1231, align 8
  %cv6532 = zext i32 %v6531 to i64
  %cond6533 = icmp ne i64 %cv6532, 0
  br i1 %cond6533, label %bb_rcslotrole2279, label %bb_rcslotowner2279
bb_rcslotrole2279:
  %v6534 = load i64, ptr %slot56, align 8
  store i64 %v6534, ptr %slot1232, align 8
  %v6535 = load i64, ptr %slot1232, align 8
  %v6536 = load i64, ptr %slot1229, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v6535, i64 %v6536) nomerge, !dbg !164
  br label %bb_rcslotdone2279
bb_rcslotowner2279:
  %v6537 = load i64, ptr %slot56, align 8
  store i64 %v6537, ptr %slot1233, align 8
  %v6538 = load i64, ptr %slot1233, align 8
  %v6539 = load i64, ptr %slot1229, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v6538, i64 %v6539) nomerge, !dbg !164
  br label %bb_rcslotdone2279
bb_rcslotdone2279:
  %v6540 = load i64, ptr %slot12, align 8
  %p6541 = inttoptr i64 %v6540 to ptr
  %ld6542 = load i32, ptr %p6541, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6542, ptr %slot1234, align 8
  %v6543 = load i32, ptr %slot1234, align 8
  %cv6544 = zext i32 %v6543 to i64
  %cond6545 = icmp ne i64 %cv6544, 0
  br i1 %cond6545, label %bb_rcslotdrop2288, label %bb_rcslotdone2288
bb_rcslotdrop2288:
  %v6546 = load i64, ptr %slot12, align 8
  %p6547 = inttoptr i64 %v6546 to ptr
  store i32 0, ptr %p6547, align 4, !alias.scope !3, !noalias !4
  %v6548 = load i64, ptr %slot40, align 8
  store i64 %v6548, ptr %slot1235, align 8
  %v6549 = load i64, ptr %slot13, align 8
  %p6550 = inttoptr i64 %v6549 to ptr
  %ld6551 = load i32, ptr %p6550, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6551, ptr %slot1236, align 8
  %v6552 = load i32, ptr %slot1236, align 8
  %op6553 = and i32 %v6552, 28
  store i32 %op6553, ptr %slot1237, align 8
  %v6554 = load i32, ptr %slot1237, align 8
  %cv6555 = zext i32 %v6554 to i64
  %cond6556 = icmp ne i64 %cv6555, 0
  br i1 %cond6556, label %bb_rcslotrole2288, label %bb_rcslotowner2288
bb_rcslotrole2288:
  %v6557 = load i64, ptr %slot56, align 8
  store i64 %v6557, ptr %slot1238, align 8
  %v6558 = load i64, ptr %slot1238, align 8
  %v6559 = load i64, ptr %slot1235, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v6558, i64 %v6559) nomerge, !dbg !164
  br label %bb_rcslotdone2288
bb_rcslotowner2288:
  %v6560 = load i64, ptr %slot56, align 8
  store i64 %v6560, ptr %slot1239, align 8
  %v6561 = load i64, ptr %slot1239, align 8
  %v6562 = load i64, ptr %slot1235, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v6561, i64 %v6562) nomerge, !dbg !164
  br label %bb_rcslotdone2288
bb_rcslotdone2288:
  %v6563 = load i64, ptr %slot10, align 8
  %p6564 = inttoptr i64 %v6563 to ptr
  %ld6565 = load i32, ptr %p6564, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6565, ptr %slot1240, align 8
  %v6566 = load i32, ptr %slot1240, align 8
  %cv6567 = zext i32 %v6566 to i64
  %cond6568 = icmp ne i64 %cv6567, 0
  br i1 %cond6568, label %bb_rcslotdrop2297, label %bb_rcslotdone2297
bb_rcslotdrop2297:
  %v6569 = load i64, ptr %slot10, align 8
  %p6570 = inttoptr i64 %v6569 to ptr
  store i32 0, ptr %p6570, align 4, !alias.scope !3, !noalias !4
  %v6571 = load i64, ptr %slot38, align 8
  store i64 %v6571, ptr %slot1241, align 8
  %v6572 = load i64, ptr %slot11, align 8
  %p6573 = inttoptr i64 %v6572 to ptr
  %ld6574 = load i32, ptr %p6573, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6574, ptr %slot1242, align 8
  %v6575 = load i32, ptr %slot1242, align 8
  %op6576 = and i32 %v6575, 28
  store i32 %op6576, ptr %slot1243, align 8
  %v6577 = load i32, ptr %slot1243, align 8
  %cv6578 = zext i32 %v6577 to i64
  %cond6579 = icmp ne i64 %cv6578, 0
  br i1 %cond6579, label %bb_rcslotrole2297, label %bb_rcslotowner2297
bb_rcslotrole2297:
  %v6580 = load i64, ptr %slot56, align 8
  store i64 %v6580, ptr %slot1244, align 8
  %v6581 = load i64, ptr %slot1244, align 8
  %v6582 = load i64, ptr %slot1241, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v6581, i64 %v6582) nomerge, !dbg !164
  br label %bb_rcslotdone2297
bb_rcslotowner2297:
  %v6583 = load i64, ptr %slot56, align 8
  store i64 %v6583, ptr %slot1245, align 8
  %v6584 = load i64, ptr %slot1245, align 8
  %v6585 = load i64, ptr %slot1241, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v6584, i64 %v6585) nomerge, !dbg !164
  br label %bb_rcslotdone2297
bb_rcslotdone2297:
  %v6586 = load i64, ptr %slot8, align 8
  %p6587 = inttoptr i64 %v6586 to ptr
  %ld6588 = load i32, ptr %p6587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6588, ptr %slot1246, align 8
  %v6589 = load i32, ptr %slot1246, align 8
  %cv6590 = zext i32 %v6589 to i64
  %cond6591 = icmp ne i64 %cv6590, 0
  br i1 %cond6591, label %bb_rcslotdrop2306, label %bb_rcslotdone2306
bb_rcslotdrop2306:
  %v6592 = load i64, ptr %slot8, align 8
  %p6593 = inttoptr i64 %v6592 to ptr
  store i32 0, ptr %p6593, align 4, !alias.scope !3, !noalias !4
  %v6594 = load i64, ptr %slot37, align 8
  store i64 %v6594, ptr %slot1247, align 8
  %v6595 = load i64, ptr %slot9, align 8
  %p6596 = inttoptr i64 %v6595 to ptr
  %ld6597 = load i32, ptr %p6596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6597, ptr %slot1248, align 8
  %v6598 = load i32, ptr %slot1248, align 8
  %op6599 = and i32 %v6598, 28
  store i32 %op6599, ptr %slot1249, align 8
  %v6600 = load i32, ptr %slot1249, align 8
  %cv6601 = zext i32 %v6600 to i64
  %cond6602 = icmp ne i64 %cv6601, 0
  br i1 %cond6602, label %bb_rcslotrole2306, label %bb_rcslotowner2306
bb_rcslotrole2306:
  %v6603 = load i64, ptr %slot56, align 8
  store i64 %v6603, ptr %slot1250, align 8
  %v6604 = load i64, ptr %slot1250, align 8
  %v6605 = load i64, ptr %slot1247, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v6604, i64 %v6605) nomerge, !dbg !164
  br label %bb_rcslotdone2306
bb_rcslotowner2306:
  %v6606 = load i64, ptr %slot56, align 8
  store i64 %v6606, ptr %slot1251, align 8
  %v6607 = load i64, ptr %slot1251, align 8
  %v6608 = load i64, ptr %slot1247, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v6607, i64 %v6608) nomerge, !dbg !164
  br label %bb_rcslotdone2306
bb_rcslotdone2306:
  %v6609 = load i64, ptr %slot6, align 8
  %p6610 = inttoptr i64 %v6609 to ptr
  %ld6611 = load i32, ptr %p6610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6611, ptr %slot1252, align 8
  %v6612 = load i32, ptr %slot1252, align 8
  %cv6613 = zext i32 %v6612 to i64
  %cond6614 = icmp ne i64 %cv6613, 0
  br i1 %cond6614, label %bb_rcslotdrop2315, label %bb_rcslotdone2315
bb_rcslotdrop2315:
  %v6615 = load i64, ptr %slot6, align 8
  %p6616 = inttoptr i64 %v6615 to ptr
  store i32 0, ptr %p6616, align 4, !alias.scope !3, !noalias !4
  %v6617 = load i64, ptr %slot36, align 8
  store i64 %v6617, ptr %slot1253, align 8
  %v6618 = load i64, ptr %slot7, align 8
  %p6619 = inttoptr i64 %v6618 to ptr
  %ld6620 = load i32, ptr %p6619, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6620, ptr %slot1254, align 8
  %v6621 = load i32, ptr %slot1254, align 8
  %op6622 = and i32 %v6621, 28
  store i32 %op6622, ptr %slot1255, align 8
  %v6623 = load i32, ptr %slot1255, align 8
  %cv6624 = zext i32 %v6623 to i64
  %cond6625 = icmp ne i64 %cv6624, 0
  br i1 %cond6625, label %bb_rcslotrole2315, label %bb_rcslotowner2315
bb_rcslotrole2315:
  %v6626 = load i64, ptr %slot56, align 8
  store i64 %v6626, ptr %slot1256, align 8
  %v6627 = load i64, ptr %slot1256, align 8
  %v6628 = load i64, ptr %slot1253, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v6627, i64 %v6628) nomerge, !dbg !164
  br label %bb_rcslotdone2315
bb_rcslotowner2315:
  %v6629 = load i64, ptr %slot56, align 8
  store i64 %v6629, ptr %slot1257, align 8
  %v6630 = load i64, ptr %slot1257, align 8
  %v6631 = load i64, ptr %slot1253, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v6630, i64 %v6631) nomerge, !dbg !164
  br label %bb_rcslotdone2315
bb_rcslotdone2315:
  %v6632 = load i64, ptr %slot1191, align 8
  %p6633 = inttoptr i64 %v6632 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6633, i64 24, i1 false)
  ret void
bb_i59:
  %v6634 = load i64, ptr %slot32, align 8
  %p6635 = inttoptr i64 %v6634 to ptr
  %ld6636 = load i64, ptr %p6635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6636, ptr %slot1258, align 8
  %v6637 = load i64, ptr %slot1258, align 8
  %v6638 = load i64, ptr %slot47, align 8
  %p6639 = inttoptr i64 %v6638 to ptr
  store i64 %v6637, ptr %p6639, align 8, !alias.scope !3, !noalias !4
  %v6640 = load i64, ptr %slot45, align 8
  %v6641 = load i64, ptr %slot48, align 8
  %p6642 = inttoptr i64 %v6641 to ptr
  store i64 %v6640, ptr %p6642, align 8, !alias.scope !3, !noalias !4
  %v6643 = load i64, ptr %slot47, align 8
  %p6644 = inttoptr i64 %v6643 to ptr
  %ld6645 = load i64, ptr %p6644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6645, ptr %slot1259, align 8
  %v6646 = load i64, ptr %slot48, align 8
  %p6647 = inttoptr i64 %v6646 to ptr
  %ld6648 = load i64, ptr %p6647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6648, ptr %slot1260, align 8
  %v6649 = load i64, ptr %slot1, align 8
  %v6650 = load i64, ptr %slot1259, align 8
  %v6651 = load i64, ptr %slot1260, align 8
  call void @myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e(ptr sret([24 x i8]) align 8 %callresult1262, i64 %v6649, i64 %v6650, i64 %v6651) nomerge, !dbg !166
  %addr6652 = ptrtoint ptr %callresult1262 to i64
  store i64 %addr6652, ptr %slot1261, align 8
  %v6653 = load i64, ptr %slot1261, align 8
  %v6654 = load i64, ptr %slot47, align 8
  %p6655 = inttoptr i64 %v6654 to ptr
  store i64 %v6653, ptr %p6655, align 8, !alias.scope !3, !noalias !4
  %v6656 = load i64, ptr %slot47, align 8
  %p6657 = inttoptr i64 %v6656 to ptr
  %ld6658 = load i64, ptr %p6657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6658, ptr %slot1263, align 8
  %v6659 = load i64, ptr %slot31, align 8
  store i64 %v6659, ptr %slot1264, align 8
  %v6660 = load i64, ptr %slot1263, align 8
  %v6661 = load i64, ptr %slot1264, align 8
  %p6662 = inttoptr i64 %v6660 to ptr
  %p6663 = inttoptr i64 %v6661 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6663, ptr %p6662, i64 24, i1 false)
  %v6664 = load i64, ptr %slot29, align 8
  %p6665 = inttoptr i64 %v6664 to ptr
  store i32 2, ptr %p6665, align 4, !alias.scope !3, !noalias !4
  %v6666 = load i64, ptr %slot28, align 8
  %p6667 = inttoptr i64 %v6666 to ptr
  store i32 1, ptr %p6667, align 4, !alias.scope !3, !noalias !4
  %v6668 = load i64, ptr %slot26, align 8
  %p6669 = inttoptr i64 %v6668 to ptr
  %ld6670 = load i32, ptr %p6669, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6670, ptr %slot1265, align 8
  %v6671 = load i32, ptr %slot1265, align 8
  %cv6672 = zext i32 %v6671 to i64
  %cond6673 = icmp ne i64 %cv6672, 0
  br i1 %cond6673, label %bb_rcslotdrop2378, label %bb_rcslotdone2378
bb_rcslotdrop2378:
  %v6674 = load i64, ptr %slot26, align 8
  %p6675 = inttoptr i64 %v6674 to ptr
  store i32 0, ptr %p6675, align 4, !alias.scope !3, !noalias !4
  %v6676 = load i64, ptr %slot30, align 8
  store i64 %v6676, ptr %slot1266, align 8
  %v6677 = load i64, ptr %slot27, align 8
  %p6678 = inttoptr i64 %v6677 to ptr
  %ld6679 = load i32, ptr %p6678, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6679, ptr %slot1267, align 8
  %v6680 = load i32, ptr %slot1267, align 8
  %op6681 = and i32 %v6680, 28
  store i32 %op6681, ptr %slot1268, align 8
  %v6682 = load i32, ptr %slot1268, align 8
  %cv6683 = zext i32 %v6682 to i64
  %cond6684 = icmp ne i64 %cv6683, 0
  br i1 %cond6684, label %bb_rcslotrole2378, label %bb_rcslotowner2378
bb_rcslotrole2378:
  %v6685 = load i64, ptr %slot56, align 8
  store i64 %v6685, ptr %slot1269, align 8
  %v6686 = load i64, ptr %slot1269, align 8
  %v6687 = load i64, ptr %slot1266, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v6686, i64 %v6687) nomerge, !dbg !166
  br label %bb_rcslotdone2378
bb_rcslotowner2378:
  %v6688 = load i64, ptr %slot56, align 8
  store i64 %v6688, ptr %slot1270, align 8
  %v6689 = load i64, ptr %slot1270, align 8
  %v6690 = load i64, ptr %slot1266, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v6689, i64 %v6690) nomerge, !dbg !166
  br label %bb_rcslotdone2378
bb_rcslotdone2378:
  %v6691 = load i64, ptr %slot30, align 8
  store i64 %v6691, ptr %slot1271, align 8
  %v6692 = load i64, ptr %slot31, align 8
  store i64 %v6692, ptr %slot1272, align 8
  %v6693 = load i64, ptr %slot1272, align 8
  %v6694 = load i64, ptr %slot1271, align 8
  %p6695 = inttoptr i64 %v6693 to ptr
  %p6696 = inttoptr i64 %v6694 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6696, ptr %p6695, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6697 = load i64, ptr %slot27, align 8
  %p6698 = inttoptr i64 %v6697 to ptr
  store i32 2, ptr %p6698, align 4, !alias.scope !3, !noalias !4
  %v6699 = load i64, ptr %slot29, align 8
  %p6700 = inttoptr i64 %v6699 to ptr
  %ld6701 = load i32, ptr %p6700, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6701, ptr %slot1273, align 8
  %v6702 = load i32, ptr %slot1273, align 8
  %v6703 = load i64, ptr %slot27, align 8
  %p6704 = inttoptr i64 %v6703 to ptr
  store i32 %v6702, ptr %p6704, align 4, !alias.scope !3, !noalias !4
  %v6705 = load i64, ptr %slot28, align 8
  %p6706 = inttoptr i64 %v6705 to ptr
  store i32 0, ptr %p6706, align 4, !alias.scope !3, !noalias !4
  %v6707 = load i64, ptr %slot26, align 8
  %p6708 = inttoptr i64 %v6707 to ptr
  store i32 1, ptr %p6708, align 4, !alias.scope !3, !noalias !4
  %v6709 = load i64, ptr %slot1271, align 8
  %v6710 = load i64, ptr %slot47, align 8
  %p6711 = inttoptr i64 %v6710 to ptr
  store i64 %v6709, ptr %p6711, align 8, !alias.scope !3, !noalias !4
  %v6712 = load i64, ptr %slot47, align 8
  %p6713 = inttoptr i64 %v6712 to ptr
  %ld6714 = load i64, ptr %p6713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6714, ptr %slot1274, align 8
  %v6715 = load i64, ptr %slot1274, align 8
  %p6716 = inttoptr i64 %v6715 to ptr
  %ld6717 = load i32, ptr %p6716, align 4, !alias.scope !3, !noalias !4
  %ext6718 = zext i32 %ld6717 to i64
  store i64 %ext6718, ptr %slot1275, align 8
  %v6719 = load i64, ptr %slot1275, align 8
  %cmp6720 = icmp eq i64 %v6719, 1
  %cv6721 = zext i1 %cmp6720 to i64
  store i64 %cv6721, ptr %slot1276, align 8
  %v6722 = load i64, ptr %slot1276, align 8
  %cond6723 = icmp ne i64 %v6722, 0
  br i1 %cond6723, label %bb_errtrace2404, label %bb_errtraced2404
bb_errtrace2404:
  %p6724 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p6724, i64 8589934654) "call-inline-cost"="0", !dbg !168
  br label %bb_errtraced2404
bb_errtraced2404:
  %v6725 = load i64, ptr %slot47, align 8
  %p6726 = inttoptr i64 %v6725 to ptr
  %ld6727 = load i64, ptr %p6726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6727, ptr %slot1277, align 8
  %v6728 = load i64, ptr %slot31, align 8
  store i64 %v6728, ptr %slot1278, align 8
  %v6729 = load i64, ptr %slot57, align 8
  store i64 %v6729, ptr %slot1279, align 8
  %v6730 = load i64, ptr %slot56, align 8
  %v6731 = load i64, ptr %slot1278, align 8
  %v6732 = load i64, ptr %slot1277, align 8
  %v6733 = load i64, ptr %slot1279, align 8
  %cv6734 = trunc i64 %v6733 to i32
  %call6735 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v6730, i64 %v6731, i64 %v6732, i32 %cv6734) nomerge, !dbg !168
  store i32 %call6735, ptr %slot1280, align 8
  %v6736 = load i32, ptr %slot1280, align 8
  %cv6737 = zext i32 %v6736 to i64
  %cond6738 = icmp ne i64 %cv6737, 0
  br i1 %cond6738, label %bb_rcsuccess2409, label %bb_rcfailure2409
bb_rcfailure2409:
  %v6739 = load i64, ptr %slot56, align 8
  %p6740 = inttoptr i64 %v6739 to ptr
  %call6741 = call i32 @myl_rc_take_failure(ptr %p6740) nomerge, !dbg !168
  store i32 %call6741, ptr %slot1281, align 8
  %v6742 = load i64, ptr %slot1, align 8
  %p6743 = inttoptr i64 %v6742 to ptr
  %v6744 = load i32, ptr %slot1281, align 8
  %call6745 = call i32 @myl_qbe_rc_status(ptr %p6743, i32 %v6744) nomerge, !dbg !168
  store i32 %call6745, ptr %slot1282, align 8
  br label %bb_failure
bb_rcsuccess2409:
  %v6746 = load i64, ptr %slot26, align 8
  %p6747 = inttoptr i64 %v6746 to ptr
  store i32 0, ptr %p6747, align 4, !alias.scope !3, !noalias !4
  %v6748 = load i64, ptr %slot29, align 8
  %p6749 = inttoptr i64 %v6748 to ptr
  store i32 2, ptr %p6749, align 4, !alias.scope !3, !noalias !4
  %v6750 = load i64, ptr %slot28, align 8
  %p6751 = inttoptr i64 %v6750 to ptr
  store i32 1, ptr %p6751, align 4, !alias.scope !3, !noalias !4
  %v6752 = load i64, ptr %slot31, align 8
  store i64 %v6752, ptr %slot1283, align 8
  %v6753 = load i64, ptr %slot28, align 8
  %p6754 = inttoptr i64 %v6753 to ptr
  store i32 0, ptr %p6754, align 4, !alias.scope !3, !noalias !4
  %v6755 = load i64, ptr %slot26, align 8
  %p6756 = inttoptr i64 %v6755 to ptr
  %ld6757 = load i32, ptr %p6756, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6757, ptr %slot1284, align 8
  %v6758 = load i32, ptr %slot1284, align 8
  %cv6759 = zext i32 %v6758 to i64
  %cond6760 = icmp ne i64 %cv6759, 0
  br i1 %cond6760, label %bb_rcslotdrop2419, label %bb_rcslotdone2419
bb_rcslotdrop2419:
  %v6761 = load i64, ptr %slot26, align 8
  %p6762 = inttoptr i64 %v6761 to ptr
  store i32 0, ptr %p6762, align 4, !alias.scope !3, !noalias !4
  %v6763 = load i64, ptr %slot30, align 8
  store i64 %v6763, ptr %slot1285, align 8
  %v6764 = load i64, ptr %slot27, align 8
  %p6765 = inttoptr i64 %v6764 to ptr
  %ld6766 = load i32, ptr %p6765, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6766, ptr %slot1286, align 8
  %v6767 = load i32, ptr %slot1286, align 8
  %op6768 = and i32 %v6767, 28
  store i32 %op6768, ptr %slot1287, align 8
  %v6769 = load i32, ptr %slot1287, align 8
  %cv6770 = zext i32 %v6769 to i64
  %cond6771 = icmp ne i64 %cv6770, 0
  br i1 %cond6771, label %bb_rcslotrole2419, label %bb_rcslotowner2419
bb_rcslotrole2419:
  %v6772 = load i64, ptr %slot56, align 8
  store i64 %v6772, ptr %slot1288, align 8
  %v6773 = load i64, ptr %slot1288, align 8
  %v6774 = load i64, ptr %slot1285, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v6773, i64 %v6774) nomerge, !dbg !168
  br label %bb_rcslotdone2419
bb_rcslotowner2419:
  %v6775 = load i64, ptr %slot56, align 8
  store i64 %v6775, ptr %slot1289, align 8
  %v6776 = load i64, ptr %slot1289, align 8
  %v6777 = load i64, ptr %slot1285, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v6776, i64 %v6777) nomerge, !dbg !168
  br label %bb_rcslotdone2419
bb_rcslotdone2419:
  %v6778 = load i64, ptr %slot24, align 8
  %p6779 = inttoptr i64 %v6778 to ptr
  %ld6780 = load i32, ptr %p6779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6780, ptr %slot1290, align 8
  %v6781 = load i32, ptr %slot1290, align 8
  %cv6782 = zext i32 %v6781 to i64
  %cond6783 = icmp ne i64 %cv6782, 0
  br i1 %cond6783, label %bb_rcslotdrop2428, label %bb_rcslotdone2428
bb_rcslotdrop2428:
  %v6784 = load i64, ptr %slot24, align 8
  %p6785 = inttoptr i64 %v6784 to ptr
  store i32 0, ptr %p6785, align 4, !alias.scope !3, !noalias !4
  %v6786 = load i64, ptr %slot46, align 8
  store i64 %v6786, ptr %slot1291, align 8
  %v6787 = load i64, ptr %slot25, align 8
  %p6788 = inttoptr i64 %v6787 to ptr
  %ld6789 = load i32, ptr %p6788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6789, ptr %slot1292, align 8
  %v6790 = load i32, ptr %slot1292, align 8
  %op6791 = and i32 %v6790, 28
  store i32 %op6791, ptr %slot1293, align 8
  %v6792 = load i32, ptr %slot1293, align 8
  %cv6793 = zext i32 %v6792 to i64
  %cond6794 = icmp ne i64 %cv6793, 0
  br i1 %cond6794, label %bb_rcslotrole2428, label %bb_rcslotowner2428
bb_rcslotrole2428:
  %v6795 = load i64, ptr %slot56, align 8
  store i64 %v6795, ptr %slot1294, align 8
  %v6796 = load i64, ptr %slot1294, align 8
  %v6797 = load i64, ptr %slot1291, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v6796, i64 %v6797) nomerge, !dbg !168
  br label %bb_rcslotdone2428
bb_rcslotowner2428:
  %v6798 = load i64, ptr %slot56, align 8
  store i64 %v6798, ptr %slot1295, align 8
  %v6799 = load i64, ptr %slot1295, align 8
  %v6800 = load i64, ptr %slot1291, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v6799, i64 %v6800) nomerge, !dbg !168
  br label %bb_rcslotdone2428
bb_rcslotdone2428:
  %v6801 = load i64, ptr %slot22, align 8
  %p6802 = inttoptr i64 %v6801 to ptr
  %ld6803 = load i32, ptr %p6802, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6803, ptr %slot1296, align 8
  %v6804 = load i32, ptr %slot1296, align 8
  %cv6805 = zext i32 %v6804 to i64
  %cond6806 = icmp ne i64 %cv6805, 0
  br i1 %cond6806, label %bb_rcslotdrop2437, label %bb_rcslotdone2437
bb_rcslotdrop2437:
  %v6807 = load i64, ptr %slot22, align 8
  %p6808 = inttoptr i64 %v6807 to ptr
  store i32 0, ptr %p6808, align 4, !alias.scope !3, !noalias !4
  %v6809 = load i64, ptr %slot45, align 8
  store i64 %v6809, ptr %slot1297, align 8
  %v6810 = load i64, ptr %slot23, align 8
  %p6811 = inttoptr i64 %v6810 to ptr
  %ld6812 = load i32, ptr %p6811, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6812, ptr %slot1298, align 8
  %v6813 = load i32, ptr %slot1298, align 8
  %op6814 = and i32 %v6813, 28
  store i32 %op6814, ptr %slot1299, align 8
  %v6815 = load i32, ptr %slot1299, align 8
  %cv6816 = zext i32 %v6815 to i64
  %cond6817 = icmp ne i64 %cv6816, 0
  br i1 %cond6817, label %bb_rcslotrole2437, label %bb_rcslotowner2437
bb_rcslotrole2437:
  %v6818 = load i64, ptr %slot56, align 8
  store i64 %v6818, ptr %slot1300, align 8
  %v6819 = load i64, ptr %slot1300, align 8
  %v6820 = load i64, ptr %slot1297, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v6819, i64 %v6820) nomerge, !dbg !168
  br label %bb_rcslotdone2437
bb_rcslotowner2437:
  %v6821 = load i64, ptr %slot56, align 8
  store i64 %v6821, ptr %slot1301, align 8
  %v6822 = load i64, ptr %slot1301, align 8
  %v6823 = load i64, ptr %slot1297, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v6822, i64 %v6823) nomerge, !dbg !168
  br label %bb_rcslotdone2437
bb_rcslotdone2437:
  %v6824 = load i64, ptr %slot20, align 8
  %p6825 = inttoptr i64 %v6824 to ptr
  %ld6826 = load i32, ptr %p6825, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6826, ptr %slot1302, align 8
  %v6827 = load i32, ptr %slot1302, align 8
  %cv6828 = zext i32 %v6827 to i64
  %cond6829 = icmp ne i64 %cv6828, 0
  br i1 %cond6829, label %bb_rcslotdrop2446, label %bb_rcslotdone2446
bb_rcslotdrop2446:
  %v6830 = load i64, ptr %slot20, align 8
  %p6831 = inttoptr i64 %v6830 to ptr
  store i32 0, ptr %p6831, align 4, !alias.scope !3, !noalias !4
  %v6832 = load i64, ptr %slot44, align 8
  store i64 %v6832, ptr %slot1303, align 8
  %v6833 = load i64, ptr %slot21, align 8
  %p6834 = inttoptr i64 %v6833 to ptr
  %ld6835 = load i32, ptr %p6834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6835, ptr %slot1304, align 8
  %v6836 = load i32, ptr %slot1304, align 8
  %op6837 = and i32 %v6836, 28
  store i32 %op6837, ptr %slot1305, align 8
  %v6838 = load i32, ptr %slot1305, align 8
  %cv6839 = zext i32 %v6838 to i64
  %cond6840 = icmp ne i64 %cv6839, 0
  br i1 %cond6840, label %bb_rcslotrole2446, label %bb_rcslotowner2446
bb_rcslotrole2446:
  %v6841 = load i64, ptr %slot56, align 8
  store i64 %v6841, ptr %slot1306, align 8
  %v6842 = load i64, ptr %slot1306, align 8
  %v6843 = load i64, ptr %slot1303, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v6842, i64 %v6843) nomerge, !dbg !168
  br label %bb_rcslotdone2446
bb_rcslotowner2446:
  %v6844 = load i64, ptr %slot56, align 8
  store i64 %v6844, ptr %slot1307, align 8
  %v6845 = load i64, ptr %slot1307, align 8
  %v6846 = load i64, ptr %slot1303, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v6845, i64 %v6846) nomerge, !dbg !168
  br label %bb_rcslotdone2446
bb_rcslotdone2446:
  %v6847 = load i64, ptr %slot18, align 8
  %p6848 = inttoptr i64 %v6847 to ptr
  %ld6849 = load i32, ptr %p6848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6849, ptr %slot1308, align 8
  %v6850 = load i32, ptr %slot1308, align 8
  %cv6851 = zext i32 %v6850 to i64
  %cond6852 = icmp ne i64 %cv6851, 0
  br i1 %cond6852, label %bb_rcslotdrop2455, label %bb_rcslotdone2455
bb_rcslotdrop2455:
  %v6853 = load i64, ptr %slot18, align 8
  %p6854 = inttoptr i64 %v6853 to ptr
  store i32 0, ptr %p6854, align 4, !alias.scope !3, !noalias !4
  %v6855 = load i64, ptr %slot43, align 8
  store i64 %v6855, ptr %slot1309, align 8
  %v6856 = load i64, ptr %slot19, align 8
  %p6857 = inttoptr i64 %v6856 to ptr
  %ld6858 = load i32, ptr %p6857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6858, ptr %slot1310, align 8
  %v6859 = load i32, ptr %slot1310, align 8
  %op6860 = and i32 %v6859, 28
  store i32 %op6860, ptr %slot1311, align 8
  %v6861 = load i32, ptr %slot1311, align 8
  %cv6862 = zext i32 %v6861 to i64
  %cond6863 = icmp ne i64 %cv6862, 0
  br i1 %cond6863, label %bb_rcslotrole2455, label %bb_rcslotowner2455
bb_rcslotrole2455:
  %v6864 = load i64, ptr %slot56, align 8
  store i64 %v6864, ptr %slot1312, align 8
  %v6865 = load i64, ptr %slot1312, align 8
  %v6866 = load i64, ptr %slot1309, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v6865, i64 %v6866) nomerge, !dbg !168
  br label %bb_rcslotdone2455
bb_rcslotowner2455:
  %v6867 = load i64, ptr %slot56, align 8
  store i64 %v6867, ptr %slot1313, align 8
  %v6868 = load i64, ptr %slot1313, align 8
  %v6869 = load i64, ptr %slot1309, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v6868, i64 %v6869) nomerge, !dbg !168
  br label %bb_rcslotdone2455
bb_rcslotdone2455:
  %v6870 = load i64, ptr %slot16, align 8
  %p6871 = inttoptr i64 %v6870 to ptr
  %ld6872 = load i32, ptr %p6871, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6872, ptr %slot1314, align 8
  %v6873 = load i32, ptr %slot1314, align 8
  %cv6874 = zext i32 %v6873 to i64
  %cond6875 = icmp ne i64 %cv6874, 0
  br i1 %cond6875, label %bb_rcslotdrop2464, label %bb_rcslotdone2464
bb_rcslotdrop2464:
  %v6876 = load i64, ptr %slot16, align 8
  %p6877 = inttoptr i64 %v6876 to ptr
  store i32 0, ptr %p6877, align 4, !alias.scope !3, !noalias !4
  %v6878 = load i64, ptr %slot42, align 8
  store i64 %v6878, ptr %slot1315, align 8
  %v6879 = load i64, ptr %slot17, align 8
  %p6880 = inttoptr i64 %v6879 to ptr
  %ld6881 = load i32, ptr %p6880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6881, ptr %slot1316, align 8
  %v6882 = load i32, ptr %slot1316, align 8
  %op6883 = and i32 %v6882, 28
  store i32 %op6883, ptr %slot1317, align 8
  %v6884 = load i32, ptr %slot1317, align 8
  %cv6885 = zext i32 %v6884 to i64
  %cond6886 = icmp ne i64 %cv6885, 0
  br i1 %cond6886, label %bb_rcslotrole2464, label %bb_rcslotowner2464
bb_rcslotrole2464:
  %v6887 = load i64, ptr %slot56, align 8
  store i64 %v6887, ptr %slot1318, align 8
  %v6888 = load i64, ptr %slot1318, align 8
  %v6889 = load i64, ptr %slot1315, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v6888, i64 %v6889) nomerge, !dbg !168
  br label %bb_rcslotdone2464
bb_rcslotowner2464:
  %v6890 = load i64, ptr %slot56, align 8
  store i64 %v6890, ptr %slot1319, align 8
  %v6891 = load i64, ptr %slot1319, align 8
  %v6892 = load i64, ptr %slot1315, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v6891, i64 %v6892) nomerge, !dbg !168
  br label %bb_rcslotdone2464
bb_rcslotdone2464:
  %v6893 = load i64, ptr %slot14, align 8
  %p6894 = inttoptr i64 %v6893 to ptr
  %ld6895 = load i32, ptr %p6894, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6895, ptr %slot1320, align 8
  %v6896 = load i32, ptr %slot1320, align 8
  %cv6897 = zext i32 %v6896 to i64
  %cond6898 = icmp ne i64 %cv6897, 0
  br i1 %cond6898, label %bb_rcslotdrop2473, label %bb_rcslotdone2473
bb_rcslotdrop2473:
  %v6899 = load i64, ptr %slot14, align 8
  %p6900 = inttoptr i64 %v6899 to ptr
  store i32 0, ptr %p6900, align 4, !alias.scope !3, !noalias !4
  %v6901 = load i64, ptr %slot41, align 8
  store i64 %v6901, ptr %slot1321, align 8
  %v6902 = load i64, ptr %slot15, align 8
  %p6903 = inttoptr i64 %v6902 to ptr
  %ld6904 = load i32, ptr %p6903, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6904, ptr %slot1322, align 8
  %v6905 = load i32, ptr %slot1322, align 8
  %op6906 = and i32 %v6905, 28
  store i32 %op6906, ptr %slot1323, align 8
  %v6907 = load i32, ptr %slot1323, align 8
  %cv6908 = zext i32 %v6907 to i64
  %cond6909 = icmp ne i64 %cv6908, 0
  br i1 %cond6909, label %bb_rcslotrole2473, label %bb_rcslotowner2473
bb_rcslotrole2473:
  %v6910 = load i64, ptr %slot56, align 8
  store i64 %v6910, ptr %slot1324, align 8
  %v6911 = load i64, ptr %slot1324, align 8
  %v6912 = load i64, ptr %slot1321, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v6911, i64 %v6912) nomerge, !dbg !168
  br label %bb_rcslotdone2473
bb_rcslotowner2473:
  %v6913 = load i64, ptr %slot56, align 8
  store i64 %v6913, ptr %slot1325, align 8
  %v6914 = load i64, ptr %slot1325, align 8
  %v6915 = load i64, ptr %slot1321, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v6914, i64 %v6915) nomerge, !dbg !168
  br label %bb_rcslotdone2473
bb_rcslotdone2473:
  %v6916 = load i64, ptr %slot12, align 8
  %p6917 = inttoptr i64 %v6916 to ptr
  %ld6918 = load i32, ptr %p6917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6918, ptr %slot1326, align 8
  %v6919 = load i32, ptr %slot1326, align 8
  %cv6920 = zext i32 %v6919 to i64
  %cond6921 = icmp ne i64 %cv6920, 0
  br i1 %cond6921, label %bb_rcslotdrop2482, label %bb_rcslotdone2482
bb_rcslotdrop2482:
  %v6922 = load i64, ptr %slot12, align 8
  %p6923 = inttoptr i64 %v6922 to ptr
  store i32 0, ptr %p6923, align 4, !alias.scope !3, !noalias !4
  %v6924 = load i64, ptr %slot40, align 8
  store i64 %v6924, ptr %slot1327, align 8
  %v6925 = load i64, ptr %slot13, align 8
  %p6926 = inttoptr i64 %v6925 to ptr
  %ld6927 = load i32, ptr %p6926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6927, ptr %slot1328, align 8
  %v6928 = load i32, ptr %slot1328, align 8
  %op6929 = and i32 %v6928, 28
  store i32 %op6929, ptr %slot1329, align 8
  %v6930 = load i32, ptr %slot1329, align 8
  %cv6931 = zext i32 %v6930 to i64
  %cond6932 = icmp ne i64 %cv6931, 0
  br i1 %cond6932, label %bb_rcslotrole2482, label %bb_rcslotowner2482
bb_rcslotrole2482:
  %v6933 = load i64, ptr %slot56, align 8
  store i64 %v6933, ptr %slot1330, align 8
  %v6934 = load i64, ptr %slot1330, align 8
  %v6935 = load i64, ptr %slot1327, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v6934, i64 %v6935) nomerge, !dbg !168
  br label %bb_rcslotdone2482
bb_rcslotowner2482:
  %v6936 = load i64, ptr %slot56, align 8
  store i64 %v6936, ptr %slot1331, align 8
  %v6937 = load i64, ptr %slot1331, align 8
  %v6938 = load i64, ptr %slot1327, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v6937, i64 %v6938) nomerge, !dbg !168
  br label %bb_rcslotdone2482
bb_rcslotdone2482:
  %v6939 = load i64, ptr %slot10, align 8
  %p6940 = inttoptr i64 %v6939 to ptr
  %ld6941 = load i32, ptr %p6940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6941, ptr %slot1332, align 8
  %v6942 = load i32, ptr %slot1332, align 8
  %cv6943 = zext i32 %v6942 to i64
  %cond6944 = icmp ne i64 %cv6943, 0
  br i1 %cond6944, label %bb_rcslotdrop2491, label %bb_rcslotdone2491
bb_rcslotdrop2491:
  %v6945 = load i64, ptr %slot10, align 8
  %p6946 = inttoptr i64 %v6945 to ptr
  store i32 0, ptr %p6946, align 4, !alias.scope !3, !noalias !4
  %v6947 = load i64, ptr %slot38, align 8
  store i64 %v6947, ptr %slot1333, align 8
  %v6948 = load i64, ptr %slot11, align 8
  %p6949 = inttoptr i64 %v6948 to ptr
  %ld6950 = load i32, ptr %p6949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6950, ptr %slot1334, align 8
  %v6951 = load i32, ptr %slot1334, align 8
  %op6952 = and i32 %v6951, 28
  store i32 %op6952, ptr %slot1335, align 8
  %v6953 = load i32, ptr %slot1335, align 8
  %cv6954 = zext i32 %v6953 to i64
  %cond6955 = icmp ne i64 %cv6954, 0
  br i1 %cond6955, label %bb_rcslotrole2491, label %bb_rcslotowner2491
bb_rcslotrole2491:
  %v6956 = load i64, ptr %slot56, align 8
  store i64 %v6956, ptr %slot1336, align 8
  %v6957 = load i64, ptr %slot1336, align 8
  %v6958 = load i64, ptr %slot1333, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v6957, i64 %v6958) nomerge, !dbg !168
  br label %bb_rcslotdone2491
bb_rcslotowner2491:
  %v6959 = load i64, ptr %slot56, align 8
  store i64 %v6959, ptr %slot1337, align 8
  %v6960 = load i64, ptr %slot1337, align 8
  %v6961 = load i64, ptr %slot1333, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v6960, i64 %v6961) nomerge, !dbg !168
  br label %bb_rcslotdone2491
bb_rcslotdone2491:
  %v6962 = load i64, ptr %slot8, align 8
  %p6963 = inttoptr i64 %v6962 to ptr
  %ld6964 = load i32, ptr %p6963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6964, ptr %slot1338, align 8
  %v6965 = load i32, ptr %slot1338, align 8
  %cv6966 = zext i32 %v6965 to i64
  %cond6967 = icmp ne i64 %cv6966, 0
  br i1 %cond6967, label %bb_rcslotdrop2500, label %bb_rcslotdone2500
bb_rcslotdrop2500:
  %v6968 = load i64, ptr %slot8, align 8
  %p6969 = inttoptr i64 %v6968 to ptr
  store i32 0, ptr %p6969, align 4, !alias.scope !3, !noalias !4
  %v6970 = load i64, ptr %slot37, align 8
  store i64 %v6970, ptr %slot1339, align 8
  %v6971 = load i64, ptr %slot9, align 8
  %p6972 = inttoptr i64 %v6971 to ptr
  %ld6973 = load i32, ptr %p6972, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6973, ptr %slot1340, align 8
  %v6974 = load i32, ptr %slot1340, align 8
  %op6975 = and i32 %v6974, 28
  store i32 %op6975, ptr %slot1341, align 8
  %v6976 = load i32, ptr %slot1341, align 8
  %cv6977 = zext i32 %v6976 to i64
  %cond6978 = icmp ne i64 %cv6977, 0
  br i1 %cond6978, label %bb_rcslotrole2500, label %bb_rcslotowner2500
bb_rcslotrole2500:
  %v6979 = load i64, ptr %slot56, align 8
  store i64 %v6979, ptr %slot1342, align 8
  %v6980 = load i64, ptr %slot1342, align 8
  %v6981 = load i64, ptr %slot1339, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v6980, i64 %v6981) nomerge, !dbg !168
  br label %bb_rcslotdone2500
bb_rcslotowner2500:
  %v6982 = load i64, ptr %slot56, align 8
  store i64 %v6982, ptr %slot1343, align 8
  %v6983 = load i64, ptr %slot1343, align 8
  %v6984 = load i64, ptr %slot1339, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v6983, i64 %v6984) nomerge, !dbg !168
  br label %bb_rcslotdone2500
bb_rcslotdone2500:
  %v6985 = load i64, ptr %slot6, align 8
  %p6986 = inttoptr i64 %v6985 to ptr
  %ld6987 = load i32, ptr %p6986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6987, ptr %slot1344, align 8
  %v6988 = load i32, ptr %slot1344, align 8
  %cv6989 = zext i32 %v6988 to i64
  %cond6990 = icmp ne i64 %cv6989, 0
  br i1 %cond6990, label %bb_rcslotdrop2509, label %bb_rcslotdone2509
bb_rcslotdrop2509:
  %v6991 = load i64, ptr %slot6, align 8
  %p6992 = inttoptr i64 %v6991 to ptr
  store i32 0, ptr %p6992, align 4, !alias.scope !3, !noalias !4
  %v6993 = load i64, ptr %slot36, align 8
  store i64 %v6993, ptr %slot1345, align 8
  %v6994 = load i64, ptr %slot7, align 8
  %p6995 = inttoptr i64 %v6994 to ptr
  %ld6996 = load i32, ptr %p6995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6996, ptr %slot1346, align 8
  %v6997 = load i32, ptr %slot1346, align 8
  %op6998 = and i32 %v6997, 28
  store i32 %op6998, ptr %slot1347, align 8
  %v6999 = load i32, ptr %slot1347, align 8
  %cv7000 = zext i32 %v6999 to i64
  %cond7001 = icmp ne i64 %cv7000, 0
  br i1 %cond7001, label %bb_rcslotrole2509, label %bb_rcslotowner2509
bb_rcslotrole2509:
  %v7002 = load i64, ptr %slot56, align 8
  store i64 %v7002, ptr %slot1348, align 8
  %v7003 = load i64, ptr %slot1348, align 8
  %v7004 = load i64, ptr %slot1345, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v7003, i64 %v7004) nomerge, !dbg !168
  br label %bb_rcslotdone2509
bb_rcslotowner2509:
  %v7005 = load i64, ptr %slot56, align 8
  store i64 %v7005, ptr %slot1349, align 8
  %v7006 = load i64, ptr %slot1349, align 8
  %v7007 = load i64, ptr %slot1345, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v7006, i64 %v7007) nomerge, !dbg !168
  br label %bb_rcslotdone2509
bb_rcslotdone2509:
  %v7008 = load i64, ptr %slot1283, align 8
  %p7009 = inttoptr i64 %v7008 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p7009, i64 24, i1 false)
  ret void
bb_i63:
  %v7010 = load i64, ptr %slot32, align 8
  %p7011 = inttoptr i64 %v7010 to ptr
  %ld7012 = load i64, ptr %p7011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7012, ptr %slot1350, align 8
  %v7013 = load i64, ptr %slot1350, align 8
  %v7014 = load i64, ptr %slot47, align 8
  %p7015 = inttoptr i64 %v7014 to ptr
  store i64 %v7013, ptr %p7015, align 8, !alias.scope !3, !noalias !4
  %v7016 = load i64, ptr %slot46, align 8
  %v7017 = load i64, ptr %slot48, align 8
  %p7018 = inttoptr i64 %v7017 to ptr
  store i64 %v7016, ptr %p7018, align 8, !alias.scope !3, !noalias !4
  %v7019 = load i64, ptr %slot48, align 8
  %p7020 = inttoptr i64 %v7019 to ptr
  %ld7021 = load i64, ptr %p7020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7021, ptr %slot1351, align 8
  %v7022 = load i64, ptr %slot1351, align 8
  %op7023 = add i64 %v7022, 40
  store i64 %op7023, ptr %slot1352, align 8
  %v7024 = load i64, ptr %slot1352, align 8
  %p7025 = inttoptr i64 %v7024 to ptr
  %ld7026 = load i64, ptr %p7025, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7026, ptr %slot1353, align 8
  %v7027 = load i64, ptr %slot1353, align 8
  %v7028 = load i64, ptr %slot48, align 8
  %p7029 = inttoptr i64 %v7028 to ptr
  store i64 %v7027, ptr %p7029, align 8, !alias.scope !3, !noalias !4
  %v7030 = load i64, ptr %slot46, align 8
  %v7031 = load i64, ptr %slot49, align 8
  %p7032 = inttoptr i64 %v7031 to ptr
  store i64 %v7030, ptr %p7032, align 8, !alias.scope !3, !noalias !4
  %v7033 = load i64, ptr %slot49, align 8
  %p7034 = inttoptr i64 %v7033 to ptr
  %ld7035 = load i64, ptr %p7034, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7035, ptr %slot1354, align 8
  %v7036 = load i64, ptr %slot1354, align 8
  %op7037 = add i64 %v7036, 48
  store i64 %op7037, ptr %slot1355, align 8
  %v7038 = load i64, ptr %slot1355, align 8
  %p7039 = inttoptr i64 %v7038 to ptr
  %ld7040 = load i64, ptr %p7039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7040, ptr %slot1356, align 8
  %v7041 = load i64, ptr %slot1356, align 8
  %v7042 = load i64, ptr %slot49, align 8
  %p7043 = inttoptr i64 %v7042 to ptr
  store i64 %v7041, ptr %p7043, align 8, !alias.scope !3, !noalias !4
  %v7044 = load i64, ptr %slot46, align 8
  %v7045 = load i64, ptr %slot50, align 8
  %p7046 = inttoptr i64 %v7045 to ptr
  store i64 %v7044, ptr %p7046, align 8, !alias.scope !3, !noalias !4
  %v7047 = load i64, ptr %slot50, align 8
  %p7048 = inttoptr i64 %v7047 to ptr
  %ld7049 = load i64, ptr %p7048, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7049, ptr %slot1357, align 8
  %v7050 = load i64, ptr %slot1357, align 8
  %op7051 = add i64 %v7050, 56
  store i64 %op7051, ptr %slot1358, align 8
  %v7052 = load i64, ptr %slot1358, align 8
  %p7053 = inttoptr i64 %v7052 to ptr
  %ld7054 = load i64, ptr %p7053, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7054, ptr %slot1359, align 8
  %v7055 = load i64, ptr %slot1359, align 8
  %v7056 = load i64, ptr %slot50, align 8
  %p7057 = inttoptr i64 %v7056 to ptr
  store i64 %v7055, ptr %p7057, align 8, !alias.scope !3, !noalias !4
  %v7058 = load i64, ptr %slot46, align 8
  %v7059 = load i64, ptr %slot51, align 8
  %p7060 = inttoptr i64 %v7059 to ptr
  store i64 %v7058, ptr %p7060, align 8, !alias.scope !3, !noalias !4
  %v7061 = load i64, ptr %slot51, align 8
  %p7062 = inttoptr i64 %v7061 to ptr
  %ld7063 = load i64, ptr %p7062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7063, ptr %slot1360, align 8
  %v7064 = load i64, ptr %slot1360, align 8
  %op7065 = add i64 %v7064, 0
  store i64 %op7065, ptr %slot1361, align 8
  %v7066 = load i64, ptr %slot1361, align 8
  %v7067 = load i64, ptr %slot51, align 8
  %p7068 = inttoptr i64 %v7067 to ptr
  store i64 %v7066, ptr %p7068, align 8, !alias.scope !3, !noalias !4
  %v7069 = load i64, ptr %slot51, align 8
  %p7070 = inttoptr i64 %v7069 to ptr
  %ld7071 = load i64, ptr %p7070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7071, ptr %slot1362, align 8
  %v7072 = load i64, ptr %slot1362, align 8
  %op7073 = add i64 %v7072, 24
  store i64 %op7073, ptr %slot1363, align 8
  %v7074 = load i64, ptr %slot1363, align 8
  %p7075 = inttoptr i64 %v7074 to ptr
  %ld7076 = load i64, ptr %p7075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7076, ptr %slot1364, align 8
  %v7077 = load i64, ptr %slot1364, align 8
  %v7078 = load i64, ptr %slot51, align 8
  %p7079 = inttoptr i64 %v7078 to ptr
  store i64 %v7077, ptr %p7079, align 8, !alias.scope !3, !noalias !4
  %v7080 = load i64, ptr %slot47, align 8
  %p7081 = inttoptr i64 %v7080 to ptr
  %ld7082 = load i64, ptr %p7081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7082, ptr %slot1365, align 8
  %v7083 = load i64, ptr %slot48, align 8
  %p7084 = inttoptr i64 %v7083 to ptr
  %ld7085 = load i64, ptr %p7084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7085, ptr %slot1366, align 8
  %v7086 = load i64, ptr %slot49, align 8
  %p7087 = inttoptr i64 %v7086 to ptr
  %ld7088 = load i64, ptr %p7087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7088, ptr %slot1367, align 8
  %v7089 = load i64, ptr %slot50, align 8
  %p7090 = inttoptr i64 %v7089 to ptr
  %ld7091 = load i64, ptr %p7090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7091, ptr %slot1368, align 8
  %v7092 = load i64, ptr %slot51, align 8
  %p7093 = inttoptr i64 %v7092 to ptr
  %ld7094 = load i64, ptr %p7093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7094, ptr %slot1369, align 8
  %v7095 = load i64, ptr %slot1, align 8
  %v7096 = load i64, ptr %slot1365, align 8
  %v7097 = load i64, ptr %slot1366, align 8
  %v7098 = load i64, ptr %slot1367, align 8
  %v7099 = load i64, ptr %slot1368, align 8
  %v7100 = load i64, ptr %slot1369, align 8
  call void @myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0(ptr sret([24 x i8]) align 8 %callresult1371, i64 %v7095, i64 %v7096, i64 %v7097, i64 %v7098, i64 %v7099, i64 %v7100) nomerge, !dbg !170
  %addr7101 = ptrtoint ptr %callresult1371 to i64
  store i64 %addr7101, ptr %slot1370, align 8
  %v7102 = load i64, ptr %slot1370, align 8
  %v7103 = load i64, ptr %slot47, align 8
  %p7104 = inttoptr i64 %v7103 to ptr
  store i64 %v7102, ptr %p7104, align 8, !alias.scope !3, !noalias !4
  %v7105 = load i64, ptr %slot47, align 8
  %p7106 = inttoptr i64 %v7105 to ptr
  %ld7107 = load i64, ptr %p7106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7107, ptr %slot1372, align 8
  %v7108 = load i64, ptr %slot31, align 8
  store i64 %v7108, ptr %slot1373, align 8
  %v7109 = load i64, ptr %slot1372, align 8
  %v7110 = load i64, ptr %slot1373, align 8
  %p7111 = inttoptr i64 %v7109 to ptr
  %p7112 = inttoptr i64 %v7110 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7112, ptr %p7111, i64 24, i1 false)
  %v7113 = load i64, ptr %slot29, align 8
  %p7114 = inttoptr i64 %v7113 to ptr
  store i32 2, ptr %p7114, align 4, !alias.scope !3, !noalias !4
  %v7115 = load i64, ptr %slot28, align 8
  %p7116 = inttoptr i64 %v7115 to ptr
  store i32 1, ptr %p7116, align 4, !alias.scope !3, !noalias !4
  %v7117 = load i64, ptr %slot26, align 8
  %p7118 = inttoptr i64 %v7117 to ptr
  %ld7119 = load i32, ptr %p7118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7119, ptr %slot1374, align 8
  %v7120 = load i32, ptr %slot1374, align 8
  %cv7121 = zext i32 %v7120 to i64
  %cond7122 = icmp ne i64 %cv7121, 0
  br i1 %cond7122, label %bb_rcslotdrop2634, label %bb_rcslotdone2634
bb_rcslotdrop2634:
  %v7123 = load i64, ptr %slot26, align 8
  %p7124 = inttoptr i64 %v7123 to ptr
  store i32 0, ptr %p7124, align 4, !alias.scope !3, !noalias !4
  %v7125 = load i64, ptr %slot30, align 8
  store i64 %v7125, ptr %slot1375, align 8
  %v7126 = load i64, ptr %slot27, align 8
  %p7127 = inttoptr i64 %v7126 to ptr
  %ld7128 = load i32, ptr %p7127, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7128, ptr %slot1376, align 8
  %v7129 = load i32, ptr %slot1376, align 8
  %op7130 = and i32 %v7129, 28
  store i32 %op7130, ptr %slot1377, align 8
  %v7131 = load i32, ptr %slot1377, align 8
  %cv7132 = zext i32 %v7131 to i64
  %cond7133 = icmp ne i64 %cv7132, 0
  br i1 %cond7133, label %bb_rcslotrole2634, label %bb_rcslotowner2634
bb_rcslotrole2634:
  %v7134 = load i64, ptr %slot56, align 8
  store i64 %v7134, ptr %slot1378, align 8
  %v7135 = load i64, ptr %slot1378, align 8
  %v7136 = load i64, ptr %slot1375, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v7135, i64 %v7136) nomerge, !dbg !170
  br label %bb_rcslotdone2634
bb_rcslotowner2634:
  %v7137 = load i64, ptr %slot56, align 8
  store i64 %v7137, ptr %slot1379, align 8
  %v7138 = load i64, ptr %slot1379, align 8
  %v7139 = load i64, ptr %slot1375, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v7138, i64 %v7139) nomerge, !dbg !170
  br label %bb_rcslotdone2634
bb_rcslotdone2634:
  %v7140 = load i64, ptr %slot30, align 8
  store i64 %v7140, ptr %slot1380, align 8
  %v7141 = load i64, ptr %slot31, align 8
  store i64 %v7141, ptr %slot1381, align 8
  %v7142 = load i64, ptr %slot1381, align 8
  %v7143 = load i64, ptr %slot1380, align 8
  %p7144 = inttoptr i64 %v7142 to ptr
  %p7145 = inttoptr i64 %v7143 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7145, ptr %p7144, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7146 = load i64, ptr %slot27, align 8
  %p7147 = inttoptr i64 %v7146 to ptr
  store i32 2, ptr %p7147, align 4, !alias.scope !3, !noalias !4
  %v7148 = load i64, ptr %slot29, align 8
  %p7149 = inttoptr i64 %v7148 to ptr
  %ld7150 = load i32, ptr %p7149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7150, ptr %slot1382, align 8
  %v7151 = load i32, ptr %slot1382, align 8
  %v7152 = load i64, ptr %slot27, align 8
  %p7153 = inttoptr i64 %v7152 to ptr
  store i32 %v7151, ptr %p7153, align 4, !alias.scope !3, !noalias !4
  %v7154 = load i64, ptr %slot28, align 8
  %p7155 = inttoptr i64 %v7154 to ptr
  store i32 0, ptr %p7155, align 4, !alias.scope !3, !noalias !4
  %v7156 = load i64, ptr %slot26, align 8
  %p7157 = inttoptr i64 %v7156 to ptr
  store i32 1, ptr %p7157, align 4, !alias.scope !3, !noalias !4
  %v7158 = load i64, ptr %slot1380, align 8
  %v7159 = load i64, ptr %slot47, align 8
  %p7160 = inttoptr i64 %v7159 to ptr
  store i64 %v7158, ptr %p7160, align 8, !alias.scope !3, !noalias !4
  %v7161 = load i64, ptr %slot47, align 8
  %p7162 = inttoptr i64 %v7161 to ptr
  %ld7163 = load i64, ptr %p7162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7163, ptr %slot1383, align 8
  %v7164 = load i64, ptr %slot1383, align 8
  %p7165 = inttoptr i64 %v7164 to ptr
  %ld7166 = load i32, ptr %p7165, align 4, !alias.scope !3, !noalias !4
  %ext7167 = zext i32 %ld7166 to i64
  store i64 %ext7167, ptr %slot1384, align 8
  %v7168 = load i64, ptr %slot1384, align 8
  %cmp7169 = icmp eq i64 %v7168, 1
  %cv7170 = zext i1 %cmp7169 to i64
  store i64 %cv7170, ptr %slot1385, align 8
  %v7171 = load i64, ptr %slot1385, align 8
  %cond7172 = icmp ne i64 %v7171, 0
  br i1 %cond7172, label %bb_errtrace2651, label %bb_errtraced2651
bb_errtrace2651:
  %p7173 = inttoptr i64 ptrtoint (ptr @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p7173, i64 8589934666) "call-inline-cost"="0", !dbg !172
  br label %bb_errtraced2651
bb_errtraced2651:
  %v7174 = load i64, ptr %slot47, align 8
  %p7175 = inttoptr i64 %v7174 to ptr
  %ld7176 = load i64, ptr %p7175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7176, ptr %slot1386, align 8
  %v7177 = load i64, ptr %slot31, align 8
  store i64 %v7177, ptr %slot1387, align 8
  %v7178 = load i64, ptr %slot57, align 8
  store i64 %v7178, ptr %slot1388, align 8
  %v7179 = load i64, ptr %slot56, align 8
  %v7180 = load i64, ptr %slot1387, align 8
  %v7181 = load i64, ptr %slot1386, align 8
  %v7182 = load i64, ptr %slot1388, align 8
  %cv7183 = trunc i64 %v7182 to i32
  %call7184 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v7179, i64 %v7180, i64 %v7181, i32 %cv7183) nomerge, !dbg !172
  store i32 %call7184, ptr %slot1389, align 8
  %v7185 = load i32, ptr %slot1389, align 8
  %cv7186 = zext i32 %v7185 to i64
  %cond7187 = icmp ne i64 %cv7186, 0
  br i1 %cond7187, label %bb_rcsuccess2656, label %bb_rcfailure2656
bb_rcfailure2656:
  %v7188 = load i64, ptr %slot56, align 8
  %p7189 = inttoptr i64 %v7188 to ptr
  %call7190 = call i32 @myl_rc_take_failure(ptr %p7189) nomerge, !dbg !172
  store i32 %call7190, ptr %slot1390, align 8
  %v7191 = load i64, ptr %slot1, align 8
  %p7192 = inttoptr i64 %v7191 to ptr
  %v7193 = load i32, ptr %slot1390, align 8
  %call7194 = call i32 @myl_qbe_rc_status(ptr %p7192, i32 %v7193) nomerge, !dbg !172
  store i32 %call7194, ptr %slot1391, align 8
  br label %bb_failure
bb_rcsuccess2656:
  %v7195 = load i64, ptr %slot26, align 8
  %p7196 = inttoptr i64 %v7195 to ptr
  store i32 0, ptr %p7196, align 4, !alias.scope !3, !noalias !4
  %v7197 = load i64, ptr %slot29, align 8
  %p7198 = inttoptr i64 %v7197 to ptr
  store i32 2, ptr %p7198, align 4, !alias.scope !3, !noalias !4
  %v7199 = load i64, ptr %slot28, align 8
  %p7200 = inttoptr i64 %v7199 to ptr
  store i32 1, ptr %p7200, align 4, !alias.scope !3, !noalias !4
  %v7201 = load i64, ptr %slot31, align 8
  store i64 %v7201, ptr %slot1392, align 8
  %v7202 = load i64, ptr %slot28, align 8
  %p7203 = inttoptr i64 %v7202 to ptr
  store i32 0, ptr %p7203, align 4, !alias.scope !3, !noalias !4
  %v7204 = load i64, ptr %slot26, align 8
  %p7205 = inttoptr i64 %v7204 to ptr
  %ld7206 = load i32, ptr %p7205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7206, ptr %slot1393, align 8
  %v7207 = load i32, ptr %slot1393, align 8
  %cv7208 = zext i32 %v7207 to i64
  %cond7209 = icmp ne i64 %cv7208, 0
  br i1 %cond7209, label %bb_rcslotdrop2666, label %bb_rcslotdone2666
bb_rcslotdrop2666:
  %v7210 = load i64, ptr %slot26, align 8
  %p7211 = inttoptr i64 %v7210 to ptr
  store i32 0, ptr %p7211, align 4, !alias.scope !3, !noalias !4
  %v7212 = load i64, ptr %slot30, align 8
  store i64 %v7212, ptr %slot1394, align 8
  %v7213 = load i64, ptr %slot27, align 8
  %p7214 = inttoptr i64 %v7213 to ptr
  %ld7215 = load i32, ptr %p7214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7215, ptr %slot1395, align 8
  %v7216 = load i32, ptr %slot1395, align 8
  %op7217 = and i32 %v7216, 28
  store i32 %op7217, ptr %slot1396, align 8
  %v7218 = load i32, ptr %slot1396, align 8
  %cv7219 = zext i32 %v7218 to i64
  %cond7220 = icmp ne i64 %cv7219, 0
  br i1 %cond7220, label %bb_rcslotrole2666, label %bb_rcslotowner2666
bb_rcslotrole2666:
  %v7221 = load i64, ptr %slot56, align 8
  store i64 %v7221, ptr %slot1397, align 8
  %v7222 = load i64, ptr %slot1397, align 8
  %v7223 = load i64, ptr %slot1394, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v7222, i64 %v7223) nomerge, !dbg !172
  br label %bb_rcslotdone2666
bb_rcslotowner2666:
  %v7224 = load i64, ptr %slot56, align 8
  store i64 %v7224, ptr %slot1398, align 8
  %v7225 = load i64, ptr %slot1398, align 8
  %v7226 = load i64, ptr %slot1394, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v7225, i64 %v7226) nomerge, !dbg !172
  br label %bb_rcslotdone2666
bb_rcslotdone2666:
  %v7227 = load i64, ptr %slot24, align 8
  %p7228 = inttoptr i64 %v7227 to ptr
  %ld7229 = load i32, ptr %p7228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7229, ptr %slot1399, align 8
  %v7230 = load i32, ptr %slot1399, align 8
  %cv7231 = zext i32 %v7230 to i64
  %cond7232 = icmp ne i64 %cv7231, 0
  br i1 %cond7232, label %bb_rcslotdrop2675, label %bb_rcslotdone2675
bb_rcslotdrop2675:
  %v7233 = load i64, ptr %slot24, align 8
  %p7234 = inttoptr i64 %v7233 to ptr
  store i32 0, ptr %p7234, align 4, !alias.scope !3, !noalias !4
  %v7235 = load i64, ptr %slot46, align 8
  store i64 %v7235, ptr %slot1400, align 8
  %v7236 = load i64, ptr %slot25, align 8
  %p7237 = inttoptr i64 %v7236 to ptr
  %ld7238 = load i32, ptr %p7237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7238, ptr %slot1401, align 8
  %v7239 = load i32, ptr %slot1401, align 8
  %op7240 = and i32 %v7239, 28
  store i32 %op7240, ptr %slot1402, align 8
  %v7241 = load i32, ptr %slot1402, align 8
  %cv7242 = zext i32 %v7241 to i64
  %cond7243 = icmp ne i64 %cv7242, 0
  br i1 %cond7243, label %bb_rcslotrole2675, label %bb_rcslotowner2675
bb_rcslotrole2675:
  %v7244 = load i64, ptr %slot56, align 8
  store i64 %v7244, ptr %slot1403, align 8
  %v7245 = load i64, ptr %slot1403, align 8
  %v7246 = load i64, ptr %slot1400, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64 %v7245, i64 %v7246) nomerge, !dbg !172
  br label %bb_rcslotdone2675
bb_rcslotowner2675:
  %v7247 = load i64, ptr %slot56, align 8
  store i64 %v7247, ptr %slot1404, align 8
  %v7248 = load i64, ptr %slot1404, align 8
  %v7249 = load i64, ptr %slot1400, align 8
  call void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64 %v7248, i64 %v7249) nomerge, !dbg !172
  br label %bb_rcslotdone2675
bb_rcslotdone2675:
  %v7250 = load i64, ptr %slot22, align 8
  %p7251 = inttoptr i64 %v7250 to ptr
  %ld7252 = load i32, ptr %p7251, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7252, ptr %slot1405, align 8
  %v7253 = load i32, ptr %slot1405, align 8
  %cv7254 = zext i32 %v7253 to i64
  %cond7255 = icmp ne i64 %cv7254, 0
  br i1 %cond7255, label %bb_rcslotdrop2684, label %bb_rcslotdone2684
bb_rcslotdrop2684:
  %v7256 = load i64, ptr %slot22, align 8
  %p7257 = inttoptr i64 %v7256 to ptr
  store i32 0, ptr %p7257, align 4, !alias.scope !3, !noalias !4
  %v7258 = load i64, ptr %slot45, align 8
  store i64 %v7258, ptr %slot1406, align 8
  %v7259 = load i64, ptr %slot23, align 8
  %p7260 = inttoptr i64 %v7259 to ptr
  %ld7261 = load i32, ptr %p7260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7261, ptr %slot1407, align 8
  %v7262 = load i32, ptr %slot1407, align 8
  %op7263 = and i32 %v7262, 28
  store i32 %op7263, ptr %slot1408, align 8
  %v7264 = load i32, ptr %slot1408, align 8
  %cv7265 = zext i32 %v7264 to i64
  %cond7266 = icmp ne i64 %cv7265, 0
  br i1 %cond7266, label %bb_rcslotrole2684, label %bb_rcslotowner2684
bb_rcslotrole2684:
  %v7267 = load i64, ptr %slot56, align 8
  store i64 %v7267, ptr %slot1409, align 8
  %v7268 = load i64, ptr %slot1409, align 8
  %v7269 = load i64, ptr %slot1406, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v7268, i64 %v7269) nomerge, !dbg !172
  br label %bb_rcslotdone2684
bb_rcslotowner2684:
  %v7270 = load i64, ptr %slot56, align 8
  store i64 %v7270, ptr %slot1410, align 8
  %v7271 = load i64, ptr %slot1410, align 8
  %v7272 = load i64, ptr %slot1406, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v7271, i64 %v7272) nomerge, !dbg !172
  br label %bb_rcslotdone2684
bb_rcslotdone2684:
  %v7273 = load i64, ptr %slot20, align 8
  %p7274 = inttoptr i64 %v7273 to ptr
  %ld7275 = load i32, ptr %p7274, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7275, ptr %slot1411, align 8
  %v7276 = load i32, ptr %slot1411, align 8
  %cv7277 = zext i32 %v7276 to i64
  %cond7278 = icmp ne i64 %cv7277, 0
  br i1 %cond7278, label %bb_rcslotdrop2693, label %bb_rcslotdone2693
bb_rcslotdrop2693:
  %v7279 = load i64, ptr %slot20, align 8
  %p7280 = inttoptr i64 %v7279 to ptr
  store i32 0, ptr %p7280, align 4, !alias.scope !3, !noalias !4
  %v7281 = load i64, ptr %slot44, align 8
  store i64 %v7281, ptr %slot1412, align 8
  %v7282 = load i64, ptr %slot21, align 8
  %p7283 = inttoptr i64 %v7282 to ptr
  %ld7284 = load i32, ptr %p7283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7284, ptr %slot1413, align 8
  %v7285 = load i32, ptr %slot1413, align 8
  %op7286 = and i32 %v7285, 28
  store i32 %op7286, ptr %slot1414, align 8
  %v7287 = load i32, ptr %slot1414, align 8
  %cv7288 = zext i32 %v7287 to i64
  %cond7289 = icmp ne i64 %cv7288, 0
  br i1 %cond7289, label %bb_rcslotrole2693, label %bb_rcslotowner2693
bb_rcslotrole2693:
  %v7290 = load i64, ptr %slot56, align 8
  store i64 %v7290, ptr %slot1415, align 8
  %v7291 = load i64, ptr %slot1415, align 8
  %v7292 = load i64, ptr %slot1412, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64 %v7291, i64 %v7292) nomerge, !dbg !172
  br label %bb_rcslotdone2693
bb_rcslotowner2693:
  %v7293 = load i64, ptr %slot56, align 8
  store i64 %v7293, ptr %slot1416, align 8
  %v7294 = load i64, ptr %slot1416, align 8
  %v7295 = load i64, ptr %slot1412, align 8
  call void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64 %v7294, i64 %v7295) nomerge, !dbg !172
  br label %bb_rcslotdone2693
bb_rcslotdone2693:
  %v7296 = load i64, ptr %slot18, align 8
  %p7297 = inttoptr i64 %v7296 to ptr
  %ld7298 = load i32, ptr %p7297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7298, ptr %slot1417, align 8
  %v7299 = load i32, ptr %slot1417, align 8
  %cv7300 = zext i32 %v7299 to i64
  %cond7301 = icmp ne i64 %cv7300, 0
  br i1 %cond7301, label %bb_rcslotdrop2702, label %bb_rcslotdone2702
bb_rcslotdrop2702:
  %v7302 = load i64, ptr %slot18, align 8
  %p7303 = inttoptr i64 %v7302 to ptr
  store i32 0, ptr %p7303, align 4, !alias.scope !3, !noalias !4
  %v7304 = load i64, ptr %slot43, align 8
  store i64 %v7304, ptr %slot1418, align 8
  %v7305 = load i64, ptr %slot19, align 8
  %p7306 = inttoptr i64 %v7305 to ptr
  %ld7307 = load i32, ptr %p7306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7307, ptr %slot1419, align 8
  %v7308 = load i32, ptr %slot1419, align 8
  %op7309 = and i32 %v7308, 28
  store i32 %op7309, ptr %slot1420, align 8
  %v7310 = load i32, ptr %slot1420, align 8
  %cv7311 = zext i32 %v7310 to i64
  %cond7312 = icmp ne i64 %cv7311, 0
  br i1 %cond7312, label %bb_rcslotrole2702, label %bb_rcslotowner2702
bb_rcslotrole2702:
  %v7313 = load i64, ptr %slot56, align 8
  store i64 %v7313, ptr %slot1421, align 8
  %v7314 = load i64, ptr %slot1421, align 8
  %v7315 = load i64, ptr %slot1418, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64 %v7314, i64 %v7315) nomerge, !dbg !172
  br label %bb_rcslotdone2702
bb_rcslotowner2702:
  %v7316 = load i64, ptr %slot56, align 8
  store i64 %v7316, ptr %slot1422, align 8
  %v7317 = load i64, ptr %slot1422, align 8
  %v7318 = load i64, ptr %slot1418, align 8
  call void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64 %v7317, i64 %v7318) nomerge, !dbg !172
  br label %bb_rcslotdone2702
bb_rcslotdone2702:
  %v7319 = load i64, ptr %slot16, align 8
  %p7320 = inttoptr i64 %v7319 to ptr
  %ld7321 = load i32, ptr %p7320, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7321, ptr %slot1423, align 8
  %v7322 = load i32, ptr %slot1423, align 8
  %cv7323 = zext i32 %v7322 to i64
  %cond7324 = icmp ne i64 %cv7323, 0
  br i1 %cond7324, label %bb_rcslotdrop2711, label %bb_rcslotdone2711
bb_rcslotdrop2711:
  %v7325 = load i64, ptr %slot16, align 8
  %p7326 = inttoptr i64 %v7325 to ptr
  store i32 0, ptr %p7326, align 4, !alias.scope !3, !noalias !4
  %v7327 = load i64, ptr %slot42, align 8
  store i64 %v7327, ptr %slot1424, align 8
  %v7328 = load i64, ptr %slot17, align 8
  %p7329 = inttoptr i64 %v7328 to ptr
  %ld7330 = load i32, ptr %p7329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7330, ptr %slot1425, align 8
  %v7331 = load i32, ptr %slot1425, align 8
  %op7332 = and i32 %v7331, 28
  store i32 %op7332, ptr %slot1426, align 8
  %v7333 = load i32, ptr %slot1426, align 8
  %cv7334 = zext i32 %v7333 to i64
  %cond7335 = icmp ne i64 %cv7334, 0
  br i1 %cond7335, label %bb_rcslotrole2711, label %bb_rcslotowner2711
bb_rcslotrole2711:
  %v7336 = load i64, ptr %slot56, align 8
  store i64 %v7336, ptr %slot1427, align 8
  %v7337 = load i64, ptr %slot1427, align 8
  %v7338 = load i64, ptr %slot1424, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64 %v7337, i64 %v7338) nomerge, !dbg !172
  br label %bb_rcslotdone2711
bb_rcslotowner2711:
  %v7339 = load i64, ptr %slot56, align 8
  store i64 %v7339, ptr %slot1428, align 8
  %v7340 = load i64, ptr %slot1428, align 8
  %v7341 = load i64, ptr %slot1424, align 8
  call void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64 %v7340, i64 %v7341) nomerge, !dbg !172
  br label %bb_rcslotdone2711
bb_rcslotdone2711:
  %v7342 = load i64, ptr %slot14, align 8
  %p7343 = inttoptr i64 %v7342 to ptr
  %ld7344 = load i32, ptr %p7343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7344, ptr %slot1429, align 8
  %v7345 = load i32, ptr %slot1429, align 8
  %cv7346 = zext i32 %v7345 to i64
  %cond7347 = icmp ne i64 %cv7346, 0
  br i1 %cond7347, label %bb_rcslotdrop2720, label %bb_rcslotdone2720
bb_rcslotdrop2720:
  %v7348 = load i64, ptr %slot14, align 8
  %p7349 = inttoptr i64 %v7348 to ptr
  store i32 0, ptr %p7349, align 4, !alias.scope !3, !noalias !4
  %v7350 = load i64, ptr %slot41, align 8
  store i64 %v7350, ptr %slot1430, align 8
  %v7351 = load i64, ptr %slot15, align 8
  %p7352 = inttoptr i64 %v7351 to ptr
  %ld7353 = load i32, ptr %p7352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7353, ptr %slot1431, align 8
  %v7354 = load i32, ptr %slot1431, align 8
  %op7355 = and i32 %v7354, 28
  store i32 %op7355, ptr %slot1432, align 8
  %v7356 = load i32, ptr %slot1432, align 8
  %cv7357 = zext i32 %v7356 to i64
  %cond7358 = icmp ne i64 %cv7357, 0
  br i1 %cond7358, label %bb_rcslotrole2720, label %bb_rcslotowner2720
bb_rcslotrole2720:
  %v7359 = load i64, ptr %slot56, align 8
  store i64 %v7359, ptr %slot1433, align 8
  %v7360 = load i64, ptr %slot1433, align 8
  %v7361 = load i64, ptr %slot1430, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64 %v7360, i64 %v7361) nomerge, !dbg !172
  br label %bb_rcslotdone2720
bb_rcslotowner2720:
  %v7362 = load i64, ptr %slot56, align 8
  store i64 %v7362, ptr %slot1434, align 8
  %v7363 = load i64, ptr %slot1434, align 8
  %v7364 = load i64, ptr %slot1430, align 8
  call void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64 %v7363, i64 %v7364) nomerge, !dbg !172
  br label %bb_rcslotdone2720
bb_rcslotdone2720:
  %v7365 = load i64, ptr %slot12, align 8
  %p7366 = inttoptr i64 %v7365 to ptr
  %ld7367 = load i32, ptr %p7366, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7367, ptr %slot1435, align 8
  %v7368 = load i32, ptr %slot1435, align 8
  %cv7369 = zext i32 %v7368 to i64
  %cond7370 = icmp ne i64 %cv7369, 0
  br i1 %cond7370, label %bb_rcslotdrop2729, label %bb_rcslotdone2729
bb_rcslotdrop2729:
  %v7371 = load i64, ptr %slot12, align 8
  %p7372 = inttoptr i64 %v7371 to ptr
  store i32 0, ptr %p7372, align 4, !alias.scope !3, !noalias !4
  %v7373 = load i64, ptr %slot40, align 8
  store i64 %v7373, ptr %slot1436, align 8
  %v7374 = load i64, ptr %slot13, align 8
  %p7375 = inttoptr i64 %v7374 to ptr
  %ld7376 = load i32, ptr %p7375, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7376, ptr %slot1437, align 8
  %v7377 = load i32, ptr %slot1437, align 8
  %op7378 = and i32 %v7377, 28
  store i32 %op7378, ptr %slot1438, align 8
  %v7379 = load i32, ptr %slot1438, align 8
  %cv7380 = zext i32 %v7379 to i64
  %cond7381 = icmp ne i64 %cv7380, 0
  br i1 %cond7381, label %bb_rcslotrole2729, label %bb_rcslotowner2729
bb_rcslotrole2729:
  %v7382 = load i64, ptr %slot56, align 8
  store i64 %v7382, ptr %slot1439, align 8
  %v7383 = load i64, ptr %slot1439, align 8
  %v7384 = load i64, ptr %slot1436, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64 %v7383, i64 %v7384) nomerge, !dbg !172
  br label %bb_rcslotdone2729
bb_rcslotowner2729:
  %v7385 = load i64, ptr %slot56, align 8
  store i64 %v7385, ptr %slot1440, align 8
  %v7386 = load i64, ptr %slot1440, align 8
  %v7387 = load i64, ptr %slot1436, align 8
  call void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64 %v7386, i64 %v7387) nomerge, !dbg !172
  br label %bb_rcslotdone2729
bb_rcslotdone2729:
  %v7388 = load i64, ptr %slot10, align 8
  %p7389 = inttoptr i64 %v7388 to ptr
  %ld7390 = load i32, ptr %p7389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7390, ptr %slot1441, align 8
  %v7391 = load i32, ptr %slot1441, align 8
  %cv7392 = zext i32 %v7391 to i64
  %cond7393 = icmp ne i64 %cv7392, 0
  br i1 %cond7393, label %bb_rcslotdrop2738, label %bb_rcslotdone2738
bb_rcslotdrop2738:
  %v7394 = load i64, ptr %slot10, align 8
  %p7395 = inttoptr i64 %v7394 to ptr
  store i32 0, ptr %p7395, align 4, !alias.scope !3, !noalias !4
  %v7396 = load i64, ptr %slot38, align 8
  store i64 %v7396, ptr %slot1442, align 8
  %v7397 = load i64, ptr %slot11, align 8
  %p7398 = inttoptr i64 %v7397 to ptr
  %ld7399 = load i32, ptr %p7398, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7399, ptr %slot1443, align 8
  %v7400 = load i32, ptr %slot1443, align 8
  %op7401 = and i32 %v7400, 28
  store i32 %op7401, ptr %slot1444, align 8
  %v7402 = load i32, ptr %slot1444, align 8
  %cv7403 = zext i32 %v7402 to i64
  %cond7404 = icmp ne i64 %cv7403, 0
  br i1 %cond7404, label %bb_rcslotrole2738, label %bb_rcslotowner2738
bb_rcslotrole2738:
  %v7405 = load i64, ptr %slot56, align 8
  store i64 %v7405, ptr %slot1445, align 8
  %v7406 = load i64, ptr %slot1445, align 8
  %v7407 = load i64, ptr %slot1442, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64 %v7406, i64 %v7407) nomerge, !dbg !172
  br label %bb_rcslotdone2738
bb_rcslotowner2738:
  %v7408 = load i64, ptr %slot56, align 8
  store i64 %v7408, ptr %slot1446, align 8
  %v7409 = load i64, ptr %slot1446, align 8
  %v7410 = load i64, ptr %slot1442, align 8
  call void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64 %v7409, i64 %v7410) nomerge, !dbg !172
  br label %bb_rcslotdone2738
bb_rcslotdone2738:
  %v7411 = load i64, ptr %slot8, align 8
  %p7412 = inttoptr i64 %v7411 to ptr
  %ld7413 = load i32, ptr %p7412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7413, ptr %slot1447, align 8
  %v7414 = load i32, ptr %slot1447, align 8
  %cv7415 = zext i32 %v7414 to i64
  %cond7416 = icmp ne i64 %cv7415, 0
  br i1 %cond7416, label %bb_rcslotdrop2747, label %bb_rcslotdone2747
bb_rcslotdrop2747:
  %v7417 = load i64, ptr %slot8, align 8
  %p7418 = inttoptr i64 %v7417 to ptr
  store i32 0, ptr %p7418, align 4, !alias.scope !3, !noalias !4
  %v7419 = load i64, ptr %slot37, align 8
  store i64 %v7419, ptr %slot1448, align 8
  %v7420 = load i64, ptr %slot9, align 8
  %p7421 = inttoptr i64 %v7420 to ptr
  %ld7422 = load i32, ptr %p7421, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7422, ptr %slot1449, align 8
  %v7423 = load i32, ptr %slot1449, align 8
  %op7424 = and i32 %v7423, 28
  store i32 %op7424, ptr %slot1450, align 8
  %v7425 = load i32, ptr %slot1450, align 8
  %cv7426 = zext i32 %v7425 to i64
  %cond7427 = icmp ne i64 %cv7426, 0
  br i1 %cond7427, label %bb_rcslotrole2747, label %bb_rcslotowner2747
bb_rcslotrole2747:
  %v7428 = load i64, ptr %slot56, align 8
  store i64 %v7428, ptr %slot1451, align 8
  %v7429 = load i64, ptr %slot1451, align 8
  %v7430 = load i64, ptr %slot1448, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64 %v7429, i64 %v7430) nomerge, !dbg !172
  br label %bb_rcslotdone2747
bb_rcslotowner2747:
  %v7431 = load i64, ptr %slot56, align 8
  store i64 %v7431, ptr %slot1452, align 8
  %v7432 = load i64, ptr %slot1452, align 8
  %v7433 = load i64, ptr %slot1448, align 8
  call void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64 %v7432, i64 %v7433) nomerge, !dbg !172
  br label %bb_rcslotdone2747
bb_rcslotdone2747:
  %v7434 = load i64, ptr %slot6, align 8
  %p7435 = inttoptr i64 %v7434 to ptr
  %ld7436 = load i32, ptr %p7435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7436, ptr %slot1453, align 8
  %v7437 = load i32, ptr %slot1453, align 8
  %cv7438 = zext i32 %v7437 to i64
  %cond7439 = icmp ne i64 %cv7438, 0
  br i1 %cond7439, label %bb_rcslotdrop2756, label %bb_rcslotdone2756
bb_rcslotdrop2756:
  %v7440 = load i64, ptr %slot6, align 8
  %p7441 = inttoptr i64 %v7440 to ptr
  store i32 0, ptr %p7441, align 4, !alias.scope !3, !noalias !4
  %v7442 = load i64, ptr %slot36, align 8
  store i64 %v7442, ptr %slot1454, align 8
  %v7443 = load i64, ptr %slot7, align 8
  %p7444 = inttoptr i64 %v7443 to ptr
  %ld7445 = load i32, ptr %p7444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7445, ptr %slot1455, align 8
  %v7446 = load i32, ptr %slot1455, align 8
  %op7447 = and i32 %v7446, 28
  store i32 %op7447, ptr %slot1456, align 8
  %v7448 = load i32, ptr %slot1456, align 8
  %cv7449 = zext i32 %v7448 to i64
  %cond7450 = icmp ne i64 %cv7449, 0
  br i1 %cond7450, label %bb_rcslotrole2756, label %bb_rcslotowner2756
bb_rcslotrole2756:
  %v7451 = load i64, ptr %slot56, align 8
  store i64 %v7451, ptr %slot1457, align 8
  %v7452 = load i64, ptr %slot1457, align 8
  %v7453 = load i64, ptr %slot1454, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64 %v7452, i64 %v7453) nomerge, !dbg !172
  br label %bb_rcslotdone2756
bb_rcslotowner2756:
  %v7454 = load i64, ptr %slot56, align 8
  store i64 %v7454, ptr %slot1458, align 8
  %v7455 = load i64, ptr %slot1458, align 8
  %v7456 = load i64, ptr %slot1454, align 8
  call void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64 %v7455, i64 %v7456) nomerge, !dbg !172
  br label %bb_rcslotdone2756
bb_rcslotdone2756:
  %v7457 = load i64, ptr %slot1392, align 8
  %p7458 = inttoptr i64 %v7457 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p7458, i64 24, i1 false)
  ret void
bb_failure:
  %v7459 = load i64, ptr %slot5, align 8
  %p7460 = inttoptr i64 %v7459 to ptr
  call void @llvm.memset.p0.i64(ptr %p7460, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !172
  %v7461 = load i64, ptr %slot5, align 8
  %p7462 = inttoptr i64 %v7461 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p7462, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v7463 = load i64, ptr %slot5, align 8
  %p7464 = inttoptr i64 %v7463 to ptr
  call void @llvm.memset.p0.i64(ptr %p7464, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !172
  %v7465 = load i64, ptr %slot5, align 8
  %p7466 = inttoptr i64 %v7465 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p7466, i64 24, i1 false)
  ret void
}

@myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_00df54ab2bd506d79f963e712b9a3f7789de5e5322e1a9bddad68090e51670b0(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_3dd24b2b8167f92811eb1aa75d06c05872b9880d7f900833ae7f6f032a592152(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_706a365e4bc67d4dbe31048a4b9bb57e9686317829d7947d70f33e26eb76ce88(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_72cff91e1ca43adf6e3bd650d1fe503b405034486590fc282e877edc70061b44(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_8fcbbbde32315b60b2a6da8b239f110b994a3e18d8c0042d9b7f76bb4a7f2ee0(ptr sret([24 x i8]) align 8, i64, i64, i64, i64, i64, i64)
declare void @myl_f_ace3269ad0fae9d1e7ed4173f8a72271ee6ee16c02f3b79ac71b6c929cdf9394(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_ad307cc2867f7ae8645edfb1559c37ecdae6ef88fa193238135e91f033295342(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_aebdc485d7756373248446bbe449e831b1afbb727357d693268ecc8fb629cd5b(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_efefaf187dbda74c0fc83883b6acb4fd651afe0399c3994d07d1373d88b055ca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_fe7a9b911e5976d536198547c07832bc757732c7fb0f639f1c35b8e4259d7e1e(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_drop(i64, i64)
declare i32 @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_unloan(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_drop(i64, i64)
declare i32 @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_354be59da1ce6b60bea6acb179fa87fff7449dacedb356e38902650fc9f7ed39_rcg_unloan(i64, i64)
declare void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_drop(i64, i64)
declare i32 @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_51d09aee7c0315b3aba97d602e52a0fedd602ab592836c5301ff256907ecd457_rcg_unloan(i64, i64)
declare void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_drop(i64, i64)
declare i32 @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_6abd693d3c458aa8b9dc6eb9b14e2eda801649c1db64304fbf9dcdf6572a8cd9_rcg_unloan(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare i32 @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_loan(i64, i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_drop(i64, i64)
declare i32 @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_8d30c7d92d10b42fd6d6b155be4b4f4627ad7a042e90a1a7260ccc17bd7d913b_rcg_unloan(i64, i64)
declare void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_drop(i64, i64)
declare i32 @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_9db29878bb870aedd7beb381f7773c3f7385b7f4bb65a46f8c7260f8d4ec45b9_rcg_unloan(i64, i64)
declare void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_drop(i64, i64)
declare i32 @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_unloan(i64, i64)
declare void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_drop(i64, i64)
declare i32 @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_bfba73c39e3a7396760d128ca6edcaee0ce40e965cf4cf9f9a961ceb2f570b93_rcg_unloan(i64, i64)
declare void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_drop(i64, i64)
declare i32 @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_unloan(i64, i64)
declare void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64, i64)
declare i32 @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca", linkageName: "myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17517795683475087247, i64 0, !"myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!126 = !DILocation(line: 21, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!128 = !DILocation(line: 22, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!130 = !DILocation(line: 25, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!132 = !DILocation(line: 26, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!136 = !DILocation(line: 30, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!138 = !DILocation(line: 33, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!140 = !DILocation(line: 34, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!142 = !DILocation(line: 38, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!144 = !DILocation(line: 39, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!146 = !DILocation(line: 42, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!148 = !DILocation(line: 43, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!150 = !DILocation(line: 46, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!152 = !DILocation(line: 47, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!154 = !DILocation(line: 50, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!156 = !DILocation(line: 51, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!158 = !DILocation(line: 54, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!160 = !DILocation(line: 55, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!162 = !DILocation(line: 58, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!164 = !DILocation(line: 59, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!166 = !DILocation(line: 62, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!168 = !DILocation(line: 63, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!170 = !DILocation(line: 74, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!172 = !DILocation(line: 75, column: 0, scope: !173)
