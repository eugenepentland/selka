target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v53 = load i64, ptr %slot1, align 8
  %op54 = add i64 %v53, 32
  store i64 %op54, ptr %slot3, align 8
  %mem55 = alloca i8, i64 8, align 8
  %ptr56 = ptrtoint ptr %mem55 to i64
  store i64 %ptr56, ptr %slot4, align 8
  %mem57 = alloca i8, i64 8, align 8
  %ptr58 = ptrtoint ptr %mem57 to i64
  store i64 %ptr58, ptr %slot5, align 8
  %mem59 = alloca i8, i64 8, align 8
  %ptr60 = ptrtoint ptr %mem59 to i64
  store i64 %ptr60, ptr %slot6, align 8
  %mem61 = alloca i8, i64 392, align 8
  %ptr62 = ptrtoint ptr %mem61 to i64
  store i64 %ptr62, ptr %slot7, align 8
  %mem63 = alloca i8, i64 392, align 8
  %ptr64 = ptrtoint ptr %mem63 to i64
  store i64 %ptr64, ptr %slot8, align 8
  %mem65 = alloca i8, i64 392, align 8
  %ptr66 = ptrtoint ptr %mem65 to i64
  store i64 %ptr66, ptr %slot9, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem67 = alloca i8, i64 8, align 8
  %ptr68 = ptrtoint ptr %mem67 to i64
  store i64 %ptr68, ptr %slot10, align 8
  %v69 = load i64, ptr %slot1, align 8
  %op70 = add i64 %v69, 64
  store i64 %op70, ptr %slot11, align 8
  %v71 = load i64, ptr %slot11, align 8
  %p72 = inttoptr i64 %v71 to ptr
  %ld73 = load i64, ptr %p72, align 8, !alias.scope !4, !noalias !3
  store i64 %ld73, ptr %slot12, align 8
  %stack74 = call ptr @llvm.stacksave()
  %stackaddr75 = ptrtoint ptr %stack74 to i64
  %v76 = load i64, ptr %slot12, align 8
  %cmp77 = icmp ult i64 %stackaddr75, %v76
  %cv78 = zext i1 %cmp77 to i64
  store i64 %cv78, ptr %slot13, align 8
  %v79 = load i64, ptr %slot13, align 8
  %cond80 = icmp ne i64 %v79, 0
  br i1 %cond80, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v81 = load i64, ptr %slot1, align 8
  %p82 = inttoptr i64 %v81 to ptr
  call void @myl_qbe_fail_frame(ptr %p82) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v83 = load i64, ptr %slot2, align 8
  %v84 = load i64, ptr %slot4, align 8
  %p85 = inttoptr i64 %v84 to ptr
  store i64 %v83, ptr %p85, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v86 = load i64, ptr %slot4, align 8
  %p87 = inttoptr i64 %v86 to ptr
  %ld88 = load i64, ptr %p87, align 8, !alias.scope !3, !noalias !4
  store i64 %ld88, ptr %slot14, align 8
  %v89 = load i64, ptr %slot14, align 8
  %v90 = load i64, ptr %slot5, align 8
  %p91 = inttoptr i64 %v90 to ptr
  store i64 %v89, ptr %p91, align 8, !alias.scope !3, !noalias !4
  %v92 = load i64, ptr %slot7, align 8
  store i64 %v92, ptr %slot15, align 8
  %v93 = load i64, ptr %slot15, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i32 0, ptr %p94, align 4, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot15, align 8
  %p96 = inttoptr i64 %v95 to ptr
  store i32 23, ptr %p96, align 4, !alias.scope !3, !noalias !4
  %v97 = load i64, ptr %slot15, align 8
  %v98 = load i64, ptr %slot6, align 8
  %p99 = inttoptr i64 %v98 to ptr
  store i64 %v97, ptr %p99, align 8, !alias.scope !3, !noalias !4
  %v100 = load i64, ptr %slot5, align 8
  %p101 = inttoptr i64 %v100 to ptr
  %ld102 = load i64, ptr %p101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld102, ptr %slot16, align 8
  %v103 = load i64, ptr %slot6, align 8
  %p104 = inttoptr i64 %v103 to ptr
  %ld105 = load i64, ptr %p104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld105, ptr %slot17, align 8
  %v106 = load i64, ptr %slot1, align 8
  %v107 = load i64, ptr %slot16, align 8
  %v108 = load i64, ptr %slot17, align 8
  %call109 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v106, i64 %v107, i64 %v108) nomerge, !dbg !112
  store i64 %call109, ptr %slot18, align 8
  %v110 = load i64, ptr %slot18, align 8
  %v111 = load i64, ptr %slot5, align 8
  %p112 = inttoptr i64 %v111 to ptr
  store i64 %v110, ptr %p112, align 8, !alias.scope !3, !noalias !4
  %v113 = load i64, ptr %slot5, align 8
  %p114 = inttoptr i64 %v113 to ptr
  %ld115 = load i64, ptr %p114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld115, ptr %slot19, align 8
  %v116 = load i64, ptr %slot19, align 8
  %cond117 = icmp ne i64 %v116, 0
  br i1 %cond117, label %bb_next23, label %bb_i8
bb_next23:
  %v118 = load i64, ptr %slot4, align 8
  %p119 = inttoptr i64 %v118 to ptr
  %ld120 = load i64, ptr %p119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld120, ptr %slot20, align 8
  %v121 = load i64, ptr %slot20, align 8
  %v122 = load i64, ptr %slot5, align 8
  %p123 = inttoptr i64 %v122 to ptr
  store i64 %v121, ptr %p123, align 8, !alias.scope !3, !noalias !4
  %v124 = load i64, ptr %slot5, align 8
  %p125 = inttoptr i64 %v124 to ptr
  %ld126 = load i64, ptr %p125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld126, ptr %slot21, align 8
  %v127 = load i64, ptr %slot1, align 8
  %v128 = load i64, ptr %slot21, align 8
  %call129 = call i64 @myl_f_5657e329775bff14911deaf3073b44d8b48138d6f620fddc6ba0d0819413d9d3(i64 %v127, i64 %v128) nomerge, !dbg !114
  store i64 %call129, ptr %slot22, align 8
  %v130 = load i64, ptr %slot22, align 8
  %v131 = load i64, ptr %slot5, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i64 %v130, ptr %p132, align 8, !alias.scope !3, !noalias !4
  br label %bb_i27
bb_i8:
  %v133 = load i64, ptr %slot4, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot23, align 8
  %v136 = load i64, ptr %slot23, align 8
  %v137 = load i64, ptr %slot5, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot8, align 8
  store i64 %v139, ptr %slot24, align 8
  %v140 = load i64, ptr %slot24, align 8
  %p141 = inttoptr i64 %v140 to ptr
  store i32 0, ptr %p141, align 4, !alias.scope !3, !noalias !4
  %v142 = load i64, ptr %slot24, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i32 27, ptr %p143, align 4, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot24, align 8
  %v145 = load i64, ptr %slot6, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot5, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot25, align 8
  %v150 = load i64, ptr %slot6, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld152, ptr %slot26, align 8
  %v153 = load i64, ptr %slot1, align 8
  %v154 = load i64, ptr %slot25, align 8
  %v155 = load i64, ptr %slot26, align 8
  %call156 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v153, i64 %v154, i64 %v155) nomerge, !dbg !116
  store i64 %call156, ptr %slot27, align 8
  %v157 = load i64, ptr %slot27, align 8
  %v158 = load i64, ptr %slot5, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i64 %v157, ptr %p159, align 8, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot5, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i64, ptr %p161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld162, ptr %slot28, align 8
  %v163 = load i64, ptr %slot28, align 8
  %cond164 = icmp ne i64 %v163, 0
  br i1 %cond164, label %bb_next50, label %bb_i16
bb_next50:
  %v165 = load i64, ptr %slot4, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld167, ptr %slot29, align 8
  %v168 = load i64, ptr %slot29, align 8
  %v169 = load i64, ptr %slot5, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i64 %v168, ptr %p170, align 8, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot5, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot30, align 8
  %v174 = load i64, ptr %slot1, align 8
  %v175 = load i64, ptr %slot30, align 8
  %call176 = call i64 @myl_f_d5b119a5754679ec7ac6b2bd0943fdb20ddd72671997692dd4bff9fbdca0372b(i64 %v174, i64 %v175) nomerge, !dbg !118
  store i64 %call176, ptr %slot31, align 8
  %v177 = load i64, ptr %slot31, align 8
  %v178 = load i64, ptr %slot5, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i64 %v177, ptr %p179, align 8, !alias.scope !3, !noalias !4
  br label %bb_i27
bb_i16:
  %v180 = load i64, ptr %slot4, align 8
  %p181 = inttoptr i64 %v180 to ptr
  %ld182 = load i64, ptr %p181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld182, ptr %slot32, align 8
  %v183 = load i64, ptr %slot32, align 8
  %v184 = load i64, ptr %slot5, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i64 %v183, ptr %p185, align 8, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot9, align 8
  store i64 %v186, ptr %slot33, align 8
  %v187 = load i64, ptr %slot33, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i32 0, ptr %p188, align 4, !alias.scope !3, !noalias !4
  %v189 = load i64, ptr %slot33, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i32 36, ptr %p190, align 4, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot33, align 8
  %v192 = load i64, ptr %slot6, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i64 %v191, ptr %p193, align 8, !alias.scope !3, !noalias !4
  %v194 = load i64, ptr %slot5, align 8
  %p195 = inttoptr i64 %v194 to ptr
  %ld196 = load i64, ptr %p195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld196, ptr %slot34, align 8
  %v197 = load i64, ptr %slot6, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot35, align 8
  %v200 = load i64, ptr %slot1, align 8
  %v201 = load i64, ptr %slot34, align 8
  %v202 = load i64, ptr %slot35, align 8
  %call203 = call i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64 %v200, i64 %v201, i64 %v202) nomerge, !dbg !120
  store i64 %call203, ptr %slot36, align 8
  %v204 = load i64, ptr %slot36, align 8
  %v205 = load i64, ptr %slot5, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i64 %v204, ptr %p206, align 8, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot5, align 8
  %p208 = inttoptr i64 %v207 to ptr
  %ld209 = load i64, ptr %p208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld209, ptr %slot37, align 8
  %v210 = load i64, ptr %slot37, align 8
  %cond211 = icmp ne i64 %v210, 0
  br i1 %cond211, label %bb_next77, label %bb_i24
bb_next77:
  %v212 = load i64, ptr %slot4, align 8
  %p213 = inttoptr i64 %v212 to ptr
  %ld214 = load i64, ptr %p213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld214, ptr %slot38, align 8
  %v215 = load i64, ptr %slot38, align 8
  %v216 = load i64, ptr %slot5, align 8
  %p217 = inttoptr i64 %v216 to ptr
  store i64 %v215, ptr %p217, align 8, !alias.scope !3, !noalias !4
  %v218 = load i64, ptr %slot5, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %ld220 = load i64, ptr %p219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld220, ptr %slot39, align 8
  %v221 = load i64, ptr %slot1, align 8
  %v222 = load i64, ptr %slot39, align 8
  %call223 = call i64 @myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45(i64 %v221, i64 %v222) nomerge, !dbg !122
  store i64 %call223, ptr %slot40, align 8
  %v224 = load i64, ptr %slot40, align 8
  %v225 = load i64, ptr %slot5, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 %v224, ptr %p226, align 8, !alias.scope !3, !noalias !4
  br label %bb_i27
bb_i24:
  %v227 = load i64, ptr %slot4, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot41, align 8
  %v230 = load i64, ptr %slot41, align 8
  %v231 = load i64, ptr %slot5, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 %v230, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot5, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot42, align 8
  %v236 = load i64, ptr %slot1, align 8
  %v237 = load i64, ptr %slot42, align 8
  %call238 = call i64 @myl_f_fc199839b3a5f5add55a3730c3eeee033e1d3abb43b3de95aed4520fd6c1c4b5(i64 %v236, i64 %v237) nomerge, !dbg !124
  store i64 %call238, ptr %slot43, align 8
  %v239 = load i64, ptr %slot43, align 8
  %v240 = load i64, ptr %slot5, align 8
  %p241 = inttoptr i64 %v240 to ptr
  store i64 %v239, ptr %p241, align 8, !alias.scope !3, !noalias !4
  br label %bb_i27
bb_i27:
  %v242 = load i64, ptr %slot4, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %ld244 = load i64, ptr %p243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld244, ptr %slot44, align 8
  %v245 = load i64, ptr %slot44, align 8
  %v246 = load i64, ptr %slot5, align 8
  %p247 = inttoptr i64 %v246 to ptr
  store i64 %v245, ptr %p247, align 8, !alias.scope !3, !noalias !4
  %v248 = load i64, ptr %slot5, align 8
  %p249 = inttoptr i64 %v248 to ptr
  %ld250 = load i64, ptr %p249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld250, ptr %slot45, align 8
  %v251 = load i64, ptr %slot45, align 8
  %op252 = add i64 %v251, 369
  store i64 %op252, ptr %slot46, align 8
  %v253 = load i64, ptr %slot46, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i8, ptr %p254, align 1, !alias.scope !4, !noalias !3
  %ext256 = zext i8 %ld255 to i64
  store i64 %ext256, ptr %slot47, align 8
  %v257 = load i64, ptr %slot47, align 8
  %v258 = load i64, ptr %slot5, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i64 %v257, ptr %p259, align 8, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot5, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i64, ptr %p261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld262, ptr %slot48, align 8
  %v263 = load i64, ptr %slot48, align 8
  %cond264 = icmp ne i64 %v263, 0
  br i1 %cond264, label %bb_next115, label %bb_i33
bb_next115:
  %v265 = load i64, ptr %slot4, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot49, align 8
  %v268 = load i64, ptr %slot49, align 8
  %v269 = load i64, ptr %slot5, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot5, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot50, align 8
  %v274 = load i64, ptr %slot1, align 8
  %v275 = load i64, ptr %slot50, align 8
  %call276 = call i64 @myl_f_4cd9ec9315008608ffe5a942c027c2efba17014114f0143b68d460f91e4b16ba(i64 %v274, i64 %v275) nomerge, !dbg !126
  store i64 %call276, ptr %slot51, align 8
  %v277 = load i64, ptr %slot51, align 8
  %v278 = load i64, ptr %slot5, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 %v277, ptr %p279, align 8, !alias.scope !3, !noalias !4
  br label %bb_i33
bb_i33:
  %v280 = load i64, ptr %slot5, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i64 0, ptr %p281, align 8, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot5, align 8
  %p283 = inttoptr i64 %v282 to ptr
  %ld284 = load i64, ptr %p283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld284, ptr %slot52, align 8
  %v285 = load i64, ptr %slot52, align 8
  ret i64 %v285
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare i64 @myl_f_4cd9ec9315008608ffe5a942c027c2efba17014114f0143b68d460f91e4b16ba(i64, i64)
declare i64 @myl_f_5657e329775bff14911deaf3073b44d8b48138d6f620fddc6ba0d0819413d9d3(i64, i64)
declare i64 @myl_f_7c1fb5dcc68552dc32392842ae18d5d677bc992b80075f8837d7435ff1929d45(i64, i64)
declare i64 @myl_f_b3fd3485d6747595caec960614b08f0d599db97cbf857690262bcba2a980be0d(i64, i64, i64)
declare i64 @myl_f_d5b119a5754679ec7ac6b2bd0943fdb20ddd72671997692dd4bff9fbdca0372b(i64, i64)
declare i64 @myl_f_fc199839b3a5f5add55a3730c3eeee033e1d3abb43b3de95aed4520fd6c1c4b5(i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8", linkageName: "myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 18180545170402937431, i64 0, !"myl_f_96c57cf6efcfc9c746e7097964f9d22558393c8141344e4c2b653917e4a55ce8"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!116 = !DILocation(line: 11, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!118 = !DILocation(line: 14, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!120 = !DILocation(line: 19, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!122 = !DILocation(line: 22, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!124 = !DILocation(line: 26, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!126 = !DILocation(line: 32, column: 0, scope: !127)
