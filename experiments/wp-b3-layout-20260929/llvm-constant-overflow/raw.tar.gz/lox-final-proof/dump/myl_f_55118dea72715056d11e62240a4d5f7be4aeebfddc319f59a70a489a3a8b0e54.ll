target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %callresult205 = alloca [16 x i8], align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %callresult262 = alloca [16 x i8], align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %callresult319 = alloca [16 x i8], align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %callresult376 = alloca [16 x i8], align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %callresult433 = alloca [16 x i8], align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %callresult490 = alloca [16 x i8], align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %callresult547 = alloca [16 x i8], align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %callresult604 = alloca [16 x i8], align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %callresult661 = alloca [16 x i8], align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %callresult718 = alloca [16 x i8], align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i32, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v773 = load i64, ptr %slot1, align 8
  %op774 = add i64 %v773, 32
  store i64 %op774, ptr %slot4, align 8
  %mem775 = alloca i8, i64 24, align 8
  %ptr776 = ptrtoint ptr %mem775 to i64
  store i64 %ptr776, ptr %slot5, align 8
  %mem777 = alloca i8, i64 8, align 8
  %ptr778 = ptrtoint ptr %mem777 to i64
  store i64 %ptr778, ptr %slot6, align 8
  %mem779 = alloca i8, i64 8, align 8
  %ptr780 = ptrtoint ptr %mem779 to i64
  store i64 %ptr780, ptr %slot7, align 8
  %mem781 = alloca i8, i64 8, align 8
  %ptr782 = ptrtoint ptr %mem781 to i64
  store i64 %ptr782, ptr %slot8, align 8
  %mem783 = alloca i8, i64 8, align 8
  %ptr784 = ptrtoint ptr %mem783 to i64
  store i64 %ptr784, ptr %slot9, align 8
  %mem785 = alloca i8, i64 8, align 8
  %ptr786 = ptrtoint ptr %mem785 to i64
  store i64 %ptr786, ptr %slot10, align 8
  %mem787 = alloca i8, i64 8, align 8
  %ptr788 = ptrtoint ptr %mem787 to i64
  store i64 %ptr788, ptr %slot11, align 8
  %mem789 = alloca i8, i64 208, align 8
  %ptr790 = ptrtoint ptr %mem789 to i64
  store i64 %ptr790, ptr %slot12, align 8
  %mem791 = alloca i8, i64 16, align 8
  %ptr792 = ptrtoint ptr %mem791 to i64
  store i64 %ptr792, ptr %slot13, align 8
  %mem793 = alloca i8, i64 208, align 8
  %ptr794 = ptrtoint ptr %mem793 to i64
  store i64 %ptr794, ptr %slot14, align 8
  %mem795 = alloca i8, i64 8, align 8
  %ptr796 = ptrtoint ptr %mem795 to i64
  store i64 %ptr796, ptr %slot15, align 8
  %mem797 = alloca i8, i64 8, align 8
  %ptr798 = ptrtoint ptr %mem797 to i64
  store i64 %ptr798, ptr %slot16, align 8
  %mem799 = alloca i8, i64 8, align 8
  %ptr800 = ptrtoint ptr %mem799 to i64
  store i64 %ptr800, ptr %slot17, align 8
  %mem801 = alloca i8, i64 8, align 8
  %ptr802 = ptrtoint ptr %mem801 to i64
  store i64 %ptr802, ptr %slot18, align 8
  %mem803 = alloca i8, i64 24, align 8
  %ptr804 = ptrtoint ptr %mem803 to i64
  store i64 %ptr804, ptr %slot19, align 8
  %mem805 = alloca i8, i64 8, align 8
  %ptr806 = ptrtoint ptr %mem805 to i64
  store i64 %ptr806, ptr %slot20, align 8
  %mem807 = alloca i8, i64 8, align 8
  %ptr808 = ptrtoint ptr %mem807 to i64
  store i64 %ptr808, ptr %slot21, align 8
  %mem809 = alloca i8, i64 24, align 8
  %ptr810 = ptrtoint ptr %mem809 to i64
  store i64 %ptr810, ptr %slot22, align 8
  %mem811 = alloca i8, i64 24, align 8
  %ptr812 = ptrtoint ptr %mem811 to i64
  store i64 %ptr812, ptr %slot23, align 8
  %mem813 = alloca i8, i64 24, align 8
  %ptr814 = ptrtoint ptr %mem813 to i64
  store i64 %ptr814, ptr %slot24, align 8
  %mem815 = alloca i8, i64 24, align 8
  %ptr816 = ptrtoint ptr %mem815 to i64
  store i64 %ptr816, ptr %slot25, align 8
  %mem817 = alloca i8, i64 24, align 8
  %ptr818 = ptrtoint ptr %mem817 to i64
  store i64 %ptr818, ptr %slot26, align 8
  %mem819 = alloca i8, i64 24, align 8
  %ptr820 = ptrtoint ptr %mem819 to i64
  store i64 %ptr820, ptr %slot27, align 8
  %mem821 = alloca i8, i64 24, align 8
  %ptr822 = ptrtoint ptr %mem821 to i64
  store i64 %ptr822, ptr %slot28, align 8
  %mem823 = alloca i8, i64 24, align 8
  %ptr824 = ptrtoint ptr %mem823 to i64
  store i64 %ptr824, ptr %slot29, align 8
  %mem825 = alloca i8, i64 24, align 8
  %ptr826 = ptrtoint ptr %mem825 to i64
  store i64 %ptr826, ptr %slot30, align 8
  %mem827 = alloca i8, i64 24, align 8
  %ptr828 = ptrtoint ptr %mem827 to i64
  store i64 %ptr828, ptr %slot31, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem829 = alloca i8, i64 8, align 8
  %ptr830 = ptrtoint ptr %mem829 to i64
  store i64 %ptr830, ptr %slot32, align 8
  %v831 = load i64, ptr %slot1, align 8
  %op832 = add i64 %v831, 64
  store i64 %op832, ptr %slot33, align 8
  %v833 = load i64, ptr %slot33, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %ld835 = load i64, ptr %p834, align 8, !alias.scope !4, !noalias !3
  store i64 %ld835, ptr %slot34, align 8
  %stack836 = call ptr @llvm.stacksave()
  %stackaddr837 = ptrtoint ptr %stack836 to i64
  %v838 = load i64, ptr %slot34, align 8
  %cmp839 = icmp ult i64 %stackaddr837, %v838
  %cv840 = zext i1 %cmp839 to i64
  store i64 %cv840, ptr %slot35, align 8
  %v841 = load i64, ptr %slot35, align 8
  %cond842 = icmp ne i64 %v841, 0
  br i1 %cond842, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v843 = load i64, ptr %slot1, align 8
  %p844 = inttoptr i64 %v843 to ptr
  call void @myl_qbe_fail_frame(ptr %p844) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v845 = load i64, ptr %slot17, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i64 0, ptr %p846, align 8, !alias.scope !3, !noalias !4
  %v847 = load i64, ptr %slot2, align 8
  %v848 = load i64, ptr %slot15, align 8
  %p849 = inttoptr i64 %v848 to ptr
  store i64 %v847, ptr %p849, align 8, !alias.scope !3, !noalias !4
  %v850 = load i64, ptr %slot3, align 8
  %v851 = load i64, ptr %slot16, align 8
  %p852 = inttoptr i64 %v851 to ptr
  store i64 %v850, ptr %p852, align 8, !alias.scope !3, !noalias !4
  %v853 = load i64, ptr %slot1, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %call855 = call ptr @myl_qbe_heap(ptr %p854) nomerge, !dbg !112
  %calladdr856 = ptrtoint ptr %call855 to i64
  store i64 %calladdr856, ptr %slot36, align 8
  %v857 = load i64, ptr %slot1, align 8
  %p858 = inttoptr i64 %v857 to ptr
  %call859 = call i64 @myl_qbe_region_mark(ptr %p858) nomerge, !dbg !112
  store i64 %call859, ptr %slot37, align 8
  %v860 = load i64, ptr %slot6, align 8
  %p861 = inttoptr i64 %v860 to ptr
  store i32 0, ptr %p861, align 4, !alias.scope !3, !noalias !4
  %v862 = load i64, ptr %slot7, align 8
  %p863 = inttoptr i64 %v862 to ptr
  store i32 0, ptr %p863, align 4, !alias.scope !3, !noalias !4
  %v864 = load i64, ptr %slot8, align 8
  %p865 = inttoptr i64 %v864 to ptr
  store i32 0, ptr %p865, align 4, !alias.scope !3, !noalias !4
  %v866 = load i64, ptr %slot9, align 8
  %p867 = inttoptr i64 %v866 to ptr
  store i32 0, ptr %p867, align 4, !alias.scope !3, !noalias !4
  %v868 = load i64, ptr %slot10, align 8
  %p869 = inttoptr i64 %v868 to ptr
  store i32 0, ptr %p869, align 4, !alias.scope !3, !noalias !4
  %v870 = load i64, ptr %slot11, align 8
  %p871 = inttoptr i64 %v870 to ptr
  store i32 0, ptr %p871, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v872 = load i64, ptr %slot15, align 8
  %p873 = inttoptr i64 %v872 to ptr
  %ld874 = load i64, ptr %p873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld874, ptr %slot38, align 8
  %v875 = load i64, ptr %slot38, align 8
  %v876 = load i64, ptr %slot20, align 8
  %p877 = inttoptr i64 %v876 to ptr
  store i64 %v875, ptr %p877, align 8, !alias.scope !3, !noalias !4
  %v878 = load i64, ptr %slot20, align 8
  %p879 = inttoptr i64 %v878 to ptr
  %ld880 = load i64, ptr %p879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld880, ptr %slot39, align 8
  %v881 = load i64, ptr %slot39, align 8
  %op882 = add i64 %v881, 0
  store i64 %op882, ptr %slot40, align 8
  %v883 = load i64, ptr %slot40, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %ld885 = load i64, ptr %p884, align 8
  store i64 %ld885, ptr %slot41, align 8
  %v886 = load i64, ptr %slot41, align 8
  %v887 = load i64, ptr %slot20, align 8
  %p888 = inttoptr i64 %v887 to ptr
  store i64 %v886, ptr %p888, align 8, !alias.scope !3, !noalias !4
  %v889 = load i64, ptr %slot6, align 8
  %p890 = inttoptr i64 %v889 to ptr
  %ld891 = load i32, ptr %p890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld891, ptr %slot42, align 8
  %v892 = load i32, ptr %slot42, align 8
  %cv893 = zext i32 %v892 to i64
  %cond894 = icmp ne i64 %cv893, 0
  br i1 %cond894, label %bb_rcslotdrop16, label %bb_rcslotdone16
bb_rcslotdrop16:
  %v895 = load i64, ptr %slot6, align 8
  %p896 = inttoptr i64 %v895 to ptr
  store i32 0, ptr %p896, align 4, !alias.scope !3, !noalias !4
  %v897 = load i64, ptr %slot12, align 8
  store i64 %v897, ptr %slot43, align 8
  %v898 = load i64, ptr %slot7, align 8
  %p899 = inttoptr i64 %v898 to ptr
  %ld900 = load i32, ptr %p899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld900, ptr %slot44, align 8
  %v901 = load i32, ptr %slot44, align 8
  %op902 = and i32 %v901, 28
  store i32 %op902, ptr %slot45, align 8
  %v903 = load i32, ptr %slot45, align 8
  %cv904 = zext i32 %v903 to i64
  %cond905 = icmp ne i64 %cv904, 0
  br i1 %cond905, label %bb_rcslotrole16, label %bb_rcslotowner16
bb_rcslotrole16:
  %v906 = load i64, ptr %slot36, align 8
  store i64 %v906, ptr %slot46, align 8
  %v907 = load i64, ptr %slot46, align 8
  %v908 = load i64, ptr %slot43, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v907, i64 %v908) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotowner16:
  %v909 = load i64, ptr %slot36, align 8
  store i64 %v909, ptr %slot47, align 8
  %v910 = load i64, ptr %slot47, align 8
  %v911 = load i64, ptr %slot43, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v910, i64 %v911) nomerge, !dbg !114
  br label %bb_rcslotdone16
bb_rcslotdone16:
  %v912 = load i64, ptr %slot20, align 8
  %p913 = inttoptr i64 %v912 to ptr
  %ld914 = load i64, ptr %p913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld914, ptr %slot48, align 8
  %v915 = load i64, ptr %slot48, align 8
  %v916 = load i64, ptr %slot17, align 8
  %p917 = inttoptr i64 %v916 to ptr
  store i64 %v915, ptr %p917, align 8, !alias.scope !3, !noalias !4
  %v918 = load i64, ptr %slot16, align 8
  %p919 = inttoptr i64 %v918 to ptr
  %ld920 = load i64, ptr %p919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld920, ptr %slot49, align 8
  %v921 = load i64, ptr %slot49, align 8
  %v922 = load i64, ptr %slot20, align 8
  %p923 = inttoptr i64 %v922 to ptr
  store i64 %v921, ptr %p923, align 8, !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot20, align 8
  %p925 = inttoptr i64 %v924 to ptr
  %ld926 = load i64, ptr %p925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld926, ptr %slot50, align 8
  %v927 = load i64, ptr %slot50, align 8
  %v928 = load i64, ptr %slot18, align 8
  %p929 = inttoptr i64 %v928 to ptr
  store i64 %v927, ptr %p929, align 8, !alias.scope !3, !noalias !4
  %v930 = load i64, ptr %slot18, align 8
  %p931 = inttoptr i64 %v930 to ptr
  %ld932 = load i64, ptr %p931, align 8, !alias.scope !3, !noalias !4
  store i64 %ld932, ptr %slot51, align 8
  %v933 = load i64, ptr %slot51, align 8
  %v934 = load i64, ptr %slot20, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i64 %v933, ptr %p935, align 8, !alias.scope !3, !noalias !4
  %v936 = load i64, ptr %slot21, align 8
  %p937 = inttoptr i64 %v936 to ptr
  store i64 0, ptr %p937, align 8, !alias.scope !3, !noalias !4
  %v938 = load i64, ptr %slot21, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %ld940 = load i64, ptr %p939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld940, ptr %slot52, align 8
  %v941 = load i64, ptr %slot20, align 8
  %p942 = inttoptr i64 %v941 to ptr
  %ld943 = load i64, ptr %p942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld943, ptr %slot53, align 8
  %v944 = load i64, ptr %slot53, align 8
  %v945 = load i64, ptr %slot52, align 8
  %cmp946 = icmp slt i64 %v944, %v945
  %cv947 = zext i1 %cmp946 to i64
  store i64 %cv947, ptr %slot54, align 8
  %v948 = load i64, ptr %slot54, align 8
  %v949 = load i64, ptr %slot20, align 8
  %p950 = inttoptr i64 %v949 to ptr
  store i64 %v948, ptr %p950, align 8, !alias.scope !3, !noalias !4
  %v951 = load i64, ptr %slot20, align 8
  %p952 = inttoptr i64 %v951 to ptr
  %ld953 = load i64, ptr %p952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld953, ptr %slot55, align 8
  %v954 = load i64, ptr %slot55, align 8
  %cond955 = icmp ne i64 %v954, 0
  br i1 %cond955, label %bb_next31, label %bb_i14
bb_next31:
  %v956 = load i64, ptr %slot17, align 8
  %p957 = inttoptr i64 %v956 to ptr
  %ld958 = load i64, ptr %p957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld958, ptr %slot56, align 8
  %v959 = load i64, ptr %slot56, align 8
  %op960 = add i64 %v959, 0
  store i64 %op960, ptr %slot57, align 8
  %v961 = load i64, ptr %slot57, align 8
  %p962 = inttoptr i64 %v961 to ptr
  %ld963 = load i64, ptr %p962, align 8, !alias.scope !6, !noalias !7
  store i64 %ld963, ptr %slot58, align 8
  %v964 = load i64, ptr %slot58, align 8
  %v965 = load i64, ptr %slot20, align 8
  %p966 = inttoptr i64 %v965 to ptr
  store i64 %v964, ptr %p966, align 8, !alias.scope !3, !noalias !4
  %v967 = load i64, ptr %slot20, align 8
  %p968 = inttoptr i64 %v967 to ptr
  %ld969 = load i64, ptr %p968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld969, ptr %slot59, align 8
  %v970 = load i64, ptr %slot59, align 8
  %cmp971 = icmp ugt i64 %v970, 9223372036854775807
  %cv972 = zext i1 %cmp971 to i64
  store i64 %cv972, ptr %slot60, align 8
  %v973 = load i64, ptr %slot60, align 8
  %cond974 = icmp ne i64 %v973, 0
  br i1 %cond974, label %bb_cast_overflow36, label %bb_cast_ok36
bb_cast_overflow36:
  %v975 = load i64, ptr %slot1, align 8
  %p976 = inttoptr i64 %v975 to ptr
  %v977 = load i64, ptr %slot59, align 8
  call void @myl_qbe_fail_cast(ptr %p976, i64 %v977, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok36:
  %v978 = load i64, ptr %slot59, align 8
  %v979 = load i64, ptr %slot20, align 8
  %p980 = inttoptr i64 %v979 to ptr
  store i64 %v978, ptr %p980, align 8, !alias.scope !3, !noalias !4
  %v981 = load i64, ptr %slot18, align 8
  %p982 = inttoptr i64 %v981 to ptr
  %ld983 = load i64, ptr %p982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld983, ptr %slot61, align 8
  %v984 = load i64, ptr %slot61, align 8
  %v985 = load i64, ptr %slot21, align 8
  %p986 = inttoptr i64 %v985 to ptr
  store i64 %v984, ptr %p986, align 8, !alias.scope !3, !noalias !4
  %v987 = load i64, ptr %slot21, align 8
  %p988 = inttoptr i64 %v987 to ptr
  %ld989 = load i64, ptr %p988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld989, ptr %slot62, align 8
  %v990 = load i64, ptr %slot20, align 8
  %p991 = inttoptr i64 %v990 to ptr
  %ld992 = load i64, ptr %p991, align 8, !alias.scope !3, !noalias !4
  store i64 %ld992, ptr %slot63, align 8
  %v993 = load i64, ptr %slot63, align 8
  %v994 = load i64, ptr %slot62, align 8
  %ovpair996 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v993, i64 %v994)
  %op995 = extractvalue { i64, i1 } %ovpair996, 0
  %ov997 = extractvalue { i64, i1 } %ovpair996, 1
  store i64 %op995, ptr %slot64, align 8
  %v998 = load i64, ptr %slot63, align 8
  %v999 = load i64, ptr %slot64, align 8
  %op1000 = xor i64 %v998, %v999
  store i64 %op1000, ptr %slot65, align 8
  %v1001 = load i64, ptr %slot62, align 8
  %v1002 = load i64, ptr %slot64, align 8
  %op1003 = xor i64 %v1001, %v1002
  store i64 %op1003, ptr %slot66, align 8
  %v1004 = load i64, ptr %slot65, align 8
  %v1005 = load i64, ptr %slot66, align 8
  %op1006 = and i64 %v1004, %v1005
  store i64 %op1006, ptr %slot67, align 8
  %cv1007 = zext i1 %ov997 to i64
  store i64 %cv1007, ptr %slot68, align 8
  %v1008 = load i64, ptr %slot68, align 8
  %cond1009 = icmp ne i64 %v1008, 0
  br i1 %cond1009, label %bb_overflow40, label %bb_checked40
bb_overflow40:
  %v1010 = load i64, ptr %slot1, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  %v1012 = load i64, ptr %slot63, align 8
  %v1013 = load i64, ptr %slot62, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1011, i64 0, i64 %v1012, i64 %v1013, i64 64) nomerge, !dbg !118
  unreachable
bb_checked40:
  %v1014 = load i64, ptr %slot64, align 8
  %v1015 = load i64, ptr %slot20, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  store i64 %v1014, ptr %p1016, align 8, !alias.scope !3, !noalias !4
  %v1017 = load i64, ptr %slot20, align 8
  %p1018 = inttoptr i64 %v1017 to ptr
  %ld1019 = load i64, ptr %p1018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1019, ptr %slot69, align 8
  %v1020 = load i64, ptr %slot69, align 8
  %v1021 = load i64, ptr %slot18, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  store i64 %v1020, ptr %p1022, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v1023 = load i64, ptr %slot18, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  %ld1025 = load i64, ptr %p1024, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1025, ptr %slot70, align 8
  %v1026 = load i64, ptr %slot70, align 8
  %v1027 = load i64, ptr %slot20, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  store i64 %v1026, ptr %p1028, align 8, !alias.scope !3, !noalias !4
  %v1029 = load i64, ptr %slot17, align 8
  %p1030 = inttoptr i64 %v1029 to ptr
  %ld1031 = load i64, ptr %p1030, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1031, ptr %slot71, align 8
  %v1032 = load i64, ptr %slot20, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  %ld1034 = load i64, ptr %p1033, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1034, ptr %slot72, align 8
  %v1035 = load i64, ptr %slot71, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  %ld1037 = load i64, ptr %p1036, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1037, ptr %slot73, align 8
  %v1038 = load i64, ptr %slot72, align 8
  %v1039 = load i64, ptr %slot73, align 8
  %cmp1040 = icmp ult i64 %v1038, %v1039
  %cv1041 = zext i1 %cmp1040 to i64
  store i64 %cv1041, ptr %slot74, align 8
  %v1042 = load i64, ptr %slot74, align 8
  %cond1043 = icmp ne i64 %v1042, 0
  br i1 %cond1043, label %bb_success52, label %bb_failed52
bb_failed52:
  %v1044 = load i64, ptr %slot1, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  %v1046 = load i64, ptr %slot72, align 8
  %v1047 = load i64, ptr %slot73, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p1045, i64 %v1046, i64 %v1047) nomerge, !dbg !120
  unreachable
bb_success52:
  %v1048 = load i64, ptr %slot71, align 8
  %op1049 = add i64 %v1048, 32
  store i64 %op1049, ptr %slot75, align 8
  %v1050 = load i64, ptr %slot75, align 8
  %p1051 = inttoptr i64 %v1050 to ptr
  %ld1052 = load i64, ptr %p1051, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1052, ptr %slot76, align 8
  %v1053 = load i64, ptr %slot72, align 8
  %op1054 = mul i64 %v1053, 56
  store i64 %op1054, ptr %slot77, align 8
  %v1055 = load i64, ptr %slot76, align 8
  %v1056 = load i64, ptr %slot77, align 8
  %op1057 = add i64 %v1055, %v1056
  store i64 %op1057, ptr %slot78, align 8
  %v1058 = load i64, ptr %slot78, align 8
  %v1059 = load i64, ptr %slot20, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  store i64 %v1058, ptr %p1060, align 8, !alias.scope !3, !noalias !4
  %v1061 = load i64, ptr %slot20, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  %ld1063 = load i64, ptr %p1062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1063, ptr %slot79, align 8
  %v1064 = load i64, ptr %slot79, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %ld1066 = load i32, ptr %p1065, align 4
  %ext1067 = zext i32 %ld1066 to i64
  store i64 %ext1067, ptr %slot80, align 8
  %v1068 = load i64, ptr %slot80, align 8
  %cmp1069 = icmp eq i64 %v1068, 0
  %cv1070 = zext i1 %cmp1069 to i64
  store i64 %cv1070, ptr %slot81, align 8
  %v1071 = load i64, ptr %slot81, align 8
  %cond1072 = icmp ne i64 %v1071, 0
  br i1 %cond1072, label %bb_rcarm59, label %bb_rcarmnext59
bb_rcarm59:
  %v1073 = load i64, ptr %slot6, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  %ld1075 = load i32, ptr %p1074, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1075, ptr %slot82, align 8
  %v1076 = load i32, ptr %slot82, align 8
  %cv1077 = zext i32 %v1076 to i64
  %cond1078 = icmp ne i64 %cv1077, 0
  br i1 %cond1078, label %bb_rcslotdrop62, label %bb_rcslotdone62
bb_rcslotdrop62:
  %v1079 = load i64, ptr %slot6, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  store i32 0, ptr %p1080, align 4, !alias.scope !3, !noalias !4
  %v1081 = load i64, ptr %slot12, align 8
  store i64 %v1081, ptr %slot83, align 8
  %v1082 = load i64, ptr %slot7, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  %ld1084 = load i32, ptr %p1083, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1084, ptr %slot84, align 8
  %v1085 = load i32, ptr %slot84, align 8
  %op1086 = and i32 %v1085, 28
  store i32 %op1086, ptr %slot85, align 8
  %v1087 = load i32, ptr %slot85, align 8
  %cv1088 = zext i32 %v1087 to i64
  %cond1089 = icmp ne i64 %cv1088, 0
  br i1 %cond1089, label %bb_rcslotrole62, label %bb_rcslotowner62
bb_rcslotrole62:
  %v1090 = load i64, ptr %slot36, align 8
  store i64 %v1090, ptr %slot86, align 8
  %v1091 = load i64, ptr %slot86, align 8
  %v1092 = load i64, ptr %slot83, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1091, i64 %v1092) nomerge, !dbg !122
  br label %bb_rcslotdone62
bb_rcslotowner62:
  %v1093 = load i64, ptr %slot36, align 8
  store i64 %v1093, ptr %slot87, align 8
  %v1094 = load i64, ptr %slot87, align 8
  %v1095 = load i64, ptr %slot83, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1094, i64 %v1095) nomerge, !dbg !122
  br label %bb_rcslotdone62
bb_rcslotdone62:
  br label %bb_i23
bb_rcarmnext59:
  %v1096 = load i64, ptr %slot80, align 8
  %cmp1097 = icmp eq i64 %v1096, 1
  %cv1098 = zext i1 %cmp1097 to i64
  store i64 %cv1098, ptr %slot88, align 8
  %v1099 = load i64, ptr %slot88, align 8
  %cond1100 = icmp ne i64 %v1099, 0
  br i1 %cond1100, label %bb_rcarm69, label %bb_rcarmnext69
bb_rcarm69:
  %v1101 = load i64, ptr %slot6, align 8
  %p1102 = inttoptr i64 %v1101 to ptr
  %ld1103 = load i32, ptr %p1102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1103, ptr %slot89, align 8
  %v1104 = load i32, ptr %slot89, align 8
  %cv1105 = zext i32 %v1104 to i64
  %cond1106 = icmp ne i64 %cv1105, 0
  br i1 %cond1106, label %bb_rcslotdrop72, label %bb_rcslotdone72
bb_rcslotdrop72:
  %v1107 = load i64, ptr %slot6, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  store i32 0, ptr %p1108, align 4, !alias.scope !3, !noalias !4
  %v1109 = load i64, ptr %slot12, align 8
  store i64 %v1109, ptr %slot90, align 8
  %v1110 = load i64, ptr %slot7, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  %ld1112 = load i32, ptr %p1111, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1112, ptr %slot91, align 8
  %v1113 = load i32, ptr %slot91, align 8
  %op1114 = and i32 %v1113, 28
  store i32 %op1114, ptr %slot92, align 8
  %v1115 = load i32, ptr %slot92, align 8
  %cv1116 = zext i32 %v1115 to i64
  %cond1117 = icmp ne i64 %cv1116, 0
  br i1 %cond1117, label %bb_rcslotrole72, label %bb_rcslotowner72
bb_rcslotrole72:
  %v1118 = load i64, ptr %slot36, align 8
  store i64 %v1118, ptr %slot93, align 8
  %v1119 = load i64, ptr %slot93, align 8
  %v1120 = load i64, ptr %slot90, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1119, i64 %v1120) nomerge, !dbg !122
  br label %bb_rcslotdone72
bb_rcslotowner72:
  %v1121 = load i64, ptr %slot36, align 8
  store i64 %v1121, ptr %slot94, align 8
  %v1122 = load i64, ptr %slot94, align 8
  %v1123 = load i64, ptr %slot90, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1122, i64 %v1123) nomerge, !dbg !122
  br label %bb_rcslotdone72
bb_rcslotdone72:
  br label %bb_i29
bb_rcarmnext69:
  %v1124 = load i64, ptr %slot80, align 8
  %cmp1125 = icmp eq i64 %v1124, 2
  %cv1126 = zext i1 %cmp1125 to i64
  store i64 %cv1126, ptr %slot95, align 8
  %v1127 = load i64, ptr %slot95, align 8
  %cond1128 = icmp ne i64 %v1127, 0
  br i1 %cond1128, label %bb_rcarm79, label %bb_rcarmnext79
bb_rcarm79:
  %v1129 = load i64, ptr %slot6, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  %ld1131 = load i32, ptr %p1130, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1131, ptr %slot96, align 8
  %v1132 = load i32, ptr %slot96, align 8
  %cv1133 = zext i32 %v1132 to i64
  %cond1134 = icmp ne i64 %cv1133, 0
  br i1 %cond1134, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v1135 = load i64, ptr %slot6, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  store i32 0, ptr %p1136, align 4, !alias.scope !3, !noalias !4
  %v1137 = load i64, ptr %slot12, align 8
  store i64 %v1137, ptr %slot97, align 8
  %v1138 = load i64, ptr %slot7, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  %ld1140 = load i32, ptr %p1139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1140, ptr %slot98, align 8
  %v1141 = load i32, ptr %slot98, align 8
  %op1142 = and i32 %v1141, 28
  store i32 %op1142, ptr %slot99, align 8
  %v1143 = load i32, ptr %slot99, align 8
  %cv1144 = zext i32 %v1143 to i64
  %cond1145 = icmp ne i64 %cv1144, 0
  br i1 %cond1145, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v1146 = load i64, ptr %slot36, align 8
  store i64 %v1146, ptr %slot100, align 8
  %v1147 = load i64, ptr %slot100, align 8
  %v1148 = load i64, ptr %slot97, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1147, i64 %v1148) nomerge, !dbg !122
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v1149 = load i64, ptr %slot36, align 8
  store i64 %v1149, ptr %slot101, align 8
  %v1150 = load i64, ptr %slot101, align 8
  %v1151 = load i64, ptr %slot97, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1150, i64 %v1151) nomerge, !dbg !122
  br label %bb_rcslotdone82
bb_rcslotdone82:
  br label %bb_i35
bb_rcarmnext79:
  %v1152 = load i64, ptr %slot80, align 8
  %cmp1153 = icmp eq i64 %v1152, 3
  %cv1154 = zext i1 %cmp1153 to i64
  store i64 %cv1154, ptr %slot102, align 8
  %v1155 = load i64, ptr %slot102, align 8
  %cond1156 = icmp ne i64 %v1155, 0
  br i1 %cond1156, label %bb_rcarm89, label %bb_rcarmnext89
bb_rcarm89:
  %v1157 = load i64, ptr %slot6, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  %ld1159 = load i32, ptr %p1158, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1159, ptr %slot103, align 8
  %v1160 = load i32, ptr %slot103, align 8
  %cv1161 = zext i32 %v1160 to i64
  %cond1162 = icmp ne i64 %cv1161, 0
  br i1 %cond1162, label %bb_rcslotdrop92, label %bb_rcslotdone92
bb_rcslotdrop92:
  %v1163 = load i64, ptr %slot6, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  store i32 0, ptr %p1164, align 4, !alias.scope !3, !noalias !4
  %v1165 = load i64, ptr %slot12, align 8
  store i64 %v1165, ptr %slot104, align 8
  %v1166 = load i64, ptr %slot7, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  %ld1168 = load i32, ptr %p1167, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1168, ptr %slot105, align 8
  %v1169 = load i32, ptr %slot105, align 8
  %op1170 = and i32 %v1169, 28
  store i32 %op1170, ptr %slot106, align 8
  %v1171 = load i32, ptr %slot106, align 8
  %cv1172 = zext i32 %v1171 to i64
  %cond1173 = icmp ne i64 %cv1172, 0
  br i1 %cond1173, label %bb_rcslotrole92, label %bb_rcslotowner92
bb_rcslotrole92:
  %v1174 = load i64, ptr %slot36, align 8
  store i64 %v1174, ptr %slot107, align 8
  %v1175 = load i64, ptr %slot107, align 8
  %v1176 = load i64, ptr %slot104, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1175, i64 %v1176) nomerge, !dbg !122
  br label %bb_rcslotdone92
bb_rcslotowner92:
  %v1177 = load i64, ptr %slot36, align 8
  store i64 %v1177, ptr %slot108, align 8
  %v1178 = load i64, ptr %slot108, align 8
  %v1179 = load i64, ptr %slot104, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1178, i64 %v1179) nomerge, !dbg !122
  br label %bb_rcslotdone92
bb_rcslotdone92:
  br label %bb_i41
bb_rcarmnext89:
  %v1180 = load i64, ptr %slot80, align 8
  %cmp1181 = icmp eq i64 %v1180, 4
  %cv1182 = zext i1 %cmp1181 to i64
  store i64 %cv1182, ptr %slot109, align 8
  %v1183 = load i64, ptr %slot109, align 8
  %cond1184 = icmp ne i64 %v1183, 0
  br i1 %cond1184, label %bb_rcarm99, label %bb_rcarmnext99
bb_rcarm99:
  %v1185 = load i64, ptr %slot6, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  %ld1187 = load i32, ptr %p1186, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1187, ptr %slot110, align 8
  %v1188 = load i32, ptr %slot110, align 8
  %cv1189 = zext i32 %v1188 to i64
  %cond1190 = icmp ne i64 %cv1189, 0
  br i1 %cond1190, label %bb_rcslotdrop102, label %bb_rcslotdone102
bb_rcslotdrop102:
  %v1191 = load i64, ptr %slot6, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  store i32 0, ptr %p1192, align 4, !alias.scope !3, !noalias !4
  %v1193 = load i64, ptr %slot12, align 8
  store i64 %v1193, ptr %slot111, align 8
  %v1194 = load i64, ptr %slot7, align 8
  %p1195 = inttoptr i64 %v1194 to ptr
  %ld1196 = load i32, ptr %p1195, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1196, ptr %slot112, align 8
  %v1197 = load i32, ptr %slot112, align 8
  %op1198 = and i32 %v1197, 28
  store i32 %op1198, ptr %slot113, align 8
  %v1199 = load i32, ptr %slot113, align 8
  %cv1200 = zext i32 %v1199 to i64
  %cond1201 = icmp ne i64 %cv1200, 0
  br i1 %cond1201, label %bb_rcslotrole102, label %bb_rcslotowner102
bb_rcslotrole102:
  %v1202 = load i64, ptr %slot36, align 8
  store i64 %v1202, ptr %slot114, align 8
  %v1203 = load i64, ptr %slot114, align 8
  %v1204 = load i64, ptr %slot111, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1203, i64 %v1204) nomerge, !dbg !122
  br label %bb_rcslotdone102
bb_rcslotowner102:
  %v1205 = load i64, ptr %slot36, align 8
  store i64 %v1205, ptr %slot115, align 8
  %v1206 = load i64, ptr %slot115, align 8
  %v1207 = load i64, ptr %slot111, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1206, i64 %v1207) nomerge, !dbg !122
  br label %bb_rcslotdone102
bb_rcslotdone102:
  br label %bb_i47
bb_rcarmnext99:
  %v1208 = load i64, ptr %slot80, align 8
  %cmp1209 = icmp eq i64 %v1208, 5
  %cv1210 = zext i1 %cmp1209 to i64
  store i64 %cv1210, ptr %slot116, align 8
  %v1211 = load i64, ptr %slot116, align 8
  %cond1212 = icmp ne i64 %v1211, 0
  br i1 %cond1212, label %bb_rcarm109, label %bb_rcarmnext109
bb_rcarm109:
  %v1213 = load i64, ptr %slot6, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i32, ptr %p1214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1215, ptr %slot117, align 8
  %v1216 = load i32, ptr %slot117, align 8
  %cv1217 = zext i32 %v1216 to i64
  %cond1218 = icmp ne i64 %cv1217, 0
  br i1 %cond1218, label %bb_rcslotdrop112, label %bb_rcslotdone112
bb_rcslotdrop112:
  %v1219 = load i64, ptr %slot6, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  store i32 0, ptr %p1220, align 4, !alias.scope !3, !noalias !4
  %v1221 = load i64, ptr %slot12, align 8
  store i64 %v1221, ptr %slot118, align 8
  %v1222 = load i64, ptr %slot7, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  %ld1224 = load i32, ptr %p1223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1224, ptr %slot119, align 8
  %v1225 = load i32, ptr %slot119, align 8
  %op1226 = and i32 %v1225, 28
  store i32 %op1226, ptr %slot120, align 8
  %v1227 = load i32, ptr %slot120, align 8
  %cv1228 = zext i32 %v1227 to i64
  %cond1229 = icmp ne i64 %cv1228, 0
  br i1 %cond1229, label %bb_rcslotrole112, label %bb_rcslotowner112
bb_rcslotrole112:
  %v1230 = load i64, ptr %slot36, align 8
  store i64 %v1230, ptr %slot121, align 8
  %v1231 = load i64, ptr %slot121, align 8
  %v1232 = load i64, ptr %slot118, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1231, i64 %v1232) nomerge, !dbg !122
  br label %bb_rcslotdone112
bb_rcslotowner112:
  %v1233 = load i64, ptr %slot36, align 8
  store i64 %v1233, ptr %slot122, align 8
  %v1234 = load i64, ptr %slot122, align 8
  %v1235 = load i64, ptr %slot118, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1234, i64 %v1235) nomerge, !dbg !122
  br label %bb_rcslotdone112
bb_rcslotdone112:
  br label %bb_i53
bb_rcarmnext109:
  %v1236 = load i64, ptr %slot80, align 8
  %cmp1237 = icmp eq i64 %v1236, 6
  %cv1238 = zext i1 %cmp1237 to i64
  store i64 %cv1238, ptr %slot123, align 8
  %v1239 = load i64, ptr %slot123, align 8
  %cond1240 = icmp ne i64 %v1239, 0
  br i1 %cond1240, label %bb_rcarm119, label %bb_rcarmnext119
bb_rcarm119:
  %v1241 = load i64, ptr %slot79, align 8
  %op1242 = add i64 %v1241, 8
  store i64 %op1242, ptr %slot124, align 8
  %v1243 = load i64, ptr %slot124, align 8
  %v1244 = load i64, ptr %slot19, align 8
  %p1245 = inttoptr i64 %v1243 to ptr
  %p1246 = inttoptr i64 %v1244 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1246, ptr %p1245, i64 24, i1 false)
  %v1247 = load i64, ptr %slot6, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  %ld1249 = load i32, ptr %p1248, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1249, ptr %slot125, align 8
  %v1250 = load i32, ptr %slot125, align 8
  %cv1251 = zext i32 %v1250 to i64
  %cond1252 = icmp ne i64 %cv1251, 0
  br i1 %cond1252, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v1253 = load i64, ptr %slot6, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  store i32 0, ptr %p1254, align 4, !alias.scope !3, !noalias !4
  %v1255 = load i64, ptr %slot12, align 8
  store i64 %v1255, ptr %slot126, align 8
  %v1256 = load i64, ptr %slot7, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  %ld1258 = load i32, ptr %p1257, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1258, ptr %slot127, align 8
  %v1259 = load i32, ptr %slot127, align 8
  %op1260 = and i32 %v1259, 28
  store i32 %op1260, ptr %slot128, align 8
  %v1261 = load i32, ptr %slot128, align 8
  %cv1262 = zext i32 %v1261 to i64
  %cond1263 = icmp ne i64 %cv1262, 0
  br i1 %cond1263, label %bb_rcslotrole133, label %bb_rcslotowner133
bb_rcslotrole133:
  %v1264 = load i64, ptr %slot36, align 8
  store i64 %v1264, ptr %slot129, align 8
  %v1265 = load i64, ptr %slot129, align 8
  %v1266 = load i64, ptr %slot126, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1265, i64 %v1266) nomerge, !dbg !122
  br label %bb_rcslotdone133
bb_rcslotowner133:
  %v1267 = load i64, ptr %slot36, align 8
  store i64 %v1267, ptr %slot130, align 8
  %v1268 = load i64, ptr %slot130, align 8
  %v1269 = load i64, ptr %slot126, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1268, i64 %v1269) nomerge, !dbg !122
  br label %bb_rcslotdone133
bb_rcslotdone133:
  br label %bb_i17
bb_rcarmnext119:
  %v1270 = load i64, ptr %slot80, align 8
  %cmp1271 = icmp eq i64 %v1270, 7
  %cv1272 = zext i1 %cmp1271 to i64
  store i64 %cv1272, ptr %slot131, align 8
  %v1273 = load i64, ptr %slot131, align 8
  %cond1274 = icmp ne i64 %v1273, 0
  br i1 %cond1274, label %bb_rcarm140, label %bb_rcarmnext140
bb_rcarm140:
  %v1275 = load i64, ptr %slot6, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  %ld1277 = load i32, ptr %p1276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1277, ptr %slot132, align 8
  %v1278 = load i32, ptr %slot132, align 8
  %cv1279 = zext i32 %v1278 to i64
  %cond1280 = icmp ne i64 %cv1279, 0
  br i1 %cond1280, label %bb_rcslotdrop143, label %bb_rcslotdone143
bb_rcslotdrop143:
  %v1281 = load i64, ptr %slot6, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i32 0, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot12, align 8
  store i64 %v1283, ptr %slot133, align 8
  %v1284 = load i64, ptr %slot7, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %ld1286 = load i32, ptr %p1285, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1286, ptr %slot134, align 8
  %v1287 = load i32, ptr %slot134, align 8
  %op1288 = and i32 %v1287, 28
  store i32 %op1288, ptr %slot135, align 8
  %v1289 = load i32, ptr %slot135, align 8
  %cv1290 = zext i32 %v1289 to i64
  %cond1291 = icmp ne i64 %cv1290, 0
  br i1 %cond1291, label %bb_rcslotrole143, label %bb_rcslotowner143
bb_rcslotrole143:
  %v1292 = load i64, ptr %slot36, align 8
  store i64 %v1292, ptr %slot136, align 8
  %v1293 = load i64, ptr %slot136, align 8
  %v1294 = load i64, ptr %slot133, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1293, i64 %v1294) nomerge, !dbg !122
  br label %bb_rcslotdone143
bb_rcslotowner143:
  %v1295 = load i64, ptr %slot36, align 8
  store i64 %v1295, ptr %slot137, align 8
  %v1296 = load i64, ptr %slot137, align 8
  %v1297 = load i64, ptr %slot133, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1296, i64 %v1297) nomerge, !dbg !122
  br label %bb_rcslotdone143
bb_rcslotdone143:
  br label %bb_i59
bb_rcarmnext140:
  %v1298 = load i64, ptr %slot80, align 8
  %cmp1299 = icmp eq i64 %v1298, 8
  %cv1300 = zext i1 %cmp1299 to i64
  store i64 %cv1300, ptr %slot138, align 8
  %v1301 = load i64, ptr %slot138, align 8
  %cond1302 = icmp ne i64 %v1301, 0
  br i1 %cond1302, label %bb_rcarm150, label %bb_rcarmnext150
bb_rcarm150:
  %v1303 = load i64, ptr %slot6, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  %ld1305 = load i32, ptr %p1304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1305, ptr %slot139, align 8
  %v1306 = load i32, ptr %slot139, align 8
  %cv1307 = zext i32 %v1306 to i64
  %cond1308 = icmp ne i64 %cv1307, 0
  br i1 %cond1308, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v1309 = load i64, ptr %slot6, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  store i32 0, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  %v1311 = load i64, ptr %slot12, align 8
  store i64 %v1311, ptr %slot140, align 8
  %v1312 = load i64, ptr %slot7, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  %ld1314 = load i32, ptr %p1313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1314, ptr %slot141, align 8
  %v1315 = load i32, ptr %slot141, align 8
  %op1316 = and i32 %v1315, 28
  store i32 %op1316, ptr %slot142, align 8
  %v1317 = load i32, ptr %slot142, align 8
  %cv1318 = zext i32 %v1317 to i64
  %cond1319 = icmp ne i64 %cv1318, 0
  br i1 %cond1319, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v1320 = load i64, ptr %slot36, align 8
  store i64 %v1320, ptr %slot143, align 8
  %v1321 = load i64, ptr %slot143, align 8
  %v1322 = load i64, ptr %slot140, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1321, i64 %v1322) nomerge, !dbg !122
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v1323 = load i64, ptr %slot36, align 8
  store i64 %v1323, ptr %slot144, align 8
  %v1324 = load i64, ptr %slot144, align 8
  %v1325 = load i64, ptr %slot140, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1324, i64 %v1325) nomerge, !dbg !122
  br label %bb_rcslotdone153
bb_rcslotdone153:
  br label %bb_i65
bb_rcarmnext150:
  %v1326 = load i64, ptr %slot80, align 8
  %cmp1327 = icmp eq i64 %v1326, 9
  %cv1328 = zext i1 %cmp1327 to i64
  store i64 %cv1328, ptr %slot145, align 8
  %v1329 = load i64, ptr %slot145, align 8
  %cond1330 = icmp ne i64 %v1329, 0
  br i1 %cond1330, label %bb_rcarm160, label %bb_rcarmnext160
bb_rcarm160:
  %v1331 = load i64, ptr %slot6, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  %ld1333 = load i32, ptr %p1332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1333, ptr %slot146, align 8
  %v1334 = load i32, ptr %slot146, align 8
  %cv1335 = zext i32 %v1334 to i64
  %cond1336 = icmp ne i64 %cv1335, 0
  br i1 %cond1336, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v1337 = load i64, ptr %slot6, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  store i32 0, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  %v1339 = load i64, ptr %slot12, align 8
  store i64 %v1339, ptr %slot147, align 8
  %v1340 = load i64, ptr %slot7, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  %ld1342 = load i32, ptr %p1341, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1342, ptr %slot148, align 8
  %v1343 = load i32, ptr %slot148, align 8
  %op1344 = and i32 %v1343, 28
  store i32 %op1344, ptr %slot149, align 8
  %v1345 = load i32, ptr %slot149, align 8
  %cv1346 = zext i32 %v1345 to i64
  %cond1347 = icmp ne i64 %cv1346, 0
  br i1 %cond1347, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v1348 = load i64, ptr %slot36, align 8
  store i64 %v1348, ptr %slot150, align 8
  %v1349 = load i64, ptr %slot150, align 8
  %v1350 = load i64, ptr %slot147, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1349, i64 %v1350) nomerge, !dbg !122
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v1351 = load i64, ptr %slot36, align 8
  store i64 %v1351, ptr %slot151, align 8
  %v1352 = load i64, ptr %slot151, align 8
  %v1353 = load i64, ptr %slot147, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1352, i64 %v1353) nomerge, !dbg !122
  br label %bb_rcslotdone163
bb_rcslotdone163:
  br label %bb_i71
bb_rcarmnext160:
  %v1354 = load i64, ptr %slot80, align 8
  %cmp1355 = icmp eq i64 %v1354, 10
  %cv1356 = zext i1 %cmp1355 to i64
  store i64 %cv1356, ptr %slot152, align 8
  %v1357 = load i64, ptr %slot152, align 8
  %cond1358 = icmp ne i64 %v1357, 0
  br i1 %cond1358, label %bb_rcarm170, label %bb_rcarmnext170
bb_rcarm170:
  %v1359 = load i64, ptr %slot6, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  %ld1361 = load i32, ptr %p1360, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1361, ptr %slot153, align 8
  %v1362 = load i32, ptr %slot153, align 8
  %cv1363 = zext i32 %v1362 to i64
  %cond1364 = icmp ne i64 %cv1363, 0
  br i1 %cond1364, label %bb_rcslotdrop173, label %bb_rcslotdone173
bb_rcslotdrop173:
  %v1365 = load i64, ptr %slot6, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  store i32 0, ptr %p1366, align 4, !alias.scope !3, !noalias !4
  %v1367 = load i64, ptr %slot12, align 8
  store i64 %v1367, ptr %slot154, align 8
  %v1368 = load i64, ptr %slot7, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  %ld1370 = load i32, ptr %p1369, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1370, ptr %slot155, align 8
  %v1371 = load i32, ptr %slot155, align 8
  %op1372 = and i32 %v1371, 28
  store i32 %op1372, ptr %slot156, align 8
  %v1373 = load i32, ptr %slot156, align 8
  %cv1374 = zext i32 %v1373 to i64
  %cond1375 = icmp ne i64 %cv1374, 0
  br i1 %cond1375, label %bb_rcslotrole173, label %bb_rcslotowner173
bb_rcslotrole173:
  %v1376 = load i64, ptr %slot36, align 8
  store i64 %v1376, ptr %slot157, align 8
  %v1377 = load i64, ptr %slot157, align 8
  %v1378 = load i64, ptr %slot154, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1377, i64 %v1378) nomerge, !dbg !122
  br label %bb_rcslotdone173
bb_rcslotowner173:
  %v1379 = load i64, ptr %slot36, align 8
  store i64 %v1379, ptr %slot158, align 8
  %v1380 = load i64, ptr %slot158, align 8
  %v1381 = load i64, ptr %slot154, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1380, i64 %v1381) nomerge, !dbg !122
  br label %bb_rcslotdone173
bb_rcslotdone173:
  br label %bb_i77
bb_rcarmnext170:
  br label %bb_failure
bb_i17:
  %v1382 = load i64, ptr %slot19, align 8
  %v1383 = load i64, ptr %slot20, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  store i64 %v1382, ptr %p1384, align 8, !alias.scope !3, !noalias !4
  %v1385 = load i64, ptr %slot19, align 8
  %v1386 = load i64, ptr %slot20, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  store i64 %v1385, ptr %p1387, align 8, !alias.scope !3, !noalias !4
  %v1388 = load i64, ptr %slot20, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %ld1390 = load i64, ptr %p1389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1390, ptr %slot159, align 8
  %v1391 = load i64, ptr %slot6, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %ld1393 = load i32, ptr %p1392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1393, ptr %slot160, align 8
  %v1394 = load i64, ptr %slot7, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  %ld1396 = load i32, ptr %p1395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1396, ptr %slot161, align 8
  %v1397 = load i32, ptr %slot161, align 8
  %op1398 = and i32 %v1397, 24
  store i32 %op1398, ptr %slot161, align 8
  %v1399 = load i32, ptr %slot161, align 8
  %cmp1400 = icmp eq i32 %v1399, 0
  %cv1401 = zext i1 %cmp1400 to i32
  store i32 %cv1401, ptr %slot162, align 8
  %v1402 = load i32, ptr %slot160, align 8
  %v1403 = load i32, ptr %slot162, align 8
  %op1404 = and i32 %v1402, %v1403
  store i32 %op1404, ptr %slot163, align 8
  %v1405 = load i64, ptr %slot37, align 8
  store i64 %v1405, ptr %slot164, align 8
  %v1406 = load i32, ptr %slot163, align 8
  %op1407 = mul i32 %v1406, 4
  store i32 %op1407, ptr %slot165, align 8
  %v1408 = load i32, ptr %slot165, align 8
  %op1409 = or i32 %v1408, 0
  store i32 %op1409, ptr %slot166, align 8
  %v1410 = load i64, ptr %slot14, align 8
  store i64 %v1410, ptr %slot167, align 8
  %v1411 = load i64, ptr %slot36, align 8
  %v1412 = load i64, ptr %slot167, align 8
  %v1413 = load i64, ptr %slot159, align 8
  %v1414 = load i64, ptr %slot164, align 8
  %cv1415 = trunc i64 %v1414 to i32
  %v1416 = load i32, ptr %slot166, align 8
  %call1417 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_publish(i64 %v1411, i64 %v1412, i64 %v1413, i32 %cv1415, i32 %v1416) nomerge, !dbg !124
  store i32 %call1417, ptr %slot168, align 8
  %v1418 = load i32, ptr %slot168, align 8
  %cv1419 = zext i32 %v1418 to i64
  %cond1420 = icmp ne i64 %cv1419, 0
  br i1 %cond1420, label %bb_rcsuccess194, label %bb_rcfailure194
bb_rcfailure194:
  %v1421 = load i64, ptr %slot36, align 8
  %p1422 = inttoptr i64 %v1421 to ptr
  %call1423 = call i32 @myl_rc_take_failure(ptr %p1422) nomerge, !dbg !124
  store i32 %call1423, ptr %slot169, align 8
  %v1424 = load i64, ptr %slot1, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  %v1426 = load i32, ptr %slot169, align 8
  %call1427 = call i32 @myl_qbe_rc_status(ptr %p1425, i32 %v1426) nomerge, !dbg !124
  store i32 %call1427, ptr %slot170, align 8
  br label %bb_failure
bb_rcsuccess194:
  %v1428 = load i32, ptr %slot163, align 8
  %cv1429 = zext i32 %v1428 to i64
  %cond1430 = icmp ne i64 %cv1429, 0
  br i1 %cond1430, label %bb_rchtaken197, label %bb_rchcopied197
bb_rchcopied197:
  %v1431 = load i64, ptr %slot6, align 8
  %p1432 = inttoptr i64 %v1431 to ptr
  %ld1433 = load i32, ptr %p1432, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1433, ptr %slot171, align 8
  %v1434 = load i32, ptr %slot171, align 8
  %cv1435 = zext i32 %v1434 to i64
  %cond1436 = icmp ne i64 %cv1435, 0
  br i1 %cond1436, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v1437 = load i64, ptr %slot6, align 8
  %p1438 = inttoptr i64 %v1437 to ptr
  store i32 0, ptr %p1438, align 4, !alias.scope !3, !noalias !4
  %v1439 = load i64, ptr %slot12, align 8
  store i64 %v1439, ptr %slot172, align 8
  %v1440 = load i64, ptr %slot7, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %ld1442 = load i32, ptr %p1441, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1442, ptr %slot173, align 8
  %v1443 = load i32, ptr %slot173, align 8
  %op1444 = and i32 %v1443, 28
  store i32 %op1444, ptr %slot174, align 8
  %v1445 = load i32, ptr %slot174, align 8
  %cv1446 = zext i32 %v1445 to i64
  %cond1447 = icmp ne i64 %cv1446, 0
  br i1 %cond1447, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v1448 = load i64, ptr %slot36, align 8
  store i64 %v1448, ptr %slot175, align 8
  %v1449 = load i64, ptr %slot175, align 8
  %v1450 = load i64, ptr %slot172, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1449, i64 %v1450) nomerge, !dbg !124
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v1451 = load i64, ptr %slot36, align 8
  store i64 %v1451, ptr %slot176, align 8
  %v1452 = load i64, ptr %slot176, align 8
  %v1453 = load i64, ptr %slot172, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v1452, i64 %v1453) nomerge, !dbg !124
  br label %bb_rcslotdone200
bb_rcslotdone200:
  br label %bb_rchprepared197
bb_rchtaken197:
  %v1454 = load i64, ptr %slot6, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  store i32 0, ptr %p1455, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared197
bb_rchprepared197:
  %v1456 = load i64, ptr %slot10, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  store i32 2, ptr %p1457, align 4, !alias.scope !3, !noalias !4
  %v1458 = load i64, ptr %slot9, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i32 1, ptr %p1459, align 4, !alias.scope !3, !noalias !4
  %v1460 = load i64, ptr %slot12, align 8
  store i64 %v1460, ptr %slot177, align 8
  %v1461 = load i64, ptr %slot14, align 8
  store i64 %v1461, ptr %slot178, align 8
  %v1462 = load i64, ptr %slot178, align 8
  %v1463 = load i64, ptr %slot177, align 8
  %p1464 = inttoptr i64 %v1462 to ptr
  %p1465 = inttoptr i64 %v1463 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1465, ptr %p1464, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1466 = load i64, ptr %slot7, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  store i32 2, ptr %p1467, align 4, !alias.scope !3, !noalias !4
  %v1468 = load i64, ptr %slot10, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  %ld1470 = load i32, ptr %p1469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1470, ptr %slot179, align 8
  %v1471 = load i32, ptr %slot179, align 8
  %v1472 = load i64, ptr %slot7, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  store i32 %v1471, ptr %p1473, align 4, !alias.scope !3, !noalias !4
  %v1474 = load i64, ptr %slot9, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  store i32 0, ptr %p1475, align 4, !alias.scope !3, !noalias !4
  %v1476 = load i64, ptr %slot6, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  store i32 1, ptr %p1477, align 4, !alias.scope !3, !noalias !4
  %v1478 = load i64, ptr %slot177, align 8
  %v1479 = load i64, ptr %slot20, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  store i64 %v1478, ptr %p1480, align 8, !alias.scope !3, !noalias !4
  %v1481 = load i64, ptr %slot20, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  %ld1483 = load i64, ptr %p1482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1483, ptr %slot180, align 8
  %v1484 = load i64, ptr %slot20, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %ld1486 = load i64, ptr %p1485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1486, ptr %slot181, align 8
  %v1487 = load i64, ptr %slot14, align 8
  store i64 %v1487, ptr %slot182, align 8
  %v1488 = load i64, ptr %slot37, align 8
  store i64 %v1488, ptr %slot183, align 8
  %v1489 = load i64, ptr %slot181, align 8
  %op1490 = add i64 %v1489, 8
  store i64 %op1490, ptr %slot184, align 8
  %v1491 = load i64, ptr %slot184, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  %ld1493 = load i64, ptr %p1492, align 8
  store i64 %ld1493, ptr %slot185, align 8
  %v1494 = load i64, ptr %slot185, align 8
  %cmp1495 = icmp ne i64 %v1494, 0
  %cv1496 = zext i1 %cmp1495 to i32
  store i32 %cv1496, ptr %slot186, align 8
  %v1497 = load i32, ptr %slot186, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcmoveheader225, label %bb_rcmovenext225
bb_rcmoveheader225:
  %v1500 = load i64, ptr %slot185, align 8
  %op1501 = sub i64 %v1500, 16
  store i64 %op1501, ptr %slot187, align 8
  %v1502 = load i64, ptr %slot185, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  %rgep1504 = getelementptr i8, ptr %p1503, i64 -16
  %ld1505 = load i64, ptr %rgep1504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1505, ptr %slot188, align 8
  %v1506 = load i64, ptr %slot188, align 8
  %op1507 = and i64 %v1506, 5764607523034234881
  store i64 %op1507, ptr %slot189, align 8
  %v1508 = load i64, ptr %slot189, align 8
  %cmp1509 = icmp ne i64 %v1508, 0
  %cv1510 = zext i1 %cmp1509 to i32
  store i32 %cv1510, ptr %slot190, align 8
  %v1511 = load i32, ptr %slot190, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcmoveslow222, label %bb_rcmovenext225
bb_rcmovenext225:
  %v1514 = load i64, ptr %slot181, align 8
  %v1515 = load i64, ptr %slot182, align 8
  %p1516 = inttoptr i64 %v1514 to ptr
  %p1517 = inttoptr i64 %v1515 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1517, ptr %p1516, i64 24, i1 false)
  %v1518 = load i64, ptr %slot181, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  store i64 0, ptr %p1519, align 8
  %v1520 = load i64, ptr %slot181, align 8
  %op1521 = add i64 %v1520, 8
  store i64 %op1521, ptr %slot191, align 8
  %v1522 = load i64, ptr %slot191, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  store i64 0, ptr %p1523, align 8
  %v1524 = load i64, ptr %slot181, align 8
  %op1525 = add i64 %v1524, 16
  store i64 %op1525, ptr %slot192, align 8
  %v1526 = load i64, ptr %slot192, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  store i64 0, ptr %p1527, align 8
  br label %bb_rcmoved222
bb_rcmoveslow222:
  %v1528 = load i64, ptr %slot36, align 8
  %v1529 = load i64, ptr %slot182, align 8
  %v1530 = load i64, ptr %slot181, align 8
  %v1531 = load i64, ptr %slot183, align 8
  %cv1532 = trunc i64 %v1531 to i32
  %call1533 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v1528, i64 %v1529, i64 %v1530, i32 %cv1532) nomerge, !dbg !126
  store i32 %call1533, ptr %slot193, align 8
  %v1534 = load i32, ptr %slot193, align 8
  %cv1535 = zext i32 %v1534 to i64
  %cond1536 = icmp ne i64 %cv1535, 0
  br i1 %cond1536, label %bb_rcsuccess234, label %bb_rcfailure234
bb_rcfailure234:
  %v1537 = load i64, ptr %slot36, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  %call1539 = call i32 @myl_rc_take_failure(ptr %p1538) nomerge, !dbg !126
  store i32 %call1539, ptr %slot194, align 8
  %v1540 = load i64, ptr %slot1, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  %v1542 = load i32, ptr %slot194, align 8
  %call1543 = call i32 @myl_qbe_rc_status(ptr %p1541, i32 %v1542) nomerge, !dbg !126
  store i32 %call1543, ptr %slot195, align 8
  br label %bb_failure
bb_rcsuccess234:
  br label %bb_rcmoved222
bb_rcmoved222:
  %v1544 = load i64, ptr %slot6, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  store i32 0, ptr %p1545, align 4, !alias.scope !3, !noalias !4
  %v1546 = load i64, ptr %slot10, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  store i32 2, ptr %p1547, align 4, !alias.scope !3, !noalias !4
  %v1548 = load i64, ptr %slot9, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  store i32 1, ptr %p1549, align 4, !alias.scope !3, !noalias !4
  %v1550 = load i64, ptr %slot14, align 8
  store i64 %v1550, ptr %slot196, align 8
  %v1551 = load i64, ptr %slot9, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  store i32 0, ptr %p1552, align 4, !alias.scope !3, !noalias !4
  %v1553 = load i64, ptr %slot6, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  %ld1555 = load i32, ptr %p1554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1555, ptr %slot197, align 8
  %v1556 = load i32, ptr %slot197, align 8
  %cv1557 = zext i32 %v1556 to i64
  %cond1558 = icmp ne i64 %cv1557, 0
  br i1 %cond1558, label %bb_rcslotdrop244, label %bb_rcslotdone244
bb_rcslotdrop244:
  %v1559 = load i64, ptr %slot6, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i32 0, ptr %p1560, align 4, !alias.scope !3, !noalias !4
  %v1561 = load i64, ptr %slot12, align 8
  store i64 %v1561, ptr %slot198, align 8
  %v1562 = load i64, ptr %slot7, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  %ld1564 = load i32, ptr %p1563, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1564, ptr %slot199, align 8
  %v1565 = load i32, ptr %slot199, align 8
  %op1566 = and i32 %v1565, 28
  store i32 %op1566, ptr %slot200, align 8
  %v1567 = load i32, ptr %slot200, align 8
  %cv1568 = zext i32 %v1567 to i64
  %cond1569 = icmp ne i64 %cv1568, 0
  br i1 %cond1569, label %bb_rcslotrole244, label %bb_rcslotowner244
bb_rcslotrole244:
  %v1570 = load i64, ptr %slot36, align 8
  store i64 %v1570, ptr %slot201, align 8
  %v1571 = load i64, ptr %slot201, align 8
  %v1572 = load i64, ptr %slot198, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1571, i64 %v1572) nomerge, !dbg !126
  br label %bb_rcslotdone244
bb_rcslotowner244:
  %v1573 = load i64, ptr %slot36, align 8
  store i64 %v1573, ptr %slot202, align 8
  %v1574 = load i64, ptr %slot202, align 8
  %v1575 = load i64, ptr %slot198, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v1574, i64 %v1575) nomerge, !dbg !126
  br label %bb_rcslotdone244
bb_rcslotdone244:
  %v1576 = load i64, ptr %slot196, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1577, i64 24, i1 false)
  ret void
bb_i23:
  %v1578 = load i64, ptr %slot20, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  store i64 0, ptr %p1579, align 8, !alias.scope !3, !noalias !4
  %v1580 = load i64, ptr %slot20, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  %ld1582 = load i64, ptr %p1581, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1582, ptr %slot203, align 8
  %v1583 = load i64, ptr %slot203, align 8
  %cond1584 = icmp ne i64 %v1583, 0
  br i1 %cond1584, label %bb_success307, label %bb_failed307
bb_failed307:
  %v1585 = load i64, ptr %slot1, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  call void @myl_qbe_fail_assert(ptr %p1586) nomerge, !dbg !128
  unreachable
bb_success307:
  %v1587 = load i64, ptr %slot20, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  store i64 18446744073709551615, ptr %p1588, align 8, !alias.scope !3, !noalias !4
  %v1589 = load i64, ptr %slot1, align 8
  %call1590 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v1589) nomerge, !dbg !130
  store { i64, i64 } %call1590, ptr %callresult205, align 8
  %addr1591 = ptrtoint ptr %callresult205 to i64
  store i64 %addr1591, ptr %slot204, align 8
  %v1592 = load i64, ptr %slot204, align 8
  %v1593 = load i64, ptr %slot21, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  store i64 %v1592, ptr %p1594, align 8, !alias.scope !3, !noalias !4
  %v1595 = load i64, ptr %slot21, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  %ld1597 = load i64, ptr %p1596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1597, ptr %slot206, align 8
  %v1598 = load i64, ptr %slot14, align 8
  store i64 %v1598, ptr %slot207, align 8
  %v1599 = load i64, ptr %slot206, align 8
  %v1600 = load i64, ptr %slot207, align 8
  %p1601 = inttoptr i64 %v1599 to ptr
  %p1602 = inttoptr i64 %v1600 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1602, ptr %p1601, i64 16, i1 false)
  %v1603 = load i64, ptr %slot10, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  store i32 2, ptr %p1604, align 4, !alias.scope !3, !noalias !4
  %v1605 = load i64, ptr %slot9, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  store i32 1, ptr %p1606, align 4, !alias.scope !3, !noalias !4
  %v1607 = load i64, ptr %slot13, align 8
  store i64 %v1607, ptr %slot208, align 8
  %v1608 = load i64, ptr %slot14, align 8
  store i64 %v1608, ptr %slot209, align 8
  %v1609 = load i64, ptr %slot209, align 8
  %v1610 = load i64, ptr %slot208, align 8
  %p1611 = inttoptr i64 %v1609 to ptr
  %p1612 = inttoptr i64 %v1610 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1612, ptr %p1611, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1613 = load i64, ptr %slot10, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  %ld1615 = load i32, ptr %p1614, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1615, ptr %slot210, align 8
  %v1616 = load i64, ptr %slot9, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  store i32 0, ptr %p1617, align 4, !alias.scope !3, !noalias !4
  %v1618 = load i64, ptr %slot8, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i32 1, ptr %p1619, align 4, !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot208, align 8
  %v1621 = load i64, ptr %slot21, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i64 %v1620, ptr %p1622, align 8, !alias.scope !3, !noalias !4
  %v1623 = load i64, ptr %slot22, align 8
  store i64 %v1623, ptr %slot211, align 8
  %v1624 = load i64, ptr %slot211, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i64 0, ptr %p1625, align 8, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot211, align 8
  %p1628 = inttoptr i64 %v1626 to ptr
  %gep1629 = getelementptr i8, ptr %p1628, i64 8
  %op1627 = ptrtoint ptr %gep1629 to i64
  store i64 %op1627, ptr %slot212, align 8
  %v1630 = load i64, ptr %slot212, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i64 0, ptr %p1631, align 8, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot211, align 8
  %p1634 = inttoptr i64 %v1632 to ptr
  %gep1635 = getelementptr i8, ptr %p1634, i64 16
  %op1633 = ptrtoint ptr %gep1635 to i64
  store i64 %op1633, ptr %slot213, align 8
  %v1636 = load i64, ptr %slot213, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  store i64 0, ptr %p1637, align 8, !alias.scope !3, !noalias !4
  %v1638 = load i64, ptr %slot11, align 8
  %p1639 = inttoptr i64 %v1638 to ptr
  store i32 1, ptr %p1639, align 4, !alias.scope !3, !noalias !4
  %v1640 = load i64, ptr %slot37, align 8
  store i64 %v1640, ptr %slot214, align 8
  %v1641 = load i64, ptr %slot20, align 8
  store i64 %v1641, ptr %slot215, align 8
  %v1642 = load i64, ptr %slot211, align 8
  %p1644 = inttoptr i64 %v1642 to ptr
  %gep1645 = getelementptr i8, ptr %p1644, i64 0
  %op1643 = ptrtoint ptr %gep1645 to i64
  store i64 %op1643, ptr %slot216, align 8
  %v1646 = load i64, ptr %slot215, align 8
  %p1647 = inttoptr i64 %v1646 to ptr
  %ld1648 = load i64, ptr %p1647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1648, ptr %slot217, align 8
  %v1649 = load i64, ptr %slot217, align 8
  %v1650 = load i64, ptr %slot216, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  store i64 %v1649, ptr %p1651, align 8, !alias.scope !3, !noalias !4
  %v1652 = load i64, ptr %slot21, align 8
  %p1653 = inttoptr i64 %v1652 to ptr
  %ld1654 = load i64, ptr %p1653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1654, ptr %slot218, align 8
  %v1655 = load i64, ptr %slot211, align 8
  %p1657 = inttoptr i64 %v1655 to ptr
  %gep1658 = getelementptr i8, ptr %p1657, i64 8
  %op1656 = ptrtoint ptr %gep1658 to i64
  store i64 %op1656, ptr %slot219, align 8
  %v1659 = load i64, ptr %slot21, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %ld1661 = load i64, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1661, ptr %slot220, align 8
  %v1662 = load i64, ptr %slot14, align 8
  store i64 %v1662, ptr %slot221, align 8
  %v1663 = load i64, ptr %slot37, align 8
  store i64 %v1663, ptr %slot222, align 8
  %v1664 = load i64, ptr %slot220, align 8
  %op1665 = add i64 %v1664, 0
  store i64 %op1665, ptr %slot223, align 8
  %v1666 = load i64, ptr %slot223, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  %ld1668 = load i64, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1668, ptr %slot224, align 8
  %v1669 = load i64, ptr %slot224, align 8
  %cmp1670 = icmp ne i64 %v1669, 0
  %cv1671 = zext i1 %cmp1670 to i32
  store i32 %cv1671, ptr %slot225, align 8
  %v1672 = load i32, ptr %slot225, align 8
  %cv1673 = zext i32 %v1672 to i64
  %cond1674 = icmp ne i64 %cv1673, 0
  br i1 %cond1674, label %bb_rcmoveheader338, label %bb_rcmovenext338
bb_rcmoveheader338:
  %v1675 = load i64, ptr %slot224, align 8
  %op1676 = sub i64 %v1675, 16
  store i64 %op1676, ptr %slot226, align 8
  %v1677 = load i64, ptr %slot224, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  %rgep1679 = getelementptr i8, ptr %p1678, i64 -16
  %ld1680 = load i64, ptr %rgep1679, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1680, ptr %slot227, align 8
  %v1681 = load i64, ptr %slot227, align 8
  %op1682 = and i64 %v1681, 5764607523034234881
  store i64 %op1682, ptr %slot228, align 8
  %v1683 = load i64, ptr %slot228, align 8
  %cmp1684 = icmp ne i64 %v1683, 0
  %cv1685 = zext i1 %cmp1684 to i32
  store i32 %cv1685, ptr %slot229, align 8
  %v1686 = load i32, ptr %slot229, align 8
  %cv1687 = zext i32 %v1686 to i64
  %cond1688 = icmp ne i64 %cv1687, 0
  br i1 %cond1688, label %bb_rcmoveslow335, label %bb_rcmovenext338
bb_rcmovenext338:
  %v1689 = load i64, ptr %slot220, align 8
  %v1690 = load i64, ptr %slot221, align 8
  %p1691 = inttoptr i64 %v1689 to ptr
  %p1692 = inttoptr i64 %v1690 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1692, ptr %p1691, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1693 = load i64, ptr %slot220, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i64 0, ptr %p1694, align 8, !alias.scope !3, !noalias !4
  %v1695 = load i64, ptr %slot220, align 8
  %op1696 = add i64 %v1695, 8
  store i64 %op1696, ptr %slot230, align 8
  %v1697 = load i64, ptr %slot230, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  store i64 0, ptr %p1698, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved335
bb_rcmoveslow335:
  %v1699 = load i64, ptr %slot36, align 8
  %v1700 = load i64, ptr %slot221, align 8
  %v1701 = load i64, ptr %slot220, align 8
  %v1702 = load i64, ptr %slot222, align 8
  %cv1703 = trunc i64 %v1702 to i32
  %call1704 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v1699, i64 %v1700, i64 %v1701, i32 %cv1703) nomerge, !dbg !132
  store i32 %call1704, ptr %slot231, align 8
  %v1705 = load i32, ptr %slot231, align 8
  %cv1706 = zext i32 %v1705 to i64
  %cond1707 = icmp ne i64 %cv1706, 0
  br i1 %cond1707, label %bb_rcsuccess346, label %bb_rcfailure346
bb_rcfailure346:
  %v1708 = load i64, ptr %slot36, align 8
  %p1709 = inttoptr i64 %v1708 to ptr
  %call1710 = call i32 @myl_rc_take_failure(ptr %p1709) nomerge, !dbg !132
  store i32 %call1710, ptr %slot232, align 8
  %v1711 = load i64, ptr %slot1, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  %v1713 = load i32, ptr %slot232, align 8
  %call1714 = call i32 @myl_qbe_rc_status(ptr %p1712, i32 %v1713) nomerge, !dbg !132
  store i32 %call1714, ptr %slot233, align 8
  br label %bb_failure
bb_rcsuccess346:
  br label %bb_rcmoved335
bb_rcmoved335:
  %v1715 = load i64, ptr %slot8, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 0, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot10, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  store i32 2, ptr %p1718, align 4, !alias.scope !3, !noalias !4
  %v1719 = load i64, ptr %slot9, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  store i32 1, ptr %p1720, align 4, !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot14, align 8
  store i64 %v1721, ptr %slot234, align 8
  %v1722 = load i64, ptr %slot234, align 8
  %v1723 = load i64, ptr %slot219, align 8
  %p1724 = inttoptr i64 %v1722 to ptr
  %p1725 = inttoptr i64 %v1723 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1725, ptr %p1724, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot9, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  store i32 0, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  %v1728 = load i64, ptr %slot211, align 8
  %v1729 = load i64, ptr %slot20, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i64 %v1728, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot20, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %ld1733 = load i64, ptr %p1732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1733, ptr %slot235, align 8
  %v1734 = load i64, ptr %slot12, align 8
  store i64 %v1734, ptr %slot236, align 8
  %v1735 = load i64, ptr %slot235, align 8
  %v1736 = load i64, ptr %slot236, align 8
  %p1737 = inttoptr i64 %v1735 to ptr
  %p1738 = inttoptr i64 %v1736 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1738, ptr %p1737, i64 24, i1 false)
  %v1739 = load i64, ptr %slot7, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i32 2, ptr %p1740, align 4, !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot6, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i32 1, ptr %p1742, align 4, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot236, align 8
  %v1744 = load i64, ptr %slot20, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  store i64 %v1743, ptr %p1745, align 8, !alias.scope !3, !noalias !4
  %v1746 = load i64, ptr %slot20, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %ld1748 = load i64, ptr %p1747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1748, ptr %slot237, align 8
  %v1749 = load i64, ptr %slot20, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i64, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1751, ptr %slot238, align 8
  %v1752 = load i64, ptr %slot14, align 8
  store i64 %v1752, ptr %slot239, align 8
  %v1753 = load i64, ptr %slot37, align 8
  store i64 %v1753, ptr %slot240, align 8
  %v1754 = load i64, ptr %slot238, align 8
  %op1755 = add i64 %v1754, 8
  store i64 %op1755, ptr %slot241, align 8
  %v1756 = load i64, ptr %slot241, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  %ld1758 = load i64, ptr %p1757, align 8
  store i64 %ld1758, ptr %slot242, align 8
  %v1759 = load i64, ptr %slot242, align 8
  %cmp1760 = icmp ne i64 %v1759, 0
  %cv1761 = zext i1 %cmp1760 to i32
  store i32 %cv1761, ptr %slot243, align 8
  %v1762 = load i32, ptr %slot243, align 8
  %cv1763 = zext i32 %v1762 to i64
  %cond1764 = icmp ne i64 %cv1763, 0
  br i1 %cond1764, label %bb_rcmoveheader365, label %bb_rcmovenext365
bb_rcmoveheader365:
  %v1765 = load i64, ptr %slot242, align 8
  %op1766 = sub i64 %v1765, 16
  store i64 %op1766, ptr %slot244, align 8
  %v1767 = load i64, ptr %slot242, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %rgep1769 = getelementptr i8, ptr %p1768, i64 -16
  %ld1770 = load i64, ptr %rgep1769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1770, ptr %slot245, align 8
  %v1771 = load i64, ptr %slot245, align 8
  %op1772 = and i64 %v1771, 5764607523034234881
  store i64 %op1772, ptr %slot246, align 8
  %v1773 = load i64, ptr %slot246, align 8
  %cmp1774 = icmp ne i64 %v1773, 0
  %cv1775 = zext i1 %cmp1774 to i32
  store i32 %cv1775, ptr %slot247, align 8
  %v1776 = load i32, ptr %slot247, align 8
  %cv1777 = zext i32 %v1776 to i64
  %cond1778 = icmp ne i64 %cv1777, 0
  br i1 %cond1778, label %bb_rcmoveslow362, label %bb_rcmovenext365
bb_rcmovenext365:
  %v1779 = load i64, ptr %slot238, align 8
  %v1780 = load i64, ptr %slot239, align 8
  %p1781 = inttoptr i64 %v1779 to ptr
  %p1782 = inttoptr i64 %v1780 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1782, ptr %p1781, i64 24, i1 false)
  %v1783 = load i64, ptr %slot238, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  store i64 0, ptr %p1784, align 8
  %v1785 = load i64, ptr %slot238, align 8
  %op1786 = add i64 %v1785, 8
  store i64 %op1786, ptr %slot248, align 8
  %v1787 = load i64, ptr %slot248, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  store i64 0, ptr %p1788, align 8
  %v1789 = load i64, ptr %slot238, align 8
  %op1790 = add i64 %v1789, 16
  store i64 %op1790, ptr %slot249, align 8
  %v1791 = load i64, ptr %slot249, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  store i64 0, ptr %p1792, align 8
  br label %bb_rcmoved362
bb_rcmoveslow362:
  %v1793 = load i64, ptr %slot36, align 8
  %v1794 = load i64, ptr %slot239, align 8
  %v1795 = load i64, ptr %slot238, align 8
  %v1796 = load i64, ptr %slot240, align 8
  %cv1797 = trunc i64 %v1796 to i32
  %call1798 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v1793, i64 %v1794, i64 %v1795, i32 %cv1797) nomerge, !dbg !134
  store i32 %call1798, ptr %slot250, align 8
  %v1799 = load i32, ptr %slot250, align 8
  %cv1800 = zext i32 %v1799 to i64
  %cond1801 = icmp ne i64 %cv1800, 0
  br i1 %cond1801, label %bb_rcsuccess374, label %bb_rcfailure374
bb_rcfailure374:
  %v1802 = load i64, ptr %slot36, align 8
  %p1803 = inttoptr i64 %v1802 to ptr
  %call1804 = call i32 @myl_rc_take_failure(ptr %p1803) nomerge, !dbg !134
  store i32 %call1804, ptr %slot251, align 8
  %v1805 = load i64, ptr %slot1, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  %v1807 = load i32, ptr %slot251, align 8
  %call1808 = call i32 @myl_qbe_rc_status(ptr %p1806, i32 %v1807) nomerge, !dbg !134
  store i32 %call1808, ptr %slot252, align 8
  br label %bb_failure
bb_rcsuccess374:
  br label %bb_rcmoved362
bb_rcmoved362:
  %v1809 = load i64, ptr %slot6, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  store i32 0, ptr %p1810, align 4, !alias.scope !3, !noalias !4
  %v1811 = load i64, ptr %slot10, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  store i32 2, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  %v1813 = load i64, ptr %slot9, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i32 1, ptr %p1814, align 4, !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot14, align 8
  store i64 %v1815, ptr %slot253, align 8
  %v1816 = load i64, ptr %slot9, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  store i32 0, ptr %p1817, align 4, !alias.scope !3, !noalias !4
  %v1818 = load i64, ptr %slot6, align 8
  %p1819 = inttoptr i64 %v1818 to ptr
  %ld1820 = load i32, ptr %p1819, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1820, ptr %slot254, align 8
  %v1821 = load i32, ptr %slot254, align 8
  %cv1822 = zext i32 %v1821 to i64
  %cond1823 = icmp ne i64 %cv1822, 0
  br i1 %cond1823, label %bb_rcslotdrop384, label %bb_rcslotdone384
bb_rcslotdrop384:
  %v1824 = load i64, ptr %slot6, align 8
  %p1825 = inttoptr i64 %v1824 to ptr
  store i32 0, ptr %p1825, align 4, !alias.scope !3, !noalias !4
  %v1826 = load i64, ptr %slot12, align 8
  store i64 %v1826, ptr %slot255, align 8
  %v1827 = load i64, ptr %slot7, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %ld1829 = load i32, ptr %p1828, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1829, ptr %slot256, align 8
  %v1830 = load i32, ptr %slot256, align 8
  %op1831 = and i32 %v1830, 28
  store i32 %op1831, ptr %slot257, align 8
  %v1832 = load i32, ptr %slot257, align 8
  %cv1833 = zext i32 %v1832 to i64
  %cond1834 = icmp ne i64 %cv1833, 0
  br i1 %cond1834, label %bb_rcslotrole384, label %bb_rcslotowner384
bb_rcslotrole384:
  %v1835 = load i64, ptr %slot36, align 8
  store i64 %v1835, ptr %slot258, align 8
  %v1836 = load i64, ptr %slot258, align 8
  %v1837 = load i64, ptr %slot255, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v1836, i64 %v1837) nomerge, !dbg !134
  br label %bb_rcslotdone384
bb_rcslotowner384:
  %v1838 = load i64, ptr %slot36, align 8
  store i64 %v1838, ptr %slot259, align 8
  %v1839 = load i64, ptr %slot259, align 8
  %v1840 = load i64, ptr %slot255, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v1839, i64 %v1840) nomerge, !dbg !134
  br label %bb_rcslotdone384
bb_rcslotdone384:
  %v1841 = load i64, ptr %slot253, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1842, i64 24, i1 false)
  ret void
bb_i29:
  %v1843 = load i64, ptr %slot20, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  store i64 0, ptr %p1844, align 8, !alias.scope !3, !noalias !4
  %v1845 = load i64, ptr %slot20, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  %ld1847 = load i64, ptr %p1846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1847, ptr %slot260, align 8
  %v1848 = load i64, ptr %slot260, align 8
  %cond1849 = icmp ne i64 %v1848, 0
  br i1 %cond1849, label %bb_success447, label %bb_failed447
bb_failed447:
  %v1850 = load i64, ptr %slot1, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  call void @myl_qbe_fail_assert(ptr %p1851) nomerge, !dbg !136
  unreachable
bb_success447:
  %v1852 = load i64, ptr %slot20, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  store i64 18446744073709551615, ptr %p1853, align 8, !alias.scope !3, !noalias !4
  %v1854 = load i64, ptr %slot1, align 8
  %call1855 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v1854) nomerge, !dbg !138
  store { i64, i64 } %call1855, ptr %callresult262, align 8
  %addr1856 = ptrtoint ptr %callresult262 to i64
  store i64 %addr1856, ptr %slot261, align 8
  %v1857 = load i64, ptr %slot261, align 8
  %v1858 = load i64, ptr %slot21, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  store i64 %v1857, ptr %p1859, align 8, !alias.scope !3, !noalias !4
  %v1860 = load i64, ptr %slot21, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  %ld1862 = load i64, ptr %p1861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1862, ptr %slot263, align 8
  %v1863 = load i64, ptr %slot14, align 8
  store i64 %v1863, ptr %slot264, align 8
  %v1864 = load i64, ptr %slot263, align 8
  %v1865 = load i64, ptr %slot264, align 8
  %p1866 = inttoptr i64 %v1864 to ptr
  %p1867 = inttoptr i64 %v1865 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1867, ptr %p1866, i64 16, i1 false)
  %v1868 = load i64, ptr %slot10, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  store i32 2, ptr %p1869, align 4, !alias.scope !3, !noalias !4
  %v1870 = load i64, ptr %slot9, align 8
  %p1871 = inttoptr i64 %v1870 to ptr
  store i32 1, ptr %p1871, align 4, !alias.scope !3, !noalias !4
  %v1872 = load i64, ptr %slot13, align 8
  store i64 %v1872, ptr %slot265, align 8
  %v1873 = load i64, ptr %slot14, align 8
  store i64 %v1873, ptr %slot266, align 8
  %v1874 = load i64, ptr %slot266, align 8
  %v1875 = load i64, ptr %slot265, align 8
  %p1876 = inttoptr i64 %v1874 to ptr
  %p1877 = inttoptr i64 %v1875 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1877, ptr %p1876, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot10, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %ld1880 = load i32, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1880, ptr %slot267, align 8
  %v1881 = load i64, ptr %slot9, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  store i32 0, ptr %p1882, align 4, !alias.scope !3, !noalias !4
  %v1883 = load i64, ptr %slot8, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  store i32 1, ptr %p1884, align 4, !alias.scope !3, !noalias !4
  %v1885 = load i64, ptr %slot265, align 8
  %v1886 = load i64, ptr %slot21, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i64 %v1885, ptr %p1887, align 8, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot23, align 8
  store i64 %v1888, ptr %slot268, align 8
  %v1889 = load i64, ptr %slot268, align 8
  %p1890 = inttoptr i64 %v1889 to ptr
  store i64 0, ptr %p1890, align 8, !alias.scope !3, !noalias !4
  %v1891 = load i64, ptr %slot268, align 8
  %p1893 = inttoptr i64 %v1891 to ptr
  %gep1894 = getelementptr i8, ptr %p1893, i64 8
  %op1892 = ptrtoint ptr %gep1894 to i64
  store i64 %op1892, ptr %slot269, align 8
  %v1895 = load i64, ptr %slot269, align 8
  %p1896 = inttoptr i64 %v1895 to ptr
  store i64 0, ptr %p1896, align 8, !alias.scope !3, !noalias !4
  %v1897 = load i64, ptr %slot268, align 8
  %p1899 = inttoptr i64 %v1897 to ptr
  %gep1900 = getelementptr i8, ptr %p1899, i64 16
  %op1898 = ptrtoint ptr %gep1900 to i64
  store i64 %op1898, ptr %slot270, align 8
  %v1901 = load i64, ptr %slot270, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  store i64 0, ptr %p1902, align 8, !alias.scope !3, !noalias !4
  %v1903 = load i64, ptr %slot11, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  store i32 1, ptr %p1904, align 4, !alias.scope !3, !noalias !4
  %v1905 = load i64, ptr %slot37, align 8
  store i64 %v1905, ptr %slot271, align 8
  %v1906 = load i64, ptr %slot20, align 8
  store i64 %v1906, ptr %slot272, align 8
  %v1907 = load i64, ptr %slot268, align 8
  %p1909 = inttoptr i64 %v1907 to ptr
  %gep1910 = getelementptr i8, ptr %p1909, i64 0
  %op1908 = ptrtoint ptr %gep1910 to i64
  store i64 %op1908, ptr %slot273, align 8
  %v1911 = load i64, ptr %slot272, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  %ld1913 = load i64, ptr %p1912, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1913, ptr %slot274, align 8
  %v1914 = load i64, ptr %slot274, align 8
  %v1915 = load i64, ptr %slot273, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  store i64 %v1914, ptr %p1916, align 8, !alias.scope !3, !noalias !4
  %v1917 = load i64, ptr %slot21, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %ld1919 = load i64, ptr %p1918, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1919, ptr %slot275, align 8
  %v1920 = load i64, ptr %slot268, align 8
  %p1922 = inttoptr i64 %v1920 to ptr
  %gep1923 = getelementptr i8, ptr %p1922, i64 8
  %op1921 = ptrtoint ptr %gep1923 to i64
  store i64 %op1921, ptr %slot276, align 8
  %v1924 = load i64, ptr %slot21, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %ld1926 = load i64, ptr %p1925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1926, ptr %slot277, align 8
  %v1927 = load i64, ptr %slot14, align 8
  store i64 %v1927, ptr %slot278, align 8
  %v1928 = load i64, ptr %slot37, align 8
  store i64 %v1928, ptr %slot279, align 8
  %v1929 = load i64, ptr %slot277, align 8
  %op1930 = add i64 %v1929, 0
  store i64 %op1930, ptr %slot280, align 8
  %v1931 = load i64, ptr %slot280, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  %ld1933 = load i64, ptr %p1932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1933, ptr %slot281, align 8
  %v1934 = load i64, ptr %slot281, align 8
  %cmp1935 = icmp ne i64 %v1934, 0
  %cv1936 = zext i1 %cmp1935 to i32
  store i32 %cv1936, ptr %slot282, align 8
  %v1937 = load i32, ptr %slot282, align 8
  %cv1938 = zext i32 %v1937 to i64
  %cond1939 = icmp ne i64 %cv1938, 0
  br i1 %cond1939, label %bb_rcmoveheader478, label %bb_rcmovenext478
bb_rcmoveheader478:
  %v1940 = load i64, ptr %slot281, align 8
  %op1941 = sub i64 %v1940, 16
  store i64 %op1941, ptr %slot283, align 8
  %v1942 = load i64, ptr %slot281, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %rgep1944 = getelementptr i8, ptr %p1943, i64 -16
  %ld1945 = load i64, ptr %rgep1944, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1945, ptr %slot284, align 8
  %v1946 = load i64, ptr %slot284, align 8
  %op1947 = and i64 %v1946, 5764607523034234881
  store i64 %op1947, ptr %slot285, align 8
  %v1948 = load i64, ptr %slot285, align 8
  %cmp1949 = icmp ne i64 %v1948, 0
  %cv1950 = zext i1 %cmp1949 to i32
  store i32 %cv1950, ptr %slot286, align 8
  %v1951 = load i32, ptr %slot286, align 8
  %cv1952 = zext i32 %v1951 to i64
  %cond1953 = icmp ne i64 %cv1952, 0
  br i1 %cond1953, label %bb_rcmoveslow475, label %bb_rcmovenext478
bb_rcmovenext478:
  %v1954 = load i64, ptr %slot277, align 8
  %v1955 = load i64, ptr %slot278, align 8
  %p1956 = inttoptr i64 %v1954 to ptr
  %p1957 = inttoptr i64 %v1955 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1957, ptr %p1956, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1958 = load i64, ptr %slot277, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  store i64 0, ptr %p1959, align 8, !alias.scope !3, !noalias !4
  %v1960 = load i64, ptr %slot277, align 8
  %op1961 = add i64 %v1960, 8
  store i64 %op1961, ptr %slot287, align 8
  %v1962 = load i64, ptr %slot287, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  store i64 0, ptr %p1963, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved475
bb_rcmoveslow475:
  %v1964 = load i64, ptr %slot36, align 8
  %v1965 = load i64, ptr %slot278, align 8
  %v1966 = load i64, ptr %slot277, align 8
  %v1967 = load i64, ptr %slot279, align 8
  %cv1968 = trunc i64 %v1967 to i32
  %call1969 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v1964, i64 %v1965, i64 %v1966, i32 %cv1968) nomerge, !dbg !140
  store i32 %call1969, ptr %slot288, align 8
  %v1970 = load i32, ptr %slot288, align 8
  %cv1971 = zext i32 %v1970 to i64
  %cond1972 = icmp ne i64 %cv1971, 0
  br i1 %cond1972, label %bb_rcsuccess486, label %bb_rcfailure486
bb_rcfailure486:
  %v1973 = load i64, ptr %slot36, align 8
  %p1974 = inttoptr i64 %v1973 to ptr
  %call1975 = call i32 @myl_rc_take_failure(ptr %p1974) nomerge, !dbg !140
  store i32 %call1975, ptr %slot289, align 8
  %v1976 = load i64, ptr %slot1, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  %v1978 = load i32, ptr %slot289, align 8
  %call1979 = call i32 @myl_qbe_rc_status(ptr %p1977, i32 %v1978) nomerge, !dbg !140
  store i32 %call1979, ptr %slot290, align 8
  br label %bb_failure
bb_rcsuccess486:
  br label %bb_rcmoved475
bb_rcmoved475:
  %v1980 = load i64, ptr %slot8, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  store i32 0, ptr %p1981, align 4, !alias.scope !3, !noalias !4
  %v1982 = load i64, ptr %slot10, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  store i32 2, ptr %p1983, align 4, !alias.scope !3, !noalias !4
  %v1984 = load i64, ptr %slot9, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  store i32 1, ptr %p1985, align 4, !alias.scope !3, !noalias !4
  %v1986 = load i64, ptr %slot14, align 8
  store i64 %v1986, ptr %slot291, align 8
  %v1987 = load i64, ptr %slot291, align 8
  %v1988 = load i64, ptr %slot276, align 8
  %p1989 = inttoptr i64 %v1987 to ptr
  %p1990 = inttoptr i64 %v1988 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1990, ptr %p1989, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1991 = load i64, ptr %slot9, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  store i32 0, ptr %p1992, align 4, !alias.scope !3, !noalias !4
  %v1993 = load i64, ptr %slot268, align 8
  %v1994 = load i64, ptr %slot20, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i64 %v1993, ptr %p1995, align 8, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot20, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %ld1998 = load i64, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1998, ptr %slot292, align 8
  %v1999 = load i64, ptr %slot12, align 8
  store i64 %v1999, ptr %slot293, align 8
  %v2000 = load i64, ptr %slot292, align 8
  %v2001 = load i64, ptr %slot293, align 8
  %p2002 = inttoptr i64 %v2000 to ptr
  %p2003 = inttoptr i64 %v2001 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2003, ptr %p2002, i64 24, i1 false)
  %v2004 = load i64, ptr %slot7, align 8
  %p2005 = inttoptr i64 %v2004 to ptr
  store i32 2, ptr %p2005, align 4, !alias.scope !3, !noalias !4
  %v2006 = load i64, ptr %slot6, align 8
  %p2007 = inttoptr i64 %v2006 to ptr
  store i32 1, ptr %p2007, align 4, !alias.scope !3, !noalias !4
  %v2008 = load i64, ptr %slot293, align 8
  %v2009 = load i64, ptr %slot20, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  store i64 %v2008, ptr %p2010, align 8, !alias.scope !3, !noalias !4
  %v2011 = load i64, ptr %slot20, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  %ld2013 = load i64, ptr %p2012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2013, ptr %slot294, align 8
  %v2014 = load i64, ptr %slot20, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  %ld2016 = load i64, ptr %p2015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2016, ptr %slot295, align 8
  %v2017 = load i64, ptr %slot14, align 8
  store i64 %v2017, ptr %slot296, align 8
  %v2018 = load i64, ptr %slot37, align 8
  store i64 %v2018, ptr %slot297, align 8
  %v2019 = load i64, ptr %slot295, align 8
  %op2020 = add i64 %v2019, 8
  store i64 %op2020, ptr %slot298, align 8
  %v2021 = load i64, ptr %slot298, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  %ld2023 = load i64, ptr %p2022, align 8
  store i64 %ld2023, ptr %slot299, align 8
  %v2024 = load i64, ptr %slot299, align 8
  %cmp2025 = icmp ne i64 %v2024, 0
  %cv2026 = zext i1 %cmp2025 to i32
  store i32 %cv2026, ptr %slot300, align 8
  %v2027 = load i32, ptr %slot300, align 8
  %cv2028 = zext i32 %v2027 to i64
  %cond2029 = icmp ne i64 %cv2028, 0
  br i1 %cond2029, label %bb_rcmoveheader505, label %bb_rcmovenext505
bb_rcmoveheader505:
  %v2030 = load i64, ptr %slot299, align 8
  %op2031 = sub i64 %v2030, 16
  store i64 %op2031, ptr %slot301, align 8
  %v2032 = load i64, ptr %slot299, align 8
  %p2033 = inttoptr i64 %v2032 to ptr
  %rgep2034 = getelementptr i8, ptr %p2033, i64 -16
  %ld2035 = load i64, ptr %rgep2034, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2035, ptr %slot302, align 8
  %v2036 = load i64, ptr %slot302, align 8
  %op2037 = and i64 %v2036, 5764607523034234881
  store i64 %op2037, ptr %slot303, align 8
  %v2038 = load i64, ptr %slot303, align 8
  %cmp2039 = icmp ne i64 %v2038, 0
  %cv2040 = zext i1 %cmp2039 to i32
  store i32 %cv2040, ptr %slot304, align 8
  %v2041 = load i32, ptr %slot304, align 8
  %cv2042 = zext i32 %v2041 to i64
  %cond2043 = icmp ne i64 %cv2042, 0
  br i1 %cond2043, label %bb_rcmoveslow502, label %bb_rcmovenext505
bb_rcmovenext505:
  %v2044 = load i64, ptr %slot295, align 8
  %v2045 = load i64, ptr %slot296, align 8
  %p2046 = inttoptr i64 %v2044 to ptr
  %p2047 = inttoptr i64 %v2045 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2047, ptr %p2046, i64 24, i1 false)
  %v2048 = load i64, ptr %slot295, align 8
  %p2049 = inttoptr i64 %v2048 to ptr
  store i64 0, ptr %p2049, align 8
  %v2050 = load i64, ptr %slot295, align 8
  %op2051 = add i64 %v2050, 8
  store i64 %op2051, ptr %slot305, align 8
  %v2052 = load i64, ptr %slot305, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  store i64 0, ptr %p2053, align 8
  %v2054 = load i64, ptr %slot295, align 8
  %op2055 = add i64 %v2054, 16
  store i64 %op2055, ptr %slot306, align 8
  %v2056 = load i64, ptr %slot306, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  store i64 0, ptr %p2057, align 8
  br label %bb_rcmoved502
bb_rcmoveslow502:
  %v2058 = load i64, ptr %slot36, align 8
  %v2059 = load i64, ptr %slot296, align 8
  %v2060 = load i64, ptr %slot295, align 8
  %v2061 = load i64, ptr %slot297, align 8
  %cv2062 = trunc i64 %v2061 to i32
  %call2063 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2058, i64 %v2059, i64 %v2060, i32 %cv2062) nomerge, !dbg !142
  store i32 %call2063, ptr %slot307, align 8
  %v2064 = load i32, ptr %slot307, align 8
  %cv2065 = zext i32 %v2064 to i64
  %cond2066 = icmp ne i64 %cv2065, 0
  br i1 %cond2066, label %bb_rcsuccess514, label %bb_rcfailure514
bb_rcfailure514:
  %v2067 = load i64, ptr %slot36, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  %call2069 = call i32 @myl_rc_take_failure(ptr %p2068) nomerge, !dbg !142
  store i32 %call2069, ptr %slot308, align 8
  %v2070 = load i64, ptr %slot1, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  %v2072 = load i32, ptr %slot308, align 8
  %call2073 = call i32 @myl_qbe_rc_status(ptr %p2071, i32 %v2072) nomerge, !dbg !142
  store i32 %call2073, ptr %slot309, align 8
  br label %bb_failure
bb_rcsuccess514:
  br label %bb_rcmoved502
bb_rcmoved502:
  %v2074 = load i64, ptr %slot6, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i32 0, ptr %p2075, align 4, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot10, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  store i32 2, ptr %p2077, align 4, !alias.scope !3, !noalias !4
  %v2078 = load i64, ptr %slot9, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  store i32 1, ptr %p2079, align 4, !alias.scope !3, !noalias !4
  %v2080 = load i64, ptr %slot14, align 8
  store i64 %v2080, ptr %slot310, align 8
  %v2081 = load i64, ptr %slot9, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i32 0, ptr %p2082, align 4, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot6, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  %ld2085 = load i32, ptr %p2084, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2085, ptr %slot311, align 8
  %v2086 = load i32, ptr %slot311, align 8
  %cv2087 = zext i32 %v2086 to i64
  %cond2088 = icmp ne i64 %cv2087, 0
  br i1 %cond2088, label %bb_rcslotdrop524, label %bb_rcslotdone524
bb_rcslotdrop524:
  %v2089 = load i64, ptr %slot6, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  store i32 0, ptr %p2090, align 4, !alias.scope !3, !noalias !4
  %v2091 = load i64, ptr %slot12, align 8
  store i64 %v2091, ptr %slot312, align 8
  %v2092 = load i64, ptr %slot7, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  %ld2094 = load i32, ptr %p2093, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2094, ptr %slot313, align 8
  %v2095 = load i32, ptr %slot313, align 8
  %op2096 = and i32 %v2095, 28
  store i32 %op2096, ptr %slot314, align 8
  %v2097 = load i32, ptr %slot314, align 8
  %cv2098 = zext i32 %v2097 to i64
  %cond2099 = icmp ne i64 %cv2098, 0
  br i1 %cond2099, label %bb_rcslotrole524, label %bb_rcslotowner524
bb_rcslotrole524:
  %v2100 = load i64, ptr %slot36, align 8
  store i64 %v2100, ptr %slot315, align 8
  %v2101 = load i64, ptr %slot315, align 8
  %v2102 = load i64, ptr %slot312, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2101, i64 %v2102) nomerge, !dbg !142
  br label %bb_rcslotdone524
bb_rcslotowner524:
  %v2103 = load i64, ptr %slot36, align 8
  store i64 %v2103, ptr %slot316, align 8
  %v2104 = load i64, ptr %slot316, align 8
  %v2105 = load i64, ptr %slot312, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2104, i64 %v2105) nomerge, !dbg !142
  br label %bb_rcslotdone524
bb_rcslotdone524:
  %v2106 = load i64, ptr %slot310, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2107, i64 24, i1 false)
  ret void
bb_i35:
  %v2108 = load i64, ptr %slot20, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  store i64 0, ptr %p2109, align 8, !alias.scope !3, !noalias !4
  %v2110 = load i64, ptr %slot20, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  %ld2112 = load i64, ptr %p2111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2112, ptr %slot317, align 8
  %v2113 = load i64, ptr %slot317, align 8
  %cond2114 = icmp ne i64 %v2113, 0
  br i1 %cond2114, label %bb_success587, label %bb_failed587
bb_failed587:
  %v2115 = load i64, ptr %slot1, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  call void @myl_qbe_fail_assert(ptr %p2116) nomerge, !dbg !144
  unreachable
bb_success587:
  %v2117 = load i64, ptr %slot20, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  store i64 18446744073709551615, ptr %p2118, align 8, !alias.scope !3, !noalias !4
  %v2119 = load i64, ptr %slot1, align 8
  %call2120 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v2119) nomerge, !dbg !146
  store { i64, i64 } %call2120, ptr %callresult319, align 8
  %addr2121 = ptrtoint ptr %callresult319 to i64
  store i64 %addr2121, ptr %slot318, align 8
  %v2122 = load i64, ptr %slot318, align 8
  %v2123 = load i64, ptr %slot21, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  store i64 %v2122, ptr %p2124, align 8, !alias.scope !3, !noalias !4
  %v2125 = load i64, ptr %slot21, align 8
  %p2126 = inttoptr i64 %v2125 to ptr
  %ld2127 = load i64, ptr %p2126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2127, ptr %slot320, align 8
  %v2128 = load i64, ptr %slot14, align 8
  store i64 %v2128, ptr %slot321, align 8
  %v2129 = load i64, ptr %slot320, align 8
  %v2130 = load i64, ptr %slot321, align 8
  %p2131 = inttoptr i64 %v2129 to ptr
  %p2132 = inttoptr i64 %v2130 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2132, ptr %p2131, i64 16, i1 false)
  %v2133 = load i64, ptr %slot10, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  store i32 2, ptr %p2134, align 4, !alias.scope !3, !noalias !4
  %v2135 = load i64, ptr %slot9, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  store i32 1, ptr %p2136, align 4, !alias.scope !3, !noalias !4
  %v2137 = load i64, ptr %slot13, align 8
  store i64 %v2137, ptr %slot322, align 8
  %v2138 = load i64, ptr %slot14, align 8
  store i64 %v2138, ptr %slot323, align 8
  %v2139 = load i64, ptr %slot323, align 8
  %v2140 = load i64, ptr %slot322, align 8
  %p2141 = inttoptr i64 %v2139 to ptr
  %p2142 = inttoptr i64 %v2140 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2142, ptr %p2141, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2143 = load i64, ptr %slot10, align 8
  %p2144 = inttoptr i64 %v2143 to ptr
  %ld2145 = load i32, ptr %p2144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2145, ptr %slot324, align 8
  %v2146 = load i64, ptr %slot9, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  store i32 0, ptr %p2147, align 4, !alias.scope !3, !noalias !4
  %v2148 = load i64, ptr %slot8, align 8
  %p2149 = inttoptr i64 %v2148 to ptr
  store i32 1, ptr %p2149, align 4, !alias.scope !3, !noalias !4
  %v2150 = load i64, ptr %slot322, align 8
  %v2151 = load i64, ptr %slot21, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i64 %v2150, ptr %p2152, align 8, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot24, align 8
  store i64 %v2153, ptr %slot325, align 8
  %v2154 = load i64, ptr %slot325, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  store i64 0, ptr %p2155, align 8, !alias.scope !3, !noalias !4
  %v2156 = load i64, ptr %slot325, align 8
  %p2158 = inttoptr i64 %v2156 to ptr
  %gep2159 = getelementptr i8, ptr %p2158, i64 8
  %op2157 = ptrtoint ptr %gep2159 to i64
  store i64 %op2157, ptr %slot326, align 8
  %v2160 = load i64, ptr %slot326, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  store i64 0, ptr %p2161, align 8, !alias.scope !3, !noalias !4
  %v2162 = load i64, ptr %slot325, align 8
  %p2164 = inttoptr i64 %v2162 to ptr
  %gep2165 = getelementptr i8, ptr %p2164, i64 16
  %op2163 = ptrtoint ptr %gep2165 to i64
  store i64 %op2163, ptr %slot327, align 8
  %v2166 = load i64, ptr %slot327, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  store i64 0, ptr %p2167, align 8, !alias.scope !3, !noalias !4
  %v2168 = load i64, ptr %slot11, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  store i32 1, ptr %p2169, align 4, !alias.scope !3, !noalias !4
  %v2170 = load i64, ptr %slot37, align 8
  store i64 %v2170, ptr %slot328, align 8
  %v2171 = load i64, ptr %slot20, align 8
  store i64 %v2171, ptr %slot329, align 8
  %v2172 = load i64, ptr %slot325, align 8
  %p2174 = inttoptr i64 %v2172 to ptr
  %gep2175 = getelementptr i8, ptr %p2174, i64 0
  %op2173 = ptrtoint ptr %gep2175 to i64
  store i64 %op2173, ptr %slot330, align 8
  %v2176 = load i64, ptr %slot329, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i64, ptr %p2177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2178, ptr %slot331, align 8
  %v2179 = load i64, ptr %slot331, align 8
  %v2180 = load i64, ptr %slot330, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i64 %v2179, ptr %p2181, align 8, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot21, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  %ld2184 = load i64, ptr %p2183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2184, ptr %slot332, align 8
  %v2185 = load i64, ptr %slot325, align 8
  %p2187 = inttoptr i64 %v2185 to ptr
  %gep2188 = getelementptr i8, ptr %p2187, i64 8
  %op2186 = ptrtoint ptr %gep2188 to i64
  store i64 %op2186, ptr %slot333, align 8
  %v2189 = load i64, ptr %slot21, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  %ld2191 = load i64, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2191, ptr %slot334, align 8
  %v2192 = load i64, ptr %slot14, align 8
  store i64 %v2192, ptr %slot335, align 8
  %v2193 = load i64, ptr %slot37, align 8
  store i64 %v2193, ptr %slot336, align 8
  %v2194 = load i64, ptr %slot334, align 8
  %op2195 = add i64 %v2194, 0
  store i64 %op2195, ptr %slot337, align 8
  %v2196 = load i64, ptr %slot337, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  %ld2198 = load i64, ptr %p2197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2198, ptr %slot338, align 8
  %v2199 = load i64, ptr %slot338, align 8
  %cmp2200 = icmp ne i64 %v2199, 0
  %cv2201 = zext i1 %cmp2200 to i32
  store i32 %cv2201, ptr %slot339, align 8
  %v2202 = load i32, ptr %slot339, align 8
  %cv2203 = zext i32 %v2202 to i64
  %cond2204 = icmp ne i64 %cv2203, 0
  br i1 %cond2204, label %bb_rcmoveheader618, label %bb_rcmovenext618
bb_rcmoveheader618:
  %v2205 = load i64, ptr %slot338, align 8
  %op2206 = sub i64 %v2205, 16
  store i64 %op2206, ptr %slot340, align 8
  %v2207 = load i64, ptr %slot338, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  %rgep2209 = getelementptr i8, ptr %p2208, i64 -16
  %ld2210 = load i64, ptr %rgep2209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2210, ptr %slot341, align 8
  %v2211 = load i64, ptr %slot341, align 8
  %op2212 = and i64 %v2211, 5764607523034234881
  store i64 %op2212, ptr %slot342, align 8
  %v2213 = load i64, ptr %slot342, align 8
  %cmp2214 = icmp ne i64 %v2213, 0
  %cv2215 = zext i1 %cmp2214 to i32
  store i32 %cv2215, ptr %slot343, align 8
  %v2216 = load i32, ptr %slot343, align 8
  %cv2217 = zext i32 %v2216 to i64
  %cond2218 = icmp ne i64 %cv2217, 0
  br i1 %cond2218, label %bb_rcmoveslow615, label %bb_rcmovenext618
bb_rcmovenext618:
  %v2219 = load i64, ptr %slot334, align 8
  %v2220 = load i64, ptr %slot335, align 8
  %p2221 = inttoptr i64 %v2219 to ptr
  %p2222 = inttoptr i64 %v2220 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2222, ptr %p2221, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2223 = load i64, ptr %slot334, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  store i64 0, ptr %p2224, align 8, !alias.scope !3, !noalias !4
  %v2225 = load i64, ptr %slot334, align 8
  %op2226 = add i64 %v2225, 8
  store i64 %op2226, ptr %slot344, align 8
  %v2227 = load i64, ptr %slot344, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  store i64 0, ptr %p2228, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved615
bb_rcmoveslow615:
  %v2229 = load i64, ptr %slot36, align 8
  %v2230 = load i64, ptr %slot335, align 8
  %v2231 = load i64, ptr %slot334, align 8
  %v2232 = load i64, ptr %slot336, align 8
  %cv2233 = trunc i64 %v2232 to i32
  %call2234 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v2229, i64 %v2230, i64 %v2231, i32 %cv2233) nomerge, !dbg !148
  store i32 %call2234, ptr %slot345, align 8
  %v2235 = load i32, ptr %slot345, align 8
  %cv2236 = zext i32 %v2235 to i64
  %cond2237 = icmp ne i64 %cv2236, 0
  br i1 %cond2237, label %bb_rcsuccess626, label %bb_rcfailure626
bb_rcfailure626:
  %v2238 = load i64, ptr %slot36, align 8
  %p2239 = inttoptr i64 %v2238 to ptr
  %call2240 = call i32 @myl_rc_take_failure(ptr %p2239) nomerge, !dbg !148
  store i32 %call2240, ptr %slot346, align 8
  %v2241 = load i64, ptr %slot1, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  %v2243 = load i32, ptr %slot346, align 8
  %call2244 = call i32 @myl_qbe_rc_status(ptr %p2242, i32 %v2243) nomerge, !dbg !148
  store i32 %call2244, ptr %slot347, align 8
  br label %bb_failure
bb_rcsuccess626:
  br label %bb_rcmoved615
bb_rcmoved615:
  %v2245 = load i64, ptr %slot8, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  store i32 0, ptr %p2246, align 4, !alias.scope !3, !noalias !4
  %v2247 = load i64, ptr %slot10, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  store i32 2, ptr %p2248, align 4, !alias.scope !3, !noalias !4
  %v2249 = load i64, ptr %slot9, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  store i32 1, ptr %p2250, align 4, !alias.scope !3, !noalias !4
  %v2251 = load i64, ptr %slot14, align 8
  store i64 %v2251, ptr %slot348, align 8
  %v2252 = load i64, ptr %slot348, align 8
  %v2253 = load i64, ptr %slot333, align 8
  %p2254 = inttoptr i64 %v2252 to ptr
  %p2255 = inttoptr i64 %v2253 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2255, ptr %p2254, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2256 = load i64, ptr %slot9, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  store i32 0, ptr %p2257, align 4, !alias.scope !3, !noalias !4
  %v2258 = load i64, ptr %slot325, align 8
  %v2259 = load i64, ptr %slot20, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  store i64 %v2258, ptr %p2260, align 8, !alias.scope !3, !noalias !4
  %v2261 = load i64, ptr %slot20, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  %ld2263 = load i64, ptr %p2262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2263, ptr %slot349, align 8
  %v2264 = load i64, ptr %slot12, align 8
  store i64 %v2264, ptr %slot350, align 8
  %v2265 = load i64, ptr %slot349, align 8
  %v2266 = load i64, ptr %slot350, align 8
  %p2267 = inttoptr i64 %v2265 to ptr
  %p2268 = inttoptr i64 %v2266 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2268, ptr %p2267, i64 24, i1 false)
  %v2269 = load i64, ptr %slot7, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  store i32 2, ptr %p2270, align 4, !alias.scope !3, !noalias !4
  %v2271 = load i64, ptr %slot6, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  store i32 1, ptr %p2272, align 4, !alias.scope !3, !noalias !4
  %v2273 = load i64, ptr %slot350, align 8
  %v2274 = load i64, ptr %slot20, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  store i64 %v2273, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  %v2276 = load i64, ptr %slot20, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %ld2278 = load i64, ptr %p2277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2278, ptr %slot351, align 8
  %v2279 = load i64, ptr %slot20, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  %ld2281 = load i64, ptr %p2280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2281, ptr %slot352, align 8
  %v2282 = load i64, ptr %slot14, align 8
  store i64 %v2282, ptr %slot353, align 8
  %v2283 = load i64, ptr %slot37, align 8
  store i64 %v2283, ptr %slot354, align 8
  %v2284 = load i64, ptr %slot352, align 8
  %op2285 = add i64 %v2284, 8
  store i64 %op2285, ptr %slot355, align 8
  %v2286 = load i64, ptr %slot355, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %ld2288 = load i64, ptr %p2287, align 8
  store i64 %ld2288, ptr %slot356, align 8
  %v2289 = load i64, ptr %slot356, align 8
  %cmp2290 = icmp ne i64 %v2289, 0
  %cv2291 = zext i1 %cmp2290 to i32
  store i32 %cv2291, ptr %slot357, align 8
  %v2292 = load i32, ptr %slot357, align 8
  %cv2293 = zext i32 %v2292 to i64
  %cond2294 = icmp ne i64 %cv2293, 0
  br i1 %cond2294, label %bb_rcmoveheader645, label %bb_rcmovenext645
bb_rcmoveheader645:
  %v2295 = load i64, ptr %slot356, align 8
  %op2296 = sub i64 %v2295, 16
  store i64 %op2296, ptr %slot358, align 8
  %v2297 = load i64, ptr %slot356, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  %rgep2299 = getelementptr i8, ptr %p2298, i64 -16
  %ld2300 = load i64, ptr %rgep2299, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2300, ptr %slot359, align 8
  %v2301 = load i64, ptr %slot359, align 8
  %op2302 = and i64 %v2301, 5764607523034234881
  store i64 %op2302, ptr %slot360, align 8
  %v2303 = load i64, ptr %slot360, align 8
  %cmp2304 = icmp ne i64 %v2303, 0
  %cv2305 = zext i1 %cmp2304 to i32
  store i32 %cv2305, ptr %slot361, align 8
  %v2306 = load i32, ptr %slot361, align 8
  %cv2307 = zext i32 %v2306 to i64
  %cond2308 = icmp ne i64 %cv2307, 0
  br i1 %cond2308, label %bb_rcmoveslow642, label %bb_rcmovenext645
bb_rcmovenext645:
  %v2309 = load i64, ptr %slot352, align 8
  %v2310 = load i64, ptr %slot353, align 8
  %p2311 = inttoptr i64 %v2309 to ptr
  %p2312 = inttoptr i64 %v2310 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2312, ptr %p2311, i64 24, i1 false)
  %v2313 = load i64, ptr %slot352, align 8
  %p2314 = inttoptr i64 %v2313 to ptr
  store i64 0, ptr %p2314, align 8
  %v2315 = load i64, ptr %slot352, align 8
  %op2316 = add i64 %v2315, 8
  store i64 %op2316, ptr %slot362, align 8
  %v2317 = load i64, ptr %slot362, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  store i64 0, ptr %p2318, align 8
  %v2319 = load i64, ptr %slot352, align 8
  %op2320 = add i64 %v2319, 16
  store i64 %op2320, ptr %slot363, align 8
  %v2321 = load i64, ptr %slot363, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  store i64 0, ptr %p2322, align 8
  br label %bb_rcmoved642
bb_rcmoveslow642:
  %v2323 = load i64, ptr %slot36, align 8
  %v2324 = load i64, ptr %slot353, align 8
  %v2325 = load i64, ptr %slot352, align 8
  %v2326 = load i64, ptr %slot354, align 8
  %cv2327 = trunc i64 %v2326 to i32
  %call2328 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2323, i64 %v2324, i64 %v2325, i32 %cv2327) nomerge, !dbg !150
  store i32 %call2328, ptr %slot364, align 8
  %v2329 = load i32, ptr %slot364, align 8
  %cv2330 = zext i32 %v2329 to i64
  %cond2331 = icmp ne i64 %cv2330, 0
  br i1 %cond2331, label %bb_rcsuccess654, label %bb_rcfailure654
bb_rcfailure654:
  %v2332 = load i64, ptr %slot36, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  %call2334 = call i32 @myl_rc_take_failure(ptr %p2333) nomerge, !dbg !150
  store i32 %call2334, ptr %slot365, align 8
  %v2335 = load i64, ptr %slot1, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  %v2337 = load i32, ptr %slot365, align 8
  %call2338 = call i32 @myl_qbe_rc_status(ptr %p2336, i32 %v2337) nomerge, !dbg !150
  store i32 %call2338, ptr %slot366, align 8
  br label %bb_failure
bb_rcsuccess654:
  br label %bb_rcmoved642
bb_rcmoved642:
  %v2339 = load i64, ptr %slot6, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  store i32 0, ptr %p2340, align 4, !alias.scope !3, !noalias !4
  %v2341 = load i64, ptr %slot10, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  store i32 2, ptr %p2342, align 4, !alias.scope !3, !noalias !4
  %v2343 = load i64, ptr %slot9, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  store i32 1, ptr %p2344, align 4, !alias.scope !3, !noalias !4
  %v2345 = load i64, ptr %slot14, align 8
  store i64 %v2345, ptr %slot367, align 8
  %v2346 = load i64, ptr %slot9, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  store i32 0, ptr %p2347, align 4, !alias.scope !3, !noalias !4
  %v2348 = load i64, ptr %slot6, align 8
  %p2349 = inttoptr i64 %v2348 to ptr
  %ld2350 = load i32, ptr %p2349, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2350, ptr %slot368, align 8
  %v2351 = load i32, ptr %slot368, align 8
  %cv2352 = zext i32 %v2351 to i64
  %cond2353 = icmp ne i64 %cv2352, 0
  br i1 %cond2353, label %bb_rcslotdrop664, label %bb_rcslotdone664
bb_rcslotdrop664:
  %v2354 = load i64, ptr %slot6, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  store i32 0, ptr %p2355, align 4, !alias.scope !3, !noalias !4
  %v2356 = load i64, ptr %slot12, align 8
  store i64 %v2356, ptr %slot369, align 8
  %v2357 = load i64, ptr %slot7, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %ld2359 = load i32, ptr %p2358, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2359, ptr %slot370, align 8
  %v2360 = load i32, ptr %slot370, align 8
  %op2361 = and i32 %v2360, 28
  store i32 %op2361, ptr %slot371, align 8
  %v2362 = load i32, ptr %slot371, align 8
  %cv2363 = zext i32 %v2362 to i64
  %cond2364 = icmp ne i64 %cv2363, 0
  br i1 %cond2364, label %bb_rcslotrole664, label %bb_rcslotowner664
bb_rcslotrole664:
  %v2365 = load i64, ptr %slot36, align 8
  store i64 %v2365, ptr %slot372, align 8
  %v2366 = load i64, ptr %slot372, align 8
  %v2367 = load i64, ptr %slot369, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2366, i64 %v2367) nomerge, !dbg !150
  br label %bb_rcslotdone664
bb_rcslotowner664:
  %v2368 = load i64, ptr %slot36, align 8
  store i64 %v2368, ptr %slot373, align 8
  %v2369 = load i64, ptr %slot373, align 8
  %v2370 = load i64, ptr %slot369, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2369, i64 %v2370) nomerge, !dbg !150
  br label %bb_rcslotdone664
bb_rcslotdone664:
  %v2371 = load i64, ptr %slot367, align 8
  %p2372 = inttoptr i64 %v2371 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2372, i64 24, i1 false)
  ret void
bb_i41:
  %v2373 = load i64, ptr %slot20, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  store i64 0, ptr %p2374, align 8, !alias.scope !3, !noalias !4
  %v2375 = load i64, ptr %slot20, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  %ld2377 = load i64, ptr %p2376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2377, ptr %slot374, align 8
  %v2378 = load i64, ptr %slot374, align 8
  %cond2379 = icmp ne i64 %v2378, 0
  br i1 %cond2379, label %bb_success727, label %bb_failed727
bb_failed727:
  %v2380 = load i64, ptr %slot1, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  call void @myl_qbe_fail_assert(ptr %p2381) nomerge, !dbg !152
  unreachable
bb_success727:
  %v2382 = load i64, ptr %slot20, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  store i64 18446744073709551615, ptr %p2383, align 8, !alias.scope !3, !noalias !4
  %v2384 = load i64, ptr %slot1, align 8
  %call2385 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v2384) nomerge, !dbg !154
  store { i64, i64 } %call2385, ptr %callresult376, align 8
  %addr2386 = ptrtoint ptr %callresult376 to i64
  store i64 %addr2386, ptr %slot375, align 8
  %v2387 = load i64, ptr %slot375, align 8
  %v2388 = load i64, ptr %slot21, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  store i64 %v2387, ptr %p2389, align 8, !alias.scope !3, !noalias !4
  %v2390 = load i64, ptr %slot21, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  %ld2392 = load i64, ptr %p2391, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2392, ptr %slot377, align 8
  %v2393 = load i64, ptr %slot14, align 8
  store i64 %v2393, ptr %slot378, align 8
  %v2394 = load i64, ptr %slot377, align 8
  %v2395 = load i64, ptr %slot378, align 8
  %p2396 = inttoptr i64 %v2394 to ptr
  %p2397 = inttoptr i64 %v2395 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2397, ptr %p2396, i64 16, i1 false)
  %v2398 = load i64, ptr %slot10, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i32 2, ptr %p2399, align 4, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot9, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  store i32 1, ptr %p2401, align 4, !alias.scope !3, !noalias !4
  %v2402 = load i64, ptr %slot13, align 8
  store i64 %v2402, ptr %slot379, align 8
  %v2403 = load i64, ptr %slot14, align 8
  store i64 %v2403, ptr %slot380, align 8
  %v2404 = load i64, ptr %slot380, align 8
  %v2405 = load i64, ptr %slot379, align 8
  %p2406 = inttoptr i64 %v2404 to ptr
  %p2407 = inttoptr i64 %v2405 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2407, ptr %p2406, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2408 = load i64, ptr %slot10, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  %ld2410 = load i32, ptr %p2409, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2410, ptr %slot381, align 8
  %v2411 = load i64, ptr %slot9, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  store i32 0, ptr %p2412, align 4, !alias.scope !3, !noalias !4
  %v2413 = load i64, ptr %slot8, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  store i32 1, ptr %p2414, align 4, !alias.scope !3, !noalias !4
  %v2415 = load i64, ptr %slot379, align 8
  %v2416 = load i64, ptr %slot21, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  store i64 %v2415, ptr %p2417, align 8, !alias.scope !3, !noalias !4
  %v2418 = load i64, ptr %slot25, align 8
  store i64 %v2418, ptr %slot382, align 8
  %v2419 = load i64, ptr %slot382, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  store i64 0, ptr %p2420, align 8, !alias.scope !3, !noalias !4
  %v2421 = load i64, ptr %slot382, align 8
  %p2423 = inttoptr i64 %v2421 to ptr
  %gep2424 = getelementptr i8, ptr %p2423, i64 8
  %op2422 = ptrtoint ptr %gep2424 to i64
  store i64 %op2422, ptr %slot383, align 8
  %v2425 = load i64, ptr %slot383, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  store i64 0, ptr %p2426, align 8, !alias.scope !3, !noalias !4
  %v2427 = load i64, ptr %slot382, align 8
  %p2429 = inttoptr i64 %v2427 to ptr
  %gep2430 = getelementptr i8, ptr %p2429, i64 16
  %op2428 = ptrtoint ptr %gep2430 to i64
  store i64 %op2428, ptr %slot384, align 8
  %v2431 = load i64, ptr %slot384, align 8
  %p2432 = inttoptr i64 %v2431 to ptr
  store i64 0, ptr %p2432, align 8, !alias.scope !3, !noalias !4
  %v2433 = load i64, ptr %slot11, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  store i32 1, ptr %p2434, align 4, !alias.scope !3, !noalias !4
  %v2435 = load i64, ptr %slot37, align 8
  store i64 %v2435, ptr %slot385, align 8
  %v2436 = load i64, ptr %slot20, align 8
  store i64 %v2436, ptr %slot386, align 8
  %v2437 = load i64, ptr %slot382, align 8
  %p2439 = inttoptr i64 %v2437 to ptr
  %gep2440 = getelementptr i8, ptr %p2439, i64 0
  %op2438 = ptrtoint ptr %gep2440 to i64
  store i64 %op2438, ptr %slot387, align 8
  %v2441 = load i64, ptr %slot386, align 8
  %p2442 = inttoptr i64 %v2441 to ptr
  %ld2443 = load i64, ptr %p2442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2443, ptr %slot388, align 8
  %v2444 = load i64, ptr %slot388, align 8
  %v2445 = load i64, ptr %slot387, align 8
  %p2446 = inttoptr i64 %v2445 to ptr
  store i64 %v2444, ptr %p2446, align 8, !alias.scope !3, !noalias !4
  %v2447 = load i64, ptr %slot21, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  %ld2449 = load i64, ptr %p2448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2449, ptr %slot389, align 8
  %v2450 = load i64, ptr %slot382, align 8
  %p2452 = inttoptr i64 %v2450 to ptr
  %gep2453 = getelementptr i8, ptr %p2452, i64 8
  %op2451 = ptrtoint ptr %gep2453 to i64
  store i64 %op2451, ptr %slot390, align 8
  %v2454 = load i64, ptr %slot21, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %ld2456 = load i64, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2456, ptr %slot391, align 8
  %v2457 = load i64, ptr %slot14, align 8
  store i64 %v2457, ptr %slot392, align 8
  %v2458 = load i64, ptr %slot37, align 8
  store i64 %v2458, ptr %slot393, align 8
  %v2459 = load i64, ptr %slot391, align 8
  %op2460 = add i64 %v2459, 0
  store i64 %op2460, ptr %slot394, align 8
  %v2461 = load i64, ptr %slot394, align 8
  %p2462 = inttoptr i64 %v2461 to ptr
  %ld2463 = load i64, ptr %p2462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2463, ptr %slot395, align 8
  %v2464 = load i64, ptr %slot395, align 8
  %cmp2465 = icmp ne i64 %v2464, 0
  %cv2466 = zext i1 %cmp2465 to i32
  store i32 %cv2466, ptr %slot396, align 8
  %v2467 = load i32, ptr %slot396, align 8
  %cv2468 = zext i32 %v2467 to i64
  %cond2469 = icmp ne i64 %cv2468, 0
  br i1 %cond2469, label %bb_rcmoveheader758, label %bb_rcmovenext758
bb_rcmoveheader758:
  %v2470 = load i64, ptr %slot395, align 8
  %op2471 = sub i64 %v2470, 16
  store i64 %op2471, ptr %slot397, align 8
  %v2472 = load i64, ptr %slot395, align 8
  %p2473 = inttoptr i64 %v2472 to ptr
  %rgep2474 = getelementptr i8, ptr %p2473, i64 -16
  %ld2475 = load i64, ptr %rgep2474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2475, ptr %slot398, align 8
  %v2476 = load i64, ptr %slot398, align 8
  %op2477 = and i64 %v2476, 5764607523034234881
  store i64 %op2477, ptr %slot399, align 8
  %v2478 = load i64, ptr %slot399, align 8
  %cmp2479 = icmp ne i64 %v2478, 0
  %cv2480 = zext i1 %cmp2479 to i32
  store i32 %cv2480, ptr %slot400, align 8
  %v2481 = load i32, ptr %slot400, align 8
  %cv2482 = zext i32 %v2481 to i64
  %cond2483 = icmp ne i64 %cv2482, 0
  br i1 %cond2483, label %bb_rcmoveslow755, label %bb_rcmovenext758
bb_rcmovenext758:
  %v2484 = load i64, ptr %slot391, align 8
  %v2485 = load i64, ptr %slot392, align 8
  %p2486 = inttoptr i64 %v2484 to ptr
  %p2487 = inttoptr i64 %v2485 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2487, ptr %p2486, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2488 = load i64, ptr %slot391, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  store i64 0, ptr %p2489, align 8, !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot391, align 8
  %op2491 = add i64 %v2490, 8
  store i64 %op2491, ptr %slot401, align 8
  %v2492 = load i64, ptr %slot401, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  store i64 0, ptr %p2493, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved755
bb_rcmoveslow755:
  %v2494 = load i64, ptr %slot36, align 8
  %v2495 = load i64, ptr %slot392, align 8
  %v2496 = load i64, ptr %slot391, align 8
  %v2497 = load i64, ptr %slot393, align 8
  %cv2498 = trunc i64 %v2497 to i32
  %call2499 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v2494, i64 %v2495, i64 %v2496, i32 %cv2498) nomerge, !dbg !156
  store i32 %call2499, ptr %slot402, align 8
  %v2500 = load i32, ptr %slot402, align 8
  %cv2501 = zext i32 %v2500 to i64
  %cond2502 = icmp ne i64 %cv2501, 0
  br i1 %cond2502, label %bb_rcsuccess766, label %bb_rcfailure766
bb_rcfailure766:
  %v2503 = load i64, ptr %slot36, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  %call2505 = call i32 @myl_rc_take_failure(ptr %p2504) nomerge, !dbg !156
  store i32 %call2505, ptr %slot403, align 8
  %v2506 = load i64, ptr %slot1, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  %v2508 = load i32, ptr %slot403, align 8
  %call2509 = call i32 @myl_qbe_rc_status(ptr %p2507, i32 %v2508) nomerge, !dbg !156
  store i32 %call2509, ptr %slot404, align 8
  br label %bb_failure
bb_rcsuccess766:
  br label %bb_rcmoved755
bb_rcmoved755:
  %v2510 = load i64, ptr %slot8, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  store i32 0, ptr %p2511, align 4, !alias.scope !3, !noalias !4
  %v2512 = load i64, ptr %slot10, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  store i32 2, ptr %p2513, align 4, !alias.scope !3, !noalias !4
  %v2514 = load i64, ptr %slot9, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  store i32 1, ptr %p2515, align 4, !alias.scope !3, !noalias !4
  %v2516 = load i64, ptr %slot14, align 8
  store i64 %v2516, ptr %slot405, align 8
  %v2517 = load i64, ptr %slot405, align 8
  %v2518 = load i64, ptr %slot390, align 8
  %p2519 = inttoptr i64 %v2517 to ptr
  %p2520 = inttoptr i64 %v2518 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2520, ptr %p2519, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot9, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i32 0, ptr %p2522, align 4, !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot382, align 8
  %v2524 = load i64, ptr %slot20, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  store i64 %v2523, ptr %p2525, align 8, !alias.scope !3, !noalias !4
  %v2526 = load i64, ptr %slot20, align 8
  %p2527 = inttoptr i64 %v2526 to ptr
  %ld2528 = load i64, ptr %p2527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2528, ptr %slot406, align 8
  %v2529 = load i64, ptr %slot12, align 8
  store i64 %v2529, ptr %slot407, align 8
  %v2530 = load i64, ptr %slot406, align 8
  %v2531 = load i64, ptr %slot407, align 8
  %p2532 = inttoptr i64 %v2530 to ptr
  %p2533 = inttoptr i64 %v2531 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2533, ptr %p2532, i64 24, i1 false)
  %v2534 = load i64, ptr %slot7, align 8
  %p2535 = inttoptr i64 %v2534 to ptr
  store i32 2, ptr %p2535, align 4, !alias.scope !3, !noalias !4
  %v2536 = load i64, ptr %slot6, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  store i32 1, ptr %p2537, align 4, !alias.scope !3, !noalias !4
  %v2538 = load i64, ptr %slot407, align 8
  %v2539 = load i64, ptr %slot20, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  store i64 %v2538, ptr %p2540, align 8, !alias.scope !3, !noalias !4
  %v2541 = load i64, ptr %slot20, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  %ld2543 = load i64, ptr %p2542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2543, ptr %slot408, align 8
  %v2544 = load i64, ptr %slot20, align 8
  %p2545 = inttoptr i64 %v2544 to ptr
  %ld2546 = load i64, ptr %p2545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2546, ptr %slot409, align 8
  %v2547 = load i64, ptr %slot14, align 8
  store i64 %v2547, ptr %slot410, align 8
  %v2548 = load i64, ptr %slot37, align 8
  store i64 %v2548, ptr %slot411, align 8
  %v2549 = load i64, ptr %slot409, align 8
  %op2550 = add i64 %v2549, 8
  store i64 %op2550, ptr %slot412, align 8
  %v2551 = load i64, ptr %slot412, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %ld2553 = load i64, ptr %p2552, align 8
  store i64 %ld2553, ptr %slot413, align 8
  %v2554 = load i64, ptr %slot413, align 8
  %cmp2555 = icmp ne i64 %v2554, 0
  %cv2556 = zext i1 %cmp2555 to i32
  store i32 %cv2556, ptr %slot414, align 8
  %v2557 = load i32, ptr %slot414, align 8
  %cv2558 = zext i32 %v2557 to i64
  %cond2559 = icmp ne i64 %cv2558, 0
  br i1 %cond2559, label %bb_rcmoveheader785, label %bb_rcmovenext785
bb_rcmoveheader785:
  %v2560 = load i64, ptr %slot413, align 8
  %op2561 = sub i64 %v2560, 16
  store i64 %op2561, ptr %slot415, align 8
  %v2562 = load i64, ptr %slot413, align 8
  %p2563 = inttoptr i64 %v2562 to ptr
  %rgep2564 = getelementptr i8, ptr %p2563, i64 -16
  %ld2565 = load i64, ptr %rgep2564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2565, ptr %slot416, align 8
  %v2566 = load i64, ptr %slot416, align 8
  %op2567 = and i64 %v2566, 5764607523034234881
  store i64 %op2567, ptr %slot417, align 8
  %v2568 = load i64, ptr %slot417, align 8
  %cmp2569 = icmp ne i64 %v2568, 0
  %cv2570 = zext i1 %cmp2569 to i32
  store i32 %cv2570, ptr %slot418, align 8
  %v2571 = load i32, ptr %slot418, align 8
  %cv2572 = zext i32 %v2571 to i64
  %cond2573 = icmp ne i64 %cv2572, 0
  br i1 %cond2573, label %bb_rcmoveslow782, label %bb_rcmovenext785
bb_rcmovenext785:
  %v2574 = load i64, ptr %slot409, align 8
  %v2575 = load i64, ptr %slot410, align 8
  %p2576 = inttoptr i64 %v2574 to ptr
  %p2577 = inttoptr i64 %v2575 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2577, ptr %p2576, i64 24, i1 false)
  %v2578 = load i64, ptr %slot409, align 8
  %p2579 = inttoptr i64 %v2578 to ptr
  store i64 0, ptr %p2579, align 8
  %v2580 = load i64, ptr %slot409, align 8
  %op2581 = add i64 %v2580, 8
  store i64 %op2581, ptr %slot419, align 8
  %v2582 = load i64, ptr %slot419, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  store i64 0, ptr %p2583, align 8
  %v2584 = load i64, ptr %slot409, align 8
  %op2585 = add i64 %v2584, 16
  store i64 %op2585, ptr %slot420, align 8
  %v2586 = load i64, ptr %slot420, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  store i64 0, ptr %p2587, align 8
  br label %bb_rcmoved782
bb_rcmoveslow782:
  %v2588 = load i64, ptr %slot36, align 8
  %v2589 = load i64, ptr %slot410, align 8
  %v2590 = load i64, ptr %slot409, align 8
  %v2591 = load i64, ptr %slot411, align 8
  %cv2592 = trunc i64 %v2591 to i32
  %call2593 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2588, i64 %v2589, i64 %v2590, i32 %cv2592) nomerge, !dbg !158
  store i32 %call2593, ptr %slot421, align 8
  %v2594 = load i32, ptr %slot421, align 8
  %cv2595 = zext i32 %v2594 to i64
  %cond2596 = icmp ne i64 %cv2595, 0
  br i1 %cond2596, label %bb_rcsuccess794, label %bb_rcfailure794
bb_rcfailure794:
  %v2597 = load i64, ptr %slot36, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  %call2599 = call i32 @myl_rc_take_failure(ptr %p2598) nomerge, !dbg !158
  store i32 %call2599, ptr %slot422, align 8
  %v2600 = load i64, ptr %slot1, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  %v2602 = load i32, ptr %slot422, align 8
  %call2603 = call i32 @myl_qbe_rc_status(ptr %p2601, i32 %v2602) nomerge, !dbg !158
  store i32 %call2603, ptr %slot423, align 8
  br label %bb_failure
bb_rcsuccess794:
  br label %bb_rcmoved782
bb_rcmoved782:
  %v2604 = load i64, ptr %slot6, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  store i32 0, ptr %p2605, align 4, !alias.scope !3, !noalias !4
  %v2606 = load i64, ptr %slot10, align 8
  %p2607 = inttoptr i64 %v2606 to ptr
  store i32 2, ptr %p2607, align 4, !alias.scope !3, !noalias !4
  %v2608 = load i64, ptr %slot9, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  store i32 1, ptr %p2609, align 4, !alias.scope !3, !noalias !4
  %v2610 = load i64, ptr %slot14, align 8
  store i64 %v2610, ptr %slot424, align 8
  %v2611 = load i64, ptr %slot9, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  store i32 0, ptr %p2612, align 4, !alias.scope !3, !noalias !4
  %v2613 = load i64, ptr %slot6, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  %ld2615 = load i32, ptr %p2614, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2615, ptr %slot425, align 8
  %v2616 = load i32, ptr %slot425, align 8
  %cv2617 = zext i32 %v2616 to i64
  %cond2618 = icmp ne i64 %cv2617, 0
  br i1 %cond2618, label %bb_rcslotdrop804, label %bb_rcslotdone804
bb_rcslotdrop804:
  %v2619 = load i64, ptr %slot6, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  store i32 0, ptr %p2620, align 4, !alias.scope !3, !noalias !4
  %v2621 = load i64, ptr %slot12, align 8
  store i64 %v2621, ptr %slot426, align 8
  %v2622 = load i64, ptr %slot7, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  %ld2624 = load i32, ptr %p2623, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2624, ptr %slot427, align 8
  %v2625 = load i32, ptr %slot427, align 8
  %op2626 = and i32 %v2625, 28
  store i32 %op2626, ptr %slot428, align 8
  %v2627 = load i32, ptr %slot428, align 8
  %cv2628 = zext i32 %v2627 to i64
  %cond2629 = icmp ne i64 %cv2628, 0
  br i1 %cond2629, label %bb_rcslotrole804, label %bb_rcslotowner804
bb_rcslotrole804:
  %v2630 = load i64, ptr %slot36, align 8
  store i64 %v2630, ptr %slot429, align 8
  %v2631 = load i64, ptr %slot429, align 8
  %v2632 = load i64, ptr %slot426, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2631, i64 %v2632) nomerge, !dbg !158
  br label %bb_rcslotdone804
bb_rcslotowner804:
  %v2633 = load i64, ptr %slot36, align 8
  store i64 %v2633, ptr %slot430, align 8
  %v2634 = load i64, ptr %slot430, align 8
  %v2635 = load i64, ptr %slot426, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2634, i64 %v2635) nomerge, !dbg !158
  br label %bb_rcslotdone804
bb_rcslotdone804:
  %v2636 = load i64, ptr %slot424, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2637, i64 24, i1 false)
  ret void
bb_i47:
  %v2638 = load i64, ptr %slot20, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  store i64 0, ptr %p2639, align 8, !alias.scope !3, !noalias !4
  %v2640 = load i64, ptr %slot20, align 8
  %p2641 = inttoptr i64 %v2640 to ptr
  %ld2642 = load i64, ptr %p2641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2642, ptr %slot431, align 8
  %v2643 = load i64, ptr %slot431, align 8
  %cond2644 = icmp ne i64 %v2643, 0
  br i1 %cond2644, label %bb_success867, label %bb_failed867
bb_failed867:
  %v2645 = load i64, ptr %slot1, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  call void @myl_qbe_fail_assert(ptr %p2646) nomerge, !dbg !160
  unreachable
bb_success867:
  %v2647 = load i64, ptr %slot20, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  store i64 18446744073709551615, ptr %p2648, align 8, !alias.scope !3, !noalias !4
  %v2649 = load i64, ptr %slot1, align 8
  %call2650 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v2649) nomerge, !dbg !162
  store { i64, i64 } %call2650, ptr %callresult433, align 8
  %addr2651 = ptrtoint ptr %callresult433 to i64
  store i64 %addr2651, ptr %slot432, align 8
  %v2652 = load i64, ptr %slot432, align 8
  %v2653 = load i64, ptr %slot21, align 8
  %p2654 = inttoptr i64 %v2653 to ptr
  store i64 %v2652, ptr %p2654, align 8, !alias.scope !3, !noalias !4
  %v2655 = load i64, ptr %slot21, align 8
  %p2656 = inttoptr i64 %v2655 to ptr
  %ld2657 = load i64, ptr %p2656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2657, ptr %slot434, align 8
  %v2658 = load i64, ptr %slot14, align 8
  store i64 %v2658, ptr %slot435, align 8
  %v2659 = load i64, ptr %slot434, align 8
  %v2660 = load i64, ptr %slot435, align 8
  %p2661 = inttoptr i64 %v2659 to ptr
  %p2662 = inttoptr i64 %v2660 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2662, ptr %p2661, i64 16, i1 false)
  %v2663 = load i64, ptr %slot10, align 8
  %p2664 = inttoptr i64 %v2663 to ptr
  store i32 2, ptr %p2664, align 4, !alias.scope !3, !noalias !4
  %v2665 = load i64, ptr %slot9, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  store i32 1, ptr %p2666, align 4, !alias.scope !3, !noalias !4
  %v2667 = load i64, ptr %slot13, align 8
  store i64 %v2667, ptr %slot436, align 8
  %v2668 = load i64, ptr %slot14, align 8
  store i64 %v2668, ptr %slot437, align 8
  %v2669 = load i64, ptr %slot437, align 8
  %v2670 = load i64, ptr %slot436, align 8
  %p2671 = inttoptr i64 %v2669 to ptr
  %p2672 = inttoptr i64 %v2670 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2672, ptr %p2671, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2673 = load i64, ptr %slot10, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  %ld2675 = load i32, ptr %p2674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2675, ptr %slot438, align 8
  %v2676 = load i64, ptr %slot9, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i32 0, ptr %p2677, align 4, !alias.scope !3, !noalias !4
  %v2678 = load i64, ptr %slot8, align 8
  %p2679 = inttoptr i64 %v2678 to ptr
  store i32 1, ptr %p2679, align 4, !alias.scope !3, !noalias !4
  %v2680 = load i64, ptr %slot436, align 8
  %v2681 = load i64, ptr %slot21, align 8
  %p2682 = inttoptr i64 %v2681 to ptr
  store i64 %v2680, ptr %p2682, align 8, !alias.scope !3, !noalias !4
  %v2683 = load i64, ptr %slot26, align 8
  store i64 %v2683, ptr %slot439, align 8
  %v2684 = load i64, ptr %slot439, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  store i64 0, ptr %p2685, align 8, !alias.scope !3, !noalias !4
  %v2686 = load i64, ptr %slot439, align 8
  %p2688 = inttoptr i64 %v2686 to ptr
  %gep2689 = getelementptr i8, ptr %p2688, i64 8
  %op2687 = ptrtoint ptr %gep2689 to i64
  store i64 %op2687, ptr %slot440, align 8
  %v2690 = load i64, ptr %slot440, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  store i64 0, ptr %p2691, align 8, !alias.scope !3, !noalias !4
  %v2692 = load i64, ptr %slot439, align 8
  %p2694 = inttoptr i64 %v2692 to ptr
  %gep2695 = getelementptr i8, ptr %p2694, i64 16
  %op2693 = ptrtoint ptr %gep2695 to i64
  store i64 %op2693, ptr %slot441, align 8
  %v2696 = load i64, ptr %slot441, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  store i64 0, ptr %p2697, align 8, !alias.scope !3, !noalias !4
  %v2698 = load i64, ptr %slot11, align 8
  %p2699 = inttoptr i64 %v2698 to ptr
  store i32 1, ptr %p2699, align 4, !alias.scope !3, !noalias !4
  %v2700 = load i64, ptr %slot37, align 8
  store i64 %v2700, ptr %slot442, align 8
  %v2701 = load i64, ptr %slot20, align 8
  store i64 %v2701, ptr %slot443, align 8
  %v2702 = load i64, ptr %slot439, align 8
  %p2704 = inttoptr i64 %v2702 to ptr
  %gep2705 = getelementptr i8, ptr %p2704, i64 0
  %op2703 = ptrtoint ptr %gep2705 to i64
  store i64 %op2703, ptr %slot444, align 8
  %v2706 = load i64, ptr %slot443, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  %ld2708 = load i64, ptr %p2707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2708, ptr %slot445, align 8
  %v2709 = load i64, ptr %slot445, align 8
  %v2710 = load i64, ptr %slot444, align 8
  %p2711 = inttoptr i64 %v2710 to ptr
  store i64 %v2709, ptr %p2711, align 8, !alias.scope !3, !noalias !4
  %v2712 = load i64, ptr %slot21, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  %ld2714 = load i64, ptr %p2713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2714, ptr %slot446, align 8
  %v2715 = load i64, ptr %slot439, align 8
  %p2717 = inttoptr i64 %v2715 to ptr
  %gep2718 = getelementptr i8, ptr %p2717, i64 8
  %op2716 = ptrtoint ptr %gep2718 to i64
  store i64 %op2716, ptr %slot447, align 8
  %v2719 = load i64, ptr %slot21, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %ld2721 = load i64, ptr %p2720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2721, ptr %slot448, align 8
  %v2722 = load i64, ptr %slot14, align 8
  store i64 %v2722, ptr %slot449, align 8
  %v2723 = load i64, ptr %slot37, align 8
  store i64 %v2723, ptr %slot450, align 8
  %v2724 = load i64, ptr %slot448, align 8
  %op2725 = add i64 %v2724, 0
  store i64 %op2725, ptr %slot451, align 8
  %v2726 = load i64, ptr %slot451, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  %ld2728 = load i64, ptr %p2727, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2728, ptr %slot452, align 8
  %v2729 = load i64, ptr %slot452, align 8
  %cmp2730 = icmp ne i64 %v2729, 0
  %cv2731 = zext i1 %cmp2730 to i32
  store i32 %cv2731, ptr %slot453, align 8
  %v2732 = load i32, ptr %slot453, align 8
  %cv2733 = zext i32 %v2732 to i64
  %cond2734 = icmp ne i64 %cv2733, 0
  br i1 %cond2734, label %bb_rcmoveheader898, label %bb_rcmovenext898
bb_rcmoveheader898:
  %v2735 = load i64, ptr %slot452, align 8
  %op2736 = sub i64 %v2735, 16
  store i64 %op2736, ptr %slot454, align 8
  %v2737 = load i64, ptr %slot452, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  %rgep2739 = getelementptr i8, ptr %p2738, i64 -16
  %ld2740 = load i64, ptr %rgep2739, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2740, ptr %slot455, align 8
  %v2741 = load i64, ptr %slot455, align 8
  %op2742 = and i64 %v2741, 5764607523034234881
  store i64 %op2742, ptr %slot456, align 8
  %v2743 = load i64, ptr %slot456, align 8
  %cmp2744 = icmp ne i64 %v2743, 0
  %cv2745 = zext i1 %cmp2744 to i32
  store i32 %cv2745, ptr %slot457, align 8
  %v2746 = load i32, ptr %slot457, align 8
  %cv2747 = zext i32 %v2746 to i64
  %cond2748 = icmp ne i64 %cv2747, 0
  br i1 %cond2748, label %bb_rcmoveslow895, label %bb_rcmovenext898
bb_rcmovenext898:
  %v2749 = load i64, ptr %slot448, align 8
  %v2750 = load i64, ptr %slot449, align 8
  %p2751 = inttoptr i64 %v2749 to ptr
  %p2752 = inttoptr i64 %v2750 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2752, ptr %p2751, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2753 = load i64, ptr %slot448, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  store i64 0, ptr %p2754, align 8, !alias.scope !3, !noalias !4
  %v2755 = load i64, ptr %slot448, align 8
  %op2756 = add i64 %v2755, 8
  store i64 %op2756, ptr %slot458, align 8
  %v2757 = load i64, ptr %slot458, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  store i64 0, ptr %p2758, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved895
bb_rcmoveslow895:
  %v2759 = load i64, ptr %slot36, align 8
  %v2760 = load i64, ptr %slot449, align 8
  %v2761 = load i64, ptr %slot448, align 8
  %v2762 = load i64, ptr %slot450, align 8
  %cv2763 = trunc i64 %v2762 to i32
  %call2764 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v2759, i64 %v2760, i64 %v2761, i32 %cv2763) nomerge, !dbg !164
  store i32 %call2764, ptr %slot459, align 8
  %v2765 = load i32, ptr %slot459, align 8
  %cv2766 = zext i32 %v2765 to i64
  %cond2767 = icmp ne i64 %cv2766, 0
  br i1 %cond2767, label %bb_rcsuccess906, label %bb_rcfailure906
bb_rcfailure906:
  %v2768 = load i64, ptr %slot36, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  %call2770 = call i32 @myl_rc_take_failure(ptr %p2769) nomerge, !dbg !164
  store i32 %call2770, ptr %slot460, align 8
  %v2771 = load i64, ptr %slot1, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  %v2773 = load i32, ptr %slot460, align 8
  %call2774 = call i32 @myl_qbe_rc_status(ptr %p2772, i32 %v2773) nomerge, !dbg !164
  store i32 %call2774, ptr %slot461, align 8
  br label %bb_failure
bb_rcsuccess906:
  br label %bb_rcmoved895
bb_rcmoved895:
  %v2775 = load i64, ptr %slot8, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  store i32 0, ptr %p2776, align 4, !alias.scope !3, !noalias !4
  %v2777 = load i64, ptr %slot10, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  store i32 2, ptr %p2778, align 4, !alias.scope !3, !noalias !4
  %v2779 = load i64, ptr %slot9, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  store i32 1, ptr %p2780, align 4, !alias.scope !3, !noalias !4
  %v2781 = load i64, ptr %slot14, align 8
  store i64 %v2781, ptr %slot462, align 8
  %v2782 = load i64, ptr %slot462, align 8
  %v2783 = load i64, ptr %slot447, align 8
  %p2784 = inttoptr i64 %v2782 to ptr
  %p2785 = inttoptr i64 %v2783 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2785, ptr %p2784, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2786 = load i64, ptr %slot9, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  store i32 0, ptr %p2787, align 4, !alias.scope !3, !noalias !4
  %v2788 = load i64, ptr %slot439, align 8
  %v2789 = load i64, ptr %slot20, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  store i64 %v2788, ptr %p2790, align 8, !alias.scope !3, !noalias !4
  %v2791 = load i64, ptr %slot20, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %ld2793 = load i64, ptr %p2792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2793, ptr %slot463, align 8
  %v2794 = load i64, ptr %slot12, align 8
  store i64 %v2794, ptr %slot464, align 8
  %v2795 = load i64, ptr %slot463, align 8
  %v2796 = load i64, ptr %slot464, align 8
  %p2797 = inttoptr i64 %v2795 to ptr
  %p2798 = inttoptr i64 %v2796 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2798, ptr %p2797, i64 24, i1 false)
  %v2799 = load i64, ptr %slot7, align 8
  %p2800 = inttoptr i64 %v2799 to ptr
  store i32 2, ptr %p2800, align 4, !alias.scope !3, !noalias !4
  %v2801 = load i64, ptr %slot6, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  store i32 1, ptr %p2802, align 4, !alias.scope !3, !noalias !4
  %v2803 = load i64, ptr %slot464, align 8
  %v2804 = load i64, ptr %slot20, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i64 %v2803, ptr %p2805, align 8, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot20, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  %ld2808 = load i64, ptr %p2807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2808, ptr %slot465, align 8
  %v2809 = load i64, ptr %slot20, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  %ld2811 = load i64, ptr %p2810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2811, ptr %slot466, align 8
  %v2812 = load i64, ptr %slot14, align 8
  store i64 %v2812, ptr %slot467, align 8
  %v2813 = load i64, ptr %slot37, align 8
  store i64 %v2813, ptr %slot468, align 8
  %v2814 = load i64, ptr %slot466, align 8
  %op2815 = add i64 %v2814, 8
  store i64 %op2815, ptr %slot469, align 8
  %v2816 = load i64, ptr %slot469, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  %ld2818 = load i64, ptr %p2817, align 8
  store i64 %ld2818, ptr %slot470, align 8
  %v2819 = load i64, ptr %slot470, align 8
  %cmp2820 = icmp ne i64 %v2819, 0
  %cv2821 = zext i1 %cmp2820 to i32
  store i32 %cv2821, ptr %slot471, align 8
  %v2822 = load i32, ptr %slot471, align 8
  %cv2823 = zext i32 %v2822 to i64
  %cond2824 = icmp ne i64 %cv2823, 0
  br i1 %cond2824, label %bb_rcmoveheader925, label %bb_rcmovenext925
bb_rcmoveheader925:
  %v2825 = load i64, ptr %slot470, align 8
  %op2826 = sub i64 %v2825, 16
  store i64 %op2826, ptr %slot472, align 8
  %v2827 = load i64, ptr %slot470, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  %rgep2829 = getelementptr i8, ptr %p2828, i64 -16
  %ld2830 = load i64, ptr %rgep2829, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2830, ptr %slot473, align 8
  %v2831 = load i64, ptr %slot473, align 8
  %op2832 = and i64 %v2831, 5764607523034234881
  store i64 %op2832, ptr %slot474, align 8
  %v2833 = load i64, ptr %slot474, align 8
  %cmp2834 = icmp ne i64 %v2833, 0
  %cv2835 = zext i1 %cmp2834 to i32
  store i32 %cv2835, ptr %slot475, align 8
  %v2836 = load i32, ptr %slot475, align 8
  %cv2837 = zext i32 %v2836 to i64
  %cond2838 = icmp ne i64 %cv2837, 0
  br i1 %cond2838, label %bb_rcmoveslow922, label %bb_rcmovenext925
bb_rcmovenext925:
  %v2839 = load i64, ptr %slot466, align 8
  %v2840 = load i64, ptr %slot467, align 8
  %p2841 = inttoptr i64 %v2839 to ptr
  %p2842 = inttoptr i64 %v2840 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2842, ptr %p2841, i64 24, i1 false)
  %v2843 = load i64, ptr %slot466, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  store i64 0, ptr %p2844, align 8
  %v2845 = load i64, ptr %slot466, align 8
  %op2846 = add i64 %v2845, 8
  store i64 %op2846, ptr %slot476, align 8
  %v2847 = load i64, ptr %slot476, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  store i64 0, ptr %p2848, align 8
  %v2849 = load i64, ptr %slot466, align 8
  %op2850 = add i64 %v2849, 16
  store i64 %op2850, ptr %slot477, align 8
  %v2851 = load i64, ptr %slot477, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  store i64 0, ptr %p2852, align 8
  br label %bb_rcmoved922
bb_rcmoveslow922:
  %v2853 = load i64, ptr %slot36, align 8
  %v2854 = load i64, ptr %slot467, align 8
  %v2855 = load i64, ptr %slot466, align 8
  %v2856 = load i64, ptr %slot468, align 8
  %cv2857 = trunc i64 %v2856 to i32
  %call2858 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v2853, i64 %v2854, i64 %v2855, i32 %cv2857) nomerge, !dbg !166
  store i32 %call2858, ptr %slot478, align 8
  %v2859 = load i32, ptr %slot478, align 8
  %cv2860 = zext i32 %v2859 to i64
  %cond2861 = icmp ne i64 %cv2860, 0
  br i1 %cond2861, label %bb_rcsuccess934, label %bb_rcfailure934
bb_rcfailure934:
  %v2862 = load i64, ptr %slot36, align 8
  %p2863 = inttoptr i64 %v2862 to ptr
  %call2864 = call i32 @myl_rc_take_failure(ptr %p2863) nomerge, !dbg !166
  store i32 %call2864, ptr %slot479, align 8
  %v2865 = load i64, ptr %slot1, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  %v2867 = load i32, ptr %slot479, align 8
  %call2868 = call i32 @myl_qbe_rc_status(ptr %p2866, i32 %v2867) nomerge, !dbg !166
  store i32 %call2868, ptr %slot480, align 8
  br label %bb_failure
bb_rcsuccess934:
  br label %bb_rcmoved922
bb_rcmoved922:
  %v2869 = load i64, ptr %slot6, align 8
  %p2870 = inttoptr i64 %v2869 to ptr
  store i32 0, ptr %p2870, align 4, !alias.scope !3, !noalias !4
  %v2871 = load i64, ptr %slot10, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  store i32 2, ptr %p2872, align 4, !alias.scope !3, !noalias !4
  %v2873 = load i64, ptr %slot9, align 8
  %p2874 = inttoptr i64 %v2873 to ptr
  store i32 1, ptr %p2874, align 4, !alias.scope !3, !noalias !4
  %v2875 = load i64, ptr %slot14, align 8
  store i64 %v2875, ptr %slot481, align 8
  %v2876 = load i64, ptr %slot9, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  store i32 0, ptr %p2877, align 4, !alias.scope !3, !noalias !4
  %v2878 = load i64, ptr %slot6, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  %ld2880 = load i32, ptr %p2879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2880, ptr %slot482, align 8
  %v2881 = load i32, ptr %slot482, align 8
  %cv2882 = zext i32 %v2881 to i64
  %cond2883 = icmp ne i64 %cv2882, 0
  br i1 %cond2883, label %bb_rcslotdrop944, label %bb_rcslotdone944
bb_rcslotdrop944:
  %v2884 = load i64, ptr %slot6, align 8
  %p2885 = inttoptr i64 %v2884 to ptr
  store i32 0, ptr %p2885, align 4, !alias.scope !3, !noalias !4
  %v2886 = load i64, ptr %slot12, align 8
  store i64 %v2886, ptr %slot483, align 8
  %v2887 = load i64, ptr %slot7, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  %ld2889 = load i32, ptr %p2888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2889, ptr %slot484, align 8
  %v2890 = load i32, ptr %slot484, align 8
  %op2891 = and i32 %v2890, 28
  store i32 %op2891, ptr %slot485, align 8
  %v2892 = load i32, ptr %slot485, align 8
  %cv2893 = zext i32 %v2892 to i64
  %cond2894 = icmp ne i64 %cv2893, 0
  br i1 %cond2894, label %bb_rcslotrole944, label %bb_rcslotowner944
bb_rcslotrole944:
  %v2895 = load i64, ptr %slot36, align 8
  store i64 %v2895, ptr %slot486, align 8
  %v2896 = load i64, ptr %slot486, align 8
  %v2897 = load i64, ptr %slot483, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v2896, i64 %v2897) nomerge, !dbg !166
  br label %bb_rcslotdone944
bb_rcslotowner944:
  %v2898 = load i64, ptr %slot36, align 8
  store i64 %v2898, ptr %slot487, align 8
  %v2899 = load i64, ptr %slot487, align 8
  %v2900 = load i64, ptr %slot483, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v2899, i64 %v2900) nomerge, !dbg !166
  br label %bb_rcslotdone944
bb_rcslotdone944:
  %v2901 = load i64, ptr %slot481, align 8
  %p2902 = inttoptr i64 %v2901 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2902, i64 24, i1 false)
  ret void
bb_i53:
  %v2903 = load i64, ptr %slot20, align 8
  %p2904 = inttoptr i64 %v2903 to ptr
  store i64 0, ptr %p2904, align 8, !alias.scope !3, !noalias !4
  %v2905 = load i64, ptr %slot20, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  %ld2907 = load i64, ptr %p2906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2907, ptr %slot488, align 8
  %v2908 = load i64, ptr %slot488, align 8
  %cond2909 = icmp ne i64 %v2908, 0
  br i1 %cond2909, label %bb_success1007, label %bb_failed1007
bb_failed1007:
  %v2910 = load i64, ptr %slot1, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  call void @myl_qbe_fail_assert(ptr %p2911) nomerge, !dbg !168
  unreachable
bb_success1007:
  %v2912 = load i64, ptr %slot20, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  store i64 18446744073709551615, ptr %p2913, align 8, !alias.scope !3, !noalias !4
  %v2914 = load i64, ptr %slot1, align 8
  %call2915 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v2914) nomerge, !dbg !170
  store { i64, i64 } %call2915, ptr %callresult490, align 8
  %addr2916 = ptrtoint ptr %callresult490 to i64
  store i64 %addr2916, ptr %slot489, align 8
  %v2917 = load i64, ptr %slot489, align 8
  %v2918 = load i64, ptr %slot21, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  store i64 %v2917, ptr %p2919, align 8, !alias.scope !3, !noalias !4
  %v2920 = load i64, ptr %slot21, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  %ld2922 = load i64, ptr %p2921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2922, ptr %slot491, align 8
  %v2923 = load i64, ptr %slot14, align 8
  store i64 %v2923, ptr %slot492, align 8
  %v2924 = load i64, ptr %slot491, align 8
  %v2925 = load i64, ptr %slot492, align 8
  %p2926 = inttoptr i64 %v2924 to ptr
  %p2927 = inttoptr i64 %v2925 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2927, ptr %p2926, i64 16, i1 false)
  %v2928 = load i64, ptr %slot10, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  store i32 2, ptr %p2929, align 4, !alias.scope !3, !noalias !4
  %v2930 = load i64, ptr %slot9, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  store i32 1, ptr %p2931, align 4, !alias.scope !3, !noalias !4
  %v2932 = load i64, ptr %slot13, align 8
  store i64 %v2932, ptr %slot493, align 8
  %v2933 = load i64, ptr %slot14, align 8
  store i64 %v2933, ptr %slot494, align 8
  %v2934 = load i64, ptr %slot494, align 8
  %v2935 = load i64, ptr %slot493, align 8
  %p2936 = inttoptr i64 %v2934 to ptr
  %p2937 = inttoptr i64 %v2935 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2937, ptr %p2936, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2938 = load i64, ptr %slot10, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  %ld2940 = load i32, ptr %p2939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2940, ptr %slot495, align 8
  %v2941 = load i64, ptr %slot9, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  store i32 0, ptr %p2942, align 4, !alias.scope !3, !noalias !4
  %v2943 = load i64, ptr %slot8, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  store i32 1, ptr %p2944, align 4, !alias.scope !3, !noalias !4
  %v2945 = load i64, ptr %slot493, align 8
  %v2946 = load i64, ptr %slot21, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  store i64 %v2945, ptr %p2947, align 8, !alias.scope !3, !noalias !4
  %v2948 = load i64, ptr %slot27, align 8
  store i64 %v2948, ptr %slot496, align 8
  %v2949 = load i64, ptr %slot496, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  store i64 0, ptr %p2950, align 8, !alias.scope !3, !noalias !4
  %v2951 = load i64, ptr %slot496, align 8
  %p2953 = inttoptr i64 %v2951 to ptr
  %gep2954 = getelementptr i8, ptr %p2953, i64 8
  %op2952 = ptrtoint ptr %gep2954 to i64
  store i64 %op2952, ptr %slot497, align 8
  %v2955 = load i64, ptr %slot497, align 8
  %p2956 = inttoptr i64 %v2955 to ptr
  store i64 0, ptr %p2956, align 8, !alias.scope !3, !noalias !4
  %v2957 = load i64, ptr %slot496, align 8
  %p2959 = inttoptr i64 %v2957 to ptr
  %gep2960 = getelementptr i8, ptr %p2959, i64 16
  %op2958 = ptrtoint ptr %gep2960 to i64
  store i64 %op2958, ptr %slot498, align 8
  %v2961 = load i64, ptr %slot498, align 8
  %p2962 = inttoptr i64 %v2961 to ptr
  store i64 0, ptr %p2962, align 8, !alias.scope !3, !noalias !4
  %v2963 = load i64, ptr %slot11, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  store i32 1, ptr %p2964, align 4, !alias.scope !3, !noalias !4
  %v2965 = load i64, ptr %slot37, align 8
  store i64 %v2965, ptr %slot499, align 8
  %v2966 = load i64, ptr %slot20, align 8
  store i64 %v2966, ptr %slot500, align 8
  %v2967 = load i64, ptr %slot496, align 8
  %p2969 = inttoptr i64 %v2967 to ptr
  %gep2970 = getelementptr i8, ptr %p2969, i64 0
  %op2968 = ptrtoint ptr %gep2970 to i64
  store i64 %op2968, ptr %slot501, align 8
  %v2971 = load i64, ptr %slot500, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  %ld2973 = load i64, ptr %p2972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2973, ptr %slot502, align 8
  %v2974 = load i64, ptr %slot502, align 8
  %v2975 = load i64, ptr %slot501, align 8
  %p2976 = inttoptr i64 %v2975 to ptr
  store i64 %v2974, ptr %p2976, align 8, !alias.scope !3, !noalias !4
  %v2977 = load i64, ptr %slot21, align 8
  %p2978 = inttoptr i64 %v2977 to ptr
  %ld2979 = load i64, ptr %p2978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2979, ptr %slot503, align 8
  %v2980 = load i64, ptr %slot496, align 8
  %p2982 = inttoptr i64 %v2980 to ptr
  %gep2983 = getelementptr i8, ptr %p2982, i64 8
  %op2981 = ptrtoint ptr %gep2983 to i64
  store i64 %op2981, ptr %slot504, align 8
  %v2984 = load i64, ptr %slot21, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  %ld2986 = load i64, ptr %p2985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2986, ptr %slot505, align 8
  %v2987 = load i64, ptr %slot14, align 8
  store i64 %v2987, ptr %slot506, align 8
  %v2988 = load i64, ptr %slot37, align 8
  store i64 %v2988, ptr %slot507, align 8
  %v2989 = load i64, ptr %slot505, align 8
  %op2990 = add i64 %v2989, 0
  store i64 %op2990, ptr %slot508, align 8
  %v2991 = load i64, ptr %slot508, align 8
  %p2992 = inttoptr i64 %v2991 to ptr
  %ld2993 = load i64, ptr %p2992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2993, ptr %slot509, align 8
  %v2994 = load i64, ptr %slot509, align 8
  %cmp2995 = icmp ne i64 %v2994, 0
  %cv2996 = zext i1 %cmp2995 to i32
  store i32 %cv2996, ptr %slot510, align 8
  %v2997 = load i32, ptr %slot510, align 8
  %cv2998 = zext i32 %v2997 to i64
  %cond2999 = icmp ne i64 %cv2998, 0
  br i1 %cond2999, label %bb_rcmoveheader1038, label %bb_rcmovenext1038
bb_rcmoveheader1038:
  %v3000 = load i64, ptr %slot509, align 8
  %op3001 = sub i64 %v3000, 16
  store i64 %op3001, ptr %slot511, align 8
  %v3002 = load i64, ptr %slot509, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  %rgep3004 = getelementptr i8, ptr %p3003, i64 -16
  %ld3005 = load i64, ptr %rgep3004, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3005, ptr %slot512, align 8
  %v3006 = load i64, ptr %slot512, align 8
  %op3007 = and i64 %v3006, 5764607523034234881
  store i64 %op3007, ptr %slot513, align 8
  %v3008 = load i64, ptr %slot513, align 8
  %cmp3009 = icmp ne i64 %v3008, 0
  %cv3010 = zext i1 %cmp3009 to i32
  store i32 %cv3010, ptr %slot514, align 8
  %v3011 = load i32, ptr %slot514, align 8
  %cv3012 = zext i32 %v3011 to i64
  %cond3013 = icmp ne i64 %cv3012, 0
  br i1 %cond3013, label %bb_rcmoveslow1035, label %bb_rcmovenext1038
bb_rcmovenext1038:
  %v3014 = load i64, ptr %slot505, align 8
  %v3015 = load i64, ptr %slot506, align 8
  %p3016 = inttoptr i64 %v3014 to ptr
  %p3017 = inttoptr i64 %v3015 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3017, ptr %p3016, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3018 = load i64, ptr %slot505, align 8
  %p3019 = inttoptr i64 %v3018 to ptr
  store i64 0, ptr %p3019, align 8, !alias.scope !3, !noalias !4
  %v3020 = load i64, ptr %slot505, align 8
  %op3021 = add i64 %v3020, 8
  store i64 %op3021, ptr %slot515, align 8
  %v3022 = load i64, ptr %slot515, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  store i64 0, ptr %p3023, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1035
bb_rcmoveslow1035:
  %v3024 = load i64, ptr %slot36, align 8
  %v3025 = load i64, ptr %slot506, align 8
  %v3026 = load i64, ptr %slot505, align 8
  %v3027 = load i64, ptr %slot507, align 8
  %cv3028 = trunc i64 %v3027 to i32
  %call3029 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v3024, i64 %v3025, i64 %v3026, i32 %cv3028) nomerge, !dbg !172
  store i32 %call3029, ptr %slot516, align 8
  %v3030 = load i32, ptr %slot516, align 8
  %cv3031 = zext i32 %v3030 to i64
  %cond3032 = icmp ne i64 %cv3031, 0
  br i1 %cond3032, label %bb_rcsuccess1046, label %bb_rcfailure1046
bb_rcfailure1046:
  %v3033 = load i64, ptr %slot36, align 8
  %p3034 = inttoptr i64 %v3033 to ptr
  %call3035 = call i32 @myl_rc_take_failure(ptr %p3034) nomerge, !dbg !172
  store i32 %call3035, ptr %slot517, align 8
  %v3036 = load i64, ptr %slot1, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  %v3038 = load i32, ptr %slot517, align 8
  %call3039 = call i32 @myl_qbe_rc_status(ptr %p3037, i32 %v3038) nomerge, !dbg !172
  store i32 %call3039, ptr %slot518, align 8
  br label %bb_failure
bb_rcsuccess1046:
  br label %bb_rcmoved1035
bb_rcmoved1035:
  %v3040 = load i64, ptr %slot8, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  store i32 0, ptr %p3041, align 4, !alias.scope !3, !noalias !4
  %v3042 = load i64, ptr %slot10, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  store i32 2, ptr %p3043, align 4, !alias.scope !3, !noalias !4
  %v3044 = load i64, ptr %slot9, align 8
  %p3045 = inttoptr i64 %v3044 to ptr
  store i32 1, ptr %p3045, align 4, !alias.scope !3, !noalias !4
  %v3046 = load i64, ptr %slot14, align 8
  store i64 %v3046, ptr %slot519, align 8
  %v3047 = load i64, ptr %slot519, align 8
  %v3048 = load i64, ptr %slot504, align 8
  %p3049 = inttoptr i64 %v3047 to ptr
  %p3050 = inttoptr i64 %v3048 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3050, ptr %p3049, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3051 = load i64, ptr %slot9, align 8
  %p3052 = inttoptr i64 %v3051 to ptr
  store i32 0, ptr %p3052, align 4, !alias.scope !3, !noalias !4
  %v3053 = load i64, ptr %slot496, align 8
  %v3054 = load i64, ptr %slot20, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  store i64 %v3053, ptr %p3055, align 8, !alias.scope !3, !noalias !4
  %v3056 = load i64, ptr %slot20, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  %ld3058 = load i64, ptr %p3057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3058, ptr %slot520, align 8
  %v3059 = load i64, ptr %slot12, align 8
  store i64 %v3059, ptr %slot521, align 8
  %v3060 = load i64, ptr %slot520, align 8
  %v3061 = load i64, ptr %slot521, align 8
  %p3062 = inttoptr i64 %v3060 to ptr
  %p3063 = inttoptr i64 %v3061 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3063, ptr %p3062, i64 24, i1 false)
  %v3064 = load i64, ptr %slot7, align 8
  %p3065 = inttoptr i64 %v3064 to ptr
  store i32 2, ptr %p3065, align 4, !alias.scope !3, !noalias !4
  %v3066 = load i64, ptr %slot6, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  store i32 1, ptr %p3067, align 4, !alias.scope !3, !noalias !4
  %v3068 = load i64, ptr %slot521, align 8
  %v3069 = load i64, ptr %slot20, align 8
  %p3070 = inttoptr i64 %v3069 to ptr
  store i64 %v3068, ptr %p3070, align 8, !alias.scope !3, !noalias !4
  %v3071 = load i64, ptr %slot20, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  %ld3073 = load i64, ptr %p3072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3073, ptr %slot522, align 8
  %v3074 = load i64, ptr %slot20, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  %ld3076 = load i64, ptr %p3075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3076, ptr %slot523, align 8
  %v3077 = load i64, ptr %slot14, align 8
  store i64 %v3077, ptr %slot524, align 8
  %v3078 = load i64, ptr %slot37, align 8
  store i64 %v3078, ptr %slot525, align 8
  %v3079 = load i64, ptr %slot523, align 8
  %op3080 = add i64 %v3079, 8
  store i64 %op3080, ptr %slot526, align 8
  %v3081 = load i64, ptr %slot526, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  %ld3083 = load i64, ptr %p3082, align 8
  store i64 %ld3083, ptr %slot527, align 8
  %v3084 = load i64, ptr %slot527, align 8
  %cmp3085 = icmp ne i64 %v3084, 0
  %cv3086 = zext i1 %cmp3085 to i32
  store i32 %cv3086, ptr %slot528, align 8
  %v3087 = load i32, ptr %slot528, align 8
  %cv3088 = zext i32 %v3087 to i64
  %cond3089 = icmp ne i64 %cv3088, 0
  br i1 %cond3089, label %bb_rcmoveheader1065, label %bb_rcmovenext1065
bb_rcmoveheader1065:
  %v3090 = load i64, ptr %slot527, align 8
  %op3091 = sub i64 %v3090, 16
  store i64 %op3091, ptr %slot529, align 8
  %v3092 = load i64, ptr %slot527, align 8
  %p3093 = inttoptr i64 %v3092 to ptr
  %rgep3094 = getelementptr i8, ptr %p3093, i64 -16
  %ld3095 = load i64, ptr %rgep3094, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3095, ptr %slot530, align 8
  %v3096 = load i64, ptr %slot530, align 8
  %op3097 = and i64 %v3096, 5764607523034234881
  store i64 %op3097, ptr %slot531, align 8
  %v3098 = load i64, ptr %slot531, align 8
  %cmp3099 = icmp ne i64 %v3098, 0
  %cv3100 = zext i1 %cmp3099 to i32
  store i32 %cv3100, ptr %slot532, align 8
  %v3101 = load i32, ptr %slot532, align 8
  %cv3102 = zext i32 %v3101 to i64
  %cond3103 = icmp ne i64 %cv3102, 0
  br i1 %cond3103, label %bb_rcmoveslow1062, label %bb_rcmovenext1065
bb_rcmovenext1065:
  %v3104 = load i64, ptr %slot523, align 8
  %v3105 = load i64, ptr %slot524, align 8
  %p3106 = inttoptr i64 %v3104 to ptr
  %p3107 = inttoptr i64 %v3105 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3107, ptr %p3106, i64 24, i1 false)
  %v3108 = load i64, ptr %slot523, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  store i64 0, ptr %p3109, align 8
  %v3110 = load i64, ptr %slot523, align 8
  %op3111 = add i64 %v3110, 8
  store i64 %op3111, ptr %slot533, align 8
  %v3112 = load i64, ptr %slot533, align 8
  %p3113 = inttoptr i64 %v3112 to ptr
  store i64 0, ptr %p3113, align 8
  %v3114 = load i64, ptr %slot523, align 8
  %op3115 = add i64 %v3114, 16
  store i64 %op3115, ptr %slot534, align 8
  %v3116 = load i64, ptr %slot534, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  store i64 0, ptr %p3117, align 8
  br label %bb_rcmoved1062
bb_rcmoveslow1062:
  %v3118 = load i64, ptr %slot36, align 8
  %v3119 = load i64, ptr %slot524, align 8
  %v3120 = load i64, ptr %slot523, align 8
  %v3121 = load i64, ptr %slot525, align 8
  %cv3122 = trunc i64 %v3121 to i32
  %call3123 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v3118, i64 %v3119, i64 %v3120, i32 %cv3122) nomerge, !dbg !174
  store i32 %call3123, ptr %slot535, align 8
  %v3124 = load i32, ptr %slot535, align 8
  %cv3125 = zext i32 %v3124 to i64
  %cond3126 = icmp ne i64 %cv3125, 0
  br i1 %cond3126, label %bb_rcsuccess1074, label %bb_rcfailure1074
bb_rcfailure1074:
  %v3127 = load i64, ptr %slot36, align 8
  %p3128 = inttoptr i64 %v3127 to ptr
  %call3129 = call i32 @myl_rc_take_failure(ptr %p3128) nomerge, !dbg !174
  store i32 %call3129, ptr %slot536, align 8
  %v3130 = load i64, ptr %slot1, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  %v3132 = load i32, ptr %slot536, align 8
  %call3133 = call i32 @myl_qbe_rc_status(ptr %p3131, i32 %v3132) nomerge, !dbg !174
  store i32 %call3133, ptr %slot537, align 8
  br label %bb_failure
bb_rcsuccess1074:
  br label %bb_rcmoved1062
bb_rcmoved1062:
  %v3134 = load i64, ptr %slot6, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  store i32 0, ptr %p3135, align 4, !alias.scope !3, !noalias !4
  %v3136 = load i64, ptr %slot10, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  store i32 2, ptr %p3137, align 4, !alias.scope !3, !noalias !4
  %v3138 = load i64, ptr %slot9, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  store i32 1, ptr %p3139, align 4, !alias.scope !3, !noalias !4
  %v3140 = load i64, ptr %slot14, align 8
  store i64 %v3140, ptr %slot538, align 8
  %v3141 = load i64, ptr %slot9, align 8
  %p3142 = inttoptr i64 %v3141 to ptr
  store i32 0, ptr %p3142, align 4, !alias.scope !3, !noalias !4
  %v3143 = load i64, ptr %slot6, align 8
  %p3144 = inttoptr i64 %v3143 to ptr
  %ld3145 = load i32, ptr %p3144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3145, ptr %slot539, align 8
  %v3146 = load i32, ptr %slot539, align 8
  %cv3147 = zext i32 %v3146 to i64
  %cond3148 = icmp ne i64 %cv3147, 0
  br i1 %cond3148, label %bb_rcslotdrop1084, label %bb_rcslotdone1084
bb_rcslotdrop1084:
  %v3149 = load i64, ptr %slot6, align 8
  %p3150 = inttoptr i64 %v3149 to ptr
  store i32 0, ptr %p3150, align 4, !alias.scope !3, !noalias !4
  %v3151 = load i64, ptr %slot12, align 8
  store i64 %v3151, ptr %slot540, align 8
  %v3152 = load i64, ptr %slot7, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  %ld3154 = load i32, ptr %p3153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3154, ptr %slot541, align 8
  %v3155 = load i32, ptr %slot541, align 8
  %op3156 = and i32 %v3155, 28
  store i32 %op3156, ptr %slot542, align 8
  %v3157 = load i32, ptr %slot542, align 8
  %cv3158 = zext i32 %v3157 to i64
  %cond3159 = icmp ne i64 %cv3158, 0
  br i1 %cond3159, label %bb_rcslotrole1084, label %bb_rcslotowner1084
bb_rcslotrole1084:
  %v3160 = load i64, ptr %slot36, align 8
  store i64 %v3160, ptr %slot543, align 8
  %v3161 = load i64, ptr %slot543, align 8
  %v3162 = load i64, ptr %slot540, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3161, i64 %v3162) nomerge, !dbg !174
  br label %bb_rcslotdone1084
bb_rcslotowner1084:
  %v3163 = load i64, ptr %slot36, align 8
  store i64 %v3163, ptr %slot544, align 8
  %v3164 = load i64, ptr %slot544, align 8
  %v3165 = load i64, ptr %slot540, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3164, i64 %v3165) nomerge, !dbg !174
  br label %bb_rcslotdone1084
bb_rcslotdone1084:
  %v3166 = load i64, ptr %slot538, align 8
  %p3167 = inttoptr i64 %v3166 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3167, i64 24, i1 false)
  ret void
bb_i59:
  %v3168 = load i64, ptr %slot20, align 8
  %p3169 = inttoptr i64 %v3168 to ptr
  store i64 0, ptr %p3169, align 8, !alias.scope !3, !noalias !4
  %v3170 = load i64, ptr %slot20, align 8
  %p3171 = inttoptr i64 %v3170 to ptr
  %ld3172 = load i64, ptr %p3171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3172, ptr %slot545, align 8
  %v3173 = load i64, ptr %slot545, align 8
  %cond3174 = icmp ne i64 %v3173, 0
  br i1 %cond3174, label %bb_success1147, label %bb_failed1147
bb_failed1147:
  %v3175 = load i64, ptr %slot1, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  call void @myl_qbe_fail_assert(ptr %p3176) nomerge, !dbg !176
  unreachable
bb_success1147:
  %v3177 = load i64, ptr %slot20, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  store i64 18446744073709551615, ptr %p3178, align 8, !alias.scope !3, !noalias !4
  %v3179 = load i64, ptr %slot1, align 8
  %call3180 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v3179) nomerge, !dbg !178
  store { i64, i64 } %call3180, ptr %callresult547, align 8
  %addr3181 = ptrtoint ptr %callresult547 to i64
  store i64 %addr3181, ptr %slot546, align 8
  %v3182 = load i64, ptr %slot546, align 8
  %v3183 = load i64, ptr %slot21, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  store i64 %v3182, ptr %p3184, align 8, !alias.scope !3, !noalias !4
  %v3185 = load i64, ptr %slot21, align 8
  %p3186 = inttoptr i64 %v3185 to ptr
  %ld3187 = load i64, ptr %p3186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3187, ptr %slot548, align 8
  %v3188 = load i64, ptr %slot14, align 8
  store i64 %v3188, ptr %slot549, align 8
  %v3189 = load i64, ptr %slot548, align 8
  %v3190 = load i64, ptr %slot549, align 8
  %p3191 = inttoptr i64 %v3189 to ptr
  %p3192 = inttoptr i64 %v3190 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3192, ptr %p3191, i64 16, i1 false)
  %v3193 = load i64, ptr %slot10, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  store i32 2, ptr %p3194, align 4, !alias.scope !3, !noalias !4
  %v3195 = load i64, ptr %slot9, align 8
  %p3196 = inttoptr i64 %v3195 to ptr
  store i32 1, ptr %p3196, align 4, !alias.scope !3, !noalias !4
  %v3197 = load i64, ptr %slot13, align 8
  store i64 %v3197, ptr %slot550, align 8
  %v3198 = load i64, ptr %slot14, align 8
  store i64 %v3198, ptr %slot551, align 8
  %v3199 = load i64, ptr %slot551, align 8
  %v3200 = load i64, ptr %slot550, align 8
  %p3201 = inttoptr i64 %v3199 to ptr
  %p3202 = inttoptr i64 %v3200 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3202, ptr %p3201, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3203 = load i64, ptr %slot10, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  %ld3205 = load i32, ptr %p3204, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3205, ptr %slot552, align 8
  %v3206 = load i64, ptr %slot9, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  store i32 0, ptr %p3207, align 4, !alias.scope !3, !noalias !4
  %v3208 = load i64, ptr %slot8, align 8
  %p3209 = inttoptr i64 %v3208 to ptr
  store i32 1, ptr %p3209, align 4, !alias.scope !3, !noalias !4
  %v3210 = load i64, ptr %slot550, align 8
  %v3211 = load i64, ptr %slot21, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  store i64 %v3210, ptr %p3212, align 8, !alias.scope !3, !noalias !4
  %v3213 = load i64, ptr %slot28, align 8
  store i64 %v3213, ptr %slot553, align 8
  %v3214 = load i64, ptr %slot553, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  store i64 0, ptr %p3215, align 8, !alias.scope !3, !noalias !4
  %v3216 = load i64, ptr %slot553, align 8
  %p3218 = inttoptr i64 %v3216 to ptr
  %gep3219 = getelementptr i8, ptr %p3218, i64 8
  %op3217 = ptrtoint ptr %gep3219 to i64
  store i64 %op3217, ptr %slot554, align 8
  %v3220 = load i64, ptr %slot554, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  store i64 0, ptr %p3221, align 8, !alias.scope !3, !noalias !4
  %v3222 = load i64, ptr %slot553, align 8
  %p3224 = inttoptr i64 %v3222 to ptr
  %gep3225 = getelementptr i8, ptr %p3224, i64 16
  %op3223 = ptrtoint ptr %gep3225 to i64
  store i64 %op3223, ptr %slot555, align 8
  %v3226 = load i64, ptr %slot555, align 8
  %p3227 = inttoptr i64 %v3226 to ptr
  store i64 0, ptr %p3227, align 8, !alias.scope !3, !noalias !4
  %v3228 = load i64, ptr %slot11, align 8
  %p3229 = inttoptr i64 %v3228 to ptr
  store i32 1, ptr %p3229, align 4, !alias.scope !3, !noalias !4
  %v3230 = load i64, ptr %slot37, align 8
  store i64 %v3230, ptr %slot556, align 8
  %v3231 = load i64, ptr %slot20, align 8
  store i64 %v3231, ptr %slot557, align 8
  %v3232 = load i64, ptr %slot553, align 8
  %p3234 = inttoptr i64 %v3232 to ptr
  %gep3235 = getelementptr i8, ptr %p3234, i64 0
  %op3233 = ptrtoint ptr %gep3235 to i64
  store i64 %op3233, ptr %slot558, align 8
  %v3236 = load i64, ptr %slot557, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  %ld3238 = load i64, ptr %p3237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3238, ptr %slot559, align 8
  %v3239 = load i64, ptr %slot559, align 8
  %v3240 = load i64, ptr %slot558, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  store i64 %v3239, ptr %p3241, align 8, !alias.scope !3, !noalias !4
  %v3242 = load i64, ptr %slot21, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  %ld3244 = load i64, ptr %p3243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3244, ptr %slot560, align 8
  %v3245 = load i64, ptr %slot553, align 8
  %p3247 = inttoptr i64 %v3245 to ptr
  %gep3248 = getelementptr i8, ptr %p3247, i64 8
  %op3246 = ptrtoint ptr %gep3248 to i64
  store i64 %op3246, ptr %slot561, align 8
  %v3249 = load i64, ptr %slot21, align 8
  %p3250 = inttoptr i64 %v3249 to ptr
  %ld3251 = load i64, ptr %p3250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3251, ptr %slot562, align 8
  %v3252 = load i64, ptr %slot14, align 8
  store i64 %v3252, ptr %slot563, align 8
  %v3253 = load i64, ptr %slot37, align 8
  store i64 %v3253, ptr %slot564, align 8
  %v3254 = load i64, ptr %slot562, align 8
  %op3255 = add i64 %v3254, 0
  store i64 %op3255, ptr %slot565, align 8
  %v3256 = load i64, ptr %slot565, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  %ld3258 = load i64, ptr %p3257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3258, ptr %slot566, align 8
  %v3259 = load i64, ptr %slot566, align 8
  %cmp3260 = icmp ne i64 %v3259, 0
  %cv3261 = zext i1 %cmp3260 to i32
  store i32 %cv3261, ptr %slot567, align 8
  %v3262 = load i32, ptr %slot567, align 8
  %cv3263 = zext i32 %v3262 to i64
  %cond3264 = icmp ne i64 %cv3263, 0
  br i1 %cond3264, label %bb_rcmoveheader1178, label %bb_rcmovenext1178
bb_rcmoveheader1178:
  %v3265 = load i64, ptr %slot566, align 8
  %op3266 = sub i64 %v3265, 16
  store i64 %op3266, ptr %slot568, align 8
  %v3267 = load i64, ptr %slot566, align 8
  %p3268 = inttoptr i64 %v3267 to ptr
  %rgep3269 = getelementptr i8, ptr %p3268, i64 -16
  %ld3270 = load i64, ptr %rgep3269, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3270, ptr %slot569, align 8
  %v3271 = load i64, ptr %slot569, align 8
  %op3272 = and i64 %v3271, 5764607523034234881
  store i64 %op3272, ptr %slot570, align 8
  %v3273 = load i64, ptr %slot570, align 8
  %cmp3274 = icmp ne i64 %v3273, 0
  %cv3275 = zext i1 %cmp3274 to i32
  store i32 %cv3275, ptr %slot571, align 8
  %v3276 = load i32, ptr %slot571, align 8
  %cv3277 = zext i32 %v3276 to i64
  %cond3278 = icmp ne i64 %cv3277, 0
  br i1 %cond3278, label %bb_rcmoveslow1175, label %bb_rcmovenext1178
bb_rcmovenext1178:
  %v3279 = load i64, ptr %slot562, align 8
  %v3280 = load i64, ptr %slot563, align 8
  %p3281 = inttoptr i64 %v3279 to ptr
  %p3282 = inttoptr i64 %v3280 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3282, ptr %p3281, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3283 = load i64, ptr %slot562, align 8
  %p3284 = inttoptr i64 %v3283 to ptr
  store i64 0, ptr %p3284, align 8, !alias.scope !3, !noalias !4
  %v3285 = load i64, ptr %slot562, align 8
  %op3286 = add i64 %v3285, 8
  store i64 %op3286, ptr %slot572, align 8
  %v3287 = load i64, ptr %slot572, align 8
  %p3288 = inttoptr i64 %v3287 to ptr
  store i64 0, ptr %p3288, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1175
bb_rcmoveslow1175:
  %v3289 = load i64, ptr %slot36, align 8
  %v3290 = load i64, ptr %slot563, align 8
  %v3291 = load i64, ptr %slot562, align 8
  %v3292 = load i64, ptr %slot564, align 8
  %cv3293 = trunc i64 %v3292 to i32
  %call3294 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v3289, i64 %v3290, i64 %v3291, i32 %cv3293) nomerge, !dbg !180
  store i32 %call3294, ptr %slot573, align 8
  %v3295 = load i32, ptr %slot573, align 8
  %cv3296 = zext i32 %v3295 to i64
  %cond3297 = icmp ne i64 %cv3296, 0
  br i1 %cond3297, label %bb_rcsuccess1186, label %bb_rcfailure1186
bb_rcfailure1186:
  %v3298 = load i64, ptr %slot36, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  %call3300 = call i32 @myl_rc_take_failure(ptr %p3299) nomerge, !dbg !180
  store i32 %call3300, ptr %slot574, align 8
  %v3301 = load i64, ptr %slot1, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  %v3303 = load i32, ptr %slot574, align 8
  %call3304 = call i32 @myl_qbe_rc_status(ptr %p3302, i32 %v3303) nomerge, !dbg !180
  store i32 %call3304, ptr %slot575, align 8
  br label %bb_failure
bb_rcsuccess1186:
  br label %bb_rcmoved1175
bb_rcmoved1175:
  %v3305 = load i64, ptr %slot8, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  store i32 0, ptr %p3306, align 4, !alias.scope !3, !noalias !4
  %v3307 = load i64, ptr %slot10, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  store i32 2, ptr %p3308, align 4, !alias.scope !3, !noalias !4
  %v3309 = load i64, ptr %slot9, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  store i32 1, ptr %p3310, align 4, !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot14, align 8
  store i64 %v3311, ptr %slot576, align 8
  %v3312 = load i64, ptr %slot576, align 8
  %v3313 = load i64, ptr %slot561, align 8
  %p3314 = inttoptr i64 %v3312 to ptr
  %p3315 = inttoptr i64 %v3313 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3315, ptr %p3314, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3316 = load i64, ptr %slot9, align 8
  %p3317 = inttoptr i64 %v3316 to ptr
  store i32 0, ptr %p3317, align 4, !alias.scope !3, !noalias !4
  %v3318 = load i64, ptr %slot553, align 8
  %v3319 = load i64, ptr %slot20, align 8
  %p3320 = inttoptr i64 %v3319 to ptr
  store i64 %v3318, ptr %p3320, align 8, !alias.scope !3, !noalias !4
  %v3321 = load i64, ptr %slot20, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  %ld3323 = load i64, ptr %p3322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3323, ptr %slot577, align 8
  %v3324 = load i64, ptr %slot12, align 8
  store i64 %v3324, ptr %slot578, align 8
  %v3325 = load i64, ptr %slot577, align 8
  %v3326 = load i64, ptr %slot578, align 8
  %p3327 = inttoptr i64 %v3325 to ptr
  %p3328 = inttoptr i64 %v3326 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3328, ptr %p3327, i64 24, i1 false)
  %v3329 = load i64, ptr %slot7, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  store i32 2, ptr %p3330, align 4, !alias.scope !3, !noalias !4
  %v3331 = load i64, ptr %slot6, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  store i32 1, ptr %p3332, align 4, !alias.scope !3, !noalias !4
  %v3333 = load i64, ptr %slot578, align 8
  %v3334 = load i64, ptr %slot20, align 8
  %p3335 = inttoptr i64 %v3334 to ptr
  store i64 %v3333, ptr %p3335, align 8, !alias.scope !3, !noalias !4
  %v3336 = load i64, ptr %slot20, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  %ld3338 = load i64, ptr %p3337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3338, ptr %slot579, align 8
  %v3339 = load i64, ptr %slot20, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  %ld3341 = load i64, ptr %p3340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3341, ptr %slot580, align 8
  %v3342 = load i64, ptr %slot14, align 8
  store i64 %v3342, ptr %slot581, align 8
  %v3343 = load i64, ptr %slot37, align 8
  store i64 %v3343, ptr %slot582, align 8
  %v3344 = load i64, ptr %slot580, align 8
  %op3345 = add i64 %v3344, 8
  store i64 %op3345, ptr %slot583, align 8
  %v3346 = load i64, ptr %slot583, align 8
  %p3347 = inttoptr i64 %v3346 to ptr
  %ld3348 = load i64, ptr %p3347, align 8
  store i64 %ld3348, ptr %slot584, align 8
  %v3349 = load i64, ptr %slot584, align 8
  %cmp3350 = icmp ne i64 %v3349, 0
  %cv3351 = zext i1 %cmp3350 to i32
  store i32 %cv3351, ptr %slot585, align 8
  %v3352 = load i32, ptr %slot585, align 8
  %cv3353 = zext i32 %v3352 to i64
  %cond3354 = icmp ne i64 %cv3353, 0
  br i1 %cond3354, label %bb_rcmoveheader1205, label %bb_rcmovenext1205
bb_rcmoveheader1205:
  %v3355 = load i64, ptr %slot584, align 8
  %op3356 = sub i64 %v3355, 16
  store i64 %op3356, ptr %slot586, align 8
  %v3357 = load i64, ptr %slot584, align 8
  %p3358 = inttoptr i64 %v3357 to ptr
  %rgep3359 = getelementptr i8, ptr %p3358, i64 -16
  %ld3360 = load i64, ptr %rgep3359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3360, ptr %slot587, align 8
  %v3361 = load i64, ptr %slot587, align 8
  %op3362 = and i64 %v3361, 5764607523034234881
  store i64 %op3362, ptr %slot588, align 8
  %v3363 = load i64, ptr %slot588, align 8
  %cmp3364 = icmp ne i64 %v3363, 0
  %cv3365 = zext i1 %cmp3364 to i32
  store i32 %cv3365, ptr %slot589, align 8
  %v3366 = load i32, ptr %slot589, align 8
  %cv3367 = zext i32 %v3366 to i64
  %cond3368 = icmp ne i64 %cv3367, 0
  br i1 %cond3368, label %bb_rcmoveslow1202, label %bb_rcmovenext1205
bb_rcmovenext1205:
  %v3369 = load i64, ptr %slot580, align 8
  %v3370 = load i64, ptr %slot581, align 8
  %p3371 = inttoptr i64 %v3369 to ptr
  %p3372 = inttoptr i64 %v3370 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3372, ptr %p3371, i64 24, i1 false)
  %v3373 = load i64, ptr %slot580, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  store i64 0, ptr %p3374, align 8
  %v3375 = load i64, ptr %slot580, align 8
  %op3376 = add i64 %v3375, 8
  store i64 %op3376, ptr %slot590, align 8
  %v3377 = load i64, ptr %slot590, align 8
  %p3378 = inttoptr i64 %v3377 to ptr
  store i64 0, ptr %p3378, align 8
  %v3379 = load i64, ptr %slot580, align 8
  %op3380 = add i64 %v3379, 16
  store i64 %op3380, ptr %slot591, align 8
  %v3381 = load i64, ptr %slot591, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  store i64 0, ptr %p3382, align 8
  br label %bb_rcmoved1202
bb_rcmoveslow1202:
  %v3383 = load i64, ptr %slot36, align 8
  %v3384 = load i64, ptr %slot581, align 8
  %v3385 = load i64, ptr %slot580, align 8
  %v3386 = load i64, ptr %slot582, align 8
  %cv3387 = trunc i64 %v3386 to i32
  %call3388 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v3383, i64 %v3384, i64 %v3385, i32 %cv3387) nomerge, !dbg !182
  store i32 %call3388, ptr %slot592, align 8
  %v3389 = load i32, ptr %slot592, align 8
  %cv3390 = zext i32 %v3389 to i64
  %cond3391 = icmp ne i64 %cv3390, 0
  br i1 %cond3391, label %bb_rcsuccess1214, label %bb_rcfailure1214
bb_rcfailure1214:
  %v3392 = load i64, ptr %slot36, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  %call3394 = call i32 @myl_rc_take_failure(ptr %p3393) nomerge, !dbg !182
  store i32 %call3394, ptr %slot593, align 8
  %v3395 = load i64, ptr %slot1, align 8
  %p3396 = inttoptr i64 %v3395 to ptr
  %v3397 = load i32, ptr %slot593, align 8
  %call3398 = call i32 @myl_qbe_rc_status(ptr %p3396, i32 %v3397) nomerge, !dbg !182
  store i32 %call3398, ptr %slot594, align 8
  br label %bb_failure
bb_rcsuccess1214:
  br label %bb_rcmoved1202
bb_rcmoved1202:
  %v3399 = load i64, ptr %slot6, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  store i32 0, ptr %p3400, align 4, !alias.scope !3, !noalias !4
  %v3401 = load i64, ptr %slot10, align 8
  %p3402 = inttoptr i64 %v3401 to ptr
  store i32 2, ptr %p3402, align 4, !alias.scope !3, !noalias !4
  %v3403 = load i64, ptr %slot9, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  store i32 1, ptr %p3404, align 4, !alias.scope !3, !noalias !4
  %v3405 = load i64, ptr %slot14, align 8
  store i64 %v3405, ptr %slot595, align 8
  %v3406 = load i64, ptr %slot9, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  store i32 0, ptr %p3407, align 4, !alias.scope !3, !noalias !4
  %v3408 = load i64, ptr %slot6, align 8
  %p3409 = inttoptr i64 %v3408 to ptr
  %ld3410 = load i32, ptr %p3409, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3410, ptr %slot596, align 8
  %v3411 = load i32, ptr %slot596, align 8
  %cv3412 = zext i32 %v3411 to i64
  %cond3413 = icmp ne i64 %cv3412, 0
  br i1 %cond3413, label %bb_rcslotdrop1224, label %bb_rcslotdone1224
bb_rcslotdrop1224:
  %v3414 = load i64, ptr %slot6, align 8
  %p3415 = inttoptr i64 %v3414 to ptr
  store i32 0, ptr %p3415, align 4, !alias.scope !3, !noalias !4
  %v3416 = load i64, ptr %slot12, align 8
  store i64 %v3416, ptr %slot597, align 8
  %v3417 = load i64, ptr %slot7, align 8
  %p3418 = inttoptr i64 %v3417 to ptr
  %ld3419 = load i32, ptr %p3418, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3419, ptr %slot598, align 8
  %v3420 = load i32, ptr %slot598, align 8
  %op3421 = and i32 %v3420, 28
  store i32 %op3421, ptr %slot599, align 8
  %v3422 = load i32, ptr %slot599, align 8
  %cv3423 = zext i32 %v3422 to i64
  %cond3424 = icmp ne i64 %cv3423, 0
  br i1 %cond3424, label %bb_rcslotrole1224, label %bb_rcslotowner1224
bb_rcslotrole1224:
  %v3425 = load i64, ptr %slot36, align 8
  store i64 %v3425, ptr %slot600, align 8
  %v3426 = load i64, ptr %slot600, align 8
  %v3427 = load i64, ptr %slot597, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3426, i64 %v3427) nomerge, !dbg !182
  br label %bb_rcslotdone1224
bb_rcslotowner1224:
  %v3428 = load i64, ptr %slot36, align 8
  store i64 %v3428, ptr %slot601, align 8
  %v3429 = load i64, ptr %slot601, align 8
  %v3430 = load i64, ptr %slot597, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3429, i64 %v3430) nomerge, !dbg !182
  br label %bb_rcslotdone1224
bb_rcslotdone1224:
  %v3431 = load i64, ptr %slot595, align 8
  %p3432 = inttoptr i64 %v3431 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3432, i64 24, i1 false)
  ret void
bb_i65:
  %v3433 = load i64, ptr %slot20, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  store i64 0, ptr %p3434, align 8, !alias.scope !3, !noalias !4
  %v3435 = load i64, ptr %slot20, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  %ld3437 = load i64, ptr %p3436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3437, ptr %slot602, align 8
  %v3438 = load i64, ptr %slot602, align 8
  %cond3439 = icmp ne i64 %v3438, 0
  br i1 %cond3439, label %bb_success1287, label %bb_failed1287
bb_failed1287:
  %v3440 = load i64, ptr %slot1, align 8
  %p3441 = inttoptr i64 %v3440 to ptr
  call void @myl_qbe_fail_assert(ptr %p3441) nomerge, !dbg !184
  unreachable
bb_success1287:
  %v3442 = load i64, ptr %slot20, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  store i64 18446744073709551615, ptr %p3443, align 8, !alias.scope !3, !noalias !4
  %v3444 = load i64, ptr %slot1, align 8
  %call3445 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v3444) nomerge, !dbg !186
  store { i64, i64 } %call3445, ptr %callresult604, align 8
  %addr3446 = ptrtoint ptr %callresult604 to i64
  store i64 %addr3446, ptr %slot603, align 8
  %v3447 = load i64, ptr %slot603, align 8
  %v3448 = load i64, ptr %slot21, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  store i64 %v3447, ptr %p3449, align 8, !alias.scope !3, !noalias !4
  %v3450 = load i64, ptr %slot21, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %ld3452 = load i64, ptr %p3451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3452, ptr %slot605, align 8
  %v3453 = load i64, ptr %slot14, align 8
  store i64 %v3453, ptr %slot606, align 8
  %v3454 = load i64, ptr %slot605, align 8
  %v3455 = load i64, ptr %slot606, align 8
  %p3456 = inttoptr i64 %v3454 to ptr
  %p3457 = inttoptr i64 %v3455 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3457, ptr %p3456, i64 16, i1 false)
  %v3458 = load i64, ptr %slot10, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  store i32 2, ptr %p3459, align 4, !alias.scope !3, !noalias !4
  %v3460 = load i64, ptr %slot9, align 8
  %p3461 = inttoptr i64 %v3460 to ptr
  store i32 1, ptr %p3461, align 4, !alias.scope !3, !noalias !4
  %v3462 = load i64, ptr %slot13, align 8
  store i64 %v3462, ptr %slot607, align 8
  %v3463 = load i64, ptr %slot14, align 8
  store i64 %v3463, ptr %slot608, align 8
  %v3464 = load i64, ptr %slot608, align 8
  %v3465 = load i64, ptr %slot607, align 8
  %p3466 = inttoptr i64 %v3464 to ptr
  %p3467 = inttoptr i64 %v3465 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3467, ptr %p3466, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3468 = load i64, ptr %slot10, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  %ld3470 = load i32, ptr %p3469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3470, ptr %slot609, align 8
  %v3471 = load i64, ptr %slot9, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  store i32 0, ptr %p3472, align 4, !alias.scope !3, !noalias !4
  %v3473 = load i64, ptr %slot8, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  store i32 1, ptr %p3474, align 4, !alias.scope !3, !noalias !4
  %v3475 = load i64, ptr %slot607, align 8
  %v3476 = load i64, ptr %slot21, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  store i64 %v3475, ptr %p3477, align 8, !alias.scope !3, !noalias !4
  %v3478 = load i64, ptr %slot29, align 8
  store i64 %v3478, ptr %slot610, align 8
  %v3479 = load i64, ptr %slot610, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  store i64 0, ptr %p3480, align 8, !alias.scope !3, !noalias !4
  %v3481 = load i64, ptr %slot610, align 8
  %p3483 = inttoptr i64 %v3481 to ptr
  %gep3484 = getelementptr i8, ptr %p3483, i64 8
  %op3482 = ptrtoint ptr %gep3484 to i64
  store i64 %op3482, ptr %slot611, align 8
  %v3485 = load i64, ptr %slot611, align 8
  %p3486 = inttoptr i64 %v3485 to ptr
  store i64 0, ptr %p3486, align 8, !alias.scope !3, !noalias !4
  %v3487 = load i64, ptr %slot610, align 8
  %p3489 = inttoptr i64 %v3487 to ptr
  %gep3490 = getelementptr i8, ptr %p3489, i64 16
  %op3488 = ptrtoint ptr %gep3490 to i64
  store i64 %op3488, ptr %slot612, align 8
  %v3491 = load i64, ptr %slot612, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  store i64 0, ptr %p3492, align 8, !alias.scope !3, !noalias !4
  %v3493 = load i64, ptr %slot11, align 8
  %p3494 = inttoptr i64 %v3493 to ptr
  store i32 1, ptr %p3494, align 4, !alias.scope !3, !noalias !4
  %v3495 = load i64, ptr %slot37, align 8
  store i64 %v3495, ptr %slot613, align 8
  %v3496 = load i64, ptr %slot20, align 8
  store i64 %v3496, ptr %slot614, align 8
  %v3497 = load i64, ptr %slot610, align 8
  %p3499 = inttoptr i64 %v3497 to ptr
  %gep3500 = getelementptr i8, ptr %p3499, i64 0
  %op3498 = ptrtoint ptr %gep3500 to i64
  store i64 %op3498, ptr %slot615, align 8
  %v3501 = load i64, ptr %slot614, align 8
  %p3502 = inttoptr i64 %v3501 to ptr
  %ld3503 = load i64, ptr %p3502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3503, ptr %slot616, align 8
  %v3504 = load i64, ptr %slot616, align 8
  %v3505 = load i64, ptr %slot615, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  store i64 %v3504, ptr %p3506, align 8, !alias.scope !3, !noalias !4
  %v3507 = load i64, ptr %slot21, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %ld3509 = load i64, ptr %p3508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3509, ptr %slot617, align 8
  %v3510 = load i64, ptr %slot610, align 8
  %p3512 = inttoptr i64 %v3510 to ptr
  %gep3513 = getelementptr i8, ptr %p3512, i64 8
  %op3511 = ptrtoint ptr %gep3513 to i64
  store i64 %op3511, ptr %slot618, align 8
  %v3514 = load i64, ptr %slot21, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  %ld3516 = load i64, ptr %p3515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3516, ptr %slot619, align 8
  %v3517 = load i64, ptr %slot14, align 8
  store i64 %v3517, ptr %slot620, align 8
  %v3518 = load i64, ptr %slot37, align 8
  store i64 %v3518, ptr %slot621, align 8
  %v3519 = load i64, ptr %slot619, align 8
  %op3520 = add i64 %v3519, 0
  store i64 %op3520, ptr %slot622, align 8
  %v3521 = load i64, ptr %slot622, align 8
  %p3522 = inttoptr i64 %v3521 to ptr
  %ld3523 = load i64, ptr %p3522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3523, ptr %slot623, align 8
  %v3524 = load i64, ptr %slot623, align 8
  %cmp3525 = icmp ne i64 %v3524, 0
  %cv3526 = zext i1 %cmp3525 to i32
  store i32 %cv3526, ptr %slot624, align 8
  %v3527 = load i32, ptr %slot624, align 8
  %cv3528 = zext i32 %v3527 to i64
  %cond3529 = icmp ne i64 %cv3528, 0
  br i1 %cond3529, label %bb_rcmoveheader1318, label %bb_rcmovenext1318
bb_rcmoveheader1318:
  %v3530 = load i64, ptr %slot623, align 8
  %op3531 = sub i64 %v3530, 16
  store i64 %op3531, ptr %slot625, align 8
  %v3532 = load i64, ptr %slot623, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  %rgep3534 = getelementptr i8, ptr %p3533, i64 -16
  %ld3535 = load i64, ptr %rgep3534, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3535, ptr %slot626, align 8
  %v3536 = load i64, ptr %slot626, align 8
  %op3537 = and i64 %v3536, 5764607523034234881
  store i64 %op3537, ptr %slot627, align 8
  %v3538 = load i64, ptr %slot627, align 8
  %cmp3539 = icmp ne i64 %v3538, 0
  %cv3540 = zext i1 %cmp3539 to i32
  store i32 %cv3540, ptr %slot628, align 8
  %v3541 = load i32, ptr %slot628, align 8
  %cv3542 = zext i32 %v3541 to i64
  %cond3543 = icmp ne i64 %cv3542, 0
  br i1 %cond3543, label %bb_rcmoveslow1315, label %bb_rcmovenext1318
bb_rcmovenext1318:
  %v3544 = load i64, ptr %slot619, align 8
  %v3545 = load i64, ptr %slot620, align 8
  %p3546 = inttoptr i64 %v3544 to ptr
  %p3547 = inttoptr i64 %v3545 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3547, ptr %p3546, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3548 = load i64, ptr %slot619, align 8
  %p3549 = inttoptr i64 %v3548 to ptr
  store i64 0, ptr %p3549, align 8, !alias.scope !3, !noalias !4
  %v3550 = load i64, ptr %slot619, align 8
  %op3551 = add i64 %v3550, 8
  store i64 %op3551, ptr %slot629, align 8
  %v3552 = load i64, ptr %slot629, align 8
  %p3553 = inttoptr i64 %v3552 to ptr
  store i64 0, ptr %p3553, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1315
bb_rcmoveslow1315:
  %v3554 = load i64, ptr %slot36, align 8
  %v3555 = load i64, ptr %slot620, align 8
  %v3556 = load i64, ptr %slot619, align 8
  %v3557 = load i64, ptr %slot621, align 8
  %cv3558 = trunc i64 %v3557 to i32
  %call3559 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v3554, i64 %v3555, i64 %v3556, i32 %cv3558) nomerge, !dbg !188
  store i32 %call3559, ptr %slot630, align 8
  %v3560 = load i32, ptr %slot630, align 8
  %cv3561 = zext i32 %v3560 to i64
  %cond3562 = icmp ne i64 %cv3561, 0
  br i1 %cond3562, label %bb_rcsuccess1326, label %bb_rcfailure1326
bb_rcfailure1326:
  %v3563 = load i64, ptr %slot36, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %call3565 = call i32 @myl_rc_take_failure(ptr %p3564) nomerge, !dbg !188
  store i32 %call3565, ptr %slot631, align 8
  %v3566 = load i64, ptr %slot1, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  %v3568 = load i32, ptr %slot631, align 8
  %call3569 = call i32 @myl_qbe_rc_status(ptr %p3567, i32 %v3568) nomerge, !dbg !188
  store i32 %call3569, ptr %slot632, align 8
  br label %bb_failure
bb_rcsuccess1326:
  br label %bb_rcmoved1315
bb_rcmoved1315:
  %v3570 = load i64, ptr %slot8, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  store i32 0, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  %v3572 = load i64, ptr %slot10, align 8
  %p3573 = inttoptr i64 %v3572 to ptr
  store i32 2, ptr %p3573, align 4, !alias.scope !3, !noalias !4
  %v3574 = load i64, ptr %slot9, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  store i32 1, ptr %p3575, align 4, !alias.scope !3, !noalias !4
  %v3576 = load i64, ptr %slot14, align 8
  store i64 %v3576, ptr %slot633, align 8
  %v3577 = load i64, ptr %slot633, align 8
  %v3578 = load i64, ptr %slot618, align 8
  %p3579 = inttoptr i64 %v3577 to ptr
  %p3580 = inttoptr i64 %v3578 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3580, ptr %p3579, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3581 = load i64, ptr %slot9, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  store i32 0, ptr %p3582, align 4, !alias.scope !3, !noalias !4
  %v3583 = load i64, ptr %slot610, align 8
  %v3584 = load i64, ptr %slot20, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  store i64 %v3583, ptr %p3585, align 8, !alias.scope !3, !noalias !4
  %v3586 = load i64, ptr %slot20, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  %ld3588 = load i64, ptr %p3587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3588, ptr %slot634, align 8
  %v3589 = load i64, ptr %slot12, align 8
  store i64 %v3589, ptr %slot635, align 8
  %v3590 = load i64, ptr %slot634, align 8
  %v3591 = load i64, ptr %slot635, align 8
  %p3592 = inttoptr i64 %v3590 to ptr
  %p3593 = inttoptr i64 %v3591 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3593, ptr %p3592, i64 24, i1 false)
  %v3594 = load i64, ptr %slot7, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  store i32 2, ptr %p3595, align 4, !alias.scope !3, !noalias !4
  %v3596 = load i64, ptr %slot6, align 8
  %p3597 = inttoptr i64 %v3596 to ptr
  store i32 1, ptr %p3597, align 4, !alias.scope !3, !noalias !4
  %v3598 = load i64, ptr %slot635, align 8
  %v3599 = load i64, ptr %slot20, align 8
  %p3600 = inttoptr i64 %v3599 to ptr
  store i64 %v3598, ptr %p3600, align 8, !alias.scope !3, !noalias !4
  %v3601 = load i64, ptr %slot20, align 8
  %p3602 = inttoptr i64 %v3601 to ptr
  %ld3603 = load i64, ptr %p3602, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3603, ptr %slot636, align 8
  %v3604 = load i64, ptr %slot20, align 8
  %p3605 = inttoptr i64 %v3604 to ptr
  %ld3606 = load i64, ptr %p3605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3606, ptr %slot637, align 8
  %v3607 = load i64, ptr %slot14, align 8
  store i64 %v3607, ptr %slot638, align 8
  %v3608 = load i64, ptr %slot37, align 8
  store i64 %v3608, ptr %slot639, align 8
  %v3609 = load i64, ptr %slot637, align 8
  %op3610 = add i64 %v3609, 8
  store i64 %op3610, ptr %slot640, align 8
  %v3611 = load i64, ptr %slot640, align 8
  %p3612 = inttoptr i64 %v3611 to ptr
  %ld3613 = load i64, ptr %p3612, align 8
  store i64 %ld3613, ptr %slot641, align 8
  %v3614 = load i64, ptr %slot641, align 8
  %cmp3615 = icmp ne i64 %v3614, 0
  %cv3616 = zext i1 %cmp3615 to i32
  store i32 %cv3616, ptr %slot642, align 8
  %v3617 = load i32, ptr %slot642, align 8
  %cv3618 = zext i32 %v3617 to i64
  %cond3619 = icmp ne i64 %cv3618, 0
  br i1 %cond3619, label %bb_rcmoveheader1345, label %bb_rcmovenext1345
bb_rcmoveheader1345:
  %v3620 = load i64, ptr %slot641, align 8
  %op3621 = sub i64 %v3620, 16
  store i64 %op3621, ptr %slot643, align 8
  %v3622 = load i64, ptr %slot641, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  %rgep3624 = getelementptr i8, ptr %p3623, i64 -16
  %ld3625 = load i64, ptr %rgep3624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3625, ptr %slot644, align 8
  %v3626 = load i64, ptr %slot644, align 8
  %op3627 = and i64 %v3626, 5764607523034234881
  store i64 %op3627, ptr %slot645, align 8
  %v3628 = load i64, ptr %slot645, align 8
  %cmp3629 = icmp ne i64 %v3628, 0
  %cv3630 = zext i1 %cmp3629 to i32
  store i32 %cv3630, ptr %slot646, align 8
  %v3631 = load i32, ptr %slot646, align 8
  %cv3632 = zext i32 %v3631 to i64
  %cond3633 = icmp ne i64 %cv3632, 0
  br i1 %cond3633, label %bb_rcmoveslow1342, label %bb_rcmovenext1345
bb_rcmovenext1345:
  %v3634 = load i64, ptr %slot637, align 8
  %v3635 = load i64, ptr %slot638, align 8
  %p3636 = inttoptr i64 %v3634 to ptr
  %p3637 = inttoptr i64 %v3635 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3637, ptr %p3636, i64 24, i1 false)
  %v3638 = load i64, ptr %slot637, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  store i64 0, ptr %p3639, align 8
  %v3640 = load i64, ptr %slot637, align 8
  %op3641 = add i64 %v3640, 8
  store i64 %op3641, ptr %slot647, align 8
  %v3642 = load i64, ptr %slot647, align 8
  %p3643 = inttoptr i64 %v3642 to ptr
  store i64 0, ptr %p3643, align 8
  %v3644 = load i64, ptr %slot637, align 8
  %op3645 = add i64 %v3644, 16
  store i64 %op3645, ptr %slot648, align 8
  %v3646 = load i64, ptr %slot648, align 8
  %p3647 = inttoptr i64 %v3646 to ptr
  store i64 0, ptr %p3647, align 8
  br label %bb_rcmoved1342
bb_rcmoveslow1342:
  %v3648 = load i64, ptr %slot36, align 8
  %v3649 = load i64, ptr %slot638, align 8
  %v3650 = load i64, ptr %slot637, align 8
  %v3651 = load i64, ptr %slot639, align 8
  %cv3652 = trunc i64 %v3651 to i32
  %call3653 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v3648, i64 %v3649, i64 %v3650, i32 %cv3652) nomerge, !dbg !190
  store i32 %call3653, ptr %slot649, align 8
  %v3654 = load i32, ptr %slot649, align 8
  %cv3655 = zext i32 %v3654 to i64
  %cond3656 = icmp ne i64 %cv3655, 0
  br i1 %cond3656, label %bb_rcsuccess1354, label %bb_rcfailure1354
bb_rcfailure1354:
  %v3657 = load i64, ptr %slot36, align 8
  %p3658 = inttoptr i64 %v3657 to ptr
  %call3659 = call i32 @myl_rc_take_failure(ptr %p3658) nomerge, !dbg !190
  store i32 %call3659, ptr %slot650, align 8
  %v3660 = load i64, ptr %slot1, align 8
  %p3661 = inttoptr i64 %v3660 to ptr
  %v3662 = load i32, ptr %slot650, align 8
  %call3663 = call i32 @myl_qbe_rc_status(ptr %p3661, i32 %v3662) nomerge, !dbg !190
  store i32 %call3663, ptr %slot651, align 8
  br label %bb_failure
bb_rcsuccess1354:
  br label %bb_rcmoved1342
bb_rcmoved1342:
  %v3664 = load i64, ptr %slot6, align 8
  %p3665 = inttoptr i64 %v3664 to ptr
  store i32 0, ptr %p3665, align 4, !alias.scope !3, !noalias !4
  %v3666 = load i64, ptr %slot10, align 8
  %p3667 = inttoptr i64 %v3666 to ptr
  store i32 2, ptr %p3667, align 4, !alias.scope !3, !noalias !4
  %v3668 = load i64, ptr %slot9, align 8
  %p3669 = inttoptr i64 %v3668 to ptr
  store i32 1, ptr %p3669, align 4, !alias.scope !3, !noalias !4
  %v3670 = load i64, ptr %slot14, align 8
  store i64 %v3670, ptr %slot652, align 8
  %v3671 = load i64, ptr %slot9, align 8
  %p3672 = inttoptr i64 %v3671 to ptr
  store i32 0, ptr %p3672, align 4, !alias.scope !3, !noalias !4
  %v3673 = load i64, ptr %slot6, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %ld3675 = load i32, ptr %p3674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3675, ptr %slot653, align 8
  %v3676 = load i32, ptr %slot653, align 8
  %cv3677 = zext i32 %v3676 to i64
  %cond3678 = icmp ne i64 %cv3677, 0
  br i1 %cond3678, label %bb_rcslotdrop1364, label %bb_rcslotdone1364
bb_rcslotdrop1364:
  %v3679 = load i64, ptr %slot6, align 8
  %p3680 = inttoptr i64 %v3679 to ptr
  store i32 0, ptr %p3680, align 4, !alias.scope !3, !noalias !4
  %v3681 = load i64, ptr %slot12, align 8
  store i64 %v3681, ptr %slot654, align 8
  %v3682 = load i64, ptr %slot7, align 8
  %p3683 = inttoptr i64 %v3682 to ptr
  %ld3684 = load i32, ptr %p3683, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3684, ptr %slot655, align 8
  %v3685 = load i32, ptr %slot655, align 8
  %op3686 = and i32 %v3685, 28
  store i32 %op3686, ptr %slot656, align 8
  %v3687 = load i32, ptr %slot656, align 8
  %cv3688 = zext i32 %v3687 to i64
  %cond3689 = icmp ne i64 %cv3688, 0
  br i1 %cond3689, label %bb_rcslotrole1364, label %bb_rcslotowner1364
bb_rcslotrole1364:
  %v3690 = load i64, ptr %slot36, align 8
  store i64 %v3690, ptr %slot657, align 8
  %v3691 = load i64, ptr %slot657, align 8
  %v3692 = load i64, ptr %slot654, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3691, i64 %v3692) nomerge, !dbg !190
  br label %bb_rcslotdone1364
bb_rcslotowner1364:
  %v3693 = load i64, ptr %slot36, align 8
  store i64 %v3693, ptr %slot658, align 8
  %v3694 = load i64, ptr %slot658, align 8
  %v3695 = load i64, ptr %slot654, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3694, i64 %v3695) nomerge, !dbg !190
  br label %bb_rcslotdone1364
bb_rcslotdone1364:
  %v3696 = load i64, ptr %slot652, align 8
  %p3697 = inttoptr i64 %v3696 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3697, i64 24, i1 false)
  ret void
bb_i71:
  %v3698 = load i64, ptr %slot20, align 8
  %p3699 = inttoptr i64 %v3698 to ptr
  store i64 0, ptr %p3699, align 8, !alias.scope !3, !noalias !4
  %v3700 = load i64, ptr %slot20, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %ld3702 = load i64, ptr %p3701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3702, ptr %slot659, align 8
  %v3703 = load i64, ptr %slot659, align 8
  %cond3704 = icmp ne i64 %v3703, 0
  br i1 %cond3704, label %bb_success1427, label %bb_failed1427
bb_failed1427:
  %v3705 = load i64, ptr %slot1, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  call void @myl_qbe_fail_assert(ptr %p3706) nomerge, !dbg !192
  unreachable
bb_success1427:
  %v3707 = load i64, ptr %slot20, align 8
  %p3708 = inttoptr i64 %v3707 to ptr
  store i64 18446744073709551615, ptr %p3708, align 8, !alias.scope !3, !noalias !4
  %v3709 = load i64, ptr %slot1, align 8
  %call3710 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v3709) nomerge, !dbg !194
  store { i64, i64 } %call3710, ptr %callresult661, align 8
  %addr3711 = ptrtoint ptr %callresult661 to i64
  store i64 %addr3711, ptr %slot660, align 8
  %v3712 = load i64, ptr %slot660, align 8
  %v3713 = load i64, ptr %slot21, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  store i64 %v3712, ptr %p3714, align 8, !alias.scope !3, !noalias !4
  %v3715 = load i64, ptr %slot21, align 8
  %p3716 = inttoptr i64 %v3715 to ptr
  %ld3717 = load i64, ptr %p3716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3717, ptr %slot662, align 8
  %v3718 = load i64, ptr %slot14, align 8
  store i64 %v3718, ptr %slot663, align 8
  %v3719 = load i64, ptr %slot662, align 8
  %v3720 = load i64, ptr %slot663, align 8
  %p3721 = inttoptr i64 %v3719 to ptr
  %p3722 = inttoptr i64 %v3720 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3722, ptr %p3721, i64 16, i1 false)
  %v3723 = load i64, ptr %slot10, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  store i32 2, ptr %p3724, align 4, !alias.scope !3, !noalias !4
  %v3725 = load i64, ptr %slot9, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  store i32 1, ptr %p3726, align 4, !alias.scope !3, !noalias !4
  %v3727 = load i64, ptr %slot13, align 8
  store i64 %v3727, ptr %slot664, align 8
  %v3728 = load i64, ptr %slot14, align 8
  store i64 %v3728, ptr %slot665, align 8
  %v3729 = load i64, ptr %slot665, align 8
  %v3730 = load i64, ptr %slot664, align 8
  %p3731 = inttoptr i64 %v3729 to ptr
  %p3732 = inttoptr i64 %v3730 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3732, ptr %p3731, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3733 = load i64, ptr %slot10, align 8
  %p3734 = inttoptr i64 %v3733 to ptr
  %ld3735 = load i32, ptr %p3734, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3735, ptr %slot666, align 8
  %v3736 = load i64, ptr %slot9, align 8
  %p3737 = inttoptr i64 %v3736 to ptr
  store i32 0, ptr %p3737, align 4, !alias.scope !3, !noalias !4
  %v3738 = load i64, ptr %slot8, align 8
  %p3739 = inttoptr i64 %v3738 to ptr
  store i32 1, ptr %p3739, align 4, !alias.scope !3, !noalias !4
  %v3740 = load i64, ptr %slot664, align 8
  %v3741 = load i64, ptr %slot21, align 8
  %p3742 = inttoptr i64 %v3741 to ptr
  store i64 %v3740, ptr %p3742, align 8, !alias.scope !3, !noalias !4
  %v3743 = load i64, ptr %slot30, align 8
  store i64 %v3743, ptr %slot667, align 8
  %v3744 = load i64, ptr %slot667, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  store i64 0, ptr %p3745, align 8, !alias.scope !3, !noalias !4
  %v3746 = load i64, ptr %slot667, align 8
  %p3748 = inttoptr i64 %v3746 to ptr
  %gep3749 = getelementptr i8, ptr %p3748, i64 8
  %op3747 = ptrtoint ptr %gep3749 to i64
  store i64 %op3747, ptr %slot668, align 8
  %v3750 = load i64, ptr %slot668, align 8
  %p3751 = inttoptr i64 %v3750 to ptr
  store i64 0, ptr %p3751, align 8, !alias.scope !3, !noalias !4
  %v3752 = load i64, ptr %slot667, align 8
  %p3754 = inttoptr i64 %v3752 to ptr
  %gep3755 = getelementptr i8, ptr %p3754, i64 16
  %op3753 = ptrtoint ptr %gep3755 to i64
  store i64 %op3753, ptr %slot669, align 8
  %v3756 = load i64, ptr %slot669, align 8
  %p3757 = inttoptr i64 %v3756 to ptr
  store i64 0, ptr %p3757, align 8, !alias.scope !3, !noalias !4
  %v3758 = load i64, ptr %slot11, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  store i32 1, ptr %p3759, align 4, !alias.scope !3, !noalias !4
  %v3760 = load i64, ptr %slot37, align 8
  store i64 %v3760, ptr %slot670, align 8
  %v3761 = load i64, ptr %slot20, align 8
  store i64 %v3761, ptr %slot671, align 8
  %v3762 = load i64, ptr %slot667, align 8
  %p3764 = inttoptr i64 %v3762 to ptr
  %gep3765 = getelementptr i8, ptr %p3764, i64 0
  %op3763 = ptrtoint ptr %gep3765 to i64
  store i64 %op3763, ptr %slot672, align 8
  %v3766 = load i64, ptr %slot671, align 8
  %p3767 = inttoptr i64 %v3766 to ptr
  %ld3768 = load i64, ptr %p3767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3768, ptr %slot673, align 8
  %v3769 = load i64, ptr %slot673, align 8
  %v3770 = load i64, ptr %slot672, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  store i64 %v3769, ptr %p3771, align 8, !alias.scope !3, !noalias !4
  %v3772 = load i64, ptr %slot21, align 8
  %p3773 = inttoptr i64 %v3772 to ptr
  %ld3774 = load i64, ptr %p3773, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3774, ptr %slot674, align 8
  %v3775 = load i64, ptr %slot667, align 8
  %p3777 = inttoptr i64 %v3775 to ptr
  %gep3778 = getelementptr i8, ptr %p3777, i64 8
  %op3776 = ptrtoint ptr %gep3778 to i64
  store i64 %op3776, ptr %slot675, align 8
  %v3779 = load i64, ptr %slot21, align 8
  %p3780 = inttoptr i64 %v3779 to ptr
  %ld3781 = load i64, ptr %p3780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3781, ptr %slot676, align 8
  %v3782 = load i64, ptr %slot14, align 8
  store i64 %v3782, ptr %slot677, align 8
  %v3783 = load i64, ptr %slot37, align 8
  store i64 %v3783, ptr %slot678, align 8
  %v3784 = load i64, ptr %slot676, align 8
  %op3785 = add i64 %v3784, 0
  store i64 %op3785, ptr %slot679, align 8
  %v3786 = load i64, ptr %slot679, align 8
  %p3787 = inttoptr i64 %v3786 to ptr
  %ld3788 = load i64, ptr %p3787, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3788, ptr %slot680, align 8
  %v3789 = load i64, ptr %slot680, align 8
  %cmp3790 = icmp ne i64 %v3789, 0
  %cv3791 = zext i1 %cmp3790 to i32
  store i32 %cv3791, ptr %slot681, align 8
  %v3792 = load i32, ptr %slot681, align 8
  %cv3793 = zext i32 %v3792 to i64
  %cond3794 = icmp ne i64 %cv3793, 0
  br i1 %cond3794, label %bb_rcmoveheader1458, label %bb_rcmovenext1458
bb_rcmoveheader1458:
  %v3795 = load i64, ptr %slot680, align 8
  %op3796 = sub i64 %v3795, 16
  store i64 %op3796, ptr %slot682, align 8
  %v3797 = load i64, ptr %slot680, align 8
  %p3798 = inttoptr i64 %v3797 to ptr
  %rgep3799 = getelementptr i8, ptr %p3798, i64 -16
  %ld3800 = load i64, ptr %rgep3799, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3800, ptr %slot683, align 8
  %v3801 = load i64, ptr %slot683, align 8
  %op3802 = and i64 %v3801, 5764607523034234881
  store i64 %op3802, ptr %slot684, align 8
  %v3803 = load i64, ptr %slot684, align 8
  %cmp3804 = icmp ne i64 %v3803, 0
  %cv3805 = zext i1 %cmp3804 to i32
  store i32 %cv3805, ptr %slot685, align 8
  %v3806 = load i32, ptr %slot685, align 8
  %cv3807 = zext i32 %v3806 to i64
  %cond3808 = icmp ne i64 %cv3807, 0
  br i1 %cond3808, label %bb_rcmoveslow1455, label %bb_rcmovenext1458
bb_rcmovenext1458:
  %v3809 = load i64, ptr %slot676, align 8
  %v3810 = load i64, ptr %slot677, align 8
  %p3811 = inttoptr i64 %v3809 to ptr
  %p3812 = inttoptr i64 %v3810 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3812, ptr %p3811, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3813 = load i64, ptr %slot676, align 8
  %p3814 = inttoptr i64 %v3813 to ptr
  store i64 0, ptr %p3814, align 8, !alias.scope !3, !noalias !4
  %v3815 = load i64, ptr %slot676, align 8
  %op3816 = add i64 %v3815, 8
  store i64 %op3816, ptr %slot686, align 8
  %v3817 = load i64, ptr %slot686, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  store i64 0, ptr %p3818, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1455
bb_rcmoveslow1455:
  %v3819 = load i64, ptr %slot36, align 8
  %v3820 = load i64, ptr %slot677, align 8
  %v3821 = load i64, ptr %slot676, align 8
  %v3822 = load i64, ptr %slot678, align 8
  %cv3823 = trunc i64 %v3822 to i32
  %call3824 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v3819, i64 %v3820, i64 %v3821, i32 %cv3823) nomerge, !dbg !196
  store i32 %call3824, ptr %slot687, align 8
  %v3825 = load i32, ptr %slot687, align 8
  %cv3826 = zext i32 %v3825 to i64
  %cond3827 = icmp ne i64 %cv3826, 0
  br i1 %cond3827, label %bb_rcsuccess1466, label %bb_rcfailure1466
bb_rcfailure1466:
  %v3828 = load i64, ptr %slot36, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  %call3830 = call i32 @myl_rc_take_failure(ptr %p3829) nomerge, !dbg !196
  store i32 %call3830, ptr %slot688, align 8
  %v3831 = load i64, ptr %slot1, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %v3833 = load i32, ptr %slot688, align 8
  %call3834 = call i32 @myl_qbe_rc_status(ptr %p3832, i32 %v3833) nomerge, !dbg !196
  store i32 %call3834, ptr %slot689, align 8
  br label %bb_failure
bb_rcsuccess1466:
  br label %bb_rcmoved1455
bb_rcmoved1455:
  %v3835 = load i64, ptr %slot8, align 8
  %p3836 = inttoptr i64 %v3835 to ptr
  store i32 0, ptr %p3836, align 4, !alias.scope !3, !noalias !4
  %v3837 = load i64, ptr %slot10, align 8
  %p3838 = inttoptr i64 %v3837 to ptr
  store i32 2, ptr %p3838, align 4, !alias.scope !3, !noalias !4
  %v3839 = load i64, ptr %slot9, align 8
  %p3840 = inttoptr i64 %v3839 to ptr
  store i32 1, ptr %p3840, align 4, !alias.scope !3, !noalias !4
  %v3841 = load i64, ptr %slot14, align 8
  store i64 %v3841, ptr %slot690, align 8
  %v3842 = load i64, ptr %slot690, align 8
  %v3843 = load i64, ptr %slot675, align 8
  %p3844 = inttoptr i64 %v3842 to ptr
  %p3845 = inttoptr i64 %v3843 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3845, ptr %p3844, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3846 = load i64, ptr %slot9, align 8
  %p3847 = inttoptr i64 %v3846 to ptr
  store i32 0, ptr %p3847, align 4, !alias.scope !3, !noalias !4
  %v3848 = load i64, ptr %slot667, align 8
  %v3849 = load i64, ptr %slot20, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  store i64 %v3848, ptr %p3850, align 8, !alias.scope !3, !noalias !4
  %v3851 = load i64, ptr %slot20, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  %ld3853 = load i64, ptr %p3852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3853, ptr %slot691, align 8
  %v3854 = load i64, ptr %slot12, align 8
  store i64 %v3854, ptr %slot692, align 8
  %v3855 = load i64, ptr %slot691, align 8
  %v3856 = load i64, ptr %slot692, align 8
  %p3857 = inttoptr i64 %v3855 to ptr
  %p3858 = inttoptr i64 %v3856 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3858, ptr %p3857, i64 24, i1 false)
  %v3859 = load i64, ptr %slot7, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  store i32 2, ptr %p3860, align 4, !alias.scope !3, !noalias !4
  %v3861 = load i64, ptr %slot6, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  store i32 1, ptr %p3862, align 4, !alias.scope !3, !noalias !4
  %v3863 = load i64, ptr %slot692, align 8
  %v3864 = load i64, ptr %slot20, align 8
  %p3865 = inttoptr i64 %v3864 to ptr
  store i64 %v3863, ptr %p3865, align 8, !alias.scope !3, !noalias !4
  %v3866 = load i64, ptr %slot20, align 8
  %p3867 = inttoptr i64 %v3866 to ptr
  %ld3868 = load i64, ptr %p3867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3868, ptr %slot693, align 8
  %v3869 = load i64, ptr %slot20, align 8
  %p3870 = inttoptr i64 %v3869 to ptr
  %ld3871 = load i64, ptr %p3870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3871, ptr %slot694, align 8
  %v3872 = load i64, ptr %slot14, align 8
  store i64 %v3872, ptr %slot695, align 8
  %v3873 = load i64, ptr %slot37, align 8
  store i64 %v3873, ptr %slot696, align 8
  %v3874 = load i64, ptr %slot694, align 8
  %op3875 = add i64 %v3874, 8
  store i64 %op3875, ptr %slot697, align 8
  %v3876 = load i64, ptr %slot697, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  %ld3878 = load i64, ptr %p3877, align 8
  store i64 %ld3878, ptr %slot698, align 8
  %v3879 = load i64, ptr %slot698, align 8
  %cmp3880 = icmp ne i64 %v3879, 0
  %cv3881 = zext i1 %cmp3880 to i32
  store i32 %cv3881, ptr %slot699, align 8
  %v3882 = load i32, ptr %slot699, align 8
  %cv3883 = zext i32 %v3882 to i64
  %cond3884 = icmp ne i64 %cv3883, 0
  br i1 %cond3884, label %bb_rcmoveheader1485, label %bb_rcmovenext1485
bb_rcmoveheader1485:
  %v3885 = load i64, ptr %slot698, align 8
  %op3886 = sub i64 %v3885, 16
  store i64 %op3886, ptr %slot700, align 8
  %v3887 = load i64, ptr %slot698, align 8
  %p3888 = inttoptr i64 %v3887 to ptr
  %rgep3889 = getelementptr i8, ptr %p3888, i64 -16
  %ld3890 = load i64, ptr %rgep3889, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3890, ptr %slot701, align 8
  %v3891 = load i64, ptr %slot701, align 8
  %op3892 = and i64 %v3891, 5764607523034234881
  store i64 %op3892, ptr %slot702, align 8
  %v3893 = load i64, ptr %slot702, align 8
  %cmp3894 = icmp ne i64 %v3893, 0
  %cv3895 = zext i1 %cmp3894 to i32
  store i32 %cv3895, ptr %slot703, align 8
  %v3896 = load i32, ptr %slot703, align 8
  %cv3897 = zext i32 %v3896 to i64
  %cond3898 = icmp ne i64 %cv3897, 0
  br i1 %cond3898, label %bb_rcmoveslow1482, label %bb_rcmovenext1485
bb_rcmovenext1485:
  %v3899 = load i64, ptr %slot694, align 8
  %v3900 = load i64, ptr %slot695, align 8
  %p3901 = inttoptr i64 %v3899 to ptr
  %p3902 = inttoptr i64 %v3900 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3902, ptr %p3901, i64 24, i1 false)
  %v3903 = load i64, ptr %slot694, align 8
  %p3904 = inttoptr i64 %v3903 to ptr
  store i64 0, ptr %p3904, align 8
  %v3905 = load i64, ptr %slot694, align 8
  %op3906 = add i64 %v3905, 8
  store i64 %op3906, ptr %slot704, align 8
  %v3907 = load i64, ptr %slot704, align 8
  %p3908 = inttoptr i64 %v3907 to ptr
  store i64 0, ptr %p3908, align 8
  %v3909 = load i64, ptr %slot694, align 8
  %op3910 = add i64 %v3909, 16
  store i64 %op3910, ptr %slot705, align 8
  %v3911 = load i64, ptr %slot705, align 8
  %p3912 = inttoptr i64 %v3911 to ptr
  store i64 0, ptr %p3912, align 8
  br label %bb_rcmoved1482
bb_rcmoveslow1482:
  %v3913 = load i64, ptr %slot36, align 8
  %v3914 = load i64, ptr %slot695, align 8
  %v3915 = load i64, ptr %slot694, align 8
  %v3916 = load i64, ptr %slot696, align 8
  %cv3917 = trunc i64 %v3916 to i32
  %call3918 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v3913, i64 %v3914, i64 %v3915, i32 %cv3917) nomerge, !dbg !198
  store i32 %call3918, ptr %slot706, align 8
  %v3919 = load i32, ptr %slot706, align 8
  %cv3920 = zext i32 %v3919 to i64
  %cond3921 = icmp ne i64 %cv3920, 0
  br i1 %cond3921, label %bb_rcsuccess1494, label %bb_rcfailure1494
bb_rcfailure1494:
  %v3922 = load i64, ptr %slot36, align 8
  %p3923 = inttoptr i64 %v3922 to ptr
  %call3924 = call i32 @myl_rc_take_failure(ptr %p3923) nomerge, !dbg !198
  store i32 %call3924, ptr %slot707, align 8
  %v3925 = load i64, ptr %slot1, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  %v3927 = load i32, ptr %slot707, align 8
  %call3928 = call i32 @myl_qbe_rc_status(ptr %p3926, i32 %v3927) nomerge, !dbg !198
  store i32 %call3928, ptr %slot708, align 8
  br label %bb_failure
bb_rcsuccess1494:
  br label %bb_rcmoved1482
bb_rcmoved1482:
  %v3929 = load i64, ptr %slot6, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  store i32 0, ptr %p3930, align 4, !alias.scope !3, !noalias !4
  %v3931 = load i64, ptr %slot10, align 8
  %p3932 = inttoptr i64 %v3931 to ptr
  store i32 2, ptr %p3932, align 4, !alias.scope !3, !noalias !4
  %v3933 = load i64, ptr %slot9, align 8
  %p3934 = inttoptr i64 %v3933 to ptr
  store i32 1, ptr %p3934, align 4, !alias.scope !3, !noalias !4
  %v3935 = load i64, ptr %slot14, align 8
  store i64 %v3935, ptr %slot709, align 8
  %v3936 = load i64, ptr %slot9, align 8
  %p3937 = inttoptr i64 %v3936 to ptr
  store i32 0, ptr %p3937, align 4, !alias.scope !3, !noalias !4
  %v3938 = load i64, ptr %slot6, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  %ld3940 = load i32, ptr %p3939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3940, ptr %slot710, align 8
  %v3941 = load i32, ptr %slot710, align 8
  %cv3942 = zext i32 %v3941 to i64
  %cond3943 = icmp ne i64 %cv3942, 0
  br i1 %cond3943, label %bb_rcslotdrop1504, label %bb_rcslotdone1504
bb_rcslotdrop1504:
  %v3944 = load i64, ptr %slot6, align 8
  %p3945 = inttoptr i64 %v3944 to ptr
  store i32 0, ptr %p3945, align 4, !alias.scope !3, !noalias !4
  %v3946 = load i64, ptr %slot12, align 8
  store i64 %v3946, ptr %slot711, align 8
  %v3947 = load i64, ptr %slot7, align 8
  %p3948 = inttoptr i64 %v3947 to ptr
  %ld3949 = load i32, ptr %p3948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3949, ptr %slot712, align 8
  %v3950 = load i32, ptr %slot712, align 8
  %op3951 = and i32 %v3950, 28
  store i32 %op3951, ptr %slot713, align 8
  %v3952 = load i32, ptr %slot713, align 8
  %cv3953 = zext i32 %v3952 to i64
  %cond3954 = icmp ne i64 %cv3953, 0
  br i1 %cond3954, label %bb_rcslotrole1504, label %bb_rcslotowner1504
bb_rcslotrole1504:
  %v3955 = load i64, ptr %slot36, align 8
  store i64 %v3955, ptr %slot714, align 8
  %v3956 = load i64, ptr %slot714, align 8
  %v3957 = load i64, ptr %slot711, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v3956, i64 %v3957) nomerge, !dbg !198
  br label %bb_rcslotdone1504
bb_rcslotowner1504:
  %v3958 = load i64, ptr %slot36, align 8
  store i64 %v3958, ptr %slot715, align 8
  %v3959 = load i64, ptr %slot715, align 8
  %v3960 = load i64, ptr %slot711, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v3959, i64 %v3960) nomerge, !dbg !198
  br label %bb_rcslotdone1504
bb_rcslotdone1504:
  %v3961 = load i64, ptr %slot709, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3962, i64 24, i1 false)
  ret void
bb_i77:
  %v3963 = load i64, ptr %slot20, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  store i64 0, ptr %p3964, align 8, !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot20, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  %ld3967 = load i64, ptr %p3966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3967, ptr %slot716, align 8
  %v3968 = load i64, ptr %slot716, align 8
  %cond3969 = icmp ne i64 %v3968, 0
  br i1 %cond3969, label %bb_success1567, label %bb_failed1567
bb_failed1567:
  %v3970 = load i64, ptr %slot1, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  call void @myl_qbe_fail_assert(ptr %p3971) nomerge, !dbg !200
  unreachable
bb_success1567:
  %v3972 = load i64, ptr %slot20, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  store i64 18446744073709551615, ptr %p3973, align 8, !alias.scope !3, !noalias !4
  %v3974 = load i64, ptr %slot1, align 8
  %call3975 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v3974) nomerge, !dbg !202
  store { i64, i64 } %call3975, ptr %callresult718, align 8
  %addr3976 = ptrtoint ptr %callresult718 to i64
  store i64 %addr3976, ptr %slot717, align 8
  %v3977 = load i64, ptr %slot717, align 8
  %v3978 = load i64, ptr %slot21, align 8
  %p3979 = inttoptr i64 %v3978 to ptr
  store i64 %v3977, ptr %p3979, align 8, !alias.scope !3, !noalias !4
  %v3980 = load i64, ptr %slot21, align 8
  %p3981 = inttoptr i64 %v3980 to ptr
  %ld3982 = load i64, ptr %p3981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3982, ptr %slot719, align 8
  %v3983 = load i64, ptr %slot14, align 8
  store i64 %v3983, ptr %slot720, align 8
  %v3984 = load i64, ptr %slot719, align 8
  %v3985 = load i64, ptr %slot720, align 8
  %p3986 = inttoptr i64 %v3984 to ptr
  %p3987 = inttoptr i64 %v3985 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3987, ptr %p3986, i64 16, i1 false)
  %v3988 = load i64, ptr %slot10, align 8
  %p3989 = inttoptr i64 %v3988 to ptr
  store i32 2, ptr %p3989, align 4, !alias.scope !3, !noalias !4
  %v3990 = load i64, ptr %slot9, align 8
  %p3991 = inttoptr i64 %v3990 to ptr
  store i32 1, ptr %p3991, align 4, !alias.scope !3, !noalias !4
  %v3992 = load i64, ptr %slot13, align 8
  store i64 %v3992, ptr %slot721, align 8
  %v3993 = load i64, ptr %slot14, align 8
  store i64 %v3993, ptr %slot722, align 8
  %v3994 = load i64, ptr %slot722, align 8
  %v3995 = load i64, ptr %slot721, align 8
  %p3996 = inttoptr i64 %v3994 to ptr
  %p3997 = inttoptr i64 %v3995 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3997, ptr %p3996, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3998 = load i64, ptr %slot10, align 8
  %p3999 = inttoptr i64 %v3998 to ptr
  %ld4000 = load i32, ptr %p3999, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4000, ptr %slot723, align 8
  %v4001 = load i64, ptr %slot9, align 8
  %p4002 = inttoptr i64 %v4001 to ptr
  store i32 0, ptr %p4002, align 4, !alias.scope !3, !noalias !4
  %v4003 = load i64, ptr %slot8, align 8
  %p4004 = inttoptr i64 %v4003 to ptr
  store i32 1, ptr %p4004, align 4, !alias.scope !3, !noalias !4
  %v4005 = load i64, ptr %slot721, align 8
  %v4006 = load i64, ptr %slot21, align 8
  %p4007 = inttoptr i64 %v4006 to ptr
  store i64 %v4005, ptr %p4007, align 8, !alias.scope !3, !noalias !4
  %v4008 = load i64, ptr %slot31, align 8
  store i64 %v4008, ptr %slot724, align 8
  %v4009 = load i64, ptr %slot724, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  store i64 0, ptr %p4010, align 8, !alias.scope !3, !noalias !4
  %v4011 = load i64, ptr %slot724, align 8
  %p4013 = inttoptr i64 %v4011 to ptr
  %gep4014 = getelementptr i8, ptr %p4013, i64 8
  %op4012 = ptrtoint ptr %gep4014 to i64
  store i64 %op4012, ptr %slot725, align 8
  %v4015 = load i64, ptr %slot725, align 8
  %p4016 = inttoptr i64 %v4015 to ptr
  store i64 0, ptr %p4016, align 8, !alias.scope !3, !noalias !4
  %v4017 = load i64, ptr %slot724, align 8
  %p4019 = inttoptr i64 %v4017 to ptr
  %gep4020 = getelementptr i8, ptr %p4019, i64 16
  %op4018 = ptrtoint ptr %gep4020 to i64
  store i64 %op4018, ptr %slot726, align 8
  %v4021 = load i64, ptr %slot726, align 8
  %p4022 = inttoptr i64 %v4021 to ptr
  store i64 0, ptr %p4022, align 8, !alias.scope !3, !noalias !4
  %v4023 = load i64, ptr %slot11, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  store i32 1, ptr %p4024, align 4, !alias.scope !3, !noalias !4
  %v4025 = load i64, ptr %slot37, align 8
  store i64 %v4025, ptr %slot727, align 8
  %v4026 = load i64, ptr %slot20, align 8
  store i64 %v4026, ptr %slot728, align 8
  %v4027 = load i64, ptr %slot724, align 8
  %p4029 = inttoptr i64 %v4027 to ptr
  %gep4030 = getelementptr i8, ptr %p4029, i64 0
  %op4028 = ptrtoint ptr %gep4030 to i64
  store i64 %op4028, ptr %slot729, align 8
  %v4031 = load i64, ptr %slot728, align 8
  %p4032 = inttoptr i64 %v4031 to ptr
  %ld4033 = load i64, ptr %p4032, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4033, ptr %slot730, align 8
  %v4034 = load i64, ptr %slot730, align 8
  %v4035 = load i64, ptr %slot729, align 8
  %p4036 = inttoptr i64 %v4035 to ptr
  store i64 %v4034, ptr %p4036, align 8, !alias.scope !3, !noalias !4
  %v4037 = load i64, ptr %slot21, align 8
  %p4038 = inttoptr i64 %v4037 to ptr
  %ld4039 = load i64, ptr %p4038, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4039, ptr %slot731, align 8
  %v4040 = load i64, ptr %slot724, align 8
  %p4042 = inttoptr i64 %v4040 to ptr
  %gep4043 = getelementptr i8, ptr %p4042, i64 8
  %op4041 = ptrtoint ptr %gep4043 to i64
  store i64 %op4041, ptr %slot732, align 8
  %v4044 = load i64, ptr %slot21, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  %ld4046 = load i64, ptr %p4045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4046, ptr %slot733, align 8
  %v4047 = load i64, ptr %slot14, align 8
  store i64 %v4047, ptr %slot734, align 8
  %v4048 = load i64, ptr %slot37, align 8
  store i64 %v4048, ptr %slot735, align 8
  %v4049 = load i64, ptr %slot733, align 8
  %op4050 = add i64 %v4049, 0
  store i64 %op4050, ptr %slot736, align 8
  %v4051 = load i64, ptr %slot736, align 8
  %p4052 = inttoptr i64 %v4051 to ptr
  %ld4053 = load i64, ptr %p4052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4053, ptr %slot737, align 8
  %v4054 = load i64, ptr %slot737, align 8
  %cmp4055 = icmp ne i64 %v4054, 0
  %cv4056 = zext i1 %cmp4055 to i32
  store i32 %cv4056, ptr %slot738, align 8
  %v4057 = load i32, ptr %slot738, align 8
  %cv4058 = zext i32 %v4057 to i64
  %cond4059 = icmp ne i64 %cv4058, 0
  br i1 %cond4059, label %bb_rcmoveheader1598, label %bb_rcmovenext1598
bb_rcmoveheader1598:
  %v4060 = load i64, ptr %slot737, align 8
  %op4061 = sub i64 %v4060, 16
  store i64 %op4061, ptr %slot739, align 8
  %v4062 = load i64, ptr %slot737, align 8
  %p4063 = inttoptr i64 %v4062 to ptr
  %rgep4064 = getelementptr i8, ptr %p4063, i64 -16
  %ld4065 = load i64, ptr %rgep4064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4065, ptr %slot740, align 8
  %v4066 = load i64, ptr %slot740, align 8
  %op4067 = and i64 %v4066, 5764607523034234881
  store i64 %op4067, ptr %slot741, align 8
  %v4068 = load i64, ptr %slot741, align 8
  %cmp4069 = icmp ne i64 %v4068, 0
  %cv4070 = zext i1 %cmp4069 to i32
  store i32 %cv4070, ptr %slot742, align 8
  %v4071 = load i32, ptr %slot742, align 8
  %cv4072 = zext i32 %v4071 to i64
  %cond4073 = icmp ne i64 %cv4072, 0
  br i1 %cond4073, label %bb_rcmoveslow1595, label %bb_rcmovenext1598
bb_rcmovenext1598:
  %v4074 = load i64, ptr %slot733, align 8
  %v4075 = load i64, ptr %slot734, align 8
  %p4076 = inttoptr i64 %v4074 to ptr
  %p4077 = inttoptr i64 %v4075 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4077, ptr %p4076, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4078 = load i64, ptr %slot733, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  store i64 0, ptr %p4079, align 8, !alias.scope !3, !noalias !4
  %v4080 = load i64, ptr %slot733, align 8
  %op4081 = add i64 %v4080, 8
  store i64 %op4081, ptr %slot743, align 8
  %v4082 = load i64, ptr %slot743, align 8
  %p4083 = inttoptr i64 %v4082 to ptr
  store i64 0, ptr %p4083, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1595
bb_rcmoveslow1595:
  %v4084 = load i64, ptr %slot36, align 8
  %v4085 = load i64, ptr %slot734, align 8
  %v4086 = load i64, ptr %slot733, align 8
  %v4087 = load i64, ptr %slot735, align 8
  %cv4088 = trunc i64 %v4087 to i32
  %call4089 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v4084, i64 %v4085, i64 %v4086, i32 %cv4088) nomerge, !dbg !204
  store i32 %call4089, ptr %slot744, align 8
  %v4090 = load i32, ptr %slot744, align 8
  %cv4091 = zext i32 %v4090 to i64
  %cond4092 = icmp ne i64 %cv4091, 0
  br i1 %cond4092, label %bb_rcsuccess1606, label %bb_rcfailure1606
bb_rcfailure1606:
  %v4093 = load i64, ptr %slot36, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  %call4095 = call i32 @myl_rc_take_failure(ptr %p4094) nomerge, !dbg !204
  store i32 %call4095, ptr %slot745, align 8
  %v4096 = load i64, ptr %slot1, align 8
  %p4097 = inttoptr i64 %v4096 to ptr
  %v4098 = load i32, ptr %slot745, align 8
  %call4099 = call i32 @myl_qbe_rc_status(ptr %p4097, i32 %v4098) nomerge, !dbg !204
  store i32 %call4099, ptr %slot746, align 8
  br label %bb_failure
bb_rcsuccess1606:
  br label %bb_rcmoved1595
bb_rcmoved1595:
  %v4100 = load i64, ptr %slot8, align 8
  %p4101 = inttoptr i64 %v4100 to ptr
  store i32 0, ptr %p4101, align 4, !alias.scope !3, !noalias !4
  %v4102 = load i64, ptr %slot10, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  store i32 2, ptr %p4103, align 4, !alias.scope !3, !noalias !4
  %v4104 = load i64, ptr %slot9, align 8
  %p4105 = inttoptr i64 %v4104 to ptr
  store i32 1, ptr %p4105, align 4, !alias.scope !3, !noalias !4
  %v4106 = load i64, ptr %slot14, align 8
  store i64 %v4106, ptr %slot747, align 8
  %v4107 = load i64, ptr %slot747, align 8
  %v4108 = load i64, ptr %slot732, align 8
  %p4109 = inttoptr i64 %v4107 to ptr
  %p4110 = inttoptr i64 %v4108 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4110, ptr %p4109, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4111 = load i64, ptr %slot9, align 8
  %p4112 = inttoptr i64 %v4111 to ptr
  store i32 0, ptr %p4112, align 4, !alias.scope !3, !noalias !4
  %v4113 = load i64, ptr %slot724, align 8
  %v4114 = load i64, ptr %slot20, align 8
  %p4115 = inttoptr i64 %v4114 to ptr
  store i64 %v4113, ptr %p4115, align 8, !alias.scope !3, !noalias !4
  %v4116 = load i64, ptr %slot20, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  %ld4118 = load i64, ptr %p4117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4118, ptr %slot748, align 8
  %v4119 = load i64, ptr %slot12, align 8
  store i64 %v4119, ptr %slot749, align 8
  %v4120 = load i64, ptr %slot748, align 8
  %v4121 = load i64, ptr %slot749, align 8
  %p4122 = inttoptr i64 %v4120 to ptr
  %p4123 = inttoptr i64 %v4121 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4123, ptr %p4122, i64 24, i1 false)
  %v4124 = load i64, ptr %slot7, align 8
  %p4125 = inttoptr i64 %v4124 to ptr
  store i32 2, ptr %p4125, align 4, !alias.scope !3, !noalias !4
  %v4126 = load i64, ptr %slot6, align 8
  %p4127 = inttoptr i64 %v4126 to ptr
  store i32 1, ptr %p4127, align 4, !alias.scope !3, !noalias !4
  %v4128 = load i64, ptr %slot749, align 8
  %v4129 = load i64, ptr %slot20, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  store i64 %v4128, ptr %p4130, align 8, !alias.scope !3, !noalias !4
  %v4131 = load i64, ptr %slot20, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  %ld4133 = load i64, ptr %p4132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4133, ptr %slot750, align 8
  %v4134 = load i64, ptr %slot20, align 8
  %p4135 = inttoptr i64 %v4134 to ptr
  %ld4136 = load i64, ptr %p4135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4136, ptr %slot751, align 8
  %v4137 = load i64, ptr %slot14, align 8
  store i64 %v4137, ptr %slot752, align 8
  %v4138 = load i64, ptr %slot37, align 8
  store i64 %v4138, ptr %slot753, align 8
  %v4139 = load i64, ptr %slot751, align 8
  %op4140 = add i64 %v4139, 8
  store i64 %op4140, ptr %slot754, align 8
  %v4141 = load i64, ptr %slot754, align 8
  %p4142 = inttoptr i64 %v4141 to ptr
  %ld4143 = load i64, ptr %p4142, align 8
  store i64 %ld4143, ptr %slot755, align 8
  %v4144 = load i64, ptr %slot755, align 8
  %cmp4145 = icmp ne i64 %v4144, 0
  %cv4146 = zext i1 %cmp4145 to i32
  store i32 %cv4146, ptr %slot756, align 8
  %v4147 = load i32, ptr %slot756, align 8
  %cv4148 = zext i32 %v4147 to i64
  %cond4149 = icmp ne i64 %cv4148, 0
  br i1 %cond4149, label %bb_rcmoveheader1625, label %bb_rcmovenext1625
bb_rcmoveheader1625:
  %v4150 = load i64, ptr %slot755, align 8
  %op4151 = sub i64 %v4150, 16
  store i64 %op4151, ptr %slot757, align 8
  %v4152 = load i64, ptr %slot755, align 8
  %p4153 = inttoptr i64 %v4152 to ptr
  %rgep4154 = getelementptr i8, ptr %p4153, i64 -16
  %ld4155 = load i64, ptr %rgep4154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4155, ptr %slot758, align 8
  %v4156 = load i64, ptr %slot758, align 8
  %op4157 = and i64 %v4156, 5764607523034234881
  store i64 %op4157, ptr %slot759, align 8
  %v4158 = load i64, ptr %slot759, align 8
  %cmp4159 = icmp ne i64 %v4158, 0
  %cv4160 = zext i1 %cmp4159 to i32
  store i32 %cv4160, ptr %slot760, align 8
  %v4161 = load i32, ptr %slot760, align 8
  %cv4162 = zext i32 %v4161 to i64
  %cond4163 = icmp ne i64 %cv4162, 0
  br i1 %cond4163, label %bb_rcmoveslow1622, label %bb_rcmovenext1625
bb_rcmovenext1625:
  %v4164 = load i64, ptr %slot751, align 8
  %v4165 = load i64, ptr %slot752, align 8
  %p4166 = inttoptr i64 %v4164 to ptr
  %p4167 = inttoptr i64 %v4165 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4167, ptr %p4166, i64 24, i1 false)
  %v4168 = load i64, ptr %slot751, align 8
  %p4169 = inttoptr i64 %v4168 to ptr
  store i64 0, ptr %p4169, align 8
  %v4170 = load i64, ptr %slot751, align 8
  %op4171 = add i64 %v4170, 8
  store i64 %op4171, ptr %slot761, align 8
  %v4172 = load i64, ptr %slot761, align 8
  %p4173 = inttoptr i64 %v4172 to ptr
  store i64 0, ptr %p4173, align 8
  %v4174 = load i64, ptr %slot751, align 8
  %op4175 = add i64 %v4174, 16
  store i64 %op4175, ptr %slot762, align 8
  %v4176 = load i64, ptr %slot762, align 8
  %p4177 = inttoptr i64 %v4176 to ptr
  store i64 0, ptr %p4177, align 8
  br label %bb_rcmoved1622
bb_rcmoveslow1622:
  %v4178 = load i64, ptr %slot36, align 8
  %v4179 = load i64, ptr %slot752, align 8
  %v4180 = load i64, ptr %slot751, align 8
  %v4181 = load i64, ptr %slot753, align 8
  %cv4182 = trunc i64 %v4181 to i32
  %call4183 = call i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64 %v4178, i64 %v4179, i64 %v4180, i32 %cv4182) nomerge, !dbg !206
  store i32 %call4183, ptr %slot763, align 8
  %v4184 = load i32, ptr %slot763, align 8
  %cv4185 = zext i32 %v4184 to i64
  %cond4186 = icmp ne i64 %cv4185, 0
  br i1 %cond4186, label %bb_rcsuccess1634, label %bb_rcfailure1634
bb_rcfailure1634:
  %v4187 = load i64, ptr %slot36, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  %call4189 = call i32 @myl_rc_take_failure(ptr %p4188) nomerge, !dbg !206
  store i32 %call4189, ptr %slot764, align 8
  %v4190 = load i64, ptr %slot1, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  %v4192 = load i32, ptr %slot764, align 8
  %call4193 = call i32 @myl_qbe_rc_status(ptr %p4191, i32 %v4192) nomerge, !dbg !206
  store i32 %call4193, ptr %slot765, align 8
  br label %bb_failure
bb_rcsuccess1634:
  br label %bb_rcmoved1622
bb_rcmoved1622:
  %v4194 = load i64, ptr %slot6, align 8
  %p4195 = inttoptr i64 %v4194 to ptr
  store i32 0, ptr %p4195, align 4, !alias.scope !3, !noalias !4
  %v4196 = load i64, ptr %slot10, align 8
  %p4197 = inttoptr i64 %v4196 to ptr
  store i32 2, ptr %p4197, align 4, !alias.scope !3, !noalias !4
  %v4198 = load i64, ptr %slot9, align 8
  %p4199 = inttoptr i64 %v4198 to ptr
  store i32 1, ptr %p4199, align 4, !alias.scope !3, !noalias !4
  %v4200 = load i64, ptr %slot14, align 8
  store i64 %v4200, ptr %slot766, align 8
  %v4201 = load i64, ptr %slot9, align 8
  %p4202 = inttoptr i64 %v4201 to ptr
  store i32 0, ptr %p4202, align 4, !alias.scope !3, !noalias !4
  %v4203 = load i64, ptr %slot6, align 8
  %p4204 = inttoptr i64 %v4203 to ptr
  %ld4205 = load i32, ptr %p4204, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4205, ptr %slot767, align 8
  %v4206 = load i32, ptr %slot767, align 8
  %cv4207 = zext i32 %v4206 to i64
  %cond4208 = icmp ne i64 %cv4207, 0
  br i1 %cond4208, label %bb_rcslotdrop1644, label %bb_rcslotdone1644
bb_rcslotdrop1644:
  %v4209 = load i64, ptr %slot6, align 8
  %p4210 = inttoptr i64 %v4209 to ptr
  store i32 0, ptr %p4210, align 4, !alias.scope !3, !noalias !4
  %v4211 = load i64, ptr %slot12, align 8
  store i64 %v4211, ptr %slot768, align 8
  %v4212 = load i64, ptr %slot7, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  %ld4214 = load i32, ptr %p4213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4214, ptr %slot769, align 8
  %v4215 = load i32, ptr %slot769, align 8
  %op4216 = and i32 %v4215, 28
  store i32 %op4216, ptr %slot770, align 8
  %v4217 = load i32, ptr %slot770, align 8
  %cv4218 = zext i32 %v4217 to i64
  %cond4219 = icmp ne i64 %cv4218, 0
  br i1 %cond4219, label %bb_rcslotrole1644, label %bb_rcslotowner1644
bb_rcslotrole1644:
  %v4220 = load i64, ptr %slot36, align 8
  store i64 %v4220, ptr %slot771, align 8
  %v4221 = load i64, ptr %slot771, align 8
  %v4222 = load i64, ptr %slot768, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v4221, i64 %v4222) nomerge, !dbg !206
  br label %bb_rcslotdone1644
bb_rcslotowner1644:
  %v4223 = load i64, ptr %slot36, align 8
  store i64 %v4223, ptr %slot772, align 8
  %v4224 = load i64, ptr %slot772, align 8
  %v4225 = load i64, ptr %slot768, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v4224, i64 %v4225) nomerge, !dbg !206
  br label %bb_rcslotdone1644
bb_rcslotdone1644:
  %v4226 = load i64, ptr %slot766, align 8
  %p4227 = inttoptr i64 %v4226 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4227, i64 24, i1 false)
  ret void
bb_failure:
  %v4228 = load i64, ptr %slot5, align 8
  %p4229 = inttoptr i64 %v4228 to ptr
  call void @llvm.memset.p0.i64(ptr %p4229, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !206
  %v4230 = load i64, ptr %slot5, align 8
  %p4231 = inttoptr i64 %v4230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4231, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v4232 = load i64, ptr %slot5, align 8
  %p4233 = inttoptr i64 %v4232 to ptr
  call void @llvm.memset.p0.i64(ptr %p4233, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !206
  %v4234 = load i64, ptr %slot5, align 8
  %p4235 = inttoptr i64 %v4234 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p4235, i64 24, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64)
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64, i64)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54", linkageName: "myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1569155190504285712, i64 0, !"myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!116 = !DILocation(line: 11, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!120 = !DILocation(line: 16, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!124 = !DILocation(line: 22, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!128 = !DILocation(line: 25, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!130 = !DILocation(line: 27, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!132 = !DILocation(line: 28, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!136 = !DILocation(line: 31, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!138 = !DILocation(line: 33, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!140 = !DILocation(line: 34, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!142 = !DILocation(line: 35, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!144 = !DILocation(line: 37, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!146 = !DILocation(line: 39, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!148 = !DILocation(line: 40, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!150 = !DILocation(line: 41, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!152 = !DILocation(line: 43, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!154 = !DILocation(line: 45, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!156 = !DILocation(line: 46, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!158 = !DILocation(line: 47, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!160 = !DILocation(line: 49, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!162 = !DILocation(line: 51, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!164 = !DILocation(line: 52, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!166 = !DILocation(line: 53, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!168 = !DILocation(line: 55, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!170 = !DILocation(line: 57, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!172 = !DILocation(line: 58, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!174 = !DILocation(line: 59, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!176 = !DILocation(line: 61, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!178 = !DILocation(line: 63, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647047)
!180 = !DILocation(line: 64, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!182 = !DILocation(line: 65, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!184 = !DILocation(line: 67, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!186 = !DILocation(line: 69, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!188 = !DILocation(line: 70, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!190 = !DILocation(line: 71, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!192 = !DILocation(line: 73, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!194 = !DILocation(line: 75, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!196 = !DILocation(line: 76, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!198 = !DILocation(line: 77, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!200 = !DILocation(line: 79, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647183)
!202 = !DILocation(line: 81, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!204 = !DILocation(line: 82, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647199)
!206 = !DILocation(line: 83, column: 0, scope: !207)
