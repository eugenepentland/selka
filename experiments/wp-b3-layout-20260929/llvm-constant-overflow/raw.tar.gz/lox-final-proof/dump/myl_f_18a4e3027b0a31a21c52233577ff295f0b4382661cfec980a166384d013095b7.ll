target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_18a4e3027b0a31a21c52233577ff295f0b4382661cfec980a166384d013095b7(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i32, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i32, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i32, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i32, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i32, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i32, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i32, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i32, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i32, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i32, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i32, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i32, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i32, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i32, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i32, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i32, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i32, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i32, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i32, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i32, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i32, align 8
  %slot1184 = alloca i32, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i32, align 8
  %slot1187 = alloca i32, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i32, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i32, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i32, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i32, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i32, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i32, align 8
  %slot1228 = alloca i32, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i32, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i32, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i32, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i32, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i32, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i32, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i32, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i32, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i32, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i32, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i32, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i32, align 8
  %slot1290 = alloca i32, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i32, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i32, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i32, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i32, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i32, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i32, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i64, align 8
  %slot1327 = alloca i32, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i32, align 8
  %slot1340 = alloca i32, align 8
  %slot1341 = alloca i32, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i32, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i32, align 8
  %slot1359 = alloca i32, align 8
  %slot1360 = alloca i32, align 8
  %slot1361 = alloca i32, align 8
  %slot1362 = alloca i32, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i32, align 8
  %slot1365 = alloca i32, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i32, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i32, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i32, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i32, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i32, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i32, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i32, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i32, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i32, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i32, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i32, align 8
  %slot1404 = alloca i32, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i64, align 8
  %slot1409 = alloca i32, align 8
  %slot1410 = alloca i32, align 8
  %slot1411 = alloca i64, align 8
  %slot1412 = alloca i32, align 8
  %slot1413 = alloca i32, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i32, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i32, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i32, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i32, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i32, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i32, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i32, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i32, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i64, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i64, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i32, align 8
  %slot1450 = alloca i64, align 8
  %slot1451 = alloca i32, align 8
  %slot1452 = alloca i32, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i32, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i64, align 8
  %slot1459 = alloca i32, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i64, align 8
  %slot1463 = alloca i32, align 8
  %slot1464 = alloca i64, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i32, align 8
  %slot1467 = alloca i64, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i32, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i32, align 8
  %slot1474 = alloca i64, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i64, align 8
  %slot1477 = alloca i32, align 8
  %slot1478 = alloca i64, align 8
  %slot1479 = alloca i64, align 8
  %slot1480 = alloca i32, align 8
  %slot1481 = alloca i64, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i32, align 8
  %slot1484 = alloca i64, align 8
  %slot1485 = alloca i64, align 8
  %slot1486 = alloca i64, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i32, align 8
  %slot1489 = alloca i32, align 8
  %slot1490 = alloca i32, align 8
  %slot1491 = alloca i64, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i32, align 8
  %slot1496 = alloca i32, align 8
  %slot1497 = alloca i32, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i32, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i32, align 8
  %slot1505 = alloca i32, align 8
  %slot1506 = alloca i32, align 8
  %slot1507 = alloca i32, align 8
  %slot1508 = alloca i32, align 8
  %slot1509 = alloca i32, align 8
  %slot1510 = alloca i32, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i32, align 8
  %slot1515 = alloca i64, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i32, align 8
  %slot1519 = alloca i64, align 8
  %slot1520 = alloca i64, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i32, align 8
  %slot1523 = alloca i32, align 8
  %slot1524 = alloca i32, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i32, align 8
  %slot1527 = alloca i32, align 8
  %slot1528 = alloca i64, align 8
  %slot1529 = alloca i64, align 8
  %slot1530 = alloca i32, align 8
  %slot1531 = alloca i64, align 8
  %slot1532 = alloca i64, align 8
  %slot1533 = alloca i64, align 8
  %slot1534 = alloca i32, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i64, align 8
  %slot1537 = alloca i64, align 8
  %slot1538 = alloca i32, align 8
  %slot1539 = alloca i64, align 8
  %slot1540 = alloca i64, align 8
  %slot1541 = alloca i32, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i64, align 8
  %slot1544 = alloca i32, align 8
  %slot1545 = alloca i64, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i64, align 8
  %slot1548 = alloca i32, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i64, align 8
  %slot1551 = alloca i64, align 8
  %slot1552 = alloca i32, align 8
  %slot1553 = alloca i64, align 8
  %slot1554 = alloca i64, align 8
  %slot1555 = alloca i32, align 8
  %slot1556 = alloca i32, align 8
  %slot1557 = alloca i64, align 8
  %slot1558 = alloca i32, align 8
  %slot1559 = alloca i32, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i64, align 8
  %slot1562 = alloca i32, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i64, align 8
  %slot1566 = alloca i32, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i64, align 8
  %slot1569 = alloca i64, align 8
  %slot1570 = alloca i32, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i64, align 8
  %slot1573 = alloca i32, align 8
  %slot1574 = alloca i64, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i32, align 8
  %slot1577 = alloca i64, align 8
  %slot1578 = alloca i64, align 8
  %slot1579 = alloca i64, align 8
  %slot1580 = alloca i32, align 8
  %slot1581 = alloca i64, align 8
  %slot1582 = alloca i64, align 8
  %slot1583 = alloca i64, align 8
  %slot1584 = alloca i32, align 8
  %slot1585 = alloca i64, align 8
  %slot1586 = alloca i64, align 8
  %slot1587 = alloca i32, align 8
  %slot1588 = alloca i64, align 8
  %slot1589 = alloca i64, align 8
  %slot1590 = alloca i32, align 8
  %slot1591 = alloca i32, align 8
  %slot1592 = alloca i64, align 8
  %slot1593 = alloca i32, align 8
  %slot1594 = alloca i32, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i64, align 8
  %slot1597 = alloca i32, align 8
  %slot1598 = alloca i64, align 8
  %slot1599 = alloca i64, align 8
  %slot1600 = alloca i64, align 8
  %slot1601 = alloca i32, align 8
  %slot1602 = alloca i64, align 8
  %slot1603 = alloca i64, align 8
  %slot1604 = alloca i64, align 8
  %slot1605 = alloca i32, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i64, align 8
  %slot1608 = alloca i32, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i64, align 8
  %slot1611 = alloca i32, align 8
  %slot1612 = alloca i64, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i32, align 8
  %slot1616 = alloca i64, align 8
  %slot1617 = alloca i64, align 8
  %slot1618 = alloca i64, align 8
  %slot1619 = alloca i32, align 8
  %slot1620 = alloca i64, align 8
  %slot1621 = alloca i64, align 8
  %slot1622 = alloca i32, align 8
  %slot1623 = alloca i32, align 8
  %slot1624 = alloca i64, align 8
  %slot1625 = alloca i32, align 8
  %slot1626 = alloca i32, align 8
  %slot1627 = alloca i64, align 8
  %slot1628 = alloca i64, align 8
  %slot1629 = alloca i32, align 8
  %slot1630 = alloca i64, align 8
  %slot1631 = alloca i64, align 8
  %slot1632 = alloca i64, align 8
  %slot1633 = alloca i32, align 8
  %slot1634 = alloca i64, align 8
  %slot1635 = alloca i64, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i32, align 8
  %slot1638 = alloca i64, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i32, align 8
  %slot1641 = alloca i64, align 8
  %slot1642 = alloca i64, align 8
  %slot1643 = alloca i32, align 8
  %slot1644 = alloca i64, align 8
  %slot1645 = alloca i64, align 8
  %slot1646 = alloca i64, align 8
  %slot1647 = alloca i32, align 8
  %slot1648 = alloca i64, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i64, align 8
  %slot1651 = alloca i32, align 8
  %slot1652 = alloca i64, align 8
  %slot1653 = alloca i64, align 8
  %slot1654 = alloca i32, align 8
  %slot1655 = alloca i64, align 8
  %slot1656 = alloca i64, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i64, align 8
  %slot1659 = alloca i64, align 8
  %slot1660 = alloca i64, align 8
  %slot1661 = alloca i64, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i32, align 8
  %slot1664 = alloca i64, align 8
  %slot1665 = alloca i64, align 8
  %slot1666 = alloca i64, align 8
  %slot1667 = alloca i64, align 8
  %slot1668 = alloca i32, align 8
  %slot1669 = alloca i32, align 8
  %slot1670 = alloca i32, align 8
  %slot1671 = alloca i32, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i64, align 8
  %slot1674 = alloca i64, align 8
  %slot1675 = alloca i64, align 8
  %slot1676 = alloca i32, align 8
  %slot1677 = alloca i32, align 8
  %slot1678 = alloca i32, align 8
  %slot1679 = alloca i64, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i32, align 8
  %slot1682 = alloca i64, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i64, align 8
  %slot1685 = alloca i32, align 8
  %slot1686 = alloca i32, align 8
  %slot1687 = alloca i32, align 8
  %slot1688 = alloca i32, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i64, align 8
  %slot1692 = alloca i32, align 8
  %slot1693 = alloca i64, align 8
  %slot1694 = alloca i64, align 8
  %slot1695 = alloca i64, align 8
  %slot1696 = alloca i32, align 8
  %slot1697 = alloca i64, align 8
  %slot1698 = alloca i64, align 8
  %slot1699 = alloca i64, align 8
  %slot1700 = alloca i32, align 8
  %slot1701 = alloca i32, align 8
  %slot1702 = alloca i64, align 8
  %slot1703 = alloca i32, align 8
  %slot1704 = alloca i32, align 8
  %slot1705 = alloca i32, align 8
  %slot1706 = alloca i32, align 8
  %slot1707 = alloca i32, align 8
  %slot1708 = alloca i64, align 8
  %slot1709 = alloca i32, align 8
  %slot1710 = alloca i32, align 8
  %slot1711 = alloca i64, align 8
  %slot1712 = alloca i64, align 8
  %slot1713 = alloca i32, align 8
  %slot1714 = alloca i64, align 8
  %slot1715 = alloca i64, align 8
  %slot1716 = alloca i64, align 8
  %slot1717 = alloca i32, align 8
  %slot1718 = alloca i64, align 8
  %slot1719 = alloca i64, align 8
  %slot1720 = alloca i64, align 8
  %slot1721 = alloca i32, align 8
  %slot1722 = alloca i64, align 8
  %slot1723 = alloca i64, align 8
  %slot1724 = alloca i32, align 8
  %slot1725 = alloca i64, align 8
  %slot1726 = alloca i64, align 8
  %slot1727 = alloca i32, align 8
  %slot1728 = alloca i64, align 8
  %slot1729 = alloca i64, align 8
  %slot1730 = alloca i64, align 8
  %slot1731 = alloca i32, align 8
  %slot1732 = alloca i64, align 8
  %slot1733 = alloca i64, align 8
  %slot1734 = alloca i64, align 8
  %slot1735 = alloca i32, align 8
  %slot1736 = alloca i64, align 8
  %slot1737 = alloca i64, align 8
  %slot1738 = alloca i32, align 8
  %slot1739 = alloca i64, align 8
  %slot1740 = alloca i64, align 8
  %slot1741 = alloca i32, align 8
  %slot1742 = alloca i64, align 8
  %slot1743 = alloca i32, align 8
  %slot1744 = alloca i32, align 8
  %slot1745 = alloca i64, align 8
  %slot1746 = alloca i64, align 8
  %slot1747 = alloca i32, align 8
  %slot1748 = alloca i64, align 8
  %slot1749 = alloca i64, align 8
  %slot1750 = alloca i64, align 8
  %slot1751 = alloca i32, align 8
  %slot1752 = alloca i64, align 8
  %slot1753 = alloca i64, align 8
  %slot1754 = alloca i64, align 8
  %slot1755 = alloca i32, align 8
  %slot1756 = alloca i64, align 8
  %slot1757 = alloca i64, align 8
  %slot1758 = alloca i32, align 8
  %slot1759 = alloca i64, align 8
  %slot1760 = alloca i64, align 8
  %slot1761 = alloca i32, align 8
  %slot1762 = alloca i64, align 8
  %slot1763 = alloca i64, align 8
  %slot1764 = alloca i64, align 8
  %slot1765 = alloca i32, align 8
  %slot1766 = alloca i64, align 8
  %slot1767 = alloca i64, align 8
  %slot1768 = alloca i64, align 8
  %slot1769 = alloca i32, align 8
  %slot1770 = alloca i64, align 8
  %slot1771 = alloca i64, align 8
  %slot1772 = alloca i32, align 8
  %slot1773 = alloca i32, align 8
  %slot1774 = alloca i64, align 8
  %slot1775 = alloca i32, align 8
  %slot1776 = alloca i32, align 8
  %slot1777 = alloca i64, align 8
  %slot1778 = alloca i64, align 8
  %slot1779 = alloca i32, align 8
  %slot1780 = alloca i64, align 8
  %slot1781 = alloca i64, align 8
  %slot1782 = alloca i64, align 8
  %slot1783 = alloca i32, align 8
  %slot1784 = alloca i64, align 8
  %slot1785 = alloca i64, align 8
  %slot1786 = alloca i64, align 8
  %slot1787 = alloca i32, align 8
  %slot1788 = alloca i64, align 8
  %slot1789 = alloca i64, align 8
  %slot1790 = alloca i32, align 8
  %slot1791 = alloca i64, align 8
  %slot1792 = alloca i64, align 8
  %slot1793 = alloca i32, align 8
  %slot1794 = alloca i64, align 8
  %slot1795 = alloca i64, align 8
  %slot1796 = alloca i64, align 8
  %slot1797 = alloca i32, align 8
  %slot1798 = alloca i64, align 8
  %slot1799 = alloca i64, align 8
  %slot1800 = alloca i64, align 8
  %slot1801 = alloca i32, align 8
  %slot1802 = alloca i64, align 8
  %slot1803 = alloca i64, align 8
  %slot1804 = alloca i32, align 8
  %slot1805 = alloca i32, align 8
  %slot1806 = alloca i64, align 8
  %slot1807 = alloca i32, align 8
  %slot1808 = alloca i32, align 8
  %slot1809 = alloca i64, align 8
  %slot1810 = alloca i64, align 8
  %slot1811 = alloca i32, align 8
  %slot1812 = alloca i64, align 8
  %slot1813 = alloca i64, align 8
  %slot1814 = alloca i64, align 8
  %slot1815 = alloca i32, align 8
  %slot1816 = alloca i64, align 8
  %slot1817 = alloca i64, align 8
  %slot1818 = alloca i64, align 8
  %slot1819 = alloca i32, align 8
  %slot1820 = alloca i64, align 8
  %slot1821 = alloca i64, align 8
  %slot1822 = alloca i32, align 8
  %slot1823 = alloca i64, align 8
  %slot1824 = alloca i64, align 8
  %slot1825 = alloca i32, align 8
  %slot1826 = alloca i64, align 8
  %slot1827 = alloca i64, align 8
  %slot1828 = alloca i64, align 8
  %slot1829 = alloca i32, align 8
  %slot1830 = alloca i64, align 8
  %slot1831 = alloca i64, align 8
  %slot1832 = alloca i64, align 8
  %slot1833 = alloca i32, align 8
  %slot1834 = alloca i64, align 8
  %slot1835 = alloca i64, align 8
  %slot1836 = alloca i32, align 8
  %slot1837 = alloca i32, align 8
  %slot1838 = alloca i64, align 8
  %slot1839 = alloca i32, align 8
  %slot1840 = alloca i32, align 8
  %slot1841 = alloca i64, align 8
  %slot1842 = alloca i64, align 8
  %slot1843 = alloca i32, align 8
  %slot1844 = alloca i64, align 8
  %slot1845 = alloca i64, align 8
  %slot1846 = alloca i64, align 8
  %slot1847 = alloca i32, align 8
  %slot1848 = alloca i64, align 8
  %slot1849 = alloca i64, align 8
  %slot1850 = alloca i64, align 8
  %slot1851 = alloca i32, align 8
  %slot1852 = alloca i64, align 8
  %slot1853 = alloca i64, align 8
  %slot1854 = alloca i32, align 8
  %slot1855 = alloca i64, align 8
  %slot1856 = alloca i64, align 8
  %slot1857 = alloca i32, align 8
  %slot1858 = alloca i64, align 8
  %slot1859 = alloca i64, align 8
  %slot1860 = alloca i64, align 8
  %slot1861 = alloca i32, align 8
  %slot1862 = alloca i64, align 8
  %slot1863 = alloca i64, align 8
  %slot1864 = alloca i64, align 8
  %slot1865 = alloca i32, align 8
  %slot1866 = alloca i64, align 8
  %slot1867 = alloca i64, align 8
  %slot1868 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1869 = load i64, ptr %slot1, align 8
  %op1870 = add i64 %v1869, 32
  store i64 %op1870, ptr %slot4, align 8
  %mem1871 = alloca i8, i64 8, align 8
  %ptr1872 = ptrtoint ptr %mem1871 to i64
  store i64 %ptr1872, ptr %slot5, align 8
  %mem1873 = alloca i8, i64 8, align 8
  %ptr1874 = ptrtoint ptr %mem1873 to i64
  store i64 %ptr1874, ptr %slot6, align 8
  %mem1875 = alloca i8, i64 8, align 8
  %ptr1876 = ptrtoint ptr %mem1875 to i64
  store i64 %ptr1876, ptr %slot7, align 8
  %mem1877 = alloca i8, i64 8, align 8
  %ptr1878 = ptrtoint ptr %mem1877 to i64
  store i64 %ptr1878, ptr %slot8, align 8
  %mem1879 = alloca i8, i64 8, align 8
  %ptr1880 = ptrtoint ptr %mem1879 to i64
  store i64 %ptr1880, ptr %slot9, align 8
  %mem1881 = alloca i8, i64 8, align 8
  %ptr1882 = ptrtoint ptr %mem1881 to i64
  store i64 %ptr1882, ptr %slot10, align 8
  %mem1883 = alloca i8, i64 8, align 8
  %ptr1884 = ptrtoint ptr %mem1883 to i64
  store i64 %ptr1884, ptr %slot11, align 8
  %mem1885 = alloca i8, i64 8, align 8
  %ptr1886 = ptrtoint ptr %mem1885 to i64
  store i64 %ptr1886, ptr %slot12, align 8
  %mem1887 = alloca i8, i64 8, align 8
  %ptr1888 = ptrtoint ptr %mem1887 to i64
  store i64 %ptr1888, ptr %slot13, align 8
  %mem1889 = alloca i8, i64 8, align 8
  %ptr1890 = ptrtoint ptr %mem1889 to i64
  store i64 %ptr1890, ptr %slot14, align 8
  %mem1891 = alloca i8, i64 208, align 8
  %ptr1892 = ptrtoint ptr %mem1891 to i64
  store i64 %ptr1892, ptr %slot15, align 8
  %mem1893 = alloca i8, i64 8, align 8
  %ptr1894 = ptrtoint ptr %mem1893 to i64
  store i64 %ptr1894, ptr %slot16, align 8
  %mem1895 = alloca i8, i64 208, align 8
  %ptr1896 = ptrtoint ptr %mem1895 to i64
  store i64 %ptr1896, ptr %slot17, align 8
  %mem1897 = alloca i8, i64 8, align 8
  %ptr1898 = ptrtoint ptr %mem1897 to i64
  store i64 %ptr1898, ptr %slot18, align 8
  %mem1899 = alloca i8, i64 8, align 8
  %ptr1900 = ptrtoint ptr %mem1899 to i64
  store i64 %ptr1900, ptr %slot19, align 8
  %mem1901 = alloca i8, i64 8, align 8
  %ptr1902 = ptrtoint ptr %mem1901 to i64
  store i64 %ptr1902, ptr %slot20, align 8
  %mem1903 = alloca i8, i64 8, align 8
  %ptr1904 = ptrtoint ptr %mem1903 to i64
  store i64 %ptr1904, ptr %slot21, align 8
  %mem1905 = alloca i8, i64 8, align 8
  %ptr1906 = ptrtoint ptr %mem1905 to i64
  store i64 %ptr1906, ptr %slot22, align 8
  %mem1907 = alloca i8, i64 8, align 8
  %ptr1908 = ptrtoint ptr %mem1907 to i64
  store i64 %ptr1908, ptr %slot23, align 8
  %mem1909 = alloca i8, i64 8, align 8
  %ptr1910 = ptrtoint ptr %mem1909 to i64
  store i64 %ptr1910, ptr %slot24, align 8
  %mem1911 = alloca i8, i64 8, align 8
  %ptr1912 = ptrtoint ptr %mem1911 to i64
  store i64 %ptr1912, ptr %slot25, align 8
  %mem1913 = alloca i8, i64 8, align 8
  %ptr1914 = ptrtoint ptr %mem1913 to i64
  store i64 %ptr1914, ptr %slot26, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1915 = alloca i8, i64 8, align 8
  %ptr1916 = ptrtoint ptr %mem1915 to i64
  store i64 %ptr1916, ptr %slot27, align 8
  %v1917 = load i64, ptr %slot1, align 8
  %op1918 = add i64 %v1917, 64
  store i64 %op1918, ptr %slot28, align 8
  %v1919 = load i64, ptr %slot28, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i64, ptr %p1920, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1921, ptr %slot29, align 8
  %stack1922 = call ptr @llvm.stacksave()
  %stackaddr1923 = ptrtoint ptr %stack1922 to i64
  %v1924 = load i64, ptr %slot29, align 8
  %cmp1925 = icmp ult i64 %stackaddr1923, %v1924
  %cv1926 = zext i1 %cmp1925 to i64
  store i64 %cv1926, ptr %slot30, align 8
  %v1927 = load i64, ptr %slot30, align 8
  %cond1928 = icmp ne i64 %v1927, 0
  br i1 %cond1928, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1929 = load i64, ptr %slot1, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  call void @myl_qbe_fail_frame(ptr %p1930) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1931 = load i64, ptr %slot22, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  store i64 0, ptr %p1932, align 8, !alias.scope !3, !noalias !4
  %v1933 = load i64, ptr %slot23, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  store i64 0, ptr %p1934, align 8, !alias.scope !3, !noalias !4
  %v1935 = load i64, ptr %slot24, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  store i64 0, ptr %p1936, align 8, !alias.scope !3, !noalias !4
  %v1937 = load i64, ptr %slot2, align 8
  %v1938 = load i64, ptr %slot19, align 8
  %p1939 = inttoptr i64 %v1938 to ptr
  store i64 %v1937, ptr %p1939, align 8, !alias.scope !3, !noalias !4
  %v1940 = load i64, ptr %slot3, align 8
  %v1941 = load i64, ptr %slot20, align 8
  %p1942 = inttoptr i64 %v1941 to ptr
  store i64 %v1940, ptr %p1942, align 8, !alias.scope !3, !noalias !4
  %v1943 = load i64, ptr %slot1, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  %call1945 = call ptr @myl_qbe_heap(ptr %p1944) nomerge, !dbg !112
  %calladdr1946 = ptrtoint ptr %call1945 to i64
  store i64 %calladdr1946, ptr %slot31, align 8
  %v1947 = load i64, ptr %slot1, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  %call1949 = call i64 @myl_qbe_region_mark(ptr %p1948) nomerge, !dbg !112
  store i64 %call1949, ptr %slot32, align 8
  %v1950 = load i64, ptr %slot5, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  store i32 0, ptr %p1951, align 4, !alias.scope !3, !noalias !4
  %v1952 = load i64, ptr %slot6, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  store i32 0, ptr %p1953, align 4, !alias.scope !3, !noalias !4
  %v1954 = load i64, ptr %slot7, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  store i32 0, ptr %p1955, align 4, !alias.scope !3, !noalias !4
  %v1956 = load i64, ptr %slot8, align 8
  %p1957 = inttoptr i64 %v1956 to ptr
  store i32 0, ptr %p1957, align 4, !alias.scope !3, !noalias !4
  %v1958 = load i64, ptr %slot9, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  store i32 0, ptr %p1959, align 4, !alias.scope !3, !noalias !4
  %v1960 = load i64, ptr %slot10, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  store i32 0, ptr %p1961, align 4, !alias.scope !3, !noalias !4
  %v1962 = load i64, ptr %slot11, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  store i32 0, ptr %p1963, align 4, !alias.scope !3, !noalias !4
  %v1964 = load i64, ptr %slot12, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  store i32 0, ptr %p1965, align 4, !alias.scope !3, !noalias !4
  %v1966 = load i64, ptr %slot13, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  store i32 0, ptr %p1967, align 4, !alias.scope !3, !noalias !4
  %v1968 = load i64, ptr %slot14, align 8
  %p1969 = inttoptr i64 %v1968 to ptr
  store i32 0, ptr %p1969, align 4, !alias.scope !3, !noalias !4
  %v1970 = load i64, ptr %slot6, align 8
  %p1971 = inttoptr i64 %v1970 to ptr
  store i32 2, ptr %p1971, align 4, !alias.scope !3, !noalias !4
  %v1972 = load i64, ptr %slot8, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  store i32 2, ptr %p1973, align 4, !alias.scope !3, !noalias !4
  %v1974 = load i64, ptr %slot10, align 8
  %p1975 = inttoptr i64 %v1974 to ptr
  store i32 2, ptr %p1975, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1976 = load i64, ptr %slot19, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  %ld1978 = load i64, ptr %p1977, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1978, ptr %slot33, align 8
  %v1979 = load i64, ptr %slot33, align 8
  %v1980 = load i64, ptr %slot25, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  store i64 %v1979, ptr %p1981, align 8, !alias.scope !3, !noalias !4
  %v1982 = load i64, ptr %slot25, align 8
  %p1983 = inttoptr i64 %v1982 to ptr
  %ld1984 = load i64, ptr %p1983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1984, ptr %slot34, align 8
  %v1985 = load i64, ptr %slot34, align 8
  %op1986 = add i64 %v1985, 96
  store i64 %op1986, ptr %slot35, align 8
  %v1987 = load i64, ptr %slot35, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  %ld1989 = load i64, ptr %p1988, align 8
  store i64 %ld1989, ptr %slot36, align 8
  %v1990 = load i64, ptr %slot36, align 8
  %v1991 = load i64, ptr %slot25, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  store i64 %v1990, ptr %p1992, align 8, !alias.scope !3, !noalias !4
  %v1993 = load i64, ptr %slot11, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  %ld1995 = load i32, ptr %p1994, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1995, ptr %slot37, align 8
  %v1996 = load i32, ptr %slot37, align 8
  %cv1997 = zext i32 %v1996 to i64
  %cond1998 = icmp ne i64 %cv1997, 0
  br i1 %cond1998, label %bb_rcslotdrop17, label %bb_rcslotdone17
bb_rcslotdrop17:
  %v1999 = load i64, ptr %slot11, align 8
  %p2000 = inttoptr i64 %v1999 to ptr
  store i32 0, ptr %p2000, align 4, !alias.scope !3, !noalias !4
  %v2001 = load i64, ptr %slot15, align 8
  store i64 %v2001, ptr %slot38, align 8
  %v2002 = load i64, ptr %slot12, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %ld2004 = load i32, ptr %p2003, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2004, ptr %slot39, align 8
  %v2005 = load i32, ptr %slot39, align 8
  %op2006 = and i32 %v2005, 28
  store i32 %op2006, ptr %slot40, align 8
  %v2007 = load i32, ptr %slot40, align 8
  %cv2008 = zext i32 %v2007 to i64
  %cond2009 = icmp ne i64 %cv2008, 0
  br i1 %cond2009, label %bb_rcslotrole17, label %bb_rcslotowner17
bb_rcslotrole17:
  %v2010 = load i64, ptr %slot31, align 8
  store i64 %v2010, ptr %slot41, align 8
  %v2011 = load i64, ptr %slot41, align 8
  %v2012 = load i64, ptr %slot38, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2011, i64 %v2012) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotowner17:
  %v2013 = load i64, ptr %slot31, align 8
  store i64 %v2013, ptr %slot42, align 8
  %v2014 = load i64, ptr %slot42, align 8
  %v2015 = load i64, ptr %slot38, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2014, i64 %v2015) nomerge, !dbg !114
  br label %bb_rcslotdone17
bb_rcslotdone17:
  %v2016 = load i64, ptr %slot19, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  %ld2018 = load i64, ptr %p2017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2018, ptr %slot43, align 8
  %v2019 = load i64, ptr %slot43, align 8
  %v2020 = load i64, ptr %slot26, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  store i64 %v2019, ptr %p2021, align 8, !alias.scope !3, !noalias !4
  %v2022 = load i64, ptr %slot26, align 8
  %p2023 = inttoptr i64 %v2022 to ptr
  %ld2024 = load i64, ptr %p2023, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2024, ptr %slot44, align 8
  %v2025 = load i64, ptr %slot44, align 8
  %op2026 = add i64 %v2025, 112
  store i64 %op2026, ptr %slot45, align 8
  %v2027 = load i64, ptr %slot45, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  %ld2029 = load i64, ptr %p2028, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2029, ptr %slot46, align 8
  %v2030 = load i64, ptr %slot46, align 8
  %v2031 = load i64, ptr %slot26, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  store i64 %v2030, ptr %p2032, align 8, !alias.scope !3, !noalias !4
  %v2033 = load i64, ptr %slot26, align 8
  %p2034 = inttoptr i64 %v2033 to ptr
  %ld2035 = load i64, ptr %p2034, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2035, ptr %slot47, align 8
  %v2036 = load i64, ptr %slot25, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  %ld2038 = load i64, ptr %p2037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2038, ptr %slot48, align 8
  %v2039 = load i64, ptr %slot48, align 8
  %v2040 = load i64, ptr %slot47, align 8
  %ovpair2042 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2039, i64 %v2040)
  %op2041 = extractvalue { i64, i1 } %ovpair2042, 0
  %ov2043 = extractvalue { i64, i1 } %ovpair2042, 1
  store i64 %op2041, ptr %slot49, align 8
  %v2044 = load i64, ptr %slot48, align 8
  %v2045 = load i64, ptr %slot47, align 8
  %op2046 = xor i64 %v2044, %v2045
  store i64 %op2046, ptr %slot50, align 8
  %v2047 = load i64, ptr %slot48, align 8
  %v2048 = load i64, ptr %slot49, align 8
  %op2049 = xor i64 %v2047, %v2048
  store i64 %op2049, ptr %slot51, align 8
  %v2050 = load i64, ptr %slot50, align 8
  %v2051 = load i64, ptr %slot51, align 8
  %op2052 = and i64 %v2050, %v2051
  store i64 %op2052, ptr %slot52, align 8
  %cv2053 = zext i1 %ov2043 to i64
  store i64 %cv2053, ptr %slot53, align 8
  %v2054 = load i64, ptr %slot53, align 8
  %cond2055 = icmp ne i64 %v2054, 0
  br i1 %cond2055, label %bb_overflow39, label %bb_checked39
bb_overflow39:
  %v2056 = load i64, ptr %slot1, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  %v2058 = load i64, ptr %slot48, align 8
  %v2059 = load i64, ptr %slot47, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2057, i64 1, i64 %v2058, i64 %v2059, i64 64) nomerge, !dbg !116
  unreachable
bb_checked39:
  %v2060 = load i64, ptr %slot49, align 8
  %v2061 = load i64, ptr %slot25, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  store i64 %v2060, ptr %p2062, align 8, !alias.scope !3, !noalias !4
  %v2063 = load i64, ptr %slot25, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  %ld2065 = load i64, ptr %p2064, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2065, ptr %slot54, align 8
  %v2066 = load i64, ptr %slot54, align 8
  %v2067 = load i64, ptr %slot21, align 8
  %p2068 = inttoptr i64 %v2067 to ptr
  store i64 %v2066, ptr %p2068, align 8, !alias.scope !3, !noalias !4
  %p2069 = inttoptr i64 ptrtoint (ptr @myl_lit_651dfa874c87674e57d05784fbb331bf215d6ec2b7d4c57db6383d02b47d316a to i64) to ptr
  %ld2070 = load i64, ptr %p2069, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2070, ptr %slot55, align 8
  %v2071 = load i64, ptr %slot55, align 8
  %v2072 = load i64, ptr %slot25, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  store i64 %v2071, ptr %p2073, align 8, !alias.scope !3, !noalias !4
  %v2074 = load i64, ptr %slot25, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %ld2076 = load i64, ptr %p2075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2076, ptr %slot56, align 8
  %v2077 = load i64, ptr %slot56, align 8
  %v2078 = load i64, ptr %slot16, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  store i64 %v2077, ptr %p2079, align 8, !alias.scope !3, !noalias !4
  %v2080 = load i64, ptr %slot16, align 8
  store i64 %v2080, ptr %slot57, align 8
  %v2081 = load i64, ptr %slot17, align 8
  store i64 %v2081, ptr %slot58, align 8
  %v2082 = load i64, ptr %slot57, align 8
  %v2083 = load i64, ptr %slot58, align 8
  %p2084 = inttoptr i64 %v2082 to ptr
  %p2085 = inttoptr i64 %v2083 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2085, ptr %p2084, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2086 = load i64, ptr %slot14, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i32 2, ptr %p2087, align 4, !alias.scope !3, !noalias !4
  %v2088 = load i64, ptr %slot13, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  store i32 1, ptr %p2089, align 4, !alias.scope !3, !noalias !4
  %v2090 = load i64, ptr %slot15, align 8
  store i64 %v2090, ptr %slot59, align 8
  %v2091 = load i64, ptr %slot17, align 8
  store i64 %v2091, ptr %slot60, align 8
  %v2092 = load i64, ptr %slot60, align 8
  %v2093 = load i64, ptr %slot59, align 8
  %p2094 = inttoptr i64 %v2092 to ptr
  %p2095 = inttoptr i64 %v2093 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2095, ptr %p2094, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2096 = load i64, ptr %slot12, align 8
  %p2097 = inttoptr i64 %v2096 to ptr
  store i32 2, ptr %p2097, align 4, !alias.scope !3, !noalias !4
  %v2098 = load i64, ptr %slot14, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  %ld2100 = load i32, ptr %p2099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2100, ptr %slot61, align 8
  %v2101 = load i32, ptr %slot61, align 8
  %v2102 = load i64, ptr %slot12, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  store i32 %v2101, ptr %p2103, align 4, !alias.scope !3, !noalias !4
  %v2104 = load i64, ptr %slot13, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i32 0, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot11, align 8
  %p2107 = inttoptr i64 %v2106 to ptr
  store i32 1, ptr %p2107, align 4, !alias.scope !3, !noalias !4
  %v2108 = load i64, ptr %slot59, align 8
  %p2109 = inttoptr i64 %v2108 to ptr
  %ld2110 = load i64, ptr %p2109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2110, ptr %slot62, align 8
  %v2111 = load i64, ptr %slot62, align 8
  %v2112 = load i64, ptr %slot25, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  store i64 %v2111, ptr %p2113, align 8, !alias.scope !3, !noalias !4
  %v2114 = load i64, ptr %slot25, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  %ld2116 = load i64, ptr %p2115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2116, ptr %slot63, align 8
  %v2117 = load i64, ptr %slot63, align 8
  %v2118 = load i64, ptr %slot16, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  store i64 %v2117, ptr %p2119, align 8, !alias.scope !3, !noalias !4
  %v2120 = load i64, ptr %slot16, align 8
  store i64 %v2120, ptr %slot64, align 8
  %v2121 = load i64, ptr %slot11, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  %ld2123 = load i32, ptr %p2122, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2123, ptr %slot65, align 8
  %v2124 = load i64, ptr %slot12, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  %ld2126 = load i32, ptr %p2125, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2126, ptr %slot66, align 8
  %v2127 = load i32, ptr %slot66, align 8
  %op2128 = and i32 %v2127, 24
  store i32 %op2128, ptr %slot66, align 8
  %v2129 = load i32, ptr %slot66, align 8
  %cmp2130 = icmp eq i32 %v2129, 0
  %cv2131 = zext i1 %cmp2130 to i32
  store i32 %cv2131, ptr %slot67, align 8
  %v2132 = load i32, ptr %slot65, align 8
  %v2133 = load i32, ptr %slot67, align 8
  %op2134 = and i32 %v2132, %v2133
  store i32 %op2134, ptr %slot68, align 8
  %v2135 = load i32, ptr %slot68, align 8
  %cv2136 = zext i32 %v2135 to i64
  %cond2137 = icmp ne i64 %cv2136, 0
  br i1 %cond2137, label %bb_rcprivateown69, label %bb_rcprivateloan69
bb_rcprivateown69:
  %v2138 = load i64, ptr %slot17, align 8
  store i64 %v2138, ptr %slot69, align 8
  %v2139 = load i64, ptr %slot32, align 8
  store i64 %v2139, ptr %slot70, align 8
  %v2140 = load i64, ptr %slot64, align 8
  %v2141 = load i64, ptr %slot69, align 8
  %op2142 = sub i64 %v2140, %v2141
  store i64 %op2142, ptr %slot71, align 8
  %v2143 = load i64, ptr %slot69, align 8
  %v2144 = load i64, ptr %slot64, align 8
  %op2145 = sub i64 %v2143, %v2144
  store i64 %op2145, ptr %slot72, align 8
  %v2146 = load i64, ptr %slot71, align 8
  %cmp2147 = icmp ult i64 %v2146, 8
  %cv2148 = zext i1 %cmp2147 to i32
  store i32 %cv2148, ptr %slot73, align 8
  %v2149 = load i64, ptr %slot72, align 8
  %cmp2150 = icmp ult i64 %v2149, 8
  %cv2151 = zext i1 %cmp2150 to i32
  store i32 %cv2151, ptr %slot74, align 8
  %v2152 = load i32, ptr %slot73, align 8
  %v2153 = load i32, ptr %slot74, align 8
  %op2154 = or i32 %v2152, %v2153
  store i32 %op2154, ptr %slot75, align 8
  %v2155 = load i32, ptr %slot75, align 8
  %cv2156 = zext i32 %v2155 to i64
  %cond2157 = icmp ne i64 %cv2156, 0
  br i1 %cond2157, label %bb_rcmoveslow72, label %bb_rcmovecheck72
bb_rcmovecheck72:
  %v2158 = load i64, ptr %slot64, align 8
  %p2160 = inttoptr i64 %v2158 to ptr
  %gep2161 = getelementptr i8, ptr %p2160, i64 0
  %op2159 = ptrtoint ptr %gep2161 to i64
  store i64 %op2159, ptr %slot76, align 8
  %v2162 = load i64, ptr %slot76, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  %ld2164 = load i64, ptr %p2163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2164, ptr %slot77, align 8
  %v2165 = load i64, ptr %slot77, align 8
  %cmp2166 = icmp ne i64 %v2165, 0
  %cv2167 = zext i1 %cmp2166 to i32
  store i32 %cv2167, ptr %slot78, align 8
  %v2168 = load i32, ptr %slot78, align 8
  %cv2169 = zext i32 %v2168 to i64
  %cond2170 = icmp ne i64 %cv2169, 0
  br i1 %cond2170, label %bb_rcmoveheader80, label %bb_rcmovenext80
bb_rcmoveheader80:
  %v2171 = load i64, ptr %slot77, align 8
  %op2172 = sub i64 %v2171, 16
  store i64 %op2172, ptr %slot79, align 8
  %v2173 = load i64, ptr %slot77, align 8
  %p2174 = inttoptr i64 %v2173 to ptr
  %rgep2175 = getelementptr i8, ptr %p2174, i64 -16
  %ld2176 = load i64, ptr %rgep2175, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2176, ptr %slot80, align 8
  %v2177 = load i64, ptr %slot80, align 8
  %op2178 = and i64 %v2177, 5764607523034234881
  store i64 %op2178, ptr %slot81, align 8
  %v2179 = load i64, ptr %slot81, align 8
  %cmp2180 = icmp ne i64 %v2179, 0
  %cv2181 = zext i1 %cmp2180 to i32
  store i32 %cv2181, ptr %slot82, align 8
  %v2182 = load i32, ptr %slot82, align 8
  %cv2183 = zext i32 %v2182 to i64
  %cond2184 = icmp ne i64 %cv2183, 0
  br i1 %cond2184, label %bb_rcmoveslow72, label %bb_rcmovenext80
bb_rcmovenext80:
  %v2185 = load i64, ptr %slot64, align 8
  %v2186 = load i64, ptr %slot69, align 8
  %p2187 = inttoptr i64 %v2185 to ptr
  %p2188 = inttoptr i64 %v2186 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2188, ptr %p2187, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot64, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  store i64 0, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved72
bb_rcmoveslow72:
  %v2191 = load i64, ptr %slot31, align 8
  %v2192 = load i64, ptr %slot69, align 8
  %v2193 = load i64, ptr %slot64, align 8
  %v2194 = load i64, ptr %slot70, align 8
  %cv2195 = trunc i64 %v2194 to i32
  %call2196 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v2191, i64 %v2192, i64 %v2193, i32 %cv2195) nomerge, !dbg !118
  store i32 %call2196, ptr %slot83, align 8
  %v2197 = load i32, ptr %slot83, align 8
  %cv2198 = zext i32 %v2197 to i64
  %cond2199 = icmp ne i64 %cv2198, 0
  br i1 %cond2199, label %bb_rcsuccess87, label %bb_rcfailure87
bb_rcfailure87:
  %v2200 = load i64, ptr %slot31, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  %call2202 = call i32 @myl_rc_take_failure(ptr %p2201) nomerge, !dbg !118
  store i32 %call2202, ptr %slot84, align 8
  %v2203 = load i64, ptr %slot1, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  %v2205 = load i32, ptr %slot84, align 8
  %call2206 = call i32 @myl_qbe_rc_status(ptr %p2204, i32 %v2205) nomerge, !dbg !118
  store i32 %call2206, ptr %slot85, align 8
  br label %bb_failure
bb_rcsuccess87:
  br label %bb_rcmoved72
bb_rcmoved72:
  %v2207 = load i64, ptr %slot11, align 8
  %p2208 = inttoptr i64 %v2207 to ptr
  store i32 0, ptr %p2208, align 4, !alias.scope !3, !noalias !4
  %v2209 = load i64, ptr %slot14, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  store i32 2, ptr %p2210, align 4, !alias.scope !3, !noalias !4
  %v2211 = load i64, ptr %slot13, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  store i32 1, ptr %p2212, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared69
bb_rcprivateloan69:
  %v2213 = load i64, ptr %slot11, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  %ld2215 = load i32, ptr %p2214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2215, ptr %slot86, align 8
  %v2216 = load i64, ptr %slot12, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  %ld2218 = load i32, ptr %p2217, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2218, ptr %slot87, align 8
  %v2219 = load i32, ptr %slot87, align 8
  %cmp2220 = icmp eq i32 %v2219, 16
  %cv2221 = zext i1 %cmp2220 to i32
  store i32 %cv2221, ptr %slot88, align 8
  %v2222 = load i32, ptr %slot88, align 8
  %v2223 = load i32, ptr %slot86, align 8
  %op2224 = and i32 %v2222, %v2223
  store i32 %op2224, ptr %slot88, align 8
  %v2225 = load i32, ptr %slot88, align 8
  %cv2226 = zext i32 %v2225 to i64
  %cond2227 = icmp ne i64 %cv2226, 0
  br i1 %cond2227, label %bb_rcprivatemove69, label %bb_rcprivatenew69
bb_rcprivatemove69:
  %v2228 = load i64, ptr %slot17, align 8
  store i64 %v2228, ptr %slot89, align 8
  %v2229 = load i64, ptr %slot64, align 8
  %v2230 = load i64, ptr %slot89, align 8
  %p2231 = inttoptr i64 %v2229 to ptr
  %p2232 = inttoptr i64 %v2230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2232, ptr %p2231, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2233 = load i64, ptr %slot64, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  store i64 0, ptr %p2234, align 8, !alias.scope !3, !noalias !4
  %v2235 = load i64, ptr %slot14, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  store i32 2, ptr %p2236, align 4, !alias.scope !3, !noalias !4
  %v2237 = load i64, ptr %slot14, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  store i32 16, ptr %p2238, align 4, !alias.scope !3, !noalias !4
  %v2239 = load i64, ptr %slot13, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  store i32 1, ptr %p2240, align 4, !alias.scope !3, !noalias !4
  %v2241 = load i64, ptr %slot11, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  store i32 0, ptr %p2242, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared69
bb_rcprivatenew69:
  %v2243 = load i64, ptr %slot17, align 8
  store i64 %v2243, ptr %slot90, align 8
  %v2244 = load i64, ptr %slot64, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  %ld2246 = load i64, ptr %p2245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2246, ptr %slot91, align 8
  %v2247 = load i64, ptr %slot91, align 8
  %cmp2248 = icmp ne i64 %v2247, 0
  %cv2249 = zext i1 %cmp2248 to i32
  store i32 %cv2249, ptr %slot92, align 8
  %v2250 = load i32, ptr %slot92, align 8
  %cv2251 = zext i32 %v2250 to i64
  %cond2252 = icmp ne i64 %cv2251, 0
  br i1 %cond2252, label %bb_rcgnn105, label %bb_rcgstore105
bb_rcgnn105:
  %v2253 = load i64, ptr %slot91, align 8
  %op2254 = sub i64 %v2253, 16
  store i64 %op2254, ptr %slot93, align 8
  %v2255 = load i64, ptr %slot91, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  %rgep2257 = getelementptr i8, ptr %p2256, i64 -16
  %ld2258 = load i64, ptr %rgep2257, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2258, ptr %slot94, align 8
  %v2259 = load i64, ptr %slot94, align 8
  %op2260 = and i64 %v2259, 4611686018427387906
  store i64 %op2260, ptr %slot95, align 8
  %v2261 = load i64, ptr %slot95, align 8
  %cmp2262 = icmp ne i64 %v2261, 0
  %cv2263 = zext i1 %cmp2262 to i32
  store i32 %cv2263, ptr %slot96, align 8
  %v2264 = load i32, ptr %slot96, align 8
  %cv2265 = zext i32 %v2264 to i64
  %cond2266 = icmp ne i64 %cv2265, 0
  br i1 %cond2266, label %bb_rcgstore105, label %bb_rcginc105
bb_rcginc105:
  %v2267 = load i64, ptr %slot91, align 8
  %op2268 = sub i64 %v2267, 24
  store i64 %op2268, ptr %slot97, align 8
  %v2269 = load i64, ptr %slot91, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  %rgep2271 = getelementptr i8, ptr %p2270, i64 -24
  %ld2272 = load i64, ptr %rgep2271, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2272, ptr %slot98, align 8
  %v2273 = load i64, ptr %slot98, align 8
  %op2274 = add i64 %v2273, 1
  store i64 %op2274, ptr %slot99, align 8
  %v2275 = load i64, ptr %slot99, align 8
  %cmp2276 = icmp eq i64 %v2275, 0
  %cv2277 = zext i1 %cmp2276 to i32
  store i32 %cv2277, ptr %slot100, align 8
  %v2278 = load i32, ptr %slot100, align 8
  %cv2279 = zext i32 %v2278 to i64
  %cond2280 = icmp ne i64 %cv2279, 0
  br i1 %cond2280, label %bb_rcglimit105, label %bb_rcgcapacity105
bb_rcglimit105:
  %v2281 = load i64, ptr %slot1, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  %call2283 = call i32 @myl_qbe_rc_status(ptr %p2282, i32 2) nomerge, !dbg !118
  store i32 %call2283, ptr %slot101, align 8
  br label %bb_failure
bb_rcgcapacity105:
  %v2284 = load i64, ptr %slot99, align 8
  %v2285 = load i64, ptr %slot91, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %rgep2287 = getelementptr i8, ptr %p2286, i64 -24
  store i64 %v2284, ptr %rgep2287, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore105
bb_rcgstore105:
  %v2288 = load i64, ptr %slot91, align 8
  %v2289 = load i64, ptr %slot90, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  store i64 %v2288, ptr %p2290, align 8, !alias.scope !3, !noalias !4
  %v2291 = load i64, ptr %slot14, align 8
  %p2292 = inttoptr i64 %v2291 to ptr
  store i32 2, ptr %p2292, align 4, !alias.scope !3, !noalias !4
  %v2293 = load i64, ptr %slot14, align 8
  %p2294 = inttoptr i64 %v2293 to ptr
  store i32 16, ptr %p2294, align 4, !alias.scope !3, !noalias !4
  %v2295 = load i64, ptr %slot13, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  store i32 1, ptr %p2296, align 4, !alias.scope !3, !noalias !4
  %v2297 = load i64, ptr %slot11, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  %ld2299 = load i32, ptr %p2298, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2299, ptr %slot102, align 8
  %v2300 = load i32, ptr %slot102, align 8
  %cv2301 = zext i32 %v2300 to i64
  %cond2302 = icmp ne i64 %cv2301, 0
  br i1 %cond2302, label %bb_rcslotdrop121, label %bb_rcslotdone121
bb_rcslotdrop121:
  %v2303 = load i64, ptr %slot11, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  store i32 0, ptr %p2304, align 4, !alias.scope !3, !noalias !4
  %v2305 = load i64, ptr %slot15, align 8
  store i64 %v2305, ptr %slot103, align 8
  %v2306 = load i64, ptr %slot12, align 8
  %p2307 = inttoptr i64 %v2306 to ptr
  %ld2308 = load i32, ptr %p2307, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2308, ptr %slot104, align 8
  %v2309 = load i32, ptr %slot104, align 8
  %op2310 = and i32 %v2309, 28
  store i32 %op2310, ptr %slot105, align 8
  %v2311 = load i32, ptr %slot105, align 8
  %cv2312 = zext i32 %v2311 to i64
  %cond2313 = icmp ne i64 %cv2312, 0
  br i1 %cond2313, label %bb_rcslotrole121, label %bb_rcslotowner121
bb_rcslotrole121:
  %v2314 = load i64, ptr %slot31, align 8
  store i64 %v2314, ptr %slot106, align 8
  %v2315 = load i64, ptr %slot103, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  %ld2317 = load i64, ptr %p2316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2317, ptr %slot107, align 8
  %v2318 = load i64, ptr %slot107, align 8
  %cmp2319 = icmp ne i64 %v2318, 0
  %cv2320 = zext i1 %cmp2319 to i32
  store i32 %cv2320, ptr %slot108, align 8
  %v2321 = load i32, ptr %slot108, align 8
  %cv2322 = zext i32 %v2321 to i64
  %cond2323 = icmp ne i64 %cv2322, 0
  br i1 %cond2323, label %bb_rcgnn137, label %bb_rcgdone137
bb_rcgnn137:
  %v2324 = load i64, ptr %slot107, align 8
  %op2325 = sub i64 %v2324, 16
  store i64 %op2325, ptr %slot109, align 8
  %v2326 = load i64, ptr %slot107, align 8
  %p2327 = inttoptr i64 %v2326 to ptr
  %rgep2328 = getelementptr i8, ptr %p2327, i64 -16
  %ld2329 = load i64, ptr %rgep2328, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2329, ptr %slot110, align 8
  %v2330 = load i64, ptr %slot110, align 8
  %op2331 = and i64 %v2330, 4611686018427387906
  store i64 %op2331, ptr %slot111, align 8
  %v2332 = load i64, ptr %slot111, align 8
  %cmp2333 = icmp ne i64 %v2332, 0
  %cv2334 = zext i1 %cmp2333 to i32
  store i32 %cv2334, ptr %slot112, align 8
  %v2335 = load i32, ptr %slot112, align 8
  %cv2336 = zext i32 %v2335 to i64
  %cond2337 = icmp ne i64 %cv2336, 0
  br i1 %cond2337, label %bb_rcgclear137, label %bb_rcgcounted137
bb_rcgcounted137:
  %v2338 = load i64, ptr %slot107, align 8
  %op2339 = sub i64 %v2338, 24
  store i64 %op2339, ptr %slot113, align 8
  %v2340 = load i64, ptr %slot107, align 8
  %p2341 = inttoptr i64 %v2340 to ptr
  %rgep2342 = getelementptr i8, ptr %p2341, i64 -24
  %ld2343 = load i64, ptr %rgep2342, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2343, ptr %slot114, align 8
  %v2344 = load i64, ptr %slot114, align 8
  %op2345 = sub i64 %v2344, 1
  store i64 %op2345, ptr %slot115, align 8
  %v2346 = load i64, ptr %slot115, align 8
  %cmp2347 = icmp eq i64 %v2346, 0
  %cv2348 = zext i1 %cmp2347 to i32
  store i32 %cv2348, ptr %slot116, align 8
  %v2349 = load i32, ptr %slot116, align 8
  %cv2350 = zext i32 %v2349 to i64
  %cond2351 = icmp ne i64 %cv2350, 0
  br i1 %cond2351, label %bb_rcglast137, label %bb_rcgdec137
bb_rcglast137:
  %v2352 = load i64, ptr %slot107, align 8
  %op2353 = sub i64 %v2352, 32
  store i64 %op2353, ptr %slot117, align 8
  %v2354 = load i64, ptr %slot107, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  %rgep2356 = getelementptr i8, ptr %p2355, i64 -32
  %ld2357 = load i64, ptr %rgep2356, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2357, ptr %slot118, align 8
  %v2358 = load i64, ptr %slot118, align 8
  %cmp2359 = icmp ne i64 %v2358, 0
  %cv2360 = zext i1 %cmp2359 to i32
  store i32 %cv2360, ptr %slot119, align 8
  %v2361 = load i32, ptr %slot119, align 8
  %cv2362 = zext i32 %v2361 to i64
  %cond2363 = icmp ne i64 %cv2362, 0
  br i1 %cond2363, label %bb_rcgdec137, label %bb_rcgslow137
bb_rcgslow137:
  %v2364 = load i64, ptr %slot106, align 8
  %v2365 = load i64, ptr %slot103, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v2364, i64 %v2365) nomerge, !dbg !118
  br label %bb_rcgdone137
bb_rcgdec137:
  %v2366 = load i64, ptr %slot115, align 8
  %v2367 = load i64, ptr %slot107, align 8
  %p2368 = inttoptr i64 %v2367 to ptr
  %rgep2369 = getelementptr i8, ptr %p2368, i64 -24
  store i64 %v2366, ptr %rgep2369, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear137
bb_rcgclear137:
  %v2370 = load i64, ptr %slot103, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  store i64 0, ptr %p2371, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone137
bb_rcgdone137:
  br label %bb_rcslotdone121
bb_rcslotowner121:
  %v2372 = load i64, ptr %slot31, align 8
  store i64 %v2372, ptr %slot120, align 8
  %v2373 = load i64, ptr %slot103, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  %ld2375 = load i64, ptr %p2374, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2375, ptr %slot121, align 8
  %v2376 = load i64, ptr %slot121, align 8
  %cmp2377 = icmp ne i64 %v2376, 0
  %cv2378 = zext i1 %cmp2377 to i32
  store i32 %cv2378, ptr %slot122, align 8
  %v2379 = load i32, ptr %slot122, align 8
  %cv2380 = zext i32 %v2379 to i64
  %cond2381 = icmp ne i64 %cv2380, 0
  br i1 %cond2381, label %bb_rcgnn152, label %bb_rcgdone152
bb_rcgnn152:
  %v2382 = load i64, ptr %slot121, align 8
  %op2383 = sub i64 %v2382, 16
  store i64 %op2383, ptr %slot123, align 8
  %v2384 = load i64, ptr %slot121, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  %rgep2386 = getelementptr i8, ptr %p2385, i64 -16
  %ld2387 = load i64, ptr %rgep2386, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2387, ptr %slot124, align 8
  %v2388 = load i64, ptr %slot124, align 8
  %op2389 = and i64 %v2388, 4611686018427387906
  store i64 %op2389, ptr %slot125, align 8
  %v2390 = load i64, ptr %slot125, align 8
  %cmp2391 = icmp ne i64 %v2390, 0
  %cv2392 = zext i1 %cmp2391 to i32
  store i32 %cv2392, ptr %slot126, align 8
  %v2393 = load i32, ptr %slot126, align 8
  %cv2394 = zext i32 %v2393 to i64
  %cond2395 = icmp ne i64 %cv2394, 0
  br i1 %cond2395, label %bb_rcgclear152, label %bb_rcgcounted152
bb_rcgcounted152:
  %v2396 = load i64, ptr %slot121, align 8
  %op2397 = sub i64 %v2396, 32
  store i64 %op2397, ptr %slot127, align 8
  %v2398 = load i64, ptr %slot121, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  %rgep2400 = getelementptr i8, ptr %p2399, i64 -32
  %ld2401 = load i64, ptr %rgep2400, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2401, ptr %slot128, align 8
  %v2402 = load i64, ptr %slot128, align 8
  %op2403 = sub i64 %v2402, 1
  store i64 %op2403, ptr %slot129, align 8
  %v2404 = load i64, ptr %slot129, align 8
  %cmp2405 = icmp eq i64 %v2404, 0
  %cv2406 = zext i1 %cmp2405 to i32
  store i32 %cv2406, ptr %slot130, align 8
  %v2407 = load i32, ptr %slot130, align 8
  %cv2408 = zext i32 %v2407 to i64
  %cond2409 = icmp ne i64 %cv2408, 0
  br i1 %cond2409, label %bb_rcglast152, label %bb_rcgdec152
bb_rcglast152:
  %v2410 = load i64, ptr %slot121, align 8
  %op2411 = sub i64 %v2410, 24
  store i64 %op2411, ptr %slot131, align 8
  %v2412 = load i64, ptr %slot121, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  %rgep2414 = getelementptr i8, ptr %p2413, i64 -24
  %ld2415 = load i64, ptr %rgep2414, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2415, ptr %slot132, align 8
  %v2416 = load i64, ptr %slot132, align 8
  %cmp2417 = icmp ne i64 %v2416, 0
  %cv2418 = zext i1 %cmp2417 to i32
  store i32 %cv2418, ptr %slot133, align 8
  %v2419 = load i32, ptr %slot133, align 8
  %cv2420 = zext i32 %v2419 to i64
  %cond2421 = icmp ne i64 %cv2420, 0
  br i1 %cond2421, label %bb_rcgdec152, label %bb_rcgslow152
bb_rcgslow152:
  %v2422 = load i64, ptr %slot120, align 8
  %v2423 = load i64, ptr %slot103, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v2422, i64 %v2423) nomerge, !dbg !118
  br label %bb_rcgdone152
bb_rcgdec152:
  %v2424 = load i64, ptr %slot129, align 8
  %v2425 = load i64, ptr %slot121, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  %rgep2427 = getelementptr i8, ptr %p2426, i64 -32
  store i64 %v2424, ptr %rgep2427, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear152
bb_rcgclear152:
  %v2428 = load i64, ptr %slot103, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  store i64 0, ptr %p2429, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone152
bb_rcgdone152:
  br label %bb_rcslotdone121
bb_rcslotdone121:
  br label %bb_rcprivateprepared69
bb_rcprivateprepared69:
  %v2430 = load i64, ptr %slot7, align 8
  %p2431 = inttoptr i64 %v2430 to ptr
  %ld2432 = load i32, ptr %p2431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2432, ptr %slot134, align 8
  %v2433 = load i32, ptr %slot134, align 8
  %cv2434 = zext i32 %v2433 to i64
  %cond2435 = icmp ne i64 %cv2434, 0
  br i1 %cond2435, label %bb_rcslotdrop159, label %bb_rcslotdone159
bb_rcslotdrop159:
  %v2436 = load i64, ptr %slot7, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  store i32 0, ptr %p2437, align 4, !alias.scope !3, !noalias !4
  %v2438 = load i64, ptr %slot23, align 8
  store i64 %v2438, ptr %slot135, align 8
  %v2439 = load i64, ptr %slot8, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  %ld2441 = load i32, ptr %p2440, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2441, ptr %slot136, align 8
  %v2442 = load i32, ptr %slot136, align 8
  %op2443 = and i32 %v2442, 28
  store i32 %op2443, ptr %slot137, align 8
  %v2444 = load i32, ptr %slot137, align 8
  %cv2445 = zext i32 %v2444 to i64
  %cond2446 = icmp ne i64 %cv2445, 0
  br i1 %cond2446, label %bb_rcslotrole159, label %bb_rcslotowner159
bb_rcslotrole159:
  %v2447 = load i64, ptr %slot31, align 8
  store i64 %v2447, ptr %slot138, align 8
  %v2448 = load i64, ptr %slot135, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  %ld2450 = load i64, ptr %p2449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2450, ptr %slot139, align 8
  %v2451 = load i64, ptr %slot139, align 8
  %cmp2452 = icmp ne i64 %v2451, 0
  %cv2453 = zext i1 %cmp2452 to i32
  store i32 %cv2453, ptr %slot140, align 8
  %v2454 = load i32, ptr %slot140, align 8
  %cv2455 = zext i32 %v2454 to i64
  %cond2456 = icmp ne i64 %cv2455, 0
  br i1 %cond2456, label %bb_rcgnn175, label %bb_rcgdone175
bb_rcgnn175:
  %v2457 = load i64, ptr %slot139, align 8
  %op2458 = sub i64 %v2457, 16
  store i64 %op2458, ptr %slot141, align 8
  %v2459 = load i64, ptr %slot139, align 8
  %p2460 = inttoptr i64 %v2459 to ptr
  %rgep2461 = getelementptr i8, ptr %p2460, i64 -16
  %ld2462 = load i64, ptr %rgep2461, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2462, ptr %slot142, align 8
  %v2463 = load i64, ptr %slot142, align 8
  %op2464 = and i64 %v2463, 4611686018427387906
  store i64 %op2464, ptr %slot143, align 8
  %v2465 = load i64, ptr %slot143, align 8
  %cmp2466 = icmp ne i64 %v2465, 0
  %cv2467 = zext i1 %cmp2466 to i32
  store i32 %cv2467, ptr %slot144, align 8
  %v2468 = load i32, ptr %slot144, align 8
  %cv2469 = zext i32 %v2468 to i64
  %cond2470 = icmp ne i64 %cv2469, 0
  br i1 %cond2470, label %bb_rcgclear175, label %bb_rcgcounted175
bb_rcgcounted175:
  %v2471 = load i64, ptr %slot139, align 8
  %op2472 = sub i64 %v2471, 24
  store i64 %op2472, ptr %slot145, align 8
  %v2473 = load i64, ptr %slot139, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  %rgep2475 = getelementptr i8, ptr %p2474, i64 -24
  %ld2476 = load i64, ptr %rgep2475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2476, ptr %slot146, align 8
  %v2477 = load i64, ptr %slot146, align 8
  %op2478 = sub i64 %v2477, 1
  store i64 %op2478, ptr %slot147, align 8
  %v2479 = load i64, ptr %slot147, align 8
  %cmp2480 = icmp eq i64 %v2479, 0
  %cv2481 = zext i1 %cmp2480 to i32
  store i32 %cv2481, ptr %slot148, align 8
  %v2482 = load i32, ptr %slot148, align 8
  %cv2483 = zext i32 %v2482 to i64
  %cond2484 = icmp ne i64 %cv2483, 0
  br i1 %cond2484, label %bb_rcglast175, label %bb_rcgdec175
bb_rcglast175:
  %v2485 = load i64, ptr %slot139, align 8
  %op2486 = sub i64 %v2485, 32
  store i64 %op2486, ptr %slot149, align 8
  %v2487 = load i64, ptr %slot139, align 8
  %p2488 = inttoptr i64 %v2487 to ptr
  %rgep2489 = getelementptr i8, ptr %p2488, i64 -32
  %ld2490 = load i64, ptr %rgep2489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2490, ptr %slot150, align 8
  %v2491 = load i64, ptr %slot150, align 8
  %cmp2492 = icmp ne i64 %v2491, 0
  %cv2493 = zext i1 %cmp2492 to i32
  store i32 %cv2493, ptr %slot151, align 8
  %v2494 = load i32, ptr %slot151, align 8
  %cv2495 = zext i32 %v2494 to i64
  %cond2496 = icmp ne i64 %cv2495, 0
  br i1 %cond2496, label %bb_rcgdec175, label %bb_rcgslow175
bb_rcgslow175:
  %v2497 = load i64, ptr %slot138, align 8
  %v2498 = load i64, ptr %slot135, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v2497, i64 %v2498) nomerge, !dbg !118
  br label %bb_rcgdone175
bb_rcgdec175:
  %v2499 = load i64, ptr %slot147, align 8
  %v2500 = load i64, ptr %slot139, align 8
  %p2501 = inttoptr i64 %v2500 to ptr
  %rgep2502 = getelementptr i8, ptr %p2501, i64 -24
  store i64 %v2499, ptr %rgep2502, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear175
bb_rcgclear175:
  %v2503 = load i64, ptr %slot135, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  store i64 0, ptr %p2504, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone175
bb_rcgdone175:
  br label %bb_rcslotdone159
bb_rcslotowner159:
  %v2505 = load i64, ptr %slot31, align 8
  store i64 %v2505, ptr %slot152, align 8
  %v2506 = load i64, ptr %slot135, align 8
  %p2507 = inttoptr i64 %v2506 to ptr
  %ld2508 = load i64, ptr %p2507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2508, ptr %slot153, align 8
  %v2509 = load i64, ptr %slot153, align 8
  %cmp2510 = icmp ne i64 %v2509, 0
  %cv2511 = zext i1 %cmp2510 to i32
  store i32 %cv2511, ptr %slot154, align 8
  %v2512 = load i32, ptr %slot154, align 8
  %cv2513 = zext i32 %v2512 to i64
  %cond2514 = icmp ne i64 %cv2513, 0
  br i1 %cond2514, label %bb_rcgnn190, label %bb_rcgdone190
bb_rcgnn190:
  %v2515 = load i64, ptr %slot153, align 8
  %op2516 = sub i64 %v2515, 16
  store i64 %op2516, ptr %slot155, align 8
  %v2517 = load i64, ptr %slot153, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  %rgep2519 = getelementptr i8, ptr %p2518, i64 -16
  %ld2520 = load i64, ptr %rgep2519, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2520, ptr %slot156, align 8
  %v2521 = load i64, ptr %slot156, align 8
  %op2522 = and i64 %v2521, 4611686018427387906
  store i64 %op2522, ptr %slot157, align 8
  %v2523 = load i64, ptr %slot157, align 8
  %cmp2524 = icmp ne i64 %v2523, 0
  %cv2525 = zext i1 %cmp2524 to i32
  store i32 %cv2525, ptr %slot158, align 8
  %v2526 = load i32, ptr %slot158, align 8
  %cv2527 = zext i32 %v2526 to i64
  %cond2528 = icmp ne i64 %cv2527, 0
  br i1 %cond2528, label %bb_rcgclear190, label %bb_rcgcounted190
bb_rcgcounted190:
  %v2529 = load i64, ptr %slot153, align 8
  %op2530 = sub i64 %v2529, 32
  store i64 %op2530, ptr %slot159, align 8
  %v2531 = load i64, ptr %slot153, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  %rgep2533 = getelementptr i8, ptr %p2532, i64 -32
  %ld2534 = load i64, ptr %rgep2533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2534, ptr %slot160, align 8
  %v2535 = load i64, ptr %slot160, align 8
  %op2536 = sub i64 %v2535, 1
  store i64 %op2536, ptr %slot161, align 8
  %v2537 = load i64, ptr %slot161, align 8
  %cmp2538 = icmp eq i64 %v2537, 0
  %cv2539 = zext i1 %cmp2538 to i32
  store i32 %cv2539, ptr %slot162, align 8
  %v2540 = load i32, ptr %slot162, align 8
  %cv2541 = zext i32 %v2540 to i64
  %cond2542 = icmp ne i64 %cv2541, 0
  br i1 %cond2542, label %bb_rcglast190, label %bb_rcgdec190
bb_rcglast190:
  %v2543 = load i64, ptr %slot153, align 8
  %op2544 = sub i64 %v2543, 24
  store i64 %op2544, ptr %slot163, align 8
  %v2545 = load i64, ptr %slot153, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  %rgep2547 = getelementptr i8, ptr %p2546, i64 -24
  %ld2548 = load i64, ptr %rgep2547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2548, ptr %slot164, align 8
  %v2549 = load i64, ptr %slot164, align 8
  %cmp2550 = icmp ne i64 %v2549, 0
  %cv2551 = zext i1 %cmp2550 to i32
  store i32 %cv2551, ptr %slot165, align 8
  %v2552 = load i32, ptr %slot165, align 8
  %cv2553 = zext i32 %v2552 to i64
  %cond2554 = icmp ne i64 %cv2553, 0
  br i1 %cond2554, label %bb_rcgdec190, label %bb_rcgslow190
bb_rcgslow190:
  %v2555 = load i64, ptr %slot152, align 8
  %v2556 = load i64, ptr %slot135, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v2555, i64 %v2556) nomerge, !dbg !118
  br label %bb_rcgdone190
bb_rcgdec190:
  %v2557 = load i64, ptr %slot161, align 8
  %v2558 = load i64, ptr %slot153, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  %rgep2560 = getelementptr i8, ptr %p2559, i64 -32
  store i64 %v2557, ptr %rgep2560, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear190
bb_rcgclear190:
  %v2561 = load i64, ptr %slot135, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  store i64 0, ptr %p2562, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone190
bb_rcgdone190:
  br label %bb_rcslotdone159
bb_rcslotdone159:
  %v2563 = load i64, ptr %slot23, align 8
  store i64 %v2563, ptr %slot166, align 8
  %v2564 = load i64, ptr %slot17, align 8
  store i64 %v2564, ptr %slot167, align 8
  %v2565 = load i64, ptr %slot167, align 8
  %v2566 = load i64, ptr %slot166, align 8
  %p2567 = inttoptr i64 %v2565 to ptr
  %p2568 = inttoptr i64 %v2566 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2568, ptr %p2567, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2569 = load i64, ptr %slot13, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  store i32 0, ptr %p2570, align 4, !alias.scope !3, !noalias !4
  %v2571 = load i64, ptr %slot8, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  store i32 2, ptr %p2572, align 4, !alias.scope !3, !noalias !4
  %v2573 = load i64, ptr %slot14, align 8
  %p2574 = inttoptr i64 %v2573 to ptr
  %ld2575 = load i32, ptr %p2574, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2575, ptr %slot168, align 8
  %v2576 = load i32, ptr %slot168, align 8
  %v2577 = load i64, ptr %slot8, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  store i32 %v2576, ptr %p2578, align 4, !alias.scope !3, !noalias !4
  %v2579 = load i64, ptr %slot7, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  store i32 1, ptr %p2580, align 4, !alias.scope !3, !noalias !4
  %v2581 = load i64, ptr %slot25, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i64 10, ptr %p2582, align 8, !alias.scope !3, !noalias !4
  %v2583 = load i64, ptr %slot25, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  %ld2585 = load i64, ptr %p2584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2585, ptr %slot169, align 8
  %v2586 = load i64, ptr %slot169, align 8
  %cmp2587 = icmp sge i64 %v2586, 0
  %cv2588 = zext i1 %cmp2587 to i64
  store i64 %cv2588, ptr %slot170, align 8
  %v2589 = load i64, ptr %slot170, align 8
  %cond2590 = icmp ne i64 %v2589, 0
  br i1 %cond2590, label %bb_success203, label %bb_failed203
bb_failed203:
  %v2591 = load i64, ptr %slot1, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p2592) nomerge, !dbg !120
  unreachable
bb_success203:
  %v2593 = load i64, ptr %slot31, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  %p2595 = inttoptr i64 ptrtoint (ptr @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a to i64) to ptr
  %v2596 = load i64, ptr %slot169, align 8
  %call2597 = call ptr @myl_native_list_new(ptr %p2594, ptr %p2595, i64 %v2596) nomerge, !dbg !120
  %calladdr2598 = ptrtoint ptr %call2597 to i64
  store i64 %calladdr2598, ptr %slot171, align 8
  %v2599 = load i64, ptr %slot171, align 8
  %cond2600 = icmp ne i64 %v2599, 0
  br i1 %cond2600, label %bb_success205, label %bb_failed205
bb_failed205:
  %v2601 = load i64, ptr %slot1, align 8
  %p2602 = inttoptr i64 %v2601 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2602) nomerge, !dbg !120
  unreachable
bb_success205:
  %v2603 = load i64, ptr %slot171, align 8
  %v2604 = load i64, ptr %slot25, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  store i64 %v2603, ptr %p2605, align 8, !alias.scope !3, !noalias !4
  %v2606 = load i64, ptr %slot25, align 8
  %p2607 = inttoptr i64 %v2606 to ptr
  %ld2608 = load i64, ptr %p2607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2608, ptr %slot172, align 8
  %v2609 = load i64, ptr %slot172, align 8
  %v2610 = load i64, ptr %slot16, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i64 %v2609, ptr %p2611, align 8, !alias.scope !3, !noalias !4
  %v2612 = load i64, ptr %slot16, align 8
  store i64 %v2612, ptr %slot173, align 8
  %v2613 = load i64, ptr %slot17, align 8
  store i64 %v2613, ptr %slot174, align 8
  %v2614 = load i64, ptr %slot173, align 8
  %v2615 = load i64, ptr %slot174, align 8
  %p2616 = inttoptr i64 %v2614 to ptr
  %p2617 = inttoptr i64 %v2615 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2617, ptr %p2616, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2618 = load i64, ptr %slot14, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  store i32 2, ptr %p2619, align 4, !alias.scope !3, !noalias !4
  %v2620 = load i64, ptr %slot13, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  store i32 1, ptr %p2621, align 4, !alias.scope !3, !noalias !4
  %v2622 = load i64, ptr %slot15, align 8
  store i64 %v2622, ptr %slot175, align 8
  %v2623 = load i64, ptr %slot17, align 8
  store i64 %v2623, ptr %slot176, align 8
  %v2624 = load i64, ptr %slot176, align 8
  %v2625 = load i64, ptr %slot175, align 8
  %p2626 = inttoptr i64 %v2624 to ptr
  %p2627 = inttoptr i64 %v2625 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2627, ptr %p2626, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2628 = load i64, ptr %slot12, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  store i32 2, ptr %p2629, align 4, !alias.scope !3, !noalias !4
  %v2630 = load i64, ptr %slot14, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  %ld2632 = load i32, ptr %p2631, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2632, ptr %slot177, align 8
  %v2633 = load i32, ptr %slot177, align 8
  %v2634 = load i64, ptr %slot12, align 8
  %p2635 = inttoptr i64 %v2634 to ptr
  store i32 %v2633, ptr %p2635, align 4, !alias.scope !3, !noalias !4
  %v2636 = load i64, ptr %slot13, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  store i32 0, ptr %p2637, align 4, !alias.scope !3, !noalias !4
  %v2638 = load i64, ptr %slot11, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  store i32 1, ptr %p2639, align 4, !alias.scope !3, !noalias !4
  %v2640 = load i64, ptr %slot175, align 8
  %p2641 = inttoptr i64 %v2640 to ptr
  %ld2642 = load i64, ptr %p2641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2642, ptr %slot178, align 8
  %v2643 = load i64, ptr %slot178, align 8
  %v2644 = load i64, ptr %slot25, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  store i64 %v2643, ptr %p2645, align 8, !alias.scope !3, !noalias !4
  %v2646 = load i64, ptr %slot25, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  %ld2648 = load i64, ptr %p2647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2648, ptr %slot179, align 8
  %v2649 = load i64, ptr %slot179, align 8
  %v2650 = load i64, ptr %slot16, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  store i64 %v2649, ptr %p2651, align 8, !alias.scope !3, !noalias !4
  %v2652 = load i64, ptr %slot16, align 8
  store i64 %v2652, ptr %slot180, align 8
  %v2653 = load i64, ptr %slot11, align 8
  %p2654 = inttoptr i64 %v2653 to ptr
  %ld2655 = load i32, ptr %p2654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2655, ptr %slot181, align 8
  %v2656 = load i64, ptr %slot12, align 8
  %p2657 = inttoptr i64 %v2656 to ptr
  %ld2658 = load i32, ptr %p2657, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2658, ptr %slot182, align 8
  %v2659 = load i32, ptr %slot182, align 8
  %op2660 = and i32 %v2659, 24
  store i32 %op2660, ptr %slot182, align 8
  %v2661 = load i32, ptr %slot182, align 8
  %cmp2662 = icmp eq i32 %v2661, 0
  %cv2663 = zext i1 %cmp2662 to i32
  store i32 %cv2663, ptr %slot183, align 8
  %v2664 = load i32, ptr %slot181, align 8
  %v2665 = load i32, ptr %slot183, align 8
  %op2666 = and i32 %v2664, %v2665
  store i32 %op2666, ptr %slot184, align 8
  %v2667 = load i32, ptr %slot184, align 8
  %cv2668 = zext i32 %v2667 to i64
  %cond2669 = icmp ne i64 %cv2668, 0
  br i1 %cond2669, label %bb_rcprivateown228, label %bb_rcprivateloan228
bb_rcprivateown228:
  %v2670 = load i64, ptr %slot17, align 8
  store i64 %v2670, ptr %slot185, align 8
  %v2671 = load i64, ptr %slot32, align 8
  store i64 %v2671, ptr %slot186, align 8
  %v2672 = load i64, ptr %slot180, align 8
  %v2673 = load i64, ptr %slot185, align 8
  %op2674 = sub i64 %v2672, %v2673
  store i64 %op2674, ptr %slot187, align 8
  %v2675 = load i64, ptr %slot185, align 8
  %v2676 = load i64, ptr %slot180, align 8
  %op2677 = sub i64 %v2675, %v2676
  store i64 %op2677, ptr %slot188, align 8
  %v2678 = load i64, ptr %slot187, align 8
  %cmp2679 = icmp ult i64 %v2678, 8
  %cv2680 = zext i1 %cmp2679 to i32
  store i32 %cv2680, ptr %slot189, align 8
  %v2681 = load i64, ptr %slot188, align 8
  %cmp2682 = icmp ult i64 %v2681, 8
  %cv2683 = zext i1 %cmp2682 to i32
  store i32 %cv2683, ptr %slot190, align 8
  %v2684 = load i32, ptr %slot189, align 8
  %v2685 = load i32, ptr %slot190, align 8
  %op2686 = or i32 %v2684, %v2685
  store i32 %op2686, ptr %slot191, align 8
  %v2687 = load i32, ptr %slot191, align 8
  %cv2688 = zext i32 %v2687 to i64
  %cond2689 = icmp ne i64 %cv2688, 0
  br i1 %cond2689, label %bb_rcmoveslow231, label %bb_rcmovecheck231
bb_rcmovecheck231:
  %v2690 = load i64, ptr %slot180, align 8
  %p2692 = inttoptr i64 %v2690 to ptr
  %gep2693 = getelementptr i8, ptr %p2692, i64 0
  %op2691 = ptrtoint ptr %gep2693 to i64
  store i64 %op2691, ptr %slot192, align 8
  %v2694 = load i64, ptr %slot192, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  %ld2696 = load i64, ptr %p2695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2696, ptr %slot193, align 8
  %v2697 = load i64, ptr %slot193, align 8
  %cmp2698 = icmp ne i64 %v2697, 0
  %cv2699 = zext i1 %cmp2698 to i32
  store i32 %cv2699, ptr %slot194, align 8
  %v2700 = load i32, ptr %slot194, align 8
  %cv2701 = zext i32 %v2700 to i64
  %cond2702 = icmp ne i64 %cv2701, 0
  br i1 %cond2702, label %bb_rcmoveheader239, label %bb_rcmovenext239
bb_rcmoveheader239:
  %v2703 = load i64, ptr %slot193, align 8
  %op2704 = sub i64 %v2703, 16
  store i64 %op2704, ptr %slot195, align 8
  %v2705 = load i64, ptr %slot193, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  %rgep2707 = getelementptr i8, ptr %p2706, i64 -16
  %ld2708 = load i64, ptr %rgep2707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2708, ptr %slot196, align 8
  %v2709 = load i64, ptr %slot196, align 8
  %op2710 = and i64 %v2709, 5764607523034234881
  store i64 %op2710, ptr %slot197, align 8
  %v2711 = load i64, ptr %slot197, align 8
  %cmp2712 = icmp ne i64 %v2711, 0
  %cv2713 = zext i1 %cmp2712 to i32
  store i32 %cv2713, ptr %slot198, align 8
  %v2714 = load i32, ptr %slot198, align 8
  %cv2715 = zext i32 %v2714 to i64
  %cond2716 = icmp ne i64 %cv2715, 0
  br i1 %cond2716, label %bb_rcmoveslow231, label %bb_rcmovenext239
bb_rcmovenext239:
  %v2717 = load i64, ptr %slot180, align 8
  %v2718 = load i64, ptr %slot185, align 8
  %p2719 = inttoptr i64 %v2717 to ptr
  %p2720 = inttoptr i64 %v2718 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2720, ptr %p2719, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2721 = load i64, ptr %slot180, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  store i64 0, ptr %p2722, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved231
bb_rcmoveslow231:
  %v2723 = load i64, ptr %slot31, align 8
  %v2724 = load i64, ptr %slot185, align 8
  %v2725 = load i64, ptr %slot180, align 8
  %v2726 = load i64, ptr %slot186, align 8
  %cv2727 = trunc i64 %v2726 to i32
  %call2728 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take(i64 %v2723, i64 %v2724, i64 %v2725, i32 %cv2727) nomerge, !dbg !122
  store i32 %call2728, ptr %slot199, align 8
  %v2729 = load i32, ptr %slot199, align 8
  %cv2730 = zext i32 %v2729 to i64
  %cond2731 = icmp ne i64 %cv2730, 0
  br i1 %cond2731, label %bb_rcsuccess246, label %bb_rcfailure246
bb_rcfailure246:
  %v2732 = load i64, ptr %slot31, align 8
  %p2733 = inttoptr i64 %v2732 to ptr
  %call2734 = call i32 @myl_rc_take_failure(ptr %p2733) nomerge, !dbg !122
  store i32 %call2734, ptr %slot200, align 8
  %v2735 = load i64, ptr %slot1, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  %v2737 = load i32, ptr %slot200, align 8
  %call2738 = call i32 @myl_qbe_rc_status(ptr %p2736, i32 %v2737) nomerge, !dbg !122
  store i32 %call2738, ptr %slot201, align 8
  br label %bb_failure
bb_rcsuccess246:
  br label %bb_rcmoved231
bb_rcmoved231:
  %v2739 = load i64, ptr %slot11, align 8
  %p2740 = inttoptr i64 %v2739 to ptr
  store i32 0, ptr %p2740, align 4, !alias.scope !3, !noalias !4
  %v2741 = load i64, ptr %slot14, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  store i32 2, ptr %p2742, align 4, !alias.scope !3, !noalias !4
  %v2743 = load i64, ptr %slot13, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  store i32 1, ptr %p2744, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared228
bb_rcprivateloan228:
  %v2745 = load i64, ptr %slot11, align 8
  %p2746 = inttoptr i64 %v2745 to ptr
  %ld2747 = load i32, ptr %p2746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2747, ptr %slot202, align 8
  %v2748 = load i64, ptr %slot12, align 8
  %p2749 = inttoptr i64 %v2748 to ptr
  %ld2750 = load i32, ptr %p2749, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2750, ptr %slot203, align 8
  %v2751 = load i32, ptr %slot203, align 8
  %cmp2752 = icmp eq i32 %v2751, 16
  %cv2753 = zext i1 %cmp2752 to i32
  store i32 %cv2753, ptr %slot204, align 8
  %v2754 = load i32, ptr %slot204, align 8
  %v2755 = load i32, ptr %slot202, align 8
  %op2756 = and i32 %v2754, %v2755
  store i32 %op2756, ptr %slot204, align 8
  %v2757 = load i32, ptr %slot204, align 8
  %cv2758 = zext i32 %v2757 to i64
  %cond2759 = icmp ne i64 %cv2758, 0
  br i1 %cond2759, label %bb_rcprivatemove228, label %bb_rcprivatenew228
bb_rcprivatemove228:
  %v2760 = load i64, ptr %slot17, align 8
  store i64 %v2760, ptr %slot205, align 8
  %v2761 = load i64, ptr %slot180, align 8
  %v2762 = load i64, ptr %slot205, align 8
  %p2763 = inttoptr i64 %v2761 to ptr
  %p2764 = inttoptr i64 %v2762 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2764, ptr %p2763, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2765 = load i64, ptr %slot180, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  store i64 0, ptr %p2766, align 8, !alias.scope !3, !noalias !4
  %v2767 = load i64, ptr %slot14, align 8
  %p2768 = inttoptr i64 %v2767 to ptr
  store i32 2, ptr %p2768, align 4, !alias.scope !3, !noalias !4
  %v2769 = load i64, ptr %slot14, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  store i32 16, ptr %p2770, align 4, !alias.scope !3, !noalias !4
  %v2771 = load i64, ptr %slot13, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  store i32 1, ptr %p2772, align 4, !alias.scope !3, !noalias !4
  %v2773 = load i64, ptr %slot11, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i32 0, ptr %p2774, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared228
bb_rcprivatenew228:
  %v2775 = load i64, ptr %slot17, align 8
  store i64 %v2775, ptr %slot206, align 8
  %v2776 = load i64, ptr %slot180, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  %ld2778 = load i64, ptr %p2777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2778, ptr %slot207, align 8
  %v2779 = load i64, ptr %slot207, align 8
  %cmp2780 = icmp ne i64 %v2779, 0
  %cv2781 = zext i1 %cmp2780 to i32
  store i32 %cv2781, ptr %slot208, align 8
  %v2782 = load i32, ptr %slot208, align 8
  %cv2783 = zext i32 %v2782 to i64
  %cond2784 = icmp ne i64 %cv2783, 0
  br i1 %cond2784, label %bb_rcgnn264, label %bb_rcgstore264
bb_rcgnn264:
  %v2785 = load i64, ptr %slot207, align 8
  %op2786 = sub i64 %v2785, 16
  store i64 %op2786, ptr %slot209, align 8
  %v2787 = load i64, ptr %slot207, align 8
  %p2788 = inttoptr i64 %v2787 to ptr
  %rgep2789 = getelementptr i8, ptr %p2788, i64 -16
  %ld2790 = load i64, ptr %rgep2789, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2790, ptr %slot210, align 8
  %v2791 = load i64, ptr %slot210, align 8
  %op2792 = and i64 %v2791, 4611686018427387906
  store i64 %op2792, ptr %slot211, align 8
  %v2793 = load i64, ptr %slot211, align 8
  %cmp2794 = icmp ne i64 %v2793, 0
  %cv2795 = zext i1 %cmp2794 to i32
  store i32 %cv2795, ptr %slot212, align 8
  %v2796 = load i32, ptr %slot212, align 8
  %cv2797 = zext i32 %v2796 to i64
  %cond2798 = icmp ne i64 %cv2797, 0
  br i1 %cond2798, label %bb_rcgstore264, label %bb_rcginc264
bb_rcginc264:
  %v2799 = load i64, ptr %slot207, align 8
  %op2800 = sub i64 %v2799, 24
  store i64 %op2800, ptr %slot213, align 8
  %v2801 = load i64, ptr %slot207, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  %rgep2803 = getelementptr i8, ptr %p2802, i64 -24
  %ld2804 = load i64, ptr %rgep2803, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2804, ptr %slot214, align 8
  %v2805 = load i64, ptr %slot214, align 8
  %op2806 = add i64 %v2805, 1
  store i64 %op2806, ptr %slot215, align 8
  %v2807 = load i64, ptr %slot215, align 8
  %cmp2808 = icmp eq i64 %v2807, 0
  %cv2809 = zext i1 %cmp2808 to i32
  store i32 %cv2809, ptr %slot216, align 8
  %v2810 = load i32, ptr %slot216, align 8
  %cv2811 = zext i32 %v2810 to i64
  %cond2812 = icmp ne i64 %cv2811, 0
  br i1 %cond2812, label %bb_rcglimit264, label %bb_rcgcapacity264
bb_rcglimit264:
  %v2813 = load i64, ptr %slot1, align 8
  %p2814 = inttoptr i64 %v2813 to ptr
  %call2815 = call i32 @myl_qbe_rc_status(ptr %p2814, i32 2) nomerge, !dbg !122
  store i32 %call2815, ptr %slot217, align 8
  br label %bb_failure
bb_rcgcapacity264:
  %v2816 = load i64, ptr %slot215, align 8
  %v2817 = load i64, ptr %slot207, align 8
  %p2818 = inttoptr i64 %v2817 to ptr
  %rgep2819 = getelementptr i8, ptr %p2818, i64 -24
  store i64 %v2816, ptr %rgep2819, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore264
bb_rcgstore264:
  %v2820 = load i64, ptr %slot207, align 8
  %v2821 = load i64, ptr %slot206, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  store i64 %v2820, ptr %p2822, align 8, !alias.scope !3, !noalias !4
  %v2823 = load i64, ptr %slot14, align 8
  %p2824 = inttoptr i64 %v2823 to ptr
  store i32 2, ptr %p2824, align 4, !alias.scope !3, !noalias !4
  %v2825 = load i64, ptr %slot14, align 8
  %p2826 = inttoptr i64 %v2825 to ptr
  store i32 16, ptr %p2826, align 4, !alias.scope !3, !noalias !4
  %v2827 = load i64, ptr %slot13, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  store i32 1, ptr %p2828, align 4, !alias.scope !3, !noalias !4
  %v2829 = load i64, ptr %slot11, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  %ld2831 = load i32, ptr %p2830, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2831, ptr %slot218, align 8
  %v2832 = load i32, ptr %slot218, align 8
  %cv2833 = zext i32 %v2832 to i64
  %cond2834 = icmp ne i64 %cv2833, 0
  br i1 %cond2834, label %bb_rcslotdrop280, label %bb_rcslotdone280
bb_rcslotdrop280:
  %v2835 = load i64, ptr %slot11, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  store i32 0, ptr %p2836, align 4, !alias.scope !3, !noalias !4
  %v2837 = load i64, ptr %slot15, align 8
  store i64 %v2837, ptr %slot219, align 8
  %v2838 = load i64, ptr %slot12, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  %ld2840 = load i32, ptr %p2839, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2840, ptr %slot220, align 8
  %v2841 = load i32, ptr %slot220, align 8
  %op2842 = and i32 %v2841, 28
  store i32 %op2842, ptr %slot221, align 8
  %v2843 = load i32, ptr %slot221, align 8
  %cv2844 = zext i32 %v2843 to i64
  %cond2845 = icmp ne i64 %cv2844, 0
  br i1 %cond2845, label %bb_rcslotrole280, label %bb_rcslotowner280
bb_rcslotrole280:
  %v2846 = load i64, ptr %slot31, align 8
  store i64 %v2846, ptr %slot222, align 8
  %v2847 = load i64, ptr %slot219, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %ld2849 = load i64, ptr %p2848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2849, ptr %slot223, align 8
  %v2850 = load i64, ptr %slot223, align 8
  %cmp2851 = icmp ne i64 %v2850, 0
  %cv2852 = zext i1 %cmp2851 to i32
  store i32 %cv2852, ptr %slot224, align 8
  %v2853 = load i32, ptr %slot224, align 8
  %cv2854 = zext i32 %v2853 to i64
  %cond2855 = icmp ne i64 %cv2854, 0
  br i1 %cond2855, label %bb_rcgnn296, label %bb_rcgdone296
bb_rcgnn296:
  %v2856 = load i64, ptr %slot223, align 8
  %op2857 = sub i64 %v2856, 16
  store i64 %op2857, ptr %slot225, align 8
  %v2858 = load i64, ptr %slot223, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  %rgep2860 = getelementptr i8, ptr %p2859, i64 -16
  %ld2861 = load i64, ptr %rgep2860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2861, ptr %slot226, align 8
  %v2862 = load i64, ptr %slot226, align 8
  %op2863 = and i64 %v2862, 4611686018427387906
  store i64 %op2863, ptr %slot227, align 8
  %v2864 = load i64, ptr %slot227, align 8
  %cmp2865 = icmp ne i64 %v2864, 0
  %cv2866 = zext i1 %cmp2865 to i32
  store i32 %cv2866, ptr %slot228, align 8
  %v2867 = load i32, ptr %slot228, align 8
  %cv2868 = zext i32 %v2867 to i64
  %cond2869 = icmp ne i64 %cv2868, 0
  br i1 %cond2869, label %bb_rcgclear296, label %bb_rcgcounted296
bb_rcgcounted296:
  %v2870 = load i64, ptr %slot223, align 8
  %op2871 = sub i64 %v2870, 24
  store i64 %op2871, ptr %slot229, align 8
  %v2872 = load i64, ptr %slot223, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  %rgep2874 = getelementptr i8, ptr %p2873, i64 -24
  %ld2875 = load i64, ptr %rgep2874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2875, ptr %slot230, align 8
  %v2876 = load i64, ptr %slot230, align 8
  %op2877 = sub i64 %v2876, 1
  store i64 %op2877, ptr %slot231, align 8
  %v2878 = load i64, ptr %slot231, align 8
  %cmp2879 = icmp eq i64 %v2878, 0
  %cv2880 = zext i1 %cmp2879 to i32
  store i32 %cv2880, ptr %slot232, align 8
  %v2881 = load i32, ptr %slot232, align 8
  %cv2882 = zext i32 %v2881 to i64
  %cond2883 = icmp ne i64 %cv2882, 0
  br i1 %cond2883, label %bb_rcglast296, label %bb_rcgdec296
bb_rcglast296:
  %v2884 = load i64, ptr %slot223, align 8
  %op2885 = sub i64 %v2884, 32
  store i64 %op2885, ptr %slot233, align 8
  %v2886 = load i64, ptr %slot223, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  %rgep2888 = getelementptr i8, ptr %p2887, i64 -32
  %ld2889 = load i64, ptr %rgep2888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2889, ptr %slot234, align 8
  %v2890 = load i64, ptr %slot234, align 8
  %cmp2891 = icmp ne i64 %v2890, 0
  %cv2892 = zext i1 %cmp2891 to i32
  store i32 %cv2892, ptr %slot235, align 8
  %v2893 = load i32, ptr %slot235, align 8
  %cv2894 = zext i32 %v2893 to i64
  %cond2895 = icmp ne i64 %cv2894, 0
  br i1 %cond2895, label %bb_rcgdec296, label %bb_rcgslow296
bb_rcgslow296:
  %v2896 = load i64, ptr %slot222, align 8
  %v2897 = load i64, ptr %slot219, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v2896, i64 %v2897) nomerge, !dbg !122
  br label %bb_rcgdone296
bb_rcgdec296:
  %v2898 = load i64, ptr %slot231, align 8
  %v2899 = load i64, ptr %slot223, align 8
  %p2900 = inttoptr i64 %v2899 to ptr
  %rgep2901 = getelementptr i8, ptr %p2900, i64 -24
  store i64 %v2898, ptr %rgep2901, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear296
bb_rcgclear296:
  %v2902 = load i64, ptr %slot219, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  store i64 0, ptr %p2903, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone296
bb_rcgdone296:
  br label %bb_rcslotdone280
bb_rcslotowner280:
  %v2904 = load i64, ptr %slot31, align 8
  store i64 %v2904, ptr %slot236, align 8
  %v2905 = load i64, ptr %slot219, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  %ld2907 = load i64, ptr %p2906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2907, ptr %slot237, align 8
  %v2908 = load i64, ptr %slot237, align 8
  %cmp2909 = icmp ne i64 %v2908, 0
  %cv2910 = zext i1 %cmp2909 to i32
  store i32 %cv2910, ptr %slot238, align 8
  %v2911 = load i32, ptr %slot238, align 8
  %cv2912 = zext i32 %v2911 to i64
  %cond2913 = icmp ne i64 %cv2912, 0
  br i1 %cond2913, label %bb_rcgnn311, label %bb_rcgdone311
bb_rcgnn311:
  %v2914 = load i64, ptr %slot237, align 8
  %op2915 = sub i64 %v2914, 16
  store i64 %op2915, ptr %slot239, align 8
  %v2916 = load i64, ptr %slot237, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  %rgep2918 = getelementptr i8, ptr %p2917, i64 -16
  %ld2919 = load i64, ptr %rgep2918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2919, ptr %slot240, align 8
  %v2920 = load i64, ptr %slot240, align 8
  %op2921 = and i64 %v2920, 4611686018427387906
  store i64 %op2921, ptr %slot241, align 8
  %v2922 = load i64, ptr %slot241, align 8
  %cmp2923 = icmp ne i64 %v2922, 0
  %cv2924 = zext i1 %cmp2923 to i32
  store i32 %cv2924, ptr %slot242, align 8
  %v2925 = load i32, ptr %slot242, align 8
  %cv2926 = zext i32 %v2925 to i64
  %cond2927 = icmp ne i64 %cv2926, 0
  br i1 %cond2927, label %bb_rcgclear311, label %bb_rcgcounted311
bb_rcgcounted311:
  %v2928 = load i64, ptr %slot237, align 8
  %op2929 = sub i64 %v2928, 32
  store i64 %op2929, ptr %slot243, align 8
  %v2930 = load i64, ptr %slot237, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  %rgep2932 = getelementptr i8, ptr %p2931, i64 -32
  %ld2933 = load i64, ptr %rgep2932, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2933, ptr %slot244, align 8
  %v2934 = load i64, ptr %slot244, align 8
  %op2935 = sub i64 %v2934, 1
  store i64 %op2935, ptr %slot245, align 8
  %v2936 = load i64, ptr %slot245, align 8
  %cmp2937 = icmp eq i64 %v2936, 0
  %cv2938 = zext i1 %cmp2937 to i32
  store i32 %cv2938, ptr %slot246, align 8
  %v2939 = load i32, ptr %slot246, align 8
  %cv2940 = zext i32 %v2939 to i64
  %cond2941 = icmp ne i64 %cv2940, 0
  br i1 %cond2941, label %bb_rcglast311, label %bb_rcgdec311
bb_rcglast311:
  %v2942 = load i64, ptr %slot237, align 8
  %op2943 = sub i64 %v2942, 24
  store i64 %op2943, ptr %slot247, align 8
  %v2944 = load i64, ptr %slot237, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  %rgep2946 = getelementptr i8, ptr %p2945, i64 -24
  %ld2947 = load i64, ptr %rgep2946, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2947, ptr %slot248, align 8
  %v2948 = load i64, ptr %slot248, align 8
  %cmp2949 = icmp ne i64 %v2948, 0
  %cv2950 = zext i1 %cmp2949 to i32
  store i32 %cv2950, ptr %slot249, align 8
  %v2951 = load i32, ptr %slot249, align 8
  %cv2952 = zext i32 %v2951 to i64
  %cond2953 = icmp ne i64 %cv2952, 0
  br i1 %cond2953, label %bb_rcgdec311, label %bb_rcgslow311
bb_rcgslow311:
  %v2954 = load i64, ptr %slot236, align 8
  %v2955 = load i64, ptr %slot219, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v2954, i64 %v2955) nomerge, !dbg !122
  br label %bb_rcgdone311
bb_rcgdec311:
  %v2956 = load i64, ptr %slot245, align 8
  %v2957 = load i64, ptr %slot237, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  %rgep2959 = getelementptr i8, ptr %p2958, i64 -32
  store i64 %v2956, ptr %rgep2959, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear311
bb_rcgclear311:
  %v2960 = load i64, ptr %slot219, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  store i64 0, ptr %p2961, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone311
bb_rcgdone311:
  br label %bb_rcslotdone280
bb_rcslotdone280:
  br label %bb_rcprivateprepared228
bb_rcprivateprepared228:
  %v2962 = load i64, ptr %slot5, align 8
  %p2963 = inttoptr i64 %v2962 to ptr
  %ld2964 = load i32, ptr %p2963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2964, ptr %slot250, align 8
  %v2965 = load i32, ptr %slot250, align 8
  %cv2966 = zext i32 %v2965 to i64
  %cond2967 = icmp ne i64 %cv2966, 0
  br i1 %cond2967, label %bb_rcslotdrop318, label %bb_rcslotdone318
bb_rcslotdrop318:
  %v2968 = load i64, ptr %slot5, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  store i32 0, ptr %p2969, align 4, !alias.scope !3, !noalias !4
  %v2970 = load i64, ptr %slot22, align 8
  store i64 %v2970, ptr %slot251, align 8
  %v2971 = load i64, ptr %slot6, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  %ld2973 = load i32, ptr %p2972, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2973, ptr %slot252, align 8
  %v2974 = load i32, ptr %slot252, align 8
  %op2975 = and i32 %v2974, 28
  store i32 %op2975, ptr %slot253, align 8
  %v2976 = load i32, ptr %slot253, align 8
  %cv2977 = zext i32 %v2976 to i64
  %cond2978 = icmp ne i64 %cv2977, 0
  br i1 %cond2978, label %bb_rcslotrole318, label %bb_rcslotowner318
bb_rcslotrole318:
  %v2979 = load i64, ptr %slot31, align 8
  store i64 %v2979, ptr %slot254, align 8
  %v2980 = load i64, ptr %slot251, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  %ld2982 = load i64, ptr %p2981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2982, ptr %slot255, align 8
  %v2983 = load i64, ptr %slot255, align 8
  %cmp2984 = icmp ne i64 %v2983, 0
  %cv2985 = zext i1 %cmp2984 to i32
  store i32 %cv2985, ptr %slot256, align 8
  %v2986 = load i32, ptr %slot256, align 8
  %cv2987 = zext i32 %v2986 to i64
  %cond2988 = icmp ne i64 %cv2987, 0
  br i1 %cond2988, label %bb_rcgnn334, label %bb_rcgdone334
bb_rcgnn334:
  %v2989 = load i64, ptr %slot255, align 8
  %op2990 = sub i64 %v2989, 16
  store i64 %op2990, ptr %slot257, align 8
  %v2991 = load i64, ptr %slot255, align 8
  %p2992 = inttoptr i64 %v2991 to ptr
  %rgep2993 = getelementptr i8, ptr %p2992, i64 -16
  %ld2994 = load i64, ptr %rgep2993, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2994, ptr %slot258, align 8
  %v2995 = load i64, ptr %slot258, align 8
  %op2996 = and i64 %v2995, 4611686018427387906
  store i64 %op2996, ptr %slot259, align 8
  %v2997 = load i64, ptr %slot259, align 8
  %cmp2998 = icmp ne i64 %v2997, 0
  %cv2999 = zext i1 %cmp2998 to i32
  store i32 %cv2999, ptr %slot260, align 8
  %v3000 = load i32, ptr %slot260, align 8
  %cv3001 = zext i32 %v3000 to i64
  %cond3002 = icmp ne i64 %cv3001, 0
  br i1 %cond3002, label %bb_rcgclear334, label %bb_rcgcounted334
bb_rcgcounted334:
  %v3003 = load i64, ptr %slot255, align 8
  %op3004 = sub i64 %v3003, 24
  store i64 %op3004, ptr %slot261, align 8
  %v3005 = load i64, ptr %slot255, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  %rgep3007 = getelementptr i8, ptr %p3006, i64 -24
  %ld3008 = load i64, ptr %rgep3007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3008, ptr %slot262, align 8
  %v3009 = load i64, ptr %slot262, align 8
  %op3010 = sub i64 %v3009, 1
  store i64 %op3010, ptr %slot263, align 8
  %v3011 = load i64, ptr %slot263, align 8
  %cmp3012 = icmp eq i64 %v3011, 0
  %cv3013 = zext i1 %cmp3012 to i32
  store i32 %cv3013, ptr %slot264, align 8
  %v3014 = load i32, ptr %slot264, align 8
  %cv3015 = zext i32 %v3014 to i64
  %cond3016 = icmp ne i64 %cv3015, 0
  br i1 %cond3016, label %bb_rcglast334, label %bb_rcgdec334
bb_rcglast334:
  %v3017 = load i64, ptr %slot255, align 8
  %op3018 = sub i64 %v3017, 32
  store i64 %op3018, ptr %slot265, align 8
  %v3019 = load i64, ptr %slot255, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %rgep3021 = getelementptr i8, ptr %p3020, i64 -32
  %ld3022 = load i64, ptr %rgep3021, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3022, ptr %slot266, align 8
  %v3023 = load i64, ptr %slot266, align 8
  %cmp3024 = icmp ne i64 %v3023, 0
  %cv3025 = zext i1 %cmp3024 to i32
  store i32 %cv3025, ptr %slot267, align 8
  %v3026 = load i32, ptr %slot267, align 8
  %cv3027 = zext i32 %v3026 to i64
  %cond3028 = icmp ne i64 %cv3027, 0
  br i1 %cond3028, label %bb_rcgdec334, label %bb_rcgslow334
bb_rcgslow334:
  %v3029 = load i64, ptr %slot254, align 8
  %v3030 = load i64, ptr %slot251, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v3029, i64 %v3030) nomerge, !dbg !122
  br label %bb_rcgdone334
bb_rcgdec334:
  %v3031 = load i64, ptr %slot263, align 8
  %v3032 = load i64, ptr %slot255, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  %rgep3034 = getelementptr i8, ptr %p3033, i64 -24
  store i64 %v3031, ptr %rgep3034, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear334
bb_rcgclear334:
  %v3035 = load i64, ptr %slot251, align 8
  %p3036 = inttoptr i64 %v3035 to ptr
  store i64 0, ptr %p3036, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone334
bb_rcgdone334:
  br label %bb_rcslotdone318
bb_rcslotowner318:
  %v3037 = load i64, ptr %slot31, align 8
  store i64 %v3037, ptr %slot268, align 8
  %v3038 = load i64, ptr %slot251, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  %ld3040 = load i64, ptr %p3039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3040, ptr %slot269, align 8
  %v3041 = load i64, ptr %slot269, align 8
  %cmp3042 = icmp ne i64 %v3041, 0
  %cv3043 = zext i1 %cmp3042 to i32
  store i32 %cv3043, ptr %slot270, align 8
  %v3044 = load i32, ptr %slot270, align 8
  %cv3045 = zext i32 %v3044 to i64
  %cond3046 = icmp ne i64 %cv3045, 0
  br i1 %cond3046, label %bb_rcgnn349, label %bb_rcgdone349
bb_rcgnn349:
  %v3047 = load i64, ptr %slot269, align 8
  %op3048 = sub i64 %v3047, 16
  store i64 %op3048, ptr %slot271, align 8
  %v3049 = load i64, ptr %slot269, align 8
  %p3050 = inttoptr i64 %v3049 to ptr
  %rgep3051 = getelementptr i8, ptr %p3050, i64 -16
  %ld3052 = load i64, ptr %rgep3051, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3052, ptr %slot272, align 8
  %v3053 = load i64, ptr %slot272, align 8
  %op3054 = and i64 %v3053, 4611686018427387906
  store i64 %op3054, ptr %slot273, align 8
  %v3055 = load i64, ptr %slot273, align 8
  %cmp3056 = icmp ne i64 %v3055, 0
  %cv3057 = zext i1 %cmp3056 to i32
  store i32 %cv3057, ptr %slot274, align 8
  %v3058 = load i32, ptr %slot274, align 8
  %cv3059 = zext i32 %v3058 to i64
  %cond3060 = icmp ne i64 %cv3059, 0
  br i1 %cond3060, label %bb_rcgclear349, label %bb_rcgcounted349
bb_rcgcounted349:
  %v3061 = load i64, ptr %slot269, align 8
  %op3062 = sub i64 %v3061, 32
  store i64 %op3062, ptr %slot275, align 8
  %v3063 = load i64, ptr %slot269, align 8
  %p3064 = inttoptr i64 %v3063 to ptr
  %rgep3065 = getelementptr i8, ptr %p3064, i64 -32
  %ld3066 = load i64, ptr %rgep3065, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3066, ptr %slot276, align 8
  %v3067 = load i64, ptr %slot276, align 8
  %op3068 = sub i64 %v3067, 1
  store i64 %op3068, ptr %slot277, align 8
  %v3069 = load i64, ptr %slot277, align 8
  %cmp3070 = icmp eq i64 %v3069, 0
  %cv3071 = zext i1 %cmp3070 to i32
  store i32 %cv3071, ptr %slot278, align 8
  %v3072 = load i32, ptr %slot278, align 8
  %cv3073 = zext i32 %v3072 to i64
  %cond3074 = icmp ne i64 %cv3073, 0
  br i1 %cond3074, label %bb_rcglast349, label %bb_rcgdec349
bb_rcglast349:
  %v3075 = load i64, ptr %slot269, align 8
  %op3076 = sub i64 %v3075, 24
  store i64 %op3076, ptr %slot279, align 8
  %v3077 = load i64, ptr %slot269, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  %rgep3079 = getelementptr i8, ptr %p3078, i64 -24
  %ld3080 = load i64, ptr %rgep3079, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3080, ptr %slot280, align 8
  %v3081 = load i64, ptr %slot280, align 8
  %cmp3082 = icmp ne i64 %v3081, 0
  %cv3083 = zext i1 %cmp3082 to i32
  store i32 %cv3083, ptr %slot281, align 8
  %v3084 = load i32, ptr %slot281, align 8
  %cv3085 = zext i32 %v3084 to i64
  %cond3086 = icmp ne i64 %cv3085, 0
  br i1 %cond3086, label %bb_rcgdec349, label %bb_rcgslow349
bb_rcgslow349:
  %v3087 = load i64, ptr %slot268, align 8
  %v3088 = load i64, ptr %slot251, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v3087, i64 %v3088) nomerge, !dbg !122
  br label %bb_rcgdone349
bb_rcgdec349:
  %v3089 = load i64, ptr %slot277, align 8
  %v3090 = load i64, ptr %slot269, align 8
  %p3091 = inttoptr i64 %v3090 to ptr
  %rgep3092 = getelementptr i8, ptr %p3091, i64 -32
  store i64 %v3089, ptr %rgep3092, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear349
bb_rcgclear349:
  %v3093 = load i64, ptr %slot251, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  store i64 0, ptr %p3094, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone349
bb_rcgdone349:
  br label %bb_rcslotdone318
bb_rcslotdone318:
  %v3095 = load i64, ptr %slot22, align 8
  store i64 %v3095, ptr %slot282, align 8
  %v3096 = load i64, ptr %slot17, align 8
  store i64 %v3096, ptr %slot283, align 8
  %v3097 = load i64, ptr %slot283, align 8
  %v3098 = load i64, ptr %slot282, align 8
  %p3099 = inttoptr i64 %v3097 to ptr
  %p3100 = inttoptr i64 %v3098 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3100, ptr %p3099, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3101 = load i64, ptr %slot13, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  store i32 0, ptr %p3102, align 4, !alias.scope !3, !noalias !4
  %v3103 = load i64, ptr %slot6, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  store i32 2, ptr %p3104, align 4, !alias.scope !3, !noalias !4
  %v3105 = load i64, ptr %slot14, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  %ld3107 = load i32, ptr %p3106, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3107, ptr %slot284, align 8
  %v3108 = load i32, ptr %slot284, align 8
  %v3109 = load i64, ptr %slot6, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  store i32 %v3108, ptr %p3110, align 4, !alias.scope !3, !noalias !4
  %v3111 = load i64, ptr %slot5, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  store i32 1, ptr %p3112, align 4, !alias.scope !3, !noalias !4
  %p3113 = inttoptr i64 ptrtoint (ptr @myl_lit_1d5aee2355887a6bff8fa5a7e568dd7aa80ffab8e6e5a5e74169985e9b588862 to i64) to ptr
  %ld3114 = load i64, ptr %p3113, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3114, ptr %slot285, align 8
  %v3115 = load i64, ptr %slot285, align 8
  %v3116 = load i64, ptr %slot25, align 8
  %p3117 = inttoptr i64 %v3116 to ptr
  store i64 %v3115, ptr %p3117, align 8, !alias.scope !3, !noalias !4
  %v3118 = load i64, ptr %slot25, align 8
  %p3119 = inttoptr i64 %v3118 to ptr
  %ld3120 = load i64, ptr %p3119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3120, ptr %slot286, align 8
  %v3121 = load i64, ptr %slot286, align 8
  %v3122 = load i64, ptr %slot16, align 8
  %p3123 = inttoptr i64 %v3122 to ptr
  store i64 %v3121, ptr %p3123, align 8, !alias.scope !3, !noalias !4
  %v3124 = load i64, ptr %slot16, align 8
  store i64 %v3124, ptr %slot287, align 8
  %v3125 = load i64, ptr %slot17, align 8
  store i64 %v3125, ptr %slot288, align 8
  %v3126 = load i64, ptr %slot287, align 8
  %v3127 = load i64, ptr %slot288, align 8
  %p3128 = inttoptr i64 %v3126 to ptr
  %p3129 = inttoptr i64 %v3127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3129, ptr %p3128, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3130 = load i64, ptr %slot14, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  store i32 2, ptr %p3131, align 4, !alias.scope !3, !noalias !4
  %v3132 = load i64, ptr %slot13, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  store i32 1, ptr %p3133, align 4, !alias.scope !3, !noalias !4
  %v3134 = load i64, ptr %slot15, align 8
  store i64 %v3134, ptr %slot289, align 8
  %v3135 = load i64, ptr %slot17, align 8
  store i64 %v3135, ptr %slot290, align 8
  %v3136 = load i64, ptr %slot290, align 8
  %v3137 = load i64, ptr %slot289, align 8
  %p3138 = inttoptr i64 %v3136 to ptr
  %p3139 = inttoptr i64 %v3137 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3139, ptr %p3138, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3140 = load i64, ptr %slot12, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  store i32 2, ptr %p3141, align 4, !alias.scope !3, !noalias !4
  %v3142 = load i64, ptr %slot14, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %ld3144 = load i32, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3144, ptr %slot291, align 8
  %v3145 = load i32, ptr %slot291, align 8
  %v3146 = load i64, ptr %slot12, align 8
  %p3147 = inttoptr i64 %v3146 to ptr
  store i32 %v3145, ptr %p3147, align 4, !alias.scope !3, !noalias !4
  %v3148 = load i64, ptr %slot13, align 8
  %p3149 = inttoptr i64 %v3148 to ptr
  store i32 0, ptr %p3149, align 4, !alias.scope !3, !noalias !4
  %v3150 = load i64, ptr %slot11, align 8
  %p3151 = inttoptr i64 %v3150 to ptr
  store i32 1, ptr %p3151, align 4, !alias.scope !3, !noalias !4
  %v3152 = load i64, ptr %slot289, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  %ld3154 = load i64, ptr %p3153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3154, ptr %slot292, align 8
  %v3155 = load i64, ptr %slot292, align 8
  %v3156 = load i64, ptr %slot25, align 8
  %p3157 = inttoptr i64 %v3156 to ptr
  store i64 %v3155, ptr %p3157, align 8, !alias.scope !3, !noalias !4
  %v3158 = load i64, ptr %slot22, align 8
  store i64 %v3158, ptr %slot293, align 8
  %v3159 = load i64, ptr %slot6, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  %ld3161 = load i32, ptr %p3160, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3161, ptr %slot294, align 8
  %v3162 = load i32, ptr %slot294, align 8
  %cmp3163 = icmp eq i32 %v3162, 16
  %cv3164 = zext i1 %cmp3163 to i32
  store i32 %cv3164, ptr %slot295, align 8
  %v3165 = load i64, ptr %slot5, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %ld3167 = load i32, ptr %p3166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3167, ptr %slot296, align 8
  %v3168 = load i32, ptr %slot296, align 8
  %v3169 = load i32, ptr %slot295, align 8
  %op3170 = and i32 %v3168, %v3169
  store i32 %op3170, ptr %slot297, align 8
  %v3171 = load i32, ptr %slot297, align 8
  %cv3172 = zext i32 %v3171 to i64
  %cond3173 = icmp ne i64 %cv3172, 0
  br i1 %cond3173, label %bb_rcownlocal382, label %bb_rcownedlocal382
bb_rcownlocal382:
  %v3174 = load i64, ptr %slot22, align 8
  store i64 %v3174, ptr %slot298, align 8
  %v3175 = load i64, ptr %slot17, align 8
  store i64 %v3175, ptr %slot299, align 8
  %v3176 = load i64, ptr %slot32, align 8
  store i64 %v3176, ptr %slot300, align 8
  %v3177 = load i64, ptr %slot298, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %ld3179 = load i64, ptr %p3178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3179, ptr %slot301, align 8
  %v3180 = load i64, ptr %slot301, align 8
  %cmp3181 = icmp ne i64 %v3180, 0
  %cv3182 = zext i1 %cmp3181 to i32
  store i32 %cv3182, ptr %slot302, align 8
  %v3183 = load i32, ptr %slot302, align 8
  %cv3184 = zext i32 %v3183 to i64
  %cond3185 = icmp ne i64 %cv3184, 0
  br i1 %cond3185, label %bb_rcgnn389, label %bb_rcgplain389
bb_rcgnn389:
  %v3186 = load i64, ptr %slot301, align 8
  %op3187 = sub i64 %v3186, 16
  store i64 %op3187, ptr %slot303, align 8
  %v3188 = load i64, ptr %slot301, align 8
  %p3189 = inttoptr i64 %v3188 to ptr
  %rgep3190 = getelementptr i8, ptr %p3189, i64 -16
  %ld3191 = load i64, ptr %rgep3190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3191, ptr %slot304, align 8
  %v3192 = load i64, ptr %slot304, align 8
  %op3193 = and i64 %v3192, 4611686018427387906
  store i64 %op3193, ptr %slot305, align 8
  %v3194 = load i64, ptr %slot305, align 8
  %cmp3195 = icmp ne i64 %v3194, 0
  %cv3196 = zext i1 %cmp3195 to i32
  store i32 %cv3196, ptr %slot306, align 8
  %v3197 = load i32, ptr %slot306, align 8
  %cv3198 = zext i32 %v3197 to i64
  %cond3199 = icmp ne i64 %cv3198, 0
  br i1 %cond3199, label %bb_rcgspecial389, label %bb_rcginc389
bb_rcginc389:
  %v3200 = load i64, ptr %slot301, align 8
  %op3201 = sub i64 %v3200, 32
  store i64 %op3201, ptr %slot307, align 8
  %v3202 = load i64, ptr %slot301, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  %rgep3204 = getelementptr i8, ptr %p3203, i64 -32
  %ld3205 = load i64, ptr %rgep3204, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3205, ptr %slot308, align 8
  %v3206 = load i64, ptr %slot308, align 8
  %op3207 = add i64 %v3206, 1
  store i64 %op3207, ptr %slot309, align 8
  %v3208 = load i64, ptr %slot309, align 8
  %cmp3209 = icmp eq i64 %v3208, 0
  %cv3210 = zext i1 %cmp3209 to i32
  store i32 %cv3210, ptr %slot310, align 8
  %v3211 = load i32, ptr %slot310, align 8
  %cv3212 = zext i32 %v3211 to i64
  %cond3213 = icmp ne i64 %cv3212, 0
  br i1 %cond3213, label %bb_rcglimit389, label %bb_rcgcapacity389
bb_rcglimit389:
  %v3214 = load i64, ptr %slot1, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  %call3216 = call i32 @myl_qbe_rc_status(ptr %p3215, i32 2) nomerge, !dbg !124
  store i32 %call3216, ptr %slot311, align 8
  br label %bb_failure
bb_rcgcapacity389:
  %v3217 = load i64, ptr %slot309, align 8
  %v3218 = load i64, ptr %slot301, align 8
  %p3219 = inttoptr i64 %v3218 to ptr
  %rgep3220 = getelementptr i8, ptr %p3219, i64 -32
  store i64 %v3217, ptr %rgep3220, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain389
bb_rcgspecial389:
  %v3221 = load i64, ptr %slot304, align 8
  %op3222 = and i64 %v3221, 4611686018427387904
  store i64 %op3222, ptr %slot312, align 8
  %v3223 = load i64, ptr %slot312, align 8
  %cmp3224 = icmp ne i64 %v3223, 0
  %cv3225 = zext i1 %cmp3224 to i32
  store i32 %cv3225, ptr %slot313, align 8
  %v3226 = load i32, ptr %slot313, align 8
  %cv3227 = zext i32 %v3226 to i64
  %cond3228 = icmp ne i64 %cv3227, 0
  br i1 %cond3228, label %bb_rcgslow389, label %bb_rcgplain389
bb_rcgslow389:
  %v3229 = load i64, ptr %slot31, align 8
  %v3230 = load i64, ptr %slot299, align 8
  %v3231 = load i64, ptr %slot298, align 8
  %v3232 = load i64, ptr %slot300, align 8
  %cv3233 = trunc i64 %v3232 to i32
  %call3234 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v3229, i64 %v3230, i64 %v3231, i32 %cv3233) nomerge, !dbg !124
  store i32 %call3234, ptr %slot314, align 8
  %v3235 = load i32, ptr %slot314, align 8
  %cv3236 = zext i32 %v3235 to i64
  %cond3237 = icmp ne i64 %cv3236, 0
  br i1 %cond3237, label %bb_rcsuccess403, label %bb_rcfailure403
bb_rcfailure403:
  %v3238 = load i64, ptr %slot31, align 8
  %p3239 = inttoptr i64 %v3238 to ptr
  %call3240 = call i32 @myl_rc_take_failure(ptr %p3239) nomerge, !dbg !124
  store i32 %call3240, ptr %slot315, align 8
  %v3241 = load i64, ptr %slot1, align 8
  %p3242 = inttoptr i64 %v3241 to ptr
  %v3243 = load i32, ptr %slot315, align 8
  %call3244 = call i32 @myl_qbe_rc_status(ptr %p3242, i32 %v3243) nomerge, !dbg !124
  store i32 %call3244, ptr %slot316, align 8
  br label %bb_failure
bb_rcsuccess403:
  br label %bb_rcgdone389
bb_rcgplain389:
  %v3245 = load i64, ptr %slot301, align 8
  %v3246 = load i64, ptr %slot299, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  store i64 %v3245, ptr %p3247, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone389
bb_rcgdone389:
  %v3248 = load i64, ptr %slot14, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  store i32 2, ptr %p3249, align 4, !alias.scope !3, !noalias !4
  %v3250 = load i64, ptr %slot13, align 8
  %p3251 = inttoptr i64 %v3250 to ptr
  store i32 1, ptr %p3251, align 4, !alias.scope !3, !noalias !4
  %v3252 = load i64, ptr %slot5, align 8
  %p3253 = inttoptr i64 %v3252 to ptr
  %ld3254 = load i32, ptr %p3253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3254, ptr %slot317, align 8
  %v3255 = load i32, ptr %slot317, align 8
  %cv3256 = zext i32 %v3255 to i64
  %cond3257 = icmp ne i64 %cv3256, 0
  br i1 %cond3257, label %bb_rcslotdrop410, label %bb_rcslotdone410
bb_rcslotdrop410:
  %v3258 = load i64, ptr %slot5, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  store i32 0, ptr %p3259, align 4, !alias.scope !3, !noalias !4
  %v3260 = load i64, ptr %slot22, align 8
  store i64 %v3260, ptr %slot318, align 8
  %v3261 = load i64, ptr %slot6, align 8
  %p3262 = inttoptr i64 %v3261 to ptr
  %ld3263 = load i32, ptr %p3262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3263, ptr %slot319, align 8
  %v3264 = load i32, ptr %slot319, align 8
  %op3265 = and i32 %v3264, 28
  store i32 %op3265, ptr %slot320, align 8
  %v3266 = load i32, ptr %slot320, align 8
  %cv3267 = zext i32 %v3266 to i64
  %cond3268 = icmp ne i64 %cv3267, 0
  br i1 %cond3268, label %bb_rcslotrole410, label %bb_rcslotowner410
bb_rcslotrole410:
  %v3269 = load i64, ptr %slot31, align 8
  store i64 %v3269, ptr %slot321, align 8
  %v3270 = load i64, ptr %slot318, align 8
  %p3271 = inttoptr i64 %v3270 to ptr
  %ld3272 = load i64, ptr %p3271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3272, ptr %slot322, align 8
  %v3273 = load i64, ptr %slot322, align 8
  %cmp3274 = icmp ne i64 %v3273, 0
  %cv3275 = zext i1 %cmp3274 to i32
  store i32 %cv3275, ptr %slot323, align 8
  %v3276 = load i32, ptr %slot323, align 8
  %cv3277 = zext i32 %v3276 to i64
  %cond3278 = icmp ne i64 %cv3277, 0
  br i1 %cond3278, label %bb_rcgnn426, label %bb_rcgdone426
bb_rcgnn426:
  %v3279 = load i64, ptr %slot322, align 8
  %op3280 = sub i64 %v3279, 16
  store i64 %op3280, ptr %slot324, align 8
  %v3281 = load i64, ptr %slot322, align 8
  %p3282 = inttoptr i64 %v3281 to ptr
  %rgep3283 = getelementptr i8, ptr %p3282, i64 -16
  %ld3284 = load i64, ptr %rgep3283, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3284, ptr %slot325, align 8
  %v3285 = load i64, ptr %slot325, align 8
  %op3286 = and i64 %v3285, 4611686018427387906
  store i64 %op3286, ptr %slot326, align 8
  %v3287 = load i64, ptr %slot326, align 8
  %cmp3288 = icmp ne i64 %v3287, 0
  %cv3289 = zext i1 %cmp3288 to i32
  store i32 %cv3289, ptr %slot327, align 8
  %v3290 = load i32, ptr %slot327, align 8
  %cv3291 = zext i32 %v3290 to i64
  %cond3292 = icmp ne i64 %cv3291, 0
  br i1 %cond3292, label %bb_rcgclear426, label %bb_rcgcounted426
bb_rcgcounted426:
  %v3293 = load i64, ptr %slot322, align 8
  %op3294 = sub i64 %v3293, 24
  store i64 %op3294, ptr %slot328, align 8
  %v3295 = load i64, ptr %slot322, align 8
  %p3296 = inttoptr i64 %v3295 to ptr
  %rgep3297 = getelementptr i8, ptr %p3296, i64 -24
  %ld3298 = load i64, ptr %rgep3297, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3298, ptr %slot329, align 8
  %v3299 = load i64, ptr %slot329, align 8
  %op3300 = sub i64 %v3299, 1
  store i64 %op3300, ptr %slot330, align 8
  %v3301 = load i64, ptr %slot330, align 8
  %cmp3302 = icmp eq i64 %v3301, 0
  %cv3303 = zext i1 %cmp3302 to i32
  store i32 %cv3303, ptr %slot331, align 8
  %v3304 = load i32, ptr %slot331, align 8
  %cv3305 = zext i32 %v3304 to i64
  %cond3306 = icmp ne i64 %cv3305, 0
  br i1 %cond3306, label %bb_rcglast426, label %bb_rcgdec426
bb_rcglast426:
  %v3307 = load i64, ptr %slot322, align 8
  %op3308 = sub i64 %v3307, 32
  store i64 %op3308, ptr %slot332, align 8
  %v3309 = load i64, ptr %slot322, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  %rgep3311 = getelementptr i8, ptr %p3310, i64 -32
  %ld3312 = load i64, ptr %rgep3311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3312, ptr %slot333, align 8
  %v3313 = load i64, ptr %slot333, align 8
  %cmp3314 = icmp ne i64 %v3313, 0
  %cv3315 = zext i1 %cmp3314 to i32
  store i32 %cv3315, ptr %slot334, align 8
  %v3316 = load i32, ptr %slot334, align 8
  %cv3317 = zext i32 %v3316 to i64
  %cond3318 = icmp ne i64 %cv3317, 0
  br i1 %cond3318, label %bb_rcgdec426, label %bb_rcgslow426
bb_rcgslow426:
  %v3319 = load i64, ptr %slot321, align 8
  %v3320 = load i64, ptr %slot318, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v3319, i64 %v3320) nomerge, !dbg !124
  br label %bb_rcgdone426
bb_rcgdec426:
  %v3321 = load i64, ptr %slot330, align 8
  %v3322 = load i64, ptr %slot322, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  %rgep3324 = getelementptr i8, ptr %p3323, i64 -24
  store i64 %v3321, ptr %rgep3324, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear426
bb_rcgclear426:
  %v3325 = load i64, ptr %slot318, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  store i64 0, ptr %p3326, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone426
bb_rcgdone426:
  br label %bb_rcslotdone410
bb_rcslotowner410:
  %v3327 = load i64, ptr %slot31, align 8
  store i64 %v3327, ptr %slot335, align 8
  %v3328 = load i64, ptr %slot318, align 8
  %p3329 = inttoptr i64 %v3328 to ptr
  %ld3330 = load i64, ptr %p3329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3330, ptr %slot336, align 8
  %v3331 = load i64, ptr %slot336, align 8
  %cmp3332 = icmp ne i64 %v3331, 0
  %cv3333 = zext i1 %cmp3332 to i32
  store i32 %cv3333, ptr %slot337, align 8
  %v3334 = load i32, ptr %slot337, align 8
  %cv3335 = zext i32 %v3334 to i64
  %cond3336 = icmp ne i64 %cv3335, 0
  br i1 %cond3336, label %bb_rcgnn441, label %bb_rcgdone441
bb_rcgnn441:
  %v3337 = load i64, ptr %slot336, align 8
  %op3338 = sub i64 %v3337, 16
  store i64 %op3338, ptr %slot338, align 8
  %v3339 = load i64, ptr %slot336, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  %rgep3341 = getelementptr i8, ptr %p3340, i64 -16
  %ld3342 = load i64, ptr %rgep3341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3342, ptr %slot339, align 8
  %v3343 = load i64, ptr %slot339, align 8
  %op3344 = and i64 %v3343, 4611686018427387906
  store i64 %op3344, ptr %slot340, align 8
  %v3345 = load i64, ptr %slot340, align 8
  %cmp3346 = icmp ne i64 %v3345, 0
  %cv3347 = zext i1 %cmp3346 to i32
  store i32 %cv3347, ptr %slot341, align 8
  %v3348 = load i32, ptr %slot341, align 8
  %cv3349 = zext i32 %v3348 to i64
  %cond3350 = icmp ne i64 %cv3349, 0
  br i1 %cond3350, label %bb_rcgclear441, label %bb_rcgcounted441
bb_rcgcounted441:
  %v3351 = load i64, ptr %slot336, align 8
  %op3352 = sub i64 %v3351, 32
  store i64 %op3352, ptr %slot342, align 8
  %v3353 = load i64, ptr %slot336, align 8
  %p3354 = inttoptr i64 %v3353 to ptr
  %rgep3355 = getelementptr i8, ptr %p3354, i64 -32
  %ld3356 = load i64, ptr %rgep3355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3356, ptr %slot343, align 8
  %v3357 = load i64, ptr %slot343, align 8
  %op3358 = sub i64 %v3357, 1
  store i64 %op3358, ptr %slot344, align 8
  %v3359 = load i64, ptr %slot344, align 8
  %cmp3360 = icmp eq i64 %v3359, 0
  %cv3361 = zext i1 %cmp3360 to i32
  store i32 %cv3361, ptr %slot345, align 8
  %v3362 = load i32, ptr %slot345, align 8
  %cv3363 = zext i32 %v3362 to i64
  %cond3364 = icmp ne i64 %cv3363, 0
  br i1 %cond3364, label %bb_rcglast441, label %bb_rcgdec441
bb_rcglast441:
  %v3365 = load i64, ptr %slot336, align 8
  %op3366 = sub i64 %v3365, 24
  store i64 %op3366, ptr %slot346, align 8
  %v3367 = load i64, ptr %slot336, align 8
  %p3368 = inttoptr i64 %v3367 to ptr
  %rgep3369 = getelementptr i8, ptr %p3368, i64 -24
  %ld3370 = load i64, ptr %rgep3369, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3370, ptr %slot347, align 8
  %v3371 = load i64, ptr %slot347, align 8
  %cmp3372 = icmp ne i64 %v3371, 0
  %cv3373 = zext i1 %cmp3372 to i32
  store i32 %cv3373, ptr %slot348, align 8
  %v3374 = load i32, ptr %slot348, align 8
  %cv3375 = zext i32 %v3374 to i64
  %cond3376 = icmp ne i64 %cv3375, 0
  br i1 %cond3376, label %bb_rcgdec441, label %bb_rcgslow441
bb_rcgslow441:
  %v3377 = load i64, ptr %slot335, align 8
  %v3378 = load i64, ptr %slot318, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v3377, i64 %v3378) nomerge, !dbg !124
  br label %bb_rcgdone441
bb_rcgdec441:
  %v3379 = load i64, ptr %slot344, align 8
  %v3380 = load i64, ptr %slot336, align 8
  %p3381 = inttoptr i64 %v3380 to ptr
  %rgep3382 = getelementptr i8, ptr %p3381, i64 -32
  store i64 %v3379, ptr %rgep3382, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear441
bb_rcgclear441:
  %v3383 = load i64, ptr %slot318, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  store i64 0, ptr %p3384, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone441
bb_rcgdone441:
  br label %bb_rcslotdone410
bb_rcslotdone410:
  %v3385 = load i64, ptr %slot17, align 8
  store i64 %v3385, ptr %slot349, align 8
  %v3386 = load i64, ptr %slot349, align 8
  %v3387 = load i64, ptr %slot298, align 8
  %p3388 = inttoptr i64 %v3386 to ptr
  %p3389 = inttoptr i64 %v3387 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3389, ptr %p3388, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3390 = load i64, ptr %slot6, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  store i32 2, ptr %p3391, align 4, !alias.scope !3, !noalias !4
  %v3392 = load i64, ptr %slot5, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  store i32 1, ptr %p3393, align 4, !alias.scope !3, !noalias !4
  %v3394 = load i64, ptr %slot13, align 8
  %p3395 = inttoptr i64 %v3394 to ptr
  store i32 0, ptr %p3395, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal382
bb_rcownedlocal382:
  %v3396 = load i64, ptr %slot6, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  store i32 2, ptr %p3397, align 4, !alias.scope !3, !noalias !4
  %v3398 = load i64, ptr %slot293, align 8
  %p3399 = inttoptr i64 %v3398 to ptr
  %ld3400 = load i64, ptr %p3399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3400, ptr %slot350, align 8
  %v3401 = load i64, ptr %slot350, align 8
  %cmp3402 = icmp ne i64 %v3401, 0
  %cv3403 = zext i1 %cmp3402 to i32
  store i32 %cv3403, ptr %slot351, align 8
  %v3404 = load i32, ptr %slot351, align 8
  %cv3405 = zext i32 %v3404 to i64
  %cond3406 = icmp ne i64 %cv3405, 0
  br i1 %cond3406, label %bb_rcguniquenn450, label %bb_rcgunique450
bb_rcguniquenn450:
  %v3407 = load i64, ptr %slot350, align 8
  %op3408 = sub i64 %v3407, 16
  store i64 %op3408, ptr %slot352, align 8
  %v3409 = load i64, ptr %slot350, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  %rgep3411 = getelementptr i8, ptr %p3410, i64 -16
  %ld3412 = load i64, ptr %rgep3411, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3412, ptr %slot353, align 8
  %v3413 = load i64, ptr %slot353, align 8
  %op3414 = and i64 %v3413, 6917529027641081858
  store i64 %op3414, ptr %slot354, align 8
  %v3415 = load i64, ptr %slot354, align 8
  %cmp3416 = icmp ne i64 %v3415, 0
  %cv3417 = zext i1 %cmp3416 to i32
  store i32 %cv3417, ptr %slot355, align 8
  %v3418 = load i32, ptr %slot355, align 8
  %cv3419 = zext i32 %v3418 to i64
  %cond3420 = icmp ne i64 %cv3419, 0
  br i1 %cond3420, label %bb_rcguniqueslow450, label %bb_rcguniquecount450
bb_rcguniquecount450:
  %v3421 = load i64, ptr %slot350, align 8
  %op3422 = sub i64 %v3421, 32
  store i64 %op3422, ptr %slot356, align 8
  %v3423 = load i64, ptr %slot350, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  %rgep3425 = getelementptr i8, ptr %p3424, i64 -32
  %ld3426 = load i64, ptr %rgep3425, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3426, ptr %slot357, align 8
  %v3427 = load i64, ptr %slot357, align 8
  %cmp3428 = icmp ult i64 %v3427, 2
  %cv3429 = zext i1 %cmp3428 to i32
  store i32 %cv3429, ptr %slot358, align 8
  %v3430 = load i32, ptr %slot358, align 8
  %cv3431 = zext i32 %v3430 to i64
  %cond3432 = icmp ne i64 %cv3431, 0
  br i1 %cond3432, label %bb_rcgunique450, label %bb_rcguniqueslow450
bb_rcguniqueslow450:
  %v3433 = load i64, ptr %slot1, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  %p3435 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v3436 = load i64, ptr %slot293, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  %v3438 = load i64, ptr %slot5, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  %call3440 = call i32 @myl_qbe_rc_unique_local(ptr %p3434, ptr %p3435, ptr %p3437, ptr %p3439) nomerge, !dbg !124
  store i32 %call3440, ptr %slot359, align 8
  %v3441 = load i32, ptr %slot359, align 8
  %cv3442 = zext i32 %v3441 to i64
  %cond3443 = icmp ne i64 %cv3442, 0
  br i1 %cond3443, label %bb_rcunique461, label %bb_failure
bb_rcunique461:
  br label %bb_rcgunique450
bb_rcgunique450:
  %v3444 = load i64, ptr %slot22, align 8
  %p3445 = inttoptr i64 %v3444 to ptr
  %ld3446 = load i64, ptr %p3445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3446, ptr %slot360, align 8
  %v3447 = load i64, ptr %slot25, align 8
  store i64 %v3447, ptr %slot361, align 8
  %v3448 = load i64, ptr %slot361, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  %ld3450 = load i64, ptr %p3449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3450, ptr %slot362, align 8
  %v3451 = load i64, ptr %slot362, align 8
  %v3452 = load i64, ptr %slot18, align 8
  %p3453 = inttoptr i64 %v3452 to ptr
  store i64 %v3451, ptr %p3453, align 8, !alias.scope !3, !noalias !4
  %v3454 = load i64, ptr %slot18, align 8
  store i64 %v3454, ptr %slot363, align 8
  %v3455 = load i64, ptr %slot31, align 8
  %v3456 = load i64, ptr %slot360, align 8
  %v3457 = load i64, ptr %slot363, align 8
  %call3458 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v3455, i64 %v3456, i64 %v3457) nomerge, !dbg !124
  store i32 %call3458, ptr %slot364, align 8
  %v3459 = load i32, ptr %slot364, align 8
  %cv3460 = zext i32 %v3459 to i64
  %cond3461 = icmp ne i64 %cv3460, 0
  br i1 %cond3461, label %bb_success467, label %bb_failed467
bb_failed467:
  %v3462 = load i64, ptr %slot1, align 8
  %p3463 = inttoptr i64 %v3462 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3463) nomerge, !dbg !124
  unreachable
bb_success467:
  %v3464 = load i64, ptr %slot25, align 8
  %p3465 = inttoptr i64 %v3464 to ptr
  store i64 0, ptr %p3465, align 8, !alias.scope !3, !noalias !4
  %v3466 = load i64, ptr %slot11, align 8
  %p3467 = inttoptr i64 %v3466 to ptr
  %ld3468 = load i32, ptr %p3467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3468, ptr %slot365, align 8
  %v3469 = load i32, ptr %slot365, align 8
  %cv3470 = zext i32 %v3469 to i64
  %cond3471 = icmp ne i64 %cv3470, 0
  br i1 %cond3471, label %bb_rcslotdrop470, label %bb_rcslotdone470
bb_rcslotdrop470:
  %v3472 = load i64, ptr %slot11, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  store i32 0, ptr %p3473, align 4, !alias.scope !3, !noalias !4
  %v3474 = load i64, ptr %slot15, align 8
  store i64 %v3474, ptr %slot366, align 8
  %v3475 = load i64, ptr %slot12, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  %ld3477 = load i32, ptr %p3476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3477, ptr %slot367, align 8
  %v3478 = load i32, ptr %slot367, align 8
  %op3479 = and i32 %v3478, 28
  store i32 %op3479, ptr %slot368, align 8
  %v3480 = load i32, ptr %slot368, align 8
  %cv3481 = zext i32 %v3480 to i64
  %cond3482 = icmp ne i64 %cv3481, 0
  br i1 %cond3482, label %bb_rcslotrole470, label %bb_rcslotowner470
bb_rcslotrole470:
  %v3483 = load i64, ptr %slot31, align 8
  store i64 %v3483, ptr %slot369, align 8
  %v3484 = load i64, ptr %slot366, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  %ld3486 = load i64, ptr %p3485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3486, ptr %slot370, align 8
  %v3487 = load i64, ptr %slot370, align 8
  %cmp3488 = icmp ne i64 %v3487, 0
  %cv3489 = zext i1 %cmp3488 to i32
  store i32 %cv3489, ptr %slot371, align 8
  %v3490 = load i32, ptr %slot371, align 8
  %cv3491 = zext i32 %v3490 to i64
  %cond3492 = icmp ne i64 %cv3491, 0
  br i1 %cond3492, label %bb_rcgnn486, label %bb_rcgdone486
bb_rcgnn486:
  %v3493 = load i64, ptr %slot370, align 8
  %op3494 = sub i64 %v3493, 16
  store i64 %op3494, ptr %slot372, align 8
  %v3495 = load i64, ptr %slot370, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  %rgep3497 = getelementptr i8, ptr %p3496, i64 -16
  %ld3498 = load i64, ptr %rgep3497, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3498, ptr %slot373, align 8
  %v3499 = load i64, ptr %slot373, align 8
  %op3500 = and i64 %v3499, 4611686018427387906
  store i64 %op3500, ptr %slot374, align 8
  %v3501 = load i64, ptr %slot374, align 8
  %cmp3502 = icmp ne i64 %v3501, 0
  %cv3503 = zext i1 %cmp3502 to i32
  store i32 %cv3503, ptr %slot375, align 8
  %v3504 = load i32, ptr %slot375, align 8
  %cv3505 = zext i32 %v3504 to i64
  %cond3506 = icmp ne i64 %cv3505, 0
  br i1 %cond3506, label %bb_rcgclear486, label %bb_rcgcounted486
bb_rcgcounted486:
  %v3507 = load i64, ptr %slot370, align 8
  %op3508 = sub i64 %v3507, 24
  store i64 %op3508, ptr %slot376, align 8
  %v3509 = load i64, ptr %slot370, align 8
  %p3510 = inttoptr i64 %v3509 to ptr
  %rgep3511 = getelementptr i8, ptr %p3510, i64 -24
  %ld3512 = load i64, ptr %rgep3511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3512, ptr %slot377, align 8
  %v3513 = load i64, ptr %slot377, align 8
  %op3514 = sub i64 %v3513, 1
  store i64 %op3514, ptr %slot378, align 8
  %v3515 = load i64, ptr %slot378, align 8
  %cmp3516 = icmp eq i64 %v3515, 0
  %cv3517 = zext i1 %cmp3516 to i32
  store i32 %cv3517, ptr %slot379, align 8
  %v3518 = load i32, ptr %slot379, align 8
  %cv3519 = zext i32 %v3518 to i64
  %cond3520 = icmp ne i64 %cv3519, 0
  br i1 %cond3520, label %bb_rcglast486, label %bb_rcgdec486
bb_rcglast486:
  %v3521 = load i64, ptr %slot370, align 8
  %op3522 = sub i64 %v3521, 32
  store i64 %op3522, ptr %slot380, align 8
  %v3523 = load i64, ptr %slot370, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  %rgep3525 = getelementptr i8, ptr %p3524, i64 -32
  %ld3526 = load i64, ptr %rgep3525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3526, ptr %slot381, align 8
  %v3527 = load i64, ptr %slot381, align 8
  %cmp3528 = icmp ne i64 %v3527, 0
  %cv3529 = zext i1 %cmp3528 to i32
  store i32 %cv3529, ptr %slot382, align 8
  %v3530 = load i32, ptr %slot382, align 8
  %cv3531 = zext i32 %v3530 to i64
  %cond3532 = icmp ne i64 %cv3531, 0
  br i1 %cond3532, label %bb_rcgdec486, label %bb_rcgslow486
bb_rcgslow486:
  %v3533 = load i64, ptr %slot369, align 8
  %v3534 = load i64, ptr %slot366, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v3533, i64 %v3534) nomerge, !dbg !124
  br label %bb_rcgdone486
bb_rcgdec486:
  %v3535 = load i64, ptr %slot378, align 8
  %v3536 = load i64, ptr %slot370, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  %rgep3538 = getelementptr i8, ptr %p3537, i64 -24
  store i64 %v3535, ptr %rgep3538, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear486
bb_rcgclear486:
  %v3539 = load i64, ptr %slot366, align 8
  %p3540 = inttoptr i64 %v3539 to ptr
  store i64 0, ptr %p3540, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone486
bb_rcgdone486:
  br label %bb_rcslotdone470
bb_rcslotowner470:
  %v3541 = load i64, ptr %slot31, align 8
  store i64 %v3541, ptr %slot383, align 8
  %v3542 = load i64, ptr %slot366, align 8
  %p3543 = inttoptr i64 %v3542 to ptr
  %ld3544 = load i64, ptr %p3543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3544, ptr %slot384, align 8
  %v3545 = load i64, ptr %slot384, align 8
  %cmp3546 = icmp ne i64 %v3545, 0
  %cv3547 = zext i1 %cmp3546 to i32
  store i32 %cv3547, ptr %slot385, align 8
  %v3548 = load i32, ptr %slot385, align 8
  %cv3549 = zext i32 %v3548 to i64
  %cond3550 = icmp ne i64 %cv3549, 0
  br i1 %cond3550, label %bb_rcgnn501, label %bb_rcgdone501
bb_rcgnn501:
  %v3551 = load i64, ptr %slot384, align 8
  %op3552 = sub i64 %v3551, 16
  store i64 %op3552, ptr %slot386, align 8
  %v3553 = load i64, ptr %slot384, align 8
  %p3554 = inttoptr i64 %v3553 to ptr
  %rgep3555 = getelementptr i8, ptr %p3554, i64 -16
  %ld3556 = load i64, ptr %rgep3555, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3556, ptr %slot387, align 8
  %v3557 = load i64, ptr %slot387, align 8
  %op3558 = and i64 %v3557, 4611686018427387906
  store i64 %op3558, ptr %slot388, align 8
  %v3559 = load i64, ptr %slot388, align 8
  %cmp3560 = icmp ne i64 %v3559, 0
  %cv3561 = zext i1 %cmp3560 to i32
  store i32 %cv3561, ptr %slot389, align 8
  %v3562 = load i32, ptr %slot389, align 8
  %cv3563 = zext i32 %v3562 to i64
  %cond3564 = icmp ne i64 %cv3563, 0
  br i1 %cond3564, label %bb_rcgclear501, label %bb_rcgcounted501
bb_rcgcounted501:
  %v3565 = load i64, ptr %slot384, align 8
  %op3566 = sub i64 %v3565, 32
  store i64 %op3566, ptr %slot390, align 8
  %v3567 = load i64, ptr %slot384, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  %rgep3569 = getelementptr i8, ptr %p3568, i64 -32
  %ld3570 = load i64, ptr %rgep3569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3570, ptr %slot391, align 8
  %v3571 = load i64, ptr %slot391, align 8
  %op3572 = sub i64 %v3571, 1
  store i64 %op3572, ptr %slot392, align 8
  %v3573 = load i64, ptr %slot392, align 8
  %cmp3574 = icmp eq i64 %v3573, 0
  %cv3575 = zext i1 %cmp3574 to i32
  store i32 %cv3575, ptr %slot393, align 8
  %v3576 = load i32, ptr %slot393, align 8
  %cv3577 = zext i32 %v3576 to i64
  %cond3578 = icmp ne i64 %cv3577, 0
  br i1 %cond3578, label %bb_rcglast501, label %bb_rcgdec501
bb_rcglast501:
  %v3579 = load i64, ptr %slot384, align 8
  %op3580 = sub i64 %v3579, 24
  store i64 %op3580, ptr %slot394, align 8
  %v3581 = load i64, ptr %slot384, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  %rgep3583 = getelementptr i8, ptr %p3582, i64 -24
  %ld3584 = load i64, ptr %rgep3583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3584, ptr %slot395, align 8
  %v3585 = load i64, ptr %slot395, align 8
  %cmp3586 = icmp ne i64 %v3585, 0
  %cv3587 = zext i1 %cmp3586 to i32
  store i32 %cv3587, ptr %slot396, align 8
  %v3588 = load i32, ptr %slot396, align 8
  %cv3589 = zext i32 %v3588 to i64
  %cond3590 = icmp ne i64 %cv3589, 0
  br i1 %cond3590, label %bb_rcgdec501, label %bb_rcgslow501
bb_rcgslow501:
  %v3591 = load i64, ptr %slot383, align 8
  %v3592 = load i64, ptr %slot366, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v3591, i64 %v3592) nomerge, !dbg !124
  br label %bb_rcgdone501
bb_rcgdec501:
  %v3593 = load i64, ptr %slot392, align 8
  %v3594 = load i64, ptr %slot384, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  %rgep3596 = getelementptr i8, ptr %p3595, i64 -32
  store i64 %v3593, ptr %rgep3596, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear501
bb_rcgclear501:
  %v3597 = load i64, ptr %slot366, align 8
  %p3598 = inttoptr i64 %v3597 to ptr
  store i64 0, ptr %p3598, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone501
bb_rcgdone501:
  br label %bb_rcslotdone470
bb_rcslotdone470:
  %v3599 = load i64, ptr %slot20, align 8
  %p3600 = inttoptr i64 %v3599 to ptr
  %ld3601 = load i64, ptr %p3600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3601, ptr %slot397, align 8
  %v3602 = load i64, ptr %slot397, align 8
  %v3603 = load i64, ptr %slot25, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  store i64 %v3602, ptr %p3604, align 8, !alias.scope !3, !noalias !4
  %v3605 = load i64, ptr %slot25, align 8
  %p3606 = inttoptr i64 %v3605 to ptr
  %ld3607 = load i64, ptr %p3606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3607, ptr %slot398, align 8
  %v3608 = load i64, ptr %slot1, align 8
  %v3609 = load i64, ptr %slot398, align 8
  %call3610 = call i64 @myl_f_e3f3f8852ef98dc490bd8fc3c4d74b40aa60caff690c4ee01a803d86d012a05b(i64 %v3608, i64 %v3609) nomerge, !dbg !126
  store i64 %call3610, ptr %slot399, align 8
  %v3611 = load i64, ptr %slot399, align 8
  %v3612 = load i64, ptr %slot25, align 8
  %p3613 = inttoptr i64 %v3612 to ptr
  store i64 %v3611, ptr %p3613, align 8, !alias.scope !3, !noalias !4
  %v3614 = load i64, ptr %slot25, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  %ld3616 = load i64, ptr %p3615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3616, ptr %slot400, align 8
  %v3617 = load i64, ptr %slot400, align 8
  %v3618 = load i64, ptr %slot16, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  store i64 %v3617, ptr %p3619, align 8, !alias.scope !3, !noalias !4
  %v3620 = load i64, ptr %slot16, align 8
  store i64 %v3620, ptr %slot401, align 8
  %v3621 = load i64, ptr %slot17, align 8
  store i64 %v3621, ptr %slot402, align 8
  %v3622 = load i64, ptr %slot401, align 8
  %v3623 = load i64, ptr %slot402, align 8
  %p3624 = inttoptr i64 %v3622 to ptr
  %p3625 = inttoptr i64 %v3623 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3625, ptr %p3624, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3626 = load i64, ptr %slot14, align 8
  %p3627 = inttoptr i64 %v3626 to ptr
  store i32 2, ptr %p3627, align 4, !alias.scope !3, !noalias !4
  %v3628 = load i64, ptr %slot13, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  store i32 1, ptr %p3629, align 4, !alias.scope !3, !noalias !4
  %v3630 = load i64, ptr %slot15, align 8
  store i64 %v3630, ptr %slot403, align 8
  %v3631 = load i64, ptr %slot17, align 8
  store i64 %v3631, ptr %slot404, align 8
  %v3632 = load i64, ptr %slot404, align 8
  %v3633 = load i64, ptr %slot403, align 8
  %p3634 = inttoptr i64 %v3632 to ptr
  %p3635 = inttoptr i64 %v3633 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3635, ptr %p3634, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3636 = load i64, ptr %slot12, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  store i32 2, ptr %p3637, align 4, !alias.scope !3, !noalias !4
  %v3638 = load i64, ptr %slot14, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  %ld3640 = load i32, ptr %p3639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3640, ptr %slot405, align 8
  %v3641 = load i32, ptr %slot405, align 8
  %v3642 = load i64, ptr %slot12, align 8
  %p3643 = inttoptr i64 %v3642 to ptr
  store i32 %v3641, ptr %p3643, align 4, !alias.scope !3, !noalias !4
  %v3644 = load i64, ptr %slot13, align 8
  %p3645 = inttoptr i64 %v3644 to ptr
  store i32 0, ptr %p3645, align 4, !alias.scope !3, !noalias !4
  %v3646 = load i64, ptr %slot11, align 8
  %p3647 = inttoptr i64 %v3646 to ptr
  store i32 1, ptr %p3647, align 4, !alias.scope !3, !noalias !4
  %v3648 = load i64, ptr %slot403, align 8
  %p3649 = inttoptr i64 %v3648 to ptr
  %ld3650 = load i64, ptr %p3649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3650, ptr %slot406, align 8
  %v3651 = load i64, ptr %slot406, align 8
  %v3652 = load i64, ptr %slot25, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  store i64 %v3651, ptr %p3653, align 8, !alias.scope !3, !noalias !4
  %v3654 = load i64, ptr %slot22, align 8
  store i64 %v3654, ptr %slot407, align 8
  %v3655 = load i64, ptr %slot6, align 8
  %p3656 = inttoptr i64 %v3655 to ptr
  %ld3657 = load i32, ptr %p3656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3657, ptr %slot408, align 8
  %v3658 = load i32, ptr %slot408, align 8
  %cmp3659 = icmp eq i32 %v3658, 16
  %cv3660 = zext i1 %cmp3659 to i32
  store i32 %cv3660, ptr %slot409, align 8
  %v3661 = load i64, ptr %slot5, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %ld3663 = load i32, ptr %p3662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3663, ptr %slot410, align 8
  %v3664 = load i32, ptr %slot410, align 8
  %v3665 = load i32, ptr %slot409, align 8
  %op3666 = and i32 %v3664, %v3665
  store i32 %op3666, ptr %slot411, align 8
  %v3667 = load i32, ptr %slot411, align 8
  %cv3668 = zext i32 %v3667 to i64
  %cond3669 = icmp ne i64 %cv3668, 0
  br i1 %cond3669, label %bb_rcownlocal528, label %bb_rcownedlocal528
bb_rcownlocal528:
  %v3670 = load i64, ptr %slot22, align 8
  store i64 %v3670, ptr %slot412, align 8
  %v3671 = load i64, ptr %slot17, align 8
  store i64 %v3671, ptr %slot413, align 8
  %v3672 = load i64, ptr %slot32, align 8
  store i64 %v3672, ptr %slot414, align 8
  %v3673 = load i64, ptr %slot412, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %ld3675 = load i64, ptr %p3674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3675, ptr %slot415, align 8
  %v3676 = load i64, ptr %slot415, align 8
  %cmp3677 = icmp ne i64 %v3676, 0
  %cv3678 = zext i1 %cmp3677 to i32
  store i32 %cv3678, ptr %slot416, align 8
  %v3679 = load i32, ptr %slot416, align 8
  %cv3680 = zext i32 %v3679 to i64
  %cond3681 = icmp ne i64 %cv3680, 0
  br i1 %cond3681, label %bb_rcgnn535, label %bb_rcgplain535
bb_rcgnn535:
  %v3682 = load i64, ptr %slot415, align 8
  %op3683 = sub i64 %v3682, 16
  store i64 %op3683, ptr %slot417, align 8
  %v3684 = load i64, ptr %slot415, align 8
  %p3685 = inttoptr i64 %v3684 to ptr
  %rgep3686 = getelementptr i8, ptr %p3685, i64 -16
  %ld3687 = load i64, ptr %rgep3686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3687, ptr %slot418, align 8
  %v3688 = load i64, ptr %slot418, align 8
  %op3689 = and i64 %v3688, 4611686018427387906
  store i64 %op3689, ptr %slot419, align 8
  %v3690 = load i64, ptr %slot419, align 8
  %cmp3691 = icmp ne i64 %v3690, 0
  %cv3692 = zext i1 %cmp3691 to i32
  store i32 %cv3692, ptr %slot420, align 8
  %v3693 = load i32, ptr %slot420, align 8
  %cv3694 = zext i32 %v3693 to i64
  %cond3695 = icmp ne i64 %cv3694, 0
  br i1 %cond3695, label %bb_rcgspecial535, label %bb_rcginc535
bb_rcginc535:
  %v3696 = load i64, ptr %slot415, align 8
  %op3697 = sub i64 %v3696, 32
  store i64 %op3697, ptr %slot421, align 8
  %v3698 = load i64, ptr %slot415, align 8
  %p3699 = inttoptr i64 %v3698 to ptr
  %rgep3700 = getelementptr i8, ptr %p3699, i64 -32
  %ld3701 = load i64, ptr %rgep3700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3701, ptr %slot422, align 8
  %v3702 = load i64, ptr %slot422, align 8
  %op3703 = add i64 %v3702, 1
  store i64 %op3703, ptr %slot423, align 8
  %v3704 = load i64, ptr %slot423, align 8
  %cmp3705 = icmp eq i64 %v3704, 0
  %cv3706 = zext i1 %cmp3705 to i32
  store i32 %cv3706, ptr %slot424, align 8
  %v3707 = load i32, ptr %slot424, align 8
  %cv3708 = zext i32 %v3707 to i64
  %cond3709 = icmp ne i64 %cv3708, 0
  br i1 %cond3709, label %bb_rcglimit535, label %bb_rcgcapacity535
bb_rcglimit535:
  %v3710 = load i64, ptr %slot1, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  %call3712 = call i32 @myl_qbe_rc_status(ptr %p3711, i32 2) nomerge, !dbg !128
  store i32 %call3712, ptr %slot425, align 8
  br label %bb_failure
bb_rcgcapacity535:
  %v3713 = load i64, ptr %slot423, align 8
  %v3714 = load i64, ptr %slot415, align 8
  %p3715 = inttoptr i64 %v3714 to ptr
  %rgep3716 = getelementptr i8, ptr %p3715, i64 -32
  store i64 %v3713, ptr %rgep3716, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain535
bb_rcgspecial535:
  %v3717 = load i64, ptr %slot418, align 8
  %op3718 = and i64 %v3717, 4611686018427387904
  store i64 %op3718, ptr %slot426, align 8
  %v3719 = load i64, ptr %slot426, align 8
  %cmp3720 = icmp ne i64 %v3719, 0
  %cv3721 = zext i1 %cmp3720 to i32
  store i32 %cv3721, ptr %slot427, align 8
  %v3722 = load i32, ptr %slot427, align 8
  %cv3723 = zext i32 %v3722 to i64
  %cond3724 = icmp ne i64 %cv3723, 0
  br i1 %cond3724, label %bb_rcgslow535, label %bb_rcgplain535
bb_rcgslow535:
  %v3725 = load i64, ptr %slot31, align 8
  %v3726 = load i64, ptr %slot413, align 8
  %v3727 = load i64, ptr %slot412, align 8
  %v3728 = load i64, ptr %slot414, align 8
  %cv3729 = trunc i64 %v3728 to i32
  %call3730 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v3725, i64 %v3726, i64 %v3727, i32 %cv3729) nomerge, !dbg !128
  store i32 %call3730, ptr %slot428, align 8
  %v3731 = load i32, ptr %slot428, align 8
  %cv3732 = zext i32 %v3731 to i64
  %cond3733 = icmp ne i64 %cv3732, 0
  br i1 %cond3733, label %bb_rcsuccess549, label %bb_rcfailure549
bb_rcfailure549:
  %v3734 = load i64, ptr %slot31, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  %call3736 = call i32 @myl_rc_take_failure(ptr %p3735) nomerge, !dbg !128
  store i32 %call3736, ptr %slot429, align 8
  %v3737 = load i64, ptr %slot1, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  %v3739 = load i32, ptr %slot429, align 8
  %call3740 = call i32 @myl_qbe_rc_status(ptr %p3738, i32 %v3739) nomerge, !dbg !128
  store i32 %call3740, ptr %slot430, align 8
  br label %bb_failure
bb_rcsuccess549:
  br label %bb_rcgdone535
bb_rcgplain535:
  %v3741 = load i64, ptr %slot415, align 8
  %v3742 = load i64, ptr %slot413, align 8
  %p3743 = inttoptr i64 %v3742 to ptr
  store i64 %v3741, ptr %p3743, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone535
bb_rcgdone535:
  %v3744 = load i64, ptr %slot14, align 8
  %p3745 = inttoptr i64 %v3744 to ptr
  store i32 2, ptr %p3745, align 4, !alias.scope !3, !noalias !4
  %v3746 = load i64, ptr %slot13, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  store i32 1, ptr %p3747, align 4, !alias.scope !3, !noalias !4
  %v3748 = load i64, ptr %slot5, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  %ld3750 = load i32, ptr %p3749, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3750, ptr %slot431, align 8
  %v3751 = load i32, ptr %slot431, align 8
  %cv3752 = zext i32 %v3751 to i64
  %cond3753 = icmp ne i64 %cv3752, 0
  br i1 %cond3753, label %bb_rcslotdrop556, label %bb_rcslotdone556
bb_rcslotdrop556:
  %v3754 = load i64, ptr %slot5, align 8
  %p3755 = inttoptr i64 %v3754 to ptr
  store i32 0, ptr %p3755, align 4, !alias.scope !3, !noalias !4
  %v3756 = load i64, ptr %slot22, align 8
  store i64 %v3756, ptr %slot432, align 8
  %v3757 = load i64, ptr %slot6, align 8
  %p3758 = inttoptr i64 %v3757 to ptr
  %ld3759 = load i32, ptr %p3758, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3759, ptr %slot433, align 8
  %v3760 = load i32, ptr %slot433, align 8
  %op3761 = and i32 %v3760, 28
  store i32 %op3761, ptr %slot434, align 8
  %v3762 = load i32, ptr %slot434, align 8
  %cv3763 = zext i32 %v3762 to i64
  %cond3764 = icmp ne i64 %cv3763, 0
  br i1 %cond3764, label %bb_rcslotrole556, label %bb_rcslotowner556
bb_rcslotrole556:
  %v3765 = load i64, ptr %slot31, align 8
  store i64 %v3765, ptr %slot435, align 8
  %v3766 = load i64, ptr %slot432, align 8
  %p3767 = inttoptr i64 %v3766 to ptr
  %ld3768 = load i64, ptr %p3767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3768, ptr %slot436, align 8
  %v3769 = load i64, ptr %slot436, align 8
  %cmp3770 = icmp ne i64 %v3769, 0
  %cv3771 = zext i1 %cmp3770 to i32
  store i32 %cv3771, ptr %slot437, align 8
  %v3772 = load i32, ptr %slot437, align 8
  %cv3773 = zext i32 %v3772 to i64
  %cond3774 = icmp ne i64 %cv3773, 0
  br i1 %cond3774, label %bb_rcgnn572, label %bb_rcgdone572
bb_rcgnn572:
  %v3775 = load i64, ptr %slot436, align 8
  %op3776 = sub i64 %v3775, 16
  store i64 %op3776, ptr %slot438, align 8
  %v3777 = load i64, ptr %slot436, align 8
  %p3778 = inttoptr i64 %v3777 to ptr
  %rgep3779 = getelementptr i8, ptr %p3778, i64 -16
  %ld3780 = load i64, ptr %rgep3779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3780, ptr %slot439, align 8
  %v3781 = load i64, ptr %slot439, align 8
  %op3782 = and i64 %v3781, 4611686018427387906
  store i64 %op3782, ptr %slot440, align 8
  %v3783 = load i64, ptr %slot440, align 8
  %cmp3784 = icmp ne i64 %v3783, 0
  %cv3785 = zext i1 %cmp3784 to i32
  store i32 %cv3785, ptr %slot441, align 8
  %v3786 = load i32, ptr %slot441, align 8
  %cv3787 = zext i32 %v3786 to i64
  %cond3788 = icmp ne i64 %cv3787, 0
  br i1 %cond3788, label %bb_rcgclear572, label %bb_rcgcounted572
bb_rcgcounted572:
  %v3789 = load i64, ptr %slot436, align 8
  %op3790 = sub i64 %v3789, 24
  store i64 %op3790, ptr %slot442, align 8
  %v3791 = load i64, ptr %slot436, align 8
  %p3792 = inttoptr i64 %v3791 to ptr
  %rgep3793 = getelementptr i8, ptr %p3792, i64 -24
  %ld3794 = load i64, ptr %rgep3793, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3794, ptr %slot443, align 8
  %v3795 = load i64, ptr %slot443, align 8
  %op3796 = sub i64 %v3795, 1
  store i64 %op3796, ptr %slot444, align 8
  %v3797 = load i64, ptr %slot444, align 8
  %cmp3798 = icmp eq i64 %v3797, 0
  %cv3799 = zext i1 %cmp3798 to i32
  store i32 %cv3799, ptr %slot445, align 8
  %v3800 = load i32, ptr %slot445, align 8
  %cv3801 = zext i32 %v3800 to i64
  %cond3802 = icmp ne i64 %cv3801, 0
  br i1 %cond3802, label %bb_rcglast572, label %bb_rcgdec572
bb_rcglast572:
  %v3803 = load i64, ptr %slot436, align 8
  %op3804 = sub i64 %v3803, 32
  store i64 %op3804, ptr %slot446, align 8
  %v3805 = load i64, ptr %slot436, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %rgep3807 = getelementptr i8, ptr %p3806, i64 -32
  %ld3808 = load i64, ptr %rgep3807, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3808, ptr %slot447, align 8
  %v3809 = load i64, ptr %slot447, align 8
  %cmp3810 = icmp ne i64 %v3809, 0
  %cv3811 = zext i1 %cmp3810 to i32
  store i32 %cv3811, ptr %slot448, align 8
  %v3812 = load i32, ptr %slot448, align 8
  %cv3813 = zext i32 %v3812 to i64
  %cond3814 = icmp ne i64 %cv3813, 0
  br i1 %cond3814, label %bb_rcgdec572, label %bb_rcgslow572
bb_rcgslow572:
  %v3815 = load i64, ptr %slot435, align 8
  %v3816 = load i64, ptr %slot432, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v3815, i64 %v3816) nomerge, !dbg !128
  br label %bb_rcgdone572
bb_rcgdec572:
  %v3817 = load i64, ptr %slot444, align 8
  %v3818 = load i64, ptr %slot436, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  %rgep3820 = getelementptr i8, ptr %p3819, i64 -24
  store i64 %v3817, ptr %rgep3820, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear572
bb_rcgclear572:
  %v3821 = load i64, ptr %slot432, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  store i64 0, ptr %p3822, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone572
bb_rcgdone572:
  br label %bb_rcslotdone556
bb_rcslotowner556:
  %v3823 = load i64, ptr %slot31, align 8
  store i64 %v3823, ptr %slot449, align 8
  %v3824 = load i64, ptr %slot432, align 8
  %p3825 = inttoptr i64 %v3824 to ptr
  %ld3826 = load i64, ptr %p3825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3826, ptr %slot450, align 8
  %v3827 = load i64, ptr %slot450, align 8
  %cmp3828 = icmp ne i64 %v3827, 0
  %cv3829 = zext i1 %cmp3828 to i32
  store i32 %cv3829, ptr %slot451, align 8
  %v3830 = load i32, ptr %slot451, align 8
  %cv3831 = zext i32 %v3830 to i64
  %cond3832 = icmp ne i64 %cv3831, 0
  br i1 %cond3832, label %bb_rcgnn587, label %bb_rcgdone587
bb_rcgnn587:
  %v3833 = load i64, ptr %slot450, align 8
  %op3834 = sub i64 %v3833, 16
  store i64 %op3834, ptr %slot452, align 8
  %v3835 = load i64, ptr %slot450, align 8
  %p3836 = inttoptr i64 %v3835 to ptr
  %rgep3837 = getelementptr i8, ptr %p3836, i64 -16
  %ld3838 = load i64, ptr %rgep3837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3838, ptr %slot453, align 8
  %v3839 = load i64, ptr %slot453, align 8
  %op3840 = and i64 %v3839, 4611686018427387906
  store i64 %op3840, ptr %slot454, align 8
  %v3841 = load i64, ptr %slot454, align 8
  %cmp3842 = icmp ne i64 %v3841, 0
  %cv3843 = zext i1 %cmp3842 to i32
  store i32 %cv3843, ptr %slot455, align 8
  %v3844 = load i32, ptr %slot455, align 8
  %cv3845 = zext i32 %v3844 to i64
  %cond3846 = icmp ne i64 %cv3845, 0
  br i1 %cond3846, label %bb_rcgclear587, label %bb_rcgcounted587
bb_rcgcounted587:
  %v3847 = load i64, ptr %slot450, align 8
  %op3848 = sub i64 %v3847, 32
  store i64 %op3848, ptr %slot456, align 8
  %v3849 = load i64, ptr %slot450, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  %rgep3851 = getelementptr i8, ptr %p3850, i64 -32
  %ld3852 = load i64, ptr %rgep3851, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3852, ptr %slot457, align 8
  %v3853 = load i64, ptr %slot457, align 8
  %op3854 = sub i64 %v3853, 1
  store i64 %op3854, ptr %slot458, align 8
  %v3855 = load i64, ptr %slot458, align 8
  %cmp3856 = icmp eq i64 %v3855, 0
  %cv3857 = zext i1 %cmp3856 to i32
  store i32 %cv3857, ptr %slot459, align 8
  %v3858 = load i32, ptr %slot459, align 8
  %cv3859 = zext i32 %v3858 to i64
  %cond3860 = icmp ne i64 %cv3859, 0
  br i1 %cond3860, label %bb_rcglast587, label %bb_rcgdec587
bb_rcglast587:
  %v3861 = load i64, ptr %slot450, align 8
  %op3862 = sub i64 %v3861, 24
  store i64 %op3862, ptr %slot460, align 8
  %v3863 = load i64, ptr %slot450, align 8
  %p3864 = inttoptr i64 %v3863 to ptr
  %rgep3865 = getelementptr i8, ptr %p3864, i64 -24
  %ld3866 = load i64, ptr %rgep3865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3866, ptr %slot461, align 8
  %v3867 = load i64, ptr %slot461, align 8
  %cmp3868 = icmp ne i64 %v3867, 0
  %cv3869 = zext i1 %cmp3868 to i32
  store i32 %cv3869, ptr %slot462, align 8
  %v3870 = load i32, ptr %slot462, align 8
  %cv3871 = zext i32 %v3870 to i64
  %cond3872 = icmp ne i64 %cv3871, 0
  br i1 %cond3872, label %bb_rcgdec587, label %bb_rcgslow587
bb_rcgslow587:
  %v3873 = load i64, ptr %slot449, align 8
  %v3874 = load i64, ptr %slot432, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v3873, i64 %v3874) nomerge, !dbg !128
  br label %bb_rcgdone587
bb_rcgdec587:
  %v3875 = load i64, ptr %slot458, align 8
  %v3876 = load i64, ptr %slot450, align 8
  %p3877 = inttoptr i64 %v3876 to ptr
  %rgep3878 = getelementptr i8, ptr %p3877, i64 -32
  store i64 %v3875, ptr %rgep3878, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear587
bb_rcgclear587:
  %v3879 = load i64, ptr %slot432, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  store i64 0, ptr %p3880, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone587
bb_rcgdone587:
  br label %bb_rcslotdone556
bb_rcslotdone556:
  %v3881 = load i64, ptr %slot17, align 8
  store i64 %v3881, ptr %slot463, align 8
  %v3882 = load i64, ptr %slot463, align 8
  %v3883 = load i64, ptr %slot412, align 8
  %p3884 = inttoptr i64 %v3882 to ptr
  %p3885 = inttoptr i64 %v3883 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3885, ptr %p3884, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3886 = load i64, ptr %slot6, align 8
  %p3887 = inttoptr i64 %v3886 to ptr
  store i32 2, ptr %p3887, align 4, !alias.scope !3, !noalias !4
  %v3888 = load i64, ptr %slot5, align 8
  %p3889 = inttoptr i64 %v3888 to ptr
  store i32 1, ptr %p3889, align 4, !alias.scope !3, !noalias !4
  %v3890 = load i64, ptr %slot13, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  store i32 0, ptr %p3891, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal528
bb_rcownedlocal528:
  %v3892 = load i64, ptr %slot6, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  store i32 2, ptr %p3893, align 4, !alias.scope !3, !noalias !4
  %v3894 = load i64, ptr %slot407, align 8
  %p3895 = inttoptr i64 %v3894 to ptr
  %ld3896 = load i64, ptr %p3895, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3896, ptr %slot464, align 8
  %v3897 = load i64, ptr %slot464, align 8
  %cmp3898 = icmp ne i64 %v3897, 0
  %cv3899 = zext i1 %cmp3898 to i32
  store i32 %cv3899, ptr %slot465, align 8
  %v3900 = load i32, ptr %slot465, align 8
  %cv3901 = zext i32 %v3900 to i64
  %cond3902 = icmp ne i64 %cv3901, 0
  br i1 %cond3902, label %bb_rcguniquenn596, label %bb_rcgunique596
bb_rcguniquenn596:
  %v3903 = load i64, ptr %slot464, align 8
  %op3904 = sub i64 %v3903, 16
  store i64 %op3904, ptr %slot466, align 8
  %v3905 = load i64, ptr %slot464, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  %rgep3907 = getelementptr i8, ptr %p3906, i64 -16
  %ld3908 = load i64, ptr %rgep3907, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3908, ptr %slot467, align 8
  %v3909 = load i64, ptr %slot467, align 8
  %op3910 = and i64 %v3909, 6917529027641081858
  store i64 %op3910, ptr %slot468, align 8
  %v3911 = load i64, ptr %slot468, align 8
  %cmp3912 = icmp ne i64 %v3911, 0
  %cv3913 = zext i1 %cmp3912 to i32
  store i32 %cv3913, ptr %slot469, align 8
  %v3914 = load i32, ptr %slot469, align 8
  %cv3915 = zext i32 %v3914 to i64
  %cond3916 = icmp ne i64 %cv3915, 0
  br i1 %cond3916, label %bb_rcguniqueslow596, label %bb_rcguniquecount596
bb_rcguniquecount596:
  %v3917 = load i64, ptr %slot464, align 8
  %op3918 = sub i64 %v3917, 32
  store i64 %op3918, ptr %slot470, align 8
  %v3919 = load i64, ptr %slot464, align 8
  %p3920 = inttoptr i64 %v3919 to ptr
  %rgep3921 = getelementptr i8, ptr %p3920, i64 -32
  %ld3922 = load i64, ptr %rgep3921, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3922, ptr %slot471, align 8
  %v3923 = load i64, ptr %slot471, align 8
  %cmp3924 = icmp ult i64 %v3923, 2
  %cv3925 = zext i1 %cmp3924 to i32
  store i32 %cv3925, ptr %slot472, align 8
  %v3926 = load i32, ptr %slot472, align 8
  %cv3927 = zext i32 %v3926 to i64
  %cond3928 = icmp ne i64 %cv3927, 0
  br i1 %cond3928, label %bb_rcgunique596, label %bb_rcguniqueslow596
bb_rcguniqueslow596:
  %v3929 = load i64, ptr %slot1, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  %p3931 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v3932 = load i64, ptr %slot407, align 8
  %p3933 = inttoptr i64 %v3932 to ptr
  %v3934 = load i64, ptr %slot5, align 8
  %p3935 = inttoptr i64 %v3934 to ptr
  %call3936 = call i32 @myl_qbe_rc_unique_local(ptr %p3930, ptr %p3931, ptr %p3933, ptr %p3935) nomerge, !dbg !128
  store i32 %call3936, ptr %slot473, align 8
  %v3937 = load i32, ptr %slot473, align 8
  %cv3938 = zext i32 %v3937 to i64
  %cond3939 = icmp ne i64 %cv3938, 0
  br i1 %cond3939, label %bb_rcunique607, label %bb_failure
bb_rcunique607:
  br label %bb_rcgunique596
bb_rcgunique596:
  %v3940 = load i64, ptr %slot22, align 8
  %p3941 = inttoptr i64 %v3940 to ptr
  %ld3942 = load i64, ptr %p3941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3942, ptr %slot474, align 8
  %v3943 = load i64, ptr %slot25, align 8
  store i64 %v3943, ptr %slot475, align 8
  %v3944 = load i64, ptr %slot475, align 8
  %p3945 = inttoptr i64 %v3944 to ptr
  %ld3946 = load i64, ptr %p3945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3946, ptr %slot476, align 8
  %v3947 = load i64, ptr %slot476, align 8
  %v3948 = load i64, ptr %slot18, align 8
  %p3949 = inttoptr i64 %v3948 to ptr
  store i64 %v3947, ptr %p3949, align 8, !alias.scope !3, !noalias !4
  %v3950 = load i64, ptr %slot18, align 8
  store i64 %v3950, ptr %slot477, align 8
  %v3951 = load i64, ptr %slot31, align 8
  %v3952 = load i64, ptr %slot474, align 8
  %v3953 = load i64, ptr %slot477, align 8
  %call3954 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v3951, i64 %v3952, i64 %v3953) nomerge, !dbg !128
  store i32 %call3954, ptr %slot478, align 8
  %v3955 = load i32, ptr %slot478, align 8
  %cv3956 = zext i32 %v3955 to i64
  %cond3957 = icmp ne i64 %cv3956, 0
  br i1 %cond3957, label %bb_success613, label %bb_failed613
bb_failed613:
  %v3958 = load i64, ptr %slot1, align 8
  %p3959 = inttoptr i64 %v3958 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3959) nomerge, !dbg !128
  unreachable
bb_success613:
  %v3960 = load i64, ptr %slot25, align 8
  %p3961 = inttoptr i64 %v3960 to ptr
  store i64 0, ptr %p3961, align 8, !alias.scope !3, !noalias !4
  %v3962 = load i64, ptr %slot11, align 8
  %p3963 = inttoptr i64 %v3962 to ptr
  %ld3964 = load i32, ptr %p3963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3964, ptr %slot479, align 8
  %v3965 = load i32, ptr %slot479, align 8
  %cv3966 = zext i32 %v3965 to i64
  %cond3967 = icmp ne i64 %cv3966, 0
  br i1 %cond3967, label %bb_rcslotdrop616, label %bb_rcslotdone616
bb_rcslotdrop616:
  %v3968 = load i64, ptr %slot11, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  store i32 0, ptr %p3969, align 4, !alias.scope !3, !noalias !4
  %v3970 = load i64, ptr %slot15, align 8
  store i64 %v3970, ptr %slot480, align 8
  %v3971 = load i64, ptr %slot12, align 8
  %p3972 = inttoptr i64 %v3971 to ptr
  %ld3973 = load i32, ptr %p3972, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3973, ptr %slot481, align 8
  %v3974 = load i32, ptr %slot481, align 8
  %op3975 = and i32 %v3974, 28
  store i32 %op3975, ptr %slot482, align 8
  %v3976 = load i32, ptr %slot482, align 8
  %cv3977 = zext i32 %v3976 to i64
  %cond3978 = icmp ne i64 %cv3977, 0
  br i1 %cond3978, label %bb_rcslotrole616, label %bb_rcslotowner616
bb_rcslotrole616:
  %v3979 = load i64, ptr %slot31, align 8
  store i64 %v3979, ptr %slot483, align 8
  %v3980 = load i64, ptr %slot480, align 8
  %p3981 = inttoptr i64 %v3980 to ptr
  %ld3982 = load i64, ptr %p3981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3982, ptr %slot484, align 8
  %v3983 = load i64, ptr %slot484, align 8
  %cmp3984 = icmp ne i64 %v3983, 0
  %cv3985 = zext i1 %cmp3984 to i32
  store i32 %cv3985, ptr %slot485, align 8
  %v3986 = load i32, ptr %slot485, align 8
  %cv3987 = zext i32 %v3986 to i64
  %cond3988 = icmp ne i64 %cv3987, 0
  br i1 %cond3988, label %bb_rcgnn632, label %bb_rcgdone632
bb_rcgnn632:
  %v3989 = load i64, ptr %slot484, align 8
  %op3990 = sub i64 %v3989, 16
  store i64 %op3990, ptr %slot486, align 8
  %v3991 = load i64, ptr %slot484, align 8
  %p3992 = inttoptr i64 %v3991 to ptr
  %rgep3993 = getelementptr i8, ptr %p3992, i64 -16
  %ld3994 = load i64, ptr %rgep3993, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3994, ptr %slot487, align 8
  %v3995 = load i64, ptr %slot487, align 8
  %op3996 = and i64 %v3995, 4611686018427387906
  store i64 %op3996, ptr %slot488, align 8
  %v3997 = load i64, ptr %slot488, align 8
  %cmp3998 = icmp ne i64 %v3997, 0
  %cv3999 = zext i1 %cmp3998 to i32
  store i32 %cv3999, ptr %slot489, align 8
  %v4000 = load i32, ptr %slot489, align 8
  %cv4001 = zext i32 %v4000 to i64
  %cond4002 = icmp ne i64 %cv4001, 0
  br i1 %cond4002, label %bb_rcgclear632, label %bb_rcgcounted632
bb_rcgcounted632:
  %v4003 = load i64, ptr %slot484, align 8
  %op4004 = sub i64 %v4003, 24
  store i64 %op4004, ptr %slot490, align 8
  %v4005 = load i64, ptr %slot484, align 8
  %p4006 = inttoptr i64 %v4005 to ptr
  %rgep4007 = getelementptr i8, ptr %p4006, i64 -24
  %ld4008 = load i64, ptr %rgep4007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4008, ptr %slot491, align 8
  %v4009 = load i64, ptr %slot491, align 8
  %op4010 = sub i64 %v4009, 1
  store i64 %op4010, ptr %slot492, align 8
  %v4011 = load i64, ptr %slot492, align 8
  %cmp4012 = icmp eq i64 %v4011, 0
  %cv4013 = zext i1 %cmp4012 to i32
  store i32 %cv4013, ptr %slot493, align 8
  %v4014 = load i32, ptr %slot493, align 8
  %cv4015 = zext i32 %v4014 to i64
  %cond4016 = icmp ne i64 %cv4015, 0
  br i1 %cond4016, label %bb_rcglast632, label %bb_rcgdec632
bb_rcglast632:
  %v4017 = load i64, ptr %slot484, align 8
  %op4018 = sub i64 %v4017, 32
  store i64 %op4018, ptr %slot494, align 8
  %v4019 = load i64, ptr %slot484, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  %rgep4021 = getelementptr i8, ptr %p4020, i64 -32
  %ld4022 = load i64, ptr %rgep4021, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4022, ptr %slot495, align 8
  %v4023 = load i64, ptr %slot495, align 8
  %cmp4024 = icmp ne i64 %v4023, 0
  %cv4025 = zext i1 %cmp4024 to i32
  store i32 %cv4025, ptr %slot496, align 8
  %v4026 = load i32, ptr %slot496, align 8
  %cv4027 = zext i32 %v4026 to i64
  %cond4028 = icmp ne i64 %cv4027, 0
  br i1 %cond4028, label %bb_rcgdec632, label %bb_rcgslow632
bb_rcgslow632:
  %v4029 = load i64, ptr %slot483, align 8
  %v4030 = load i64, ptr %slot480, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v4029, i64 %v4030) nomerge, !dbg !128
  br label %bb_rcgdone632
bb_rcgdec632:
  %v4031 = load i64, ptr %slot492, align 8
  %v4032 = load i64, ptr %slot484, align 8
  %p4033 = inttoptr i64 %v4032 to ptr
  %rgep4034 = getelementptr i8, ptr %p4033, i64 -24
  store i64 %v4031, ptr %rgep4034, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear632
bb_rcgclear632:
  %v4035 = load i64, ptr %slot480, align 8
  %p4036 = inttoptr i64 %v4035 to ptr
  store i64 0, ptr %p4036, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone632
bb_rcgdone632:
  br label %bb_rcslotdone616
bb_rcslotowner616:
  %v4037 = load i64, ptr %slot31, align 8
  store i64 %v4037, ptr %slot497, align 8
  %v4038 = load i64, ptr %slot480, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  %ld4040 = load i64, ptr %p4039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4040, ptr %slot498, align 8
  %v4041 = load i64, ptr %slot498, align 8
  %cmp4042 = icmp ne i64 %v4041, 0
  %cv4043 = zext i1 %cmp4042 to i32
  store i32 %cv4043, ptr %slot499, align 8
  %v4044 = load i32, ptr %slot499, align 8
  %cv4045 = zext i32 %v4044 to i64
  %cond4046 = icmp ne i64 %cv4045, 0
  br i1 %cond4046, label %bb_rcgnn647, label %bb_rcgdone647
bb_rcgnn647:
  %v4047 = load i64, ptr %slot498, align 8
  %op4048 = sub i64 %v4047, 16
  store i64 %op4048, ptr %slot500, align 8
  %v4049 = load i64, ptr %slot498, align 8
  %p4050 = inttoptr i64 %v4049 to ptr
  %rgep4051 = getelementptr i8, ptr %p4050, i64 -16
  %ld4052 = load i64, ptr %rgep4051, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4052, ptr %slot501, align 8
  %v4053 = load i64, ptr %slot501, align 8
  %op4054 = and i64 %v4053, 4611686018427387906
  store i64 %op4054, ptr %slot502, align 8
  %v4055 = load i64, ptr %slot502, align 8
  %cmp4056 = icmp ne i64 %v4055, 0
  %cv4057 = zext i1 %cmp4056 to i32
  store i32 %cv4057, ptr %slot503, align 8
  %v4058 = load i32, ptr %slot503, align 8
  %cv4059 = zext i32 %v4058 to i64
  %cond4060 = icmp ne i64 %cv4059, 0
  br i1 %cond4060, label %bb_rcgclear647, label %bb_rcgcounted647
bb_rcgcounted647:
  %v4061 = load i64, ptr %slot498, align 8
  %op4062 = sub i64 %v4061, 32
  store i64 %op4062, ptr %slot504, align 8
  %v4063 = load i64, ptr %slot498, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  %rgep4065 = getelementptr i8, ptr %p4064, i64 -32
  %ld4066 = load i64, ptr %rgep4065, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4066, ptr %slot505, align 8
  %v4067 = load i64, ptr %slot505, align 8
  %op4068 = sub i64 %v4067, 1
  store i64 %op4068, ptr %slot506, align 8
  %v4069 = load i64, ptr %slot506, align 8
  %cmp4070 = icmp eq i64 %v4069, 0
  %cv4071 = zext i1 %cmp4070 to i32
  store i32 %cv4071, ptr %slot507, align 8
  %v4072 = load i32, ptr %slot507, align 8
  %cv4073 = zext i32 %v4072 to i64
  %cond4074 = icmp ne i64 %cv4073, 0
  br i1 %cond4074, label %bb_rcglast647, label %bb_rcgdec647
bb_rcglast647:
  %v4075 = load i64, ptr %slot498, align 8
  %op4076 = sub i64 %v4075, 24
  store i64 %op4076, ptr %slot508, align 8
  %v4077 = load i64, ptr %slot498, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  %rgep4079 = getelementptr i8, ptr %p4078, i64 -24
  %ld4080 = load i64, ptr %rgep4079, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4080, ptr %slot509, align 8
  %v4081 = load i64, ptr %slot509, align 8
  %cmp4082 = icmp ne i64 %v4081, 0
  %cv4083 = zext i1 %cmp4082 to i32
  store i32 %cv4083, ptr %slot510, align 8
  %v4084 = load i32, ptr %slot510, align 8
  %cv4085 = zext i32 %v4084 to i64
  %cond4086 = icmp ne i64 %cv4085, 0
  br i1 %cond4086, label %bb_rcgdec647, label %bb_rcgslow647
bb_rcgslow647:
  %v4087 = load i64, ptr %slot497, align 8
  %v4088 = load i64, ptr %slot480, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v4087, i64 %v4088) nomerge, !dbg !128
  br label %bb_rcgdone647
bb_rcgdec647:
  %v4089 = load i64, ptr %slot506, align 8
  %v4090 = load i64, ptr %slot498, align 8
  %p4091 = inttoptr i64 %v4090 to ptr
  %rgep4092 = getelementptr i8, ptr %p4091, i64 -32
  store i64 %v4089, ptr %rgep4092, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear647
bb_rcgclear647:
  %v4093 = load i64, ptr %slot480, align 8
  %p4094 = inttoptr i64 %v4093 to ptr
  store i64 0, ptr %p4094, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone647
bb_rcgdone647:
  br label %bb_rcslotdone616
bb_rcslotdone616:
  %p4095 = inttoptr i64 ptrtoint (ptr @myl_lit_3e0f7c480fb396db96bccf46cda95f243fa43708fba20c82ddd7533a5f278861 to i64) to ptr
  %ld4096 = load i64, ptr %p4095, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4096, ptr %slot511, align 8
  %v4097 = load i64, ptr %slot511, align 8
  %v4098 = load i64, ptr %slot25, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  store i64 %v4097, ptr %p4099, align 8, !alias.scope !3, !noalias !4
  %v4100 = load i64, ptr %slot25, align 8
  %p4101 = inttoptr i64 %v4100 to ptr
  %ld4102 = load i64, ptr %p4101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4102, ptr %slot512, align 8
  %v4103 = load i64, ptr %slot512, align 8
  %v4104 = load i64, ptr %slot16, align 8
  %p4105 = inttoptr i64 %v4104 to ptr
  store i64 %v4103, ptr %p4105, align 8, !alias.scope !3, !noalias !4
  %v4106 = load i64, ptr %slot16, align 8
  store i64 %v4106, ptr %slot513, align 8
  %v4107 = load i64, ptr %slot17, align 8
  store i64 %v4107, ptr %slot514, align 8
  %v4108 = load i64, ptr %slot513, align 8
  %v4109 = load i64, ptr %slot514, align 8
  %p4110 = inttoptr i64 %v4108 to ptr
  %p4111 = inttoptr i64 %v4109 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4111, ptr %p4110, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4112 = load i64, ptr %slot14, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  store i32 2, ptr %p4113, align 4, !alias.scope !3, !noalias !4
  %v4114 = load i64, ptr %slot13, align 8
  %p4115 = inttoptr i64 %v4114 to ptr
  store i32 1, ptr %p4115, align 4, !alias.scope !3, !noalias !4
  %v4116 = load i64, ptr %slot15, align 8
  store i64 %v4116, ptr %slot515, align 8
  %v4117 = load i64, ptr %slot17, align 8
  store i64 %v4117, ptr %slot516, align 8
  %v4118 = load i64, ptr %slot516, align 8
  %v4119 = load i64, ptr %slot515, align 8
  %p4120 = inttoptr i64 %v4118 to ptr
  %p4121 = inttoptr i64 %v4119 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4121, ptr %p4120, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4122 = load i64, ptr %slot12, align 8
  %p4123 = inttoptr i64 %v4122 to ptr
  store i32 2, ptr %p4123, align 4, !alias.scope !3, !noalias !4
  %v4124 = load i64, ptr %slot14, align 8
  %p4125 = inttoptr i64 %v4124 to ptr
  %ld4126 = load i32, ptr %p4125, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4126, ptr %slot517, align 8
  %v4127 = load i32, ptr %slot517, align 8
  %v4128 = load i64, ptr %slot12, align 8
  %p4129 = inttoptr i64 %v4128 to ptr
  store i32 %v4127, ptr %p4129, align 4, !alias.scope !3, !noalias !4
  %v4130 = load i64, ptr %slot13, align 8
  %p4131 = inttoptr i64 %v4130 to ptr
  store i32 0, ptr %p4131, align 4, !alias.scope !3, !noalias !4
  %v4132 = load i64, ptr %slot11, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  store i32 1, ptr %p4133, align 4, !alias.scope !3, !noalias !4
  %v4134 = load i64, ptr %slot515, align 8
  %p4135 = inttoptr i64 %v4134 to ptr
  %ld4136 = load i64, ptr %p4135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4136, ptr %slot518, align 8
  %v4137 = load i64, ptr %slot518, align 8
  %v4138 = load i64, ptr %slot25, align 8
  %p4139 = inttoptr i64 %v4138 to ptr
  store i64 %v4137, ptr %p4139, align 8, !alias.scope !3, !noalias !4
  %v4140 = load i64, ptr %slot22, align 8
  store i64 %v4140, ptr %slot519, align 8
  %v4141 = load i64, ptr %slot6, align 8
  %p4142 = inttoptr i64 %v4141 to ptr
  %ld4143 = load i32, ptr %p4142, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4143, ptr %slot520, align 8
  %v4144 = load i32, ptr %slot520, align 8
  %cmp4145 = icmp eq i32 %v4144, 16
  %cv4146 = zext i1 %cmp4145 to i32
  store i32 %cv4146, ptr %slot521, align 8
  %v4147 = load i64, ptr %slot5, align 8
  %p4148 = inttoptr i64 %v4147 to ptr
  %ld4149 = load i32, ptr %p4148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4149, ptr %slot522, align 8
  %v4150 = load i32, ptr %slot522, align 8
  %v4151 = load i32, ptr %slot521, align 8
  %op4152 = and i32 %v4150, %v4151
  store i32 %op4152, ptr %slot523, align 8
  %v4153 = load i32, ptr %slot523, align 8
  %cv4154 = zext i32 %v4153 to i64
  %cond4155 = icmp ne i64 %cv4154, 0
  br i1 %cond4155, label %bb_rcownlocal673, label %bb_rcownedlocal673
bb_rcownlocal673:
  %v4156 = load i64, ptr %slot22, align 8
  store i64 %v4156, ptr %slot524, align 8
  %v4157 = load i64, ptr %slot17, align 8
  store i64 %v4157, ptr %slot525, align 8
  %v4158 = load i64, ptr %slot32, align 8
  store i64 %v4158, ptr %slot526, align 8
  %v4159 = load i64, ptr %slot524, align 8
  %p4160 = inttoptr i64 %v4159 to ptr
  %ld4161 = load i64, ptr %p4160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4161, ptr %slot527, align 8
  %v4162 = load i64, ptr %slot527, align 8
  %cmp4163 = icmp ne i64 %v4162, 0
  %cv4164 = zext i1 %cmp4163 to i32
  store i32 %cv4164, ptr %slot528, align 8
  %v4165 = load i32, ptr %slot528, align 8
  %cv4166 = zext i32 %v4165 to i64
  %cond4167 = icmp ne i64 %cv4166, 0
  br i1 %cond4167, label %bb_rcgnn680, label %bb_rcgplain680
bb_rcgnn680:
  %v4168 = load i64, ptr %slot527, align 8
  %op4169 = sub i64 %v4168, 16
  store i64 %op4169, ptr %slot529, align 8
  %v4170 = load i64, ptr %slot527, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %rgep4172 = getelementptr i8, ptr %p4171, i64 -16
  %ld4173 = load i64, ptr %rgep4172, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4173, ptr %slot530, align 8
  %v4174 = load i64, ptr %slot530, align 8
  %op4175 = and i64 %v4174, 4611686018427387906
  store i64 %op4175, ptr %slot531, align 8
  %v4176 = load i64, ptr %slot531, align 8
  %cmp4177 = icmp ne i64 %v4176, 0
  %cv4178 = zext i1 %cmp4177 to i32
  store i32 %cv4178, ptr %slot532, align 8
  %v4179 = load i32, ptr %slot532, align 8
  %cv4180 = zext i32 %v4179 to i64
  %cond4181 = icmp ne i64 %cv4180, 0
  br i1 %cond4181, label %bb_rcgspecial680, label %bb_rcginc680
bb_rcginc680:
  %v4182 = load i64, ptr %slot527, align 8
  %op4183 = sub i64 %v4182, 32
  store i64 %op4183, ptr %slot533, align 8
  %v4184 = load i64, ptr %slot527, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  %rgep4186 = getelementptr i8, ptr %p4185, i64 -32
  %ld4187 = load i64, ptr %rgep4186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4187, ptr %slot534, align 8
  %v4188 = load i64, ptr %slot534, align 8
  %op4189 = add i64 %v4188, 1
  store i64 %op4189, ptr %slot535, align 8
  %v4190 = load i64, ptr %slot535, align 8
  %cmp4191 = icmp eq i64 %v4190, 0
  %cv4192 = zext i1 %cmp4191 to i32
  store i32 %cv4192, ptr %slot536, align 8
  %v4193 = load i32, ptr %slot536, align 8
  %cv4194 = zext i32 %v4193 to i64
  %cond4195 = icmp ne i64 %cv4194, 0
  br i1 %cond4195, label %bb_rcglimit680, label %bb_rcgcapacity680
bb_rcglimit680:
  %v4196 = load i64, ptr %slot1, align 8
  %p4197 = inttoptr i64 %v4196 to ptr
  %call4198 = call i32 @myl_qbe_rc_status(ptr %p4197, i32 2) nomerge, !dbg !130
  store i32 %call4198, ptr %slot537, align 8
  br label %bb_failure
bb_rcgcapacity680:
  %v4199 = load i64, ptr %slot535, align 8
  %v4200 = load i64, ptr %slot527, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  %rgep4202 = getelementptr i8, ptr %p4201, i64 -32
  store i64 %v4199, ptr %rgep4202, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain680
bb_rcgspecial680:
  %v4203 = load i64, ptr %slot530, align 8
  %op4204 = and i64 %v4203, 4611686018427387904
  store i64 %op4204, ptr %slot538, align 8
  %v4205 = load i64, ptr %slot538, align 8
  %cmp4206 = icmp ne i64 %v4205, 0
  %cv4207 = zext i1 %cmp4206 to i32
  store i32 %cv4207, ptr %slot539, align 8
  %v4208 = load i32, ptr %slot539, align 8
  %cv4209 = zext i32 %v4208 to i64
  %cond4210 = icmp ne i64 %cv4209, 0
  br i1 %cond4210, label %bb_rcgslow680, label %bb_rcgplain680
bb_rcgslow680:
  %v4211 = load i64, ptr %slot31, align 8
  %v4212 = load i64, ptr %slot525, align 8
  %v4213 = load i64, ptr %slot524, align 8
  %v4214 = load i64, ptr %slot526, align 8
  %cv4215 = trunc i64 %v4214 to i32
  %call4216 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v4211, i64 %v4212, i64 %v4213, i32 %cv4215) nomerge, !dbg !130
  store i32 %call4216, ptr %slot540, align 8
  %v4217 = load i32, ptr %slot540, align 8
  %cv4218 = zext i32 %v4217 to i64
  %cond4219 = icmp ne i64 %cv4218, 0
  br i1 %cond4219, label %bb_rcsuccess694, label %bb_rcfailure694
bb_rcfailure694:
  %v4220 = load i64, ptr %slot31, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  %call4222 = call i32 @myl_rc_take_failure(ptr %p4221) nomerge, !dbg !130
  store i32 %call4222, ptr %slot541, align 8
  %v4223 = load i64, ptr %slot1, align 8
  %p4224 = inttoptr i64 %v4223 to ptr
  %v4225 = load i32, ptr %slot541, align 8
  %call4226 = call i32 @myl_qbe_rc_status(ptr %p4224, i32 %v4225) nomerge, !dbg !130
  store i32 %call4226, ptr %slot542, align 8
  br label %bb_failure
bb_rcsuccess694:
  br label %bb_rcgdone680
bb_rcgplain680:
  %v4227 = load i64, ptr %slot527, align 8
  %v4228 = load i64, ptr %slot525, align 8
  %p4229 = inttoptr i64 %v4228 to ptr
  store i64 %v4227, ptr %p4229, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone680
bb_rcgdone680:
  %v4230 = load i64, ptr %slot14, align 8
  %p4231 = inttoptr i64 %v4230 to ptr
  store i32 2, ptr %p4231, align 4, !alias.scope !3, !noalias !4
  %v4232 = load i64, ptr %slot13, align 8
  %p4233 = inttoptr i64 %v4232 to ptr
  store i32 1, ptr %p4233, align 4, !alias.scope !3, !noalias !4
  %v4234 = load i64, ptr %slot5, align 8
  %p4235 = inttoptr i64 %v4234 to ptr
  %ld4236 = load i32, ptr %p4235, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4236, ptr %slot543, align 8
  %v4237 = load i32, ptr %slot543, align 8
  %cv4238 = zext i32 %v4237 to i64
  %cond4239 = icmp ne i64 %cv4238, 0
  br i1 %cond4239, label %bb_rcslotdrop701, label %bb_rcslotdone701
bb_rcslotdrop701:
  %v4240 = load i64, ptr %slot5, align 8
  %p4241 = inttoptr i64 %v4240 to ptr
  store i32 0, ptr %p4241, align 4, !alias.scope !3, !noalias !4
  %v4242 = load i64, ptr %slot22, align 8
  store i64 %v4242, ptr %slot544, align 8
  %v4243 = load i64, ptr %slot6, align 8
  %p4244 = inttoptr i64 %v4243 to ptr
  %ld4245 = load i32, ptr %p4244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4245, ptr %slot545, align 8
  %v4246 = load i32, ptr %slot545, align 8
  %op4247 = and i32 %v4246, 28
  store i32 %op4247, ptr %slot546, align 8
  %v4248 = load i32, ptr %slot546, align 8
  %cv4249 = zext i32 %v4248 to i64
  %cond4250 = icmp ne i64 %cv4249, 0
  br i1 %cond4250, label %bb_rcslotrole701, label %bb_rcslotowner701
bb_rcslotrole701:
  %v4251 = load i64, ptr %slot31, align 8
  store i64 %v4251, ptr %slot547, align 8
  %v4252 = load i64, ptr %slot544, align 8
  %p4253 = inttoptr i64 %v4252 to ptr
  %ld4254 = load i64, ptr %p4253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4254, ptr %slot548, align 8
  %v4255 = load i64, ptr %slot548, align 8
  %cmp4256 = icmp ne i64 %v4255, 0
  %cv4257 = zext i1 %cmp4256 to i32
  store i32 %cv4257, ptr %slot549, align 8
  %v4258 = load i32, ptr %slot549, align 8
  %cv4259 = zext i32 %v4258 to i64
  %cond4260 = icmp ne i64 %cv4259, 0
  br i1 %cond4260, label %bb_rcgnn717, label %bb_rcgdone717
bb_rcgnn717:
  %v4261 = load i64, ptr %slot548, align 8
  %op4262 = sub i64 %v4261, 16
  store i64 %op4262, ptr %slot550, align 8
  %v4263 = load i64, ptr %slot548, align 8
  %p4264 = inttoptr i64 %v4263 to ptr
  %rgep4265 = getelementptr i8, ptr %p4264, i64 -16
  %ld4266 = load i64, ptr %rgep4265, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4266, ptr %slot551, align 8
  %v4267 = load i64, ptr %slot551, align 8
  %op4268 = and i64 %v4267, 4611686018427387906
  store i64 %op4268, ptr %slot552, align 8
  %v4269 = load i64, ptr %slot552, align 8
  %cmp4270 = icmp ne i64 %v4269, 0
  %cv4271 = zext i1 %cmp4270 to i32
  store i32 %cv4271, ptr %slot553, align 8
  %v4272 = load i32, ptr %slot553, align 8
  %cv4273 = zext i32 %v4272 to i64
  %cond4274 = icmp ne i64 %cv4273, 0
  br i1 %cond4274, label %bb_rcgclear717, label %bb_rcgcounted717
bb_rcgcounted717:
  %v4275 = load i64, ptr %slot548, align 8
  %op4276 = sub i64 %v4275, 24
  store i64 %op4276, ptr %slot554, align 8
  %v4277 = load i64, ptr %slot548, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  %rgep4279 = getelementptr i8, ptr %p4278, i64 -24
  %ld4280 = load i64, ptr %rgep4279, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4280, ptr %slot555, align 8
  %v4281 = load i64, ptr %slot555, align 8
  %op4282 = sub i64 %v4281, 1
  store i64 %op4282, ptr %slot556, align 8
  %v4283 = load i64, ptr %slot556, align 8
  %cmp4284 = icmp eq i64 %v4283, 0
  %cv4285 = zext i1 %cmp4284 to i32
  store i32 %cv4285, ptr %slot557, align 8
  %v4286 = load i32, ptr %slot557, align 8
  %cv4287 = zext i32 %v4286 to i64
  %cond4288 = icmp ne i64 %cv4287, 0
  br i1 %cond4288, label %bb_rcglast717, label %bb_rcgdec717
bb_rcglast717:
  %v4289 = load i64, ptr %slot548, align 8
  %op4290 = sub i64 %v4289, 32
  store i64 %op4290, ptr %slot558, align 8
  %v4291 = load i64, ptr %slot548, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  %rgep4293 = getelementptr i8, ptr %p4292, i64 -32
  %ld4294 = load i64, ptr %rgep4293, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4294, ptr %slot559, align 8
  %v4295 = load i64, ptr %slot559, align 8
  %cmp4296 = icmp ne i64 %v4295, 0
  %cv4297 = zext i1 %cmp4296 to i32
  store i32 %cv4297, ptr %slot560, align 8
  %v4298 = load i32, ptr %slot560, align 8
  %cv4299 = zext i32 %v4298 to i64
  %cond4300 = icmp ne i64 %cv4299, 0
  br i1 %cond4300, label %bb_rcgdec717, label %bb_rcgslow717
bb_rcgslow717:
  %v4301 = load i64, ptr %slot547, align 8
  %v4302 = load i64, ptr %slot544, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v4301, i64 %v4302) nomerge, !dbg !130
  br label %bb_rcgdone717
bb_rcgdec717:
  %v4303 = load i64, ptr %slot556, align 8
  %v4304 = load i64, ptr %slot548, align 8
  %p4305 = inttoptr i64 %v4304 to ptr
  %rgep4306 = getelementptr i8, ptr %p4305, i64 -24
  store i64 %v4303, ptr %rgep4306, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear717
bb_rcgclear717:
  %v4307 = load i64, ptr %slot544, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  store i64 0, ptr %p4308, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone717
bb_rcgdone717:
  br label %bb_rcslotdone701
bb_rcslotowner701:
  %v4309 = load i64, ptr %slot31, align 8
  store i64 %v4309, ptr %slot561, align 8
  %v4310 = load i64, ptr %slot544, align 8
  %p4311 = inttoptr i64 %v4310 to ptr
  %ld4312 = load i64, ptr %p4311, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4312, ptr %slot562, align 8
  %v4313 = load i64, ptr %slot562, align 8
  %cmp4314 = icmp ne i64 %v4313, 0
  %cv4315 = zext i1 %cmp4314 to i32
  store i32 %cv4315, ptr %slot563, align 8
  %v4316 = load i32, ptr %slot563, align 8
  %cv4317 = zext i32 %v4316 to i64
  %cond4318 = icmp ne i64 %cv4317, 0
  br i1 %cond4318, label %bb_rcgnn732, label %bb_rcgdone732
bb_rcgnn732:
  %v4319 = load i64, ptr %slot562, align 8
  %op4320 = sub i64 %v4319, 16
  store i64 %op4320, ptr %slot564, align 8
  %v4321 = load i64, ptr %slot562, align 8
  %p4322 = inttoptr i64 %v4321 to ptr
  %rgep4323 = getelementptr i8, ptr %p4322, i64 -16
  %ld4324 = load i64, ptr %rgep4323, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4324, ptr %slot565, align 8
  %v4325 = load i64, ptr %slot565, align 8
  %op4326 = and i64 %v4325, 4611686018427387906
  store i64 %op4326, ptr %slot566, align 8
  %v4327 = load i64, ptr %slot566, align 8
  %cmp4328 = icmp ne i64 %v4327, 0
  %cv4329 = zext i1 %cmp4328 to i32
  store i32 %cv4329, ptr %slot567, align 8
  %v4330 = load i32, ptr %slot567, align 8
  %cv4331 = zext i32 %v4330 to i64
  %cond4332 = icmp ne i64 %cv4331, 0
  br i1 %cond4332, label %bb_rcgclear732, label %bb_rcgcounted732
bb_rcgcounted732:
  %v4333 = load i64, ptr %slot562, align 8
  %op4334 = sub i64 %v4333, 32
  store i64 %op4334, ptr %slot568, align 8
  %v4335 = load i64, ptr %slot562, align 8
  %p4336 = inttoptr i64 %v4335 to ptr
  %rgep4337 = getelementptr i8, ptr %p4336, i64 -32
  %ld4338 = load i64, ptr %rgep4337, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4338, ptr %slot569, align 8
  %v4339 = load i64, ptr %slot569, align 8
  %op4340 = sub i64 %v4339, 1
  store i64 %op4340, ptr %slot570, align 8
  %v4341 = load i64, ptr %slot570, align 8
  %cmp4342 = icmp eq i64 %v4341, 0
  %cv4343 = zext i1 %cmp4342 to i32
  store i32 %cv4343, ptr %slot571, align 8
  %v4344 = load i32, ptr %slot571, align 8
  %cv4345 = zext i32 %v4344 to i64
  %cond4346 = icmp ne i64 %cv4345, 0
  br i1 %cond4346, label %bb_rcglast732, label %bb_rcgdec732
bb_rcglast732:
  %v4347 = load i64, ptr %slot562, align 8
  %op4348 = sub i64 %v4347, 24
  store i64 %op4348, ptr %slot572, align 8
  %v4349 = load i64, ptr %slot562, align 8
  %p4350 = inttoptr i64 %v4349 to ptr
  %rgep4351 = getelementptr i8, ptr %p4350, i64 -24
  %ld4352 = load i64, ptr %rgep4351, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4352, ptr %slot573, align 8
  %v4353 = load i64, ptr %slot573, align 8
  %cmp4354 = icmp ne i64 %v4353, 0
  %cv4355 = zext i1 %cmp4354 to i32
  store i32 %cv4355, ptr %slot574, align 8
  %v4356 = load i32, ptr %slot574, align 8
  %cv4357 = zext i32 %v4356 to i64
  %cond4358 = icmp ne i64 %cv4357, 0
  br i1 %cond4358, label %bb_rcgdec732, label %bb_rcgslow732
bb_rcgslow732:
  %v4359 = load i64, ptr %slot561, align 8
  %v4360 = load i64, ptr %slot544, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v4359, i64 %v4360) nomerge, !dbg !130
  br label %bb_rcgdone732
bb_rcgdec732:
  %v4361 = load i64, ptr %slot570, align 8
  %v4362 = load i64, ptr %slot562, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  %rgep4364 = getelementptr i8, ptr %p4363, i64 -32
  store i64 %v4361, ptr %rgep4364, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear732
bb_rcgclear732:
  %v4365 = load i64, ptr %slot544, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  store i64 0, ptr %p4366, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone732
bb_rcgdone732:
  br label %bb_rcslotdone701
bb_rcslotdone701:
  %v4367 = load i64, ptr %slot17, align 8
  store i64 %v4367, ptr %slot575, align 8
  %v4368 = load i64, ptr %slot575, align 8
  %v4369 = load i64, ptr %slot524, align 8
  %p4370 = inttoptr i64 %v4368 to ptr
  %p4371 = inttoptr i64 %v4369 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4371, ptr %p4370, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4372 = load i64, ptr %slot6, align 8
  %p4373 = inttoptr i64 %v4372 to ptr
  store i32 2, ptr %p4373, align 4, !alias.scope !3, !noalias !4
  %v4374 = load i64, ptr %slot5, align 8
  %p4375 = inttoptr i64 %v4374 to ptr
  store i32 1, ptr %p4375, align 4, !alias.scope !3, !noalias !4
  %v4376 = load i64, ptr %slot13, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  store i32 0, ptr %p4377, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal673
bb_rcownedlocal673:
  %v4378 = load i64, ptr %slot6, align 8
  %p4379 = inttoptr i64 %v4378 to ptr
  store i32 2, ptr %p4379, align 4, !alias.scope !3, !noalias !4
  %v4380 = load i64, ptr %slot519, align 8
  %p4381 = inttoptr i64 %v4380 to ptr
  %ld4382 = load i64, ptr %p4381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4382, ptr %slot576, align 8
  %v4383 = load i64, ptr %slot576, align 8
  %cmp4384 = icmp ne i64 %v4383, 0
  %cv4385 = zext i1 %cmp4384 to i32
  store i32 %cv4385, ptr %slot577, align 8
  %v4386 = load i32, ptr %slot577, align 8
  %cv4387 = zext i32 %v4386 to i64
  %cond4388 = icmp ne i64 %cv4387, 0
  br i1 %cond4388, label %bb_rcguniquenn741, label %bb_rcgunique741
bb_rcguniquenn741:
  %v4389 = load i64, ptr %slot576, align 8
  %op4390 = sub i64 %v4389, 16
  store i64 %op4390, ptr %slot578, align 8
  %v4391 = load i64, ptr %slot576, align 8
  %p4392 = inttoptr i64 %v4391 to ptr
  %rgep4393 = getelementptr i8, ptr %p4392, i64 -16
  %ld4394 = load i64, ptr %rgep4393, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4394, ptr %slot579, align 8
  %v4395 = load i64, ptr %slot579, align 8
  %op4396 = and i64 %v4395, 6917529027641081858
  store i64 %op4396, ptr %slot580, align 8
  %v4397 = load i64, ptr %slot580, align 8
  %cmp4398 = icmp ne i64 %v4397, 0
  %cv4399 = zext i1 %cmp4398 to i32
  store i32 %cv4399, ptr %slot581, align 8
  %v4400 = load i32, ptr %slot581, align 8
  %cv4401 = zext i32 %v4400 to i64
  %cond4402 = icmp ne i64 %cv4401, 0
  br i1 %cond4402, label %bb_rcguniqueslow741, label %bb_rcguniquecount741
bb_rcguniquecount741:
  %v4403 = load i64, ptr %slot576, align 8
  %op4404 = sub i64 %v4403, 32
  store i64 %op4404, ptr %slot582, align 8
  %v4405 = load i64, ptr %slot576, align 8
  %p4406 = inttoptr i64 %v4405 to ptr
  %rgep4407 = getelementptr i8, ptr %p4406, i64 -32
  %ld4408 = load i64, ptr %rgep4407, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4408, ptr %slot583, align 8
  %v4409 = load i64, ptr %slot583, align 8
  %cmp4410 = icmp ult i64 %v4409, 2
  %cv4411 = zext i1 %cmp4410 to i32
  store i32 %cv4411, ptr %slot584, align 8
  %v4412 = load i32, ptr %slot584, align 8
  %cv4413 = zext i32 %v4412 to i64
  %cond4414 = icmp ne i64 %cv4413, 0
  br i1 %cond4414, label %bb_rcgunique741, label %bb_rcguniqueslow741
bb_rcguniqueslow741:
  %v4415 = load i64, ptr %slot1, align 8
  %p4416 = inttoptr i64 %v4415 to ptr
  %p4417 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v4418 = load i64, ptr %slot519, align 8
  %p4419 = inttoptr i64 %v4418 to ptr
  %v4420 = load i64, ptr %slot5, align 8
  %p4421 = inttoptr i64 %v4420 to ptr
  %call4422 = call i32 @myl_qbe_rc_unique_local(ptr %p4416, ptr %p4417, ptr %p4419, ptr %p4421) nomerge, !dbg !130
  store i32 %call4422, ptr %slot585, align 8
  %v4423 = load i32, ptr %slot585, align 8
  %cv4424 = zext i32 %v4423 to i64
  %cond4425 = icmp ne i64 %cv4424, 0
  br i1 %cond4425, label %bb_rcunique752, label %bb_failure
bb_rcunique752:
  br label %bb_rcgunique741
bb_rcgunique741:
  %v4426 = load i64, ptr %slot22, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  %ld4428 = load i64, ptr %p4427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4428, ptr %slot586, align 8
  %v4429 = load i64, ptr %slot25, align 8
  store i64 %v4429, ptr %slot587, align 8
  %v4430 = load i64, ptr %slot587, align 8
  %p4431 = inttoptr i64 %v4430 to ptr
  %ld4432 = load i64, ptr %p4431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4432, ptr %slot588, align 8
  %v4433 = load i64, ptr %slot588, align 8
  %v4434 = load i64, ptr %slot18, align 8
  %p4435 = inttoptr i64 %v4434 to ptr
  store i64 %v4433, ptr %p4435, align 8, !alias.scope !3, !noalias !4
  %v4436 = load i64, ptr %slot18, align 8
  store i64 %v4436, ptr %slot589, align 8
  %v4437 = load i64, ptr %slot31, align 8
  %v4438 = load i64, ptr %slot586, align 8
  %v4439 = load i64, ptr %slot589, align 8
  %call4440 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v4437, i64 %v4438, i64 %v4439) nomerge, !dbg !130
  store i32 %call4440, ptr %slot590, align 8
  %v4441 = load i32, ptr %slot590, align 8
  %cv4442 = zext i32 %v4441 to i64
  %cond4443 = icmp ne i64 %cv4442, 0
  br i1 %cond4443, label %bb_success758, label %bb_failed758
bb_failed758:
  %v4444 = load i64, ptr %slot1, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4445) nomerge, !dbg !130
  unreachable
bb_success758:
  %v4446 = load i64, ptr %slot25, align 8
  %p4447 = inttoptr i64 %v4446 to ptr
  store i64 0, ptr %p4447, align 8, !alias.scope !3, !noalias !4
  %v4448 = load i64, ptr %slot11, align 8
  %p4449 = inttoptr i64 %v4448 to ptr
  %ld4450 = load i32, ptr %p4449, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4450, ptr %slot591, align 8
  %v4451 = load i32, ptr %slot591, align 8
  %cv4452 = zext i32 %v4451 to i64
  %cond4453 = icmp ne i64 %cv4452, 0
  br i1 %cond4453, label %bb_rcslotdrop761, label %bb_rcslotdone761
bb_rcslotdrop761:
  %v4454 = load i64, ptr %slot11, align 8
  %p4455 = inttoptr i64 %v4454 to ptr
  store i32 0, ptr %p4455, align 4, !alias.scope !3, !noalias !4
  %v4456 = load i64, ptr %slot15, align 8
  store i64 %v4456, ptr %slot592, align 8
  %v4457 = load i64, ptr %slot12, align 8
  %p4458 = inttoptr i64 %v4457 to ptr
  %ld4459 = load i32, ptr %p4458, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4459, ptr %slot593, align 8
  %v4460 = load i32, ptr %slot593, align 8
  %op4461 = and i32 %v4460, 28
  store i32 %op4461, ptr %slot594, align 8
  %v4462 = load i32, ptr %slot594, align 8
  %cv4463 = zext i32 %v4462 to i64
  %cond4464 = icmp ne i64 %cv4463, 0
  br i1 %cond4464, label %bb_rcslotrole761, label %bb_rcslotowner761
bb_rcslotrole761:
  %v4465 = load i64, ptr %slot31, align 8
  store i64 %v4465, ptr %slot595, align 8
  %v4466 = load i64, ptr %slot592, align 8
  %p4467 = inttoptr i64 %v4466 to ptr
  %ld4468 = load i64, ptr %p4467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4468, ptr %slot596, align 8
  %v4469 = load i64, ptr %slot596, align 8
  %cmp4470 = icmp ne i64 %v4469, 0
  %cv4471 = zext i1 %cmp4470 to i32
  store i32 %cv4471, ptr %slot597, align 8
  %v4472 = load i32, ptr %slot597, align 8
  %cv4473 = zext i32 %v4472 to i64
  %cond4474 = icmp ne i64 %cv4473, 0
  br i1 %cond4474, label %bb_rcgnn777, label %bb_rcgdone777
bb_rcgnn777:
  %v4475 = load i64, ptr %slot596, align 8
  %op4476 = sub i64 %v4475, 16
  store i64 %op4476, ptr %slot598, align 8
  %v4477 = load i64, ptr %slot596, align 8
  %p4478 = inttoptr i64 %v4477 to ptr
  %rgep4479 = getelementptr i8, ptr %p4478, i64 -16
  %ld4480 = load i64, ptr %rgep4479, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4480, ptr %slot599, align 8
  %v4481 = load i64, ptr %slot599, align 8
  %op4482 = and i64 %v4481, 4611686018427387906
  store i64 %op4482, ptr %slot600, align 8
  %v4483 = load i64, ptr %slot600, align 8
  %cmp4484 = icmp ne i64 %v4483, 0
  %cv4485 = zext i1 %cmp4484 to i32
  store i32 %cv4485, ptr %slot601, align 8
  %v4486 = load i32, ptr %slot601, align 8
  %cv4487 = zext i32 %v4486 to i64
  %cond4488 = icmp ne i64 %cv4487, 0
  br i1 %cond4488, label %bb_rcgclear777, label %bb_rcgcounted777
bb_rcgcounted777:
  %v4489 = load i64, ptr %slot596, align 8
  %op4490 = sub i64 %v4489, 24
  store i64 %op4490, ptr %slot602, align 8
  %v4491 = load i64, ptr %slot596, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  %rgep4493 = getelementptr i8, ptr %p4492, i64 -24
  %ld4494 = load i64, ptr %rgep4493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4494, ptr %slot603, align 8
  %v4495 = load i64, ptr %slot603, align 8
  %op4496 = sub i64 %v4495, 1
  store i64 %op4496, ptr %slot604, align 8
  %v4497 = load i64, ptr %slot604, align 8
  %cmp4498 = icmp eq i64 %v4497, 0
  %cv4499 = zext i1 %cmp4498 to i32
  store i32 %cv4499, ptr %slot605, align 8
  %v4500 = load i32, ptr %slot605, align 8
  %cv4501 = zext i32 %v4500 to i64
  %cond4502 = icmp ne i64 %cv4501, 0
  br i1 %cond4502, label %bb_rcglast777, label %bb_rcgdec777
bb_rcglast777:
  %v4503 = load i64, ptr %slot596, align 8
  %op4504 = sub i64 %v4503, 32
  store i64 %op4504, ptr %slot606, align 8
  %v4505 = load i64, ptr %slot596, align 8
  %p4506 = inttoptr i64 %v4505 to ptr
  %rgep4507 = getelementptr i8, ptr %p4506, i64 -32
  %ld4508 = load i64, ptr %rgep4507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4508, ptr %slot607, align 8
  %v4509 = load i64, ptr %slot607, align 8
  %cmp4510 = icmp ne i64 %v4509, 0
  %cv4511 = zext i1 %cmp4510 to i32
  store i32 %cv4511, ptr %slot608, align 8
  %v4512 = load i32, ptr %slot608, align 8
  %cv4513 = zext i32 %v4512 to i64
  %cond4514 = icmp ne i64 %cv4513, 0
  br i1 %cond4514, label %bb_rcgdec777, label %bb_rcgslow777
bb_rcgslow777:
  %v4515 = load i64, ptr %slot595, align 8
  %v4516 = load i64, ptr %slot592, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v4515, i64 %v4516) nomerge, !dbg !130
  br label %bb_rcgdone777
bb_rcgdec777:
  %v4517 = load i64, ptr %slot604, align 8
  %v4518 = load i64, ptr %slot596, align 8
  %p4519 = inttoptr i64 %v4518 to ptr
  %rgep4520 = getelementptr i8, ptr %p4519, i64 -24
  store i64 %v4517, ptr %rgep4520, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear777
bb_rcgclear777:
  %v4521 = load i64, ptr %slot592, align 8
  %p4522 = inttoptr i64 %v4521 to ptr
  store i64 0, ptr %p4522, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone777
bb_rcgdone777:
  br label %bb_rcslotdone761
bb_rcslotowner761:
  %v4523 = load i64, ptr %slot31, align 8
  store i64 %v4523, ptr %slot609, align 8
  %v4524 = load i64, ptr %slot592, align 8
  %p4525 = inttoptr i64 %v4524 to ptr
  %ld4526 = load i64, ptr %p4525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4526, ptr %slot610, align 8
  %v4527 = load i64, ptr %slot610, align 8
  %cmp4528 = icmp ne i64 %v4527, 0
  %cv4529 = zext i1 %cmp4528 to i32
  store i32 %cv4529, ptr %slot611, align 8
  %v4530 = load i32, ptr %slot611, align 8
  %cv4531 = zext i32 %v4530 to i64
  %cond4532 = icmp ne i64 %cv4531, 0
  br i1 %cond4532, label %bb_rcgnn792, label %bb_rcgdone792
bb_rcgnn792:
  %v4533 = load i64, ptr %slot610, align 8
  %op4534 = sub i64 %v4533, 16
  store i64 %op4534, ptr %slot612, align 8
  %v4535 = load i64, ptr %slot610, align 8
  %p4536 = inttoptr i64 %v4535 to ptr
  %rgep4537 = getelementptr i8, ptr %p4536, i64 -16
  %ld4538 = load i64, ptr %rgep4537, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4538, ptr %slot613, align 8
  %v4539 = load i64, ptr %slot613, align 8
  %op4540 = and i64 %v4539, 4611686018427387906
  store i64 %op4540, ptr %slot614, align 8
  %v4541 = load i64, ptr %slot614, align 8
  %cmp4542 = icmp ne i64 %v4541, 0
  %cv4543 = zext i1 %cmp4542 to i32
  store i32 %cv4543, ptr %slot615, align 8
  %v4544 = load i32, ptr %slot615, align 8
  %cv4545 = zext i32 %v4544 to i64
  %cond4546 = icmp ne i64 %cv4545, 0
  br i1 %cond4546, label %bb_rcgclear792, label %bb_rcgcounted792
bb_rcgcounted792:
  %v4547 = load i64, ptr %slot610, align 8
  %op4548 = sub i64 %v4547, 32
  store i64 %op4548, ptr %slot616, align 8
  %v4549 = load i64, ptr %slot610, align 8
  %p4550 = inttoptr i64 %v4549 to ptr
  %rgep4551 = getelementptr i8, ptr %p4550, i64 -32
  %ld4552 = load i64, ptr %rgep4551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4552, ptr %slot617, align 8
  %v4553 = load i64, ptr %slot617, align 8
  %op4554 = sub i64 %v4553, 1
  store i64 %op4554, ptr %slot618, align 8
  %v4555 = load i64, ptr %slot618, align 8
  %cmp4556 = icmp eq i64 %v4555, 0
  %cv4557 = zext i1 %cmp4556 to i32
  store i32 %cv4557, ptr %slot619, align 8
  %v4558 = load i32, ptr %slot619, align 8
  %cv4559 = zext i32 %v4558 to i64
  %cond4560 = icmp ne i64 %cv4559, 0
  br i1 %cond4560, label %bb_rcglast792, label %bb_rcgdec792
bb_rcglast792:
  %v4561 = load i64, ptr %slot610, align 8
  %op4562 = sub i64 %v4561, 24
  store i64 %op4562, ptr %slot620, align 8
  %v4563 = load i64, ptr %slot610, align 8
  %p4564 = inttoptr i64 %v4563 to ptr
  %rgep4565 = getelementptr i8, ptr %p4564, i64 -24
  %ld4566 = load i64, ptr %rgep4565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4566, ptr %slot621, align 8
  %v4567 = load i64, ptr %slot621, align 8
  %cmp4568 = icmp ne i64 %v4567, 0
  %cv4569 = zext i1 %cmp4568 to i32
  store i32 %cv4569, ptr %slot622, align 8
  %v4570 = load i32, ptr %slot622, align 8
  %cv4571 = zext i32 %v4570 to i64
  %cond4572 = icmp ne i64 %cv4571, 0
  br i1 %cond4572, label %bb_rcgdec792, label %bb_rcgslow792
bb_rcgslow792:
  %v4573 = load i64, ptr %slot609, align 8
  %v4574 = load i64, ptr %slot592, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v4573, i64 %v4574) nomerge, !dbg !130
  br label %bb_rcgdone792
bb_rcgdec792:
  %v4575 = load i64, ptr %slot618, align 8
  %v4576 = load i64, ptr %slot610, align 8
  %p4577 = inttoptr i64 %v4576 to ptr
  %rgep4578 = getelementptr i8, ptr %p4577, i64 -32
  store i64 %v4575, ptr %rgep4578, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear792
bb_rcgclear792:
  %v4579 = load i64, ptr %slot592, align 8
  %p4580 = inttoptr i64 %v4579 to ptr
  store i64 0, ptr %p4580, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone792
bb_rcgdone792:
  br label %bb_rcslotdone761
bb_rcslotdone761:
  %v4581 = load i64, ptr %slot19, align 8
  %p4582 = inttoptr i64 %v4581 to ptr
  %ld4583 = load i64, ptr %p4582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4583, ptr %slot623, align 8
  %v4584 = load i64, ptr %slot623, align 8
  %v4585 = load i64, ptr %slot25, align 8
  %p4586 = inttoptr i64 %v4585 to ptr
  store i64 %v4584, ptr %p4586, align 8, !alias.scope !3, !noalias !4
  %v4587 = load i64, ptr %slot25, align 8
  %p4588 = inttoptr i64 %v4587 to ptr
  %ld4589 = load i64, ptr %p4588, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4589, ptr %slot624, align 8
  %v4590 = load i64, ptr %slot624, align 8
  %op4591 = add i64 %v4590, 96
  store i64 %op4591, ptr %slot625, align 8
  %v4592 = load i64, ptr %slot625, align 8
  %p4593 = inttoptr i64 %v4592 to ptr
  %ld4594 = load i64, ptr %p4593, align 8
  store i64 %ld4594, ptr %slot626, align 8
  %v4595 = load i64, ptr %slot626, align 8
  %v4596 = load i64, ptr %slot25, align 8
  %p4597 = inttoptr i64 %v4596 to ptr
  store i64 %v4595, ptr %p4597, align 8, !alias.scope !3, !noalias !4
  %v4598 = load i64, ptr %slot11, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %ld4600 = load i32, ptr %p4599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4600, ptr %slot627, align 8
  %v4601 = load i32, ptr %slot627, align 8
  %cv4602 = zext i32 %v4601 to i64
  %cond4603 = icmp ne i64 %cv4602, 0
  br i1 %cond4603, label %bb_rcslotdrop802, label %bb_rcslotdone802
bb_rcslotdrop802:
  %v4604 = load i64, ptr %slot11, align 8
  %p4605 = inttoptr i64 %v4604 to ptr
  store i32 0, ptr %p4605, align 4, !alias.scope !3, !noalias !4
  %v4606 = load i64, ptr %slot15, align 8
  store i64 %v4606, ptr %slot628, align 8
  %v4607 = load i64, ptr %slot12, align 8
  %p4608 = inttoptr i64 %v4607 to ptr
  %ld4609 = load i32, ptr %p4608, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4609, ptr %slot629, align 8
  %v4610 = load i32, ptr %slot629, align 8
  %op4611 = and i32 %v4610, 28
  store i32 %op4611, ptr %slot630, align 8
  %v4612 = load i32, ptr %slot630, align 8
  %cv4613 = zext i32 %v4612 to i64
  %cond4614 = icmp ne i64 %cv4613, 0
  br i1 %cond4614, label %bb_rcslotrole802, label %bb_rcslotowner802
bb_rcslotrole802:
  %v4615 = load i64, ptr %slot31, align 8
  store i64 %v4615, ptr %slot631, align 8
  %v4616 = load i64, ptr %slot631, align 8
  %v4617 = load i64, ptr %slot628, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4616, i64 %v4617) nomerge, !dbg !132
  br label %bb_rcslotdone802
bb_rcslotowner802:
  %v4618 = load i64, ptr %slot31, align 8
  store i64 %v4618, ptr %slot632, align 8
  %v4619 = load i64, ptr %slot632, align 8
  %v4620 = load i64, ptr %slot628, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4619, i64 %v4620) nomerge, !dbg !132
  br label %bb_rcslotdone802
bb_rcslotdone802:
  %v4621 = load i64, ptr %slot25, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  %ld4623 = load i64, ptr %p4622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4623, ptr %slot633, align 8
  %v4624 = load i64, ptr %slot31, align 8
  %p4625 = inttoptr i64 %v4624 to ptr
  %v4626 = load i64, ptr %slot633, align 8
  %p4627 = inttoptr i64 %v4626 to ptr
  %call4628 = call ptr @myl_native_text_scalar(ptr %p4625, ptr %p4627, i32 0) nomerge, !dbg !134
  %calladdr4629 = ptrtoint ptr %call4628 to i64
  store i64 %calladdr4629, ptr %slot634, align 8
  %v4630 = load i64, ptr %slot634, align 8
  %cond4631 = icmp ne i64 %v4630, 0
  br i1 %cond4631, label %bb_success811, label %bb_failed811
bb_failed811:
  %v4632 = load i64, ptr %slot1, align 8
  %p4633 = inttoptr i64 %v4632 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4633) nomerge, !dbg !134
  unreachable
bb_success811:
  %v4634 = load i64, ptr %slot634, align 8
  %v4635 = load i64, ptr %slot25, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  store i64 %v4634, ptr %p4636, align 8, !alias.scope !3, !noalias !4
  %v4637 = load i64, ptr %slot25, align 8
  %p4638 = inttoptr i64 %v4637 to ptr
  %ld4639 = load i64, ptr %p4638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4639, ptr %slot635, align 8
  %v4640 = load i64, ptr %slot635, align 8
  %v4641 = load i64, ptr %slot16, align 8
  %p4642 = inttoptr i64 %v4641 to ptr
  store i64 %v4640, ptr %p4642, align 8, !alias.scope !3, !noalias !4
  %v4643 = load i64, ptr %slot16, align 8
  store i64 %v4643, ptr %slot636, align 8
  %v4644 = load i64, ptr %slot17, align 8
  store i64 %v4644, ptr %slot637, align 8
  %v4645 = load i64, ptr %slot636, align 8
  %v4646 = load i64, ptr %slot637, align 8
  %p4647 = inttoptr i64 %v4645 to ptr
  %p4648 = inttoptr i64 %v4646 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4648, ptr %p4647, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4649 = load i64, ptr %slot14, align 8
  %p4650 = inttoptr i64 %v4649 to ptr
  store i32 2, ptr %p4650, align 4, !alias.scope !3, !noalias !4
  %v4651 = load i64, ptr %slot13, align 8
  %p4652 = inttoptr i64 %v4651 to ptr
  store i32 1, ptr %p4652, align 4, !alias.scope !3, !noalias !4
  %v4653 = load i64, ptr %slot15, align 8
  store i64 %v4653, ptr %slot638, align 8
  %v4654 = load i64, ptr %slot17, align 8
  store i64 %v4654, ptr %slot639, align 8
  %v4655 = load i64, ptr %slot639, align 8
  %v4656 = load i64, ptr %slot638, align 8
  %p4657 = inttoptr i64 %v4655 to ptr
  %p4658 = inttoptr i64 %v4656 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4658, ptr %p4657, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4659 = load i64, ptr %slot12, align 8
  %p4660 = inttoptr i64 %v4659 to ptr
  store i32 2, ptr %p4660, align 4, !alias.scope !3, !noalias !4
  %v4661 = load i64, ptr %slot14, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %ld4663 = load i32, ptr %p4662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4663, ptr %slot640, align 8
  %v4664 = load i32, ptr %slot640, align 8
  %v4665 = load i64, ptr %slot12, align 8
  %p4666 = inttoptr i64 %v4665 to ptr
  store i32 %v4664, ptr %p4666, align 4, !alias.scope !3, !noalias !4
  %v4667 = load i64, ptr %slot13, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  store i32 0, ptr %p4668, align 4, !alias.scope !3, !noalias !4
  %v4669 = load i64, ptr %slot11, align 8
  %p4670 = inttoptr i64 %v4669 to ptr
  store i32 1, ptr %p4670, align 4, !alias.scope !3, !noalias !4
  %v4671 = load i64, ptr %slot638, align 8
  %p4672 = inttoptr i64 %v4671 to ptr
  %ld4673 = load i64, ptr %p4672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4673, ptr %slot641, align 8
  %v4674 = load i64, ptr %slot641, align 8
  %v4675 = load i64, ptr %slot25, align 8
  %p4676 = inttoptr i64 %v4675 to ptr
  store i64 %v4674, ptr %p4676, align 8, !alias.scope !3, !noalias !4
  %v4677 = load i64, ptr %slot22, align 8
  store i64 %v4677, ptr %slot642, align 8
  %v4678 = load i64, ptr %slot6, align 8
  %p4679 = inttoptr i64 %v4678 to ptr
  %ld4680 = load i32, ptr %p4679, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4680, ptr %slot643, align 8
  %v4681 = load i32, ptr %slot643, align 8
  %cmp4682 = icmp eq i32 %v4681, 16
  %cv4683 = zext i1 %cmp4682 to i32
  store i32 %cv4683, ptr %slot644, align 8
  %v4684 = load i64, ptr %slot5, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  %ld4686 = load i32, ptr %p4685, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4686, ptr %slot645, align 8
  %v4687 = load i32, ptr %slot645, align 8
  %v4688 = load i32, ptr %slot644, align 8
  %op4689 = and i32 %v4687, %v4688
  store i32 %op4689, ptr %slot646, align 8
  %v4690 = load i32, ptr %slot646, align 8
  %cv4691 = zext i32 %v4690 to i64
  %cond4692 = icmp ne i64 %cv4691, 0
  br i1 %cond4692, label %bb_rcownlocal832, label %bb_rcownedlocal832
bb_rcownlocal832:
  %v4693 = load i64, ptr %slot22, align 8
  store i64 %v4693, ptr %slot647, align 8
  %v4694 = load i64, ptr %slot17, align 8
  store i64 %v4694, ptr %slot648, align 8
  %v4695 = load i64, ptr %slot32, align 8
  store i64 %v4695, ptr %slot649, align 8
  %v4696 = load i64, ptr %slot647, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  %ld4698 = load i64, ptr %p4697, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4698, ptr %slot650, align 8
  %v4699 = load i64, ptr %slot650, align 8
  %cmp4700 = icmp ne i64 %v4699, 0
  %cv4701 = zext i1 %cmp4700 to i32
  store i32 %cv4701, ptr %slot651, align 8
  %v4702 = load i32, ptr %slot651, align 8
  %cv4703 = zext i32 %v4702 to i64
  %cond4704 = icmp ne i64 %cv4703, 0
  br i1 %cond4704, label %bb_rcgnn839, label %bb_rcgplain839
bb_rcgnn839:
  %v4705 = load i64, ptr %slot650, align 8
  %op4706 = sub i64 %v4705, 16
  store i64 %op4706, ptr %slot652, align 8
  %v4707 = load i64, ptr %slot650, align 8
  %p4708 = inttoptr i64 %v4707 to ptr
  %rgep4709 = getelementptr i8, ptr %p4708, i64 -16
  %ld4710 = load i64, ptr %rgep4709, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4710, ptr %slot653, align 8
  %v4711 = load i64, ptr %slot653, align 8
  %op4712 = and i64 %v4711, 4611686018427387906
  store i64 %op4712, ptr %slot654, align 8
  %v4713 = load i64, ptr %slot654, align 8
  %cmp4714 = icmp ne i64 %v4713, 0
  %cv4715 = zext i1 %cmp4714 to i32
  store i32 %cv4715, ptr %slot655, align 8
  %v4716 = load i32, ptr %slot655, align 8
  %cv4717 = zext i32 %v4716 to i64
  %cond4718 = icmp ne i64 %cv4717, 0
  br i1 %cond4718, label %bb_rcgspecial839, label %bb_rcginc839
bb_rcginc839:
  %v4719 = load i64, ptr %slot650, align 8
  %op4720 = sub i64 %v4719, 32
  store i64 %op4720, ptr %slot656, align 8
  %v4721 = load i64, ptr %slot650, align 8
  %p4722 = inttoptr i64 %v4721 to ptr
  %rgep4723 = getelementptr i8, ptr %p4722, i64 -32
  %ld4724 = load i64, ptr %rgep4723, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4724, ptr %slot657, align 8
  %v4725 = load i64, ptr %slot657, align 8
  %op4726 = add i64 %v4725, 1
  store i64 %op4726, ptr %slot658, align 8
  %v4727 = load i64, ptr %slot658, align 8
  %cmp4728 = icmp eq i64 %v4727, 0
  %cv4729 = zext i1 %cmp4728 to i32
  store i32 %cv4729, ptr %slot659, align 8
  %v4730 = load i32, ptr %slot659, align 8
  %cv4731 = zext i32 %v4730 to i64
  %cond4732 = icmp ne i64 %cv4731, 0
  br i1 %cond4732, label %bb_rcglimit839, label %bb_rcgcapacity839
bb_rcglimit839:
  %v4733 = load i64, ptr %slot1, align 8
  %p4734 = inttoptr i64 %v4733 to ptr
  %call4735 = call i32 @myl_qbe_rc_status(ptr %p4734, i32 2) nomerge, !dbg !136
  store i32 %call4735, ptr %slot660, align 8
  br label %bb_failure
bb_rcgcapacity839:
  %v4736 = load i64, ptr %slot658, align 8
  %v4737 = load i64, ptr %slot650, align 8
  %p4738 = inttoptr i64 %v4737 to ptr
  %rgep4739 = getelementptr i8, ptr %p4738, i64 -32
  store i64 %v4736, ptr %rgep4739, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain839
bb_rcgspecial839:
  %v4740 = load i64, ptr %slot653, align 8
  %op4741 = and i64 %v4740, 4611686018427387904
  store i64 %op4741, ptr %slot661, align 8
  %v4742 = load i64, ptr %slot661, align 8
  %cmp4743 = icmp ne i64 %v4742, 0
  %cv4744 = zext i1 %cmp4743 to i32
  store i32 %cv4744, ptr %slot662, align 8
  %v4745 = load i32, ptr %slot662, align 8
  %cv4746 = zext i32 %v4745 to i64
  %cond4747 = icmp ne i64 %cv4746, 0
  br i1 %cond4747, label %bb_rcgslow839, label %bb_rcgplain839
bb_rcgslow839:
  %v4748 = load i64, ptr %slot31, align 8
  %v4749 = load i64, ptr %slot648, align 8
  %v4750 = load i64, ptr %slot647, align 8
  %v4751 = load i64, ptr %slot649, align 8
  %cv4752 = trunc i64 %v4751 to i32
  %call4753 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v4748, i64 %v4749, i64 %v4750, i32 %cv4752) nomerge, !dbg !136
  store i32 %call4753, ptr %slot663, align 8
  %v4754 = load i32, ptr %slot663, align 8
  %cv4755 = zext i32 %v4754 to i64
  %cond4756 = icmp ne i64 %cv4755, 0
  br i1 %cond4756, label %bb_rcsuccess853, label %bb_rcfailure853
bb_rcfailure853:
  %v4757 = load i64, ptr %slot31, align 8
  %p4758 = inttoptr i64 %v4757 to ptr
  %call4759 = call i32 @myl_rc_take_failure(ptr %p4758) nomerge, !dbg !136
  store i32 %call4759, ptr %slot664, align 8
  %v4760 = load i64, ptr %slot1, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  %v4762 = load i32, ptr %slot664, align 8
  %call4763 = call i32 @myl_qbe_rc_status(ptr %p4761, i32 %v4762) nomerge, !dbg !136
  store i32 %call4763, ptr %slot665, align 8
  br label %bb_failure
bb_rcsuccess853:
  br label %bb_rcgdone839
bb_rcgplain839:
  %v4764 = load i64, ptr %slot650, align 8
  %v4765 = load i64, ptr %slot648, align 8
  %p4766 = inttoptr i64 %v4765 to ptr
  store i64 %v4764, ptr %p4766, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone839
bb_rcgdone839:
  %v4767 = load i64, ptr %slot14, align 8
  %p4768 = inttoptr i64 %v4767 to ptr
  store i32 2, ptr %p4768, align 4, !alias.scope !3, !noalias !4
  %v4769 = load i64, ptr %slot13, align 8
  %p4770 = inttoptr i64 %v4769 to ptr
  store i32 1, ptr %p4770, align 4, !alias.scope !3, !noalias !4
  %v4771 = load i64, ptr %slot5, align 8
  %p4772 = inttoptr i64 %v4771 to ptr
  %ld4773 = load i32, ptr %p4772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4773, ptr %slot666, align 8
  %v4774 = load i32, ptr %slot666, align 8
  %cv4775 = zext i32 %v4774 to i64
  %cond4776 = icmp ne i64 %cv4775, 0
  br i1 %cond4776, label %bb_rcslotdrop860, label %bb_rcslotdone860
bb_rcslotdrop860:
  %v4777 = load i64, ptr %slot5, align 8
  %p4778 = inttoptr i64 %v4777 to ptr
  store i32 0, ptr %p4778, align 4, !alias.scope !3, !noalias !4
  %v4779 = load i64, ptr %slot22, align 8
  store i64 %v4779, ptr %slot667, align 8
  %v4780 = load i64, ptr %slot6, align 8
  %p4781 = inttoptr i64 %v4780 to ptr
  %ld4782 = load i32, ptr %p4781, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4782, ptr %slot668, align 8
  %v4783 = load i32, ptr %slot668, align 8
  %op4784 = and i32 %v4783, 28
  store i32 %op4784, ptr %slot669, align 8
  %v4785 = load i32, ptr %slot669, align 8
  %cv4786 = zext i32 %v4785 to i64
  %cond4787 = icmp ne i64 %cv4786, 0
  br i1 %cond4787, label %bb_rcslotrole860, label %bb_rcslotowner860
bb_rcslotrole860:
  %v4788 = load i64, ptr %slot31, align 8
  store i64 %v4788, ptr %slot670, align 8
  %v4789 = load i64, ptr %slot667, align 8
  %p4790 = inttoptr i64 %v4789 to ptr
  %ld4791 = load i64, ptr %p4790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4791, ptr %slot671, align 8
  %v4792 = load i64, ptr %slot671, align 8
  %cmp4793 = icmp ne i64 %v4792, 0
  %cv4794 = zext i1 %cmp4793 to i32
  store i32 %cv4794, ptr %slot672, align 8
  %v4795 = load i32, ptr %slot672, align 8
  %cv4796 = zext i32 %v4795 to i64
  %cond4797 = icmp ne i64 %cv4796, 0
  br i1 %cond4797, label %bb_rcgnn876, label %bb_rcgdone876
bb_rcgnn876:
  %v4798 = load i64, ptr %slot671, align 8
  %op4799 = sub i64 %v4798, 16
  store i64 %op4799, ptr %slot673, align 8
  %v4800 = load i64, ptr %slot671, align 8
  %p4801 = inttoptr i64 %v4800 to ptr
  %rgep4802 = getelementptr i8, ptr %p4801, i64 -16
  %ld4803 = load i64, ptr %rgep4802, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4803, ptr %slot674, align 8
  %v4804 = load i64, ptr %slot674, align 8
  %op4805 = and i64 %v4804, 4611686018427387906
  store i64 %op4805, ptr %slot675, align 8
  %v4806 = load i64, ptr %slot675, align 8
  %cmp4807 = icmp ne i64 %v4806, 0
  %cv4808 = zext i1 %cmp4807 to i32
  store i32 %cv4808, ptr %slot676, align 8
  %v4809 = load i32, ptr %slot676, align 8
  %cv4810 = zext i32 %v4809 to i64
  %cond4811 = icmp ne i64 %cv4810, 0
  br i1 %cond4811, label %bb_rcgclear876, label %bb_rcgcounted876
bb_rcgcounted876:
  %v4812 = load i64, ptr %slot671, align 8
  %op4813 = sub i64 %v4812, 24
  store i64 %op4813, ptr %slot677, align 8
  %v4814 = load i64, ptr %slot671, align 8
  %p4815 = inttoptr i64 %v4814 to ptr
  %rgep4816 = getelementptr i8, ptr %p4815, i64 -24
  %ld4817 = load i64, ptr %rgep4816, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4817, ptr %slot678, align 8
  %v4818 = load i64, ptr %slot678, align 8
  %op4819 = sub i64 %v4818, 1
  store i64 %op4819, ptr %slot679, align 8
  %v4820 = load i64, ptr %slot679, align 8
  %cmp4821 = icmp eq i64 %v4820, 0
  %cv4822 = zext i1 %cmp4821 to i32
  store i32 %cv4822, ptr %slot680, align 8
  %v4823 = load i32, ptr %slot680, align 8
  %cv4824 = zext i32 %v4823 to i64
  %cond4825 = icmp ne i64 %cv4824, 0
  br i1 %cond4825, label %bb_rcglast876, label %bb_rcgdec876
bb_rcglast876:
  %v4826 = load i64, ptr %slot671, align 8
  %op4827 = sub i64 %v4826, 32
  store i64 %op4827, ptr %slot681, align 8
  %v4828 = load i64, ptr %slot671, align 8
  %p4829 = inttoptr i64 %v4828 to ptr
  %rgep4830 = getelementptr i8, ptr %p4829, i64 -32
  %ld4831 = load i64, ptr %rgep4830, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4831, ptr %slot682, align 8
  %v4832 = load i64, ptr %slot682, align 8
  %cmp4833 = icmp ne i64 %v4832, 0
  %cv4834 = zext i1 %cmp4833 to i32
  store i32 %cv4834, ptr %slot683, align 8
  %v4835 = load i32, ptr %slot683, align 8
  %cv4836 = zext i32 %v4835 to i64
  %cond4837 = icmp ne i64 %cv4836, 0
  br i1 %cond4837, label %bb_rcgdec876, label %bb_rcgslow876
bb_rcgslow876:
  %v4838 = load i64, ptr %slot670, align 8
  %v4839 = load i64, ptr %slot667, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v4838, i64 %v4839) nomerge, !dbg !136
  br label %bb_rcgdone876
bb_rcgdec876:
  %v4840 = load i64, ptr %slot679, align 8
  %v4841 = load i64, ptr %slot671, align 8
  %p4842 = inttoptr i64 %v4841 to ptr
  %rgep4843 = getelementptr i8, ptr %p4842, i64 -24
  store i64 %v4840, ptr %rgep4843, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear876
bb_rcgclear876:
  %v4844 = load i64, ptr %slot667, align 8
  %p4845 = inttoptr i64 %v4844 to ptr
  store i64 0, ptr %p4845, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone876
bb_rcgdone876:
  br label %bb_rcslotdone860
bb_rcslotowner860:
  %v4846 = load i64, ptr %slot31, align 8
  store i64 %v4846, ptr %slot684, align 8
  %v4847 = load i64, ptr %slot667, align 8
  %p4848 = inttoptr i64 %v4847 to ptr
  %ld4849 = load i64, ptr %p4848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4849, ptr %slot685, align 8
  %v4850 = load i64, ptr %slot685, align 8
  %cmp4851 = icmp ne i64 %v4850, 0
  %cv4852 = zext i1 %cmp4851 to i32
  store i32 %cv4852, ptr %slot686, align 8
  %v4853 = load i32, ptr %slot686, align 8
  %cv4854 = zext i32 %v4853 to i64
  %cond4855 = icmp ne i64 %cv4854, 0
  br i1 %cond4855, label %bb_rcgnn891, label %bb_rcgdone891
bb_rcgnn891:
  %v4856 = load i64, ptr %slot685, align 8
  %op4857 = sub i64 %v4856, 16
  store i64 %op4857, ptr %slot687, align 8
  %v4858 = load i64, ptr %slot685, align 8
  %p4859 = inttoptr i64 %v4858 to ptr
  %rgep4860 = getelementptr i8, ptr %p4859, i64 -16
  %ld4861 = load i64, ptr %rgep4860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4861, ptr %slot688, align 8
  %v4862 = load i64, ptr %slot688, align 8
  %op4863 = and i64 %v4862, 4611686018427387906
  store i64 %op4863, ptr %slot689, align 8
  %v4864 = load i64, ptr %slot689, align 8
  %cmp4865 = icmp ne i64 %v4864, 0
  %cv4866 = zext i1 %cmp4865 to i32
  store i32 %cv4866, ptr %slot690, align 8
  %v4867 = load i32, ptr %slot690, align 8
  %cv4868 = zext i32 %v4867 to i64
  %cond4869 = icmp ne i64 %cv4868, 0
  br i1 %cond4869, label %bb_rcgclear891, label %bb_rcgcounted891
bb_rcgcounted891:
  %v4870 = load i64, ptr %slot685, align 8
  %op4871 = sub i64 %v4870, 32
  store i64 %op4871, ptr %slot691, align 8
  %v4872 = load i64, ptr %slot685, align 8
  %p4873 = inttoptr i64 %v4872 to ptr
  %rgep4874 = getelementptr i8, ptr %p4873, i64 -32
  %ld4875 = load i64, ptr %rgep4874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4875, ptr %slot692, align 8
  %v4876 = load i64, ptr %slot692, align 8
  %op4877 = sub i64 %v4876, 1
  store i64 %op4877, ptr %slot693, align 8
  %v4878 = load i64, ptr %slot693, align 8
  %cmp4879 = icmp eq i64 %v4878, 0
  %cv4880 = zext i1 %cmp4879 to i32
  store i32 %cv4880, ptr %slot694, align 8
  %v4881 = load i32, ptr %slot694, align 8
  %cv4882 = zext i32 %v4881 to i64
  %cond4883 = icmp ne i64 %cv4882, 0
  br i1 %cond4883, label %bb_rcglast891, label %bb_rcgdec891
bb_rcglast891:
  %v4884 = load i64, ptr %slot685, align 8
  %op4885 = sub i64 %v4884, 24
  store i64 %op4885, ptr %slot695, align 8
  %v4886 = load i64, ptr %slot685, align 8
  %p4887 = inttoptr i64 %v4886 to ptr
  %rgep4888 = getelementptr i8, ptr %p4887, i64 -24
  %ld4889 = load i64, ptr %rgep4888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4889, ptr %slot696, align 8
  %v4890 = load i64, ptr %slot696, align 8
  %cmp4891 = icmp ne i64 %v4890, 0
  %cv4892 = zext i1 %cmp4891 to i32
  store i32 %cv4892, ptr %slot697, align 8
  %v4893 = load i32, ptr %slot697, align 8
  %cv4894 = zext i32 %v4893 to i64
  %cond4895 = icmp ne i64 %cv4894, 0
  br i1 %cond4895, label %bb_rcgdec891, label %bb_rcgslow891
bb_rcgslow891:
  %v4896 = load i64, ptr %slot684, align 8
  %v4897 = load i64, ptr %slot667, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v4896, i64 %v4897) nomerge, !dbg !136
  br label %bb_rcgdone891
bb_rcgdec891:
  %v4898 = load i64, ptr %slot693, align 8
  %v4899 = load i64, ptr %slot685, align 8
  %p4900 = inttoptr i64 %v4899 to ptr
  %rgep4901 = getelementptr i8, ptr %p4900, i64 -32
  store i64 %v4898, ptr %rgep4901, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear891
bb_rcgclear891:
  %v4902 = load i64, ptr %slot667, align 8
  %p4903 = inttoptr i64 %v4902 to ptr
  store i64 0, ptr %p4903, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone891
bb_rcgdone891:
  br label %bb_rcslotdone860
bb_rcslotdone860:
  %v4904 = load i64, ptr %slot17, align 8
  store i64 %v4904, ptr %slot698, align 8
  %v4905 = load i64, ptr %slot698, align 8
  %v4906 = load i64, ptr %slot647, align 8
  %p4907 = inttoptr i64 %v4905 to ptr
  %p4908 = inttoptr i64 %v4906 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4908, ptr %p4907, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4909 = load i64, ptr %slot6, align 8
  %p4910 = inttoptr i64 %v4909 to ptr
  store i32 2, ptr %p4910, align 4, !alias.scope !3, !noalias !4
  %v4911 = load i64, ptr %slot5, align 8
  %p4912 = inttoptr i64 %v4911 to ptr
  store i32 1, ptr %p4912, align 4, !alias.scope !3, !noalias !4
  %v4913 = load i64, ptr %slot13, align 8
  %p4914 = inttoptr i64 %v4913 to ptr
  store i32 0, ptr %p4914, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal832
bb_rcownedlocal832:
  %v4915 = load i64, ptr %slot6, align 8
  %p4916 = inttoptr i64 %v4915 to ptr
  store i32 2, ptr %p4916, align 4, !alias.scope !3, !noalias !4
  %v4917 = load i64, ptr %slot642, align 8
  %p4918 = inttoptr i64 %v4917 to ptr
  %ld4919 = load i64, ptr %p4918, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4919, ptr %slot699, align 8
  %v4920 = load i64, ptr %slot699, align 8
  %cmp4921 = icmp ne i64 %v4920, 0
  %cv4922 = zext i1 %cmp4921 to i32
  store i32 %cv4922, ptr %slot700, align 8
  %v4923 = load i32, ptr %slot700, align 8
  %cv4924 = zext i32 %v4923 to i64
  %cond4925 = icmp ne i64 %cv4924, 0
  br i1 %cond4925, label %bb_rcguniquenn900, label %bb_rcgunique900
bb_rcguniquenn900:
  %v4926 = load i64, ptr %slot699, align 8
  %op4927 = sub i64 %v4926, 16
  store i64 %op4927, ptr %slot701, align 8
  %v4928 = load i64, ptr %slot699, align 8
  %p4929 = inttoptr i64 %v4928 to ptr
  %rgep4930 = getelementptr i8, ptr %p4929, i64 -16
  %ld4931 = load i64, ptr %rgep4930, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4931, ptr %slot702, align 8
  %v4932 = load i64, ptr %slot702, align 8
  %op4933 = and i64 %v4932, 6917529027641081858
  store i64 %op4933, ptr %slot703, align 8
  %v4934 = load i64, ptr %slot703, align 8
  %cmp4935 = icmp ne i64 %v4934, 0
  %cv4936 = zext i1 %cmp4935 to i32
  store i32 %cv4936, ptr %slot704, align 8
  %v4937 = load i32, ptr %slot704, align 8
  %cv4938 = zext i32 %v4937 to i64
  %cond4939 = icmp ne i64 %cv4938, 0
  br i1 %cond4939, label %bb_rcguniqueslow900, label %bb_rcguniquecount900
bb_rcguniquecount900:
  %v4940 = load i64, ptr %slot699, align 8
  %op4941 = sub i64 %v4940, 32
  store i64 %op4941, ptr %slot705, align 8
  %v4942 = load i64, ptr %slot699, align 8
  %p4943 = inttoptr i64 %v4942 to ptr
  %rgep4944 = getelementptr i8, ptr %p4943, i64 -32
  %ld4945 = load i64, ptr %rgep4944, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4945, ptr %slot706, align 8
  %v4946 = load i64, ptr %slot706, align 8
  %cmp4947 = icmp ult i64 %v4946, 2
  %cv4948 = zext i1 %cmp4947 to i32
  store i32 %cv4948, ptr %slot707, align 8
  %v4949 = load i32, ptr %slot707, align 8
  %cv4950 = zext i32 %v4949 to i64
  %cond4951 = icmp ne i64 %cv4950, 0
  br i1 %cond4951, label %bb_rcgunique900, label %bb_rcguniqueslow900
bb_rcguniqueslow900:
  %v4952 = load i64, ptr %slot1, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %p4954 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v4955 = load i64, ptr %slot642, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  %v4957 = load i64, ptr %slot5, align 8
  %p4958 = inttoptr i64 %v4957 to ptr
  %call4959 = call i32 @myl_qbe_rc_unique_local(ptr %p4953, ptr %p4954, ptr %p4956, ptr %p4958) nomerge, !dbg !136
  store i32 %call4959, ptr %slot708, align 8
  %v4960 = load i32, ptr %slot708, align 8
  %cv4961 = zext i32 %v4960 to i64
  %cond4962 = icmp ne i64 %cv4961, 0
  br i1 %cond4962, label %bb_rcunique911, label %bb_failure
bb_rcunique911:
  br label %bb_rcgunique900
bb_rcgunique900:
  %v4963 = load i64, ptr %slot22, align 8
  %p4964 = inttoptr i64 %v4963 to ptr
  %ld4965 = load i64, ptr %p4964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4965, ptr %slot709, align 8
  %v4966 = load i64, ptr %slot25, align 8
  store i64 %v4966, ptr %slot710, align 8
  %v4967 = load i64, ptr %slot710, align 8
  %p4968 = inttoptr i64 %v4967 to ptr
  %ld4969 = load i64, ptr %p4968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4969, ptr %slot711, align 8
  %v4970 = load i64, ptr %slot711, align 8
  %v4971 = load i64, ptr %slot18, align 8
  %p4972 = inttoptr i64 %v4971 to ptr
  store i64 %v4970, ptr %p4972, align 8, !alias.scope !3, !noalias !4
  %v4973 = load i64, ptr %slot18, align 8
  store i64 %v4973, ptr %slot712, align 8
  %v4974 = load i64, ptr %slot31, align 8
  %v4975 = load i64, ptr %slot709, align 8
  %v4976 = load i64, ptr %slot712, align 8
  %call4977 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v4974, i64 %v4975, i64 %v4976) nomerge, !dbg !136
  store i32 %call4977, ptr %slot713, align 8
  %v4978 = load i32, ptr %slot713, align 8
  %cv4979 = zext i32 %v4978 to i64
  %cond4980 = icmp ne i64 %cv4979, 0
  br i1 %cond4980, label %bb_success917, label %bb_failed917
bb_failed917:
  %v4981 = load i64, ptr %slot1, align 8
  %p4982 = inttoptr i64 %v4981 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4982) nomerge, !dbg !136
  unreachable
bb_success917:
  %v4983 = load i64, ptr %slot25, align 8
  %p4984 = inttoptr i64 %v4983 to ptr
  store i64 0, ptr %p4984, align 8, !alias.scope !3, !noalias !4
  %v4985 = load i64, ptr %slot11, align 8
  %p4986 = inttoptr i64 %v4985 to ptr
  %ld4987 = load i32, ptr %p4986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4987, ptr %slot714, align 8
  %v4988 = load i32, ptr %slot714, align 8
  %cv4989 = zext i32 %v4988 to i64
  %cond4990 = icmp ne i64 %cv4989, 0
  br i1 %cond4990, label %bb_rcslotdrop920, label %bb_rcslotdone920
bb_rcslotdrop920:
  %v4991 = load i64, ptr %slot11, align 8
  %p4992 = inttoptr i64 %v4991 to ptr
  store i32 0, ptr %p4992, align 4, !alias.scope !3, !noalias !4
  %v4993 = load i64, ptr %slot15, align 8
  store i64 %v4993, ptr %slot715, align 8
  %v4994 = load i64, ptr %slot12, align 8
  %p4995 = inttoptr i64 %v4994 to ptr
  %ld4996 = load i32, ptr %p4995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4996, ptr %slot716, align 8
  %v4997 = load i32, ptr %slot716, align 8
  %op4998 = and i32 %v4997, 28
  store i32 %op4998, ptr %slot717, align 8
  %v4999 = load i32, ptr %slot717, align 8
  %cv5000 = zext i32 %v4999 to i64
  %cond5001 = icmp ne i64 %cv5000, 0
  br i1 %cond5001, label %bb_rcslotrole920, label %bb_rcslotowner920
bb_rcslotrole920:
  %v5002 = load i64, ptr %slot31, align 8
  store i64 %v5002, ptr %slot718, align 8
  %v5003 = load i64, ptr %slot715, align 8
  %p5004 = inttoptr i64 %v5003 to ptr
  %ld5005 = load i64, ptr %p5004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5005, ptr %slot719, align 8
  %v5006 = load i64, ptr %slot719, align 8
  %cmp5007 = icmp ne i64 %v5006, 0
  %cv5008 = zext i1 %cmp5007 to i32
  store i32 %cv5008, ptr %slot720, align 8
  %v5009 = load i32, ptr %slot720, align 8
  %cv5010 = zext i32 %v5009 to i64
  %cond5011 = icmp ne i64 %cv5010, 0
  br i1 %cond5011, label %bb_rcgnn936, label %bb_rcgdone936
bb_rcgnn936:
  %v5012 = load i64, ptr %slot719, align 8
  %op5013 = sub i64 %v5012, 16
  store i64 %op5013, ptr %slot721, align 8
  %v5014 = load i64, ptr %slot719, align 8
  %p5015 = inttoptr i64 %v5014 to ptr
  %rgep5016 = getelementptr i8, ptr %p5015, i64 -16
  %ld5017 = load i64, ptr %rgep5016, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5017, ptr %slot722, align 8
  %v5018 = load i64, ptr %slot722, align 8
  %op5019 = and i64 %v5018, 4611686018427387906
  store i64 %op5019, ptr %slot723, align 8
  %v5020 = load i64, ptr %slot723, align 8
  %cmp5021 = icmp ne i64 %v5020, 0
  %cv5022 = zext i1 %cmp5021 to i32
  store i32 %cv5022, ptr %slot724, align 8
  %v5023 = load i32, ptr %slot724, align 8
  %cv5024 = zext i32 %v5023 to i64
  %cond5025 = icmp ne i64 %cv5024, 0
  br i1 %cond5025, label %bb_rcgclear936, label %bb_rcgcounted936
bb_rcgcounted936:
  %v5026 = load i64, ptr %slot719, align 8
  %op5027 = sub i64 %v5026, 24
  store i64 %op5027, ptr %slot725, align 8
  %v5028 = load i64, ptr %slot719, align 8
  %p5029 = inttoptr i64 %v5028 to ptr
  %rgep5030 = getelementptr i8, ptr %p5029, i64 -24
  %ld5031 = load i64, ptr %rgep5030, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5031, ptr %slot726, align 8
  %v5032 = load i64, ptr %slot726, align 8
  %op5033 = sub i64 %v5032, 1
  store i64 %op5033, ptr %slot727, align 8
  %v5034 = load i64, ptr %slot727, align 8
  %cmp5035 = icmp eq i64 %v5034, 0
  %cv5036 = zext i1 %cmp5035 to i32
  store i32 %cv5036, ptr %slot728, align 8
  %v5037 = load i32, ptr %slot728, align 8
  %cv5038 = zext i32 %v5037 to i64
  %cond5039 = icmp ne i64 %cv5038, 0
  br i1 %cond5039, label %bb_rcglast936, label %bb_rcgdec936
bb_rcglast936:
  %v5040 = load i64, ptr %slot719, align 8
  %op5041 = sub i64 %v5040, 32
  store i64 %op5041, ptr %slot729, align 8
  %v5042 = load i64, ptr %slot719, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  %rgep5044 = getelementptr i8, ptr %p5043, i64 -32
  %ld5045 = load i64, ptr %rgep5044, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5045, ptr %slot730, align 8
  %v5046 = load i64, ptr %slot730, align 8
  %cmp5047 = icmp ne i64 %v5046, 0
  %cv5048 = zext i1 %cmp5047 to i32
  store i32 %cv5048, ptr %slot731, align 8
  %v5049 = load i32, ptr %slot731, align 8
  %cv5050 = zext i32 %v5049 to i64
  %cond5051 = icmp ne i64 %cv5050, 0
  br i1 %cond5051, label %bb_rcgdec936, label %bb_rcgslow936
bb_rcgslow936:
  %v5052 = load i64, ptr %slot718, align 8
  %v5053 = load i64, ptr %slot715, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5052, i64 %v5053) nomerge, !dbg !136
  br label %bb_rcgdone936
bb_rcgdec936:
  %v5054 = load i64, ptr %slot727, align 8
  %v5055 = load i64, ptr %slot719, align 8
  %p5056 = inttoptr i64 %v5055 to ptr
  %rgep5057 = getelementptr i8, ptr %p5056, i64 -24
  store i64 %v5054, ptr %rgep5057, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear936
bb_rcgclear936:
  %v5058 = load i64, ptr %slot715, align 8
  %p5059 = inttoptr i64 %v5058 to ptr
  store i64 0, ptr %p5059, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone936
bb_rcgdone936:
  br label %bb_rcslotdone920
bb_rcslotowner920:
  %v5060 = load i64, ptr %slot31, align 8
  store i64 %v5060, ptr %slot732, align 8
  %v5061 = load i64, ptr %slot715, align 8
  %p5062 = inttoptr i64 %v5061 to ptr
  %ld5063 = load i64, ptr %p5062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5063, ptr %slot733, align 8
  %v5064 = load i64, ptr %slot733, align 8
  %cmp5065 = icmp ne i64 %v5064, 0
  %cv5066 = zext i1 %cmp5065 to i32
  store i32 %cv5066, ptr %slot734, align 8
  %v5067 = load i32, ptr %slot734, align 8
  %cv5068 = zext i32 %v5067 to i64
  %cond5069 = icmp ne i64 %cv5068, 0
  br i1 %cond5069, label %bb_rcgnn951, label %bb_rcgdone951
bb_rcgnn951:
  %v5070 = load i64, ptr %slot733, align 8
  %op5071 = sub i64 %v5070, 16
  store i64 %op5071, ptr %slot735, align 8
  %v5072 = load i64, ptr %slot733, align 8
  %p5073 = inttoptr i64 %v5072 to ptr
  %rgep5074 = getelementptr i8, ptr %p5073, i64 -16
  %ld5075 = load i64, ptr %rgep5074, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5075, ptr %slot736, align 8
  %v5076 = load i64, ptr %slot736, align 8
  %op5077 = and i64 %v5076, 4611686018427387906
  store i64 %op5077, ptr %slot737, align 8
  %v5078 = load i64, ptr %slot737, align 8
  %cmp5079 = icmp ne i64 %v5078, 0
  %cv5080 = zext i1 %cmp5079 to i32
  store i32 %cv5080, ptr %slot738, align 8
  %v5081 = load i32, ptr %slot738, align 8
  %cv5082 = zext i32 %v5081 to i64
  %cond5083 = icmp ne i64 %cv5082, 0
  br i1 %cond5083, label %bb_rcgclear951, label %bb_rcgcounted951
bb_rcgcounted951:
  %v5084 = load i64, ptr %slot733, align 8
  %op5085 = sub i64 %v5084, 32
  store i64 %op5085, ptr %slot739, align 8
  %v5086 = load i64, ptr %slot733, align 8
  %p5087 = inttoptr i64 %v5086 to ptr
  %rgep5088 = getelementptr i8, ptr %p5087, i64 -32
  %ld5089 = load i64, ptr %rgep5088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5089, ptr %slot740, align 8
  %v5090 = load i64, ptr %slot740, align 8
  %op5091 = sub i64 %v5090, 1
  store i64 %op5091, ptr %slot741, align 8
  %v5092 = load i64, ptr %slot741, align 8
  %cmp5093 = icmp eq i64 %v5092, 0
  %cv5094 = zext i1 %cmp5093 to i32
  store i32 %cv5094, ptr %slot742, align 8
  %v5095 = load i32, ptr %slot742, align 8
  %cv5096 = zext i32 %v5095 to i64
  %cond5097 = icmp ne i64 %cv5096, 0
  br i1 %cond5097, label %bb_rcglast951, label %bb_rcgdec951
bb_rcglast951:
  %v5098 = load i64, ptr %slot733, align 8
  %op5099 = sub i64 %v5098, 24
  store i64 %op5099, ptr %slot743, align 8
  %v5100 = load i64, ptr %slot733, align 8
  %p5101 = inttoptr i64 %v5100 to ptr
  %rgep5102 = getelementptr i8, ptr %p5101, i64 -24
  %ld5103 = load i64, ptr %rgep5102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5103, ptr %slot744, align 8
  %v5104 = load i64, ptr %slot744, align 8
  %cmp5105 = icmp ne i64 %v5104, 0
  %cv5106 = zext i1 %cmp5105 to i32
  store i32 %cv5106, ptr %slot745, align 8
  %v5107 = load i32, ptr %slot745, align 8
  %cv5108 = zext i32 %v5107 to i64
  %cond5109 = icmp ne i64 %cv5108, 0
  br i1 %cond5109, label %bb_rcgdec951, label %bb_rcgslow951
bb_rcgslow951:
  %v5110 = load i64, ptr %slot732, align 8
  %v5111 = load i64, ptr %slot715, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5110, i64 %v5111) nomerge, !dbg !136
  br label %bb_rcgdone951
bb_rcgdec951:
  %v5112 = load i64, ptr %slot741, align 8
  %v5113 = load i64, ptr %slot733, align 8
  %p5114 = inttoptr i64 %v5113 to ptr
  %rgep5115 = getelementptr i8, ptr %p5114, i64 -32
  store i64 %v5112, ptr %rgep5115, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear951
bb_rcgclear951:
  %v5116 = load i64, ptr %slot715, align 8
  %p5117 = inttoptr i64 %v5116 to ptr
  store i64 0, ptr %p5117, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone951
bb_rcgdone951:
  br label %bb_rcslotdone920
bb_rcslotdone920:
  %p5118 = inttoptr i64 ptrtoint (ptr @myl_lit_969454b6011418fe25ac5bacf7816bad5d3fa5fe2b6de6485748b195f0f1c065 to i64) to ptr
  %ld5119 = load i64, ptr %p5118, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5119, ptr %slot746, align 8
  %v5120 = load i64, ptr %slot746, align 8
  %v5121 = load i64, ptr %slot25, align 8
  %p5122 = inttoptr i64 %v5121 to ptr
  store i64 %v5120, ptr %p5122, align 8, !alias.scope !3, !noalias !4
  %v5123 = load i64, ptr %slot25, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  %ld5125 = load i64, ptr %p5124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5125, ptr %slot747, align 8
  %v5126 = load i64, ptr %slot747, align 8
  %v5127 = load i64, ptr %slot16, align 8
  %p5128 = inttoptr i64 %v5127 to ptr
  store i64 %v5126, ptr %p5128, align 8, !alias.scope !3, !noalias !4
  %v5129 = load i64, ptr %slot16, align 8
  store i64 %v5129, ptr %slot748, align 8
  %v5130 = load i64, ptr %slot17, align 8
  store i64 %v5130, ptr %slot749, align 8
  %v5131 = load i64, ptr %slot748, align 8
  %v5132 = load i64, ptr %slot749, align 8
  %p5133 = inttoptr i64 %v5131 to ptr
  %p5134 = inttoptr i64 %v5132 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5134, ptr %p5133, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5135 = load i64, ptr %slot14, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  store i32 2, ptr %p5136, align 4, !alias.scope !3, !noalias !4
  %v5137 = load i64, ptr %slot13, align 8
  %p5138 = inttoptr i64 %v5137 to ptr
  store i32 1, ptr %p5138, align 4, !alias.scope !3, !noalias !4
  %v5139 = load i64, ptr %slot15, align 8
  store i64 %v5139, ptr %slot750, align 8
  %v5140 = load i64, ptr %slot17, align 8
  store i64 %v5140, ptr %slot751, align 8
  %v5141 = load i64, ptr %slot751, align 8
  %v5142 = load i64, ptr %slot750, align 8
  %p5143 = inttoptr i64 %v5141 to ptr
  %p5144 = inttoptr i64 %v5142 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5144, ptr %p5143, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5145 = load i64, ptr %slot12, align 8
  %p5146 = inttoptr i64 %v5145 to ptr
  store i32 2, ptr %p5146, align 4, !alias.scope !3, !noalias !4
  %v5147 = load i64, ptr %slot14, align 8
  %p5148 = inttoptr i64 %v5147 to ptr
  %ld5149 = load i32, ptr %p5148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5149, ptr %slot752, align 8
  %v5150 = load i32, ptr %slot752, align 8
  %v5151 = load i64, ptr %slot12, align 8
  %p5152 = inttoptr i64 %v5151 to ptr
  store i32 %v5150, ptr %p5152, align 4, !alias.scope !3, !noalias !4
  %v5153 = load i64, ptr %slot13, align 8
  %p5154 = inttoptr i64 %v5153 to ptr
  store i32 0, ptr %p5154, align 4, !alias.scope !3, !noalias !4
  %v5155 = load i64, ptr %slot11, align 8
  %p5156 = inttoptr i64 %v5155 to ptr
  store i32 1, ptr %p5156, align 4, !alias.scope !3, !noalias !4
  %v5157 = load i64, ptr %slot750, align 8
  %p5158 = inttoptr i64 %v5157 to ptr
  %ld5159 = load i64, ptr %p5158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5159, ptr %slot753, align 8
  %v5160 = load i64, ptr %slot753, align 8
  %v5161 = load i64, ptr %slot25, align 8
  %p5162 = inttoptr i64 %v5161 to ptr
  store i64 %v5160, ptr %p5162, align 8, !alias.scope !3, !noalias !4
  %v5163 = load i64, ptr %slot22, align 8
  store i64 %v5163, ptr %slot754, align 8
  %v5164 = load i64, ptr %slot6, align 8
  %p5165 = inttoptr i64 %v5164 to ptr
  %ld5166 = load i32, ptr %p5165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5166, ptr %slot755, align 8
  %v5167 = load i32, ptr %slot755, align 8
  %cmp5168 = icmp eq i32 %v5167, 16
  %cv5169 = zext i1 %cmp5168 to i32
  store i32 %cv5169, ptr %slot756, align 8
  %v5170 = load i64, ptr %slot5, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  %ld5172 = load i32, ptr %p5171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5172, ptr %slot757, align 8
  %v5173 = load i32, ptr %slot757, align 8
  %v5174 = load i32, ptr %slot756, align 8
  %op5175 = and i32 %v5173, %v5174
  store i32 %op5175, ptr %slot758, align 8
  %v5176 = load i32, ptr %slot758, align 8
  %cv5177 = zext i32 %v5176 to i64
  %cond5178 = icmp ne i64 %cv5177, 0
  br i1 %cond5178, label %bb_rcownlocal977, label %bb_rcownedlocal977
bb_rcownlocal977:
  %v5179 = load i64, ptr %slot22, align 8
  store i64 %v5179, ptr %slot759, align 8
  %v5180 = load i64, ptr %slot17, align 8
  store i64 %v5180, ptr %slot760, align 8
  %v5181 = load i64, ptr %slot32, align 8
  store i64 %v5181, ptr %slot761, align 8
  %v5182 = load i64, ptr %slot759, align 8
  %p5183 = inttoptr i64 %v5182 to ptr
  %ld5184 = load i64, ptr %p5183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5184, ptr %slot762, align 8
  %v5185 = load i64, ptr %slot762, align 8
  %cmp5186 = icmp ne i64 %v5185, 0
  %cv5187 = zext i1 %cmp5186 to i32
  store i32 %cv5187, ptr %slot763, align 8
  %v5188 = load i32, ptr %slot763, align 8
  %cv5189 = zext i32 %v5188 to i64
  %cond5190 = icmp ne i64 %cv5189, 0
  br i1 %cond5190, label %bb_rcgnn984, label %bb_rcgplain984
bb_rcgnn984:
  %v5191 = load i64, ptr %slot762, align 8
  %op5192 = sub i64 %v5191, 16
  store i64 %op5192, ptr %slot764, align 8
  %v5193 = load i64, ptr %slot762, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  %rgep5195 = getelementptr i8, ptr %p5194, i64 -16
  %ld5196 = load i64, ptr %rgep5195, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5196, ptr %slot765, align 8
  %v5197 = load i64, ptr %slot765, align 8
  %op5198 = and i64 %v5197, 4611686018427387906
  store i64 %op5198, ptr %slot766, align 8
  %v5199 = load i64, ptr %slot766, align 8
  %cmp5200 = icmp ne i64 %v5199, 0
  %cv5201 = zext i1 %cmp5200 to i32
  store i32 %cv5201, ptr %slot767, align 8
  %v5202 = load i32, ptr %slot767, align 8
  %cv5203 = zext i32 %v5202 to i64
  %cond5204 = icmp ne i64 %cv5203, 0
  br i1 %cond5204, label %bb_rcgspecial984, label %bb_rcginc984
bb_rcginc984:
  %v5205 = load i64, ptr %slot762, align 8
  %op5206 = sub i64 %v5205, 32
  store i64 %op5206, ptr %slot768, align 8
  %v5207 = load i64, ptr %slot762, align 8
  %p5208 = inttoptr i64 %v5207 to ptr
  %rgep5209 = getelementptr i8, ptr %p5208, i64 -32
  %ld5210 = load i64, ptr %rgep5209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5210, ptr %slot769, align 8
  %v5211 = load i64, ptr %slot769, align 8
  %op5212 = add i64 %v5211, 1
  store i64 %op5212, ptr %slot770, align 8
  %v5213 = load i64, ptr %slot770, align 8
  %cmp5214 = icmp eq i64 %v5213, 0
  %cv5215 = zext i1 %cmp5214 to i32
  store i32 %cv5215, ptr %slot771, align 8
  %v5216 = load i32, ptr %slot771, align 8
  %cv5217 = zext i32 %v5216 to i64
  %cond5218 = icmp ne i64 %cv5217, 0
  br i1 %cond5218, label %bb_rcglimit984, label %bb_rcgcapacity984
bb_rcglimit984:
  %v5219 = load i64, ptr %slot1, align 8
  %p5220 = inttoptr i64 %v5219 to ptr
  %call5221 = call i32 @myl_qbe_rc_status(ptr %p5220, i32 2) nomerge, !dbg !138
  store i32 %call5221, ptr %slot772, align 8
  br label %bb_failure
bb_rcgcapacity984:
  %v5222 = load i64, ptr %slot770, align 8
  %v5223 = load i64, ptr %slot762, align 8
  %p5224 = inttoptr i64 %v5223 to ptr
  %rgep5225 = getelementptr i8, ptr %p5224, i64 -32
  store i64 %v5222, ptr %rgep5225, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain984
bb_rcgspecial984:
  %v5226 = load i64, ptr %slot765, align 8
  %op5227 = and i64 %v5226, 4611686018427387904
  store i64 %op5227, ptr %slot773, align 8
  %v5228 = load i64, ptr %slot773, align 8
  %cmp5229 = icmp ne i64 %v5228, 0
  %cv5230 = zext i1 %cmp5229 to i32
  store i32 %cv5230, ptr %slot774, align 8
  %v5231 = load i32, ptr %slot774, align 8
  %cv5232 = zext i32 %v5231 to i64
  %cond5233 = icmp ne i64 %cv5232, 0
  br i1 %cond5233, label %bb_rcgslow984, label %bb_rcgplain984
bb_rcgslow984:
  %v5234 = load i64, ptr %slot31, align 8
  %v5235 = load i64, ptr %slot760, align 8
  %v5236 = load i64, ptr %slot759, align 8
  %v5237 = load i64, ptr %slot761, align 8
  %cv5238 = trunc i64 %v5237 to i32
  %call5239 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v5234, i64 %v5235, i64 %v5236, i32 %cv5238) nomerge, !dbg !138
  store i32 %call5239, ptr %slot775, align 8
  %v5240 = load i32, ptr %slot775, align 8
  %cv5241 = zext i32 %v5240 to i64
  %cond5242 = icmp ne i64 %cv5241, 0
  br i1 %cond5242, label %bb_rcsuccess998, label %bb_rcfailure998
bb_rcfailure998:
  %v5243 = load i64, ptr %slot31, align 8
  %p5244 = inttoptr i64 %v5243 to ptr
  %call5245 = call i32 @myl_rc_take_failure(ptr %p5244) nomerge, !dbg !138
  store i32 %call5245, ptr %slot776, align 8
  %v5246 = load i64, ptr %slot1, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  %v5248 = load i32, ptr %slot776, align 8
  %call5249 = call i32 @myl_qbe_rc_status(ptr %p5247, i32 %v5248) nomerge, !dbg !138
  store i32 %call5249, ptr %slot777, align 8
  br label %bb_failure
bb_rcsuccess998:
  br label %bb_rcgdone984
bb_rcgplain984:
  %v5250 = load i64, ptr %slot762, align 8
  %v5251 = load i64, ptr %slot760, align 8
  %p5252 = inttoptr i64 %v5251 to ptr
  store i64 %v5250, ptr %p5252, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone984
bb_rcgdone984:
  %v5253 = load i64, ptr %slot14, align 8
  %p5254 = inttoptr i64 %v5253 to ptr
  store i32 2, ptr %p5254, align 4, !alias.scope !3, !noalias !4
  %v5255 = load i64, ptr %slot13, align 8
  %p5256 = inttoptr i64 %v5255 to ptr
  store i32 1, ptr %p5256, align 4, !alias.scope !3, !noalias !4
  %v5257 = load i64, ptr %slot5, align 8
  %p5258 = inttoptr i64 %v5257 to ptr
  %ld5259 = load i32, ptr %p5258, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5259, ptr %slot778, align 8
  %v5260 = load i32, ptr %slot778, align 8
  %cv5261 = zext i32 %v5260 to i64
  %cond5262 = icmp ne i64 %cv5261, 0
  br i1 %cond5262, label %bb_rcslotdrop1005, label %bb_rcslotdone1005
bb_rcslotdrop1005:
  %v5263 = load i64, ptr %slot5, align 8
  %p5264 = inttoptr i64 %v5263 to ptr
  store i32 0, ptr %p5264, align 4, !alias.scope !3, !noalias !4
  %v5265 = load i64, ptr %slot22, align 8
  store i64 %v5265, ptr %slot779, align 8
  %v5266 = load i64, ptr %slot6, align 8
  %p5267 = inttoptr i64 %v5266 to ptr
  %ld5268 = load i32, ptr %p5267, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5268, ptr %slot780, align 8
  %v5269 = load i32, ptr %slot780, align 8
  %op5270 = and i32 %v5269, 28
  store i32 %op5270, ptr %slot781, align 8
  %v5271 = load i32, ptr %slot781, align 8
  %cv5272 = zext i32 %v5271 to i64
  %cond5273 = icmp ne i64 %cv5272, 0
  br i1 %cond5273, label %bb_rcslotrole1005, label %bb_rcslotowner1005
bb_rcslotrole1005:
  %v5274 = load i64, ptr %slot31, align 8
  store i64 %v5274, ptr %slot782, align 8
  %v5275 = load i64, ptr %slot779, align 8
  %p5276 = inttoptr i64 %v5275 to ptr
  %ld5277 = load i64, ptr %p5276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5277, ptr %slot783, align 8
  %v5278 = load i64, ptr %slot783, align 8
  %cmp5279 = icmp ne i64 %v5278, 0
  %cv5280 = zext i1 %cmp5279 to i32
  store i32 %cv5280, ptr %slot784, align 8
  %v5281 = load i32, ptr %slot784, align 8
  %cv5282 = zext i32 %v5281 to i64
  %cond5283 = icmp ne i64 %cv5282, 0
  br i1 %cond5283, label %bb_rcgnn1021, label %bb_rcgdone1021
bb_rcgnn1021:
  %v5284 = load i64, ptr %slot783, align 8
  %op5285 = sub i64 %v5284, 16
  store i64 %op5285, ptr %slot785, align 8
  %v5286 = load i64, ptr %slot783, align 8
  %p5287 = inttoptr i64 %v5286 to ptr
  %rgep5288 = getelementptr i8, ptr %p5287, i64 -16
  %ld5289 = load i64, ptr %rgep5288, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5289, ptr %slot786, align 8
  %v5290 = load i64, ptr %slot786, align 8
  %op5291 = and i64 %v5290, 4611686018427387906
  store i64 %op5291, ptr %slot787, align 8
  %v5292 = load i64, ptr %slot787, align 8
  %cmp5293 = icmp ne i64 %v5292, 0
  %cv5294 = zext i1 %cmp5293 to i32
  store i32 %cv5294, ptr %slot788, align 8
  %v5295 = load i32, ptr %slot788, align 8
  %cv5296 = zext i32 %v5295 to i64
  %cond5297 = icmp ne i64 %cv5296, 0
  br i1 %cond5297, label %bb_rcgclear1021, label %bb_rcgcounted1021
bb_rcgcounted1021:
  %v5298 = load i64, ptr %slot783, align 8
  %op5299 = sub i64 %v5298, 24
  store i64 %op5299, ptr %slot789, align 8
  %v5300 = load i64, ptr %slot783, align 8
  %p5301 = inttoptr i64 %v5300 to ptr
  %rgep5302 = getelementptr i8, ptr %p5301, i64 -24
  %ld5303 = load i64, ptr %rgep5302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5303, ptr %slot790, align 8
  %v5304 = load i64, ptr %slot790, align 8
  %op5305 = sub i64 %v5304, 1
  store i64 %op5305, ptr %slot791, align 8
  %v5306 = load i64, ptr %slot791, align 8
  %cmp5307 = icmp eq i64 %v5306, 0
  %cv5308 = zext i1 %cmp5307 to i32
  store i32 %cv5308, ptr %slot792, align 8
  %v5309 = load i32, ptr %slot792, align 8
  %cv5310 = zext i32 %v5309 to i64
  %cond5311 = icmp ne i64 %cv5310, 0
  br i1 %cond5311, label %bb_rcglast1021, label %bb_rcgdec1021
bb_rcglast1021:
  %v5312 = load i64, ptr %slot783, align 8
  %op5313 = sub i64 %v5312, 32
  store i64 %op5313, ptr %slot793, align 8
  %v5314 = load i64, ptr %slot783, align 8
  %p5315 = inttoptr i64 %v5314 to ptr
  %rgep5316 = getelementptr i8, ptr %p5315, i64 -32
  %ld5317 = load i64, ptr %rgep5316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5317, ptr %slot794, align 8
  %v5318 = load i64, ptr %slot794, align 8
  %cmp5319 = icmp ne i64 %v5318, 0
  %cv5320 = zext i1 %cmp5319 to i32
  store i32 %cv5320, ptr %slot795, align 8
  %v5321 = load i32, ptr %slot795, align 8
  %cv5322 = zext i32 %v5321 to i64
  %cond5323 = icmp ne i64 %cv5322, 0
  br i1 %cond5323, label %bb_rcgdec1021, label %bb_rcgslow1021
bb_rcgslow1021:
  %v5324 = load i64, ptr %slot782, align 8
  %v5325 = load i64, ptr %slot779, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v5324, i64 %v5325) nomerge, !dbg !138
  br label %bb_rcgdone1021
bb_rcgdec1021:
  %v5326 = load i64, ptr %slot791, align 8
  %v5327 = load i64, ptr %slot783, align 8
  %p5328 = inttoptr i64 %v5327 to ptr
  %rgep5329 = getelementptr i8, ptr %p5328, i64 -24
  store i64 %v5326, ptr %rgep5329, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1021
bb_rcgclear1021:
  %v5330 = load i64, ptr %slot779, align 8
  %p5331 = inttoptr i64 %v5330 to ptr
  store i64 0, ptr %p5331, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1021
bb_rcgdone1021:
  br label %bb_rcslotdone1005
bb_rcslotowner1005:
  %v5332 = load i64, ptr %slot31, align 8
  store i64 %v5332, ptr %slot796, align 8
  %v5333 = load i64, ptr %slot779, align 8
  %p5334 = inttoptr i64 %v5333 to ptr
  %ld5335 = load i64, ptr %p5334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5335, ptr %slot797, align 8
  %v5336 = load i64, ptr %slot797, align 8
  %cmp5337 = icmp ne i64 %v5336, 0
  %cv5338 = zext i1 %cmp5337 to i32
  store i32 %cv5338, ptr %slot798, align 8
  %v5339 = load i32, ptr %slot798, align 8
  %cv5340 = zext i32 %v5339 to i64
  %cond5341 = icmp ne i64 %cv5340, 0
  br i1 %cond5341, label %bb_rcgnn1036, label %bb_rcgdone1036
bb_rcgnn1036:
  %v5342 = load i64, ptr %slot797, align 8
  %op5343 = sub i64 %v5342, 16
  store i64 %op5343, ptr %slot799, align 8
  %v5344 = load i64, ptr %slot797, align 8
  %p5345 = inttoptr i64 %v5344 to ptr
  %rgep5346 = getelementptr i8, ptr %p5345, i64 -16
  %ld5347 = load i64, ptr %rgep5346, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5347, ptr %slot800, align 8
  %v5348 = load i64, ptr %slot800, align 8
  %op5349 = and i64 %v5348, 4611686018427387906
  store i64 %op5349, ptr %slot801, align 8
  %v5350 = load i64, ptr %slot801, align 8
  %cmp5351 = icmp ne i64 %v5350, 0
  %cv5352 = zext i1 %cmp5351 to i32
  store i32 %cv5352, ptr %slot802, align 8
  %v5353 = load i32, ptr %slot802, align 8
  %cv5354 = zext i32 %v5353 to i64
  %cond5355 = icmp ne i64 %cv5354, 0
  br i1 %cond5355, label %bb_rcgclear1036, label %bb_rcgcounted1036
bb_rcgcounted1036:
  %v5356 = load i64, ptr %slot797, align 8
  %op5357 = sub i64 %v5356, 32
  store i64 %op5357, ptr %slot803, align 8
  %v5358 = load i64, ptr %slot797, align 8
  %p5359 = inttoptr i64 %v5358 to ptr
  %rgep5360 = getelementptr i8, ptr %p5359, i64 -32
  %ld5361 = load i64, ptr %rgep5360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5361, ptr %slot804, align 8
  %v5362 = load i64, ptr %slot804, align 8
  %op5363 = sub i64 %v5362, 1
  store i64 %op5363, ptr %slot805, align 8
  %v5364 = load i64, ptr %slot805, align 8
  %cmp5365 = icmp eq i64 %v5364, 0
  %cv5366 = zext i1 %cmp5365 to i32
  store i32 %cv5366, ptr %slot806, align 8
  %v5367 = load i32, ptr %slot806, align 8
  %cv5368 = zext i32 %v5367 to i64
  %cond5369 = icmp ne i64 %cv5368, 0
  br i1 %cond5369, label %bb_rcglast1036, label %bb_rcgdec1036
bb_rcglast1036:
  %v5370 = load i64, ptr %slot797, align 8
  %op5371 = sub i64 %v5370, 24
  store i64 %op5371, ptr %slot807, align 8
  %v5372 = load i64, ptr %slot797, align 8
  %p5373 = inttoptr i64 %v5372 to ptr
  %rgep5374 = getelementptr i8, ptr %p5373, i64 -24
  %ld5375 = load i64, ptr %rgep5374, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5375, ptr %slot808, align 8
  %v5376 = load i64, ptr %slot808, align 8
  %cmp5377 = icmp ne i64 %v5376, 0
  %cv5378 = zext i1 %cmp5377 to i32
  store i32 %cv5378, ptr %slot809, align 8
  %v5379 = load i32, ptr %slot809, align 8
  %cv5380 = zext i32 %v5379 to i64
  %cond5381 = icmp ne i64 %cv5380, 0
  br i1 %cond5381, label %bb_rcgdec1036, label %bb_rcgslow1036
bb_rcgslow1036:
  %v5382 = load i64, ptr %slot796, align 8
  %v5383 = load i64, ptr %slot779, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v5382, i64 %v5383) nomerge, !dbg !138
  br label %bb_rcgdone1036
bb_rcgdec1036:
  %v5384 = load i64, ptr %slot805, align 8
  %v5385 = load i64, ptr %slot797, align 8
  %p5386 = inttoptr i64 %v5385 to ptr
  %rgep5387 = getelementptr i8, ptr %p5386, i64 -32
  store i64 %v5384, ptr %rgep5387, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1036
bb_rcgclear1036:
  %v5388 = load i64, ptr %slot779, align 8
  %p5389 = inttoptr i64 %v5388 to ptr
  store i64 0, ptr %p5389, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1036
bb_rcgdone1036:
  br label %bb_rcslotdone1005
bb_rcslotdone1005:
  %v5390 = load i64, ptr %slot17, align 8
  store i64 %v5390, ptr %slot810, align 8
  %v5391 = load i64, ptr %slot810, align 8
  %v5392 = load i64, ptr %slot759, align 8
  %p5393 = inttoptr i64 %v5391 to ptr
  %p5394 = inttoptr i64 %v5392 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5394, ptr %p5393, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5395 = load i64, ptr %slot6, align 8
  %p5396 = inttoptr i64 %v5395 to ptr
  store i32 2, ptr %p5396, align 4, !alias.scope !3, !noalias !4
  %v5397 = load i64, ptr %slot5, align 8
  %p5398 = inttoptr i64 %v5397 to ptr
  store i32 1, ptr %p5398, align 4, !alias.scope !3, !noalias !4
  %v5399 = load i64, ptr %slot13, align 8
  %p5400 = inttoptr i64 %v5399 to ptr
  store i32 0, ptr %p5400, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal977
bb_rcownedlocal977:
  %v5401 = load i64, ptr %slot6, align 8
  %p5402 = inttoptr i64 %v5401 to ptr
  store i32 2, ptr %p5402, align 4, !alias.scope !3, !noalias !4
  %v5403 = load i64, ptr %slot754, align 8
  %p5404 = inttoptr i64 %v5403 to ptr
  %ld5405 = load i64, ptr %p5404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5405, ptr %slot811, align 8
  %v5406 = load i64, ptr %slot811, align 8
  %cmp5407 = icmp ne i64 %v5406, 0
  %cv5408 = zext i1 %cmp5407 to i32
  store i32 %cv5408, ptr %slot812, align 8
  %v5409 = load i32, ptr %slot812, align 8
  %cv5410 = zext i32 %v5409 to i64
  %cond5411 = icmp ne i64 %cv5410, 0
  br i1 %cond5411, label %bb_rcguniquenn1045, label %bb_rcgunique1045
bb_rcguniquenn1045:
  %v5412 = load i64, ptr %slot811, align 8
  %op5413 = sub i64 %v5412, 16
  store i64 %op5413, ptr %slot813, align 8
  %v5414 = load i64, ptr %slot811, align 8
  %p5415 = inttoptr i64 %v5414 to ptr
  %rgep5416 = getelementptr i8, ptr %p5415, i64 -16
  %ld5417 = load i64, ptr %rgep5416, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5417, ptr %slot814, align 8
  %v5418 = load i64, ptr %slot814, align 8
  %op5419 = and i64 %v5418, 6917529027641081858
  store i64 %op5419, ptr %slot815, align 8
  %v5420 = load i64, ptr %slot815, align 8
  %cmp5421 = icmp ne i64 %v5420, 0
  %cv5422 = zext i1 %cmp5421 to i32
  store i32 %cv5422, ptr %slot816, align 8
  %v5423 = load i32, ptr %slot816, align 8
  %cv5424 = zext i32 %v5423 to i64
  %cond5425 = icmp ne i64 %cv5424, 0
  br i1 %cond5425, label %bb_rcguniqueslow1045, label %bb_rcguniquecount1045
bb_rcguniquecount1045:
  %v5426 = load i64, ptr %slot811, align 8
  %op5427 = sub i64 %v5426, 32
  store i64 %op5427, ptr %slot817, align 8
  %v5428 = load i64, ptr %slot811, align 8
  %p5429 = inttoptr i64 %v5428 to ptr
  %rgep5430 = getelementptr i8, ptr %p5429, i64 -32
  %ld5431 = load i64, ptr %rgep5430, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5431, ptr %slot818, align 8
  %v5432 = load i64, ptr %slot818, align 8
  %cmp5433 = icmp ult i64 %v5432, 2
  %cv5434 = zext i1 %cmp5433 to i32
  store i32 %cv5434, ptr %slot819, align 8
  %v5435 = load i32, ptr %slot819, align 8
  %cv5436 = zext i32 %v5435 to i64
  %cond5437 = icmp ne i64 %cv5436, 0
  br i1 %cond5437, label %bb_rcgunique1045, label %bb_rcguniqueslow1045
bb_rcguniqueslow1045:
  %v5438 = load i64, ptr %slot1, align 8
  %p5439 = inttoptr i64 %v5438 to ptr
  %p5440 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v5441 = load i64, ptr %slot754, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  %v5443 = load i64, ptr %slot5, align 8
  %p5444 = inttoptr i64 %v5443 to ptr
  %call5445 = call i32 @myl_qbe_rc_unique_local(ptr %p5439, ptr %p5440, ptr %p5442, ptr %p5444) nomerge, !dbg !138
  store i32 %call5445, ptr %slot820, align 8
  %v5446 = load i32, ptr %slot820, align 8
  %cv5447 = zext i32 %v5446 to i64
  %cond5448 = icmp ne i64 %cv5447, 0
  br i1 %cond5448, label %bb_rcunique1056, label %bb_failure
bb_rcunique1056:
  br label %bb_rcgunique1045
bb_rcgunique1045:
  %v5449 = load i64, ptr %slot22, align 8
  %p5450 = inttoptr i64 %v5449 to ptr
  %ld5451 = load i64, ptr %p5450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5451, ptr %slot821, align 8
  %v5452 = load i64, ptr %slot25, align 8
  store i64 %v5452, ptr %slot822, align 8
  %v5453 = load i64, ptr %slot822, align 8
  %p5454 = inttoptr i64 %v5453 to ptr
  %ld5455 = load i64, ptr %p5454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5455, ptr %slot823, align 8
  %v5456 = load i64, ptr %slot823, align 8
  %v5457 = load i64, ptr %slot18, align 8
  %p5458 = inttoptr i64 %v5457 to ptr
  store i64 %v5456, ptr %p5458, align 8, !alias.scope !3, !noalias !4
  %v5459 = load i64, ptr %slot18, align 8
  store i64 %v5459, ptr %slot824, align 8
  %v5460 = load i64, ptr %slot31, align 8
  %v5461 = load i64, ptr %slot821, align 8
  %v5462 = load i64, ptr %slot824, align 8
  %call5463 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v5460, i64 %v5461, i64 %v5462) nomerge, !dbg !138
  store i32 %call5463, ptr %slot825, align 8
  %v5464 = load i32, ptr %slot825, align 8
  %cv5465 = zext i32 %v5464 to i64
  %cond5466 = icmp ne i64 %cv5465, 0
  br i1 %cond5466, label %bb_success1062, label %bb_failed1062
bb_failed1062:
  %v5467 = load i64, ptr %slot1, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5468) nomerge, !dbg !138
  unreachable
bb_success1062:
  %v5469 = load i64, ptr %slot25, align 8
  %p5470 = inttoptr i64 %v5469 to ptr
  store i64 0, ptr %p5470, align 8, !alias.scope !3, !noalias !4
  %v5471 = load i64, ptr %slot11, align 8
  %p5472 = inttoptr i64 %v5471 to ptr
  %ld5473 = load i32, ptr %p5472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5473, ptr %slot826, align 8
  %v5474 = load i32, ptr %slot826, align 8
  %cv5475 = zext i32 %v5474 to i64
  %cond5476 = icmp ne i64 %cv5475, 0
  br i1 %cond5476, label %bb_rcslotdrop1065, label %bb_rcslotdone1065
bb_rcslotdrop1065:
  %v5477 = load i64, ptr %slot11, align 8
  %p5478 = inttoptr i64 %v5477 to ptr
  store i32 0, ptr %p5478, align 4, !alias.scope !3, !noalias !4
  %v5479 = load i64, ptr %slot15, align 8
  store i64 %v5479, ptr %slot827, align 8
  %v5480 = load i64, ptr %slot12, align 8
  %p5481 = inttoptr i64 %v5480 to ptr
  %ld5482 = load i32, ptr %p5481, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5482, ptr %slot828, align 8
  %v5483 = load i32, ptr %slot828, align 8
  %op5484 = and i32 %v5483, 28
  store i32 %op5484, ptr %slot829, align 8
  %v5485 = load i32, ptr %slot829, align 8
  %cv5486 = zext i32 %v5485 to i64
  %cond5487 = icmp ne i64 %cv5486, 0
  br i1 %cond5487, label %bb_rcslotrole1065, label %bb_rcslotowner1065
bb_rcslotrole1065:
  %v5488 = load i64, ptr %slot31, align 8
  store i64 %v5488, ptr %slot830, align 8
  %v5489 = load i64, ptr %slot827, align 8
  %p5490 = inttoptr i64 %v5489 to ptr
  %ld5491 = load i64, ptr %p5490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5491, ptr %slot831, align 8
  %v5492 = load i64, ptr %slot831, align 8
  %cmp5493 = icmp ne i64 %v5492, 0
  %cv5494 = zext i1 %cmp5493 to i32
  store i32 %cv5494, ptr %slot832, align 8
  %v5495 = load i32, ptr %slot832, align 8
  %cv5496 = zext i32 %v5495 to i64
  %cond5497 = icmp ne i64 %cv5496, 0
  br i1 %cond5497, label %bb_rcgnn1081, label %bb_rcgdone1081
bb_rcgnn1081:
  %v5498 = load i64, ptr %slot831, align 8
  %op5499 = sub i64 %v5498, 16
  store i64 %op5499, ptr %slot833, align 8
  %v5500 = load i64, ptr %slot831, align 8
  %p5501 = inttoptr i64 %v5500 to ptr
  %rgep5502 = getelementptr i8, ptr %p5501, i64 -16
  %ld5503 = load i64, ptr %rgep5502, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5503, ptr %slot834, align 8
  %v5504 = load i64, ptr %slot834, align 8
  %op5505 = and i64 %v5504, 4611686018427387906
  store i64 %op5505, ptr %slot835, align 8
  %v5506 = load i64, ptr %slot835, align 8
  %cmp5507 = icmp ne i64 %v5506, 0
  %cv5508 = zext i1 %cmp5507 to i32
  store i32 %cv5508, ptr %slot836, align 8
  %v5509 = load i32, ptr %slot836, align 8
  %cv5510 = zext i32 %v5509 to i64
  %cond5511 = icmp ne i64 %cv5510, 0
  br i1 %cond5511, label %bb_rcgclear1081, label %bb_rcgcounted1081
bb_rcgcounted1081:
  %v5512 = load i64, ptr %slot831, align 8
  %op5513 = sub i64 %v5512, 24
  store i64 %op5513, ptr %slot837, align 8
  %v5514 = load i64, ptr %slot831, align 8
  %p5515 = inttoptr i64 %v5514 to ptr
  %rgep5516 = getelementptr i8, ptr %p5515, i64 -24
  %ld5517 = load i64, ptr %rgep5516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5517, ptr %slot838, align 8
  %v5518 = load i64, ptr %slot838, align 8
  %op5519 = sub i64 %v5518, 1
  store i64 %op5519, ptr %slot839, align 8
  %v5520 = load i64, ptr %slot839, align 8
  %cmp5521 = icmp eq i64 %v5520, 0
  %cv5522 = zext i1 %cmp5521 to i32
  store i32 %cv5522, ptr %slot840, align 8
  %v5523 = load i32, ptr %slot840, align 8
  %cv5524 = zext i32 %v5523 to i64
  %cond5525 = icmp ne i64 %cv5524, 0
  br i1 %cond5525, label %bb_rcglast1081, label %bb_rcgdec1081
bb_rcglast1081:
  %v5526 = load i64, ptr %slot831, align 8
  %op5527 = sub i64 %v5526, 32
  store i64 %op5527, ptr %slot841, align 8
  %v5528 = load i64, ptr %slot831, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  %rgep5530 = getelementptr i8, ptr %p5529, i64 -32
  %ld5531 = load i64, ptr %rgep5530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5531, ptr %slot842, align 8
  %v5532 = load i64, ptr %slot842, align 8
  %cmp5533 = icmp ne i64 %v5532, 0
  %cv5534 = zext i1 %cmp5533 to i32
  store i32 %cv5534, ptr %slot843, align 8
  %v5535 = load i32, ptr %slot843, align 8
  %cv5536 = zext i32 %v5535 to i64
  %cond5537 = icmp ne i64 %cv5536, 0
  br i1 %cond5537, label %bb_rcgdec1081, label %bb_rcgslow1081
bb_rcgslow1081:
  %v5538 = load i64, ptr %slot830, align 8
  %v5539 = load i64, ptr %slot827, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5538, i64 %v5539) nomerge, !dbg !138
  br label %bb_rcgdone1081
bb_rcgdec1081:
  %v5540 = load i64, ptr %slot839, align 8
  %v5541 = load i64, ptr %slot831, align 8
  %p5542 = inttoptr i64 %v5541 to ptr
  %rgep5543 = getelementptr i8, ptr %p5542, i64 -24
  store i64 %v5540, ptr %rgep5543, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1081
bb_rcgclear1081:
  %v5544 = load i64, ptr %slot827, align 8
  %p5545 = inttoptr i64 %v5544 to ptr
  store i64 0, ptr %p5545, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1081
bb_rcgdone1081:
  br label %bb_rcslotdone1065
bb_rcslotowner1065:
  %v5546 = load i64, ptr %slot31, align 8
  store i64 %v5546, ptr %slot844, align 8
  %v5547 = load i64, ptr %slot827, align 8
  %p5548 = inttoptr i64 %v5547 to ptr
  %ld5549 = load i64, ptr %p5548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5549, ptr %slot845, align 8
  %v5550 = load i64, ptr %slot845, align 8
  %cmp5551 = icmp ne i64 %v5550, 0
  %cv5552 = zext i1 %cmp5551 to i32
  store i32 %cv5552, ptr %slot846, align 8
  %v5553 = load i32, ptr %slot846, align 8
  %cv5554 = zext i32 %v5553 to i64
  %cond5555 = icmp ne i64 %cv5554, 0
  br i1 %cond5555, label %bb_rcgnn1096, label %bb_rcgdone1096
bb_rcgnn1096:
  %v5556 = load i64, ptr %slot845, align 8
  %op5557 = sub i64 %v5556, 16
  store i64 %op5557, ptr %slot847, align 8
  %v5558 = load i64, ptr %slot845, align 8
  %p5559 = inttoptr i64 %v5558 to ptr
  %rgep5560 = getelementptr i8, ptr %p5559, i64 -16
  %ld5561 = load i64, ptr %rgep5560, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5561, ptr %slot848, align 8
  %v5562 = load i64, ptr %slot848, align 8
  %op5563 = and i64 %v5562, 4611686018427387906
  store i64 %op5563, ptr %slot849, align 8
  %v5564 = load i64, ptr %slot849, align 8
  %cmp5565 = icmp ne i64 %v5564, 0
  %cv5566 = zext i1 %cmp5565 to i32
  store i32 %cv5566, ptr %slot850, align 8
  %v5567 = load i32, ptr %slot850, align 8
  %cv5568 = zext i32 %v5567 to i64
  %cond5569 = icmp ne i64 %cv5568, 0
  br i1 %cond5569, label %bb_rcgclear1096, label %bb_rcgcounted1096
bb_rcgcounted1096:
  %v5570 = load i64, ptr %slot845, align 8
  %op5571 = sub i64 %v5570, 32
  store i64 %op5571, ptr %slot851, align 8
  %v5572 = load i64, ptr %slot845, align 8
  %p5573 = inttoptr i64 %v5572 to ptr
  %rgep5574 = getelementptr i8, ptr %p5573, i64 -32
  %ld5575 = load i64, ptr %rgep5574, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5575, ptr %slot852, align 8
  %v5576 = load i64, ptr %slot852, align 8
  %op5577 = sub i64 %v5576, 1
  store i64 %op5577, ptr %slot853, align 8
  %v5578 = load i64, ptr %slot853, align 8
  %cmp5579 = icmp eq i64 %v5578, 0
  %cv5580 = zext i1 %cmp5579 to i32
  store i32 %cv5580, ptr %slot854, align 8
  %v5581 = load i32, ptr %slot854, align 8
  %cv5582 = zext i32 %v5581 to i64
  %cond5583 = icmp ne i64 %cv5582, 0
  br i1 %cond5583, label %bb_rcglast1096, label %bb_rcgdec1096
bb_rcglast1096:
  %v5584 = load i64, ptr %slot845, align 8
  %op5585 = sub i64 %v5584, 24
  store i64 %op5585, ptr %slot855, align 8
  %v5586 = load i64, ptr %slot845, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %rgep5588 = getelementptr i8, ptr %p5587, i64 -24
  %ld5589 = load i64, ptr %rgep5588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5589, ptr %slot856, align 8
  %v5590 = load i64, ptr %slot856, align 8
  %cmp5591 = icmp ne i64 %v5590, 0
  %cv5592 = zext i1 %cmp5591 to i32
  store i32 %cv5592, ptr %slot857, align 8
  %v5593 = load i32, ptr %slot857, align 8
  %cv5594 = zext i32 %v5593 to i64
  %cond5595 = icmp ne i64 %cv5594, 0
  br i1 %cond5595, label %bb_rcgdec1096, label %bb_rcgslow1096
bb_rcgslow1096:
  %v5596 = load i64, ptr %slot844, align 8
  %v5597 = load i64, ptr %slot827, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5596, i64 %v5597) nomerge, !dbg !138
  br label %bb_rcgdone1096
bb_rcgdec1096:
  %v5598 = load i64, ptr %slot853, align 8
  %v5599 = load i64, ptr %slot845, align 8
  %p5600 = inttoptr i64 %v5599 to ptr
  %rgep5601 = getelementptr i8, ptr %p5600, i64 -32
  store i64 %v5598, ptr %rgep5601, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1096
bb_rcgclear1096:
  %v5602 = load i64, ptr %slot827, align 8
  %p5603 = inttoptr i64 %v5602 to ptr
  store i64 0, ptr %p5603, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1096
bb_rcgdone1096:
  br label %bb_rcslotdone1065
bb_rcslotdone1065:
  %v5604 = load i64, ptr %slot19, align 8
  %p5605 = inttoptr i64 %v5604 to ptr
  %ld5606 = load i64, ptr %p5605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5606, ptr %slot858, align 8
  %v5607 = load i64, ptr %slot858, align 8
  %v5608 = load i64, ptr %slot25, align 8
  %p5609 = inttoptr i64 %v5608 to ptr
  store i64 %v5607, ptr %p5609, align 8, !alias.scope !3, !noalias !4
  %v5610 = load i64, ptr %slot25, align 8
  %p5611 = inttoptr i64 %v5610 to ptr
  %ld5612 = load i64, ptr %p5611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5612, ptr %slot859, align 8
  %v5613 = load i64, ptr %slot859, align 8
  %op5614 = add i64 %v5613, 104
  store i64 %op5614, ptr %slot860, align 8
  %v5615 = load i64, ptr %slot860, align 8
  %p5616 = inttoptr i64 %v5615 to ptr
  %ld5617 = load i64, ptr %p5616, align 8
  store i64 %ld5617, ptr %slot861, align 8
  %v5618 = load i64, ptr %slot861, align 8
  %v5619 = load i64, ptr %slot25, align 8
  %p5620 = inttoptr i64 %v5619 to ptr
  store i64 %v5618, ptr %p5620, align 8, !alias.scope !3, !noalias !4
  %v5621 = load i64, ptr %slot11, align 8
  %p5622 = inttoptr i64 %v5621 to ptr
  %ld5623 = load i32, ptr %p5622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5623, ptr %slot862, align 8
  %v5624 = load i32, ptr %slot862, align 8
  %cv5625 = zext i32 %v5624 to i64
  %cond5626 = icmp ne i64 %cv5625, 0
  br i1 %cond5626, label %bb_rcslotdrop1106, label %bb_rcslotdone1106
bb_rcslotdrop1106:
  %v5627 = load i64, ptr %slot11, align 8
  %p5628 = inttoptr i64 %v5627 to ptr
  store i32 0, ptr %p5628, align 4, !alias.scope !3, !noalias !4
  %v5629 = load i64, ptr %slot15, align 8
  store i64 %v5629, ptr %slot863, align 8
  %v5630 = load i64, ptr %slot12, align 8
  %p5631 = inttoptr i64 %v5630 to ptr
  %ld5632 = load i32, ptr %p5631, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5632, ptr %slot864, align 8
  %v5633 = load i32, ptr %slot864, align 8
  %op5634 = and i32 %v5633, 28
  store i32 %op5634, ptr %slot865, align 8
  %v5635 = load i32, ptr %slot865, align 8
  %cv5636 = zext i32 %v5635 to i64
  %cond5637 = icmp ne i64 %cv5636, 0
  br i1 %cond5637, label %bb_rcslotrole1106, label %bb_rcslotowner1106
bb_rcslotrole1106:
  %v5638 = load i64, ptr %slot31, align 8
  store i64 %v5638, ptr %slot866, align 8
  %v5639 = load i64, ptr %slot866, align 8
  %v5640 = load i64, ptr %slot863, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5639, i64 %v5640) nomerge, !dbg !140
  br label %bb_rcslotdone1106
bb_rcslotowner1106:
  %v5641 = load i64, ptr %slot31, align 8
  store i64 %v5641, ptr %slot867, align 8
  %v5642 = load i64, ptr %slot867, align 8
  %v5643 = load i64, ptr %slot863, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5642, i64 %v5643) nomerge, !dbg !140
  br label %bb_rcslotdone1106
bb_rcslotdone1106:
  %v5644 = load i64, ptr %slot25, align 8
  %p5645 = inttoptr i64 %v5644 to ptr
  %ld5646 = load i64, ptr %p5645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5646, ptr %slot868, align 8
  %v5647 = load i64, ptr %slot31, align 8
  %p5648 = inttoptr i64 %v5647 to ptr
  %v5649 = load i64, ptr %slot868, align 8
  %p5650 = inttoptr i64 %v5649 to ptr
  %call5651 = call ptr @myl_native_text_scalar(ptr %p5648, ptr %p5650, i32 0) nomerge, !dbg !142
  %calladdr5652 = ptrtoint ptr %call5651 to i64
  store i64 %calladdr5652, ptr %slot869, align 8
  %v5653 = load i64, ptr %slot869, align 8
  %cond5654 = icmp ne i64 %v5653, 0
  br i1 %cond5654, label %bb_success1115, label %bb_failed1115
bb_failed1115:
  %v5655 = load i64, ptr %slot1, align 8
  %p5656 = inttoptr i64 %v5655 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5656) nomerge, !dbg !142
  unreachable
bb_success1115:
  %v5657 = load i64, ptr %slot869, align 8
  %v5658 = load i64, ptr %slot25, align 8
  %p5659 = inttoptr i64 %v5658 to ptr
  store i64 %v5657, ptr %p5659, align 8, !alias.scope !3, !noalias !4
  %v5660 = load i64, ptr %slot25, align 8
  %p5661 = inttoptr i64 %v5660 to ptr
  %ld5662 = load i64, ptr %p5661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5662, ptr %slot870, align 8
  %v5663 = load i64, ptr %slot870, align 8
  %v5664 = load i64, ptr %slot16, align 8
  %p5665 = inttoptr i64 %v5664 to ptr
  store i64 %v5663, ptr %p5665, align 8, !alias.scope !3, !noalias !4
  %v5666 = load i64, ptr %slot16, align 8
  store i64 %v5666, ptr %slot871, align 8
  %v5667 = load i64, ptr %slot17, align 8
  store i64 %v5667, ptr %slot872, align 8
  %v5668 = load i64, ptr %slot871, align 8
  %v5669 = load i64, ptr %slot872, align 8
  %p5670 = inttoptr i64 %v5668 to ptr
  %p5671 = inttoptr i64 %v5669 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5671, ptr %p5670, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5672 = load i64, ptr %slot14, align 8
  %p5673 = inttoptr i64 %v5672 to ptr
  store i32 2, ptr %p5673, align 4, !alias.scope !3, !noalias !4
  %v5674 = load i64, ptr %slot13, align 8
  %p5675 = inttoptr i64 %v5674 to ptr
  store i32 1, ptr %p5675, align 4, !alias.scope !3, !noalias !4
  %v5676 = load i64, ptr %slot15, align 8
  store i64 %v5676, ptr %slot873, align 8
  %v5677 = load i64, ptr %slot17, align 8
  store i64 %v5677, ptr %slot874, align 8
  %v5678 = load i64, ptr %slot874, align 8
  %v5679 = load i64, ptr %slot873, align 8
  %p5680 = inttoptr i64 %v5678 to ptr
  %p5681 = inttoptr i64 %v5679 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5681, ptr %p5680, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5682 = load i64, ptr %slot12, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  store i32 2, ptr %p5683, align 4, !alias.scope !3, !noalias !4
  %v5684 = load i64, ptr %slot14, align 8
  %p5685 = inttoptr i64 %v5684 to ptr
  %ld5686 = load i32, ptr %p5685, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5686, ptr %slot875, align 8
  %v5687 = load i32, ptr %slot875, align 8
  %v5688 = load i64, ptr %slot12, align 8
  %p5689 = inttoptr i64 %v5688 to ptr
  store i32 %v5687, ptr %p5689, align 4, !alias.scope !3, !noalias !4
  %v5690 = load i64, ptr %slot13, align 8
  %p5691 = inttoptr i64 %v5690 to ptr
  store i32 0, ptr %p5691, align 4, !alias.scope !3, !noalias !4
  %v5692 = load i64, ptr %slot11, align 8
  %p5693 = inttoptr i64 %v5692 to ptr
  store i32 1, ptr %p5693, align 4, !alias.scope !3, !noalias !4
  %v5694 = load i64, ptr %slot873, align 8
  %p5695 = inttoptr i64 %v5694 to ptr
  %ld5696 = load i64, ptr %p5695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5696, ptr %slot876, align 8
  %v5697 = load i64, ptr %slot876, align 8
  %v5698 = load i64, ptr %slot25, align 8
  %p5699 = inttoptr i64 %v5698 to ptr
  store i64 %v5697, ptr %p5699, align 8, !alias.scope !3, !noalias !4
  %v5700 = load i64, ptr %slot22, align 8
  store i64 %v5700, ptr %slot877, align 8
  %v5701 = load i64, ptr %slot6, align 8
  %p5702 = inttoptr i64 %v5701 to ptr
  %ld5703 = load i32, ptr %p5702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5703, ptr %slot878, align 8
  %v5704 = load i32, ptr %slot878, align 8
  %cmp5705 = icmp eq i32 %v5704, 16
  %cv5706 = zext i1 %cmp5705 to i32
  store i32 %cv5706, ptr %slot879, align 8
  %v5707 = load i64, ptr %slot5, align 8
  %p5708 = inttoptr i64 %v5707 to ptr
  %ld5709 = load i32, ptr %p5708, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5709, ptr %slot880, align 8
  %v5710 = load i32, ptr %slot880, align 8
  %v5711 = load i32, ptr %slot879, align 8
  %op5712 = and i32 %v5710, %v5711
  store i32 %op5712, ptr %slot881, align 8
  %v5713 = load i32, ptr %slot881, align 8
  %cv5714 = zext i32 %v5713 to i64
  %cond5715 = icmp ne i64 %cv5714, 0
  br i1 %cond5715, label %bb_rcownlocal1136, label %bb_rcownedlocal1136
bb_rcownlocal1136:
  %v5716 = load i64, ptr %slot22, align 8
  store i64 %v5716, ptr %slot882, align 8
  %v5717 = load i64, ptr %slot17, align 8
  store i64 %v5717, ptr %slot883, align 8
  %v5718 = load i64, ptr %slot32, align 8
  store i64 %v5718, ptr %slot884, align 8
  %v5719 = load i64, ptr %slot882, align 8
  %p5720 = inttoptr i64 %v5719 to ptr
  %ld5721 = load i64, ptr %p5720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5721, ptr %slot885, align 8
  %v5722 = load i64, ptr %slot885, align 8
  %cmp5723 = icmp ne i64 %v5722, 0
  %cv5724 = zext i1 %cmp5723 to i32
  store i32 %cv5724, ptr %slot886, align 8
  %v5725 = load i32, ptr %slot886, align 8
  %cv5726 = zext i32 %v5725 to i64
  %cond5727 = icmp ne i64 %cv5726, 0
  br i1 %cond5727, label %bb_rcgnn1143, label %bb_rcgplain1143
bb_rcgnn1143:
  %v5728 = load i64, ptr %slot885, align 8
  %op5729 = sub i64 %v5728, 16
  store i64 %op5729, ptr %slot887, align 8
  %v5730 = load i64, ptr %slot885, align 8
  %p5731 = inttoptr i64 %v5730 to ptr
  %rgep5732 = getelementptr i8, ptr %p5731, i64 -16
  %ld5733 = load i64, ptr %rgep5732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5733, ptr %slot888, align 8
  %v5734 = load i64, ptr %slot888, align 8
  %op5735 = and i64 %v5734, 4611686018427387906
  store i64 %op5735, ptr %slot889, align 8
  %v5736 = load i64, ptr %slot889, align 8
  %cmp5737 = icmp ne i64 %v5736, 0
  %cv5738 = zext i1 %cmp5737 to i32
  store i32 %cv5738, ptr %slot890, align 8
  %v5739 = load i32, ptr %slot890, align 8
  %cv5740 = zext i32 %v5739 to i64
  %cond5741 = icmp ne i64 %cv5740, 0
  br i1 %cond5741, label %bb_rcgspecial1143, label %bb_rcginc1143
bb_rcginc1143:
  %v5742 = load i64, ptr %slot885, align 8
  %op5743 = sub i64 %v5742, 32
  store i64 %op5743, ptr %slot891, align 8
  %v5744 = load i64, ptr %slot885, align 8
  %p5745 = inttoptr i64 %v5744 to ptr
  %rgep5746 = getelementptr i8, ptr %p5745, i64 -32
  %ld5747 = load i64, ptr %rgep5746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5747, ptr %slot892, align 8
  %v5748 = load i64, ptr %slot892, align 8
  %op5749 = add i64 %v5748, 1
  store i64 %op5749, ptr %slot893, align 8
  %v5750 = load i64, ptr %slot893, align 8
  %cmp5751 = icmp eq i64 %v5750, 0
  %cv5752 = zext i1 %cmp5751 to i32
  store i32 %cv5752, ptr %slot894, align 8
  %v5753 = load i32, ptr %slot894, align 8
  %cv5754 = zext i32 %v5753 to i64
  %cond5755 = icmp ne i64 %cv5754, 0
  br i1 %cond5755, label %bb_rcglimit1143, label %bb_rcgcapacity1143
bb_rcglimit1143:
  %v5756 = load i64, ptr %slot1, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  %call5758 = call i32 @myl_qbe_rc_status(ptr %p5757, i32 2) nomerge, !dbg !144
  store i32 %call5758, ptr %slot895, align 8
  br label %bb_failure
bb_rcgcapacity1143:
  %v5759 = load i64, ptr %slot893, align 8
  %v5760 = load i64, ptr %slot885, align 8
  %p5761 = inttoptr i64 %v5760 to ptr
  %rgep5762 = getelementptr i8, ptr %p5761, i64 -32
  store i64 %v5759, ptr %rgep5762, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1143
bb_rcgspecial1143:
  %v5763 = load i64, ptr %slot888, align 8
  %op5764 = and i64 %v5763, 4611686018427387904
  store i64 %op5764, ptr %slot896, align 8
  %v5765 = load i64, ptr %slot896, align 8
  %cmp5766 = icmp ne i64 %v5765, 0
  %cv5767 = zext i1 %cmp5766 to i32
  store i32 %cv5767, ptr %slot897, align 8
  %v5768 = load i32, ptr %slot897, align 8
  %cv5769 = zext i32 %v5768 to i64
  %cond5770 = icmp ne i64 %cv5769, 0
  br i1 %cond5770, label %bb_rcgslow1143, label %bb_rcgplain1143
bb_rcgslow1143:
  %v5771 = load i64, ptr %slot31, align 8
  %v5772 = load i64, ptr %slot883, align 8
  %v5773 = load i64, ptr %slot882, align 8
  %v5774 = load i64, ptr %slot884, align 8
  %cv5775 = trunc i64 %v5774 to i32
  %call5776 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v5771, i64 %v5772, i64 %v5773, i32 %cv5775) nomerge, !dbg !144
  store i32 %call5776, ptr %slot898, align 8
  %v5777 = load i32, ptr %slot898, align 8
  %cv5778 = zext i32 %v5777 to i64
  %cond5779 = icmp ne i64 %cv5778, 0
  br i1 %cond5779, label %bb_rcsuccess1157, label %bb_rcfailure1157
bb_rcfailure1157:
  %v5780 = load i64, ptr %slot31, align 8
  %p5781 = inttoptr i64 %v5780 to ptr
  %call5782 = call i32 @myl_rc_take_failure(ptr %p5781) nomerge, !dbg !144
  store i32 %call5782, ptr %slot899, align 8
  %v5783 = load i64, ptr %slot1, align 8
  %p5784 = inttoptr i64 %v5783 to ptr
  %v5785 = load i32, ptr %slot899, align 8
  %call5786 = call i32 @myl_qbe_rc_status(ptr %p5784, i32 %v5785) nomerge, !dbg !144
  store i32 %call5786, ptr %slot900, align 8
  br label %bb_failure
bb_rcsuccess1157:
  br label %bb_rcgdone1143
bb_rcgplain1143:
  %v5787 = load i64, ptr %slot885, align 8
  %v5788 = load i64, ptr %slot883, align 8
  %p5789 = inttoptr i64 %v5788 to ptr
  store i64 %v5787, ptr %p5789, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1143
bb_rcgdone1143:
  %v5790 = load i64, ptr %slot14, align 8
  %p5791 = inttoptr i64 %v5790 to ptr
  store i32 2, ptr %p5791, align 4, !alias.scope !3, !noalias !4
  %v5792 = load i64, ptr %slot13, align 8
  %p5793 = inttoptr i64 %v5792 to ptr
  store i32 1, ptr %p5793, align 4, !alias.scope !3, !noalias !4
  %v5794 = load i64, ptr %slot5, align 8
  %p5795 = inttoptr i64 %v5794 to ptr
  %ld5796 = load i32, ptr %p5795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5796, ptr %slot901, align 8
  %v5797 = load i32, ptr %slot901, align 8
  %cv5798 = zext i32 %v5797 to i64
  %cond5799 = icmp ne i64 %cv5798, 0
  br i1 %cond5799, label %bb_rcslotdrop1164, label %bb_rcslotdone1164
bb_rcslotdrop1164:
  %v5800 = load i64, ptr %slot5, align 8
  %p5801 = inttoptr i64 %v5800 to ptr
  store i32 0, ptr %p5801, align 4, !alias.scope !3, !noalias !4
  %v5802 = load i64, ptr %slot22, align 8
  store i64 %v5802, ptr %slot902, align 8
  %v5803 = load i64, ptr %slot6, align 8
  %p5804 = inttoptr i64 %v5803 to ptr
  %ld5805 = load i32, ptr %p5804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5805, ptr %slot903, align 8
  %v5806 = load i32, ptr %slot903, align 8
  %op5807 = and i32 %v5806, 28
  store i32 %op5807, ptr %slot904, align 8
  %v5808 = load i32, ptr %slot904, align 8
  %cv5809 = zext i32 %v5808 to i64
  %cond5810 = icmp ne i64 %cv5809, 0
  br i1 %cond5810, label %bb_rcslotrole1164, label %bb_rcslotowner1164
bb_rcslotrole1164:
  %v5811 = load i64, ptr %slot31, align 8
  store i64 %v5811, ptr %slot905, align 8
  %v5812 = load i64, ptr %slot902, align 8
  %p5813 = inttoptr i64 %v5812 to ptr
  %ld5814 = load i64, ptr %p5813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5814, ptr %slot906, align 8
  %v5815 = load i64, ptr %slot906, align 8
  %cmp5816 = icmp ne i64 %v5815, 0
  %cv5817 = zext i1 %cmp5816 to i32
  store i32 %cv5817, ptr %slot907, align 8
  %v5818 = load i32, ptr %slot907, align 8
  %cv5819 = zext i32 %v5818 to i64
  %cond5820 = icmp ne i64 %cv5819, 0
  br i1 %cond5820, label %bb_rcgnn1180, label %bb_rcgdone1180
bb_rcgnn1180:
  %v5821 = load i64, ptr %slot906, align 8
  %op5822 = sub i64 %v5821, 16
  store i64 %op5822, ptr %slot908, align 8
  %v5823 = load i64, ptr %slot906, align 8
  %p5824 = inttoptr i64 %v5823 to ptr
  %rgep5825 = getelementptr i8, ptr %p5824, i64 -16
  %ld5826 = load i64, ptr %rgep5825, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5826, ptr %slot909, align 8
  %v5827 = load i64, ptr %slot909, align 8
  %op5828 = and i64 %v5827, 4611686018427387906
  store i64 %op5828, ptr %slot910, align 8
  %v5829 = load i64, ptr %slot910, align 8
  %cmp5830 = icmp ne i64 %v5829, 0
  %cv5831 = zext i1 %cmp5830 to i32
  store i32 %cv5831, ptr %slot911, align 8
  %v5832 = load i32, ptr %slot911, align 8
  %cv5833 = zext i32 %v5832 to i64
  %cond5834 = icmp ne i64 %cv5833, 0
  br i1 %cond5834, label %bb_rcgclear1180, label %bb_rcgcounted1180
bb_rcgcounted1180:
  %v5835 = load i64, ptr %slot906, align 8
  %op5836 = sub i64 %v5835, 24
  store i64 %op5836, ptr %slot912, align 8
  %v5837 = load i64, ptr %slot906, align 8
  %p5838 = inttoptr i64 %v5837 to ptr
  %rgep5839 = getelementptr i8, ptr %p5838, i64 -24
  %ld5840 = load i64, ptr %rgep5839, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5840, ptr %slot913, align 8
  %v5841 = load i64, ptr %slot913, align 8
  %op5842 = sub i64 %v5841, 1
  store i64 %op5842, ptr %slot914, align 8
  %v5843 = load i64, ptr %slot914, align 8
  %cmp5844 = icmp eq i64 %v5843, 0
  %cv5845 = zext i1 %cmp5844 to i32
  store i32 %cv5845, ptr %slot915, align 8
  %v5846 = load i32, ptr %slot915, align 8
  %cv5847 = zext i32 %v5846 to i64
  %cond5848 = icmp ne i64 %cv5847, 0
  br i1 %cond5848, label %bb_rcglast1180, label %bb_rcgdec1180
bb_rcglast1180:
  %v5849 = load i64, ptr %slot906, align 8
  %op5850 = sub i64 %v5849, 32
  store i64 %op5850, ptr %slot916, align 8
  %v5851 = load i64, ptr %slot906, align 8
  %p5852 = inttoptr i64 %v5851 to ptr
  %rgep5853 = getelementptr i8, ptr %p5852, i64 -32
  %ld5854 = load i64, ptr %rgep5853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5854, ptr %slot917, align 8
  %v5855 = load i64, ptr %slot917, align 8
  %cmp5856 = icmp ne i64 %v5855, 0
  %cv5857 = zext i1 %cmp5856 to i32
  store i32 %cv5857, ptr %slot918, align 8
  %v5858 = load i32, ptr %slot918, align 8
  %cv5859 = zext i32 %v5858 to i64
  %cond5860 = icmp ne i64 %cv5859, 0
  br i1 %cond5860, label %bb_rcgdec1180, label %bb_rcgslow1180
bb_rcgslow1180:
  %v5861 = load i64, ptr %slot905, align 8
  %v5862 = load i64, ptr %slot902, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v5861, i64 %v5862) nomerge, !dbg !144
  br label %bb_rcgdone1180
bb_rcgdec1180:
  %v5863 = load i64, ptr %slot914, align 8
  %v5864 = load i64, ptr %slot906, align 8
  %p5865 = inttoptr i64 %v5864 to ptr
  %rgep5866 = getelementptr i8, ptr %p5865, i64 -24
  store i64 %v5863, ptr %rgep5866, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1180
bb_rcgclear1180:
  %v5867 = load i64, ptr %slot902, align 8
  %p5868 = inttoptr i64 %v5867 to ptr
  store i64 0, ptr %p5868, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1180
bb_rcgdone1180:
  br label %bb_rcslotdone1164
bb_rcslotowner1164:
  %v5869 = load i64, ptr %slot31, align 8
  store i64 %v5869, ptr %slot919, align 8
  %v5870 = load i64, ptr %slot902, align 8
  %p5871 = inttoptr i64 %v5870 to ptr
  %ld5872 = load i64, ptr %p5871, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5872, ptr %slot920, align 8
  %v5873 = load i64, ptr %slot920, align 8
  %cmp5874 = icmp ne i64 %v5873, 0
  %cv5875 = zext i1 %cmp5874 to i32
  store i32 %cv5875, ptr %slot921, align 8
  %v5876 = load i32, ptr %slot921, align 8
  %cv5877 = zext i32 %v5876 to i64
  %cond5878 = icmp ne i64 %cv5877, 0
  br i1 %cond5878, label %bb_rcgnn1195, label %bb_rcgdone1195
bb_rcgnn1195:
  %v5879 = load i64, ptr %slot920, align 8
  %op5880 = sub i64 %v5879, 16
  store i64 %op5880, ptr %slot922, align 8
  %v5881 = load i64, ptr %slot920, align 8
  %p5882 = inttoptr i64 %v5881 to ptr
  %rgep5883 = getelementptr i8, ptr %p5882, i64 -16
  %ld5884 = load i64, ptr %rgep5883, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5884, ptr %slot923, align 8
  %v5885 = load i64, ptr %slot923, align 8
  %op5886 = and i64 %v5885, 4611686018427387906
  store i64 %op5886, ptr %slot924, align 8
  %v5887 = load i64, ptr %slot924, align 8
  %cmp5888 = icmp ne i64 %v5887, 0
  %cv5889 = zext i1 %cmp5888 to i32
  store i32 %cv5889, ptr %slot925, align 8
  %v5890 = load i32, ptr %slot925, align 8
  %cv5891 = zext i32 %v5890 to i64
  %cond5892 = icmp ne i64 %cv5891, 0
  br i1 %cond5892, label %bb_rcgclear1195, label %bb_rcgcounted1195
bb_rcgcounted1195:
  %v5893 = load i64, ptr %slot920, align 8
  %op5894 = sub i64 %v5893, 32
  store i64 %op5894, ptr %slot926, align 8
  %v5895 = load i64, ptr %slot920, align 8
  %p5896 = inttoptr i64 %v5895 to ptr
  %rgep5897 = getelementptr i8, ptr %p5896, i64 -32
  %ld5898 = load i64, ptr %rgep5897, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5898, ptr %slot927, align 8
  %v5899 = load i64, ptr %slot927, align 8
  %op5900 = sub i64 %v5899, 1
  store i64 %op5900, ptr %slot928, align 8
  %v5901 = load i64, ptr %slot928, align 8
  %cmp5902 = icmp eq i64 %v5901, 0
  %cv5903 = zext i1 %cmp5902 to i32
  store i32 %cv5903, ptr %slot929, align 8
  %v5904 = load i32, ptr %slot929, align 8
  %cv5905 = zext i32 %v5904 to i64
  %cond5906 = icmp ne i64 %cv5905, 0
  br i1 %cond5906, label %bb_rcglast1195, label %bb_rcgdec1195
bb_rcglast1195:
  %v5907 = load i64, ptr %slot920, align 8
  %op5908 = sub i64 %v5907, 24
  store i64 %op5908, ptr %slot930, align 8
  %v5909 = load i64, ptr %slot920, align 8
  %p5910 = inttoptr i64 %v5909 to ptr
  %rgep5911 = getelementptr i8, ptr %p5910, i64 -24
  %ld5912 = load i64, ptr %rgep5911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5912, ptr %slot931, align 8
  %v5913 = load i64, ptr %slot931, align 8
  %cmp5914 = icmp ne i64 %v5913, 0
  %cv5915 = zext i1 %cmp5914 to i32
  store i32 %cv5915, ptr %slot932, align 8
  %v5916 = load i32, ptr %slot932, align 8
  %cv5917 = zext i32 %v5916 to i64
  %cond5918 = icmp ne i64 %cv5917, 0
  br i1 %cond5918, label %bb_rcgdec1195, label %bb_rcgslow1195
bb_rcgslow1195:
  %v5919 = load i64, ptr %slot919, align 8
  %v5920 = load i64, ptr %slot902, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v5919, i64 %v5920) nomerge, !dbg !144
  br label %bb_rcgdone1195
bb_rcgdec1195:
  %v5921 = load i64, ptr %slot928, align 8
  %v5922 = load i64, ptr %slot920, align 8
  %p5923 = inttoptr i64 %v5922 to ptr
  %rgep5924 = getelementptr i8, ptr %p5923, i64 -32
  store i64 %v5921, ptr %rgep5924, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1195
bb_rcgclear1195:
  %v5925 = load i64, ptr %slot902, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  store i64 0, ptr %p5926, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1195
bb_rcgdone1195:
  br label %bb_rcslotdone1164
bb_rcslotdone1164:
  %v5927 = load i64, ptr %slot17, align 8
  store i64 %v5927, ptr %slot933, align 8
  %v5928 = load i64, ptr %slot933, align 8
  %v5929 = load i64, ptr %slot882, align 8
  %p5930 = inttoptr i64 %v5928 to ptr
  %p5931 = inttoptr i64 %v5929 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5931, ptr %p5930, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5932 = load i64, ptr %slot6, align 8
  %p5933 = inttoptr i64 %v5932 to ptr
  store i32 2, ptr %p5933, align 4, !alias.scope !3, !noalias !4
  %v5934 = load i64, ptr %slot5, align 8
  %p5935 = inttoptr i64 %v5934 to ptr
  store i32 1, ptr %p5935, align 4, !alias.scope !3, !noalias !4
  %v5936 = load i64, ptr %slot13, align 8
  %p5937 = inttoptr i64 %v5936 to ptr
  store i32 0, ptr %p5937, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal1136
bb_rcownedlocal1136:
  %v5938 = load i64, ptr %slot6, align 8
  %p5939 = inttoptr i64 %v5938 to ptr
  store i32 2, ptr %p5939, align 4, !alias.scope !3, !noalias !4
  %v5940 = load i64, ptr %slot877, align 8
  %p5941 = inttoptr i64 %v5940 to ptr
  %ld5942 = load i64, ptr %p5941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5942, ptr %slot934, align 8
  %v5943 = load i64, ptr %slot934, align 8
  %cmp5944 = icmp ne i64 %v5943, 0
  %cv5945 = zext i1 %cmp5944 to i32
  store i32 %cv5945, ptr %slot935, align 8
  %v5946 = load i32, ptr %slot935, align 8
  %cv5947 = zext i32 %v5946 to i64
  %cond5948 = icmp ne i64 %cv5947, 0
  br i1 %cond5948, label %bb_rcguniquenn1204, label %bb_rcgunique1204
bb_rcguniquenn1204:
  %v5949 = load i64, ptr %slot934, align 8
  %op5950 = sub i64 %v5949, 16
  store i64 %op5950, ptr %slot936, align 8
  %v5951 = load i64, ptr %slot934, align 8
  %p5952 = inttoptr i64 %v5951 to ptr
  %rgep5953 = getelementptr i8, ptr %p5952, i64 -16
  %ld5954 = load i64, ptr %rgep5953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5954, ptr %slot937, align 8
  %v5955 = load i64, ptr %slot937, align 8
  %op5956 = and i64 %v5955, 6917529027641081858
  store i64 %op5956, ptr %slot938, align 8
  %v5957 = load i64, ptr %slot938, align 8
  %cmp5958 = icmp ne i64 %v5957, 0
  %cv5959 = zext i1 %cmp5958 to i32
  store i32 %cv5959, ptr %slot939, align 8
  %v5960 = load i32, ptr %slot939, align 8
  %cv5961 = zext i32 %v5960 to i64
  %cond5962 = icmp ne i64 %cv5961, 0
  br i1 %cond5962, label %bb_rcguniqueslow1204, label %bb_rcguniquecount1204
bb_rcguniquecount1204:
  %v5963 = load i64, ptr %slot934, align 8
  %op5964 = sub i64 %v5963, 32
  store i64 %op5964, ptr %slot940, align 8
  %v5965 = load i64, ptr %slot934, align 8
  %p5966 = inttoptr i64 %v5965 to ptr
  %rgep5967 = getelementptr i8, ptr %p5966, i64 -32
  %ld5968 = load i64, ptr %rgep5967, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5968, ptr %slot941, align 8
  %v5969 = load i64, ptr %slot941, align 8
  %cmp5970 = icmp ult i64 %v5969, 2
  %cv5971 = zext i1 %cmp5970 to i32
  store i32 %cv5971, ptr %slot942, align 8
  %v5972 = load i32, ptr %slot942, align 8
  %cv5973 = zext i32 %v5972 to i64
  %cond5974 = icmp ne i64 %cv5973, 0
  br i1 %cond5974, label %bb_rcgunique1204, label %bb_rcguniqueslow1204
bb_rcguniqueslow1204:
  %v5975 = load i64, ptr %slot1, align 8
  %p5976 = inttoptr i64 %v5975 to ptr
  %p5977 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v5978 = load i64, ptr %slot877, align 8
  %p5979 = inttoptr i64 %v5978 to ptr
  %v5980 = load i64, ptr %slot5, align 8
  %p5981 = inttoptr i64 %v5980 to ptr
  %call5982 = call i32 @myl_qbe_rc_unique_local(ptr %p5976, ptr %p5977, ptr %p5979, ptr %p5981) nomerge, !dbg !144
  store i32 %call5982, ptr %slot943, align 8
  %v5983 = load i32, ptr %slot943, align 8
  %cv5984 = zext i32 %v5983 to i64
  %cond5985 = icmp ne i64 %cv5984, 0
  br i1 %cond5985, label %bb_rcunique1215, label %bb_failure
bb_rcunique1215:
  br label %bb_rcgunique1204
bb_rcgunique1204:
  %v5986 = load i64, ptr %slot22, align 8
  %p5987 = inttoptr i64 %v5986 to ptr
  %ld5988 = load i64, ptr %p5987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5988, ptr %slot944, align 8
  %v5989 = load i64, ptr %slot25, align 8
  store i64 %v5989, ptr %slot945, align 8
  %v5990 = load i64, ptr %slot945, align 8
  %p5991 = inttoptr i64 %v5990 to ptr
  %ld5992 = load i64, ptr %p5991, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5992, ptr %slot946, align 8
  %v5993 = load i64, ptr %slot946, align 8
  %v5994 = load i64, ptr %slot18, align 8
  %p5995 = inttoptr i64 %v5994 to ptr
  store i64 %v5993, ptr %p5995, align 8, !alias.scope !3, !noalias !4
  %v5996 = load i64, ptr %slot18, align 8
  store i64 %v5996, ptr %slot947, align 8
  %v5997 = load i64, ptr %slot31, align 8
  %v5998 = load i64, ptr %slot944, align 8
  %v5999 = load i64, ptr %slot947, align 8
  %call6000 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v5997, i64 %v5998, i64 %v5999) nomerge, !dbg !144
  store i32 %call6000, ptr %slot948, align 8
  %v6001 = load i32, ptr %slot948, align 8
  %cv6002 = zext i32 %v6001 to i64
  %cond6003 = icmp ne i64 %cv6002, 0
  br i1 %cond6003, label %bb_success1221, label %bb_failed1221
bb_failed1221:
  %v6004 = load i64, ptr %slot1, align 8
  %p6005 = inttoptr i64 %v6004 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6005) nomerge, !dbg !144
  unreachable
bb_success1221:
  %v6006 = load i64, ptr %slot25, align 8
  %p6007 = inttoptr i64 %v6006 to ptr
  store i64 0, ptr %p6007, align 8, !alias.scope !3, !noalias !4
  %v6008 = load i64, ptr %slot11, align 8
  %p6009 = inttoptr i64 %v6008 to ptr
  %ld6010 = load i32, ptr %p6009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6010, ptr %slot949, align 8
  %v6011 = load i32, ptr %slot949, align 8
  %cv6012 = zext i32 %v6011 to i64
  %cond6013 = icmp ne i64 %cv6012, 0
  br i1 %cond6013, label %bb_rcslotdrop1224, label %bb_rcslotdone1224
bb_rcslotdrop1224:
  %v6014 = load i64, ptr %slot11, align 8
  %p6015 = inttoptr i64 %v6014 to ptr
  store i32 0, ptr %p6015, align 4, !alias.scope !3, !noalias !4
  %v6016 = load i64, ptr %slot15, align 8
  store i64 %v6016, ptr %slot950, align 8
  %v6017 = load i64, ptr %slot12, align 8
  %p6018 = inttoptr i64 %v6017 to ptr
  %ld6019 = load i32, ptr %p6018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6019, ptr %slot951, align 8
  %v6020 = load i32, ptr %slot951, align 8
  %op6021 = and i32 %v6020, 28
  store i32 %op6021, ptr %slot952, align 8
  %v6022 = load i32, ptr %slot952, align 8
  %cv6023 = zext i32 %v6022 to i64
  %cond6024 = icmp ne i64 %cv6023, 0
  br i1 %cond6024, label %bb_rcslotrole1224, label %bb_rcslotowner1224
bb_rcslotrole1224:
  %v6025 = load i64, ptr %slot31, align 8
  store i64 %v6025, ptr %slot953, align 8
  %v6026 = load i64, ptr %slot950, align 8
  %p6027 = inttoptr i64 %v6026 to ptr
  %ld6028 = load i64, ptr %p6027, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6028, ptr %slot954, align 8
  %v6029 = load i64, ptr %slot954, align 8
  %cmp6030 = icmp ne i64 %v6029, 0
  %cv6031 = zext i1 %cmp6030 to i32
  store i32 %cv6031, ptr %slot955, align 8
  %v6032 = load i32, ptr %slot955, align 8
  %cv6033 = zext i32 %v6032 to i64
  %cond6034 = icmp ne i64 %cv6033, 0
  br i1 %cond6034, label %bb_rcgnn1240, label %bb_rcgdone1240
bb_rcgnn1240:
  %v6035 = load i64, ptr %slot954, align 8
  %op6036 = sub i64 %v6035, 16
  store i64 %op6036, ptr %slot956, align 8
  %v6037 = load i64, ptr %slot954, align 8
  %p6038 = inttoptr i64 %v6037 to ptr
  %rgep6039 = getelementptr i8, ptr %p6038, i64 -16
  %ld6040 = load i64, ptr %rgep6039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6040, ptr %slot957, align 8
  %v6041 = load i64, ptr %slot957, align 8
  %op6042 = and i64 %v6041, 4611686018427387906
  store i64 %op6042, ptr %slot958, align 8
  %v6043 = load i64, ptr %slot958, align 8
  %cmp6044 = icmp ne i64 %v6043, 0
  %cv6045 = zext i1 %cmp6044 to i32
  store i32 %cv6045, ptr %slot959, align 8
  %v6046 = load i32, ptr %slot959, align 8
  %cv6047 = zext i32 %v6046 to i64
  %cond6048 = icmp ne i64 %cv6047, 0
  br i1 %cond6048, label %bb_rcgclear1240, label %bb_rcgcounted1240
bb_rcgcounted1240:
  %v6049 = load i64, ptr %slot954, align 8
  %op6050 = sub i64 %v6049, 24
  store i64 %op6050, ptr %slot960, align 8
  %v6051 = load i64, ptr %slot954, align 8
  %p6052 = inttoptr i64 %v6051 to ptr
  %rgep6053 = getelementptr i8, ptr %p6052, i64 -24
  %ld6054 = load i64, ptr %rgep6053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6054, ptr %slot961, align 8
  %v6055 = load i64, ptr %slot961, align 8
  %op6056 = sub i64 %v6055, 1
  store i64 %op6056, ptr %slot962, align 8
  %v6057 = load i64, ptr %slot962, align 8
  %cmp6058 = icmp eq i64 %v6057, 0
  %cv6059 = zext i1 %cmp6058 to i32
  store i32 %cv6059, ptr %slot963, align 8
  %v6060 = load i32, ptr %slot963, align 8
  %cv6061 = zext i32 %v6060 to i64
  %cond6062 = icmp ne i64 %cv6061, 0
  br i1 %cond6062, label %bb_rcglast1240, label %bb_rcgdec1240
bb_rcglast1240:
  %v6063 = load i64, ptr %slot954, align 8
  %op6064 = sub i64 %v6063, 32
  store i64 %op6064, ptr %slot964, align 8
  %v6065 = load i64, ptr %slot954, align 8
  %p6066 = inttoptr i64 %v6065 to ptr
  %rgep6067 = getelementptr i8, ptr %p6066, i64 -32
  %ld6068 = load i64, ptr %rgep6067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6068, ptr %slot965, align 8
  %v6069 = load i64, ptr %slot965, align 8
  %cmp6070 = icmp ne i64 %v6069, 0
  %cv6071 = zext i1 %cmp6070 to i32
  store i32 %cv6071, ptr %slot966, align 8
  %v6072 = load i32, ptr %slot966, align 8
  %cv6073 = zext i32 %v6072 to i64
  %cond6074 = icmp ne i64 %cv6073, 0
  br i1 %cond6074, label %bb_rcgdec1240, label %bb_rcgslow1240
bb_rcgslow1240:
  %v6075 = load i64, ptr %slot953, align 8
  %v6076 = load i64, ptr %slot950, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v6075, i64 %v6076) nomerge, !dbg !144
  br label %bb_rcgdone1240
bb_rcgdec1240:
  %v6077 = load i64, ptr %slot962, align 8
  %v6078 = load i64, ptr %slot954, align 8
  %p6079 = inttoptr i64 %v6078 to ptr
  %rgep6080 = getelementptr i8, ptr %p6079, i64 -24
  store i64 %v6077, ptr %rgep6080, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1240
bb_rcgclear1240:
  %v6081 = load i64, ptr %slot950, align 8
  %p6082 = inttoptr i64 %v6081 to ptr
  store i64 0, ptr %p6082, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1240
bb_rcgdone1240:
  br label %bb_rcslotdone1224
bb_rcslotowner1224:
  %v6083 = load i64, ptr %slot31, align 8
  store i64 %v6083, ptr %slot967, align 8
  %v6084 = load i64, ptr %slot950, align 8
  %p6085 = inttoptr i64 %v6084 to ptr
  %ld6086 = load i64, ptr %p6085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6086, ptr %slot968, align 8
  %v6087 = load i64, ptr %slot968, align 8
  %cmp6088 = icmp ne i64 %v6087, 0
  %cv6089 = zext i1 %cmp6088 to i32
  store i32 %cv6089, ptr %slot969, align 8
  %v6090 = load i32, ptr %slot969, align 8
  %cv6091 = zext i32 %v6090 to i64
  %cond6092 = icmp ne i64 %cv6091, 0
  br i1 %cond6092, label %bb_rcgnn1255, label %bb_rcgdone1255
bb_rcgnn1255:
  %v6093 = load i64, ptr %slot968, align 8
  %op6094 = sub i64 %v6093, 16
  store i64 %op6094, ptr %slot970, align 8
  %v6095 = load i64, ptr %slot968, align 8
  %p6096 = inttoptr i64 %v6095 to ptr
  %rgep6097 = getelementptr i8, ptr %p6096, i64 -16
  %ld6098 = load i64, ptr %rgep6097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6098, ptr %slot971, align 8
  %v6099 = load i64, ptr %slot971, align 8
  %op6100 = and i64 %v6099, 4611686018427387906
  store i64 %op6100, ptr %slot972, align 8
  %v6101 = load i64, ptr %slot972, align 8
  %cmp6102 = icmp ne i64 %v6101, 0
  %cv6103 = zext i1 %cmp6102 to i32
  store i32 %cv6103, ptr %slot973, align 8
  %v6104 = load i32, ptr %slot973, align 8
  %cv6105 = zext i32 %v6104 to i64
  %cond6106 = icmp ne i64 %cv6105, 0
  br i1 %cond6106, label %bb_rcgclear1255, label %bb_rcgcounted1255
bb_rcgcounted1255:
  %v6107 = load i64, ptr %slot968, align 8
  %op6108 = sub i64 %v6107, 32
  store i64 %op6108, ptr %slot974, align 8
  %v6109 = load i64, ptr %slot968, align 8
  %p6110 = inttoptr i64 %v6109 to ptr
  %rgep6111 = getelementptr i8, ptr %p6110, i64 -32
  %ld6112 = load i64, ptr %rgep6111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6112, ptr %slot975, align 8
  %v6113 = load i64, ptr %slot975, align 8
  %op6114 = sub i64 %v6113, 1
  store i64 %op6114, ptr %slot976, align 8
  %v6115 = load i64, ptr %slot976, align 8
  %cmp6116 = icmp eq i64 %v6115, 0
  %cv6117 = zext i1 %cmp6116 to i32
  store i32 %cv6117, ptr %slot977, align 8
  %v6118 = load i32, ptr %slot977, align 8
  %cv6119 = zext i32 %v6118 to i64
  %cond6120 = icmp ne i64 %cv6119, 0
  br i1 %cond6120, label %bb_rcglast1255, label %bb_rcgdec1255
bb_rcglast1255:
  %v6121 = load i64, ptr %slot968, align 8
  %op6122 = sub i64 %v6121, 24
  store i64 %op6122, ptr %slot978, align 8
  %v6123 = load i64, ptr %slot968, align 8
  %p6124 = inttoptr i64 %v6123 to ptr
  %rgep6125 = getelementptr i8, ptr %p6124, i64 -24
  %ld6126 = load i64, ptr %rgep6125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6126, ptr %slot979, align 8
  %v6127 = load i64, ptr %slot979, align 8
  %cmp6128 = icmp ne i64 %v6127, 0
  %cv6129 = zext i1 %cmp6128 to i32
  store i32 %cv6129, ptr %slot980, align 8
  %v6130 = load i32, ptr %slot980, align 8
  %cv6131 = zext i32 %v6130 to i64
  %cond6132 = icmp ne i64 %cv6131, 0
  br i1 %cond6132, label %bb_rcgdec1255, label %bb_rcgslow1255
bb_rcgslow1255:
  %v6133 = load i64, ptr %slot967, align 8
  %v6134 = load i64, ptr %slot950, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v6133, i64 %v6134) nomerge, !dbg !144
  br label %bb_rcgdone1255
bb_rcgdec1255:
  %v6135 = load i64, ptr %slot976, align 8
  %v6136 = load i64, ptr %slot968, align 8
  %p6137 = inttoptr i64 %v6136 to ptr
  %rgep6138 = getelementptr i8, ptr %p6137, i64 -32
  store i64 %v6135, ptr %rgep6138, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1255
bb_rcgclear1255:
  %v6139 = load i64, ptr %slot950, align 8
  %p6140 = inttoptr i64 %v6139 to ptr
  store i64 0, ptr %p6140, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1255
bb_rcgdone1255:
  br label %bb_rcslotdone1224
bb_rcslotdone1224:
  %p6141 = inttoptr i64 ptrtoint (ptr @myl_lit_c24298efef9d84eab8d1ecb612ef258e35c6697e067d3770527afc0b5af176f8 to i64) to ptr
  %ld6142 = load i64, ptr %p6141, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6142, ptr %slot981, align 8
  %v6143 = load i64, ptr %slot981, align 8
  %v6144 = load i64, ptr %slot25, align 8
  %p6145 = inttoptr i64 %v6144 to ptr
  store i64 %v6143, ptr %p6145, align 8, !alias.scope !3, !noalias !4
  %v6146 = load i64, ptr %slot25, align 8
  %p6147 = inttoptr i64 %v6146 to ptr
  %ld6148 = load i64, ptr %p6147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6148, ptr %slot982, align 8
  %v6149 = load i64, ptr %slot982, align 8
  %v6150 = load i64, ptr %slot16, align 8
  %p6151 = inttoptr i64 %v6150 to ptr
  store i64 %v6149, ptr %p6151, align 8, !alias.scope !3, !noalias !4
  %v6152 = load i64, ptr %slot16, align 8
  store i64 %v6152, ptr %slot983, align 8
  %v6153 = load i64, ptr %slot17, align 8
  store i64 %v6153, ptr %slot984, align 8
  %v6154 = load i64, ptr %slot983, align 8
  %v6155 = load i64, ptr %slot984, align 8
  %p6156 = inttoptr i64 %v6154 to ptr
  %p6157 = inttoptr i64 %v6155 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6157, ptr %p6156, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6158 = load i64, ptr %slot14, align 8
  %p6159 = inttoptr i64 %v6158 to ptr
  store i32 2, ptr %p6159, align 4, !alias.scope !3, !noalias !4
  %v6160 = load i64, ptr %slot13, align 8
  %p6161 = inttoptr i64 %v6160 to ptr
  store i32 1, ptr %p6161, align 4, !alias.scope !3, !noalias !4
  %v6162 = load i64, ptr %slot15, align 8
  store i64 %v6162, ptr %slot985, align 8
  %v6163 = load i64, ptr %slot17, align 8
  store i64 %v6163, ptr %slot986, align 8
  %v6164 = load i64, ptr %slot986, align 8
  %v6165 = load i64, ptr %slot985, align 8
  %p6166 = inttoptr i64 %v6164 to ptr
  %p6167 = inttoptr i64 %v6165 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6167, ptr %p6166, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6168 = load i64, ptr %slot12, align 8
  %p6169 = inttoptr i64 %v6168 to ptr
  store i32 2, ptr %p6169, align 4, !alias.scope !3, !noalias !4
  %v6170 = load i64, ptr %slot14, align 8
  %p6171 = inttoptr i64 %v6170 to ptr
  %ld6172 = load i32, ptr %p6171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6172, ptr %slot987, align 8
  %v6173 = load i32, ptr %slot987, align 8
  %v6174 = load i64, ptr %slot12, align 8
  %p6175 = inttoptr i64 %v6174 to ptr
  store i32 %v6173, ptr %p6175, align 4, !alias.scope !3, !noalias !4
  %v6176 = load i64, ptr %slot13, align 8
  %p6177 = inttoptr i64 %v6176 to ptr
  store i32 0, ptr %p6177, align 4, !alias.scope !3, !noalias !4
  %v6178 = load i64, ptr %slot11, align 8
  %p6179 = inttoptr i64 %v6178 to ptr
  store i32 1, ptr %p6179, align 4, !alias.scope !3, !noalias !4
  %v6180 = load i64, ptr %slot985, align 8
  %p6181 = inttoptr i64 %v6180 to ptr
  %ld6182 = load i64, ptr %p6181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6182, ptr %slot988, align 8
  %v6183 = load i64, ptr %slot988, align 8
  %v6184 = load i64, ptr %slot25, align 8
  %p6185 = inttoptr i64 %v6184 to ptr
  store i64 %v6183, ptr %p6185, align 8, !alias.scope !3, !noalias !4
  %v6186 = load i64, ptr %slot22, align 8
  store i64 %v6186, ptr %slot989, align 8
  %v6187 = load i64, ptr %slot6, align 8
  %p6188 = inttoptr i64 %v6187 to ptr
  %ld6189 = load i32, ptr %p6188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6189, ptr %slot990, align 8
  %v6190 = load i32, ptr %slot990, align 8
  %cmp6191 = icmp eq i32 %v6190, 16
  %cv6192 = zext i1 %cmp6191 to i32
  store i32 %cv6192, ptr %slot991, align 8
  %v6193 = load i64, ptr %slot5, align 8
  %p6194 = inttoptr i64 %v6193 to ptr
  %ld6195 = load i32, ptr %p6194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6195, ptr %slot992, align 8
  %v6196 = load i32, ptr %slot992, align 8
  %v6197 = load i32, ptr %slot991, align 8
  %op6198 = and i32 %v6196, %v6197
  store i32 %op6198, ptr %slot993, align 8
  %v6199 = load i32, ptr %slot993, align 8
  %cv6200 = zext i32 %v6199 to i64
  %cond6201 = icmp ne i64 %cv6200, 0
  br i1 %cond6201, label %bb_rcownlocal1281, label %bb_rcownedlocal1281
bb_rcownlocal1281:
  %v6202 = load i64, ptr %slot22, align 8
  store i64 %v6202, ptr %slot994, align 8
  %v6203 = load i64, ptr %slot17, align 8
  store i64 %v6203, ptr %slot995, align 8
  %v6204 = load i64, ptr %slot32, align 8
  store i64 %v6204, ptr %slot996, align 8
  %v6205 = load i64, ptr %slot994, align 8
  %p6206 = inttoptr i64 %v6205 to ptr
  %ld6207 = load i64, ptr %p6206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6207, ptr %slot997, align 8
  %v6208 = load i64, ptr %slot997, align 8
  %cmp6209 = icmp ne i64 %v6208, 0
  %cv6210 = zext i1 %cmp6209 to i32
  store i32 %cv6210, ptr %slot998, align 8
  %v6211 = load i32, ptr %slot998, align 8
  %cv6212 = zext i32 %v6211 to i64
  %cond6213 = icmp ne i64 %cv6212, 0
  br i1 %cond6213, label %bb_rcgnn1288, label %bb_rcgplain1288
bb_rcgnn1288:
  %v6214 = load i64, ptr %slot997, align 8
  %op6215 = sub i64 %v6214, 16
  store i64 %op6215, ptr %slot999, align 8
  %v6216 = load i64, ptr %slot997, align 8
  %p6217 = inttoptr i64 %v6216 to ptr
  %rgep6218 = getelementptr i8, ptr %p6217, i64 -16
  %ld6219 = load i64, ptr %rgep6218, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6219, ptr %slot1000, align 8
  %v6220 = load i64, ptr %slot1000, align 8
  %op6221 = and i64 %v6220, 4611686018427387906
  store i64 %op6221, ptr %slot1001, align 8
  %v6222 = load i64, ptr %slot1001, align 8
  %cmp6223 = icmp ne i64 %v6222, 0
  %cv6224 = zext i1 %cmp6223 to i32
  store i32 %cv6224, ptr %slot1002, align 8
  %v6225 = load i32, ptr %slot1002, align 8
  %cv6226 = zext i32 %v6225 to i64
  %cond6227 = icmp ne i64 %cv6226, 0
  br i1 %cond6227, label %bb_rcgspecial1288, label %bb_rcginc1288
bb_rcginc1288:
  %v6228 = load i64, ptr %slot997, align 8
  %op6229 = sub i64 %v6228, 32
  store i64 %op6229, ptr %slot1003, align 8
  %v6230 = load i64, ptr %slot997, align 8
  %p6231 = inttoptr i64 %v6230 to ptr
  %rgep6232 = getelementptr i8, ptr %p6231, i64 -32
  %ld6233 = load i64, ptr %rgep6232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6233, ptr %slot1004, align 8
  %v6234 = load i64, ptr %slot1004, align 8
  %op6235 = add i64 %v6234, 1
  store i64 %op6235, ptr %slot1005, align 8
  %v6236 = load i64, ptr %slot1005, align 8
  %cmp6237 = icmp eq i64 %v6236, 0
  %cv6238 = zext i1 %cmp6237 to i32
  store i32 %cv6238, ptr %slot1006, align 8
  %v6239 = load i32, ptr %slot1006, align 8
  %cv6240 = zext i32 %v6239 to i64
  %cond6241 = icmp ne i64 %cv6240, 0
  br i1 %cond6241, label %bb_rcglimit1288, label %bb_rcgcapacity1288
bb_rcglimit1288:
  %v6242 = load i64, ptr %slot1, align 8
  %p6243 = inttoptr i64 %v6242 to ptr
  %call6244 = call i32 @myl_qbe_rc_status(ptr %p6243, i32 2) nomerge, !dbg !146
  store i32 %call6244, ptr %slot1007, align 8
  br label %bb_failure
bb_rcgcapacity1288:
  %v6245 = load i64, ptr %slot1005, align 8
  %v6246 = load i64, ptr %slot997, align 8
  %p6247 = inttoptr i64 %v6246 to ptr
  %rgep6248 = getelementptr i8, ptr %p6247, i64 -32
  store i64 %v6245, ptr %rgep6248, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1288
bb_rcgspecial1288:
  %v6249 = load i64, ptr %slot1000, align 8
  %op6250 = and i64 %v6249, 4611686018427387904
  store i64 %op6250, ptr %slot1008, align 8
  %v6251 = load i64, ptr %slot1008, align 8
  %cmp6252 = icmp ne i64 %v6251, 0
  %cv6253 = zext i1 %cmp6252 to i32
  store i32 %cv6253, ptr %slot1009, align 8
  %v6254 = load i32, ptr %slot1009, align 8
  %cv6255 = zext i32 %v6254 to i64
  %cond6256 = icmp ne i64 %cv6255, 0
  br i1 %cond6256, label %bb_rcgslow1288, label %bb_rcgplain1288
bb_rcgslow1288:
  %v6257 = load i64, ptr %slot31, align 8
  %v6258 = load i64, ptr %slot995, align 8
  %v6259 = load i64, ptr %slot994, align 8
  %v6260 = load i64, ptr %slot996, align 8
  %cv6261 = trunc i64 %v6260 to i32
  %call6262 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v6257, i64 %v6258, i64 %v6259, i32 %cv6261) nomerge, !dbg !146
  store i32 %call6262, ptr %slot1010, align 8
  %v6263 = load i32, ptr %slot1010, align 8
  %cv6264 = zext i32 %v6263 to i64
  %cond6265 = icmp ne i64 %cv6264, 0
  br i1 %cond6265, label %bb_rcsuccess1302, label %bb_rcfailure1302
bb_rcfailure1302:
  %v6266 = load i64, ptr %slot31, align 8
  %p6267 = inttoptr i64 %v6266 to ptr
  %call6268 = call i32 @myl_rc_take_failure(ptr %p6267) nomerge, !dbg !146
  store i32 %call6268, ptr %slot1011, align 8
  %v6269 = load i64, ptr %slot1, align 8
  %p6270 = inttoptr i64 %v6269 to ptr
  %v6271 = load i32, ptr %slot1011, align 8
  %call6272 = call i32 @myl_qbe_rc_status(ptr %p6270, i32 %v6271) nomerge, !dbg !146
  store i32 %call6272, ptr %slot1012, align 8
  br label %bb_failure
bb_rcsuccess1302:
  br label %bb_rcgdone1288
bb_rcgplain1288:
  %v6273 = load i64, ptr %slot997, align 8
  %v6274 = load i64, ptr %slot995, align 8
  %p6275 = inttoptr i64 %v6274 to ptr
  store i64 %v6273, ptr %p6275, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1288
bb_rcgdone1288:
  %v6276 = load i64, ptr %slot14, align 8
  %p6277 = inttoptr i64 %v6276 to ptr
  store i32 2, ptr %p6277, align 4, !alias.scope !3, !noalias !4
  %v6278 = load i64, ptr %slot13, align 8
  %p6279 = inttoptr i64 %v6278 to ptr
  store i32 1, ptr %p6279, align 4, !alias.scope !3, !noalias !4
  %v6280 = load i64, ptr %slot5, align 8
  %p6281 = inttoptr i64 %v6280 to ptr
  %ld6282 = load i32, ptr %p6281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6282, ptr %slot1013, align 8
  %v6283 = load i32, ptr %slot1013, align 8
  %cv6284 = zext i32 %v6283 to i64
  %cond6285 = icmp ne i64 %cv6284, 0
  br i1 %cond6285, label %bb_rcslotdrop1309, label %bb_rcslotdone1309
bb_rcslotdrop1309:
  %v6286 = load i64, ptr %slot5, align 8
  %p6287 = inttoptr i64 %v6286 to ptr
  store i32 0, ptr %p6287, align 4, !alias.scope !3, !noalias !4
  %v6288 = load i64, ptr %slot22, align 8
  store i64 %v6288, ptr %slot1014, align 8
  %v6289 = load i64, ptr %slot6, align 8
  %p6290 = inttoptr i64 %v6289 to ptr
  %ld6291 = load i32, ptr %p6290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6291, ptr %slot1015, align 8
  %v6292 = load i32, ptr %slot1015, align 8
  %op6293 = and i32 %v6292, 28
  store i32 %op6293, ptr %slot1016, align 8
  %v6294 = load i32, ptr %slot1016, align 8
  %cv6295 = zext i32 %v6294 to i64
  %cond6296 = icmp ne i64 %cv6295, 0
  br i1 %cond6296, label %bb_rcslotrole1309, label %bb_rcslotowner1309
bb_rcslotrole1309:
  %v6297 = load i64, ptr %slot31, align 8
  store i64 %v6297, ptr %slot1017, align 8
  %v6298 = load i64, ptr %slot1014, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  %ld6300 = load i64, ptr %p6299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6300, ptr %slot1018, align 8
  %v6301 = load i64, ptr %slot1018, align 8
  %cmp6302 = icmp ne i64 %v6301, 0
  %cv6303 = zext i1 %cmp6302 to i32
  store i32 %cv6303, ptr %slot1019, align 8
  %v6304 = load i32, ptr %slot1019, align 8
  %cv6305 = zext i32 %v6304 to i64
  %cond6306 = icmp ne i64 %cv6305, 0
  br i1 %cond6306, label %bb_rcgnn1325, label %bb_rcgdone1325
bb_rcgnn1325:
  %v6307 = load i64, ptr %slot1018, align 8
  %op6308 = sub i64 %v6307, 16
  store i64 %op6308, ptr %slot1020, align 8
  %v6309 = load i64, ptr %slot1018, align 8
  %p6310 = inttoptr i64 %v6309 to ptr
  %rgep6311 = getelementptr i8, ptr %p6310, i64 -16
  %ld6312 = load i64, ptr %rgep6311, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6312, ptr %slot1021, align 8
  %v6313 = load i64, ptr %slot1021, align 8
  %op6314 = and i64 %v6313, 4611686018427387906
  store i64 %op6314, ptr %slot1022, align 8
  %v6315 = load i64, ptr %slot1022, align 8
  %cmp6316 = icmp ne i64 %v6315, 0
  %cv6317 = zext i1 %cmp6316 to i32
  store i32 %cv6317, ptr %slot1023, align 8
  %v6318 = load i32, ptr %slot1023, align 8
  %cv6319 = zext i32 %v6318 to i64
  %cond6320 = icmp ne i64 %cv6319, 0
  br i1 %cond6320, label %bb_rcgclear1325, label %bb_rcgcounted1325
bb_rcgcounted1325:
  %v6321 = load i64, ptr %slot1018, align 8
  %op6322 = sub i64 %v6321, 24
  store i64 %op6322, ptr %slot1024, align 8
  %v6323 = load i64, ptr %slot1018, align 8
  %p6324 = inttoptr i64 %v6323 to ptr
  %rgep6325 = getelementptr i8, ptr %p6324, i64 -24
  %ld6326 = load i64, ptr %rgep6325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6326, ptr %slot1025, align 8
  %v6327 = load i64, ptr %slot1025, align 8
  %op6328 = sub i64 %v6327, 1
  store i64 %op6328, ptr %slot1026, align 8
  %v6329 = load i64, ptr %slot1026, align 8
  %cmp6330 = icmp eq i64 %v6329, 0
  %cv6331 = zext i1 %cmp6330 to i32
  store i32 %cv6331, ptr %slot1027, align 8
  %v6332 = load i32, ptr %slot1027, align 8
  %cv6333 = zext i32 %v6332 to i64
  %cond6334 = icmp ne i64 %cv6333, 0
  br i1 %cond6334, label %bb_rcglast1325, label %bb_rcgdec1325
bb_rcglast1325:
  %v6335 = load i64, ptr %slot1018, align 8
  %op6336 = sub i64 %v6335, 32
  store i64 %op6336, ptr %slot1028, align 8
  %v6337 = load i64, ptr %slot1018, align 8
  %p6338 = inttoptr i64 %v6337 to ptr
  %rgep6339 = getelementptr i8, ptr %p6338, i64 -32
  %ld6340 = load i64, ptr %rgep6339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6340, ptr %slot1029, align 8
  %v6341 = load i64, ptr %slot1029, align 8
  %cmp6342 = icmp ne i64 %v6341, 0
  %cv6343 = zext i1 %cmp6342 to i32
  store i32 %cv6343, ptr %slot1030, align 8
  %v6344 = load i32, ptr %slot1030, align 8
  %cv6345 = zext i32 %v6344 to i64
  %cond6346 = icmp ne i64 %cv6345, 0
  br i1 %cond6346, label %bb_rcgdec1325, label %bb_rcgslow1325
bb_rcgslow1325:
  %v6347 = load i64, ptr %slot1017, align 8
  %v6348 = load i64, ptr %slot1014, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v6347, i64 %v6348) nomerge, !dbg !146
  br label %bb_rcgdone1325
bb_rcgdec1325:
  %v6349 = load i64, ptr %slot1026, align 8
  %v6350 = load i64, ptr %slot1018, align 8
  %p6351 = inttoptr i64 %v6350 to ptr
  %rgep6352 = getelementptr i8, ptr %p6351, i64 -24
  store i64 %v6349, ptr %rgep6352, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1325
bb_rcgclear1325:
  %v6353 = load i64, ptr %slot1014, align 8
  %p6354 = inttoptr i64 %v6353 to ptr
  store i64 0, ptr %p6354, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1325
bb_rcgdone1325:
  br label %bb_rcslotdone1309
bb_rcslotowner1309:
  %v6355 = load i64, ptr %slot31, align 8
  store i64 %v6355, ptr %slot1031, align 8
  %v6356 = load i64, ptr %slot1014, align 8
  %p6357 = inttoptr i64 %v6356 to ptr
  %ld6358 = load i64, ptr %p6357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6358, ptr %slot1032, align 8
  %v6359 = load i64, ptr %slot1032, align 8
  %cmp6360 = icmp ne i64 %v6359, 0
  %cv6361 = zext i1 %cmp6360 to i32
  store i32 %cv6361, ptr %slot1033, align 8
  %v6362 = load i32, ptr %slot1033, align 8
  %cv6363 = zext i32 %v6362 to i64
  %cond6364 = icmp ne i64 %cv6363, 0
  br i1 %cond6364, label %bb_rcgnn1340, label %bb_rcgdone1340
bb_rcgnn1340:
  %v6365 = load i64, ptr %slot1032, align 8
  %op6366 = sub i64 %v6365, 16
  store i64 %op6366, ptr %slot1034, align 8
  %v6367 = load i64, ptr %slot1032, align 8
  %p6368 = inttoptr i64 %v6367 to ptr
  %rgep6369 = getelementptr i8, ptr %p6368, i64 -16
  %ld6370 = load i64, ptr %rgep6369, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6370, ptr %slot1035, align 8
  %v6371 = load i64, ptr %slot1035, align 8
  %op6372 = and i64 %v6371, 4611686018427387906
  store i64 %op6372, ptr %slot1036, align 8
  %v6373 = load i64, ptr %slot1036, align 8
  %cmp6374 = icmp ne i64 %v6373, 0
  %cv6375 = zext i1 %cmp6374 to i32
  store i32 %cv6375, ptr %slot1037, align 8
  %v6376 = load i32, ptr %slot1037, align 8
  %cv6377 = zext i32 %v6376 to i64
  %cond6378 = icmp ne i64 %cv6377, 0
  br i1 %cond6378, label %bb_rcgclear1340, label %bb_rcgcounted1340
bb_rcgcounted1340:
  %v6379 = load i64, ptr %slot1032, align 8
  %op6380 = sub i64 %v6379, 32
  store i64 %op6380, ptr %slot1038, align 8
  %v6381 = load i64, ptr %slot1032, align 8
  %p6382 = inttoptr i64 %v6381 to ptr
  %rgep6383 = getelementptr i8, ptr %p6382, i64 -32
  %ld6384 = load i64, ptr %rgep6383, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6384, ptr %slot1039, align 8
  %v6385 = load i64, ptr %slot1039, align 8
  %op6386 = sub i64 %v6385, 1
  store i64 %op6386, ptr %slot1040, align 8
  %v6387 = load i64, ptr %slot1040, align 8
  %cmp6388 = icmp eq i64 %v6387, 0
  %cv6389 = zext i1 %cmp6388 to i32
  store i32 %cv6389, ptr %slot1041, align 8
  %v6390 = load i32, ptr %slot1041, align 8
  %cv6391 = zext i32 %v6390 to i64
  %cond6392 = icmp ne i64 %cv6391, 0
  br i1 %cond6392, label %bb_rcglast1340, label %bb_rcgdec1340
bb_rcglast1340:
  %v6393 = load i64, ptr %slot1032, align 8
  %op6394 = sub i64 %v6393, 24
  store i64 %op6394, ptr %slot1042, align 8
  %v6395 = load i64, ptr %slot1032, align 8
  %p6396 = inttoptr i64 %v6395 to ptr
  %rgep6397 = getelementptr i8, ptr %p6396, i64 -24
  %ld6398 = load i64, ptr %rgep6397, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6398, ptr %slot1043, align 8
  %v6399 = load i64, ptr %slot1043, align 8
  %cmp6400 = icmp ne i64 %v6399, 0
  %cv6401 = zext i1 %cmp6400 to i32
  store i32 %cv6401, ptr %slot1044, align 8
  %v6402 = load i32, ptr %slot1044, align 8
  %cv6403 = zext i32 %v6402 to i64
  %cond6404 = icmp ne i64 %cv6403, 0
  br i1 %cond6404, label %bb_rcgdec1340, label %bb_rcgslow1340
bb_rcgslow1340:
  %v6405 = load i64, ptr %slot1031, align 8
  %v6406 = load i64, ptr %slot1014, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v6405, i64 %v6406) nomerge, !dbg !146
  br label %bb_rcgdone1340
bb_rcgdec1340:
  %v6407 = load i64, ptr %slot1040, align 8
  %v6408 = load i64, ptr %slot1032, align 8
  %p6409 = inttoptr i64 %v6408 to ptr
  %rgep6410 = getelementptr i8, ptr %p6409, i64 -32
  store i64 %v6407, ptr %rgep6410, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1340
bb_rcgclear1340:
  %v6411 = load i64, ptr %slot1014, align 8
  %p6412 = inttoptr i64 %v6411 to ptr
  store i64 0, ptr %p6412, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1340
bb_rcgdone1340:
  br label %bb_rcslotdone1309
bb_rcslotdone1309:
  %v6413 = load i64, ptr %slot17, align 8
  store i64 %v6413, ptr %slot1045, align 8
  %v6414 = load i64, ptr %slot1045, align 8
  %v6415 = load i64, ptr %slot994, align 8
  %p6416 = inttoptr i64 %v6414 to ptr
  %p6417 = inttoptr i64 %v6415 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6417, ptr %p6416, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6418 = load i64, ptr %slot6, align 8
  %p6419 = inttoptr i64 %v6418 to ptr
  store i32 2, ptr %p6419, align 4, !alias.scope !3, !noalias !4
  %v6420 = load i64, ptr %slot5, align 8
  %p6421 = inttoptr i64 %v6420 to ptr
  store i32 1, ptr %p6421, align 4, !alias.scope !3, !noalias !4
  %v6422 = load i64, ptr %slot13, align 8
  %p6423 = inttoptr i64 %v6422 to ptr
  store i32 0, ptr %p6423, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal1281
bb_rcownedlocal1281:
  %v6424 = load i64, ptr %slot6, align 8
  %p6425 = inttoptr i64 %v6424 to ptr
  store i32 2, ptr %p6425, align 4, !alias.scope !3, !noalias !4
  %v6426 = load i64, ptr %slot989, align 8
  %p6427 = inttoptr i64 %v6426 to ptr
  %ld6428 = load i64, ptr %p6427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6428, ptr %slot1046, align 8
  %v6429 = load i64, ptr %slot1046, align 8
  %cmp6430 = icmp ne i64 %v6429, 0
  %cv6431 = zext i1 %cmp6430 to i32
  store i32 %cv6431, ptr %slot1047, align 8
  %v6432 = load i32, ptr %slot1047, align 8
  %cv6433 = zext i32 %v6432 to i64
  %cond6434 = icmp ne i64 %cv6433, 0
  br i1 %cond6434, label %bb_rcguniquenn1349, label %bb_rcgunique1349
bb_rcguniquenn1349:
  %v6435 = load i64, ptr %slot1046, align 8
  %op6436 = sub i64 %v6435, 16
  store i64 %op6436, ptr %slot1048, align 8
  %v6437 = load i64, ptr %slot1046, align 8
  %p6438 = inttoptr i64 %v6437 to ptr
  %rgep6439 = getelementptr i8, ptr %p6438, i64 -16
  %ld6440 = load i64, ptr %rgep6439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6440, ptr %slot1049, align 8
  %v6441 = load i64, ptr %slot1049, align 8
  %op6442 = and i64 %v6441, 6917529027641081858
  store i64 %op6442, ptr %slot1050, align 8
  %v6443 = load i64, ptr %slot1050, align 8
  %cmp6444 = icmp ne i64 %v6443, 0
  %cv6445 = zext i1 %cmp6444 to i32
  store i32 %cv6445, ptr %slot1051, align 8
  %v6446 = load i32, ptr %slot1051, align 8
  %cv6447 = zext i32 %v6446 to i64
  %cond6448 = icmp ne i64 %cv6447, 0
  br i1 %cond6448, label %bb_rcguniqueslow1349, label %bb_rcguniquecount1349
bb_rcguniquecount1349:
  %v6449 = load i64, ptr %slot1046, align 8
  %op6450 = sub i64 %v6449, 32
  store i64 %op6450, ptr %slot1052, align 8
  %v6451 = load i64, ptr %slot1046, align 8
  %p6452 = inttoptr i64 %v6451 to ptr
  %rgep6453 = getelementptr i8, ptr %p6452, i64 -32
  %ld6454 = load i64, ptr %rgep6453, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6454, ptr %slot1053, align 8
  %v6455 = load i64, ptr %slot1053, align 8
  %cmp6456 = icmp ult i64 %v6455, 2
  %cv6457 = zext i1 %cmp6456 to i32
  store i32 %cv6457, ptr %slot1054, align 8
  %v6458 = load i32, ptr %slot1054, align 8
  %cv6459 = zext i32 %v6458 to i64
  %cond6460 = icmp ne i64 %cv6459, 0
  br i1 %cond6460, label %bb_rcgunique1349, label %bb_rcguniqueslow1349
bb_rcguniqueslow1349:
  %v6461 = load i64, ptr %slot1, align 8
  %p6462 = inttoptr i64 %v6461 to ptr
  %p6463 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v6464 = load i64, ptr %slot989, align 8
  %p6465 = inttoptr i64 %v6464 to ptr
  %v6466 = load i64, ptr %slot5, align 8
  %p6467 = inttoptr i64 %v6466 to ptr
  %call6468 = call i32 @myl_qbe_rc_unique_local(ptr %p6462, ptr %p6463, ptr %p6465, ptr %p6467) nomerge, !dbg !146
  store i32 %call6468, ptr %slot1055, align 8
  %v6469 = load i32, ptr %slot1055, align 8
  %cv6470 = zext i32 %v6469 to i64
  %cond6471 = icmp ne i64 %cv6470, 0
  br i1 %cond6471, label %bb_rcunique1360, label %bb_failure
bb_rcunique1360:
  br label %bb_rcgunique1349
bb_rcgunique1349:
  %v6472 = load i64, ptr %slot22, align 8
  %p6473 = inttoptr i64 %v6472 to ptr
  %ld6474 = load i64, ptr %p6473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6474, ptr %slot1056, align 8
  %v6475 = load i64, ptr %slot25, align 8
  store i64 %v6475, ptr %slot1057, align 8
  %v6476 = load i64, ptr %slot1057, align 8
  %p6477 = inttoptr i64 %v6476 to ptr
  %ld6478 = load i64, ptr %p6477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6478, ptr %slot1058, align 8
  %v6479 = load i64, ptr %slot1058, align 8
  %v6480 = load i64, ptr %slot18, align 8
  %p6481 = inttoptr i64 %v6480 to ptr
  store i64 %v6479, ptr %p6481, align 8, !alias.scope !3, !noalias !4
  %v6482 = load i64, ptr %slot18, align 8
  store i64 %v6482, ptr %slot1059, align 8
  %v6483 = load i64, ptr %slot31, align 8
  %v6484 = load i64, ptr %slot1056, align 8
  %v6485 = load i64, ptr %slot1059, align 8
  %call6486 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v6483, i64 %v6484, i64 %v6485) nomerge, !dbg !146
  store i32 %call6486, ptr %slot1060, align 8
  %v6487 = load i32, ptr %slot1060, align 8
  %cv6488 = zext i32 %v6487 to i64
  %cond6489 = icmp ne i64 %cv6488, 0
  br i1 %cond6489, label %bb_success1366, label %bb_failed1366
bb_failed1366:
  %v6490 = load i64, ptr %slot1, align 8
  %p6491 = inttoptr i64 %v6490 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6491) nomerge, !dbg !146
  unreachable
bb_success1366:
  %v6492 = load i64, ptr %slot25, align 8
  %p6493 = inttoptr i64 %v6492 to ptr
  store i64 0, ptr %p6493, align 8, !alias.scope !3, !noalias !4
  %v6494 = load i64, ptr %slot11, align 8
  %p6495 = inttoptr i64 %v6494 to ptr
  %ld6496 = load i32, ptr %p6495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6496, ptr %slot1061, align 8
  %v6497 = load i32, ptr %slot1061, align 8
  %cv6498 = zext i32 %v6497 to i64
  %cond6499 = icmp ne i64 %cv6498, 0
  br i1 %cond6499, label %bb_rcslotdrop1369, label %bb_rcslotdone1369
bb_rcslotdrop1369:
  %v6500 = load i64, ptr %slot11, align 8
  %p6501 = inttoptr i64 %v6500 to ptr
  store i32 0, ptr %p6501, align 4, !alias.scope !3, !noalias !4
  %v6502 = load i64, ptr %slot15, align 8
  store i64 %v6502, ptr %slot1062, align 8
  %v6503 = load i64, ptr %slot12, align 8
  %p6504 = inttoptr i64 %v6503 to ptr
  %ld6505 = load i32, ptr %p6504, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6505, ptr %slot1063, align 8
  %v6506 = load i32, ptr %slot1063, align 8
  %op6507 = and i32 %v6506, 28
  store i32 %op6507, ptr %slot1064, align 8
  %v6508 = load i32, ptr %slot1064, align 8
  %cv6509 = zext i32 %v6508 to i64
  %cond6510 = icmp ne i64 %cv6509, 0
  br i1 %cond6510, label %bb_rcslotrole1369, label %bb_rcslotowner1369
bb_rcslotrole1369:
  %v6511 = load i64, ptr %slot31, align 8
  store i64 %v6511, ptr %slot1065, align 8
  %v6512 = load i64, ptr %slot1062, align 8
  %p6513 = inttoptr i64 %v6512 to ptr
  %ld6514 = load i64, ptr %p6513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6514, ptr %slot1066, align 8
  %v6515 = load i64, ptr %slot1066, align 8
  %cmp6516 = icmp ne i64 %v6515, 0
  %cv6517 = zext i1 %cmp6516 to i32
  store i32 %cv6517, ptr %slot1067, align 8
  %v6518 = load i32, ptr %slot1067, align 8
  %cv6519 = zext i32 %v6518 to i64
  %cond6520 = icmp ne i64 %cv6519, 0
  br i1 %cond6520, label %bb_rcgnn1385, label %bb_rcgdone1385
bb_rcgnn1385:
  %v6521 = load i64, ptr %slot1066, align 8
  %op6522 = sub i64 %v6521, 16
  store i64 %op6522, ptr %slot1068, align 8
  %v6523 = load i64, ptr %slot1066, align 8
  %p6524 = inttoptr i64 %v6523 to ptr
  %rgep6525 = getelementptr i8, ptr %p6524, i64 -16
  %ld6526 = load i64, ptr %rgep6525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6526, ptr %slot1069, align 8
  %v6527 = load i64, ptr %slot1069, align 8
  %op6528 = and i64 %v6527, 4611686018427387906
  store i64 %op6528, ptr %slot1070, align 8
  %v6529 = load i64, ptr %slot1070, align 8
  %cmp6530 = icmp ne i64 %v6529, 0
  %cv6531 = zext i1 %cmp6530 to i32
  store i32 %cv6531, ptr %slot1071, align 8
  %v6532 = load i32, ptr %slot1071, align 8
  %cv6533 = zext i32 %v6532 to i64
  %cond6534 = icmp ne i64 %cv6533, 0
  br i1 %cond6534, label %bb_rcgclear1385, label %bb_rcgcounted1385
bb_rcgcounted1385:
  %v6535 = load i64, ptr %slot1066, align 8
  %op6536 = sub i64 %v6535, 24
  store i64 %op6536, ptr %slot1072, align 8
  %v6537 = load i64, ptr %slot1066, align 8
  %p6538 = inttoptr i64 %v6537 to ptr
  %rgep6539 = getelementptr i8, ptr %p6538, i64 -24
  %ld6540 = load i64, ptr %rgep6539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6540, ptr %slot1073, align 8
  %v6541 = load i64, ptr %slot1073, align 8
  %op6542 = sub i64 %v6541, 1
  store i64 %op6542, ptr %slot1074, align 8
  %v6543 = load i64, ptr %slot1074, align 8
  %cmp6544 = icmp eq i64 %v6543, 0
  %cv6545 = zext i1 %cmp6544 to i32
  store i32 %cv6545, ptr %slot1075, align 8
  %v6546 = load i32, ptr %slot1075, align 8
  %cv6547 = zext i32 %v6546 to i64
  %cond6548 = icmp ne i64 %cv6547, 0
  br i1 %cond6548, label %bb_rcglast1385, label %bb_rcgdec1385
bb_rcglast1385:
  %v6549 = load i64, ptr %slot1066, align 8
  %op6550 = sub i64 %v6549, 32
  store i64 %op6550, ptr %slot1076, align 8
  %v6551 = load i64, ptr %slot1066, align 8
  %p6552 = inttoptr i64 %v6551 to ptr
  %rgep6553 = getelementptr i8, ptr %p6552, i64 -32
  %ld6554 = load i64, ptr %rgep6553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6554, ptr %slot1077, align 8
  %v6555 = load i64, ptr %slot1077, align 8
  %cmp6556 = icmp ne i64 %v6555, 0
  %cv6557 = zext i1 %cmp6556 to i32
  store i32 %cv6557, ptr %slot1078, align 8
  %v6558 = load i32, ptr %slot1078, align 8
  %cv6559 = zext i32 %v6558 to i64
  %cond6560 = icmp ne i64 %cv6559, 0
  br i1 %cond6560, label %bb_rcgdec1385, label %bb_rcgslow1385
bb_rcgslow1385:
  %v6561 = load i64, ptr %slot1065, align 8
  %v6562 = load i64, ptr %slot1062, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v6561, i64 %v6562) nomerge, !dbg !146
  br label %bb_rcgdone1385
bb_rcgdec1385:
  %v6563 = load i64, ptr %slot1074, align 8
  %v6564 = load i64, ptr %slot1066, align 8
  %p6565 = inttoptr i64 %v6564 to ptr
  %rgep6566 = getelementptr i8, ptr %p6565, i64 -24
  store i64 %v6563, ptr %rgep6566, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1385
bb_rcgclear1385:
  %v6567 = load i64, ptr %slot1062, align 8
  %p6568 = inttoptr i64 %v6567 to ptr
  store i64 0, ptr %p6568, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1385
bb_rcgdone1385:
  br label %bb_rcslotdone1369
bb_rcslotowner1369:
  %v6569 = load i64, ptr %slot31, align 8
  store i64 %v6569, ptr %slot1079, align 8
  %v6570 = load i64, ptr %slot1062, align 8
  %p6571 = inttoptr i64 %v6570 to ptr
  %ld6572 = load i64, ptr %p6571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6572, ptr %slot1080, align 8
  %v6573 = load i64, ptr %slot1080, align 8
  %cmp6574 = icmp ne i64 %v6573, 0
  %cv6575 = zext i1 %cmp6574 to i32
  store i32 %cv6575, ptr %slot1081, align 8
  %v6576 = load i32, ptr %slot1081, align 8
  %cv6577 = zext i32 %v6576 to i64
  %cond6578 = icmp ne i64 %cv6577, 0
  br i1 %cond6578, label %bb_rcgnn1400, label %bb_rcgdone1400
bb_rcgnn1400:
  %v6579 = load i64, ptr %slot1080, align 8
  %op6580 = sub i64 %v6579, 16
  store i64 %op6580, ptr %slot1082, align 8
  %v6581 = load i64, ptr %slot1080, align 8
  %p6582 = inttoptr i64 %v6581 to ptr
  %rgep6583 = getelementptr i8, ptr %p6582, i64 -16
  %ld6584 = load i64, ptr %rgep6583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6584, ptr %slot1083, align 8
  %v6585 = load i64, ptr %slot1083, align 8
  %op6586 = and i64 %v6585, 4611686018427387906
  store i64 %op6586, ptr %slot1084, align 8
  %v6587 = load i64, ptr %slot1084, align 8
  %cmp6588 = icmp ne i64 %v6587, 0
  %cv6589 = zext i1 %cmp6588 to i32
  store i32 %cv6589, ptr %slot1085, align 8
  %v6590 = load i32, ptr %slot1085, align 8
  %cv6591 = zext i32 %v6590 to i64
  %cond6592 = icmp ne i64 %cv6591, 0
  br i1 %cond6592, label %bb_rcgclear1400, label %bb_rcgcounted1400
bb_rcgcounted1400:
  %v6593 = load i64, ptr %slot1080, align 8
  %op6594 = sub i64 %v6593, 32
  store i64 %op6594, ptr %slot1086, align 8
  %v6595 = load i64, ptr %slot1080, align 8
  %p6596 = inttoptr i64 %v6595 to ptr
  %rgep6597 = getelementptr i8, ptr %p6596, i64 -32
  %ld6598 = load i64, ptr %rgep6597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6598, ptr %slot1087, align 8
  %v6599 = load i64, ptr %slot1087, align 8
  %op6600 = sub i64 %v6599, 1
  store i64 %op6600, ptr %slot1088, align 8
  %v6601 = load i64, ptr %slot1088, align 8
  %cmp6602 = icmp eq i64 %v6601, 0
  %cv6603 = zext i1 %cmp6602 to i32
  store i32 %cv6603, ptr %slot1089, align 8
  %v6604 = load i32, ptr %slot1089, align 8
  %cv6605 = zext i32 %v6604 to i64
  %cond6606 = icmp ne i64 %cv6605, 0
  br i1 %cond6606, label %bb_rcglast1400, label %bb_rcgdec1400
bb_rcglast1400:
  %v6607 = load i64, ptr %slot1080, align 8
  %op6608 = sub i64 %v6607, 24
  store i64 %op6608, ptr %slot1090, align 8
  %v6609 = load i64, ptr %slot1080, align 8
  %p6610 = inttoptr i64 %v6609 to ptr
  %rgep6611 = getelementptr i8, ptr %p6610, i64 -24
  %ld6612 = load i64, ptr %rgep6611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6612, ptr %slot1091, align 8
  %v6613 = load i64, ptr %slot1091, align 8
  %cmp6614 = icmp ne i64 %v6613, 0
  %cv6615 = zext i1 %cmp6614 to i32
  store i32 %cv6615, ptr %slot1092, align 8
  %v6616 = load i32, ptr %slot1092, align 8
  %cv6617 = zext i32 %v6616 to i64
  %cond6618 = icmp ne i64 %cv6617, 0
  br i1 %cond6618, label %bb_rcgdec1400, label %bb_rcgslow1400
bb_rcgslow1400:
  %v6619 = load i64, ptr %slot1079, align 8
  %v6620 = load i64, ptr %slot1062, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v6619, i64 %v6620) nomerge, !dbg !146
  br label %bb_rcgdone1400
bb_rcgdec1400:
  %v6621 = load i64, ptr %slot1088, align 8
  %v6622 = load i64, ptr %slot1080, align 8
  %p6623 = inttoptr i64 %v6622 to ptr
  %rgep6624 = getelementptr i8, ptr %p6623, i64 -32
  store i64 %v6621, ptr %rgep6624, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1400
bb_rcgclear1400:
  %v6625 = load i64, ptr %slot1062, align 8
  %p6626 = inttoptr i64 %v6625 to ptr
  store i64 0, ptr %p6626, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1400
bb_rcgdone1400:
  br label %bb_rcslotdone1369
bb_rcslotdone1369:
  %v6627 = load i64, ptr %slot19, align 8
  %p6628 = inttoptr i64 %v6627 to ptr
  %ld6629 = load i64, ptr %p6628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6629, ptr %slot1093, align 8
  %v6630 = load i64, ptr %slot1093, align 8
  %v6631 = load i64, ptr %slot25, align 8
  %p6632 = inttoptr i64 %v6631 to ptr
  store i64 %v6630, ptr %p6632, align 8, !alias.scope !3, !noalias !4
  %v6633 = load i64, ptr %slot25, align 8
  %p6634 = inttoptr i64 %v6633 to ptr
  %ld6635 = load i64, ptr %p6634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6635, ptr %slot1094, align 8
  %v6636 = load i64, ptr %slot1094, align 8
  %op6637 = add i64 %v6636, 112
  store i64 %op6637, ptr %slot1095, align 8
  %v6638 = load i64, ptr %slot1095, align 8
  %p6639 = inttoptr i64 %v6638 to ptr
  %ld6640 = load i64, ptr %p6639, align 8
  store i64 %ld6640, ptr %slot1096, align 8
  %v6641 = load i64, ptr %slot1096, align 8
  %v6642 = load i64, ptr %slot25, align 8
  %p6643 = inttoptr i64 %v6642 to ptr
  store i64 %v6641, ptr %p6643, align 8, !alias.scope !3, !noalias !4
  %v6644 = load i64, ptr %slot11, align 8
  %p6645 = inttoptr i64 %v6644 to ptr
  %ld6646 = load i32, ptr %p6645, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6646, ptr %slot1097, align 8
  %v6647 = load i32, ptr %slot1097, align 8
  %cv6648 = zext i32 %v6647 to i64
  %cond6649 = icmp ne i64 %cv6648, 0
  br i1 %cond6649, label %bb_rcslotdrop1410, label %bb_rcslotdone1410
bb_rcslotdrop1410:
  %v6650 = load i64, ptr %slot11, align 8
  %p6651 = inttoptr i64 %v6650 to ptr
  store i32 0, ptr %p6651, align 4, !alias.scope !3, !noalias !4
  %v6652 = load i64, ptr %slot15, align 8
  store i64 %v6652, ptr %slot1098, align 8
  %v6653 = load i64, ptr %slot12, align 8
  %p6654 = inttoptr i64 %v6653 to ptr
  %ld6655 = load i32, ptr %p6654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6655, ptr %slot1099, align 8
  %v6656 = load i32, ptr %slot1099, align 8
  %op6657 = and i32 %v6656, 28
  store i32 %op6657, ptr %slot1100, align 8
  %v6658 = load i32, ptr %slot1100, align 8
  %cv6659 = zext i32 %v6658 to i64
  %cond6660 = icmp ne i64 %cv6659, 0
  br i1 %cond6660, label %bb_rcslotrole1410, label %bb_rcslotowner1410
bb_rcslotrole1410:
  %v6661 = load i64, ptr %slot31, align 8
  store i64 %v6661, ptr %slot1101, align 8
  %v6662 = load i64, ptr %slot1101, align 8
  %v6663 = load i64, ptr %slot1098, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6662, i64 %v6663) nomerge, !dbg !148
  br label %bb_rcslotdone1410
bb_rcslotowner1410:
  %v6664 = load i64, ptr %slot31, align 8
  store i64 %v6664, ptr %slot1102, align 8
  %v6665 = load i64, ptr %slot1102, align 8
  %v6666 = load i64, ptr %slot1098, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6665, i64 %v6666) nomerge, !dbg !148
  br label %bb_rcslotdone1410
bb_rcslotdone1410:
  %v6667 = load i64, ptr %slot25, align 8
  %p6668 = inttoptr i64 %v6667 to ptr
  %ld6669 = load i64, ptr %p6668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6669, ptr %slot1103, align 8
  %v6670 = load i64, ptr %slot31, align 8
  %p6671 = inttoptr i64 %v6670 to ptr
  %v6672 = load i64, ptr %slot1103, align 8
  %p6673 = inttoptr i64 %v6672 to ptr
  %call6674 = call ptr @myl_native_text_scalar(ptr %p6671, ptr %p6673, i32 0) nomerge, !dbg !150
  %calladdr6675 = ptrtoint ptr %call6674 to i64
  store i64 %calladdr6675, ptr %slot1104, align 8
  %v6676 = load i64, ptr %slot1104, align 8
  %cond6677 = icmp ne i64 %v6676, 0
  br i1 %cond6677, label %bb_success1419, label %bb_failed1419
bb_failed1419:
  %v6678 = load i64, ptr %slot1, align 8
  %p6679 = inttoptr i64 %v6678 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6679) nomerge, !dbg !150
  unreachable
bb_success1419:
  %v6680 = load i64, ptr %slot1104, align 8
  %v6681 = load i64, ptr %slot25, align 8
  %p6682 = inttoptr i64 %v6681 to ptr
  store i64 %v6680, ptr %p6682, align 8, !alias.scope !3, !noalias !4
  %v6683 = load i64, ptr %slot25, align 8
  %p6684 = inttoptr i64 %v6683 to ptr
  %ld6685 = load i64, ptr %p6684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6685, ptr %slot1105, align 8
  %v6686 = load i64, ptr %slot1105, align 8
  %v6687 = load i64, ptr %slot16, align 8
  %p6688 = inttoptr i64 %v6687 to ptr
  store i64 %v6686, ptr %p6688, align 8, !alias.scope !3, !noalias !4
  %v6689 = load i64, ptr %slot16, align 8
  store i64 %v6689, ptr %slot1106, align 8
  %v6690 = load i64, ptr %slot17, align 8
  store i64 %v6690, ptr %slot1107, align 8
  %v6691 = load i64, ptr %slot1106, align 8
  %v6692 = load i64, ptr %slot1107, align 8
  %p6693 = inttoptr i64 %v6691 to ptr
  %p6694 = inttoptr i64 %v6692 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6694, ptr %p6693, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6695 = load i64, ptr %slot14, align 8
  %p6696 = inttoptr i64 %v6695 to ptr
  store i32 2, ptr %p6696, align 4, !alias.scope !3, !noalias !4
  %v6697 = load i64, ptr %slot13, align 8
  %p6698 = inttoptr i64 %v6697 to ptr
  store i32 1, ptr %p6698, align 4, !alias.scope !3, !noalias !4
  %v6699 = load i64, ptr %slot15, align 8
  store i64 %v6699, ptr %slot1108, align 8
  %v6700 = load i64, ptr %slot17, align 8
  store i64 %v6700, ptr %slot1109, align 8
  %v6701 = load i64, ptr %slot1109, align 8
  %v6702 = load i64, ptr %slot1108, align 8
  %p6703 = inttoptr i64 %v6701 to ptr
  %p6704 = inttoptr i64 %v6702 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6704, ptr %p6703, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6705 = load i64, ptr %slot12, align 8
  %p6706 = inttoptr i64 %v6705 to ptr
  store i32 2, ptr %p6706, align 4, !alias.scope !3, !noalias !4
  %v6707 = load i64, ptr %slot14, align 8
  %p6708 = inttoptr i64 %v6707 to ptr
  %ld6709 = load i32, ptr %p6708, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6709, ptr %slot1110, align 8
  %v6710 = load i32, ptr %slot1110, align 8
  %v6711 = load i64, ptr %slot12, align 8
  %p6712 = inttoptr i64 %v6711 to ptr
  store i32 %v6710, ptr %p6712, align 4, !alias.scope !3, !noalias !4
  %v6713 = load i64, ptr %slot13, align 8
  %p6714 = inttoptr i64 %v6713 to ptr
  store i32 0, ptr %p6714, align 4, !alias.scope !3, !noalias !4
  %v6715 = load i64, ptr %slot11, align 8
  %p6716 = inttoptr i64 %v6715 to ptr
  store i32 1, ptr %p6716, align 4, !alias.scope !3, !noalias !4
  %v6717 = load i64, ptr %slot1108, align 8
  %p6718 = inttoptr i64 %v6717 to ptr
  %ld6719 = load i64, ptr %p6718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6719, ptr %slot1111, align 8
  %v6720 = load i64, ptr %slot1111, align 8
  %v6721 = load i64, ptr %slot25, align 8
  %p6722 = inttoptr i64 %v6721 to ptr
  store i64 %v6720, ptr %p6722, align 8, !alias.scope !3, !noalias !4
  %v6723 = load i64, ptr %slot22, align 8
  store i64 %v6723, ptr %slot1112, align 8
  %v6724 = load i64, ptr %slot6, align 8
  %p6725 = inttoptr i64 %v6724 to ptr
  %ld6726 = load i32, ptr %p6725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6726, ptr %slot1113, align 8
  %v6727 = load i32, ptr %slot1113, align 8
  %cmp6728 = icmp eq i32 %v6727, 16
  %cv6729 = zext i1 %cmp6728 to i32
  store i32 %cv6729, ptr %slot1114, align 8
  %v6730 = load i64, ptr %slot5, align 8
  %p6731 = inttoptr i64 %v6730 to ptr
  %ld6732 = load i32, ptr %p6731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6732, ptr %slot1115, align 8
  %v6733 = load i32, ptr %slot1115, align 8
  %v6734 = load i32, ptr %slot1114, align 8
  %op6735 = and i32 %v6733, %v6734
  store i32 %op6735, ptr %slot1116, align 8
  %v6736 = load i32, ptr %slot1116, align 8
  %cv6737 = zext i32 %v6736 to i64
  %cond6738 = icmp ne i64 %cv6737, 0
  br i1 %cond6738, label %bb_rcownlocal1440, label %bb_rcownedlocal1440
bb_rcownlocal1440:
  %v6739 = load i64, ptr %slot22, align 8
  store i64 %v6739, ptr %slot1117, align 8
  %v6740 = load i64, ptr %slot17, align 8
  store i64 %v6740, ptr %slot1118, align 8
  %v6741 = load i64, ptr %slot32, align 8
  store i64 %v6741, ptr %slot1119, align 8
  %v6742 = load i64, ptr %slot1117, align 8
  %p6743 = inttoptr i64 %v6742 to ptr
  %ld6744 = load i64, ptr %p6743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6744, ptr %slot1120, align 8
  %v6745 = load i64, ptr %slot1120, align 8
  %cmp6746 = icmp ne i64 %v6745, 0
  %cv6747 = zext i1 %cmp6746 to i32
  store i32 %cv6747, ptr %slot1121, align 8
  %v6748 = load i32, ptr %slot1121, align 8
  %cv6749 = zext i32 %v6748 to i64
  %cond6750 = icmp ne i64 %cv6749, 0
  br i1 %cond6750, label %bb_rcgnn1447, label %bb_rcgplain1447
bb_rcgnn1447:
  %v6751 = load i64, ptr %slot1120, align 8
  %op6752 = sub i64 %v6751, 16
  store i64 %op6752, ptr %slot1122, align 8
  %v6753 = load i64, ptr %slot1120, align 8
  %p6754 = inttoptr i64 %v6753 to ptr
  %rgep6755 = getelementptr i8, ptr %p6754, i64 -16
  %ld6756 = load i64, ptr %rgep6755, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6756, ptr %slot1123, align 8
  %v6757 = load i64, ptr %slot1123, align 8
  %op6758 = and i64 %v6757, 4611686018427387906
  store i64 %op6758, ptr %slot1124, align 8
  %v6759 = load i64, ptr %slot1124, align 8
  %cmp6760 = icmp ne i64 %v6759, 0
  %cv6761 = zext i1 %cmp6760 to i32
  store i32 %cv6761, ptr %slot1125, align 8
  %v6762 = load i32, ptr %slot1125, align 8
  %cv6763 = zext i32 %v6762 to i64
  %cond6764 = icmp ne i64 %cv6763, 0
  br i1 %cond6764, label %bb_rcgspecial1447, label %bb_rcginc1447
bb_rcginc1447:
  %v6765 = load i64, ptr %slot1120, align 8
  %op6766 = sub i64 %v6765, 32
  store i64 %op6766, ptr %slot1126, align 8
  %v6767 = load i64, ptr %slot1120, align 8
  %p6768 = inttoptr i64 %v6767 to ptr
  %rgep6769 = getelementptr i8, ptr %p6768, i64 -32
  %ld6770 = load i64, ptr %rgep6769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6770, ptr %slot1127, align 8
  %v6771 = load i64, ptr %slot1127, align 8
  %op6772 = add i64 %v6771, 1
  store i64 %op6772, ptr %slot1128, align 8
  %v6773 = load i64, ptr %slot1128, align 8
  %cmp6774 = icmp eq i64 %v6773, 0
  %cv6775 = zext i1 %cmp6774 to i32
  store i32 %cv6775, ptr %slot1129, align 8
  %v6776 = load i32, ptr %slot1129, align 8
  %cv6777 = zext i32 %v6776 to i64
  %cond6778 = icmp ne i64 %cv6777, 0
  br i1 %cond6778, label %bb_rcglimit1447, label %bb_rcgcapacity1447
bb_rcglimit1447:
  %v6779 = load i64, ptr %slot1, align 8
  %p6780 = inttoptr i64 %v6779 to ptr
  %call6781 = call i32 @myl_qbe_rc_status(ptr %p6780, i32 2) nomerge, !dbg !152
  store i32 %call6781, ptr %slot1130, align 8
  br label %bb_failure
bb_rcgcapacity1447:
  %v6782 = load i64, ptr %slot1128, align 8
  %v6783 = load i64, ptr %slot1120, align 8
  %p6784 = inttoptr i64 %v6783 to ptr
  %rgep6785 = getelementptr i8, ptr %p6784, i64 -32
  store i64 %v6782, ptr %rgep6785, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1447
bb_rcgspecial1447:
  %v6786 = load i64, ptr %slot1123, align 8
  %op6787 = and i64 %v6786, 4611686018427387904
  store i64 %op6787, ptr %slot1131, align 8
  %v6788 = load i64, ptr %slot1131, align 8
  %cmp6789 = icmp ne i64 %v6788, 0
  %cv6790 = zext i1 %cmp6789 to i32
  store i32 %cv6790, ptr %slot1132, align 8
  %v6791 = load i32, ptr %slot1132, align 8
  %cv6792 = zext i32 %v6791 to i64
  %cond6793 = icmp ne i64 %cv6792, 0
  br i1 %cond6793, label %bb_rcgslow1447, label %bb_rcgplain1447
bb_rcgslow1447:
  %v6794 = load i64, ptr %slot31, align 8
  %v6795 = load i64, ptr %slot1118, align 8
  %v6796 = load i64, ptr %slot1117, align 8
  %v6797 = load i64, ptr %slot1119, align 8
  %cv6798 = trunc i64 %v6797 to i32
  %call6799 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v6794, i64 %v6795, i64 %v6796, i32 %cv6798) nomerge, !dbg !152
  store i32 %call6799, ptr %slot1133, align 8
  %v6800 = load i32, ptr %slot1133, align 8
  %cv6801 = zext i32 %v6800 to i64
  %cond6802 = icmp ne i64 %cv6801, 0
  br i1 %cond6802, label %bb_rcsuccess1461, label %bb_rcfailure1461
bb_rcfailure1461:
  %v6803 = load i64, ptr %slot31, align 8
  %p6804 = inttoptr i64 %v6803 to ptr
  %call6805 = call i32 @myl_rc_take_failure(ptr %p6804) nomerge, !dbg !152
  store i32 %call6805, ptr %slot1134, align 8
  %v6806 = load i64, ptr %slot1, align 8
  %p6807 = inttoptr i64 %v6806 to ptr
  %v6808 = load i32, ptr %slot1134, align 8
  %call6809 = call i32 @myl_qbe_rc_status(ptr %p6807, i32 %v6808) nomerge, !dbg !152
  store i32 %call6809, ptr %slot1135, align 8
  br label %bb_failure
bb_rcsuccess1461:
  br label %bb_rcgdone1447
bb_rcgplain1447:
  %v6810 = load i64, ptr %slot1120, align 8
  %v6811 = load i64, ptr %slot1118, align 8
  %p6812 = inttoptr i64 %v6811 to ptr
  store i64 %v6810, ptr %p6812, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1447
bb_rcgdone1447:
  %v6813 = load i64, ptr %slot14, align 8
  %p6814 = inttoptr i64 %v6813 to ptr
  store i32 2, ptr %p6814, align 4, !alias.scope !3, !noalias !4
  %v6815 = load i64, ptr %slot13, align 8
  %p6816 = inttoptr i64 %v6815 to ptr
  store i32 1, ptr %p6816, align 4, !alias.scope !3, !noalias !4
  %v6817 = load i64, ptr %slot5, align 8
  %p6818 = inttoptr i64 %v6817 to ptr
  %ld6819 = load i32, ptr %p6818, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6819, ptr %slot1136, align 8
  %v6820 = load i32, ptr %slot1136, align 8
  %cv6821 = zext i32 %v6820 to i64
  %cond6822 = icmp ne i64 %cv6821, 0
  br i1 %cond6822, label %bb_rcslotdrop1468, label %bb_rcslotdone1468
bb_rcslotdrop1468:
  %v6823 = load i64, ptr %slot5, align 8
  %p6824 = inttoptr i64 %v6823 to ptr
  store i32 0, ptr %p6824, align 4, !alias.scope !3, !noalias !4
  %v6825 = load i64, ptr %slot22, align 8
  store i64 %v6825, ptr %slot1137, align 8
  %v6826 = load i64, ptr %slot6, align 8
  %p6827 = inttoptr i64 %v6826 to ptr
  %ld6828 = load i32, ptr %p6827, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6828, ptr %slot1138, align 8
  %v6829 = load i32, ptr %slot1138, align 8
  %op6830 = and i32 %v6829, 28
  store i32 %op6830, ptr %slot1139, align 8
  %v6831 = load i32, ptr %slot1139, align 8
  %cv6832 = zext i32 %v6831 to i64
  %cond6833 = icmp ne i64 %cv6832, 0
  br i1 %cond6833, label %bb_rcslotrole1468, label %bb_rcslotowner1468
bb_rcslotrole1468:
  %v6834 = load i64, ptr %slot31, align 8
  store i64 %v6834, ptr %slot1140, align 8
  %v6835 = load i64, ptr %slot1137, align 8
  %p6836 = inttoptr i64 %v6835 to ptr
  %ld6837 = load i64, ptr %p6836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6837, ptr %slot1141, align 8
  %v6838 = load i64, ptr %slot1141, align 8
  %cmp6839 = icmp ne i64 %v6838, 0
  %cv6840 = zext i1 %cmp6839 to i32
  store i32 %cv6840, ptr %slot1142, align 8
  %v6841 = load i32, ptr %slot1142, align 8
  %cv6842 = zext i32 %v6841 to i64
  %cond6843 = icmp ne i64 %cv6842, 0
  br i1 %cond6843, label %bb_rcgnn1484, label %bb_rcgdone1484
bb_rcgnn1484:
  %v6844 = load i64, ptr %slot1141, align 8
  %op6845 = sub i64 %v6844, 16
  store i64 %op6845, ptr %slot1143, align 8
  %v6846 = load i64, ptr %slot1141, align 8
  %p6847 = inttoptr i64 %v6846 to ptr
  %rgep6848 = getelementptr i8, ptr %p6847, i64 -16
  %ld6849 = load i64, ptr %rgep6848, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6849, ptr %slot1144, align 8
  %v6850 = load i64, ptr %slot1144, align 8
  %op6851 = and i64 %v6850, 4611686018427387906
  store i64 %op6851, ptr %slot1145, align 8
  %v6852 = load i64, ptr %slot1145, align 8
  %cmp6853 = icmp ne i64 %v6852, 0
  %cv6854 = zext i1 %cmp6853 to i32
  store i32 %cv6854, ptr %slot1146, align 8
  %v6855 = load i32, ptr %slot1146, align 8
  %cv6856 = zext i32 %v6855 to i64
  %cond6857 = icmp ne i64 %cv6856, 0
  br i1 %cond6857, label %bb_rcgclear1484, label %bb_rcgcounted1484
bb_rcgcounted1484:
  %v6858 = load i64, ptr %slot1141, align 8
  %op6859 = sub i64 %v6858, 24
  store i64 %op6859, ptr %slot1147, align 8
  %v6860 = load i64, ptr %slot1141, align 8
  %p6861 = inttoptr i64 %v6860 to ptr
  %rgep6862 = getelementptr i8, ptr %p6861, i64 -24
  %ld6863 = load i64, ptr %rgep6862, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6863, ptr %slot1148, align 8
  %v6864 = load i64, ptr %slot1148, align 8
  %op6865 = sub i64 %v6864, 1
  store i64 %op6865, ptr %slot1149, align 8
  %v6866 = load i64, ptr %slot1149, align 8
  %cmp6867 = icmp eq i64 %v6866, 0
  %cv6868 = zext i1 %cmp6867 to i32
  store i32 %cv6868, ptr %slot1150, align 8
  %v6869 = load i32, ptr %slot1150, align 8
  %cv6870 = zext i32 %v6869 to i64
  %cond6871 = icmp ne i64 %cv6870, 0
  br i1 %cond6871, label %bb_rcglast1484, label %bb_rcgdec1484
bb_rcglast1484:
  %v6872 = load i64, ptr %slot1141, align 8
  %op6873 = sub i64 %v6872, 32
  store i64 %op6873, ptr %slot1151, align 8
  %v6874 = load i64, ptr %slot1141, align 8
  %p6875 = inttoptr i64 %v6874 to ptr
  %rgep6876 = getelementptr i8, ptr %p6875, i64 -32
  %ld6877 = load i64, ptr %rgep6876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6877, ptr %slot1152, align 8
  %v6878 = load i64, ptr %slot1152, align 8
  %cmp6879 = icmp ne i64 %v6878, 0
  %cv6880 = zext i1 %cmp6879 to i32
  store i32 %cv6880, ptr %slot1153, align 8
  %v6881 = load i32, ptr %slot1153, align 8
  %cv6882 = zext i32 %v6881 to i64
  %cond6883 = icmp ne i64 %cv6882, 0
  br i1 %cond6883, label %bb_rcgdec1484, label %bb_rcgslow1484
bb_rcgslow1484:
  %v6884 = load i64, ptr %slot1140, align 8
  %v6885 = load i64, ptr %slot1137, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v6884, i64 %v6885) nomerge, !dbg !152
  br label %bb_rcgdone1484
bb_rcgdec1484:
  %v6886 = load i64, ptr %slot1149, align 8
  %v6887 = load i64, ptr %slot1141, align 8
  %p6888 = inttoptr i64 %v6887 to ptr
  %rgep6889 = getelementptr i8, ptr %p6888, i64 -24
  store i64 %v6886, ptr %rgep6889, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1484
bb_rcgclear1484:
  %v6890 = load i64, ptr %slot1137, align 8
  %p6891 = inttoptr i64 %v6890 to ptr
  store i64 0, ptr %p6891, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1484
bb_rcgdone1484:
  br label %bb_rcslotdone1468
bb_rcslotowner1468:
  %v6892 = load i64, ptr %slot31, align 8
  store i64 %v6892, ptr %slot1154, align 8
  %v6893 = load i64, ptr %slot1137, align 8
  %p6894 = inttoptr i64 %v6893 to ptr
  %ld6895 = load i64, ptr %p6894, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6895, ptr %slot1155, align 8
  %v6896 = load i64, ptr %slot1155, align 8
  %cmp6897 = icmp ne i64 %v6896, 0
  %cv6898 = zext i1 %cmp6897 to i32
  store i32 %cv6898, ptr %slot1156, align 8
  %v6899 = load i32, ptr %slot1156, align 8
  %cv6900 = zext i32 %v6899 to i64
  %cond6901 = icmp ne i64 %cv6900, 0
  br i1 %cond6901, label %bb_rcgnn1499, label %bb_rcgdone1499
bb_rcgnn1499:
  %v6902 = load i64, ptr %slot1155, align 8
  %op6903 = sub i64 %v6902, 16
  store i64 %op6903, ptr %slot1157, align 8
  %v6904 = load i64, ptr %slot1155, align 8
  %p6905 = inttoptr i64 %v6904 to ptr
  %rgep6906 = getelementptr i8, ptr %p6905, i64 -16
  %ld6907 = load i64, ptr %rgep6906, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6907, ptr %slot1158, align 8
  %v6908 = load i64, ptr %slot1158, align 8
  %op6909 = and i64 %v6908, 4611686018427387906
  store i64 %op6909, ptr %slot1159, align 8
  %v6910 = load i64, ptr %slot1159, align 8
  %cmp6911 = icmp ne i64 %v6910, 0
  %cv6912 = zext i1 %cmp6911 to i32
  store i32 %cv6912, ptr %slot1160, align 8
  %v6913 = load i32, ptr %slot1160, align 8
  %cv6914 = zext i32 %v6913 to i64
  %cond6915 = icmp ne i64 %cv6914, 0
  br i1 %cond6915, label %bb_rcgclear1499, label %bb_rcgcounted1499
bb_rcgcounted1499:
  %v6916 = load i64, ptr %slot1155, align 8
  %op6917 = sub i64 %v6916, 32
  store i64 %op6917, ptr %slot1161, align 8
  %v6918 = load i64, ptr %slot1155, align 8
  %p6919 = inttoptr i64 %v6918 to ptr
  %rgep6920 = getelementptr i8, ptr %p6919, i64 -32
  %ld6921 = load i64, ptr %rgep6920, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6921, ptr %slot1162, align 8
  %v6922 = load i64, ptr %slot1162, align 8
  %op6923 = sub i64 %v6922, 1
  store i64 %op6923, ptr %slot1163, align 8
  %v6924 = load i64, ptr %slot1163, align 8
  %cmp6925 = icmp eq i64 %v6924, 0
  %cv6926 = zext i1 %cmp6925 to i32
  store i32 %cv6926, ptr %slot1164, align 8
  %v6927 = load i32, ptr %slot1164, align 8
  %cv6928 = zext i32 %v6927 to i64
  %cond6929 = icmp ne i64 %cv6928, 0
  br i1 %cond6929, label %bb_rcglast1499, label %bb_rcgdec1499
bb_rcglast1499:
  %v6930 = load i64, ptr %slot1155, align 8
  %op6931 = sub i64 %v6930, 24
  store i64 %op6931, ptr %slot1165, align 8
  %v6932 = load i64, ptr %slot1155, align 8
  %p6933 = inttoptr i64 %v6932 to ptr
  %rgep6934 = getelementptr i8, ptr %p6933, i64 -24
  %ld6935 = load i64, ptr %rgep6934, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6935, ptr %slot1166, align 8
  %v6936 = load i64, ptr %slot1166, align 8
  %cmp6937 = icmp ne i64 %v6936, 0
  %cv6938 = zext i1 %cmp6937 to i32
  store i32 %cv6938, ptr %slot1167, align 8
  %v6939 = load i32, ptr %slot1167, align 8
  %cv6940 = zext i32 %v6939 to i64
  %cond6941 = icmp ne i64 %cv6940, 0
  br i1 %cond6941, label %bb_rcgdec1499, label %bb_rcgslow1499
bb_rcgslow1499:
  %v6942 = load i64, ptr %slot1154, align 8
  %v6943 = load i64, ptr %slot1137, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v6942, i64 %v6943) nomerge, !dbg !152
  br label %bb_rcgdone1499
bb_rcgdec1499:
  %v6944 = load i64, ptr %slot1163, align 8
  %v6945 = load i64, ptr %slot1155, align 8
  %p6946 = inttoptr i64 %v6945 to ptr
  %rgep6947 = getelementptr i8, ptr %p6946, i64 -32
  store i64 %v6944, ptr %rgep6947, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1499
bb_rcgclear1499:
  %v6948 = load i64, ptr %slot1137, align 8
  %p6949 = inttoptr i64 %v6948 to ptr
  store i64 0, ptr %p6949, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1499
bb_rcgdone1499:
  br label %bb_rcslotdone1468
bb_rcslotdone1468:
  %v6950 = load i64, ptr %slot17, align 8
  store i64 %v6950, ptr %slot1168, align 8
  %v6951 = load i64, ptr %slot1168, align 8
  %v6952 = load i64, ptr %slot1117, align 8
  %p6953 = inttoptr i64 %v6951 to ptr
  %p6954 = inttoptr i64 %v6952 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6954, ptr %p6953, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6955 = load i64, ptr %slot6, align 8
  %p6956 = inttoptr i64 %v6955 to ptr
  store i32 2, ptr %p6956, align 4, !alias.scope !3, !noalias !4
  %v6957 = load i64, ptr %slot5, align 8
  %p6958 = inttoptr i64 %v6957 to ptr
  store i32 1, ptr %p6958, align 4, !alias.scope !3, !noalias !4
  %v6959 = load i64, ptr %slot13, align 8
  %p6960 = inttoptr i64 %v6959 to ptr
  store i32 0, ptr %p6960, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal1440
bb_rcownedlocal1440:
  %v6961 = load i64, ptr %slot6, align 8
  %p6962 = inttoptr i64 %v6961 to ptr
  store i32 2, ptr %p6962, align 4, !alias.scope !3, !noalias !4
  %v6963 = load i64, ptr %slot1112, align 8
  %p6964 = inttoptr i64 %v6963 to ptr
  %ld6965 = load i64, ptr %p6964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6965, ptr %slot1169, align 8
  %v6966 = load i64, ptr %slot1169, align 8
  %cmp6967 = icmp ne i64 %v6966, 0
  %cv6968 = zext i1 %cmp6967 to i32
  store i32 %cv6968, ptr %slot1170, align 8
  %v6969 = load i32, ptr %slot1170, align 8
  %cv6970 = zext i32 %v6969 to i64
  %cond6971 = icmp ne i64 %cv6970, 0
  br i1 %cond6971, label %bb_rcguniquenn1508, label %bb_rcgunique1508
bb_rcguniquenn1508:
  %v6972 = load i64, ptr %slot1169, align 8
  %op6973 = sub i64 %v6972, 16
  store i64 %op6973, ptr %slot1171, align 8
  %v6974 = load i64, ptr %slot1169, align 8
  %p6975 = inttoptr i64 %v6974 to ptr
  %rgep6976 = getelementptr i8, ptr %p6975, i64 -16
  %ld6977 = load i64, ptr %rgep6976, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6977, ptr %slot1172, align 8
  %v6978 = load i64, ptr %slot1172, align 8
  %op6979 = and i64 %v6978, 6917529027641081858
  store i64 %op6979, ptr %slot1173, align 8
  %v6980 = load i64, ptr %slot1173, align 8
  %cmp6981 = icmp ne i64 %v6980, 0
  %cv6982 = zext i1 %cmp6981 to i32
  store i32 %cv6982, ptr %slot1174, align 8
  %v6983 = load i32, ptr %slot1174, align 8
  %cv6984 = zext i32 %v6983 to i64
  %cond6985 = icmp ne i64 %cv6984, 0
  br i1 %cond6985, label %bb_rcguniqueslow1508, label %bb_rcguniquecount1508
bb_rcguniquecount1508:
  %v6986 = load i64, ptr %slot1169, align 8
  %op6987 = sub i64 %v6986, 32
  store i64 %op6987, ptr %slot1175, align 8
  %v6988 = load i64, ptr %slot1169, align 8
  %p6989 = inttoptr i64 %v6988 to ptr
  %rgep6990 = getelementptr i8, ptr %p6989, i64 -32
  %ld6991 = load i64, ptr %rgep6990, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6991, ptr %slot1176, align 8
  %v6992 = load i64, ptr %slot1176, align 8
  %cmp6993 = icmp ult i64 %v6992, 2
  %cv6994 = zext i1 %cmp6993 to i32
  store i32 %cv6994, ptr %slot1177, align 8
  %v6995 = load i32, ptr %slot1177, align 8
  %cv6996 = zext i32 %v6995 to i64
  %cond6997 = icmp ne i64 %cv6996, 0
  br i1 %cond6997, label %bb_rcgunique1508, label %bb_rcguniqueslow1508
bb_rcguniqueslow1508:
  %v6998 = load i64, ptr %slot1, align 8
  %p6999 = inttoptr i64 %v6998 to ptr
  %p7000 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v7001 = load i64, ptr %slot1112, align 8
  %p7002 = inttoptr i64 %v7001 to ptr
  %v7003 = load i64, ptr %slot5, align 8
  %p7004 = inttoptr i64 %v7003 to ptr
  %call7005 = call i32 @myl_qbe_rc_unique_local(ptr %p6999, ptr %p7000, ptr %p7002, ptr %p7004) nomerge, !dbg !152
  store i32 %call7005, ptr %slot1178, align 8
  %v7006 = load i32, ptr %slot1178, align 8
  %cv7007 = zext i32 %v7006 to i64
  %cond7008 = icmp ne i64 %cv7007, 0
  br i1 %cond7008, label %bb_rcunique1519, label %bb_failure
bb_rcunique1519:
  br label %bb_rcgunique1508
bb_rcgunique1508:
  %v7009 = load i64, ptr %slot22, align 8
  %p7010 = inttoptr i64 %v7009 to ptr
  %ld7011 = load i64, ptr %p7010, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7011, ptr %slot1179, align 8
  %v7012 = load i64, ptr %slot25, align 8
  store i64 %v7012, ptr %slot1180, align 8
  %v7013 = load i64, ptr %slot1180, align 8
  %p7014 = inttoptr i64 %v7013 to ptr
  %ld7015 = load i64, ptr %p7014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7015, ptr %slot1181, align 8
  %v7016 = load i64, ptr %slot1181, align 8
  %v7017 = load i64, ptr %slot18, align 8
  %p7018 = inttoptr i64 %v7017 to ptr
  store i64 %v7016, ptr %p7018, align 8, !alias.scope !3, !noalias !4
  %v7019 = load i64, ptr %slot18, align 8
  store i64 %v7019, ptr %slot1182, align 8
  %v7020 = load i64, ptr %slot31, align 8
  %v7021 = load i64, ptr %slot1179, align 8
  %v7022 = load i64, ptr %slot1182, align 8
  %call7023 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v7020, i64 %v7021, i64 %v7022) nomerge, !dbg !152
  store i32 %call7023, ptr %slot1183, align 8
  %v7024 = load i32, ptr %slot1183, align 8
  %cv7025 = zext i32 %v7024 to i64
  %cond7026 = icmp ne i64 %cv7025, 0
  br i1 %cond7026, label %bb_success1525, label %bb_failed1525
bb_failed1525:
  %v7027 = load i64, ptr %slot1, align 8
  %p7028 = inttoptr i64 %v7027 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7028) nomerge, !dbg !152
  unreachable
bb_success1525:
  %v7029 = load i64, ptr %slot25, align 8
  %p7030 = inttoptr i64 %v7029 to ptr
  store i64 0, ptr %p7030, align 8, !alias.scope !3, !noalias !4
  %v7031 = load i64, ptr %slot11, align 8
  %p7032 = inttoptr i64 %v7031 to ptr
  %ld7033 = load i32, ptr %p7032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7033, ptr %slot1184, align 8
  %v7034 = load i32, ptr %slot1184, align 8
  %cv7035 = zext i32 %v7034 to i64
  %cond7036 = icmp ne i64 %cv7035, 0
  br i1 %cond7036, label %bb_rcslotdrop1528, label %bb_rcslotdone1528
bb_rcslotdrop1528:
  %v7037 = load i64, ptr %slot11, align 8
  %p7038 = inttoptr i64 %v7037 to ptr
  store i32 0, ptr %p7038, align 4, !alias.scope !3, !noalias !4
  %v7039 = load i64, ptr %slot15, align 8
  store i64 %v7039, ptr %slot1185, align 8
  %v7040 = load i64, ptr %slot12, align 8
  %p7041 = inttoptr i64 %v7040 to ptr
  %ld7042 = load i32, ptr %p7041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7042, ptr %slot1186, align 8
  %v7043 = load i32, ptr %slot1186, align 8
  %op7044 = and i32 %v7043, 28
  store i32 %op7044, ptr %slot1187, align 8
  %v7045 = load i32, ptr %slot1187, align 8
  %cv7046 = zext i32 %v7045 to i64
  %cond7047 = icmp ne i64 %cv7046, 0
  br i1 %cond7047, label %bb_rcslotrole1528, label %bb_rcslotowner1528
bb_rcslotrole1528:
  %v7048 = load i64, ptr %slot31, align 8
  store i64 %v7048, ptr %slot1188, align 8
  %v7049 = load i64, ptr %slot1185, align 8
  %p7050 = inttoptr i64 %v7049 to ptr
  %ld7051 = load i64, ptr %p7050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7051, ptr %slot1189, align 8
  %v7052 = load i64, ptr %slot1189, align 8
  %cmp7053 = icmp ne i64 %v7052, 0
  %cv7054 = zext i1 %cmp7053 to i32
  store i32 %cv7054, ptr %slot1190, align 8
  %v7055 = load i32, ptr %slot1190, align 8
  %cv7056 = zext i32 %v7055 to i64
  %cond7057 = icmp ne i64 %cv7056, 0
  br i1 %cond7057, label %bb_rcgnn1544, label %bb_rcgdone1544
bb_rcgnn1544:
  %v7058 = load i64, ptr %slot1189, align 8
  %op7059 = sub i64 %v7058, 16
  store i64 %op7059, ptr %slot1191, align 8
  %v7060 = load i64, ptr %slot1189, align 8
  %p7061 = inttoptr i64 %v7060 to ptr
  %rgep7062 = getelementptr i8, ptr %p7061, i64 -16
  %ld7063 = load i64, ptr %rgep7062, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7063, ptr %slot1192, align 8
  %v7064 = load i64, ptr %slot1192, align 8
  %op7065 = and i64 %v7064, 4611686018427387906
  store i64 %op7065, ptr %slot1193, align 8
  %v7066 = load i64, ptr %slot1193, align 8
  %cmp7067 = icmp ne i64 %v7066, 0
  %cv7068 = zext i1 %cmp7067 to i32
  store i32 %cv7068, ptr %slot1194, align 8
  %v7069 = load i32, ptr %slot1194, align 8
  %cv7070 = zext i32 %v7069 to i64
  %cond7071 = icmp ne i64 %cv7070, 0
  br i1 %cond7071, label %bb_rcgclear1544, label %bb_rcgcounted1544
bb_rcgcounted1544:
  %v7072 = load i64, ptr %slot1189, align 8
  %op7073 = sub i64 %v7072, 24
  store i64 %op7073, ptr %slot1195, align 8
  %v7074 = load i64, ptr %slot1189, align 8
  %p7075 = inttoptr i64 %v7074 to ptr
  %rgep7076 = getelementptr i8, ptr %p7075, i64 -24
  %ld7077 = load i64, ptr %rgep7076, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7077, ptr %slot1196, align 8
  %v7078 = load i64, ptr %slot1196, align 8
  %op7079 = sub i64 %v7078, 1
  store i64 %op7079, ptr %slot1197, align 8
  %v7080 = load i64, ptr %slot1197, align 8
  %cmp7081 = icmp eq i64 %v7080, 0
  %cv7082 = zext i1 %cmp7081 to i32
  store i32 %cv7082, ptr %slot1198, align 8
  %v7083 = load i32, ptr %slot1198, align 8
  %cv7084 = zext i32 %v7083 to i64
  %cond7085 = icmp ne i64 %cv7084, 0
  br i1 %cond7085, label %bb_rcglast1544, label %bb_rcgdec1544
bb_rcglast1544:
  %v7086 = load i64, ptr %slot1189, align 8
  %op7087 = sub i64 %v7086, 32
  store i64 %op7087, ptr %slot1199, align 8
  %v7088 = load i64, ptr %slot1189, align 8
  %p7089 = inttoptr i64 %v7088 to ptr
  %rgep7090 = getelementptr i8, ptr %p7089, i64 -32
  %ld7091 = load i64, ptr %rgep7090, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7091, ptr %slot1200, align 8
  %v7092 = load i64, ptr %slot1200, align 8
  %cmp7093 = icmp ne i64 %v7092, 0
  %cv7094 = zext i1 %cmp7093 to i32
  store i32 %cv7094, ptr %slot1201, align 8
  %v7095 = load i32, ptr %slot1201, align 8
  %cv7096 = zext i32 %v7095 to i64
  %cond7097 = icmp ne i64 %cv7096, 0
  br i1 %cond7097, label %bb_rcgdec1544, label %bb_rcgslow1544
bb_rcgslow1544:
  %v7098 = load i64, ptr %slot1188, align 8
  %v7099 = load i64, ptr %slot1185, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v7098, i64 %v7099) nomerge, !dbg !152
  br label %bb_rcgdone1544
bb_rcgdec1544:
  %v7100 = load i64, ptr %slot1197, align 8
  %v7101 = load i64, ptr %slot1189, align 8
  %p7102 = inttoptr i64 %v7101 to ptr
  %rgep7103 = getelementptr i8, ptr %p7102, i64 -24
  store i64 %v7100, ptr %rgep7103, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1544
bb_rcgclear1544:
  %v7104 = load i64, ptr %slot1185, align 8
  %p7105 = inttoptr i64 %v7104 to ptr
  store i64 0, ptr %p7105, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1544
bb_rcgdone1544:
  br label %bb_rcslotdone1528
bb_rcslotowner1528:
  %v7106 = load i64, ptr %slot31, align 8
  store i64 %v7106, ptr %slot1202, align 8
  %v7107 = load i64, ptr %slot1185, align 8
  %p7108 = inttoptr i64 %v7107 to ptr
  %ld7109 = load i64, ptr %p7108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7109, ptr %slot1203, align 8
  %v7110 = load i64, ptr %slot1203, align 8
  %cmp7111 = icmp ne i64 %v7110, 0
  %cv7112 = zext i1 %cmp7111 to i32
  store i32 %cv7112, ptr %slot1204, align 8
  %v7113 = load i32, ptr %slot1204, align 8
  %cv7114 = zext i32 %v7113 to i64
  %cond7115 = icmp ne i64 %cv7114, 0
  br i1 %cond7115, label %bb_rcgnn1559, label %bb_rcgdone1559
bb_rcgnn1559:
  %v7116 = load i64, ptr %slot1203, align 8
  %op7117 = sub i64 %v7116, 16
  store i64 %op7117, ptr %slot1205, align 8
  %v7118 = load i64, ptr %slot1203, align 8
  %p7119 = inttoptr i64 %v7118 to ptr
  %rgep7120 = getelementptr i8, ptr %p7119, i64 -16
  %ld7121 = load i64, ptr %rgep7120, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7121, ptr %slot1206, align 8
  %v7122 = load i64, ptr %slot1206, align 8
  %op7123 = and i64 %v7122, 4611686018427387906
  store i64 %op7123, ptr %slot1207, align 8
  %v7124 = load i64, ptr %slot1207, align 8
  %cmp7125 = icmp ne i64 %v7124, 0
  %cv7126 = zext i1 %cmp7125 to i32
  store i32 %cv7126, ptr %slot1208, align 8
  %v7127 = load i32, ptr %slot1208, align 8
  %cv7128 = zext i32 %v7127 to i64
  %cond7129 = icmp ne i64 %cv7128, 0
  br i1 %cond7129, label %bb_rcgclear1559, label %bb_rcgcounted1559
bb_rcgcounted1559:
  %v7130 = load i64, ptr %slot1203, align 8
  %op7131 = sub i64 %v7130, 32
  store i64 %op7131, ptr %slot1209, align 8
  %v7132 = load i64, ptr %slot1203, align 8
  %p7133 = inttoptr i64 %v7132 to ptr
  %rgep7134 = getelementptr i8, ptr %p7133, i64 -32
  %ld7135 = load i64, ptr %rgep7134, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7135, ptr %slot1210, align 8
  %v7136 = load i64, ptr %slot1210, align 8
  %op7137 = sub i64 %v7136, 1
  store i64 %op7137, ptr %slot1211, align 8
  %v7138 = load i64, ptr %slot1211, align 8
  %cmp7139 = icmp eq i64 %v7138, 0
  %cv7140 = zext i1 %cmp7139 to i32
  store i32 %cv7140, ptr %slot1212, align 8
  %v7141 = load i32, ptr %slot1212, align 8
  %cv7142 = zext i32 %v7141 to i64
  %cond7143 = icmp ne i64 %cv7142, 0
  br i1 %cond7143, label %bb_rcglast1559, label %bb_rcgdec1559
bb_rcglast1559:
  %v7144 = load i64, ptr %slot1203, align 8
  %op7145 = sub i64 %v7144, 24
  store i64 %op7145, ptr %slot1213, align 8
  %v7146 = load i64, ptr %slot1203, align 8
  %p7147 = inttoptr i64 %v7146 to ptr
  %rgep7148 = getelementptr i8, ptr %p7147, i64 -24
  %ld7149 = load i64, ptr %rgep7148, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7149, ptr %slot1214, align 8
  %v7150 = load i64, ptr %slot1214, align 8
  %cmp7151 = icmp ne i64 %v7150, 0
  %cv7152 = zext i1 %cmp7151 to i32
  store i32 %cv7152, ptr %slot1215, align 8
  %v7153 = load i32, ptr %slot1215, align 8
  %cv7154 = zext i32 %v7153 to i64
  %cond7155 = icmp ne i64 %cv7154, 0
  br i1 %cond7155, label %bb_rcgdec1559, label %bb_rcgslow1559
bb_rcgslow1559:
  %v7156 = load i64, ptr %slot1202, align 8
  %v7157 = load i64, ptr %slot1185, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v7156, i64 %v7157) nomerge, !dbg !152
  br label %bb_rcgdone1559
bb_rcgdec1559:
  %v7158 = load i64, ptr %slot1211, align 8
  %v7159 = load i64, ptr %slot1203, align 8
  %p7160 = inttoptr i64 %v7159 to ptr
  %rgep7161 = getelementptr i8, ptr %p7160, i64 -32
  store i64 %v7158, ptr %rgep7161, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1559
bb_rcgclear1559:
  %v7162 = load i64, ptr %slot1185, align 8
  %p7163 = inttoptr i64 %v7162 to ptr
  store i64 0, ptr %p7163, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1559
bb_rcgdone1559:
  br label %bb_rcslotdone1528
bb_rcslotdone1528:
  %p7164 = inttoptr i64 ptrtoint (ptr @myl_lit_bd90ef796306d9e474feb3d6510532661f5ac29d8bd5c1fff372bb5602cd80af to i64) to ptr
  %ld7165 = load i64, ptr %p7164, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7165, ptr %slot1216, align 8
  %v7166 = load i64, ptr %slot1216, align 8
  %v7167 = load i64, ptr %slot25, align 8
  %p7168 = inttoptr i64 %v7167 to ptr
  store i64 %v7166, ptr %p7168, align 8, !alias.scope !3, !noalias !4
  %v7169 = load i64, ptr %slot25, align 8
  %p7170 = inttoptr i64 %v7169 to ptr
  %ld7171 = load i64, ptr %p7170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7171, ptr %slot1217, align 8
  %v7172 = load i64, ptr %slot1217, align 8
  %v7173 = load i64, ptr %slot16, align 8
  %p7174 = inttoptr i64 %v7173 to ptr
  store i64 %v7172, ptr %p7174, align 8, !alias.scope !3, !noalias !4
  %v7175 = load i64, ptr %slot16, align 8
  store i64 %v7175, ptr %slot1218, align 8
  %v7176 = load i64, ptr %slot17, align 8
  store i64 %v7176, ptr %slot1219, align 8
  %v7177 = load i64, ptr %slot1218, align 8
  %v7178 = load i64, ptr %slot1219, align 8
  %p7179 = inttoptr i64 %v7177 to ptr
  %p7180 = inttoptr i64 %v7178 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7180, ptr %p7179, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7181 = load i64, ptr %slot14, align 8
  %p7182 = inttoptr i64 %v7181 to ptr
  store i32 2, ptr %p7182, align 4, !alias.scope !3, !noalias !4
  %v7183 = load i64, ptr %slot13, align 8
  %p7184 = inttoptr i64 %v7183 to ptr
  store i32 1, ptr %p7184, align 4, !alias.scope !3, !noalias !4
  %v7185 = load i64, ptr %slot15, align 8
  store i64 %v7185, ptr %slot1220, align 8
  %v7186 = load i64, ptr %slot17, align 8
  store i64 %v7186, ptr %slot1221, align 8
  %v7187 = load i64, ptr %slot1221, align 8
  %v7188 = load i64, ptr %slot1220, align 8
  %p7189 = inttoptr i64 %v7187 to ptr
  %p7190 = inttoptr i64 %v7188 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7190, ptr %p7189, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7191 = load i64, ptr %slot12, align 8
  %p7192 = inttoptr i64 %v7191 to ptr
  store i32 2, ptr %p7192, align 4, !alias.scope !3, !noalias !4
  %v7193 = load i64, ptr %slot14, align 8
  %p7194 = inttoptr i64 %v7193 to ptr
  %ld7195 = load i32, ptr %p7194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7195, ptr %slot1222, align 8
  %v7196 = load i32, ptr %slot1222, align 8
  %v7197 = load i64, ptr %slot12, align 8
  %p7198 = inttoptr i64 %v7197 to ptr
  store i32 %v7196, ptr %p7198, align 4, !alias.scope !3, !noalias !4
  %v7199 = load i64, ptr %slot13, align 8
  %p7200 = inttoptr i64 %v7199 to ptr
  store i32 0, ptr %p7200, align 4, !alias.scope !3, !noalias !4
  %v7201 = load i64, ptr %slot11, align 8
  %p7202 = inttoptr i64 %v7201 to ptr
  store i32 1, ptr %p7202, align 4, !alias.scope !3, !noalias !4
  %v7203 = load i64, ptr %slot1220, align 8
  %p7204 = inttoptr i64 %v7203 to ptr
  %ld7205 = load i64, ptr %p7204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7205, ptr %slot1223, align 8
  %v7206 = load i64, ptr %slot1223, align 8
  %v7207 = load i64, ptr %slot25, align 8
  %p7208 = inttoptr i64 %v7207 to ptr
  store i64 %v7206, ptr %p7208, align 8, !alias.scope !3, !noalias !4
  %v7209 = load i64, ptr %slot22, align 8
  store i64 %v7209, ptr %slot1224, align 8
  %v7210 = load i64, ptr %slot6, align 8
  %p7211 = inttoptr i64 %v7210 to ptr
  %ld7212 = load i32, ptr %p7211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7212, ptr %slot1225, align 8
  %v7213 = load i32, ptr %slot1225, align 8
  %cmp7214 = icmp eq i32 %v7213, 16
  %cv7215 = zext i1 %cmp7214 to i32
  store i32 %cv7215, ptr %slot1226, align 8
  %v7216 = load i64, ptr %slot5, align 8
  %p7217 = inttoptr i64 %v7216 to ptr
  %ld7218 = load i32, ptr %p7217, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7218, ptr %slot1227, align 8
  %v7219 = load i32, ptr %slot1227, align 8
  %v7220 = load i32, ptr %slot1226, align 8
  %op7221 = and i32 %v7219, %v7220
  store i32 %op7221, ptr %slot1228, align 8
  %v7222 = load i32, ptr %slot1228, align 8
  %cv7223 = zext i32 %v7222 to i64
  %cond7224 = icmp ne i64 %cv7223, 0
  br i1 %cond7224, label %bb_rcownlocal1585, label %bb_rcownedlocal1585
bb_rcownlocal1585:
  %v7225 = load i64, ptr %slot22, align 8
  store i64 %v7225, ptr %slot1229, align 8
  %v7226 = load i64, ptr %slot17, align 8
  store i64 %v7226, ptr %slot1230, align 8
  %v7227 = load i64, ptr %slot32, align 8
  store i64 %v7227, ptr %slot1231, align 8
  %v7228 = load i64, ptr %slot1229, align 8
  %p7229 = inttoptr i64 %v7228 to ptr
  %ld7230 = load i64, ptr %p7229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7230, ptr %slot1232, align 8
  %v7231 = load i64, ptr %slot1232, align 8
  %cmp7232 = icmp ne i64 %v7231, 0
  %cv7233 = zext i1 %cmp7232 to i32
  store i32 %cv7233, ptr %slot1233, align 8
  %v7234 = load i32, ptr %slot1233, align 8
  %cv7235 = zext i32 %v7234 to i64
  %cond7236 = icmp ne i64 %cv7235, 0
  br i1 %cond7236, label %bb_rcgnn1592, label %bb_rcgplain1592
bb_rcgnn1592:
  %v7237 = load i64, ptr %slot1232, align 8
  %op7238 = sub i64 %v7237, 16
  store i64 %op7238, ptr %slot1234, align 8
  %v7239 = load i64, ptr %slot1232, align 8
  %p7240 = inttoptr i64 %v7239 to ptr
  %rgep7241 = getelementptr i8, ptr %p7240, i64 -16
  %ld7242 = load i64, ptr %rgep7241, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7242, ptr %slot1235, align 8
  %v7243 = load i64, ptr %slot1235, align 8
  %op7244 = and i64 %v7243, 4611686018427387906
  store i64 %op7244, ptr %slot1236, align 8
  %v7245 = load i64, ptr %slot1236, align 8
  %cmp7246 = icmp ne i64 %v7245, 0
  %cv7247 = zext i1 %cmp7246 to i32
  store i32 %cv7247, ptr %slot1237, align 8
  %v7248 = load i32, ptr %slot1237, align 8
  %cv7249 = zext i32 %v7248 to i64
  %cond7250 = icmp ne i64 %cv7249, 0
  br i1 %cond7250, label %bb_rcgspecial1592, label %bb_rcginc1592
bb_rcginc1592:
  %v7251 = load i64, ptr %slot1232, align 8
  %op7252 = sub i64 %v7251, 32
  store i64 %op7252, ptr %slot1238, align 8
  %v7253 = load i64, ptr %slot1232, align 8
  %p7254 = inttoptr i64 %v7253 to ptr
  %rgep7255 = getelementptr i8, ptr %p7254, i64 -32
  %ld7256 = load i64, ptr %rgep7255, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7256, ptr %slot1239, align 8
  %v7257 = load i64, ptr %slot1239, align 8
  %op7258 = add i64 %v7257, 1
  store i64 %op7258, ptr %slot1240, align 8
  %v7259 = load i64, ptr %slot1240, align 8
  %cmp7260 = icmp eq i64 %v7259, 0
  %cv7261 = zext i1 %cmp7260 to i32
  store i32 %cv7261, ptr %slot1241, align 8
  %v7262 = load i32, ptr %slot1241, align 8
  %cv7263 = zext i32 %v7262 to i64
  %cond7264 = icmp ne i64 %cv7263, 0
  br i1 %cond7264, label %bb_rcglimit1592, label %bb_rcgcapacity1592
bb_rcglimit1592:
  %v7265 = load i64, ptr %slot1, align 8
  %p7266 = inttoptr i64 %v7265 to ptr
  %call7267 = call i32 @myl_qbe_rc_status(ptr %p7266, i32 2) nomerge, !dbg !154
  store i32 %call7267, ptr %slot1242, align 8
  br label %bb_failure
bb_rcgcapacity1592:
  %v7268 = load i64, ptr %slot1240, align 8
  %v7269 = load i64, ptr %slot1232, align 8
  %p7270 = inttoptr i64 %v7269 to ptr
  %rgep7271 = getelementptr i8, ptr %p7270, i64 -32
  store i64 %v7268, ptr %rgep7271, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1592
bb_rcgspecial1592:
  %v7272 = load i64, ptr %slot1235, align 8
  %op7273 = and i64 %v7272, 4611686018427387904
  store i64 %op7273, ptr %slot1243, align 8
  %v7274 = load i64, ptr %slot1243, align 8
  %cmp7275 = icmp ne i64 %v7274, 0
  %cv7276 = zext i1 %cmp7275 to i32
  store i32 %cv7276, ptr %slot1244, align 8
  %v7277 = load i32, ptr %slot1244, align 8
  %cv7278 = zext i32 %v7277 to i64
  %cond7279 = icmp ne i64 %cv7278, 0
  br i1 %cond7279, label %bb_rcgslow1592, label %bb_rcgplain1592
bb_rcgslow1592:
  %v7280 = load i64, ptr %slot31, align 8
  %v7281 = load i64, ptr %slot1230, align 8
  %v7282 = load i64, ptr %slot1229, align 8
  %v7283 = load i64, ptr %slot1231, align 8
  %cv7284 = trunc i64 %v7283 to i32
  %call7285 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v7280, i64 %v7281, i64 %v7282, i32 %cv7284) nomerge, !dbg !154
  store i32 %call7285, ptr %slot1245, align 8
  %v7286 = load i32, ptr %slot1245, align 8
  %cv7287 = zext i32 %v7286 to i64
  %cond7288 = icmp ne i64 %cv7287, 0
  br i1 %cond7288, label %bb_rcsuccess1606, label %bb_rcfailure1606
bb_rcfailure1606:
  %v7289 = load i64, ptr %slot31, align 8
  %p7290 = inttoptr i64 %v7289 to ptr
  %call7291 = call i32 @myl_rc_take_failure(ptr %p7290) nomerge, !dbg !154
  store i32 %call7291, ptr %slot1246, align 8
  %v7292 = load i64, ptr %slot1, align 8
  %p7293 = inttoptr i64 %v7292 to ptr
  %v7294 = load i32, ptr %slot1246, align 8
  %call7295 = call i32 @myl_qbe_rc_status(ptr %p7293, i32 %v7294) nomerge, !dbg !154
  store i32 %call7295, ptr %slot1247, align 8
  br label %bb_failure
bb_rcsuccess1606:
  br label %bb_rcgdone1592
bb_rcgplain1592:
  %v7296 = load i64, ptr %slot1232, align 8
  %v7297 = load i64, ptr %slot1230, align 8
  %p7298 = inttoptr i64 %v7297 to ptr
  store i64 %v7296, ptr %p7298, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1592
bb_rcgdone1592:
  %v7299 = load i64, ptr %slot14, align 8
  %p7300 = inttoptr i64 %v7299 to ptr
  store i32 2, ptr %p7300, align 4, !alias.scope !3, !noalias !4
  %v7301 = load i64, ptr %slot13, align 8
  %p7302 = inttoptr i64 %v7301 to ptr
  store i32 1, ptr %p7302, align 4, !alias.scope !3, !noalias !4
  %v7303 = load i64, ptr %slot5, align 8
  %p7304 = inttoptr i64 %v7303 to ptr
  %ld7305 = load i32, ptr %p7304, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7305, ptr %slot1248, align 8
  %v7306 = load i32, ptr %slot1248, align 8
  %cv7307 = zext i32 %v7306 to i64
  %cond7308 = icmp ne i64 %cv7307, 0
  br i1 %cond7308, label %bb_rcslotdrop1613, label %bb_rcslotdone1613
bb_rcslotdrop1613:
  %v7309 = load i64, ptr %slot5, align 8
  %p7310 = inttoptr i64 %v7309 to ptr
  store i32 0, ptr %p7310, align 4, !alias.scope !3, !noalias !4
  %v7311 = load i64, ptr %slot22, align 8
  store i64 %v7311, ptr %slot1249, align 8
  %v7312 = load i64, ptr %slot6, align 8
  %p7313 = inttoptr i64 %v7312 to ptr
  %ld7314 = load i32, ptr %p7313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7314, ptr %slot1250, align 8
  %v7315 = load i32, ptr %slot1250, align 8
  %op7316 = and i32 %v7315, 28
  store i32 %op7316, ptr %slot1251, align 8
  %v7317 = load i32, ptr %slot1251, align 8
  %cv7318 = zext i32 %v7317 to i64
  %cond7319 = icmp ne i64 %cv7318, 0
  br i1 %cond7319, label %bb_rcslotrole1613, label %bb_rcslotowner1613
bb_rcslotrole1613:
  %v7320 = load i64, ptr %slot31, align 8
  store i64 %v7320, ptr %slot1252, align 8
  %v7321 = load i64, ptr %slot1249, align 8
  %p7322 = inttoptr i64 %v7321 to ptr
  %ld7323 = load i64, ptr %p7322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7323, ptr %slot1253, align 8
  %v7324 = load i64, ptr %slot1253, align 8
  %cmp7325 = icmp ne i64 %v7324, 0
  %cv7326 = zext i1 %cmp7325 to i32
  store i32 %cv7326, ptr %slot1254, align 8
  %v7327 = load i32, ptr %slot1254, align 8
  %cv7328 = zext i32 %v7327 to i64
  %cond7329 = icmp ne i64 %cv7328, 0
  br i1 %cond7329, label %bb_rcgnn1629, label %bb_rcgdone1629
bb_rcgnn1629:
  %v7330 = load i64, ptr %slot1253, align 8
  %op7331 = sub i64 %v7330, 16
  store i64 %op7331, ptr %slot1255, align 8
  %v7332 = load i64, ptr %slot1253, align 8
  %p7333 = inttoptr i64 %v7332 to ptr
  %rgep7334 = getelementptr i8, ptr %p7333, i64 -16
  %ld7335 = load i64, ptr %rgep7334, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7335, ptr %slot1256, align 8
  %v7336 = load i64, ptr %slot1256, align 8
  %op7337 = and i64 %v7336, 4611686018427387906
  store i64 %op7337, ptr %slot1257, align 8
  %v7338 = load i64, ptr %slot1257, align 8
  %cmp7339 = icmp ne i64 %v7338, 0
  %cv7340 = zext i1 %cmp7339 to i32
  store i32 %cv7340, ptr %slot1258, align 8
  %v7341 = load i32, ptr %slot1258, align 8
  %cv7342 = zext i32 %v7341 to i64
  %cond7343 = icmp ne i64 %cv7342, 0
  br i1 %cond7343, label %bb_rcgclear1629, label %bb_rcgcounted1629
bb_rcgcounted1629:
  %v7344 = load i64, ptr %slot1253, align 8
  %op7345 = sub i64 %v7344, 24
  store i64 %op7345, ptr %slot1259, align 8
  %v7346 = load i64, ptr %slot1253, align 8
  %p7347 = inttoptr i64 %v7346 to ptr
  %rgep7348 = getelementptr i8, ptr %p7347, i64 -24
  %ld7349 = load i64, ptr %rgep7348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7349, ptr %slot1260, align 8
  %v7350 = load i64, ptr %slot1260, align 8
  %op7351 = sub i64 %v7350, 1
  store i64 %op7351, ptr %slot1261, align 8
  %v7352 = load i64, ptr %slot1261, align 8
  %cmp7353 = icmp eq i64 %v7352, 0
  %cv7354 = zext i1 %cmp7353 to i32
  store i32 %cv7354, ptr %slot1262, align 8
  %v7355 = load i32, ptr %slot1262, align 8
  %cv7356 = zext i32 %v7355 to i64
  %cond7357 = icmp ne i64 %cv7356, 0
  br i1 %cond7357, label %bb_rcglast1629, label %bb_rcgdec1629
bb_rcglast1629:
  %v7358 = load i64, ptr %slot1253, align 8
  %op7359 = sub i64 %v7358, 32
  store i64 %op7359, ptr %slot1263, align 8
  %v7360 = load i64, ptr %slot1253, align 8
  %p7361 = inttoptr i64 %v7360 to ptr
  %rgep7362 = getelementptr i8, ptr %p7361, i64 -32
  %ld7363 = load i64, ptr %rgep7362, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7363, ptr %slot1264, align 8
  %v7364 = load i64, ptr %slot1264, align 8
  %cmp7365 = icmp ne i64 %v7364, 0
  %cv7366 = zext i1 %cmp7365 to i32
  store i32 %cv7366, ptr %slot1265, align 8
  %v7367 = load i32, ptr %slot1265, align 8
  %cv7368 = zext i32 %v7367 to i64
  %cond7369 = icmp ne i64 %cv7368, 0
  br i1 %cond7369, label %bb_rcgdec1629, label %bb_rcgslow1629
bb_rcgslow1629:
  %v7370 = load i64, ptr %slot1252, align 8
  %v7371 = load i64, ptr %slot1249, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v7370, i64 %v7371) nomerge, !dbg !154
  br label %bb_rcgdone1629
bb_rcgdec1629:
  %v7372 = load i64, ptr %slot1261, align 8
  %v7373 = load i64, ptr %slot1253, align 8
  %p7374 = inttoptr i64 %v7373 to ptr
  %rgep7375 = getelementptr i8, ptr %p7374, i64 -24
  store i64 %v7372, ptr %rgep7375, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1629
bb_rcgclear1629:
  %v7376 = load i64, ptr %slot1249, align 8
  %p7377 = inttoptr i64 %v7376 to ptr
  store i64 0, ptr %p7377, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1629
bb_rcgdone1629:
  br label %bb_rcslotdone1613
bb_rcslotowner1613:
  %v7378 = load i64, ptr %slot31, align 8
  store i64 %v7378, ptr %slot1266, align 8
  %v7379 = load i64, ptr %slot1249, align 8
  %p7380 = inttoptr i64 %v7379 to ptr
  %ld7381 = load i64, ptr %p7380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7381, ptr %slot1267, align 8
  %v7382 = load i64, ptr %slot1267, align 8
  %cmp7383 = icmp ne i64 %v7382, 0
  %cv7384 = zext i1 %cmp7383 to i32
  store i32 %cv7384, ptr %slot1268, align 8
  %v7385 = load i32, ptr %slot1268, align 8
  %cv7386 = zext i32 %v7385 to i64
  %cond7387 = icmp ne i64 %cv7386, 0
  br i1 %cond7387, label %bb_rcgnn1644, label %bb_rcgdone1644
bb_rcgnn1644:
  %v7388 = load i64, ptr %slot1267, align 8
  %op7389 = sub i64 %v7388, 16
  store i64 %op7389, ptr %slot1269, align 8
  %v7390 = load i64, ptr %slot1267, align 8
  %p7391 = inttoptr i64 %v7390 to ptr
  %rgep7392 = getelementptr i8, ptr %p7391, i64 -16
  %ld7393 = load i64, ptr %rgep7392, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7393, ptr %slot1270, align 8
  %v7394 = load i64, ptr %slot1270, align 8
  %op7395 = and i64 %v7394, 4611686018427387906
  store i64 %op7395, ptr %slot1271, align 8
  %v7396 = load i64, ptr %slot1271, align 8
  %cmp7397 = icmp ne i64 %v7396, 0
  %cv7398 = zext i1 %cmp7397 to i32
  store i32 %cv7398, ptr %slot1272, align 8
  %v7399 = load i32, ptr %slot1272, align 8
  %cv7400 = zext i32 %v7399 to i64
  %cond7401 = icmp ne i64 %cv7400, 0
  br i1 %cond7401, label %bb_rcgclear1644, label %bb_rcgcounted1644
bb_rcgcounted1644:
  %v7402 = load i64, ptr %slot1267, align 8
  %op7403 = sub i64 %v7402, 32
  store i64 %op7403, ptr %slot1273, align 8
  %v7404 = load i64, ptr %slot1267, align 8
  %p7405 = inttoptr i64 %v7404 to ptr
  %rgep7406 = getelementptr i8, ptr %p7405, i64 -32
  %ld7407 = load i64, ptr %rgep7406, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7407, ptr %slot1274, align 8
  %v7408 = load i64, ptr %slot1274, align 8
  %op7409 = sub i64 %v7408, 1
  store i64 %op7409, ptr %slot1275, align 8
  %v7410 = load i64, ptr %slot1275, align 8
  %cmp7411 = icmp eq i64 %v7410, 0
  %cv7412 = zext i1 %cmp7411 to i32
  store i32 %cv7412, ptr %slot1276, align 8
  %v7413 = load i32, ptr %slot1276, align 8
  %cv7414 = zext i32 %v7413 to i64
  %cond7415 = icmp ne i64 %cv7414, 0
  br i1 %cond7415, label %bb_rcglast1644, label %bb_rcgdec1644
bb_rcglast1644:
  %v7416 = load i64, ptr %slot1267, align 8
  %op7417 = sub i64 %v7416, 24
  store i64 %op7417, ptr %slot1277, align 8
  %v7418 = load i64, ptr %slot1267, align 8
  %p7419 = inttoptr i64 %v7418 to ptr
  %rgep7420 = getelementptr i8, ptr %p7419, i64 -24
  %ld7421 = load i64, ptr %rgep7420, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7421, ptr %slot1278, align 8
  %v7422 = load i64, ptr %slot1278, align 8
  %cmp7423 = icmp ne i64 %v7422, 0
  %cv7424 = zext i1 %cmp7423 to i32
  store i32 %cv7424, ptr %slot1279, align 8
  %v7425 = load i32, ptr %slot1279, align 8
  %cv7426 = zext i32 %v7425 to i64
  %cond7427 = icmp ne i64 %cv7426, 0
  br i1 %cond7427, label %bb_rcgdec1644, label %bb_rcgslow1644
bb_rcgslow1644:
  %v7428 = load i64, ptr %slot1266, align 8
  %v7429 = load i64, ptr %slot1249, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v7428, i64 %v7429) nomerge, !dbg !154
  br label %bb_rcgdone1644
bb_rcgdec1644:
  %v7430 = load i64, ptr %slot1275, align 8
  %v7431 = load i64, ptr %slot1267, align 8
  %p7432 = inttoptr i64 %v7431 to ptr
  %rgep7433 = getelementptr i8, ptr %p7432, i64 -32
  store i64 %v7430, ptr %rgep7433, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1644
bb_rcgclear1644:
  %v7434 = load i64, ptr %slot1249, align 8
  %p7435 = inttoptr i64 %v7434 to ptr
  store i64 0, ptr %p7435, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1644
bb_rcgdone1644:
  br label %bb_rcslotdone1613
bb_rcslotdone1613:
  %v7436 = load i64, ptr %slot17, align 8
  store i64 %v7436, ptr %slot1280, align 8
  %v7437 = load i64, ptr %slot1280, align 8
  %v7438 = load i64, ptr %slot1229, align 8
  %p7439 = inttoptr i64 %v7437 to ptr
  %p7440 = inttoptr i64 %v7438 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7440, ptr %p7439, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7441 = load i64, ptr %slot6, align 8
  %p7442 = inttoptr i64 %v7441 to ptr
  store i32 2, ptr %p7442, align 4, !alias.scope !3, !noalias !4
  %v7443 = load i64, ptr %slot5, align 8
  %p7444 = inttoptr i64 %v7443 to ptr
  store i32 1, ptr %p7444, align 4, !alias.scope !3, !noalias !4
  %v7445 = load i64, ptr %slot13, align 8
  %p7446 = inttoptr i64 %v7445 to ptr
  store i32 0, ptr %p7446, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal1585
bb_rcownedlocal1585:
  %v7447 = load i64, ptr %slot6, align 8
  %p7448 = inttoptr i64 %v7447 to ptr
  store i32 2, ptr %p7448, align 4, !alias.scope !3, !noalias !4
  %v7449 = load i64, ptr %slot1224, align 8
  %p7450 = inttoptr i64 %v7449 to ptr
  %ld7451 = load i64, ptr %p7450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7451, ptr %slot1281, align 8
  %v7452 = load i64, ptr %slot1281, align 8
  %cmp7453 = icmp ne i64 %v7452, 0
  %cv7454 = zext i1 %cmp7453 to i32
  store i32 %cv7454, ptr %slot1282, align 8
  %v7455 = load i32, ptr %slot1282, align 8
  %cv7456 = zext i32 %v7455 to i64
  %cond7457 = icmp ne i64 %cv7456, 0
  br i1 %cond7457, label %bb_rcguniquenn1653, label %bb_rcgunique1653
bb_rcguniquenn1653:
  %v7458 = load i64, ptr %slot1281, align 8
  %op7459 = sub i64 %v7458, 16
  store i64 %op7459, ptr %slot1283, align 8
  %v7460 = load i64, ptr %slot1281, align 8
  %p7461 = inttoptr i64 %v7460 to ptr
  %rgep7462 = getelementptr i8, ptr %p7461, i64 -16
  %ld7463 = load i64, ptr %rgep7462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7463, ptr %slot1284, align 8
  %v7464 = load i64, ptr %slot1284, align 8
  %op7465 = and i64 %v7464, 6917529027641081858
  store i64 %op7465, ptr %slot1285, align 8
  %v7466 = load i64, ptr %slot1285, align 8
  %cmp7467 = icmp ne i64 %v7466, 0
  %cv7468 = zext i1 %cmp7467 to i32
  store i32 %cv7468, ptr %slot1286, align 8
  %v7469 = load i32, ptr %slot1286, align 8
  %cv7470 = zext i32 %v7469 to i64
  %cond7471 = icmp ne i64 %cv7470, 0
  br i1 %cond7471, label %bb_rcguniqueslow1653, label %bb_rcguniquecount1653
bb_rcguniquecount1653:
  %v7472 = load i64, ptr %slot1281, align 8
  %op7473 = sub i64 %v7472, 32
  store i64 %op7473, ptr %slot1287, align 8
  %v7474 = load i64, ptr %slot1281, align 8
  %p7475 = inttoptr i64 %v7474 to ptr
  %rgep7476 = getelementptr i8, ptr %p7475, i64 -32
  %ld7477 = load i64, ptr %rgep7476, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7477, ptr %slot1288, align 8
  %v7478 = load i64, ptr %slot1288, align 8
  %cmp7479 = icmp ult i64 %v7478, 2
  %cv7480 = zext i1 %cmp7479 to i32
  store i32 %cv7480, ptr %slot1289, align 8
  %v7481 = load i32, ptr %slot1289, align 8
  %cv7482 = zext i32 %v7481 to i64
  %cond7483 = icmp ne i64 %cv7482, 0
  br i1 %cond7483, label %bb_rcgunique1653, label %bb_rcguniqueslow1653
bb_rcguniqueslow1653:
  %v7484 = load i64, ptr %slot1, align 8
  %p7485 = inttoptr i64 %v7484 to ptr
  %p7486 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v7487 = load i64, ptr %slot1224, align 8
  %p7488 = inttoptr i64 %v7487 to ptr
  %v7489 = load i64, ptr %slot5, align 8
  %p7490 = inttoptr i64 %v7489 to ptr
  %call7491 = call i32 @myl_qbe_rc_unique_local(ptr %p7485, ptr %p7486, ptr %p7488, ptr %p7490) nomerge, !dbg !154
  store i32 %call7491, ptr %slot1290, align 8
  %v7492 = load i32, ptr %slot1290, align 8
  %cv7493 = zext i32 %v7492 to i64
  %cond7494 = icmp ne i64 %cv7493, 0
  br i1 %cond7494, label %bb_rcunique1664, label %bb_failure
bb_rcunique1664:
  br label %bb_rcgunique1653
bb_rcgunique1653:
  %v7495 = load i64, ptr %slot22, align 8
  %p7496 = inttoptr i64 %v7495 to ptr
  %ld7497 = load i64, ptr %p7496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7497, ptr %slot1291, align 8
  %v7498 = load i64, ptr %slot25, align 8
  store i64 %v7498, ptr %slot1292, align 8
  %v7499 = load i64, ptr %slot1292, align 8
  %p7500 = inttoptr i64 %v7499 to ptr
  %ld7501 = load i64, ptr %p7500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7501, ptr %slot1293, align 8
  %v7502 = load i64, ptr %slot1293, align 8
  %v7503 = load i64, ptr %slot18, align 8
  %p7504 = inttoptr i64 %v7503 to ptr
  store i64 %v7502, ptr %p7504, align 8, !alias.scope !3, !noalias !4
  %v7505 = load i64, ptr %slot18, align 8
  store i64 %v7505, ptr %slot1294, align 8
  %v7506 = load i64, ptr %slot31, align 8
  %v7507 = load i64, ptr %slot1291, align 8
  %v7508 = load i64, ptr %slot1294, align 8
  %call7509 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v7506, i64 %v7507, i64 %v7508) nomerge, !dbg !154
  store i32 %call7509, ptr %slot1295, align 8
  %v7510 = load i32, ptr %slot1295, align 8
  %cv7511 = zext i32 %v7510 to i64
  %cond7512 = icmp ne i64 %cv7511, 0
  br i1 %cond7512, label %bb_success1670, label %bb_failed1670
bb_failed1670:
  %v7513 = load i64, ptr %slot1, align 8
  %p7514 = inttoptr i64 %v7513 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7514) nomerge, !dbg !154
  unreachable
bb_success1670:
  %v7515 = load i64, ptr %slot25, align 8
  %p7516 = inttoptr i64 %v7515 to ptr
  store i64 0, ptr %p7516, align 8, !alias.scope !3, !noalias !4
  %v7517 = load i64, ptr %slot11, align 8
  %p7518 = inttoptr i64 %v7517 to ptr
  %ld7519 = load i32, ptr %p7518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7519, ptr %slot1296, align 8
  %v7520 = load i32, ptr %slot1296, align 8
  %cv7521 = zext i32 %v7520 to i64
  %cond7522 = icmp ne i64 %cv7521, 0
  br i1 %cond7522, label %bb_rcslotdrop1673, label %bb_rcslotdone1673
bb_rcslotdrop1673:
  %v7523 = load i64, ptr %slot11, align 8
  %p7524 = inttoptr i64 %v7523 to ptr
  store i32 0, ptr %p7524, align 4, !alias.scope !3, !noalias !4
  %v7525 = load i64, ptr %slot15, align 8
  store i64 %v7525, ptr %slot1297, align 8
  %v7526 = load i64, ptr %slot12, align 8
  %p7527 = inttoptr i64 %v7526 to ptr
  %ld7528 = load i32, ptr %p7527, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7528, ptr %slot1298, align 8
  %v7529 = load i32, ptr %slot1298, align 8
  %op7530 = and i32 %v7529, 28
  store i32 %op7530, ptr %slot1299, align 8
  %v7531 = load i32, ptr %slot1299, align 8
  %cv7532 = zext i32 %v7531 to i64
  %cond7533 = icmp ne i64 %cv7532, 0
  br i1 %cond7533, label %bb_rcslotrole1673, label %bb_rcslotowner1673
bb_rcslotrole1673:
  %v7534 = load i64, ptr %slot31, align 8
  store i64 %v7534, ptr %slot1300, align 8
  %v7535 = load i64, ptr %slot1297, align 8
  %p7536 = inttoptr i64 %v7535 to ptr
  %ld7537 = load i64, ptr %p7536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7537, ptr %slot1301, align 8
  %v7538 = load i64, ptr %slot1301, align 8
  %cmp7539 = icmp ne i64 %v7538, 0
  %cv7540 = zext i1 %cmp7539 to i32
  store i32 %cv7540, ptr %slot1302, align 8
  %v7541 = load i32, ptr %slot1302, align 8
  %cv7542 = zext i32 %v7541 to i64
  %cond7543 = icmp ne i64 %cv7542, 0
  br i1 %cond7543, label %bb_rcgnn1689, label %bb_rcgdone1689
bb_rcgnn1689:
  %v7544 = load i64, ptr %slot1301, align 8
  %op7545 = sub i64 %v7544, 16
  store i64 %op7545, ptr %slot1303, align 8
  %v7546 = load i64, ptr %slot1301, align 8
  %p7547 = inttoptr i64 %v7546 to ptr
  %rgep7548 = getelementptr i8, ptr %p7547, i64 -16
  %ld7549 = load i64, ptr %rgep7548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7549, ptr %slot1304, align 8
  %v7550 = load i64, ptr %slot1304, align 8
  %op7551 = and i64 %v7550, 4611686018427387906
  store i64 %op7551, ptr %slot1305, align 8
  %v7552 = load i64, ptr %slot1305, align 8
  %cmp7553 = icmp ne i64 %v7552, 0
  %cv7554 = zext i1 %cmp7553 to i32
  store i32 %cv7554, ptr %slot1306, align 8
  %v7555 = load i32, ptr %slot1306, align 8
  %cv7556 = zext i32 %v7555 to i64
  %cond7557 = icmp ne i64 %cv7556, 0
  br i1 %cond7557, label %bb_rcgclear1689, label %bb_rcgcounted1689
bb_rcgcounted1689:
  %v7558 = load i64, ptr %slot1301, align 8
  %op7559 = sub i64 %v7558, 24
  store i64 %op7559, ptr %slot1307, align 8
  %v7560 = load i64, ptr %slot1301, align 8
  %p7561 = inttoptr i64 %v7560 to ptr
  %rgep7562 = getelementptr i8, ptr %p7561, i64 -24
  %ld7563 = load i64, ptr %rgep7562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7563, ptr %slot1308, align 8
  %v7564 = load i64, ptr %slot1308, align 8
  %op7565 = sub i64 %v7564, 1
  store i64 %op7565, ptr %slot1309, align 8
  %v7566 = load i64, ptr %slot1309, align 8
  %cmp7567 = icmp eq i64 %v7566, 0
  %cv7568 = zext i1 %cmp7567 to i32
  store i32 %cv7568, ptr %slot1310, align 8
  %v7569 = load i32, ptr %slot1310, align 8
  %cv7570 = zext i32 %v7569 to i64
  %cond7571 = icmp ne i64 %cv7570, 0
  br i1 %cond7571, label %bb_rcglast1689, label %bb_rcgdec1689
bb_rcglast1689:
  %v7572 = load i64, ptr %slot1301, align 8
  %op7573 = sub i64 %v7572, 32
  store i64 %op7573, ptr %slot1311, align 8
  %v7574 = load i64, ptr %slot1301, align 8
  %p7575 = inttoptr i64 %v7574 to ptr
  %rgep7576 = getelementptr i8, ptr %p7575, i64 -32
  %ld7577 = load i64, ptr %rgep7576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7577, ptr %slot1312, align 8
  %v7578 = load i64, ptr %slot1312, align 8
  %cmp7579 = icmp ne i64 %v7578, 0
  %cv7580 = zext i1 %cmp7579 to i32
  store i32 %cv7580, ptr %slot1313, align 8
  %v7581 = load i32, ptr %slot1313, align 8
  %cv7582 = zext i32 %v7581 to i64
  %cond7583 = icmp ne i64 %cv7582, 0
  br i1 %cond7583, label %bb_rcgdec1689, label %bb_rcgslow1689
bb_rcgslow1689:
  %v7584 = load i64, ptr %slot1300, align 8
  %v7585 = load i64, ptr %slot1297, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v7584, i64 %v7585) nomerge, !dbg !154
  br label %bb_rcgdone1689
bb_rcgdec1689:
  %v7586 = load i64, ptr %slot1309, align 8
  %v7587 = load i64, ptr %slot1301, align 8
  %p7588 = inttoptr i64 %v7587 to ptr
  %rgep7589 = getelementptr i8, ptr %p7588, i64 -24
  store i64 %v7586, ptr %rgep7589, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1689
bb_rcgclear1689:
  %v7590 = load i64, ptr %slot1297, align 8
  %p7591 = inttoptr i64 %v7590 to ptr
  store i64 0, ptr %p7591, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1689
bb_rcgdone1689:
  br label %bb_rcslotdone1673
bb_rcslotowner1673:
  %v7592 = load i64, ptr %slot31, align 8
  store i64 %v7592, ptr %slot1314, align 8
  %v7593 = load i64, ptr %slot1297, align 8
  %p7594 = inttoptr i64 %v7593 to ptr
  %ld7595 = load i64, ptr %p7594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7595, ptr %slot1315, align 8
  %v7596 = load i64, ptr %slot1315, align 8
  %cmp7597 = icmp ne i64 %v7596, 0
  %cv7598 = zext i1 %cmp7597 to i32
  store i32 %cv7598, ptr %slot1316, align 8
  %v7599 = load i32, ptr %slot1316, align 8
  %cv7600 = zext i32 %v7599 to i64
  %cond7601 = icmp ne i64 %cv7600, 0
  br i1 %cond7601, label %bb_rcgnn1704, label %bb_rcgdone1704
bb_rcgnn1704:
  %v7602 = load i64, ptr %slot1315, align 8
  %op7603 = sub i64 %v7602, 16
  store i64 %op7603, ptr %slot1317, align 8
  %v7604 = load i64, ptr %slot1315, align 8
  %p7605 = inttoptr i64 %v7604 to ptr
  %rgep7606 = getelementptr i8, ptr %p7605, i64 -16
  %ld7607 = load i64, ptr %rgep7606, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7607, ptr %slot1318, align 8
  %v7608 = load i64, ptr %slot1318, align 8
  %op7609 = and i64 %v7608, 4611686018427387906
  store i64 %op7609, ptr %slot1319, align 8
  %v7610 = load i64, ptr %slot1319, align 8
  %cmp7611 = icmp ne i64 %v7610, 0
  %cv7612 = zext i1 %cmp7611 to i32
  store i32 %cv7612, ptr %slot1320, align 8
  %v7613 = load i32, ptr %slot1320, align 8
  %cv7614 = zext i32 %v7613 to i64
  %cond7615 = icmp ne i64 %cv7614, 0
  br i1 %cond7615, label %bb_rcgclear1704, label %bb_rcgcounted1704
bb_rcgcounted1704:
  %v7616 = load i64, ptr %slot1315, align 8
  %op7617 = sub i64 %v7616, 32
  store i64 %op7617, ptr %slot1321, align 8
  %v7618 = load i64, ptr %slot1315, align 8
  %p7619 = inttoptr i64 %v7618 to ptr
  %rgep7620 = getelementptr i8, ptr %p7619, i64 -32
  %ld7621 = load i64, ptr %rgep7620, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7621, ptr %slot1322, align 8
  %v7622 = load i64, ptr %slot1322, align 8
  %op7623 = sub i64 %v7622, 1
  store i64 %op7623, ptr %slot1323, align 8
  %v7624 = load i64, ptr %slot1323, align 8
  %cmp7625 = icmp eq i64 %v7624, 0
  %cv7626 = zext i1 %cmp7625 to i32
  store i32 %cv7626, ptr %slot1324, align 8
  %v7627 = load i32, ptr %slot1324, align 8
  %cv7628 = zext i32 %v7627 to i64
  %cond7629 = icmp ne i64 %cv7628, 0
  br i1 %cond7629, label %bb_rcglast1704, label %bb_rcgdec1704
bb_rcglast1704:
  %v7630 = load i64, ptr %slot1315, align 8
  %op7631 = sub i64 %v7630, 24
  store i64 %op7631, ptr %slot1325, align 8
  %v7632 = load i64, ptr %slot1315, align 8
  %p7633 = inttoptr i64 %v7632 to ptr
  %rgep7634 = getelementptr i8, ptr %p7633, i64 -24
  %ld7635 = load i64, ptr %rgep7634, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7635, ptr %slot1326, align 8
  %v7636 = load i64, ptr %slot1326, align 8
  %cmp7637 = icmp ne i64 %v7636, 0
  %cv7638 = zext i1 %cmp7637 to i32
  store i32 %cv7638, ptr %slot1327, align 8
  %v7639 = load i32, ptr %slot1327, align 8
  %cv7640 = zext i32 %v7639 to i64
  %cond7641 = icmp ne i64 %cv7640, 0
  br i1 %cond7641, label %bb_rcgdec1704, label %bb_rcgslow1704
bb_rcgslow1704:
  %v7642 = load i64, ptr %slot1314, align 8
  %v7643 = load i64, ptr %slot1297, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v7642, i64 %v7643) nomerge, !dbg !154
  br label %bb_rcgdone1704
bb_rcgdec1704:
  %v7644 = load i64, ptr %slot1323, align 8
  %v7645 = load i64, ptr %slot1315, align 8
  %p7646 = inttoptr i64 %v7645 to ptr
  %rgep7647 = getelementptr i8, ptr %p7646, i64 -32
  store i64 %v7644, ptr %rgep7647, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1704
bb_rcgclear1704:
  %v7648 = load i64, ptr %slot1297, align 8
  %p7649 = inttoptr i64 %v7648 to ptr
  store i64 0, ptr %p7649, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1704
bb_rcgdone1704:
  br label %bb_rcslotdone1673
bb_rcslotdone1673:
  %v7650 = load i64, ptr %slot21, align 8
  %p7651 = inttoptr i64 %v7650 to ptr
  %ld7652 = load i64, ptr %p7651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7652, ptr %slot1328, align 8
  %v7653 = load i64, ptr %slot1328, align 8
  %v7654 = load i64, ptr %slot25, align 8
  %p7655 = inttoptr i64 %v7654 to ptr
  store i64 %v7653, ptr %p7655, align 8, !alias.scope !3, !noalias !4
  %v7656 = load i64, ptr %slot25, align 8
  %p7657 = inttoptr i64 %v7656 to ptr
  %ld7658 = load i64, ptr %p7657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7658, ptr %slot1329, align 8
  %v7659 = load i64, ptr %slot31, align 8
  %p7660 = inttoptr i64 %v7659 to ptr
  %v7661 = load i64, ptr %slot1329, align 8
  %p7662 = inttoptr i64 %v7661 to ptr
  %call7663 = call ptr @myl_native_text_scalar(ptr %p7660, ptr %p7662, i32 0) nomerge, !dbg !156
  %calladdr7664 = ptrtoint ptr %call7663 to i64
  store i64 %calladdr7664, ptr %slot1330, align 8
  %v7665 = load i64, ptr %slot1330, align 8
  %cond7666 = icmp ne i64 %v7665, 0
  br i1 %cond7666, label %bb_success1711, label %bb_failed1711
bb_failed1711:
  %v7667 = load i64, ptr %slot1, align 8
  %p7668 = inttoptr i64 %v7667 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7668) nomerge, !dbg !156
  unreachable
bb_success1711:
  %v7669 = load i64, ptr %slot1330, align 8
  %v7670 = load i64, ptr %slot25, align 8
  %p7671 = inttoptr i64 %v7670 to ptr
  store i64 %v7669, ptr %p7671, align 8, !alias.scope !3, !noalias !4
  %v7672 = load i64, ptr %slot25, align 8
  %p7673 = inttoptr i64 %v7672 to ptr
  %ld7674 = load i64, ptr %p7673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7674, ptr %slot1331, align 8
  %v7675 = load i64, ptr %slot1331, align 8
  %v7676 = load i64, ptr %slot16, align 8
  %p7677 = inttoptr i64 %v7676 to ptr
  store i64 %v7675, ptr %p7677, align 8, !alias.scope !3, !noalias !4
  %v7678 = load i64, ptr %slot16, align 8
  store i64 %v7678, ptr %slot1332, align 8
  %v7679 = load i64, ptr %slot17, align 8
  store i64 %v7679, ptr %slot1333, align 8
  %v7680 = load i64, ptr %slot1332, align 8
  %v7681 = load i64, ptr %slot1333, align 8
  %p7682 = inttoptr i64 %v7680 to ptr
  %p7683 = inttoptr i64 %v7681 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7683, ptr %p7682, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7684 = load i64, ptr %slot14, align 8
  %p7685 = inttoptr i64 %v7684 to ptr
  store i32 2, ptr %p7685, align 4, !alias.scope !3, !noalias !4
  %v7686 = load i64, ptr %slot13, align 8
  %p7687 = inttoptr i64 %v7686 to ptr
  store i32 1, ptr %p7687, align 4, !alias.scope !3, !noalias !4
  %v7688 = load i64, ptr %slot15, align 8
  store i64 %v7688, ptr %slot1334, align 8
  %v7689 = load i64, ptr %slot17, align 8
  store i64 %v7689, ptr %slot1335, align 8
  %v7690 = load i64, ptr %slot1335, align 8
  %v7691 = load i64, ptr %slot1334, align 8
  %p7692 = inttoptr i64 %v7690 to ptr
  %p7693 = inttoptr i64 %v7691 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7693, ptr %p7692, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7694 = load i64, ptr %slot12, align 8
  %p7695 = inttoptr i64 %v7694 to ptr
  store i32 2, ptr %p7695, align 4, !alias.scope !3, !noalias !4
  %v7696 = load i64, ptr %slot14, align 8
  %p7697 = inttoptr i64 %v7696 to ptr
  %ld7698 = load i32, ptr %p7697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7698, ptr %slot1336, align 8
  %v7699 = load i32, ptr %slot1336, align 8
  %v7700 = load i64, ptr %slot12, align 8
  %p7701 = inttoptr i64 %v7700 to ptr
  store i32 %v7699, ptr %p7701, align 4, !alias.scope !3, !noalias !4
  %v7702 = load i64, ptr %slot13, align 8
  %p7703 = inttoptr i64 %v7702 to ptr
  store i32 0, ptr %p7703, align 4, !alias.scope !3, !noalias !4
  %v7704 = load i64, ptr %slot11, align 8
  %p7705 = inttoptr i64 %v7704 to ptr
  store i32 1, ptr %p7705, align 4, !alias.scope !3, !noalias !4
  %v7706 = load i64, ptr %slot1334, align 8
  %p7707 = inttoptr i64 %v7706 to ptr
  %ld7708 = load i64, ptr %p7707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7708, ptr %slot1337, align 8
  %v7709 = load i64, ptr %slot1337, align 8
  %v7710 = load i64, ptr %slot25, align 8
  %p7711 = inttoptr i64 %v7710 to ptr
  store i64 %v7709, ptr %p7711, align 8, !alias.scope !3, !noalias !4
  %v7712 = load i64, ptr %slot22, align 8
  store i64 %v7712, ptr %slot1338, align 8
  %v7713 = load i64, ptr %slot6, align 8
  %p7714 = inttoptr i64 %v7713 to ptr
  %ld7715 = load i32, ptr %p7714, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7715, ptr %slot1339, align 8
  %v7716 = load i32, ptr %slot1339, align 8
  %cmp7717 = icmp eq i32 %v7716, 16
  %cv7718 = zext i1 %cmp7717 to i32
  store i32 %cv7718, ptr %slot1340, align 8
  %v7719 = load i64, ptr %slot5, align 8
  %p7720 = inttoptr i64 %v7719 to ptr
  %ld7721 = load i32, ptr %p7720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7721, ptr %slot1341, align 8
  %v7722 = load i32, ptr %slot1341, align 8
  %v7723 = load i32, ptr %slot1340, align 8
  %op7724 = and i32 %v7722, %v7723
  store i32 %op7724, ptr %slot1342, align 8
  %v7725 = load i32, ptr %slot1342, align 8
  %cv7726 = zext i32 %v7725 to i64
  %cond7727 = icmp ne i64 %cv7726, 0
  br i1 %cond7727, label %bb_rcownlocal1732, label %bb_rcownedlocal1732
bb_rcownlocal1732:
  %v7728 = load i64, ptr %slot22, align 8
  store i64 %v7728, ptr %slot1343, align 8
  %v7729 = load i64, ptr %slot17, align 8
  store i64 %v7729, ptr %slot1344, align 8
  %v7730 = load i64, ptr %slot32, align 8
  store i64 %v7730, ptr %slot1345, align 8
  %v7731 = load i64, ptr %slot1343, align 8
  %p7732 = inttoptr i64 %v7731 to ptr
  %ld7733 = load i64, ptr %p7732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7733, ptr %slot1346, align 8
  %v7734 = load i64, ptr %slot1346, align 8
  %cmp7735 = icmp ne i64 %v7734, 0
  %cv7736 = zext i1 %cmp7735 to i32
  store i32 %cv7736, ptr %slot1347, align 8
  %v7737 = load i32, ptr %slot1347, align 8
  %cv7738 = zext i32 %v7737 to i64
  %cond7739 = icmp ne i64 %cv7738, 0
  br i1 %cond7739, label %bb_rcgnn1739, label %bb_rcgplain1739
bb_rcgnn1739:
  %v7740 = load i64, ptr %slot1346, align 8
  %op7741 = sub i64 %v7740, 16
  store i64 %op7741, ptr %slot1348, align 8
  %v7742 = load i64, ptr %slot1346, align 8
  %p7743 = inttoptr i64 %v7742 to ptr
  %rgep7744 = getelementptr i8, ptr %p7743, i64 -16
  %ld7745 = load i64, ptr %rgep7744, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7745, ptr %slot1349, align 8
  %v7746 = load i64, ptr %slot1349, align 8
  %op7747 = and i64 %v7746, 4611686018427387906
  store i64 %op7747, ptr %slot1350, align 8
  %v7748 = load i64, ptr %slot1350, align 8
  %cmp7749 = icmp ne i64 %v7748, 0
  %cv7750 = zext i1 %cmp7749 to i32
  store i32 %cv7750, ptr %slot1351, align 8
  %v7751 = load i32, ptr %slot1351, align 8
  %cv7752 = zext i32 %v7751 to i64
  %cond7753 = icmp ne i64 %cv7752, 0
  br i1 %cond7753, label %bb_rcgspecial1739, label %bb_rcginc1739
bb_rcginc1739:
  %v7754 = load i64, ptr %slot1346, align 8
  %op7755 = sub i64 %v7754, 32
  store i64 %op7755, ptr %slot1352, align 8
  %v7756 = load i64, ptr %slot1346, align 8
  %p7757 = inttoptr i64 %v7756 to ptr
  %rgep7758 = getelementptr i8, ptr %p7757, i64 -32
  %ld7759 = load i64, ptr %rgep7758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7759, ptr %slot1353, align 8
  %v7760 = load i64, ptr %slot1353, align 8
  %op7761 = add i64 %v7760, 1
  store i64 %op7761, ptr %slot1354, align 8
  %v7762 = load i64, ptr %slot1354, align 8
  %cmp7763 = icmp eq i64 %v7762, 0
  %cv7764 = zext i1 %cmp7763 to i32
  store i32 %cv7764, ptr %slot1355, align 8
  %v7765 = load i32, ptr %slot1355, align 8
  %cv7766 = zext i32 %v7765 to i64
  %cond7767 = icmp ne i64 %cv7766, 0
  br i1 %cond7767, label %bb_rcglimit1739, label %bb_rcgcapacity1739
bb_rcglimit1739:
  %v7768 = load i64, ptr %slot1, align 8
  %p7769 = inttoptr i64 %v7768 to ptr
  %call7770 = call i32 @myl_qbe_rc_status(ptr %p7769, i32 2) nomerge, !dbg !158
  store i32 %call7770, ptr %slot1356, align 8
  br label %bb_failure
bb_rcgcapacity1739:
  %v7771 = load i64, ptr %slot1354, align 8
  %v7772 = load i64, ptr %slot1346, align 8
  %p7773 = inttoptr i64 %v7772 to ptr
  %rgep7774 = getelementptr i8, ptr %p7773, i64 -32
  store i64 %v7771, ptr %rgep7774, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1739
bb_rcgspecial1739:
  %v7775 = load i64, ptr %slot1349, align 8
  %op7776 = and i64 %v7775, 4611686018427387904
  store i64 %op7776, ptr %slot1357, align 8
  %v7777 = load i64, ptr %slot1357, align 8
  %cmp7778 = icmp ne i64 %v7777, 0
  %cv7779 = zext i1 %cmp7778 to i32
  store i32 %cv7779, ptr %slot1358, align 8
  %v7780 = load i32, ptr %slot1358, align 8
  %cv7781 = zext i32 %v7780 to i64
  %cond7782 = icmp ne i64 %cv7781, 0
  br i1 %cond7782, label %bb_rcgslow1739, label %bb_rcgplain1739
bb_rcgslow1739:
  %v7783 = load i64, ptr %slot31, align 8
  %v7784 = load i64, ptr %slot1344, align 8
  %v7785 = load i64, ptr %slot1343, align 8
  %v7786 = load i64, ptr %slot1345, align 8
  %cv7787 = trunc i64 %v7786 to i32
  %call7788 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v7783, i64 %v7784, i64 %v7785, i32 %cv7787) nomerge, !dbg !158
  store i32 %call7788, ptr %slot1359, align 8
  %v7789 = load i32, ptr %slot1359, align 8
  %cv7790 = zext i32 %v7789 to i64
  %cond7791 = icmp ne i64 %cv7790, 0
  br i1 %cond7791, label %bb_rcsuccess1753, label %bb_rcfailure1753
bb_rcfailure1753:
  %v7792 = load i64, ptr %slot31, align 8
  %p7793 = inttoptr i64 %v7792 to ptr
  %call7794 = call i32 @myl_rc_take_failure(ptr %p7793) nomerge, !dbg !158
  store i32 %call7794, ptr %slot1360, align 8
  %v7795 = load i64, ptr %slot1, align 8
  %p7796 = inttoptr i64 %v7795 to ptr
  %v7797 = load i32, ptr %slot1360, align 8
  %call7798 = call i32 @myl_qbe_rc_status(ptr %p7796, i32 %v7797) nomerge, !dbg !158
  store i32 %call7798, ptr %slot1361, align 8
  br label %bb_failure
bb_rcsuccess1753:
  br label %bb_rcgdone1739
bb_rcgplain1739:
  %v7799 = load i64, ptr %slot1346, align 8
  %v7800 = load i64, ptr %slot1344, align 8
  %p7801 = inttoptr i64 %v7800 to ptr
  store i64 %v7799, ptr %p7801, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1739
bb_rcgdone1739:
  %v7802 = load i64, ptr %slot14, align 8
  %p7803 = inttoptr i64 %v7802 to ptr
  store i32 2, ptr %p7803, align 4, !alias.scope !3, !noalias !4
  %v7804 = load i64, ptr %slot13, align 8
  %p7805 = inttoptr i64 %v7804 to ptr
  store i32 1, ptr %p7805, align 4, !alias.scope !3, !noalias !4
  %v7806 = load i64, ptr %slot5, align 8
  %p7807 = inttoptr i64 %v7806 to ptr
  %ld7808 = load i32, ptr %p7807, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7808, ptr %slot1362, align 8
  %v7809 = load i32, ptr %slot1362, align 8
  %cv7810 = zext i32 %v7809 to i64
  %cond7811 = icmp ne i64 %cv7810, 0
  br i1 %cond7811, label %bb_rcslotdrop1760, label %bb_rcslotdone1760
bb_rcslotdrop1760:
  %v7812 = load i64, ptr %slot5, align 8
  %p7813 = inttoptr i64 %v7812 to ptr
  store i32 0, ptr %p7813, align 4, !alias.scope !3, !noalias !4
  %v7814 = load i64, ptr %slot22, align 8
  store i64 %v7814, ptr %slot1363, align 8
  %v7815 = load i64, ptr %slot6, align 8
  %p7816 = inttoptr i64 %v7815 to ptr
  %ld7817 = load i32, ptr %p7816, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7817, ptr %slot1364, align 8
  %v7818 = load i32, ptr %slot1364, align 8
  %op7819 = and i32 %v7818, 28
  store i32 %op7819, ptr %slot1365, align 8
  %v7820 = load i32, ptr %slot1365, align 8
  %cv7821 = zext i32 %v7820 to i64
  %cond7822 = icmp ne i64 %cv7821, 0
  br i1 %cond7822, label %bb_rcslotrole1760, label %bb_rcslotowner1760
bb_rcslotrole1760:
  %v7823 = load i64, ptr %slot31, align 8
  store i64 %v7823, ptr %slot1366, align 8
  %v7824 = load i64, ptr %slot1363, align 8
  %p7825 = inttoptr i64 %v7824 to ptr
  %ld7826 = load i64, ptr %p7825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7826, ptr %slot1367, align 8
  %v7827 = load i64, ptr %slot1367, align 8
  %cmp7828 = icmp ne i64 %v7827, 0
  %cv7829 = zext i1 %cmp7828 to i32
  store i32 %cv7829, ptr %slot1368, align 8
  %v7830 = load i32, ptr %slot1368, align 8
  %cv7831 = zext i32 %v7830 to i64
  %cond7832 = icmp ne i64 %cv7831, 0
  br i1 %cond7832, label %bb_rcgnn1776, label %bb_rcgdone1776
bb_rcgnn1776:
  %v7833 = load i64, ptr %slot1367, align 8
  %op7834 = sub i64 %v7833, 16
  store i64 %op7834, ptr %slot1369, align 8
  %v7835 = load i64, ptr %slot1367, align 8
  %p7836 = inttoptr i64 %v7835 to ptr
  %rgep7837 = getelementptr i8, ptr %p7836, i64 -16
  %ld7838 = load i64, ptr %rgep7837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7838, ptr %slot1370, align 8
  %v7839 = load i64, ptr %slot1370, align 8
  %op7840 = and i64 %v7839, 4611686018427387906
  store i64 %op7840, ptr %slot1371, align 8
  %v7841 = load i64, ptr %slot1371, align 8
  %cmp7842 = icmp ne i64 %v7841, 0
  %cv7843 = zext i1 %cmp7842 to i32
  store i32 %cv7843, ptr %slot1372, align 8
  %v7844 = load i32, ptr %slot1372, align 8
  %cv7845 = zext i32 %v7844 to i64
  %cond7846 = icmp ne i64 %cv7845, 0
  br i1 %cond7846, label %bb_rcgclear1776, label %bb_rcgcounted1776
bb_rcgcounted1776:
  %v7847 = load i64, ptr %slot1367, align 8
  %op7848 = sub i64 %v7847, 24
  store i64 %op7848, ptr %slot1373, align 8
  %v7849 = load i64, ptr %slot1367, align 8
  %p7850 = inttoptr i64 %v7849 to ptr
  %rgep7851 = getelementptr i8, ptr %p7850, i64 -24
  %ld7852 = load i64, ptr %rgep7851, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7852, ptr %slot1374, align 8
  %v7853 = load i64, ptr %slot1374, align 8
  %op7854 = sub i64 %v7853, 1
  store i64 %op7854, ptr %slot1375, align 8
  %v7855 = load i64, ptr %slot1375, align 8
  %cmp7856 = icmp eq i64 %v7855, 0
  %cv7857 = zext i1 %cmp7856 to i32
  store i32 %cv7857, ptr %slot1376, align 8
  %v7858 = load i32, ptr %slot1376, align 8
  %cv7859 = zext i32 %v7858 to i64
  %cond7860 = icmp ne i64 %cv7859, 0
  br i1 %cond7860, label %bb_rcglast1776, label %bb_rcgdec1776
bb_rcglast1776:
  %v7861 = load i64, ptr %slot1367, align 8
  %op7862 = sub i64 %v7861, 32
  store i64 %op7862, ptr %slot1377, align 8
  %v7863 = load i64, ptr %slot1367, align 8
  %p7864 = inttoptr i64 %v7863 to ptr
  %rgep7865 = getelementptr i8, ptr %p7864, i64 -32
  %ld7866 = load i64, ptr %rgep7865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7866, ptr %slot1378, align 8
  %v7867 = load i64, ptr %slot1378, align 8
  %cmp7868 = icmp ne i64 %v7867, 0
  %cv7869 = zext i1 %cmp7868 to i32
  store i32 %cv7869, ptr %slot1379, align 8
  %v7870 = load i32, ptr %slot1379, align 8
  %cv7871 = zext i32 %v7870 to i64
  %cond7872 = icmp ne i64 %cv7871, 0
  br i1 %cond7872, label %bb_rcgdec1776, label %bb_rcgslow1776
bb_rcgslow1776:
  %v7873 = load i64, ptr %slot1366, align 8
  %v7874 = load i64, ptr %slot1363, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v7873, i64 %v7874) nomerge, !dbg !158
  br label %bb_rcgdone1776
bb_rcgdec1776:
  %v7875 = load i64, ptr %slot1375, align 8
  %v7876 = load i64, ptr %slot1367, align 8
  %p7877 = inttoptr i64 %v7876 to ptr
  %rgep7878 = getelementptr i8, ptr %p7877, i64 -24
  store i64 %v7875, ptr %rgep7878, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1776
bb_rcgclear1776:
  %v7879 = load i64, ptr %slot1363, align 8
  %p7880 = inttoptr i64 %v7879 to ptr
  store i64 0, ptr %p7880, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1776
bb_rcgdone1776:
  br label %bb_rcslotdone1760
bb_rcslotowner1760:
  %v7881 = load i64, ptr %slot31, align 8
  store i64 %v7881, ptr %slot1380, align 8
  %v7882 = load i64, ptr %slot1363, align 8
  %p7883 = inttoptr i64 %v7882 to ptr
  %ld7884 = load i64, ptr %p7883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7884, ptr %slot1381, align 8
  %v7885 = load i64, ptr %slot1381, align 8
  %cmp7886 = icmp ne i64 %v7885, 0
  %cv7887 = zext i1 %cmp7886 to i32
  store i32 %cv7887, ptr %slot1382, align 8
  %v7888 = load i32, ptr %slot1382, align 8
  %cv7889 = zext i32 %v7888 to i64
  %cond7890 = icmp ne i64 %cv7889, 0
  br i1 %cond7890, label %bb_rcgnn1791, label %bb_rcgdone1791
bb_rcgnn1791:
  %v7891 = load i64, ptr %slot1381, align 8
  %op7892 = sub i64 %v7891, 16
  store i64 %op7892, ptr %slot1383, align 8
  %v7893 = load i64, ptr %slot1381, align 8
  %p7894 = inttoptr i64 %v7893 to ptr
  %rgep7895 = getelementptr i8, ptr %p7894, i64 -16
  %ld7896 = load i64, ptr %rgep7895, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7896, ptr %slot1384, align 8
  %v7897 = load i64, ptr %slot1384, align 8
  %op7898 = and i64 %v7897, 4611686018427387906
  store i64 %op7898, ptr %slot1385, align 8
  %v7899 = load i64, ptr %slot1385, align 8
  %cmp7900 = icmp ne i64 %v7899, 0
  %cv7901 = zext i1 %cmp7900 to i32
  store i32 %cv7901, ptr %slot1386, align 8
  %v7902 = load i32, ptr %slot1386, align 8
  %cv7903 = zext i32 %v7902 to i64
  %cond7904 = icmp ne i64 %cv7903, 0
  br i1 %cond7904, label %bb_rcgclear1791, label %bb_rcgcounted1791
bb_rcgcounted1791:
  %v7905 = load i64, ptr %slot1381, align 8
  %op7906 = sub i64 %v7905, 32
  store i64 %op7906, ptr %slot1387, align 8
  %v7907 = load i64, ptr %slot1381, align 8
  %p7908 = inttoptr i64 %v7907 to ptr
  %rgep7909 = getelementptr i8, ptr %p7908, i64 -32
  %ld7910 = load i64, ptr %rgep7909, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7910, ptr %slot1388, align 8
  %v7911 = load i64, ptr %slot1388, align 8
  %op7912 = sub i64 %v7911, 1
  store i64 %op7912, ptr %slot1389, align 8
  %v7913 = load i64, ptr %slot1389, align 8
  %cmp7914 = icmp eq i64 %v7913, 0
  %cv7915 = zext i1 %cmp7914 to i32
  store i32 %cv7915, ptr %slot1390, align 8
  %v7916 = load i32, ptr %slot1390, align 8
  %cv7917 = zext i32 %v7916 to i64
  %cond7918 = icmp ne i64 %cv7917, 0
  br i1 %cond7918, label %bb_rcglast1791, label %bb_rcgdec1791
bb_rcglast1791:
  %v7919 = load i64, ptr %slot1381, align 8
  %op7920 = sub i64 %v7919, 24
  store i64 %op7920, ptr %slot1391, align 8
  %v7921 = load i64, ptr %slot1381, align 8
  %p7922 = inttoptr i64 %v7921 to ptr
  %rgep7923 = getelementptr i8, ptr %p7922, i64 -24
  %ld7924 = load i64, ptr %rgep7923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7924, ptr %slot1392, align 8
  %v7925 = load i64, ptr %slot1392, align 8
  %cmp7926 = icmp ne i64 %v7925, 0
  %cv7927 = zext i1 %cmp7926 to i32
  store i32 %cv7927, ptr %slot1393, align 8
  %v7928 = load i32, ptr %slot1393, align 8
  %cv7929 = zext i32 %v7928 to i64
  %cond7930 = icmp ne i64 %cv7929, 0
  br i1 %cond7930, label %bb_rcgdec1791, label %bb_rcgslow1791
bb_rcgslow1791:
  %v7931 = load i64, ptr %slot1380, align 8
  %v7932 = load i64, ptr %slot1363, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v7931, i64 %v7932) nomerge, !dbg !158
  br label %bb_rcgdone1791
bb_rcgdec1791:
  %v7933 = load i64, ptr %slot1389, align 8
  %v7934 = load i64, ptr %slot1381, align 8
  %p7935 = inttoptr i64 %v7934 to ptr
  %rgep7936 = getelementptr i8, ptr %p7935, i64 -32
  store i64 %v7933, ptr %rgep7936, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1791
bb_rcgclear1791:
  %v7937 = load i64, ptr %slot1363, align 8
  %p7938 = inttoptr i64 %v7937 to ptr
  store i64 0, ptr %p7938, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1791
bb_rcgdone1791:
  br label %bb_rcslotdone1760
bb_rcslotdone1760:
  %v7939 = load i64, ptr %slot17, align 8
  store i64 %v7939, ptr %slot1394, align 8
  %v7940 = load i64, ptr %slot1394, align 8
  %v7941 = load i64, ptr %slot1343, align 8
  %p7942 = inttoptr i64 %v7940 to ptr
  %p7943 = inttoptr i64 %v7941 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7943, ptr %p7942, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7944 = load i64, ptr %slot6, align 8
  %p7945 = inttoptr i64 %v7944 to ptr
  store i32 2, ptr %p7945, align 4, !alias.scope !3, !noalias !4
  %v7946 = load i64, ptr %slot5, align 8
  %p7947 = inttoptr i64 %v7946 to ptr
  store i32 1, ptr %p7947, align 4, !alias.scope !3, !noalias !4
  %v7948 = load i64, ptr %slot13, align 8
  %p7949 = inttoptr i64 %v7948 to ptr
  store i32 0, ptr %p7949, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal1732
bb_rcownedlocal1732:
  %v7950 = load i64, ptr %slot6, align 8
  %p7951 = inttoptr i64 %v7950 to ptr
  store i32 2, ptr %p7951, align 4, !alias.scope !3, !noalias !4
  %v7952 = load i64, ptr %slot1338, align 8
  %p7953 = inttoptr i64 %v7952 to ptr
  %ld7954 = load i64, ptr %p7953, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7954, ptr %slot1395, align 8
  %v7955 = load i64, ptr %slot1395, align 8
  %cmp7956 = icmp ne i64 %v7955, 0
  %cv7957 = zext i1 %cmp7956 to i32
  store i32 %cv7957, ptr %slot1396, align 8
  %v7958 = load i32, ptr %slot1396, align 8
  %cv7959 = zext i32 %v7958 to i64
  %cond7960 = icmp ne i64 %cv7959, 0
  br i1 %cond7960, label %bb_rcguniquenn1800, label %bb_rcgunique1800
bb_rcguniquenn1800:
  %v7961 = load i64, ptr %slot1395, align 8
  %op7962 = sub i64 %v7961, 16
  store i64 %op7962, ptr %slot1397, align 8
  %v7963 = load i64, ptr %slot1395, align 8
  %p7964 = inttoptr i64 %v7963 to ptr
  %rgep7965 = getelementptr i8, ptr %p7964, i64 -16
  %ld7966 = load i64, ptr %rgep7965, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7966, ptr %slot1398, align 8
  %v7967 = load i64, ptr %slot1398, align 8
  %op7968 = and i64 %v7967, 6917529027641081858
  store i64 %op7968, ptr %slot1399, align 8
  %v7969 = load i64, ptr %slot1399, align 8
  %cmp7970 = icmp ne i64 %v7969, 0
  %cv7971 = zext i1 %cmp7970 to i32
  store i32 %cv7971, ptr %slot1400, align 8
  %v7972 = load i32, ptr %slot1400, align 8
  %cv7973 = zext i32 %v7972 to i64
  %cond7974 = icmp ne i64 %cv7973, 0
  br i1 %cond7974, label %bb_rcguniqueslow1800, label %bb_rcguniquecount1800
bb_rcguniquecount1800:
  %v7975 = load i64, ptr %slot1395, align 8
  %op7976 = sub i64 %v7975, 32
  store i64 %op7976, ptr %slot1401, align 8
  %v7977 = load i64, ptr %slot1395, align 8
  %p7978 = inttoptr i64 %v7977 to ptr
  %rgep7979 = getelementptr i8, ptr %p7978, i64 -32
  %ld7980 = load i64, ptr %rgep7979, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7980, ptr %slot1402, align 8
  %v7981 = load i64, ptr %slot1402, align 8
  %cmp7982 = icmp ult i64 %v7981, 2
  %cv7983 = zext i1 %cmp7982 to i32
  store i32 %cv7983, ptr %slot1403, align 8
  %v7984 = load i32, ptr %slot1403, align 8
  %cv7985 = zext i32 %v7984 to i64
  %cond7986 = icmp ne i64 %cv7985, 0
  br i1 %cond7986, label %bb_rcgunique1800, label %bb_rcguniqueslow1800
bb_rcguniqueslow1800:
  %v7987 = load i64, ptr %slot1, align 8
  %p7988 = inttoptr i64 %v7987 to ptr
  %p7989 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v7990 = load i64, ptr %slot1338, align 8
  %p7991 = inttoptr i64 %v7990 to ptr
  %v7992 = load i64, ptr %slot5, align 8
  %p7993 = inttoptr i64 %v7992 to ptr
  %call7994 = call i32 @myl_qbe_rc_unique_local(ptr %p7988, ptr %p7989, ptr %p7991, ptr %p7993) nomerge, !dbg !158
  store i32 %call7994, ptr %slot1404, align 8
  %v7995 = load i32, ptr %slot1404, align 8
  %cv7996 = zext i32 %v7995 to i64
  %cond7997 = icmp ne i64 %cv7996, 0
  br i1 %cond7997, label %bb_rcunique1811, label %bb_failure
bb_rcunique1811:
  br label %bb_rcgunique1800
bb_rcgunique1800:
  %v7998 = load i64, ptr %slot22, align 8
  %p7999 = inttoptr i64 %v7998 to ptr
  %ld8000 = load i64, ptr %p7999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8000, ptr %slot1405, align 8
  %v8001 = load i64, ptr %slot25, align 8
  store i64 %v8001, ptr %slot1406, align 8
  %v8002 = load i64, ptr %slot1406, align 8
  %p8003 = inttoptr i64 %v8002 to ptr
  %ld8004 = load i64, ptr %p8003, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8004, ptr %slot1407, align 8
  %v8005 = load i64, ptr %slot1407, align 8
  %v8006 = load i64, ptr %slot18, align 8
  %p8007 = inttoptr i64 %v8006 to ptr
  store i64 %v8005, ptr %p8007, align 8, !alias.scope !3, !noalias !4
  %v8008 = load i64, ptr %slot18, align 8
  store i64 %v8008, ptr %slot1408, align 8
  %v8009 = load i64, ptr %slot31, align 8
  %v8010 = load i64, ptr %slot1405, align 8
  %v8011 = load i64, ptr %slot1408, align 8
  %call8012 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v8009, i64 %v8010, i64 %v8011) nomerge, !dbg !158
  store i32 %call8012, ptr %slot1409, align 8
  %v8013 = load i32, ptr %slot1409, align 8
  %cv8014 = zext i32 %v8013 to i64
  %cond8015 = icmp ne i64 %cv8014, 0
  br i1 %cond8015, label %bb_success1817, label %bb_failed1817
bb_failed1817:
  %v8016 = load i64, ptr %slot1, align 8
  %p8017 = inttoptr i64 %v8016 to ptr
  call void @myl_qbe_fail_allocation(ptr %p8017) nomerge, !dbg !158
  unreachable
bb_success1817:
  %v8018 = load i64, ptr %slot25, align 8
  %p8019 = inttoptr i64 %v8018 to ptr
  store i64 0, ptr %p8019, align 8, !alias.scope !3, !noalias !4
  %v8020 = load i64, ptr %slot11, align 8
  %p8021 = inttoptr i64 %v8020 to ptr
  %ld8022 = load i32, ptr %p8021, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8022, ptr %slot1410, align 8
  %v8023 = load i32, ptr %slot1410, align 8
  %cv8024 = zext i32 %v8023 to i64
  %cond8025 = icmp ne i64 %cv8024, 0
  br i1 %cond8025, label %bb_rcslotdrop1820, label %bb_rcslotdone1820
bb_rcslotdrop1820:
  %v8026 = load i64, ptr %slot11, align 8
  %p8027 = inttoptr i64 %v8026 to ptr
  store i32 0, ptr %p8027, align 4, !alias.scope !3, !noalias !4
  %v8028 = load i64, ptr %slot15, align 8
  store i64 %v8028, ptr %slot1411, align 8
  %v8029 = load i64, ptr %slot12, align 8
  %p8030 = inttoptr i64 %v8029 to ptr
  %ld8031 = load i32, ptr %p8030, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8031, ptr %slot1412, align 8
  %v8032 = load i32, ptr %slot1412, align 8
  %op8033 = and i32 %v8032, 28
  store i32 %op8033, ptr %slot1413, align 8
  %v8034 = load i32, ptr %slot1413, align 8
  %cv8035 = zext i32 %v8034 to i64
  %cond8036 = icmp ne i64 %cv8035, 0
  br i1 %cond8036, label %bb_rcslotrole1820, label %bb_rcslotowner1820
bb_rcslotrole1820:
  %v8037 = load i64, ptr %slot31, align 8
  store i64 %v8037, ptr %slot1414, align 8
  %v8038 = load i64, ptr %slot1411, align 8
  %p8039 = inttoptr i64 %v8038 to ptr
  %ld8040 = load i64, ptr %p8039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8040, ptr %slot1415, align 8
  %v8041 = load i64, ptr %slot1415, align 8
  %cmp8042 = icmp ne i64 %v8041, 0
  %cv8043 = zext i1 %cmp8042 to i32
  store i32 %cv8043, ptr %slot1416, align 8
  %v8044 = load i32, ptr %slot1416, align 8
  %cv8045 = zext i32 %v8044 to i64
  %cond8046 = icmp ne i64 %cv8045, 0
  br i1 %cond8046, label %bb_rcgnn1836, label %bb_rcgdone1836
bb_rcgnn1836:
  %v8047 = load i64, ptr %slot1415, align 8
  %op8048 = sub i64 %v8047, 16
  store i64 %op8048, ptr %slot1417, align 8
  %v8049 = load i64, ptr %slot1415, align 8
  %p8050 = inttoptr i64 %v8049 to ptr
  %rgep8051 = getelementptr i8, ptr %p8050, i64 -16
  %ld8052 = load i64, ptr %rgep8051, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8052, ptr %slot1418, align 8
  %v8053 = load i64, ptr %slot1418, align 8
  %op8054 = and i64 %v8053, 4611686018427387906
  store i64 %op8054, ptr %slot1419, align 8
  %v8055 = load i64, ptr %slot1419, align 8
  %cmp8056 = icmp ne i64 %v8055, 0
  %cv8057 = zext i1 %cmp8056 to i32
  store i32 %cv8057, ptr %slot1420, align 8
  %v8058 = load i32, ptr %slot1420, align 8
  %cv8059 = zext i32 %v8058 to i64
  %cond8060 = icmp ne i64 %cv8059, 0
  br i1 %cond8060, label %bb_rcgclear1836, label %bb_rcgcounted1836
bb_rcgcounted1836:
  %v8061 = load i64, ptr %slot1415, align 8
  %op8062 = sub i64 %v8061, 24
  store i64 %op8062, ptr %slot1421, align 8
  %v8063 = load i64, ptr %slot1415, align 8
  %p8064 = inttoptr i64 %v8063 to ptr
  %rgep8065 = getelementptr i8, ptr %p8064, i64 -24
  %ld8066 = load i64, ptr %rgep8065, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8066, ptr %slot1422, align 8
  %v8067 = load i64, ptr %slot1422, align 8
  %op8068 = sub i64 %v8067, 1
  store i64 %op8068, ptr %slot1423, align 8
  %v8069 = load i64, ptr %slot1423, align 8
  %cmp8070 = icmp eq i64 %v8069, 0
  %cv8071 = zext i1 %cmp8070 to i32
  store i32 %cv8071, ptr %slot1424, align 8
  %v8072 = load i32, ptr %slot1424, align 8
  %cv8073 = zext i32 %v8072 to i64
  %cond8074 = icmp ne i64 %cv8073, 0
  br i1 %cond8074, label %bb_rcglast1836, label %bb_rcgdec1836
bb_rcglast1836:
  %v8075 = load i64, ptr %slot1415, align 8
  %op8076 = sub i64 %v8075, 32
  store i64 %op8076, ptr %slot1425, align 8
  %v8077 = load i64, ptr %slot1415, align 8
  %p8078 = inttoptr i64 %v8077 to ptr
  %rgep8079 = getelementptr i8, ptr %p8078, i64 -32
  %ld8080 = load i64, ptr %rgep8079, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8080, ptr %slot1426, align 8
  %v8081 = load i64, ptr %slot1426, align 8
  %cmp8082 = icmp ne i64 %v8081, 0
  %cv8083 = zext i1 %cmp8082 to i32
  store i32 %cv8083, ptr %slot1427, align 8
  %v8084 = load i32, ptr %slot1427, align 8
  %cv8085 = zext i32 %v8084 to i64
  %cond8086 = icmp ne i64 %cv8085, 0
  br i1 %cond8086, label %bb_rcgdec1836, label %bb_rcgslow1836
bb_rcgslow1836:
  %v8087 = load i64, ptr %slot1414, align 8
  %v8088 = load i64, ptr %slot1411, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v8087, i64 %v8088) nomerge, !dbg !158
  br label %bb_rcgdone1836
bb_rcgdec1836:
  %v8089 = load i64, ptr %slot1423, align 8
  %v8090 = load i64, ptr %slot1415, align 8
  %p8091 = inttoptr i64 %v8090 to ptr
  %rgep8092 = getelementptr i8, ptr %p8091, i64 -24
  store i64 %v8089, ptr %rgep8092, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1836
bb_rcgclear1836:
  %v8093 = load i64, ptr %slot1411, align 8
  %p8094 = inttoptr i64 %v8093 to ptr
  store i64 0, ptr %p8094, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1836
bb_rcgdone1836:
  br label %bb_rcslotdone1820
bb_rcslotowner1820:
  %v8095 = load i64, ptr %slot31, align 8
  store i64 %v8095, ptr %slot1428, align 8
  %v8096 = load i64, ptr %slot1411, align 8
  %p8097 = inttoptr i64 %v8096 to ptr
  %ld8098 = load i64, ptr %p8097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8098, ptr %slot1429, align 8
  %v8099 = load i64, ptr %slot1429, align 8
  %cmp8100 = icmp ne i64 %v8099, 0
  %cv8101 = zext i1 %cmp8100 to i32
  store i32 %cv8101, ptr %slot1430, align 8
  %v8102 = load i32, ptr %slot1430, align 8
  %cv8103 = zext i32 %v8102 to i64
  %cond8104 = icmp ne i64 %cv8103, 0
  br i1 %cond8104, label %bb_rcgnn1851, label %bb_rcgdone1851
bb_rcgnn1851:
  %v8105 = load i64, ptr %slot1429, align 8
  %op8106 = sub i64 %v8105, 16
  store i64 %op8106, ptr %slot1431, align 8
  %v8107 = load i64, ptr %slot1429, align 8
  %p8108 = inttoptr i64 %v8107 to ptr
  %rgep8109 = getelementptr i8, ptr %p8108, i64 -16
  %ld8110 = load i64, ptr %rgep8109, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8110, ptr %slot1432, align 8
  %v8111 = load i64, ptr %slot1432, align 8
  %op8112 = and i64 %v8111, 4611686018427387906
  store i64 %op8112, ptr %slot1433, align 8
  %v8113 = load i64, ptr %slot1433, align 8
  %cmp8114 = icmp ne i64 %v8113, 0
  %cv8115 = zext i1 %cmp8114 to i32
  store i32 %cv8115, ptr %slot1434, align 8
  %v8116 = load i32, ptr %slot1434, align 8
  %cv8117 = zext i32 %v8116 to i64
  %cond8118 = icmp ne i64 %cv8117, 0
  br i1 %cond8118, label %bb_rcgclear1851, label %bb_rcgcounted1851
bb_rcgcounted1851:
  %v8119 = load i64, ptr %slot1429, align 8
  %op8120 = sub i64 %v8119, 32
  store i64 %op8120, ptr %slot1435, align 8
  %v8121 = load i64, ptr %slot1429, align 8
  %p8122 = inttoptr i64 %v8121 to ptr
  %rgep8123 = getelementptr i8, ptr %p8122, i64 -32
  %ld8124 = load i64, ptr %rgep8123, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8124, ptr %slot1436, align 8
  %v8125 = load i64, ptr %slot1436, align 8
  %op8126 = sub i64 %v8125, 1
  store i64 %op8126, ptr %slot1437, align 8
  %v8127 = load i64, ptr %slot1437, align 8
  %cmp8128 = icmp eq i64 %v8127, 0
  %cv8129 = zext i1 %cmp8128 to i32
  store i32 %cv8129, ptr %slot1438, align 8
  %v8130 = load i32, ptr %slot1438, align 8
  %cv8131 = zext i32 %v8130 to i64
  %cond8132 = icmp ne i64 %cv8131, 0
  br i1 %cond8132, label %bb_rcglast1851, label %bb_rcgdec1851
bb_rcglast1851:
  %v8133 = load i64, ptr %slot1429, align 8
  %op8134 = sub i64 %v8133, 24
  store i64 %op8134, ptr %slot1439, align 8
  %v8135 = load i64, ptr %slot1429, align 8
  %p8136 = inttoptr i64 %v8135 to ptr
  %rgep8137 = getelementptr i8, ptr %p8136, i64 -24
  %ld8138 = load i64, ptr %rgep8137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8138, ptr %slot1440, align 8
  %v8139 = load i64, ptr %slot1440, align 8
  %cmp8140 = icmp ne i64 %v8139, 0
  %cv8141 = zext i1 %cmp8140 to i32
  store i32 %cv8141, ptr %slot1441, align 8
  %v8142 = load i32, ptr %slot1441, align 8
  %cv8143 = zext i32 %v8142 to i64
  %cond8144 = icmp ne i64 %cv8143, 0
  br i1 %cond8144, label %bb_rcgdec1851, label %bb_rcgslow1851
bb_rcgslow1851:
  %v8145 = load i64, ptr %slot1428, align 8
  %v8146 = load i64, ptr %slot1411, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v8145, i64 %v8146) nomerge, !dbg !158
  br label %bb_rcgdone1851
bb_rcgdec1851:
  %v8147 = load i64, ptr %slot1437, align 8
  %v8148 = load i64, ptr %slot1429, align 8
  %p8149 = inttoptr i64 %v8148 to ptr
  %rgep8150 = getelementptr i8, ptr %p8149, i64 -32
  store i64 %v8147, ptr %rgep8150, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1851
bb_rcgclear1851:
  %v8151 = load i64, ptr %slot1411, align 8
  %p8152 = inttoptr i64 %v8151 to ptr
  store i64 0, ptr %p8152, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1851
bb_rcgdone1851:
  br label %bb_rcslotdone1820
bb_rcslotdone1820:
  %v8153 = load i64, ptr %slot22, align 8
  %p8154 = inttoptr i64 %v8153 to ptr
  %ld8155 = load i64, ptr %p8154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8155, ptr %slot1442, align 8
  %v8156 = load i64, ptr %slot1442, align 8
  %v8157 = load i64, ptr %slot25, align 8
  %p8158 = inttoptr i64 %v8157 to ptr
  store i64 %v8156, ptr %p8158, align 8, !alias.scope !3, !noalias !4
  %v8159 = load i64, ptr %slot23, align 8
  %p8160 = inttoptr i64 %v8159 to ptr
  %ld8161 = load i64, ptr %p8160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8161, ptr %slot1443, align 8
  %v8162 = load i64, ptr %slot25, align 8
  %p8163 = inttoptr i64 %v8162 to ptr
  %ld8164 = load i64, ptr %p8163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8164, ptr %slot1444, align 8
  %v8165 = load i64, ptr %slot31, align 8
  %p8166 = inttoptr i64 %v8165 to ptr
  %v8167 = load i64, ptr %slot1443, align 8
  %p8168 = inttoptr i64 %v8167 to ptr
  %v8169 = load i64, ptr %slot1444, align 8
  %p8170 = inttoptr i64 %v8169 to ptr
  %call8171 = call ptr @myl_native_text_join(ptr %p8166, ptr %p8168, ptr %p8170) nomerge, !dbg !160
  %calladdr8172 = ptrtoint ptr %call8171 to i64
  store i64 %calladdr8172, ptr %slot1445, align 8
  %v8173 = load i64, ptr %slot1445, align 8
  %cond8174 = icmp ne i64 %v8173, 0
  br i1 %cond8174, label %bb_success1859, label %bb_failed1859
bb_failed1859:
  %v8175 = load i64, ptr %slot1, align 8
  %p8176 = inttoptr i64 %v8175 to ptr
  call void @myl_qbe_fail_allocation(ptr %p8176) nomerge, !dbg !160
  unreachable
bb_success1859:
  %v8177 = load i64, ptr %slot1445, align 8
  %v8178 = load i64, ptr %slot25, align 8
  %p8179 = inttoptr i64 %v8178 to ptr
  store i64 %v8177, ptr %p8179, align 8, !alias.scope !3, !noalias !4
  %v8180 = load i64, ptr %slot25, align 8
  %p8181 = inttoptr i64 %v8180 to ptr
  %ld8182 = load i64, ptr %p8181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8182, ptr %slot1446, align 8
  %v8183 = load i64, ptr %slot1446, align 8
  %v8184 = load i64, ptr %slot16, align 8
  %p8185 = inttoptr i64 %v8184 to ptr
  store i64 %v8183, ptr %p8185, align 8, !alias.scope !3, !noalias !4
  %v8186 = load i64, ptr %slot16, align 8
  store i64 %v8186, ptr %slot1447, align 8
  %v8187 = load i64, ptr %slot17, align 8
  store i64 %v8187, ptr %slot1448, align 8
  %v8188 = load i64, ptr %slot1447, align 8
  %v8189 = load i64, ptr %slot1448, align 8
  %p8190 = inttoptr i64 %v8188 to ptr
  %p8191 = inttoptr i64 %v8189 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8191, ptr %p8190, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8192 = load i64, ptr %slot14, align 8
  %p8193 = inttoptr i64 %v8192 to ptr
  store i32 2, ptr %p8193, align 4, !alias.scope !3, !noalias !4
  %v8194 = load i64, ptr %slot13, align 8
  %p8195 = inttoptr i64 %v8194 to ptr
  store i32 1, ptr %p8195, align 4, !alias.scope !3, !noalias !4
  %v8196 = load i64, ptr %slot11, align 8
  %p8197 = inttoptr i64 %v8196 to ptr
  %ld8198 = load i32, ptr %p8197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8198, ptr %slot1449, align 8
  %v8199 = load i32, ptr %slot1449, align 8
  %cv8200 = zext i32 %v8199 to i64
  %cond8201 = icmp ne i64 %cv8200, 0
  br i1 %cond8201, label %bb_rcslotdrop1867, label %bb_rcslotdone1867
bb_rcslotdrop1867:
  %v8202 = load i64, ptr %slot11, align 8
  %p8203 = inttoptr i64 %v8202 to ptr
  store i32 0, ptr %p8203, align 4, !alias.scope !3, !noalias !4
  %v8204 = load i64, ptr %slot15, align 8
  store i64 %v8204, ptr %slot1450, align 8
  %v8205 = load i64, ptr %slot12, align 8
  %p8206 = inttoptr i64 %v8205 to ptr
  %ld8207 = load i32, ptr %p8206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8207, ptr %slot1451, align 8
  %v8208 = load i32, ptr %slot1451, align 8
  %op8209 = and i32 %v8208, 28
  store i32 %op8209, ptr %slot1452, align 8
  %v8210 = load i32, ptr %slot1452, align 8
  %cv8211 = zext i32 %v8210 to i64
  %cond8212 = icmp ne i64 %cv8211, 0
  br i1 %cond8212, label %bb_rcslotrole1867, label %bb_rcslotowner1867
bb_rcslotrole1867:
  %v8213 = load i64, ptr %slot31, align 8
  store i64 %v8213, ptr %slot1453, align 8
  %v8214 = load i64, ptr %slot1450, align 8
  %p8215 = inttoptr i64 %v8214 to ptr
  %ld8216 = load i64, ptr %p8215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8216, ptr %slot1454, align 8
  %v8217 = load i64, ptr %slot1454, align 8
  %cmp8218 = icmp ne i64 %v8217, 0
  %cv8219 = zext i1 %cmp8218 to i32
  store i32 %cv8219, ptr %slot1455, align 8
  %v8220 = load i32, ptr %slot1455, align 8
  %cv8221 = zext i32 %v8220 to i64
  %cond8222 = icmp ne i64 %cv8221, 0
  br i1 %cond8222, label %bb_rcgnn1883, label %bb_rcgdone1883
bb_rcgnn1883:
  %v8223 = load i64, ptr %slot1454, align 8
  %op8224 = sub i64 %v8223, 16
  store i64 %op8224, ptr %slot1456, align 8
  %v8225 = load i64, ptr %slot1454, align 8
  %p8226 = inttoptr i64 %v8225 to ptr
  %rgep8227 = getelementptr i8, ptr %p8226, i64 -16
  %ld8228 = load i64, ptr %rgep8227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8228, ptr %slot1457, align 8
  %v8229 = load i64, ptr %slot1457, align 8
  %op8230 = and i64 %v8229, 4611686018427387906
  store i64 %op8230, ptr %slot1458, align 8
  %v8231 = load i64, ptr %slot1458, align 8
  %cmp8232 = icmp ne i64 %v8231, 0
  %cv8233 = zext i1 %cmp8232 to i32
  store i32 %cv8233, ptr %slot1459, align 8
  %v8234 = load i32, ptr %slot1459, align 8
  %cv8235 = zext i32 %v8234 to i64
  %cond8236 = icmp ne i64 %cv8235, 0
  br i1 %cond8236, label %bb_rcgclear1883, label %bb_rcgcounted1883
bb_rcgcounted1883:
  %v8237 = load i64, ptr %slot1454, align 8
  %op8238 = sub i64 %v8237, 24
  store i64 %op8238, ptr %slot1460, align 8
  %v8239 = load i64, ptr %slot1454, align 8
  %p8240 = inttoptr i64 %v8239 to ptr
  %rgep8241 = getelementptr i8, ptr %p8240, i64 -24
  %ld8242 = load i64, ptr %rgep8241, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8242, ptr %slot1461, align 8
  %v8243 = load i64, ptr %slot1461, align 8
  %op8244 = sub i64 %v8243, 1
  store i64 %op8244, ptr %slot1462, align 8
  %v8245 = load i64, ptr %slot1462, align 8
  %cmp8246 = icmp eq i64 %v8245, 0
  %cv8247 = zext i1 %cmp8246 to i32
  store i32 %cv8247, ptr %slot1463, align 8
  %v8248 = load i32, ptr %slot1463, align 8
  %cv8249 = zext i32 %v8248 to i64
  %cond8250 = icmp ne i64 %cv8249, 0
  br i1 %cond8250, label %bb_rcglast1883, label %bb_rcgdec1883
bb_rcglast1883:
  %v8251 = load i64, ptr %slot1454, align 8
  %op8252 = sub i64 %v8251, 32
  store i64 %op8252, ptr %slot1464, align 8
  %v8253 = load i64, ptr %slot1454, align 8
  %p8254 = inttoptr i64 %v8253 to ptr
  %rgep8255 = getelementptr i8, ptr %p8254, i64 -32
  %ld8256 = load i64, ptr %rgep8255, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8256, ptr %slot1465, align 8
  %v8257 = load i64, ptr %slot1465, align 8
  %cmp8258 = icmp ne i64 %v8257, 0
  %cv8259 = zext i1 %cmp8258 to i32
  store i32 %cv8259, ptr %slot1466, align 8
  %v8260 = load i32, ptr %slot1466, align 8
  %cv8261 = zext i32 %v8260 to i64
  %cond8262 = icmp ne i64 %cv8261, 0
  br i1 %cond8262, label %bb_rcgdec1883, label %bb_rcgslow1883
bb_rcgslow1883:
  %v8263 = load i64, ptr %slot1453, align 8
  %v8264 = load i64, ptr %slot1450, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v8263, i64 %v8264) nomerge, !dbg !160
  br label %bb_rcgdone1883
bb_rcgdec1883:
  %v8265 = load i64, ptr %slot1462, align 8
  %v8266 = load i64, ptr %slot1454, align 8
  %p8267 = inttoptr i64 %v8266 to ptr
  %rgep8268 = getelementptr i8, ptr %p8267, i64 -24
  store i64 %v8265, ptr %rgep8268, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1883
bb_rcgclear1883:
  %v8269 = load i64, ptr %slot1450, align 8
  %p8270 = inttoptr i64 %v8269 to ptr
  store i64 0, ptr %p8270, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1883
bb_rcgdone1883:
  br label %bb_rcslotdone1867
bb_rcslotowner1867:
  %v8271 = load i64, ptr %slot31, align 8
  store i64 %v8271, ptr %slot1467, align 8
  %v8272 = load i64, ptr %slot1450, align 8
  %p8273 = inttoptr i64 %v8272 to ptr
  %ld8274 = load i64, ptr %p8273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8274, ptr %slot1468, align 8
  %v8275 = load i64, ptr %slot1468, align 8
  %cmp8276 = icmp ne i64 %v8275, 0
  %cv8277 = zext i1 %cmp8276 to i32
  store i32 %cv8277, ptr %slot1469, align 8
  %v8278 = load i32, ptr %slot1469, align 8
  %cv8279 = zext i32 %v8278 to i64
  %cond8280 = icmp ne i64 %cv8279, 0
  br i1 %cond8280, label %bb_rcgnn1898, label %bb_rcgdone1898
bb_rcgnn1898:
  %v8281 = load i64, ptr %slot1468, align 8
  %op8282 = sub i64 %v8281, 16
  store i64 %op8282, ptr %slot1470, align 8
  %v8283 = load i64, ptr %slot1468, align 8
  %p8284 = inttoptr i64 %v8283 to ptr
  %rgep8285 = getelementptr i8, ptr %p8284, i64 -16
  %ld8286 = load i64, ptr %rgep8285, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8286, ptr %slot1471, align 8
  %v8287 = load i64, ptr %slot1471, align 8
  %op8288 = and i64 %v8287, 4611686018427387906
  store i64 %op8288, ptr %slot1472, align 8
  %v8289 = load i64, ptr %slot1472, align 8
  %cmp8290 = icmp ne i64 %v8289, 0
  %cv8291 = zext i1 %cmp8290 to i32
  store i32 %cv8291, ptr %slot1473, align 8
  %v8292 = load i32, ptr %slot1473, align 8
  %cv8293 = zext i32 %v8292 to i64
  %cond8294 = icmp ne i64 %cv8293, 0
  br i1 %cond8294, label %bb_rcgclear1898, label %bb_rcgcounted1898
bb_rcgcounted1898:
  %v8295 = load i64, ptr %slot1468, align 8
  %op8296 = sub i64 %v8295, 32
  store i64 %op8296, ptr %slot1474, align 8
  %v8297 = load i64, ptr %slot1468, align 8
  %p8298 = inttoptr i64 %v8297 to ptr
  %rgep8299 = getelementptr i8, ptr %p8298, i64 -32
  %ld8300 = load i64, ptr %rgep8299, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8300, ptr %slot1475, align 8
  %v8301 = load i64, ptr %slot1475, align 8
  %op8302 = sub i64 %v8301, 1
  store i64 %op8302, ptr %slot1476, align 8
  %v8303 = load i64, ptr %slot1476, align 8
  %cmp8304 = icmp eq i64 %v8303, 0
  %cv8305 = zext i1 %cmp8304 to i32
  store i32 %cv8305, ptr %slot1477, align 8
  %v8306 = load i32, ptr %slot1477, align 8
  %cv8307 = zext i32 %v8306 to i64
  %cond8308 = icmp ne i64 %cv8307, 0
  br i1 %cond8308, label %bb_rcglast1898, label %bb_rcgdec1898
bb_rcglast1898:
  %v8309 = load i64, ptr %slot1468, align 8
  %op8310 = sub i64 %v8309, 24
  store i64 %op8310, ptr %slot1478, align 8
  %v8311 = load i64, ptr %slot1468, align 8
  %p8312 = inttoptr i64 %v8311 to ptr
  %rgep8313 = getelementptr i8, ptr %p8312, i64 -24
  %ld8314 = load i64, ptr %rgep8313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8314, ptr %slot1479, align 8
  %v8315 = load i64, ptr %slot1479, align 8
  %cmp8316 = icmp ne i64 %v8315, 0
  %cv8317 = zext i1 %cmp8316 to i32
  store i32 %cv8317, ptr %slot1480, align 8
  %v8318 = load i32, ptr %slot1480, align 8
  %cv8319 = zext i32 %v8318 to i64
  %cond8320 = icmp ne i64 %cv8319, 0
  br i1 %cond8320, label %bb_rcgdec1898, label %bb_rcgslow1898
bb_rcgslow1898:
  %v8321 = load i64, ptr %slot1467, align 8
  %v8322 = load i64, ptr %slot1450, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v8321, i64 %v8322) nomerge, !dbg !160
  br label %bb_rcgdone1898
bb_rcgdec1898:
  %v8323 = load i64, ptr %slot1476, align 8
  %v8324 = load i64, ptr %slot1468, align 8
  %p8325 = inttoptr i64 %v8324 to ptr
  %rgep8326 = getelementptr i8, ptr %p8325, i64 -32
  store i64 %v8323, ptr %rgep8326, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1898
bb_rcgclear1898:
  %v8327 = load i64, ptr %slot1450, align 8
  %p8328 = inttoptr i64 %v8327 to ptr
  store i64 0, ptr %p8328, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1898
bb_rcgdone1898:
  br label %bb_rcslotdone1867
bb_rcslotdone1867:
  %v8329 = load i64, ptr %slot15, align 8
  store i64 %v8329, ptr %slot1481, align 8
  %v8330 = load i64, ptr %slot17, align 8
  store i64 %v8330, ptr %slot1482, align 8
  %v8331 = load i64, ptr %slot1482, align 8
  %v8332 = load i64, ptr %slot1481, align 8
  %p8333 = inttoptr i64 %v8331 to ptr
  %p8334 = inttoptr i64 %v8332 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8334, ptr %p8333, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8335 = load i64, ptr %slot12, align 8
  %p8336 = inttoptr i64 %v8335 to ptr
  store i32 2, ptr %p8336, align 4, !alias.scope !3, !noalias !4
  %v8337 = load i64, ptr %slot14, align 8
  %p8338 = inttoptr i64 %v8337 to ptr
  %ld8339 = load i32, ptr %p8338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8339, ptr %slot1483, align 8
  %v8340 = load i32, ptr %slot1483, align 8
  %v8341 = load i64, ptr %slot12, align 8
  %p8342 = inttoptr i64 %v8341 to ptr
  store i32 %v8340, ptr %p8342, align 4, !alias.scope !3, !noalias !4
  %v8343 = load i64, ptr %slot13, align 8
  %p8344 = inttoptr i64 %v8343 to ptr
  store i32 0, ptr %p8344, align 4, !alias.scope !3, !noalias !4
  %v8345 = load i64, ptr %slot11, align 8
  %p8346 = inttoptr i64 %v8345 to ptr
  store i32 1, ptr %p8346, align 4, !alias.scope !3, !noalias !4
  %v8347 = load i64, ptr %slot1481, align 8
  %p8348 = inttoptr i64 %v8347 to ptr
  %ld8349 = load i64, ptr %p8348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8349, ptr %slot1484, align 8
  %v8350 = load i64, ptr %slot1484, align 8
  %v8351 = load i64, ptr %slot25, align 8
  %p8352 = inttoptr i64 %v8351 to ptr
  store i64 %v8350, ptr %p8352, align 8, !alias.scope !3, !noalias !4
  %v8353 = load i64, ptr %slot25, align 8
  %p8354 = inttoptr i64 %v8353 to ptr
  %ld8355 = load i64, ptr %p8354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8355, ptr %slot1485, align 8
  %v8356 = load i64, ptr %slot1485, align 8
  %v8357 = load i64, ptr %slot16, align 8
  %p8358 = inttoptr i64 %v8357 to ptr
  store i64 %v8356, ptr %p8358, align 8, !alias.scope !3, !noalias !4
  %v8359 = load i64, ptr %slot16, align 8
  store i64 %v8359, ptr %slot1486, align 8
  %v8360 = load i64, ptr %slot11, align 8
  %p8361 = inttoptr i64 %v8360 to ptr
  %ld8362 = load i32, ptr %p8361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8362, ptr %slot1487, align 8
  %v8363 = load i64, ptr %slot12, align 8
  %p8364 = inttoptr i64 %v8363 to ptr
  %ld8365 = load i32, ptr %p8364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8365, ptr %slot1488, align 8
  %v8366 = load i32, ptr %slot1488, align 8
  %op8367 = and i32 %v8366, 24
  store i32 %op8367, ptr %slot1488, align 8
  %v8368 = load i32, ptr %slot1488, align 8
  %cmp8369 = icmp eq i32 %v8368, 0
  %cv8370 = zext i1 %cmp8369 to i32
  store i32 %cv8370, ptr %slot1489, align 8
  %v8371 = load i32, ptr %slot1487, align 8
  %v8372 = load i32, ptr %slot1489, align 8
  %op8373 = and i32 %v8371, %v8372
  store i32 %op8373, ptr %slot1490, align 8
  %v8374 = load i32, ptr %slot1490, align 8
  %cv8375 = zext i32 %v8374 to i64
  %cond8376 = icmp ne i64 %cv8375, 0
  br i1 %cond8376, label %bb_rcprivateown1919, label %bb_rcprivateloan1919
bb_rcprivateown1919:
  %v8377 = load i64, ptr %slot17, align 8
  store i64 %v8377, ptr %slot1491, align 8
  %v8378 = load i64, ptr %slot32, align 8
  store i64 %v8378, ptr %slot1492, align 8
  %v8379 = load i64, ptr %slot1486, align 8
  %v8380 = load i64, ptr %slot1491, align 8
  %op8381 = sub i64 %v8379, %v8380
  store i64 %op8381, ptr %slot1493, align 8
  %v8382 = load i64, ptr %slot1491, align 8
  %v8383 = load i64, ptr %slot1486, align 8
  %op8384 = sub i64 %v8382, %v8383
  store i64 %op8384, ptr %slot1494, align 8
  %v8385 = load i64, ptr %slot1493, align 8
  %cmp8386 = icmp ult i64 %v8385, 8
  %cv8387 = zext i1 %cmp8386 to i32
  store i32 %cv8387, ptr %slot1495, align 8
  %v8388 = load i64, ptr %slot1494, align 8
  %cmp8389 = icmp ult i64 %v8388, 8
  %cv8390 = zext i1 %cmp8389 to i32
  store i32 %cv8390, ptr %slot1496, align 8
  %v8391 = load i32, ptr %slot1495, align 8
  %v8392 = load i32, ptr %slot1496, align 8
  %op8393 = or i32 %v8391, %v8392
  store i32 %op8393, ptr %slot1497, align 8
  %v8394 = load i32, ptr %slot1497, align 8
  %cv8395 = zext i32 %v8394 to i64
  %cond8396 = icmp ne i64 %cv8395, 0
  br i1 %cond8396, label %bb_rcmoveslow1922, label %bb_rcmovecheck1922
bb_rcmovecheck1922:
  %v8397 = load i64, ptr %slot1486, align 8
  %p8399 = inttoptr i64 %v8397 to ptr
  %gep8400 = getelementptr i8, ptr %p8399, i64 0
  %op8398 = ptrtoint ptr %gep8400 to i64
  store i64 %op8398, ptr %slot1498, align 8
  %v8401 = load i64, ptr %slot1498, align 8
  %p8402 = inttoptr i64 %v8401 to ptr
  %ld8403 = load i64, ptr %p8402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8403, ptr %slot1499, align 8
  %v8404 = load i64, ptr %slot1499, align 8
  %cmp8405 = icmp ne i64 %v8404, 0
  %cv8406 = zext i1 %cmp8405 to i32
  store i32 %cv8406, ptr %slot1500, align 8
  %v8407 = load i32, ptr %slot1500, align 8
  %cv8408 = zext i32 %v8407 to i64
  %cond8409 = icmp ne i64 %cv8408, 0
  br i1 %cond8409, label %bb_rcmoveheader1930, label %bb_rcmovenext1930
bb_rcmoveheader1930:
  %v8410 = load i64, ptr %slot1499, align 8
  %op8411 = sub i64 %v8410, 16
  store i64 %op8411, ptr %slot1501, align 8
  %v8412 = load i64, ptr %slot1499, align 8
  %p8413 = inttoptr i64 %v8412 to ptr
  %rgep8414 = getelementptr i8, ptr %p8413, i64 -16
  %ld8415 = load i64, ptr %rgep8414, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8415, ptr %slot1502, align 8
  %v8416 = load i64, ptr %slot1502, align 8
  %op8417 = and i64 %v8416, 5764607523034234881
  store i64 %op8417, ptr %slot1503, align 8
  %v8418 = load i64, ptr %slot1503, align 8
  %cmp8419 = icmp ne i64 %v8418, 0
  %cv8420 = zext i1 %cmp8419 to i32
  store i32 %cv8420, ptr %slot1504, align 8
  %v8421 = load i32, ptr %slot1504, align 8
  %cv8422 = zext i32 %v8421 to i64
  %cond8423 = icmp ne i64 %cv8422, 0
  br i1 %cond8423, label %bb_rcmoveslow1922, label %bb_rcmovenext1930
bb_rcmovenext1930:
  %v8424 = load i64, ptr %slot1486, align 8
  %v8425 = load i64, ptr %slot1491, align 8
  %p8426 = inttoptr i64 %v8424 to ptr
  %p8427 = inttoptr i64 %v8425 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8427, ptr %p8426, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8428 = load i64, ptr %slot1486, align 8
  %p8429 = inttoptr i64 %v8428 to ptr
  store i64 0, ptr %p8429, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1922
bb_rcmoveslow1922:
  %v8430 = load i64, ptr %slot31, align 8
  %v8431 = load i64, ptr %slot1491, align 8
  %v8432 = load i64, ptr %slot1486, align 8
  %v8433 = load i64, ptr %slot1492, align 8
  %cv8434 = trunc i64 %v8433 to i32
  %call8435 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v8430, i64 %v8431, i64 %v8432, i32 %cv8434) nomerge, !dbg !162
  store i32 %call8435, ptr %slot1505, align 8
  %v8436 = load i32, ptr %slot1505, align 8
  %cv8437 = zext i32 %v8436 to i64
  %cond8438 = icmp ne i64 %cv8437, 0
  br i1 %cond8438, label %bb_rcsuccess1937, label %bb_rcfailure1937
bb_rcfailure1937:
  %v8439 = load i64, ptr %slot31, align 8
  %p8440 = inttoptr i64 %v8439 to ptr
  %call8441 = call i32 @myl_rc_take_failure(ptr %p8440) nomerge, !dbg !162
  store i32 %call8441, ptr %slot1506, align 8
  %v8442 = load i64, ptr %slot1, align 8
  %p8443 = inttoptr i64 %v8442 to ptr
  %v8444 = load i32, ptr %slot1506, align 8
  %call8445 = call i32 @myl_qbe_rc_status(ptr %p8443, i32 %v8444) nomerge, !dbg !162
  store i32 %call8445, ptr %slot1507, align 8
  br label %bb_failure
bb_rcsuccess1937:
  br label %bb_rcmoved1922
bb_rcmoved1922:
  %v8446 = load i64, ptr %slot11, align 8
  %p8447 = inttoptr i64 %v8446 to ptr
  store i32 0, ptr %p8447, align 4, !alias.scope !3, !noalias !4
  %v8448 = load i64, ptr %slot14, align 8
  %p8449 = inttoptr i64 %v8448 to ptr
  store i32 2, ptr %p8449, align 4, !alias.scope !3, !noalias !4
  %v8450 = load i64, ptr %slot13, align 8
  %p8451 = inttoptr i64 %v8450 to ptr
  store i32 1, ptr %p8451, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1919
bb_rcprivateloan1919:
  %v8452 = load i64, ptr %slot11, align 8
  %p8453 = inttoptr i64 %v8452 to ptr
  %ld8454 = load i32, ptr %p8453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8454, ptr %slot1508, align 8
  %v8455 = load i64, ptr %slot12, align 8
  %p8456 = inttoptr i64 %v8455 to ptr
  %ld8457 = load i32, ptr %p8456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8457, ptr %slot1509, align 8
  %v8458 = load i32, ptr %slot1509, align 8
  %cmp8459 = icmp eq i32 %v8458, 16
  %cv8460 = zext i1 %cmp8459 to i32
  store i32 %cv8460, ptr %slot1510, align 8
  %v8461 = load i32, ptr %slot1510, align 8
  %v8462 = load i32, ptr %slot1508, align 8
  %op8463 = and i32 %v8461, %v8462
  store i32 %op8463, ptr %slot1510, align 8
  %v8464 = load i32, ptr %slot1510, align 8
  %cv8465 = zext i32 %v8464 to i64
  %cond8466 = icmp ne i64 %cv8465, 0
  br i1 %cond8466, label %bb_rcprivatemove1919, label %bb_rcprivatenew1919
bb_rcprivatemove1919:
  %v8467 = load i64, ptr %slot17, align 8
  store i64 %v8467, ptr %slot1511, align 8
  %v8468 = load i64, ptr %slot1486, align 8
  %v8469 = load i64, ptr %slot1511, align 8
  %p8470 = inttoptr i64 %v8468 to ptr
  %p8471 = inttoptr i64 %v8469 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8471, ptr %p8470, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8472 = load i64, ptr %slot1486, align 8
  %p8473 = inttoptr i64 %v8472 to ptr
  store i64 0, ptr %p8473, align 8, !alias.scope !3, !noalias !4
  %v8474 = load i64, ptr %slot14, align 8
  %p8475 = inttoptr i64 %v8474 to ptr
  store i32 2, ptr %p8475, align 4, !alias.scope !3, !noalias !4
  %v8476 = load i64, ptr %slot14, align 8
  %p8477 = inttoptr i64 %v8476 to ptr
  store i32 16, ptr %p8477, align 4, !alias.scope !3, !noalias !4
  %v8478 = load i64, ptr %slot13, align 8
  %p8479 = inttoptr i64 %v8478 to ptr
  store i32 1, ptr %p8479, align 4, !alias.scope !3, !noalias !4
  %v8480 = load i64, ptr %slot11, align 8
  %p8481 = inttoptr i64 %v8480 to ptr
  store i32 0, ptr %p8481, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1919
bb_rcprivatenew1919:
  %v8482 = load i64, ptr %slot17, align 8
  store i64 %v8482, ptr %slot1512, align 8
  %v8483 = load i64, ptr %slot1486, align 8
  %p8484 = inttoptr i64 %v8483 to ptr
  %ld8485 = load i64, ptr %p8484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8485, ptr %slot1513, align 8
  %v8486 = load i64, ptr %slot1513, align 8
  %cmp8487 = icmp ne i64 %v8486, 0
  %cv8488 = zext i1 %cmp8487 to i32
  store i32 %cv8488, ptr %slot1514, align 8
  %v8489 = load i32, ptr %slot1514, align 8
  %cv8490 = zext i32 %v8489 to i64
  %cond8491 = icmp ne i64 %cv8490, 0
  br i1 %cond8491, label %bb_rcgnn1955, label %bb_rcgstore1955
bb_rcgnn1955:
  %v8492 = load i64, ptr %slot1513, align 8
  %op8493 = sub i64 %v8492, 16
  store i64 %op8493, ptr %slot1515, align 8
  %v8494 = load i64, ptr %slot1513, align 8
  %p8495 = inttoptr i64 %v8494 to ptr
  %rgep8496 = getelementptr i8, ptr %p8495, i64 -16
  %ld8497 = load i64, ptr %rgep8496, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8497, ptr %slot1516, align 8
  %v8498 = load i64, ptr %slot1516, align 8
  %op8499 = and i64 %v8498, 4611686018427387906
  store i64 %op8499, ptr %slot1517, align 8
  %v8500 = load i64, ptr %slot1517, align 8
  %cmp8501 = icmp ne i64 %v8500, 0
  %cv8502 = zext i1 %cmp8501 to i32
  store i32 %cv8502, ptr %slot1518, align 8
  %v8503 = load i32, ptr %slot1518, align 8
  %cv8504 = zext i32 %v8503 to i64
  %cond8505 = icmp ne i64 %cv8504, 0
  br i1 %cond8505, label %bb_rcgstore1955, label %bb_rcginc1955
bb_rcginc1955:
  %v8506 = load i64, ptr %slot1513, align 8
  %op8507 = sub i64 %v8506, 24
  store i64 %op8507, ptr %slot1519, align 8
  %v8508 = load i64, ptr %slot1513, align 8
  %p8509 = inttoptr i64 %v8508 to ptr
  %rgep8510 = getelementptr i8, ptr %p8509, i64 -24
  %ld8511 = load i64, ptr %rgep8510, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8511, ptr %slot1520, align 8
  %v8512 = load i64, ptr %slot1520, align 8
  %op8513 = add i64 %v8512, 1
  store i64 %op8513, ptr %slot1521, align 8
  %v8514 = load i64, ptr %slot1521, align 8
  %cmp8515 = icmp eq i64 %v8514, 0
  %cv8516 = zext i1 %cmp8515 to i32
  store i32 %cv8516, ptr %slot1522, align 8
  %v8517 = load i32, ptr %slot1522, align 8
  %cv8518 = zext i32 %v8517 to i64
  %cond8519 = icmp ne i64 %cv8518, 0
  br i1 %cond8519, label %bb_rcglimit1955, label %bb_rcgcapacity1955
bb_rcglimit1955:
  %v8520 = load i64, ptr %slot1, align 8
  %p8521 = inttoptr i64 %v8520 to ptr
  %call8522 = call i32 @myl_qbe_rc_status(ptr %p8521, i32 2) nomerge, !dbg !162
  store i32 %call8522, ptr %slot1523, align 8
  br label %bb_failure
bb_rcgcapacity1955:
  %v8523 = load i64, ptr %slot1521, align 8
  %v8524 = load i64, ptr %slot1513, align 8
  %p8525 = inttoptr i64 %v8524 to ptr
  %rgep8526 = getelementptr i8, ptr %p8525, i64 -24
  store i64 %v8523, ptr %rgep8526, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1955
bb_rcgstore1955:
  %v8527 = load i64, ptr %slot1513, align 8
  %v8528 = load i64, ptr %slot1512, align 8
  %p8529 = inttoptr i64 %v8528 to ptr
  store i64 %v8527, ptr %p8529, align 8, !alias.scope !3, !noalias !4
  %v8530 = load i64, ptr %slot14, align 8
  %p8531 = inttoptr i64 %v8530 to ptr
  store i32 2, ptr %p8531, align 4, !alias.scope !3, !noalias !4
  %v8532 = load i64, ptr %slot14, align 8
  %p8533 = inttoptr i64 %v8532 to ptr
  store i32 16, ptr %p8533, align 4, !alias.scope !3, !noalias !4
  %v8534 = load i64, ptr %slot13, align 8
  %p8535 = inttoptr i64 %v8534 to ptr
  store i32 1, ptr %p8535, align 4, !alias.scope !3, !noalias !4
  %v8536 = load i64, ptr %slot11, align 8
  %p8537 = inttoptr i64 %v8536 to ptr
  %ld8538 = load i32, ptr %p8537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8538, ptr %slot1524, align 8
  %v8539 = load i32, ptr %slot1524, align 8
  %cv8540 = zext i32 %v8539 to i64
  %cond8541 = icmp ne i64 %cv8540, 0
  br i1 %cond8541, label %bb_rcslotdrop1971, label %bb_rcslotdone1971
bb_rcslotdrop1971:
  %v8542 = load i64, ptr %slot11, align 8
  %p8543 = inttoptr i64 %v8542 to ptr
  store i32 0, ptr %p8543, align 4, !alias.scope !3, !noalias !4
  %v8544 = load i64, ptr %slot15, align 8
  store i64 %v8544, ptr %slot1525, align 8
  %v8545 = load i64, ptr %slot12, align 8
  %p8546 = inttoptr i64 %v8545 to ptr
  %ld8547 = load i32, ptr %p8546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8547, ptr %slot1526, align 8
  %v8548 = load i32, ptr %slot1526, align 8
  %op8549 = and i32 %v8548, 28
  store i32 %op8549, ptr %slot1527, align 8
  %v8550 = load i32, ptr %slot1527, align 8
  %cv8551 = zext i32 %v8550 to i64
  %cond8552 = icmp ne i64 %cv8551, 0
  br i1 %cond8552, label %bb_rcslotrole1971, label %bb_rcslotowner1971
bb_rcslotrole1971:
  %v8553 = load i64, ptr %slot31, align 8
  store i64 %v8553, ptr %slot1528, align 8
  %v8554 = load i64, ptr %slot1525, align 8
  %p8555 = inttoptr i64 %v8554 to ptr
  %ld8556 = load i64, ptr %p8555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8556, ptr %slot1529, align 8
  %v8557 = load i64, ptr %slot1529, align 8
  %cmp8558 = icmp ne i64 %v8557, 0
  %cv8559 = zext i1 %cmp8558 to i32
  store i32 %cv8559, ptr %slot1530, align 8
  %v8560 = load i32, ptr %slot1530, align 8
  %cv8561 = zext i32 %v8560 to i64
  %cond8562 = icmp ne i64 %cv8561, 0
  br i1 %cond8562, label %bb_rcgnn1987, label %bb_rcgdone1987
bb_rcgnn1987:
  %v8563 = load i64, ptr %slot1529, align 8
  %op8564 = sub i64 %v8563, 16
  store i64 %op8564, ptr %slot1531, align 8
  %v8565 = load i64, ptr %slot1529, align 8
  %p8566 = inttoptr i64 %v8565 to ptr
  %rgep8567 = getelementptr i8, ptr %p8566, i64 -16
  %ld8568 = load i64, ptr %rgep8567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8568, ptr %slot1532, align 8
  %v8569 = load i64, ptr %slot1532, align 8
  %op8570 = and i64 %v8569, 4611686018427387906
  store i64 %op8570, ptr %slot1533, align 8
  %v8571 = load i64, ptr %slot1533, align 8
  %cmp8572 = icmp ne i64 %v8571, 0
  %cv8573 = zext i1 %cmp8572 to i32
  store i32 %cv8573, ptr %slot1534, align 8
  %v8574 = load i32, ptr %slot1534, align 8
  %cv8575 = zext i32 %v8574 to i64
  %cond8576 = icmp ne i64 %cv8575, 0
  br i1 %cond8576, label %bb_rcgclear1987, label %bb_rcgcounted1987
bb_rcgcounted1987:
  %v8577 = load i64, ptr %slot1529, align 8
  %op8578 = sub i64 %v8577, 24
  store i64 %op8578, ptr %slot1535, align 8
  %v8579 = load i64, ptr %slot1529, align 8
  %p8580 = inttoptr i64 %v8579 to ptr
  %rgep8581 = getelementptr i8, ptr %p8580, i64 -24
  %ld8582 = load i64, ptr %rgep8581, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8582, ptr %slot1536, align 8
  %v8583 = load i64, ptr %slot1536, align 8
  %op8584 = sub i64 %v8583, 1
  store i64 %op8584, ptr %slot1537, align 8
  %v8585 = load i64, ptr %slot1537, align 8
  %cmp8586 = icmp eq i64 %v8585, 0
  %cv8587 = zext i1 %cmp8586 to i32
  store i32 %cv8587, ptr %slot1538, align 8
  %v8588 = load i32, ptr %slot1538, align 8
  %cv8589 = zext i32 %v8588 to i64
  %cond8590 = icmp ne i64 %cv8589, 0
  br i1 %cond8590, label %bb_rcglast1987, label %bb_rcgdec1987
bb_rcglast1987:
  %v8591 = load i64, ptr %slot1529, align 8
  %op8592 = sub i64 %v8591, 32
  store i64 %op8592, ptr %slot1539, align 8
  %v8593 = load i64, ptr %slot1529, align 8
  %p8594 = inttoptr i64 %v8593 to ptr
  %rgep8595 = getelementptr i8, ptr %p8594, i64 -32
  %ld8596 = load i64, ptr %rgep8595, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8596, ptr %slot1540, align 8
  %v8597 = load i64, ptr %slot1540, align 8
  %cmp8598 = icmp ne i64 %v8597, 0
  %cv8599 = zext i1 %cmp8598 to i32
  store i32 %cv8599, ptr %slot1541, align 8
  %v8600 = load i32, ptr %slot1541, align 8
  %cv8601 = zext i32 %v8600 to i64
  %cond8602 = icmp ne i64 %cv8601, 0
  br i1 %cond8602, label %bb_rcgdec1987, label %bb_rcgslow1987
bb_rcgslow1987:
  %v8603 = load i64, ptr %slot1528, align 8
  %v8604 = load i64, ptr %slot1525, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v8603, i64 %v8604) nomerge, !dbg !162
  br label %bb_rcgdone1987
bb_rcgdec1987:
  %v8605 = load i64, ptr %slot1537, align 8
  %v8606 = load i64, ptr %slot1529, align 8
  %p8607 = inttoptr i64 %v8606 to ptr
  %rgep8608 = getelementptr i8, ptr %p8607, i64 -24
  store i64 %v8605, ptr %rgep8608, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1987
bb_rcgclear1987:
  %v8609 = load i64, ptr %slot1525, align 8
  %p8610 = inttoptr i64 %v8609 to ptr
  store i64 0, ptr %p8610, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1987
bb_rcgdone1987:
  br label %bb_rcslotdone1971
bb_rcslotowner1971:
  %v8611 = load i64, ptr %slot31, align 8
  store i64 %v8611, ptr %slot1542, align 8
  %v8612 = load i64, ptr %slot1525, align 8
  %p8613 = inttoptr i64 %v8612 to ptr
  %ld8614 = load i64, ptr %p8613, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8614, ptr %slot1543, align 8
  %v8615 = load i64, ptr %slot1543, align 8
  %cmp8616 = icmp ne i64 %v8615, 0
  %cv8617 = zext i1 %cmp8616 to i32
  store i32 %cv8617, ptr %slot1544, align 8
  %v8618 = load i32, ptr %slot1544, align 8
  %cv8619 = zext i32 %v8618 to i64
  %cond8620 = icmp ne i64 %cv8619, 0
  br i1 %cond8620, label %bb_rcgnn2002, label %bb_rcgdone2002
bb_rcgnn2002:
  %v8621 = load i64, ptr %slot1543, align 8
  %op8622 = sub i64 %v8621, 16
  store i64 %op8622, ptr %slot1545, align 8
  %v8623 = load i64, ptr %slot1543, align 8
  %p8624 = inttoptr i64 %v8623 to ptr
  %rgep8625 = getelementptr i8, ptr %p8624, i64 -16
  %ld8626 = load i64, ptr %rgep8625, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8626, ptr %slot1546, align 8
  %v8627 = load i64, ptr %slot1546, align 8
  %op8628 = and i64 %v8627, 4611686018427387906
  store i64 %op8628, ptr %slot1547, align 8
  %v8629 = load i64, ptr %slot1547, align 8
  %cmp8630 = icmp ne i64 %v8629, 0
  %cv8631 = zext i1 %cmp8630 to i32
  store i32 %cv8631, ptr %slot1548, align 8
  %v8632 = load i32, ptr %slot1548, align 8
  %cv8633 = zext i32 %v8632 to i64
  %cond8634 = icmp ne i64 %cv8633, 0
  br i1 %cond8634, label %bb_rcgclear2002, label %bb_rcgcounted2002
bb_rcgcounted2002:
  %v8635 = load i64, ptr %slot1543, align 8
  %op8636 = sub i64 %v8635, 32
  store i64 %op8636, ptr %slot1549, align 8
  %v8637 = load i64, ptr %slot1543, align 8
  %p8638 = inttoptr i64 %v8637 to ptr
  %rgep8639 = getelementptr i8, ptr %p8638, i64 -32
  %ld8640 = load i64, ptr %rgep8639, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8640, ptr %slot1550, align 8
  %v8641 = load i64, ptr %slot1550, align 8
  %op8642 = sub i64 %v8641, 1
  store i64 %op8642, ptr %slot1551, align 8
  %v8643 = load i64, ptr %slot1551, align 8
  %cmp8644 = icmp eq i64 %v8643, 0
  %cv8645 = zext i1 %cmp8644 to i32
  store i32 %cv8645, ptr %slot1552, align 8
  %v8646 = load i32, ptr %slot1552, align 8
  %cv8647 = zext i32 %v8646 to i64
  %cond8648 = icmp ne i64 %cv8647, 0
  br i1 %cond8648, label %bb_rcglast2002, label %bb_rcgdec2002
bb_rcglast2002:
  %v8649 = load i64, ptr %slot1543, align 8
  %op8650 = sub i64 %v8649, 24
  store i64 %op8650, ptr %slot1553, align 8
  %v8651 = load i64, ptr %slot1543, align 8
  %p8652 = inttoptr i64 %v8651 to ptr
  %rgep8653 = getelementptr i8, ptr %p8652, i64 -24
  %ld8654 = load i64, ptr %rgep8653, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8654, ptr %slot1554, align 8
  %v8655 = load i64, ptr %slot1554, align 8
  %cmp8656 = icmp ne i64 %v8655, 0
  %cv8657 = zext i1 %cmp8656 to i32
  store i32 %cv8657, ptr %slot1555, align 8
  %v8658 = load i32, ptr %slot1555, align 8
  %cv8659 = zext i32 %v8658 to i64
  %cond8660 = icmp ne i64 %cv8659, 0
  br i1 %cond8660, label %bb_rcgdec2002, label %bb_rcgslow2002
bb_rcgslow2002:
  %v8661 = load i64, ptr %slot1542, align 8
  %v8662 = load i64, ptr %slot1525, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v8661, i64 %v8662) nomerge, !dbg !162
  br label %bb_rcgdone2002
bb_rcgdec2002:
  %v8663 = load i64, ptr %slot1551, align 8
  %v8664 = load i64, ptr %slot1543, align 8
  %p8665 = inttoptr i64 %v8664 to ptr
  %rgep8666 = getelementptr i8, ptr %p8665, i64 -32
  store i64 %v8663, ptr %rgep8666, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2002
bb_rcgclear2002:
  %v8667 = load i64, ptr %slot1525, align 8
  %p8668 = inttoptr i64 %v8667 to ptr
  store i64 0, ptr %p8668, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2002
bb_rcgdone2002:
  br label %bb_rcslotdone1971
bb_rcslotdone1971:
  br label %bb_rcprivateprepared1919
bb_rcprivateprepared1919:
  %v8669 = load i64, ptr %slot9, align 8
  %p8670 = inttoptr i64 %v8669 to ptr
  %ld8671 = load i32, ptr %p8670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8671, ptr %slot1556, align 8
  %v8672 = load i32, ptr %slot1556, align 8
  %cv8673 = zext i32 %v8672 to i64
  %cond8674 = icmp ne i64 %cv8673, 0
  br i1 %cond8674, label %bb_rcslotdrop2009, label %bb_rcslotdone2009
bb_rcslotdrop2009:
  %v8675 = load i64, ptr %slot9, align 8
  %p8676 = inttoptr i64 %v8675 to ptr
  store i32 0, ptr %p8676, align 4, !alias.scope !3, !noalias !4
  %v8677 = load i64, ptr %slot24, align 8
  store i64 %v8677, ptr %slot1557, align 8
  %v8678 = load i64, ptr %slot10, align 8
  %p8679 = inttoptr i64 %v8678 to ptr
  %ld8680 = load i32, ptr %p8679, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8680, ptr %slot1558, align 8
  %v8681 = load i32, ptr %slot1558, align 8
  %op8682 = and i32 %v8681, 28
  store i32 %op8682, ptr %slot1559, align 8
  %v8683 = load i32, ptr %slot1559, align 8
  %cv8684 = zext i32 %v8683 to i64
  %cond8685 = icmp ne i64 %cv8684, 0
  br i1 %cond8685, label %bb_rcslotrole2009, label %bb_rcslotowner2009
bb_rcslotrole2009:
  %v8686 = load i64, ptr %slot31, align 8
  store i64 %v8686, ptr %slot1560, align 8
  %v8687 = load i64, ptr %slot1557, align 8
  %p8688 = inttoptr i64 %v8687 to ptr
  %ld8689 = load i64, ptr %p8688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8689, ptr %slot1561, align 8
  %v8690 = load i64, ptr %slot1561, align 8
  %cmp8691 = icmp ne i64 %v8690, 0
  %cv8692 = zext i1 %cmp8691 to i32
  store i32 %cv8692, ptr %slot1562, align 8
  %v8693 = load i32, ptr %slot1562, align 8
  %cv8694 = zext i32 %v8693 to i64
  %cond8695 = icmp ne i64 %cv8694, 0
  br i1 %cond8695, label %bb_rcgnn2025, label %bb_rcgdone2025
bb_rcgnn2025:
  %v8696 = load i64, ptr %slot1561, align 8
  %op8697 = sub i64 %v8696, 16
  store i64 %op8697, ptr %slot1563, align 8
  %v8698 = load i64, ptr %slot1561, align 8
  %p8699 = inttoptr i64 %v8698 to ptr
  %rgep8700 = getelementptr i8, ptr %p8699, i64 -16
  %ld8701 = load i64, ptr %rgep8700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8701, ptr %slot1564, align 8
  %v8702 = load i64, ptr %slot1564, align 8
  %op8703 = and i64 %v8702, 4611686018427387906
  store i64 %op8703, ptr %slot1565, align 8
  %v8704 = load i64, ptr %slot1565, align 8
  %cmp8705 = icmp ne i64 %v8704, 0
  %cv8706 = zext i1 %cmp8705 to i32
  store i32 %cv8706, ptr %slot1566, align 8
  %v8707 = load i32, ptr %slot1566, align 8
  %cv8708 = zext i32 %v8707 to i64
  %cond8709 = icmp ne i64 %cv8708, 0
  br i1 %cond8709, label %bb_rcgclear2025, label %bb_rcgcounted2025
bb_rcgcounted2025:
  %v8710 = load i64, ptr %slot1561, align 8
  %op8711 = sub i64 %v8710, 24
  store i64 %op8711, ptr %slot1567, align 8
  %v8712 = load i64, ptr %slot1561, align 8
  %p8713 = inttoptr i64 %v8712 to ptr
  %rgep8714 = getelementptr i8, ptr %p8713, i64 -24
  %ld8715 = load i64, ptr %rgep8714, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8715, ptr %slot1568, align 8
  %v8716 = load i64, ptr %slot1568, align 8
  %op8717 = sub i64 %v8716, 1
  store i64 %op8717, ptr %slot1569, align 8
  %v8718 = load i64, ptr %slot1569, align 8
  %cmp8719 = icmp eq i64 %v8718, 0
  %cv8720 = zext i1 %cmp8719 to i32
  store i32 %cv8720, ptr %slot1570, align 8
  %v8721 = load i32, ptr %slot1570, align 8
  %cv8722 = zext i32 %v8721 to i64
  %cond8723 = icmp ne i64 %cv8722, 0
  br i1 %cond8723, label %bb_rcglast2025, label %bb_rcgdec2025
bb_rcglast2025:
  %v8724 = load i64, ptr %slot1561, align 8
  %op8725 = sub i64 %v8724, 32
  store i64 %op8725, ptr %slot1571, align 8
  %v8726 = load i64, ptr %slot1561, align 8
  %p8727 = inttoptr i64 %v8726 to ptr
  %rgep8728 = getelementptr i8, ptr %p8727, i64 -32
  %ld8729 = load i64, ptr %rgep8728, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8729, ptr %slot1572, align 8
  %v8730 = load i64, ptr %slot1572, align 8
  %cmp8731 = icmp ne i64 %v8730, 0
  %cv8732 = zext i1 %cmp8731 to i32
  store i32 %cv8732, ptr %slot1573, align 8
  %v8733 = load i32, ptr %slot1573, align 8
  %cv8734 = zext i32 %v8733 to i64
  %cond8735 = icmp ne i64 %cv8734, 0
  br i1 %cond8735, label %bb_rcgdec2025, label %bb_rcgslow2025
bb_rcgslow2025:
  %v8736 = load i64, ptr %slot1560, align 8
  %v8737 = load i64, ptr %slot1557, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v8736, i64 %v8737) nomerge, !dbg !162
  br label %bb_rcgdone2025
bb_rcgdec2025:
  %v8738 = load i64, ptr %slot1569, align 8
  %v8739 = load i64, ptr %slot1561, align 8
  %p8740 = inttoptr i64 %v8739 to ptr
  %rgep8741 = getelementptr i8, ptr %p8740, i64 -24
  store i64 %v8738, ptr %rgep8741, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2025
bb_rcgclear2025:
  %v8742 = load i64, ptr %slot1557, align 8
  %p8743 = inttoptr i64 %v8742 to ptr
  store i64 0, ptr %p8743, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2025
bb_rcgdone2025:
  br label %bb_rcslotdone2009
bb_rcslotowner2009:
  %v8744 = load i64, ptr %slot31, align 8
  store i64 %v8744, ptr %slot1574, align 8
  %v8745 = load i64, ptr %slot1557, align 8
  %p8746 = inttoptr i64 %v8745 to ptr
  %ld8747 = load i64, ptr %p8746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8747, ptr %slot1575, align 8
  %v8748 = load i64, ptr %slot1575, align 8
  %cmp8749 = icmp ne i64 %v8748, 0
  %cv8750 = zext i1 %cmp8749 to i32
  store i32 %cv8750, ptr %slot1576, align 8
  %v8751 = load i32, ptr %slot1576, align 8
  %cv8752 = zext i32 %v8751 to i64
  %cond8753 = icmp ne i64 %cv8752, 0
  br i1 %cond8753, label %bb_rcgnn2040, label %bb_rcgdone2040
bb_rcgnn2040:
  %v8754 = load i64, ptr %slot1575, align 8
  %op8755 = sub i64 %v8754, 16
  store i64 %op8755, ptr %slot1577, align 8
  %v8756 = load i64, ptr %slot1575, align 8
  %p8757 = inttoptr i64 %v8756 to ptr
  %rgep8758 = getelementptr i8, ptr %p8757, i64 -16
  %ld8759 = load i64, ptr %rgep8758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8759, ptr %slot1578, align 8
  %v8760 = load i64, ptr %slot1578, align 8
  %op8761 = and i64 %v8760, 4611686018427387906
  store i64 %op8761, ptr %slot1579, align 8
  %v8762 = load i64, ptr %slot1579, align 8
  %cmp8763 = icmp ne i64 %v8762, 0
  %cv8764 = zext i1 %cmp8763 to i32
  store i32 %cv8764, ptr %slot1580, align 8
  %v8765 = load i32, ptr %slot1580, align 8
  %cv8766 = zext i32 %v8765 to i64
  %cond8767 = icmp ne i64 %cv8766, 0
  br i1 %cond8767, label %bb_rcgclear2040, label %bb_rcgcounted2040
bb_rcgcounted2040:
  %v8768 = load i64, ptr %slot1575, align 8
  %op8769 = sub i64 %v8768, 32
  store i64 %op8769, ptr %slot1581, align 8
  %v8770 = load i64, ptr %slot1575, align 8
  %p8771 = inttoptr i64 %v8770 to ptr
  %rgep8772 = getelementptr i8, ptr %p8771, i64 -32
  %ld8773 = load i64, ptr %rgep8772, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8773, ptr %slot1582, align 8
  %v8774 = load i64, ptr %slot1582, align 8
  %op8775 = sub i64 %v8774, 1
  store i64 %op8775, ptr %slot1583, align 8
  %v8776 = load i64, ptr %slot1583, align 8
  %cmp8777 = icmp eq i64 %v8776, 0
  %cv8778 = zext i1 %cmp8777 to i32
  store i32 %cv8778, ptr %slot1584, align 8
  %v8779 = load i32, ptr %slot1584, align 8
  %cv8780 = zext i32 %v8779 to i64
  %cond8781 = icmp ne i64 %cv8780, 0
  br i1 %cond8781, label %bb_rcglast2040, label %bb_rcgdec2040
bb_rcglast2040:
  %v8782 = load i64, ptr %slot1575, align 8
  %op8783 = sub i64 %v8782, 24
  store i64 %op8783, ptr %slot1585, align 8
  %v8784 = load i64, ptr %slot1575, align 8
  %p8785 = inttoptr i64 %v8784 to ptr
  %rgep8786 = getelementptr i8, ptr %p8785, i64 -24
  %ld8787 = load i64, ptr %rgep8786, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8787, ptr %slot1586, align 8
  %v8788 = load i64, ptr %slot1586, align 8
  %cmp8789 = icmp ne i64 %v8788, 0
  %cv8790 = zext i1 %cmp8789 to i32
  store i32 %cv8790, ptr %slot1587, align 8
  %v8791 = load i32, ptr %slot1587, align 8
  %cv8792 = zext i32 %v8791 to i64
  %cond8793 = icmp ne i64 %cv8792, 0
  br i1 %cond8793, label %bb_rcgdec2040, label %bb_rcgslow2040
bb_rcgslow2040:
  %v8794 = load i64, ptr %slot1574, align 8
  %v8795 = load i64, ptr %slot1557, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v8794, i64 %v8795) nomerge, !dbg !162
  br label %bb_rcgdone2040
bb_rcgdec2040:
  %v8796 = load i64, ptr %slot1583, align 8
  %v8797 = load i64, ptr %slot1575, align 8
  %p8798 = inttoptr i64 %v8797 to ptr
  %rgep8799 = getelementptr i8, ptr %p8798, i64 -32
  store i64 %v8796, ptr %rgep8799, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2040
bb_rcgclear2040:
  %v8800 = load i64, ptr %slot1557, align 8
  %p8801 = inttoptr i64 %v8800 to ptr
  store i64 0, ptr %p8801, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2040
bb_rcgdone2040:
  br label %bb_rcslotdone2009
bb_rcslotdone2009:
  %v8802 = load i64, ptr %slot24, align 8
  store i64 %v8802, ptr %slot1588, align 8
  %v8803 = load i64, ptr %slot17, align 8
  store i64 %v8803, ptr %slot1589, align 8
  %v8804 = load i64, ptr %slot1589, align 8
  %v8805 = load i64, ptr %slot1588, align 8
  %p8806 = inttoptr i64 %v8804 to ptr
  %p8807 = inttoptr i64 %v8805 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8807, ptr %p8806, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8808 = load i64, ptr %slot13, align 8
  %p8809 = inttoptr i64 %v8808 to ptr
  store i32 0, ptr %p8809, align 4, !alias.scope !3, !noalias !4
  %v8810 = load i64, ptr %slot10, align 8
  %p8811 = inttoptr i64 %v8810 to ptr
  store i32 2, ptr %p8811, align 4, !alias.scope !3, !noalias !4
  %v8812 = load i64, ptr %slot14, align 8
  %p8813 = inttoptr i64 %v8812 to ptr
  %ld8814 = load i32, ptr %p8813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8814, ptr %slot1590, align 8
  %v8815 = load i32, ptr %slot1590, align 8
  %v8816 = load i64, ptr %slot10, align 8
  %p8817 = inttoptr i64 %v8816 to ptr
  store i32 %v8815, ptr %p8817, align 4, !alias.scope !3, !noalias !4
  %v8818 = load i64, ptr %slot9, align 8
  %p8819 = inttoptr i64 %v8818 to ptr
  store i32 1, ptr %p8819, align 4, !alias.scope !3, !noalias !4
  %v8820 = load i64, ptr %slot5, align 8
  %p8821 = inttoptr i64 %v8820 to ptr
  %ld8822 = load i32, ptr %p8821, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8822, ptr %slot1591, align 8
  %v8823 = load i32, ptr %slot1591, align 8
  %cv8824 = zext i32 %v8823 to i64
  %cond8825 = icmp ne i64 %cv8824, 0
  br i1 %cond8825, label %bb_rcslotdrop2053, label %bb_rcslotdone2053
bb_rcslotdrop2053:
  %v8826 = load i64, ptr %slot5, align 8
  %p8827 = inttoptr i64 %v8826 to ptr
  store i32 0, ptr %p8827, align 4, !alias.scope !3, !noalias !4
  %v8828 = load i64, ptr %slot22, align 8
  store i64 %v8828, ptr %slot1592, align 8
  %v8829 = load i64, ptr %slot6, align 8
  %p8830 = inttoptr i64 %v8829 to ptr
  %ld8831 = load i32, ptr %p8830, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8831, ptr %slot1593, align 8
  %v8832 = load i32, ptr %slot1593, align 8
  %op8833 = and i32 %v8832, 28
  store i32 %op8833, ptr %slot1594, align 8
  %v8834 = load i32, ptr %slot1594, align 8
  %cv8835 = zext i32 %v8834 to i64
  %cond8836 = icmp ne i64 %cv8835, 0
  br i1 %cond8836, label %bb_rcslotrole2053, label %bb_rcslotowner2053
bb_rcslotrole2053:
  %v8837 = load i64, ptr %slot31, align 8
  store i64 %v8837, ptr %slot1595, align 8
  %v8838 = load i64, ptr %slot1592, align 8
  %p8839 = inttoptr i64 %v8838 to ptr
  %ld8840 = load i64, ptr %p8839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8840, ptr %slot1596, align 8
  %v8841 = load i64, ptr %slot1596, align 8
  %cmp8842 = icmp ne i64 %v8841, 0
  %cv8843 = zext i1 %cmp8842 to i32
  store i32 %cv8843, ptr %slot1597, align 8
  %v8844 = load i32, ptr %slot1597, align 8
  %cv8845 = zext i32 %v8844 to i64
  %cond8846 = icmp ne i64 %cv8845, 0
  br i1 %cond8846, label %bb_rcgnn2069, label %bb_rcgdone2069
bb_rcgnn2069:
  %v8847 = load i64, ptr %slot1596, align 8
  %op8848 = sub i64 %v8847, 16
  store i64 %op8848, ptr %slot1598, align 8
  %v8849 = load i64, ptr %slot1596, align 8
  %p8850 = inttoptr i64 %v8849 to ptr
  %rgep8851 = getelementptr i8, ptr %p8850, i64 -16
  %ld8852 = load i64, ptr %rgep8851, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8852, ptr %slot1599, align 8
  %v8853 = load i64, ptr %slot1599, align 8
  %op8854 = and i64 %v8853, 4611686018427387906
  store i64 %op8854, ptr %slot1600, align 8
  %v8855 = load i64, ptr %slot1600, align 8
  %cmp8856 = icmp ne i64 %v8855, 0
  %cv8857 = zext i1 %cmp8856 to i32
  store i32 %cv8857, ptr %slot1601, align 8
  %v8858 = load i32, ptr %slot1601, align 8
  %cv8859 = zext i32 %v8858 to i64
  %cond8860 = icmp ne i64 %cv8859, 0
  br i1 %cond8860, label %bb_rcgclear2069, label %bb_rcgcounted2069
bb_rcgcounted2069:
  %v8861 = load i64, ptr %slot1596, align 8
  %op8862 = sub i64 %v8861, 24
  store i64 %op8862, ptr %slot1602, align 8
  %v8863 = load i64, ptr %slot1596, align 8
  %p8864 = inttoptr i64 %v8863 to ptr
  %rgep8865 = getelementptr i8, ptr %p8864, i64 -24
  %ld8866 = load i64, ptr %rgep8865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8866, ptr %slot1603, align 8
  %v8867 = load i64, ptr %slot1603, align 8
  %op8868 = sub i64 %v8867, 1
  store i64 %op8868, ptr %slot1604, align 8
  %v8869 = load i64, ptr %slot1604, align 8
  %cmp8870 = icmp eq i64 %v8869, 0
  %cv8871 = zext i1 %cmp8870 to i32
  store i32 %cv8871, ptr %slot1605, align 8
  %v8872 = load i32, ptr %slot1605, align 8
  %cv8873 = zext i32 %v8872 to i64
  %cond8874 = icmp ne i64 %cv8873, 0
  br i1 %cond8874, label %bb_rcglast2069, label %bb_rcgdec2069
bb_rcglast2069:
  %v8875 = load i64, ptr %slot1596, align 8
  %op8876 = sub i64 %v8875, 32
  store i64 %op8876, ptr %slot1606, align 8
  %v8877 = load i64, ptr %slot1596, align 8
  %p8878 = inttoptr i64 %v8877 to ptr
  %rgep8879 = getelementptr i8, ptr %p8878, i64 -32
  %ld8880 = load i64, ptr %rgep8879, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8880, ptr %slot1607, align 8
  %v8881 = load i64, ptr %slot1607, align 8
  %cmp8882 = icmp ne i64 %v8881, 0
  %cv8883 = zext i1 %cmp8882 to i32
  store i32 %cv8883, ptr %slot1608, align 8
  %v8884 = load i32, ptr %slot1608, align 8
  %cv8885 = zext i32 %v8884 to i64
  %cond8886 = icmp ne i64 %cv8885, 0
  br i1 %cond8886, label %bb_rcgdec2069, label %bb_rcgslow2069
bb_rcgslow2069:
  %v8887 = load i64, ptr %slot1595, align 8
  %v8888 = load i64, ptr %slot1592, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v8887, i64 %v8888) nomerge, !dbg !162
  br label %bb_rcgdone2069
bb_rcgdec2069:
  %v8889 = load i64, ptr %slot1604, align 8
  %v8890 = load i64, ptr %slot1596, align 8
  %p8891 = inttoptr i64 %v8890 to ptr
  %rgep8892 = getelementptr i8, ptr %p8891, i64 -24
  store i64 %v8889, ptr %rgep8892, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2069
bb_rcgclear2069:
  %v8893 = load i64, ptr %slot1592, align 8
  %p8894 = inttoptr i64 %v8893 to ptr
  store i64 0, ptr %p8894, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2069
bb_rcgdone2069:
  br label %bb_rcslotdone2053
bb_rcslotowner2053:
  %v8895 = load i64, ptr %slot31, align 8
  store i64 %v8895, ptr %slot1609, align 8
  %v8896 = load i64, ptr %slot1592, align 8
  %p8897 = inttoptr i64 %v8896 to ptr
  %ld8898 = load i64, ptr %p8897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8898, ptr %slot1610, align 8
  %v8899 = load i64, ptr %slot1610, align 8
  %cmp8900 = icmp ne i64 %v8899, 0
  %cv8901 = zext i1 %cmp8900 to i32
  store i32 %cv8901, ptr %slot1611, align 8
  %v8902 = load i32, ptr %slot1611, align 8
  %cv8903 = zext i32 %v8902 to i64
  %cond8904 = icmp ne i64 %cv8903, 0
  br i1 %cond8904, label %bb_rcgnn2084, label %bb_rcgdone2084
bb_rcgnn2084:
  %v8905 = load i64, ptr %slot1610, align 8
  %op8906 = sub i64 %v8905, 16
  store i64 %op8906, ptr %slot1612, align 8
  %v8907 = load i64, ptr %slot1610, align 8
  %p8908 = inttoptr i64 %v8907 to ptr
  %rgep8909 = getelementptr i8, ptr %p8908, i64 -16
  %ld8910 = load i64, ptr %rgep8909, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8910, ptr %slot1613, align 8
  %v8911 = load i64, ptr %slot1613, align 8
  %op8912 = and i64 %v8911, 4611686018427387906
  store i64 %op8912, ptr %slot1614, align 8
  %v8913 = load i64, ptr %slot1614, align 8
  %cmp8914 = icmp ne i64 %v8913, 0
  %cv8915 = zext i1 %cmp8914 to i32
  store i32 %cv8915, ptr %slot1615, align 8
  %v8916 = load i32, ptr %slot1615, align 8
  %cv8917 = zext i32 %v8916 to i64
  %cond8918 = icmp ne i64 %cv8917, 0
  br i1 %cond8918, label %bb_rcgclear2084, label %bb_rcgcounted2084
bb_rcgcounted2084:
  %v8919 = load i64, ptr %slot1610, align 8
  %op8920 = sub i64 %v8919, 32
  store i64 %op8920, ptr %slot1616, align 8
  %v8921 = load i64, ptr %slot1610, align 8
  %p8922 = inttoptr i64 %v8921 to ptr
  %rgep8923 = getelementptr i8, ptr %p8922, i64 -32
  %ld8924 = load i64, ptr %rgep8923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8924, ptr %slot1617, align 8
  %v8925 = load i64, ptr %slot1617, align 8
  %op8926 = sub i64 %v8925, 1
  store i64 %op8926, ptr %slot1618, align 8
  %v8927 = load i64, ptr %slot1618, align 8
  %cmp8928 = icmp eq i64 %v8927, 0
  %cv8929 = zext i1 %cmp8928 to i32
  store i32 %cv8929, ptr %slot1619, align 8
  %v8930 = load i32, ptr %slot1619, align 8
  %cv8931 = zext i32 %v8930 to i64
  %cond8932 = icmp ne i64 %cv8931, 0
  br i1 %cond8932, label %bb_rcglast2084, label %bb_rcgdec2084
bb_rcglast2084:
  %v8933 = load i64, ptr %slot1610, align 8
  %op8934 = sub i64 %v8933, 24
  store i64 %op8934, ptr %slot1620, align 8
  %v8935 = load i64, ptr %slot1610, align 8
  %p8936 = inttoptr i64 %v8935 to ptr
  %rgep8937 = getelementptr i8, ptr %p8936, i64 -24
  %ld8938 = load i64, ptr %rgep8937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8938, ptr %slot1621, align 8
  %v8939 = load i64, ptr %slot1621, align 8
  %cmp8940 = icmp ne i64 %v8939, 0
  %cv8941 = zext i1 %cmp8940 to i32
  store i32 %cv8941, ptr %slot1622, align 8
  %v8942 = load i32, ptr %slot1622, align 8
  %cv8943 = zext i32 %v8942 to i64
  %cond8944 = icmp ne i64 %cv8943, 0
  br i1 %cond8944, label %bb_rcgdec2084, label %bb_rcgslow2084
bb_rcgslow2084:
  %v8945 = load i64, ptr %slot1609, align 8
  %v8946 = load i64, ptr %slot1592, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v8945, i64 %v8946) nomerge, !dbg !162
  br label %bb_rcgdone2084
bb_rcgdec2084:
  %v8947 = load i64, ptr %slot1618, align 8
  %v8948 = load i64, ptr %slot1610, align 8
  %p8949 = inttoptr i64 %v8948 to ptr
  %rgep8950 = getelementptr i8, ptr %p8949, i64 -32
  store i64 %v8947, ptr %rgep8950, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2084
bb_rcgclear2084:
  %v8951 = load i64, ptr %slot1592, align 8
  %p8952 = inttoptr i64 %v8951 to ptr
  store i64 0, ptr %p8952, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2084
bb_rcgdone2084:
  br label %bb_rcslotdone2053
bb_rcslotdone2053:
  %v8953 = load i64, ptr %slot7, align 8
  %p8954 = inttoptr i64 %v8953 to ptr
  %ld8955 = load i32, ptr %p8954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8955, ptr %slot1623, align 8
  %v8956 = load i32, ptr %slot1623, align 8
  %cv8957 = zext i32 %v8956 to i64
  %cond8958 = icmp ne i64 %cv8957, 0
  br i1 %cond8958, label %bb_rcslotdrop2090, label %bb_rcslotdone2090
bb_rcslotdrop2090:
  %v8959 = load i64, ptr %slot7, align 8
  %p8960 = inttoptr i64 %v8959 to ptr
  store i32 0, ptr %p8960, align 4, !alias.scope !3, !noalias !4
  %v8961 = load i64, ptr %slot23, align 8
  store i64 %v8961, ptr %slot1624, align 8
  %v8962 = load i64, ptr %slot8, align 8
  %p8963 = inttoptr i64 %v8962 to ptr
  %ld8964 = load i32, ptr %p8963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8964, ptr %slot1625, align 8
  %v8965 = load i32, ptr %slot1625, align 8
  %op8966 = and i32 %v8965, 28
  store i32 %op8966, ptr %slot1626, align 8
  %v8967 = load i32, ptr %slot1626, align 8
  %cv8968 = zext i32 %v8967 to i64
  %cond8969 = icmp ne i64 %cv8968, 0
  br i1 %cond8969, label %bb_rcslotrole2090, label %bb_rcslotowner2090
bb_rcslotrole2090:
  %v8970 = load i64, ptr %slot31, align 8
  store i64 %v8970, ptr %slot1627, align 8
  %v8971 = load i64, ptr %slot1624, align 8
  %p8972 = inttoptr i64 %v8971 to ptr
  %ld8973 = load i64, ptr %p8972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8973, ptr %slot1628, align 8
  %v8974 = load i64, ptr %slot1628, align 8
  %cmp8975 = icmp ne i64 %v8974, 0
  %cv8976 = zext i1 %cmp8975 to i32
  store i32 %cv8976, ptr %slot1629, align 8
  %v8977 = load i32, ptr %slot1629, align 8
  %cv8978 = zext i32 %v8977 to i64
  %cond8979 = icmp ne i64 %cv8978, 0
  br i1 %cond8979, label %bb_rcgnn2106, label %bb_rcgdone2106
bb_rcgnn2106:
  %v8980 = load i64, ptr %slot1628, align 8
  %op8981 = sub i64 %v8980, 16
  store i64 %op8981, ptr %slot1630, align 8
  %v8982 = load i64, ptr %slot1628, align 8
  %p8983 = inttoptr i64 %v8982 to ptr
  %rgep8984 = getelementptr i8, ptr %p8983, i64 -16
  %ld8985 = load i64, ptr %rgep8984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8985, ptr %slot1631, align 8
  %v8986 = load i64, ptr %slot1631, align 8
  %op8987 = and i64 %v8986, 4611686018427387906
  store i64 %op8987, ptr %slot1632, align 8
  %v8988 = load i64, ptr %slot1632, align 8
  %cmp8989 = icmp ne i64 %v8988, 0
  %cv8990 = zext i1 %cmp8989 to i32
  store i32 %cv8990, ptr %slot1633, align 8
  %v8991 = load i32, ptr %slot1633, align 8
  %cv8992 = zext i32 %v8991 to i64
  %cond8993 = icmp ne i64 %cv8992, 0
  br i1 %cond8993, label %bb_rcgclear2106, label %bb_rcgcounted2106
bb_rcgcounted2106:
  %v8994 = load i64, ptr %slot1628, align 8
  %op8995 = sub i64 %v8994, 24
  store i64 %op8995, ptr %slot1634, align 8
  %v8996 = load i64, ptr %slot1628, align 8
  %p8997 = inttoptr i64 %v8996 to ptr
  %rgep8998 = getelementptr i8, ptr %p8997, i64 -24
  %ld8999 = load i64, ptr %rgep8998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8999, ptr %slot1635, align 8
  %v9000 = load i64, ptr %slot1635, align 8
  %op9001 = sub i64 %v9000, 1
  store i64 %op9001, ptr %slot1636, align 8
  %v9002 = load i64, ptr %slot1636, align 8
  %cmp9003 = icmp eq i64 %v9002, 0
  %cv9004 = zext i1 %cmp9003 to i32
  store i32 %cv9004, ptr %slot1637, align 8
  %v9005 = load i32, ptr %slot1637, align 8
  %cv9006 = zext i32 %v9005 to i64
  %cond9007 = icmp ne i64 %cv9006, 0
  br i1 %cond9007, label %bb_rcglast2106, label %bb_rcgdec2106
bb_rcglast2106:
  %v9008 = load i64, ptr %slot1628, align 8
  %op9009 = sub i64 %v9008, 32
  store i64 %op9009, ptr %slot1638, align 8
  %v9010 = load i64, ptr %slot1628, align 8
  %p9011 = inttoptr i64 %v9010 to ptr
  %rgep9012 = getelementptr i8, ptr %p9011, i64 -32
  %ld9013 = load i64, ptr %rgep9012, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9013, ptr %slot1639, align 8
  %v9014 = load i64, ptr %slot1639, align 8
  %cmp9015 = icmp ne i64 %v9014, 0
  %cv9016 = zext i1 %cmp9015 to i32
  store i32 %cv9016, ptr %slot1640, align 8
  %v9017 = load i32, ptr %slot1640, align 8
  %cv9018 = zext i32 %v9017 to i64
  %cond9019 = icmp ne i64 %cv9018, 0
  br i1 %cond9019, label %bb_rcgdec2106, label %bb_rcgslow2106
bb_rcgslow2106:
  %v9020 = load i64, ptr %slot1627, align 8
  %v9021 = load i64, ptr %slot1624, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v9020, i64 %v9021) nomerge, !dbg !162
  br label %bb_rcgdone2106
bb_rcgdec2106:
  %v9022 = load i64, ptr %slot1636, align 8
  %v9023 = load i64, ptr %slot1628, align 8
  %p9024 = inttoptr i64 %v9023 to ptr
  %rgep9025 = getelementptr i8, ptr %p9024, i64 -24
  store i64 %v9022, ptr %rgep9025, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2106
bb_rcgclear2106:
  %v9026 = load i64, ptr %slot1624, align 8
  %p9027 = inttoptr i64 %v9026 to ptr
  store i64 0, ptr %p9027, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2106
bb_rcgdone2106:
  br label %bb_rcslotdone2090
bb_rcslotowner2090:
  %v9028 = load i64, ptr %slot31, align 8
  store i64 %v9028, ptr %slot1641, align 8
  %v9029 = load i64, ptr %slot1624, align 8
  %p9030 = inttoptr i64 %v9029 to ptr
  %ld9031 = load i64, ptr %p9030, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9031, ptr %slot1642, align 8
  %v9032 = load i64, ptr %slot1642, align 8
  %cmp9033 = icmp ne i64 %v9032, 0
  %cv9034 = zext i1 %cmp9033 to i32
  store i32 %cv9034, ptr %slot1643, align 8
  %v9035 = load i32, ptr %slot1643, align 8
  %cv9036 = zext i32 %v9035 to i64
  %cond9037 = icmp ne i64 %cv9036, 0
  br i1 %cond9037, label %bb_rcgnn2121, label %bb_rcgdone2121
bb_rcgnn2121:
  %v9038 = load i64, ptr %slot1642, align 8
  %op9039 = sub i64 %v9038, 16
  store i64 %op9039, ptr %slot1644, align 8
  %v9040 = load i64, ptr %slot1642, align 8
  %p9041 = inttoptr i64 %v9040 to ptr
  %rgep9042 = getelementptr i8, ptr %p9041, i64 -16
  %ld9043 = load i64, ptr %rgep9042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9043, ptr %slot1645, align 8
  %v9044 = load i64, ptr %slot1645, align 8
  %op9045 = and i64 %v9044, 4611686018427387906
  store i64 %op9045, ptr %slot1646, align 8
  %v9046 = load i64, ptr %slot1646, align 8
  %cmp9047 = icmp ne i64 %v9046, 0
  %cv9048 = zext i1 %cmp9047 to i32
  store i32 %cv9048, ptr %slot1647, align 8
  %v9049 = load i32, ptr %slot1647, align 8
  %cv9050 = zext i32 %v9049 to i64
  %cond9051 = icmp ne i64 %cv9050, 0
  br i1 %cond9051, label %bb_rcgclear2121, label %bb_rcgcounted2121
bb_rcgcounted2121:
  %v9052 = load i64, ptr %slot1642, align 8
  %op9053 = sub i64 %v9052, 32
  store i64 %op9053, ptr %slot1648, align 8
  %v9054 = load i64, ptr %slot1642, align 8
  %p9055 = inttoptr i64 %v9054 to ptr
  %rgep9056 = getelementptr i8, ptr %p9055, i64 -32
  %ld9057 = load i64, ptr %rgep9056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9057, ptr %slot1649, align 8
  %v9058 = load i64, ptr %slot1649, align 8
  %op9059 = sub i64 %v9058, 1
  store i64 %op9059, ptr %slot1650, align 8
  %v9060 = load i64, ptr %slot1650, align 8
  %cmp9061 = icmp eq i64 %v9060, 0
  %cv9062 = zext i1 %cmp9061 to i32
  store i32 %cv9062, ptr %slot1651, align 8
  %v9063 = load i32, ptr %slot1651, align 8
  %cv9064 = zext i32 %v9063 to i64
  %cond9065 = icmp ne i64 %cv9064, 0
  br i1 %cond9065, label %bb_rcglast2121, label %bb_rcgdec2121
bb_rcglast2121:
  %v9066 = load i64, ptr %slot1642, align 8
  %op9067 = sub i64 %v9066, 24
  store i64 %op9067, ptr %slot1652, align 8
  %v9068 = load i64, ptr %slot1642, align 8
  %p9069 = inttoptr i64 %v9068 to ptr
  %rgep9070 = getelementptr i8, ptr %p9069, i64 -24
  %ld9071 = load i64, ptr %rgep9070, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9071, ptr %slot1653, align 8
  %v9072 = load i64, ptr %slot1653, align 8
  %cmp9073 = icmp ne i64 %v9072, 0
  %cv9074 = zext i1 %cmp9073 to i32
  store i32 %cv9074, ptr %slot1654, align 8
  %v9075 = load i32, ptr %slot1654, align 8
  %cv9076 = zext i32 %v9075 to i64
  %cond9077 = icmp ne i64 %cv9076, 0
  br i1 %cond9077, label %bb_rcgdec2121, label %bb_rcgslow2121
bb_rcgslow2121:
  %v9078 = load i64, ptr %slot1641, align 8
  %v9079 = load i64, ptr %slot1624, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v9078, i64 %v9079) nomerge, !dbg !162
  br label %bb_rcgdone2121
bb_rcgdec2121:
  %v9080 = load i64, ptr %slot1650, align 8
  %v9081 = load i64, ptr %slot1642, align 8
  %p9082 = inttoptr i64 %v9081 to ptr
  %rgep9083 = getelementptr i8, ptr %p9082, i64 -32
  store i64 %v9080, ptr %rgep9083, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2121
bb_rcgclear2121:
  %v9084 = load i64, ptr %slot1624, align 8
  %p9085 = inttoptr i64 %v9084 to ptr
  store i64 0, ptr %p9085, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2121
bb_rcgdone2121:
  br label %bb_rcslotdone2090
bb_rcslotdone2090:
  %v9086 = load i64, ptr %slot24, align 8
  %p9087 = inttoptr i64 %v9086 to ptr
  %ld9088 = load i64, ptr %p9087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9088, ptr %slot1655, align 8
  %v9089 = load i64, ptr %slot24, align 8
  %p9090 = inttoptr i64 %v9089 to ptr
  %ld9091 = load i64, ptr %p9090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9091, ptr %slot1656, align 8
  %v9092 = load i64, ptr %slot31, align 8
  %p9093 = inttoptr i64 %v9092 to ptr
  %v9094 = load i64, ptr %slot1656, align 8
  %p9095 = inttoptr i64 %v9094 to ptr
  %call9096 = call ptr @myl_native_bytes_encode(ptr %p9093, ptr %p9095) nomerge, !dbg !164
  %calladdr9097 = ptrtoint ptr %call9096 to i64
  store i64 %calladdr9097, ptr %slot1657, align 8
  %v9098 = load i64, ptr %slot1657, align 8
  %cond9099 = icmp ne i64 %v9098, 0
  br i1 %cond9099, label %bb_success2129, label %bb_failed2129
bb_failed2129:
  %v9100 = load i64, ptr %slot1, align 8
  %p9101 = inttoptr i64 %v9100 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9101) nomerge, !dbg !164
  unreachable
bb_success2129:
  %v9102 = load i64, ptr %slot1657, align 8
  %v9103 = load i64, ptr %slot25, align 8
  %p9104 = inttoptr i64 %v9103 to ptr
  store i64 %v9102, ptr %p9104, align 8, !alias.scope !3, !noalias !4
  %v9105 = load i64, ptr %slot25, align 8
  %p9106 = inttoptr i64 %v9105 to ptr
  %ld9107 = load i64, ptr %p9106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9107, ptr %slot1658, align 8
  %v9108 = load i64, ptr %slot1658, align 8
  %v9109 = load i64, ptr %slot16, align 8
  %p9110 = inttoptr i64 %v9109 to ptr
  store i64 %v9108, ptr %p9110, align 8, !alias.scope !3, !noalias !4
  %v9111 = load i64, ptr %slot16, align 8
  store i64 %v9111, ptr %slot1659, align 8
  %v9112 = load i64, ptr %slot17, align 8
  store i64 %v9112, ptr %slot1660, align 8
  %v9113 = load i64, ptr %slot1659, align 8
  %v9114 = load i64, ptr %slot1660, align 8
  %p9115 = inttoptr i64 %v9113 to ptr
  %p9116 = inttoptr i64 %v9114 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9116, ptr %p9115, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9117 = load i64, ptr %slot14, align 8
  %p9118 = inttoptr i64 %v9117 to ptr
  store i32 2, ptr %p9118, align 4, !alias.scope !3, !noalias !4
  %v9119 = load i64, ptr %slot13, align 8
  %p9120 = inttoptr i64 %v9119 to ptr
  store i32 1, ptr %p9120, align 4, !alias.scope !3, !noalias !4
  %v9121 = load i64, ptr %slot15, align 8
  store i64 %v9121, ptr %slot1661, align 8
  %v9122 = load i64, ptr %slot17, align 8
  store i64 %v9122, ptr %slot1662, align 8
  %v9123 = load i64, ptr %slot1662, align 8
  %v9124 = load i64, ptr %slot1661, align 8
  %p9125 = inttoptr i64 %v9123 to ptr
  %p9126 = inttoptr i64 %v9124 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9126, ptr %p9125, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9127 = load i64, ptr %slot12, align 8
  %p9128 = inttoptr i64 %v9127 to ptr
  store i32 2, ptr %p9128, align 4, !alias.scope !3, !noalias !4
  %v9129 = load i64, ptr %slot14, align 8
  %p9130 = inttoptr i64 %v9129 to ptr
  %ld9131 = load i32, ptr %p9130, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9131, ptr %slot1663, align 8
  %v9132 = load i32, ptr %slot1663, align 8
  %v9133 = load i64, ptr %slot12, align 8
  %p9134 = inttoptr i64 %v9133 to ptr
  store i32 %v9132, ptr %p9134, align 4, !alias.scope !3, !noalias !4
  %v9135 = load i64, ptr %slot13, align 8
  %p9136 = inttoptr i64 %v9135 to ptr
  store i32 0, ptr %p9136, align 4, !alias.scope !3, !noalias !4
  %v9137 = load i64, ptr %slot11, align 8
  %p9138 = inttoptr i64 %v9137 to ptr
  store i32 1, ptr %p9138, align 4, !alias.scope !3, !noalias !4
  %v9139 = load i64, ptr %slot1661, align 8
  %p9140 = inttoptr i64 %v9139 to ptr
  %ld9141 = load i64, ptr %p9140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9141, ptr %slot1664, align 8
  %v9142 = load i64, ptr %slot1664, align 8
  %v9143 = load i64, ptr %slot25, align 8
  %p9144 = inttoptr i64 %v9143 to ptr
  store i64 %v9142, ptr %p9144, align 8, !alias.scope !3, !noalias !4
  %v9145 = load i64, ptr %slot25, align 8
  %p9146 = inttoptr i64 %v9145 to ptr
  %ld9147 = load i64, ptr %p9146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9147, ptr %slot1665, align 8
  %v9148 = load i64, ptr %slot25, align 8
  %p9149 = inttoptr i64 %v9148 to ptr
  %ld9150 = load i64, ptr %p9149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9150, ptr %slot1666, align 8
  %v9151 = load i64, ptr %slot1666, align 8
  %v9152 = load i64, ptr %slot16, align 8
  %p9153 = inttoptr i64 %v9152 to ptr
  store i64 %v9151, ptr %p9153, align 8, !alias.scope !3, !noalias !4
  %v9154 = load i64, ptr %slot16, align 8
  store i64 %v9154, ptr %slot1667, align 8
  %v9155 = load i64, ptr %slot11, align 8
  %p9156 = inttoptr i64 %v9155 to ptr
  %ld9157 = load i32, ptr %p9156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9157, ptr %slot1668, align 8
  %v9158 = load i64, ptr %slot12, align 8
  %p9159 = inttoptr i64 %v9158 to ptr
  %ld9160 = load i32, ptr %p9159, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9160, ptr %slot1669, align 8
  %v9161 = load i32, ptr %slot1669, align 8
  %op9162 = and i32 %v9161, 24
  store i32 %op9162, ptr %slot1669, align 8
  %v9163 = load i32, ptr %slot1669, align 8
  %cmp9164 = icmp eq i32 %v9163, 0
  %cv9165 = zext i1 %cmp9164 to i32
  store i32 %cv9165, ptr %slot1670, align 8
  %v9166 = load i32, ptr %slot1668, align 8
  %v9167 = load i32, ptr %slot1670, align 8
  %op9168 = and i32 %v9166, %v9167
  store i32 %op9168, ptr %slot1671, align 8
  %v9169 = load i32, ptr %slot1671, align 8
  %cv9170 = zext i32 %v9169 to i64
  %cond9171 = icmp ne i64 %cv9170, 0
  br i1 %cond9171, label %bb_rctake2147, label %bb_rccopy2147
bb_rctake2147:
  %v9172 = load i64, ptr %slot17, align 8
  store i64 %v9172, ptr %slot1672, align 8
  %v9173 = load i64, ptr %slot32, align 8
  store i64 %v9173, ptr %slot1673, align 8
  %v9174 = load i64, ptr %slot1667, align 8
  %v9175 = load i64, ptr %slot1672, align 8
  %op9176 = sub i64 %v9174, %v9175
  store i64 %op9176, ptr %slot1674, align 8
  %v9177 = load i64, ptr %slot1672, align 8
  %v9178 = load i64, ptr %slot1667, align 8
  %op9179 = sub i64 %v9177, %v9178
  store i64 %op9179, ptr %slot1675, align 8
  %v9180 = load i64, ptr %slot1674, align 8
  %cmp9181 = icmp ult i64 %v9180, 8
  %cv9182 = zext i1 %cmp9181 to i32
  store i32 %cv9182, ptr %slot1676, align 8
  %v9183 = load i64, ptr %slot1675, align 8
  %cmp9184 = icmp ult i64 %v9183, 8
  %cv9185 = zext i1 %cmp9184 to i32
  store i32 %cv9185, ptr %slot1677, align 8
  %v9186 = load i32, ptr %slot1676, align 8
  %v9187 = load i32, ptr %slot1677, align 8
  %op9188 = or i32 %v9186, %v9187
  store i32 %op9188, ptr %slot1678, align 8
  %v9189 = load i32, ptr %slot1678, align 8
  %cv9190 = zext i32 %v9189 to i64
  %cond9191 = icmp ne i64 %cv9190, 0
  br i1 %cond9191, label %bb_rcmoveslow2156, label %bb_rcmovecheck2156
bb_rcmovecheck2156:
  %v9192 = load i64, ptr %slot1667, align 8
  %p9194 = inttoptr i64 %v9192 to ptr
  %gep9195 = getelementptr i8, ptr %p9194, i64 0
  %op9193 = ptrtoint ptr %gep9195 to i64
  store i64 %op9193, ptr %slot1679, align 8
  %v9196 = load i64, ptr %slot1679, align 8
  %p9197 = inttoptr i64 %v9196 to ptr
  %ld9198 = load i64, ptr %p9197, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9198, ptr %slot1680, align 8
  %v9199 = load i64, ptr %slot1680, align 8
  %cmp9200 = icmp ne i64 %v9199, 0
  %cv9201 = zext i1 %cmp9200 to i32
  store i32 %cv9201, ptr %slot1681, align 8
  %v9202 = load i32, ptr %slot1681, align 8
  %cv9203 = zext i32 %v9202 to i64
  %cond9204 = icmp ne i64 %cv9203, 0
  br i1 %cond9204, label %bb_rcmoveheader2164, label %bb_rcmovenext2164
bb_rcmoveheader2164:
  %v9205 = load i64, ptr %slot1680, align 8
  %op9206 = sub i64 %v9205, 16
  store i64 %op9206, ptr %slot1682, align 8
  %v9207 = load i64, ptr %slot1680, align 8
  %p9208 = inttoptr i64 %v9207 to ptr
  %rgep9209 = getelementptr i8, ptr %p9208, i64 -16
  %ld9210 = load i64, ptr %rgep9209, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9210, ptr %slot1683, align 8
  %v9211 = load i64, ptr %slot1683, align 8
  %op9212 = and i64 %v9211, 5764607523034234881
  store i64 %op9212, ptr %slot1684, align 8
  %v9213 = load i64, ptr %slot1684, align 8
  %cmp9214 = icmp ne i64 %v9213, 0
  %cv9215 = zext i1 %cmp9214 to i32
  store i32 %cv9215, ptr %slot1685, align 8
  %v9216 = load i32, ptr %slot1685, align 8
  %cv9217 = zext i32 %v9216 to i64
  %cond9218 = icmp ne i64 %cv9217, 0
  br i1 %cond9218, label %bb_rcmoveslow2156, label %bb_rcmovenext2164
bb_rcmovenext2164:
  %v9219 = load i64, ptr %slot1667, align 8
  %v9220 = load i64, ptr %slot1672, align 8
  %p9221 = inttoptr i64 %v9219 to ptr
  %p9222 = inttoptr i64 %v9220 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9222, ptr %p9221, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9223 = load i64, ptr %slot1667, align 8
  %p9224 = inttoptr i64 %v9223 to ptr
  store i64 0, ptr %p9224, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2156
bb_rcmoveslow2156:
  %v9225 = load i64, ptr %slot31, align 8
  %v9226 = load i64, ptr %slot1672, align 8
  %v9227 = load i64, ptr %slot1667, align 8
  %v9228 = load i64, ptr %slot1673, align 8
  %cv9229 = trunc i64 %v9228 to i32
  %call9230 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v9225, i64 %v9226, i64 %v9227, i32 %cv9229) nomerge, !dbg !166
  store i32 %call9230, ptr %slot1686, align 8
  %v9231 = load i32, ptr %slot1686, align 8
  %cv9232 = zext i32 %v9231 to i64
  %cond9233 = icmp ne i64 %cv9232, 0
  br i1 %cond9233, label %bb_rcsuccess2171, label %bb_rcfailure2171
bb_rcfailure2171:
  %v9234 = load i64, ptr %slot31, align 8
  %p9235 = inttoptr i64 %v9234 to ptr
  %call9236 = call i32 @myl_rc_take_failure(ptr %p9235) nomerge, !dbg !166
  store i32 %call9236, ptr %slot1687, align 8
  %v9237 = load i64, ptr %slot1, align 8
  %p9238 = inttoptr i64 %v9237 to ptr
  %v9239 = load i32, ptr %slot1687, align 8
  %call9240 = call i32 @myl_qbe_rc_status(ptr %p9238, i32 %v9239) nomerge, !dbg !166
  store i32 %call9240, ptr %slot1688, align 8
  br label %bb_failure
bb_rcsuccess2171:
  br label %bb_rcmoved2156
bb_rcmoved2156:
  %v9241 = load i64, ptr %slot11, align 8
  %p9242 = inttoptr i64 %v9241 to ptr
  store i32 0, ptr %p9242, align 4, !alias.scope !3, !noalias !4
  %v9243 = load i64, ptr %slot14, align 8
  %p9244 = inttoptr i64 %v9243 to ptr
  store i32 2, ptr %p9244, align 4, !alias.scope !3, !noalias !4
  %v9245 = load i64, ptr %slot13, align 8
  %p9246 = inttoptr i64 %v9245 to ptr
  store i32 1, ptr %p9246, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2147
bb_rccopy2147:
  %v9247 = load i64, ptr %slot17, align 8
  store i64 %v9247, ptr %slot1689, align 8
  %v9248 = load i64, ptr %slot32, align 8
  store i64 %v9248, ptr %slot1690, align 8
  %v9249 = load i64, ptr %slot1667, align 8
  %p9250 = inttoptr i64 %v9249 to ptr
  %ld9251 = load i64, ptr %p9250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9251, ptr %slot1691, align 8
  %v9252 = load i64, ptr %slot1691, align 8
  %cmp9253 = icmp ne i64 %v9252, 0
  %cv9254 = zext i1 %cmp9253 to i32
  store i32 %cv9254, ptr %slot1692, align 8
  %v9255 = load i32, ptr %slot1692, align 8
  %cv9256 = zext i32 %v9255 to i64
  %cond9257 = icmp ne i64 %cv9256, 0
  br i1 %cond9257, label %bb_rcgnn2180, label %bb_rcgplain2180
bb_rcgnn2180:
  %v9258 = load i64, ptr %slot1691, align 8
  %op9259 = sub i64 %v9258, 16
  store i64 %op9259, ptr %slot1693, align 8
  %v9260 = load i64, ptr %slot1691, align 8
  %p9261 = inttoptr i64 %v9260 to ptr
  %rgep9262 = getelementptr i8, ptr %p9261, i64 -16
  %ld9263 = load i64, ptr %rgep9262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9263, ptr %slot1694, align 8
  %v9264 = load i64, ptr %slot1694, align 8
  %op9265 = and i64 %v9264, 4611686018427387906
  store i64 %op9265, ptr %slot1695, align 8
  %v9266 = load i64, ptr %slot1695, align 8
  %cmp9267 = icmp ne i64 %v9266, 0
  %cv9268 = zext i1 %cmp9267 to i32
  store i32 %cv9268, ptr %slot1696, align 8
  %v9269 = load i32, ptr %slot1696, align 8
  %cv9270 = zext i32 %v9269 to i64
  %cond9271 = icmp ne i64 %cv9270, 0
  br i1 %cond9271, label %bb_rcgspecial2180, label %bb_rcginc2180
bb_rcginc2180:
  %v9272 = load i64, ptr %slot1691, align 8
  %op9273 = sub i64 %v9272, 32
  store i64 %op9273, ptr %slot1697, align 8
  %v9274 = load i64, ptr %slot1691, align 8
  %p9275 = inttoptr i64 %v9274 to ptr
  %rgep9276 = getelementptr i8, ptr %p9275, i64 -32
  %ld9277 = load i64, ptr %rgep9276, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9277, ptr %slot1698, align 8
  %v9278 = load i64, ptr %slot1698, align 8
  %op9279 = add i64 %v9278, 1
  store i64 %op9279, ptr %slot1699, align 8
  %v9280 = load i64, ptr %slot1699, align 8
  %cmp9281 = icmp eq i64 %v9280, 0
  %cv9282 = zext i1 %cmp9281 to i32
  store i32 %cv9282, ptr %slot1700, align 8
  %v9283 = load i32, ptr %slot1700, align 8
  %cv9284 = zext i32 %v9283 to i64
  %cond9285 = icmp ne i64 %cv9284, 0
  br i1 %cond9285, label %bb_rcglimit2180, label %bb_rcgcapacity2180
bb_rcglimit2180:
  %v9286 = load i64, ptr %slot1, align 8
  %p9287 = inttoptr i64 %v9286 to ptr
  %call9288 = call i32 @myl_qbe_rc_status(ptr %p9287, i32 2) nomerge, !dbg !166
  store i32 %call9288, ptr %slot1701, align 8
  br label %bb_failure
bb_rcgcapacity2180:
  %v9289 = load i64, ptr %slot1699, align 8
  %v9290 = load i64, ptr %slot1691, align 8
  %p9291 = inttoptr i64 %v9290 to ptr
  %rgep9292 = getelementptr i8, ptr %p9291, i64 -32
  store i64 %v9289, ptr %rgep9292, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2180
bb_rcgspecial2180:
  %v9293 = load i64, ptr %slot1694, align 8
  %op9294 = and i64 %v9293, 4611686018427387904
  store i64 %op9294, ptr %slot1702, align 8
  %v9295 = load i64, ptr %slot1702, align 8
  %cmp9296 = icmp ne i64 %v9295, 0
  %cv9297 = zext i1 %cmp9296 to i32
  store i32 %cv9297, ptr %slot1703, align 8
  %v9298 = load i32, ptr %slot1703, align 8
  %cv9299 = zext i32 %v9298 to i64
  %cond9300 = icmp ne i64 %cv9299, 0
  br i1 %cond9300, label %bb_rcgslow2180, label %bb_rcgplain2180
bb_rcgslow2180:
  %v9301 = load i64, ptr %slot31, align 8
  %v9302 = load i64, ptr %slot1689, align 8
  %v9303 = load i64, ptr %slot1667, align 8
  %v9304 = load i64, ptr %slot1690, align 8
  %cv9305 = trunc i64 %v9304 to i32
  %call9306 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v9301, i64 %v9302, i64 %v9303, i32 %cv9305) nomerge, !dbg !166
  store i32 %call9306, ptr %slot1704, align 8
  %v9307 = load i32, ptr %slot1704, align 8
  %cv9308 = zext i32 %v9307 to i64
  %cond9309 = icmp ne i64 %cv9308, 0
  br i1 %cond9309, label %bb_rcsuccess2194, label %bb_rcfailure2194
bb_rcfailure2194:
  %v9310 = load i64, ptr %slot31, align 8
  %p9311 = inttoptr i64 %v9310 to ptr
  %call9312 = call i32 @myl_rc_take_failure(ptr %p9311) nomerge, !dbg !166
  store i32 %call9312, ptr %slot1705, align 8
  %v9313 = load i64, ptr %slot1, align 8
  %p9314 = inttoptr i64 %v9313 to ptr
  %v9315 = load i32, ptr %slot1705, align 8
  %call9316 = call i32 @myl_qbe_rc_status(ptr %p9314, i32 %v9315) nomerge, !dbg !166
  store i32 %call9316, ptr %slot1706, align 8
  br label %bb_failure
bb_rcsuccess2194:
  br label %bb_rcgdone2180
bb_rcgplain2180:
  %v9317 = load i64, ptr %slot1691, align 8
  %v9318 = load i64, ptr %slot1689, align 8
  %p9319 = inttoptr i64 %v9318 to ptr
  store i64 %v9317, ptr %p9319, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2180
bb_rcgdone2180:
  %v9320 = load i64, ptr %slot14, align 8
  %p9321 = inttoptr i64 %v9320 to ptr
  store i32 2, ptr %p9321, align 4, !alias.scope !3, !noalias !4
  %v9322 = load i64, ptr %slot13, align 8
  %p9323 = inttoptr i64 %v9322 to ptr
  store i32 1, ptr %p9323, align 4, !alias.scope !3, !noalias !4
  %v9324 = load i64, ptr %slot11, align 8
  %p9325 = inttoptr i64 %v9324 to ptr
  %ld9326 = load i32, ptr %p9325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9326, ptr %slot1707, align 8
  %v9327 = load i32, ptr %slot1707, align 8
  %cv9328 = zext i32 %v9327 to i64
  %cond9329 = icmp ne i64 %cv9328, 0
  br i1 %cond9329, label %bb_rcslotdrop2201, label %bb_rcslotdone2201
bb_rcslotdrop2201:
  %v9330 = load i64, ptr %slot11, align 8
  %p9331 = inttoptr i64 %v9330 to ptr
  store i32 0, ptr %p9331, align 4, !alias.scope !3, !noalias !4
  %v9332 = load i64, ptr %slot15, align 8
  store i64 %v9332, ptr %slot1708, align 8
  %v9333 = load i64, ptr %slot12, align 8
  %p9334 = inttoptr i64 %v9333 to ptr
  %ld9335 = load i32, ptr %p9334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9335, ptr %slot1709, align 8
  %v9336 = load i32, ptr %slot1709, align 8
  %op9337 = and i32 %v9336, 28
  store i32 %op9337, ptr %slot1710, align 8
  %v9338 = load i32, ptr %slot1710, align 8
  %cv9339 = zext i32 %v9338 to i64
  %cond9340 = icmp ne i64 %cv9339, 0
  br i1 %cond9340, label %bb_rcslotrole2201, label %bb_rcslotowner2201
bb_rcslotrole2201:
  %v9341 = load i64, ptr %slot31, align 8
  store i64 %v9341, ptr %slot1711, align 8
  %v9342 = load i64, ptr %slot1708, align 8
  %p9343 = inttoptr i64 %v9342 to ptr
  %ld9344 = load i64, ptr %p9343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9344, ptr %slot1712, align 8
  %v9345 = load i64, ptr %slot1712, align 8
  %cmp9346 = icmp ne i64 %v9345, 0
  %cv9347 = zext i1 %cmp9346 to i32
  store i32 %cv9347, ptr %slot1713, align 8
  %v9348 = load i32, ptr %slot1713, align 8
  %cv9349 = zext i32 %v9348 to i64
  %cond9350 = icmp ne i64 %cv9349, 0
  br i1 %cond9350, label %bb_rcgnn2217, label %bb_rcgdone2217
bb_rcgnn2217:
  %v9351 = load i64, ptr %slot1712, align 8
  %op9352 = sub i64 %v9351, 16
  store i64 %op9352, ptr %slot1714, align 8
  %v9353 = load i64, ptr %slot1712, align 8
  %p9354 = inttoptr i64 %v9353 to ptr
  %rgep9355 = getelementptr i8, ptr %p9354, i64 -16
  %ld9356 = load i64, ptr %rgep9355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9356, ptr %slot1715, align 8
  %v9357 = load i64, ptr %slot1715, align 8
  %op9358 = and i64 %v9357, 4611686018427387906
  store i64 %op9358, ptr %slot1716, align 8
  %v9359 = load i64, ptr %slot1716, align 8
  %cmp9360 = icmp ne i64 %v9359, 0
  %cv9361 = zext i1 %cmp9360 to i32
  store i32 %cv9361, ptr %slot1717, align 8
  %v9362 = load i32, ptr %slot1717, align 8
  %cv9363 = zext i32 %v9362 to i64
  %cond9364 = icmp ne i64 %cv9363, 0
  br i1 %cond9364, label %bb_rcgclear2217, label %bb_rcgcounted2217
bb_rcgcounted2217:
  %v9365 = load i64, ptr %slot1712, align 8
  %op9366 = sub i64 %v9365, 24
  store i64 %op9366, ptr %slot1718, align 8
  %v9367 = load i64, ptr %slot1712, align 8
  %p9368 = inttoptr i64 %v9367 to ptr
  %rgep9369 = getelementptr i8, ptr %p9368, i64 -24
  %ld9370 = load i64, ptr %rgep9369, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9370, ptr %slot1719, align 8
  %v9371 = load i64, ptr %slot1719, align 8
  %op9372 = sub i64 %v9371, 1
  store i64 %op9372, ptr %slot1720, align 8
  %v9373 = load i64, ptr %slot1720, align 8
  %cmp9374 = icmp eq i64 %v9373, 0
  %cv9375 = zext i1 %cmp9374 to i32
  store i32 %cv9375, ptr %slot1721, align 8
  %v9376 = load i32, ptr %slot1721, align 8
  %cv9377 = zext i32 %v9376 to i64
  %cond9378 = icmp ne i64 %cv9377, 0
  br i1 %cond9378, label %bb_rcglast2217, label %bb_rcgdec2217
bb_rcglast2217:
  %v9379 = load i64, ptr %slot1712, align 8
  %op9380 = sub i64 %v9379, 32
  store i64 %op9380, ptr %slot1722, align 8
  %v9381 = load i64, ptr %slot1712, align 8
  %p9382 = inttoptr i64 %v9381 to ptr
  %rgep9383 = getelementptr i8, ptr %p9382, i64 -32
  %ld9384 = load i64, ptr %rgep9383, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9384, ptr %slot1723, align 8
  %v9385 = load i64, ptr %slot1723, align 8
  %cmp9386 = icmp ne i64 %v9385, 0
  %cv9387 = zext i1 %cmp9386 to i32
  store i32 %cv9387, ptr %slot1724, align 8
  %v9388 = load i32, ptr %slot1724, align 8
  %cv9389 = zext i32 %v9388 to i64
  %cond9390 = icmp ne i64 %cv9389, 0
  br i1 %cond9390, label %bb_rcgdec2217, label %bb_rcgslow2217
bb_rcgslow2217:
  %v9391 = load i64, ptr %slot1711, align 8
  %v9392 = load i64, ptr %slot1708, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v9391, i64 %v9392) nomerge, !dbg !166
  br label %bb_rcgdone2217
bb_rcgdec2217:
  %v9393 = load i64, ptr %slot1720, align 8
  %v9394 = load i64, ptr %slot1712, align 8
  %p9395 = inttoptr i64 %v9394 to ptr
  %rgep9396 = getelementptr i8, ptr %p9395, i64 -24
  store i64 %v9393, ptr %rgep9396, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2217
bb_rcgclear2217:
  %v9397 = load i64, ptr %slot1708, align 8
  %p9398 = inttoptr i64 %v9397 to ptr
  store i64 0, ptr %p9398, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2217
bb_rcgdone2217:
  br label %bb_rcslotdone2201
bb_rcslotowner2201:
  %v9399 = load i64, ptr %slot31, align 8
  store i64 %v9399, ptr %slot1725, align 8
  %v9400 = load i64, ptr %slot1708, align 8
  %p9401 = inttoptr i64 %v9400 to ptr
  %ld9402 = load i64, ptr %p9401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9402, ptr %slot1726, align 8
  %v9403 = load i64, ptr %slot1726, align 8
  %cmp9404 = icmp ne i64 %v9403, 0
  %cv9405 = zext i1 %cmp9404 to i32
  store i32 %cv9405, ptr %slot1727, align 8
  %v9406 = load i32, ptr %slot1727, align 8
  %cv9407 = zext i32 %v9406 to i64
  %cond9408 = icmp ne i64 %cv9407, 0
  br i1 %cond9408, label %bb_rcgnn2232, label %bb_rcgdone2232
bb_rcgnn2232:
  %v9409 = load i64, ptr %slot1726, align 8
  %op9410 = sub i64 %v9409, 16
  store i64 %op9410, ptr %slot1728, align 8
  %v9411 = load i64, ptr %slot1726, align 8
  %p9412 = inttoptr i64 %v9411 to ptr
  %rgep9413 = getelementptr i8, ptr %p9412, i64 -16
  %ld9414 = load i64, ptr %rgep9413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9414, ptr %slot1729, align 8
  %v9415 = load i64, ptr %slot1729, align 8
  %op9416 = and i64 %v9415, 4611686018427387906
  store i64 %op9416, ptr %slot1730, align 8
  %v9417 = load i64, ptr %slot1730, align 8
  %cmp9418 = icmp ne i64 %v9417, 0
  %cv9419 = zext i1 %cmp9418 to i32
  store i32 %cv9419, ptr %slot1731, align 8
  %v9420 = load i32, ptr %slot1731, align 8
  %cv9421 = zext i32 %v9420 to i64
  %cond9422 = icmp ne i64 %cv9421, 0
  br i1 %cond9422, label %bb_rcgclear2232, label %bb_rcgcounted2232
bb_rcgcounted2232:
  %v9423 = load i64, ptr %slot1726, align 8
  %op9424 = sub i64 %v9423, 32
  store i64 %op9424, ptr %slot1732, align 8
  %v9425 = load i64, ptr %slot1726, align 8
  %p9426 = inttoptr i64 %v9425 to ptr
  %rgep9427 = getelementptr i8, ptr %p9426, i64 -32
  %ld9428 = load i64, ptr %rgep9427, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9428, ptr %slot1733, align 8
  %v9429 = load i64, ptr %slot1733, align 8
  %op9430 = sub i64 %v9429, 1
  store i64 %op9430, ptr %slot1734, align 8
  %v9431 = load i64, ptr %slot1734, align 8
  %cmp9432 = icmp eq i64 %v9431, 0
  %cv9433 = zext i1 %cmp9432 to i32
  store i32 %cv9433, ptr %slot1735, align 8
  %v9434 = load i32, ptr %slot1735, align 8
  %cv9435 = zext i32 %v9434 to i64
  %cond9436 = icmp ne i64 %cv9435, 0
  br i1 %cond9436, label %bb_rcglast2232, label %bb_rcgdec2232
bb_rcglast2232:
  %v9437 = load i64, ptr %slot1726, align 8
  %op9438 = sub i64 %v9437, 24
  store i64 %op9438, ptr %slot1736, align 8
  %v9439 = load i64, ptr %slot1726, align 8
  %p9440 = inttoptr i64 %v9439 to ptr
  %rgep9441 = getelementptr i8, ptr %p9440, i64 -24
  %ld9442 = load i64, ptr %rgep9441, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9442, ptr %slot1737, align 8
  %v9443 = load i64, ptr %slot1737, align 8
  %cmp9444 = icmp ne i64 %v9443, 0
  %cv9445 = zext i1 %cmp9444 to i32
  store i32 %cv9445, ptr %slot1738, align 8
  %v9446 = load i32, ptr %slot1738, align 8
  %cv9447 = zext i32 %v9446 to i64
  %cond9448 = icmp ne i64 %cv9447, 0
  br i1 %cond9448, label %bb_rcgdec2232, label %bb_rcgslow2232
bb_rcgslow2232:
  %v9449 = load i64, ptr %slot1725, align 8
  %v9450 = load i64, ptr %slot1708, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v9449, i64 %v9450) nomerge, !dbg !166
  br label %bb_rcgdone2232
bb_rcgdec2232:
  %v9451 = load i64, ptr %slot1734, align 8
  %v9452 = load i64, ptr %slot1726, align 8
  %p9453 = inttoptr i64 %v9452 to ptr
  %rgep9454 = getelementptr i8, ptr %p9453, i64 -32
  store i64 %v9451, ptr %rgep9454, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2232
bb_rcgclear2232:
  %v9455 = load i64, ptr %slot1708, align 8
  %p9456 = inttoptr i64 %v9455 to ptr
  store i64 0, ptr %p9456, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2232
bb_rcgdone2232:
  br label %bb_rcslotdone2201
bb_rcslotdone2201:
  br label %bb_rcprepared2147
bb_rcprepared2147:
  %v9457 = load i64, ptr %slot17, align 8
  store i64 %v9457, ptr %slot1739, align 8
  %v9458 = load i64, ptr %slot1739, align 8
  %p9459 = inttoptr i64 %v9458 to ptr
  %ld9460 = load i64, ptr %p9459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9460, ptr %slot1740, align 8
  %v9461 = load i64, ptr %slot13, align 8
  %p9462 = inttoptr i64 %v9461 to ptr
  store i32 0, ptr %p9462, align 4, !alias.scope !3, !noalias !4
  %v9463 = load i64, ptr %slot11, align 8
  %p9464 = inttoptr i64 %v9463 to ptr
  %ld9465 = load i32, ptr %p9464, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9465, ptr %slot1741, align 8
  %v9466 = load i32, ptr %slot1741, align 8
  %cv9467 = zext i32 %v9466 to i64
  %cond9468 = icmp ne i64 %cv9467, 0
  br i1 %cond9468, label %bb_rcslotdrop2241, label %bb_rcslotdone2241
bb_rcslotdrop2241:
  %v9469 = load i64, ptr %slot11, align 8
  %p9470 = inttoptr i64 %v9469 to ptr
  store i32 0, ptr %p9470, align 4, !alias.scope !3, !noalias !4
  %v9471 = load i64, ptr %slot15, align 8
  store i64 %v9471, ptr %slot1742, align 8
  %v9472 = load i64, ptr %slot12, align 8
  %p9473 = inttoptr i64 %v9472 to ptr
  %ld9474 = load i32, ptr %p9473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9474, ptr %slot1743, align 8
  %v9475 = load i32, ptr %slot1743, align 8
  %op9476 = and i32 %v9475, 28
  store i32 %op9476, ptr %slot1744, align 8
  %v9477 = load i32, ptr %slot1744, align 8
  %cv9478 = zext i32 %v9477 to i64
  %cond9479 = icmp ne i64 %cv9478, 0
  br i1 %cond9479, label %bb_rcslotrole2241, label %bb_rcslotowner2241
bb_rcslotrole2241:
  %v9480 = load i64, ptr %slot31, align 8
  store i64 %v9480, ptr %slot1745, align 8
  %v9481 = load i64, ptr %slot1742, align 8
  %p9482 = inttoptr i64 %v9481 to ptr
  %ld9483 = load i64, ptr %p9482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9483, ptr %slot1746, align 8
  %v9484 = load i64, ptr %slot1746, align 8
  %cmp9485 = icmp ne i64 %v9484, 0
  %cv9486 = zext i1 %cmp9485 to i32
  store i32 %cv9486, ptr %slot1747, align 8
  %v9487 = load i32, ptr %slot1747, align 8
  %cv9488 = zext i32 %v9487 to i64
  %cond9489 = icmp ne i64 %cv9488, 0
  br i1 %cond9489, label %bb_rcgnn2257, label %bb_rcgdone2257
bb_rcgnn2257:
  %v9490 = load i64, ptr %slot1746, align 8
  %op9491 = sub i64 %v9490, 16
  store i64 %op9491, ptr %slot1748, align 8
  %v9492 = load i64, ptr %slot1746, align 8
  %p9493 = inttoptr i64 %v9492 to ptr
  %rgep9494 = getelementptr i8, ptr %p9493, i64 -16
  %ld9495 = load i64, ptr %rgep9494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9495, ptr %slot1749, align 8
  %v9496 = load i64, ptr %slot1749, align 8
  %op9497 = and i64 %v9496, 4611686018427387906
  store i64 %op9497, ptr %slot1750, align 8
  %v9498 = load i64, ptr %slot1750, align 8
  %cmp9499 = icmp ne i64 %v9498, 0
  %cv9500 = zext i1 %cmp9499 to i32
  store i32 %cv9500, ptr %slot1751, align 8
  %v9501 = load i32, ptr %slot1751, align 8
  %cv9502 = zext i32 %v9501 to i64
  %cond9503 = icmp ne i64 %cv9502, 0
  br i1 %cond9503, label %bb_rcgclear2257, label %bb_rcgcounted2257
bb_rcgcounted2257:
  %v9504 = load i64, ptr %slot1746, align 8
  %op9505 = sub i64 %v9504, 24
  store i64 %op9505, ptr %slot1752, align 8
  %v9506 = load i64, ptr %slot1746, align 8
  %p9507 = inttoptr i64 %v9506 to ptr
  %rgep9508 = getelementptr i8, ptr %p9507, i64 -24
  %ld9509 = load i64, ptr %rgep9508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9509, ptr %slot1753, align 8
  %v9510 = load i64, ptr %slot1753, align 8
  %op9511 = sub i64 %v9510, 1
  store i64 %op9511, ptr %slot1754, align 8
  %v9512 = load i64, ptr %slot1754, align 8
  %cmp9513 = icmp eq i64 %v9512, 0
  %cv9514 = zext i1 %cmp9513 to i32
  store i32 %cv9514, ptr %slot1755, align 8
  %v9515 = load i32, ptr %slot1755, align 8
  %cv9516 = zext i32 %v9515 to i64
  %cond9517 = icmp ne i64 %cv9516, 0
  br i1 %cond9517, label %bb_rcglast2257, label %bb_rcgdec2257
bb_rcglast2257:
  %v9518 = load i64, ptr %slot1746, align 8
  %op9519 = sub i64 %v9518, 32
  store i64 %op9519, ptr %slot1756, align 8
  %v9520 = load i64, ptr %slot1746, align 8
  %p9521 = inttoptr i64 %v9520 to ptr
  %rgep9522 = getelementptr i8, ptr %p9521, i64 -32
  %ld9523 = load i64, ptr %rgep9522, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9523, ptr %slot1757, align 8
  %v9524 = load i64, ptr %slot1757, align 8
  %cmp9525 = icmp ne i64 %v9524, 0
  %cv9526 = zext i1 %cmp9525 to i32
  store i32 %cv9526, ptr %slot1758, align 8
  %v9527 = load i32, ptr %slot1758, align 8
  %cv9528 = zext i32 %v9527 to i64
  %cond9529 = icmp ne i64 %cv9528, 0
  br i1 %cond9529, label %bb_rcgdec2257, label %bb_rcgslow2257
bb_rcgslow2257:
  %v9530 = load i64, ptr %slot1745, align 8
  %v9531 = load i64, ptr %slot1742, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v9530, i64 %v9531) nomerge, !dbg !166
  br label %bb_rcgdone2257
bb_rcgdec2257:
  %v9532 = load i64, ptr %slot1754, align 8
  %v9533 = load i64, ptr %slot1746, align 8
  %p9534 = inttoptr i64 %v9533 to ptr
  %rgep9535 = getelementptr i8, ptr %p9534, i64 -24
  store i64 %v9532, ptr %rgep9535, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2257
bb_rcgclear2257:
  %v9536 = load i64, ptr %slot1742, align 8
  %p9537 = inttoptr i64 %v9536 to ptr
  store i64 0, ptr %p9537, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2257
bb_rcgdone2257:
  br label %bb_rcslotdone2241
bb_rcslotowner2241:
  %v9538 = load i64, ptr %slot31, align 8
  store i64 %v9538, ptr %slot1759, align 8
  %v9539 = load i64, ptr %slot1742, align 8
  %p9540 = inttoptr i64 %v9539 to ptr
  %ld9541 = load i64, ptr %p9540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9541, ptr %slot1760, align 8
  %v9542 = load i64, ptr %slot1760, align 8
  %cmp9543 = icmp ne i64 %v9542, 0
  %cv9544 = zext i1 %cmp9543 to i32
  store i32 %cv9544, ptr %slot1761, align 8
  %v9545 = load i32, ptr %slot1761, align 8
  %cv9546 = zext i32 %v9545 to i64
  %cond9547 = icmp ne i64 %cv9546, 0
  br i1 %cond9547, label %bb_rcgnn2272, label %bb_rcgdone2272
bb_rcgnn2272:
  %v9548 = load i64, ptr %slot1760, align 8
  %op9549 = sub i64 %v9548, 16
  store i64 %op9549, ptr %slot1762, align 8
  %v9550 = load i64, ptr %slot1760, align 8
  %p9551 = inttoptr i64 %v9550 to ptr
  %rgep9552 = getelementptr i8, ptr %p9551, i64 -16
  %ld9553 = load i64, ptr %rgep9552, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9553, ptr %slot1763, align 8
  %v9554 = load i64, ptr %slot1763, align 8
  %op9555 = and i64 %v9554, 4611686018427387906
  store i64 %op9555, ptr %slot1764, align 8
  %v9556 = load i64, ptr %slot1764, align 8
  %cmp9557 = icmp ne i64 %v9556, 0
  %cv9558 = zext i1 %cmp9557 to i32
  store i32 %cv9558, ptr %slot1765, align 8
  %v9559 = load i32, ptr %slot1765, align 8
  %cv9560 = zext i32 %v9559 to i64
  %cond9561 = icmp ne i64 %cv9560, 0
  br i1 %cond9561, label %bb_rcgclear2272, label %bb_rcgcounted2272
bb_rcgcounted2272:
  %v9562 = load i64, ptr %slot1760, align 8
  %op9563 = sub i64 %v9562, 32
  store i64 %op9563, ptr %slot1766, align 8
  %v9564 = load i64, ptr %slot1760, align 8
  %p9565 = inttoptr i64 %v9564 to ptr
  %rgep9566 = getelementptr i8, ptr %p9565, i64 -32
  %ld9567 = load i64, ptr %rgep9566, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9567, ptr %slot1767, align 8
  %v9568 = load i64, ptr %slot1767, align 8
  %op9569 = sub i64 %v9568, 1
  store i64 %op9569, ptr %slot1768, align 8
  %v9570 = load i64, ptr %slot1768, align 8
  %cmp9571 = icmp eq i64 %v9570, 0
  %cv9572 = zext i1 %cmp9571 to i32
  store i32 %cv9572, ptr %slot1769, align 8
  %v9573 = load i32, ptr %slot1769, align 8
  %cv9574 = zext i32 %v9573 to i64
  %cond9575 = icmp ne i64 %cv9574, 0
  br i1 %cond9575, label %bb_rcglast2272, label %bb_rcgdec2272
bb_rcglast2272:
  %v9576 = load i64, ptr %slot1760, align 8
  %op9577 = sub i64 %v9576, 24
  store i64 %op9577, ptr %slot1770, align 8
  %v9578 = load i64, ptr %slot1760, align 8
  %p9579 = inttoptr i64 %v9578 to ptr
  %rgep9580 = getelementptr i8, ptr %p9579, i64 -24
  %ld9581 = load i64, ptr %rgep9580, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9581, ptr %slot1771, align 8
  %v9582 = load i64, ptr %slot1771, align 8
  %cmp9583 = icmp ne i64 %v9582, 0
  %cv9584 = zext i1 %cmp9583 to i32
  store i32 %cv9584, ptr %slot1772, align 8
  %v9585 = load i32, ptr %slot1772, align 8
  %cv9586 = zext i32 %v9585 to i64
  %cond9587 = icmp ne i64 %cv9586, 0
  br i1 %cond9587, label %bb_rcgdec2272, label %bb_rcgslow2272
bb_rcgslow2272:
  %v9588 = load i64, ptr %slot1759, align 8
  %v9589 = load i64, ptr %slot1742, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v9588, i64 %v9589) nomerge, !dbg !166
  br label %bb_rcgdone2272
bb_rcgdec2272:
  %v9590 = load i64, ptr %slot1768, align 8
  %v9591 = load i64, ptr %slot1760, align 8
  %p9592 = inttoptr i64 %v9591 to ptr
  %rgep9593 = getelementptr i8, ptr %p9592, i64 -32
  store i64 %v9590, ptr %rgep9593, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2272
bb_rcgclear2272:
  %v9594 = load i64, ptr %slot1742, align 8
  %p9595 = inttoptr i64 %v9594 to ptr
  store i64 0, ptr %p9595, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2272
bb_rcgdone2272:
  br label %bb_rcslotdone2241
bb_rcslotdone2241:
  %v9596 = load i64, ptr %slot9, align 8
  %p9597 = inttoptr i64 %v9596 to ptr
  %ld9598 = load i32, ptr %p9597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9598, ptr %slot1773, align 8
  %v9599 = load i32, ptr %slot1773, align 8
  %cv9600 = zext i32 %v9599 to i64
  %cond9601 = icmp ne i64 %cv9600, 0
  br i1 %cond9601, label %bb_rcslotdrop2278, label %bb_rcslotdone2278
bb_rcslotdrop2278:
  %v9602 = load i64, ptr %slot9, align 8
  %p9603 = inttoptr i64 %v9602 to ptr
  store i32 0, ptr %p9603, align 4, !alias.scope !3, !noalias !4
  %v9604 = load i64, ptr %slot24, align 8
  store i64 %v9604, ptr %slot1774, align 8
  %v9605 = load i64, ptr %slot10, align 8
  %p9606 = inttoptr i64 %v9605 to ptr
  %ld9607 = load i32, ptr %p9606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9607, ptr %slot1775, align 8
  %v9608 = load i32, ptr %slot1775, align 8
  %op9609 = and i32 %v9608, 28
  store i32 %op9609, ptr %slot1776, align 8
  %v9610 = load i32, ptr %slot1776, align 8
  %cv9611 = zext i32 %v9610 to i64
  %cond9612 = icmp ne i64 %cv9611, 0
  br i1 %cond9612, label %bb_rcslotrole2278, label %bb_rcslotowner2278
bb_rcslotrole2278:
  %v9613 = load i64, ptr %slot31, align 8
  store i64 %v9613, ptr %slot1777, align 8
  %v9614 = load i64, ptr %slot1774, align 8
  %p9615 = inttoptr i64 %v9614 to ptr
  %ld9616 = load i64, ptr %p9615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9616, ptr %slot1778, align 8
  %v9617 = load i64, ptr %slot1778, align 8
  %cmp9618 = icmp ne i64 %v9617, 0
  %cv9619 = zext i1 %cmp9618 to i32
  store i32 %cv9619, ptr %slot1779, align 8
  %v9620 = load i32, ptr %slot1779, align 8
  %cv9621 = zext i32 %v9620 to i64
  %cond9622 = icmp ne i64 %cv9621, 0
  br i1 %cond9622, label %bb_rcgnn2294, label %bb_rcgdone2294
bb_rcgnn2294:
  %v9623 = load i64, ptr %slot1778, align 8
  %op9624 = sub i64 %v9623, 16
  store i64 %op9624, ptr %slot1780, align 8
  %v9625 = load i64, ptr %slot1778, align 8
  %p9626 = inttoptr i64 %v9625 to ptr
  %rgep9627 = getelementptr i8, ptr %p9626, i64 -16
  %ld9628 = load i64, ptr %rgep9627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9628, ptr %slot1781, align 8
  %v9629 = load i64, ptr %slot1781, align 8
  %op9630 = and i64 %v9629, 4611686018427387906
  store i64 %op9630, ptr %slot1782, align 8
  %v9631 = load i64, ptr %slot1782, align 8
  %cmp9632 = icmp ne i64 %v9631, 0
  %cv9633 = zext i1 %cmp9632 to i32
  store i32 %cv9633, ptr %slot1783, align 8
  %v9634 = load i32, ptr %slot1783, align 8
  %cv9635 = zext i32 %v9634 to i64
  %cond9636 = icmp ne i64 %cv9635, 0
  br i1 %cond9636, label %bb_rcgclear2294, label %bb_rcgcounted2294
bb_rcgcounted2294:
  %v9637 = load i64, ptr %slot1778, align 8
  %op9638 = sub i64 %v9637, 24
  store i64 %op9638, ptr %slot1784, align 8
  %v9639 = load i64, ptr %slot1778, align 8
  %p9640 = inttoptr i64 %v9639 to ptr
  %rgep9641 = getelementptr i8, ptr %p9640, i64 -24
  %ld9642 = load i64, ptr %rgep9641, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9642, ptr %slot1785, align 8
  %v9643 = load i64, ptr %slot1785, align 8
  %op9644 = sub i64 %v9643, 1
  store i64 %op9644, ptr %slot1786, align 8
  %v9645 = load i64, ptr %slot1786, align 8
  %cmp9646 = icmp eq i64 %v9645, 0
  %cv9647 = zext i1 %cmp9646 to i32
  store i32 %cv9647, ptr %slot1787, align 8
  %v9648 = load i32, ptr %slot1787, align 8
  %cv9649 = zext i32 %v9648 to i64
  %cond9650 = icmp ne i64 %cv9649, 0
  br i1 %cond9650, label %bb_rcglast2294, label %bb_rcgdec2294
bb_rcglast2294:
  %v9651 = load i64, ptr %slot1778, align 8
  %op9652 = sub i64 %v9651, 32
  store i64 %op9652, ptr %slot1788, align 8
  %v9653 = load i64, ptr %slot1778, align 8
  %p9654 = inttoptr i64 %v9653 to ptr
  %rgep9655 = getelementptr i8, ptr %p9654, i64 -32
  %ld9656 = load i64, ptr %rgep9655, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9656, ptr %slot1789, align 8
  %v9657 = load i64, ptr %slot1789, align 8
  %cmp9658 = icmp ne i64 %v9657, 0
  %cv9659 = zext i1 %cmp9658 to i32
  store i32 %cv9659, ptr %slot1790, align 8
  %v9660 = load i32, ptr %slot1790, align 8
  %cv9661 = zext i32 %v9660 to i64
  %cond9662 = icmp ne i64 %cv9661, 0
  br i1 %cond9662, label %bb_rcgdec2294, label %bb_rcgslow2294
bb_rcgslow2294:
  %v9663 = load i64, ptr %slot1777, align 8
  %v9664 = load i64, ptr %slot1774, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v9663, i64 %v9664) nomerge, !dbg !166
  br label %bb_rcgdone2294
bb_rcgdec2294:
  %v9665 = load i64, ptr %slot1786, align 8
  %v9666 = load i64, ptr %slot1778, align 8
  %p9667 = inttoptr i64 %v9666 to ptr
  %rgep9668 = getelementptr i8, ptr %p9667, i64 -24
  store i64 %v9665, ptr %rgep9668, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2294
bb_rcgclear2294:
  %v9669 = load i64, ptr %slot1774, align 8
  %p9670 = inttoptr i64 %v9669 to ptr
  store i64 0, ptr %p9670, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2294
bb_rcgdone2294:
  br label %bb_rcslotdone2278
bb_rcslotowner2278:
  %v9671 = load i64, ptr %slot31, align 8
  store i64 %v9671, ptr %slot1791, align 8
  %v9672 = load i64, ptr %slot1774, align 8
  %p9673 = inttoptr i64 %v9672 to ptr
  %ld9674 = load i64, ptr %p9673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9674, ptr %slot1792, align 8
  %v9675 = load i64, ptr %slot1792, align 8
  %cmp9676 = icmp ne i64 %v9675, 0
  %cv9677 = zext i1 %cmp9676 to i32
  store i32 %cv9677, ptr %slot1793, align 8
  %v9678 = load i32, ptr %slot1793, align 8
  %cv9679 = zext i32 %v9678 to i64
  %cond9680 = icmp ne i64 %cv9679, 0
  br i1 %cond9680, label %bb_rcgnn2309, label %bb_rcgdone2309
bb_rcgnn2309:
  %v9681 = load i64, ptr %slot1792, align 8
  %op9682 = sub i64 %v9681, 16
  store i64 %op9682, ptr %slot1794, align 8
  %v9683 = load i64, ptr %slot1792, align 8
  %p9684 = inttoptr i64 %v9683 to ptr
  %rgep9685 = getelementptr i8, ptr %p9684, i64 -16
  %ld9686 = load i64, ptr %rgep9685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9686, ptr %slot1795, align 8
  %v9687 = load i64, ptr %slot1795, align 8
  %op9688 = and i64 %v9687, 4611686018427387906
  store i64 %op9688, ptr %slot1796, align 8
  %v9689 = load i64, ptr %slot1796, align 8
  %cmp9690 = icmp ne i64 %v9689, 0
  %cv9691 = zext i1 %cmp9690 to i32
  store i32 %cv9691, ptr %slot1797, align 8
  %v9692 = load i32, ptr %slot1797, align 8
  %cv9693 = zext i32 %v9692 to i64
  %cond9694 = icmp ne i64 %cv9693, 0
  br i1 %cond9694, label %bb_rcgclear2309, label %bb_rcgcounted2309
bb_rcgcounted2309:
  %v9695 = load i64, ptr %slot1792, align 8
  %op9696 = sub i64 %v9695, 32
  store i64 %op9696, ptr %slot1798, align 8
  %v9697 = load i64, ptr %slot1792, align 8
  %p9698 = inttoptr i64 %v9697 to ptr
  %rgep9699 = getelementptr i8, ptr %p9698, i64 -32
  %ld9700 = load i64, ptr %rgep9699, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9700, ptr %slot1799, align 8
  %v9701 = load i64, ptr %slot1799, align 8
  %op9702 = sub i64 %v9701, 1
  store i64 %op9702, ptr %slot1800, align 8
  %v9703 = load i64, ptr %slot1800, align 8
  %cmp9704 = icmp eq i64 %v9703, 0
  %cv9705 = zext i1 %cmp9704 to i32
  store i32 %cv9705, ptr %slot1801, align 8
  %v9706 = load i32, ptr %slot1801, align 8
  %cv9707 = zext i32 %v9706 to i64
  %cond9708 = icmp ne i64 %cv9707, 0
  br i1 %cond9708, label %bb_rcglast2309, label %bb_rcgdec2309
bb_rcglast2309:
  %v9709 = load i64, ptr %slot1792, align 8
  %op9710 = sub i64 %v9709, 24
  store i64 %op9710, ptr %slot1802, align 8
  %v9711 = load i64, ptr %slot1792, align 8
  %p9712 = inttoptr i64 %v9711 to ptr
  %rgep9713 = getelementptr i8, ptr %p9712, i64 -24
  %ld9714 = load i64, ptr %rgep9713, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9714, ptr %slot1803, align 8
  %v9715 = load i64, ptr %slot1803, align 8
  %cmp9716 = icmp ne i64 %v9715, 0
  %cv9717 = zext i1 %cmp9716 to i32
  store i32 %cv9717, ptr %slot1804, align 8
  %v9718 = load i32, ptr %slot1804, align 8
  %cv9719 = zext i32 %v9718 to i64
  %cond9720 = icmp ne i64 %cv9719, 0
  br i1 %cond9720, label %bb_rcgdec2309, label %bb_rcgslow2309
bb_rcgslow2309:
  %v9721 = load i64, ptr %slot1791, align 8
  %v9722 = load i64, ptr %slot1774, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v9721, i64 %v9722) nomerge, !dbg !166
  br label %bb_rcgdone2309
bb_rcgdec2309:
  %v9723 = load i64, ptr %slot1800, align 8
  %v9724 = load i64, ptr %slot1792, align 8
  %p9725 = inttoptr i64 %v9724 to ptr
  %rgep9726 = getelementptr i8, ptr %p9725, i64 -32
  store i64 %v9723, ptr %rgep9726, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2309
bb_rcgclear2309:
  %v9727 = load i64, ptr %slot1774, align 8
  %p9728 = inttoptr i64 %v9727 to ptr
  store i64 0, ptr %p9728, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2309
bb_rcgdone2309:
  br label %bb_rcslotdone2278
bb_rcslotdone2278:
  %v9729 = load i64, ptr %slot7, align 8
  %p9730 = inttoptr i64 %v9729 to ptr
  %ld9731 = load i32, ptr %p9730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9731, ptr %slot1805, align 8
  %v9732 = load i32, ptr %slot1805, align 8
  %cv9733 = zext i32 %v9732 to i64
  %cond9734 = icmp ne i64 %cv9733, 0
  br i1 %cond9734, label %bb_rcslotdrop2315, label %bb_rcslotdone2315
bb_rcslotdrop2315:
  %v9735 = load i64, ptr %slot7, align 8
  %p9736 = inttoptr i64 %v9735 to ptr
  store i32 0, ptr %p9736, align 4, !alias.scope !3, !noalias !4
  %v9737 = load i64, ptr %slot23, align 8
  store i64 %v9737, ptr %slot1806, align 8
  %v9738 = load i64, ptr %slot8, align 8
  %p9739 = inttoptr i64 %v9738 to ptr
  %ld9740 = load i32, ptr %p9739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9740, ptr %slot1807, align 8
  %v9741 = load i32, ptr %slot1807, align 8
  %op9742 = and i32 %v9741, 28
  store i32 %op9742, ptr %slot1808, align 8
  %v9743 = load i32, ptr %slot1808, align 8
  %cv9744 = zext i32 %v9743 to i64
  %cond9745 = icmp ne i64 %cv9744, 0
  br i1 %cond9745, label %bb_rcslotrole2315, label %bb_rcslotowner2315
bb_rcslotrole2315:
  %v9746 = load i64, ptr %slot31, align 8
  store i64 %v9746, ptr %slot1809, align 8
  %v9747 = load i64, ptr %slot1806, align 8
  %p9748 = inttoptr i64 %v9747 to ptr
  %ld9749 = load i64, ptr %p9748, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9749, ptr %slot1810, align 8
  %v9750 = load i64, ptr %slot1810, align 8
  %cmp9751 = icmp ne i64 %v9750, 0
  %cv9752 = zext i1 %cmp9751 to i32
  store i32 %cv9752, ptr %slot1811, align 8
  %v9753 = load i32, ptr %slot1811, align 8
  %cv9754 = zext i32 %v9753 to i64
  %cond9755 = icmp ne i64 %cv9754, 0
  br i1 %cond9755, label %bb_rcgnn2331, label %bb_rcgdone2331
bb_rcgnn2331:
  %v9756 = load i64, ptr %slot1810, align 8
  %op9757 = sub i64 %v9756, 16
  store i64 %op9757, ptr %slot1812, align 8
  %v9758 = load i64, ptr %slot1810, align 8
  %p9759 = inttoptr i64 %v9758 to ptr
  %rgep9760 = getelementptr i8, ptr %p9759, i64 -16
  %ld9761 = load i64, ptr %rgep9760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9761, ptr %slot1813, align 8
  %v9762 = load i64, ptr %slot1813, align 8
  %op9763 = and i64 %v9762, 4611686018427387906
  store i64 %op9763, ptr %slot1814, align 8
  %v9764 = load i64, ptr %slot1814, align 8
  %cmp9765 = icmp ne i64 %v9764, 0
  %cv9766 = zext i1 %cmp9765 to i32
  store i32 %cv9766, ptr %slot1815, align 8
  %v9767 = load i32, ptr %slot1815, align 8
  %cv9768 = zext i32 %v9767 to i64
  %cond9769 = icmp ne i64 %cv9768, 0
  br i1 %cond9769, label %bb_rcgclear2331, label %bb_rcgcounted2331
bb_rcgcounted2331:
  %v9770 = load i64, ptr %slot1810, align 8
  %op9771 = sub i64 %v9770, 24
  store i64 %op9771, ptr %slot1816, align 8
  %v9772 = load i64, ptr %slot1810, align 8
  %p9773 = inttoptr i64 %v9772 to ptr
  %rgep9774 = getelementptr i8, ptr %p9773, i64 -24
  %ld9775 = load i64, ptr %rgep9774, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9775, ptr %slot1817, align 8
  %v9776 = load i64, ptr %slot1817, align 8
  %op9777 = sub i64 %v9776, 1
  store i64 %op9777, ptr %slot1818, align 8
  %v9778 = load i64, ptr %slot1818, align 8
  %cmp9779 = icmp eq i64 %v9778, 0
  %cv9780 = zext i1 %cmp9779 to i32
  store i32 %cv9780, ptr %slot1819, align 8
  %v9781 = load i32, ptr %slot1819, align 8
  %cv9782 = zext i32 %v9781 to i64
  %cond9783 = icmp ne i64 %cv9782, 0
  br i1 %cond9783, label %bb_rcglast2331, label %bb_rcgdec2331
bb_rcglast2331:
  %v9784 = load i64, ptr %slot1810, align 8
  %op9785 = sub i64 %v9784, 32
  store i64 %op9785, ptr %slot1820, align 8
  %v9786 = load i64, ptr %slot1810, align 8
  %p9787 = inttoptr i64 %v9786 to ptr
  %rgep9788 = getelementptr i8, ptr %p9787, i64 -32
  %ld9789 = load i64, ptr %rgep9788, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9789, ptr %slot1821, align 8
  %v9790 = load i64, ptr %slot1821, align 8
  %cmp9791 = icmp ne i64 %v9790, 0
  %cv9792 = zext i1 %cmp9791 to i32
  store i32 %cv9792, ptr %slot1822, align 8
  %v9793 = load i32, ptr %slot1822, align 8
  %cv9794 = zext i32 %v9793 to i64
  %cond9795 = icmp ne i64 %cv9794, 0
  br i1 %cond9795, label %bb_rcgdec2331, label %bb_rcgslow2331
bb_rcgslow2331:
  %v9796 = load i64, ptr %slot1809, align 8
  %v9797 = load i64, ptr %slot1806, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v9796, i64 %v9797) nomerge, !dbg !166
  br label %bb_rcgdone2331
bb_rcgdec2331:
  %v9798 = load i64, ptr %slot1818, align 8
  %v9799 = load i64, ptr %slot1810, align 8
  %p9800 = inttoptr i64 %v9799 to ptr
  %rgep9801 = getelementptr i8, ptr %p9800, i64 -24
  store i64 %v9798, ptr %rgep9801, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2331
bb_rcgclear2331:
  %v9802 = load i64, ptr %slot1806, align 8
  %p9803 = inttoptr i64 %v9802 to ptr
  store i64 0, ptr %p9803, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2331
bb_rcgdone2331:
  br label %bb_rcslotdone2315
bb_rcslotowner2315:
  %v9804 = load i64, ptr %slot31, align 8
  store i64 %v9804, ptr %slot1823, align 8
  %v9805 = load i64, ptr %slot1806, align 8
  %p9806 = inttoptr i64 %v9805 to ptr
  %ld9807 = load i64, ptr %p9806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9807, ptr %slot1824, align 8
  %v9808 = load i64, ptr %slot1824, align 8
  %cmp9809 = icmp ne i64 %v9808, 0
  %cv9810 = zext i1 %cmp9809 to i32
  store i32 %cv9810, ptr %slot1825, align 8
  %v9811 = load i32, ptr %slot1825, align 8
  %cv9812 = zext i32 %v9811 to i64
  %cond9813 = icmp ne i64 %cv9812, 0
  br i1 %cond9813, label %bb_rcgnn2346, label %bb_rcgdone2346
bb_rcgnn2346:
  %v9814 = load i64, ptr %slot1824, align 8
  %op9815 = sub i64 %v9814, 16
  store i64 %op9815, ptr %slot1826, align 8
  %v9816 = load i64, ptr %slot1824, align 8
  %p9817 = inttoptr i64 %v9816 to ptr
  %rgep9818 = getelementptr i8, ptr %p9817, i64 -16
  %ld9819 = load i64, ptr %rgep9818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9819, ptr %slot1827, align 8
  %v9820 = load i64, ptr %slot1827, align 8
  %op9821 = and i64 %v9820, 4611686018427387906
  store i64 %op9821, ptr %slot1828, align 8
  %v9822 = load i64, ptr %slot1828, align 8
  %cmp9823 = icmp ne i64 %v9822, 0
  %cv9824 = zext i1 %cmp9823 to i32
  store i32 %cv9824, ptr %slot1829, align 8
  %v9825 = load i32, ptr %slot1829, align 8
  %cv9826 = zext i32 %v9825 to i64
  %cond9827 = icmp ne i64 %cv9826, 0
  br i1 %cond9827, label %bb_rcgclear2346, label %bb_rcgcounted2346
bb_rcgcounted2346:
  %v9828 = load i64, ptr %slot1824, align 8
  %op9829 = sub i64 %v9828, 32
  store i64 %op9829, ptr %slot1830, align 8
  %v9830 = load i64, ptr %slot1824, align 8
  %p9831 = inttoptr i64 %v9830 to ptr
  %rgep9832 = getelementptr i8, ptr %p9831, i64 -32
  %ld9833 = load i64, ptr %rgep9832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9833, ptr %slot1831, align 8
  %v9834 = load i64, ptr %slot1831, align 8
  %op9835 = sub i64 %v9834, 1
  store i64 %op9835, ptr %slot1832, align 8
  %v9836 = load i64, ptr %slot1832, align 8
  %cmp9837 = icmp eq i64 %v9836, 0
  %cv9838 = zext i1 %cmp9837 to i32
  store i32 %cv9838, ptr %slot1833, align 8
  %v9839 = load i32, ptr %slot1833, align 8
  %cv9840 = zext i32 %v9839 to i64
  %cond9841 = icmp ne i64 %cv9840, 0
  br i1 %cond9841, label %bb_rcglast2346, label %bb_rcgdec2346
bb_rcglast2346:
  %v9842 = load i64, ptr %slot1824, align 8
  %op9843 = sub i64 %v9842, 24
  store i64 %op9843, ptr %slot1834, align 8
  %v9844 = load i64, ptr %slot1824, align 8
  %p9845 = inttoptr i64 %v9844 to ptr
  %rgep9846 = getelementptr i8, ptr %p9845, i64 -24
  %ld9847 = load i64, ptr %rgep9846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9847, ptr %slot1835, align 8
  %v9848 = load i64, ptr %slot1835, align 8
  %cmp9849 = icmp ne i64 %v9848, 0
  %cv9850 = zext i1 %cmp9849 to i32
  store i32 %cv9850, ptr %slot1836, align 8
  %v9851 = load i32, ptr %slot1836, align 8
  %cv9852 = zext i32 %v9851 to i64
  %cond9853 = icmp ne i64 %cv9852, 0
  br i1 %cond9853, label %bb_rcgdec2346, label %bb_rcgslow2346
bb_rcgslow2346:
  %v9854 = load i64, ptr %slot1823, align 8
  %v9855 = load i64, ptr %slot1806, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v9854, i64 %v9855) nomerge, !dbg !166
  br label %bb_rcgdone2346
bb_rcgdec2346:
  %v9856 = load i64, ptr %slot1832, align 8
  %v9857 = load i64, ptr %slot1824, align 8
  %p9858 = inttoptr i64 %v9857 to ptr
  %rgep9859 = getelementptr i8, ptr %p9858, i64 -32
  store i64 %v9856, ptr %rgep9859, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2346
bb_rcgclear2346:
  %v9860 = load i64, ptr %slot1806, align 8
  %p9861 = inttoptr i64 %v9860 to ptr
  store i64 0, ptr %p9861, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2346
bb_rcgdone2346:
  br label %bb_rcslotdone2315
bb_rcslotdone2315:
  %v9862 = load i64, ptr %slot5, align 8
  %p9863 = inttoptr i64 %v9862 to ptr
  %ld9864 = load i32, ptr %p9863, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9864, ptr %slot1837, align 8
  %v9865 = load i32, ptr %slot1837, align 8
  %cv9866 = zext i32 %v9865 to i64
  %cond9867 = icmp ne i64 %cv9866, 0
  br i1 %cond9867, label %bb_rcslotdrop2352, label %bb_rcslotdone2352
bb_rcslotdrop2352:
  %v9868 = load i64, ptr %slot5, align 8
  %p9869 = inttoptr i64 %v9868 to ptr
  store i32 0, ptr %p9869, align 4, !alias.scope !3, !noalias !4
  %v9870 = load i64, ptr %slot22, align 8
  store i64 %v9870, ptr %slot1838, align 8
  %v9871 = load i64, ptr %slot6, align 8
  %p9872 = inttoptr i64 %v9871 to ptr
  %ld9873 = load i32, ptr %p9872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9873, ptr %slot1839, align 8
  %v9874 = load i32, ptr %slot1839, align 8
  %op9875 = and i32 %v9874, 28
  store i32 %op9875, ptr %slot1840, align 8
  %v9876 = load i32, ptr %slot1840, align 8
  %cv9877 = zext i32 %v9876 to i64
  %cond9878 = icmp ne i64 %cv9877, 0
  br i1 %cond9878, label %bb_rcslotrole2352, label %bb_rcslotowner2352
bb_rcslotrole2352:
  %v9879 = load i64, ptr %slot31, align 8
  store i64 %v9879, ptr %slot1841, align 8
  %v9880 = load i64, ptr %slot1838, align 8
  %p9881 = inttoptr i64 %v9880 to ptr
  %ld9882 = load i64, ptr %p9881, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9882, ptr %slot1842, align 8
  %v9883 = load i64, ptr %slot1842, align 8
  %cmp9884 = icmp ne i64 %v9883, 0
  %cv9885 = zext i1 %cmp9884 to i32
  store i32 %cv9885, ptr %slot1843, align 8
  %v9886 = load i32, ptr %slot1843, align 8
  %cv9887 = zext i32 %v9886 to i64
  %cond9888 = icmp ne i64 %cv9887, 0
  br i1 %cond9888, label %bb_rcgnn2368, label %bb_rcgdone2368
bb_rcgnn2368:
  %v9889 = load i64, ptr %slot1842, align 8
  %op9890 = sub i64 %v9889, 16
  store i64 %op9890, ptr %slot1844, align 8
  %v9891 = load i64, ptr %slot1842, align 8
  %p9892 = inttoptr i64 %v9891 to ptr
  %rgep9893 = getelementptr i8, ptr %p9892, i64 -16
  %ld9894 = load i64, ptr %rgep9893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9894, ptr %slot1845, align 8
  %v9895 = load i64, ptr %slot1845, align 8
  %op9896 = and i64 %v9895, 4611686018427387906
  store i64 %op9896, ptr %slot1846, align 8
  %v9897 = load i64, ptr %slot1846, align 8
  %cmp9898 = icmp ne i64 %v9897, 0
  %cv9899 = zext i1 %cmp9898 to i32
  store i32 %cv9899, ptr %slot1847, align 8
  %v9900 = load i32, ptr %slot1847, align 8
  %cv9901 = zext i32 %v9900 to i64
  %cond9902 = icmp ne i64 %cv9901, 0
  br i1 %cond9902, label %bb_rcgclear2368, label %bb_rcgcounted2368
bb_rcgcounted2368:
  %v9903 = load i64, ptr %slot1842, align 8
  %op9904 = sub i64 %v9903, 24
  store i64 %op9904, ptr %slot1848, align 8
  %v9905 = load i64, ptr %slot1842, align 8
  %p9906 = inttoptr i64 %v9905 to ptr
  %rgep9907 = getelementptr i8, ptr %p9906, i64 -24
  %ld9908 = load i64, ptr %rgep9907, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9908, ptr %slot1849, align 8
  %v9909 = load i64, ptr %slot1849, align 8
  %op9910 = sub i64 %v9909, 1
  store i64 %op9910, ptr %slot1850, align 8
  %v9911 = load i64, ptr %slot1850, align 8
  %cmp9912 = icmp eq i64 %v9911, 0
  %cv9913 = zext i1 %cmp9912 to i32
  store i32 %cv9913, ptr %slot1851, align 8
  %v9914 = load i32, ptr %slot1851, align 8
  %cv9915 = zext i32 %v9914 to i64
  %cond9916 = icmp ne i64 %cv9915, 0
  br i1 %cond9916, label %bb_rcglast2368, label %bb_rcgdec2368
bb_rcglast2368:
  %v9917 = load i64, ptr %slot1842, align 8
  %op9918 = sub i64 %v9917, 32
  store i64 %op9918, ptr %slot1852, align 8
  %v9919 = load i64, ptr %slot1842, align 8
  %p9920 = inttoptr i64 %v9919 to ptr
  %rgep9921 = getelementptr i8, ptr %p9920, i64 -32
  %ld9922 = load i64, ptr %rgep9921, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9922, ptr %slot1853, align 8
  %v9923 = load i64, ptr %slot1853, align 8
  %cmp9924 = icmp ne i64 %v9923, 0
  %cv9925 = zext i1 %cmp9924 to i32
  store i32 %cv9925, ptr %slot1854, align 8
  %v9926 = load i32, ptr %slot1854, align 8
  %cv9927 = zext i32 %v9926 to i64
  %cond9928 = icmp ne i64 %cv9927, 0
  br i1 %cond9928, label %bb_rcgdec2368, label %bb_rcgslow2368
bb_rcgslow2368:
  %v9929 = load i64, ptr %slot1841, align 8
  %v9930 = load i64, ptr %slot1838, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v9929, i64 %v9930) nomerge, !dbg !166
  br label %bb_rcgdone2368
bb_rcgdec2368:
  %v9931 = load i64, ptr %slot1850, align 8
  %v9932 = load i64, ptr %slot1842, align 8
  %p9933 = inttoptr i64 %v9932 to ptr
  %rgep9934 = getelementptr i8, ptr %p9933, i64 -24
  store i64 %v9931, ptr %rgep9934, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2368
bb_rcgclear2368:
  %v9935 = load i64, ptr %slot1838, align 8
  %p9936 = inttoptr i64 %v9935 to ptr
  store i64 0, ptr %p9936, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2368
bb_rcgdone2368:
  br label %bb_rcslotdone2352
bb_rcslotowner2352:
  %v9937 = load i64, ptr %slot31, align 8
  store i64 %v9937, ptr %slot1855, align 8
  %v9938 = load i64, ptr %slot1838, align 8
  %p9939 = inttoptr i64 %v9938 to ptr
  %ld9940 = load i64, ptr %p9939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9940, ptr %slot1856, align 8
  %v9941 = load i64, ptr %slot1856, align 8
  %cmp9942 = icmp ne i64 %v9941, 0
  %cv9943 = zext i1 %cmp9942 to i32
  store i32 %cv9943, ptr %slot1857, align 8
  %v9944 = load i32, ptr %slot1857, align 8
  %cv9945 = zext i32 %v9944 to i64
  %cond9946 = icmp ne i64 %cv9945, 0
  br i1 %cond9946, label %bb_rcgnn2383, label %bb_rcgdone2383
bb_rcgnn2383:
  %v9947 = load i64, ptr %slot1856, align 8
  %op9948 = sub i64 %v9947, 16
  store i64 %op9948, ptr %slot1858, align 8
  %v9949 = load i64, ptr %slot1856, align 8
  %p9950 = inttoptr i64 %v9949 to ptr
  %rgep9951 = getelementptr i8, ptr %p9950, i64 -16
  %ld9952 = load i64, ptr %rgep9951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9952, ptr %slot1859, align 8
  %v9953 = load i64, ptr %slot1859, align 8
  %op9954 = and i64 %v9953, 4611686018427387906
  store i64 %op9954, ptr %slot1860, align 8
  %v9955 = load i64, ptr %slot1860, align 8
  %cmp9956 = icmp ne i64 %v9955, 0
  %cv9957 = zext i1 %cmp9956 to i32
  store i32 %cv9957, ptr %slot1861, align 8
  %v9958 = load i32, ptr %slot1861, align 8
  %cv9959 = zext i32 %v9958 to i64
  %cond9960 = icmp ne i64 %cv9959, 0
  br i1 %cond9960, label %bb_rcgclear2383, label %bb_rcgcounted2383
bb_rcgcounted2383:
  %v9961 = load i64, ptr %slot1856, align 8
  %op9962 = sub i64 %v9961, 32
  store i64 %op9962, ptr %slot1862, align 8
  %v9963 = load i64, ptr %slot1856, align 8
  %p9964 = inttoptr i64 %v9963 to ptr
  %rgep9965 = getelementptr i8, ptr %p9964, i64 -32
  %ld9966 = load i64, ptr %rgep9965, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9966, ptr %slot1863, align 8
  %v9967 = load i64, ptr %slot1863, align 8
  %op9968 = sub i64 %v9967, 1
  store i64 %op9968, ptr %slot1864, align 8
  %v9969 = load i64, ptr %slot1864, align 8
  %cmp9970 = icmp eq i64 %v9969, 0
  %cv9971 = zext i1 %cmp9970 to i32
  store i32 %cv9971, ptr %slot1865, align 8
  %v9972 = load i32, ptr %slot1865, align 8
  %cv9973 = zext i32 %v9972 to i64
  %cond9974 = icmp ne i64 %cv9973, 0
  br i1 %cond9974, label %bb_rcglast2383, label %bb_rcgdec2383
bb_rcglast2383:
  %v9975 = load i64, ptr %slot1856, align 8
  %op9976 = sub i64 %v9975, 24
  store i64 %op9976, ptr %slot1866, align 8
  %v9977 = load i64, ptr %slot1856, align 8
  %p9978 = inttoptr i64 %v9977 to ptr
  %rgep9979 = getelementptr i8, ptr %p9978, i64 -24
  %ld9980 = load i64, ptr %rgep9979, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9980, ptr %slot1867, align 8
  %v9981 = load i64, ptr %slot1867, align 8
  %cmp9982 = icmp ne i64 %v9981, 0
  %cv9983 = zext i1 %cmp9982 to i32
  store i32 %cv9983, ptr %slot1868, align 8
  %v9984 = load i32, ptr %slot1868, align 8
  %cv9985 = zext i32 %v9984 to i64
  %cond9986 = icmp ne i64 %cv9985, 0
  br i1 %cond9986, label %bb_rcgdec2383, label %bb_rcgslow2383
bb_rcgslow2383:
  %v9987 = load i64, ptr %slot1855, align 8
  %v9988 = load i64, ptr %slot1838, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v9987, i64 %v9988) nomerge, !dbg !166
  br label %bb_rcgdone2383
bb_rcgdec2383:
  %v9989 = load i64, ptr %slot1864, align 8
  %v9990 = load i64, ptr %slot1856, align 8
  %p9991 = inttoptr i64 %v9990 to ptr
  %rgep9992 = getelementptr i8, ptr %p9991, i64 -32
  store i64 %v9989, ptr %rgep9992, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2383
bb_rcgclear2383:
  %v9993 = load i64, ptr %slot1838, align 8
  %p9994 = inttoptr i64 %v9993 to ptr
  store i64 0, ptr %p9994, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2383
bb_rcgdone2383:
  br label %bb_rcslotdone2352
bb_rcslotdone2352:
  %v9995 = load i64, ptr %slot1740, align 8
  ret i64 %v9995
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_1d5aee2355887a6bff8fa5a7e568dd7aa80ffab8e6e5a5e74169985e9b588862 = external global i8, align 8
@myl_lit_3e0f7c480fb396db96bccf46cda95f243fa43708fba20c82ddd7533a5f278861 = external global i8, align 8
@myl_lit_651dfa874c87674e57d05784fbb331bf215d6ec2b7d4c57db6383d02b47d316a = external global i8, align 8
@myl_lit_969454b6011418fe25ac5bacf7816bad5d3fa5fe2b6de6485748b195f0f1c065 = external global i8, align 8
@myl_lit_bd90ef796306d9e474feb3d6510532661f5ac29d8bd5c1fff372bb5602cd80af = external global i8, align 8
@myl_lit_c24298efef9d84eab8d1ecb612ef258e35c6697e067d3770527afc0b5af176f8 = external global i8, align 8
@myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b = external global i8, align 8
@myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_e3f3f8852ef98dc490bd8fc3c4d74b40aa60caff690c4ee01a803d86d012a05b(i64, i64)
declare ptr @myl_native_bytes_encode(ptr, ptr)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare ptr @myl_native_text_join(ptr, ptr, ptr)
declare ptr @myl_native_text_scalar(ptr, ptr, i32)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64, i64)
declare i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64, i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_18a4e3027b0a31a21c52233577ff295f0b4382661cfec980a166384d013095b7", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_18a4e3027b0a31a21c52233577ff295f0b4382661cfec980a166384d013095b7", linkageName: "myl_f_18a4e3027b0a31a21c52233577ff295f0b4382661cfec980a166384d013095b7", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2037020977724253236, i64 0, !"myl_f_18a4e3027b0a31a21c52233577ff295f0b4382661cfec980a166384d013095b7"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!122 = !DILocation(line: 11, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!124 = !DILocation(line: 13, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!126 = !DILocation(line: 16, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!130 = !DILocation(line: 20, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!132 = !DILocation(line: 23, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!134 = !DILocation(line: 24, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!136 = !DILocation(line: 25, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!138 = !DILocation(line: 28, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!140 = !DILocation(line: 31, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!142 = !DILocation(line: 32, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!144 = !DILocation(line: 33, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!146 = !DILocation(line: 36, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!148 = !DILocation(line: 39, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!150 = !DILocation(line: 40, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!152 = !DILocation(line: 41, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!154 = !DILocation(line: 44, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!156 = !DILocation(line: 47, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!158 = !DILocation(line: 48, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!160 = !DILocation(line: 51, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!162 = !DILocation(line: 52, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!164 = !DILocation(line: 53, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!166 = !DILocation(line: 54, column: 0, scope: !167)
