target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v70 = load i64, ptr %slot1, align 8
  %op71 = add i64 %v70, 32
  store i64 %op71, ptr %slot3, align 8
  %mem72 = alloca i8, i64 40, align 8
  %ptr73 = ptrtoint ptr %mem72 to i64
  store i64 %ptr73, ptr %slot4, align 8
  %mem74 = alloca i8, i64 8, align 8
  %ptr75 = ptrtoint ptr %mem74 to i64
  store i64 %ptr75, ptr %slot5, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot6, align 8
  %mem78 = alloca i8, i64 312, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot7, align 8
  %mem80 = alloca i8, i64 8, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot8, align 8
  %mem82 = alloca i8, i64 8, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot9, align 8
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot10, align 8
  %mem86 = alloca i8, i64 8, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot11, align 8
  %mem88 = alloca i8, i64 8, align 8
  %ptr89 = ptrtoint ptr %mem88 to i64
  store i64 %ptr89, ptr %slot12, align 8
  %v90 = load i64, ptr %slot9, align 8
  %p91 = inttoptr i64 %v90 to ptr
  store i64 0, ptr %p91, align 8, !alias.scope !3, !noalias !4
  %v92 = load i64, ptr %slot2, align 8
  %v93 = load i64, ptr %slot8, align 8
  %p94 = inttoptr i64 %v93 to ptr
  store i64 %v92, ptr %p94, align 8, !alias.scope !3, !noalias !4
  %v95 = load i64, ptr %slot1, align 8
  %p96 = inttoptr i64 %v95 to ptr
  %call97 = call ptr @myl_qbe_heap(ptr %p96) nomerge, !dbg !110
  %calladdr98 = ptrtoint ptr %call97 to i64
  store i64 %calladdr98, ptr %slot13, align 8
  %v99 = load i64, ptr %slot1, align 8
  %p100 = inttoptr i64 %v99 to ptr
  %call101 = call i64 @myl_qbe_region_mark(ptr %p100) nomerge, !dbg !110
  store i64 %call101, ptr %slot14, align 8
  %v102 = load i64, ptr %slot5, align 8
  %p103 = inttoptr i64 %v102 to ptr
  store i32 0, ptr %p103, align 4, !alias.scope !3, !noalias !4
  %v104 = load i64, ptr %slot6, align 8
  %p105 = inttoptr i64 %v104 to ptr
  store i32 0, ptr %p105, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v106 = load i64, ptr %slot8, align 8
  %p107 = inttoptr i64 %v106 to ptr
  %ld108 = load i64, ptr %p107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld108, ptr %slot15, align 8
  %v109 = load i64, ptr %slot15, align 8
  %v110 = load i64, ptr %slot11, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot11, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld114, ptr %slot16, align 8
  %v115 = load i64, ptr %slot16, align 8
  %op116 = add i64 %v115, 256
  store i64 %op116, ptr %slot17, align 8
  %v117 = load i64, ptr %slot17, align 8
  %p118 = inttoptr i64 %v117 to ptr
  %ld119 = load i64, ptr %p118, align 8, !alias.scope !4, !noalias !3
  store i64 %ld119, ptr %slot18, align 8
  %v120 = load i64, ptr %slot18, align 8
  %v121 = load i64, ptr %slot11, align 8
  %p122 = inttoptr i64 %v121 to ptr
  store i64 %v120, ptr %p122, align 8, !alias.scope !3, !noalias !4
  %v123 = load i64, ptr %slot11, align 8
  %p124 = inttoptr i64 %v123 to ptr
  %ld125 = load i64, ptr %p124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld125, ptr %slot19, align 8
  %v126 = load i64, ptr %slot19, align 8
  %v127 = load i64, ptr %slot9, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 %v126, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot8, align 8
  %p130 = inttoptr i64 %v129 to ptr
  %ld131 = load i64, ptr %p130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld131, ptr %slot20, align 8
  %v132 = load i64, ptr %slot20, align 8
  %v133 = load i64, ptr %slot11, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i64 %v132, ptr %p134, align 8, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot11, align 8
  %p136 = inttoptr i64 %v135 to ptr
  %ld137 = load i64, ptr %p136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld137, ptr %slot21, align 8
  %v138 = load i64, ptr %slot21, align 8
  %op139 = add i64 %v138, 264
  store i64 %op139, ptr %slot22, align 8
  %v140 = load i64, ptr %slot22, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i64, ptr %p141, align 8, !alias.scope !4, !noalias !3
  store i64 %ld142, ptr %slot23, align 8
  %v143 = load i64, ptr %slot23, align 8
  %v144 = load i64, ptr %slot11, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 %v143, ptr %p145, align 8, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot11, align 8
  %p147 = inttoptr i64 %v146 to ptr
  %ld148 = load i64, ptr %p147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld148, ptr %slot24, align 8
  %v149 = load i64, ptr %slot24, align 8
  %v150 = load i64, ptr %slot10, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot10, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot25, align 8
  %v155 = load i64, ptr %slot25, align 8
  %v156 = load i64, ptr %slot11, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 %v155, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot12, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i64 0, ptr %p159, align 8, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot12, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ld162 = load i64, ptr %p161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld162, ptr %slot26, align 8
  %v163 = load i64, ptr %slot11, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld165, ptr %slot27, align 8
  %v166 = load i64, ptr %slot27, align 8
  %v167 = load i64, ptr %slot26, align 8
  %cmp168 = icmp slt i64 %v166, %v167
  %cv169 = zext i1 %cmp168 to i64
  store i64 %cv169, ptr %slot28, align 8
  %v170 = load i64, ptr %slot28, align 8
  %v171 = load i64, ptr %slot11, align 8
  %p172 = inttoptr i64 %v171 to ptr
  store i64 %v170, ptr %p172, align 8, !alias.scope !3, !noalias !4
  %v173 = load i64, ptr %slot11, align 8
  %p174 = inttoptr i64 %v173 to ptr
  %ld175 = load i64, ptr %p174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld175, ptr %slot29, align 8
  %v176 = load i64, ptr %slot29, align 8
  %cond177 = icmp ne i64 %v176, 0
  br i1 %cond177, label %bb_next35, label %bb_i15
bb_next35:
  %v178 = load i64, ptr %slot9, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot30, align 8
  %v181 = load i64, ptr %slot30, align 8
  %op182 = add i64 %v181, 0
  store i64 %op182, ptr %slot31, align 8
  %v183 = load i64, ptr %slot31, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i64, ptr %p184, align 8, !alias.scope !6, !noalias !7
  store i64 %ld185, ptr %slot32, align 8
  %v186 = load i64, ptr %slot32, align 8
  %v187 = load i64, ptr %slot11, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i64 %v186, ptr %p188, align 8, !alias.scope !3, !noalias !4
  %v189 = load i64, ptr %slot11, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %ld191 = load i64, ptr %p190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld191, ptr %slot33, align 8
  %v192 = load i64, ptr %slot33, align 8
  %cmp193 = icmp ugt i64 %v192, 9223372036854775807
  %cv194 = zext i1 %cmp193 to i64
  store i64 %cv194, ptr %slot34, align 8
  %v195 = load i64, ptr %slot34, align 8
  %cond196 = icmp ne i64 %v195, 0
  br i1 %cond196, label %bb_cast_overflow40, label %bb_cast_ok40
bb_cast_overflow40:
  %v197 = load i64, ptr %slot1, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %v199 = load i64, ptr %slot33, align 8
  call void @myl_qbe_fail_cast(ptr %p198, i64 %v199, i64 320) nomerge, !dbg !112
  unreachable
bb_cast_ok40:
  %v200 = load i64, ptr %slot33, align 8
  %v201 = load i64, ptr %slot11, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot10, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot35, align 8
  %v206 = load i64, ptr %slot35, align 8
  %v207 = load i64, ptr %slot12, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i64 %v206, ptr %p208, align 8, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot12, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i64, ptr %p210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld211, ptr %slot36, align 8
  %v212 = load i64, ptr %slot11, align 8
  %p213 = inttoptr i64 %v212 to ptr
  %ld214 = load i64, ptr %p213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld214, ptr %slot37, align 8
  %v215 = load i64, ptr %slot37, align 8
  %v216 = load i64, ptr %slot36, align 8
  %ovpair218 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v215, i64 %v216)
  %op217 = extractvalue { i64, i1 } %ovpair218, 0
  %ov219 = extractvalue { i64, i1 } %ovpair218, 1
  store i64 %op217, ptr %slot38, align 8
  %v220 = load i64, ptr %slot37, align 8
  %v221 = load i64, ptr %slot38, align 8
  %op222 = xor i64 %v220, %v221
  store i64 %op222, ptr %slot39, align 8
  %v223 = load i64, ptr %slot36, align 8
  %v224 = load i64, ptr %slot38, align 8
  %op225 = xor i64 %v223, %v224
  store i64 %op225, ptr %slot40, align 8
  %v226 = load i64, ptr %slot39, align 8
  %v227 = load i64, ptr %slot40, align 8
  %op228 = and i64 %v226, %v227
  store i64 %op228, ptr %slot41, align 8
  %cv229 = zext i1 %ov219 to i64
  store i64 %cv229, ptr %slot42, align 8
  %v230 = load i64, ptr %slot42, align 8
  %cond231 = icmp ne i64 %v230, 0
  br i1 %cond231, label %bb_overflow44, label %bb_checked44
bb_overflow44:
  %v232 = load i64, ptr %slot1, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %v234 = load i64, ptr %slot37, align 8
  %v235 = load i64, ptr %slot36, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p233, i64 0, i64 %v234, i64 %v235, i64 64) nomerge, !dbg !114
  unreachable
bb_checked44:
  %v236 = load i64, ptr %slot38, align 8
  %v237 = load i64, ptr %slot11, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot11, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %ld241 = load i64, ptr %p240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld241, ptr %slot43, align 8
  %v242 = load i64, ptr %slot43, align 8
  %v243 = load i64, ptr %slot10, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i64 %v242, ptr %p244, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v245 = load i64, ptr %slot10, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %ld247 = load i64, ptr %p246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld247, ptr %slot44, align 8
  %v248 = load i64, ptr %slot44, align 8
  %v249 = load i64, ptr %slot11, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 %v248, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot9, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i64, ptr %p252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld253, ptr %slot45, align 8
  %v254 = load i64, ptr %slot11, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %ld256 = load i64, ptr %p255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld256, ptr %slot46, align 8
  %v257 = load i64, ptr %slot45, align 8
  %p258 = inttoptr i64 %v257 to ptr
  %ld259 = load i64, ptr %p258, align 8, !alias.scope !6, !noalias !7
  store i64 %ld259, ptr %slot47, align 8
  %v260 = load i64, ptr %slot46, align 8
  %v261 = load i64, ptr %slot47, align 8
  %cmp262 = icmp ult i64 %v260, %v261
  %cv263 = zext i1 %cmp262 to i64
  store i64 %cv263, ptr %slot48, align 8
  %v264 = load i64, ptr %slot48, align 8
  %cond265 = icmp ne i64 %v264, 0
  br i1 %cond265, label %bb_success56, label %bb_failed56
bb_failed56:
  %v266 = load i64, ptr %slot1, align 8
  %p267 = inttoptr i64 %v266 to ptr
  %v268 = load i64, ptr %slot46, align 8
  %v269 = load i64, ptr %slot47, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p267, i64 %v268, i64 %v269) nomerge, !dbg !116
  unreachable
bb_success56:
  %v270 = load i64, ptr %slot45, align 8
  %op271 = add i64 %v270, 32
  store i64 %op271, ptr %slot49, align 8
  %v272 = load i64, ptr %slot49, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %ld274 = load i64, ptr %p273, align 8, !alias.scope !6, !noalias !7
  store i64 %ld274, ptr %slot50, align 8
  %v275 = load i64, ptr %slot46, align 8
  %op276 = mul i64 %v275, 40
  store i64 %op276, ptr %slot51, align 8
  %v277 = load i64, ptr %slot50, align 8
  %v278 = load i64, ptr %slot51, align 8
  %op279 = add i64 %v277, %v278
  store i64 %op279, ptr %slot52, align 8
  %v280 = load i64, ptr %slot52, align 8
  %v281 = load i64, ptr %slot11, align 8
  %p282 = inttoptr i64 %v281 to ptr
  store i64 %v280, ptr %p282, align 8, !alias.scope !3, !noalias !4
  %v283 = load i64, ptr %slot11, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld285, ptr %slot53, align 8
  %v286 = load i64, ptr %slot11, align 8
  %p287 = inttoptr i64 %v286 to ptr
  %ld288 = load i64, ptr %p287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld288, ptr %slot54, align 8
  store i32 0, ptr %slot55, align 8
  %v289 = load i64, ptr %slot5, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i32, ptr %p290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld291, ptr %slot56, align 8
  %v292 = load i32, ptr %slot56, align 8
  %op293 = and i32 %v292, 24
  store i32 %op293, ptr %slot56, align 8
  %v294 = load i32, ptr %slot56, align 8
  %cmp295 = icmp eq i32 %v294, 0
  %cv296 = zext i1 %cmp295 to i32
  store i32 %cv296, ptr %slot57, align 8
  %v297 = load i32, ptr %slot55, align 8
  %v298 = load i32, ptr %slot57, align 8
  %op299 = and i32 %v297, %v298
  store i32 %op299, ptr %slot58, align 8
  %v300 = load i32, ptr %slot58, align 8
  %cv301 = zext i32 %v300 to i64
  %cond302 = icmp ne i64 %cv301, 0
  br i1 %cond302, label %bb_rctake63, label %bb_rccopy63
bb_rctake63:
  %v303 = load i64, ptr %slot7, align 8
  store i64 %v303, ptr %slot59, align 8
  %v304 = load i64, ptr %slot14, align 8
  store i64 %v304, ptr %slot60, align 8
  %v305 = load i64, ptr %slot13, align 8
  %v306 = load i64, ptr %slot59, align 8
  %v307 = load i64, ptr %slot54, align 8
  %v308 = load i64, ptr %slot60, align 8
  %cv309 = trunc i64 %v308 to i32
  %call310 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v305, i64 %v306, i64 %v307, i32 %cv309) nomerge, !dbg !118
  store i32 %call310, ptr %slot61, align 8
  %v311 = load i32, ptr %slot61, align 8
  %cv312 = zext i32 %v311 to i64
  %cond313 = icmp ne i64 %cv312, 0
  br i1 %cond313, label %bb_rcsuccess73, label %bb_rcfailure73
bb_rcfailure73:
  %v314 = load i64, ptr %slot13, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %call316 = call i32 @myl_rc_take_failure(ptr %p315) nomerge, !dbg !118
  store i32 %call316, ptr %slot62, align 8
  %v317 = load i64, ptr %slot1, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %v319 = load i32, ptr %slot62, align 8
  %call320 = call i32 @myl_qbe_rc_status(ptr %p318, i32 %v319) nomerge, !dbg !118
  store i32 %call320, ptr %slot63, align 8
  br label %bb_failure
bb_rcsuccess73:
  %v321 = load i64, ptr %slot6, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i32 1, ptr %p322, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared63
bb_rccopy63:
  %v323 = load i64, ptr %slot7, align 8
  store i64 %v323, ptr %slot64, align 8
  %v324 = load i64, ptr %slot14, align 8
  store i64 %v324, ptr %slot65, align 8
  %v325 = load i64, ptr %slot13, align 8
  %v326 = load i64, ptr %slot64, align 8
  %v327 = load i64, ptr %slot54, align 8
  %v328 = load i64, ptr %slot65, align 8
  %cv329 = trunc i64 %v328 to i32
  %call330 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v325, i64 %v326, i64 %v327, i32 %cv329) nomerge, !dbg !118
  store i32 %call330, ptr %slot66, align 8
  %v331 = load i32, ptr %slot66, align 8
  %cv332 = zext i32 %v331 to i64
  %cond333 = icmp ne i64 %cv332, 0
  br i1 %cond333, label %bb_rcsuccess82, label %bb_rcfailure82
bb_rcfailure82:
  %v334 = load i64, ptr %slot13, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %call336 = call i32 @myl_rc_take_failure(ptr %p335) nomerge, !dbg !118
  store i32 %call336, ptr %slot67, align 8
  %v337 = load i64, ptr %slot1, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %v339 = load i32, ptr %slot67, align 8
  %call340 = call i32 @myl_qbe_rc_status(ptr %p338, i32 %v339) nomerge, !dbg !118
  store i32 %call340, ptr %slot68, align 8
  br label %bb_failure
bb_rcsuccess82:
  %v341 = load i64, ptr %slot6, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i32 1, ptr %p342, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared63
bb_rcprepared63:
  %v343 = load i64, ptr %slot7, align 8
  store i64 %v343, ptr %slot69, align 8
  %v344 = load i64, ptr %slot6, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i32 0, ptr %p345, align 4, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot69, align 8
  %p347 = inttoptr i64 %v346 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p347, i64 40, i1 false)
  ret void
bb_failure:
  %v348 = load i64, ptr %slot4, align 8
  %p349 = inttoptr i64 %v348 to ptr
  call void @llvm.memset.p0.i64(ptr %p349, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v350 = load i64, ptr %slot4, align 8
  %p351 = inttoptr i64 %v350 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p351, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v352 = load i64, ptr %slot4, align 8
  %p353 = inttoptr i64 %v352 to ptr
  call void @llvm.memset.p0.i64(ptr %p353, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v354 = load i64, ptr %slot4, align 8
  %p355 = inttoptr i64 %v354 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p355, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace", linkageName: "myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16501509723662138912, i64 0, !"myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!112 = !DILocation(line: 12, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!114 = !DILocation(line: 14, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!116 = !DILocation(line: 17, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!118 = !DILocation(line: 18, column: 0, scope: !119)
