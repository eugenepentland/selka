target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_2ebb09da19ad16997dccbe29951fffb7732b9a85aecee0e00a2bd8e0128061f9(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v260 = load i64, ptr %slot1, align 8
  %op261 = add i64 %v260, 32
  store i64 %op261, ptr %slot3, align 8
  %mem262 = alloca i8, i64 8, align 8
  %ptr263 = ptrtoint ptr %mem262 to i64
  store i64 %ptr263, ptr %slot4, align 8
  %mem264 = alloca i8, i64 8, align 8
  %ptr265 = ptrtoint ptr %mem264 to i64
  store i64 %ptr265, ptr %slot5, align 8
  %mem266 = alloca i8, i64 8, align 8
  %ptr267 = ptrtoint ptr %mem266 to i64
  store i64 %ptr267, ptr %slot6, align 8
  %mem268 = alloca i8, i64 8, align 8
  %ptr269 = ptrtoint ptr %mem268 to i64
  store i64 %ptr269, ptr %slot7, align 8
  %mem270 = alloca i8, i64 8, align 8
  %ptr271 = ptrtoint ptr %mem270 to i64
  store i64 %ptr271, ptr %slot8, align 8
  %mem272 = alloca i8, i64 8, align 8
  %ptr273 = ptrtoint ptr %mem272 to i64
  store i64 %ptr273, ptr %slot9, align 8
  %mem274 = alloca i8, i64 8, align 8
  %ptr275 = ptrtoint ptr %mem274 to i64
  store i64 %ptr275, ptr %slot10, align 8
  %mem276 = alloca i8, i64 8, align 8
  %ptr277 = ptrtoint ptr %mem276 to i64
  store i64 %ptr277, ptr %slot11, align 8
  %mem278 = alloca i8, i64 8, align 8
  %ptr279 = ptrtoint ptr %mem278 to i64
  store i64 %ptr279, ptr %slot12, align 8
  %mem280 = alloca i8, i64 392, align 8
  %ptr281 = ptrtoint ptr %mem280 to i64
  store i64 %ptr281, ptr %slot13, align 8
  %mem282 = alloca i8, i64 16, align 8
  %ptr283 = ptrtoint ptr %mem282 to i64
  store i64 %ptr283, ptr %slot14, align 8
  %mem284 = alloca i8, i64 8, align 8
  %ptr285 = ptrtoint ptr %mem284 to i64
  store i64 %ptr285, ptr %slot15, align 8
  %mem286 = alloca i8, i64 40, align 8
  %ptr287 = ptrtoint ptr %mem286 to i64
  store i64 %ptr287, ptr %slot16, align 8
  %mem288 = alloca i8, i64 8, align 8
  %ptr289 = ptrtoint ptr %mem288 to i64
  store i64 %ptr289, ptr %slot17, align 8
  %mem290 = alloca i8, i64 16, align 8
  %ptr291 = ptrtoint ptr %mem290 to i64
  store i64 %ptr291, ptr %slot18, align 8
  %mem292 = alloca i8, i64 8, align 8
  %ptr293 = ptrtoint ptr %mem292 to i64
  store i64 %ptr293, ptr %slot19, align 8
  %mem294 = alloca i8, i64 8, align 8
  %ptr295 = ptrtoint ptr %mem294 to i64
  store i64 %ptr295, ptr %slot20, align 8
  %mem296 = alloca i8, i64 8, align 8
  %ptr297 = ptrtoint ptr %mem296 to i64
  store i64 %ptr297, ptr %slot21, align 8
  %mem298 = alloca i8, i64 8, align 8
  %ptr299 = ptrtoint ptr %mem298 to i64
  store i64 %ptr299, ptr %slot22, align 8
  %mem300 = alloca i8, i64 8, align 8
  %ptr301 = ptrtoint ptr %mem300 to i64
  store i64 %ptr301, ptr %slot23, align 8
  %mem302 = alloca i8, i64 8, align 8
  %ptr303 = ptrtoint ptr %mem302 to i64
  store i64 %ptr303, ptr %slot24, align 8
  %mem304 = alloca i8, i64 392, align 8
  %ptr305 = ptrtoint ptr %mem304 to i64
  store i64 %ptr305, ptr %slot25, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem306 = alloca i8, i64 8, align 8
  %ptr307 = ptrtoint ptr %mem306 to i64
  store i64 %ptr307, ptr %slot26, align 8
  %v308 = load i64, ptr %slot1, align 8
  %op309 = add i64 %v308, 64
  store i64 %op309, ptr %slot27, align 8
  %v310 = load i64, ptr %slot27, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %ld312 = load i64, ptr %p311, align 8, !alias.scope !4, !noalias !3
  store i64 %ld312, ptr %slot28, align 8
  %stack313 = call ptr @llvm.stacksave()
  %stackaddr314 = ptrtoint ptr %stack313 to i64
  %v315 = load i64, ptr %slot28, align 8
  %cmp316 = icmp ult i64 %stackaddr314, %v315
  %cv317 = zext i1 %cmp316 to i64
  store i64 %cv317, ptr %slot29, align 8
  %v318 = load i64, ptr %slot29, align 8
  %cond319 = icmp ne i64 %v318, 0
  br i1 %cond319, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v320 = load i64, ptr %slot1, align 8
  %p321 = inttoptr i64 %v320 to ptr
  call void @myl_qbe_fail_frame(ptr %p321) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %mem322 = alloca i8, i64 16, align 8
  %ptr323 = ptrtoint ptr %mem322 to i64
  store i64 %ptr323, ptr %slot30, align 8
  %v324 = load i64, ptr %slot17, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i64 0, ptr %p325, align 8, !alias.scope !3, !noalias !4
  %v326 = load i64, ptr %slot2, align 8
  %v327 = load i64, ptr %slot15, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 %v326, ptr %p328, align 8, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot1, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %call331 = call ptr @myl_qbe_heap(ptr %p330) nomerge, !dbg !112
  %calladdr332 = ptrtoint ptr %call331 to i64
  store i64 %calladdr332, ptr %slot31, align 8
  %v333 = load i64, ptr %slot1, align 8
  %p334 = inttoptr i64 %v333 to ptr
  %call335 = call i64 @myl_qbe_region_mark(ptr %p334) nomerge, !dbg !112
  store i64 %call335, ptr %slot32, align 8
  %v336 = load i64, ptr %slot4, align 8
  %p337 = inttoptr i64 %v336 to ptr
  store i32 0, ptr %p337, align 4, !alias.scope !3, !noalias !4
  %v338 = load i64, ptr %slot5, align 8
  %p339 = inttoptr i64 %v338 to ptr
  store i32 0, ptr %p339, align 4, !alias.scope !3, !noalias !4
  %v340 = load i64, ptr %slot6, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i32 0, ptr %p341, align 4, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot7, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i32 0, ptr %p343, align 4, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot8, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i32 0, ptr %p345, align 4, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot9, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i32 0, ptr %p347, align 4, !alias.scope !3, !noalias !4
  %v348 = load i64, ptr %slot10, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i32 0, ptr %p349, align 4, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot11, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i32 0, ptr %p351, align 4, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot5, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 2, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot7, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i32 2, ptr %p355, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v356 = load i64, ptr %slot15, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i64, ptr %p357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld358, ptr %slot33, align 8
  %v359 = load i64, ptr %slot33, align 8
  %v360 = load i64, ptr %slot22, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i64 %v359, ptr %p361, align 8, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot22, align 8
  %p363 = inttoptr i64 %v362 to ptr
  %ld364 = load i64, ptr %p363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld364, ptr %slot34, align 8
  %v365 = load i64, ptr %slot34, align 8
  %op366 = add i64 %v365, 328
  store i64 %op366, ptr %slot35, align 8
  %v367 = load i64, ptr %slot35, align 8
  %v368 = load i64, ptr %slot22, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i64 %v367, ptr %p369, align 8, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot22, align 8
  %p371 = inttoptr i64 %v370 to ptr
  %ld372 = load i64, ptr %p371, align 8, !alias.scope !3, !noalias !4
  store i64 %ld372, ptr %slot36, align 8
  store i32 0, ptr %slot37, align 8
  %v373 = load i64, ptr %slot8, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %ld375 = load i32, ptr %p374, align 4, !alias.scope !3, !noalias !4
  store i32 %ld375, ptr %slot38, align 8
  %v376 = load i32, ptr %slot38, align 8
  %op377 = and i32 %v376, 24
  store i32 %op377, ptr %slot38, align 8
  %v378 = load i32, ptr %slot38, align 8
  %cmp379 = icmp eq i32 %v378, 0
  %cv380 = zext i1 %cmp379 to i32
  store i32 %cv380, ptr %slot39, align 8
  %v381 = load i32, ptr %slot37, align 8
  %v382 = load i32, ptr %slot39, align 8
  %op383 = and i32 %v381, %v382
  store i32 %op383, ptr %slot40, align 8
  %v384 = load i32, ptr %slot40, align 8
  %cv385 = zext i32 %v384 to i64
  %cond386 = icmp ne i64 %cv385, 0
  br i1 %cond386, label %bb_rctake23, label %bb_rccopy23
bb_rctake23:
  %v387 = load i64, ptr %slot13, align 8
  store i64 %v387, ptr %slot41, align 8
  %v388 = load i64, ptr %slot32, align 8
  store i64 %v388, ptr %slot42, align 8
  %v389 = load i64, ptr %slot31, align 8
  %v390 = load i64, ptr %slot41, align 8
  %v391 = load i64, ptr %slot36, align 8
  %v392 = load i64, ptr %slot42, align 8
  %cv393 = trunc i64 %v392 to i32
  %call394 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v389, i64 %v390, i64 %v391, i32 %cv393) nomerge, !dbg !114
  store i32 %call394, ptr %slot43, align 8
  %v395 = load i32, ptr %slot43, align 8
  %cv396 = zext i32 %v395 to i64
  %cond397 = icmp ne i64 %cv396, 0
  br i1 %cond397, label %bb_rcsuccess33, label %bb_rcfailure33
bb_rcfailure33:
  %v398 = load i64, ptr %slot31, align 8
  %p399 = inttoptr i64 %v398 to ptr
  %call400 = call i32 @myl_rc_take_failure(ptr %p399) nomerge, !dbg !114
  store i32 %call400, ptr %slot44, align 8
  %v401 = load i64, ptr %slot1, align 8
  %p402 = inttoptr i64 %v401 to ptr
  %v403 = load i32, ptr %slot44, align 8
  %call404 = call i32 @myl_qbe_rc_status(ptr %p402, i32 %v403) nomerge, !dbg !114
  store i32 %call404, ptr %slot45, align 8
  br label %bb_failure
bb_rcsuccess33:
  %v405 = load i64, ptr %slot10, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i32 2, ptr %p406, align 4, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot9, align 8
  %p408 = inttoptr i64 %v407 to ptr
  store i32 1, ptr %p408, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared23
bb_rccopy23:
  %v409 = load i64, ptr %slot13, align 8
  store i64 %v409, ptr %slot46, align 8
  %v410 = load i64, ptr %slot32, align 8
  store i64 %v410, ptr %slot47, align 8
  %v411 = load i64, ptr %slot31, align 8
  %v412 = load i64, ptr %slot46, align 8
  %v413 = load i64, ptr %slot36, align 8
  %v414 = load i64, ptr %slot47, align 8
  %cv415 = trunc i64 %v414 to i32
  %call416 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v411, i64 %v412, i64 %v413, i32 %cv415) nomerge, !dbg !114
  store i32 %call416, ptr %slot48, align 8
  %v417 = load i32, ptr %slot48, align 8
  %cv418 = zext i32 %v417 to i64
  %cond419 = icmp ne i64 %cv418, 0
  br i1 %cond419, label %bb_rcsuccess42, label %bb_rcfailure42
bb_rcfailure42:
  %v420 = load i64, ptr %slot31, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %call422 = call i32 @myl_rc_take_failure(ptr %p421) nomerge, !dbg !114
  store i32 %call422, ptr %slot49, align 8
  %v423 = load i64, ptr %slot1, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %v425 = load i32, ptr %slot49, align 8
  %call426 = call i32 @myl_qbe_rc_status(ptr %p424, i32 %v425) nomerge, !dbg !114
  store i32 %call426, ptr %slot50, align 8
  br label %bb_failure
bb_rcsuccess42:
  %v427 = load i64, ptr %slot10, align 8
  %p428 = inttoptr i64 %v427 to ptr
  store i32 2, ptr %p428, align 4, !alias.scope !3, !noalias !4
  %v429 = load i64, ptr %slot9, align 8
  %p430 = inttoptr i64 %v429 to ptr
  store i32 1, ptr %p430, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared23
bb_rcprepared23:
  %v431 = load i64, ptr %slot4, align 8
  %p432 = inttoptr i64 %v431 to ptr
  %ld433 = load i32, ptr %p432, align 4, !alias.scope !3, !noalias !4
  store i32 %ld433, ptr %slot51, align 8
  %v434 = load i32, ptr %slot51, align 8
  %cv435 = zext i32 %v434 to i64
  %cond436 = icmp ne i64 %cv435, 0
  br i1 %cond436, label %bb_rcslotdrop59, label %bb_rcslotdone59
bb_rcslotdrop59:
  %v437 = load i64, ptr %slot4, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i32 0, ptr %p438, align 4, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot16, align 8
  store i64 %v439, ptr %slot52, align 8
  %v440 = load i64, ptr %slot5, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %ld442 = load i32, ptr %p441, align 4, !alias.scope !3, !noalias !4
  store i32 %ld442, ptr %slot53, align 8
  %v443 = load i32, ptr %slot53, align 8
  %op444 = and i32 %v443, 28
  store i32 %op444, ptr %slot54, align 8
  %v445 = load i32, ptr %slot54, align 8
  %cv446 = zext i32 %v445 to i64
  %cond447 = icmp ne i64 %cv446, 0
  br i1 %cond447, label %bb_rcslotrole59, label %bb_rcslotowner59
bb_rcslotrole59:
  %v448 = load i64, ptr %slot31, align 8
  store i64 %v448, ptr %slot55, align 8
  %v449 = load i64, ptr %slot55, align 8
  %v450 = load i64, ptr %slot52, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v449, i64 %v450) nomerge, !dbg !114
  br label %bb_rcslotdone59
bb_rcslotowner59:
  %v451 = load i64, ptr %slot31, align 8
  store i64 %v451, ptr %slot56, align 8
  %v452 = load i64, ptr %slot56, align 8
  %v453 = load i64, ptr %slot52, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v452, i64 %v453) nomerge, !dbg !114
  br label %bb_rcslotdone59
bb_rcslotdone59:
  %v454 = load i64, ptr %slot16, align 8
  store i64 %v454, ptr %slot57, align 8
  %v455 = load i64, ptr %slot13, align 8
  store i64 %v455, ptr %slot58, align 8
  %v456 = load i64, ptr %slot58, align 8
  %v457 = load i64, ptr %slot57, align 8
  %p458 = inttoptr i64 %v456 to ptr
  %p459 = inttoptr i64 %v457 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p459, ptr %p458, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v460 = load i64, ptr %slot9, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i32 0, ptr %p461, align 4, !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot5, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i32 2, ptr %p463, align 4, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot10, align 8
  %p465 = inttoptr i64 %v464 to ptr
  %ld466 = load i32, ptr %p465, align 4, !alias.scope !3, !noalias !4
  store i32 %ld466, ptr %slot59, align 8
  %v467 = load i32, ptr %slot59, align 8
  %v468 = load i64, ptr %slot5, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i32 %v467, ptr %p469, align 4, !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot4, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 1, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot15, align 8
  %p473 = inttoptr i64 %v472 to ptr
  %ld474 = load i64, ptr %p473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld474, ptr %slot60, align 8
  %v475 = load i64, ptr %slot60, align 8
  %v476 = load i64, ptr %slot22, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i64 %v475, ptr %p477, align 8, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot22, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %ld480 = load i64, ptr %p479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld480, ptr %slot61, align 8
  %v481 = load i64, ptr %slot61, align 8
  %op482 = add i64 %v481, 248
  store i64 %op482, ptr %slot62, align 8
  %v483 = load i64, ptr %slot62, align 8
  %p484 = inttoptr i64 %v483 to ptr
  %ld485 = load i64, ptr %p484, align 8, !alias.scope !4, !noalias !3
  store i64 %ld485, ptr %slot63, align 8
  %v486 = load i64, ptr %slot63, align 8
  %v487 = load i64, ptr %slot22, align 8
  %p488 = inttoptr i64 %v487 to ptr
  store i64 %v486, ptr %p488, align 8, !alias.scope !3, !noalias !4
  %v489 = load i64, ptr %slot22, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %ld491 = load i64, ptr %p490, align 8, !alias.scope !3, !noalias !4
  store i64 %ld491, ptr %slot64, align 8
  %v492 = load i64, ptr %slot64, align 8
  %v493 = load i64, ptr %slot12, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i64 %v492, ptr %p494, align 8, !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot12, align 8
  store i64 %v495, ptr %slot65, align 8
  store i32 0, ptr %slot66, align 8
  %v496 = load i64, ptr %slot8, align 8
  %p497 = inttoptr i64 %v496 to ptr
  %ld498 = load i32, ptr %p497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld498, ptr %slot67, align 8
  %v499 = load i32, ptr %slot67, align 8
  %op500 = and i32 %v499, 24
  store i32 %op500, ptr %slot67, align 8
  %v501 = load i32, ptr %slot67, align 8
  %cmp502 = icmp eq i32 %v501, 0
  %cv503 = zext i1 %cmp502 to i32
  store i32 %cv503, ptr %slot68, align 8
  %v504 = load i32, ptr %slot66, align 8
  %v505 = load i32, ptr %slot68, align 8
  %op506 = and i32 %v504, %v505
  store i32 %op506, ptr %slot69, align 8
  %v507 = load i32, ptr %slot69, align 8
  %cv508 = zext i32 %v507 to i64
  %cond509 = icmp ne i64 %cv508, 0
  br i1 %cond509, label %bb_rcprivateown94, label %bb_rcprivateloan94
bb_rcprivateown94:
  %v510 = load i64, ptr %slot13, align 8
  store i64 %v510, ptr %slot70, align 8
  %v511 = load i64, ptr %slot32, align 8
  store i64 %v511, ptr %slot71, align 8
  %v512 = load i64, ptr %slot65, align 8
  %v513 = load i64, ptr %slot70, align 8
  %op514 = sub i64 %v512, %v513
  store i64 %op514, ptr %slot72, align 8
  %v515 = load i64, ptr %slot70, align 8
  %v516 = load i64, ptr %slot65, align 8
  %op517 = sub i64 %v515, %v516
  store i64 %op517, ptr %slot73, align 8
  %v518 = load i64, ptr %slot72, align 8
  %cmp519 = icmp ult i64 %v518, 8
  %cv520 = zext i1 %cmp519 to i32
  store i32 %cv520, ptr %slot74, align 8
  %v521 = load i64, ptr %slot73, align 8
  %cmp522 = icmp ult i64 %v521, 8
  %cv523 = zext i1 %cmp522 to i32
  store i32 %cv523, ptr %slot75, align 8
  %v524 = load i32, ptr %slot74, align 8
  %v525 = load i32, ptr %slot75, align 8
  %op526 = or i32 %v524, %v525
  store i32 %op526, ptr %slot76, align 8
  %v527 = load i32, ptr %slot76, align 8
  %cv528 = zext i32 %v527 to i64
  %cond529 = icmp ne i64 %cv528, 0
  br i1 %cond529, label %bb_rcmoveslow97, label %bb_rcmovecheck97
bb_rcmovecheck97:
  %v530 = load i64, ptr %slot65, align 8
  %p532 = inttoptr i64 %v530 to ptr
  %gep533 = getelementptr i8, ptr %p532, i64 0
  %op531 = ptrtoint ptr %gep533 to i64
  store i64 %op531, ptr %slot77, align 8
  %v534 = load i64, ptr %slot77, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i64, ptr %p535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld536, ptr %slot78, align 8
  %v537 = load i64, ptr %slot78, align 8
  %cmp538 = icmp ne i64 %v537, 0
  %cv539 = zext i1 %cmp538 to i32
  store i32 %cv539, ptr %slot79, align 8
  %v540 = load i32, ptr %slot79, align 8
  %cv541 = zext i32 %v540 to i64
  %cond542 = icmp ne i64 %cv541, 0
  br i1 %cond542, label %bb_rcmoveheader105, label %bb_rcmovenext105
bb_rcmoveheader105:
  %v543 = load i64, ptr %slot78, align 8
  %op544 = sub i64 %v543, 16
  store i64 %op544, ptr %slot80, align 8
  %v545 = load i64, ptr %slot78, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %rgep547 = getelementptr i8, ptr %p546, i64 -16
  %ld548 = load i64, ptr %rgep547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld548, ptr %slot81, align 8
  %v549 = load i64, ptr %slot81, align 8
  %op550 = and i64 %v549, 5764607523034234881
  store i64 %op550, ptr %slot82, align 8
  %v551 = load i64, ptr %slot82, align 8
  %cmp552 = icmp ne i64 %v551, 0
  %cv553 = zext i1 %cmp552 to i32
  store i32 %cv553, ptr %slot83, align 8
  %v554 = load i32, ptr %slot83, align 8
  %cv555 = zext i32 %v554 to i64
  %cond556 = icmp ne i64 %cv555, 0
  br i1 %cond556, label %bb_rcmoveslow97, label %bb_rcmovenext105
bb_rcmovenext105:
  %v557 = load i64, ptr %slot65, align 8
  %v558 = load i64, ptr %slot70, align 8
  %p559 = inttoptr i64 %v557 to ptr
  %p560 = inttoptr i64 %v558 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p560, ptr %p559, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v561 = load i64, ptr %slot65, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i64 0, ptr %p562, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved97
bb_rcmoveslow97:
  %v563 = load i64, ptr %slot31, align 8
  %v564 = load i64, ptr %slot70, align 8
  %v565 = load i64, ptr %slot65, align 8
  %v566 = load i64, ptr %slot71, align 8
  %cv567 = trunc i64 %v566 to i32
  %call568 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v563, i64 %v564, i64 %v565, i32 %cv567) nomerge, !dbg !116
  store i32 %call568, ptr %slot84, align 8
  %v569 = load i32, ptr %slot84, align 8
  %cv570 = zext i32 %v569 to i64
  %cond571 = icmp ne i64 %cv570, 0
  br i1 %cond571, label %bb_rcsuccess112, label %bb_rcfailure112
bb_rcfailure112:
  %v572 = load i64, ptr %slot31, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %call574 = call i32 @myl_rc_take_failure(ptr %p573) nomerge, !dbg !116
  store i32 %call574, ptr %slot85, align 8
  %v575 = load i64, ptr %slot1, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %v577 = load i32, ptr %slot85, align 8
  %call578 = call i32 @myl_qbe_rc_status(ptr %p576, i32 %v577) nomerge, !dbg !116
  store i32 %call578, ptr %slot86, align 8
  br label %bb_failure
bb_rcsuccess112:
  br label %bb_rcmoved97
bb_rcmoved97:
  %v579 = load i64, ptr %slot10, align 8
  %p580 = inttoptr i64 %v579 to ptr
  store i32 2, ptr %p580, align 4, !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot9, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i32 1, ptr %p582, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared94
bb_rcprivateloan94:
  store i32 0, ptr %slot87, align 8
  %v583 = load i64, ptr %slot8, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i32, ptr %p584, align 4, !alias.scope !3, !noalias !4
  store i32 %ld585, ptr %slot88, align 8
  %v586 = load i32, ptr %slot88, align 8
  %cmp587 = icmp eq i32 %v586, 16
  %cv588 = zext i1 %cmp587 to i32
  store i32 %cv588, ptr %slot89, align 8
  %v589 = load i32, ptr %slot89, align 8
  %v590 = load i32, ptr %slot87, align 8
  %op591 = and i32 %v589, %v590
  store i32 %op591, ptr %slot89, align 8
  %v592 = load i32, ptr %slot89, align 8
  %cv593 = zext i32 %v592 to i64
  %cond594 = icmp ne i64 %cv593, 0
  br i1 %cond594, label %bb_rcprivatemove94, label %bb_rcprivatenew94
bb_rcprivatemove94:
  %v595 = load i64, ptr %slot13, align 8
  store i64 %v595, ptr %slot90, align 8
  %v596 = load i64, ptr %slot65, align 8
  %v597 = load i64, ptr %slot90, align 8
  %p598 = inttoptr i64 %v596 to ptr
  %p599 = inttoptr i64 %v597 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p599, ptr %p598, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot65, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i64 0, ptr %p601, align 8, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot10, align 8
  %p603 = inttoptr i64 %v602 to ptr
  store i32 2, ptr %p603, align 4, !alias.scope !3, !noalias !4
  %v604 = load i64, ptr %slot10, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 16, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot9, align 8
  %p607 = inttoptr i64 %v606 to ptr
  store i32 1, ptr %p607, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared94
bb_rcprivatenew94:
  %v608 = load i64, ptr %slot13, align 8
  store i64 %v608, ptr %slot91, align 8
  %v609 = load i64, ptr %slot65, align 8
  %p610 = inttoptr i64 %v609 to ptr
  %ld611 = load i64, ptr %p610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld611, ptr %slot92, align 8
  %v612 = load i64, ptr %slot92, align 8
  %cmp613 = icmp ne i64 %v612, 0
  %cv614 = zext i1 %cmp613 to i32
  store i32 %cv614, ptr %slot93, align 8
  %v615 = load i32, ptr %slot93, align 8
  %cv616 = zext i32 %v615 to i64
  %cond617 = icmp ne i64 %cv616, 0
  br i1 %cond617, label %bb_rcgnn130, label %bb_rcgstore130
bb_rcgnn130:
  %v618 = load i64, ptr %slot92, align 8
  %op619 = sub i64 %v618, 16
  store i64 %op619, ptr %slot94, align 8
  %v620 = load i64, ptr %slot92, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %rgep622 = getelementptr i8, ptr %p621, i64 -16
  %ld623 = load i64, ptr %rgep622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld623, ptr %slot95, align 8
  %v624 = load i64, ptr %slot95, align 8
  %op625 = and i64 %v624, 4611686018427387906
  store i64 %op625, ptr %slot96, align 8
  %v626 = load i64, ptr %slot96, align 8
  %cmp627 = icmp ne i64 %v626, 0
  %cv628 = zext i1 %cmp627 to i32
  store i32 %cv628, ptr %slot97, align 8
  %v629 = load i32, ptr %slot97, align 8
  %cv630 = zext i32 %v629 to i64
  %cond631 = icmp ne i64 %cv630, 0
  br i1 %cond631, label %bb_rcgstore130, label %bb_rcginc130
bb_rcginc130:
  %v632 = load i64, ptr %slot92, align 8
  %op633 = sub i64 %v632, 24
  store i64 %op633, ptr %slot98, align 8
  %v634 = load i64, ptr %slot92, align 8
  %p635 = inttoptr i64 %v634 to ptr
  %rgep636 = getelementptr i8, ptr %p635, i64 -24
  %ld637 = load i64, ptr %rgep636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld637, ptr %slot99, align 8
  %v638 = load i64, ptr %slot99, align 8
  %op639 = add i64 %v638, 1
  store i64 %op639, ptr %slot100, align 8
  %v640 = load i64, ptr %slot100, align 8
  %cmp641 = icmp eq i64 %v640, 0
  %cv642 = zext i1 %cmp641 to i32
  store i32 %cv642, ptr %slot101, align 8
  %v643 = load i32, ptr %slot101, align 8
  %cv644 = zext i32 %v643 to i64
  %cond645 = icmp ne i64 %cv644, 0
  br i1 %cond645, label %bb_rcglimit130, label %bb_rcgcapacity130
bb_rcglimit130:
  %v646 = load i64, ptr %slot1, align 8
  %p647 = inttoptr i64 %v646 to ptr
  %call648 = call i32 @myl_qbe_rc_status(ptr %p647, i32 2) nomerge, !dbg !116
  store i32 %call648, ptr %slot102, align 8
  br label %bb_failure
bb_rcgcapacity130:
  %v649 = load i64, ptr %slot100, align 8
  %v650 = load i64, ptr %slot92, align 8
  %p651 = inttoptr i64 %v650 to ptr
  %rgep652 = getelementptr i8, ptr %p651, i64 -24
  store i64 %v649, ptr %rgep652, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore130
bb_rcgstore130:
  %v653 = load i64, ptr %slot92, align 8
  %v654 = load i64, ptr %slot91, align 8
  %p655 = inttoptr i64 %v654 to ptr
  store i64 %v653, ptr %p655, align 8, !alias.scope !3, !noalias !4
  %v656 = load i64, ptr %slot10, align 8
  %p657 = inttoptr i64 %v656 to ptr
  store i32 2, ptr %p657, align 4, !alias.scope !3, !noalias !4
  %v658 = load i64, ptr %slot10, align 8
  %p659 = inttoptr i64 %v658 to ptr
  store i32 16, ptr %p659, align 4, !alias.scope !3, !noalias !4
  %v660 = load i64, ptr %slot9, align 8
  %p661 = inttoptr i64 %v660 to ptr
  store i32 1, ptr %p661, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared94
bb_rcprivateprepared94:
  %v662 = load i64, ptr %slot6, align 8
  %p663 = inttoptr i64 %v662 to ptr
  %ld664 = load i32, ptr %p663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld664, ptr %slot103, align 8
  %v665 = load i32, ptr %slot103, align 8
  %cv666 = zext i32 %v665 to i64
  %cond667 = icmp ne i64 %cv666, 0
  br i1 %cond667, label %bb_rcslotdrop184, label %bb_rcslotdone184
bb_rcslotdrop184:
  %v668 = load i64, ptr %slot6, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i32 0, ptr %p669, align 4, !alias.scope !3, !noalias !4
  %v670 = load i64, ptr %slot17, align 8
  store i64 %v670, ptr %slot104, align 8
  %v671 = load i64, ptr %slot7, align 8
  %p672 = inttoptr i64 %v671 to ptr
  %ld673 = load i32, ptr %p672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld673, ptr %slot105, align 8
  %v674 = load i32, ptr %slot105, align 8
  %op675 = and i32 %v674, 28
  store i32 %op675, ptr %slot106, align 8
  %v676 = load i32, ptr %slot106, align 8
  %cv677 = zext i32 %v676 to i64
  %cond678 = icmp ne i64 %cv677, 0
  br i1 %cond678, label %bb_rcslotrole184, label %bb_rcslotowner184
bb_rcslotrole184:
  %v679 = load i64, ptr %slot31, align 8
  store i64 %v679, ptr %slot107, align 8
  %v680 = load i64, ptr %slot104, align 8
  %p681 = inttoptr i64 %v680 to ptr
  %ld682 = load i64, ptr %p681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld682, ptr %slot108, align 8
  %v683 = load i64, ptr %slot108, align 8
  %cmp684 = icmp ne i64 %v683, 0
  %cv685 = zext i1 %cmp684 to i32
  store i32 %cv685, ptr %slot109, align 8
  %v686 = load i32, ptr %slot109, align 8
  %cv687 = zext i32 %v686 to i64
  %cond688 = icmp ne i64 %cv687, 0
  br i1 %cond688, label %bb_rcgnn200, label %bb_rcgdone200
bb_rcgnn200:
  %v689 = load i64, ptr %slot108, align 8
  %op690 = sub i64 %v689, 16
  store i64 %op690, ptr %slot110, align 8
  %v691 = load i64, ptr %slot108, align 8
  %p692 = inttoptr i64 %v691 to ptr
  %rgep693 = getelementptr i8, ptr %p692, i64 -16
  %ld694 = load i64, ptr %rgep693, align 8, !alias.scope !9, !noalias !10
  store i64 %ld694, ptr %slot111, align 8
  %v695 = load i64, ptr %slot111, align 8
  %op696 = and i64 %v695, 4611686018427387906
  store i64 %op696, ptr %slot112, align 8
  %v697 = load i64, ptr %slot112, align 8
  %cmp698 = icmp ne i64 %v697, 0
  %cv699 = zext i1 %cmp698 to i32
  store i32 %cv699, ptr %slot113, align 8
  %v700 = load i32, ptr %slot113, align 8
  %cv701 = zext i32 %v700 to i64
  %cond702 = icmp ne i64 %cv701, 0
  br i1 %cond702, label %bb_rcgclear200, label %bb_rcgcounted200
bb_rcgcounted200:
  %v703 = load i64, ptr %slot108, align 8
  %op704 = sub i64 %v703, 24
  store i64 %op704, ptr %slot114, align 8
  %v705 = load i64, ptr %slot108, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %rgep707 = getelementptr i8, ptr %p706, i64 -24
  %ld708 = load i64, ptr %rgep707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld708, ptr %slot115, align 8
  %v709 = load i64, ptr %slot115, align 8
  %op710 = sub i64 %v709, 1
  store i64 %op710, ptr %slot116, align 8
  %v711 = load i64, ptr %slot116, align 8
  %cmp712 = icmp eq i64 %v711, 0
  %cv713 = zext i1 %cmp712 to i32
  store i32 %cv713, ptr %slot117, align 8
  %v714 = load i32, ptr %slot117, align 8
  %cv715 = zext i32 %v714 to i64
  %cond716 = icmp ne i64 %cv715, 0
  br i1 %cond716, label %bb_rcglast200, label %bb_rcgdec200
bb_rcglast200:
  %v717 = load i64, ptr %slot108, align 8
  %op718 = sub i64 %v717, 32
  store i64 %op718, ptr %slot118, align 8
  %v719 = load i64, ptr %slot108, align 8
  %p720 = inttoptr i64 %v719 to ptr
  %rgep721 = getelementptr i8, ptr %p720, i64 -32
  %ld722 = load i64, ptr %rgep721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld722, ptr %slot119, align 8
  %v723 = load i64, ptr %slot119, align 8
  %cmp724 = icmp ne i64 %v723, 0
  %cv725 = zext i1 %cmp724 to i32
  store i32 %cv725, ptr %slot120, align 8
  %v726 = load i32, ptr %slot120, align 8
  %cv727 = zext i32 %v726 to i64
  %cond728 = icmp ne i64 %cv727, 0
  br i1 %cond728, label %bb_rcgdec200, label %bb_rcgslow200
bb_rcgslow200:
  %v729 = load i64, ptr %slot107, align 8
  %v730 = load i64, ptr %slot104, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v729, i64 %v730) nomerge, !dbg !116
  br label %bb_rcgdone200
bb_rcgdec200:
  %v731 = load i64, ptr %slot116, align 8
  %v732 = load i64, ptr %slot108, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %rgep734 = getelementptr i8, ptr %p733, i64 -24
  store i64 %v731, ptr %rgep734, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear200
bb_rcgclear200:
  %v735 = load i64, ptr %slot104, align 8
  %p736 = inttoptr i64 %v735 to ptr
  store i64 0, ptr %p736, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone200
bb_rcgdone200:
  br label %bb_rcslotdone184
bb_rcslotowner184:
  %v737 = load i64, ptr %slot31, align 8
  store i64 %v737, ptr %slot121, align 8
  %v738 = load i64, ptr %slot104, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i64, ptr %p739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld740, ptr %slot122, align 8
  %v741 = load i64, ptr %slot122, align 8
  %cmp742 = icmp ne i64 %v741, 0
  %cv743 = zext i1 %cmp742 to i32
  store i32 %cv743, ptr %slot123, align 8
  %v744 = load i32, ptr %slot123, align 8
  %cv745 = zext i32 %v744 to i64
  %cond746 = icmp ne i64 %cv745, 0
  br i1 %cond746, label %bb_rcgnn215, label %bb_rcgdone215
bb_rcgnn215:
  %v747 = load i64, ptr %slot122, align 8
  %op748 = sub i64 %v747, 16
  store i64 %op748, ptr %slot124, align 8
  %v749 = load i64, ptr %slot122, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %rgep751 = getelementptr i8, ptr %p750, i64 -16
  %ld752 = load i64, ptr %rgep751, align 8, !alias.scope !9, !noalias !10
  store i64 %ld752, ptr %slot125, align 8
  %v753 = load i64, ptr %slot125, align 8
  %op754 = and i64 %v753, 4611686018427387906
  store i64 %op754, ptr %slot126, align 8
  %v755 = load i64, ptr %slot126, align 8
  %cmp756 = icmp ne i64 %v755, 0
  %cv757 = zext i1 %cmp756 to i32
  store i32 %cv757, ptr %slot127, align 8
  %v758 = load i32, ptr %slot127, align 8
  %cv759 = zext i32 %v758 to i64
  %cond760 = icmp ne i64 %cv759, 0
  br i1 %cond760, label %bb_rcgclear215, label %bb_rcgcounted215
bb_rcgcounted215:
  %v761 = load i64, ptr %slot122, align 8
  %op762 = sub i64 %v761, 32
  store i64 %op762, ptr %slot128, align 8
  %v763 = load i64, ptr %slot122, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %rgep765 = getelementptr i8, ptr %p764, i64 -32
  %ld766 = load i64, ptr %rgep765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld766, ptr %slot129, align 8
  %v767 = load i64, ptr %slot129, align 8
  %op768 = sub i64 %v767, 1
  store i64 %op768, ptr %slot130, align 8
  %v769 = load i64, ptr %slot130, align 8
  %cmp770 = icmp eq i64 %v769, 0
  %cv771 = zext i1 %cmp770 to i32
  store i32 %cv771, ptr %slot131, align 8
  %v772 = load i32, ptr %slot131, align 8
  %cv773 = zext i32 %v772 to i64
  %cond774 = icmp ne i64 %cv773, 0
  br i1 %cond774, label %bb_rcglast215, label %bb_rcgdec215
bb_rcglast215:
  %v775 = load i64, ptr %slot122, align 8
  %op776 = sub i64 %v775, 24
  store i64 %op776, ptr %slot132, align 8
  %v777 = load i64, ptr %slot122, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %rgep779 = getelementptr i8, ptr %p778, i64 -24
  %ld780 = load i64, ptr %rgep779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld780, ptr %slot133, align 8
  %v781 = load i64, ptr %slot133, align 8
  %cmp782 = icmp ne i64 %v781, 0
  %cv783 = zext i1 %cmp782 to i32
  store i32 %cv783, ptr %slot134, align 8
  %v784 = load i32, ptr %slot134, align 8
  %cv785 = zext i32 %v784 to i64
  %cond786 = icmp ne i64 %cv785, 0
  br i1 %cond786, label %bb_rcgdec215, label %bb_rcgslow215
bb_rcgslow215:
  %v787 = load i64, ptr %slot121, align 8
  %v788 = load i64, ptr %slot104, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v787, i64 %v788) nomerge, !dbg !116
  br label %bb_rcgdone215
bb_rcgdec215:
  %v789 = load i64, ptr %slot130, align 8
  %v790 = load i64, ptr %slot122, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %rgep792 = getelementptr i8, ptr %p791, i64 -32
  store i64 %v789, ptr %rgep792, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear215
bb_rcgclear215:
  %v793 = load i64, ptr %slot104, align 8
  %p794 = inttoptr i64 %v793 to ptr
  store i64 0, ptr %p794, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone215
bb_rcgdone215:
  br label %bb_rcslotdone184
bb_rcslotdone184:
  %v795 = load i64, ptr %slot17, align 8
  store i64 %v795, ptr %slot135, align 8
  %v796 = load i64, ptr %slot13, align 8
  store i64 %v796, ptr %slot136, align 8
  %v797 = load i64, ptr %slot136, align 8
  %v798 = load i64, ptr %slot135, align 8
  %p799 = inttoptr i64 %v797 to ptr
  %p800 = inttoptr i64 %v798 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p800, ptr %p799, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v801 = load i64, ptr %slot9, align 8
  %p802 = inttoptr i64 %v801 to ptr
  store i32 0, ptr %p802, align 4, !alias.scope !3, !noalias !4
  %v803 = load i64, ptr %slot7, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i32 2, ptr %p804, align 4, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot10, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i32, ptr %p806, align 4, !alias.scope !3, !noalias !4
  store i32 %ld807, ptr %slot137, align 8
  %v808 = load i32, ptr %slot137, align 8
  %v809 = load i64, ptr %slot7, align 8
  %p810 = inttoptr i64 %v809 to ptr
  store i32 %v808, ptr %p810, align 4, !alias.scope !3, !noalias !4
  %v811 = load i64, ptr %slot6, align 8
  %p812 = inttoptr i64 %v811 to ptr
  store i32 1, ptr %p812, align 4, !alias.scope !3, !noalias !4
  %v813 = load i64, ptr %slot16, align 8
  %v814 = load i64, ptr %slot22, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i64 %v813, ptr %p815, align 8, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot22, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %ld818 = load i64, ptr %p817, align 8, !alias.scope !3, !noalias !4
  store i64 %ld818, ptr %slot138, align 8
  %v819 = load i64, ptr %slot138, align 8
  %op820 = add i64 %v819, 8
  store i64 %op820, ptr %slot139, align 8
  %v821 = load i64, ptr %slot139, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ld823 = load i64, ptr %p822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld823, ptr %slot140, align 8
  %v824 = load i64, ptr %slot140, align 8
  %v825 = load i64, ptr %slot22, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i64 %v824, ptr %p826, align 8, !alias.scope !3, !noalias !4
  %v827 = load i64, ptr %slot16, align 8
  %v828 = load i64, ptr %slot23, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 %v827, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot23, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %ld832 = load i64, ptr %p831, align 8, !alias.scope !3, !noalias !4
  store i64 %ld832, ptr %slot141, align 8
  %v833 = load i64, ptr %slot141, align 8
  %op834 = add i64 %v833, 8
  store i64 %op834, ptr %slot142, align 8
  %v835 = load i64, ptr %slot142, align 8
  %p836 = inttoptr i64 %v835 to ptr
  %ld837 = load i64, ptr %p836, align 8
  store i64 %ld837, ptr %slot143, align 8
  %v838 = load i64, ptr %slot143, align 8
  %v839 = load i64, ptr %slot23, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i64 %v838, ptr %p840, align 8, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot16, align 8
  %v842 = load i64, ptr %slot24, align 8
  %p843 = inttoptr i64 %v842 to ptr
  store i64 %v841, ptr %p843, align 8, !alias.scope !3, !noalias !4
  %v844 = load i64, ptr %slot24, align 8
  %p845 = inttoptr i64 %v844 to ptr
  %ld846 = load i64, ptr %p845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld846, ptr %slot144, align 8
  %v847 = load i64, ptr %slot144, align 8
  %op848 = add i64 %v847, 16
  store i64 %op848, ptr %slot145, align 8
  %v849 = load i64, ptr %slot145, align 8
  %p850 = inttoptr i64 %v849 to ptr
  %ld851 = load i64, ptr %p850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld851, ptr %slot146, align 8
  %v852 = load i64, ptr %slot146, align 8
  %v853 = load i64, ptr %slot24, align 8
  %p854 = inttoptr i64 %v853 to ptr
  store i64 %v852, ptr %p854, align 8, !alias.scope !3, !noalias !4
  %v855 = load i64, ptr %slot24, align 8
  %p856 = inttoptr i64 %v855 to ptr
  %ld857 = load i64, ptr %p856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld857, ptr %slot147, align 8
  %v858 = load i64, ptr %slot23, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %ld860 = load i64, ptr %p859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld860, ptr %slot148, align 8
  %v861 = load i64, ptr %slot148, align 8
  %v862 = load i64, ptr %slot147, align 8
  %ovpair864 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v861, i64 %v862)
  %op863 = extractvalue { i64, i1 } %ovpair864, 0
  %ov865 = extractvalue { i64, i1 } %ovpair864, 1
  store i64 %op863, ptr %slot149, align 8
  %v866 = load i64, ptr %slot148, align 8
  %v867 = load i64, ptr %slot149, align 8
  %op868 = xor i64 %v866, %v867
  store i64 %op868, ptr %slot150, align 8
  %v869 = load i64, ptr %slot147, align 8
  %v870 = load i64, ptr %slot149, align 8
  %op871 = xor i64 %v869, %v870
  store i64 %op871, ptr %slot151, align 8
  %v872 = load i64, ptr %slot150, align 8
  %v873 = load i64, ptr %slot151, align 8
  %op874 = and i64 %v872, %v873
  store i64 %op874, ptr %slot152, align 8
  %cv875 = zext i1 %ov865 to i64
  store i64 %cv875, ptr %slot153, align 8
  %v876 = load i64, ptr %slot153, align 8
  %cond877 = icmp ne i64 %v876, 0
  br i1 %cond877, label %bb_overflow264, label %bb_checked264
bb_overflow264:
  %v878 = load i64, ptr %slot1, align 8
  %p879 = inttoptr i64 %v878 to ptr
  %v880 = load i64, ptr %slot148, align 8
  %v881 = load i64, ptr %slot147, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p879, i64 0, i64 %v880, i64 %v881, i64 64) nomerge, !dbg !118
  unreachable
bb_checked264:
  %v882 = load i64, ptr %slot149, align 8
  %v883 = load i64, ptr %slot23, align 8
  %p884 = inttoptr i64 %v883 to ptr
  store i64 %v882, ptr %p884, align 8, !alias.scope !3, !noalias !4
  %v885 = load i64, ptr %slot17, align 8
  %p886 = inttoptr i64 %v885 to ptr
  %ld887 = load i64, ptr %p886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld887, ptr %slot154, align 8
  %v888 = load i64, ptr %slot22, align 8
  %p889 = inttoptr i64 %v888 to ptr
  %ld890 = load i64, ptr %p889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld890, ptr %slot155, align 8
  %v891 = load i64, ptr %slot23, align 8
  %p892 = inttoptr i64 %v891 to ptr
  %ld893 = load i64, ptr %p892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld893, ptr %slot156, align 8
  %v894 = load i64, ptr %slot154, align 8
  %p895 = inttoptr i64 %v894 to ptr
  %v896 = load i64, ptr %slot155, align 8
  %v897 = load i64, ptr %slot156, align 8
  %v898 = load i64, ptr %slot14, align 8
  %p899 = inttoptr i64 %v898 to ptr
  %call900 = call ptr @myl_native_bytes_range(ptr %p895, i64 %v896, i64 %v897, ptr %p899) nomerge, !dbg !120
  %calladdr901 = ptrtoint ptr %call900 to i64
  store i64 %calladdr901, ptr %slot157, align 8
  %v902 = load i64, ptr %slot14, align 8
  %p903 = inttoptr i64 %v902 to ptr
  %ld904 = load i64, ptr %p903, align 8, !alias.scope !3, !noalias !4
  store i64 %ld904, ptr %slot158, align 8
  %v905 = load i64, ptr %slot157, align 8
  %p906 = inttoptr i64 %v905 to ptr
  %v907 = load i64, ptr %slot158, align 8
  %v908 = load i64, ptr %slot14, align 8
  %p909 = inttoptr i64 %v908 to ptr
  %call910 = call i32 @myl_native_bytes_number_parse(ptr %p906, i64 %v907, i32 1, ptr %p909) nomerge, !dbg !120
  store i32 %call910, ptr %slot159, align 8
  %v911 = load i64, ptr %slot14, align 8
  %p912 = inttoptr i64 %v911 to ptr
  %ld913 = load i64, ptr %p912, align 8, !alias.scope !3, !noalias !4
  store i64 %ld913, ptr %slot160, align 8
  %v914 = load i64, ptr %slot30, align 8
  store i64 %v914, ptr %slot161, align 8
  %v915 = load i64, ptr %slot161, align 8
  %p917 = inttoptr i64 %v915 to ptr
  %gep918 = getelementptr i8, ptr %p917, i64 8
  %op916 = ptrtoint ptr %gep918 to i64
  store i64 %op916, ptr %slot162, align 8
  %v919 = load i32, ptr %slot159, align 8
  %cv920 = zext i32 %v919 to i64
  %cond921 = icmp ne i64 %cv920, 0
  br i1 %cond921, label %bb_some279, label %bb_none279
bb_some279:
  %v922 = load i64, ptr %slot161, align 8
  %p923 = inttoptr i64 %v922 to ptr
  store i32 1, ptr %p923, align 4, !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot160, align 8
  %v925 = load i64, ptr %slot162, align 8
  %p926 = inttoptr i64 %v925 to ptr
  store i64 %v924, ptr %p926, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed279
bb_none279:
  %v927 = load i64, ptr %slot161, align 8
  %p928 = inttoptr i64 %v927 to ptr
  store i32 0, ptr %p928, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed279
bb_parsed279:
  %v929 = load i64, ptr %slot161, align 8
  %v930 = load i64, ptr %slot22, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i64 %v929, ptr %p931, align 8, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot22, align 8
  %p933 = inttoptr i64 %v932 to ptr
  %ld934 = load i64, ptr %p933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld934, ptr %slot163, align 8
  %v935 = load i64, ptr %slot163, align 8
  %v936 = load i64, ptr %slot18, align 8
  %p937 = inttoptr i64 %v935 to ptr
  %p938 = inttoptr i64 %v936 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p938, ptr %p937, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v939 = load i64, ptr %slot6, align 8
  %p940 = inttoptr i64 %v939 to ptr
  %ld941 = load i32, ptr %p940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld941, ptr %slot164, align 8
  %v942 = load i32, ptr %slot164, align 8
  %cv943 = zext i32 %v942 to i64
  %cond944 = icmp ne i64 %cv943, 0
  br i1 %cond944, label %bb_rcslotdrop283, label %bb_rcslotdone283
bb_rcslotdrop283:
  %v945 = load i64, ptr %slot6, align 8
  %p946 = inttoptr i64 %v945 to ptr
  store i32 0, ptr %p946, align 4, !alias.scope !3, !noalias !4
  %v947 = load i64, ptr %slot17, align 8
  store i64 %v947, ptr %slot165, align 8
  %v948 = load i64, ptr %slot7, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %ld950 = load i32, ptr %p949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld950, ptr %slot166, align 8
  %v951 = load i32, ptr %slot166, align 8
  %op952 = and i32 %v951, 28
  store i32 %op952, ptr %slot167, align 8
  %v953 = load i32, ptr %slot167, align 8
  %cv954 = zext i32 %v953 to i64
  %cond955 = icmp ne i64 %cv954, 0
  br i1 %cond955, label %bb_rcslotrole283, label %bb_rcslotowner283
bb_rcslotrole283:
  %v956 = load i64, ptr %slot31, align 8
  store i64 %v956, ptr %slot168, align 8
  %v957 = load i64, ptr %slot165, align 8
  %p958 = inttoptr i64 %v957 to ptr
  %ld959 = load i64, ptr %p958, align 8, !alias.scope !3, !noalias !4
  store i64 %ld959, ptr %slot169, align 8
  %v960 = load i64, ptr %slot169, align 8
  %cmp961 = icmp ne i64 %v960, 0
  %cv962 = zext i1 %cmp961 to i32
  store i32 %cv962, ptr %slot170, align 8
  %v963 = load i32, ptr %slot170, align 8
  %cv964 = zext i32 %v963 to i64
  %cond965 = icmp ne i64 %cv964, 0
  br i1 %cond965, label %bb_rcgnn299, label %bb_rcgdone299
bb_rcgnn299:
  %v966 = load i64, ptr %slot169, align 8
  %op967 = sub i64 %v966, 16
  store i64 %op967, ptr %slot171, align 8
  %v968 = load i64, ptr %slot169, align 8
  %p969 = inttoptr i64 %v968 to ptr
  %rgep970 = getelementptr i8, ptr %p969, i64 -16
  %ld971 = load i64, ptr %rgep970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld971, ptr %slot172, align 8
  %v972 = load i64, ptr %slot172, align 8
  %op973 = and i64 %v972, 4611686018427387906
  store i64 %op973, ptr %slot173, align 8
  %v974 = load i64, ptr %slot173, align 8
  %cmp975 = icmp ne i64 %v974, 0
  %cv976 = zext i1 %cmp975 to i32
  store i32 %cv976, ptr %slot174, align 8
  %v977 = load i32, ptr %slot174, align 8
  %cv978 = zext i32 %v977 to i64
  %cond979 = icmp ne i64 %cv978, 0
  br i1 %cond979, label %bb_rcgclear299, label %bb_rcgcounted299
bb_rcgcounted299:
  %v980 = load i64, ptr %slot169, align 8
  %op981 = sub i64 %v980, 24
  store i64 %op981, ptr %slot175, align 8
  %v982 = load i64, ptr %slot169, align 8
  %p983 = inttoptr i64 %v982 to ptr
  %rgep984 = getelementptr i8, ptr %p983, i64 -24
  %ld985 = load i64, ptr %rgep984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld985, ptr %slot176, align 8
  %v986 = load i64, ptr %slot176, align 8
  %op987 = sub i64 %v986, 1
  store i64 %op987, ptr %slot177, align 8
  %v988 = load i64, ptr %slot177, align 8
  %cmp989 = icmp eq i64 %v988, 0
  %cv990 = zext i1 %cmp989 to i32
  store i32 %cv990, ptr %slot178, align 8
  %v991 = load i32, ptr %slot178, align 8
  %cv992 = zext i32 %v991 to i64
  %cond993 = icmp ne i64 %cv992, 0
  br i1 %cond993, label %bb_rcglast299, label %bb_rcgdec299
bb_rcglast299:
  %v994 = load i64, ptr %slot169, align 8
  %op995 = sub i64 %v994, 32
  store i64 %op995, ptr %slot179, align 8
  %v996 = load i64, ptr %slot169, align 8
  %p997 = inttoptr i64 %v996 to ptr
  %rgep998 = getelementptr i8, ptr %p997, i64 -32
  %ld999 = load i64, ptr %rgep998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld999, ptr %slot180, align 8
  %v1000 = load i64, ptr %slot180, align 8
  %cmp1001 = icmp ne i64 %v1000, 0
  %cv1002 = zext i1 %cmp1001 to i32
  store i32 %cv1002, ptr %slot181, align 8
  %v1003 = load i32, ptr %slot181, align 8
  %cv1004 = zext i32 %v1003 to i64
  %cond1005 = icmp ne i64 %cv1004, 0
  br i1 %cond1005, label %bb_rcgdec299, label %bb_rcgslow299
bb_rcgslow299:
  %v1006 = load i64, ptr %slot168, align 8
  %v1007 = load i64, ptr %slot165, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1006, i64 %v1007) nomerge, !dbg !122
  br label %bb_rcgdone299
bb_rcgdec299:
  %v1008 = load i64, ptr %slot177, align 8
  %v1009 = load i64, ptr %slot169, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  %rgep1011 = getelementptr i8, ptr %p1010, i64 -24
  store i64 %v1008, ptr %rgep1011, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear299
bb_rcgclear299:
  %v1012 = load i64, ptr %slot165, align 8
  %p1013 = inttoptr i64 %v1012 to ptr
  store i64 0, ptr %p1013, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone299
bb_rcgdone299:
  br label %bb_rcslotdone283
bb_rcslotowner283:
  %v1014 = load i64, ptr %slot31, align 8
  store i64 %v1014, ptr %slot182, align 8
  %v1015 = load i64, ptr %slot165, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %ld1017 = load i64, ptr %p1016, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1017, ptr %slot183, align 8
  %v1018 = load i64, ptr %slot183, align 8
  %cmp1019 = icmp ne i64 %v1018, 0
  %cv1020 = zext i1 %cmp1019 to i32
  store i32 %cv1020, ptr %slot184, align 8
  %v1021 = load i32, ptr %slot184, align 8
  %cv1022 = zext i32 %v1021 to i64
  %cond1023 = icmp ne i64 %cv1022, 0
  br i1 %cond1023, label %bb_rcgnn314, label %bb_rcgdone314
bb_rcgnn314:
  %v1024 = load i64, ptr %slot183, align 8
  %op1025 = sub i64 %v1024, 16
  store i64 %op1025, ptr %slot185, align 8
  %v1026 = load i64, ptr %slot183, align 8
  %p1027 = inttoptr i64 %v1026 to ptr
  %rgep1028 = getelementptr i8, ptr %p1027, i64 -16
  %ld1029 = load i64, ptr %rgep1028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1029, ptr %slot186, align 8
  %v1030 = load i64, ptr %slot186, align 8
  %op1031 = and i64 %v1030, 4611686018427387906
  store i64 %op1031, ptr %slot187, align 8
  %v1032 = load i64, ptr %slot187, align 8
  %cmp1033 = icmp ne i64 %v1032, 0
  %cv1034 = zext i1 %cmp1033 to i32
  store i32 %cv1034, ptr %slot188, align 8
  %v1035 = load i32, ptr %slot188, align 8
  %cv1036 = zext i32 %v1035 to i64
  %cond1037 = icmp ne i64 %cv1036, 0
  br i1 %cond1037, label %bb_rcgclear314, label %bb_rcgcounted314
bb_rcgcounted314:
  %v1038 = load i64, ptr %slot183, align 8
  %op1039 = sub i64 %v1038, 32
  store i64 %op1039, ptr %slot189, align 8
  %v1040 = load i64, ptr %slot183, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %rgep1042 = getelementptr i8, ptr %p1041, i64 -32
  %ld1043 = load i64, ptr %rgep1042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1043, ptr %slot190, align 8
  %v1044 = load i64, ptr %slot190, align 8
  %op1045 = sub i64 %v1044, 1
  store i64 %op1045, ptr %slot191, align 8
  %v1046 = load i64, ptr %slot191, align 8
  %cmp1047 = icmp eq i64 %v1046, 0
  %cv1048 = zext i1 %cmp1047 to i32
  store i32 %cv1048, ptr %slot192, align 8
  %v1049 = load i32, ptr %slot192, align 8
  %cv1050 = zext i32 %v1049 to i64
  %cond1051 = icmp ne i64 %cv1050, 0
  br i1 %cond1051, label %bb_rcglast314, label %bb_rcgdec314
bb_rcglast314:
  %v1052 = load i64, ptr %slot183, align 8
  %op1053 = sub i64 %v1052, 24
  store i64 %op1053, ptr %slot193, align 8
  %v1054 = load i64, ptr %slot183, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  %rgep1056 = getelementptr i8, ptr %p1055, i64 -24
  %ld1057 = load i64, ptr %rgep1056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1057, ptr %slot194, align 8
  %v1058 = load i64, ptr %slot194, align 8
  %cmp1059 = icmp ne i64 %v1058, 0
  %cv1060 = zext i1 %cmp1059 to i32
  store i32 %cv1060, ptr %slot195, align 8
  %v1061 = load i32, ptr %slot195, align 8
  %cv1062 = zext i32 %v1061 to i64
  %cond1063 = icmp ne i64 %cv1062, 0
  br i1 %cond1063, label %bb_rcgdec314, label %bb_rcgslow314
bb_rcgslow314:
  %v1064 = load i64, ptr %slot182, align 8
  %v1065 = load i64, ptr %slot165, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1064, i64 %v1065) nomerge, !dbg !122
  br label %bb_rcgdone314
bb_rcgdec314:
  %v1066 = load i64, ptr %slot191, align 8
  %v1067 = load i64, ptr %slot183, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  %rgep1069 = getelementptr i8, ptr %p1068, i64 -32
  store i64 %v1066, ptr %rgep1069, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear314
bb_rcgclear314:
  %v1070 = load i64, ptr %slot165, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  store i64 0, ptr %p1071, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone314
bb_rcgdone314:
  br label %bb_rcslotdone283
bb_rcslotdone283:
  %v1072 = load i64, ptr %slot22, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  store i64 0, ptr %p1073, align 8, !alias.scope !3, !noalias !4
  %v1074 = load i64, ptr %slot22, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  %ld1076 = load i64, ptr %p1075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1076, ptr %slot196, align 8
  %v1077 = load i64, ptr %slot196, align 8
  %v1078 = load i64, ptr %slot19, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  store i64 %v1077, ptr %p1079, align 8, !alias.scope !3, !noalias !4
  %v1080 = load i64, ptr %slot18, align 8
  %v1081 = load i64, ptr %slot22, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i64 %v1080, ptr %p1082, align 8, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot22, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  %ld1085 = load i64, ptr %p1084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1085, ptr %slot197, align 8
  %v1086 = load i64, ptr %slot197, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  %ld1088 = load i32, ptr %p1087, align 4, !alias.scope !3, !noalias !4
  %ext1089 = zext i32 %ld1088 to i64
  store i64 %ext1089, ptr %slot198, align 8
  %v1090 = load i64, ptr %slot198, align 8
  %cmp1091 = icmp eq i64 %v1090, 0
  %cv1092 = zext i1 %cmp1091 to i64
  store i64 %cv1092, ptr %slot199, align 8
  %v1093 = load i64, ptr %slot199, align 8
  %cond1094 = icmp ne i64 %v1093, 0
  br i1 %cond1094, label %bb_rcarm321, label %bb_rcarmnext321
bb_rcarm321:
  br label %bb_i21
bb_rcarmnext321:
  %v1095 = load i64, ptr %slot198, align 8
  %cmp1096 = icmp eq i64 %v1095, 1
  %cv1097 = zext i1 %cmp1096 to i64
  store i64 %cv1097, ptr %slot200, align 8
  %v1098 = load i64, ptr %slot200, align 8
  %cond1099 = icmp ne i64 %v1098, 0
  br i1 %cond1099, label %bb_rcarm322, label %bb_rcarmnext322
bb_rcarm322:
  %v1100 = load i64, ptr %slot13, align 8
  store i64 %v1100, ptr %slot201, align 8
  %v1101 = load i64, ptr %slot197, align 8
  %op1102 = add i64 %v1101, 8
  store i64 %op1102, ptr %slot202, align 8
  %v1103 = load i64, ptr %slot32, align 8
  store i64 %v1103, ptr %slot203, align 8
  %v1104 = load i64, ptr %slot202, align 8
  %p1105 = inttoptr i64 %v1104 to ptr
  %ld1106 = load i64, ptr %p1105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1106, ptr %slot204, align 8
  %v1107 = load i64, ptr %slot204, align 8
  %v1108 = load i64, ptr %slot201, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  store i64 %v1107, ptr %p1109, align 8, !alias.scope !3, !noalias !4
  %v1110 = load i64, ptr %slot10, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  store i32 0, ptr %p1111, align 4, !alias.scope !3, !noalias !4
  %v1112 = load i64, ptr %slot9, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  store i32 1, ptr %p1113, align 4, !alias.scope !3, !noalias !4
  %v1114 = load i64, ptr %slot201, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  %ld1116 = load i64, ptr %p1115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1116, ptr %slot205, align 8
  %v1117 = load i64, ptr %slot205, align 8
  %v1118 = load i64, ptr %slot20, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i64 %v1117, ptr %p1119, align 8, !alias.scope !3, !noalias !4
  %v1120 = load i64, ptr %slot9, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  store i32 0, ptr %p1121, align 4, !alias.scope !3, !noalias !4
  br label %bb_i20
bb_rcarmnext322:
  br label %bb_failure
bb_i20:
  br label %bb_i24
bb_i21:
  %v1122 = load i64, ptr %slot19, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  %ld1124 = load i64, ptr %p1123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1124, ptr %slot206, align 8
  %v1125 = load i64, ptr %slot206, align 8
  %v1126 = load i64, ptr %slot22, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  store i64 %v1125, ptr %p1127, align 8, !alias.scope !3, !noalias !4
  %v1128 = load i64, ptr %slot22, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %ld1130 = load i64, ptr %p1129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1130, ptr %slot207, align 8
  %v1131 = load i64, ptr %slot207, align 8
  %v1132 = load i64, ptr %slot20, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  store i64 %v1131, ptr %p1133, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i24:
  %v1134 = load i64, ptr %slot20, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  %ld1136 = load i64, ptr %p1135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1136, ptr %slot208, align 8
  %v1137 = load i64, ptr %slot208, align 8
  %v1138 = load i64, ptr %slot22, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i64 %v1137, ptr %p1139, align 8, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot22, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i64, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1142, ptr %slot209, align 8
  %v1143 = load i64, ptr %slot209, align 8
  %v1144 = load i64, ptr %slot21, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  store i64 %v1143, ptr %p1145, align 8, !alias.scope !3, !noalias !4
  %v1146 = load i64, ptr %slot15, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  %ld1148 = load i64, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1148, ptr %slot210, align 8
  %v1149 = load i64, ptr %slot210, align 8
  %v1150 = load i64, ptr %slot22, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  store i64 %v1149, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  %v1152 = load i64, ptr %slot21, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  %ld1154 = load i64, ptr %p1153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1154, ptr %slot211, align 8
  %v1155 = load i64, ptr %slot211, align 8
  %v1156 = load i64, ptr %slot23, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  store i64 %v1155, ptr %p1157, align 8, !alias.scope !3, !noalias !4
  %v1158 = load i64, ptr %slot25, align 8
  store i64 %v1158, ptr %slot212, align 8
  %v1159 = load i64, ptr %slot212, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  store i64 0, ptr %p1160, align 8, !alias.scope !3, !noalias !4
  %v1161 = load i64, ptr %slot212, align 8
  %p1163 = inttoptr i64 %v1161 to ptr
  %gep1164 = getelementptr i8, ptr %p1163, i64 8
  %op1162 = ptrtoint ptr %gep1164 to i64
  store i64 %op1162, ptr %slot213, align 8
  %v1165 = load i64, ptr %slot213, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  store i64 0, ptr %p1166, align 8, !alias.scope !3, !noalias !4
  %v1167 = load i64, ptr %slot212, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i32 2, ptr %p1168, align 4, !alias.scope !3, !noalias !4
  %v1169 = load i64, ptr %slot11, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  store i32 1, ptr %p1170, align 4, !alias.scope !3, !noalias !4
  %v1171 = load i64, ptr %slot23, align 8
  store i64 %v1171, ptr %slot214, align 8
  %v1172 = load i64, ptr %slot212, align 8
  %p1174 = inttoptr i64 %v1172 to ptr
  %gep1175 = getelementptr i8, ptr %p1174, i64 8
  %op1173 = ptrtoint ptr %gep1175 to i64
  store i64 %op1173, ptr %slot215, align 8
  %v1176 = load i64, ptr %slot32, align 8
  store i64 %v1176, ptr %slot216, align 8
  %v1177 = load i64, ptr %slot214, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %ld1179 = load i64, ptr %p1178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1179, ptr %slot217, align 8
  %v1180 = load i64, ptr %slot217, align 8
  %v1181 = load i64, ptr %slot215, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  store i64 %v1180, ptr %p1182, align 8, !alias.scope !3, !noalias !4
  %v1183 = load i64, ptr %slot212, align 8
  %v1184 = load i64, ptr %slot23, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  store i64 %v1183, ptr %p1185, align 8, !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot22, align 8
  %p1187 = inttoptr i64 %v1186 to ptr
  %ld1188 = load i64, ptr %p1187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1188, ptr %slot218, align 8
  %v1189 = load i64, ptr %slot23, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  %ld1191 = load i64, ptr %p1190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1191, ptr %slot219, align 8
  %v1192 = load i64, ptr %slot1, align 8
  %v1193 = load i64, ptr %slot218, align 8
  %v1194 = load i64, ptr %slot219, align 8
  %call1195 = call i64 @myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365(i64 %v1192, i64 %v1193, i64 %v1194) nomerge, !dbg !124
  store i64 %call1195, ptr %slot220, align 8
  %v1196 = load i64, ptr %slot220, align 8
  %v1197 = load i64, ptr %slot22, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  store i64 %v1196, ptr %p1198, align 8, !alias.scope !3, !noalias !4
  %v1199 = load i64, ptr %slot22, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  store i64 0, ptr %p1200, align 8, !alias.scope !3, !noalias !4
  %v1201 = load i64, ptr %slot22, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %ld1203 = load i64, ptr %p1202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1203, ptr %slot221, align 8
  %v1204 = load i64, ptr %slot6, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  %ld1206 = load i32, ptr %p1205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1206, ptr %slot222, align 8
  %v1207 = load i32, ptr %slot222, align 8
  %cv1208 = zext i32 %v1207 to i64
  %cond1209 = icmp ne i64 %cv1208, 0
  br i1 %cond1209, label %bb_rcslotdrop363, label %bb_rcslotdone363
bb_rcslotdrop363:
  %v1210 = load i64, ptr %slot6, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i32 0, ptr %p1211, align 4, !alias.scope !3, !noalias !4
  %v1212 = load i64, ptr %slot17, align 8
  store i64 %v1212, ptr %slot223, align 8
  %v1213 = load i64, ptr %slot7, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i32, ptr %p1214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1215, ptr %slot224, align 8
  %v1216 = load i32, ptr %slot224, align 8
  %op1217 = and i32 %v1216, 28
  store i32 %op1217, ptr %slot225, align 8
  %v1218 = load i32, ptr %slot225, align 8
  %cv1219 = zext i32 %v1218 to i64
  %cond1220 = icmp ne i64 %cv1219, 0
  br i1 %cond1220, label %bb_rcslotrole363, label %bb_rcslotowner363
bb_rcslotrole363:
  %v1221 = load i64, ptr %slot31, align 8
  store i64 %v1221, ptr %slot226, align 8
  %v1222 = load i64, ptr %slot223, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  %ld1224 = load i64, ptr %p1223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1224, ptr %slot227, align 8
  %v1225 = load i64, ptr %slot227, align 8
  %cmp1226 = icmp ne i64 %v1225, 0
  %cv1227 = zext i1 %cmp1226 to i32
  store i32 %cv1227, ptr %slot228, align 8
  %v1228 = load i32, ptr %slot228, align 8
  %cv1229 = zext i32 %v1228 to i64
  %cond1230 = icmp ne i64 %cv1229, 0
  br i1 %cond1230, label %bb_rcgnn379, label %bb_rcgdone379
bb_rcgnn379:
  %v1231 = load i64, ptr %slot227, align 8
  %op1232 = sub i64 %v1231, 16
  store i64 %op1232, ptr %slot229, align 8
  %v1233 = load i64, ptr %slot227, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  %rgep1235 = getelementptr i8, ptr %p1234, i64 -16
  %ld1236 = load i64, ptr %rgep1235, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1236, ptr %slot230, align 8
  %v1237 = load i64, ptr %slot230, align 8
  %op1238 = and i64 %v1237, 4611686018427387906
  store i64 %op1238, ptr %slot231, align 8
  %v1239 = load i64, ptr %slot231, align 8
  %cmp1240 = icmp ne i64 %v1239, 0
  %cv1241 = zext i1 %cmp1240 to i32
  store i32 %cv1241, ptr %slot232, align 8
  %v1242 = load i32, ptr %slot232, align 8
  %cv1243 = zext i32 %v1242 to i64
  %cond1244 = icmp ne i64 %cv1243, 0
  br i1 %cond1244, label %bb_rcgclear379, label %bb_rcgcounted379
bb_rcgcounted379:
  %v1245 = load i64, ptr %slot227, align 8
  %op1246 = sub i64 %v1245, 24
  store i64 %op1246, ptr %slot233, align 8
  %v1247 = load i64, ptr %slot227, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  %rgep1249 = getelementptr i8, ptr %p1248, i64 -24
  %ld1250 = load i64, ptr %rgep1249, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1250, ptr %slot234, align 8
  %v1251 = load i64, ptr %slot234, align 8
  %op1252 = sub i64 %v1251, 1
  store i64 %op1252, ptr %slot235, align 8
  %v1253 = load i64, ptr %slot235, align 8
  %cmp1254 = icmp eq i64 %v1253, 0
  %cv1255 = zext i1 %cmp1254 to i32
  store i32 %cv1255, ptr %slot236, align 8
  %v1256 = load i32, ptr %slot236, align 8
  %cv1257 = zext i32 %v1256 to i64
  %cond1258 = icmp ne i64 %cv1257, 0
  br i1 %cond1258, label %bb_rcglast379, label %bb_rcgdec379
bb_rcglast379:
  %v1259 = load i64, ptr %slot227, align 8
  %op1260 = sub i64 %v1259, 32
  store i64 %op1260, ptr %slot237, align 8
  %v1261 = load i64, ptr %slot227, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %rgep1263 = getelementptr i8, ptr %p1262, i64 -32
  %ld1264 = load i64, ptr %rgep1263, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1264, ptr %slot238, align 8
  %v1265 = load i64, ptr %slot238, align 8
  %cmp1266 = icmp ne i64 %v1265, 0
  %cv1267 = zext i1 %cmp1266 to i32
  store i32 %cv1267, ptr %slot239, align 8
  %v1268 = load i32, ptr %slot239, align 8
  %cv1269 = zext i32 %v1268 to i64
  %cond1270 = icmp ne i64 %cv1269, 0
  br i1 %cond1270, label %bb_rcgdec379, label %bb_rcgslow379
bb_rcgslow379:
  %v1271 = load i64, ptr %slot226, align 8
  %v1272 = load i64, ptr %slot223, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1271, i64 %v1272) nomerge, !dbg !126
  br label %bb_rcgdone379
bb_rcgdec379:
  %v1273 = load i64, ptr %slot235, align 8
  %v1274 = load i64, ptr %slot227, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  %rgep1276 = getelementptr i8, ptr %p1275, i64 -24
  store i64 %v1273, ptr %rgep1276, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear379
bb_rcgclear379:
  %v1277 = load i64, ptr %slot223, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  store i64 0, ptr %p1278, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone379
bb_rcgdone379:
  br label %bb_rcslotdone363
bb_rcslotowner363:
  %v1279 = load i64, ptr %slot31, align 8
  store i64 %v1279, ptr %slot240, align 8
  %v1280 = load i64, ptr %slot223, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  %ld1282 = load i64, ptr %p1281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1282, ptr %slot241, align 8
  %v1283 = load i64, ptr %slot241, align 8
  %cmp1284 = icmp ne i64 %v1283, 0
  %cv1285 = zext i1 %cmp1284 to i32
  store i32 %cv1285, ptr %slot242, align 8
  %v1286 = load i32, ptr %slot242, align 8
  %cv1287 = zext i32 %v1286 to i64
  %cond1288 = icmp ne i64 %cv1287, 0
  br i1 %cond1288, label %bb_rcgnn394, label %bb_rcgdone394
bb_rcgnn394:
  %v1289 = load i64, ptr %slot241, align 8
  %op1290 = sub i64 %v1289, 16
  store i64 %op1290, ptr %slot243, align 8
  %v1291 = load i64, ptr %slot241, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  %rgep1293 = getelementptr i8, ptr %p1292, i64 -16
  %ld1294 = load i64, ptr %rgep1293, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1294, ptr %slot244, align 8
  %v1295 = load i64, ptr %slot244, align 8
  %op1296 = and i64 %v1295, 4611686018427387906
  store i64 %op1296, ptr %slot245, align 8
  %v1297 = load i64, ptr %slot245, align 8
  %cmp1298 = icmp ne i64 %v1297, 0
  %cv1299 = zext i1 %cmp1298 to i32
  store i32 %cv1299, ptr %slot246, align 8
  %v1300 = load i32, ptr %slot246, align 8
  %cv1301 = zext i32 %v1300 to i64
  %cond1302 = icmp ne i64 %cv1301, 0
  br i1 %cond1302, label %bb_rcgclear394, label %bb_rcgcounted394
bb_rcgcounted394:
  %v1303 = load i64, ptr %slot241, align 8
  %op1304 = sub i64 %v1303, 32
  store i64 %op1304, ptr %slot247, align 8
  %v1305 = load i64, ptr %slot241, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %rgep1307 = getelementptr i8, ptr %p1306, i64 -32
  %ld1308 = load i64, ptr %rgep1307, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1308, ptr %slot248, align 8
  %v1309 = load i64, ptr %slot248, align 8
  %op1310 = sub i64 %v1309, 1
  store i64 %op1310, ptr %slot249, align 8
  %v1311 = load i64, ptr %slot249, align 8
  %cmp1312 = icmp eq i64 %v1311, 0
  %cv1313 = zext i1 %cmp1312 to i32
  store i32 %cv1313, ptr %slot250, align 8
  %v1314 = load i32, ptr %slot250, align 8
  %cv1315 = zext i32 %v1314 to i64
  %cond1316 = icmp ne i64 %cv1315, 0
  br i1 %cond1316, label %bb_rcglast394, label %bb_rcgdec394
bb_rcglast394:
  %v1317 = load i64, ptr %slot241, align 8
  %op1318 = sub i64 %v1317, 24
  store i64 %op1318, ptr %slot251, align 8
  %v1319 = load i64, ptr %slot241, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  %rgep1321 = getelementptr i8, ptr %p1320, i64 -24
  %ld1322 = load i64, ptr %rgep1321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1322, ptr %slot252, align 8
  %v1323 = load i64, ptr %slot252, align 8
  %cmp1324 = icmp ne i64 %v1323, 0
  %cv1325 = zext i1 %cmp1324 to i32
  store i32 %cv1325, ptr %slot253, align 8
  %v1326 = load i32, ptr %slot253, align 8
  %cv1327 = zext i32 %v1326 to i64
  %cond1328 = icmp ne i64 %cv1327, 0
  br i1 %cond1328, label %bb_rcgdec394, label %bb_rcgslow394
bb_rcgslow394:
  %v1329 = load i64, ptr %slot240, align 8
  %v1330 = load i64, ptr %slot223, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1329, i64 %v1330) nomerge, !dbg !126
  br label %bb_rcgdone394
bb_rcgdec394:
  %v1331 = load i64, ptr %slot249, align 8
  %v1332 = load i64, ptr %slot241, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  %rgep1334 = getelementptr i8, ptr %p1333, i64 -32
  store i64 %v1331, ptr %rgep1334, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear394
bb_rcgclear394:
  %v1335 = load i64, ptr %slot223, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  store i64 0, ptr %p1336, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone394
bb_rcgdone394:
  br label %bb_rcslotdone363
bb_rcslotdone363:
  %v1337 = load i64, ptr %slot4, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  %ld1339 = load i32, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1339, ptr %slot254, align 8
  %v1340 = load i32, ptr %slot254, align 8
  %cv1341 = zext i32 %v1340 to i64
  %cond1342 = icmp ne i64 %cv1341, 0
  br i1 %cond1342, label %bb_rcslotdrop400, label %bb_rcslotdone400
bb_rcslotdrop400:
  %v1343 = load i64, ptr %slot4, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  store i32 0, ptr %p1344, align 4, !alias.scope !3, !noalias !4
  %v1345 = load i64, ptr %slot16, align 8
  store i64 %v1345, ptr %slot255, align 8
  %v1346 = load i64, ptr %slot5, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %ld1348 = load i32, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1348, ptr %slot256, align 8
  %v1349 = load i32, ptr %slot256, align 8
  %op1350 = and i32 %v1349, 28
  store i32 %op1350, ptr %slot257, align 8
  %v1351 = load i32, ptr %slot257, align 8
  %cv1352 = zext i32 %v1351 to i64
  %cond1353 = icmp ne i64 %cv1352, 0
  br i1 %cond1353, label %bb_rcslotrole400, label %bb_rcslotowner400
bb_rcslotrole400:
  %v1354 = load i64, ptr %slot31, align 8
  store i64 %v1354, ptr %slot258, align 8
  %v1355 = load i64, ptr %slot258, align 8
  %v1356 = load i64, ptr %slot255, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1355, i64 %v1356) nomerge, !dbg !126
  br label %bb_rcslotdone400
bb_rcslotowner400:
  %v1357 = load i64, ptr %slot31, align 8
  store i64 %v1357, ptr %slot259, align 8
  %v1358 = load i64, ptr %slot259, align 8
  %v1359 = load i64, ptr %slot255, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1358, i64 %v1359) nomerge, !dbg !126
  br label %bb_rcslotdone400
bb_rcslotdone400:
  %v1360 = load i64, ptr %slot221, align 8
  ret i64 %v1360
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365(i64, i64, i64)
declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_bytes_range(ptr, i64, i64, ptr)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_2ebb09da19ad16997dccbe29951fffb7732b9a85aecee0e00a2bd8e0128061f9", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_2ebb09da19ad16997dccbe29951fffb7732b9a85aecee0e00a2bd8e0128061f9", linkageName: "myl_f_2ebb09da19ad16997dccbe29951fffb7732b9a85aecee0e00a2bd8e0128061f9", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1042106034358618563, i64 0, !"myl_f_2ebb09da19ad16997dccbe29951fffb7732b9a85aecee0e00a2bd8e0128061f9"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!122 = !DILocation(line: 15, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!124 = !DILocation(line: 30, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!126 = !DILocation(line: 33, column: 0, scope: !127)
