target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %callresult30 = alloca [16 x i8], align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %callresult92 = alloca [16 x i8], align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v107 = load i64, ptr %slot1, align 8
  %op108 = add i64 %v107, 32
  store i64 %op108, ptr %slot4, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot5, align 8
  %mem111 = alloca i8, i64 8, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot6, align 8
  %mem113 = alloca i8, i64 8, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot7, align 8
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot8, align 8
  %mem117 = alloca i8, i64 8, align 8
  %ptr118 = ptrtoint ptr %mem117 to i64
  store i64 %ptr118, ptr %slot9, align 8
  %mem119 = alloca i8, i64 8, align 8
  %ptr120 = ptrtoint ptr %mem119 to i64
  store i64 %ptr120, ptr %slot10, align 8
  %mem121 = alloca i8, i64 8, align 8
  %ptr122 = ptrtoint ptr %mem121 to i64
  store i64 %ptr122, ptr %slot11, align 8
  %mem123 = alloca i8, i64 208, align 8
  %ptr124 = ptrtoint ptr %mem123 to i64
  store i64 %ptr124, ptr %slot12, align 8
  %mem125 = alloca i8, i64 8, align 8
  %ptr126 = ptrtoint ptr %mem125 to i64
  store i64 %ptr126, ptr %slot13, align 8
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot14, align 8
  %mem129 = alloca i8, i64 16, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot15, align 8
  %mem131 = alloca i8, i64 8, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot16, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot17, align 8
  %mem135 = alloca i8, i64 8, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot18, align 8
  %mem137 = alloca i8, i64 208, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot19, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot20, align 8
  %v141 = load i64, ptr %slot1, align 8
  %op142 = add i64 %v141, 64
  store i64 %op142, ptr %slot21, align 8
  %v143 = load i64, ptr %slot21, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %ld145 = load i64, ptr %p144, align 8, !alias.scope !4, !noalias !3
  store i64 %ld145, ptr %slot22, align 8
  %stack146 = call ptr @llvm.stacksave()
  %stackaddr147 = ptrtoint ptr %stack146 to i64
  %v148 = load i64, ptr %slot22, align 8
  %cmp149 = icmp ult i64 %stackaddr147, %v148
  %cv150 = zext i1 %cmp149 to i64
  store i64 %cv150, ptr %slot23, align 8
  %v151 = load i64, ptr %slot23, align 8
  %cond152 = icmp ne i64 %v151, 0
  br i1 %cond152, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v153 = load i64, ptr %slot1, align 8
  %p154 = inttoptr i64 %v153 to ptr
  call void @myl_qbe_fail_frame(ptr %p154) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v155 = load i64, ptr %slot2, align 8
  %v156 = load i64, ptr %slot13, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 %v155, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot3, align 8
  %v159 = load i64, ptr %slot14, align 8
  %p160 = inttoptr i64 %v159 to ptr
  store i64 %v158, ptr %p160, align 8, !alias.scope !3, !noalias !4
  %v161 = load i64, ptr %slot1, align 8
  %p162 = inttoptr i64 %v161 to ptr
  %call163 = call ptr @myl_qbe_heap(ptr %p162) nomerge, !dbg !112
  %calladdr164 = ptrtoint ptr %call163 to i64
  store i64 %calladdr164, ptr %slot24, align 8
  %v165 = load i64, ptr %slot1, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %call167 = call i64 @myl_qbe_region_mark(ptr %p166) nomerge, !dbg !112
  store i64 %call167, ptr %slot25, align 8
  %v168 = load i64, ptr %slot5, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i32 0, ptr %p169, align 4, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot6, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i32 0, ptr %p171, align 4, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot7, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i32 0, ptr %p173, align 4, !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot8, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i32 0, ptr %p175, align 4, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot9, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i32 0, ptr %p177, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v178 = load i64, ptr %slot13, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot26, align 8
  %v181 = load i64, ptr %slot26, align 8
  %v182 = load i64, ptr %slot16, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot17, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i64 0, ptr %p185, align 8, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot16, align 8
  %p187 = inttoptr i64 %v186 to ptr
  %ld188 = load i64, ptr %p187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld188, ptr %slot27, align 8
  %v189 = load i64, ptr %slot17, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %ld191 = load i64, ptr %p190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld191, ptr %slot28, align 8
  %v192 = load i64, ptr %slot1, align 8
  %v193 = load i64, ptr %slot27, align 8
  %v194 = load i64, ptr %slot28, align 8
  %call195 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v192, i64 %v193, i64 %v194) nomerge, !dbg !114
  store { i64, i64 } %call195, ptr %callresult30, align 8
  %addr196 = ptrtoint ptr %callresult30 to i64
  store i64 %addr196, ptr %slot29, align 8
  %v197 = load i64, ptr %slot29, align 8
  %v198 = load i64, ptr %slot16, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i64 %v197, ptr %p199, align 8, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot16, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i64, ptr %p201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld202, ptr %slot31, align 8
  %v203 = load i64, ptr %slot31, align 8
  %v204 = load i64, ptr %slot15, align 8
  %p205 = inttoptr i64 %v203 to ptr
  %p206 = inttoptr i64 %v204 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p206, ptr %p205, i64 16, i1 false)
  %v207 = load i64, ptr %slot15, align 8
  %v208 = load i64, ptr %slot16, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i64 %v207, ptr %p209, align 8, !alias.scope !3, !noalias !4
  %v210 = load i64, ptr %slot16, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i64, ptr %p211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld212, ptr %slot32, align 8
  %v213 = load i64, ptr %slot32, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i32, ptr %p214, align 4, !alias.scope !3, !noalias !4
  %ext216 = zext i32 %ld215 to i64
  store i64 %ext216, ptr %slot33, align 8
  %v217 = load i64, ptr %slot33, align 8
  %cmp218 = icmp eq i64 %v217, 0
  %cv219 = zext i1 %cmp218 to i64
  store i64 %cv219, ptr %slot34, align 8
  %v220 = load i64, ptr %slot34, align 8
  %cond221 = icmp ne i64 %v220, 0
  br i1 %cond221, label %bb_rcarm25, label %bb_rcarmnext25
bb_rcarm25:
  br label %bb_i8
bb_rcarmnext25:
  %v222 = load i64, ptr %slot33, align 8
  %cmp223 = icmp eq i64 %v222, 1
  %cv224 = zext i1 %cmp223 to i64
  store i64 %cv224, ptr %slot35, align 8
  %v225 = load i64, ptr %slot35, align 8
  %cond226 = icmp ne i64 %v225, 0
  br i1 %cond226, label %bb_rcarm26, label %bb_rcarmnext26
bb_rcarm26:
  br label %bb_i10
bb_rcarmnext26:
  %v227 = load i64, ptr %slot33, align 8
  %cmp228 = icmp eq i64 %v227, 2
  %cv229 = zext i1 %cmp228 to i64
  store i64 %cv229, ptr %slot36, align 8
  %v230 = load i64, ptr %slot36, align 8
  %cond231 = icmp ne i64 %v230, 0
  br i1 %cond231, label %bb_rcarm27, label %bb_rcarmnext27
bb_rcarm27:
  br label %bb_i6
bb_rcarmnext27:
  %v232 = load i64, ptr %slot33, align 8
  %cmp233 = icmp eq i64 %v232, 3
  %cv234 = zext i1 %cmp233 to i64
  store i64 %cv234, ptr %slot37, align 8
  %v235 = load i64, ptr %slot37, align 8
  %cond236 = icmp ne i64 %v235, 0
  br i1 %cond236, label %bb_rcarm28, label %bb_rcarmnext28
bb_rcarm28:
  br label %bb_i12
bb_rcarmnext28:
  br label %bb_failure
bb_i6:
  %v237 = load i64, ptr %slot16, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 1, ptr %p238, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i8:
  %v239 = load i64, ptr %slot16, align 8
  %p240 = inttoptr i64 %v239 to ptr
  store i64 0, ptr %p240, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i10:
  %v241 = load i64, ptr %slot16, align 8
  %p242 = inttoptr i64 %v241 to ptr
  store i64 0, ptr %p242, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i12:
  %v243 = load i64, ptr %slot16, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i64 0, ptr %p244, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v245 = load i64, ptr %slot16, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %ld247 = load i64, ptr %p246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld247, ptr %slot38, align 8
  %v248 = load i64, ptr %slot38, align 8
  %op249 = xor i64 %v248, 1
  store i64 %op249, ptr %slot39, align 8
  %v250 = load i64, ptr %slot39, align 8
  %v251 = load i64, ptr %slot16, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i64 %v250, ptr %p252, align 8, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot16, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i64, ptr %p254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld255, ptr %slot40, align 8
  %v256 = load i64, ptr %slot40, align 8
  %cond257 = icmp ne i64 %v256, 0
  br i1 %cond257, label %bb_next32, label %bb_i21
bb_next32:
  %v258 = load i64, ptr %slot13, align 8
  %p259 = inttoptr i64 %v258 to ptr
  %ld260 = load i64, ptr %p259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld260, ptr %slot41, align 8
  %v261 = load i64, ptr %slot41, align 8
  %v262 = load i64, ptr %slot16, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i64 %v261, ptr %p263, align 8, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot14, align 8
  %p265 = inttoptr i64 %v264 to ptr
  %ld266 = load i64, ptr %p265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld266, ptr %slot42, align 8
  %v267 = load i64, ptr %slot42, align 8
  %v268 = load i64, ptr %slot17, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i64 %v267, ptr %p269, align 8, !alias.scope !3, !noalias !4
  %p270 = inttoptr i64 ptrtoint (ptr @myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5 to i64) to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !4, !noalias !3
  store i64 %ld271, ptr %slot43, align 8
  %v272 = load i64, ptr %slot43, align 8
  %v273 = load i64, ptr %slot18, align 8
  %p274 = inttoptr i64 %v273 to ptr
  store i64 %v272, ptr %p274, align 8, !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot18, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ld277 = load i64, ptr %p276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld277, ptr %slot44, align 8
  %v278 = load i64, ptr %slot44, align 8
  %v279 = load i64, ptr %slot11, align 8
  %p280 = inttoptr i64 %v279 to ptr
  store i64 %v278, ptr %p280, align 8, !alias.scope !3, !noalias !4
  %v281 = load i64, ptr %slot11, align 8
  store i64 %v281, ptr %slot45, align 8
  %v282 = load i64, ptr %slot12, align 8
  store i64 %v282, ptr %slot46, align 8
  %v283 = load i64, ptr %slot45, align 8
  %v284 = load i64, ptr %slot46, align 8
  %p285 = inttoptr i64 %v283 to ptr
  %p286 = inttoptr i64 %v284 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p286, ptr %p285, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot8, align 8
  %p288 = inttoptr i64 %v287 to ptr
  store i32 2, ptr %p288, align 4, !alias.scope !3, !noalias !4
  %v289 = load i64, ptr %slot7, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i32 1, ptr %p290, align 4, !alias.scope !3, !noalias !4
  %v291 = load i64, ptr %slot10, align 8
  store i64 %v291, ptr %slot47, align 8
  %v292 = load i64, ptr %slot12, align 8
  store i64 %v292, ptr %slot48, align 8
  %v293 = load i64, ptr %slot48, align 8
  %v294 = load i64, ptr %slot47, align 8
  %p295 = inttoptr i64 %v293 to ptr
  %p296 = inttoptr i64 %v294 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p296, ptr %p295, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot6, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i32 2, ptr %p298, align 4, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot8, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i32, ptr %p300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld301, ptr %slot49, align 8
  %v302 = load i32, ptr %slot49, align 8
  %v303 = load i64, ptr %slot6, align 8
  %p304 = inttoptr i64 %v303 to ptr
  store i32 %v302, ptr %p304, align 4, !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot7, align 8
  %p306 = inttoptr i64 %v305 to ptr
  store i32 0, ptr %p306, align 4, !alias.scope !3, !noalias !4
  %v307 = load i64, ptr %slot5, align 8
  %p308 = inttoptr i64 %v307 to ptr
  store i32 1, ptr %p308, align 4, !alias.scope !3, !noalias !4
  %v309 = load i64, ptr %slot47, align 8
  %p310 = inttoptr i64 %v309 to ptr
  %ld311 = load i64, ptr %p310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld311, ptr %slot50, align 8
  %v312 = load i64, ptr %slot50, align 8
  %v313 = load i64, ptr %slot18, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot16, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot51, align 8
  %v318 = load i64, ptr %slot17, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %ld320 = load i64, ptr %p319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld320, ptr %slot52, align 8
  %v321 = load i64, ptr %slot18, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %ld323 = load i64, ptr %p322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld323, ptr %slot53, align 8
  %v324 = load i64, ptr %slot1, align 8
  %v325 = load i64, ptr %slot51, align 8
  %v326 = load i64, ptr %slot52, align 8
  %v327 = load i64, ptr %slot53, align 8
  %call328 = call i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64 %v324, i64 %v325, i64 %v326, i64 %v327) nomerge, !dbg !116
  store i64 %call328, ptr %slot54, align 8
  %v329 = load i64, ptr %slot54, align 8
  %v330 = load i64, ptr %slot16, align 8
  %p331 = inttoptr i64 %v330 to ptr
  store i64 %v329, ptr %p331, align 8, !alias.scope !3, !noalias !4
  %v332 = load i64, ptr %slot5, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %ld334 = load i32, ptr %p333, align 4, !alias.scope !3, !noalias !4
  store i32 %ld334, ptr %slot55, align 8
  %v335 = load i32, ptr %slot55, align 8
  %cv336 = zext i32 %v335 to i64
  %cond337 = icmp ne i64 %cv336, 0
  br i1 %cond337, label %bb_rcslotdrop74, label %bb_rcslotdone74
bb_rcslotdrop74:
  %v338 = load i64, ptr %slot5, align 8
  %p339 = inttoptr i64 %v338 to ptr
  store i32 0, ptr %p339, align 4, !alias.scope !3, !noalias !4
  %v340 = load i64, ptr %slot10, align 8
  store i64 %v340, ptr %slot56, align 8
  %v341 = load i64, ptr %slot6, align 8
  %p342 = inttoptr i64 %v341 to ptr
  %ld343 = load i32, ptr %p342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld343, ptr %slot57, align 8
  %v344 = load i32, ptr %slot57, align 8
  %op345 = and i32 %v344, 28
  store i32 %op345, ptr %slot58, align 8
  %v346 = load i32, ptr %slot58, align 8
  %cv347 = zext i32 %v346 to i64
  %cond348 = icmp ne i64 %cv347, 0
  br i1 %cond348, label %bb_rcslotrole74, label %bb_rcslotowner74
bb_rcslotrole74:
  %v349 = load i64, ptr %slot24, align 8
  store i64 %v349, ptr %slot59, align 8
  %v350 = load i64, ptr %slot56, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot60, align 8
  %v353 = load i64, ptr %slot60, align 8
  %cmp354 = icmp ne i64 %v353, 0
  %cv355 = zext i1 %cmp354 to i32
  store i32 %cv355, ptr %slot61, align 8
  %v356 = load i32, ptr %slot61, align 8
  %cv357 = zext i32 %v356 to i64
  %cond358 = icmp ne i64 %cv357, 0
  br i1 %cond358, label %bb_rcgnn90, label %bb_rcgdone90
bb_rcgnn90:
  %v359 = load i64, ptr %slot60, align 8
  %op360 = sub i64 %v359, 16
  store i64 %op360, ptr %slot62, align 8
  %v361 = load i64, ptr %slot60, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %rgep363 = getelementptr i8, ptr %p362, i64 -16
  %ld364 = load i64, ptr %rgep363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld364, ptr %slot63, align 8
  %v365 = load i64, ptr %slot63, align 8
  %op366 = and i64 %v365, 4611686018427387906
  store i64 %op366, ptr %slot64, align 8
  %v367 = load i64, ptr %slot64, align 8
  %cmp368 = icmp ne i64 %v367, 0
  %cv369 = zext i1 %cmp368 to i32
  store i32 %cv369, ptr %slot65, align 8
  %v370 = load i32, ptr %slot65, align 8
  %cv371 = zext i32 %v370 to i64
  %cond372 = icmp ne i64 %cv371, 0
  br i1 %cond372, label %bb_rcgclear90, label %bb_rcgcounted90
bb_rcgcounted90:
  %v373 = load i64, ptr %slot60, align 8
  %op374 = sub i64 %v373, 24
  store i64 %op374, ptr %slot66, align 8
  %v375 = load i64, ptr %slot60, align 8
  %p376 = inttoptr i64 %v375 to ptr
  %rgep377 = getelementptr i8, ptr %p376, i64 -24
  %ld378 = load i64, ptr %rgep377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld378, ptr %slot67, align 8
  %v379 = load i64, ptr %slot67, align 8
  %op380 = sub i64 %v379, 1
  store i64 %op380, ptr %slot68, align 8
  %v381 = load i64, ptr %slot68, align 8
  %cmp382 = icmp eq i64 %v381, 0
  %cv383 = zext i1 %cmp382 to i32
  store i32 %cv383, ptr %slot69, align 8
  %v384 = load i32, ptr %slot69, align 8
  %cv385 = zext i32 %v384 to i64
  %cond386 = icmp ne i64 %cv385, 0
  br i1 %cond386, label %bb_rcglast90, label %bb_rcgdec90
bb_rcglast90:
  %v387 = load i64, ptr %slot60, align 8
  %op388 = sub i64 %v387, 32
  store i64 %op388, ptr %slot70, align 8
  %v389 = load i64, ptr %slot60, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %rgep391 = getelementptr i8, ptr %p390, i64 -32
  %ld392 = load i64, ptr %rgep391, align 8, !alias.scope !9, !noalias !10
  store i64 %ld392, ptr %slot71, align 8
  %v393 = load i64, ptr %slot71, align 8
  %cmp394 = icmp ne i64 %v393, 0
  %cv395 = zext i1 %cmp394 to i32
  store i32 %cv395, ptr %slot72, align 8
  %v396 = load i32, ptr %slot72, align 8
  %cv397 = zext i32 %v396 to i64
  %cond398 = icmp ne i64 %cv397, 0
  br i1 %cond398, label %bb_rcgdec90, label %bb_rcgslow90
bb_rcgslow90:
  %v399 = load i64, ptr %slot59, align 8
  %v400 = load i64, ptr %slot56, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v399, i64 %v400) nomerge, !dbg !116
  br label %bb_rcgdone90
bb_rcgdec90:
  %v401 = load i64, ptr %slot68, align 8
  %v402 = load i64, ptr %slot60, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %rgep404 = getelementptr i8, ptr %p403, i64 -24
  store i64 %v401, ptr %rgep404, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear90
bb_rcgclear90:
  %v405 = load i64, ptr %slot56, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 0, ptr %p406, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone90
bb_rcgdone90:
  br label %bb_rcslotdone74
bb_rcslotowner74:
  %v407 = load i64, ptr %slot24, align 8
  store i64 %v407, ptr %slot73, align 8
  %v408 = load i64, ptr %slot56, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot74, align 8
  %v411 = load i64, ptr %slot74, align 8
  %cmp412 = icmp ne i64 %v411, 0
  %cv413 = zext i1 %cmp412 to i32
  store i32 %cv413, ptr %slot75, align 8
  %v414 = load i32, ptr %slot75, align 8
  %cv415 = zext i32 %v414 to i64
  %cond416 = icmp ne i64 %cv415, 0
  br i1 %cond416, label %bb_rcgnn105, label %bb_rcgdone105
bb_rcgnn105:
  %v417 = load i64, ptr %slot74, align 8
  %op418 = sub i64 %v417, 16
  store i64 %op418, ptr %slot76, align 8
  %v419 = load i64, ptr %slot74, align 8
  %p420 = inttoptr i64 %v419 to ptr
  %rgep421 = getelementptr i8, ptr %p420, i64 -16
  %ld422 = load i64, ptr %rgep421, align 8, !alias.scope !9, !noalias !10
  store i64 %ld422, ptr %slot77, align 8
  %v423 = load i64, ptr %slot77, align 8
  %op424 = and i64 %v423, 4611686018427387906
  store i64 %op424, ptr %slot78, align 8
  %v425 = load i64, ptr %slot78, align 8
  %cmp426 = icmp ne i64 %v425, 0
  %cv427 = zext i1 %cmp426 to i32
  store i32 %cv427, ptr %slot79, align 8
  %v428 = load i32, ptr %slot79, align 8
  %cv429 = zext i32 %v428 to i64
  %cond430 = icmp ne i64 %cv429, 0
  br i1 %cond430, label %bb_rcgclear105, label %bb_rcgcounted105
bb_rcgcounted105:
  %v431 = load i64, ptr %slot74, align 8
  %op432 = sub i64 %v431, 32
  store i64 %op432, ptr %slot80, align 8
  %v433 = load i64, ptr %slot74, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %rgep435 = getelementptr i8, ptr %p434, i64 -32
  %ld436 = load i64, ptr %rgep435, align 8, !alias.scope !9, !noalias !10
  store i64 %ld436, ptr %slot81, align 8
  %v437 = load i64, ptr %slot81, align 8
  %op438 = sub i64 %v437, 1
  store i64 %op438, ptr %slot82, align 8
  %v439 = load i64, ptr %slot82, align 8
  %cmp440 = icmp eq i64 %v439, 0
  %cv441 = zext i1 %cmp440 to i32
  store i32 %cv441, ptr %slot83, align 8
  %v442 = load i32, ptr %slot83, align 8
  %cv443 = zext i32 %v442 to i64
  %cond444 = icmp ne i64 %cv443, 0
  br i1 %cond444, label %bb_rcglast105, label %bb_rcgdec105
bb_rcglast105:
  %v445 = load i64, ptr %slot74, align 8
  %op446 = sub i64 %v445, 24
  store i64 %op446, ptr %slot84, align 8
  %v447 = load i64, ptr %slot74, align 8
  %p448 = inttoptr i64 %v447 to ptr
  %rgep449 = getelementptr i8, ptr %p448, i64 -24
  %ld450 = load i64, ptr %rgep449, align 8, !alias.scope !9, !noalias !10
  store i64 %ld450, ptr %slot85, align 8
  %v451 = load i64, ptr %slot85, align 8
  %cmp452 = icmp ne i64 %v451, 0
  %cv453 = zext i1 %cmp452 to i32
  store i32 %cv453, ptr %slot86, align 8
  %v454 = load i32, ptr %slot86, align 8
  %cv455 = zext i32 %v454 to i64
  %cond456 = icmp ne i64 %cv455, 0
  br i1 %cond456, label %bb_rcgdec105, label %bb_rcgslow105
bb_rcgslow105:
  %v457 = load i64, ptr %slot73, align 8
  %v458 = load i64, ptr %slot56, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v457, i64 %v458) nomerge, !dbg !116
  br label %bb_rcgdone105
bb_rcgdec105:
  %v459 = load i64, ptr %slot82, align 8
  %v460 = load i64, ptr %slot74, align 8
  %p461 = inttoptr i64 %v460 to ptr
  %rgep462 = getelementptr i8, ptr %p461, i64 -32
  store i64 %v459, ptr %rgep462, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear105
bb_rcgclear105:
  %v463 = load i64, ptr %slot56, align 8
  %p464 = inttoptr i64 %v463 to ptr
  store i64 0, ptr %p464, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone105
bb_rcgdone105:
  br label %bb_rcslotdone74
bb_rcslotdone74:
  %v465 = load i64, ptr %slot16, align 8
  %p466 = inttoptr i64 %v465 to ptr
  %ld467 = load i64, ptr %p466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld467, ptr %slot87, align 8
  %v468 = load i64, ptr %slot87, align 8
  ret i64 %v468
bb_i21:
  %v469 = load i64, ptr %slot13, align 8
  %p470 = inttoptr i64 %v469 to ptr
  %ld471 = load i64, ptr %p470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld471, ptr %slot88, align 8
  %v472 = load i64, ptr %slot88, align 8
  %v473 = load i64, ptr %slot16, align 8
  %p474 = inttoptr i64 %v473 to ptr
  store i64 %v472, ptr %p474, align 8, !alias.scope !3, !noalias !4
  %v475 = load i64, ptr %slot13, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %ld477 = load i64, ptr %p476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld477, ptr %slot89, align 8
  %v478 = load i64, ptr %slot89, align 8
  %v479 = load i64, ptr %slot17, align 8
  %p480 = inttoptr i64 %v479 to ptr
  store i64 %v478, ptr %p480, align 8, !alias.scope !3, !noalias !4
  %v481 = load i64, ptr %slot17, align 8
  %p482 = inttoptr i64 %v481 to ptr
  %ld483 = load i64, ptr %p482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld483, ptr %slot90, align 8
  %v484 = load i64, ptr %slot1, align 8
  %v485 = load i64, ptr %slot90, align 8
  %call486 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v484, i64 %v485) nomerge, !dbg !118
  store { i64, i64 } %call486, ptr %callresult92, align 8
  %addr487 = ptrtoint ptr %callresult92 to i64
  store i64 %addr487, ptr %slot91, align 8
  %v488 = load i64, ptr %slot91, align 8
  %v489 = load i64, ptr %slot17, align 8
  %p490 = inttoptr i64 %v489 to ptr
  store i64 %v488, ptr %p490, align 8, !alias.scope !3, !noalias !4
  %v491 = load i64, ptr %slot17, align 8
  %p492 = inttoptr i64 %v491 to ptr
  %ld493 = load i64, ptr %p492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld493, ptr %slot93, align 8
  %v494 = load i64, ptr %slot1, align 8
  %v495 = load i64, ptr %slot93, align 8
  %call496 = call i64 @myl_f_6e2f64922337cac03073da8a803005d3f98411163e7fbfe2a99d9b810772fc10(i64 %v494, i64 %v495) nomerge, !dbg !120
  store i64 %call496, ptr %slot94, align 8
  %v497 = load i64, ptr %slot94, align 8
  %v498 = load i64, ptr %slot17, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i64 %v497, ptr %p499, align 8, !alias.scope !3, !noalias !4
  %v500 = load i64, ptr %slot17, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i64, ptr %p501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld502, ptr %slot95, align 8
  %v503 = load i64, ptr %slot1, align 8
  %p504 = inttoptr i64 %v503 to ptr
  %v505 = load i64, ptr %slot95, align 8
  %call506 = call i64 @myl_qbe_float_unary(ptr %p504, i64 7, i64 %v505) nomerge, !dbg !122
  store i64 %call506, ptr %slot96, align 8
  %v507 = load i64, ptr %slot96, align 8
  %v508 = load i64, ptr %slot17, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 %v507, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot19, align 8
  store i64 %v510, ptr %slot97, align 8
  %v511 = load i64, ptr %slot97, align 8
  %p512 = inttoptr i64 %v511 to ptr
  store i64 0, ptr %p512, align 8, !alias.scope !3, !noalias !4
  %v513 = load i64, ptr %slot97, align 8
  %p515 = inttoptr i64 %v513 to ptr
  %gep516 = getelementptr i8, ptr %p515, i64 8
  %op514 = ptrtoint ptr %gep516 to i64
  store i64 %op514, ptr %slot98, align 8
  %v517 = load i64, ptr %slot98, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i64 0, ptr %p518, align 8, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot97, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i32 2, ptr %p520, align 4, !alias.scope !3, !noalias !4
  %v521 = load i64, ptr %slot9, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i32 1, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot17, align 8
  store i64 %v523, ptr %slot99, align 8
  %v524 = load i64, ptr %slot97, align 8
  %p526 = inttoptr i64 %v524 to ptr
  %gep527 = getelementptr i8, ptr %p526, i64 8
  %op525 = ptrtoint ptr %gep527 to i64
  store i64 %op525, ptr %slot100, align 8
  %v528 = load i64, ptr %slot25, align 8
  store i64 %v528, ptr %slot101, align 8
  %v529 = load i64, ptr %slot99, align 8
  %p530 = inttoptr i64 %v529 to ptr
  %ld531 = load i64, ptr %p530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld531, ptr %slot102, align 8
  %v532 = load i64, ptr %slot102, align 8
  %v533 = load i64, ptr %slot100, align 8
  %p534 = inttoptr i64 %v533 to ptr
  store i64 %v532, ptr %p534, align 8, !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot97, align 8
  %v536 = load i64, ptr %slot17, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i64 %v535, ptr %p537, align 8, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot16, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld540, ptr %slot103, align 8
  %v541 = load i64, ptr %slot17, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i64, ptr %p542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld543, ptr %slot104, align 8
  %v544 = load i64, ptr %slot1, align 8
  %v545 = load i64, ptr %slot103, align 8
  %v546 = load i64, ptr %slot104, align 8
  %call547 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v544, i64 %v545, i64 %v546) nomerge, !dbg !124
  store i64 %call547, ptr %slot105, align 8
  %v548 = load i64, ptr %slot105, align 8
  %v549 = load i64, ptr %slot16, align 8
  %p550 = inttoptr i64 %v549 to ptr
  store i64 %v548, ptr %p550, align 8, !alias.scope !3, !noalias !4
  %v551 = load i64, ptr %slot16, align 8
  %p552 = inttoptr i64 %v551 to ptr
  store i64 1, ptr %p552, align 8, !alias.scope !3, !noalias !4
  %v553 = load i64, ptr %slot16, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i64, ptr %p554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld555, ptr %slot106, align 8
  %v556 = load i64, ptr %slot106, align 8
  ret i64 %v556
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare i64 @myl_f_6e2f64922337cac03073da8a803005d3f98411163e7fbfe2a99d9b810772fc10(i64, i64)
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64, i64, i64, i64)
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare i64 @myl_qbe_float_unary(ptr, i64, i64)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i64 @myl_qbe_region_mark(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840", linkageName: "myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1942036443634956301, i64 0, !"myl_f_6b8d2a166bbd9c248350f439dfeb2952399d529c32ecd164fee3dd015aa55840"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!116 = !DILocation(line: 20, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!118 = !DILocation(line: 24, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!120 = !DILocation(line: 25, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!122 = !DILocation(line: 27, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!124 = !DILocation(line: 30, column: 0, scope: !125)
