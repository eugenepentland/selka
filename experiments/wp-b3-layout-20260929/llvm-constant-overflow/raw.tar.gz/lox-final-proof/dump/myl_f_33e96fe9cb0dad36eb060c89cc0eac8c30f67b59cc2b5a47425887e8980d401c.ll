target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %callresult32 = alloca [16 x i8], align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v75 = load i64, ptr %slot1, align 8
  %op76 = add i64 %v75, 32
  store i64 %op76, ptr %slot5, align 8
  %mem77 = alloca i8, i64 8, align 8
  %ptr78 = ptrtoint ptr %mem77 to i64
  store i64 %ptr78, ptr %slot6, align 8
  %mem79 = alloca i8, i64 8, align 8
  %ptr80 = ptrtoint ptr %mem79 to i64
  store i64 %ptr80, ptr %slot7, align 8
  %mem81 = alloca i8, i64 8, align 8
  %ptr82 = ptrtoint ptr %mem81 to i64
  store i64 %ptr82, ptr %slot8, align 8
  %mem83 = alloca i8, i64 8, align 8
  %ptr84 = ptrtoint ptr %mem83 to i64
  store i64 %ptr84, ptr %slot9, align 8
  %mem85 = alloca i8, i64 8, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot10, align 8
  %mem87 = alloca i8, i64 56, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot11, align 8
  %mem89 = alloca i8, i64 208, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot12, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot13, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot14, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot15, align 8
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot16, align 8
  %mem99 = alloca i8, i64 8, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot17, align 8
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot18, align 8
  %mem103 = alloca i8, i64 208, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot19, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem105 = alloca i8, i64 8, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot20, align 8
  %v107 = load i64, ptr %slot1, align 8
  %op108 = add i64 %v107, 64
  store i64 %op108, ptr %slot21, align 8
  %v109 = load i64, ptr %slot21, align 8
  %p110 = inttoptr i64 %v109 to ptr
  %ld111 = load i64, ptr %p110, align 8, !alias.scope !4, !noalias !3
  store i64 %ld111, ptr %slot22, align 8
  %stack112 = call ptr @llvm.stacksave()
  %stackaddr113 = ptrtoint ptr %stack112 to i64
  %v114 = load i64, ptr %slot22, align 8
  %cmp115 = icmp ult i64 %stackaddr113, %v114
  %cv116 = zext i1 %cmp115 to i64
  store i64 %cv116, ptr %slot23, align 8
  %v117 = load i64, ptr %slot23, align 8
  %cond118 = icmp ne i64 %v117, 0
  br i1 %cond118, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v119 = load i64, ptr %slot1, align 8
  %p120 = inttoptr i64 %v119 to ptr
  call void @myl_qbe_fail_frame(ptr %p120) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v121 = load i64, ptr %slot2, align 8
  %v122 = load i64, ptr %slot13, align 8
  %p123 = inttoptr i64 %v122 to ptr
  store i64 %v121, ptr %p123, align 8, !alias.scope !3, !noalias !4
  %v124 = load i64, ptr %slot3, align 8
  %v125 = load i64, ptr %slot14, align 8
  %p126 = inttoptr i64 %v125 to ptr
  store i64 %v124, ptr %p126, align 8, !alias.scope !3, !noalias !4
  %v127 = load i64, ptr %slot4, align 8
  %v128 = load i64, ptr %slot15, align 8
  %p129 = inttoptr i64 %v128 to ptr
  store i64 %v127, ptr %p129, align 8, !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot1, align 8
  %p131 = inttoptr i64 %v130 to ptr
  %call132 = call ptr @myl_qbe_heap(ptr %p131) nomerge, !dbg !112
  %calladdr133 = ptrtoint ptr %call132 to i64
  store i64 %calladdr133, ptr %slot24, align 8
  %v134 = load i64, ptr %slot1, align 8
  %p135 = inttoptr i64 %v134 to ptr
  %call136 = call i64 @myl_qbe_region_mark(ptr %p135) nomerge, !dbg !112
  store i64 %call136, ptr %slot25, align 8
  %v137 = load i64, ptr %slot6, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i32 0, ptr %p138, align 4, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot7, align 8
  %p140 = inttoptr i64 %v139 to ptr
  store i32 0, ptr %p140, align 4, !alias.scope !3, !noalias !4
  %v141 = load i64, ptr %slot8, align 8
  %p142 = inttoptr i64 %v141 to ptr
  store i32 0, ptr %p142, align 4, !alias.scope !3, !noalias !4
  %v143 = load i64, ptr %slot9, align 8
  %p144 = inttoptr i64 %v143 to ptr
  store i32 0, ptr %p144, align 4, !alias.scope !3, !noalias !4
  %v145 = load i64, ptr %slot10, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i32 0, ptr %p146, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v147 = load i64, ptr %slot13, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot26, align 8
  %v150 = load i64, ptr %slot26, align 8
  %v151 = load i64, ptr %slot16, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i64 %v150, ptr %p152, align 8, !alias.scope !3, !noalias !4
  %v153 = load i64, ptr %slot14, align 8
  %p154 = inttoptr i64 %v153 to ptr
  %ld155 = load i64, ptr %p154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld155, ptr %slot27, align 8
  %v156 = load i64, ptr %slot27, align 8
  %v157 = load i64, ptr %slot17, align 8
  %p158 = inttoptr i64 %v157 to ptr
  store i64 %v156, ptr %p158, align 8, !alias.scope !3, !noalias !4
  %v159 = load i64, ptr %slot15, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %ld161 = load i64, ptr %p160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld161, ptr %slot28, align 8
  %v162 = load i64, ptr %slot28, align 8
  %v163 = load i64, ptr %slot18, align 8
  %p164 = inttoptr i64 %v163 to ptr
  store i64 %v162, ptr %p164, align 8, !alias.scope !3, !noalias !4
  %v165 = load i64, ptr %slot17, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld167, ptr %slot29, align 8
  %v168 = load i64, ptr %slot18, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot30, align 8
  %v171 = load i64, ptr %slot1, align 8
  %v172 = load i64, ptr %slot29, align 8
  %v173 = load i64, ptr %slot30, align 8
  %call174 = call { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64 %v171, i64 %v172, i64 %v173) nomerge, !dbg !114
  store { i64, i64 } %call174, ptr %callresult32, align 8
  %addr175 = ptrtoint ptr %callresult32 to i64
  store i64 %addr175, ptr %slot31, align 8
  %v176 = load i64, ptr %slot31, align 8
  %v177 = load i64, ptr %slot17, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i64 %v176, ptr %p178, align 8, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot17, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld181, ptr %slot33, align 8
  %v182 = load i64, ptr %slot12, align 8
  store i64 %v182, ptr %slot34, align 8
  %v183 = load i64, ptr %slot33, align 8
  %v184 = load i64, ptr %slot34, align 8
  %p185 = inttoptr i64 %v183 to ptr
  %p186 = inttoptr i64 %v184 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p186, ptr %p185, i64 16, i1 false)
  %v187 = load i64, ptr %slot9, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i32 2, ptr %p188, align 4, !alias.scope !3, !noalias !4
  %v189 = load i64, ptr %slot8, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i32 1, ptr %p190, align 4, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot11, align 8
  store i64 %v191, ptr %slot35, align 8
  %v192 = load i64, ptr %slot12, align 8
  store i64 %v192, ptr %slot36, align 8
  %v193 = load i64, ptr %slot36, align 8
  %v194 = load i64, ptr %slot35, align 8
  %p195 = inttoptr i64 %v193 to ptr
  %p196 = inttoptr i64 %v194 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p196, ptr %p195, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot7, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i32 2, ptr %p198, align 4, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot9, align 8
  %p200 = inttoptr i64 %v199 to ptr
  %ld201 = load i32, ptr %p200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld201, ptr %slot37, align 8
  %v202 = load i32, ptr %slot37, align 8
  %v203 = load i64, ptr %slot7, align 8
  %p204 = inttoptr i64 %v203 to ptr
  store i32 %v202, ptr %p204, align 4, !alias.scope !3, !noalias !4
  %v205 = load i64, ptr %slot8, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i32 0, ptr %p206, align 4, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot6, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i32 1, ptr %p208, align 4, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot35, align 8
  %v210 = load i64, ptr %slot17, align 8
  %p211 = inttoptr i64 %v210 to ptr
  store i64 %v209, ptr %p211, align 8, !alias.scope !3, !noalias !4
  %v212 = load i64, ptr %slot19, align 8
  store i64 %v212, ptr %slot38, align 8
  %v213 = load i64, ptr %slot38, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i64 0, ptr %p214, align 8, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot38, align 8
  %p217 = inttoptr i64 %v215 to ptr
  %gep218 = getelementptr i8, ptr %p217, i64 8
  %op216 = ptrtoint ptr %gep218 to i64
  store i64 %op216, ptr %slot39, align 8
  %v219 = load i64, ptr %slot39, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 0, ptr %p220, align 8, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot38, align 8
  %p223 = inttoptr i64 %v221 to ptr
  %gep224 = getelementptr i8, ptr %p223, i64 16
  %op222 = ptrtoint ptr %gep224 to i64
  store i64 %op222, ptr %slot40, align 8
  %v225 = load i64, ptr %slot40, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 0, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot38, align 8
  %p229 = inttoptr i64 %v227 to ptr
  %gep230 = getelementptr i8, ptr %p229, i64 24
  %op228 = ptrtoint ptr %gep230 to i64
  store i64 %op228, ptr %slot41, align 8
  %v231 = load i64, ptr %slot41, align 8
  %p232 = inttoptr i64 %v231 to ptr
  store i64 0, ptr %p232, align 8, !alias.scope !3, !noalias !4
  %v233 = load i64, ptr %slot38, align 8
  %p235 = inttoptr i64 %v233 to ptr
  %gep236 = getelementptr i8, ptr %p235, i64 32
  %op234 = ptrtoint ptr %gep236 to i64
  store i64 %op234, ptr %slot42, align 8
  %v237 = load i64, ptr %slot42, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 0, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot38, align 8
  %p241 = inttoptr i64 %v239 to ptr
  %gep242 = getelementptr i8, ptr %p241, i64 40
  %op240 = ptrtoint ptr %gep242 to i64
  store i64 %op240, ptr %slot43, align 8
  %v243 = load i64, ptr %slot43, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i64 0, ptr %p244, align 8, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot38, align 8
  %p247 = inttoptr i64 %v245 to ptr
  %gep248 = getelementptr i8, ptr %p247, i64 48
  %op246 = ptrtoint ptr %gep248 to i64
  store i64 %op246, ptr %slot44, align 8
  %v249 = load i64, ptr %slot44, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 0, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot38, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i32 9, ptr %p252, align 4, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot10, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i32 1, ptr %p254, align 4, !alias.scope !3, !noalias !4
  %v255 = load i64, ptr %slot17, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %ld257 = load i64, ptr %p256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld257, ptr %slot45, align 8
  %v258 = load i64, ptr %slot38, align 8
  %p260 = inttoptr i64 %v258 to ptr
  %gep261 = getelementptr i8, ptr %p260, i64 8
  %op259 = ptrtoint ptr %gep261 to i64
  store i64 %op259, ptr %slot46, align 8
  %v262 = load i64, ptr %slot25, align 8
  store i64 %v262, ptr %slot47, align 8
  %v263 = load i64, ptr %slot17, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot48, align 8
  %v266 = load i64, ptr %slot12, align 8
  store i64 %v266, ptr %slot49, align 8
  %v267 = load i64, ptr %slot25, align 8
  store i64 %v267, ptr %slot50, align 8
  %v268 = load i64, ptr %slot48, align 8
  %op269 = add i64 %v268, 8
  store i64 %op269, ptr %slot51, align 8
  %v270 = load i64, ptr %slot51, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ld272 = load i64, ptr %p271, align 8, !alias.scope !3, !noalias !4
  store i64 %ld272, ptr %slot52, align 8
  %v273 = load i64, ptr %slot52, align 8
  %cmp274 = icmp ne i64 %v273, 0
  %cv275 = zext i1 %cmp274 to i32
  store i32 %cv275, ptr %slot53, align 8
  %v276 = load i32, ptr %slot53, align 8
  %cv277 = zext i32 %v276 to i64
  %cond278 = icmp ne i64 %cv277, 0
  br i1 %cond278, label %bb_rcmoveheader44, label %bb_rcmovenext44
bb_rcmoveheader44:
  %v279 = load i64, ptr %slot52, align 8
  %op280 = sub i64 %v279, 16
  store i64 %op280, ptr %slot54, align 8
  %v281 = load i64, ptr %slot52, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %rgep283 = getelementptr i8, ptr %p282, i64 -16
  %ld284 = load i64, ptr %rgep283, align 8, !alias.scope !9, !noalias !10
  store i64 %ld284, ptr %slot55, align 8
  %v285 = load i64, ptr %slot55, align 8
  %op286 = and i64 %v285, 5764607523034234881
  store i64 %op286, ptr %slot56, align 8
  %v287 = load i64, ptr %slot56, align 8
  %cmp288 = icmp ne i64 %v287, 0
  %cv289 = zext i1 %cmp288 to i32
  store i32 %cv289, ptr %slot57, align 8
  %v290 = load i32, ptr %slot57, align 8
  %cv291 = zext i32 %v290 to i64
  %cond292 = icmp ne i64 %cv291, 0
  br i1 %cond292, label %bb_rcmoveslow41, label %bb_rcmovenext44
bb_rcmovenext44:
  %v293 = load i64, ptr %slot48, align 8
  %v294 = load i64, ptr %slot49, align 8
  %p295 = inttoptr i64 %v293 to ptr
  %p296 = inttoptr i64 %v294 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p296, ptr %p295, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot48, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i64 0, ptr %p298, align 8, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot48, align 8
  %op300 = add i64 %v299, 8
  store i64 %op300, ptr %slot58, align 8
  %v301 = load i64, ptr %slot58, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i64 0, ptr %p302, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved41
bb_rcmoveslow41:
  %v303 = load i64, ptr %slot24, align 8
  %v304 = load i64, ptr %slot49, align 8
  %v305 = load i64, ptr %slot48, align 8
  %v306 = load i64, ptr %slot50, align 8
  %cv307 = trunc i64 %v306 to i32
  %call308 = call i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64 %v303, i64 %v304, i64 %v305, i32 %cv307) nomerge, !dbg !116
  store i32 %call308, ptr %slot59, align 8
  %v309 = load i32, ptr %slot59, align 8
  %cv310 = zext i32 %v309 to i64
  %cond311 = icmp ne i64 %cv310, 0
  br i1 %cond311, label %bb_rcsuccess52, label %bb_rcfailure52
bb_rcfailure52:
  %v312 = load i64, ptr %slot24, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %call314 = call i32 @myl_rc_take_failure(ptr %p313) nomerge, !dbg !116
  store i32 %call314, ptr %slot60, align 8
  %v315 = load i64, ptr %slot1, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %v317 = load i32, ptr %slot60, align 8
  %call318 = call i32 @myl_qbe_rc_status(ptr %p316, i32 %v317) nomerge, !dbg !116
  store i32 %call318, ptr %slot61, align 8
  br label %bb_failure
bb_rcsuccess52:
  br label %bb_rcmoved41
bb_rcmoved41:
  %v319 = load i64, ptr %slot6, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 0, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot9, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i32 2, ptr %p322, align 4, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot8, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i32 1, ptr %p324, align 4, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot12, align 8
  store i64 %v325, ptr %slot62, align 8
  %v326 = load i64, ptr %slot62, align 8
  %v327 = load i64, ptr %slot46, align 8
  %p328 = inttoptr i64 %v326 to ptr
  %p329 = inttoptr i64 %v327 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p329, ptr %p328, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v330 = load i64, ptr %slot8, align 8
  %p331 = inttoptr i64 %v330 to ptr
  store i32 0, ptr %p331, align 4, !alias.scope !3, !noalias !4
  %v332 = load i64, ptr %slot38, align 8
  %v333 = load i64, ptr %slot17, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 %v332, ptr %p334, align 8, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot17, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %ld337 = load i64, ptr %p336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld337, ptr %slot63, align 8
  %v338 = load i64, ptr %slot11, align 8
  store i64 %v338, ptr %slot64, align 8
  %v339 = load i64, ptr %slot63, align 8
  %v340 = load i64, ptr %slot64, align 8
  %p341 = inttoptr i64 %v339 to ptr
  %p342 = inttoptr i64 %v340 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p342, ptr %p341, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot7, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i32 2, ptr %p344, align 4, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot6, align 8
  %p346 = inttoptr i64 %v345 to ptr
  store i32 1, ptr %p346, align 4, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot64, align 8
  %v348 = load i64, ptr %slot17, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i64 %v347, ptr %p349, align 8, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot16, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot65, align 8
  %v353 = load i64, ptr %slot17, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %ld355 = load i64, ptr %p354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld355, ptr %slot66, align 8
  %v356 = load i64, ptr %slot1, align 8
  %v357 = load i64, ptr %slot65, align 8
  %v358 = load i64, ptr %slot66, align 8
  %call359 = call i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64 %v356, i64 %v357, i64 %v358) nomerge, !dbg !118
  store i64 %call359, ptr %slot67, align 8
  %v360 = load i64, ptr %slot67, align 8
  %v361 = load i64, ptr %slot16, align 8
  %p362 = inttoptr i64 %v361 to ptr
  store i64 %v360, ptr %p362, align 8, !alias.scope !3, !noalias !4
  %v363 = load i64, ptr %slot6, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i32, ptr %p364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld365, ptr %slot68, align 8
  %v366 = load i32, ptr %slot68, align 8
  %cv367 = zext i32 %v366 to i64
  %cond368 = icmp ne i64 %cv367, 0
  br i1 %cond368, label %bb_rcslotdrop78, label %bb_rcslotdone78
bb_rcslotdrop78:
  %v369 = load i64, ptr %slot6, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i32 0, ptr %p370, align 4, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot11, align 8
  store i64 %v371, ptr %slot69, align 8
  %v372 = load i64, ptr %slot7, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i32, ptr %p373, align 4, !alias.scope !3, !noalias !4
  store i32 %ld374, ptr %slot70, align 8
  %v375 = load i32, ptr %slot70, align 8
  %op376 = and i32 %v375, 28
  store i32 %op376, ptr %slot71, align 8
  %v377 = load i32, ptr %slot71, align 8
  %cv378 = zext i32 %v377 to i64
  %cond379 = icmp ne i64 %cv378, 0
  br i1 %cond379, label %bb_rcslotrole78, label %bb_rcslotowner78
bb_rcslotrole78:
  %v380 = load i64, ptr %slot24, align 8
  store i64 %v380, ptr %slot72, align 8
  %v381 = load i64, ptr %slot72, align 8
  %v382 = load i64, ptr %slot69, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v381, i64 %v382) nomerge, !dbg !118
  br label %bb_rcslotdone78
bb_rcslotowner78:
  %v383 = load i64, ptr %slot24, align 8
  store i64 %v383, ptr %slot73, align 8
  %v384 = load i64, ptr %slot73, align 8
  %v385 = load i64, ptr %slot69, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v384, i64 %v385) nomerge, !dbg !118
  br label %bb_rcslotdone78
bb_rcslotdone78:
  %v386 = load i64, ptr %slot16, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot74, align 8
  %v389 = load i64, ptr %slot74, align 8
  ret i64 %v389
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64, i64, i64)
declare { i64, i64 } @myl_f_ed6cdb459a10359c7af7d7dea26329312cfcb29abed1d3364e6791153809bc70(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_57782efa376d384df4e2bcf0d0f9129dd005d97f40c0e347be9c59287da998ec_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c", linkageName: "myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8643756277850062154, i64 0, !"myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
