target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_5af755ff39699d4050214e9fdc5e92b763fd42b47cc67a218a0ace498e9cdd61(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v87 = load i64, ptr %slot1, align 8
  %op88 = add i64 %v87, 32
  store i64 %op88, ptr %slot4, align 8
  %mem89 = alloca i8, i64 8, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot5, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot6, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot7, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot8, align 8
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot9, align 8
  %mem99 = alloca i8, i64 8, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot10, align 8
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot11, align 8
  %mem103 = alloca i8, i64 8, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot12, align 8
  %v105 = load i64, ptr %slot8, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i64 0, ptr %p106, align 8, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot9, align 8
  %p108 = inttoptr i64 %v107 to ptr
  store i64 0, ptr %p108, align 8, !alias.scope !3, !noalias !4
  %v109 = load i64, ptr %slot2, align 8
  %v110 = load i64, ptr %slot5, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot3, align 8
  %v113 = load i64, ptr %slot6, align 8
  %p114 = inttoptr i64 %v113 to ptr
  store i64 %v112, ptr %p114, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v115 = load i64, ptr %slot11, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 0, ptr %p116, align 8, !alias.scope !3, !noalias !4
  %v117 = load i64, ptr %slot11, align 8
  %p118 = inttoptr i64 %v117 to ptr
  %ld119 = load i64, ptr %p118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld119, ptr %slot13, align 8
  %v120 = load i64, ptr %slot7, align 8
  store i64 %v120, ptr %slot14, align 8
  %v121 = load i64, ptr %slot13, align 8
  %v122 = load i64, ptr %slot14, align 8
  %p123 = inttoptr i64 %v122 to ptr
  store i64 %v121, ptr %p123, align 8, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_i2:
  %v124 = load i64, ptr %slot7, align 8
  %p125 = inttoptr i64 %v124 to ptr
  %ld126 = load i64, ptr %p125, align 8, !alias.scope !3, !noalias !4
  store i64 %ld126, ptr %slot15, align 8
  %v127 = load i64, ptr %slot15, align 8
  %v128 = load i64, ptr %slot11, align 8
  %p129 = inttoptr i64 %v128 to ptr
  store i64 %v127, ptr %p129, align 8, !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot5, align 8
  %p131 = inttoptr i64 %v130 to ptr
  %ld132 = load i64, ptr %p131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld132, ptr %slot16, align 8
  %v133 = load i64, ptr %slot16, align 8
  %v134 = load i64, ptr %slot12, align 8
  %p135 = inttoptr i64 %v134 to ptr
  store i64 %v133, ptr %p135, align 8, !alias.scope !3, !noalias !4
  %v136 = load i64, ptr %slot12, align 8
  %p137 = inttoptr i64 %v136 to ptr
  %ld138 = load i64, ptr %p137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld138, ptr %slot17, align 8
  %v139 = load i64, ptr %slot17, align 8
  %op140 = add i64 %v139, 0
  store i64 %op140, ptr %slot18, align 8
  %v141 = load i64, ptr %slot18, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %ld143 = load i64, ptr %p142, align 8, !alias.scope !4, !noalias !3
  store i64 %ld143, ptr %slot19, align 8
  %v144 = load i64, ptr %slot19, align 8
  %v145 = load i64, ptr %slot12, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot12, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot20, align 8
  %v150 = load i64, ptr %slot8, align 8
  store i64 %v150, ptr %slot21, align 8
  %v151 = load i64, ptr %slot20, align 8
  %v152 = load i64, ptr %slot21, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 %v151, ptr %p153, align 8, !alias.scope !3, !noalias !4
  %v154 = load i64, ptr %slot8, align 8
  %p155 = inttoptr i64 %v154 to ptr
  %ld156 = load i64, ptr %p155, align 8, !alias.scope !3, !noalias !4
  store i64 %ld156, ptr %slot22, align 8
  %v157 = load i64, ptr %slot22, align 8
  %op158 = add i64 %v157, 0
  store i64 %op158, ptr %slot23, align 8
  %v159 = load i64, ptr %slot23, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %ld161 = load i64, ptr %p160, align 8, !alias.scope !6, !noalias !7
  store i64 %ld161, ptr %slot24, align 8
  %v162 = load i64, ptr %slot24, align 8
  %v163 = load i64, ptr %slot12, align 8
  %p164 = inttoptr i64 %v163 to ptr
  store i64 %v162, ptr %p164, align 8, !alias.scope !3, !noalias !4
  %v165 = load i64, ptr %slot12, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld167, ptr %slot25, align 8
  %v168 = load i64, ptr %slot25, align 8
  %cmp169 = icmp ugt i64 %v168, 9223372036854775807
  %cv170 = zext i1 %cmp169 to i64
  store i64 %cv170, ptr %slot26, align 8
  %v171 = load i64, ptr %slot26, align 8
  %cond172 = icmp ne i64 %v171, 0
  br i1 %cond172, label %bb_cast_overflow14, label %bb_cast_ok14
bb_cast_overflow14:
  %v173 = load i64, ptr %slot1, align 8
  %p174 = inttoptr i64 %v173 to ptr
  %v175 = load i64, ptr %slot25, align 8
  call void @myl_qbe_fail_cast(ptr %p174, i64 %v175, i64 320) nomerge, !dbg !110
  unreachable
bb_cast_ok14:
  %v176 = load i64, ptr %slot25, align 8
  %v177 = load i64, ptr %slot12, align 8
  %p178 = inttoptr i64 %v177 to ptr
  store i64 %v176, ptr %p178, align 8, !alias.scope !3, !noalias !4
  %v179 = load i64, ptr %slot12, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !3, !noalias !4
  store i64 %ld181, ptr %slot27, align 8
  %v182 = load i64, ptr %slot11, align 8
  %p183 = inttoptr i64 %v182 to ptr
  %ld184 = load i64, ptr %p183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld184, ptr %slot28, align 8
  %v185 = load i64, ptr %slot28, align 8
  %v186 = load i64, ptr %slot27, align 8
  %cmp187 = icmp slt i64 %v185, %v186
  %cv188 = zext i1 %cmp187 to i64
  store i64 %cv188, ptr %slot29, align 8
  %v189 = load i64, ptr %slot29, align 8
  %v190 = load i64, ptr %slot11, align 8
  %p191 = inttoptr i64 %v190 to ptr
  store i64 %v189, ptr %p191, align 8, !alias.scope !3, !noalias !4
  %v192 = load i64, ptr %slot11, align 8
  %p193 = inttoptr i64 %v192 to ptr
  %ld194 = load i64, ptr %p193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld194, ptr %slot30, align 8
  %v195 = load i64, ptr %slot30, align 8
  %cond196 = icmp ne i64 %v195, 0
  br i1 %cond196, label %bb_next19, label %bb_i37
bb_next19:
  %v197 = load i64, ptr %slot5, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %ld199 = load i64, ptr %p198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld199, ptr %slot31, align 8
  %v200 = load i64, ptr %slot31, align 8
  %v201 = load i64, ptr %slot11, align 8
  %p202 = inttoptr i64 %v201 to ptr
  store i64 %v200, ptr %p202, align 8, !alias.scope !3, !noalias !4
  %v203 = load i64, ptr %slot11, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot32, align 8
  %v206 = load i64, ptr %slot32, align 8
  %op207 = add i64 %v206, 0
  store i64 %op207, ptr %slot33, align 8
  %v208 = load i64, ptr %slot33, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !4, !noalias !3
  store i64 %ld210, ptr %slot34, align 8
  %v211 = load i64, ptr %slot34, align 8
  %v212 = load i64, ptr %slot11, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot11, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot35, align 8
  %v217 = load i64, ptr %slot9, align 8
  store i64 %v217, ptr %slot36, align 8
  %v218 = load i64, ptr %slot35, align 8
  %v219 = load i64, ptr %slot36, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i64 %v218, ptr %p220, align 8, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot7, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld223, ptr %slot37, align 8
  %v224 = load i64, ptr %slot37, align 8
  %v225 = load i64, ptr %slot11, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 %v224, ptr %p226, align 8, !alias.scope !3, !noalias !4
  %v227 = load i64, ptr %slot11, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot38, align 8
  %v230 = load i64, ptr %slot10, align 8
  store i64 %v230, ptr %slot39, align 8
  %v231 = load i64, ptr %slot38, align 8
  %v232 = load i64, ptr %slot39, align 8
  %p233 = inttoptr i64 %v232 to ptr
  store i64 %v231, ptr %p233, align 8, !alias.scope !3, !noalias !4
  %v234 = load i64, ptr %slot10, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %ld236 = load i64, ptr %p235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld236, ptr %slot40, align 8
  %v237 = load i64, ptr %slot40, align 8
  %v238 = load i64, ptr %slot11, align 8
  %p239 = inttoptr i64 %v238 to ptr
  store i64 %v237, ptr %p239, align 8, !alias.scope !3, !noalias !4
  %v240 = load i64, ptr %slot12, align 8
  %p241 = inttoptr i64 %v240 to ptr
  store i64 0, ptr %p241, align 8, !alias.scope !3, !noalias !4
  %v242 = load i64, ptr %slot12, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %ld244 = load i64, ptr %p243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld244, ptr %slot41, align 8
  %v245 = load i64, ptr %slot11, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %ld247 = load i64, ptr %p246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld247, ptr %slot42, align 8
  %v248 = load i64, ptr %slot42, align 8
  %v249 = load i64, ptr %slot41, align 8
  %cmp250 = icmp slt i64 %v248, %v249
  %cv251 = zext i1 %cmp250 to i64
  store i64 %cv251, ptr %slot43, align 8
  %v252 = load i64, ptr %slot43, align 8
  %v253 = load i64, ptr %slot11, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i64 %v252, ptr %p254, align 8, !alias.scope !3, !noalias !4
  %v255 = load i64, ptr %slot11, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %ld257 = load i64, ptr %p256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld257, ptr %slot44, align 8
  %v258 = load i64, ptr %slot44, align 8
  %cond259 = icmp ne i64 %v258, 0
  br i1 %cond259, label %bb_next33, label %bb_i24
bb_next33:
  %v260 = load i64, ptr %slot9, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i64, ptr %p261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld262, ptr %slot45, align 8
  %v263 = load i64, ptr %slot45, align 8
  %op264 = add i64 %v263, 0
  store i64 %op264, ptr %slot46, align 8
  %v265 = load i64, ptr %slot46, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !6, !noalias !7
  store i64 %ld267, ptr %slot47, align 8
  %v268 = load i64, ptr %slot47, align 8
  %v269 = load i64, ptr %slot11, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot11, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot48, align 8
  %v274 = load i64, ptr %slot48, align 8
  %cmp275 = icmp ugt i64 %v274, 9223372036854775807
  %cv276 = zext i1 %cmp275 to i64
  store i64 %cv276, ptr %slot49, align 8
  %v277 = load i64, ptr %slot49, align 8
  %cond278 = icmp ne i64 %v277, 0
  br i1 %cond278, label %bb_cast_overflow38, label %bb_cast_ok38
bb_cast_overflow38:
  %v279 = load i64, ptr %slot1, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %v281 = load i64, ptr %slot48, align 8
  call void @myl_qbe_fail_cast(ptr %p280, i64 %v281, i64 320) nomerge, !dbg !112
  unreachable
bb_cast_ok38:
  %v282 = load i64, ptr %slot48, align 8
  %v283 = load i64, ptr %slot11, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 %v282, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot10, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i64, ptr %p286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld287, ptr %slot50, align 8
  %v288 = load i64, ptr %slot50, align 8
  %v289 = load i64, ptr %slot12, align 8
  %p290 = inttoptr i64 %v289 to ptr
  store i64 %v288, ptr %p290, align 8, !alias.scope !3, !noalias !4
  %v291 = load i64, ptr %slot12, align 8
  %p292 = inttoptr i64 %v291 to ptr
  %ld293 = load i64, ptr %p292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld293, ptr %slot51, align 8
  %v294 = load i64, ptr %slot11, align 8
  %p295 = inttoptr i64 %v294 to ptr
  %ld296 = load i64, ptr %p295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld296, ptr %slot52, align 8
  %v297 = load i64, ptr %slot52, align 8
  %v298 = load i64, ptr %slot51, align 8
  %ovpair300 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v297, i64 %v298)
  %op299 = extractvalue { i64, i1 } %ovpair300, 0
  %ov301 = extractvalue { i64, i1 } %ovpair300, 1
  store i64 %op299, ptr %slot53, align 8
  %v302 = load i64, ptr %slot52, align 8
  %v303 = load i64, ptr %slot53, align 8
  %op304 = xor i64 %v302, %v303
  store i64 %op304, ptr %slot54, align 8
  %v305 = load i64, ptr %slot51, align 8
  %v306 = load i64, ptr %slot53, align 8
  %op307 = xor i64 %v305, %v306
  store i64 %op307, ptr %slot55, align 8
  %v308 = load i64, ptr %slot54, align 8
  %v309 = load i64, ptr %slot55, align 8
  %op310 = and i64 %v308, %v309
  store i64 %op310, ptr %slot56, align 8
  %cv311 = zext i1 %ov301 to i64
  store i64 %cv311, ptr %slot57, align 8
  %v312 = load i64, ptr %slot57, align 8
  %cond313 = icmp ne i64 %v312, 0
  br i1 %cond313, label %bb_overflow42, label %bb_checked42
bb_overflow42:
  %v314 = load i64, ptr %slot1, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %v316 = load i64, ptr %slot52, align 8
  %v317 = load i64, ptr %slot51, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p315, i64 0, i64 %v316, i64 %v317, i64 64) nomerge, !dbg !114
  unreachable
bb_checked42:
  %v318 = load i64, ptr %slot53, align 8
  %v319 = load i64, ptr %slot11, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i64 %v318, ptr %p320, align 8, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot11, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %ld323 = load i64, ptr %p322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld323, ptr %slot58, align 8
  %v324 = load i64, ptr %slot10, align 8
  store i64 %v324, ptr %slot59, align 8
  %v325 = load i64, ptr %slot58, align 8
  %v326 = load i64, ptr %slot59, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i64 %v325, ptr %p327, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i24:
  %v328 = load i64, ptr %slot10, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i64, ptr %p329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld330, ptr %slot60, align 8
  %v331 = load i64, ptr %slot60, align 8
  %v332 = load i64, ptr %slot11, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 %v331, ptr %p333, align 8, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot9, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %ld336 = load i64, ptr %p335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld336, ptr %slot61, align 8
  %v337 = load i64, ptr %slot11, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot62, align 8
  %v340 = load i64, ptr %slot61, align 8
  %p341 = inttoptr i64 %v340 to ptr
  %ld342 = load i64, ptr %p341, align 8, !alias.scope !6, !noalias !7
  store i64 %ld342, ptr %slot63, align 8
  %v343 = load i64, ptr %slot62, align 8
  %v344 = load i64, ptr %slot63, align 8
  %cmp345 = icmp ult i64 %v343, %v344
  %cv346 = zext i1 %cmp345 to i64
  store i64 %cv346, ptr %slot64, align 8
  %v347 = load i64, ptr %slot64, align 8
  %cond348 = icmp ne i64 %v347, 0
  br i1 %cond348, label %bb_success55, label %bb_failed55
bb_failed55:
  %v349 = load i64, ptr %slot1, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %v351 = load i64, ptr %slot62, align 8
  %v352 = load i64, ptr %slot63, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p350, i64 %v351, i64 %v352) nomerge, !dbg !116
  unreachable
bb_success55:
  %v353 = load i64, ptr %slot61, align 8
  %op354 = add i64 %v353, 32
  store i64 %op354, ptr %slot65, align 8
  %v355 = load i64, ptr %slot65, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !6, !noalias !7
  store i64 %ld357, ptr %slot66, align 8
  %v358 = load i64, ptr %slot62, align 8
  %op359 = mul i64 %v358, 24
  store i64 %op359, ptr %slot67, align 8
  %v360 = load i64, ptr %slot66, align 8
  %v361 = load i64, ptr %slot67, align 8
  %op362 = add i64 %v360, %v361
  store i64 %op362, ptr %slot68, align 8
  %v363 = load i64, ptr %slot68, align 8
  %v364 = load i64, ptr %slot11, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i64 %v363, ptr %p365, align 8, !alias.scope !3, !noalias !4
  %v366 = load i64, ptr %slot11, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot69, align 8
  %v369 = load i64, ptr %slot69, align 8
  %op370 = add i64 %v369, 0
  store i64 %op370, ptr %slot70, align 8
  %v371 = load i64, ptr %slot70, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !12, !noalias !13
  store i64 %ld373, ptr %slot71, align 8
  %v374 = load i64, ptr %slot71, align 8
  %v375 = load i64, ptr %slot11, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot6, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %ld379 = load i64, ptr %p378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld379, ptr %slot72, align 8
  %v380 = load i64, ptr %slot72, align 8
  %v381 = load i64, ptr %slot12, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 %v380, ptr %p382, align 8, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot12, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot73, align 8
  %v386 = load i64, ptr %slot11, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot74, align 8
  %v389 = load i64, ptr %slot74, align 8
  %v390 = load i64, ptr %slot73, align 8
  %cmp391 = icmp eq i64 %v389, %v390
  %cv392 = zext i1 %cmp391 to i64
  store i64 %cv392, ptr %slot75, align 8
  %v393 = load i64, ptr %slot75, align 8
  %v394 = load i64, ptr %slot11, align 8
  %p395 = inttoptr i64 %v394 to ptr
  store i64 %v393, ptr %p395, align 8, !alias.scope !3, !noalias !4
  %v396 = load i64, ptr %slot11, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot76, align 8
  %v399 = load i64, ptr %slot76, align 8
  %cond400 = icmp ne i64 %v399, 0
  br i1 %cond400, label %bb_next68, label %bb_i32
bb_next68:
  %v401 = load i64, ptr %slot7, align 8
  %p402 = inttoptr i64 %v401 to ptr
  %ld403 = load i64, ptr %p402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld403, ptr %slot77, align 8
  %v404 = load i64, ptr %slot77, align 8
  %v405 = load i64, ptr %slot11, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 %v404, ptr %p406, align 8, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot11, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i64, ptr %p408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld409, ptr %slot78, align 8
  %v410 = load i64, ptr %slot78, align 8
  ret i64 %v410
bb_i32:
  %v411 = load i64, ptr %slot7, align 8
  %p412 = inttoptr i64 %v411 to ptr
  %ld413 = load i64, ptr %p412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld413, ptr %slot79, align 8
  %v414 = load i64, ptr %slot79, align 8
  %v415 = load i64, ptr %slot11, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i64 %v414, ptr %p416, align 8, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot12, align 8
  %p418 = inttoptr i64 %v417 to ptr
  store i64 1, ptr %p418, align 8, !alias.scope !3, !noalias !4
  %v419 = load i64, ptr %slot12, align 8
  %p420 = inttoptr i64 %v419 to ptr
  %ld421 = load i64, ptr %p420, align 8, !alias.scope !3, !noalias !4
  store i64 %ld421, ptr %slot80, align 8
  %v422 = load i64, ptr %slot11, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %ld424 = load i64, ptr %p423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld424, ptr %slot81, align 8
  %v425 = load i64, ptr %slot81, align 8
  %v426 = load i64, ptr %slot80, align 8
  %ovpair428 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v425, i64 %v426)
  %op427 = extractvalue { i64, i1 } %ovpair428, 0
  %ov429 = extractvalue { i64, i1 } %ovpair428, 1
  store i64 %op427, ptr %slot82, align 8
  %cv430 = zext i1 %ov429 to i64
  store i64 %cv430, ptr %slot83, align 8
  %v431 = load i64, ptr %slot83, align 8
  %cond432 = icmp ne i64 %v431, 0
  br i1 %cond432, label %bb_overflow73, label %bb_checked73
bb_overflow73:
  %v433 = load i64, ptr %slot1, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %v435 = load i64, ptr %slot81, align 8
  %v436 = load i64, ptr %slot80, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p434, i64 0, i64 %v435, i64 %v436, i64 64) nomerge, !dbg !118
  unreachable
bb_checked73:
  %v437 = load i64, ptr %slot82, align 8
  %v438 = load i64, ptr %slot11, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i64 %v437, ptr %p439, align 8, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot11, align 8
  %p441 = inttoptr i64 %v440 to ptr
  %ld442 = load i64, ptr %p441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld442, ptr %slot84, align 8
  %v443 = load i64, ptr %slot7, align 8
  store i64 %v443, ptr %slot85, align 8
  %v444 = load i64, ptr %slot84, align 8
  %v445 = load i64, ptr %slot85, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i64 %v444, ptr %p446, align 8, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_i37:
  %v447 = load i64, ptr %slot11, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i64 18446744073709551615, ptr %p448, align 8, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot11, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %ld451 = load i64, ptr %p450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld451, ptr %slot86, align 8
  %v452 = load i64, ptr %slot86, align 8
  ret i64 %v452
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 24v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_5af755ff39699d4050214e9fdc5e92b763fd42b47cc67a218a0ace498e9cdd61", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_5af755ff39699d4050214e9fdc5e92b763fd42b47cc67a218a0ace498e9cdd61", linkageName: "myl_f_5af755ff39699d4050214e9fdc5e92b763fd42b47cc67a218a0ace498e9cdd61", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8600185152613952236, i64 0, !"myl_f_5af755ff39699d4050214e9fdc5e92b763fd42b47cc67a218a0ace498e9cdd61"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!110 = !DILocation(line: 8, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!112 = !DILocation(line: 21, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!114 = !DILocation(line: 23, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!116 = !DILocation(line: 26, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!118 = !DILocation(line: 35, column: 0, scope: !119)
