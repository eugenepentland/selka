target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_022254012379d669c70ce85172d39cd6b7c017a53416bb4eb6fc259fa8842271(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v13 = load i64, ptr %slot1, align 8
  %op14 = add i64 %v13, 32
  store i64 %op14, ptr %slot3, align 8
  %mem15 = alloca i8, i64 8, align 8
  %ptr16 = ptrtoint ptr %mem15 to i64
  store i64 %ptr16, ptr %slot4, align 8
  %mem17 = alloca i8, i64 8, align 8
  %ptr18 = ptrtoint ptr %mem17 to i64
  store i64 %ptr18, ptr %slot5, align 8
  %v19 = load i64, ptr %slot2, align 8
  %v20 = load i64, ptr %slot4, align 8
  %p21 = inttoptr i64 %v20 to ptr
  store i64 %v19, ptr %p21, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v22 = load i64, ptr %slot4, align 8
  %p23 = inttoptr i64 %v22 to ptr
  %ld24 = load i64, ptr %p23, align 8, !alias.scope !3, !noalias !4
  store i64 %ld24, ptr %slot6, align 8
  %v25 = load i64, ptr %slot6, align 8
  %v26 = load i64, ptr %slot5, align 8
  %p27 = inttoptr i64 %v26 to ptr
  store i64 %v25, ptr %p27, align 8, !alias.scope !3, !noalias !4
  %v28 = load i64, ptr %slot5, align 8
  %p29 = inttoptr i64 %v28 to ptr
  %ld30 = load i64, ptr %p29, align 8, !alias.scope !3, !noalias !4
  store i64 %ld30, ptr %slot7, align 8
  %v31 = load i64, ptr %slot7, align 8
  %op32 = add i64 %v31, 0
  store i64 %op32, ptr %slot8, align 8
  %v33 = load i64, ptr %slot8, align 8
  %p34 = inttoptr i64 %v33 to ptr
  %ld35 = load i64, ptr %p34, align 8, !alias.scope !4, !noalias !3
  store i64 %ld35, ptr %slot9, align 8
  %v36 = load i64, ptr %slot9, align 8
  %v37 = load i64, ptr %slot5, align 8
  %p38 = inttoptr i64 %v37 to ptr
  store i64 %v36, ptr %p38, align 8, !alias.scope !3, !noalias !4
  %v39 = load i64, ptr %slot5, align 8
  %p40 = inttoptr i64 %v39 to ptr
  %ld41 = load i64, ptr %p40, align 8, !alias.scope !3, !noalias !4
  store i64 %ld41, ptr %slot10, align 8
  %v42 = load i64, ptr %slot1, align 8
  %p43 = inttoptr i64 %v42 to ptr
  %v44 = load i64, ptr %slot10, align 8
  %call45 = call i64 @myl_qbe_stand_in(ptr %p43, i64 0, i64 %v44) nomerge, !dbg !110
  store i64 %call45, ptr %slot11, align 8
  %v46 = load i64, ptr %slot11, align 8
  %v47 = load i64, ptr %slot5, align 8
  %p48 = inttoptr i64 %v47 to ptr
  store i64 %v46, ptr %p48, align 8, !alias.scope !3, !noalias !4
  %v49 = load i64, ptr %slot5, align 8
  %p50 = inttoptr i64 %v49 to ptr
  %ld51 = load i64, ptr %p50, align 8, !alias.scope !3, !noalias !4
  store i64 %ld51, ptr %slot12, align 8
  %v52 = load i64, ptr %slot12, align 8
  ret i64 %v52
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare i64 @myl_qbe_stand_in(ptr, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_022254012379d669c70ce85172d39cd6b7c017a53416bb4eb6fc259fa8842271", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_022254012379d669c70ce85172d39cd6b7c017a53416bb4eb6fc259fa8842271", linkageName: "myl_f_022254012379d669c70ce85172d39cd6b7c017a53416bb4eb6fc259fa8842271", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5177717179201935074, i64 0, !"myl_f_022254012379d669c70ce85172d39cd6b7c017a53416bb4eb6fc259fa8842271"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!110 = !DILocation(line: 3, column: 0, scope: !111)
