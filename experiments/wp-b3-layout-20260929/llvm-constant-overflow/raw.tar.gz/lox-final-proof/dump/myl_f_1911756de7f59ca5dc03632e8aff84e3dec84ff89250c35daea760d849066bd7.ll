target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_1911756de7f59ca5dc03632e8aff84e3dec84ff89250c35daea760d849066bd7(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i32, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v64 = load i64, ptr %slot1, align 8
  %op65 = add i64 %v64, 32
  store i64 %op65, ptr %slot3, align 8
  %mem66 = alloca i8, i64 8, align 8
  %ptr67 = ptrtoint ptr %mem66 to i64
  store i64 %ptr67, ptr %slot4, align 8
  %mem68 = alloca i8, i64 8, align 8
  %ptr69 = ptrtoint ptr %mem68 to i64
  store i64 %ptr69, ptr %slot5, align 8
  %mem70 = alloca i8, i64 8, align 8
  %ptr71 = ptrtoint ptr %mem70 to i64
  store i64 %ptr71, ptr %slot6, align 8
  %mem72 = alloca i8, i64 8, align 8
  %ptr73 = ptrtoint ptr %mem72 to i64
  store i64 %ptr73, ptr %slot7, align 8
  %mem74 = alloca i8, i64 8, align 8
  %ptr75 = ptrtoint ptr %mem74 to i64
  store i64 %ptr75, ptr %slot8, align 8
  %mem76 = alloca i8, i64 8, align 8
  %ptr77 = ptrtoint ptr %mem76 to i64
  store i64 %ptr77, ptr %slot9, align 8
  %mem78 = alloca i8, i64 8, align 8
  %ptr79 = ptrtoint ptr %mem78 to i64
  store i64 %ptr79, ptr %slot10, align 8
  %mem80 = alloca i8, i64 8, align 8
  %ptr81 = ptrtoint ptr %mem80 to i64
  store i64 %ptr81, ptr %slot11, align 8
  %mem82 = alloca i8, i64 8, align 8
  %ptr83 = ptrtoint ptr %mem82 to i64
  store i64 %ptr83, ptr %slot12, align 8
  %mem84 = alloca i8, i64 8, align 8
  %ptr85 = ptrtoint ptr %mem84 to i64
  store i64 %ptr85, ptr %slot13, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem86 = alloca i8, i64 8, align 8
  %ptr87 = ptrtoint ptr %mem86 to i64
  store i64 %ptr87, ptr %slot14, align 8
  %v88 = load i64, ptr %slot1, align 8
  %op89 = add i64 %v88, 64
  store i64 %op89, ptr %slot15, align 8
  %v90 = load i64, ptr %slot15, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !4, !noalias !3
  store i64 %ld92, ptr %slot16, align 8
  %stack93 = call ptr @llvm.stacksave()
  %stackaddr94 = ptrtoint ptr %stack93 to i64
  %v95 = load i64, ptr %slot16, align 8
  %cmp96 = icmp ult i64 %stackaddr94, %v95
  %cv97 = zext i1 %cmp96 to i64
  store i64 %cv97, ptr %slot17, align 8
  %v98 = load i64, ptr %slot17, align 8
  %cond99 = icmp ne i64 %v98, 0
  br i1 %cond99, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v100 = load i64, ptr %slot1, align 8
  %p101 = inttoptr i64 %v100 to ptr
  call void @myl_qbe_fail_frame(ptr %p101) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v102 = load i64, ptr %slot2, align 8
  %v103 = load i64, ptr %slot11, align 8
  %p104 = inttoptr i64 %v103 to ptr
  store i64 %v102, ptr %p104, align 8, !alias.scope !3, !noalias !4
  %v105 = load i64, ptr %slot1, align 8
  %p106 = inttoptr i64 %v105 to ptr
  %call107 = call ptr @myl_qbe_heap(ptr %p106) nomerge, !dbg !112
  %calladdr108 = ptrtoint ptr %call107 to i64
  store i64 %calladdr108, ptr %slot18, align 8
  %v109 = load i64, ptr %slot4, align 8
  %p110 = inttoptr i64 %v109 to ptr
  store i32 0, ptr %p110, align 4, !alias.scope !3, !noalias !4
  %v111 = load i64, ptr %slot5, align 8
  %p112 = inttoptr i64 %v111 to ptr
  store i32 0, ptr %p112, align 4, !alias.scope !3, !noalias !4
  %v113 = load i64, ptr %slot6, align 8
  %p114 = inttoptr i64 %v113 to ptr
  store i32 0, ptr %p114, align 4, !alias.scope !3, !noalias !4
  %v115 = load i64, ptr %slot7, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i32 0, ptr %p116, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v117 = load i64, ptr %slot11, align 8
  %p118 = inttoptr i64 %v117 to ptr
  %ld119 = load i64, ptr %p118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld119, ptr %slot19, align 8
  %v120 = load i64, ptr %slot19, align 8
  %v121 = load i64, ptr %slot12, align 8
  %p122 = inttoptr i64 %v121 to ptr
  store i64 %v120, ptr %p122, align 8, !alias.scope !3, !noalias !4
  %v123 = load i64, ptr %slot1, align 8
  %call124 = call i64 @myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775(i64 %v123) nomerge, !dbg !114
  store i64 %call124, ptr %slot20, align 8
  %v125 = load i64, ptr %slot20, align 8
  %v126 = load i64, ptr %slot13, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i64 %v125, ptr %p127, align 8, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot13, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i64, ptr %p129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld130, ptr %slot21, align 8
  %v131 = load i64, ptr %slot21, align 8
  %v132 = load i64, ptr %slot9, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i64 %v131, ptr %p133, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot9, align 8
  store i64 %v134, ptr %slot22, align 8
  %v135 = load i64, ptr %slot10, align 8
  store i64 %v135, ptr %slot23, align 8
  %v136 = load i64, ptr %slot22, align 8
  %v137 = load i64, ptr %slot23, align 8
  %p138 = inttoptr i64 %v136 to ptr
  %p139 = inttoptr i64 %v137 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p139, ptr %p138, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot7, align 8
  %p141 = inttoptr i64 %v140 to ptr
  store i32 2, ptr %p141, align 4, !alias.scope !3, !noalias !4
  %v142 = load i64, ptr %slot6, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i32 1, ptr %p143, align 4, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot8, align 8
  store i64 %v144, ptr %slot24, align 8
  %v145 = load i64, ptr %slot10, align 8
  store i64 %v145, ptr %slot25, align 8
  %v146 = load i64, ptr %slot25, align 8
  %v147 = load i64, ptr %slot24, align 8
  %p148 = inttoptr i64 %v146 to ptr
  %p149 = inttoptr i64 %v147 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p149, ptr %p148, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot5, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i32 2, ptr %p151, align 4, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot7, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i32, ptr %p153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld154, ptr %slot26, align 8
  %v155 = load i32, ptr %slot26, align 8
  %v156 = load i64, ptr %slot5, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i32 %v155, ptr %p157, align 4, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot6, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i32 0, ptr %p159, align 4, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot4, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i32 1, ptr %p161, align 4, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot24, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld164, ptr %slot27, align 8
  %v165 = load i64, ptr %slot27, align 8
  %v166 = load i64, ptr %slot13, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot13, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot28, align 8
  %v171 = load i64, ptr %slot12, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot29, align 8
  %v174 = load i64, ptr %slot1, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %v176 = load i64, ptr %slot29, align 8
  %v177 = load i64, ptr %slot28, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %call179 = call i64 @myl_qbe_stream_write_bytes(ptr %p175, i64 %v176, ptr %p178) nomerge, !dbg !116
  store i64 %call179, ptr %slot30, align 8
  %v180 = load i64, ptr %slot30, align 8
  %v181 = load i64, ptr %slot12, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot4, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i32, ptr %p184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld185, ptr %slot31, align 8
  %v186 = load i32, ptr %slot31, align 8
  %cv187 = zext i32 %v186 to i64
  %cond188 = icmp ne i64 %cv187, 0
  br i1 %cond188, label %bb_rcslotdrop28, label %bb_rcslotdone28
bb_rcslotdrop28:
  %v189 = load i64, ptr %slot4, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i32 0, ptr %p190, align 4, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot8, align 8
  store i64 %v191, ptr %slot32, align 8
  %v192 = load i64, ptr %slot5, align 8
  %p193 = inttoptr i64 %v192 to ptr
  %ld194 = load i32, ptr %p193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld194, ptr %slot33, align 8
  %v195 = load i32, ptr %slot33, align 8
  %op196 = and i32 %v195, 28
  store i32 %op196, ptr %slot34, align 8
  %v197 = load i32, ptr %slot34, align 8
  %cv198 = zext i32 %v197 to i64
  %cond199 = icmp ne i64 %cv198, 0
  br i1 %cond199, label %bb_rcslotrole28, label %bb_rcslotowner28
bb_rcslotrole28:
  %v200 = load i64, ptr %slot18, align 8
  store i64 %v200, ptr %slot35, align 8
  %v201 = load i64, ptr %slot32, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i64, ptr %p202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld203, ptr %slot36, align 8
  %v204 = load i64, ptr %slot36, align 8
  %cmp205 = icmp ne i64 %v204, 0
  %cv206 = zext i1 %cmp205 to i32
  store i32 %cv206, ptr %slot37, align 8
  %v207 = load i32, ptr %slot37, align 8
  %cv208 = zext i32 %v207 to i64
  %cond209 = icmp ne i64 %cv208, 0
  br i1 %cond209, label %bb_rcgnn44, label %bb_rcgdone44
bb_rcgnn44:
  %v210 = load i64, ptr %slot36, align 8
  %op211 = sub i64 %v210, 16
  store i64 %op211, ptr %slot38, align 8
  %v212 = load i64, ptr %slot36, align 8
  %p213 = inttoptr i64 %v212 to ptr
  %rgep214 = getelementptr i8, ptr %p213, i64 -16
  %ld215 = load i64, ptr %rgep214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld215, ptr %slot39, align 8
  %v216 = load i64, ptr %slot39, align 8
  %op217 = and i64 %v216, 4611686018427387906
  store i64 %op217, ptr %slot40, align 8
  %v218 = load i64, ptr %slot40, align 8
  %cmp219 = icmp ne i64 %v218, 0
  %cv220 = zext i1 %cmp219 to i32
  store i32 %cv220, ptr %slot41, align 8
  %v221 = load i32, ptr %slot41, align 8
  %cv222 = zext i32 %v221 to i64
  %cond223 = icmp ne i64 %cv222, 0
  br i1 %cond223, label %bb_rcgclear44, label %bb_rcgcounted44
bb_rcgcounted44:
  %v224 = load i64, ptr %slot36, align 8
  %op225 = sub i64 %v224, 24
  store i64 %op225, ptr %slot42, align 8
  %v226 = load i64, ptr %slot36, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %rgep228 = getelementptr i8, ptr %p227, i64 -24
  %ld229 = load i64, ptr %rgep228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld229, ptr %slot43, align 8
  %v230 = load i64, ptr %slot43, align 8
  %op231 = sub i64 %v230, 1
  store i64 %op231, ptr %slot44, align 8
  %v232 = load i64, ptr %slot44, align 8
  %cmp233 = icmp eq i64 %v232, 0
  %cv234 = zext i1 %cmp233 to i32
  store i32 %cv234, ptr %slot45, align 8
  %v235 = load i32, ptr %slot45, align 8
  %cv236 = zext i32 %v235 to i64
  %cond237 = icmp ne i64 %cv236, 0
  br i1 %cond237, label %bb_rcglast44, label %bb_rcgdec44
bb_rcglast44:
  %v238 = load i64, ptr %slot36, align 8
  %op239 = sub i64 %v238, 32
  store i64 %op239, ptr %slot46, align 8
  %v240 = load i64, ptr %slot36, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %rgep242 = getelementptr i8, ptr %p241, i64 -32
  %ld243 = load i64, ptr %rgep242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld243, ptr %slot47, align 8
  %v244 = load i64, ptr %slot47, align 8
  %cmp245 = icmp ne i64 %v244, 0
  %cv246 = zext i1 %cmp245 to i32
  store i32 %cv246, ptr %slot48, align 8
  %v247 = load i32, ptr %slot48, align 8
  %cv248 = zext i32 %v247 to i64
  %cond249 = icmp ne i64 %cv248, 0
  br i1 %cond249, label %bb_rcgdec44, label %bb_rcgslow44
bb_rcgslow44:
  %v250 = load i64, ptr %slot35, align 8
  %v251 = load i64, ptr %slot32, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v250, i64 %v251) nomerge, !dbg !116
  br label %bb_rcgdone44
bb_rcgdec44:
  %v252 = load i64, ptr %slot44, align 8
  %v253 = load i64, ptr %slot36, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %rgep255 = getelementptr i8, ptr %p254, i64 -24
  store i64 %v252, ptr %rgep255, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear44
bb_rcgclear44:
  %v256 = load i64, ptr %slot32, align 8
  %p257 = inttoptr i64 %v256 to ptr
  store i64 0, ptr %p257, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone44
bb_rcgdone44:
  br label %bb_rcslotdone28
bb_rcslotowner28:
  %v258 = load i64, ptr %slot18, align 8
  store i64 %v258, ptr %slot49, align 8
  %v259 = load i64, ptr %slot32, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld261, ptr %slot50, align 8
  %v262 = load i64, ptr %slot50, align 8
  %cmp263 = icmp ne i64 %v262, 0
  %cv264 = zext i1 %cmp263 to i32
  store i32 %cv264, ptr %slot51, align 8
  %v265 = load i32, ptr %slot51, align 8
  %cv266 = zext i32 %v265 to i64
  %cond267 = icmp ne i64 %cv266, 0
  br i1 %cond267, label %bb_rcgnn59, label %bb_rcgdone59
bb_rcgnn59:
  %v268 = load i64, ptr %slot50, align 8
  %op269 = sub i64 %v268, 16
  store i64 %op269, ptr %slot52, align 8
  %v270 = load i64, ptr %slot50, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %rgep272 = getelementptr i8, ptr %p271, i64 -16
  %ld273 = load i64, ptr %rgep272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld273, ptr %slot53, align 8
  %v274 = load i64, ptr %slot53, align 8
  %op275 = and i64 %v274, 4611686018427387906
  store i64 %op275, ptr %slot54, align 8
  %v276 = load i64, ptr %slot54, align 8
  %cmp277 = icmp ne i64 %v276, 0
  %cv278 = zext i1 %cmp277 to i32
  store i32 %cv278, ptr %slot55, align 8
  %v279 = load i32, ptr %slot55, align 8
  %cv280 = zext i32 %v279 to i64
  %cond281 = icmp ne i64 %cv280, 0
  br i1 %cond281, label %bb_rcgclear59, label %bb_rcgcounted59
bb_rcgcounted59:
  %v282 = load i64, ptr %slot50, align 8
  %op283 = sub i64 %v282, 32
  store i64 %op283, ptr %slot56, align 8
  %v284 = load i64, ptr %slot50, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %rgep286 = getelementptr i8, ptr %p285, i64 -32
  %ld287 = load i64, ptr %rgep286, align 8, !alias.scope !9, !noalias !10
  store i64 %ld287, ptr %slot57, align 8
  %v288 = load i64, ptr %slot57, align 8
  %op289 = sub i64 %v288, 1
  store i64 %op289, ptr %slot58, align 8
  %v290 = load i64, ptr %slot58, align 8
  %cmp291 = icmp eq i64 %v290, 0
  %cv292 = zext i1 %cmp291 to i32
  store i32 %cv292, ptr %slot59, align 8
  %v293 = load i32, ptr %slot59, align 8
  %cv294 = zext i32 %v293 to i64
  %cond295 = icmp ne i64 %cv294, 0
  br i1 %cond295, label %bb_rcglast59, label %bb_rcgdec59
bb_rcglast59:
  %v296 = load i64, ptr %slot50, align 8
  %op297 = sub i64 %v296, 24
  store i64 %op297, ptr %slot60, align 8
  %v298 = load i64, ptr %slot50, align 8
  %p299 = inttoptr i64 %v298 to ptr
  %rgep300 = getelementptr i8, ptr %p299, i64 -24
  %ld301 = load i64, ptr %rgep300, align 8, !alias.scope !9, !noalias !10
  store i64 %ld301, ptr %slot61, align 8
  %v302 = load i64, ptr %slot61, align 8
  %cmp303 = icmp ne i64 %v302, 0
  %cv304 = zext i1 %cmp303 to i32
  store i32 %cv304, ptr %slot62, align 8
  %v305 = load i32, ptr %slot62, align 8
  %cv306 = zext i32 %v305 to i64
  %cond307 = icmp ne i64 %cv306, 0
  br i1 %cond307, label %bb_rcgdec59, label %bb_rcgslow59
bb_rcgslow59:
  %v308 = load i64, ptr %slot49, align 8
  %v309 = load i64, ptr %slot32, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v308, i64 %v309) nomerge, !dbg !116
  br label %bb_rcgdone59
bb_rcgdec59:
  %v310 = load i64, ptr %slot58, align 8
  %v311 = load i64, ptr %slot50, align 8
  %p312 = inttoptr i64 %v311 to ptr
  %rgep313 = getelementptr i8, ptr %p312, i64 -32
  store i64 %v310, ptr %rgep313, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear59
bb_rcgclear59:
  %v314 = load i64, ptr %slot32, align 8
  %p315 = inttoptr i64 %v314 to ptr
  store i64 0, ptr %p315, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone59
bb_rcgdone59:
  br label %bb_rcslotdone28
bb_rcslotdone28:
  %v316 = load i64, ptr %slot12, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i64 64, ptr %p317, align 8, !alias.scope !3, !noalias !4
  %v318 = load i64, ptr %slot12, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %ld320 = load i64, ptr %p319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld320, ptr %slot63, align 8
  %v321 = load i64, ptr %slot63, align 8
  ret i64 %v321
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_1c5d9648c819e0c8d31985f0371b3d3452cb3afe635ba4c788a2e64e33e03775(i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i64 @myl_qbe_stream_write_bytes(ptr, i64, ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_1911756de7f59ca5dc03632e8aff84e3dec84ff89250c35daea760d849066bd7", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_1911756de7f59ca5dc03632e8aff84e3dec84ff89250c35daea760d849066bd7", linkageName: "myl_f_1911756de7f59ca5dc03632e8aff84e3dec84ff89250c35daea760d849066bd7", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1671066893849019009, i64 0, !"myl_f_1911756de7f59ca5dc03632e8aff84e3dec84ff89250c35daea760d849066bd7"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
