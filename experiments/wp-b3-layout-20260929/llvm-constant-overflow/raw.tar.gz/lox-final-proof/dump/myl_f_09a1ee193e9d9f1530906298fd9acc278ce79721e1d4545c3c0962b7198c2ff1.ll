target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_09a1ee193e9d9f1530906298fd9acc278ce79721e1d4545c3c0962b7198c2ff1(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i32, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i32, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i32, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i32, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i32, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i32, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i32, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i32, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i32, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i32, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i32, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  %v1125 = load i64, ptr %slot1, align 8
  %op1126 = add i64 %v1125, 32
  store i64 %op1126, ptr %slot6, align 8
  %mem1127 = alloca i8, i64 8, align 8
  %ptr1128 = ptrtoint ptr %mem1127 to i64
  store i64 %ptr1128, ptr %slot7, align 8
  %mem1129 = alloca i8, i64 8, align 8
  %ptr1130 = ptrtoint ptr %mem1129 to i64
  store i64 %ptr1130, ptr %slot8, align 8
  %mem1131 = alloca i8, i64 8, align 8
  %ptr1132 = ptrtoint ptr %mem1131 to i64
  store i64 %ptr1132, ptr %slot9, align 8
  %mem1133 = alloca i8, i64 8, align 8
  %ptr1134 = ptrtoint ptr %mem1133 to i64
  store i64 %ptr1134, ptr %slot10, align 8
  %mem1135 = alloca i8, i64 8, align 8
  %ptr1136 = ptrtoint ptr %mem1135 to i64
  store i64 %ptr1136, ptr %slot11, align 8
  %mem1137 = alloca i8, i64 8, align 8
  %ptr1138 = ptrtoint ptr %mem1137 to i64
  store i64 %ptr1138, ptr %slot12, align 8
  %mem1139 = alloca i8, i64 8, align 8
  %ptr1140 = ptrtoint ptr %mem1139 to i64
  store i64 %ptr1140, ptr %slot13, align 8
  %mem1141 = alloca i8, i64 8, align 8
  %ptr1142 = ptrtoint ptr %mem1141 to i64
  store i64 %ptr1142, ptr %slot14, align 8
  %mem1143 = alloca i8, i64 8, align 8
  %ptr1144 = ptrtoint ptr %mem1143 to i64
  store i64 %ptr1144, ptr %slot15, align 8
  %mem1145 = alloca i8, i64 8, align 8
  %ptr1146 = ptrtoint ptr %mem1145 to i64
  store i64 %ptr1146, ptr %slot16, align 8
  %mem1147 = alloca i8, i64 8, align 8
  %ptr1148 = ptrtoint ptr %mem1147 to i64
  store i64 %ptr1148, ptr %slot17, align 8
  %mem1149 = alloca i8, i64 8, align 8
  %ptr1150 = ptrtoint ptr %mem1149 to i64
  store i64 %ptr1150, ptr %slot18, align 8
  %mem1151 = alloca i8, i64 208, align 8
  %ptr1152 = ptrtoint ptr %mem1151 to i64
  store i64 %ptr1152, ptr %slot19, align 8
  %mem1153 = alloca i8, i64 8, align 8
  %ptr1154 = ptrtoint ptr %mem1153 to i64
  store i64 %ptr1154, ptr %slot20, align 8
  %mem1155 = alloca i8, i64 8, align 8
  %ptr1156 = ptrtoint ptr %mem1155 to i64
  store i64 %ptr1156, ptr %slot21, align 8
  %mem1157 = alloca i8, i64 8, align 8
  %ptr1158 = ptrtoint ptr %mem1157 to i64
  store i64 %ptr1158, ptr %slot22, align 8
  %mem1159 = alloca i8, i64 8, align 8
  %ptr1160 = ptrtoint ptr %mem1159 to i64
  store i64 %ptr1160, ptr %slot23, align 8
  %mem1161 = alloca i8, i64 8, align 8
  %ptr1162 = ptrtoint ptr %mem1161 to i64
  store i64 %ptr1162, ptr %slot24, align 8
  %mem1163 = alloca i8, i64 8, align 8
  %ptr1164 = ptrtoint ptr %mem1163 to i64
  store i64 %ptr1164, ptr %slot25, align 8
  %mem1165 = alloca i8, i64 8, align 8
  %ptr1166 = ptrtoint ptr %mem1165 to i64
  store i64 %ptr1166, ptr %slot26, align 8
  %mem1167 = alloca i8, i64 8, align 8
  %ptr1168 = ptrtoint ptr %mem1167 to i64
  store i64 %ptr1168, ptr %slot27, align 8
  %mem1169 = alloca i8, i64 8, align 8
  %ptr1170 = ptrtoint ptr %mem1169 to i64
  store i64 %ptr1170, ptr %slot28, align 8
  %mem1171 = alloca i8, i64 8, align 8
  %ptr1172 = ptrtoint ptr %mem1171 to i64
  store i64 %ptr1172, ptr %slot29, align 8
  %mem1173 = alloca i8, i64 8, align 8
  %ptr1174 = ptrtoint ptr %mem1173 to i64
  store i64 %ptr1174, ptr %slot30, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1175 = alloca i8, i64 8, align 8
  %ptr1176 = ptrtoint ptr %mem1175 to i64
  store i64 %ptr1176, ptr %slot31, align 8
  %v1177 = load i64, ptr %slot1, align 8
  %op1178 = add i64 %v1177, 64
  store i64 %op1178, ptr %slot32, align 8
  %v1179 = load i64, ptr %slot32, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  %ld1181 = load i64, ptr %p1180, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1181, ptr %slot33, align 8
  %stack1182 = call ptr @llvm.stacksave()
  %stackaddr1183 = ptrtoint ptr %stack1182 to i64
  %v1184 = load i64, ptr %slot33, align 8
  %cmp1185 = icmp ult i64 %stackaddr1183, %v1184
  %cv1186 = zext i1 %cmp1185 to i64
  store i64 %cv1186, ptr %slot34, align 8
  %v1187 = load i64, ptr %slot34, align 8
  %cond1188 = icmp ne i64 %v1187, 0
  br i1 %cond1188, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1189 = load i64, ptr %slot1, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  call void @myl_qbe_fail_frame(ptr %p1190) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1191 = load i64, ptr %slot25, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  store i64 0, ptr %p1192, align 8, !alias.scope !3, !noalias !4
  %v1193 = load i64, ptr %slot26, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i64 0, ptr %p1194, align 8, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot27, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  store i64 0, ptr %p1196, align 8, !alias.scope !3, !noalias !4
  %v1197 = load i64, ptr %slot2, align 8
  %v1198 = load i64, ptr %slot21, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  store i64 %v1197, ptr %p1199, align 8, !alias.scope !3, !noalias !4
  %v1200 = load i64, ptr %slot3, align 8
  %v1201 = load i64, ptr %slot22, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  store i64 %v1200, ptr %p1202, align 8, !alias.scope !3, !noalias !4
  %v1203 = load i64, ptr %slot4, align 8
  %v1204 = load i64, ptr %slot23, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  store i64 %v1203, ptr %p1205, align 8, !alias.scope !3, !noalias !4
  %v1206 = load i64, ptr %slot5, align 8
  %v1207 = load i64, ptr %slot24, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  store i64 %v1206, ptr %p1208, align 8, !alias.scope !3, !noalias !4
  %v1209 = load i64, ptr %slot1, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  %call1211 = call ptr @myl_qbe_heap(ptr %p1210) nomerge, !dbg !112
  %calladdr1212 = ptrtoint ptr %call1211 to i64
  store i64 %calladdr1212, ptr %slot35, align 8
  %v1213 = load i64, ptr %slot1, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %call1215 = call i64 @myl_qbe_region_mark(ptr %p1214) nomerge, !dbg !112
  store i64 %call1215, ptr %slot36, align 8
  %v1216 = load i64, ptr %slot7, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  store i32 0, ptr %p1217, align 4, !alias.scope !3, !noalias !4
  %v1218 = load i64, ptr %slot8, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  store i32 0, ptr %p1219, align 4, !alias.scope !3, !noalias !4
  %v1220 = load i64, ptr %slot9, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  store i32 0, ptr %p1221, align 4, !alias.scope !3, !noalias !4
  %v1222 = load i64, ptr %slot10, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  store i32 0, ptr %p1223, align 4, !alias.scope !3, !noalias !4
  %v1224 = load i64, ptr %slot11, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  store i32 0, ptr %p1225, align 4, !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot12, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  store i32 0, ptr %p1227, align 4, !alias.scope !3, !noalias !4
  %v1228 = load i64, ptr %slot13, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  store i32 0, ptr %p1229, align 4, !alias.scope !3, !noalias !4
  %v1230 = load i64, ptr %slot14, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  store i32 0, ptr %p1231, align 4, !alias.scope !3, !noalias !4
  %v1232 = load i64, ptr %slot15, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  store i32 0, ptr %p1233, align 4, !alias.scope !3, !noalias !4
  %v1234 = load i64, ptr %slot16, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  store i32 0, ptr %p1235, align 4, !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot8, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i32 2, ptr %p1237, align 4, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot10, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  store i32 2, ptr %p1239, align 4, !alias.scope !3, !noalias !4
  %v1240 = load i64, ptr %slot12, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  store i32 2, ptr %p1241, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1242 = load i64, ptr %slot21, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  %ld1244 = load i64, ptr %p1243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1244, ptr %slot37, align 8
  %v1245 = load i64, ptr %slot37, align 8
  %v1246 = load i64, ptr %slot28, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  store i64 %v1245, ptr %p1247, align 8, !alias.scope !3, !noalias !4
  %v1248 = load i64, ptr %slot22, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  %ld1250 = load i64, ptr %p1249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1250, ptr %slot38, align 8
  %v1251 = load i64, ptr %slot38, align 8
  %v1252 = load i64, ptr %slot29, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  store i64 %v1251, ptr %p1253, align 8, !alias.scope !3, !noalias !4
  %p1254 = inttoptr i64 ptrtoint (ptr @myl_lit_651dfa874c87674e57d05784fbb331bf215d6ec2b7d4c57db6383d02b47d316a to i64) to ptr
  %ld1255 = load i64, ptr %p1254, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1255, ptr %slot39, align 8
  %v1256 = load i64, ptr %slot39, align 8
  %v1257 = load i64, ptr %slot30, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  store i64 %v1256, ptr %p1258, align 8, !alias.scope !3, !noalias !4
  %v1259 = load i64, ptr %slot30, align 8
  %p1260 = inttoptr i64 %v1259 to ptr
  %ld1261 = load i64, ptr %p1260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1261, ptr %slot40, align 8
  %v1262 = load i64, ptr %slot40, align 8
  %v1263 = load i64, ptr %slot18, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  store i64 %v1262, ptr %p1264, align 8, !alias.scope !3, !noalias !4
  %v1265 = load i64, ptr %slot18, align 8
  store i64 %v1265, ptr %slot41, align 8
  %v1266 = load i64, ptr %slot19, align 8
  store i64 %v1266, ptr %slot42, align 8
  %v1267 = load i64, ptr %slot41, align 8
  %v1268 = load i64, ptr %slot42, align 8
  %p1269 = inttoptr i64 %v1267 to ptr
  %p1270 = inttoptr i64 %v1268 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1270, ptr %p1269, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1271 = load i64, ptr %slot16, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  store i32 2, ptr %p1272, align 4, !alias.scope !3, !noalias !4
  %v1273 = load i64, ptr %slot15, align 8
  %p1274 = inttoptr i64 %v1273 to ptr
  store i32 1, ptr %p1274, align 4, !alias.scope !3, !noalias !4
  %v1275 = load i64, ptr %slot17, align 8
  store i64 %v1275, ptr %slot43, align 8
  %v1276 = load i64, ptr %slot19, align 8
  store i64 %v1276, ptr %slot44, align 8
  %v1277 = load i64, ptr %slot44, align 8
  %v1278 = load i64, ptr %slot43, align 8
  %p1279 = inttoptr i64 %v1277 to ptr
  %p1280 = inttoptr i64 %v1278 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1280, ptr %p1279, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1281 = load i64, ptr %slot14, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i32 2, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot16, align 8
  %p1284 = inttoptr i64 %v1283 to ptr
  %ld1285 = load i32, ptr %p1284, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1285, ptr %slot45, align 8
  %v1286 = load i32, ptr %slot45, align 8
  %v1287 = load i64, ptr %slot14, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i32 %v1286, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot15, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  store i32 0, ptr %p1290, align 4, !alias.scope !3, !noalias !4
  %v1291 = load i64, ptr %slot13, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  store i32 1, ptr %p1292, align 4, !alias.scope !3, !noalias !4
  %v1293 = load i64, ptr %slot43, align 8
  %p1294 = inttoptr i64 %v1293 to ptr
  %ld1295 = load i64, ptr %p1294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1295, ptr %slot46, align 8
  %v1296 = load i64, ptr %slot46, align 8
  %v1297 = load i64, ptr %slot30, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  store i64 %v1296, ptr %p1298, align 8, !alias.scope !3, !noalias !4
  %v1299 = load i64, ptr %slot30, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  %ld1301 = load i64, ptr %p1300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1301, ptr %slot47, align 8
  %v1302 = load i64, ptr %slot47, align 8
  %v1303 = load i64, ptr %slot18, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  store i64 %v1302, ptr %p1304, align 8, !alias.scope !3, !noalias !4
  %v1305 = load i64, ptr %slot18, align 8
  store i64 %v1305, ptr %slot48, align 8
  %v1306 = load i64, ptr %slot13, align 8
  %p1307 = inttoptr i64 %v1306 to ptr
  %ld1308 = load i32, ptr %p1307, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1308, ptr %slot49, align 8
  %v1309 = load i64, ptr %slot14, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  %ld1311 = load i32, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1311, ptr %slot50, align 8
  %v1312 = load i32, ptr %slot50, align 8
  %op1313 = and i32 %v1312, 24
  store i32 %op1313, ptr %slot50, align 8
  %v1314 = load i32, ptr %slot50, align 8
  %cmp1315 = icmp eq i32 %v1314, 0
  %cv1316 = zext i1 %cmp1315 to i32
  store i32 %cv1316, ptr %slot51, align 8
  %v1317 = load i32, ptr %slot49, align 8
  %v1318 = load i32, ptr %slot51, align 8
  %op1319 = and i32 %v1317, %v1318
  store i32 %op1319, ptr %slot52, align 8
  %v1320 = load i32, ptr %slot52, align 8
  %cv1321 = zext i32 %v1320 to i64
  %cond1322 = icmp ne i64 %cv1321, 0
  br i1 %cond1322, label %bb_rcprivateown38, label %bb_rcprivateloan38
bb_rcprivateown38:
  %v1323 = load i64, ptr %slot19, align 8
  store i64 %v1323, ptr %slot53, align 8
  %v1324 = load i64, ptr %slot36, align 8
  store i64 %v1324, ptr %slot54, align 8
  %v1325 = load i64, ptr %slot48, align 8
  %v1326 = load i64, ptr %slot53, align 8
  %op1327 = sub i64 %v1325, %v1326
  store i64 %op1327, ptr %slot55, align 8
  %v1328 = load i64, ptr %slot53, align 8
  %v1329 = load i64, ptr %slot48, align 8
  %op1330 = sub i64 %v1328, %v1329
  store i64 %op1330, ptr %slot56, align 8
  %v1331 = load i64, ptr %slot55, align 8
  %cmp1332 = icmp ult i64 %v1331, 8
  %cv1333 = zext i1 %cmp1332 to i32
  store i32 %cv1333, ptr %slot57, align 8
  %v1334 = load i64, ptr %slot56, align 8
  %cmp1335 = icmp ult i64 %v1334, 8
  %cv1336 = zext i1 %cmp1335 to i32
  store i32 %cv1336, ptr %slot58, align 8
  %v1337 = load i32, ptr %slot57, align 8
  %v1338 = load i32, ptr %slot58, align 8
  %op1339 = or i32 %v1337, %v1338
  store i32 %op1339, ptr %slot59, align 8
  %v1340 = load i32, ptr %slot59, align 8
  %cv1341 = zext i32 %v1340 to i64
  %cond1342 = icmp ne i64 %cv1341, 0
  br i1 %cond1342, label %bb_rcmoveslow41, label %bb_rcmovecheck41
bb_rcmovecheck41:
  %v1343 = load i64, ptr %slot48, align 8
  %p1345 = inttoptr i64 %v1343 to ptr
  %gep1346 = getelementptr i8, ptr %p1345, i64 0
  %op1344 = ptrtoint ptr %gep1346 to i64
  store i64 %op1344, ptr %slot60, align 8
  %v1347 = load i64, ptr %slot60, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  %ld1349 = load i64, ptr %p1348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1349, ptr %slot61, align 8
  %v1350 = load i64, ptr %slot61, align 8
  %cmp1351 = icmp ne i64 %v1350, 0
  %cv1352 = zext i1 %cmp1351 to i32
  store i32 %cv1352, ptr %slot62, align 8
  %v1353 = load i32, ptr %slot62, align 8
  %cv1354 = zext i32 %v1353 to i64
  %cond1355 = icmp ne i64 %cv1354, 0
  br i1 %cond1355, label %bb_rcmoveheader49, label %bb_rcmovenext49
bb_rcmoveheader49:
  %v1356 = load i64, ptr %slot61, align 8
  %op1357 = sub i64 %v1356, 16
  store i64 %op1357, ptr %slot63, align 8
  %v1358 = load i64, ptr %slot61, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  %rgep1360 = getelementptr i8, ptr %p1359, i64 -16
  %ld1361 = load i64, ptr %rgep1360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1361, ptr %slot64, align 8
  %v1362 = load i64, ptr %slot64, align 8
  %op1363 = and i64 %v1362, 5764607523034234881
  store i64 %op1363, ptr %slot65, align 8
  %v1364 = load i64, ptr %slot65, align 8
  %cmp1365 = icmp ne i64 %v1364, 0
  %cv1366 = zext i1 %cmp1365 to i32
  store i32 %cv1366, ptr %slot66, align 8
  %v1367 = load i32, ptr %slot66, align 8
  %cv1368 = zext i32 %v1367 to i64
  %cond1369 = icmp ne i64 %cv1368, 0
  br i1 %cond1369, label %bb_rcmoveslow41, label %bb_rcmovenext49
bb_rcmovenext49:
  %v1370 = load i64, ptr %slot48, align 8
  %v1371 = load i64, ptr %slot53, align 8
  %p1372 = inttoptr i64 %v1370 to ptr
  %p1373 = inttoptr i64 %v1371 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1373, ptr %p1372, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1374 = load i64, ptr %slot48, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  store i64 0, ptr %p1375, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved41
bb_rcmoveslow41:
  %v1376 = load i64, ptr %slot35, align 8
  %v1377 = load i64, ptr %slot53, align 8
  %v1378 = load i64, ptr %slot48, align 8
  %v1379 = load i64, ptr %slot54, align 8
  %cv1380 = trunc i64 %v1379 to i32
  %call1381 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v1376, i64 %v1377, i64 %v1378, i32 %cv1380) nomerge, !dbg !114
  store i32 %call1381, ptr %slot67, align 8
  %v1382 = load i32, ptr %slot67, align 8
  %cv1383 = zext i32 %v1382 to i64
  %cond1384 = icmp ne i64 %cv1383, 0
  br i1 %cond1384, label %bb_rcsuccess56, label %bb_rcfailure56
bb_rcfailure56:
  %v1385 = load i64, ptr %slot35, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  %call1387 = call i32 @myl_rc_take_failure(ptr %p1386) nomerge, !dbg !114
  store i32 %call1387, ptr %slot68, align 8
  %v1388 = load i64, ptr %slot1, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %v1390 = load i32, ptr %slot68, align 8
  %call1391 = call i32 @myl_qbe_rc_status(ptr %p1389, i32 %v1390) nomerge, !dbg !114
  store i32 %call1391, ptr %slot69, align 8
  br label %bb_failure
bb_rcsuccess56:
  br label %bb_rcmoved41
bb_rcmoved41:
  %v1392 = load i64, ptr %slot13, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i32 0, ptr %p1393, align 4, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot16, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  store i32 2, ptr %p1395, align 4, !alias.scope !3, !noalias !4
  %v1396 = load i64, ptr %slot15, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  store i32 1, ptr %p1397, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared38
bb_rcprivateloan38:
  %v1398 = load i64, ptr %slot13, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  %ld1400 = load i32, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1400, ptr %slot70, align 8
  %v1401 = load i64, ptr %slot14, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  %ld1403 = load i32, ptr %p1402, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1403, ptr %slot71, align 8
  %v1404 = load i32, ptr %slot71, align 8
  %cmp1405 = icmp eq i32 %v1404, 16
  %cv1406 = zext i1 %cmp1405 to i32
  store i32 %cv1406, ptr %slot72, align 8
  %v1407 = load i32, ptr %slot72, align 8
  %v1408 = load i32, ptr %slot70, align 8
  %op1409 = and i32 %v1407, %v1408
  store i32 %op1409, ptr %slot72, align 8
  %v1410 = load i32, ptr %slot72, align 8
  %cv1411 = zext i32 %v1410 to i64
  %cond1412 = icmp ne i64 %cv1411, 0
  br i1 %cond1412, label %bb_rcprivatemove38, label %bb_rcprivatenew38
bb_rcprivatemove38:
  %v1413 = load i64, ptr %slot19, align 8
  store i64 %v1413, ptr %slot73, align 8
  %v1414 = load i64, ptr %slot48, align 8
  %v1415 = load i64, ptr %slot73, align 8
  %p1416 = inttoptr i64 %v1414 to ptr
  %p1417 = inttoptr i64 %v1415 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1417, ptr %p1416, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1418 = load i64, ptr %slot48, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  store i64 0, ptr %p1419, align 8, !alias.scope !3, !noalias !4
  %v1420 = load i64, ptr %slot16, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  store i32 2, ptr %p1421, align 4, !alias.scope !3, !noalias !4
  %v1422 = load i64, ptr %slot16, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i32 16, ptr %p1423, align 4, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot15, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i32 1, ptr %p1425, align 4, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot13, align 8
  %p1427 = inttoptr i64 %v1426 to ptr
  store i32 0, ptr %p1427, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared38
bb_rcprivatenew38:
  %v1428 = load i64, ptr %slot19, align 8
  store i64 %v1428, ptr %slot74, align 8
  %v1429 = load i64, ptr %slot48, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot75, align 8
  %v1432 = load i64, ptr %slot75, align 8
  %cmp1433 = icmp ne i64 %v1432, 0
  %cv1434 = zext i1 %cmp1433 to i32
  store i32 %cv1434, ptr %slot76, align 8
  %v1435 = load i32, ptr %slot76, align 8
  %cv1436 = zext i32 %v1435 to i64
  %cond1437 = icmp ne i64 %cv1436, 0
  br i1 %cond1437, label %bb_rcgnn74, label %bb_rcgstore74
bb_rcgnn74:
  %v1438 = load i64, ptr %slot75, align 8
  %op1439 = sub i64 %v1438, 16
  store i64 %op1439, ptr %slot77, align 8
  %v1440 = load i64, ptr %slot75, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %rgep1442 = getelementptr i8, ptr %p1441, i64 -16
  %ld1443 = load i64, ptr %rgep1442, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1443, ptr %slot78, align 8
  %v1444 = load i64, ptr %slot78, align 8
  %op1445 = and i64 %v1444, 4611686018427387906
  store i64 %op1445, ptr %slot79, align 8
  %v1446 = load i64, ptr %slot79, align 8
  %cmp1447 = icmp ne i64 %v1446, 0
  %cv1448 = zext i1 %cmp1447 to i32
  store i32 %cv1448, ptr %slot80, align 8
  %v1449 = load i32, ptr %slot80, align 8
  %cv1450 = zext i32 %v1449 to i64
  %cond1451 = icmp ne i64 %cv1450, 0
  br i1 %cond1451, label %bb_rcgstore74, label %bb_rcginc74
bb_rcginc74:
  %v1452 = load i64, ptr %slot75, align 8
  %op1453 = sub i64 %v1452, 24
  store i64 %op1453, ptr %slot81, align 8
  %v1454 = load i64, ptr %slot75, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %rgep1456 = getelementptr i8, ptr %p1455, i64 -24
  %ld1457 = load i64, ptr %rgep1456, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1457, ptr %slot82, align 8
  %v1458 = load i64, ptr %slot82, align 8
  %op1459 = add i64 %v1458, 1
  store i64 %op1459, ptr %slot83, align 8
  %v1460 = load i64, ptr %slot83, align 8
  %cmp1461 = icmp eq i64 %v1460, 0
  %cv1462 = zext i1 %cmp1461 to i32
  store i32 %cv1462, ptr %slot84, align 8
  %v1463 = load i32, ptr %slot84, align 8
  %cv1464 = zext i32 %v1463 to i64
  %cond1465 = icmp ne i64 %cv1464, 0
  br i1 %cond1465, label %bb_rcglimit74, label %bb_rcgcapacity74
bb_rcglimit74:
  %v1466 = load i64, ptr %slot1, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  %call1468 = call i32 @myl_qbe_rc_status(ptr %p1467, i32 2) nomerge, !dbg !114
  store i32 %call1468, ptr %slot85, align 8
  br label %bb_failure
bb_rcgcapacity74:
  %v1469 = load i64, ptr %slot83, align 8
  %v1470 = load i64, ptr %slot75, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  %rgep1472 = getelementptr i8, ptr %p1471, i64 -24
  store i64 %v1469, ptr %rgep1472, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore74
bb_rcgstore74:
  %v1473 = load i64, ptr %slot75, align 8
  %v1474 = load i64, ptr %slot74, align 8
  %p1475 = inttoptr i64 %v1474 to ptr
  store i64 %v1473, ptr %p1475, align 8, !alias.scope !3, !noalias !4
  %v1476 = load i64, ptr %slot16, align 8
  %p1477 = inttoptr i64 %v1476 to ptr
  store i32 2, ptr %p1477, align 4, !alias.scope !3, !noalias !4
  %v1478 = load i64, ptr %slot16, align 8
  %p1479 = inttoptr i64 %v1478 to ptr
  store i32 16, ptr %p1479, align 4, !alias.scope !3, !noalias !4
  %v1480 = load i64, ptr %slot15, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  store i32 1, ptr %p1481, align 4, !alias.scope !3, !noalias !4
  %v1482 = load i64, ptr %slot13, align 8
  %p1483 = inttoptr i64 %v1482 to ptr
  %ld1484 = load i32, ptr %p1483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1484, ptr %slot86, align 8
  %v1485 = load i32, ptr %slot86, align 8
  %cv1486 = zext i32 %v1485 to i64
  %cond1487 = icmp ne i64 %cv1486, 0
  br i1 %cond1487, label %bb_rcslotdrop90, label %bb_rcslotdone90
bb_rcslotdrop90:
  %v1488 = load i64, ptr %slot13, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  store i32 0, ptr %p1489, align 4, !alias.scope !3, !noalias !4
  %v1490 = load i64, ptr %slot17, align 8
  store i64 %v1490, ptr %slot87, align 8
  %v1491 = load i64, ptr %slot14, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  %ld1493 = load i32, ptr %p1492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1493, ptr %slot88, align 8
  %v1494 = load i32, ptr %slot88, align 8
  %op1495 = and i32 %v1494, 28
  store i32 %op1495, ptr %slot89, align 8
  %v1496 = load i32, ptr %slot89, align 8
  %cv1497 = zext i32 %v1496 to i64
  %cond1498 = icmp ne i64 %cv1497, 0
  br i1 %cond1498, label %bb_rcslotrole90, label %bb_rcslotowner90
bb_rcslotrole90:
  %v1499 = load i64, ptr %slot35, align 8
  store i64 %v1499, ptr %slot90, align 8
  %v1500 = load i64, ptr %slot87, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  %ld1502 = load i64, ptr %p1501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1502, ptr %slot91, align 8
  %v1503 = load i64, ptr %slot91, align 8
  %cmp1504 = icmp ne i64 %v1503, 0
  %cv1505 = zext i1 %cmp1504 to i32
  store i32 %cv1505, ptr %slot92, align 8
  %v1506 = load i32, ptr %slot92, align 8
  %cv1507 = zext i32 %v1506 to i64
  %cond1508 = icmp ne i64 %cv1507, 0
  br i1 %cond1508, label %bb_rcgnn106, label %bb_rcgdone106
bb_rcgnn106:
  %v1509 = load i64, ptr %slot91, align 8
  %op1510 = sub i64 %v1509, 16
  store i64 %op1510, ptr %slot93, align 8
  %v1511 = load i64, ptr %slot91, align 8
  %p1512 = inttoptr i64 %v1511 to ptr
  %rgep1513 = getelementptr i8, ptr %p1512, i64 -16
  %ld1514 = load i64, ptr %rgep1513, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1514, ptr %slot94, align 8
  %v1515 = load i64, ptr %slot94, align 8
  %op1516 = and i64 %v1515, 4611686018427387906
  store i64 %op1516, ptr %slot95, align 8
  %v1517 = load i64, ptr %slot95, align 8
  %cmp1518 = icmp ne i64 %v1517, 0
  %cv1519 = zext i1 %cmp1518 to i32
  store i32 %cv1519, ptr %slot96, align 8
  %v1520 = load i32, ptr %slot96, align 8
  %cv1521 = zext i32 %v1520 to i64
  %cond1522 = icmp ne i64 %cv1521, 0
  br i1 %cond1522, label %bb_rcgclear106, label %bb_rcgcounted106
bb_rcgcounted106:
  %v1523 = load i64, ptr %slot91, align 8
  %op1524 = sub i64 %v1523, 24
  store i64 %op1524, ptr %slot97, align 8
  %v1525 = load i64, ptr %slot91, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %rgep1527 = getelementptr i8, ptr %p1526, i64 -24
  %ld1528 = load i64, ptr %rgep1527, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1528, ptr %slot98, align 8
  %v1529 = load i64, ptr %slot98, align 8
  %op1530 = sub i64 %v1529, 1
  store i64 %op1530, ptr %slot99, align 8
  %v1531 = load i64, ptr %slot99, align 8
  %cmp1532 = icmp eq i64 %v1531, 0
  %cv1533 = zext i1 %cmp1532 to i32
  store i32 %cv1533, ptr %slot100, align 8
  %v1534 = load i32, ptr %slot100, align 8
  %cv1535 = zext i32 %v1534 to i64
  %cond1536 = icmp ne i64 %cv1535, 0
  br i1 %cond1536, label %bb_rcglast106, label %bb_rcgdec106
bb_rcglast106:
  %v1537 = load i64, ptr %slot91, align 8
  %op1538 = sub i64 %v1537, 32
  store i64 %op1538, ptr %slot101, align 8
  %v1539 = load i64, ptr %slot91, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  %rgep1541 = getelementptr i8, ptr %p1540, i64 -32
  %ld1542 = load i64, ptr %rgep1541, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1542, ptr %slot102, align 8
  %v1543 = load i64, ptr %slot102, align 8
  %cmp1544 = icmp ne i64 %v1543, 0
  %cv1545 = zext i1 %cmp1544 to i32
  store i32 %cv1545, ptr %slot103, align 8
  %v1546 = load i32, ptr %slot103, align 8
  %cv1547 = zext i32 %v1546 to i64
  %cond1548 = icmp ne i64 %cv1547, 0
  br i1 %cond1548, label %bb_rcgdec106, label %bb_rcgslow106
bb_rcgslow106:
  %v1549 = load i64, ptr %slot90, align 8
  %v1550 = load i64, ptr %slot87, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v1549, i64 %v1550) nomerge, !dbg !114
  br label %bb_rcgdone106
bb_rcgdec106:
  %v1551 = load i64, ptr %slot99, align 8
  %v1552 = load i64, ptr %slot91, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  %rgep1554 = getelementptr i8, ptr %p1553, i64 -24
  store i64 %v1551, ptr %rgep1554, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear106
bb_rcgclear106:
  %v1555 = load i64, ptr %slot87, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  store i64 0, ptr %p1556, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone106
bb_rcgdone106:
  br label %bb_rcslotdone90
bb_rcslotowner90:
  %v1557 = load i64, ptr %slot35, align 8
  store i64 %v1557, ptr %slot104, align 8
  %v1558 = load i64, ptr %slot87, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  %ld1560 = load i64, ptr %p1559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1560, ptr %slot105, align 8
  %v1561 = load i64, ptr %slot105, align 8
  %cmp1562 = icmp ne i64 %v1561, 0
  %cv1563 = zext i1 %cmp1562 to i32
  store i32 %cv1563, ptr %slot106, align 8
  %v1564 = load i32, ptr %slot106, align 8
  %cv1565 = zext i32 %v1564 to i64
  %cond1566 = icmp ne i64 %cv1565, 0
  br i1 %cond1566, label %bb_rcgnn121, label %bb_rcgdone121
bb_rcgnn121:
  %v1567 = load i64, ptr %slot105, align 8
  %op1568 = sub i64 %v1567, 16
  store i64 %op1568, ptr %slot107, align 8
  %v1569 = load i64, ptr %slot105, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  %rgep1571 = getelementptr i8, ptr %p1570, i64 -16
  %ld1572 = load i64, ptr %rgep1571, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1572, ptr %slot108, align 8
  %v1573 = load i64, ptr %slot108, align 8
  %op1574 = and i64 %v1573, 4611686018427387906
  store i64 %op1574, ptr %slot109, align 8
  %v1575 = load i64, ptr %slot109, align 8
  %cmp1576 = icmp ne i64 %v1575, 0
  %cv1577 = zext i1 %cmp1576 to i32
  store i32 %cv1577, ptr %slot110, align 8
  %v1578 = load i32, ptr %slot110, align 8
  %cv1579 = zext i32 %v1578 to i64
  %cond1580 = icmp ne i64 %cv1579, 0
  br i1 %cond1580, label %bb_rcgclear121, label %bb_rcgcounted121
bb_rcgcounted121:
  %v1581 = load i64, ptr %slot105, align 8
  %op1582 = sub i64 %v1581, 32
  store i64 %op1582, ptr %slot111, align 8
  %v1583 = load i64, ptr %slot105, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %rgep1585 = getelementptr i8, ptr %p1584, i64 -32
  %ld1586 = load i64, ptr %rgep1585, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1586, ptr %slot112, align 8
  %v1587 = load i64, ptr %slot112, align 8
  %op1588 = sub i64 %v1587, 1
  store i64 %op1588, ptr %slot113, align 8
  %v1589 = load i64, ptr %slot113, align 8
  %cmp1590 = icmp eq i64 %v1589, 0
  %cv1591 = zext i1 %cmp1590 to i32
  store i32 %cv1591, ptr %slot114, align 8
  %v1592 = load i32, ptr %slot114, align 8
  %cv1593 = zext i32 %v1592 to i64
  %cond1594 = icmp ne i64 %cv1593, 0
  br i1 %cond1594, label %bb_rcglast121, label %bb_rcgdec121
bb_rcglast121:
  %v1595 = load i64, ptr %slot105, align 8
  %op1596 = sub i64 %v1595, 24
  store i64 %op1596, ptr %slot115, align 8
  %v1597 = load i64, ptr %slot105, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  %rgep1599 = getelementptr i8, ptr %p1598, i64 -24
  %ld1600 = load i64, ptr %rgep1599, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1600, ptr %slot116, align 8
  %v1601 = load i64, ptr %slot116, align 8
  %cmp1602 = icmp ne i64 %v1601, 0
  %cv1603 = zext i1 %cmp1602 to i32
  store i32 %cv1603, ptr %slot117, align 8
  %v1604 = load i32, ptr %slot117, align 8
  %cv1605 = zext i32 %v1604 to i64
  %cond1606 = icmp ne i64 %cv1605, 0
  br i1 %cond1606, label %bb_rcgdec121, label %bb_rcgslow121
bb_rcgslow121:
  %v1607 = load i64, ptr %slot104, align 8
  %v1608 = load i64, ptr %slot87, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v1607, i64 %v1608) nomerge, !dbg !114
  br label %bb_rcgdone121
bb_rcgdec121:
  %v1609 = load i64, ptr %slot113, align 8
  %v1610 = load i64, ptr %slot105, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  %rgep1612 = getelementptr i8, ptr %p1611, i64 -32
  store i64 %v1609, ptr %rgep1612, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear121
bb_rcgclear121:
  %v1613 = load i64, ptr %slot87, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i64 0, ptr %p1614, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone121
bb_rcgdone121:
  br label %bb_rcslotdone90
bb_rcslotdone90:
  br label %bb_rcprivateprepared38
bb_rcprivateprepared38:
  %v1615 = load i64, ptr %slot9, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %ld1617 = load i32, ptr %p1616, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1617, ptr %slot118, align 8
  %v1618 = load i32, ptr %slot118, align 8
  %cv1619 = zext i32 %v1618 to i64
  %cond1620 = icmp ne i64 %cv1619, 0
  br i1 %cond1620, label %bb_rcslotdrop128, label %bb_rcslotdone128
bb_rcslotdrop128:
  %v1621 = load i64, ptr %slot9, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  store i32 0, ptr %p1622, align 4, !alias.scope !3, !noalias !4
  %v1623 = load i64, ptr %slot26, align 8
  store i64 %v1623, ptr %slot119, align 8
  %v1624 = load i64, ptr %slot10, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  %ld1626 = load i32, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1626, ptr %slot120, align 8
  %v1627 = load i32, ptr %slot120, align 8
  %op1628 = and i32 %v1627, 28
  store i32 %op1628, ptr %slot121, align 8
  %v1629 = load i32, ptr %slot121, align 8
  %cv1630 = zext i32 %v1629 to i64
  %cond1631 = icmp ne i64 %cv1630, 0
  br i1 %cond1631, label %bb_rcslotrole128, label %bb_rcslotowner128
bb_rcslotrole128:
  %v1632 = load i64, ptr %slot35, align 8
  store i64 %v1632, ptr %slot122, align 8
  %v1633 = load i64, ptr %slot119, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  %ld1635 = load i64, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1635, ptr %slot123, align 8
  %v1636 = load i64, ptr %slot123, align 8
  %cmp1637 = icmp ne i64 %v1636, 0
  %cv1638 = zext i1 %cmp1637 to i32
  store i32 %cv1638, ptr %slot124, align 8
  %v1639 = load i32, ptr %slot124, align 8
  %cv1640 = zext i32 %v1639 to i64
  %cond1641 = icmp ne i64 %cv1640, 0
  br i1 %cond1641, label %bb_rcgnn144, label %bb_rcgdone144
bb_rcgnn144:
  %v1642 = load i64, ptr %slot123, align 8
  %op1643 = sub i64 %v1642, 16
  store i64 %op1643, ptr %slot125, align 8
  %v1644 = load i64, ptr %slot123, align 8
  %p1645 = inttoptr i64 %v1644 to ptr
  %rgep1646 = getelementptr i8, ptr %p1645, i64 -16
  %ld1647 = load i64, ptr %rgep1646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1647, ptr %slot126, align 8
  %v1648 = load i64, ptr %slot126, align 8
  %op1649 = and i64 %v1648, 4611686018427387906
  store i64 %op1649, ptr %slot127, align 8
  %v1650 = load i64, ptr %slot127, align 8
  %cmp1651 = icmp ne i64 %v1650, 0
  %cv1652 = zext i1 %cmp1651 to i32
  store i32 %cv1652, ptr %slot128, align 8
  %v1653 = load i32, ptr %slot128, align 8
  %cv1654 = zext i32 %v1653 to i64
  %cond1655 = icmp ne i64 %cv1654, 0
  br i1 %cond1655, label %bb_rcgclear144, label %bb_rcgcounted144
bb_rcgcounted144:
  %v1656 = load i64, ptr %slot123, align 8
  %op1657 = sub i64 %v1656, 24
  store i64 %op1657, ptr %slot129, align 8
  %v1658 = load i64, ptr %slot123, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  %rgep1660 = getelementptr i8, ptr %p1659, i64 -24
  %ld1661 = load i64, ptr %rgep1660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1661, ptr %slot130, align 8
  %v1662 = load i64, ptr %slot130, align 8
  %op1663 = sub i64 %v1662, 1
  store i64 %op1663, ptr %slot131, align 8
  %v1664 = load i64, ptr %slot131, align 8
  %cmp1665 = icmp eq i64 %v1664, 0
  %cv1666 = zext i1 %cmp1665 to i32
  store i32 %cv1666, ptr %slot132, align 8
  %v1667 = load i32, ptr %slot132, align 8
  %cv1668 = zext i32 %v1667 to i64
  %cond1669 = icmp ne i64 %cv1668, 0
  br i1 %cond1669, label %bb_rcglast144, label %bb_rcgdec144
bb_rcglast144:
  %v1670 = load i64, ptr %slot123, align 8
  %op1671 = sub i64 %v1670, 32
  store i64 %op1671, ptr %slot133, align 8
  %v1672 = load i64, ptr %slot123, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %rgep1674 = getelementptr i8, ptr %p1673, i64 -32
  %ld1675 = load i64, ptr %rgep1674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1675, ptr %slot134, align 8
  %v1676 = load i64, ptr %slot134, align 8
  %cmp1677 = icmp ne i64 %v1676, 0
  %cv1678 = zext i1 %cmp1677 to i32
  store i32 %cv1678, ptr %slot135, align 8
  %v1679 = load i32, ptr %slot135, align 8
  %cv1680 = zext i32 %v1679 to i64
  %cond1681 = icmp ne i64 %cv1680, 0
  br i1 %cond1681, label %bb_rcgdec144, label %bb_rcgslow144
bb_rcgslow144:
  %v1682 = load i64, ptr %slot122, align 8
  %v1683 = load i64, ptr %slot119, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v1682, i64 %v1683) nomerge, !dbg !114
  br label %bb_rcgdone144
bb_rcgdec144:
  %v1684 = load i64, ptr %slot131, align 8
  %v1685 = load i64, ptr %slot123, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %rgep1687 = getelementptr i8, ptr %p1686, i64 -24
  store i64 %v1684, ptr %rgep1687, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear144
bb_rcgclear144:
  %v1688 = load i64, ptr %slot119, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  store i64 0, ptr %p1689, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone144
bb_rcgdone144:
  br label %bb_rcslotdone128
bb_rcslotowner128:
  %v1690 = load i64, ptr %slot35, align 8
  store i64 %v1690, ptr %slot136, align 8
  %v1691 = load i64, ptr %slot119, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %ld1693 = load i64, ptr %p1692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1693, ptr %slot137, align 8
  %v1694 = load i64, ptr %slot137, align 8
  %cmp1695 = icmp ne i64 %v1694, 0
  %cv1696 = zext i1 %cmp1695 to i32
  store i32 %cv1696, ptr %slot138, align 8
  %v1697 = load i32, ptr %slot138, align 8
  %cv1698 = zext i32 %v1697 to i64
  %cond1699 = icmp ne i64 %cv1698, 0
  br i1 %cond1699, label %bb_rcgnn159, label %bb_rcgdone159
bb_rcgnn159:
  %v1700 = load i64, ptr %slot137, align 8
  %op1701 = sub i64 %v1700, 16
  store i64 %op1701, ptr %slot139, align 8
  %v1702 = load i64, ptr %slot137, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  %rgep1704 = getelementptr i8, ptr %p1703, i64 -16
  %ld1705 = load i64, ptr %rgep1704, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1705, ptr %slot140, align 8
  %v1706 = load i64, ptr %slot140, align 8
  %op1707 = and i64 %v1706, 4611686018427387906
  store i64 %op1707, ptr %slot141, align 8
  %v1708 = load i64, ptr %slot141, align 8
  %cmp1709 = icmp ne i64 %v1708, 0
  %cv1710 = zext i1 %cmp1709 to i32
  store i32 %cv1710, ptr %slot142, align 8
  %v1711 = load i32, ptr %slot142, align 8
  %cv1712 = zext i32 %v1711 to i64
  %cond1713 = icmp ne i64 %cv1712, 0
  br i1 %cond1713, label %bb_rcgclear159, label %bb_rcgcounted159
bb_rcgcounted159:
  %v1714 = load i64, ptr %slot137, align 8
  %op1715 = sub i64 %v1714, 32
  store i64 %op1715, ptr %slot143, align 8
  %v1716 = load i64, ptr %slot137, align 8
  %p1717 = inttoptr i64 %v1716 to ptr
  %rgep1718 = getelementptr i8, ptr %p1717, i64 -32
  %ld1719 = load i64, ptr %rgep1718, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1719, ptr %slot144, align 8
  %v1720 = load i64, ptr %slot144, align 8
  %op1721 = sub i64 %v1720, 1
  store i64 %op1721, ptr %slot145, align 8
  %v1722 = load i64, ptr %slot145, align 8
  %cmp1723 = icmp eq i64 %v1722, 0
  %cv1724 = zext i1 %cmp1723 to i32
  store i32 %cv1724, ptr %slot146, align 8
  %v1725 = load i32, ptr %slot146, align 8
  %cv1726 = zext i32 %v1725 to i64
  %cond1727 = icmp ne i64 %cv1726, 0
  br i1 %cond1727, label %bb_rcglast159, label %bb_rcgdec159
bb_rcglast159:
  %v1728 = load i64, ptr %slot137, align 8
  %op1729 = sub i64 %v1728, 24
  store i64 %op1729, ptr %slot147, align 8
  %v1730 = load i64, ptr %slot137, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  %rgep1732 = getelementptr i8, ptr %p1731, i64 -24
  %ld1733 = load i64, ptr %rgep1732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1733, ptr %slot148, align 8
  %v1734 = load i64, ptr %slot148, align 8
  %cmp1735 = icmp ne i64 %v1734, 0
  %cv1736 = zext i1 %cmp1735 to i32
  store i32 %cv1736, ptr %slot149, align 8
  %v1737 = load i32, ptr %slot149, align 8
  %cv1738 = zext i32 %v1737 to i64
  %cond1739 = icmp ne i64 %cv1738, 0
  br i1 %cond1739, label %bb_rcgdec159, label %bb_rcgslow159
bb_rcgslow159:
  %v1740 = load i64, ptr %slot136, align 8
  %v1741 = load i64, ptr %slot119, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v1740, i64 %v1741) nomerge, !dbg !114
  br label %bb_rcgdone159
bb_rcgdec159:
  %v1742 = load i64, ptr %slot145, align 8
  %v1743 = load i64, ptr %slot137, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  %rgep1745 = getelementptr i8, ptr %p1744, i64 -32
  store i64 %v1742, ptr %rgep1745, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear159
bb_rcgclear159:
  %v1746 = load i64, ptr %slot119, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  store i64 0, ptr %p1747, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone159
bb_rcgdone159:
  br label %bb_rcslotdone128
bb_rcslotdone128:
  %v1748 = load i64, ptr %slot26, align 8
  store i64 %v1748, ptr %slot150, align 8
  %v1749 = load i64, ptr %slot19, align 8
  store i64 %v1749, ptr %slot151, align 8
  %v1750 = load i64, ptr %slot151, align 8
  %v1751 = load i64, ptr %slot150, align 8
  %p1752 = inttoptr i64 %v1750 to ptr
  %p1753 = inttoptr i64 %v1751 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1753, ptr %p1752, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot15, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  store i32 0, ptr %p1755, align 4, !alias.scope !3, !noalias !4
  %v1756 = load i64, ptr %slot10, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  store i32 2, ptr %p1757, align 4, !alias.scope !3, !noalias !4
  %v1758 = load i64, ptr %slot16, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %ld1760 = load i32, ptr %p1759, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1760, ptr %slot152, align 8
  %v1761 = load i32, ptr %slot152, align 8
  %v1762 = load i64, ptr %slot10, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  store i32 %v1761, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  %v1764 = load i64, ptr %slot9, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  store i32 1, ptr %p1765, align 4, !alias.scope !3, !noalias !4
  %v1766 = load i64, ptr %slot30, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  store i64 5, ptr %p1767, align 8, !alias.scope !3, !noalias !4
  %v1768 = load i64, ptr %slot30, align 8
  %p1769 = inttoptr i64 %v1768 to ptr
  %ld1770 = load i64, ptr %p1769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1770, ptr %slot153, align 8
  %v1771 = load i64, ptr %slot153, align 8
  %cmp1772 = icmp sge i64 %v1771, 0
  %cv1773 = zext i1 %cmp1772 to i64
  store i64 %cv1773, ptr %slot154, align 8
  %v1774 = load i64, ptr %slot154, align 8
  %cond1775 = icmp ne i64 %v1774, 0
  br i1 %cond1775, label %bb_success172, label %bb_failed172
bb_failed172:
  %v1776 = load i64, ptr %slot1, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1777) nomerge, !dbg !116
  unreachable
bb_success172:
  %v1778 = load i64, ptr %slot35, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  %p1780 = inttoptr i64 ptrtoint (ptr @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a to i64) to ptr
  %v1781 = load i64, ptr %slot153, align 8
  %call1782 = call ptr @myl_native_list_new(ptr %p1779, ptr %p1780, i64 %v1781) nomerge, !dbg !116
  %calladdr1783 = ptrtoint ptr %call1782 to i64
  store i64 %calladdr1783, ptr %slot155, align 8
  %v1784 = load i64, ptr %slot155, align 8
  %cond1785 = icmp ne i64 %v1784, 0
  br i1 %cond1785, label %bb_success174, label %bb_failed174
bb_failed174:
  %v1786 = load i64, ptr %slot1, align 8
  %p1787 = inttoptr i64 %v1786 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1787) nomerge, !dbg !116
  unreachable
bb_success174:
  %v1788 = load i64, ptr %slot155, align 8
  %v1789 = load i64, ptr %slot30, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  store i64 %v1788, ptr %p1790, align 8, !alias.scope !3, !noalias !4
  %v1791 = load i64, ptr %slot30, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  %ld1793 = load i64, ptr %p1792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1793, ptr %slot156, align 8
  %v1794 = load i64, ptr %slot156, align 8
  %v1795 = load i64, ptr %slot18, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  store i64 %v1794, ptr %p1796, align 8, !alias.scope !3, !noalias !4
  %v1797 = load i64, ptr %slot18, align 8
  store i64 %v1797, ptr %slot157, align 8
  %v1798 = load i64, ptr %slot19, align 8
  store i64 %v1798, ptr %slot158, align 8
  %v1799 = load i64, ptr %slot157, align 8
  %v1800 = load i64, ptr %slot158, align 8
  %p1801 = inttoptr i64 %v1799 to ptr
  %p1802 = inttoptr i64 %v1800 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1802, ptr %p1801, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1803 = load i64, ptr %slot16, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  store i32 2, ptr %p1804, align 4, !alias.scope !3, !noalias !4
  %v1805 = load i64, ptr %slot15, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i32 1, ptr %p1806, align 4, !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot17, align 8
  store i64 %v1807, ptr %slot159, align 8
  %v1808 = load i64, ptr %slot19, align 8
  store i64 %v1808, ptr %slot160, align 8
  %v1809 = load i64, ptr %slot160, align 8
  %v1810 = load i64, ptr %slot159, align 8
  %p1811 = inttoptr i64 %v1809 to ptr
  %p1812 = inttoptr i64 %v1810 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1812, ptr %p1811, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1813 = load i64, ptr %slot14, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i32 2, ptr %p1814, align 4, !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot16, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  %ld1817 = load i32, ptr %p1816, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1817, ptr %slot161, align 8
  %v1818 = load i32, ptr %slot161, align 8
  %v1819 = load i64, ptr %slot14, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  store i32 %v1818, ptr %p1820, align 4, !alias.scope !3, !noalias !4
  %v1821 = load i64, ptr %slot15, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  store i32 0, ptr %p1822, align 4, !alias.scope !3, !noalias !4
  %v1823 = load i64, ptr %slot13, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  store i32 1, ptr %p1824, align 4, !alias.scope !3, !noalias !4
  %v1825 = load i64, ptr %slot159, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %ld1827 = load i64, ptr %p1826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1827, ptr %slot162, align 8
  %v1828 = load i64, ptr %slot162, align 8
  %v1829 = load i64, ptr %slot30, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  store i64 %v1828, ptr %p1830, align 8, !alias.scope !3, !noalias !4
  %v1831 = load i64, ptr %slot30, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  %ld1833 = load i64, ptr %p1832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1833, ptr %slot163, align 8
  %v1834 = load i64, ptr %slot163, align 8
  %v1835 = load i64, ptr %slot18, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  store i64 %v1834, ptr %p1836, align 8, !alias.scope !3, !noalias !4
  %v1837 = load i64, ptr %slot18, align 8
  store i64 %v1837, ptr %slot164, align 8
  %v1838 = load i64, ptr %slot13, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  %ld1840 = load i32, ptr %p1839, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1840, ptr %slot165, align 8
  %v1841 = load i64, ptr %slot14, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %ld1843 = load i32, ptr %p1842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1843, ptr %slot166, align 8
  %v1844 = load i32, ptr %slot166, align 8
  %op1845 = and i32 %v1844, 24
  store i32 %op1845, ptr %slot166, align 8
  %v1846 = load i32, ptr %slot166, align 8
  %cmp1847 = icmp eq i32 %v1846, 0
  %cv1848 = zext i1 %cmp1847 to i32
  store i32 %cv1848, ptr %slot167, align 8
  %v1849 = load i32, ptr %slot165, align 8
  %v1850 = load i32, ptr %slot167, align 8
  %op1851 = and i32 %v1849, %v1850
  store i32 %op1851, ptr %slot168, align 8
  %v1852 = load i32, ptr %slot168, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcprivateown197, label %bb_rcprivateloan197
bb_rcprivateown197:
  %v1855 = load i64, ptr %slot19, align 8
  store i64 %v1855, ptr %slot169, align 8
  %v1856 = load i64, ptr %slot36, align 8
  store i64 %v1856, ptr %slot170, align 8
  %v1857 = load i64, ptr %slot164, align 8
  %v1858 = load i64, ptr %slot169, align 8
  %op1859 = sub i64 %v1857, %v1858
  store i64 %op1859, ptr %slot171, align 8
  %v1860 = load i64, ptr %slot169, align 8
  %v1861 = load i64, ptr %slot164, align 8
  %op1862 = sub i64 %v1860, %v1861
  store i64 %op1862, ptr %slot172, align 8
  %v1863 = load i64, ptr %slot171, align 8
  %cmp1864 = icmp ult i64 %v1863, 8
  %cv1865 = zext i1 %cmp1864 to i32
  store i32 %cv1865, ptr %slot173, align 8
  %v1866 = load i64, ptr %slot172, align 8
  %cmp1867 = icmp ult i64 %v1866, 8
  %cv1868 = zext i1 %cmp1867 to i32
  store i32 %cv1868, ptr %slot174, align 8
  %v1869 = load i32, ptr %slot173, align 8
  %v1870 = load i32, ptr %slot174, align 8
  %op1871 = or i32 %v1869, %v1870
  store i32 %op1871, ptr %slot175, align 8
  %v1872 = load i32, ptr %slot175, align 8
  %cv1873 = zext i32 %v1872 to i64
  %cond1874 = icmp ne i64 %cv1873, 0
  br i1 %cond1874, label %bb_rcmoveslow200, label %bb_rcmovecheck200
bb_rcmovecheck200:
  %v1875 = load i64, ptr %slot164, align 8
  %p1877 = inttoptr i64 %v1875 to ptr
  %gep1878 = getelementptr i8, ptr %p1877, i64 0
  %op1876 = ptrtoint ptr %gep1878 to i64
  store i64 %op1876, ptr %slot176, align 8
  %v1879 = load i64, ptr %slot176, align 8
  %p1880 = inttoptr i64 %v1879 to ptr
  %ld1881 = load i64, ptr %p1880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1881, ptr %slot177, align 8
  %v1882 = load i64, ptr %slot177, align 8
  %cmp1883 = icmp ne i64 %v1882, 0
  %cv1884 = zext i1 %cmp1883 to i32
  store i32 %cv1884, ptr %slot178, align 8
  %v1885 = load i32, ptr %slot178, align 8
  %cv1886 = zext i32 %v1885 to i64
  %cond1887 = icmp ne i64 %cv1886, 0
  br i1 %cond1887, label %bb_rcmoveheader208, label %bb_rcmovenext208
bb_rcmoveheader208:
  %v1888 = load i64, ptr %slot177, align 8
  %op1889 = sub i64 %v1888, 16
  store i64 %op1889, ptr %slot179, align 8
  %v1890 = load i64, ptr %slot177, align 8
  %p1891 = inttoptr i64 %v1890 to ptr
  %rgep1892 = getelementptr i8, ptr %p1891, i64 -16
  %ld1893 = load i64, ptr %rgep1892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1893, ptr %slot180, align 8
  %v1894 = load i64, ptr %slot180, align 8
  %op1895 = and i64 %v1894, 5764607523034234881
  store i64 %op1895, ptr %slot181, align 8
  %v1896 = load i64, ptr %slot181, align 8
  %cmp1897 = icmp ne i64 %v1896, 0
  %cv1898 = zext i1 %cmp1897 to i32
  store i32 %cv1898, ptr %slot182, align 8
  %v1899 = load i32, ptr %slot182, align 8
  %cv1900 = zext i32 %v1899 to i64
  %cond1901 = icmp ne i64 %cv1900, 0
  br i1 %cond1901, label %bb_rcmoveslow200, label %bb_rcmovenext208
bb_rcmovenext208:
  %v1902 = load i64, ptr %slot164, align 8
  %v1903 = load i64, ptr %slot169, align 8
  %p1904 = inttoptr i64 %v1902 to ptr
  %p1905 = inttoptr i64 %v1903 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1905, ptr %p1904, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1906 = load i64, ptr %slot164, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  store i64 0, ptr %p1907, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved200
bb_rcmoveslow200:
  %v1908 = load i64, ptr %slot35, align 8
  %v1909 = load i64, ptr %slot169, align 8
  %v1910 = load i64, ptr %slot164, align 8
  %v1911 = load i64, ptr %slot170, align 8
  %cv1912 = trunc i64 %v1911 to i32
  %call1913 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take(i64 %v1908, i64 %v1909, i64 %v1910, i32 %cv1912) nomerge, !dbg !118
  store i32 %call1913, ptr %slot183, align 8
  %v1914 = load i32, ptr %slot183, align 8
  %cv1915 = zext i32 %v1914 to i64
  %cond1916 = icmp ne i64 %cv1915, 0
  br i1 %cond1916, label %bb_rcsuccess215, label %bb_rcfailure215
bb_rcfailure215:
  %v1917 = load i64, ptr %slot35, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %call1919 = call i32 @myl_rc_take_failure(ptr %p1918) nomerge, !dbg !118
  store i32 %call1919, ptr %slot184, align 8
  %v1920 = load i64, ptr %slot1, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  %v1922 = load i32, ptr %slot184, align 8
  %call1923 = call i32 @myl_qbe_rc_status(ptr %p1921, i32 %v1922) nomerge, !dbg !118
  store i32 %call1923, ptr %slot185, align 8
  br label %bb_failure
bb_rcsuccess215:
  br label %bb_rcmoved200
bb_rcmoved200:
  %v1924 = load i64, ptr %slot13, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  store i32 0, ptr %p1925, align 4, !alias.scope !3, !noalias !4
  %v1926 = load i64, ptr %slot16, align 8
  %p1927 = inttoptr i64 %v1926 to ptr
  store i32 2, ptr %p1927, align 4, !alias.scope !3, !noalias !4
  %v1928 = load i64, ptr %slot15, align 8
  %p1929 = inttoptr i64 %v1928 to ptr
  store i32 1, ptr %p1929, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared197
bb_rcprivateloan197:
  %v1930 = load i64, ptr %slot13, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  %ld1932 = load i32, ptr %p1931, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1932, ptr %slot186, align 8
  %v1933 = load i64, ptr %slot14, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  %ld1935 = load i32, ptr %p1934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1935, ptr %slot187, align 8
  %v1936 = load i32, ptr %slot187, align 8
  %cmp1937 = icmp eq i32 %v1936, 16
  %cv1938 = zext i1 %cmp1937 to i32
  store i32 %cv1938, ptr %slot188, align 8
  %v1939 = load i32, ptr %slot188, align 8
  %v1940 = load i32, ptr %slot186, align 8
  %op1941 = and i32 %v1939, %v1940
  store i32 %op1941, ptr %slot188, align 8
  %v1942 = load i32, ptr %slot188, align 8
  %cv1943 = zext i32 %v1942 to i64
  %cond1944 = icmp ne i64 %cv1943, 0
  br i1 %cond1944, label %bb_rcprivatemove197, label %bb_rcprivatenew197
bb_rcprivatemove197:
  %v1945 = load i64, ptr %slot19, align 8
  store i64 %v1945, ptr %slot189, align 8
  %v1946 = load i64, ptr %slot164, align 8
  %v1947 = load i64, ptr %slot189, align 8
  %p1948 = inttoptr i64 %v1946 to ptr
  %p1949 = inttoptr i64 %v1947 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1949, ptr %p1948, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1950 = load i64, ptr %slot164, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  store i64 0, ptr %p1951, align 8, !alias.scope !3, !noalias !4
  %v1952 = load i64, ptr %slot16, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  store i32 2, ptr %p1953, align 4, !alias.scope !3, !noalias !4
  %v1954 = load i64, ptr %slot16, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  store i32 16, ptr %p1955, align 4, !alias.scope !3, !noalias !4
  %v1956 = load i64, ptr %slot15, align 8
  %p1957 = inttoptr i64 %v1956 to ptr
  store i32 1, ptr %p1957, align 4, !alias.scope !3, !noalias !4
  %v1958 = load i64, ptr %slot13, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  store i32 0, ptr %p1959, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared197
bb_rcprivatenew197:
  %v1960 = load i64, ptr %slot19, align 8
  store i64 %v1960, ptr %slot190, align 8
  %v1961 = load i64, ptr %slot164, align 8
  %p1962 = inttoptr i64 %v1961 to ptr
  %ld1963 = load i64, ptr %p1962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1963, ptr %slot191, align 8
  %v1964 = load i64, ptr %slot191, align 8
  %cmp1965 = icmp ne i64 %v1964, 0
  %cv1966 = zext i1 %cmp1965 to i32
  store i32 %cv1966, ptr %slot192, align 8
  %v1967 = load i32, ptr %slot192, align 8
  %cv1968 = zext i32 %v1967 to i64
  %cond1969 = icmp ne i64 %cv1968, 0
  br i1 %cond1969, label %bb_rcgnn233, label %bb_rcgstore233
bb_rcgnn233:
  %v1970 = load i64, ptr %slot191, align 8
  %op1971 = sub i64 %v1970, 16
  store i64 %op1971, ptr %slot193, align 8
  %v1972 = load i64, ptr %slot191, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  %rgep1974 = getelementptr i8, ptr %p1973, i64 -16
  %ld1975 = load i64, ptr %rgep1974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1975, ptr %slot194, align 8
  %v1976 = load i64, ptr %slot194, align 8
  %op1977 = and i64 %v1976, 4611686018427387906
  store i64 %op1977, ptr %slot195, align 8
  %v1978 = load i64, ptr %slot195, align 8
  %cmp1979 = icmp ne i64 %v1978, 0
  %cv1980 = zext i1 %cmp1979 to i32
  store i32 %cv1980, ptr %slot196, align 8
  %v1981 = load i32, ptr %slot196, align 8
  %cv1982 = zext i32 %v1981 to i64
  %cond1983 = icmp ne i64 %cv1982, 0
  br i1 %cond1983, label %bb_rcgstore233, label %bb_rcginc233
bb_rcginc233:
  %v1984 = load i64, ptr %slot191, align 8
  %op1985 = sub i64 %v1984, 24
  store i64 %op1985, ptr %slot197, align 8
  %v1986 = load i64, ptr %slot191, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  %rgep1988 = getelementptr i8, ptr %p1987, i64 -24
  %ld1989 = load i64, ptr %rgep1988, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1989, ptr %slot198, align 8
  %v1990 = load i64, ptr %slot198, align 8
  %op1991 = add i64 %v1990, 1
  store i64 %op1991, ptr %slot199, align 8
  %v1992 = load i64, ptr %slot199, align 8
  %cmp1993 = icmp eq i64 %v1992, 0
  %cv1994 = zext i1 %cmp1993 to i32
  store i32 %cv1994, ptr %slot200, align 8
  %v1995 = load i32, ptr %slot200, align 8
  %cv1996 = zext i32 %v1995 to i64
  %cond1997 = icmp ne i64 %cv1996, 0
  br i1 %cond1997, label %bb_rcglimit233, label %bb_rcgcapacity233
bb_rcglimit233:
  %v1998 = load i64, ptr %slot1, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  %call2000 = call i32 @myl_qbe_rc_status(ptr %p1999, i32 2) nomerge, !dbg !118
  store i32 %call2000, ptr %slot201, align 8
  br label %bb_failure
bb_rcgcapacity233:
  %v2001 = load i64, ptr %slot199, align 8
  %v2002 = load i64, ptr %slot191, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %rgep2004 = getelementptr i8, ptr %p2003, i64 -24
  store i64 %v2001, ptr %rgep2004, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore233
bb_rcgstore233:
  %v2005 = load i64, ptr %slot191, align 8
  %v2006 = load i64, ptr %slot190, align 8
  %p2007 = inttoptr i64 %v2006 to ptr
  store i64 %v2005, ptr %p2007, align 8, !alias.scope !3, !noalias !4
  %v2008 = load i64, ptr %slot16, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  store i32 2, ptr %p2009, align 4, !alias.scope !3, !noalias !4
  %v2010 = load i64, ptr %slot16, align 8
  %p2011 = inttoptr i64 %v2010 to ptr
  store i32 16, ptr %p2011, align 4, !alias.scope !3, !noalias !4
  %v2012 = load i64, ptr %slot15, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  store i32 1, ptr %p2013, align 4, !alias.scope !3, !noalias !4
  %v2014 = load i64, ptr %slot13, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  %ld2016 = load i32, ptr %p2015, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2016, ptr %slot202, align 8
  %v2017 = load i32, ptr %slot202, align 8
  %cv2018 = zext i32 %v2017 to i64
  %cond2019 = icmp ne i64 %cv2018, 0
  br i1 %cond2019, label %bb_rcslotdrop249, label %bb_rcslotdone249
bb_rcslotdrop249:
  %v2020 = load i64, ptr %slot13, align 8
  %p2021 = inttoptr i64 %v2020 to ptr
  store i32 0, ptr %p2021, align 4, !alias.scope !3, !noalias !4
  %v2022 = load i64, ptr %slot17, align 8
  store i64 %v2022, ptr %slot203, align 8
  %v2023 = load i64, ptr %slot14, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  %ld2025 = load i32, ptr %p2024, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2025, ptr %slot204, align 8
  %v2026 = load i32, ptr %slot204, align 8
  %op2027 = and i32 %v2026, 28
  store i32 %op2027, ptr %slot205, align 8
  %v2028 = load i32, ptr %slot205, align 8
  %cv2029 = zext i32 %v2028 to i64
  %cond2030 = icmp ne i64 %cv2029, 0
  br i1 %cond2030, label %bb_rcslotrole249, label %bb_rcslotowner249
bb_rcslotrole249:
  %v2031 = load i64, ptr %slot35, align 8
  store i64 %v2031, ptr %slot206, align 8
  %v2032 = load i64, ptr %slot203, align 8
  %p2033 = inttoptr i64 %v2032 to ptr
  %ld2034 = load i64, ptr %p2033, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2034, ptr %slot207, align 8
  %v2035 = load i64, ptr %slot207, align 8
  %cmp2036 = icmp ne i64 %v2035, 0
  %cv2037 = zext i1 %cmp2036 to i32
  store i32 %cv2037, ptr %slot208, align 8
  %v2038 = load i32, ptr %slot208, align 8
  %cv2039 = zext i32 %v2038 to i64
  %cond2040 = icmp ne i64 %cv2039, 0
  br i1 %cond2040, label %bb_rcgnn265, label %bb_rcgdone265
bb_rcgnn265:
  %v2041 = load i64, ptr %slot207, align 8
  %op2042 = sub i64 %v2041, 16
  store i64 %op2042, ptr %slot209, align 8
  %v2043 = load i64, ptr %slot207, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %rgep2045 = getelementptr i8, ptr %p2044, i64 -16
  %ld2046 = load i64, ptr %rgep2045, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2046, ptr %slot210, align 8
  %v2047 = load i64, ptr %slot210, align 8
  %op2048 = and i64 %v2047, 4611686018427387906
  store i64 %op2048, ptr %slot211, align 8
  %v2049 = load i64, ptr %slot211, align 8
  %cmp2050 = icmp ne i64 %v2049, 0
  %cv2051 = zext i1 %cmp2050 to i32
  store i32 %cv2051, ptr %slot212, align 8
  %v2052 = load i32, ptr %slot212, align 8
  %cv2053 = zext i32 %v2052 to i64
  %cond2054 = icmp ne i64 %cv2053, 0
  br i1 %cond2054, label %bb_rcgclear265, label %bb_rcgcounted265
bb_rcgcounted265:
  %v2055 = load i64, ptr %slot207, align 8
  %op2056 = sub i64 %v2055, 24
  store i64 %op2056, ptr %slot213, align 8
  %v2057 = load i64, ptr %slot207, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %rgep2059 = getelementptr i8, ptr %p2058, i64 -24
  %ld2060 = load i64, ptr %rgep2059, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2060, ptr %slot214, align 8
  %v2061 = load i64, ptr %slot214, align 8
  %op2062 = sub i64 %v2061, 1
  store i64 %op2062, ptr %slot215, align 8
  %v2063 = load i64, ptr %slot215, align 8
  %cmp2064 = icmp eq i64 %v2063, 0
  %cv2065 = zext i1 %cmp2064 to i32
  store i32 %cv2065, ptr %slot216, align 8
  %v2066 = load i32, ptr %slot216, align 8
  %cv2067 = zext i32 %v2066 to i64
  %cond2068 = icmp ne i64 %cv2067, 0
  br i1 %cond2068, label %bb_rcglast265, label %bb_rcgdec265
bb_rcglast265:
  %v2069 = load i64, ptr %slot207, align 8
  %op2070 = sub i64 %v2069, 32
  store i64 %op2070, ptr %slot217, align 8
  %v2071 = load i64, ptr %slot207, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  %rgep2073 = getelementptr i8, ptr %p2072, i64 -32
  %ld2074 = load i64, ptr %rgep2073, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2074, ptr %slot218, align 8
  %v2075 = load i64, ptr %slot218, align 8
  %cmp2076 = icmp ne i64 %v2075, 0
  %cv2077 = zext i1 %cmp2076 to i32
  store i32 %cv2077, ptr %slot219, align 8
  %v2078 = load i32, ptr %slot219, align 8
  %cv2079 = zext i32 %v2078 to i64
  %cond2080 = icmp ne i64 %cv2079, 0
  br i1 %cond2080, label %bb_rcgdec265, label %bb_rcgslow265
bb_rcgslow265:
  %v2081 = load i64, ptr %slot206, align 8
  %v2082 = load i64, ptr %slot203, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v2081, i64 %v2082) nomerge, !dbg !118
  br label %bb_rcgdone265
bb_rcgdec265:
  %v2083 = load i64, ptr %slot215, align 8
  %v2084 = load i64, ptr %slot207, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  %rgep2086 = getelementptr i8, ptr %p2085, i64 -24
  store i64 %v2083, ptr %rgep2086, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear265
bb_rcgclear265:
  %v2087 = load i64, ptr %slot203, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  store i64 0, ptr %p2088, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone265
bb_rcgdone265:
  br label %bb_rcslotdone249
bb_rcslotowner249:
  %v2089 = load i64, ptr %slot35, align 8
  store i64 %v2089, ptr %slot220, align 8
  %v2090 = load i64, ptr %slot203, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  %ld2092 = load i64, ptr %p2091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2092, ptr %slot221, align 8
  %v2093 = load i64, ptr %slot221, align 8
  %cmp2094 = icmp ne i64 %v2093, 0
  %cv2095 = zext i1 %cmp2094 to i32
  store i32 %cv2095, ptr %slot222, align 8
  %v2096 = load i32, ptr %slot222, align 8
  %cv2097 = zext i32 %v2096 to i64
  %cond2098 = icmp ne i64 %cv2097, 0
  br i1 %cond2098, label %bb_rcgnn280, label %bb_rcgdone280
bb_rcgnn280:
  %v2099 = load i64, ptr %slot221, align 8
  %op2100 = sub i64 %v2099, 16
  store i64 %op2100, ptr %slot223, align 8
  %v2101 = load i64, ptr %slot221, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  %rgep2103 = getelementptr i8, ptr %p2102, i64 -16
  %ld2104 = load i64, ptr %rgep2103, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2104, ptr %slot224, align 8
  %v2105 = load i64, ptr %slot224, align 8
  %op2106 = and i64 %v2105, 4611686018427387906
  store i64 %op2106, ptr %slot225, align 8
  %v2107 = load i64, ptr %slot225, align 8
  %cmp2108 = icmp ne i64 %v2107, 0
  %cv2109 = zext i1 %cmp2108 to i32
  store i32 %cv2109, ptr %slot226, align 8
  %v2110 = load i32, ptr %slot226, align 8
  %cv2111 = zext i32 %v2110 to i64
  %cond2112 = icmp ne i64 %cv2111, 0
  br i1 %cond2112, label %bb_rcgclear280, label %bb_rcgcounted280
bb_rcgcounted280:
  %v2113 = load i64, ptr %slot221, align 8
  %op2114 = sub i64 %v2113, 32
  store i64 %op2114, ptr %slot227, align 8
  %v2115 = load i64, ptr %slot221, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  %rgep2117 = getelementptr i8, ptr %p2116, i64 -32
  %ld2118 = load i64, ptr %rgep2117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2118, ptr %slot228, align 8
  %v2119 = load i64, ptr %slot228, align 8
  %op2120 = sub i64 %v2119, 1
  store i64 %op2120, ptr %slot229, align 8
  %v2121 = load i64, ptr %slot229, align 8
  %cmp2122 = icmp eq i64 %v2121, 0
  %cv2123 = zext i1 %cmp2122 to i32
  store i32 %cv2123, ptr %slot230, align 8
  %v2124 = load i32, ptr %slot230, align 8
  %cv2125 = zext i32 %v2124 to i64
  %cond2126 = icmp ne i64 %cv2125, 0
  br i1 %cond2126, label %bb_rcglast280, label %bb_rcgdec280
bb_rcglast280:
  %v2127 = load i64, ptr %slot221, align 8
  %op2128 = sub i64 %v2127, 24
  store i64 %op2128, ptr %slot231, align 8
  %v2129 = load i64, ptr %slot221, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  %rgep2131 = getelementptr i8, ptr %p2130, i64 -24
  %ld2132 = load i64, ptr %rgep2131, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2132, ptr %slot232, align 8
  %v2133 = load i64, ptr %slot232, align 8
  %cmp2134 = icmp ne i64 %v2133, 0
  %cv2135 = zext i1 %cmp2134 to i32
  store i32 %cv2135, ptr %slot233, align 8
  %v2136 = load i32, ptr %slot233, align 8
  %cv2137 = zext i32 %v2136 to i64
  %cond2138 = icmp ne i64 %cv2137, 0
  br i1 %cond2138, label %bb_rcgdec280, label %bb_rcgslow280
bb_rcgslow280:
  %v2139 = load i64, ptr %slot220, align 8
  %v2140 = load i64, ptr %slot203, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v2139, i64 %v2140) nomerge, !dbg !118
  br label %bb_rcgdone280
bb_rcgdec280:
  %v2141 = load i64, ptr %slot229, align 8
  %v2142 = load i64, ptr %slot221, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  %rgep2144 = getelementptr i8, ptr %p2143, i64 -32
  store i64 %v2141, ptr %rgep2144, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear280
bb_rcgclear280:
  %v2145 = load i64, ptr %slot203, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  store i64 0, ptr %p2146, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone280
bb_rcgdone280:
  br label %bb_rcslotdone249
bb_rcslotdone249:
  br label %bb_rcprivateprepared197
bb_rcprivateprepared197:
  %v2147 = load i64, ptr %slot7, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  %ld2149 = load i32, ptr %p2148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2149, ptr %slot234, align 8
  %v2150 = load i32, ptr %slot234, align 8
  %cv2151 = zext i32 %v2150 to i64
  %cond2152 = icmp ne i64 %cv2151, 0
  br i1 %cond2152, label %bb_rcslotdrop287, label %bb_rcslotdone287
bb_rcslotdrop287:
  %v2153 = load i64, ptr %slot7, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  store i32 0, ptr %p2154, align 4, !alias.scope !3, !noalias !4
  %v2155 = load i64, ptr %slot25, align 8
  store i64 %v2155, ptr %slot235, align 8
  %v2156 = load i64, ptr %slot8, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  %ld2158 = load i32, ptr %p2157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2158, ptr %slot236, align 8
  %v2159 = load i32, ptr %slot236, align 8
  %op2160 = and i32 %v2159, 28
  store i32 %op2160, ptr %slot237, align 8
  %v2161 = load i32, ptr %slot237, align 8
  %cv2162 = zext i32 %v2161 to i64
  %cond2163 = icmp ne i64 %cv2162, 0
  br i1 %cond2163, label %bb_rcslotrole287, label %bb_rcslotowner287
bb_rcslotrole287:
  %v2164 = load i64, ptr %slot35, align 8
  store i64 %v2164, ptr %slot238, align 8
  %v2165 = load i64, ptr %slot235, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %ld2167 = load i64, ptr %p2166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2167, ptr %slot239, align 8
  %v2168 = load i64, ptr %slot239, align 8
  %cmp2169 = icmp ne i64 %v2168, 0
  %cv2170 = zext i1 %cmp2169 to i32
  store i32 %cv2170, ptr %slot240, align 8
  %v2171 = load i32, ptr %slot240, align 8
  %cv2172 = zext i32 %v2171 to i64
  %cond2173 = icmp ne i64 %cv2172, 0
  br i1 %cond2173, label %bb_rcgnn303, label %bb_rcgdone303
bb_rcgnn303:
  %v2174 = load i64, ptr %slot239, align 8
  %op2175 = sub i64 %v2174, 16
  store i64 %op2175, ptr %slot241, align 8
  %v2176 = load i64, ptr %slot239, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %rgep2178 = getelementptr i8, ptr %p2177, i64 -16
  %ld2179 = load i64, ptr %rgep2178, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2179, ptr %slot242, align 8
  %v2180 = load i64, ptr %slot242, align 8
  %op2181 = and i64 %v2180, 4611686018427387906
  store i64 %op2181, ptr %slot243, align 8
  %v2182 = load i64, ptr %slot243, align 8
  %cmp2183 = icmp ne i64 %v2182, 0
  %cv2184 = zext i1 %cmp2183 to i32
  store i32 %cv2184, ptr %slot244, align 8
  %v2185 = load i32, ptr %slot244, align 8
  %cv2186 = zext i32 %v2185 to i64
  %cond2187 = icmp ne i64 %cv2186, 0
  br i1 %cond2187, label %bb_rcgclear303, label %bb_rcgcounted303
bb_rcgcounted303:
  %v2188 = load i64, ptr %slot239, align 8
  %op2189 = sub i64 %v2188, 24
  store i64 %op2189, ptr %slot245, align 8
  %v2190 = load i64, ptr %slot239, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  %rgep2192 = getelementptr i8, ptr %p2191, i64 -24
  %ld2193 = load i64, ptr %rgep2192, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2193, ptr %slot246, align 8
  %v2194 = load i64, ptr %slot246, align 8
  %op2195 = sub i64 %v2194, 1
  store i64 %op2195, ptr %slot247, align 8
  %v2196 = load i64, ptr %slot247, align 8
  %cmp2197 = icmp eq i64 %v2196, 0
  %cv2198 = zext i1 %cmp2197 to i32
  store i32 %cv2198, ptr %slot248, align 8
  %v2199 = load i32, ptr %slot248, align 8
  %cv2200 = zext i32 %v2199 to i64
  %cond2201 = icmp ne i64 %cv2200, 0
  br i1 %cond2201, label %bb_rcglast303, label %bb_rcgdec303
bb_rcglast303:
  %v2202 = load i64, ptr %slot239, align 8
  %op2203 = sub i64 %v2202, 32
  store i64 %op2203, ptr %slot249, align 8
  %v2204 = load i64, ptr %slot239, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  %rgep2206 = getelementptr i8, ptr %p2205, i64 -32
  %ld2207 = load i64, ptr %rgep2206, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2207, ptr %slot250, align 8
  %v2208 = load i64, ptr %slot250, align 8
  %cmp2209 = icmp ne i64 %v2208, 0
  %cv2210 = zext i1 %cmp2209 to i32
  store i32 %cv2210, ptr %slot251, align 8
  %v2211 = load i32, ptr %slot251, align 8
  %cv2212 = zext i32 %v2211 to i64
  %cond2213 = icmp ne i64 %cv2212, 0
  br i1 %cond2213, label %bb_rcgdec303, label %bb_rcgslow303
bb_rcgslow303:
  %v2214 = load i64, ptr %slot238, align 8
  %v2215 = load i64, ptr %slot235, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v2214, i64 %v2215) nomerge, !dbg !118
  br label %bb_rcgdone303
bb_rcgdec303:
  %v2216 = load i64, ptr %slot247, align 8
  %v2217 = load i64, ptr %slot239, align 8
  %p2218 = inttoptr i64 %v2217 to ptr
  %rgep2219 = getelementptr i8, ptr %p2218, i64 -24
  store i64 %v2216, ptr %rgep2219, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear303
bb_rcgclear303:
  %v2220 = load i64, ptr %slot235, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  store i64 0, ptr %p2221, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone303
bb_rcgdone303:
  br label %bb_rcslotdone287
bb_rcslotowner287:
  %v2222 = load i64, ptr %slot35, align 8
  store i64 %v2222, ptr %slot252, align 8
  %v2223 = load i64, ptr %slot235, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %ld2225 = load i64, ptr %p2224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2225, ptr %slot253, align 8
  %v2226 = load i64, ptr %slot253, align 8
  %cmp2227 = icmp ne i64 %v2226, 0
  %cv2228 = zext i1 %cmp2227 to i32
  store i32 %cv2228, ptr %slot254, align 8
  %v2229 = load i32, ptr %slot254, align 8
  %cv2230 = zext i32 %v2229 to i64
  %cond2231 = icmp ne i64 %cv2230, 0
  br i1 %cond2231, label %bb_rcgnn318, label %bb_rcgdone318
bb_rcgnn318:
  %v2232 = load i64, ptr %slot253, align 8
  %op2233 = sub i64 %v2232, 16
  store i64 %op2233, ptr %slot255, align 8
  %v2234 = load i64, ptr %slot253, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  %rgep2236 = getelementptr i8, ptr %p2235, i64 -16
  %ld2237 = load i64, ptr %rgep2236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2237, ptr %slot256, align 8
  %v2238 = load i64, ptr %slot256, align 8
  %op2239 = and i64 %v2238, 4611686018427387906
  store i64 %op2239, ptr %slot257, align 8
  %v2240 = load i64, ptr %slot257, align 8
  %cmp2241 = icmp ne i64 %v2240, 0
  %cv2242 = zext i1 %cmp2241 to i32
  store i32 %cv2242, ptr %slot258, align 8
  %v2243 = load i32, ptr %slot258, align 8
  %cv2244 = zext i32 %v2243 to i64
  %cond2245 = icmp ne i64 %cv2244, 0
  br i1 %cond2245, label %bb_rcgclear318, label %bb_rcgcounted318
bb_rcgcounted318:
  %v2246 = load i64, ptr %slot253, align 8
  %op2247 = sub i64 %v2246, 32
  store i64 %op2247, ptr %slot259, align 8
  %v2248 = load i64, ptr %slot253, align 8
  %p2249 = inttoptr i64 %v2248 to ptr
  %rgep2250 = getelementptr i8, ptr %p2249, i64 -32
  %ld2251 = load i64, ptr %rgep2250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2251, ptr %slot260, align 8
  %v2252 = load i64, ptr %slot260, align 8
  %op2253 = sub i64 %v2252, 1
  store i64 %op2253, ptr %slot261, align 8
  %v2254 = load i64, ptr %slot261, align 8
  %cmp2255 = icmp eq i64 %v2254, 0
  %cv2256 = zext i1 %cmp2255 to i32
  store i32 %cv2256, ptr %slot262, align 8
  %v2257 = load i32, ptr %slot262, align 8
  %cv2258 = zext i32 %v2257 to i64
  %cond2259 = icmp ne i64 %cv2258, 0
  br i1 %cond2259, label %bb_rcglast318, label %bb_rcgdec318
bb_rcglast318:
  %v2260 = load i64, ptr %slot253, align 8
  %op2261 = sub i64 %v2260, 24
  store i64 %op2261, ptr %slot263, align 8
  %v2262 = load i64, ptr %slot253, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  %rgep2264 = getelementptr i8, ptr %p2263, i64 -24
  %ld2265 = load i64, ptr %rgep2264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2265, ptr %slot264, align 8
  %v2266 = load i64, ptr %slot264, align 8
  %cmp2267 = icmp ne i64 %v2266, 0
  %cv2268 = zext i1 %cmp2267 to i32
  store i32 %cv2268, ptr %slot265, align 8
  %v2269 = load i32, ptr %slot265, align 8
  %cv2270 = zext i32 %v2269 to i64
  %cond2271 = icmp ne i64 %cv2270, 0
  br i1 %cond2271, label %bb_rcgdec318, label %bb_rcgslow318
bb_rcgslow318:
  %v2272 = load i64, ptr %slot252, align 8
  %v2273 = load i64, ptr %slot235, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v2272, i64 %v2273) nomerge, !dbg !118
  br label %bb_rcgdone318
bb_rcgdec318:
  %v2274 = load i64, ptr %slot261, align 8
  %v2275 = load i64, ptr %slot253, align 8
  %p2276 = inttoptr i64 %v2275 to ptr
  %rgep2277 = getelementptr i8, ptr %p2276, i64 -32
  store i64 %v2274, ptr %rgep2277, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear318
bb_rcgclear318:
  %v2278 = load i64, ptr %slot235, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  store i64 0, ptr %p2279, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone318
bb_rcgdone318:
  br label %bb_rcslotdone287
bb_rcslotdone287:
  %v2280 = load i64, ptr %slot25, align 8
  store i64 %v2280, ptr %slot266, align 8
  %v2281 = load i64, ptr %slot19, align 8
  store i64 %v2281, ptr %slot267, align 8
  %v2282 = load i64, ptr %slot267, align 8
  %v2283 = load i64, ptr %slot266, align 8
  %p2284 = inttoptr i64 %v2282 to ptr
  %p2285 = inttoptr i64 %v2283 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2285, ptr %p2284, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot15, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  store i32 0, ptr %p2287, align 4, !alias.scope !3, !noalias !4
  %v2288 = load i64, ptr %slot8, align 8
  %p2289 = inttoptr i64 %v2288 to ptr
  store i32 2, ptr %p2289, align 4, !alias.scope !3, !noalias !4
  %v2290 = load i64, ptr %slot16, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i32, ptr %p2291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2292, ptr %slot268, align 8
  %v2293 = load i32, ptr %slot268, align 8
  %v2294 = load i64, ptr %slot8, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i32 %v2293, ptr %p2295, align 4, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot7, align 8
  %p2297 = inttoptr i64 %v2296 to ptr
  store i32 1, ptr %p2297, align 4, !alias.scope !3, !noalias !4
  %p2298 = inttoptr i64 ptrtoint (ptr @myl_lit_30bdecd870d597c62d1c30c02882c43b1f27244eec6e99c1398f7fc84cf4ce25 to i64) to ptr
  %ld2299 = load i64, ptr %p2298, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2299, ptr %slot269, align 8
  %v2300 = load i64, ptr %slot269, align 8
  %v2301 = load i64, ptr %slot30, align 8
  %p2302 = inttoptr i64 %v2301 to ptr
  store i64 %v2300, ptr %p2302, align 8, !alias.scope !3, !noalias !4
  %v2303 = load i64, ptr %slot30, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  %ld2305 = load i64, ptr %p2304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2305, ptr %slot270, align 8
  %v2306 = load i64, ptr %slot270, align 8
  %v2307 = load i64, ptr %slot18, align 8
  %p2308 = inttoptr i64 %v2307 to ptr
  store i64 %v2306, ptr %p2308, align 8, !alias.scope !3, !noalias !4
  %v2309 = load i64, ptr %slot18, align 8
  store i64 %v2309, ptr %slot271, align 8
  %v2310 = load i64, ptr %slot19, align 8
  store i64 %v2310, ptr %slot272, align 8
  %v2311 = load i64, ptr %slot271, align 8
  %v2312 = load i64, ptr %slot272, align 8
  %p2313 = inttoptr i64 %v2311 to ptr
  %p2314 = inttoptr i64 %v2312 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2314, ptr %p2313, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2315 = load i64, ptr %slot16, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  store i32 2, ptr %p2316, align 4, !alias.scope !3, !noalias !4
  %v2317 = load i64, ptr %slot15, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  store i32 1, ptr %p2318, align 4, !alias.scope !3, !noalias !4
  %v2319 = load i64, ptr %slot17, align 8
  store i64 %v2319, ptr %slot273, align 8
  %v2320 = load i64, ptr %slot19, align 8
  store i64 %v2320, ptr %slot274, align 8
  %v2321 = load i64, ptr %slot274, align 8
  %v2322 = load i64, ptr %slot273, align 8
  %p2323 = inttoptr i64 %v2321 to ptr
  %p2324 = inttoptr i64 %v2322 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2324, ptr %p2323, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2325 = load i64, ptr %slot14, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  store i32 2, ptr %p2326, align 4, !alias.scope !3, !noalias !4
  %v2327 = load i64, ptr %slot16, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  %ld2329 = load i32, ptr %p2328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2329, ptr %slot275, align 8
  %v2330 = load i32, ptr %slot275, align 8
  %v2331 = load i64, ptr %slot14, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i32 %v2330, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  %v2333 = load i64, ptr %slot15, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  store i32 0, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  %v2335 = load i64, ptr %slot13, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  store i32 1, ptr %p2336, align 4, !alias.scope !3, !noalias !4
  %v2337 = load i64, ptr %slot273, align 8
  %p2338 = inttoptr i64 %v2337 to ptr
  %ld2339 = load i64, ptr %p2338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2339, ptr %slot276, align 8
  %v2340 = load i64, ptr %slot276, align 8
  %v2341 = load i64, ptr %slot30, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  store i64 %v2340, ptr %p2342, align 8, !alias.scope !3, !noalias !4
  %v2343 = load i64, ptr %slot25, align 8
  store i64 %v2343, ptr %slot277, align 8
  %v2344 = load i64, ptr %slot8, align 8
  %p2345 = inttoptr i64 %v2344 to ptr
  %ld2346 = load i32, ptr %p2345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2346, ptr %slot278, align 8
  %v2347 = load i32, ptr %slot278, align 8
  %cmp2348 = icmp eq i32 %v2347, 16
  %cv2349 = zext i1 %cmp2348 to i32
  store i32 %cv2349, ptr %slot279, align 8
  %v2350 = load i64, ptr %slot7, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  %ld2352 = load i32, ptr %p2351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2352, ptr %slot280, align 8
  %v2353 = load i32, ptr %slot280, align 8
  %v2354 = load i32, ptr %slot279, align 8
  %op2355 = and i32 %v2353, %v2354
  store i32 %op2355, ptr %slot281, align 8
  %v2356 = load i32, ptr %slot281, align 8
  %cv2357 = zext i32 %v2356 to i64
  %cond2358 = icmp ne i64 %cv2357, 0
  br i1 %cond2358, label %bb_rcownlocal351, label %bb_rcownedlocal351
bb_rcownlocal351:
  %v2359 = load i64, ptr %slot25, align 8
  store i64 %v2359, ptr %slot282, align 8
  %v2360 = load i64, ptr %slot19, align 8
  store i64 %v2360, ptr %slot283, align 8
  %v2361 = load i64, ptr %slot36, align 8
  store i64 %v2361, ptr %slot284, align 8
  %v2362 = load i64, ptr %slot282, align 8
  %p2363 = inttoptr i64 %v2362 to ptr
  %ld2364 = load i64, ptr %p2363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2364, ptr %slot285, align 8
  %v2365 = load i64, ptr %slot285, align 8
  %cmp2366 = icmp ne i64 %v2365, 0
  %cv2367 = zext i1 %cmp2366 to i32
  store i32 %cv2367, ptr %slot286, align 8
  %v2368 = load i32, ptr %slot286, align 8
  %cv2369 = zext i32 %v2368 to i64
  %cond2370 = icmp ne i64 %cv2369, 0
  br i1 %cond2370, label %bb_rcgnn358, label %bb_rcgplain358
bb_rcgnn358:
  %v2371 = load i64, ptr %slot285, align 8
  %op2372 = sub i64 %v2371, 16
  store i64 %op2372, ptr %slot287, align 8
  %v2373 = load i64, ptr %slot285, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  %rgep2375 = getelementptr i8, ptr %p2374, i64 -16
  %ld2376 = load i64, ptr %rgep2375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2376, ptr %slot288, align 8
  %v2377 = load i64, ptr %slot288, align 8
  %op2378 = and i64 %v2377, 4611686018427387906
  store i64 %op2378, ptr %slot289, align 8
  %v2379 = load i64, ptr %slot289, align 8
  %cmp2380 = icmp ne i64 %v2379, 0
  %cv2381 = zext i1 %cmp2380 to i32
  store i32 %cv2381, ptr %slot290, align 8
  %v2382 = load i32, ptr %slot290, align 8
  %cv2383 = zext i32 %v2382 to i64
  %cond2384 = icmp ne i64 %cv2383, 0
  br i1 %cond2384, label %bb_rcgspecial358, label %bb_rcginc358
bb_rcginc358:
  %v2385 = load i64, ptr %slot285, align 8
  %op2386 = sub i64 %v2385, 32
  store i64 %op2386, ptr %slot291, align 8
  %v2387 = load i64, ptr %slot285, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  %rgep2389 = getelementptr i8, ptr %p2388, i64 -32
  %ld2390 = load i64, ptr %rgep2389, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2390, ptr %slot292, align 8
  %v2391 = load i64, ptr %slot292, align 8
  %op2392 = add i64 %v2391, 1
  store i64 %op2392, ptr %slot293, align 8
  %v2393 = load i64, ptr %slot293, align 8
  %cmp2394 = icmp eq i64 %v2393, 0
  %cv2395 = zext i1 %cmp2394 to i32
  store i32 %cv2395, ptr %slot294, align 8
  %v2396 = load i32, ptr %slot294, align 8
  %cv2397 = zext i32 %v2396 to i64
  %cond2398 = icmp ne i64 %cv2397, 0
  br i1 %cond2398, label %bb_rcglimit358, label %bb_rcgcapacity358
bb_rcglimit358:
  %v2399 = load i64, ptr %slot1, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %call2401 = call i32 @myl_qbe_rc_status(ptr %p2400, i32 2) nomerge, !dbg !120
  store i32 %call2401, ptr %slot295, align 8
  br label %bb_failure
bb_rcgcapacity358:
  %v2402 = load i64, ptr %slot293, align 8
  %v2403 = load i64, ptr %slot285, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  %rgep2405 = getelementptr i8, ptr %p2404, i64 -32
  store i64 %v2402, ptr %rgep2405, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain358
bb_rcgspecial358:
  %v2406 = load i64, ptr %slot288, align 8
  %op2407 = and i64 %v2406, 4611686018427387904
  store i64 %op2407, ptr %slot296, align 8
  %v2408 = load i64, ptr %slot296, align 8
  %cmp2409 = icmp ne i64 %v2408, 0
  %cv2410 = zext i1 %cmp2409 to i32
  store i32 %cv2410, ptr %slot297, align 8
  %v2411 = load i32, ptr %slot297, align 8
  %cv2412 = zext i32 %v2411 to i64
  %cond2413 = icmp ne i64 %cv2412, 0
  br i1 %cond2413, label %bb_rcgslow358, label %bb_rcgplain358
bb_rcgslow358:
  %v2414 = load i64, ptr %slot35, align 8
  %v2415 = load i64, ptr %slot283, align 8
  %v2416 = load i64, ptr %slot282, align 8
  %v2417 = load i64, ptr %slot284, align 8
  %cv2418 = trunc i64 %v2417 to i32
  %call2419 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v2414, i64 %v2415, i64 %v2416, i32 %cv2418) nomerge, !dbg !120
  store i32 %call2419, ptr %slot298, align 8
  %v2420 = load i32, ptr %slot298, align 8
  %cv2421 = zext i32 %v2420 to i64
  %cond2422 = icmp ne i64 %cv2421, 0
  br i1 %cond2422, label %bb_rcsuccess372, label %bb_rcfailure372
bb_rcfailure372:
  %v2423 = load i64, ptr %slot35, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  %call2425 = call i32 @myl_rc_take_failure(ptr %p2424) nomerge, !dbg !120
  store i32 %call2425, ptr %slot299, align 8
  %v2426 = load i64, ptr %slot1, align 8
  %p2427 = inttoptr i64 %v2426 to ptr
  %v2428 = load i32, ptr %slot299, align 8
  %call2429 = call i32 @myl_qbe_rc_status(ptr %p2427, i32 %v2428) nomerge, !dbg !120
  store i32 %call2429, ptr %slot300, align 8
  br label %bb_failure
bb_rcsuccess372:
  br label %bb_rcgdone358
bb_rcgplain358:
  %v2430 = load i64, ptr %slot285, align 8
  %v2431 = load i64, ptr %slot283, align 8
  %p2432 = inttoptr i64 %v2431 to ptr
  store i64 %v2430, ptr %p2432, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone358
bb_rcgdone358:
  %v2433 = load i64, ptr %slot16, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  store i32 2, ptr %p2434, align 4, !alias.scope !3, !noalias !4
  %v2435 = load i64, ptr %slot15, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  store i32 1, ptr %p2436, align 4, !alias.scope !3, !noalias !4
  %v2437 = load i64, ptr %slot7, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  %ld2439 = load i32, ptr %p2438, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2439, ptr %slot301, align 8
  %v2440 = load i32, ptr %slot301, align 8
  %cv2441 = zext i32 %v2440 to i64
  %cond2442 = icmp ne i64 %cv2441, 0
  br i1 %cond2442, label %bb_rcslotdrop379, label %bb_rcslotdone379
bb_rcslotdrop379:
  %v2443 = load i64, ptr %slot7, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  store i32 0, ptr %p2444, align 4, !alias.scope !3, !noalias !4
  %v2445 = load i64, ptr %slot25, align 8
  store i64 %v2445, ptr %slot302, align 8
  %v2446 = load i64, ptr %slot8, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  %ld2448 = load i32, ptr %p2447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2448, ptr %slot303, align 8
  %v2449 = load i32, ptr %slot303, align 8
  %op2450 = and i32 %v2449, 28
  store i32 %op2450, ptr %slot304, align 8
  %v2451 = load i32, ptr %slot304, align 8
  %cv2452 = zext i32 %v2451 to i64
  %cond2453 = icmp ne i64 %cv2452, 0
  br i1 %cond2453, label %bb_rcslotrole379, label %bb_rcslotowner379
bb_rcslotrole379:
  %v2454 = load i64, ptr %slot35, align 8
  store i64 %v2454, ptr %slot305, align 8
  %v2455 = load i64, ptr %slot302, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  %ld2457 = load i64, ptr %p2456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2457, ptr %slot306, align 8
  %v2458 = load i64, ptr %slot306, align 8
  %cmp2459 = icmp ne i64 %v2458, 0
  %cv2460 = zext i1 %cmp2459 to i32
  store i32 %cv2460, ptr %slot307, align 8
  %v2461 = load i32, ptr %slot307, align 8
  %cv2462 = zext i32 %v2461 to i64
  %cond2463 = icmp ne i64 %cv2462, 0
  br i1 %cond2463, label %bb_rcgnn395, label %bb_rcgdone395
bb_rcgnn395:
  %v2464 = load i64, ptr %slot306, align 8
  %op2465 = sub i64 %v2464, 16
  store i64 %op2465, ptr %slot308, align 8
  %v2466 = load i64, ptr %slot306, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  %rgep2468 = getelementptr i8, ptr %p2467, i64 -16
  %ld2469 = load i64, ptr %rgep2468, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2469, ptr %slot309, align 8
  %v2470 = load i64, ptr %slot309, align 8
  %op2471 = and i64 %v2470, 4611686018427387906
  store i64 %op2471, ptr %slot310, align 8
  %v2472 = load i64, ptr %slot310, align 8
  %cmp2473 = icmp ne i64 %v2472, 0
  %cv2474 = zext i1 %cmp2473 to i32
  store i32 %cv2474, ptr %slot311, align 8
  %v2475 = load i32, ptr %slot311, align 8
  %cv2476 = zext i32 %v2475 to i64
  %cond2477 = icmp ne i64 %cv2476, 0
  br i1 %cond2477, label %bb_rcgclear395, label %bb_rcgcounted395
bb_rcgcounted395:
  %v2478 = load i64, ptr %slot306, align 8
  %op2479 = sub i64 %v2478, 24
  store i64 %op2479, ptr %slot312, align 8
  %v2480 = load i64, ptr %slot306, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  %rgep2482 = getelementptr i8, ptr %p2481, i64 -24
  %ld2483 = load i64, ptr %rgep2482, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2483, ptr %slot313, align 8
  %v2484 = load i64, ptr %slot313, align 8
  %op2485 = sub i64 %v2484, 1
  store i64 %op2485, ptr %slot314, align 8
  %v2486 = load i64, ptr %slot314, align 8
  %cmp2487 = icmp eq i64 %v2486, 0
  %cv2488 = zext i1 %cmp2487 to i32
  store i32 %cv2488, ptr %slot315, align 8
  %v2489 = load i32, ptr %slot315, align 8
  %cv2490 = zext i32 %v2489 to i64
  %cond2491 = icmp ne i64 %cv2490, 0
  br i1 %cond2491, label %bb_rcglast395, label %bb_rcgdec395
bb_rcglast395:
  %v2492 = load i64, ptr %slot306, align 8
  %op2493 = sub i64 %v2492, 32
  store i64 %op2493, ptr %slot316, align 8
  %v2494 = load i64, ptr %slot306, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  %rgep2496 = getelementptr i8, ptr %p2495, i64 -32
  %ld2497 = load i64, ptr %rgep2496, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2497, ptr %slot317, align 8
  %v2498 = load i64, ptr %slot317, align 8
  %cmp2499 = icmp ne i64 %v2498, 0
  %cv2500 = zext i1 %cmp2499 to i32
  store i32 %cv2500, ptr %slot318, align 8
  %v2501 = load i32, ptr %slot318, align 8
  %cv2502 = zext i32 %v2501 to i64
  %cond2503 = icmp ne i64 %cv2502, 0
  br i1 %cond2503, label %bb_rcgdec395, label %bb_rcgslow395
bb_rcgslow395:
  %v2504 = load i64, ptr %slot305, align 8
  %v2505 = load i64, ptr %slot302, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v2504, i64 %v2505) nomerge, !dbg !120
  br label %bb_rcgdone395
bb_rcgdec395:
  %v2506 = load i64, ptr %slot314, align 8
  %v2507 = load i64, ptr %slot306, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  %rgep2509 = getelementptr i8, ptr %p2508, i64 -24
  store i64 %v2506, ptr %rgep2509, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear395
bb_rcgclear395:
  %v2510 = load i64, ptr %slot302, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  store i64 0, ptr %p2511, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone395
bb_rcgdone395:
  br label %bb_rcslotdone379
bb_rcslotowner379:
  %v2512 = load i64, ptr %slot35, align 8
  store i64 %v2512, ptr %slot319, align 8
  %v2513 = load i64, ptr %slot302, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  %ld2515 = load i64, ptr %p2514, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2515, ptr %slot320, align 8
  %v2516 = load i64, ptr %slot320, align 8
  %cmp2517 = icmp ne i64 %v2516, 0
  %cv2518 = zext i1 %cmp2517 to i32
  store i32 %cv2518, ptr %slot321, align 8
  %v2519 = load i32, ptr %slot321, align 8
  %cv2520 = zext i32 %v2519 to i64
  %cond2521 = icmp ne i64 %cv2520, 0
  br i1 %cond2521, label %bb_rcgnn410, label %bb_rcgdone410
bb_rcgnn410:
  %v2522 = load i64, ptr %slot320, align 8
  %op2523 = sub i64 %v2522, 16
  store i64 %op2523, ptr %slot322, align 8
  %v2524 = load i64, ptr %slot320, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  %rgep2526 = getelementptr i8, ptr %p2525, i64 -16
  %ld2527 = load i64, ptr %rgep2526, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2527, ptr %slot323, align 8
  %v2528 = load i64, ptr %slot323, align 8
  %op2529 = and i64 %v2528, 4611686018427387906
  store i64 %op2529, ptr %slot324, align 8
  %v2530 = load i64, ptr %slot324, align 8
  %cmp2531 = icmp ne i64 %v2530, 0
  %cv2532 = zext i1 %cmp2531 to i32
  store i32 %cv2532, ptr %slot325, align 8
  %v2533 = load i32, ptr %slot325, align 8
  %cv2534 = zext i32 %v2533 to i64
  %cond2535 = icmp ne i64 %cv2534, 0
  br i1 %cond2535, label %bb_rcgclear410, label %bb_rcgcounted410
bb_rcgcounted410:
  %v2536 = load i64, ptr %slot320, align 8
  %op2537 = sub i64 %v2536, 32
  store i64 %op2537, ptr %slot326, align 8
  %v2538 = load i64, ptr %slot320, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  %rgep2540 = getelementptr i8, ptr %p2539, i64 -32
  %ld2541 = load i64, ptr %rgep2540, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2541, ptr %slot327, align 8
  %v2542 = load i64, ptr %slot327, align 8
  %op2543 = sub i64 %v2542, 1
  store i64 %op2543, ptr %slot328, align 8
  %v2544 = load i64, ptr %slot328, align 8
  %cmp2545 = icmp eq i64 %v2544, 0
  %cv2546 = zext i1 %cmp2545 to i32
  store i32 %cv2546, ptr %slot329, align 8
  %v2547 = load i32, ptr %slot329, align 8
  %cv2548 = zext i32 %v2547 to i64
  %cond2549 = icmp ne i64 %cv2548, 0
  br i1 %cond2549, label %bb_rcglast410, label %bb_rcgdec410
bb_rcglast410:
  %v2550 = load i64, ptr %slot320, align 8
  %op2551 = sub i64 %v2550, 24
  store i64 %op2551, ptr %slot330, align 8
  %v2552 = load i64, ptr %slot320, align 8
  %p2553 = inttoptr i64 %v2552 to ptr
  %rgep2554 = getelementptr i8, ptr %p2553, i64 -24
  %ld2555 = load i64, ptr %rgep2554, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2555, ptr %slot331, align 8
  %v2556 = load i64, ptr %slot331, align 8
  %cmp2557 = icmp ne i64 %v2556, 0
  %cv2558 = zext i1 %cmp2557 to i32
  store i32 %cv2558, ptr %slot332, align 8
  %v2559 = load i32, ptr %slot332, align 8
  %cv2560 = zext i32 %v2559 to i64
  %cond2561 = icmp ne i64 %cv2560, 0
  br i1 %cond2561, label %bb_rcgdec410, label %bb_rcgslow410
bb_rcgslow410:
  %v2562 = load i64, ptr %slot319, align 8
  %v2563 = load i64, ptr %slot302, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v2562, i64 %v2563) nomerge, !dbg !120
  br label %bb_rcgdone410
bb_rcgdec410:
  %v2564 = load i64, ptr %slot328, align 8
  %v2565 = load i64, ptr %slot320, align 8
  %p2566 = inttoptr i64 %v2565 to ptr
  %rgep2567 = getelementptr i8, ptr %p2566, i64 -32
  store i64 %v2564, ptr %rgep2567, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear410
bb_rcgclear410:
  %v2568 = load i64, ptr %slot302, align 8
  %p2569 = inttoptr i64 %v2568 to ptr
  store i64 0, ptr %p2569, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone410
bb_rcgdone410:
  br label %bb_rcslotdone379
bb_rcslotdone379:
  %v2570 = load i64, ptr %slot19, align 8
  store i64 %v2570, ptr %slot333, align 8
  %v2571 = load i64, ptr %slot333, align 8
  %v2572 = load i64, ptr %slot282, align 8
  %p2573 = inttoptr i64 %v2571 to ptr
  %p2574 = inttoptr i64 %v2572 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2574, ptr %p2573, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2575 = load i64, ptr %slot8, align 8
  %p2576 = inttoptr i64 %v2575 to ptr
  store i32 2, ptr %p2576, align 4, !alias.scope !3, !noalias !4
  %v2577 = load i64, ptr %slot7, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  store i32 1, ptr %p2578, align 4, !alias.scope !3, !noalias !4
  %v2579 = load i64, ptr %slot15, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  store i32 0, ptr %p2580, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal351
bb_rcownedlocal351:
  %v2581 = load i64, ptr %slot8, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i32 2, ptr %p2582, align 4, !alias.scope !3, !noalias !4
  %v2583 = load i64, ptr %slot277, align 8
  %p2584 = inttoptr i64 %v2583 to ptr
  %ld2585 = load i64, ptr %p2584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2585, ptr %slot334, align 8
  %v2586 = load i64, ptr %slot334, align 8
  %cmp2587 = icmp ne i64 %v2586, 0
  %cv2588 = zext i1 %cmp2587 to i32
  store i32 %cv2588, ptr %slot335, align 8
  %v2589 = load i32, ptr %slot335, align 8
  %cv2590 = zext i32 %v2589 to i64
  %cond2591 = icmp ne i64 %cv2590, 0
  br i1 %cond2591, label %bb_rcguniquenn419, label %bb_rcgunique419
bb_rcguniquenn419:
  %v2592 = load i64, ptr %slot334, align 8
  %op2593 = sub i64 %v2592, 16
  store i64 %op2593, ptr %slot336, align 8
  %v2594 = load i64, ptr %slot334, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  %rgep2596 = getelementptr i8, ptr %p2595, i64 -16
  %ld2597 = load i64, ptr %rgep2596, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2597, ptr %slot337, align 8
  %v2598 = load i64, ptr %slot337, align 8
  %op2599 = and i64 %v2598, 6917529027641081858
  store i64 %op2599, ptr %slot338, align 8
  %v2600 = load i64, ptr %slot338, align 8
  %cmp2601 = icmp ne i64 %v2600, 0
  %cv2602 = zext i1 %cmp2601 to i32
  store i32 %cv2602, ptr %slot339, align 8
  %v2603 = load i32, ptr %slot339, align 8
  %cv2604 = zext i32 %v2603 to i64
  %cond2605 = icmp ne i64 %cv2604, 0
  br i1 %cond2605, label %bb_rcguniqueslow419, label %bb_rcguniquecount419
bb_rcguniquecount419:
  %v2606 = load i64, ptr %slot334, align 8
  %op2607 = sub i64 %v2606, 32
  store i64 %op2607, ptr %slot340, align 8
  %v2608 = load i64, ptr %slot334, align 8
  %p2609 = inttoptr i64 %v2608 to ptr
  %rgep2610 = getelementptr i8, ptr %p2609, i64 -32
  %ld2611 = load i64, ptr %rgep2610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2611, ptr %slot341, align 8
  %v2612 = load i64, ptr %slot341, align 8
  %cmp2613 = icmp ult i64 %v2612, 2
  %cv2614 = zext i1 %cmp2613 to i32
  store i32 %cv2614, ptr %slot342, align 8
  %v2615 = load i32, ptr %slot342, align 8
  %cv2616 = zext i32 %v2615 to i64
  %cond2617 = icmp ne i64 %cv2616, 0
  br i1 %cond2617, label %bb_rcgunique419, label %bb_rcguniqueslow419
bb_rcguniqueslow419:
  %v2618 = load i64, ptr %slot1, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  %p2620 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v2621 = load i64, ptr %slot277, align 8
  %p2622 = inttoptr i64 %v2621 to ptr
  %v2623 = load i64, ptr %slot7, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  %call2625 = call i32 @myl_qbe_rc_unique_local(ptr %p2619, ptr %p2620, ptr %p2622, ptr %p2624) nomerge, !dbg !120
  store i32 %call2625, ptr %slot343, align 8
  %v2626 = load i32, ptr %slot343, align 8
  %cv2627 = zext i32 %v2626 to i64
  %cond2628 = icmp ne i64 %cv2627, 0
  br i1 %cond2628, label %bb_rcunique430, label %bb_failure
bb_rcunique430:
  br label %bb_rcgunique419
bb_rcgunique419:
  %v2629 = load i64, ptr %slot25, align 8
  %p2630 = inttoptr i64 %v2629 to ptr
  %ld2631 = load i64, ptr %p2630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2631, ptr %slot344, align 8
  %v2632 = load i64, ptr %slot30, align 8
  store i64 %v2632, ptr %slot345, align 8
  %v2633 = load i64, ptr %slot345, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  %ld2635 = load i64, ptr %p2634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2635, ptr %slot346, align 8
  %v2636 = load i64, ptr %slot346, align 8
  %v2637 = load i64, ptr %slot20, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i64 %v2636, ptr %p2638, align 8, !alias.scope !3, !noalias !4
  %v2639 = load i64, ptr %slot20, align 8
  store i64 %v2639, ptr %slot347, align 8
  %v2640 = load i64, ptr %slot35, align 8
  %v2641 = load i64, ptr %slot344, align 8
  %v2642 = load i64, ptr %slot347, align 8
  %call2643 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v2640, i64 %v2641, i64 %v2642) nomerge, !dbg !120
  store i32 %call2643, ptr %slot348, align 8
  %v2644 = load i32, ptr %slot348, align 8
  %cv2645 = zext i32 %v2644 to i64
  %cond2646 = icmp ne i64 %cv2645, 0
  br i1 %cond2646, label %bb_success436, label %bb_failed436
bb_failed436:
  %v2647 = load i64, ptr %slot1, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2648) nomerge, !dbg !120
  unreachable
bb_success436:
  %v2649 = load i64, ptr %slot30, align 8
  %p2650 = inttoptr i64 %v2649 to ptr
  store i64 0, ptr %p2650, align 8, !alias.scope !3, !noalias !4
  %v2651 = load i64, ptr %slot13, align 8
  %p2652 = inttoptr i64 %v2651 to ptr
  %ld2653 = load i32, ptr %p2652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2653, ptr %slot349, align 8
  %v2654 = load i32, ptr %slot349, align 8
  %cv2655 = zext i32 %v2654 to i64
  %cond2656 = icmp ne i64 %cv2655, 0
  br i1 %cond2656, label %bb_rcslotdrop439, label %bb_rcslotdone439
bb_rcslotdrop439:
  %v2657 = load i64, ptr %slot13, align 8
  %p2658 = inttoptr i64 %v2657 to ptr
  store i32 0, ptr %p2658, align 4, !alias.scope !3, !noalias !4
  %v2659 = load i64, ptr %slot17, align 8
  store i64 %v2659, ptr %slot350, align 8
  %v2660 = load i64, ptr %slot14, align 8
  %p2661 = inttoptr i64 %v2660 to ptr
  %ld2662 = load i32, ptr %p2661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2662, ptr %slot351, align 8
  %v2663 = load i32, ptr %slot351, align 8
  %op2664 = and i32 %v2663, 28
  store i32 %op2664, ptr %slot352, align 8
  %v2665 = load i32, ptr %slot352, align 8
  %cv2666 = zext i32 %v2665 to i64
  %cond2667 = icmp ne i64 %cv2666, 0
  br i1 %cond2667, label %bb_rcslotrole439, label %bb_rcslotowner439
bb_rcslotrole439:
  %v2668 = load i64, ptr %slot35, align 8
  store i64 %v2668, ptr %slot353, align 8
  %v2669 = load i64, ptr %slot350, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  %ld2671 = load i64, ptr %p2670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2671, ptr %slot354, align 8
  %v2672 = load i64, ptr %slot354, align 8
  %cmp2673 = icmp ne i64 %v2672, 0
  %cv2674 = zext i1 %cmp2673 to i32
  store i32 %cv2674, ptr %slot355, align 8
  %v2675 = load i32, ptr %slot355, align 8
  %cv2676 = zext i32 %v2675 to i64
  %cond2677 = icmp ne i64 %cv2676, 0
  br i1 %cond2677, label %bb_rcgnn455, label %bb_rcgdone455
bb_rcgnn455:
  %v2678 = load i64, ptr %slot354, align 8
  %op2679 = sub i64 %v2678, 16
  store i64 %op2679, ptr %slot356, align 8
  %v2680 = load i64, ptr %slot354, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  %rgep2682 = getelementptr i8, ptr %p2681, i64 -16
  %ld2683 = load i64, ptr %rgep2682, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2683, ptr %slot357, align 8
  %v2684 = load i64, ptr %slot357, align 8
  %op2685 = and i64 %v2684, 4611686018427387906
  store i64 %op2685, ptr %slot358, align 8
  %v2686 = load i64, ptr %slot358, align 8
  %cmp2687 = icmp ne i64 %v2686, 0
  %cv2688 = zext i1 %cmp2687 to i32
  store i32 %cv2688, ptr %slot359, align 8
  %v2689 = load i32, ptr %slot359, align 8
  %cv2690 = zext i32 %v2689 to i64
  %cond2691 = icmp ne i64 %cv2690, 0
  br i1 %cond2691, label %bb_rcgclear455, label %bb_rcgcounted455
bb_rcgcounted455:
  %v2692 = load i64, ptr %slot354, align 8
  %op2693 = sub i64 %v2692, 24
  store i64 %op2693, ptr %slot360, align 8
  %v2694 = load i64, ptr %slot354, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  %rgep2696 = getelementptr i8, ptr %p2695, i64 -24
  %ld2697 = load i64, ptr %rgep2696, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2697, ptr %slot361, align 8
  %v2698 = load i64, ptr %slot361, align 8
  %op2699 = sub i64 %v2698, 1
  store i64 %op2699, ptr %slot362, align 8
  %v2700 = load i64, ptr %slot362, align 8
  %cmp2701 = icmp eq i64 %v2700, 0
  %cv2702 = zext i1 %cmp2701 to i32
  store i32 %cv2702, ptr %slot363, align 8
  %v2703 = load i32, ptr %slot363, align 8
  %cv2704 = zext i32 %v2703 to i64
  %cond2705 = icmp ne i64 %cv2704, 0
  br i1 %cond2705, label %bb_rcglast455, label %bb_rcgdec455
bb_rcglast455:
  %v2706 = load i64, ptr %slot354, align 8
  %op2707 = sub i64 %v2706, 32
  store i64 %op2707, ptr %slot364, align 8
  %v2708 = load i64, ptr %slot354, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  %rgep2710 = getelementptr i8, ptr %p2709, i64 -32
  %ld2711 = load i64, ptr %rgep2710, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2711, ptr %slot365, align 8
  %v2712 = load i64, ptr %slot365, align 8
  %cmp2713 = icmp ne i64 %v2712, 0
  %cv2714 = zext i1 %cmp2713 to i32
  store i32 %cv2714, ptr %slot366, align 8
  %v2715 = load i32, ptr %slot366, align 8
  %cv2716 = zext i32 %v2715 to i64
  %cond2717 = icmp ne i64 %cv2716, 0
  br i1 %cond2717, label %bb_rcgdec455, label %bb_rcgslow455
bb_rcgslow455:
  %v2718 = load i64, ptr %slot353, align 8
  %v2719 = load i64, ptr %slot350, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v2718, i64 %v2719) nomerge, !dbg !120
  br label %bb_rcgdone455
bb_rcgdec455:
  %v2720 = load i64, ptr %slot362, align 8
  %v2721 = load i64, ptr %slot354, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  %rgep2723 = getelementptr i8, ptr %p2722, i64 -24
  store i64 %v2720, ptr %rgep2723, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear455
bb_rcgclear455:
  %v2724 = load i64, ptr %slot350, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  store i64 0, ptr %p2725, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone455
bb_rcgdone455:
  br label %bb_rcslotdone439
bb_rcslotowner439:
  %v2726 = load i64, ptr %slot35, align 8
  store i64 %v2726, ptr %slot367, align 8
  %v2727 = load i64, ptr %slot350, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  %ld2729 = load i64, ptr %p2728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2729, ptr %slot368, align 8
  %v2730 = load i64, ptr %slot368, align 8
  %cmp2731 = icmp ne i64 %v2730, 0
  %cv2732 = zext i1 %cmp2731 to i32
  store i32 %cv2732, ptr %slot369, align 8
  %v2733 = load i32, ptr %slot369, align 8
  %cv2734 = zext i32 %v2733 to i64
  %cond2735 = icmp ne i64 %cv2734, 0
  br i1 %cond2735, label %bb_rcgnn470, label %bb_rcgdone470
bb_rcgnn470:
  %v2736 = load i64, ptr %slot368, align 8
  %op2737 = sub i64 %v2736, 16
  store i64 %op2737, ptr %slot370, align 8
  %v2738 = load i64, ptr %slot368, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %rgep2740 = getelementptr i8, ptr %p2739, i64 -16
  %ld2741 = load i64, ptr %rgep2740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2741, ptr %slot371, align 8
  %v2742 = load i64, ptr %slot371, align 8
  %op2743 = and i64 %v2742, 4611686018427387906
  store i64 %op2743, ptr %slot372, align 8
  %v2744 = load i64, ptr %slot372, align 8
  %cmp2745 = icmp ne i64 %v2744, 0
  %cv2746 = zext i1 %cmp2745 to i32
  store i32 %cv2746, ptr %slot373, align 8
  %v2747 = load i32, ptr %slot373, align 8
  %cv2748 = zext i32 %v2747 to i64
  %cond2749 = icmp ne i64 %cv2748, 0
  br i1 %cond2749, label %bb_rcgclear470, label %bb_rcgcounted470
bb_rcgcounted470:
  %v2750 = load i64, ptr %slot368, align 8
  %op2751 = sub i64 %v2750, 32
  store i64 %op2751, ptr %slot374, align 8
  %v2752 = load i64, ptr %slot368, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  %rgep2754 = getelementptr i8, ptr %p2753, i64 -32
  %ld2755 = load i64, ptr %rgep2754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2755, ptr %slot375, align 8
  %v2756 = load i64, ptr %slot375, align 8
  %op2757 = sub i64 %v2756, 1
  store i64 %op2757, ptr %slot376, align 8
  %v2758 = load i64, ptr %slot376, align 8
  %cmp2759 = icmp eq i64 %v2758, 0
  %cv2760 = zext i1 %cmp2759 to i32
  store i32 %cv2760, ptr %slot377, align 8
  %v2761 = load i32, ptr %slot377, align 8
  %cv2762 = zext i32 %v2761 to i64
  %cond2763 = icmp ne i64 %cv2762, 0
  br i1 %cond2763, label %bb_rcglast470, label %bb_rcgdec470
bb_rcglast470:
  %v2764 = load i64, ptr %slot368, align 8
  %op2765 = sub i64 %v2764, 24
  store i64 %op2765, ptr %slot378, align 8
  %v2766 = load i64, ptr %slot368, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  %rgep2768 = getelementptr i8, ptr %p2767, i64 -24
  %ld2769 = load i64, ptr %rgep2768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2769, ptr %slot379, align 8
  %v2770 = load i64, ptr %slot379, align 8
  %cmp2771 = icmp ne i64 %v2770, 0
  %cv2772 = zext i1 %cmp2771 to i32
  store i32 %cv2772, ptr %slot380, align 8
  %v2773 = load i32, ptr %slot380, align 8
  %cv2774 = zext i32 %v2773 to i64
  %cond2775 = icmp ne i64 %cv2774, 0
  br i1 %cond2775, label %bb_rcgdec470, label %bb_rcgslow470
bb_rcgslow470:
  %v2776 = load i64, ptr %slot367, align 8
  %v2777 = load i64, ptr %slot350, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v2776, i64 %v2777) nomerge, !dbg !120
  br label %bb_rcgdone470
bb_rcgdec470:
  %v2778 = load i64, ptr %slot376, align 8
  %v2779 = load i64, ptr %slot368, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  %rgep2781 = getelementptr i8, ptr %p2780, i64 -32
  store i64 %v2778, ptr %rgep2781, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear470
bb_rcgclear470:
  %v2782 = load i64, ptr %slot350, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i64 0, ptr %p2783, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone470
bb_rcgdone470:
  br label %bb_rcslotdone439
bb_rcslotdone439:
  %v2784 = load i64, ptr %slot23, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  %ld2786 = load i64, ptr %p2785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2786, ptr %slot381, align 8
  %v2787 = load i64, ptr %slot381, align 8
  %v2788 = load i64, ptr %slot30, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  store i64 %v2787, ptr %p2789, align 8, !alias.scope !3, !noalias !4
  %v2790 = load i64, ptr %slot30, align 8
  %p2791 = inttoptr i64 %v2790 to ptr
  %ld2792 = load i64, ptr %p2791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2792, ptr %slot382, align 8
  %v2793 = load i64, ptr %slot35, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  %v2795 = load i64, ptr %slot382, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  %call2797 = call ptr @myl_native_text_scalar(ptr %p2794, ptr %p2796, i32 0) nomerge, !dbg !122
  %calladdr2798 = ptrtoint ptr %call2797 to i64
  store i64 %calladdr2798, ptr %slot383, align 8
  %v2799 = load i64, ptr %slot383, align 8
  %cond2800 = icmp ne i64 %v2799, 0
  br i1 %cond2800, label %bb_success477, label %bb_failed477
bb_failed477:
  %v2801 = load i64, ptr %slot1, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2802) nomerge, !dbg !122
  unreachable
bb_success477:
  %v2803 = load i64, ptr %slot383, align 8
  %v2804 = load i64, ptr %slot30, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i64 %v2803, ptr %p2805, align 8, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot30, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  %ld2808 = load i64, ptr %p2807, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2808, ptr %slot384, align 8
  %v2809 = load i64, ptr %slot384, align 8
  %v2810 = load i64, ptr %slot18, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  store i64 %v2809, ptr %p2811, align 8, !alias.scope !3, !noalias !4
  %v2812 = load i64, ptr %slot18, align 8
  store i64 %v2812, ptr %slot385, align 8
  %v2813 = load i64, ptr %slot19, align 8
  store i64 %v2813, ptr %slot386, align 8
  %v2814 = load i64, ptr %slot385, align 8
  %v2815 = load i64, ptr %slot386, align 8
  %p2816 = inttoptr i64 %v2814 to ptr
  %p2817 = inttoptr i64 %v2815 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2817, ptr %p2816, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2818 = load i64, ptr %slot16, align 8
  %p2819 = inttoptr i64 %v2818 to ptr
  store i32 2, ptr %p2819, align 4, !alias.scope !3, !noalias !4
  %v2820 = load i64, ptr %slot15, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  store i32 1, ptr %p2821, align 4, !alias.scope !3, !noalias !4
  %v2822 = load i64, ptr %slot17, align 8
  store i64 %v2822, ptr %slot387, align 8
  %v2823 = load i64, ptr %slot19, align 8
  store i64 %v2823, ptr %slot388, align 8
  %v2824 = load i64, ptr %slot388, align 8
  %v2825 = load i64, ptr %slot387, align 8
  %p2826 = inttoptr i64 %v2824 to ptr
  %p2827 = inttoptr i64 %v2825 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2827, ptr %p2826, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2828 = load i64, ptr %slot14, align 8
  %p2829 = inttoptr i64 %v2828 to ptr
  store i32 2, ptr %p2829, align 4, !alias.scope !3, !noalias !4
  %v2830 = load i64, ptr %slot16, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  %ld2832 = load i32, ptr %p2831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2832, ptr %slot389, align 8
  %v2833 = load i32, ptr %slot389, align 8
  %v2834 = load i64, ptr %slot14, align 8
  %p2835 = inttoptr i64 %v2834 to ptr
  store i32 %v2833, ptr %p2835, align 4, !alias.scope !3, !noalias !4
  %v2836 = load i64, ptr %slot15, align 8
  %p2837 = inttoptr i64 %v2836 to ptr
  store i32 0, ptr %p2837, align 4, !alias.scope !3, !noalias !4
  %v2838 = load i64, ptr %slot13, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  store i32 1, ptr %p2839, align 4, !alias.scope !3, !noalias !4
  %v2840 = load i64, ptr %slot387, align 8
  %p2841 = inttoptr i64 %v2840 to ptr
  %ld2842 = load i64, ptr %p2841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2842, ptr %slot390, align 8
  %v2843 = load i64, ptr %slot390, align 8
  %v2844 = load i64, ptr %slot30, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  store i64 %v2843, ptr %p2845, align 8, !alias.scope !3, !noalias !4
  %v2846 = load i64, ptr %slot25, align 8
  store i64 %v2846, ptr %slot391, align 8
  %v2847 = load i64, ptr %slot8, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  %ld2849 = load i32, ptr %p2848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2849, ptr %slot392, align 8
  %v2850 = load i32, ptr %slot392, align 8
  %cmp2851 = icmp eq i32 %v2850, 16
  %cv2852 = zext i1 %cmp2851 to i32
  store i32 %cv2852, ptr %slot393, align 8
  %v2853 = load i64, ptr %slot7, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  %ld2855 = load i32, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2855, ptr %slot394, align 8
  %v2856 = load i32, ptr %slot394, align 8
  %v2857 = load i32, ptr %slot393, align 8
  %op2858 = and i32 %v2856, %v2857
  store i32 %op2858, ptr %slot395, align 8
  %v2859 = load i32, ptr %slot395, align 8
  %cv2860 = zext i32 %v2859 to i64
  %cond2861 = icmp ne i64 %cv2860, 0
  br i1 %cond2861, label %bb_rcownlocal498, label %bb_rcownedlocal498
bb_rcownlocal498:
  %v2862 = load i64, ptr %slot25, align 8
  store i64 %v2862, ptr %slot396, align 8
  %v2863 = load i64, ptr %slot19, align 8
  store i64 %v2863, ptr %slot397, align 8
  %v2864 = load i64, ptr %slot36, align 8
  store i64 %v2864, ptr %slot398, align 8
  %v2865 = load i64, ptr %slot396, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  %ld2867 = load i64, ptr %p2866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2867, ptr %slot399, align 8
  %v2868 = load i64, ptr %slot399, align 8
  %cmp2869 = icmp ne i64 %v2868, 0
  %cv2870 = zext i1 %cmp2869 to i32
  store i32 %cv2870, ptr %slot400, align 8
  %v2871 = load i32, ptr %slot400, align 8
  %cv2872 = zext i32 %v2871 to i64
  %cond2873 = icmp ne i64 %cv2872, 0
  br i1 %cond2873, label %bb_rcgnn505, label %bb_rcgplain505
bb_rcgnn505:
  %v2874 = load i64, ptr %slot399, align 8
  %op2875 = sub i64 %v2874, 16
  store i64 %op2875, ptr %slot401, align 8
  %v2876 = load i64, ptr %slot399, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  %rgep2878 = getelementptr i8, ptr %p2877, i64 -16
  %ld2879 = load i64, ptr %rgep2878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2879, ptr %slot402, align 8
  %v2880 = load i64, ptr %slot402, align 8
  %op2881 = and i64 %v2880, 4611686018427387906
  store i64 %op2881, ptr %slot403, align 8
  %v2882 = load i64, ptr %slot403, align 8
  %cmp2883 = icmp ne i64 %v2882, 0
  %cv2884 = zext i1 %cmp2883 to i32
  store i32 %cv2884, ptr %slot404, align 8
  %v2885 = load i32, ptr %slot404, align 8
  %cv2886 = zext i32 %v2885 to i64
  %cond2887 = icmp ne i64 %cv2886, 0
  br i1 %cond2887, label %bb_rcgspecial505, label %bb_rcginc505
bb_rcginc505:
  %v2888 = load i64, ptr %slot399, align 8
  %op2889 = sub i64 %v2888, 32
  store i64 %op2889, ptr %slot405, align 8
  %v2890 = load i64, ptr %slot399, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  %rgep2892 = getelementptr i8, ptr %p2891, i64 -32
  %ld2893 = load i64, ptr %rgep2892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2893, ptr %slot406, align 8
  %v2894 = load i64, ptr %slot406, align 8
  %op2895 = add i64 %v2894, 1
  store i64 %op2895, ptr %slot407, align 8
  %v2896 = load i64, ptr %slot407, align 8
  %cmp2897 = icmp eq i64 %v2896, 0
  %cv2898 = zext i1 %cmp2897 to i32
  store i32 %cv2898, ptr %slot408, align 8
  %v2899 = load i32, ptr %slot408, align 8
  %cv2900 = zext i32 %v2899 to i64
  %cond2901 = icmp ne i64 %cv2900, 0
  br i1 %cond2901, label %bb_rcglimit505, label %bb_rcgcapacity505
bb_rcglimit505:
  %v2902 = load i64, ptr %slot1, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  %call2904 = call i32 @myl_qbe_rc_status(ptr %p2903, i32 2) nomerge, !dbg !124
  store i32 %call2904, ptr %slot409, align 8
  br label %bb_failure
bb_rcgcapacity505:
  %v2905 = load i64, ptr %slot407, align 8
  %v2906 = load i64, ptr %slot399, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  %rgep2908 = getelementptr i8, ptr %p2907, i64 -32
  store i64 %v2905, ptr %rgep2908, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain505
bb_rcgspecial505:
  %v2909 = load i64, ptr %slot402, align 8
  %op2910 = and i64 %v2909, 4611686018427387904
  store i64 %op2910, ptr %slot410, align 8
  %v2911 = load i64, ptr %slot410, align 8
  %cmp2912 = icmp ne i64 %v2911, 0
  %cv2913 = zext i1 %cmp2912 to i32
  store i32 %cv2913, ptr %slot411, align 8
  %v2914 = load i32, ptr %slot411, align 8
  %cv2915 = zext i32 %v2914 to i64
  %cond2916 = icmp ne i64 %cv2915, 0
  br i1 %cond2916, label %bb_rcgslow505, label %bb_rcgplain505
bb_rcgslow505:
  %v2917 = load i64, ptr %slot35, align 8
  %v2918 = load i64, ptr %slot397, align 8
  %v2919 = load i64, ptr %slot396, align 8
  %v2920 = load i64, ptr %slot398, align 8
  %cv2921 = trunc i64 %v2920 to i32
  %call2922 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v2917, i64 %v2918, i64 %v2919, i32 %cv2921) nomerge, !dbg !124
  store i32 %call2922, ptr %slot412, align 8
  %v2923 = load i32, ptr %slot412, align 8
  %cv2924 = zext i32 %v2923 to i64
  %cond2925 = icmp ne i64 %cv2924, 0
  br i1 %cond2925, label %bb_rcsuccess519, label %bb_rcfailure519
bb_rcfailure519:
  %v2926 = load i64, ptr %slot35, align 8
  %p2927 = inttoptr i64 %v2926 to ptr
  %call2928 = call i32 @myl_rc_take_failure(ptr %p2927) nomerge, !dbg !124
  store i32 %call2928, ptr %slot413, align 8
  %v2929 = load i64, ptr %slot1, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  %v2931 = load i32, ptr %slot413, align 8
  %call2932 = call i32 @myl_qbe_rc_status(ptr %p2930, i32 %v2931) nomerge, !dbg !124
  store i32 %call2932, ptr %slot414, align 8
  br label %bb_failure
bb_rcsuccess519:
  br label %bb_rcgdone505
bb_rcgplain505:
  %v2933 = load i64, ptr %slot399, align 8
  %v2934 = load i64, ptr %slot397, align 8
  %p2935 = inttoptr i64 %v2934 to ptr
  store i64 %v2933, ptr %p2935, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone505
bb_rcgdone505:
  %v2936 = load i64, ptr %slot16, align 8
  %p2937 = inttoptr i64 %v2936 to ptr
  store i32 2, ptr %p2937, align 4, !alias.scope !3, !noalias !4
  %v2938 = load i64, ptr %slot15, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  store i32 1, ptr %p2939, align 4, !alias.scope !3, !noalias !4
  %v2940 = load i64, ptr %slot7, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  %ld2942 = load i32, ptr %p2941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2942, ptr %slot415, align 8
  %v2943 = load i32, ptr %slot415, align 8
  %cv2944 = zext i32 %v2943 to i64
  %cond2945 = icmp ne i64 %cv2944, 0
  br i1 %cond2945, label %bb_rcslotdrop526, label %bb_rcslotdone526
bb_rcslotdrop526:
  %v2946 = load i64, ptr %slot7, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  store i32 0, ptr %p2947, align 4, !alias.scope !3, !noalias !4
  %v2948 = load i64, ptr %slot25, align 8
  store i64 %v2948, ptr %slot416, align 8
  %v2949 = load i64, ptr %slot8, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  %ld2951 = load i32, ptr %p2950, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2951, ptr %slot417, align 8
  %v2952 = load i32, ptr %slot417, align 8
  %op2953 = and i32 %v2952, 28
  store i32 %op2953, ptr %slot418, align 8
  %v2954 = load i32, ptr %slot418, align 8
  %cv2955 = zext i32 %v2954 to i64
  %cond2956 = icmp ne i64 %cv2955, 0
  br i1 %cond2956, label %bb_rcslotrole526, label %bb_rcslotowner526
bb_rcslotrole526:
  %v2957 = load i64, ptr %slot35, align 8
  store i64 %v2957, ptr %slot419, align 8
  %v2958 = load i64, ptr %slot416, align 8
  %p2959 = inttoptr i64 %v2958 to ptr
  %ld2960 = load i64, ptr %p2959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2960, ptr %slot420, align 8
  %v2961 = load i64, ptr %slot420, align 8
  %cmp2962 = icmp ne i64 %v2961, 0
  %cv2963 = zext i1 %cmp2962 to i32
  store i32 %cv2963, ptr %slot421, align 8
  %v2964 = load i32, ptr %slot421, align 8
  %cv2965 = zext i32 %v2964 to i64
  %cond2966 = icmp ne i64 %cv2965, 0
  br i1 %cond2966, label %bb_rcgnn542, label %bb_rcgdone542
bb_rcgnn542:
  %v2967 = load i64, ptr %slot420, align 8
  %op2968 = sub i64 %v2967, 16
  store i64 %op2968, ptr %slot422, align 8
  %v2969 = load i64, ptr %slot420, align 8
  %p2970 = inttoptr i64 %v2969 to ptr
  %rgep2971 = getelementptr i8, ptr %p2970, i64 -16
  %ld2972 = load i64, ptr %rgep2971, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2972, ptr %slot423, align 8
  %v2973 = load i64, ptr %slot423, align 8
  %op2974 = and i64 %v2973, 4611686018427387906
  store i64 %op2974, ptr %slot424, align 8
  %v2975 = load i64, ptr %slot424, align 8
  %cmp2976 = icmp ne i64 %v2975, 0
  %cv2977 = zext i1 %cmp2976 to i32
  store i32 %cv2977, ptr %slot425, align 8
  %v2978 = load i32, ptr %slot425, align 8
  %cv2979 = zext i32 %v2978 to i64
  %cond2980 = icmp ne i64 %cv2979, 0
  br i1 %cond2980, label %bb_rcgclear542, label %bb_rcgcounted542
bb_rcgcounted542:
  %v2981 = load i64, ptr %slot420, align 8
  %op2982 = sub i64 %v2981, 24
  store i64 %op2982, ptr %slot426, align 8
  %v2983 = load i64, ptr %slot420, align 8
  %p2984 = inttoptr i64 %v2983 to ptr
  %rgep2985 = getelementptr i8, ptr %p2984, i64 -24
  %ld2986 = load i64, ptr %rgep2985, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2986, ptr %slot427, align 8
  %v2987 = load i64, ptr %slot427, align 8
  %op2988 = sub i64 %v2987, 1
  store i64 %op2988, ptr %slot428, align 8
  %v2989 = load i64, ptr %slot428, align 8
  %cmp2990 = icmp eq i64 %v2989, 0
  %cv2991 = zext i1 %cmp2990 to i32
  store i32 %cv2991, ptr %slot429, align 8
  %v2992 = load i32, ptr %slot429, align 8
  %cv2993 = zext i32 %v2992 to i64
  %cond2994 = icmp ne i64 %cv2993, 0
  br i1 %cond2994, label %bb_rcglast542, label %bb_rcgdec542
bb_rcglast542:
  %v2995 = load i64, ptr %slot420, align 8
  %op2996 = sub i64 %v2995, 32
  store i64 %op2996, ptr %slot430, align 8
  %v2997 = load i64, ptr %slot420, align 8
  %p2998 = inttoptr i64 %v2997 to ptr
  %rgep2999 = getelementptr i8, ptr %p2998, i64 -32
  %ld3000 = load i64, ptr %rgep2999, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3000, ptr %slot431, align 8
  %v3001 = load i64, ptr %slot431, align 8
  %cmp3002 = icmp ne i64 %v3001, 0
  %cv3003 = zext i1 %cmp3002 to i32
  store i32 %cv3003, ptr %slot432, align 8
  %v3004 = load i32, ptr %slot432, align 8
  %cv3005 = zext i32 %v3004 to i64
  %cond3006 = icmp ne i64 %cv3005, 0
  br i1 %cond3006, label %bb_rcgdec542, label %bb_rcgslow542
bb_rcgslow542:
  %v3007 = load i64, ptr %slot419, align 8
  %v3008 = load i64, ptr %slot416, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v3007, i64 %v3008) nomerge, !dbg !124
  br label %bb_rcgdone542
bb_rcgdec542:
  %v3009 = load i64, ptr %slot428, align 8
  %v3010 = load i64, ptr %slot420, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  %rgep3012 = getelementptr i8, ptr %p3011, i64 -24
  store i64 %v3009, ptr %rgep3012, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear542
bb_rcgclear542:
  %v3013 = load i64, ptr %slot416, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  store i64 0, ptr %p3014, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone542
bb_rcgdone542:
  br label %bb_rcslotdone526
bb_rcslotowner526:
  %v3015 = load i64, ptr %slot35, align 8
  store i64 %v3015, ptr %slot433, align 8
  %v3016 = load i64, ptr %slot416, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  %ld3018 = load i64, ptr %p3017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3018, ptr %slot434, align 8
  %v3019 = load i64, ptr %slot434, align 8
  %cmp3020 = icmp ne i64 %v3019, 0
  %cv3021 = zext i1 %cmp3020 to i32
  store i32 %cv3021, ptr %slot435, align 8
  %v3022 = load i32, ptr %slot435, align 8
  %cv3023 = zext i32 %v3022 to i64
  %cond3024 = icmp ne i64 %cv3023, 0
  br i1 %cond3024, label %bb_rcgnn557, label %bb_rcgdone557
bb_rcgnn557:
  %v3025 = load i64, ptr %slot434, align 8
  %op3026 = sub i64 %v3025, 16
  store i64 %op3026, ptr %slot436, align 8
  %v3027 = load i64, ptr %slot434, align 8
  %p3028 = inttoptr i64 %v3027 to ptr
  %rgep3029 = getelementptr i8, ptr %p3028, i64 -16
  %ld3030 = load i64, ptr %rgep3029, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3030, ptr %slot437, align 8
  %v3031 = load i64, ptr %slot437, align 8
  %op3032 = and i64 %v3031, 4611686018427387906
  store i64 %op3032, ptr %slot438, align 8
  %v3033 = load i64, ptr %slot438, align 8
  %cmp3034 = icmp ne i64 %v3033, 0
  %cv3035 = zext i1 %cmp3034 to i32
  store i32 %cv3035, ptr %slot439, align 8
  %v3036 = load i32, ptr %slot439, align 8
  %cv3037 = zext i32 %v3036 to i64
  %cond3038 = icmp ne i64 %cv3037, 0
  br i1 %cond3038, label %bb_rcgclear557, label %bb_rcgcounted557
bb_rcgcounted557:
  %v3039 = load i64, ptr %slot434, align 8
  %op3040 = sub i64 %v3039, 32
  store i64 %op3040, ptr %slot440, align 8
  %v3041 = load i64, ptr %slot434, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  %rgep3043 = getelementptr i8, ptr %p3042, i64 -32
  %ld3044 = load i64, ptr %rgep3043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3044, ptr %slot441, align 8
  %v3045 = load i64, ptr %slot441, align 8
  %op3046 = sub i64 %v3045, 1
  store i64 %op3046, ptr %slot442, align 8
  %v3047 = load i64, ptr %slot442, align 8
  %cmp3048 = icmp eq i64 %v3047, 0
  %cv3049 = zext i1 %cmp3048 to i32
  store i32 %cv3049, ptr %slot443, align 8
  %v3050 = load i32, ptr %slot443, align 8
  %cv3051 = zext i32 %v3050 to i64
  %cond3052 = icmp ne i64 %cv3051, 0
  br i1 %cond3052, label %bb_rcglast557, label %bb_rcgdec557
bb_rcglast557:
  %v3053 = load i64, ptr %slot434, align 8
  %op3054 = sub i64 %v3053, 24
  store i64 %op3054, ptr %slot444, align 8
  %v3055 = load i64, ptr %slot434, align 8
  %p3056 = inttoptr i64 %v3055 to ptr
  %rgep3057 = getelementptr i8, ptr %p3056, i64 -24
  %ld3058 = load i64, ptr %rgep3057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3058, ptr %slot445, align 8
  %v3059 = load i64, ptr %slot445, align 8
  %cmp3060 = icmp ne i64 %v3059, 0
  %cv3061 = zext i1 %cmp3060 to i32
  store i32 %cv3061, ptr %slot446, align 8
  %v3062 = load i32, ptr %slot446, align 8
  %cv3063 = zext i32 %v3062 to i64
  %cond3064 = icmp ne i64 %cv3063, 0
  br i1 %cond3064, label %bb_rcgdec557, label %bb_rcgslow557
bb_rcgslow557:
  %v3065 = load i64, ptr %slot433, align 8
  %v3066 = load i64, ptr %slot416, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v3065, i64 %v3066) nomerge, !dbg !124
  br label %bb_rcgdone557
bb_rcgdec557:
  %v3067 = load i64, ptr %slot442, align 8
  %v3068 = load i64, ptr %slot434, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %rgep3070 = getelementptr i8, ptr %p3069, i64 -32
  store i64 %v3067, ptr %rgep3070, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear557
bb_rcgclear557:
  %v3071 = load i64, ptr %slot416, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  store i64 0, ptr %p3072, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone557
bb_rcgdone557:
  br label %bb_rcslotdone526
bb_rcslotdone526:
  %v3073 = load i64, ptr %slot19, align 8
  store i64 %v3073, ptr %slot447, align 8
  %v3074 = load i64, ptr %slot447, align 8
  %v3075 = load i64, ptr %slot396, align 8
  %p3076 = inttoptr i64 %v3074 to ptr
  %p3077 = inttoptr i64 %v3075 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3077, ptr %p3076, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3078 = load i64, ptr %slot8, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  store i32 2, ptr %p3079, align 4, !alias.scope !3, !noalias !4
  %v3080 = load i64, ptr %slot7, align 8
  %p3081 = inttoptr i64 %v3080 to ptr
  store i32 1, ptr %p3081, align 4, !alias.scope !3, !noalias !4
  %v3082 = load i64, ptr %slot15, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  store i32 0, ptr %p3083, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal498
bb_rcownedlocal498:
  %v3084 = load i64, ptr %slot8, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  store i32 2, ptr %p3085, align 4, !alias.scope !3, !noalias !4
  %v3086 = load i64, ptr %slot391, align 8
  %p3087 = inttoptr i64 %v3086 to ptr
  %ld3088 = load i64, ptr %p3087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3088, ptr %slot448, align 8
  %v3089 = load i64, ptr %slot448, align 8
  %cmp3090 = icmp ne i64 %v3089, 0
  %cv3091 = zext i1 %cmp3090 to i32
  store i32 %cv3091, ptr %slot449, align 8
  %v3092 = load i32, ptr %slot449, align 8
  %cv3093 = zext i32 %v3092 to i64
  %cond3094 = icmp ne i64 %cv3093, 0
  br i1 %cond3094, label %bb_rcguniquenn566, label %bb_rcgunique566
bb_rcguniquenn566:
  %v3095 = load i64, ptr %slot448, align 8
  %op3096 = sub i64 %v3095, 16
  store i64 %op3096, ptr %slot450, align 8
  %v3097 = load i64, ptr %slot448, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  %rgep3099 = getelementptr i8, ptr %p3098, i64 -16
  %ld3100 = load i64, ptr %rgep3099, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3100, ptr %slot451, align 8
  %v3101 = load i64, ptr %slot451, align 8
  %op3102 = and i64 %v3101, 6917529027641081858
  store i64 %op3102, ptr %slot452, align 8
  %v3103 = load i64, ptr %slot452, align 8
  %cmp3104 = icmp ne i64 %v3103, 0
  %cv3105 = zext i1 %cmp3104 to i32
  store i32 %cv3105, ptr %slot453, align 8
  %v3106 = load i32, ptr %slot453, align 8
  %cv3107 = zext i32 %v3106 to i64
  %cond3108 = icmp ne i64 %cv3107, 0
  br i1 %cond3108, label %bb_rcguniqueslow566, label %bb_rcguniquecount566
bb_rcguniquecount566:
  %v3109 = load i64, ptr %slot448, align 8
  %op3110 = sub i64 %v3109, 32
  store i64 %op3110, ptr %slot454, align 8
  %v3111 = load i64, ptr %slot448, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  %rgep3113 = getelementptr i8, ptr %p3112, i64 -32
  %ld3114 = load i64, ptr %rgep3113, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3114, ptr %slot455, align 8
  %v3115 = load i64, ptr %slot455, align 8
  %cmp3116 = icmp ult i64 %v3115, 2
  %cv3117 = zext i1 %cmp3116 to i32
  store i32 %cv3117, ptr %slot456, align 8
  %v3118 = load i32, ptr %slot456, align 8
  %cv3119 = zext i32 %v3118 to i64
  %cond3120 = icmp ne i64 %cv3119, 0
  br i1 %cond3120, label %bb_rcgunique566, label %bb_rcguniqueslow566
bb_rcguniqueslow566:
  %v3121 = load i64, ptr %slot1, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  %p3123 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v3124 = load i64, ptr %slot391, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  %v3126 = load i64, ptr %slot7, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  %call3128 = call i32 @myl_qbe_rc_unique_local(ptr %p3122, ptr %p3123, ptr %p3125, ptr %p3127) nomerge, !dbg !124
  store i32 %call3128, ptr %slot457, align 8
  %v3129 = load i32, ptr %slot457, align 8
  %cv3130 = zext i32 %v3129 to i64
  %cond3131 = icmp ne i64 %cv3130, 0
  br i1 %cond3131, label %bb_rcunique577, label %bb_failure
bb_rcunique577:
  br label %bb_rcgunique566
bb_rcgunique566:
  %v3132 = load i64, ptr %slot25, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  %ld3134 = load i64, ptr %p3133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3134, ptr %slot458, align 8
  %v3135 = load i64, ptr %slot30, align 8
  store i64 %v3135, ptr %slot459, align 8
  %v3136 = load i64, ptr %slot459, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  %ld3138 = load i64, ptr %p3137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3138, ptr %slot460, align 8
  %v3139 = load i64, ptr %slot460, align 8
  %v3140 = load i64, ptr %slot20, align 8
  %p3141 = inttoptr i64 %v3140 to ptr
  store i64 %v3139, ptr %p3141, align 8, !alias.scope !3, !noalias !4
  %v3142 = load i64, ptr %slot20, align 8
  store i64 %v3142, ptr %slot461, align 8
  %v3143 = load i64, ptr %slot35, align 8
  %v3144 = load i64, ptr %slot458, align 8
  %v3145 = load i64, ptr %slot461, align 8
  %call3146 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v3143, i64 %v3144, i64 %v3145) nomerge, !dbg !124
  store i32 %call3146, ptr %slot462, align 8
  %v3147 = load i32, ptr %slot462, align 8
  %cv3148 = zext i32 %v3147 to i64
  %cond3149 = icmp ne i64 %cv3148, 0
  br i1 %cond3149, label %bb_success583, label %bb_failed583
bb_failed583:
  %v3150 = load i64, ptr %slot1, align 8
  %p3151 = inttoptr i64 %v3150 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3151) nomerge, !dbg !124
  unreachable
bb_success583:
  %v3152 = load i64, ptr %slot30, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  store i64 0, ptr %p3153, align 8, !alias.scope !3, !noalias !4
  %v3154 = load i64, ptr %slot13, align 8
  %p3155 = inttoptr i64 %v3154 to ptr
  %ld3156 = load i32, ptr %p3155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3156, ptr %slot463, align 8
  %v3157 = load i32, ptr %slot463, align 8
  %cv3158 = zext i32 %v3157 to i64
  %cond3159 = icmp ne i64 %cv3158, 0
  br i1 %cond3159, label %bb_rcslotdrop586, label %bb_rcslotdone586
bb_rcslotdrop586:
  %v3160 = load i64, ptr %slot13, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  store i32 0, ptr %p3161, align 4, !alias.scope !3, !noalias !4
  %v3162 = load i64, ptr %slot17, align 8
  store i64 %v3162, ptr %slot464, align 8
  %v3163 = load i64, ptr %slot14, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  %ld3165 = load i32, ptr %p3164, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3165, ptr %slot465, align 8
  %v3166 = load i32, ptr %slot465, align 8
  %op3167 = and i32 %v3166, 28
  store i32 %op3167, ptr %slot466, align 8
  %v3168 = load i32, ptr %slot466, align 8
  %cv3169 = zext i32 %v3168 to i64
  %cond3170 = icmp ne i64 %cv3169, 0
  br i1 %cond3170, label %bb_rcslotrole586, label %bb_rcslotowner586
bb_rcslotrole586:
  %v3171 = load i64, ptr %slot35, align 8
  store i64 %v3171, ptr %slot467, align 8
  %v3172 = load i64, ptr %slot464, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  %ld3174 = load i64, ptr %p3173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3174, ptr %slot468, align 8
  %v3175 = load i64, ptr %slot468, align 8
  %cmp3176 = icmp ne i64 %v3175, 0
  %cv3177 = zext i1 %cmp3176 to i32
  store i32 %cv3177, ptr %slot469, align 8
  %v3178 = load i32, ptr %slot469, align 8
  %cv3179 = zext i32 %v3178 to i64
  %cond3180 = icmp ne i64 %cv3179, 0
  br i1 %cond3180, label %bb_rcgnn602, label %bb_rcgdone602
bb_rcgnn602:
  %v3181 = load i64, ptr %slot468, align 8
  %op3182 = sub i64 %v3181, 16
  store i64 %op3182, ptr %slot470, align 8
  %v3183 = load i64, ptr %slot468, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  %rgep3185 = getelementptr i8, ptr %p3184, i64 -16
  %ld3186 = load i64, ptr %rgep3185, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3186, ptr %slot471, align 8
  %v3187 = load i64, ptr %slot471, align 8
  %op3188 = and i64 %v3187, 4611686018427387906
  store i64 %op3188, ptr %slot472, align 8
  %v3189 = load i64, ptr %slot472, align 8
  %cmp3190 = icmp ne i64 %v3189, 0
  %cv3191 = zext i1 %cmp3190 to i32
  store i32 %cv3191, ptr %slot473, align 8
  %v3192 = load i32, ptr %slot473, align 8
  %cv3193 = zext i32 %v3192 to i64
  %cond3194 = icmp ne i64 %cv3193, 0
  br i1 %cond3194, label %bb_rcgclear602, label %bb_rcgcounted602
bb_rcgcounted602:
  %v3195 = load i64, ptr %slot468, align 8
  %op3196 = sub i64 %v3195, 24
  store i64 %op3196, ptr %slot474, align 8
  %v3197 = load i64, ptr %slot468, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  %rgep3199 = getelementptr i8, ptr %p3198, i64 -24
  %ld3200 = load i64, ptr %rgep3199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3200, ptr %slot475, align 8
  %v3201 = load i64, ptr %slot475, align 8
  %op3202 = sub i64 %v3201, 1
  store i64 %op3202, ptr %slot476, align 8
  %v3203 = load i64, ptr %slot476, align 8
  %cmp3204 = icmp eq i64 %v3203, 0
  %cv3205 = zext i1 %cmp3204 to i32
  store i32 %cv3205, ptr %slot477, align 8
  %v3206 = load i32, ptr %slot477, align 8
  %cv3207 = zext i32 %v3206 to i64
  %cond3208 = icmp ne i64 %cv3207, 0
  br i1 %cond3208, label %bb_rcglast602, label %bb_rcgdec602
bb_rcglast602:
  %v3209 = load i64, ptr %slot468, align 8
  %op3210 = sub i64 %v3209, 32
  store i64 %op3210, ptr %slot478, align 8
  %v3211 = load i64, ptr %slot468, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %rgep3213 = getelementptr i8, ptr %p3212, i64 -32
  %ld3214 = load i64, ptr %rgep3213, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3214, ptr %slot479, align 8
  %v3215 = load i64, ptr %slot479, align 8
  %cmp3216 = icmp ne i64 %v3215, 0
  %cv3217 = zext i1 %cmp3216 to i32
  store i32 %cv3217, ptr %slot480, align 8
  %v3218 = load i32, ptr %slot480, align 8
  %cv3219 = zext i32 %v3218 to i64
  %cond3220 = icmp ne i64 %cv3219, 0
  br i1 %cond3220, label %bb_rcgdec602, label %bb_rcgslow602
bb_rcgslow602:
  %v3221 = load i64, ptr %slot467, align 8
  %v3222 = load i64, ptr %slot464, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v3221, i64 %v3222) nomerge, !dbg !124
  br label %bb_rcgdone602
bb_rcgdec602:
  %v3223 = load i64, ptr %slot476, align 8
  %v3224 = load i64, ptr %slot468, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  %rgep3226 = getelementptr i8, ptr %p3225, i64 -24
  store i64 %v3223, ptr %rgep3226, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear602
bb_rcgclear602:
  %v3227 = load i64, ptr %slot464, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  store i64 0, ptr %p3228, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone602
bb_rcgdone602:
  br label %bb_rcslotdone586
bb_rcslotowner586:
  %v3229 = load i64, ptr %slot35, align 8
  store i64 %v3229, ptr %slot481, align 8
  %v3230 = load i64, ptr %slot464, align 8
  %p3231 = inttoptr i64 %v3230 to ptr
  %ld3232 = load i64, ptr %p3231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3232, ptr %slot482, align 8
  %v3233 = load i64, ptr %slot482, align 8
  %cmp3234 = icmp ne i64 %v3233, 0
  %cv3235 = zext i1 %cmp3234 to i32
  store i32 %cv3235, ptr %slot483, align 8
  %v3236 = load i32, ptr %slot483, align 8
  %cv3237 = zext i32 %v3236 to i64
  %cond3238 = icmp ne i64 %cv3237, 0
  br i1 %cond3238, label %bb_rcgnn617, label %bb_rcgdone617
bb_rcgnn617:
  %v3239 = load i64, ptr %slot482, align 8
  %op3240 = sub i64 %v3239, 16
  store i64 %op3240, ptr %slot484, align 8
  %v3241 = load i64, ptr %slot482, align 8
  %p3242 = inttoptr i64 %v3241 to ptr
  %rgep3243 = getelementptr i8, ptr %p3242, i64 -16
  %ld3244 = load i64, ptr %rgep3243, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3244, ptr %slot485, align 8
  %v3245 = load i64, ptr %slot485, align 8
  %op3246 = and i64 %v3245, 4611686018427387906
  store i64 %op3246, ptr %slot486, align 8
  %v3247 = load i64, ptr %slot486, align 8
  %cmp3248 = icmp ne i64 %v3247, 0
  %cv3249 = zext i1 %cmp3248 to i32
  store i32 %cv3249, ptr %slot487, align 8
  %v3250 = load i32, ptr %slot487, align 8
  %cv3251 = zext i32 %v3250 to i64
  %cond3252 = icmp ne i64 %cv3251, 0
  br i1 %cond3252, label %bb_rcgclear617, label %bb_rcgcounted617
bb_rcgcounted617:
  %v3253 = load i64, ptr %slot482, align 8
  %op3254 = sub i64 %v3253, 32
  store i64 %op3254, ptr %slot488, align 8
  %v3255 = load i64, ptr %slot482, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  %rgep3257 = getelementptr i8, ptr %p3256, i64 -32
  %ld3258 = load i64, ptr %rgep3257, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3258, ptr %slot489, align 8
  %v3259 = load i64, ptr %slot489, align 8
  %op3260 = sub i64 %v3259, 1
  store i64 %op3260, ptr %slot490, align 8
  %v3261 = load i64, ptr %slot490, align 8
  %cmp3262 = icmp eq i64 %v3261, 0
  %cv3263 = zext i1 %cmp3262 to i32
  store i32 %cv3263, ptr %slot491, align 8
  %v3264 = load i32, ptr %slot491, align 8
  %cv3265 = zext i32 %v3264 to i64
  %cond3266 = icmp ne i64 %cv3265, 0
  br i1 %cond3266, label %bb_rcglast617, label %bb_rcgdec617
bb_rcglast617:
  %v3267 = load i64, ptr %slot482, align 8
  %op3268 = sub i64 %v3267, 24
  store i64 %op3268, ptr %slot492, align 8
  %v3269 = load i64, ptr %slot482, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  %rgep3271 = getelementptr i8, ptr %p3270, i64 -24
  %ld3272 = load i64, ptr %rgep3271, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3272, ptr %slot493, align 8
  %v3273 = load i64, ptr %slot493, align 8
  %cmp3274 = icmp ne i64 %v3273, 0
  %cv3275 = zext i1 %cmp3274 to i32
  store i32 %cv3275, ptr %slot494, align 8
  %v3276 = load i32, ptr %slot494, align 8
  %cv3277 = zext i32 %v3276 to i64
  %cond3278 = icmp ne i64 %cv3277, 0
  br i1 %cond3278, label %bb_rcgdec617, label %bb_rcgslow617
bb_rcgslow617:
  %v3279 = load i64, ptr %slot481, align 8
  %v3280 = load i64, ptr %slot464, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v3279, i64 %v3280) nomerge, !dbg !124
  br label %bb_rcgdone617
bb_rcgdec617:
  %v3281 = load i64, ptr %slot490, align 8
  %v3282 = load i64, ptr %slot482, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  %rgep3284 = getelementptr i8, ptr %p3283, i64 -32
  store i64 %v3281, ptr %rgep3284, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear617
bb_rcgclear617:
  %v3285 = load i64, ptr %slot464, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  store i64 0, ptr %p3286, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone617
bb_rcgdone617:
  br label %bb_rcslotdone586
bb_rcslotdone586:
  %p3287 = inttoptr i64 ptrtoint (ptr @myl_lit_fadbbcee37090aefcabf2bf0f6a9366f5f34ef8c1ccde596b7696a8936daffcc to i64) to ptr
  %ld3288 = load i64, ptr %p3287, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3288, ptr %slot495, align 8
  %v3289 = load i64, ptr %slot495, align 8
  %v3290 = load i64, ptr %slot30, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  store i64 %v3289, ptr %p3291, align 8, !alias.scope !3, !noalias !4
  %v3292 = load i64, ptr %slot30, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  %ld3294 = load i64, ptr %p3293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3294, ptr %slot496, align 8
  %v3295 = load i64, ptr %slot496, align 8
  %v3296 = load i64, ptr %slot18, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  store i64 %v3295, ptr %p3297, align 8, !alias.scope !3, !noalias !4
  %v3298 = load i64, ptr %slot18, align 8
  store i64 %v3298, ptr %slot497, align 8
  %v3299 = load i64, ptr %slot19, align 8
  store i64 %v3299, ptr %slot498, align 8
  %v3300 = load i64, ptr %slot497, align 8
  %v3301 = load i64, ptr %slot498, align 8
  %p3302 = inttoptr i64 %v3300 to ptr
  %p3303 = inttoptr i64 %v3301 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3303, ptr %p3302, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3304 = load i64, ptr %slot16, align 8
  %p3305 = inttoptr i64 %v3304 to ptr
  store i32 2, ptr %p3305, align 4, !alias.scope !3, !noalias !4
  %v3306 = load i64, ptr %slot15, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  store i32 1, ptr %p3307, align 4, !alias.scope !3, !noalias !4
  %v3308 = load i64, ptr %slot17, align 8
  store i64 %v3308, ptr %slot499, align 8
  %v3309 = load i64, ptr %slot19, align 8
  store i64 %v3309, ptr %slot500, align 8
  %v3310 = load i64, ptr %slot500, align 8
  %v3311 = load i64, ptr %slot499, align 8
  %p3312 = inttoptr i64 %v3310 to ptr
  %p3313 = inttoptr i64 %v3311 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3313, ptr %p3312, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3314 = load i64, ptr %slot14, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  store i32 2, ptr %p3315, align 4, !alias.scope !3, !noalias !4
  %v3316 = load i64, ptr %slot16, align 8
  %p3317 = inttoptr i64 %v3316 to ptr
  %ld3318 = load i32, ptr %p3317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3318, ptr %slot501, align 8
  %v3319 = load i32, ptr %slot501, align 8
  %v3320 = load i64, ptr %slot14, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  store i32 %v3319, ptr %p3321, align 4, !alias.scope !3, !noalias !4
  %v3322 = load i64, ptr %slot15, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  store i32 0, ptr %p3323, align 4, !alias.scope !3, !noalias !4
  %v3324 = load i64, ptr %slot13, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  store i32 1, ptr %p3325, align 4, !alias.scope !3, !noalias !4
  %v3326 = load i64, ptr %slot499, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  %ld3328 = load i64, ptr %p3327, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3328, ptr %slot502, align 8
  %v3329 = load i64, ptr %slot502, align 8
  %v3330 = load i64, ptr %slot30, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  store i64 %v3329, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  %v3332 = load i64, ptr %slot25, align 8
  store i64 %v3332, ptr %slot503, align 8
  %v3333 = load i64, ptr %slot8, align 8
  %p3334 = inttoptr i64 %v3333 to ptr
  %ld3335 = load i32, ptr %p3334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3335, ptr %slot504, align 8
  %v3336 = load i32, ptr %slot504, align 8
  %cmp3337 = icmp eq i32 %v3336, 16
  %cv3338 = zext i1 %cmp3337 to i32
  store i32 %cv3338, ptr %slot505, align 8
  %v3339 = load i64, ptr %slot7, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  %ld3341 = load i32, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3341, ptr %slot506, align 8
  %v3342 = load i32, ptr %slot506, align 8
  %v3343 = load i32, ptr %slot505, align 8
  %op3344 = and i32 %v3342, %v3343
  store i32 %op3344, ptr %slot507, align 8
  %v3345 = load i32, ptr %slot507, align 8
  %cv3346 = zext i32 %v3345 to i64
  %cond3347 = icmp ne i64 %cv3346, 0
  br i1 %cond3347, label %bb_rcownlocal643, label %bb_rcownedlocal643
bb_rcownlocal643:
  %v3348 = load i64, ptr %slot25, align 8
  store i64 %v3348, ptr %slot508, align 8
  %v3349 = load i64, ptr %slot19, align 8
  store i64 %v3349, ptr %slot509, align 8
  %v3350 = load i64, ptr %slot36, align 8
  store i64 %v3350, ptr %slot510, align 8
  %v3351 = load i64, ptr %slot508, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  %ld3353 = load i64, ptr %p3352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3353, ptr %slot511, align 8
  %v3354 = load i64, ptr %slot511, align 8
  %cmp3355 = icmp ne i64 %v3354, 0
  %cv3356 = zext i1 %cmp3355 to i32
  store i32 %cv3356, ptr %slot512, align 8
  %v3357 = load i32, ptr %slot512, align 8
  %cv3358 = zext i32 %v3357 to i64
  %cond3359 = icmp ne i64 %cv3358, 0
  br i1 %cond3359, label %bb_rcgnn650, label %bb_rcgplain650
bb_rcgnn650:
  %v3360 = load i64, ptr %slot511, align 8
  %op3361 = sub i64 %v3360, 16
  store i64 %op3361, ptr %slot513, align 8
  %v3362 = load i64, ptr %slot511, align 8
  %p3363 = inttoptr i64 %v3362 to ptr
  %rgep3364 = getelementptr i8, ptr %p3363, i64 -16
  %ld3365 = load i64, ptr %rgep3364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3365, ptr %slot514, align 8
  %v3366 = load i64, ptr %slot514, align 8
  %op3367 = and i64 %v3366, 4611686018427387906
  store i64 %op3367, ptr %slot515, align 8
  %v3368 = load i64, ptr %slot515, align 8
  %cmp3369 = icmp ne i64 %v3368, 0
  %cv3370 = zext i1 %cmp3369 to i32
  store i32 %cv3370, ptr %slot516, align 8
  %v3371 = load i32, ptr %slot516, align 8
  %cv3372 = zext i32 %v3371 to i64
  %cond3373 = icmp ne i64 %cv3372, 0
  br i1 %cond3373, label %bb_rcgspecial650, label %bb_rcginc650
bb_rcginc650:
  %v3374 = load i64, ptr %slot511, align 8
  %op3375 = sub i64 %v3374, 32
  store i64 %op3375, ptr %slot517, align 8
  %v3376 = load i64, ptr %slot511, align 8
  %p3377 = inttoptr i64 %v3376 to ptr
  %rgep3378 = getelementptr i8, ptr %p3377, i64 -32
  %ld3379 = load i64, ptr %rgep3378, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3379, ptr %slot518, align 8
  %v3380 = load i64, ptr %slot518, align 8
  %op3381 = add i64 %v3380, 1
  store i64 %op3381, ptr %slot519, align 8
  %v3382 = load i64, ptr %slot519, align 8
  %cmp3383 = icmp eq i64 %v3382, 0
  %cv3384 = zext i1 %cmp3383 to i32
  store i32 %cv3384, ptr %slot520, align 8
  %v3385 = load i32, ptr %slot520, align 8
  %cv3386 = zext i32 %v3385 to i64
  %cond3387 = icmp ne i64 %cv3386, 0
  br i1 %cond3387, label %bb_rcglimit650, label %bb_rcgcapacity650
bb_rcglimit650:
  %v3388 = load i64, ptr %slot1, align 8
  %p3389 = inttoptr i64 %v3388 to ptr
  %call3390 = call i32 @myl_qbe_rc_status(ptr %p3389, i32 2) nomerge, !dbg !126
  store i32 %call3390, ptr %slot521, align 8
  br label %bb_failure
bb_rcgcapacity650:
  %v3391 = load i64, ptr %slot519, align 8
  %v3392 = load i64, ptr %slot511, align 8
  %p3393 = inttoptr i64 %v3392 to ptr
  %rgep3394 = getelementptr i8, ptr %p3393, i64 -32
  store i64 %v3391, ptr %rgep3394, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain650
bb_rcgspecial650:
  %v3395 = load i64, ptr %slot514, align 8
  %op3396 = and i64 %v3395, 4611686018427387904
  store i64 %op3396, ptr %slot522, align 8
  %v3397 = load i64, ptr %slot522, align 8
  %cmp3398 = icmp ne i64 %v3397, 0
  %cv3399 = zext i1 %cmp3398 to i32
  store i32 %cv3399, ptr %slot523, align 8
  %v3400 = load i32, ptr %slot523, align 8
  %cv3401 = zext i32 %v3400 to i64
  %cond3402 = icmp ne i64 %cv3401, 0
  br i1 %cond3402, label %bb_rcgslow650, label %bb_rcgplain650
bb_rcgslow650:
  %v3403 = load i64, ptr %slot35, align 8
  %v3404 = load i64, ptr %slot509, align 8
  %v3405 = load i64, ptr %slot508, align 8
  %v3406 = load i64, ptr %slot510, align 8
  %cv3407 = trunc i64 %v3406 to i32
  %call3408 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v3403, i64 %v3404, i64 %v3405, i32 %cv3407) nomerge, !dbg !126
  store i32 %call3408, ptr %slot524, align 8
  %v3409 = load i32, ptr %slot524, align 8
  %cv3410 = zext i32 %v3409 to i64
  %cond3411 = icmp ne i64 %cv3410, 0
  br i1 %cond3411, label %bb_rcsuccess664, label %bb_rcfailure664
bb_rcfailure664:
  %v3412 = load i64, ptr %slot35, align 8
  %p3413 = inttoptr i64 %v3412 to ptr
  %call3414 = call i32 @myl_rc_take_failure(ptr %p3413) nomerge, !dbg !126
  store i32 %call3414, ptr %slot525, align 8
  %v3415 = load i64, ptr %slot1, align 8
  %p3416 = inttoptr i64 %v3415 to ptr
  %v3417 = load i32, ptr %slot525, align 8
  %call3418 = call i32 @myl_qbe_rc_status(ptr %p3416, i32 %v3417) nomerge, !dbg !126
  store i32 %call3418, ptr %slot526, align 8
  br label %bb_failure
bb_rcsuccess664:
  br label %bb_rcgdone650
bb_rcgplain650:
  %v3419 = load i64, ptr %slot511, align 8
  %v3420 = load i64, ptr %slot509, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  store i64 %v3419, ptr %p3421, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone650
bb_rcgdone650:
  %v3422 = load i64, ptr %slot16, align 8
  %p3423 = inttoptr i64 %v3422 to ptr
  store i32 2, ptr %p3423, align 4, !alias.scope !3, !noalias !4
  %v3424 = load i64, ptr %slot15, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  store i32 1, ptr %p3425, align 4, !alias.scope !3, !noalias !4
  %v3426 = load i64, ptr %slot7, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  %ld3428 = load i32, ptr %p3427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3428, ptr %slot527, align 8
  %v3429 = load i32, ptr %slot527, align 8
  %cv3430 = zext i32 %v3429 to i64
  %cond3431 = icmp ne i64 %cv3430, 0
  br i1 %cond3431, label %bb_rcslotdrop671, label %bb_rcslotdone671
bb_rcslotdrop671:
  %v3432 = load i64, ptr %slot7, align 8
  %p3433 = inttoptr i64 %v3432 to ptr
  store i32 0, ptr %p3433, align 4, !alias.scope !3, !noalias !4
  %v3434 = load i64, ptr %slot25, align 8
  store i64 %v3434, ptr %slot528, align 8
  %v3435 = load i64, ptr %slot8, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  %ld3437 = load i32, ptr %p3436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3437, ptr %slot529, align 8
  %v3438 = load i32, ptr %slot529, align 8
  %op3439 = and i32 %v3438, 28
  store i32 %op3439, ptr %slot530, align 8
  %v3440 = load i32, ptr %slot530, align 8
  %cv3441 = zext i32 %v3440 to i64
  %cond3442 = icmp ne i64 %cv3441, 0
  br i1 %cond3442, label %bb_rcslotrole671, label %bb_rcslotowner671
bb_rcslotrole671:
  %v3443 = load i64, ptr %slot35, align 8
  store i64 %v3443, ptr %slot531, align 8
  %v3444 = load i64, ptr %slot528, align 8
  %p3445 = inttoptr i64 %v3444 to ptr
  %ld3446 = load i64, ptr %p3445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3446, ptr %slot532, align 8
  %v3447 = load i64, ptr %slot532, align 8
  %cmp3448 = icmp ne i64 %v3447, 0
  %cv3449 = zext i1 %cmp3448 to i32
  store i32 %cv3449, ptr %slot533, align 8
  %v3450 = load i32, ptr %slot533, align 8
  %cv3451 = zext i32 %v3450 to i64
  %cond3452 = icmp ne i64 %cv3451, 0
  br i1 %cond3452, label %bb_rcgnn687, label %bb_rcgdone687
bb_rcgnn687:
  %v3453 = load i64, ptr %slot532, align 8
  %op3454 = sub i64 %v3453, 16
  store i64 %op3454, ptr %slot534, align 8
  %v3455 = load i64, ptr %slot532, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  %rgep3457 = getelementptr i8, ptr %p3456, i64 -16
  %ld3458 = load i64, ptr %rgep3457, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3458, ptr %slot535, align 8
  %v3459 = load i64, ptr %slot535, align 8
  %op3460 = and i64 %v3459, 4611686018427387906
  store i64 %op3460, ptr %slot536, align 8
  %v3461 = load i64, ptr %slot536, align 8
  %cmp3462 = icmp ne i64 %v3461, 0
  %cv3463 = zext i1 %cmp3462 to i32
  store i32 %cv3463, ptr %slot537, align 8
  %v3464 = load i32, ptr %slot537, align 8
  %cv3465 = zext i32 %v3464 to i64
  %cond3466 = icmp ne i64 %cv3465, 0
  br i1 %cond3466, label %bb_rcgclear687, label %bb_rcgcounted687
bb_rcgcounted687:
  %v3467 = load i64, ptr %slot532, align 8
  %op3468 = sub i64 %v3467, 24
  store i64 %op3468, ptr %slot538, align 8
  %v3469 = load i64, ptr %slot532, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  %rgep3471 = getelementptr i8, ptr %p3470, i64 -24
  %ld3472 = load i64, ptr %rgep3471, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3472, ptr %slot539, align 8
  %v3473 = load i64, ptr %slot539, align 8
  %op3474 = sub i64 %v3473, 1
  store i64 %op3474, ptr %slot540, align 8
  %v3475 = load i64, ptr %slot540, align 8
  %cmp3476 = icmp eq i64 %v3475, 0
  %cv3477 = zext i1 %cmp3476 to i32
  store i32 %cv3477, ptr %slot541, align 8
  %v3478 = load i32, ptr %slot541, align 8
  %cv3479 = zext i32 %v3478 to i64
  %cond3480 = icmp ne i64 %cv3479, 0
  br i1 %cond3480, label %bb_rcglast687, label %bb_rcgdec687
bb_rcglast687:
  %v3481 = load i64, ptr %slot532, align 8
  %op3482 = sub i64 %v3481, 32
  store i64 %op3482, ptr %slot542, align 8
  %v3483 = load i64, ptr %slot532, align 8
  %p3484 = inttoptr i64 %v3483 to ptr
  %rgep3485 = getelementptr i8, ptr %p3484, i64 -32
  %ld3486 = load i64, ptr %rgep3485, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3486, ptr %slot543, align 8
  %v3487 = load i64, ptr %slot543, align 8
  %cmp3488 = icmp ne i64 %v3487, 0
  %cv3489 = zext i1 %cmp3488 to i32
  store i32 %cv3489, ptr %slot544, align 8
  %v3490 = load i32, ptr %slot544, align 8
  %cv3491 = zext i32 %v3490 to i64
  %cond3492 = icmp ne i64 %cv3491, 0
  br i1 %cond3492, label %bb_rcgdec687, label %bb_rcgslow687
bb_rcgslow687:
  %v3493 = load i64, ptr %slot531, align 8
  %v3494 = load i64, ptr %slot528, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v3493, i64 %v3494) nomerge, !dbg !126
  br label %bb_rcgdone687
bb_rcgdec687:
  %v3495 = load i64, ptr %slot540, align 8
  %v3496 = load i64, ptr %slot532, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  %rgep3498 = getelementptr i8, ptr %p3497, i64 -24
  store i64 %v3495, ptr %rgep3498, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear687
bb_rcgclear687:
  %v3499 = load i64, ptr %slot528, align 8
  %p3500 = inttoptr i64 %v3499 to ptr
  store i64 0, ptr %p3500, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone687
bb_rcgdone687:
  br label %bb_rcslotdone671
bb_rcslotowner671:
  %v3501 = load i64, ptr %slot35, align 8
  store i64 %v3501, ptr %slot545, align 8
  %v3502 = load i64, ptr %slot528, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  %ld3504 = load i64, ptr %p3503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3504, ptr %slot546, align 8
  %v3505 = load i64, ptr %slot546, align 8
  %cmp3506 = icmp ne i64 %v3505, 0
  %cv3507 = zext i1 %cmp3506 to i32
  store i32 %cv3507, ptr %slot547, align 8
  %v3508 = load i32, ptr %slot547, align 8
  %cv3509 = zext i32 %v3508 to i64
  %cond3510 = icmp ne i64 %cv3509, 0
  br i1 %cond3510, label %bb_rcgnn702, label %bb_rcgdone702
bb_rcgnn702:
  %v3511 = load i64, ptr %slot546, align 8
  %op3512 = sub i64 %v3511, 16
  store i64 %op3512, ptr %slot548, align 8
  %v3513 = load i64, ptr %slot546, align 8
  %p3514 = inttoptr i64 %v3513 to ptr
  %rgep3515 = getelementptr i8, ptr %p3514, i64 -16
  %ld3516 = load i64, ptr %rgep3515, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3516, ptr %slot549, align 8
  %v3517 = load i64, ptr %slot549, align 8
  %op3518 = and i64 %v3517, 4611686018427387906
  store i64 %op3518, ptr %slot550, align 8
  %v3519 = load i64, ptr %slot550, align 8
  %cmp3520 = icmp ne i64 %v3519, 0
  %cv3521 = zext i1 %cmp3520 to i32
  store i32 %cv3521, ptr %slot551, align 8
  %v3522 = load i32, ptr %slot551, align 8
  %cv3523 = zext i32 %v3522 to i64
  %cond3524 = icmp ne i64 %cv3523, 0
  br i1 %cond3524, label %bb_rcgclear702, label %bb_rcgcounted702
bb_rcgcounted702:
  %v3525 = load i64, ptr %slot546, align 8
  %op3526 = sub i64 %v3525, 32
  store i64 %op3526, ptr %slot552, align 8
  %v3527 = load i64, ptr %slot546, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  %rgep3529 = getelementptr i8, ptr %p3528, i64 -32
  %ld3530 = load i64, ptr %rgep3529, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3530, ptr %slot553, align 8
  %v3531 = load i64, ptr %slot553, align 8
  %op3532 = sub i64 %v3531, 1
  store i64 %op3532, ptr %slot554, align 8
  %v3533 = load i64, ptr %slot554, align 8
  %cmp3534 = icmp eq i64 %v3533, 0
  %cv3535 = zext i1 %cmp3534 to i32
  store i32 %cv3535, ptr %slot555, align 8
  %v3536 = load i32, ptr %slot555, align 8
  %cv3537 = zext i32 %v3536 to i64
  %cond3538 = icmp ne i64 %cv3537, 0
  br i1 %cond3538, label %bb_rcglast702, label %bb_rcgdec702
bb_rcglast702:
  %v3539 = load i64, ptr %slot546, align 8
  %op3540 = sub i64 %v3539, 24
  store i64 %op3540, ptr %slot556, align 8
  %v3541 = load i64, ptr %slot546, align 8
  %p3542 = inttoptr i64 %v3541 to ptr
  %rgep3543 = getelementptr i8, ptr %p3542, i64 -24
  %ld3544 = load i64, ptr %rgep3543, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3544, ptr %slot557, align 8
  %v3545 = load i64, ptr %slot557, align 8
  %cmp3546 = icmp ne i64 %v3545, 0
  %cv3547 = zext i1 %cmp3546 to i32
  store i32 %cv3547, ptr %slot558, align 8
  %v3548 = load i32, ptr %slot558, align 8
  %cv3549 = zext i32 %v3548 to i64
  %cond3550 = icmp ne i64 %cv3549, 0
  br i1 %cond3550, label %bb_rcgdec702, label %bb_rcgslow702
bb_rcgslow702:
  %v3551 = load i64, ptr %slot545, align 8
  %v3552 = load i64, ptr %slot528, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v3551, i64 %v3552) nomerge, !dbg !126
  br label %bb_rcgdone702
bb_rcgdec702:
  %v3553 = load i64, ptr %slot554, align 8
  %v3554 = load i64, ptr %slot546, align 8
  %p3555 = inttoptr i64 %v3554 to ptr
  %rgep3556 = getelementptr i8, ptr %p3555, i64 -32
  store i64 %v3553, ptr %rgep3556, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear702
bb_rcgclear702:
  %v3557 = load i64, ptr %slot528, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  store i64 0, ptr %p3558, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone702
bb_rcgdone702:
  br label %bb_rcslotdone671
bb_rcslotdone671:
  %v3559 = load i64, ptr %slot19, align 8
  store i64 %v3559, ptr %slot559, align 8
  %v3560 = load i64, ptr %slot559, align 8
  %v3561 = load i64, ptr %slot508, align 8
  %p3562 = inttoptr i64 %v3560 to ptr
  %p3563 = inttoptr i64 %v3561 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3563, ptr %p3562, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3564 = load i64, ptr %slot8, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  store i32 2, ptr %p3565, align 4, !alias.scope !3, !noalias !4
  %v3566 = load i64, ptr %slot7, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  store i32 1, ptr %p3567, align 4, !alias.scope !3, !noalias !4
  %v3568 = load i64, ptr %slot15, align 8
  %p3569 = inttoptr i64 %v3568 to ptr
  store i32 0, ptr %p3569, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal643
bb_rcownedlocal643:
  %v3570 = load i64, ptr %slot8, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  store i32 2, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  %v3572 = load i64, ptr %slot503, align 8
  %p3573 = inttoptr i64 %v3572 to ptr
  %ld3574 = load i64, ptr %p3573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3574, ptr %slot560, align 8
  %v3575 = load i64, ptr %slot560, align 8
  %cmp3576 = icmp ne i64 %v3575, 0
  %cv3577 = zext i1 %cmp3576 to i32
  store i32 %cv3577, ptr %slot561, align 8
  %v3578 = load i32, ptr %slot561, align 8
  %cv3579 = zext i32 %v3578 to i64
  %cond3580 = icmp ne i64 %cv3579, 0
  br i1 %cond3580, label %bb_rcguniquenn711, label %bb_rcgunique711
bb_rcguniquenn711:
  %v3581 = load i64, ptr %slot560, align 8
  %op3582 = sub i64 %v3581, 16
  store i64 %op3582, ptr %slot562, align 8
  %v3583 = load i64, ptr %slot560, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  %rgep3585 = getelementptr i8, ptr %p3584, i64 -16
  %ld3586 = load i64, ptr %rgep3585, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3586, ptr %slot563, align 8
  %v3587 = load i64, ptr %slot563, align 8
  %op3588 = and i64 %v3587, 6917529027641081858
  store i64 %op3588, ptr %slot564, align 8
  %v3589 = load i64, ptr %slot564, align 8
  %cmp3590 = icmp ne i64 %v3589, 0
  %cv3591 = zext i1 %cmp3590 to i32
  store i32 %cv3591, ptr %slot565, align 8
  %v3592 = load i32, ptr %slot565, align 8
  %cv3593 = zext i32 %v3592 to i64
  %cond3594 = icmp ne i64 %cv3593, 0
  br i1 %cond3594, label %bb_rcguniqueslow711, label %bb_rcguniquecount711
bb_rcguniquecount711:
  %v3595 = load i64, ptr %slot560, align 8
  %op3596 = sub i64 %v3595, 32
  store i64 %op3596, ptr %slot566, align 8
  %v3597 = load i64, ptr %slot560, align 8
  %p3598 = inttoptr i64 %v3597 to ptr
  %rgep3599 = getelementptr i8, ptr %p3598, i64 -32
  %ld3600 = load i64, ptr %rgep3599, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3600, ptr %slot567, align 8
  %v3601 = load i64, ptr %slot567, align 8
  %cmp3602 = icmp ult i64 %v3601, 2
  %cv3603 = zext i1 %cmp3602 to i32
  store i32 %cv3603, ptr %slot568, align 8
  %v3604 = load i32, ptr %slot568, align 8
  %cv3605 = zext i32 %v3604 to i64
  %cond3606 = icmp ne i64 %cv3605, 0
  br i1 %cond3606, label %bb_rcgunique711, label %bb_rcguniqueslow711
bb_rcguniqueslow711:
  %v3607 = load i64, ptr %slot1, align 8
  %p3608 = inttoptr i64 %v3607 to ptr
  %p3609 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v3610 = load i64, ptr %slot503, align 8
  %p3611 = inttoptr i64 %v3610 to ptr
  %v3612 = load i64, ptr %slot7, align 8
  %p3613 = inttoptr i64 %v3612 to ptr
  %call3614 = call i32 @myl_qbe_rc_unique_local(ptr %p3608, ptr %p3609, ptr %p3611, ptr %p3613) nomerge, !dbg !126
  store i32 %call3614, ptr %slot569, align 8
  %v3615 = load i32, ptr %slot569, align 8
  %cv3616 = zext i32 %v3615 to i64
  %cond3617 = icmp ne i64 %cv3616, 0
  br i1 %cond3617, label %bb_rcunique722, label %bb_failure
bb_rcunique722:
  br label %bb_rcgunique711
bb_rcgunique711:
  %v3618 = load i64, ptr %slot25, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  %ld3620 = load i64, ptr %p3619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3620, ptr %slot570, align 8
  %v3621 = load i64, ptr %slot30, align 8
  store i64 %v3621, ptr %slot571, align 8
  %v3622 = load i64, ptr %slot571, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  %ld3624 = load i64, ptr %p3623, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3624, ptr %slot572, align 8
  %v3625 = load i64, ptr %slot572, align 8
  %v3626 = load i64, ptr %slot20, align 8
  %p3627 = inttoptr i64 %v3626 to ptr
  store i64 %v3625, ptr %p3627, align 8, !alias.scope !3, !noalias !4
  %v3628 = load i64, ptr %slot20, align 8
  store i64 %v3628, ptr %slot573, align 8
  %v3629 = load i64, ptr %slot35, align 8
  %v3630 = load i64, ptr %slot570, align 8
  %v3631 = load i64, ptr %slot573, align 8
  %call3632 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v3629, i64 %v3630, i64 %v3631) nomerge, !dbg !126
  store i32 %call3632, ptr %slot574, align 8
  %v3633 = load i32, ptr %slot574, align 8
  %cv3634 = zext i32 %v3633 to i64
  %cond3635 = icmp ne i64 %cv3634, 0
  br i1 %cond3635, label %bb_success728, label %bb_failed728
bb_failed728:
  %v3636 = load i64, ptr %slot1, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3637) nomerge, !dbg !126
  unreachable
bb_success728:
  %v3638 = load i64, ptr %slot30, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  store i64 0, ptr %p3639, align 8, !alias.scope !3, !noalias !4
  %v3640 = load i64, ptr %slot13, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %ld3642 = load i32, ptr %p3641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3642, ptr %slot575, align 8
  %v3643 = load i32, ptr %slot575, align 8
  %cv3644 = zext i32 %v3643 to i64
  %cond3645 = icmp ne i64 %cv3644, 0
  br i1 %cond3645, label %bb_rcslotdrop731, label %bb_rcslotdone731
bb_rcslotdrop731:
  %v3646 = load i64, ptr %slot13, align 8
  %p3647 = inttoptr i64 %v3646 to ptr
  store i32 0, ptr %p3647, align 4, !alias.scope !3, !noalias !4
  %v3648 = load i64, ptr %slot17, align 8
  store i64 %v3648, ptr %slot576, align 8
  %v3649 = load i64, ptr %slot14, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  %ld3651 = load i32, ptr %p3650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3651, ptr %slot577, align 8
  %v3652 = load i32, ptr %slot577, align 8
  %op3653 = and i32 %v3652, 28
  store i32 %op3653, ptr %slot578, align 8
  %v3654 = load i32, ptr %slot578, align 8
  %cv3655 = zext i32 %v3654 to i64
  %cond3656 = icmp ne i64 %cv3655, 0
  br i1 %cond3656, label %bb_rcslotrole731, label %bb_rcslotowner731
bb_rcslotrole731:
  %v3657 = load i64, ptr %slot35, align 8
  store i64 %v3657, ptr %slot579, align 8
  %v3658 = load i64, ptr %slot576, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  %ld3660 = load i64, ptr %p3659, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3660, ptr %slot580, align 8
  %v3661 = load i64, ptr %slot580, align 8
  %cmp3662 = icmp ne i64 %v3661, 0
  %cv3663 = zext i1 %cmp3662 to i32
  store i32 %cv3663, ptr %slot581, align 8
  %v3664 = load i32, ptr %slot581, align 8
  %cv3665 = zext i32 %v3664 to i64
  %cond3666 = icmp ne i64 %cv3665, 0
  br i1 %cond3666, label %bb_rcgnn747, label %bb_rcgdone747
bb_rcgnn747:
  %v3667 = load i64, ptr %slot580, align 8
  %op3668 = sub i64 %v3667, 16
  store i64 %op3668, ptr %slot582, align 8
  %v3669 = load i64, ptr %slot580, align 8
  %p3670 = inttoptr i64 %v3669 to ptr
  %rgep3671 = getelementptr i8, ptr %p3670, i64 -16
  %ld3672 = load i64, ptr %rgep3671, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3672, ptr %slot583, align 8
  %v3673 = load i64, ptr %slot583, align 8
  %op3674 = and i64 %v3673, 4611686018427387906
  store i64 %op3674, ptr %slot584, align 8
  %v3675 = load i64, ptr %slot584, align 8
  %cmp3676 = icmp ne i64 %v3675, 0
  %cv3677 = zext i1 %cmp3676 to i32
  store i32 %cv3677, ptr %slot585, align 8
  %v3678 = load i32, ptr %slot585, align 8
  %cv3679 = zext i32 %v3678 to i64
  %cond3680 = icmp ne i64 %cv3679, 0
  br i1 %cond3680, label %bb_rcgclear747, label %bb_rcgcounted747
bb_rcgcounted747:
  %v3681 = load i64, ptr %slot580, align 8
  %op3682 = sub i64 %v3681, 24
  store i64 %op3682, ptr %slot586, align 8
  %v3683 = load i64, ptr %slot580, align 8
  %p3684 = inttoptr i64 %v3683 to ptr
  %rgep3685 = getelementptr i8, ptr %p3684, i64 -24
  %ld3686 = load i64, ptr %rgep3685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3686, ptr %slot587, align 8
  %v3687 = load i64, ptr %slot587, align 8
  %op3688 = sub i64 %v3687, 1
  store i64 %op3688, ptr %slot588, align 8
  %v3689 = load i64, ptr %slot588, align 8
  %cmp3690 = icmp eq i64 %v3689, 0
  %cv3691 = zext i1 %cmp3690 to i32
  store i32 %cv3691, ptr %slot589, align 8
  %v3692 = load i32, ptr %slot589, align 8
  %cv3693 = zext i32 %v3692 to i64
  %cond3694 = icmp ne i64 %cv3693, 0
  br i1 %cond3694, label %bb_rcglast747, label %bb_rcgdec747
bb_rcglast747:
  %v3695 = load i64, ptr %slot580, align 8
  %op3696 = sub i64 %v3695, 32
  store i64 %op3696, ptr %slot590, align 8
  %v3697 = load i64, ptr %slot580, align 8
  %p3698 = inttoptr i64 %v3697 to ptr
  %rgep3699 = getelementptr i8, ptr %p3698, i64 -32
  %ld3700 = load i64, ptr %rgep3699, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3700, ptr %slot591, align 8
  %v3701 = load i64, ptr %slot591, align 8
  %cmp3702 = icmp ne i64 %v3701, 0
  %cv3703 = zext i1 %cmp3702 to i32
  store i32 %cv3703, ptr %slot592, align 8
  %v3704 = load i32, ptr %slot592, align 8
  %cv3705 = zext i32 %v3704 to i64
  %cond3706 = icmp ne i64 %cv3705, 0
  br i1 %cond3706, label %bb_rcgdec747, label %bb_rcgslow747
bb_rcgslow747:
  %v3707 = load i64, ptr %slot579, align 8
  %v3708 = load i64, ptr %slot576, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v3707, i64 %v3708) nomerge, !dbg !126
  br label %bb_rcgdone747
bb_rcgdec747:
  %v3709 = load i64, ptr %slot588, align 8
  %v3710 = load i64, ptr %slot580, align 8
  %p3711 = inttoptr i64 %v3710 to ptr
  %rgep3712 = getelementptr i8, ptr %p3711, i64 -24
  store i64 %v3709, ptr %rgep3712, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear747
bb_rcgclear747:
  %v3713 = load i64, ptr %slot576, align 8
  %p3714 = inttoptr i64 %v3713 to ptr
  store i64 0, ptr %p3714, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone747
bb_rcgdone747:
  br label %bb_rcslotdone731
bb_rcslotowner731:
  %v3715 = load i64, ptr %slot35, align 8
  store i64 %v3715, ptr %slot593, align 8
  %v3716 = load i64, ptr %slot576, align 8
  %p3717 = inttoptr i64 %v3716 to ptr
  %ld3718 = load i64, ptr %p3717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3718, ptr %slot594, align 8
  %v3719 = load i64, ptr %slot594, align 8
  %cmp3720 = icmp ne i64 %v3719, 0
  %cv3721 = zext i1 %cmp3720 to i32
  store i32 %cv3721, ptr %slot595, align 8
  %v3722 = load i32, ptr %slot595, align 8
  %cv3723 = zext i32 %v3722 to i64
  %cond3724 = icmp ne i64 %cv3723, 0
  br i1 %cond3724, label %bb_rcgnn762, label %bb_rcgdone762
bb_rcgnn762:
  %v3725 = load i64, ptr %slot594, align 8
  %op3726 = sub i64 %v3725, 16
  store i64 %op3726, ptr %slot596, align 8
  %v3727 = load i64, ptr %slot594, align 8
  %p3728 = inttoptr i64 %v3727 to ptr
  %rgep3729 = getelementptr i8, ptr %p3728, i64 -16
  %ld3730 = load i64, ptr %rgep3729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3730, ptr %slot597, align 8
  %v3731 = load i64, ptr %slot597, align 8
  %op3732 = and i64 %v3731, 4611686018427387906
  store i64 %op3732, ptr %slot598, align 8
  %v3733 = load i64, ptr %slot598, align 8
  %cmp3734 = icmp ne i64 %v3733, 0
  %cv3735 = zext i1 %cmp3734 to i32
  store i32 %cv3735, ptr %slot599, align 8
  %v3736 = load i32, ptr %slot599, align 8
  %cv3737 = zext i32 %v3736 to i64
  %cond3738 = icmp ne i64 %cv3737, 0
  br i1 %cond3738, label %bb_rcgclear762, label %bb_rcgcounted762
bb_rcgcounted762:
  %v3739 = load i64, ptr %slot594, align 8
  %op3740 = sub i64 %v3739, 32
  store i64 %op3740, ptr %slot600, align 8
  %v3741 = load i64, ptr %slot594, align 8
  %p3742 = inttoptr i64 %v3741 to ptr
  %rgep3743 = getelementptr i8, ptr %p3742, i64 -32
  %ld3744 = load i64, ptr %rgep3743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3744, ptr %slot601, align 8
  %v3745 = load i64, ptr %slot601, align 8
  %op3746 = sub i64 %v3745, 1
  store i64 %op3746, ptr %slot602, align 8
  %v3747 = load i64, ptr %slot602, align 8
  %cmp3748 = icmp eq i64 %v3747, 0
  %cv3749 = zext i1 %cmp3748 to i32
  store i32 %cv3749, ptr %slot603, align 8
  %v3750 = load i32, ptr %slot603, align 8
  %cv3751 = zext i32 %v3750 to i64
  %cond3752 = icmp ne i64 %cv3751, 0
  br i1 %cond3752, label %bb_rcglast762, label %bb_rcgdec762
bb_rcglast762:
  %v3753 = load i64, ptr %slot594, align 8
  %op3754 = sub i64 %v3753, 24
  store i64 %op3754, ptr %slot604, align 8
  %v3755 = load i64, ptr %slot594, align 8
  %p3756 = inttoptr i64 %v3755 to ptr
  %rgep3757 = getelementptr i8, ptr %p3756, i64 -24
  %ld3758 = load i64, ptr %rgep3757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3758, ptr %slot605, align 8
  %v3759 = load i64, ptr %slot605, align 8
  %cmp3760 = icmp ne i64 %v3759, 0
  %cv3761 = zext i1 %cmp3760 to i32
  store i32 %cv3761, ptr %slot606, align 8
  %v3762 = load i32, ptr %slot606, align 8
  %cv3763 = zext i32 %v3762 to i64
  %cond3764 = icmp ne i64 %cv3763, 0
  br i1 %cond3764, label %bb_rcgdec762, label %bb_rcgslow762
bb_rcgslow762:
  %v3765 = load i64, ptr %slot593, align 8
  %v3766 = load i64, ptr %slot576, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v3765, i64 %v3766) nomerge, !dbg !126
  br label %bb_rcgdone762
bb_rcgdec762:
  %v3767 = load i64, ptr %slot602, align 8
  %v3768 = load i64, ptr %slot594, align 8
  %p3769 = inttoptr i64 %v3768 to ptr
  %rgep3770 = getelementptr i8, ptr %p3769, i64 -32
  store i64 %v3767, ptr %rgep3770, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear762
bb_rcgclear762:
  %v3771 = load i64, ptr %slot576, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  store i64 0, ptr %p3772, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone762
bb_rcgdone762:
  br label %bb_rcslotdone731
bb_rcslotdone731:
  %v3773 = load i64, ptr %slot24, align 8
  %p3774 = inttoptr i64 %v3773 to ptr
  %ld3775 = load i64, ptr %p3774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3775, ptr %slot607, align 8
  %v3776 = load i64, ptr %slot607, align 8
  %v3777 = load i64, ptr %slot30, align 8
  %p3778 = inttoptr i64 %v3777 to ptr
  store i64 %v3776, ptr %p3778, align 8, !alias.scope !3, !noalias !4
  %v3779 = load i64, ptr %slot30, align 8
  %p3780 = inttoptr i64 %v3779 to ptr
  %ld3781 = load i64, ptr %p3780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3781, ptr %slot608, align 8
  %v3782 = load i64, ptr %slot35, align 8
  %p3783 = inttoptr i64 %v3782 to ptr
  %v3784 = load i64, ptr %slot608, align 8
  %p3785 = inttoptr i64 %v3784 to ptr
  %call3786 = call ptr @myl_native_text_scalar(ptr %p3783, ptr %p3785, i32 0) nomerge, !dbg !128
  %calladdr3787 = ptrtoint ptr %call3786 to i64
  store i64 %calladdr3787, ptr %slot609, align 8
  %v3788 = load i64, ptr %slot609, align 8
  %cond3789 = icmp ne i64 %v3788, 0
  br i1 %cond3789, label %bb_success769, label %bb_failed769
bb_failed769:
  %v3790 = load i64, ptr %slot1, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3791) nomerge, !dbg !128
  unreachable
bb_success769:
  %v3792 = load i64, ptr %slot609, align 8
  %v3793 = load i64, ptr %slot30, align 8
  %p3794 = inttoptr i64 %v3793 to ptr
  store i64 %v3792, ptr %p3794, align 8, !alias.scope !3, !noalias !4
  %v3795 = load i64, ptr %slot30, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  %ld3797 = load i64, ptr %p3796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3797, ptr %slot610, align 8
  %v3798 = load i64, ptr %slot610, align 8
  %v3799 = load i64, ptr %slot18, align 8
  %p3800 = inttoptr i64 %v3799 to ptr
  store i64 %v3798, ptr %p3800, align 8, !alias.scope !3, !noalias !4
  %v3801 = load i64, ptr %slot18, align 8
  store i64 %v3801, ptr %slot611, align 8
  %v3802 = load i64, ptr %slot19, align 8
  store i64 %v3802, ptr %slot612, align 8
  %v3803 = load i64, ptr %slot611, align 8
  %v3804 = load i64, ptr %slot612, align 8
  %p3805 = inttoptr i64 %v3803 to ptr
  %p3806 = inttoptr i64 %v3804 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3806, ptr %p3805, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3807 = load i64, ptr %slot16, align 8
  %p3808 = inttoptr i64 %v3807 to ptr
  store i32 2, ptr %p3808, align 4, !alias.scope !3, !noalias !4
  %v3809 = load i64, ptr %slot15, align 8
  %p3810 = inttoptr i64 %v3809 to ptr
  store i32 1, ptr %p3810, align 4, !alias.scope !3, !noalias !4
  %v3811 = load i64, ptr %slot17, align 8
  store i64 %v3811, ptr %slot613, align 8
  %v3812 = load i64, ptr %slot19, align 8
  store i64 %v3812, ptr %slot614, align 8
  %v3813 = load i64, ptr %slot614, align 8
  %v3814 = load i64, ptr %slot613, align 8
  %p3815 = inttoptr i64 %v3813 to ptr
  %p3816 = inttoptr i64 %v3814 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3816, ptr %p3815, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3817 = load i64, ptr %slot14, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  store i32 2, ptr %p3818, align 4, !alias.scope !3, !noalias !4
  %v3819 = load i64, ptr %slot16, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %ld3821 = load i32, ptr %p3820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3821, ptr %slot615, align 8
  %v3822 = load i32, ptr %slot615, align 8
  %v3823 = load i64, ptr %slot14, align 8
  %p3824 = inttoptr i64 %v3823 to ptr
  store i32 %v3822, ptr %p3824, align 4, !alias.scope !3, !noalias !4
  %v3825 = load i64, ptr %slot15, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  store i32 0, ptr %p3826, align 4, !alias.scope !3, !noalias !4
  %v3827 = load i64, ptr %slot13, align 8
  %p3828 = inttoptr i64 %v3827 to ptr
  store i32 1, ptr %p3828, align 4, !alias.scope !3, !noalias !4
  %v3829 = load i64, ptr %slot613, align 8
  %p3830 = inttoptr i64 %v3829 to ptr
  %ld3831 = load i64, ptr %p3830, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3831, ptr %slot616, align 8
  %v3832 = load i64, ptr %slot616, align 8
  %v3833 = load i64, ptr %slot30, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  store i64 %v3832, ptr %p3834, align 8, !alias.scope !3, !noalias !4
  %v3835 = load i64, ptr %slot25, align 8
  store i64 %v3835, ptr %slot617, align 8
  %v3836 = load i64, ptr %slot8, align 8
  %p3837 = inttoptr i64 %v3836 to ptr
  %ld3838 = load i32, ptr %p3837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3838, ptr %slot618, align 8
  %v3839 = load i32, ptr %slot618, align 8
  %cmp3840 = icmp eq i32 %v3839, 16
  %cv3841 = zext i1 %cmp3840 to i32
  store i32 %cv3841, ptr %slot619, align 8
  %v3842 = load i64, ptr %slot7, align 8
  %p3843 = inttoptr i64 %v3842 to ptr
  %ld3844 = load i32, ptr %p3843, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3844, ptr %slot620, align 8
  %v3845 = load i32, ptr %slot620, align 8
  %v3846 = load i32, ptr %slot619, align 8
  %op3847 = and i32 %v3845, %v3846
  store i32 %op3847, ptr %slot621, align 8
  %v3848 = load i32, ptr %slot621, align 8
  %cv3849 = zext i32 %v3848 to i64
  %cond3850 = icmp ne i64 %cv3849, 0
  br i1 %cond3850, label %bb_rcownlocal790, label %bb_rcownedlocal790
bb_rcownlocal790:
  %v3851 = load i64, ptr %slot25, align 8
  store i64 %v3851, ptr %slot622, align 8
  %v3852 = load i64, ptr %slot19, align 8
  store i64 %v3852, ptr %slot623, align 8
  %v3853 = load i64, ptr %slot36, align 8
  store i64 %v3853, ptr %slot624, align 8
  %v3854 = load i64, ptr %slot622, align 8
  %p3855 = inttoptr i64 %v3854 to ptr
  %ld3856 = load i64, ptr %p3855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3856, ptr %slot625, align 8
  %v3857 = load i64, ptr %slot625, align 8
  %cmp3858 = icmp ne i64 %v3857, 0
  %cv3859 = zext i1 %cmp3858 to i32
  store i32 %cv3859, ptr %slot626, align 8
  %v3860 = load i32, ptr %slot626, align 8
  %cv3861 = zext i32 %v3860 to i64
  %cond3862 = icmp ne i64 %cv3861, 0
  br i1 %cond3862, label %bb_rcgnn797, label %bb_rcgplain797
bb_rcgnn797:
  %v3863 = load i64, ptr %slot625, align 8
  %op3864 = sub i64 %v3863, 16
  store i64 %op3864, ptr %slot627, align 8
  %v3865 = load i64, ptr %slot625, align 8
  %p3866 = inttoptr i64 %v3865 to ptr
  %rgep3867 = getelementptr i8, ptr %p3866, i64 -16
  %ld3868 = load i64, ptr %rgep3867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3868, ptr %slot628, align 8
  %v3869 = load i64, ptr %slot628, align 8
  %op3870 = and i64 %v3869, 4611686018427387906
  store i64 %op3870, ptr %slot629, align 8
  %v3871 = load i64, ptr %slot629, align 8
  %cmp3872 = icmp ne i64 %v3871, 0
  %cv3873 = zext i1 %cmp3872 to i32
  store i32 %cv3873, ptr %slot630, align 8
  %v3874 = load i32, ptr %slot630, align 8
  %cv3875 = zext i32 %v3874 to i64
  %cond3876 = icmp ne i64 %cv3875, 0
  br i1 %cond3876, label %bb_rcgspecial797, label %bb_rcginc797
bb_rcginc797:
  %v3877 = load i64, ptr %slot625, align 8
  %op3878 = sub i64 %v3877, 32
  store i64 %op3878, ptr %slot631, align 8
  %v3879 = load i64, ptr %slot625, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %rgep3881 = getelementptr i8, ptr %p3880, i64 -32
  %ld3882 = load i64, ptr %rgep3881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3882, ptr %slot632, align 8
  %v3883 = load i64, ptr %slot632, align 8
  %op3884 = add i64 %v3883, 1
  store i64 %op3884, ptr %slot633, align 8
  %v3885 = load i64, ptr %slot633, align 8
  %cmp3886 = icmp eq i64 %v3885, 0
  %cv3887 = zext i1 %cmp3886 to i32
  store i32 %cv3887, ptr %slot634, align 8
  %v3888 = load i32, ptr %slot634, align 8
  %cv3889 = zext i32 %v3888 to i64
  %cond3890 = icmp ne i64 %cv3889, 0
  br i1 %cond3890, label %bb_rcglimit797, label %bb_rcgcapacity797
bb_rcglimit797:
  %v3891 = load i64, ptr %slot1, align 8
  %p3892 = inttoptr i64 %v3891 to ptr
  %call3893 = call i32 @myl_qbe_rc_status(ptr %p3892, i32 2) nomerge, !dbg !130
  store i32 %call3893, ptr %slot635, align 8
  br label %bb_failure
bb_rcgcapacity797:
  %v3894 = load i64, ptr %slot633, align 8
  %v3895 = load i64, ptr %slot625, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  %rgep3897 = getelementptr i8, ptr %p3896, i64 -32
  store i64 %v3894, ptr %rgep3897, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain797
bb_rcgspecial797:
  %v3898 = load i64, ptr %slot628, align 8
  %op3899 = and i64 %v3898, 4611686018427387904
  store i64 %op3899, ptr %slot636, align 8
  %v3900 = load i64, ptr %slot636, align 8
  %cmp3901 = icmp ne i64 %v3900, 0
  %cv3902 = zext i1 %cmp3901 to i32
  store i32 %cv3902, ptr %slot637, align 8
  %v3903 = load i32, ptr %slot637, align 8
  %cv3904 = zext i32 %v3903 to i64
  %cond3905 = icmp ne i64 %cv3904, 0
  br i1 %cond3905, label %bb_rcgslow797, label %bb_rcgplain797
bb_rcgslow797:
  %v3906 = load i64, ptr %slot35, align 8
  %v3907 = load i64, ptr %slot623, align 8
  %v3908 = load i64, ptr %slot622, align 8
  %v3909 = load i64, ptr %slot624, align 8
  %cv3910 = trunc i64 %v3909 to i32
  %call3911 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v3906, i64 %v3907, i64 %v3908, i32 %cv3910) nomerge, !dbg !130
  store i32 %call3911, ptr %slot638, align 8
  %v3912 = load i32, ptr %slot638, align 8
  %cv3913 = zext i32 %v3912 to i64
  %cond3914 = icmp ne i64 %cv3913, 0
  br i1 %cond3914, label %bb_rcsuccess811, label %bb_rcfailure811
bb_rcfailure811:
  %v3915 = load i64, ptr %slot35, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  %call3917 = call i32 @myl_rc_take_failure(ptr %p3916) nomerge, !dbg !130
  store i32 %call3917, ptr %slot639, align 8
  %v3918 = load i64, ptr %slot1, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  %v3920 = load i32, ptr %slot639, align 8
  %call3921 = call i32 @myl_qbe_rc_status(ptr %p3919, i32 %v3920) nomerge, !dbg !130
  store i32 %call3921, ptr %slot640, align 8
  br label %bb_failure
bb_rcsuccess811:
  br label %bb_rcgdone797
bb_rcgplain797:
  %v3922 = load i64, ptr %slot625, align 8
  %v3923 = load i64, ptr %slot623, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  store i64 %v3922, ptr %p3924, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone797
bb_rcgdone797:
  %v3925 = load i64, ptr %slot16, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  store i32 2, ptr %p3926, align 4, !alias.scope !3, !noalias !4
  %v3927 = load i64, ptr %slot15, align 8
  %p3928 = inttoptr i64 %v3927 to ptr
  store i32 1, ptr %p3928, align 4, !alias.scope !3, !noalias !4
  %v3929 = load i64, ptr %slot7, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  %ld3931 = load i32, ptr %p3930, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3931, ptr %slot641, align 8
  %v3932 = load i32, ptr %slot641, align 8
  %cv3933 = zext i32 %v3932 to i64
  %cond3934 = icmp ne i64 %cv3933, 0
  br i1 %cond3934, label %bb_rcslotdrop818, label %bb_rcslotdone818
bb_rcslotdrop818:
  %v3935 = load i64, ptr %slot7, align 8
  %p3936 = inttoptr i64 %v3935 to ptr
  store i32 0, ptr %p3936, align 4, !alias.scope !3, !noalias !4
  %v3937 = load i64, ptr %slot25, align 8
  store i64 %v3937, ptr %slot642, align 8
  %v3938 = load i64, ptr %slot8, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  %ld3940 = load i32, ptr %p3939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3940, ptr %slot643, align 8
  %v3941 = load i32, ptr %slot643, align 8
  %op3942 = and i32 %v3941, 28
  store i32 %op3942, ptr %slot644, align 8
  %v3943 = load i32, ptr %slot644, align 8
  %cv3944 = zext i32 %v3943 to i64
  %cond3945 = icmp ne i64 %cv3944, 0
  br i1 %cond3945, label %bb_rcslotrole818, label %bb_rcslotowner818
bb_rcslotrole818:
  %v3946 = load i64, ptr %slot35, align 8
  store i64 %v3946, ptr %slot645, align 8
  %v3947 = load i64, ptr %slot642, align 8
  %p3948 = inttoptr i64 %v3947 to ptr
  %ld3949 = load i64, ptr %p3948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3949, ptr %slot646, align 8
  %v3950 = load i64, ptr %slot646, align 8
  %cmp3951 = icmp ne i64 %v3950, 0
  %cv3952 = zext i1 %cmp3951 to i32
  store i32 %cv3952, ptr %slot647, align 8
  %v3953 = load i32, ptr %slot647, align 8
  %cv3954 = zext i32 %v3953 to i64
  %cond3955 = icmp ne i64 %cv3954, 0
  br i1 %cond3955, label %bb_rcgnn834, label %bb_rcgdone834
bb_rcgnn834:
  %v3956 = load i64, ptr %slot646, align 8
  %op3957 = sub i64 %v3956, 16
  store i64 %op3957, ptr %slot648, align 8
  %v3958 = load i64, ptr %slot646, align 8
  %p3959 = inttoptr i64 %v3958 to ptr
  %rgep3960 = getelementptr i8, ptr %p3959, i64 -16
  %ld3961 = load i64, ptr %rgep3960, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3961, ptr %slot649, align 8
  %v3962 = load i64, ptr %slot649, align 8
  %op3963 = and i64 %v3962, 4611686018427387906
  store i64 %op3963, ptr %slot650, align 8
  %v3964 = load i64, ptr %slot650, align 8
  %cmp3965 = icmp ne i64 %v3964, 0
  %cv3966 = zext i1 %cmp3965 to i32
  store i32 %cv3966, ptr %slot651, align 8
  %v3967 = load i32, ptr %slot651, align 8
  %cv3968 = zext i32 %v3967 to i64
  %cond3969 = icmp ne i64 %cv3968, 0
  br i1 %cond3969, label %bb_rcgclear834, label %bb_rcgcounted834
bb_rcgcounted834:
  %v3970 = load i64, ptr %slot646, align 8
  %op3971 = sub i64 %v3970, 24
  store i64 %op3971, ptr %slot652, align 8
  %v3972 = load i64, ptr %slot646, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  %rgep3974 = getelementptr i8, ptr %p3973, i64 -24
  %ld3975 = load i64, ptr %rgep3974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3975, ptr %slot653, align 8
  %v3976 = load i64, ptr %slot653, align 8
  %op3977 = sub i64 %v3976, 1
  store i64 %op3977, ptr %slot654, align 8
  %v3978 = load i64, ptr %slot654, align 8
  %cmp3979 = icmp eq i64 %v3978, 0
  %cv3980 = zext i1 %cmp3979 to i32
  store i32 %cv3980, ptr %slot655, align 8
  %v3981 = load i32, ptr %slot655, align 8
  %cv3982 = zext i32 %v3981 to i64
  %cond3983 = icmp ne i64 %cv3982, 0
  br i1 %cond3983, label %bb_rcglast834, label %bb_rcgdec834
bb_rcglast834:
  %v3984 = load i64, ptr %slot646, align 8
  %op3985 = sub i64 %v3984, 32
  store i64 %op3985, ptr %slot656, align 8
  %v3986 = load i64, ptr %slot646, align 8
  %p3987 = inttoptr i64 %v3986 to ptr
  %rgep3988 = getelementptr i8, ptr %p3987, i64 -32
  %ld3989 = load i64, ptr %rgep3988, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3989, ptr %slot657, align 8
  %v3990 = load i64, ptr %slot657, align 8
  %cmp3991 = icmp ne i64 %v3990, 0
  %cv3992 = zext i1 %cmp3991 to i32
  store i32 %cv3992, ptr %slot658, align 8
  %v3993 = load i32, ptr %slot658, align 8
  %cv3994 = zext i32 %v3993 to i64
  %cond3995 = icmp ne i64 %cv3994, 0
  br i1 %cond3995, label %bb_rcgdec834, label %bb_rcgslow834
bb_rcgslow834:
  %v3996 = load i64, ptr %slot645, align 8
  %v3997 = load i64, ptr %slot642, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v3996, i64 %v3997) nomerge, !dbg !130
  br label %bb_rcgdone834
bb_rcgdec834:
  %v3998 = load i64, ptr %slot654, align 8
  %v3999 = load i64, ptr %slot646, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  %rgep4001 = getelementptr i8, ptr %p4000, i64 -24
  store i64 %v3998, ptr %rgep4001, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear834
bb_rcgclear834:
  %v4002 = load i64, ptr %slot642, align 8
  %p4003 = inttoptr i64 %v4002 to ptr
  store i64 0, ptr %p4003, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone834
bb_rcgdone834:
  br label %bb_rcslotdone818
bb_rcslotowner818:
  %v4004 = load i64, ptr %slot35, align 8
  store i64 %v4004, ptr %slot659, align 8
  %v4005 = load i64, ptr %slot642, align 8
  %p4006 = inttoptr i64 %v4005 to ptr
  %ld4007 = load i64, ptr %p4006, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4007, ptr %slot660, align 8
  %v4008 = load i64, ptr %slot660, align 8
  %cmp4009 = icmp ne i64 %v4008, 0
  %cv4010 = zext i1 %cmp4009 to i32
  store i32 %cv4010, ptr %slot661, align 8
  %v4011 = load i32, ptr %slot661, align 8
  %cv4012 = zext i32 %v4011 to i64
  %cond4013 = icmp ne i64 %cv4012, 0
  br i1 %cond4013, label %bb_rcgnn849, label %bb_rcgdone849
bb_rcgnn849:
  %v4014 = load i64, ptr %slot660, align 8
  %op4015 = sub i64 %v4014, 16
  store i64 %op4015, ptr %slot662, align 8
  %v4016 = load i64, ptr %slot660, align 8
  %p4017 = inttoptr i64 %v4016 to ptr
  %rgep4018 = getelementptr i8, ptr %p4017, i64 -16
  %ld4019 = load i64, ptr %rgep4018, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4019, ptr %slot663, align 8
  %v4020 = load i64, ptr %slot663, align 8
  %op4021 = and i64 %v4020, 4611686018427387906
  store i64 %op4021, ptr %slot664, align 8
  %v4022 = load i64, ptr %slot664, align 8
  %cmp4023 = icmp ne i64 %v4022, 0
  %cv4024 = zext i1 %cmp4023 to i32
  store i32 %cv4024, ptr %slot665, align 8
  %v4025 = load i32, ptr %slot665, align 8
  %cv4026 = zext i32 %v4025 to i64
  %cond4027 = icmp ne i64 %cv4026, 0
  br i1 %cond4027, label %bb_rcgclear849, label %bb_rcgcounted849
bb_rcgcounted849:
  %v4028 = load i64, ptr %slot660, align 8
  %op4029 = sub i64 %v4028, 32
  store i64 %op4029, ptr %slot666, align 8
  %v4030 = load i64, ptr %slot660, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  %rgep4032 = getelementptr i8, ptr %p4031, i64 -32
  %ld4033 = load i64, ptr %rgep4032, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4033, ptr %slot667, align 8
  %v4034 = load i64, ptr %slot667, align 8
  %op4035 = sub i64 %v4034, 1
  store i64 %op4035, ptr %slot668, align 8
  %v4036 = load i64, ptr %slot668, align 8
  %cmp4037 = icmp eq i64 %v4036, 0
  %cv4038 = zext i1 %cmp4037 to i32
  store i32 %cv4038, ptr %slot669, align 8
  %v4039 = load i32, ptr %slot669, align 8
  %cv4040 = zext i32 %v4039 to i64
  %cond4041 = icmp ne i64 %cv4040, 0
  br i1 %cond4041, label %bb_rcglast849, label %bb_rcgdec849
bb_rcglast849:
  %v4042 = load i64, ptr %slot660, align 8
  %op4043 = sub i64 %v4042, 24
  store i64 %op4043, ptr %slot670, align 8
  %v4044 = load i64, ptr %slot660, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  %rgep4046 = getelementptr i8, ptr %p4045, i64 -24
  %ld4047 = load i64, ptr %rgep4046, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4047, ptr %slot671, align 8
  %v4048 = load i64, ptr %slot671, align 8
  %cmp4049 = icmp ne i64 %v4048, 0
  %cv4050 = zext i1 %cmp4049 to i32
  store i32 %cv4050, ptr %slot672, align 8
  %v4051 = load i32, ptr %slot672, align 8
  %cv4052 = zext i32 %v4051 to i64
  %cond4053 = icmp ne i64 %cv4052, 0
  br i1 %cond4053, label %bb_rcgdec849, label %bb_rcgslow849
bb_rcgslow849:
  %v4054 = load i64, ptr %slot659, align 8
  %v4055 = load i64, ptr %slot642, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v4054, i64 %v4055) nomerge, !dbg !130
  br label %bb_rcgdone849
bb_rcgdec849:
  %v4056 = load i64, ptr %slot668, align 8
  %v4057 = load i64, ptr %slot660, align 8
  %p4058 = inttoptr i64 %v4057 to ptr
  %rgep4059 = getelementptr i8, ptr %p4058, i64 -32
  store i64 %v4056, ptr %rgep4059, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear849
bb_rcgclear849:
  %v4060 = load i64, ptr %slot642, align 8
  %p4061 = inttoptr i64 %v4060 to ptr
  store i64 0, ptr %p4061, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone849
bb_rcgdone849:
  br label %bb_rcslotdone818
bb_rcslotdone818:
  %v4062 = load i64, ptr %slot19, align 8
  store i64 %v4062, ptr %slot673, align 8
  %v4063 = load i64, ptr %slot673, align 8
  %v4064 = load i64, ptr %slot622, align 8
  %p4065 = inttoptr i64 %v4063 to ptr
  %p4066 = inttoptr i64 %v4064 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4066, ptr %p4065, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4067 = load i64, ptr %slot8, align 8
  %p4068 = inttoptr i64 %v4067 to ptr
  store i32 2, ptr %p4068, align 4, !alias.scope !3, !noalias !4
  %v4069 = load i64, ptr %slot7, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  store i32 1, ptr %p4070, align 4, !alias.scope !3, !noalias !4
  %v4071 = load i64, ptr %slot15, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  store i32 0, ptr %p4072, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal790
bb_rcownedlocal790:
  %v4073 = load i64, ptr %slot8, align 8
  %p4074 = inttoptr i64 %v4073 to ptr
  store i32 2, ptr %p4074, align 4, !alias.scope !3, !noalias !4
  %v4075 = load i64, ptr %slot617, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  %ld4077 = load i64, ptr %p4076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4077, ptr %slot674, align 8
  %v4078 = load i64, ptr %slot674, align 8
  %cmp4079 = icmp ne i64 %v4078, 0
  %cv4080 = zext i1 %cmp4079 to i32
  store i32 %cv4080, ptr %slot675, align 8
  %v4081 = load i32, ptr %slot675, align 8
  %cv4082 = zext i32 %v4081 to i64
  %cond4083 = icmp ne i64 %cv4082, 0
  br i1 %cond4083, label %bb_rcguniquenn858, label %bb_rcgunique858
bb_rcguniquenn858:
  %v4084 = load i64, ptr %slot674, align 8
  %op4085 = sub i64 %v4084, 16
  store i64 %op4085, ptr %slot676, align 8
  %v4086 = load i64, ptr %slot674, align 8
  %p4087 = inttoptr i64 %v4086 to ptr
  %rgep4088 = getelementptr i8, ptr %p4087, i64 -16
  %ld4089 = load i64, ptr %rgep4088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4089, ptr %slot677, align 8
  %v4090 = load i64, ptr %slot677, align 8
  %op4091 = and i64 %v4090, 6917529027641081858
  store i64 %op4091, ptr %slot678, align 8
  %v4092 = load i64, ptr %slot678, align 8
  %cmp4093 = icmp ne i64 %v4092, 0
  %cv4094 = zext i1 %cmp4093 to i32
  store i32 %cv4094, ptr %slot679, align 8
  %v4095 = load i32, ptr %slot679, align 8
  %cv4096 = zext i32 %v4095 to i64
  %cond4097 = icmp ne i64 %cv4096, 0
  br i1 %cond4097, label %bb_rcguniqueslow858, label %bb_rcguniquecount858
bb_rcguniquecount858:
  %v4098 = load i64, ptr %slot674, align 8
  %op4099 = sub i64 %v4098, 32
  store i64 %op4099, ptr %slot680, align 8
  %v4100 = load i64, ptr %slot674, align 8
  %p4101 = inttoptr i64 %v4100 to ptr
  %rgep4102 = getelementptr i8, ptr %p4101, i64 -32
  %ld4103 = load i64, ptr %rgep4102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4103, ptr %slot681, align 8
  %v4104 = load i64, ptr %slot681, align 8
  %cmp4105 = icmp ult i64 %v4104, 2
  %cv4106 = zext i1 %cmp4105 to i32
  store i32 %cv4106, ptr %slot682, align 8
  %v4107 = load i32, ptr %slot682, align 8
  %cv4108 = zext i32 %v4107 to i64
  %cond4109 = icmp ne i64 %cv4108, 0
  br i1 %cond4109, label %bb_rcgunique858, label %bb_rcguniqueslow858
bb_rcguniqueslow858:
  %v4110 = load i64, ptr %slot1, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  %p4112 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v4113 = load i64, ptr %slot617, align 8
  %p4114 = inttoptr i64 %v4113 to ptr
  %v4115 = load i64, ptr %slot7, align 8
  %p4116 = inttoptr i64 %v4115 to ptr
  %call4117 = call i32 @myl_qbe_rc_unique_local(ptr %p4111, ptr %p4112, ptr %p4114, ptr %p4116) nomerge, !dbg !130
  store i32 %call4117, ptr %slot683, align 8
  %v4118 = load i32, ptr %slot683, align 8
  %cv4119 = zext i32 %v4118 to i64
  %cond4120 = icmp ne i64 %cv4119, 0
  br i1 %cond4120, label %bb_rcunique869, label %bb_failure
bb_rcunique869:
  br label %bb_rcgunique858
bb_rcgunique858:
  %v4121 = load i64, ptr %slot25, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  %ld4123 = load i64, ptr %p4122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4123, ptr %slot684, align 8
  %v4124 = load i64, ptr %slot30, align 8
  store i64 %v4124, ptr %slot685, align 8
  %v4125 = load i64, ptr %slot685, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  %ld4127 = load i64, ptr %p4126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4127, ptr %slot686, align 8
  %v4128 = load i64, ptr %slot686, align 8
  %v4129 = load i64, ptr %slot20, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  store i64 %v4128, ptr %p4130, align 8, !alias.scope !3, !noalias !4
  %v4131 = load i64, ptr %slot20, align 8
  store i64 %v4131, ptr %slot687, align 8
  %v4132 = load i64, ptr %slot35, align 8
  %v4133 = load i64, ptr %slot684, align 8
  %v4134 = load i64, ptr %slot687, align 8
  %call4135 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v4132, i64 %v4133, i64 %v4134) nomerge, !dbg !130
  store i32 %call4135, ptr %slot688, align 8
  %v4136 = load i32, ptr %slot688, align 8
  %cv4137 = zext i32 %v4136 to i64
  %cond4138 = icmp ne i64 %cv4137, 0
  br i1 %cond4138, label %bb_success875, label %bb_failed875
bb_failed875:
  %v4139 = load i64, ptr %slot1, align 8
  %p4140 = inttoptr i64 %v4139 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4140) nomerge, !dbg !130
  unreachable
bb_success875:
  %v4141 = load i64, ptr %slot30, align 8
  %p4142 = inttoptr i64 %v4141 to ptr
  store i64 0, ptr %p4142, align 8, !alias.scope !3, !noalias !4
  %v4143 = load i64, ptr %slot13, align 8
  %p4144 = inttoptr i64 %v4143 to ptr
  %ld4145 = load i32, ptr %p4144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4145, ptr %slot689, align 8
  %v4146 = load i32, ptr %slot689, align 8
  %cv4147 = zext i32 %v4146 to i64
  %cond4148 = icmp ne i64 %cv4147, 0
  br i1 %cond4148, label %bb_rcslotdrop878, label %bb_rcslotdone878
bb_rcslotdrop878:
  %v4149 = load i64, ptr %slot13, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  store i32 0, ptr %p4150, align 4, !alias.scope !3, !noalias !4
  %v4151 = load i64, ptr %slot17, align 8
  store i64 %v4151, ptr %slot690, align 8
  %v4152 = load i64, ptr %slot14, align 8
  %p4153 = inttoptr i64 %v4152 to ptr
  %ld4154 = load i32, ptr %p4153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4154, ptr %slot691, align 8
  %v4155 = load i32, ptr %slot691, align 8
  %op4156 = and i32 %v4155, 28
  store i32 %op4156, ptr %slot692, align 8
  %v4157 = load i32, ptr %slot692, align 8
  %cv4158 = zext i32 %v4157 to i64
  %cond4159 = icmp ne i64 %cv4158, 0
  br i1 %cond4159, label %bb_rcslotrole878, label %bb_rcslotowner878
bb_rcslotrole878:
  %v4160 = load i64, ptr %slot35, align 8
  store i64 %v4160, ptr %slot693, align 8
  %v4161 = load i64, ptr %slot690, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %ld4163 = load i64, ptr %p4162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4163, ptr %slot694, align 8
  %v4164 = load i64, ptr %slot694, align 8
  %cmp4165 = icmp ne i64 %v4164, 0
  %cv4166 = zext i1 %cmp4165 to i32
  store i32 %cv4166, ptr %slot695, align 8
  %v4167 = load i32, ptr %slot695, align 8
  %cv4168 = zext i32 %v4167 to i64
  %cond4169 = icmp ne i64 %cv4168, 0
  br i1 %cond4169, label %bb_rcgnn894, label %bb_rcgdone894
bb_rcgnn894:
  %v4170 = load i64, ptr %slot694, align 8
  %op4171 = sub i64 %v4170, 16
  store i64 %op4171, ptr %slot696, align 8
  %v4172 = load i64, ptr %slot694, align 8
  %p4173 = inttoptr i64 %v4172 to ptr
  %rgep4174 = getelementptr i8, ptr %p4173, i64 -16
  %ld4175 = load i64, ptr %rgep4174, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4175, ptr %slot697, align 8
  %v4176 = load i64, ptr %slot697, align 8
  %op4177 = and i64 %v4176, 4611686018427387906
  store i64 %op4177, ptr %slot698, align 8
  %v4178 = load i64, ptr %slot698, align 8
  %cmp4179 = icmp ne i64 %v4178, 0
  %cv4180 = zext i1 %cmp4179 to i32
  store i32 %cv4180, ptr %slot699, align 8
  %v4181 = load i32, ptr %slot699, align 8
  %cv4182 = zext i32 %v4181 to i64
  %cond4183 = icmp ne i64 %cv4182, 0
  br i1 %cond4183, label %bb_rcgclear894, label %bb_rcgcounted894
bb_rcgcounted894:
  %v4184 = load i64, ptr %slot694, align 8
  %op4185 = sub i64 %v4184, 24
  store i64 %op4185, ptr %slot700, align 8
  %v4186 = load i64, ptr %slot694, align 8
  %p4187 = inttoptr i64 %v4186 to ptr
  %rgep4188 = getelementptr i8, ptr %p4187, i64 -24
  %ld4189 = load i64, ptr %rgep4188, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4189, ptr %slot701, align 8
  %v4190 = load i64, ptr %slot701, align 8
  %op4191 = sub i64 %v4190, 1
  store i64 %op4191, ptr %slot702, align 8
  %v4192 = load i64, ptr %slot702, align 8
  %cmp4193 = icmp eq i64 %v4192, 0
  %cv4194 = zext i1 %cmp4193 to i32
  store i32 %cv4194, ptr %slot703, align 8
  %v4195 = load i32, ptr %slot703, align 8
  %cv4196 = zext i32 %v4195 to i64
  %cond4197 = icmp ne i64 %cv4196, 0
  br i1 %cond4197, label %bb_rcglast894, label %bb_rcgdec894
bb_rcglast894:
  %v4198 = load i64, ptr %slot694, align 8
  %op4199 = sub i64 %v4198, 32
  store i64 %op4199, ptr %slot704, align 8
  %v4200 = load i64, ptr %slot694, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  %rgep4202 = getelementptr i8, ptr %p4201, i64 -32
  %ld4203 = load i64, ptr %rgep4202, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4203, ptr %slot705, align 8
  %v4204 = load i64, ptr %slot705, align 8
  %cmp4205 = icmp ne i64 %v4204, 0
  %cv4206 = zext i1 %cmp4205 to i32
  store i32 %cv4206, ptr %slot706, align 8
  %v4207 = load i32, ptr %slot706, align 8
  %cv4208 = zext i32 %v4207 to i64
  %cond4209 = icmp ne i64 %cv4208, 0
  br i1 %cond4209, label %bb_rcgdec894, label %bb_rcgslow894
bb_rcgslow894:
  %v4210 = load i64, ptr %slot693, align 8
  %v4211 = load i64, ptr %slot690, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v4210, i64 %v4211) nomerge, !dbg !130
  br label %bb_rcgdone894
bb_rcgdec894:
  %v4212 = load i64, ptr %slot702, align 8
  %v4213 = load i64, ptr %slot694, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  %rgep4215 = getelementptr i8, ptr %p4214, i64 -24
  store i64 %v4212, ptr %rgep4215, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear894
bb_rcgclear894:
  %v4216 = load i64, ptr %slot690, align 8
  %p4217 = inttoptr i64 %v4216 to ptr
  store i64 0, ptr %p4217, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone894
bb_rcgdone894:
  br label %bb_rcslotdone878
bb_rcslotowner878:
  %v4218 = load i64, ptr %slot35, align 8
  store i64 %v4218, ptr %slot707, align 8
  %v4219 = load i64, ptr %slot690, align 8
  %p4220 = inttoptr i64 %v4219 to ptr
  %ld4221 = load i64, ptr %p4220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4221, ptr %slot708, align 8
  %v4222 = load i64, ptr %slot708, align 8
  %cmp4223 = icmp ne i64 %v4222, 0
  %cv4224 = zext i1 %cmp4223 to i32
  store i32 %cv4224, ptr %slot709, align 8
  %v4225 = load i32, ptr %slot709, align 8
  %cv4226 = zext i32 %v4225 to i64
  %cond4227 = icmp ne i64 %cv4226, 0
  br i1 %cond4227, label %bb_rcgnn909, label %bb_rcgdone909
bb_rcgnn909:
  %v4228 = load i64, ptr %slot708, align 8
  %op4229 = sub i64 %v4228, 16
  store i64 %op4229, ptr %slot710, align 8
  %v4230 = load i64, ptr %slot708, align 8
  %p4231 = inttoptr i64 %v4230 to ptr
  %rgep4232 = getelementptr i8, ptr %p4231, i64 -16
  %ld4233 = load i64, ptr %rgep4232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4233, ptr %slot711, align 8
  %v4234 = load i64, ptr %slot711, align 8
  %op4235 = and i64 %v4234, 4611686018427387906
  store i64 %op4235, ptr %slot712, align 8
  %v4236 = load i64, ptr %slot712, align 8
  %cmp4237 = icmp ne i64 %v4236, 0
  %cv4238 = zext i1 %cmp4237 to i32
  store i32 %cv4238, ptr %slot713, align 8
  %v4239 = load i32, ptr %slot713, align 8
  %cv4240 = zext i32 %v4239 to i64
  %cond4241 = icmp ne i64 %cv4240, 0
  br i1 %cond4241, label %bb_rcgclear909, label %bb_rcgcounted909
bb_rcgcounted909:
  %v4242 = load i64, ptr %slot708, align 8
  %op4243 = sub i64 %v4242, 32
  store i64 %op4243, ptr %slot714, align 8
  %v4244 = load i64, ptr %slot708, align 8
  %p4245 = inttoptr i64 %v4244 to ptr
  %rgep4246 = getelementptr i8, ptr %p4245, i64 -32
  %ld4247 = load i64, ptr %rgep4246, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4247, ptr %slot715, align 8
  %v4248 = load i64, ptr %slot715, align 8
  %op4249 = sub i64 %v4248, 1
  store i64 %op4249, ptr %slot716, align 8
  %v4250 = load i64, ptr %slot716, align 8
  %cmp4251 = icmp eq i64 %v4250, 0
  %cv4252 = zext i1 %cmp4251 to i32
  store i32 %cv4252, ptr %slot717, align 8
  %v4253 = load i32, ptr %slot717, align 8
  %cv4254 = zext i32 %v4253 to i64
  %cond4255 = icmp ne i64 %cv4254, 0
  br i1 %cond4255, label %bb_rcglast909, label %bb_rcgdec909
bb_rcglast909:
  %v4256 = load i64, ptr %slot708, align 8
  %op4257 = sub i64 %v4256, 24
  store i64 %op4257, ptr %slot718, align 8
  %v4258 = load i64, ptr %slot708, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  %rgep4260 = getelementptr i8, ptr %p4259, i64 -24
  %ld4261 = load i64, ptr %rgep4260, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4261, ptr %slot719, align 8
  %v4262 = load i64, ptr %slot719, align 8
  %cmp4263 = icmp ne i64 %v4262, 0
  %cv4264 = zext i1 %cmp4263 to i32
  store i32 %cv4264, ptr %slot720, align 8
  %v4265 = load i32, ptr %slot720, align 8
  %cv4266 = zext i32 %v4265 to i64
  %cond4267 = icmp ne i64 %cv4266, 0
  br i1 %cond4267, label %bb_rcgdec909, label %bb_rcgslow909
bb_rcgslow909:
  %v4268 = load i64, ptr %slot707, align 8
  %v4269 = load i64, ptr %slot690, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v4268, i64 %v4269) nomerge, !dbg !130
  br label %bb_rcgdone909
bb_rcgdec909:
  %v4270 = load i64, ptr %slot716, align 8
  %v4271 = load i64, ptr %slot708, align 8
  %p4272 = inttoptr i64 %v4271 to ptr
  %rgep4273 = getelementptr i8, ptr %p4272, i64 -32
  store i64 %v4270, ptr %rgep4273, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear909
bb_rcgclear909:
  %v4274 = load i64, ptr %slot690, align 8
  %p4275 = inttoptr i64 %v4274 to ptr
  store i64 0, ptr %p4275, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone909
bb_rcgdone909:
  br label %bb_rcslotdone878
bb_rcslotdone878:
  %p4276 = inttoptr i64 ptrtoint (ptr @myl_lit_8d330aa2f416754a391eaf7715dfedb3b3b4f6f34dd9cc9ef16b81d95dfd3df3 to i64) to ptr
  %ld4277 = load i64, ptr %p4276, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4277, ptr %slot721, align 8
  %v4278 = load i64, ptr %slot721, align 8
  %v4279 = load i64, ptr %slot30, align 8
  %p4280 = inttoptr i64 %v4279 to ptr
  store i64 %v4278, ptr %p4280, align 8, !alias.scope !3, !noalias !4
  %v4281 = load i64, ptr %slot30, align 8
  %p4282 = inttoptr i64 %v4281 to ptr
  %ld4283 = load i64, ptr %p4282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4283, ptr %slot722, align 8
  %v4284 = load i64, ptr %slot722, align 8
  %v4285 = load i64, ptr %slot18, align 8
  %p4286 = inttoptr i64 %v4285 to ptr
  store i64 %v4284, ptr %p4286, align 8, !alias.scope !3, !noalias !4
  %v4287 = load i64, ptr %slot18, align 8
  store i64 %v4287, ptr %slot723, align 8
  %v4288 = load i64, ptr %slot19, align 8
  store i64 %v4288, ptr %slot724, align 8
  %v4289 = load i64, ptr %slot723, align 8
  %v4290 = load i64, ptr %slot724, align 8
  %p4291 = inttoptr i64 %v4289 to ptr
  %p4292 = inttoptr i64 %v4290 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4292, ptr %p4291, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4293 = load i64, ptr %slot16, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  store i32 2, ptr %p4294, align 4, !alias.scope !3, !noalias !4
  %v4295 = load i64, ptr %slot15, align 8
  %p4296 = inttoptr i64 %v4295 to ptr
  store i32 1, ptr %p4296, align 4, !alias.scope !3, !noalias !4
  %v4297 = load i64, ptr %slot17, align 8
  store i64 %v4297, ptr %slot725, align 8
  %v4298 = load i64, ptr %slot19, align 8
  store i64 %v4298, ptr %slot726, align 8
  %v4299 = load i64, ptr %slot726, align 8
  %v4300 = load i64, ptr %slot725, align 8
  %p4301 = inttoptr i64 %v4299 to ptr
  %p4302 = inttoptr i64 %v4300 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4302, ptr %p4301, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4303 = load i64, ptr %slot14, align 8
  %p4304 = inttoptr i64 %v4303 to ptr
  store i32 2, ptr %p4304, align 4, !alias.scope !3, !noalias !4
  %v4305 = load i64, ptr %slot16, align 8
  %p4306 = inttoptr i64 %v4305 to ptr
  %ld4307 = load i32, ptr %p4306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4307, ptr %slot727, align 8
  %v4308 = load i32, ptr %slot727, align 8
  %v4309 = load i64, ptr %slot14, align 8
  %p4310 = inttoptr i64 %v4309 to ptr
  store i32 %v4308, ptr %p4310, align 4, !alias.scope !3, !noalias !4
  %v4311 = load i64, ptr %slot15, align 8
  %p4312 = inttoptr i64 %v4311 to ptr
  store i32 0, ptr %p4312, align 4, !alias.scope !3, !noalias !4
  %v4313 = load i64, ptr %slot13, align 8
  %p4314 = inttoptr i64 %v4313 to ptr
  store i32 1, ptr %p4314, align 4, !alias.scope !3, !noalias !4
  %v4315 = load i64, ptr %slot725, align 8
  %p4316 = inttoptr i64 %v4315 to ptr
  %ld4317 = load i64, ptr %p4316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4317, ptr %slot728, align 8
  %v4318 = load i64, ptr %slot728, align 8
  %v4319 = load i64, ptr %slot30, align 8
  %p4320 = inttoptr i64 %v4319 to ptr
  store i64 %v4318, ptr %p4320, align 8, !alias.scope !3, !noalias !4
  %v4321 = load i64, ptr %slot25, align 8
  store i64 %v4321, ptr %slot729, align 8
  %v4322 = load i64, ptr %slot8, align 8
  %p4323 = inttoptr i64 %v4322 to ptr
  %ld4324 = load i32, ptr %p4323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4324, ptr %slot730, align 8
  %v4325 = load i32, ptr %slot730, align 8
  %cmp4326 = icmp eq i32 %v4325, 16
  %cv4327 = zext i1 %cmp4326 to i32
  store i32 %cv4327, ptr %slot731, align 8
  %v4328 = load i64, ptr %slot7, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  %ld4330 = load i32, ptr %p4329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4330, ptr %slot732, align 8
  %v4331 = load i32, ptr %slot732, align 8
  %v4332 = load i32, ptr %slot731, align 8
  %op4333 = and i32 %v4331, %v4332
  store i32 %op4333, ptr %slot733, align 8
  %v4334 = load i32, ptr %slot733, align 8
  %cv4335 = zext i32 %v4334 to i64
  %cond4336 = icmp ne i64 %cv4335, 0
  br i1 %cond4336, label %bb_rcownlocal935, label %bb_rcownedlocal935
bb_rcownlocal935:
  %v4337 = load i64, ptr %slot25, align 8
  store i64 %v4337, ptr %slot734, align 8
  %v4338 = load i64, ptr %slot19, align 8
  store i64 %v4338, ptr %slot735, align 8
  %v4339 = load i64, ptr %slot36, align 8
  store i64 %v4339, ptr %slot736, align 8
  %v4340 = load i64, ptr %slot734, align 8
  %p4341 = inttoptr i64 %v4340 to ptr
  %ld4342 = load i64, ptr %p4341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4342, ptr %slot737, align 8
  %v4343 = load i64, ptr %slot737, align 8
  %cmp4344 = icmp ne i64 %v4343, 0
  %cv4345 = zext i1 %cmp4344 to i32
  store i32 %cv4345, ptr %slot738, align 8
  %v4346 = load i32, ptr %slot738, align 8
  %cv4347 = zext i32 %v4346 to i64
  %cond4348 = icmp ne i64 %cv4347, 0
  br i1 %cond4348, label %bb_rcgnn942, label %bb_rcgplain942
bb_rcgnn942:
  %v4349 = load i64, ptr %slot737, align 8
  %op4350 = sub i64 %v4349, 16
  store i64 %op4350, ptr %slot739, align 8
  %v4351 = load i64, ptr %slot737, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  %rgep4353 = getelementptr i8, ptr %p4352, i64 -16
  %ld4354 = load i64, ptr %rgep4353, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4354, ptr %slot740, align 8
  %v4355 = load i64, ptr %slot740, align 8
  %op4356 = and i64 %v4355, 4611686018427387906
  store i64 %op4356, ptr %slot741, align 8
  %v4357 = load i64, ptr %slot741, align 8
  %cmp4358 = icmp ne i64 %v4357, 0
  %cv4359 = zext i1 %cmp4358 to i32
  store i32 %cv4359, ptr %slot742, align 8
  %v4360 = load i32, ptr %slot742, align 8
  %cv4361 = zext i32 %v4360 to i64
  %cond4362 = icmp ne i64 %cv4361, 0
  br i1 %cond4362, label %bb_rcgspecial942, label %bb_rcginc942
bb_rcginc942:
  %v4363 = load i64, ptr %slot737, align 8
  %op4364 = sub i64 %v4363, 32
  store i64 %op4364, ptr %slot743, align 8
  %v4365 = load i64, ptr %slot737, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  %rgep4367 = getelementptr i8, ptr %p4366, i64 -32
  %ld4368 = load i64, ptr %rgep4367, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4368, ptr %slot744, align 8
  %v4369 = load i64, ptr %slot744, align 8
  %op4370 = add i64 %v4369, 1
  store i64 %op4370, ptr %slot745, align 8
  %v4371 = load i64, ptr %slot745, align 8
  %cmp4372 = icmp eq i64 %v4371, 0
  %cv4373 = zext i1 %cmp4372 to i32
  store i32 %cv4373, ptr %slot746, align 8
  %v4374 = load i32, ptr %slot746, align 8
  %cv4375 = zext i32 %v4374 to i64
  %cond4376 = icmp ne i64 %cv4375, 0
  br i1 %cond4376, label %bb_rcglimit942, label %bb_rcgcapacity942
bb_rcglimit942:
  %v4377 = load i64, ptr %slot1, align 8
  %p4378 = inttoptr i64 %v4377 to ptr
  %call4379 = call i32 @myl_qbe_rc_status(ptr %p4378, i32 2) nomerge, !dbg !132
  store i32 %call4379, ptr %slot747, align 8
  br label %bb_failure
bb_rcgcapacity942:
  %v4380 = load i64, ptr %slot745, align 8
  %v4381 = load i64, ptr %slot737, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  %rgep4383 = getelementptr i8, ptr %p4382, i64 -32
  store i64 %v4380, ptr %rgep4383, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain942
bb_rcgspecial942:
  %v4384 = load i64, ptr %slot740, align 8
  %op4385 = and i64 %v4384, 4611686018427387904
  store i64 %op4385, ptr %slot748, align 8
  %v4386 = load i64, ptr %slot748, align 8
  %cmp4387 = icmp ne i64 %v4386, 0
  %cv4388 = zext i1 %cmp4387 to i32
  store i32 %cv4388, ptr %slot749, align 8
  %v4389 = load i32, ptr %slot749, align 8
  %cv4390 = zext i32 %v4389 to i64
  %cond4391 = icmp ne i64 %cv4390, 0
  br i1 %cond4391, label %bb_rcgslow942, label %bb_rcgplain942
bb_rcgslow942:
  %v4392 = load i64, ptr %slot35, align 8
  %v4393 = load i64, ptr %slot735, align 8
  %v4394 = load i64, ptr %slot734, align 8
  %v4395 = load i64, ptr %slot736, align 8
  %cv4396 = trunc i64 %v4395 to i32
  %call4397 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v4392, i64 %v4393, i64 %v4394, i32 %cv4396) nomerge, !dbg !132
  store i32 %call4397, ptr %slot750, align 8
  %v4398 = load i32, ptr %slot750, align 8
  %cv4399 = zext i32 %v4398 to i64
  %cond4400 = icmp ne i64 %cv4399, 0
  br i1 %cond4400, label %bb_rcsuccess956, label %bb_rcfailure956
bb_rcfailure956:
  %v4401 = load i64, ptr %slot35, align 8
  %p4402 = inttoptr i64 %v4401 to ptr
  %call4403 = call i32 @myl_rc_take_failure(ptr %p4402) nomerge, !dbg !132
  store i32 %call4403, ptr %slot751, align 8
  %v4404 = load i64, ptr %slot1, align 8
  %p4405 = inttoptr i64 %v4404 to ptr
  %v4406 = load i32, ptr %slot751, align 8
  %call4407 = call i32 @myl_qbe_rc_status(ptr %p4405, i32 %v4406) nomerge, !dbg !132
  store i32 %call4407, ptr %slot752, align 8
  br label %bb_failure
bb_rcsuccess956:
  br label %bb_rcgdone942
bb_rcgplain942:
  %v4408 = load i64, ptr %slot737, align 8
  %v4409 = load i64, ptr %slot735, align 8
  %p4410 = inttoptr i64 %v4409 to ptr
  store i64 %v4408, ptr %p4410, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone942
bb_rcgdone942:
  %v4411 = load i64, ptr %slot16, align 8
  %p4412 = inttoptr i64 %v4411 to ptr
  store i32 2, ptr %p4412, align 4, !alias.scope !3, !noalias !4
  %v4413 = load i64, ptr %slot15, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  store i32 1, ptr %p4414, align 4, !alias.scope !3, !noalias !4
  %v4415 = load i64, ptr %slot7, align 8
  %p4416 = inttoptr i64 %v4415 to ptr
  %ld4417 = load i32, ptr %p4416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4417, ptr %slot753, align 8
  %v4418 = load i32, ptr %slot753, align 8
  %cv4419 = zext i32 %v4418 to i64
  %cond4420 = icmp ne i64 %cv4419, 0
  br i1 %cond4420, label %bb_rcslotdrop963, label %bb_rcslotdone963
bb_rcslotdrop963:
  %v4421 = load i64, ptr %slot7, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  store i32 0, ptr %p4422, align 4, !alias.scope !3, !noalias !4
  %v4423 = load i64, ptr %slot25, align 8
  store i64 %v4423, ptr %slot754, align 8
  %v4424 = load i64, ptr %slot8, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  %ld4426 = load i32, ptr %p4425, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4426, ptr %slot755, align 8
  %v4427 = load i32, ptr %slot755, align 8
  %op4428 = and i32 %v4427, 28
  store i32 %op4428, ptr %slot756, align 8
  %v4429 = load i32, ptr %slot756, align 8
  %cv4430 = zext i32 %v4429 to i64
  %cond4431 = icmp ne i64 %cv4430, 0
  br i1 %cond4431, label %bb_rcslotrole963, label %bb_rcslotowner963
bb_rcslotrole963:
  %v4432 = load i64, ptr %slot35, align 8
  store i64 %v4432, ptr %slot757, align 8
  %v4433 = load i64, ptr %slot754, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  %ld4435 = load i64, ptr %p4434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4435, ptr %slot758, align 8
  %v4436 = load i64, ptr %slot758, align 8
  %cmp4437 = icmp ne i64 %v4436, 0
  %cv4438 = zext i1 %cmp4437 to i32
  store i32 %cv4438, ptr %slot759, align 8
  %v4439 = load i32, ptr %slot759, align 8
  %cv4440 = zext i32 %v4439 to i64
  %cond4441 = icmp ne i64 %cv4440, 0
  br i1 %cond4441, label %bb_rcgnn979, label %bb_rcgdone979
bb_rcgnn979:
  %v4442 = load i64, ptr %slot758, align 8
  %op4443 = sub i64 %v4442, 16
  store i64 %op4443, ptr %slot760, align 8
  %v4444 = load i64, ptr %slot758, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  %rgep4446 = getelementptr i8, ptr %p4445, i64 -16
  %ld4447 = load i64, ptr %rgep4446, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4447, ptr %slot761, align 8
  %v4448 = load i64, ptr %slot761, align 8
  %op4449 = and i64 %v4448, 4611686018427387906
  store i64 %op4449, ptr %slot762, align 8
  %v4450 = load i64, ptr %slot762, align 8
  %cmp4451 = icmp ne i64 %v4450, 0
  %cv4452 = zext i1 %cmp4451 to i32
  store i32 %cv4452, ptr %slot763, align 8
  %v4453 = load i32, ptr %slot763, align 8
  %cv4454 = zext i32 %v4453 to i64
  %cond4455 = icmp ne i64 %cv4454, 0
  br i1 %cond4455, label %bb_rcgclear979, label %bb_rcgcounted979
bb_rcgcounted979:
  %v4456 = load i64, ptr %slot758, align 8
  %op4457 = sub i64 %v4456, 24
  store i64 %op4457, ptr %slot764, align 8
  %v4458 = load i64, ptr %slot758, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  %rgep4460 = getelementptr i8, ptr %p4459, i64 -24
  %ld4461 = load i64, ptr %rgep4460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4461, ptr %slot765, align 8
  %v4462 = load i64, ptr %slot765, align 8
  %op4463 = sub i64 %v4462, 1
  store i64 %op4463, ptr %slot766, align 8
  %v4464 = load i64, ptr %slot766, align 8
  %cmp4465 = icmp eq i64 %v4464, 0
  %cv4466 = zext i1 %cmp4465 to i32
  store i32 %cv4466, ptr %slot767, align 8
  %v4467 = load i32, ptr %slot767, align 8
  %cv4468 = zext i32 %v4467 to i64
  %cond4469 = icmp ne i64 %cv4468, 0
  br i1 %cond4469, label %bb_rcglast979, label %bb_rcgdec979
bb_rcglast979:
  %v4470 = load i64, ptr %slot758, align 8
  %op4471 = sub i64 %v4470, 32
  store i64 %op4471, ptr %slot768, align 8
  %v4472 = load i64, ptr %slot758, align 8
  %p4473 = inttoptr i64 %v4472 to ptr
  %rgep4474 = getelementptr i8, ptr %p4473, i64 -32
  %ld4475 = load i64, ptr %rgep4474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4475, ptr %slot769, align 8
  %v4476 = load i64, ptr %slot769, align 8
  %cmp4477 = icmp ne i64 %v4476, 0
  %cv4478 = zext i1 %cmp4477 to i32
  store i32 %cv4478, ptr %slot770, align 8
  %v4479 = load i32, ptr %slot770, align 8
  %cv4480 = zext i32 %v4479 to i64
  %cond4481 = icmp ne i64 %cv4480, 0
  br i1 %cond4481, label %bb_rcgdec979, label %bb_rcgslow979
bb_rcgslow979:
  %v4482 = load i64, ptr %slot757, align 8
  %v4483 = load i64, ptr %slot754, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v4482, i64 %v4483) nomerge, !dbg !132
  br label %bb_rcgdone979
bb_rcgdec979:
  %v4484 = load i64, ptr %slot766, align 8
  %v4485 = load i64, ptr %slot758, align 8
  %p4486 = inttoptr i64 %v4485 to ptr
  %rgep4487 = getelementptr i8, ptr %p4486, i64 -24
  store i64 %v4484, ptr %rgep4487, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear979
bb_rcgclear979:
  %v4488 = load i64, ptr %slot754, align 8
  %p4489 = inttoptr i64 %v4488 to ptr
  store i64 0, ptr %p4489, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone979
bb_rcgdone979:
  br label %bb_rcslotdone963
bb_rcslotowner963:
  %v4490 = load i64, ptr %slot35, align 8
  store i64 %v4490, ptr %slot771, align 8
  %v4491 = load i64, ptr %slot754, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  %ld4493 = load i64, ptr %p4492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4493, ptr %slot772, align 8
  %v4494 = load i64, ptr %slot772, align 8
  %cmp4495 = icmp ne i64 %v4494, 0
  %cv4496 = zext i1 %cmp4495 to i32
  store i32 %cv4496, ptr %slot773, align 8
  %v4497 = load i32, ptr %slot773, align 8
  %cv4498 = zext i32 %v4497 to i64
  %cond4499 = icmp ne i64 %cv4498, 0
  br i1 %cond4499, label %bb_rcgnn994, label %bb_rcgdone994
bb_rcgnn994:
  %v4500 = load i64, ptr %slot772, align 8
  %op4501 = sub i64 %v4500, 16
  store i64 %op4501, ptr %slot774, align 8
  %v4502 = load i64, ptr %slot772, align 8
  %p4503 = inttoptr i64 %v4502 to ptr
  %rgep4504 = getelementptr i8, ptr %p4503, i64 -16
  %ld4505 = load i64, ptr %rgep4504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4505, ptr %slot775, align 8
  %v4506 = load i64, ptr %slot775, align 8
  %op4507 = and i64 %v4506, 4611686018427387906
  store i64 %op4507, ptr %slot776, align 8
  %v4508 = load i64, ptr %slot776, align 8
  %cmp4509 = icmp ne i64 %v4508, 0
  %cv4510 = zext i1 %cmp4509 to i32
  store i32 %cv4510, ptr %slot777, align 8
  %v4511 = load i32, ptr %slot777, align 8
  %cv4512 = zext i32 %v4511 to i64
  %cond4513 = icmp ne i64 %cv4512, 0
  br i1 %cond4513, label %bb_rcgclear994, label %bb_rcgcounted994
bb_rcgcounted994:
  %v4514 = load i64, ptr %slot772, align 8
  %op4515 = sub i64 %v4514, 32
  store i64 %op4515, ptr %slot778, align 8
  %v4516 = load i64, ptr %slot772, align 8
  %p4517 = inttoptr i64 %v4516 to ptr
  %rgep4518 = getelementptr i8, ptr %p4517, i64 -32
  %ld4519 = load i64, ptr %rgep4518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4519, ptr %slot779, align 8
  %v4520 = load i64, ptr %slot779, align 8
  %op4521 = sub i64 %v4520, 1
  store i64 %op4521, ptr %slot780, align 8
  %v4522 = load i64, ptr %slot780, align 8
  %cmp4523 = icmp eq i64 %v4522, 0
  %cv4524 = zext i1 %cmp4523 to i32
  store i32 %cv4524, ptr %slot781, align 8
  %v4525 = load i32, ptr %slot781, align 8
  %cv4526 = zext i32 %v4525 to i64
  %cond4527 = icmp ne i64 %cv4526, 0
  br i1 %cond4527, label %bb_rcglast994, label %bb_rcgdec994
bb_rcglast994:
  %v4528 = load i64, ptr %slot772, align 8
  %op4529 = sub i64 %v4528, 24
  store i64 %op4529, ptr %slot782, align 8
  %v4530 = load i64, ptr %slot772, align 8
  %p4531 = inttoptr i64 %v4530 to ptr
  %rgep4532 = getelementptr i8, ptr %p4531, i64 -24
  %ld4533 = load i64, ptr %rgep4532, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4533, ptr %slot783, align 8
  %v4534 = load i64, ptr %slot783, align 8
  %cmp4535 = icmp ne i64 %v4534, 0
  %cv4536 = zext i1 %cmp4535 to i32
  store i32 %cv4536, ptr %slot784, align 8
  %v4537 = load i32, ptr %slot784, align 8
  %cv4538 = zext i32 %v4537 to i64
  %cond4539 = icmp ne i64 %cv4538, 0
  br i1 %cond4539, label %bb_rcgdec994, label %bb_rcgslow994
bb_rcgslow994:
  %v4540 = load i64, ptr %slot771, align 8
  %v4541 = load i64, ptr %slot754, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v4540, i64 %v4541) nomerge, !dbg !132
  br label %bb_rcgdone994
bb_rcgdec994:
  %v4542 = load i64, ptr %slot780, align 8
  %v4543 = load i64, ptr %slot772, align 8
  %p4544 = inttoptr i64 %v4543 to ptr
  %rgep4545 = getelementptr i8, ptr %p4544, i64 -32
  store i64 %v4542, ptr %rgep4545, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear994
bb_rcgclear994:
  %v4546 = load i64, ptr %slot754, align 8
  %p4547 = inttoptr i64 %v4546 to ptr
  store i64 0, ptr %p4547, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone994
bb_rcgdone994:
  br label %bb_rcslotdone963
bb_rcslotdone963:
  %v4548 = load i64, ptr %slot19, align 8
  store i64 %v4548, ptr %slot785, align 8
  %v4549 = load i64, ptr %slot785, align 8
  %v4550 = load i64, ptr %slot734, align 8
  %p4551 = inttoptr i64 %v4549 to ptr
  %p4552 = inttoptr i64 %v4550 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4552, ptr %p4551, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4553 = load i64, ptr %slot8, align 8
  %p4554 = inttoptr i64 %v4553 to ptr
  store i32 2, ptr %p4554, align 4, !alias.scope !3, !noalias !4
  %v4555 = load i64, ptr %slot7, align 8
  %p4556 = inttoptr i64 %v4555 to ptr
  store i32 1, ptr %p4556, align 4, !alias.scope !3, !noalias !4
  %v4557 = load i64, ptr %slot15, align 8
  %p4558 = inttoptr i64 %v4557 to ptr
  store i32 0, ptr %p4558, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal935
bb_rcownedlocal935:
  %v4559 = load i64, ptr %slot8, align 8
  %p4560 = inttoptr i64 %v4559 to ptr
  store i32 2, ptr %p4560, align 4, !alias.scope !3, !noalias !4
  %v4561 = load i64, ptr %slot729, align 8
  %p4562 = inttoptr i64 %v4561 to ptr
  %ld4563 = load i64, ptr %p4562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4563, ptr %slot786, align 8
  %v4564 = load i64, ptr %slot786, align 8
  %cmp4565 = icmp ne i64 %v4564, 0
  %cv4566 = zext i1 %cmp4565 to i32
  store i32 %cv4566, ptr %slot787, align 8
  %v4567 = load i32, ptr %slot787, align 8
  %cv4568 = zext i32 %v4567 to i64
  %cond4569 = icmp ne i64 %cv4568, 0
  br i1 %cond4569, label %bb_rcguniquenn1003, label %bb_rcgunique1003
bb_rcguniquenn1003:
  %v4570 = load i64, ptr %slot786, align 8
  %op4571 = sub i64 %v4570, 16
  store i64 %op4571, ptr %slot788, align 8
  %v4572 = load i64, ptr %slot786, align 8
  %p4573 = inttoptr i64 %v4572 to ptr
  %rgep4574 = getelementptr i8, ptr %p4573, i64 -16
  %ld4575 = load i64, ptr %rgep4574, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4575, ptr %slot789, align 8
  %v4576 = load i64, ptr %slot789, align 8
  %op4577 = and i64 %v4576, 6917529027641081858
  store i64 %op4577, ptr %slot790, align 8
  %v4578 = load i64, ptr %slot790, align 8
  %cmp4579 = icmp ne i64 %v4578, 0
  %cv4580 = zext i1 %cmp4579 to i32
  store i32 %cv4580, ptr %slot791, align 8
  %v4581 = load i32, ptr %slot791, align 8
  %cv4582 = zext i32 %v4581 to i64
  %cond4583 = icmp ne i64 %cv4582, 0
  br i1 %cond4583, label %bb_rcguniqueslow1003, label %bb_rcguniquecount1003
bb_rcguniquecount1003:
  %v4584 = load i64, ptr %slot786, align 8
  %op4585 = sub i64 %v4584, 32
  store i64 %op4585, ptr %slot792, align 8
  %v4586 = load i64, ptr %slot786, align 8
  %p4587 = inttoptr i64 %v4586 to ptr
  %rgep4588 = getelementptr i8, ptr %p4587, i64 -32
  %ld4589 = load i64, ptr %rgep4588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4589, ptr %slot793, align 8
  %v4590 = load i64, ptr %slot793, align 8
  %cmp4591 = icmp ult i64 %v4590, 2
  %cv4592 = zext i1 %cmp4591 to i32
  store i32 %cv4592, ptr %slot794, align 8
  %v4593 = load i32, ptr %slot794, align 8
  %cv4594 = zext i32 %v4593 to i64
  %cond4595 = icmp ne i64 %cv4594, 0
  br i1 %cond4595, label %bb_rcgunique1003, label %bb_rcguniqueslow1003
bb_rcguniqueslow1003:
  %v4596 = load i64, ptr %slot1, align 8
  %p4597 = inttoptr i64 %v4596 to ptr
  %p4598 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v4599 = load i64, ptr %slot729, align 8
  %p4600 = inttoptr i64 %v4599 to ptr
  %v4601 = load i64, ptr %slot7, align 8
  %p4602 = inttoptr i64 %v4601 to ptr
  %call4603 = call i32 @myl_qbe_rc_unique_local(ptr %p4597, ptr %p4598, ptr %p4600, ptr %p4602) nomerge, !dbg !132
  store i32 %call4603, ptr %slot795, align 8
  %v4604 = load i32, ptr %slot795, align 8
  %cv4605 = zext i32 %v4604 to i64
  %cond4606 = icmp ne i64 %cv4605, 0
  br i1 %cond4606, label %bb_rcunique1014, label %bb_failure
bb_rcunique1014:
  br label %bb_rcgunique1003
bb_rcgunique1003:
  %v4607 = load i64, ptr %slot25, align 8
  %p4608 = inttoptr i64 %v4607 to ptr
  %ld4609 = load i64, ptr %p4608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4609, ptr %slot796, align 8
  %v4610 = load i64, ptr %slot30, align 8
  store i64 %v4610, ptr %slot797, align 8
  %v4611 = load i64, ptr %slot797, align 8
  %p4612 = inttoptr i64 %v4611 to ptr
  %ld4613 = load i64, ptr %p4612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4613, ptr %slot798, align 8
  %v4614 = load i64, ptr %slot798, align 8
  %v4615 = load i64, ptr %slot20, align 8
  %p4616 = inttoptr i64 %v4615 to ptr
  store i64 %v4614, ptr %p4616, align 8, !alias.scope !3, !noalias !4
  %v4617 = load i64, ptr %slot20, align 8
  store i64 %v4617, ptr %slot799, align 8
  %v4618 = load i64, ptr %slot35, align 8
  %v4619 = load i64, ptr %slot796, align 8
  %v4620 = load i64, ptr %slot799, align 8
  %call4621 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v4618, i64 %v4619, i64 %v4620) nomerge, !dbg !132
  store i32 %call4621, ptr %slot800, align 8
  %v4622 = load i32, ptr %slot800, align 8
  %cv4623 = zext i32 %v4622 to i64
  %cond4624 = icmp ne i64 %cv4623, 0
  br i1 %cond4624, label %bb_success1020, label %bb_failed1020
bb_failed1020:
  %v4625 = load i64, ptr %slot1, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4626) nomerge, !dbg !132
  unreachable
bb_success1020:
  %v4627 = load i64, ptr %slot30, align 8
  %p4628 = inttoptr i64 %v4627 to ptr
  store i64 0, ptr %p4628, align 8, !alias.scope !3, !noalias !4
  %v4629 = load i64, ptr %slot13, align 8
  %p4630 = inttoptr i64 %v4629 to ptr
  %ld4631 = load i32, ptr %p4630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4631, ptr %slot801, align 8
  %v4632 = load i32, ptr %slot801, align 8
  %cv4633 = zext i32 %v4632 to i64
  %cond4634 = icmp ne i64 %cv4633, 0
  br i1 %cond4634, label %bb_rcslotdrop1023, label %bb_rcslotdone1023
bb_rcslotdrop1023:
  %v4635 = load i64, ptr %slot13, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  store i32 0, ptr %p4636, align 4, !alias.scope !3, !noalias !4
  %v4637 = load i64, ptr %slot17, align 8
  store i64 %v4637, ptr %slot802, align 8
  %v4638 = load i64, ptr %slot14, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  %ld4640 = load i32, ptr %p4639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4640, ptr %slot803, align 8
  %v4641 = load i32, ptr %slot803, align 8
  %op4642 = and i32 %v4641, 28
  store i32 %op4642, ptr %slot804, align 8
  %v4643 = load i32, ptr %slot804, align 8
  %cv4644 = zext i32 %v4643 to i64
  %cond4645 = icmp ne i64 %cv4644, 0
  br i1 %cond4645, label %bb_rcslotrole1023, label %bb_rcslotowner1023
bb_rcslotrole1023:
  %v4646 = load i64, ptr %slot35, align 8
  store i64 %v4646, ptr %slot805, align 8
  %v4647 = load i64, ptr %slot802, align 8
  %p4648 = inttoptr i64 %v4647 to ptr
  %ld4649 = load i64, ptr %p4648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4649, ptr %slot806, align 8
  %v4650 = load i64, ptr %slot806, align 8
  %cmp4651 = icmp ne i64 %v4650, 0
  %cv4652 = zext i1 %cmp4651 to i32
  store i32 %cv4652, ptr %slot807, align 8
  %v4653 = load i32, ptr %slot807, align 8
  %cv4654 = zext i32 %v4653 to i64
  %cond4655 = icmp ne i64 %cv4654, 0
  br i1 %cond4655, label %bb_rcgnn1039, label %bb_rcgdone1039
bb_rcgnn1039:
  %v4656 = load i64, ptr %slot806, align 8
  %op4657 = sub i64 %v4656, 16
  store i64 %op4657, ptr %slot808, align 8
  %v4658 = load i64, ptr %slot806, align 8
  %p4659 = inttoptr i64 %v4658 to ptr
  %rgep4660 = getelementptr i8, ptr %p4659, i64 -16
  %ld4661 = load i64, ptr %rgep4660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4661, ptr %slot809, align 8
  %v4662 = load i64, ptr %slot809, align 8
  %op4663 = and i64 %v4662, 4611686018427387906
  store i64 %op4663, ptr %slot810, align 8
  %v4664 = load i64, ptr %slot810, align 8
  %cmp4665 = icmp ne i64 %v4664, 0
  %cv4666 = zext i1 %cmp4665 to i32
  store i32 %cv4666, ptr %slot811, align 8
  %v4667 = load i32, ptr %slot811, align 8
  %cv4668 = zext i32 %v4667 to i64
  %cond4669 = icmp ne i64 %cv4668, 0
  br i1 %cond4669, label %bb_rcgclear1039, label %bb_rcgcounted1039
bb_rcgcounted1039:
  %v4670 = load i64, ptr %slot806, align 8
  %op4671 = sub i64 %v4670, 24
  store i64 %op4671, ptr %slot812, align 8
  %v4672 = load i64, ptr %slot806, align 8
  %p4673 = inttoptr i64 %v4672 to ptr
  %rgep4674 = getelementptr i8, ptr %p4673, i64 -24
  %ld4675 = load i64, ptr %rgep4674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4675, ptr %slot813, align 8
  %v4676 = load i64, ptr %slot813, align 8
  %op4677 = sub i64 %v4676, 1
  store i64 %op4677, ptr %slot814, align 8
  %v4678 = load i64, ptr %slot814, align 8
  %cmp4679 = icmp eq i64 %v4678, 0
  %cv4680 = zext i1 %cmp4679 to i32
  store i32 %cv4680, ptr %slot815, align 8
  %v4681 = load i32, ptr %slot815, align 8
  %cv4682 = zext i32 %v4681 to i64
  %cond4683 = icmp ne i64 %cv4682, 0
  br i1 %cond4683, label %bb_rcglast1039, label %bb_rcgdec1039
bb_rcglast1039:
  %v4684 = load i64, ptr %slot806, align 8
  %op4685 = sub i64 %v4684, 32
  store i64 %op4685, ptr %slot816, align 8
  %v4686 = load i64, ptr %slot806, align 8
  %p4687 = inttoptr i64 %v4686 to ptr
  %rgep4688 = getelementptr i8, ptr %p4687, i64 -32
  %ld4689 = load i64, ptr %rgep4688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4689, ptr %slot817, align 8
  %v4690 = load i64, ptr %slot817, align 8
  %cmp4691 = icmp ne i64 %v4690, 0
  %cv4692 = zext i1 %cmp4691 to i32
  store i32 %cv4692, ptr %slot818, align 8
  %v4693 = load i32, ptr %slot818, align 8
  %cv4694 = zext i32 %v4693 to i64
  %cond4695 = icmp ne i64 %cv4694, 0
  br i1 %cond4695, label %bb_rcgdec1039, label %bb_rcgslow1039
bb_rcgslow1039:
  %v4696 = load i64, ptr %slot805, align 8
  %v4697 = load i64, ptr %slot802, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v4696, i64 %v4697) nomerge, !dbg !132
  br label %bb_rcgdone1039
bb_rcgdec1039:
  %v4698 = load i64, ptr %slot814, align 8
  %v4699 = load i64, ptr %slot806, align 8
  %p4700 = inttoptr i64 %v4699 to ptr
  %rgep4701 = getelementptr i8, ptr %p4700, i64 -24
  store i64 %v4698, ptr %rgep4701, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1039
bb_rcgclear1039:
  %v4702 = load i64, ptr %slot802, align 8
  %p4703 = inttoptr i64 %v4702 to ptr
  store i64 0, ptr %p4703, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1039
bb_rcgdone1039:
  br label %bb_rcslotdone1023
bb_rcslotowner1023:
  %v4704 = load i64, ptr %slot35, align 8
  store i64 %v4704, ptr %slot819, align 8
  %v4705 = load i64, ptr %slot802, align 8
  %p4706 = inttoptr i64 %v4705 to ptr
  %ld4707 = load i64, ptr %p4706, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4707, ptr %slot820, align 8
  %v4708 = load i64, ptr %slot820, align 8
  %cmp4709 = icmp ne i64 %v4708, 0
  %cv4710 = zext i1 %cmp4709 to i32
  store i32 %cv4710, ptr %slot821, align 8
  %v4711 = load i32, ptr %slot821, align 8
  %cv4712 = zext i32 %v4711 to i64
  %cond4713 = icmp ne i64 %cv4712, 0
  br i1 %cond4713, label %bb_rcgnn1054, label %bb_rcgdone1054
bb_rcgnn1054:
  %v4714 = load i64, ptr %slot820, align 8
  %op4715 = sub i64 %v4714, 16
  store i64 %op4715, ptr %slot822, align 8
  %v4716 = load i64, ptr %slot820, align 8
  %p4717 = inttoptr i64 %v4716 to ptr
  %rgep4718 = getelementptr i8, ptr %p4717, i64 -16
  %ld4719 = load i64, ptr %rgep4718, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4719, ptr %slot823, align 8
  %v4720 = load i64, ptr %slot823, align 8
  %op4721 = and i64 %v4720, 4611686018427387906
  store i64 %op4721, ptr %slot824, align 8
  %v4722 = load i64, ptr %slot824, align 8
  %cmp4723 = icmp ne i64 %v4722, 0
  %cv4724 = zext i1 %cmp4723 to i32
  store i32 %cv4724, ptr %slot825, align 8
  %v4725 = load i32, ptr %slot825, align 8
  %cv4726 = zext i32 %v4725 to i64
  %cond4727 = icmp ne i64 %cv4726, 0
  br i1 %cond4727, label %bb_rcgclear1054, label %bb_rcgcounted1054
bb_rcgcounted1054:
  %v4728 = load i64, ptr %slot820, align 8
  %op4729 = sub i64 %v4728, 32
  store i64 %op4729, ptr %slot826, align 8
  %v4730 = load i64, ptr %slot820, align 8
  %p4731 = inttoptr i64 %v4730 to ptr
  %rgep4732 = getelementptr i8, ptr %p4731, i64 -32
  %ld4733 = load i64, ptr %rgep4732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4733, ptr %slot827, align 8
  %v4734 = load i64, ptr %slot827, align 8
  %op4735 = sub i64 %v4734, 1
  store i64 %op4735, ptr %slot828, align 8
  %v4736 = load i64, ptr %slot828, align 8
  %cmp4737 = icmp eq i64 %v4736, 0
  %cv4738 = zext i1 %cmp4737 to i32
  store i32 %cv4738, ptr %slot829, align 8
  %v4739 = load i32, ptr %slot829, align 8
  %cv4740 = zext i32 %v4739 to i64
  %cond4741 = icmp ne i64 %cv4740, 0
  br i1 %cond4741, label %bb_rcglast1054, label %bb_rcgdec1054
bb_rcglast1054:
  %v4742 = load i64, ptr %slot820, align 8
  %op4743 = sub i64 %v4742, 24
  store i64 %op4743, ptr %slot830, align 8
  %v4744 = load i64, ptr %slot820, align 8
  %p4745 = inttoptr i64 %v4744 to ptr
  %rgep4746 = getelementptr i8, ptr %p4745, i64 -24
  %ld4747 = load i64, ptr %rgep4746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4747, ptr %slot831, align 8
  %v4748 = load i64, ptr %slot831, align 8
  %cmp4749 = icmp ne i64 %v4748, 0
  %cv4750 = zext i1 %cmp4749 to i32
  store i32 %cv4750, ptr %slot832, align 8
  %v4751 = load i32, ptr %slot832, align 8
  %cv4752 = zext i32 %v4751 to i64
  %cond4753 = icmp ne i64 %cv4752, 0
  br i1 %cond4753, label %bb_rcgdec1054, label %bb_rcgslow1054
bb_rcgslow1054:
  %v4754 = load i64, ptr %slot819, align 8
  %v4755 = load i64, ptr %slot802, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v4754, i64 %v4755) nomerge, !dbg !132
  br label %bb_rcgdone1054
bb_rcgdec1054:
  %v4756 = load i64, ptr %slot828, align 8
  %v4757 = load i64, ptr %slot820, align 8
  %p4758 = inttoptr i64 %v4757 to ptr
  %rgep4759 = getelementptr i8, ptr %p4758, i64 -32
  store i64 %v4756, ptr %rgep4759, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1054
bb_rcgclear1054:
  %v4760 = load i64, ptr %slot802, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  store i64 0, ptr %p4761, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1054
bb_rcgdone1054:
  br label %bb_rcslotdone1023
bb_rcslotdone1023:
  %v4762 = load i64, ptr %slot25, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  %ld4764 = load i64, ptr %p4763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4764, ptr %slot833, align 8
  %v4765 = load i64, ptr %slot833, align 8
  %v4766 = load i64, ptr %slot30, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  store i64 %v4765, ptr %p4767, align 8, !alias.scope !3, !noalias !4
  %v4768 = load i64, ptr %slot26, align 8
  %p4769 = inttoptr i64 %v4768 to ptr
  %ld4770 = load i64, ptr %p4769, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4770, ptr %slot834, align 8
  %v4771 = load i64, ptr %slot30, align 8
  %p4772 = inttoptr i64 %v4771 to ptr
  %ld4773 = load i64, ptr %p4772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4773, ptr %slot835, align 8
  %v4774 = load i64, ptr %slot35, align 8
  %p4775 = inttoptr i64 %v4774 to ptr
  %v4776 = load i64, ptr %slot834, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %v4778 = load i64, ptr %slot835, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  %call4780 = call ptr @myl_native_text_join(ptr %p4775, ptr %p4777, ptr %p4779) nomerge, !dbg !134
  %calladdr4781 = ptrtoint ptr %call4780 to i64
  store i64 %calladdr4781, ptr %slot836, align 8
  %v4782 = load i64, ptr %slot836, align 8
  %cond4783 = icmp ne i64 %v4782, 0
  br i1 %cond4783, label %bb_success1062, label %bb_failed1062
bb_failed1062:
  %v4784 = load i64, ptr %slot1, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4785) nomerge, !dbg !134
  unreachable
bb_success1062:
  %v4786 = load i64, ptr %slot836, align 8
  %v4787 = load i64, ptr %slot30, align 8
  %p4788 = inttoptr i64 %v4787 to ptr
  store i64 %v4786, ptr %p4788, align 8, !alias.scope !3, !noalias !4
  %v4789 = load i64, ptr %slot30, align 8
  %p4790 = inttoptr i64 %v4789 to ptr
  %ld4791 = load i64, ptr %p4790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4791, ptr %slot837, align 8
  %v4792 = load i64, ptr %slot837, align 8
  %v4793 = load i64, ptr %slot18, align 8
  %p4794 = inttoptr i64 %v4793 to ptr
  store i64 %v4792, ptr %p4794, align 8, !alias.scope !3, !noalias !4
  %v4795 = load i64, ptr %slot18, align 8
  store i64 %v4795, ptr %slot838, align 8
  %v4796 = load i64, ptr %slot19, align 8
  store i64 %v4796, ptr %slot839, align 8
  %v4797 = load i64, ptr %slot838, align 8
  %v4798 = load i64, ptr %slot839, align 8
  %p4799 = inttoptr i64 %v4797 to ptr
  %p4800 = inttoptr i64 %v4798 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4800, ptr %p4799, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4801 = load i64, ptr %slot16, align 8
  %p4802 = inttoptr i64 %v4801 to ptr
  store i32 2, ptr %p4802, align 4, !alias.scope !3, !noalias !4
  %v4803 = load i64, ptr %slot15, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  store i32 1, ptr %p4804, align 4, !alias.scope !3, !noalias !4
  %v4805 = load i64, ptr %slot13, align 8
  %p4806 = inttoptr i64 %v4805 to ptr
  %ld4807 = load i32, ptr %p4806, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4807, ptr %slot840, align 8
  %v4808 = load i32, ptr %slot840, align 8
  %cv4809 = zext i32 %v4808 to i64
  %cond4810 = icmp ne i64 %cv4809, 0
  br i1 %cond4810, label %bb_rcslotdrop1070, label %bb_rcslotdone1070
bb_rcslotdrop1070:
  %v4811 = load i64, ptr %slot13, align 8
  %p4812 = inttoptr i64 %v4811 to ptr
  store i32 0, ptr %p4812, align 4, !alias.scope !3, !noalias !4
  %v4813 = load i64, ptr %slot17, align 8
  store i64 %v4813, ptr %slot841, align 8
  %v4814 = load i64, ptr %slot14, align 8
  %p4815 = inttoptr i64 %v4814 to ptr
  %ld4816 = load i32, ptr %p4815, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4816, ptr %slot842, align 8
  %v4817 = load i32, ptr %slot842, align 8
  %op4818 = and i32 %v4817, 28
  store i32 %op4818, ptr %slot843, align 8
  %v4819 = load i32, ptr %slot843, align 8
  %cv4820 = zext i32 %v4819 to i64
  %cond4821 = icmp ne i64 %cv4820, 0
  br i1 %cond4821, label %bb_rcslotrole1070, label %bb_rcslotowner1070
bb_rcslotrole1070:
  %v4822 = load i64, ptr %slot35, align 8
  store i64 %v4822, ptr %slot844, align 8
  %v4823 = load i64, ptr %slot841, align 8
  %p4824 = inttoptr i64 %v4823 to ptr
  %ld4825 = load i64, ptr %p4824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4825, ptr %slot845, align 8
  %v4826 = load i64, ptr %slot845, align 8
  %cmp4827 = icmp ne i64 %v4826, 0
  %cv4828 = zext i1 %cmp4827 to i32
  store i32 %cv4828, ptr %slot846, align 8
  %v4829 = load i32, ptr %slot846, align 8
  %cv4830 = zext i32 %v4829 to i64
  %cond4831 = icmp ne i64 %cv4830, 0
  br i1 %cond4831, label %bb_rcgnn1086, label %bb_rcgdone1086
bb_rcgnn1086:
  %v4832 = load i64, ptr %slot845, align 8
  %op4833 = sub i64 %v4832, 16
  store i64 %op4833, ptr %slot847, align 8
  %v4834 = load i64, ptr %slot845, align 8
  %p4835 = inttoptr i64 %v4834 to ptr
  %rgep4836 = getelementptr i8, ptr %p4835, i64 -16
  %ld4837 = load i64, ptr %rgep4836, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4837, ptr %slot848, align 8
  %v4838 = load i64, ptr %slot848, align 8
  %op4839 = and i64 %v4838, 4611686018427387906
  store i64 %op4839, ptr %slot849, align 8
  %v4840 = load i64, ptr %slot849, align 8
  %cmp4841 = icmp ne i64 %v4840, 0
  %cv4842 = zext i1 %cmp4841 to i32
  store i32 %cv4842, ptr %slot850, align 8
  %v4843 = load i32, ptr %slot850, align 8
  %cv4844 = zext i32 %v4843 to i64
  %cond4845 = icmp ne i64 %cv4844, 0
  br i1 %cond4845, label %bb_rcgclear1086, label %bb_rcgcounted1086
bb_rcgcounted1086:
  %v4846 = load i64, ptr %slot845, align 8
  %op4847 = sub i64 %v4846, 24
  store i64 %op4847, ptr %slot851, align 8
  %v4848 = load i64, ptr %slot845, align 8
  %p4849 = inttoptr i64 %v4848 to ptr
  %rgep4850 = getelementptr i8, ptr %p4849, i64 -24
  %ld4851 = load i64, ptr %rgep4850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4851, ptr %slot852, align 8
  %v4852 = load i64, ptr %slot852, align 8
  %op4853 = sub i64 %v4852, 1
  store i64 %op4853, ptr %slot853, align 8
  %v4854 = load i64, ptr %slot853, align 8
  %cmp4855 = icmp eq i64 %v4854, 0
  %cv4856 = zext i1 %cmp4855 to i32
  store i32 %cv4856, ptr %slot854, align 8
  %v4857 = load i32, ptr %slot854, align 8
  %cv4858 = zext i32 %v4857 to i64
  %cond4859 = icmp ne i64 %cv4858, 0
  br i1 %cond4859, label %bb_rcglast1086, label %bb_rcgdec1086
bb_rcglast1086:
  %v4860 = load i64, ptr %slot845, align 8
  %op4861 = sub i64 %v4860, 32
  store i64 %op4861, ptr %slot855, align 8
  %v4862 = load i64, ptr %slot845, align 8
  %p4863 = inttoptr i64 %v4862 to ptr
  %rgep4864 = getelementptr i8, ptr %p4863, i64 -32
  %ld4865 = load i64, ptr %rgep4864, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4865, ptr %slot856, align 8
  %v4866 = load i64, ptr %slot856, align 8
  %cmp4867 = icmp ne i64 %v4866, 0
  %cv4868 = zext i1 %cmp4867 to i32
  store i32 %cv4868, ptr %slot857, align 8
  %v4869 = load i32, ptr %slot857, align 8
  %cv4870 = zext i32 %v4869 to i64
  %cond4871 = icmp ne i64 %cv4870, 0
  br i1 %cond4871, label %bb_rcgdec1086, label %bb_rcgslow1086
bb_rcgslow1086:
  %v4872 = load i64, ptr %slot844, align 8
  %v4873 = load i64, ptr %slot841, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v4872, i64 %v4873) nomerge, !dbg !134
  br label %bb_rcgdone1086
bb_rcgdec1086:
  %v4874 = load i64, ptr %slot853, align 8
  %v4875 = load i64, ptr %slot845, align 8
  %p4876 = inttoptr i64 %v4875 to ptr
  %rgep4877 = getelementptr i8, ptr %p4876, i64 -24
  store i64 %v4874, ptr %rgep4877, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1086
bb_rcgclear1086:
  %v4878 = load i64, ptr %slot841, align 8
  %p4879 = inttoptr i64 %v4878 to ptr
  store i64 0, ptr %p4879, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1086
bb_rcgdone1086:
  br label %bb_rcslotdone1070
bb_rcslotowner1070:
  %v4880 = load i64, ptr %slot35, align 8
  store i64 %v4880, ptr %slot858, align 8
  %v4881 = load i64, ptr %slot841, align 8
  %p4882 = inttoptr i64 %v4881 to ptr
  %ld4883 = load i64, ptr %p4882, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4883, ptr %slot859, align 8
  %v4884 = load i64, ptr %slot859, align 8
  %cmp4885 = icmp ne i64 %v4884, 0
  %cv4886 = zext i1 %cmp4885 to i32
  store i32 %cv4886, ptr %slot860, align 8
  %v4887 = load i32, ptr %slot860, align 8
  %cv4888 = zext i32 %v4887 to i64
  %cond4889 = icmp ne i64 %cv4888, 0
  br i1 %cond4889, label %bb_rcgnn1101, label %bb_rcgdone1101
bb_rcgnn1101:
  %v4890 = load i64, ptr %slot859, align 8
  %op4891 = sub i64 %v4890, 16
  store i64 %op4891, ptr %slot861, align 8
  %v4892 = load i64, ptr %slot859, align 8
  %p4893 = inttoptr i64 %v4892 to ptr
  %rgep4894 = getelementptr i8, ptr %p4893, i64 -16
  %ld4895 = load i64, ptr %rgep4894, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4895, ptr %slot862, align 8
  %v4896 = load i64, ptr %slot862, align 8
  %op4897 = and i64 %v4896, 4611686018427387906
  store i64 %op4897, ptr %slot863, align 8
  %v4898 = load i64, ptr %slot863, align 8
  %cmp4899 = icmp ne i64 %v4898, 0
  %cv4900 = zext i1 %cmp4899 to i32
  store i32 %cv4900, ptr %slot864, align 8
  %v4901 = load i32, ptr %slot864, align 8
  %cv4902 = zext i32 %v4901 to i64
  %cond4903 = icmp ne i64 %cv4902, 0
  br i1 %cond4903, label %bb_rcgclear1101, label %bb_rcgcounted1101
bb_rcgcounted1101:
  %v4904 = load i64, ptr %slot859, align 8
  %op4905 = sub i64 %v4904, 32
  store i64 %op4905, ptr %slot865, align 8
  %v4906 = load i64, ptr %slot859, align 8
  %p4907 = inttoptr i64 %v4906 to ptr
  %rgep4908 = getelementptr i8, ptr %p4907, i64 -32
  %ld4909 = load i64, ptr %rgep4908, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4909, ptr %slot866, align 8
  %v4910 = load i64, ptr %slot866, align 8
  %op4911 = sub i64 %v4910, 1
  store i64 %op4911, ptr %slot867, align 8
  %v4912 = load i64, ptr %slot867, align 8
  %cmp4913 = icmp eq i64 %v4912, 0
  %cv4914 = zext i1 %cmp4913 to i32
  store i32 %cv4914, ptr %slot868, align 8
  %v4915 = load i32, ptr %slot868, align 8
  %cv4916 = zext i32 %v4915 to i64
  %cond4917 = icmp ne i64 %cv4916, 0
  br i1 %cond4917, label %bb_rcglast1101, label %bb_rcgdec1101
bb_rcglast1101:
  %v4918 = load i64, ptr %slot859, align 8
  %op4919 = sub i64 %v4918, 24
  store i64 %op4919, ptr %slot869, align 8
  %v4920 = load i64, ptr %slot859, align 8
  %p4921 = inttoptr i64 %v4920 to ptr
  %rgep4922 = getelementptr i8, ptr %p4921, i64 -24
  %ld4923 = load i64, ptr %rgep4922, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4923, ptr %slot870, align 8
  %v4924 = load i64, ptr %slot870, align 8
  %cmp4925 = icmp ne i64 %v4924, 0
  %cv4926 = zext i1 %cmp4925 to i32
  store i32 %cv4926, ptr %slot871, align 8
  %v4927 = load i32, ptr %slot871, align 8
  %cv4928 = zext i32 %v4927 to i64
  %cond4929 = icmp ne i64 %cv4928, 0
  br i1 %cond4929, label %bb_rcgdec1101, label %bb_rcgslow1101
bb_rcgslow1101:
  %v4930 = load i64, ptr %slot858, align 8
  %v4931 = load i64, ptr %slot841, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v4930, i64 %v4931) nomerge, !dbg !134
  br label %bb_rcgdone1101
bb_rcgdec1101:
  %v4932 = load i64, ptr %slot867, align 8
  %v4933 = load i64, ptr %slot859, align 8
  %p4934 = inttoptr i64 %v4933 to ptr
  %rgep4935 = getelementptr i8, ptr %p4934, i64 -32
  store i64 %v4932, ptr %rgep4935, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1101
bb_rcgclear1101:
  %v4936 = load i64, ptr %slot841, align 8
  %p4937 = inttoptr i64 %v4936 to ptr
  store i64 0, ptr %p4937, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1101
bb_rcgdone1101:
  br label %bb_rcslotdone1070
bb_rcslotdone1070:
  %v4938 = load i64, ptr %slot17, align 8
  store i64 %v4938, ptr %slot872, align 8
  %v4939 = load i64, ptr %slot19, align 8
  store i64 %v4939, ptr %slot873, align 8
  %v4940 = load i64, ptr %slot873, align 8
  %v4941 = load i64, ptr %slot872, align 8
  %p4942 = inttoptr i64 %v4940 to ptr
  %p4943 = inttoptr i64 %v4941 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4943, ptr %p4942, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4944 = load i64, ptr %slot14, align 8
  %p4945 = inttoptr i64 %v4944 to ptr
  store i32 2, ptr %p4945, align 4, !alias.scope !3, !noalias !4
  %v4946 = load i64, ptr %slot16, align 8
  %p4947 = inttoptr i64 %v4946 to ptr
  %ld4948 = load i32, ptr %p4947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4948, ptr %slot874, align 8
  %v4949 = load i32, ptr %slot874, align 8
  %v4950 = load i64, ptr %slot14, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  store i32 %v4949, ptr %p4951, align 4, !alias.scope !3, !noalias !4
  %v4952 = load i64, ptr %slot15, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  store i32 0, ptr %p4953, align 4, !alias.scope !3, !noalias !4
  %v4954 = load i64, ptr %slot13, align 8
  %p4955 = inttoptr i64 %v4954 to ptr
  store i32 1, ptr %p4955, align 4, !alias.scope !3, !noalias !4
  %v4956 = load i64, ptr %slot872, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  %ld4958 = load i64, ptr %p4957, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4958, ptr %slot875, align 8
  %v4959 = load i64, ptr %slot875, align 8
  %v4960 = load i64, ptr %slot30, align 8
  %p4961 = inttoptr i64 %v4960 to ptr
  store i64 %v4959, ptr %p4961, align 8, !alias.scope !3, !noalias !4
  %v4962 = load i64, ptr %slot30, align 8
  %p4963 = inttoptr i64 %v4962 to ptr
  %ld4964 = load i64, ptr %p4963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4964, ptr %slot876, align 8
  %v4965 = load i64, ptr %slot876, align 8
  %v4966 = load i64, ptr %slot18, align 8
  %p4967 = inttoptr i64 %v4966 to ptr
  store i64 %v4965, ptr %p4967, align 8, !alias.scope !3, !noalias !4
  %v4968 = load i64, ptr %slot18, align 8
  store i64 %v4968, ptr %slot877, align 8
  %v4969 = load i64, ptr %slot13, align 8
  %p4970 = inttoptr i64 %v4969 to ptr
  %ld4971 = load i32, ptr %p4970, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4971, ptr %slot878, align 8
  %v4972 = load i64, ptr %slot14, align 8
  %p4973 = inttoptr i64 %v4972 to ptr
  %ld4974 = load i32, ptr %p4973, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4974, ptr %slot879, align 8
  %v4975 = load i32, ptr %slot879, align 8
  %op4976 = and i32 %v4975, 24
  store i32 %op4976, ptr %slot879, align 8
  %v4977 = load i32, ptr %slot879, align 8
  %cmp4978 = icmp eq i32 %v4977, 0
  %cv4979 = zext i1 %cmp4978 to i32
  store i32 %cv4979, ptr %slot880, align 8
  %v4980 = load i32, ptr %slot878, align 8
  %v4981 = load i32, ptr %slot880, align 8
  %op4982 = and i32 %v4980, %v4981
  store i32 %op4982, ptr %slot881, align 8
  %v4983 = load i32, ptr %slot881, align 8
  %cv4984 = zext i32 %v4983 to i64
  %cond4985 = icmp ne i64 %cv4984, 0
  br i1 %cond4985, label %bb_rcprivateown1122, label %bb_rcprivateloan1122
bb_rcprivateown1122:
  %v4986 = load i64, ptr %slot19, align 8
  store i64 %v4986, ptr %slot882, align 8
  %v4987 = load i64, ptr %slot36, align 8
  store i64 %v4987, ptr %slot883, align 8
  %v4988 = load i64, ptr %slot877, align 8
  %v4989 = load i64, ptr %slot882, align 8
  %op4990 = sub i64 %v4988, %v4989
  store i64 %op4990, ptr %slot884, align 8
  %v4991 = load i64, ptr %slot882, align 8
  %v4992 = load i64, ptr %slot877, align 8
  %op4993 = sub i64 %v4991, %v4992
  store i64 %op4993, ptr %slot885, align 8
  %v4994 = load i64, ptr %slot884, align 8
  %cmp4995 = icmp ult i64 %v4994, 8
  %cv4996 = zext i1 %cmp4995 to i32
  store i32 %cv4996, ptr %slot886, align 8
  %v4997 = load i64, ptr %slot885, align 8
  %cmp4998 = icmp ult i64 %v4997, 8
  %cv4999 = zext i1 %cmp4998 to i32
  store i32 %cv4999, ptr %slot887, align 8
  %v5000 = load i32, ptr %slot886, align 8
  %v5001 = load i32, ptr %slot887, align 8
  %op5002 = or i32 %v5000, %v5001
  store i32 %op5002, ptr %slot888, align 8
  %v5003 = load i32, ptr %slot888, align 8
  %cv5004 = zext i32 %v5003 to i64
  %cond5005 = icmp ne i64 %cv5004, 0
  br i1 %cond5005, label %bb_rcmoveslow1125, label %bb_rcmovecheck1125
bb_rcmovecheck1125:
  %v5006 = load i64, ptr %slot877, align 8
  %p5008 = inttoptr i64 %v5006 to ptr
  %gep5009 = getelementptr i8, ptr %p5008, i64 0
  %op5007 = ptrtoint ptr %gep5009 to i64
  store i64 %op5007, ptr %slot889, align 8
  %v5010 = load i64, ptr %slot889, align 8
  %p5011 = inttoptr i64 %v5010 to ptr
  %ld5012 = load i64, ptr %p5011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5012, ptr %slot890, align 8
  %v5013 = load i64, ptr %slot890, align 8
  %cmp5014 = icmp ne i64 %v5013, 0
  %cv5015 = zext i1 %cmp5014 to i32
  store i32 %cv5015, ptr %slot891, align 8
  %v5016 = load i32, ptr %slot891, align 8
  %cv5017 = zext i32 %v5016 to i64
  %cond5018 = icmp ne i64 %cv5017, 0
  br i1 %cond5018, label %bb_rcmoveheader1133, label %bb_rcmovenext1133
bb_rcmoveheader1133:
  %v5019 = load i64, ptr %slot890, align 8
  %op5020 = sub i64 %v5019, 16
  store i64 %op5020, ptr %slot892, align 8
  %v5021 = load i64, ptr %slot890, align 8
  %p5022 = inttoptr i64 %v5021 to ptr
  %rgep5023 = getelementptr i8, ptr %p5022, i64 -16
  %ld5024 = load i64, ptr %rgep5023, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5024, ptr %slot893, align 8
  %v5025 = load i64, ptr %slot893, align 8
  %op5026 = and i64 %v5025, 5764607523034234881
  store i64 %op5026, ptr %slot894, align 8
  %v5027 = load i64, ptr %slot894, align 8
  %cmp5028 = icmp ne i64 %v5027, 0
  %cv5029 = zext i1 %cmp5028 to i32
  store i32 %cv5029, ptr %slot895, align 8
  %v5030 = load i32, ptr %slot895, align 8
  %cv5031 = zext i32 %v5030 to i64
  %cond5032 = icmp ne i64 %cv5031, 0
  br i1 %cond5032, label %bb_rcmoveslow1125, label %bb_rcmovenext1133
bb_rcmovenext1133:
  %v5033 = load i64, ptr %slot877, align 8
  %v5034 = load i64, ptr %slot882, align 8
  %p5035 = inttoptr i64 %v5033 to ptr
  %p5036 = inttoptr i64 %v5034 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5036, ptr %p5035, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5037 = load i64, ptr %slot877, align 8
  %p5038 = inttoptr i64 %v5037 to ptr
  store i64 0, ptr %p5038, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1125
bb_rcmoveslow1125:
  %v5039 = load i64, ptr %slot35, align 8
  %v5040 = load i64, ptr %slot882, align 8
  %v5041 = load i64, ptr %slot877, align 8
  %v5042 = load i64, ptr %slot883, align 8
  %cv5043 = trunc i64 %v5042 to i32
  %call5044 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v5039, i64 %v5040, i64 %v5041, i32 %cv5043) nomerge, !dbg !136
  store i32 %call5044, ptr %slot896, align 8
  %v5045 = load i32, ptr %slot896, align 8
  %cv5046 = zext i32 %v5045 to i64
  %cond5047 = icmp ne i64 %cv5046, 0
  br i1 %cond5047, label %bb_rcsuccess1140, label %bb_rcfailure1140
bb_rcfailure1140:
  %v5048 = load i64, ptr %slot35, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  %call5050 = call i32 @myl_rc_take_failure(ptr %p5049) nomerge, !dbg !136
  store i32 %call5050, ptr %slot897, align 8
  %v5051 = load i64, ptr %slot1, align 8
  %p5052 = inttoptr i64 %v5051 to ptr
  %v5053 = load i32, ptr %slot897, align 8
  %call5054 = call i32 @myl_qbe_rc_status(ptr %p5052, i32 %v5053) nomerge, !dbg !136
  store i32 %call5054, ptr %slot898, align 8
  br label %bb_failure
bb_rcsuccess1140:
  br label %bb_rcmoved1125
bb_rcmoved1125:
  %v5055 = load i64, ptr %slot13, align 8
  %p5056 = inttoptr i64 %v5055 to ptr
  store i32 0, ptr %p5056, align 4, !alias.scope !3, !noalias !4
  %v5057 = load i64, ptr %slot16, align 8
  %p5058 = inttoptr i64 %v5057 to ptr
  store i32 2, ptr %p5058, align 4, !alias.scope !3, !noalias !4
  %v5059 = load i64, ptr %slot15, align 8
  %p5060 = inttoptr i64 %v5059 to ptr
  store i32 1, ptr %p5060, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1122
bb_rcprivateloan1122:
  %v5061 = load i64, ptr %slot13, align 8
  %p5062 = inttoptr i64 %v5061 to ptr
  %ld5063 = load i32, ptr %p5062, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5063, ptr %slot899, align 8
  %v5064 = load i64, ptr %slot14, align 8
  %p5065 = inttoptr i64 %v5064 to ptr
  %ld5066 = load i32, ptr %p5065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5066, ptr %slot900, align 8
  %v5067 = load i32, ptr %slot900, align 8
  %cmp5068 = icmp eq i32 %v5067, 16
  %cv5069 = zext i1 %cmp5068 to i32
  store i32 %cv5069, ptr %slot901, align 8
  %v5070 = load i32, ptr %slot901, align 8
  %v5071 = load i32, ptr %slot899, align 8
  %op5072 = and i32 %v5070, %v5071
  store i32 %op5072, ptr %slot901, align 8
  %v5073 = load i32, ptr %slot901, align 8
  %cv5074 = zext i32 %v5073 to i64
  %cond5075 = icmp ne i64 %cv5074, 0
  br i1 %cond5075, label %bb_rcprivatemove1122, label %bb_rcprivatenew1122
bb_rcprivatemove1122:
  %v5076 = load i64, ptr %slot19, align 8
  store i64 %v5076, ptr %slot902, align 8
  %v5077 = load i64, ptr %slot877, align 8
  %v5078 = load i64, ptr %slot902, align 8
  %p5079 = inttoptr i64 %v5077 to ptr
  %p5080 = inttoptr i64 %v5078 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5080, ptr %p5079, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5081 = load i64, ptr %slot877, align 8
  %p5082 = inttoptr i64 %v5081 to ptr
  store i64 0, ptr %p5082, align 8, !alias.scope !3, !noalias !4
  %v5083 = load i64, ptr %slot16, align 8
  %p5084 = inttoptr i64 %v5083 to ptr
  store i32 2, ptr %p5084, align 4, !alias.scope !3, !noalias !4
  %v5085 = load i64, ptr %slot16, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  store i32 16, ptr %p5086, align 4, !alias.scope !3, !noalias !4
  %v5087 = load i64, ptr %slot15, align 8
  %p5088 = inttoptr i64 %v5087 to ptr
  store i32 1, ptr %p5088, align 4, !alias.scope !3, !noalias !4
  %v5089 = load i64, ptr %slot13, align 8
  %p5090 = inttoptr i64 %v5089 to ptr
  store i32 0, ptr %p5090, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1122
bb_rcprivatenew1122:
  %v5091 = load i64, ptr %slot19, align 8
  store i64 %v5091, ptr %slot903, align 8
  %v5092 = load i64, ptr %slot877, align 8
  %p5093 = inttoptr i64 %v5092 to ptr
  %ld5094 = load i64, ptr %p5093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5094, ptr %slot904, align 8
  %v5095 = load i64, ptr %slot904, align 8
  %cmp5096 = icmp ne i64 %v5095, 0
  %cv5097 = zext i1 %cmp5096 to i32
  store i32 %cv5097, ptr %slot905, align 8
  %v5098 = load i32, ptr %slot905, align 8
  %cv5099 = zext i32 %v5098 to i64
  %cond5100 = icmp ne i64 %cv5099, 0
  br i1 %cond5100, label %bb_rcgnn1158, label %bb_rcgstore1158
bb_rcgnn1158:
  %v5101 = load i64, ptr %slot904, align 8
  %op5102 = sub i64 %v5101, 16
  store i64 %op5102, ptr %slot906, align 8
  %v5103 = load i64, ptr %slot904, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  %rgep5105 = getelementptr i8, ptr %p5104, i64 -16
  %ld5106 = load i64, ptr %rgep5105, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5106, ptr %slot907, align 8
  %v5107 = load i64, ptr %slot907, align 8
  %op5108 = and i64 %v5107, 4611686018427387906
  store i64 %op5108, ptr %slot908, align 8
  %v5109 = load i64, ptr %slot908, align 8
  %cmp5110 = icmp ne i64 %v5109, 0
  %cv5111 = zext i1 %cmp5110 to i32
  store i32 %cv5111, ptr %slot909, align 8
  %v5112 = load i32, ptr %slot909, align 8
  %cv5113 = zext i32 %v5112 to i64
  %cond5114 = icmp ne i64 %cv5113, 0
  br i1 %cond5114, label %bb_rcgstore1158, label %bb_rcginc1158
bb_rcginc1158:
  %v5115 = load i64, ptr %slot904, align 8
  %op5116 = sub i64 %v5115, 24
  store i64 %op5116, ptr %slot910, align 8
  %v5117 = load i64, ptr %slot904, align 8
  %p5118 = inttoptr i64 %v5117 to ptr
  %rgep5119 = getelementptr i8, ptr %p5118, i64 -24
  %ld5120 = load i64, ptr %rgep5119, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5120, ptr %slot911, align 8
  %v5121 = load i64, ptr %slot911, align 8
  %op5122 = add i64 %v5121, 1
  store i64 %op5122, ptr %slot912, align 8
  %v5123 = load i64, ptr %slot912, align 8
  %cmp5124 = icmp eq i64 %v5123, 0
  %cv5125 = zext i1 %cmp5124 to i32
  store i32 %cv5125, ptr %slot913, align 8
  %v5126 = load i32, ptr %slot913, align 8
  %cv5127 = zext i32 %v5126 to i64
  %cond5128 = icmp ne i64 %cv5127, 0
  br i1 %cond5128, label %bb_rcglimit1158, label %bb_rcgcapacity1158
bb_rcglimit1158:
  %v5129 = load i64, ptr %slot1, align 8
  %p5130 = inttoptr i64 %v5129 to ptr
  %call5131 = call i32 @myl_qbe_rc_status(ptr %p5130, i32 2) nomerge, !dbg !136
  store i32 %call5131, ptr %slot914, align 8
  br label %bb_failure
bb_rcgcapacity1158:
  %v5132 = load i64, ptr %slot912, align 8
  %v5133 = load i64, ptr %slot904, align 8
  %p5134 = inttoptr i64 %v5133 to ptr
  %rgep5135 = getelementptr i8, ptr %p5134, i64 -24
  store i64 %v5132, ptr %rgep5135, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1158
bb_rcgstore1158:
  %v5136 = load i64, ptr %slot904, align 8
  %v5137 = load i64, ptr %slot903, align 8
  %p5138 = inttoptr i64 %v5137 to ptr
  store i64 %v5136, ptr %p5138, align 8, !alias.scope !3, !noalias !4
  %v5139 = load i64, ptr %slot16, align 8
  %p5140 = inttoptr i64 %v5139 to ptr
  store i32 2, ptr %p5140, align 4, !alias.scope !3, !noalias !4
  %v5141 = load i64, ptr %slot16, align 8
  %p5142 = inttoptr i64 %v5141 to ptr
  store i32 16, ptr %p5142, align 4, !alias.scope !3, !noalias !4
  %v5143 = load i64, ptr %slot15, align 8
  %p5144 = inttoptr i64 %v5143 to ptr
  store i32 1, ptr %p5144, align 4, !alias.scope !3, !noalias !4
  %v5145 = load i64, ptr %slot13, align 8
  %p5146 = inttoptr i64 %v5145 to ptr
  %ld5147 = load i32, ptr %p5146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5147, ptr %slot915, align 8
  %v5148 = load i32, ptr %slot915, align 8
  %cv5149 = zext i32 %v5148 to i64
  %cond5150 = icmp ne i64 %cv5149, 0
  br i1 %cond5150, label %bb_rcslotdrop1174, label %bb_rcslotdone1174
bb_rcslotdrop1174:
  %v5151 = load i64, ptr %slot13, align 8
  %p5152 = inttoptr i64 %v5151 to ptr
  store i32 0, ptr %p5152, align 4, !alias.scope !3, !noalias !4
  %v5153 = load i64, ptr %slot17, align 8
  store i64 %v5153, ptr %slot916, align 8
  %v5154 = load i64, ptr %slot14, align 8
  %p5155 = inttoptr i64 %v5154 to ptr
  %ld5156 = load i32, ptr %p5155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5156, ptr %slot917, align 8
  %v5157 = load i32, ptr %slot917, align 8
  %op5158 = and i32 %v5157, 28
  store i32 %op5158, ptr %slot918, align 8
  %v5159 = load i32, ptr %slot918, align 8
  %cv5160 = zext i32 %v5159 to i64
  %cond5161 = icmp ne i64 %cv5160, 0
  br i1 %cond5161, label %bb_rcslotrole1174, label %bb_rcslotowner1174
bb_rcslotrole1174:
  %v5162 = load i64, ptr %slot35, align 8
  store i64 %v5162, ptr %slot919, align 8
  %v5163 = load i64, ptr %slot916, align 8
  %p5164 = inttoptr i64 %v5163 to ptr
  %ld5165 = load i64, ptr %p5164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5165, ptr %slot920, align 8
  %v5166 = load i64, ptr %slot920, align 8
  %cmp5167 = icmp ne i64 %v5166, 0
  %cv5168 = zext i1 %cmp5167 to i32
  store i32 %cv5168, ptr %slot921, align 8
  %v5169 = load i32, ptr %slot921, align 8
  %cv5170 = zext i32 %v5169 to i64
  %cond5171 = icmp ne i64 %cv5170, 0
  br i1 %cond5171, label %bb_rcgnn1190, label %bb_rcgdone1190
bb_rcgnn1190:
  %v5172 = load i64, ptr %slot920, align 8
  %op5173 = sub i64 %v5172, 16
  store i64 %op5173, ptr %slot922, align 8
  %v5174 = load i64, ptr %slot920, align 8
  %p5175 = inttoptr i64 %v5174 to ptr
  %rgep5176 = getelementptr i8, ptr %p5175, i64 -16
  %ld5177 = load i64, ptr %rgep5176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5177, ptr %slot923, align 8
  %v5178 = load i64, ptr %slot923, align 8
  %op5179 = and i64 %v5178, 4611686018427387906
  store i64 %op5179, ptr %slot924, align 8
  %v5180 = load i64, ptr %slot924, align 8
  %cmp5181 = icmp ne i64 %v5180, 0
  %cv5182 = zext i1 %cmp5181 to i32
  store i32 %cv5182, ptr %slot925, align 8
  %v5183 = load i32, ptr %slot925, align 8
  %cv5184 = zext i32 %v5183 to i64
  %cond5185 = icmp ne i64 %cv5184, 0
  br i1 %cond5185, label %bb_rcgclear1190, label %bb_rcgcounted1190
bb_rcgcounted1190:
  %v5186 = load i64, ptr %slot920, align 8
  %op5187 = sub i64 %v5186, 24
  store i64 %op5187, ptr %slot926, align 8
  %v5188 = load i64, ptr %slot920, align 8
  %p5189 = inttoptr i64 %v5188 to ptr
  %rgep5190 = getelementptr i8, ptr %p5189, i64 -24
  %ld5191 = load i64, ptr %rgep5190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5191, ptr %slot927, align 8
  %v5192 = load i64, ptr %slot927, align 8
  %op5193 = sub i64 %v5192, 1
  store i64 %op5193, ptr %slot928, align 8
  %v5194 = load i64, ptr %slot928, align 8
  %cmp5195 = icmp eq i64 %v5194, 0
  %cv5196 = zext i1 %cmp5195 to i32
  store i32 %cv5196, ptr %slot929, align 8
  %v5197 = load i32, ptr %slot929, align 8
  %cv5198 = zext i32 %v5197 to i64
  %cond5199 = icmp ne i64 %cv5198, 0
  br i1 %cond5199, label %bb_rcglast1190, label %bb_rcgdec1190
bb_rcglast1190:
  %v5200 = load i64, ptr %slot920, align 8
  %op5201 = sub i64 %v5200, 32
  store i64 %op5201, ptr %slot930, align 8
  %v5202 = load i64, ptr %slot920, align 8
  %p5203 = inttoptr i64 %v5202 to ptr
  %rgep5204 = getelementptr i8, ptr %p5203, i64 -32
  %ld5205 = load i64, ptr %rgep5204, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5205, ptr %slot931, align 8
  %v5206 = load i64, ptr %slot931, align 8
  %cmp5207 = icmp ne i64 %v5206, 0
  %cv5208 = zext i1 %cmp5207 to i32
  store i32 %cv5208, ptr %slot932, align 8
  %v5209 = load i32, ptr %slot932, align 8
  %cv5210 = zext i32 %v5209 to i64
  %cond5211 = icmp ne i64 %cv5210, 0
  br i1 %cond5211, label %bb_rcgdec1190, label %bb_rcgslow1190
bb_rcgslow1190:
  %v5212 = load i64, ptr %slot919, align 8
  %v5213 = load i64, ptr %slot916, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5212, i64 %v5213) nomerge, !dbg !136
  br label %bb_rcgdone1190
bb_rcgdec1190:
  %v5214 = load i64, ptr %slot928, align 8
  %v5215 = load i64, ptr %slot920, align 8
  %p5216 = inttoptr i64 %v5215 to ptr
  %rgep5217 = getelementptr i8, ptr %p5216, i64 -24
  store i64 %v5214, ptr %rgep5217, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1190
bb_rcgclear1190:
  %v5218 = load i64, ptr %slot916, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  store i64 0, ptr %p5219, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1190
bb_rcgdone1190:
  br label %bb_rcslotdone1174
bb_rcslotowner1174:
  %v5220 = load i64, ptr %slot35, align 8
  store i64 %v5220, ptr %slot933, align 8
  %v5221 = load i64, ptr %slot916, align 8
  %p5222 = inttoptr i64 %v5221 to ptr
  %ld5223 = load i64, ptr %p5222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5223, ptr %slot934, align 8
  %v5224 = load i64, ptr %slot934, align 8
  %cmp5225 = icmp ne i64 %v5224, 0
  %cv5226 = zext i1 %cmp5225 to i32
  store i32 %cv5226, ptr %slot935, align 8
  %v5227 = load i32, ptr %slot935, align 8
  %cv5228 = zext i32 %v5227 to i64
  %cond5229 = icmp ne i64 %cv5228, 0
  br i1 %cond5229, label %bb_rcgnn1205, label %bb_rcgdone1205
bb_rcgnn1205:
  %v5230 = load i64, ptr %slot934, align 8
  %op5231 = sub i64 %v5230, 16
  store i64 %op5231, ptr %slot936, align 8
  %v5232 = load i64, ptr %slot934, align 8
  %p5233 = inttoptr i64 %v5232 to ptr
  %rgep5234 = getelementptr i8, ptr %p5233, i64 -16
  %ld5235 = load i64, ptr %rgep5234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5235, ptr %slot937, align 8
  %v5236 = load i64, ptr %slot937, align 8
  %op5237 = and i64 %v5236, 4611686018427387906
  store i64 %op5237, ptr %slot938, align 8
  %v5238 = load i64, ptr %slot938, align 8
  %cmp5239 = icmp ne i64 %v5238, 0
  %cv5240 = zext i1 %cmp5239 to i32
  store i32 %cv5240, ptr %slot939, align 8
  %v5241 = load i32, ptr %slot939, align 8
  %cv5242 = zext i32 %v5241 to i64
  %cond5243 = icmp ne i64 %cv5242, 0
  br i1 %cond5243, label %bb_rcgclear1205, label %bb_rcgcounted1205
bb_rcgcounted1205:
  %v5244 = load i64, ptr %slot934, align 8
  %op5245 = sub i64 %v5244, 32
  store i64 %op5245, ptr %slot940, align 8
  %v5246 = load i64, ptr %slot934, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  %rgep5248 = getelementptr i8, ptr %p5247, i64 -32
  %ld5249 = load i64, ptr %rgep5248, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5249, ptr %slot941, align 8
  %v5250 = load i64, ptr %slot941, align 8
  %op5251 = sub i64 %v5250, 1
  store i64 %op5251, ptr %slot942, align 8
  %v5252 = load i64, ptr %slot942, align 8
  %cmp5253 = icmp eq i64 %v5252, 0
  %cv5254 = zext i1 %cmp5253 to i32
  store i32 %cv5254, ptr %slot943, align 8
  %v5255 = load i32, ptr %slot943, align 8
  %cv5256 = zext i32 %v5255 to i64
  %cond5257 = icmp ne i64 %cv5256, 0
  br i1 %cond5257, label %bb_rcglast1205, label %bb_rcgdec1205
bb_rcglast1205:
  %v5258 = load i64, ptr %slot934, align 8
  %op5259 = sub i64 %v5258, 24
  store i64 %op5259, ptr %slot944, align 8
  %v5260 = load i64, ptr %slot934, align 8
  %p5261 = inttoptr i64 %v5260 to ptr
  %rgep5262 = getelementptr i8, ptr %p5261, i64 -24
  %ld5263 = load i64, ptr %rgep5262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5263, ptr %slot945, align 8
  %v5264 = load i64, ptr %slot945, align 8
  %cmp5265 = icmp ne i64 %v5264, 0
  %cv5266 = zext i1 %cmp5265 to i32
  store i32 %cv5266, ptr %slot946, align 8
  %v5267 = load i32, ptr %slot946, align 8
  %cv5268 = zext i32 %v5267 to i64
  %cond5269 = icmp ne i64 %cv5268, 0
  br i1 %cond5269, label %bb_rcgdec1205, label %bb_rcgslow1205
bb_rcgslow1205:
  %v5270 = load i64, ptr %slot933, align 8
  %v5271 = load i64, ptr %slot916, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5270, i64 %v5271) nomerge, !dbg !136
  br label %bb_rcgdone1205
bb_rcgdec1205:
  %v5272 = load i64, ptr %slot942, align 8
  %v5273 = load i64, ptr %slot934, align 8
  %p5274 = inttoptr i64 %v5273 to ptr
  %rgep5275 = getelementptr i8, ptr %p5274, i64 -32
  store i64 %v5272, ptr %rgep5275, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1205
bb_rcgclear1205:
  %v5276 = load i64, ptr %slot916, align 8
  %p5277 = inttoptr i64 %v5276 to ptr
  store i64 0, ptr %p5277, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1205
bb_rcgdone1205:
  br label %bb_rcslotdone1174
bb_rcslotdone1174:
  br label %bb_rcprivateprepared1122
bb_rcprivateprepared1122:
  %v5278 = load i64, ptr %slot11, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  %ld5280 = load i32, ptr %p5279, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5280, ptr %slot947, align 8
  %v5281 = load i32, ptr %slot947, align 8
  %cv5282 = zext i32 %v5281 to i64
  %cond5283 = icmp ne i64 %cv5282, 0
  br i1 %cond5283, label %bb_rcslotdrop1212, label %bb_rcslotdone1212
bb_rcslotdrop1212:
  %v5284 = load i64, ptr %slot11, align 8
  %p5285 = inttoptr i64 %v5284 to ptr
  store i32 0, ptr %p5285, align 4, !alias.scope !3, !noalias !4
  %v5286 = load i64, ptr %slot27, align 8
  store i64 %v5286, ptr %slot948, align 8
  %v5287 = load i64, ptr %slot12, align 8
  %p5288 = inttoptr i64 %v5287 to ptr
  %ld5289 = load i32, ptr %p5288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5289, ptr %slot949, align 8
  %v5290 = load i32, ptr %slot949, align 8
  %op5291 = and i32 %v5290, 28
  store i32 %op5291, ptr %slot950, align 8
  %v5292 = load i32, ptr %slot950, align 8
  %cv5293 = zext i32 %v5292 to i64
  %cond5294 = icmp ne i64 %cv5293, 0
  br i1 %cond5294, label %bb_rcslotrole1212, label %bb_rcslotowner1212
bb_rcslotrole1212:
  %v5295 = load i64, ptr %slot35, align 8
  store i64 %v5295, ptr %slot951, align 8
  %v5296 = load i64, ptr %slot948, align 8
  %p5297 = inttoptr i64 %v5296 to ptr
  %ld5298 = load i64, ptr %p5297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5298, ptr %slot952, align 8
  %v5299 = load i64, ptr %slot952, align 8
  %cmp5300 = icmp ne i64 %v5299, 0
  %cv5301 = zext i1 %cmp5300 to i32
  store i32 %cv5301, ptr %slot953, align 8
  %v5302 = load i32, ptr %slot953, align 8
  %cv5303 = zext i32 %v5302 to i64
  %cond5304 = icmp ne i64 %cv5303, 0
  br i1 %cond5304, label %bb_rcgnn1228, label %bb_rcgdone1228
bb_rcgnn1228:
  %v5305 = load i64, ptr %slot952, align 8
  %op5306 = sub i64 %v5305, 16
  store i64 %op5306, ptr %slot954, align 8
  %v5307 = load i64, ptr %slot952, align 8
  %p5308 = inttoptr i64 %v5307 to ptr
  %rgep5309 = getelementptr i8, ptr %p5308, i64 -16
  %ld5310 = load i64, ptr %rgep5309, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5310, ptr %slot955, align 8
  %v5311 = load i64, ptr %slot955, align 8
  %op5312 = and i64 %v5311, 4611686018427387906
  store i64 %op5312, ptr %slot956, align 8
  %v5313 = load i64, ptr %slot956, align 8
  %cmp5314 = icmp ne i64 %v5313, 0
  %cv5315 = zext i1 %cmp5314 to i32
  store i32 %cv5315, ptr %slot957, align 8
  %v5316 = load i32, ptr %slot957, align 8
  %cv5317 = zext i32 %v5316 to i64
  %cond5318 = icmp ne i64 %cv5317, 0
  br i1 %cond5318, label %bb_rcgclear1228, label %bb_rcgcounted1228
bb_rcgcounted1228:
  %v5319 = load i64, ptr %slot952, align 8
  %op5320 = sub i64 %v5319, 24
  store i64 %op5320, ptr %slot958, align 8
  %v5321 = load i64, ptr %slot952, align 8
  %p5322 = inttoptr i64 %v5321 to ptr
  %rgep5323 = getelementptr i8, ptr %p5322, i64 -24
  %ld5324 = load i64, ptr %rgep5323, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5324, ptr %slot959, align 8
  %v5325 = load i64, ptr %slot959, align 8
  %op5326 = sub i64 %v5325, 1
  store i64 %op5326, ptr %slot960, align 8
  %v5327 = load i64, ptr %slot960, align 8
  %cmp5328 = icmp eq i64 %v5327, 0
  %cv5329 = zext i1 %cmp5328 to i32
  store i32 %cv5329, ptr %slot961, align 8
  %v5330 = load i32, ptr %slot961, align 8
  %cv5331 = zext i32 %v5330 to i64
  %cond5332 = icmp ne i64 %cv5331, 0
  br i1 %cond5332, label %bb_rcglast1228, label %bb_rcgdec1228
bb_rcglast1228:
  %v5333 = load i64, ptr %slot952, align 8
  %op5334 = sub i64 %v5333, 32
  store i64 %op5334, ptr %slot962, align 8
  %v5335 = load i64, ptr %slot952, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  %rgep5337 = getelementptr i8, ptr %p5336, i64 -32
  %ld5338 = load i64, ptr %rgep5337, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5338, ptr %slot963, align 8
  %v5339 = load i64, ptr %slot963, align 8
  %cmp5340 = icmp ne i64 %v5339, 0
  %cv5341 = zext i1 %cmp5340 to i32
  store i32 %cv5341, ptr %slot964, align 8
  %v5342 = load i32, ptr %slot964, align 8
  %cv5343 = zext i32 %v5342 to i64
  %cond5344 = icmp ne i64 %cv5343, 0
  br i1 %cond5344, label %bb_rcgdec1228, label %bb_rcgslow1228
bb_rcgslow1228:
  %v5345 = load i64, ptr %slot951, align 8
  %v5346 = load i64, ptr %slot948, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5345, i64 %v5346) nomerge, !dbg !136
  br label %bb_rcgdone1228
bb_rcgdec1228:
  %v5347 = load i64, ptr %slot960, align 8
  %v5348 = load i64, ptr %slot952, align 8
  %p5349 = inttoptr i64 %v5348 to ptr
  %rgep5350 = getelementptr i8, ptr %p5349, i64 -24
  store i64 %v5347, ptr %rgep5350, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1228
bb_rcgclear1228:
  %v5351 = load i64, ptr %slot948, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  store i64 0, ptr %p5352, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1228
bb_rcgdone1228:
  br label %bb_rcslotdone1212
bb_rcslotowner1212:
  %v5353 = load i64, ptr %slot35, align 8
  store i64 %v5353, ptr %slot965, align 8
  %v5354 = load i64, ptr %slot948, align 8
  %p5355 = inttoptr i64 %v5354 to ptr
  %ld5356 = load i64, ptr %p5355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5356, ptr %slot966, align 8
  %v5357 = load i64, ptr %slot966, align 8
  %cmp5358 = icmp ne i64 %v5357, 0
  %cv5359 = zext i1 %cmp5358 to i32
  store i32 %cv5359, ptr %slot967, align 8
  %v5360 = load i32, ptr %slot967, align 8
  %cv5361 = zext i32 %v5360 to i64
  %cond5362 = icmp ne i64 %cv5361, 0
  br i1 %cond5362, label %bb_rcgnn1243, label %bb_rcgdone1243
bb_rcgnn1243:
  %v5363 = load i64, ptr %slot966, align 8
  %op5364 = sub i64 %v5363, 16
  store i64 %op5364, ptr %slot968, align 8
  %v5365 = load i64, ptr %slot966, align 8
  %p5366 = inttoptr i64 %v5365 to ptr
  %rgep5367 = getelementptr i8, ptr %p5366, i64 -16
  %ld5368 = load i64, ptr %rgep5367, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5368, ptr %slot969, align 8
  %v5369 = load i64, ptr %slot969, align 8
  %op5370 = and i64 %v5369, 4611686018427387906
  store i64 %op5370, ptr %slot970, align 8
  %v5371 = load i64, ptr %slot970, align 8
  %cmp5372 = icmp ne i64 %v5371, 0
  %cv5373 = zext i1 %cmp5372 to i32
  store i32 %cv5373, ptr %slot971, align 8
  %v5374 = load i32, ptr %slot971, align 8
  %cv5375 = zext i32 %v5374 to i64
  %cond5376 = icmp ne i64 %cv5375, 0
  br i1 %cond5376, label %bb_rcgclear1243, label %bb_rcgcounted1243
bb_rcgcounted1243:
  %v5377 = load i64, ptr %slot966, align 8
  %op5378 = sub i64 %v5377, 32
  store i64 %op5378, ptr %slot972, align 8
  %v5379 = load i64, ptr %slot966, align 8
  %p5380 = inttoptr i64 %v5379 to ptr
  %rgep5381 = getelementptr i8, ptr %p5380, i64 -32
  %ld5382 = load i64, ptr %rgep5381, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5382, ptr %slot973, align 8
  %v5383 = load i64, ptr %slot973, align 8
  %op5384 = sub i64 %v5383, 1
  store i64 %op5384, ptr %slot974, align 8
  %v5385 = load i64, ptr %slot974, align 8
  %cmp5386 = icmp eq i64 %v5385, 0
  %cv5387 = zext i1 %cmp5386 to i32
  store i32 %cv5387, ptr %slot975, align 8
  %v5388 = load i32, ptr %slot975, align 8
  %cv5389 = zext i32 %v5388 to i64
  %cond5390 = icmp ne i64 %cv5389, 0
  br i1 %cond5390, label %bb_rcglast1243, label %bb_rcgdec1243
bb_rcglast1243:
  %v5391 = load i64, ptr %slot966, align 8
  %op5392 = sub i64 %v5391, 24
  store i64 %op5392, ptr %slot976, align 8
  %v5393 = load i64, ptr %slot966, align 8
  %p5394 = inttoptr i64 %v5393 to ptr
  %rgep5395 = getelementptr i8, ptr %p5394, i64 -24
  %ld5396 = load i64, ptr %rgep5395, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5396, ptr %slot977, align 8
  %v5397 = load i64, ptr %slot977, align 8
  %cmp5398 = icmp ne i64 %v5397, 0
  %cv5399 = zext i1 %cmp5398 to i32
  store i32 %cv5399, ptr %slot978, align 8
  %v5400 = load i32, ptr %slot978, align 8
  %cv5401 = zext i32 %v5400 to i64
  %cond5402 = icmp ne i64 %cv5401, 0
  br i1 %cond5402, label %bb_rcgdec1243, label %bb_rcgslow1243
bb_rcgslow1243:
  %v5403 = load i64, ptr %slot965, align 8
  %v5404 = load i64, ptr %slot948, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5403, i64 %v5404) nomerge, !dbg !136
  br label %bb_rcgdone1243
bb_rcgdec1243:
  %v5405 = load i64, ptr %slot974, align 8
  %v5406 = load i64, ptr %slot966, align 8
  %p5407 = inttoptr i64 %v5406 to ptr
  %rgep5408 = getelementptr i8, ptr %p5407, i64 -32
  store i64 %v5405, ptr %rgep5408, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1243
bb_rcgclear1243:
  %v5409 = load i64, ptr %slot948, align 8
  %p5410 = inttoptr i64 %v5409 to ptr
  store i64 0, ptr %p5410, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1243
bb_rcgdone1243:
  br label %bb_rcslotdone1212
bb_rcslotdone1212:
  %v5411 = load i64, ptr %slot27, align 8
  store i64 %v5411, ptr %slot979, align 8
  %v5412 = load i64, ptr %slot19, align 8
  store i64 %v5412, ptr %slot980, align 8
  %v5413 = load i64, ptr %slot980, align 8
  %v5414 = load i64, ptr %slot979, align 8
  %p5415 = inttoptr i64 %v5413 to ptr
  %p5416 = inttoptr i64 %v5414 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5416, ptr %p5415, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5417 = load i64, ptr %slot15, align 8
  %p5418 = inttoptr i64 %v5417 to ptr
  store i32 0, ptr %p5418, align 4, !alias.scope !3, !noalias !4
  %v5419 = load i64, ptr %slot12, align 8
  %p5420 = inttoptr i64 %v5419 to ptr
  store i32 2, ptr %p5420, align 4, !alias.scope !3, !noalias !4
  %v5421 = load i64, ptr %slot16, align 8
  %p5422 = inttoptr i64 %v5421 to ptr
  %ld5423 = load i32, ptr %p5422, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5423, ptr %slot981, align 8
  %v5424 = load i32, ptr %slot981, align 8
  %v5425 = load i64, ptr %slot12, align 8
  %p5426 = inttoptr i64 %v5425 to ptr
  store i32 %v5424, ptr %p5426, align 4, !alias.scope !3, !noalias !4
  %v5427 = load i64, ptr %slot11, align 8
  %p5428 = inttoptr i64 %v5427 to ptr
  store i32 1, ptr %p5428, align 4, !alias.scope !3, !noalias !4
  %v5429 = load i64, ptr %slot27, align 8
  %p5430 = inttoptr i64 %v5429 to ptr
  %ld5431 = load i64, ptr %p5430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5431, ptr %slot982, align 8
  %v5432 = load i64, ptr %slot27, align 8
  %p5433 = inttoptr i64 %v5432 to ptr
  %ld5434 = load i64, ptr %p5433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5434, ptr %slot983, align 8
  %v5435 = load i64, ptr %slot35, align 8
  %p5436 = inttoptr i64 %v5435 to ptr
  %v5437 = load i64, ptr %slot983, align 8
  %p5438 = inttoptr i64 %v5437 to ptr
  %call5439 = call ptr @myl_native_bytes_encode(ptr %p5436, ptr %p5438) nomerge, !dbg !138
  %calladdr5440 = ptrtoint ptr %call5439 to i64
  store i64 %calladdr5440, ptr %slot984, align 8
  %v5441 = load i64, ptr %slot984, align 8
  %cond5442 = icmp ne i64 %v5441, 0
  br i1 %cond5442, label %bb_success1258, label %bb_failed1258
bb_failed1258:
  %v5443 = load i64, ptr %slot1, align 8
  %p5444 = inttoptr i64 %v5443 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5444) nomerge, !dbg !138
  unreachable
bb_success1258:
  %v5445 = load i64, ptr %slot984, align 8
  %v5446 = load i64, ptr %slot30, align 8
  %p5447 = inttoptr i64 %v5446 to ptr
  store i64 %v5445, ptr %p5447, align 8, !alias.scope !3, !noalias !4
  %v5448 = load i64, ptr %slot30, align 8
  %p5449 = inttoptr i64 %v5448 to ptr
  %ld5450 = load i64, ptr %p5449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5450, ptr %slot985, align 8
  %v5451 = load i64, ptr %slot985, align 8
  %v5452 = load i64, ptr %slot18, align 8
  %p5453 = inttoptr i64 %v5452 to ptr
  store i64 %v5451, ptr %p5453, align 8, !alias.scope !3, !noalias !4
  %v5454 = load i64, ptr %slot18, align 8
  store i64 %v5454, ptr %slot986, align 8
  %v5455 = load i64, ptr %slot19, align 8
  store i64 %v5455, ptr %slot987, align 8
  %v5456 = load i64, ptr %slot986, align 8
  %v5457 = load i64, ptr %slot987, align 8
  %p5458 = inttoptr i64 %v5456 to ptr
  %p5459 = inttoptr i64 %v5457 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5459, ptr %p5458, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5460 = load i64, ptr %slot16, align 8
  %p5461 = inttoptr i64 %v5460 to ptr
  store i32 2, ptr %p5461, align 4, !alias.scope !3, !noalias !4
  %v5462 = load i64, ptr %slot15, align 8
  %p5463 = inttoptr i64 %v5462 to ptr
  store i32 1, ptr %p5463, align 4, !alias.scope !3, !noalias !4
  %v5464 = load i64, ptr %slot17, align 8
  store i64 %v5464, ptr %slot988, align 8
  %v5465 = load i64, ptr %slot19, align 8
  store i64 %v5465, ptr %slot989, align 8
  %v5466 = load i64, ptr %slot989, align 8
  %v5467 = load i64, ptr %slot988, align 8
  %p5468 = inttoptr i64 %v5466 to ptr
  %p5469 = inttoptr i64 %v5467 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5469, ptr %p5468, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5470 = load i64, ptr %slot14, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  store i32 2, ptr %p5471, align 4, !alias.scope !3, !noalias !4
  %v5472 = load i64, ptr %slot16, align 8
  %p5473 = inttoptr i64 %v5472 to ptr
  %ld5474 = load i32, ptr %p5473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5474, ptr %slot990, align 8
  %v5475 = load i32, ptr %slot990, align 8
  %v5476 = load i64, ptr %slot14, align 8
  %p5477 = inttoptr i64 %v5476 to ptr
  store i32 %v5475, ptr %p5477, align 4, !alias.scope !3, !noalias !4
  %v5478 = load i64, ptr %slot15, align 8
  %p5479 = inttoptr i64 %v5478 to ptr
  store i32 0, ptr %p5479, align 4, !alias.scope !3, !noalias !4
  %v5480 = load i64, ptr %slot13, align 8
  %p5481 = inttoptr i64 %v5480 to ptr
  store i32 1, ptr %p5481, align 4, !alias.scope !3, !noalias !4
  %v5482 = load i64, ptr %slot988, align 8
  %p5483 = inttoptr i64 %v5482 to ptr
  %ld5484 = load i64, ptr %p5483, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5484, ptr %slot991, align 8
  %v5485 = load i64, ptr %slot991, align 8
  %v5486 = load i64, ptr %slot30, align 8
  %p5487 = inttoptr i64 %v5486 to ptr
  store i64 %v5485, ptr %p5487, align 8, !alias.scope !3, !noalias !4
  %v5488 = load i64, ptr %slot28, align 8
  %p5489 = inttoptr i64 %v5488 to ptr
  %ld5490 = load i64, ptr %p5489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5490, ptr %slot992, align 8
  %v5491 = load i64, ptr %slot29, align 8
  %p5492 = inttoptr i64 %v5491 to ptr
  %ld5493 = load i64, ptr %p5492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5493, ptr %slot993, align 8
  %v5494 = load i64, ptr %slot30, align 8
  %p5495 = inttoptr i64 %v5494 to ptr
  %ld5496 = load i64, ptr %p5495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5496, ptr %slot994, align 8
  %v5497 = load i64, ptr %slot1, align 8
  %v5498 = load i64, ptr %slot992, align 8
  %v5499 = load i64, ptr %slot993, align 8
  %v5500 = load i64, ptr %slot994, align 8
  %call5501 = call i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64 %v5497, i64 %v5498, i64 %v5499, i64 %v5500) nomerge, !dbg !140
  store i64 %call5501, ptr %slot995, align 8
  %v5502 = load i64, ptr %slot995, align 8
  %v5503 = load i64, ptr %slot28, align 8
  %p5504 = inttoptr i64 %v5503 to ptr
  store i64 %v5502, ptr %p5504, align 8, !alias.scope !3, !noalias !4
  %v5505 = load i64, ptr %slot13, align 8
  %p5506 = inttoptr i64 %v5505 to ptr
  %ld5507 = load i32, ptr %p5506, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5507, ptr %slot996, align 8
  %v5508 = load i32, ptr %slot996, align 8
  %cv5509 = zext i32 %v5508 to i64
  %cond5510 = icmp ne i64 %cv5509, 0
  br i1 %cond5510, label %bb_rcslotdrop1297, label %bb_rcslotdone1297
bb_rcslotdrop1297:
  %v5511 = load i64, ptr %slot13, align 8
  %p5512 = inttoptr i64 %v5511 to ptr
  store i32 0, ptr %p5512, align 4, !alias.scope !3, !noalias !4
  %v5513 = load i64, ptr %slot17, align 8
  store i64 %v5513, ptr %slot997, align 8
  %v5514 = load i64, ptr %slot14, align 8
  %p5515 = inttoptr i64 %v5514 to ptr
  %ld5516 = load i32, ptr %p5515, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5516, ptr %slot998, align 8
  %v5517 = load i32, ptr %slot998, align 8
  %op5518 = and i32 %v5517, 28
  store i32 %op5518, ptr %slot999, align 8
  %v5519 = load i32, ptr %slot999, align 8
  %cv5520 = zext i32 %v5519 to i64
  %cond5521 = icmp ne i64 %cv5520, 0
  br i1 %cond5521, label %bb_rcslotrole1297, label %bb_rcslotowner1297
bb_rcslotrole1297:
  %v5522 = load i64, ptr %slot35, align 8
  store i64 %v5522, ptr %slot1000, align 8
  %v5523 = load i64, ptr %slot997, align 8
  %p5524 = inttoptr i64 %v5523 to ptr
  %ld5525 = load i64, ptr %p5524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5525, ptr %slot1001, align 8
  %v5526 = load i64, ptr %slot1001, align 8
  %cmp5527 = icmp ne i64 %v5526, 0
  %cv5528 = zext i1 %cmp5527 to i32
  store i32 %cv5528, ptr %slot1002, align 8
  %v5529 = load i32, ptr %slot1002, align 8
  %cv5530 = zext i32 %v5529 to i64
  %cond5531 = icmp ne i64 %cv5530, 0
  br i1 %cond5531, label %bb_rcgnn1313, label %bb_rcgdone1313
bb_rcgnn1313:
  %v5532 = load i64, ptr %slot1001, align 8
  %op5533 = sub i64 %v5532, 16
  store i64 %op5533, ptr %slot1003, align 8
  %v5534 = load i64, ptr %slot1001, align 8
  %p5535 = inttoptr i64 %v5534 to ptr
  %rgep5536 = getelementptr i8, ptr %p5535, i64 -16
  %ld5537 = load i64, ptr %rgep5536, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5537, ptr %slot1004, align 8
  %v5538 = load i64, ptr %slot1004, align 8
  %op5539 = and i64 %v5538, 4611686018427387906
  store i64 %op5539, ptr %slot1005, align 8
  %v5540 = load i64, ptr %slot1005, align 8
  %cmp5541 = icmp ne i64 %v5540, 0
  %cv5542 = zext i1 %cmp5541 to i32
  store i32 %cv5542, ptr %slot1006, align 8
  %v5543 = load i32, ptr %slot1006, align 8
  %cv5544 = zext i32 %v5543 to i64
  %cond5545 = icmp ne i64 %cv5544, 0
  br i1 %cond5545, label %bb_rcgclear1313, label %bb_rcgcounted1313
bb_rcgcounted1313:
  %v5546 = load i64, ptr %slot1001, align 8
  %op5547 = sub i64 %v5546, 24
  store i64 %op5547, ptr %slot1007, align 8
  %v5548 = load i64, ptr %slot1001, align 8
  %p5549 = inttoptr i64 %v5548 to ptr
  %rgep5550 = getelementptr i8, ptr %p5549, i64 -24
  %ld5551 = load i64, ptr %rgep5550, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5551, ptr %slot1008, align 8
  %v5552 = load i64, ptr %slot1008, align 8
  %op5553 = sub i64 %v5552, 1
  store i64 %op5553, ptr %slot1009, align 8
  %v5554 = load i64, ptr %slot1009, align 8
  %cmp5555 = icmp eq i64 %v5554, 0
  %cv5556 = zext i1 %cmp5555 to i32
  store i32 %cv5556, ptr %slot1010, align 8
  %v5557 = load i32, ptr %slot1010, align 8
  %cv5558 = zext i32 %v5557 to i64
  %cond5559 = icmp ne i64 %cv5558, 0
  br i1 %cond5559, label %bb_rcglast1313, label %bb_rcgdec1313
bb_rcglast1313:
  %v5560 = load i64, ptr %slot1001, align 8
  %op5561 = sub i64 %v5560, 32
  store i64 %op5561, ptr %slot1011, align 8
  %v5562 = load i64, ptr %slot1001, align 8
  %p5563 = inttoptr i64 %v5562 to ptr
  %rgep5564 = getelementptr i8, ptr %p5563, i64 -32
  %ld5565 = load i64, ptr %rgep5564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5565, ptr %slot1012, align 8
  %v5566 = load i64, ptr %slot1012, align 8
  %cmp5567 = icmp ne i64 %v5566, 0
  %cv5568 = zext i1 %cmp5567 to i32
  store i32 %cv5568, ptr %slot1013, align 8
  %v5569 = load i32, ptr %slot1013, align 8
  %cv5570 = zext i32 %v5569 to i64
  %cond5571 = icmp ne i64 %cv5570, 0
  br i1 %cond5571, label %bb_rcgdec1313, label %bb_rcgslow1313
bb_rcgslow1313:
  %v5572 = load i64, ptr %slot1000, align 8
  %v5573 = load i64, ptr %slot997, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5572, i64 %v5573) nomerge, !dbg !140
  br label %bb_rcgdone1313
bb_rcgdec1313:
  %v5574 = load i64, ptr %slot1009, align 8
  %v5575 = load i64, ptr %slot1001, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  %rgep5577 = getelementptr i8, ptr %p5576, i64 -24
  store i64 %v5574, ptr %rgep5577, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1313
bb_rcgclear1313:
  %v5578 = load i64, ptr %slot997, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  store i64 0, ptr %p5579, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1313
bb_rcgdone1313:
  br label %bb_rcslotdone1297
bb_rcslotowner1297:
  %v5580 = load i64, ptr %slot35, align 8
  store i64 %v5580, ptr %slot1014, align 8
  %v5581 = load i64, ptr %slot997, align 8
  %p5582 = inttoptr i64 %v5581 to ptr
  %ld5583 = load i64, ptr %p5582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5583, ptr %slot1015, align 8
  %v5584 = load i64, ptr %slot1015, align 8
  %cmp5585 = icmp ne i64 %v5584, 0
  %cv5586 = zext i1 %cmp5585 to i32
  store i32 %cv5586, ptr %slot1016, align 8
  %v5587 = load i32, ptr %slot1016, align 8
  %cv5588 = zext i32 %v5587 to i64
  %cond5589 = icmp ne i64 %cv5588, 0
  br i1 %cond5589, label %bb_rcgnn1328, label %bb_rcgdone1328
bb_rcgnn1328:
  %v5590 = load i64, ptr %slot1015, align 8
  %op5591 = sub i64 %v5590, 16
  store i64 %op5591, ptr %slot1017, align 8
  %v5592 = load i64, ptr %slot1015, align 8
  %p5593 = inttoptr i64 %v5592 to ptr
  %rgep5594 = getelementptr i8, ptr %p5593, i64 -16
  %ld5595 = load i64, ptr %rgep5594, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5595, ptr %slot1018, align 8
  %v5596 = load i64, ptr %slot1018, align 8
  %op5597 = and i64 %v5596, 4611686018427387906
  store i64 %op5597, ptr %slot1019, align 8
  %v5598 = load i64, ptr %slot1019, align 8
  %cmp5599 = icmp ne i64 %v5598, 0
  %cv5600 = zext i1 %cmp5599 to i32
  store i32 %cv5600, ptr %slot1020, align 8
  %v5601 = load i32, ptr %slot1020, align 8
  %cv5602 = zext i32 %v5601 to i64
  %cond5603 = icmp ne i64 %cv5602, 0
  br i1 %cond5603, label %bb_rcgclear1328, label %bb_rcgcounted1328
bb_rcgcounted1328:
  %v5604 = load i64, ptr %slot1015, align 8
  %op5605 = sub i64 %v5604, 32
  store i64 %op5605, ptr %slot1021, align 8
  %v5606 = load i64, ptr %slot1015, align 8
  %p5607 = inttoptr i64 %v5606 to ptr
  %rgep5608 = getelementptr i8, ptr %p5607, i64 -32
  %ld5609 = load i64, ptr %rgep5608, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5609, ptr %slot1022, align 8
  %v5610 = load i64, ptr %slot1022, align 8
  %op5611 = sub i64 %v5610, 1
  store i64 %op5611, ptr %slot1023, align 8
  %v5612 = load i64, ptr %slot1023, align 8
  %cmp5613 = icmp eq i64 %v5612, 0
  %cv5614 = zext i1 %cmp5613 to i32
  store i32 %cv5614, ptr %slot1024, align 8
  %v5615 = load i32, ptr %slot1024, align 8
  %cv5616 = zext i32 %v5615 to i64
  %cond5617 = icmp ne i64 %cv5616, 0
  br i1 %cond5617, label %bb_rcglast1328, label %bb_rcgdec1328
bb_rcglast1328:
  %v5618 = load i64, ptr %slot1015, align 8
  %op5619 = sub i64 %v5618, 24
  store i64 %op5619, ptr %slot1025, align 8
  %v5620 = load i64, ptr %slot1015, align 8
  %p5621 = inttoptr i64 %v5620 to ptr
  %rgep5622 = getelementptr i8, ptr %p5621, i64 -24
  %ld5623 = load i64, ptr %rgep5622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5623, ptr %slot1026, align 8
  %v5624 = load i64, ptr %slot1026, align 8
  %cmp5625 = icmp ne i64 %v5624, 0
  %cv5626 = zext i1 %cmp5625 to i32
  store i32 %cv5626, ptr %slot1027, align 8
  %v5627 = load i32, ptr %slot1027, align 8
  %cv5628 = zext i32 %v5627 to i64
  %cond5629 = icmp ne i64 %cv5628, 0
  br i1 %cond5629, label %bb_rcgdec1328, label %bb_rcgslow1328
bb_rcgslow1328:
  %v5630 = load i64, ptr %slot1014, align 8
  %v5631 = load i64, ptr %slot997, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5630, i64 %v5631) nomerge, !dbg !140
  br label %bb_rcgdone1328
bb_rcgdec1328:
  %v5632 = load i64, ptr %slot1023, align 8
  %v5633 = load i64, ptr %slot1015, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  %rgep5635 = getelementptr i8, ptr %p5634, i64 -32
  store i64 %v5632, ptr %rgep5635, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1328
bb_rcgclear1328:
  %v5636 = load i64, ptr %slot997, align 8
  %p5637 = inttoptr i64 %v5636 to ptr
  store i64 0, ptr %p5637, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1328
bb_rcgdone1328:
  br label %bb_rcslotdone1297
bb_rcslotdone1297:
  %v5638 = load i64, ptr %slot28, align 8
  %p5639 = inttoptr i64 %v5638 to ptr
  %ld5640 = load i64, ptr %p5639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5640, ptr %slot1028, align 8
  %v5641 = load i64, ptr %slot11, align 8
  %p5642 = inttoptr i64 %v5641 to ptr
  %ld5643 = load i32, ptr %p5642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5643, ptr %slot1029, align 8
  %v5644 = load i32, ptr %slot1029, align 8
  %cv5645 = zext i32 %v5644 to i64
  %cond5646 = icmp ne i64 %cv5645, 0
  br i1 %cond5646, label %bb_rcslotdrop1338, label %bb_rcslotdone1338
bb_rcslotdrop1338:
  %v5647 = load i64, ptr %slot11, align 8
  %p5648 = inttoptr i64 %v5647 to ptr
  store i32 0, ptr %p5648, align 4, !alias.scope !3, !noalias !4
  %v5649 = load i64, ptr %slot27, align 8
  store i64 %v5649, ptr %slot1030, align 8
  %v5650 = load i64, ptr %slot12, align 8
  %p5651 = inttoptr i64 %v5650 to ptr
  %ld5652 = load i32, ptr %p5651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5652, ptr %slot1031, align 8
  %v5653 = load i32, ptr %slot1031, align 8
  %op5654 = and i32 %v5653, 28
  store i32 %op5654, ptr %slot1032, align 8
  %v5655 = load i32, ptr %slot1032, align 8
  %cv5656 = zext i32 %v5655 to i64
  %cond5657 = icmp ne i64 %cv5656, 0
  br i1 %cond5657, label %bb_rcslotrole1338, label %bb_rcslotowner1338
bb_rcslotrole1338:
  %v5658 = load i64, ptr %slot35, align 8
  store i64 %v5658, ptr %slot1033, align 8
  %v5659 = load i64, ptr %slot1030, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  %ld5661 = load i64, ptr %p5660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5661, ptr %slot1034, align 8
  %v5662 = load i64, ptr %slot1034, align 8
  %cmp5663 = icmp ne i64 %v5662, 0
  %cv5664 = zext i1 %cmp5663 to i32
  store i32 %cv5664, ptr %slot1035, align 8
  %v5665 = load i32, ptr %slot1035, align 8
  %cv5666 = zext i32 %v5665 to i64
  %cond5667 = icmp ne i64 %cv5666, 0
  br i1 %cond5667, label %bb_rcgnn1354, label %bb_rcgdone1354
bb_rcgnn1354:
  %v5668 = load i64, ptr %slot1034, align 8
  %op5669 = sub i64 %v5668, 16
  store i64 %op5669, ptr %slot1036, align 8
  %v5670 = load i64, ptr %slot1034, align 8
  %p5671 = inttoptr i64 %v5670 to ptr
  %rgep5672 = getelementptr i8, ptr %p5671, i64 -16
  %ld5673 = load i64, ptr %rgep5672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5673, ptr %slot1037, align 8
  %v5674 = load i64, ptr %slot1037, align 8
  %op5675 = and i64 %v5674, 4611686018427387906
  store i64 %op5675, ptr %slot1038, align 8
  %v5676 = load i64, ptr %slot1038, align 8
  %cmp5677 = icmp ne i64 %v5676, 0
  %cv5678 = zext i1 %cmp5677 to i32
  store i32 %cv5678, ptr %slot1039, align 8
  %v5679 = load i32, ptr %slot1039, align 8
  %cv5680 = zext i32 %v5679 to i64
  %cond5681 = icmp ne i64 %cv5680, 0
  br i1 %cond5681, label %bb_rcgclear1354, label %bb_rcgcounted1354
bb_rcgcounted1354:
  %v5682 = load i64, ptr %slot1034, align 8
  %op5683 = sub i64 %v5682, 24
  store i64 %op5683, ptr %slot1040, align 8
  %v5684 = load i64, ptr %slot1034, align 8
  %p5685 = inttoptr i64 %v5684 to ptr
  %rgep5686 = getelementptr i8, ptr %p5685, i64 -24
  %ld5687 = load i64, ptr %rgep5686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5687, ptr %slot1041, align 8
  %v5688 = load i64, ptr %slot1041, align 8
  %op5689 = sub i64 %v5688, 1
  store i64 %op5689, ptr %slot1042, align 8
  %v5690 = load i64, ptr %slot1042, align 8
  %cmp5691 = icmp eq i64 %v5690, 0
  %cv5692 = zext i1 %cmp5691 to i32
  store i32 %cv5692, ptr %slot1043, align 8
  %v5693 = load i32, ptr %slot1043, align 8
  %cv5694 = zext i32 %v5693 to i64
  %cond5695 = icmp ne i64 %cv5694, 0
  br i1 %cond5695, label %bb_rcglast1354, label %bb_rcgdec1354
bb_rcglast1354:
  %v5696 = load i64, ptr %slot1034, align 8
  %op5697 = sub i64 %v5696, 32
  store i64 %op5697, ptr %slot1044, align 8
  %v5698 = load i64, ptr %slot1034, align 8
  %p5699 = inttoptr i64 %v5698 to ptr
  %rgep5700 = getelementptr i8, ptr %p5699, i64 -32
  %ld5701 = load i64, ptr %rgep5700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5701, ptr %slot1045, align 8
  %v5702 = load i64, ptr %slot1045, align 8
  %cmp5703 = icmp ne i64 %v5702, 0
  %cv5704 = zext i1 %cmp5703 to i32
  store i32 %cv5704, ptr %slot1046, align 8
  %v5705 = load i32, ptr %slot1046, align 8
  %cv5706 = zext i32 %v5705 to i64
  %cond5707 = icmp ne i64 %cv5706, 0
  br i1 %cond5707, label %bb_rcgdec1354, label %bb_rcgslow1354
bb_rcgslow1354:
  %v5708 = load i64, ptr %slot1033, align 8
  %v5709 = load i64, ptr %slot1030, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5708, i64 %v5709) nomerge, !dbg !142
  br label %bb_rcgdone1354
bb_rcgdec1354:
  %v5710 = load i64, ptr %slot1042, align 8
  %v5711 = load i64, ptr %slot1034, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  %rgep5713 = getelementptr i8, ptr %p5712, i64 -24
  store i64 %v5710, ptr %rgep5713, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1354
bb_rcgclear1354:
  %v5714 = load i64, ptr %slot1030, align 8
  %p5715 = inttoptr i64 %v5714 to ptr
  store i64 0, ptr %p5715, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1354
bb_rcgdone1354:
  br label %bb_rcslotdone1338
bb_rcslotowner1338:
  %v5716 = load i64, ptr %slot35, align 8
  store i64 %v5716, ptr %slot1047, align 8
  %v5717 = load i64, ptr %slot1030, align 8
  %p5718 = inttoptr i64 %v5717 to ptr
  %ld5719 = load i64, ptr %p5718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5719, ptr %slot1048, align 8
  %v5720 = load i64, ptr %slot1048, align 8
  %cmp5721 = icmp ne i64 %v5720, 0
  %cv5722 = zext i1 %cmp5721 to i32
  store i32 %cv5722, ptr %slot1049, align 8
  %v5723 = load i32, ptr %slot1049, align 8
  %cv5724 = zext i32 %v5723 to i64
  %cond5725 = icmp ne i64 %cv5724, 0
  br i1 %cond5725, label %bb_rcgnn1369, label %bb_rcgdone1369
bb_rcgnn1369:
  %v5726 = load i64, ptr %slot1048, align 8
  %op5727 = sub i64 %v5726, 16
  store i64 %op5727, ptr %slot1050, align 8
  %v5728 = load i64, ptr %slot1048, align 8
  %p5729 = inttoptr i64 %v5728 to ptr
  %rgep5730 = getelementptr i8, ptr %p5729, i64 -16
  %ld5731 = load i64, ptr %rgep5730, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5731, ptr %slot1051, align 8
  %v5732 = load i64, ptr %slot1051, align 8
  %op5733 = and i64 %v5732, 4611686018427387906
  store i64 %op5733, ptr %slot1052, align 8
  %v5734 = load i64, ptr %slot1052, align 8
  %cmp5735 = icmp ne i64 %v5734, 0
  %cv5736 = zext i1 %cmp5735 to i32
  store i32 %cv5736, ptr %slot1053, align 8
  %v5737 = load i32, ptr %slot1053, align 8
  %cv5738 = zext i32 %v5737 to i64
  %cond5739 = icmp ne i64 %cv5738, 0
  br i1 %cond5739, label %bb_rcgclear1369, label %bb_rcgcounted1369
bb_rcgcounted1369:
  %v5740 = load i64, ptr %slot1048, align 8
  %op5741 = sub i64 %v5740, 32
  store i64 %op5741, ptr %slot1054, align 8
  %v5742 = load i64, ptr %slot1048, align 8
  %p5743 = inttoptr i64 %v5742 to ptr
  %rgep5744 = getelementptr i8, ptr %p5743, i64 -32
  %ld5745 = load i64, ptr %rgep5744, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5745, ptr %slot1055, align 8
  %v5746 = load i64, ptr %slot1055, align 8
  %op5747 = sub i64 %v5746, 1
  store i64 %op5747, ptr %slot1056, align 8
  %v5748 = load i64, ptr %slot1056, align 8
  %cmp5749 = icmp eq i64 %v5748, 0
  %cv5750 = zext i1 %cmp5749 to i32
  store i32 %cv5750, ptr %slot1057, align 8
  %v5751 = load i32, ptr %slot1057, align 8
  %cv5752 = zext i32 %v5751 to i64
  %cond5753 = icmp ne i64 %cv5752, 0
  br i1 %cond5753, label %bb_rcglast1369, label %bb_rcgdec1369
bb_rcglast1369:
  %v5754 = load i64, ptr %slot1048, align 8
  %op5755 = sub i64 %v5754, 24
  store i64 %op5755, ptr %slot1058, align 8
  %v5756 = load i64, ptr %slot1048, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  %rgep5758 = getelementptr i8, ptr %p5757, i64 -24
  %ld5759 = load i64, ptr %rgep5758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5759, ptr %slot1059, align 8
  %v5760 = load i64, ptr %slot1059, align 8
  %cmp5761 = icmp ne i64 %v5760, 0
  %cv5762 = zext i1 %cmp5761 to i32
  store i32 %cv5762, ptr %slot1060, align 8
  %v5763 = load i32, ptr %slot1060, align 8
  %cv5764 = zext i32 %v5763 to i64
  %cond5765 = icmp ne i64 %cv5764, 0
  br i1 %cond5765, label %bb_rcgdec1369, label %bb_rcgslow1369
bb_rcgslow1369:
  %v5766 = load i64, ptr %slot1047, align 8
  %v5767 = load i64, ptr %slot1030, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5766, i64 %v5767) nomerge, !dbg !142
  br label %bb_rcgdone1369
bb_rcgdec1369:
  %v5768 = load i64, ptr %slot1056, align 8
  %v5769 = load i64, ptr %slot1048, align 8
  %p5770 = inttoptr i64 %v5769 to ptr
  %rgep5771 = getelementptr i8, ptr %p5770, i64 -32
  store i64 %v5768, ptr %rgep5771, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1369
bb_rcgclear1369:
  %v5772 = load i64, ptr %slot1030, align 8
  %p5773 = inttoptr i64 %v5772 to ptr
  store i64 0, ptr %p5773, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1369
bb_rcgdone1369:
  br label %bb_rcslotdone1338
bb_rcslotdone1338:
  %v5774 = load i64, ptr %slot9, align 8
  %p5775 = inttoptr i64 %v5774 to ptr
  %ld5776 = load i32, ptr %p5775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5776, ptr %slot1061, align 8
  %v5777 = load i32, ptr %slot1061, align 8
  %cv5778 = zext i32 %v5777 to i64
  %cond5779 = icmp ne i64 %cv5778, 0
  br i1 %cond5779, label %bb_rcslotdrop1375, label %bb_rcslotdone1375
bb_rcslotdrop1375:
  %v5780 = load i64, ptr %slot9, align 8
  %p5781 = inttoptr i64 %v5780 to ptr
  store i32 0, ptr %p5781, align 4, !alias.scope !3, !noalias !4
  %v5782 = load i64, ptr %slot26, align 8
  store i64 %v5782, ptr %slot1062, align 8
  %v5783 = load i64, ptr %slot10, align 8
  %p5784 = inttoptr i64 %v5783 to ptr
  %ld5785 = load i32, ptr %p5784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5785, ptr %slot1063, align 8
  %v5786 = load i32, ptr %slot1063, align 8
  %op5787 = and i32 %v5786, 28
  store i32 %op5787, ptr %slot1064, align 8
  %v5788 = load i32, ptr %slot1064, align 8
  %cv5789 = zext i32 %v5788 to i64
  %cond5790 = icmp ne i64 %cv5789, 0
  br i1 %cond5790, label %bb_rcslotrole1375, label %bb_rcslotowner1375
bb_rcslotrole1375:
  %v5791 = load i64, ptr %slot35, align 8
  store i64 %v5791, ptr %slot1065, align 8
  %v5792 = load i64, ptr %slot1062, align 8
  %p5793 = inttoptr i64 %v5792 to ptr
  %ld5794 = load i64, ptr %p5793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5794, ptr %slot1066, align 8
  %v5795 = load i64, ptr %slot1066, align 8
  %cmp5796 = icmp ne i64 %v5795, 0
  %cv5797 = zext i1 %cmp5796 to i32
  store i32 %cv5797, ptr %slot1067, align 8
  %v5798 = load i32, ptr %slot1067, align 8
  %cv5799 = zext i32 %v5798 to i64
  %cond5800 = icmp ne i64 %cv5799, 0
  br i1 %cond5800, label %bb_rcgnn1391, label %bb_rcgdone1391
bb_rcgnn1391:
  %v5801 = load i64, ptr %slot1066, align 8
  %op5802 = sub i64 %v5801, 16
  store i64 %op5802, ptr %slot1068, align 8
  %v5803 = load i64, ptr %slot1066, align 8
  %p5804 = inttoptr i64 %v5803 to ptr
  %rgep5805 = getelementptr i8, ptr %p5804, i64 -16
  %ld5806 = load i64, ptr %rgep5805, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5806, ptr %slot1069, align 8
  %v5807 = load i64, ptr %slot1069, align 8
  %op5808 = and i64 %v5807, 4611686018427387906
  store i64 %op5808, ptr %slot1070, align 8
  %v5809 = load i64, ptr %slot1070, align 8
  %cmp5810 = icmp ne i64 %v5809, 0
  %cv5811 = zext i1 %cmp5810 to i32
  store i32 %cv5811, ptr %slot1071, align 8
  %v5812 = load i32, ptr %slot1071, align 8
  %cv5813 = zext i32 %v5812 to i64
  %cond5814 = icmp ne i64 %cv5813, 0
  br i1 %cond5814, label %bb_rcgclear1391, label %bb_rcgcounted1391
bb_rcgcounted1391:
  %v5815 = load i64, ptr %slot1066, align 8
  %op5816 = sub i64 %v5815, 24
  store i64 %op5816, ptr %slot1072, align 8
  %v5817 = load i64, ptr %slot1066, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  %rgep5819 = getelementptr i8, ptr %p5818, i64 -24
  %ld5820 = load i64, ptr %rgep5819, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5820, ptr %slot1073, align 8
  %v5821 = load i64, ptr %slot1073, align 8
  %op5822 = sub i64 %v5821, 1
  store i64 %op5822, ptr %slot1074, align 8
  %v5823 = load i64, ptr %slot1074, align 8
  %cmp5824 = icmp eq i64 %v5823, 0
  %cv5825 = zext i1 %cmp5824 to i32
  store i32 %cv5825, ptr %slot1075, align 8
  %v5826 = load i32, ptr %slot1075, align 8
  %cv5827 = zext i32 %v5826 to i64
  %cond5828 = icmp ne i64 %cv5827, 0
  br i1 %cond5828, label %bb_rcglast1391, label %bb_rcgdec1391
bb_rcglast1391:
  %v5829 = load i64, ptr %slot1066, align 8
  %op5830 = sub i64 %v5829, 32
  store i64 %op5830, ptr %slot1076, align 8
  %v5831 = load i64, ptr %slot1066, align 8
  %p5832 = inttoptr i64 %v5831 to ptr
  %rgep5833 = getelementptr i8, ptr %p5832, i64 -32
  %ld5834 = load i64, ptr %rgep5833, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5834, ptr %slot1077, align 8
  %v5835 = load i64, ptr %slot1077, align 8
  %cmp5836 = icmp ne i64 %v5835, 0
  %cv5837 = zext i1 %cmp5836 to i32
  store i32 %cv5837, ptr %slot1078, align 8
  %v5838 = load i32, ptr %slot1078, align 8
  %cv5839 = zext i32 %v5838 to i64
  %cond5840 = icmp ne i64 %cv5839, 0
  br i1 %cond5840, label %bb_rcgdec1391, label %bb_rcgslow1391
bb_rcgslow1391:
  %v5841 = load i64, ptr %slot1065, align 8
  %v5842 = load i64, ptr %slot1062, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v5841, i64 %v5842) nomerge, !dbg !142
  br label %bb_rcgdone1391
bb_rcgdec1391:
  %v5843 = load i64, ptr %slot1074, align 8
  %v5844 = load i64, ptr %slot1066, align 8
  %p5845 = inttoptr i64 %v5844 to ptr
  %rgep5846 = getelementptr i8, ptr %p5845, i64 -24
  store i64 %v5843, ptr %rgep5846, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1391
bb_rcgclear1391:
  %v5847 = load i64, ptr %slot1062, align 8
  %p5848 = inttoptr i64 %v5847 to ptr
  store i64 0, ptr %p5848, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1391
bb_rcgdone1391:
  br label %bb_rcslotdone1375
bb_rcslotowner1375:
  %v5849 = load i64, ptr %slot35, align 8
  store i64 %v5849, ptr %slot1079, align 8
  %v5850 = load i64, ptr %slot1062, align 8
  %p5851 = inttoptr i64 %v5850 to ptr
  %ld5852 = load i64, ptr %p5851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5852, ptr %slot1080, align 8
  %v5853 = load i64, ptr %slot1080, align 8
  %cmp5854 = icmp ne i64 %v5853, 0
  %cv5855 = zext i1 %cmp5854 to i32
  store i32 %cv5855, ptr %slot1081, align 8
  %v5856 = load i32, ptr %slot1081, align 8
  %cv5857 = zext i32 %v5856 to i64
  %cond5858 = icmp ne i64 %cv5857, 0
  br i1 %cond5858, label %bb_rcgnn1406, label %bb_rcgdone1406
bb_rcgnn1406:
  %v5859 = load i64, ptr %slot1080, align 8
  %op5860 = sub i64 %v5859, 16
  store i64 %op5860, ptr %slot1082, align 8
  %v5861 = load i64, ptr %slot1080, align 8
  %p5862 = inttoptr i64 %v5861 to ptr
  %rgep5863 = getelementptr i8, ptr %p5862, i64 -16
  %ld5864 = load i64, ptr %rgep5863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5864, ptr %slot1083, align 8
  %v5865 = load i64, ptr %slot1083, align 8
  %op5866 = and i64 %v5865, 4611686018427387906
  store i64 %op5866, ptr %slot1084, align 8
  %v5867 = load i64, ptr %slot1084, align 8
  %cmp5868 = icmp ne i64 %v5867, 0
  %cv5869 = zext i1 %cmp5868 to i32
  store i32 %cv5869, ptr %slot1085, align 8
  %v5870 = load i32, ptr %slot1085, align 8
  %cv5871 = zext i32 %v5870 to i64
  %cond5872 = icmp ne i64 %cv5871, 0
  br i1 %cond5872, label %bb_rcgclear1406, label %bb_rcgcounted1406
bb_rcgcounted1406:
  %v5873 = load i64, ptr %slot1080, align 8
  %op5874 = sub i64 %v5873, 32
  store i64 %op5874, ptr %slot1086, align 8
  %v5875 = load i64, ptr %slot1080, align 8
  %p5876 = inttoptr i64 %v5875 to ptr
  %rgep5877 = getelementptr i8, ptr %p5876, i64 -32
  %ld5878 = load i64, ptr %rgep5877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5878, ptr %slot1087, align 8
  %v5879 = load i64, ptr %slot1087, align 8
  %op5880 = sub i64 %v5879, 1
  store i64 %op5880, ptr %slot1088, align 8
  %v5881 = load i64, ptr %slot1088, align 8
  %cmp5882 = icmp eq i64 %v5881, 0
  %cv5883 = zext i1 %cmp5882 to i32
  store i32 %cv5883, ptr %slot1089, align 8
  %v5884 = load i32, ptr %slot1089, align 8
  %cv5885 = zext i32 %v5884 to i64
  %cond5886 = icmp ne i64 %cv5885, 0
  br i1 %cond5886, label %bb_rcglast1406, label %bb_rcgdec1406
bb_rcglast1406:
  %v5887 = load i64, ptr %slot1080, align 8
  %op5888 = sub i64 %v5887, 24
  store i64 %op5888, ptr %slot1090, align 8
  %v5889 = load i64, ptr %slot1080, align 8
  %p5890 = inttoptr i64 %v5889 to ptr
  %rgep5891 = getelementptr i8, ptr %p5890, i64 -24
  %ld5892 = load i64, ptr %rgep5891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5892, ptr %slot1091, align 8
  %v5893 = load i64, ptr %slot1091, align 8
  %cmp5894 = icmp ne i64 %v5893, 0
  %cv5895 = zext i1 %cmp5894 to i32
  store i32 %cv5895, ptr %slot1092, align 8
  %v5896 = load i32, ptr %slot1092, align 8
  %cv5897 = zext i32 %v5896 to i64
  %cond5898 = icmp ne i64 %cv5897, 0
  br i1 %cond5898, label %bb_rcgdec1406, label %bb_rcgslow1406
bb_rcgslow1406:
  %v5899 = load i64, ptr %slot1079, align 8
  %v5900 = load i64, ptr %slot1062, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v5899, i64 %v5900) nomerge, !dbg !142
  br label %bb_rcgdone1406
bb_rcgdec1406:
  %v5901 = load i64, ptr %slot1088, align 8
  %v5902 = load i64, ptr %slot1080, align 8
  %p5903 = inttoptr i64 %v5902 to ptr
  %rgep5904 = getelementptr i8, ptr %p5903, i64 -32
  store i64 %v5901, ptr %rgep5904, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1406
bb_rcgclear1406:
  %v5905 = load i64, ptr %slot1062, align 8
  %p5906 = inttoptr i64 %v5905 to ptr
  store i64 0, ptr %p5906, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1406
bb_rcgdone1406:
  br label %bb_rcslotdone1375
bb_rcslotdone1375:
  %v5907 = load i64, ptr %slot7, align 8
  %p5908 = inttoptr i64 %v5907 to ptr
  %ld5909 = load i32, ptr %p5908, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5909, ptr %slot1093, align 8
  %v5910 = load i32, ptr %slot1093, align 8
  %cv5911 = zext i32 %v5910 to i64
  %cond5912 = icmp ne i64 %cv5911, 0
  br i1 %cond5912, label %bb_rcslotdrop1412, label %bb_rcslotdone1412
bb_rcslotdrop1412:
  %v5913 = load i64, ptr %slot7, align 8
  %p5914 = inttoptr i64 %v5913 to ptr
  store i32 0, ptr %p5914, align 4, !alias.scope !3, !noalias !4
  %v5915 = load i64, ptr %slot25, align 8
  store i64 %v5915, ptr %slot1094, align 8
  %v5916 = load i64, ptr %slot8, align 8
  %p5917 = inttoptr i64 %v5916 to ptr
  %ld5918 = load i32, ptr %p5917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5918, ptr %slot1095, align 8
  %v5919 = load i32, ptr %slot1095, align 8
  %op5920 = and i32 %v5919, 28
  store i32 %op5920, ptr %slot1096, align 8
  %v5921 = load i32, ptr %slot1096, align 8
  %cv5922 = zext i32 %v5921 to i64
  %cond5923 = icmp ne i64 %cv5922, 0
  br i1 %cond5923, label %bb_rcslotrole1412, label %bb_rcslotowner1412
bb_rcslotrole1412:
  %v5924 = load i64, ptr %slot35, align 8
  store i64 %v5924, ptr %slot1097, align 8
  %v5925 = load i64, ptr %slot1094, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  %ld5927 = load i64, ptr %p5926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5927, ptr %slot1098, align 8
  %v5928 = load i64, ptr %slot1098, align 8
  %cmp5929 = icmp ne i64 %v5928, 0
  %cv5930 = zext i1 %cmp5929 to i32
  store i32 %cv5930, ptr %slot1099, align 8
  %v5931 = load i32, ptr %slot1099, align 8
  %cv5932 = zext i32 %v5931 to i64
  %cond5933 = icmp ne i64 %cv5932, 0
  br i1 %cond5933, label %bb_rcgnn1428, label %bb_rcgdone1428
bb_rcgnn1428:
  %v5934 = load i64, ptr %slot1098, align 8
  %op5935 = sub i64 %v5934, 16
  store i64 %op5935, ptr %slot1100, align 8
  %v5936 = load i64, ptr %slot1098, align 8
  %p5937 = inttoptr i64 %v5936 to ptr
  %rgep5938 = getelementptr i8, ptr %p5937, i64 -16
  %ld5939 = load i64, ptr %rgep5938, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5939, ptr %slot1101, align 8
  %v5940 = load i64, ptr %slot1101, align 8
  %op5941 = and i64 %v5940, 4611686018427387906
  store i64 %op5941, ptr %slot1102, align 8
  %v5942 = load i64, ptr %slot1102, align 8
  %cmp5943 = icmp ne i64 %v5942, 0
  %cv5944 = zext i1 %cmp5943 to i32
  store i32 %cv5944, ptr %slot1103, align 8
  %v5945 = load i32, ptr %slot1103, align 8
  %cv5946 = zext i32 %v5945 to i64
  %cond5947 = icmp ne i64 %cv5946, 0
  br i1 %cond5947, label %bb_rcgclear1428, label %bb_rcgcounted1428
bb_rcgcounted1428:
  %v5948 = load i64, ptr %slot1098, align 8
  %op5949 = sub i64 %v5948, 24
  store i64 %op5949, ptr %slot1104, align 8
  %v5950 = load i64, ptr %slot1098, align 8
  %p5951 = inttoptr i64 %v5950 to ptr
  %rgep5952 = getelementptr i8, ptr %p5951, i64 -24
  %ld5953 = load i64, ptr %rgep5952, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5953, ptr %slot1105, align 8
  %v5954 = load i64, ptr %slot1105, align 8
  %op5955 = sub i64 %v5954, 1
  store i64 %op5955, ptr %slot1106, align 8
  %v5956 = load i64, ptr %slot1106, align 8
  %cmp5957 = icmp eq i64 %v5956, 0
  %cv5958 = zext i1 %cmp5957 to i32
  store i32 %cv5958, ptr %slot1107, align 8
  %v5959 = load i32, ptr %slot1107, align 8
  %cv5960 = zext i32 %v5959 to i64
  %cond5961 = icmp ne i64 %cv5960, 0
  br i1 %cond5961, label %bb_rcglast1428, label %bb_rcgdec1428
bb_rcglast1428:
  %v5962 = load i64, ptr %slot1098, align 8
  %op5963 = sub i64 %v5962, 32
  store i64 %op5963, ptr %slot1108, align 8
  %v5964 = load i64, ptr %slot1098, align 8
  %p5965 = inttoptr i64 %v5964 to ptr
  %rgep5966 = getelementptr i8, ptr %p5965, i64 -32
  %ld5967 = load i64, ptr %rgep5966, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5967, ptr %slot1109, align 8
  %v5968 = load i64, ptr %slot1109, align 8
  %cmp5969 = icmp ne i64 %v5968, 0
  %cv5970 = zext i1 %cmp5969 to i32
  store i32 %cv5970, ptr %slot1110, align 8
  %v5971 = load i32, ptr %slot1110, align 8
  %cv5972 = zext i32 %v5971 to i64
  %cond5973 = icmp ne i64 %cv5972, 0
  br i1 %cond5973, label %bb_rcgdec1428, label %bb_rcgslow1428
bb_rcgslow1428:
  %v5974 = load i64, ptr %slot1097, align 8
  %v5975 = load i64, ptr %slot1094, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v5974, i64 %v5975) nomerge, !dbg !142
  br label %bb_rcgdone1428
bb_rcgdec1428:
  %v5976 = load i64, ptr %slot1106, align 8
  %v5977 = load i64, ptr %slot1098, align 8
  %p5978 = inttoptr i64 %v5977 to ptr
  %rgep5979 = getelementptr i8, ptr %p5978, i64 -24
  store i64 %v5976, ptr %rgep5979, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1428
bb_rcgclear1428:
  %v5980 = load i64, ptr %slot1094, align 8
  %p5981 = inttoptr i64 %v5980 to ptr
  store i64 0, ptr %p5981, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1428
bb_rcgdone1428:
  br label %bb_rcslotdone1412
bb_rcslotowner1412:
  %v5982 = load i64, ptr %slot35, align 8
  store i64 %v5982, ptr %slot1111, align 8
  %v5983 = load i64, ptr %slot1094, align 8
  %p5984 = inttoptr i64 %v5983 to ptr
  %ld5985 = load i64, ptr %p5984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5985, ptr %slot1112, align 8
  %v5986 = load i64, ptr %slot1112, align 8
  %cmp5987 = icmp ne i64 %v5986, 0
  %cv5988 = zext i1 %cmp5987 to i32
  store i32 %cv5988, ptr %slot1113, align 8
  %v5989 = load i32, ptr %slot1113, align 8
  %cv5990 = zext i32 %v5989 to i64
  %cond5991 = icmp ne i64 %cv5990, 0
  br i1 %cond5991, label %bb_rcgnn1443, label %bb_rcgdone1443
bb_rcgnn1443:
  %v5992 = load i64, ptr %slot1112, align 8
  %op5993 = sub i64 %v5992, 16
  store i64 %op5993, ptr %slot1114, align 8
  %v5994 = load i64, ptr %slot1112, align 8
  %p5995 = inttoptr i64 %v5994 to ptr
  %rgep5996 = getelementptr i8, ptr %p5995, i64 -16
  %ld5997 = load i64, ptr %rgep5996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5997, ptr %slot1115, align 8
  %v5998 = load i64, ptr %slot1115, align 8
  %op5999 = and i64 %v5998, 4611686018427387906
  store i64 %op5999, ptr %slot1116, align 8
  %v6000 = load i64, ptr %slot1116, align 8
  %cmp6001 = icmp ne i64 %v6000, 0
  %cv6002 = zext i1 %cmp6001 to i32
  store i32 %cv6002, ptr %slot1117, align 8
  %v6003 = load i32, ptr %slot1117, align 8
  %cv6004 = zext i32 %v6003 to i64
  %cond6005 = icmp ne i64 %cv6004, 0
  br i1 %cond6005, label %bb_rcgclear1443, label %bb_rcgcounted1443
bb_rcgcounted1443:
  %v6006 = load i64, ptr %slot1112, align 8
  %op6007 = sub i64 %v6006, 32
  store i64 %op6007, ptr %slot1118, align 8
  %v6008 = load i64, ptr %slot1112, align 8
  %p6009 = inttoptr i64 %v6008 to ptr
  %rgep6010 = getelementptr i8, ptr %p6009, i64 -32
  %ld6011 = load i64, ptr %rgep6010, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6011, ptr %slot1119, align 8
  %v6012 = load i64, ptr %slot1119, align 8
  %op6013 = sub i64 %v6012, 1
  store i64 %op6013, ptr %slot1120, align 8
  %v6014 = load i64, ptr %slot1120, align 8
  %cmp6015 = icmp eq i64 %v6014, 0
  %cv6016 = zext i1 %cmp6015 to i32
  store i32 %cv6016, ptr %slot1121, align 8
  %v6017 = load i32, ptr %slot1121, align 8
  %cv6018 = zext i32 %v6017 to i64
  %cond6019 = icmp ne i64 %cv6018, 0
  br i1 %cond6019, label %bb_rcglast1443, label %bb_rcgdec1443
bb_rcglast1443:
  %v6020 = load i64, ptr %slot1112, align 8
  %op6021 = sub i64 %v6020, 24
  store i64 %op6021, ptr %slot1122, align 8
  %v6022 = load i64, ptr %slot1112, align 8
  %p6023 = inttoptr i64 %v6022 to ptr
  %rgep6024 = getelementptr i8, ptr %p6023, i64 -24
  %ld6025 = load i64, ptr %rgep6024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6025, ptr %slot1123, align 8
  %v6026 = load i64, ptr %slot1123, align 8
  %cmp6027 = icmp ne i64 %v6026, 0
  %cv6028 = zext i1 %cmp6027 to i32
  store i32 %cv6028, ptr %slot1124, align 8
  %v6029 = load i32, ptr %slot1124, align 8
  %cv6030 = zext i32 %v6029 to i64
  %cond6031 = icmp ne i64 %cv6030, 0
  br i1 %cond6031, label %bb_rcgdec1443, label %bb_rcgslow1443
bb_rcgslow1443:
  %v6032 = load i64, ptr %slot1111, align 8
  %v6033 = load i64, ptr %slot1094, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v6032, i64 %v6033) nomerge, !dbg !142
  br label %bb_rcgdone1443
bb_rcgdec1443:
  %v6034 = load i64, ptr %slot1120, align 8
  %v6035 = load i64, ptr %slot1112, align 8
  %p6036 = inttoptr i64 %v6035 to ptr
  %rgep6037 = getelementptr i8, ptr %p6036, i64 -32
  store i64 %v6034, ptr %rgep6037, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1443
bb_rcgclear1443:
  %v6038 = load i64, ptr %slot1094, align 8
  %p6039 = inttoptr i64 %v6038 to ptr
  store i64 0, ptr %p6039, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1443
bb_rcgdone1443:
  br label %bb_rcslotdone1412
bb_rcslotdone1412:
  %v6040 = load i64, ptr %slot1028, align 8
  ret i64 %v6040
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_30bdecd870d597c62d1c30c02882c43b1f27244eec6e99c1398f7fc84cf4ce25 = external global i8, align 8
@myl_lit_651dfa874c87674e57d05784fbb331bf215d6ec2b7d4c57db6383d02b47d316a = external global i8, align 8
@myl_lit_8d330aa2f416754a391eaf7715dfedb3b3b4f6f34dd9cc9ef16b81d95dfd3df3 = external global i8, align 8
@myl_lit_fadbbcee37090aefcabf2bf0f6a9366f5f34ef8c1ccde596b7696a8936daffcc = external global i8, align 8
@myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b = external global i8, align 8
@myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64, i64, i64, i64)
declare ptr @myl_native_bytes_encode(ptr, ptr)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare ptr @myl_native_text_join(ptr, ptr, ptr)
declare ptr @myl_native_text_scalar(ptr, ptr, i32)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64, i64)
declare i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64, i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_09a1ee193e9d9f1530906298fd9acc278ce79721e1d4545c3c0962b7198c2ff1", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_09a1ee193e9d9f1530906298fd9acc278ce79721e1d4545c3c0962b7198c2ff1", linkageName: "myl_f_09a1ee193e9d9f1530906298fd9acc278ce79721e1d4545c3c0962b7198c2ff1", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16986436870101239776, i64 0, !"myl_f_09a1ee193e9d9f1530906298fd9acc278ce79721e1d4545c3c0962b7198c2ff1"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!122 = !DILocation(line: 12, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!124 = !DILocation(line: 13, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!126 = !DILocation(line: 16, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!128 = !DILocation(line: 19, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!130 = !DILocation(line: 20, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!132 = !DILocation(line: 23, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!134 = !DILocation(line: 26, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!136 = !DILocation(line: 27, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!138 = !DILocation(line: 28, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!140 = !DILocation(line: 29, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!142 = !DILocation(line: 30, column: 0, scope: !143)
