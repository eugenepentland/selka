target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_77c8aeea8f087d048765e2c779dcec5d681bbe3fe04487c962362b93ca437442(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %callresult38 = alloca [16 x i8], align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %callresult118 = alloca [40 x i8], align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %callresult166 = alloca [16 x i8], align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v225 = load i64, ptr %slot1, align 8
  %op226 = add i64 %v225, 32
  store i64 %op226, ptr %slot3, align 8
  %mem227 = alloca i8, i64 16, align 8
  %ptr228 = ptrtoint ptr %mem227 to i64
  store i64 %ptr228, ptr %slot4, align 8
  %mem229 = alloca i8, i64 8, align 8
  %ptr230 = ptrtoint ptr %mem229 to i64
  store i64 %ptr230, ptr %slot5, align 8
  %mem231 = alloca i8, i64 8, align 8
  %ptr232 = ptrtoint ptr %mem231 to i64
  store i64 %ptr232, ptr %slot6, align 8
  %mem233 = alloca i8, i64 8, align 8
  %ptr234 = ptrtoint ptr %mem233 to i64
  store i64 %ptr234, ptr %slot7, align 8
  %mem235 = alloca i8, i64 8, align 8
  %ptr236 = ptrtoint ptr %mem235 to i64
  store i64 %ptr236, ptr %slot8, align 8
  %mem237 = alloca i8, i64 8, align 8
  %ptr238 = ptrtoint ptr %mem237 to i64
  store i64 %ptr238, ptr %slot9, align 8
  %mem239 = alloca i8, i64 8, align 8
  %ptr240 = ptrtoint ptr %mem239 to i64
  store i64 %ptr240, ptr %slot10, align 8
  %mem241 = alloca i8, i64 8, align 8
  %ptr242 = ptrtoint ptr %mem241 to i64
  store i64 %ptr242, ptr %slot11, align 8
  %mem243 = alloca i8, i64 312, align 8
  %ptr244 = ptrtoint ptr %mem243 to i64
  store i64 %ptr244, ptr %slot12, align 8
  %mem245 = alloca i8, i64 312, align 8
  %ptr246 = ptrtoint ptr %mem245 to i64
  store i64 %ptr246, ptr %slot13, align 8
  %mem247 = alloca i8, i64 8, align 8
  %ptr248 = ptrtoint ptr %mem247 to i64
  store i64 %ptr248, ptr %slot14, align 8
  %mem249 = alloca i8, i64 8, align 8
  %ptr250 = ptrtoint ptr %mem249 to i64
  store i64 %ptr250, ptr %slot15, align 8
  %mem251 = alloca i8, i64 40, align 8
  %ptr252 = ptrtoint ptr %mem251 to i64
  store i64 %ptr252, ptr %slot16, align 8
  %mem253 = alloca i8, i64 8, align 8
  %ptr254 = ptrtoint ptr %mem253 to i64
  store i64 %ptr254, ptr %slot17, align 8
  %mem255 = alloca i8, i64 8, align 8
  %ptr256 = ptrtoint ptr %mem255 to i64
  store i64 %ptr256, ptr %slot18, align 8
  %mem257 = alloca i8, i64 8, align 8
  %ptr258 = ptrtoint ptr %mem257 to i64
  store i64 %ptr258, ptr %slot19, align 8
  %mem259 = alloca i8, i64 8, align 8
  %ptr260 = ptrtoint ptr %mem259 to i64
  store i64 %ptr260, ptr %slot20, align 8
  %mem261 = alloca i8, i64 8, align 8
  %ptr262 = ptrtoint ptr %mem261 to i64
  store i64 %ptr262, ptr %slot21, align 8
  %mem263 = alloca i8, i64 16, align 8
  %ptr264 = ptrtoint ptr %mem263 to i64
  store i64 %ptr264, ptr %slot22, align 8
  %mem265 = alloca i8, i64 312, align 8
  %ptr266 = ptrtoint ptr %mem265 to i64
  store i64 %ptr266, ptr %slot23, align 8
  %mem267 = alloca i8, i64 312, align 8
  %ptr268 = ptrtoint ptr %mem267 to i64
  store i64 %ptr268, ptr %slot24, align 8
  %mem269 = alloca i8, i64 312, align 8
  %ptr270 = ptrtoint ptr %mem269 to i64
  store i64 %ptr270, ptr %slot25, align 8
  %mem271 = alloca i8, i64 312, align 8
  %ptr272 = ptrtoint ptr %mem271 to i64
  store i64 %ptr272, ptr %slot26, align 8
  %mem273 = alloca i8, i64 16, align 8
  %ptr274 = ptrtoint ptr %mem273 to i64
  store i64 %ptr274, ptr %slot27, align 8
  %mem275 = alloca i8, i64 16, align 8
  %ptr276 = ptrtoint ptr %mem275 to i64
  store i64 %ptr276, ptr %slot28, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem277 = alloca i8, i64 8, align 8
  %ptr278 = ptrtoint ptr %mem277 to i64
  store i64 %ptr278, ptr %slot29, align 8
  %v279 = load i64, ptr %slot1, align 8
  %op280 = add i64 %v279, 64
  store i64 %op280, ptr %slot30, align 8
  %v281 = load i64, ptr %slot30, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !4, !noalias !3
  store i64 %ld283, ptr %slot31, align 8
  %stack284 = call ptr @llvm.stacksave()
  %stackaddr285 = ptrtoint ptr %stack284 to i64
  %v286 = load i64, ptr %slot31, align 8
  %cmp287 = icmp ult i64 %stackaddr285, %v286
  %cv288 = zext i1 %cmp287 to i64
  store i64 %cv288, ptr %slot32, align 8
  %v289 = load i64, ptr %slot32, align 8
  %cond290 = icmp ne i64 %v289, 0
  br i1 %cond290, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v291 = load i64, ptr %slot1, align 8
  %p292 = inttoptr i64 %v291 to ptr
  call void @myl_qbe_fail_frame(ptr %p292) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v293 = load i64, ptr %slot2, align 8
  %v294 = load i64, ptr %slot14, align 8
  %p295 = inttoptr i64 %v294 to ptr
  store i64 %v293, ptr %p295, align 8, !alias.scope !3, !noalias !4
  %v296 = load i64, ptr %slot1, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %call298 = call ptr @myl_qbe_heap(ptr %p297) nomerge, !dbg !112
  %calladdr299 = ptrtoint ptr %call298 to i64
  store i64 %calladdr299, ptr %slot33, align 8
  %v300 = load i64, ptr %slot1, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %call302 = call i64 @myl_qbe_region_mark(ptr %p301) nomerge, !dbg !112
  store i64 %call302, ptr %slot34, align 8
  %v303 = load i64, ptr %slot5, align 8
  %p304 = inttoptr i64 %v303 to ptr
  store i32 0, ptr %p304, align 4, !alias.scope !3, !noalias !4
  %v305 = load i64, ptr %slot6, align 8
  %p306 = inttoptr i64 %v305 to ptr
  store i32 0, ptr %p306, align 4, !alias.scope !3, !noalias !4
  %v307 = load i64, ptr %slot7, align 8
  %p308 = inttoptr i64 %v307 to ptr
  store i32 0, ptr %p308, align 4, !alias.scope !3, !noalias !4
  %v309 = load i64, ptr %slot8, align 8
  %p310 = inttoptr i64 %v309 to ptr
  store i32 0, ptr %p310, align 4, !alias.scope !3, !noalias !4
  %v311 = load i64, ptr %slot9, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i32 0, ptr %p312, align 4, !alias.scope !3, !noalias !4
  %v313 = load i64, ptr %slot10, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i32 0, ptr %p314, align 4, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot11, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i32 0, ptr %p316, align 4, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot6, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i32 2, ptr %p318, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v319 = load i64, ptr %slot14, align 8
  %p320 = inttoptr i64 %v319 to ptr
  %ld321 = load i64, ptr %p320, align 8, !alias.scope !3, !noalias !4
  store i64 %ld321, ptr %slot35, align 8
  %v322 = load i64, ptr %slot35, align 8
  %v323 = load i64, ptr %slot18, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i64 %v322, ptr %p324, align 8, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot18, align 8
  %p326 = inttoptr i64 %v325 to ptr
  %ld327 = load i64, ptr %p326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld327, ptr %slot36, align 8
  %v328 = load i64, ptr %slot1, align 8
  %v329 = load i64, ptr %slot36, align 8
  %call330 = call { i64, i64 } @myl_f_3366aa3455c03ea2dc76bc5b993933cc133e3c3405b7857cda1785b0c17f8295(i64 %v328, i64 %v329) nomerge, !dbg !114
  store { i64, i64 } %call330, ptr %callresult38, align 8
  %addr331 = ptrtoint ptr %callresult38 to i64
  store i64 %addr331, ptr %slot37, align 8
  %v332 = load i64, ptr %slot37, align 8
  %v333 = load i64, ptr %slot18, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 %v332, ptr %p334, align 8, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot7, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %ld337 = load i32, ptr %p336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld337, ptr %slot39, align 8
  %v338 = load i32, ptr %slot39, align 8
  %cv339 = zext i32 %v338 to i64
  %cond340 = icmp ne i64 %cv339, 0
  br i1 %cond340, label %bb_rcslotdrop14, label %bb_rcslotdone14
bb_rcslotdrop14:
  %v341 = load i64, ptr %slot7, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i32 0, ptr %p342, align 4, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot12, align 8
  store i64 %v343, ptr %slot40, align 8
  %v344 = load i64, ptr %slot8, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %ld346 = load i32, ptr %p345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld346, ptr %slot41, align 8
  %v347 = load i32, ptr %slot41, align 8
  %op348 = and i32 %v347, 28
  store i32 %op348, ptr %slot42, align 8
  %v349 = load i32, ptr %slot42, align 8
  %cv350 = zext i32 %v349 to i64
  %cond351 = icmp ne i64 %cv350, 0
  br i1 %cond351, label %bb_rcslotrole14, label %bb_rcslotowner14
bb_rcslotrole14:
  %v352 = load i64, ptr %slot33, align 8
  store i64 %v352, ptr %slot43, align 8
  %v353 = load i64, ptr %slot43, align 8
  %v354 = load i64, ptr %slot40, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v353, i64 %v354) nomerge, !dbg !114
  br label %bb_rcslotdone14
bb_rcslotowner14:
  %v355 = load i64, ptr %slot33, align 8
  store i64 %v355, ptr %slot44, align 8
  %v356 = load i64, ptr %slot44, align 8
  %v357 = load i64, ptr %slot40, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v356, i64 %v357) nomerge, !dbg !114
  br label %bb_rcslotdone14
bb_rcslotdone14:
  %v358 = load i64, ptr %slot18, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld360, ptr %slot45, align 8
  %v361 = load i64, ptr %slot45, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %ld363 = load i32, ptr %p362, align 4
  %ext364 = zext i32 %ld363 to i64
  store i64 %ext364, ptr %slot46, align 8
  %v365 = load i64, ptr %slot46, align 8
  %cmp366 = icmp eq i64 %v365, 0
  %cv367 = zext i1 %cmp366 to i64
  store i64 %cv367, ptr %slot47, align 8
  %v368 = load i64, ptr %slot47, align 8
  %cond369 = icmp ne i64 %v368, 0
  br i1 %cond369, label %bb_rctryok22, label %bb_rctryerror22
bb_rctryerror22:
  %p370 = inttoptr i64 ptrtoint (ptr @myl_f_77c8aeea8f087d048765e2c779dcec5d681bbe3fe04487c962362b93ca437442_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p370, i64 12884901890) "call-inline-cost"="0", !dbg !116
  %v371 = load i64, ptr %slot45, align 8
  %op372 = add i64 %v371, 8
  store i64 %op372, ptr %slot48, align 8
  %v373 = load i64, ptr %slot22, align 8
  store i64 %v373, ptr %slot49, align 8
  %v374 = load i64, ptr %slot49, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i64 0, ptr %p375, align 8, !alias.scope !3, !noalias !4
  %v376 = load i64, ptr %slot49, align 8
  %p378 = inttoptr i64 %v376 to ptr
  %gep379 = getelementptr i8, ptr %p378, i64 8
  %op377 = ptrtoint ptr %gep379 to i64
  store i64 %op377, ptr %slot50, align 8
  %v380 = load i64, ptr %slot50, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i64 0, ptr %p381, align 8, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot49, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i32 1, ptr %p383, align 4, !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot49, align 8
  %p386 = inttoptr i64 %v384 to ptr
  %gep387 = getelementptr i8, ptr %p386, i64 8
  %op385 = ptrtoint ptr %gep387 to i64
  store i64 %op385, ptr %slot51, align 8
  %v388 = load i64, ptr %slot11, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i32 1, ptr %p389, align 4, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot34, align 8
  store i64 %v390, ptr %slot52, align 8
  %v391 = load i64, ptr %slot49, align 8
  %v392 = load i64, ptr %slot18, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i64 %v391, ptr %p393, align 8, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rctryok22:
  %v394 = load i64, ptr %slot22, align 8
  store i64 %v394, ptr %slot53, align 8
  %v395 = load i64, ptr %slot53, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i64 0, ptr %p396, align 8, !alias.scope !3, !noalias !4
  %v397 = load i64, ptr %slot11, align 8
  %p398 = inttoptr i64 %v397 to ptr
  store i32 1, ptr %p398, align 4, !alias.scope !3, !noalias !4
  %v399 = load i64, ptr %slot45, align 8
  %op400 = add i64 %v399, 8
  store i64 %op400, ptr %slot54, align 8
  %v401 = load i64, ptr %slot34, align 8
  store i64 %v401, ptr %slot55, align 8
  %v402 = load i64, ptr %slot54, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8
  store i64 %ld404, ptr %slot56, align 8
  %v405 = load i64, ptr %slot56, align 8
  %v406 = load i64, ptr %slot53, align 8
  %p407 = inttoptr i64 %v406 to ptr
  store i64 %v405, ptr %p407, align 8, !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot53, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot57, align 8
  %v411 = load i64, ptr %slot57, align 8
  %v412 = load i64, ptr %slot18, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 %v411, ptr %p413, align 8, !alias.scope !3, !noalias !4
  br label %bb_i5
bb_i4:
  %v414 = load i64, ptr %slot18, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot58, align 8
  %v417 = load i64, ptr %slot7, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i32, ptr %p418, align 4, !alias.scope !3, !noalias !4
  store i32 %ld419, ptr %slot59, align 8
  %v420 = load i32, ptr %slot59, align 8
  %cv421 = zext i32 %v420 to i64
  %cond422 = icmp ne i64 %cv421, 0
  br i1 %cond422, label %bb_rcslotdrop41, label %bb_rcslotdone41
bb_rcslotdrop41:
  %v423 = load i64, ptr %slot7, align 8
  %p424 = inttoptr i64 %v423 to ptr
  store i32 0, ptr %p424, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone41
bb_rcslotdone41:
  %v425 = load i64, ptr %slot5, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i32, ptr %p426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld427, ptr %slot60, align 8
  %v428 = load i32, ptr %slot60, align 8
  %cv429 = zext i32 %v428 to i64
  %cond430 = icmp ne i64 %cv429, 0
  br i1 %cond430, label %bb_rcslotdrop44, label %bb_rcslotdone44
bb_rcslotdrop44:
  %v431 = load i64, ptr %slot5, align 8
  %p432 = inttoptr i64 %v431 to ptr
  store i32 0, ptr %p432, align 4, !alias.scope !3, !noalias !4
  %v433 = load i64, ptr %slot16, align 8
  store i64 %v433, ptr %slot61, align 8
  %v434 = load i64, ptr %slot6, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %ld436 = load i32, ptr %p435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld436, ptr %slot62, align 8
  %v437 = load i32, ptr %slot62, align 8
  %op438 = and i32 %v437, 28
  store i32 %op438, ptr %slot63, align 8
  %v439 = load i32, ptr %slot63, align 8
  %cv440 = zext i32 %v439 to i64
  %cond441 = icmp ne i64 %cv440, 0
  br i1 %cond441, label %bb_rcslotrole44, label %bb_rcslotowner44
bb_rcslotrole44:
  %v442 = load i64, ptr %slot33, align 8
  store i64 %v442, ptr %slot64, align 8
  %v443 = load i64, ptr %slot64, align 8
  %v444 = load i64, ptr %slot61, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v443, i64 %v444) nomerge, !dbg !118
  br label %bb_rcslotdone44
bb_rcslotowner44:
  %v445 = load i64, ptr %slot33, align 8
  store i64 %v445, ptr %slot65, align 8
  %v446 = load i64, ptr %slot65, align 8
  %v447 = load i64, ptr %slot61, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v446, i64 %v447) nomerge, !dbg !118
  br label %bb_rcslotdone44
bb_rcslotdone44:
  %v448 = load i64, ptr %slot58, align 8
  %p449 = inttoptr i64 %v448 to ptr
  %ret450 = load { i64, i64 }, ptr %p449, align 8
  ret { i64, i64 } %ret450
bb_i5:
  %v451 = load i64, ptr %slot18, align 8
  %p452 = inttoptr i64 %v451 to ptr
  %ld453 = load i64, ptr %p452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld453, ptr %slot66, align 8
  %v454 = load i64, ptr %slot66, align 8
  %v455 = load i64, ptr %slot15, align 8
  %p456 = inttoptr i64 %v455 to ptr
  store i64 %v454, ptr %p456, align 8, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_i6:
  %v457 = load i64, ptr %slot14, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %ld459 = load i64, ptr %p458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld459, ptr %slot67, align 8
  %v460 = load i64, ptr %slot67, align 8
  %v461 = load i64, ptr %slot18, align 8
  %p462 = inttoptr i64 %v461 to ptr
  store i64 %v460, ptr %p462, align 8, !alias.scope !3, !noalias !4
  %v463 = load i64, ptr %slot23, align 8
  store i64 %v463, ptr %slot68, align 8
  %v464 = load i64, ptr %slot68, align 8
  %p465 = inttoptr i64 %v464 to ptr
  store i32 0, ptr %p465, align 4, !alias.scope !3, !noalias !4
  %v466 = load i64, ptr %slot68, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i32 15, ptr %p467, align 4, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot68, align 8
  %v469 = load i64, ptr %slot19, align 8
  %p470 = inttoptr i64 %v469 to ptr
  store i64 %v468, ptr %p470, align 8, !alias.scope !3, !noalias !4
  %v471 = load i64, ptr %slot18, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %ld473 = load i64, ptr %p472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld473, ptr %slot69, align 8
  %v474 = load i64, ptr %slot19, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld476, ptr %slot70, align 8
  %v477 = load i64, ptr %slot1, align 8
  %v478 = load i64, ptr %slot69, align 8
  %v479 = load i64, ptr %slot70, align 8
  %call480 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v477, i64 %v478, i64 %v479) nomerge, !dbg !120
  store i64 %call480, ptr %slot71, align 8
  %v481 = load i64, ptr %slot71, align 8
  %v482 = load i64, ptr %slot18, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i64 %v481, ptr %p483, align 8, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot7, align 8
  %p485 = inttoptr i64 %v484 to ptr
  %ld486 = load i32, ptr %p485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld486, ptr %slot72, align 8
  %v487 = load i32, ptr %slot72, align 8
  %cv488 = zext i32 %v487 to i64
  %cond489 = icmp ne i64 %cv488, 0
  br i1 %cond489, label %bb_rcslotdrop68, label %bb_rcslotdone68
bb_rcslotdrop68:
  %v490 = load i64, ptr %slot7, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i32 0, ptr %p491, align 4, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot12, align 8
  store i64 %v492, ptr %slot73, align 8
  %v493 = load i64, ptr %slot8, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %ld495 = load i32, ptr %p494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld495, ptr %slot74, align 8
  %v496 = load i32, ptr %slot74, align 8
  %op497 = and i32 %v496, 28
  store i32 %op497, ptr %slot75, align 8
  %v498 = load i32, ptr %slot75, align 8
  %cv499 = zext i32 %v498 to i64
  %cond500 = icmp ne i64 %cv499, 0
  br i1 %cond500, label %bb_rcslotrole68, label %bb_rcslotowner68
bb_rcslotrole68:
  %v501 = load i64, ptr %slot33, align 8
  store i64 %v501, ptr %slot76, align 8
  %v502 = load i64, ptr %slot76, align 8
  %v503 = load i64, ptr %slot73, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v502, i64 %v503) nomerge, !dbg !120
  br label %bb_rcslotdone68
bb_rcslotowner68:
  %v504 = load i64, ptr %slot33, align 8
  store i64 %v504, ptr %slot77, align 8
  %v505 = load i64, ptr %slot77, align 8
  %v506 = load i64, ptr %slot73, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v505, i64 %v506) nomerge, !dbg !120
  br label %bb_rcslotdone68
bb_rcslotdone68:
  %v507 = load i64, ptr %slot18, align 8
  %p508 = inttoptr i64 %v507 to ptr
  %ld509 = load i64, ptr %p508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld509, ptr %slot78, align 8
  %v510 = load i64, ptr %slot78, align 8
  %cond511 = icmp ne i64 %v510, 0
  br i1 %cond511, label %bb_next76, label %bb_i12
bb_next76:
  %v512 = load i64, ptr %slot18, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i64 1, ptr %p513, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i12:
  %v514 = load i64, ptr %slot14, align 8
  %p515 = inttoptr i64 %v514 to ptr
  %ld516 = load i64, ptr %p515, align 8, !alias.scope !3, !noalias !4
  store i64 %ld516, ptr %slot79, align 8
  %v517 = load i64, ptr %slot79, align 8
  %v518 = load i64, ptr %slot18, align 8
  %p519 = inttoptr i64 %v518 to ptr
  store i64 %v517, ptr %p519, align 8, !alias.scope !3, !noalias !4
  %v520 = load i64, ptr %slot24, align 8
  store i64 %v520, ptr %slot80, align 8
  %v521 = load i64, ptr %slot80, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i32 0, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot80, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 16, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot80, align 8
  %v526 = load i64, ptr %slot19, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i64 %v525, ptr %p527, align 8, !alias.scope !3, !noalias !4
  %v528 = load i64, ptr %slot18, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot81, align 8
  %v531 = load i64, ptr %slot19, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i64, ptr %p532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld533, ptr %slot82, align 8
  %v534 = load i64, ptr %slot1, align 8
  %v535 = load i64, ptr %slot81, align 8
  %v536 = load i64, ptr %slot82, align 8
  %call537 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v534, i64 %v535, i64 %v536) nomerge, !dbg !122
  store i64 %call537, ptr %slot83, align 8
  %v538 = load i64, ptr %slot83, align 8
  %v539 = load i64, ptr %slot18, align 8
  %p540 = inttoptr i64 %v539 to ptr
  store i64 %v538, ptr %p540, align 8, !alias.scope !3, !noalias !4
  %v541 = load i64, ptr %slot7, align 8
  %p542 = inttoptr i64 %v541 to ptr
  %ld543 = load i32, ptr %p542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld543, ptr %slot84, align 8
  %v544 = load i32, ptr %slot84, align 8
  %cv545 = zext i32 %v544 to i64
  %cond546 = icmp ne i64 %cv545, 0
  br i1 %cond546, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v547 = load i64, ptr %slot7, align 8
  %p548 = inttoptr i64 %v547 to ptr
  store i32 0, ptr %p548, align 4, !alias.scope !3, !noalias !4
  %v549 = load i64, ptr %slot12, align 8
  store i64 %v549, ptr %slot85, align 8
  %v550 = load i64, ptr %slot8, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i32, ptr %p551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld552, ptr %slot86, align 8
  %v553 = load i32, ptr %slot86, align 8
  %op554 = and i32 %v553, 28
  store i32 %op554, ptr %slot87, align 8
  %v555 = load i32, ptr %slot87, align 8
  %cv556 = zext i32 %v555 to i64
  %cond557 = icmp ne i64 %cv556, 0
  br i1 %cond557, label %bb_rcslotrole83, label %bb_rcslotowner83
bb_rcslotrole83:
  %v558 = load i64, ptr %slot33, align 8
  store i64 %v558, ptr %slot88, align 8
  %v559 = load i64, ptr %slot88, align 8
  %v560 = load i64, ptr %slot85, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v559, i64 %v560) nomerge, !dbg !122
  br label %bb_rcslotdone83
bb_rcslotowner83:
  %v561 = load i64, ptr %slot33, align 8
  store i64 %v561, ptr %slot89, align 8
  %v562 = load i64, ptr %slot89, align 8
  %v563 = load i64, ptr %slot85, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v562, i64 %v563) nomerge, !dbg !122
  br label %bb_rcslotdone83
bb_rcslotdone83:
  br label %bb_i15
bb_i15:
  %v564 = load i64, ptr %slot18, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %ld566 = load i64, ptr %p565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld566, ptr %slot90, align 8
  %v567 = load i64, ptr %slot90, align 8
  %cond568 = icmp ne i64 %v567, 0
  br i1 %cond568, label %bb_next91, label %bb_i18
bb_next91:
  %v569 = load i64, ptr %slot18, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i64 1, ptr %p570, align 8, !alias.scope !3, !noalias !4
  br label %bb_i21
bb_i18:
  %v571 = load i64, ptr %slot14, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot91, align 8
  %v574 = load i64, ptr %slot91, align 8
  %v575 = load i64, ptr %slot18, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot25, align 8
  store i64 %v577, ptr %slot92, align 8
  %v578 = load i64, ptr %slot92, align 8
  %p579 = inttoptr i64 %v578 to ptr
  store i32 0, ptr %p579, align 4, !alias.scope !3, !noalias !4
  %v580 = load i64, ptr %slot92, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i32 17, ptr %p581, align 4, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot92, align 8
  %v583 = load i64, ptr %slot19, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i64 %v582, ptr %p584, align 8, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot18, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %ld587 = load i64, ptr %p586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld587, ptr %slot93, align 8
  %v588 = load i64, ptr %slot19, align 8
  %p589 = inttoptr i64 %v588 to ptr
  %ld590 = load i64, ptr %p589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld590, ptr %slot94, align 8
  %v591 = load i64, ptr %slot1, align 8
  %v592 = load i64, ptr %slot93, align 8
  %v593 = load i64, ptr %slot94, align 8
  %call594 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v591, i64 %v592, i64 %v593) nomerge, !dbg !124
  store i64 %call594, ptr %slot95, align 8
  %v595 = load i64, ptr %slot95, align 8
  %v596 = load i64, ptr %slot18, align 8
  %p597 = inttoptr i64 %v596 to ptr
  store i64 %v595, ptr %p597, align 8, !alias.scope !3, !noalias !4
  %v598 = load i64, ptr %slot7, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i32, ptr %p599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld600, ptr %slot96, align 8
  %v601 = load i32, ptr %slot96, align 8
  %cv602 = zext i32 %v601 to i64
  %cond603 = icmp ne i64 %cv602, 0
  br i1 %cond603, label %bb_rcslotdrop98, label %bb_rcslotdone98
bb_rcslotdrop98:
  %v604 = load i64, ptr %slot7, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i32 0, ptr %p605, align 4, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot12, align 8
  store i64 %v606, ptr %slot97, align 8
  %v607 = load i64, ptr %slot8, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i32, ptr %p608, align 4, !alias.scope !3, !noalias !4
  store i32 %ld609, ptr %slot98, align 8
  %v610 = load i32, ptr %slot98, align 8
  %op611 = and i32 %v610, 28
  store i32 %op611, ptr %slot99, align 8
  %v612 = load i32, ptr %slot99, align 8
  %cv613 = zext i32 %v612 to i64
  %cond614 = icmp ne i64 %cv613, 0
  br i1 %cond614, label %bb_rcslotrole98, label %bb_rcslotowner98
bb_rcslotrole98:
  %v615 = load i64, ptr %slot33, align 8
  store i64 %v615, ptr %slot100, align 8
  %v616 = load i64, ptr %slot100, align 8
  %v617 = load i64, ptr %slot97, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v616, i64 %v617) nomerge, !dbg !124
  br label %bb_rcslotdone98
bb_rcslotowner98:
  %v618 = load i64, ptr %slot33, align 8
  store i64 %v618, ptr %slot101, align 8
  %v619 = load i64, ptr %slot101, align 8
  %v620 = load i64, ptr %slot97, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v619, i64 %v620) nomerge, !dbg !124
  br label %bb_rcslotdone98
bb_rcslotdone98:
  br label %bb_i21
bb_i21:
  %v621 = load i64, ptr %slot18, align 8
  %p622 = inttoptr i64 %v621 to ptr
  %ld623 = load i64, ptr %p622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld623, ptr %slot102, align 8
  %v624 = load i64, ptr %slot102, align 8
  %cond625 = icmp ne i64 %v624, 0
  br i1 %cond625, label %bb_next106, label %bb_i24
bb_next106:
  %v626 = load i64, ptr %slot18, align 8
  %p627 = inttoptr i64 %v626 to ptr
  store i64 1, ptr %p627, align 8, !alias.scope !3, !noalias !4
  br label %bb_i27
bb_i24:
  %v628 = load i64, ptr %slot14, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %ld630 = load i64, ptr %p629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld630, ptr %slot103, align 8
  %v631 = load i64, ptr %slot103, align 8
  %v632 = load i64, ptr %slot18, align 8
  %p633 = inttoptr i64 %v632 to ptr
  store i64 %v631, ptr %p633, align 8, !alias.scope !3, !noalias !4
  %v634 = load i64, ptr %slot26, align 8
  store i64 %v634, ptr %slot104, align 8
  %v635 = load i64, ptr %slot104, align 8
  %p636 = inttoptr i64 %v635 to ptr
  store i32 0, ptr %p636, align 4, !alias.scope !3, !noalias !4
  %v637 = load i64, ptr %slot104, align 8
  %p638 = inttoptr i64 %v637 to ptr
  store i32 18, ptr %p638, align 4, !alias.scope !3, !noalias !4
  %v639 = load i64, ptr %slot104, align 8
  %v640 = load i64, ptr %slot19, align 8
  %p641 = inttoptr i64 %v640 to ptr
  store i64 %v639, ptr %p641, align 8, !alias.scope !3, !noalias !4
  %v642 = load i64, ptr %slot18, align 8
  %p643 = inttoptr i64 %v642 to ptr
  %ld644 = load i64, ptr %p643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld644, ptr %slot105, align 8
  %v645 = load i64, ptr %slot19, align 8
  %p646 = inttoptr i64 %v645 to ptr
  %ld647 = load i64, ptr %p646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld647, ptr %slot106, align 8
  %v648 = load i64, ptr %slot1, align 8
  %v649 = load i64, ptr %slot105, align 8
  %v650 = load i64, ptr %slot106, align 8
  %call651 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v648, i64 %v649, i64 %v650) nomerge, !dbg !126
  store i64 %call651, ptr %slot107, align 8
  %v652 = load i64, ptr %slot107, align 8
  %v653 = load i64, ptr %slot18, align 8
  %p654 = inttoptr i64 %v653 to ptr
  store i64 %v652, ptr %p654, align 8, !alias.scope !3, !noalias !4
  %v655 = load i64, ptr %slot7, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i32, ptr %p656, align 4, !alias.scope !3, !noalias !4
  store i32 %ld657, ptr %slot108, align 8
  %v658 = load i32, ptr %slot108, align 8
  %cv659 = zext i32 %v658 to i64
  %cond660 = icmp ne i64 %cv659, 0
  br i1 %cond660, label %bb_rcslotdrop113, label %bb_rcslotdone113
bb_rcslotdrop113:
  %v661 = load i64, ptr %slot7, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i32 0, ptr %p662, align 4, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot12, align 8
  store i64 %v663, ptr %slot109, align 8
  %v664 = load i64, ptr %slot8, align 8
  %p665 = inttoptr i64 %v664 to ptr
  %ld666 = load i32, ptr %p665, align 4, !alias.scope !3, !noalias !4
  store i32 %ld666, ptr %slot110, align 8
  %v667 = load i32, ptr %slot110, align 8
  %op668 = and i32 %v667, 28
  store i32 %op668, ptr %slot111, align 8
  %v669 = load i32, ptr %slot111, align 8
  %cv670 = zext i32 %v669 to i64
  %cond671 = icmp ne i64 %cv670, 0
  br i1 %cond671, label %bb_rcslotrole113, label %bb_rcslotowner113
bb_rcslotrole113:
  %v672 = load i64, ptr %slot33, align 8
  store i64 %v672, ptr %slot112, align 8
  %v673 = load i64, ptr %slot112, align 8
  %v674 = load i64, ptr %slot109, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v673, i64 %v674) nomerge, !dbg !126
  br label %bb_rcslotdone113
bb_rcslotowner113:
  %v675 = load i64, ptr %slot33, align 8
  store i64 %v675, ptr %slot113, align 8
  %v676 = load i64, ptr %slot113, align 8
  %v677 = load i64, ptr %slot109, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v676, i64 %v677) nomerge, !dbg !126
  br label %bb_rcslotdone113
bb_rcslotdone113:
  br label %bb_i27
bb_i27:
  %v678 = load i64, ptr %slot18, align 8
  %p679 = inttoptr i64 %v678 to ptr
  %ld680 = load i64, ptr %p679, align 8, !alias.scope !3, !noalias !4
  store i64 %ld680, ptr %slot114, align 8
  %v681 = load i64, ptr %slot114, align 8
  %cond682 = icmp ne i64 %v681, 0
  br i1 %cond682, label %bb_next121, label %bb_i44
bb_next121:
  %v683 = load i64, ptr %slot14, align 8
  %p684 = inttoptr i64 %v683 to ptr
  %ld685 = load i64, ptr %p684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld685, ptr %slot115, align 8
  %v686 = load i64, ptr %slot115, align 8
  %v687 = load i64, ptr %slot18, align 8
  %p688 = inttoptr i64 %v687 to ptr
  store i64 %v686, ptr %p688, align 8, !alias.scope !3, !noalias !4
  %v689 = load i64, ptr %slot18, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i64, ptr %p690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld691, ptr %slot116, align 8
  %v692 = load i64, ptr %slot1, align 8
  %v693 = load i64, ptr %slot116, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult118, i64 %v692, i64 %v693) nomerge, !dbg !128
  %addr694 = ptrtoint ptr %callresult118 to i64
  store i64 %addr694, ptr %slot117, align 8
  %v695 = load i64, ptr %slot117, align 8
  %v696 = load i64, ptr %slot18, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i64 %v695, ptr %p697, align 8, !alias.scope !3, !noalias !4
  %v698 = load i64, ptr %slot18, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i64, ptr %p699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld700, ptr %slot119, align 8
  %v701 = load i64, ptr %slot13, align 8
  store i64 %v701, ptr %slot120, align 8
  %v702 = load i64, ptr %slot33, align 8
  %v703 = load i64, ptr %slot120, align 8
  %v704 = load i64, ptr %slot119, align 8
  %call705 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v702, i64 %v703, i64 %v704) nomerge, !dbg !128
  store i32 %call705, ptr %slot121, align 8
  %v706 = load i32, ptr %slot121, align 8
  %cv707 = zext i32 %v706 to i64
  %cond708 = icmp ne i64 %cv707, 0
  br i1 %cond708, label %bb_rcsuccess127, label %bb_rcfailure127
bb_rcfailure127:
  %v709 = load i64, ptr %slot33, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %call711 = call i32 @myl_rc_take_failure(ptr %p710) nomerge, !dbg !128
  store i32 %call711, ptr %slot122, align 8
  %v712 = load i64, ptr %slot1, align 8
  %p713 = inttoptr i64 %v712 to ptr
  %v714 = load i32, ptr %slot122, align 8
  %call715 = call i32 @myl_qbe_rc_status(ptr %p713, i32 %v714) nomerge, !dbg !128
  store i32 %call715, ptr %slot123, align 8
  br label %bb_failure
bb_rcsuccess127:
  %v716 = load i64, ptr %slot10, align 8
  %p717 = inttoptr i64 %v716 to ptr
  store i32 2, ptr %p717, align 4, !alias.scope !3, !noalias !4
  %v718 = load i64, ptr %slot10, align 8
  %p719 = inttoptr i64 %v718 to ptr
  store i32 16, ptr %p719, align 4, !alias.scope !3, !noalias !4
  %v720 = load i64, ptr %slot9, align 8
  %p721 = inttoptr i64 %v720 to ptr
  store i32 1, ptr %p721, align 4, !alias.scope !3, !noalias !4
  %v722 = load i64, ptr %slot7, align 8
  %p723 = inttoptr i64 %v722 to ptr
  %ld724 = load i32, ptr %p723, align 4, !alias.scope !3, !noalias !4
  store i32 %ld724, ptr %slot124, align 8
  %v725 = load i32, ptr %slot124, align 8
  %cv726 = zext i32 %v725 to i64
  %cond727 = icmp ne i64 %cv726, 0
  br i1 %cond727, label %bb_rcslotdrop135, label %bb_rcslotdone135
bb_rcslotdrop135:
  %v728 = load i64, ptr %slot7, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i32 0, ptr %p729, align 4, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot12, align 8
  store i64 %v730, ptr %slot125, align 8
  %v731 = load i64, ptr %slot8, align 8
  %p732 = inttoptr i64 %v731 to ptr
  %ld733 = load i32, ptr %p732, align 4, !alias.scope !3, !noalias !4
  store i32 %ld733, ptr %slot126, align 8
  %v734 = load i32, ptr %slot126, align 8
  %op735 = and i32 %v734, 28
  store i32 %op735, ptr %slot127, align 8
  %v736 = load i32, ptr %slot127, align 8
  %cv737 = zext i32 %v736 to i64
  %cond738 = icmp ne i64 %cv737, 0
  br i1 %cond738, label %bb_rcslotrole135, label %bb_rcslotowner135
bb_rcslotrole135:
  %v739 = load i64, ptr %slot33, align 8
  store i64 %v739, ptr %slot128, align 8
  %v740 = load i64, ptr %slot128, align 8
  %v741 = load i64, ptr %slot125, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v740, i64 %v741) nomerge, !dbg !128
  br label %bb_rcslotdone135
bb_rcslotowner135:
  %v742 = load i64, ptr %slot33, align 8
  store i64 %v742, ptr %slot129, align 8
  %v743 = load i64, ptr %slot129, align 8
  %v744 = load i64, ptr %slot125, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v743, i64 %v744) nomerge, !dbg !128
  br label %bb_rcslotdone135
bb_rcslotdone135:
  %v745 = load i64, ptr %slot12, align 8
  store i64 %v745, ptr %slot130, align 8
  %v746 = load i64, ptr %slot13, align 8
  store i64 %v746, ptr %slot131, align 8
  %v747 = load i64, ptr %slot131, align 8
  %v748 = load i64, ptr %slot130, align 8
  %p749 = inttoptr i64 %v747 to ptr
  %p750 = inttoptr i64 %v748 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p750, ptr %p749, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot8, align 8
  %p752 = inttoptr i64 %v751 to ptr
  store i32 2, ptr %p752, align 4, !alias.scope !3, !noalias !4
  %v753 = load i64, ptr %slot10, align 8
  %p754 = inttoptr i64 %v753 to ptr
  %ld755 = load i32, ptr %p754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld755, ptr %slot132, align 8
  %v756 = load i32, ptr %slot132, align 8
  %v757 = load i64, ptr %slot8, align 8
  %p758 = inttoptr i64 %v757 to ptr
  store i32 %v756, ptr %p758, align 4, !alias.scope !3, !noalias !4
  %v759 = load i64, ptr %slot9, align 8
  %p760 = inttoptr i64 %v759 to ptr
  store i32 0, ptr %p760, align 4, !alias.scope !3, !noalias !4
  %v761 = load i64, ptr %slot7, align 8
  %p762 = inttoptr i64 %v761 to ptr
  store i32 1, ptr %p762, align 4, !alias.scope !3, !noalias !4
  %v763 = load i64, ptr %slot130, align 8
  %v764 = load i64, ptr %slot18, align 8
  %p765 = inttoptr i64 %v764 to ptr
  store i64 %v763, ptr %p765, align 8, !alias.scope !3, !noalias !4
  %v766 = load i64, ptr %slot18, align 8
  %p767 = inttoptr i64 %v766 to ptr
  %ld768 = load i64, ptr %p767, align 8, !alias.scope !3, !noalias !4
  store i64 %ld768, ptr %slot133, align 8
  %v769 = load i64, ptr %slot7, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %ld771 = load i32, ptr %p770, align 4, !alias.scope !3, !noalias !4
  store i32 %ld771, ptr %slot134, align 8
  %v772 = load i64, ptr %slot8, align 8
  %p773 = inttoptr i64 %v772 to ptr
  %ld774 = load i32, ptr %p773, align 4, !alias.scope !3, !noalias !4
  store i32 %ld774, ptr %slot135, align 8
  %v775 = load i32, ptr %slot135, align 8
  %op776 = and i32 %v775, 24
  store i32 %op776, ptr %slot135, align 8
  %v777 = load i32, ptr %slot135, align 8
  %cmp778 = icmp eq i32 %v777, 0
  %cv779 = zext i1 %cmp778 to i32
  store i32 %cv779, ptr %slot136, align 8
  %v780 = load i32, ptr %slot134, align 8
  %v781 = load i32, ptr %slot136, align 8
  %op782 = and i32 %v780, %v781
  store i32 %op782, ptr %slot137, align 8
  %v783 = load i32, ptr %slot137, align 8
  %cv784 = zext i32 %v783 to i64
  %cond785 = icmp ne i64 %cv784, 0
  br i1 %cond785, label %bb_rctake151, label %bb_rccopy151
bb_rctake151:
  %v786 = load i64, ptr %slot13, align 8
  store i64 %v786, ptr %slot138, align 8
  %v787 = load i64, ptr %slot34, align 8
  store i64 %v787, ptr %slot139, align 8
  %v788 = load i64, ptr %slot33, align 8
  %v789 = load i64, ptr %slot138, align 8
  %v790 = load i64, ptr %slot133, align 8
  %v791 = load i64, ptr %slot139, align 8
  %cv792 = trunc i64 %v791 to i32
  %call793 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v788, i64 %v789, i64 %v790, i32 %cv792) nomerge, !dbg !130
  store i32 %call793, ptr %slot140, align 8
  %v794 = load i32, ptr %slot140, align 8
  %cv795 = zext i32 %v794 to i64
  %cond796 = icmp ne i64 %cv795, 0
  br i1 %cond796, label %bb_rcsuccess161, label %bb_rcfailure161
bb_rcfailure161:
  %v797 = load i64, ptr %slot33, align 8
  %p798 = inttoptr i64 %v797 to ptr
  %call799 = call i32 @myl_rc_take_failure(ptr %p798) nomerge, !dbg !130
  store i32 %call799, ptr %slot141, align 8
  %v800 = load i64, ptr %slot1, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %v802 = load i32, ptr %slot141, align 8
  %call803 = call i32 @myl_qbe_rc_status(ptr %p801, i32 %v802) nomerge, !dbg !130
  store i32 %call803, ptr %slot142, align 8
  br label %bb_failure
bb_rcsuccess161:
  %v804 = load i64, ptr %slot7, align 8
  %p805 = inttoptr i64 %v804 to ptr
  store i32 0, ptr %p805, align 4, !alias.scope !3, !noalias !4
  %v806 = load i64, ptr %slot10, align 8
  %p807 = inttoptr i64 %v806 to ptr
  store i32 2, ptr %p807, align 4, !alias.scope !3, !noalias !4
  %v808 = load i64, ptr %slot9, align 8
  %p809 = inttoptr i64 %v808 to ptr
  store i32 1, ptr %p809, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared151
bb_rccopy151:
  %v810 = load i64, ptr %slot13, align 8
  store i64 %v810, ptr %slot143, align 8
  %v811 = load i64, ptr %slot34, align 8
  store i64 %v811, ptr %slot144, align 8
  %v812 = load i64, ptr %slot33, align 8
  %v813 = load i64, ptr %slot143, align 8
  %v814 = load i64, ptr %slot133, align 8
  %v815 = load i64, ptr %slot144, align 8
  %cv816 = trunc i64 %v815 to i32
  %call817 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v812, i64 %v813, i64 %v814, i32 %cv816) nomerge, !dbg !130
  store i32 %call817, ptr %slot145, align 8
  %v818 = load i32, ptr %slot145, align 8
  %cv819 = zext i32 %v818 to i64
  %cond820 = icmp ne i64 %cv819, 0
  br i1 %cond820, label %bb_rcsuccess170, label %bb_rcfailure170
bb_rcfailure170:
  %v821 = load i64, ptr %slot33, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %call823 = call i32 @myl_rc_take_failure(ptr %p822) nomerge, !dbg !130
  store i32 %call823, ptr %slot146, align 8
  %v824 = load i64, ptr %slot1, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %v826 = load i32, ptr %slot146, align 8
  %call827 = call i32 @myl_qbe_rc_status(ptr %p825, i32 %v826) nomerge, !dbg !130
  store i32 %call827, ptr %slot147, align 8
  br label %bb_failure
bb_rcsuccess170:
  %v828 = load i64, ptr %slot10, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i32 2, ptr %p829, align 4, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot9, align 8
  %p831 = inttoptr i64 %v830 to ptr
  store i32 1, ptr %p831, align 4, !alias.scope !3, !noalias !4
  %v832 = load i64, ptr %slot7, align 8
  %p833 = inttoptr i64 %v832 to ptr
  %ld834 = load i32, ptr %p833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld834, ptr %slot148, align 8
  %v835 = load i32, ptr %slot148, align 8
  %cv836 = zext i32 %v835 to i64
  %cond837 = icmp ne i64 %cv836, 0
  br i1 %cond837, label %bb_rcslotdrop177, label %bb_rcslotdone177
bb_rcslotdrop177:
  %v838 = load i64, ptr %slot7, align 8
  %p839 = inttoptr i64 %v838 to ptr
  store i32 0, ptr %p839, align 4, !alias.scope !3, !noalias !4
  %v840 = load i64, ptr %slot12, align 8
  store i64 %v840, ptr %slot149, align 8
  %v841 = load i64, ptr %slot8, align 8
  %p842 = inttoptr i64 %v841 to ptr
  %ld843 = load i32, ptr %p842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld843, ptr %slot150, align 8
  %v844 = load i32, ptr %slot150, align 8
  %op845 = and i32 %v844, 28
  store i32 %op845, ptr %slot151, align 8
  %v846 = load i32, ptr %slot151, align 8
  %cv847 = zext i32 %v846 to i64
  %cond848 = icmp ne i64 %cv847, 0
  br i1 %cond848, label %bb_rcslotrole177, label %bb_rcslotowner177
bb_rcslotrole177:
  %v849 = load i64, ptr %slot33, align 8
  store i64 %v849, ptr %slot152, align 8
  %v850 = load i64, ptr %slot152, align 8
  %v851 = load i64, ptr %slot149, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v850, i64 %v851) nomerge, !dbg !130
  br label %bb_rcslotdone177
bb_rcslotowner177:
  %v852 = load i64, ptr %slot33, align 8
  store i64 %v852, ptr %slot153, align 8
  %v853 = load i64, ptr %slot153, align 8
  %v854 = load i64, ptr %slot149, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v853, i64 %v854) nomerge, !dbg !130
  br label %bb_rcslotdone177
bb_rcslotdone177:
  br label %bb_rcprepared151
bb_rcprepared151:
  %v855 = load i64, ptr %slot5, align 8
  %p856 = inttoptr i64 %v855 to ptr
  %ld857 = load i32, ptr %p856, align 4, !alias.scope !3, !noalias !4
  store i32 %ld857, ptr %slot154, align 8
  %v858 = load i32, ptr %slot154, align 8
  %cv859 = zext i32 %v858 to i64
  %cond860 = icmp ne i64 %cv859, 0
  br i1 %cond860, label %bb_rcslotdrop187, label %bb_rcslotdone187
bb_rcslotdrop187:
  %v861 = load i64, ptr %slot5, align 8
  %p862 = inttoptr i64 %v861 to ptr
  store i32 0, ptr %p862, align 4, !alias.scope !3, !noalias !4
  %v863 = load i64, ptr %slot16, align 8
  store i64 %v863, ptr %slot155, align 8
  %v864 = load i64, ptr %slot6, align 8
  %p865 = inttoptr i64 %v864 to ptr
  %ld866 = load i32, ptr %p865, align 4, !alias.scope !3, !noalias !4
  store i32 %ld866, ptr %slot156, align 8
  %v867 = load i32, ptr %slot156, align 8
  %op868 = and i32 %v867, 28
  store i32 %op868, ptr %slot157, align 8
  %v869 = load i32, ptr %slot157, align 8
  %cv870 = zext i32 %v869 to i64
  %cond871 = icmp ne i64 %cv870, 0
  br i1 %cond871, label %bb_rcslotrole187, label %bb_rcslotowner187
bb_rcslotrole187:
  %v872 = load i64, ptr %slot33, align 8
  store i64 %v872, ptr %slot158, align 8
  %v873 = load i64, ptr %slot158, align 8
  %v874 = load i64, ptr %slot155, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v873, i64 %v874) nomerge, !dbg !130
  br label %bb_rcslotdone187
bb_rcslotowner187:
  %v875 = load i64, ptr %slot33, align 8
  store i64 %v875, ptr %slot159, align 8
  %v876 = load i64, ptr %slot159, align 8
  %v877 = load i64, ptr %slot155, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v876, i64 %v877) nomerge, !dbg !130
  br label %bb_rcslotdone187
bb_rcslotdone187:
  %v878 = load i64, ptr %slot16, align 8
  store i64 %v878, ptr %slot160, align 8
  %v879 = load i64, ptr %slot13, align 8
  store i64 %v879, ptr %slot161, align 8
  %v880 = load i64, ptr %slot161, align 8
  %v881 = load i64, ptr %slot160, align 8
  %p882 = inttoptr i64 %v880 to ptr
  %p883 = inttoptr i64 %v881 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p883, ptr %p882, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v884 = load i64, ptr %slot9, align 8
  %p885 = inttoptr i64 %v884 to ptr
  store i32 0, ptr %p885, align 4, !alias.scope !3, !noalias !4
  %v886 = load i64, ptr %slot6, align 8
  %p887 = inttoptr i64 %v886 to ptr
  store i32 2, ptr %p887, align 4, !alias.scope !3, !noalias !4
  %v888 = load i64, ptr %slot10, align 8
  %p889 = inttoptr i64 %v888 to ptr
  %ld890 = load i32, ptr %p889, align 4, !alias.scope !3, !noalias !4
  store i32 %ld890, ptr %slot162, align 8
  %v891 = load i32, ptr %slot162, align 8
  %v892 = load i64, ptr %slot6, align 8
  %p893 = inttoptr i64 %v892 to ptr
  store i32 %v891, ptr %p893, align 4, !alias.scope !3, !noalias !4
  %v894 = load i64, ptr %slot5, align 8
  %p895 = inttoptr i64 %v894 to ptr
  store i32 1, ptr %p895, align 4, !alias.scope !3, !noalias !4
  %v896 = load i64, ptr %slot14, align 8
  %p897 = inttoptr i64 %v896 to ptr
  %ld898 = load i64, ptr %p897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld898, ptr %slot163, align 8
  %v899 = load i64, ptr %slot163, align 8
  %v900 = load i64, ptr %slot18, align 8
  %p901 = inttoptr i64 %v900 to ptr
  store i64 %v899, ptr %p901, align 8, !alias.scope !3, !noalias !4
  %v902 = load i64, ptr %slot18, align 8
  %p903 = inttoptr i64 %v902 to ptr
  %ld904 = load i64, ptr %p903, align 8, !alias.scope !3, !noalias !4
  store i64 %ld904, ptr %slot164, align 8
  %v905 = load i64, ptr %slot1, align 8
  %v906 = load i64, ptr %slot164, align 8
  %call907 = call { i64, i64 } @myl_f_3366aa3455c03ea2dc76bc5b993933cc133e3c3405b7857cda1785b0c17f8295(i64 %v905, i64 %v906) nomerge, !dbg !132
  store { i64, i64 } %call907, ptr %callresult166, align 8
  %addr908 = ptrtoint ptr %callresult166 to i64
  store i64 %addr908, ptr %slot165, align 8
  %v909 = load i64, ptr %slot165, align 8
  %v910 = load i64, ptr %slot18, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i64 %v909, ptr %p911, align 8, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot7, align 8
  %p913 = inttoptr i64 %v912 to ptr
  %ld914 = load i32, ptr %p913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld914, ptr %slot167, align 8
  %v915 = load i32, ptr %slot167, align 8
  %cv916 = zext i32 %v915 to i64
  %cond917 = icmp ne i64 %cv916, 0
  br i1 %cond917, label %bb_rcslotdrop206, label %bb_rcslotdone206
bb_rcslotdrop206:
  %v918 = load i64, ptr %slot7, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i32 0, ptr %p919, align 4, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot12, align 8
  store i64 %v920, ptr %slot168, align 8
  %v921 = load i64, ptr %slot8, align 8
  %p922 = inttoptr i64 %v921 to ptr
  %ld923 = load i32, ptr %p922, align 4, !alias.scope !3, !noalias !4
  store i32 %ld923, ptr %slot169, align 8
  %v924 = load i32, ptr %slot169, align 8
  %op925 = and i32 %v924, 28
  store i32 %op925, ptr %slot170, align 8
  %v926 = load i32, ptr %slot170, align 8
  %cv927 = zext i32 %v926 to i64
  %cond928 = icmp ne i64 %cv927, 0
  br i1 %cond928, label %bb_rcslotrole206, label %bb_rcslotowner206
bb_rcslotrole206:
  %v929 = load i64, ptr %slot33, align 8
  store i64 %v929, ptr %slot171, align 8
  %v930 = load i64, ptr %slot171, align 8
  %v931 = load i64, ptr %slot168, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v930, i64 %v931) nomerge, !dbg !132
  br label %bb_rcslotdone206
bb_rcslotowner206:
  %v932 = load i64, ptr %slot33, align 8
  store i64 %v932, ptr %slot172, align 8
  %v933 = load i64, ptr %slot172, align 8
  %v934 = load i64, ptr %slot168, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v933, i64 %v934) nomerge, !dbg !132
  br label %bb_rcslotdone206
bb_rcslotdone206:
  %v935 = load i64, ptr %slot18, align 8
  %p936 = inttoptr i64 %v935 to ptr
  %ld937 = load i64, ptr %p936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld937, ptr %slot173, align 8
  %v938 = load i64, ptr %slot173, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %ld940 = load i32, ptr %p939, align 4
  %ext941 = zext i32 %ld940 to i64
  store i64 %ext941, ptr %slot174, align 8
  %v942 = load i64, ptr %slot174, align 8
  %cmp943 = icmp eq i64 %v942, 0
  %cv944 = zext i1 %cmp943 to i64
  store i64 %cv944, ptr %slot175, align 8
  %v945 = load i64, ptr %slot175, align 8
  %cond946 = icmp ne i64 %v945, 0
  br i1 %cond946, label %bb_rctryok214, label %bb_rctryerror214
bb_rctryerror214:
  %p947 = inttoptr i64 ptrtoint (ptr @myl_f_77c8aeea8f087d048765e2c779dcec5d681bbe3fe04487c962362b93ca437442_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p947, i64 12884901921) "call-inline-cost"="0", !dbg !134
  %v948 = load i64, ptr %slot173, align 8
  %op949 = add i64 %v948, 8
  store i64 %op949, ptr %slot176, align 8
  %v950 = load i64, ptr %slot27, align 8
  store i64 %v950, ptr %slot177, align 8
  %v951 = load i64, ptr %slot177, align 8
  %p952 = inttoptr i64 %v951 to ptr
  store i64 0, ptr %p952, align 8, !alias.scope !3, !noalias !4
  %v953 = load i64, ptr %slot177, align 8
  %p955 = inttoptr i64 %v953 to ptr
  %gep956 = getelementptr i8, ptr %p955, i64 8
  %op954 = ptrtoint ptr %gep956 to i64
  store i64 %op954, ptr %slot178, align 8
  %v957 = load i64, ptr %slot178, align 8
  %p958 = inttoptr i64 %v957 to ptr
  store i64 0, ptr %p958, align 8, !alias.scope !3, !noalias !4
  %v959 = load i64, ptr %slot177, align 8
  %p960 = inttoptr i64 %v959 to ptr
  store i32 1, ptr %p960, align 4, !alias.scope !3, !noalias !4
  %v961 = load i64, ptr %slot177, align 8
  %p963 = inttoptr i64 %v961 to ptr
  %gep964 = getelementptr i8, ptr %p963, i64 8
  %op962 = ptrtoint ptr %gep964 to i64
  store i64 %op962, ptr %slot179, align 8
  %v965 = load i64, ptr %slot11, align 8
  %p966 = inttoptr i64 %v965 to ptr
  store i32 1, ptr %p966, align 4, !alias.scope !3, !noalias !4
  %v967 = load i64, ptr %slot34, align 8
  store i64 %v967, ptr %slot180, align 8
  %v968 = load i64, ptr %slot177, align 8
  %v969 = load i64, ptr %slot18, align 8
  %p970 = inttoptr i64 %v969 to ptr
  store i64 %v968, ptr %p970, align 8, !alias.scope !3, !noalias !4
  br label %bb_i35
bb_rctryok214:
  %v971 = load i64, ptr %slot27, align 8
  store i64 %v971, ptr %slot181, align 8
  %v972 = load i64, ptr %slot181, align 8
  %p973 = inttoptr i64 %v972 to ptr
  store i64 0, ptr %p973, align 8, !alias.scope !3, !noalias !4
  %v974 = load i64, ptr %slot11, align 8
  %p975 = inttoptr i64 %v974 to ptr
  store i32 1, ptr %p975, align 4, !alias.scope !3, !noalias !4
  %v976 = load i64, ptr %slot173, align 8
  %op977 = add i64 %v976, 8
  store i64 %op977, ptr %slot182, align 8
  %v978 = load i64, ptr %slot34, align 8
  store i64 %v978, ptr %slot183, align 8
  %v979 = load i64, ptr %slot182, align 8
  %p980 = inttoptr i64 %v979 to ptr
  %ld981 = load i64, ptr %p980, align 8
  store i64 %ld981, ptr %slot184, align 8
  %v982 = load i64, ptr %slot184, align 8
  %v983 = load i64, ptr %slot181, align 8
  %p984 = inttoptr i64 %v983 to ptr
  store i64 %v982, ptr %p984, align 8, !alias.scope !3, !noalias !4
  %v985 = load i64, ptr %slot181, align 8
  %p986 = inttoptr i64 %v985 to ptr
  %ld987 = load i64, ptr %p986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld987, ptr %slot185, align 8
  %v988 = load i64, ptr %slot185, align 8
  %v989 = load i64, ptr %slot18, align 8
  %p990 = inttoptr i64 %v989 to ptr
  store i64 %v988, ptr %p990, align 8, !alias.scope !3, !noalias !4
  br label %bb_i36
bb_i35:
  %v991 = load i64, ptr %slot18, align 8
  %p992 = inttoptr i64 %v991 to ptr
  %ld993 = load i64, ptr %p992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld993, ptr %slot186, align 8
  %v994 = load i64, ptr %slot7, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %ld996 = load i32, ptr %p995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld996, ptr %slot187, align 8
  %v997 = load i32, ptr %slot187, align 8
  %cv998 = zext i32 %v997 to i64
  %cond999 = icmp ne i64 %cv998, 0
  br i1 %cond999, label %bb_rcslotdrop233, label %bb_rcslotdone233
bb_rcslotdrop233:
  %v1000 = load i64, ptr %slot7, align 8
  %p1001 = inttoptr i64 %v1000 to ptr
  store i32 0, ptr %p1001, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone233
bb_rcslotdone233:
  %v1002 = load i64, ptr %slot5, align 8
  %p1003 = inttoptr i64 %v1002 to ptr
  %ld1004 = load i32, ptr %p1003, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1004, ptr %slot188, align 8
  %v1005 = load i32, ptr %slot188, align 8
  %cv1006 = zext i32 %v1005 to i64
  %cond1007 = icmp ne i64 %cv1006, 0
  br i1 %cond1007, label %bb_rcslotdrop236, label %bb_rcslotdone236
bb_rcslotdrop236:
  %v1008 = load i64, ptr %slot5, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  store i32 0, ptr %p1009, align 4, !alias.scope !3, !noalias !4
  %v1010 = load i64, ptr %slot16, align 8
  store i64 %v1010, ptr %slot189, align 8
  %v1011 = load i64, ptr %slot6, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  %ld1013 = load i32, ptr %p1012, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1013, ptr %slot190, align 8
  %v1014 = load i32, ptr %slot190, align 8
  %op1015 = and i32 %v1014, 28
  store i32 %op1015, ptr %slot191, align 8
  %v1016 = load i32, ptr %slot191, align 8
  %cv1017 = zext i32 %v1016 to i64
  %cond1018 = icmp ne i64 %cv1017, 0
  br i1 %cond1018, label %bb_rcslotrole236, label %bb_rcslotowner236
bb_rcslotrole236:
  %v1019 = load i64, ptr %slot33, align 8
  store i64 %v1019, ptr %slot192, align 8
  %v1020 = load i64, ptr %slot192, align 8
  %v1021 = load i64, ptr %slot189, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1020, i64 %v1021) nomerge, !dbg !136
  br label %bb_rcslotdone236
bb_rcslotowner236:
  %v1022 = load i64, ptr %slot33, align 8
  store i64 %v1022, ptr %slot193, align 8
  %v1023 = load i64, ptr %slot193, align 8
  %v1024 = load i64, ptr %slot189, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1023, i64 %v1024) nomerge, !dbg !136
  br label %bb_rcslotdone236
bb_rcslotdone236:
  %v1025 = load i64, ptr %slot186, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  %ret1027 = load { i64, i64 }, ptr %p1026, align 8
  ret { i64, i64 } %ret1027
bb_i36:
  %v1028 = load i64, ptr %slot18, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  %ld1030 = load i64, ptr %p1029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1030, ptr %slot194, align 8
  %v1031 = load i64, ptr %slot194, align 8
  %v1032 = load i64, ptr %slot17, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  store i64 %v1031, ptr %p1033, align 8, !alias.scope !3, !noalias !4
  %v1034 = load i64, ptr %slot14, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i64, ptr %p1035, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1036, ptr %slot195, align 8
  %v1037 = load i64, ptr %slot195, align 8
  %v1038 = load i64, ptr %slot18, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  store i64 %v1037, ptr %p1039, align 8, !alias.scope !3, !noalias !4
  %v1040 = load i64, ptr %slot15, align 8
  %p1041 = inttoptr i64 %v1040 to ptr
  %ld1042 = load i64, ptr %p1041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1042, ptr %slot196, align 8
  %v1043 = load i64, ptr %slot196, align 8
  %v1044 = load i64, ptr %slot19, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i64 %v1043, ptr %p1045, align 8, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot16, align 8
  %v1047 = load i64, ptr %slot20, align 8
  %p1048 = inttoptr i64 %v1047 to ptr
  store i64 %v1046, ptr %p1048, align 8, !alias.scope !3, !noalias !4
  %v1049 = load i64, ptr %slot17, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  %ld1051 = load i64, ptr %p1050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1051, ptr %slot197, align 8
  %v1052 = load i64, ptr %slot197, align 8
  %v1053 = load i64, ptr %slot21, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i64 %v1052, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot18, align 8
  %p1056 = inttoptr i64 %v1055 to ptr
  %ld1057 = load i64, ptr %p1056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1057, ptr %slot198, align 8
  %v1058 = load i64, ptr %slot19, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %ld1060 = load i64, ptr %p1059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1060, ptr %slot199, align 8
  %v1061 = load i64, ptr %slot20, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  %ld1063 = load i64, ptr %p1062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1063, ptr %slot200, align 8
  %v1064 = load i64, ptr %slot21, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %ld1066 = load i64, ptr %p1065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1066, ptr %slot201, align 8
  %v1067 = load i64, ptr %slot1, align 8
  %v1068 = load i64, ptr %slot198, align 8
  %v1069 = load i64, ptr %slot199, align 8
  %v1070 = load i64, ptr %slot200, align 8
  %v1071 = load i64, ptr %slot201, align 8
  %call1072 = call i64 @myl_f_38fe4a08ed5126ee25eb50d3fd267560c09029705d126b945d52153c6f2b1ffb(i64 %v1067, i64 %v1068, i64 %v1069, i64 %v1070, i64 %v1071) nomerge, !dbg !138
  store i64 %call1072, ptr %slot202, align 8
  %v1073 = load i64, ptr %slot202, align 8
  %v1074 = load i64, ptr %slot18, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  store i64 %v1073, ptr %p1075, align 8, !alias.scope !3, !noalias !4
  %v1076 = load i64, ptr %slot7, align 8
  %p1077 = inttoptr i64 %v1076 to ptr
  %ld1078 = load i32, ptr %p1077, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1078, ptr %slot203, align 8
  %v1079 = load i32, ptr %slot203, align 8
  %cv1080 = zext i32 %v1079 to i64
  %cond1081 = icmp ne i64 %cv1080, 0
  br i1 %cond1081, label %bb_rcslotdrop263, label %bb_rcslotdone263
bb_rcslotdrop263:
  %v1082 = load i64, ptr %slot7, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  store i32 0, ptr %p1083, align 4, !alias.scope !3, !noalias !4
  %v1084 = load i64, ptr %slot12, align 8
  store i64 %v1084, ptr %slot204, align 8
  %v1085 = load i64, ptr %slot8, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  %ld1087 = load i32, ptr %p1086, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1087, ptr %slot205, align 8
  %v1088 = load i32, ptr %slot205, align 8
  %op1089 = and i32 %v1088, 28
  store i32 %op1089, ptr %slot206, align 8
  %v1090 = load i32, ptr %slot206, align 8
  %cv1091 = zext i32 %v1090 to i64
  %cond1092 = icmp ne i64 %cv1091, 0
  br i1 %cond1092, label %bb_rcslotrole263, label %bb_rcslotowner263
bb_rcslotrole263:
  %v1093 = load i64, ptr %slot33, align 8
  store i64 %v1093, ptr %slot207, align 8
  %v1094 = load i64, ptr %slot207, align 8
  %v1095 = load i64, ptr %slot204, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v1094, i64 %v1095) nomerge, !dbg !138
  br label %bb_rcslotdone263
bb_rcslotowner263:
  %v1096 = load i64, ptr %slot33, align 8
  store i64 %v1096, ptr %slot208, align 8
  %v1097 = load i64, ptr %slot208, align 8
  %v1098 = load i64, ptr %slot204, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v1097, i64 %v1098) nomerge, !dbg !138
  br label %bb_rcslotdone263
bb_rcslotdone263:
  %v1099 = load i64, ptr %slot18, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  %ld1101 = load i64, ptr %p1100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1101, ptr %slot209, align 8
  %v1102 = load i64, ptr %slot209, align 8
  %v1103 = load i64, ptr %slot15, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  store i64 %v1102, ptr %p1104, align 8, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_i44:
  %v1105 = load i64, ptr %slot15, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  %ld1107 = load i64, ptr %p1106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1107, ptr %slot210, align 8
  %v1108 = load i64, ptr %slot210, align 8
  %v1109 = load i64, ptr %slot18, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  store i64 %v1108, ptr %p1110, align 8, !alias.scope !3, !noalias !4
  %v1111 = load i64, ptr %slot28, align 8
  store i64 %v1111, ptr %slot211, align 8
  %v1112 = load i64, ptr %slot211, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  store i64 0, ptr %p1113, align 8, !alias.scope !3, !noalias !4
  %v1114 = load i64, ptr %slot211, align 8
  %p1116 = inttoptr i64 %v1114 to ptr
  %gep1117 = getelementptr i8, ptr %p1116, i64 8
  %op1115 = ptrtoint ptr %gep1117 to i64
  store i64 %op1115, ptr %slot212, align 8
  %v1118 = load i64, ptr %slot212, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i64 0, ptr %p1119, align 8, !alias.scope !3, !noalias !4
  %v1120 = load i64, ptr %slot211, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  store i32 0, ptr %p1121, align 4, !alias.scope !3, !noalias !4
  %v1122 = load i64, ptr %slot11, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  store i32 1, ptr %p1123, align 4, !alias.scope !3, !noalias !4
  %v1124 = load i64, ptr %slot18, align 8
  store i64 %v1124, ptr %slot213, align 8
  %v1125 = load i64, ptr %slot211, align 8
  %p1127 = inttoptr i64 %v1125 to ptr
  %gep1128 = getelementptr i8, ptr %p1127, i64 8
  %op1126 = ptrtoint ptr %gep1128 to i64
  store i64 %op1126, ptr %slot214, align 8
  %v1129 = load i64, ptr %slot34, align 8
  store i64 %v1129, ptr %slot215, align 8
  %v1130 = load i64, ptr %slot213, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  %ld1132 = load i64, ptr %p1131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1132, ptr %slot216, align 8
  %v1133 = load i64, ptr %slot216, align 8
  %v1134 = load i64, ptr %slot214, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  store i64 %v1133, ptr %p1135, align 8, !alias.scope !3, !noalias !4
  %v1136 = load i64, ptr %slot211, align 8
  %v1137 = load i64, ptr %slot18, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  store i64 %v1136, ptr %p1138, align 8, !alias.scope !3, !noalias !4
  %v1139 = load i64, ptr %slot18, align 8
  %p1140 = inttoptr i64 %v1139 to ptr
  %ld1141 = load i64, ptr %p1140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1141, ptr %slot217, align 8
  %v1142 = load i64, ptr %slot7, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %ld1144 = load i32, ptr %p1143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1144, ptr %slot218, align 8
  %v1145 = load i32, ptr %slot218, align 8
  %cv1146 = zext i32 %v1145 to i64
  %cond1147 = icmp ne i64 %cv1146, 0
  br i1 %cond1147, label %bb_rcslotdrop292, label %bb_rcslotdone292
bb_rcslotdrop292:
  %v1148 = load i64, ptr %slot7, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  store i32 0, ptr %p1149, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone292
bb_rcslotdone292:
  %v1150 = load i64, ptr %slot5, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i32, ptr %p1151, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1152, ptr %slot219, align 8
  %v1153 = load i32, ptr %slot219, align 8
  %cv1154 = zext i32 %v1153 to i64
  %cond1155 = icmp ne i64 %cv1154, 0
  br i1 %cond1155, label %bb_rcslotdrop295, label %bb_rcslotdone295
bb_rcslotdrop295:
  %v1156 = load i64, ptr %slot5, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  store i32 0, ptr %p1157, align 4, !alias.scope !3, !noalias !4
  %v1158 = load i64, ptr %slot16, align 8
  store i64 %v1158, ptr %slot220, align 8
  %v1159 = load i64, ptr %slot6, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  %ld1161 = load i32, ptr %p1160, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1161, ptr %slot221, align 8
  %v1162 = load i32, ptr %slot221, align 8
  %op1163 = and i32 %v1162, 28
  store i32 %op1163, ptr %slot222, align 8
  %v1164 = load i32, ptr %slot222, align 8
  %cv1165 = zext i32 %v1164 to i64
  %cond1166 = icmp ne i64 %cv1165, 0
  br i1 %cond1166, label %bb_rcslotrole295, label %bb_rcslotowner295
bb_rcslotrole295:
  %v1167 = load i64, ptr %slot33, align 8
  store i64 %v1167, ptr %slot223, align 8
  %v1168 = load i64, ptr %slot223, align 8
  %v1169 = load i64, ptr %slot220, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1168, i64 %v1169) nomerge, !dbg !140
  br label %bb_rcslotdone295
bb_rcslotowner295:
  %v1170 = load i64, ptr %slot33, align 8
  store i64 %v1170, ptr %slot224, align 8
  %v1171 = load i64, ptr %slot224, align 8
  %v1172 = load i64, ptr %slot220, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1171, i64 %v1172) nomerge, !dbg !140
  br label %bb_rcslotdone295
bb_rcslotdone295:
  %v1173 = load i64, ptr %slot217, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  %ret1175 = load { i64, i64 }, ptr %p1174, align 8
  ret { i64, i64 } %ret1175
bb_failure:
  %v1176 = load i64, ptr %slot4, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  call void @llvm.memset.p0.i64(ptr %p1177, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !140
  %v1178 = load i64, ptr %slot4, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  %ret1180 = load { i64, i64 }, ptr %p1179, align 8
  ret { i64, i64 } %ret1180
bb_entry_failure:
  %v1181 = load i64, ptr %slot4, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  call void @llvm.memset.p0.i64(ptr %p1182, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !140
  %v1183 = load i64, ptr %slot4, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %ret1185 = load { i64, i64 }, ptr %p1184, align 8
  ret { i64, i64 } %ret1185
}

@myl_f_77c8aeea8f087d048765e2c779dcec5d681bbe3fe04487c962362b93ca437442_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare { i64, i64 } @myl_f_3366aa3455c03ea2dc76bc5b993933cc133e3c3405b7857cda1785b0c17f8295(i64, i64)
declare i64 @myl_f_38fe4a08ed5126ee25eb50d3fd267560c09029705d126b945d52153c6f2b1ffb(i64, i64, i64, i64, i64)
declare i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_77c8aeea8f087d048765e2c779dcec5d681bbe3fe04487c962362b93ca437442", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_77c8aeea8f087d048765e2c779dcec5d681bbe3fe04487c962362b93ca437442", linkageName: "myl_f_77c8aeea8f087d048765e2c779dcec5d681bbe3fe04487c962362b93ca437442", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 14280269681223359968, i64 0, !"myl_f_77c8aeea8f087d048765e2c779dcec5d681bbe3fe04487c962362b93ca437442"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!122 = !DILocation(line: 15, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!124 = !DILocation(line: 21, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!126 = !DILocation(line: 27, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!128 = !DILocation(line: 30, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!130 = !DILocation(line: 31, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!132 = !DILocation(line: 33, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!134 = !DILocation(line: 34, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!136 = !DILocation(line: 36, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!138 = !DILocation(line: 42, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!140 = !DILocation(line: 47, column: 0, scope: !141)
