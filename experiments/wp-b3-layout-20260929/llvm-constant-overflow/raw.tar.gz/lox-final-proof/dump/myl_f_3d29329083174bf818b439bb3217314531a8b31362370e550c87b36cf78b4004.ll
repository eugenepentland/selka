target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %callresult42 = alloca [24 x i8], align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %callresult137 = alloca [16 x i8], align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %callresult175 = alloca [24 x i8], align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %callresult226 = alloca [24 x i8], align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v289 = load i64, ptr %slot1, align 8
  %op290 = add i64 %v289, 32
  store i64 %op290, ptr %slot4, align 8
  %mem291 = alloca i8, i64 24, align 8
  %ptr292 = ptrtoint ptr %mem291 to i64
  store i64 %ptr292, ptr %slot5, align 8
  %mem293 = alloca i8, i64 8, align 8
  %ptr294 = ptrtoint ptr %mem293 to i64
  store i64 %ptr294, ptr %slot6, align 8
  %mem295 = alloca i8, i64 8, align 8
  %ptr296 = ptrtoint ptr %mem295 to i64
  store i64 %ptr296, ptr %slot7, align 8
  %mem297 = alloca i8, i64 8, align 8
  %ptr298 = ptrtoint ptr %mem297 to i64
  store i64 %ptr298, ptr %slot8, align 8
  %mem299 = alloca i8, i64 8, align 8
  %ptr300 = ptrtoint ptr %mem299 to i64
  store i64 %ptr300, ptr %slot9, align 8
  %mem301 = alloca i8, i64 8, align 8
  %ptr302 = ptrtoint ptr %mem301 to i64
  store i64 %ptr302, ptr %slot10, align 8
  %mem303 = alloca i8, i64 8, align 8
  %ptr304 = ptrtoint ptr %mem303 to i64
  store i64 %ptr304, ptr %slot11, align 8
  %mem305 = alloca i8, i64 8, align 8
  %ptr306 = ptrtoint ptr %mem305 to i64
  store i64 %ptr306, ptr %slot12, align 8
  %mem307 = alloca i8, i64 304, align 8
  %ptr308 = ptrtoint ptr %mem307 to i64
  store i64 %ptr308, ptr %slot13, align 8
  %mem309 = alloca i8, i64 304, align 8
  %ptr310 = ptrtoint ptr %mem309 to i64
  store i64 %ptr310, ptr %slot14, align 8
  %mem311 = alloca i8, i64 8, align 8
  %ptr312 = ptrtoint ptr %mem311 to i64
  store i64 %ptr312, ptr %slot15, align 8
  %mem313 = alloca i8, i64 8, align 8
  %ptr314 = ptrtoint ptr %mem313 to i64
  store i64 %ptr314, ptr %slot16, align 8
  %mem315 = alloca i8, i64 208, align 8
  %ptr316 = ptrtoint ptr %mem315 to i64
  store i64 %ptr316, ptr %slot17, align 8
  %mem317 = alloca i8, i64 8, align 8
  %ptr318 = ptrtoint ptr %mem317 to i64
  store i64 %ptr318, ptr %slot18, align 8
  %mem319 = alloca i8, i64 8, align 8
  %ptr320 = ptrtoint ptr %mem319 to i64
  store i64 %ptr320, ptr %slot19, align 8
  %mem321 = alloca i8, i64 16, align 8
  %ptr322 = ptrtoint ptr %mem321 to i64
  store i64 %ptr322, ptr %slot20, align 8
  %mem323 = alloca i8, i64 8, align 8
  %ptr324 = ptrtoint ptr %mem323 to i64
  store i64 %ptr324, ptr %slot21, align 8
  %mem325 = alloca i8, i64 8, align 8
  %ptr326 = ptrtoint ptr %mem325 to i64
  store i64 %ptr326, ptr %slot22, align 8
  %mem327 = alloca i8, i64 8, align 8
  %ptr328 = ptrtoint ptr %mem327 to i64
  store i64 %ptr328, ptr %slot23, align 8
  %mem329 = alloca i8, i64 24, align 8
  %ptr330 = ptrtoint ptr %mem329 to i64
  store i64 %ptr330, ptr %slot24, align 8
  %mem331 = alloca i8, i64 304, align 8
  %ptr332 = ptrtoint ptr %mem331 to i64
  store i64 %ptr332, ptr %slot25, align 8
  %mem333 = alloca i8, i64 8, align 8
  %ptr334 = ptrtoint ptr %mem333 to i64
  store i64 %ptr334, ptr %slot26, align 8
  %mem335 = alloca i8, i64 24, align 8
  %ptr336 = ptrtoint ptr %mem335 to i64
  store i64 %ptr336, ptr %slot27, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem337 = alloca i8, i64 8, align 8
  %ptr338 = ptrtoint ptr %mem337 to i64
  store i64 %ptr338, ptr %slot28, align 8
  %v339 = load i64, ptr %slot1, align 8
  %op340 = add i64 %v339, 64
  store i64 %op340, ptr %slot29, align 8
  %v341 = load i64, ptr %slot29, align 8
  %p342 = inttoptr i64 %v341 to ptr
  %ld343 = load i64, ptr %p342, align 8, !alias.scope !4, !noalias !3
  store i64 %ld343, ptr %slot30, align 8
  %stack344 = call ptr @llvm.stacksave()
  %stackaddr345 = ptrtoint ptr %stack344 to i64
  %v346 = load i64, ptr %slot30, align 8
  %cmp347 = icmp ult i64 %stackaddr345, %v346
  %cv348 = zext i1 %cmp347 to i64
  store i64 %cv348, ptr %slot31, align 8
  %v349 = load i64, ptr %slot31, align 8
  %cond350 = icmp ne i64 %v349, 0
  br i1 %cond350, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v351 = load i64, ptr %slot1, align 8
  %p352 = inttoptr i64 %v351 to ptr
  call void @myl_qbe_fail_frame(ptr %p352) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v353 = load i64, ptr %slot2, align 8
  %v354 = load i64, ptr %slot15, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i64 %v353, ptr %p355, align 8, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot3, align 8
  %v357 = load i64, ptr %slot16, align 8
  %p358 = inttoptr i64 %v357 to ptr
  store i64 %v356, ptr %p358, align 8, !alias.scope !3, !noalias !4
  %v359 = load i64, ptr %slot1, align 8
  %p360 = inttoptr i64 %v359 to ptr
  %call361 = call ptr @myl_qbe_heap(ptr %p360) nomerge, !dbg !112
  %calladdr362 = ptrtoint ptr %call361 to i64
  store i64 %calladdr362, ptr %slot32, align 8
  %v363 = load i64, ptr %slot1, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %call365 = call i64 @myl_qbe_region_mark(ptr %p364) nomerge, !dbg !112
  store i64 %call365, ptr %slot33, align 8
  %v366 = load i64, ptr %slot6, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i32 0, ptr %p367, align 4, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot7, align 8
  %p369 = inttoptr i64 %v368 to ptr
  store i32 0, ptr %p369, align 4, !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot8, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i32 0, ptr %p371, align 4, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot9, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i32 0, ptr %p373, align 4, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot10, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i32 0, ptr %p375, align 4, !alias.scope !3, !noalias !4
  %v376 = load i64, ptr %slot11, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i32 0, ptr %p377, align 4, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot12, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i32 0, ptr %p379, align 4, !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot7, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i32 2, ptr %p381, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v382 = load i64, ptr %slot15, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i64, ptr %p383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld384, ptr %slot34, align 8
  %v385 = load i64, ptr %slot34, align 8
  %v386 = load i64, ptr %slot22, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i64 %v385, ptr %p387, align 8, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot16, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i64, ptr %p389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld390, ptr %slot35, align 8
  %v391 = load i64, ptr %slot35, align 8
  %v392 = load i64, ptr %slot23, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i64 %v391, ptr %p393, align 8, !alias.scope !3, !noalias !4
  %v394 = load i64, ptr %slot23, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld396, ptr %slot36, align 8
  %v397 = load i64, ptr %slot36, align 8
  %op398 = add i64 %v397, 0
  store i64 %op398, ptr %slot37, align 8
  %v399 = load i64, ptr %slot37, align 8
  %p400 = inttoptr i64 %v399 to ptr
  %ld401 = load i64, ptr %p400, align 8, !alias.scope !4, !noalias !3
  store i64 %ld401, ptr %slot38, align 8
  %v402 = load i64, ptr %slot38, align 8
  %v403 = load i64, ptr %slot23, align 8
  %p404 = inttoptr i64 %v403 to ptr
  store i64 %v402, ptr %p404, align 8, !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot22, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i64, ptr %p406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld407, ptr %slot39, align 8
  %v408 = load i64, ptr %slot23, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld410, ptr %slot40, align 8
  %v411 = load i64, ptr %slot1, align 8
  %v412 = load i64, ptr %slot39, align 8
  %v413 = load i64, ptr %slot40, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult42, i64 %v411, i64 %v412, i64 %v413) nomerge, !dbg !114
  %addr414 = ptrtoint ptr %callresult42 to i64
  store i64 %addr414, ptr %slot41, align 8
  %v415 = load i64, ptr %slot41, align 8
  %v416 = load i64, ptr %slot22, align 8
  %p417 = inttoptr i64 %v416 to ptr
  store i64 %v415, ptr %p417, align 8, !alias.scope !3, !noalias !4
  %v418 = load i64, ptr %slot22, align 8
  %p419 = inttoptr i64 %v418 to ptr
  %ld420 = load i64, ptr %p419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld420, ptr %slot43, align 8
  %v421 = load i64, ptr %slot14, align 8
  store i64 %v421, ptr %slot44, align 8
  %v422 = load i64, ptr %slot43, align 8
  %v423 = load i64, ptr %slot44, align 8
  %p424 = inttoptr i64 %v422 to ptr
  %p425 = inttoptr i64 %v423 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p425, ptr %p424, i64 24, i1 false)
  %v426 = load i64, ptr %slot11, align 8
  %p427 = inttoptr i64 %v426 to ptr
  store i32 2, ptr %p427, align 4, !alias.scope !3, !noalias !4
  %v428 = load i64, ptr %slot10, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i32 1, ptr %p429, align 4, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot8, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i32, ptr %p431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld432, ptr %slot45, align 8
  %v433 = load i32, ptr %slot45, align 8
  %cv434 = zext i32 %v433 to i64
  %cond435 = icmp ne i64 %cv434, 0
  br i1 %cond435, label %bb_rcslotdrop25, label %bb_rcslotdone25
bb_rcslotdrop25:
  %v436 = load i64, ptr %slot8, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i32 0, ptr %p437, align 4, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot13, align 8
  store i64 %v438, ptr %slot46, align 8
  %v439 = load i64, ptr %slot9, align 8
  %p440 = inttoptr i64 %v439 to ptr
  %ld441 = load i32, ptr %p440, align 4, !alias.scope !3, !noalias !4
  store i32 %ld441, ptr %slot47, align 8
  %v442 = load i32, ptr %slot47, align 8
  %op443 = and i32 %v442, 28
  store i32 %op443, ptr %slot48, align 8
  %v444 = load i32, ptr %slot48, align 8
  %cv445 = zext i32 %v444 to i64
  %cond446 = icmp ne i64 %cv445, 0
  br i1 %cond446, label %bb_rcslotrole25, label %bb_rcslotowner25
bb_rcslotrole25:
  %v447 = load i64, ptr %slot32, align 8
  store i64 %v447, ptr %slot49, align 8
  %v448 = load i64, ptr %slot49, align 8
  %v449 = load i64, ptr %slot46, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v448, i64 %v449) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotowner25:
  %v450 = load i64, ptr %slot32, align 8
  store i64 %v450, ptr %slot50, align 8
  %v451 = load i64, ptr %slot50, align 8
  %v452 = load i64, ptr %slot46, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v451, i64 %v452) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotdone25:
  %v453 = load i64, ptr %slot13, align 8
  store i64 %v453, ptr %slot51, align 8
  %v454 = load i64, ptr %slot14, align 8
  store i64 %v454, ptr %slot52, align 8
  %v455 = load i64, ptr %slot52, align 8
  %v456 = load i64, ptr %slot51, align 8
  %p457 = inttoptr i64 %v455 to ptr
  %p458 = inttoptr i64 %v456 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p458, ptr %p457, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot9, align 8
  %p460 = inttoptr i64 %v459 to ptr
  store i32 2, ptr %p460, align 4, !alias.scope !3, !noalias !4
  %v461 = load i64, ptr %slot11, align 8
  %p462 = inttoptr i64 %v461 to ptr
  %ld463 = load i32, ptr %p462, align 4, !alias.scope !3, !noalias !4
  store i32 %ld463, ptr %slot53, align 8
  %v464 = load i32, ptr %slot53, align 8
  %v465 = load i64, ptr %slot9, align 8
  %p466 = inttoptr i64 %v465 to ptr
  store i32 %v464, ptr %p466, align 4, !alias.scope !3, !noalias !4
  %v467 = load i64, ptr %slot10, align 8
  %p468 = inttoptr i64 %v467 to ptr
  store i32 0, ptr %p468, align 4, !alias.scope !3, !noalias !4
  %v469 = load i64, ptr %slot8, align 8
  %p470 = inttoptr i64 %v469 to ptr
  store i32 1, ptr %p470, align 4, !alias.scope !3, !noalias !4
  %v471 = load i64, ptr %slot51, align 8
  %v472 = load i64, ptr %slot22, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i64 %v471, ptr %p473, align 8, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot22, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld476, ptr %slot54, align 8
  %v477 = load i64, ptr %slot54, align 8
  %p478 = inttoptr i64 %v477 to ptr
  %ld479 = load i32, ptr %p478, align 4, !alias.scope !3, !noalias !4
  %ext480 = zext i32 %ld479 to i64
  store i64 %ext480, ptr %slot55, align 8
  %v481 = load i64, ptr %slot55, align 8
  %cmp482 = icmp eq i64 %v481, 0
  %cv483 = zext i1 %cmp482 to i64
  store i64 %cv483, ptr %slot56, align 8
  %v484 = load i64, ptr %slot56, align 8
  %cond485 = icmp ne i64 %v484, 0
  br i1 %cond485, label %bb_rctryok41, label %bb_rctryerror41
bb_rctryerror41:
  %p486 = inttoptr i64 ptrtoint (ptr @myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p486, i64 12884901892) "call-inline-cost"="0", !dbg !116
  %v487 = load i64, ptr %slot54, align 8
  %op488 = add i64 %v487, 8
  store i64 %op488, ptr %slot57, align 8
  %v489 = load i64, ptr %slot24, align 8
  store i64 %v489, ptr %slot58, align 8
  %v490 = load i64, ptr %slot58, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i64 0, ptr %p491, align 8, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot58, align 8
  %p494 = inttoptr i64 %v492 to ptr
  %gep495 = getelementptr i8, ptr %p494, i64 8
  %op493 = ptrtoint ptr %gep495 to i64
  store i64 %op493, ptr %slot59, align 8
  %v496 = load i64, ptr %slot59, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i64 0, ptr %p497, align 8, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot58, align 8
  %p500 = inttoptr i64 %v498 to ptr
  %gep501 = getelementptr i8, ptr %p500, i64 16
  %op499 = ptrtoint ptr %gep501 to i64
  store i64 %op499, ptr %slot60, align 8
  %v502 = load i64, ptr %slot60, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 0, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot58, align 8
  %p505 = inttoptr i64 %v504 to ptr
  store i32 1, ptr %p505, align 4, !alias.scope !3, !noalias !4
  %v506 = load i64, ptr %slot58, align 8
  %p508 = inttoptr i64 %v506 to ptr
  %gep509 = getelementptr i8, ptr %p508, i64 8
  %op507 = ptrtoint ptr %gep509 to i64
  store i64 %op507, ptr %slot61, align 8
  %v510 = load i64, ptr %slot12, align 8
  %p511 = inttoptr i64 %v510 to ptr
  store i32 1, ptr %p511, align 4, !alias.scope !3, !noalias !4
  %v512 = load i64, ptr %slot33, align 8
  store i64 %v512, ptr %slot62, align 8
  %v513 = load i64, ptr %slot32, align 8
  %v514 = load i64, ptr %slot61, align 8
  %v515 = load i64, ptr %slot57, align 8
  %v516 = load i64, ptr %slot62, align 8
  %cv517 = trunc i64 %v516 to i32
  %call518 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v513, i64 %v514, i64 %v515, i32 %cv517) nomerge, !dbg !116
  store i32 %call518, ptr %slot63, align 8
  %v519 = load i32, ptr %slot63, align 8
  %cv520 = zext i32 %v519 to i64
  %cond521 = icmp ne i64 %cv520, 0
  br i1 %cond521, label %bb_rcsuccess52, label %bb_rcfailure52
bb_rcfailure52:
  %v522 = load i64, ptr %slot32, align 8
  %p523 = inttoptr i64 %v522 to ptr
  %call524 = call i32 @myl_rc_take_failure(ptr %p523) nomerge, !dbg !116
  store i32 %call524, ptr %slot64, align 8
  %v525 = load i64, ptr %slot1, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %v527 = load i32, ptr %slot64, align 8
  %call528 = call i32 @myl_qbe_rc_status(ptr %p526, i32 %v527) nomerge, !dbg !116
  store i32 %call528, ptr %slot65, align 8
  br label %bb_failure
bb_rcsuccess52:
  %v529 = load i64, ptr %slot58, align 8
  %v530 = load i64, ptr %slot22, align 8
  %p531 = inttoptr i64 %v530 to ptr
  store i64 %v529, ptr %p531, align 8, !alias.scope !3, !noalias !4
  %v532 = load i64, ptr %slot22, align 8
  %p533 = inttoptr i64 %v532 to ptr
  %ld534 = load i64, ptr %p533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld534, ptr %slot66, align 8
  %v535 = load i64, ptr %slot14, align 8
  store i64 %v535, ptr %slot67, align 8
  %v536 = load i64, ptr %slot66, align 8
  %v537 = load i64, ptr %slot67, align 8
  %p538 = inttoptr i64 %v536 to ptr
  %p539 = inttoptr i64 %v537 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p539, ptr %p538, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot11, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i32 2, ptr %p541, align 4, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot10, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i32 1, ptr %p543, align 4, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot8, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i32, ptr %p545, align 4, !alias.scope !3, !noalias !4
  store i32 %ld546, ptr %slot68, align 8
  %v547 = load i32, ptr %slot68, align 8
  %cv548 = zext i32 %v547 to i64
  %cond549 = icmp ne i64 %cv548, 0
  br i1 %cond549, label %bb_rcslotdrop61, label %bb_rcslotdone61
bb_rcslotdrop61:
  %v550 = load i64, ptr %slot8, align 8
  %p551 = inttoptr i64 %v550 to ptr
  store i32 0, ptr %p551, align 4, !alias.scope !3, !noalias !4
  %v552 = load i64, ptr %slot13, align 8
  store i64 %v552, ptr %slot69, align 8
  %v553 = load i64, ptr %slot9, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i32, ptr %p554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld555, ptr %slot70, align 8
  %v556 = load i32, ptr %slot70, align 8
  %op557 = and i32 %v556, 28
  store i32 %op557, ptr %slot71, align 8
  %v558 = load i32, ptr %slot71, align 8
  %cv559 = zext i32 %v558 to i64
  %cond560 = icmp ne i64 %cv559, 0
  br i1 %cond560, label %bb_rcslotrole61, label %bb_rcslotowner61
bb_rcslotrole61:
  %v561 = load i64, ptr %slot32, align 8
  store i64 %v561, ptr %slot72, align 8
  %v562 = load i64, ptr %slot72, align 8
  %v563 = load i64, ptr %slot69, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v562, i64 %v563) nomerge, !dbg !116
  br label %bb_rcslotdone61
bb_rcslotowner61:
  %v564 = load i64, ptr %slot32, align 8
  store i64 %v564, ptr %slot73, align 8
  %v565 = load i64, ptr %slot73, align 8
  %v566 = load i64, ptr %slot69, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v565, i64 %v566) nomerge, !dbg !116
  br label %bb_rcslotdone61
bb_rcslotdone61:
  %v567 = load i64, ptr %slot13, align 8
  store i64 %v567, ptr %slot74, align 8
  %v568 = load i64, ptr %slot14, align 8
  store i64 %v568, ptr %slot75, align 8
  %v569 = load i64, ptr %slot75, align 8
  %v570 = load i64, ptr %slot74, align 8
  %p571 = inttoptr i64 %v569 to ptr
  %p572 = inttoptr i64 %v570 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p572, ptr %p571, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot9, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i32 2, ptr %p574, align 4, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot11, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i32, ptr %p576, align 4, !alias.scope !3, !noalias !4
  store i32 %ld577, ptr %slot76, align 8
  %v578 = load i32, ptr %slot76, align 8
  %v579 = load i64, ptr %slot9, align 8
  %p580 = inttoptr i64 %v579 to ptr
  store i32 %v578, ptr %p580, align 4, !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot10, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i32 0, ptr %p582, align 4, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot8, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i32 1, ptr %p584, align 4, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot74, align 8
  %v586 = load i64, ptr %slot22, align 8
  %p587 = inttoptr i64 %v586 to ptr
  store i64 %v585, ptr %p587, align 8, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_rctryok41:
  %v588 = load i64, ptr %slot24, align 8
  store i64 %v588, ptr %slot77, align 8
  %v589 = load i64, ptr %slot12, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i32 1, ptr %p590, align 4, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot54, align 8
  %op592 = add i64 %v591, 8
  store i64 %op592, ptr %slot78, align 8
  %v593 = load i64, ptr %slot33, align 8
  store i64 %v593, ptr %slot79, align 8
  store i64 0, ptr %slot80, align 8
  store i64 0, ptr %slot81, align 8
  %v594 = load i64, ptr %slot81, align 8
  %v595 = load i64, ptr %slot22, align 8
  %p596 = inttoptr i64 %v595 to ptr
  store i64 %v594, ptr %p596, align 8, !alias.scope !3, !noalias !4
  %v597 = load i64, ptr %slot8, align 8
  %p598 = inttoptr i64 %v597 to ptr
  %ld599 = load i32, ptr %p598, align 4, !alias.scope !3, !noalias !4
  store i32 %ld599, ptr %slot82, align 8
  %v600 = load i32, ptr %slot82, align 8
  %cv601 = zext i32 %v600 to i64
  %cond602 = icmp ne i64 %cv601, 0
  br i1 %cond602, label %bb_rcslotdrop85, label %bb_rcslotdone85
bb_rcslotdrop85:
  %v603 = load i64, ptr %slot8, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i32 0, ptr %p604, align 4, !alias.scope !3, !noalias !4
  %v605 = load i64, ptr %slot13, align 8
  store i64 %v605, ptr %slot83, align 8
  %v606 = load i64, ptr %slot9, align 8
  %p607 = inttoptr i64 %v606 to ptr
  %ld608 = load i32, ptr %p607, align 4, !alias.scope !3, !noalias !4
  store i32 %ld608, ptr %slot84, align 8
  %v609 = load i32, ptr %slot84, align 8
  %op610 = and i32 %v609, 28
  store i32 %op610, ptr %slot85, align 8
  %v611 = load i32, ptr %slot85, align 8
  %cv612 = zext i32 %v611 to i64
  %cond613 = icmp ne i64 %cv612, 0
  br i1 %cond613, label %bb_rcslotrole85, label %bb_rcslotowner85
bb_rcslotrole85:
  %v614 = load i64, ptr %slot32, align 8
  store i64 %v614, ptr %slot86, align 8
  %v615 = load i64, ptr %slot86, align 8
  %v616 = load i64, ptr %slot83, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v615, i64 %v616) nomerge, !dbg !116
  br label %bb_rcslotdone85
bb_rcslotowner85:
  %v617 = load i64, ptr %slot32, align 8
  store i64 %v617, ptr %slot87, align 8
  %v618 = load i64, ptr %slot87, align 8
  %v619 = load i64, ptr %slot83, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v618, i64 %v619) nomerge, !dbg !116
  br label %bb_rcslotdone85
bb_rcslotdone85:
  br label %bb_i7
bb_i6:
  %v620 = load i64, ptr %slot22, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %ld622 = load i64, ptr %p621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld622, ptr %slot88, align 8
  %v623 = load i64, ptr %slot22, align 8
  %p624 = inttoptr i64 %v623 to ptr
  %ld625 = load i64, ptr %p624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld625, ptr %slot89, align 8
  %v626 = load i64, ptr %slot8, align 8
  %p627 = inttoptr i64 %v626 to ptr
  %ld628 = load i32, ptr %p627, align 4, !alias.scope !3, !noalias !4
  store i32 %ld628, ptr %slot90, align 8
  %v629 = load i64, ptr %slot9, align 8
  %p630 = inttoptr i64 %v629 to ptr
  %ld631 = load i32, ptr %p630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld631, ptr %slot91, align 8
  %v632 = load i32, ptr %slot91, align 8
  %op633 = and i32 %v632, 24
  store i32 %op633, ptr %slot91, align 8
  %v634 = load i32, ptr %slot91, align 8
  %cmp635 = icmp eq i32 %v634, 0
  %cv636 = zext i1 %cmp635 to i32
  store i32 %cv636, ptr %slot92, align 8
  %v637 = load i32, ptr %slot90, align 8
  %v638 = load i32, ptr %slot92, align 8
  %op639 = and i32 %v637, %v638
  store i32 %op639, ptr %slot93, align 8
  %v640 = load i32, ptr %slot93, align 8
  %cv641 = zext i32 %v640 to i64
  %cond642 = icmp ne i64 %cv641, 0
  br i1 %cond642, label %bb_rctake94, label %bb_rccopy94
bb_rctake94:
  %v643 = load i64, ptr %slot14, align 8
  store i64 %v643, ptr %slot94, align 8
  %v644 = load i64, ptr %slot33, align 8
  store i64 %v644, ptr %slot95, align 8
  %v645 = load i64, ptr %slot32, align 8
  %v646 = load i64, ptr %slot94, align 8
  %v647 = load i64, ptr %slot89, align 8
  %v648 = load i64, ptr %slot95, align 8
  %cv649 = trunc i64 %v648 to i32
  %call650 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v645, i64 %v646, i64 %v647, i32 %cv649) nomerge, !dbg !118
  store i32 %call650, ptr %slot96, align 8
  %v651 = load i32, ptr %slot96, align 8
  %cv652 = zext i32 %v651 to i64
  %cond653 = icmp ne i64 %cv652, 0
  br i1 %cond653, label %bb_rcsuccess104, label %bb_rcfailure104
bb_rcfailure104:
  %v654 = load i64, ptr %slot32, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %call656 = call i32 @myl_rc_take_failure(ptr %p655) nomerge, !dbg !118
  store i32 %call656, ptr %slot97, align 8
  %v657 = load i64, ptr %slot1, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %v659 = load i32, ptr %slot97, align 8
  %call660 = call i32 @myl_qbe_rc_status(ptr %p658, i32 %v659) nomerge, !dbg !118
  store i32 %call660, ptr %slot98, align 8
  br label %bb_failure
bb_rcsuccess104:
  %v661 = load i64, ptr %slot8, align 8
  %p662 = inttoptr i64 %v661 to ptr
  store i32 0, ptr %p662, align 4, !alias.scope !3, !noalias !4
  %v663 = load i64, ptr %slot11, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i32 2, ptr %p664, align 4, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot10, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i32 1, ptr %p666, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared94
bb_rccopy94:
  %v667 = load i64, ptr %slot14, align 8
  store i64 %v667, ptr %slot99, align 8
  %v668 = load i64, ptr %slot33, align 8
  store i64 %v668, ptr %slot100, align 8
  %v669 = load i64, ptr %slot32, align 8
  %v670 = load i64, ptr %slot99, align 8
  %v671 = load i64, ptr %slot89, align 8
  %v672 = load i64, ptr %slot100, align 8
  %cv673 = trunc i64 %v672 to i32
  %call674 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64 %v669, i64 %v670, i64 %v671, i32 %cv673) nomerge, !dbg !118
  store i32 %call674, ptr %slot101, align 8
  %v675 = load i32, ptr %slot101, align 8
  %cv676 = zext i32 %v675 to i64
  %cond677 = icmp ne i64 %cv676, 0
  br i1 %cond677, label %bb_rcsuccess113, label %bb_rcfailure113
bb_rcfailure113:
  %v678 = load i64, ptr %slot32, align 8
  %p679 = inttoptr i64 %v678 to ptr
  %call680 = call i32 @myl_rc_take_failure(ptr %p679) nomerge, !dbg !118
  store i32 %call680, ptr %slot102, align 8
  %v681 = load i64, ptr %slot1, align 8
  %p682 = inttoptr i64 %v681 to ptr
  %v683 = load i32, ptr %slot102, align 8
  %call684 = call i32 @myl_qbe_rc_status(ptr %p682, i32 %v683) nomerge, !dbg !118
  store i32 %call684, ptr %slot103, align 8
  br label %bb_failure
bb_rcsuccess113:
  %v685 = load i64, ptr %slot11, align 8
  %p686 = inttoptr i64 %v685 to ptr
  store i32 2, ptr %p686, align 4, !alias.scope !3, !noalias !4
  %v687 = load i64, ptr %slot10, align 8
  %p688 = inttoptr i64 %v687 to ptr
  store i32 1, ptr %p688, align 4, !alias.scope !3, !noalias !4
  %v689 = load i64, ptr %slot8, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i32, ptr %p690, align 4, !alias.scope !3, !noalias !4
  store i32 %ld691, ptr %slot104, align 8
  %v692 = load i32, ptr %slot104, align 8
  %cv693 = zext i32 %v692 to i64
  %cond694 = icmp ne i64 %cv693, 0
  br i1 %cond694, label %bb_rcslotdrop120, label %bb_rcslotdone120
bb_rcslotdrop120:
  %v695 = load i64, ptr %slot8, align 8
  %p696 = inttoptr i64 %v695 to ptr
  store i32 0, ptr %p696, align 4, !alias.scope !3, !noalias !4
  %v697 = load i64, ptr %slot13, align 8
  store i64 %v697, ptr %slot105, align 8
  %v698 = load i64, ptr %slot9, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i32, ptr %p699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld700, ptr %slot106, align 8
  %v701 = load i32, ptr %slot106, align 8
  %op702 = and i32 %v701, 28
  store i32 %op702, ptr %slot107, align 8
  %v703 = load i32, ptr %slot107, align 8
  %cv704 = zext i32 %v703 to i64
  %cond705 = icmp ne i64 %cv704, 0
  br i1 %cond705, label %bb_rcslotrole120, label %bb_rcslotowner120
bb_rcslotrole120:
  %v706 = load i64, ptr %slot32, align 8
  store i64 %v706, ptr %slot108, align 8
  %v707 = load i64, ptr %slot108, align 8
  %v708 = load i64, ptr %slot105, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v707, i64 %v708) nomerge, !dbg !118
  br label %bb_rcslotdone120
bb_rcslotowner120:
  %v709 = load i64, ptr %slot32, align 8
  store i64 %v709, ptr %slot109, align 8
  %v710 = load i64, ptr %slot109, align 8
  %v711 = load i64, ptr %slot105, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v710, i64 %v711) nomerge, !dbg !118
  br label %bb_rcslotdone120
bb_rcslotdone120:
  br label %bb_rcprepared94
bb_rcprepared94:
  %v712 = load i64, ptr %slot14, align 8
  store i64 %v712, ptr %slot110, align 8
  %v713 = load i64, ptr %slot10, align 8
  %p714 = inttoptr i64 %v713 to ptr
  store i32 0, ptr %p714, align 4, !alias.scope !3, !noalias !4
  %v715 = load i64, ptr %slot8, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %ld717 = load i32, ptr %p716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld717, ptr %slot111, align 8
  %v718 = load i32, ptr %slot111, align 8
  %cv719 = zext i32 %v718 to i64
  %cond720 = icmp ne i64 %cv719, 0
  br i1 %cond720, label %bb_rcslotdrop131, label %bb_rcslotdone131
bb_rcslotdrop131:
  %v721 = load i64, ptr %slot8, align 8
  %p722 = inttoptr i64 %v721 to ptr
  store i32 0, ptr %p722, align 4, !alias.scope !3, !noalias !4
  %v723 = load i64, ptr %slot13, align 8
  store i64 %v723, ptr %slot112, align 8
  %v724 = load i64, ptr %slot9, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %ld726 = load i32, ptr %p725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld726, ptr %slot113, align 8
  %v727 = load i32, ptr %slot113, align 8
  %op728 = and i32 %v727, 28
  store i32 %op728, ptr %slot114, align 8
  %v729 = load i32, ptr %slot114, align 8
  %cv730 = zext i32 %v729 to i64
  %cond731 = icmp ne i64 %cv730, 0
  br i1 %cond731, label %bb_rcslotrole131, label %bb_rcslotowner131
bb_rcslotrole131:
  %v732 = load i64, ptr %slot32, align 8
  store i64 %v732, ptr %slot115, align 8
  %v733 = load i64, ptr %slot115, align 8
  %v734 = load i64, ptr %slot112, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v733, i64 %v734) nomerge, !dbg !118
  br label %bb_rcslotdone131
bb_rcslotowner131:
  %v735 = load i64, ptr %slot32, align 8
  store i64 %v735, ptr %slot116, align 8
  %v736 = load i64, ptr %slot116, align 8
  %v737 = load i64, ptr %slot112, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v736, i64 %v737) nomerge, !dbg !118
  br label %bb_rcslotdone131
bb_rcslotdone131:
  %v738 = load i64, ptr %slot6, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i32, ptr %p739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld740, ptr %slot117, align 8
  %v741 = load i32, ptr %slot117, align 8
  %cv742 = zext i32 %v741 to i64
  %cond743 = icmp ne i64 %cv742, 0
  br i1 %cond743, label %bb_rcslotdrop158, label %bb_rcslotdone158
bb_rcslotdrop158:
  %v744 = load i64, ptr %slot6, align 8
  %p745 = inttoptr i64 %v744 to ptr
  store i32 0, ptr %p745, align 4, !alias.scope !3, !noalias !4
  %v746 = load i64, ptr %slot17, align 8
  store i64 %v746, ptr %slot118, align 8
  %v747 = load i64, ptr %slot7, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %ld749 = load i32, ptr %p748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld749, ptr %slot119, align 8
  %v750 = load i32, ptr %slot119, align 8
  %op751 = and i32 %v750, 28
  store i32 %op751, ptr %slot120, align 8
  %v752 = load i32, ptr %slot120, align 8
  %cv753 = zext i32 %v752 to i64
  %cond754 = icmp ne i64 %cv753, 0
  br i1 %cond754, label %bb_rcslotrole158, label %bb_rcslotowner158
bb_rcslotrole158:
  %v755 = load i64, ptr %slot32, align 8
  store i64 %v755, ptr %slot121, align 8
  %v756 = load i64, ptr %slot121, align 8
  %v757 = load i64, ptr %slot118, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v756, i64 %v757) nomerge, !dbg !118
  br label %bb_rcslotdone158
bb_rcslotowner158:
  %v758 = load i64, ptr %slot32, align 8
  store i64 %v758, ptr %slot122, align 8
  %v759 = load i64, ptr %slot122, align 8
  %v760 = load i64, ptr %slot118, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v759, i64 %v760) nomerge, !dbg !118
  br label %bb_rcslotdone158
bb_rcslotdone158:
  %v761 = load i64, ptr %slot110, align 8
  %p762 = inttoptr i64 %v761 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p762, i64 24, i1 false)
  ret void
bb_i7:
  %v763 = load i64, ptr %slot15, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %ld765 = load i64, ptr %p764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld765, ptr %slot123, align 8
  %v766 = load i64, ptr %slot123, align 8
  %v767 = load i64, ptr %slot25, align 8
  %p768 = inttoptr i64 %v766 to ptr
  %p769 = inttoptr i64 %v767 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p769, ptr %p768, i64 304, i1 false), !alias.scope !10000000
  %v770 = load i64, ptr %slot25, align 8
  %v771 = load i64, ptr %slot22, align 8
  %p772 = inttoptr i64 %v771 to ptr
  store i64 %v770, ptr %p772, align 8, !alias.scope !3, !noalias !4
  %v773 = load i64, ptr %slot22, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %ld775 = load i64, ptr %p774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld775, ptr %slot124, align 8
  %v776 = load i64, ptr %slot124, align 8
  %op777 = add i64 %v776, 32
  store i64 %op777, ptr %slot125, align 8
  %v778 = load i64, ptr %slot125, align 8
  %v779 = load i64, ptr %slot22, align 8
  %p780 = inttoptr i64 %v779 to ptr
  store i64 %v778, ptr %p780, align 8, !alias.scope !3, !noalias !4
  %v781 = load i64, ptr %slot6, align 8
  %p782 = inttoptr i64 %v781 to ptr
  %ld783 = load i32, ptr %p782, align 4, !alias.scope !3, !noalias !4
  store i32 %ld783, ptr %slot126, align 8
  %v784 = load i32, ptr %slot126, align 8
  %cv785 = zext i32 %v784 to i64
  %cond786 = icmp ne i64 %cv785, 0
  br i1 %cond786, label %bb_rcslotdrop179, label %bb_rcslotdone179
bb_rcslotdrop179:
  %v787 = load i64, ptr %slot6, align 8
  %p788 = inttoptr i64 %v787 to ptr
  store i32 0, ptr %p788, align 4, !alias.scope !3, !noalias !4
  %v789 = load i64, ptr %slot17, align 8
  store i64 %v789, ptr %slot127, align 8
  %v790 = load i64, ptr %slot7, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %ld792 = load i32, ptr %p791, align 4, !alias.scope !3, !noalias !4
  store i32 %ld792, ptr %slot128, align 8
  %v793 = load i32, ptr %slot128, align 8
  %op794 = and i32 %v793, 28
  store i32 %op794, ptr %slot129, align 8
  %v795 = load i32, ptr %slot129, align 8
  %cv796 = zext i32 %v795 to i64
  %cond797 = icmp ne i64 %cv796, 0
  br i1 %cond797, label %bb_rcslotrole179, label %bb_rcslotowner179
bb_rcslotrole179:
  %v798 = load i64, ptr %slot32, align 8
  store i64 %v798, ptr %slot130, align 8
  %v799 = load i64, ptr %slot130, align 8
  %v800 = load i64, ptr %slot127, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v799, i64 %v800) nomerge, !dbg !120
  br label %bb_rcslotdone179
bb_rcslotowner179:
  %v801 = load i64, ptr %slot32, align 8
  store i64 %v801, ptr %slot131, align 8
  %v802 = load i64, ptr %slot131, align 8
  %v803 = load i64, ptr %slot127, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v802, i64 %v803) nomerge, !dbg !120
  br label %bb_rcslotdone179
bb_rcslotdone179:
  %v804 = load i64, ptr %slot15, align 8
  %p805 = inttoptr i64 %v804 to ptr
  %ld806 = load i64, ptr %p805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld806, ptr %slot132, align 8
  %v807 = load i64, ptr %slot132, align 8
  %op808 = add i64 %v807, 32
  store i64 %op808, ptr %slot133, align 8
  %v809 = load i64, ptr %slot17, align 8
  store i64 %v809, ptr %slot134, align 8
  %v810 = load i64, ptr %slot133, align 8
  %v811 = load i64, ptr %slot134, align 8
  %p812 = inttoptr i64 %v810 to ptr
  %p813 = inttoptr i64 %v811 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p813, ptr %p812, i64 208, i1 false), !alias.scope !10000000
  %v814 = load i64, ptr %slot133, align 8
  %p815 = inttoptr i64 %v814 to ptr
  call void @llvm.memset.p0.i64(ptr %p815, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !120
  %v816 = load i64, ptr %slot6, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i32 1, ptr %p817, align 4, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot17, align 8
  %v819 = load i64, ptr %slot22, align 8
  %p820 = inttoptr i64 %v819 to ptr
  store i64 %v818, ptr %p820, align 8, !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot22, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ld823 = load i64, ptr %p822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld823, ptr %slot135, align 8
  %v824 = load i64, ptr %slot1, align 8
  %v825 = load i64, ptr %slot135, align 8
  %call826 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v824, i64 %v825) nomerge, !dbg !122
  store { i64, i64 } %call826, ptr %callresult137, align 8
  %addr827 = ptrtoint ptr %callresult137 to i64
  store i64 %addr827, ptr %slot136, align 8
  %v828 = load i64, ptr %slot136, align 8
  %v829 = load i64, ptr %slot22, align 8
  %p830 = inttoptr i64 %v829 to ptr
  store i64 %v828, ptr %p830, align 8, !alias.scope !3, !noalias !4
  %v831 = load i64, ptr %slot8, align 8
  %p832 = inttoptr i64 %v831 to ptr
  %ld833 = load i32, ptr %p832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld833, ptr %slot138, align 8
  %v834 = load i32, ptr %slot138, align 8
  %cv835 = zext i32 %v834 to i64
  %cond836 = icmp ne i64 %cv835, 0
  br i1 %cond836, label %bb_rcslotdrop194, label %bb_rcslotdone194
bb_rcslotdrop194:
  %v837 = load i64, ptr %slot8, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i32 0, ptr %p838, align 4, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot13, align 8
  store i64 %v839, ptr %slot139, align 8
  %v840 = load i64, ptr %slot9, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %ld842 = load i32, ptr %p841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld842, ptr %slot140, align 8
  %v843 = load i32, ptr %slot140, align 8
  %op844 = and i32 %v843, 28
  store i32 %op844, ptr %slot141, align 8
  %v845 = load i32, ptr %slot141, align 8
  %cv846 = zext i32 %v845 to i64
  %cond847 = icmp ne i64 %cv846, 0
  br i1 %cond847, label %bb_rcslotrole194, label %bb_rcslotowner194
bb_rcslotrole194:
  %v848 = load i64, ptr %slot32, align 8
  store i64 %v848, ptr %slot142, align 8
  %v849 = load i64, ptr %slot142, align 8
  %v850 = load i64, ptr %slot139, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v849, i64 %v850) nomerge, !dbg !122
  br label %bb_rcslotdone194
bb_rcslotowner194:
  %v851 = load i64, ptr %slot32, align 8
  store i64 %v851, ptr %slot143, align 8
  %v852 = load i64, ptr %slot143, align 8
  %v853 = load i64, ptr %slot139, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v852, i64 %v853) nomerge, !dbg !122
  br label %bb_rcslotdone194
bb_rcslotdone194:
  %v854 = load i64, ptr %slot22, align 8
  %p855 = inttoptr i64 %v854 to ptr
  %ld856 = load i64, ptr %p855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld856, ptr %slot144, align 8
  %v857 = load i64, ptr %slot144, align 8
  %v858 = load i64, ptr %slot20, align 8
  %p859 = inttoptr i64 %v857 to ptr
  %p860 = inttoptr i64 %v858 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p860, ptr %p859, i64 16, i1 false)
  %v861 = load i64, ptr %slot20, align 8
  %v862 = load i64, ptr %slot22, align 8
  %p863 = inttoptr i64 %v862 to ptr
  store i64 %v861, ptr %p863, align 8, !alias.scope !3, !noalias !4
  %v864 = load i64, ptr %slot22, align 8
  %p865 = inttoptr i64 %v864 to ptr
  %ld866 = load i64, ptr %p865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld866, ptr %slot145, align 8
  %v867 = load i64, ptr %slot145, align 8
  %p868 = inttoptr i64 %v867 to ptr
  %ld869 = load i32, ptr %p868, align 4, !alias.scope !3, !noalias !4
  %ext870 = zext i32 %ld869 to i64
  store i64 %ext870, ptr %slot146, align 8
  %v871 = load i64, ptr %slot146, align 8
  %cmp872 = icmp eq i64 %v871, 0
  %cv873 = zext i1 %cmp872 to i64
  store i64 %cv873, ptr %slot147, align 8
  %v874 = load i64, ptr %slot147, align 8
  %cond875 = icmp ne i64 %v874, 0
  br i1 %cond875, label %bb_rcarm204, label %bb_rcarmnext204
bb_rcarm204:
  br label %bb_i17
bb_rcarmnext204:
  %v876 = load i64, ptr %slot146, align 8
  %cmp877 = icmp eq i64 %v876, 1
  %cv878 = zext i1 %cmp877 to i64
  store i64 %cv878, ptr %slot148, align 8
  %v879 = load i64, ptr %slot148, align 8
  %cond880 = icmp ne i64 %v879, 0
  br i1 %cond880, label %bb_rcarm205, label %bb_rcarmnext205
bb_rcarm205:
  %v881 = load i64, ptr %slot14, align 8
  store i64 %v881, ptr %slot149, align 8
  %v882 = load i64, ptr %slot145, align 8
  %op883 = add i64 %v882, 8
  store i64 %op883, ptr %slot150, align 8
  %v884 = load i64, ptr %slot33, align 8
  store i64 %v884, ptr %slot151, align 8
  %v885 = load i64, ptr %slot150, align 8
  %p886 = inttoptr i64 %v885 to ptr
  %ld887 = load i8, ptr %p886, align 1, !alias.scope !3, !noalias !4
  %ext888 = zext i8 %ld887 to i64
  store i64 %ext888, ptr %slot152, align 8
  %v889 = load i64, ptr %slot152, align 8
  %cv890 = trunc i64 %v889 to i8
  %v891 = load i64, ptr %slot149, align 8
  %p892 = inttoptr i64 %v891 to ptr
  store i8 %cv890, ptr %p892, align 1, !alias.scope !3, !noalias !4
  %v893 = load i64, ptr %slot11, align 8
  %p894 = inttoptr i64 %v893 to ptr
  store i32 0, ptr %p894, align 4, !alias.scope !3, !noalias !4
  %v895 = load i64, ptr %slot10, align 8
  %p896 = inttoptr i64 %v895 to ptr
  store i32 1, ptr %p896, align 4, !alias.scope !3, !noalias !4
  %v897 = load i64, ptr %slot149, align 8
  %p898 = inttoptr i64 %v897 to ptr
  %ld899 = load i8, ptr %p898, align 1, !alias.scope !3, !noalias !4
  %ext900 = zext i8 %ld899 to i64
  store i64 %ext900, ptr %slot153, align 8
  %v901 = load i64, ptr %slot153, align 8
  %v902 = load i64, ptr %slot21, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i64 %v901, ptr %p903, align 8, !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot10, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i32 0, ptr %p905, align 4, !alias.scope !3, !noalias !4
  br label %bb_i19
bb_rcarmnext205:
  %v906 = load i64, ptr %slot146, align 8
  %cmp907 = icmp eq i64 %v906, 2
  %cv908 = zext i1 %cmp907 to i64
  store i64 %cv908, ptr %slot154, align 8
  %v909 = load i64, ptr %slot154, align 8
  %cond910 = icmp ne i64 %v909, 0
  br i1 %cond910, label %bb_rcarm214, label %bb_rcarmnext214
bb_rcarm214:
  br label %bb_i22
bb_rcarmnext214:
  %v911 = load i64, ptr %slot146, align 8
  %cmp912 = icmp eq i64 %v911, 3
  %cv913 = zext i1 %cmp912 to i64
  store i64 %cv913, ptr %slot155, align 8
  %v914 = load i64, ptr %slot155, align 8
  %cond915 = icmp ne i64 %v914, 0
  br i1 %cond915, label %bb_rcarm215, label %bb_rcarmnext215
bb_rcarm215:
  br label %bb_i24
bb_rcarmnext215:
  br label %bb_failure
bb_i17:
  %v916 = load i64, ptr %slot22, align 8
  %p917 = inttoptr i64 %v916 to ptr
  store i64 1, ptr %p917, align 8, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_i19:
  %v918 = load i64, ptr %slot21, align 8
  %p919 = inttoptr i64 %v918 to ptr
  %ld920 = load i64, ptr %p919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld920, ptr %slot156, align 8
  %v921 = load i64, ptr %slot156, align 8
  %v922 = load i64, ptr %slot22, align 8
  %p923 = inttoptr i64 %v922 to ptr
  store i64 %v921, ptr %p923, align 8, !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot22, align 8
  %p925 = inttoptr i64 %v924 to ptr
  %ld926 = load i64, ptr %p925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld926, ptr %slot157, align 8
  %v927 = load i64, ptr %slot157, align 8
  %op928 = xor i64 %v927, 1
  store i64 %op928, ptr %slot158, align 8
  %v929 = load i64, ptr %slot158, align 8
  %v930 = load i64, ptr %slot22, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i64 %v929, ptr %p931, align 8, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_i22:
  %v932 = load i64, ptr %slot22, align 8
  %p933 = inttoptr i64 %v932 to ptr
  store i64 0, ptr %p933, align 8, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_i24:
  %v934 = load i64, ptr %slot22, align 8
  %p935 = inttoptr i64 %v934 to ptr
  store i64 0, ptr %p935, align 8, !alias.scope !3, !noalias !4
  br label %bb_i26
bb_i26:
  %v936 = load i64, ptr %slot22, align 8
  %p937 = inttoptr i64 %v936 to ptr
  %ld938 = load i64, ptr %p937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld938, ptr %slot159, align 8
  %v939 = load i64, ptr %slot159, align 8
  %op940 = xor i64 %v939, 1
  store i64 %op940, ptr %slot160, align 8
  %v941 = load i64, ptr %slot160, align 8
  %v942 = load i64, ptr %slot22, align 8
  %p943 = inttoptr i64 %v942 to ptr
  store i64 %v941, ptr %p943, align 8, !alias.scope !3, !noalias !4
  %v944 = load i64, ptr %slot22, align 8
  %p945 = inttoptr i64 %v944 to ptr
  %ld946 = load i64, ptr %p945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld946, ptr %slot161, align 8
  %v947 = load i64, ptr %slot161, align 8
  %v948 = load i64, ptr %slot18, align 8
  %p949 = inttoptr i64 %v948 to ptr
  store i64 %v947, ptr %p949, align 8, !alias.scope !3, !noalias !4
  %v950 = load i64, ptr %slot15, align 8
  %p951 = inttoptr i64 %v950 to ptr
  %ld952 = load i64, ptr %p951, align 8, !alias.scope !3, !noalias !4
  store i64 %ld952, ptr %slot162, align 8
  %v953 = load i64, ptr %slot162, align 8
  %op954 = add i64 %v953, 32
  store i64 %op954, ptr %slot163, align 8
  %v955 = load i64, ptr %slot17, align 8
  store i64 %v955, ptr %slot164, align 8
  %v956 = load i64, ptr %slot164, align 8
  %v957 = load i64, ptr %slot163, align 8
  %p958 = inttoptr i64 %v956 to ptr
  %p959 = inttoptr i64 %v957 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p959, ptr %p958, i64 208, i1 false), !alias.scope !10000000
  %v960 = load i64, ptr %slot164, align 8
  %p961 = inttoptr i64 %v960 to ptr
  call void @llvm.memset.p0.i64(ptr %p961, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !124
  %v962 = load i64, ptr %slot6, align 8
  %p963 = inttoptr i64 %v962 to ptr
  store i32 0, ptr %p963, align 4, !alias.scope !3, !noalias !4
  %v964 = load i64, ptr %slot22, align 8
  %p965 = inttoptr i64 %v964 to ptr
  store i64 0, ptr %p965, align 8, !alias.scope !3, !noalias !4
  %v966 = load i64, ptr %slot18, align 8
  %p967 = inttoptr i64 %v966 to ptr
  %ld968 = load i64, ptr %p967, align 8, !alias.scope !3, !noalias !4
  store i64 %ld968, ptr %slot165, align 8
  %v969 = load i64, ptr %slot165, align 8
  %v970 = load i64, ptr %slot22, align 8
  %p971 = inttoptr i64 %v970 to ptr
  store i64 %v969, ptr %p971, align 8, !alias.scope !3, !noalias !4
  %v972 = load i64, ptr %slot22, align 8
  %p973 = inttoptr i64 %v972 to ptr
  %ld974 = load i64, ptr %p973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld974, ptr %slot166, align 8
  %v975 = load i64, ptr %slot166, align 8
  %cond976 = icmp ne i64 %v975, 0
  br i1 %cond976, label %bb_next228, label %bb_i48
bb_next228:
  %v977 = load i64, ptr %slot15, align 8
  %p978 = inttoptr i64 %v977 to ptr
  %ld979 = load i64, ptr %p978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld979, ptr %slot167, align 8
  %v980 = load i64, ptr %slot167, align 8
  %v981 = load i64, ptr %slot22, align 8
  %p982 = inttoptr i64 %v981 to ptr
  store i64 %v980, ptr %p982, align 8, !alias.scope !3, !noalias !4
  %v983 = load i64, ptr %slot16, align 8
  %p984 = inttoptr i64 %v983 to ptr
  %ld985 = load i64, ptr %p984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld985, ptr %slot168, align 8
  %v986 = load i64, ptr %slot168, align 8
  %v987 = load i64, ptr %slot23, align 8
  %p988 = inttoptr i64 %v987 to ptr
  store i64 %v986, ptr %p988, align 8, !alias.scope !3, !noalias !4
  %v989 = load i64, ptr %slot23, align 8
  %p990 = inttoptr i64 %v989 to ptr
  %ld991 = load i64, ptr %p990, align 8, !alias.scope !3, !noalias !4
  store i64 %ld991, ptr %slot169, align 8
  %v992 = load i64, ptr %slot169, align 8
  %op993 = add i64 %v992, 8
  store i64 %op993, ptr %slot170, align 8
  %v994 = load i64, ptr %slot170, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %ld996 = load i64, ptr %p995, align 8, !alias.scope !4, !noalias !3
  store i64 %ld996, ptr %slot171, align 8
  %v997 = load i64, ptr %slot171, align 8
  %v998 = load i64, ptr %slot23, align 8
  %p999 = inttoptr i64 %v998 to ptr
  store i64 %v997, ptr %p999, align 8, !alias.scope !3, !noalias !4
  %v1000 = load i64, ptr %slot22, align 8
  %p1001 = inttoptr i64 %v1000 to ptr
  %ld1002 = load i64, ptr %p1001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1002, ptr %slot172, align 8
  %v1003 = load i64, ptr %slot23, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  %ld1005 = load i64, ptr %p1004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1005, ptr %slot173, align 8
  %v1006 = load i64, ptr %slot1, align 8
  %v1007 = load i64, ptr %slot172, align 8
  %v1008 = load i64, ptr %slot173, align 8
  call void @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806(ptr sret([24 x i8]) align 8 %callresult175, i64 %v1006, i64 %v1007, i64 %v1008) nomerge, !dbg !126
  %addr1009 = ptrtoint ptr %callresult175 to i64
  store i64 %addr1009, ptr %slot174, align 8
  %v1010 = load i64, ptr %slot174, align 8
  %v1011 = load i64, ptr %slot22, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  store i64 %v1010, ptr %p1012, align 8, !alias.scope !3, !noalias !4
  %v1013 = load i64, ptr %slot22, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  %ld1015 = load i64, ptr %p1014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1015, ptr %slot176, align 8
  %v1016 = load i64, ptr %slot14, align 8
  store i64 %v1016, ptr %slot177, align 8
  %v1017 = load i64, ptr %slot176, align 8
  %v1018 = load i64, ptr %slot177, align 8
  %p1019 = inttoptr i64 %v1017 to ptr
  %p1020 = inttoptr i64 %v1018 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1020, ptr %p1019, i64 24, i1 false)
  %v1021 = load i64, ptr %slot11, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  store i32 2, ptr %p1022, align 4, !alias.scope !3, !noalias !4
  %v1023 = load i64, ptr %slot10, align 8
  %p1024 = inttoptr i64 %v1023 to ptr
  store i32 1, ptr %p1024, align 4, !alias.scope !3, !noalias !4
  %v1025 = load i64, ptr %slot8, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  %ld1027 = load i32, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1027, ptr %slot178, align 8
  %v1028 = load i32, ptr %slot178, align 8
  %cv1029 = zext i32 %v1028 to i64
  %cond1030 = icmp ne i64 %cv1029, 0
  br i1 %cond1030, label %bb_rcslotdrop242, label %bb_rcslotdone242
bb_rcslotdrop242:
  %v1031 = load i64, ptr %slot8, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  store i32 0, ptr %p1032, align 4, !alias.scope !3, !noalias !4
  %v1033 = load i64, ptr %slot13, align 8
  store i64 %v1033, ptr %slot179, align 8
  %v1034 = load i64, ptr %slot9, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i32, ptr %p1035, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1036, ptr %slot180, align 8
  %v1037 = load i32, ptr %slot180, align 8
  %op1038 = and i32 %v1037, 28
  store i32 %op1038, ptr %slot181, align 8
  %v1039 = load i32, ptr %slot181, align 8
  %cv1040 = zext i32 %v1039 to i64
  %cond1041 = icmp ne i64 %cv1040, 0
  br i1 %cond1041, label %bb_rcslotrole242, label %bb_rcslotowner242
bb_rcslotrole242:
  %v1042 = load i64, ptr %slot32, align 8
  store i64 %v1042, ptr %slot182, align 8
  %v1043 = load i64, ptr %slot182, align 8
  %v1044 = load i64, ptr %slot179, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1043, i64 %v1044) nomerge, !dbg !126
  br label %bb_rcslotdone242
bb_rcslotowner242:
  %v1045 = load i64, ptr %slot32, align 8
  store i64 %v1045, ptr %slot183, align 8
  %v1046 = load i64, ptr %slot183, align 8
  %v1047 = load i64, ptr %slot179, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1046, i64 %v1047) nomerge, !dbg !126
  br label %bb_rcslotdone242
bb_rcslotdone242:
  %v1048 = load i64, ptr %slot13, align 8
  store i64 %v1048, ptr %slot184, align 8
  %v1049 = load i64, ptr %slot14, align 8
  store i64 %v1049, ptr %slot185, align 8
  %v1050 = load i64, ptr %slot185, align 8
  %v1051 = load i64, ptr %slot184, align 8
  %p1052 = inttoptr i64 %v1050 to ptr
  %p1053 = inttoptr i64 %v1051 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1053, ptr %p1052, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot9, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  store i32 2, ptr %p1055, align 4, !alias.scope !3, !noalias !4
  %v1056 = load i64, ptr %slot11, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  %ld1058 = load i32, ptr %p1057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1058, ptr %slot186, align 8
  %v1059 = load i32, ptr %slot186, align 8
  %v1060 = load i64, ptr %slot9, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  store i32 %v1059, ptr %p1061, align 4, !alias.scope !3, !noalias !4
  %v1062 = load i64, ptr %slot10, align 8
  %p1063 = inttoptr i64 %v1062 to ptr
  store i32 0, ptr %p1063, align 4, !alias.scope !3, !noalias !4
  %v1064 = load i64, ptr %slot8, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  store i32 1, ptr %p1065, align 4, !alias.scope !3, !noalias !4
  %v1066 = load i64, ptr %slot184, align 8
  %v1067 = load i64, ptr %slot22, align 8
  %p1068 = inttoptr i64 %v1067 to ptr
  store i64 %v1066, ptr %p1068, align 8, !alias.scope !3, !noalias !4
  %v1069 = load i64, ptr %slot22, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  %ld1071 = load i64, ptr %p1070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1071, ptr %slot187, align 8
  %v1072 = load i64, ptr %slot187, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i32, ptr %p1073, align 4, !alias.scope !3, !noalias !4
  %ext1075 = zext i32 %ld1074 to i64
  store i64 %ext1075, ptr %slot188, align 8
  %v1076 = load i64, ptr %slot188, align 8
  %cmp1077 = icmp eq i64 %v1076, 1
  %cv1078 = zext i1 %cmp1077 to i64
  store i64 %cv1078, ptr %slot189, align 8
  %v1079 = load i64, ptr %slot189, align 8
  %cond1080 = icmp ne i64 %v1079, 0
  br i1 %cond1080, label %bb_errtrace259, label %bb_errtraced259
bb_errtrace259:
  %p1081 = inttoptr i64 ptrtoint (ptr @myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1081, i64 8589934639) "call-inline-cost"="0", !dbg !128
  br label %bb_errtraced259
bb_errtraced259:
  %v1082 = load i64, ptr %slot22, align 8
  %p1083 = inttoptr i64 %v1082 to ptr
  %ld1084 = load i64, ptr %p1083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1084, ptr %slot190, align 8
  %v1085 = load i64, ptr %slot14, align 8
  store i64 %v1085, ptr %slot191, align 8
  %v1086 = load i64, ptr %slot33, align 8
  store i64 %v1086, ptr %slot192, align 8
  %v1087 = load i64, ptr %slot32, align 8
  %v1088 = load i64, ptr %slot191, align 8
  %v1089 = load i64, ptr %slot190, align 8
  %v1090 = load i64, ptr %slot192, align 8
  %cv1091 = trunc i64 %v1090 to i32
  %call1092 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v1087, i64 %v1088, i64 %v1089, i32 %cv1091) nomerge, !dbg !128
  store i32 %call1092, ptr %slot193, align 8
  %v1093 = load i32, ptr %slot193, align 8
  %cv1094 = zext i32 %v1093 to i64
  %cond1095 = icmp ne i64 %cv1094, 0
  br i1 %cond1095, label %bb_rcsuccess264, label %bb_rcfailure264
bb_rcfailure264:
  %v1096 = load i64, ptr %slot32, align 8
  %p1097 = inttoptr i64 %v1096 to ptr
  %call1098 = call i32 @myl_rc_take_failure(ptr %p1097) nomerge, !dbg !128
  store i32 %call1098, ptr %slot194, align 8
  %v1099 = load i64, ptr %slot1, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  %v1101 = load i32, ptr %slot194, align 8
  %call1102 = call i32 @myl_qbe_rc_status(ptr %p1100, i32 %v1101) nomerge, !dbg !128
  store i32 %call1102, ptr %slot195, align 8
  br label %bb_failure
bb_rcsuccess264:
  %v1103 = load i64, ptr %slot8, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  store i32 0, ptr %p1104, align 4, !alias.scope !3, !noalias !4
  %v1105 = load i64, ptr %slot11, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  store i32 2, ptr %p1106, align 4, !alias.scope !3, !noalias !4
  %v1107 = load i64, ptr %slot10, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  store i32 1, ptr %p1108, align 4, !alias.scope !3, !noalias !4
  %v1109 = load i64, ptr %slot14, align 8
  store i64 %v1109, ptr %slot196, align 8
  %v1110 = load i64, ptr %slot10, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  store i32 0, ptr %p1111, align 4, !alias.scope !3, !noalias !4
  %v1112 = load i64, ptr %slot8, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  %ld1114 = load i32, ptr %p1113, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1114, ptr %slot197, align 8
  %v1115 = load i32, ptr %slot197, align 8
  %cv1116 = zext i32 %v1115 to i64
  %cond1117 = icmp ne i64 %cv1116, 0
  br i1 %cond1117, label %bb_rcslotdrop274, label %bb_rcslotdone274
bb_rcslotdrop274:
  %v1118 = load i64, ptr %slot8, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i32 0, ptr %p1119, align 4, !alias.scope !3, !noalias !4
  %v1120 = load i64, ptr %slot13, align 8
  store i64 %v1120, ptr %slot198, align 8
  %v1121 = load i64, ptr %slot9, align 8
  %p1122 = inttoptr i64 %v1121 to ptr
  %ld1123 = load i32, ptr %p1122, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1123, ptr %slot199, align 8
  %v1124 = load i32, ptr %slot199, align 8
  %op1125 = and i32 %v1124, 28
  store i32 %op1125, ptr %slot200, align 8
  %v1126 = load i32, ptr %slot200, align 8
  %cv1127 = zext i32 %v1126 to i64
  %cond1128 = icmp ne i64 %cv1127, 0
  br i1 %cond1128, label %bb_rcslotrole274, label %bb_rcslotowner274
bb_rcslotrole274:
  %v1129 = load i64, ptr %slot32, align 8
  store i64 %v1129, ptr %slot201, align 8
  %v1130 = load i64, ptr %slot201, align 8
  %v1131 = load i64, ptr %slot198, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1130, i64 %v1131) nomerge, !dbg !128
  br label %bb_rcslotdone274
bb_rcslotowner274:
  %v1132 = load i64, ptr %slot32, align 8
  store i64 %v1132, ptr %slot202, align 8
  %v1133 = load i64, ptr %slot202, align 8
  %v1134 = load i64, ptr %slot198, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1133, i64 %v1134) nomerge, !dbg !128
  br label %bb_rcslotdone274
bb_rcslotdone274:
  %v1135 = load i64, ptr %slot6, align 8
  %p1136 = inttoptr i64 %v1135 to ptr
  %ld1137 = load i32, ptr %p1136, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1137, ptr %slot203, align 8
  %v1138 = load i32, ptr %slot203, align 8
  %cv1139 = zext i32 %v1138 to i64
  %cond1140 = icmp ne i64 %cv1139, 0
  br i1 %cond1140, label %bb_rcslotdrop301, label %bb_rcslotdone301
bb_rcslotdrop301:
  %v1141 = load i64, ptr %slot6, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  store i32 0, ptr %p1142, align 4, !alias.scope !3, !noalias !4
  %v1143 = load i64, ptr %slot17, align 8
  store i64 %v1143, ptr %slot204, align 8
  %v1144 = load i64, ptr %slot7, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %ld1146 = load i32, ptr %p1145, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1146, ptr %slot205, align 8
  %v1147 = load i32, ptr %slot205, align 8
  %op1148 = and i32 %v1147, 28
  store i32 %op1148, ptr %slot206, align 8
  %v1149 = load i32, ptr %slot206, align 8
  %cv1150 = zext i32 %v1149 to i64
  %cond1151 = icmp ne i64 %cv1150, 0
  br i1 %cond1151, label %bb_rcslotrole301, label %bb_rcslotowner301
bb_rcslotrole301:
  %v1152 = load i64, ptr %slot32, align 8
  store i64 %v1152, ptr %slot207, align 8
  %v1153 = load i64, ptr %slot207, align 8
  %v1154 = load i64, ptr %slot204, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1153, i64 %v1154) nomerge, !dbg !128
  br label %bb_rcslotdone301
bb_rcslotowner301:
  %v1155 = load i64, ptr %slot32, align 8
  store i64 %v1155, ptr %slot208, align 8
  %v1156 = load i64, ptr %slot208, align 8
  %v1157 = load i64, ptr %slot204, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1156, i64 %v1157) nomerge, !dbg !128
  br label %bb_rcslotdone301
bb_rcslotdone301:
  %v1158 = load i64, ptr %slot196, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1159, i64 24, i1 false)
  ret void
bb_i48:
  %v1160 = load i64, ptr %slot16, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  %ld1162 = load i64, ptr %p1161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1162, ptr %slot209, align 8
  %v1163 = load i64, ptr %slot209, align 8
  %v1164 = load i64, ptr %slot22, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  store i64 %v1163, ptr %p1165, align 8, !alias.scope !3, !noalias !4
  %v1166 = load i64, ptr %slot22, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  %ld1168 = load i64, ptr %p1167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1168, ptr %slot210, align 8
  %v1169 = load i64, ptr %slot210, align 8
  %op1170 = add i64 %v1169, 16
  store i64 %op1170, ptr %slot211, align 8
  %v1171 = load i64, ptr %slot211, align 8
  %v1172 = load i64, ptr %slot22, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  store i64 %v1171, ptr %p1173, align 8, !alias.scope !3, !noalias !4
  %v1174 = load i64, ptr %slot22, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %ld1176 = load i64, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1176, ptr %slot212, align 8
  %v1177 = load i64, ptr %slot212, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %ld1179 = load i32, ptr %p1178, align 4, !alias.scope !4, !noalias !3
  %ext1180 = zext i32 %ld1179 to i64
  store i64 %ext1180, ptr %slot213, align 8
  %v1181 = load i64, ptr %slot213, align 8
  %cmp1182 = icmp eq i64 %v1181, 0
  %cv1183 = zext i1 %cmp1182 to i64
  store i64 %cv1183, ptr %slot214, align 8
  %v1184 = load i64, ptr %slot214, align 8
  %cond1185 = icmp ne i64 %v1184, 0
  br i1 %cond1185, label %bb_rcarm322, label %bb_rcarmnext322
bb_rcarm322:
  br label %bb_i55
bb_rcarmnext322:
  %v1186 = load i64, ptr %slot213, align 8
  %cmp1187 = icmp eq i64 %v1186, 1
  %cv1188 = zext i1 %cmp1187 to i64
  store i64 %cv1188, ptr %slot215, align 8
  %v1189 = load i64, ptr %slot215, align 8
  %cond1190 = icmp ne i64 %v1189, 0
  br i1 %cond1190, label %bb_rcarm323, label %bb_rcarmnext323
bb_rcarm323:
  %v1191 = load i64, ptr %slot14, align 8
  store i64 %v1191, ptr %slot216, align 8
  %v1192 = load i64, ptr %slot212, align 8
  %op1193 = add i64 %v1192, 8
  store i64 %op1193, ptr %slot217, align 8
  %v1194 = load i64, ptr %slot33, align 8
  store i64 %v1194, ptr %slot218, align 8
  %v1195 = load i64, ptr %slot217, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %ld1197 = load i64, ptr %p1196, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1197, ptr %slot219, align 8
  %v1198 = load i64, ptr %slot219, align 8
  %v1199 = load i64, ptr %slot216, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  store i64 %v1198, ptr %p1200, align 8, !alias.scope !3, !noalias !4
  %v1201 = load i64, ptr %slot11, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  store i32 0, ptr %p1202, align 4, !alias.scope !3, !noalias !4
  %v1203 = load i64, ptr %slot10, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  store i32 1, ptr %p1204, align 4, !alias.scope !3, !noalias !4
  %v1205 = load i64, ptr %slot216, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  %ld1207 = load i64, ptr %p1206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1207, ptr %slot220, align 8
  %v1208 = load i64, ptr %slot220, align 8
  %v1209 = load i64, ptr %slot19, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i64 %v1208, ptr %p1210, align 8, !alias.scope !3, !noalias !4
  %v1211 = load i64, ptr %slot10, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i32 0, ptr %p1212, align 4, !alias.scope !3, !noalias !4
  br label %bb_i51
bb_rcarmnext323:
  br label %bb_failure
bb_i51:
  %v1213 = load i64, ptr %slot15, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i64, ptr %p1214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1215, ptr %slot221, align 8
  %v1216 = load i64, ptr %slot221, align 8
  %v1217 = load i64, ptr %slot22, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  store i64 %v1216, ptr %p1218, align 8, !alias.scope !3, !noalias !4
  %v1219 = load i64, ptr %slot19, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  %ld1221 = load i64, ptr %p1220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1221, ptr %slot222, align 8
  %v1222 = load i64, ptr %slot222, align 8
  %v1223 = load i64, ptr %slot23, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  store i64 %v1222, ptr %p1224, align 8, !alias.scope !3, !noalias !4
  %v1225 = load i64, ptr %slot22, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  %ld1227 = load i64, ptr %p1226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1227, ptr %slot223, align 8
  %v1228 = load i64, ptr %slot23, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  %ld1230 = load i64, ptr %p1229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1230, ptr %slot224, align 8
  %v1231 = load i64, ptr %slot1, align 8
  %v1232 = load i64, ptr %slot223, align 8
  %v1233 = load i64, ptr %slot224, align 8
  call void @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806(ptr sret([24 x i8]) align 8 %callresult226, i64 %v1231, i64 %v1232, i64 %v1233) nomerge, !dbg !130
  %addr1234 = ptrtoint ptr %callresult226 to i64
  store i64 %addr1234, ptr %slot225, align 8
  %v1235 = load i64, ptr %slot225, align 8
  %v1236 = load i64, ptr %slot22, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i64 %v1235, ptr %p1237, align 8, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot22, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  %ld1240 = load i64, ptr %p1239, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1240, ptr %slot227, align 8
  %v1241 = load i64, ptr %slot14, align 8
  store i64 %v1241, ptr %slot228, align 8
  %v1242 = load i64, ptr %slot227, align 8
  %v1243 = load i64, ptr %slot228, align 8
  %p1244 = inttoptr i64 %v1242 to ptr
  %p1245 = inttoptr i64 %v1243 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1245, ptr %p1244, i64 24, i1 false)
  %v1246 = load i64, ptr %slot11, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  store i32 2, ptr %p1247, align 4, !alias.scope !3, !noalias !4
  %v1248 = load i64, ptr %slot10, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i32 1, ptr %p1249, align 4, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot8, align 8
  %p1251 = inttoptr i64 %v1250 to ptr
  %ld1252 = load i32, ptr %p1251, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1252, ptr %slot229, align 8
  %v1253 = load i32, ptr %slot229, align 8
  %cv1254 = zext i32 %v1253 to i64
  %cond1255 = icmp ne i64 %cv1254, 0
  br i1 %cond1255, label %bb_rcslotdrop343, label %bb_rcslotdone343
bb_rcslotdrop343:
  %v1256 = load i64, ptr %slot8, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  store i32 0, ptr %p1257, align 4, !alias.scope !3, !noalias !4
  %v1258 = load i64, ptr %slot13, align 8
  store i64 %v1258, ptr %slot230, align 8
  %v1259 = load i64, ptr %slot9, align 8
  %p1260 = inttoptr i64 %v1259 to ptr
  %ld1261 = load i32, ptr %p1260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1261, ptr %slot231, align 8
  %v1262 = load i32, ptr %slot231, align 8
  %op1263 = and i32 %v1262, 28
  store i32 %op1263, ptr %slot232, align 8
  %v1264 = load i32, ptr %slot232, align 8
  %cv1265 = zext i32 %v1264 to i64
  %cond1266 = icmp ne i64 %cv1265, 0
  br i1 %cond1266, label %bb_rcslotrole343, label %bb_rcslotowner343
bb_rcslotrole343:
  %v1267 = load i64, ptr %slot32, align 8
  store i64 %v1267, ptr %slot233, align 8
  %v1268 = load i64, ptr %slot233, align 8
  %v1269 = load i64, ptr %slot230, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1268, i64 %v1269) nomerge, !dbg !130
  br label %bb_rcslotdone343
bb_rcslotowner343:
  %v1270 = load i64, ptr %slot32, align 8
  store i64 %v1270, ptr %slot234, align 8
  %v1271 = load i64, ptr %slot234, align 8
  %v1272 = load i64, ptr %slot230, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1271, i64 %v1272) nomerge, !dbg !130
  br label %bb_rcslotdone343
bb_rcslotdone343:
  %v1273 = load i64, ptr %slot13, align 8
  store i64 %v1273, ptr %slot235, align 8
  %v1274 = load i64, ptr %slot14, align 8
  store i64 %v1274, ptr %slot236, align 8
  %v1275 = load i64, ptr %slot236, align 8
  %v1276 = load i64, ptr %slot235, align 8
  %p1277 = inttoptr i64 %v1275 to ptr
  %p1278 = inttoptr i64 %v1276 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1278, ptr %p1277, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1279 = load i64, ptr %slot9, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  store i32 2, ptr %p1280, align 4, !alias.scope !3, !noalias !4
  %v1281 = load i64, ptr %slot11, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  %ld1283 = load i32, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1283, ptr %slot237, align 8
  %v1284 = load i32, ptr %slot237, align 8
  %v1285 = load i64, ptr %slot9, align 8
  %p1286 = inttoptr i64 %v1285 to ptr
  store i32 %v1284, ptr %p1286, align 4, !alias.scope !3, !noalias !4
  %v1287 = load i64, ptr %slot10, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i32 0, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot8, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  store i32 1, ptr %p1290, align 4, !alias.scope !3, !noalias !4
  %v1291 = load i64, ptr %slot235, align 8
  %v1292 = load i64, ptr %slot22, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  store i64 %v1291, ptr %p1293, align 8, !alias.scope !3, !noalias !4
  %v1294 = load i64, ptr %slot22, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  %ld1296 = load i64, ptr %p1295, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1296, ptr %slot238, align 8
  %v1297 = load i64, ptr %slot238, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %ld1299 = load i32, ptr %p1298, align 4, !alias.scope !3, !noalias !4
  %ext1300 = zext i32 %ld1299 to i64
  store i64 %ext1300, ptr %slot239, align 8
  %v1301 = load i64, ptr %slot239, align 8
  %cmp1302 = icmp eq i64 %v1301, 1
  %cv1303 = zext i1 %cmp1302 to i64
  store i64 %cv1303, ptr %slot240, align 8
  %v1304 = load i64, ptr %slot240, align 8
  %cond1305 = icmp ne i64 %v1304, 0
  br i1 %cond1305, label %bb_errtrace360, label %bb_errtraced360
bb_errtrace360:
  %p1306 = inttoptr i64 ptrtoint (ptr @myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p1306, i64 8589934646) "call-inline-cost"="0", !dbg !132
  br label %bb_errtraced360
bb_errtraced360:
  %v1307 = load i64, ptr %slot22, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  %ld1309 = load i64, ptr %p1308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1309, ptr %slot241, align 8
  %v1310 = load i64, ptr %slot14, align 8
  store i64 %v1310, ptr %slot242, align 8
  %v1311 = load i64, ptr %slot33, align 8
  store i64 %v1311, ptr %slot243, align 8
  %v1312 = load i64, ptr %slot32, align 8
  %v1313 = load i64, ptr %slot242, align 8
  %v1314 = load i64, ptr %slot241, align 8
  %v1315 = load i64, ptr %slot243, align 8
  %cv1316 = trunc i64 %v1315 to i32
  %call1317 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v1312, i64 %v1313, i64 %v1314, i32 %cv1316) nomerge, !dbg !132
  store i32 %call1317, ptr %slot244, align 8
  %v1318 = load i32, ptr %slot244, align 8
  %cv1319 = zext i32 %v1318 to i64
  %cond1320 = icmp ne i64 %cv1319, 0
  br i1 %cond1320, label %bb_rcsuccess365, label %bb_rcfailure365
bb_rcfailure365:
  %v1321 = load i64, ptr %slot32, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  %call1323 = call i32 @myl_rc_take_failure(ptr %p1322) nomerge, !dbg !132
  store i32 %call1323, ptr %slot245, align 8
  %v1324 = load i64, ptr %slot1, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  %v1326 = load i32, ptr %slot245, align 8
  %call1327 = call i32 @myl_qbe_rc_status(ptr %p1325, i32 %v1326) nomerge, !dbg !132
  store i32 %call1327, ptr %slot246, align 8
  br label %bb_failure
bb_rcsuccess365:
  %v1328 = load i64, ptr %slot8, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 0, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot11, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  store i32 2, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  %v1332 = load i64, ptr %slot10, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i32 1, ptr %p1333, align 4, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot14, align 8
  store i64 %v1334, ptr %slot247, align 8
  %v1335 = load i64, ptr %slot10, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  store i32 0, ptr %p1336, align 4, !alias.scope !3, !noalias !4
  %v1337 = load i64, ptr %slot8, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  %ld1339 = load i32, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1339, ptr %slot248, align 8
  %v1340 = load i32, ptr %slot248, align 8
  %cv1341 = zext i32 %v1340 to i64
  %cond1342 = icmp ne i64 %cv1341, 0
  br i1 %cond1342, label %bb_rcslotdrop375, label %bb_rcslotdone375
bb_rcslotdrop375:
  %v1343 = load i64, ptr %slot8, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  store i32 0, ptr %p1344, align 4, !alias.scope !3, !noalias !4
  %v1345 = load i64, ptr %slot13, align 8
  store i64 %v1345, ptr %slot249, align 8
  %v1346 = load i64, ptr %slot9, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %ld1348 = load i32, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1348, ptr %slot250, align 8
  %v1349 = load i32, ptr %slot250, align 8
  %op1350 = and i32 %v1349, 28
  store i32 %op1350, ptr %slot251, align 8
  %v1351 = load i32, ptr %slot251, align 8
  %cv1352 = zext i32 %v1351 to i64
  %cond1353 = icmp ne i64 %cv1352, 0
  br i1 %cond1353, label %bb_rcslotrole375, label %bb_rcslotowner375
bb_rcslotrole375:
  %v1354 = load i64, ptr %slot32, align 8
  store i64 %v1354, ptr %slot252, align 8
  %v1355 = load i64, ptr %slot252, align 8
  %v1356 = load i64, ptr %slot249, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1355, i64 %v1356) nomerge, !dbg !132
  br label %bb_rcslotdone375
bb_rcslotowner375:
  %v1357 = load i64, ptr %slot32, align 8
  store i64 %v1357, ptr %slot253, align 8
  %v1358 = load i64, ptr %slot253, align 8
  %v1359 = load i64, ptr %slot249, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1358, i64 %v1359) nomerge, !dbg !132
  br label %bb_rcslotdone375
bb_rcslotdone375:
  %v1360 = load i64, ptr %slot6, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  %ld1362 = load i32, ptr %p1361, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1362, ptr %slot254, align 8
  %v1363 = load i32, ptr %slot254, align 8
  %cv1364 = zext i32 %v1363 to i64
  %cond1365 = icmp ne i64 %cv1364, 0
  br i1 %cond1365, label %bb_rcslotdrop402, label %bb_rcslotdone402
bb_rcslotdrop402:
  %v1366 = load i64, ptr %slot6, align 8
  %p1367 = inttoptr i64 %v1366 to ptr
  store i32 0, ptr %p1367, align 4, !alias.scope !3, !noalias !4
  %v1368 = load i64, ptr %slot17, align 8
  store i64 %v1368, ptr %slot255, align 8
  %v1369 = load i64, ptr %slot7, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %ld1371 = load i32, ptr %p1370, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1371, ptr %slot256, align 8
  %v1372 = load i32, ptr %slot256, align 8
  %op1373 = and i32 %v1372, 28
  store i32 %op1373, ptr %slot257, align 8
  %v1374 = load i32, ptr %slot257, align 8
  %cv1375 = zext i32 %v1374 to i64
  %cond1376 = icmp ne i64 %cv1375, 0
  br i1 %cond1376, label %bb_rcslotrole402, label %bb_rcslotowner402
bb_rcslotrole402:
  %v1377 = load i64, ptr %slot32, align 8
  store i64 %v1377, ptr %slot258, align 8
  %v1378 = load i64, ptr %slot258, align 8
  %v1379 = load i64, ptr %slot255, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1378, i64 %v1379) nomerge, !dbg !132
  br label %bb_rcslotdone402
bb_rcslotowner402:
  %v1380 = load i64, ptr %slot32, align 8
  store i64 %v1380, ptr %slot259, align 8
  %v1381 = load i64, ptr %slot259, align 8
  %v1382 = load i64, ptr %slot255, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1381, i64 %v1382) nomerge, !dbg !132
  br label %bb_rcslotdone402
bb_rcslotdone402:
  %v1383 = load i64, ptr %slot247, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1384, i64 24, i1 false)
  ret void
bb_i55:
  br label %bb_i56
bb_i56:
  %v1385 = load i64, ptr %slot26, align 8
  store i64 %v1385, ptr %slot260, align 8
  %v1386 = load i64, ptr %slot260, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  store i32 0, ptr %p1387, align 4, !alias.scope !3, !noalias !4
  %v1388 = load i64, ptr %slot260, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  store i32 0, ptr %p1389, align 4, !alias.scope !3, !noalias !4
  %v1390 = load i64, ptr %slot260, align 8
  %v1391 = load i64, ptr %slot22, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  store i64 %v1390, ptr %p1392, align 8, !alias.scope !3, !noalias !4
  %v1393 = load i64, ptr %slot27, align 8
  store i64 %v1393, ptr %slot261, align 8
  %v1394 = load i64, ptr %slot261, align 8
  %p1395 = inttoptr i64 %v1394 to ptr
  store i64 0, ptr %p1395, align 8, !alias.scope !3, !noalias !4
  %v1396 = load i64, ptr %slot261, align 8
  %p1398 = inttoptr i64 %v1396 to ptr
  %gep1399 = getelementptr i8, ptr %p1398, i64 8
  %op1397 = ptrtoint ptr %gep1399 to i64
  store i64 %op1397, ptr %slot262, align 8
  %v1400 = load i64, ptr %slot262, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  store i64 0, ptr %p1401, align 8, !alias.scope !3, !noalias !4
  %v1402 = load i64, ptr %slot261, align 8
  %p1404 = inttoptr i64 %v1402 to ptr
  %gep1405 = getelementptr i8, ptr %p1404, i64 16
  %op1403 = ptrtoint ptr %gep1405 to i64
  store i64 %op1403, ptr %slot263, align 8
  %v1406 = load i64, ptr %slot263, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i64 0, ptr %p1407, align 8, !alias.scope !3, !noalias !4
  %v1408 = load i64, ptr %slot261, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  store i32 0, ptr %p1409, align 4, !alias.scope !3, !noalias !4
  %v1410 = load i64, ptr %slot12, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  store i32 1, ptr %p1411, align 4, !alias.scope !3, !noalias !4
  %v1412 = load i64, ptr %slot22, align 8
  %p1413 = inttoptr i64 %v1412 to ptr
  %ld1414 = load i64, ptr %p1413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1414, ptr %slot264, align 8
  %v1415 = load i64, ptr %slot261, align 8
  %p1417 = inttoptr i64 %v1415 to ptr
  %gep1418 = getelementptr i8, ptr %p1417, i64 8
  %op1416 = ptrtoint ptr %gep1418 to i64
  store i64 %op1416, ptr %slot265, align 8
  %v1419 = load i64, ptr %slot33, align 8
  store i64 %v1419, ptr %slot266, align 8
  %v1420 = load i64, ptr %slot264, align 8
  %v1421 = load i64, ptr %slot265, align 8
  %p1422 = inttoptr i64 %v1420 to ptr
  %p1423 = inttoptr i64 %v1421 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1423, ptr %p1422, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot261, align 8
  %v1425 = load i64, ptr %slot22, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  store i64 %v1424, ptr %p1426, align 8, !alias.scope !3, !noalias !4
  %v1427 = load i64, ptr %slot22, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  %ld1429 = load i64, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1429, ptr %slot267, align 8
  %v1430 = load i64, ptr %slot13, align 8
  store i64 %v1430, ptr %slot268, align 8
  %v1431 = load i64, ptr %slot267, align 8
  %v1432 = load i64, ptr %slot268, align 8
  %p1433 = inttoptr i64 %v1431 to ptr
  %p1434 = inttoptr i64 %v1432 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1434, ptr %p1433, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1435 = load i64, ptr %slot9, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  store i32 2, ptr %p1436, align 4, !alias.scope !3, !noalias !4
  %v1437 = load i64, ptr %slot8, align 8
  %p1438 = inttoptr i64 %v1437 to ptr
  store i32 1, ptr %p1438, align 4, !alias.scope !3, !noalias !4
  %v1439 = load i64, ptr %slot268, align 8
  %v1440 = load i64, ptr %slot22, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  store i64 %v1439, ptr %p1441, align 8, !alias.scope !3, !noalias !4
  %v1442 = load i64, ptr %slot22, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  %ld1444 = load i64, ptr %p1443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1444, ptr %slot269, align 8
  %v1445 = load i64, ptr %slot22, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  %ld1447 = load i64, ptr %p1446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1447, ptr %slot270, align 8
  %v1448 = load i64, ptr %slot14, align 8
  store i64 %v1448, ptr %slot271, align 8
  %v1449 = load i64, ptr %slot33, align 8
  store i64 %v1449, ptr %slot272, align 8
  %v1450 = load i64, ptr %slot32, align 8
  %v1451 = load i64, ptr %slot271, align 8
  %v1452 = load i64, ptr %slot270, align 8
  %v1453 = load i64, ptr %slot272, align 8
  %cv1454 = trunc i64 %v1453 to i32
  %call1455 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v1450, i64 %v1451, i64 %v1452, i32 %cv1454) nomerge, !dbg !134
  store i32 %call1455, ptr %slot273, align 8
  %v1456 = load i32, ptr %slot273, align 8
  %cv1457 = zext i32 %v1456 to i64
  %cond1458 = icmp ne i64 %cv1457, 0
  br i1 %cond1458, label %bb_rcsuccess436, label %bb_rcfailure436
bb_rcfailure436:
  %v1459 = load i64, ptr %slot32, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  %call1461 = call i32 @myl_rc_take_failure(ptr %p1460) nomerge, !dbg !134
  store i32 %call1461, ptr %slot274, align 8
  %v1462 = load i64, ptr %slot1, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %v1464 = load i32, ptr %slot274, align 8
  %call1465 = call i32 @myl_qbe_rc_status(ptr %p1463, i32 %v1464) nomerge, !dbg !134
  store i32 %call1465, ptr %slot275, align 8
  br label %bb_failure
bb_rcsuccess436:
  %v1466 = load i64, ptr %slot8, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  store i32 0, ptr %p1467, align 4, !alias.scope !3, !noalias !4
  %v1468 = load i64, ptr %slot11, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  store i32 2, ptr %p1469, align 4, !alias.scope !3, !noalias !4
  %v1470 = load i64, ptr %slot10, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  store i32 1, ptr %p1471, align 4, !alias.scope !3, !noalias !4
  %v1472 = load i64, ptr %slot14, align 8
  store i64 %v1472, ptr %slot276, align 8
  %v1473 = load i64, ptr %slot10, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i32 0, ptr %p1474, align 4, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot8, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ld1477 = load i32, ptr %p1476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1477, ptr %slot277, align 8
  %v1478 = load i32, ptr %slot277, align 8
  %cv1479 = zext i32 %v1478 to i64
  %cond1480 = icmp ne i64 %cv1479, 0
  br i1 %cond1480, label %bb_rcslotdrop446, label %bb_rcslotdone446
bb_rcslotdrop446:
  %v1481 = load i64, ptr %slot8, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i32 0, ptr %p1482, align 4, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot13, align 8
  store i64 %v1483, ptr %slot278, align 8
  %v1484 = load i64, ptr %slot9, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %ld1486 = load i32, ptr %p1485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1486, ptr %slot279, align 8
  %v1487 = load i32, ptr %slot279, align 8
  %op1488 = and i32 %v1487, 28
  store i32 %op1488, ptr %slot280, align 8
  %v1489 = load i32, ptr %slot280, align 8
  %cv1490 = zext i32 %v1489 to i64
  %cond1491 = icmp ne i64 %cv1490, 0
  br i1 %cond1491, label %bb_rcslotrole446, label %bb_rcslotowner446
bb_rcslotrole446:
  %v1492 = load i64, ptr %slot32, align 8
  store i64 %v1492, ptr %slot281, align 8
  %v1493 = load i64, ptr %slot281, align 8
  %v1494 = load i64, ptr %slot278, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1493, i64 %v1494) nomerge, !dbg !134
  br label %bb_rcslotdone446
bb_rcslotowner446:
  %v1495 = load i64, ptr %slot32, align 8
  store i64 %v1495, ptr %slot282, align 8
  %v1496 = load i64, ptr %slot282, align 8
  %v1497 = load i64, ptr %slot278, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1496, i64 %v1497) nomerge, !dbg !134
  br label %bb_rcslotdone446
bb_rcslotdone446:
  %v1498 = load i64, ptr %slot6, align 8
  %p1499 = inttoptr i64 %v1498 to ptr
  %ld1500 = load i32, ptr %p1499, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1500, ptr %slot283, align 8
  %v1501 = load i32, ptr %slot283, align 8
  %cv1502 = zext i32 %v1501 to i64
  %cond1503 = icmp ne i64 %cv1502, 0
  br i1 %cond1503, label %bb_rcslotdrop473, label %bb_rcslotdone473
bb_rcslotdrop473:
  %v1504 = load i64, ptr %slot6, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  store i32 0, ptr %p1505, align 4, !alias.scope !3, !noalias !4
  %v1506 = load i64, ptr %slot17, align 8
  store i64 %v1506, ptr %slot284, align 8
  %v1507 = load i64, ptr %slot7, align 8
  %p1508 = inttoptr i64 %v1507 to ptr
  %ld1509 = load i32, ptr %p1508, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1509, ptr %slot285, align 8
  %v1510 = load i32, ptr %slot285, align 8
  %op1511 = and i32 %v1510, 28
  store i32 %op1511, ptr %slot286, align 8
  %v1512 = load i32, ptr %slot286, align 8
  %cv1513 = zext i32 %v1512 to i64
  %cond1514 = icmp ne i64 %cv1513, 0
  br i1 %cond1514, label %bb_rcslotrole473, label %bb_rcslotowner473
bb_rcslotrole473:
  %v1515 = load i64, ptr %slot32, align 8
  store i64 %v1515, ptr %slot287, align 8
  %v1516 = load i64, ptr %slot287, align 8
  %v1517 = load i64, ptr %slot284, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1516, i64 %v1517) nomerge, !dbg !134
  br label %bb_rcslotdone473
bb_rcslotowner473:
  %v1518 = load i64, ptr %slot32, align 8
  store i64 %v1518, ptr %slot288, align 8
  %v1519 = load i64, ptr %slot288, align 8
  %v1520 = load i64, ptr %slot284, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1519, i64 %v1520) nomerge, !dbg !134
  br label %bb_rcslotdone473
bb_rcslotdone473:
  %v1521 = load i64, ptr %slot276, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1522, i64 24, i1 false)
  ret void
bb_failure:
  %v1523 = load i64, ptr %slot5, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  call void @llvm.memset.p0.i64(ptr %p1524, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v1525 = load i64, ptr %slot5, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1526, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v1527 = load i64, ptr %slot5, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  call void @llvm.memset.p0.i64(ptr %p1528, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v1529 = load i64, ptr %slot5, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1530, i64 24, i1 false)
  ret void
}

@myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare void @myl_f_866b323a26c1f255ec52657168306d80f60f75f1d366d57675001af4151be806(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64, i64)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004", linkageName: "myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8736419093023068627, i64 0, !"myl_f_3d29329083174bf818b439bb3217314531a8b31362370e550c87b36cf78b4004"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!122 = !DILocation(line: 14, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!124 = !DILocation(line: 39, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!126 = !DILocation(line: 47, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!128 = !DILocation(line: 48, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!130 = !DILocation(line: 54, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!132 = !DILocation(line: 55, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!134 = !DILocation(line: 59, column: 0, scope: !135)
