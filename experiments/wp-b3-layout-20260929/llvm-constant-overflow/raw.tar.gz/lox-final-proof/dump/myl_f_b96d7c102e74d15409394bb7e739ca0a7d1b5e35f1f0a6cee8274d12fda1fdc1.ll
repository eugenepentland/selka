target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_b96d7c102e74d15409394bb7e739ca0a7d1b5e35f1f0a6cee8274d12fda1fdc1(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v90 = load i64, ptr %slot1, align 8
  %op91 = add i64 %v90, 32
  store i64 %op91, ptr %slot3, align 8
  %mem92 = alloca i8, i64 8, align 8
  %ptr93 = ptrtoint ptr %mem92 to i64
  store i64 %ptr93, ptr %slot4, align 8
  %mem94 = alloca i8, i64 8, align 8
  %ptr95 = ptrtoint ptr %mem94 to i64
  store i64 %ptr95, ptr %slot5, align 8
  %mem96 = alloca i8, i64 8, align 8
  %ptr97 = ptrtoint ptr %mem96 to i64
  store i64 %ptr97, ptr %slot6, align 8
  %mem98 = alloca i8, i64 8, align 8
  %ptr99 = ptrtoint ptr %mem98 to i64
  store i64 %ptr99, ptr %slot7, align 8
  %v100 = load i64, ptr %slot2, align 8
  %v101 = load i64, ptr %slot4, align 8
  %p102 = inttoptr i64 %v101 to ptr
  store i64 %v100, ptr %p102, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v103 = load i64, ptr %slot4, align 8
  %p104 = inttoptr i64 %v103 to ptr
  %ld105 = load i64, ptr %p104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld105, ptr %slot8, align 8
  %v106 = load i64, ptr %slot8, align 8
  %v107 = load i64, ptr %slot5, align 8
  %p108 = inttoptr i64 %v107 to ptr
  store i64 %v106, ptr %p108, align 8, !alias.scope !3, !noalias !4
  %v109 = load i64, ptr %slot5, align 8
  %p110 = inttoptr i64 %v109 to ptr
  %ld111 = load i64, ptr %p110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld111, ptr %slot9, align 8
  %v112 = load i64, ptr %slot9, align 8
  %op113 = add i64 %v112, 0
  store i64 %op113, ptr %slot10, align 8
  %v114 = load i64, ptr %slot10, align 8
  %p115 = inttoptr i64 %v114 to ptr
  %ld116 = load i64, ptr %p115, align 8, !alias.scope !4, !noalias !3
  store i64 %ld116, ptr %slot11, align 8
  %v117 = load i64, ptr %slot11, align 8
  %v118 = load i64, ptr %slot5, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot6, align 8
  %p121 = inttoptr i64 %v120 to ptr
  store i64 0, ptr %p121, align 8, !alias.scope !3, !noalias !4
  %v122 = load i64, ptr %slot6, align 8
  %p123 = inttoptr i64 %v122 to ptr
  %ld124 = load i64, ptr %p123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld124, ptr %slot12, align 8
  %v125 = load i64, ptr %slot5, align 8
  %p126 = inttoptr i64 %v125 to ptr
  %ld127 = load i64, ptr %p126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld127, ptr %slot13, align 8
  %v128 = load i64, ptr %slot13, align 8
  %v129 = load i64, ptr %slot12, align 8
  %cmp130 = icmp sge i64 %v128, %v129
  %cv131 = zext i1 %cmp130 to i64
  store i64 %cv131, ptr %slot14, align 8
  %v132 = load i64, ptr %slot14, align 8
  %v133 = load i64, ptr %slot5, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i64 %v132, ptr %p134, align 8, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot5, align 8
  %p136 = inttoptr i64 %v135 to ptr
  %ld137 = load i64, ptr %p136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld137, ptr %slot15, align 8
  %v138 = load i64, ptr %slot15, align 8
  %cond139 = icmp ne i64 %v138, 0
  br i1 %cond139, label %bb_next8, label %bb_i10
bb_next8:
  %v140 = load i64, ptr %slot4, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i64, ptr %p141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld142, ptr %slot16, align 8
  %v143 = load i64, ptr %slot16, align 8
  %v144 = load i64, ptr %slot5, align 8
  %p145 = inttoptr i64 %v144 to ptr
  store i64 %v143, ptr %p145, align 8, !alias.scope !3, !noalias !4
  %v146 = load i64, ptr %slot5, align 8
  %p147 = inttoptr i64 %v146 to ptr
  %ld148 = load i64, ptr %p147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld148, ptr %slot17, align 8
  %v149 = load i64, ptr %slot17, align 8
  %op150 = add i64 %v149, 0
  store i64 %op150, ptr %slot18, align 8
  %v151 = load i64, ptr %slot18, align 8
  %p152 = inttoptr i64 %v151 to ptr
  %ld153 = load i64, ptr %p152, align 8, !alias.scope !4, !noalias !3
  store i64 %ld153, ptr %slot19, align 8
  %v154 = load i64, ptr %slot19, align 8
  %v155 = load i64, ptr %slot5, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 %v154, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot6, align 8
  %p158 = inttoptr i64 %v157 to ptr
  store i64 1000000, ptr %p158, align 8, !alias.scope !3, !noalias !4
  %v159 = load i64, ptr %slot6, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %ld161 = load i64, ptr %p160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld161, ptr %slot20, align 8
  %v162 = load i64, ptr %slot5, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld164, ptr %slot21, align 8
  %v165 = load i64, ptr %slot20, align 8
  %cmp166 = icmp eq i64 %v165, 0
  %cv167 = zext i1 %cmp166 to i64
  store i64 %cv167, ptr %slot22, align 8
  %v168 = load i64, ptr %slot22, align 8
  %cond169 = icmp ne i64 %v168, 0
  br i1 %cond169, label %bb_division14, label %bb_nonzero14
bb_division14:
  %v170 = load i64, ptr %slot1, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %v172 = load i64, ptr %slot21, align 8
  %v173 = load i64, ptr %slot20, align 8
  call void @myl_qbe_fail_division(ptr %p171, i64 5, i64 %v172, i64 %v173) nomerge, !dbg !110
  unreachable
bb_nonzero14:
  %v174 = load i64, ptr %slot21, align 8
  %cmp175 = icmp eq i64 %v174, 9223372036854775808
  %cv176 = zext i1 %cmp175 to i64
  store i64 %cv176, ptr %slot23, align 8
  %v177 = load i64, ptr %slot20, align 8
  %cmp178 = icmp eq i64 %v177, 18446744073709551615
  %cv179 = zext i1 %cmp178 to i64
  store i64 %cv179, ptr %slot24, align 8
  %v180 = load i64, ptr %slot23, align 8
  %v181 = load i64, ptr %slot24, align 8
  %op182 = and i64 %v180, %v181
  store i64 %op182, ptr %slot25, align 8
  %v183 = load i64, ptr %slot25, align 8
  %cond184 = icmp ne i64 %v183, 0
  br i1 %cond184, label %bb_overflow14, label %bb_checked14
bb_overflow14:
  %v185 = load i64, ptr %slot1, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %v187 = load i64, ptr %slot21, align 8
  %v188 = load i64, ptr %slot20, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p186, i64 5, i64 %v187, i64 %v188, i64 64) nomerge, !dbg !110
  unreachable
bb_checked14:
  %v189 = load i64, ptr %slot21, align 8
  %v190 = load i64, ptr %slot20, align 8
  %op191 = sdiv i64 %v189, %v190
  store i64 %op191, ptr %slot26, align 8
  %v192 = load i64, ptr %slot21, align 8
  %v193 = load i64, ptr %slot20, align 8
  %op194 = srem i64 %v192, %v193
  store i64 %op194, ptr %slot27, align 8
  %v195 = load i64, ptr %slot27, align 8
  %cmp196 = icmp ne i64 %v195, 0
  %cv197 = zext i1 %cmp196 to i64
  store i64 %cv197, ptr %slot28, align 8
  %v198 = load i64, ptr %slot27, align 8
  %v199 = load i64, ptr %slot20, align 8
  %op200 = xor i64 %v198, %v199
  store i64 %op200, ptr %slot29, align 8
  %v201 = load i64, ptr %slot29, align 8
  %cmp202 = icmp slt i64 %v201, 0
  %cv203 = zext i1 %cmp202 to i64
  store i64 %cv203, ptr %slot30, align 8
  %v204 = load i64, ptr %slot28, align 8
  %v205 = load i64, ptr %slot30, align 8
  %op206 = and i64 %v204, %v205
  store i64 %op206, ptr %slot31, align 8
  %v207 = load i64, ptr %slot31, align 8
  %neg208 = sub i64 0, %v207
  store i64 %neg208, ptr %slot32, align 8
  %v209 = load i64, ptr %slot26, align 8
  %v210 = load i64, ptr %slot31, align 8
  %op211 = sub i64 %v209, %v210
  store i64 %op211, ptr %slot26, align 8
  %v212 = load i64, ptr %slot26, align 8
  %v213 = load i64, ptr %slot5, align 8
  %p214 = inttoptr i64 %v213 to ptr
  store i64 %v212, ptr %p214, align 8, !alias.scope !3, !noalias !4
  %v215 = load i64, ptr %slot5, align 8
  %p216 = inttoptr i64 %v215 to ptr
  %ld217 = load i64, ptr %p216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld217, ptr %slot33, align 8
  %v218 = load i64, ptr %slot33, align 8
  ret i64 %v218
bb_i10:
  %v219 = load i64, ptr %slot4, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot34, align 8
  %v222 = load i64, ptr %slot34, align 8
  %v223 = load i64, ptr %slot5, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i64 %v222, ptr %p224, align 8, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot5, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot35, align 8
  %v228 = load i64, ptr %slot35, align 8
  %op229 = add i64 %v228, 0
  store i64 %op229, ptr %slot36, align 8
  %v230 = load i64, ptr %slot36, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !4, !noalias !3
  store i64 %ld232, ptr %slot37, align 8
  %v233 = load i64, ptr %slot37, align 8
  %v234 = load i64, ptr %slot5, align 8
  %p235 = inttoptr i64 %v234 to ptr
  store i64 %v233, ptr %p235, align 8, !alias.scope !3, !noalias !4
  %v236 = load i64, ptr %slot6, align 8
  %p237 = inttoptr i64 %v236 to ptr
  store i64 0, ptr %p237, align 8, !alias.scope !3, !noalias !4
  %v238 = load i64, ptr %slot7, align 8
  %p239 = inttoptr i64 %v238 to ptr
  store i64 9223372036854775807, ptr %p239, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v240 = load i64, ptr %slot7, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i64, ptr %p241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld242, ptr %slot38, align 8
  %v243 = load i64, ptr %slot6, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld245, ptr %slot39, align 8
  %v246 = load i64, ptr %slot39, align 8
  %v247 = load i64, ptr %slot38, align 8
  %ovpair249 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v246, i64 %v247)
  %op248 = extractvalue { i64, i1 } %ovpair249, 0
  %ov250 = extractvalue { i64, i1 } %ovpair249, 1
  store i64 %op248, ptr %slot40, align 8
  %v251 = load i64, ptr %slot39, align 8
  %v252 = load i64, ptr %slot38, align 8
  %op253 = xor i64 %v251, %v252
  store i64 %op253, ptr %slot41, align 8
  %v254 = load i64, ptr %slot39, align 8
  %v255 = load i64, ptr %slot40, align 8
  %op256 = xor i64 %v254, %v255
  store i64 %op256, ptr %slot42, align 8
  %v257 = load i64, ptr %slot41, align 8
  %v258 = load i64, ptr %slot42, align 8
  %op259 = and i64 %v257, %v258
  store i64 %op259, ptr %slot43, align 8
  %cv260 = zext i1 %ov250 to i64
  store i64 %cv260, ptr %slot44, align 8
  %v261 = load i64, ptr %slot44, align 8
  %cond262 = icmp ne i64 %v261, 0
  br i1 %cond262, label %bb_overflow32, label %bb_checked32
bb_overflow32:
  %v263 = load i64, ptr %slot1, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %v265 = load i64, ptr %slot39, align 8
  %v266 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p264, i64 1, i64 %v265, i64 %v266, i64 64) nomerge, !dbg !112
  unreachable
bb_checked32:
  %v267 = load i64, ptr %slot40, align 8
  %v268 = load i64, ptr %slot6, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i64 %v267, ptr %p269, align 8, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot7, align 8
  %p271 = inttoptr i64 %v270 to ptr
  store i64 1, ptr %p271, align 8, !alias.scope !3, !noalias !4
  %v272 = load i64, ptr %slot7, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %ld274 = load i64, ptr %p273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld274, ptr %slot45, align 8
  %v275 = load i64, ptr %slot6, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ld277 = load i64, ptr %p276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld277, ptr %slot46, align 8
  %v278 = load i64, ptr %slot46, align 8
  %v279 = load i64, ptr %slot45, align 8
  %ovpair281 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v278, i64 %v279)
  %op280 = extractvalue { i64, i1 } %ovpair281, 0
  %ov282 = extractvalue { i64, i1 } %ovpair281, 1
  store i64 %op280, ptr %slot47, align 8
  %cv283 = zext i1 %ov282 to i64
  store i64 %cv283, ptr %slot48, align 8
  %v284 = load i64, ptr %slot48, align 8
  %cond285 = icmp ne i64 %v284, 0
  br i1 %cond285, label %bb_overflow39, label %bb_checked39
bb_overflow39:
  %v286 = load i64, ptr %slot1, align 8
  %p287 = inttoptr i64 %v286 to ptr
  %v288 = load i64, ptr %slot46, align 8
  %v289 = load i64, ptr %slot45, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p287, i64 1, i64 %v288, i64 %v289, i64 64) nomerge, !dbg !114
  unreachable
bb_checked39:
  %v290 = load i64, ptr %slot47, align 8
  %v291 = load i64, ptr %slot6, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i64 %v290, ptr %p292, align 8, !alias.scope !3, !noalias !4
  %v293 = load i64, ptr %slot6, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot49, align 8
  %v296 = load i64, ptr %slot5, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld298, ptr %slot50, align 8
  %v299 = load i64, ptr %slot50, align 8
  %v300 = load i64, ptr %slot49, align 8
  %cmp301 = icmp eq i64 %v299, %v300
  %cv302 = zext i1 %cmp301 to i64
  store i64 %cv302, ptr %slot51, align 8
  %v303 = load i64, ptr %slot51, align 8
  %v304 = load i64, ptr %slot5, align 8
  %p305 = inttoptr i64 %v304 to ptr
  store i64 %v303, ptr %p305, align 8, !alias.scope !3, !noalias !4
  %v306 = load i64, ptr %slot5, align 8
  %p307 = inttoptr i64 %v306 to ptr
  %ld308 = load i64, ptr %p307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld308, ptr %slot52, align 8
  %v309 = load i64, ptr %slot52, align 8
  %cond310 = icmp ne i64 %v309, 0
  br i1 %cond310, label %bb_next45, label %bb_i24
bb_next45:
  %v311 = load i64, ptr %slot5, align 8
  %p312 = inttoptr i64 %v311 to ptr
  store i64 0, ptr %p312, align 8, !alias.scope !3, !noalias !4
  %v313 = load i64, ptr %slot6, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 9223372036854, ptr %p314, align 8, !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot6, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot53, align 8
  %v318 = load i64, ptr %slot5, align 8
  %p319 = inttoptr i64 %v318 to ptr
  %ld320 = load i64, ptr %p319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld320, ptr %slot54, align 8
  %v321 = load i64, ptr %slot54, align 8
  %v322 = load i64, ptr %slot53, align 8
  %op323 = sub i64 %v321, %v322
  store i64 %op323, ptr %slot55, align 8
  %v324 = load i64, ptr %slot54, align 8
  %cmp325 = icmp slt i64 %v324, 9223381260226812662
  %cv326 = zext i1 %cmp325 to i64
  store i64 %cv326, ptr %slot56, align 8
  %v327 = load i64, ptr %slot56, align 8
  %cond328 = icmp ne i64 %v327, 0
  br i1 %cond328, label %bb_overflow47, label %bb_checked47
bb_overflow47:
  %v329 = load i64, ptr %slot1, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %v331 = load i64, ptr %slot54, align 8
  %v332 = load i64, ptr %slot53, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p330, i64 1, i64 %v331, i64 %v332, i64 64) nomerge, !dbg !116
  unreachable
bb_checked47:
  %v333 = load i64, ptr %slot55, align 8
  %v334 = load i64, ptr %slot5, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i64 %v333, ptr %p335, align 8, !alias.scope !3, !noalias !4
  %v336 = load i64, ptr %slot5, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %ld338 = load i64, ptr %p337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld338, ptr %slot57, align 8
  %v339 = load i64, ptr %slot57, align 8
  ret i64 %v339
bb_i24:
  %v340 = load i64, ptr %slot5, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i64 0, ptr %p341, align 8, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot6, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i64 0, ptr %p343, align 8, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot4, align 8
  %p345 = inttoptr i64 %v344 to ptr
  %ld346 = load i64, ptr %p345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld346, ptr %slot58, align 8
  %v347 = load i64, ptr %slot58, align 8
  %v348 = load i64, ptr %slot7, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i64 %v347, ptr %p349, align 8, !alias.scope !3, !noalias !4
  %v350 = load i64, ptr %slot7, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot59, align 8
  %v353 = load i64, ptr %slot59, align 8
  %op354 = add i64 %v353, 0
  store i64 %op354, ptr %slot60, align 8
  %v355 = load i64, ptr %slot60, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !4, !noalias !3
  store i64 %ld357, ptr %slot61, align 8
  %v358 = load i64, ptr %slot61, align 8
  %v359 = load i64, ptr %slot7, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i64 %v358, ptr %p360, align 8, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot7, align 8
  %p362 = inttoptr i64 %v361 to ptr
  %ld363 = load i64, ptr %p362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld363, ptr %slot62, align 8
  %v364 = load i64, ptr %slot6, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot63, align 8
  %v367 = load i64, ptr %slot63, align 8
  %v368 = load i64, ptr %slot62, align 8
  %ovpair370 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v367, i64 %v368)
  %op369 = extractvalue { i64, i1 } %ovpair370, 0
  %ov371 = extractvalue { i64, i1 } %ovpair370, 1
  store i64 %op369, ptr %slot64, align 8
  %v372 = load i64, ptr %slot63, align 8
  %v373 = load i64, ptr %slot62, align 8
  %op374 = xor i64 %v372, %v373
  store i64 %op374, ptr %slot65, align 8
  %v375 = load i64, ptr %slot63, align 8
  %v376 = load i64, ptr %slot64, align 8
  %op377 = xor i64 %v375, %v376
  store i64 %op377, ptr %slot66, align 8
  %v378 = load i64, ptr %slot65, align 8
  %v379 = load i64, ptr %slot66, align 8
  %op380 = and i64 %v378, %v379
  store i64 %op380, ptr %slot67, align 8
  %cv381 = zext i1 %ov371 to i64
  store i64 %cv381, ptr %slot68, align 8
  %v382 = load i64, ptr %slot68, align 8
  %cond383 = icmp ne i64 %v382, 0
  br i1 %cond383, label %bb_overflow56, label %bb_checked56
bb_overflow56:
  %v384 = load i64, ptr %slot1, align 8
  %p385 = inttoptr i64 %v384 to ptr
  %v386 = load i64, ptr %slot63, align 8
  %v387 = load i64, ptr %slot62, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p385, i64 1, i64 %v386, i64 %v387, i64 64) nomerge, !dbg !118
  unreachable
bb_checked56:
  %v388 = load i64, ptr %slot64, align 8
  %v389 = load i64, ptr %slot6, align 8
  %p390 = inttoptr i64 %v389 to ptr
  store i64 %v388, ptr %p390, align 8, !alias.scope !3, !noalias !4
  %v391 = load i64, ptr %slot7, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i64 1000000, ptr %p392, align 8, !alias.scope !3, !noalias !4
  %v393 = load i64, ptr %slot7, align 8
  %p394 = inttoptr i64 %v393 to ptr
  %ld395 = load i64, ptr %p394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld395, ptr %slot69, align 8
  %v396 = load i64, ptr %slot6, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %ld398 = load i64, ptr %p397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld398, ptr %slot70, align 8
  %v399 = load i64, ptr %slot69, align 8
  %cmp400 = icmp eq i64 %v399, 0
  %cv401 = zext i1 %cmp400 to i64
  store i64 %cv401, ptr %slot71, align 8
  %v402 = load i64, ptr %slot71, align 8
  %cond403 = icmp ne i64 %v402, 0
  br i1 %cond403, label %bb_division63, label %bb_nonzero63
bb_division63:
  %v404 = load i64, ptr %slot1, align 8
  %p405 = inttoptr i64 %v404 to ptr
  %v406 = load i64, ptr %slot70, align 8
  %v407 = load i64, ptr %slot69, align 8
  call void @myl_qbe_fail_division(ptr %p405, i64 5, i64 %v406, i64 %v407) nomerge, !dbg !120
  unreachable
bb_nonzero63:
  %v408 = load i64, ptr %slot70, align 8
  %cmp409 = icmp eq i64 %v408, 9223372036854775808
  %cv410 = zext i1 %cmp409 to i64
  store i64 %cv410, ptr %slot72, align 8
  %v411 = load i64, ptr %slot69, align 8
  %cmp412 = icmp eq i64 %v411, 18446744073709551615
  %cv413 = zext i1 %cmp412 to i64
  store i64 %cv413, ptr %slot73, align 8
  %v414 = load i64, ptr %slot72, align 8
  %v415 = load i64, ptr %slot73, align 8
  %op416 = and i64 %v414, %v415
  store i64 %op416, ptr %slot74, align 8
  %v417 = load i64, ptr %slot74, align 8
  %cond418 = icmp ne i64 %v417, 0
  br i1 %cond418, label %bb_overflow63, label %bb_checked63
bb_overflow63:
  %v419 = load i64, ptr %slot1, align 8
  %p420 = inttoptr i64 %v419 to ptr
  %v421 = load i64, ptr %slot70, align 8
  %v422 = load i64, ptr %slot69, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p420, i64 5, i64 %v421, i64 %v422, i64 64) nomerge, !dbg !120
  unreachable
bb_checked63:
  %v423 = load i64, ptr %slot70, align 8
  %v424 = load i64, ptr %slot69, align 8
  %op425 = sdiv i64 %v423, %v424
  store i64 %op425, ptr %slot75, align 8
  %v426 = load i64, ptr %slot70, align 8
  %v427 = load i64, ptr %slot69, align 8
  %op428 = srem i64 %v426, %v427
  store i64 %op428, ptr %slot76, align 8
  %v429 = load i64, ptr %slot76, align 8
  %cmp430 = icmp ne i64 %v429, 0
  %cv431 = zext i1 %cmp430 to i64
  store i64 %cv431, ptr %slot77, align 8
  %v432 = load i64, ptr %slot76, align 8
  %v433 = load i64, ptr %slot69, align 8
  %op434 = xor i64 %v432, %v433
  store i64 %op434, ptr %slot78, align 8
  %v435 = load i64, ptr %slot78, align 8
  %cmp436 = icmp slt i64 %v435, 0
  %cv437 = zext i1 %cmp436 to i64
  store i64 %cv437, ptr %slot79, align 8
  %v438 = load i64, ptr %slot77, align 8
  %v439 = load i64, ptr %slot79, align 8
  %op440 = and i64 %v438, %v439
  store i64 %op440, ptr %slot80, align 8
  %v441 = load i64, ptr %slot80, align 8
  %neg442 = sub i64 0, %v441
  store i64 %neg442, ptr %slot81, align 8
  %v443 = load i64, ptr %slot75, align 8
  %v444 = load i64, ptr %slot80, align 8
  %op445 = sub i64 %v443, %v444
  store i64 %op445, ptr %slot75, align 8
  %v446 = load i64, ptr %slot75, align 8
  %v447 = load i64, ptr %slot6, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i64 %v446, ptr %p448, align 8, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot6, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %ld451 = load i64, ptr %p450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld451, ptr %slot82, align 8
  %v452 = load i64, ptr %slot5, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot83, align 8
  %v455 = load i64, ptr %slot83, align 8
  %v456 = load i64, ptr %slot82, align 8
  %ovpair458 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v455, i64 %v456)
  %op457 = extractvalue { i64, i1 } %ovpair458, 0
  %ov459 = extractvalue { i64, i1 } %ovpair458, 1
  store i64 %op457, ptr %slot84, align 8
  %v460 = load i64, ptr %slot83, align 8
  %v461 = load i64, ptr %slot82, align 8
  %op462 = xor i64 %v460, %v461
  store i64 %op462, ptr %slot85, align 8
  %v463 = load i64, ptr %slot83, align 8
  %v464 = load i64, ptr %slot84, align 8
  %op465 = xor i64 %v463, %v464
  store i64 %op465, ptr %slot86, align 8
  %v466 = load i64, ptr %slot85, align 8
  %v467 = load i64, ptr %slot86, align 8
  %op468 = and i64 %v466, %v467
  store i64 %op468, ptr %slot87, align 8
  %cv469 = zext i1 %ov459 to i64
  store i64 %cv469, ptr %slot88, align 8
  %v470 = load i64, ptr %slot88, align 8
  %cond471 = icmp ne i64 %v470, 0
  br i1 %cond471, label %bb_overflow76, label %bb_checked76
bb_overflow76:
  %v472 = load i64, ptr %slot1, align 8
  %p473 = inttoptr i64 %v472 to ptr
  %v474 = load i64, ptr %slot83, align 8
  %v475 = load i64, ptr %slot82, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p473, i64 1, i64 %v474, i64 %v475, i64 64) nomerge, !dbg !122
  unreachable
bb_checked76:
  %v476 = load i64, ptr %slot84, align 8
  %v477 = load i64, ptr %slot5, align 8
  %p478 = inttoptr i64 %v477 to ptr
  store i64 %v476, ptr %p478, align 8, !alias.scope !3, !noalias !4
  %v479 = load i64, ptr %slot5, align 8
  %p480 = inttoptr i64 %v479 to ptr
  %ld481 = load i64, ptr %p480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld481, ptr %slot89, align 8
  %v482 = load i64, ptr %slot89, align 8
  ret i64 %v482
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_division(ptr, i64, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b96d7c102e74d15409394bb7e739ca0a7d1b5e35f1f0a6cee8274d12fda1fdc1", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b96d7c102e74d15409394bb7e739ca0a7d1b5e35f1f0a6cee8274d12fda1fdc1", linkageName: "myl_f_b96d7c102e74d15409394bb7e739ca0a7d1b5e35f1f0a6cee8274d12fda1fdc1", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5132129725249352974, i64 0, !"myl_f_b96d7c102e74d15409394bb7e739ca0a7d1b5e35f1f0a6cee8274d12fda1fdc1"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!110 = !DILocation(line: 9, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!112 = !DILocation(line: 16, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!114 = !DILocation(line: 18, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!116 = !DILocation(line: 23, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!118 = !DILocation(line: 29, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!120 = !DILocation(line: 31, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!122 = !DILocation(line: 32, column: 0, scope: !123)
