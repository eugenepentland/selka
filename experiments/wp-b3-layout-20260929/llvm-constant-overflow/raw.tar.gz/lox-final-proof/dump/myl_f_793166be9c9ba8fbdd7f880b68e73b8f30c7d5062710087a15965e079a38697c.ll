target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_793166be9c9ba8fbdd7f880b68e73b8f30c7d5062710087a15965e079a38697c(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v118 = load i64, ptr %slot1, align 8
  %op119 = add i64 %v118, 32
  store i64 %op119, ptr %slot4, align 8
  %mem120 = alloca i8, i64 8, align 8
  %ptr121 = ptrtoint ptr %mem120 to i64
  store i64 %ptr121, ptr %slot5, align 8
  %mem122 = alloca i8, i64 8, align 8
  %ptr123 = ptrtoint ptr %mem122 to i64
  store i64 %ptr123, ptr %slot6, align 8
  %mem124 = alloca i8, i64 8, align 8
  %ptr125 = ptrtoint ptr %mem124 to i64
  store i64 %ptr125, ptr %slot7, align 8
  %mem126 = alloca i8, i64 8, align 8
  %ptr127 = ptrtoint ptr %mem126 to i64
  store i64 %ptr127, ptr %slot8, align 8
  %mem128 = alloca i8, i64 392, align 8
  %ptr129 = ptrtoint ptr %mem128 to i64
  store i64 %ptr129, ptr %slot9, align 8
  %mem130 = alloca i8, i64 8, align 8
  %ptr131 = ptrtoint ptr %mem130 to i64
  store i64 %ptr131, ptr %slot10, align 8
  %mem132 = alloca i8, i64 392, align 8
  %ptr133 = ptrtoint ptr %mem132 to i64
  store i64 %ptr133, ptr %slot11, align 8
  %mem134 = alloca i8, i64 8, align 8
  %ptr135 = ptrtoint ptr %mem134 to i64
  store i64 %ptr135, ptr %slot12, align 8
  %mem136 = alloca i8, i64 8, align 8
  %ptr137 = ptrtoint ptr %mem136 to i64
  store i64 %ptr137, ptr %slot13, align 8
  %mem138 = alloca i8, i64 8, align 8
  %ptr139 = ptrtoint ptr %mem138 to i64
  store i64 %ptr139, ptr %slot14, align 8
  %mem140 = alloca i8, i64 8, align 8
  %ptr141 = ptrtoint ptr %mem140 to i64
  store i64 %ptr141, ptr %slot15, align 8
  %mem142 = alloca i8, i64 8, align 8
  %ptr143 = ptrtoint ptr %mem142 to i64
  store i64 %ptr143, ptr %slot16, align 8
  %mem144 = alloca i8, i64 392, align 8
  %ptr145 = ptrtoint ptr %mem144 to i64
  store i64 %ptr145, ptr %slot17, align 8
  %mem146 = alloca i8, i64 392, align 8
  %ptr147 = ptrtoint ptr %mem146 to i64
  store i64 %ptr147, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem148 = alloca i8, i64 8, align 8
  %ptr149 = ptrtoint ptr %mem148 to i64
  store i64 %ptr149, ptr %slot19, align 8
  %v150 = load i64, ptr %slot1, align 8
  %op151 = add i64 %v150, 64
  store i64 %op151, ptr %slot20, align 8
  %v152 = load i64, ptr %slot20, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !4, !noalias !3
  store i64 %ld154, ptr %slot21, align 8
  %stack155 = call ptr @llvm.stacksave()
  %stackaddr156 = ptrtoint ptr %stack155 to i64
  %v157 = load i64, ptr %slot21, align 8
  %cmp158 = icmp ult i64 %stackaddr156, %v157
  %cv159 = zext i1 %cmp158 to i64
  store i64 %cv159, ptr %slot22, align 8
  %v160 = load i64, ptr %slot22, align 8
  %cond161 = icmp ne i64 %v160, 0
  br i1 %cond161, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v162 = load i64, ptr %slot1, align 8
  %p163 = inttoptr i64 %v162 to ptr
  call void @myl_qbe_fail_frame(ptr %p163) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v164 = load i64, ptr %slot2, align 8
  %v165 = load i64, ptr %slot12, align 8
  %p166 = inttoptr i64 %v165 to ptr
  store i64 %v164, ptr %p166, align 8, !alias.scope !3, !noalias !4
  %v167 = load i64, ptr %slot3, align 8
  %v168 = load i64, ptr %slot13, align 8
  %p169 = inttoptr i64 %v168 to ptr
  store i64 %v167, ptr %p169, align 8, !alias.scope !3, !noalias !4
  %v170 = load i64, ptr %slot1, align 8
  %p171 = inttoptr i64 %v170 to ptr
  %call172 = call ptr @myl_qbe_heap(ptr %p171) nomerge, !dbg !112
  %calladdr173 = ptrtoint ptr %call172 to i64
  store i64 %calladdr173, ptr %slot23, align 8
  %v174 = load i64, ptr %slot5, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i32 0, ptr %p175, align 4, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot6, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i32 0, ptr %p177, align 4, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot7, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i32 0, ptr %p179, align 4, !alias.scope !3, !noalias !4
  %v180 = load i64, ptr %slot8, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i32 0, ptr %p181, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v182 = load i64, ptr %slot12, align 8
  %p183 = inttoptr i64 %v182 to ptr
  %ld184 = load i64, ptr %p183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld184, ptr %slot24, align 8
  %v185 = load i64, ptr %slot24, align 8
  %v186 = load i64, ptr %slot14, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot12, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld190, ptr %slot25, align 8
  %v191 = load i64, ptr %slot25, align 8
  %v192 = load i64, ptr %slot17, align 8
  %p193 = inttoptr i64 %v191 to ptr
  %p194 = inttoptr i64 %v192 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p194, ptr %p193, i64 392, i1 false), !alias.scope !10000000
  %v195 = load i64, ptr %slot17, align 8
  %v196 = load i64, ptr %slot15, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 %v195, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot15, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot26, align 8
  %v201 = load i64, ptr %slot26, align 8
  %op202 = add i64 %v201, 248
  store i64 %op202, ptr %slot27, align 8
  %v203 = load i64, ptr %slot27, align 8
  %p204 = inttoptr i64 %v203 to ptr
  %ld205 = load i64, ptr %p204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld205, ptr %slot28, align 8
  %v206 = load i64, ptr %slot28, align 8
  %v207 = load i64, ptr %slot15, align 8
  %p208 = inttoptr i64 %v207 to ptr
  store i64 %v206, ptr %p208, align 8, !alias.scope !3, !noalias !4
  %v209 = load i64, ptr %slot5, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i32, ptr %p210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld211, ptr %slot29, align 8
  %v212 = load i32, ptr %slot29, align 8
  %cv213 = zext i32 %v212 to i64
  %cond214 = icmp ne i64 %cv213, 0
  br i1 %cond214, label %bb_rcslotdrop15, label %bb_rcslotdone15
bb_rcslotdrop15:
  %v215 = load i64, ptr %slot5, align 8
  %p216 = inttoptr i64 %v215 to ptr
  store i32 0, ptr %p216, align 4, !alias.scope !3, !noalias !4
  %v217 = load i64, ptr %slot9, align 8
  store i64 %v217, ptr %slot30, align 8
  %v218 = load i64, ptr %slot6, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %ld220 = load i32, ptr %p219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld220, ptr %slot31, align 8
  %v221 = load i32, ptr %slot31, align 8
  %op222 = and i32 %v221, 28
  store i32 %op222, ptr %slot32, align 8
  %v223 = load i32, ptr %slot32, align 8
  %cv224 = zext i32 %v223 to i64
  %cond225 = icmp ne i64 %cv224, 0
  br i1 %cond225, label %bb_rcslotrole15, label %bb_rcslotowner15
bb_rcslotrole15:
  %v226 = load i64, ptr %slot23, align 8
  store i64 %v226, ptr %slot33, align 8
  %v227 = load i64, ptr %slot33, align 8
  %v228 = load i64, ptr %slot30, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v227, i64 %v228) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotowner15:
  %v229 = load i64, ptr %slot23, align 8
  store i64 %v229, ptr %slot34, align 8
  %v230 = load i64, ptr %slot34, align 8
  %v231 = load i64, ptr %slot30, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v230, i64 %v231) nomerge, !dbg !114
  br label %bb_rcslotdone15
bb_rcslotdone15:
  %v232 = load i64, ptr %slot12, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot35, align 8
  %v235 = load i64, ptr %slot35, align 8
  %v236 = load i64, ptr %slot18, align 8
  %p237 = inttoptr i64 %v235 to ptr
  %p238 = inttoptr i64 %v236 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p238, ptr %p237, i64 392, i1 false), !alias.scope !10000000
  %v239 = load i64, ptr %slot18, align 8
  %v240 = load i64, ptr %slot16, align 8
  %p241 = inttoptr i64 %v240 to ptr
  store i64 %v239, ptr %p241, align 8, !alias.scope !3, !noalias !4
  %v242 = load i64, ptr %slot16, align 8
  %p243 = inttoptr i64 %v242 to ptr
  %ld244 = load i64, ptr %p243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld244, ptr %slot36, align 8
  %v245 = load i64, ptr %slot36, align 8
  %op246 = add i64 %v245, 328
  store i64 %op246, ptr %slot37, align 8
  %v247 = load i64, ptr %slot37, align 8
  %v248 = load i64, ptr %slot16, align 8
  %p249 = inttoptr i64 %v248 to ptr
  store i64 %v247, ptr %p249, align 8, !alias.scope !3, !noalias !4
  %v250 = load i64, ptr %slot15, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %ld252 = load i64, ptr %p251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld252, ptr %slot38, align 8
  %v253 = load i64, ptr %slot16, align 8
  %p254 = inttoptr i64 %v253 to ptr
  %ld255 = load i64, ptr %p254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld255, ptr %slot39, align 8
  %v256 = load i64, ptr %slot1, align 8
  %v257 = load i64, ptr %slot38, align 8
  %v258 = load i64, ptr %slot39, align 8
  %call259 = call i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64 %v256, i64 %v257, i64 %v258) nomerge, !dbg !116
  store i64 %call259, ptr %slot40, align 8
  %v260 = load i64, ptr %slot40, align 8
  %v261 = load i64, ptr %slot15, align 8
  %p262 = inttoptr i64 %v261 to ptr
  store i64 %v260, ptr %p262, align 8, !alias.scope !3, !noalias !4
  %v263 = load i64, ptr %slot15, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %ld265 = load i64, ptr %p264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld265, ptr %slot41, align 8
  %v266 = load i64, ptr %slot41, align 8
  %v267 = load i64, ptr %slot10, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i64 %v266, ptr %p268, align 8, !alias.scope !3, !noalias !4
  %v269 = load i64, ptr %slot10, align 8
  store i64 %v269, ptr %slot42, align 8
  %v270 = load i64, ptr %slot11, align 8
  store i64 %v270, ptr %slot43, align 8
  %v271 = load i64, ptr %slot42, align 8
  %v272 = load i64, ptr %slot43, align 8
  %p273 = inttoptr i64 %v271 to ptr
  %p274 = inttoptr i64 %v272 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p274, ptr %p273, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot8, align 8
  %p276 = inttoptr i64 %v275 to ptr
  store i32 2, ptr %p276, align 4, !alias.scope !3, !noalias !4
  %v277 = load i64, ptr %slot7, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i32 1, ptr %p278, align 4, !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot5, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i32, ptr %p280, align 4, !alias.scope !3, !noalias !4
  store i32 %ld281, ptr %slot44, align 8
  %v282 = load i32, ptr %slot44, align 8
  %cv283 = zext i32 %v282 to i64
  %cond284 = icmp ne i64 %cv283, 0
  br i1 %cond284, label %bb_rcslotdrop44, label %bb_rcslotdone44
bb_rcslotdrop44:
  %v285 = load i64, ptr %slot5, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i32 0, ptr %p286, align 4, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot9, align 8
  store i64 %v287, ptr %slot45, align 8
  %v288 = load i64, ptr %slot6, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i32, ptr %p289, align 4, !alias.scope !3, !noalias !4
  store i32 %ld290, ptr %slot46, align 8
  %v291 = load i32, ptr %slot46, align 8
  %op292 = and i32 %v291, 28
  store i32 %op292, ptr %slot47, align 8
  %v293 = load i32, ptr %slot47, align 8
  %cv294 = zext i32 %v293 to i64
  %cond295 = icmp ne i64 %cv294, 0
  br i1 %cond295, label %bb_rcslotrole44, label %bb_rcslotowner44
bb_rcslotrole44:
  %v296 = load i64, ptr %slot23, align 8
  store i64 %v296, ptr %slot48, align 8
  %v297 = load i64, ptr %slot45, align 8
  %p298 = inttoptr i64 %v297 to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld299, ptr %slot49, align 8
  %v300 = load i64, ptr %slot49, align 8
  %cmp301 = icmp ne i64 %v300, 0
  %cv302 = zext i1 %cmp301 to i32
  store i32 %cv302, ptr %slot50, align 8
  %v303 = load i32, ptr %slot50, align 8
  %cv304 = zext i32 %v303 to i64
  %cond305 = icmp ne i64 %cv304, 0
  br i1 %cond305, label %bb_rcgnn60, label %bb_rcgdone60
bb_rcgnn60:
  %v306 = load i64, ptr %slot49, align 8
  %op307 = sub i64 %v306, 16
  store i64 %op307, ptr %slot51, align 8
  %v308 = load i64, ptr %slot49, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %rgep310 = getelementptr i8, ptr %p309, i64 -16
  %ld311 = load i64, ptr %rgep310, align 8, !alias.scope !9, !noalias !10
  store i64 %ld311, ptr %slot52, align 8
  %v312 = load i64, ptr %slot52, align 8
  %op313 = and i64 %v312, 4611686018427387906
  store i64 %op313, ptr %slot53, align 8
  %v314 = load i64, ptr %slot53, align 8
  %cmp315 = icmp ne i64 %v314, 0
  %cv316 = zext i1 %cmp315 to i32
  store i32 %cv316, ptr %slot54, align 8
  %v317 = load i32, ptr %slot54, align 8
  %cv318 = zext i32 %v317 to i64
  %cond319 = icmp ne i64 %cv318, 0
  br i1 %cond319, label %bb_rcgclear60, label %bb_rcgcounted60
bb_rcgcounted60:
  %v320 = load i64, ptr %slot49, align 8
  %op321 = sub i64 %v320, 24
  store i64 %op321, ptr %slot55, align 8
  %v322 = load i64, ptr %slot49, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %rgep324 = getelementptr i8, ptr %p323, i64 -24
  %ld325 = load i64, ptr %rgep324, align 8, !alias.scope !9, !noalias !10
  store i64 %ld325, ptr %slot56, align 8
  %v326 = load i64, ptr %slot56, align 8
  %op327 = sub i64 %v326, 1
  store i64 %op327, ptr %slot57, align 8
  %v328 = load i64, ptr %slot57, align 8
  %cmp329 = icmp eq i64 %v328, 0
  %cv330 = zext i1 %cmp329 to i32
  store i32 %cv330, ptr %slot58, align 8
  %v331 = load i32, ptr %slot58, align 8
  %cv332 = zext i32 %v331 to i64
  %cond333 = icmp ne i64 %cv332, 0
  br i1 %cond333, label %bb_rcglast60, label %bb_rcgdec60
bb_rcglast60:
  %v334 = load i64, ptr %slot49, align 8
  %op335 = sub i64 %v334, 32
  store i64 %op335, ptr %slot59, align 8
  %v336 = load i64, ptr %slot49, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %rgep338 = getelementptr i8, ptr %p337, i64 -32
  %ld339 = load i64, ptr %rgep338, align 8, !alias.scope !9, !noalias !10
  store i64 %ld339, ptr %slot60, align 8
  %v340 = load i64, ptr %slot60, align 8
  %cmp341 = icmp ne i64 %v340, 0
  %cv342 = zext i1 %cmp341 to i32
  store i32 %cv342, ptr %slot61, align 8
  %v343 = load i32, ptr %slot61, align 8
  %cv344 = zext i32 %v343 to i64
  %cond345 = icmp ne i64 %cv344, 0
  br i1 %cond345, label %bb_rcgdec60, label %bb_rcgslow60
bb_rcgslow60:
  %v346 = load i64, ptr %slot48, align 8
  %v347 = load i64, ptr %slot45, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v346, i64 %v347) nomerge, !dbg !116
  br label %bb_rcgdone60
bb_rcgdec60:
  %v348 = load i64, ptr %slot57, align 8
  %v349 = load i64, ptr %slot49, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %rgep351 = getelementptr i8, ptr %p350, i64 -24
  store i64 %v348, ptr %rgep351, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear60
bb_rcgclear60:
  %v352 = load i64, ptr %slot45, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i64 0, ptr %p353, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone60
bb_rcgdone60:
  br label %bb_rcslotdone44
bb_rcslotowner44:
  %v354 = load i64, ptr %slot23, align 8
  store i64 %v354, ptr %slot62, align 8
  %v355 = load i64, ptr %slot45, align 8
  %p356 = inttoptr i64 %v355 to ptr
  %ld357 = load i64, ptr %p356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld357, ptr %slot63, align 8
  %v358 = load i64, ptr %slot63, align 8
  %cmp359 = icmp ne i64 %v358, 0
  %cv360 = zext i1 %cmp359 to i32
  store i32 %cv360, ptr %slot64, align 8
  %v361 = load i32, ptr %slot64, align 8
  %cv362 = zext i32 %v361 to i64
  %cond363 = icmp ne i64 %cv362, 0
  br i1 %cond363, label %bb_rcgnn75, label %bb_rcgdone75
bb_rcgnn75:
  %v364 = load i64, ptr %slot63, align 8
  %op365 = sub i64 %v364, 16
  store i64 %op365, ptr %slot65, align 8
  %v366 = load i64, ptr %slot63, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %rgep368 = getelementptr i8, ptr %p367, i64 -16
  %ld369 = load i64, ptr %rgep368, align 8, !alias.scope !9, !noalias !10
  store i64 %ld369, ptr %slot66, align 8
  %v370 = load i64, ptr %slot66, align 8
  %op371 = and i64 %v370, 4611686018427387906
  store i64 %op371, ptr %slot67, align 8
  %v372 = load i64, ptr %slot67, align 8
  %cmp373 = icmp ne i64 %v372, 0
  %cv374 = zext i1 %cmp373 to i32
  store i32 %cv374, ptr %slot68, align 8
  %v375 = load i32, ptr %slot68, align 8
  %cv376 = zext i32 %v375 to i64
  %cond377 = icmp ne i64 %cv376, 0
  br i1 %cond377, label %bb_rcgclear75, label %bb_rcgcounted75
bb_rcgcounted75:
  %v378 = load i64, ptr %slot63, align 8
  %op379 = sub i64 %v378, 32
  store i64 %op379, ptr %slot69, align 8
  %v380 = load i64, ptr %slot63, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %rgep382 = getelementptr i8, ptr %p381, i64 -32
  %ld383 = load i64, ptr %rgep382, align 8, !alias.scope !9, !noalias !10
  store i64 %ld383, ptr %slot70, align 8
  %v384 = load i64, ptr %slot70, align 8
  %op385 = sub i64 %v384, 1
  store i64 %op385, ptr %slot71, align 8
  %v386 = load i64, ptr %slot71, align 8
  %cmp387 = icmp eq i64 %v386, 0
  %cv388 = zext i1 %cmp387 to i32
  store i32 %cv388, ptr %slot72, align 8
  %v389 = load i32, ptr %slot72, align 8
  %cv390 = zext i32 %v389 to i64
  %cond391 = icmp ne i64 %cv390, 0
  br i1 %cond391, label %bb_rcglast75, label %bb_rcgdec75
bb_rcglast75:
  %v392 = load i64, ptr %slot63, align 8
  %op393 = sub i64 %v392, 24
  store i64 %op393, ptr %slot73, align 8
  %v394 = load i64, ptr %slot63, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %rgep396 = getelementptr i8, ptr %p395, i64 -24
  %ld397 = load i64, ptr %rgep396, align 8, !alias.scope !9, !noalias !10
  store i64 %ld397, ptr %slot74, align 8
  %v398 = load i64, ptr %slot74, align 8
  %cmp399 = icmp ne i64 %v398, 0
  %cv400 = zext i1 %cmp399 to i32
  store i32 %cv400, ptr %slot75, align 8
  %v401 = load i32, ptr %slot75, align 8
  %cv402 = zext i32 %v401 to i64
  %cond403 = icmp ne i64 %cv402, 0
  br i1 %cond403, label %bb_rcgdec75, label %bb_rcgslow75
bb_rcgslow75:
  %v404 = load i64, ptr %slot62, align 8
  %v405 = load i64, ptr %slot45, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v404, i64 %v405) nomerge, !dbg !116
  br label %bb_rcgdone75
bb_rcgdec75:
  %v406 = load i64, ptr %slot71, align 8
  %v407 = load i64, ptr %slot63, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %rgep409 = getelementptr i8, ptr %p408, i64 -32
  store i64 %v406, ptr %rgep409, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear75
bb_rcgclear75:
  %v410 = load i64, ptr %slot45, align 8
  %p411 = inttoptr i64 %v410 to ptr
  store i64 0, ptr %p411, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone75
bb_rcgdone75:
  br label %bb_rcslotdone44
bb_rcslotdone44:
  %v412 = load i64, ptr %slot9, align 8
  store i64 %v412, ptr %slot76, align 8
  %v413 = load i64, ptr %slot11, align 8
  store i64 %v413, ptr %slot77, align 8
  %v414 = load i64, ptr %slot77, align 8
  %v415 = load i64, ptr %slot76, align 8
  %p416 = inttoptr i64 %v414 to ptr
  %p417 = inttoptr i64 %v415 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p417, ptr %p416, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v418 = load i64, ptr %slot6, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i32 2, ptr %p419, align 4, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot8, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %ld422 = load i32, ptr %p421, align 4, !alias.scope !3, !noalias !4
  store i32 %ld422, ptr %slot78, align 8
  %v423 = load i32, ptr %slot78, align 8
  %v424 = load i64, ptr %slot6, align 8
  %p425 = inttoptr i64 %v424 to ptr
  store i32 %v423, ptr %p425, align 4, !alias.scope !3, !noalias !4
  %v426 = load i64, ptr %slot7, align 8
  %p427 = inttoptr i64 %v426 to ptr
  store i32 0, ptr %p427, align 4, !alias.scope !3, !noalias !4
  %v428 = load i64, ptr %slot5, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i32 1, ptr %p429, align 4, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot76, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot79, align 8
  %v433 = load i64, ptr %slot79, align 8
  %v434 = load i64, ptr %slot15, align 8
  %p435 = inttoptr i64 %v434 to ptr
  store i64 %v433, ptr %p435, align 8, !alias.scope !3, !noalias !4
  %v436 = load i64, ptr %slot13, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %ld438 = load i64, ptr %p437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld438, ptr %slot80, align 8
  %v439 = load i64, ptr %slot80, align 8
  %v440 = load i64, ptr %slot16, align 8
  %p441 = inttoptr i64 %v440 to ptr
  store i64 %v439, ptr %p441, align 8, !alias.scope !3, !noalias !4
  %v442 = load i64, ptr %slot14, align 8
  %p443 = inttoptr i64 %v442 to ptr
  %ld444 = load i64, ptr %p443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld444, ptr %slot81, align 8
  %v445 = load i64, ptr %slot15, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %ld447 = load i64, ptr %p446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld447, ptr %slot82, align 8
  %v448 = load i64, ptr %slot16, align 8
  %p449 = inttoptr i64 %v448 to ptr
  %ld450 = load i64, ptr %p449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld450, ptr %slot83, align 8
  %v451 = load i64, ptr %slot1, align 8
  %v452 = load i64, ptr %slot81, align 8
  %v453 = load i64, ptr %slot82, align 8
  %v454 = load i64, ptr %slot83, align 8
  %call455 = call i64 @myl_f_260d35b32c6c4c67030ea0fb2f7c297a4f6cac38fd40cde07c0a68a45af8d701(i64 %v451, i64 %v452, i64 %v453, i64 %v454) nomerge, !dbg !118
  store i64 %call455, ptr %slot84, align 8
  %v456 = load i64, ptr %slot84, align 8
  %v457 = load i64, ptr %slot14, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i64 %v456, ptr %p458, align 8, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot5, align 8
  %p460 = inttoptr i64 %v459 to ptr
  %ld461 = load i32, ptr %p460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld461, ptr %slot85, align 8
  %v462 = load i32, ptr %slot85, align 8
  %cv463 = zext i32 %v462 to i64
  %cond464 = icmp ne i64 %cv463, 0
  br i1 %cond464, label %bb_rcslotdrop113, label %bb_rcslotdone113
bb_rcslotdrop113:
  %v465 = load i64, ptr %slot5, align 8
  %p466 = inttoptr i64 %v465 to ptr
  store i32 0, ptr %p466, align 4, !alias.scope !3, !noalias !4
  %v467 = load i64, ptr %slot9, align 8
  store i64 %v467, ptr %slot86, align 8
  %v468 = load i64, ptr %slot6, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %ld470 = load i32, ptr %p469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld470, ptr %slot87, align 8
  %v471 = load i32, ptr %slot87, align 8
  %op472 = and i32 %v471, 28
  store i32 %op472, ptr %slot88, align 8
  %v473 = load i32, ptr %slot88, align 8
  %cv474 = zext i32 %v473 to i64
  %cond475 = icmp ne i64 %cv474, 0
  br i1 %cond475, label %bb_rcslotrole113, label %bb_rcslotowner113
bb_rcslotrole113:
  %v476 = load i64, ptr %slot23, align 8
  store i64 %v476, ptr %slot89, align 8
  %v477 = load i64, ptr %slot86, align 8
  %p478 = inttoptr i64 %v477 to ptr
  %ld479 = load i64, ptr %p478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld479, ptr %slot90, align 8
  %v480 = load i64, ptr %slot90, align 8
  %cmp481 = icmp ne i64 %v480, 0
  %cv482 = zext i1 %cmp481 to i32
  store i32 %cv482, ptr %slot91, align 8
  %v483 = load i32, ptr %slot91, align 8
  %cv484 = zext i32 %v483 to i64
  %cond485 = icmp ne i64 %cv484, 0
  br i1 %cond485, label %bb_rcgnn129, label %bb_rcgdone129
bb_rcgnn129:
  %v486 = load i64, ptr %slot90, align 8
  %op487 = sub i64 %v486, 16
  store i64 %op487, ptr %slot92, align 8
  %v488 = load i64, ptr %slot90, align 8
  %p489 = inttoptr i64 %v488 to ptr
  %rgep490 = getelementptr i8, ptr %p489, i64 -16
  %ld491 = load i64, ptr %rgep490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld491, ptr %slot93, align 8
  %v492 = load i64, ptr %slot93, align 8
  %op493 = and i64 %v492, 4611686018427387906
  store i64 %op493, ptr %slot94, align 8
  %v494 = load i64, ptr %slot94, align 8
  %cmp495 = icmp ne i64 %v494, 0
  %cv496 = zext i1 %cmp495 to i32
  store i32 %cv496, ptr %slot95, align 8
  %v497 = load i32, ptr %slot95, align 8
  %cv498 = zext i32 %v497 to i64
  %cond499 = icmp ne i64 %cv498, 0
  br i1 %cond499, label %bb_rcgclear129, label %bb_rcgcounted129
bb_rcgcounted129:
  %v500 = load i64, ptr %slot90, align 8
  %op501 = sub i64 %v500, 24
  store i64 %op501, ptr %slot96, align 8
  %v502 = load i64, ptr %slot90, align 8
  %p503 = inttoptr i64 %v502 to ptr
  %rgep504 = getelementptr i8, ptr %p503, i64 -24
  %ld505 = load i64, ptr %rgep504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld505, ptr %slot97, align 8
  %v506 = load i64, ptr %slot97, align 8
  %op507 = sub i64 %v506, 1
  store i64 %op507, ptr %slot98, align 8
  %v508 = load i64, ptr %slot98, align 8
  %cmp509 = icmp eq i64 %v508, 0
  %cv510 = zext i1 %cmp509 to i32
  store i32 %cv510, ptr %slot99, align 8
  %v511 = load i32, ptr %slot99, align 8
  %cv512 = zext i32 %v511 to i64
  %cond513 = icmp ne i64 %cv512, 0
  br i1 %cond513, label %bb_rcglast129, label %bb_rcgdec129
bb_rcglast129:
  %v514 = load i64, ptr %slot90, align 8
  %op515 = sub i64 %v514, 32
  store i64 %op515, ptr %slot100, align 8
  %v516 = load i64, ptr %slot90, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %rgep518 = getelementptr i8, ptr %p517, i64 -32
  %ld519 = load i64, ptr %rgep518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld519, ptr %slot101, align 8
  %v520 = load i64, ptr %slot101, align 8
  %cmp521 = icmp ne i64 %v520, 0
  %cv522 = zext i1 %cmp521 to i32
  store i32 %cv522, ptr %slot102, align 8
  %v523 = load i32, ptr %slot102, align 8
  %cv524 = zext i32 %v523 to i64
  %cond525 = icmp ne i64 %cv524, 0
  br i1 %cond525, label %bb_rcgdec129, label %bb_rcgslow129
bb_rcgslow129:
  %v526 = load i64, ptr %slot89, align 8
  %v527 = load i64, ptr %slot86, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v526, i64 %v527) nomerge, !dbg !118
  br label %bb_rcgdone129
bb_rcgdec129:
  %v528 = load i64, ptr %slot98, align 8
  %v529 = load i64, ptr %slot90, align 8
  %p530 = inttoptr i64 %v529 to ptr
  %rgep531 = getelementptr i8, ptr %p530, i64 -24
  store i64 %v528, ptr %rgep531, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear129
bb_rcgclear129:
  %v532 = load i64, ptr %slot86, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i64 0, ptr %p533, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone129
bb_rcgdone129:
  br label %bb_rcslotdone113
bb_rcslotowner113:
  %v534 = load i64, ptr %slot23, align 8
  store i64 %v534, ptr %slot103, align 8
  %v535 = load i64, ptr %slot86, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i64, ptr %p536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld537, ptr %slot104, align 8
  %v538 = load i64, ptr %slot104, align 8
  %cmp539 = icmp ne i64 %v538, 0
  %cv540 = zext i1 %cmp539 to i32
  store i32 %cv540, ptr %slot105, align 8
  %v541 = load i32, ptr %slot105, align 8
  %cv542 = zext i32 %v541 to i64
  %cond543 = icmp ne i64 %cv542, 0
  br i1 %cond543, label %bb_rcgnn144, label %bb_rcgdone144
bb_rcgnn144:
  %v544 = load i64, ptr %slot104, align 8
  %op545 = sub i64 %v544, 16
  store i64 %op545, ptr %slot106, align 8
  %v546 = load i64, ptr %slot104, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %rgep548 = getelementptr i8, ptr %p547, i64 -16
  %ld549 = load i64, ptr %rgep548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld549, ptr %slot107, align 8
  %v550 = load i64, ptr %slot107, align 8
  %op551 = and i64 %v550, 4611686018427387906
  store i64 %op551, ptr %slot108, align 8
  %v552 = load i64, ptr %slot108, align 8
  %cmp553 = icmp ne i64 %v552, 0
  %cv554 = zext i1 %cmp553 to i32
  store i32 %cv554, ptr %slot109, align 8
  %v555 = load i32, ptr %slot109, align 8
  %cv556 = zext i32 %v555 to i64
  %cond557 = icmp ne i64 %cv556, 0
  br i1 %cond557, label %bb_rcgclear144, label %bb_rcgcounted144
bb_rcgcounted144:
  %v558 = load i64, ptr %slot104, align 8
  %op559 = sub i64 %v558, 32
  store i64 %op559, ptr %slot110, align 8
  %v560 = load i64, ptr %slot104, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %rgep562 = getelementptr i8, ptr %p561, i64 -32
  %ld563 = load i64, ptr %rgep562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld563, ptr %slot111, align 8
  %v564 = load i64, ptr %slot111, align 8
  %op565 = sub i64 %v564, 1
  store i64 %op565, ptr %slot112, align 8
  %v566 = load i64, ptr %slot112, align 8
  %cmp567 = icmp eq i64 %v566, 0
  %cv568 = zext i1 %cmp567 to i32
  store i32 %cv568, ptr %slot113, align 8
  %v569 = load i32, ptr %slot113, align 8
  %cv570 = zext i32 %v569 to i64
  %cond571 = icmp ne i64 %cv570, 0
  br i1 %cond571, label %bb_rcglast144, label %bb_rcgdec144
bb_rcglast144:
  %v572 = load i64, ptr %slot104, align 8
  %op573 = sub i64 %v572, 24
  store i64 %op573, ptr %slot114, align 8
  %v574 = load i64, ptr %slot104, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %rgep576 = getelementptr i8, ptr %p575, i64 -24
  %ld577 = load i64, ptr %rgep576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld577, ptr %slot115, align 8
  %v578 = load i64, ptr %slot115, align 8
  %cmp579 = icmp ne i64 %v578, 0
  %cv580 = zext i1 %cmp579 to i32
  store i32 %cv580, ptr %slot116, align 8
  %v581 = load i32, ptr %slot116, align 8
  %cv582 = zext i32 %v581 to i64
  %cond583 = icmp ne i64 %cv582, 0
  br i1 %cond583, label %bb_rcgdec144, label %bb_rcgslow144
bb_rcgslow144:
  %v584 = load i64, ptr %slot103, align 8
  %v585 = load i64, ptr %slot86, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v584, i64 %v585) nomerge, !dbg !118
  br label %bb_rcgdone144
bb_rcgdec144:
  %v586 = load i64, ptr %slot112, align 8
  %v587 = load i64, ptr %slot104, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %rgep589 = getelementptr i8, ptr %p588, i64 -32
  store i64 %v586, ptr %rgep589, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear144
bb_rcgclear144:
  %v590 = load i64, ptr %slot86, align 8
  %p591 = inttoptr i64 %v590 to ptr
  store i64 0, ptr %p591, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone144
bb_rcgdone144:
  br label %bb_rcslotdone113
bb_rcslotdone113:
  %v592 = load i64, ptr %slot14, align 8
  %p593 = inttoptr i64 %v592 to ptr
  store i64 0, ptr %p593, align 8, !alias.scope !3, !noalias !4
  %v594 = load i64, ptr %slot14, align 8
  %p595 = inttoptr i64 %v594 to ptr
  %ld596 = load i64, ptr %p595, align 8, !alias.scope !3, !noalias !4
  store i64 %ld596, ptr %slot117, align 8
  %v597 = load i64, ptr %slot117, align 8
  ret i64 %v597
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_260d35b32c6c4c67030ea0fb2f7c297a4f6cac38fd40cde07c0a68a45af8d701(i64, i64, i64, i64)
declare i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_793166be9c9ba8fbdd7f880b68e73b8f30c7d5062710087a15965e079a38697c", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_793166be9c9ba8fbdd7f880b68e73b8f30c7d5062710087a15965e079a38697c", linkageName: "myl_f_793166be9c9ba8fbdd7f880b68e73b8f30c7d5062710087a15965e079a38697c", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3257098501844048306, i64 0, !"myl_f_793166be9c9ba8fbdd7f880b68e73b8f30c7d5062710087a15965e079a38697c"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
