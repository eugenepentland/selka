target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_da29e2319f1ca7211fbec2590e8b68131c88b074f9f0bad6b5347509ebaee07c(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v526 = load i64, ptr %slot1, align 8
  %op527 = add i64 %v526, 32
  store i64 %op527, ptr %slot3, align 8
  %mem528 = alloca i8, i64 8, align 8
  %ptr529 = ptrtoint ptr %mem528 to i64
  store i64 %ptr529, ptr %slot4, align 8
  %mem530 = alloca i8, i64 8, align 8
  %ptr531 = ptrtoint ptr %mem530 to i64
  store i64 %ptr531, ptr %slot5, align 8
  %mem532 = alloca i8, i64 8, align 8
  %ptr533 = ptrtoint ptr %mem532 to i64
  store i64 %ptr533, ptr %slot6, align 8
  %mem534 = alloca i8, i64 8, align 8
  %ptr535 = ptrtoint ptr %mem534 to i64
  store i64 %ptr535, ptr %slot7, align 8
  %mem536 = alloca i8, i64 8, align 8
  %ptr537 = ptrtoint ptr %mem536 to i64
  store i64 %ptr537, ptr %slot8, align 8
  %mem538 = alloca i8, i64 8, align 8
  %ptr539 = ptrtoint ptr %mem538 to i64
  store i64 %ptr539, ptr %slot9, align 8
  %mem540 = alloca i8, i64 8, align 8
  %ptr541 = ptrtoint ptr %mem540 to i64
  store i64 %ptr541, ptr %slot10, align 8
  %mem542 = alloca i8, i64 8, align 8
  %ptr543 = ptrtoint ptr %mem542 to i64
  store i64 %ptr543, ptr %slot11, align 8
  %mem544 = alloca i8, i64 8, align 8
  %ptr545 = ptrtoint ptr %mem544 to i64
  store i64 %ptr545, ptr %slot12, align 8
  %mem546 = alloca i8, i64 8, align 8
  %ptr547 = ptrtoint ptr %mem546 to i64
  store i64 %ptr547, ptr %slot13, align 8
  %mem548 = alloca i8, i64 8, align 8
  %ptr549 = ptrtoint ptr %mem548 to i64
  store i64 %ptr549, ptr %slot14, align 8
  %mem550 = alloca i8, i64 8, align 8
  %ptr551 = ptrtoint ptr %mem550 to i64
  store i64 %ptr551, ptr %slot15, align 8
  %mem552 = alloca i8, i64 8, align 8
  %ptr553 = ptrtoint ptr %mem552 to i64
  store i64 %ptr553, ptr %slot16, align 8
  %mem554 = alloca i8, i64 392, align 8
  %ptr555 = ptrtoint ptr %mem554 to i64
  store i64 %ptr555, ptr %slot17, align 8
  %mem556 = alloca i8, i64 8, align 8
  %ptr557 = ptrtoint ptr %mem556 to i64
  store i64 %ptr557, ptr %slot18, align 8
  %mem558 = alloca i8, i64 392, align 8
  %ptr559 = ptrtoint ptr %mem558 to i64
  store i64 %ptr559, ptr %slot19, align 8
  %mem560 = alloca i8, i64 8, align 8
  %ptr561 = ptrtoint ptr %mem560 to i64
  store i64 %ptr561, ptr %slot20, align 8
  %mem562 = alloca i8, i64 40, align 8
  %ptr563 = ptrtoint ptr %mem562 to i64
  store i64 %ptr563, ptr %slot21, align 8
  %mem564 = alloca i8, i64 8, align 8
  %ptr565 = ptrtoint ptr %mem564 to i64
  store i64 %ptr565, ptr %slot22, align 8
  %mem566 = alloca i8, i64 8, align 8
  %ptr567 = ptrtoint ptr %mem566 to i64
  store i64 %ptr567, ptr %slot23, align 8
  %mem568 = alloca i8, i64 208, align 8
  %ptr569 = ptrtoint ptr %mem568 to i64
  store i64 %ptr569, ptr %slot24, align 8
  %mem570 = alloca i8, i64 8, align 8
  %ptr571 = ptrtoint ptr %mem570 to i64
  store i64 %ptr571, ptr %slot25, align 8
  %mem572 = alloca i8, i64 8, align 8
  %ptr573 = ptrtoint ptr %mem572 to i64
  store i64 %ptr573, ptr %slot26, align 8
  %mem574 = alloca i8, i64 8, align 8
  %ptr575 = ptrtoint ptr %mem574 to i64
  store i64 %ptr575, ptr %slot27, align 8
  %mem576 = alloca i8, i64 8, align 8
  %ptr577 = ptrtoint ptr %mem576 to i64
  store i64 %ptr577, ptr %slot28, align 8
  %mem578 = alloca i8, i64 392, align 8
  %ptr579 = ptrtoint ptr %mem578 to i64
  store i64 %ptr579, ptr %slot29, align 8
  %mem580 = alloca i8, i64 392, align 8
  %ptr581 = ptrtoint ptr %mem580 to i64
  store i64 %ptr581, ptr %slot30, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem582 = alloca i8, i64 8, align 8
  %ptr583 = ptrtoint ptr %mem582 to i64
  store i64 %ptr583, ptr %slot31, align 8
  %v584 = load i64, ptr %slot1, align 8
  %op585 = add i64 %v584, 64
  store i64 %op585, ptr %slot32, align 8
  %v586 = load i64, ptr %slot32, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %ld588 = load i64, ptr %p587, align 8, !alias.scope !4, !noalias !3
  store i64 %ld588, ptr %slot33, align 8
  %stack589 = call ptr @llvm.stacksave()
  %stackaddr590 = ptrtoint ptr %stack589 to i64
  %v591 = load i64, ptr %slot33, align 8
  %cmp592 = icmp ult i64 %stackaddr590, %v591
  %cv593 = zext i1 %cmp592 to i64
  store i64 %cv593, ptr %slot34, align 8
  %v594 = load i64, ptr %slot34, align 8
  %cond595 = icmp ne i64 %v594, 0
  br i1 %cond595, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v596 = load i64, ptr %slot1, align 8
  %p597 = inttoptr i64 %v596 to ptr
  call void @myl_qbe_fail_frame(ptr %p597) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v598 = load i64, ptr %slot22, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i64 0, ptr %p599, align 8, !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot23, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i64 0, ptr %p601, align 8, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot2, align 8
  %v603 = load i64, ptr %slot20, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i64 %v602, ptr %p604, align 8, !alias.scope !3, !noalias !4
  %v605 = load i64, ptr %slot1, align 8
  %p606 = inttoptr i64 %v605 to ptr
  %call607 = call ptr @myl_qbe_heap(ptr %p606) nomerge, !dbg !112
  %calladdr608 = ptrtoint ptr %call607 to i64
  store i64 %calladdr608, ptr %slot35, align 8
  %v609 = load i64, ptr %slot1, align 8
  %p610 = inttoptr i64 %v609 to ptr
  %call611 = call i64 @myl_qbe_region_mark(ptr %p610) nomerge, !dbg !112
  store i64 %call611, ptr %slot36, align 8
  %v612 = load i64, ptr %slot4, align 8
  %p613 = inttoptr i64 %v612 to ptr
  store i32 0, ptr %p613, align 4, !alias.scope !3, !noalias !4
  %v614 = load i64, ptr %slot5, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i32 0, ptr %p615, align 4, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot6, align 8
  %p617 = inttoptr i64 %v616 to ptr
  store i32 0, ptr %p617, align 4, !alias.scope !3, !noalias !4
  %v618 = load i64, ptr %slot7, align 8
  %p619 = inttoptr i64 %v618 to ptr
  store i32 0, ptr %p619, align 4, !alias.scope !3, !noalias !4
  %v620 = load i64, ptr %slot8, align 8
  %p621 = inttoptr i64 %v620 to ptr
  store i32 0, ptr %p621, align 4, !alias.scope !3, !noalias !4
  %v622 = load i64, ptr %slot9, align 8
  %p623 = inttoptr i64 %v622 to ptr
  store i32 0, ptr %p623, align 4, !alias.scope !3, !noalias !4
  %v624 = load i64, ptr %slot10, align 8
  %p625 = inttoptr i64 %v624 to ptr
  store i32 0, ptr %p625, align 4, !alias.scope !3, !noalias !4
  %v626 = load i64, ptr %slot11, align 8
  %p627 = inttoptr i64 %v626 to ptr
  store i32 0, ptr %p627, align 4, !alias.scope !3, !noalias !4
  %v628 = load i64, ptr %slot12, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i32 0, ptr %p629, align 4, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot13, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i32 0, ptr %p631, align 4, !alias.scope !3, !noalias !4
  %v632 = load i64, ptr %slot14, align 8
  %p633 = inttoptr i64 %v632 to ptr
  store i32 0, ptr %p633, align 4, !alias.scope !3, !noalias !4
  %v634 = load i64, ptr %slot15, align 8
  %p635 = inttoptr i64 %v634 to ptr
  store i32 0, ptr %p635, align 4, !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot16, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i32 0, ptr %p637, align 4, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot5, align 8
  %p639 = inttoptr i64 %v638 to ptr
  store i32 2, ptr %p639, align 4, !alias.scope !3, !noalias !4
  %v640 = load i64, ptr %slot7, align 8
  %p641 = inttoptr i64 %v640 to ptr
  store i32 2, ptr %p641, align 4, !alias.scope !3, !noalias !4
  %v642 = load i64, ptr %slot9, align 8
  %p643 = inttoptr i64 %v642 to ptr
  store i32 2, ptr %p643, align 4, !alias.scope !3, !noalias !4
  %v644 = load i64, ptr %slot11, align 8
  %p645 = inttoptr i64 %v644 to ptr
  store i32 2, ptr %p645, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v646 = load i64, ptr %slot20, align 8
  %p647 = inttoptr i64 %v646 to ptr
  %ld648 = load i64, ptr %p647, align 8, !alias.scope !3, !noalias !4
  store i64 %ld648, ptr %slot37, align 8
  %v649 = load i64, ptr %slot37, align 8
  %v650 = load i64, ptr %slot26, align 8
  %p651 = inttoptr i64 %v650 to ptr
  store i64 %v649, ptr %p651, align 8, !alias.scope !3, !noalias !4
  %v652 = load i64, ptr %slot26, align 8
  %p653 = inttoptr i64 %v652 to ptr
  %ld654 = load i64, ptr %p653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld654, ptr %slot38, align 8
  %v655 = load i64, ptr %slot38, align 8
  %op656 = add i64 %v655, 328
  store i64 %op656, ptr %slot39, align 8
  %v657 = load i64, ptr %slot39, align 8
  %v658 = load i64, ptr %slot26, align 8
  %p659 = inttoptr i64 %v658 to ptr
  store i64 %v657, ptr %p659, align 8, !alias.scope !3, !noalias !4
  %v660 = load i64, ptr %slot12, align 8
  %p661 = inttoptr i64 %v660 to ptr
  %ld662 = load i32, ptr %p661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld662, ptr %slot40, align 8
  %v663 = load i32, ptr %slot40, align 8
  %cv664 = zext i32 %v663 to i64
  %cond665 = icmp ne i64 %cv664, 0
  br i1 %cond665, label %bb_rcslotdrop19, label %bb_rcslotdone19
bb_rcslotdrop19:
  %v666 = load i64, ptr %slot12, align 8
  %p667 = inttoptr i64 %v666 to ptr
  store i32 0, ptr %p667, align 4, !alias.scope !3, !noalias !4
  %v668 = load i64, ptr %slot17, align 8
  store i64 %v668, ptr %slot41, align 8
  %v669 = load i64, ptr %slot13, align 8
  %p670 = inttoptr i64 %v669 to ptr
  %ld671 = load i32, ptr %p670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld671, ptr %slot42, align 8
  %v672 = load i32, ptr %slot42, align 8
  %op673 = and i32 %v672, 28
  store i32 %op673, ptr %slot43, align 8
  %v674 = load i32, ptr %slot43, align 8
  %cv675 = zext i32 %v674 to i64
  %cond676 = icmp ne i64 %cv675, 0
  br i1 %cond676, label %bb_rcslotrole19, label %bb_rcslotowner19
bb_rcslotrole19:
  %v677 = load i64, ptr %slot35, align 8
  store i64 %v677, ptr %slot44, align 8
  %v678 = load i64, ptr %slot44, align 8
  %v679 = load i64, ptr %slot41, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v678, i64 %v679) nomerge, !dbg !114
  br label %bb_rcslotdone19
bb_rcslotowner19:
  %v680 = load i64, ptr %slot35, align 8
  store i64 %v680, ptr %slot45, align 8
  %v681 = load i64, ptr %slot45, align 8
  %v682 = load i64, ptr %slot41, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v681, i64 %v682) nomerge, !dbg !114
  br label %bb_rcslotdone19
bb_rcslotdone19:
  %v683 = load i64, ptr %slot26, align 8
  %p684 = inttoptr i64 %v683 to ptr
  %ld685 = load i64, ptr %p684, align 8, !alias.scope !3, !noalias !4
  store i64 %ld685, ptr %slot46, align 8
  %v686 = load i64, ptr %slot12, align 8
  %p687 = inttoptr i64 %v686 to ptr
  %ld688 = load i32, ptr %p687, align 4, !alias.scope !3, !noalias !4
  store i32 %ld688, ptr %slot47, align 8
  %v689 = load i64, ptr %slot13, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %ld691 = load i32, ptr %p690, align 4, !alias.scope !3, !noalias !4
  store i32 %ld691, ptr %slot48, align 8
  %v692 = load i32, ptr %slot48, align 8
  %op693 = and i32 %v692, 24
  store i32 %op693, ptr %slot48, align 8
  %v694 = load i32, ptr %slot48, align 8
  %cmp695 = icmp eq i32 %v694, 0
  %cv696 = zext i1 %cmp695 to i32
  store i32 %cv696, ptr %slot49, align 8
  %v697 = load i32, ptr %slot47, align 8
  %v698 = load i32, ptr %slot49, align 8
  %op699 = and i32 %v697, %v698
  store i32 %op699, ptr %slot50, align 8
  %v700 = load i32, ptr %slot50, align 8
  %cv701 = zext i32 %v700 to i64
  %cond702 = icmp ne i64 %cv701, 0
  br i1 %cond702, label %bb_rctake27, label %bb_rccopy27
bb_rctake27:
  %v703 = load i64, ptr %slot19, align 8
  store i64 %v703, ptr %slot51, align 8
  %v704 = load i64, ptr %slot36, align 8
  store i64 %v704, ptr %slot52, align 8
  %v705 = load i64, ptr %slot35, align 8
  %v706 = load i64, ptr %slot51, align 8
  %v707 = load i64, ptr %slot46, align 8
  %v708 = load i64, ptr %slot52, align 8
  %cv709 = trunc i64 %v708 to i32
  %call710 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v705, i64 %v706, i64 %v707, i32 %cv709) nomerge, !dbg !116
  store i32 %call710, ptr %slot53, align 8
  %v711 = load i32, ptr %slot53, align 8
  %cv712 = zext i32 %v711 to i64
  %cond713 = icmp ne i64 %cv712, 0
  br i1 %cond713, label %bb_rcsuccess37, label %bb_rcfailure37
bb_rcfailure37:
  %v714 = load i64, ptr %slot35, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %call716 = call i32 @myl_rc_take_failure(ptr %p715) nomerge, !dbg !116
  store i32 %call716, ptr %slot54, align 8
  %v717 = load i64, ptr %slot1, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %v719 = load i32, ptr %slot54, align 8
  %call720 = call i32 @myl_qbe_rc_status(ptr %p718, i32 %v719) nomerge, !dbg !116
  store i32 %call720, ptr %slot55, align 8
  br label %bb_failure
bb_rcsuccess37:
  %v721 = load i64, ptr %slot12, align 8
  %p722 = inttoptr i64 %v721 to ptr
  store i32 0, ptr %p722, align 4, !alias.scope !3, !noalias !4
  %v723 = load i64, ptr %slot15, align 8
  %p724 = inttoptr i64 %v723 to ptr
  store i32 2, ptr %p724, align 4, !alias.scope !3, !noalias !4
  %v725 = load i64, ptr %slot14, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i32 1, ptr %p726, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared27
bb_rccopy27:
  %v727 = load i64, ptr %slot19, align 8
  store i64 %v727, ptr %slot56, align 8
  %v728 = load i64, ptr %slot36, align 8
  store i64 %v728, ptr %slot57, align 8
  %v729 = load i64, ptr %slot35, align 8
  %v730 = load i64, ptr %slot56, align 8
  %v731 = load i64, ptr %slot46, align 8
  %v732 = load i64, ptr %slot57, align 8
  %cv733 = trunc i64 %v732 to i32
  %call734 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v729, i64 %v730, i64 %v731, i32 %cv733) nomerge, !dbg !116
  store i32 %call734, ptr %slot58, align 8
  %v735 = load i32, ptr %slot58, align 8
  %cv736 = zext i32 %v735 to i64
  %cond737 = icmp ne i64 %cv736, 0
  br i1 %cond737, label %bb_rcsuccess46, label %bb_rcfailure46
bb_rcfailure46:
  %v738 = load i64, ptr %slot35, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %call740 = call i32 @myl_rc_take_failure(ptr %p739) nomerge, !dbg !116
  store i32 %call740, ptr %slot59, align 8
  %v741 = load i64, ptr %slot1, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %v743 = load i32, ptr %slot59, align 8
  %call744 = call i32 @myl_qbe_rc_status(ptr %p742, i32 %v743) nomerge, !dbg !116
  store i32 %call744, ptr %slot60, align 8
  br label %bb_failure
bb_rcsuccess46:
  %v745 = load i64, ptr %slot15, align 8
  %p746 = inttoptr i64 %v745 to ptr
  store i32 2, ptr %p746, align 4, !alias.scope !3, !noalias !4
  %v747 = load i64, ptr %slot14, align 8
  %p748 = inttoptr i64 %v747 to ptr
  store i32 1, ptr %p748, align 4, !alias.scope !3, !noalias !4
  %v749 = load i64, ptr %slot12, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %ld751 = load i32, ptr %p750, align 4, !alias.scope !3, !noalias !4
  store i32 %ld751, ptr %slot61, align 8
  %v752 = load i32, ptr %slot61, align 8
  %cv753 = zext i32 %v752 to i64
  %cond754 = icmp ne i64 %cv753, 0
  br i1 %cond754, label %bb_rcslotdrop53, label %bb_rcslotdone53
bb_rcslotdrop53:
  %v755 = load i64, ptr %slot12, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i32 0, ptr %p756, align 4, !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot17, align 8
  store i64 %v757, ptr %slot62, align 8
  %v758 = load i64, ptr %slot13, align 8
  %p759 = inttoptr i64 %v758 to ptr
  %ld760 = load i32, ptr %p759, align 4, !alias.scope !3, !noalias !4
  store i32 %ld760, ptr %slot63, align 8
  %v761 = load i32, ptr %slot63, align 8
  %op762 = and i32 %v761, 28
  store i32 %op762, ptr %slot64, align 8
  %v763 = load i32, ptr %slot64, align 8
  %cv764 = zext i32 %v763 to i64
  %cond765 = icmp ne i64 %cv764, 0
  br i1 %cond765, label %bb_rcslotrole53, label %bb_rcslotowner53
bb_rcslotrole53:
  %v766 = load i64, ptr %slot35, align 8
  store i64 %v766, ptr %slot65, align 8
  %v767 = load i64, ptr %slot65, align 8
  %v768 = load i64, ptr %slot62, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v767, i64 %v768) nomerge, !dbg !116
  br label %bb_rcslotdone53
bb_rcslotowner53:
  %v769 = load i64, ptr %slot35, align 8
  store i64 %v769, ptr %slot66, align 8
  %v770 = load i64, ptr %slot66, align 8
  %v771 = load i64, ptr %slot62, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v770, i64 %v771) nomerge, !dbg !116
  br label %bb_rcslotdone53
bb_rcslotdone53:
  br label %bb_rcprepared27
bb_rcprepared27:
  %v772 = load i64, ptr %slot4, align 8
  %p773 = inttoptr i64 %v772 to ptr
  %ld774 = load i32, ptr %p773, align 4, !alias.scope !3, !noalias !4
  store i32 %ld774, ptr %slot67, align 8
  %v775 = load i32, ptr %slot67, align 8
  %cv776 = zext i32 %v775 to i64
  %cond777 = icmp ne i64 %cv776, 0
  br i1 %cond777, label %bb_rcslotdrop63, label %bb_rcslotdone63
bb_rcslotdrop63:
  %v778 = load i64, ptr %slot4, align 8
  %p779 = inttoptr i64 %v778 to ptr
  store i32 0, ptr %p779, align 4, !alias.scope !3, !noalias !4
  %v780 = load i64, ptr %slot21, align 8
  store i64 %v780, ptr %slot68, align 8
  %v781 = load i64, ptr %slot5, align 8
  %p782 = inttoptr i64 %v781 to ptr
  %ld783 = load i32, ptr %p782, align 4, !alias.scope !3, !noalias !4
  store i32 %ld783, ptr %slot69, align 8
  %v784 = load i32, ptr %slot69, align 8
  %op785 = and i32 %v784, 28
  store i32 %op785, ptr %slot70, align 8
  %v786 = load i32, ptr %slot70, align 8
  %cv787 = zext i32 %v786 to i64
  %cond788 = icmp ne i64 %cv787, 0
  br i1 %cond788, label %bb_rcslotrole63, label %bb_rcslotowner63
bb_rcslotrole63:
  %v789 = load i64, ptr %slot35, align 8
  store i64 %v789, ptr %slot71, align 8
  %v790 = load i64, ptr %slot71, align 8
  %v791 = load i64, ptr %slot68, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v790, i64 %v791) nomerge, !dbg !116
  br label %bb_rcslotdone63
bb_rcslotowner63:
  %v792 = load i64, ptr %slot35, align 8
  store i64 %v792, ptr %slot72, align 8
  %v793 = load i64, ptr %slot72, align 8
  %v794 = load i64, ptr %slot68, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v793, i64 %v794) nomerge, !dbg !116
  br label %bb_rcslotdone63
bb_rcslotdone63:
  %v795 = load i64, ptr %slot21, align 8
  store i64 %v795, ptr %slot73, align 8
  %v796 = load i64, ptr %slot19, align 8
  store i64 %v796, ptr %slot74, align 8
  %v797 = load i64, ptr %slot74, align 8
  %v798 = load i64, ptr %slot73, align 8
  %p799 = inttoptr i64 %v797 to ptr
  %p800 = inttoptr i64 %v798 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p800, ptr %p799, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v801 = load i64, ptr %slot14, align 8
  %p802 = inttoptr i64 %v801 to ptr
  store i32 0, ptr %p802, align 4, !alias.scope !3, !noalias !4
  %v803 = load i64, ptr %slot5, align 8
  %p804 = inttoptr i64 %v803 to ptr
  store i32 2, ptr %p804, align 4, !alias.scope !3, !noalias !4
  %v805 = load i64, ptr %slot15, align 8
  %p806 = inttoptr i64 %v805 to ptr
  %ld807 = load i32, ptr %p806, align 4, !alias.scope !3, !noalias !4
  store i32 %ld807, ptr %slot75, align 8
  %v808 = load i32, ptr %slot75, align 8
  %v809 = load i64, ptr %slot5, align 8
  %p810 = inttoptr i64 %v809 to ptr
  store i32 %v808, ptr %p810, align 4, !alias.scope !3, !noalias !4
  %v811 = load i64, ptr %slot4, align 8
  %p812 = inttoptr i64 %v811 to ptr
  store i32 1, ptr %p812, align 4, !alias.scope !3, !noalias !4
  %v813 = load i64, ptr %slot20, align 8
  %p814 = inttoptr i64 %v813 to ptr
  %ld815 = load i64, ptr %p814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld815, ptr %slot76, align 8
  %v816 = load i64, ptr %slot76, align 8
  %v817 = load i64, ptr %slot26, align 8
  %p818 = inttoptr i64 %v817 to ptr
  store i64 %v816, ptr %p818, align 8, !alias.scope !3, !noalias !4
  %v819 = load i64, ptr %slot26, align 8
  %p820 = inttoptr i64 %v819 to ptr
  %ld821 = load i64, ptr %p820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld821, ptr %slot77, align 8
  %v822 = load i64, ptr %slot77, align 8
  %op823 = add i64 %v822, 248
  store i64 %op823, ptr %slot78, align 8
  %v824 = load i64, ptr %slot78, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %ld826 = load i64, ptr %p825, align 8, !alias.scope !4, !noalias !3
  store i64 %ld826, ptr %slot79, align 8
  %v827 = load i64, ptr %slot79, align 8
  %v828 = load i64, ptr %slot26, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 %v827, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot12, align 8
  %p831 = inttoptr i64 %v830 to ptr
  %ld832 = load i32, ptr %p831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld832, ptr %slot80, align 8
  %v833 = load i32, ptr %slot80, align 8
  %cv834 = zext i32 %v833 to i64
  %cond835 = icmp ne i64 %cv834, 0
  br i1 %cond835, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v836 = load i64, ptr %slot12, align 8
  %p837 = inttoptr i64 %v836 to ptr
  store i32 0, ptr %p837, align 4, !alias.scope !3, !noalias !4
  %v838 = load i64, ptr %slot17, align 8
  store i64 %v838, ptr %slot81, align 8
  %v839 = load i64, ptr %slot13, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i32, ptr %p840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld841, ptr %slot82, align 8
  %v842 = load i32, ptr %slot82, align 8
  %op843 = and i32 %v842, 28
  store i32 %op843, ptr %slot83, align 8
  %v844 = load i32, ptr %slot83, align 8
  %cv845 = zext i32 %v844 to i64
  %cond846 = icmp ne i64 %cv845, 0
  br i1 %cond846, label %bb_rcslotrole83, label %bb_rcslotowner83
bb_rcslotrole83:
  %v847 = load i64, ptr %slot35, align 8
  store i64 %v847, ptr %slot84, align 8
  %v848 = load i64, ptr %slot84, align 8
  %v849 = load i64, ptr %slot81, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v848, i64 %v849) nomerge, !dbg !118
  br label %bb_rcslotdone83
bb_rcslotowner83:
  %v850 = load i64, ptr %slot35, align 8
  store i64 %v850, ptr %slot85, align 8
  %v851 = load i64, ptr %slot85, align 8
  %v852 = load i64, ptr %slot81, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v851, i64 %v852) nomerge, !dbg !118
  br label %bb_rcslotdone83
bb_rcslotdone83:
  %v853 = load i64, ptr %slot26, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %ld855 = load i64, ptr %p854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld855, ptr %slot86, align 8
  %v856 = load i64, ptr %slot86, align 8
  %v857 = load i64, ptr %slot18, align 8
  %p858 = inttoptr i64 %v857 to ptr
  store i64 %v856, ptr %p858, align 8, !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot18, align 8
  store i64 %v859, ptr %slot87, align 8
  %v860 = load i64, ptr %slot12, align 8
  %p861 = inttoptr i64 %v860 to ptr
  %ld862 = load i32, ptr %p861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld862, ptr %slot88, align 8
  %v863 = load i64, ptr %slot13, align 8
  %p864 = inttoptr i64 %v863 to ptr
  %ld865 = load i32, ptr %p864, align 4, !alias.scope !3, !noalias !4
  store i32 %ld865, ptr %slot89, align 8
  %v866 = load i32, ptr %slot89, align 8
  %op867 = and i32 %v866, 24
  store i32 %op867, ptr %slot89, align 8
  %v868 = load i32, ptr %slot89, align 8
  %cmp869 = icmp eq i32 %v868, 0
  %cv870 = zext i1 %cmp869 to i32
  store i32 %cv870, ptr %slot90, align 8
  %v871 = load i32, ptr %slot88, align 8
  %v872 = load i32, ptr %slot90, align 8
  %op873 = and i32 %v871, %v872
  store i32 %op873, ptr %slot91, align 8
  %v874 = load i32, ptr %slot91, align 8
  %cv875 = zext i32 %v874 to i64
  %cond876 = icmp ne i64 %cv875, 0
  br i1 %cond876, label %bb_rcprivateown98, label %bb_rcprivateloan98
bb_rcprivateown98:
  %v877 = load i64, ptr %slot19, align 8
  store i64 %v877, ptr %slot92, align 8
  %v878 = load i64, ptr %slot36, align 8
  store i64 %v878, ptr %slot93, align 8
  %v879 = load i64, ptr %slot87, align 8
  %v880 = load i64, ptr %slot92, align 8
  %op881 = sub i64 %v879, %v880
  store i64 %op881, ptr %slot94, align 8
  %v882 = load i64, ptr %slot92, align 8
  %v883 = load i64, ptr %slot87, align 8
  %op884 = sub i64 %v882, %v883
  store i64 %op884, ptr %slot95, align 8
  %v885 = load i64, ptr %slot94, align 8
  %cmp886 = icmp ult i64 %v885, 8
  %cv887 = zext i1 %cmp886 to i32
  store i32 %cv887, ptr %slot96, align 8
  %v888 = load i64, ptr %slot95, align 8
  %cmp889 = icmp ult i64 %v888, 8
  %cv890 = zext i1 %cmp889 to i32
  store i32 %cv890, ptr %slot97, align 8
  %v891 = load i32, ptr %slot96, align 8
  %v892 = load i32, ptr %slot97, align 8
  %op893 = or i32 %v891, %v892
  store i32 %op893, ptr %slot98, align 8
  %v894 = load i32, ptr %slot98, align 8
  %cv895 = zext i32 %v894 to i64
  %cond896 = icmp ne i64 %cv895, 0
  br i1 %cond896, label %bb_rcmoveslow101, label %bb_rcmovecheck101
bb_rcmovecheck101:
  %v897 = load i64, ptr %slot87, align 8
  %p899 = inttoptr i64 %v897 to ptr
  %gep900 = getelementptr i8, ptr %p899, i64 0
  %op898 = ptrtoint ptr %gep900 to i64
  store i64 %op898, ptr %slot99, align 8
  %v901 = load i64, ptr %slot99, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %ld903 = load i64, ptr %p902, align 8, !alias.scope !3, !noalias !4
  store i64 %ld903, ptr %slot100, align 8
  %v904 = load i64, ptr %slot100, align 8
  %cmp905 = icmp ne i64 %v904, 0
  %cv906 = zext i1 %cmp905 to i32
  store i32 %cv906, ptr %slot101, align 8
  %v907 = load i32, ptr %slot101, align 8
  %cv908 = zext i32 %v907 to i64
  %cond909 = icmp ne i64 %cv908, 0
  br i1 %cond909, label %bb_rcmoveheader109, label %bb_rcmovenext109
bb_rcmoveheader109:
  %v910 = load i64, ptr %slot100, align 8
  %op911 = sub i64 %v910, 16
  store i64 %op911, ptr %slot102, align 8
  %v912 = load i64, ptr %slot100, align 8
  %p913 = inttoptr i64 %v912 to ptr
  %rgep914 = getelementptr i8, ptr %p913, i64 -16
  %ld915 = load i64, ptr %rgep914, align 8, !alias.scope !9, !noalias !10
  store i64 %ld915, ptr %slot103, align 8
  %v916 = load i64, ptr %slot103, align 8
  %op917 = and i64 %v916, 5764607523034234881
  store i64 %op917, ptr %slot104, align 8
  %v918 = load i64, ptr %slot104, align 8
  %cmp919 = icmp ne i64 %v918, 0
  %cv920 = zext i1 %cmp919 to i32
  store i32 %cv920, ptr %slot105, align 8
  %v921 = load i32, ptr %slot105, align 8
  %cv922 = zext i32 %v921 to i64
  %cond923 = icmp ne i64 %cv922, 0
  br i1 %cond923, label %bb_rcmoveslow101, label %bb_rcmovenext109
bb_rcmovenext109:
  %v924 = load i64, ptr %slot87, align 8
  %v925 = load i64, ptr %slot92, align 8
  %p926 = inttoptr i64 %v924 to ptr
  %p927 = inttoptr i64 %v925 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p927, ptr %p926, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v928 = load i64, ptr %slot87, align 8
  %p929 = inttoptr i64 %v928 to ptr
  store i64 0, ptr %p929, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved101
bb_rcmoveslow101:
  %v930 = load i64, ptr %slot35, align 8
  %v931 = load i64, ptr %slot92, align 8
  %v932 = load i64, ptr %slot87, align 8
  %v933 = load i64, ptr %slot93, align 8
  %cv934 = trunc i64 %v933 to i32
  %call935 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v930, i64 %v931, i64 %v932, i32 %cv934) nomerge, !dbg !120
  store i32 %call935, ptr %slot106, align 8
  %v936 = load i32, ptr %slot106, align 8
  %cv937 = zext i32 %v936 to i64
  %cond938 = icmp ne i64 %cv937, 0
  br i1 %cond938, label %bb_rcsuccess116, label %bb_rcfailure116
bb_rcfailure116:
  %v939 = load i64, ptr %slot35, align 8
  %p940 = inttoptr i64 %v939 to ptr
  %call941 = call i32 @myl_rc_take_failure(ptr %p940) nomerge, !dbg !120
  store i32 %call941, ptr %slot107, align 8
  %v942 = load i64, ptr %slot1, align 8
  %p943 = inttoptr i64 %v942 to ptr
  %v944 = load i32, ptr %slot107, align 8
  %call945 = call i32 @myl_qbe_rc_status(ptr %p943, i32 %v944) nomerge, !dbg !120
  store i32 %call945, ptr %slot108, align 8
  br label %bb_failure
bb_rcsuccess116:
  br label %bb_rcmoved101
bb_rcmoved101:
  %v946 = load i64, ptr %slot12, align 8
  %p947 = inttoptr i64 %v946 to ptr
  store i32 0, ptr %p947, align 4, !alias.scope !3, !noalias !4
  %v948 = load i64, ptr %slot15, align 8
  %p949 = inttoptr i64 %v948 to ptr
  store i32 2, ptr %p949, align 4, !alias.scope !3, !noalias !4
  %v950 = load i64, ptr %slot14, align 8
  %p951 = inttoptr i64 %v950 to ptr
  store i32 1, ptr %p951, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared98
bb_rcprivateloan98:
  %v952 = load i64, ptr %slot12, align 8
  %p953 = inttoptr i64 %v952 to ptr
  %ld954 = load i32, ptr %p953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld954, ptr %slot109, align 8
  %v955 = load i64, ptr %slot13, align 8
  %p956 = inttoptr i64 %v955 to ptr
  %ld957 = load i32, ptr %p956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld957, ptr %slot110, align 8
  %v958 = load i32, ptr %slot110, align 8
  %cmp959 = icmp eq i32 %v958, 16
  %cv960 = zext i1 %cmp959 to i32
  store i32 %cv960, ptr %slot111, align 8
  %v961 = load i32, ptr %slot111, align 8
  %v962 = load i32, ptr %slot109, align 8
  %op963 = and i32 %v961, %v962
  store i32 %op963, ptr %slot111, align 8
  %v964 = load i32, ptr %slot111, align 8
  %cv965 = zext i32 %v964 to i64
  %cond966 = icmp ne i64 %cv965, 0
  br i1 %cond966, label %bb_rcprivatemove98, label %bb_rcprivatenew98
bb_rcprivatemove98:
  %v967 = load i64, ptr %slot19, align 8
  store i64 %v967, ptr %slot112, align 8
  %v968 = load i64, ptr %slot87, align 8
  %v969 = load i64, ptr %slot112, align 8
  %p970 = inttoptr i64 %v968 to ptr
  %p971 = inttoptr i64 %v969 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p971, ptr %p970, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v972 = load i64, ptr %slot87, align 8
  %p973 = inttoptr i64 %v972 to ptr
  store i64 0, ptr %p973, align 8, !alias.scope !3, !noalias !4
  %v974 = load i64, ptr %slot15, align 8
  %p975 = inttoptr i64 %v974 to ptr
  store i32 2, ptr %p975, align 4, !alias.scope !3, !noalias !4
  %v976 = load i64, ptr %slot15, align 8
  %p977 = inttoptr i64 %v976 to ptr
  store i32 16, ptr %p977, align 4, !alias.scope !3, !noalias !4
  %v978 = load i64, ptr %slot14, align 8
  %p979 = inttoptr i64 %v978 to ptr
  store i32 1, ptr %p979, align 4, !alias.scope !3, !noalias !4
  %v980 = load i64, ptr %slot12, align 8
  %p981 = inttoptr i64 %v980 to ptr
  store i32 0, ptr %p981, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared98
bb_rcprivatenew98:
  %v982 = load i64, ptr %slot19, align 8
  store i64 %v982, ptr %slot113, align 8
  %v983 = load i64, ptr %slot87, align 8
  %p984 = inttoptr i64 %v983 to ptr
  %ld985 = load i64, ptr %p984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld985, ptr %slot114, align 8
  %v986 = load i64, ptr %slot114, align 8
  %cmp987 = icmp ne i64 %v986, 0
  %cv988 = zext i1 %cmp987 to i32
  store i32 %cv988, ptr %slot115, align 8
  %v989 = load i32, ptr %slot115, align 8
  %cv990 = zext i32 %v989 to i64
  %cond991 = icmp ne i64 %cv990, 0
  br i1 %cond991, label %bb_rcgnn134, label %bb_rcgstore134
bb_rcgnn134:
  %v992 = load i64, ptr %slot114, align 8
  %op993 = sub i64 %v992, 16
  store i64 %op993, ptr %slot116, align 8
  %v994 = load i64, ptr %slot114, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %rgep996 = getelementptr i8, ptr %p995, i64 -16
  %ld997 = load i64, ptr %rgep996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld997, ptr %slot117, align 8
  %v998 = load i64, ptr %slot117, align 8
  %op999 = and i64 %v998, 4611686018427387906
  store i64 %op999, ptr %slot118, align 8
  %v1000 = load i64, ptr %slot118, align 8
  %cmp1001 = icmp ne i64 %v1000, 0
  %cv1002 = zext i1 %cmp1001 to i32
  store i32 %cv1002, ptr %slot119, align 8
  %v1003 = load i32, ptr %slot119, align 8
  %cv1004 = zext i32 %v1003 to i64
  %cond1005 = icmp ne i64 %cv1004, 0
  br i1 %cond1005, label %bb_rcgstore134, label %bb_rcginc134
bb_rcginc134:
  %v1006 = load i64, ptr %slot114, align 8
  %op1007 = sub i64 %v1006, 24
  store i64 %op1007, ptr %slot120, align 8
  %v1008 = load i64, ptr %slot114, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  %rgep1010 = getelementptr i8, ptr %p1009, i64 -24
  %ld1011 = load i64, ptr %rgep1010, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1011, ptr %slot121, align 8
  %v1012 = load i64, ptr %slot121, align 8
  %op1013 = add i64 %v1012, 1
  store i64 %op1013, ptr %slot122, align 8
  %v1014 = load i64, ptr %slot122, align 8
  %cmp1015 = icmp eq i64 %v1014, 0
  %cv1016 = zext i1 %cmp1015 to i32
  store i32 %cv1016, ptr %slot123, align 8
  %v1017 = load i32, ptr %slot123, align 8
  %cv1018 = zext i32 %v1017 to i64
  %cond1019 = icmp ne i64 %cv1018, 0
  br i1 %cond1019, label %bb_rcglimit134, label %bb_rcgcapacity134
bb_rcglimit134:
  %v1020 = load i64, ptr %slot1, align 8
  %p1021 = inttoptr i64 %v1020 to ptr
  %call1022 = call i32 @myl_qbe_rc_status(ptr %p1021, i32 2) nomerge, !dbg !120
  store i32 %call1022, ptr %slot124, align 8
  br label %bb_failure
bb_rcgcapacity134:
  %v1023 = load i64, ptr %slot122, align 8
  %v1024 = load i64, ptr %slot114, align 8
  %p1025 = inttoptr i64 %v1024 to ptr
  %rgep1026 = getelementptr i8, ptr %p1025, i64 -24
  store i64 %v1023, ptr %rgep1026, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore134
bb_rcgstore134:
  %v1027 = load i64, ptr %slot114, align 8
  %v1028 = load i64, ptr %slot113, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  store i64 %v1027, ptr %p1029, align 8, !alias.scope !3, !noalias !4
  %v1030 = load i64, ptr %slot15, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  store i32 2, ptr %p1031, align 4, !alias.scope !3, !noalias !4
  %v1032 = load i64, ptr %slot15, align 8
  %p1033 = inttoptr i64 %v1032 to ptr
  store i32 16, ptr %p1033, align 4, !alias.scope !3, !noalias !4
  %v1034 = load i64, ptr %slot14, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  store i32 1, ptr %p1035, align 4, !alias.scope !3, !noalias !4
  %v1036 = load i64, ptr %slot12, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  %ld1038 = load i32, ptr %p1037, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1038, ptr %slot125, align 8
  %v1039 = load i32, ptr %slot125, align 8
  %cv1040 = zext i32 %v1039 to i64
  %cond1041 = icmp ne i64 %cv1040, 0
  br i1 %cond1041, label %bb_rcslotdrop150, label %bb_rcslotdone150
bb_rcslotdrop150:
  %v1042 = load i64, ptr %slot12, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  store i32 0, ptr %p1043, align 4, !alias.scope !3, !noalias !4
  %v1044 = load i64, ptr %slot17, align 8
  store i64 %v1044, ptr %slot126, align 8
  %v1045 = load i64, ptr %slot13, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  %ld1047 = load i32, ptr %p1046, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1047, ptr %slot127, align 8
  %v1048 = load i32, ptr %slot127, align 8
  %op1049 = and i32 %v1048, 28
  store i32 %op1049, ptr %slot128, align 8
  %v1050 = load i32, ptr %slot128, align 8
  %cv1051 = zext i32 %v1050 to i64
  %cond1052 = icmp ne i64 %cv1051, 0
  br i1 %cond1052, label %bb_rcslotrole150, label %bb_rcslotowner150
bb_rcslotrole150:
  %v1053 = load i64, ptr %slot35, align 8
  store i64 %v1053, ptr %slot129, align 8
  %v1054 = load i64, ptr %slot126, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  %ld1056 = load i64, ptr %p1055, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1056, ptr %slot130, align 8
  %v1057 = load i64, ptr %slot130, align 8
  %cmp1058 = icmp ne i64 %v1057, 0
  %cv1059 = zext i1 %cmp1058 to i32
  store i32 %cv1059, ptr %slot131, align 8
  %v1060 = load i32, ptr %slot131, align 8
  %cv1061 = zext i32 %v1060 to i64
  %cond1062 = icmp ne i64 %cv1061, 0
  br i1 %cond1062, label %bb_rcgnn166, label %bb_rcgdone166
bb_rcgnn166:
  %v1063 = load i64, ptr %slot130, align 8
  %op1064 = sub i64 %v1063, 16
  store i64 %op1064, ptr %slot132, align 8
  %v1065 = load i64, ptr %slot130, align 8
  %p1066 = inttoptr i64 %v1065 to ptr
  %rgep1067 = getelementptr i8, ptr %p1066, i64 -16
  %ld1068 = load i64, ptr %rgep1067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1068, ptr %slot133, align 8
  %v1069 = load i64, ptr %slot133, align 8
  %op1070 = and i64 %v1069, 4611686018427387906
  store i64 %op1070, ptr %slot134, align 8
  %v1071 = load i64, ptr %slot134, align 8
  %cmp1072 = icmp ne i64 %v1071, 0
  %cv1073 = zext i1 %cmp1072 to i32
  store i32 %cv1073, ptr %slot135, align 8
  %v1074 = load i32, ptr %slot135, align 8
  %cv1075 = zext i32 %v1074 to i64
  %cond1076 = icmp ne i64 %cv1075, 0
  br i1 %cond1076, label %bb_rcgclear166, label %bb_rcgcounted166
bb_rcgcounted166:
  %v1077 = load i64, ptr %slot130, align 8
  %op1078 = sub i64 %v1077, 24
  store i64 %op1078, ptr %slot136, align 8
  %v1079 = load i64, ptr %slot130, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  %rgep1081 = getelementptr i8, ptr %p1080, i64 -24
  %ld1082 = load i64, ptr %rgep1081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1082, ptr %slot137, align 8
  %v1083 = load i64, ptr %slot137, align 8
  %op1084 = sub i64 %v1083, 1
  store i64 %op1084, ptr %slot138, align 8
  %v1085 = load i64, ptr %slot138, align 8
  %cmp1086 = icmp eq i64 %v1085, 0
  %cv1087 = zext i1 %cmp1086 to i32
  store i32 %cv1087, ptr %slot139, align 8
  %v1088 = load i32, ptr %slot139, align 8
  %cv1089 = zext i32 %v1088 to i64
  %cond1090 = icmp ne i64 %cv1089, 0
  br i1 %cond1090, label %bb_rcglast166, label %bb_rcgdec166
bb_rcglast166:
  %v1091 = load i64, ptr %slot130, align 8
  %op1092 = sub i64 %v1091, 32
  store i64 %op1092, ptr %slot140, align 8
  %v1093 = load i64, ptr %slot130, align 8
  %p1094 = inttoptr i64 %v1093 to ptr
  %rgep1095 = getelementptr i8, ptr %p1094, i64 -32
  %ld1096 = load i64, ptr %rgep1095, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1096, ptr %slot141, align 8
  %v1097 = load i64, ptr %slot141, align 8
  %cmp1098 = icmp ne i64 %v1097, 0
  %cv1099 = zext i1 %cmp1098 to i32
  store i32 %cv1099, ptr %slot142, align 8
  %v1100 = load i32, ptr %slot142, align 8
  %cv1101 = zext i32 %v1100 to i64
  %cond1102 = icmp ne i64 %cv1101, 0
  br i1 %cond1102, label %bb_rcgdec166, label %bb_rcgslow166
bb_rcgslow166:
  %v1103 = load i64, ptr %slot129, align 8
  %v1104 = load i64, ptr %slot126, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1103, i64 %v1104) nomerge, !dbg !120
  br label %bb_rcgdone166
bb_rcgdec166:
  %v1105 = load i64, ptr %slot138, align 8
  %v1106 = load i64, ptr %slot130, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  %rgep1108 = getelementptr i8, ptr %p1107, i64 -24
  store i64 %v1105, ptr %rgep1108, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear166
bb_rcgclear166:
  %v1109 = load i64, ptr %slot126, align 8
  %p1110 = inttoptr i64 %v1109 to ptr
  store i64 0, ptr %p1110, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone166
bb_rcgdone166:
  br label %bb_rcslotdone150
bb_rcslotowner150:
  %v1111 = load i64, ptr %slot35, align 8
  store i64 %v1111, ptr %slot143, align 8
  %v1112 = load i64, ptr %slot126, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  %ld1114 = load i64, ptr %p1113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1114, ptr %slot144, align 8
  %v1115 = load i64, ptr %slot144, align 8
  %cmp1116 = icmp ne i64 %v1115, 0
  %cv1117 = zext i1 %cmp1116 to i32
  store i32 %cv1117, ptr %slot145, align 8
  %v1118 = load i32, ptr %slot145, align 8
  %cv1119 = zext i32 %v1118 to i64
  %cond1120 = icmp ne i64 %cv1119, 0
  br i1 %cond1120, label %bb_rcgnn181, label %bb_rcgdone181
bb_rcgnn181:
  %v1121 = load i64, ptr %slot144, align 8
  %op1122 = sub i64 %v1121, 16
  store i64 %op1122, ptr %slot146, align 8
  %v1123 = load i64, ptr %slot144, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  %rgep1125 = getelementptr i8, ptr %p1124, i64 -16
  %ld1126 = load i64, ptr %rgep1125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1126, ptr %slot147, align 8
  %v1127 = load i64, ptr %slot147, align 8
  %op1128 = and i64 %v1127, 4611686018427387906
  store i64 %op1128, ptr %slot148, align 8
  %v1129 = load i64, ptr %slot148, align 8
  %cmp1130 = icmp ne i64 %v1129, 0
  %cv1131 = zext i1 %cmp1130 to i32
  store i32 %cv1131, ptr %slot149, align 8
  %v1132 = load i32, ptr %slot149, align 8
  %cv1133 = zext i32 %v1132 to i64
  %cond1134 = icmp ne i64 %cv1133, 0
  br i1 %cond1134, label %bb_rcgclear181, label %bb_rcgcounted181
bb_rcgcounted181:
  %v1135 = load i64, ptr %slot144, align 8
  %op1136 = sub i64 %v1135, 32
  store i64 %op1136, ptr %slot150, align 8
  %v1137 = load i64, ptr %slot144, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %rgep1139 = getelementptr i8, ptr %p1138, i64 -32
  %ld1140 = load i64, ptr %rgep1139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1140, ptr %slot151, align 8
  %v1141 = load i64, ptr %slot151, align 8
  %op1142 = sub i64 %v1141, 1
  store i64 %op1142, ptr %slot152, align 8
  %v1143 = load i64, ptr %slot152, align 8
  %cmp1144 = icmp eq i64 %v1143, 0
  %cv1145 = zext i1 %cmp1144 to i32
  store i32 %cv1145, ptr %slot153, align 8
  %v1146 = load i32, ptr %slot153, align 8
  %cv1147 = zext i32 %v1146 to i64
  %cond1148 = icmp ne i64 %cv1147, 0
  br i1 %cond1148, label %bb_rcglast181, label %bb_rcgdec181
bb_rcglast181:
  %v1149 = load i64, ptr %slot144, align 8
  %op1150 = sub i64 %v1149, 24
  store i64 %op1150, ptr %slot154, align 8
  %v1151 = load i64, ptr %slot144, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  %rgep1153 = getelementptr i8, ptr %p1152, i64 -24
  %ld1154 = load i64, ptr %rgep1153, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1154, ptr %slot155, align 8
  %v1155 = load i64, ptr %slot155, align 8
  %cmp1156 = icmp ne i64 %v1155, 0
  %cv1157 = zext i1 %cmp1156 to i32
  store i32 %cv1157, ptr %slot156, align 8
  %v1158 = load i32, ptr %slot156, align 8
  %cv1159 = zext i32 %v1158 to i64
  %cond1160 = icmp ne i64 %cv1159, 0
  br i1 %cond1160, label %bb_rcgdec181, label %bb_rcgslow181
bb_rcgslow181:
  %v1161 = load i64, ptr %slot143, align 8
  %v1162 = load i64, ptr %slot126, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1161, i64 %v1162) nomerge, !dbg !120
  br label %bb_rcgdone181
bb_rcgdec181:
  %v1163 = load i64, ptr %slot152, align 8
  %v1164 = load i64, ptr %slot144, align 8
  %p1165 = inttoptr i64 %v1164 to ptr
  %rgep1166 = getelementptr i8, ptr %p1165, i64 -32
  store i64 %v1163, ptr %rgep1166, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear181
bb_rcgclear181:
  %v1167 = load i64, ptr %slot126, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i64 0, ptr %p1168, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone181
bb_rcgdone181:
  br label %bb_rcslotdone150
bb_rcslotdone150:
  br label %bb_rcprivateprepared98
bb_rcprivateprepared98:
  %v1169 = load i64, ptr %slot6, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  %ld1171 = load i32, ptr %p1170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1171, ptr %slot157, align 8
  %v1172 = load i32, ptr %slot157, align 8
  %cv1173 = zext i32 %v1172 to i64
  %cond1174 = icmp ne i64 %cv1173, 0
  br i1 %cond1174, label %bb_rcslotdrop188, label %bb_rcslotdone188
bb_rcslotdrop188:
  %v1175 = load i64, ptr %slot6, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  store i32 0, ptr %p1176, align 4, !alias.scope !3, !noalias !4
  %v1177 = load i64, ptr %slot22, align 8
  store i64 %v1177, ptr %slot158, align 8
  %v1178 = load i64, ptr %slot7, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  %ld1180 = load i32, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1180, ptr %slot159, align 8
  %v1181 = load i32, ptr %slot159, align 8
  %op1182 = and i32 %v1181, 28
  store i32 %op1182, ptr %slot160, align 8
  %v1183 = load i32, ptr %slot160, align 8
  %cv1184 = zext i32 %v1183 to i64
  %cond1185 = icmp ne i64 %cv1184, 0
  br i1 %cond1185, label %bb_rcslotrole188, label %bb_rcslotowner188
bb_rcslotrole188:
  %v1186 = load i64, ptr %slot35, align 8
  store i64 %v1186, ptr %slot161, align 8
  %v1187 = load i64, ptr %slot158, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i64, ptr %p1188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1189, ptr %slot162, align 8
  %v1190 = load i64, ptr %slot162, align 8
  %cmp1191 = icmp ne i64 %v1190, 0
  %cv1192 = zext i1 %cmp1191 to i32
  store i32 %cv1192, ptr %slot163, align 8
  %v1193 = load i32, ptr %slot163, align 8
  %cv1194 = zext i32 %v1193 to i64
  %cond1195 = icmp ne i64 %cv1194, 0
  br i1 %cond1195, label %bb_rcgnn204, label %bb_rcgdone204
bb_rcgnn204:
  %v1196 = load i64, ptr %slot162, align 8
  %op1197 = sub i64 %v1196, 16
  store i64 %op1197, ptr %slot164, align 8
  %v1198 = load i64, ptr %slot162, align 8
  %p1199 = inttoptr i64 %v1198 to ptr
  %rgep1200 = getelementptr i8, ptr %p1199, i64 -16
  %ld1201 = load i64, ptr %rgep1200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1201, ptr %slot165, align 8
  %v1202 = load i64, ptr %slot165, align 8
  %op1203 = and i64 %v1202, 4611686018427387906
  store i64 %op1203, ptr %slot166, align 8
  %v1204 = load i64, ptr %slot166, align 8
  %cmp1205 = icmp ne i64 %v1204, 0
  %cv1206 = zext i1 %cmp1205 to i32
  store i32 %cv1206, ptr %slot167, align 8
  %v1207 = load i32, ptr %slot167, align 8
  %cv1208 = zext i32 %v1207 to i64
  %cond1209 = icmp ne i64 %cv1208, 0
  br i1 %cond1209, label %bb_rcgclear204, label %bb_rcgcounted204
bb_rcgcounted204:
  %v1210 = load i64, ptr %slot162, align 8
  %op1211 = sub i64 %v1210, 24
  store i64 %op1211, ptr %slot168, align 8
  %v1212 = load i64, ptr %slot162, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  %rgep1214 = getelementptr i8, ptr %p1213, i64 -24
  %ld1215 = load i64, ptr %rgep1214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1215, ptr %slot169, align 8
  %v1216 = load i64, ptr %slot169, align 8
  %op1217 = sub i64 %v1216, 1
  store i64 %op1217, ptr %slot170, align 8
  %v1218 = load i64, ptr %slot170, align 8
  %cmp1219 = icmp eq i64 %v1218, 0
  %cv1220 = zext i1 %cmp1219 to i32
  store i32 %cv1220, ptr %slot171, align 8
  %v1221 = load i32, ptr %slot171, align 8
  %cv1222 = zext i32 %v1221 to i64
  %cond1223 = icmp ne i64 %cv1222, 0
  br i1 %cond1223, label %bb_rcglast204, label %bb_rcgdec204
bb_rcglast204:
  %v1224 = load i64, ptr %slot162, align 8
  %op1225 = sub i64 %v1224, 32
  store i64 %op1225, ptr %slot172, align 8
  %v1226 = load i64, ptr %slot162, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  %rgep1228 = getelementptr i8, ptr %p1227, i64 -32
  %ld1229 = load i64, ptr %rgep1228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1229, ptr %slot173, align 8
  %v1230 = load i64, ptr %slot173, align 8
  %cmp1231 = icmp ne i64 %v1230, 0
  %cv1232 = zext i1 %cmp1231 to i32
  store i32 %cv1232, ptr %slot174, align 8
  %v1233 = load i32, ptr %slot174, align 8
  %cv1234 = zext i32 %v1233 to i64
  %cond1235 = icmp ne i64 %cv1234, 0
  br i1 %cond1235, label %bb_rcgdec204, label %bb_rcgslow204
bb_rcgslow204:
  %v1236 = load i64, ptr %slot161, align 8
  %v1237 = load i64, ptr %slot158, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1236, i64 %v1237) nomerge, !dbg !120
  br label %bb_rcgdone204
bb_rcgdec204:
  %v1238 = load i64, ptr %slot170, align 8
  %v1239 = load i64, ptr %slot162, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %rgep1241 = getelementptr i8, ptr %p1240, i64 -24
  store i64 %v1238, ptr %rgep1241, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear204
bb_rcgclear204:
  %v1242 = load i64, ptr %slot158, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  store i64 0, ptr %p1243, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone204
bb_rcgdone204:
  br label %bb_rcslotdone188
bb_rcslotowner188:
  %v1244 = load i64, ptr %slot35, align 8
  store i64 %v1244, ptr %slot175, align 8
  %v1245 = load i64, ptr %slot158, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  %ld1247 = load i64, ptr %p1246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1247, ptr %slot176, align 8
  %v1248 = load i64, ptr %slot176, align 8
  %cmp1249 = icmp ne i64 %v1248, 0
  %cv1250 = zext i1 %cmp1249 to i32
  store i32 %cv1250, ptr %slot177, align 8
  %v1251 = load i32, ptr %slot177, align 8
  %cv1252 = zext i32 %v1251 to i64
  %cond1253 = icmp ne i64 %cv1252, 0
  br i1 %cond1253, label %bb_rcgnn219, label %bb_rcgdone219
bb_rcgnn219:
  %v1254 = load i64, ptr %slot176, align 8
  %op1255 = sub i64 %v1254, 16
  store i64 %op1255, ptr %slot178, align 8
  %v1256 = load i64, ptr %slot176, align 8
  %p1257 = inttoptr i64 %v1256 to ptr
  %rgep1258 = getelementptr i8, ptr %p1257, i64 -16
  %ld1259 = load i64, ptr %rgep1258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1259, ptr %slot179, align 8
  %v1260 = load i64, ptr %slot179, align 8
  %op1261 = and i64 %v1260, 4611686018427387906
  store i64 %op1261, ptr %slot180, align 8
  %v1262 = load i64, ptr %slot180, align 8
  %cmp1263 = icmp ne i64 %v1262, 0
  %cv1264 = zext i1 %cmp1263 to i32
  store i32 %cv1264, ptr %slot181, align 8
  %v1265 = load i32, ptr %slot181, align 8
  %cv1266 = zext i32 %v1265 to i64
  %cond1267 = icmp ne i64 %cv1266, 0
  br i1 %cond1267, label %bb_rcgclear219, label %bb_rcgcounted219
bb_rcgcounted219:
  %v1268 = load i64, ptr %slot176, align 8
  %op1269 = sub i64 %v1268, 32
  store i64 %op1269, ptr %slot182, align 8
  %v1270 = load i64, ptr %slot176, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  %rgep1272 = getelementptr i8, ptr %p1271, i64 -32
  %ld1273 = load i64, ptr %rgep1272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1273, ptr %slot183, align 8
  %v1274 = load i64, ptr %slot183, align 8
  %op1275 = sub i64 %v1274, 1
  store i64 %op1275, ptr %slot184, align 8
  %v1276 = load i64, ptr %slot184, align 8
  %cmp1277 = icmp eq i64 %v1276, 0
  %cv1278 = zext i1 %cmp1277 to i32
  store i32 %cv1278, ptr %slot185, align 8
  %v1279 = load i32, ptr %slot185, align 8
  %cv1280 = zext i32 %v1279 to i64
  %cond1281 = icmp ne i64 %cv1280, 0
  br i1 %cond1281, label %bb_rcglast219, label %bb_rcgdec219
bb_rcglast219:
  %v1282 = load i64, ptr %slot176, align 8
  %op1283 = sub i64 %v1282, 24
  store i64 %op1283, ptr %slot186, align 8
  %v1284 = load i64, ptr %slot176, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  %rgep1286 = getelementptr i8, ptr %p1285, i64 -24
  %ld1287 = load i64, ptr %rgep1286, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1287, ptr %slot187, align 8
  %v1288 = load i64, ptr %slot187, align 8
  %cmp1289 = icmp ne i64 %v1288, 0
  %cv1290 = zext i1 %cmp1289 to i32
  store i32 %cv1290, ptr %slot188, align 8
  %v1291 = load i32, ptr %slot188, align 8
  %cv1292 = zext i32 %v1291 to i64
  %cond1293 = icmp ne i64 %cv1292, 0
  br i1 %cond1293, label %bb_rcgdec219, label %bb_rcgslow219
bb_rcgslow219:
  %v1294 = load i64, ptr %slot175, align 8
  %v1295 = load i64, ptr %slot158, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1294, i64 %v1295) nomerge, !dbg !120
  br label %bb_rcgdone219
bb_rcgdec219:
  %v1296 = load i64, ptr %slot184, align 8
  %v1297 = load i64, ptr %slot176, align 8
  %p1298 = inttoptr i64 %v1297 to ptr
  %rgep1299 = getelementptr i8, ptr %p1298, i64 -32
  store i64 %v1296, ptr %rgep1299, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear219
bb_rcgclear219:
  %v1300 = load i64, ptr %slot158, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i64 0, ptr %p1301, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone219
bb_rcgdone219:
  br label %bb_rcslotdone188
bb_rcslotdone188:
  %v1302 = load i64, ptr %slot22, align 8
  store i64 %v1302, ptr %slot189, align 8
  %v1303 = load i64, ptr %slot19, align 8
  store i64 %v1303, ptr %slot190, align 8
  %v1304 = load i64, ptr %slot190, align 8
  %v1305 = load i64, ptr %slot189, align 8
  %p1306 = inttoptr i64 %v1304 to ptr
  %p1307 = inttoptr i64 %v1305 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1307, ptr %p1306, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1308 = load i64, ptr %slot14, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  store i32 0, ptr %p1309, align 4, !alias.scope !3, !noalias !4
  %v1310 = load i64, ptr %slot7, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  store i32 2, ptr %p1311, align 4, !alias.scope !3, !noalias !4
  %v1312 = load i64, ptr %slot15, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  %ld1314 = load i32, ptr %p1313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1314, ptr %slot191, align 8
  %v1315 = load i32, ptr %slot191, align 8
  %v1316 = load i64, ptr %slot7, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  store i32 %v1315, ptr %p1317, align 4, !alias.scope !3, !noalias !4
  %v1318 = load i64, ptr %slot6, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i32 1, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  %v1320 = load i64, ptr %slot21, align 8
  %v1321 = load i64, ptr %slot26, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  store i64 %v1320, ptr %p1322, align 8, !alias.scope !3, !noalias !4
  %v1323 = load i64, ptr %slot26, align 8
  %p1324 = inttoptr i64 %v1323 to ptr
  %ld1325 = load i64, ptr %p1324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1325, ptr %slot192, align 8
  %v1326 = load i64, ptr %slot192, align 8
  %op1327 = add i64 %v1326, 8
  store i64 %op1327, ptr %slot193, align 8
  %v1328 = load i64, ptr %slot193, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  %ld1330 = load i64, ptr %p1329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1330, ptr %slot194, align 8
  %v1331 = load i64, ptr %slot194, align 8
  %v1332 = load i64, ptr %slot26, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  store i64 %v1331, ptr %p1333, align 8, !alias.scope !3, !noalias !4
  %v1334 = load i64, ptr %slot12, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  %ld1336 = load i32, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1336, ptr %slot195, align 8
  %v1337 = load i32, ptr %slot195, align 8
  %cv1338 = zext i32 %v1337 to i64
  %cond1339 = icmp ne i64 %cv1338, 0
  br i1 %cond1339, label %bb_rcslotdrop235, label %bb_rcslotdone235
bb_rcslotdrop235:
  %v1340 = load i64, ptr %slot12, align 8
  %p1341 = inttoptr i64 %v1340 to ptr
  store i32 0, ptr %p1341, align 4, !alias.scope !3, !noalias !4
  %v1342 = load i64, ptr %slot17, align 8
  store i64 %v1342, ptr %slot196, align 8
  %v1343 = load i64, ptr %slot13, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  %ld1345 = load i32, ptr %p1344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1345, ptr %slot197, align 8
  %v1346 = load i32, ptr %slot197, align 8
  %op1347 = and i32 %v1346, 28
  store i32 %op1347, ptr %slot198, align 8
  %v1348 = load i32, ptr %slot198, align 8
  %cv1349 = zext i32 %v1348 to i64
  %cond1350 = icmp ne i64 %cv1349, 0
  br i1 %cond1350, label %bb_rcslotrole235, label %bb_rcslotowner235
bb_rcslotrole235:
  %v1351 = load i64, ptr %slot35, align 8
  store i64 %v1351, ptr %slot199, align 8
  %v1352 = load i64, ptr %slot199, align 8
  %v1353 = load i64, ptr %slot196, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1352, i64 %v1353) nomerge, !dbg !122
  br label %bb_rcslotdone235
bb_rcslotowner235:
  %v1354 = load i64, ptr %slot35, align 8
  store i64 %v1354, ptr %slot200, align 8
  %v1355 = load i64, ptr %slot200, align 8
  %v1356 = load i64, ptr %slot196, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1355, i64 %v1356) nomerge, !dbg !122
  br label %bb_rcslotdone235
bb_rcslotdone235:
  %v1357 = load i64, ptr %slot27, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  store i64 1, ptr %p1358, align 8, !alias.scope !3, !noalias !4
  %v1359 = load i64, ptr %slot27, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  %ld1361 = load i64, ptr %p1360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1361, ptr %slot201, align 8
  %v1362 = load i64, ptr %slot26, align 8
  %p1363 = inttoptr i64 %v1362 to ptr
  %ld1364 = load i64, ptr %p1363, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1364, ptr %slot202, align 8
  %v1365 = load i64, ptr %slot202, align 8
  %v1366 = load i64, ptr %slot201, align 8
  %ovpair1368 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1365, i64 %v1366)
  %op1367 = extractvalue { i64, i1 } %ovpair1368, 0
  %ov1369 = extractvalue { i64, i1 } %ovpair1368, 1
  store i64 %op1367, ptr %slot203, align 8
  %cv1370 = zext i1 %ov1369 to i64
  store i64 %cv1370, ptr %slot204, align 8
  %v1371 = load i64, ptr %slot204, align 8
  %cond1372 = icmp ne i64 %v1371, 0
  br i1 %cond1372, label %bb_overflow244, label %bb_checked244
bb_overflow244:
  %v1373 = load i64, ptr %slot1, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  %v1375 = load i64, ptr %slot202, align 8
  %v1376 = load i64, ptr %slot201, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1374, i64 0, i64 %v1375, i64 %v1376, i64 64) nomerge, !dbg !124
  unreachable
bb_checked244:
  %v1377 = load i64, ptr %slot203, align 8
  %v1378 = load i64, ptr %slot26, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i64 %v1377, ptr %p1379, align 8, !alias.scope !3, !noalias !4
  %v1380 = load i64, ptr %slot21, align 8
  %v1381 = load i64, ptr %slot27, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  store i64 %v1380, ptr %p1382, align 8, !alias.scope !3, !noalias !4
  %v1383 = load i64, ptr %slot27, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  %ld1385 = load i64, ptr %p1384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1385, ptr %slot205, align 8
  %v1386 = load i64, ptr %slot205, align 8
  %op1387 = add i64 %v1386, 8
  store i64 %op1387, ptr %slot206, align 8
  %v1388 = load i64, ptr %slot206, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %ld1390 = load i64, ptr %p1389, align 8
  store i64 %ld1390, ptr %slot207, align 8
  %v1391 = load i64, ptr %slot207, align 8
  %v1392 = load i64, ptr %slot27, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i64 %v1391, ptr %p1393, align 8, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot21, align 8
  %v1395 = load i64, ptr %slot28, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  store i64 %v1394, ptr %p1396, align 8, !alias.scope !3, !noalias !4
  %v1397 = load i64, ptr %slot28, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  %ld1399 = load i64, ptr %p1398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1399, ptr %slot208, align 8
  %v1400 = load i64, ptr %slot208, align 8
  %op1401 = add i64 %v1400, 16
  store i64 %op1401, ptr %slot209, align 8
  %v1402 = load i64, ptr %slot209, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  %ld1404 = load i64, ptr %p1403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1404, ptr %slot210, align 8
  %v1405 = load i64, ptr %slot210, align 8
  %v1406 = load i64, ptr %slot28, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i64 %v1405, ptr %p1407, align 8, !alias.scope !3, !noalias !4
  %v1408 = load i64, ptr %slot28, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i64, ptr %p1409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1410, ptr %slot211, align 8
  %v1411 = load i64, ptr %slot27, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i64, ptr %p1412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1413, ptr %slot212, align 8
  %v1414 = load i64, ptr %slot212, align 8
  %v1415 = load i64, ptr %slot211, align 8
  %ovpair1417 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1414, i64 %v1415)
  %op1416 = extractvalue { i64, i1 } %ovpair1417, 0
  %ov1418 = extractvalue { i64, i1 } %ovpair1417, 1
  store i64 %op1416, ptr %slot213, align 8
  %v1419 = load i64, ptr %slot212, align 8
  %v1420 = load i64, ptr %slot213, align 8
  %op1421 = xor i64 %v1419, %v1420
  store i64 %op1421, ptr %slot214, align 8
  %v1422 = load i64, ptr %slot211, align 8
  %v1423 = load i64, ptr %slot213, align 8
  %op1424 = xor i64 %v1422, %v1423
  store i64 %op1424, ptr %slot215, align 8
  %v1425 = load i64, ptr %slot214, align 8
  %v1426 = load i64, ptr %slot215, align 8
  %op1427 = and i64 %v1425, %v1426
  store i64 %op1427, ptr %slot216, align 8
  %cv1428 = zext i1 %ov1418 to i64
  store i64 %cv1428, ptr %slot217, align 8
  %v1429 = load i64, ptr %slot217, align 8
  %cond1430 = icmp ne i64 %v1429, 0
  br i1 %cond1430, label %bb_overflow272, label %bb_checked272
bb_overflow272:
  %v1431 = load i64, ptr %slot1, align 8
  %p1432 = inttoptr i64 %v1431 to ptr
  %v1433 = load i64, ptr %slot212, align 8
  %v1434 = load i64, ptr %slot211, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1432, i64 0, i64 %v1433, i64 %v1434, i64 64) nomerge, !dbg !126
  unreachable
bb_checked272:
  %v1435 = load i64, ptr %slot213, align 8
  %v1436 = load i64, ptr %slot27, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  store i64 %v1435, ptr %p1437, align 8, !alias.scope !3, !noalias !4
  %v1438 = load i64, ptr %slot28, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  store i64 1, ptr %p1439, align 8, !alias.scope !3, !noalias !4
  %v1440 = load i64, ptr %slot28, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %ld1442 = load i64, ptr %p1441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1442, ptr %slot218, align 8
  %v1443 = load i64, ptr %slot27, align 8
  %p1444 = inttoptr i64 %v1443 to ptr
  %ld1445 = load i64, ptr %p1444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1445, ptr %slot219, align 8
  %v1446 = load i64, ptr %slot219, align 8
  %v1447 = load i64, ptr %slot218, align 8
  %ovpair1449 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v1446, i64 %v1447)
  %op1448 = extractvalue { i64, i1 } %ovpair1449, 0
  %ov1450 = extractvalue { i64, i1 } %ovpair1449, 1
  store i64 %op1448, ptr %slot220, align 8
  %cv1451 = zext i1 %ov1450 to i64
  store i64 %cv1451, ptr %slot221, align 8
  %v1452 = load i64, ptr %slot221, align 8
  %cond1453 = icmp ne i64 %v1452, 0
  br i1 %cond1453, label %bb_overflow279, label %bb_checked279
bb_overflow279:
  %v1454 = load i64, ptr %slot1, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %v1456 = load i64, ptr %slot219, align 8
  %v1457 = load i64, ptr %slot218, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1455, i64 1, i64 %v1456, i64 %v1457, i64 64) nomerge, !dbg !128
  unreachable
bb_checked279:
  %v1458 = load i64, ptr %slot220, align 8
  %v1459 = load i64, ptr %slot27, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  store i64 %v1458, ptr %p1460, align 8, !alias.scope !3, !noalias !4
  %v1461 = load i64, ptr %slot22, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  %ld1463 = load i64, ptr %p1462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1463, ptr %slot222, align 8
  %v1464 = load i64, ptr %slot26, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %ld1466 = load i64, ptr %p1465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1466, ptr %slot223, align 8
  %v1467 = load i64, ptr %slot27, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  %ld1469 = load i64, ptr %p1468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1469, ptr %slot224, align 8
  %v1470 = load i64, ptr %slot35, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  %v1472 = load i64, ptr %slot222, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  %v1474 = load i64, ptr %slot223, align 8
  %v1475 = load i64, ptr %slot224, align 8
  %call1476 = call ptr @myl_native_bytes_view(ptr %p1471, ptr %p1473, i64 %v1474, i64 %v1475) nomerge, !dbg !130
  %calladdr1477 = ptrtoint ptr %call1476 to i64
  store i64 %calladdr1477, ptr %slot225, align 8
  %v1478 = load i64, ptr %slot225, align 8
  %cond1479 = icmp ne i64 %v1478, 0
  br i1 %cond1479, label %bb_success285, label %bb_failed285
bb_failed285:
  %v1480 = load i64, ptr %slot1, align 8
  %p1481 = inttoptr i64 %v1480 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1481) nomerge, !dbg !130
  unreachable
bb_success285:
  %v1482 = load i64, ptr %slot225, align 8
  %v1483 = load i64, ptr %slot26, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  store i64 %v1482, ptr %p1484, align 8, !alias.scope !3, !noalias !4
  %v1485 = load i64, ptr %slot26, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  %ld1487 = load i64, ptr %p1486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1487, ptr %slot226, align 8
  %v1488 = load i64, ptr %slot226, align 8
  %v1489 = load i64, ptr %slot18, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  store i64 %v1488, ptr %p1490, align 8, !alias.scope !3, !noalias !4
  %v1491 = load i64, ptr %slot18, align 8
  store i64 %v1491, ptr %slot227, align 8
  %v1492 = load i64, ptr %slot19, align 8
  store i64 %v1492, ptr %slot228, align 8
  %v1493 = load i64, ptr %slot227, align 8
  %v1494 = load i64, ptr %slot228, align 8
  %p1495 = inttoptr i64 %v1493 to ptr
  %p1496 = inttoptr i64 %v1494 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1496, ptr %p1495, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1497 = load i64, ptr %slot15, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  store i32 2, ptr %p1498, align 4, !alias.scope !3, !noalias !4
  %v1499 = load i64, ptr %slot14, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  store i32 1, ptr %p1500, align 4, !alias.scope !3, !noalias !4
  %v1501 = load i64, ptr %slot17, align 8
  store i64 %v1501, ptr %slot229, align 8
  %v1502 = load i64, ptr %slot19, align 8
  store i64 %v1502, ptr %slot230, align 8
  %v1503 = load i64, ptr %slot230, align 8
  %v1504 = load i64, ptr %slot229, align 8
  %p1505 = inttoptr i64 %v1503 to ptr
  %p1506 = inttoptr i64 %v1504 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1506, ptr %p1505, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1507 = load i64, ptr %slot13, align 8
  %p1508 = inttoptr i64 %v1507 to ptr
  store i32 2, ptr %p1508, align 4, !alias.scope !3, !noalias !4
  %v1509 = load i64, ptr %slot15, align 8
  %p1510 = inttoptr i64 %v1509 to ptr
  %ld1511 = load i32, ptr %p1510, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1511, ptr %slot231, align 8
  %v1512 = load i32, ptr %slot231, align 8
  %v1513 = load i64, ptr %slot13, align 8
  %p1514 = inttoptr i64 %v1513 to ptr
  store i32 %v1512, ptr %p1514, align 4, !alias.scope !3, !noalias !4
  %v1515 = load i64, ptr %slot14, align 8
  %p1516 = inttoptr i64 %v1515 to ptr
  store i32 0, ptr %p1516, align 4, !alias.scope !3, !noalias !4
  %v1517 = load i64, ptr %slot12, align 8
  %p1518 = inttoptr i64 %v1517 to ptr
  store i32 1, ptr %p1518, align 4, !alias.scope !3, !noalias !4
  %v1519 = load i64, ptr %slot229, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  %ld1521 = load i64, ptr %p1520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1521, ptr %slot232, align 8
  %v1522 = load i64, ptr %slot232, align 8
  %v1523 = load i64, ptr %slot26, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i64 %v1522, ptr %p1524, align 8, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot26, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %ld1527 = load i64, ptr %p1526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1527, ptr %slot233, align 8
  %v1528 = load i64, ptr %slot233, align 8
  %v1529 = load i64, ptr %slot18, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  store i64 %v1528, ptr %p1530, align 8, !alias.scope !3, !noalias !4
  %v1531 = load i64, ptr %slot18, align 8
  store i64 %v1531, ptr %slot234, align 8
  %v1532 = load i64, ptr %slot12, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  %ld1534 = load i32, ptr %p1533, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1534, ptr %slot235, align 8
  %v1535 = load i64, ptr %slot13, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  %ld1537 = load i32, ptr %p1536, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1537, ptr %slot236, align 8
  %v1538 = load i32, ptr %slot236, align 8
  %op1539 = and i32 %v1538, 24
  store i32 %op1539, ptr %slot236, align 8
  %v1540 = load i32, ptr %slot236, align 8
  %cmp1541 = icmp eq i32 %v1540, 0
  %cv1542 = zext i1 %cmp1541 to i32
  store i32 %cv1542, ptr %slot237, align 8
  %v1543 = load i32, ptr %slot235, align 8
  %v1544 = load i32, ptr %slot237, align 8
  %op1545 = and i32 %v1543, %v1544
  store i32 %op1545, ptr %slot238, align 8
  %v1546 = load i32, ptr %slot238, align 8
  %cv1547 = zext i32 %v1546 to i64
  %cond1548 = icmp ne i64 %cv1547, 0
  br i1 %cond1548, label %bb_rctake302, label %bb_rccopy302
bb_rctake302:
  %v1549 = load i64, ptr %slot19, align 8
  store i64 %v1549, ptr %slot239, align 8
  %v1550 = load i64, ptr %slot36, align 8
  store i64 %v1550, ptr %slot240, align 8
  %v1551 = load i64, ptr %slot234, align 8
  %v1552 = load i64, ptr %slot239, align 8
  %op1553 = sub i64 %v1551, %v1552
  store i64 %op1553, ptr %slot241, align 8
  %v1554 = load i64, ptr %slot239, align 8
  %v1555 = load i64, ptr %slot234, align 8
  %op1556 = sub i64 %v1554, %v1555
  store i64 %op1556, ptr %slot242, align 8
  %v1557 = load i64, ptr %slot241, align 8
  %cmp1558 = icmp ult i64 %v1557, 8
  %cv1559 = zext i1 %cmp1558 to i32
  store i32 %cv1559, ptr %slot243, align 8
  %v1560 = load i64, ptr %slot242, align 8
  %cmp1561 = icmp ult i64 %v1560, 8
  %cv1562 = zext i1 %cmp1561 to i32
  store i32 %cv1562, ptr %slot244, align 8
  %v1563 = load i32, ptr %slot243, align 8
  %v1564 = load i32, ptr %slot244, align 8
  %op1565 = or i32 %v1563, %v1564
  store i32 %op1565, ptr %slot245, align 8
  %v1566 = load i32, ptr %slot245, align 8
  %cv1567 = zext i32 %v1566 to i64
  %cond1568 = icmp ne i64 %cv1567, 0
  br i1 %cond1568, label %bb_rcmoveslow311, label %bb_rcmovecheck311
bb_rcmovecheck311:
  %v1569 = load i64, ptr %slot234, align 8
  %p1571 = inttoptr i64 %v1569 to ptr
  %gep1572 = getelementptr i8, ptr %p1571, i64 0
  %op1570 = ptrtoint ptr %gep1572 to i64
  store i64 %op1570, ptr %slot246, align 8
  %v1573 = load i64, ptr %slot246, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  %ld1575 = load i64, ptr %p1574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1575, ptr %slot247, align 8
  %v1576 = load i64, ptr %slot247, align 8
  %cmp1577 = icmp ne i64 %v1576, 0
  %cv1578 = zext i1 %cmp1577 to i32
  store i32 %cv1578, ptr %slot248, align 8
  %v1579 = load i32, ptr %slot248, align 8
  %cv1580 = zext i32 %v1579 to i64
  %cond1581 = icmp ne i64 %cv1580, 0
  br i1 %cond1581, label %bb_rcmoveheader319, label %bb_rcmovenext319
bb_rcmoveheader319:
  %v1582 = load i64, ptr %slot247, align 8
  %op1583 = sub i64 %v1582, 16
  store i64 %op1583, ptr %slot249, align 8
  %v1584 = load i64, ptr %slot247, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %rgep1586 = getelementptr i8, ptr %p1585, i64 -16
  %ld1587 = load i64, ptr %rgep1586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1587, ptr %slot250, align 8
  %v1588 = load i64, ptr %slot250, align 8
  %op1589 = and i64 %v1588, 5764607523034234881
  store i64 %op1589, ptr %slot251, align 8
  %v1590 = load i64, ptr %slot251, align 8
  %cmp1591 = icmp ne i64 %v1590, 0
  %cv1592 = zext i1 %cmp1591 to i32
  store i32 %cv1592, ptr %slot252, align 8
  %v1593 = load i32, ptr %slot252, align 8
  %cv1594 = zext i32 %v1593 to i64
  %cond1595 = icmp ne i64 %cv1594, 0
  br i1 %cond1595, label %bb_rcmoveslow311, label %bb_rcmovenext319
bb_rcmovenext319:
  %v1596 = load i64, ptr %slot234, align 8
  %v1597 = load i64, ptr %slot239, align 8
  %p1598 = inttoptr i64 %v1596 to ptr
  %p1599 = inttoptr i64 %v1597 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1599, ptr %p1598, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1600 = load i64, ptr %slot234, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  store i64 0, ptr %p1601, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved311
bb_rcmoveslow311:
  %v1602 = load i64, ptr %slot35, align 8
  %v1603 = load i64, ptr %slot239, align 8
  %v1604 = load i64, ptr %slot234, align 8
  %v1605 = load i64, ptr %slot240, align 8
  %cv1606 = trunc i64 %v1605 to i32
  %call1607 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v1602, i64 %v1603, i64 %v1604, i32 %cv1606) nomerge, !dbg !132
  store i32 %call1607, ptr %slot253, align 8
  %v1608 = load i32, ptr %slot253, align 8
  %cv1609 = zext i32 %v1608 to i64
  %cond1610 = icmp ne i64 %cv1609, 0
  br i1 %cond1610, label %bb_rcsuccess326, label %bb_rcfailure326
bb_rcfailure326:
  %v1611 = load i64, ptr %slot35, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %call1613 = call i32 @myl_rc_take_failure(ptr %p1612) nomerge, !dbg !132
  store i32 %call1613, ptr %slot254, align 8
  %v1614 = load i64, ptr %slot1, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  %v1616 = load i32, ptr %slot254, align 8
  %call1617 = call i32 @myl_qbe_rc_status(ptr %p1615, i32 %v1616) nomerge, !dbg !132
  store i32 %call1617, ptr %slot255, align 8
  br label %bb_failure
bb_rcsuccess326:
  br label %bb_rcmoved311
bb_rcmoved311:
  %v1618 = load i64, ptr %slot12, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i32 0, ptr %p1619, align 4, !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot15, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  store i32 2, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot14, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 1, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared302
bb_rccopy302:
  %v1624 = load i64, ptr %slot19, align 8
  store i64 %v1624, ptr %slot256, align 8
  %v1625 = load i64, ptr %slot36, align 8
  store i64 %v1625, ptr %slot257, align 8
  %v1626 = load i64, ptr %slot234, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  %ld1628 = load i64, ptr %p1627, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1628, ptr %slot258, align 8
  %v1629 = load i64, ptr %slot258, align 8
  %cmp1630 = icmp ne i64 %v1629, 0
  %cv1631 = zext i1 %cmp1630 to i32
  store i32 %cv1631, ptr %slot259, align 8
  %v1632 = load i32, ptr %slot259, align 8
  %cv1633 = zext i32 %v1632 to i64
  %cond1634 = icmp ne i64 %cv1633, 0
  br i1 %cond1634, label %bb_rcgnn335, label %bb_rcgplain335
bb_rcgnn335:
  %v1635 = load i64, ptr %slot258, align 8
  %op1636 = sub i64 %v1635, 16
  store i64 %op1636, ptr %slot260, align 8
  %v1637 = load i64, ptr %slot258, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  %rgep1639 = getelementptr i8, ptr %p1638, i64 -16
  %ld1640 = load i64, ptr %rgep1639, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1640, ptr %slot261, align 8
  %v1641 = load i64, ptr %slot261, align 8
  %op1642 = and i64 %v1641, 4611686018427387906
  store i64 %op1642, ptr %slot262, align 8
  %v1643 = load i64, ptr %slot262, align 8
  %cmp1644 = icmp ne i64 %v1643, 0
  %cv1645 = zext i1 %cmp1644 to i32
  store i32 %cv1645, ptr %slot263, align 8
  %v1646 = load i32, ptr %slot263, align 8
  %cv1647 = zext i32 %v1646 to i64
  %cond1648 = icmp ne i64 %cv1647, 0
  br i1 %cond1648, label %bb_rcgspecial335, label %bb_rcginc335
bb_rcginc335:
  %v1649 = load i64, ptr %slot258, align 8
  %op1650 = sub i64 %v1649, 32
  store i64 %op1650, ptr %slot264, align 8
  %v1651 = load i64, ptr %slot258, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  %rgep1653 = getelementptr i8, ptr %p1652, i64 -32
  %ld1654 = load i64, ptr %rgep1653, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1654, ptr %slot265, align 8
  %v1655 = load i64, ptr %slot265, align 8
  %op1656 = add i64 %v1655, 1
  store i64 %op1656, ptr %slot266, align 8
  %v1657 = load i64, ptr %slot266, align 8
  %cmp1658 = icmp eq i64 %v1657, 0
  %cv1659 = zext i1 %cmp1658 to i32
  store i32 %cv1659, ptr %slot267, align 8
  %v1660 = load i32, ptr %slot267, align 8
  %cv1661 = zext i32 %v1660 to i64
  %cond1662 = icmp ne i64 %cv1661, 0
  br i1 %cond1662, label %bb_rcglimit335, label %bb_rcgcapacity335
bb_rcglimit335:
  %v1663 = load i64, ptr %slot1, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  %call1665 = call i32 @myl_qbe_rc_status(ptr %p1664, i32 2) nomerge, !dbg !132
  store i32 %call1665, ptr %slot268, align 8
  br label %bb_failure
bb_rcgcapacity335:
  %v1666 = load i64, ptr %slot266, align 8
  %v1667 = load i64, ptr %slot258, align 8
  %p1668 = inttoptr i64 %v1667 to ptr
  %rgep1669 = getelementptr i8, ptr %p1668, i64 -32
  store i64 %v1666, ptr %rgep1669, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain335
bb_rcgspecial335:
  %v1670 = load i64, ptr %slot261, align 8
  %op1671 = and i64 %v1670, 4611686018427387904
  store i64 %op1671, ptr %slot269, align 8
  %v1672 = load i64, ptr %slot269, align 8
  %cmp1673 = icmp ne i64 %v1672, 0
  %cv1674 = zext i1 %cmp1673 to i32
  store i32 %cv1674, ptr %slot270, align 8
  %v1675 = load i32, ptr %slot270, align 8
  %cv1676 = zext i32 %v1675 to i64
  %cond1677 = icmp ne i64 %cv1676, 0
  br i1 %cond1677, label %bb_rcgslow335, label %bb_rcgplain335
bb_rcgslow335:
  %v1678 = load i64, ptr %slot35, align 8
  %v1679 = load i64, ptr %slot256, align 8
  %v1680 = load i64, ptr %slot234, align 8
  %v1681 = load i64, ptr %slot257, align 8
  %cv1682 = trunc i64 %v1681 to i32
  %call1683 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v1678, i64 %v1679, i64 %v1680, i32 %cv1682) nomerge, !dbg !132
  store i32 %call1683, ptr %slot271, align 8
  %v1684 = load i32, ptr %slot271, align 8
  %cv1685 = zext i32 %v1684 to i64
  %cond1686 = icmp ne i64 %cv1685, 0
  br i1 %cond1686, label %bb_rcsuccess349, label %bb_rcfailure349
bb_rcfailure349:
  %v1687 = load i64, ptr %slot35, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  %call1689 = call i32 @myl_rc_take_failure(ptr %p1688) nomerge, !dbg !132
  store i32 %call1689, ptr %slot272, align 8
  %v1690 = load i64, ptr %slot1, align 8
  %p1691 = inttoptr i64 %v1690 to ptr
  %v1692 = load i32, ptr %slot272, align 8
  %call1693 = call i32 @myl_qbe_rc_status(ptr %p1691, i32 %v1692) nomerge, !dbg !132
  store i32 %call1693, ptr %slot273, align 8
  br label %bb_failure
bb_rcsuccess349:
  br label %bb_rcgdone335
bb_rcgplain335:
  %v1694 = load i64, ptr %slot258, align 8
  %v1695 = load i64, ptr %slot256, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  store i64 %v1694, ptr %p1696, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone335
bb_rcgdone335:
  %v1697 = load i64, ptr %slot15, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  store i32 2, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  %v1699 = load i64, ptr %slot14, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i32 1, ptr %p1700, align 4, !alias.scope !3, !noalias !4
  %v1701 = load i64, ptr %slot12, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  %ld1703 = load i32, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1703, ptr %slot274, align 8
  %v1704 = load i32, ptr %slot274, align 8
  %cv1705 = zext i32 %v1704 to i64
  %cond1706 = icmp ne i64 %cv1705, 0
  br i1 %cond1706, label %bb_rcslotdrop356, label %bb_rcslotdone356
bb_rcslotdrop356:
  %v1707 = load i64, ptr %slot12, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  store i32 0, ptr %p1708, align 4, !alias.scope !3, !noalias !4
  %v1709 = load i64, ptr %slot17, align 8
  store i64 %v1709, ptr %slot275, align 8
  %v1710 = load i64, ptr %slot13, align 8
  %p1711 = inttoptr i64 %v1710 to ptr
  %ld1712 = load i32, ptr %p1711, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1712, ptr %slot276, align 8
  %v1713 = load i32, ptr %slot276, align 8
  %op1714 = and i32 %v1713, 28
  store i32 %op1714, ptr %slot277, align 8
  %v1715 = load i32, ptr %slot277, align 8
  %cv1716 = zext i32 %v1715 to i64
  %cond1717 = icmp ne i64 %cv1716, 0
  br i1 %cond1717, label %bb_rcslotrole356, label %bb_rcslotowner356
bb_rcslotrole356:
  %v1718 = load i64, ptr %slot35, align 8
  store i64 %v1718, ptr %slot278, align 8
  %v1719 = load i64, ptr %slot275, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  %ld1721 = load i64, ptr %p1720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1721, ptr %slot279, align 8
  %v1722 = load i64, ptr %slot279, align 8
  %cmp1723 = icmp ne i64 %v1722, 0
  %cv1724 = zext i1 %cmp1723 to i32
  store i32 %cv1724, ptr %slot280, align 8
  %v1725 = load i32, ptr %slot280, align 8
  %cv1726 = zext i32 %v1725 to i64
  %cond1727 = icmp ne i64 %cv1726, 0
  br i1 %cond1727, label %bb_rcgnn372, label %bb_rcgdone372
bb_rcgnn372:
  %v1728 = load i64, ptr %slot279, align 8
  %op1729 = sub i64 %v1728, 16
  store i64 %op1729, ptr %slot281, align 8
  %v1730 = load i64, ptr %slot279, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  %rgep1732 = getelementptr i8, ptr %p1731, i64 -16
  %ld1733 = load i64, ptr %rgep1732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1733, ptr %slot282, align 8
  %v1734 = load i64, ptr %slot282, align 8
  %op1735 = and i64 %v1734, 4611686018427387906
  store i64 %op1735, ptr %slot283, align 8
  %v1736 = load i64, ptr %slot283, align 8
  %cmp1737 = icmp ne i64 %v1736, 0
  %cv1738 = zext i1 %cmp1737 to i32
  store i32 %cv1738, ptr %slot284, align 8
  %v1739 = load i32, ptr %slot284, align 8
  %cv1740 = zext i32 %v1739 to i64
  %cond1741 = icmp ne i64 %cv1740, 0
  br i1 %cond1741, label %bb_rcgclear372, label %bb_rcgcounted372
bb_rcgcounted372:
  %v1742 = load i64, ptr %slot279, align 8
  %op1743 = sub i64 %v1742, 24
  store i64 %op1743, ptr %slot285, align 8
  %v1744 = load i64, ptr %slot279, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  %rgep1746 = getelementptr i8, ptr %p1745, i64 -24
  %ld1747 = load i64, ptr %rgep1746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1747, ptr %slot286, align 8
  %v1748 = load i64, ptr %slot286, align 8
  %op1749 = sub i64 %v1748, 1
  store i64 %op1749, ptr %slot287, align 8
  %v1750 = load i64, ptr %slot287, align 8
  %cmp1751 = icmp eq i64 %v1750, 0
  %cv1752 = zext i1 %cmp1751 to i32
  store i32 %cv1752, ptr %slot288, align 8
  %v1753 = load i32, ptr %slot288, align 8
  %cv1754 = zext i32 %v1753 to i64
  %cond1755 = icmp ne i64 %cv1754, 0
  br i1 %cond1755, label %bb_rcglast372, label %bb_rcgdec372
bb_rcglast372:
  %v1756 = load i64, ptr %slot279, align 8
  %op1757 = sub i64 %v1756, 32
  store i64 %op1757, ptr %slot289, align 8
  %v1758 = load i64, ptr %slot279, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %rgep1760 = getelementptr i8, ptr %p1759, i64 -32
  %ld1761 = load i64, ptr %rgep1760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1761, ptr %slot290, align 8
  %v1762 = load i64, ptr %slot290, align 8
  %cmp1763 = icmp ne i64 %v1762, 0
  %cv1764 = zext i1 %cmp1763 to i32
  store i32 %cv1764, ptr %slot291, align 8
  %v1765 = load i32, ptr %slot291, align 8
  %cv1766 = zext i32 %v1765 to i64
  %cond1767 = icmp ne i64 %cv1766, 0
  br i1 %cond1767, label %bb_rcgdec372, label %bb_rcgslow372
bb_rcgslow372:
  %v1768 = load i64, ptr %slot278, align 8
  %v1769 = load i64, ptr %slot275, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1768, i64 %v1769) nomerge, !dbg !132
  br label %bb_rcgdone372
bb_rcgdec372:
  %v1770 = load i64, ptr %slot287, align 8
  %v1771 = load i64, ptr %slot279, align 8
  %p1772 = inttoptr i64 %v1771 to ptr
  %rgep1773 = getelementptr i8, ptr %p1772, i64 -24
  store i64 %v1770, ptr %rgep1773, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear372
bb_rcgclear372:
  %v1774 = load i64, ptr %slot275, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  store i64 0, ptr %p1775, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone372
bb_rcgdone372:
  br label %bb_rcslotdone356
bb_rcslotowner356:
  %v1776 = load i64, ptr %slot35, align 8
  store i64 %v1776, ptr %slot292, align 8
  %v1777 = load i64, ptr %slot275, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  %ld1779 = load i64, ptr %p1778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1779, ptr %slot293, align 8
  %v1780 = load i64, ptr %slot293, align 8
  %cmp1781 = icmp ne i64 %v1780, 0
  %cv1782 = zext i1 %cmp1781 to i32
  store i32 %cv1782, ptr %slot294, align 8
  %v1783 = load i32, ptr %slot294, align 8
  %cv1784 = zext i32 %v1783 to i64
  %cond1785 = icmp ne i64 %cv1784, 0
  br i1 %cond1785, label %bb_rcgnn387, label %bb_rcgdone387
bb_rcgnn387:
  %v1786 = load i64, ptr %slot293, align 8
  %op1787 = sub i64 %v1786, 16
  store i64 %op1787, ptr %slot295, align 8
  %v1788 = load i64, ptr %slot293, align 8
  %p1789 = inttoptr i64 %v1788 to ptr
  %rgep1790 = getelementptr i8, ptr %p1789, i64 -16
  %ld1791 = load i64, ptr %rgep1790, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1791, ptr %slot296, align 8
  %v1792 = load i64, ptr %slot296, align 8
  %op1793 = and i64 %v1792, 4611686018427387906
  store i64 %op1793, ptr %slot297, align 8
  %v1794 = load i64, ptr %slot297, align 8
  %cmp1795 = icmp ne i64 %v1794, 0
  %cv1796 = zext i1 %cmp1795 to i32
  store i32 %cv1796, ptr %slot298, align 8
  %v1797 = load i32, ptr %slot298, align 8
  %cv1798 = zext i32 %v1797 to i64
  %cond1799 = icmp ne i64 %cv1798, 0
  br i1 %cond1799, label %bb_rcgclear387, label %bb_rcgcounted387
bb_rcgcounted387:
  %v1800 = load i64, ptr %slot293, align 8
  %op1801 = sub i64 %v1800, 32
  store i64 %op1801, ptr %slot299, align 8
  %v1802 = load i64, ptr %slot293, align 8
  %p1803 = inttoptr i64 %v1802 to ptr
  %rgep1804 = getelementptr i8, ptr %p1803, i64 -32
  %ld1805 = load i64, ptr %rgep1804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1805, ptr %slot300, align 8
  %v1806 = load i64, ptr %slot300, align 8
  %op1807 = sub i64 %v1806, 1
  store i64 %op1807, ptr %slot301, align 8
  %v1808 = load i64, ptr %slot301, align 8
  %cmp1809 = icmp eq i64 %v1808, 0
  %cv1810 = zext i1 %cmp1809 to i32
  store i32 %cv1810, ptr %slot302, align 8
  %v1811 = load i32, ptr %slot302, align 8
  %cv1812 = zext i32 %v1811 to i64
  %cond1813 = icmp ne i64 %cv1812, 0
  br i1 %cond1813, label %bb_rcglast387, label %bb_rcgdec387
bb_rcglast387:
  %v1814 = load i64, ptr %slot293, align 8
  %op1815 = sub i64 %v1814, 24
  store i64 %op1815, ptr %slot303, align 8
  %v1816 = load i64, ptr %slot293, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  %rgep1818 = getelementptr i8, ptr %p1817, i64 -24
  %ld1819 = load i64, ptr %rgep1818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1819, ptr %slot304, align 8
  %v1820 = load i64, ptr %slot304, align 8
  %cmp1821 = icmp ne i64 %v1820, 0
  %cv1822 = zext i1 %cmp1821 to i32
  store i32 %cv1822, ptr %slot305, align 8
  %v1823 = load i32, ptr %slot305, align 8
  %cv1824 = zext i32 %v1823 to i64
  %cond1825 = icmp ne i64 %cv1824, 0
  br i1 %cond1825, label %bb_rcgdec387, label %bb_rcgslow387
bb_rcgslow387:
  %v1826 = load i64, ptr %slot292, align 8
  %v1827 = load i64, ptr %slot275, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1826, i64 %v1827) nomerge, !dbg !132
  br label %bb_rcgdone387
bb_rcgdec387:
  %v1828 = load i64, ptr %slot301, align 8
  %v1829 = load i64, ptr %slot293, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  %rgep1831 = getelementptr i8, ptr %p1830, i64 -32
  store i64 %v1828, ptr %rgep1831, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear387
bb_rcgclear387:
  %v1832 = load i64, ptr %slot275, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  store i64 0, ptr %p1833, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone387
bb_rcgdone387:
  br label %bb_rcslotdone356
bb_rcslotdone356:
  br label %bb_rcprepared302
bb_rcprepared302:
  %v1834 = load i64, ptr %slot8, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  %ld1836 = load i32, ptr %p1835, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1836, ptr %slot306, align 8
  %v1837 = load i32, ptr %slot306, align 8
  %cv1838 = zext i32 %v1837 to i64
  %cond1839 = icmp ne i64 %cv1838, 0
  br i1 %cond1839, label %bb_rcslotdrop394, label %bb_rcslotdone394
bb_rcslotdrop394:
  %v1840 = load i64, ptr %slot8, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  store i32 0, ptr %p1841, align 4, !alias.scope !3, !noalias !4
  %v1842 = load i64, ptr %slot23, align 8
  store i64 %v1842, ptr %slot307, align 8
  %v1843 = load i64, ptr %slot9, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  %ld1845 = load i32, ptr %p1844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1845, ptr %slot308, align 8
  %v1846 = load i32, ptr %slot308, align 8
  %op1847 = and i32 %v1846, 28
  store i32 %op1847, ptr %slot309, align 8
  %v1848 = load i32, ptr %slot309, align 8
  %cv1849 = zext i32 %v1848 to i64
  %cond1850 = icmp ne i64 %cv1849, 0
  br i1 %cond1850, label %bb_rcslotrole394, label %bb_rcslotowner394
bb_rcslotrole394:
  %v1851 = load i64, ptr %slot35, align 8
  store i64 %v1851, ptr %slot310, align 8
  %v1852 = load i64, ptr %slot307, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  %ld1854 = load i64, ptr %p1853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1854, ptr %slot311, align 8
  %v1855 = load i64, ptr %slot311, align 8
  %cmp1856 = icmp ne i64 %v1855, 0
  %cv1857 = zext i1 %cmp1856 to i32
  store i32 %cv1857, ptr %slot312, align 8
  %v1858 = load i32, ptr %slot312, align 8
  %cv1859 = zext i32 %v1858 to i64
  %cond1860 = icmp ne i64 %cv1859, 0
  br i1 %cond1860, label %bb_rcgnn410, label %bb_rcgdone410
bb_rcgnn410:
  %v1861 = load i64, ptr %slot311, align 8
  %op1862 = sub i64 %v1861, 16
  store i64 %op1862, ptr %slot313, align 8
  %v1863 = load i64, ptr %slot311, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  %rgep1865 = getelementptr i8, ptr %p1864, i64 -16
  %ld1866 = load i64, ptr %rgep1865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1866, ptr %slot314, align 8
  %v1867 = load i64, ptr %slot314, align 8
  %op1868 = and i64 %v1867, 4611686018427387906
  store i64 %op1868, ptr %slot315, align 8
  %v1869 = load i64, ptr %slot315, align 8
  %cmp1870 = icmp ne i64 %v1869, 0
  %cv1871 = zext i1 %cmp1870 to i32
  store i32 %cv1871, ptr %slot316, align 8
  %v1872 = load i32, ptr %slot316, align 8
  %cv1873 = zext i32 %v1872 to i64
  %cond1874 = icmp ne i64 %cv1873, 0
  br i1 %cond1874, label %bb_rcgclear410, label %bb_rcgcounted410
bb_rcgcounted410:
  %v1875 = load i64, ptr %slot311, align 8
  %op1876 = sub i64 %v1875, 24
  store i64 %op1876, ptr %slot317, align 8
  %v1877 = load i64, ptr %slot311, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %rgep1879 = getelementptr i8, ptr %p1878, i64 -24
  %ld1880 = load i64, ptr %rgep1879, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1880, ptr %slot318, align 8
  %v1881 = load i64, ptr %slot318, align 8
  %op1882 = sub i64 %v1881, 1
  store i64 %op1882, ptr %slot319, align 8
  %v1883 = load i64, ptr %slot319, align 8
  %cmp1884 = icmp eq i64 %v1883, 0
  %cv1885 = zext i1 %cmp1884 to i32
  store i32 %cv1885, ptr %slot320, align 8
  %v1886 = load i32, ptr %slot320, align 8
  %cv1887 = zext i32 %v1886 to i64
  %cond1888 = icmp ne i64 %cv1887, 0
  br i1 %cond1888, label %bb_rcglast410, label %bb_rcgdec410
bb_rcglast410:
  %v1889 = load i64, ptr %slot311, align 8
  %op1890 = sub i64 %v1889, 32
  store i64 %op1890, ptr %slot321, align 8
  %v1891 = load i64, ptr %slot311, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %rgep1893 = getelementptr i8, ptr %p1892, i64 -32
  %ld1894 = load i64, ptr %rgep1893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1894, ptr %slot322, align 8
  %v1895 = load i64, ptr %slot322, align 8
  %cmp1896 = icmp ne i64 %v1895, 0
  %cv1897 = zext i1 %cmp1896 to i32
  store i32 %cv1897, ptr %slot323, align 8
  %v1898 = load i32, ptr %slot323, align 8
  %cv1899 = zext i32 %v1898 to i64
  %cond1900 = icmp ne i64 %cv1899, 0
  br i1 %cond1900, label %bb_rcgdec410, label %bb_rcgslow410
bb_rcgslow410:
  %v1901 = load i64, ptr %slot310, align 8
  %v1902 = load i64, ptr %slot307, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1901, i64 %v1902) nomerge, !dbg !132
  br label %bb_rcgdone410
bb_rcgdec410:
  %v1903 = load i64, ptr %slot319, align 8
  %v1904 = load i64, ptr %slot311, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  %rgep1906 = getelementptr i8, ptr %p1905, i64 -24
  store i64 %v1903, ptr %rgep1906, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear410
bb_rcgclear410:
  %v1907 = load i64, ptr %slot307, align 8
  %p1908 = inttoptr i64 %v1907 to ptr
  store i64 0, ptr %p1908, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone410
bb_rcgdone410:
  br label %bb_rcslotdone394
bb_rcslotowner394:
  %v1909 = load i64, ptr %slot35, align 8
  store i64 %v1909, ptr %slot324, align 8
  %v1910 = load i64, ptr %slot307, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  %ld1912 = load i64, ptr %p1911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1912, ptr %slot325, align 8
  %v1913 = load i64, ptr %slot325, align 8
  %cmp1914 = icmp ne i64 %v1913, 0
  %cv1915 = zext i1 %cmp1914 to i32
  store i32 %cv1915, ptr %slot326, align 8
  %v1916 = load i32, ptr %slot326, align 8
  %cv1917 = zext i32 %v1916 to i64
  %cond1918 = icmp ne i64 %cv1917, 0
  br i1 %cond1918, label %bb_rcgnn425, label %bb_rcgdone425
bb_rcgnn425:
  %v1919 = load i64, ptr %slot325, align 8
  %op1920 = sub i64 %v1919, 16
  store i64 %op1920, ptr %slot327, align 8
  %v1921 = load i64, ptr %slot325, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  %rgep1923 = getelementptr i8, ptr %p1922, i64 -16
  %ld1924 = load i64, ptr %rgep1923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1924, ptr %slot328, align 8
  %v1925 = load i64, ptr %slot328, align 8
  %op1926 = and i64 %v1925, 4611686018427387906
  store i64 %op1926, ptr %slot329, align 8
  %v1927 = load i64, ptr %slot329, align 8
  %cmp1928 = icmp ne i64 %v1927, 0
  %cv1929 = zext i1 %cmp1928 to i32
  store i32 %cv1929, ptr %slot330, align 8
  %v1930 = load i32, ptr %slot330, align 8
  %cv1931 = zext i32 %v1930 to i64
  %cond1932 = icmp ne i64 %cv1931, 0
  br i1 %cond1932, label %bb_rcgclear425, label %bb_rcgcounted425
bb_rcgcounted425:
  %v1933 = load i64, ptr %slot325, align 8
  %op1934 = sub i64 %v1933, 32
  store i64 %op1934, ptr %slot331, align 8
  %v1935 = load i64, ptr %slot325, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  %rgep1937 = getelementptr i8, ptr %p1936, i64 -32
  %ld1938 = load i64, ptr %rgep1937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1938, ptr %slot332, align 8
  %v1939 = load i64, ptr %slot332, align 8
  %op1940 = sub i64 %v1939, 1
  store i64 %op1940, ptr %slot333, align 8
  %v1941 = load i64, ptr %slot333, align 8
  %cmp1942 = icmp eq i64 %v1941, 0
  %cv1943 = zext i1 %cmp1942 to i32
  store i32 %cv1943, ptr %slot334, align 8
  %v1944 = load i32, ptr %slot334, align 8
  %cv1945 = zext i32 %v1944 to i64
  %cond1946 = icmp ne i64 %cv1945, 0
  br i1 %cond1946, label %bb_rcglast425, label %bb_rcgdec425
bb_rcglast425:
  %v1947 = load i64, ptr %slot325, align 8
  %op1948 = sub i64 %v1947, 24
  store i64 %op1948, ptr %slot335, align 8
  %v1949 = load i64, ptr %slot325, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %rgep1951 = getelementptr i8, ptr %p1950, i64 -24
  %ld1952 = load i64, ptr %rgep1951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1952, ptr %slot336, align 8
  %v1953 = load i64, ptr %slot336, align 8
  %cmp1954 = icmp ne i64 %v1953, 0
  %cv1955 = zext i1 %cmp1954 to i32
  store i32 %cv1955, ptr %slot337, align 8
  %v1956 = load i32, ptr %slot337, align 8
  %cv1957 = zext i32 %v1956 to i64
  %cond1958 = icmp ne i64 %cv1957, 0
  br i1 %cond1958, label %bb_rcgdec425, label %bb_rcgslow425
bb_rcgslow425:
  %v1959 = load i64, ptr %slot324, align 8
  %v1960 = load i64, ptr %slot307, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1959, i64 %v1960) nomerge, !dbg !132
  br label %bb_rcgdone425
bb_rcgdec425:
  %v1961 = load i64, ptr %slot333, align 8
  %v1962 = load i64, ptr %slot325, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  %rgep1964 = getelementptr i8, ptr %p1963, i64 -32
  store i64 %v1961, ptr %rgep1964, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear425
bb_rcgclear425:
  %v1965 = load i64, ptr %slot307, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  store i64 0, ptr %p1966, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone425
bb_rcgdone425:
  br label %bb_rcslotdone394
bb_rcslotdone394:
  %v1967 = load i64, ptr %slot23, align 8
  store i64 %v1967, ptr %slot338, align 8
  %v1968 = load i64, ptr %slot19, align 8
  store i64 %v1968, ptr %slot339, align 8
  %v1969 = load i64, ptr %slot339, align 8
  %v1970 = load i64, ptr %slot338, align 8
  %p1971 = inttoptr i64 %v1969 to ptr
  %p1972 = inttoptr i64 %v1970 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1972, ptr %p1971, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1973 = load i64, ptr %slot14, align 8
  %p1974 = inttoptr i64 %v1973 to ptr
  store i32 0, ptr %p1974, align 4, !alias.scope !3, !noalias !4
  %v1975 = load i64, ptr %slot9, align 8
  %p1976 = inttoptr i64 %v1975 to ptr
  store i32 2, ptr %p1976, align 4, !alias.scope !3, !noalias !4
  %v1977 = load i64, ptr %slot15, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  %ld1979 = load i32, ptr %p1978, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1979, ptr %slot340, align 8
  %v1980 = load i32, ptr %slot340, align 8
  %v1981 = load i64, ptr %slot9, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  store i32 %v1980, ptr %p1982, align 4, !alias.scope !3, !noalias !4
  %v1983 = load i64, ptr %slot8, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  store i32 1, ptr %p1984, align 4, !alias.scope !3, !noalias !4
  %v1985 = load i64, ptr %slot6, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  %ld1987 = load i32, ptr %p1986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1987, ptr %slot341, align 8
  %v1988 = load i32, ptr %slot341, align 8
  %cv1989 = zext i32 %v1988 to i64
  %cond1990 = icmp ne i64 %cv1989, 0
  br i1 %cond1990, label %bb_rcslotdrop438, label %bb_rcslotdone438
bb_rcslotdrop438:
  %v1991 = load i64, ptr %slot6, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  store i32 0, ptr %p1992, align 4, !alias.scope !3, !noalias !4
  %v1993 = load i64, ptr %slot22, align 8
  store i64 %v1993, ptr %slot342, align 8
  %v1994 = load i64, ptr %slot7, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  %ld1996 = load i32, ptr %p1995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1996, ptr %slot343, align 8
  %v1997 = load i32, ptr %slot343, align 8
  %op1998 = and i32 %v1997, 28
  store i32 %op1998, ptr %slot344, align 8
  %v1999 = load i32, ptr %slot344, align 8
  %cv2000 = zext i32 %v1999 to i64
  %cond2001 = icmp ne i64 %cv2000, 0
  br i1 %cond2001, label %bb_rcslotrole438, label %bb_rcslotowner438
bb_rcslotrole438:
  %v2002 = load i64, ptr %slot35, align 8
  store i64 %v2002, ptr %slot345, align 8
  %v2003 = load i64, ptr %slot342, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  %ld2005 = load i64, ptr %p2004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2005, ptr %slot346, align 8
  %v2006 = load i64, ptr %slot346, align 8
  %cmp2007 = icmp ne i64 %v2006, 0
  %cv2008 = zext i1 %cmp2007 to i32
  store i32 %cv2008, ptr %slot347, align 8
  %v2009 = load i32, ptr %slot347, align 8
  %cv2010 = zext i32 %v2009 to i64
  %cond2011 = icmp ne i64 %cv2010, 0
  br i1 %cond2011, label %bb_rcgnn454, label %bb_rcgdone454
bb_rcgnn454:
  %v2012 = load i64, ptr %slot346, align 8
  %op2013 = sub i64 %v2012, 16
  store i64 %op2013, ptr %slot348, align 8
  %v2014 = load i64, ptr %slot346, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  %rgep2016 = getelementptr i8, ptr %p2015, i64 -16
  %ld2017 = load i64, ptr %rgep2016, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2017, ptr %slot349, align 8
  %v2018 = load i64, ptr %slot349, align 8
  %op2019 = and i64 %v2018, 4611686018427387906
  store i64 %op2019, ptr %slot350, align 8
  %v2020 = load i64, ptr %slot350, align 8
  %cmp2021 = icmp ne i64 %v2020, 0
  %cv2022 = zext i1 %cmp2021 to i32
  store i32 %cv2022, ptr %slot351, align 8
  %v2023 = load i32, ptr %slot351, align 8
  %cv2024 = zext i32 %v2023 to i64
  %cond2025 = icmp ne i64 %cv2024, 0
  br i1 %cond2025, label %bb_rcgclear454, label %bb_rcgcounted454
bb_rcgcounted454:
  %v2026 = load i64, ptr %slot346, align 8
  %op2027 = sub i64 %v2026, 24
  store i64 %op2027, ptr %slot352, align 8
  %v2028 = load i64, ptr %slot346, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  %rgep2030 = getelementptr i8, ptr %p2029, i64 -24
  %ld2031 = load i64, ptr %rgep2030, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2031, ptr %slot353, align 8
  %v2032 = load i64, ptr %slot353, align 8
  %op2033 = sub i64 %v2032, 1
  store i64 %op2033, ptr %slot354, align 8
  %v2034 = load i64, ptr %slot354, align 8
  %cmp2035 = icmp eq i64 %v2034, 0
  %cv2036 = zext i1 %cmp2035 to i32
  store i32 %cv2036, ptr %slot355, align 8
  %v2037 = load i32, ptr %slot355, align 8
  %cv2038 = zext i32 %v2037 to i64
  %cond2039 = icmp ne i64 %cv2038, 0
  br i1 %cond2039, label %bb_rcglast454, label %bb_rcgdec454
bb_rcglast454:
  %v2040 = load i64, ptr %slot346, align 8
  %op2041 = sub i64 %v2040, 32
  store i64 %op2041, ptr %slot356, align 8
  %v2042 = load i64, ptr %slot346, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  %rgep2044 = getelementptr i8, ptr %p2043, i64 -32
  %ld2045 = load i64, ptr %rgep2044, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2045, ptr %slot357, align 8
  %v2046 = load i64, ptr %slot357, align 8
  %cmp2047 = icmp ne i64 %v2046, 0
  %cv2048 = zext i1 %cmp2047 to i32
  store i32 %cv2048, ptr %slot358, align 8
  %v2049 = load i32, ptr %slot358, align 8
  %cv2050 = zext i32 %v2049 to i64
  %cond2051 = icmp ne i64 %cv2050, 0
  br i1 %cond2051, label %bb_rcgdec454, label %bb_rcgslow454
bb_rcgslow454:
  %v2052 = load i64, ptr %slot345, align 8
  %v2053 = load i64, ptr %slot342, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2052, i64 %v2053) nomerge, !dbg !132
  br label %bb_rcgdone454
bb_rcgdec454:
  %v2054 = load i64, ptr %slot354, align 8
  %v2055 = load i64, ptr %slot346, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  %rgep2057 = getelementptr i8, ptr %p2056, i64 -24
  store i64 %v2054, ptr %rgep2057, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear454
bb_rcgclear454:
  %v2058 = load i64, ptr %slot342, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  store i64 0, ptr %p2059, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone454
bb_rcgdone454:
  br label %bb_rcslotdone438
bb_rcslotowner438:
  %v2060 = load i64, ptr %slot35, align 8
  store i64 %v2060, ptr %slot359, align 8
  %v2061 = load i64, ptr %slot342, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %ld2063 = load i64, ptr %p2062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2063, ptr %slot360, align 8
  %v2064 = load i64, ptr %slot360, align 8
  %cmp2065 = icmp ne i64 %v2064, 0
  %cv2066 = zext i1 %cmp2065 to i32
  store i32 %cv2066, ptr %slot361, align 8
  %v2067 = load i32, ptr %slot361, align 8
  %cv2068 = zext i32 %v2067 to i64
  %cond2069 = icmp ne i64 %cv2068, 0
  br i1 %cond2069, label %bb_rcgnn469, label %bb_rcgdone469
bb_rcgnn469:
  %v2070 = load i64, ptr %slot360, align 8
  %op2071 = sub i64 %v2070, 16
  store i64 %op2071, ptr %slot362, align 8
  %v2072 = load i64, ptr %slot360, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  %rgep2074 = getelementptr i8, ptr %p2073, i64 -16
  %ld2075 = load i64, ptr %rgep2074, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2075, ptr %slot363, align 8
  %v2076 = load i64, ptr %slot363, align 8
  %op2077 = and i64 %v2076, 4611686018427387906
  store i64 %op2077, ptr %slot364, align 8
  %v2078 = load i64, ptr %slot364, align 8
  %cmp2079 = icmp ne i64 %v2078, 0
  %cv2080 = zext i1 %cmp2079 to i32
  store i32 %cv2080, ptr %slot365, align 8
  %v2081 = load i32, ptr %slot365, align 8
  %cv2082 = zext i32 %v2081 to i64
  %cond2083 = icmp ne i64 %cv2082, 0
  br i1 %cond2083, label %bb_rcgclear469, label %bb_rcgcounted469
bb_rcgcounted469:
  %v2084 = load i64, ptr %slot360, align 8
  %op2085 = sub i64 %v2084, 32
  store i64 %op2085, ptr %slot366, align 8
  %v2086 = load i64, ptr %slot360, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  %rgep2088 = getelementptr i8, ptr %p2087, i64 -32
  %ld2089 = load i64, ptr %rgep2088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2089, ptr %slot367, align 8
  %v2090 = load i64, ptr %slot367, align 8
  %op2091 = sub i64 %v2090, 1
  store i64 %op2091, ptr %slot368, align 8
  %v2092 = load i64, ptr %slot368, align 8
  %cmp2093 = icmp eq i64 %v2092, 0
  %cv2094 = zext i1 %cmp2093 to i32
  store i32 %cv2094, ptr %slot369, align 8
  %v2095 = load i32, ptr %slot369, align 8
  %cv2096 = zext i32 %v2095 to i64
  %cond2097 = icmp ne i64 %cv2096, 0
  br i1 %cond2097, label %bb_rcglast469, label %bb_rcgdec469
bb_rcglast469:
  %v2098 = load i64, ptr %slot360, align 8
  %op2099 = sub i64 %v2098, 24
  store i64 %op2099, ptr %slot370, align 8
  %v2100 = load i64, ptr %slot360, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  %rgep2102 = getelementptr i8, ptr %p2101, i64 -24
  %ld2103 = load i64, ptr %rgep2102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2103, ptr %slot371, align 8
  %v2104 = load i64, ptr %slot371, align 8
  %cmp2105 = icmp ne i64 %v2104, 0
  %cv2106 = zext i1 %cmp2105 to i32
  store i32 %cv2106, ptr %slot372, align 8
  %v2107 = load i32, ptr %slot372, align 8
  %cv2108 = zext i32 %v2107 to i64
  %cond2109 = icmp ne i64 %cv2108, 0
  br i1 %cond2109, label %bb_rcgdec469, label %bb_rcgslow469
bb_rcgslow469:
  %v2110 = load i64, ptr %slot359, align 8
  %v2111 = load i64, ptr %slot342, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2110, i64 %v2111) nomerge, !dbg !132
  br label %bb_rcgdone469
bb_rcgdec469:
  %v2112 = load i64, ptr %slot368, align 8
  %v2113 = load i64, ptr %slot360, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %rgep2115 = getelementptr i8, ptr %p2114, i64 -32
  store i64 %v2112, ptr %rgep2115, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear469
bb_rcgclear469:
  %v2116 = load i64, ptr %slot342, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  store i64 0, ptr %p2117, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone469
bb_rcgdone469:
  br label %bb_rcslotdone438
bb_rcslotdone438:
  %v2118 = load i64, ptr %slot20, align 8
  %p2119 = inttoptr i64 %v2118 to ptr
  %ld2120 = load i64, ptr %p2119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2120, ptr %slot373, align 8
  %v2121 = load i64, ptr %slot373, align 8
  %v2122 = load i64, ptr %slot29, align 8
  %p2123 = inttoptr i64 %v2121 to ptr
  %p2124 = inttoptr i64 %v2122 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2124, ptr %p2123, i64 392, i1 false), !alias.scope !10000000
  %v2125 = load i64, ptr %slot29, align 8
  %v2126 = load i64, ptr %slot26, align 8
  %p2127 = inttoptr i64 %v2126 to ptr
  store i64 %v2125, ptr %p2127, align 8, !alias.scope !3, !noalias !4
  %v2128 = load i64, ptr %slot26, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  %ld2130 = load i64, ptr %p2129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2130, ptr %slot374, align 8
  %v2131 = load i64, ptr %slot374, align 8
  %op2132 = add i64 %v2131, 0
  store i64 %op2132, ptr %slot375, align 8
  %v2133 = load i64, ptr %slot375, align 8
  %v2134 = load i64, ptr %slot26, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  store i64 %v2133, ptr %p2135, align 8, !alias.scope !3, !noalias !4
  %v2136 = load i64, ptr %slot10, align 8
  %p2137 = inttoptr i64 %v2136 to ptr
  %ld2138 = load i32, ptr %p2137, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2138, ptr %slot376, align 8
  %v2139 = load i32, ptr %slot376, align 8
  %cv2140 = zext i32 %v2139 to i64
  %cond2141 = icmp ne i64 %cv2140, 0
  br i1 %cond2141, label %bb_rcslotdrop478, label %bb_rcslotdone478
bb_rcslotdrop478:
  %v2142 = load i64, ptr %slot10, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  store i32 0, ptr %p2143, align 4, !alias.scope !3, !noalias !4
  %v2144 = load i64, ptr %slot24, align 8
  store i64 %v2144, ptr %slot377, align 8
  %v2145 = load i64, ptr %slot11, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  %ld2147 = load i32, ptr %p2146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2147, ptr %slot378, align 8
  %v2148 = load i32, ptr %slot378, align 8
  %op2149 = and i32 %v2148, 28
  store i32 %op2149, ptr %slot379, align 8
  %v2150 = load i32, ptr %slot379, align 8
  %cv2151 = zext i32 %v2150 to i64
  %cond2152 = icmp ne i64 %cv2151, 0
  br i1 %cond2152, label %bb_rcslotrole478, label %bb_rcslotowner478
bb_rcslotrole478:
  %v2153 = load i64, ptr %slot35, align 8
  store i64 %v2153, ptr %slot380, align 8
  %v2154 = load i64, ptr %slot380, align 8
  %v2155 = load i64, ptr %slot377, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2154, i64 %v2155) nomerge, !dbg !134
  br label %bb_rcslotdone478
bb_rcslotowner478:
  %v2156 = load i64, ptr %slot35, align 8
  store i64 %v2156, ptr %slot381, align 8
  %v2157 = load i64, ptr %slot381, align 8
  %v2158 = load i64, ptr %slot377, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2157, i64 %v2158) nomerge, !dbg !134
  br label %bb_rcslotdone478
bb_rcslotdone478:
  %v2159 = load i64, ptr %slot20, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  %ld2161 = load i64, ptr %p2160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2161, ptr %slot382, align 8
  %v2162 = load i64, ptr %slot382, align 8
  %op2163 = add i64 %v2162, 0
  store i64 %op2163, ptr %slot383, align 8
  %v2164 = load i64, ptr %slot24, align 8
  store i64 %v2164, ptr %slot384, align 8
  %v2165 = load i64, ptr %slot383, align 8
  %v2166 = load i64, ptr %slot384, align 8
  %p2167 = inttoptr i64 %v2165 to ptr
  %p2168 = inttoptr i64 %v2166 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2168, ptr %p2167, i64 208, i1 false), !alias.scope !10000000
  %v2169 = load i64, ptr %slot383, align 8
  %p2170 = inttoptr i64 %v2169 to ptr
  call void @llvm.memset.p0.i64(ptr %p2170, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !134
  %v2171 = load i64, ptr %slot10, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  store i32 1, ptr %p2172, align 4, !alias.scope !3, !noalias !4
  %v2173 = load i64, ptr %slot24, align 8
  %v2174 = load i64, ptr %slot26, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i64 %v2173, ptr %p2175, align 8, !alias.scope !3, !noalias !4
  %v2176 = load i64, ptr %slot23, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i64, ptr %p2177, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2178, ptr %slot385, align 8
  %v2179 = load i64, ptr %slot385, align 8
  %v2180 = load i64, ptr %slot27, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i64 %v2179, ptr %p2181, align 8, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot26, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  %ld2184 = load i64, ptr %p2183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2184, ptr %slot386, align 8
  %v2185 = load i64, ptr %slot27, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %ld2187 = load i64, ptr %p2186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2187, ptr %slot387, align 8
  %v2188 = load i64, ptr %slot1, align 8
  %v2189 = load i64, ptr %slot386, align 8
  %v2190 = load i64, ptr %slot387, align 8
  %call2191 = call i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64 %v2188, i64 %v2189, i64 %v2190) nomerge, !dbg !136
  store i64 %call2191, ptr %slot388, align 8
  %v2192 = load i64, ptr %slot388, align 8
  %v2193 = load i64, ptr %slot26, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  store i64 %v2192, ptr %p2194, align 8, !alias.scope !3, !noalias !4
  %v2195 = load i64, ptr %slot12, align 8
  %p2196 = inttoptr i64 %v2195 to ptr
  %ld2197 = load i32, ptr %p2196, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2197, ptr %slot389, align 8
  %v2198 = load i32, ptr %slot389, align 8
  %cv2199 = zext i32 %v2198 to i64
  %cond2200 = icmp ne i64 %cv2199, 0
  br i1 %cond2200, label %bb_rcslotdrop495, label %bb_rcslotdone495
bb_rcslotdrop495:
  %v2201 = load i64, ptr %slot12, align 8
  %p2202 = inttoptr i64 %v2201 to ptr
  store i32 0, ptr %p2202, align 4, !alias.scope !3, !noalias !4
  %v2203 = load i64, ptr %slot17, align 8
  store i64 %v2203, ptr %slot390, align 8
  %v2204 = load i64, ptr %slot13, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  %ld2206 = load i32, ptr %p2205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2206, ptr %slot391, align 8
  %v2207 = load i32, ptr %slot391, align 8
  %op2208 = and i32 %v2207, 28
  store i32 %op2208, ptr %slot392, align 8
  %v2209 = load i32, ptr %slot392, align 8
  %cv2210 = zext i32 %v2209 to i64
  %cond2211 = icmp ne i64 %cv2210, 0
  br i1 %cond2211, label %bb_rcslotrole495, label %bb_rcslotowner495
bb_rcslotrole495:
  %v2212 = load i64, ptr %slot35, align 8
  store i64 %v2212, ptr %slot393, align 8
  %v2213 = load i64, ptr %slot393, align 8
  %v2214 = load i64, ptr %slot390, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2213, i64 %v2214) nomerge, !dbg !136
  br label %bb_rcslotdone495
bb_rcslotowner495:
  %v2215 = load i64, ptr %slot35, align 8
  store i64 %v2215, ptr %slot394, align 8
  %v2216 = load i64, ptr %slot394, align 8
  %v2217 = load i64, ptr %slot390, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2216, i64 %v2217) nomerge, !dbg !136
  br label %bb_rcslotdone495
bb_rcslotdone495:
  %v2218 = load i64, ptr %slot26, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  %ld2220 = load i64, ptr %p2219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2220, ptr %slot395, align 8
  %v2221 = load i64, ptr %slot395, align 8
  %v2222 = load i64, ptr %slot25, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  store i64 %v2221, ptr %p2223, align 8, !alias.scope !3, !noalias !4
  %v2224 = load i64, ptr %slot8, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  %ld2226 = load i32, ptr %p2225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2226, ptr %slot396, align 8
  %v2227 = load i32, ptr %slot396, align 8
  %cv2228 = zext i32 %v2227 to i64
  %cond2229 = icmp ne i64 %cv2228, 0
  br i1 %cond2229, label %bb_rcslotdrop542, label %bb_rcslotdone542
bb_rcslotdrop542:
  %v2230 = load i64, ptr %slot8, align 8
  %p2231 = inttoptr i64 %v2230 to ptr
  store i32 0, ptr %p2231, align 4, !alias.scope !3, !noalias !4
  %v2232 = load i64, ptr %slot23, align 8
  store i64 %v2232, ptr %slot397, align 8
  %v2233 = load i64, ptr %slot9, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %ld2235 = load i32, ptr %p2234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2235, ptr %slot398, align 8
  %v2236 = load i32, ptr %slot398, align 8
  %op2237 = and i32 %v2236, 28
  store i32 %op2237, ptr %slot399, align 8
  %v2238 = load i32, ptr %slot399, align 8
  %cv2239 = zext i32 %v2238 to i64
  %cond2240 = icmp ne i64 %cv2239, 0
  br i1 %cond2240, label %bb_rcslotrole542, label %bb_rcslotowner542
bb_rcslotrole542:
  %v2241 = load i64, ptr %slot35, align 8
  store i64 %v2241, ptr %slot400, align 8
  %v2242 = load i64, ptr %slot397, align 8
  %p2243 = inttoptr i64 %v2242 to ptr
  %ld2244 = load i64, ptr %p2243, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2244, ptr %slot401, align 8
  %v2245 = load i64, ptr %slot401, align 8
  %cmp2246 = icmp ne i64 %v2245, 0
  %cv2247 = zext i1 %cmp2246 to i32
  store i32 %cv2247, ptr %slot402, align 8
  %v2248 = load i32, ptr %slot402, align 8
  %cv2249 = zext i32 %v2248 to i64
  %cond2250 = icmp ne i64 %cv2249, 0
  br i1 %cond2250, label %bb_rcgnn558, label %bb_rcgdone558
bb_rcgnn558:
  %v2251 = load i64, ptr %slot401, align 8
  %op2252 = sub i64 %v2251, 16
  store i64 %op2252, ptr %slot403, align 8
  %v2253 = load i64, ptr %slot401, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  %rgep2255 = getelementptr i8, ptr %p2254, i64 -16
  %ld2256 = load i64, ptr %rgep2255, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2256, ptr %slot404, align 8
  %v2257 = load i64, ptr %slot404, align 8
  %op2258 = and i64 %v2257, 4611686018427387906
  store i64 %op2258, ptr %slot405, align 8
  %v2259 = load i64, ptr %slot405, align 8
  %cmp2260 = icmp ne i64 %v2259, 0
  %cv2261 = zext i1 %cmp2260 to i32
  store i32 %cv2261, ptr %slot406, align 8
  %v2262 = load i32, ptr %slot406, align 8
  %cv2263 = zext i32 %v2262 to i64
  %cond2264 = icmp ne i64 %cv2263, 0
  br i1 %cond2264, label %bb_rcgclear558, label %bb_rcgcounted558
bb_rcgcounted558:
  %v2265 = load i64, ptr %slot401, align 8
  %op2266 = sub i64 %v2265, 24
  store i64 %op2266, ptr %slot407, align 8
  %v2267 = load i64, ptr %slot401, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %rgep2269 = getelementptr i8, ptr %p2268, i64 -24
  %ld2270 = load i64, ptr %rgep2269, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2270, ptr %slot408, align 8
  %v2271 = load i64, ptr %slot408, align 8
  %op2272 = sub i64 %v2271, 1
  store i64 %op2272, ptr %slot409, align 8
  %v2273 = load i64, ptr %slot409, align 8
  %cmp2274 = icmp eq i64 %v2273, 0
  %cv2275 = zext i1 %cmp2274 to i32
  store i32 %cv2275, ptr %slot410, align 8
  %v2276 = load i32, ptr %slot410, align 8
  %cv2277 = zext i32 %v2276 to i64
  %cond2278 = icmp ne i64 %cv2277, 0
  br i1 %cond2278, label %bb_rcglast558, label %bb_rcgdec558
bb_rcglast558:
  %v2279 = load i64, ptr %slot401, align 8
  %op2280 = sub i64 %v2279, 32
  store i64 %op2280, ptr %slot411, align 8
  %v2281 = load i64, ptr %slot401, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  %rgep2283 = getelementptr i8, ptr %p2282, i64 -32
  %ld2284 = load i64, ptr %rgep2283, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2284, ptr %slot412, align 8
  %v2285 = load i64, ptr %slot412, align 8
  %cmp2286 = icmp ne i64 %v2285, 0
  %cv2287 = zext i1 %cmp2286 to i32
  store i32 %cv2287, ptr %slot413, align 8
  %v2288 = load i32, ptr %slot413, align 8
  %cv2289 = zext i32 %v2288 to i64
  %cond2290 = icmp ne i64 %cv2289, 0
  br i1 %cond2290, label %bb_rcgdec558, label %bb_rcgslow558
bb_rcgslow558:
  %v2291 = load i64, ptr %slot400, align 8
  %v2292 = load i64, ptr %slot397, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2291, i64 %v2292) nomerge, !dbg !138
  br label %bb_rcgdone558
bb_rcgdec558:
  %v2293 = load i64, ptr %slot409, align 8
  %v2294 = load i64, ptr %slot401, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  %rgep2296 = getelementptr i8, ptr %p2295, i64 -24
  store i64 %v2293, ptr %rgep2296, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear558
bb_rcgclear558:
  %v2297 = load i64, ptr %slot397, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  store i64 0, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone558
bb_rcgdone558:
  br label %bb_rcslotdone542
bb_rcslotowner542:
  %v2299 = load i64, ptr %slot35, align 8
  store i64 %v2299, ptr %slot414, align 8
  %v2300 = load i64, ptr %slot397, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  %ld2302 = load i64, ptr %p2301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2302, ptr %slot415, align 8
  %v2303 = load i64, ptr %slot415, align 8
  %cmp2304 = icmp ne i64 %v2303, 0
  %cv2305 = zext i1 %cmp2304 to i32
  store i32 %cv2305, ptr %slot416, align 8
  %v2306 = load i32, ptr %slot416, align 8
  %cv2307 = zext i32 %v2306 to i64
  %cond2308 = icmp ne i64 %cv2307, 0
  br i1 %cond2308, label %bb_rcgnn573, label %bb_rcgdone573
bb_rcgnn573:
  %v2309 = load i64, ptr %slot415, align 8
  %op2310 = sub i64 %v2309, 16
  store i64 %op2310, ptr %slot417, align 8
  %v2311 = load i64, ptr %slot415, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %rgep2313 = getelementptr i8, ptr %p2312, i64 -16
  %ld2314 = load i64, ptr %rgep2313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2314, ptr %slot418, align 8
  %v2315 = load i64, ptr %slot418, align 8
  %op2316 = and i64 %v2315, 4611686018427387906
  store i64 %op2316, ptr %slot419, align 8
  %v2317 = load i64, ptr %slot419, align 8
  %cmp2318 = icmp ne i64 %v2317, 0
  %cv2319 = zext i1 %cmp2318 to i32
  store i32 %cv2319, ptr %slot420, align 8
  %v2320 = load i32, ptr %slot420, align 8
  %cv2321 = zext i32 %v2320 to i64
  %cond2322 = icmp ne i64 %cv2321, 0
  br i1 %cond2322, label %bb_rcgclear573, label %bb_rcgcounted573
bb_rcgcounted573:
  %v2323 = load i64, ptr %slot415, align 8
  %op2324 = sub i64 %v2323, 32
  store i64 %op2324, ptr %slot421, align 8
  %v2325 = load i64, ptr %slot415, align 8
  %p2326 = inttoptr i64 %v2325 to ptr
  %rgep2327 = getelementptr i8, ptr %p2326, i64 -32
  %ld2328 = load i64, ptr %rgep2327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2328, ptr %slot422, align 8
  %v2329 = load i64, ptr %slot422, align 8
  %op2330 = sub i64 %v2329, 1
  store i64 %op2330, ptr %slot423, align 8
  %v2331 = load i64, ptr %slot423, align 8
  %cmp2332 = icmp eq i64 %v2331, 0
  %cv2333 = zext i1 %cmp2332 to i32
  store i32 %cv2333, ptr %slot424, align 8
  %v2334 = load i32, ptr %slot424, align 8
  %cv2335 = zext i32 %v2334 to i64
  %cond2336 = icmp ne i64 %cv2335, 0
  br i1 %cond2336, label %bb_rcglast573, label %bb_rcgdec573
bb_rcglast573:
  %v2337 = load i64, ptr %slot415, align 8
  %op2338 = sub i64 %v2337, 24
  store i64 %op2338, ptr %slot425, align 8
  %v2339 = load i64, ptr %slot415, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  %rgep2341 = getelementptr i8, ptr %p2340, i64 -24
  %ld2342 = load i64, ptr %rgep2341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2342, ptr %slot426, align 8
  %v2343 = load i64, ptr %slot426, align 8
  %cmp2344 = icmp ne i64 %v2343, 0
  %cv2345 = zext i1 %cmp2344 to i32
  store i32 %cv2345, ptr %slot427, align 8
  %v2346 = load i32, ptr %slot427, align 8
  %cv2347 = zext i32 %v2346 to i64
  %cond2348 = icmp ne i64 %cv2347, 0
  br i1 %cond2348, label %bb_rcgdec573, label %bb_rcgslow573
bb_rcgslow573:
  %v2349 = load i64, ptr %slot414, align 8
  %v2350 = load i64, ptr %slot397, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2349, i64 %v2350) nomerge, !dbg !138
  br label %bb_rcgdone573
bb_rcgdec573:
  %v2351 = load i64, ptr %slot423, align 8
  %v2352 = load i64, ptr %slot415, align 8
  %p2353 = inttoptr i64 %v2352 to ptr
  %rgep2354 = getelementptr i8, ptr %p2353, i64 -32
  store i64 %v2351, ptr %rgep2354, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear573
bb_rcgclear573:
  %v2355 = load i64, ptr %slot397, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i64 0, ptr %p2356, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone573
bb_rcgdone573:
  br label %bb_rcslotdone542
bb_rcslotdone542:
  %v2357 = load i64, ptr %slot20, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %ld2359 = load i64, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2359, ptr %slot428, align 8
  %v2360 = load i64, ptr %slot428, align 8
  %op2361 = add i64 %v2360, 0
  store i64 %op2361, ptr %slot429, align 8
  %v2362 = load i64, ptr %slot24, align 8
  store i64 %v2362, ptr %slot430, align 8
  %v2363 = load i64, ptr %slot430, align 8
  %v2364 = load i64, ptr %slot429, align 8
  %p2365 = inttoptr i64 %v2363 to ptr
  %p2366 = inttoptr i64 %v2364 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2366, ptr %p2365, i64 208, i1 false), !alias.scope !10000000
  %v2367 = load i64, ptr %slot430, align 8
  %p2368 = inttoptr i64 %v2367 to ptr
  call void @llvm.memset.p0.i64(ptr %p2368, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !140
  %v2369 = load i64, ptr %slot10, align 8
  %p2370 = inttoptr i64 %v2369 to ptr
  store i32 0, ptr %p2370, align 4, !alias.scope !3, !noalias !4
  %v2371 = load i64, ptr %slot26, align 8
  %p2372 = inttoptr i64 %v2371 to ptr
  store i64 0, ptr %p2372, align 8, !alias.scope !3, !noalias !4
  %v2373 = load i64, ptr %slot20, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  %ld2375 = load i64, ptr %p2374, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2375, ptr %slot431, align 8
  %v2376 = load i64, ptr %slot431, align 8
  %v2377 = load i64, ptr %slot26, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  store i64 %v2376, ptr %p2378, align 8, !alias.scope !3, !noalias !4
  %v2379 = load i64, ptr %slot25, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  %ld2381 = load i64, ptr %p2380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2381, ptr %slot432, align 8
  %v2382 = load i64, ptr %slot432, align 8
  %v2383 = load i64, ptr %slot27, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  store i64 %v2382, ptr %p2384, align 8, !alias.scope !3, !noalias !4
  %v2385 = load i64, ptr %slot30, align 8
  store i64 %v2385, ptr %slot433, align 8
  %v2386 = load i64, ptr %slot433, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  store i64 0, ptr %p2387, align 8, !alias.scope !3, !noalias !4
  %v2388 = load i64, ptr %slot433, align 8
  %p2390 = inttoptr i64 %v2388 to ptr
  %gep2391 = getelementptr i8, ptr %p2390, i64 8
  %op2389 = ptrtoint ptr %gep2391 to i64
  store i64 %op2389, ptr %slot434, align 8
  %v2392 = load i64, ptr %slot434, align 8
  %p2393 = inttoptr i64 %v2392 to ptr
  store i64 0, ptr %p2393, align 8, !alias.scope !3, !noalias !4
  %v2394 = load i64, ptr %slot433, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  store i32 3, ptr %p2395, align 4, !alias.scope !3, !noalias !4
  %v2396 = load i64, ptr %slot16, align 8
  %p2397 = inttoptr i64 %v2396 to ptr
  store i32 1, ptr %p2397, align 4, !alias.scope !3, !noalias !4
  %v2398 = load i64, ptr %slot27, align 8
  store i64 %v2398, ptr %slot435, align 8
  %v2399 = load i64, ptr %slot433, align 8
  %p2401 = inttoptr i64 %v2399 to ptr
  %gep2402 = getelementptr i8, ptr %p2401, i64 8
  %op2400 = ptrtoint ptr %gep2402 to i64
  store i64 %op2400, ptr %slot436, align 8
  %v2403 = load i64, ptr %slot36, align 8
  store i64 %v2403, ptr %slot437, align 8
  %v2404 = load i64, ptr %slot435, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  %ld2406 = load i64, ptr %p2405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2406, ptr %slot438, align 8
  %v2407 = load i64, ptr %slot438, align 8
  %v2408 = load i64, ptr %slot436, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  store i64 %v2407, ptr %p2409, align 8, !alias.scope !3, !noalias !4
  %v2410 = load i64, ptr %slot433, align 8
  %v2411 = load i64, ptr %slot27, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  store i64 %v2410, ptr %p2412, align 8, !alias.scope !3, !noalias !4
  %v2413 = load i64, ptr %slot26, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  %ld2415 = load i64, ptr %p2414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2415, ptr %slot439, align 8
  %v2416 = load i64, ptr %slot27, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  %ld2418 = load i64, ptr %p2417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2418, ptr %slot440, align 8
  %v2419 = load i64, ptr %slot1, align 8
  %v2420 = load i64, ptr %slot439, align 8
  %v2421 = load i64, ptr %slot440, align 8
  %call2422 = call i64 @myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365(i64 %v2419, i64 %v2420, i64 %v2421) nomerge, !dbg !142
  store i64 %call2422, ptr %slot441, align 8
  %v2423 = load i64, ptr %slot441, align 8
  %v2424 = load i64, ptr %slot26, align 8
  %p2425 = inttoptr i64 %v2424 to ptr
  store i64 %v2423, ptr %p2425, align 8, !alias.scope !3, !noalias !4
  %v2426 = load i64, ptr %slot12, align 8
  %p2427 = inttoptr i64 %v2426 to ptr
  %ld2428 = load i32, ptr %p2427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2428, ptr %slot442, align 8
  %v2429 = load i32, ptr %slot442, align 8
  %cv2430 = zext i32 %v2429 to i64
  %cond2431 = icmp ne i64 %cv2430, 0
  br i1 %cond2431, label %bb_rcslotdrop596, label %bb_rcslotdone596
bb_rcslotdrop596:
  %v2432 = load i64, ptr %slot12, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  store i32 0, ptr %p2433, align 4, !alias.scope !3, !noalias !4
  %v2434 = load i64, ptr %slot17, align 8
  store i64 %v2434, ptr %slot443, align 8
  %v2435 = load i64, ptr %slot13, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  %ld2437 = load i32, ptr %p2436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2437, ptr %slot444, align 8
  %v2438 = load i32, ptr %slot444, align 8
  %op2439 = and i32 %v2438, 28
  store i32 %op2439, ptr %slot445, align 8
  %v2440 = load i32, ptr %slot445, align 8
  %cv2441 = zext i32 %v2440 to i64
  %cond2442 = icmp ne i64 %cv2441, 0
  br i1 %cond2442, label %bb_rcslotrole596, label %bb_rcslotowner596
bb_rcslotrole596:
  %v2443 = load i64, ptr %slot35, align 8
  store i64 %v2443, ptr %slot446, align 8
  %v2444 = load i64, ptr %slot446, align 8
  %v2445 = load i64, ptr %slot443, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2444, i64 %v2445) nomerge, !dbg !142
  br label %bb_rcslotdone596
bb_rcslotowner596:
  %v2446 = load i64, ptr %slot35, align 8
  store i64 %v2446, ptr %slot447, align 8
  %v2447 = load i64, ptr %slot447, align 8
  %v2448 = load i64, ptr %slot443, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2447, i64 %v2448) nomerge, !dbg !142
  br label %bb_rcslotdone596
bb_rcslotdone596:
  %v2449 = load i64, ptr %slot26, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  store i64 0, ptr %p2450, align 8, !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot26, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  %ld2453 = load i64, ptr %p2452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2453, ptr %slot448, align 8
  %v2454 = load i64, ptr %slot12, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %ld2456 = load i32, ptr %p2455, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2456, ptr %slot449, align 8
  %v2457 = load i32, ptr %slot449, align 8
  %cv2458 = zext i32 %v2457 to i64
  %cond2459 = icmp ne i64 %cv2458, 0
  br i1 %cond2459, label %bb_rcslotdrop606, label %bb_rcslotdone606
bb_rcslotdrop606:
  %v2460 = load i64, ptr %slot12, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  store i32 0, ptr %p2461, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone606
bb_rcslotdone606:
  %v2462 = load i64, ptr %slot10, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  %ld2464 = load i32, ptr %p2463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2464, ptr %slot450, align 8
  %v2465 = load i32, ptr %slot450, align 8
  %cv2466 = zext i32 %v2465 to i64
  %cond2467 = icmp ne i64 %cv2466, 0
  br i1 %cond2467, label %bb_rcslotdrop627, label %bb_rcslotdone627
bb_rcslotdrop627:
  %v2468 = load i64, ptr %slot10, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  store i32 0, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  %v2470 = load i64, ptr %slot24, align 8
  store i64 %v2470, ptr %slot451, align 8
  %v2471 = load i64, ptr %slot11, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %ld2473 = load i32, ptr %p2472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2473, ptr %slot452, align 8
  %v2474 = load i32, ptr %slot452, align 8
  %op2475 = and i32 %v2474, 28
  store i32 %op2475, ptr %slot453, align 8
  %v2476 = load i32, ptr %slot453, align 8
  %cv2477 = zext i32 %v2476 to i64
  %cond2478 = icmp ne i64 %cv2477, 0
  br i1 %cond2478, label %bb_rcslotrole627, label %bb_rcslotowner627
bb_rcslotrole627:
  %v2479 = load i64, ptr %slot35, align 8
  store i64 %v2479, ptr %slot454, align 8
  %v2480 = load i64, ptr %slot454, align 8
  %v2481 = load i64, ptr %slot451, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2480, i64 %v2481) nomerge, !dbg !144
  br label %bb_rcslotdone627
bb_rcslotowner627:
  %v2482 = load i64, ptr %slot35, align 8
  store i64 %v2482, ptr %slot455, align 8
  %v2483 = load i64, ptr %slot455, align 8
  %v2484 = load i64, ptr %slot451, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2483, i64 %v2484) nomerge, !dbg !144
  br label %bb_rcslotdone627
bb_rcslotdone627:
  %v2485 = load i64, ptr %slot8, align 8
  %p2486 = inttoptr i64 %v2485 to ptr
  %ld2487 = load i32, ptr %p2486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2487, ptr %slot456, align 8
  %v2488 = load i32, ptr %slot456, align 8
  %cv2489 = zext i32 %v2488 to i64
  %cond2490 = icmp ne i64 %cv2489, 0
  br i1 %cond2490, label %bb_rcslotdrop636, label %bb_rcslotdone636
bb_rcslotdrop636:
  %v2491 = load i64, ptr %slot8, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  store i32 0, ptr %p2492, align 4, !alias.scope !3, !noalias !4
  %v2493 = load i64, ptr %slot23, align 8
  store i64 %v2493, ptr %slot457, align 8
  %v2494 = load i64, ptr %slot9, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  %ld2496 = load i32, ptr %p2495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2496, ptr %slot458, align 8
  %v2497 = load i32, ptr %slot458, align 8
  %op2498 = and i32 %v2497, 28
  store i32 %op2498, ptr %slot459, align 8
  %v2499 = load i32, ptr %slot459, align 8
  %cv2500 = zext i32 %v2499 to i64
  %cond2501 = icmp ne i64 %cv2500, 0
  br i1 %cond2501, label %bb_rcslotrole636, label %bb_rcslotowner636
bb_rcslotrole636:
  %v2502 = load i64, ptr %slot35, align 8
  store i64 %v2502, ptr %slot460, align 8
  %v2503 = load i64, ptr %slot457, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  %ld2505 = load i64, ptr %p2504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2505, ptr %slot461, align 8
  %v2506 = load i64, ptr %slot461, align 8
  %cmp2507 = icmp ne i64 %v2506, 0
  %cv2508 = zext i1 %cmp2507 to i32
  store i32 %cv2508, ptr %slot462, align 8
  %v2509 = load i32, ptr %slot462, align 8
  %cv2510 = zext i32 %v2509 to i64
  %cond2511 = icmp ne i64 %cv2510, 0
  br i1 %cond2511, label %bb_rcgnn652, label %bb_rcgdone652
bb_rcgnn652:
  %v2512 = load i64, ptr %slot461, align 8
  %op2513 = sub i64 %v2512, 16
  store i64 %op2513, ptr %slot463, align 8
  %v2514 = load i64, ptr %slot461, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  %rgep2516 = getelementptr i8, ptr %p2515, i64 -16
  %ld2517 = load i64, ptr %rgep2516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2517, ptr %slot464, align 8
  %v2518 = load i64, ptr %slot464, align 8
  %op2519 = and i64 %v2518, 4611686018427387906
  store i64 %op2519, ptr %slot465, align 8
  %v2520 = load i64, ptr %slot465, align 8
  %cmp2521 = icmp ne i64 %v2520, 0
  %cv2522 = zext i1 %cmp2521 to i32
  store i32 %cv2522, ptr %slot466, align 8
  %v2523 = load i32, ptr %slot466, align 8
  %cv2524 = zext i32 %v2523 to i64
  %cond2525 = icmp ne i64 %cv2524, 0
  br i1 %cond2525, label %bb_rcgclear652, label %bb_rcgcounted652
bb_rcgcounted652:
  %v2526 = load i64, ptr %slot461, align 8
  %op2527 = sub i64 %v2526, 24
  store i64 %op2527, ptr %slot467, align 8
  %v2528 = load i64, ptr %slot461, align 8
  %p2529 = inttoptr i64 %v2528 to ptr
  %rgep2530 = getelementptr i8, ptr %p2529, i64 -24
  %ld2531 = load i64, ptr %rgep2530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2531, ptr %slot468, align 8
  %v2532 = load i64, ptr %slot468, align 8
  %op2533 = sub i64 %v2532, 1
  store i64 %op2533, ptr %slot469, align 8
  %v2534 = load i64, ptr %slot469, align 8
  %cmp2535 = icmp eq i64 %v2534, 0
  %cv2536 = zext i1 %cmp2535 to i32
  store i32 %cv2536, ptr %slot470, align 8
  %v2537 = load i32, ptr %slot470, align 8
  %cv2538 = zext i32 %v2537 to i64
  %cond2539 = icmp ne i64 %cv2538, 0
  br i1 %cond2539, label %bb_rcglast652, label %bb_rcgdec652
bb_rcglast652:
  %v2540 = load i64, ptr %slot461, align 8
  %op2541 = sub i64 %v2540, 32
  store i64 %op2541, ptr %slot471, align 8
  %v2542 = load i64, ptr %slot461, align 8
  %p2543 = inttoptr i64 %v2542 to ptr
  %rgep2544 = getelementptr i8, ptr %p2543, i64 -32
  %ld2545 = load i64, ptr %rgep2544, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2545, ptr %slot472, align 8
  %v2546 = load i64, ptr %slot472, align 8
  %cmp2547 = icmp ne i64 %v2546, 0
  %cv2548 = zext i1 %cmp2547 to i32
  store i32 %cv2548, ptr %slot473, align 8
  %v2549 = load i32, ptr %slot473, align 8
  %cv2550 = zext i32 %v2549 to i64
  %cond2551 = icmp ne i64 %cv2550, 0
  br i1 %cond2551, label %bb_rcgdec652, label %bb_rcgslow652
bb_rcgslow652:
  %v2552 = load i64, ptr %slot460, align 8
  %v2553 = load i64, ptr %slot457, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2552, i64 %v2553) nomerge, !dbg !144
  br label %bb_rcgdone652
bb_rcgdec652:
  %v2554 = load i64, ptr %slot469, align 8
  %v2555 = load i64, ptr %slot461, align 8
  %p2556 = inttoptr i64 %v2555 to ptr
  %rgep2557 = getelementptr i8, ptr %p2556, i64 -24
  store i64 %v2554, ptr %rgep2557, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear652
bb_rcgclear652:
  %v2558 = load i64, ptr %slot457, align 8
  %p2559 = inttoptr i64 %v2558 to ptr
  store i64 0, ptr %p2559, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone652
bb_rcgdone652:
  br label %bb_rcslotdone636
bb_rcslotowner636:
  %v2560 = load i64, ptr %slot35, align 8
  store i64 %v2560, ptr %slot474, align 8
  %v2561 = load i64, ptr %slot457, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  %ld2563 = load i64, ptr %p2562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2563, ptr %slot475, align 8
  %v2564 = load i64, ptr %slot475, align 8
  %cmp2565 = icmp ne i64 %v2564, 0
  %cv2566 = zext i1 %cmp2565 to i32
  store i32 %cv2566, ptr %slot476, align 8
  %v2567 = load i32, ptr %slot476, align 8
  %cv2568 = zext i32 %v2567 to i64
  %cond2569 = icmp ne i64 %cv2568, 0
  br i1 %cond2569, label %bb_rcgnn667, label %bb_rcgdone667
bb_rcgnn667:
  %v2570 = load i64, ptr %slot475, align 8
  %op2571 = sub i64 %v2570, 16
  store i64 %op2571, ptr %slot477, align 8
  %v2572 = load i64, ptr %slot475, align 8
  %p2573 = inttoptr i64 %v2572 to ptr
  %rgep2574 = getelementptr i8, ptr %p2573, i64 -16
  %ld2575 = load i64, ptr %rgep2574, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2575, ptr %slot478, align 8
  %v2576 = load i64, ptr %slot478, align 8
  %op2577 = and i64 %v2576, 4611686018427387906
  store i64 %op2577, ptr %slot479, align 8
  %v2578 = load i64, ptr %slot479, align 8
  %cmp2579 = icmp ne i64 %v2578, 0
  %cv2580 = zext i1 %cmp2579 to i32
  store i32 %cv2580, ptr %slot480, align 8
  %v2581 = load i32, ptr %slot480, align 8
  %cv2582 = zext i32 %v2581 to i64
  %cond2583 = icmp ne i64 %cv2582, 0
  br i1 %cond2583, label %bb_rcgclear667, label %bb_rcgcounted667
bb_rcgcounted667:
  %v2584 = load i64, ptr %slot475, align 8
  %op2585 = sub i64 %v2584, 32
  store i64 %op2585, ptr %slot481, align 8
  %v2586 = load i64, ptr %slot475, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  %rgep2588 = getelementptr i8, ptr %p2587, i64 -32
  %ld2589 = load i64, ptr %rgep2588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2589, ptr %slot482, align 8
  %v2590 = load i64, ptr %slot482, align 8
  %op2591 = sub i64 %v2590, 1
  store i64 %op2591, ptr %slot483, align 8
  %v2592 = load i64, ptr %slot483, align 8
  %cmp2593 = icmp eq i64 %v2592, 0
  %cv2594 = zext i1 %cmp2593 to i32
  store i32 %cv2594, ptr %slot484, align 8
  %v2595 = load i32, ptr %slot484, align 8
  %cv2596 = zext i32 %v2595 to i64
  %cond2597 = icmp ne i64 %cv2596, 0
  br i1 %cond2597, label %bb_rcglast667, label %bb_rcgdec667
bb_rcglast667:
  %v2598 = load i64, ptr %slot475, align 8
  %op2599 = sub i64 %v2598, 24
  store i64 %op2599, ptr %slot485, align 8
  %v2600 = load i64, ptr %slot475, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  %rgep2602 = getelementptr i8, ptr %p2601, i64 -24
  %ld2603 = load i64, ptr %rgep2602, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2603, ptr %slot486, align 8
  %v2604 = load i64, ptr %slot486, align 8
  %cmp2605 = icmp ne i64 %v2604, 0
  %cv2606 = zext i1 %cmp2605 to i32
  store i32 %cv2606, ptr %slot487, align 8
  %v2607 = load i32, ptr %slot487, align 8
  %cv2608 = zext i32 %v2607 to i64
  %cond2609 = icmp ne i64 %cv2608, 0
  br i1 %cond2609, label %bb_rcgdec667, label %bb_rcgslow667
bb_rcgslow667:
  %v2610 = load i64, ptr %slot474, align 8
  %v2611 = load i64, ptr %slot457, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2610, i64 %v2611) nomerge, !dbg !144
  br label %bb_rcgdone667
bb_rcgdec667:
  %v2612 = load i64, ptr %slot483, align 8
  %v2613 = load i64, ptr %slot475, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  %rgep2615 = getelementptr i8, ptr %p2614, i64 -32
  store i64 %v2612, ptr %rgep2615, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear667
bb_rcgclear667:
  %v2616 = load i64, ptr %slot457, align 8
  %p2617 = inttoptr i64 %v2616 to ptr
  store i64 0, ptr %p2617, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone667
bb_rcgdone667:
  br label %bb_rcslotdone636
bb_rcslotdone636:
  %v2618 = load i64, ptr %slot6, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  %ld2620 = load i32, ptr %p2619, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2620, ptr %slot488, align 8
  %v2621 = load i32, ptr %slot488, align 8
  %cv2622 = zext i32 %v2621 to i64
  %cond2623 = icmp ne i64 %cv2622, 0
  br i1 %cond2623, label %bb_rcslotdrop673, label %bb_rcslotdone673
bb_rcslotdrop673:
  %v2624 = load i64, ptr %slot6, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  store i32 0, ptr %p2625, align 4, !alias.scope !3, !noalias !4
  %v2626 = load i64, ptr %slot22, align 8
  store i64 %v2626, ptr %slot489, align 8
  %v2627 = load i64, ptr %slot7, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  %ld2629 = load i32, ptr %p2628, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2629, ptr %slot490, align 8
  %v2630 = load i32, ptr %slot490, align 8
  %op2631 = and i32 %v2630, 28
  store i32 %op2631, ptr %slot491, align 8
  %v2632 = load i32, ptr %slot491, align 8
  %cv2633 = zext i32 %v2632 to i64
  %cond2634 = icmp ne i64 %cv2633, 0
  br i1 %cond2634, label %bb_rcslotrole673, label %bb_rcslotowner673
bb_rcslotrole673:
  %v2635 = load i64, ptr %slot35, align 8
  store i64 %v2635, ptr %slot492, align 8
  %v2636 = load i64, ptr %slot489, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  %ld2638 = load i64, ptr %p2637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2638, ptr %slot493, align 8
  %v2639 = load i64, ptr %slot493, align 8
  %cmp2640 = icmp ne i64 %v2639, 0
  %cv2641 = zext i1 %cmp2640 to i32
  store i32 %cv2641, ptr %slot494, align 8
  %v2642 = load i32, ptr %slot494, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcgnn689, label %bb_rcgdone689
bb_rcgnn689:
  %v2645 = load i64, ptr %slot493, align 8
  %op2646 = sub i64 %v2645, 16
  store i64 %op2646, ptr %slot495, align 8
  %v2647 = load i64, ptr %slot493, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %rgep2649 = getelementptr i8, ptr %p2648, i64 -16
  %ld2650 = load i64, ptr %rgep2649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2650, ptr %slot496, align 8
  %v2651 = load i64, ptr %slot496, align 8
  %op2652 = and i64 %v2651, 4611686018427387906
  store i64 %op2652, ptr %slot497, align 8
  %v2653 = load i64, ptr %slot497, align 8
  %cmp2654 = icmp ne i64 %v2653, 0
  %cv2655 = zext i1 %cmp2654 to i32
  store i32 %cv2655, ptr %slot498, align 8
  %v2656 = load i32, ptr %slot498, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcgclear689, label %bb_rcgcounted689
bb_rcgcounted689:
  %v2659 = load i64, ptr %slot493, align 8
  %op2660 = sub i64 %v2659, 24
  store i64 %op2660, ptr %slot499, align 8
  %v2661 = load i64, ptr %slot493, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %rgep2663 = getelementptr i8, ptr %p2662, i64 -24
  %ld2664 = load i64, ptr %rgep2663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2664, ptr %slot500, align 8
  %v2665 = load i64, ptr %slot500, align 8
  %op2666 = sub i64 %v2665, 1
  store i64 %op2666, ptr %slot501, align 8
  %v2667 = load i64, ptr %slot501, align 8
  %cmp2668 = icmp eq i64 %v2667, 0
  %cv2669 = zext i1 %cmp2668 to i32
  store i32 %cv2669, ptr %slot502, align 8
  %v2670 = load i32, ptr %slot502, align 8
  %cv2671 = zext i32 %v2670 to i64
  %cond2672 = icmp ne i64 %cv2671, 0
  br i1 %cond2672, label %bb_rcglast689, label %bb_rcgdec689
bb_rcglast689:
  %v2673 = load i64, ptr %slot493, align 8
  %op2674 = sub i64 %v2673, 32
  store i64 %op2674, ptr %slot503, align 8
  %v2675 = load i64, ptr %slot493, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  %rgep2677 = getelementptr i8, ptr %p2676, i64 -32
  %ld2678 = load i64, ptr %rgep2677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2678, ptr %slot504, align 8
  %v2679 = load i64, ptr %slot504, align 8
  %cmp2680 = icmp ne i64 %v2679, 0
  %cv2681 = zext i1 %cmp2680 to i32
  store i32 %cv2681, ptr %slot505, align 8
  %v2682 = load i32, ptr %slot505, align 8
  %cv2683 = zext i32 %v2682 to i64
  %cond2684 = icmp ne i64 %cv2683, 0
  br i1 %cond2684, label %bb_rcgdec689, label %bb_rcgslow689
bb_rcgslow689:
  %v2685 = load i64, ptr %slot492, align 8
  %v2686 = load i64, ptr %slot489, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2685, i64 %v2686) nomerge, !dbg !144
  br label %bb_rcgdone689
bb_rcgdec689:
  %v2687 = load i64, ptr %slot501, align 8
  %v2688 = load i64, ptr %slot493, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %rgep2690 = getelementptr i8, ptr %p2689, i64 -24
  store i64 %v2687, ptr %rgep2690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear689
bb_rcgclear689:
  %v2691 = load i64, ptr %slot489, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  store i64 0, ptr %p2692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone689
bb_rcgdone689:
  br label %bb_rcslotdone673
bb_rcslotowner673:
  %v2693 = load i64, ptr %slot35, align 8
  store i64 %v2693, ptr %slot506, align 8
  %v2694 = load i64, ptr %slot489, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  %ld2696 = load i64, ptr %p2695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2696, ptr %slot507, align 8
  %v2697 = load i64, ptr %slot507, align 8
  %cmp2698 = icmp ne i64 %v2697, 0
  %cv2699 = zext i1 %cmp2698 to i32
  store i32 %cv2699, ptr %slot508, align 8
  %v2700 = load i32, ptr %slot508, align 8
  %cv2701 = zext i32 %v2700 to i64
  %cond2702 = icmp ne i64 %cv2701, 0
  br i1 %cond2702, label %bb_rcgnn704, label %bb_rcgdone704
bb_rcgnn704:
  %v2703 = load i64, ptr %slot507, align 8
  %op2704 = sub i64 %v2703, 16
  store i64 %op2704, ptr %slot509, align 8
  %v2705 = load i64, ptr %slot507, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  %rgep2707 = getelementptr i8, ptr %p2706, i64 -16
  %ld2708 = load i64, ptr %rgep2707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2708, ptr %slot510, align 8
  %v2709 = load i64, ptr %slot510, align 8
  %op2710 = and i64 %v2709, 4611686018427387906
  store i64 %op2710, ptr %slot511, align 8
  %v2711 = load i64, ptr %slot511, align 8
  %cmp2712 = icmp ne i64 %v2711, 0
  %cv2713 = zext i1 %cmp2712 to i32
  store i32 %cv2713, ptr %slot512, align 8
  %v2714 = load i32, ptr %slot512, align 8
  %cv2715 = zext i32 %v2714 to i64
  %cond2716 = icmp ne i64 %cv2715, 0
  br i1 %cond2716, label %bb_rcgclear704, label %bb_rcgcounted704
bb_rcgcounted704:
  %v2717 = load i64, ptr %slot507, align 8
  %op2718 = sub i64 %v2717, 32
  store i64 %op2718, ptr %slot513, align 8
  %v2719 = load i64, ptr %slot507, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  %rgep2721 = getelementptr i8, ptr %p2720, i64 -32
  %ld2722 = load i64, ptr %rgep2721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2722, ptr %slot514, align 8
  %v2723 = load i64, ptr %slot514, align 8
  %op2724 = sub i64 %v2723, 1
  store i64 %op2724, ptr %slot515, align 8
  %v2725 = load i64, ptr %slot515, align 8
  %cmp2726 = icmp eq i64 %v2725, 0
  %cv2727 = zext i1 %cmp2726 to i32
  store i32 %cv2727, ptr %slot516, align 8
  %v2728 = load i32, ptr %slot516, align 8
  %cv2729 = zext i32 %v2728 to i64
  %cond2730 = icmp ne i64 %cv2729, 0
  br i1 %cond2730, label %bb_rcglast704, label %bb_rcgdec704
bb_rcglast704:
  %v2731 = load i64, ptr %slot507, align 8
  %op2732 = sub i64 %v2731, 24
  store i64 %op2732, ptr %slot517, align 8
  %v2733 = load i64, ptr %slot507, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  %rgep2735 = getelementptr i8, ptr %p2734, i64 -24
  %ld2736 = load i64, ptr %rgep2735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2736, ptr %slot518, align 8
  %v2737 = load i64, ptr %slot518, align 8
  %cmp2738 = icmp ne i64 %v2737, 0
  %cv2739 = zext i1 %cmp2738 to i32
  store i32 %cv2739, ptr %slot519, align 8
  %v2740 = load i32, ptr %slot519, align 8
  %cv2741 = zext i32 %v2740 to i64
  %cond2742 = icmp ne i64 %cv2741, 0
  br i1 %cond2742, label %bb_rcgdec704, label %bb_rcgslow704
bb_rcgslow704:
  %v2743 = load i64, ptr %slot506, align 8
  %v2744 = load i64, ptr %slot489, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2743, i64 %v2744) nomerge, !dbg !144
  br label %bb_rcgdone704
bb_rcgdec704:
  %v2745 = load i64, ptr %slot515, align 8
  %v2746 = load i64, ptr %slot507, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  %rgep2748 = getelementptr i8, ptr %p2747, i64 -32
  store i64 %v2745, ptr %rgep2748, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear704
bb_rcgclear704:
  %v2749 = load i64, ptr %slot489, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  store i64 0, ptr %p2750, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone704
bb_rcgdone704:
  br label %bb_rcslotdone673
bb_rcslotdone673:
  %v2751 = load i64, ptr %slot4, align 8
  %p2752 = inttoptr i64 %v2751 to ptr
  %ld2753 = load i32, ptr %p2752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2753, ptr %slot520, align 8
  %v2754 = load i32, ptr %slot520, align 8
  %cv2755 = zext i32 %v2754 to i64
  %cond2756 = icmp ne i64 %cv2755, 0
  br i1 %cond2756, label %bb_rcslotdrop710, label %bb_rcslotdone710
bb_rcslotdrop710:
  %v2757 = load i64, ptr %slot4, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  store i32 0, ptr %p2758, align 4, !alias.scope !3, !noalias !4
  %v2759 = load i64, ptr %slot21, align 8
  store i64 %v2759, ptr %slot521, align 8
  %v2760 = load i64, ptr %slot5, align 8
  %p2761 = inttoptr i64 %v2760 to ptr
  %ld2762 = load i32, ptr %p2761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2762, ptr %slot522, align 8
  %v2763 = load i32, ptr %slot522, align 8
  %op2764 = and i32 %v2763, 28
  store i32 %op2764, ptr %slot523, align 8
  %v2765 = load i32, ptr %slot523, align 8
  %cv2766 = zext i32 %v2765 to i64
  %cond2767 = icmp ne i64 %cv2766, 0
  br i1 %cond2767, label %bb_rcslotrole710, label %bb_rcslotowner710
bb_rcslotrole710:
  %v2768 = load i64, ptr %slot35, align 8
  store i64 %v2768, ptr %slot524, align 8
  %v2769 = load i64, ptr %slot524, align 8
  %v2770 = load i64, ptr %slot521, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2769, i64 %v2770) nomerge, !dbg !144
  br label %bb_rcslotdone710
bb_rcslotowner710:
  %v2771 = load i64, ptr %slot35, align 8
  store i64 %v2771, ptr %slot525, align 8
  %v2772 = load i64, ptr %slot525, align 8
  %v2773 = load i64, ptr %slot521, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2772, i64 %v2773) nomerge, !dbg !144
  br label %bb_rcslotdone710
bb_rcslotdone710:
  %v2774 = load i64, ptr %slot448, align 8
  ret i64 %v2774
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_21359198e4b9ab9b0fccc1dfb92f246b272722a8ef7709255ff3cae4a9b66f1c(i64, i64, i64)
declare i64 @myl_f_449150a5e00d42d4312cf17b5dfe8a409a2f900752b01e8a4b3efb9331340365(i64, i64, i64)
declare ptr @myl_native_bytes_view(ptr, ptr, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_da29e2319f1ca7211fbec2590e8b68131c88b074f9f0bad6b5347509ebaee07c", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_da29e2319f1ca7211fbec2590e8b68131c88b074f9f0bad6b5347509ebaee07c", linkageName: "myl_f_da29e2319f1ca7211fbec2590e8b68131c88b074f9f0bad6b5347509ebaee07c", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9949120821860098042, i64 0, !"myl_f_da29e2319f1ca7211fbec2590e8b68131c88b074f9f0bad6b5347509ebaee07c"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!120 = !DILocation(line: 6, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!122 = !DILocation(line: 8, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!124 = !DILocation(line: 10, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!126 = !DILocation(line: 15, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!130 = !DILocation(line: 18, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!132 = !DILocation(line: 19, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!134 = !DILocation(line: 21, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!136 = !DILocation(line: 26, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!138 = !DILocation(line: 27, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!140 = !DILocation(line: 38, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!142 = !DILocation(line: 44, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!144 = !DILocation(line: 47, column: 0, scope: !145)
