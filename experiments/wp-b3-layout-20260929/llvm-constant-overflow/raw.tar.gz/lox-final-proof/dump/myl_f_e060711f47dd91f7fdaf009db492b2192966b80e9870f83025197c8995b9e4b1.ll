target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i32, align 8
  %slot24 = alloca i32, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i32, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v215 = load i64, ptr %slot1, align 8
  %op216 = add i64 %v215, 32
  store i64 %op216, ptr %slot3, align 8
  %mem217 = alloca i8, i64 8, align 8
  %ptr218 = ptrtoint ptr %mem217 to i64
  store i64 %ptr218, ptr %slot4, align 8
  %mem219 = alloca i8, i64 8, align 8
  %ptr220 = ptrtoint ptr %mem219 to i64
  store i64 %ptr220, ptr %slot5, align 8
  %mem221 = alloca i8, i64 8, align 8
  %ptr222 = ptrtoint ptr %mem221 to i64
  store i64 %ptr222, ptr %slot6, align 8
  %mem223 = alloca i8, i64 8, align 8
  %ptr224 = ptrtoint ptr %mem223 to i64
  store i64 %ptr224, ptr %slot7, align 8
  %mem225 = alloca i8, i64 8, align 8
  %ptr226 = ptrtoint ptr %mem225 to i64
  store i64 %ptr226, ptr %slot8, align 8
  %mem227 = alloca i8, i64 8, align 8
  %ptr228 = ptrtoint ptr %mem227 to i64
  store i64 %ptr228, ptr %slot9, align 8
  %mem229 = alloca i8, i64 8, align 8
  %ptr230 = ptrtoint ptr %mem229 to i64
  store i64 %ptr230, ptr %slot10, align 8
  %mem231 = alloca i8, i64 8, align 8
  %ptr232 = ptrtoint ptr %mem231 to i64
  store i64 %ptr232, ptr %slot11, align 8
  %mem233 = alloca i8, i64 8, align 8
  %ptr234 = ptrtoint ptr %mem233 to i64
  store i64 %ptr234, ptr %slot12, align 8
  %mem235 = alloca i8, i64 8, align 8
  %ptr236 = ptrtoint ptr %mem235 to i64
  store i64 %ptr236, ptr %slot13, align 8
  %mem237 = alloca i8, i64 8, align 8
  %ptr238 = ptrtoint ptr %mem237 to i64
  store i64 %ptr238, ptr %slot14, align 8
  %mem239 = alloca i8, i64 8, align 8
  %ptr240 = ptrtoint ptr %mem239 to i64
  store i64 %ptr240, ptr %slot15, align 8
  %mem241 = alloca i8, i64 8, align 8
  %ptr242 = ptrtoint ptr %mem241 to i64
  store i64 %ptr242, ptr %slot16, align 8
  %mem243 = alloca i8, i64 8, align 8
  %ptr244 = ptrtoint ptr %mem243 to i64
  store i64 %ptr244, ptr %slot17, align 8
  %mem245 = alloca i8, i64 8, align 8
  %ptr246 = ptrtoint ptr %mem245 to i64
  store i64 %ptr246, ptr %slot18, align 8
  %mem247 = alloca i8, i64 8, align 8
  %ptr248 = ptrtoint ptr %mem247 to i64
  store i64 %ptr248, ptr %slot19, align 8
  %v249 = load i64, ptr %slot14, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 0, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot2, align 8
  %v252 = load i64, ptr %slot12, align 8
  %p253 = inttoptr i64 %v252 to ptr
  store i64 %v251, ptr %p253, align 8, !alias.scope !3, !noalias !4
  %v254 = load i64, ptr %slot1, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %call256 = call ptr @myl_qbe_heap(ptr %p255) nomerge, !dbg !110
  %calladdr257 = ptrtoint ptr %call256 to i64
  store i64 %calladdr257, ptr %slot20, align 8
  %v258 = load i64, ptr %slot4, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i32 0, ptr %p259, align 4, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot5, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i32 0, ptr %p261, align 4, !alias.scope !3, !noalias !4
  %v262 = load i64, ptr %slot6, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i32 0, ptr %p263, align 4, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot7, align 8
  %p265 = inttoptr i64 %v264 to ptr
  store i32 0, ptr %p265, align 4, !alias.scope !3, !noalias !4
  %v266 = load i64, ptr %slot8, align 8
  %p267 = inttoptr i64 %v266 to ptr
  store i32 0, ptr %p267, align 4, !alias.scope !3, !noalias !4
  %v268 = load i64, ptr %slot9, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i32 0, ptr %p269, align 4, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot4, align 8
  %p271 = inttoptr i64 %v270 to ptr
  store i32 2, ptr %p271, align 4, !alias.scope !3, !noalias !4
  %v272 = load i64, ptr %slot6, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i32 2, ptr %p273, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v274 = load i64, ptr %slot18, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i64 2166136261, ptr %p275, align 8, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot18, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i64, ptr %p277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot21, align 8
  %v279 = load i64, ptr %slot21, align 8
  %v280 = load i64, ptr %slot13, align 8
  %p281 = inttoptr i64 %v280 to ptr
  store i64 %v279, ptr %p281, align 8, !alias.scope !3, !noalias !4
  %v282 = load i64, ptr %slot12, align 8
  %p283 = inttoptr i64 %v282 to ptr
  %ld284 = load i64, ptr %p283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld284, ptr %slot22, align 8
  %v285 = load i64, ptr %slot4, align 8
  %p286 = inttoptr i64 %v285 to ptr
  %ld287 = load i32, ptr %p286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld287, ptr %slot23, align 8
  %v288 = load i32, ptr %slot23, align 8
  %cmp289 = icmp eq i32 %v288, 8
  %cv290 = zext i1 %cmp289 to i32
  store i32 %cv290, ptr %slot24, align 8
  store i32 0, ptr %slot25, align 8
  %v291 = load i32, ptr %slot24, align 8
  %v292 = load i32, ptr %slot25, align 8
  %op293 = and i32 %v291, %v292
  store i32 %op293, ptr %slot26, align 8
  %v294 = load i32, ptr %slot26, align 8
  %cv295 = zext i32 %v294 to i64
  %cond296 = icmp ne i64 %cv295, 0
  br i1 %cond296, label %bb_rchold4, label %bb_rcordinary4
bb_rchold4:
  %v297 = load i64, ptr %slot11, align 8
  store i64 %v297, ptr %slot27, align 8
  %v298 = load i64, ptr %slot22, align 8
  %cmp299 = icmp ne i64 %v298, 0
  %cv300 = zext i1 %cmp299 to i32
  store i32 %cv300, ptr %slot28, align 8
  %v301 = load i32, ptr %slot28, align 8
  %cv302 = zext i32 %v301 to i64
  %cond303 = icmp ne i64 %cv302, 0
  br i1 %cond303, label %bb_rcgnn14, label %bb_rcgstore14
bb_rcgnn14:
  %v304 = load i64, ptr %slot22, align 8
  %op305 = sub i64 %v304, 16
  store i64 %op305, ptr %slot29, align 8
  %v306 = load i64, ptr %slot22, align 8
  %p307 = inttoptr i64 %v306 to ptr
  %rgep308 = getelementptr i8, ptr %p307, i64 -16
  %ld309 = load i64, ptr %rgep308, align 8, !alias.scope !9, !noalias !10
  store i64 %ld309, ptr %slot30, align 8
  %v310 = load i64, ptr %slot30, align 8
  %op311 = and i64 %v310, 4611686018427387906
  store i64 %op311, ptr %slot31, align 8
  %v312 = load i64, ptr %slot31, align 8
  %cmp313 = icmp ne i64 %v312, 0
  %cv314 = zext i1 %cmp313 to i32
  store i32 %cv314, ptr %slot32, align 8
  %v315 = load i32, ptr %slot32, align 8
  %cv316 = zext i32 %v315 to i64
  %cond317 = icmp ne i64 %cv316, 0
  br i1 %cond317, label %bb_rcgstore14, label %bb_rcginc14
bb_rcginc14:
  %v318 = load i64, ptr %slot22, align 8
  %op319 = sub i64 %v318, 24
  store i64 %op319, ptr %slot33, align 8
  %v320 = load i64, ptr %slot22, align 8
  %p321 = inttoptr i64 %v320 to ptr
  %rgep322 = getelementptr i8, ptr %p321, i64 -24
  %ld323 = load i64, ptr %rgep322, align 8, !alias.scope !9, !noalias !10
  store i64 %ld323, ptr %slot34, align 8
  %v324 = load i64, ptr %slot34, align 8
  %op325 = add i64 %v324, 1
  store i64 %op325, ptr %slot35, align 8
  %v326 = load i64, ptr %slot35, align 8
  %cmp327 = icmp eq i64 %v326, 0
  %cv328 = zext i1 %cmp327 to i32
  store i32 %cv328, ptr %slot36, align 8
  %v329 = load i32, ptr %slot36, align 8
  %cv330 = zext i32 %v329 to i64
  %cond331 = icmp ne i64 %cv330, 0
  br i1 %cond331, label %bb_rcglimit14, label %bb_rcgcapacity14
bb_rcglimit14:
  %v332 = load i64, ptr %slot1, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %call334 = call i32 @myl_qbe_rc_status(ptr %p333, i32 2) nomerge, !dbg !112
  store i32 %call334, ptr %slot37, align 8
  br label %bb_failure
bb_rcgcapacity14:
  %v335 = load i64, ptr %slot35, align 8
  %v336 = load i64, ptr %slot22, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %rgep338 = getelementptr i8, ptr %p337, i64 -24
  store i64 %v335, ptr %rgep338, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore14
bb_rcgstore14:
  %v339 = load i64, ptr %slot22, align 8
  %v340 = load i64, ptr %slot27, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i64 %v339, ptr %p341, align 8, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot9, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i32 1, ptr %p343, align 4, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot10, align 8
  store i64 %v344, ptr %slot38, align 8
  %v345 = load i64, ptr %slot11, align 8
  store i64 %v345, ptr %slot39, align 8
  %v346 = load i64, ptr %slot39, align 8
  %p347 = inttoptr i64 %v346 to ptr
  %ld348 = load i64, ptr %p347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld348, ptr %slot40, align 8
  %v349 = load i64, ptr %slot40, align 8
  %v350 = load i64, ptr %slot38, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i64 %v349, ptr %p351, align 8, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot8, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 2, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot8, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i32 8, ptr %p355, align 4, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot7, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i32 1, ptr %p357, align 4, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot9, align 8
  %p359 = inttoptr i64 %v358 to ptr
  store i32 0, ptr %p359, align 4, !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot40, align 8
  %v361 = load i64, ptr %slot18, align 8
  %p362 = inttoptr i64 %v361 to ptr
  store i64 %v360, ptr %p362, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined4
bb_rcordinary4:
  %v363 = load i64, ptr %slot22, align 8
  %v364 = load i64, ptr %slot18, align 8
  %p365 = inttoptr i64 %v364 to ptr
  store i64 %v363, ptr %p365, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcholdjoined4
bb_rcholdjoined4:
  %v366 = load i64, ptr %slot18, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot41, align 8
  %v369 = load i64, ptr %slot11, align 8
  store i64 %v369, ptr %slot42, align 8
  %v370 = load i64, ptr %slot41, align 8
  %cmp371 = icmp ne i64 %v370, 0
  %cv372 = zext i1 %cmp371 to i32
  store i32 %cv372, ptr %slot43, align 8
  %v373 = load i32, ptr %slot43, align 8
  %cv374 = zext i32 %v373 to i64
  %cond375 = icmp ne i64 %cv374, 0
  br i1 %cond375, label %bb_rcgnn39, label %bb_rcgstore39
bb_rcgnn39:
  %v376 = load i64, ptr %slot41, align 8
  %op377 = sub i64 %v376, 16
  store i64 %op377, ptr %slot44, align 8
  %v378 = load i64, ptr %slot41, align 8
  %p379 = inttoptr i64 %v378 to ptr
  %rgep380 = getelementptr i8, ptr %p379, i64 -16
  %ld381 = load i64, ptr %rgep380, align 8, !alias.scope !9, !noalias !10
  store i64 %ld381, ptr %slot45, align 8
  %v382 = load i64, ptr %slot45, align 8
  %op383 = and i64 %v382, 4611686018427387906
  store i64 %op383, ptr %slot46, align 8
  %v384 = load i64, ptr %slot46, align 8
  %cmp385 = icmp ne i64 %v384, 0
  %cv386 = zext i1 %cmp385 to i32
  store i32 %cv386, ptr %slot47, align 8
  %v387 = load i32, ptr %slot47, align 8
  %cv388 = zext i32 %v387 to i64
  %cond389 = icmp ne i64 %cv388, 0
  br i1 %cond389, label %bb_rcgstore39, label %bb_rcginc39
bb_rcginc39:
  %v390 = load i64, ptr %slot41, align 8
  %op391 = sub i64 %v390, 24
  store i64 %op391, ptr %slot48, align 8
  %v392 = load i64, ptr %slot41, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %rgep394 = getelementptr i8, ptr %p393, i64 -24
  %ld395 = load i64, ptr %rgep394, align 8, !alias.scope !9, !noalias !10
  store i64 %ld395, ptr %slot49, align 8
  %v396 = load i64, ptr %slot49, align 8
  %op397 = add i64 %v396, 1
  store i64 %op397, ptr %slot50, align 8
  %v398 = load i64, ptr %slot50, align 8
  %cmp399 = icmp eq i64 %v398, 0
  %cv400 = zext i1 %cmp399 to i32
  store i32 %cv400, ptr %slot51, align 8
  %v401 = load i32, ptr %slot51, align 8
  %cv402 = zext i32 %v401 to i64
  %cond403 = icmp ne i64 %cv402, 0
  br i1 %cond403, label %bb_rcglimit39, label %bb_rcgcapacity39
bb_rcglimit39:
  %v404 = load i64, ptr %slot1, align 8
  %p405 = inttoptr i64 %v404 to ptr
  %call406 = call i32 @myl_qbe_rc_status(ptr %p405, i32 2) nomerge, !dbg !114
  store i32 %call406, ptr %slot52, align 8
  br label %bb_failure
bb_rcgcapacity39:
  %v407 = load i64, ptr %slot50, align 8
  %v408 = load i64, ptr %slot41, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %rgep410 = getelementptr i8, ptr %p409, i64 -24
  store i64 %v407, ptr %rgep410, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore39
bb_rcgstore39:
  %v411 = load i64, ptr %slot41, align 8
  %v412 = load i64, ptr %slot42, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 %v411, ptr %p413, align 8, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot9, align 8
  %p415 = inttoptr i64 %v414 to ptr
  store i32 1, ptr %p415, align 4, !alias.scope !3, !noalias !4
  %v416 = load i64, ptr %slot7, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %ld418 = load i32, ptr %p417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld418, ptr %slot53, align 8
  %v419 = load i32, ptr %slot53, align 8
  %cv420 = zext i32 %v419 to i64
  %cond421 = icmp ne i64 %cv420, 0
  br i1 %cond421, label %bb_rcslotdrop55, label %bb_rcslotdone55
bb_rcslotdrop55:
  %v422 = load i64, ptr %slot7, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i32 0, ptr %p423, align 4, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot10, align 8
  store i64 %v424, ptr %slot54, align 8
  %v425 = load i64, ptr %slot8, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i32, ptr %p426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld427, ptr %slot55, align 8
  %v428 = load i32, ptr %slot55, align 8
  %op429 = and i32 %v428, 28
  store i32 %op429, ptr %slot56, align 8
  %v430 = load i32, ptr %slot56, align 8
  %cv431 = zext i32 %v430 to i64
  %cond432 = icmp ne i64 %cv431, 0
  br i1 %cond432, label %bb_rcslotrole55, label %bb_rcslotowner55
bb_rcslotrole55:
  %v433 = load i64, ptr %slot20, align 8
  store i64 %v433, ptr %slot57, align 8
  %v434 = load i64, ptr %slot54, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %ld436 = load i64, ptr %p435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld436, ptr %slot58, align 8
  %v437 = load i64, ptr %slot58, align 8
  %cmp438 = icmp ne i64 %v437, 0
  %cv439 = zext i1 %cmp438 to i32
  store i32 %cv439, ptr %slot59, align 8
  %v440 = load i32, ptr %slot59, align 8
  %cv441 = zext i32 %v440 to i64
  %cond442 = icmp ne i64 %cv441, 0
  br i1 %cond442, label %bb_rcgnn71, label %bb_rcgdone71
bb_rcgnn71:
  %v443 = load i64, ptr %slot58, align 8
  %op444 = sub i64 %v443, 16
  store i64 %op444, ptr %slot60, align 8
  %v445 = load i64, ptr %slot58, align 8
  %p446 = inttoptr i64 %v445 to ptr
  %rgep447 = getelementptr i8, ptr %p446, i64 -16
  %ld448 = load i64, ptr %rgep447, align 8, !alias.scope !9, !noalias !10
  store i64 %ld448, ptr %slot61, align 8
  %v449 = load i64, ptr %slot61, align 8
  %op450 = and i64 %v449, 4611686018427387906
  store i64 %op450, ptr %slot62, align 8
  %v451 = load i64, ptr %slot62, align 8
  %cmp452 = icmp ne i64 %v451, 0
  %cv453 = zext i1 %cmp452 to i32
  store i32 %cv453, ptr %slot63, align 8
  %v454 = load i32, ptr %slot63, align 8
  %cv455 = zext i32 %v454 to i64
  %cond456 = icmp ne i64 %cv455, 0
  br i1 %cond456, label %bb_rcgclear71, label %bb_rcgcounted71
bb_rcgcounted71:
  %v457 = load i64, ptr %slot58, align 8
  %op458 = sub i64 %v457, 24
  store i64 %op458, ptr %slot64, align 8
  %v459 = load i64, ptr %slot58, align 8
  %p460 = inttoptr i64 %v459 to ptr
  %rgep461 = getelementptr i8, ptr %p460, i64 -24
  %ld462 = load i64, ptr %rgep461, align 8, !alias.scope !9, !noalias !10
  store i64 %ld462, ptr %slot65, align 8
  %v463 = load i64, ptr %slot65, align 8
  %op464 = sub i64 %v463, 1
  store i64 %op464, ptr %slot66, align 8
  %v465 = load i64, ptr %slot66, align 8
  %cmp466 = icmp eq i64 %v465, 0
  %cv467 = zext i1 %cmp466 to i32
  store i32 %cv467, ptr %slot67, align 8
  %v468 = load i32, ptr %slot67, align 8
  %cv469 = zext i32 %v468 to i64
  %cond470 = icmp ne i64 %cv469, 0
  br i1 %cond470, label %bb_rcglast71, label %bb_rcgdec71
bb_rcglast71:
  %v471 = load i64, ptr %slot58, align 8
  %op472 = sub i64 %v471, 32
  store i64 %op472, ptr %slot68, align 8
  %v473 = load i64, ptr %slot58, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %rgep475 = getelementptr i8, ptr %p474, i64 -32
  %ld476 = load i64, ptr %rgep475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld476, ptr %slot69, align 8
  %v477 = load i64, ptr %slot69, align 8
  %cmp478 = icmp ne i64 %v477, 0
  %cv479 = zext i1 %cmp478 to i32
  store i32 %cv479, ptr %slot70, align 8
  %v480 = load i32, ptr %slot70, align 8
  %cv481 = zext i32 %v480 to i64
  %cond482 = icmp ne i64 %cv481, 0
  br i1 %cond482, label %bb_rcgdec71, label %bb_rcgslow71
bb_rcgslow71:
  %v483 = load i64, ptr %slot57, align 8
  %v484 = load i64, ptr %slot54, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v483, i64 %v484) nomerge, !dbg !114
  br label %bb_rcgdone71
bb_rcgdec71:
  %v485 = load i64, ptr %slot66, align 8
  %v486 = load i64, ptr %slot58, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %rgep488 = getelementptr i8, ptr %p487, i64 -24
  store i64 %v485, ptr %rgep488, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear71
bb_rcgclear71:
  %v489 = load i64, ptr %slot54, align 8
  %p490 = inttoptr i64 %v489 to ptr
  store i64 0, ptr %p490, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone71
bb_rcgdone71:
  br label %bb_rcslotdone55
bb_rcslotowner55:
  %v491 = load i64, ptr %slot20, align 8
  store i64 %v491, ptr %slot71, align 8
  %v492 = load i64, ptr %slot54, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i64, ptr %p493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld494, ptr %slot72, align 8
  %v495 = load i64, ptr %slot72, align 8
  %cmp496 = icmp ne i64 %v495, 0
  %cv497 = zext i1 %cmp496 to i32
  store i32 %cv497, ptr %slot73, align 8
  %v498 = load i32, ptr %slot73, align 8
  %cv499 = zext i32 %v498 to i64
  %cond500 = icmp ne i64 %cv499, 0
  br i1 %cond500, label %bb_rcgnn86, label %bb_rcgdone86
bb_rcgnn86:
  %v501 = load i64, ptr %slot72, align 8
  %op502 = sub i64 %v501, 16
  store i64 %op502, ptr %slot74, align 8
  %v503 = load i64, ptr %slot72, align 8
  %p504 = inttoptr i64 %v503 to ptr
  %rgep505 = getelementptr i8, ptr %p504, i64 -16
  %ld506 = load i64, ptr %rgep505, align 8, !alias.scope !9, !noalias !10
  store i64 %ld506, ptr %slot75, align 8
  %v507 = load i64, ptr %slot75, align 8
  %op508 = and i64 %v507, 4611686018427387906
  store i64 %op508, ptr %slot76, align 8
  %v509 = load i64, ptr %slot76, align 8
  %cmp510 = icmp ne i64 %v509, 0
  %cv511 = zext i1 %cmp510 to i32
  store i32 %cv511, ptr %slot77, align 8
  %v512 = load i32, ptr %slot77, align 8
  %cv513 = zext i32 %v512 to i64
  %cond514 = icmp ne i64 %cv513, 0
  br i1 %cond514, label %bb_rcgclear86, label %bb_rcgcounted86
bb_rcgcounted86:
  %v515 = load i64, ptr %slot72, align 8
  %op516 = sub i64 %v515, 32
  store i64 %op516, ptr %slot78, align 8
  %v517 = load i64, ptr %slot72, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %rgep519 = getelementptr i8, ptr %p518, i64 -32
  %ld520 = load i64, ptr %rgep519, align 8, !alias.scope !9, !noalias !10
  store i64 %ld520, ptr %slot79, align 8
  %v521 = load i64, ptr %slot79, align 8
  %op522 = sub i64 %v521, 1
  store i64 %op522, ptr %slot80, align 8
  %v523 = load i64, ptr %slot80, align 8
  %cmp524 = icmp eq i64 %v523, 0
  %cv525 = zext i1 %cmp524 to i32
  store i32 %cv525, ptr %slot81, align 8
  %v526 = load i32, ptr %slot81, align 8
  %cv527 = zext i32 %v526 to i64
  %cond528 = icmp ne i64 %cv527, 0
  br i1 %cond528, label %bb_rcglast86, label %bb_rcgdec86
bb_rcglast86:
  %v529 = load i64, ptr %slot72, align 8
  %op530 = sub i64 %v529, 24
  store i64 %op530, ptr %slot82, align 8
  %v531 = load i64, ptr %slot72, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %rgep533 = getelementptr i8, ptr %p532, i64 -24
  %ld534 = load i64, ptr %rgep533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld534, ptr %slot83, align 8
  %v535 = load i64, ptr %slot83, align 8
  %cmp536 = icmp ne i64 %v535, 0
  %cv537 = zext i1 %cmp536 to i32
  store i32 %cv537, ptr %slot84, align 8
  %v538 = load i32, ptr %slot84, align 8
  %cv539 = zext i32 %v538 to i64
  %cond540 = icmp ne i64 %cv539, 0
  br i1 %cond540, label %bb_rcgdec86, label %bb_rcgslow86
bb_rcgslow86:
  %v541 = load i64, ptr %slot71, align 8
  %v542 = load i64, ptr %slot54, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v541, i64 %v542) nomerge, !dbg !114
  br label %bb_rcgdone86
bb_rcgdec86:
  %v543 = load i64, ptr %slot80, align 8
  %v544 = load i64, ptr %slot72, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %rgep546 = getelementptr i8, ptr %p545, i64 -32
  store i64 %v543, ptr %rgep546, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear86
bb_rcgclear86:
  %v547 = load i64, ptr %slot54, align 8
  %p548 = inttoptr i64 %v547 to ptr
  store i64 0, ptr %p548, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone86
bb_rcgdone86:
  br label %bb_rcslotdone55
bb_rcslotdone55:
  %v549 = load i64, ptr %slot10, align 8
  store i64 %v549, ptr %slot85, align 8
  %v550 = load i64, ptr %slot11, align 8
  store i64 %v550, ptr %slot86, align 8
  %v551 = load i64, ptr %slot86, align 8
  %p552 = inttoptr i64 %v551 to ptr
  %ld553 = load i64, ptr %p552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld553, ptr %slot87, align 8
  %v554 = load i64, ptr %slot87, align 8
  %v555 = load i64, ptr %slot85, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i64 %v554, ptr %p556, align 8, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot8, align 8
  %p558 = inttoptr i64 %v557 to ptr
  store i32 2, ptr %p558, align 4, !alias.scope !3, !noalias !4
  %v559 = load i64, ptr %slot8, align 8
  %p560 = inttoptr i64 %v559 to ptr
  store i32 8, ptr %p560, align 4, !alias.scope !3, !noalias !4
  %v561 = load i64, ptr %slot7, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i32 1, ptr %p562, align 4, !alias.scope !3, !noalias !4
  %v563 = load i64, ptr %slot9, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 0, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot87, align 8
  %v566 = load i64, ptr %slot18, align 8
  %p567 = inttoptr i64 %v566 to ptr
  store i64 %v565, ptr %p567, align 8, !alias.scope !3, !noalias !4
  %v568 = load i64, ptr %slot11, align 8
  store i64 %v568, ptr %slot88, align 8
  %v569 = load i64, ptr %slot18, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot89, align 8
  %v572 = load i64, ptr %slot89, align 8
  %v573 = load i64, ptr %slot88, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i64 %v572, ptr %p574, align 8, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot9, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i32 1, ptr %p576, align 4, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot7, align 8
  %p578 = inttoptr i64 %v577 to ptr
  store i32 0, ptr %p578, align 4, !alias.scope !3, !noalias !4
  %v579 = load i64, ptr %slot5, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %ld581 = load i32, ptr %p580, align 4, !alias.scope !3, !noalias !4
  store i32 %ld581, ptr %slot90, align 8
  %v582 = load i32, ptr %slot90, align 8
  %cv583 = zext i32 %v582 to i64
  %cond584 = icmp ne i64 %cv583, 0
  br i1 %cond584, label %bb_rcslotdrop105, label %bb_rcslotdone105
bb_rcslotdrop105:
  %v585 = load i64, ptr %slot5, align 8
  %p586 = inttoptr i64 %v585 to ptr
  store i32 0, ptr %p586, align 4, !alias.scope !3, !noalias !4
  %v587 = load i64, ptr %slot14, align 8
  store i64 %v587, ptr %slot91, align 8
  %v588 = load i64, ptr %slot6, align 8
  %p589 = inttoptr i64 %v588 to ptr
  %ld590 = load i32, ptr %p589, align 4, !alias.scope !3, !noalias !4
  store i32 %ld590, ptr %slot92, align 8
  %v591 = load i32, ptr %slot92, align 8
  %op592 = and i32 %v591, 28
  store i32 %op592, ptr %slot93, align 8
  %v593 = load i32, ptr %slot93, align 8
  %cv594 = zext i32 %v593 to i64
  %cond595 = icmp ne i64 %cv594, 0
  br i1 %cond595, label %bb_rcslotrole105, label %bb_rcslotowner105
bb_rcslotrole105:
  %v596 = load i64, ptr %slot20, align 8
  store i64 %v596, ptr %slot94, align 8
  %v597 = load i64, ptr %slot91, align 8
  %p598 = inttoptr i64 %v597 to ptr
  %ld599 = load i64, ptr %p598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld599, ptr %slot95, align 8
  %v600 = load i64, ptr %slot95, align 8
  %cmp601 = icmp ne i64 %v600, 0
  %cv602 = zext i1 %cmp601 to i32
  store i32 %cv602, ptr %slot96, align 8
  %v603 = load i32, ptr %slot96, align 8
  %cv604 = zext i32 %v603 to i64
  %cond605 = icmp ne i64 %cv604, 0
  br i1 %cond605, label %bb_rcgnn121, label %bb_rcgdone121
bb_rcgnn121:
  %v606 = load i64, ptr %slot95, align 8
  %op607 = sub i64 %v606, 16
  store i64 %op607, ptr %slot97, align 8
  %v608 = load i64, ptr %slot95, align 8
  %p609 = inttoptr i64 %v608 to ptr
  %rgep610 = getelementptr i8, ptr %p609, i64 -16
  %ld611 = load i64, ptr %rgep610, align 8, !alias.scope !9, !noalias !10
  store i64 %ld611, ptr %slot98, align 8
  %v612 = load i64, ptr %slot98, align 8
  %op613 = and i64 %v612, 4611686018427387906
  store i64 %op613, ptr %slot99, align 8
  %v614 = load i64, ptr %slot99, align 8
  %cmp615 = icmp ne i64 %v614, 0
  %cv616 = zext i1 %cmp615 to i32
  store i32 %cv616, ptr %slot100, align 8
  %v617 = load i32, ptr %slot100, align 8
  %cv618 = zext i32 %v617 to i64
  %cond619 = icmp ne i64 %cv618, 0
  br i1 %cond619, label %bb_rcgclear121, label %bb_rcgcounted121
bb_rcgcounted121:
  %v620 = load i64, ptr %slot95, align 8
  %op621 = sub i64 %v620, 24
  store i64 %op621, ptr %slot101, align 8
  %v622 = load i64, ptr %slot95, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %rgep624 = getelementptr i8, ptr %p623, i64 -24
  %ld625 = load i64, ptr %rgep624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld625, ptr %slot102, align 8
  %v626 = load i64, ptr %slot102, align 8
  %op627 = sub i64 %v626, 1
  store i64 %op627, ptr %slot103, align 8
  %v628 = load i64, ptr %slot103, align 8
  %cmp629 = icmp eq i64 %v628, 0
  %cv630 = zext i1 %cmp629 to i32
  store i32 %cv630, ptr %slot104, align 8
  %v631 = load i32, ptr %slot104, align 8
  %cv632 = zext i32 %v631 to i64
  %cond633 = icmp ne i64 %cv632, 0
  br i1 %cond633, label %bb_rcglast121, label %bb_rcgdec121
bb_rcglast121:
  %v634 = load i64, ptr %slot95, align 8
  %op635 = sub i64 %v634, 32
  store i64 %op635, ptr %slot105, align 8
  %v636 = load i64, ptr %slot95, align 8
  %p637 = inttoptr i64 %v636 to ptr
  %rgep638 = getelementptr i8, ptr %p637, i64 -32
  %ld639 = load i64, ptr %rgep638, align 8, !alias.scope !9, !noalias !10
  store i64 %ld639, ptr %slot106, align 8
  %v640 = load i64, ptr %slot106, align 8
  %cmp641 = icmp ne i64 %v640, 0
  %cv642 = zext i1 %cmp641 to i32
  store i32 %cv642, ptr %slot107, align 8
  %v643 = load i32, ptr %slot107, align 8
  %cv644 = zext i32 %v643 to i64
  %cond645 = icmp ne i64 %cv644, 0
  br i1 %cond645, label %bb_rcgdec121, label %bb_rcgslow121
bb_rcgslow121:
  %v646 = load i64, ptr %slot94, align 8
  %v647 = load i64, ptr %slot91, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v646, i64 %v647) nomerge, !dbg !114
  br label %bb_rcgdone121
bb_rcgdec121:
  %v648 = load i64, ptr %slot103, align 8
  %v649 = load i64, ptr %slot95, align 8
  %p650 = inttoptr i64 %v649 to ptr
  %rgep651 = getelementptr i8, ptr %p650, i64 -24
  store i64 %v648, ptr %rgep651, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear121
bb_rcgclear121:
  %v652 = load i64, ptr %slot91, align 8
  %p653 = inttoptr i64 %v652 to ptr
  store i64 0, ptr %p653, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone121
bb_rcgdone121:
  br label %bb_rcslotdone105
bb_rcslotowner105:
  %v654 = load i64, ptr %slot20, align 8
  store i64 %v654, ptr %slot108, align 8
  %v655 = load i64, ptr %slot91, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i64, ptr %p656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld657, ptr %slot109, align 8
  %v658 = load i64, ptr %slot109, align 8
  %cmp659 = icmp ne i64 %v658, 0
  %cv660 = zext i1 %cmp659 to i32
  store i32 %cv660, ptr %slot110, align 8
  %v661 = load i32, ptr %slot110, align 8
  %cv662 = zext i32 %v661 to i64
  %cond663 = icmp ne i64 %cv662, 0
  br i1 %cond663, label %bb_rcgnn136, label %bb_rcgdone136
bb_rcgnn136:
  %v664 = load i64, ptr %slot109, align 8
  %op665 = sub i64 %v664, 16
  store i64 %op665, ptr %slot111, align 8
  %v666 = load i64, ptr %slot109, align 8
  %p667 = inttoptr i64 %v666 to ptr
  %rgep668 = getelementptr i8, ptr %p667, i64 -16
  %ld669 = load i64, ptr %rgep668, align 8, !alias.scope !9, !noalias !10
  store i64 %ld669, ptr %slot112, align 8
  %v670 = load i64, ptr %slot112, align 8
  %op671 = and i64 %v670, 4611686018427387906
  store i64 %op671, ptr %slot113, align 8
  %v672 = load i64, ptr %slot113, align 8
  %cmp673 = icmp ne i64 %v672, 0
  %cv674 = zext i1 %cmp673 to i32
  store i32 %cv674, ptr %slot114, align 8
  %v675 = load i32, ptr %slot114, align 8
  %cv676 = zext i32 %v675 to i64
  %cond677 = icmp ne i64 %cv676, 0
  br i1 %cond677, label %bb_rcgclear136, label %bb_rcgcounted136
bb_rcgcounted136:
  %v678 = load i64, ptr %slot109, align 8
  %op679 = sub i64 %v678, 32
  store i64 %op679, ptr %slot115, align 8
  %v680 = load i64, ptr %slot109, align 8
  %p681 = inttoptr i64 %v680 to ptr
  %rgep682 = getelementptr i8, ptr %p681, i64 -32
  %ld683 = load i64, ptr %rgep682, align 8, !alias.scope !9, !noalias !10
  store i64 %ld683, ptr %slot116, align 8
  %v684 = load i64, ptr %slot116, align 8
  %op685 = sub i64 %v684, 1
  store i64 %op685, ptr %slot117, align 8
  %v686 = load i64, ptr %slot117, align 8
  %cmp687 = icmp eq i64 %v686, 0
  %cv688 = zext i1 %cmp687 to i32
  store i32 %cv688, ptr %slot118, align 8
  %v689 = load i32, ptr %slot118, align 8
  %cv690 = zext i32 %v689 to i64
  %cond691 = icmp ne i64 %cv690, 0
  br i1 %cond691, label %bb_rcglast136, label %bb_rcgdec136
bb_rcglast136:
  %v692 = load i64, ptr %slot109, align 8
  %op693 = sub i64 %v692, 24
  store i64 %op693, ptr %slot119, align 8
  %v694 = load i64, ptr %slot109, align 8
  %p695 = inttoptr i64 %v694 to ptr
  %rgep696 = getelementptr i8, ptr %p695, i64 -24
  %ld697 = load i64, ptr %rgep696, align 8, !alias.scope !9, !noalias !10
  store i64 %ld697, ptr %slot120, align 8
  %v698 = load i64, ptr %slot120, align 8
  %cmp699 = icmp ne i64 %v698, 0
  %cv700 = zext i1 %cmp699 to i32
  store i32 %cv700, ptr %slot121, align 8
  %v701 = load i32, ptr %slot121, align 8
  %cv702 = zext i32 %v701 to i64
  %cond703 = icmp ne i64 %cv702, 0
  br i1 %cond703, label %bb_rcgdec136, label %bb_rcgslow136
bb_rcgslow136:
  %v704 = load i64, ptr %slot108, align 8
  %v705 = load i64, ptr %slot91, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v704, i64 %v705) nomerge, !dbg !114
  br label %bb_rcgdone136
bb_rcgdec136:
  %v706 = load i64, ptr %slot117, align 8
  %v707 = load i64, ptr %slot109, align 8
  %p708 = inttoptr i64 %v707 to ptr
  %rgep709 = getelementptr i8, ptr %p708, i64 -32
  store i64 %v706, ptr %rgep709, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear136
bb_rcgclear136:
  %v710 = load i64, ptr %slot91, align 8
  %p711 = inttoptr i64 %v710 to ptr
  store i64 0, ptr %p711, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone136
bb_rcgdone136:
  br label %bb_rcslotdone105
bb_rcslotdone105:
  %v712 = load i64, ptr %slot14, align 8
  store i64 %v712, ptr %slot122, align 8
  %v713 = load i64, ptr %slot88, align 8
  %p714 = inttoptr i64 %v713 to ptr
  %ld715 = load i64, ptr %p714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld715, ptr %slot123, align 8
  %v716 = load i64, ptr %slot123, align 8
  %v717 = load i64, ptr %slot122, align 8
  %p718 = inttoptr i64 %v717 to ptr
  store i64 %v716, ptr %p718, align 8, !alias.scope !3, !noalias !4
  %v719 = load i64, ptr %slot6, align 8
  %p720 = inttoptr i64 %v719 to ptr
  store i32 2, ptr %p720, align 4, !alias.scope !3, !noalias !4
  %v721 = load i64, ptr %slot6, align 8
  %p722 = inttoptr i64 %v721 to ptr
  store i32 8, ptr %p722, align 4, !alias.scope !3, !noalias !4
  %v723 = load i64, ptr %slot5, align 8
  %p724 = inttoptr i64 %v723 to ptr
  store i32 1, ptr %p724, align 4, !alias.scope !3, !noalias !4
  %v725 = load i64, ptr %slot9, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i32 0, ptr %p726, align 4, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot18, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i64 0, ptr %p728, align 8, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot18, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %ld731 = load i64, ptr %p730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld731, ptr %slot124, align 8
  %v732 = load i64, ptr %slot124, align 8
  %v733 = load i64, ptr %slot15, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 %v732, ptr %p734, align 8, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot14, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld737, ptr %slot125, align 8
  %v738 = load i64, ptr %slot125, align 8
  %op739 = add i64 %v738, 0
  store i64 %op739, ptr %slot126, align 8
  %v740 = load i64, ptr %slot126, align 8
  %p741 = inttoptr i64 %v740 to ptr
  %ld742 = load i64, ptr %p741, align 8, !alias.scope !6, !noalias !7
  store i64 %ld742, ptr %slot127, align 8
  %v743 = load i64, ptr %slot127, align 8
  %v744 = load i64, ptr %slot18, align 8
  %p745 = inttoptr i64 %v744 to ptr
  store i64 %v743, ptr %p745, align 8, !alias.scope !3, !noalias !4
  %v746 = load i64, ptr %slot18, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %ld748 = load i64, ptr %p747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld748, ptr %slot128, align 8
  %v749 = load i64, ptr %slot128, align 8
  %v750 = load i64, ptr %slot18, align 8
  %p751 = inttoptr i64 %v750 to ptr
  store i64 %v749, ptr %p751, align 8, !alias.scope !3, !noalias !4
  %v752 = load i64, ptr %slot18, align 8
  %p753 = inttoptr i64 %v752 to ptr
  %ld754 = load i64, ptr %p753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld754, ptr %slot129, align 8
  %v755 = load i64, ptr %slot129, align 8
  %v756 = load i64, ptr %slot16, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i64 %v755, ptr %p757, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i9:
  %v758 = load i64, ptr %slot15, align 8
  %p759 = inttoptr i64 %v758 to ptr
  %ld760 = load i64, ptr %p759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld760, ptr %slot130, align 8
  %v761 = load i64, ptr %slot130, align 8
  %v762 = load i64, ptr %slot18, align 8
  %p763 = inttoptr i64 %v762 to ptr
  store i64 %v761, ptr %p763, align 8, !alias.scope !3, !noalias !4
  %v764 = load i64, ptr %slot16, align 8
  %p765 = inttoptr i64 %v764 to ptr
  %ld766 = load i64, ptr %p765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld766, ptr %slot131, align 8
  %v767 = load i64, ptr %slot131, align 8
  %v768 = load i64, ptr %slot19, align 8
  %p769 = inttoptr i64 %v768 to ptr
  store i64 %v767, ptr %p769, align 8, !alias.scope !3, !noalias !4
  %v770 = load i64, ptr %slot19, align 8
  %p771 = inttoptr i64 %v770 to ptr
  %ld772 = load i64, ptr %p771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld772, ptr %slot132, align 8
  %v773 = load i64, ptr %slot18, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %ld775 = load i64, ptr %p774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld775, ptr %slot133, align 8
  %v776 = load i64, ptr %slot133, align 8
  %v777 = load i64, ptr %slot132, align 8
  %cmp778 = icmp slt i64 %v776, %v777
  %cv779 = zext i1 %cmp778 to i64
  store i64 %cv779, ptr %slot134, align 8
  %v780 = load i64, ptr %slot134, align 8
  %v781 = load i64, ptr %slot18, align 8
  %p782 = inttoptr i64 %v781 to ptr
  store i64 %v780, ptr %p782, align 8, !alias.scope !3, !noalias !4
  %v783 = load i64, ptr %slot18, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %ld785 = load i64, ptr %p784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld785, ptr %slot135, align 8
  %v786 = load i64, ptr %slot135, align 8
  %cond787 = icmp ne i64 %v786, 0
  br i1 %cond787, label %bb_next158, label %bb_i35
bb_next158:
  %v788 = load i64, ptr %slot16, align 8
  %p789 = inttoptr i64 %v788 to ptr
  %ld790 = load i64, ptr %p789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld790, ptr %slot136, align 8
  %v791 = load i64, ptr %slot136, align 8
  %v792 = load i64, ptr %slot18, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i64 %v791, ptr %p793, align 8, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot14, align 8
  %p795 = inttoptr i64 %v794 to ptr
  %ld796 = load i64, ptr %p795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld796, ptr %slot137, align 8
  %v797 = load i64, ptr %slot18, align 8
  %p798 = inttoptr i64 %v797 to ptr
  %ld799 = load i64, ptr %p798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld799, ptr %slot138, align 8
  %v800 = load i64, ptr %slot137, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i64, ptr %p801, align 8, !alias.scope !6, !noalias !7
  store i64 %ld802, ptr %slot139, align 8
  %v803 = load i64, ptr %slot139, align 8
  %v804 = load i64, ptr %slot138, align 8
  %cmp805 = icmp eq i64 %v803, %v804
  %cv806 = zext i1 %cmp805 to i64
  store i64 %cv806, ptr %slot140, align 8
  %v807 = load i64, ptr %slot140, align 8
  %cond808 = icmp ne i64 %v807, 0
  br i1 %cond808, label %bb_success163, label %bb_failed163
bb_failed163:
  %v809 = load i64, ptr %slot1, align 8
  %p810 = inttoptr i64 %v809 to ptr
  call void @myl_qbe_fail_iteration(ptr %p810) nomerge, !dbg !116
  unreachable
bb_success163:
  %v811 = load i64, ptr %slot18, align 8
  %p812 = inttoptr i64 %v811 to ptr
  store i64 0, ptr %p812, align 8, !alias.scope !3, !noalias !4
  %v813 = load i64, ptr %slot15, align 8
  %p814 = inttoptr i64 %v813 to ptr
  %ld815 = load i64, ptr %p814, align 8, !alias.scope !3, !noalias !4
  store i64 %ld815, ptr %slot141, align 8
  %v816 = load i64, ptr %slot141, align 8
  %v817 = load i64, ptr %slot18, align 8
  %p818 = inttoptr i64 %v817 to ptr
  store i64 %v816, ptr %p818, align 8, !alias.scope !3, !noalias !4
  %v819 = load i64, ptr %slot14, align 8
  %p820 = inttoptr i64 %v819 to ptr
  %ld821 = load i64, ptr %p820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld821, ptr %slot142, align 8
  %v822 = load i64, ptr %slot18, align 8
  %p823 = inttoptr i64 %v822 to ptr
  %ld824 = load i64, ptr %p823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld824, ptr %slot143, align 8
  %v825 = load i64, ptr %slot142, align 8
  %p826 = inttoptr i64 %v825 to ptr
  %ld827 = load i64, ptr %p826, align 8, !alias.scope !6, !noalias !7
  store i64 %ld827, ptr %slot144, align 8
  %v828 = load i64, ptr %slot143, align 8
  %v829 = load i64, ptr %slot144, align 8
  %cmp830 = icmp ult i64 %v828, %v829
  %cv831 = zext i1 %cmp830 to i64
  store i64 %cv831, ptr %slot145, align 8
  %v832 = load i64, ptr %slot145, align 8
  %cond833 = icmp ne i64 %v832, 0
  br i1 %cond833, label %bb_success170, label %bb_failed170
bb_failed170:
  %v834 = load i64, ptr %slot1, align 8
  %p835 = inttoptr i64 %v834 to ptr
  %v836 = load i64, ptr %slot143, align 8
  %v837 = load i64, ptr %slot144, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p835, i64 %v836, i64 %v837) nomerge, !dbg !118
  unreachable
bb_success170:
  %v838 = load i64, ptr %slot142, align 8
  %op839 = add i64 %v838, 32
  store i64 %op839, ptr %slot146, align 8
  %v840 = load i64, ptr %slot146, align 8
  %p841 = inttoptr i64 %v840 to ptr
  %ld842 = load i64, ptr %p841, align 8, !alias.scope !6, !noalias !7
  store i64 %ld842, ptr %slot147, align 8
  %v843 = load i64, ptr %slot147, align 8
  %v844 = load i64, ptr %slot143, align 8
  %op845 = add i64 %v843, %v844
  store i64 %op845, ptr %slot148, align 8
  %v846 = load i64, ptr %slot147, align 8
  %p847 = inttoptr i64 %v846 to ptr
  %v848 = load i64, ptr %slot143, align 8
  %egep849 = getelementptr i8, ptr %p847, i64 %v848
  %ld850 = load i8, ptr %egep849, align 1, !alias.scope !12, !noalias !13
  %ext851 = zext i8 %ld850 to i64
  store i64 %ext851, ptr %slot149, align 8
  %v852 = load i64, ptr %slot149, align 8
  %v853 = load i64, ptr %slot18, align 8
  %p854 = inttoptr i64 %v853 to ptr
  store i64 %v852, ptr %p854, align 8, !alias.scope !3, !noalias !4
  %v855 = load i64, ptr %slot18, align 8
  %p856 = inttoptr i64 %v855 to ptr
  %ld857 = load i64, ptr %p856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld857, ptr %slot150, align 8
  %v858 = load i64, ptr %slot150, align 8
  %v859 = load i64, ptr %slot18, align 8
  %p860 = inttoptr i64 %v859 to ptr
  store i64 %v858, ptr %p860, align 8, !alias.scope !3, !noalias !4
  %v861 = load i64, ptr %slot18, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %ld863 = load i64, ptr %p862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld863, ptr %slot151, align 8
  %v864 = load i64, ptr %slot151, align 8
  %v865 = load i64, ptr %slot17, align 8
  %p866 = inttoptr i64 %v865 to ptr
  store i64 %v864, ptr %p866, align 8, !alias.scope !3, !noalias !4
  %v867 = load i64, ptr %slot13, align 8
  %p868 = inttoptr i64 %v867 to ptr
  %ld869 = load i64, ptr %p868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld869, ptr %slot152, align 8
  %v870 = load i64, ptr %slot152, align 8
  %v871 = load i64, ptr %slot18, align 8
  %p872 = inttoptr i64 %v871 to ptr
  store i64 %v870, ptr %p872, align 8, !alias.scope !3, !noalias !4
  %v873 = load i64, ptr %slot17, align 8
  %p874 = inttoptr i64 %v873 to ptr
  %ld875 = load i64, ptr %p874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld875, ptr %slot153, align 8
  %v876 = load i64, ptr %slot153, align 8
  %v877 = load i64, ptr %slot19, align 8
  %p878 = inttoptr i64 %v877 to ptr
  store i64 %v876, ptr %p878, align 8, !alias.scope !3, !noalias !4
  %v879 = load i64, ptr %slot19, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %ld881 = load i64, ptr %p880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld881, ptr %slot154, align 8
  %v882 = load i64, ptr %slot154, align 8
  %cmp883 = icmp slt i64 %v882, 0
  %cv884 = zext i1 %cmp883 to i64
  store i64 %cv884, ptr %slot155, align 8
  %v885 = load i64, ptr %slot154, align 8
  %cmp886 = icmp sgt i64 %v885, 4294967295
  %cv887 = zext i1 %cmp886 to i64
  store i64 %cv887, ptr %slot156, align 8
  %v888 = load i64, ptr %slot155, align 8
  %v889 = load i64, ptr %slot156, align 8
  %op890 = or i64 %v888, %v889
  store i64 %op890, ptr %slot157, align 8
  %v891 = load i64, ptr %slot157, align 8
  %cond892 = icmp ne i64 %v891, 0
  br i1 %cond892, label %bb_cast_overflow184, label %bb_cast_ok184
bb_cast_overflow184:
  %v893 = load i64, ptr %slot1, align 8
  %p894 = inttoptr i64 %v893 to ptr
  %v895 = load i64, ptr %slot154, align 8
  call void @myl_qbe_fail_cast(ptr %p894, i64 %v895, i64 32) nomerge, !dbg !120
  unreachable
bb_cast_ok184:
  %v896 = load i64, ptr %slot154, align 8
  %v897 = load i64, ptr %slot19, align 8
  %p898 = inttoptr i64 %v897 to ptr
  store i64 %v896, ptr %p898, align 8, !alias.scope !3, !noalias !4
  %v899 = load i64, ptr %slot19, align 8
  %p900 = inttoptr i64 %v899 to ptr
  %ld901 = load i64, ptr %p900, align 8, !alias.scope !3, !noalias !4
  store i64 %ld901, ptr %slot158, align 8
  %v902 = load i64, ptr %slot18, align 8
  %p903 = inttoptr i64 %v902 to ptr
  %ld904 = load i64, ptr %p903, align 8, !alias.scope !3, !noalias !4
  store i64 %ld904, ptr %slot159, align 8
  %v905 = load i64, ptr %slot159, align 8
  %v906 = load i64, ptr %slot158, align 8
  %op907 = xor i64 %v905, %v906
  store i64 %op907, ptr %slot160, align 8
  %v908 = load i64, ptr %slot160, align 8
  %op909 = shl i64 %v908, 32
  store i64 %op909, ptr %slot161, align 8
  %v910 = load i64, ptr %slot161, align 8
  %op911 = lshr i64 %v910, 32
  store i64 %op911, ptr %slot162, align 8
  %v912 = load i64, ptr %slot162, align 8
  %v913 = load i64, ptr %slot18, align 8
  %p914 = inttoptr i64 %v913 to ptr
  store i64 %v912, ptr %p914, align 8, !alias.scope !3, !noalias !4
  %v915 = load i64, ptr %slot19, align 8
  %p916 = inttoptr i64 %v915 to ptr
  store i64 16777619, ptr %p916, align 8, !alias.scope !3, !noalias !4
  %v917 = load i64, ptr %slot19, align 8
  %p918 = inttoptr i64 %v917 to ptr
  %ld919 = load i64, ptr %p918, align 8, !alias.scope !3, !noalias !4
  store i64 %ld919, ptr %slot163, align 8
  %v920 = load i64, ptr %slot18, align 8
  %p921 = inttoptr i64 %v920 to ptr
  %ld922 = load i64, ptr %p921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld922, ptr %slot164, align 8
  %v923 = load i64, ptr %slot164, align 8
  %v924 = load i64, ptr %slot163, align 8
  %op925 = mul i64 %v923, %v924
  store i64 %op925, ptr %slot165, align 8
  %v926 = load i64, ptr %slot165, align 8
  %op927 = shl i64 %v926, 32
  store i64 %op927, ptr %slot166, align 8
  %v928 = load i64, ptr %slot166, align 8
  %op929 = lshr i64 %v928, 32
  store i64 %op929, ptr %slot167, align 8
  %v930 = load i64, ptr %slot167, align 8
  %v931 = load i64, ptr %slot18, align 8
  %p932 = inttoptr i64 %v931 to ptr
  store i64 %v930, ptr %p932, align 8, !alias.scope !3, !noalias !4
  %v933 = load i64, ptr %slot18, align 8
  %p934 = inttoptr i64 %v933 to ptr
  %ld935 = load i64, ptr %p934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld935, ptr %slot168, align 8
  %v936 = load i64, ptr %slot168, align 8
  %v937 = load i64, ptr %slot13, align 8
  %p938 = inttoptr i64 %v937 to ptr
  store i64 %v936, ptr %p938, align 8, !alias.scope !3, !noalias !4
  %v939 = load i64, ptr %slot16, align 8
  %p940 = inttoptr i64 %v939 to ptr
  %ld941 = load i64, ptr %p940, align 8, !alias.scope !3, !noalias !4
  store i64 %ld941, ptr %slot169, align 8
  %v942 = load i64, ptr %slot169, align 8
  %v943 = load i64, ptr %slot18, align 8
  %p944 = inttoptr i64 %v943 to ptr
  store i64 %v942, ptr %p944, align 8, !alias.scope !3, !noalias !4
  %v945 = load i64, ptr %slot14, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %ld947 = load i64, ptr %p946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld947, ptr %slot170, align 8
  %v948 = load i64, ptr %slot18, align 8
  %p949 = inttoptr i64 %v948 to ptr
  %ld950 = load i64, ptr %p949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld950, ptr %slot171, align 8
  %v951 = load i64, ptr %slot170, align 8
  %p952 = inttoptr i64 %v951 to ptr
  %ld953 = load i64, ptr %p952, align 8, !alias.scope !6, !noalias !7
  store i64 %ld953, ptr %slot172, align 8
  %v954 = load i64, ptr %slot172, align 8
  %v955 = load i64, ptr %slot171, align 8
  %cmp956 = icmp eq i64 %v954, %v955
  %cv957 = zext i1 %cmp956 to i64
  store i64 %cv957, ptr %slot173, align 8
  %v958 = load i64, ptr %slot173, align 8
  %cond959 = icmp ne i64 %v958, 0
  br i1 %cond959, label %bb_success201, label %bb_failed201
bb_failed201:
  %v960 = load i64, ptr %slot1, align 8
  %p961 = inttoptr i64 %v960 to ptr
  call void @myl_qbe_fail_iteration(ptr %p961) nomerge, !dbg !122
  unreachable
bb_success201:
  %v962 = load i64, ptr %slot18, align 8
  %p963 = inttoptr i64 %v962 to ptr
  store i64 0, ptr %p963, align 8, !alias.scope !3, !noalias !4
  %v964 = load i64, ptr %slot15, align 8
  %p965 = inttoptr i64 %v964 to ptr
  %ld966 = load i64, ptr %p965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld966, ptr %slot174, align 8
  %v967 = load i64, ptr %slot174, align 8
  %v968 = load i64, ptr %slot18, align 8
  %p969 = inttoptr i64 %v968 to ptr
  store i64 %v967, ptr %p969, align 8, !alias.scope !3, !noalias !4
  %v970 = load i64, ptr %slot19, align 8
  %p971 = inttoptr i64 %v970 to ptr
  store i64 1, ptr %p971, align 8, !alias.scope !3, !noalias !4
  %v972 = load i64, ptr %slot19, align 8
  %p973 = inttoptr i64 %v972 to ptr
  %ld974 = load i64, ptr %p973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld974, ptr %slot175, align 8
  %v975 = load i64, ptr %slot18, align 8
  %p976 = inttoptr i64 %v975 to ptr
  %ld977 = load i64, ptr %p976, align 8, !alias.scope !3, !noalias !4
  store i64 %ld977, ptr %slot176, align 8
  %v978 = load i64, ptr %slot176, align 8
  %v979 = load i64, ptr %slot175, align 8
  %ovpair981 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v978, i64 %v979)
  %op980 = extractvalue { i64, i1 } %ovpair981, 0
  %ov982 = extractvalue { i64, i1 } %ovpair981, 1
  store i64 %op980, ptr %slot177, align 8
  %cv983 = zext i1 %ov982 to i64
  store i64 %cv983, ptr %slot178, align 8
  %v984 = load i64, ptr %slot178, align 8
  %cond985 = icmp ne i64 %v984, 0
  br i1 %cond985, label %bb_overflow205, label %bb_checked205
bb_overflow205:
  %v986 = load i64, ptr %slot1, align 8
  %p987 = inttoptr i64 %v986 to ptr
  %v988 = load i64, ptr %slot176, align 8
  %v989 = load i64, ptr %slot175, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p987, i64 0, i64 %v988, i64 %v989, i64 64) nomerge, !dbg !124
  unreachable
bb_checked205:
  %v990 = load i64, ptr %slot177, align 8
  %v991 = load i64, ptr %slot18, align 8
  %p992 = inttoptr i64 %v991 to ptr
  store i64 %v990, ptr %p992, align 8, !alias.scope !3, !noalias !4
  %v993 = load i64, ptr %slot18, align 8
  %p994 = inttoptr i64 %v993 to ptr
  %ld995 = load i64, ptr %p994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld995, ptr %slot179, align 8
  %v996 = load i64, ptr %slot179, align 8
  %v997 = load i64, ptr %slot15, align 8
  %p998 = inttoptr i64 %v997 to ptr
  store i64 %v996, ptr %p998, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i35:
  %v999 = load i64, ptr %slot13, align 8
  %p1000 = inttoptr i64 %v999 to ptr
  %ld1001 = load i64, ptr %p1000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1001, ptr %slot180, align 8
  %v1002 = load i64, ptr %slot180, align 8
  %v1003 = load i64, ptr %slot18, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  store i64 %v1002, ptr %p1004, align 8, !alias.scope !3, !noalias !4
  %v1005 = load i64, ptr %slot18, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  %ld1007 = load i64, ptr %p1006, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1007, ptr %slot181, align 8
  %v1008 = load i64, ptr %slot7, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  %ld1010 = load i32, ptr %p1009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1010, ptr %slot182, align 8
  %v1011 = load i32, ptr %slot182, align 8
  %cv1012 = zext i32 %v1011 to i64
  %cond1013 = icmp ne i64 %cv1012, 0
  br i1 %cond1013, label %bb_rcslotdrop212, label %bb_rcslotdone212
bb_rcslotdrop212:
  %v1014 = load i64, ptr %slot7, align 8
  %p1015 = inttoptr i64 %v1014 to ptr
  store i32 0, ptr %p1015, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone212
bb_rcslotdone212:
  %v1016 = load i64, ptr %slot5, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %ld1018 = load i32, ptr %p1017, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1018, ptr %slot183, align 8
  %v1019 = load i32, ptr %slot183, align 8
  %cv1020 = zext i32 %v1019 to i64
  %cond1021 = icmp ne i64 %cv1020, 0
  br i1 %cond1021, label %bb_rcslotdrop215, label %bb_rcslotdone215
bb_rcslotdrop215:
  %v1022 = load i64, ptr %slot5, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  store i32 0, ptr %p1023, align 4, !alias.scope !3, !noalias !4
  %v1024 = load i64, ptr %slot14, align 8
  store i64 %v1024, ptr %slot184, align 8
  %v1025 = load i64, ptr %slot6, align 8
  %p1026 = inttoptr i64 %v1025 to ptr
  %ld1027 = load i32, ptr %p1026, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1027, ptr %slot185, align 8
  %v1028 = load i32, ptr %slot185, align 8
  %op1029 = and i32 %v1028, 28
  store i32 %op1029, ptr %slot186, align 8
  %v1030 = load i32, ptr %slot186, align 8
  %cv1031 = zext i32 %v1030 to i64
  %cond1032 = icmp ne i64 %cv1031, 0
  br i1 %cond1032, label %bb_rcslotrole215, label %bb_rcslotowner215
bb_rcslotrole215:
  %v1033 = load i64, ptr %slot20, align 8
  store i64 %v1033, ptr %slot187, align 8
  %v1034 = load i64, ptr %slot184, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %ld1036 = load i64, ptr %p1035, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1036, ptr %slot188, align 8
  %v1037 = load i64, ptr %slot188, align 8
  %cmp1038 = icmp ne i64 %v1037, 0
  %cv1039 = zext i1 %cmp1038 to i32
  store i32 %cv1039, ptr %slot189, align 8
  %v1040 = load i32, ptr %slot189, align 8
  %cv1041 = zext i32 %v1040 to i64
  %cond1042 = icmp ne i64 %cv1041, 0
  br i1 %cond1042, label %bb_rcgnn231, label %bb_rcgdone231
bb_rcgnn231:
  %v1043 = load i64, ptr %slot188, align 8
  %op1044 = sub i64 %v1043, 16
  store i64 %op1044, ptr %slot190, align 8
  %v1045 = load i64, ptr %slot188, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  %rgep1047 = getelementptr i8, ptr %p1046, i64 -16
  %ld1048 = load i64, ptr %rgep1047, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1048, ptr %slot191, align 8
  %v1049 = load i64, ptr %slot191, align 8
  %op1050 = and i64 %v1049, 4611686018427387906
  store i64 %op1050, ptr %slot192, align 8
  %v1051 = load i64, ptr %slot192, align 8
  %cmp1052 = icmp ne i64 %v1051, 0
  %cv1053 = zext i1 %cmp1052 to i32
  store i32 %cv1053, ptr %slot193, align 8
  %v1054 = load i32, ptr %slot193, align 8
  %cv1055 = zext i32 %v1054 to i64
  %cond1056 = icmp ne i64 %cv1055, 0
  br i1 %cond1056, label %bb_rcgclear231, label %bb_rcgcounted231
bb_rcgcounted231:
  %v1057 = load i64, ptr %slot188, align 8
  %op1058 = sub i64 %v1057, 24
  store i64 %op1058, ptr %slot194, align 8
  %v1059 = load i64, ptr %slot188, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  %rgep1061 = getelementptr i8, ptr %p1060, i64 -24
  %ld1062 = load i64, ptr %rgep1061, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1062, ptr %slot195, align 8
  %v1063 = load i64, ptr %slot195, align 8
  %op1064 = sub i64 %v1063, 1
  store i64 %op1064, ptr %slot196, align 8
  %v1065 = load i64, ptr %slot196, align 8
  %cmp1066 = icmp eq i64 %v1065, 0
  %cv1067 = zext i1 %cmp1066 to i32
  store i32 %cv1067, ptr %slot197, align 8
  %v1068 = load i32, ptr %slot197, align 8
  %cv1069 = zext i32 %v1068 to i64
  %cond1070 = icmp ne i64 %cv1069, 0
  br i1 %cond1070, label %bb_rcglast231, label %bb_rcgdec231
bb_rcglast231:
  %v1071 = load i64, ptr %slot188, align 8
  %op1072 = sub i64 %v1071, 32
  store i64 %op1072, ptr %slot198, align 8
  %v1073 = load i64, ptr %slot188, align 8
  %p1074 = inttoptr i64 %v1073 to ptr
  %rgep1075 = getelementptr i8, ptr %p1074, i64 -32
  %ld1076 = load i64, ptr %rgep1075, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1076, ptr %slot199, align 8
  %v1077 = load i64, ptr %slot199, align 8
  %cmp1078 = icmp ne i64 %v1077, 0
  %cv1079 = zext i1 %cmp1078 to i32
  store i32 %cv1079, ptr %slot200, align 8
  %v1080 = load i32, ptr %slot200, align 8
  %cv1081 = zext i32 %v1080 to i64
  %cond1082 = icmp ne i64 %cv1081, 0
  br i1 %cond1082, label %bb_rcgdec231, label %bb_rcgslow231
bb_rcgslow231:
  %v1083 = load i64, ptr %slot187, align 8
  %v1084 = load i64, ptr %slot184, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1083, i64 %v1084) nomerge, !dbg !126
  br label %bb_rcgdone231
bb_rcgdec231:
  %v1085 = load i64, ptr %slot196, align 8
  %v1086 = load i64, ptr %slot188, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  %rgep1088 = getelementptr i8, ptr %p1087, i64 -24
  store i64 %v1085, ptr %rgep1088, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear231
bb_rcgclear231:
  %v1089 = load i64, ptr %slot184, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  store i64 0, ptr %p1090, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone231
bb_rcgdone231:
  br label %bb_rcslotdone215
bb_rcslotowner215:
  %v1091 = load i64, ptr %slot20, align 8
  store i64 %v1091, ptr %slot201, align 8
  %v1092 = load i64, ptr %slot184, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %ld1094 = load i64, ptr %p1093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1094, ptr %slot202, align 8
  %v1095 = load i64, ptr %slot202, align 8
  %cmp1096 = icmp ne i64 %v1095, 0
  %cv1097 = zext i1 %cmp1096 to i32
  store i32 %cv1097, ptr %slot203, align 8
  %v1098 = load i32, ptr %slot203, align 8
  %cv1099 = zext i32 %v1098 to i64
  %cond1100 = icmp ne i64 %cv1099, 0
  br i1 %cond1100, label %bb_rcgnn246, label %bb_rcgdone246
bb_rcgnn246:
  %v1101 = load i64, ptr %slot202, align 8
  %op1102 = sub i64 %v1101, 16
  store i64 %op1102, ptr %slot204, align 8
  %v1103 = load i64, ptr %slot202, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  %rgep1105 = getelementptr i8, ptr %p1104, i64 -16
  %ld1106 = load i64, ptr %rgep1105, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1106, ptr %slot205, align 8
  %v1107 = load i64, ptr %slot205, align 8
  %op1108 = and i64 %v1107, 4611686018427387906
  store i64 %op1108, ptr %slot206, align 8
  %v1109 = load i64, ptr %slot206, align 8
  %cmp1110 = icmp ne i64 %v1109, 0
  %cv1111 = zext i1 %cmp1110 to i32
  store i32 %cv1111, ptr %slot207, align 8
  %v1112 = load i32, ptr %slot207, align 8
  %cv1113 = zext i32 %v1112 to i64
  %cond1114 = icmp ne i64 %cv1113, 0
  br i1 %cond1114, label %bb_rcgclear246, label %bb_rcgcounted246
bb_rcgcounted246:
  %v1115 = load i64, ptr %slot202, align 8
  %op1116 = sub i64 %v1115, 32
  store i64 %op1116, ptr %slot208, align 8
  %v1117 = load i64, ptr %slot202, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %rgep1119 = getelementptr i8, ptr %p1118, i64 -32
  %ld1120 = load i64, ptr %rgep1119, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1120, ptr %slot209, align 8
  %v1121 = load i64, ptr %slot209, align 8
  %op1122 = sub i64 %v1121, 1
  store i64 %op1122, ptr %slot210, align 8
  %v1123 = load i64, ptr %slot210, align 8
  %cmp1124 = icmp eq i64 %v1123, 0
  %cv1125 = zext i1 %cmp1124 to i32
  store i32 %cv1125, ptr %slot211, align 8
  %v1126 = load i32, ptr %slot211, align 8
  %cv1127 = zext i32 %v1126 to i64
  %cond1128 = icmp ne i64 %cv1127, 0
  br i1 %cond1128, label %bb_rcglast246, label %bb_rcgdec246
bb_rcglast246:
  %v1129 = load i64, ptr %slot202, align 8
  %op1130 = sub i64 %v1129, 24
  store i64 %op1130, ptr %slot212, align 8
  %v1131 = load i64, ptr %slot202, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  %rgep1133 = getelementptr i8, ptr %p1132, i64 -24
  %ld1134 = load i64, ptr %rgep1133, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1134, ptr %slot213, align 8
  %v1135 = load i64, ptr %slot213, align 8
  %cmp1136 = icmp ne i64 %v1135, 0
  %cv1137 = zext i1 %cmp1136 to i32
  store i32 %cv1137, ptr %slot214, align 8
  %v1138 = load i32, ptr %slot214, align 8
  %cv1139 = zext i32 %v1138 to i64
  %cond1140 = icmp ne i64 %cv1139, 0
  br i1 %cond1140, label %bb_rcgdec246, label %bb_rcgslow246
bb_rcgslow246:
  %v1141 = load i64, ptr %slot201, align 8
  %v1142 = load i64, ptr %slot184, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1141, i64 %v1142) nomerge, !dbg !126
  br label %bb_rcgdone246
bb_rcgdec246:
  %v1143 = load i64, ptr %slot210, align 8
  %v1144 = load i64, ptr %slot202, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %rgep1146 = getelementptr i8, ptr %p1145, i64 -32
  store i64 %v1143, ptr %rgep1146, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear246
bb_rcgclear246:
  %v1147 = load i64, ptr %slot184, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  store i64 0, ptr %p1148, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone246
bb_rcgdone246:
  br label %bb_rcslotdone215
bb_rcslotdone215:
  %v1149 = load i64, ptr %slot181, align 8
  ret i64 %v1149
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_iteration(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1", linkageName: "myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 13188888942386916461, i64 0, !"myl_f_e060711f47dd91f7fdaf009db492b2192966b80e9870f83025197c8995b9e4b1"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!116 = !DILocation(line: 15, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!118 = !DILocation(line: 18, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!120 = !DILocation(line: 23, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!122 = !DILocation(line: 29, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!124 = !DILocation(line: 33, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!126 = !DILocation(line: 37, column: 0, scope: !127)
