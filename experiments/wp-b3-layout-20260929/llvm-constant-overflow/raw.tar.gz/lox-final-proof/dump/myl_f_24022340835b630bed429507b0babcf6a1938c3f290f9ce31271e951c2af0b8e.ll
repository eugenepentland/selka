target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %callresult53 = alloca [24 x i8], align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %callresult152 = alloca [16 x i8], align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %callresult360 = alloca [16 x i8], align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i32, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i32, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %callresult487 = alloca [16 x i8], align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %callresult614 = alloca [16 x i8], align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v724 = load i64, ptr %slot1, align 8
  %op725 = add i64 %v724, 32
  store i64 %op725, ptr %slot4, align 8
  %mem726 = alloca i8, i64 24, align 8
  %ptr727 = ptrtoint ptr %mem726 to i64
  store i64 %ptr727, ptr %slot5, align 8
  %mem728 = alloca i8, i64 8, align 8
  %ptr729 = ptrtoint ptr %mem728 to i64
  store i64 %ptr729, ptr %slot6, align 8
  %mem730 = alloca i8, i64 8, align 8
  %ptr731 = ptrtoint ptr %mem730 to i64
  store i64 %ptr731, ptr %slot7, align 8
  %mem732 = alloca i8, i64 8, align 8
  %ptr733 = ptrtoint ptr %mem732 to i64
  store i64 %ptr733, ptr %slot8, align 8
  %mem734 = alloca i8, i64 8, align 8
  %ptr735 = ptrtoint ptr %mem734 to i64
  store i64 %ptr735, ptr %slot9, align 8
  %mem736 = alloca i8, i64 8, align 8
  %ptr737 = ptrtoint ptr %mem736 to i64
  store i64 %ptr737, ptr %slot10, align 8
  %mem738 = alloca i8, i64 8, align 8
  %ptr739 = ptrtoint ptr %mem738 to i64
  store i64 %ptr739, ptr %slot11, align 8
  %mem740 = alloca i8, i64 8, align 8
  %ptr741 = ptrtoint ptr %mem740 to i64
  store i64 %ptr741, ptr %slot12, align 8
  %mem742 = alloca i8, i64 8, align 8
  %ptr743 = ptrtoint ptr %mem742 to i64
  store i64 %ptr743, ptr %slot13, align 8
  %mem744 = alloca i8, i64 8, align 8
  %ptr745 = ptrtoint ptr %mem744 to i64
  store i64 %ptr745, ptr %slot14, align 8
  %mem746 = alloca i8, i64 304, align 8
  %ptr747 = ptrtoint ptr %mem746 to i64
  store i64 %ptr747, ptr %slot15, align 8
  %mem748 = alloca i8, i64 8, align 8
  %ptr749 = ptrtoint ptr %mem748 to i64
  store i64 %ptr749, ptr %slot16, align 8
  %mem750 = alloca i8, i64 304, align 8
  %ptr751 = ptrtoint ptr %mem750 to i64
  store i64 %ptr751, ptr %slot17, align 8
  %mem752 = alloca i8, i64 8, align 8
  %ptr753 = ptrtoint ptr %mem752 to i64
  store i64 %ptr753, ptr %slot18, align 8
  %mem754 = alloca i8, i64 8, align 8
  %ptr755 = ptrtoint ptr %mem754 to i64
  store i64 %ptr755, ptr %slot19, align 8
  %mem756 = alloca i8, i64 16, align 8
  %ptr757 = ptrtoint ptr %mem756 to i64
  store i64 %ptr757, ptr %slot20, align 8
  %mem758 = alloca i8, i64 208, align 8
  %ptr759 = ptrtoint ptr %mem758 to i64
  store i64 %ptr759, ptr %slot21, align 8
  %mem760 = alloca i8, i64 8, align 8
  %ptr761 = ptrtoint ptr %mem760 to i64
  store i64 %ptr761, ptr %slot22, align 8
  %mem762 = alloca i8, i64 208, align 8
  %ptr763 = ptrtoint ptr %mem762 to i64
  store i64 %ptr763, ptr %slot23, align 8
  %mem764 = alloca i8, i64 16, align 8
  %ptr765 = ptrtoint ptr %mem764 to i64
  store i64 %ptr765, ptr %slot24, align 8
  %mem766 = alloca i8, i64 8, align 8
  %ptr767 = ptrtoint ptr %mem766 to i64
  store i64 %ptr767, ptr %slot25, align 8
  %mem768 = alloca i8, i64 8, align 8
  %ptr769 = ptrtoint ptr %mem768 to i64
  store i64 %ptr769, ptr %slot26, align 8
  %mem770 = alloca i8, i64 8, align 8
  %ptr771 = ptrtoint ptr %mem770 to i64
  store i64 %ptr771, ptr %slot27, align 8
  %mem772 = alloca i8, i64 24, align 8
  %ptr773 = ptrtoint ptr %mem772 to i64
  store i64 %ptr773, ptr %slot28, align 8
  %mem774 = alloca i8, i64 8, align 8
  %ptr775 = ptrtoint ptr %mem774 to i64
  store i64 %ptr775, ptr %slot29, align 8
  %mem776 = alloca i8, i64 304, align 8
  %ptr777 = ptrtoint ptr %mem776 to i64
  store i64 %ptr777, ptr %slot30, align 8
  %mem778 = alloca i8, i64 208, align 8
  %ptr779 = ptrtoint ptr %mem778 to i64
  store i64 %ptr779, ptr %slot31, align 8
  %mem780 = alloca i8, i64 24, align 8
  %ptr781 = ptrtoint ptr %mem780 to i64
  store i64 %ptr781, ptr %slot32, align 8
  %mem782 = alloca i8, i64 304, align 8
  %ptr783 = ptrtoint ptr %mem782 to i64
  store i64 %ptr783, ptr %slot33, align 8
  %mem784 = alloca i8, i64 208, align 8
  %ptr785 = ptrtoint ptr %mem784 to i64
  store i64 %ptr785, ptr %slot34, align 8
  %mem786 = alloca i8, i64 24, align 8
  %ptr787 = ptrtoint ptr %mem786 to i64
  store i64 %ptr787, ptr %slot35, align 8
  %mem788 = alloca i8, i64 24, align 8
  %ptr789 = ptrtoint ptr %mem788 to i64
  store i64 %ptr789, ptr %slot36, align 8
  %mem790 = alloca i8, i64 24, align 8
  %ptr791 = ptrtoint ptr %mem790 to i64
  store i64 %ptr791, ptr %slot37, align 8
  %mem792 = alloca i8, i64 24, align 8
  %ptr793 = ptrtoint ptr %mem792 to i64
  store i64 %ptr793, ptr %slot38, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem794 = alloca i8, i64 8, align 8
  %ptr795 = ptrtoint ptr %mem794 to i64
  store i64 %ptr795, ptr %slot39, align 8
  %v796 = load i64, ptr %slot1, align 8
  %op797 = add i64 %v796, 64
  store i64 %op797, ptr %slot40, align 8
  %v798 = load i64, ptr %slot40, align 8
  %p799 = inttoptr i64 %v798 to ptr
  %ld800 = load i64, ptr %p799, align 8, !alias.scope !4, !noalias !3
  store i64 %ld800, ptr %slot41, align 8
  %stack801 = call ptr @llvm.stacksave()
  %stackaddr802 = ptrtoint ptr %stack801 to i64
  %v803 = load i64, ptr %slot41, align 8
  %cmp804 = icmp ult i64 %stackaddr802, %v803
  %cv805 = zext i1 %cmp804 to i64
  store i64 %cv805, ptr %slot42, align 8
  %v806 = load i64, ptr %slot42, align 8
  %cond807 = icmp ne i64 %v806, 0
  br i1 %cond807, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v808 = load i64, ptr %slot1, align 8
  %p809 = inttoptr i64 %v808 to ptr
  call void @myl_qbe_fail_frame(ptr %p809) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v810 = load i64, ptr %slot2, align 8
  %v811 = load i64, ptr %slot18, align 8
  %p812 = inttoptr i64 %v811 to ptr
  store i64 %v810, ptr %p812, align 8, !alias.scope !3, !noalias !4
  %v813 = load i64, ptr %slot3, align 8
  %v814 = load i64, ptr %slot19, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i64 %v813, ptr %p815, align 8, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot1, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %call818 = call ptr @myl_qbe_heap(ptr %p817) nomerge, !dbg !112
  %calladdr819 = ptrtoint ptr %call818 to i64
  store i64 %calladdr819, ptr %slot43, align 8
  %v820 = load i64, ptr %slot1, align 8
  %p821 = inttoptr i64 %v820 to ptr
  %call822 = call i64 @myl_qbe_region_mark(ptr %p821) nomerge, !dbg !112
  store i64 %call822, ptr %slot44, align 8
  %v823 = load i64, ptr %slot6, align 8
  %p824 = inttoptr i64 %v823 to ptr
  store i32 0, ptr %p824, align 4, !alias.scope !3, !noalias !4
  %v825 = load i64, ptr %slot7, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i32 0, ptr %p826, align 4, !alias.scope !3, !noalias !4
  %v827 = load i64, ptr %slot8, align 8
  %p828 = inttoptr i64 %v827 to ptr
  store i32 0, ptr %p828, align 4, !alias.scope !3, !noalias !4
  %v829 = load i64, ptr %slot9, align 8
  %p830 = inttoptr i64 %v829 to ptr
  store i32 0, ptr %p830, align 4, !alias.scope !3, !noalias !4
  %v831 = load i64, ptr %slot10, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i32 0, ptr %p832, align 4, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot11, align 8
  %p834 = inttoptr i64 %v833 to ptr
  store i32 0, ptr %p834, align 4, !alias.scope !3, !noalias !4
  %v835 = load i64, ptr %slot12, align 8
  %p836 = inttoptr i64 %v835 to ptr
  store i32 0, ptr %p836, align 4, !alias.scope !3, !noalias !4
  %v837 = load i64, ptr %slot13, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i32 0, ptr %p838, align 4, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot14, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i32 0, ptr %p840, align 4, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot7, align 8
  %p842 = inttoptr i64 %v841 to ptr
  store i32 2, ptr %p842, align 4, !alias.scope !3, !noalias !4
  %v843 = load i64, ptr %slot9, align 8
  %p844 = inttoptr i64 %v843 to ptr
  store i32 2, ptr %p844, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v845 = load i64, ptr %slot18, align 8
  %p846 = inttoptr i64 %v845 to ptr
  %ld847 = load i64, ptr %p846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld847, ptr %slot45, align 8
  %v848 = load i64, ptr %slot45, align 8
  %v849 = load i64, ptr %slot26, align 8
  %p850 = inttoptr i64 %v849 to ptr
  store i64 %v848, ptr %p850, align 8, !alias.scope !3, !noalias !4
  %v851 = load i64, ptr %slot19, align 8
  %p852 = inttoptr i64 %v851 to ptr
  %ld853 = load i64, ptr %p852, align 8, !alias.scope !3, !noalias !4
  store i64 %ld853, ptr %slot46, align 8
  %v854 = load i64, ptr %slot46, align 8
  %v855 = load i64, ptr %slot27, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i64 %v854, ptr %p856, align 8, !alias.scope !3, !noalias !4
  %v857 = load i64, ptr %slot27, align 8
  %p858 = inttoptr i64 %v857 to ptr
  %ld859 = load i64, ptr %p858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld859, ptr %slot47, align 8
  %v860 = load i64, ptr %slot47, align 8
  %op861 = add i64 %v860, 40
  store i64 %op861, ptr %slot48, align 8
  %v862 = load i64, ptr %slot48, align 8
  %p863 = inttoptr i64 %v862 to ptr
  %ld864 = load i64, ptr %p863, align 8
  store i64 %ld864, ptr %slot49, align 8
  %v865 = load i64, ptr %slot49, align 8
  %v866 = load i64, ptr %slot27, align 8
  %p867 = inttoptr i64 %v866 to ptr
  store i64 %v865, ptr %p867, align 8, !alias.scope !3, !noalias !4
  %v868 = load i64, ptr %slot26, align 8
  %p869 = inttoptr i64 %v868 to ptr
  %ld870 = load i64, ptr %p869, align 8, !alias.scope !3, !noalias !4
  store i64 %ld870, ptr %slot50, align 8
  %v871 = load i64, ptr %slot27, align 8
  %p872 = inttoptr i64 %v871 to ptr
  %ld873 = load i64, ptr %p872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld873, ptr %slot51, align 8
  %v874 = load i64, ptr %slot1, align 8
  %v875 = load i64, ptr %slot50, align 8
  %v876 = load i64, ptr %slot51, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult53, i64 %v874, i64 %v875, i64 %v876) nomerge, !dbg !114
  %addr877 = ptrtoint ptr %callresult53 to i64
  store i64 %addr877, ptr %slot52, align 8
  %v878 = load i64, ptr %slot52, align 8
  %v879 = load i64, ptr %slot26, align 8
  %p880 = inttoptr i64 %v879 to ptr
  store i64 %v878, ptr %p880, align 8, !alias.scope !3, !noalias !4
  %v881 = load i64, ptr %slot26, align 8
  %p882 = inttoptr i64 %v881 to ptr
  %ld883 = load i64, ptr %p882, align 8, !alias.scope !3, !noalias !4
  store i64 %ld883, ptr %slot54, align 8
  %v884 = load i64, ptr %slot17, align 8
  store i64 %v884, ptr %slot55, align 8
  %v885 = load i64, ptr %slot54, align 8
  %v886 = load i64, ptr %slot55, align 8
  %p887 = inttoptr i64 %v885 to ptr
  %p888 = inttoptr i64 %v886 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p888, ptr %p887, i64 24, i1 false)
  %v889 = load i64, ptr %slot13, align 8
  %p890 = inttoptr i64 %v889 to ptr
  store i32 2, ptr %p890, align 4, !alias.scope !3, !noalias !4
  %v891 = load i64, ptr %slot12, align 8
  %p892 = inttoptr i64 %v891 to ptr
  store i32 1, ptr %p892, align 4, !alias.scope !3, !noalias !4
  %v893 = load i64, ptr %slot10, align 8
  %p894 = inttoptr i64 %v893 to ptr
  %ld895 = load i32, ptr %p894, align 4, !alias.scope !3, !noalias !4
  store i32 %ld895, ptr %slot56, align 8
  %v896 = load i32, ptr %slot56, align 8
  %cv897 = zext i32 %v896 to i64
  %cond898 = icmp ne i64 %cv897, 0
  br i1 %cond898, label %bb_rcslotdrop38, label %bb_rcslotdone38
bb_rcslotdrop38:
  %v899 = load i64, ptr %slot10, align 8
  %p900 = inttoptr i64 %v899 to ptr
  store i32 0, ptr %p900, align 4, !alias.scope !3, !noalias !4
  %v901 = load i64, ptr %slot15, align 8
  store i64 %v901, ptr %slot57, align 8
  %v902 = load i64, ptr %slot11, align 8
  %p903 = inttoptr i64 %v902 to ptr
  %ld904 = load i32, ptr %p903, align 4, !alias.scope !3, !noalias !4
  store i32 %ld904, ptr %slot58, align 8
  %v905 = load i32, ptr %slot58, align 8
  %op906 = and i32 %v905, 28
  store i32 %op906, ptr %slot59, align 8
  %v907 = load i32, ptr %slot59, align 8
  %cv908 = zext i32 %v907 to i64
  %cond909 = icmp ne i64 %cv908, 0
  br i1 %cond909, label %bb_rcslotrole38, label %bb_rcslotowner38
bb_rcslotrole38:
  %v910 = load i64, ptr %slot43, align 8
  store i64 %v910, ptr %slot60, align 8
  %v911 = load i64, ptr %slot60, align 8
  %v912 = load i64, ptr %slot57, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v911, i64 %v912) nomerge, !dbg !114
  br label %bb_rcslotdone38
bb_rcslotowner38:
  %v913 = load i64, ptr %slot43, align 8
  store i64 %v913, ptr %slot61, align 8
  %v914 = load i64, ptr %slot61, align 8
  %v915 = load i64, ptr %slot57, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v914, i64 %v915) nomerge, !dbg !114
  br label %bb_rcslotdone38
bb_rcslotdone38:
  %v916 = load i64, ptr %slot15, align 8
  store i64 %v916, ptr %slot62, align 8
  %v917 = load i64, ptr %slot17, align 8
  store i64 %v917, ptr %slot63, align 8
  %v918 = load i64, ptr %slot63, align 8
  %v919 = load i64, ptr %slot62, align 8
  %p920 = inttoptr i64 %v918 to ptr
  %p921 = inttoptr i64 %v919 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p921, ptr %p920, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot11, align 8
  %p923 = inttoptr i64 %v922 to ptr
  store i32 2, ptr %p923, align 4, !alias.scope !3, !noalias !4
  %v924 = load i64, ptr %slot13, align 8
  %p925 = inttoptr i64 %v924 to ptr
  %ld926 = load i32, ptr %p925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld926, ptr %slot64, align 8
  %v927 = load i32, ptr %slot64, align 8
  %v928 = load i64, ptr %slot11, align 8
  %p929 = inttoptr i64 %v928 to ptr
  store i32 %v927, ptr %p929, align 4, !alias.scope !3, !noalias !4
  %v930 = load i64, ptr %slot12, align 8
  %p931 = inttoptr i64 %v930 to ptr
  store i32 0, ptr %p931, align 4, !alias.scope !3, !noalias !4
  %v932 = load i64, ptr %slot10, align 8
  %p933 = inttoptr i64 %v932 to ptr
  store i32 1, ptr %p933, align 4, !alias.scope !3, !noalias !4
  %v934 = load i64, ptr %slot62, align 8
  %v935 = load i64, ptr %slot26, align 8
  %p936 = inttoptr i64 %v935 to ptr
  store i64 %v934, ptr %p936, align 8, !alias.scope !3, !noalias !4
  %v937 = load i64, ptr %slot26, align 8
  %p938 = inttoptr i64 %v937 to ptr
  %ld939 = load i64, ptr %p938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld939, ptr %slot65, align 8
  %v940 = load i64, ptr %slot65, align 8
  %p941 = inttoptr i64 %v940 to ptr
  %ld942 = load i32, ptr %p941, align 4
  %ext943 = zext i32 %ld942 to i64
  store i64 %ext943, ptr %slot66, align 8
  %v944 = load i64, ptr %slot66, align 8
  %cmp945 = icmp eq i64 %v944, 0
  %cv946 = zext i1 %cmp945 to i64
  store i64 %cv946, ptr %slot67, align 8
  %v947 = load i64, ptr %slot67, align 8
  %cond948 = icmp ne i64 %v947, 0
  br i1 %cond948, label %bb_rctryok54, label %bb_rctryerror54
bb_rctryerror54:
  %p949 = inttoptr i64 ptrtoint (ptr @myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p949, i64 12884901892) "call-inline-cost"="0", !dbg !116
  %v950 = load i64, ptr %slot65, align 8
  %op951 = add i64 %v950, 8
  store i64 %op951, ptr %slot68, align 8
  %v952 = load i64, ptr %slot28, align 8
  store i64 %v952, ptr %slot69, align 8
  %v953 = load i64, ptr %slot69, align 8
  %p954 = inttoptr i64 %v953 to ptr
  store i64 0, ptr %p954, align 8, !alias.scope !3, !noalias !4
  %v955 = load i64, ptr %slot69, align 8
  %p957 = inttoptr i64 %v955 to ptr
  %gep958 = getelementptr i8, ptr %p957, i64 8
  %op956 = ptrtoint ptr %gep958 to i64
  store i64 %op956, ptr %slot70, align 8
  %v959 = load i64, ptr %slot70, align 8
  %p960 = inttoptr i64 %v959 to ptr
  store i64 0, ptr %p960, align 8, !alias.scope !3, !noalias !4
  %v961 = load i64, ptr %slot69, align 8
  %p963 = inttoptr i64 %v961 to ptr
  %gep964 = getelementptr i8, ptr %p963, i64 16
  %op962 = ptrtoint ptr %gep964 to i64
  store i64 %op962, ptr %slot71, align 8
  %v965 = load i64, ptr %slot71, align 8
  %p966 = inttoptr i64 %v965 to ptr
  store i64 0, ptr %p966, align 8, !alias.scope !3, !noalias !4
  %v967 = load i64, ptr %slot69, align 8
  %p968 = inttoptr i64 %v967 to ptr
  store i32 1, ptr %p968, align 4, !alias.scope !3, !noalias !4
  %v969 = load i64, ptr %slot69, align 8
  %p971 = inttoptr i64 %v969 to ptr
  %gep972 = getelementptr i8, ptr %p971, i64 8
  %op970 = ptrtoint ptr %gep972 to i64
  store i64 %op970, ptr %slot72, align 8
  %v973 = load i64, ptr %slot14, align 8
  %p974 = inttoptr i64 %v973 to ptr
  store i32 1, ptr %p974, align 4, !alias.scope !3, !noalias !4
  %v975 = load i64, ptr %slot44, align 8
  store i64 %v975, ptr %slot73, align 8
  %v976 = load i64, ptr %slot43, align 8
  %v977 = load i64, ptr %slot72, align 8
  %v978 = load i64, ptr %slot68, align 8
  %v979 = load i64, ptr %slot73, align 8
  %cv980 = trunc i64 %v979 to i32
  %call981 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v976, i64 %v977, i64 %v978, i32 %cv980) nomerge, !dbg !116
  store i32 %call981, ptr %slot74, align 8
  %v982 = load i32, ptr %slot74, align 8
  %cv983 = zext i32 %v982 to i64
  %cond984 = icmp ne i64 %cv983, 0
  br i1 %cond984, label %bb_rcsuccess65, label %bb_rcfailure65
bb_rcfailure65:
  %v985 = load i64, ptr %slot43, align 8
  %p986 = inttoptr i64 %v985 to ptr
  %call987 = call i32 @myl_rc_take_failure(ptr %p986) nomerge, !dbg !116
  store i32 %call987, ptr %slot75, align 8
  %v988 = load i64, ptr %slot1, align 8
  %p989 = inttoptr i64 %v988 to ptr
  %v990 = load i32, ptr %slot75, align 8
  %call991 = call i32 @myl_qbe_rc_status(ptr %p989, i32 %v990) nomerge, !dbg !116
  store i32 %call991, ptr %slot76, align 8
  br label %bb_failure
bb_rcsuccess65:
  %v992 = load i64, ptr %slot69, align 8
  %v993 = load i64, ptr %slot26, align 8
  %p994 = inttoptr i64 %v993 to ptr
  store i64 %v992, ptr %p994, align 8, !alias.scope !3, !noalias !4
  %v995 = load i64, ptr %slot26, align 8
  %p996 = inttoptr i64 %v995 to ptr
  %ld997 = load i64, ptr %p996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld997, ptr %slot77, align 8
  %v998 = load i64, ptr %slot17, align 8
  store i64 %v998, ptr %slot78, align 8
  %v999 = load i64, ptr %slot77, align 8
  %v1000 = load i64, ptr %slot78, align 8
  %p1001 = inttoptr i64 %v999 to ptr
  %p1002 = inttoptr i64 %v1000 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1002, ptr %p1001, i64 24, i1 false)
  %v1003 = load i64, ptr %slot13, align 8
  %p1004 = inttoptr i64 %v1003 to ptr
  store i32 2, ptr %p1004, align 4, !alias.scope !3, !noalias !4
  %v1005 = load i64, ptr %slot12, align 8
  %p1006 = inttoptr i64 %v1005 to ptr
  store i32 1, ptr %p1006, align 4, !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot10, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  %ld1009 = load i32, ptr %p1008, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1009, ptr %slot79, align 8
  %v1010 = load i32, ptr %slot79, align 8
  %cv1011 = zext i32 %v1010 to i64
  %cond1012 = icmp ne i64 %cv1011, 0
  br i1 %cond1012, label %bb_rcslotdrop74, label %bb_rcslotdone74
bb_rcslotdrop74:
  %v1013 = load i64, ptr %slot10, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  store i32 0, ptr %p1014, align 4, !alias.scope !3, !noalias !4
  %v1015 = load i64, ptr %slot15, align 8
  store i64 %v1015, ptr %slot80, align 8
  %v1016 = load i64, ptr %slot11, align 8
  %p1017 = inttoptr i64 %v1016 to ptr
  %ld1018 = load i32, ptr %p1017, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1018, ptr %slot81, align 8
  %v1019 = load i32, ptr %slot81, align 8
  %op1020 = and i32 %v1019, 28
  store i32 %op1020, ptr %slot82, align 8
  %v1021 = load i32, ptr %slot82, align 8
  %cv1022 = zext i32 %v1021 to i64
  %cond1023 = icmp ne i64 %cv1022, 0
  br i1 %cond1023, label %bb_rcslotrole74, label %bb_rcslotowner74
bb_rcslotrole74:
  %v1024 = load i64, ptr %slot43, align 8
  store i64 %v1024, ptr %slot83, align 8
  %v1025 = load i64, ptr %slot83, align 8
  %v1026 = load i64, ptr %slot80, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1025, i64 %v1026) nomerge, !dbg !116
  br label %bb_rcslotdone74
bb_rcslotowner74:
  %v1027 = load i64, ptr %slot43, align 8
  store i64 %v1027, ptr %slot84, align 8
  %v1028 = load i64, ptr %slot84, align 8
  %v1029 = load i64, ptr %slot80, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1028, i64 %v1029) nomerge, !dbg !116
  br label %bb_rcslotdone74
bb_rcslotdone74:
  %v1030 = load i64, ptr %slot15, align 8
  store i64 %v1030, ptr %slot85, align 8
  %v1031 = load i64, ptr %slot17, align 8
  store i64 %v1031, ptr %slot86, align 8
  %v1032 = load i64, ptr %slot86, align 8
  %v1033 = load i64, ptr %slot85, align 8
  %p1034 = inttoptr i64 %v1032 to ptr
  %p1035 = inttoptr i64 %v1033 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1035, ptr %p1034, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1036 = load i64, ptr %slot11, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  store i32 2, ptr %p1037, align 4, !alias.scope !3, !noalias !4
  %v1038 = load i64, ptr %slot13, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  %ld1040 = load i32, ptr %p1039, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1040, ptr %slot87, align 8
  %v1041 = load i32, ptr %slot87, align 8
  %v1042 = load i64, ptr %slot11, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  store i32 %v1041, ptr %p1043, align 4, !alias.scope !3, !noalias !4
  %v1044 = load i64, ptr %slot12, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i32 0, ptr %p1045, align 4, !alias.scope !3, !noalias !4
  %v1046 = load i64, ptr %slot10, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  store i32 1, ptr %p1047, align 4, !alias.scope !3, !noalias !4
  %v1048 = load i64, ptr %slot85, align 8
  %v1049 = load i64, ptr %slot26, align 8
  %p1050 = inttoptr i64 %v1049 to ptr
  store i64 %v1048, ptr %p1050, align 8, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_rctryok54:
  %v1051 = load i64, ptr %slot28, align 8
  store i64 %v1051, ptr %slot88, align 8
  %v1052 = load i64, ptr %slot14, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  store i32 1, ptr %p1053, align 4, !alias.scope !3, !noalias !4
  %v1054 = load i64, ptr %slot65, align 8
  %op1055 = add i64 %v1054, 8
  store i64 %op1055, ptr %slot89, align 8
  %v1056 = load i64, ptr %slot44, align 8
  store i64 %v1056, ptr %slot90, align 8
  store i64 0, ptr %slot91, align 8
  store i64 0, ptr %slot92, align 8
  %v1057 = load i64, ptr %slot92, align 8
  %v1058 = load i64, ptr %slot26, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  store i64 %v1057, ptr %p1059, align 8, !alias.scope !3, !noalias !4
  %v1060 = load i64, ptr %slot10, align 8
  %p1061 = inttoptr i64 %v1060 to ptr
  %ld1062 = load i32, ptr %p1061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1062, ptr %slot93, align 8
  %v1063 = load i32, ptr %slot93, align 8
  %cv1064 = zext i32 %v1063 to i64
  %cond1065 = icmp ne i64 %cv1064, 0
  br i1 %cond1065, label %bb_rcslotdrop98, label %bb_rcslotdone98
bb_rcslotdrop98:
  %v1066 = load i64, ptr %slot10, align 8
  %p1067 = inttoptr i64 %v1066 to ptr
  store i32 0, ptr %p1067, align 4, !alias.scope !3, !noalias !4
  %v1068 = load i64, ptr %slot15, align 8
  store i64 %v1068, ptr %slot94, align 8
  %v1069 = load i64, ptr %slot11, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  %ld1071 = load i32, ptr %p1070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1071, ptr %slot95, align 8
  %v1072 = load i32, ptr %slot95, align 8
  %op1073 = and i32 %v1072, 28
  store i32 %op1073, ptr %slot96, align 8
  %v1074 = load i32, ptr %slot96, align 8
  %cv1075 = zext i32 %v1074 to i64
  %cond1076 = icmp ne i64 %cv1075, 0
  br i1 %cond1076, label %bb_rcslotrole98, label %bb_rcslotowner98
bb_rcslotrole98:
  %v1077 = load i64, ptr %slot43, align 8
  store i64 %v1077, ptr %slot97, align 8
  %v1078 = load i64, ptr %slot97, align 8
  %v1079 = load i64, ptr %slot94, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1078, i64 %v1079) nomerge, !dbg !116
  br label %bb_rcslotdone98
bb_rcslotowner98:
  %v1080 = load i64, ptr %slot43, align 8
  store i64 %v1080, ptr %slot98, align 8
  %v1081 = load i64, ptr %slot98, align 8
  %v1082 = load i64, ptr %slot94, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1081, i64 %v1082) nomerge, !dbg !116
  br label %bb_rcslotdone98
bb_rcslotdone98:
  br label %bb_i7
bb_i6:
  %v1083 = load i64, ptr %slot26, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  %ld1085 = load i64, ptr %p1084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1085, ptr %slot99, align 8
  %v1086 = load i64, ptr %slot26, align 8
  %p1087 = inttoptr i64 %v1086 to ptr
  %ld1088 = load i64, ptr %p1087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1088, ptr %slot100, align 8
  %v1089 = load i64, ptr %slot10, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  %ld1091 = load i32, ptr %p1090, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1091, ptr %slot101, align 8
  %v1092 = load i64, ptr %slot11, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  %ld1094 = load i32, ptr %p1093, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1094, ptr %slot102, align 8
  %v1095 = load i32, ptr %slot102, align 8
  %op1096 = and i32 %v1095, 24
  store i32 %op1096, ptr %slot102, align 8
  %v1097 = load i32, ptr %slot102, align 8
  %cmp1098 = icmp eq i32 %v1097, 0
  %cv1099 = zext i1 %cmp1098 to i32
  store i32 %cv1099, ptr %slot103, align 8
  %v1100 = load i32, ptr %slot101, align 8
  %v1101 = load i32, ptr %slot103, align 8
  %op1102 = and i32 %v1100, %v1101
  store i32 %op1102, ptr %slot104, align 8
  %v1103 = load i32, ptr %slot104, align 8
  %cv1104 = zext i32 %v1103 to i64
  %cond1105 = icmp ne i64 %cv1104, 0
  br i1 %cond1105, label %bb_rctake107, label %bb_rccopy107
bb_rctake107:
  %v1106 = load i64, ptr %slot17, align 8
  store i64 %v1106, ptr %slot105, align 8
  %v1107 = load i64, ptr %slot44, align 8
  store i64 %v1107, ptr %slot106, align 8
  %v1108 = load i64, ptr %slot43, align 8
  %v1109 = load i64, ptr %slot105, align 8
  %v1110 = load i64, ptr %slot100, align 8
  %v1111 = load i64, ptr %slot106, align 8
  %cv1112 = trunc i64 %v1111 to i32
  %call1113 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v1108, i64 %v1109, i64 %v1110, i32 %cv1112) nomerge, !dbg !118
  store i32 %call1113, ptr %slot107, align 8
  %v1114 = load i32, ptr %slot107, align 8
  %cv1115 = zext i32 %v1114 to i64
  %cond1116 = icmp ne i64 %cv1115, 0
  br i1 %cond1116, label %bb_rcsuccess117, label %bb_rcfailure117
bb_rcfailure117:
  %v1117 = load i64, ptr %slot43, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %call1119 = call i32 @myl_rc_take_failure(ptr %p1118) nomerge, !dbg !118
  store i32 %call1119, ptr %slot108, align 8
  %v1120 = load i64, ptr %slot1, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  %v1122 = load i32, ptr %slot108, align 8
  %call1123 = call i32 @myl_qbe_rc_status(ptr %p1121, i32 %v1122) nomerge, !dbg !118
  store i32 %call1123, ptr %slot109, align 8
  br label %bb_failure
bb_rcsuccess117:
  %v1124 = load i64, ptr %slot10, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  store i32 0, ptr %p1125, align 4, !alias.scope !3, !noalias !4
  %v1126 = load i64, ptr %slot13, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  store i32 2, ptr %p1127, align 4, !alias.scope !3, !noalias !4
  %v1128 = load i64, ptr %slot12, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  store i32 1, ptr %p1129, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared107
bb_rccopy107:
  %v1130 = load i64, ptr %slot17, align 8
  store i64 %v1130, ptr %slot110, align 8
  %v1131 = load i64, ptr %slot44, align 8
  store i64 %v1131, ptr %slot111, align 8
  %v1132 = load i64, ptr %slot43, align 8
  %v1133 = load i64, ptr %slot110, align 8
  %v1134 = load i64, ptr %slot100, align 8
  %v1135 = load i64, ptr %slot111, align 8
  %cv1136 = trunc i64 %v1135 to i32
  %call1137 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v1132, i64 %v1133, i64 %v1134, i32 %cv1136) nomerge, !dbg !118
  store i32 %call1137, ptr %slot112, align 8
  %v1138 = load i32, ptr %slot112, align 8
  %cv1139 = zext i32 %v1138 to i64
  %cond1140 = icmp ne i64 %cv1139, 0
  br i1 %cond1140, label %bb_rcsuccess126, label %bb_rcfailure126
bb_rcfailure126:
  %v1141 = load i64, ptr %slot43, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  %call1143 = call i32 @myl_rc_take_failure(ptr %p1142) nomerge, !dbg !118
  store i32 %call1143, ptr %slot113, align 8
  %v1144 = load i64, ptr %slot1, align 8
  %p1145 = inttoptr i64 %v1144 to ptr
  %v1146 = load i32, ptr %slot113, align 8
  %call1147 = call i32 @myl_qbe_rc_status(ptr %p1145, i32 %v1146) nomerge, !dbg !118
  store i32 %call1147, ptr %slot114, align 8
  br label %bb_failure
bb_rcsuccess126:
  %v1148 = load i64, ptr %slot13, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  store i32 2, ptr %p1149, align 4, !alias.scope !3, !noalias !4
  %v1150 = load i64, ptr %slot12, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  store i32 1, ptr %p1151, align 4, !alias.scope !3, !noalias !4
  %v1152 = load i64, ptr %slot10, align 8
  %p1153 = inttoptr i64 %v1152 to ptr
  %ld1154 = load i32, ptr %p1153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1154, ptr %slot115, align 8
  %v1155 = load i32, ptr %slot115, align 8
  %cv1156 = zext i32 %v1155 to i64
  %cond1157 = icmp ne i64 %cv1156, 0
  br i1 %cond1157, label %bb_rcslotdrop133, label %bb_rcslotdone133
bb_rcslotdrop133:
  %v1158 = load i64, ptr %slot10, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  store i32 0, ptr %p1159, align 4, !alias.scope !3, !noalias !4
  %v1160 = load i64, ptr %slot15, align 8
  store i64 %v1160, ptr %slot116, align 8
  %v1161 = load i64, ptr %slot11, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  %ld1163 = load i32, ptr %p1162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1163, ptr %slot117, align 8
  %v1164 = load i32, ptr %slot117, align 8
  %op1165 = and i32 %v1164, 28
  store i32 %op1165, ptr %slot118, align 8
  %v1166 = load i32, ptr %slot118, align 8
  %cv1167 = zext i32 %v1166 to i64
  %cond1168 = icmp ne i64 %cv1167, 0
  br i1 %cond1168, label %bb_rcslotrole133, label %bb_rcslotowner133
bb_rcslotrole133:
  %v1169 = load i64, ptr %slot43, align 8
  store i64 %v1169, ptr %slot119, align 8
  %v1170 = load i64, ptr %slot119, align 8
  %v1171 = load i64, ptr %slot116, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1170, i64 %v1171) nomerge, !dbg !118
  br label %bb_rcslotdone133
bb_rcslotowner133:
  %v1172 = load i64, ptr %slot43, align 8
  store i64 %v1172, ptr %slot120, align 8
  %v1173 = load i64, ptr %slot120, align 8
  %v1174 = load i64, ptr %slot116, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1173, i64 %v1174) nomerge, !dbg !118
  br label %bb_rcslotdone133
bb_rcslotdone133:
  br label %bb_rcprepared107
bb_rcprepared107:
  %v1175 = load i64, ptr %slot17, align 8
  store i64 %v1175, ptr %slot121, align 8
  %v1176 = load i64, ptr %slot12, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i32 0, ptr %p1177, align 4, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot10, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  %ld1180 = load i32, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1180, ptr %slot122, align 8
  %v1181 = load i32, ptr %slot122, align 8
  %cv1182 = zext i32 %v1181 to i64
  %cond1183 = icmp ne i64 %cv1182, 0
  br i1 %cond1183, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v1184 = load i64, ptr %slot10, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  store i32 0, ptr %p1185, align 4, !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot15, align 8
  store i64 %v1186, ptr %slot123, align 8
  %v1187 = load i64, ptr %slot11, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i32, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1189, ptr %slot124, align 8
  %v1190 = load i32, ptr %slot124, align 8
  %op1191 = and i32 %v1190, 28
  store i32 %op1191, ptr %slot125, align 8
  %v1192 = load i32, ptr %slot125, align 8
  %cv1193 = zext i32 %v1192 to i64
  %cond1194 = icmp ne i64 %cv1193, 0
  br i1 %cond1194, label %bb_rcslotrole144, label %bb_rcslotowner144
bb_rcslotrole144:
  %v1195 = load i64, ptr %slot43, align 8
  store i64 %v1195, ptr %slot126, align 8
  %v1196 = load i64, ptr %slot126, align 8
  %v1197 = load i64, ptr %slot123, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1196, i64 %v1197) nomerge, !dbg !118
  br label %bb_rcslotdone144
bb_rcslotowner144:
  %v1198 = load i64, ptr %slot43, align 8
  store i64 %v1198, ptr %slot127, align 8
  %v1199 = load i64, ptr %slot127, align 8
  %v1200 = load i64, ptr %slot123, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1199, i64 %v1200) nomerge, !dbg !118
  br label %bb_rcslotdone144
bb_rcslotdone144:
  %v1201 = load i64, ptr %slot8, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %ld1203 = load i32, ptr %p1202, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1203, ptr %slot128, align 8
  %v1204 = load i32, ptr %slot128, align 8
  %cv1205 = zext i32 %v1204 to i64
  %cond1206 = icmp ne i64 %cv1205, 0
  br i1 %cond1206, label %bb_rcslotdrop171, label %bb_rcslotdone171
bb_rcslotdrop171:
  %v1207 = load i64, ptr %slot8, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  store i32 0, ptr %p1208, align 4, !alias.scope !3, !noalias !4
  %v1209 = load i64, ptr %slot23, align 8
  store i64 %v1209, ptr %slot129, align 8
  %v1210 = load i64, ptr %slot9, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  %ld1212 = load i32, ptr %p1211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1212, ptr %slot130, align 8
  %v1213 = load i32, ptr %slot130, align 8
  %op1214 = and i32 %v1213, 28
  store i32 %op1214, ptr %slot131, align 8
  %v1215 = load i32, ptr %slot131, align 8
  %cv1216 = zext i32 %v1215 to i64
  %cond1217 = icmp ne i64 %cv1216, 0
  br i1 %cond1217, label %bb_rcslotrole171, label %bb_rcslotowner171
bb_rcslotrole171:
  %v1218 = load i64, ptr %slot43, align 8
  store i64 %v1218, ptr %slot132, align 8
  %v1219 = load i64, ptr %slot132, align 8
  %v1220 = load i64, ptr %slot129, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1219, i64 %v1220) nomerge, !dbg !118
  br label %bb_rcslotdone171
bb_rcslotowner171:
  %v1221 = load i64, ptr %slot43, align 8
  store i64 %v1221, ptr %slot133, align 8
  %v1222 = load i64, ptr %slot133, align 8
  %v1223 = load i64, ptr %slot129, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1222, i64 %v1223) nomerge, !dbg !118
  br label %bb_rcslotdone171
bb_rcslotdone171:
  %v1224 = load i64, ptr %slot6, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  %ld1226 = load i32, ptr %p1225, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1226, ptr %slot134, align 8
  %v1227 = load i32, ptr %slot134, align 8
  %cv1228 = zext i32 %v1227 to i64
  %cond1229 = icmp ne i64 %cv1228, 0
  br i1 %cond1229, label %bb_rcslotdrop198, label %bb_rcslotdone198
bb_rcslotdrop198:
  %v1230 = load i64, ptr %slot6, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  store i32 0, ptr %p1231, align 4, !alias.scope !3, !noalias !4
  %v1232 = load i64, ptr %slot21, align 8
  store i64 %v1232, ptr %slot135, align 8
  %v1233 = load i64, ptr %slot7, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  %ld1235 = load i32, ptr %p1234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1235, ptr %slot136, align 8
  %v1236 = load i32, ptr %slot136, align 8
  %op1237 = and i32 %v1236, 28
  store i32 %op1237, ptr %slot137, align 8
  %v1238 = load i32, ptr %slot137, align 8
  %cv1239 = zext i32 %v1238 to i64
  %cond1240 = icmp ne i64 %cv1239, 0
  br i1 %cond1240, label %bb_rcslotrole198, label %bb_rcslotowner198
bb_rcslotrole198:
  %v1241 = load i64, ptr %slot43, align 8
  store i64 %v1241, ptr %slot138, align 8
  %v1242 = load i64, ptr %slot138, align 8
  %v1243 = load i64, ptr %slot135, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1242, i64 %v1243) nomerge, !dbg !118
  br label %bb_rcslotdone198
bb_rcslotowner198:
  %v1244 = load i64, ptr %slot43, align 8
  store i64 %v1244, ptr %slot139, align 8
  %v1245 = load i64, ptr %slot139, align 8
  %v1246 = load i64, ptr %slot135, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1245, i64 %v1246) nomerge, !dbg !118
  br label %bb_rcslotdone198
bb_rcslotdone198:
  %v1247 = load i64, ptr %slot121, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1248, i64 24, i1 false)
  ret void
bb_i7:
  %v1249 = load i64, ptr %slot18, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %ld1251 = load i64, ptr %p1250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1251, ptr %slot140, align 8
  %v1252 = load i64, ptr %slot140, align 8
  %v1253 = load i64, ptr %slot26, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  store i64 %v1252, ptr %p1254, align 8, !alias.scope !3, !noalias !4
  %v1255 = load i64, ptr %slot26, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  %ld1257 = load i64, ptr %p1256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1257, ptr %slot141, align 8
  %v1258 = load i64, ptr %slot141, align 8
  %op1259 = add i64 %v1258, 32
  store i64 %op1259, ptr %slot142, align 8
  %v1260 = load i64, ptr %slot142, align 8
  %v1261 = load i64, ptr %slot26, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  store i64 %v1260, ptr %p1262, align 8, !alias.scope !3, !noalias !4
  %v1263 = load i64, ptr %slot10, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  %ld1265 = load i32, ptr %p1264, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1265, ptr %slot143, align 8
  %v1266 = load i32, ptr %slot143, align 8
  %cv1267 = zext i32 %v1266 to i64
  %cond1268 = icmp ne i64 %cv1267, 0
  br i1 %cond1268, label %bb_rcslotdrop228, label %bb_rcslotdone228
bb_rcslotdrop228:
  %v1269 = load i64, ptr %slot10, align 8
  %p1270 = inttoptr i64 %v1269 to ptr
  store i32 0, ptr %p1270, align 4, !alias.scope !3, !noalias !4
  %v1271 = load i64, ptr %slot15, align 8
  store i64 %v1271, ptr %slot144, align 8
  %v1272 = load i64, ptr %slot11, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  %ld1274 = load i32, ptr %p1273, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1274, ptr %slot145, align 8
  %v1275 = load i32, ptr %slot145, align 8
  %op1276 = and i32 %v1275, 28
  store i32 %op1276, ptr %slot146, align 8
  %v1277 = load i32, ptr %slot146, align 8
  %cv1278 = zext i32 %v1277 to i64
  %cond1279 = icmp ne i64 %cv1278, 0
  br i1 %cond1279, label %bb_rcslotrole228, label %bb_rcslotowner228
bb_rcslotrole228:
  %v1280 = load i64, ptr %slot43, align 8
  store i64 %v1280, ptr %slot147, align 8
  %v1281 = load i64, ptr %slot147, align 8
  %v1282 = load i64, ptr %slot144, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1281, i64 %v1282) nomerge, !dbg !120
  br label %bb_rcslotdone228
bb_rcslotowner228:
  %v1283 = load i64, ptr %slot43, align 8
  store i64 %v1283, ptr %slot148, align 8
  %v1284 = load i64, ptr %slot148, align 8
  %v1285 = load i64, ptr %slot144, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1284, i64 %v1285) nomerge, !dbg !120
  br label %bb_rcslotdone228
bb_rcslotdone228:
  %v1286 = load i64, ptr %slot27, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  store i64 0, ptr %p1287, align 8, !alias.scope !3, !noalias !4
  %v1288 = load i64, ptr %slot26, align 8
  %p1289 = inttoptr i64 %v1288 to ptr
  %ld1290 = load i64, ptr %p1289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1290, ptr %slot149, align 8
  %v1291 = load i64, ptr %slot27, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  %ld1293 = load i64, ptr %p1292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1293, ptr %slot150, align 8
  %v1294 = load i64, ptr %slot1, align 8
  %v1295 = load i64, ptr %slot149, align 8
  %v1296 = load i64, ptr %slot150, align 8
  %call1297 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v1294, i64 %v1295, i64 %v1296) nomerge, !dbg !122
  store { i64, i64 } %call1297, ptr %callresult152, align 8
  %addr1298 = ptrtoint ptr %callresult152 to i64
  store i64 %addr1298, ptr %slot151, align 8
  %v1299 = load i64, ptr %slot151, align 8
  %v1300 = load i64, ptr %slot26, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i64 %v1299, ptr %p1301, align 8, !alias.scope !3, !noalias !4
  %v1302 = load i64, ptr %slot10, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  %ld1304 = load i32, ptr %p1303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1304, ptr %slot153, align 8
  %v1305 = load i32, ptr %slot153, align 8
  %cv1306 = zext i32 %v1305 to i64
  %cond1307 = icmp ne i64 %cv1306, 0
  br i1 %cond1307, label %bb_rcslotdrop240, label %bb_rcslotdone240
bb_rcslotdrop240:
  %v1308 = load i64, ptr %slot10, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  store i32 0, ptr %p1309, align 4, !alias.scope !3, !noalias !4
  %v1310 = load i64, ptr %slot15, align 8
  store i64 %v1310, ptr %slot154, align 8
  %v1311 = load i64, ptr %slot11, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  %ld1313 = load i32, ptr %p1312, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1313, ptr %slot155, align 8
  %v1314 = load i32, ptr %slot155, align 8
  %op1315 = and i32 %v1314, 28
  store i32 %op1315, ptr %slot156, align 8
  %v1316 = load i32, ptr %slot156, align 8
  %cv1317 = zext i32 %v1316 to i64
  %cond1318 = icmp ne i64 %cv1317, 0
  br i1 %cond1318, label %bb_rcslotrole240, label %bb_rcslotowner240
bb_rcslotrole240:
  %v1319 = load i64, ptr %slot43, align 8
  store i64 %v1319, ptr %slot157, align 8
  %v1320 = load i64, ptr %slot157, align 8
  %v1321 = load i64, ptr %slot154, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1320, i64 %v1321) nomerge, !dbg !122
  br label %bb_rcslotdone240
bb_rcslotowner240:
  %v1322 = load i64, ptr %slot43, align 8
  store i64 %v1322, ptr %slot158, align 8
  %v1323 = load i64, ptr %slot158, align 8
  %v1324 = load i64, ptr %slot154, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1323, i64 %v1324) nomerge, !dbg !122
  br label %bb_rcslotdone240
bb_rcslotdone240:
  %v1325 = load i64, ptr %slot26, align 8
  %p1326 = inttoptr i64 %v1325 to ptr
  %ld1327 = load i64, ptr %p1326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1327, ptr %slot159, align 8
  %v1328 = load i64, ptr %slot159, align 8
  %v1329 = load i64, ptr %slot20, align 8
  %p1330 = inttoptr i64 %v1328 to ptr
  %p1331 = inttoptr i64 %v1329 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1331, ptr %p1330, i64 16, i1 false)
  %v1332 = load i64, ptr %slot19, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  %ld1334 = load i64, ptr %p1333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1334, ptr %slot160, align 8
  %v1335 = load i64, ptr %slot160, align 8
  %v1336 = load i64, ptr %slot26, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i64 %v1335, ptr %p1337, align 8, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot26, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  %ld1340 = load i64, ptr %p1339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1340, ptr %slot161, align 8
  %v1341 = load i64, ptr %slot161, align 8
  %op1342 = add i64 %v1341, 0
  store i64 %op1342, ptr %slot162, align 8
  %v1343 = load i64, ptr %slot162, align 8
  %v1344 = load i64, ptr %slot26, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  store i64 %v1343, ptr %p1345, align 8, !alias.scope !3, !noalias !4
  %v1346 = load i64, ptr %slot10, align 8
  %p1347 = inttoptr i64 %v1346 to ptr
  %ld1348 = load i32, ptr %p1347, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1348, ptr %slot163, align 8
  %v1349 = load i32, ptr %slot163, align 8
  %cv1350 = zext i32 %v1349 to i64
  %cond1351 = icmp ne i64 %cv1350, 0
  br i1 %cond1351, label %bb_rcslotdrop253, label %bb_rcslotdone253
bb_rcslotdrop253:
  %v1352 = load i64, ptr %slot10, align 8
  %p1353 = inttoptr i64 %v1352 to ptr
  store i32 0, ptr %p1353, align 4, !alias.scope !3, !noalias !4
  %v1354 = load i64, ptr %slot15, align 8
  store i64 %v1354, ptr %slot164, align 8
  %v1355 = load i64, ptr %slot11, align 8
  %p1356 = inttoptr i64 %v1355 to ptr
  %ld1357 = load i32, ptr %p1356, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1357, ptr %slot165, align 8
  %v1358 = load i32, ptr %slot165, align 8
  %op1359 = and i32 %v1358, 28
  store i32 %op1359, ptr %slot166, align 8
  %v1360 = load i32, ptr %slot166, align 8
  %cv1361 = zext i32 %v1360 to i64
  %cond1362 = icmp ne i64 %cv1361, 0
  br i1 %cond1362, label %bb_rcslotrole253, label %bb_rcslotowner253
bb_rcslotrole253:
  %v1363 = load i64, ptr %slot43, align 8
  store i64 %v1363, ptr %slot167, align 8
  %v1364 = load i64, ptr %slot167, align 8
  %v1365 = load i64, ptr %slot164, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64 %v1364, i64 %v1365) nomerge, !dbg !124
  br label %bb_rcslotdone253
bb_rcslotowner253:
  %v1366 = load i64, ptr %slot43, align 8
  store i64 %v1366, ptr %slot168, align 8
  %v1367 = load i64, ptr %slot168, align 8
  %v1368 = load i64, ptr %slot164, align 8
  call void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64 %v1367, i64 %v1368) nomerge, !dbg !124
  br label %bb_rcslotdone253
bb_rcslotdone253:
  %v1369 = load i64, ptr %slot26, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %ld1371 = load i64, ptr %p1370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1371, ptr %slot169, align 8
  %v1372 = load i64, ptr %slot169, align 8
  %op1373 = add i64 %v1372, 0
  store i64 %op1373, ptr %slot170, align 8
  %v1374 = load i64, ptr %slot170, align 8
  %v1375 = load i64, ptr %slot26, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  store i64 %v1374, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot10, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  %ld1379 = load i32, ptr %p1378, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1379, ptr %slot171, align 8
  %v1380 = load i32, ptr %slot171, align 8
  %cv1381 = zext i32 %v1380 to i64
  %cond1382 = icmp ne i64 %cv1381, 0
  br i1 %cond1382, label %bb_rcslotdrop264, label %bb_rcslotdone264
bb_rcslotdrop264:
  %v1383 = load i64, ptr %slot10, align 8
  %p1384 = inttoptr i64 %v1383 to ptr
  store i32 0, ptr %p1384, align 4, !alias.scope !3, !noalias !4
  %v1385 = load i64, ptr %slot15, align 8
  store i64 %v1385, ptr %slot172, align 8
  %v1386 = load i64, ptr %slot11, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  %ld1388 = load i32, ptr %p1387, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1388, ptr %slot173, align 8
  %v1389 = load i32, ptr %slot173, align 8
  %op1390 = and i32 %v1389, 28
  store i32 %op1390, ptr %slot174, align 8
  %v1391 = load i32, ptr %slot174, align 8
  %cv1392 = zext i32 %v1391 to i64
  %cond1393 = icmp ne i64 %cv1392, 0
  br i1 %cond1393, label %bb_rcslotrole264, label %bb_rcslotowner264
bb_rcslotrole264:
  %v1394 = load i64, ptr %slot43, align 8
  store i64 %v1394, ptr %slot175, align 8
  %v1395 = load i64, ptr %slot175, align 8
  %v1396 = load i64, ptr %slot172, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v1395, i64 %v1396) nomerge, !dbg !126
  br label %bb_rcslotdone264
bb_rcslotowner264:
  %v1397 = load i64, ptr %slot43, align 8
  store i64 %v1397, ptr %slot176, align 8
  %v1398 = load i64, ptr %slot176, align 8
  %v1399 = load i64, ptr %slot172, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v1398, i64 %v1399) nomerge, !dbg !126
  br label %bb_rcslotdone264
bb_rcslotdone264:
  %v1400 = load i64, ptr %slot29, align 8
  store i64 %v1400, ptr %slot177, align 8
  %v1401 = load i64, ptr %slot177, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  store i32 0, ptr %p1402, align 4, !alias.scope !3, !noalias !4
  %v1403 = load i64, ptr %slot177, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  store i32 11, ptr %p1404, align 4, !alias.scope !3, !noalias !4
  %v1405 = load i64, ptr %slot177, align 8
  %v1406 = load i64, ptr %slot27, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i64 %v1405, ptr %p1407, align 8, !alias.scope !3, !noalias !4
  %v1408 = load i64, ptr %slot27, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i64, ptr %p1409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1410, ptr %slot178, align 8
  %v1411 = load i64, ptr %slot26, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i64, ptr %p1412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1413, ptr %slot179, align 8
  %v1414 = load i64, ptr %slot179, align 8
  %p1415 = inttoptr i64 %v1414 to ptr
  %ld1416 = load i32, ptr %p1415, align 4
  %ext1417 = zext i32 %ld1416 to i64
  store i64 %ext1417, ptr %slot180, align 8
  %v1418 = load i64, ptr %slot178, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  %ld1420 = load i32, ptr %p1419, align 4
  %ext1421 = zext i32 %ld1420 to i64
  store i64 %ext1421, ptr %slot181, align 8
  %v1422 = load i64, ptr %slot180, align 8
  %v1423 = load i64, ptr %slot181, align 8
  %cmp1424 = icmp eq i64 %v1422, %v1423
  %cv1425 = zext i1 %cmp1424 to i64
  store i64 %cv1425, ptr %slot182, align 8
  %v1426 = load i64, ptr %slot182, align 8
  %v1427 = load i64, ptr %slot26, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i64 %v1426, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot26, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot183, align 8
  %v1432 = load i64, ptr %slot183, align 8
  %cond1433 = icmp ne i64 %v1432, 0
  br i1 %cond1433, label %bb_next278, label %bb_i56
bb_next278:
  %v1434 = load i64, ptr %slot18, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  %ld1436 = load i64, ptr %p1435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1436, ptr %slot184, align 8
  %v1437 = load i64, ptr %slot184, align 8
  %v1438 = load i64, ptr %slot30, align 8
  %p1439 = inttoptr i64 %v1437 to ptr
  %p1440 = inttoptr i64 %v1438 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1440, ptr %p1439, i64 304, i1 false), !alias.scope !10000000
  %v1441 = load i64, ptr %slot30, align 8
  %v1442 = load i64, ptr %slot26, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  store i64 %v1441, ptr %p1443, align 8, !alias.scope !3, !noalias !4
  %v1444 = load i64, ptr %slot26, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  %ld1446 = load i64, ptr %p1445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1446, ptr %slot185, align 8
  %v1447 = load i64, ptr %slot185, align 8
  %op1448 = add i64 %v1447, 32
  store i64 %op1448, ptr %slot186, align 8
  %v1449 = load i64, ptr %slot186, align 8
  %v1450 = load i64, ptr %slot26, align 8
  %p1451 = inttoptr i64 %v1450 to ptr
  store i64 %v1449, ptr %p1451, align 8, !alias.scope !3, !noalias !4
  %v1452 = load i64, ptr %slot6, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  %ld1454 = load i32, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1454, ptr %slot187, align 8
  %v1455 = load i32, ptr %slot187, align 8
  %cv1456 = zext i32 %v1455 to i64
  %cond1457 = icmp ne i64 %cv1456, 0
  br i1 %cond1457, label %bb_rcslotdrop283, label %bb_rcslotdone283
bb_rcslotdrop283:
  %v1458 = load i64, ptr %slot6, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i32 0, ptr %p1459, align 4, !alias.scope !3, !noalias !4
  %v1460 = load i64, ptr %slot21, align 8
  store i64 %v1460, ptr %slot188, align 8
  %v1461 = load i64, ptr %slot7, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  %ld1463 = load i32, ptr %p1462, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1463, ptr %slot189, align 8
  %v1464 = load i32, ptr %slot189, align 8
  %op1465 = and i32 %v1464, 28
  store i32 %op1465, ptr %slot190, align 8
  %v1466 = load i32, ptr %slot190, align 8
  %cv1467 = zext i32 %v1466 to i64
  %cond1468 = icmp ne i64 %cv1467, 0
  br i1 %cond1468, label %bb_rcslotrole283, label %bb_rcslotowner283
bb_rcslotrole283:
  %v1469 = load i64, ptr %slot43, align 8
  store i64 %v1469, ptr %slot191, align 8
  %v1470 = load i64, ptr %slot191, align 8
  %v1471 = load i64, ptr %slot188, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1470, i64 %v1471) nomerge, !dbg !128
  br label %bb_rcslotdone283
bb_rcslotowner283:
  %v1472 = load i64, ptr %slot43, align 8
  store i64 %v1472, ptr %slot192, align 8
  %v1473 = load i64, ptr %slot192, align 8
  %v1474 = load i64, ptr %slot188, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1473, i64 %v1474) nomerge, !dbg !128
  br label %bb_rcslotdone283
bb_rcslotdone283:
  %v1475 = load i64, ptr %slot18, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ld1477 = load i64, ptr %p1476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1477, ptr %slot193, align 8
  %v1478 = load i64, ptr %slot193, align 8
  %op1479 = add i64 %v1478, 32
  store i64 %op1479, ptr %slot194, align 8
  %v1480 = load i64, ptr %slot21, align 8
  store i64 %v1480, ptr %slot195, align 8
  %v1481 = load i64, ptr %slot194, align 8
  %v1482 = load i64, ptr %slot195, align 8
  %p1483 = inttoptr i64 %v1481 to ptr
  %p1484 = inttoptr i64 %v1482 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1484, ptr %p1483, i64 208, i1 false), !alias.scope !10000000
  %v1485 = load i64, ptr %slot194, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  call void @llvm.memset.p0.i64(ptr %p1486, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !128
  %v1487 = load i64, ptr %slot6, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  store i32 1, ptr %p1488, align 4, !alias.scope !3, !noalias !4
  %v1489 = load i64, ptr %slot21, align 8
  %v1490 = load i64, ptr %slot26, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  store i64 %v1489, ptr %p1491, align 8, !alias.scope !3, !noalias !4
  %v1492 = load i64, ptr %slot20, align 8
  %v1493 = load i64, ptr %slot27, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  store i64 %v1492, ptr %p1494, align 8, !alias.scope !3, !noalias !4
  %v1495 = load i64, ptr %slot27, align 8
  %p1496 = inttoptr i64 %v1495 to ptr
  %ld1497 = load i64, ptr %p1496, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1497, ptr %slot196, align 8
  %v1498 = load i64, ptr %slot196, align 8
  %v1499 = load i64, ptr %slot24, align 8
  %p1500 = inttoptr i64 %v1498 to ptr
  %p1501 = inttoptr i64 %v1499 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1501, ptr %p1500, i64 16, i1 false)
  %v1502 = load i64, ptr %slot24, align 8
  %v1503 = load i64, ptr %slot27, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  store i64 %v1502, ptr %p1504, align 8, !alias.scope !3, !noalias !4
  %v1505 = load i64, ptr %slot27, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %ld1507 = load i64, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1507, ptr %slot197, align 8
  %v1508 = load i64, ptr %slot197, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %ld1510 = load i32, ptr %p1509, align 4
  %ext1511 = zext i32 %ld1510 to i64
  store i64 %ext1511, ptr %slot198, align 8
  %v1512 = load i64, ptr %slot198, align 8
  %cmp1513 = icmp eq i64 %v1512, 0
  %cv1514 = zext i1 %cmp1513 to i64
  store i64 %cv1514, ptr %slot199, align 8
  %v1515 = load i64, ptr %slot199, align 8
  %cond1516 = icmp ne i64 %v1515, 0
  br i1 %cond1516, label %bb_rcarm297, label %bb_rcarmnext297
bb_rcarm297:
  br label %bb_i28
bb_rcarmnext297:
  %v1517 = load i64, ptr %slot198, align 8
  %cmp1518 = icmp eq i64 %v1517, 1
  %cv1519 = zext i1 %cmp1518 to i64
  store i64 %cv1519, ptr %slot200, align 8
  %v1520 = load i64, ptr %slot200, align 8
  %cond1521 = icmp ne i64 %v1520, 0
  br i1 %cond1521, label %bb_rcarm298, label %bb_rcarmnext298
bb_rcarm298:
  %v1522 = load i64, ptr %slot17, align 8
  store i64 %v1522, ptr %slot201, align 8
  %v1523 = load i64, ptr %slot197, align 8
  %op1524 = add i64 %v1523, 8
  store i64 %op1524, ptr %slot202, align 8
  %v1525 = load i64, ptr %slot44, align 8
  store i64 %v1525, ptr %slot203, align 8
  %v1526 = load i64, ptr %slot202, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  %ld1528 = load i8, ptr %p1527, align 1
  %ext1529 = zext i8 %ld1528 to i64
  store i64 %ext1529, ptr %slot204, align 8
  %v1530 = load i64, ptr %slot204, align 8
  %cv1531 = trunc i64 %v1530 to i8
  %v1532 = load i64, ptr %slot201, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  store i8 %cv1531, ptr %p1533, align 1, !alias.scope !3, !noalias !4
  %v1534 = load i64, ptr %slot13, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  store i32 0, ptr %p1535, align 4, !alias.scope !3, !noalias !4
  %v1536 = load i64, ptr %slot12, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  store i32 1, ptr %p1537, align 4, !alias.scope !3, !noalias !4
  %v1538 = load i64, ptr %slot201, align 8
  %p1539 = inttoptr i64 %v1538 to ptr
  %ld1540 = load i8, ptr %p1539, align 1, !alias.scope !3, !noalias !4
  %ext1541 = zext i8 %ld1540 to i64
  store i64 %ext1541, ptr %slot205, align 8
  %v1542 = load i64, ptr %slot205, align 8
  %v1543 = load i64, ptr %slot25, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  store i64 %v1542, ptr %p1544, align 8, !alias.scope !3, !noalias !4
  %v1545 = load i64, ptr %slot12, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  store i32 0, ptr %p1546, align 4, !alias.scope !3, !noalias !4
  br label %bb_i30
bb_rcarmnext298:
  %v1547 = load i64, ptr %slot198, align 8
  %cmp1548 = icmp eq i64 %v1547, 2
  %cv1549 = zext i1 %cmp1548 to i64
  store i64 %cv1549, ptr %slot206, align 8
  %v1550 = load i64, ptr %slot206, align 8
  %cond1551 = icmp ne i64 %v1550, 0
  br i1 %cond1551, label %bb_rcarm307, label %bb_rcarmnext307
bb_rcarm307:
  br label %bb_i33
bb_rcarmnext307:
  %v1552 = load i64, ptr %slot198, align 8
  %cmp1553 = icmp eq i64 %v1552, 3
  %cv1554 = zext i1 %cmp1553 to i64
  store i64 %cv1554, ptr %slot207, align 8
  %v1555 = load i64, ptr %slot207, align 8
  %cond1556 = icmp ne i64 %v1555, 0
  br i1 %cond1556, label %bb_rcarm308, label %bb_rcarmnext308
bb_rcarm308:
  br label %bb_i35
bb_rcarmnext308:
  br label %bb_failure
bb_i28:
  %v1557 = load i64, ptr %slot27, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  store i64 1, ptr %p1558, align 8, !alias.scope !3, !noalias !4
  br label %bb_i37
bb_i30:
  %v1559 = load i64, ptr %slot25, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %ld1561 = load i64, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1561, ptr %slot208, align 8
  %v1562 = load i64, ptr %slot208, align 8
  %v1563 = load i64, ptr %slot27, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  store i64 %v1562, ptr %p1564, align 8, !alias.scope !3, !noalias !4
  %v1565 = load i64, ptr %slot27, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  %ld1567 = load i64, ptr %p1566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1567, ptr %slot209, align 8
  %v1568 = load i64, ptr %slot209, align 8
  %op1569 = xor i64 %v1568, 1
  store i64 %op1569, ptr %slot210, align 8
  %v1570 = load i64, ptr %slot210, align 8
  %v1571 = load i64, ptr %slot27, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i64 %v1570, ptr %p1572, align 8, !alias.scope !3, !noalias !4
  br label %bb_i37
bb_i33:
  %v1573 = load i64, ptr %slot27, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i64 0, ptr %p1574, align 8, !alias.scope !3, !noalias !4
  br label %bb_i37
bb_i35:
  %v1575 = load i64, ptr %slot27, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  store i64 0, ptr %p1576, align 8, !alias.scope !3, !noalias !4
  br label %bb_i37
bb_i37:
  %v1577 = load i64, ptr %slot31, align 8
  store i64 %v1577, ptr %slot211, align 8
  %v1578 = load i64, ptr %slot211, align 8
  %p1579 = inttoptr i64 %v1578 to ptr
  store i64 0, ptr %p1579, align 8, !alias.scope !3, !noalias !4
  %v1580 = load i64, ptr %slot211, align 8
  %p1582 = inttoptr i64 %v1580 to ptr
  %gep1583 = getelementptr i8, ptr %p1582, i64 8
  %op1581 = ptrtoint ptr %gep1583 to i64
  store i64 %op1581, ptr %slot212, align 8
  %v1584 = load i64, ptr %slot212, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  store i64 0, ptr %p1585, align 8, !alias.scope !3, !noalias !4
  %v1586 = load i64, ptr %slot211, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  store i32 1, ptr %p1587, align 4, !alias.scope !3, !noalias !4
  %v1588 = load i64, ptr %slot14, align 8
  %p1589 = inttoptr i64 %v1588 to ptr
  store i32 1, ptr %p1589, align 4, !alias.scope !3, !noalias !4
  %v1590 = load i64, ptr %slot27, align 8
  store i64 %v1590, ptr %slot213, align 8
  %v1591 = load i64, ptr %slot211, align 8
  %p1593 = inttoptr i64 %v1591 to ptr
  %gep1594 = getelementptr i8, ptr %p1593, i64 8
  %op1592 = ptrtoint ptr %gep1594 to i64
  store i64 %op1592, ptr %slot214, align 8
  %v1595 = load i64, ptr %slot44, align 8
  store i64 %v1595, ptr %slot215, align 8
  %v1596 = load i64, ptr %slot213, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %ld1598 = load i8, ptr %p1597, align 1, !alias.scope !3, !noalias !4
  %ext1599 = zext i8 %ld1598 to i64
  store i64 %ext1599, ptr %slot216, align 8
  %v1600 = load i64, ptr %slot216, align 8
  %cv1601 = trunc i64 %v1600 to i8
  %v1602 = load i64, ptr %slot214, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  store i8 %cv1601, ptr %p1603, align 1, !alias.scope !3, !noalias !4
  %v1604 = load i64, ptr %slot211, align 8
  %v1605 = load i64, ptr %slot27, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  store i64 %v1604, ptr %p1606, align 8, !alias.scope !3, !noalias !4
  %v1607 = load i64, ptr %slot26, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  %ld1609 = load i64, ptr %p1608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1609, ptr %slot217, align 8
  %v1610 = load i64, ptr %slot27, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  %ld1612 = load i64, ptr %p1611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1612, ptr %slot218, align 8
  %v1613 = load i64, ptr %slot1, align 8
  %v1614 = load i64, ptr %slot217, align 8
  %v1615 = load i64, ptr %slot218, align 8
  %call1616 = call i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64 %v1613, i64 %v1614, i64 %v1615) nomerge, !dbg !130
  store i64 %call1616, ptr %slot219, align 8
  %v1617 = load i64, ptr %slot219, align 8
  %v1618 = load i64, ptr %slot26, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  store i64 %v1617, ptr %p1619, align 8, !alias.scope !3, !noalias !4
  %v1620 = load i64, ptr %slot10, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  %ld1622 = load i32, ptr %p1621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1622, ptr %slot220, align 8
  %v1623 = load i32, ptr %slot220, align 8
  %cv1624 = zext i32 %v1623 to i64
  %cond1625 = icmp ne i64 %cv1624, 0
  br i1 %cond1625, label %bb_rcslotdrop325, label %bb_rcslotdone325
bb_rcslotdrop325:
  %v1626 = load i64, ptr %slot10, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  store i32 0, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  %v1628 = load i64, ptr %slot15, align 8
  store i64 %v1628, ptr %slot221, align 8
  %v1629 = load i64, ptr %slot11, align 8
  %p1630 = inttoptr i64 %v1629 to ptr
  %ld1631 = load i32, ptr %p1630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1631, ptr %slot222, align 8
  %v1632 = load i32, ptr %slot222, align 8
  %op1633 = and i32 %v1632, 28
  store i32 %op1633, ptr %slot223, align 8
  %v1634 = load i32, ptr %slot223, align 8
  %cv1635 = zext i32 %v1634 to i64
  %cond1636 = icmp ne i64 %cv1635, 0
  br i1 %cond1636, label %bb_rcslotrole325, label %bb_rcslotowner325
bb_rcslotrole325:
  %v1637 = load i64, ptr %slot43, align 8
  store i64 %v1637, ptr %slot224, align 8
  %v1638 = load i64, ptr %slot224, align 8
  %v1639 = load i64, ptr %slot221, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1638, i64 %v1639) nomerge, !dbg !130
  br label %bb_rcslotdone325
bb_rcslotowner325:
  %v1640 = load i64, ptr %slot43, align 8
  store i64 %v1640, ptr %slot225, align 8
  %v1641 = load i64, ptr %slot225, align 8
  %v1642 = load i64, ptr %slot221, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1641, i64 %v1642) nomerge, !dbg !130
  br label %bb_rcslotdone325
bb_rcslotdone325:
  %v1643 = load i64, ptr %slot18, align 8
  %p1644 = inttoptr i64 %v1643 to ptr
  %ld1645 = load i64, ptr %p1644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1645, ptr %slot226, align 8
  %v1646 = load i64, ptr %slot226, align 8
  %op1647 = add i64 %v1646, 32
  store i64 %op1647, ptr %slot227, align 8
  %v1648 = load i64, ptr %slot21, align 8
  store i64 %v1648, ptr %slot228, align 8
  %v1649 = load i64, ptr %slot228, align 8
  %v1650 = load i64, ptr %slot227, align 8
  %p1651 = inttoptr i64 %v1649 to ptr
  %p1652 = inttoptr i64 %v1650 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1652, ptr %p1651, i64 208, i1 false), !alias.scope !10000000
  %v1653 = load i64, ptr %slot228, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  call void @llvm.memset.p0.i64(ptr %p1654, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v1655 = load i64, ptr %slot6, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  store i32 0, ptr %p1656, align 4, !alias.scope !3, !noalias !4
  %v1657 = load i64, ptr %slot26, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  store i64 0, ptr %p1658, align 8, !alias.scope !3, !noalias !4
  %v1659 = load i64, ptr %slot26, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i64 0, ptr %p1660, align 8, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot32, align 8
  store i64 %v1661, ptr %slot229, align 8
  %v1662 = load i64, ptr %slot229, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  store i64 0, ptr %p1663, align 8, !alias.scope !3, !noalias !4
  %v1664 = load i64, ptr %slot229, align 8
  %p1666 = inttoptr i64 %v1664 to ptr
  %gep1667 = getelementptr i8, ptr %p1666, i64 8
  %op1665 = ptrtoint ptr %gep1667 to i64
  store i64 %op1665, ptr %slot230, align 8
  %v1668 = load i64, ptr %slot230, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  store i64 0, ptr %p1669, align 8, !alias.scope !3, !noalias !4
  %v1670 = load i64, ptr %slot229, align 8
  %p1672 = inttoptr i64 %v1670 to ptr
  %gep1673 = getelementptr i8, ptr %p1672, i64 16
  %op1671 = ptrtoint ptr %gep1673 to i64
  store i64 %op1671, ptr %slot231, align 8
  %v1674 = load i64, ptr %slot231, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 0, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot229, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  store i32 0, ptr %p1677, align 4, !alias.scope !3, !noalias !4
  %v1678 = load i64, ptr %slot14, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  store i32 1, ptr %p1679, align 4, !alias.scope !3, !noalias !4
  %v1680 = load i64, ptr %slot26, align 8
  store i64 %v1680, ptr %slot232, align 8
  %v1681 = load i64, ptr %slot229, align 8
  %p1683 = inttoptr i64 %v1681 to ptr
  %gep1684 = getelementptr i8, ptr %p1683, i64 8
  %op1682 = ptrtoint ptr %gep1684 to i64
  store i64 %op1682, ptr %slot233, align 8
  %v1685 = load i64, ptr %slot44, align 8
  store i64 %v1685, ptr %slot234, align 8
  store i64 0, ptr %slot235, align 8
  %v1686 = load i64, ptr %slot229, align 8
  %v1687 = load i64, ptr %slot26, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  store i64 %v1686, ptr %p1688, align 8, !alias.scope !3, !noalias !4
  %v1689 = load i64, ptr %slot26, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  %ld1691 = load i64, ptr %p1690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1691, ptr %slot236, align 8
  %v1692 = load i64, ptr %slot15, align 8
  store i64 %v1692, ptr %slot237, align 8
  %v1693 = load i64, ptr %slot236, align 8
  %v1694 = load i64, ptr %slot237, align 8
  %p1695 = inttoptr i64 %v1693 to ptr
  %p1696 = inttoptr i64 %v1694 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1696, ptr %p1695, i64 24, i1 false)
  %v1697 = load i64, ptr %slot11, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  store i32 2, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  %v1699 = load i64, ptr %slot10, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i32 1, ptr %p1700, align 4, !alias.scope !3, !noalias !4
  %v1701 = load i64, ptr %slot237, align 8
  %v1702 = load i64, ptr %slot26, align 8
  %p1703 = inttoptr i64 %v1702 to ptr
  store i64 %v1701, ptr %p1703, align 8, !alias.scope !3, !noalias !4
  %v1704 = load i64, ptr %slot26, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  %ld1706 = load i64, ptr %p1705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1706, ptr %slot238, align 8
  %v1707 = load i64, ptr %slot26, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  %ld1709 = load i64, ptr %p1708, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1709, ptr %slot239, align 8
  %v1710 = load i64, ptr %slot17, align 8
  store i64 %v1710, ptr %slot240, align 8
  %v1711 = load i64, ptr %slot44, align 8
  store i64 %v1711, ptr %slot241, align 8
  %v1712 = load i64, ptr %slot43, align 8
  %v1713 = load i64, ptr %slot240, align 8
  %v1714 = load i64, ptr %slot239, align 8
  %v1715 = load i64, ptr %slot241, align 8
  %cv1716 = trunc i64 %v1715 to i32
  %call1717 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v1712, i64 %v1713, i64 %v1714, i32 %cv1716) nomerge, !dbg !134
  store i32 %call1717, ptr %slot242, align 8
  %v1718 = load i32, ptr %slot242, align 8
  %cv1719 = zext i32 %v1718 to i64
  %cond1720 = icmp ne i64 %cv1719, 0
  br i1 %cond1720, label %bb_rcsuccess354, label %bb_rcfailure354
bb_rcfailure354:
  %v1721 = load i64, ptr %slot43, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  %call1723 = call i32 @myl_rc_take_failure(ptr %p1722) nomerge, !dbg !134
  store i32 %call1723, ptr %slot243, align 8
  %v1724 = load i64, ptr %slot1, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  %v1726 = load i32, ptr %slot243, align 8
  %call1727 = call i32 @myl_qbe_rc_status(ptr %p1725, i32 %v1726) nomerge, !dbg !134
  store i32 %call1727, ptr %slot244, align 8
  br label %bb_failure
bb_rcsuccess354:
  %v1728 = load i64, ptr %slot10, align 8
  %p1729 = inttoptr i64 %v1728 to ptr
  store i32 0, ptr %p1729, align 4, !alias.scope !3, !noalias !4
  %v1730 = load i64, ptr %slot13, align 8
  %p1731 = inttoptr i64 %v1730 to ptr
  store i32 2, ptr %p1731, align 4, !alias.scope !3, !noalias !4
  %v1732 = load i64, ptr %slot12, align 8
  %p1733 = inttoptr i64 %v1732 to ptr
  store i32 1, ptr %p1733, align 4, !alias.scope !3, !noalias !4
  %v1734 = load i64, ptr %slot17, align 8
  store i64 %v1734, ptr %slot245, align 8
  %v1735 = load i64, ptr %slot12, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  store i32 0, ptr %p1736, align 4, !alias.scope !3, !noalias !4
  %v1737 = load i64, ptr %slot10, align 8
  %p1738 = inttoptr i64 %v1737 to ptr
  %ld1739 = load i32, ptr %p1738, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1739, ptr %slot246, align 8
  %v1740 = load i32, ptr %slot246, align 8
  %cv1741 = zext i32 %v1740 to i64
  %cond1742 = icmp ne i64 %cv1741, 0
  br i1 %cond1742, label %bb_rcslotdrop364, label %bb_rcslotdone364
bb_rcslotdrop364:
  %v1743 = load i64, ptr %slot10, align 8
  %p1744 = inttoptr i64 %v1743 to ptr
  store i32 0, ptr %p1744, align 4, !alias.scope !3, !noalias !4
  %v1745 = load i64, ptr %slot15, align 8
  store i64 %v1745, ptr %slot247, align 8
  %v1746 = load i64, ptr %slot11, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %ld1748 = load i32, ptr %p1747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1748, ptr %slot248, align 8
  %v1749 = load i32, ptr %slot248, align 8
  %op1750 = and i32 %v1749, 28
  store i32 %op1750, ptr %slot249, align 8
  %v1751 = load i32, ptr %slot249, align 8
  %cv1752 = zext i32 %v1751 to i64
  %cond1753 = icmp ne i64 %cv1752, 0
  br i1 %cond1753, label %bb_rcslotrole364, label %bb_rcslotowner364
bb_rcslotrole364:
  %v1754 = load i64, ptr %slot43, align 8
  store i64 %v1754, ptr %slot250, align 8
  %v1755 = load i64, ptr %slot250, align 8
  %v1756 = load i64, ptr %slot247, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v1755, i64 %v1756) nomerge, !dbg !134
  br label %bb_rcslotdone364
bb_rcslotowner364:
  %v1757 = load i64, ptr %slot43, align 8
  store i64 %v1757, ptr %slot251, align 8
  %v1758 = load i64, ptr %slot251, align 8
  %v1759 = load i64, ptr %slot247, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v1758, i64 %v1759) nomerge, !dbg !134
  br label %bb_rcslotdone364
bb_rcslotdone364:
  %v1760 = load i64, ptr %slot8, align 8
  %p1761 = inttoptr i64 %v1760 to ptr
  %ld1762 = load i32, ptr %p1761, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1762, ptr %slot252, align 8
  %v1763 = load i32, ptr %slot252, align 8
  %cv1764 = zext i32 %v1763 to i64
  %cond1765 = icmp ne i64 %cv1764, 0
  br i1 %cond1765, label %bb_rcslotdrop391, label %bb_rcslotdone391
bb_rcslotdrop391:
  %v1766 = load i64, ptr %slot8, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  store i32 0, ptr %p1767, align 4, !alias.scope !3, !noalias !4
  %v1768 = load i64, ptr %slot23, align 8
  store i64 %v1768, ptr %slot253, align 8
  %v1769 = load i64, ptr %slot9, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  %ld1771 = load i32, ptr %p1770, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1771, ptr %slot254, align 8
  %v1772 = load i32, ptr %slot254, align 8
  %op1773 = and i32 %v1772, 28
  store i32 %op1773, ptr %slot255, align 8
  %v1774 = load i32, ptr %slot255, align 8
  %cv1775 = zext i32 %v1774 to i64
  %cond1776 = icmp ne i64 %cv1775, 0
  br i1 %cond1776, label %bb_rcslotrole391, label %bb_rcslotowner391
bb_rcslotrole391:
  %v1777 = load i64, ptr %slot43, align 8
  store i64 %v1777, ptr %slot256, align 8
  %v1778 = load i64, ptr %slot256, align 8
  %v1779 = load i64, ptr %slot253, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1778, i64 %v1779) nomerge, !dbg !134
  br label %bb_rcslotdone391
bb_rcslotowner391:
  %v1780 = load i64, ptr %slot43, align 8
  store i64 %v1780, ptr %slot257, align 8
  %v1781 = load i64, ptr %slot257, align 8
  %v1782 = load i64, ptr %slot253, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1781, i64 %v1782) nomerge, !dbg !134
  br label %bb_rcslotdone391
bb_rcslotdone391:
  %v1783 = load i64, ptr %slot6, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  %ld1785 = load i32, ptr %p1784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1785, ptr %slot258, align 8
  %v1786 = load i32, ptr %slot258, align 8
  %cv1787 = zext i32 %v1786 to i64
  %cond1788 = icmp ne i64 %cv1787, 0
  br i1 %cond1788, label %bb_rcslotdrop418, label %bb_rcslotdone418
bb_rcslotdrop418:
  %v1789 = load i64, ptr %slot6, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  store i32 0, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  %v1791 = load i64, ptr %slot21, align 8
  store i64 %v1791, ptr %slot259, align 8
  %v1792 = load i64, ptr %slot7, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %ld1794 = load i32, ptr %p1793, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1794, ptr %slot260, align 8
  %v1795 = load i32, ptr %slot260, align 8
  %op1796 = and i32 %v1795, 28
  store i32 %op1796, ptr %slot261, align 8
  %v1797 = load i32, ptr %slot261, align 8
  %cv1798 = zext i32 %v1797 to i64
  %cond1799 = icmp ne i64 %cv1798, 0
  br i1 %cond1799, label %bb_rcslotrole418, label %bb_rcslotowner418
bb_rcslotrole418:
  %v1800 = load i64, ptr %slot43, align 8
  store i64 %v1800, ptr %slot262, align 8
  %v1801 = load i64, ptr %slot262, align 8
  %v1802 = load i64, ptr %slot259, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1801, i64 %v1802) nomerge, !dbg !134
  br label %bb_rcslotdone418
bb_rcslotowner418:
  %v1803 = load i64, ptr %slot43, align 8
  store i64 %v1803, ptr %slot263, align 8
  %v1804 = load i64, ptr %slot263, align 8
  %v1805 = load i64, ptr %slot259, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1804, i64 %v1805) nomerge, !dbg !134
  br label %bb_rcslotdone418
bb_rcslotdone418:
  %v1806 = load i64, ptr %slot245, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1807, i64 24, i1 false)
  ret void
bb_i56:
  %v1808 = load i64, ptr %slot20, align 8
  %v1809 = load i64, ptr %slot26, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  store i64 %v1808, ptr %p1810, align 8, !alias.scope !3, !noalias !4
  %v1811 = load i64, ptr %slot26, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %ld1813 = load i64, ptr %p1812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1813, ptr %slot264, align 8
  %v1814 = load i64, ptr %slot264, align 8
  %p1815 = inttoptr i64 %v1814 to ptr
  %ld1816 = load i32, ptr %p1815, align 4
  %ext1817 = zext i32 %ld1816 to i64
  store i64 %ext1817, ptr %slot265, align 8
  %v1818 = load i64, ptr %slot265, align 8
  %cmp1819 = icmp eq i64 %v1818, 0
  %cv1820 = zext i1 %cmp1819 to i64
  store i64 %cv1820, ptr %slot266, align 8
  %v1821 = load i64, ptr %slot266, align 8
  %cond1822 = icmp ne i64 %v1821, 0
  br i1 %cond1822, label %bb_rcarm445, label %bb_rcarmnext445
bb_rcarm445:
  br label %bb_i86
bb_rcarmnext445:
  %v1823 = load i64, ptr %slot265, align 8
  %cmp1824 = icmp eq i64 %v1823, 1
  %cv1825 = zext i1 %cmp1824 to i64
  store i64 %cv1825, ptr %slot267, align 8
  %v1826 = load i64, ptr %slot267, align 8
  %cond1827 = icmp ne i64 %v1826, 0
  br i1 %cond1827, label %bb_rcarm446, label %bb_rcarmnext446
bb_rcarm446:
  br label %bb_i93
bb_rcarmnext446:
  %v1828 = load i64, ptr %slot265, align 8
  %cmp1829 = icmp eq i64 %v1828, 2
  %cv1830 = zext i1 %cmp1829 to i64
  store i64 %cv1830, ptr %slot268, align 8
  %v1831 = load i64, ptr %slot268, align 8
  %cond1832 = icmp ne i64 %v1831, 0
  br i1 %cond1832, label %bb_rcarm447, label %bb_rcarmnext447
bb_rcarm447:
  %v1833 = load i64, ptr %slot17, align 8
  store i64 %v1833, ptr %slot269, align 8
  %v1834 = load i64, ptr %slot264, align 8
  %op1835 = add i64 %v1834, 8
  store i64 %op1835, ptr %slot270, align 8
  %v1836 = load i64, ptr %slot44, align 8
  store i64 %v1836, ptr %slot271, align 8
  %v1837 = load i64, ptr %slot270, align 8
  %p1838 = inttoptr i64 %v1837 to ptr
  %ld1839 = load i64, ptr %p1838, align 8
  store i64 %ld1839, ptr %slot272, align 8
  %v1840 = load i64, ptr %slot272, align 8
  %v1841 = load i64, ptr %slot269, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  store i64 %v1840, ptr %p1842, align 8, !alias.scope !3, !noalias !4
  %v1843 = load i64, ptr %slot13, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  store i32 0, ptr %p1844, align 4, !alias.scope !3, !noalias !4
  %v1845 = load i64, ptr %slot12, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  store i32 1, ptr %p1846, align 4, !alias.scope !3, !noalias !4
  %v1847 = load i64, ptr %slot269, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  %ld1849 = load i64, ptr %p1848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1849, ptr %slot273, align 8
  %v1850 = load i64, ptr %slot273, align 8
  %v1851 = load i64, ptr %slot22, align 8
  %p1852 = inttoptr i64 %v1851 to ptr
  store i64 %v1850, ptr %p1852, align 8, !alias.scope !3, !noalias !4
  %v1853 = load i64, ptr %slot12, align 8
  %p1854 = inttoptr i64 %v1853 to ptr
  store i32 0, ptr %p1854, align 4, !alias.scope !3, !noalias !4
  br label %bb_i58
bb_rcarmnext447:
  %v1855 = load i64, ptr %slot265, align 8
  %cmp1856 = icmp eq i64 %v1855, 3
  %cv1857 = zext i1 %cmp1856 to i64
  store i64 %cv1857, ptr %slot274, align 8
  %v1858 = load i64, ptr %slot274, align 8
  %cond1859 = icmp ne i64 %v1858, 0
  br i1 %cond1859, label %bb_rcarm456, label %bb_rcarmnext456
bb_rcarm456:
  br label %bb_i100
bb_rcarmnext456:
  br label %bb_failure
bb_i58:
  %v1860 = load i64, ptr %slot18, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  %ld1862 = load i64, ptr %p1861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1862, ptr %slot275, align 8
  %v1863 = load i64, ptr %slot275, align 8
  %v1864 = load i64, ptr %slot33, align 8
  %p1865 = inttoptr i64 %v1863 to ptr
  %p1866 = inttoptr i64 %v1864 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1866, ptr %p1865, i64 304, i1 false), !alias.scope !10000000
  %v1867 = load i64, ptr %slot33, align 8
  %v1868 = load i64, ptr %slot26, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  store i64 %v1867, ptr %p1869, align 8, !alias.scope !3, !noalias !4
  %v1870 = load i64, ptr %slot26, align 8
  %p1871 = inttoptr i64 %v1870 to ptr
  %ld1872 = load i64, ptr %p1871, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1872, ptr %slot276, align 8
  %v1873 = load i64, ptr %slot276, align 8
  %op1874 = add i64 %v1873, 32
  store i64 %op1874, ptr %slot277, align 8
  %v1875 = load i64, ptr %slot277, align 8
  %v1876 = load i64, ptr %slot26, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i64 %v1875, ptr %p1877, align 8, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot8, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  %ld1880 = load i32, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1880, ptr %slot278, align 8
  %v1881 = load i32, ptr %slot278, align 8
  %cv1882 = zext i32 %v1881 to i64
  %cond1883 = icmp ne i64 %cv1882, 0
  br i1 %cond1883, label %bb_rcslotdrop462, label %bb_rcslotdone462
bb_rcslotdrop462:
  %v1884 = load i64, ptr %slot8, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i32 0, ptr %p1885, align 4, !alias.scope !3, !noalias !4
  %v1886 = load i64, ptr %slot23, align 8
  store i64 %v1886, ptr %slot279, align 8
  %v1887 = load i64, ptr %slot9, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  %ld1889 = load i32, ptr %p1888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1889, ptr %slot280, align 8
  %v1890 = load i32, ptr %slot280, align 8
  %op1891 = and i32 %v1890, 28
  store i32 %op1891, ptr %slot281, align 8
  %v1892 = load i32, ptr %slot281, align 8
  %cv1893 = zext i32 %v1892 to i64
  %cond1894 = icmp ne i64 %cv1893, 0
  br i1 %cond1894, label %bb_rcslotrole462, label %bb_rcslotowner462
bb_rcslotrole462:
  %v1895 = load i64, ptr %slot43, align 8
  store i64 %v1895, ptr %slot282, align 8
  %v1896 = load i64, ptr %slot282, align 8
  %v1897 = load i64, ptr %slot279, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1896, i64 %v1897) nomerge, !dbg !136
  br label %bb_rcslotdone462
bb_rcslotowner462:
  %v1898 = load i64, ptr %slot43, align 8
  store i64 %v1898, ptr %slot283, align 8
  %v1899 = load i64, ptr %slot283, align 8
  %v1900 = load i64, ptr %slot279, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1899, i64 %v1900) nomerge, !dbg !136
  br label %bb_rcslotdone462
bb_rcslotdone462:
  %v1901 = load i64, ptr %slot18, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  %ld1903 = load i64, ptr %p1902, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1903, ptr %slot284, align 8
  %v1904 = load i64, ptr %slot284, align 8
  %op1905 = add i64 %v1904, 32
  store i64 %op1905, ptr %slot285, align 8
  %v1906 = load i64, ptr %slot23, align 8
  store i64 %v1906, ptr %slot286, align 8
  %v1907 = load i64, ptr %slot285, align 8
  %v1908 = load i64, ptr %slot286, align 8
  %p1909 = inttoptr i64 %v1907 to ptr
  %p1910 = inttoptr i64 %v1908 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1910, ptr %p1909, i64 208, i1 false), !alias.scope !10000000
  %v1911 = load i64, ptr %slot285, align 8
  %p1912 = inttoptr i64 %v1911 to ptr
  call void @llvm.memset.p0.i64(ptr %p1912, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !136
  %v1913 = load i64, ptr %slot8, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  store i32 1, ptr %p1914, align 4, !alias.scope !3, !noalias !4
  %v1915 = load i64, ptr %slot23, align 8
  %v1916 = load i64, ptr %slot26, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  store i64 %v1915, ptr %p1917, align 8, !alias.scope !3, !noalias !4
  %v1918 = load i64, ptr %slot22, align 8
  %p1919 = inttoptr i64 %v1918 to ptr
  %ld1920 = load i64, ptr %p1919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1920, ptr %slot287, align 8
  %v1921 = load i64, ptr %slot287, align 8
  %v1922 = load i64, ptr %slot27, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  store i64 %v1921, ptr %p1923, align 8, !alias.scope !3, !noalias !4
  %v1924 = load i64, ptr %slot27, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %ld1926 = load i64, ptr %p1925, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1926, ptr %slot288, align 8
  %v1927 = load i64, ptr %slot1, align 8
  %p1928 = inttoptr i64 %v1927 to ptr
  %v1929 = load i64, ptr %slot288, align 8
  %call1930 = call i64 @myl_qbe_float_unary(ptr %p1928, i64 7, i64 %v1929) nomerge, !dbg !138
  store i64 %call1930, ptr %slot289, align 8
  %v1931 = load i64, ptr %slot289, align 8
  %v1932 = load i64, ptr %slot27, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  store i64 %v1931, ptr %p1933, align 8, !alias.scope !3, !noalias !4
  %v1934 = load i64, ptr %slot34, align 8
  store i64 %v1934, ptr %slot290, align 8
  %v1935 = load i64, ptr %slot290, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  store i64 0, ptr %p1936, align 8, !alias.scope !3, !noalias !4
  %v1937 = load i64, ptr %slot290, align 8
  %p1939 = inttoptr i64 %v1937 to ptr
  %gep1940 = getelementptr i8, ptr %p1939, i64 8
  %op1938 = ptrtoint ptr %gep1940 to i64
  store i64 %op1938, ptr %slot291, align 8
  %v1941 = load i64, ptr %slot291, align 8
  %p1942 = inttoptr i64 %v1941 to ptr
  store i64 0, ptr %p1942, align 8, !alias.scope !3, !noalias !4
  %v1943 = load i64, ptr %slot290, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  store i32 2, ptr %p1944, align 4, !alias.scope !3, !noalias !4
  %v1945 = load i64, ptr %slot14, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  store i32 1, ptr %p1946, align 4, !alias.scope !3, !noalias !4
  %v1947 = load i64, ptr %slot27, align 8
  store i64 %v1947, ptr %slot292, align 8
  %v1948 = load i64, ptr %slot290, align 8
  %p1950 = inttoptr i64 %v1948 to ptr
  %gep1951 = getelementptr i8, ptr %p1950, i64 8
  %op1949 = ptrtoint ptr %gep1951 to i64
  store i64 %op1949, ptr %slot293, align 8
  %v1952 = load i64, ptr %slot44, align 8
  store i64 %v1952, ptr %slot294, align 8
  %v1953 = load i64, ptr %slot292, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  %ld1955 = load i64, ptr %p1954, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1955, ptr %slot295, align 8
  %v1956 = load i64, ptr %slot295, align 8
  %v1957 = load i64, ptr %slot293, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  store i64 %v1956, ptr %p1958, align 8, !alias.scope !3, !noalias !4
  %v1959 = load i64, ptr %slot290, align 8
  %v1960 = load i64, ptr %slot27, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  store i64 %v1959, ptr %p1961, align 8, !alias.scope !3, !noalias !4
  %v1962 = load i64, ptr %slot26, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  %ld1964 = load i64, ptr %p1963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1964, ptr %slot296, align 8
  %v1965 = load i64, ptr %slot27, align 8
  %p1966 = inttoptr i64 %v1965 to ptr
  %ld1967 = load i64, ptr %p1966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1967, ptr %slot297, align 8
  %v1968 = load i64, ptr %slot1, align 8
  %v1969 = load i64, ptr %slot296, align 8
  %v1970 = load i64, ptr %slot297, align 8
  %call1971 = call i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64 %v1968, i64 %v1969, i64 %v1970) nomerge, !dbg !140
  store i64 %call1971, ptr %slot298, align 8
  %v1972 = load i64, ptr %slot298, align 8
  %v1973 = load i64, ptr %slot26, align 8
  %p1974 = inttoptr i64 %v1973 to ptr
  store i64 %v1972, ptr %p1974, align 8, !alias.scope !3, !noalias !4
  %v1975 = load i64, ptr %slot10, align 8
  %p1976 = inttoptr i64 %v1975 to ptr
  %ld1977 = load i32, ptr %p1976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1977, ptr %slot299, align 8
  %v1978 = load i32, ptr %slot299, align 8
  %cv1979 = zext i32 %v1978 to i64
  %cond1980 = icmp ne i64 %cv1979, 0
  br i1 %cond1980, label %bb_rcslotdrop489, label %bb_rcslotdone489
bb_rcslotdrop489:
  %v1981 = load i64, ptr %slot10, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  store i32 0, ptr %p1982, align 4, !alias.scope !3, !noalias !4
  %v1983 = load i64, ptr %slot15, align 8
  store i64 %v1983, ptr %slot300, align 8
  %v1984 = load i64, ptr %slot11, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  %ld1986 = load i32, ptr %p1985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1986, ptr %slot301, align 8
  %v1987 = load i32, ptr %slot301, align 8
  %op1988 = and i32 %v1987, 28
  store i32 %op1988, ptr %slot302, align 8
  %v1989 = load i32, ptr %slot302, align 8
  %cv1990 = zext i32 %v1989 to i64
  %cond1991 = icmp ne i64 %cv1990, 0
  br i1 %cond1991, label %bb_rcslotrole489, label %bb_rcslotowner489
bb_rcslotrole489:
  %v1992 = load i64, ptr %slot43, align 8
  store i64 %v1992, ptr %slot303, align 8
  %v1993 = load i64, ptr %slot303, align 8
  %v1994 = load i64, ptr %slot300, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1993, i64 %v1994) nomerge, !dbg !140
  br label %bb_rcslotdone489
bb_rcslotowner489:
  %v1995 = load i64, ptr %slot43, align 8
  store i64 %v1995, ptr %slot304, align 8
  %v1996 = load i64, ptr %slot304, align 8
  %v1997 = load i64, ptr %slot300, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1996, i64 %v1997) nomerge, !dbg !140
  br label %bb_rcslotdone489
bb_rcslotdone489:
  %v1998 = load i64, ptr %slot18, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  %ld2000 = load i64, ptr %p1999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2000, ptr %slot305, align 8
  %v2001 = load i64, ptr %slot305, align 8
  %op2002 = add i64 %v2001, 32
  store i64 %op2002, ptr %slot306, align 8
  %v2003 = load i64, ptr %slot23, align 8
  store i64 %v2003, ptr %slot307, align 8
  %v2004 = load i64, ptr %slot307, align 8
  %v2005 = load i64, ptr %slot306, align 8
  %p2006 = inttoptr i64 %v2004 to ptr
  %p2007 = inttoptr i64 %v2005 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2007, ptr %p2006, i64 208, i1 false), !alias.scope !10000000
  %v2008 = load i64, ptr %slot307, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  call void @llvm.memset.p0.i64(ptr %p2009, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !142
  %v2010 = load i64, ptr %slot8, align 8
  %p2011 = inttoptr i64 %v2010 to ptr
  store i32 0, ptr %p2011, align 4, !alias.scope !3, !noalias !4
  %v2012 = load i64, ptr %slot26, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  store i64 0, ptr %p2013, align 8, !alias.scope !3, !noalias !4
  %v2014 = load i64, ptr %slot26, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  store i64 0, ptr %p2015, align 8, !alias.scope !3, !noalias !4
  %v2016 = load i64, ptr %slot35, align 8
  store i64 %v2016, ptr %slot308, align 8
  %v2017 = load i64, ptr %slot308, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  store i64 0, ptr %p2018, align 8, !alias.scope !3, !noalias !4
  %v2019 = load i64, ptr %slot308, align 8
  %p2021 = inttoptr i64 %v2019 to ptr
  %gep2022 = getelementptr i8, ptr %p2021, i64 8
  %op2020 = ptrtoint ptr %gep2022 to i64
  store i64 %op2020, ptr %slot309, align 8
  %v2023 = load i64, ptr %slot309, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i64 0, ptr %p2024, align 8, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot308, align 8
  %p2027 = inttoptr i64 %v2025 to ptr
  %gep2028 = getelementptr i8, ptr %p2027, i64 16
  %op2026 = ptrtoint ptr %gep2028 to i64
  store i64 %op2026, ptr %slot310, align 8
  %v2029 = load i64, ptr %slot310, align 8
  %p2030 = inttoptr i64 %v2029 to ptr
  store i64 0, ptr %p2030, align 8, !alias.scope !3, !noalias !4
  %v2031 = load i64, ptr %slot308, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  store i32 0, ptr %p2032, align 4, !alias.scope !3, !noalias !4
  %v2033 = load i64, ptr %slot14, align 8
  %p2034 = inttoptr i64 %v2033 to ptr
  store i32 1, ptr %p2034, align 4, !alias.scope !3, !noalias !4
  %v2035 = load i64, ptr %slot26, align 8
  store i64 %v2035, ptr %slot311, align 8
  %v2036 = load i64, ptr %slot308, align 8
  %p2038 = inttoptr i64 %v2036 to ptr
  %gep2039 = getelementptr i8, ptr %p2038, i64 8
  %op2037 = ptrtoint ptr %gep2039 to i64
  store i64 %op2037, ptr %slot312, align 8
  %v2040 = load i64, ptr %slot44, align 8
  store i64 %v2040, ptr %slot313, align 8
  store i64 0, ptr %slot314, align 8
  %v2041 = load i64, ptr %slot308, align 8
  %v2042 = load i64, ptr %slot26, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  store i64 %v2041, ptr %p2043, align 8, !alias.scope !3, !noalias !4
  %v2044 = load i64, ptr %slot26, align 8
  %p2045 = inttoptr i64 %v2044 to ptr
  %ld2046 = load i64, ptr %p2045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2046, ptr %slot315, align 8
  %v2047 = load i64, ptr %slot15, align 8
  store i64 %v2047, ptr %slot316, align 8
  %v2048 = load i64, ptr %slot315, align 8
  %v2049 = load i64, ptr %slot316, align 8
  %p2050 = inttoptr i64 %v2048 to ptr
  %p2051 = inttoptr i64 %v2049 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2051, ptr %p2050, i64 24, i1 false)
  %v2052 = load i64, ptr %slot11, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  store i32 2, ptr %p2053, align 4, !alias.scope !3, !noalias !4
  %v2054 = load i64, ptr %slot10, align 8
  %p2055 = inttoptr i64 %v2054 to ptr
  store i32 1, ptr %p2055, align 4, !alias.scope !3, !noalias !4
  %v2056 = load i64, ptr %slot316, align 8
  %v2057 = load i64, ptr %slot26, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  store i64 %v2056, ptr %p2058, align 8, !alias.scope !3, !noalias !4
  %v2059 = load i64, ptr %slot26, align 8
  %p2060 = inttoptr i64 %v2059 to ptr
  %ld2061 = load i64, ptr %p2060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2061, ptr %slot317, align 8
  %v2062 = load i64, ptr %slot26, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  %ld2064 = load i64, ptr %p2063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2064, ptr %slot318, align 8
  %v2065 = load i64, ptr %slot17, align 8
  store i64 %v2065, ptr %slot319, align 8
  %v2066 = load i64, ptr %slot44, align 8
  store i64 %v2066, ptr %slot320, align 8
  %v2067 = load i64, ptr %slot43, align 8
  %v2068 = load i64, ptr %slot319, align 8
  %v2069 = load i64, ptr %slot318, align 8
  %v2070 = load i64, ptr %slot320, align 8
  %cv2071 = trunc i64 %v2070 to i32
  %call2072 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v2067, i64 %v2068, i64 %v2069, i32 %cv2071) nomerge, !dbg !144
  store i32 %call2072, ptr %slot321, align 8
  %v2073 = load i32, ptr %slot321, align 8
  %cv2074 = zext i32 %v2073 to i64
  %cond2075 = icmp ne i64 %cv2074, 0
  br i1 %cond2075, label %bb_rcsuccess518, label %bb_rcfailure518
bb_rcfailure518:
  %v2076 = load i64, ptr %slot43, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  %call2078 = call i32 @myl_rc_take_failure(ptr %p2077) nomerge, !dbg !144
  store i32 %call2078, ptr %slot322, align 8
  %v2079 = load i64, ptr %slot1, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  %v2081 = load i32, ptr %slot322, align 8
  %call2082 = call i32 @myl_qbe_rc_status(ptr %p2080, i32 %v2081) nomerge, !dbg !144
  store i32 %call2082, ptr %slot323, align 8
  br label %bb_failure
bb_rcsuccess518:
  %v2083 = load i64, ptr %slot10, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  store i32 0, ptr %p2084, align 4, !alias.scope !3, !noalias !4
  %v2085 = load i64, ptr %slot13, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  store i32 2, ptr %p2086, align 4, !alias.scope !3, !noalias !4
  %v2087 = load i64, ptr %slot12, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  store i32 1, ptr %p2088, align 4, !alias.scope !3, !noalias !4
  %v2089 = load i64, ptr %slot17, align 8
  store i64 %v2089, ptr %slot324, align 8
  %v2090 = load i64, ptr %slot12, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  store i32 0, ptr %p2091, align 4, !alias.scope !3, !noalias !4
  %v2092 = load i64, ptr %slot10, align 8
  %p2093 = inttoptr i64 %v2092 to ptr
  %ld2094 = load i32, ptr %p2093, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2094, ptr %slot325, align 8
  %v2095 = load i32, ptr %slot325, align 8
  %cv2096 = zext i32 %v2095 to i64
  %cond2097 = icmp ne i64 %cv2096, 0
  br i1 %cond2097, label %bb_rcslotdrop528, label %bb_rcslotdone528
bb_rcslotdrop528:
  %v2098 = load i64, ptr %slot10, align 8
  %p2099 = inttoptr i64 %v2098 to ptr
  store i32 0, ptr %p2099, align 4, !alias.scope !3, !noalias !4
  %v2100 = load i64, ptr %slot15, align 8
  store i64 %v2100, ptr %slot326, align 8
  %v2101 = load i64, ptr %slot11, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  %ld2103 = load i32, ptr %p2102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2103, ptr %slot327, align 8
  %v2104 = load i32, ptr %slot327, align 8
  %op2105 = and i32 %v2104, 28
  store i32 %op2105, ptr %slot328, align 8
  %v2106 = load i32, ptr %slot328, align 8
  %cv2107 = zext i32 %v2106 to i64
  %cond2108 = icmp ne i64 %cv2107, 0
  br i1 %cond2108, label %bb_rcslotrole528, label %bb_rcslotowner528
bb_rcslotrole528:
  %v2109 = load i64, ptr %slot43, align 8
  store i64 %v2109, ptr %slot329, align 8
  %v2110 = load i64, ptr %slot329, align 8
  %v2111 = load i64, ptr %slot326, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2110, i64 %v2111) nomerge, !dbg !144
  br label %bb_rcslotdone528
bb_rcslotowner528:
  %v2112 = load i64, ptr %slot43, align 8
  store i64 %v2112, ptr %slot330, align 8
  %v2113 = load i64, ptr %slot330, align 8
  %v2114 = load i64, ptr %slot326, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2113, i64 %v2114) nomerge, !dbg !144
  br label %bb_rcslotdone528
bb_rcslotdone528:
  %v2115 = load i64, ptr %slot8, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  %ld2117 = load i32, ptr %p2116, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2117, ptr %slot331, align 8
  %v2118 = load i32, ptr %slot331, align 8
  %cv2119 = zext i32 %v2118 to i64
  %cond2120 = icmp ne i64 %cv2119, 0
  br i1 %cond2120, label %bb_rcslotdrop555, label %bb_rcslotdone555
bb_rcslotdrop555:
  %v2121 = load i64, ptr %slot8, align 8
  %p2122 = inttoptr i64 %v2121 to ptr
  store i32 0, ptr %p2122, align 4, !alias.scope !3, !noalias !4
  %v2123 = load i64, ptr %slot23, align 8
  store i64 %v2123, ptr %slot332, align 8
  %v2124 = load i64, ptr %slot9, align 8
  %p2125 = inttoptr i64 %v2124 to ptr
  %ld2126 = load i32, ptr %p2125, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2126, ptr %slot333, align 8
  %v2127 = load i32, ptr %slot333, align 8
  %op2128 = and i32 %v2127, 28
  store i32 %op2128, ptr %slot334, align 8
  %v2129 = load i32, ptr %slot334, align 8
  %cv2130 = zext i32 %v2129 to i64
  %cond2131 = icmp ne i64 %cv2130, 0
  br i1 %cond2131, label %bb_rcslotrole555, label %bb_rcslotowner555
bb_rcslotrole555:
  %v2132 = load i64, ptr %slot43, align 8
  store i64 %v2132, ptr %slot335, align 8
  %v2133 = load i64, ptr %slot335, align 8
  %v2134 = load i64, ptr %slot332, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2133, i64 %v2134) nomerge, !dbg !144
  br label %bb_rcslotdone555
bb_rcslotowner555:
  %v2135 = load i64, ptr %slot43, align 8
  store i64 %v2135, ptr %slot336, align 8
  %v2136 = load i64, ptr %slot336, align 8
  %v2137 = load i64, ptr %slot332, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2136, i64 %v2137) nomerge, !dbg !144
  br label %bb_rcslotdone555
bb_rcslotdone555:
  %v2138 = load i64, ptr %slot6, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  %ld2140 = load i32, ptr %p2139, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2140, ptr %slot337, align 8
  %v2141 = load i32, ptr %slot337, align 8
  %cv2142 = zext i32 %v2141 to i64
  %cond2143 = icmp ne i64 %cv2142, 0
  br i1 %cond2143, label %bb_rcslotdrop582, label %bb_rcslotdone582
bb_rcslotdrop582:
  %v2144 = load i64, ptr %slot6, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  store i32 0, ptr %p2145, align 4, !alias.scope !3, !noalias !4
  %v2146 = load i64, ptr %slot21, align 8
  store i64 %v2146, ptr %slot338, align 8
  %v2147 = load i64, ptr %slot7, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  %ld2149 = load i32, ptr %p2148, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2149, ptr %slot339, align 8
  %v2150 = load i32, ptr %slot339, align 8
  %op2151 = and i32 %v2150, 28
  store i32 %op2151, ptr %slot340, align 8
  %v2152 = load i32, ptr %slot340, align 8
  %cv2153 = zext i32 %v2152 to i64
  %cond2154 = icmp ne i64 %cv2153, 0
  br i1 %cond2154, label %bb_rcslotrole582, label %bb_rcslotowner582
bb_rcslotrole582:
  %v2155 = load i64, ptr %slot43, align 8
  store i64 %v2155, ptr %slot341, align 8
  %v2156 = load i64, ptr %slot341, align 8
  %v2157 = load i64, ptr %slot338, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2156, i64 %v2157) nomerge, !dbg !144
  br label %bb_rcslotdone582
bb_rcslotowner582:
  %v2158 = load i64, ptr %slot43, align 8
  store i64 %v2158, ptr %slot342, align 8
  %v2159 = load i64, ptr %slot342, align 8
  %v2160 = load i64, ptr %slot338, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2159, i64 %v2160) nomerge, !dbg !144
  br label %bb_rcslotdone582
bb_rcslotdone582:
  %v2161 = load i64, ptr %slot324, align 8
  %p2162 = inttoptr i64 %v2161 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2162, i64 24, i1 false)
  ret void
bb_i86:
  %p2163 = inttoptr i64 ptrtoint (ptr @myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5 to i64) to ptr
  %ld2164 = load i64, ptr %p2163, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2164, ptr %slot343, align 8
  %v2165 = load i64, ptr %slot343, align 8
  %v2166 = load i64, ptr %slot26, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  store i64 %v2165, ptr %p2167, align 8, !alias.scope !3, !noalias !4
  %v2168 = load i64, ptr %slot26, align 8
  %p2169 = inttoptr i64 %v2168 to ptr
  %ld2170 = load i64, ptr %p2169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2170, ptr %slot344, align 8
  %v2171 = load i64, ptr %slot344, align 8
  %v2172 = load i64, ptr %slot16, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  store i64 %v2171, ptr %p2173, align 8, !alias.scope !3, !noalias !4
  %v2174 = load i64, ptr %slot16, align 8
  store i64 %v2174, ptr %slot345, align 8
  %v2175 = load i64, ptr %slot17, align 8
  store i64 %v2175, ptr %slot346, align 8
  %v2176 = load i64, ptr %slot345, align 8
  %v2177 = load i64, ptr %slot346, align 8
  %p2178 = inttoptr i64 %v2176 to ptr
  %p2179 = inttoptr i64 %v2177 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2179, ptr %p2178, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2180 = load i64, ptr %slot13, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i32 2, ptr %p2181, align 4, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot12, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i32 1, ptr %p2183, align 4, !alias.scope !3, !noalias !4
  %v2184 = load i64, ptr %slot15, align 8
  store i64 %v2184, ptr %slot347, align 8
  %v2185 = load i64, ptr %slot17, align 8
  store i64 %v2185, ptr %slot348, align 8
  %v2186 = load i64, ptr %slot348, align 8
  %v2187 = load i64, ptr %slot347, align 8
  %p2188 = inttoptr i64 %v2186 to ptr
  %p2189 = inttoptr i64 %v2187 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2189, ptr %p2188, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2190 = load i64, ptr %slot11, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  store i32 2, ptr %p2191, align 4, !alias.scope !3, !noalias !4
  %v2192 = load i64, ptr %slot13, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %ld2194 = load i32, ptr %p2193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2194, ptr %slot349, align 8
  %v2195 = load i32, ptr %slot349, align 8
  %v2196 = load i64, ptr %slot11, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  store i32 %v2195, ptr %p2197, align 4, !alias.scope !3, !noalias !4
  %v2198 = load i64, ptr %slot12, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  store i32 0, ptr %p2199, align 4, !alias.scope !3, !noalias !4
  %v2200 = load i64, ptr %slot10, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  store i32 1, ptr %p2201, align 4, !alias.scope !3, !noalias !4
  %v2202 = load i64, ptr %slot347, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %ld2204 = load i64, ptr %p2203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2204, ptr %slot350, align 8
  %v2205 = load i64, ptr %slot350, align 8
  %v2206 = load i64, ptr %slot26, align 8
  %p2207 = inttoptr i64 %v2206 to ptr
  store i64 %v2205, ptr %p2207, align 8, !alias.scope !3, !noalias !4
  %v2208 = load i64, ptr %slot19, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  %ld2210 = load i64, ptr %p2209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2210, ptr %slot351, align 8
  %v2211 = load i64, ptr %slot351, align 8
  %v2212 = load i64, ptr %slot27, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  store i64 %v2211, ptr %p2213, align 8, !alias.scope !3, !noalias !4
  %v2214 = load i64, ptr %slot27, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  %ld2216 = load i64, ptr %p2215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2216, ptr %slot352, align 8
  %v2217 = load i64, ptr %slot352, align 8
  %op2218 = add i64 %v2217, 0
  store i64 %op2218, ptr %slot353, align 8
  %v2219 = load i64, ptr %slot353, align 8
  %v2220 = load i64, ptr %slot27, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  store i64 %v2219, ptr %p2221, align 8, !alias.scope !3, !noalias !4
  %v2222 = load i64, ptr %slot27, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  %ld2224 = load i64, ptr %p2223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2224, ptr %slot354, align 8
  %v2225 = load i64, ptr %slot354, align 8
  %op2226 = add i64 %v2225, 24
  store i64 %op2226, ptr %slot355, align 8
  %v2227 = load i64, ptr %slot355, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  %ld2229 = load i64, ptr %p2228, align 8
  store i64 %ld2229, ptr %slot356, align 8
  %v2230 = load i64, ptr %slot356, align 8
  %v2231 = load i64, ptr %slot27, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  store i64 %v2230, ptr %p2232, align 8, !alias.scope !3, !noalias !4
  %v2233 = load i64, ptr %slot26, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  %ld2235 = load i64, ptr %p2234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2235, ptr %slot357, align 8
  %v2236 = load i64, ptr %slot27, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  %ld2238 = load i64, ptr %p2237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2238, ptr %slot358, align 8
  %v2239 = load i64, ptr %slot1, align 8
  %v2240 = load i64, ptr %slot357, align 8
  %v2241 = load i64, ptr %slot358, align 8
  %call2242 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v2239, i64 %v2240, i64 %v2241) nomerge, !dbg !146
  store { i64, i64 } %call2242, ptr %callresult360, align 8
  %addr2243 = ptrtoint ptr %callresult360 to i64
  store i64 %addr2243, ptr %slot359, align 8
  %v2244 = load i64, ptr %slot359, align 8
  %v2245 = load i64, ptr %slot26, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  store i64 %v2244, ptr %p2246, align 8, !alias.scope !3, !noalias !4
  %v2247 = load i64, ptr %slot26, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  %ld2249 = load i64, ptr %p2248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2249, ptr %slot361, align 8
  %v2250 = load i64, ptr %slot17, align 8
  store i64 %v2250, ptr %slot362, align 8
  %v2251 = load i64, ptr %slot43, align 8
  %v2252 = load i64, ptr %slot362, align 8
  %v2253 = load i64, ptr %slot361, align 8
  %call2254 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v2251, i64 %v2252, i64 %v2253) nomerge, !dbg !146
  store i32 %call2254, ptr %slot363, align 8
  %v2255 = load i32, ptr %slot363, align 8
  %cv2256 = zext i32 %v2255 to i64
  %cond2257 = icmp ne i64 %cv2256, 0
  br i1 %cond2257, label %bb_rcsuccess653, label %bb_rcfailure653
bb_rcfailure653:
  %v2258 = load i64, ptr %slot43, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  %call2260 = call i32 @myl_rc_take_failure(ptr %p2259) nomerge, !dbg !146
  store i32 %call2260, ptr %slot364, align 8
  %v2261 = load i64, ptr %slot1, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  %v2263 = load i32, ptr %slot364, align 8
  %call2264 = call i32 @myl_qbe_rc_status(ptr %p2262, i32 %v2263) nomerge, !dbg !146
  store i32 %call2264, ptr %slot365, align 8
  br label %bb_failure
bb_rcsuccess653:
  %v2265 = load i64, ptr %slot13, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  store i32 2, ptr %p2266, align 4, !alias.scope !3, !noalias !4
  %v2267 = load i64, ptr %slot13, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  store i32 16, ptr %p2268, align 4, !alias.scope !3, !noalias !4
  %v2269 = load i64, ptr %slot12, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  store i32 1, ptr %p2270, align 4, !alias.scope !3, !noalias !4
  %v2271 = load i64, ptr %slot10, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  %ld2273 = load i32, ptr %p2272, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2273, ptr %slot366, align 8
  %v2274 = load i32, ptr %slot366, align 8
  %cv2275 = zext i32 %v2274 to i64
  %cond2276 = icmp ne i64 %cv2275, 0
  br i1 %cond2276, label %bb_rcslotdrop661, label %bb_rcslotdone661
bb_rcslotdrop661:
  %v2277 = load i64, ptr %slot10, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  store i32 0, ptr %p2278, align 4, !alias.scope !3, !noalias !4
  %v2279 = load i64, ptr %slot15, align 8
  store i64 %v2279, ptr %slot367, align 8
  %v2280 = load i64, ptr %slot11, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  %ld2282 = load i32, ptr %p2281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2282, ptr %slot368, align 8
  %v2283 = load i32, ptr %slot368, align 8
  %op2284 = and i32 %v2283, 28
  store i32 %op2284, ptr %slot369, align 8
  %v2285 = load i32, ptr %slot369, align 8
  %cv2286 = zext i32 %v2285 to i64
  %cond2287 = icmp ne i64 %cv2286, 0
  br i1 %cond2287, label %bb_rcslotrole661, label %bb_rcslotowner661
bb_rcslotrole661:
  %v2288 = load i64, ptr %slot43, align 8
  store i64 %v2288, ptr %slot370, align 8
  %v2289 = load i64, ptr %slot367, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  %ld2291 = load i64, ptr %p2290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2291, ptr %slot371, align 8
  %v2292 = load i64, ptr %slot371, align 8
  %cmp2293 = icmp ne i64 %v2292, 0
  %cv2294 = zext i1 %cmp2293 to i32
  store i32 %cv2294, ptr %slot372, align 8
  %v2295 = load i32, ptr %slot372, align 8
  %cv2296 = zext i32 %v2295 to i64
  %cond2297 = icmp ne i64 %cv2296, 0
  br i1 %cond2297, label %bb_rcgnn677, label %bb_rcgdone677
bb_rcgnn677:
  %v2298 = load i64, ptr %slot371, align 8
  %op2299 = sub i64 %v2298, 16
  store i64 %op2299, ptr %slot373, align 8
  %v2300 = load i64, ptr %slot371, align 8
  %p2301 = inttoptr i64 %v2300 to ptr
  %rgep2302 = getelementptr i8, ptr %p2301, i64 -16
  %ld2303 = load i64, ptr %rgep2302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2303, ptr %slot374, align 8
  %v2304 = load i64, ptr %slot374, align 8
  %op2305 = and i64 %v2304, 4611686018427387906
  store i64 %op2305, ptr %slot375, align 8
  %v2306 = load i64, ptr %slot375, align 8
  %cmp2307 = icmp ne i64 %v2306, 0
  %cv2308 = zext i1 %cmp2307 to i32
  store i32 %cv2308, ptr %slot376, align 8
  %v2309 = load i32, ptr %slot376, align 8
  %cv2310 = zext i32 %v2309 to i64
  %cond2311 = icmp ne i64 %cv2310, 0
  br i1 %cond2311, label %bb_rcgclear677, label %bb_rcgcounted677
bb_rcgcounted677:
  %v2312 = load i64, ptr %slot371, align 8
  %op2313 = sub i64 %v2312, 24
  store i64 %op2313, ptr %slot377, align 8
  %v2314 = load i64, ptr %slot371, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %rgep2316 = getelementptr i8, ptr %p2315, i64 -24
  %ld2317 = load i64, ptr %rgep2316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2317, ptr %slot378, align 8
  %v2318 = load i64, ptr %slot378, align 8
  %op2319 = sub i64 %v2318, 1
  store i64 %op2319, ptr %slot379, align 8
  %v2320 = load i64, ptr %slot379, align 8
  %cmp2321 = icmp eq i64 %v2320, 0
  %cv2322 = zext i1 %cmp2321 to i32
  store i32 %cv2322, ptr %slot380, align 8
  %v2323 = load i32, ptr %slot380, align 8
  %cv2324 = zext i32 %v2323 to i64
  %cond2325 = icmp ne i64 %cv2324, 0
  br i1 %cond2325, label %bb_rcglast677, label %bb_rcgdec677
bb_rcglast677:
  %v2326 = load i64, ptr %slot371, align 8
  %op2327 = sub i64 %v2326, 32
  store i64 %op2327, ptr %slot381, align 8
  %v2328 = load i64, ptr %slot371, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  %rgep2330 = getelementptr i8, ptr %p2329, i64 -32
  %ld2331 = load i64, ptr %rgep2330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2331, ptr %slot382, align 8
  %v2332 = load i64, ptr %slot382, align 8
  %cmp2333 = icmp ne i64 %v2332, 0
  %cv2334 = zext i1 %cmp2333 to i32
  store i32 %cv2334, ptr %slot383, align 8
  %v2335 = load i32, ptr %slot383, align 8
  %cv2336 = zext i32 %v2335 to i64
  %cond2337 = icmp ne i64 %cv2336, 0
  br i1 %cond2337, label %bb_rcgdec677, label %bb_rcgslow677
bb_rcgslow677:
  %v2338 = load i64, ptr %slot370, align 8
  %v2339 = load i64, ptr %slot367, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2338, i64 %v2339) nomerge, !dbg !146
  br label %bb_rcgdone677
bb_rcgdec677:
  %v2340 = load i64, ptr %slot379, align 8
  %v2341 = load i64, ptr %slot371, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  %rgep2343 = getelementptr i8, ptr %p2342, i64 -24
  store i64 %v2340, ptr %rgep2343, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear677
bb_rcgclear677:
  %v2344 = load i64, ptr %slot367, align 8
  %p2345 = inttoptr i64 %v2344 to ptr
  store i64 0, ptr %p2345, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone677
bb_rcgdone677:
  br label %bb_rcslotdone661
bb_rcslotowner661:
  %v2346 = load i64, ptr %slot43, align 8
  store i64 %v2346, ptr %slot384, align 8
  %v2347 = load i64, ptr %slot367, align 8
  %p2348 = inttoptr i64 %v2347 to ptr
  %ld2349 = load i64, ptr %p2348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2349, ptr %slot385, align 8
  %v2350 = load i64, ptr %slot385, align 8
  %cmp2351 = icmp ne i64 %v2350, 0
  %cv2352 = zext i1 %cmp2351 to i32
  store i32 %cv2352, ptr %slot386, align 8
  %v2353 = load i32, ptr %slot386, align 8
  %cv2354 = zext i32 %v2353 to i64
  %cond2355 = icmp ne i64 %cv2354, 0
  br i1 %cond2355, label %bb_rcgnn692, label %bb_rcgdone692
bb_rcgnn692:
  %v2356 = load i64, ptr %slot385, align 8
  %op2357 = sub i64 %v2356, 16
  store i64 %op2357, ptr %slot387, align 8
  %v2358 = load i64, ptr %slot385, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  %rgep2360 = getelementptr i8, ptr %p2359, i64 -16
  %ld2361 = load i64, ptr %rgep2360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2361, ptr %slot388, align 8
  %v2362 = load i64, ptr %slot388, align 8
  %op2363 = and i64 %v2362, 4611686018427387906
  store i64 %op2363, ptr %slot389, align 8
  %v2364 = load i64, ptr %slot389, align 8
  %cmp2365 = icmp ne i64 %v2364, 0
  %cv2366 = zext i1 %cmp2365 to i32
  store i32 %cv2366, ptr %slot390, align 8
  %v2367 = load i32, ptr %slot390, align 8
  %cv2368 = zext i32 %v2367 to i64
  %cond2369 = icmp ne i64 %cv2368, 0
  br i1 %cond2369, label %bb_rcgclear692, label %bb_rcgcounted692
bb_rcgcounted692:
  %v2370 = load i64, ptr %slot385, align 8
  %op2371 = sub i64 %v2370, 32
  store i64 %op2371, ptr %slot391, align 8
  %v2372 = load i64, ptr %slot385, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %rgep2374 = getelementptr i8, ptr %p2373, i64 -32
  %ld2375 = load i64, ptr %rgep2374, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2375, ptr %slot392, align 8
  %v2376 = load i64, ptr %slot392, align 8
  %op2377 = sub i64 %v2376, 1
  store i64 %op2377, ptr %slot393, align 8
  %v2378 = load i64, ptr %slot393, align 8
  %cmp2379 = icmp eq i64 %v2378, 0
  %cv2380 = zext i1 %cmp2379 to i32
  store i32 %cv2380, ptr %slot394, align 8
  %v2381 = load i32, ptr %slot394, align 8
  %cv2382 = zext i32 %v2381 to i64
  %cond2383 = icmp ne i64 %cv2382, 0
  br i1 %cond2383, label %bb_rcglast692, label %bb_rcgdec692
bb_rcglast692:
  %v2384 = load i64, ptr %slot385, align 8
  %op2385 = sub i64 %v2384, 24
  store i64 %op2385, ptr %slot395, align 8
  %v2386 = load i64, ptr %slot385, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  %rgep2388 = getelementptr i8, ptr %p2387, i64 -24
  %ld2389 = load i64, ptr %rgep2388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2389, ptr %slot396, align 8
  %v2390 = load i64, ptr %slot396, align 8
  %cmp2391 = icmp ne i64 %v2390, 0
  %cv2392 = zext i1 %cmp2391 to i32
  store i32 %cv2392, ptr %slot397, align 8
  %v2393 = load i32, ptr %slot397, align 8
  %cv2394 = zext i32 %v2393 to i64
  %cond2395 = icmp ne i64 %cv2394, 0
  br i1 %cond2395, label %bb_rcgdec692, label %bb_rcgslow692
bb_rcgslow692:
  %v2396 = load i64, ptr %slot384, align 8
  %v2397 = load i64, ptr %slot367, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2396, i64 %v2397) nomerge, !dbg !146
  br label %bb_rcgdone692
bb_rcgdec692:
  %v2398 = load i64, ptr %slot393, align 8
  %v2399 = load i64, ptr %slot385, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %rgep2401 = getelementptr i8, ptr %p2400, i64 -32
  store i64 %v2398, ptr %rgep2401, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear692
bb_rcgclear692:
  %v2402 = load i64, ptr %slot367, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  store i64 0, ptr %p2403, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone692
bb_rcgdone692:
  br label %bb_rcslotdone661
bb_rcslotdone661:
  %v2404 = load i64, ptr %slot15, align 8
  store i64 %v2404, ptr %slot398, align 8
  %v2405 = load i64, ptr %slot17, align 8
  store i64 %v2405, ptr %slot399, align 8
  %v2406 = load i64, ptr %slot399, align 8
  %v2407 = load i64, ptr %slot398, align 8
  %p2408 = inttoptr i64 %v2406 to ptr
  %p2409 = inttoptr i64 %v2407 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2409, ptr %p2408, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2410 = load i64, ptr %slot11, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  store i32 2, ptr %p2411, align 4, !alias.scope !3, !noalias !4
  %v2412 = load i64, ptr %slot13, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  %ld2414 = load i32, ptr %p2413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2414, ptr %slot400, align 8
  %v2415 = load i32, ptr %slot400, align 8
  %v2416 = load i64, ptr %slot11, align 8
  %p2417 = inttoptr i64 %v2416 to ptr
  store i32 %v2415, ptr %p2417, align 4, !alias.scope !3, !noalias !4
  %v2418 = load i64, ptr %slot12, align 8
  %p2419 = inttoptr i64 %v2418 to ptr
  store i32 0, ptr %p2419, align 4, !alias.scope !3, !noalias !4
  %v2420 = load i64, ptr %slot10, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  store i32 1, ptr %p2421, align 4, !alias.scope !3, !noalias !4
  %v2422 = load i64, ptr %slot398, align 8
  %v2423 = load i64, ptr %slot26, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  store i64 %v2422, ptr %p2424, align 8, !alias.scope !3, !noalias !4
  %v2425 = load i64, ptr %slot36, align 8
  store i64 %v2425, ptr %slot401, align 8
  %v2426 = load i64, ptr %slot401, align 8
  %p2427 = inttoptr i64 %v2426 to ptr
  store i64 0, ptr %p2427, align 8, !alias.scope !3, !noalias !4
  %v2428 = load i64, ptr %slot401, align 8
  %p2430 = inttoptr i64 %v2428 to ptr
  %gep2431 = getelementptr i8, ptr %p2430, i64 8
  %op2429 = ptrtoint ptr %gep2431 to i64
  store i64 %op2429, ptr %slot402, align 8
  %v2432 = load i64, ptr %slot402, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  store i64 0, ptr %p2433, align 8, !alias.scope !3, !noalias !4
  %v2434 = load i64, ptr %slot401, align 8
  %p2436 = inttoptr i64 %v2434 to ptr
  %gep2437 = getelementptr i8, ptr %p2436, i64 16
  %op2435 = ptrtoint ptr %gep2437 to i64
  store i64 %op2435, ptr %slot403, align 8
  %v2438 = load i64, ptr %slot403, align 8
  %p2439 = inttoptr i64 %v2438 to ptr
  store i64 0, ptr %p2439, align 8, !alias.scope !3, !noalias !4
  %v2440 = load i64, ptr %slot401, align 8
  %p2441 = inttoptr i64 %v2440 to ptr
  store i32 1, ptr %p2441, align 4, !alias.scope !3, !noalias !4
  %v2442 = load i64, ptr %slot14, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  store i32 1, ptr %p2443, align 4, !alias.scope !3, !noalias !4
  %v2444 = load i64, ptr %slot26, align 8
  %p2445 = inttoptr i64 %v2444 to ptr
  %ld2446 = load i64, ptr %p2445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2446, ptr %slot404, align 8
  %v2447 = load i64, ptr %slot401, align 8
  %p2449 = inttoptr i64 %v2447 to ptr
  %gep2450 = getelementptr i8, ptr %p2449, i64 8
  %op2448 = ptrtoint ptr %gep2450 to i64
  store i64 %op2448, ptr %slot405, align 8
  %v2451 = load i64, ptr %slot44, align 8
  store i64 %v2451, ptr %slot406, align 8
  %v2452 = load i64, ptr %slot26, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  %ld2454 = load i64, ptr %p2453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2454, ptr %slot407, align 8
  %v2455 = load i64, ptr %slot10, align 8
  %p2456 = inttoptr i64 %v2455 to ptr
  %ld2457 = load i32, ptr %p2456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2457, ptr %slot408, align 8
  %v2458 = load i64, ptr %slot11, align 8
  %p2459 = inttoptr i64 %v2458 to ptr
  %ld2460 = load i32, ptr %p2459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2460, ptr %slot409, align 8
  %v2461 = load i32, ptr %slot409, align 8
  %op2462 = and i32 %v2461, 24
  store i32 %op2462, ptr %slot409, align 8
  %v2463 = load i32, ptr %slot409, align 8
  %cmp2464 = icmp eq i32 %v2463, 0
  %cv2465 = zext i1 %cmp2464 to i32
  store i32 %cv2465, ptr %slot410, align 8
  %v2466 = load i32, ptr %slot408, align 8
  %v2467 = load i32, ptr %slot410, align 8
  %op2468 = and i32 %v2466, %v2467
  store i32 %op2468, ptr %slot411, align 8
  %v2469 = load i32, ptr %slot411, align 8
  %cv2470 = zext i32 %v2469 to i64
  %cond2471 = icmp ne i64 %cv2470, 0
  br i1 %cond2471, label %bb_rctake713, label %bb_rccopy713
bb_rctake713:
  %v2472 = load i64, ptr %slot17, align 8
  store i64 %v2472, ptr %slot412, align 8
  %v2473 = load i64, ptr %slot44, align 8
  store i64 %v2473, ptr %slot413, align 8
  %v2474 = load i64, ptr %slot407, align 8
  %v2475 = load i64, ptr %slot412, align 8
  %op2476 = sub i64 %v2474, %v2475
  store i64 %op2476, ptr %slot414, align 8
  %v2477 = load i64, ptr %slot412, align 8
  %v2478 = load i64, ptr %slot407, align 8
  %op2479 = sub i64 %v2477, %v2478
  store i64 %op2479, ptr %slot415, align 8
  %v2480 = load i64, ptr %slot414, align 8
  %cmp2481 = icmp ult i64 %v2480, 16
  %cv2482 = zext i1 %cmp2481 to i32
  store i32 %cv2482, ptr %slot416, align 8
  %v2483 = load i64, ptr %slot415, align 8
  %cmp2484 = icmp ult i64 %v2483, 16
  %cv2485 = zext i1 %cmp2484 to i32
  store i32 %cv2485, ptr %slot417, align 8
  %v2486 = load i32, ptr %slot416, align 8
  %v2487 = load i32, ptr %slot417, align 8
  %op2488 = or i32 %v2486, %v2487
  store i32 %op2488, ptr %slot418, align 8
  %v2489 = load i32, ptr %slot418, align 8
  %cv2490 = zext i32 %v2489 to i64
  %cond2491 = icmp ne i64 %cv2490, 0
  br i1 %cond2491, label %bb_rcmoveslow722, label %bb_rcmovecheck722
bb_rcmovecheck722:
  %v2492 = load i64, ptr %slot407, align 8
  %op2493 = add i64 %v2492, 0
  store i64 %op2493, ptr %slot419, align 8
  %v2494 = load i64, ptr %slot419, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  %ld2496 = load i64, ptr %p2495, align 8
  store i64 %ld2496, ptr %slot420, align 8
  %v2497 = load i64, ptr %slot420, align 8
  %cmp2498 = icmp ne i64 %v2497, 0
  %cv2499 = zext i1 %cmp2498 to i32
  store i32 %cv2499, ptr %slot421, align 8
  %v2500 = load i32, ptr %slot421, align 8
  %cv2501 = zext i32 %v2500 to i64
  %cond2502 = icmp ne i64 %cv2501, 0
  br i1 %cond2502, label %bb_rcmoveheader730, label %bb_rcmovenext730
bb_rcmoveheader730:
  %v2503 = load i64, ptr %slot420, align 8
  %op2504 = sub i64 %v2503, 16
  store i64 %op2504, ptr %slot422, align 8
  %v2505 = load i64, ptr %slot420, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %rgep2507 = getelementptr i8, ptr %p2506, i64 -16
  %ld2508 = load i64, ptr %rgep2507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2508, ptr %slot423, align 8
  %v2509 = load i64, ptr %slot423, align 8
  %op2510 = and i64 %v2509, 5764607523034234881
  store i64 %op2510, ptr %slot424, align 8
  %v2511 = load i64, ptr %slot424, align 8
  %cmp2512 = icmp ne i64 %v2511, 0
  %cv2513 = zext i1 %cmp2512 to i32
  store i32 %cv2513, ptr %slot425, align 8
  %v2514 = load i32, ptr %slot425, align 8
  %cv2515 = zext i32 %v2514 to i64
  %cond2516 = icmp ne i64 %cv2515, 0
  br i1 %cond2516, label %bb_rcmoveslow722, label %bb_rcmovenext730
bb_rcmovenext730:
  %v2517 = load i64, ptr %slot407, align 8
  %v2518 = load i64, ptr %slot412, align 8
  %p2519 = inttoptr i64 %v2517 to ptr
  %p2520 = inttoptr i64 %v2518 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2520, ptr %p2519, i64 16, i1 false)
  %v2521 = load i64, ptr %slot407, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i64 0, ptr %p2522, align 8
  %v2523 = load i64, ptr %slot407, align 8
  %op2524 = add i64 %v2523, 8
  store i64 %op2524, ptr %slot426, align 8
  %v2525 = load i64, ptr %slot426, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  store i64 0, ptr %p2526, align 8
  br label %bb_rcmoved722
bb_rcmoveslow722:
  %v2527 = load i64, ptr %slot43, align 8
  %v2528 = load i64, ptr %slot412, align 8
  %v2529 = load i64, ptr %slot407, align 8
  %v2530 = load i64, ptr %slot413, align 8
  %cv2531 = trunc i64 %v2530 to i32
  %call2532 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v2527, i64 %v2528, i64 %v2529, i32 %cv2531) nomerge, !dbg !148
  store i32 %call2532, ptr %slot427, align 8
  %v2533 = load i32, ptr %slot427, align 8
  %cv2534 = zext i32 %v2533 to i64
  %cond2535 = icmp ne i64 %cv2534, 0
  br i1 %cond2535, label %bb_rcsuccess738, label %bb_rcfailure738
bb_rcfailure738:
  %v2536 = load i64, ptr %slot43, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %call2538 = call i32 @myl_rc_take_failure(ptr %p2537) nomerge, !dbg !148
  store i32 %call2538, ptr %slot428, align 8
  %v2539 = load i64, ptr %slot1, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  %v2541 = load i32, ptr %slot428, align 8
  %call2542 = call i32 @myl_qbe_rc_status(ptr %p2540, i32 %v2541) nomerge, !dbg !148
  store i32 %call2542, ptr %slot429, align 8
  br label %bb_failure
bb_rcsuccess738:
  br label %bb_rcmoved722
bb_rcmoved722:
  %v2543 = load i64, ptr %slot10, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  store i32 0, ptr %p2544, align 4, !alias.scope !3, !noalias !4
  %v2545 = load i64, ptr %slot13, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  store i32 2, ptr %p2546, align 4, !alias.scope !3, !noalias !4
  %v2547 = load i64, ptr %slot12, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  store i32 1, ptr %p2548, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared713
bb_rccopy713:
  %v2549 = load i64, ptr %slot17, align 8
  store i64 %v2549, ptr %slot430, align 8
  %v2550 = load i64, ptr %slot44, align 8
  store i64 %v2550, ptr %slot431, align 8
  %v2551 = load i64, ptr %slot43, align 8
  %v2552 = load i64, ptr %slot430, align 8
  %v2553 = load i64, ptr %slot407, align 8
  %v2554 = load i64, ptr %slot431, align 8
  %cv2555 = trunc i64 %v2554 to i32
  %call2556 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v2551, i64 %v2552, i64 %v2553, i32 %cv2555) nomerge, !dbg !148
  store i32 %call2556, ptr %slot432, align 8
  %v2557 = load i32, ptr %slot432, align 8
  %cv2558 = zext i32 %v2557 to i64
  %cond2559 = icmp ne i64 %cv2558, 0
  br i1 %cond2559, label %bb_rcsuccess747, label %bb_rcfailure747
bb_rcfailure747:
  %v2560 = load i64, ptr %slot43, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %call2562 = call i32 @myl_rc_take_failure(ptr %p2561) nomerge, !dbg !148
  store i32 %call2562, ptr %slot433, align 8
  %v2563 = load i64, ptr %slot1, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %v2565 = load i32, ptr %slot433, align 8
  %call2566 = call i32 @myl_qbe_rc_status(ptr %p2564, i32 %v2565) nomerge, !dbg !148
  store i32 %call2566, ptr %slot434, align 8
  br label %bb_failure
bb_rcsuccess747:
  %v2567 = load i64, ptr %slot13, align 8
  %p2568 = inttoptr i64 %v2567 to ptr
  store i32 2, ptr %p2568, align 4, !alias.scope !3, !noalias !4
  %v2569 = load i64, ptr %slot12, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  store i32 1, ptr %p2570, align 4, !alias.scope !3, !noalias !4
  %v2571 = load i64, ptr %slot10, align 8
  %p2572 = inttoptr i64 %v2571 to ptr
  %ld2573 = load i32, ptr %p2572, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2573, ptr %slot435, align 8
  %v2574 = load i32, ptr %slot435, align 8
  %cv2575 = zext i32 %v2574 to i64
  %cond2576 = icmp ne i64 %cv2575, 0
  br i1 %cond2576, label %bb_rcslotdrop754, label %bb_rcslotdone754
bb_rcslotdrop754:
  %v2577 = load i64, ptr %slot10, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  store i32 0, ptr %p2578, align 4, !alias.scope !3, !noalias !4
  %v2579 = load i64, ptr %slot15, align 8
  store i64 %v2579, ptr %slot436, align 8
  %v2580 = load i64, ptr %slot11, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  %ld2582 = load i32, ptr %p2581, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2582, ptr %slot437, align 8
  %v2583 = load i32, ptr %slot437, align 8
  %op2584 = and i32 %v2583, 28
  store i32 %op2584, ptr %slot438, align 8
  %v2585 = load i32, ptr %slot438, align 8
  %cv2586 = zext i32 %v2585 to i64
  %cond2587 = icmp ne i64 %cv2586, 0
  br i1 %cond2587, label %bb_rcslotrole754, label %bb_rcslotowner754
bb_rcslotrole754:
  %v2588 = load i64, ptr %slot43, align 8
  store i64 %v2588, ptr %slot439, align 8
  %v2589 = load i64, ptr %slot439, align 8
  %v2590 = load i64, ptr %slot436, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v2589, i64 %v2590) nomerge, !dbg !148
  br label %bb_rcslotdone754
bb_rcslotowner754:
  %v2591 = load i64, ptr %slot43, align 8
  store i64 %v2591, ptr %slot440, align 8
  %v2592 = load i64, ptr %slot440, align 8
  %v2593 = load i64, ptr %slot436, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v2592, i64 %v2593) nomerge, !dbg !148
  br label %bb_rcslotdone754
bb_rcslotdone754:
  br label %bb_rcprepared713
bb_rcprepared713:
  %v2594 = load i64, ptr %slot17, align 8
  store i64 %v2594, ptr %slot441, align 8
  %v2595 = load i64, ptr %slot441, align 8
  %v2596 = load i64, ptr %slot405, align 8
  %p2597 = inttoptr i64 %v2595 to ptr
  %p2598 = inttoptr i64 %v2596 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2598, ptr %p2597, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2599 = load i64, ptr %slot12, align 8
  %p2600 = inttoptr i64 %v2599 to ptr
  store i32 0, ptr %p2600, align 4, !alias.scope !3, !noalias !4
  %v2601 = load i64, ptr %slot401, align 8
  %v2602 = load i64, ptr %slot26, align 8
  %p2603 = inttoptr i64 %v2602 to ptr
  store i64 %v2601, ptr %p2603, align 8, !alias.scope !3, !noalias !4
  %p2604 = inttoptr i64 ptrtoint (ptr @myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p2604, i64 91) "call-inline-cost"="0", !dbg !148
  %v2605 = load i64, ptr %slot26, align 8
  %p2606 = inttoptr i64 %v2605 to ptr
  %ld2607 = load i64, ptr %p2606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2607, ptr %slot442, align 8
  %v2608 = load i64, ptr %slot15, align 8
  store i64 %v2608, ptr %slot443, align 8
  %v2609 = load i64, ptr %slot442, align 8
  %v2610 = load i64, ptr %slot443, align 8
  %p2611 = inttoptr i64 %v2609 to ptr
  %p2612 = inttoptr i64 %v2610 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2612, ptr %p2611, i64 24, i1 false)
  %v2613 = load i64, ptr %slot11, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  store i32 2, ptr %p2614, align 4, !alias.scope !3, !noalias !4
  %v2615 = load i64, ptr %slot10, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  store i32 1, ptr %p2616, align 4, !alias.scope !3, !noalias !4
  %v2617 = load i64, ptr %slot443, align 8
  %v2618 = load i64, ptr %slot26, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  store i64 %v2617, ptr %p2619, align 8, !alias.scope !3, !noalias !4
  %v2620 = load i64, ptr %slot26, align 8
  %p2621 = inttoptr i64 %v2620 to ptr
  %ld2622 = load i64, ptr %p2621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2622, ptr %slot444, align 8
  %v2623 = load i64, ptr %slot26, align 8
  %p2624 = inttoptr i64 %v2623 to ptr
  %ld2625 = load i64, ptr %p2624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2625, ptr %slot445, align 8
  %v2626 = load i64, ptr %slot17, align 8
  store i64 %v2626, ptr %slot446, align 8
  %v2627 = load i64, ptr %slot44, align 8
  store i64 %v2627, ptr %slot447, align 8
  %v2628 = load i64, ptr %slot43, align 8
  %v2629 = load i64, ptr %slot446, align 8
  %v2630 = load i64, ptr %slot445, align 8
  %v2631 = load i64, ptr %slot447, align 8
  %cv2632 = trunc i64 %v2631 to i32
  %call2633 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v2628, i64 %v2629, i64 %v2630, i32 %cv2632) nomerge, !dbg !150
  store i32 %call2633, ptr %slot448, align 8
  %v2634 = load i32, ptr %slot448, align 8
  %cv2635 = zext i32 %v2634 to i64
  %cond2636 = icmp ne i64 %cv2635, 0
  br i1 %cond2636, label %bb_rcsuccess772, label %bb_rcfailure772
bb_rcfailure772:
  %v2637 = load i64, ptr %slot43, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %call2639 = call i32 @myl_rc_take_failure(ptr %p2638) nomerge, !dbg !150
  store i32 %call2639, ptr %slot449, align 8
  %v2640 = load i64, ptr %slot1, align 8
  %p2641 = inttoptr i64 %v2640 to ptr
  %v2642 = load i32, ptr %slot449, align 8
  %call2643 = call i32 @myl_qbe_rc_status(ptr %p2641, i32 %v2642) nomerge, !dbg !150
  store i32 %call2643, ptr %slot450, align 8
  br label %bb_failure
bb_rcsuccess772:
  %v2644 = load i64, ptr %slot10, align 8
  %p2645 = inttoptr i64 %v2644 to ptr
  store i32 0, ptr %p2645, align 4, !alias.scope !3, !noalias !4
  %v2646 = load i64, ptr %slot13, align 8
  %p2647 = inttoptr i64 %v2646 to ptr
  store i32 2, ptr %p2647, align 4, !alias.scope !3, !noalias !4
  %v2648 = load i64, ptr %slot12, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  store i32 1, ptr %p2649, align 4, !alias.scope !3, !noalias !4
  %v2650 = load i64, ptr %slot17, align 8
  store i64 %v2650, ptr %slot451, align 8
  %v2651 = load i64, ptr %slot12, align 8
  %p2652 = inttoptr i64 %v2651 to ptr
  store i32 0, ptr %p2652, align 4, !alias.scope !3, !noalias !4
  %v2653 = load i64, ptr %slot10, align 8
  %p2654 = inttoptr i64 %v2653 to ptr
  %ld2655 = load i32, ptr %p2654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2655, ptr %slot452, align 8
  %v2656 = load i32, ptr %slot452, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcslotdrop782, label %bb_rcslotdone782
bb_rcslotdrop782:
  %v2659 = load i64, ptr %slot10, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  store i32 0, ptr %p2660, align 4, !alias.scope !3, !noalias !4
  %v2661 = load i64, ptr %slot15, align 8
  store i64 %v2661, ptr %slot453, align 8
  %v2662 = load i64, ptr %slot11, align 8
  %p2663 = inttoptr i64 %v2662 to ptr
  %ld2664 = load i32, ptr %p2663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2664, ptr %slot454, align 8
  %v2665 = load i32, ptr %slot454, align 8
  %op2666 = and i32 %v2665, 28
  store i32 %op2666, ptr %slot455, align 8
  %v2667 = load i32, ptr %slot455, align 8
  %cv2668 = zext i32 %v2667 to i64
  %cond2669 = icmp ne i64 %cv2668, 0
  br i1 %cond2669, label %bb_rcslotrole782, label %bb_rcslotowner782
bb_rcslotrole782:
  %v2670 = load i64, ptr %slot43, align 8
  store i64 %v2670, ptr %slot456, align 8
  %v2671 = load i64, ptr %slot456, align 8
  %v2672 = load i64, ptr %slot453, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v2671, i64 %v2672) nomerge, !dbg !150
  br label %bb_rcslotdone782
bb_rcslotowner782:
  %v2673 = load i64, ptr %slot43, align 8
  store i64 %v2673, ptr %slot457, align 8
  %v2674 = load i64, ptr %slot457, align 8
  %v2675 = load i64, ptr %slot453, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v2674, i64 %v2675) nomerge, !dbg !150
  br label %bb_rcslotdone782
bb_rcslotdone782:
  %v2676 = load i64, ptr %slot8, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  %ld2678 = load i32, ptr %p2677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2678, ptr %slot458, align 8
  %v2679 = load i32, ptr %slot458, align 8
  %cv2680 = zext i32 %v2679 to i64
  %cond2681 = icmp ne i64 %cv2680, 0
  br i1 %cond2681, label %bb_rcslotdrop809, label %bb_rcslotdone809
bb_rcslotdrop809:
  %v2682 = load i64, ptr %slot8, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  store i32 0, ptr %p2683, align 4, !alias.scope !3, !noalias !4
  %v2684 = load i64, ptr %slot23, align 8
  store i64 %v2684, ptr %slot459, align 8
  %v2685 = load i64, ptr %slot9, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %ld2687 = load i32, ptr %p2686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2687, ptr %slot460, align 8
  %v2688 = load i32, ptr %slot460, align 8
  %op2689 = and i32 %v2688, 28
  store i32 %op2689, ptr %slot461, align 8
  %v2690 = load i32, ptr %slot461, align 8
  %cv2691 = zext i32 %v2690 to i64
  %cond2692 = icmp ne i64 %cv2691, 0
  br i1 %cond2692, label %bb_rcslotrole809, label %bb_rcslotowner809
bb_rcslotrole809:
  %v2693 = load i64, ptr %slot43, align 8
  store i64 %v2693, ptr %slot462, align 8
  %v2694 = load i64, ptr %slot462, align 8
  %v2695 = load i64, ptr %slot459, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2694, i64 %v2695) nomerge, !dbg !150
  br label %bb_rcslotdone809
bb_rcslotowner809:
  %v2696 = load i64, ptr %slot43, align 8
  store i64 %v2696, ptr %slot463, align 8
  %v2697 = load i64, ptr %slot463, align 8
  %v2698 = load i64, ptr %slot459, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2697, i64 %v2698) nomerge, !dbg !150
  br label %bb_rcslotdone809
bb_rcslotdone809:
  %v2699 = load i64, ptr %slot6, align 8
  %p2700 = inttoptr i64 %v2699 to ptr
  %ld2701 = load i32, ptr %p2700, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2701, ptr %slot464, align 8
  %v2702 = load i32, ptr %slot464, align 8
  %cv2703 = zext i32 %v2702 to i64
  %cond2704 = icmp ne i64 %cv2703, 0
  br i1 %cond2704, label %bb_rcslotdrop836, label %bb_rcslotdone836
bb_rcslotdrop836:
  %v2705 = load i64, ptr %slot6, align 8
  %p2706 = inttoptr i64 %v2705 to ptr
  store i32 0, ptr %p2706, align 4, !alias.scope !3, !noalias !4
  %v2707 = load i64, ptr %slot21, align 8
  store i64 %v2707, ptr %slot465, align 8
  %v2708 = load i64, ptr %slot7, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  %ld2710 = load i32, ptr %p2709, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2710, ptr %slot466, align 8
  %v2711 = load i32, ptr %slot466, align 8
  %op2712 = and i32 %v2711, 28
  store i32 %op2712, ptr %slot467, align 8
  %v2713 = load i32, ptr %slot467, align 8
  %cv2714 = zext i32 %v2713 to i64
  %cond2715 = icmp ne i64 %cv2714, 0
  br i1 %cond2715, label %bb_rcslotrole836, label %bb_rcslotowner836
bb_rcslotrole836:
  %v2716 = load i64, ptr %slot43, align 8
  store i64 %v2716, ptr %slot468, align 8
  %v2717 = load i64, ptr %slot468, align 8
  %v2718 = load i64, ptr %slot465, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2717, i64 %v2718) nomerge, !dbg !150
  br label %bb_rcslotdone836
bb_rcslotowner836:
  %v2719 = load i64, ptr %slot43, align 8
  store i64 %v2719, ptr %slot469, align 8
  %v2720 = load i64, ptr %slot469, align 8
  %v2721 = load i64, ptr %slot465, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2720, i64 %v2721) nomerge, !dbg !150
  br label %bb_rcslotdone836
bb_rcslotdone836:
  %v2722 = load i64, ptr %slot451, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2723, i64 24, i1 false)
  ret void
bb_i93:
  %p2724 = inttoptr i64 ptrtoint (ptr @myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5 to i64) to ptr
  %ld2725 = load i64, ptr %p2724, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2725, ptr %slot470, align 8
  %v2726 = load i64, ptr %slot470, align 8
  %v2727 = load i64, ptr %slot26, align 8
  %p2728 = inttoptr i64 %v2727 to ptr
  store i64 %v2726, ptr %p2728, align 8, !alias.scope !3, !noalias !4
  %v2729 = load i64, ptr %slot26, align 8
  %p2730 = inttoptr i64 %v2729 to ptr
  %ld2731 = load i64, ptr %p2730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2731, ptr %slot471, align 8
  %v2732 = load i64, ptr %slot471, align 8
  %v2733 = load i64, ptr %slot16, align 8
  %p2734 = inttoptr i64 %v2733 to ptr
  store i64 %v2732, ptr %p2734, align 8, !alias.scope !3, !noalias !4
  %v2735 = load i64, ptr %slot16, align 8
  store i64 %v2735, ptr %slot472, align 8
  %v2736 = load i64, ptr %slot17, align 8
  store i64 %v2736, ptr %slot473, align 8
  %v2737 = load i64, ptr %slot472, align 8
  %v2738 = load i64, ptr %slot473, align 8
  %p2739 = inttoptr i64 %v2737 to ptr
  %p2740 = inttoptr i64 %v2738 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2740, ptr %p2739, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2741 = load i64, ptr %slot13, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  store i32 2, ptr %p2742, align 4, !alias.scope !3, !noalias !4
  %v2743 = load i64, ptr %slot12, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  store i32 1, ptr %p2744, align 4, !alias.scope !3, !noalias !4
  %v2745 = load i64, ptr %slot15, align 8
  store i64 %v2745, ptr %slot474, align 8
  %v2746 = load i64, ptr %slot17, align 8
  store i64 %v2746, ptr %slot475, align 8
  %v2747 = load i64, ptr %slot475, align 8
  %v2748 = load i64, ptr %slot474, align 8
  %p2749 = inttoptr i64 %v2747 to ptr
  %p2750 = inttoptr i64 %v2748 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2750, ptr %p2749, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2751 = load i64, ptr %slot11, align 8
  %p2752 = inttoptr i64 %v2751 to ptr
  store i32 2, ptr %p2752, align 4, !alias.scope !3, !noalias !4
  %v2753 = load i64, ptr %slot13, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  %ld2755 = load i32, ptr %p2754, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2755, ptr %slot476, align 8
  %v2756 = load i32, ptr %slot476, align 8
  %v2757 = load i64, ptr %slot11, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  store i32 %v2756, ptr %p2758, align 4, !alias.scope !3, !noalias !4
  %v2759 = load i64, ptr %slot12, align 8
  %p2760 = inttoptr i64 %v2759 to ptr
  store i32 0, ptr %p2760, align 4, !alias.scope !3, !noalias !4
  %v2761 = load i64, ptr %slot10, align 8
  %p2762 = inttoptr i64 %v2761 to ptr
  store i32 1, ptr %p2762, align 4, !alias.scope !3, !noalias !4
  %v2763 = load i64, ptr %slot474, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %ld2765 = load i64, ptr %p2764, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2765, ptr %slot477, align 8
  %v2766 = load i64, ptr %slot477, align 8
  %v2767 = load i64, ptr %slot26, align 8
  %p2768 = inttoptr i64 %v2767 to ptr
  store i64 %v2766, ptr %p2768, align 8, !alias.scope !3, !noalias !4
  %v2769 = load i64, ptr %slot19, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  %ld2771 = load i64, ptr %p2770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2771, ptr %slot478, align 8
  %v2772 = load i64, ptr %slot478, align 8
  %v2773 = load i64, ptr %slot27, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  store i64 %v2772, ptr %p2774, align 8, !alias.scope !3, !noalias !4
  %v2775 = load i64, ptr %slot27, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  %ld2777 = load i64, ptr %p2776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2777, ptr %slot479, align 8
  %v2778 = load i64, ptr %slot479, align 8
  %op2779 = add i64 %v2778, 0
  store i64 %op2779, ptr %slot480, align 8
  %v2780 = load i64, ptr %slot480, align 8
  %v2781 = load i64, ptr %slot27, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  store i64 %v2780, ptr %p2782, align 8, !alias.scope !3, !noalias !4
  %v2783 = load i64, ptr %slot27, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  %ld2785 = load i64, ptr %p2784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2785, ptr %slot481, align 8
  %v2786 = load i64, ptr %slot481, align 8
  %op2787 = add i64 %v2786, 24
  store i64 %op2787, ptr %slot482, align 8
  %v2788 = load i64, ptr %slot482, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  %ld2790 = load i64, ptr %p2789, align 8
  store i64 %ld2790, ptr %slot483, align 8
  %v2791 = load i64, ptr %slot483, align 8
  %v2792 = load i64, ptr %slot27, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  store i64 %v2791, ptr %p2793, align 8, !alias.scope !3, !noalias !4
  %v2794 = load i64, ptr %slot26, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %ld2796 = load i64, ptr %p2795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2796, ptr %slot484, align 8
  %v2797 = load i64, ptr %slot27, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %ld2799 = load i64, ptr %p2798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2799, ptr %slot485, align 8
  %v2800 = load i64, ptr %slot1, align 8
  %v2801 = load i64, ptr %slot484, align 8
  %v2802 = load i64, ptr %slot485, align 8
  %call2803 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v2800, i64 %v2801, i64 %v2802) nomerge, !dbg !152
  store { i64, i64 } %call2803, ptr %callresult487, align 8
  %addr2804 = ptrtoint ptr %callresult487 to i64
  store i64 %addr2804, ptr %slot486, align 8
  %v2805 = load i64, ptr %slot486, align 8
  %v2806 = load i64, ptr %slot26, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i64 %v2805, ptr %p2807, align 8, !alias.scope !3, !noalias !4
  %v2808 = load i64, ptr %slot26, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  %ld2810 = load i64, ptr %p2809, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2810, ptr %slot488, align 8
  %v2811 = load i64, ptr %slot17, align 8
  store i64 %v2811, ptr %slot489, align 8
  %v2812 = load i64, ptr %slot43, align 8
  %v2813 = load i64, ptr %slot489, align 8
  %v2814 = load i64, ptr %slot488, align 8
  %call2815 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v2812, i64 %v2813, i64 %v2814) nomerge, !dbg !152
  store i32 %call2815, ptr %slot490, align 8
  %v2816 = load i32, ptr %slot490, align 8
  %cv2817 = zext i32 %v2816 to i64
  %cond2818 = icmp ne i64 %cv2817, 0
  br i1 %cond2818, label %bb_rcsuccess907, label %bb_rcfailure907
bb_rcfailure907:
  %v2819 = load i64, ptr %slot43, align 8
  %p2820 = inttoptr i64 %v2819 to ptr
  %call2821 = call i32 @myl_rc_take_failure(ptr %p2820) nomerge, !dbg !152
  store i32 %call2821, ptr %slot491, align 8
  %v2822 = load i64, ptr %slot1, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  %v2824 = load i32, ptr %slot491, align 8
  %call2825 = call i32 @myl_qbe_rc_status(ptr %p2823, i32 %v2824) nomerge, !dbg !152
  store i32 %call2825, ptr %slot492, align 8
  br label %bb_failure
bb_rcsuccess907:
  %v2826 = load i64, ptr %slot13, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  store i32 2, ptr %p2827, align 4, !alias.scope !3, !noalias !4
  %v2828 = load i64, ptr %slot13, align 8
  %p2829 = inttoptr i64 %v2828 to ptr
  store i32 16, ptr %p2829, align 4, !alias.scope !3, !noalias !4
  %v2830 = load i64, ptr %slot12, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  store i32 1, ptr %p2831, align 4, !alias.scope !3, !noalias !4
  %v2832 = load i64, ptr %slot10, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  %ld2834 = load i32, ptr %p2833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2834, ptr %slot493, align 8
  %v2835 = load i32, ptr %slot493, align 8
  %cv2836 = zext i32 %v2835 to i64
  %cond2837 = icmp ne i64 %cv2836, 0
  br i1 %cond2837, label %bb_rcslotdrop915, label %bb_rcslotdone915
bb_rcslotdrop915:
  %v2838 = load i64, ptr %slot10, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  store i32 0, ptr %p2839, align 4, !alias.scope !3, !noalias !4
  %v2840 = load i64, ptr %slot15, align 8
  store i64 %v2840, ptr %slot494, align 8
  %v2841 = load i64, ptr %slot11, align 8
  %p2842 = inttoptr i64 %v2841 to ptr
  %ld2843 = load i32, ptr %p2842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2843, ptr %slot495, align 8
  %v2844 = load i32, ptr %slot495, align 8
  %op2845 = and i32 %v2844, 28
  store i32 %op2845, ptr %slot496, align 8
  %v2846 = load i32, ptr %slot496, align 8
  %cv2847 = zext i32 %v2846 to i64
  %cond2848 = icmp ne i64 %cv2847, 0
  br i1 %cond2848, label %bb_rcslotrole915, label %bb_rcslotowner915
bb_rcslotrole915:
  %v2849 = load i64, ptr %slot43, align 8
  store i64 %v2849, ptr %slot497, align 8
  %v2850 = load i64, ptr %slot494, align 8
  %p2851 = inttoptr i64 %v2850 to ptr
  %ld2852 = load i64, ptr %p2851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2852, ptr %slot498, align 8
  %v2853 = load i64, ptr %slot498, align 8
  %cmp2854 = icmp ne i64 %v2853, 0
  %cv2855 = zext i1 %cmp2854 to i32
  store i32 %cv2855, ptr %slot499, align 8
  %v2856 = load i32, ptr %slot499, align 8
  %cv2857 = zext i32 %v2856 to i64
  %cond2858 = icmp ne i64 %cv2857, 0
  br i1 %cond2858, label %bb_rcgnn931, label %bb_rcgdone931
bb_rcgnn931:
  %v2859 = load i64, ptr %slot498, align 8
  %op2860 = sub i64 %v2859, 16
  store i64 %op2860, ptr %slot500, align 8
  %v2861 = load i64, ptr %slot498, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  %rgep2863 = getelementptr i8, ptr %p2862, i64 -16
  %ld2864 = load i64, ptr %rgep2863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2864, ptr %slot501, align 8
  %v2865 = load i64, ptr %slot501, align 8
  %op2866 = and i64 %v2865, 4611686018427387906
  store i64 %op2866, ptr %slot502, align 8
  %v2867 = load i64, ptr %slot502, align 8
  %cmp2868 = icmp ne i64 %v2867, 0
  %cv2869 = zext i1 %cmp2868 to i32
  store i32 %cv2869, ptr %slot503, align 8
  %v2870 = load i32, ptr %slot503, align 8
  %cv2871 = zext i32 %v2870 to i64
  %cond2872 = icmp ne i64 %cv2871, 0
  br i1 %cond2872, label %bb_rcgclear931, label %bb_rcgcounted931
bb_rcgcounted931:
  %v2873 = load i64, ptr %slot498, align 8
  %op2874 = sub i64 %v2873, 24
  store i64 %op2874, ptr %slot504, align 8
  %v2875 = load i64, ptr %slot498, align 8
  %p2876 = inttoptr i64 %v2875 to ptr
  %rgep2877 = getelementptr i8, ptr %p2876, i64 -24
  %ld2878 = load i64, ptr %rgep2877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2878, ptr %slot505, align 8
  %v2879 = load i64, ptr %slot505, align 8
  %op2880 = sub i64 %v2879, 1
  store i64 %op2880, ptr %slot506, align 8
  %v2881 = load i64, ptr %slot506, align 8
  %cmp2882 = icmp eq i64 %v2881, 0
  %cv2883 = zext i1 %cmp2882 to i32
  store i32 %cv2883, ptr %slot507, align 8
  %v2884 = load i32, ptr %slot507, align 8
  %cv2885 = zext i32 %v2884 to i64
  %cond2886 = icmp ne i64 %cv2885, 0
  br i1 %cond2886, label %bb_rcglast931, label %bb_rcgdec931
bb_rcglast931:
  %v2887 = load i64, ptr %slot498, align 8
  %op2888 = sub i64 %v2887, 32
  store i64 %op2888, ptr %slot508, align 8
  %v2889 = load i64, ptr %slot498, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  %rgep2891 = getelementptr i8, ptr %p2890, i64 -32
  %ld2892 = load i64, ptr %rgep2891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2892, ptr %slot509, align 8
  %v2893 = load i64, ptr %slot509, align 8
  %cmp2894 = icmp ne i64 %v2893, 0
  %cv2895 = zext i1 %cmp2894 to i32
  store i32 %cv2895, ptr %slot510, align 8
  %v2896 = load i32, ptr %slot510, align 8
  %cv2897 = zext i32 %v2896 to i64
  %cond2898 = icmp ne i64 %cv2897, 0
  br i1 %cond2898, label %bb_rcgdec931, label %bb_rcgslow931
bb_rcgslow931:
  %v2899 = load i64, ptr %slot497, align 8
  %v2900 = load i64, ptr %slot494, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2899, i64 %v2900) nomerge, !dbg !152
  br label %bb_rcgdone931
bb_rcgdec931:
  %v2901 = load i64, ptr %slot506, align 8
  %v2902 = load i64, ptr %slot498, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  %rgep2904 = getelementptr i8, ptr %p2903, i64 -24
  store i64 %v2901, ptr %rgep2904, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear931
bb_rcgclear931:
  %v2905 = load i64, ptr %slot494, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  store i64 0, ptr %p2906, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone931
bb_rcgdone931:
  br label %bb_rcslotdone915
bb_rcslotowner915:
  %v2907 = load i64, ptr %slot43, align 8
  store i64 %v2907, ptr %slot511, align 8
  %v2908 = load i64, ptr %slot494, align 8
  %p2909 = inttoptr i64 %v2908 to ptr
  %ld2910 = load i64, ptr %p2909, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2910, ptr %slot512, align 8
  %v2911 = load i64, ptr %slot512, align 8
  %cmp2912 = icmp ne i64 %v2911, 0
  %cv2913 = zext i1 %cmp2912 to i32
  store i32 %cv2913, ptr %slot513, align 8
  %v2914 = load i32, ptr %slot513, align 8
  %cv2915 = zext i32 %v2914 to i64
  %cond2916 = icmp ne i64 %cv2915, 0
  br i1 %cond2916, label %bb_rcgnn946, label %bb_rcgdone946
bb_rcgnn946:
  %v2917 = load i64, ptr %slot512, align 8
  %op2918 = sub i64 %v2917, 16
  store i64 %op2918, ptr %slot514, align 8
  %v2919 = load i64, ptr %slot512, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  %rgep2921 = getelementptr i8, ptr %p2920, i64 -16
  %ld2922 = load i64, ptr %rgep2921, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2922, ptr %slot515, align 8
  %v2923 = load i64, ptr %slot515, align 8
  %op2924 = and i64 %v2923, 4611686018427387906
  store i64 %op2924, ptr %slot516, align 8
  %v2925 = load i64, ptr %slot516, align 8
  %cmp2926 = icmp ne i64 %v2925, 0
  %cv2927 = zext i1 %cmp2926 to i32
  store i32 %cv2927, ptr %slot517, align 8
  %v2928 = load i32, ptr %slot517, align 8
  %cv2929 = zext i32 %v2928 to i64
  %cond2930 = icmp ne i64 %cv2929, 0
  br i1 %cond2930, label %bb_rcgclear946, label %bb_rcgcounted946
bb_rcgcounted946:
  %v2931 = load i64, ptr %slot512, align 8
  %op2932 = sub i64 %v2931, 32
  store i64 %op2932, ptr %slot518, align 8
  %v2933 = load i64, ptr %slot512, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  %rgep2935 = getelementptr i8, ptr %p2934, i64 -32
  %ld2936 = load i64, ptr %rgep2935, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2936, ptr %slot519, align 8
  %v2937 = load i64, ptr %slot519, align 8
  %op2938 = sub i64 %v2937, 1
  store i64 %op2938, ptr %slot520, align 8
  %v2939 = load i64, ptr %slot520, align 8
  %cmp2940 = icmp eq i64 %v2939, 0
  %cv2941 = zext i1 %cmp2940 to i32
  store i32 %cv2941, ptr %slot521, align 8
  %v2942 = load i32, ptr %slot521, align 8
  %cv2943 = zext i32 %v2942 to i64
  %cond2944 = icmp ne i64 %cv2943, 0
  br i1 %cond2944, label %bb_rcglast946, label %bb_rcgdec946
bb_rcglast946:
  %v2945 = load i64, ptr %slot512, align 8
  %op2946 = sub i64 %v2945, 24
  store i64 %op2946, ptr %slot522, align 8
  %v2947 = load i64, ptr %slot512, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  %rgep2949 = getelementptr i8, ptr %p2948, i64 -24
  %ld2950 = load i64, ptr %rgep2949, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2950, ptr %slot523, align 8
  %v2951 = load i64, ptr %slot523, align 8
  %cmp2952 = icmp ne i64 %v2951, 0
  %cv2953 = zext i1 %cmp2952 to i32
  store i32 %cv2953, ptr %slot524, align 8
  %v2954 = load i32, ptr %slot524, align 8
  %cv2955 = zext i32 %v2954 to i64
  %cond2956 = icmp ne i64 %cv2955, 0
  br i1 %cond2956, label %bb_rcgdec946, label %bb_rcgslow946
bb_rcgslow946:
  %v2957 = load i64, ptr %slot511, align 8
  %v2958 = load i64, ptr %slot494, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2957, i64 %v2958) nomerge, !dbg !152
  br label %bb_rcgdone946
bb_rcgdec946:
  %v2959 = load i64, ptr %slot520, align 8
  %v2960 = load i64, ptr %slot512, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  %rgep2962 = getelementptr i8, ptr %p2961, i64 -32
  store i64 %v2959, ptr %rgep2962, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear946
bb_rcgclear946:
  %v2963 = load i64, ptr %slot494, align 8
  %p2964 = inttoptr i64 %v2963 to ptr
  store i64 0, ptr %p2964, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone946
bb_rcgdone946:
  br label %bb_rcslotdone915
bb_rcslotdone915:
  %v2965 = load i64, ptr %slot15, align 8
  store i64 %v2965, ptr %slot525, align 8
  %v2966 = load i64, ptr %slot17, align 8
  store i64 %v2966, ptr %slot526, align 8
  %v2967 = load i64, ptr %slot526, align 8
  %v2968 = load i64, ptr %slot525, align 8
  %p2969 = inttoptr i64 %v2967 to ptr
  %p2970 = inttoptr i64 %v2968 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2970, ptr %p2969, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v2971 = load i64, ptr %slot11, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  store i32 2, ptr %p2972, align 4, !alias.scope !3, !noalias !4
  %v2973 = load i64, ptr %slot13, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  %ld2975 = load i32, ptr %p2974, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2975, ptr %slot527, align 8
  %v2976 = load i32, ptr %slot527, align 8
  %v2977 = load i64, ptr %slot11, align 8
  %p2978 = inttoptr i64 %v2977 to ptr
  store i32 %v2976, ptr %p2978, align 4, !alias.scope !3, !noalias !4
  %v2979 = load i64, ptr %slot12, align 8
  %p2980 = inttoptr i64 %v2979 to ptr
  store i32 0, ptr %p2980, align 4, !alias.scope !3, !noalias !4
  %v2981 = load i64, ptr %slot10, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  store i32 1, ptr %p2982, align 4, !alias.scope !3, !noalias !4
  %v2983 = load i64, ptr %slot525, align 8
  %v2984 = load i64, ptr %slot26, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  store i64 %v2983, ptr %p2985, align 8, !alias.scope !3, !noalias !4
  %v2986 = load i64, ptr %slot37, align 8
  store i64 %v2986, ptr %slot528, align 8
  %v2987 = load i64, ptr %slot528, align 8
  %p2988 = inttoptr i64 %v2987 to ptr
  store i64 0, ptr %p2988, align 8, !alias.scope !3, !noalias !4
  %v2989 = load i64, ptr %slot528, align 8
  %p2991 = inttoptr i64 %v2989 to ptr
  %gep2992 = getelementptr i8, ptr %p2991, i64 8
  %op2990 = ptrtoint ptr %gep2992 to i64
  store i64 %op2990, ptr %slot529, align 8
  %v2993 = load i64, ptr %slot529, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  store i64 0, ptr %p2994, align 8, !alias.scope !3, !noalias !4
  %v2995 = load i64, ptr %slot528, align 8
  %p2997 = inttoptr i64 %v2995 to ptr
  %gep2998 = getelementptr i8, ptr %p2997, i64 16
  %op2996 = ptrtoint ptr %gep2998 to i64
  store i64 %op2996, ptr %slot530, align 8
  %v2999 = load i64, ptr %slot530, align 8
  %p3000 = inttoptr i64 %v2999 to ptr
  store i64 0, ptr %p3000, align 8, !alias.scope !3, !noalias !4
  %v3001 = load i64, ptr %slot528, align 8
  %p3002 = inttoptr i64 %v3001 to ptr
  store i32 1, ptr %p3002, align 4, !alias.scope !3, !noalias !4
  %v3003 = load i64, ptr %slot14, align 8
  %p3004 = inttoptr i64 %v3003 to ptr
  store i32 1, ptr %p3004, align 4, !alias.scope !3, !noalias !4
  %v3005 = load i64, ptr %slot26, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  %ld3007 = load i64, ptr %p3006, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3007, ptr %slot531, align 8
  %v3008 = load i64, ptr %slot528, align 8
  %p3010 = inttoptr i64 %v3008 to ptr
  %gep3011 = getelementptr i8, ptr %p3010, i64 8
  %op3009 = ptrtoint ptr %gep3011 to i64
  store i64 %op3009, ptr %slot532, align 8
  %v3012 = load i64, ptr %slot44, align 8
  store i64 %v3012, ptr %slot533, align 8
  %v3013 = load i64, ptr %slot26, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  %ld3015 = load i64, ptr %p3014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3015, ptr %slot534, align 8
  %v3016 = load i64, ptr %slot10, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  %ld3018 = load i32, ptr %p3017, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3018, ptr %slot535, align 8
  %v3019 = load i64, ptr %slot11, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %ld3021 = load i32, ptr %p3020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3021, ptr %slot536, align 8
  %v3022 = load i32, ptr %slot536, align 8
  %op3023 = and i32 %v3022, 24
  store i32 %op3023, ptr %slot536, align 8
  %v3024 = load i32, ptr %slot536, align 8
  %cmp3025 = icmp eq i32 %v3024, 0
  %cv3026 = zext i1 %cmp3025 to i32
  store i32 %cv3026, ptr %slot537, align 8
  %v3027 = load i32, ptr %slot535, align 8
  %v3028 = load i32, ptr %slot537, align 8
  %op3029 = and i32 %v3027, %v3028
  store i32 %op3029, ptr %slot538, align 8
  %v3030 = load i32, ptr %slot538, align 8
  %cv3031 = zext i32 %v3030 to i64
  %cond3032 = icmp ne i64 %cv3031, 0
  br i1 %cond3032, label %bb_rctake967, label %bb_rccopy967
bb_rctake967:
  %v3033 = load i64, ptr %slot17, align 8
  store i64 %v3033, ptr %slot539, align 8
  %v3034 = load i64, ptr %slot44, align 8
  store i64 %v3034, ptr %slot540, align 8
  %v3035 = load i64, ptr %slot534, align 8
  %v3036 = load i64, ptr %slot539, align 8
  %op3037 = sub i64 %v3035, %v3036
  store i64 %op3037, ptr %slot541, align 8
  %v3038 = load i64, ptr %slot539, align 8
  %v3039 = load i64, ptr %slot534, align 8
  %op3040 = sub i64 %v3038, %v3039
  store i64 %op3040, ptr %slot542, align 8
  %v3041 = load i64, ptr %slot541, align 8
  %cmp3042 = icmp ult i64 %v3041, 16
  %cv3043 = zext i1 %cmp3042 to i32
  store i32 %cv3043, ptr %slot543, align 8
  %v3044 = load i64, ptr %slot542, align 8
  %cmp3045 = icmp ult i64 %v3044, 16
  %cv3046 = zext i1 %cmp3045 to i32
  store i32 %cv3046, ptr %slot544, align 8
  %v3047 = load i32, ptr %slot543, align 8
  %v3048 = load i32, ptr %slot544, align 8
  %op3049 = or i32 %v3047, %v3048
  store i32 %op3049, ptr %slot545, align 8
  %v3050 = load i32, ptr %slot545, align 8
  %cv3051 = zext i32 %v3050 to i64
  %cond3052 = icmp ne i64 %cv3051, 0
  br i1 %cond3052, label %bb_rcmoveslow976, label %bb_rcmovecheck976
bb_rcmovecheck976:
  %v3053 = load i64, ptr %slot534, align 8
  %op3054 = add i64 %v3053, 0
  store i64 %op3054, ptr %slot546, align 8
  %v3055 = load i64, ptr %slot546, align 8
  %p3056 = inttoptr i64 %v3055 to ptr
  %ld3057 = load i64, ptr %p3056, align 8
  store i64 %ld3057, ptr %slot547, align 8
  %v3058 = load i64, ptr %slot547, align 8
  %cmp3059 = icmp ne i64 %v3058, 0
  %cv3060 = zext i1 %cmp3059 to i32
  store i32 %cv3060, ptr %slot548, align 8
  %v3061 = load i32, ptr %slot548, align 8
  %cv3062 = zext i32 %v3061 to i64
  %cond3063 = icmp ne i64 %cv3062, 0
  br i1 %cond3063, label %bb_rcmoveheader984, label %bb_rcmovenext984
bb_rcmoveheader984:
  %v3064 = load i64, ptr %slot547, align 8
  %op3065 = sub i64 %v3064, 16
  store i64 %op3065, ptr %slot549, align 8
  %v3066 = load i64, ptr %slot547, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  %rgep3068 = getelementptr i8, ptr %p3067, i64 -16
  %ld3069 = load i64, ptr %rgep3068, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3069, ptr %slot550, align 8
  %v3070 = load i64, ptr %slot550, align 8
  %op3071 = and i64 %v3070, 5764607523034234881
  store i64 %op3071, ptr %slot551, align 8
  %v3072 = load i64, ptr %slot551, align 8
  %cmp3073 = icmp ne i64 %v3072, 0
  %cv3074 = zext i1 %cmp3073 to i32
  store i32 %cv3074, ptr %slot552, align 8
  %v3075 = load i32, ptr %slot552, align 8
  %cv3076 = zext i32 %v3075 to i64
  %cond3077 = icmp ne i64 %cv3076, 0
  br i1 %cond3077, label %bb_rcmoveslow976, label %bb_rcmovenext984
bb_rcmovenext984:
  %v3078 = load i64, ptr %slot534, align 8
  %v3079 = load i64, ptr %slot539, align 8
  %p3080 = inttoptr i64 %v3078 to ptr
  %p3081 = inttoptr i64 %v3079 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3081, ptr %p3080, i64 16, i1 false)
  %v3082 = load i64, ptr %slot534, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  store i64 0, ptr %p3083, align 8
  %v3084 = load i64, ptr %slot534, align 8
  %op3085 = add i64 %v3084, 8
  store i64 %op3085, ptr %slot553, align 8
  %v3086 = load i64, ptr %slot553, align 8
  %p3087 = inttoptr i64 %v3086 to ptr
  store i64 0, ptr %p3087, align 8
  br label %bb_rcmoved976
bb_rcmoveslow976:
  %v3088 = load i64, ptr %slot43, align 8
  %v3089 = load i64, ptr %slot539, align 8
  %v3090 = load i64, ptr %slot534, align 8
  %v3091 = load i64, ptr %slot540, align 8
  %cv3092 = trunc i64 %v3091 to i32
  %call3093 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v3088, i64 %v3089, i64 %v3090, i32 %cv3092) nomerge, !dbg !154
  store i32 %call3093, ptr %slot554, align 8
  %v3094 = load i32, ptr %slot554, align 8
  %cv3095 = zext i32 %v3094 to i64
  %cond3096 = icmp ne i64 %cv3095, 0
  br i1 %cond3096, label %bb_rcsuccess992, label %bb_rcfailure992
bb_rcfailure992:
  %v3097 = load i64, ptr %slot43, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  %call3099 = call i32 @myl_rc_take_failure(ptr %p3098) nomerge, !dbg !154
  store i32 %call3099, ptr %slot555, align 8
  %v3100 = load i64, ptr %slot1, align 8
  %p3101 = inttoptr i64 %v3100 to ptr
  %v3102 = load i32, ptr %slot555, align 8
  %call3103 = call i32 @myl_qbe_rc_status(ptr %p3101, i32 %v3102) nomerge, !dbg !154
  store i32 %call3103, ptr %slot556, align 8
  br label %bb_failure
bb_rcsuccess992:
  br label %bb_rcmoved976
bb_rcmoved976:
  %v3104 = load i64, ptr %slot10, align 8
  %p3105 = inttoptr i64 %v3104 to ptr
  store i32 0, ptr %p3105, align 4, !alias.scope !3, !noalias !4
  %v3106 = load i64, ptr %slot13, align 8
  %p3107 = inttoptr i64 %v3106 to ptr
  store i32 2, ptr %p3107, align 4, !alias.scope !3, !noalias !4
  %v3108 = load i64, ptr %slot12, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  store i32 1, ptr %p3109, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared967
bb_rccopy967:
  %v3110 = load i64, ptr %slot17, align 8
  store i64 %v3110, ptr %slot557, align 8
  %v3111 = load i64, ptr %slot44, align 8
  store i64 %v3111, ptr %slot558, align 8
  %v3112 = load i64, ptr %slot43, align 8
  %v3113 = load i64, ptr %slot557, align 8
  %v3114 = load i64, ptr %slot534, align 8
  %v3115 = load i64, ptr %slot558, align 8
  %cv3116 = trunc i64 %v3115 to i32
  %call3117 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v3112, i64 %v3113, i64 %v3114, i32 %cv3116) nomerge, !dbg !154
  store i32 %call3117, ptr %slot559, align 8
  %v3118 = load i32, ptr %slot559, align 8
  %cv3119 = zext i32 %v3118 to i64
  %cond3120 = icmp ne i64 %cv3119, 0
  br i1 %cond3120, label %bb_rcsuccess1001, label %bb_rcfailure1001
bb_rcfailure1001:
  %v3121 = load i64, ptr %slot43, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  %call3123 = call i32 @myl_rc_take_failure(ptr %p3122) nomerge, !dbg !154
  store i32 %call3123, ptr %slot560, align 8
  %v3124 = load i64, ptr %slot1, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  %v3126 = load i32, ptr %slot560, align 8
  %call3127 = call i32 @myl_qbe_rc_status(ptr %p3125, i32 %v3126) nomerge, !dbg !154
  store i32 %call3127, ptr %slot561, align 8
  br label %bb_failure
bb_rcsuccess1001:
  %v3128 = load i64, ptr %slot13, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  store i32 2, ptr %p3129, align 4, !alias.scope !3, !noalias !4
  %v3130 = load i64, ptr %slot12, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  store i32 1, ptr %p3131, align 4, !alias.scope !3, !noalias !4
  %v3132 = load i64, ptr %slot10, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  %ld3134 = load i32, ptr %p3133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3134, ptr %slot562, align 8
  %v3135 = load i32, ptr %slot562, align 8
  %cv3136 = zext i32 %v3135 to i64
  %cond3137 = icmp ne i64 %cv3136, 0
  br i1 %cond3137, label %bb_rcslotdrop1008, label %bb_rcslotdone1008
bb_rcslotdrop1008:
  %v3138 = load i64, ptr %slot10, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  store i32 0, ptr %p3139, align 4, !alias.scope !3, !noalias !4
  %v3140 = load i64, ptr %slot15, align 8
  store i64 %v3140, ptr %slot563, align 8
  %v3141 = load i64, ptr %slot11, align 8
  %p3142 = inttoptr i64 %v3141 to ptr
  %ld3143 = load i32, ptr %p3142, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3143, ptr %slot564, align 8
  %v3144 = load i32, ptr %slot564, align 8
  %op3145 = and i32 %v3144, 28
  store i32 %op3145, ptr %slot565, align 8
  %v3146 = load i32, ptr %slot565, align 8
  %cv3147 = zext i32 %v3146 to i64
  %cond3148 = icmp ne i64 %cv3147, 0
  br i1 %cond3148, label %bb_rcslotrole1008, label %bb_rcslotowner1008
bb_rcslotrole1008:
  %v3149 = load i64, ptr %slot43, align 8
  store i64 %v3149, ptr %slot566, align 8
  %v3150 = load i64, ptr %slot566, align 8
  %v3151 = load i64, ptr %slot563, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v3150, i64 %v3151) nomerge, !dbg !154
  br label %bb_rcslotdone1008
bb_rcslotowner1008:
  %v3152 = load i64, ptr %slot43, align 8
  store i64 %v3152, ptr %slot567, align 8
  %v3153 = load i64, ptr %slot567, align 8
  %v3154 = load i64, ptr %slot563, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v3153, i64 %v3154) nomerge, !dbg !154
  br label %bb_rcslotdone1008
bb_rcslotdone1008:
  br label %bb_rcprepared967
bb_rcprepared967:
  %v3155 = load i64, ptr %slot17, align 8
  store i64 %v3155, ptr %slot568, align 8
  %v3156 = load i64, ptr %slot568, align 8
  %v3157 = load i64, ptr %slot532, align 8
  %p3158 = inttoptr i64 %v3156 to ptr
  %p3159 = inttoptr i64 %v3157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3159, ptr %p3158, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3160 = load i64, ptr %slot12, align 8
  %p3161 = inttoptr i64 %v3160 to ptr
  store i32 0, ptr %p3161, align 4, !alias.scope !3, !noalias !4
  %v3162 = load i64, ptr %slot528, align 8
  %v3163 = load i64, ptr %slot26, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  store i64 %v3162, ptr %p3164, align 8, !alias.scope !3, !noalias !4
  %p3165 = inttoptr i64 ptrtoint (ptr @myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p3165, i64 98) "call-inline-cost"="0", !dbg !154
  %v3166 = load i64, ptr %slot26, align 8
  %p3167 = inttoptr i64 %v3166 to ptr
  %ld3168 = load i64, ptr %p3167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3168, ptr %slot569, align 8
  %v3169 = load i64, ptr %slot15, align 8
  store i64 %v3169, ptr %slot570, align 8
  %v3170 = load i64, ptr %slot569, align 8
  %v3171 = load i64, ptr %slot570, align 8
  %p3172 = inttoptr i64 %v3170 to ptr
  %p3173 = inttoptr i64 %v3171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3173, ptr %p3172, i64 24, i1 false)
  %v3174 = load i64, ptr %slot11, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  store i32 2, ptr %p3175, align 4, !alias.scope !3, !noalias !4
  %v3176 = load i64, ptr %slot10, align 8
  %p3177 = inttoptr i64 %v3176 to ptr
  store i32 1, ptr %p3177, align 4, !alias.scope !3, !noalias !4
  %v3178 = load i64, ptr %slot570, align 8
  %v3179 = load i64, ptr %slot26, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  store i64 %v3178, ptr %p3180, align 8, !alias.scope !3, !noalias !4
  %v3181 = load i64, ptr %slot26, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  %ld3183 = load i64, ptr %p3182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3183, ptr %slot571, align 8
  %v3184 = load i64, ptr %slot26, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  %ld3186 = load i64, ptr %p3185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3186, ptr %slot572, align 8
  %v3187 = load i64, ptr %slot17, align 8
  store i64 %v3187, ptr %slot573, align 8
  %v3188 = load i64, ptr %slot44, align 8
  store i64 %v3188, ptr %slot574, align 8
  %v3189 = load i64, ptr %slot43, align 8
  %v3190 = load i64, ptr %slot573, align 8
  %v3191 = load i64, ptr %slot572, align 8
  %v3192 = load i64, ptr %slot574, align 8
  %cv3193 = trunc i64 %v3192 to i32
  %call3194 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v3189, i64 %v3190, i64 %v3191, i32 %cv3193) nomerge, !dbg !156
  store i32 %call3194, ptr %slot575, align 8
  %v3195 = load i32, ptr %slot575, align 8
  %cv3196 = zext i32 %v3195 to i64
  %cond3197 = icmp ne i64 %cv3196, 0
  br i1 %cond3197, label %bb_rcsuccess1026, label %bb_rcfailure1026
bb_rcfailure1026:
  %v3198 = load i64, ptr %slot43, align 8
  %p3199 = inttoptr i64 %v3198 to ptr
  %call3200 = call i32 @myl_rc_take_failure(ptr %p3199) nomerge, !dbg !156
  store i32 %call3200, ptr %slot576, align 8
  %v3201 = load i64, ptr %slot1, align 8
  %p3202 = inttoptr i64 %v3201 to ptr
  %v3203 = load i32, ptr %slot576, align 8
  %call3204 = call i32 @myl_qbe_rc_status(ptr %p3202, i32 %v3203) nomerge, !dbg !156
  store i32 %call3204, ptr %slot577, align 8
  br label %bb_failure
bb_rcsuccess1026:
  %v3205 = load i64, ptr %slot10, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  store i32 0, ptr %p3206, align 4, !alias.scope !3, !noalias !4
  %v3207 = load i64, ptr %slot13, align 8
  %p3208 = inttoptr i64 %v3207 to ptr
  store i32 2, ptr %p3208, align 4, !alias.scope !3, !noalias !4
  %v3209 = load i64, ptr %slot12, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  store i32 1, ptr %p3210, align 4, !alias.scope !3, !noalias !4
  %v3211 = load i64, ptr %slot17, align 8
  store i64 %v3211, ptr %slot578, align 8
  %v3212 = load i64, ptr %slot12, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  store i32 0, ptr %p3213, align 4, !alias.scope !3, !noalias !4
  %v3214 = load i64, ptr %slot10, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  %ld3216 = load i32, ptr %p3215, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3216, ptr %slot579, align 8
  %v3217 = load i32, ptr %slot579, align 8
  %cv3218 = zext i32 %v3217 to i64
  %cond3219 = icmp ne i64 %cv3218, 0
  br i1 %cond3219, label %bb_rcslotdrop1036, label %bb_rcslotdone1036
bb_rcslotdrop1036:
  %v3220 = load i64, ptr %slot10, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  store i32 0, ptr %p3221, align 4, !alias.scope !3, !noalias !4
  %v3222 = load i64, ptr %slot15, align 8
  store i64 %v3222, ptr %slot580, align 8
  %v3223 = load i64, ptr %slot11, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %ld3225 = load i32, ptr %p3224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3225, ptr %slot581, align 8
  %v3226 = load i32, ptr %slot581, align 8
  %op3227 = and i32 %v3226, 28
  store i32 %op3227, ptr %slot582, align 8
  %v3228 = load i32, ptr %slot582, align 8
  %cv3229 = zext i32 %v3228 to i64
  %cond3230 = icmp ne i64 %cv3229, 0
  br i1 %cond3230, label %bb_rcslotrole1036, label %bb_rcslotowner1036
bb_rcslotrole1036:
  %v3231 = load i64, ptr %slot43, align 8
  store i64 %v3231, ptr %slot583, align 8
  %v3232 = load i64, ptr %slot583, align 8
  %v3233 = load i64, ptr %slot580, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v3232, i64 %v3233) nomerge, !dbg !156
  br label %bb_rcslotdone1036
bb_rcslotowner1036:
  %v3234 = load i64, ptr %slot43, align 8
  store i64 %v3234, ptr %slot584, align 8
  %v3235 = load i64, ptr %slot584, align 8
  %v3236 = load i64, ptr %slot580, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3235, i64 %v3236) nomerge, !dbg !156
  br label %bb_rcslotdone1036
bb_rcslotdone1036:
  %v3237 = load i64, ptr %slot8, align 8
  %p3238 = inttoptr i64 %v3237 to ptr
  %ld3239 = load i32, ptr %p3238, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3239, ptr %slot585, align 8
  %v3240 = load i32, ptr %slot585, align 8
  %cv3241 = zext i32 %v3240 to i64
  %cond3242 = icmp ne i64 %cv3241, 0
  br i1 %cond3242, label %bb_rcslotdrop1063, label %bb_rcslotdone1063
bb_rcslotdrop1063:
  %v3243 = load i64, ptr %slot8, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  store i32 0, ptr %p3244, align 4, !alias.scope !3, !noalias !4
  %v3245 = load i64, ptr %slot23, align 8
  store i64 %v3245, ptr %slot586, align 8
  %v3246 = load i64, ptr %slot9, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  %ld3248 = load i32, ptr %p3247, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3248, ptr %slot587, align 8
  %v3249 = load i32, ptr %slot587, align 8
  %op3250 = and i32 %v3249, 28
  store i32 %op3250, ptr %slot588, align 8
  %v3251 = load i32, ptr %slot588, align 8
  %cv3252 = zext i32 %v3251 to i64
  %cond3253 = icmp ne i64 %cv3252, 0
  br i1 %cond3253, label %bb_rcslotrole1063, label %bb_rcslotowner1063
bb_rcslotrole1063:
  %v3254 = load i64, ptr %slot43, align 8
  store i64 %v3254, ptr %slot589, align 8
  %v3255 = load i64, ptr %slot589, align 8
  %v3256 = load i64, ptr %slot586, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3255, i64 %v3256) nomerge, !dbg !156
  br label %bb_rcslotdone1063
bb_rcslotowner1063:
  %v3257 = load i64, ptr %slot43, align 8
  store i64 %v3257, ptr %slot590, align 8
  %v3258 = load i64, ptr %slot590, align 8
  %v3259 = load i64, ptr %slot586, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3258, i64 %v3259) nomerge, !dbg !156
  br label %bb_rcslotdone1063
bb_rcslotdone1063:
  %v3260 = load i64, ptr %slot6, align 8
  %p3261 = inttoptr i64 %v3260 to ptr
  %ld3262 = load i32, ptr %p3261, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3262, ptr %slot591, align 8
  %v3263 = load i32, ptr %slot591, align 8
  %cv3264 = zext i32 %v3263 to i64
  %cond3265 = icmp ne i64 %cv3264, 0
  br i1 %cond3265, label %bb_rcslotdrop1090, label %bb_rcslotdone1090
bb_rcslotdrop1090:
  %v3266 = load i64, ptr %slot6, align 8
  %p3267 = inttoptr i64 %v3266 to ptr
  store i32 0, ptr %p3267, align 4, !alias.scope !3, !noalias !4
  %v3268 = load i64, ptr %slot21, align 8
  store i64 %v3268, ptr %slot592, align 8
  %v3269 = load i64, ptr %slot7, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  %ld3271 = load i32, ptr %p3270, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3271, ptr %slot593, align 8
  %v3272 = load i32, ptr %slot593, align 8
  %op3273 = and i32 %v3272, 28
  store i32 %op3273, ptr %slot594, align 8
  %v3274 = load i32, ptr %slot594, align 8
  %cv3275 = zext i32 %v3274 to i64
  %cond3276 = icmp ne i64 %cv3275, 0
  br i1 %cond3276, label %bb_rcslotrole1090, label %bb_rcslotowner1090
bb_rcslotrole1090:
  %v3277 = load i64, ptr %slot43, align 8
  store i64 %v3277, ptr %slot595, align 8
  %v3278 = load i64, ptr %slot595, align 8
  %v3279 = load i64, ptr %slot592, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3278, i64 %v3279) nomerge, !dbg !156
  br label %bb_rcslotdone1090
bb_rcslotowner1090:
  %v3280 = load i64, ptr %slot43, align 8
  store i64 %v3280, ptr %slot596, align 8
  %v3281 = load i64, ptr %slot596, align 8
  %v3282 = load i64, ptr %slot592, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3281, i64 %v3282) nomerge, !dbg !156
  br label %bb_rcslotdone1090
bb_rcslotdone1090:
  %v3283 = load i64, ptr %slot578, align 8
  %p3284 = inttoptr i64 %v3283 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3284, i64 24, i1 false)
  ret void
bb_i100:
  %p3285 = inttoptr i64 ptrtoint (ptr @myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5 to i64) to ptr
  %ld3286 = load i64, ptr %p3285, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3286, ptr %slot597, align 8
  %v3287 = load i64, ptr %slot597, align 8
  %v3288 = load i64, ptr %slot26, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i64 %v3287, ptr %p3289, align 8, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot26, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  %ld3292 = load i64, ptr %p3291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3292, ptr %slot598, align 8
  %v3293 = load i64, ptr %slot598, align 8
  %v3294 = load i64, ptr %slot16, align 8
  %p3295 = inttoptr i64 %v3294 to ptr
  store i64 %v3293, ptr %p3295, align 8, !alias.scope !3, !noalias !4
  %v3296 = load i64, ptr %slot16, align 8
  store i64 %v3296, ptr %slot599, align 8
  %v3297 = load i64, ptr %slot17, align 8
  store i64 %v3297, ptr %slot600, align 8
  %v3298 = load i64, ptr %slot599, align 8
  %v3299 = load i64, ptr %slot600, align 8
  %p3300 = inttoptr i64 %v3298 to ptr
  %p3301 = inttoptr i64 %v3299 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3301, ptr %p3300, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3302 = load i64, ptr %slot13, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  store i32 2, ptr %p3303, align 4, !alias.scope !3, !noalias !4
  %v3304 = load i64, ptr %slot12, align 8
  %p3305 = inttoptr i64 %v3304 to ptr
  store i32 1, ptr %p3305, align 4, !alias.scope !3, !noalias !4
  %v3306 = load i64, ptr %slot15, align 8
  store i64 %v3306, ptr %slot601, align 8
  %v3307 = load i64, ptr %slot17, align 8
  store i64 %v3307, ptr %slot602, align 8
  %v3308 = load i64, ptr %slot602, align 8
  %v3309 = load i64, ptr %slot601, align 8
  %p3310 = inttoptr i64 %v3308 to ptr
  %p3311 = inttoptr i64 %v3309 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3311, ptr %p3310, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3312 = load i64, ptr %slot11, align 8
  %p3313 = inttoptr i64 %v3312 to ptr
  store i32 2, ptr %p3313, align 4, !alias.scope !3, !noalias !4
  %v3314 = load i64, ptr %slot13, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  %ld3316 = load i32, ptr %p3315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3316, ptr %slot603, align 8
  %v3317 = load i32, ptr %slot603, align 8
  %v3318 = load i64, ptr %slot11, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  store i32 %v3317, ptr %p3319, align 4, !alias.scope !3, !noalias !4
  %v3320 = load i64, ptr %slot12, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  store i32 0, ptr %p3321, align 4, !alias.scope !3, !noalias !4
  %v3322 = load i64, ptr %slot10, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  store i32 1, ptr %p3323, align 4, !alias.scope !3, !noalias !4
  %v3324 = load i64, ptr %slot601, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %ld3326 = load i64, ptr %p3325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3326, ptr %slot604, align 8
  %v3327 = load i64, ptr %slot604, align 8
  %v3328 = load i64, ptr %slot26, align 8
  %p3329 = inttoptr i64 %v3328 to ptr
  store i64 %v3327, ptr %p3329, align 8, !alias.scope !3, !noalias !4
  %v3330 = load i64, ptr %slot19, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  %ld3332 = load i64, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3332, ptr %slot605, align 8
  %v3333 = load i64, ptr %slot605, align 8
  %v3334 = load i64, ptr %slot27, align 8
  %p3335 = inttoptr i64 %v3334 to ptr
  store i64 %v3333, ptr %p3335, align 8, !alias.scope !3, !noalias !4
  %v3336 = load i64, ptr %slot27, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  %ld3338 = load i64, ptr %p3337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3338, ptr %slot606, align 8
  %v3339 = load i64, ptr %slot606, align 8
  %op3340 = add i64 %v3339, 0
  store i64 %op3340, ptr %slot607, align 8
  %v3341 = load i64, ptr %slot607, align 8
  %v3342 = load i64, ptr %slot27, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  store i64 %v3341, ptr %p3343, align 8, !alias.scope !3, !noalias !4
  %v3344 = load i64, ptr %slot27, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  %ld3346 = load i64, ptr %p3345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3346, ptr %slot608, align 8
  %v3347 = load i64, ptr %slot608, align 8
  %op3348 = add i64 %v3347, 24
  store i64 %op3348, ptr %slot609, align 8
  %v3349 = load i64, ptr %slot609, align 8
  %p3350 = inttoptr i64 %v3349 to ptr
  %ld3351 = load i64, ptr %p3350, align 8
  store i64 %ld3351, ptr %slot610, align 8
  %v3352 = load i64, ptr %slot610, align 8
  %v3353 = load i64, ptr %slot27, align 8
  %p3354 = inttoptr i64 %v3353 to ptr
  store i64 %v3352, ptr %p3354, align 8, !alias.scope !3, !noalias !4
  %v3355 = load i64, ptr %slot26, align 8
  %p3356 = inttoptr i64 %v3355 to ptr
  %ld3357 = load i64, ptr %p3356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3357, ptr %slot611, align 8
  %v3358 = load i64, ptr %slot27, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  %ld3360 = load i64, ptr %p3359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3360, ptr %slot612, align 8
  %v3361 = load i64, ptr %slot1, align 8
  %v3362 = load i64, ptr %slot611, align 8
  %v3363 = load i64, ptr %slot612, align 8
  %call3364 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v3361, i64 %v3362, i64 %v3363) nomerge, !dbg !158
  store { i64, i64 } %call3364, ptr %callresult614, align 8
  %addr3365 = ptrtoint ptr %callresult614 to i64
  store i64 %addr3365, ptr %slot613, align 8
  %v3366 = load i64, ptr %slot613, align 8
  %v3367 = load i64, ptr %slot26, align 8
  %p3368 = inttoptr i64 %v3367 to ptr
  store i64 %v3366, ptr %p3368, align 8, !alias.scope !3, !noalias !4
  %v3369 = load i64, ptr %slot26, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %ld3371 = load i64, ptr %p3370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3371, ptr %slot615, align 8
  %v3372 = load i64, ptr %slot17, align 8
  store i64 %v3372, ptr %slot616, align 8
  %v3373 = load i64, ptr %slot43, align 8
  %v3374 = load i64, ptr %slot616, align 8
  %v3375 = load i64, ptr %slot615, align 8
  %call3376 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v3373, i64 %v3374, i64 %v3375) nomerge, !dbg !158
  store i32 %call3376, ptr %slot617, align 8
  %v3377 = load i32, ptr %slot617, align 8
  %cv3378 = zext i32 %v3377 to i64
  %cond3379 = icmp ne i64 %cv3378, 0
  br i1 %cond3379, label %bb_rcsuccess1161, label %bb_rcfailure1161
bb_rcfailure1161:
  %v3380 = load i64, ptr %slot43, align 8
  %p3381 = inttoptr i64 %v3380 to ptr
  %call3382 = call i32 @myl_rc_take_failure(ptr %p3381) nomerge, !dbg !158
  store i32 %call3382, ptr %slot618, align 8
  %v3383 = load i64, ptr %slot1, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %v3385 = load i32, ptr %slot618, align 8
  %call3386 = call i32 @myl_qbe_rc_status(ptr %p3384, i32 %v3385) nomerge, !dbg !158
  store i32 %call3386, ptr %slot619, align 8
  br label %bb_failure
bb_rcsuccess1161:
  %v3387 = load i64, ptr %slot13, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  store i32 2, ptr %p3388, align 4, !alias.scope !3, !noalias !4
  %v3389 = load i64, ptr %slot13, align 8
  %p3390 = inttoptr i64 %v3389 to ptr
  store i32 16, ptr %p3390, align 4, !alias.scope !3, !noalias !4
  %v3391 = load i64, ptr %slot12, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  store i32 1, ptr %p3392, align 4, !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot10, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  %ld3395 = load i32, ptr %p3394, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3395, ptr %slot620, align 8
  %v3396 = load i32, ptr %slot620, align 8
  %cv3397 = zext i32 %v3396 to i64
  %cond3398 = icmp ne i64 %cv3397, 0
  br i1 %cond3398, label %bb_rcslotdrop1169, label %bb_rcslotdone1169
bb_rcslotdrop1169:
  %v3399 = load i64, ptr %slot10, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  store i32 0, ptr %p3400, align 4, !alias.scope !3, !noalias !4
  %v3401 = load i64, ptr %slot15, align 8
  store i64 %v3401, ptr %slot621, align 8
  %v3402 = load i64, ptr %slot11, align 8
  %p3403 = inttoptr i64 %v3402 to ptr
  %ld3404 = load i32, ptr %p3403, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3404, ptr %slot622, align 8
  %v3405 = load i32, ptr %slot622, align 8
  %op3406 = and i32 %v3405, 28
  store i32 %op3406, ptr %slot623, align 8
  %v3407 = load i32, ptr %slot623, align 8
  %cv3408 = zext i32 %v3407 to i64
  %cond3409 = icmp ne i64 %cv3408, 0
  br i1 %cond3409, label %bb_rcslotrole1169, label %bb_rcslotowner1169
bb_rcslotrole1169:
  %v3410 = load i64, ptr %slot43, align 8
  store i64 %v3410, ptr %slot624, align 8
  %v3411 = load i64, ptr %slot621, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  %ld3413 = load i64, ptr %p3412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3413, ptr %slot625, align 8
  %v3414 = load i64, ptr %slot625, align 8
  %cmp3415 = icmp ne i64 %v3414, 0
  %cv3416 = zext i1 %cmp3415 to i32
  store i32 %cv3416, ptr %slot626, align 8
  %v3417 = load i32, ptr %slot626, align 8
  %cv3418 = zext i32 %v3417 to i64
  %cond3419 = icmp ne i64 %cv3418, 0
  br i1 %cond3419, label %bb_rcgnn1185, label %bb_rcgdone1185
bb_rcgnn1185:
  %v3420 = load i64, ptr %slot625, align 8
  %op3421 = sub i64 %v3420, 16
  store i64 %op3421, ptr %slot627, align 8
  %v3422 = load i64, ptr %slot625, align 8
  %p3423 = inttoptr i64 %v3422 to ptr
  %rgep3424 = getelementptr i8, ptr %p3423, i64 -16
  %ld3425 = load i64, ptr %rgep3424, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3425, ptr %slot628, align 8
  %v3426 = load i64, ptr %slot628, align 8
  %op3427 = and i64 %v3426, 4611686018427387906
  store i64 %op3427, ptr %slot629, align 8
  %v3428 = load i64, ptr %slot629, align 8
  %cmp3429 = icmp ne i64 %v3428, 0
  %cv3430 = zext i1 %cmp3429 to i32
  store i32 %cv3430, ptr %slot630, align 8
  %v3431 = load i32, ptr %slot630, align 8
  %cv3432 = zext i32 %v3431 to i64
  %cond3433 = icmp ne i64 %cv3432, 0
  br i1 %cond3433, label %bb_rcgclear1185, label %bb_rcgcounted1185
bb_rcgcounted1185:
  %v3434 = load i64, ptr %slot625, align 8
  %op3435 = sub i64 %v3434, 24
  store i64 %op3435, ptr %slot631, align 8
  %v3436 = load i64, ptr %slot625, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  %rgep3438 = getelementptr i8, ptr %p3437, i64 -24
  %ld3439 = load i64, ptr %rgep3438, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3439, ptr %slot632, align 8
  %v3440 = load i64, ptr %slot632, align 8
  %op3441 = sub i64 %v3440, 1
  store i64 %op3441, ptr %slot633, align 8
  %v3442 = load i64, ptr %slot633, align 8
  %cmp3443 = icmp eq i64 %v3442, 0
  %cv3444 = zext i1 %cmp3443 to i32
  store i32 %cv3444, ptr %slot634, align 8
  %v3445 = load i32, ptr %slot634, align 8
  %cv3446 = zext i32 %v3445 to i64
  %cond3447 = icmp ne i64 %cv3446, 0
  br i1 %cond3447, label %bb_rcglast1185, label %bb_rcgdec1185
bb_rcglast1185:
  %v3448 = load i64, ptr %slot625, align 8
  %op3449 = sub i64 %v3448, 32
  store i64 %op3449, ptr %slot635, align 8
  %v3450 = load i64, ptr %slot625, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  %rgep3452 = getelementptr i8, ptr %p3451, i64 -32
  %ld3453 = load i64, ptr %rgep3452, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3453, ptr %slot636, align 8
  %v3454 = load i64, ptr %slot636, align 8
  %cmp3455 = icmp ne i64 %v3454, 0
  %cv3456 = zext i1 %cmp3455 to i32
  store i32 %cv3456, ptr %slot637, align 8
  %v3457 = load i32, ptr %slot637, align 8
  %cv3458 = zext i32 %v3457 to i64
  %cond3459 = icmp ne i64 %cv3458, 0
  br i1 %cond3459, label %bb_rcgdec1185, label %bb_rcgslow1185
bb_rcgslow1185:
  %v3460 = load i64, ptr %slot624, align 8
  %v3461 = load i64, ptr %slot621, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3460, i64 %v3461) nomerge, !dbg !158
  br label %bb_rcgdone1185
bb_rcgdec1185:
  %v3462 = load i64, ptr %slot633, align 8
  %v3463 = load i64, ptr %slot625, align 8
  %p3464 = inttoptr i64 %v3463 to ptr
  %rgep3465 = getelementptr i8, ptr %p3464, i64 -24
  store i64 %v3462, ptr %rgep3465, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1185
bb_rcgclear1185:
  %v3466 = load i64, ptr %slot621, align 8
  %p3467 = inttoptr i64 %v3466 to ptr
  store i64 0, ptr %p3467, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1185
bb_rcgdone1185:
  br label %bb_rcslotdone1169
bb_rcslotowner1169:
  %v3468 = load i64, ptr %slot43, align 8
  store i64 %v3468, ptr %slot638, align 8
  %v3469 = load i64, ptr %slot621, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  %ld3471 = load i64, ptr %p3470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3471, ptr %slot639, align 8
  %v3472 = load i64, ptr %slot639, align 8
  %cmp3473 = icmp ne i64 %v3472, 0
  %cv3474 = zext i1 %cmp3473 to i32
  store i32 %cv3474, ptr %slot640, align 8
  %v3475 = load i32, ptr %slot640, align 8
  %cv3476 = zext i32 %v3475 to i64
  %cond3477 = icmp ne i64 %cv3476, 0
  br i1 %cond3477, label %bb_rcgnn1200, label %bb_rcgdone1200
bb_rcgnn1200:
  %v3478 = load i64, ptr %slot639, align 8
  %op3479 = sub i64 %v3478, 16
  store i64 %op3479, ptr %slot641, align 8
  %v3480 = load i64, ptr %slot639, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  %rgep3482 = getelementptr i8, ptr %p3481, i64 -16
  %ld3483 = load i64, ptr %rgep3482, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3483, ptr %slot642, align 8
  %v3484 = load i64, ptr %slot642, align 8
  %op3485 = and i64 %v3484, 4611686018427387906
  store i64 %op3485, ptr %slot643, align 8
  %v3486 = load i64, ptr %slot643, align 8
  %cmp3487 = icmp ne i64 %v3486, 0
  %cv3488 = zext i1 %cmp3487 to i32
  store i32 %cv3488, ptr %slot644, align 8
  %v3489 = load i32, ptr %slot644, align 8
  %cv3490 = zext i32 %v3489 to i64
  %cond3491 = icmp ne i64 %cv3490, 0
  br i1 %cond3491, label %bb_rcgclear1200, label %bb_rcgcounted1200
bb_rcgcounted1200:
  %v3492 = load i64, ptr %slot639, align 8
  %op3493 = sub i64 %v3492, 32
  store i64 %op3493, ptr %slot645, align 8
  %v3494 = load i64, ptr %slot639, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  %rgep3496 = getelementptr i8, ptr %p3495, i64 -32
  %ld3497 = load i64, ptr %rgep3496, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3497, ptr %slot646, align 8
  %v3498 = load i64, ptr %slot646, align 8
  %op3499 = sub i64 %v3498, 1
  store i64 %op3499, ptr %slot647, align 8
  %v3500 = load i64, ptr %slot647, align 8
  %cmp3501 = icmp eq i64 %v3500, 0
  %cv3502 = zext i1 %cmp3501 to i32
  store i32 %cv3502, ptr %slot648, align 8
  %v3503 = load i32, ptr %slot648, align 8
  %cv3504 = zext i32 %v3503 to i64
  %cond3505 = icmp ne i64 %cv3504, 0
  br i1 %cond3505, label %bb_rcglast1200, label %bb_rcgdec1200
bb_rcglast1200:
  %v3506 = load i64, ptr %slot639, align 8
  %op3507 = sub i64 %v3506, 24
  store i64 %op3507, ptr %slot649, align 8
  %v3508 = load i64, ptr %slot639, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  %rgep3510 = getelementptr i8, ptr %p3509, i64 -24
  %ld3511 = load i64, ptr %rgep3510, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3511, ptr %slot650, align 8
  %v3512 = load i64, ptr %slot650, align 8
  %cmp3513 = icmp ne i64 %v3512, 0
  %cv3514 = zext i1 %cmp3513 to i32
  store i32 %cv3514, ptr %slot651, align 8
  %v3515 = load i32, ptr %slot651, align 8
  %cv3516 = zext i32 %v3515 to i64
  %cond3517 = icmp ne i64 %cv3516, 0
  br i1 %cond3517, label %bb_rcgdec1200, label %bb_rcgslow1200
bb_rcgslow1200:
  %v3518 = load i64, ptr %slot638, align 8
  %v3519 = load i64, ptr %slot621, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3518, i64 %v3519) nomerge, !dbg !158
  br label %bb_rcgdone1200
bb_rcgdec1200:
  %v3520 = load i64, ptr %slot647, align 8
  %v3521 = load i64, ptr %slot639, align 8
  %p3522 = inttoptr i64 %v3521 to ptr
  %rgep3523 = getelementptr i8, ptr %p3522, i64 -32
  store i64 %v3520, ptr %rgep3523, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1200
bb_rcgclear1200:
  %v3524 = load i64, ptr %slot621, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  store i64 0, ptr %p3525, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1200
bb_rcgdone1200:
  br label %bb_rcslotdone1169
bb_rcslotdone1169:
  %v3526 = load i64, ptr %slot15, align 8
  store i64 %v3526, ptr %slot652, align 8
  %v3527 = load i64, ptr %slot17, align 8
  store i64 %v3527, ptr %slot653, align 8
  %v3528 = load i64, ptr %slot653, align 8
  %v3529 = load i64, ptr %slot652, align 8
  %p3530 = inttoptr i64 %v3528 to ptr
  %p3531 = inttoptr i64 %v3529 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3531, ptr %p3530, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3532 = load i64, ptr %slot11, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  store i32 2, ptr %p3533, align 4, !alias.scope !3, !noalias !4
  %v3534 = load i64, ptr %slot13, align 8
  %p3535 = inttoptr i64 %v3534 to ptr
  %ld3536 = load i32, ptr %p3535, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3536, ptr %slot654, align 8
  %v3537 = load i32, ptr %slot654, align 8
  %v3538 = load i64, ptr %slot11, align 8
  %p3539 = inttoptr i64 %v3538 to ptr
  store i32 %v3537, ptr %p3539, align 4, !alias.scope !3, !noalias !4
  %v3540 = load i64, ptr %slot12, align 8
  %p3541 = inttoptr i64 %v3540 to ptr
  store i32 0, ptr %p3541, align 4, !alias.scope !3, !noalias !4
  %v3542 = load i64, ptr %slot10, align 8
  %p3543 = inttoptr i64 %v3542 to ptr
  store i32 1, ptr %p3543, align 4, !alias.scope !3, !noalias !4
  %v3544 = load i64, ptr %slot652, align 8
  %v3545 = load i64, ptr %slot26, align 8
  %p3546 = inttoptr i64 %v3545 to ptr
  store i64 %v3544, ptr %p3546, align 8, !alias.scope !3, !noalias !4
  %v3547 = load i64, ptr %slot38, align 8
  store i64 %v3547, ptr %slot655, align 8
  %v3548 = load i64, ptr %slot655, align 8
  %p3549 = inttoptr i64 %v3548 to ptr
  store i64 0, ptr %p3549, align 8, !alias.scope !3, !noalias !4
  %v3550 = load i64, ptr %slot655, align 8
  %p3552 = inttoptr i64 %v3550 to ptr
  %gep3553 = getelementptr i8, ptr %p3552, i64 8
  %op3551 = ptrtoint ptr %gep3553 to i64
  store i64 %op3551, ptr %slot656, align 8
  %v3554 = load i64, ptr %slot656, align 8
  %p3555 = inttoptr i64 %v3554 to ptr
  store i64 0, ptr %p3555, align 8, !alias.scope !3, !noalias !4
  %v3556 = load i64, ptr %slot655, align 8
  %p3558 = inttoptr i64 %v3556 to ptr
  %gep3559 = getelementptr i8, ptr %p3558, i64 16
  %op3557 = ptrtoint ptr %gep3559 to i64
  store i64 %op3557, ptr %slot657, align 8
  %v3560 = load i64, ptr %slot657, align 8
  %p3561 = inttoptr i64 %v3560 to ptr
  store i64 0, ptr %p3561, align 8, !alias.scope !3, !noalias !4
  %v3562 = load i64, ptr %slot655, align 8
  %p3563 = inttoptr i64 %v3562 to ptr
  store i32 1, ptr %p3563, align 4, !alias.scope !3, !noalias !4
  %v3564 = load i64, ptr %slot14, align 8
  %p3565 = inttoptr i64 %v3564 to ptr
  store i32 1, ptr %p3565, align 4, !alias.scope !3, !noalias !4
  %v3566 = load i64, ptr %slot26, align 8
  %p3567 = inttoptr i64 %v3566 to ptr
  %ld3568 = load i64, ptr %p3567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3568, ptr %slot658, align 8
  %v3569 = load i64, ptr %slot655, align 8
  %p3571 = inttoptr i64 %v3569 to ptr
  %gep3572 = getelementptr i8, ptr %p3571, i64 8
  %op3570 = ptrtoint ptr %gep3572 to i64
  store i64 %op3570, ptr %slot659, align 8
  %v3573 = load i64, ptr %slot44, align 8
  store i64 %v3573, ptr %slot660, align 8
  %v3574 = load i64, ptr %slot26, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  %ld3576 = load i64, ptr %p3575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3576, ptr %slot661, align 8
  %v3577 = load i64, ptr %slot10, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  %ld3579 = load i32, ptr %p3578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3579, ptr %slot662, align 8
  %v3580 = load i64, ptr %slot11, align 8
  %p3581 = inttoptr i64 %v3580 to ptr
  %ld3582 = load i32, ptr %p3581, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3582, ptr %slot663, align 8
  %v3583 = load i32, ptr %slot663, align 8
  %op3584 = and i32 %v3583, 24
  store i32 %op3584, ptr %slot663, align 8
  %v3585 = load i32, ptr %slot663, align 8
  %cmp3586 = icmp eq i32 %v3585, 0
  %cv3587 = zext i1 %cmp3586 to i32
  store i32 %cv3587, ptr %slot664, align 8
  %v3588 = load i32, ptr %slot662, align 8
  %v3589 = load i32, ptr %slot664, align 8
  %op3590 = and i32 %v3588, %v3589
  store i32 %op3590, ptr %slot665, align 8
  %v3591 = load i32, ptr %slot665, align 8
  %cv3592 = zext i32 %v3591 to i64
  %cond3593 = icmp ne i64 %cv3592, 0
  br i1 %cond3593, label %bb_rctake1221, label %bb_rccopy1221
bb_rctake1221:
  %v3594 = load i64, ptr %slot17, align 8
  store i64 %v3594, ptr %slot666, align 8
  %v3595 = load i64, ptr %slot44, align 8
  store i64 %v3595, ptr %slot667, align 8
  %v3596 = load i64, ptr %slot661, align 8
  %v3597 = load i64, ptr %slot666, align 8
  %op3598 = sub i64 %v3596, %v3597
  store i64 %op3598, ptr %slot668, align 8
  %v3599 = load i64, ptr %slot666, align 8
  %v3600 = load i64, ptr %slot661, align 8
  %op3601 = sub i64 %v3599, %v3600
  store i64 %op3601, ptr %slot669, align 8
  %v3602 = load i64, ptr %slot668, align 8
  %cmp3603 = icmp ult i64 %v3602, 16
  %cv3604 = zext i1 %cmp3603 to i32
  store i32 %cv3604, ptr %slot670, align 8
  %v3605 = load i64, ptr %slot669, align 8
  %cmp3606 = icmp ult i64 %v3605, 16
  %cv3607 = zext i1 %cmp3606 to i32
  store i32 %cv3607, ptr %slot671, align 8
  %v3608 = load i32, ptr %slot670, align 8
  %v3609 = load i32, ptr %slot671, align 8
  %op3610 = or i32 %v3608, %v3609
  store i32 %op3610, ptr %slot672, align 8
  %v3611 = load i32, ptr %slot672, align 8
  %cv3612 = zext i32 %v3611 to i64
  %cond3613 = icmp ne i64 %cv3612, 0
  br i1 %cond3613, label %bb_rcmoveslow1230, label %bb_rcmovecheck1230
bb_rcmovecheck1230:
  %v3614 = load i64, ptr %slot661, align 8
  %op3615 = add i64 %v3614, 0
  store i64 %op3615, ptr %slot673, align 8
  %v3616 = load i64, ptr %slot673, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  %ld3618 = load i64, ptr %p3617, align 8
  store i64 %ld3618, ptr %slot674, align 8
  %v3619 = load i64, ptr %slot674, align 8
  %cmp3620 = icmp ne i64 %v3619, 0
  %cv3621 = zext i1 %cmp3620 to i32
  store i32 %cv3621, ptr %slot675, align 8
  %v3622 = load i32, ptr %slot675, align 8
  %cv3623 = zext i32 %v3622 to i64
  %cond3624 = icmp ne i64 %cv3623, 0
  br i1 %cond3624, label %bb_rcmoveheader1238, label %bb_rcmovenext1238
bb_rcmoveheader1238:
  %v3625 = load i64, ptr %slot674, align 8
  %op3626 = sub i64 %v3625, 16
  store i64 %op3626, ptr %slot676, align 8
  %v3627 = load i64, ptr %slot674, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  %rgep3629 = getelementptr i8, ptr %p3628, i64 -16
  %ld3630 = load i64, ptr %rgep3629, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3630, ptr %slot677, align 8
  %v3631 = load i64, ptr %slot677, align 8
  %op3632 = and i64 %v3631, 5764607523034234881
  store i64 %op3632, ptr %slot678, align 8
  %v3633 = load i64, ptr %slot678, align 8
  %cmp3634 = icmp ne i64 %v3633, 0
  %cv3635 = zext i1 %cmp3634 to i32
  store i32 %cv3635, ptr %slot679, align 8
  %v3636 = load i32, ptr %slot679, align 8
  %cv3637 = zext i32 %v3636 to i64
  %cond3638 = icmp ne i64 %cv3637, 0
  br i1 %cond3638, label %bb_rcmoveslow1230, label %bb_rcmovenext1238
bb_rcmovenext1238:
  %v3639 = load i64, ptr %slot661, align 8
  %v3640 = load i64, ptr %slot666, align 8
  %p3641 = inttoptr i64 %v3639 to ptr
  %p3642 = inttoptr i64 %v3640 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3642, ptr %p3641, i64 16, i1 false)
  %v3643 = load i64, ptr %slot661, align 8
  %p3644 = inttoptr i64 %v3643 to ptr
  store i64 0, ptr %p3644, align 8
  %v3645 = load i64, ptr %slot661, align 8
  %op3646 = add i64 %v3645, 8
  store i64 %op3646, ptr %slot680, align 8
  %v3647 = load i64, ptr %slot680, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  store i64 0, ptr %p3648, align 8
  br label %bb_rcmoved1230
bb_rcmoveslow1230:
  %v3649 = load i64, ptr %slot43, align 8
  %v3650 = load i64, ptr %slot666, align 8
  %v3651 = load i64, ptr %slot661, align 8
  %v3652 = load i64, ptr %slot667, align 8
  %cv3653 = trunc i64 %v3652 to i32
  %call3654 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v3649, i64 %v3650, i64 %v3651, i32 %cv3653) nomerge, !dbg !160
  store i32 %call3654, ptr %slot681, align 8
  %v3655 = load i32, ptr %slot681, align 8
  %cv3656 = zext i32 %v3655 to i64
  %cond3657 = icmp ne i64 %cv3656, 0
  br i1 %cond3657, label %bb_rcsuccess1246, label %bb_rcfailure1246
bb_rcfailure1246:
  %v3658 = load i64, ptr %slot43, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  %call3660 = call i32 @myl_rc_take_failure(ptr %p3659) nomerge, !dbg !160
  store i32 %call3660, ptr %slot682, align 8
  %v3661 = load i64, ptr %slot1, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  %v3663 = load i32, ptr %slot682, align 8
  %call3664 = call i32 @myl_qbe_rc_status(ptr %p3662, i32 %v3663) nomerge, !dbg !160
  store i32 %call3664, ptr %slot683, align 8
  br label %bb_failure
bb_rcsuccess1246:
  br label %bb_rcmoved1230
bb_rcmoved1230:
  %v3665 = load i64, ptr %slot10, align 8
  %p3666 = inttoptr i64 %v3665 to ptr
  store i32 0, ptr %p3666, align 4, !alias.scope !3, !noalias !4
  %v3667 = load i64, ptr %slot13, align 8
  %p3668 = inttoptr i64 %v3667 to ptr
  store i32 2, ptr %p3668, align 4, !alias.scope !3, !noalias !4
  %v3669 = load i64, ptr %slot12, align 8
  %p3670 = inttoptr i64 %v3669 to ptr
  store i32 1, ptr %p3670, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1221
bb_rccopy1221:
  %v3671 = load i64, ptr %slot17, align 8
  store i64 %v3671, ptr %slot684, align 8
  %v3672 = load i64, ptr %slot44, align 8
  store i64 %v3672, ptr %slot685, align 8
  %v3673 = load i64, ptr %slot43, align 8
  %v3674 = load i64, ptr %slot684, align 8
  %v3675 = load i64, ptr %slot661, align 8
  %v3676 = load i64, ptr %slot685, align 8
  %cv3677 = trunc i64 %v3676 to i32
  %call3678 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v3673, i64 %v3674, i64 %v3675, i32 %cv3677) nomerge, !dbg !160
  store i32 %call3678, ptr %slot686, align 8
  %v3679 = load i32, ptr %slot686, align 8
  %cv3680 = zext i32 %v3679 to i64
  %cond3681 = icmp ne i64 %cv3680, 0
  br i1 %cond3681, label %bb_rcsuccess1255, label %bb_rcfailure1255
bb_rcfailure1255:
  %v3682 = load i64, ptr %slot43, align 8
  %p3683 = inttoptr i64 %v3682 to ptr
  %call3684 = call i32 @myl_rc_take_failure(ptr %p3683) nomerge, !dbg !160
  store i32 %call3684, ptr %slot687, align 8
  %v3685 = load i64, ptr %slot1, align 8
  %p3686 = inttoptr i64 %v3685 to ptr
  %v3687 = load i32, ptr %slot687, align 8
  %call3688 = call i32 @myl_qbe_rc_status(ptr %p3686, i32 %v3687) nomerge, !dbg !160
  store i32 %call3688, ptr %slot688, align 8
  br label %bb_failure
bb_rcsuccess1255:
  %v3689 = load i64, ptr %slot13, align 8
  %p3690 = inttoptr i64 %v3689 to ptr
  store i32 2, ptr %p3690, align 4, !alias.scope !3, !noalias !4
  %v3691 = load i64, ptr %slot12, align 8
  %p3692 = inttoptr i64 %v3691 to ptr
  store i32 1, ptr %p3692, align 4, !alias.scope !3, !noalias !4
  %v3693 = load i64, ptr %slot10, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  %ld3695 = load i32, ptr %p3694, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3695, ptr %slot689, align 8
  %v3696 = load i32, ptr %slot689, align 8
  %cv3697 = zext i32 %v3696 to i64
  %cond3698 = icmp ne i64 %cv3697, 0
  br i1 %cond3698, label %bb_rcslotdrop1262, label %bb_rcslotdone1262
bb_rcslotdrop1262:
  %v3699 = load i64, ptr %slot10, align 8
  %p3700 = inttoptr i64 %v3699 to ptr
  store i32 0, ptr %p3700, align 4, !alias.scope !3, !noalias !4
  %v3701 = load i64, ptr %slot15, align 8
  store i64 %v3701, ptr %slot690, align 8
  %v3702 = load i64, ptr %slot11, align 8
  %p3703 = inttoptr i64 %v3702 to ptr
  %ld3704 = load i32, ptr %p3703, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3704, ptr %slot691, align 8
  %v3705 = load i32, ptr %slot691, align 8
  %op3706 = and i32 %v3705, 28
  store i32 %op3706, ptr %slot692, align 8
  %v3707 = load i32, ptr %slot692, align 8
  %cv3708 = zext i32 %v3707 to i64
  %cond3709 = icmp ne i64 %cv3708, 0
  br i1 %cond3709, label %bb_rcslotrole1262, label %bb_rcslotowner1262
bb_rcslotrole1262:
  %v3710 = load i64, ptr %slot43, align 8
  store i64 %v3710, ptr %slot693, align 8
  %v3711 = load i64, ptr %slot693, align 8
  %v3712 = load i64, ptr %slot690, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v3711, i64 %v3712) nomerge, !dbg !160
  br label %bb_rcslotdone1262
bb_rcslotowner1262:
  %v3713 = load i64, ptr %slot43, align 8
  store i64 %v3713, ptr %slot694, align 8
  %v3714 = load i64, ptr %slot694, align 8
  %v3715 = load i64, ptr %slot690, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v3714, i64 %v3715) nomerge, !dbg !160
  br label %bb_rcslotdone1262
bb_rcslotdone1262:
  br label %bb_rcprepared1221
bb_rcprepared1221:
  %v3716 = load i64, ptr %slot17, align 8
  store i64 %v3716, ptr %slot695, align 8
  %v3717 = load i64, ptr %slot695, align 8
  %v3718 = load i64, ptr %slot659, align 8
  %p3719 = inttoptr i64 %v3717 to ptr
  %p3720 = inttoptr i64 %v3718 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3720, ptr %p3719, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3721 = load i64, ptr %slot12, align 8
  %p3722 = inttoptr i64 %v3721 to ptr
  store i32 0, ptr %p3722, align 4, !alias.scope !3, !noalias !4
  %v3723 = load i64, ptr %slot655, align 8
  %v3724 = load i64, ptr %slot26, align 8
  %p3725 = inttoptr i64 %v3724 to ptr
  store i64 %v3723, ptr %p3725, align 8, !alias.scope !3, !noalias !4
  %p3726 = inttoptr i64 ptrtoint (ptr @myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p3726, i64 105) "call-inline-cost"="0", !dbg !160
  %v3727 = load i64, ptr %slot26, align 8
  %p3728 = inttoptr i64 %v3727 to ptr
  %ld3729 = load i64, ptr %p3728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3729, ptr %slot696, align 8
  %v3730 = load i64, ptr %slot15, align 8
  store i64 %v3730, ptr %slot697, align 8
  %v3731 = load i64, ptr %slot696, align 8
  %v3732 = load i64, ptr %slot697, align 8
  %p3733 = inttoptr i64 %v3731 to ptr
  %p3734 = inttoptr i64 %v3732 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3734, ptr %p3733, i64 24, i1 false)
  %v3735 = load i64, ptr %slot11, align 8
  %p3736 = inttoptr i64 %v3735 to ptr
  store i32 2, ptr %p3736, align 4, !alias.scope !3, !noalias !4
  %v3737 = load i64, ptr %slot10, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  store i32 1, ptr %p3738, align 4, !alias.scope !3, !noalias !4
  %v3739 = load i64, ptr %slot697, align 8
  %v3740 = load i64, ptr %slot26, align 8
  %p3741 = inttoptr i64 %v3740 to ptr
  store i64 %v3739, ptr %p3741, align 8, !alias.scope !3, !noalias !4
  %v3742 = load i64, ptr %slot26, align 8
  %p3743 = inttoptr i64 %v3742 to ptr
  %ld3744 = load i64, ptr %p3743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3744, ptr %slot698, align 8
  %v3745 = load i64, ptr %slot26, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  %ld3747 = load i64, ptr %p3746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3747, ptr %slot699, align 8
  %v3748 = load i64, ptr %slot17, align 8
  store i64 %v3748, ptr %slot700, align 8
  %v3749 = load i64, ptr %slot44, align 8
  store i64 %v3749, ptr %slot701, align 8
  %v3750 = load i64, ptr %slot43, align 8
  %v3751 = load i64, ptr %slot700, align 8
  %v3752 = load i64, ptr %slot699, align 8
  %v3753 = load i64, ptr %slot701, align 8
  %cv3754 = trunc i64 %v3753 to i32
  %call3755 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v3750, i64 %v3751, i64 %v3752, i32 %cv3754) nomerge, !dbg !162
  store i32 %call3755, ptr %slot702, align 8
  %v3756 = load i32, ptr %slot702, align 8
  %cv3757 = zext i32 %v3756 to i64
  %cond3758 = icmp ne i64 %cv3757, 0
  br i1 %cond3758, label %bb_rcsuccess1280, label %bb_rcfailure1280
bb_rcfailure1280:
  %v3759 = load i64, ptr %slot43, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  %call3761 = call i32 @myl_rc_take_failure(ptr %p3760) nomerge, !dbg !162
  store i32 %call3761, ptr %slot703, align 8
  %v3762 = load i64, ptr %slot1, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %v3764 = load i32, ptr %slot703, align 8
  %call3765 = call i32 @myl_qbe_rc_status(ptr %p3763, i32 %v3764) nomerge, !dbg !162
  store i32 %call3765, ptr %slot704, align 8
  br label %bb_failure
bb_rcsuccess1280:
  %v3766 = load i64, ptr %slot10, align 8
  %p3767 = inttoptr i64 %v3766 to ptr
  store i32 0, ptr %p3767, align 4, !alias.scope !3, !noalias !4
  %v3768 = load i64, ptr %slot13, align 8
  %p3769 = inttoptr i64 %v3768 to ptr
  store i32 2, ptr %p3769, align 4, !alias.scope !3, !noalias !4
  %v3770 = load i64, ptr %slot12, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  store i32 1, ptr %p3771, align 4, !alias.scope !3, !noalias !4
  %v3772 = load i64, ptr %slot17, align 8
  store i64 %v3772, ptr %slot705, align 8
  %v3773 = load i64, ptr %slot12, align 8
  %p3774 = inttoptr i64 %v3773 to ptr
  store i32 0, ptr %p3774, align 4, !alias.scope !3, !noalias !4
  %v3775 = load i64, ptr %slot10, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  %ld3777 = load i32, ptr %p3776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3777, ptr %slot706, align 8
  %v3778 = load i32, ptr %slot706, align 8
  %cv3779 = zext i32 %v3778 to i64
  %cond3780 = icmp ne i64 %cv3779, 0
  br i1 %cond3780, label %bb_rcslotdrop1290, label %bb_rcslotdone1290
bb_rcslotdrop1290:
  %v3781 = load i64, ptr %slot10, align 8
  %p3782 = inttoptr i64 %v3781 to ptr
  store i32 0, ptr %p3782, align 4, !alias.scope !3, !noalias !4
  %v3783 = load i64, ptr %slot15, align 8
  store i64 %v3783, ptr %slot707, align 8
  %v3784 = load i64, ptr %slot11, align 8
  %p3785 = inttoptr i64 %v3784 to ptr
  %ld3786 = load i32, ptr %p3785, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3786, ptr %slot708, align 8
  %v3787 = load i32, ptr %slot708, align 8
  %op3788 = and i32 %v3787, 28
  store i32 %op3788, ptr %slot709, align 8
  %v3789 = load i32, ptr %slot709, align 8
  %cv3790 = zext i32 %v3789 to i64
  %cond3791 = icmp ne i64 %cv3790, 0
  br i1 %cond3791, label %bb_rcslotrole1290, label %bb_rcslotowner1290
bb_rcslotrole1290:
  %v3792 = load i64, ptr %slot43, align 8
  store i64 %v3792, ptr %slot710, align 8
  %v3793 = load i64, ptr %slot710, align 8
  %v3794 = load i64, ptr %slot707, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v3793, i64 %v3794) nomerge, !dbg !162
  br label %bb_rcslotdone1290
bb_rcslotowner1290:
  %v3795 = load i64, ptr %slot43, align 8
  store i64 %v3795, ptr %slot711, align 8
  %v3796 = load i64, ptr %slot711, align 8
  %v3797 = load i64, ptr %slot707, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v3796, i64 %v3797) nomerge, !dbg !162
  br label %bb_rcslotdone1290
bb_rcslotdone1290:
  %v3798 = load i64, ptr %slot8, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  %ld3800 = load i32, ptr %p3799, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3800, ptr %slot712, align 8
  %v3801 = load i32, ptr %slot712, align 8
  %cv3802 = zext i32 %v3801 to i64
  %cond3803 = icmp ne i64 %cv3802, 0
  br i1 %cond3803, label %bb_rcslotdrop1317, label %bb_rcslotdone1317
bb_rcslotdrop1317:
  %v3804 = load i64, ptr %slot8, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  store i32 0, ptr %p3805, align 4, !alias.scope !3, !noalias !4
  %v3806 = load i64, ptr %slot23, align 8
  store i64 %v3806, ptr %slot713, align 8
  %v3807 = load i64, ptr %slot9, align 8
  %p3808 = inttoptr i64 %v3807 to ptr
  %ld3809 = load i32, ptr %p3808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3809, ptr %slot714, align 8
  %v3810 = load i32, ptr %slot714, align 8
  %op3811 = and i32 %v3810, 28
  store i32 %op3811, ptr %slot715, align 8
  %v3812 = load i32, ptr %slot715, align 8
  %cv3813 = zext i32 %v3812 to i64
  %cond3814 = icmp ne i64 %cv3813, 0
  br i1 %cond3814, label %bb_rcslotrole1317, label %bb_rcslotowner1317
bb_rcslotrole1317:
  %v3815 = load i64, ptr %slot43, align 8
  store i64 %v3815, ptr %slot716, align 8
  %v3816 = load i64, ptr %slot716, align 8
  %v3817 = load i64, ptr %slot713, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3816, i64 %v3817) nomerge, !dbg !162
  br label %bb_rcslotdone1317
bb_rcslotowner1317:
  %v3818 = load i64, ptr %slot43, align 8
  store i64 %v3818, ptr %slot717, align 8
  %v3819 = load i64, ptr %slot717, align 8
  %v3820 = load i64, ptr %slot713, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3819, i64 %v3820) nomerge, !dbg !162
  br label %bb_rcslotdone1317
bb_rcslotdone1317:
  %v3821 = load i64, ptr %slot6, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  %ld3823 = load i32, ptr %p3822, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3823, ptr %slot718, align 8
  %v3824 = load i32, ptr %slot718, align 8
  %cv3825 = zext i32 %v3824 to i64
  %cond3826 = icmp ne i64 %cv3825, 0
  br i1 %cond3826, label %bb_rcslotdrop1344, label %bb_rcslotdone1344
bb_rcslotdrop1344:
  %v3827 = load i64, ptr %slot6, align 8
  %p3828 = inttoptr i64 %v3827 to ptr
  store i32 0, ptr %p3828, align 4, !alias.scope !3, !noalias !4
  %v3829 = load i64, ptr %slot21, align 8
  store i64 %v3829, ptr %slot719, align 8
  %v3830 = load i64, ptr %slot7, align 8
  %p3831 = inttoptr i64 %v3830 to ptr
  %ld3832 = load i32, ptr %p3831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3832, ptr %slot720, align 8
  %v3833 = load i32, ptr %slot720, align 8
  %op3834 = and i32 %v3833, 28
  store i32 %op3834, ptr %slot721, align 8
  %v3835 = load i32, ptr %slot721, align 8
  %cv3836 = zext i32 %v3835 to i64
  %cond3837 = icmp ne i64 %cv3836, 0
  br i1 %cond3837, label %bb_rcslotrole1344, label %bb_rcslotowner1344
bb_rcslotrole1344:
  %v3838 = load i64, ptr %slot43, align 8
  store i64 %v3838, ptr %slot722, align 8
  %v3839 = load i64, ptr %slot722, align 8
  %v3840 = load i64, ptr %slot719, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3839, i64 %v3840) nomerge, !dbg !162
  br label %bb_rcslotdone1344
bb_rcslotowner1344:
  %v3841 = load i64, ptr %slot43, align 8
  store i64 %v3841, ptr %slot723, align 8
  %v3842 = load i64, ptr %slot723, align 8
  %v3843 = load i64, ptr %slot719, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3842, i64 %v3843) nomerge, !dbg !162
  br label %bb_rcslotdone1344
bb_rcslotdone1344:
  %v3844 = load i64, ptr %slot705, align 8
  %p3845 = inttoptr i64 %v3844 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3845, i64 24, i1 false)
  ret void
bb_failure:
  %v3846 = load i64, ptr %slot5, align 8
  %p3847 = inttoptr i64 %v3846 to ptr
  call void @llvm.memset.p0.i64(ptr %p3847, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !162
  %v3848 = load i64, ptr %slot5, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3849, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v3850 = load i64, ptr %slot5, align 8
  %p3851 = inttoptr i64 %v3850 to ptr
  call void @llvm.memset.p0.i64(ptr %p3851, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !162
  %v3852 = load i64, ptr %slot5, align 8
  %p3853 = inttoptr i64 %v3852 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p3853, i64 24, i1 false)
  ret void
}

@myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e_meta = external global i8, align 8
@myl_lit_2d6548b0d20925eb41b8b902da17a2651a780e0ecf585d7c93694f27a1a25cd5 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_1e67eb8ef4c3a3acc3a97242d455a6d9c8a2bcb48d8912e38331c2e291a74a0e(i64, i64, i64)
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64, i64, i64)
declare void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare i64 @myl_qbe_float_unary(ptr, i64, i64)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64, i64)
declare void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_drop(i64, i64)
declare void @myl_t_f298b6d8457736465302b199391c1c9d6e57cdd1f586a7753cd47f47922b1d32_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e", linkageName: "myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 2110239902949550956, i64 0, !"myl_f_24022340835b630bed429507b0babcf6a1938c3f290f9ce31271e951c2af0b8e"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!122 = !DILocation(line: 12, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!124 = !DILocation(line: 15, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!126 = !DILocation(line: 16, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!128 = !DILocation(line: 21, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!130 = !DILocation(line: 39, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!132 = !DILocation(line: 51, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!134 = !DILocation(line: 56, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!136 = !DILocation(line: 60, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!138 = !DILocation(line: 66, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!140 = !DILocation(line: 69, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647183)
!142 = !DILocation(line: 81, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647223)
!144 = !DILocation(line: 86, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647263)
!146 = !DILocation(line: 91, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!148 = !DILocation(line: 92, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647279)
!150 = !DILocation(line: 93, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647319)
!152 = !DILocation(line: 98, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!154 = !DILocation(line: 99, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647335)
!156 = !DILocation(line: 100, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647375)
!158 = !DILocation(line: 105, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647383)
!160 = !DILocation(line: 106, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!162 = !DILocation(line: 107, column: 0, scope: !163)
