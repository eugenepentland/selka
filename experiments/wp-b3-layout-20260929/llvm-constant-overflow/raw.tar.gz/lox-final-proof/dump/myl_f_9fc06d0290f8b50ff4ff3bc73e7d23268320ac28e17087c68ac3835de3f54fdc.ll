target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_9fc06d0290f8b50ff4ff3bc73e7d23268320ac28e17087c68ac3835de3f54fdc(ptr sret([32 x i8]) align 8 %p_sret, i64 %p_ctx) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i32, align 8
  %slot416 = alloca i32, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i32, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i32, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i32, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i32, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i32, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i32, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i32, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i32, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i32, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i32, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  %v999 = load i64, ptr %slot1, align 8
  %op1000 = add i64 %v999, 32
  store i64 %op1000, ptr %slot2, align 8
  %mem1001 = alloca i8, i64 32, align 8
  %ptr1002 = ptrtoint ptr %mem1001 to i64
  store i64 %ptr1002, ptr %slot3, align 8
  %mem1003 = alloca i8, i64 8, align 8
  %ptr1004 = ptrtoint ptr %mem1003 to i64
  store i64 %ptr1004, ptr %slot4, align 8
  %mem1005 = alloca i8, i64 8, align 8
  %ptr1006 = ptrtoint ptr %mem1005 to i64
  store i64 %ptr1006, ptr %slot5, align 8
  %mem1007 = alloca i8, i64 8, align 8
  %ptr1008 = ptrtoint ptr %mem1007 to i64
  store i64 %ptr1008, ptr %slot6, align 8
  %mem1009 = alloca i8, i64 8, align 8
  %ptr1010 = ptrtoint ptr %mem1009 to i64
  store i64 %ptr1010, ptr %slot7, align 8
  %mem1011 = alloca i8, i64 8, align 8
  %ptr1012 = ptrtoint ptr %mem1011 to i64
  store i64 %ptr1012, ptr %slot8, align 8
  %mem1013 = alloca i8, i64 8, align 8
  %ptr1014 = ptrtoint ptr %mem1013 to i64
  store i64 %ptr1014, ptr %slot9, align 8
  %mem1015 = alloca i8, i64 8, align 8
  %ptr1016 = ptrtoint ptr %mem1015 to i64
  store i64 %ptr1016, ptr %slot10, align 8
  %mem1017 = alloca i8, i64 8, align 8
  %ptr1018 = ptrtoint ptr %mem1017 to i64
  store i64 %ptr1018, ptr %slot11, align 8
  %mem1019 = alloca i8, i64 8, align 8
  %ptr1020 = ptrtoint ptr %mem1019 to i64
  store i64 %ptr1020, ptr %slot12, align 8
  %mem1021 = alloca i8, i64 8, align 8
  %ptr1022 = ptrtoint ptr %mem1021 to i64
  store i64 %ptr1022, ptr %slot13, align 8
  %mem1023 = alloca i8, i64 8, align 8
  %ptr1024 = ptrtoint ptr %mem1023 to i64
  store i64 %ptr1024, ptr %slot14, align 8
  %mem1025 = alloca i8, i64 8, align 8
  %ptr1026 = ptrtoint ptr %mem1025 to i64
  store i64 %ptr1026, ptr %slot15, align 8
  %mem1027 = alloca i8, i64 8, align 8
  %ptr1028 = ptrtoint ptr %mem1027 to i64
  store i64 %ptr1028, ptr %slot16, align 8
  %mem1029 = alloca i8, i64 8, align 8
  %ptr1030 = ptrtoint ptr %mem1029 to i64
  store i64 %ptr1030, ptr %slot17, align 8
  %mem1031 = alloca i8, i64 8, align 8
  %ptr1032 = ptrtoint ptr %mem1031 to i64
  store i64 %ptr1032, ptr %slot18, align 8
  %mem1033 = alloca i8, i64 8, align 8
  %ptr1034 = ptrtoint ptr %mem1033 to i64
  store i64 %ptr1034, ptr %slot19, align 8
  %mem1035 = alloca i8, i64 8, align 8
  %ptr1036 = ptrtoint ptr %mem1035 to i64
  store i64 %ptr1036, ptr %slot20, align 8
  %mem1037 = alloca i8, i64 8, align 8
  %ptr1038 = ptrtoint ptr %mem1037 to i64
  store i64 %ptr1038, ptr %slot21, align 8
  %mem1039 = alloca i8, i64 8, align 8
  %ptr1040 = ptrtoint ptr %mem1039 to i64
  store i64 %ptr1040, ptr %slot22, align 8
  %mem1041 = alloca i8, i64 32, align 8
  %ptr1042 = ptrtoint ptr %mem1041 to i64
  store i64 %ptr1042, ptr %slot23, align 8
  %mem1043 = alloca i8, i64 8, align 8
  %ptr1044 = ptrtoint ptr %mem1043 to i64
  store i64 %ptr1044, ptr %slot24, align 8
  %mem1045 = alloca i8, i64 8, align 8
  %ptr1046 = ptrtoint ptr %mem1045 to i64
  store i64 %ptr1046, ptr %slot25, align 8
  %mem1047 = alloca i8, i64 8, align 8
  %ptr1048 = ptrtoint ptr %mem1047 to i64
  store i64 %ptr1048, ptr %slot26, align 8
  %mem1049 = alloca i8, i64 8, align 8
  %ptr1050 = ptrtoint ptr %mem1049 to i64
  store i64 %ptr1050, ptr %slot27, align 8
  %mem1051 = alloca i8, i64 8, align 8
  %ptr1052 = ptrtoint ptr %mem1051 to i64
  store i64 %ptr1052, ptr %slot28, align 8
  %mem1053 = alloca i8, i64 8, align 8
  %ptr1054 = ptrtoint ptr %mem1053 to i64
  store i64 %ptr1054, ptr %slot29, align 8
  %mem1055 = alloca i8, i64 8, align 8
  %ptr1056 = ptrtoint ptr %mem1055 to i64
  store i64 %ptr1056, ptr %slot30, align 8
  %mem1057 = alloca i8, i64 32, align 8
  %ptr1058 = ptrtoint ptr %mem1057 to i64
  store i64 %ptr1058, ptr %slot31, align 8
  %mem1059 = alloca i8, i64 8, align 8
  %ptr1060 = ptrtoint ptr %mem1059 to i64
  store i64 %ptr1060, ptr %slot32, align 8
  %mem1061 = alloca i8, i64 8, align 8
  %ptr1062 = ptrtoint ptr %mem1061 to i64
  store i64 %ptr1062, ptr %slot33, align 8
  %mem1063 = alloca i8, i64 8, align 8
  %ptr1064 = ptrtoint ptr %mem1063 to i64
  store i64 %ptr1064, ptr %slot34, align 8
  %mem1065 = alloca i8, i64 8, align 8
  %ptr1066 = ptrtoint ptr %mem1065 to i64
  store i64 %ptr1066, ptr %slot35, align 8
  %mem1067 = alloca i8, i64 8, align 8
  %ptr1068 = ptrtoint ptr %mem1067 to i64
  store i64 %ptr1068, ptr %slot36, align 8
  %mem1069 = alloca i8, i64 8, align 8
  %ptr1070 = ptrtoint ptr %mem1069 to i64
  store i64 %ptr1070, ptr %slot37, align 8
  %mem1071 = alloca i8, i64 8, align 8
  %ptr1072 = ptrtoint ptr %mem1071 to i64
  store i64 %ptr1072, ptr %slot38, align 8
  %mem1073 = alloca i8, i64 8, align 8
  %ptr1074 = ptrtoint ptr %mem1073 to i64
  store i64 %ptr1074, ptr %slot39, align 8
  %mem1075 = alloca i8, i64 32, align 8
  %ptr1076 = ptrtoint ptr %mem1075 to i64
  store i64 %ptr1076, ptr %slot40, align 8
  %v1077 = load i64, ptr %slot32, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  store i64 0, ptr %p1078, align 8, !alias.scope !3, !noalias !4
  %v1079 = load i64, ptr %slot33, align 8
  %p1080 = inttoptr i64 %v1079 to ptr
  store i64 0, ptr %p1080, align 8, !alias.scope !3, !noalias !4
  %v1081 = load i64, ptr %slot34, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i64 0, ptr %p1082, align 8, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot35, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  store i64 0, ptr %p1084, align 8, !alias.scope !3, !noalias !4
  %v1085 = load i64, ptr %slot1, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  %call1087 = call ptr @myl_qbe_heap(ptr %p1086) nomerge, !dbg !110
  %calladdr1088 = ptrtoint ptr %call1087 to i64
  store i64 %calladdr1088, ptr %slot41, align 8
  %v1089 = load i64, ptr %slot1, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  %call1091 = call i64 @myl_qbe_region_mark(ptr %p1090) nomerge, !dbg !110
  store i64 %call1091, ptr %slot42, align 8
  %v1092 = load i64, ptr %slot4, align 8
  %p1093 = inttoptr i64 %v1092 to ptr
  store i32 0, ptr %p1093, align 4, !alias.scope !3, !noalias !4
  %v1094 = load i64, ptr %slot5, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  store i32 0, ptr %p1095, align 4, !alias.scope !3, !noalias !4
  %v1096 = load i64, ptr %slot6, align 8
  %p1097 = inttoptr i64 %v1096 to ptr
  store i32 0, ptr %p1097, align 4, !alias.scope !3, !noalias !4
  %v1098 = load i64, ptr %slot7, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  store i32 0, ptr %p1099, align 4, !alias.scope !3, !noalias !4
  %v1100 = load i64, ptr %slot8, align 8
  %p1101 = inttoptr i64 %v1100 to ptr
  store i32 0, ptr %p1101, align 4, !alias.scope !3, !noalias !4
  %v1102 = load i64, ptr %slot9, align 8
  %p1103 = inttoptr i64 %v1102 to ptr
  store i32 0, ptr %p1103, align 4, !alias.scope !3, !noalias !4
  %v1104 = load i64, ptr %slot10, align 8
  %p1105 = inttoptr i64 %v1104 to ptr
  store i32 0, ptr %p1105, align 4, !alias.scope !3, !noalias !4
  %v1106 = load i64, ptr %slot11, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  store i32 0, ptr %p1107, align 4, !alias.scope !3, !noalias !4
  %v1108 = load i64, ptr %slot12, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  store i32 0, ptr %p1109, align 4, !alias.scope !3, !noalias !4
  %v1110 = load i64, ptr %slot13, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  store i32 0, ptr %p1111, align 4, !alias.scope !3, !noalias !4
  %v1112 = load i64, ptr %slot14, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  store i32 0, ptr %p1113, align 4, !alias.scope !3, !noalias !4
  %v1114 = load i64, ptr %slot15, align 8
  %p1115 = inttoptr i64 %v1114 to ptr
  store i32 0, ptr %p1115, align 4, !alias.scope !3, !noalias !4
  %v1116 = load i64, ptr %slot16, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  store i32 0, ptr %p1117, align 4, !alias.scope !3, !noalias !4
  %v1118 = load i64, ptr %slot17, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i32 0, ptr %p1119, align 4, !alias.scope !3, !noalias !4
  %v1120 = load i64, ptr %slot18, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  store i32 0, ptr %p1121, align 4, !alias.scope !3, !noalias !4
  %v1122 = load i64, ptr %slot19, align 8
  %p1123 = inttoptr i64 %v1122 to ptr
  store i32 0, ptr %p1123, align 4, !alias.scope !3, !noalias !4
  %v1124 = load i64, ptr %slot20, align 8
  %p1125 = inttoptr i64 %v1124 to ptr
  store i32 0, ptr %p1125, align 4, !alias.scope !3, !noalias !4
  %v1126 = load i64, ptr %slot21, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  store i32 0, ptr %p1127, align 4, !alias.scope !3, !noalias !4
  %v1128 = load i64, ptr %slot22, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  store i32 0, ptr %p1129, align 4, !alias.scope !3, !noalias !4
  %v1130 = load i64, ptr %slot5, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  store i32 2, ptr %p1131, align 4, !alias.scope !3, !noalias !4
  %v1132 = load i64, ptr %slot7, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  store i32 2, ptr %p1133, align 4, !alias.scope !3, !noalias !4
  %v1134 = load i64, ptr %slot9, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  store i32 2, ptr %p1135, align 4, !alias.scope !3, !noalias !4
  %v1136 = load i64, ptr %slot11, align 8
  %p1137 = inttoptr i64 %v1136 to ptr
  store i32 2, ptr %p1137, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1138 = load i64, ptr %slot36, align 8
  %p1139 = inttoptr i64 %v1138 to ptr
  store i64 0, ptr %p1139, align 8, !alias.scope !3, !noalias !4
  %v1140 = load i64, ptr %slot36, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i64, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1142, ptr %slot43, align 8
  %v1143 = load i64, ptr %slot43, align 8
  %cmp1144 = icmp sge i64 %v1143, 0
  %cv1145 = zext i1 %cmp1144 to i64
  store i64 %cv1145, ptr %slot44, align 8
  %v1146 = load i64, ptr %slot44, align 8
  %cond1147 = icmp ne i64 %v1146, 0
  br i1 %cond1147, label %bb_success6, label %bb_failed6
bb_failed6:
  %v1148 = load i64, ptr %slot1, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1149) nomerge, !dbg !112
  unreachable
bb_success6:
  %v1150 = load i64, ptr %slot41, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %p1152 = inttoptr i64 ptrtoint (ptr @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec to i64) to ptr
  %v1153 = load i64, ptr %slot43, align 8
  %call1154 = call ptr @myl_native_list_new(ptr %p1151, ptr %p1152, i64 %v1153) nomerge, !dbg !112
  %calladdr1155 = ptrtoint ptr %call1154 to i64
  store i64 %calladdr1155, ptr %slot45, align 8
  %v1156 = load i64, ptr %slot45, align 8
  %cond1157 = icmp ne i64 %v1156, 0
  br i1 %cond1157, label %bb_success8, label %bb_failed8
bb_failed8:
  %v1158 = load i64, ptr %slot1, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1159) nomerge, !dbg !112
  unreachable
bb_success8:
  %v1160 = load i64, ptr %slot45, align 8
  %v1161 = load i64, ptr %slot36, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  store i64 %v1160, ptr %p1162, align 8, !alias.scope !3, !noalias !4
  %v1163 = load i64, ptr %slot36, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  %ld1165 = load i64, ptr %p1164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1165, ptr %slot46, align 8
  %v1166 = load i64, ptr %slot46, align 8
  %v1167 = load i64, ptr %slot27, align 8
  %p1168 = inttoptr i64 %v1167 to ptr
  store i64 %v1166, ptr %p1168, align 8, !alias.scope !3, !noalias !4
  %v1169 = load i64, ptr %slot27, align 8
  store i64 %v1169, ptr %slot47, align 8
  %v1170 = load i64, ptr %slot31, align 8
  store i64 %v1170, ptr %slot48, align 8
  %v1171 = load i64, ptr %slot47, align 8
  %v1172 = load i64, ptr %slot48, align 8
  %p1173 = inttoptr i64 %v1171 to ptr
  %p1174 = inttoptr i64 %v1172 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1174, ptr %p1173, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1175 = load i64, ptr %slot21, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  store i32 2, ptr %p1176, align 4, !alias.scope !3, !noalias !4
  %v1177 = load i64, ptr %slot20, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  store i32 1, ptr %p1178, align 4, !alias.scope !3, !noalias !4
  %v1179 = load i64, ptr %slot23, align 8
  store i64 %v1179, ptr %slot49, align 8
  %v1180 = load i64, ptr %slot31, align 8
  store i64 %v1180, ptr %slot50, align 8
  %v1181 = load i64, ptr %slot50, align 8
  %v1182 = load i64, ptr %slot49, align 8
  %p1183 = inttoptr i64 %v1181 to ptr
  %p1184 = inttoptr i64 %v1182 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1184, ptr %p1183, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1185 = load i64, ptr %slot13, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  store i32 2, ptr %p1186, align 4, !alias.scope !3, !noalias !4
  %v1187 = load i64, ptr %slot21, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i32, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1189, ptr %slot51, align 8
  %v1190 = load i32, ptr %slot51, align 8
  %v1191 = load i64, ptr %slot13, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  store i32 %v1190, ptr %p1192, align 4, !alias.scope !3, !noalias !4
  %v1193 = load i64, ptr %slot20, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i32 0, ptr %p1194, align 4, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot12, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  store i32 1, ptr %p1196, align 4, !alias.scope !3, !noalias !4
  %v1197 = load i64, ptr %slot49, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  %ld1199 = load i64, ptr %p1198, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1199, ptr %slot52, align 8
  %v1200 = load i64, ptr %slot52, align 8
  %v1201 = load i64, ptr %slot36, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  store i64 %v1200, ptr %p1202, align 8, !alias.scope !3, !noalias !4
  %v1203 = load i64, ptr %slot36, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  %ld1205 = load i64, ptr %p1204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1205, ptr %slot53, align 8
  %v1206 = load i64, ptr %slot53, align 8
  %v1207 = load i64, ptr %slot27, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  store i64 %v1206, ptr %p1208, align 8, !alias.scope !3, !noalias !4
  %v1209 = load i64, ptr %slot27, align 8
  store i64 %v1209, ptr %slot54, align 8
  %v1210 = load i64, ptr %slot12, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  %ld1212 = load i32, ptr %p1211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1212, ptr %slot55, align 8
  %v1213 = load i64, ptr %slot13, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %ld1215 = load i32, ptr %p1214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1215, ptr %slot56, align 8
  %v1216 = load i32, ptr %slot56, align 8
  %op1217 = and i32 %v1216, 24
  store i32 %op1217, ptr %slot56, align 8
  %v1218 = load i32, ptr %slot56, align 8
  %cmp1219 = icmp eq i32 %v1218, 0
  %cv1220 = zext i1 %cmp1219 to i32
  store i32 %cv1220, ptr %slot57, align 8
  %v1221 = load i32, ptr %slot55, align 8
  %v1222 = load i32, ptr %slot57, align 8
  %op1223 = and i32 %v1221, %v1222
  store i32 %op1223, ptr %slot58, align 8
  %v1224 = load i32, ptr %slot58, align 8
  %cv1225 = zext i32 %v1224 to i64
  %cond1226 = icmp ne i64 %cv1225, 0
  br i1 %cond1226, label %bb_rcprivateown31, label %bb_rcprivateloan31
bb_rcprivateown31:
  %v1227 = load i64, ptr %slot31, align 8
  store i64 %v1227, ptr %slot59, align 8
  %v1228 = load i64, ptr %slot42, align 8
  store i64 %v1228, ptr %slot60, align 8
  %v1229 = load i64, ptr %slot54, align 8
  %v1230 = load i64, ptr %slot59, align 8
  %op1231 = sub i64 %v1229, %v1230
  store i64 %op1231, ptr %slot61, align 8
  %v1232 = load i64, ptr %slot59, align 8
  %v1233 = load i64, ptr %slot54, align 8
  %op1234 = sub i64 %v1232, %v1233
  store i64 %op1234, ptr %slot62, align 8
  %v1235 = load i64, ptr %slot61, align 8
  %cmp1236 = icmp ult i64 %v1235, 8
  %cv1237 = zext i1 %cmp1236 to i32
  store i32 %cv1237, ptr %slot63, align 8
  %v1238 = load i64, ptr %slot62, align 8
  %cmp1239 = icmp ult i64 %v1238, 8
  %cv1240 = zext i1 %cmp1239 to i32
  store i32 %cv1240, ptr %slot64, align 8
  %v1241 = load i32, ptr %slot63, align 8
  %v1242 = load i32, ptr %slot64, align 8
  %op1243 = or i32 %v1241, %v1242
  store i32 %op1243, ptr %slot65, align 8
  %v1244 = load i32, ptr %slot65, align 8
  %cv1245 = zext i32 %v1244 to i64
  %cond1246 = icmp ne i64 %cv1245, 0
  br i1 %cond1246, label %bb_rcmoveslow34, label %bb_rcmovecheck34
bb_rcmovecheck34:
  %v1247 = load i64, ptr %slot54, align 8
  %p1249 = inttoptr i64 %v1247 to ptr
  %gep1250 = getelementptr i8, ptr %p1249, i64 0
  %op1248 = ptrtoint ptr %gep1250 to i64
  store i64 %op1248, ptr %slot66, align 8
  %v1251 = load i64, ptr %slot66, align 8
  %p1252 = inttoptr i64 %v1251 to ptr
  %ld1253 = load i64, ptr %p1252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1253, ptr %slot67, align 8
  %v1254 = load i64, ptr %slot67, align 8
  %cmp1255 = icmp ne i64 %v1254, 0
  %cv1256 = zext i1 %cmp1255 to i32
  store i32 %cv1256, ptr %slot68, align 8
  %v1257 = load i32, ptr %slot68, align 8
  %cv1258 = zext i32 %v1257 to i64
  %cond1259 = icmp ne i64 %cv1258, 0
  br i1 %cond1259, label %bb_rcmoveheader42, label %bb_rcmovenext42
bb_rcmoveheader42:
  %v1260 = load i64, ptr %slot67, align 8
  %op1261 = sub i64 %v1260, 16
  store i64 %op1261, ptr %slot69, align 8
  %v1262 = load i64, ptr %slot67, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %rgep1264 = getelementptr i8, ptr %p1263, i64 -16
  %ld1265 = load i64, ptr %rgep1264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1265, ptr %slot70, align 8
  %v1266 = load i64, ptr %slot70, align 8
  %op1267 = and i64 %v1266, 5764607523034234881
  store i64 %op1267, ptr %slot71, align 8
  %v1268 = load i64, ptr %slot71, align 8
  %cmp1269 = icmp ne i64 %v1268, 0
  %cv1270 = zext i1 %cmp1269 to i32
  store i32 %cv1270, ptr %slot72, align 8
  %v1271 = load i32, ptr %slot72, align 8
  %cv1272 = zext i32 %v1271 to i64
  %cond1273 = icmp ne i64 %cv1272, 0
  br i1 %cond1273, label %bb_rcmoveslow34, label %bb_rcmovenext42
bb_rcmovenext42:
  %v1274 = load i64, ptr %slot54, align 8
  %v1275 = load i64, ptr %slot59, align 8
  %p1276 = inttoptr i64 %v1274 to ptr
  %p1277 = inttoptr i64 %v1275 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1277, ptr %p1276, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot54, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  store i64 0, ptr %p1279, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved34
bb_rcmoveslow34:
  %v1280 = load i64, ptr %slot41, align 8
  %v1281 = load i64, ptr %slot59, align 8
  %v1282 = load i64, ptr %slot54, align 8
  %v1283 = load i64, ptr %slot60, align 8
  %cv1284 = trunc i64 %v1283 to i32
  %call1285 = call i32 @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_take(i64 %v1280, i64 %v1281, i64 %v1282, i32 %cv1284) nomerge, !dbg !114
  store i32 %call1285, ptr %slot73, align 8
  %v1286 = load i32, ptr %slot73, align 8
  %cv1287 = zext i32 %v1286 to i64
  %cond1288 = icmp ne i64 %cv1287, 0
  br i1 %cond1288, label %bb_rcsuccess49, label %bb_rcfailure49
bb_rcfailure49:
  %v1289 = load i64, ptr %slot41, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  %call1291 = call i32 @myl_rc_take_failure(ptr %p1290) nomerge, !dbg !114
  store i32 %call1291, ptr %slot74, align 8
  %v1292 = load i64, ptr %slot1, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  %v1294 = load i32, ptr %slot74, align 8
  %call1295 = call i32 @myl_qbe_rc_status(ptr %p1293, i32 %v1294) nomerge, !dbg !114
  store i32 %call1295, ptr %slot75, align 8
  br label %bb_failure
bb_rcsuccess49:
  br label %bb_rcmoved34
bb_rcmoved34:
  %v1296 = load i64, ptr %slot12, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  store i32 0, ptr %p1297, align 4, !alias.scope !3, !noalias !4
  %v1298 = load i64, ptr %slot21, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  store i32 2, ptr %p1299, align 4, !alias.scope !3, !noalias !4
  %v1300 = load i64, ptr %slot20, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i32 1, ptr %p1301, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared31
bb_rcprivateloan31:
  %v1302 = load i64, ptr %slot12, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  %ld1304 = load i32, ptr %p1303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1304, ptr %slot76, align 8
  %v1305 = load i64, ptr %slot13, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %ld1307 = load i32, ptr %p1306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1307, ptr %slot77, align 8
  %v1308 = load i32, ptr %slot77, align 8
  %cmp1309 = icmp eq i32 %v1308, 16
  %cv1310 = zext i1 %cmp1309 to i32
  store i32 %cv1310, ptr %slot78, align 8
  %v1311 = load i32, ptr %slot78, align 8
  %v1312 = load i32, ptr %slot76, align 8
  %op1313 = and i32 %v1311, %v1312
  store i32 %op1313, ptr %slot78, align 8
  %v1314 = load i32, ptr %slot78, align 8
  %cv1315 = zext i32 %v1314 to i64
  %cond1316 = icmp ne i64 %cv1315, 0
  br i1 %cond1316, label %bb_rcprivatemove31, label %bb_rcprivatenew31
bb_rcprivatemove31:
  %v1317 = load i64, ptr %slot31, align 8
  store i64 %v1317, ptr %slot79, align 8
  %v1318 = load i64, ptr %slot54, align 8
  %v1319 = load i64, ptr %slot79, align 8
  %p1320 = inttoptr i64 %v1318 to ptr
  %p1321 = inttoptr i64 %v1319 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1321, ptr %p1320, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot54, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  store i64 0, ptr %p1323, align 8, !alias.scope !3, !noalias !4
  %v1324 = load i64, ptr %slot21, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  store i32 2, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  %v1326 = load i64, ptr %slot21, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  store i32 16, ptr %p1327, align 4, !alias.scope !3, !noalias !4
  %v1328 = load i64, ptr %slot20, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 1, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  %v1330 = load i64, ptr %slot12, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  store i32 0, ptr %p1331, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared31
bb_rcprivatenew31:
  %v1332 = load i64, ptr %slot31, align 8
  store i64 %v1332, ptr %slot80, align 8
  %v1333 = load i64, ptr %slot54, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  %ld1335 = load i64, ptr %p1334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1335, ptr %slot81, align 8
  %v1336 = load i64, ptr %slot81, align 8
  %cmp1337 = icmp ne i64 %v1336, 0
  %cv1338 = zext i1 %cmp1337 to i32
  store i32 %cv1338, ptr %slot82, align 8
  %v1339 = load i32, ptr %slot82, align 8
  %cv1340 = zext i32 %v1339 to i64
  %cond1341 = icmp ne i64 %cv1340, 0
  br i1 %cond1341, label %bb_rcgnn67, label %bb_rcgstore67
bb_rcgnn67:
  %v1342 = load i64, ptr %slot81, align 8
  %op1343 = sub i64 %v1342, 16
  store i64 %op1343, ptr %slot83, align 8
  %v1344 = load i64, ptr %slot81, align 8
  %p1345 = inttoptr i64 %v1344 to ptr
  %rgep1346 = getelementptr i8, ptr %p1345, i64 -16
  %ld1347 = load i64, ptr %rgep1346, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1347, ptr %slot84, align 8
  %v1348 = load i64, ptr %slot84, align 8
  %op1349 = and i64 %v1348, 4611686018427387906
  store i64 %op1349, ptr %slot85, align 8
  %v1350 = load i64, ptr %slot85, align 8
  %cmp1351 = icmp ne i64 %v1350, 0
  %cv1352 = zext i1 %cmp1351 to i32
  store i32 %cv1352, ptr %slot86, align 8
  %v1353 = load i32, ptr %slot86, align 8
  %cv1354 = zext i32 %v1353 to i64
  %cond1355 = icmp ne i64 %cv1354, 0
  br i1 %cond1355, label %bb_rcgstore67, label %bb_rcginc67
bb_rcginc67:
  %v1356 = load i64, ptr %slot81, align 8
  %op1357 = sub i64 %v1356, 24
  store i64 %op1357, ptr %slot87, align 8
  %v1358 = load i64, ptr %slot81, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  %rgep1360 = getelementptr i8, ptr %p1359, i64 -24
  %ld1361 = load i64, ptr %rgep1360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1361, ptr %slot88, align 8
  %v1362 = load i64, ptr %slot88, align 8
  %op1363 = add i64 %v1362, 1
  store i64 %op1363, ptr %slot89, align 8
  %v1364 = load i64, ptr %slot89, align 8
  %cmp1365 = icmp eq i64 %v1364, 0
  %cv1366 = zext i1 %cmp1365 to i32
  store i32 %cv1366, ptr %slot90, align 8
  %v1367 = load i32, ptr %slot90, align 8
  %cv1368 = zext i32 %v1367 to i64
  %cond1369 = icmp ne i64 %cv1368, 0
  br i1 %cond1369, label %bb_rcglimit67, label %bb_rcgcapacity67
bb_rcglimit67:
  %v1370 = load i64, ptr %slot1, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  %call1372 = call i32 @myl_qbe_rc_status(ptr %p1371, i32 2) nomerge, !dbg !114
  store i32 %call1372, ptr %slot91, align 8
  br label %bb_failure
bb_rcgcapacity67:
  %v1373 = load i64, ptr %slot89, align 8
  %v1374 = load i64, ptr %slot81, align 8
  %p1375 = inttoptr i64 %v1374 to ptr
  %rgep1376 = getelementptr i8, ptr %p1375, i64 -24
  store i64 %v1373, ptr %rgep1376, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore67
bb_rcgstore67:
  %v1377 = load i64, ptr %slot81, align 8
  %v1378 = load i64, ptr %slot80, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i64 %v1377, ptr %p1379, align 8, !alias.scope !3, !noalias !4
  %v1380 = load i64, ptr %slot21, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  store i32 2, ptr %p1381, align 4, !alias.scope !3, !noalias !4
  %v1382 = load i64, ptr %slot21, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  store i32 16, ptr %p1383, align 4, !alias.scope !3, !noalias !4
  %v1384 = load i64, ptr %slot20, align 8
  %p1385 = inttoptr i64 %v1384 to ptr
  store i32 1, ptr %p1385, align 4, !alias.scope !3, !noalias !4
  %v1386 = load i64, ptr %slot12, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  %ld1388 = load i32, ptr %p1387, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1388, ptr %slot92, align 8
  %v1389 = load i32, ptr %slot92, align 8
  %cv1390 = zext i32 %v1389 to i64
  %cond1391 = icmp ne i64 %cv1390, 0
  br i1 %cond1391, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v1392 = load i64, ptr %slot12, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  store i32 0, ptr %p1393, align 4, !alias.scope !3, !noalias !4
  %v1394 = load i64, ptr %slot23, align 8
  store i64 %v1394, ptr %slot93, align 8
  %v1395 = load i64, ptr %slot13, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  %ld1397 = load i32, ptr %p1396, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1397, ptr %slot94, align 8
  %v1398 = load i32, ptr %slot94, align 8
  %op1399 = and i32 %v1398, 28
  store i32 %op1399, ptr %slot95, align 8
  %v1400 = load i32, ptr %slot95, align 8
  %cv1401 = zext i32 %v1400 to i64
  %cond1402 = icmp ne i64 %cv1401, 0
  br i1 %cond1402, label %bb_rcslotrole83, label %bb_rcslotowner83
bb_rcslotrole83:
  %v1403 = load i64, ptr %slot41, align 8
  store i64 %v1403, ptr %slot96, align 8
  %v1404 = load i64, ptr %slot93, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  %ld1406 = load i64, ptr %p1405, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1406, ptr %slot97, align 8
  %v1407 = load i64, ptr %slot97, align 8
  %cmp1408 = icmp ne i64 %v1407, 0
  %cv1409 = zext i1 %cmp1408 to i32
  store i32 %cv1409, ptr %slot98, align 8
  %v1410 = load i32, ptr %slot98, align 8
  %cv1411 = zext i32 %v1410 to i64
  %cond1412 = icmp ne i64 %cv1411, 0
  br i1 %cond1412, label %bb_rcgnn99, label %bb_rcgdone99
bb_rcgnn99:
  %v1413 = load i64, ptr %slot97, align 8
  %op1414 = sub i64 %v1413, 16
  store i64 %op1414, ptr %slot99, align 8
  %v1415 = load i64, ptr %slot97, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  %rgep1417 = getelementptr i8, ptr %p1416, i64 -16
  %ld1418 = load i64, ptr %rgep1417, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1418, ptr %slot100, align 8
  %v1419 = load i64, ptr %slot100, align 8
  %op1420 = and i64 %v1419, 4611686018427387906
  store i64 %op1420, ptr %slot101, align 8
  %v1421 = load i64, ptr %slot101, align 8
  %cmp1422 = icmp ne i64 %v1421, 0
  %cv1423 = zext i1 %cmp1422 to i32
  store i32 %cv1423, ptr %slot102, align 8
  %v1424 = load i32, ptr %slot102, align 8
  %cv1425 = zext i32 %v1424 to i64
  %cond1426 = icmp ne i64 %cv1425, 0
  br i1 %cond1426, label %bb_rcgclear99, label %bb_rcgcounted99
bb_rcgcounted99:
  %v1427 = load i64, ptr %slot97, align 8
  %op1428 = sub i64 %v1427, 24
  store i64 %op1428, ptr %slot103, align 8
  %v1429 = load i64, ptr %slot97, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %rgep1431 = getelementptr i8, ptr %p1430, i64 -24
  %ld1432 = load i64, ptr %rgep1431, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1432, ptr %slot104, align 8
  %v1433 = load i64, ptr %slot104, align 8
  %op1434 = sub i64 %v1433, 1
  store i64 %op1434, ptr %slot105, align 8
  %v1435 = load i64, ptr %slot105, align 8
  %cmp1436 = icmp eq i64 %v1435, 0
  %cv1437 = zext i1 %cmp1436 to i32
  store i32 %cv1437, ptr %slot106, align 8
  %v1438 = load i32, ptr %slot106, align 8
  %cv1439 = zext i32 %v1438 to i64
  %cond1440 = icmp ne i64 %cv1439, 0
  br i1 %cond1440, label %bb_rcglast99, label %bb_rcgdec99
bb_rcglast99:
  %v1441 = load i64, ptr %slot97, align 8
  %op1442 = sub i64 %v1441, 32
  store i64 %op1442, ptr %slot107, align 8
  %v1443 = load i64, ptr %slot97, align 8
  %p1444 = inttoptr i64 %v1443 to ptr
  %rgep1445 = getelementptr i8, ptr %p1444, i64 -32
  %ld1446 = load i64, ptr %rgep1445, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1446, ptr %slot108, align 8
  %v1447 = load i64, ptr %slot108, align 8
  %cmp1448 = icmp ne i64 %v1447, 0
  %cv1449 = zext i1 %cmp1448 to i32
  store i32 %cv1449, ptr %slot109, align 8
  %v1450 = load i32, ptr %slot109, align 8
  %cv1451 = zext i32 %v1450 to i64
  %cond1452 = icmp ne i64 %cv1451, 0
  br i1 %cond1452, label %bb_rcgdec99, label %bb_rcgslow99
bb_rcgslow99:
  %v1453 = load i64, ptr %slot96, align 8
  %v1454 = load i64, ptr %slot93, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_unloan(i64 %v1453, i64 %v1454) nomerge, !dbg !114
  br label %bb_rcgdone99
bb_rcgdec99:
  %v1455 = load i64, ptr %slot105, align 8
  %v1456 = load i64, ptr %slot97, align 8
  %p1457 = inttoptr i64 %v1456 to ptr
  %rgep1458 = getelementptr i8, ptr %p1457, i64 -24
  store i64 %v1455, ptr %rgep1458, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear99
bb_rcgclear99:
  %v1459 = load i64, ptr %slot93, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  store i64 0, ptr %p1460, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone99
bb_rcgdone99:
  br label %bb_rcslotdone83
bb_rcslotowner83:
  %v1461 = load i64, ptr %slot41, align 8
  store i64 %v1461, ptr %slot110, align 8
  %v1462 = load i64, ptr %slot93, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %ld1464 = load i64, ptr %p1463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1464, ptr %slot111, align 8
  %v1465 = load i64, ptr %slot111, align 8
  %cmp1466 = icmp ne i64 %v1465, 0
  %cv1467 = zext i1 %cmp1466 to i32
  store i32 %cv1467, ptr %slot112, align 8
  %v1468 = load i32, ptr %slot112, align 8
  %cv1469 = zext i32 %v1468 to i64
  %cond1470 = icmp ne i64 %cv1469, 0
  br i1 %cond1470, label %bb_rcgnn114, label %bb_rcgdone114
bb_rcgnn114:
  %v1471 = load i64, ptr %slot111, align 8
  %op1472 = sub i64 %v1471, 16
  store i64 %op1472, ptr %slot113, align 8
  %v1473 = load i64, ptr %slot111, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  %rgep1475 = getelementptr i8, ptr %p1474, i64 -16
  %ld1476 = load i64, ptr %rgep1475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1476, ptr %slot114, align 8
  %v1477 = load i64, ptr %slot114, align 8
  %op1478 = and i64 %v1477, 4611686018427387906
  store i64 %op1478, ptr %slot115, align 8
  %v1479 = load i64, ptr %slot115, align 8
  %cmp1480 = icmp ne i64 %v1479, 0
  %cv1481 = zext i1 %cmp1480 to i32
  store i32 %cv1481, ptr %slot116, align 8
  %v1482 = load i32, ptr %slot116, align 8
  %cv1483 = zext i32 %v1482 to i64
  %cond1484 = icmp ne i64 %cv1483, 0
  br i1 %cond1484, label %bb_rcgclear114, label %bb_rcgcounted114
bb_rcgcounted114:
  %v1485 = load i64, ptr %slot111, align 8
  %op1486 = sub i64 %v1485, 32
  store i64 %op1486, ptr %slot117, align 8
  %v1487 = load i64, ptr %slot111, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  %rgep1489 = getelementptr i8, ptr %p1488, i64 -32
  %ld1490 = load i64, ptr %rgep1489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1490, ptr %slot118, align 8
  %v1491 = load i64, ptr %slot118, align 8
  %op1492 = sub i64 %v1491, 1
  store i64 %op1492, ptr %slot119, align 8
  %v1493 = load i64, ptr %slot119, align 8
  %cmp1494 = icmp eq i64 %v1493, 0
  %cv1495 = zext i1 %cmp1494 to i32
  store i32 %cv1495, ptr %slot120, align 8
  %v1496 = load i32, ptr %slot120, align 8
  %cv1497 = zext i32 %v1496 to i64
  %cond1498 = icmp ne i64 %cv1497, 0
  br i1 %cond1498, label %bb_rcglast114, label %bb_rcgdec114
bb_rcglast114:
  %v1499 = load i64, ptr %slot111, align 8
  %op1500 = sub i64 %v1499, 24
  store i64 %op1500, ptr %slot121, align 8
  %v1501 = load i64, ptr %slot111, align 8
  %p1502 = inttoptr i64 %v1501 to ptr
  %rgep1503 = getelementptr i8, ptr %p1502, i64 -24
  %ld1504 = load i64, ptr %rgep1503, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1504, ptr %slot122, align 8
  %v1505 = load i64, ptr %slot122, align 8
  %cmp1506 = icmp ne i64 %v1505, 0
  %cv1507 = zext i1 %cmp1506 to i32
  store i32 %cv1507, ptr %slot123, align 8
  %v1508 = load i32, ptr %slot123, align 8
  %cv1509 = zext i32 %v1508 to i64
  %cond1510 = icmp ne i64 %cv1509, 0
  br i1 %cond1510, label %bb_rcgdec114, label %bb_rcgslow114
bb_rcgslow114:
  %v1511 = load i64, ptr %slot110, align 8
  %v1512 = load i64, ptr %slot93, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64 %v1511, i64 %v1512) nomerge, !dbg !114
  br label %bb_rcgdone114
bb_rcgdec114:
  %v1513 = load i64, ptr %slot119, align 8
  %v1514 = load i64, ptr %slot111, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %rgep1516 = getelementptr i8, ptr %p1515, i64 -32
  store i64 %v1513, ptr %rgep1516, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear114
bb_rcgclear114:
  %v1517 = load i64, ptr %slot93, align 8
  %p1518 = inttoptr i64 %v1517 to ptr
  store i64 0, ptr %p1518, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone114
bb_rcgdone114:
  br label %bb_rcslotdone83
bb_rcslotdone83:
  br label %bb_rcprivateprepared31
bb_rcprivateprepared31:
  %v1519 = load i64, ptr %slot4, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  %ld1521 = load i32, ptr %p1520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1521, ptr %slot124, align 8
  %v1522 = load i32, ptr %slot124, align 8
  %cv1523 = zext i32 %v1522 to i64
  %cond1524 = icmp ne i64 %cv1523, 0
  br i1 %cond1524, label %bb_rcslotdrop121, label %bb_rcslotdone121
bb_rcslotdrop121:
  %v1525 = load i64, ptr %slot4, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  store i32 0, ptr %p1526, align 4, !alias.scope !3, !noalias !4
  %v1527 = load i64, ptr %slot32, align 8
  store i64 %v1527, ptr %slot125, align 8
  %v1528 = load i64, ptr %slot5, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  %ld1530 = load i32, ptr %p1529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1530, ptr %slot126, align 8
  %v1531 = load i32, ptr %slot126, align 8
  %op1532 = and i32 %v1531, 28
  store i32 %op1532, ptr %slot127, align 8
  %v1533 = load i32, ptr %slot127, align 8
  %cv1534 = zext i32 %v1533 to i64
  %cond1535 = icmp ne i64 %cv1534, 0
  br i1 %cond1535, label %bb_rcslotrole121, label %bb_rcslotowner121
bb_rcslotrole121:
  %v1536 = load i64, ptr %slot41, align 8
  store i64 %v1536, ptr %slot128, align 8
  %v1537 = load i64, ptr %slot125, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  %ld1539 = load i64, ptr %p1538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1539, ptr %slot129, align 8
  %v1540 = load i64, ptr %slot129, align 8
  %cmp1541 = icmp ne i64 %v1540, 0
  %cv1542 = zext i1 %cmp1541 to i32
  store i32 %cv1542, ptr %slot130, align 8
  %v1543 = load i32, ptr %slot130, align 8
  %cv1544 = zext i32 %v1543 to i64
  %cond1545 = icmp ne i64 %cv1544, 0
  br i1 %cond1545, label %bb_rcgnn137, label %bb_rcgdone137
bb_rcgnn137:
  %v1546 = load i64, ptr %slot129, align 8
  %op1547 = sub i64 %v1546, 16
  store i64 %op1547, ptr %slot131, align 8
  %v1548 = load i64, ptr %slot129, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  %rgep1550 = getelementptr i8, ptr %p1549, i64 -16
  %ld1551 = load i64, ptr %rgep1550, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1551, ptr %slot132, align 8
  %v1552 = load i64, ptr %slot132, align 8
  %op1553 = and i64 %v1552, 4611686018427387906
  store i64 %op1553, ptr %slot133, align 8
  %v1554 = load i64, ptr %slot133, align 8
  %cmp1555 = icmp ne i64 %v1554, 0
  %cv1556 = zext i1 %cmp1555 to i32
  store i32 %cv1556, ptr %slot134, align 8
  %v1557 = load i32, ptr %slot134, align 8
  %cv1558 = zext i32 %v1557 to i64
  %cond1559 = icmp ne i64 %cv1558, 0
  br i1 %cond1559, label %bb_rcgclear137, label %bb_rcgcounted137
bb_rcgcounted137:
  %v1560 = load i64, ptr %slot129, align 8
  %op1561 = sub i64 %v1560, 24
  store i64 %op1561, ptr %slot135, align 8
  %v1562 = load i64, ptr %slot129, align 8
  %p1563 = inttoptr i64 %v1562 to ptr
  %rgep1564 = getelementptr i8, ptr %p1563, i64 -24
  %ld1565 = load i64, ptr %rgep1564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1565, ptr %slot136, align 8
  %v1566 = load i64, ptr %slot136, align 8
  %op1567 = sub i64 %v1566, 1
  store i64 %op1567, ptr %slot137, align 8
  %v1568 = load i64, ptr %slot137, align 8
  %cmp1569 = icmp eq i64 %v1568, 0
  %cv1570 = zext i1 %cmp1569 to i32
  store i32 %cv1570, ptr %slot138, align 8
  %v1571 = load i32, ptr %slot138, align 8
  %cv1572 = zext i32 %v1571 to i64
  %cond1573 = icmp ne i64 %cv1572, 0
  br i1 %cond1573, label %bb_rcglast137, label %bb_rcgdec137
bb_rcglast137:
  %v1574 = load i64, ptr %slot129, align 8
  %op1575 = sub i64 %v1574, 32
  store i64 %op1575, ptr %slot139, align 8
  %v1576 = load i64, ptr %slot129, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  %rgep1578 = getelementptr i8, ptr %p1577, i64 -32
  %ld1579 = load i64, ptr %rgep1578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1579, ptr %slot140, align 8
  %v1580 = load i64, ptr %slot140, align 8
  %cmp1581 = icmp ne i64 %v1580, 0
  %cv1582 = zext i1 %cmp1581 to i32
  store i32 %cv1582, ptr %slot141, align 8
  %v1583 = load i32, ptr %slot141, align 8
  %cv1584 = zext i32 %v1583 to i64
  %cond1585 = icmp ne i64 %cv1584, 0
  br i1 %cond1585, label %bb_rcgdec137, label %bb_rcgslow137
bb_rcgslow137:
  %v1586 = load i64, ptr %slot128, align 8
  %v1587 = load i64, ptr %slot125, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_unloan(i64 %v1586, i64 %v1587) nomerge, !dbg !114
  br label %bb_rcgdone137
bb_rcgdec137:
  %v1588 = load i64, ptr %slot137, align 8
  %v1589 = load i64, ptr %slot129, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  %rgep1591 = getelementptr i8, ptr %p1590, i64 -24
  store i64 %v1588, ptr %rgep1591, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear137
bb_rcgclear137:
  %v1592 = load i64, ptr %slot125, align 8
  %p1593 = inttoptr i64 %v1592 to ptr
  store i64 0, ptr %p1593, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone137
bb_rcgdone137:
  br label %bb_rcslotdone121
bb_rcslotowner121:
  %v1594 = load i64, ptr %slot41, align 8
  store i64 %v1594, ptr %slot142, align 8
  %v1595 = load i64, ptr %slot125, align 8
  %p1596 = inttoptr i64 %v1595 to ptr
  %ld1597 = load i64, ptr %p1596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1597, ptr %slot143, align 8
  %v1598 = load i64, ptr %slot143, align 8
  %cmp1599 = icmp ne i64 %v1598, 0
  %cv1600 = zext i1 %cmp1599 to i32
  store i32 %cv1600, ptr %slot144, align 8
  %v1601 = load i32, ptr %slot144, align 8
  %cv1602 = zext i32 %v1601 to i64
  %cond1603 = icmp ne i64 %cv1602, 0
  br i1 %cond1603, label %bb_rcgnn152, label %bb_rcgdone152
bb_rcgnn152:
  %v1604 = load i64, ptr %slot143, align 8
  %op1605 = sub i64 %v1604, 16
  store i64 %op1605, ptr %slot145, align 8
  %v1606 = load i64, ptr %slot143, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %rgep1608 = getelementptr i8, ptr %p1607, i64 -16
  %ld1609 = load i64, ptr %rgep1608, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1609, ptr %slot146, align 8
  %v1610 = load i64, ptr %slot146, align 8
  %op1611 = and i64 %v1610, 4611686018427387906
  store i64 %op1611, ptr %slot147, align 8
  %v1612 = load i64, ptr %slot147, align 8
  %cmp1613 = icmp ne i64 %v1612, 0
  %cv1614 = zext i1 %cmp1613 to i32
  store i32 %cv1614, ptr %slot148, align 8
  %v1615 = load i32, ptr %slot148, align 8
  %cv1616 = zext i32 %v1615 to i64
  %cond1617 = icmp ne i64 %cv1616, 0
  br i1 %cond1617, label %bb_rcgclear152, label %bb_rcgcounted152
bb_rcgcounted152:
  %v1618 = load i64, ptr %slot143, align 8
  %op1619 = sub i64 %v1618, 32
  store i64 %op1619, ptr %slot149, align 8
  %v1620 = load i64, ptr %slot143, align 8
  %p1621 = inttoptr i64 %v1620 to ptr
  %rgep1622 = getelementptr i8, ptr %p1621, i64 -32
  %ld1623 = load i64, ptr %rgep1622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1623, ptr %slot150, align 8
  %v1624 = load i64, ptr %slot150, align 8
  %op1625 = sub i64 %v1624, 1
  store i64 %op1625, ptr %slot151, align 8
  %v1626 = load i64, ptr %slot151, align 8
  %cmp1627 = icmp eq i64 %v1626, 0
  %cv1628 = zext i1 %cmp1627 to i32
  store i32 %cv1628, ptr %slot152, align 8
  %v1629 = load i32, ptr %slot152, align 8
  %cv1630 = zext i32 %v1629 to i64
  %cond1631 = icmp ne i64 %cv1630, 0
  br i1 %cond1631, label %bb_rcglast152, label %bb_rcgdec152
bb_rcglast152:
  %v1632 = load i64, ptr %slot143, align 8
  %op1633 = sub i64 %v1632, 24
  store i64 %op1633, ptr %slot153, align 8
  %v1634 = load i64, ptr %slot143, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  %rgep1636 = getelementptr i8, ptr %p1635, i64 -24
  %ld1637 = load i64, ptr %rgep1636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1637, ptr %slot154, align 8
  %v1638 = load i64, ptr %slot154, align 8
  %cmp1639 = icmp ne i64 %v1638, 0
  %cv1640 = zext i1 %cmp1639 to i32
  store i32 %cv1640, ptr %slot155, align 8
  %v1641 = load i32, ptr %slot155, align 8
  %cv1642 = zext i32 %v1641 to i64
  %cond1643 = icmp ne i64 %cv1642, 0
  br i1 %cond1643, label %bb_rcgdec152, label %bb_rcgslow152
bb_rcgslow152:
  %v1644 = load i64, ptr %slot142, align 8
  %v1645 = load i64, ptr %slot125, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64 %v1644, i64 %v1645) nomerge, !dbg !114
  br label %bb_rcgdone152
bb_rcgdec152:
  %v1646 = load i64, ptr %slot151, align 8
  %v1647 = load i64, ptr %slot143, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %rgep1649 = getelementptr i8, ptr %p1648, i64 -32
  store i64 %v1646, ptr %rgep1649, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear152
bb_rcgclear152:
  %v1650 = load i64, ptr %slot125, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  store i64 0, ptr %p1651, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone152
bb_rcgdone152:
  br label %bb_rcslotdone121
bb_rcslotdone121:
  %v1652 = load i64, ptr %slot32, align 8
  store i64 %v1652, ptr %slot156, align 8
  %v1653 = load i64, ptr %slot31, align 8
  store i64 %v1653, ptr %slot157, align 8
  %v1654 = load i64, ptr %slot157, align 8
  %v1655 = load i64, ptr %slot156, align 8
  %p1656 = inttoptr i64 %v1654 to ptr
  %p1657 = inttoptr i64 %v1655 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1657, ptr %p1656, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1658 = load i64, ptr %slot20, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  store i32 0, ptr %p1659, align 4, !alias.scope !3, !noalias !4
  %v1660 = load i64, ptr %slot5, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  store i32 2, ptr %p1661, align 4, !alias.scope !3, !noalias !4
  %v1662 = load i64, ptr %slot21, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  %ld1664 = load i32, ptr %p1663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1664, ptr %slot158, align 8
  %v1665 = load i32, ptr %slot158, align 8
  %v1666 = load i64, ptr %slot5, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i32 %v1665, ptr %p1667, align 4, !alias.scope !3, !noalias !4
  %v1668 = load i64, ptr %slot4, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  store i32 1, ptr %p1669, align 4, !alias.scope !3, !noalias !4
  %v1670 = load i64, ptr %slot32, align 8
  %p1671 = inttoptr i64 %v1670 to ptr
  %ld1672 = load i64, ptr %p1671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1672, ptr %slot159, align 8
  %v1673 = load i64, ptr %slot159, align 8
  %v1674 = load i64, ptr %slot36, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 %v1673, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot37, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  store i64 0, ptr %p1677, align 8, !alias.scope !3, !noalias !4
  %v1678 = load i64, ptr %slot37, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  %ld1680 = load i64, ptr %p1679, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1680, ptr %slot160, align 8
  %v1681 = load i64, ptr %slot160, align 8
  %cmp1682 = icmp sge i64 %v1681, 0
  %cv1683 = zext i1 %cmp1682 to i64
  store i64 %cv1683, ptr %slot161, align 8
  %v1684 = load i64, ptr %slot161, align 8
  %cond1685 = icmp ne i64 %v1684, 0
  br i1 %cond1685, label %bb_success166, label %bb_failed166
bb_failed166:
  %v1686 = load i64, ptr %slot1, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1687) nomerge, !dbg !116
  unreachable
bb_success166:
  %v1688 = load i64, ptr %slot41, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  %p1690 = inttoptr i64 ptrtoint (ptr @myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3 to i64) to ptr
  %v1691 = load i64, ptr %slot160, align 8
  %call1692 = call ptr @myl_native_list_new(ptr %p1689, ptr %p1690, i64 %v1691) nomerge, !dbg !116
  %calladdr1693 = ptrtoint ptr %call1692 to i64
  store i64 %calladdr1693, ptr %slot162, align 8
  %v1694 = load i64, ptr %slot162, align 8
  %cond1695 = icmp ne i64 %v1694, 0
  br i1 %cond1695, label %bb_success168, label %bb_failed168
bb_failed168:
  %v1696 = load i64, ptr %slot1, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1697) nomerge, !dbg !116
  unreachable
bb_success168:
  %v1698 = load i64, ptr %slot162, align 8
  %v1699 = load i64, ptr %slot37, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i64 %v1698, ptr %p1700, align 8, !alias.scope !3, !noalias !4
  %v1701 = load i64, ptr %slot37, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  %ld1703 = load i64, ptr %p1702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1703, ptr %slot163, align 8
  %v1704 = load i64, ptr %slot163, align 8
  %v1705 = load i64, ptr %slot28, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  store i64 %v1704, ptr %p1706, align 8, !alias.scope !3, !noalias !4
  %v1707 = load i64, ptr %slot28, align 8
  store i64 %v1707, ptr %slot164, align 8
  %v1708 = load i64, ptr %slot31, align 8
  store i64 %v1708, ptr %slot165, align 8
  %v1709 = load i64, ptr %slot164, align 8
  %v1710 = load i64, ptr %slot165, align 8
  %p1711 = inttoptr i64 %v1709 to ptr
  %p1712 = inttoptr i64 %v1710 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1712, ptr %p1711, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot21, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  store i32 2, ptr %p1714, align 4, !alias.scope !3, !noalias !4
  %v1715 = load i64, ptr %slot20, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 1, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot24, align 8
  store i64 %v1717, ptr %slot166, align 8
  %v1718 = load i64, ptr %slot31, align 8
  store i64 %v1718, ptr %slot167, align 8
  %v1719 = load i64, ptr %slot167, align 8
  %v1720 = load i64, ptr %slot166, align 8
  %p1721 = inttoptr i64 %v1719 to ptr
  %p1722 = inttoptr i64 %v1720 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1722, ptr %p1721, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1723 = load i64, ptr %slot15, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i32 2, ptr %p1724, align 4, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot21, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  %ld1727 = load i32, ptr %p1726, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1727, ptr %slot168, align 8
  %v1728 = load i32, ptr %slot168, align 8
  %v1729 = load i64, ptr %slot15, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i32 %v1728, ptr %p1730, align 4, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot20, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i32 0, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  %v1733 = load i64, ptr %slot14, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 1, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot166, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  %ld1737 = load i64, ptr %p1736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1737, ptr %slot169, align 8
  %v1738 = load i64, ptr %slot169, align 8
  %v1739 = load i64, ptr %slot37, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i64 %v1738, ptr %p1740, align 8, !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot37, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  %ld1743 = load i64, ptr %p1742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1743, ptr %slot170, align 8
  %v1744 = load i64, ptr %slot170, align 8
  %v1745 = load i64, ptr %slot28, align 8
  %p1746 = inttoptr i64 %v1745 to ptr
  store i64 %v1744, ptr %p1746, align 8, !alias.scope !3, !noalias !4
  %v1747 = load i64, ptr %slot28, align 8
  store i64 %v1747, ptr %slot171, align 8
  %v1748 = load i64, ptr %slot14, align 8
  %p1749 = inttoptr i64 %v1748 to ptr
  %ld1750 = load i32, ptr %p1749, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1750, ptr %slot172, align 8
  %v1751 = load i64, ptr %slot15, align 8
  %p1752 = inttoptr i64 %v1751 to ptr
  %ld1753 = load i32, ptr %p1752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1753, ptr %slot173, align 8
  %v1754 = load i32, ptr %slot173, align 8
  %op1755 = and i32 %v1754, 24
  store i32 %op1755, ptr %slot173, align 8
  %v1756 = load i32, ptr %slot173, align 8
  %cmp1757 = icmp eq i32 %v1756, 0
  %cv1758 = zext i1 %cmp1757 to i32
  store i32 %cv1758, ptr %slot174, align 8
  %v1759 = load i32, ptr %slot172, align 8
  %v1760 = load i32, ptr %slot174, align 8
  %op1761 = and i32 %v1759, %v1760
  store i32 %op1761, ptr %slot175, align 8
  %v1762 = load i32, ptr %slot175, align 8
  %cv1763 = zext i32 %v1762 to i64
  %cond1764 = icmp ne i64 %cv1763, 0
  br i1 %cond1764, label %bb_rcprivateown191, label %bb_rcprivateloan191
bb_rcprivateown191:
  %v1765 = load i64, ptr %slot31, align 8
  store i64 %v1765, ptr %slot176, align 8
  %v1766 = load i64, ptr %slot42, align 8
  store i64 %v1766, ptr %slot177, align 8
  %v1767 = load i64, ptr %slot171, align 8
  %v1768 = load i64, ptr %slot176, align 8
  %op1769 = sub i64 %v1767, %v1768
  store i64 %op1769, ptr %slot178, align 8
  %v1770 = load i64, ptr %slot176, align 8
  %v1771 = load i64, ptr %slot171, align 8
  %op1772 = sub i64 %v1770, %v1771
  store i64 %op1772, ptr %slot179, align 8
  %v1773 = load i64, ptr %slot178, align 8
  %cmp1774 = icmp ult i64 %v1773, 8
  %cv1775 = zext i1 %cmp1774 to i32
  store i32 %cv1775, ptr %slot180, align 8
  %v1776 = load i64, ptr %slot179, align 8
  %cmp1777 = icmp ult i64 %v1776, 8
  %cv1778 = zext i1 %cmp1777 to i32
  store i32 %cv1778, ptr %slot181, align 8
  %v1779 = load i32, ptr %slot180, align 8
  %v1780 = load i32, ptr %slot181, align 8
  %op1781 = or i32 %v1779, %v1780
  store i32 %op1781, ptr %slot182, align 8
  %v1782 = load i32, ptr %slot182, align 8
  %cv1783 = zext i32 %v1782 to i64
  %cond1784 = icmp ne i64 %cv1783, 0
  br i1 %cond1784, label %bb_rcmoveslow194, label %bb_rcmovecheck194
bb_rcmovecheck194:
  %v1785 = load i64, ptr %slot171, align 8
  %p1787 = inttoptr i64 %v1785 to ptr
  %gep1788 = getelementptr i8, ptr %p1787, i64 0
  %op1786 = ptrtoint ptr %gep1788 to i64
  store i64 %op1786, ptr %slot183, align 8
  %v1789 = load i64, ptr %slot183, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  %ld1791 = load i64, ptr %p1790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1791, ptr %slot184, align 8
  %v1792 = load i64, ptr %slot184, align 8
  %cmp1793 = icmp ne i64 %v1792, 0
  %cv1794 = zext i1 %cmp1793 to i32
  store i32 %cv1794, ptr %slot185, align 8
  %v1795 = load i32, ptr %slot185, align 8
  %cv1796 = zext i32 %v1795 to i64
  %cond1797 = icmp ne i64 %cv1796, 0
  br i1 %cond1797, label %bb_rcmoveheader202, label %bb_rcmovenext202
bb_rcmoveheader202:
  %v1798 = load i64, ptr %slot184, align 8
  %op1799 = sub i64 %v1798, 16
  store i64 %op1799, ptr %slot186, align 8
  %v1800 = load i64, ptr %slot184, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %rgep1802 = getelementptr i8, ptr %p1801, i64 -16
  %ld1803 = load i64, ptr %rgep1802, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1803, ptr %slot187, align 8
  %v1804 = load i64, ptr %slot187, align 8
  %op1805 = and i64 %v1804, 5764607523034234881
  store i64 %op1805, ptr %slot188, align 8
  %v1806 = load i64, ptr %slot188, align 8
  %cmp1807 = icmp ne i64 %v1806, 0
  %cv1808 = zext i1 %cmp1807 to i32
  store i32 %cv1808, ptr %slot189, align 8
  %v1809 = load i32, ptr %slot189, align 8
  %cv1810 = zext i32 %v1809 to i64
  %cond1811 = icmp ne i64 %cv1810, 0
  br i1 %cond1811, label %bb_rcmoveslow194, label %bb_rcmovenext202
bb_rcmovenext202:
  %v1812 = load i64, ptr %slot171, align 8
  %v1813 = load i64, ptr %slot176, align 8
  %p1814 = inttoptr i64 %v1812 to ptr
  %p1815 = inttoptr i64 %v1813 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1815, ptr %p1814, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1816 = load i64, ptr %slot171, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  store i64 0, ptr %p1817, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved194
bb_rcmoveslow194:
  %v1818 = load i64, ptr %slot41, align 8
  %v1819 = load i64, ptr %slot176, align 8
  %v1820 = load i64, ptr %slot171, align 8
  %v1821 = load i64, ptr %slot177, align 8
  %cv1822 = trunc i64 %v1821 to i32
  %call1823 = call i32 @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_take(i64 %v1818, i64 %v1819, i64 %v1820, i32 %cv1822) nomerge, !dbg !118
  store i32 %call1823, ptr %slot190, align 8
  %v1824 = load i32, ptr %slot190, align 8
  %cv1825 = zext i32 %v1824 to i64
  %cond1826 = icmp ne i64 %cv1825, 0
  br i1 %cond1826, label %bb_rcsuccess209, label %bb_rcfailure209
bb_rcfailure209:
  %v1827 = load i64, ptr %slot41, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  %call1829 = call i32 @myl_rc_take_failure(ptr %p1828) nomerge, !dbg !118
  store i32 %call1829, ptr %slot191, align 8
  %v1830 = load i64, ptr %slot1, align 8
  %p1831 = inttoptr i64 %v1830 to ptr
  %v1832 = load i32, ptr %slot191, align 8
  %call1833 = call i32 @myl_qbe_rc_status(ptr %p1831, i32 %v1832) nomerge, !dbg !118
  store i32 %call1833, ptr %slot192, align 8
  br label %bb_failure
bb_rcsuccess209:
  br label %bb_rcmoved194
bb_rcmoved194:
  %v1834 = load i64, ptr %slot14, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  store i32 0, ptr %p1835, align 4, !alias.scope !3, !noalias !4
  %v1836 = load i64, ptr %slot21, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  store i32 2, ptr %p1837, align 4, !alias.scope !3, !noalias !4
  %v1838 = load i64, ptr %slot20, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  store i32 1, ptr %p1839, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared191
bb_rcprivateloan191:
  %v1840 = load i64, ptr %slot14, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  %ld1842 = load i32, ptr %p1841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1842, ptr %slot193, align 8
  %v1843 = load i64, ptr %slot15, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  %ld1845 = load i32, ptr %p1844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1845, ptr %slot194, align 8
  %v1846 = load i32, ptr %slot194, align 8
  %cmp1847 = icmp eq i32 %v1846, 16
  %cv1848 = zext i1 %cmp1847 to i32
  store i32 %cv1848, ptr %slot195, align 8
  %v1849 = load i32, ptr %slot195, align 8
  %v1850 = load i32, ptr %slot193, align 8
  %op1851 = and i32 %v1849, %v1850
  store i32 %op1851, ptr %slot195, align 8
  %v1852 = load i32, ptr %slot195, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcprivatemove191, label %bb_rcprivatenew191
bb_rcprivatemove191:
  %v1855 = load i64, ptr %slot31, align 8
  store i64 %v1855, ptr %slot196, align 8
  %v1856 = load i64, ptr %slot171, align 8
  %v1857 = load i64, ptr %slot196, align 8
  %p1858 = inttoptr i64 %v1856 to ptr
  %p1859 = inttoptr i64 %v1857 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1859, ptr %p1858, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1860 = load i64, ptr %slot171, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  store i64 0, ptr %p1861, align 8, !alias.scope !3, !noalias !4
  %v1862 = load i64, ptr %slot21, align 8
  %p1863 = inttoptr i64 %v1862 to ptr
  store i32 2, ptr %p1863, align 4, !alias.scope !3, !noalias !4
  %v1864 = load i64, ptr %slot21, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  store i32 16, ptr %p1865, align 4, !alias.scope !3, !noalias !4
  %v1866 = load i64, ptr %slot20, align 8
  %p1867 = inttoptr i64 %v1866 to ptr
  store i32 1, ptr %p1867, align 4, !alias.scope !3, !noalias !4
  %v1868 = load i64, ptr %slot14, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  store i32 0, ptr %p1869, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared191
bb_rcprivatenew191:
  %v1870 = load i64, ptr %slot31, align 8
  store i64 %v1870, ptr %slot197, align 8
  %v1871 = load i64, ptr %slot171, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  %ld1873 = load i64, ptr %p1872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1873, ptr %slot198, align 8
  %v1874 = load i64, ptr %slot198, align 8
  %cmp1875 = icmp ne i64 %v1874, 0
  %cv1876 = zext i1 %cmp1875 to i32
  store i32 %cv1876, ptr %slot199, align 8
  %v1877 = load i32, ptr %slot199, align 8
  %cv1878 = zext i32 %v1877 to i64
  %cond1879 = icmp ne i64 %cv1878, 0
  br i1 %cond1879, label %bb_rcgnn227, label %bb_rcgstore227
bb_rcgnn227:
  %v1880 = load i64, ptr %slot198, align 8
  %op1881 = sub i64 %v1880, 16
  store i64 %op1881, ptr %slot200, align 8
  %v1882 = load i64, ptr %slot198, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  %rgep1884 = getelementptr i8, ptr %p1883, i64 -16
  %ld1885 = load i64, ptr %rgep1884, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1885, ptr %slot201, align 8
  %v1886 = load i64, ptr %slot201, align 8
  %op1887 = and i64 %v1886, 4611686018427387906
  store i64 %op1887, ptr %slot202, align 8
  %v1888 = load i64, ptr %slot202, align 8
  %cmp1889 = icmp ne i64 %v1888, 0
  %cv1890 = zext i1 %cmp1889 to i32
  store i32 %cv1890, ptr %slot203, align 8
  %v1891 = load i32, ptr %slot203, align 8
  %cv1892 = zext i32 %v1891 to i64
  %cond1893 = icmp ne i64 %cv1892, 0
  br i1 %cond1893, label %bb_rcgstore227, label %bb_rcginc227
bb_rcginc227:
  %v1894 = load i64, ptr %slot198, align 8
  %op1895 = sub i64 %v1894, 24
  store i64 %op1895, ptr %slot204, align 8
  %v1896 = load i64, ptr %slot198, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  %rgep1898 = getelementptr i8, ptr %p1897, i64 -24
  %ld1899 = load i64, ptr %rgep1898, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1899, ptr %slot205, align 8
  %v1900 = load i64, ptr %slot205, align 8
  %op1901 = add i64 %v1900, 1
  store i64 %op1901, ptr %slot206, align 8
  %v1902 = load i64, ptr %slot206, align 8
  %cmp1903 = icmp eq i64 %v1902, 0
  %cv1904 = zext i1 %cmp1903 to i32
  store i32 %cv1904, ptr %slot207, align 8
  %v1905 = load i32, ptr %slot207, align 8
  %cv1906 = zext i32 %v1905 to i64
  %cond1907 = icmp ne i64 %cv1906, 0
  br i1 %cond1907, label %bb_rcglimit227, label %bb_rcgcapacity227
bb_rcglimit227:
  %v1908 = load i64, ptr %slot1, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  %call1910 = call i32 @myl_qbe_rc_status(ptr %p1909, i32 2) nomerge, !dbg !118
  store i32 %call1910, ptr %slot208, align 8
  br label %bb_failure
bb_rcgcapacity227:
  %v1911 = load i64, ptr %slot206, align 8
  %v1912 = load i64, ptr %slot198, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  %rgep1914 = getelementptr i8, ptr %p1913, i64 -24
  store i64 %v1911, ptr %rgep1914, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore227
bb_rcgstore227:
  %v1915 = load i64, ptr %slot198, align 8
  %v1916 = load i64, ptr %slot197, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  store i64 %v1915, ptr %p1917, align 8, !alias.scope !3, !noalias !4
  %v1918 = load i64, ptr %slot21, align 8
  %p1919 = inttoptr i64 %v1918 to ptr
  store i32 2, ptr %p1919, align 4, !alias.scope !3, !noalias !4
  %v1920 = load i64, ptr %slot21, align 8
  %p1921 = inttoptr i64 %v1920 to ptr
  store i32 16, ptr %p1921, align 4, !alias.scope !3, !noalias !4
  %v1922 = load i64, ptr %slot20, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  store i32 1, ptr %p1923, align 4, !alias.scope !3, !noalias !4
  %v1924 = load i64, ptr %slot14, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %ld1926 = load i32, ptr %p1925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1926, ptr %slot209, align 8
  %v1927 = load i32, ptr %slot209, align 8
  %cv1928 = zext i32 %v1927 to i64
  %cond1929 = icmp ne i64 %cv1928, 0
  br i1 %cond1929, label %bb_rcslotdrop243, label %bb_rcslotdone243
bb_rcslotdrop243:
  %v1930 = load i64, ptr %slot14, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  store i32 0, ptr %p1931, align 4, !alias.scope !3, !noalias !4
  %v1932 = load i64, ptr %slot24, align 8
  store i64 %v1932, ptr %slot210, align 8
  %v1933 = load i64, ptr %slot15, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  %ld1935 = load i32, ptr %p1934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1935, ptr %slot211, align 8
  %v1936 = load i32, ptr %slot211, align 8
  %op1937 = and i32 %v1936, 28
  store i32 %op1937, ptr %slot212, align 8
  %v1938 = load i32, ptr %slot212, align 8
  %cv1939 = zext i32 %v1938 to i64
  %cond1940 = icmp ne i64 %cv1939, 0
  br i1 %cond1940, label %bb_rcslotrole243, label %bb_rcslotowner243
bb_rcslotrole243:
  %v1941 = load i64, ptr %slot41, align 8
  store i64 %v1941, ptr %slot213, align 8
  %v1942 = load i64, ptr %slot210, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  %ld1944 = load i64, ptr %p1943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1944, ptr %slot214, align 8
  %v1945 = load i64, ptr %slot214, align 8
  %cmp1946 = icmp ne i64 %v1945, 0
  %cv1947 = zext i1 %cmp1946 to i32
  store i32 %cv1947, ptr %slot215, align 8
  %v1948 = load i32, ptr %slot215, align 8
  %cv1949 = zext i32 %v1948 to i64
  %cond1950 = icmp ne i64 %cv1949, 0
  br i1 %cond1950, label %bb_rcgnn259, label %bb_rcgdone259
bb_rcgnn259:
  %v1951 = load i64, ptr %slot214, align 8
  %op1952 = sub i64 %v1951, 16
  store i64 %op1952, ptr %slot216, align 8
  %v1953 = load i64, ptr %slot214, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  %rgep1955 = getelementptr i8, ptr %p1954, i64 -16
  %ld1956 = load i64, ptr %rgep1955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1956, ptr %slot217, align 8
  %v1957 = load i64, ptr %slot217, align 8
  %op1958 = and i64 %v1957, 4611686018427387906
  store i64 %op1958, ptr %slot218, align 8
  %v1959 = load i64, ptr %slot218, align 8
  %cmp1960 = icmp ne i64 %v1959, 0
  %cv1961 = zext i1 %cmp1960 to i32
  store i32 %cv1961, ptr %slot219, align 8
  %v1962 = load i32, ptr %slot219, align 8
  %cv1963 = zext i32 %v1962 to i64
  %cond1964 = icmp ne i64 %cv1963, 0
  br i1 %cond1964, label %bb_rcgclear259, label %bb_rcgcounted259
bb_rcgcounted259:
  %v1965 = load i64, ptr %slot214, align 8
  %op1966 = sub i64 %v1965, 24
  store i64 %op1966, ptr %slot220, align 8
  %v1967 = load i64, ptr %slot214, align 8
  %p1968 = inttoptr i64 %v1967 to ptr
  %rgep1969 = getelementptr i8, ptr %p1968, i64 -24
  %ld1970 = load i64, ptr %rgep1969, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1970, ptr %slot221, align 8
  %v1971 = load i64, ptr %slot221, align 8
  %op1972 = sub i64 %v1971, 1
  store i64 %op1972, ptr %slot222, align 8
  %v1973 = load i64, ptr %slot222, align 8
  %cmp1974 = icmp eq i64 %v1973, 0
  %cv1975 = zext i1 %cmp1974 to i32
  store i32 %cv1975, ptr %slot223, align 8
  %v1976 = load i32, ptr %slot223, align 8
  %cv1977 = zext i32 %v1976 to i64
  %cond1978 = icmp ne i64 %cv1977, 0
  br i1 %cond1978, label %bb_rcglast259, label %bb_rcgdec259
bb_rcglast259:
  %v1979 = load i64, ptr %slot214, align 8
  %op1980 = sub i64 %v1979, 32
  store i64 %op1980, ptr %slot224, align 8
  %v1981 = load i64, ptr %slot214, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  %rgep1983 = getelementptr i8, ptr %p1982, i64 -32
  %ld1984 = load i64, ptr %rgep1983, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1984, ptr %slot225, align 8
  %v1985 = load i64, ptr %slot225, align 8
  %cmp1986 = icmp ne i64 %v1985, 0
  %cv1987 = zext i1 %cmp1986 to i32
  store i32 %cv1987, ptr %slot226, align 8
  %v1988 = load i32, ptr %slot226, align 8
  %cv1989 = zext i32 %v1988 to i64
  %cond1990 = icmp ne i64 %cv1989, 0
  br i1 %cond1990, label %bb_rcgdec259, label %bb_rcgslow259
bb_rcgslow259:
  %v1991 = load i64, ptr %slot213, align 8
  %v1992 = load i64, ptr %slot210, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_unloan(i64 %v1991, i64 %v1992) nomerge, !dbg !118
  br label %bb_rcgdone259
bb_rcgdec259:
  %v1993 = load i64, ptr %slot222, align 8
  %v1994 = load i64, ptr %slot214, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  %rgep1996 = getelementptr i8, ptr %p1995, i64 -24
  store i64 %v1993, ptr %rgep1996, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear259
bb_rcgclear259:
  %v1997 = load i64, ptr %slot210, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  store i64 0, ptr %p1998, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone259
bb_rcgdone259:
  br label %bb_rcslotdone243
bb_rcslotowner243:
  %v1999 = load i64, ptr %slot41, align 8
  store i64 %v1999, ptr %slot227, align 8
  %v2000 = load i64, ptr %slot210, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  %ld2002 = load i64, ptr %p2001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2002, ptr %slot228, align 8
  %v2003 = load i64, ptr %slot228, align 8
  %cmp2004 = icmp ne i64 %v2003, 0
  %cv2005 = zext i1 %cmp2004 to i32
  store i32 %cv2005, ptr %slot229, align 8
  %v2006 = load i32, ptr %slot229, align 8
  %cv2007 = zext i32 %v2006 to i64
  %cond2008 = icmp ne i64 %cv2007, 0
  br i1 %cond2008, label %bb_rcgnn274, label %bb_rcgdone274
bb_rcgnn274:
  %v2009 = load i64, ptr %slot228, align 8
  %op2010 = sub i64 %v2009, 16
  store i64 %op2010, ptr %slot230, align 8
  %v2011 = load i64, ptr %slot228, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  %rgep2013 = getelementptr i8, ptr %p2012, i64 -16
  %ld2014 = load i64, ptr %rgep2013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2014, ptr %slot231, align 8
  %v2015 = load i64, ptr %slot231, align 8
  %op2016 = and i64 %v2015, 4611686018427387906
  store i64 %op2016, ptr %slot232, align 8
  %v2017 = load i64, ptr %slot232, align 8
  %cmp2018 = icmp ne i64 %v2017, 0
  %cv2019 = zext i1 %cmp2018 to i32
  store i32 %cv2019, ptr %slot233, align 8
  %v2020 = load i32, ptr %slot233, align 8
  %cv2021 = zext i32 %v2020 to i64
  %cond2022 = icmp ne i64 %cv2021, 0
  br i1 %cond2022, label %bb_rcgclear274, label %bb_rcgcounted274
bb_rcgcounted274:
  %v2023 = load i64, ptr %slot228, align 8
  %op2024 = sub i64 %v2023, 32
  store i64 %op2024, ptr %slot234, align 8
  %v2025 = load i64, ptr %slot228, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  %rgep2027 = getelementptr i8, ptr %p2026, i64 -32
  %ld2028 = load i64, ptr %rgep2027, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2028, ptr %slot235, align 8
  %v2029 = load i64, ptr %slot235, align 8
  %op2030 = sub i64 %v2029, 1
  store i64 %op2030, ptr %slot236, align 8
  %v2031 = load i64, ptr %slot236, align 8
  %cmp2032 = icmp eq i64 %v2031, 0
  %cv2033 = zext i1 %cmp2032 to i32
  store i32 %cv2033, ptr %slot237, align 8
  %v2034 = load i32, ptr %slot237, align 8
  %cv2035 = zext i32 %v2034 to i64
  %cond2036 = icmp ne i64 %cv2035, 0
  br i1 %cond2036, label %bb_rcglast274, label %bb_rcgdec274
bb_rcglast274:
  %v2037 = load i64, ptr %slot228, align 8
  %op2038 = sub i64 %v2037, 24
  store i64 %op2038, ptr %slot238, align 8
  %v2039 = load i64, ptr %slot228, align 8
  %p2040 = inttoptr i64 %v2039 to ptr
  %rgep2041 = getelementptr i8, ptr %p2040, i64 -24
  %ld2042 = load i64, ptr %rgep2041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2042, ptr %slot239, align 8
  %v2043 = load i64, ptr %slot239, align 8
  %cmp2044 = icmp ne i64 %v2043, 0
  %cv2045 = zext i1 %cmp2044 to i32
  store i32 %cv2045, ptr %slot240, align 8
  %v2046 = load i32, ptr %slot240, align 8
  %cv2047 = zext i32 %v2046 to i64
  %cond2048 = icmp ne i64 %cv2047, 0
  br i1 %cond2048, label %bb_rcgdec274, label %bb_rcgslow274
bb_rcgslow274:
  %v2049 = load i64, ptr %slot227, align 8
  %v2050 = load i64, ptr %slot210, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_drop(i64 %v2049, i64 %v2050) nomerge, !dbg !118
  br label %bb_rcgdone274
bb_rcgdec274:
  %v2051 = load i64, ptr %slot236, align 8
  %v2052 = load i64, ptr %slot228, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  %rgep2054 = getelementptr i8, ptr %p2053, i64 -32
  store i64 %v2051, ptr %rgep2054, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear274
bb_rcgclear274:
  %v2055 = load i64, ptr %slot210, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  store i64 0, ptr %p2056, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone274
bb_rcgdone274:
  br label %bb_rcslotdone243
bb_rcslotdone243:
  br label %bb_rcprivateprepared191
bb_rcprivateprepared191:
  %v2057 = load i64, ptr %slot6, align 8
  %p2058 = inttoptr i64 %v2057 to ptr
  %ld2059 = load i32, ptr %p2058, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2059, ptr %slot241, align 8
  %v2060 = load i32, ptr %slot241, align 8
  %cv2061 = zext i32 %v2060 to i64
  %cond2062 = icmp ne i64 %cv2061, 0
  br i1 %cond2062, label %bb_rcslotdrop281, label %bb_rcslotdone281
bb_rcslotdrop281:
  %v2063 = load i64, ptr %slot6, align 8
  %p2064 = inttoptr i64 %v2063 to ptr
  store i32 0, ptr %p2064, align 4, !alias.scope !3, !noalias !4
  %v2065 = load i64, ptr %slot33, align 8
  store i64 %v2065, ptr %slot242, align 8
  %v2066 = load i64, ptr %slot7, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  %ld2068 = load i32, ptr %p2067, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2068, ptr %slot243, align 8
  %v2069 = load i32, ptr %slot243, align 8
  %op2070 = and i32 %v2069, 28
  store i32 %op2070, ptr %slot244, align 8
  %v2071 = load i32, ptr %slot244, align 8
  %cv2072 = zext i32 %v2071 to i64
  %cond2073 = icmp ne i64 %cv2072, 0
  br i1 %cond2073, label %bb_rcslotrole281, label %bb_rcslotowner281
bb_rcslotrole281:
  %v2074 = load i64, ptr %slot41, align 8
  store i64 %v2074, ptr %slot245, align 8
  %v2075 = load i64, ptr %slot242, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %ld2077 = load i64, ptr %p2076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2077, ptr %slot246, align 8
  %v2078 = load i64, ptr %slot246, align 8
  %cmp2079 = icmp ne i64 %v2078, 0
  %cv2080 = zext i1 %cmp2079 to i32
  store i32 %cv2080, ptr %slot247, align 8
  %v2081 = load i32, ptr %slot247, align 8
  %cv2082 = zext i32 %v2081 to i64
  %cond2083 = icmp ne i64 %cv2082, 0
  br i1 %cond2083, label %bb_rcgnn297, label %bb_rcgdone297
bb_rcgnn297:
  %v2084 = load i64, ptr %slot246, align 8
  %op2085 = sub i64 %v2084, 16
  store i64 %op2085, ptr %slot248, align 8
  %v2086 = load i64, ptr %slot246, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  %rgep2088 = getelementptr i8, ptr %p2087, i64 -16
  %ld2089 = load i64, ptr %rgep2088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2089, ptr %slot249, align 8
  %v2090 = load i64, ptr %slot249, align 8
  %op2091 = and i64 %v2090, 4611686018427387906
  store i64 %op2091, ptr %slot250, align 8
  %v2092 = load i64, ptr %slot250, align 8
  %cmp2093 = icmp ne i64 %v2092, 0
  %cv2094 = zext i1 %cmp2093 to i32
  store i32 %cv2094, ptr %slot251, align 8
  %v2095 = load i32, ptr %slot251, align 8
  %cv2096 = zext i32 %v2095 to i64
  %cond2097 = icmp ne i64 %cv2096, 0
  br i1 %cond2097, label %bb_rcgclear297, label %bb_rcgcounted297
bb_rcgcounted297:
  %v2098 = load i64, ptr %slot246, align 8
  %op2099 = sub i64 %v2098, 24
  store i64 %op2099, ptr %slot252, align 8
  %v2100 = load i64, ptr %slot246, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  %rgep2102 = getelementptr i8, ptr %p2101, i64 -24
  %ld2103 = load i64, ptr %rgep2102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2103, ptr %slot253, align 8
  %v2104 = load i64, ptr %slot253, align 8
  %op2105 = sub i64 %v2104, 1
  store i64 %op2105, ptr %slot254, align 8
  %v2106 = load i64, ptr %slot254, align 8
  %cmp2107 = icmp eq i64 %v2106, 0
  %cv2108 = zext i1 %cmp2107 to i32
  store i32 %cv2108, ptr %slot255, align 8
  %v2109 = load i32, ptr %slot255, align 8
  %cv2110 = zext i32 %v2109 to i64
  %cond2111 = icmp ne i64 %cv2110, 0
  br i1 %cond2111, label %bb_rcglast297, label %bb_rcgdec297
bb_rcglast297:
  %v2112 = load i64, ptr %slot246, align 8
  %op2113 = sub i64 %v2112, 32
  store i64 %op2113, ptr %slot256, align 8
  %v2114 = load i64, ptr %slot246, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  %rgep2116 = getelementptr i8, ptr %p2115, i64 -32
  %ld2117 = load i64, ptr %rgep2116, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2117, ptr %slot257, align 8
  %v2118 = load i64, ptr %slot257, align 8
  %cmp2119 = icmp ne i64 %v2118, 0
  %cv2120 = zext i1 %cmp2119 to i32
  store i32 %cv2120, ptr %slot258, align 8
  %v2121 = load i32, ptr %slot258, align 8
  %cv2122 = zext i32 %v2121 to i64
  %cond2123 = icmp ne i64 %cv2122, 0
  br i1 %cond2123, label %bb_rcgdec297, label %bb_rcgslow297
bb_rcgslow297:
  %v2124 = load i64, ptr %slot245, align 8
  %v2125 = load i64, ptr %slot242, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_unloan(i64 %v2124, i64 %v2125) nomerge, !dbg !118
  br label %bb_rcgdone297
bb_rcgdec297:
  %v2126 = load i64, ptr %slot254, align 8
  %v2127 = load i64, ptr %slot246, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  %rgep2129 = getelementptr i8, ptr %p2128, i64 -24
  store i64 %v2126, ptr %rgep2129, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear297
bb_rcgclear297:
  %v2130 = load i64, ptr %slot242, align 8
  %p2131 = inttoptr i64 %v2130 to ptr
  store i64 0, ptr %p2131, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone297
bb_rcgdone297:
  br label %bb_rcslotdone281
bb_rcslotowner281:
  %v2132 = load i64, ptr %slot41, align 8
  store i64 %v2132, ptr %slot259, align 8
  %v2133 = load i64, ptr %slot242, align 8
  %p2134 = inttoptr i64 %v2133 to ptr
  %ld2135 = load i64, ptr %p2134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2135, ptr %slot260, align 8
  %v2136 = load i64, ptr %slot260, align 8
  %cmp2137 = icmp ne i64 %v2136, 0
  %cv2138 = zext i1 %cmp2137 to i32
  store i32 %cv2138, ptr %slot261, align 8
  %v2139 = load i32, ptr %slot261, align 8
  %cv2140 = zext i32 %v2139 to i64
  %cond2141 = icmp ne i64 %cv2140, 0
  br i1 %cond2141, label %bb_rcgnn312, label %bb_rcgdone312
bb_rcgnn312:
  %v2142 = load i64, ptr %slot260, align 8
  %op2143 = sub i64 %v2142, 16
  store i64 %op2143, ptr %slot262, align 8
  %v2144 = load i64, ptr %slot260, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  %rgep2146 = getelementptr i8, ptr %p2145, i64 -16
  %ld2147 = load i64, ptr %rgep2146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2147, ptr %slot263, align 8
  %v2148 = load i64, ptr %slot263, align 8
  %op2149 = and i64 %v2148, 4611686018427387906
  store i64 %op2149, ptr %slot264, align 8
  %v2150 = load i64, ptr %slot264, align 8
  %cmp2151 = icmp ne i64 %v2150, 0
  %cv2152 = zext i1 %cmp2151 to i32
  store i32 %cv2152, ptr %slot265, align 8
  %v2153 = load i32, ptr %slot265, align 8
  %cv2154 = zext i32 %v2153 to i64
  %cond2155 = icmp ne i64 %cv2154, 0
  br i1 %cond2155, label %bb_rcgclear312, label %bb_rcgcounted312
bb_rcgcounted312:
  %v2156 = load i64, ptr %slot260, align 8
  %op2157 = sub i64 %v2156, 32
  store i64 %op2157, ptr %slot266, align 8
  %v2158 = load i64, ptr %slot260, align 8
  %p2159 = inttoptr i64 %v2158 to ptr
  %rgep2160 = getelementptr i8, ptr %p2159, i64 -32
  %ld2161 = load i64, ptr %rgep2160, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2161, ptr %slot267, align 8
  %v2162 = load i64, ptr %slot267, align 8
  %op2163 = sub i64 %v2162, 1
  store i64 %op2163, ptr %slot268, align 8
  %v2164 = load i64, ptr %slot268, align 8
  %cmp2165 = icmp eq i64 %v2164, 0
  %cv2166 = zext i1 %cmp2165 to i32
  store i32 %cv2166, ptr %slot269, align 8
  %v2167 = load i32, ptr %slot269, align 8
  %cv2168 = zext i32 %v2167 to i64
  %cond2169 = icmp ne i64 %cv2168, 0
  br i1 %cond2169, label %bb_rcglast312, label %bb_rcgdec312
bb_rcglast312:
  %v2170 = load i64, ptr %slot260, align 8
  %op2171 = sub i64 %v2170, 24
  store i64 %op2171, ptr %slot270, align 8
  %v2172 = load i64, ptr %slot260, align 8
  %p2173 = inttoptr i64 %v2172 to ptr
  %rgep2174 = getelementptr i8, ptr %p2173, i64 -24
  %ld2175 = load i64, ptr %rgep2174, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2175, ptr %slot271, align 8
  %v2176 = load i64, ptr %slot271, align 8
  %cmp2177 = icmp ne i64 %v2176, 0
  %cv2178 = zext i1 %cmp2177 to i32
  store i32 %cv2178, ptr %slot272, align 8
  %v2179 = load i32, ptr %slot272, align 8
  %cv2180 = zext i32 %v2179 to i64
  %cond2181 = icmp ne i64 %cv2180, 0
  br i1 %cond2181, label %bb_rcgdec312, label %bb_rcgslow312
bb_rcgslow312:
  %v2182 = load i64, ptr %slot259, align 8
  %v2183 = load i64, ptr %slot242, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_drop(i64 %v2182, i64 %v2183) nomerge, !dbg !118
  br label %bb_rcgdone312
bb_rcgdec312:
  %v2184 = load i64, ptr %slot268, align 8
  %v2185 = load i64, ptr %slot260, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %rgep2187 = getelementptr i8, ptr %p2186, i64 -32
  store i64 %v2184, ptr %rgep2187, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear312
bb_rcgclear312:
  %v2188 = load i64, ptr %slot242, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  store i64 0, ptr %p2189, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone312
bb_rcgdone312:
  br label %bb_rcslotdone281
bb_rcslotdone281:
  %v2190 = load i64, ptr %slot33, align 8
  store i64 %v2190, ptr %slot273, align 8
  %v2191 = load i64, ptr %slot31, align 8
  store i64 %v2191, ptr %slot274, align 8
  %v2192 = load i64, ptr %slot274, align 8
  %v2193 = load i64, ptr %slot273, align 8
  %p2194 = inttoptr i64 %v2192 to ptr
  %p2195 = inttoptr i64 %v2193 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2195, ptr %p2194, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2196 = load i64, ptr %slot20, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  store i32 0, ptr %p2197, align 4, !alias.scope !3, !noalias !4
  %v2198 = load i64, ptr %slot7, align 8
  %p2199 = inttoptr i64 %v2198 to ptr
  store i32 2, ptr %p2199, align 4, !alias.scope !3, !noalias !4
  %v2200 = load i64, ptr %slot21, align 8
  %p2201 = inttoptr i64 %v2200 to ptr
  %ld2202 = load i32, ptr %p2201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2202, ptr %slot275, align 8
  %v2203 = load i32, ptr %slot275, align 8
  %v2204 = load i64, ptr %slot7, align 8
  %p2205 = inttoptr i64 %v2204 to ptr
  store i32 %v2203, ptr %p2205, align 4, !alias.scope !3, !noalias !4
  %v2206 = load i64, ptr %slot6, align 8
  %p2207 = inttoptr i64 %v2206 to ptr
  store i32 1, ptr %p2207, align 4, !alias.scope !3, !noalias !4
  %v2208 = load i64, ptr %slot33, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  %ld2210 = load i64, ptr %p2209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2210, ptr %slot276, align 8
  %v2211 = load i64, ptr %slot276, align 8
  %v2212 = load i64, ptr %slot37, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  store i64 %v2211, ptr %p2213, align 8, !alias.scope !3, !noalias !4
  %v2214 = load i64, ptr %slot38, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  store i64 0, ptr %p2215, align 8, !alias.scope !3, !noalias !4
  %v2216 = load i64, ptr %slot38, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  %ld2218 = load i64, ptr %p2217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2218, ptr %slot277, align 8
  %v2219 = load i64, ptr %slot277, align 8
  %cmp2220 = icmp sge i64 %v2219, 0
  %cv2221 = zext i1 %cmp2220 to i64
  store i64 %cv2221, ptr %slot278, align 8
  %v2222 = load i64, ptr %slot278, align 8
  %cond2223 = icmp ne i64 %v2222, 0
  br i1 %cond2223, label %bb_success326, label %bb_failed326
bb_failed326:
  %v2224 = load i64, ptr %slot1, align 8
  %p2225 = inttoptr i64 %v2224 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p2225) nomerge, !dbg !120
  unreachable
bb_success326:
  %v2226 = load i64, ptr %slot41, align 8
  %p2227 = inttoptr i64 %v2226 to ptr
  %p2228 = inttoptr i64 ptrtoint (ptr @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c to i64) to ptr
  %v2229 = load i64, ptr %slot277, align 8
  %call2230 = call ptr @myl_native_list_new(ptr %p2227, ptr %p2228, i64 %v2229) nomerge, !dbg !120
  %calladdr2231 = ptrtoint ptr %call2230 to i64
  store i64 %calladdr2231, ptr %slot279, align 8
  %v2232 = load i64, ptr %slot279, align 8
  %cond2233 = icmp ne i64 %v2232, 0
  br i1 %cond2233, label %bb_success328, label %bb_failed328
bb_failed328:
  %v2234 = load i64, ptr %slot1, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2235) nomerge, !dbg !120
  unreachable
bb_success328:
  %v2236 = load i64, ptr %slot279, align 8
  %v2237 = load i64, ptr %slot38, align 8
  %p2238 = inttoptr i64 %v2237 to ptr
  store i64 %v2236, ptr %p2238, align 8, !alias.scope !3, !noalias !4
  %v2239 = load i64, ptr %slot38, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  %ld2241 = load i64, ptr %p2240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2241, ptr %slot280, align 8
  %v2242 = load i64, ptr %slot280, align 8
  %v2243 = load i64, ptr %slot29, align 8
  %p2244 = inttoptr i64 %v2243 to ptr
  store i64 %v2242, ptr %p2244, align 8, !alias.scope !3, !noalias !4
  %v2245 = load i64, ptr %slot29, align 8
  store i64 %v2245, ptr %slot281, align 8
  %v2246 = load i64, ptr %slot31, align 8
  store i64 %v2246, ptr %slot282, align 8
  %v2247 = load i64, ptr %slot281, align 8
  %v2248 = load i64, ptr %slot282, align 8
  %p2249 = inttoptr i64 %v2247 to ptr
  %p2250 = inttoptr i64 %v2248 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2250, ptr %p2249, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2251 = load i64, ptr %slot21, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i32 2, ptr %p2252, align 4, !alias.scope !3, !noalias !4
  %v2253 = load i64, ptr %slot20, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  store i32 1, ptr %p2254, align 4, !alias.scope !3, !noalias !4
  %v2255 = load i64, ptr %slot25, align 8
  store i64 %v2255, ptr %slot283, align 8
  %v2256 = load i64, ptr %slot31, align 8
  store i64 %v2256, ptr %slot284, align 8
  %v2257 = load i64, ptr %slot284, align 8
  %v2258 = load i64, ptr %slot283, align 8
  %p2259 = inttoptr i64 %v2257 to ptr
  %p2260 = inttoptr i64 %v2258 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2260, ptr %p2259, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2261 = load i64, ptr %slot17, align 8
  %p2262 = inttoptr i64 %v2261 to ptr
  store i32 2, ptr %p2262, align 4, !alias.scope !3, !noalias !4
  %v2263 = load i64, ptr %slot21, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  %ld2265 = load i32, ptr %p2264, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2265, ptr %slot285, align 8
  %v2266 = load i32, ptr %slot285, align 8
  %v2267 = load i64, ptr %slot17, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  store i32 %v2266, ptr %p2268, align 4, !alias.scope !3, !noalias !4
  %v2269 = load i64, ptr %slot20, align 8
  %p2270 = inttoptr i64 %v2269 to ptr
  store i32 0, ptr %p2270, align 4, !alias.scope !3, !noalias !4
  %v2271 = load i64, ptr %slot16, align 8
  %p2272 = inttoptr i64 %v2271 to ptr
  store i32 1, ptr %p2272, align 4, !alias.scope !3, !noalias !4
  %v2273 = load i64, ptr %slot283, align 8
  %p2274 = inttoptr i64 %v2273 to ptr
  %ld2275 = load i64, ptr %p2274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2275, ptr %slot286, align 8
  %v2276 = load i64, ptr %slot286, align 8
  %v2277 = load i64, ptr %slot38, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  store i64 %v2276, ptr %p2278, align 8, !alias.scope !3, !noalias !4
  %v2279 = load i64, ptr %slot38, align 8
  %p2280 = inttoptr i64 %v2279 to ptr
  %ld2281 = load i64, ptr %p2280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2281, ptr %slot287, align 8
  %v2282 = load i64, ptr %slot287, align 8
  %v2283 = load i64, ptr %slot29, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  store i64 %v2282, ptr %p2284, align 8, !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot29, align 8
  store i64 %v2285, ptr %slot288, align 8
  %v2286 = load i64, ptr %slot16, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %ld2288 = load i32, ptr %p2287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2288, ptr %slot289, align 8
  %v2289 = load i64, ptr %slot17, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  %ld2291 = load i32, ptr %p2290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2291, ptr %slot290, align 8
  %v2292 = load i32, ptr %slot290, align 8
  %op2293 = and i32 %v2292, 24
  store i32 %op2293, ptr %slot290, align 8
  %v2294 = load i32, ptr %slot290, align 8
  %cmp2295 = icmp eq i32 %v2294, 0
  %cv2296 = zext i1 %cmp2295 to i32
  store i32 %cv2296, ptr %slot291, align 8
  %v2297 = load i32, ptr %slot289, align 8
  %v2298 = load i32, ptr %slot291, align 8
  %op2299 = and i32 %v2297, %v2298
  store i32 %op2299, ptr %slot292, align 8
  %v2300 = load i32, ptr %slot292, align 8
  %cv2301 = zext i32 %v2300 to i64
  %cond2302 = icmp ne i64 %cv2301, 0
  br i1 %cond2302, label %bb_rcprivateown351, label %bb_rcprivateloan351
bb_rcprivateown351:
  %v2303 = load i64, ptr %slot31, align 8
  store i64 %v2303, ptr %slot293, align 8
  %v2304 = load i64, ptr %slot42, align 8
  store i64 %v2304, ptr %slot294, align 8
  %v2305 = load i64, ptr %slot288, align 8
  %v2306 = load i64, ptr %slot293, align 8
  %op2307 = sub i64 %v2305, %v2306
  store i64 %op2307, ptr %slot295, align 8
  %v2308 = load i64, ptr %slot293, align 8
  %v2309 = load i64, ptr %slot288, align 8
  %op2310 = sub i64 %v2308, %v2309
  store i64 %op2310, ptr %slot296, align 8
  %v2311 = load i64, ptr %slot295, align 8
  %cmp2312 = icmp ult i64 %v2311, 8
  %cv2313 = zext i1 %cmp2312 to i32
  store i32 %cv2313, ptr %slot297, align 8
  %v2314 = load i64, ptr %slot296, align 8
  %cmp2315 = icmp ult i64 %v2314, 8
  %cv2316 = zext i1 %cmp2315 to i32
  store i32 %cv2316, ptr %slot298, align 8
  %v2317 = load i32, ptr %slot297, align 8
  %v2318 = load i32, ptr %slot298, align 8
  %op2319 = or i32 %v2317, %v2318
  store i32 %op2319, ptr %slot299, align 8
  %v2320 = load i32, ptr %slot299, align 8
  %cv2321 = zext i32 %v2320 to i64
  %cond2322 = icmp ne i64 %cv2321, 0
  br i1 %cond2322, label %bb_rcmoveslow354, label %bb_rcmovecheck354
bb_rcmovecheck354:
  %v2323 = load i64, ptr %slot288, align 8
  %p2325 = inttoptr i64 %v2323 to ptr
  %gep2326 = getelementptr i8, ptr %p2325, i64 0
  %op2324 = ptrtoint ptr %gep2326 to i64
  store i64 %op2324, ptr %slot300, align 8
  %v2327 = load i64, ptr %slot300, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  %ld2329 = load i64, ptr %p2328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2329, ptr %slot301, align 8
  %v2330 = load i64, ptr %slot301, align 8
  %cmp2331 = icmp ne i64 %v2330, 0
  %cv2332 = zext i1 %cmp2331 to i32
  store i32 %cv2332, ptr %slot302, align 8
  %v2333 = load i32, ptr %slot302, align 8
  %cv2334 = zext i32 %v2333 to i64
  %cond2335 = icmp ne i64 %cv2334, 0
  br i1 %cond2335, label %bb_rcmoveheader362, label %bb_rcmovenext362
bb_rcmoveheader362:
  %v2336 = load i64, ptr %slot301, align 8
  %op2337 = sub i64 %v2336, 16
  store i64 %op2337, ptr %slot303, align 8
  %v2338 = load i64, ptr %slot301, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  %rgep2340 = getelementptr i8, ptr %p2339, i64 -16
  %ld2341 = load i64, ptr %rgep2340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2341, ptr %slot304, align 8
  %v2342 = load i64, ptr %slot304, align 8
  %op2343 = and i64 %v2342, 5764607523034234881
  store i64 %op2343, ptr %slot305, align 8
  %v2344 = load i64, ptr %slot305, align 8
  %cmp2345 = icmp ne i64 %v2344, 0
  %cv2346 = zext i1 %cmp2345 to i32
  store i32 %cv2346, ptr %slot306, align 8
  %v2347 = load i32, ptr %slot306, align 8
  %cv2348 = zext i32 %v2347 to i64
  %cond2349 = icmp ne i64 %cv2348, 0
  br i1 %cond2349, label %bb_rcmoveslow354, label %bb_rcmovenext362
bb_rcmovenext362:
  %v2350 = load i64, ptr %slot288, align 8
  %v2351 = load i64, ptr %slot293, align 8
  %p2352 = inttoptr i64 %v2350 to ptr
  %p2353 = inttoptr i64 %v2351 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2353, ptr %p2352, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2354 = load i64, ptr %slot288, align 8
  %p2355 = inttoptr i64 %v2354 to ptr
  store i64 0, ptr %p2355, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved354
bb_rcmoveslow354:
  %v2356 = load i64, ptr %slot41, align 8
  %v2357 = load i64, ptr %slot293, align 8
  %v2358 = load i64, ptr %slot288, align 8
  %v2359 = load i64, ptr %slot294, align 8
  %cv2360 = trunc i64 %v2359 to i32
  %call2361 = call i32 @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_take(i64 %v2356, i64 %v2357, i64 %v2358, i32 %cv2360) nomerge, !dbg !122
  store i32 %call2361, ptr %slot307, align 8
  %v2362 = load i32, ptr %slot307, align 8
  %cv2363 = zext i32 %v2362 to i64
  %cond2364 = icmp ne i64 %cv2363, 0
  br i1 %cond2364, label %bb_rcsuccess369, label %bb_rcfailure369
bb_rcfailure369:
  %v2365 = load i64, ptr %slot41, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %call2367 = call i32 @myl_rc_take_failure(ptr %p2366) nomerge, !dbg !122
  store i32 %call2367, ptr %slot308, align 8
  %v2368 = load i64, ptr %slot1, align 8
  %p2369 = inttoptr i64 %v2368 to ptr
  %v2370 = load i32, ptr %slot308, align 8
  %call2371 = call i32 @myl_qbe_rc_status(ptr %p2369, i32 %v2370) nomerge, !dbg !122
  store i32 %call2371, ptr %slot309, align 8
  br label %bb_failure
bb_rcsuccess369:
  br label %bb_rcmoved354
bb_rcmoved354:
  %v2372 = load i64, ptr %slot16, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  store i32 0, ptr %p2373, align 4, !alias.scope !3, !noalias !4
  %v2374 = load i64, ptr %slot21, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  store i32 2, ptr %p2375, align 4, !alias.scope !3, !noalias !4
  %v2376 = load i64, ptr %slot20, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  store i32 1, ptr %p2377, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared351
bb_rcprivateloan351:
  %v2378 = load i64, ptr %slot16, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  %ld2380 = load i32, ptr %p2379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2380, ptr %slot310, align 8
  %v2381 = load i64, ptr %slot17, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  %ld2383 = load i32, ptr %p2382, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2383, ptr %slot311, align 8
  %v2384 = load i32, ptr %slot311, align 8
  %cmp2385 = icmp eq i32 %v2384, 16
  %cv2386 = zext i1 %cmp2385 to i32
  store i32 %cv2386, ptr %slot312, align 8
  %v2387 = load i32, ptr %slot312, align 8
  %v2388 = load i32, ptr %slot310, align 8
  %op2389 = and i32 %v2387, %v2388
  store i32 %op2389, ptr %slot312, align 8
  %v2390 = load i32, ptr %slot312, align 8
  %cv2391 = zext i32 %v2390 to i64
  %cond2392 = icmp ne i64 %cv2391, 0
  br i1 %cond2392, label %bb_rcprivatemove351, label %bb_rcprivatenew351
bb_rcprivatemove351:
  %v2393 = load i64, ptr %slot31, align 8
  store i64 %v2393, ptr %slot313, align 8
  %v2394 = load i64, ptr %slot288, align 8
  %v2395 = load i64, ptr %slot313, align 8
  %p2396 = inttoptr i64 %v2394 to ptr
  %p2397 = inttoptr i64 %v2395 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2397, ptr %p2396, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2398 = load i64, ptr %slot288, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 0, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot21, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  store i32 2, ptr %p2401, align 4, !alias.scope !3, !noalias !4
  %v2402 = load i64, ptr %slot21, align 8
  %p2403 = inttoptr i64 %v2402 to ptr
  store i32 16, ptr %p2403, align 4, !alias.scope !3, !noalias !4
  %v2404 = load i64, ptr %slot20, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  store i32 1, ptr %p2405, align 4, !alias.scope !3, !noalias !4
  %v2406 = load i64, ptr %slot16, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  store i32 0, ptr %p2407, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared351
bb_rcprivatenew351:
  %v2408 = load i64, ptr %slot31, align 8
  store i64 %v2408, ptr %slot314, align 8
  %v2409 = load i64, ptr %slot288, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  %ld2411 = load i64, ptr %p2410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2411, ptr %slot315, align 8
  %v2412 = load i64, ptr %slot315, align 8
  %cmp2413 = icmp ne i64 %v2412, 0
  %cv2414 = zext i1 %cmp2413 to i32
  store i32 %cv2414, ptr %slot316, align 8
  %v2415 = load i32, ptr %slot316, align 8
  %cv2416 = zext i32 %v2415 to i64
  %cond2417 = icmp ne i64 %cv2416, 0
  br i1 %cond2417, label %bb_rcgnn387, label %bb_rcgstore387
bb_rcgnn387:
  %v2418 = load i64, ptr %slot315, align 8
  %op2419 = sub i64 %v2418, 16
  store i64 %op2419, ptr %slot317, align 8
  %v2420 = load i64, ptr %slot315, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  %rgep2422 = getelementptr i8, ptr %p2421, i64 -16
  %ld2423 = load i64, ptr %rgep2422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2423, ptr %slot318, align 8
  %v2424 = load i64, ptr %slot318, align 8
  %op2425 = and i64 %v2424, 4611686018427387906
  store i64 %op2425, ptr %slot319, align 8
  %v2426 = load i64, ptr %slot319, align 8
  %cmp2427 = icmp ne i64 %v2426, 0
  %cv2428 = zext i1 %cmp2427 to i32
  store i32 %cv2428, ptr %slot320, align 8
  %v2429 = load i32, ptr %slot320, align 8
  %cv2430 = zext i32 %v2429 to i64
  %cond2431 = icmp ne i64 %cv2430, 0
  br i1 %cond2431, label %bb_rcgstore387, label %bb_rcginc387
bb_rcginc387:
  %v2432 = load i64, ptr %slot315, align 8
  %op2433 = sub i64 %v2432, 24
  store i64 %op2433, ptr %slot321, align 8
  %v2434 = load i64, ptr %slot315, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  %rgep2436 = getelementptr i8, ptr %p2435, i64 -24
  %ld2437 = load i64, ptr %rgep2436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2437, ptr %slot322, align 8
  %v2438 = load i64, ptr %slot322, align 8
  %op2439 = add i64 %v2438, 1
  store i64 %op2439, ptr %slot323, align 8
  %v2440 = load i64, ptr %slot323, align 8
  %cmp2441 = icmp eq i64 %v2440, 0
  %cv2442 = zext i1 %cmp2441 to i32
  store i32 %cv2442, ptr %slot324, align 8
  %v2443 = load i32, ptr %slot324, align 8
  %cv2444 = zext i32 %v2443 to i64
  %cond2445 = icmp ne i64 %cv2444, 0
  br i1 %cond2445, label %bb_rcglimit387, label %bb_rcgcapacity387
bb_rcglimit387:
  %v2446 = load i64, ptr %slot1, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  %call2448 = call i32 @myl_qbe_rc_status(ptr %p2447, i32 2) nomerge, !dbg !122
  store i32 %call2448, ptr %slot325, align 8
  br label %bb_failure
bb_rcgcapacity387:
  %v2449 = load i64, ptr %slot323, align 8
  %v2450 = load i64, ptr %slot315, align 8
  %p2451 = inttoptr i64 %v2450 to ptr
  %rgep2452 = getelementptr i8, ptr %p2451, i64 -24
  store i64 %v2449, ptr %rgep2452, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore387
bb_rcgstore387:
  %v2453 = load i64, ptr %slot315, align 8
  %v2454 = load i64, ptr %slot314, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  store i64 %v2453, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  %v2456 = load i64, ptr %slot21, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  store i32 2, ptr %p2457, align 4, !alias.scope !3, !noalias !4
  %v2458 = load i64, ptr %slot21, align 8
  %p2459 = inttoptr i64 %v2458 to ptr
  store i32 16, ptr %p2459, align 4, !alias.scope !3, !noalias !4
  %v2460 = load i64, ptr %slot20, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  store i32 1, ptr %p2461, align 4, !alias.scope !3, !noalias !4
  %v2462 = load i64, ptr %slot16, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  %ld2464 = load i32, ptr %p2463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2464, ptr %slot326, align 8
  %v2465 = load i32, ptr %slot326, align 8
  %cv2466 = zext i32 %v2465 to i64
  %cond2467 = icmp ne i64 %cv2466, 0
  br i1 %cond2467, label %bb_rcslotdrop403, label %bb_rcslotdone403
bb_rcslotdrop403:
  %v2468 = load i64, ptr %slot16, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  store i32 0, ptr %p2469, align 4, !alias.scope !3, !noalias !4
  %v2470 = load i64, ptr %slot25, align 8
  store i64 %v2470, ptr %slot327, align 8
  %v2471 = load i64, ptr %slot17, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %ld2473 = load i32, ptr %p2472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2473, ptr %slot328, align 8
  %v2474 = load i32, ptr %slot328, align 8
  %op2475 = and i32 %v2474, 28
  store i32 %op2475, ptr %slot329, align 8
  %v2476 = load i32, ptr %slot329, align 8
  %cv2477 = zext i32 %v2476 to i64
  %cond2478 = icmp ne i64 %cv2477, 0
  br i1 %cond2478, label %bb_rcslotrole403, label %bb_rcslotowner403
bb_rcslotrole403:
  %v2479 = load i64, ptr %slot41, align 8
  store i64 %v2479, ptr %slot330, align 8
  %v2480 = load i64, ptr %slot327, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  %ld2482 = load i64, ptr %p2481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2482, ptr %slot331, align 8
  %v2483 = load i64, ptr %slot331, align 8
  %cmp2484 = icmp ne i64 %v2483, 0
  %cv2485 = zext i1 %cmp2484 to i32
  store i32 %cv2485, ptr %slot332, align 8
  %v2486 = load i32, ptr %slot332, align 8
  %cv2487 = zext i32 %v2486 to i64
  %cond2488 = icmp ne i64 %cv2487, 0
  br i1 %cond2488, label %bb_rcgnn419, label %bb_rcgdone419
bb_rcgnn419:
  %v2489 = load i64, ptr %slot331, align 8
  %op2490 = sub i64 %v2489, 16
  store i64 %op2490, ptr %slot333, align 8
  %v2491 = load i64, ptr %slot331, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  %rgep2493 = getelementptr i8, ptr %p2492, i64 -16
  %ld2494 = load i64, ptr %rgep2493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2494, ptr %slot334, align 8
  %v2495 = load i64, ptr %slot334, align 8
  %op2496 = and i64 %v2495, 4611686018427387906
  store i64 %op2496, ptr %slot335, align 8
  %v2497 = load i64, ptr %slot335, align 8
  %cmp2498 = icmp ne i64 %v2497, 0
  %cv2499 = zext i1 %cmp2498 to i32
  store i32 %cv2499, ptr %slot336, align 8
  %v2500 = load i32, ptr %slot336, align 8
  %cv2501 = zext i32 %v2500 to i64
  %cond2502 = icmp ne i64 %cv2501, 0
  br i1 %cond2502, label %bb_rcgclear419, label %bb_rcgcounted419
bb_rcgcounted419:
  %v2503 = load i64, ptr %slot331, align 8
  %op2504 = sub i64 %v2503, 24
  store i64 %op2504, ptr %slot337, align 8
  %v2505 = load i64, ptr %slot331, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %rgep2507 = getelementptr i8, ptr %p2506, i64 -24
  %ld2508 = load i64, ptr %rgep2507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2508, ptr %slot338, align 8
  %v2509 = load i64, ptr %slot338, align 8
  %op2510 = sub i64 %v2509, 1
  store i64 %op2510, ptr %slot339, align 8
  %v2511 = load i64, ptr %slot339, align 8
  %cmp2512 = icmp eq i64 %v2511, 0
  %cv2513 = zext i1 %cmp2512 to i32
  store i32 %cv2513, ptr %slot340, align 8
  %v2514 = load i32, ptr %slot340, align 8
  %cv2515 = zext i32 %v2514 to i64
  %cond2516 = icmp ne i64 %cv2515, 0
  br i1 %cond2516, label %bb_rcglast419, label %bb_rcgdec419
bb_rcglast419:
  %v2517 = load i64, ptr %slot331, align 8
  %op2518 = sub i64 %v2517, 32
  store i64 %op2518, ptr %slot341, align 8
  %v2519 = load i64, ptr %slot331, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  %rgep2521 = getelementptr i8, ptr %p2520, i64 -32
  %ld2522 = load i64, ptr %rgep2521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2522, ptr %slot342, align 8
  %v2523 = load i64, ptr %slot342, align 8
  %cmp2524 = icmp ne i64 %v2523, 0
  %cv2525 = zext i1 %cmp2524 to i32
  store i32 %cv2525, ptr %slot343, align 8
  %v2526 = load i32, ptr %slot343, align 8
  %cv2527 = zext i32 %v2526 to i64
  %cond2528 = icmp ne i64 %cv2527, 0
  br i1 %cond2528, label %bb_rcgdec419, label %bb_rcgslow419
bb_rcgslow419:
  %v2529 = load i64, ptr %slot330, align 8
  %v2530 = load i64, ptr %slot327, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_unloan(i64 %v2529, i64 %v2530) nomerge, !dbg !122
  br label %bb_rcgdone419
bb_rcgdec419:
  %v2531 = load i64, ptr %slot339, align 8
  %v2532 = load i64, ptr %slot331, align 8
  %p2533 = inttoptr i64 %v2532 to ptr
  %rgep2534 = getelementptr i8, ptr %p2533, i64 -24
  store i64 %v2531, ptr %rgep2534, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear419
bb_rcgclear419:
  %v2535 = load i64, ptr %slot327, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i64 0, ptr %p2536, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone419
bb_rcgdone419:
  br label %bb_rcslotdone403
bb_rcslotowner403:
  %v2537 = load i64, ptr %slot41, align 8
  store i64 %v2537, ptr %slot344, align 8
  %v2538 = load i64, ptr %slot327, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  %ld2540 = load i64, ptr %p2539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2540, ptr %slot345, align 8
  %v2541 = load i64, ptr %slot345, align 8
  %cmp2542 = icmp ne i64 %v2541, 0
  %cv2543 = zext i1 %cmp2542 to i32
  store i32 %cv2543, ptr %slot346, align 8
  %v2544 = load i32, ptr %slot346, align 8
  %cv2545 = zext i32 %v2544 to i64
  %cond2546 = icmp ne i64 %cv2545, 0
  br i1 %cond2546, label %bb_rcgnn434, label %bb_rcgdone434
bb_rcgnn434:
  %v2547 = load i64, ptr %slot345, align 8
  %op2548 = sub i64 %v2547, 16
  store i64 %op2548, ptr %slot347, align 8
  %v2549 = load i64, ptr %slot345, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  %rgep2551 = getelementptr i8, ptr %p2550, i64 -16
  %ld2552 = load i64, ptr %rgep2551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2552, ptr %slot348, align 8
  %v2553 = load i64, ptr %slot348, align 8
  %op2554 = and i64 %v2553, 4611686018427387906
  store i64 %op2554, ptr %slot349, align 8
  %v2555 = load i64, ptr %slot349, align 8
  %cmp2556 = icmp ne i64 %v2555, 0
  %cv2557 = zext i1 %cmp2556 to i32
  store i32 %cv2557, ptr %slot350, align 8
  %v2558 = load i32, ptr %slot350, align 8
  %cv2559 = zext i32 %v2558 to i64
  %cond2560 = icmp ne i64 %cv2559, 0
  br i1 %cond2560, label %bb_rcgclear434, label %bb_rcgcounted434
bb_rcgcounted434:
  %v2561 = load i64, ptr %slot345, align 8
  %op2562 = sub i64 %v2561, 32
  store i64 %op2562, ptr %slot351, align 8
  %v2563 = load i64, ptr %slot345, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %rgep2565 = getelementptr i8, ptr %p2564, i64 -32
  %ld2566 = load i64, ptr %rgep2565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2566, ptr %slot352, align 8
  %v2567 = load i64, ptr %slot352, align 8
  %op2568 = sub i64 %v2567, 1
  store i64 %op2568, ptr %slot353, align 8
  %v2569 = load i64, ptr %slot353, align 8
  %cmp2570 = icmp eq i64 %v2569, 0
  %cv2571 = zext i1 %cmp2570 to i32
  store i32 %cv2571, ptr %slot354, align 8
  %v2572 = load i32, ptr %slot354, align 8
  %cv2573 = zext i32 %v2572 to i64
  %cond2574 = icmp ne i64 %cv2573, 0
  br i1 %cond2574, label %bb_rcglast434, label %bb_rcgdec434
bb_rcglast434:
  %v2575 = load i64, ptr %slot345, align 8
  %op2576 = sub i64 %v2575, 24
  store i64 %op2576, ptr %slot355, align 8
  %v2577 = load i64, ptr %slot345, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %rgep2579 = getelementptr i8, ptr %p2578, i64 -24
  %ld2580 = load i64, ptr %rgep2579, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2580, ptr %slot356, align 8
  %v2581 = load i64, ptr %slot356, align 8
  %cmp2582 = icmp ne i64 %v2581, 0
  %cv2583 = zext i1 %cmp2582 to i32
  store i32 %cv2583, ptr %slot357, align 8
  %v2584 = load i32, ptr %slot357, align 8
  %cv2585 = zext i32 %v2584 to i64
  %cond2586 = icmp ne i64 %cv2585, 0
  br i1 %cond2586, label %bb_rcgdec434, label %bb_rcgslow434
bb_rcgslow434:
  %v2587 = load i64, ptr %slot344, align 8
  %v2588 = load i64, ptr %slot327, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64 %v2587, i64 %v2588) nomerge, !dbg !122
  br label %bb_rcgdone434
bb_rcgdec434:
  %v2589 = load i64, ptr %slot353, align 8
  %v2590 = load i64, ptr %slot345, align 8
  %p2591 = inttoptr i64 %v2590 to ptr
  %rgep2592 = getelementptr i8, ptr %p2591, i64 -32
  store i64 %v2589, ptr %rgep2592, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear434
bb_rcgclear434:
  %v2593 = load i64, ptr %slot327, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  store i64 0, ptr %p2594, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone434
bb_rcgdone434:
  br label %bb_rcslotdone403
bb_rcslotdone403:
  br label %bb_rcprivateprepared351
bb_rcprivateprepared351:
  %v2595 = load i64, ptr %slot8, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  %ld2597 = load i32, ptr %p2596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2597, ptr %slot358, align 8
  %v2598 = load i32, ptr %slot358, align 8
  %cv2599 = zext i32 %v2598 to i64
  %cond2600 = icmp ne i64 %cv2599, 0
  br i1 %cond2600, label %bb_rcslotdrop441, label %bb_rcslotdone441
bb_rcslotdrop441:
  %v2601 = load i64, ptr %slot8, align 8
  %p2602 = inttoptr i64 %v2601 to ptr
  store i32 0, ptr %p2602, align 4, !alias.scope !3, !noalias !4
  %v2603 = load i64, ptr %slot34, align 8
  store i64 %v2603, ptr %slot359, align 8
  %v2604 = load i64, ptr %slot9, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  %ld2606 = load i32, ptr %p2605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2606, ptr %slot360, align 8
  %v2607 = load i32, ptr %slot360, align 8
  %op2608 = and i32 %v2607, 28
  store i32 %op2608, ptr %slot361, align 8
  %v2609 = load i32, ptr %slot361, align 8
  %cv2610 = zext i32 %v2609 to i64
  %cond2611 = icmp ne i64 %cv2610, 0
  br i1 %cond2611, label %bb_rcslotrole441, label %bb_rcslotowner441
bb_rcslotrole441:
  %v2612 = load i64, ptr %slot41, align 8
  store i64 %v2612, ptr %slot362, align 8
  %v2613 = load i64, ptr %slot359, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  %ld2615 = load i64, ptr %p2614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2615, ptr %slot363, align 8
  %v2616 = load i64, ptr %slot363, align 8
  %cmp2617 = icmp ne i64 %v2616, 0
  %cv2618 = zext i1 %cmp2617 to i32
  store i32 %cv2618, ptr %slot364, align 8
  %v2619 = load i32, ptr %slot364, align 8
  %cv2620 = zext i32 %v2619 to i64
  %cond2621 = icmp ne i64 %cv2620, 0
  br i1 %cond2621, label %bb_rcgnn457, label %bb_rcgdone457
bb_rcgnn457:
  %v2622 = load i64, ptr %slot363, align 8
  %op2623 = sub i64 %v2622, 16
  store i64 %op2623, ptr %slot365, align 8
  %v2624 = load i64, ptr %slot363, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  %rgep2626 = getelementptr i8, ptr %p2625, i64 -16
  %ld2627 = load i64, ptr %rgep2626, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2627, ptr %slot366, align 8
  %v2628 = load i64, ptr %slot366, align 8
  %op2629 = and i64 %v2628, 4611686018427387906
  store i64 %op2629, ptr %slot367, align 8
  %v2630 = load i64, ptr %slot367, align 8
  %cmp2631 = icmp ne i64 %v2630, 0
  %cv2632 = zext i1 %cmp2631 to i32
  store i32 %cv2632, ptr %slot368, align 8
  %v2633 = load i32, ptr %slot368, align 8
  %cv2634 = zext i32 %v2633 to i64
  %cond2635 = icmp ne i64 %cv2634, 0
  br i1 %cond2635, label %bb_rcgclear457, label %bb_rcgcounted457
bb_rcgcounted457:
  %v2636 = load i64, ptr %slot363, align 8
  %op2637 = sub i64 %v2636, 24
  store i64 %op2637, ptr %slot369, align 8
  %v2638 = load i64, ptr %slot363, align 8
  %p2639 = inttoptr i64 %v2638 to ptr
  %rgep2640 = getelementptr i8, ptr %p2639, i64 -24
  %ld2641 = load i64, ptr %rgep2640, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2641, ptr %slot370, align 8
  %v2642 = load i64, ptr %slot370, align 8
  %op2643 = sub i64 %v2642, 1
  store i64 %op2643, ptr %slot371, align 8
  %v2644 = load i64, ptr %slot371, align 8
  %cmp2645 = icmp eq i64 %v2644, 0
  %cv2646 = zext i1 %cmp2645 to i32
  store i32 %cv2646, ptr %slot372, align 8
  %v2647 = load i32, ptr %slot372, align 8
  %cv2648 = zext i32 %v2647 to i64
  %cond2649 = icmp ne i64 %cv2648, 0
  br i1 %cond2649, label %bb_rcglast457, label %bb_rcgdec457
bb_rcglast457:
  %v2650 = load i64, ptr %slot363, align 8
  %op2651 = sub i64 %v2650, 32
  store i64 %op2651, ptr %slot373, align 8
  %v2652 = load i64, ptr %slot363, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  %rgep2654 = getelementptr i8, ptr %p2653, i64 -32
  %ld2655 = load i64, ptr %rgep2654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2655, ptr %slot374, align 8
  %v2656 = load i64, ptr %slot374, align 8
  %cmp2657 = icmp ne i64 %v2656, 0
  %cv2658 = zext i1 %cmp2657 to i32
  store i32 %cv2658, ptr %slot375, align 8
  %v2659 = load i32, ptr %slot375, align 8
  %cv2660 = zext i32 %v2659 to i64
  %cond2661 = icmp ne i64 %cv2660, 0
  br i1 %cond2661, label %bb_rcgdec457, label %bb_rcgslow457
bb_rcgslow457:
  %v2662 = load i64, ptr %slot362, align 8
  %v2663 = load i64, ptr %slot359, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_unloan(i64 %v2662, i64 %v2663) nomerge, !dbg !122
  br label %bb_rcgdone457
bb_rcgdec457:
  %v2664 = load i64, ptr %slot371, align 8
  %v2665 = load i64, ptr %slot363, align 8
  %p2666 = inttoptr i64 %v2665 to ptr
  %rgep2667 = getelementptr i8, ptr %p2666, i64 -24
  store i64 %v2664, ptr %rgep2667, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear457
bb_rcgclear457:
  %v2668 = load i64, ptr %slot359, align 8
  %p2669 = inttoptr i64 %v2668 to ptr
  store i64 0, ptr %p2669, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone457
bb_rcgdone457:
  br label %bb_rcslotdone441
bb_rcslotowner441:
  %v2670 = load i64, ptr %slot41, align 8
  store i64 %v2670, ptr %slot376, align 8
  %v2671 = load i64, ptr %slot359, align 8
  %p2672 = inttoptr i64 %v2671 to ptr
  %ld2673 = load i64, ptr %p2672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2673, ptr %slot377, align 8
  %v2674 = load i64, ptr %slot377, align 8
  %cmp2675 = icmp ne i64 %v2674, 0
  %cv2676 = zext i1 %cmp2675 to i32
  store i32 %cv2676, ptr %slot378, align 8
  %v2677 = load i32, ptr %slot378, align 8
  %cv2678 = zext i32 %v2677 to i64
  %cond2679 = icmp ne i64 %cv2678, 0
  br i1 %cond2679, label %bb_rcgnn472, label %bb_rcgdone472
bb_rcgnn472:
  %v2680 = load i64, ptr %slot377, align 8
  %op2681 = sub i64 %v2680, 16
  store i64 %op2681, ptr %slot379, align 8
  %v2682 = load i64, ptr %slot377, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  %rgep2684 = getelementptr i8, ptr %p2683, i64 -16
  %ld2685 = load i64, ptr %rgep2684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2685, ptr %slot380, align 8
  %v2686 = load i64, ptr %slot380, align 8
  %op2687 = and i64 %v2686, 4611686018427387906
  store i64 %op2687, ptr %slot381, align 8
  %v2688 = load i64, ptr %slot381, align 8
  %cmp2689 = icmp ne i64 %v2688, 0
  %cv2690 = zext i1 %cmp2689 to i32
  store i32 %cv2690, ptr %slot382, align 8
  %v2691 = load i32, ptr %slot382, align 8
  %cv2692 = zext i32 %v2691 to i64
  %cond2693 = icmp ne i64 %cv2692, 0
  br i1 %cond2693, label %bb_rcgclear472, label %bb_rcgcounted472
bb_rcgcounted472:
  %v2694 = load i64, ptr %slot377, align 8
  %op2695 = sub i64 %v2694, 32
  store i64 %op2695, ptr %slot383, align 8
  %v2696 = load i64, ptr %slot377, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  %rgep2698 = getelementptr i8, ptr %p2697, i64 -32
  %ld2699 = load i64, ptr %rgep2698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2699, ptr %slot384, align 8
  %v2700 = load i64, ptr %slot384, align 8
  %op2701 = sub i64 %v2700, 1
  store i64 %op2701, ptr %slot385, align 8
  %v2702 = load i64, ptr %slot385, align 8
  %cmp2703 = icmp eq i64 %v2702, 0
  %cv2704 = zext i1 %cmp2703 to i32
  store i32 %cv2704, ptr %slot386, align 8
  %v2705 = load i32, ptr %slot386, align 8
  %cv2706 = zext i32 %v2705 to i64
  %cond2707 = icmp ne i64 %cv2706, 0
  br i1 %cond2707, label %bb_rcglast472, label %bb_rcgdec472
bb_rcglast472:
  %v2708 = load i64, ptr %slot377, align 8
  %op2709 = sub i64 %v2708, 24
  store i64 %op2709, ptr %slot387, align 8
  %v2710 = load i64, ptr %slot377, align 8
  %p2711 = inttoptr i64 %v2710 to ptr
  %rgep2712 = getelementptr i8, ptr %p2711, i64 -24
  %ld2713 = load i64, ptr %rgep2712, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2713, ptr %slot388, align 8
  %v2714 = load i64, ptr %slot388, align 8
  %cmp2715 = icmp ne i64 %v2714, 0
  %cv2716 = zext i1 %cmp2715 to i32
  store i32 %cv2716, ptr %slot389, align 8
  %v2717 = load i32, ptr %slot389, align 8
  %cv2718 = zext i32 %v2717 to i64
  %cond2719 = icmp ne i64 %cv2718, 0
  br i1 %cond2719, label %bb_rcgdec472, label %bb_rcgslow472
bb_rcgslow472:
  %v2720 = load i64, ptr %slot376, align 8
  %v2721 = load i64, ptr %slot359, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64 %v2720, i64 %v2721) nomerge, !dbg !122
  br label %bb_rcgdone472
bb_rcgdec472:
  %v2722 = load i64, ptr %slot385, align 8
  %v2723 = load i64, ptr %slot377, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  %rgep2725 = getelementptr i8, ptr %p2724, i64 -32
  store i64 %v2722, ptr %rgep2725, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear472
bb_rcgclear472:
  %v2726 = load i64, ptr %slot359, align 8
  %p2727 = inttoptr i64 %v2726 to ptr
  store i64 0, ptr %p2727, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone472
bb_rcgdone472:
  br label %bb_rcslotdone441
bb_rcslotdone441:
  %v2728 = load i64, ptr %slot34, align 8
  store i64 %v2728, ptr %slot390, align 8
  %v2729 = load i64, ptr %slot31, align 8
  store i64 %v2729, ptr %slot391, align 8
  %v2730 = load i64, ptr %slot391, align 8
  %v2731 = load i64, ptr %slot390, align 8
  %p2732 = inttoptr i64 %v2730 to ptr
  %p2733 = inttoptr i64 %v2731 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2733, ptr %p2732, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2734 = load i64, ptr %slot20, align 8
  %p2735 = inttoptr i64 %v2734 to ptr
  store i32 0, ptr %p2735, align 4, !alias.scope !3, !noalias !4
  %v2736 = load i64, ptr %slot9, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  store i32 2, ptr %p2737, align 4, !alias.scope !3, !noalias !4
  %v2738 = load i64, ptr %slot21, align 8
  %p2739 = inttoptr i64 %v2738 to ptr
  %ld2740 = load i32, ptr %p2739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2740, ptr %slot392, align 8
  %v2741 = load i32, ptr %slot392, align 8
  %v2742 = load i64, ptr %slot9, align 8
  %p2743 = inttoptr i64 %v2742 to ptr
  store i32 %v2741, ptr %p2743, align 4, !alias.scope !3, !noalias !4
  %v2744 = load i64, ptr %slot8, align 8
  %p2745 = inttoptr i64 %v2744 to ptr
  store i32 1, ptr %p2745, align 4, !alias.scope !3, !noalias !4
  %v2746 = load i64, ptr %slot34, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  %ld2748 = load i64, ptr %p2747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2748, ptr %slot393, align 8
  %v2749 = load i64, ptr %slot393, align 8
  %v2750 = load i64, ptr %slot38, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  store i64 %v2749, ptr %p2751, align 8, !alias.scope !3, !noalias !4
  %v2752 = load i64, ptr %slot39, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  store i64 0, ptr %p2753, align 8, !alias.scope !3, !noalias !4
  %v2754 = load i64, ptr %slot39, align 8
  %p2755 = inttoptr i64 %v2754 to ptr
  %ld2756 = load i64, ptr %p2755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2756, ptr %slot394, align 8
  %v2757 = load i64, ptr %slot394, align 8
  %cmp2758 = icmp sge i64 %v2757, 0
  %cv2759 = zext i1 %cmp2758 to i64
  store i64 %cv2759, ptr %slot395, align 8
  %v2760 = load i64, ptr %slot395, align 8
  %cond2761 = icmp ne i64 %v2760, 0
  br i1 %cond2761, label %bb_success486, label %bb_failed486
bb_failed486:
  %v2762 = load i64, ptr %slot1, align 8
  %p2763 = inttoptr i64 %v2762 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p2763) nomerge, !dbg !124
  unreachable
bb_success486:
  %v2764 = load i64, ptr %slot41, align 8
  %p2765 = inttoptr i64 %v2764 to ptr
  %p2766 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v2767 = load i64, ptr %slot394, align 8
  %call2768 = call ptr @myl_native_list_new(ptr %p2765, ptr %p2766, i64 %v2767) nomerge, !dbg !124
  %calladdr2769 = ptrtoint ptr %call2768 to i64
  store i64 %calladdr2769, ptr %slot396, align 8
  %v2770 = load i64, ptr %slot396, align 8
  %cond2771 = icmp ne i64 %v2770, 0
  br i1 %cond2771, label %bb_success488, label %bb_failed488
bb_failed488:
  %v2772 = load i64, ptr %slot1, align 8
  %p2773 = inttoptr i64 %v2772 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2773) nomerge, !dbg !124
  unreachable
bb_success488:
  %v2774 = load i64, ptr %slot396, align 8
  %v2775 = load i64, ptr %slot39, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  store i64 %v2774, ptr %p2776, align 8, !alias.scope !3, !noalias !4
  %v2777 = load i64, ptr %slot39, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  %ld2779 = load i64, ptr %p2778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2779, ptr %slot397, align 8
  %v2780 = load i64, ptr %slot397, align 8
  %v2781 = load i64, ptr %slot30, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  store i64 %v2780, ptr %p2782, align 8, !alias.scope !3, !noalias !4
  %v2783 = load i64, ptr %slot30, align 8
  store i64 %v2783, ptr %slot398, align 8
  %v2784 = load i64, ptr %slot31, align 8
  store i64 %v2784, ptr %slot399, align 8
  %v2785 = load i64, ptr %slot398, align 8
  %v2786 = load i64, ptr %slot399, align 8
  %p2787 = inttoptr i64 %v2785 to ptr
  %p2788 = inttoptr i64 %v2786 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2788, ptr %p2787, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2789 = load i64, ptr %slot21, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  store i32 2, ptr %p2790, align 4, !alias.scope !3, !noalias !4
  %v2791 = load i64, ptr %slot20, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  store i32 1, ptr %p2792, align 4, !alias.scope !3, !noalias !4
  %v2793 = load i64, ptr %slot26, align 8
  store i64 %v2793, ptr %slot400, align 8
  %v2794 = load i64, ptr %slot31, align 8
  store i64 %v2794, ptr %slot401, align 8
  %v2795 = load i64, ptr %slot401, align 8
  %v2796 = load i64, ptr %slot400, align 8
  %p2797 = inttoptr i64 %v2795 to ptr
  %p2798 = inttoptr i64 %v2796 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2798, ptr %p2797, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2799 = load i64, ptr %slot19, align 8
  %p2800 = inttoptr i64 %v2799 to ptr
  store i32 2, ptr %p2800, align 4, !alias.scope !3, !noalias !4
  %v2801 = load i64, ptr %slot21, align 8
  %p2802 = inttoptr i64 %v2801 to ptr
  %ld2803 = load i32, ptr %p2802, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2803, ptr %slot402, align 8
  %v2804 = load i32, ptr %slot402, align 8
  %v2805 = load i64, ptr %slot19, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  store i32 %v2804, ptr %p2806, align 4, !alias.scope !3, !noalias !4
  %v2807 = load i64, ptr %slot20, align 8
  %p2808 = inttoptr i64 %v2807 to ptr
  store i32 0, ptr %p2808, align 4, !alias.scope !3, !noalias !4
  %v2809 = load i64, ptr %slot18, align 8
  %p2810 = inttoptr i64 %v2809 to ptr
  store i32 1, ptr %p2810, align 4, !alias.scope !3, !noalias !4
  %v2811 = load i64, ptr %slot400, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  %ld2813 = load i64, ptr %p2812, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2813, ptr %slot403, align 8
  %v2814 = load i64, ptr %slot403, align 8
  %v2815 = load i64, ptr %slot39, align 8
  %p2816 = inttoptr i64 %v2815 to ptr
  store i64 %v2814, ptr %p2816, align 8, !alias.scope !3, !noalias !4
  %v2817 = load i64, ptr %slot39, align 8
  %p2818 = inttoptr i64 %v2817 to ptr
  %ld2819 = load i64, ptr %p2818, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2819, ptr %slot404, align 8
  %v2820 = load i64, ptr %slot404, align 8
  %v2821 = load i64, ptr %slot30, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  store i64 %v2820, ptr %p2822, align 8, !alias.scope !3, !noalias !4
  %v2823 = load i64, ptr %slot30, align 8
  store i64 %v2823, ptr %slot405, align 8
  %v2824 = load i64, ptr %slot18, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  %ld2826 = load i32, ptr %p2825, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2826, ptr %slot406, align 8
  %v2827 = load i64, ptr %slot19, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  %ld2829 = load i32, ptr %p2828, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2829, ptr %slot407, align 8
  %v2830 = load i32, ptr %slot407, align 8
  %op2831 = and i32 %v2830, 24
  store i32 %op2831, ptr %slot407, align 8
  %v2832 = load i32, ptr %slot407, align 8
  %cmp2833 = icmp eq i32 %v2832, 0
  %cv2834 = zext i1 %cmp2833 to i32
  store i32 %cv2834, ptr %slot408, align 8
  %v2835 = load i32, ptr %slot406, align 8
  %v2836 = load i32, ptr %slot408, align 8
  %op2837 = and i32 %v2835, %v2836
  store i32 %op2837, ptr %slot409, align 8
  %v2838 = load i32, ptr %slot409, align 8
  %cv2839 = zext i32 %v2838 to i64
  %cond2840 = icmp ne i64 %cv2839, 0
  br i1 %cond2840, label %bb_rcprivateown511, label %bb_rcprivateloan511
bb_rcprivateown511:
  %v2841 = load i64, ptr %slot31, align 8
  store i64 %v2841, ptr %slot410, align 8
  %v2842 = load i64, ptr %slot42, align 8
  store i64 %v2842, ptr %slot411, align 8
  %v2843 = load i64, ptr %slot405, align 8
  %v2844 = load i64, ptr %slot410, align 8
  %op2845 = sub i64 %v2843, %v2844
  store i64 %op2845, ptr %slot412, align 8
  %v2846 = load i64, ptr %slot410, align 8
  %v2847 = load i64, ptr %slot405, align 8
  %op2848 = sub i64 %v2846, %v2847
  store i64 %op2848, ptr %slot413, align 8
  %v2849 = load i64, ptr %slot412, align 8
  %cmp2850 = icmp ult i64 %v2849, 8
  %cv2851 = zext i1 %cmp2850 to i32
  store i32 %cv2851, ptr %slot414, align 8
  %v2852 = load i64, ptr %slot413, align 8
  %cmp2853 = icmp ult i64 %v2852, 8
  %cv2854 = zext i1 %cmp2853 to i32
  store i32 %cv2854, ptr %slot415, align 8
  %v2855 = load i32, ptr %slot414, align 8
  %v2856 = load i32, ptr %slot415, align 8
  %op2857 = or i32 %v2855, %v2856
  store i32 %op2857, ptr %slot416, align 8
  %v2858 = load i32, ptr %slot416, align 8
  %cv2859 = zext i32 %v2858 to i64
  %cond2860 = icmp ne i64 %cv2859, 0
  br i1 %cond2860, label %bb_rcmoveslow514, label %bb_rcmovecheck514
bb_rcmovecheck514:
  %v2861 = load i64, ptr %slot405, align 8
  %p2863 = inttoptr i64 %v2861 to ptr
  %gep2864 = getelementptr i8, ptr %p2863, i64 0
  %op2862 = ptrtoint ptr %gep2864 to i64
  store i64 %op2862, ptr %slot417, align 8
  %v2865 = load i64, ptr %slot417, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  %ld2867 = load i64, ptr %p2866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2867, ptr %slot418, align 8
  %v2868 = load i64, ptr %slot418, align 8
  %cmp2869 = icmp ne i64 %v2868, 0
  %cv2870 = zext i1 %cmp2869 to i32
  store i32 %cv2870, ptr %slot419, align 8
  %v2871 = load i32, ptr %slot419, align 8
  %cv2872 = zext i32 %v2871 to i64
  %cond2873 = icmp ne i64 %cv2872, 0
  br i1 %cond2873, label %bb_rcmoveheader522, label %bb_rcmovenext522
bb_rcmoveheader522:
  %v2874 = load i64, ptr %slot418, align 8
  %op2875 = sub i64 %v2874, 16
  store i64 %op2875, ptr %slot420, align 8
  %v2876 = load i64, ptr %slot418, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  %rgep2878 = getelementptr i8, ptr %p2877, i64 -16
  %ld2879 = load i64, ptr %rgep2878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2879, ptr %slot421, align 8
  %v2880 = load i64, ptr %slot421, align 8
  %op2881 = and i64 %v2880, 5764607523034234881
  store i64 %op2881, ptr %slot422, align 8
  %v2882 = load i64, ptr %slot422, align 8
  %cmp2883 = icmp ne i64 %v2882, 0
  %cv2884 = zext i1 %cmp2883 to i32
  store i32 %cv2884, ptr %slot423, align 8
  %v2885 = load i32, ptr %slot423, align 8
  %cv2886 = zext i32 %v2885 to i64
  %cond2887 = icmp ne i64 %cv2886, 0
  br i1 %cond2887, label %bb_rcmoveslow514, label %bb_rcmovenext522
bb_rcmovenext522:
  %v2888 = load i64, ptr %slot405, align 8
  %v2889 = load i64, ptr %slot410, align 8
  %p2890 = inttoptr i64 %v2888 to ptr
  %p2891 = inttoptr i64 %v2889 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2891, ptr %p2890, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2892 = load i64, ptr %slot405, align 8
  %p2893 = inttoptr i64 %v2892 to ptr
  store i64 0, ptr %p2893, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved514
bb_rcmoveslow514:
  %v2894 = load i64, ptr %slot41, align 8
  %v2895 = load i64, ptr %slot410, align 8
  %v2896 = load i64, ptr %slot405, align 8
  %v2897 = load i64, ptr %slot411, align 8
  %cv2898 = trunc i64 %v2897 to i32
  %call2899 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v2894, i64 %v2895, i64 %v2896, i32 %cv2898) nomerge, !dbg !126
  store i32 %call2899, ptr %slot424, align 8
  %v2900 = load i32, ptr %slot424, align 8
  %cv2901 = zext i32 %v2900 to i64
  %cond2902 = icmp ne i64 %cv2901, 0
  br i1 %cond2902, label %bb_rcsuccess529, label %bb_rcfailure529
bb_rcfailure529:
  %v2903 = load i64, ptr %slot41, align 8
  %p2904 = inttoptr i64 %v2903 to ptr
  %call2905 = call i32 @myl_rc_take_failure(ptr %p2904) nomerge, !dbg !126
  store i32 %call2905, ptr %slot425, align 8
  %v2906 = load i64, ptr %slot1, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  %v2908 = load i32, ptr %slot425, align 8
  %call2909 = call i32 @myl_qbe_rc_status(ptr %p2907, i32 %v2908) nomerge, !dbg !126
  store i32 %call2909, ptr %slot426, align 8
  br label %bb_failure
bb_rcsuccess529:
  br label %bb_rcmoved514
bb_rcmoved514:
  %v2910 = load i64, ptr %slot18, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  store i32 0, ptr %p2911, align 4, !alias.scope !3, !noalias !4
  %v2912 = load i64, ptr %slot21, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  store i32 2, ptr %p2913, align 4, !alias.scope !3, !noalias !4
  %v2914 = load i64, ptr %slot20, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  store i32 1, ptr %p2915, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared511
bb_rcprivateloan511:
  %v2916 = load i64, ptr %slot18, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  %ld2918 = load i32, ptr %p2917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2918, ptr %slot427, align 8
  %v2919 = load i64, ptr %slot19, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  %ld2921 = load i32, ptr %p2920, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2921, ptr %slot428, align 8
  %v2922 = load i32, ptr %slot428, align 8
  %cmp2923 = icmp eq i32 %v2922, 16
  %cv2924 = zext i1 %cmp2923 to i32
  store i32 %cv2924, ptr %slot429, align 8
  %v2925 = load i32, ptr %slot429, align 8
  %v2926 = load i32, ptr %slot427, align 8
  %op2927 = and i32 %v2925, %v2926
  store i32 %op2927, ptr %slot429, align 8
  %v2928 = load i32, ptr %slot429, align 8
  %cv2929 = zext i32 %v2928 to i64
  %cond2930 = icmp ne i64 %cv2929, 0
  br i1 %cond2930, label %bb_rcprivatemove511, label %bb_rcprivatenew511
bb_rcprivatemove511:
  %v2931 = load i64, ptr %slot31, align 8
  store i64 %v2931, ptr %slot430, align 8
  %v2932 = load i64, ptr %slot405, align 8
  %v2933 = load i64, ptr %slot430, align 8
  %p2934 = inttoptr i64 %v2932 to ptr
  %p2935 = inttoptr i64 %v2933 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2935, ptr %p2934, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2936 = load i64, ptr %slot405, align 8
  %p2937 = inttoptr i64 %v2936 to ptr
  store i64 0, ptr %p2937, align 8, !alias.scope !3, !noalias !4
  %v2938 = load i64, ptr %slot21, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  store i32 2, ptr %p2939, align 4, !alias.scope !3, !noalias !4
  %v2940 = load i64, ptr %slot21, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  store i32 16, ptr %p2941, align 4, !alias.scope !3, !noalias !4
  %v2942 = load i64, ptr %slot20, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  store i32 1, ptr %p2943, align 4, !alias.scope !3, !noalias !4
  %v2944 = load i64, ptr %slot18, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  store i32 0, ptr %p2945, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared511
bb_rcprivatenew511:
  %v2946 = load i64, ptr %slot31, align 8
  store i64 %v2946, ptr %slot431, align 8
  %v2947 = load i64, ptr %slot405, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  %ld2949 = load i64, ptr %p2948, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2949, ptr %slot432, align 8
  %v2950 = load i64, ptr %slot432, align 8
  %cmp2951 = icmp ne i64 %v2950, 0
  %cv2952 = zext i1 %cmp2951 to i32
  store i32 %cv2952, ptr %slot433, align 8
  %v2953 = load i32, ptr %slot433, align 8
  %cv2954 = zext i32 %v2953 to i64
  %cond2955 = icmp ne i64 %cv2954, 0
  br i1 %cond2955, label %bb_rcgnn547, label %bb_rcgstore547
bb_rcgnn547:
  %v2956 = load i64, ptr %slot432, align 8
  %op2957 = sub i64 %v2956, 16
  store i64 %op2957, ptr %slot434, align 8
  %v2958 = load i64, ptr %slot432, align 8
  %p2959 = inttoptr i64 %v2958 to ptr
  %rgep2960 = getelementptr i8, ptr %p2959, i64 -16
  %ld2961 = load i64, ptr %rgep2960, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2961, ptr %slot435, align 8
  %v2962 = load i64, ptr %slot435, align 8
  %op2963 = and i64 %v2962, 4611686018427387906
  store i64 %op2963, ptr %slot436, align 8
  %v2964 = load i64, ptr %slot436, align 8
  %cmp2965 = icmp ne i64 %v2964, 0
  %cv2966 = zext i1 %cmp2965 to i32
  store i32 %cv2966, ptr %slot437, align 8
  %v2967 = load i32, ptr %slot437, align 8
  %cv2968 = zext i32 %v2967 to i64
  %cond2969 = icmp ne i64 %cv2968, 0
  br i1 %cond2969, label %bb_rcgstore547, label %bb_rcginc547
bb_rcginc547:
  %v2970 = load i64, ptr %slot432, align 8
  %op2971 = sub i64 %v2970, 24
  store i64 %op2971, ptr %slot438, align 8
  %v2972 = load i64, ptr %slot432, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  %rgep2974 = getelementptr i8, ptr %p2973, i64 -24
  %ld2975 = load i64, ptr %rgep2974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2975, ptr %slot439, align 8
  %v2976 = load i64, ptr %slot439, align 8
  %op2977 = add i64 %v2976, 1
  store i64 %op2977, ptr %slot440, align 8
  %v2978 = load i64, ptr %slot440, align 8
  %cmp2979 = icmp eq i64 %v2978, 0
  %cv2980 = zext i1 %cmp2979 to i32
  store i32 %cv2980, ptr %slot441, align 8
  %v2981 = load i32, ptr %slot441, align 8
  %cv2982 = zext i32 %v2981 to i64
  %cond2983 = icmp ne i64 %cv2982, 0
  br i1 %cond2983, label %bb_rcglimit547, label %bb_rcgcapacity547
bb_rcglimit547:
  %v2984 = load i64, ptr %slot1, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  %call2986 = call i32 @myl_qbe_rc_status(ptr %p2985, i32 2) nomerge, !dbg !126
  store i32 %call2986, ptr %slot442, align 8
  br label %bb_failure
bb_rcgcapacity547:
  %v2987 = load i64, ptr %slot440, align 8
  %v2988 = load i64, ptr %slot432, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  %rgep2990 = getelementptr i8, ptr %p2989, i64 -24
  store i64 %v2987, ptr %rgep2990, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore547
bb_rcgstore547:
  %v2991 = load i64, ptr %slot432, align 8
  %v2992 = load i64, ptr %slot431, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  store i64 %v2991, ptr %p2993, align 8, !alias.scope !3, !noalias !4
  %v2994 = load i64, ptr %slot21, align 8
  %p2995 = inttoptr i64 %v2994 to ptr
  store i32 2, ptr %p2995, align 4, !alias.scope !3, !noalias !4
  %v2996 = load i64, ptr %slot21, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  store i32 16, ptr %p2997, align 4, !alias.scope !3, !noalias !4
  %v2998 = load i64, ptr %slot20, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  store i32 1, ptr %p2999, align 4, !alias.scope !3, !noalias !4
  %v3000 = load i64, ptr %slot18, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  %ld3002 = load i32, ptr %p3001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3002, ptr %slot443, align 8
  %v3003 = load i32, ptr %slot443, align 8
  %cv3004 = zext i32 %v3003 to i64
  %cond3005 = icmp ne i64 %cv3004, 0
  br i1 %cond3005, label %bb_rcslotdrop563, label %bb_rcslotdone563
bb_rcslotdrop563:
  %v3006 = load i64, ptr %slot18, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i32 0, ptr %p3007, align 4, !alias.scope !3, !noalias !4
  %v3008 = load i64, ptr %slot26, align 8
  store i64 %v3008, ptr %slot444, align 8
  %v3009 = load i64, ptr %slot19, align 8
  %p3010 = inttoptr i64 %v3009 to ptr
  %ld3011 = load i32, ptr %p3010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3011, ptr %slot445, align 8
  %v3012 = load i32, ptr %slot445, align 8
  %op3013 = and i32 %v3012, 28
  store i32 %op3013, ptr %slot446, align 8
  %v3014 = load i32, ptr %slot446, align 8
  %cv3015 = zext i32 %v3014 to i64
  %cond3016 = icmp ne i64 %cv3015, 0
  br i1 %cond3016, label %bb_rcslotrole563, label %bb_rcslotowner563
bb_rcslotrole563:
  %v3017 = load i64, ptr %slot41, align 8
  store i64 %v3017, ptr %slot447, align 8
  %v3018 = load i64, ptr %slot444, align 8
  %p3019 = inttoptr i64 %v3018 to ptr
  %ld3020 = load i64, ptr %p3019, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3020, ptr %slot448, align 8
  %v3021 = load i64, ptr %slot448, align 8
  %cmp3022 = icmp ne i64 %v3021, 0
  %cv3023 = zext i1 %cmp3022 to i32
  store i32 %cv3023, ptr %slot449, align 8
  %v3024 = load i32, ptr %slot449, align 8
  %cv3025 = zext i32 %v3024 to i64
  %cond3026 = icmp ne i64 %cv3025, 0
  br i1 %cond3026, label %bb_rcgnn579, label %bb_rcgdone579
bb_rcgnn579:
  %v3027 = load i64, ptr %slot448, align 8
  %op3028 = sub i64 %v3027, 16
  store i64 %op3028, ptr %slot450, align 8
  %v3029 = load i64, ptr %slot448, align 8
  %p3030 = inttoptr i64 %v3029 to ptr
  %rgep3031 = getelementptr i8, ptr %p3030, i64 -16
  %ld3032 = load i64, ptr %rgep3031, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3032, ptr %slot451, align 8
  %v3033 = load i64, ptr %slot451, align 8
  %op3034 = and i64 %v3033, 4611686018427387906
  store i64 %op3034, ptr %slot452, align 8
  %v3035 = load i64, ptr %slot452, align 8
  %cmp3036 = icmp ne i64 %v3035, 0
  %cv3037 = zext i1 %cmp3036 to i32
  store i32 %cv3037, ptr %slot453, align 8
  %v3038 = load i32, ptr %slot453, align 8
  %cv3039 = zext i32 %v3038 to i64
  %cond3040 = icmp ne i64 %cv3039, 0
  br i1 %cond3040, label %bb_rcgclear579, label %bb_rcgcounted579
bb_rcgcounted579:
  %v3041 = load i64, ptr %slot448, align 8
  %op3042 = sub i64 %v3041, 24
  store i64 %op3042, ptr %slot454, align 8
  %v3043 = load i64, ptr %slot448, align 8
  %p3044 = inttoptr i64 %v3043 to ptr
  %rgep3045 = getelementptr i8, ptr %p3044, i64 -24
  %ld3046 = load i64, ptr %rgep3045, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3046, ptr %slot455, align 8
  %v3047 = load i64, ptr %slot455, align 8
  %op3048 = sub i64 %v3047, 1
  store i64 %op3048, ptr %slot456, align 8
  %v3049 = load i64, ptr %slot456, align 8
  %cmp3050 = icmp eq i64 %v3049, 0
  %cv3051 = zext i1 %cmp3050 to i32
  store i32 %cv3051, ptr %slot457, align 8
  %v3052 = load i32, ptr %slot457, align 8
  %cv3053 = zext i32 %v3052 to i64
  %cond3054 = icmp ne i64 %cv3053, 0
  br i1 %cond3054, label %bb_rcglast579, label %bb_rcgdec579
bb_rcglast579:
  %v3055 = load i64, ptr %slot448, align 8
  %op3056 = sub i64 %v3055, 32
  store i64 %op3056, ptr %slot458, align 8
  %v3057 = load i64, ptr %slot448, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  %rgep3059 = getelementptr i8, ptr %p3058, i64 -32
  %ld3060 = load i64, ptr %rgep3059, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3060, ptr %slot459, align 8
  %v3061 = load i64, ptr %slot459, align 8
  %cmp3062 = icmp ne i64 %v3061, 0
  %cv3063 = zext i1 %cmp3062 to i32
  store i32 %cv3063, ptr %slot460, align 8
  %v3064 = load i32, ptr %slot460, align 8
  %cv3065 = zext i32 %v3064 to i64
  %cond3066 = icmp ne i64 %cv3065, 0
  br i1 %cond3066, label %bb_rcgdec579, label %bb_rcgslow579
bb_rcgslow579:
  %v3067 = load i64, ptr %slot447, align 8
  %v3068 = load i64, ptr %slot444, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3067, i64 %v3068) nomerge, !dbg !126
  br label %bb_rcgdone579
bb_rcgdec579:
  %v3069 = load i64, ptr %slot456, align 8
  %v3070 = load i64, ptr %slot448, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  %rgep3072 = getelementptr i8, ptr %p3071, i64 -24
  store i64 %v3069, ptr %rgep3072, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear579
bb_rcgclear579:
  %v3073 = load i64, ptr %slot444, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  store i64 0, ptr %p3074, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone579
bb_rcgdone579:
  br label %bb_rcslotdone563
bb_rcslotowner563:
  %v3075 = load i64, ptr %slot41, align 8
  store i64 %v3075, ptr %slot461, align 8
  %v3076 = load i64, ptr %slot444, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  %ld3078 = load i64, ptr %p3077, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3078, ptr %slot462, align 8
  %v3079 = load i64, ptr %slot462, align 8
  %cmp3080 = icmp ne i64 %v3079, 0
  %cv3081 = zext i1 %cmp3080 to i32
  store i32 %cv3081, ptr %slot463, align 8
  %v3082 = load i32, ptr %slot463, align 8
  %cv3083 = zext i32 %v3082 to i64
  %cond3084 = icmp ne i64 %cv3083, 0
  br i1 %cond3084, label %bb_rcgnn594, label %bb_rcgdone594
bb_rcgnn594:
  %v3085 = load i64, ptr %slot462, align 8
  %op3086 = sub i64 %v3085, 16
  store i64 %op3086, ptr %slot464, align 8
  %v3087 = load i64, ptr %slot462, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  %rgep3089 = getelementptr i8, ptr %p3088, i64 -16
  %ld3090 = load i64, ptr %rgep3089, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3090, ptr %slot465, align 8
  %v3091 = load i64, ptr %slot465, align 8
  %op3092 = and i64 %v3091, 4611686018427387906
  store i64 %op3092, ptr %slot466, align 8
  %v3093 = load i64, ptr %slot466, align 8
  %cmp3094 = icmp ne i64 %v3093, 0
  %cv3095 = zext i1 %cmp3094 to i32
  store i32 %cv3095, ptr %slot467, align 8
  %v3096 = load i32, ptr %slot467, align 8
  %cv3097 = zext i32 %v3096 to i64
  %cond3098 = icmp ne i64 %cv3097, 0
  br i1 %cond3098, label %bb_rcgclear594, label %bb_rcgcounted594
bb_rcgcounted594:
  %v3099 = load i64, ptr %slot462, align 8
  %op3100 = sub i64 %v3099, 32
  store i64 %op3100, ptr %slot468, align 8
  %v3101 = load i64, ptr %slot462, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %rgep3103 = getelementptr i8, ptr %p3102, i64 -32
  %ld3104 = load i64, ptr %rgep3103, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3104, ptr %slot469, align 8
  %v3105 = load i64, ptr %slot469, align 8
  %op3106 = sub i64 %v3105, 1
  store i64 %op3106, ptr %slot470, align 8
  %v3107 = load i64, ptr %slot470, align 8
  %cmp3108 = icmp eq i64 %v3107, 0
  %cv3109 = zext i1 %cmp3108 to i32
  store i32 %cv3109, ptr %slot471, align 8
  %v3110 = load i32, ptr %slot471, align 8
  %cv3111 = zext i32 %v3110 to i64
  %cond3112 = icmp ne i64 %cv3111, 0
  br i1 %cond3112, label %bb_rcglast594, label %bb_rcgdec594
bb_rcglast594:
  %v3113 = load i64, ptr %slot462, align 8
  %op3114 = sub i64 %v3113, 24
  store i64 %op3114, ptr %slot472, align 8
  %v3115 = load i64, ptr %slot462, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  %rgep3117 = getelementptr i8, ptr %p3116, i64 -24
  %ld3118 = load i64, ptr %rgep3117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3118, ptr %slot473, align 8
  %v3119 = load i64, ptr %slot473, align 8
  %cmp3120 = icmp ne i64 %v3119, 0
  %cv3121 = zext i1 %cmp3120 to i32
  store i32 %cv3121, ptr %slot474, align 8
  %v3122 = load i32, ptr %slot474, align 8
  %cv3123 = zext i32 %v3122 to i64
  %cond3124 = icmp ne i64 %cv3123, 0
  br i1 %cond3124, label %bb_rcgdec594, label %bb_rcgslow594
bb_rcgslow594:
  %v3125 = load i64, ptr %slot461, align 8
  %v3126 = load i64, ptr %slot444, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3125, i64 %v3126) nomerge, !dbg !126
  br label %bb_rcgdone594
bb_rcgdec594:
  %v3127 = load i64, ptr %slot470, align 8
  %v3128 = load i64, ptr %slot462, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  %rgep3130 = getelementptr i8, ptr %p3129, i64 -32
  store i64 %v3127, ptr %rgep3130, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear594
bb_rcgclear594:
  %v3131 = load i64, ptr %slot444, align 8
  %p3132 = inttoptr i64 %v3131 to ptr
  store i64 0, ptr %p3132, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone594
bb_rcgdone594:
  br label %bb_rcslotdone563
bb_rcslotdone563:
  br label %bb_rcprivateprepared511
bb_rcprivateprepared511:
  %v3133 = load i64, ptr %slot10, align 8
  %p3134 = inttoptr i64 %v3133 to ptr
  %ld3135 = load i32, ptr %p3134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3135, ptr %slot475, align 8
  %v3136 = load i32, ptr %slot475, align 8
  %cv3137 = zext i32 %v3136 to i64
  %cond3138 = icmp ne i64 %cv3137, 0
  br i1 %cond3138, label %bb_rcslotdrop601, label %bb_rcslotdone601
bb_rcslotdrop601:
  %v3139 = load i64, ptr %slot10, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  store i32 0, ptr %p3140, align 4, !alias.scope !3, !noalias !4
  %v3141 = load i64, ptr %slot35, align 8
  store i64 %v3141, ptr %slot476, align 8
  %v3142 = load i64, ptr %slot11, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %ld3144 = load i32, ptr %p3143, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3144, ptr %slot477, align 8
  %v3145 = load i32, ptr %slot477, align 8
  %op3146 = and i32 %v3145, 28
  store i32 %op3146, ptr %slot478, align 8
  %v3147 = load i32, ptr %slot478, align 8
  %cv3148 = zext i32 %v3147 to i64
  %cond3149 = icmp ne i64 %cv3148, 0
  br i1 %cond3149, label %bb_rcslotrole601, label %bb_rcslotowner601
bb_rcslotrole601:
  %v3150 = load i64, ptr %slot41, align 8
  store i64 %v3150, ptr %slot479, align 8
  %v3151 = load i64, ptr %slot476, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %ld3153 = load i64, ptr %p3152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3153, ptr %slot480, align 8
  %v3154 = load i64, ptr %slot480, align 8
  %cmp3155 = icmp ne i64 %v3154, 0
  %cv3156 = zext i1 %cmp3155 to i32
  store i32 %cv3156, ptr %slot481, align 8
  %v3157 = load i32, ptr %slot481, align 8
  %cv3158 = zext i32 %v3157 to i64
  %cond3159 = icmp ne i64 %cv3158, 0
  br i1 %cond3159, label %bb_rcgnn617, label %bb_rcgdone617
bb_rcgnn617:
  %v3160 = load i64, ptr %slot480, align 8
  %op3161 = sub i64 %v3160, 16
  store i64 %op3161, ptr %slot482, align 8
  %v3162 = load i64, ptr %slot480, align 8
  %p3163 = inttoptr i64 %v3162 to ptr
  %rgep3164 = getelementptr i8, ptr %p3163, i64 -16
  %ld3165 = load i64, ptr %rgep3164, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3165, ptr %slot483, align 8
  %v3166 = load i64, ptr %slot483, align 8
  %op3167 = and i64 %v3166, 4611686018427387906
  store i64 %op3167, ptr %slot484, align 8
  %v3168 = load i64, ptr %slot484, align 8
  %cmp3169 = icmp ne i64 %v3168, 0
  %cv3170 = zext i1 %cmp3169 to i32
  store i32 %cv3170, ptr %slot485, align 8
  %v3171 = load i32, ptr %slot485, align 8
  %cv3172 = zext i32 %v3171 to i64
  %cond3173 = icmp ne i64 %cv3172, 0
  br i1 %cond3173, label %bb_rcgclear617, label %bb_rcgcounted617
bb_rcgcounted617:
  %v3174 = load i64, ptr %slot480, align 8
  %op3175 = sub i64 %v3174, 24
  store i64 %op3175, ptr %slot486, align 8
  %v3176 = load i64, ptr %slot480, align 8
  %p3177 = inttoptr i64 %v3176 to ptr
  %rgep3178 = getelementptr i8, ptr %p3177, i64 -24
  %ld3179 = load i64, ptr %rgep3178, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3179, ptr %slot487, align 8
  %v3180 = load i64, ptr %slot487, align 8
  %op3181 = sub i64 %v3180, 1
  store i64 %op3181, ptr %slot488, align 8
  %v3182 = load i64, ptr %slot488, align 8
  %cmp3183 = icmp eq i64 %v3182, 0
  %cv3184 = zext i1 %cmp3183 to i32
  store i32 %cv3184, ptr %slot489, align 8
  %v3185 = load i32, ptr %slot489, align 8
  %cv3186 = zext i32 %v3185 to i64
  %cond3187 = icmp ne i64 %cv3186, 0
  br i1 %cond3187, label %bb_rcglast617, label %bb_rcgdec617
bb_rcglast617:
  %v3188 = load i64, ptr %slot480, align 8
  %op3189 = sub i64 %v3188, 32
  store i64 %op3189, ptr %slot490, align 8
  %v3190 = load i64, ptr %slot480, align 8
  %p3191 = inttoptr i64 %v3190 to ptr
  %rgep3192 = getelementptr i8, ptr %p3191, i64 -32
  %ld3193 = load i64, ptr %rgep3192, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3193, ptr %slot491, align 8
  %v3194 = load i64, ptr %slot491, align 8
  %cmp3195 = icmp ne i64 %v3194, 0
  %cv3196 = zext i1 %cmp3195 to i32
  store i32 %cv3196, ptr %slot492, align 8
  %v3197 = load i32, ptr %slot492, align 8
  %cv3198 = zext i32 %v3197 to i64
  %cond3199 = icmp ne i64 %cv3198, 0
  br i1 %cond3199, label %bb_rcgdec617, label %bb_rcgslow617
bb_rcgslow617:
  %v3200 = load i64, ptr %slot479, align 8
  %v3201 = load i64, ptr %slot476, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3200, i64 %v3201) nomerge, !dbg !126
  br label %bb_rcgdone617
bb_rcgdec617:
  %v3202 = load i64, ptr %slot488, align 8
  %v3203 = load i64, ptr %slot480, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  %rgep3205 = getelementptr i8, ptr %p3204, i64 -24
  store i64 %v3202, ptr %rgep3205, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear617
bb_rcgclear617:
  %v3206 = load i64, ptr %slot476, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  store i64 0, ptr %p3207, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone617
bb_rcgdone617:
  br label %bb_rcslotdone601
bb_rcslotowner601:
  %v3208 = load i64, ptr %slot41, align 8
  store i64 %v3208, ptr %slot493, align 8
  %v3209 = load i64, ptr %slot476, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  %ld3211 = load i64, ptr %p3210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3211, ptr %slot494, align 8
  %v3212 = load i64, ptr %slot494, align 8
  %cmp3213 = icmp ne i64 %v3212, 0
  %cv3214 = zext i1 %cmp3213 to i32
  store i32 %cv3214, ptr %slot495, align 8
  %v3215 = load i32, ptr %slot495, align 8
  %cv3216 = zext i32 %v3215 to i64
  %cond3217 = icmp ne i64 %cv3216, 0
  br i1 %cond3217, label %bb_rcgnn632, label %bb_rcgdone632
bb_rcgnn632:
  %v3218 = load i64, ptr %slot494, align 8
  %op3219 = sub i64 %v3218, 16
  store i64 %op3219, ptr %slot496, align 8
  %v3220 = load i64, ptr %slot494, align 8
  %p3221 = inttoptr i64 %v3220 to ptr
  %rgep3222 = getelementptr i8, ptr %p3221, i64 -16
  %ld3223 = load i64, ptr %rgep3222, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3223, ptr %slot497, align 8
  %v3224 = load i64, ptr %slot497, align 8
  %op3225 = and i64 %v3224, 4611686018427387906
  store i64 %op3225, ptr %slot498, align 8
  %v3226 = load i64, ptr %slot498, align 8
  %cmp3227 = icmp ne i64 %v3226, 0
  %cv3228 = zext i1 %cmp3227 to i32
  store i32 %cv3228, ptr %slot499, align 8
  %v3229 = load i32, ptr %slot499, align 8
  %cv3230 = zext i32 %v3229 to i64
  %cond3231 = icmp ne i64 %cv3230, 0
  br i1 %cond3231, label %bb_rcgclear632, label %bb_rcgcounted632
bb_rcgcounted632:
  %v3232 = load i64, ptr %slot494, align 8
  %op3233 = sub i64 %v3232, 32
  store i64 %op3233, ptr %slot500, align 8
  %v3234 = load i64, ptr %slot494, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  %rgep3236 = getelementptr i8, ptr %p3235, i64 -32
  %ld3237 = load i64, ptr %rgep3236, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3237, ptr %slot501, align 8
  %v3238 = load i64, ptr %slot501, align 8
  %op3239 = sub i64 %v3238, 1
  store i64 %op3239, ptr %slot502, align 8
  %v3240 = load i64, ptr %slot502, align 8
  %cmp3241 = icmp eq i64 %v3240, 0
  %cv3242 = zext i1 %cmp3241 to i32
  store i32 %cv3242, ptr %slot503, align 8
  %v3243 = load i32, ptr %slot503, align 8
  %cv3244 = zext i32 %v3243 to i64
  %cond3245 = icmp ne i64 %cv3244, 0
  br i1 %cond3245, label %bb_rcglast632, label %bb_rcgdec632
bb_rcglast632:
  %v3246 = load i64, ptr %slot494, align 8
  %op3247 = sub i64 %v3246, 24
  store i64 %op3247, ptr %slot504, align 8
  %v3248 = load i64, ptr %slot494, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %rgep3250 = getelementptr i8, ptr %p3249, i64 -24
  %ld3251 = load i64, ptr %rgep3250, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3251, ptr %slot505, align 8
  %v3252 = load i64, ptr %slot505, align 8
  %cmp3253 = icmp ne i64 %v3252, 0
  %cv3254 = zext i1 %cmp3253 to i32
  store i32 %cv3254, ptr %slot506, align 8
  %v3255 = load i32, ptr %slot506, align 8
  %cv3256 = zext i32 %v3255 to i64
  %cond3257 = icmp ne i64 %cv3256, 0
  br i1 %cond3257, label %bb_rcgdec632, label %bb_rcgslow632
bb_rcgslow632:
  %v3258 = load i64, ptr %slot493, align 8
  %v3259 = load i64, ptr %slot476, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3258, i64 %v3259) nomerge, !dbg !126
  br label %bb_rcgdone632
bb_rcgdec632:
  %v3260 = load i64, ptr %slot502, align 8
  %v3261 = load i64, ptr %slot494, align 8
  %p3262 = inttoptr i64 %v3261 to ptr
  %rgep3263 = getelementptr i8, ptr %p3262, i64 -32
  store i64 %v3260, ptr %rgep3263, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear632
bb_rcgclear632:
  %v3264 = load i64, ptr %slot476, align 8
  %p3265 = inttoptr i64 %v3264 to ptr
  store i64 0, ptr %p3265, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone632
bb_rcgdone632:
  br label %bb_rcslotdone601
bb_rcslotdone601:
  %v3266 = load i64, ptr %slot35, align 8
  store i64 %v3266, ptr %slot507, align 8
  %v3267 = load i64, ptr %slot31, align 8
  store i64 %v3267, ptr %slot508, align 8
  %v3268 = load i64, ptr %slot508, align 8
  %v3269 = load i64, ptr %slot507, align 8
  %p3270 = inttoptr i64 %v3268 to ptr
  %p3271 = inttoptr i64 %v3269 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3271, ptr %p3270, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3272 = load i64, ptr %slot20, align 8
  %p3273 = inttoptr i64 %v3272 to ptr
  store i32 0, ptr %p3273, align 4, !alias.scope !3, !noalias !4
  %v3274 = load i64, ptr %slot11, align 8
  %p3275 = inttoptr i64 %v3274 to ptr
  store i32 2, ptr %p3275, align 4, !alias.scope !3, !noalias !4
  %v3276 = load i64, ptr %slot21, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  %ld3278 = load i32, ptr %p3277, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3278, ptr %slot509, align 8
  %v3279 = load i32, ptr %slot509, align 8
  %v3280 = load i64, ptr %slot11, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  store i32 %v3279, ptr %p3281, align 4, !alias.scope !3, !noalias !4
  %v3282 = load i64, ptr %slot10, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  store i32 1, ptr %p3283, align 4, !alias.scope !3, !noalias !4
  %v3284 = load i64, ptr %slot35, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  %ld3286 = load i64, ptr %p3285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3286, ptr %slot510, align 8
  %v3287 = load i64, ptr %slot510, align 8
  %v3288 = load i64, ptr %slot39, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i64 %v3287, ptr %p3289, align 8, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot40, align 8
  store i64 %v3290, ptr %slot511, align 8
  %v3291 = load i64, ptr %slot511, align 8
  %p3292 = inttoptr i64 %v3291 to ptr
  store i64 0, ptr %p3292, align 8, !alias.scope !3, !noalias !4
  %v3293 = load i64, ptr %slot511, align 8
  %p3295 = inttoptr i64 %v3293 to ptr
  %gep3296 = getelementptr i8, ptr %p3295, i64 8
  %op3294 = ptrtoint ptr %gep3296 to i64
  store i64 %op3294, ptr %slot512, align 8
  %v3297 = load i64, ptr %slot512, align 8
  %p3298 = inttoptr i64 %v3297 to ptr
  store i64 0, ptr %p3298, align 8, !alias.scope !3, !noalias !4
  %v3299 = load i64, ptr %slot511, align 8
  %p3301 = inttoptr i64 %v3299 to ptr
  %gep3302 = getelementptr i8, ptr %p3301, i64 16
  %op3300 = ptrtoint ptr %gep3302 to i64
  store i64 %op3300, ptr %slot513, align 8
  %v3303 = load i64, ptr %slot513, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  store i64 0, ptr %p3304, align 8, !alias.scope !3, !noalias !4
  %v3305 = load i64, ptr %slot511, align 8
  %p3307 = inttoptr i64 %v3305 to ptr
  %gep3308 = getelementptr i8, ptr %p3307, i64 24
  %op3306 = ptrtoint ptr %gep3308 to i64
  store i64 %op3306, ptr %slot514, align 8
  %v3309 = load i64, ptr %slot514, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  store i64 0, ptr %p3310, align 8, !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot22, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  store i32 1, ptr %p3312, align 4, !alias.scope !3, !noalias !4
  %v3313 = load i64, ptr %slot42, align 8
  store i64 %v3313, ptr %slot515, align 8
  %v3314 = load i64, ptr %slot36, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  %ld3316 = load i64, ptr %p3315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3316, ptr %slot516, align 8
  %v3317 = load i64, ptr %slot516, align 8
  %v3318 = load i64, ptr %slot27, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  store i64 %v3317, ptr %p3319, align 8, !alias.scope !3, !noalias !4
  %v3320 = load i64, ptr %slot27, align 8
  store i64 %v3320, ptr %slot517, align 8
  %v3321 = load i64, ptr %slot511, align 8
  %p3323 = inttoptr i64 %v3321 to ptr
  %gep3324 = getelementptr i8, ptr %p3323, i64 0
  %op3322 = ptrtoint ptr %gep3324 to i64
  store i64 %op3322, ptr %slot518, align 8
  %v3325 = load i64, ptr %slot36, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  %ld3327 = load i64, ptr %p3326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3327, ptr %slot519, align 8
  %v3328 = load i64, ptr %slot519, align 8
  %v3329 = load i64, ptr %slot27, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  store i64 %v3328, ptr %p3330, align 8, !alias.scope !3, !noalias !4
  %v3331 = load i64, ptr %slot27, align 8
  store i64 %v3331, ptr %slot520, align 8
  %v3332 = load i64, ptr %slot12, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i32, ptr %p3333, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3334, ptr %slot521, align 8
  %v3335 = load i64, ptr %slot13, align 8
  %p3336 = inttoptr i64 %v3335 to ptr
  %ld3337 = load i32, ptr %p3336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3337, ptr %slot522, align 8
  %v3338 = load i32, ptr %slot522, align 8
  %op3339 = and i32 %v3338, 24
  store i32 %op3339, ptr %slot522, align 8
  %v3340 = load i32, ptr %slot522, align 8
  %cmp3341 = icmp eq i32 %v3340, 0
  %cv3342 = zext i1 %cmp3341 to i32
  store i32 %cv3342, ptr %slot523, align 8
  %v3343 = load i32, ptr %slot521, align 8
  %v3344 = load i32, ptr %slot523, align 8
  %op3345 = and i32 %v3343, %v3344
  store i32 %op3345, ptr %slot524, align 8
  %v3346 = load i32, ptr %slot524, align 8
  %cv3347 = zext i32 %v3346 to i64
  %cond3348 = icmp ne i64 %cv3347, 0
  br i1 %cond3348, label %bb_rctake656, label %bb_rccopy656
bb_rctake656:
  %v3349 = load i64, ptr %slot31, align 8
  store i64 %v3349, ptr %slot525, align 8
  %v3350 = load i64, ptr %slot42, align 8
  store i64 %v3350, ptr %slot526, align 8
  %v3351 = load i64, ptr %slot520, align 8
  %v3352 = load i64, ptr %slot525, align 8
  %op3353 = sub i64 %v3351, %v3352
  store i64 %op3353, ptr %slot527, align 8
  %v3354 = load i64, ptr %slot525, align 8
  %v3355 = load i64, ptr %slot520, align 8
  %op3356 = sub i64 %v3354, %v3355
  store i64 %op3356, ptr %slot528, align 8
  %v3357 = load i64, ptr %slot527, align 8
  %cmp3358 = icmp ult i64 %v3357, 8
  %cv3359 = zext i1 %cmp3358 to i32
  store i32 %cv3359, ptr %slot529, align 8
  %v3360 = load i64, ptr %slot528, align 8
  %cmp3361 = icmp ult i64 %v3360, 8
  %cv3362 = zext i1 %cmp3361 to i32
  store i32 %cv3362, ptr %slot530, align 8
  %v3363 = load i32, ptr %slot529, align 8
  %v3364 = load i32, ptr %slot530, align 8
  %op3365 = or i32 %v3363, %v3364
  store i32 %op3365, ptr %slot531, align 8
  %v3366 = load i32, ptr %slot531, align 8
  %cv3367 = zext i32 %v3366 to i64
  %cond3368 = icmp ne i64 %cv3367, 0
  br i1 %cond3368, label %bb_rcmoveslow665, label %bb_rcmovecheck665
bb_rcmovecheck665:
  %v3369 = load i64, ptr %slot520, align 8
  %p3371 = inttoptr i64 %v3369 to ptr
  %gep3372 = getelementptr i8, ptr %p3371, i64 0
  %op3370 = ptrtoint ptr %gep3372 to i64
  store i64 %op3370, ptr %slot532, align 8
  %v3373 = load i64, ptr %slot532, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  %ld3375 = load i64, ptr %p3374, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3375, ptr %slot533, align 8
  %v3376 = load i64, ptr %slot533, align 8
  %cmp3377 = icmp ne i64 %v3376, 0
  %cv3378 = zext i1 %cmp3377 to i32
  store i32 %cv3378, ptr %slot534, align 8
  %v3379 = load i32, ptr %slot534, align 8
  %cv3380 = zext i32 %v3379 to i64
  %cond3381 = icmp ne i64 %cv3380, 0
  br i1 %cond3381, label %bb_rcmoveheader673, label %bb_rcmovenext673
bb_rcmoveheader673:
  %v3382 = load i64, ptr %slot533, align 8
  %op3383 = sub i64 %v3382, 16
  store i64 %op3383, ptr %slot535, align 8
  %v3384 = load i64, ptr %slot533, align 8
  %p3385 = inttoptr i64 %v3384 to ptr
  %rgep3386 = getelementptr i8, ptr %p3385, i64 -16
  %ld3387 = load i64, ptr %rgep3386, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3387, ptr %slot536, align 8
  %v3388 = load i64, ptr %slot536, align 8
  %op3389 = and i64 %v3388, 5764607523034234881
  store i64 %op3389, ptr %slot537, align 8
  %v3390 = load i64, ptr %slot537, align 8
  %cmp3391 = icmp ne i64 %v3390, 0
  %cv3392 = zext i1 %cmp3391 to i32
  store i32 %cv3392, ptr %slot538, align 8
  %v3393 = load i32, ptr %slot538, align 8
  %cv3394 = zext i32 %v3393 to i64
  %cond3395 = icmp ne i64 %cv3394, 0
  br i1 %cond3395, label %bb_rcmoveslow665, label %bb_rcmovenext673
bb_rcmovenext673:
  %v3396 = load i64, ptr %slot520, align 8
  %v3397 = load i64, ptr %slot525, align 8
  %p3398 = inttoptr i64 %v3396 to ptr
  %p3399 = inttoptr i64 %v3397 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3399, ptr %p3398, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3400 = load i64, ptr %slot520, align 8
  %p3401 = inttoptr i64 %v3400 to ptr
  store i64 0, ptr %p3401, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved665
bb_rcmoveslow665:
  %v3402 = load i64, ptr %slot41, align 8
  %v3403 = load i64, ptr %slot525, align 8
  %v3404 = load i64, ptr %slot520, align 8
  %v3405 = load i64, ptr %slot526, align 8
  %cv3406 = trunc i64 %v3405 to i32
  %call3407 = call i32 @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_take(i64 %v3402, i64 %v3403, i64 %v3404, i32 %cv3406) nomerge, !dbg !128
  store i32 %call3407, ptr %slot539, align 8
  %v3408 = load i32, ptr %slot539, align 8
  %cv3409 = zext i32 %v3408 to i64
  %cond3410 = icmp ne i64 %cv3409, 0
  br i1 %cond3410, label %bb_rcsuccess680, label %bb_rcfailure680
bb_rcfailure680:
  %v3411 = load i64, ptr %slot41, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  %call3413 = call i32 @myl_rc_take_failure(ptr %p3412) nomerge, !dbg !128
  store i32 %call3413, ptr %slot540, align 8
  %v3414 = load i64, ptr %slot1, align 8
  %p3415 = inttoptr i64 %v3414 to ptr
  %v3416 = load i32, ptr %slot540, align 8
  %call3417 = call i32 @myl_qbe_rc_status(ptr %p3415, i32 %v3416) nomerge, !dbg !128
  store i32 %call3417, ptr %slot541, align 8
  br label %bb_failure
bb_rcsuccess680:
  br label %bb_rcmoved665
bb_rcmoved665:
  %v3418 = load i64, ptr %slot12, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  store i32 0, ptr %p3419, align 4, !alias.scope !3, !noalias !4
  %v3420 = load i64, ptr %slot21, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  store i32 2, ptr %p3421, align 4, !alias.scope !3, !noalias !4
  %v3422 = load i64, ptr %slot20, align 8
  %p3423 = inttoptr i64 %v3422 to ptr
  store i32 1, ptr %p3423, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared656
bb_rccopy656:
  %v3424 = load i64, ptr %slot31, align 8
  store i64 %v3424, ptr %slot542, align 8
  %v3425 = load i64, ptr %slot42, align 8
  store i64 %v3425, ptr %slot543, align 8
  %v3426 = load i64, ptr %slot520, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  %ld3428 = load i64, ptr %p3427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3428, ptr %slot544, align 8
  %v3429 = load i64, ptr %slot544, align 8
  %cmp3430 = icmp ne i64 %v3429, 0
  %cv3431 = zext i1 %cmp3430 to i32
  store i32 %cv3431, ptr %slot545, align 8
  %v3432 = load i32, ptr %slot545, align 8
  %cv3433 = zext i32 %v3432 to i64
  %cond3434 = icmp ne i64 %cv3433, 0
  br i1 %cond3434, label %bb_rcgnn689, label %bb_rcgplain689
bb_rcgnn689:
  %v3435 = load i64, ptr %slot544, align 8
  %op3436 = sub i64 %v3435, 16
  store i64 %op3436, ptr %slot546, align 8
  %v3437 = load i64, ptr %slot544, align 8
  %p3438 = inttoptr i64 %v3437 to ptr
  %rgep3439 = getelementptr i8, ptr %p3438, i64 -16
  %ld3440 = load i64, ptr %rgep3439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3440, ptr %slot547, align 8
  %v3441 = load i64, ptr %slot547, align 8
  %op3442 = and i64 %v3441, 4611686018427387906
  store i64 %op3442, ptr %slot548, align 8
  %v3443 = load i64, ptr %slot548, align 8
  %cmp3444 = icmp ne i64 %v3443, 0
  %cv3445 = zext i1 %cmp3444 to i32
  store i32 %cv3445, ptr %slot549, align 8
  %v3446 = load i32, ptr %slot549, align 8
  %cv3447 = zext i32 %v3446 to i64
  %cond3448 = icmp ne i64 %cv3447, 0
  br i1 %cond3448, label %bb_rcgspecial689, label %bb_rcginc689
bb_rcginc689:
  %v3449 = load i64, ptr %slot544, align 8
  %op3450 = sub i64 %v3449, 32
  store i64 %op3450, ptr %slot550, align 8
  %v3451 = load i64, ptr %slot544, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  %rgep3453 = getelementptr i8, ptr %p3452, i64 -32
  %ld3454 = load i64, ptr %rgep3453, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3454, ptr %slot551, align 8
  %v3455 = load i64, ptr %slot551, align 8
  %op3456 = add i64 %v3455, 1
  store i64 %op3456, ptr %slot552, align 8
  %v3457 = load i64, ptr %slot552, align 8
  %cmp3458 = icmp eq i64 %v3457, 0
  %cv3459 = zext i1 %cmp3458 to i32
  store i32 %cv3459, ptr %slot553, align 8
  %v3460 = load i32, ptr %slot553, align 8
  %cv3461 = zext i32 %v3460 to i64
  %cond3462 = icmp ne i64 %cv3461, 0
  br i1 %cond3462, label %bb_rcglimit689, label %bb_rcgcapacity689
bb_rcglimit689:
  %v3463 = load i64, ptr %slot1, align 8
  %p3464 = inttoptr i64 %v3463 to ptr
  %call3465 = call i32 @myl_qbe_rc_status(ptr %p3464, i32 2) nomerge, !dbg !128
  store i32 %call3465, ptr %slot554, align 8
  br label %bb_failure
bb_rcgcapacity689:
  %v3466 = load i64, ptr %slot552, align 8
  %v3467 = load i64, ptr %slot544, align 8
  %p3468 = inttoptr i64 %v3467 to ptr
  %rgep3469 = getelementptr i8, ptr %p3468, i64 -32
  store i64 %v3466, ptr %rgep3469, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain689
bb_rcgspecial689:
  %v3470 = load i64, ptr %slot547, align 8
  %op3471 = and i64 %v3470, 4611686018427387904
  store i64 %op3471, ptr %slot555, align 8
  %v3472 = load i64, ptr %slot555, align 8
  %cmp3473 = icmp ne i64 %v3472, 0
  %cv3474 = zext i1 %cmp3473 to i32
  store i32 %cv3474, ptr %slot556, align 8
  %v3475 = load i32, ptr %slot556, align 8
  %cv3476 = zext i32 %v3475 to i64
  %cond3477 = icmp ne i64 %cv3476, 0
  br i1 %cond3477, label %bb_rcgslow689, label %bb_rcgplain689
bb_rcgslow689:
  %v3478 = load i64, ptr %slot41, align 8
  %v3479 = load i64, ptr %slot542, align 8
  %v3480 = load i64, ptr %slot520, align 8
  %v3481 = load i64, ptr %slot543, align 8
  %cv3482 = trunc i64 %v3481 to i32
  %call3483 = call i32 @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_retain(i64 %v3478, i64 %v3479, i64 %v3480, i32 %cv3482) nomerge, !dbg !128
  store i32 %call3483, ptr %slot557, align 8
  %v3484 = load i32, ptr %slot557, align 8
  %cv3485 = zext i32 %v3484 to i64
  %cond3486 = icmp ne i64 %cv3485, 0
  br i1 %cond3486, label %bb_rcsuccess703, label %bb_rcfailure703
bb_rcfailure703:
  %v3487 = load i64, ptr %slot41, align 8
  %p3488 = inttoptr i64 %v3487 to ptr
  %call3489 = call i32 @myl_rc_take_failure(ptr %p3488) nomerge, !dbg !128
  store i32 %call3489, ptr %slot558, align 8
  %v3490 = load i64, ptr %slot1, align 8
  %p3491 = inttoptr i64 %v3490 to ptr
  %v3492 = load i32, ptr %slot558, align 8
  %call3493 = call i32 @myl_qbe_rc_status(ptr %p3491, i32 %v3492) nomerge, !dbg !128
  store i32 %call3493, ptr %slot559, align 8
  br label %bb_failure
bb_rcsuccess703:
  br label %bb_rcgdone689
bb_rcgplain689:
  %v3494 = load i64, ptr %slot544, align 8
  %v3495 = load i64, ptr %slot542, align 8
  %p3496 = inttoptr i64 %v3495 to ptr
  store i64 %v3494, ptr %p3496, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone689
bb_rcgdone689:
  %v3497 = load i64, ptr %slot21, align 8
  %p3498 = inttoptr i64 %v3497 to ptr
  store i32 2, ptr %p3498, align 4, !alias.scope !3, !noalias !4
  %v3499 = load i64, ptr %slot20, align 8
  %p3500 = inttoptr i64 %v3499 to ptr
  store i32 1, ptr %p3500, align 4, !alias.scope !3, !noalias !4
  %v3501 = load i64, ptr %slot12, align 8
  %p3502 = inttoptr i64 %v3501 to ptr
  %ld3503 = load i32, ptr %p3502, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3503, ptr %slot560, align 8
  %v3504 = load i32, ptr %slot560, align 8
  %cv3505 = zext i32 %v3504 to i64
  %cond3506 = icmp ne i64 %cv3505, 0
  br i1 %cond3506, label %bb_rcslotdrop710, label %bb_rcslotdone710
bb_rcslotdrop710:
  %v3507 = load i64, ptr %slot12, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  store i32 0, ptr %p3508, align 4, !alias.scope !3, !noalias !4
  %v3509 = load i64, ptr %slot23, align 8
  store i64 %v3509, ptr %slot561, align 8
  %v3510 = load i64, ptr %slot13, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  %ld3512 = load i32, ptr %p3511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3512, ptr %slot562, align 8
  %v3513 = load i32, ptr %slot562, align 8
  %op3514 = and i32 %v3513, 28
  store i32 %op3514, ptr %slot563, align 8
  %v3515 = load i32, ptr %slot563, align 8
  %cv3516 = zext i32 %v3515 to i64
  %cond3517 = icmp ne i64 %cv3516, 0
  br i1 %cond3517, label %bb_rcslotrole710, label %bb_rcslotowner710
bb_rcslotrole710:
  %v3518 = load i64, ptr %slot41, align 8
  store i64 %v3518, ptr %slot564, align 8
  %v3519 = load i64, ptr %slot561, align 8
  %p3520 = inttoptr i64 %v3519 to ptr
  %ld3521 = load i64, ptr %p3520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3521, ptr %slot565, align 8
  %v3522 = load i64, ptr %slot565, align 8
  %cmp3523 = icmp ne i64 %v3522, 0
  %cv3524 = zext i1 %cmp3523 to i32
  store i32 %cv3524, ptr %slot566, align 8
  %v3525 = load i32, ptr %slot566, align 8
  %cv3526 = zext i32 %v3525 to i64
  %cond3527 = icmp ne i64 %cv3526, 0
  br i1 %cond3527, label %bb_rcgnn726, label %bb_rcgdone726
bb_rcgnn726:
  %v3528 = load i64, ptr %slot565, align 8
  %op3529 = sub i64 %v3528, 16
  store i64 %op3529, ptr %slot567, align 8
  %v3530 = load i64, ptr %slot565, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  %rgep3532 = getelementptr i8, ptr %p3531, i64 -16
  %ld3533 = load i64, ptr %rgep3532, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3533, ptr %slot568, align 8
  %v3534 = load i64, ptr %slot568, align 8
  %op3535 = and i64 %v3534, 4611686018427387906
  store i64 %op3535, ptr %slot569, align 8
  %v3536 = load i64, ptr %slot569, align 8
  %cmp3537 = icmp ne i64 %v3536, 0
  %cv3538 = zext i1 %cmp3537 to i32
  store i32 %cv3538, ptr %slot570, align 8
  %v3539 = load i32, ptr %slot570, align 8
  %cv3540 = zext i32 %v3539 to i64
  %cond3541 = icmp ne i64 %cv3540, 0
  br i1 %cond3541, label %bb_rcgclear726, label %bb_rcgcounted726
bb_rcgcounted726:
  %v3542 = load i64, ptr %slot565, align 8
  %op3543 = sub i64 %v3542, 24
  store i64 %op3543, ptr %slot571, align 8
  %v3544 = load i64, ptr %slot565, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  %rgep3546 = getelementptr i8, ptr %p3545, i64 -24
  %ld3547 = load i64, ptr %rgep3546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3547, ptr %slot572, align 8
  %v3548 = load i64, ptr %slot572, align 8
  %op3549 = sub i64 %v3548, 1
  store i64 %op3549, ptr %slot573, align 8
  %v3550 = load i64, ptr %slot573, align 8
  %cmp3551 = icmp eq i64 %v3550, 0
  %cv3552 = zext i1 %cmp3551 to i32
  store i32 %cv3552, ptr %slot574, align 8
  %v3553 = load i32, ptr %slot574, align 8
  %cv3554 = zext i32 %v3553 to i64
  %cond3555 = icmp ne i64 %cv3554, 0
  br i1 %cond3555, label %bb_rcglast726, label %bb_rcgdec726
bb_rcglast726:
  %v3556 = load i64, ptr %slot565, align 8
  %op3557 = sub i64 %v3556, 32
  store i64 %op3557, ptr %slot575, align 8
  %v3558 = load i64, ptr %slot565, align 8
  %p3559 = inttoptr i64 %v3558 to ptr
  %rgep3560 = getelementptr i8, ptr %p3559, i64 -32
  %ld3561 = load i64, ptr %rgep3560, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3561, ptr %slot576, align 8
  %v3562 = load i64, ptr %slot576, align 8
  %cmp3563 = icmp ne i64 %v3562, 0
  %cv3564 = zext i1 %cmp3563 to i32
  store i32 %cv3564, ptr %slot577, align 8
  %v3565 = load i32, ptr %slot577, align 8
  %cv3566 = zext i32 %v3565 to i64
  %cond3567 = icmp ne i64 %cv3566, 0
  br i1 %cond3567, label %bb_rcgdec726, label %bb_rcgslow726
bb_rcgslow726:
  %v3568 = load i64, ptr %slot564, align 8
  %v3569 = load i64, ptr %slot561, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_unloan(i64 %v3568, i64 %v3569) nomerge, !dbg !128
  br label %bb_rcgdone726
bb_rcgdec726:
  %v3570 = load i64, ptr %slot573, align 8
  %v3571 = load i64, ptr %slot565, align 8
  %p3572 = inttoptr i64 %v3571 to ptr
  %rgep3573 = getelementptr i8, ptr %p3572, i64 -24
  store i64 %v3570, ptr %rgep3573, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear726
bb_rcgclear726:
  %v3574 = load i64, ptr %slot561, align 8
  %p3575 = inttoptr i64 %v3574 to ptr
  store i64 0, ptr %p3575, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone726
bb_rcgdone726:
  br label %bb_rcslotdone710
bb_rcslotowner710:
  %v3576 = load i64, ptr %slot41, align 8
  store i64 %v3576, ptr %slot578, align 8
  %v3577 = load i64, ptr %slot561, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  %ld3579 = load i64, ptr %p3578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3579, ptr %slot579, align 8
  %v3580 = load i64, ptr %slot579, align 8
  %cmp3581 = icmp ne i64 %v3580, 0
  %cv3582 = zext i1 %cmp3581 to i32
  store i32 %cv3582, ptr %slot580, align 8
  %v3583 = load i32, ptr %slot580, align 8
  %cv3584 = zext i32 %v3583 to i64
  %cond3585 = icmp ne i64 %cv3584, 0
  br i1 %cond3585, label %bb_rcgnn741, label %bb_rcgdone741
bb_rcgnn741:
  %v3586 = load i64, ptr %slot579, align 8
  %op3587 = sub i64 %v3586, 16
  store i64 %op3587, ptr %slot581, align 8
  %v3588 = load i64, ptr %slot579, align 8
  %p3589 = inttoptr i64 %v3588 to ptr
  %rgep3590 = getelementptr i8, ptr %p3589, i64 -16
  %ld3591 = load i64, ptr %rgep3590, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3591, ptr %slot582, align 8
  %v3592 = load i64, ptr %slot582, align 8
  %op3593 = and i64 %v3592, 4611686018427387906
  store i64 %op3593, ptr %slot583, align 8
  %v3594 = load i64, ptr %slot583, align 8
  %cmp3595 = icmp ne i64 %v3594, 0
  %cv3596 = zext i1 %cmp3595 to i32
  store i32 %cv3596, ptr %slot584, align 8
  %v3597 = load i32, ptr %slot584, align 8
  %cv3598 = zext i32 %v3597 to i64
  %cond3599 = icmp ne i64 %cv3598, 0
  br i1 %cond3599, label %bb_rcgclear741, label %bb_rcgcounted741
bb_rcgcounted741:
  %v3600 = load i64, ptr %slot579, align 8
  %op3601 = sub i64 %v3600, 32
  store i64 %op3601, ptr %slot585, align 8
  %v3602 = load i64, ptr %slot579, align 8
  %p3603 = inttoptr i64 %v3602 to ptr
  %rgep3604 = getelementptr i8, ptr %p3603, i64 -32
  %ld3605 = load i64, ptr %rgep3604, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3605, ptr %slot586, align 8
  %v3606 = load i64, ptr %slot586, align 8
  %op3607 = sub i64 %v3606, 1
  store i64 %op3607, ptr %slot587, align 8
  %v3608 = load i64, ptr %slot587, align 8
  %cmp3609 = icmp eq i64 %v3608, 0
  %cv3610 = zext i1 %cmp3609 to i32
  store i32 %cv3610, ptr %slot588, align 8
  %v3611 = load i32, ptr %slot588, align 8
  %cv3612 = zext i32 %v3611 to i64
  %cond3613 = icmp ne i64 %cv3612, 0
  br i1 %cond3613, label %bb_rcglast741, label %bb_rcgdec741
bb_rcglast741:
  %v3614 = load i64, ptr %slot579, align 8
  %op3615 = sub i64 %v3614, 24
  store i64 %op3615, ptr %slot589, align 8
  %v3616 = load i64, ptr %slot579, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  %rgep3618 = getelementptr i8, ptr %p3617, i64 -24
  %ld3619 = load i64, ptr %rgep3618, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3619, ptr %slot590, align 8
  %v3620 = load i64, ptr %slot590, align 8
  %cmp3621 = icmp ne i64 %v3620, 0
  %cv3622 = zext i1 %cmp3621 to i32
  store i32 %cv3622, ptr %slot591, align 8
  %v3623 = load i32, ptr %slot591, align 8
  %cv3624 = zext i32 %v3623 to i64
  %cond3625 = icmp ne i64 %cv3624, 0
  br i1 %cond3625, label %bb_rcgdec741, label %bb_rcgslow741
bb_rcgslow741:
  %v3626 = load i64, ptr %slot578, align 8
  %v3627 = load i64, ptr %slot561, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64 %v3626, i64 %v3627) nomerge, !dbg !128
  br label %bb_rcgdone741
bb_rcgdec741:
  %v3628 = load i64, ptr %slot587, align 8
  %v3629 = load i64, ptr %slot579, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  %rgep3631 = getelementptr i8, ptr %p3630, i64 -32
  store i64 %v3628, ptr %rgep3631, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear741
bb_rcgclear741:
  %v3632 = load i64, ptr %slot561, align 8
  %p3633 = inttoptr i64 %v3632 to ptr
  store i64 0, ptr %p3633, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone741
bb_rcgdone741:
  br label %bb_rcslotdone710
bb_rcslotdone710:
  br label %bb_rcprepared656
bb_rcprepared656:
  %v3634 = load i64, ptr %slot31, align 8
  store i64 %v3634, ptr %slot592, align 8
  %v3635 = load i64, ptr %slot592, align 8
  %v3636 = load i64, ptr %slot518, align 8
  %p3637 = inttoptr i64 %v3635 to ptr
  %p3638 = inttoptr i64 %v3636 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3638, ptr %p3637, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3639 = load i64, ptr %slot20, align 8
  %p3640 = inttoptr i64 %v3639 to ptr
  store i32 0, ptr %p3640, align 4, !alias.scope !3, !noalias !4
  %v3641 = load i64, ptr %slot37, align 8
  %p3642 = inttoptr i64 %v3641 to ptr
  %ld3643 = load i64, ptr %p3642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3643, ptr %slot593, align 8
  %v3644 = load i64, ptr %slot593, align 8
  %v3645 = load i64, ptr %slot28, align 8
  %p3646 = inttoptr i64 %v3645 to ptr
  store i64 %v3644, ptr %p3646, align 8, !alias.scope !3, !noalias !4
  %v3647 = load i64, ptr %slot28, align 8
  store i64 %v3647, ptr %slot594, align 8
  %v3648 = load i64, ptr %slot511, align 8
  %p3650 = inttoptr i64 %v3648 to ptr
  %gep3651 = getelementptr i8, ptr %p3650, i64 8
  %op3649 = ptrtoint ptr %gep3651 to i64
  store i64 %op3649, ptr %slot595, align 8
  %v3652 = load i64, ptr %slot37, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  %ld3654 = load i64, ptr %p3653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3654, ptr %slot596, align 8
  %v3655 = load i64, ptr %slot596, align 8
  %v3656 = load i64, ptr %slot28, align 8
  %p3657 = inttoptr i64 %v3656 to ptr
  store i64 %v3655, ptr %p3657, align 8, !alias.scope !3, !noalias !4
  %v3658 = load i64, ptr %slot28, align 8
  store i64 %v3658, ptr %slot597, align 8
  %v3659 = load i64, ptr %slot14, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  %ld3661 = load i32, ptr %p3660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3661, ptr %slot598, align 8
  %v3662 = load i64, ptr %slot15, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  %ld3664 = load i32, ptr %p3663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3664, ptr %slot599, align 8
  %v3665 = load i32, ptr %slot599, align 8
  %op3666 = and i32 %v3665, 24
  store i32 %op3666, ptr %slot599, align 8
  %v3667 = load i32, ptr %slot599, align 8
  %cmp3668 = icmp eq i32 %v3667, 0
  %cv3669 = zext i1 %cmp3668 to i32
  store i32 %cv3669, ptr %slot600, align 8
  %v3670 = load i32, ptr %slot598, align 8
  %v3671 = load i32, ptr %slot600, align 8
  %op3672 = and i32 %v3670, %v3671
  store i32 %op3672, ptr %slot601, align 8
  %v3673 = load i32, ptr %slot601, align 8
  %cv3674 = zext i32 %v3673 to i64
  %cond3675 = icmp ne i64 %cv3674, 0
  br i1 %cond3675, label %bb_rctake752, label %bb_rccopy752
bb_rctake752:
  %v3676 = load i64, ptr %slot31, align 8
  store i64 %v3676, ptr %slot602, align 8
  %v3677 = load i64, ptr %slot42, align 8
  store i64 %v3677, ptr %slot603, align 8
  %v3678 = load i64, ptr %slot597, align 8
  %v3679 = load i64, ptr %slot602, align 8
  %op3680 = sub i64 %v3678, %v3679
  store i64 %op3680, ptr %slot604, align 8
  %v3681 = load i64, ptr %slot602, align 8
  %v3682 = load i64, ptr %slot597, align 8
  %op3683 = sub i64 %v3681, %v3682
  store i64 %op3683, ptr %slot605, align 8
  %v3684 = load i64, ptr %slot604, align 8
  %cmp3685 = icmp ult i64 %v3684, 8
  %cv3686 = zext i1 %cmp3685 to i32
  store i32 %cv3686, ptr %slot606, align 8
  %v3687 = load i64, ptr %slot605, align 8
  %cmp3688 = icmp ult i64 %v3687, 8
  %cv3689 = zext i1 %cmp3688 to i32
  store i32 %cv3689, ptr %slot607, align 8
  %v3690 = load i32, ptr %slot606, align 8
  %v3691 = load i32, ptr %slot607, align 8
  %op3692 = or i32 %v3690, %v3691
  store i32 %op3692, ptr %slot608, align 8
  %v3693 = load i32, ptr %slot608, align 8
  %cv3694 = zext i32 %v3693 to i64
  %cond3695 = icmp ne i64 %cv3694, 0
  br i1 %cond3695, label %bb_rcmoveslow761, label %bb_rcmovecheck761
bb_rcmovecheck761:
  %v3696 = load i64, ptr %slot597, align 8
  %p3698 = inttoptr i64 %v3696 to ptr
  %gep3699 = getelementptr i8, ptr %p3698, i64 0
  %op3697 = ptrtoint ptr %gep3699 to i64
  store i64 %op3697, ptr %slot609, align 8
  %v3700 = load i64, ptr %slot609, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %ld3702 = load i64, ptr %p3701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3702, ptr %slot610, align 8
  %v3703 = load i64, ptr %slot610, align 8
  %cmp3704 = icmp ne i64 %v3703, 0
  %cv3705 = zext i1 %cmp3704 to i32
  store i32 %cv3705, ptr %slot611, align 8
  %v3706 = load i32, ptr %slot611, align 8
  %cv3707 = zext i32 %v3706 to i64
  %cond3708 = icmp ne i64 %cv3707, 0
  br i1 %cond3708, label %bb_rcmoveheader769, label %bb_rcmovenext769
bb_rcmoveheader769:
  %v3709 = load i64, ptr %slot610, align 8
  %op3710 = sub i64 %v3709, 16
  store i64 %op3710, ptr %slot612, align 8
  %v3711 = load i64, ptr %slot610, align 8
  %p3712 = inttoptr i64 %v3711 to ptr
  %rgep3713 = getelementptr i8, ptr %p3712, i64 -16
  %ld3714 = load i64, ptr %rgep3713, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3714, ptr %slot613, align 8
  %v3715 = load i64, ptr %slot613, align 8
  %op3716 = and i64 %v3715, 5764607523034234881
  store i64 %op3716, ptr %slot614, align 8
  %v3717 = load i64, ptr %slot614, align 8
  %cmp3718 = icmp ne i64 %v3717, 0
  %cv3719 = zext i1 %cmp3718 to i32
  store i32 %cv3719, ptr %slot615, align 8
  %v3720 = load i32, ptr %slot615, align 8
  %cv3721 = zext i32 %v3720 to i64
  %cond3722 = icmp ne i64 %cv3721, 0
  br i1 %cond3722, label %bb_rcmoveslow761, label %bb_rcmovenext769
bb_rcmovenext769:
  %v3723 = load i64, ptr %slot597, align 8
  %v3724 = load i64, ptr %slot602, align 8
  %p3725 = inttoptr i64 %v3723 to ptr
  %p3726 = inttoptr i64 %v3724 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3726, ptr %p3725, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3727 = load i64, ptr %slot597, align 8
  %p3728 = inttoptr i64 %v3727 to ptr
  store i64 0, ptr %p3728, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved761
bb_rcmoveslow761:
  %v3729 = load i64, ptr %slot41, align 8
  %v3730 = load i64, ptr %slot602, align 8
  %v3731 = load i64, ptr %slot597, align 8
  %v3732 = load i64, ptr %slot603, align 8
  %cv3733 = trunc i64 %v3732 to i32
  %call3734 = call i32 @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_take(i64 %v3729, i64 %v3730, i64 %v3731, i32 %cv3733) nomerge, !dbg !128
  store i32 %call3734, ptr %slot616, align 8
  %v3735 = load i32, ptr %slot616, align 8
  %cv3736 = zext i32 %v3735 to i64
  %cond3737 = icmp ne i64 %cv3736, 0
  br i1 %cond3737, label %bb_rcsuccess776, label %bb_rcfailure776
bb_rcfailure776:
  %v3738 = load i64, ptr %slot41, align 8
  %p3739 = inttoptr i64 %v3738 to ptr
  %call3740 = call i32 @myl_rc_take_failure(ptr %p3739) nomerge, !dbg !128
  store i32 %call3740, ptr %slot617, align 8
  %v3741 = load i64, ptr %slot1, align 8
  %p3742 = inttoptr i64 %v3741 to ptr
  %v3743 = load i32, ptr %slot617, align 8
  %call3744 = call i32 @myl_qbe_rc_status(ptr %p3742, i32 %v3743) nomerge, !dbg !128
  store i32 %call3744, ptr %slot618, align 8
  br label %bb_failure
bb_rcsuccess776:
  br label %bb_rcmoved761
bb_rcmoved761:
  %v3745 = load i64, ptr %slot14, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  store i32 0, ptr %p3746, align 4, !alias.scope !3, !noalias !4
  %v3747 = load i64, ptr %slot21, align 8
  %p3748 = inttoptr i64 %v3747 to ptr
  store i32 2, ptr %p3748, align 4, !alias.scope !3, !noalias !4
  %v3749 = load i64, ptr %slot20, align 8
  %p3750 = inttoptr i64 %v3749 to ptr
  store i32 1, ptr %p3750, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared752
bb_rccopy752:
  %v3751 = load i64, ptr %slot31, align 8
  store i64 %v3751, ptr %slot619, align 8
  %v3752 = load i64, ptr %slot42, align 8
  store i64 %v3752, ptr %slot620, align 8
  %v3753 = load i64, ptr %slot597, align 8
  %p3754 = inttoptr i64 %v3753 to ptr
  %ld3755 = load i64, ptr %p3754, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3755, ptr %slot621, align 8
  %v3756 = load i64, ptr %slot621, align 8
  %cmp3757 = icmp ne i64 %v3756, 0
  %cv3758 = zext i1 %cmp3757 to i32
  store i32 %cv3758, ptr %slot622, align 8
  %v3759 = load i32, ptr %slot622, align 8
  %cv3760 = zext i32 %v3759 to i64
  %cond3761 = icmp ne i64 %cv3760, 0
  br i1 %cond3761, label %bb_rcgnn785, label %bb_rcgplain785
bb_rcgnn785:
  %v3762 = load i64, ptr %slot621, align 8
  %op3763 = sub i64 %v3762, 16
  store i64 %op3763, ptr %slot623, align 8
  %v3764 = load i64, ptr %slot621, align 8
  %p3765 = inttoptr i64 %v3764 to ptr
  %rgep3766 = getelementptr i8, ptr %p3765, i64 -16
  %ld3767 = load i64, ptr %rgep3766, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3767, ptr %slot624, align 8
  %v3768 = load i64, ptr %slot624, align 8
  %op3769 = and i64 %v3768, 4611686018427387906
  store i64 %op3769, ptr %slot625, align 8
  %v3770 = load i64, ptr %slot625, align 8
  %cmp3771 = icmp ne i64 %v3770, 0
  %cv3772 = zext i1 %cmp3771 to i32
  store i32 %cv3772, ptr %slot626, align 8
  %v3773 = load i32, ptr %slot626, align 8
  %cv3774 = zext i32 %v3773 to i64
  %cond3775 = icmp ne i64 %cv3774, 0
  br i1 %cond3775, label %bb_rcgspecial785, label %bb_rcginc785
bb_rcginc785:
  %v3776 = load i64, ptr %slot621, align 8
  %op3777 = sub i64 %v3776, 32
  store i64 %op3777, ptr %slot627, align 8
  %v3778 = load i64, ptr %slot621, align 8
  %p3779 = inttoptr i64 %v3778 to ptr
  %rgep3780 = getelementptr i8, ptr %p3779, i64 -32
  %ld3781 = load i64, ptr %rgep3780, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3781, ptr %slot628, align 8
  %v3782 = load i64, ptr %slot628, align 8
  %op3783 = add i64 %v3782, 1
  store i64 %op3783, ptr %slot629, align 8
  %v3784 = load i64, ptr %slot629, align 8
  %cmp3785 = icmp eq i64 %v3784, 0
  %cv3786 = zext i1 %cmp3785 to i32
  store i32 %cv3786, ptr %slot630, align 8
  %v3787 = load i32, ptr %slot630, align 8
  %cv3788 = zext i32 %v3787 to i64
  %cond3789 = icmp ne i64 %cv3788, 0
  br i1 %cond3789, label %bb_rcglimit785, label %bb_rcgcapacity785
bb_rcglimit785:
  %v3790 = load i64, ptr %slot1, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  %call3792 = call i32 @myl_qbe_rc_status(ptr %p3791, i32 2) nomerge, !dbg !128
  store i32 %call3792, ptr %slot631, align 8
  br label %bb_failure
bb_rcgcapacity785:
  %v3793 = load i64, ptr %slot629, align 8
  %v3794 = load i64, ptr %slot621, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  %rgep3796 = getelementptr i8, ptr %p3795, i64 -32
  store i64 %v3793, ptr %rgep3796, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain785
bb_rcgspecial785:
  %v3797 = load i64, ptr %slot624, align 8
  %op3798 = and i64 %v3797, 4611686018427387904
  store i64 %op3798, ptr %slot632, align 8
  %v3799 = load i64, ptr %slot632, align 8
  %cmp3800 = icmp ne i64 %v3799, 0
  %cv3801 = zext i1 %cmp3800 to i32
  store i32 %cv3801, ptr %slot633, align 8
  %v3802 = load i32, ptr %slot633, align 8
  %cv3803 = zext i32 %v3802 to i64
  %cond3804 = icmp ne i64 %cv3803, 0
  br i1 %cond3804, label %bb_rcgslow785, label %bb_rcgplain785
bb_rcgslow785:
  %v3805 = load i64, ptr %slot41, align 8
  %v3806 = load i64, ptr %slot619, align 8
  %v3807 = load i64, ptr %slot597, align 8
  %v3808 = load i64, ptr %slot620, align 8
  %cv3809 = trunc i64 %v3808 to i32
  %call3810 = call i32 @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_retain(i64 %v3805, i64 %v3806, i64 %v3807, i32 %cv3809) nomerge, !dbg !128
  store i32 %call3810, ptr %slot634, align 8
  %v3811 = load i32, ptr %slot634, align 8
  %cv3812 = zext i32 %v3811 to i64
  %cond3813 = icmp ne i64 %cv3812, 0
  br i1 %cond3813, label %bb_rcsuccess799, label %bb_rcfailure799
bb_rcfailure799:
  %v3814 = load i64, ptr %slot41, align 8
  %p3815 = inttoptr i64 %v3814 to ptr
  %call3816 = call i32 @myl_rc_take_failure(ptr %p3815) nomerge, !dbg !128
  store i32 %call3816, ptr %slot635, align 8
  %v3817 = load i64, ptr %slot1, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  %v3819 = load i32, ptr %slot635, align 8
  %call3820 = call i32 @myl_qbe_rc_status(ptr %p3818, i32 %v3819) nomerge, !dbg !128
  store i32 %call3820, ptr %slot636, align 8
  br label %bb_failure
bb_rcsuccess799:
  br label %bb_rcgdone785
bb_rcgplain785:
  %v3821 = load i64, ptr %slot621, align 8
  %v3822 = load i64, ptr %slot619, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  store i64 %v3821, ptr %p3823, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone785
bb_rcgdone785:
  %v3824 = load i64, ptr %slot21, align 8
  %p3825 = inttoptr i64 %v3824 to ptr
  store i32 2, ptr %p3825, align 4, !alias.scope !3, !noalias !4
  %v3826 = load i64, ptr %slot20, align 8
  %p3827 = inttoptr i64 %v3826 to ptr
  store i32 1, ptr %p3827, align 4, !alias.scope !3, !noalias !4
  %v3828 = load i64, ptr %slot14, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  %ld3830 = load i32, ptr %p3829, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3830, ptr %slot637, align 8
  %v3831 = load i32, ptr %slot637, align 8
  %cv3832 = zext i32 %v3831 to i64
  %cond3833 = icmp ne i64 %cv3832, 0
  br i1 %cond3833, label %bb_rcslotdrop806, label %bb_rcslotdone806
bb_rcslotdrop806:
  %v3834 = load i64, ptr %slot14, align 8
  %p3835 = inttoptr i64 %v3834 to ptr
  store i32 0, ptr %p3835, align 4, !alias.scope !3, !noalias !4
  %v3836 = load i64, ptr %slot24, align 8
  store i64 %v3836, ptr %slot638, align 8
  %v3837 = load i64, ptr %slot15, align 8
  %p3838 = inttoptr i64 %v3837 to ptr
  %ld3839 = load i32, ptr %p3838, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3839, ptr %slot639, align 8
  %v3840 = load i32, ptr %slot639, align 8
  %op3841 = and i32 %v3840, 28
  store i32 %op3841, ptr %slot640, align 8
  %v3842 = load i32, ptr %slot640, align 8
  %cv3843 = zext i32 %v3842 to i64
  %cond3844 = icmp ne i64 %cv3843, 0
  br i1 %cond3844, label %bb_rcslotrole806, label %bb_rcslotowner806
bb_rcslotrole806:
  %v3845 = load i64, ptr %slot41, align 8
  store i64 %v3845, ptr %slot641, align 8
  %v3846 = load i64, ptr %slot638, align 8
  %p3847 = inttoptr i64 %v3846 to ptr
  %ld3848 = load i64, ptr %p3847, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3848, ptr %slot642, align 8
  %v3849 = load i64, ptr %slot642, align 8
  %cmp3850 = icmp ne i64 %v3849, 0
  %cv3851 = zext i1 %cmp3850 to i32
  store i32 %cv3851, ptr %slot643, align 8
  %v3852 = load i32, ptr %slot643, align 8
  %cv3853 = zext i32 %v3852 to i64
  %cond3854 = icmp ne i64 %cv3853, 0
  br i1 %cond3854, label %bb_rcgnn822, label %bb_rcgdone822
bb_rcgnn822:
  %v3855 = load i64, ptr %slot642, align 8
  %op3856 = sub i64 %v3855, 16
  store i64 %op3856, ptr %slot644, align 8
  %v3857 = load i64, ptr %slot642, align 8
  %p3858 = inttoptr i64 %v3857 to ptr
  %rgep3859 = getelementptr i8, ptr %p3858, i64 -16
  %ld3860 = load i64, ptr %rgep3859, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3860, ptr %slot645, align 8
  %v3861 = load i64, ptr %slot645, align 8
  %op3862 = and i64 %v3861, 4611686018427387906
  store i64 %op3862, ptr %slot646, align 8
  %v3863 = load i64, ptr %slot646, align 8
  %cmp3864 = icmp ne i64 %v3863, 0
  %cv3865 = zext i1 %cmp3864 to i32
  store i32 %cv3865, ptr %slot647, align 8
  %v3866 = load i32, ptr %slot647, align 8
  %cv3867 = zext i32 %v3866 to i64
  %cond3868 = icmp ne i64 %cv3867, 0
  br i1 %cond3868, label %bb_rcgclear822, label %bb_rcgcounted822
bb_rcgcounted822:
  %v3869 = load i64, ptr %slot642, align 8
  %op3870 = sub i64 %v3869, 24
  store i64 %op3870, ptr %slot648, align 8
  %v3871 = load i64, ptr %slot642, align 8
  %p3872 = inttoptr i64 %v3871 to ptr
  %rgep3873 = getelementptr i8, ptr %p3872, i64 -24
  %ld3874 = load i64, ptr %rgep3873, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3874, ptr %slot649, align 8
  %v3875 = load i64, ptr %slot649, align 8
  %op3876 = sub i64 %v3875, 1
  store i64 %op3876, ptr %slot650, align 8
  %v3877 = load i64, ptr %slot650, align 8
  %cmp3878 = icmp eq i64 %v3877, 0
  %cv3879 = zext i1 %cmp3878 to i32
  store i32 %cv3879, ptr %slot651, align 8
  %v3880 = load i32, ptr %slot651, align 8
  %cv3881 = zext i32 %v3880 to i64
  %cond3882 = icmp ne i64 %cv3881, 0
  br i1 %cond3882, label %bb_rcglast822, label %bb_rcgdec822
bb_rcglast822:
  %v3883 = load i64, ptr %slot642, align 8
  %op3884 = sub i64 %v3883, 32
  store i64 %op3884, ptr %slot652, align 8
  %v3885 = load i64, ptr %slot642, align 8
  %p3886 = inttoptr i64 %v3885 to ptr
  %rgep3887 = getelementptr i8, ptr %p3886, i64 -32
  %ld3888 = load i64, ptr %rgep3887, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3888, ptr %slot653, align 8
  %v3889 = load i64, ptr %slot653, align 8
  %cmp3890 = icmp ne i64 %v3889, 0
  %cv3891 = zext i1 %cmp3890 to i32
  store i32 %cv3891, ptr %slot654, align 8
  %v3892 = load i32, ptr %slot654, align 8
  %cv3893 = zext i32 %v3892 to i64
  %cond3894 = icmp ne i64 %cv3893, 0
  br i1 %cond3894, label %bb_rcgdec822, label %bb_rcgslow822
bb_rcgslow822:
  %v3895 = load i64, ptr %slot641, align 8
  %v3896 = load i64, ptr %slot638, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_unloan(i64 %v3895, i64 %v3896) nomerge, !dbg !128
  br label %bb_rcgdone822
bb_rcgdec822:
  %v3897 = load i64, ptr %slot650, align 8
  %v3898 = load i64, ptr %slot642, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  %rgep3900 = getelementptr i8, ptr %p3899, i64 -24
  store i64 %v3897, ptr %rgep3900, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear822
bb_rcgclear822:
  %v3901 = load i64, ptr %slot638, align 8
  %p3902 = inttoptr i64 %v3901 to ptr
  store i64 0, ptr %p3902, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone822
bb_rcgdone822:
  br label %bb_rcslotdone806
bb_rcslotowner806:
  %v3903 = load i64, ptr %slot41, align 8
  store i64 %v3903, ptr %slot655, align 8
  %v3904 = load i64, ptr %slot638, align 8
  %p3905 = inttoptr i64 %v3904 to ptr
  %ld3906 = load i64, ptr %p3905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3906, ptr %slot656, align 8
  %v3907 = load i64, ptr %slot656, align 8
  %cmp3908 = icmp ne i64 %v3907, 0
  %cv3909 = zext i1 %cmp3908 to i32
  store i32 %cv3909, ptr %slot657, align 8
  %v3910 = load i32, ptr %slot657, align 8
  %cv3911 = zext i32 %v3910 to i64
  %cond3912 = icmp ne i64 %cv3911, 0
  br i1 %cond3912, label %bb_rcgnn837, label %bb_rcgdone837
bb_rcgnn837:
  %v3913 = load i64, ptr %slot656, align 8
  %op3914 = sub i64 %v3913, 16
  store i64 %op3914, ptr %slot658, align 8
  %v3915 = load i64, ptr %slot656, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  %rgep3917 = getelementptr i8, ptr %p3916, i64 -16
  %ld3918 = load i64, ptr %rgep3917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3918, ptr %slot659, align 8
  %v3919 = load i64, ptr %slot659, align 8
  %op3920 = and i64 %v3919, 4611686018427387906
  store i64 %op3920, ptr %slot660, align 8
  %v3921 = load i64, ptr %slot660, align 8
  %cmp3922 = icmp ne i64 %v3921, 0
  %cv3923 = zext i1 %cmp3922 to i32
  store i32 %cv3923, ptr %slot661, align 8
  %v3924 = load i32, ptr %slot661, align 8
  %cv3925 = zext i32 %v3924 to i64
  %cond3926 = icmp ne i64 %cv3925, 0
  br i1 %cond3926, label %bb_rcgclear837, label %bb_rcgcounted837
bb_rcgcounted837:
  %v3927 = load i64, ptr %slot656, align 8
  %op3928 = sub i64 %v3927, 32
  store i64 %op3928, ptr %slot662, align 8
  %v3929 = load i64, ptr %slot656, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  %rgep3931 = getelementptr i8, ptr %p3930, i64 -32
  %ld3932 = load i64, ptr %rgep3931, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3932, ptr %slot663, align 8
  %v3933 = load i64, ptr %slot663, align 8
  %op3934 = sub i64 %v3933, 1
  store i64 %op3934, ptr %slot664, align 8
  %v3935 = load i64, ptr %slot664, align 8
  %cmp3936 = icmp eq i64 %v3935, 0
  %cv3937 = zext i1 %cmp3936 to i32
  store i32 %cv3937, ptr %slot665, align 8
  %v3938 = load i32, ptr %slot665, align 8
  %cv3939 = zext i32 %v3938 to i64
  %cond3940 = icmp ne i64 %cv3939, 0
  br i1 %cond3940, label %bb_rcglast837, label %bb_rcgdec837
bb_rcglast837:
  %v3941 = load i64, ptr %slot656, align 8
  %op3942 = sub i64 %v3941, 24
  store i64 %op3942, ptr %slot666, align 8
  %v3943 = load i64, ptr %slot656, align 8
  %p3944 = inttoptr i64 %v3943 to ptr
  %rgep3945 = getelementptr i8, ptr %p3944, i64 -24
  %ld3946 = load i64, ptr %rgep3945, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3946, ptr %slot667, align 8
  %v3947 = load i64, ptr %slot667, align 8
  %cmp3948 = icmp ne i64 %v3947, 0
  %cv3949 = zext i1 %cmp3948 to i32
  store i32 %cv3949, ptr %slot668, align 8
  %v3950 = load i32, ptr %slot668, align 8
  %cv3951 = zext i32 %v3950 to i64
  %cond3952 = icmp ne i64 %cv3951, 0
  br i1 %cond3952, label %bb_rcgdec837, label %bb_rcgslow837
bb_rcgslow837:
  %v3953 = load i64, ptr %slot655, align 8
  %v3954 = load i64, ptr %slot638, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_drop(i64 %v3953, i64 %v3954) nomerge, !dbg !128
  br label %bb_rcgdone837
bb_rcgdec837:
  %v3955 = load i64, ptr %slot664, align 8
  %v3956 = load i64, ptr %slot656, align 8
  %p3957 = inttoptr i64 %v3956 to ptr
  %rgep3958 = getelementptr i8, ptr %p3957, i64 -32
  store i64 %v3955, ptr %rgep3958, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear837
bb_rcgclear837:
  %v3959 = load i64, ptr %slot638, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  store i64 0, ptr %p3960, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone837
bb_rcgdone837:
  br label %bb_rcslotdone806
bb_rcslotdone806:
  br label %bb_rcprepared752
bb_rcprepared752:
  %v3961 = load i64, ptr %slot31, align 8
  store i64 %v3961, ptr %slot669, align 8
  %v3962 = load i64, ptr %slot669, align 8
  %v3963 = load i64, ptr %slot595, align 8
  %p3964 = inttoptr i64 %v3962 to ptr
  %p3965 = inttoptr i64 %v3963 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3965, ptr %p3964, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3966 = load i64, ptr %slot20, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  store i32 0, ptr %p3967, align 4, !alias.scope !3, !noalias !4
  %v3968 = load i64, ptr %slot38, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  %ld3970 = load i64, ptr %p3969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3970, ptr %slot670, align 8
  %v3971 = load i64, ptr %slot670, align 8
  %v3972 = load i64, ptr %slot29, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  store i64 %v3971, ptr %p3973, align 8, !alias.scope !3, !noalias !4
  %v3974 = load i64, ptr %slot29, align 8
  store i64 %v3974, ptr %slot671, align 8
  %v3975 = load i64, ptr %slot511, align 8
  %p3977 = inttoptr i64 %v3975 to ptr
  %gep3978 = getelementptr i8, ptr %p3977, i64 16
  %op3976 = ptrtoint ptr %gep3978 to i64
  store i64 %op3976, ptr %slot672, align 8
  %v3979 = load i64, ptr %slot38, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  %ld3981 = load i64, ptr %p3980, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3981, ptr %slot673, align 8
  %v3982 = load i64, ptr %slot673, align 8
  %v3983 = load i64, ptr %slot29, align 8
  %p3984 = inttoptr i64 %v3983 to ptr
  store i64 %v3982, ptr %p3984, align 8, !alias.scope !3, !noalias !4
  %v3985 = load i64, ptr %slot29, align 8
  store i64 %v3985, ptr %slot674, align 8
  %v3986 = load i64, ptr %slot16, align 8
  %p3987 = inttoptr i64 %v3986 to ptr
  %ld3988 = load i32, ptr %p3987, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3988, ptr %slot675, align 8
  %v3989 = load i64, ptr %slot17, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  %ld3991 = load i32, ptr %p3990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3991, ptr %slot676, align 8
  %v3992 = load i32, ptr %slot676, align 8
  %op3993 = and i32 %v3992, 24
  store i32 %op3993, ptr %slot676, align 8
  %v3994 = load i32, ptr %slot676, align 8
  %cmp3995 = icmp eq i32 %v3994, 0
  %cv3996 = zext i1 %cmp3995 to i32
  store i32 %cv3996, ptr %slot677, align 8
  %v3997 = load i32, ptr %slot675, align 8
  %v3998 = load i32, ptr %slot677, align 8
  %op3999 = and i32 %v3997, %v3998
  store i32 %op3999, ptr %slot678, align 8
  %v4000 = load i32, ptr %slot678, align 8
  %cv4001 = zext i32 %v4000 to i64
  %cond4002 = icmp ne i64 %cv4001, 0
  br i1 %cond4002, label %bb_rctake848, label %bb_rccopy848
bb_rctake848:
  %v4003 = load i64, ptr %slot31, align 8
  store i64 %v4003, ptr %slot679, align 8
  %v4004 = load i64, ptr %slot42, align 8
  store i64 %v4004, ptr %slot680, align 8
  %v4005 = load i64, ptr %slot674, align 8
  %v4006 = load i64, ptr %slot679, align 8
  %op4007 = sub i64 %v4005, %v4006
  store i64 %op4007, ptr %slot681, align 8
  %v4008 = load i64, ptr %slot679, align 8
  %v4009 = load i64, ptr %slot674, align 8
  %op4010 = sub i64 %v4008, %v4009
  store i64 %op4010, ptr %slot682, align 8
  %v4011 = load i64, ptr %slot681, align 8
  %cmp4012 = icmp ult i64 %v4011, 8
  %cv4013 = zext i1 %cmp4012 to i32
  store i32 %cv4013, ptr %slot683, align 8
  %v4014 = load i64, ptr %slot682, align 8
  %cmp4015 = icmp ult i64 %v4014, 8
  %cv4016 = zext i1 %cmp4015 to i32
  store i32 %cv4016, ptr %slot684, align 8
  %v4017 = load i32, ptr %slot683, align 8
  %v4018 = load i32, ptr %slot684, align 8
  %op4019 = or i32 %v4017, %v4018
  store i32 %op4019, ptr %slot685, align 8
  %v4020 = load i32, ptr %slot685, align 8
  %cv4021 = zext i32 %v4020 to i64
  %cond4022 = icmp ne i64 %cv4021, 0
  br i1 %cond4022, label %bb_rcmoveslow857, label %bb_rcmovecheck857
bb_rcmovecheck857:
  %v4023 = load i64, ptr %slot674, align 8
  %p4025 = inttoptr i64 %v4023 to ptr
  %gep4026 = getelementptr i8, ptr %p4025, i64 0
  %op4024 = ptrtoint ptr %gep4026 to i64
  store i64 %op4024, ptr %slot686, align 8
  %v4027 = load i64, ptr %slot686, align 8
  %p4028 = inttoptr i64 %v4027 to ptr
  %ld4029 = load i64, ptr %p4028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4029, ptr %slot687, align 8
  %v4030 = load i64, ptr %slot687, align 8
  %cmp4031 = icmp ne i64 %v4030, 0
  %cv4032 = zext i1 %cmp4031 to i32
  store i32 %cv4032, ptr %slot688, align 8
  %v4033 = load i32, ptr %slot688, align 8
  %cv4034 = zext i32 %v4033 to i64
  %cond4035 = icmp ne i64 %cv4034, 0
  br i1 %cond4035, label %bb_rcmoveheader865, label %bb_rcmovenext865
bb_rcmoveheader865:
  %v4036 = load i64, ptr %slot687, align 8
  %op4037 = sub i64 %v4036, 16
  store i64 %op4037, ptr %slot689, align 8
  %v4038 = load i64, ptr %slot687, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  %rgep4040 = getelementptr i8, ptr %p4039, i64 -16
  %ld4041 = load i64, ptr %rgep4040, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4041, ptr %slot690, align 8
  %v4042 = load i64, ptr %slot690, align 8
  %op4043 = and i64 %v4042, 5764607523034234881
  store i64 %op4043, ptr %slot691, align 8
  %v4044 = load i64, ptr %slot691, align 8
  %cmp4045 = icmp ne i64 %v4044, 0
  %cv4046 = zext i1 %cmp4045 to i32
  store i32 %cv4046, ptr %slot692, align 8
  %v4047 = load i32, ptr %slot692, align 8
  %cv4048 = zext i32 %v4047 to i64
  %cond4049 = icmp ne i64 %cv4048, 0
  br i1 %cond4049, label %bb_rcmoveslow857, label %bb_rcmovenext865
bb_rcmovenext865:
  %v4050 = load i64, ptr %slot674, align 8
  %v4051 = load i64, ptr %slot679, align 8
  %p4052 = inttoptr i64 %v4050 to ptr
  %p4053 = inttoptr i64 %v4051 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4053, ptr %p4052, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4054 = load i64, ptr %slot674, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  store i64 0, ptr %p4055, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved857
bb_rcmoveslow857:
  %v4056 = load i64, ptr %slot41, align 8
  %v4057 = load i64, ptr %slot679, align 8
  %v4058 = load i64, ptr %slot674, align 8
  %v4059 = load i64, ptr %slot680, align 8
  %cv4060 = trunc i64 %v4059 to i32
  %call4061 = call i32 @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_take(i64 %v4056, i64 %v4057, i64 %v4058, i32 %cv4060) nomerge, !dbg !128
  store i32 %call4061, ptr %slot693, align 8
  %v4062 = load i32, ptr %slot693, align 8
  %cv4063 = zext i32 %v4062 to i64
  %cond4064 = icmp ne i64 %cv4063, 0
  br i1 %cond4064, label %bb_rcsuccess872, label %bb_rcfailure872
bb_rcfailure872:
  %v4065 = load i64, ptr %slot41, align 8
  %p4066 = inttoptr i64 %v4065 to ptr
  %call4067 = call i32 @myl_rc_take_failure(ptr %p4066) nomerge, !dbg !128
  store i32 %call4067, ptr %slot694, align 8
  %v4068 = load i64, ptr %slot1, align 8
  %p4069 = inttoptr i64 %v4068 to ptr
  %v4070 = load i32, ptr %slot694, align 8
  %call4071 = call i32 @myl_qbe_rc_status(ptr %p4069, i32 %v4070) nomerge, !dbg !128
  store i32 %call4071, ptr %slot695, align 8
  br label %bb_failure
bb_rcsuccess872:
  br label %bb_rcmoved857
bb_rcmoved857:
  %v4072 = load i64, ptr %slot16, align 8
  %p4073 = inttoptr i64 %v4072 to ptr
  store i32 0, ptr %p4073, align 4, !alias.scope !3, !noalias !4
  %v4074 = load i64, ptr %slot21, align 8
  %p4075 = inttoptr i64 %v4074 to ptr
  store i32 2, ptr %p4075, align 4, !alias.scope !3, !noalias !4
  %v4076 = load i64, ptr %slot20, align 8
  %p4077 = inttoptr i64 %v4076 to ptr
  store i32 1, ptr %p4077, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared848
bb_rccopy848:
  %v4078 = load i64, ptr %slot31, align 8
  store i64 %v4078, ptr %slot696, align 8
  %v4079 = load i64, ptr %slot42, align 8
  store i64 %v4079, ptr %slot697, align 8
  %v4080 = load i64, ptr %slot674, align 8
  %p4081 = inttoptr i64 %v4080 to ptr
  %ld4082 = load i64, ptr %p4081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4082, ptr %slot698, align 8
  %v4083 = load i64, ptr %slot698, align 8
  %cmp4084 = icmp ne i64 %v4083, 0
  %cv4085 = zext i1 %cmp4084 to i32
  store i32 %cv4085, ptr %slot699, align 8
  %v4086 = load i32, ptr %slot699, align 8
  %cv4087 = zext i32 %v4086 to i64
  %cond4088 = icmp ne i64 %cv4087, 0
  br i1 %cond4088, label %bb_rcgnn881, label %bb_rcgplain881
bb_rcgnn881:
  %v4089 = load i64, ptr %slot698, align 8
  %op4090 = sub i64 %v4089, 16
  store i64 %op4090, ptr %slot700, align 8
  %v4091 = load i64, ptr %slot698, align 8
  %p4092 = inttoptr i64 %v4091 to ptr
  %rgep4093 = getelementptr i8, ptr %p4092, i64 -16
  %ld4094 = load i64, ptr %rgep4093, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4094, ptr %slot701, align 8
  %v4095 = load i64, ptr %slot701, align 8
  %op4096 = and i64 %v4095, 4611686018427387906
  store i64 %op4096, ptr %slot702, align 8
  %v4097 = load i64, ptr %slot702, align 8
  %cmp4098 = icmp ne i64 %v4097, 0
  %cv4099 = zext i1 %cmp4098 to i32
  store i32 %cv4099, ptr %slot703, align 8
  %v4100 = load i32, ptr %slot703, align 8
  %cv4101 = zext i32 %v4100 to i64
  %cond4102 = icmp ne i64 %cv4101, 0
  br i1 %cond4102, label %bb_rcgspecial881, label %bb_rcginc881
bb_rcginc881:
  %v4103 = load i64, ptr %slot698, align 8
  %op4104 = sub i64 %v4103, 32
  store i64 %op4104, ptr %slot704, align 8
  %v4105 = load i64, ptr %slot698, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  %rgep4107 = getelementptr i8, ptr %p4106, i64 -32
  %ld4108 = load i64, ptr %rgep4107, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4108, ptr %slot705, align 8
  %v4109 = load i64, ptr %slot705, align 8
  %op4110 = add i64 %v4109, 1
  store i64 %op4110, ptr %slot706, align 8
  %v4111 = load i64, ptr %slot706, align 8
  %cmp4112 = icmp eq i64 %v4111, 0
  %cv4113 = zext i1 %cmp4112 to i32
  store i32 %cv4113, ptr %slot707, align 8
  %v4114 = load i32, ptr %slot707, align 8
  %cv4115 = zext i32 %v4114 to i64
  %cond4116 = icmp ne i64 %cv4115, 0
  br i1 %cond4116, label %bb_rcglimit881, label %bb_rcgcapacity881
bb_rcglimit881:
  %v4117 = load i64, ptr %slot1, align 8
  %p4118 = inttoptr i64 %v4117 to ptr
  %call4119 = call i32 @myl_qbe_rc_status(ptr %p4118, i32 2) nomerge, !dbg !128
  store i32 %call4119, ptr %slot708, align 8
  br label %bb_failure
bb_rcgcapacity881:
  %v4120 = load i64, ptr %slot706, align 8
  %v4121 = load i64, ptr %slot698, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  %rgep4123 = getelementptr i8, ptr %p4122, i64 -32
  store i64 %v4120, ptr %rgep4123, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain881
bb_rcgspecial881:
  %v4124 = load i64, ptr %slot701, align 8
  %op4125 = and i64 %v4124, 4611686018427387904
  store i64 %op4125, ptr %slot709, align 8
  %v4126 = load i64, ptr %slot709, align 8
  %cmp4127 = icmp ne i64 %v4126, 0
  %cv4128 = zext i1 %cmp4127 to i32
  store i32 %cv4128, ptr %slot710, align 8
  %v4129 = load i32, ptr %slot710, align 8
  %cv4130 = zext i32 %v4129 to i64
  %cond4131 = icmp ne i64 %cv4130, 0
  br i1 %cond4131, label %bb_rcgslow881, label %bb_rcgplain881
bb_rcgslow881:
  %v4132 = load i64, ptr %slot41, align 8
  %v4133 = load i64, ptr %slot696, align 8
  %v4134 = load i64, ptr %slot674, align 8
  %v4135 = load i64, ptr %slot697, align 8
  %cv4136 = trunc i64 %v4135 to i32
  %call4137 = call i32 @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_retain(i64 %v4132, i64 %v4133, i64 %v4134, i32 %cv4136) nomerge, !dbg !128
  store i32 %call4137, ptr %slot711, align 8
  %v4138 = load i32, ptr %slot711, align 8
  %cv4139 = zext i32 %v4138 to i64
  %cond4140 = icmp ne i64 %cv4139, 0
  br i1 %cond4140, label %bb_rcsuccess895, label %bb_rcfailure895
bb_rcfailure895:
  %v4141 = load i64, ptr %slot41, align 8
  %p4142 = inttoptr i64 %v4141 to ptr
  %call4143 = call i32 @myl_rc_take_failure(ptr %p4142) nomerge, !dbg !128
  store i32 %call4143, ptr %slot712, align 8
  %v4144 = load i64, ptr %slot1, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  %v4146 = load i32, ptr %slot712, align 8
  %call4147 = call i32 @myl_qbe_rc_status(ptr %p4145, i32 %v4146) nomerge, !dbg !128
  store i32 %call4147, ptr %slot713, align 8
  br label %bb_failure
bb_rcsuccess895:
  br label %bb_rcgdone881
bb_rcgplain881:
  %v4148 = load i64, ptr %slot698, align 8
  %v4149 = load i64, ptr %slot696, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  store i64 %v4148, ptr %p4150, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone881
bb_rcgdone881:
  %v4151 = load i64, ptr %slot21, align 8
  %p4152 = inttoptr i64 %v4151 to ptr
  store i32 2, ptr %p4152, align 4, !alias.scope !3, !noalias !4
  %v4153 = load i64, ptr %slot20, align 8
  %p4154 = inttoptr i64 %v4153 to ptr
  store i32 1, ptr %p4154, align 4, !alias.scope !3, !noalias !4
  %v4155 = load i64, ptr %slot16, align 8
  %p4156 = inttoptr i64 %v4155 to ptr
  %ld4157 = load i32, ptr %p4156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4157, ptr %slot714, align 8
  %v4158 = load i32, ptr %slot714, align 8
  %cv4159 = zext i32 %v4158 to i64
  %cond4160 = icmp ne i64 %cv4159, 0
  br i1 %cond4160, label %bb_rcslotdrop902, label %bb_rcslotdone902
bb_rcslotdrop902:
  %v4161 = load i64, ptr %slot16, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  store i32 0, ptr %p4162, align 4, !alias.scope !3, !noalias !4
  %v4163 = load i64, ptr %slot25, align 8
  store i64 %v4163, ptr %slot715, align 8
  %v4164 = load i64, ptr %slot17, align 8
  %p4165 = inttoptr i64 %v4164 to ptr
  %ld4166 = load i32, ptr %p4165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4166, ptr %slot716, align 8
  %v4167 = load i32, ptr %slot716, align 8
  %op4168 = and i32 %v4167, 28
  store i32 %op4168, ptr %slot717, align 8
  %v4169 = load i32, ptr %slot717, align 8
  %cv4170 = zext i32 %v4169 to i64
  %cond4171 = icmp ne i64 %cv4170, 0
  br i1 %cond4171, label %bb_rcslotrole902, label %bb_rcslotowner902
bb_rcslotrole902:
  %v4172 = load i64, ptr %slot41, align 8
  store i64 %v4172, ptr %slot718, align 8
  %v4173 = load i64, ptr %slot715, align 8
  %p4174 = inttoptr i64 %v4173 to ptr
  %ld4175 = load i64, ptr %p4174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4175, ptr %slot719, align 8
  %v4176 = load i64, ptr %slot719, align 8
  %cmp4177 = icmp ne i64 %v4176, 0
  %cv4178 = zext i1 %cmp4177 to i32
  store i32 %cv4178, ptr %slot720, align 8
  %v4179 = load i32, ptr %slot720, align 8
  %cv4180 = zext i32 %v4179 to i64
  %cond4181 = icmp ne i64 %cv4180, 0
  br i1 %cond4181, label %bb_rcgnn918, label %bb_rcgdone918
bb_rcgnn918:
  %v4182 = load i64, ptr %slot719, align 8
  %op4183 = sub i64 %v4182, 16
  store i64 %op4183, ptr %slot721, align 8
  %v4184 = load i64, ptr %slot719, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  %rgep4186 = getelementptr i8, ptr %p4185, i64 -16
  %ld4187 = load i64, ptr %rgep4186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4187, ptr %slot722, align 8
  %v4188 = load i64, ptr %slot722, align 8
  %op4189 = and i64 %v4188, 4611686018427387906
  store i64 %op4189, ptr %slot723, align 8
  %v4190 = load i64, ptr %slot723, align 8
  %cmp4191 = icmp ne i64 %v4190, 0
  %cv4192 = zext i1 %cmp4191 to i32
  store i32 %cv4192, ptr %slot724, align 8
  %v4193 = load i32, ptr %slot724, align 8
  %cv4194 = zext i32 %v4193 to i64
  %cond4195 = icmp ne i64 %cv4194, 0
  br i1 %cond4195, label %bb_rcgclear918, label %bb_rcgcounted918
bb_rcgcounted918:
  %v4196 = load i64, ptr %slot719, align 8
  %op4197 = sub i64 %v4196, 24
  store i64 %op4197, ptr %slot725, align 8
  %v4198 = load i64, ptr %slot719, align 8
  %p4199 = inttoptr i64 %v4198 to ptr
  %rgep4200 = getelementptr i8, ptr %p4199, i64 -24
  %ld4201 = load i64, ptr %rgep4200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4201, ptr %slot726, align 8
  %v4202 = load i64, ptr %slot726, align 8
  %op4203 = sub i64 %v4202, 1
  store i64 %op4203, ptr %slot727, align 8
  %v4204 = load i64, ptr %slot727, align 8
  %cmp4205 = icmp eq i64 %v4204, 0
  %cv4206 = zext i1 %cmp4205 to i32
  store i32 %cv4206, ptr %slot728, align 8
  %v4207 = load i32, ptr %slot728, align 8
  %cv4208 = zext i32 %v4207 to i64
  %cond4209 = icmp ne i64 %cv4208, 0
  br i1 %cond4209, label %bb_rcglast918, label %bb_rcgdec918
bb_rcglast918:
  %v4210 = load i64, ptr %slot719, align 8
  %op4211 = sub i64 %v4210, 32
  store i64 %op4211, ptr %slot729, align 8
  %v4212 = load i64, ptr %slot719, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  %rgep4214 = getelementptr i8, ptr %p4213, i64 -32
  %ld4215 = load i64, ptr %rgep4214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4215, ptr %slot730, align 8
  %v4216 = load i64, ptr %slot730, align 8
  %cmp4217 = icmp ne i64 %v4216, 0
  %cv4218 = zext i1 %cmp4217 to i32
  store i32 %cv4218, ptr %slot731, align 8
  %v4219 = load i32, ptr %slot731, align 8
  %cv4220 = zext i32 %v4219 to i64
  %cond4221 = icmp ne i64 %cv4220, 0
  br i1 %cond4221, label %bb_rcgdec918, label %bb_rcgslow918
bb_rcgslow918:
  %v4222 = load i64, ptr %slot718, align 8
  %v4223 = load i64, ptr %slot715, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_unloan(i64 %v4222, i64 %v4223) nomerge, !dbg !128
  br label %bb_rcgdone918
bb_rcgdec918:
  %v4224 = load i64, ptr %slot727, align 8
  %v4225 = load i64, ptr %slot719, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  %rgep4227 = getelementptr i8, ptr %p4226, i64 -24
  store i64 %v4224, ptr %rgep4227, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear918
bb_rcgclear918:
  %v4228 = load i64, ptr %slot715, align 8
  %p4229 = inttoptr i64 %v4228 to ptr
  store i64 0, ptr %p4229, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone918
bb_rcgdone918:
  br label %bb_rcslotdone902
bb_rcslotowner902:
  %v4230 = load i64, ptr %slot41, align 8
  store i64 %v4230, ptr %slot732, align 8
  %v4231 = load i64, ptr %slot715, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %ld4233 = load i64, ptr %p4232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4233, ptr %slot733, align 8
  %v4234 = load i64, ptr %slot733, align 8
  %cmp4235 = icmp ne i64 %v4234, 0
  %cv4236 = zext i1 %cmp4235 to i32
  store i32 %cv4236, ptr %slot734, align 8
  %v4237 = load i32, ptr %slot734, align 8
  %cv4238 = zext i32 %v4237 to i64
  %cond4239 = icmp ne i64 %cv4238, 0
  br i1 %cond4239, label %bb_rcgnn933, label %bb_rcgdone933
bb_rcgnn933:
  %v4240 = load i64, ptr %slot733, align 8
  %op4241 = sub i64 %v4240, 16
  store i64 %op4241, ptr %slot735, align 8
  %v4242 = load i64, ptr %slot733, align 8
  %p4243 = inttoptr i64 %v4242 to ptr
  %rgep4244 = getelementptr i8, ptr %p4243, i64 -16
  %ld4245 = load i64, ptr %rgep4244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4245, ptr %slot736, align 8
  %v4246 = load i64, ptr %slot736, align 8
  %op4247 = and i64 %v4246, 4611686018427387906
  store i64 %op4247, ptr %slot737, align 8
  %v4248 = load i64, ptr %slot737, align 8
  %cmp4249 = icmp ne i64 %v4248, 0
  %cv4250 = zext i1 %cmp4249 to i32
  store i32 %cv4250, ptr %slot738, align 8
  %v4251 = load i32, ptr %slot738, align 8
  %cv4252 = zext i32 %v4251 to i64
  %cond4253 = icmp ne i64 %cv4252, 0
  br i1 %cond4253, label %bb_rcgclear933, label %bb_rcgcounted933
bb_rcgcounted933:
  %v4254 = load i64, ptr %slot733, align 8
  %op4255 = sub i64 %v4254, 32
  store i64 %op4255, ptr %slot739, align 8
  %v4256 = load i64, ptr %slot733, align 8
  %p4257 = inttoptr i64 %v4256 to ptr
  %rgep4258 = getelementptr i8, ptr %p4257, i64 -32
  %ld4259 = load i64, ptr %rgep4258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4259, ptr %slot740, align 8
  %v4260 = load i64, ptr %slot740, align 8
  %op4261 = sub i64 %v4260, 1
  store i64 %op4261, ptr %slot741, align 8
  %v4262 = load i64, ptr %slot741, align 8
  %cmp4263 = icmp eq i64 %v4262, 0
  %cv4264 = zext i1 %cmp4263 to i32
  store i32 %cv4264, ptr %slot742, align 8
  %v4265 = load i32, ptr %slot742, align 8
  %cv4266 = zext i32 %v4265 to i64
  %cond4267 = icmp ne i64 %cv4266, 0
  br i1 %cond4267, label %bb_rcglast933, label %bb_rcgdec933
bb_rcglast933:
  %v4268 = load i64, ptr %slot733, align 8
  %op4269 = sub i64 %v4268, 24
  store i64 %op4269, ptr %slot743, align 8
  %v4270 = load i64, ptr %slot733, align 8
  %p4271 = inttoptr i64 %v4270 to ptr
  %rgep4272 = getelementptr i8, ptr %p4271, i64 -24
  %ld4273 = load i64, ptr %rgep4272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4273, ptr %slot744, align 8
  %v4274 = load i64, ptr %slot744, align 8
  %cmp4275 = icmp ne i64 %v4274, 0
  %cv4276 = zext i1 %cmp4275 to i32
  store i32 %cv4276, ptr %slot745, align 8
  %v4277 = load i32, ptr %slot745, align 8
  %cv4278 = zext i32 %v4277 to i64
  %cond4279 = icmp ne i64 %cv4278, 0
  br i1 %cond4279, label %bb_rcgdec933, label %bb_rcgslow933
bb_rcgslow933:
  %v4280 = load i64, ptr %slot732, align 8
  %v4281 = load i64, ptr %slot715, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64 %v4280, i64 %v4281) nomerge, !dbg !128
  br label %bb_rcgdone933
bb_rcgdec933:
  %v4282 = load i64, ptr %slot741, align 8
  %v4283 = load i64, ptr %slot733, align 8
  %p4284 = inttoptr i64 %v4283 to ptr
  %rgep4285 = getelementptr i8, ptr %p4284, i64 -32
  store i64 %v4282, ptr %rgep4285, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear933
bb_rcgclear933:
  %v4286 = load i64, ptr %slot715, align 8
  %p4287 = inttoptr i64 %v4286 to ptr
  store i64 0, ptr %p4287, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone933
bb_rcgdone933:
  br label %bb_rcslotdone902
bb_rcslotdone902:
  br label %bb_rcprepared848
bb_rcprepared848:
  %v4288 = load i64, ptr %slot31, align 8
  store i64 %v4288, ptr %slot746, align 8
  %v4289 = load i64, ptr %slot746, align 8
  %v4290 = load i64, ptr %slot672, align 8
  %p4291 = inttoptr i64 %v4289 to ptr
  %p4292 = inttoptr i64 %v4290 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4292, ptr %p4291, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4293 = load i64, ptr %slot20, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  store i32 0, ptr %p4294, align 4, !alias.scope !3, !noalias !4
  %v4295 = load i64, ptr %slot39, align 8
  %p4296 = inttoptr i64 %v4295 to ptr
  %ld4297 = load i64, ptr %p4296, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4297, ptr %slot747, align 8
  %v4298 = load i64, ptr %slot747, align 8
  %v4299 = load i64, ptr %slot30, align 8
  %p4300 = inttoptr i64 %v4299 to ptr
  store i64 %v4298, ptr %p4300, align 8, !alias.scope !3, !noalias !4
  %v4301 = load i64, ptr %slot30, align 8
  store i64 %v4301, ptr %slot748, align 8
  %v4302 = load i64, ptr %slot511, align 8
  %p4304 = inttoptr i64 %v4302 to ptr
  %gep4305 = getelementptr i8, ptr %p4304, i64 24
  %op4303 = ptrtoint ptr %gep4305 to i64
  store i64 %op4303, ptr %slot749, align 8
  %v4306 = load i64, ptr %slot39, align 8
  %p4307 = inttoptr i64 %v4306 to ptr
  %ld4308 = load i64, ptr %p4307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4308, ptr %slot750, align 8
  %v4309 = load i64, ptr %slot750, align 8
  %v4310 = load i64, ptr %slot30, align 8
  %p4311 = inttoptr i64 %v4310 to ptr
  store i64 %v4309, ptr %p4311, align 8, !alias.scope !3, !noalias !4
  %v4312 = load i64, ptr %slot30, align 8
  store i64 %v4312, ptr %slot751, align 8
  %v4313 = load i64, ptr %slot18, align 8
  %p4314 = inttoptr i64 %v4313 to ptr
  %ld4315 = load i32, ptr %p4314, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4315, ptr %slot752, align 8
  %v4316 = load i64, ptr %slot19, align 8
  %p4317 = inttoptr i64 %v4316 to ptr
  %ld4318 = load i32, ptr %p4317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4318, ptr %slot753, align 8
  %v4319 = load i32, ptr %slot753, align 8
  %op4320 = and i32 %v4319, 24
  store i32 %op4320, ptr %slot753, align 8
  %v4321 = load i32, ptr %slot753, align 8
  %cmp4322 = icmp eq i32 %v4321, 0
  %cv4323 = zext i1 %cmp4322 to i32
  store i32 %cv4323, ptr %slot754, align 8
  %v4324 = load i32, ptr %slot752, align 8
  %v4325 = load i32, ptr %slot754, align 8
  %op4326 = and i32 %v4324, %v4325
  store i32 %op4326, ptr %slot755, align 8
  %v4327 = load i32, ptr %slot755, align 8
  %cv4328 = zext i32 %v4327 to i64
  %cond4329 = icmp ne i64 %cv4328, 0
  br i1 %cond4329, label %bb_rctake944, label %bb_rccopy944
bb_rctake944:
  %v4330 = load i64, ptr %slot31, align 8
  store i64 %v4330, ptr %slot756, align 8
  %v4331 = load i64, ptr %slot42, align 8
  store i64 %v4331, ptr %slot757, align 8
  %v4332 = load i64, ptr %slot751, align 8
  %v4333 = load i64, ptr %slot756, align 8
  %op4334 = sub i64 %v4332, %v4333
  store i64 %op4334, ptr %slot758, align 8
  %v4335 = load i64, ptr %slot756, align 8
  %v4336 = load i64, ptr %slot751, align 8
  %op4337 = sub i64 %v4335, %v4336
  store i64 %op4337, ptr %slot759, align 8
  %v4338 = load i64, ptr %slot758, align 8
  %cmp4339 = icmp ult i64 %v4338, 8
  %cv4340 = zext i1 %cmp4339 to i32
  store i32 %cv4340, ptr %slot760, align 8
  %v4341 = load i64, ptr %slot759, align 8
  %cmp4342 = icmp ult i64 %v4341, 8
  %cv4343 = zext i1 %cmp4342 to i32
  store i32 %cv4343, ptr %slot761, align 8
  %v4344 = load i32, ptr %slot760, align 8
  %v4345 = load i32, ptr %slot761, align 8
  %op4346 = or i32 %v4344, %v4345
  store i32 %op4346, ptr %slot762, align 8
  %v4347 = load i32, ptr %slot762, align 8
  %cv4348 = zext i32 %v4347 to i64
  %cond4349 = icmp ne i64 %cv4348, 0
  br i1 %cond4349, label %bb_rcmoveslow953, label %bb_rcmovecheck953
bb_rcmovecheck953:
  %v4350 = load i64, ptr %slot751, align 8
  %p4352 = inttoptr i64 %v4350 to ptr
  %gep4353 = getelementptr i8, ptr %p4352, i64 0
  %op4351 = ptrtoint ptr %gep4353 to i64
  store i64 %op4351, ptr %slot763, align 8
  %v4354 = load i64, ptr %slot763, align 8
  %p4355 = inttoptr i64 %v4354 to ptr
  %ld4356 = load i64, ptr %p4355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4356, ptr %slot764, align 8
  %v4357 = load i64, ptr %slot764, align 8
  %cmp4358 = icmp ne i64 %v4357, 0
  %cv4359 = zext i1 %cmp4358 to i32
  store i32 %cv4359, ptr %slot765, align 8
  %v4360 = load i32, ptr %slot765, align 8
  %cv4361 = zext i32 %v4360 to i64
  %cond4362 = icmp ne i64 %cv4361, 0
  br i1 %cond4362, label %bb_rcmoveheader961, label %bb_rcmovenext961
bb_rcmoveheader961:
  %v4363 = load i64, ptr %slot764, align 8
  %op4364 = sub i64 %v4363, 16
  store i64 %op4364, ptr %slot766, align 8
  %v4365 = load i64, ptr %slot764, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  %rgep4367 = getelementptr i8, ptr %p4366, i64 -16
  %ld4368 = load i64, ptr %rgep4367, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4368, ptr %slot767, align 8
  %v4369 = load i64, ptr %slot767, align 8
  %op4370 = and i64 %v4369, 5764607523034234881
  store i64 %op4370, ptr %slot768, align 8
  %v4371 = load i64, ptr %slot768, align 8
  %cmp4372 = icmp ne i64 %v4371, 0
  %cv4373 = zext i1 %cmp4372 to i32
  store i32 %cv4373, ptr %slot769, align 8
  %v4374 = load i32, ptr %slot769, align 8
  %cv4375 = zext i32 %v4374 to i64
  %cond4376 = icmp ne i64 %cv4375, 0
  br i1 %cond4376, label %bb_rcmoveslow953, label %bb_rcmovenext961
bb_rcmovenext961:
  %v4377 = load i64, ptr %slot751, align 8
  %v4378 = load i64, ptr %slot756, align 8
  %p4379 = inttoptr i64 %v4377 to ptr
  %p4380 = inttoptr i64 %v4378 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4380, ptr %p4379, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4381 = load i64, ptr %slot751, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  store i64 0, ptr %p4382, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved953
bb_rcmoveslow953:
  %v4383 = load i64, ptr %slot41, align 8
  %v4384 = load i64, ptr %slot756, align 8
  %v4385 = load i64, ptr %slot751, align 8
  %v4386 = load i64, ptr %slot757, align 8
  %cv4387 = trunc i64 %v4386 to i32
  %call4388 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v4383, i64 %v4384, i64 %v4385, i32 %cv4387) nomerge, !dbg !128
  store i32 %call4388, ptr %slot770, align 8
  %v4389 = load i32, ptr %slot770, align 8
  %cv4390 = zext i32 %v4389 to i64
  %cond4391 = icmp ne i64 %cv4390, 0
  br i1 %cond4391, label %bb_rcsuccess968, label %bb_rcfailure968
bb_rcfailure968:
  %v4392 = load i64, ptr %slot41, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  %call4394 = call i32 @myl_rc_take_failure(ptr %p4393) nomerge, !dbg !128
  store i32 %call4394, ptr %slot771, align 8
  %v4395 = load i64, ptr %slot1, align 8
  %p4396 = inttoptr i64 %v4395 to ptr
  %v4397 = load i32, ptr %slot771, align 8
  %call4398 = call i32 @myl_qbe_rc_status(ptr %p4396, i32 %v4397) nomerge, !dbg !128
  store i32 %call4398, ptr %slot772, align 8
  br label %bb_failure
bb_rcsuccess968:
  br label %bb_rcmoved953
bb_rcmoved953:
  %v4399 = load i64, ptr %slot18, align 8
  %p4400 = inttoptr i64 %v4399 to ptr
  store i32 0, ptr %p4400, align 4, !alias.scope !3, !noalias !4
  %v4401 = load i64, ptr %slot21, align 8
  %p4402 = inttoptr i64 %v4401 to ptr
  store i32 2, ptr %p4402, align 4, !alias.scope !3, !noalias !4
  %v4403 = load i64, ptr %slot20, align 8
  %p4404 = inttoptr i64 %v4403 to ptr
  store i32 1, ptr %p4404, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared944
bb_rccopy944:
  %v4405 = load i64, ptr %slot31, align 8
  store i64 %v4405, ptr %slot773, align 8
  %v4406 = load i64, ptr %slot42, align 8
  store i64 %v4406, ptr %slot774, align 8
  %v4407 = load i64, ptr %slot751, align 8
  %p4408 = inttoptr i64 %v4407 to ptr
  %ld4409 = load i64, ptr %p4408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4409, ptr %slot775, align 8
  %v4410 = load i64, ptr %slot775, align 8
  %cmp4411 = icmp ne i64 %v4410, 0
  %cv4412 = zext i1 %cmp4411 to i32
  store i32 %cv4412, ptr %slot776, align 8
  %v4413 = load i32, ptr %slot776, align 8
  %cv4414 = zext i32 %v4413 to i64
  %cond4415 = icmp ne i64 %cv4414, 0
  br i1 %cond4415, label %bb_rcgnn977, label %bb_rcgplain977
bb_rcgnn977:
  %v4416 = load i64, ptr %slot775, align 8
  %op4417 = sub i64 %v4416, 16
  store i64 %op4417, ptr %slot777, align 8
  %v4418 = load i64, ptr %slot775, align 8
  %p4419 = inttoptr i64 %v4418 to ptr
  %rgep4420 = getelementptr i8, ptr %p4419, i64 -16
  %ld4421 = load i64, ptr %rgep4420, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4421, ptr %slot778, align 8
  %v4422 = load i64, ptr %slot778, align 8
  %op4423 = and i64 %v4422, 4611686018427387906
  store i64 %op4423, ptr %slot779, align 8
  %v4424 = load i64, ptr %slot779, align 8
  %cmp4425 = icmp ne i64 %v4424, 0
  %cv4426 = zext i1 %cmp4425 to i32
  store i32 %cv4426, ptr %slot780, align 8
  %v4427 = load i32, ptr %slot780, align 8
  %cv4428 = zext i32 %v4427 to i64
  %cond4429 = icmp ne i64 %cv4428, 0
  br i1 %cond4429, label %bb_rcgspecial977, label %bb_rcginc977
bb_rcginc977:
  %v4430 = load i64, ptr %slot775, align 8
  %op4431 = sub i64 %v4430, 32
  store i64 %op4431, ptr %slot781, align 8
  %v4432 = load i64, ptr %slot775, align 8
  %p4433 = inttoptr i64 %v4432 to ptr
  %rgep4434 = getelementptr i8, ptr %p4433, i64 -32
  %ld4435 = load i64, ptr %rgep4434, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4435, ptr %slot782, align 8
  %v4436 = load i64, ptr %slot782, align 8
  %op4437 = add i64 %v4436, 1
  store i64 %op4437, ptr %slot783, align 8
  %v4438 = load i64, ptr %slot783, align 8
  %cmp4439 = icmp eq i64 %v4438, 0
  %cv4440 = zext i1 %cmp4439 to i32
  store i32 %cv4440, ptr %slot784, align 8
  %v4441 = load i32, ptr %slot784, align 8
  %cv4442 = zext i32 %v4441 to i64
  %cond4443 = icmp ne i64 %cv4442, 0
  br i1 %cond4443, label %bb_rcglimit977, label %bb_rcgcapacity977
bb_rcglimit977:
  %v4444 = load i64, ptr %slot1, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  %call4446 = call i32 @myl_qbe_rc_status(ptr %p4445, i32 2) nomerge, !dbg !128
  store i32 %call4446, ptr %slot785, align 8
  br label %bb_failure
bb_rcgcapacity977:
  %v4447 = load i64, ptr %slot783, align 8
  %v4448 = load i64, ptr %slot775, align 8
  %p4449 = inttoptr i64 %v4448 to ptr
  %rgep4450 = getelementptr i8, ptr %p4449, i64 -32
  store i64 %v4447, ptr %rgep4450, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain977
bb_rcgspecial977:
  %v4451 = load i64, ptr %slot778, align 8
  %op4452 = and i64 %v4451, 4611686018427387904
  store i64 %op4452, ptr %slot786, align 8
  %v4453 = load i64, ptr %slot786, align 8
  %cmp4454 = icmp ne i64 %v4453, 0
  %cv4455 = zext i1 %cmp4454 to i32
  store i32 %cv4455, ptr %slot787, align 8
  %v4456 = load i32, ptr %slot787, align 8
  %cv4457 = zext i32 %v4456 to i64
  %cond4458 = icmp ne i64 %cv4457, 0
  br i1 %cond4458, label %bb_rcgslow977, label %bb_rcgplain977
bb_rcgslow977:
  %v4459 = load i64, ptr %slot41, align 8
  %v4460 = load i64, ptr %slot773, align 8
  %v4461 = load i64, ptr %slot751, align 8
  %v4462 = load i64, ptr %slot774, align 8
  %cv4463 = trunc i64 %v4462 to i32
  %call4464 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v4459, i64 %v4460, i64 %v4461, i32 %cv4463) nomerge, !dbg !128
  store i32 %call4464, ptr %slot788, align 8
  %v4465 = load i32, ptr %slot788, align 8
  %cv4466 = zext i32 %v4465 to i64
  %cond4467 = icmp ne i64 %cv4466, 0
  br i1 %cond4467, label %bb_rcsuccess991, label %bb_rcfailure991
bb_rcfailure991:
  %v4468 = load i64, ptr %slot41, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  %call4470 = call i32 @myl_rc_take_failure(ptr %p4469) nomerge, !dbg !128
  store i32 %call4470, ptr %slot789, align 8
  %v4471 = load i64, ptr %slot1, align 8
  %p4472 = inttoptr i64 %v4471 to ptr
  %v4473 = load i32, ptr %slot789, align 8
  %call4474 = call i32 @myl_qbe_rc_status(ptr %p4472, i32 %v4473) nomerge, !dbg !128
  store i32 %call4474, ptr %slot790, align 8
  br label %bb_failure
bb_rcsuccess991:
  br label %bb_rcgdone977
bb_rcgplain977:
  %v4475 = load i64, ptr %slot775, align 8
  %v4476 = load i64, ptr %slot773, align 8
  %p4477 = inttoptr i64 %v4476 to ptr
  store i64 %v4475, ptr %p4477, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone977
bb_rcgdone977:
  %v4478 = load i64, ptr %slot21, align 8
  %p4479 = inttoptr i64 %v4478 to ptr
  store i32 2, ptr %p4479, align 4, !alias.scope !3, !noalias !4
  %v4480 = load i64, ptr %slot20, align 8
  %p4481 = inttoptr i64 %v4480 to ptr
  store i32 1, ptr %p4481, align 4, !alias.scope !3, !noalias !4
  %v4482 = load i64, ptr %slot18, align 8
  %p4483 = inttoptr i64 %v4482 to ptr
  %ld4484 = load i32, ptr %p4483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4484, ptr %slot791, align 8
  %v4485 = load i32, ptr %slot791, align 8
  %cv4486 = zext i32 %v4485 to i64
  %cond4487 = icmp ne i64 %cv4486, 0
  br i1 %cond4487, label %bb_rcslotdrop998, label %bb_rcslotdone998
bb_rcslotdrop998:
  %v4488 = load i64, ptr %slot18, align 8
  %p4489 = inttoptr i64 %v4488 to ptr
  store i32 0, ptr %p4489, align 4, !alias.scope !3, !noalias !4
  %v4490 = load i64, ptr %slot26, align 8
  store i64 %v4490, ptr %slot792, align 8
  %v4491 = load i64, ptr %slot19, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  %ld4493 = load i32, ptr %p4492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4493, ptr %slot793, align 8
  %v4494 = load i32, ptr %slot793, align 8
  %op4495 = and i32 %v4494, 28
  store i32 %op4495, ptr %slot794, align 8
  %v4496 = load i32, ptr %slot794, align 8
  %cv4497 = zext i32 %v4496 to i64
  %cond4498 = icmp ne i64 %cv4497, 0
  br i1 %cond4498, label %bb_rcslotrole998, label %bb_rcslotowner998
bb_rcslotrole998:
  %v4499 = load i64, ptr %slot41, align 8
  store i64 %v4499, ptr %slot795, align 8
  %v4500 = load i64, ptr %slot792, align 8
  %p4501 = inttoptr i64 %v4500 to ptr
  %ld4502 = load i64, ptr %p4501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4502, ptr %slot796, align 8
  %v4503 = load i64, ptr %slot796, align 8
  %cmp4504 = icmp ne i64 %v4503, 0
  %cv4505 = zext i1 %cmp4504 to i32
  store i32 %cv4505, ptr %slot797, align 8
  %v4506 = load i32, ptr %slot797, align 8
  %cv4507 = zext i32 %v4506 to i64
  %cond4508 = icmp ne i64 %cv4507, 0
  br i1 %cond4508, label %bb_rcgnn1014, label %bb_rcgdone1014
bb_rcgnn1014:
  %v4509 = load i64, ptr %slot796, align 8
  %op4510 = sub i64 %v4509, 16
  store i64 %op4510, ptr %slot798, align 8
  %v4511 = load i64, ptr %slot796, align 8
  %p4512 = inttoptr i64 %v4511 to ptr
  %rgep4513 = getelementptr i8, ptr %p4512, i64 -16
  %ld4514 = load i64, ptr %rgep4513, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4514, ptr %slot799, align 8
  %v4515 = load i64, ptr %slot799, align 8
  %op4516 = and i64 %v4515, 4611686018427387906
  store i64 %op4516, ptr %slot800, align 8
  %v4517 = load i64, ptr %slot800, align 8
  %cmp4518 = icmp ne i64 %v4517, 0
  %cv4519 = zext i1 %cmp4518 to i32
  store i32 %cv4519, ptr %slot801, align 8
  %v4520 = load i32, ptr %slot801, align 8
  %cv4521 = zext i32 %v4520 to i64
  %cond4522 = icmp ne i64 %cv4521, 0
  br i1 %cond4522, label %bb_rcgclear1014, label %bb_rcgcounted1014
bb_rcgcounted1014:
  %v4523 = load i64, ptr %slot796, align 8
  %op4524 = sub i64 %v4523, 24
  store i64 %op4524, ptr %slot802, align 8
  %v4525 = load i64, ptr %slot796, align 8
  %p4526 = inttoptr i64 %v4525 to ptr
  %rgep4527 = getelementptr i8, ptr %p4526, i64 -24
  %ld4528 = load i64, ptr %rgep4527, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4528, ptr %slot803, align 8
  %v4529 = load i64, ptr %slot803, align 8
  %op4530 = sub i64 %v4529, 1
  store i64 %op4530, ptr %slot804, align 8
  %v4531 = load i64, ptr %slot804, align 8
  %cmp4532 = icmp eq i64 %v4531, 0
  %cv4533 = zext i1 %cmp4532 to i32
  store i32 %cv4533, ptr %slot805, align 8
  %v4534 = load i32, ptr %slot805, align 8
  %cv4535 = zext i32 %v4534 to i64
  %cond4536 = icmp ne i64 %cv4535, 0
  br i1 %cond4536, label %bb_rcglast1014, label %bb_rcgdec1014
bb_rcglast1014:
  %v4537 = load i64, ptr %slot796, align 8
  %op4538 = sub i64 %v4537, 32
  store i64 %op4538, ptr %slot806, align 8
  %v4539 = load i64, ptr %slot796, align 8
  %p4540 = inttoptr i64 %v4539 to ptr
  %rgep4541 = getelementptr i8, ptr %p4540, i64 -32
  %ld4542 = load i64, ptr %rgep4541, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4542, ptr %slot807, align 8
  %v4543 = load i64, ptr %slot807, align 8
  %cmp4544 = icmp ne i64 %v4543, 0
  %cv4545 = zext i1 %cmp4544 to i32
  store i32 %cv4545, ptr %slot808, align 8
  %v4546 = load i32, ptr %slot808, align 8
  %cv4547 = zext i32 %v4546 to i64
  %cond4548 = icmp ne i64 %cv4547, 0
  br i1 %cond4548, label %bb_rcgdec1014, label %bb_rcgslow1014
bb_rcgslow1014:
  %v4549 = load i64, ptr %slot795, align 8
  %v4550 = load i64, ptr %slot792, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4549, i64 %v4550) nomerge, !dbg !128
  br label %bb_rcgdone1014
bb_rcgdec1014:
  %v4551 = load i64, ptr %slot804, align 8
  %v4552 = load i64, ptr %slot796, align 8
  %p4553 = inttoptr i64 %v4552 to ptr
  %rgep4554 = getelementptr i8, ptr %p4553, i64 -24
  store i64 %v4551, ptr %rgep4554, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1014
bb_rcgclear1014:
  %v4555 = load i64, ptr %slot792, align 8
  %p4556 = inttoptr i64 %v4555 to ptr
  store i64 0, ptr %p4556, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1014
bb_rcgdone1014:
  br label %bb_rcslotdone998
bb_rcslotowner998:
  %v4557 = load i64, ptr %slot41, align 8
  store i64 %v4557, ptr %slot809, align 8
  %v4558 = load i64, ptr %slot792, align 8
  %p4559 = inttoptr i64 %v4558 to ptr
  %ld4560 = load i64, ptr %p4559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4560, ptr %slot810, align 8
  %v4561 = load i64, ptr %slot810, align 8
  %cmp4562 = icmp ne i64 %v4561, 0
  %cv4563 = zext i1 %cmp4562 to i32
  store i32 %cv4563, ptr %slot811, align 8
  %v4564 = load i32, ptr %slot811, align 8
  %cv4565 = zext i32 %v4564 to i64
  %cond4566 = icmp ne i64 %cv4565, 0
  br i1 %cond4566, label %bb_rcgnn1029, label %bb_rcgdone1029
bb_rcgnn1029:
  %v4567 = load i64, ptr %slot810, align 8
  %op4568 = sub i64 %v4567, 16
  store i64 %op4568, ptr %slot812, align 8
  %v4569 = load i64, ptr %slot810, align 8
  %p4570 = inttoptr i64 %v4569 to ptr
  %rgep4571 = getelementptr i8, ptr %p4570, i64 -16
  %ld4572 = load i64, ptr %rgep4571, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4572, ptr %slot813, align 8
  %v4573 = load i64, ptr %slot813, align 8
  %op4574 = and i64 %v4573, 4611686018427387906
  store i64 %op4574, ptr %slot814, align 8
  %v4575 = load i64, ptr %slot814, align 8
  %cmp4576 = icmp ne i64 %v4575, 0
  %cv4577 = zext i1 %cmp4576 to i32
  store i32 %cv4577, ptr %slot815, align 8
  %v4578 = load i32, ptr %slot815, align 8
  %cv4579 = zext i32 %v4578 to i64
  %cond4580 = icmp ne i64 %cv4579, 0
  br i1 %cond4580, label %bb_rcgclear1029, label %bb_rcgcounted1029
bb_rcgcounted1029:
  %v4581 = load i64, ptr %slot810, align 8
  %op4582 = sub i64 %v4581, 32
  store i64 %op4582, ptr %slot816, align 8
  %v4583 = load i64, ptr %slot810, align 8
  %p4584 = inttoptr i64 %v4583 to ptr
  %rgep4585 = getelementptr i8, ptr %p4584, i64 -32
  %ld4586 = load i64, ptr %rgep4585, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4586, ptr %slot817, align 8
  %v4587 = load i64, ptr %slot817, align 8
  %op4588 = sub i64 %v4587, 1
  store i64 %op4588, ptr %slot818, align 8
  %v4589 = load i64, ptr %slot818, align 8
  %cmp4590 = icmp eq i64 %v4589, 0
  %cv4591 = zext i1 %cmp4590 to i32
  store i32 %cv4591, ptr %slot819, align 8
  %v4592 = load i32, ptr %slot819, align 8
  %cv4593 = zext i32 %v4592 to i64
  %cond4594 = icmp ne i64 %cv4593, 0
  br i1 %cond4594, label %bb_rcglast1029, label %bb_rcgdec1029
bb_rcglast1029:
  %v4595 = load i64, ptr %slot810, align 8
  %op4596 = sub i64 %v4595, 24
  store i64 %op4596, ptr %slot820, align 8
  %v4597 = load i64, ptr %slot810, align 8
  %p4598 = inttoptr i64 %v4597 to ptr
  %rgep4599 = getelementptr i8, ptr %p4598, i64 -24
  %ld4600 = load i64, ptr %rgep4599, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4600, ptr %slot821, align 8
  %v4601 = load i64, ptr %slot821, align 8
  %cmp4602 = icmp ne i64 %v4601, 0
  %cv4603 = zext i1 %cmp4602 to i32
  store i32 %cv4603, ptr %slot822, align 8
  %v4604 = load i32, ptr %slot822, align 8
  %cv4605 = zext i32 %v4604 to i64
  %cond4606 = icmp ne i64 %cv4605, 0
  br i1 %cond4606, label %bb_rcgdec1029, label %bb_rcgslow1029
bb_rcgslow1029:
  %v4607 = load i64, ptr %slot809, align 8
  %v4608 = load i64, ptr %slot792, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4607, i64 %v4608) nomerge, !dbg !128
  br label %bb_rcgdone1029
bb_rcgdec1029:
  %v4609 = load i64, ptr %slot818, align 8
  %v4610 = load i64, ptr %slot810, align 8
  %p4611 = inttoptr i64 %v4610 to ptr
  %rgep4612 = getelementptr i8, ptr %p4611, i64 -32
  store i64 %v4609, ptr %rgep4612, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1029
bb_rcgclear1029:
  %v4613 = load i64, ptr %slot792, align 8
  %p4614 = inttoptr i64 %v4613 to ptr
  store i64 0, ptr %p4614, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1029
bb_rcgdone1029:
  br label %bb_rcslotdone998
bb_rcslotdone998:
  br label %bb_rcprepared944
bb_rcprepared944:
  %v4615 = load i64, ptr %slot31, align 8
  store i64 %v4615, ptr %slot823, align 8
  %v4616 = load i64, ptr %slot823, align 8
  %v4617 = load i64, ptr %slot749, align 8
  %p4618 = inttoptr i64 %v4616 to ptr
  %p4619 = inttoptr i64 %v4617 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4619, ptr %p4618, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4620 = load i64, ptr %slot20, align 8
  %p4621 = inttoptr i64 %v4620 to ptr
  store i32 0, ptr %p4621, align 4, !alias.scope !3, !noalias !4
  %v4622 = load i64, ptr %slot511, align 8
  %v4623 = load i64, ptr %slot36, align 8
  %p4624 = inttoptr i64 %v4623 to ptr
  store i64 %v4622, ptr %p4624, align 8, !alias.scope !3, !noalias !4
  %v4625 = load i64, ptr %slot36, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  %ld4627 = load i64, ptr %p4626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4627, ptr %slot824, align 8
  %v4628 = load i64, ptr %slot23, align 8
  store i64 %v4628, ptr %slot825, align 8
  %v4629 = load i64, ptr %slot824, align 8
  %v4630 = load i64, ptr %slot825, align 8
  %p4631 = inttoptr i64 %v4629 to ptr
  %p4632 = inttoptr i64 %v4630 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4632, ptr %p4631, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v4633 = load i64, ptr %slot13, align 8
  %p4634 = inttoptr i64 %v4633 to ptr
  store i32 2, ptr %p4634, align 4, !alias.scope !3, !noalias !4
  %v4635 = load i64, ptr %slot12, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  store i32 1, ptr %p4636, align 4, !alias.scope !3, !noalias !4
  %v4637 = load i64, ptr %slot825, align 8
  %v4638 = load i64, ptr %slot36, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  store i64 %v4637, ptr %p4639, align 8, !alias.scope !3, !noalias !4
  %v4640 = load i64, ptr %slot36, align 8
  %p4641 = inttoptr i64 %v4640 to ptr
  %ld4642 = load i64, ptr %p4641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4642, ptr %slot826, align 8
  %v4643 = load i64, ptr %slot36, align 8
  %p4644 = inttoptr i64 %v4643 to ptr
  %ld4645 = load i64, ptr %p4644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4645, ptr %slot827, align 8
  %v4646 = load i64, ptr %slot31, align 8
  store i64 %v4646, ptr %slot828, align 8
  %v4647 = load i64, ptr %slot42, align 8
  store i64 %v4647, ptr %slot829, align 8
  %v4648 = load i64, ptr %slot827, align 8
  %op4649 = add i64 %v4648, 0
  store i64 %op4649, ptr %slot830, align 8
  %v4650 = load i64, ptr %slot830, align 8
  %p4651 = inttoptr i64 %v4650 to ptr
  %ld4652 = load i64, ptr %p4651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4652, ptr %slot831, align 8
  %v4653 = load i64, ptr %slot831, align 8
  %cmp4654 = icmp ne i64 %v4653, 0
  %cv4655 = zext i1 %cmp4654 to i32
  store i32 %cv4655, ptr %slot832, align 8
  %v4656 = load i32, ptr %slot832, align 8
  %cv4657 = zext i32 %v4656 to i64
  %cond4658 = icmp ne i64 %cv4657, 0
  br i1 %cond4658, label %bb_rcmoveheader1046, label %bb_rcmovenext1046
bb_rcmoveheader1046:
  %v4659 = load i64, ptr %slot831, align 8
  %op4660 = sub i64 %v4659, 16
  store i64 %op4660, ptr %slot833, align 8
  %v4661 = load i64, ptr %slot831, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %rgep4663 = getelementptr i8, ptr %p4662, i64 -16
  %ld4664 = load i64, ptr %rgep4663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4664, ptr %slot834, align 8
  %v4665 = load i64, ptr %slot834, align 8
  %op4666 = and i64 %v4665, 5764607523034234881
  store i64 %op4666, ptr %slot835, align 8
  %v4667 = load i64, ptr %slot835, align 8
  %cmp4668 = icmp ne i64 %v4667, 0
  %cv4669 = zext i1 %cmp4668 to i32
  store i32 %cv4669, ptr %slot836, align 8
  %v4670 = load i32, ptr %slot836, align 8
  %cv4671 = zext i32 %v4670 to i64
  %cond4672 = icmp ne i64 %cv4671, 0
  br i1 %cond4672, label %bb_rcmoveslow1043, label %bb_rcmovenext1046
bb_rcmovenext1046:
  %v4673 = load i64, ptr %slot827, align 8
  %op4674 = add i64 %v4673, 8
  store i64 %op4674, ptr %slot837, align 8
  %v4675 = load i64, ptr %slot837, align 8
  %p4676 = inttoptr i64 %v4675 to ptr
  %ld4677 = load i64, ptr %p4676, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4677, ptr %slot838, align 8
  %v4678 = load i64, ptr %slot838, align 8
  %cmp4679 = icmp ne i64 %v4678, 0
  %cv4680 = zext i1 %cmp4679 to i32
  store i32 %cv4680, ptr %slot839, align 8
  %v4681 = load i32, ptr %slot839, align 8
  %cv4682 = zext i32 %v4681 to i64
  %cond4683 = icmp ne i64 %cv4682, 0
  br i1 %cond4683, label %bb_rcmoveheader1054, label %bb_rcmovenext1054
bb_rcmoveheader1054:
  %v4684 = load i64, ptr %slot838, align 8
  %op4685 = sub i64 %v4684, 16
  store i64 %op4685, ptr %slot840, align 8
  %v4686 = load i64, ptr %slot838, align 8
  %p4687 = inttoptr i64 %v4686 to ptr
  %rgep4688 = getelementptr i8, ptr %p4687, i64 -16
  %ld4689 = load i64, ptr %rgep4688, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4689, ptr %slot841, align 8
  %v4690 = load i64, ptr %slot841, align 8
  %op4691 = and i64 %v4690, 5764607523034234881
  store i64 %op4691, ptr %slot842, align 8
  %v4692 = load i64, ptr %slot842, align 8
  %cmp4693 = icmp ne i64 %v4692, 0
  %cv4694 = zext i1 %cmp4693 to i32
  store i32 %cv4694, ptr %slot843, align 8
  %v4695 = load i32, ptr %slot843, align 8
  %cv4696 = zext i32 %v4695 to i64
  %cond4697 = icmp ne i64 %cv4696, 0
  br i1 %cond4697, label %bb_rcmoveslow1043, label %bb_rcmovenext1054
bb_rcmovenext1054:
  %v4698 = load i64, ptr %slot827, align 8
  %op4699 = add i64 %v4698, 16
  store i64 %op4699, ptr %slot844, align 8
  %v4700 = load i64, ptr %slot844, align 8
  %p4701 = inttoptr i64 %v4700 to ptr
  %ld4702 = load i64, ptr %p4701, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4702, ptr %slot845, align 8
  %v4703 = load i64, ptr %slot845, align 8
  %cmp4704 = icmp ne i64 %v4703, 0
  %cv4705 = zext i1 %cmp4704 to i32
  store i32 %cv4705, ptr %slot846, align 8
  %v4706 = load i32, ptr %slot846, align 8
  %cv4707 = zext i32 %v4706 to i64
  %cond4708 = icmp ne i64 %cv4707, 0
  br i1 %cond4708, label %bb_rcmoveheader1062, label %bb_rcmovenext1062
bb_rcmoveheader1062:
  %v4709 = load i64, ptr %slot845, align 8
  %op4710 = sub i64 %v4709, 16
  store i64 %op4710, ptr %slot847, align 8
  %v4711 = load i64, ptr %slot845, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  %rgep4713 = getelementptr i8, ptr %p4712, i64 -16
  %ld4714 = load i64, ptr %rgep4713, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4714, ptr %slot848, align 8
  %v4715 = load i64, ptr %slot848, align 8
  %op4716 = and i64 %v4715, 5764607523034234881
  store i64 %op4716, ptr %slot849, align 8
  %v4717 = load i64, ptr %slot849, align 8
  %cmp4718 = icmp ne i64 %v4717, 0
  %cv4719 = zext i1 %cmp4718 to i32
  store i32 %cv4719, ptr %slot850, align 8
  %v4720 = load i32, ptr %slot850, align 8
  %cv4721 = zext i32 %v4720 to i64
  %cond4722 = icmp ne i64 %cv4721, 0
  br i1 %cond4722, label %bb_rcmoveslow1043, label %bb_rcmovenext1062
bb_rcmovenext1062:
  %v4723 = load i64, ptr %slot827, align 8
  %op4724 = add i64 %v4723, 24
  store i64 %op4724, ptr %slot851, align 8
  %v4725 = load i64, ptr %slot851, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  %ld4727 = load i64, ptr %p4726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4727, ptr %slot852, align 8
  %v4728 = load i64, ptr %slot852, align 8
  %cmp4729 = icmp ne i64 %v4728, 0
  %cv4730 = zext i1 %cmp4729 to i32
  store i32 %cv4730, ptr %slot853, align 8
  %v4731 = load i32, ptr %slot853, align 8
  %cv4732 = zext i32 %v4731 to i64
  %cond4733 = icmp ne i64 %cv4732, 0
  br i1 %cond4733, label %bb_rcmoveheader1070, label %bb_rcmovenext1070
bb_rcmoveheader1070:
  %v4734 = load i64, ptr %slot852, align 8
  %op4735 = sub i64 %v4734, 16
  store i64 %op4735, ptr %slot854, align 8
  %v4736 = load i64, ptr %slot852, align 8
  %p4737 = inttoptr i64 %v4736 to ptr
  %rgep4738 = getelementptr i8, ptr %p4737, i64 -16
  %ld4739 = load i64, ptr %rgep4738, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4739, ptr %slot855, align 8
  %v4740 = load i64, ptr %slot855, align 8
  %op4741 = and i64 %v4740, 5764607523034234881
  store i64 %op4741, ptr %slot856, align 8
  %v4742 = load i64, ptr %slot856, align 8
  %cmp4743 = icmp ne i64 %v4742, 0
  %cv4744 = zext i1 %cmp4743 to i32
  store i32 %cv4744, ptr %slot857, align 8
  %v4745 = load i32, ptr %slot857, align 8
  %cv4746 = zext i32 %v4745 to i64
  %cond4747 = icmp ne i64 %cv4746, 0
  br i1 %cond4747, label %bb_rcmoveslow1043, label %bb_rcmovenext1070
bb_rcmovenext1070:
  %v4748 = load i64, ptr %slot827, align 8
  %v4749 = load i64, ptr %slot828, align 8
  %p4750 = inttoptr i64 %v4748 to ptr
  %p4751 = inttoptr i64 %v4749 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4751, ptr %p4750, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v4752 = load i64, ptr %slot827, align 8
  %p4753 = inttoptr i64 %v4752 to ptr
  store i64 0, ptr %p4753, align 8, !alias.scope !3, !noalias !4
  %v4754 = load i64, ptr %slot827, align 8
  %op4755 = add i64 %v4754, 8
  store i64 %op4755, ptr %slot858, align 8
  %v4756 = load i64, ptr %slot858, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  store i64 0, ptr %p4757, align 8, !alias.scope !3, !noalias !4
  %v4758 = load i64, ptr %slot827, align 8
  %op4759 = add i64 %v4758, 16
  store i64 %op4759, ptr %slot859, align 8
  %v4760 = load i64, ptr %slot859, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  store i64 0, ptr %p4761, align 8, !alias.scope !3, !noalias !4
  %v4762 = load i64, ptr %slot827, align 8
  %op4763 = add i64 %v4762, 24
  store i64 %op4763, ptr %slot860, align 8
  %v4764 = load i64, ptr %slot860, align 8
  %p4765 = inttoptr i64 %v4764 to ptr
  store i64 0, ptr %p4765, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1043
bb_rcmoveslow1043:
  %v4766 = load i64, ptr %slot41, align 8
  %v4767 = load i64, ptr %slot828, align 8
  %v4768 = load i64, ptr %slot827, align 8
  %v4769 = load i64, ptr %slot829, align 8
  %cv4770 = trunc i64 %v4769 to i32
  %call4771 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_take(i64 %v4766, i64 %v4767, i64 %v4768, i32 %cv4770) nomerge, !dbg !130
  store i32 %call4771, ptr %slot861, align 8
  %v4772 = load i32, ptr %slot861, align 8
  %cv4773 = zext i32 %v4772 to i64
  %cond4774 = icmp ne i64 %cv4773, 0
  br i1 %cond4774, label %bb_rcsuccess1080, label %bb_rcfailure1080
bb_rcfailure1080:
  %v4775 = load i64, ptr %slot41, align 8
  %p4776 = inttoptr i64 %v4775 to ptr
  %call4777 = call i32 @myl_rc_take_failure(ptr %p4776) nomerge, !dbg !130
  store i32 %call4777, ptr %slot862, align 8
  %v4778 = load i64, ptr %slot1, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  %v4780 = load i32, ptr %slot862, align 8
  %call4781 = call i32 @myl_qbe_rc_status(ptr %p4779, i32 %v4780) nomerge, !dbg !130
  store i32 %call4781, ptr %slot863, align 8
  br label %bb_failure
bb_rcsuccess1080:
  br label %bb_rcmoved1043
bb_rcmoved1043:
  %v4782 = load i64, ptr %slot12, align 8
  %p4783 = inttoptr i64 %v4782 to ptr
  store i32 0, ptr %p4783, align 4, !alias.scope !3, !noalias !4
  %v4784 = load i64, ptr %slot21, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  store i32 2, ptr %p4785, align 4, !alias.scope !3, !noalias !4
  %v4786 = load i64, ptr %slot20, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  store i32 1, ptr %p4787, align 4, !alias.scope !3, !noalias !4
  %v4788 = load i64, ptr %slot31, align 8
  store i64 %v4788, ptr %slot864, align 8
  %v4789 = load i64, ptr %slot20, align 8
  %p4790 = inttoptr i64 %v4789 to ptr
  store i32 0, ptr %p4790, align 4, !alias.scope !3, !noalias !4
  %v4791 = load i64, ptr %slot12, align 8
  %p4792 = inttoptr i64 %v4791 to ptr
  %ld4793 = load i32, ptr %p4792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4793, ptr %slot865, align 8
  %v4794 = load i32, ptr %slot865, align 8
  %cv4795 = zext i32 %v4794 to i64
  %cond4796 = icmp ne i64 %cv4795, 0
  br i1 %cond4796, label %bb_rcslotdrop1090, label %bb_rcslotdone1090
bb_rcslotdrop1090:
  %v4797 = load i64, ptr %slot12, align 8
  %p4798 = inttoptr i64 %v4797 to ptr
  store i32 0, ptr %p4798, align 4, !alias.scope !3, !noalias !4
  %v4799 = load i64, ptr %slot23, align 8
  store i64 %v4799, ptr %slot866, align 8
  %v4800 = load i64, ptr %slot13, align 8
  %p4801 = inttoptr i64 %v4800 to ptr
  %ld4802 = load i32, ptr %p4801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4802, ptr %slot867, align 8
  %v4803 = load i32, ptr %slot867, align 8
  %op4804 = and i32 %v4803, 28
  store i32 %op4804, ptr %slot868, align 8
  %v4805 = load i32, ptr %slot868, align 8
  %cv4806 = zext i32 %v4805 to i64
  %cond4807 = icmp ne i64 %cv4806, 0
  br i1 %cond4807, label %bb_rcslotrole1090, label %bb_rcslotowner1090
bb_rcslotrole1090:
  %v4808 = load i64, ptr %slot41, align 8
  store i64 %v4808, ptr %slot869, align 8
  %v4809 = load i64, ptr %slot869, align 8
  %v4810 = load i64, ptr %slot866, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v4809, i64 %v4810) nomerge, !dbg !130
  br label %bb_rcslotdone1090
bb_rcslotowner1090:
  %v4811 = load i64, ptr %slot41, align 8
  store i64 %v4811, ptr %slot870, align 8
  %v4812 = load i64, ptr %slot870, align 8
  %v4813 = load i64, ptr %slot866, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v4812, i64 %v4813) nomerge, !dbg !130
  br label %bb_rcslotdone1090
bb_rcslotdone1090:
  %v4814 = load i64, ptr %slot10, align 8
  %p4815 = inttoptr i64 %v4814 to ptr
  %ld4816 = load i32, ptr %p4815, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4816, ptr %slot871, align 8
  %v4817 = load i32, ptr %slot871, align 8
  %cv4818 = zext i32 %v4817 to i64
  %cond4819 = icmp ne i64 %cv4818, 0
  br i1 %cond4819, label %bb_rcslotdrop1099, label %bb_rcslotdone1099
bb_rcslotdrop1099:
  %v4820 = load i64, ptr %slot10, align 8
  %p4821 = inttoptr i64 %v4820 to ptr
  store i32 0, ptr %p4821, align 4, !alias.scope !3, !noalias !4
  %v4822 = load i64, ptr %slot35, align 8
  store i64 %v4822, ptr %slot872, align 8
  %v4823 = load i64, ptr %slot11, align 8
  %p4824 = inttoptr i64 %v4823 to ptr
  %ld4825 = load i32, ptr %p4824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4825, ptr %slot873, align 8
  %v4826 = load i32, ptr %slot873, align 8
  %op4827 = and i32 %v4826, 28
  store i32 %op4827, ptr %slot874, align 8
  %v4828 = load i32, ptr %slot874, align 8
  %cv4829 = zext i32 %v4828 to i64
  %cond4830 = icmp ne i64 %cv4829, 0
  br i1 %cond4830, label %bb_rcslotrole1099, label %bb_rcslotowner1099
bb_rcslotrole1099:
  %v4831 = load i64, ptr %slot41, align 8
  store i64 %v4831, ptr %slot875, align 8
  %v4832 = load i64, ptr %slot872, align 8
  %p4833 = inttoptr i64 %v4832 to ptr
  %ld4834 = load i64, ptr %p4833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4834, ptr %slot876, align 8
  %v4835 = load i64, ptr %slot876, align 8
  %cmp4836 = icmp ne i64 %v4835, 0
  %cv4837 = zext i1 %cmp4836 to i32
  store i32 %cv4837, ptr %slot877, align 8
  %v4838 = load i32, ptr %slot877, align 8
  %cv4839 = zext i32 %v4838 to i64
  %cond4840 = icmp ne i64 %cv4839, 0
  br i1 %cond4840, label %bb_rcgnn1115, label %bb_rcgdone1115
bb_rcgnn1115:
  %v4841 = load i64, ptr %slot876, align 8
  %op4842 = sub i64 %v4841, 16
  store i64 %op4842, ptr %slot878, align 8
  %v4843 = load i64, ptr %slot876, align 8
  %p4844 = inttoptr i64 %v4843 to ptr
  %rgep4845 = getelementptr i8, ptr %p4844, i64 -16
  %ld4846 = load i64, ptr %rgep4845, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4846, ptr %slot879, align 8
  %v4847 = load i64, ptr %slot879, align 8
  %op4848 = and i64 %v4847, 4611686018427387906
  store i64 %op4848, ptr %slot880, align 8
  %v4849 = load i64, ptr %slot880, align 8
  %cmp4850 = icmp ne i64 %v4849, 0
  %cv4851 = zext i1 %cmp4850 to i32
  store i32 %cv4851, ptr %slot881, align 8
  %v4852 = load i32, ptr %slot881, align 8
  %cv4853 = zext i32 %v4852 to i64
  %cond4854 = icmp ne i64 %cv4853, 0
  br i1 %cond4854, label %bb_rcgclear1115, label %bb_rcgcounted1115
bb_rcgcounted1115:
  %v4855 = load i64, ptr %slot876, align 8
  %op4856 = sub i64 %v4855, 24
  store i64 %op4856, ptr %slot882, align 8
  %v4857 = load i64, ptr %slot876, align 8
  %p4858 = inttoptr i64 %v4857 to ptr
  %rgep4859 = getelementptr i8, ptr %p4858, i64 -24
  %ld4860 = load i64, ptr %rgep4859, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4860, ptr %slot883, align 8
  %v4861 = load i64, ptr %slot883, align 8
  %op4862 = sub i64 %v4861, 1
  store i64 %op4862, ptr %slot884, align 8
  %v4863 = load i64, ptr %slot884, align 8
  %cmp4864 = icmp eq i64 %v4863, 0
  %cv4865 = zext i1 %cmp4864 to i32
  store i32 %cv4865, ptr %slot885, align 8
  %v4866 = load i32, ptr %slot885, align 8
  %cv4867 = zext i32 %v4866 to i64
  %cond4868 = icmp ne i64 %cv4867, 0
  br i1 %cond4868, label %bb_rcglast1115, label %bb_rcgdec1115
bb_rcglast1115:
  %v4869 = load i64, ptr %slot876, align 8
  %op4870 = sub i64 %v4869, 32
  store i64 %op4870, ptr %slot886, align 8
  %v4871 = load i64, ptr %slot876, align 8
  %p4872 = inttoptr i64 %v4871 to ptr
  %rgep4873 = getelementptr i8, ptr %p4872, i64 -32
  %ld4874 = load i64, ptr %rgep4873, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4874, ptr %slot887, align 8
  %v4875 = load i64, ptr %slot887, align 8
  %cmp4876 = icmp ne i64 %v4875, 0
  %cv4877 = zext i1 %cmp4876 to i32
  store i32 %cv4877, ptr %slot888, align 8
  %v4878 = load i32, ptr %slot888, align 8
  %cv4879 = zext i32 %v4878 to i64
  %cond4880 = icmp ne i64 %cv4879, 0
  br i1 %cond4880, label %bb_rcgdec1115, label %bb_rcgslow1115
bb_rcgslow1115:
  %v4881 = load i64, ptr %slot875, align 8
  %v4882 = load i64, ptr %slot872, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4881, i64 %v4882) nomerge, !dbg !130
  br label %bb_rcgdone1115
bb_rcgdec1115:
  %v4883 = load i64, ptr %slot884, align 8
  %v4884 = load i64, ptr %slot876, align 8
  %p4885 = inttoptr i64 %v4884 to ptr
  %rgep4886 = getelementptr i8, ptr %p4885, i64 -24
  store i64 %v4883, ptr %rgep4886, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1115
bb_rcgclear1115:
  %v4887 = load i64, ptr %slot872, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  store i64 0, ptr %p4888, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1115
bb_rcgdone1115:
  br label %bb_rcslotdone1099
bb_rcslotowner1099:
  %v4889 = load i64, ptr %slot41, align 8
  store i64 %v4889, ptr %slot889, align 8
  %v4890 = load i64, ptr %slot872, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  %ld4892 = load i64, ptr %p4891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4892, ptr %slot890, align 8
  %v4893 = load i64, ptr %slot890, align 8
  %cmp4894 = icmp ne i64 %v4893, 0
  %cv4895 = zext i1 %cmp4894 to i32
  store i32 %cv4895, ptr %slot891, align 8
  %v4896 = load i32, ptr %slot891, align 8
  %cv4897 = zext i32 %v4896 to i64
  %cond4898 = icmp ne i64 %cv4897, 0
  br i1 %cond4898, label %bb_rcgnn1130, label %bb_rcgdone1130
bb_rcgnn1130:
  %v4899 = load i64, ptr %slot890, align 8
  %op4900 = sub i64 %v4899, 16
  store i64 %op4900, ptr %slot892, align 8
  %v4901 = load i64, ptr %slot890, align 8
  %p4902 = inttoptr i64 %v4901 to ptr
  %rgep4903 = getelementptr i8, ptr %p4902, i64 -16
  %ld4904 = load i64, ptr %rgep4903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4904, ptr %slot893, align 8
  %v4905 = load i64, ptr %slot893, align 8
  %op4906 = and i64 %v4905, 4611686018427387906
  store i64 %op4906, ptr %slot894, align 8
  %v4907 = load i64, ptr %slot894, align 8
  %cmp4908 = icmp ne i64 %v4907, 0
  %cv4909 = zext i1 %cmp4908 to i32
  store i32 %cv4909, ptr %slot895, align 8
  %v4910 = load i32, ptr %slot895, align 8
  %cv4911 = zext i32 %v4910 to i64
  %cond4912 = icmp ne i64 %cv4911, 0
  br i1 %cond4912, label %bb_rcgclear1130, label %bb_rcgcounted1130
bb_rcgcounted1130:
  %v4913 = load i64, ptr %slot890, align 8
  %op4914 = sub i64 %v4913, 32
  store i64 %op4914, ptr %slot896, align 8
  %v4915 = load i64, ptr %slot890, align 8
  %p4916 = inttoptr i64 %v4915 to ptr
  %rgep4917 = getelementptr i8, ptr %p4916, i64 -32
  %ld4918 = load i64, ptr %rgep4917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4918, ptr %slot897, align 8
  %v4919 = load i64, ptr %slot897, align 8
  %op4920 = sub i64 %v4919, 1
  store i64 %op4920, ptr %slot898, align 8
  %v4921 = load i64, ptr %slot898, align 8
  %cmp4922 = icmp eq i64 %v4921, 0
  %cv4923 = zext i1 %cmp4922 to i32
  store i32 %cv4923, ptr %slot899, align 8
  %v4924 = load i32, ptr %slot899, align 8
  %cv4925 = zext i32 %v4924 to i64
  %cond4926 = icmp ne i64 %cv4925, 0
  br i1 %cond4926, label %bb_rcglast1130, label %bb_rcgdec1130
bb_rcglast1130:
  %v4927 = load i64, ptr %slot890, align 8
  %op4928 = sub i64 %v4927, 24
  store i64 %op4928, ptr %slot900, align 8
  %v4929 = load i64, ptr %slot890, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  %rgep4931 = getelementptr i8, ptr %p4930, i64 -24
  %ld4932 = load i64, ptr %rgep4931, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4932, ptr %slot901, align 8
  %v4933 = load i64, ptr %slot901, align 8
  %cmp4934 = icmp ne i64 %v4933, 0
  %cv4935 = zext i1 %cmp4934 to i32
  store i32 %cv4935, ptr %slot902, align 8
  %v4936 = load i32, ptr %slot902, align 8
  %cv4937 = zext i32 %v4936 to i64
  %cond4938 = icmp ne i64 %cv4937, 0
  br i1 %cond4938, label %bb_rcgdec1130, label %bb_rcgslow1130
bb_rcgslow1130:
  %v4939 = load i64, ptr %slot889, align 8
  %v4940 = load i64, ptr %slot872, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4939, i64 %v4940) nomerge, !dbg !130
  br label %bb_rcgdone1130
bb_rcgdec1130:
  %v4941 = load i64, ptr %slot898, align 8
  %v4942 = load i64, ptr %slot890, align 8
  %p4943 = inttoptr i64 %v4942 to ptr
  %rgep4944 = getelementptr i8, ptr %p4943, i64 -32
  store i64 %v4941, ptr %rgep4944, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1130
bb_rcgclear1130:
  %v4945 = load i64, ptr %slot872, align 8
  %p4946 = inttoptr i64 %v4945 to ptr
  store i64 0, ptr %p4946, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1130
bb_rcgdone1130:
  br label %bb_rcslotdone1099
bb_rcslotdone1099:
  %v4947 = load i64, ptr %slot8, align 8
  %p4948 = inttoptr i64 %v4947 to ptr
  %ld4949 = load i32, ptr %p4948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4949, ptr %slot903, align 8
  %v4950 = load i32, ptr %slot903, align 8
  %cv4951 = zext i32 %v4950 to i64
  %cond4952 = icmp ne i64 %cv4951, 0
  br i1 %cond4952, label %bb_rcslotdrop1136, label %bb_rcslotdone1136
bb_rcslotdrop1136:
  %v4953 = load i64, ptr %slot8, align 8
  %p4954 = inttoptr i64 %v4953 to ptr
  store i32 0, ptr %p4954, align 4, !alias.scope !3, !noalias !4
  %v4955 = load i64, ptr %slot34, align 8
  store i64 %v4955, ptr %slot904, align 8
  %v4956 = load i64, ptr %slot9, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  %ld4958 = load i32, ptr %p4957, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4958, ptr %slot905, align 8
  %v4959 = load i32, ptr %slot905, align 8
  %op4960 = and i32 %v4959, 28
  store i32 %op4960, ptr %slot906, align 8
  %v4961 = load i32, ptr %slot906, align 8
  %cv4962 = zext i32 %v4961 to i64
  %cond4963 = icmp ne i64 %cv4962, 0
  br i1 %cond4963, label %bb_rcslotrole1136, label %bb_rcslotowner1136
bb_rcslotrole1136:
  %v4964 = load i64, ptr %slot41, align 8
  store i64 %v4964, ptr %slot907, align 8
  %v4965 = load i64, ptr %slot904, align 8
  %p4966 = inttoptr i64 %v4965 to ptr
  %ld4967 = load i64, ptr %p4966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4967, ptr %slot908, align 8
  %v4968 = load i64, ptr %slot908, align 8
  %cmp4969 = icmp ne i64 %v4968, 0
  %cv4970 = zext i1 %cmp4969 to i32
  store i32 %cv4970, ptr %slot909, align 8
  %v4971 = load i32, ptr %slot909, align 8
  %cv4972 = zext i32 %v4971 to i64
  %cond4973 = icmp ne i64 %cv4972, 0
  br i1 %cond4973, label %bb_rcgnn1152, label %bb_rcgdone1152
bb_rcgnn1152:
  %v4974 = load i64, ptr %slot908, align 8
  %op4975 = sub i64 %v4974, 16
  store i64 %op4975, ptr %slot910, align 8
  %v4976 = load i64, ptr %slot908, align 8
  %p4977 = inttoptr i64 %v4976 to ptr
  %rgep4978 = getelementptr i8, ptr %p4977, i64 -16
  %ld4979 = load i64, ptr %rgep4978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4979, ptr %slot911, align 8
  %v4980 = load i64, ptr %slot911, align 8
  %op4981 = and i64 %v4980, 4611686018427387906
  store i64 %op4981, ptr %slot912, align 8
  %v4982 = load i64, ptr %slot912, align 8
  %cmp4983 = icmp ne i64 %v4982, 0
  %cv4984 = zext i1 %cmp4983 to i32
  store i32 %cv4984, ptr %slot913, align 8
  %v4985 = load i32, ptr %slot913, align 8
  %cv4986 = zext i32 %v4985 to i64
  %cond4987 = icmp ne i64 %cv4986, 0
  br i1 %cond4987, label %bb_rcgclear1152, label %bb_rcgcounted1152
bb_rcgcounted1152:
  %v4988 = load i64, ptr %slot908, align 8
  %op4989 = sub i64 %v4988, 24
  store i64 %op4989, ptr %slot914, align 8
  %v4990 = load i64, ptr %slot908, align 8
  %p4991 = inttoptr i64 %v4990 to ptr
  %rgep4992 = getelementptr i8, ptr %p4991, i64 -24
  %ld4993 = load i64, ptr %rgep4992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4993, ptr %slot915, align 8
  %v4994 = load i64, ptr %slot915, align 8
  %op4995 = sub i64 %v4994, 1
  store i64 %op4995, ptr %slot916, align 8
  %v4996 = load i64, ptr %slot916, align 8
  %cmp4997 = icmp eq i64 %v4996, 0
  %cv4998 = zext i1 %cmp4997 to i32
  store i32 %cv4998, ptr %slot917, align 8
  %v4999 = load i32, ptr %slot917, align 8
  %cv5000 = zext i32 %v4999 to i64
  %cond5001 = icmp ne i64 %cv5000, 0
  br i1 %cond5001, label %bb_rcglast1152, label %bb_rcgdec1152
bb_rcglast1152:
  %v5002 = load i64, ptr %slot908, align 8
  %op5003 = sub i64 %v5002, 32
  store i64 %op5003, ptr %slot918, align 8
  %v5004 = load i64, ptr %slot908, align 8
  %p5005 = inttoptr i64 %v5004 to ptr
  %rgep5006 = getelementptr i8, ptr %p5005, i64 -32
  %ld5007 = load i64, ptr %rgep5006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5007, ptr %slot919, align 8
  %v5008 = load i64, ptr %slot919, align 8
  %cmp5009 = icmp ne i64 %v5008, 0
  %cv5010 = zext i1 %cmp5009 to i32
  store i32 %cv5010, ptr %slot920, align 8
  %v5011 = load i32, ptr %slot920, align 8
  %cv5012 = zext i32 %v5011 to i64
  %cond5013 = icmp ne i64 %cv5012, 0
  br i1 %cond5013, label %bb_rcgdec1152, label %bb_rcgslow1152
bb_rcgslow1152:
  %v5014 = load i64, ptr %slot907, align 8
  %v5015 = load i64, ptr %slot904, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_unloan(i64 %v5014, i64 %v5015) nomerge, !dbg !130
  br label %bb_rcgdone1152
bb_rcgdec1152:
  %v5016 = load i64, ptr %slot916, align 8
  %v5017 = load i64, ptr %slot908, align 8
  %p5018 = inttoptr i64 %v5017 to ptr
  %rgep5019 = getelementptr i8, ptr %p5018, i64 -24
  store i64 %v5016, ptr %rgep5019, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1152
bb_rcgclear1152:
  %v5020 = load i64, ptr %slot904, align 8
  %p5021 = inttoptr i64 %v5020 to ptr
  store i64 0, ptr %p5021, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1152
bb_rcgdone1152:
  br label %bb_rcslotdone1136
bb_rcslotowner1136:
  %v5022 = load i64, ptr %slot41, align 8
  store i64 %v5022, ptr %slot921, align 8
  %v5023 = load i64, ptr %slot904, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  %ld5025 = load i64, ptr %p5024, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5025, ptr %slot922, align 8
  %v5026 = load i64, ptr %slot922, align 8
  %cmp5027 = icmp ne i64 %v5026, 0
  %cv5028 = zext i1 %cmp5027 to i32
  store i32 %cv5028, ptr %slot923, align 8
  %v5029 = load i32, ptr %slot923, align 8
  %cv5030 = zext i32 %v5029 to i64
  %cond5031 = icmp ne i64 %cv5030, 0
  br i1 %cond5031, label %bb_rcgnn1167, label %bb_rcgdone1167
bb_rcgnn1167:
  %v5032 = load i64, ptr %slot922, align 8
  %op5033 = sub i64 %v5032, 16
  store i64 %op5033, ptr %slot924, align 8
  %v5034 = load i64, ptr %slot922, align 8
  %p5035 = inttoptr i64 %v5034 to ptr
  %rgep5036 = getelementptr i8, ptr %p5035, i64 -16
  %ld5037 = load i64, ptr %rgep5036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5037, ptr %slot925, align 8
  %v5038 = load i64, ptr %slot925, align 8
  %op5039 = and i64 %v5038, 4611686018427387906
  store i64 %op5039, ptr %slot926, align 8
  %v5040 = load i64, ptr %slot926, align 8
  %cmp5041 = icmp ne i64 %v5040, 0
  %cv5042 = zext i1 %cmp5041 to i32
  store i32 %cv5042, ptr %slot927, align 8
  %v5043 = load i32, ptr %slot927, align 8
  %cv5044 = zext i32 %v5043 to i64
  %cond5045 = icmp ne i64 %cv5044, 0
  br i1 %cond5045, label %bb_rcgclear1167, label %bb_rcgcounted1167
bb_rcgcounted1167:
  %v5046 = load i64, ptr %slot922, align 8
  %op5047 = sub i64 %v5046, 32
  store i64 %op5047, ptr %slot928, align 8
  %v5048 = load i64, ptr %slot922, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  %rgep5050 = getelementptr i8, ptr %p5049, i64 -32
  %ld5051 = load i64, ptr %rgep5050, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5051, ptr %slot929, align 8
  %v5052 = load i64, ptr %slot929, align 8
  %op5053 = sub i64 %v5052, 1
  store i64 %op5053, ptr %slot930, align 8
  %v5054 = load i64, ptr %slot930, align 8
  %cmp5055 = icmp eq i64 %v5054, 0
  %cv5056 = zext i1 %cmp5055 to i32
  store i32 %cv5056, ptr %slot931, align 8
  %v5057 = load i32, ptr %slot931, align 8
  %cv5058 = zext i32 %v5057 to i64
  %cond5059 = icmp ne i64 %cv5058, 0
  br i1 %cond5059, label %bb_rcglast1167, label %bb_rcgdec1167
bb_rcglast1167:
  %v5060 = load i64, ptr %slot922, align 8
  %op5061 = sub i64 %v5060, 24
  store i64 %op5061, ptr %slot932, align 8
  %v5062 = load i64, ptr %slot922, align 8
  %p5063 = inttoptr i64 %v5062 to ptr
  %rgep5064 = getelementptr i8, ptr %p5063, i64 -24
  %ld5065 = load i64, ptr %rgep5064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5065, ptr %slot933, align 8
  %v5066 = load i64, ptr %slot933, align 8
  %cmp5067 = icmp ne i64 %v5066, 0
  %cv5068 = zext i1 %cmp5067 to i32
  store i32 %cv5068, ptr %slot934, align 8
  %v5069 = load i32, ptr %slot934, align 8
  %cv5070 = zext i32 %v5069 to i64
  %cond5071 = icmp ne i64 %cv5070, 0
  br i1 %cond5071, label %bb_rcgdec1167, label %bb_rcgslow1167
bb_rcgslow1167:
  %v5072 = load i64, ptr %slot921, align 8
  %v5073 = load i64, ptr %slot904, align 8
  call void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64 %v5072, i64 %v5073) nomerge, !dbg !130
  br label %bb_rcgdone1167
bb_rcgdec1167:
  %v5074 = load i64, ptr %slot930, align 8
  %v5075 = load i64, ptr %slot922, align 8
  %p5076 = inttoptr i64 %v5075 to ptr
  %rgep5077 = getelementptr i8, ptr %p5076, i64 -32
  store i64 %v5074, ptr %rgep5077, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1167
bb_rcgclear1167:
  %v5078 = load i64, ptr %slot904, align 8
  %p5079 = inttoptr i64 %v5078 to ptr
  store i64 0, ptr %p5079, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1167
bb_rcgdone1167:
  br label %bb_rcslotdone1136
bb_rcslotdone1136:
  %v5080 = load i64, ptr %slot6, align 8
  %p5081 = inttoptr i64 %v5080 to ptr
  %ld5082 = load i32, ptr %p5081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5082, ptr %slot935, align 8
  %v5083 = load i32, ptr %slot935, align 8
  %cv5084 = zext i32 %v5083 to i64
  %cond5085 = icmp ne i64 %cv5084, 0
  br i1 %cond5085, label %bb_rcslotdrop1173, label %bb_rcslotdone1173
bb_rcslotdrop1173:
  %v5086 = load i64, ptr %slot6, align 8
  %p5087 = inttoptr i64 %v5086 to ptr
  store i32 0, ptr %p5087, align 4, !alias.scope !3, !noalias !4
  %v5088 = load i64, ptr %slot33, align 8
  store i64 %v5088, ptr %slot936, align 8
  %v5089 = load i64, ptr %slot7, align 8
  %p5090 = inttoptr i64 %v5089 to ptr
  %ld5091 = load i32, ptr %p5090, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5091, ptr %slot937, align 8
  %v5092 = load i32, ptr %slot937, align 8
  %op5093 = and i32 %v5092, 28
  store i32 %op5093, ptr %slot938, align 8
  %v5094 = load i32, ptr %slot938, align 8
  %cv5095 = zext i32 %v5094 to i64
  %cond5096 = icmp ne i64 %cv5095, 0
  br i1 %cond5096, label %bb_rcslotrole1173, label %bb_rcslotowner1173
bb_rcslotrole1173:
  %v5097 = load i64, ptr %slot41, align 8
  store i64 %v5097, ptr %slot939, align 8
  %v5098 = load i64, ptr %slot936, align 8
  %p5099 = inttoptr i64 %v5098 to ptr
  %ld5100 = load i64, ptr %p5099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5100, ptr %slot940, align 8
  %v5101 = load i64, ptr %slot940, align 8
  %cmp5102 = icmp ne i64 %v5101, 0
  %cv5103 = zext i1 %cmp5102 to i32
  store i32 %cv5103, ptr %slot941, align 8
  %v5104 = load i32, ptr %slot941, align 8
  %cv5105 = zext i32 %v5104 to i64
  %cond5106 = icmp ne i64 %cv5105, 0
  br i1 %cond5106, label %bb_rcgnn1189, label %bb_rcgdone1189
bb_rcgnn1189:
  %v5107 = load i64, ptr %slot940, align 8
  %op5108 = sub i64 %v5107, 16
  store i64 %op5108, ptr %slot942, align 8
  %v5109 = load i64, ptr %slot940, align 8
  %p5110 = inttoptr i64 %v5109 to ptr
  %rgep5111 = getelementptr i8, ptr %p5110, i64 -16
  %ld5112 = load i64, ptr %rgep5111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5112, ptr %slot943, align 8
  %v5113 = load i64, ptr %slot943, align 8
  %op5114 = and i64 %v5113, 4611686018427387906
  store i64 %op5114, ptr %slot944, align 8
  %v5115 = load i64, ptr %slot944, align 8
  %cmp5116 = icmp ne i64 %v5115, 0
  %cv5117 = zext i1 %cmp5116 to i32
  store i32 %cv5117, ptr %slot945, align 8
  %v5118 = load i32, ptr %slot945, align 8
  %cv5119 = zext i32 %v5118 to i64
  %cond5120 = icmp ne i64 %cv5119, 0
  br i1 %cond5120, label %bb_rcgclear1189, label %bb_rcgcounted1189
bb_rcgcounted1189:
  %v5121 = load i64, ptr %slot940, align 8
  %op5122 = sub i64 %v5121, 24
  store i64 %op5122, ptr %slot946, align 8
  %v5123 = load i64, ptr %slot940, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  %rgep5125 = getelementptr i8, ptr %p5124, i64 -24
  %ld5126 = load i64, ptr %rgep5125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5126, ptr %slot947, align 8
  %v5127 = load i64, ptr %slot947, align 8
  %op5128 = sub i64 %v5127, 1
  store i64 %op5128, ptr %slot948, align 8
  %v5129 = load i64, ptr %slot948, align 8
  %cmp5130 = icmp eq i64 %v5129, 0
  %cv5131 = zext i1 %cmp5130 to i32
  store i32 %cv5131, ptr %slot949, align 8
  %v5132 = load i32, ptr %slot949, align 8
  %cv5133 = zext i32 %v5132 to i64
  %cond5134 = icmp ne i64 %cv5133, 0
  br i1 %cond5134, label %bb_rcglast1189, label %bb_rcgdec1189
bb_rcglast1189:
  %v5135 = load i64, ptr %slot940, align 8
  %op5136 = sub i64 %v5135, 32
  store i64 %op5136, ptr %slot950, align 8
  %v5137 = load i64, ptr %slot940, align 8
  %p5138 = inttoptr i64 %v5137 to ptr
  %rgep5139 = getelementptr i8, ptr %p5138, i64 -32
  %ld5140 = load i64, ptr %rgep5139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5140, ptr %slot951, align 8
  %v5141 = load i64, ptr %slot951, align 8
  %cmp5142 = icmp ne i64 %v5141, 0
  %cv5143 = zext i1 %cmp5142 to i32
  store i32 %cv5143, ptr %slot952, align 8
  %v5144 = load i32, ptr %slot952, align 8
  %cv5145 = zext i32 %v5144 to i64
  %cond5146 = icmp ne i64 %cv5145, 0
  br i1 %cond5146, label %bb_rcgdec1189, label %bb_rcgslow1189
bb_rcgslow1189:
  %v5147 = load i64, ptr %slot939, align 8
  %v5148 = load i64, ptr %slot936, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_unloan(i64 %v5147, i64 %v5148) nomerge, !dbg !130
  br label %bb_rcgdone1189
bb_rcgdec1189:
  %v5149 = load i64, ptr %slot948, align 8
  %v5150 = load i64, ptr %slot940, align 8
  %p5151 = inttoptr i64 %v5150 to ptr
  %rgep5152 = getelementptr i8, ptr %p5151, i64 -24
  store i64 %v5149, ptr %rgep5152, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1189
bb_rcgclear1189:
  %v5153 = load i64, ptr %slot936, align 8
  %p5154 = inttoptr i64 %v5153 to ptr
  store i64 0, ptr %p5154, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1189
bb_rcgdone1189:
  br label %bb_rcslotdone1173
bb_rcslotowner1173:
  %v5155 = load i64, ptr %slot41, align 8
  store i64 %v5155, ptr %slot953, align 8
  %v5156 = load i64, ptr %slot936, align 8
  %p5157 = inttoptr i64 %v5156 to ptr
  %ld5158 = load i64, ptr %p5157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5158, ptr %slot954, align 8
  %v5159 = load i64, ptr %slot954, align 8
  %cmp5160 = icmp ne i64 %v5159, 0
  %cv5161 = zext i1 %cmp5160 to i32
  store i32 %cv5161, ptr %slot955, align 8
  %v5162 = load i32, ptr %slot955, align 8
  %cv5163 = zext i32 %v5162 to i64
  %cond5164 = icmp ne i64 %cv5163, 0
  br i1 %cond5164, label %bb_rcgnn1204, label %bb_rcgdone1204
bb_rcgnn1204:
  %v5165 = load i64, ptr %slot954, align 8
  %op5166 = sub i64 %v5165, 16
  store i64 %op5166, ptr %slot956, align 8
  %v5167 = load i64, ptr %slot954, align 8
  %p5168 = inttoptr i64 %v5167 to ptr
  %rgep5169 = getelementptr i8, ptr %p5168, i64 -16
  %ld5170 = load i64, ptr %rgep5169, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5170, ptr %slot957, align 8
  %v5171 = load i64, ptr %slot957, align 8
  %op5172 = and i64 %v5171, 4611686018427387906
  store i64 %op5172, ptr %slot958, align 8
  %v5173 = load i64, ptr %slot958, align 8
  %cmp5174 = icmp ne i64 %v5173, 0
  %cv5175 = zext i1 %cmp5174 to i32
  store i32 %cv5175, ptr %slot959, align 8
  %v5176 = load i32, ptr %slot959, align 8
  %cv5177 = zext i32 %v5176 to i64
  %cond5178 = icmp ne i64 %cv5177, 0
  br i1 %cond5178, label %bb_rcgclear1204, label %bb_rcgcounted1204
bb_rcgcounted1204:
  %v5179 = load i64, ptr %slot954, align 8
  %op5180 = sub i64 %v5179, 32
  store i64 %op5180, ptr %slot960, align 8
  %v5181 = load i64, ptr %slot954, align 8
  %p5182 = inttoptr i64 %v5181 to ptr
  %rgep5183 = getelementptr i8, ptr %p5182, i64 -32
  %ld5184 = load i64, ptr %rgep5183, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5184, ptr %slot961, align 8
  %v5185 = load i64, ptr %slot961, align 8
  %op5186 = sub i64 %v5185, 1
  store i64 %op5186, ptr %slot962, align 8
  %v5187 = load i64, ptr %slot962, align 8
  %cmp5188 = icmp eq i64 %v5187, 0
  %cv5189 = zext i1 %cmp5188 to i32
  store i32 %cv5189, ptr %slot963, align 8
  %v5190 = load i32, ptr %slot963, align 8
  %cv5191 = zext i32 %v5190 to i64
  %cond5192 = icmp ne i64 %cv5191, 0
  br i1 %cond5192, label %bb_rcglast1204, label %bb_rcgdec1204
bb_rcglast1204:
  %v5193 = load i64, ptr %slot954, align 8
  %op5194 = sub i64 %v5193, 24
  store i64 %op5194, ptr %slot964, align 8
  %v5195 = load i64, ptr %slot954, align 8
  %p5196 = inttoptr i64 %v5195 to ptr
  %rgep5197 = getelementptr i8, ptr %p5196, i64 -24
  %ld5198 = load i64, ptr %rgep5197, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5198, ptr %slot965, align 8
  %v5199 = load i64, ptr %slot965, align 8
  %cmp5200 = icmp ne i64 %v5199, 0
  %cv5201 = zext i1 %cmp5200 to i32
  store i32 %cv5201, ptr %slot966, align 8
  %v5202 = load i32, ptr %slot966, align 8
  %cv5203 = zext i32 %v5202 to i64
  %cond5204 = icmp ne i64 %cv5203, 0
  br i1 %cond5204, label %bb_rcgdec1204, label %bb_rcgslow1204
bb_rcgslow1204:
  %v5205 = load i64, ptr %slot953, align 8
  %v5206 = load i64, ptr %slot936, align 8
  call void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_drop(i64 %v5205, i64 %v5206) nomerge, !dbg !130
  br label %bb_rcgdone1204
bb_rcgdec1204:
  %v5207 = load i64, ptr %slot962, align 8
  %v5208 = load i64, ptr %slot954, align 8
  %p5209 = inttoptr i64 %v5208 to ptr
  %rgep5210 = getelementptr i8, ptr %p5209, i64 -32
  store i64 %v5207, ptr %rgep5210, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1204
bb_rcgclear1204:
  %v5211 = load i64, ptr %slot936, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  store i64 0, ptr %p5212, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1204
bb_rcgdone1204:
  br label %bb_rcslotdone1173
bb_rcslotdone1173:
  %v5213 = load i64, ptr %slot4, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  %ld5215 = load i32, ptr %p5214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5215, ptr %slot967, align 8
  %v5216 = load i32, ptr %slot967, align 8
  %cv5217 = zext i32 %v5216 to i64
  %cond5218 = icmp ne i64 %cv5217, 0
  br i1 %cond5218, label %bb_rcslotdrop1210, label %bb_rcslotdone1210
bb_rcslotdrop1210:
  %v5219 = load i64, ptr %slot4, align 8
  %p5220 = inttoptr i64 %v5219 to ptr
  store i32 0, ptr %p5220, align 4, !alias.scope !3, !noalias !4
  %v5221 = load i64, ptr %slot32, align 8
  store i64 %v5221, ptr %slot968, align 8
  %v5222 = load i64, ptr %slot5, align 8
  %p5223 = inttoptr i64 %v5222 to ptr
  %ld5224 = load i32, ptr %p5223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5224, ptr %slot969, align 8
  %v5225 = load i32, ptr %slot969, align 8
  %op5226 = and i32 %v5225, 28
  store i32 %op5226, ptr %slot970, align 8
  %v5227 = load i32, ptr %slot970, align 8
  %cv5228 = zext i32 %v5227 to i64
  %cond5229 = icmp ne i64 %cv5228, 0
  br i1 %cond5229, label %bb_rcslotrole1210, label %bb_rcslotowner1210
bb_rcslotrole1210:
  %v5230 = load i64, ptr %slot41, align 8
  store i64 %v5230, ptr %slot971, align 8
  %v5231 = load i64, ptr %slot968, align 8
  %p5232 = inttoptr i64 %v5231 to ptr
  %ld5233 = load i64, ptr %p5232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5233, ptr %slot972, align 8
  %v5234 = load i64, ptr %slot972, align 8
  %cmp5235 = icmp ne i64 %v5234, 0
  %cv5236 = zext i1 %cmp5235 to i32
  store i32 %cv5236, ptr %slot973, align 8
  %v5237 = load i32, ptr %slot973, align 8
  %cv5238 = zext i32 %v5237 to i64
  %cond5239 = icmp ne i64 %cv5238, 0
  br i1 %cond5239, label %bb_rcgnn1226, label %bb_rcgdone1226
bb_rcgnn1226:
  %v5240 = load i64, ptr %slot972, align 8
  %op5241 = sub i64 %v5240, 16
  store i64 %op5241, ptr %slot974, align 8
  %v5242 = load i64, ptr %slot972, align 8
  %p5243 = inttoptr i64 %v5242 to ptr
  %rgep5244 = getelementptr i8, ptr %p5243, i64 -16
  %ld5245 = load i64, ptr %rgep5244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5245, ptr %slot975, align 8
  %v5246 = load i64, ptr %slot975, align 8
  %op5247 = and i64 %v5246, 4611686018427387906
  store i64 %op5247, ptr %slot976, align 8
  %v5248 = load i64, ptr %slot976, align 8
  %cmp5249 = icmp ne i64 %v5248, 0
  %cv5250 = zext i1 %cmp5249 to i32
  store i32 %cv5250, ptr %slot977, align 8
  %v5251 = load i32, ptr %slot977, align 8
  %cv5252 = zext i32 %v5251 to i64
  %cond5253 = icmp ne i64 %cv5252, 0
  br i1 %cond5253, label %bb_rcgclear1226, label %bb_rcgcounted1226
bb_rcgcounted1226:
  %v5254 = load i64, ptr %slot972, align 8
  %op5255 = sub i64 %v5254, 24
  store i64 %op5255, ptr %slot978, align 8
  %v5256 = load i64, ptr %slot972, align 8
  %p5257 = inttoptr i64 %v5256 to ptr
  %rgep5258 = getelementptr i8, ptr %p5257, i64 -24
  %ld5259 = load i64, ptr %rgep5258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5259, ptr %slot979, align 8
  %v5260 = load i64, ptr %slot979, align 8
  %op5261 = sub i64 %v5260, 1
  store i64 %op5261, ptr %slot980, align 8
  %v5262 = load i64, ptr %slot980, align 8
  %cmp5263 = icmp eq i64 %v5262, 0
  %cv5264 = zext i1 %cmp5263 to i32
  store i32 %cv5264, ptr %slot981, align 8
  %v5265 = load i32, ptr %slot981, align 8
  %cv5266 = zext i32 %v5265 to i64
  %cond5267 = icmp ne i64 %cv5266, 0
  br i1 %cond5267, label %bb_rcglast1226, label %bb_rcgdec1226
bb_rcglast1226:
  %v5268 = load i64, ptr %slot972, align 8
  %op5269 = sub i64 %v5268, 32
  store i64 %op5269, ptr %slot982, align 8
  %v5270 = load i64, ptr %slot972, align 8
  %p5271 = inttoptr i64 %v5270 to ptr
  %rgep5272 = getelementptr i8, ptr %p5271, i64 -32
  %ld5273 = load i64, ptr %rgep5272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5273, ptr %slot983, align 8
  %v5274 = load i64, ptr %slot983, align 8
  %cmp5275 = icmp ne i64 %v5274, 0
  %cv5276 = zext i1 %cmp5275 to i32
  store i32 %cv5276, ptr %slot984, align 8
  %v5277 = load i32, ptr %slot984, align 8
  %cv5278 = zext i32 %v5277 to i64
  %cond5279 = icmp ne i64 %cv5278, 0
  br i1 %cond5279, label %bb_rcgdec1226, label %bb_rcgslow1226
bb_rcgslow1226:
  %v5280 = load i64, ptr %slot971, align 8
  %v5281 = load i64, ptr %slot968, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_unloan(i64 %v5280, i64 %v5281) nomerge, !dbg !130
  br label %bb_rcgdone1226
bb_rcgdec1226:
  %v5282 = load i64, ptr %slot980, align 8
  %v5283 = load i64, ptr %slot972, align 8
  %p5284 = inttoptr i64 %v5283 to ptr
  %rgep5285 = getelementptr i8, ptr %p5284, i64 -24
  store i64 %v5282, ptr %rgep5285, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1226
bb_rcgclear1226:
  %v5286 = load i64, ptr %slot968, align 8
  %p5287 = inttoptr i64 %v5286 to ptr
  store i64 0, ptr %p5287, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1226
bb_rcgdone1226:
  br label %bb_rcslotdone1210
bb_rcslotowner1210:
  %v5288 = load i64, ptr %slot41, align 8
  store i64 %v5288, ptr %slot985, align 8
  %v5289 = load i64, ptr %slot968, align 8
  %p5290 = inttoptr i64 %v5289 to ptr
  %ld5291 = load i64, ptr %p5290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5291, ptr %slot986, align 8
  %v5292 = load i64, ptr %slot986, align 8
  %cmp5293 = icmp ne i64 %v5292, 0
  %cv5294 = zext i1 %cmp5293 to i32
  store i32 %cv5294, ptr %slot987, align 8
  %v5295 = load i32, ptr %slot987, align 8
  %cv5296 = zext i32 %v5295 to i64
  %cond5297 = icmp ne i64 %cv5296, 0
  br i1 %cond5297, label %bb_rcgnn1241, label %bb_rcgdone1241
bb_rcgnn1241:
  %v5298 = load i64, ptr %slot986, align 8
  %op5299 = sub i64 %v5298, 16
  store i64 %op5299, ptr %slot988, align 8
  %v5300 = load i64, ptr %slot986, align 8
  %p5301 = inttoptr i64 %v5300 to ptr
  %rgep5302 = getelementptr i8, ptr %p5301, i64 -16
  %ld5303 = load i64, ptr %rgep5302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5303, ptr %slot989, align 8
  %v5304 = load i64, ptr %slot989, align 8
  %op5305 = and i64 %v5304, 4611686018427387906
  store i64 %op5305, ptr %slot990, align 8
  %v5306 = load i64, ptr %slot990, align 8
  %cmp5307 = icmp ne i64 %v5306, 0
  %cv5308 = zext i1 %cmp5307 to i32
  store i32 %cv5308, ptr %slot991, align 8
  %v5309 = load i32, ptr %slot991, align 8
  %cv5310 = zext i32 %v5309 to i64
  %cond5311 = icmp ne i64 %cv5310, 0
  br i1 %cond5311, label %bb_rcgclear1241, label %bb_rcgcounted1241
bb_rcgcounted1241:
  %v5312 = load i64, ptr %slot986, align 8
  %op5313 = sub i64 %v5312, 32
  store i64 %op5313, ptr %slot992, align 8
  %v5314 = load i64, ptr %slot986, align 8
  %p5315 = inttoptr i64 %v5314 to ptr
  %rgep5316 = getelementptr i8, ptr %p5315, i64 -32
  %ld5317 = load i64, ptr %rgep5316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5317, ptr %slot993, align 8
  %v5318 = load i64, ptr %slot993, align 8
  %op5319 = sub i64 %v5318, 1
  store i64 %op5319, ptr %slot994, align 8
  %v5320 = load i64, ptr %slot994, align 8
  %cmp5321 = icmp eq i64 %v5320, 0
  %cv5322 = zext i1 %cmp5321 to i32
  store i32 %cv5322, ptr %slot995, align 8
  %v5323 = load i32, ptr %slot995, align 8
  %cv5324 = zext i32 %v5323 to i64
  %cond5325 = icmp ne i64 %cv5324, 0
  br i1 %cond5325, label %bb_rcglast1241, label %bb_rcgdec1241
bb_rcglast1241:
  %v5326 = load i64, ptr %slot986, align 8
  %op5327 = sub i64 %v5326, 24
  store i64 %op5327, ptr %slot996, align 8
  %v5328 = load i64, ptr %slot986, align 8
  %p5329 = inttoptr i64 %v5328 to ptr
  %rgep5330 = getelementptr i8, ptr %p5329, i64 -24
  %ld5331 = load i64, ptr %rgep5330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5331, ptr %slot997, align 8
  %v5332 = load i64, ptr %slot997, align 8
  %cmp5333 = icmp ne i64 %v5332, 0
  %cv5334 = zext i1 %cmp5333 to i32
  store i32 %cv5334, ptr %slot998, align 8
  %v5335 = load i32, ptr %slot998, align 8
  %cv5336 = zext i32 %v5335 to i64
  %cond5337 = icmp ne i64 %cv5336, 0
  br i1 %cond5337, label %bb_rcgdec1241, label %bb_rcgslow1241
bb_rcgslow1241:
  %v5338 = load i64, ptr %slot985, align 8
  %v5339 = load i64, ptr %slot968, align 8
  call void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64 %v5338, i64 %v5339) nomerge, !dbg !130
  br label %bb_rcgdone1241
bb_rcgdec1241:
  %v5340 = load i64, ptr %slot994, align 8
  %v5341 = load i64, ptr %slot986, align 8
  %p5342 = inttoptr i64 %v5341 to ptr
  %rgep5343 = getelementptr i8, ptr %p5342, i64 -32
  store i64 %v5340, ptr %rgep5343, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1241
bb_rcgclear1241:
  %v5344 = load i64, ptr %slot968, align 8
  %p5345 = inttoptr i64 %v5344 to ptr
  store i64 0, ptr %p5345, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1241
bb_rcgdone1241:
  br label %bb_rcslotdone1210
bb_rcslotdone1210:
  %v5346 = load i64, ptr %slot864, align 8
  %p5347 = inttoptr i64 %v5346 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5347, i64 32, i1 false)
  ret void
bb_failure:
  %v5348 = load i64, ptr %slot3, align 8
  %p5349 = inttoptr i64 %v5348 to ptr
  call void @llvm.memset.p0.i64(ptr %p5349, i8 0, i64 32, i1 false), !alias.scope !3, !noalias !4, !dbg !130
  %v5350 = load i64, ptr %slot3, align 8
  %p5351 = inttoptr i64 %v5350 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5351, i64 32, i1 false)
  ret void
bb_entry_failure:
  %v5352 = load i64, ptr %slot3, align 8
  %p5353 = inttoptr i64 %v5352 to ptr
  call void @llvm.memset.p0.i64(ptr %p5353, i8 0, i64 32, i1 false), !alias.scope !3, !noalias !4, !dbg !130
  %v5354 = load i64, ptr %slot3, align 8
  %p5355 = inttoptr i64 %v5354 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5355, i64 32, i1 false)
  ret void
}

@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8
@myl_t_4effe551e6f882f95ca22b6a99ba7ef2d10593cb127780f431fe8228826f5fd3 = external global i8, align 8
@myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c = external global i8, align 8
@myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_drop(i64, i64)
declare i32 @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_take(i64, i64, i64, i32)
declare void @myl_t_088a268867b687a3a9caeae275ffeed5df3a15f8e022662cd075544b276d86ae_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_drop(i64, i64)
declare i32 @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_take(i64, i64, i64, i32)
declare void @myl_t_5e6ee5f0ed6b1d4ee8fc0afdaa088445498daa28d3e9e07cdbbcceac14ec74fb_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_take(i64, i64, i64, i32)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_drop(i64, i64)
declare i32 @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fa50b7bf30f3b4cd8f725d3e1e35b0eb86a95fb940698ebcb15d9aeb757679f7_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9fc06d0290f8b50ff4ff3bc73e7d23268320ac28e17087c68ac3835de3f54fdc", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9fc06d0290f8b50ff4ff3bc73e7d23268320ac28e17087c68ac3835de3f54fdc", linkageName: "myl_f_9fc06d0290f8b50ff4ff3bc73e7d23268320ac28e17087c68ac3835de3f54fdc", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 13739754665434447619, i64 0, !"myl_f_9fc06d0290f8b50ff4ff3bc73e7d23268320ac28e17087c68ac3835de3f54fdc"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!120 = !DILocation(line: 12, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!124 = !DILocation(line: 17, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!126 = !DILocation(line: 18, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!128 = !DILocation(line: 21, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!130 = !DILocation(line: 22, column: 0, scope: !131)
