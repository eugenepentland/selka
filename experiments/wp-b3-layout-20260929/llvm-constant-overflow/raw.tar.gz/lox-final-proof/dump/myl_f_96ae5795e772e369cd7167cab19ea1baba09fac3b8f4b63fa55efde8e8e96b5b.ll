target triple = "x86_64-unknown-linux-gnu"

define dllexport i32 @myl_f_96ae5795e772e369cd7167cab19ea1baba09fac3b8f4b63fa55efde8e8e96b5b(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  %v125 = load i64, ptr %slot1, align 8
  %op126 = add i64 %v125, 32
  store i64 %op126, ptr %slot6, align 8
  %mem127 = alloca i8, i64 8, align 8
  %ptr128 = ptrtoint ptr %mem127 to i64
  store i64 %ptr128, ptr %slot7, align 8
  %mem129 = alloca i8, i64 8, align 8
  %ptr130 = ptrtoint ptr %mem129 to i64
  store i64 %ptr130, ptr %slot8, align 8
  %mem131 = alloca i8, i64 8, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot9, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot10, align 8
  %mem135 = alloca i8, i64 8, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot11, align 8
  %mem137 = alloca i8, i64 8, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot12, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot13, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot14, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot15, align 8
  %mem145 = alloca i8, i64 8, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot16, align 8
  %mem147 = alloca i8, i64 8, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot17, align 8
  %v149 = load i64, ptr %slot2, align 8
  %v150 = load i64, ptr %slot8, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot3, align 8
  %v153 = load i64, ptr %slot9, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 %v152, ptr %p154, align 8, !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot4, align 8
  %v156 = load i64, ptr %slot10, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 %v155, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot5, align 8
  %v159 = load i64, ptr %slot11, align 8
  %p160 = inttoptr i64 %v159 to ptr
  store i64 %v158, ptr %p160, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v161 = load i64, ptr %slot8, align 8
  %p162 = inttoptr i64 %v161 to ptr
  %ld163 = load i64, ptr %p162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld163, ptr %slot18, align 8
  %v164 = load i64, ptr %slot18, align 8
  %v165 = load i64, ptr %slot13, align 8
  %p166 = inttoptr i64 %v165 to ptr
  store i64 %v164, ptr %p166, align 8, !alias.scope !3, !noalias !4
  %v167 = load i64, ptr %slot13, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %ld169 = load i64, ptr %p168, align 8, !alias.scope !3, !noalias !4
  store i64 %ld169, ptr %slot19, align 8
  %v170 = load i64, ptr %slot19, align 8
  %op171 = add i64 %v170, 16
  store i64 %op171, ptr %slot20, align 8
  %v172 = load i64, ptr %slot20, align 8
  %p173 = inttoptr i64 %v172 to ptr
  %ld174 = load i64, ptr %p173, align 8, !alias.scope !4, !noalias !3
  store i64 %ld174, ptr %slot21, align 8
  %v175 = load i64, ptr %slot21, align 8
  %v176 = load i64, ptr %slot13, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i64 %v175, ptr %p177, align 8, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot8, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot22, align 8
  %v181 = load i64, ptr %slot22, align 8
  %v182 = load i64, ptr %slot14, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot14, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %ld186 = load i64, ptr %p185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot23, align 8
  %v187 = load i64, ptr %slot23, align 8
  %op188 = add i64 %v187, 8
  store i64 %op188, ptr %slot24, align 8
  %v189 = load i64, ptr %slot24, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %ld191 = load i64, ptr %p190, align 8, !alias.scope !4, !noalias !3
  store i64 %ld191, ptr %slot25, align 8
  %v192 = load i64, ptr %slot25, align 8
  %v193 = load i64, ptr %slot14, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i64 %v192, ptr %p194, align 8, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot14, align 8
  %p196 = inttoptr i64 %v195 to ptr
  %ld197 = load i64, ptr %p196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld197, ptr %slot26, align 8
  %v198 = load i64, ptr %slot13, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot27, align 8
  %v201 = load i64, ptr %slot27, align 8
  %v202 = load i64, ptr %slot26, align 8
  %ovpair204 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v201, i64 %v202)
  %op203 = extractvalue { i64, i1 } %ovpair204, 0
  %ov205 = extractvalue { i64, i1 } %ovpair204, 1
  store i64 %op203, ptr %slot28, align 8
  %v206 = load i64, ptr %slot27, align 8
  %v207 = load i64, ptr %slot26, align 8
  %op208 = xor i64 %v206, %v207
  store i64 %op208, ptr %slot29, align 8
  %v209 = load i64, ptr %slot27, align 8
  %v210 = load i64, ptr %slot28, align 8
  %op211 = xor i64 %v209, %v210
  store i64 %op211, ptr %slot30, align 8
  %v212 = load i64, ptr %slot29, align 8
  %v213 = load i64, ptr %slot30, align 8
  %op214 = and i64 %v212, %v213
  store i64 %op214, ptr %slot31, align 8
  %cv215 = zext i1 %ov205 to i64
  store i64 %cv215, ptr %slot32, align 8
  %v216 = load i64, ptr %slot32, align 8
  %cond217 = icmp ne i64 %v216, 0
  br i1 %cond217, label %bb_overflow10, label %bb_checked10
bb_overflow10:
  %v218 = load i64, ptr %slot1, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %v220 = load i64, ptr %slot27, align 8
  %v221 = load i64, ptr %slot26, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p219, i64 1, i64 %v220, i64 %v221, i64 64) nomerge, !dbg !110
  unreachable
bb_checked10:
  %v222 = load i64, ptr %slot28, align 8
  %v223 = load i64, ptr %slot13, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i64 %v222, ptr %p224, align 8, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot9, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot33, align 8
  %v228 = load i64, ptr %slot33, align 8
  %v229 = load i64, ptr %slot14, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 %v228, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot10, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld233, ptr %slot34, align 8
  %v234 = load i64, ptr %slot34, align 8
  %v235 = load i64, ptr %slot15, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i64 %v234, ptr %p236, align 8, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot15, align 8
  %p238 = inttoptr i64 %v237 to ptr
  %ld239 = load i64, ptr %p238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld239, ptr %slot35, align 8
  %v240 = load i64, ptr %slot35, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i64, ptr %p241, align 8, !alias.scope !6, !noalias !7
  store i64 %ld242, ptr %slot36, align 8
  %v243 = load i64, ptr %slot36, align 8
  %v244 = load i64, ptr %slot15, align 8
  %p245 = inttoptr i64 %v244 to ptr
  store i64 %v243, ptr %p245, align 8, !alias.scope !3, !noalias !4
  %v246 = load i64, ptr %slot15, align 8
  %p247 = inttoptr i64 %v246 to ptr
  %ld248 = load i64, ptr %p247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld248, ptr %slot37, align 8
  %v249 = load i64, ptr %slot14, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %ld251 = load i64, ptr %p250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld251, ptr %slot38, align 8
  %v252 = load i64, ptr %slot38, align 8
  %v253 = load i64, ptr %slot37, align 8
  %ovpair255 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v252, i64 %v253)
  %op254 = extractvalue { i64, i1 } %ovpair255, 0
  %ov256 = extractvalue { i64, i1 } %ovpair255, 1
  store i64 %op254, ptr %slot39, align 8
  %v257 = load i64, ptr %slot38, align 8
  %v258 = load i64, ptr %slot39, align 8
  %op259 = xor i64 %v257, %v258
  store i64 %op259, ptr %slot40, align 8
  %v260 = load i64, ptr %slot37, align 8
  %v261 = load i64, ptr %slot39, align 8
  %op262 = xor i64 %v260, %v261
  store i64 %op262, ptr %slot41, align 8
  %v263 = load i64, ptr %slot40, align 8
  %v264 = load i64, ptr %slot41, align 8
  %op265 = and i64 %v263, %v264
  store i64 %op265, ptr %slot42, align 8
  %cv266 = zext i1 %ov256 to i64
  store i64 %cv266, ptr %slot43, align 8
  %v267 = load i64, ptr %slot43, align 8
  %cond268 = icmp ne i64 %v267, 0
  br i1 %cond268, label %bb_overflow21, label %bb_checked21
bb_overflow21:
  %v269 = load i64, ptr %slot1, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %v271 = load i64, ptr %slot38, align 8
  %v272 = load i64, ptr %slot37, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p270, i64 0, i64 %v271, i64 %v272, i64 64) nomerge, !dbg !112
  unreachable
bb_checked21:
  %v273 = load i64, ptr %slot39, align 8
  %v274 = load i64, ptr %slot14, align 8
  %p275 = inttoptr i64 %v274 to ptr
  store i64 %v273, ptr %p275, align 8, !alias.scope !3, !noalias !4
  %v276 = load i64, ptr %slot14, align 8
  %p277 = inttoptr i64 %v276 to ptr
  %ld278 = load i64, ptr %p277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld278, ptr %slot44, align 8
  %v279 = load i64, ptr %slot13, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %ld281 = load i64, ptr %p280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld281, ptr %slot45, align 8
  %v282 = load i64, ptr %slot45, align 8
  %v283 = load i64, ptr %slot44, align 8
  %cmp284 = icmp ne i64 %v282, %v283
  %cv285 = zext i1 %cmp284 to i64
  store i64 %cv285, ptr %slot46, align 8
  %v286 = load i64, ptr %slot46, align 8
  %v287 = load i64, ptr %slot13, align 8
  %p288 = inttoptr i64 %v287 to ptr
  store i64 %v286, ptr %p288, align 8, !alias.scope !3, !noalias !4
  %v289 = load i64, ptr %slot13, align 8
  %p290 = inttoptr i64 %v289 to ptr
  %ld291 = load i64, ptr %p290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld291, ptr %slot47, align 8
  %v292 = load i64, ptr %slot47, align 8
  %cond293 = icmp ne i64 %v292, 0
  br i1 %cond293, label %bb_next30, label %bb_i13
bb_next30:
  %v294 = load i64, ptr %slot16, align 8
  store i64 %v294, ptr %slot48, align 8
  %v295 = load i64, ptr %slot48, align 8
  %p296 = inttoptr i64 %v295 to ptr
  store i32 19, ptr %p296, align 4, !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot48, align 8
  %v298 = load i64, ptr %slot13, align 8
  %p299 = inttoptr i64 %v298 to ptr
  store i64 %v297, ptr %p299, align 8, !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot13, align 8
  %p301 = inttoptr i64 %v300 to ptr
  %ld302 = load i64, ptr %p301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld302, ptr %slot49, align 8
  %v303 = load i64, ptr %slot49, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ret305 = load i32, ptr %p304, align 4
  ret i32 %ret305
bb_i13:
  %v306 = load i64, ptr %slot13, align 8
  %p307 = inttoptr i64 %v306 to ptr
  store i64 0, ptr %p307, align 8, !alias.scope !3, !noalias !4
  %v308 = load i64, ptr %slot13, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %ld310 = load i64, ptr %p309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld310, ptr %slot50, align 8
  %v311 = load i64, ptr %slot12, align 8
  store i64 %v311, ptr %slot51, align 8
  %v312 = load i64, ptr %slot50, align 8
  %v313 = load i64, ptr %slot51, align 8
  %p314 = inttoptr i64 %v313 to ptr
  store i64 %v312, ptr %p314, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v315 = load i64, ptr %slot12, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot52, align 8
  %v318 = load i64, ptr %slot52, align 8
  %v319 = load i64, ptr %slot13, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i64 %v318, ptr %p320, align 8, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot10, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %ld323 = load i64, ptr %p322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld323, ptr %slot53, align 8
  %v324 = load i64, ptr %slot53, align 8
  %v325 = load i64, ptr %slot14, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i64 %v324, ptr %p326, align 8, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot14, align 8
  %p328 = inttoptr i64 %v327 to ptr
  %ld329 = load i64, ptr %p328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld329, ptr %slot54, align 8
  %v330 = load i64, ptr %slot54, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %ld332 = load i64, ptr %p331, align 8, !alias.scope !6, !noalias !7
  store i64 %ld332, ptr %slot55, align 8
  %v333 = load i64, ptr %slot55, align 8
  %v334 = load i64, ptr %slot14, align 8
  %p335 = inttoptr i64 %v334 to ptr
  store i64 %v333, ptr %p335, align 8, !alias.scope !3, !noalias !4
  %v336 = load i64, ptr %slot14, align 8
  %p337 = inttoptr i64 %v336 to ptr
  %ld338 = load i64, ptr %p337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld338, ptr %slot56, align 8
  %v339 = load i64, ptr %slot13, align 8
  %p340 = inttoptr i64 %v339 to ptr
  %ld341 = load i64, ptr %p340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld341, ptr %slot57, align 8
  %v342 = load i64, ptr %slot57, align 8
  %v343 = load i64, ptr %slot56, align 8
  %cmp344 = icmp slt i64 %v342, %v343
  %cv345 = zext i1 %cmp344 to i64
  store i64 %cv345, ptr %slot58, align 8
  %v346 = load i64, ptr %slot58, align 8
  %v347 = load i64, ptr %slot13, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i64 %v346, ptr %p348, align 8, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot13, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %ld351 = load i64, ptr %p350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld351, ptr %slot59, align 8
  %v352 = load i64, ptr %slot59, align 8
  %cond353 = icmp ne i64 %v352, 0
  br i1 %cond353, label %bb_next42, label %bb_i43
bb_next42:
  %v354 = load i64, ptr %slot8, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %ld356 = load i64, ptr %p355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld356, ptr %slot60, align 8
  %v357 = load i64, ptr %slot60, align 8
  %v358 = load i64, ptr %slot13, align 8
  %p359 = inttoptr i64 %v358 to ptr
  store i64 %v357, ptr %p359, align 8, !alias.scope !3, !noalias !4
  %v360 = load i64, ptr %slot13, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %ld362 = load i64, ptr %p361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld362, ptr %slot61, align 8
  %v363 = load i64, ptr %slot61, align 8
  %op364 = add i64 %v363, 0
  store i64 %op364, ptr %slot62, align 8
  %v365 = load i64, ptr %slot62, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %ld367 = load i64, ptr %p366, align 8, !alias.scope !4, !noalias !3
  store i64 %ld367, ptr %slot63, align 8
  %v368 = load i64, ptr %slot63, align 8
  %v369 = load i64, ptr %slot13, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i64 %v368, ptr %p370, align 8, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot8, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld373, ptr %slot64, align 8
  %v374 = load i64, ptr %slot64, align 8
  %v375 = load i64, ptr %slot14, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot14, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %ld379 = load i64, ptr %p378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld379, ptr %slot65, align 8
  %v380 = load i64, ptr %slot65, align 8
  %op381 = add i64 %v380, 8
  store i64 %op381, ptr %slot66, align 8
  %v382 = load i64, ptr %slot66, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i64, ptr %p383, align 8, !alias.scope !4, !noalias !3
  store i64 %ld384, ptr %slot67, align 8
  %v385 = load i64, ptr %slot67, align 8
  %v386 = load i64, ptr %slot14, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i64 %v385, ptr %p387, align 8, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot9, align 8
  %p389 = inttoptr i64 %v388 to ptr
  %ld390 = load i64, ptr %p389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld390, ptr %slot68, align 8
  %v391 = load i64, ptr %slot68, align 8
  %v392 = load i64, ptr %slot15, align 8
  %p393 = inttoptr i64 %v392 to ptr
  store i64 %v391, ptr %p393, align 8, !alias.scope !3, !noalias !4
  %v394 = load i64, ptr %slot15, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld396, ptr %slot69, align 8
  %v397 = load i64, ptr %slot14, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %ld399 = load i64, ptr %p398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld399, ptr %slot70, align 8
  %v400 = load i64, ptr %slot70, align 8
  %v401 = load i64, ptr %slot69, align 8
  %ovpair403 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v400, i64 %v401)
  %op402 = extractvalue { i64, i1 } %ovpair403, 0
  %ov404 = extractvalue { i64, i1 } %ovpair403, 1
  store i64 %op402, ptr %slot71, align 8
  %v405 = load i64, ptr %slot70, align 8
  %v406 = load i64, ptr %slot71, align 8
  %op407 = xor i64 %v405, %v406
  store i64 %op407, ptr %slot72, align 8
  %v408 = load i64, ptr %slot69, align 8
  %v409 = load i64, ptr %slot71, align 8
  %op410 = xor i64 %v408, %v409
  store i64 %op410, ptr %slot73, align 8
  %v411 = load i64, ptr %slot72, align 8
  %v412 = load i64, ptr %slot73, align 8
  %op413 = and i64 %v411, %v412
  store i64 %op413, ptr %slot74, align 8
  %cv414 = zext i1 %ov404 to i64
  store i64 %cv414, ptr %slot75, align 8
  %v415 = load i64, ptr %slot75, align 8
  %cond416 = icmp ne i64 %v415, 0
  br i1 %cond416, label %bb_overflow53, label %bb_checked53
bb_overflow53:
  %v417 = load i64, ptr %slot1, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %v419 = load i64, ptr %slot70, align 8
  %v420 = load i64, ptr %slot69, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p418, i64 0, i64 %v419, i64 %v420, i64 64) nomerge, !dbg !114
  unreachable
bb_checked53:
  %v421 = load i64, ptr %slot71, align 8
  %v422 = load i64, ptr %slot14, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i64 %v421, ptr %p423, align 8, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot12, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %ld426 = load i64, ptr %p425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld426, ptr %slot76, align 8
  %v427 = load i64, ptr %slot76, align 8
  %v428 = load i64, ptr %slot15, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i64 %v427, ptr %p429, align 8, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot15, align 8
  %p431 = inttoptr i64 %v430 to ptr
  %ld432 = load i64, ptr %p431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld432, ptr %slot77, align 8
  %v433 = load i64, ptr %slot14, align 8
  %p434 = inttoptr i64 %v433 to ptr
  %ld435 = load i64, ptr %p434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld435, ptr %slot78, align 8
  %v436 = load i64, ptr %slot78, align 8
  %v437 = load i64, ptr %slot77, align 8
  %ovpair439 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v436, i64 %v437)
  %op438 = extractvalue { i64, i1 } %ovpair439, 0
  %ov440 = extractvalue { i64, i1 } %ovpair439, 1
  store i64 %op438, ptr %slot79, align 8
  %v441 = load i64, ptr %slot78, align 8
  %v442 = load i64, ptr %slot79, align 8
  %op443 = xor i64 %v441, %v442
  store i64 %op443, ptr %slot80, align 8
  %v444 = load i64, ptr %slot77, align 8
  %v445 = load i64, ptr %slot79, align 8
  %op446 = xor i64 %v444, %v445
  store i64 %op446, ptr %slot81, align 8
  %v447 = load i64, ptr %slot80, align 8
  %v448 = load i64, ptr %slot81, align 8
  %op449 = and i64 %v447, %v448
  store i64 %op449, ptr %slot82, align 8
  %cv450 = zext i1 %ov440 to i64
  store i64 %cv450, ptr %slot83, align 8
  %v451 = load i64, ptr %slot83, align 8
  %cond452 = icmp ne i64 %v451, 0
  br i1 %cond452, label %bb_overflow61, label %bb_checked61
bb_overflow61:
  %v453 = load i64, ptr %slot1, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %v455 = load i64, ptr %slot78, align 8
  %v456 = load i64, ptr %slot77, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p454, i64 0, i64 %v455, i64 %v456, i64 64) nomerge, !dbg !116
  unreachable
bb_checked61:
  %v457 = load i64, ptr %slot79, align 8
  %v458 = load i64, ptr %slot14, align 8
  %p459 = inttoptr i64 %v458 to ptr
  store i64 %v457, ptr %p459, align 8, !alias.scope !3, !noalias !4
  %v460 = load i64, ptr %slot13, align 8
  %p461 = inttoptr i64 %v460 to ptr
  %ld462 = load i64, ptr %p461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld462, ptr %slot84, align 8
  %v463 = load i64, ptr %slot14, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %ld465 = load i64, ptr %p464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld465, ptr %slot85, align 8
  %v466 = load i64, ptr %slot84, align 8
  %p467 = inttoptr i64 %v466 to ptr
  %ld468 = load i64, ptr %p467, align 8, !alias.scope !6, !noalias !7
  store i64 %ld468, ptr %slot86, align 8
  %v469 = load i64, ptr %slot85, align 8
  %op470 = ashr i64 %v469, 63
  store i64 %op470, ptr %slot87, align 8
  %v471 = load i64, ptr %slot87, align 8
  %v472 = load i64, ptr %slot86, align 8
  %op473 = and i64 %v471, %v472
  store i64 %op473, ptr %slot88, align 8
  %v474 = load i64, ptr %slot85, align 8
  %v475 = load i64, ptr %slot88, align 8
  %op476 = add i64 %v474, %v475
  store i64 %op476, ptr %slot89, align 8
  %v477 = load i64, ptr %slot89, align 8
  %v478 = load i64, ptr %slot86, align 8
  %cmp479 = icmp ult i64 %v477, %v478
  %cv480 = zext i1 %cmp479 to i64
  store i64 %cv480, ptr %slot90, align 8
  %v481 = load i64, ptr %slot90, align 8
  %cond482 = icmp ne i64 %v481, 0
  br i1 %cond482, label %bb_success74, label %bb_failed74
bb_failed74:
  %v483 = load i64, ptr %slot1, align 8
  %p484 = inttoptr i64 %v483 to ptr
  %v485 = load i64, ptr %slot85, align 8
  %v486 = load i64, ptr %slot86, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p484, i64 %v485, i64 %v486) nomerge, !dbg !118
  unreachable
bb_success74:
  %v487 = load i64, ptr %slot84, align 8
  %op488 = add i64 %v487, 32
  store i64 %op488, ptr %slot91, align 8
  %v489 = load i64, ptr %slot91, align 8
  %p490 = inttoptr i64 %v489 to ptr
  %ld491 = load i64, ptr %p490, align 8, !alias.scope !6, !noalias !7
  store i64 %ld491, ptr %slot92, align 8
  %v492 = load i64, ptr %slot92, align 8
  %v493 = load i64, ptr %slot89, align 8
  %op494 = add i64 %v492, %v493
  store i64 %op494, ptr %slot93, align 8
  %v495 = load i64, ptr %slot92, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %v497 = load i64, ptr %slot89, align 8
  %egep498 = getelementptr i8, ptr %p496, i64 %v497
  %ld499 = load i8, ptr %egep498, align 1, !alias.scope !12, !noalias !13
  %ext500 = zext i8 %ld499 to i64
  store i64 %ext500, ptr %slot94, align 8
  %v501 = load i64, ptr %slot94, align 8
  %v502 = load i64, ptr %slot13, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i64 %v501, ptr %p503, align 8, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot13, align 8
  %p505 = inttoptr i64 %v504 to ptr
  %ld506 = load i64, ptr %p505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld506, ptr %slot95, align 8
  %v507 = load i64, ptr %slot95, align 8
  %v508 = load i64, ptr %slot13, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 %v507, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot10, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i64, ptr %p511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld512, ptr %slot96, align 8
  %v513 = load i64, ptr %slot96, align 8
  %v514 = load i64, ptr %slot14, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i64 %v513, ptr %p515, align 8, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot12, align 8
  %p517 = inttoptr i64 %v516 to ptr
  %ld518 = load i64, ptr %p517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld518, ptr %slot97, align 8
  %v519 = load i64, ptr %slot97, align 8
  %v520 = load i64, ptr %slot15, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i64 %v519, ptr %p521, align 8, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot14, align 8
  %p523 = inttoptr i64 %v522 to ptr
  %ld524 = load i64, ptr %p523, align 8, !alias.scope !3, !noalias !4
  store i64 %ld524, ptr %slot98, align 8
  %v525 = load i64, ptr %slot15, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i64, ptr %p526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld527, ptr %slot99, align 8
  %v528 = load i64, ptr %slot98, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !6, !noalias !7
  store i64 %ld530, ptr %slot100, align 8
  %v531 = load i64, ptr %slot99, align 8
  %op532 = ashr i64 %v531, 63
  store i64 %op532, ptr %slot101, align 8
  %v533 = load i64, ptr %slot101, align 8
  %v534 = load i64, ptr %slot100, align 8
  %op535 = and i64 %v533, %v534
  store i64 %op535, ptr %slot102, align 8
  %v536 = load i64, ptr %slot99, align 8
  %v537 = load i64, ptr %slot102, align 8
  %op538 = add i64 %v536, %v537
  store i64 %op538, ptr %slot103, align 8
  %v539 = load i64, ptr %slot103, align 8
  %v540 = load i64, ptr %slot100, align 8
  %cmp541 = icmp ult i64 %v539, %v540
  %cv542 = zext i1 %cmp541 to i64
  store i64 %cv542, ptr %slot104, align 8
  %v543 = load i64, ptr %slot104, align 8
  %cond544 = icmp ne i64 %v543, 0
  br i1 %cond544, label %bb_success91, label %bb_failed91
bb_failed91:
  %v545 = load i64, ptr %slot1, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %v547 = load i64, ptr %slot99, align 8
  %v548 = load i64, ptr %slot100, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p546, i64 %v547, i64 %v548) nomerge, !dbg !120
  unreachable
bb_success91:
  %v549 = load i64, ptr %slot98, align 8
  %op550 = add i64 %v549, 32
  store i64 %op550, ptr %slot105, align 8
  %v551 = load i64, ptr %slot105, align 8
  %p552 = inttoptr i64 %v551 to ptr
  %ld553 = load i64, ptr %p552, align 8, !alias.scope !6, !noalias !7
  store i64 %ld553, ptr %slot106, align 8
  %v554 = load i64, ptr %slot106, align 8
  %v555 = load i64, ptr %slot103, align 8
  %op556 = add i64 %v554, %v555
  store i64 %op556, ptr %slot107, align 8
  %v557 = load i64, ptr %slot106, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %v559 = load i64, ptr %slot103, align 8
  %egep560 = getelementptr i8, ptr %p558, i64 %v559
  %ld561 = load i8, ptr %egep560, align 1, !alias.scope !12, !noalias !13
  %ext562 = zext i8 %ld561 to i64
  store i64 %ext562, ptr %slot108, align 8
  %v563 = load i64, ptr %slot108, align 8
  %v564 = load i64, ptr %slot14, align 8
  %p565 = inttoptr i64 %v564 to ptr
  store i64 %v563, ptr %p565, align 8, !alias.scope !3, !noalias !4
  %v566 = load i64, ptr %slot14, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i64, ptr %p567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld568, ptr %slot109, align 8
  %v569 = load i64, ptr %slot109, align 8
  %v570 = load i64, ptr %slot14, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i64 %v569, ptr %p571, align 8, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot14, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %ld574 = load i64, ptr %p573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld574, ptr %slot110, align 8
  %v575 = load i64, ptr %slot13, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i64, ptr %p576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld577, ptr %slot111, align 8
  %v578 = load i64, ptr %slot111, align 8
  %v579 = load i64, ptr %slot110, align 8
  %cmp580 = icmp ne i64 %v578, %v579
  %cv581 = zext i1 %cmp580 to i64
  store i64 %cv581, ptr %slot112, align 8
  %v582 = load i64, ptr %slot112, align 8
  %v583 = load i64, ptr %slot13, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i64 %v582, ptr %p584, align 8, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot13, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %ld587 = load i64, ptr %p586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld587, ptr %slot113, align 8
  %v588 = load i64, ptr %slot113, align 8
  %cond589 = icmp ne i64 %v588, 0
  br i1 %cond589, label %bb_next102, label %bb_i38
bb_next102:
  %v590 = load i64, ptr %slot17, align 8
  store i64 %v590, ptr %slot114, align 8
  %v591 = load i64, ptr %slot114, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i32 19, ptr %p592, align 4, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot114, align 8
  %v594 = load i64, ptr %slot13, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i64 %v593, ptr %p595, align 8, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot13, align 8
  %p597 = inttoptr i64 %v596 to ptr
  %ld598 = load i64, ptr %p597, align 8, !alias.scope !3, !noalias !4
  store i64 %ld598, ptr %slot115, align 8
  %v599 = load i64, ptr %slot115, align 8
  %p600 = inttoptr i64 %v599 to ptr
  %ret601 = load i32, ptr %p600, align 4
  ret i32 %ret601
bb_i38:
  %v602 = load i64, ptr %slot12, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %ld604 = load i64, ptr %p603, align 8, !alias.scope !3, !noalias !4
  store i64 %ld604, ptr %slot116, align 8
  %v605 = load i64, ptr %slot116, align 8
  %v606 = load i64, ptr %slot13, align 8
  %p607 = inttoptr i64 %v606 to ptr
  store i64 %v605, ptr %p607, align 8, !alias.scope !3, !noalias !4
  %v608 = load i64, ptr %slot14, align 8
  %p609 = inttoptr i64 %v608 to ptr
  store i64 1, ptr %p609, align 8, !alias.scope !3, !noalias !4
  %v610 = load i64, ptr %slot14, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %ld612 = load i64, ptr %p611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld612, ptr %slot117, align 8
  %v613 = load i64, ptr %slot13, align 8
  %p614 = inttoptr i64 %v613 to ptr
  %ld615 = load i64, ptr %p614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld615, ptr %slot118, align 8
  %v616 = load i64, ptr %slot118, align 8
  %v617 = load i64, ptr %slot117, align 8
  %ovpair619 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v616, i64 %v617)
  %op618 = extractvalue { i64, i1 } %ovpair619, 0
  %ov620 = extractvalue { i64, i1 } %ovpair619, 1
  store i64 %op618, ptr %slot119, align 8
  %cv621 = zext i1 %ov620 to i64
  store i64 %cv621, ptr %slot120, align 8
  %v622 = load i64, ptr %slot120, align 8
  %cond623 = icmp ne i64 %v622, 0
  br i1 %cond623, label %bb_overflow107, label %bb_checked107
bb_overflow107:
  %v624 = load i64, ptr %slot1, align 8
  %p625 = inttoptr i64 %v624 to ptr
  %v626 = load i64, ptr %slot118, align 8
  %v627 = load i64, ptr %slot117, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p625, i64 0, i64 %v626, i64 %v627, i64 64) nomerge, !dbg !122
  unreachable
bb_checked107:
  %v628 = load i64, ptr %slot119, align 8
  %v629 = load i64, ptr %slot13, align 8
  %p630 = inttoptr i64 %v629 to ptr
  store i64 %v628, ptr %p630, align 8, !alias.scope !3, !noalias !4
  %v631 = load i64, ptr %slot13, align 8
  %p632 = inttoptr i64 %v631 to ptr
  %ld633 = load i64, ptr %p632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld633, ptr %slot121, align 8
  %v634 = load i64, ptr %slot12, align 8
  store i64 %v634, ptr %slot122, align 8
  %v635 = load i64, ptr %slot121, align 8
  %v636 = load i64, ptr %slot122, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i64 %v635, ptr %p637, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i43:
  %v638 = load i64, ptr %slot11, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %ld640 = load i64, ptr %p639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld640, ptr %slot123, align 8
  %v641 = load i64, ptr %slot123, align 8
  %v642 = load i64, ptr %slot13, align 8
  %p643 = inttoptr i64 %v642 to ptr
  store i64 %v641, ptr %p643, align 8, !alias.scope !3, !noalias !4
  %v644 = load i64, ptr %slot13, align 8
  %p645 = inttoptr i64 %v644 to ptr
  %ld646 = load i64, ptr %p645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld646, ptr %slot124, align 8
  %v647 = load i64, ptr %slot124, align 8
  %p648 = inttoptr i64 %v647 to ptr
  %ret649 = load i32, ptr %p648, align 4
  ret i32 %ret649
bb_failure:
  %v650 = load i64, ptr %slot7, align 8
  %p651 = inttoptr i64 %v650 to ptr
  call void @llvm.memset.p0.i64(ptr %p651, i8 0, i64 8, i1 false), !alias.scope !3, !noalias !4, !dbg !124
  %v652 = load i64, ptr %slot7, align 8
  %p653 = inttoptr i64 %v652 to ptr
  %ret654 = load i32, ptr %p653, align 4
  ret i32 %ret654
bb_entry_failure:
  %v655 = load i64, ptr %slot7, align 8
  %p656 = inttoptr i64 %v655 to ptr
  call void @llvm.memset.p0.i64(ptr %p656, i8 0, i64 8, i1 false), !alias.scope !3, !noalias !4, !dbg !124
  %v657 = load i64, ptr %slot7, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ret659 = load i32, ptr %p658, align 4
  ret i32 %ret659
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_96ae5795e772e369cd7167cab19ea1baba09fac3b8f4b63fa55efde8e8e96b5b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_96ae5795e772e369cd7167cab19ea1baba09fac3b8f4b63fa55efde8e8e96b5b", linkageName: "myl_f_96ae5795e772e369cd7167cab19ea1baba09fac3b8f4b63fa55efde8e8e96b5b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4695887466324449128, i64 0, !"myl_f_96ae5795e772e369cd7167cab19ea1baba09fac3b8f4b63fa55efde8e8e96b5b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!110 = !DILocation(line: 5, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!112 = !DILocation(line: 9, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!114 = !DILocation(line: 26, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!116 = !DILocation(line: 28, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!118 = !DILocation(line: 29, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!120 = !DILocation(line: 33, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!122 = !DILocation(line: 41, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!124 = !DILocation(line: 45, column: 0, scope: !125)
