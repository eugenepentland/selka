target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %callresult41 = alloca [24 x i8], align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %callresult159 = alloca [16 x i8], align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %callresult191 = alloca [16 x i8], align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v236 = load i64, ptr %slot1, align 8
  %op237 = add i64 %v236, 32
  store i64 %op237, ptr %slot4, align 8
  %mem238 = alloca i8, i64 24, align 8
  %ptr239 = ptrtoint ptr %mem238 to i64
  store i64 %ptr239, ptr %slot5, align 8
  %mem240 = alloca i8, i64 8, align 8
  %ptr241 = ptrtoint ptr %mem240 to i64
  store i64 %ptr241, ptr %slot6, align 8
  %mem242 = alloca i8, i64 8, align 8
  %ptr243 = ptrtoint ptr %mem242 to i64
  store i64 %ptr243, ptr %slot7, align 8
  %mem244 = alloca i8, i64 8, align 8
  %ptr245 = ptrtoint ptr %mem244 to i64
  store i64 %ptr245, ptr %slot8, align 8
  %mem246 = alloca i8, i64 8, align 8
  %ptr247 = ptrtoint ptr %mem246 to i64
  store i64 %ptr247, ptr %slot9, align 8
  %mem248 = alloca i8, i64 8, align 8
  %ptr249 = ptrtoint ptr %mem248 to i64
  store i64 %ptr249, ptr %slot10, align 8
  %mem250 = alloca i8, i64 8, align 8
  %ptr251 = ptrtoint ptr %mem250 to i64
  store i64 %ptr251, ptr %slot11, align 8
  %mem252 = alloca i8, i64 8, align 8
  %ptr253 = ptrtoint ptr %mem252 to i64
  store i64 %ptr253, ptr %slot12, align 8
  %mem254 = alloca i8, i64 8, align 8
  %ptr255 = ptrtoint ptr %mem254 to i64
  store i64 %ptr255, ptr %slot13, align 8
  %mem256 = alloca i8, i64 8, align 8
  %ptr257 = ptrtoint ptr %mem256 to i64
  store i64 %ptr257, ptr %slot14, align 8
  %mem258 = alloca i8, i64 304, align 8
  %ptr259 = ptrtoint ptr %mem258 to i64
  store i64 %ptr259, ptr %slot15, align 8
  %mem260 = alloca i8, i64 304, align 8
  %ptr261 = ptrtoint ptr %mem260 to i64
  store i64 %ptr261, ptr %slot16, align 8
  %mem262 = alloca i8, i64 8, align 8
  %ptr263 = ptrtoint ptr %mem262 to i64
  store i64 %ptr263, ptr %slot17, align 8
  %mem264 = alloca i8, i64 8, align 8
  %ptr265 = ptrtoint ptr %mem264 to i64
  store i64 %ptr265, ptr %slot18, align 8
  %mem266 = alloca i8, i64 40, align 8
  %ptr267 = ptrtoint ptr %mem266 to i64
  store i64 %ptr267, ptr %slot19, align 8
  %mem268 = alloca i8, i64 208, align 8
  %ptr269 = ptrtoint ptr %mem268 to i64
  store i64 %ptr269, ptr %slot20, align 8
  %mem270 = alloca i8, i64 8, align 8
  %ptr271 = ptrtoint ptr %mem270 to i64
  store i64 %ptr271, ptr %slot21, align 8
  %mem272 = alloca i8, i64 8, align 8
  %ptr273 = ptrtoint ptr %mem272 to i64
  store i64 %ptr273, ptr %slot22, align 8
  %mem274 = alloca i8, i64 8, align 8
  %ptr275 = ptrtoint ptr %mem274 to i64
  store i64 %ptr275, ptr %slot23, align 8
  %mem276 = alloca i8, i64 8, align 8
  %ptr277 = ptrtoint ptr %mem276 to i64
  store i64 %ptr277, ptr %slot24, align 8
  %mem278 = alloca i8, i64 24, align 8
  %ptr279 = ptrtoint ptr %mem278 to i64
  store i64 %ptr279, ptr %slot25, align 8
  %mem280 = alloca i8, i64 304, align 8
  %ptr281 = ptrtoint ptr %mem280 to i64
  store i64 %ptr281, ptr %slot26, align 8
  %mem282 = alloca i8, i64 304, align 8
  %ptr283 = ptrtoint ptr %mem282 to i64
  store i64 %ptr283, ptr %slot27, align 8
  %mem284 = alloca i8, i64 8, align 8
  %ptr285 = ptrtoint ptr %mem284 to i64
  store i64 %ptr285, ptr %slot28, align 8
  %mem286 = alloca i8, i64 24, align 8
  %ptr287 = ptrtoint ptr %mem286 to i64
  store i64 %ptr287, ptr %slot29, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem288 = alloca i8, i64 8, align 8
  %ptr289 = ptrtoint ptr %mem288 to i64
  store i64 %ptr289, ptr %slot30, align 8
  %v290 = load i64, ptr %slot1, align 8
  %op291 = add i64 %v290, 64
  store i64 %op291, ptr %slot31, align 8
  %v292 = load i64, ptr %slot31, align 8
  %p293 = inttoptr i64 %v292 to ptr
  %ld294 = load i64, ptr %p293, align 8, !alias.scope !4, !noalias !3
  store i64 %ld294, ptr %slot32, align 8
  %stack295 = call ptr @llvm.stacksave()
  %stackaddr296 = ptrtoint ptr %stack295 to i64
  %v297 = load i64, ptr %slot32, align 8
  %cmp298 = icmp ult i64 %stackaddr296, %v297
  %cv299 = zext i1 %cmp298 to i64
  store i64 %cv299, ptr %slot33, align 8
  %v300 = load i64, ptr %slot33, align 8
  %cond301 = icmp ne i64 %v300, 0
  br i1 %cond301, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v302 = load i64, ptr %slot1, align 8
  %p303 = inttoptr i64 %v302 to ptr
  call void @myl_qbe_fail_frame(ptr %p303) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v304 = load i64, ptr %slot2, align 8
  %v305 = load i64, ptr %slot17, align 8
  %p306 = inttoptr i64 %v305 to ptr
  store i64 %v304, ptr %p306, align 8, !alias.scope !3, !noalias !4
  %v307 = load i64, ptr %slot3, align 8
  %v308 = load i64, ptr %slot18, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 %v307, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot1, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %call312 = call ptr @myl_qbe_heap(ptr %p311) nomerge, !dbg !112
  %calladdr313 = ptrtoint ptr %call312 to i64
  store i64 %calladdr313, ptr %slot34, align 8
  %v314 = load i64, ptr %slot1, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %call316 = call i64 @myl_qbe_region_mark(ptr %p315) nomerge, !dbg !112
  store i64 %call316, ptr %slot35, align 8
  %v317 = load i64, ptr %slot6, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i32 0, ptr %p318, align 4, !alias.scope !3, !noalias !4
  %v319 = load i64, ptr %slot7, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 0, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot8, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i32 0, ptr %p322, align 4, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot9, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i32 0, ptr %p324, align 4, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot10, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i32 0, ptr %p326, align 4, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot11, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i32 0, ptr %p328, align 4, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot12, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i32 0, ptr %p330, align 4, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot13, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i32 0, ptr %p332, align 4, !alias.scope !3, !noalias !4
  %v333 = load i64, ptr %slot14, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i32 0, ptr %p334, align 4, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot7, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i32 2, ptr %p336, align 4, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot9, align 8
  %p338 = inttoptr i64 %v337 to ptr
  store i32 2, ptr %p338, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v339 = load i64, ptr %slot17, align 8
  %p340 = inttoptr i64 %v339 to ptr
  %ld341 = load i64, ptr %p340, align 8, !alias.scope !3, !noalias !4
  store i64 %ld341, ptr %slot36, align 8
  %v342 = load i64, ptr %slot36, align 8
  %v343 = load i64, ptr %slot21, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i64 %v342, ptr %p344, align 8, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot18, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld347, ptr %slot37, align 8
  %v348 = load i64, ptr %slot37, align 8
  %v349 = load i64, ptr %slot22, align 8
  %p350 = inttoptr i64 %v349 to ptr
  store i64 %v348, ptr %p350, align 8, !alias.scope !3, !noalias !4
  %v351 = load i64, ptr %slot21, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %ld353 = load i64, ptr %p352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld353, ptr %slot38, align 8
  %v354 = load i64, ptr %slot22, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %ld356 = load i64, ptr %p355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld356, ptr %slot39, align 8
  %v357 = load i64, ptr %slot1, align 8
  %v358 = load i64, ptr %slot38, align 8
  %v359 = load i64, ptr %slot39, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult41, i64 %v357, i64 %v358, i64 %v359) nomerge, !dbg !114
  %addr360 = ptrtoint ptr %callresult41 to i64
  store i64 %addr360, ptr %slot40, align 8
  %v361 = load i64, ptr %slot40, align 8
  %v362 = load i64, ptr %slot21, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i64 %v361, ptr %p363, align 8, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot21, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot42, align 8
  %v367 = load i64, ptr %slot16, align 8
  store i64 %v367, ptr %slot43, align 8
  %v368 = load i64, ptr %slot42, align 8
  %v369 = load i64, ptr %slot43, align 8
  %p370 = inttoptr i64 %v368 to ptr
  %p371 = inttoptr i64 %v369 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p371, ptr %p370, i64 24, i1 false)
  %v372 = load i64, ptr %slot13, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i32 2, ptr %p373, align 4, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot12, align 8
  %p375 = inttoptr i64 %v374 to ptr
  store i32 1, ptr %p375, align 4, !alias.scope !3, !noalias !4
  %v376 = load i64, ptr %slot10, align 8
  %p377 = inttoptr i64 %v376 to ptr
  %ld378 = load i32, ptr %p377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld378, ptr %slot44, align 8
  %v379 = load i32, ptr %slot44, align 8
  %cv380 = zext i32 %v379 to i64
  %cond381 = icmp ne i64 %cv380, 0
  br i1 %cond381, label %bb_rcslotdrop25, label %bb_rcslotdone25
bb_rcslotdrop25:
  %v382 = load i64, ptr %slot10, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i32 0, ptr %p383, align 4, !alias.scope !3, !noalias !4
  %v384 = load i64, ptr %slot15, align 8
  store i64 %v384, ptr %slot45, align 8
  %v385 = load i64, ptr %slot11, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %ld387 = load i32, ptr %p386, align 4, !alias.scope !3, !noalias !4
  store i32 %ld387, ptr %slot46, align 8
  %v388 = load i32, ptr %slot46, align 8
  %op389 = and i32 %v388, 28
  store i32 %op389, ptr %slot47, align 8
  %v390 = load i32, ptr %slot47, align 8
  %cv391 = zext i32 %v390 to i64
  %cond392 = icmp ne i64 %cv391, 0
  br i1 %cond392, label %bb_rcslotrole25, label %bb_rcslotowner25
bb_rcslotrole25:
  %v393 = load i64, ptr %slot34, align 8
  store i64 %v393, ptr %slot48, align 8
  %v394 = load i64, ptr %slot48, align 8
  %v395 = load i64, ptr %slot45, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v394, i64 %v395) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotowner25:
  %v396 = load i64, ptr %slot34, align 8
  store i64 %v396, ptr %slot49, align 8
  %v397 = load i64, ptr %slot49, align 8
  %v398 = load i64, ptr %slot45, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v397, i64 %v398) nomerge, !dbg !114
  br label %bb_rcslotdone25
bb_rcslotdone25:
  %v399 = load i64, ptr %slot15, align 8
  store i64 %v399, ptr %slot50, align 8
  %v400 = load i64, ptr %slot16, align 8
  store i64 %v400, ptr %slot51, align 8
  %v401 = load i64, ptr %slot51, align 8
  %v402 = load i64, ptr %slot50, align 8
  %p403 = inttoptr i64 %v401 to ptr
  %p404 = inttoptr i64 %v402 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p404, ptr %p403, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot11, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i32 2, ptr %p406, align 4, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot13, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i32, ptr %p408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld409, ptr %slot52, align 8
  %v410 = load i32, ptr %slot52, align 8
  %v411 = load i64, ptr %slot11, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i32 %v410, ptr %p412, align 4, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot12, align 8
  %p414 = inttoptr i64 %v413 to ptr
  store i32 0, ptr %p414, align 4, !alias.scope !3, !noalias !4
  %v415 = load i64, ptr %slot10, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i32 1, ptr %p416, align 4, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot50, align 8
  %v418 = load i64, ptr %slot21, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i64 %v417, ptr %p419, align 8, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot21, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %ld422 = load i64, ptr %p421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld422, ptr %slot53, align 8
  %v423 = load i64, ptr %slot53, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i32, ptr %p424, align 4, !alias.scope !3, !noalias !4
  %ext426 = zext i32 %ld425 to i64
  store i64 %ext426, ptr %slot54, align 8
  %v427 = load i64, ptr %slot54, align 8
  %cmp428 = icmp eq i64 %v427, 0
  %cv429 = zext i1 %cmp428 to i64
  store i64 %cv429, ptr %slot55, align 8
  %v430 = load i64, ptr %slot55, align 8
  %cond431 = icmp ne i64 %v430, 0
  br i1 %cond431, label %bb_rctryok41, label %bb_rctryerror41
bb_rctryerror41:
  %p432 = inttoptr i64 ptrtoint (ptr @myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p432, i64 12884901891) "call-inline-cost"="0", !dbg !116
  %v433 = load i64, ptr %slot53, align 8
  %op434 = add i64 %v433, 8
  store i64 %op434, ptr %slot56, align 8
  %v435 = load i64, ptr %slot25, align 8
  store i64 %v435, ptr %slot57, align 8
  %v436 = load i64, ptr %slot57, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i64 0, ptr %p437, align 8, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot57, align 8
  %p440 = inttoptr i64 %v438 to ptr
  %gep441 = getelementptr i8, ptr %p440, i64 8
  %op439 = ptrtoint ptr %gep441 to i64
  store i64 %op439, ptr %slot58, align 8
  %v442 = load i64, ptr %slot58, align 8
  %p443 = inttoptr i64 %v442 to ptr
  store i64 0, ptr %p443, align 8, !alias.scope !3, !noalias !4
  %v444 = load i64, ptr %slot57, align 8
  %p446 = inttoptr i64 %v444 to ptr
  %gep447 = getelementptr i8, ptr %p446, i64 16
  %op445 = ptrtoint ptr %gep447 to i64
  store i64 %op445, ptr %slot59, align 8
  %v448 = load i64, ptr %slot59, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i64 0, ptr %p449, align 8, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot57, align 8
  %p451 = inttoptr i64 %v450 to ptr
  store i32 1, ptr %p451, align 4, !alias.scope !3, !noalias !4
  %v452 = load i64, ptr %slot57, align 8
  %p454 = inttoptr i64 %v452 to ptr
  %gep455 = getelementptr i8, ptr %p454, i64 8
  %op453 = ptrtoint ptr %gep455 to i64
  store i64 %op453, ptr %slot60, align 8
  %v456 = load i64, ptr %slot14, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i32 1, ptr %p457, align 4, !alias.scope !3, !noalias !4
  %v458 = load i64, ptr %slot35, align 8
  store i64 %v458, ptr %slot61, align 8
  %v459 = load i64, ptr %slot34, align 8
  %v460 = load i64, ptr %slot60, align 8
  %v461 = load i64, ptr %slot56, align 8
  %v462 = load i64, ptr %slot61, align 8
  %cv463 = trunc i64 %v462 to i32
  %call464 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v459, i64 %v460, i64 %v461, i32 %cv463) nomerge, !dbg !116
  store i32 %call464, ptr %slot62, align 8
  %v465 = load i32, ptr %slot62, align 8
  %cv466 = zext i32 %v465 to i64
  %cond467 = icmp ne i64 %cv466, 0
  br i1 %cond467, label %bb_rcsuccess52, label %bb_rcfailure52
bb_rcfailure52:
  %v468 = load i64, ptr %slot34, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %call470 = call i32 @myl_rc_take_failure(ptr %p469) nomerge, !dbg !116
  store i32 %call470, ptr %slot63, align 8
  %v471 = load i64, ptr %slot1, align 8
  %p472 = inttoptr i64 %v471 to ptr
  %v473 = load i32, ptr %slot63, align 8
  %call474 = call i32 @myl_qbe_rc_status(ptr %p472, i32 %v473) nomerge, !dbg !116
  store i32 %call474, ptr %slot64, align 8
  br label %bb_failure
bb_rcsuccess52:
  %v475 = load i64, ptr %slot57, align 8
  %v476 = load i64, ptr %slot21, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i64 %v475, ptr %p477, align 8, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot21, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %ld480 = load i64, ptr %p479, align 8, !alias.scope !3, !noalias !4
  store i64 %ld480, ptr %slot65, align 8
  %v481 = load i64, ptr %slot16, align 8
  store i64 %v481, ptr %slot66, align 8
  %v482 = load i64, ptr %slot65, align 8
  %v483 = load i64, ptr %slot66, align 8
  %p484 = inttoptr i64 %v482 to ptr
  %p485 = inttoptr i64 %v483 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p485, ptr %p484, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot13, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 2, ptr %p487, align 4, !alias.scope !3, !noalias !4
  %v488 = load i64, ptr %slot12, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i32 1, ptr %p489, align 4, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot10, align 8
  %p491 = inttoptr i64 %v490 to ptr
  %ld492 = load i32, ptr %p491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld492, ptr %slot67, align 8
  %v493 = load i32, ptr %slot67, align 8
  %cv494 = zext i32 %v493 to i64
  %cond495 = icmp ne i64 %cv494, 0
  br i1 %cond495, label %bb_rcslotdrop61, label %bb_rcslotdone61
bb_rcslotdrop61:
  %v496 = load i64, ptr %slot10, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i32 0, ptr %p497, align 4, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot15, align 8
  store i64 %v498, ptr %slot68, align 8
  %v499 = load i64, ptr %slot11, align 8
  %p500 = inttoptr i64 %v499 to ptr
  %ld501 = load i32, ptr %p500, align 4, !alias.scope !3, !noalias !4
  store i32 %ld501, ptr %slot69, align 8
  %v502 = load i32, ptr %slot69, align 8
  %op503 = and i32 %v502, 28
  store i32 %op503, ptr %slot70, align 8
  %v504 = load i32, ptr %slot70, align 8
  %cv505 = zext i32 %v504 to i64
  %cond506 = icmp ne i64 %cv505, 0
  br i1 %cond506, label %bb_rcslotrole61, label %bb_rcslotowner61
bb_rcslotrole61:
  %v507 = load i64, ptr %slot34, align 8
  store i64 %v507, ptr %slot71, align 8
  %v508 = load i64, ptr %slot71, align 8
  %v509 = load i64, ptr %slot68, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v508, i64 %v509) nomerge, !dbg !116
  br label %bb_rcslotdone61
bb_rcslotowner61:
  %v510 = load i64, ptr %slot34, align 8
  store i64 %v510, ptr %slot72, align 8
  %v511 = load i64, ptr %slot72, align 8
  %v512 = load i64, ptr %slot68, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v511, i64 %v512) nomerge, !dbg !116
  br label %bb_rcslotdone61
bb_rcslotdone61:
  %v513 = load i64, ptr %slot15, align 8
  store i64 %v513, ptr %slot73, align 8
  %v514 = load i64, ptr %slot16, align 8
  store i64 %v514, ptr %slot74, align 8
  %v515 = load i64, ptr %slot74, align 8
  %v516 = load i64, ptr %slot73, align 8
  %p517 = inttoptr i64 %v515 to ptr
  %p518 = inttoptr i64 %v516 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p518, ptr %p517, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot11, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i32 2, ptr %p520, align 4, !alias.scope !3, !noalias !4
  %v521 = load i64, ptr %slot13, align 8
  %p522 = inttoptr i64 %v521 to ptr
  %ld523 = load i32, ptr %p522, align 4, !alias.scope !3, !noalias !4
  store i32 %ld523, ptr %slot75, align 8
  %v524 = load i32, ptr %slot75, align 8
  %v525 = load i64, ptr %slot11, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 %v524, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %v527 = load i64, ptr %slot12, align 8
  %p528 = inttoptr i64 %v527 to ptr
  store i32 0, ptr %p528, align 4, !alias.scope !3, !noalias !4
  %v529 = load i64, ptr %slot10, align 8
  %p530 = inttoptr i64 %v529 to ptr
  store i32 1, ptr %p530, align 4, !alias.scope !3, !noalias !4
  %v531 = load i64, ptr %slot73, align 8
  %v532 = load i64, ptr %slot21, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i64 %v531, ptr %p533, align 8, !alias.scope !3, !noalias !4
  br label %bb_i5
bb_rctryok41:
  %v534 = load i64, ptr %slot25, align 8
  store i64 %v534, ptr %slot76, align 8
  %v535 = load i64, ptr %slot14, align 8
  %p536 = inttoptr i64 %v535 to ptr
  store i32 1, ptr %p536, align 4, !alias.scope !3, !noalias !4
  %v537 = load i64, ptr %slot53, align 8
  %op538 = add i64 %v537, 8
  store i64 %op538, ptr %slot77, align 8
  %v539 = load i64, ptr %slot35, align 8
  store i64 %v539, ptr %slot78, align 8
  store i64 0, ptr %slot79, align 8
  store i64 0, ptr %slot80, align 8
  %v540 = load i64, ptr %slot80, align 8
  %v541 = load i64, ptr %slot21, align 8
  %p542 = inttoptr i64 %v541 to ptr
  store i64 %v540, ptr %p542, align 8, !alias.scope !3, !noalias !4
  %v543 = load i64, ptr %slot10, align 8
  %p544 = inttoptr i64 %v543 to ptr
  %ld545 = load i32, ptr %p544, align 4, !alias.scope !3, !noalias !4
  store i32 %ld545, ptr %slot81, align 8
  %v546 = load i32, ptr %slot81, align 8
  %cv547 = zext i32 %v546 to i64
  %cond548 = icmp ne i64 %cv547, 0
  br i1 %cond548, label %bb_rcslotdrop85, label %bb_rcslotdone85
bb_rcslotdrop85:
  %v549 = load i64, ptr %slot10, align 8
  %p550 = inttoptr i64 %v549 to ptr
  store i32 0, ptr %p550, align 4, !alias.scope !3, !noalias !4
  %v551 = load i64, ptr %slot15, align 8
  store i64 %v551, ptr %slot82, align 8
  %v552 = load i64, ptr %slot11, align 8
  %p553 = inttoptr i64 %v552 to ptr
  %ld554 = load i32, ptr %p553, align 4, !alias.scope !3, !noalias !4
  store i32 %ld554, ptr %slot83, align 8
  %v555 = load i32, ptr %slot83, align 8
  %op556 = and i32 %v555, 28
  store i32 %op556, ptr %slot84, align 8
  %v557 = load i32, ptr %slot84, align 8
  %cv558 = zext i32 %v557 to i64
  %cond559 = icmp ne i64 %cv558, 0
  br i1 %cond559, label %bb_rcslotrole85, label %bb_rcslotowner85
bb_rcslotrole85:
  %v560 = load i64, ptr %slot34, align 8
  store i64 %v560, ptr %slot85, align 8
  %v561 = load i64, ptr %slot85, align 8
  %v562 = load i64, ptr %slot82, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v561, i64 %v562) nomerge, !dbg !116
  br label %bb_rcslotdone85
bb_rcslotowner85:
  %v563 = load i64, ptr %slot34, align 8
  store i64 %v563, ptr %slot86, align 8
  %v564 = load i64, ptr %slot86, align 8
  %v565 = load i64, ptr %slot82, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v564, i64 %v565) nomerge, !dbg !116
  br label %bb_rcslotdone85
bb_rcslotdone85:
  br label %bb_i6
bb_i5:
  %v566 = load i64, ptr %slot21, align 8
  %p567 = inttoptr i64 %v566 to ptr
  %ld568 = load i64, ptr %p567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld568, ptr %slot87, align 8
  %v569 = load i64, ptr %slot21, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot88, align 8
  %v572 = load i64, ptr %slot10, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %ld574 = load i32, ptr %p573, align 4, !alias.scope !3, !noalias !4
  store i32 %ld574, ptr %slot89, align 8
  %v575 = load i64, ptr %slot11, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %ld577 = load i32, ptr %p576, align 4, !alias.scope !3, !noalias !4
  store i32 %ld577, ptr %slot90, align 8
  %v578 = load i32, ptr %slot90, align 8
  %op579 = and i32 %v578, 24
  store i32 %op579, ptr %slot90, align 8
  %v580 = load i32, ptr %slot90, align 8
  %cmp581 = icmp eq i32 %v580, 0
  %cv582 = zext i1 %cmp581 to i32
  store i32 %cv582, ptr %slot91, align 8
  %v583 = load i32, ptr %slot89, align 8
  %v584 = load i32, ptr %slot91, align 8
  %op585 = and i32 %v583, %v584
  store i32 %op585, ptr %slot92, align 8
  %v586 = load i32, ptr %slot92, align 8
  %cv587 = zext i32 %v586 to i64
  %cond588 = icmp ne i64 %cv587, 0
  br i1 %cond588, label %bb_rctake94, label %bb_rccopy94
bb_rctake94:
  %v589 = load i64, ptr %slot16, align 8
  store i64 %v589, ptr %slot93, align 8
  %v590 = load i64, ptr %slot35, align 8
  store i64 %v590, ptr %slot94, align 8
  %v591 = load i64, ptr %slot34, align 8
  %v592 = load i64, ptr %slot93, align 8
  %v593 = load i64, ptr %slot88, align 8
  %v594 = load i64, ptr %slot94, align 8
  %cv595 = trunc i64 %v594 to i32
  %call596 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v591, i64 %v592, i64 %v593, i32 %cv595) nomerge, !dbg !118
  store i32 %call596, ptr %slot95, align 8
  %v597 = load i32, ptr %slot95, align 8
  %cv598 = zext i32 %v597 to i64
  %cond599 = icmp ne i64 %cv598, 0
  br i1 %cond599, label %bb_rcsuccess104, label %bb_rcfailure104
bb_rcfailure104:
  %v600 = load i64, ptr %slot34, align 8
  %p601 = inttoptr i64 %v600 to ptr
  %call602 = call i32 @myl_rc_take_failure(ptr %p601) nomerge, !dbg !118
  store i32 %call602, ptr %slot96, align 8
  %v603 = load i64, ptr %slot1, align 8
  %p604 = inttoptr i64 %v603 to ptr
  %v605 = load i32, ptr %slot96, align 8
  %call606 = call i32 @myl_qbe_rc_status(ptr %p604, i32 %v605) nomerge, !dbg !118
  store i32 %call606, ptr %slot97, align 8
  br label %bb_failure
bb_rcsuccess104:
  %v607 = load i64, ptr %slot10, align 8
  %p608 = inttoptr i64 %v607 to ptr
  store i32 0, ptr %p608, align 4, !alias.scope !3, !noalias !4
  %v609 = load i64, ptr %slot13, align 8
  %p610 = inttoptr i64 %v609 to ptr
  store i32 2, ptr %p610, align 4, !alias.scope !3, !noalias !4
  %v611 = load i64, ptr %slot12, align 8
  %p612 = inttoptr i64 %v611 to ptr
  store i32 1, ptr %p612, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared94
bb_rccopy94:
  %v613 = load i64, ptr %slot16, align 8
  store i64 %v613, ptr %slot98, align 8
  %v614 = load i64, ptr %slot35, align 8
  store i64 %v614, ptr %slot99, align 8
  %v615 = load i64, ptr %slot34, align 8
  %v616 = load i64, ptr %slot98, align 8
  %v617 = load i64, ptr %slot88, align 8
  %v618 = load i64, ptr %slot99, align 8
  %cv619 = trunc i64 %v618 to i32
  %call620 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64 %v615, i64 %v616, i64 %v617, i32 %cv619) nomerge, !dbg !118
  store i32 %call620, ptr %slot100, align 8
  %v621 = load i32, ptr %slot100, align 8
  %cv622 = zext i32 %v621 to i64
  %cond623 = icmp ne i64 %cv622, 0
  br i1 %cond623, label %bb_rcsuccess113, label %bb_rcfailure113
bb_rcfailure113:
  %v624 = load i64, ptr %slot34, align 8
  %p625 = inttoptr i64 %v624 to ptr
  %call626 = call i32 @myl_rc_take_failure(ptr %p625) nomerge, !dbg !118
  store i32 %call626, ptr %slot101, align 8
  %v627 = load i64, ptr %slot1, align 8
  %p628 = inttoptr i64 %v627 to ptr
  %v629 = load i32, ptr %slot101, align 8
  %call630 = call i32 @myl_qbe_rc_status(ptr %p628, i32 %v629) nomerge, !dbg !118
  store i32 %call630, ptr %slot102, align 8
  br label %bb_failure
bb_rcsuccess113:
  %v631 = load i64, ptr %slot13, align 8
  %p632 = inttoptr i64 %v631 to ptr
  store i32 2, ptr %p632, align 4, !alias.scope !3, !noalias !4
  %v633 = load i64, ptr %slot12, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i32 1, ptr %p634, align 4, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot10, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i32, ptr %p636, align 4, !alias.scope !3, !noalias !4
  store i32 %ld637, ptr %slot103, align 8
  %v638 = load i32, ptr %slot103, align 8
  %cv639 = zext i32 %v638 to i64
  %cond640 = icmp ne i64 %cv639, 0
  br i1 %cond640, label %bb_rcslotdrop120, label %bb_rcslotdone120
bb_rcslotdrop120:
  %v641 = load i64, ptr %slot10, align 8
  %p642 = inttoptr i64 %v641 to ptr
  store i32 0, ptr %p642, align 4, !alias.scope !3, !noalias !4
  %v643 = load i64, ptr %slot15, align 8
  store i64 %v643, ptr %slot104, align 8
  %v644 = load i64, ptr %slot11, align 8
  %p645 = inttoptr i64 %v644 to ptr
  %ld646 = load i32, ptr %p645, align 4, !alias.scope !3, !noalias !4
  store i32 %ld646, ptr %slot105, align 8
  %v647 = load i32, ptr %slot105, align 8
  %op648 = and i32 %v647, 28
  store i32 %op648, ptr %slot106, align 8
  %v649 = load i32, ptr %slot106, align 8
  %cv650 = zext i32 %v649 to i64
  %cond651 = icmp ne i64 %cv650, 0
  br i1 %cond651, label %bb_rcslotrole120, label %bb_rcslotowner120
bb_rcslotrole120:
  %v652 = load i64, ptr %slot34, align 8
  store i64 %v652, ptr %slot107, align 8
  %v653 = load i64, ptr %slot107, align 8
  %v654 = load i64, ptr %slot104, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v653, i64 %v654) nomerge, !dbg !118
  br label %bb_rcslotdone120
bb_rcslotowner120:
  %v655 = load i64, ptr %slot34, align 8
  store i64 %v655, ptr %slot108, align 8
  %v656 = load i64, ptr %slot108, align 8
  %v657 = load i64, ptr %slot104, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v656, i64 %v657) nomerge, !dbg !118
  br label %bb_rcslotdone120
bb_rcslotdone120:
  br label %bb_rcprepared94
bb_rcprepared94:
  %v658 = load i64, ptr %slot16, align 8
  store i64 %v658, ptr %slot109, align 8
  %v659 = load i64, ptr %slot12, align 8
  %p660 = inttoptr i64 %v659 to ptr
  store i32 0, ptr %p660, align 4, !alias.scope !3, !noalias !4
  %v661 = load i64, ptr %slot10, align 8
  %p662 = inttoptr i64 %v661 to ptr
  %ld663 = load i32, ptr %p662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld663, ptr %slot110, align 8
  %v664 = load i32, ptr %slot110, align 8
  %cv665 = zext i32 %v664 to i64
  %cond666 = icmp ne i64 %cv665, 0
  br i1 %cond666, label %bb_rcslotdrop131, label %bb_rcslotdone131
bb_rcslotdrop131:
  %v667 = load i64, ptr %slot10, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 0, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot15, align 8
  store i64 %v669, ptr %slot111, align 8
  %v670 = load i64, ptr %slot11, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i32, ptr %p671, align 4, !alias.scope !3, !noalias !4
  store i32 %ld672, ptr %slot112, align 8
  %v673 = load i32, ptr %slot112, align 8
  %op674 = and i32 %v673, 28
  store i32 %op674, ptr %slot113, align 8
  %v675 = load i32, ptr %slot113, align 8
  %cv676 = zext i32 %v675 to i64
  %cond677 = icmp ne i64 %cv676, 0
  br i1 %cond677, label %bb_rcslotrole131, label %bb_rcslotowner131
bb_rcslotrole131:
  %v678 = load i64, ptr %slot34, align 8
  store i64 %v678, ptr %slot114, align 8
  %v679 = load i64, ptr %slot114, align 8
  %v680 = load i64, ptr %slot111, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v679, i64 %v680) nomerge, !dbg !118
  br label %bb_rcslotdone131
bb_rcslotowner131:
  %v681 = load i64, ptr %slot34, align 8
  store i64 %v681, ptr %slot115, align 8
  %v682 = load i64, ptr %slot115, align 8
  %v683 = load i64, ptr %slot111, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v682, i64 %v683) nomerge, !dbg !118
  br label %bb_rcslotdone131
bb_rcslotdone131:
  %v684 = load i64, ptr %slot8, align 8
  %p685 = inttoptr i64 %v684 to ptr
  %ld686 = load i32, ptr %p685, align 4, !alias.scope !3, !noalias !4
  store i32 %ld686, ptr %slot116, align 8
  %v687 = load i32, ptr %slot116, align 8
  %cv688 = zext i32 %v687 to i64
  %cond689 = icmp ne i64 %cv688, 0
  br i1 %cond689, label %bb_rcslotdrop158, label %bb_rcslotdone158
bb_rcslotdrop158:
  %v690 = load i64, ptr %slot8, align 8
  %p691 = inttoptr i64 %v690 to ptr
  store i32 0, ptr %p691, align 4, !alias.scope !3, !noalias !4
  %v692 = load i64, ptr %slot20, align 8
  store i64 %v692, ptr %slot117, align 8
  %v693 = load i64, ptr %slot9, align 8
  %p694 = inttoptr i64 %v693 to ptr
  %ld695 = load i32, ptr %p694, align 4, !alias.scope !3, !noalias !4
  store i32 %ld695, ptr %slot118, align 8
  %v696 = load i32, ptr %slot118, align 8
  %op697 = and i32 %v696, 28
  store i32 %op697, ptr %slot119, align 8
  %v698 = load i32, ptr %slot119, align 8
  %cv699 = zext i32 %v698 to i64
  %cond700 = icmp ne i64 %cv699, 0
  br i1 %cond700, label %bb_rcslotrole158, label %bb_rcslotowner158
bb_rcslotrole158:
  %v701 = load i64, ptr %slot34, align 8
  store i64 %v701, ptr %slot120, align 8
  %v702 = load i64, ptr %slot120, align 8
  %v703 = load i64, ptr %slot117, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v702, i64 %v703) nomerge, !dbg !118
  br label %bb_rcslotdone158
bb_rcslotowner158:
  %v704 = load i64, ptr %slot34, align 8
  store i64 %v704, ptr %slot121, align 8
  %v705 = load i64, ptr %slot121, align 8
  %v706 = load i64, ptr %slot117, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v705, i64 %v706) nomerge, !dbg !118
  br label %bb_rcslotdone158
bb_rcslotdone158:
  %v707 = load i64, ptr %slot6, align 8
  %p708 = inttoptr i64 %v707 to ptr
  %ld709 = load i32, ptr %p708, align 4, !alias.scope !3, !noalias !4
  store i32 %ld709, ptr %slot122, align 8
  %v710 = load i32, ptr %slot122, align 8
  %cv711 = zext i32 %v710 to i64
  %cond712 = icmp ne i64 %cv711, 0
  br i1 %cond712, label %bb_rcslotdrop185, label %bb_rcslotdone185
bb_rcslotdrop185:
  %v713 = load i64, ptr %slot6, align 8
  %p714 = inttoptr i64 %v713 to ptr
  store i32 0, ptr %p714, align 4, !alias.scope !3, !noalias !4
  %v715 = load i64, ptr %slot19, align 8
  store i64 %v715, ptr %slot123, align 8
  %v716 = load i64, ptr %slot7, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %ld718 = load i32, ptr %p717, align 4, !alias.scope !3, !noalias !4
  store i32 %ld718, ptr %slot124, align 8
  %v719 = load i32, ptr %slot124, align 8
  %op720 = and i32 %v719, 28
  store i32 %op720, ptr %slot125, align 8
  %v721 = load i32, ptr %slot125, align 8
  %cv722 = zext i32 %v721 to i64
  %cond723 = icmp ne i64 %cv722, 0
  br i1 %cond723, label %bb_rcslotrole185, label %bb_rcslotowner185
bb_rcslotrole185:
  %v724 = load i64, ptr %slot34, align 8
  store i64 %v724, ptr %slot126, align 8
  %v725 = load i64, ptr %slot126, align 8
  %v726 = load i64, ptr %slot123, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v725, i64 %v726) nomerge, !dbg !118
  br label %bb_rcslotdone185
bb_rcslotowner185:
  %v727 = load i64, ptr %slot34, align 8
  store i64 %v727, ptr %slot127, align 8
  %v728 = load i64, ptr %slot127, align 8
  %v729 = load i64, ptr %slot123, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v728, i64 %v729) nomerge, !dbg !118
  br label %bb_rcslotdone185
bb_rcslotdone185:
  %v730 = load i64, ptr %slot109, align 8
  %p731 = inttoptr i64 %v730 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p731, i64 24, i1 false)
  ret void
bb_i6:
  %v732 = load i64, ptr %slot17, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %ld734 = load i64, ptr %p733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld734, ptr %slot128, align 8
  %v735 = load i64, ptr %slot128, align 8
  %v736 = load i64, ptr %slot26, align 8
  %p737 = inttoptr i64 %v735 to ptr
  %p738 = inttoptr i64 %v736 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p738, ptr %p737, i64 304, i1 false), !alias.scope !10000000
  %v739 = load i64, ptr %slot26, align 8
  %v740 = load i64, ptr %slot21, align 8
  %p741 = inttoptr i64 %v740 to ptr
  store i64 %v739, ptr %p741, align 8, !alias.scope !3, !noalias !4
  %v742 = load i64, ptr %slot21, align 8
  %p743 = inttoptr i64 %v742 to ptr
  %ld744 = load i64, ptr %p743, align 8, !alias.scope !3, !noalias !4
  store i64 %ld744, ptr %slot129, align 8
  %v745 = load i64, ptr %slot129, align 8
  %op746 = add i64 %v745, 240
  store i64 %op746, ptr %slot130, align 8
  %v747 = load i64, ptr %slot130, align 8
  %v748 = load i64, ptr %slot21, align 8
  %p749 = inttoptr i64 %v748 to ptr
  store i64 %v747, ptr %p749, align 8, !alias.scope !3, !noalias !4
  %v750 = load i64, ptr %slot6, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %ld752 = load i32, ptr %p751, align 4, !alias.scope !3, !noalias !4
  store i32 %ld752, ptr %slot131, align 8
  %v753 = load i32, ptr %slot131, align 8
  %cv754 = zext i32 %v753 to i64
  %cond755 = icmp ne i64 %cv754, 0
  br i1 %cond755, label %bb_rcslotdrop206, label %bb_rcslotdone206
bb_rcslotdrop206:
  %v756 = load i64, ptr %slot6, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i32 0, ptr %p757, align 4, !alias.scope !3, !noalias !4
  %v758 = load i64, ptr %slot19, align 8
  store i64 %v758, ptr %slot132, align 8
  %v759 = load i64, ptr %slot7, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %ld761 = load i32, ptr %p760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld761, ptr %slot133, align 8
  %v762 = load i32, ptr %slot133, align 8
  %op763 = and i32 %v762, 28
  store i32 %op763, ptr %slot134, align 8
  %v764 = load i32, ptr %slot134, align 8
  %cv765 = zext i32 %v764 to i64
  %cond766 = icmp ne i64 %cv765, 0
  br i1 %cond766, label %bb_rcslotrole206, label %bb_rcslotowner206
bb_rcslotrole206:
  %v767 = load i64, ptr %slot34, align 8
  store i64 %v767, ptr %slot135, align 8
  %v768 = load i64, ptr %slot135, align 8
  %v769 = load i64, ptr %slot132, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v768, i64 %v769) nomerge, !dbg !120
  br label %bb_rcslotdone206
bb_rcslotowner206:
  %v770 = load i64, ptr %slot34, align 8
  store i64 %v770, ptr %slot136, align 8
  %v771 = load i64, ptr %slot136, align 8
  %v772 = load i64, ptr %slot132, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v771, i64 %v772) nomerge, !dbg !120
  br label %bb_rcslotdone206
bb_rcslotdone206:
  %v773 = load i64, ptr %slot17, align 8
  %p774 = inttoptr i64 %v773 to ptr
  %ld775 = load i64, ptr %p774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld775, ptr %slot137, align 8
  %v776 = load i64, ptr %slot137, align 8
  %op777 = add i64 %v776, 240
  store i64 %op777, ptr %slot138, align 8
  %v778 = load i64, ptr %slot19, align 8
  store i64 %v778, ptr %slot139, align 8
  %v779 = load i64, ptr %slot138, align 8
  %v780 = load i64, ptr %slot139, align 8
  %p781 = inttoptr i64 %v779 to ptr
  %p782 = inttoptr i64 %v780 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p782, ptr %p781, i64 40, i1 false), !alias.scope !10000000
  %v783 = load i64, ptr %slot138, align 8
  %p784 = inttoptr i64 %v783 to ptr
  store i64 0, ptr %p784, align 8, !alias.scope !4, !noalias !3
  %v785 = load i64, ptr %slot138, align 8
  %op786 = add i64 %v785, 8
  store i64 %op786, ptr %slot140, align 8
  %v787 = load i64, ptr %slot140, align 8
  %p788 = inttoptr i64 %v787 to ptr
  store i64 0, ptr %p788, align 8, !alias.scope !4, !noalias !3
  %v789 = load i64, ptr %slot138, align 8
  %op790 = add i64 %v789, 16
  store i64 %op790, ptr %slot141, align 8
  %v791 = load i64, ptr %slot141, align 8
  %p792 = inttoptr i64 %v791 to ptr
  store i64 0, ptr %p792, align 8, !alias.scope !4, !noalias !3
  %v793 = load i64, ptr %slot138, align 8
  %op794 = add i64 %v793, 24
  store i64 %op794, ptr %slot142, align 8
  %v795 = load i64, ptr %slot142, align 8
  %p796 = inttoptr i64 %v795 to ptr
  store i64 0, ptr %p796, align 8, !alias.scope !4, !noalias !3
  %v797 = load i64, ptr %slot138, align 8
  %op798 = add i64 %v797, 32
  store i64 %op798, ptr %slot143, align 8
  %v799 = load i64, ptr %slot143, align 8
  %p800 = inttoptr i64 %v799 to ptr
  store i64 0, ptr %p800, align 8, !alias.scope !4, !noalias !3
  %v801 = load i64, ptr %slot6, align 8
  %p802 = inttoptr i64 %v801 to ptr
  store i32 1, ptr %p802, align 4, !alias.scope !3, !noalias !4
  %v803 = load i64, ptr %slot17, align 8
  %p804 = inttoptr i64 %v803 to ptr
  %ld805 = load i64, ptr %p804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld805, ptr %slot144, align 8
  %v806 = load i64, ptr %slot144, align 8
  %v807 = load i64, ptr %slot21, align 8
  %p808 = inttoptr i64 %v807 to ptr
  store i64 %v806, ptr %p808, align 8, !alias.scope !3, !noalias !4
  %v809 = load i64, ptr %slot21, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %ld811 = load i64, ptr %p810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld811, ptr %slot145, align 8
  %v812 = load i64, ptr %slot145, align 8
  %op813 = add i64 %v812, 32
  store i64 %op813, ptr %slot146, align 8
  %v814 = load i64, ptr %slot146, align 8
  %v815 = load i64, ptr %slot21, align 8
  %p816 = inttoptr i64 %v815 to ptr
  store i64 %v814, ptr %p816, align 8, !alias.scope !3, !noalias !4
  %v817 = load i64, ptr %slot10, align 8
  %p818 = inttoptr i64 %v817 to ptr
  %ld819 = load i32, ptr %p818, align 4, !alias.scope !3, !noalias !4
  store i32 %ld819, ptr %slot147, align 8
  %v820 = load i32, ptr %slot147, align 8
  %cv821 = zext i32 %v820 to i64
  %cond822 = icmp ne i64 %cv821, 0
  br i1 %cond822, label %bb_rcslotdrop226, label %bb_rcslotdone226
bb_rcslotdrop226:
  %v823 = load i64, ptr %slot10, align 8
  %p824 = inttoptr i64 %v823 to ptr
  store i32 0, ptr %p824, align 4, !alias.scope !3, !noalias !4
  %v825 = load i64, ptr %slot15, align 8
  store i64 %v825, ptr %slot148, align 8
  %v826 = load i64, ptr %slot11, align 8
  %p827 = inttoptr i64 %v826 to ptr
  %ld828 = load i32, ptr %p827, align 4, !alias.scope !3, !noalias !4
  store i32 %ld828, ptr %slot149, align 8
  %v829 = load i32, ptr %slot149, align 8
  %op830 = and i32 %v829, 28
  store i32 %op830, ptr %slot150, align 8
  %v831 = load i32, ptr %slot150, align 8
  %cv832 = zext i32 %v831 to i64
  %cond833 = icmp ne i64 %cv832, 0
  br i1 %cond833, label %bb_rcslotrole226, label %bb_rcslotowner226
bb_rcslotrole226:
  %v834 = load i64, ptr %slot34, align 8
  store i64 %v834, ptr %slot151, align 8
  %v835 = load i64, ptr %slot151, align 8
  %v836 = load i64, ptr %slot148, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v835, i64 %v836) nomerge, !dbg !122
  br label %bb_rcslotdone226
bb_rcslotowner226:
  %v837 = load i64, ptr %slot34, align 8
  store i64 %v837, ptr %slot152, align 8
  %v838 = load i64, ptr %slot152, align 8
  %v839 = load i64, ptr %slot148, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v838, i64 %v839) nomerge, !dbg !122
  br label %bb_rcslotdone226
bb_rcslotdone226:
  %v840 = load i64, ptr %slot19, align 8
  %v841 = load i64, ptr %slot22, align 8
  %p842 = inttoptr i64 %v841 to ptr
  store i64 %v840, ptr %p842, align 8, !alias.scope !3, !noalias !4
  %v843 = load i64, ptr %slot17, align 8
  %p844 = inttoptr i64 %v843 to ptr
  %ld845 = load i64, ptr %p844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld845, ptr %slot153, align 8
  %v846 = load i64, ptr %slot153, align 8
  %v847 = load i64, ptr %slot23, align 8
  %p848 = inttoptr i64 %v847 to ptr
  store i64 %v846, ptr %p848, align 8, !alias.scope !3, !noalias !4
  %v849 = load i64, ptr %slot23, align 8
  %p850 = inttoptr i64 %v849 to ptr
  %ld851 = load i64, ptr %p850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld851, ptr %slot154, align 8
  %v852 = load i64, ptr %slot154, align 8
  %op853 = add i64 %v852, 32
  store i64 %op853, ptr %slot155, align 8
  %v854 = load i64, ptr %slot155, align 8
  %v855 = load i64, ptr %slot23, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i64 %v854, ptr %p856, align 8, !alias.scope !3, !noalias !4
  %v857 = load i64, ptr %slot24, align 8
  %p858 = inttoptr i64 %v857 to ptr
  store i64 0, ptr %p858, align 8, !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot23, align 8
  %p860 = inttoptr i64 %v859 to ptr
  %ld861 = load i64, ptr %p860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld861, ptr %slot156, align 8
  %v862 = load i64, ptr %slot24, align 8
  %p863 = inttoptr i64 %v862 to ptr
  %ld864 = load i64, ptr %p863, align 8, !alias.scope !3, !noalias !4
  store i64 %ld864, ptr %slot157, align 8
  %v865 = load i64, ptr %slot1, align 8
  %v866 = load i64, ptr %slot156, align 8
  %v867 = load i64, ptr %slot157, align 8
  %call868 = call { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64 %v865, i64 %v866, i64 %v867) nomerge, !dbg !124
  store { i64, i64 } %call868, ptr %callresult159, align 8
  %addr869 = ptrtoint ptr %callresult159 to i64
  store i64 %addr869, ptr %slot158, align 8
  %v870 = load i64, ptr %slot158, align 8
  %v871 = load i64, ptr %slot23, align 8
  %p872 = inttoptr i64 %v871 to ptr
  store i64 %v870, ptr %p872, align 8, !alias.scope !3, !noalias !4
  %v873 = load i64, ptr %slot21, align 8
  %p874 = inttoptr i64 %v873 to ptr
  %ld875 = load i64, ptr %p874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld875, ptr %slot160, align 8
  %v876 = load i64, ptr %slot22, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %ld878 = load i64, ptr %p877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld878, ptr %slot161, align 8
  %v879 = load i64, ptr %slot23, align 8
  %p880 = inttoptr i64 %v879 to ptr
  %ld881 = load i64, ptr %p880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld881, ptr %slot162, align 8
  %v882 = load i64, ptr %slot1, align 8
  %v883 = load i64, ptr %slot160, align 8
  %v884 = load i64, ptr %slot161, align 8
  %v885 = load i64, ptr %slot162, align 8
  %call886 = call i64 @myl_f_a931877b11ea3aa7de37854bbbc13e6f0160c87ee24000d47530697609fa185a(i64 %v882, i64 %v883, i64 %v884, i64 %v885) nomerge, !dbg !126
  store i64 %call886, ptr %slot163, align 8
  %v887 = load i64, ptr %slot163, align 8
  %v888 = load i64, ptr %slot21, align 8
  %p889 = inttoptr i64 %v888 to ptr
  store i64 %v887, ptr %p889, align 8, !alias.scope !3, !noalias !4
  %v890 = load i64, ptr %slot10, align 8
  %p891 = inttoptr i64 %v890 to ptr
  %ld892 = load i32, ptr %p891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld892, ptr %slot164, align 8
  %v893 = load i32, ptr %slot164, align 8
  %cv894 = zext i32 %v893 to i64
  %cond895 = icmp ne i64 %cv894, 0
  br i1 %cond895, label %bb_rcslotdrop263, label %bb_rcslotdone263
bb_rcslotdrop263:
  %v896 = load i64, ptr %slot10, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i32 0, ptr %p897, align 4, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot15, align 8
  store i64 %v898, ptr %slot165, align 8
  %v899 = load i64, ptr %slot11, align 8
  %p900 = inttoptr i64 %v899 to ptr
  %ld901 = load i32, ptr %p900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld901, ptr %slot166, align 8
  %v902 = load i32, ptr %slot166, align 8
  %op903 = and i32 %v902, 28
  store i32 %op903, ptr %slot167, align 8
  %v904 = load i32, ptr %slot167, align 8
  %cv905 = zext i32 %v904 to i64
  %cond906 = icmp ne i64 %cv905, 0
  br i1 %cond906, label %bb_rcslotrole263, label %bb_rcslotowner263
bb_rcslotrole263:
  %v907 = load i64, ptr %slot34, align 8
  store i64 %v907, ptr %slot168, align 8
  %v908 = load i64, ptr %slot168, align 8
  %v909 = load i64, ptr %slot165, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v908, i64 %v909) nomerge, !dbg !126
  br label %bb_rcslotdone263
bb_rcslotowner263:
  %v910 = load i64, ptr %slot34, align 8
  store i64 %v910, ptr %slot169, align 8
  %v911 = load i64, ptr %slot169, align 8
  %v912 = load i64, ptr %slot165, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v911, i64 %v912) nomerge, !dbg !126
  br label %bb_rcslotdone263
bb_rcslotdone263:
  %v913 = load i64, ptr %slot17, align 8
  %p914 = inttoptr i64 %v913 to ptr
  %ld915 = load i64, ptr %p914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld915, ptr %slot170, align 8
  %v916 = load i64, ptr %slot170, align 8
  %op917 = add i64 %v916, 240
  store i64 %op917, ptr %slot171, align 8
  %v918 = load i64, ptr %slot19, align 8
  store i64 %v918, ptr %slot172, align 8
  %v919 = load i64, ptr %slot172, align 8
  %v920 = load i64, ptr %slot171, align 8
  %p921 = inttoptr i64 %v919 to ptr
  %p922 = inttoptr i64 %v920 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p922, ptr %p921, i64 40, i1 false), !alias.scope !10000000
  %v923 = load i64, ptr %slot172, align 8
  %p924 = inttoptr i64 %v923 to ptr
  store i64 0, ptr %p924, align 8, !alias.scope !3, !noalias !4
  %v925 = load i64, ptr %slot172, align 8
  %p927 = inttoptr i64 %v925 to ptr
  %gep928 = getelementptr i8, ptr %p927, i64 8
  %op926 = ptrtoint ptr %gep928 to i64
  store i64 %op926, ptr %slot173, align 8
  %v929 = load i64, ptr %slot173, align 8
  %p930 = inttoptr i64 %v929 to ptr
  store i64 0, ptr %p930, align 8, !alias.scope !3, !noalias !4
  %v931 = load i64, ptr %slot172, align 8
  %p933 = inttoptr i64 %v931 to ptr
  %gep934 = getelementptr i8, ptr %p933, i64 16
  %op932 = ptrtoint ptr %gep934 to i64
  store i64 %op932, ptr %slot174, align 8
  %v935 = load i64, ptr %slot174, align 8
  %p936 = inttoptr i64 %v935 to ptr
  store i64 0, ptr %p936, align 8, !alias.scope !3, !noalias !4
  %v937 = load i64, ptr %slot172, align 8
  %p939 = inttoptr i64 %v937 to ptr
  %gep940 = getelementptr i8, ptr %p939, i64 24
  %op938 = ptrtoint ptr %gep940 to i64
  store i64 %op938, ptr %slot175, align 8
  %v941 = load i64, ptr %slot175, align 8
  %p942 = inttoptr i64 %v941 to ptr
  store i64 0, ptr %p942, align 8, !alias.scope !3, !noalias !4
  %v943 = load i64, ptr %slot172, align 8
  %p945 = inttoptr i64 %v943 to ptr
  %gep946 = getelementptr i8, ptr %p945, i64 32
  %op944 = ptrtoint ptr %gep946 to i64
  store i64 %op944, ptr %slot176, align 8
  %v947 = load i64, ptr %slot176, align 8
  %p948 = inttoptr i64 %v947 to ptr
  store i64 0, ptr %p948, align 8, !alias.scope !3, !noalias !4
  %v949 = load i64, ptr %slot6, align 8
  %p950 = inttoptr i64 %v949 to ptr
  store i32 0, ptr %p950, align 4, !alias.scope !3, !noalias !4
  %v951 = load i64, ptr %slot21, align 8
  %p952 = inttoptr i64 %v951 to ptr
  store i64 0, ptr %p952, align 8, !alias.scope !3, !noalias !4
  %v953 = load i64, ptr %slot17, align 8
  %p954 = inttoptr i64 %v953 to ptr
  %ld955 = load i64, ptr %p954, align 8, !alias.scope !3, !noalias !4
  store i64 %ld955, ptr %slot177, align 8
  %v956 = load i64, ptr %slot177, align 8
  %v957 = load i64, ptr %slot27, align 8
  %p958 = inttoptr i64 %v956 to ptr
  %p959 = inttoptr i64 %v957 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p959, ptr %p958, i64 304, i1 false), !alias.scope !10000000
  %v960 = load i64, ptr %slot27, align 8
  %v961 = load i64, ptr %slot21, align 8
  %p962 = inttoptr i64 %v961 to ptr
  store i64 %v960, ptr %p962, align 8, !alias.scope !3, !noalias !4
  %v963 = load i64, ptr %slot21, align 8
  %p964 = inttoptr i64 %v963 to ptr
  %ld965 = load i64, ptr %p964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld965, ptr %slot178, align 8
  %v966 = load i64, ptr %slot178, align 8
  %op967 = add i64 %v966, 32
  store i64 %op967, ptr %slot179, align 8
  %v968 = load i64, ptr %slot179, align 8
  %v969 = load i64, ptr %slot21, align 8
  %p970 = inttoptr i64 %v969 to ptr
  store i64 %v968, ptr %p970, align 8, !alias.scope !3, !noalias !4
  %v971 = load i64, ptr %slot8, align 8
  %p972 = inttoptr i64 %v971 to ptr
  %ld973 = load i32, ptr %p972, align 4, !alias.scope !3, !noalias !4
  store i32 %ld973, ptr %slot180, align 8
  %v974 = load i32, ptr %slot180, align 8
  %cv975 = zext i32 %v974 to i64
  %cond976 = icmp ne i64 %cv975, 0
  br i1 %cond976, label %bb_rcslotdrop292, label %bb_rcslotdone292
bb_rcslotdrop292:
  %v977 = load i64, ptr %slot8, align 8
  %p978 = inttoptr i64 %v977 to ptr
  store i32 0, ptr %p978, align 4, !alias.scope !3, !noalias !4
  %v979 = load i64, ptr %slot20, align 8
  store i64 %v979, ptr %slot181, align 8
  %v980 = load i64, ptr %slot9, align 8
  %p981 = inttoptr i64 %v980 to ptr
  %ld982 = load i32, ptr %p981, align 4, !alias.scope !3, !noalias !4
  store i32 %ld982, ptr %slot182, align 8
  %v983 = load i32, ptr %slot182, align 8
  %op984 = and i32 %v983, 28
  store i32 %op984, ptr %slot183, align 8
  %v985 = load i32, ptr %slot183, align 8
  %cv986 = zext i32 %v985 to i64
  %cond987 = icmp ne i64 %cv986, 0
  br i1 %cond987, label %bb_rcslotrole292, label %bb_rcslotowner292
bb_rcslotrole292:
  %v988 = load i64, ptr %slot34, align 8
  store i64 %v988, ptr %slot184, align 8
  %v989 = load i64, ptr %slot184, align 8
  %v990 = load i64, ptr %slot181, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v989, i64 %v990) nomerge, !dbg !128
  br label %bb_rcslotdone292
bb_rcslotowner292:
  %v991 = load i64, ptr %slot34, align 8
  store i64 %v991, ptr %slot185, align 8
  %v992 = load i64, ptr %slot185, align 8
  %v993 = load i64, ptr %slot181, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v992, i64 %v993) nomerge, !dbg !128
  br label %bb_rcslotdone292
bb_rcslotdone292:
  %v994 = load i64, ptr %slot17, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %ld996 = load i64, ptr %p995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld996, ptr %slot186, align 8
  %v997 = load i64, ptr %slot186, align 8
  %op998 = add i64 %v997, 32
  store i64 %op998, ptr %slot187, align 8
  %v999 = load i64, ptr %slot20, align 8
  store i64 %v999, ptr %slot188, align 8
  %v1000 = load i64, ptr %slot187, align 8
  %v1001 = load i64, ptr %slot188, align 8
  %p1002 = inttoptr i64 %v1000 to ptr
  %p1003 = inttoptr i64 %v1001 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1003, ptr %p1002, i64 208, i1 false), !alias.scope !10000000
  %v1004 = load i64, ptr %slot187, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  call void @llvm.memset.p0.i64(ptr %p1005, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !128
  %v1006 = load i64, ptr %slot8, align 8
  %p1007 = inttoptr i64 %v1006 to ptr
  store i32 1, ptr %p1007, align 4, !alias.scope !3, !noalias !4
  %v1008 = load i64, ptr %slot20, align 8
  %v1009 = load i64, ptr %slot21, align 8
  %p1010 = inttoptr i64 %v1009 to ptr
  store i64 %v1008, ptr %p1010, align 8, !alias.scope !3, !noalias !4
  %v1011 = load i64, ptr %slot21, align 8
  %p1012 = inttoptr i64 %v1011 to ptr
  %ld1013 = load i64, ptr %p1012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1013, ptr %slot189, align 8
  %v1014 = load i64, ptr %slot1, align 8
  %v1015 = load i64, ptr %slot189, align 8
  %call1016 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v1014, i64 %v1015) nomerge, !dbg !130
  store { i64, i64 } %call1016, ptr %callresult191, align 8
  %addr1017 = ptrtoint ptr %callresult191 to i64
  store i64 %addr1017, ptr %slot190, align 8
  %v1018 = load i64, ptr %slot190, align 8
  %v1019 = load i64, ptr %slot21, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  store i64 %v1018, ptr %p1020, align 8, !alias.scope !3, !noalias !4
  %v1021 = load i64, ptr %slot10, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  %ld1023 = load i32, ptr %p1022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1023, ptr %slot192, align 8
  %v1024 = load i32, ptr %slot192, align 8
  %cv1025 = zext i32 %v1024 to i64
  %cond1026 = icmp ne i64 %cv1025, 0
  br i1 %cond1026, label %bb_rcslotdrop307, label %bb_rcslotdone307
bb_rcslotdrop307:
  %v1027 = load i64, ptr %slot10, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  store i32 0, ptr %p1028, align 4, !alias.scope !3, !noalias !4
  %v1029 = load i64, ptr %slot15, align 8
  store i64 %v1029, ptr %slot193, align 8
  %v1030 = load i64, ptr %slot11, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  %ld1032 = load i32, ptr %p1031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1032, ptr %slot194, align 8
  %v1033 = load i32, ptr %slot194, align 8
  %op1034 = and i32 %v1033, 28
  store i32 %op1034, ptr %slot195, align 8
  %v1035 = load i32, ptr %slot195, align 8
  %cv1036 = zext i32 %v1035 to i64
  %cond1037 = icmp ne i64 %cv1036, 0
  br i1 %cond1037, label %bb_rcslotrole307, label %bb_rcslotowner307
bb_rcslotrole307:
  %v1038 = load i64, ptr %slot34, align 8
  store i64 %v1038, ptr %slot196, align 8
  %v1039 = load i64, ptr %slot196, align 8
  %v1040 = load i64, ptr %slot193, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1039, i64 %v1040) nomerge, !dbg !130
  br label %bb_rcslotdone307
bb_rcslotowner307:
  %v1041 = load i64, ptr %slot34, align 8
  store i64 %v1041, ptr %slot197, align 8
  %v1042 = load i64, ptr %slot197, align 8
  %v1043 = load i64, ptr %slot193, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1042, i64 %v1043) nomerge, !dbg !130
  br label %bb_rcslotdone307
bb_rcslotdone307:
  %v1044 = load i64, ptr %slot17, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  %ld1046 = load i64, ptr %p1045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1046, ptr %slot198, align 8
  %v1047 = load i64, ptr %slot198, align 8
  %op1048 = add i64 %v1047, 32
  store i64 %op1048, ptr %slot199, align 8
  %v1049 = load i64, ptr %slot20, align 8
  store i64 %v1049, ptr %slot200, align 8
  %v1050 = load i64, ptr %slot200, align 8
  %v1051 = load i64, ptr %slot199, align 8
  %p1052 = inttoptr i64 %v1050 to ptr
  %p1053 = inttoptr i64 %v1051 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1053, ptr %p1052, i64 208, i1 false), !alias.scope !10000000
  %v1054 = load i64, ptr %slot200, align 8
  %p1055 = inttoptr i64 %v1054 to ptr
  call void @llvm.memset.p0.i64(ptr %p1055, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v1056 = load i64, ptr %slot8, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  store i32 0, ptr %p1057, align 4, !alias.scope !3, !noalias !4
  %v1058 = load i64, ptr %slot21, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  store i64 0, ptr %p1059, align 8, !alias.scope !3, !noalias !4
  %v1060 = load i64, ptr %slot28, align 8
  store i64 %v1060, ptr %slot201, align 8
  %v1061 = load i64, ptr %slot201, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  store i32 0, ptr %p1062, align 4, !alias.scope !3, !noalias !4
  %v1063 = load i64, ptr %slot201, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  store i32 0, ptr %p1064, align 4, !alias.scope !3, !noalias !4
  %v1065 = load i64, ptr %slot201, align 8
  %v1066 = load i64, ptr %slot21, align 8
  %p1067 = inttoptr i64 %v1066 to ptr
  store i64 %v1065, ptr %p1067, align 8, !alias.scope !3, !noalias !4
  %v1068 = load i64, ptr %slot29, align 8
  store i64 %v1068, ptr %slot202, align 8
  %v1069 = load i64, ptr %slot202, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  store i64 0, ptr %p1070, align 8, !alias.scope !3, !noalias !4
  %v1071 = load i64, ptr %slot202, align 8
  %p1073 = inttoptr i64 %v1071 to ptr
  %gep1074 = getelementptr i8, ptr %p1073, i64 8
  %op1072 = ptrtoint ptr %gep1074 to i64
  store i64 %op1072, ptr %slot203, align 8
  %v1075 = load i64, ptr %slot203, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  store i64 0, ptr %p1076, align 8, !alias.scope !3, !noalias !4
  %v1077 = load i64, ptr %slot202, align 8
  %p1079 = inttoptr i64 %v1077 to ptr
  %gep1080 = getelementptr i8, ptr %p1079, i64 16
  %op1078 = ptrtoint ptr %gep1080 to i64
  store i64 %op1078, ptr %slot204, align 8
  %v1081 = load i64, ptr %slot204, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i64 0, ptr %p1082, align 8, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot202, align 8
  %p1084 = inttoptr i64 %v1083 to ptr
  store i32 0, ptr %p1084, align 4, !alias.scope !3, !noalias !4
  %v1085 = load i64, ptr %slot14, align 8
  %p1086 = inttoptr i64 %v1085 to ptr
  store i32 1, ptr %p1086, align 4, !alias.scope !3, !noalias !4
  %v1087 = load i64, ptr %slot21, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  %ld1089 = load i64, ptr %p1088, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1089, ptr %slot205, align 8
  %v1090 = load i64, ptr %slot202, align 8
  %p1092 = inttoptr i64 %v1090 to ptr
  %gep1093 = getelementptr i8, ptr %p1092, i64 8
  %op1091 = ptrtoint ptr %gep1093 to i64
  store i64 %op1091, ptr %slot206, align 8
  %v1094 = load i64, ptr %slot35, align 8
  store i64 %v1094, ptr %slot207, align 8
  %v1095 = load i64, ptr %slot205, align 8
  %v1096 = load i64, ptr %slot206, align 8
  %p1097 = inttoptr i64 %v1095 to ptr
  %p1098 = inttoptr i64 %v1096 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1098, ptr %p1097, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v1099 = load i64, ptr %slot202, align 8
  %v1100 = load i64, ptr %slot21, align 8
  %p1101 = inttoptr i64 %v1100 to ptr
  store i64 %v1099, ptr %p1101, align 8, !alias.scope !3, !noalias !4
  %v1102 = load i64, ptr %slot21, align 8
  %p1103 = inttoptr i64 %v1102 to ptr
  %ld1104 = load i64, ptr %p1103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1104, ptr %slot208, align 8
  %v1105 = load i64, ptr %slot15, align 8
  store i64 %v1105, ptr %slot209, align 8
  %v1106 = load i64, ptr %slot208, align 8
  %v1107 = load i64, ptr %slot209, align 8
  %p1108 = inttoptr i64 %v1106 to ptr
  %p1109 = inttoptr i64 %v1107 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1109, ptr %p1108, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1110 = load i64, ptr %slot11, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  store i32 2, ptr %p1111, align 4, !alias.scope !3, !noalias !4
  %v1112 = load i64, ptr %slot10, align 8
  %p1113 = inttoptr i64 %v1112 to ptr
  store i32 1, ptr %p1113, align 4, !alias.scope !3, !noalias !4
  %v1114 = load i64, ptr %slot209, align 8
  %v1115 = load i64, ptr %slot21, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  store i64 %v1114, ptr %p1116, align 8, !alias.scope !3, !noalias !4
  %v1117 = load i64, ptr %slot21, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %ld1119 = load i64, ptr %p1118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1119, ptr %slot210, align 8
  %v1120 = load i64, ptr %slot21, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  %ld1122 = load i64, ptr %p1121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1122, ptr %slot211, align 8
  %v1123 = load i64, ptr %slot16, align 8
  store i64 %v1123, ptr %slot212, align 8
  %v1124 = load i64, ptr %slot35, align 8
  store i64 %v1124, ptr %slot213, align 8
  %v1125 = load i64, ptr %slot34, align 8
  %v1126 = load i64, ptr %slot212, align 8
  %v1127 = load i64, ptr %slot211, align 8
  %v1128 = load i64, ptr %slot213, align 8
  %cv1129 = trunc i64 %v1128 to i32
  %call1130 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v1125, i64 %v1126, i64 %v1127, i32 %cv1129) nomerge, !dbg !134
  store i32 %call1130, ptr %slot214, align 8
  %v1131 = load i32, ptr %slot214, align 8
  %cv1132 = zext i32 %v1131 to i64
  %cond1133 = icmp ne i64 %cv1132, 0
  br i1 %cond1133, label %bb_rcsuccess336, label %bb_rcfailure336
bb_rcfailure336:
  %v1134 = load i64, ptr %slot34, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  %call1136 = call i32 @myl_rc_take_failure(ptr %p1135) nomerge, !dbg !134
  store i32 %call1136, ptr %slot215, align 8
  %v1137 = load i64, ptr %slot1, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %v1139 = load i32, ptr %slot215, align 8
  %call1140 = call i32 @myl_qbe_rc_status(ptr %p1138, i32 %v1139) nomerge, !dbg !134
  store i32 %call1140, ptr %slot216, align 8
  br label %bb_failure
bb_rcsuccess336:
  %v1141 = load i64, ptr %slot10, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  store i32 0, ptr %p1142, align 4, !alias.scope !3, !noalias !4
  %v1143 = load i64, ptr %slot13, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i32 2, ptr %p1144, align 4, !alias.scope !3, !noalias !4
  %v1145 = load i64, ptr %slot12, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  store i32 1, ptr %p1146, align 4, !alias.scope !3, !noalias !4
  %v1147 = load i64, ptr %slot16, align 8
  store i64 %v1147, ptr %slot217, align 8
  %v1148 = load i64, ptr %slot12, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  store i32 0, ptr %p1149, align 4, !alias.scope !3, !noalias !4
  %v1150 = load i64, ptr %slot10, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i32, ptr %p1151, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1152, ptr %slot218, align 8
  %v1153 = load i32, ptr %slot218, align 8
  %cv1154 = zext i32 %v1153 to i64
  %cond1155 = icmp ne i64 %cv1154, 0
  br i1 %cond1155, label %bb_rcslotdrop346, label %bb_rcslotdone346
bb_rcslotdrop346:
  %v1156 = load i64, ptr %slot10, align 8
  %p1157 = inttoptr i64 %v1156 to ptr
  store i32 0, ptr %p1157, align 4, !alias.scope !3, !noalias !4
  %v1158 = load i64, ptr %slot15, align 8
  store i64 %v1158, ptr %slot219, align 8
  %v1159 = load i64, ptr %slot11, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  %ld1161 = load i32, ptr %p1160, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1161, ptr %slot220, align 8
  %v1162 = load i32, ptr %slot220, align 8
  %op1163 = and i32 %v1162, 28
  store i32 %op1163, ptr %slot221, align 8
  %v1164 = load i32, ptr %slot221, align 8
  %cv1165 = zext i32 %v1164 to i64
  %cond1166 = icmp ne i64 %cv1165, 0
  br i1 %cond1166, label %bb_rcslotrole346, label %bb_rcslotowner346
bb_rcslotrole346:
  %v1167 = load i64, ptr %slot34, align 8
  store i64 %v1167, ptr %slot222, align 8
  %v1168 = load i64, ptr %slot222, align 8
  %v1169 = load i64, ptr %slot219, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1168, i64 %v1169) nomerge, !dbg !134
  br label %bb_rcslotdone346
bb_rcslotowner346:
  %v1170 = load i64, ptr %slot34, align 8
  store i64 %v1170, ptr %slot223, align 8
  %v1171 = load i64, ptr %slot223, align 8
  %v1172 = load i64, ptr %slot219, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1171, i64 %v1172) nomerge, !dbg !134
  br label %bb_rcslotdone346
bb_rcslotdone346:
  %v1173 = load i64, ptr %slot8, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  %ld1175 = load i32, ptr %p1174, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1175, ptr %slot224, align 8
  %v1176 = load i32, ptr %slot224, align 8
  %cv1177 = zext i32 %v1176 to i64
  %cond1178 = icmp ne i64 %cv1177, 0
  br i1 %cond1178, label %bb_rcslotdrop373, label %bb_rcslotdone373
bb_rcslotdrop373:
  %v1179 = load i64, ptr %slot8, align 8
  %p1180 = inttoptr i64 %v1179 to ptr
  store i32 0, ptr %p1180, align 4, !alias.scope !3, !noalias !4
  %v1181 = load i64, ptr %slot20, align 8
  store i64 %v1181, ptr %slot225, align 8
  %v1182 = load i64, ptr %slot9, align 8
  %p1183 = inttoptr i64 %v1182 to ptr
  %ld1184 = load i32, ptr %p1183, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1184, ptr %slot226, align 8
  %v1185 = load i32, ptr %slot226, align 8
  %op1186 = and i32 %v1185, 28
  store i32 %op1186, ptr %slot227, align 8
  %v1187 = load i32, ptr %slot227, align 8
  %cv1188 = zext i32 %v1187 to i64
  %cond1189 = icmp ne i64 %cv1188, 0
  br i1 %cond1189, label %bb_rcslotrole373, label %bb_rcslotowner373
bb_rcslotrole373:
  %v1190 = load i64, ptr %slot34, align 8
  store i64 %v1190, ptr %slot228, align 8
  %v1191 = load i64, ptr %slot228, align 8
  %v1192 = load i64, ptr %slot225, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1191, i64 %v1192) nomerge, !dbg !134
  br label %bb_rcslotdone373
bb_rcslotowner373:
  %v1193 = load i64, ptr %slot34, align 8
  store i64 %v1193, ptr %slot229, align 8
  %v1194 = load i64, ptr %slot229, align 8
  %v1195 = load i64, ptr %slot225, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1194, i64 %v1195) nomerge, !dbg !134
  br label %bb_rcslotdone373
bb_rcslotdone373:
  %v1196 = load i64, ptr %slot6, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  %ld1198 = load i32, ptr %p1197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1198, ptr %slot230, align 8
  %v1199 = load i32, ptr %slot230, align 8
  %cv1200 = zext i32 %v1199 to i64
  %cond1201 = icmp ne i64 %cv1200, 0
  br i1 %cond1201, label %bb_rcslotdrop400, label %bb_rcslotdone400
bb_rcslotdrop400:
  %v1202 = load i64, ptr %slot6, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  store i32 0, ptr %p1203, align 4, !alias.scope !3, !noalias !4
  %v1204 = load i64, ptr %slot19, align 8
  store i64 %v1204, ptr %slot231, align 8
  %v1205 = load i64, ptr %slot7, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  %ld1207 = load i32, ptr %p1206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1207, ptr %slot232, align 8
  %v1208 = load i32, ptr %slot232, align 8
  %op1209 = and i32 %v1208, 28
  store i32 %op1209, ptr %slot233, align 8
  %v1210 = load i32, ptr %slot233, align 8
  %cv1211 = zext i32 %v1210 to i64
  %cond1212 = icmp ne i64 %cv1211, 0
  br i1 %cond1212, label %bb_rcslotrole400, label %bb_rcslotowner400
bb_rcslotrole400:
  %v1213 = load i64, ptr %slot34, align 8
  store i64 %v1213, ptr %slot234, align 8
  %v1214 = load i64, ptr %slot234, align 8
  %v1215 = load i64, ptr %slot231, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1214, i64 %v1215) nomerge, !dbg !134
  br label %bb_rcslotdone400
bb_rcslotowner400:
  %v1216 = load i64, ptr %slot34, align 8
  store i64 %v1216, ptr %slot235, align 8
  %v1217 = load i64, ptr %slot235, align 8
  %v1218 = load i64, ptr %slot231, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1217, i64 %v1218) nomerge, !dbg !134
  br label %bb_rcslotdone400
bb_rcslotdone400:
  %v1219 = load i64, ptr %slot217, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1220, i64 24, i1 false)
  ret void
bb_failure:
  %v1221 = load i64, ptr %slot5, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  call void @llvm.memset.p0.i64(ptr %p1222, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v1223 = load i64, ptr %slot5, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1224, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v1225 = load i64, ptr %slot5, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  call void @llvm.memset.p0.i64(ptr %p1226, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v1227 = load i64, ptr %slot5, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1228, i64 24, i1 false)
  ret void
}

@myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare { i64, i64 } @myl_f_851eb64c403b25f3166dffdb17dfc9e3c924451c20caa5851a74e0f4081ba50f(i64, i64, i64)
declare i64 @myl_f_a931877b11ea3aa7de37854bbbc13e6f0160c87ee24000d47530697609fa185a(i64, i64, i64, i64)
declare void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64, i64)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2", linkageName: "myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11835071567814759241, i64 0, !"myl_f_b52d32a86fcce1fabbd48bba793e10d64e0a86b7fe706d7a156a78000f9bddb2"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!126 = !DILocation(line: 19, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!128 = !DILocation(line: 35, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!130 = !DILocation(line: 39, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!132 = !DILocation(line: 51, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!134 = !DILocation(line: 56, column: 0, scope: !135)
