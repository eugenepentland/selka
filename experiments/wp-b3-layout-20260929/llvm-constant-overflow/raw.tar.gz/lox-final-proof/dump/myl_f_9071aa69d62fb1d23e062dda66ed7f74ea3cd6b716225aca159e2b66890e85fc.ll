target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_9071aa69d62fb1d23e062dda66ed7f74ea3cd6b716225aca159e2b66890e85fc(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %callresult280 = alloca [16 x i8], align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v337 = load i64, ptr %slot1, align 8
  %op338 = add i64 %v337, 32
  store i64 %op338, ptr %slot4, align 8
  %mem339 = alloca i8, i64 24, align 8
  %ptr340 = ptrtoint ptr %mem339 to i64
  store i64 %ptr340, ptr %slot5, align 8
  %mem341 = alloca i8, i64 8, align 8
  %ptr342 = ptrtoint ptr %mem341 to i64
  store i64 %ptr342, ptr %slot6, align 8
  %mem343 = alloca i8, i64 8, align 8
  %ptr344 = ptrtoint ptr %mem343 to i64
  store i64 %ptr344, ptr %slot7, align 8
  %mem345 = alloca i8, i64 8, align 8
  %ptr346 = ptrtoint ptr %mem345 to i64
  store i64 %ptr346, ptr %slot8, align 8
  %mem347 = alloca i8, i64 8, align 8
  %ptr348 = ptrtoint ptr %mem347 to i64
  store i64 %ptr348, ptr %slot9, align 8
  %mem349 = alloca i8, i64 8, align 8
  %ptr350 = ptrtoint ptr %mem349 to i64
  store i64 %ptr350, ptr %slot10, align 8
  %mem351 = alloca i8, i64 8, align 8
  %ptr352 = ptrtoint ptr %mem351 to i64
  store i64 %ptr352, ptr %slot11, align 8
  %mem353 = alloca i8, i64 8, align 8
  %ptr354 = ptrtoint ptr %mem353 to i64
  store i64 %ptr354, ptr %slot12, align 8
  %mem355 = alloca i8, i64 8, align 8
  %ptr356 = ptrtoint ptr %mem355 to i64
  store i64 %ptr356, ptr %slot13, align 8
  %mem357 = alloca i8, i64 8, align 8
  %ptr358 = ptrtoint ptr %mem357 to i64
  store i64 %ptr358, ptr %slot14, align 8
  %mem359 = alloca i8, i64 8, align 8
  %ptr360 = ptrtoint ptr %mem359 to i64
  store i64 %ptr360, ptr %slot15, align 8
  %mem361 = alloca i8, i64 8, align 8
  %ptr362 = ptrtoint ptr %mem361 to i64
  store i64 %ptr362, ptr %slot16, align 8
  %mem363 = alloca i8, i64 8, align 8
  %ptr364 = ptrtoint ptr %mem363 to i64
  store i64 %ptr364, ptr %slot17, align 8
  %mem365 = alloca i8, i64 8, align 8
  %ptr366 = ptrtoint ptr %mem365 to i64
  store i64 %ptr366, ptr %slot18, align 8
  %mem367 = alloca i8, i64 8, align 8
  %ptr368 = ptrtoint ptr %mem367 to i64
  store i64 %ptr368, ptr %slot19, align 8
  %mem369 = alloca i8, i64 8, align 8
  %ptr370 = ptrtoint ptr %mem369 to i64
  store i64 %ptr370, ptr %slot20, align 8
  %mem371 = alloca i8, i64 304, align 8
  %ptr372 = ptrtoint ptr %mem371 to i64
  store i64 %ptr372, ptr %slot21, align 8
  %mem373 = alloca i8, i64 208, align 8
  %ptr374 = ptrtoint ptr %mem373 to i64
  store i64 %ptr374, ptr %slot22, align 8
  %mem375 = alloca i8, i64 304, align 8
  %ptr376 = ptrtoint ptr %mem375 to i64
  store i64 %ptr376, ptr %slot23, align 8
  %mem377 = alloca i8, i64 8, align 8
  %ptr378 = ptrtoint ptr %mem377 to i64
  store i64 %ptr378, ptr %slot24, align 8
  %mem379 = alloca i8, i64 8, align 8
  %ptr380 = ptrtoint ptr %mem379 to i64
  store i64 %ptr380, ptr %slot25, align 8
  %mem381 = alloca i8, i64 8, align 8
  %ptr382 = ptrtoint ptr %mem381 to i64
  store i64 %ptr382, ptr %slot26, align 8
  %mem383 = alloca i8, i64 8, align 8
  %ptr384 = ptrtoint ptr %mem383 to i64
  store i64 %ptr384, ptr %slot27, align 8
  %mem385 = alloca i8, i64 80, align 8
  %ptr386 = ptrtoint ptr %mem385 to i64
  store i64 %ptr386, ptr %slot28, align 8
  %mem387 = alloca i8, i64 208, align 8
  %ptr388 = ptrtoint ptr %mem387 to i64
  store i64 %ptr388, ptr %slot29, align 8
  %mem389 = alloca i8, i64 8, align 8
  %ptr390 = ptrtoint ptr %mem389 to i64
  store i64 %ptr390, ptr %slot30, align 8
  %mem391 = alloca i8, i64 208, align 8
  %ptr392 = ptrtoint ptr %mem391 to i64
  store i64 %ptr392, ptr %slot31, align 8
  %mem393 = alloca i8, i64 208, align 8
  %ptr394 = ptrtoint ptr %mem393 to i64
  store i64 %ptr394, ptr %slot32, align 8
  %mem395 = alloca i8, i64 8, align 8
  %ptr396 = ptrtoint ptr %mem395 to i64
  store i64 %ptr396, ptr %slot33, align 8
  %mem397 = alloca i8, i64 8, align 8
  %ptr398 = ptrtoint ptr %mem397 to i64
  store i64 %ptr398, ptr %slot34, align 8
  %mem399 = alloca i8, i64 8, align 8
  %ptr400 = ptrtoint ptr %mem399 to i64
  store i64 %ptr400, ptr %slot35, align 8
  %mem401 = alloca i8, i64 8, align 8
  %ptr402 = ptrtoint ptr %mem401 to i64
  store i64 %ptr402, ptr %slot36, align 8
  %mem403 = alloca i8, i64 8, align 8
  %ptr404 = ptrtoint ptr %mem403 to i64
  store i64 %ptr404, ptr %slot37, align 8
  %mem405 = alloca i8, i64 304, align 8
  %ptr406 = ptrtoint ptr %mem405 to i64
  store i64 %ptr406, ptr %slot38, align 8
  %mem407 = alloca i8, i64 208, align 8
  %ptr408 = ptrtoint ptr %mem407 to i64
  store i64 %ptr408, ptr %slot39, align 8
  %mem409 = alloca i8, i64 208, align 8
  %ptr410 = ptrtoint ptr %mem409 to i64
  store i64 %ptr410, ptr %slot40, align 8
  %mem411 = alloca i8, i64 208, align 8
  %ptr412 = ptrtoint ptr %mem411 to i64
  store i64 %ptr412, ptr %slot41, align 8
  %mem413 = alloca i8, i64 304, align 8
  %ptr414 = ptrtoint ptr %mem413 to i64
  store i64 %ptr414, ptr %slot42, align 8
  %mem415 = alloca i8, i64 208, align 8
  %ptr416 = ptrtoint ptr %mem415 to i64
  store i64 %ptr416, ptr %slot43, align 8
  %mem417 = alloca i8, i64 304, align 8
  %ptr418 = ptrtoint ptr %mem417 to i64
  store i64 %ptr418, ptr %slot44, align 8
  %mem419 = alloca i8, i64 8, align 8
  %ptr420 = ptrtoint ptr %mem419 to i64
  store i64 %ptr420, ptr %slot45, align 8
  %mem421 = alloca i8, i64 24, align 8
  %ptr422 = ptrtoint ptr %mem421 to i64
  store i64 %ptr422, ptr %slot46, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem423 = alloca i8, i64 8, align 8
  %ptr424 = ptrtoint ptr %mem423 to i64
  store i64 %ptr424, ptr %slot47, align 8
  %v425 = load i64, ptr %slot1, align 8
  %op426 = add i64 %v425, 64
  store i64 %op426, ptr %slot48, align 8
  %v427 = load i64, ptr %slot48, align 8
  %p428 = inttoptr i64 %v427 to ptr
  %ld429 = load i64, ptr %p428, align 8, !alias.scope !4, !noalias !3
  store i64 %ld429, ptr %slot49, align 8
  %stack430 = call ptr @llvm.stacksave()
  %stackaddr431 = ptrtoint ptr %stack430 to i64
  %v432 = load i64, ptr %slot49, align 8
  %cmp433 = icmp ult i64 %stackaddr431, %v432
  %cv434 = zext i1 %cmp433 to i64
  store i64 %cv434, ptr %slot50, align 8
  %v435 = load i64, ptr %slot50, align 8
  %cond436 = icmp ne i64 %v435, 0
  br i1 %cond436, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v437 = load i64, ptr %slot1, align 8
  %p438 = inttoptr i64 %v437 to ptr
  call void @myl_qbe_fail_frame(ptr %p438) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %mem439 = alloca i8, i64 80, align 8
  %ptr440 = ptrtoint ptr %mem439 to i64
  store i64 %ptr440, ptr %slot51, align 8
  %v441 = load i64, ptr %slot26, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i64 0, ptr %p442, align 8, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot2, align 8
  %v444 = load i64, ptr %slot24, align 8
  %p445 = inttoptr i64 %v444 to ptr
  store i64 %v443, ptr %p445, align 8, !alias.scope !3, !noalias !4
  %v446 = load i64, ptr %slot3, align 8
  %v447 = load i64, ptr %slot25, align 8
  %p448 = inttoptr i64 %v447 to ptr
  store i64 %v446, ptr %p448, align 8, !alias.scope !3, !noalias !4
  %v449 = load i64, ptr %slot1, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %call451 = call ptr @myl_qbe_heap(ptr %p450) nomerge, !dbg !112
  %calladdr452 = ptrtoint ptr %call451 to i64
  store i64 %calladdr452, ptr %slot52, align 8
  %v453 = load i64, ptr %slot1, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %call455 = call i64 @myl_qbe_region_mark(ptr %p454) nomerge, !dbg !112
  store i64 %call455, ptr %slot53, align 8
  %v456 = load i64, ptr %slot6, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i32 0, ptr %p457, align 4, !alias.scope !3, !noalias !4
  %v458 = load i64, ptr %slot7, align 8
  %p459 = inttoptr i64 %v458 to ptr
  store i32 0, ptr %p459, align 4, !alias.scope !3, !noalias !4
  %v460 = load i64, ptr %slot8, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i32 0, ptr %p461, align 4, !alias.scope !3, !noalias !4
  %v462 = load i64, ptr %slot9, align 8
  %p463 = inttoptr i64 %v462 to ptr
  store i32 0, ptr %p463, align 4, !alias.scope !3, !noalias !4
  %v464 = load i64, ptr %slot10, align 8
  %p465 = inttoptr i64 %v464 to ptr
  store i32 0, ptr %p465, align 4, !alias.scope !3, !noalias !4
  %v466 = load i64, ptr %slot11, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i32 0, ptr %p467, align 4, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot12, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i32 0, ptr %p469, align 4, !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot13, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 0, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot14, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i32 0, ptr %p473, align 4, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot15, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i32 0, ptr %p475, align 4, !alias.scope !3, !noalias !4
  %v476 = load i64, ptr %slot16, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i32 0, ptr %p477, align 4, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot17, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i32 0, ptr %p479, align 4, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot18, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i32 0, ptr %p481, align 4, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot19, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 0, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot20, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 0, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot7, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 2, ptr %p487, align 4, !alias.scope !3, !noalias !4
  %v488 = load i64, ptr %slot9, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i32 2, ptr %p489, align 4, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot11, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i32 2, ptr %p491, align 4, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot13, align 8
  %p493 = inttoptr i64 %v492 to ptr
  store i32 2, ptr %p493, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v494 = load i64, ptr %slot24, align 8
  %p495 = inttoptr i64 %v494 to ptr
  %ld496 = load i64, ptr %p495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld496, ptr %slot54, align 8
  %v497 = load i64, ptr %slot54, align 8
  %v498 = load i64, ptr %slot33, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i64 %v497, ptr %p499, align 8, !alias.scope !3, !noalias !4
  %v500 = load i64, ptr %slot33, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i64, ptr %p501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld502, ptr %slot55, align 8
  %v503 = load i64, ptr %slot55, align 8
  %op504 = add i64 %v503, 0
  store i64 %op504, ptr %slot56, align 8
  %v505 = load i64, ptr %slot56, align 8
  %v506 = load i64, ptr %slot33, align 8
  %p507 = inttoptr i64 %v506 to ptr
  store i64 %v505, ptr %p507, align 8, !alias.scope !3, !noalias !4
  %v508 = load i64, ptr %slot14, align 8
  %p509 = inttoptr i64 %v508 to ptr
  %ld510 = load i32, ptr %p509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld510, ptr %slot57, align 8
  %v511 = load i32, ptr %slot57, align 8
  %cv512 = zext i32 %v511 to i64
  %cond513 = icmp ne i64 %cv512, 0
  br i1 %cond513, label %bb_rcslotdrop24, label %bb_rcslotdone24
bb_rcslotdrop24:
  %v514 = load i64, ptr %slot14, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i32 0, ptr %p515, align 4, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot21, align 8
  store i64 %v516, ptr %slot58, align 8
  %v517 = load i64, ptr %slot15, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ld519 = load i32, ptr %p518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld519, ptr %slot59, align 8
  %v520 = load i32, ptr %slot59, align 8
  %op521 = and i32 %v520, 28
  store i32 %op521, ptr %slot60, align 8
  %v522 = load i32, ptr %slot60, align 8
  %cv523 = zext i32 %v522 to i64
  %cond524 = icmp ne i64 %cv523, 0
  br i1 %cond524, label %bb_rcslotrole24, label %bb_rcslotowner24
bb_rcslotrole24:
  %v525 = load i64, ptr %slot52, align 8
  store i64 %v525, ptr %slot61, align 8
  %v526 = load i64, ptr %slot61, align 8
  %v527 = load i64, ptr %slot58, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v526, i64 %v527) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotowner24:
  %v528 = load i64, ptr %slot52, align 8
  store i64 %v528, ptr %slot62, align 8
  %v529 = load i64, ptr %slot62, align 8
  %v530 = load i64, ptr %slot58, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v529, i64 %v530) nomerge, !dbg !114
  br label %bb_rcslotdone24
bb_rcslotdone24:
  %v531 = load i64, ptr %slot33, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i64, ptr %p532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld533, ptr %slot63, align 8
  %v534 = load i64, ptr %slot63, align 8
  %op535 = add i64 %v534, 16
  store i64 %op535, ptr %slot64, align 8
  %v536 = load i64, ptr %slot64, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !4, !noalias !3
  store i64 %ld538, ptr %slot65, align 8
  %v539 = load i64, ptr %slot65, align 8
  %v540 = load i64, ptr %slot33, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 %v539, ptr %p541, align 8, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot14, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i32, ptr %p543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld544, ptr %slot66, align 8
  %v545 = load i32, ptr %slot66, align 8
  %cv546 = zext i32 %v545 to i64
  %cond547 = icmp ne i64 %cv546, 0
  br i1 %cond547, label %bb_rcslotdrop36, label %bb_rcslotdone36
bb_rcslotdrop36:
  %v548 = load i64, ptr %slot14, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i32 0, ptr %p549, align 4, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot21, align 8
  store i64 %v550, ptr %slot67, align 8
  %v551 = load i64, ptr %slot15, align 8
  %p552 = inttoptr i64 %v551 to ptr
  %ld553 = load i32, ptr %p552, align 4, !alias.scope !3, !noalias !4
  store i32 %ld553, ptr %slot68, align 8
  %v554 = load i32, ptr %slot68, align 8
  %op555 = and i32 %v554, 28
  store i32 %op555, ptr %slot69, align 8
  %v556 = load i32, ptr %slot69, align 8
  %cv557 = zext i32 %v556 to i64
  %cond558 = icmp ne i64 %cv557, 0
  br i1 %cond558, label %bb_rcslotrole36, label %bb_rcslotowner36
bb_rcslotrole36:
  %v559 = load i64, ptr %slot52, align 8
  store i64 %v559, ptr %slot70, align 8
  %v560 = load i64, ptr %slot70, align 8
  %v561 = load i64, ptr %slot67, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v560, i64 %v561) nomerge, !dbg !116
  br label %bb_rcslotdone36
bb_rcslotowner36:
  %v562 = load i64, ptr %slot52, align 8
  store i64 %v562, ptr %slot71, align 8
  %v563 = load i64, ptr %slot71, align 8
  %v564 = load i64, ptr %slot67, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v563, i64 %v564) nomerge, !dbg !116
  br label %bb_rcslotdone36
bb_rcslotdone36:
  %v565 = load i64, ptr %slot33, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %ld567 = load i64, ptr %p566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld567, ptr %slot72, align 8
  %v568 = load i64, ptr %slot72, align 8
  %v569 = load i64, ptr %slot26, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i64 %v568, ptr %p570, align 8, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot25, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot73, align 8
  %v574 = load i64, ptr %slot73, align 8
  %v575 = load i64, ptr %slot33, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot33, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld579, ptr %slot74, align 8
  %v580 = load i64, ptr %slot74, align 8
  %v581 = load i64, ptr %slot27, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 %v580, ptr %p582, align 8, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot27, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot75, align 8
  %v586 = load i64, ptr %slot75, align 8
  %v587 = load i64, ptr %slot33, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i64 %v586, ptr %p588, align 8, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot34, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i64 0, ptr %p590, align 8, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot34, align 8
  %p592 = inttoptr i64 %v591 to ptr
  %ld593 = load i64, ptr %p592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld593, ptr %slot76, align 8
  %v594 = load i64, ptr %slot33, align 8
  %p595 = inttoptr i64 %v594 to ptr
  %ld596 = load i64, ptr %p595, align 8, !alias.scope !3, !noalias !4
  store i64 %ld596, ptr %slot77, align 8
  %v597 = load i64, ptr %slot77, align 8
  %v598 = load i64, ptr %slot76, align 8
  %cmp599 = icmp slt i64 %v597, %v598
  %cv600 = zext i1 %cmp599 to i64
  store i64 %cv600, ptr %slot78, align 8
  %v601 = load i64, ptr %slot78, align 8
  %v602 = load i64, ptr %slot33, align 8
  %p603 = inttoptr i64 %v602 to ptr
  store i64 %v601, ptr %p603, align 8, !alias.scope !3, !noalias !4
  %v604 = load i64, ptr %slot33, align 8
  %p605 = inttoptr i64 %v604 to ptr
  %ld606 = load i64, ptr %p605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld606, ptr %slot79, align 8
  %v607 = load i64, ptr %slot79, align 8
  %cond608 = icmp ne i64 %v607, 0
  br i1 %cond608, label %bb_next51, label %bb_i15
bb_next51:
  %v609 = load i64, ptr %slot26, align 8
  %p610 = inttoptr i64 %v609 to ptr
  %ld611 = load i64, ptr %p610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld611, ptr %slot80, align 8
  %v612 = load i64, ptr %slot80, align 8
  %op613 = add i64 %v612, 0
  store i64 %op613, ptr %slot81, align 8
  %v614 = load i64, ptr %slot81, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %ld616 = load i64, ptr %p615, align 8, !alias.scope !6, !noalias !7
  store i64 %ld616, ptr %slot82, align 8
  %v617 = load i64, ptr %slot82, align 8
  %v618 = load i64, ptr %slot33, align 8
  %p619 = inttoptr i64 %v618 to ptr
  store i64 %v617, ptr %p619, align 8, !alias.scope !3, !noalias !4
  %v620 = load i64, ptr %slot33, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %ld622 = load i64, ptr %p621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld622, ptr %slot83, align 8
  %v623 = load i64, ptr %slot83, align 8
  %cmp624 = icmp ugt i64 %v623, 9223372036854775807
  %cv625 = zext i1 %cmp624 to i64
  store i64 %cv625, ptr %slot84, align 8
  %v626 = load i64, ptr %slot84, align 8
  %cond627 = icmp ne i64 %v626, 0
  br i1 %cond627, label %bb_cast_overflow56, label %bb_cast_ok56
bb_cast_overflow56:
  %v628 = load i64, ptr %slot1, align 8
  %p629 = inttoptr i64 %v628 to ptr
  %v630 = load i64, ptr %slot83, align 8
  call void @myl_qbe_fail_cast(ptr %p629, i64 %v630, i64 320) nomerge, !dbg !118
  unreachable
bb_cast_ok56:
  %v631 = load i64, ptr %slot83, align 8
  %v632 = load i64, ptr %slot33, align 8
  %p633 = inttoptr i64 %v632 to ptr
  store i64 %v631, ptr %p633, align 8, !alias.scope !3, !noalias !4
  %v634 = load i64, ptr %slot27, align 8
  %p635 = inttoptr i64 %v634 to ptr
  %ld636 = load i64, ptr %p635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld636, ptr %slot85, align 8
  %v637 = load i64, ptr %slot85, align 8
  %v638 = load i64, ptr %slot34, align 8
  %p639 = inttoptr i64 %v638 to ptr
  store i64 %v637, ptr %p639, align 8, !alias.scope !3, !noalias !4
  %v640 = load i64, ptr %slot34, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i64, ptr %p641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld642, ptr %slot86, align 8
  %v643 = load i64, ptr %slot33, align 8
  %p644 = inttoptr i64 %v643 to ptr
  %ld645 = load i64, ptr %p644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld645, ptr %slot87, align 8
  %v646 = load i64, ptr %slot87, align 8
  %v647 = load i64, ptr %slot86, align 8
  %ovpair649 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v646, i64 %v647)
  %op648 = extractvalue { i64, i1 } %ovpair649, 0
  %ov650 = extractvalue { i64, i1 } %ovpair649, 1
  store i64 %op648, ptr %slot88, align 8
  %v651 = load i64, ptr %slot87, align 8
  %v652 = load i64, ptr %slot88, align 8
  %op653 = xor i64 %v651, %v652
  store i64 %op653, ptr %slot89, align 8
  %v654 = load i64, ptr %slot86, align 8
  %v655 = load i64, ptr %slot88, align 8
  %op656 = xor i64 %v654, %v655
  store i64 %op656, ptr %slot90, align 8
  %v657 = load i64, ptr %slot89, align 8
  %v658 = load i64, ptr %slot90, align 8
  %op659 = and i64 %v657, %v658
  store i64 %op659, ptr %slot91, align 8
  %cv660 = zext i1 %ov650 to i64
  store i64 %cv660, ptr %slot92, align 8
  %v661 = load i64, ptr %slot92, align 8
  %cond662 = icmp ne i64 %v661, 0
  br i1 %cond662, label %bb_overflow60, label %bb_checked60
bb_overflow60:
  %v663 = load i64, ptr %slot1, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %v665 = load i64, ptr %slot87, align 8
  %v666 = load i64, ptr %slot86, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p664, i64 0, i64 %v665, i64 %v666, i64 64) nomerge, !dbg !120
  unreachable
bb_checked60:
  %v667 = load i64, ptr %slot88, align 8
  %v668 = load i64, ptr %slot33, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i64 %v667, ptr %p669, align 8, !alias.scope !3, !noalias !4
  %v670 = load i64, ptr %slot33, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i64, ptr %p671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld672, ptr %slot93, align 8
  %v673 = load i64, ptr %slot93, align 8
  %v674 = load i64, ptr %slot27, align 8
  %p675 = inttoptr i64 %v674 to ptr
  store i64 %v673, ptr %p675, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v676 = load i64, ptr %slot27, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %ld678 = load i64, ptr %p677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld678, ptr %slot94, align 8
  %v679 = load i64, ptr %slot94, align 8
  %v680 = load i64, ptr %slot33, align 8
  %p681 = inttoptr i64 %v680 to ptr
  store i64 %v679, ptr %p681, align 8, !alias.scope !3, !noalias !4
  %v682 = load i64, ptr %slot26, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %ld684 = load i64, ptr %p683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld684, ptr %slot95, align 8
  %v685 = load i64, ptr %slot33, align 8
  %p686 = inttoptr i64 %v685 to ptr
  %ld687 = load i64, ptr %p686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld687, ptr %slot96, align 8
  %v688 = load i64, ptr %slot95, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !6, !noalias !7
  store i64 %ld690, ptr %slot97, align 8
  %v691 = load i64, ptr %slot96, align 8
  %v692 = load i64, ptr %slot97, align 8
  %cmp693 = icmp ult i64 %v691, %v692
  %cv694 = zext i1 %cmp693 to i64
  store i64 %cv694, ptr %slot98, align 8
  %v695 = load i64, ptr %slot98, align 8
  %cond696 = icmp ne i64 %v695, 0
  br i1 %cond696, label %bb_success72, label %bb_failed72
bb_failed72:
  %v697 = load i64, ptr %slot1, align 8
  %p698 = inttoptr i64 %v697 to ptr
  %v699 = load i64, ptr %slot96, align 8
  %v700 = load i64, ptr %slot97, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p698, i64 %v699, i64 %v700) nomerge, !dbg !122
  unreachable
bb_success72:
  %v701 = load i64, ptr %slot95, align 8
  %op702 = add i64 %v701, 32
  store i64 %op702, ptr %slot99, align 8
  %v703 = load i64, ptr %slot99, align 8
  %p704 = inttoptr i64 %v703 to ptr
  %ld705 = load i64, ptr %p704, align 8, !alias.scope !6, !noalias !7
  store i64 %ld705, ptr %slot100, align 8
  %v706 = load i64, ptr %slot96, align 8
  %op707 = mul i64 %v706, 80
  store i64 %op707, ptr %slot101, align 8
  %v708 = load i64, ptr %slot100, align 8
  %v709 = load i64, ptr %slot101, align 8
  %op710 = add i64 %v708, %v709
  store i64 %op710, ptr %slot102, align 8
  %v711 = load i64, ptr %slot51, align 8
  store i64 %v711, ptr %slot103, align 8
  %v712 = load i64, ptr %slot102, align 8
  %v713 = load i64, ptr %slot103, align 8
  %p714 = inttoptr i64 %v712 to ptr
  %p715 = inttoptr i64 %v713 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p715, ptr %p714, i64 80, i1 false), !alias.scope !10000000
  %v716 = load i64, ptr %slot103, align 8
  %v717 = load i64, ptr %slot33, align 8
  %p718 = inttoptr i64 %v717 to ptr
  store i64 %v716, ptr %p718, align 8, !alias.scope !3, !noalias !4
  %v719 = load i64, ptr %slot33, align 8
  %p720 = inttoptr i64 %v719 to ptr
  %ld721 = load i64, ptr %p720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld721, ptr %slot104, align 8
  %v722 = load i64, ptr %slot23, align 8
  store i64 %v722, ptr %slot105, align 8
  %v723 = load i64, ptr %slot52, align 8
  %v724 = load i64, ptr %slot105, align 8
  %v725 = load i64, ptr %slot104, align 8
  %call726 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64 %v723, i64 %v724, i64 %v725) nomerge, !dbg !122
  store i32 %call726, ptr %slot106, align 8
  %v727 = load i32, ptr %slot106, align 8
  %cv728 = zext i32 %v727 to i64
  %cond729 = icmp ne i64 %cv728, 0
  br i1 %cond729, label %bb_rcsuccess81, label %bb_rcfailure81
bb_rcfailure81:
  %v730 = load i64, ptr %slot52, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %call732 = call i32 @myl_rc_take_failure(ptr %p731) nomerge, !dbg !122
  store i32 %call732, ptr %slot107, align 8
  %v733 = load i64, ptr %slot1, align 8
  %p734 = inttoptr i64 %v733 to ptr
  %v735 = load i32, ptr %slot107, align 8
  %call736 = call i32 @myl_qbe_rc_status(ptr %p734, i32 %v735) nomerge, !dbg !122
  store i32 %call736, ptr %slot108, align 8
  br label %bb_failure
bb_rcsuccess81:
  %v737 = load i64, ptr %slot19, align 8
  %p738 = inttoptr i64 %v737 to ptr
  store i32 2, ptr %p738, align 4, !alias.scope !3, !noalias !4
  %v739 = load i64, ptr %slot19, align 8
  %p740 = inttoptr i64 %v739 to ptr
  store i32 16, ptr %p740, align 4, !alias.scope !3, !noalias !4
  %v741 = load i64, ptr %slot18, align 8
  %p742 = inttoptr i64 %v741 to ptr
  store i32 1, ptr %p742, align 4, !alias.scope !3, !noalias !4
  %v743 = load i64, ptr %slot21, align 8
  store i64 %v743, ptr %slot109, align 8
  %v744 = load i64, ptr %slot23, align 8
  store i64 %v744, ptr %slot110, align 8
  %v745 = load i64, ptr %slot110, align 8
  %v746 = load i64, ptr %slot109, align 8
  %p747 = inttoptr i64 %v745 to ptr
  %p748 = inttoptr i64 %v746 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p748, ptr %p747, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v749 = load i64, ptr %slot15, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i32 2, ptr %p750, align 4, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot19, align 8
  %p752 = inttoptr i64 %v751 to ptr
  %ld753 = load i32, ptr %p752, align 4, !alias.scope !3, !noalias !4
  store i32 %ld753, ptr %slot111, align 8
  %v754 = load i32, ptr %slot111, align 8
  %v755 = load i64, ptr %slot15, align 8
  %p756 = inttoptr i64 %v755 to ptr
  store i32 %v754, ptr %p756, align 4, !alias.scope !3, !noalias !4
  %v757 = load i64, ptr %slot18, align 8
  %p758 = inttoptr i64 %v757 to ptr
  store i32 0, ptr %p758, align 4, !alias.scope !3, !noalias !4
  %v759 = load i64, ptr %slot14, align 8
  %p760 = inttoptr i64 %v759 to ptr
  store i32 1, ptr %p760, align 4, !alias.scope !3, !noalias !4
  %v761 = load i64, ptr %slot109, align 8
  %v762 = load i64, ptr %slot33, align 8
  %p763 = inttoptr i64 %v762 to ptr
  store i64 %v761, ptr %p763, align 8, !alias.scope !3, !noalias !4
  %v764 = load i64, ptr %slot33, align 8
  %p765 = inttoptr i64 %v764 to ptr
  %ld766 = load i64, ptr %p765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld766, ptr %slot112, align 8
  %v767 = load i64, ptr %slot14, align 8
  %p768 = inttoptr i64 %v767 to ptr
  %ld769 = load i32, ptr %p768, align 4, !alias.scope !3, !noalias !4
  store i32 %ld769, ptr %slot113, align 8
  %v770 = load i64, ptr %slot15, align 8
  %p771 = inttoptr i64 %v770 to ptr
  %ld772 = load i32, ptr %p771, align 4, !alias.scope !3, !noalias !4
  store i32 %ld772, ptr %slot114, align 8
  %v773 = load i32, ptr %slot114, align 8
  %op774 = and i32 %v773, 24
  store i32 %op774, ptr %slot114, align 8
  %v775 = load i32, ptr %slot114, align 8
  %cmp776 = icmp eq i32 %v775, 0
  %cv777 = zext i1 %cmp776 to i32
  store i32 %cv777, ptr %slot115, align 8
  %v778 = load i32, ptr %slot113, align 8
  %v779 = load i32, ptr %slot115, align 8
  %op780 = and i32 %v778, %v779
  store i32 %op780, ptr %slot116, align 8
  %v781 = load i64, ptr %slot53, align 8
  store i64 %v781, ptr %slot117, align 8
  %v782 = load i32, ptr %slot116, align 8
  %op783 = mul i32 %v782, 4
  store i32 %op783, ptr %slot118, align 8
  %v784 = load i32, ptr %slot118, align 8
  %op785 = or i32 %v784, 0
  store i32 %op785, ptr %slot119, align 8
  %v786 = load i64, ptr %slot23, align 8
  store i64 %v786, ptr %slot120, align 8
  %v787 = load i64, ptr %slot52, align 8
  %v788 = load i64, ptr %slot120, align 8
  %v789 = load i64, ptr %slot112, align 8
  %v790 = load i64, ptr %slot117, align 8
  %cv791 = trunc i64 %v790 to i32
  %v792 = load i32, ptr %slot119, align 8
  %call793 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_publish(i64 %v787, i64 %v788, i64 %v789, i32 %cv791, i32 %v792) nomerge, !dbg !124
  store i32 %call793, ptr %slot121, align 8
  %v794 = load i32, ptr %slot121, align 8
  %cv795 = zext i32 %v794 to i64
  %cond796 = icmp ne i64 %cv795, 0
  br i1 %cond796, label %bb_rcsuccess109, label %bb_rcfailure109
bb_rcfailure109:
  %v797 = load i64, ptr %slot52, align 8
  %p798 = inttoptr i64 %v797 to ptr
  %call799 = call i32 @myl_rc_take_failure(ptr %p798) nomerge, !dbg !124
  store i32 %call799, ptr %slot122, align 8
  %v800 = load i64, ptr %slot1, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %v802 = load i32, ptr %slot122, align 8
  %call803 = call i32 @myl_qbe_rc_status(ptr %p801, i32 %v802) nomerge, !dbg !124
  store i32 %call803, ptr %slot123, align 8
  br label %bb_failure
bb_rcsuccess109:
  %v804 = load i32, ptr %slot116, align 8
  %cv805 = zext i32 %v804 to i64
  %cond806 = icmp ne i64 %cv805, 0
  br i1 %cond806, label %bb_rchtaken112, label %bb_rchcopied112
bb_rchcopied112:
  %v807 = load i64, ptr %slot14, align 8
  %p808 = inttoptr i64 %v807 to ptr
  %ld809 = load i32, ptr %p808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld809, ptr %slot124, align 8
  %v810 = load i32, ptr %slot124, align 8
  %cv811 = zext i32 %v810 to i64
  %cond812 = icmp ne i64 %cv811, 0
  br i1 %cond812, label %bb_rcslotdrop115, label %bb_rcslotdone115
bb_rcslotdrop115:
  %v813 = load i64, ptr %slot14, align 8
  %p814 = inttoptr i64 %v813 to ptr
  store i32 0, ptr %p814, align 4, !alias.scope !3, !noalias !4
  %v815 = load i64, ptr %slot21, align 8
  store i64 %v815, ptr %slot125, align 8
  %v816 = load i64, ptr %slot15, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %ld818 = load i32, ptr %p817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld818, ptr %slot126, align 8
  %v819 = load i32, ptr %slot126, align 8
  %op820 = and i32 %v819, 28
  store i32 %op820, ptr %slot127, align 8
  %v821 = load i32, ptr %slot127, align 8
  %cv822 = zext i32 %v821 to i64
  %cond823 = icmp ne i64 %cv822, 0
  br i1 %cond823, label %bb_rcslotrole115, label %bb_rcslotowner115
bb_rcslotrole115:
  %v824 = load i64, ptr %slot52, align 8
  store i64 %v824, ptr %slot128, align 8
  %v825 = load i64, ptr %slot128, align 8
  %v826 = load i64, ptr %slot125, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v825, i64 %v826) nomerge, !dbg !124
  br label %bb_rcslotdone115
bb_rcslotowner115:
  %v827 = load i64, ptr %slot52, align 8
  store i64 %v827, ptr %slot129, align 8
  %v828 = load i64, ptr %slot129, align 8
  %v829 = load i64, ptr %slot125, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v828, i64 %v829) nomerge, !dbg !124
  br label %bb_rcslotdone115
bb_rcslotdone115:
  br label %bb_rchprepared112
bb_rchtaken112:
  %v830 = load i64, ptr %slot14, align 8
  %p831 = inttoptr i64 %v830 to ptr
  store i32 0, ptr %p831, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared112
bb_rchprepared112:
  %v832 = load i64, ptr %slot19, align 8
  %p833 = inttoptr i64 %v832 to ptr
  store i32 2, ptr %p833, align 4, !alias.scope !3, !noalias !4
  %v834 = load i64, ptr %slot18, align 8
  %p835 = inttoptr i64 %v834 to ptr
  store i32 1, ptr %p835, align 4, !alias.scope !3, !noalias !4
  %v836 = load i64, ptr %slot21, align 8
  store i64 %v836, ptr %slot130, align 8
  %v837 = load i64, ptr %slot23, align 8
  store i64 %v837, ptr %slot131, align 8
  %v838 = load i64, ptr %slot131, align 8
  %v839 = load i64, ptr %slot130, align 8
  %p840 = inttoptr i64 %v838 to ptr
  %p841 = inttoptr i64 %v839 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p841, ptr %p840, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v842 = load i64, ptr %slot15, align 8
  %p843 = inttoptr i64 %v842 to ptr
  store i32 2, ptr %p843, align 4, !alias.scope !3, !noalias !4
  %v844 = load i64, ptr %slot19, align 8
  %p845 = inttoptr i64 %v844 to ptr
  %ld846 = load i32, ptr %p845, align 4, !alias.scope !3, !noalias !4
  store i32 %ld846, ptr %slot132, align 8
  %v847 = load i32, ptr %slot132, align 8
  %v848 = load i64, ptr %slot15, align 8
  %p849 = inttoptr i64 %v848 to ptr
  store i32 %v847, ptr %p849, align 4, !alias.scope !3, !noalias !4
  %v850 = load i64, ptr %slot18, align 8
  %p851 = inttoptr i64 %v850 to ptr
  store i32 0, ptr %p851, align 4, !alias.scope !3, !noalias !4
  %v852 = load i64, ptr %slot14, align 8
  %p853 = inttoptr i64 %v852 to ptr
  store i32 1, ptr %p853, align 4, !alias.scope !3, !noalias !4
  %v854 = load i64, ptr %slot130, align 8
  %v855 = load i64, ptr %slot33, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i64 %v854, ptr %p856, align 8, !alias.scope !3, !noalias !4
  %v857 = load i64, ptr %slot33, align 8
  %p858 = inttoptr i64 %v857 to ptr
  %ld859 = load i64, ptr %p858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld859, ptr %slot133, align 8
  %v860 = load i64, ptr %slot23, align 8
  store i64 %v860, ptr %slot134, align 8
  %v861 = load i64, ptr %slot53, align 8
  store i64 %v861, ptr %slot135, align 8
  %v862 = load i64, ptr %slot52, align 8
  %v863 = load i64, ptr %slot134, align 8
  %v864 = load i64, ptr %slot133, align 8
  %v865 = load i64, ptr %slot135, align 8
  %cv866 = trunc i64 %v865 to i32
  %call867 = call i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_take(i64 %v862, i64 %v863, i64 %v864, i32 %cv866) nomerge, !dbg !126
  store i32 %call867, ptr %slot136, align 8
  %v868 = load i32, ptr %slot136, align 8
  %cv869 = zext i32 %v868 to i64
  %cond870 = icmp ne i64 %cv869, 0
  br i1 %cond870, label %bb_rcsuccess137, label %bb_rcfailure137
bb_rcfailure137:
  %v871 = load i64, ptr %slot52, align 8
  %p872 = inttoptr i64 %v871 to ptr
  %call873 = call i32 @myl_rc_take_failure(ptr %p872) nomerge, !dbg !126
  store i32 %call873, ptr %slot137, align 8
  %v874 = load i64, ptr %slot1, align 8
  %p875 = inttoptr i64 %v874 to ptr
  %v876 = load i32, ptr %slot137, align 8
  %call877 = call i32 @myl_qbe_rc_status(ptr %p875, i32 %v876) nomerge, !dbg !126
  store i32 %call877, ptr %slot138, align 8
  br label %bb_failure
bb_rcsuccess137:
  %v878 = load i64, ptr %slot14, align 8
  %p879 = inttoptr i64 %v878 to ptr
  store i32 0, ptr %p879, align 4, !alias.scope !3, !noalias !4
  %v880 = load i64, ptr %slot19, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i32 2, ptr %p881, align 4, !alias.scope !3, !noalias !4
  %v882 = load i64, ptr %slot18, align 8
  %p883 = inttoptr i64 %v882 to ptr
  store i32 1, ptr %p883, align 4, !alias.scope !3, !noalias !4
  %v884 = load i64, ptr %slot6, align 8
  %p885 = inttoptr i64 %v884 to ptr
  %ld886 = load i32, ptr %p885, align 4, !alias.scope !3, !noalias !4
  store i32 %ld886, ptr %slot139, align 8
  %v887 = load i32, ptr %slot139, align 8
  %cv888 = zext i32 %v887 to i64
  %cond889 = icmp ne i64 %cv888, 0
  br i1 %cond889, label %bb_rcslotdrop146, label %bb_rcslotdone146
bb_rcslotdrop146:
  %v890 = load i64, ptr %slot6, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i32 0, ptr %p891, align 4, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot28, align 8
  store i64 %v892, ptr %slot140, align 8
  %v893 = load i64, ptr %slot7, align 8
  %p894 = inttoptr i64 %v893 to ptr
  %ld895 = load i32, ptr %p894, align 4, !alias.scope !3, !noalias !4
  store i32 %ld895, ptr %slot141, align 8
  %v896 = load i32, ptr %slot141, align 8
  %op897 = and i32 %v896, 28
  store i32 %op897, ptr %slot142, align 8
  %v898 = load i32, ptr %slot142, align 8
  %cv899 = zext i32 %v898 to i64
  %cond900 = icmp ne i64 %cv899, 0
  br i1 %cond900, label %bb_rcslotrole146, label %bb_rcslotowner146
bb_rcslotrole146:
  %v901 = load i64, ptr %slot52, align 8
  store i64 %v901, ptr %slot143, align 8
  %v902 = load i64, ptr %slot143, align 8
  %v903 = load i64, ptr %slot140, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v902, i64 %v903) nomerge, !dbg !126
  br label %bb_rcslotdone146
bb_rcslotowner146:
  %v904 = load i64, ptr %slot52, align 8
  store i64 %v904, ptr %slot144, align 8
  %v905 = load i64, ptr %slot144, align 8
  %v906 = load i64, ptr %slot140, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v905, i64 %v906) nomerge, !dbg !126
  br label %bb_rcslotdone146
bb_rcslotdone146:
  %v907 = load i64, ptr %slot28, align 8
  store i64 %v907, ptr %slot145, align 8
  %v908 = load i64, ptr %slot23, align 8
  store i64 %v908, ptr %slot146, align 8
  %v909 = load i64, ptr %slot146, align 8
  %v910 = load i64, ptr %slot145, align 8
  %p911 = inttoptr i64 %v909 to ptr
  %p912 = inttoptr i64 %v910 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p912, ptr %p911, i64 80, i1 false), !alias.scope !3, !noalias !4
  %v913 = load i64, ptr %slot18, align 8
  %p914 = inttoptr i64 %v913 to ptr
  store i32 0, ptr %p914, align 4, !alias.scope !3, !noalias !4
  %v915 = load i64, ptr %slot7, align 8
  %p916 = inttoptr i64 %v915 to ptr
  store i32 2, ptr %p916, align 4, !alias.scope !3, !noalias !4
  %v917 = load i64, ptr %slot19, align 8
  %p918 = inttoptr i64 %v917 to ptr
  %ld919 = load i32, ptr %p918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld919, ptr %slot147, align 8
  %v920 = load i32, ptr %slot147, align 8
  %v921 = load i64, ptr %slot7, align 8
  %p922 = inttoptr i64 %v921 to ptr
  store i32 %v920, ptr %p922, align 4, !alias.scope !3, !noalias !4
  %v923 = load i64, ptr %slot6, align 8
  %p924 = inttoptr i64 %v923 to ptr
  store i32 1, ptr %p924, align 4, !alias.scope !3, !noalias !4
  %v925 = load i64, ptr %slot24, align 8
  %p926 = inttoptr i64 %v925 to ptr
  %ld927 = load i64, ptr %p926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld927, ptr %slot148, align 8
  %v928 = load i64, ptr %slot148, align 8
  %v929 = load i64, ptr %slot38, align 8
  %p930 = inttoptr i64 %v928 to ptr
  %p931 = inttoptr i64 %v929 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p931, ptr %p930, i64 304, i1 false), !alias.scope !10000001
  %v932 = load i64, ptr %slot38, align 8
  %v933 = load i64, ptr %slot33, align 8
  %p934 = inttoptr i64 %v933 to ptr
  store i64 %v932, ptr %p934, align 8, !alias.scope !3, !noalias !4
  %v935 = load i64, ptr %slot33, align 8
  %p936 = inttoptr i64 %v935 to ptr
  %ld937 = load i64, ptr %p936, align 8, !alias.scope !3, !noalias !4
  store i64 %ld937, ptr %slot149, align 8
  %v938 = load i64, ptr %slot149, align 8
  %op939 = add i64 %v938, 32
  store i64 %op939, ptr %slot150, align 8
  %v940 = load i64, ptr %slot150, align 8
  %v941 = load i64, ptr %slot33, align 8
  %p942 = inttoptr i64 %v941 to ptr
  store i64 %v940, ptr %p942, align 8, !alias.scope !3, !noalias !4
  %v943 = load i64, ptr %slot8, align 8
  %p944 = inttoptr i64 %v943 to ptr
  %ld945 = load i32, ptr %p944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld945, ptr %slot151, align 8
  %v946 = load i32, ptr %slot151, align 8
  %cv947 = zext i32 %v946 to i64
  %cond948 = icmp ne i64 %cv947, 0
  br i1 %cond948, label %bb_rcslotdrop165, label %bb_rcslotdone165
bb_rcslotdrop165:
  %v949 = load i64, ptr %slot8, align 8
  %p950 = inttoptr i64 %v949 to ptr
  store i32 0, ptr %p950, align 4, !alias.scope !3, !noalias !4
  %v951 = load i64, ptr %slot29, align 8
  store i64 %v951, ptr %slot152, align 8
  %v952 = load i64, ptr %slot9, align 8
  %p953 = inttoptr i64 %v952 to ptr
  %ld954 = load i32, ptr %p953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld954, ptr %slot153, align 8
  %v955 = load i32, ptr %slot153, align 8
  %op956 = and i32 %v955, 28
  store i32 %op956, ptr %slot154, align 8
  %v957 = load i32, ptr %slot154, align 8
  %cv958 = zext i32 %v957 to i64
  %cond959 = icmp ne i64 %cv958, 0
  br i1 %cond959, label %bb_rcslotrole165, label %bb_rcslotowner165
bb_rcslotrole165:
  %v960 = load i64, ptr %slot52, align 8
  store i64 %v960, ptr %slot155, align 8
  %v961 = load i64, ptr %slot155, align 8
  %v962 = load i64, ptr %slot152, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v961, i64 %v962) nomerge, !dbg !128
  br label %bb_rcslotdone165
bb_rcslotowner165:
  %v963 = load i64, ptr %slot52, align 8
  store i64 %v963, ptr %slot156, align 8
  %v964 = load i64, ptr %slot156, align 8
  %v965 = load i64, ptr %slot152, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v964, i64 %v965) nomerge, !dbg !128
  br label %bb_rcslotdone165
bb_rcslotdone165:
  %v966 = load i64, ptr %slot24, align 8
  %p967 = inttoptr i64 %v966 to ptr
  %ld968 = load i64, ptr %p967, align 8, !alias.scope !3, !noalias !4
  store i64 %ld968, ptr %slot157, align 8
  %v969 = load i64, ptr %slot157, align 8
  %op970 = add i64 %v969, 32
  store i64 %op970, ptr %slot158, align 8
  %v971 = load i64, ptr %slot29, align 8
  store i64 %v971, ptr %slot159, align 8
  %v972 = load i64, ptr %slot158, align 8
  %v973 = load i64, ptr %slot159, align 8
  %p974 = inttoptr i64 %v972 to ptr
  %p975 = inttoptr i64 %v973 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p975, ptr %p974, i64 208, i1 false), !alias.scope !10000001
  %v976 = load i64, ptr %slot158, align 8
  %p977 = inttoptr i64 %v976 to ptr
  call void @llvm.memset.p0.i64(ptr %p977, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !128
  %v978 = load i64, ptr %slot8, align 8
  %p979 = inttoptr i64 %v978 to ptr
  store i32 1, ptr %p979, align 4, !alias.scope !3, !noalias !4
  %v980 = load i64, ptr %slot29, align 8
  %v981 = load i64, ptr %slot33, align 8
  %p982 = inttoptr i64 %v981 to ptr
  store i64 %v980, ptr %p982, align 8, !alias.scope !3, !noalias !4
  %v983 = load i64, ptr %slot25, align 8
  %p984 = inttoptr i64 %v983 to ptr
  %ld985 = load i64, ptr %p984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld985, ptr %slot160, align 8
  %v986 = load i64, ptr %slot160, align 8
  %v987 = load i64, ptr %slot34, align 8
  %p988 = inttoptr i64 %v987 to ptr
  store i64 %v986, ptr %p988, align 8, !alias.scope !3, !noalias !4
  %v989 = load i64, ptr %slot28, align 8
  %v990 = load i64, ptr %slot35, align 8
  %p991 = inttoptr i64 %v990 to ptr
  store i64 %v989, ptr %p991, align 8, !alias.scope !3, !noalias !4
  %v992 = load i64, ptr %slot35, align 8
  %p993 = inttoptr i64 %v992 to ptr
  %ld994 = load i64, ptr %p993, align 8, !alias.scope !3, !noalias !4
  store i64 %ld994, ptr %slot161, align 8
  %v995 = load i64, ptr %slot161, align 8
  %op996 = add i64 %v995, 40
  store i64 %op996, ptr %slot162, align 8
  %v997 = load i64, ptr %slot162, align 8
  %p998 = inttoptr i64 %v997 to ptr
  %ld999 = load i64, ptr %p998, align 8
  store i64 %ld999, ptr %slot163, align 8
  %v1000 = load i64, ptr %slot163, align 8
  %v1001 = load i64, ptr %slot35, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  store i64 %v1000, ptr %p1002, align 8, !alias.scope !3, !noalias !4
  %v1003 = load i64, ptr %slot29, align 8
  %v1004 = load i64, ptr %slot39, align 8
  %p1005 = inttoptr i64 %v1003 to ptr
  %p1006 = inttoptr i64 %v1004 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1006, ptr %p1005, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v1007 = load i64, ptr %slot39, align 8
  %v1008 = load i64, ptr %slot36, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  store i64 %v1007, ptr %p1009, align 8, !alias.scope !3, !noalias !4
  %v1010 = load i64, ptr %slot36, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  %ld1012 = load i64, ptr %p1011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1012, ptr %slot164, align 8
  %v1013 = load i64, ptr %slot164, align 8
  %op1014 = add i64 %v1013, 168
  store i64 %op1014, ptr %slot165, align 8
  %v1015 = load i64, ptr %slot165, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %ld1017 = load i64, ptr %p1016, align 8
  store i64 %ld1017, ptr %slot166, align 8
  %v1018 = load i64, ptr %slot166, align 8
  %v1019 = load i64, ptr %slot36, align 8
  %p1020 = inttoptr i64 %v1019 to ptr
  store i64 %v1018, ptr %p1020, align 8, !alias.scope !3, !noalias !4
  %v1021 = load i64, ptr %slot37, align 8
  %p1022 = inttoptr i64 %v1021 to ptr
  store i64 0, ptr %p1022, align 8, !alias.scope !3, !noalias !4
  %v1023 = load i64, ptr %slot40, align 8
  store i64 %v1023, ptr %slot167, align 8
  %v1024 = load i64, ptr %slot53, align 8
  store i64 %v1024, ptr %slot168, align 8
  %v1025 = load i64, ptr %slot34, align 8
  store i64 %v1025, ptr %slot169, align 8
  %v1026 = load i64, ptr %slot167, align 8
  %p1028 = inttoptr i64 %v1026 to ptr
  %gep1029 = getelementptr i8, ptr %p1028, i64 0
  %op1027 = ptrtoint ptr %gep1029 to i64
  store i64 %op1027, ptr %slot170, align 8
  %v1030 = load i64, ptr %slot169, align 8
  %p1031 = inttoptr i64 %v1030 to ptr
  %ld1032 = load i64, ptr %p1031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1032, ptr %slot171, align 8
  %v1033 = load i64, ptr %slot171, align 8
  %v1034 = load i64, ptr %slot170, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  store i64 %v1033, ptr %p1035, align 8, !alias.scope !3, !noalias !4
  %v1036 = load i64, ptr %slot35, align 8
  store i64 %v1036, ptr %slot172, align 8
  %v1037 = load i64, ptr %slot167, align 8
  %p1039 = inttoptr i64 %v1037 to ptr
  %gep1040 = getelementptr i8, ptr %p1039, i64 8
  %op1038 = ptrtoint ptr %gep1040 to i64
  store i64 %op1038, ptr %slot173, align 8
  %v1041 = load i64, ptr %slot172, align 8
  %p1042 = inttoptr i64 %v1041 to ptr
  %ld1043 = load i64, ptr %p1042, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1043, ptr %slot174, align 8
  %v1044 = load i64, ptr %slot174, align 8
  %v1045 = load i64, ptr %slot173, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  store i64 %v1044, ptr %p1046, align 8, !alias.scope !3, !noalias !4
  %v1047 = load i64, ptr %slot36, align 8
  store i64 %v1047, ptr %slot175, align 8
  %v1048 = load i64, ptr %slot167, align 8
  %p1050 = inttoptr i64 %v1048 to ptr
  %gep1051 = getelementptr i8, ptr %p1050, i64 16
  %op1049 = ptrtoint ptr %gep1051 to i64
  store i64 %op1049, ptr %slot176, align 8
  %v1052 = load i64, ptr %slot175, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  %ld1054 = load i64, ptr %p1053, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1054, ptr %slot177, align 8
  %v1055 = load i64, ptr %slot177, align 8
  %v1056 = load i64, ptr %slot176, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  store i64 %v1055, ptr %p1057, align 8, !alias.scope !3, !noalias !4
  %v1058 = load i64, ptr %slot37, align 8
  store i64 %v1058, ptr %slot178, align 8
  %v1059 = load i64, ptr %slot167, align 8
  %p1061 = inttoptr i64 %v1059 to ptr
  %gep1062 = getelementptr i8, ptr %p1061, i64 24
  %op1060 = ptrtoint ptr %gep1062 to i64
  store i64 %op1060, ptr %slot179, align 8
  %v1063 = load i64, ptr %slot178, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  %ld1065 = load i8, ptr %p1064, align 1, !alias.scope !3, !noalias !4
  %ext1066 = zext i8 %ld1065 to i64
  store i64 %ext1066, ptr %slot180, align 8
  %v1067 = load i64, ptr %slot180, align 8
  %cv1068 = trunc i64 %v1067 to i8
  %v1069 = load i64, ptr %slot179, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  store i8 %cv1068, ptr %p1070, align 1, !alias.scope !3, !noalias !4
  %v1071 = load i64, ptr %slot167, align 8
  %v1072 = load i64, ptr %slot34, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  store i64 %v1071, ptr %p1073, align 8, !alias.scope !3, !noalias !4
  %v1074 = load i64, ptr %slot41, align 8
  store i64 %v1074, ptr %slot181, align 8
  %v1075 = load i64, ptr %slot181, align 8
  %p1076 = inttoptr i64 %v1075 to ptr
  store i64 0, ptr %p1076, align 8, !alias.scope !3, !noalias !4
  %v1077 = load i64, ptr %slot181, align 8
  %p1079 = inttoptr i64 %v1077 to ptr
  %gep1080 = getelementptr i8, ptr %p1079, i64 8
  %op1078 = ptrtoint ptr %gep1080 to i64
  store i64 %op1078, ptr %slot182, align 8
  %v1081 = load i64, ptr %slot182, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  store i64 0, ptr %p1082, align 8, !alias.scope !3, !noalias !4
  %v1083 = load i64, ptr %slot181, align 8
  %p1085 = inttoptr i64 %v1083 to ptr
  %gep1086 = getelementptr i8, ptr %p1085, i64 16
  %op1084 = ptrtoint ptr %gep1086 to i64
  store i64 %op1084, ptr %slot183, align 8
  %v1087 = load i64, ptr %slot183, align 8
  %p1088 = inttoptr i64 %v1087 to ptr
  store i64 0, ptr %p1088, align 8, !alias.scope !3, !noalias !4
  %v1089 = load i64, ptr %slot181, align 8
  %p1091 = inttoptr i64 %v1089 to ptr
  %gep1092 = getelementptr i8, ptr %p1091, i64 24
  %op1090 = ptrtoint ptr %gep1092 to i64
  store i64 %op1090, ptr %slot184, align 8
  %v1093 = load i64, ptr %slot184, align 8
  %p1094 = inttoptr i64 %v1093 to ptr
  store i64 0, ptr %p1094, align 8, !alias.scope !3, !noalias !4
  %v1095 = load i64, ptr %slot181, align 8
  %p1097 = inttoptr i64 %v1095 to ptr
  %gep1098 = getelementptr i8, ptr %p1097, i64 32
  %op1096 = ptrtoint ptr %gep1098 to i64
  store i64 %op1096, ptr %slot185, align 8
  %v1099 = load i64, ptr %slot185, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  store i64 0, ptr %p1100, align 8, !alias.scope !3, !noalias !4
  %v1101 = load i64, ptr %slot181, align 8
  %p1103 = inttoptr i64 %v1101 to ptr
  %gep1104 = getelementptr i8, ptr %p1103, i64 40
  %op1102 = ptrtoint ptr %gep1104 to i64
  store i64 %op1102, ptr %slot186, align 8
  %v1105 = load i64, ptr %slot186, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  store i64 0, ptr %p1106, align 8, !alias.scope !3, !noalias !4
  %v1107 = load i64, ptr %slot181, align 8
  %p1109 = inttoptr i64 %v1107 to ptr
  %gep1110 = getelementptr i8, ptr %p1109, i64 48
  %op1108 = ptrtoint ptr %gep1110 to i64
  store i64 %op1108, ptr %slot187, align 8
  %v1111 = load i64, ptr %slot187, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i64 0, ptr %p1112, align 8, !alias.scope !3, !noalias !4
  %v1113 = load i64, ptr %slot181, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  store i32 10, ptr %p1114, align 4, !alias.scope !3, !noalias !4
  %v1115 = load i64, ptr %slot20, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  store i32 1, ptr %p1116, align 4, !alias.scope !3, !noalias !4
  %v1117 = load i64, ptr %slot34, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  %ld1119 = load i64, ptr %p1118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1119, ptr %slot188, align 8
  %v1120 = load i64, ptr %slot181, align 8
  %p1122 = inttoptr i64 %v1120 to ptr
  %gep1123 = getelementptr i8, ptr %p1122, i64 8
  %op1121 = ptrtoint ptr %gep1123 to i64
  store i64 %op1121, ptr %slot189, align 8
  %v1124 = load i64, ptr %slot53, align 8
  store i64 %v1124, ptr %slot190, align 8
  %v1125 = load i64, ptr %slot188, align 8
  %v1126 = load i64, ptr %slot189, align 8
  %p1127 = inttoptr i64 %v1125 to ptr
  %p1128 = inttoptr i64 %v1126 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1128, ptr %p1127, i64 32, i1 false)
  %v1129 = load i64, ptr %slot181, align 8
  %v1130 = load i64, ptr %slot34, align 8
  %p1131 = inttoptr i64 %v1130 to ptr
  store i64 %v1129, ptr %p1131, align 8, !alias.scope !3, !noalias !4
  %v1132 = load i64, ptr %slot34, align 8
  %p1133 = inttoptr i64 %v1132 to ptr
  %ld1134 = load i64, ptr %p1133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1134, ptr %slot191, align 8
  %v1135 = load i64, ptr %slot22, align 8
  store i64 %v1135, ptr %slot192, align 8
  %v1136 = load i64, ptr %slot191, align 8
  %v1137 = load i64, ptr %slot192, align 8
  %p1138 = inttoptr i64 %v1136 to ptr
  %p1139 = inttoptr i64 %v1137 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1139, ptr %p1138, i64 56, i1 false)
  %v1140 = load i64, ptr %slot17, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i32 2, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot16, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  store i32 1, ptr %p1143, align 4, !alias.scope !3, !noalias !4
  %v1144 = load i64, ptr %slot192, align 8
  %v1145 = load i64, ptr %slot34, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  store i64 %v1144, ptr %p1146, align 8, !alias.scope !3, !noalias !4
  %v1147 = load i64, ptr %slot33, align 8
  %p1148 = inttoptr i64 %v1147 to ptr
  %ld1149 = load i64, ptr %p1148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1149, ptr %slot193, align 8
  %v1150 = load i64, ptr %slot34, align 8
  %p1151 = inttoptr i64 %v1150 to ptr
  %ld1152 = load i64, ptr %p1151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1152, ptr %slot194, align 8
  %v1153 = load i64, ptr %slot1, align 8
  %v1154 = load i64, ptr %slot193, align 8
  %v1155 = load i64, ptr %slot194, align 8
  %call1156 = call i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64 %v1153, i64 %v1154, i64 %v1155) nomerge, !dbg !130
  store i64 %call1156, ptr %slot195, align 8
  %v1157 = load i64, ptr %slot195, align 8
  %v1158 = load i64, ptr %slot33, align 8
  %p1159 = inttoptr i64 %v1158 to ptr
  store i64 %v1157, ptr %p1159, align 8, !alias.scope !3, !noalias !4
  %v1160 = load i64, ptr %slot14, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  %ld1162 = load i32, ptr %p1161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1162, ptr %slot196, align 8
  %v1163 = load i32, ptr %slot196, align 8
  %cv1164 = zext i32 %v1163 to i64
  %cond1165 = icmp ne i64 %cv1164, 0
  br i1 %cond1165, label %bb_rcslotdrop236, label %bb_rcslotdone236
bb_rcslotdrop236:
  %v1166 = load i64, ptr %slot14, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  store i32 0, ptr %p1167, align 4, !alias.scope !3, !noalias !4
  %v1168 = load i64, ptr %slot21, align 8
  store i64 %v1168, ptr %slot197, align 8
  %v1169 = load i64, ptr %slot15, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  %ld1171 = load i32, ptr %p1170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1171, ptr %slot198, align 8
  %v1172 = load i32, ptr %slot198, align 8
  %op1173 = and i32 %v1172, 28
  store i32 %op1173, ptr %slot199, align 8
  %v1174 = load i32, ptr %slot199, align 8
  %cv1175 = zext i32 %v1174 to i64
  %cond1176 = icmp ne i64 %cv1175, 0
  br i1 %cond1176, label %bb_rcslotrole236, label %bb_rcslotowner236
bb_rcslotrole236:
  %v1177 = load i64, ptr %slot52, align 8
  store i64 %v1177, ptr %slot200, align 8
  %v1178 = load i64, ptr %slot200, align 8
  %v1179 = load i64, ptr %slot197, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1178, i64 %v1179) nomerge, !dbg !130
  br label %bb_rcslotdone236
bb_rcslotowner236:
  %v1180 = load i64, ptr %slot52, align 8
  store i64 %v1180, ptr %slot201, align 8
  %v1181 = load i64, ptr %slot201, align 8
  %v1182 = load i64, ptr %slot197, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1181, i64 %v1182) nomerge, !dbg !130
  br label %bb_rcslotdone236
bb_rcslotdone236:
  %v1183 = load i64, ptr %slot16, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %ld1185 = load i32, ptr %p1184, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1185, ptr %slot202, align 8
  %v1186 = load i32, ptr %slot202, align 8
  %cv1187 = zext i32 %v1186 to i64
  %cond1188 = icmp ne i64 %cv1187, 0
  br i1 %cond1188, label %bb_rcslotdrop245, label %bb_rcslotdone245
bb_rcslotdrop245:
  %v1189 = load i64, ptr %slot16, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  store i32 0, ptr %p1190, align 4, !alias.scope !3, !noalias !4
  %v1191 = load i64, ptr %slot22, align 8
  store i64 %v1191, ptr %slot203, align 8
  %v1192 = load i64, ptr %slot17, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  %ld1194 = load i32, ptr %p1193, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1194, ptr %slot204, align 8
  %v1195 = load i32, ptr %slot204, align 8
  %op1196 = and i32 %v1195, 28
  store i32 %op1196, ptr %slot205, align 8
  %v1197 = load i32, ptr %slot205, align 8
  %cv1198 = zext i32 %v1197 to i64
  %cond1199 = icmp ne i64 %cv1198, 0
  br i1 %cond1199, label %bb_rcslotrole245, label %bb_rcslotowner245
bb_rcslotrole245:
  %v1200 = load i64, ptr %slot52, align 8
  store i64 %v1200, ptr %slot206, align 8
  %v1201 = load i64, ptr %slot206, align 8
  %v1202 = load i64, ptr %slot203, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1201, i64 %v1202) nomerge, !dbg !130
  br label %bb_rcslotdone245
bb_rcslotowner245:
  %v1203 = load i64, ptr %slot52, align 8
  store i64 %v1203, ptr %slot207, align 8
  %v1204 = load i64, ptr %slot207, align 8
  %v1205 = load i64, ptr %slot203, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1204, i64 %v1205) nomerge, !dbg !130
  br label %bb_rcslotdone245
bb_rcslotdone245:
  %v1206 = load i64, ptr %slot33, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  %ld1208 = load i64, ptr %p1207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1208, ptr %slot208, align 8
  %v1209 = load i64, ptr %slot208, align 8
  %v1210 = load i64, ptr %slot30, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i64 %v1209, ptr %p1211, align 8, !alias.scope !3, !noalias !4
  %v1212 = load i64, ptr %slot24, align 8
  %p1213 = inttoptr i64 %v1212 to ptr
  %ld1214 = load i64, ptr %p1213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1214, ptr %slot209, align 8
  %v1215 = load i64, ptr %slot209, align 8
  %op1216 = add i64 %v1215, 32
  store i64 %op1216, ptr %slot210, align 8
  %v1217 = load i64, ptr %slot29, align 8
  store i64 %v1217, ptr %slot211, align 8
  %v1218 = load i64, ptr %slot211, align 8
  %v1219 = load i64, ptr %slot210, align 8
  %p1220 = inttoptr i64 %v1218 to ptr
  %p1221 = inttoptr i64 %v1219 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1221, ptr %p1220, i64 208, i1 false), !alias.scope !10000001
  %v1222 = load i64, ptr %slot211, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  call void @llvm.memset.p0.i64(ptr %p1223, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v1224 = load i64, ptr %slot8, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  store i32 0, ptr %p1225, align 4, !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot33, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  store i64 0, ptr %p1227, align 8, !alias.scope !3, !noalias !4
  %v1228 = load i64, ptr %slot24, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  %ld1230 = load i64, ptr %p1229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1230, ptr %slot212, align 8
  %v1231 = load i64, ptr %slot212, align 8
  %v1232 = load i64, ptr %slot42, align 8
  %p1233 = inttoptr i64 %v1231 to ptr
  %p1234 = inttoptr i64 %v1232 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1234, ptr %p1233, i64 304, i1 false), !alias.scope !10000001
  %v1235 = load i64, ptr %slot42, align 8
  %v1236 = load i64, ptr %slot33, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i64 %v1235, ptr %p1237, align 8, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot33, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  %ld1240 = load i64, ptr %p1239, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1240, ptr %slot213, align 8
  %v1241 = load i64, ptr %slot213, align 8
  %op1242 = add i64 %v1241, 32
  store i64 %op1242, ptr %slot214, align 8
  %v1243 = load i64, ptr %slot214, align 8
  %v1244 = load i64, ptr %slot33, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  store i64 %v1243, ptr %p1245, align 8, !alias.scope !3, !noalias !4
  %v1246 = load i64, ptr %slot10, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  %ld1248 = load i32, ptr %p1247, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1248, ptr %slot215, align 8
  %v1249 = load i32, ptr %slot215, align 8
  %cv1250 = zext i32 %v1249 to i64
  %cond1251 = icmp ne i64 %cv1250, 0
  br i1 %cond1251, label %bb_rcslotdrop262, label %bb_rcslotdone262
bb_rcslotdrop262:
  %v1252 = load i64, ptr %slot10, align 8
  %p1253 = inttoptr i64 %v1252 to ptr
  store i32 0, ptr %p1253, align 4, !alias.scope !3, !noalias !4
  %v1254 = load i64, ptr %slot31, align 8
  store i64 %v1254, ptr %slot216, align 8
  %v1255 = load i64, ptr %slot11, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  %ld1257 = load i32, ptr %p1256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1257, ptr %slot217, align 8
  %v1258 = load i32, ptr %slot217, align 8
  %op1259 = and i32 %v1258, 28
  store i32 %op1259, ptr %slot218, align 8
  %v1260 = load i32, ptr %slot218, align 8
  %cv1261 = zext i32 %v1260 to i64
  %cond1262 = icmp ne i64 %cv1261, 0
  br i1 %cond1262, label %bb_rcslotrole262, label %bb_rcslotowner262
bb_rcslotrole262:
  %v1263 = load i64, ptr %slot52, align 8
  store i64 %v1263, ptr %slot219, align 8
  %v1264 = load i64, ptr %slot219, align 8
  %v1265 = load i64, ptr %slot216, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1264, i64 %v1265) nomerge, !dbg !134
  br label %bb_rcslotdone262
bb_rcslotowner262:
  %v1266 = load i64, ptr %slot52, align 8
  store i64 %v1266, ptr %slot220, align 8
  %v1267 = load i64, ptr %slot220, align 8
  %v1268 = load i64, ptr %slot216, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1267, i64 %v1268) nomerge, !dbg !134
  br label %bb_rcslotdone262
bb_rcslotdone262:
  %v1269 = load i64, ptr %slot24, align 8
  %p1270 = inttoptr i64 %v1269 to ptr
  %ld1271 = load i64, ptr %p1270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1271, ptr %slot221, align 8
  %v1272 = load i64, ptr %slot221, align 8
  %op1273 = add i64 %v1272, 32
  store i64 %op1273, ptr %slot222, align 8
  %v1274 = load i64, ptr %slot31, align 8
  store i64 %v1274, ptr %slot223, align 8
  %v1275 = load i64, ptr %slot222, align 8
  %v1276 = load i64, ptr %slot223, align 8
  %p1277 = inttoptr i64 %v1275 to ptr
  %p1278 = inttoptr i64 %v1276 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1278, ptr %p1277, i64 208, i1 false), !alias.scope !10000001
  %v1279 = load i64, ptr %slot222, align 8
  %p1280 = inttoptr i64 %v1279 to ptr
  call void @llvm.memset.p0.i64(ptr %p1280, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !134
  %v1281 = load i64, ptr %slot10, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i32 1, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot31, align 8
  %v1284 = load i64, ptr %slot33, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  store i64 %v1283, ptr %p1285, align 8, !alias.scope !3, !noalias !4
  %v1286 = load i64, ptr %slot30, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  %ld1288 = load i64, ptr %p1287, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1288, ptr %slot224, align 8
  %v1289 = load i64, ptr %slot224, align 8
  %v1290 = load i64, ptr %slot34, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  store i64 %v1289, ptr %p1291, align 8, !alias.scope !3, !noalias !4
  %v1292 = load i64, ptr %slot43, align 8
  store i64 %v1292, ptr %slot225, align 8
  %v1293 = load i64, ptr %slot225, align 8
  %p1294 = inttoptr i64 %v1293 to ptr
  store i64 0, ptr %p1294, align 8, !alias.scope !3, !noalias !4
  %v1295 = load i64, ptr %slot225, align 8
  %p1297 = inttoptr i64 %v1295 to ptr
  %gep1298 = getelementptr i8, ptr %p1297, i64 8
  %op1296 = ptrtoint ptr %gep1298 to i64
  store i64 %op1296, ptr %slot226, align 8
  %v1299 = load i64, ptr %slot226, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  store i64 0, ptr %p1300, align 8, !alias.scope !3, !noalias !4
  %v1301 = load i64, ptr %slot225, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  store i32 3, ptr %p1302, align 4, !alias.scope !3, !noalias !4
  %v1303 = load i64, ptr %slot20, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  store i32 1, ptr %p1304, align 4, !alias.scope !3, !noalias !4
  %v1305 = load i64, ptr %slot34, align 8
  store i64 %v1305, ptr %slot227, align 8
  %v1306 = load i64, ptr %slot225, align 8
  %p1308 = inttoptr i64 %v1306 to ptr
  %gep1309 = getelementptr i8, ptr %p1308, i64 8
  %op1307 = ptrtoint ptr %gep1309 to i64
  store i64 %op1307, ptr %slot228, align 8
  %v1310 = load i64, ptr %slot53, align 8
  store i64 %v1310, ptr %slot229, align 8
  %v1311 = load i64, ptr %slot227, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  %ld1313 = load i64, ptr %p1312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1313, ptr %slot230, align 8
  %v1314 = load i64, ptr %slot230, align 8
  %v1315 = load i64, ptr %slot228, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  store i64 %v1314, ptr %p1316, align 8, !alias.scope !3, !noalias !4
  %v1317 = load i64, ptr %slot225, align 8
  %v1318 = load i64, ptr %slot34, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i64 %v1317, ptr %p1319, align 8, !alias.scope !3, !noalias !4
  %v1320 = load i64, ptr %slot33, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  %ld1322 = load i64, ptr %p1321, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1322, ptr %slot231, align 8
  %v1323 = load i64, ptr %slot34, align 8
  %p1324 = inttoptr i64 %v1323 to ptr
  %ld1325 = load i64, ptr %p1324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1325, ptr %slot232, align 8
  %v1326 = load i64, ptr %slot1, align 8
  %v1327 = load i64, ptr %slot231, align 8
  %v1328 = load i64, ptr %slot232, align 8
  %call1329 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v1326, i64 %v1327, i64 %v1328) nomerge, !dbg !136
  store i64 %call1329, ptr %slot233, align 8
  %v1330 = load i64, ptr %slot233, align 8
  %v1331 = load i64, ptr %slot33, align 8
  %p1332 = inttoptr i64 %v1331 to ptr
  store i64 %v1330, ptr %p1332, align 8, !alias.scope !3, !noalias !4
  %v1333 = load i64, ptr %slot14, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  %ld1335 = load i32, ptr %p1334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1335, ptr %slot234, align 8
  %v1336 = load i32, ptr %slot234, align 8
  %cv1337 = zext i32 %v1336 to i64
  %cond1338 = icmp ne i64 %cv1337, 0
  br i1 %cond1338, label %bb_rcslotdrop287, label %bb_rcslotdone287
bb_rcslotdrop287:
  %v1339 = load i64, ptr %slot14, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  store i32 0, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot21, align 8
  store i64 %v1341, ptr %slot235, align 8
  %v1342 = load i64, ptr %slot15, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %ld1344 = load i32, ptr %p1343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1344, ptr %slot236, align 8
  %v1345 = load i32, ptr %slot236, align 8
  %op1346 = and i32 %v1345, 28
  store i32 %op1346, ptr %slot237, align 8
  %v1347 = load i32, ptr %slot237, align 8
  %cv1348 = zext i32 %v1347 to i64
  %cond1349 = icmp ne i64 %cv1348, 0
  br i1 %cond1349, label %bb_rcslotrole287, label %bb_rcslotowner287
bb_rcslotrole287:
  %v1350 = load i64, ptr %slot52, align 8
  store i64 %v1350, ptr %slot238, align 8
  %v1351 = load i64, ptr %slot238, align 8
  %v1352 = load i64, ptr %slot235, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1351, i64 %v1352) nomerge, !dbg !136
  br label %bb_rcslotdone287
bb_rcslotowner287:
  %v1353 = load i64, ptr %slot52, align 8
  store i64 %v1353, ptr %slot239, align 8
  %v1354 = load i64, ptr %slot239, align 8
  %v1355 = load i64, ptr %slot235, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1354, i64 %v1355) nomerge, !dbg !136
  br label %bb_rcslotdone287
bb_rcslotdone287:
  %v1356 = load i64, ptr %slot24, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  %ld1358 = load i64, ptr %p1357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1358, ptr %slot240, align 8
  %v1359 = load i64, ptr %slot240, align 8
  %op1360 = add i64 %v1359, 32
  store i64 %op1360, ptr %slot241, align 8
  %v1361 = load i64, ptr %slot31, align 8
  store i64 %v1361, ptr %slot242, align 8
  %v1362 = load i64, ptr %slot242, align 8
  %v1363 = load i64, ptr %slot241, align 8
  %p1364 = inttoptr i64 %v1362 to ptr
  %p1365 = inttoptr i64 %v1363 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1365, ptr %p1364, i64 208, i1 false), !alias.scope !10000001
  %v1366 = load i64, ptr %slot242, align 8
  %p1367 = inttoptr i64 %v1366 to ptr
  call void @llvm.memset.p0.i64(ptr %p1367, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !138
  %v1368 = load i64, ptr %slot10, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  store i32 0, ptr %p1369, align 4, !alias.scope !3, !noalias !4
  %v1370 = load i64, ptr %slot33, align 8
  %p1371 = inttoptr i64 %v1370 to ptr
  store i64 0, ptr %p1371, align 8, !alias.scope !3, !noalias !4
  %v1372 = load i64, ptr %slot24, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  %ld1374 = load i64, ptr %p1373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1374, ptr %slot243, align 8
  %v1375 = load i64, ptr %slot243, align 8
  %v1376 = load i64, ptr %slot33, align 8
  %p1377 = inttoptr i64 %v1376 to ptr
  store i64 %v1375, ptr %p1377, align 8, !alias.scope !3, !noalias !4
  %v1378 = load i64, ptr %slot28, align 8
  %v1379 = load i64, ptr %slot34, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  store i64 %v1378, ptr %p1380, align 8, !alias.scope !3, !noalias !4
  %v1381 = load i64, ptr %slot34, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  %ld1383 = load i64, ptr %p1382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1383, ptr %slot244, align 8
  %v1384 = load i64, ptr %slot244, align 8
  %op1385 = add i64 %v1384, 40
  store i64 %op1385, ptr %slot245, align 8
  %v1386 = load i64, ptr %slot245, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  %ld1388 = load i64, ptr %p1387, align 8
  store i64 %ld1388, ptr %slot246, align 8
  %v1389 = load i64, ptr %slot246, align 8
  %v1390 = load i64, ptr %slot34, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  store i64 %v1389, ptr %p1391, align 8, !alias.scope !3, !noalias !4
  %v1392 = load i64, ptr %slot16, align 8
  %p1393 = inttoptr i64 %v1392 to ptr
  %ld1394 = load i32, ptr %p1393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1394, ptr %slot247, align 8
  %v1395 = load i32, ptr %slot247, align 8
  %cv1396 = zext i32 %v1395 to i64
  %cond1397 = icmp ne i64 %cv1396, 0
  br i1 %cond1397, label %bb_rcslotdrop304, label %bb_rcslotdone304
bb_rcslotdrop304:
  %v1398 = load i64, ptr %slot16, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  store i32 0, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  %v1400 = load i64, ptr %slot22, align 8
  store i64 %v1400, ptr %slot248, align 8
  %v1401 = load i64, ptr %slot17, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  %ld1403 = load i32, ptr %p1402, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1403, ptr %slot249, align 8
  %v1404 = load i32, ptr %slot249, align 8
  %op1405 = and i32 %v1404, 28
  store i32 %op1405, ptr %slot250, align 8
  %v1406 = load i32, ptr %slot250, align 8
  %cv1407 = zext i32 %v1406 to i64
  %cond1408 = icmp ne i64 %cv1407, 0
  br i1 %cond1408, label %bb_rcslotrole304, label %bb_rcslotowner304
bb_rcslotrole304:
  %v1409 = load i64, ptr %slot52, align 8
  store i64 %v1409, ptr %slot251, align 8
  %v1410 = load i64, ptr %slot251, align 8
  %v1411 = load i64, ptr %slot248, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v1410, i64 %v1411) nomerge, !dbg !140
  br label %bb_rcslotdone304
bb_rcslotowner304:
  %v1412 = load i64, ptr %slot52, align 8
  store i64 %v1412, ptr %slot252, align 8
  %v1413 = load i64, ptr %slot252, align 8
  %v1414 = load i64, ptr %slot248, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v1413, i64 %v1414) nomerge, !dbg !140
  br label %bb_rcslotdone304
bb_rcslotdone304:
  %v1415 = load i64, ptr %slot28, align 8
  %v1416 = load i64, ptr %slot35, align 8
  %p1417 = inttoptr i64 %v1416 to ptr
  store i64 %v1415, ptr %p1417, align 8, !alias.scope !3, !noalias !4
  %v1418 = load i64, ptr %slot35, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  %ld1420 = load i64, ptr %p1419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1420, ptr %slot253, align 8
  %v1421 = load i64, ptr %slot253, align 8
  %op1422 = add i64 %v1421, 64
  store i64 %op1422, ptr %slot254, align 8
  %v1423 = load i64, ptr %slot254, align 8
  %p1424 = inttoptr i64 %v1423 to ptr
  %ld1425 = load i64, ptr %p1424, align 8
  store i64 %ld1425, ptr %slot255, align 8
  %v1426 = load i64, ptr %slot255, align 8
  %v1427 = load i64, ptr %slot35, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i64 %v1426, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot33, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot256, align 8
  %v1432 = load i64, ptr %slot34, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  %ld1434 = load i64, ptr %p1433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1434, ptr %slot257, align 8
  %v1435 = load i64, ptr %slot35, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  %ld1437 = load i64, ptr %p1436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1437, ptr %slot258, align 8
  %v1438 = load i64, ptr %slot1, align 8
  %v1439 = load i64, ptr %slot256, align 8
  %v1440 = load i64, ptr %slot257, align 8
  %v1441 = load i64, ptr %slot258, align 8
  %call1442 = call i64 @myl_f_bd9e3a524ab3cf6b1d10f9f010a9809523e9baa589e1d9e95734ec89624acb99(i64 %v1438, i64 %v1439, i64 %v1440, i64 %v1441) nomerge, !dbg !142
  store i64 %call1442, ptr %slot259, align 8
  %v1443 = load i64, ptr %slot259, align 8
  %v1444 = load i64, ptr %slot33, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i64 %v1443, ptr %p1445, align 8, !alias.scope !3, !noalias !4
  %v1446 = load i64, ptr %slot14, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  %ld1448 = load i32, ptr %p1447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1448, ptr %slot260, align 8
  %v1449 = load i32, ptr %slot260, align 8
  %cv1450 = zext i32 %v1449 to i64
  %cond1451 = icmp ne i64 %cv1450, 0
  br i1 %cond1451, label %bb_rcslotdrop329, label %bb_rcslotdone329
bb_rcslotdrop329:
  %v1452 = load i64, ptr %slot14, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  store i32 0, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  %v1454 = load i64, ptr %slot21, align 8
  store i64 %v1454, ptr %slot261, align 8
  %v1455 = load i64, ptr %slot15, align 8
  %p1456 = inttoptr i64 %v1455 to ptr
  %ld1457 = load i32, ptr %p1456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1457, ptr %slot262, align 8
  %v1458 = load i32, ptr %slot262, align 8
  %op1459 = and i32 %v1458, 28
  store i32 %op1459, ptr %slot263, align 8
  %v1460 = load i32, ptr %slot263, align 8
  %cv1461 = zext i32 %v1460 to i64
  %cond1462 = icmp ne i64 %cv1461, 0
  br i1 %cond1462, label %bb_rcslotrole329, label %bb_rcslotowner329
bb_rcslotrole329:
  %v1463 = load i64, ptr %slot52, align 8
  store i64 %v1463, ptr %slot264, align 8
  %v1464 = load i64, ptr %slot264, align 8
  %v1465 = load i64, ptr %slot261, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1464, i64 %v1465) nomerge, !dbg !142
  br label %bb_rcslotdone329
bb_rcslotowner329:
  %v1466 = load i64, ptr %slot52, align 8
  store i64 %v1466, ptr %slot265, align 8
  %v1467 = load i64, ptr %slot265, align 8
  %v1468 = load i64, ptr %slot261, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1467, i64 %v1468) nomerge, !dbg !142
  br label %bb_rcslotdone329
bb_rcslotdone329:
  %v1469 = load i64, ptr %slot24, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i64, ptr %p1470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1471, ptr %slot266, align 8
  %v1472 = load i64, ptr %slot266, align 8
  %v1473 = load i64, ptr %slot44, align 8
  %p1474 = inttoptr i64 %v1472 to ptr
  %p1475 = inttoptr i64 %v1473 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1475, ptr %p1474, i64 304, i1 false), !alias.scope !10000001
  %v1476 = load i64, ptr %slot44, align 8
  %v1477 = load i64, ptr %slot33, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  store i64 %v1476, ptr %p1478, align 8, !alias.scope !3, !noalias !4
  %v1479 = load i64, ptr %slot33, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  %ld1481 = load i64, ptr %p1480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1481, ptr %slot267, align 8
  %v1482 = load i64, ptr %slot267, align 8
  %op1483 = add i64 %v1482, 32
  store i64 %op1483, ptr %slot268, align 8
  %v1484 = load i64, ptr %slot268, align 8
  %v1485 = load i64, ptr %slot33, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  store i64 %v1484, ptr %p1486, align 8, !alias.scope !3, !noalias !4
  %v1487 = load i64, ptr %slot12, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  %ld1489 = load i32, ptr %p1488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1489, ptr %slot269, align 8
  %v1490 = load i32, ptr %slot269, align 8
  %cv1491 = zext i32 %v1490 to i64
  %cond1492 = icmp ne i64 %cv1491, 0
  br i1 %cond1492, label %bb_rcslotdrop341, label %bb_rcslotdone341
bb_rcslotdrop341:
  %v1493 = load i64, ptr %slot12, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  store i32 0, ptr %p1494, align 4, !alias.scope !3, !noalias !4
  %v1495 = load i64, ptr %slot32, align 8
  store i64 %v1495, ptr %slot270, align 8
  %v1496 = load i64, ptr %slot13, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  %ld1498 = load i32, ptr %p1497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1498, ptr %slot271, align 8
  %v1499 = load i32, ptr %slot271, align 8
  %op1500 = and i32 %v1499, 28
  store i32 %op1500, ptr %slot272, align 8
  %v1501 = load i32, ptr %slot272, align 8
  %cv1502 = zext i32 %v1501 to i64
  %cond1503 = icmp ne i64 %cv1502, 0
  br i1 %cond1503, label %bb_rcslotrole341, label %bb_rcslotowner341
bb_rcslotrole341:
  %v1504 = load i64, ptr %slot52, align 8
  store i64 %v1504, ptr %slot273, align 8
  %v1505 = load i64, ptr %slot273, align 8
  %v1506 = load i64, ptr %slot270, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1505, i64 %v1506) nomerge, !dbg !144
  br label %bb_rcslotdone341
bb_rcslotowner341:
  %v1507 = load i64, ptr %slot52, align 8
  store i64 %v1507, ptr %slot274, align 8
  %v1508 = load i64, ptr %slot274, align 8
  %v1509 = load i64, ptr %slot270, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1508, i64 %v1509) nomerge, !dbg !144
  br label %bb_rcslotdone341
bb_rcslotdone341:
  %v1510 = load i64, ptr %slot24, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  %ld1512 = load i64, ptr %p1511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1512, ptr %slot275, align 8
  %v1513 = load i64, ptr %slot275, align 8
  %op1514 = add i64 %v1513, 32
  store i64 %op1514, ptr %slot276, align 8
  %v1515 = load i64, ptr %slot32, align 8
  store i64 %v1515, ptr %slot277, align 8
  %v1516 = load i64, ptr %slot276, align 8
  %v1517 = load i64, ptr %slot277, align 8
  %p1518 = inttoptr i64 %v1516 to ptr
  %p1519 = inttoptr i64 %v1517 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1519, ptr %p1518, i64 208, i1 false), !alias.scope !10000001
  %v1520 = load i64, ptr %slot276, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  call void @llvm.memset.p0.i64(ptr %p1521, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !144
  %v1522 = load i64, ptr %slot12, align 8
  %p1523 = inttoptr i64 %v1522 to ptr
  store i32 1, ptr %p1523, align 4, !alias.scope !3, !noalias !4
  %v1524 = load i64, ptr %slot32, align 8
  %v1525 = load i64, ptr %slot33, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  store i64 %v1524, ptr %p1526, align 8, !alias.scope !3, !noalias !4
  %v1527 = load i64, ptr %slot33, align 8
  %p1528 = inttoptr i64 %v1527 to ptr
  %ld1529 = load i64, ptr %p1528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1529, ptr %slot278, align 8
  %v1530 = load i64, ptr %slot1, align 8
  %v1531 = load i64, ptr %slot278, align 8
  %call1532 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v1530, i64 %v1531) nomerge, !dbg !146
  store { i64, i64 } %call1532, ptr %callresult280, align 8
  %addr1533 = ptrtoint ptr %callresult280 to i64
  store i64 %addr1533, ptr %slot279, align 8
  %v1534 = load i64, ptr %slot279, align 8
  %v1535 = load i64, ptr %slot33, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  store i64 %v1534, ptr %p1536, align 8, !alias.scope !3, !noalias !4
  %v1537 = load i64, ptr %slot14, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  %ld1539 = load i32, ptr %p1538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1539, ptr %slot281, align 8
  %v1540 = load i32, ptr %slot281, align 8
  %cv1541 = zext i32 %v1540 to i64
  %cond1542 = icmp ne i64 %cv1541, 0
  br i1 %cond1542, label %bb_rcslotdrop356, label %bb_rcslotdone356
bb_rcslotdrop356:
  %v1543 = load i64, ptr %slot14, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  store i32 0, ptr %p1544, align 4, !alias.scope !3, !noalias !4
  %v1545 = load i64, ptr %slot21, align 8
  store i64 %v1545, ptr %slot282, align 8
  %v1546 = load i64, ptr %slot15, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  %ld1548 = load i32, ptr %p1547, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1548, ptr %slot283, align 8
  %v1549 = load i32, ptr %slot283, align 8
  %op1550 = and i32 %v1549, 28
  store i32 %op1550, ptr %slot284, align 8
  %v1551 = load i32, ptr %slot284, align 8
  %cv1552 = zext i32 %v1551 to i64
  %cond1553 = icmp ne i64 %cv1552, 0
  br i1 %cond1553, label %bb_rcslotrole356, label %bb_rcslotowner356
bb_rcslotrole356:
  %v1554 = load i64, ptr %slot52, align 8
  store i64 %v1554, ptr %slot285, align 8
  %v1555 = load i64, ptr %slot285, align 8
  %v1556 = load i64, ptr %slot282, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1555, i64 %v1556) nomerge, !dbg !146
  br label %bb_rcslotdone356
bb_rcslotowner356:
  %v1557 = load i64, ptr %slot52, align 8
  store i64 %v1557, ptr %slot286, align 8
  %v1558 = load i64, ptr %slot286, align 8
  %v1559 = load i64, ptr %slot282, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1558, i64 %v1559) nomerge, !dbg !146
  br label %bb_rcslotdone356
bb_rcslotdone356:
  %v1560 = load i64, ptr %slot24, align 8
  %p1561 = inttoptr i64 %v1560 to ptr
  %ld1562 = load i64, ptr %p1561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1562, ptr %slot287, align 8
  %v1563 = load i64, ptr %slot287, align 8
  %op1564 = add i64 %v1563, 32
  store i64 %op1564, ptr %slot288, align 8
  %v1565 = load i64, ptr %slot32, align 8
  store i64 %v1565, ptr %slot289, align 8
  %v1566 = load i64, ptr %slot289, align 8
  %v1567 = load i64, ptr %slot288, align 8
  %p1568 = inttoptr i64 %v1566 to ptr
  %p1569 = inttoptr i64 %v1567 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1569, ptr %p1568, i64 208, i1 false), !alias.scope !10000001
  %v1570 = load i64, ptr %slot289, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  call void @llvm.memset.p0.i64(ptr %p1571, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !148
  %v1572 = load i64, ptr %slot12, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i32 0, ptr %p1573, align 4, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot33, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i64 0, ptr %p1575, align 8, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot45, align 8
  store i64 %v1576, ptr %slot290, align 8
  %v1577 = load i64, ptr %slot290, align 8
  %p1578 = inttoptr i64 %v1577 to ptr
  store i32 0, ptr %p1578, align 4, !alias.scope !3, !noalias !4
  %v1579 = load i64, ptr %slot290, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  store i32 0, ptr %p1580, align 4, !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot290, align 8
  %v1582 = load i64, ptr %slot33, align 8
  %p1583 = inttoptr i64 %v1582 to ptr
  store i64 %v1581, ptr %p1583, align 8, !alias.scope !3, !noalias !4
  %v1584 = load i64, ptr %slot46, align 8
  store i64 %v1584, ptr %slot291, align 8
  %v1585 = load i64, ptr %slot291, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  store i64 0, ptr %p1586, align 8, !alias.scope !3, !noalias !4
  %v1587 = load i64, ptr %slot291, align 8
  %p1589 = inttoptr i64 %v1587 to ptr
  %gep1590 = getelementptr i8, ptr %p1589, i64 8
  %op1588 = ptrtoint ptr %gep1590 to i64
  store i64 %op1588, ptr %slot292, align 8
  %v1591 = load i64, ptr %slot292, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i64 0, ptr %p1592, align 8, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot291, align 8
  %p1595 = inttoptr i64 %v1593 to ptr
  %gep1596 = getelementptr i8, ptr %p1595, i64 16
  %op1594 = ptrtoint ptr %gep1596 to i64
  store i64 %op1594, ptr %slot293, align 8
  %v1597 = load i64, ptr %slot293, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  store i64 0, ptr %p1598, align 8, !alias.scope !3, !noalias !4
  %v1599 = load i64, ptr %slot291, align 8
  %p1600 = inttoptr i64 %v1599 to ptr
  store i32 0, ptr %p1600, align 4, !alias.scope !3, !noalias !4
  %v1601 = load i64, ptr %slot20, align 8
  %p1602 = inttoptr i64 %v1601 to ptr
  store i32 1, ptr %p1602, align 4, !alias.scope !3, !noalias !4
  %v1603 = load i64, ptr %slot33, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  %ld1605 = load i64, ptr %p1604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1605, ptr %slot294, align 8
  %v1606 = load i64, ptr %slot291, align 8
  %p1608 = inttoptr i64 %v1606 to ptr
  %gep1609 = getelementptr i8, ptr %p1608, i64 8
  %op1607 = ptrtoint ptr %gep1609 to i64
  store i64 %op1607, ptr %slot295, align 8
  %v1610 = load i64, ptr %slot53, align 8
  store i64 %v1610, ptr %slot296, align 8
  %v1611 = load i64, ptr %slot294, align 8
  %v1612 = load i64, ptr %slot295, align 8
  %p1613 = inttoptr i64 %v1611 to ptr
  %p1614 = inttoptr i64 %v1612 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1614, ptr %p1613, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v1615 = load i64, ptr %slot291, align 8
  %v1616 = load i64, ptr %slot33, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  store i64 %v1615, ptr %p1617, align 8, !alias.scope !3, !noalias !4
  %v1618 = load i64, ptr %slot33, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  %ld1620 = load i64, ptr %p1619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1620, ptr %slot297, align 8
  %v1621 = load i64, ptr %slot21, align 8
  store i64 %v1621, ptr %slot298, align 8
  %v1622 = load i64, ptr %slot297, align 8
  %v1623 = load i64, ptr %slot298, align 8
  %p1624 = inttoptr i64 %v1622 to ptr
  %p1625 = inttoptr i64 %v1623 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1625, ptr %p1624, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot15, align 8
  %p1627 = inttoptr i64 %v1626 to ptr
  store i32 2, ptr %p1627, align 4, !alias.scope !3, !noalias !4
  %v1628 = load i64, ptr %slot14, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i32 1, ptr %p1629, align 4, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot298, align 8
  %v1631 = load i64, ptr %slot33, align 8
  %p1632 = inttoptr i64 %v1631 to ptr
  store i64 %v1630, ptr %p1632, align 8, !alias.scope !3, !noalias !4
  %v1633 = load i64, ptr %slot33, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  %ld1635 = load i64, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1635, ptr %slot299, align 8
  %v1636 = load i64, ptr %slot33, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  %ld1638 = load i64, ptr %p1637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1638, ptr %slot300, align 8
  %v1639 = load i64, ptr %slot23, align 8
  store i64 %v1639, ptr %slot301, align 8
  %v1640 = load i64, ptr %slot53, align 8
  store i64 %v1640, ptr %slot302, align 8
  %v1641 = load i64, ptr %slot52, align 8
  %v1642 = load i64, ptr %slot301, align 8
  %v1643 = load i64, ptr %slot300, align 8
  %v1644 = load i64, ptr %slot302, align 8
  %cv1645 = trunc i64 %v1644 to i32
  %call1646 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v1641, i64 %v1642, i64 %v1643, i32 %cv1645) nomerge, !dbg !150
  store i32 %call1646, ptr %slot303, align 8
  %v1647 = load i32, ptr %slot303, align 8
  %cv1648 = zext i32 %v1647 to i64
  %cond1649 = icmp ne i64 %cv1648, 0
  br i1 %cond1649, label %bb_rcsuccess385, label %bb_rcfailure385
bb_rcfailure385:
  %v1650 = load i64, ptr %slot52, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  %call1652 = call i32 @myl_rc_take_failure(ptr %p1651) nomerge, !dbg !150
  store i32 %call1652, ptr %slot304, align 8
  %v1653 = load i64, ptr %slot1, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  %v1655 = load i32, ptr %slot304, align 8
  %call1656 = call i32 @myl_qbe_rc_status(ptr %p1654, i32 %v1655) nomerge, !dbg !150
  store i32 %call1656, ptr %slot305, align 8
  br label %bb_failure
bb_rcsuccess385:
  %v1657 = load i64, ptr %slot14, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  store i32 0, ptr %p1658, align 4, !alias.scope !3, !noalias !4
  %v1659 = load i64, ptr %slot19, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  store i32 2, ptr %p1660, align 4, !alias.scope !3, !noalias !4
  %v1661 = load i64, ptr %slot18, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  store i32 1, ptr %p1662, align 4, !alias.scope !3, !noalias !4
  %v1663 = load i64, ptr %slot23, align 8
  store i64 %v1663, ptr %slot306, align 8
  %v1664 = load i64, ptr %slot18, align 8
  %p1665 = inttoptr i64 %v1664 to ptr
  store i32 0, ptr %p1665, align 4, !alias.scope !3, !noalias !4
  %v1666 = load i64, ptr %slot14, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  %ld1668 = load i32, ptr %p1667, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1668, ptr %slot307, align 8
  %v1669 = load i32, ptr %slot307, align 8
  %cv1670 = zext i32 %v1669 to i64
  %cond1671 = icmp ne i64 %cv1670, 0
  br i1 %cond1671, label %bb_rcslotdrop395, label %bb_rcslotdone395
bb_rcslotdrop395:
  %v1672 = load i64, ptr %slot14, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  store i32 0, ptr %p1673, align 4, !alias.scope !3, !noalias !4
  %v1674 = load i64, ptr %slot21, align 8
  store i64 %v1674, ptr %slot308, align 8
  %v1675 = load i64, ptr %slot15, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  %ld1677 = load i32, ptr %p1676, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1677, ptr %slot309, align 8
  %v1678 = load i32, ptr %slot309, align 8
  %op1679 = and i32 %v1678, 28
  store i32 %op1679, ptr %slot310, align 8
  %v1680 = load i32, ptr %slot310, align 8
  %cv1681 = zext i32 %v1680 to i64
  %cond1682 = icmp ne i64 %cv1681, 0
  br i1 %cond1682, label %bb_rcslotrole395, label %bb_rcslotowner395
bb_rcslotrole395:
  %v1683 = load i64, ptr %slot52, align 8
  store i64 %v1683, ptr %slot311, align 8
  %v1684 = load i64, ptr %slot311, align 8
  %v1685 = load i64, ptr %slot308, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1684, i64 %v1685) nomerge, !dbg !150
  br label %bb_rcslotdone395
bb_rcslotowner395:
  %v1686 = load i64, ptr %slot52, align 8
  store i64 %v1686, ptr %slot312, align 8
  %v1687 = load i64, ptr %slot312, align 8
  %v1688 = load i64, ptr %slot308, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1687, i64 %v1688) nomerge, !dbg !150
  br label %bb_rcslotdone395
bb_rcslotdone395:
  %v1689 = load i64, ptr %slot12, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  %ld1691 = load i32, ptr %p1690, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1691, ptr %slot313, align 8
  %v1692 = load i32, ptr %slot313, align 8
  %cv1693 = zext i32 %v1692 to i64
  %cond1694 = icmp ne i64 %cv1693, 0
  br i1 %cond1694, label %bb_rcslotdrop422, label %bb_rcslotdone422
bb_rcslotdrop422:
  %v1695 = load i64, ptr %slot12, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  store i32 0, ptr %p1696, align 4, !alias.scope !3, !noalias !4
  %v1697 = load i64, ptr %slot32, align 8
  store i64 %v1697, ptr %slot314, align 8
  %v1698 = load i64, ptr %slot13, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  %ld1700 = load i32, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1700, ptr %slot315, align 8
  %v1701 = load i32, ptr %slot315, align 8
  %op1702 = and i32 %v1701, 28
  store i32 %op1702, ptr %slot316, align 8
  %v1703 = load i32, ptr %slot316, align 8
  %cv1704 = zext i32 %v1703 to i64
  %cond1705 = icmp ne i64 %cv1704, 0
  br i1 %cond1705, label %bb_rcslotrole422, label %bb_rcslotowner422
bb_rcslotrole422:
  %v1706 = load i64, ptr %slot52, align 8
  store i64 %v1706, ptr %slot317, align 8
  %v1707 = load i64, ptr %slot317, align 8
  %v1708 = load i64, ptr %slot314, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1707, i64 %v1708) nomerge, !dbg !150
  br label %bb_rcslotdone422
bb_rcslotowner422:
  %v1709 = load i64, ptr %slot52, align 8
  store i64 %v1709, ptr %slot318, align 8
  %v1710 = load i64, ptr %slot318, align 8
  %v1711 = load i64, ptr %slot314, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1710, i64 %v1711) nomerge, !dbg !150
  br label %bb_rcslotdone422
bb_rcslotdone422:
  %v1712 = load i64, ptr %slot10, align 8
  %p1713 = inttoptr i64 %v1712 to ptr
  %ld1714 = load i32, ptr %p1713, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1714, ptr %slot319, align 8
  %v1715 = load i32, ptr %slot319, align 8
  %cv1716 = zext i32 %v1715 to i64
  %cond1717 = icmp ne i64 %cv1716, 0
  br i1 %cond1717, label %bb_rcslotdrop449, label %bb_rcslotdone449
bb_rcslotdrop449:
  %v1718 = load i64, ptr %slot10, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  store i32 0, ptr %p1719, align 4, !alias.scope !3, !noalias !4
  %v1720 = load i64, ptr %slot31, align 8
  store i64 %v1720, ptr %slot320, align 8
  %v1721 = load i64, ptr %slot11, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  %ld1723 = load i32, ptr %p1722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1723, ptr %slot321, align 8
  %v1724 = load i32, ptr %slot321, align 8
  %op1725 = and i32 %v1724, 28
  store i32 %op1725, ptr %slot322, align 8
  %v1726 = load i32, ptr %slot322, align 8
  %cv1727 = zext i32 %v1726 to i64
  %cond1728 = icmp ne i64 %cv1727, 0
  br i1 %cond1728, label %bb_rcslotrole449, label %bb_rcslotowner449
bb_rcslotrole449:
  %v1729 = load i64, ptr %slot52, align 8
  store i64 %v1729, ptr %slot323, align 8
  %v1730 = load i64, ptr %slot323, align 8
  %v1731 = load i64, ptr %slot320, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1730, i64 %v1731) nomerge, !dbg !150
  br label %bb_rcslotdone449
bb_rcslotowner449:
  %v1732 = load i64, ptr %slot52, align 8
  store i64 %v1732, ptr %slot324, align 8
  %v1733 = load i64, ptr %slot324, align 8
  %v1734 = load i64, ptr %slot320, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1733, i64 %v1734) nomerge, !dbg !150
  br label %bb_rcslotdone449
bb_rcslotdone449:
  %v1735 = load i64, ptr %slot8, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  %ld1737 = load i32, ptr %p1736, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1737, ptr %slot325, align 8
  %v1738 = load i32, ptr %slot325, align 8
  %cv1739 = zext i32 %v1738 to i64
  %cond1740 = icmp ne i64 %cv1739, 0
  br i1 %cond1740, label %bb_rcslotdrop476, label %bb_rcslotdone476
bb_rcslotdrop476:
  %v1741 = load i64, ptr %slot8, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i32 0, ptr %p1742, align 4, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot29, align 8
  store i64 %v1743, ptr %slot326, align 8
  %v1744 = load i64, ptr %slot9, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  %ld1746 = load i32, ptr %p1745, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1746, ptr %slot327, align 8
  %v1747 = load i32, ptr %slot327, align 8
  %op1748 = and i32 %v1747, 28
  store i32 %op1748, ptr %slot328, align 8
  %v1749 = load i32, ptr %slot328, align 8
  %cv1750 = zext i32 %v1749 to i64
  %cond1751 = icmp ne i64 %cv1750, 0
  br i1 %cond1751, label %bb_rcslotrole476, label %bb_rcslotowner476
bb_rcslotrole476:
  %v1752 = load i64, ptr %slot52, align 8
  store i64 %v1752, ptr %slot329, align 8
  %v1753 = load i64, ptr %slot329, align 8
  %v1754 = load i64, ptr %slot326, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1753, i64 %v1754) nomerge, !dbg !150
  br label %bb_rcslotdone476
bb_rcslotowner476:
  %v1755 = load i64, ptr %slot52, align 8
  store i64 %v1755, ptr %slot330, align 8
  %v1756 = load i64, ptr %slot330, align 8
  %v1757 = load i64, ptr %slot326, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1756, i64 %v1757) nomerge, !dbg !150
  br label %bb_rcslotdone476
bb_rcslotdone476:
  %v1758 = load i64, ptr %slot6, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %ld1760 = load i32, ptr %p1759, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1760, ptr %slot331, align 8
  %v1761 = load i32, ptr %slot331, align 8
  %cv1762 = zext i32 %v1761 to i64
  %cond1763 = icmp ne i64 %cv1762, 0
  br i1 %cond1763, label %bb_rcslotdrop485, label %bb_rcslotdone485
bb_rcslotdrop485:
  %v1764 = load i64, ptr %slot6, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  store i32 0, ptr %p1765, align 4, !alias.scope !3, !noalias !4
  %v1766 = load i64, ptr %slot28, align 8
  store i64 %v1766, ptr %slot332, align 8
  %v1767 = load i64, ptr %slot7, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %ld1769 = load i32, ptr %p1768, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1769, ptr %slot333, align 8
  %v1770 = load i32, ptr %slot333, align 8
  %op1771 = and i32 %v1770, 28
  store i32 %op1771, ptr %slot334, align 8
  %v1772 = load i32, ptr %slot334, align 8
  %cv1773 = zext i32 %v1772 to i64
  %cond1774 = icmp ne i64 %cv1773, 0
  br i1 %cond1774, label %bb_rcslotrole485, label %bb_rcslotowner485
bb_rcslotrole485:
  %v1775 = load i64, ptr %slot52, align 8
  store i64 %v1775, ptr %slot335, align 8
  %v1776 = load i64, ptr %slot335, align 8
  %v1777 = load i64, ptr %slot332, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64 %v1776, i64 %v1777) nomerge, !dbg !150
  br label %bb_rcslotdone485
bb_rcslotowner485:
  %v1778 = load i64, ptr %slot52, align 8
  store i64 %v1778, ptr %slot336, align 8
  %v1779 = load i64, ptr %slot336, align 8
  %v1780 = load i64, ptr %slot332, align 8
  call void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64 %v1779, i64 %v1780) nomerge, !dbg !150
  br label %bb_rcslotdone485
bb_rcslotdone485:
  %v1781 = load i64, ptr %slot306, align 8
  %p1782 = inttoptr i64 %v1781 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1782, i64 24, i1 false)
  ret void
bb_failure:
  %v1783 = load i64, ptr %slot5, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  call void @llvm.memset.p0.i64(ptr %p1784, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !150
  %v1785 = load i64, ptr %slot5, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1786, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v1787 = load i64, ptr %slot5, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  call void @llvm.memset.p0.i64(ptr %p1788, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !150
  %v1789 = load i64, ptr %slot5, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1790, i64 24, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64, i64, i64)
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare i64 @myl_f_bd9e3a524ab3cf6b1d10f9f010a9809523e9baa589e1d9e95734ec89624acb99(i64, i64, i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64, i64)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_drop(i64, i64)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_loan(i64, i64, i64)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_4f61ce03124355c2e5bf745e18f8973b529736e48b81b0bb984582fb742cc20c_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 80v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!10000001 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9071aa69d62fb1d23e062dda66ed7f74ea3cd6b716225aca159e2b66890e85fc", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9071aa69d62fb1d23e062dda66ed7f74ea3cd6b716225aca159e2b66890e85fc", linkageName: "myl_f_9071aa69d62fb1d23e062dda66ed7f74ea3cd6b716225aca159e2b66890e85fc", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16159079066433449101, i64 0, !"myl_f_9071aa69d62fb1d23e062dda66ed7f74ea3cd6b716225aca159e2b66890e85fc"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!122 = !DILocation(line: 17, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!126 = !DILocation(line: 19, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!128 = !DILocation(line: 21, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!130 = !DILocation(line: 33, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!132 = !DILocation(line: 45, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!134 = !DILocation(line: 49, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!136 = !DILocation(line: 55, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!138 = !DILocation(line: 67, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!140 = !DILocation(line: 72, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!142 = !DILocation(line: 75, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!144 = !DILocation(line: 78, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!146 = !DILocation(line: 82, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647287)
!148 = !DILocation(line: 94, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!150 = !DILocation(line: 99, column: 0, scope: !151)
