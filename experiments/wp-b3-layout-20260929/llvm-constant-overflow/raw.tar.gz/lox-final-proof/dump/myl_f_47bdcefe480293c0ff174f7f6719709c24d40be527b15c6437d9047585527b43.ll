target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_47bdcefe480293c0ff174f7f6719709c24d40be527b15c6437d9047585527b43(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v155 = load i64, ptr %slot1, align 8
  %op156 = add i64 %v155, 32
  store i64 %op156, ptr %slot4, align 8
  %mem157 = alloca i8, i64 16, align 8
  %ptr158 = ptrtoint ptr %mem157 to i64
  store i64 %ptr158, ptr %slot5, align 8
  %mem159 = alloca i8, i64 8, align 8
  %ptr160 = ptrtoint ptr %mem159 to i64
  store i64 %ptr160, ptr %slot6, align 8
  %mem161 = alloca i8, i64 8, align 8
  %ptr162 = ptrtoint ptr %mem161 to i64
  store i64 %ptr162, ptr %slot7, align 8
  %mem163 = alloca i8, i64 8, align 8
  %ptr164 = ptrtoint ptr %mem163 to i64
  store i64 %ptr164, ptr %slot8, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot9, align 8
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot10, align 8
  %mem169 = alloca i8, i64 16, align 8
  %ptr170 = ptrtoint ptr %mem169 to i64
  store i64 %ptr170, ptr %slot11, align 8
  %mem171 = alloca i8, i64 8, align 8
  %ptr172 = ptrtoint ptr %mem171 to i64
  store i64 %ptr172, ptr %slot12, align 8
  %mem173 = alloca i8, i64 16, align 8
  %ptr174 = ptrtoint ptr %mem173 to i64
  store i64 %ptr174, ptr %slot13, align 8
  %mem175 = alloca i8, i64 8, align 8
  %ptr176 = ptrtoint ptr %mem175 to i64
  store i64 %ptr176, ptr %slot14, align 8
  %mem177 = alloca i8, i64 8, align 8
  %ptr178 = ptrtoint ptr %mem177 to i64
  store i64 %ptr178, ptr %slot15, align 8
  %mem179 = alloca i8, i64 8, align 8
  %ptr180 = ptrtoint ptr %mem179 to i64
  store i64 %ptr180, ptr %slot16, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot17, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot18, align 8
  %mem185 = alloca i8, i64 16, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot19, align 8
  %mem187 = alloca i8, i64 16, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot20, align 8
  %mem189 = alloca i8, i64 16, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot21, align 8
  %v191 = load i64, ptr %slot2, align 8
  %v192 = load i64, ptr %slot14, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i64 %v191, ptr %p193, align 8, !alias.scope !3, !noalias !4
  %v194 = load i64, ptr %slot3, align 8
  %v195 = load i64, ptr %slot15, align 8
  %p196 = inttoptr i64 %v195 to ptr
  store i64 %v194, ptr %p196, align 8, !alias.scope !3, !noalias !4
  %v197 = load i64, ptr %slot1, align 8
  %p198 = inttoptr i64 %v197 to ptr
  %call199 = call ptr @myl_qbe_heap(ptr %p198) nomerge, !dbg !110
  %calladdr200 = ptrtoint ptr %call199 to i64
  store i64 %calladdr200, ptr %slot22, align 8
  %v201 = load i64, ptr %slot1, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %call203 = call i64 @myl_qbe_region_mark(ptr %p202) nomerge, !dbg !110
  store i64 %call203, ptr %slot23, align 8
  %v204 = load i64, ptr %slot6, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i32 0, ptr %p205, align 4, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot7, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i32 0, ptr %p207, align 4, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot8, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i32 0, ptr %p209, align 4, !alias.scope !3, !noalias !4
  %v210 = load i64, ptr %slot9, align 8
  %p211 = inttoptr i64 %v210 to ptr
  store i32 0, ptr %p211, align 4, !alias.scope !3, !noalias !4
  %v212 = load i64, ptr %slot10, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i32 0, ptr %p213, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v214 = load i64, ptr %slot14, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot24, align 8
  %v217 = load i64, ptr %slot24, align 8
  %v218 = load i64, ptr %slot17, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot15, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot25, align 8
  %v223 = load i64, ptr %slot25, align 8
  %v224 = load i64, ptr %slot18, align 8
  %p225 = inttoptr i64 %v224 to ptr
  store i64 %v223, ptr %p225, align 8, !alias.scope !3, !noalias !4
  %v226 = load i64, ptr %slot18, align 8
  %p227 = inttoptr i64 %v226 to ptr
  %ld228 = load i64, ptr %p227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld228, ptr %slot26, align 8
  %v229 = load i64, ptr %slot26, align 8
  %op230 = add i64 %v229, 0
  store i64 %op230, ptr %slot27, align 8
  %v231 = load i64, ptr %slot27, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i64, ptr %p232, align 8, !alias.scope !4, !noalias !3
  store i64 %ld233, ptr %slot28, align 8
  %v234 = load i64, ptr %slot28, align 8
  %v235 = load i64, ptr %slot18, align 8
  %p236 = inttoptr i64 %v235 to ptr
  store i64 %v234, ptr %p236, align 8, !alias.scope !3, !noalias !4
  %v237 = load i64, ptr %slot17, align 8
  %p238 = inttoptr i64 %v237 to ptr
  %ld239 = load i64, ptr %p238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld239, ptr %slot29, align 8
  %v240 = load i64, ptr %slot18, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i64, ptr %p241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld242, ptr %slot30, align 8
  %v243 = load i64, ptr %slot1, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %v245 = load i64, ptr %slot29, align 8
  %v246 = load i64, ptr %slot30, align 8
  %call247 = call i64 @myl_qbe_clock_advance(ptr %p244, i64 %v245, i64 %v246) nomerge, !dbg !112
  store i64 %call247, ptr %slot31, align 8
  %v248 = load i64, ptr %slot31, align 8
  %v249 = load i64, ptr %slot17, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 %v248, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot17, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i64, ptr %p252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld253, ptr %slot32, align 8
  %v254 = load i64, ptr %slot32, align 8
  %v255 = load i64, ptr %slot16, align 8
  %p256 = inttoptr i64 %v255 to ptr
  store i64 %v254, ptr %p256, align 8, !alias.scope !3, !noalias !4
  %v257 = load i64, ptr %slot16, align 8
  %p258 = inttoptr i64 %v257 to ptr
  %ld259 = load i64, ptr %p258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld259, ptr %slot33, align 8
  %v260 = load i64, ptr %slot33, align 8
  %v261 = load i64, ptr %slot17, align 8
  %p262 = inttoptr i64 %v261 to ptr
  store i64 %v260, ptr %p262, align 8, !alias.scope !3, !noalias !4
  %v263 = load i64, ptr %slot18, align 8
  %p264 = inttoptr i64 %v263 to ptr
  store i64 1, ptr %p264, align 8, !alias.scope !3, !noalias !4
  %v265 = load i64, ptr %slot18, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld267, ptr %slot34, align 8
  %v268 = load i64, ptr %slot17, align 8
  %p269 = inttoptr i64 %v268 to ptr
  %ld270 = load i64, ptr %p269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld270, ptr %slot35, align 8
  %v271 = load i64, ptr %slot35, align 8
  %v272 = load i64, ptr %slot34, align 8
  %cmp273 = icmp eq i64 %v271, %v272
  %cv274 = zext i1 %cmp273 to i64
  store i64 %cv274, ptr %slot36, align 8
  %v275 = load i64, ptr %slot36, align 8
  %v276 = load i64, ptr %slot17, align 8
  %p277 = inttoptr i64 %v276 to ptr
  store i64 %v275, ptr %p277, align 8, !alias.scope !3, !noalias !4
  %v278 = load i64, ptr %slot17, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld280, ptr %slot37, align 8
  %v281 = load i64, ptr %slot37, align 8
  %cond282 = icmp ne i64 %v281, 0
  br i1 %cond282, label %bb_next14, label %bb_i12
bb_next14:
  %p283 = inttoptr i64 ptrtoint (ptr @myl_lit_0fd5cd837248232ba0243aa952e6cae898dcaf640f99b606fe3db33b738ccc18 to i64) to ptr
  %ld284 = load i64, ptr %p283, align 8, !alias.scope !4, !noalias !3
  store i64 %ld284, ptr %slot38, align 8
  %v285 = load i64, ptr %slot38, align 8
  %v286 = load i64, ptr %slot17, align 8
  %p287 = inttoptr i64 %v286 to ptr
  store i64 %v285, ptr %p287, align 8, !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot17, align 8
  %p289 = inttoptr i64 %v288 to ptr
  %ld290 = load i64, ptr %p289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld290, ptr %slot39, align 8
  %v291 = load i64, ptr %slot39, align 8
  %v292 = load i64, ptr %slot12, align 8
  %p293 = inttoptr i64 %v292 to ptr
  store i64 %v291, ptr %p293, align 8, !alias.scope !3, !noalias !4
  %v294 = load i64, ptr %slot12, align 8
  store i64 %v294, ptr %slot40, align 8
  %v295 = load i64, ptr %slot13, align 8
  store i64 %v295, ptr %slot41, align 8
  %v296 = load i64, ptr %slot40, align 8
  %v297 = load i64, ptr %slot41, align 8
  %p298 = inttoptr i64 %v296 to ptr
  %p299 = inttoptr i64 %v297 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p299, ptr %p298, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot9, align 8
  %p301 = inttoptr i64 %v300 to ptr
  store i32 2, ptr %p301, align 4, !alias.scope !3, !noalias !4
  %v302 = load i64, ptr %slot8, align 8
  %p303 = inttoptr i64 %v302 to ptr
  store i32 1, ptr %p303, align 4, !alias.scope !3, !noalias !4
  %v304 = load i64, ptr %slot11, align 8
  store i64 %v304, ptr %slot42, align 8
  %v305 = load i64, ptr %slot13, align 8
  store i64 %v305, ptr %slot43, align 8
  %v306 = load i64, ptr %slot43, align 8
  %v307 = load i64, ptr %slot42, align 8
  %p308 = inttoptr i64 %v306 to ptr
  %p309 = inttoptr i64 %v307 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p309, ptr %p308, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot7, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i32 2, ptr %p311, align 4, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot9, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %ld314 = load i32, ptr %p313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld314, ptr %slot44, align 8
  %v315 = load i32, ptr %slot44, align 8
  %v316 = load i64, ptr %slot7, align 8
  %p317 = inttoptr i64 %v316 to ptr
  store i32 %v315, ptr %p317, align 4, !alias.scope !3, !noalias !4
  %v318 = load i64, ptr %slot8, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i32 0, ptr %p319, align 4, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot6, align 8
  %p321 = inttoptr i64 %v320 to ptr
  store i32 1, ptr %p321, align 4, !alias.scope !3, !noalias !4
  %v322 = load i64, ptr %slot42, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %ld324 = load i64, ptr %p323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld324, ptr %slot45, align 8
  %v325 = load i64, ptr %slot45, align 8
  %v326 = load i64, ptr %slot17, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i64 %v325, ptr %p327, align 8, !alias.scope !3, !noalias !4
  %v328 = load i64, ptr %slot19, align 8
  store i64 %v328, ptr %slot46, align 8
  %v329 = load i64, ptr %slot46, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i64 0, ptr %p330, align 8, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot46, align 8
  %p333 = inttoptr i64 %v331 to ptr
  %gep334 = getelementptr i8, ptr %p333, i64 8
  %op332 = ptrtoint ptr %gep334 to i64
  store i64 %op332, ptr %slot47, align 8
  %v335 = load i64, ptr %slot47, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 0, ptr %p336, align 8, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot46, align 8
  %p338 = inttoptr i64 %v337 to ptr
  store i32 1, ptr %p338, align 4, !alias.scope !3, !noalias !4
  %v339 = load i64, ptr %slot10, align 8
  %p340 = inttoptr i64 %v339 to ptr
  store i32 1, ptr %p340, align 4, !alias.scope !3, !noalias !4
  %v341 = load i64, ptr %slot17, align 8
  %p342 = inttoptr i64 %v341 to ptr
  %ld343 = load i64, ptr %p342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld343, ptr %slot48, align 8
  %v344 = load i64, ptr %slot48, align 8
  %v345 = load i64, ptr %slot12, align 8
  %p346 = inttoptr i64 %v345 to ptr
  store i64 %v344, ptr %p346, align 8, !alias.scope !3, !noalias !4
  %v347 = load i64, ptr %slot12, align 8
  store i64 %v347, ptr %slot49, align 8
  %v348 = load i64, ptr %slot46, align 8
  %p350 = inttoptr i64 %v348 to ptr
  %gep351 = getelementptr i8, ptr %p350, i64 8
  %op349 = ptrtoint ptr %gep351 to i64
  store i64 %op349, ptr %slot50, align 8
  %v352 = load i64, ptr %slot23, align 8
  store i64 %v352, ptr %slot51, align 8
  %v353 = load i64, ptr %slot17, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %ld355 = load i64, ptr %p354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld355, ptr %slot52, align 8
  %v356 = load i64, ptr %slot52, align 8
  %v357 = load i64, ptr %slot12, align 8
  %p358 = inttoptr i64 %v357 to ptr
  store i64 %v356, ptr %p358, align 8, !alias.scope !3, !noalias !4
  %v359 = load i64, ptr %slot12, align 8
  store i64 %v359, ptr %slot53, align 8
  %v360 = load i64, ptr %slot13, align 8
  store i64 %v360, ptr %slot54, align 8
  %v361 = load i64, ptr %slot23, align 8
  store i64 %v361, ptr %slot55, align 8
  %v362 = load i64, ptr %slot53, align 8
  %p364 = inttoptr i64 %v362 to ptr
  %gep365 = getelementptr i8, ptr %p364, i64 0
  %op363 = ptrtoint ptr %gep365 to i64
  store i64 %op363, ptr %slot56, align 8
  %v366 = load i64, ptr %slot56, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld368, ptr %slot57, align 8
  %v369 = load i64, ptr %slot57, align 8
  %cmp370 = icmp ne i64 %v369, 0
  %cv371 = zext i1 %cmp370 to i32
  store i32 %cv371, ptr %slot58, align 8
  %v372 = load i32, ptr %slot58, align 8
  %cv373 = zext i32 %v372 to i64
  %cond374 = icmp ne i64 %cv373, 0
  br i1 %cond374, label %bb_rcmoveheader45, label %bb_rcmovenext45
bb_rcmoveheader45:
  %v375 = load i64, ptr %slot57, align 8
  %op376 = sub i64 %v375, 16
  store i64 %op376, ptr %slot59, align 8
  %v377 = load i64, ptr %slot57, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %rgep379 = getelementptr i8, ptr %p378, i64 -16
  %ld380 = load i64, ptr %rgep379, align 8, !alias.scope !9, !noalias !10
  store i64 %ld380, ptr %slot60, align 8
  %v381 = load i64, ptr %slot60, align 8
  %op382 = and i64 %v381, 5764607523034234881
  store i64 %op382, ptr %slot61, align 8
  %v383 = load i64, ptr %slot61, align 8
  %cmp384 = icmp ne i64 %v383, 0
  %cv385 = zext i1 %cmp384 to i32
  store i32 %cv385, ptr %slot62, align 8
  %v386 = load i32, ptr %slot62, align 8
  %cv387 = zext i32 %v386 to i64
  %cond388 = icmp ne i64 %cv387, 0
  br i1 %cond388, label %bb_rcmoveslow42, label %bb_rcmovenext45
bb_rcmovenext45:
  %v389 = load i64, ptr %slot53, align 8
  %v390 = load i64, ptr %slot54, align 8
  %p391 = inttoptr i64 %v389 to ptr
  %p392 = inttoptr i64 %v390 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p392, ptr %p391, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v393 = load i64, ptr %slot53, align 8
  %p394 = inttoptr i64 %v393 to ptr
  store i64 0, ptr %p394, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved42
bb_rcmoveslow42:
  %v395 = load i64, ptr %slot22, align 8
  %v396 = load i64, ptr %slot54, align 8
  %v397 = load i64, ptr %slot53, align 8
  %v398 = load i64, ptr %slot55, align 8
  %cv399 = trunc i64 %v398 to i32
  %call400 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v395, i64 %v396, i64 %v397, i32 %cv399) nomerge, !dbg !114
  store i32 %call400, ptr %slot63, align 8
  %v401 = load i32, ptr %slot63, align 8
  %cv402 = zext i32 %v401 to i64
  %cond403 = icmp ne i64 %cv402, 0
  br i1 %cond403, label %bb_rcsuccess52, label %bb_rcfailure52
bb_rcfailure52:
  %v404 = load i64, ptr %slot22, align 8
  %p405 = inttoptr i64 %v404 to ptr
  %call406 = call i32 @myl_rc_take_failure(ptr %p405) nomerge, !dbg !114
  store i32 %call406, ptr %slot64, align 8
  %v407 = load i64, ptr %slot1, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %v409 = load i32, ptr %slot64, align 8
  %call410 = call i32 @myl_qbe_rc_status(ptr %p408, i32 %v409) nomerge, !dbg !114
  store i32 %call410, ptr %slot65, align 8
  br label %bb_failure
bb_rcsuccess52:
  br label %bb_rcmoved42
bb_rcmoved42:
  %v411 = load i64, ptr %slot6, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i32 0, ptr %p412, align 4, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot9, align 8
  %p414 = inttoptr i64 %v413 to ptr
  store i32 2, ptr %p414, align 4, !alias.scope !3, !noalias !4
  %v415 = load i64, ptr %slot8, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i32 1, ptr %p416, align 4, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot13, align 8
  store i64 %v417, ptr %slot66, align 8
  %v418 = load i64, ptr %slot66, align 8
  %v419 = load i64, ptr %slot50, align 8
  %p420 = inttoptr i64 %v418 to ptr
  %p421 = inttoptr i64 %v419 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p421, ptr %p420, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v422 = load i64, ptr %slot8, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i32 0, ptr %p423, align 4, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot46, align 8
  %v425 = load i64, ptr %slot17, align 8
  %p426 = inttoptr i64 %v425 to ptr
  store i64 %v424, ptr %p426, align 8, !alias.scope !3, !noalias !4
  %p427 = inttoptr i64 ptrtoint (ptr @myl_f_47bdcefe480293c0ff174f7f6719709c24d40be527b15c6437d9047585527b43_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p427, i64 10) "call-inline-cost"="0", !dbg !114
  %v428 = load i64, ptr %slot17, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %ld430 = load i64, ptr %p429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld430, ptr %slot67, align 8
  %v431 = load i64, ptr %slot11, align 8
  store i64 %v431, ptr %slot68, align 8
  %v432 = load i64, ptr %slot67, align 8
  %v433 = load i64, ptr %slot68, align 8
  %p434 = inttoptr i64 %v432 to ptr
  %p435 = inttoptr i64 %v433 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p435, ptr %p434, i64 16, i1 false)
  %v436 = load i64, ptr %slot7, align 8
  %p437 = inttoptr i64 %v436 to ptr
  store i32 2, ptr %p437, align 4, !alias.scope !3, !noalias !4
  %v438 = load i64, ptr %slot6, align 8
  %p439 = inttoptr i64 %v438 to ptr
  store i32 1, ptr %p439, align 4, !alias.scope !3, !noalias !4
  %v440 = load i64, ptr %slot68, align 8
  %v441 = load i64, ptr %slot17, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i64 %v440, ptr %p442, align 8, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot17, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i64, ptr %p444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld445, ptr %slot69, align 8
  %v446 = load i64, ptr %slot17, align 8
  %p447 = inttoptr i64 %v446 to ptr
  %ld448 = load i64, ptr %p447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld448, ptr %slot70, align 8
  %v449 = load i64, ptr %slot13, align 8
  store i64 %v449, ptr %slot71, align 8
  %v450 = load i64, ptr %slot23, align 8
  store i64 %v450, ptr %slot72, align 8
  %v451 = load i64, ptr %slot22, align 8
  %v452 = load i64, ptr %slot71, align 8
  %v453 = load i64, ptr %slot70, align 8
  %v454 = load i64, ptr %slot72, align 8
  %cv455 = trunc i64 %v454 to i32
  %call456 = call i32 @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_take(i64 %v451, i64 %v452, i64 %v453, i32 %cv455) nomerge, !dbg !116
  store i32 %call456, ptr %slot73, align 8
  %v457 = load i32, ptr %slot73, align 8
  %cv458 = zext i32 %v457 to i64
  %cond459 = icmp ne i64 %cv458, 0
  br i1 %cond459, label %bb_rcsuccess69, label %bb_rcfailure69
bb_rcfailure69:
  %v460 = load i64, ptr %slot22, align 8
  %p461 = inttoptr i64 %v460 to ptr
  %call462 = call i32 @myl_rc_take_failure(ptr %p461) nomerge, !dbg !116
  store i32 %call462, ptr %slot74, align 8
  %v463 = load i64, ptr %slot1, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %v465 = load i32, ptr %slot74, align 8
  %call466 = call i32 @myl_qbe_rc_status(ptr %p464, i32 %v465) nomerge, !dbg !116
  store i32 %call466, ptr %slot75, align 8
  br label %bb_failure
bb_rcsuccess69:
  %v467 = load i64, ptr %slot6, align 8
  %p468 = inttoptr i64 %v467 to ptr
  store i32 0, ptr %p468, align 4, !alias.scope !3, !noalias !4
  %v469 = load i64, ptr %slot9, align 8
  %p470 = inttoptr i64 %v469 to ptr
  store i32 2, ptr %p470, align 4, !alias.scope !3, !noalias !4
  %v471 = load i64, ptr %slot8, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i32 1, ptr %p472, align 4, !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot13, align 8
  store i64 %v473, ptr %slot76, align 8
  %v474 = load i64, ptr %slot8, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i32 0, ptr %p475, align 4, !alias.scope !3, !noalias !4
  %v476 = load i64, ptr %slot6, align 8
  %p477 = inttoptr i64 %v476 to ptr
  %ld478 = load i32, ptr %p477, align 4, !alias.scope !3, !noalias !4
  store i32 %ld478, ptr %slot77, align 8
  %v479 = load i32, ptr %slot77, align 8
  %cv480 = zext i32 %v479 to i64
  %cond481 = icmp ne i64 %cv480, 0
  br i1 %cond481, label %bb_rcslotdrop79, label %bb_rcslotdone79
bb_rcslotdrop79:
  %v482 = load i64, ptr %slot6, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 0, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot11, align 8
  store i64 %v484, ptr %slot78, align 8
  %v485 = load i64, ptr %slot7, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %ld487 = load i32, ptr %p486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld487, ptr %slot79, align 8
  %v488 = load i32, ptr %slot79, align 8
  %op489 = and i32 %v488, 28
  store i32 %op489, ptr %slot80, align 8
  %v490 = load i32, ptr %slot80, align 8
  %cv491 = zext i32 %v490 to i64
  %cond492 = icmp ne i64 %cv491, 0
  br i1 %cond492, label %bb_rcslotrole79, label %bb_rcslotowner79
bb_rcslotrole79:
  %v493 = load i64, ptr %slot22, align 8
  store i64 %v493, ptr %slot81, align 8
  %v494 = load i64, ptr %slot81, align 8
  %v495 = load i64, ptr %slot78, align 8
  call void @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_unloan(i64 %v494, i64 %v495) nomerge, !dbg !116
  br label %bb_rcslotdone79
bb_rcslotowner79:
  %v496 = load i64, ptr %slot22, align 8
  store i64 %v496, ptr %slot82, align 8
  %v497 = load i64, ptr %slot82, align 8
  %v498 = load i64, ptr %slot78, align 8
  call void @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_drop(i64 %v497, i64 %v498) nomerge, !dbg !116
  br label %bb_rcslotdone79
bb_rcslotdone79:
  %v499 = load i64, ptr %slot76, align 8
  %p500 = inttoptr i64 %v499 to ptr
  %ret501 = load { i64, i64 }, ptr %p500, align 8
  ret { i64, i64 } %ret501
bb_i12:
  %v502 = load i64, ptr %slot16, align 8
  %p503 = inttoptr i64 %v502 to ptr
  %ld504 = load i64, ptr %p503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld504, ptr %slot83, align 8
  %v505 = load i64, ptr %slot83, align 8
  %v506 = load i64, ptr %slot17, align 8
  %p507 = inttoptr i64 %v506 to ptr
  store i64 %v505, ptr %p507, align 8, !alias.scope !3, !noalias !4
  %v508 = load i64, ptr %slot18, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i64 2, ptr %p509, align 8, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot18, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i64, ptr %p511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld512, ptr %slot84, align 8
  %v513 = load i64, ptr %slot17, align 8
  %p514 = inttoptr i64 %v513 to ptr
  %ld515 = load i64, ptr %p514, align 8, !alias.scope !3, !noalias !4
  store i64 %ld515, ptr %slot85, align 8
  %v516 = load i64, ptr %slot85, align 8
  %v517 = load i64, ptr %slot84, align 8
  %cmp518 = icmp eq i64 %v516, %v517
  %cv519 = zext i1 %cmp518 to i64
  store i64 %cv519, ptr %slot86, align 8
  %v520 = load i64, ptr %slot86, align 8
  %v521 = load i64, ptr %slot17, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i64 %v520, ptr %p522, align 8, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot17, align 8
  %p524 = inttoptr i64 %v523 to ptr
  %ld525 = load i64, ptr %p524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld525, ptr %slot87, align 8
  %v526 = load i64, ptr %slot87, align 8
  %cond527 = icmp ne i64 %v526, 0
  br i1 %cond527, label %bb_next91, label %bb_i19
bb_next91:
  %p528 = inttoptr i64 ptrtoint (ptr @myl_lit_39b669ecaea859d8e7dd47a58db57c5345b1deb3ccc2541b691370cc2f5b7110 to i64) to ptr
  %ld529 = load i64, ptr %p528, align 8, !alias.scope !4, !noalias !3
  store i64 %ld529, ptr %slot88, align 8
  %v530 = load i64, ptr %slot88, align 8
  %v531 = load i64, ptr %slot17, align 8
  %p532 = inttoptr i64 %v531 to ptr
  store i64 %v530, ptr %p532, align 8, !alias.scope !3, !noalias !4
  %v533 = load i64, ptr %slot17, align 8
  %p534 = inttoptr i64 %v533 to ptr
  %ld535 = load i64, ptr %p534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld535, ptr %slot89, align 8
  %v536 = load i64, ptr %slot89, align 8
  %v537 = load i64, ptr %slot12, align 8
  %p538 = inttoptr i64 %v537 to ptr
  store i64 %v536, ptr %p538, align 8, !alias.scope !3, !noalias !4
  %v539 = load i64, ptr %slot12, align 8
  store i64 %v539, ptr %slot90, align 8
  %v540 = load i64, ptr %slot13, align 8
  store i64 %v540, ptr %slot91, align 8
  %v541 = load i64, ptr %slot90, align 8
  %v542 = load i64, ptr %slot91, align 8
  %p543 = inttoptr i64 %v541 to ptr
  %p544 = inttoptr i64 %v542 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p544, ptr %p543, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v545 = load i64, ptr %slot9, align 8
  %p546 = inttoptr i64 %v545 to ptr
  store i32 2, ptr %p546, align 4, !alias.scope !3, !noalias !4
  %v547 = load i64, ptr %slot8, align 8
  %p548 = inttoptr i64 %v547 to ptr
  store i32 1, ptr %p548, align 4, !alias.scope !3, !noalias !4
  %v549 = load i64, ptr %slot11, align 8
  store i64 %v549, ptr %slot92, align 8
  %v550 = load i64, ptr %slot13, align 8
  store i64 %v550, ptr %slot93, align 8
  %v551 = load i64, ptr %slot93, align 8
  %v552 = load i64, ptr %slot92, align 8
  %p553 = inttoptr i64 %v551 to ptr
  %p554 = inttoptr i64 %v552 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p554, ptr %p553, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v555 = load i64, ptr %slot7, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i32 2, ptr %p556, align 4, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot9, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i32, ptr %p558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld559, ptr %slot94, align 8
  %v560 = load i32, ptr %slot94, align 8
  %v561 = load i64, ptr %slot7, align 8
  %p562 = inttoptr i64 %v561 to ptr
  store i32 %v560, ptr %p562, align 4, !alias.scope !3, !noalias !4
  %v563 = load i64, ptr %slot8, align 8
  %p564 = inttoptr i64 %v563 to ptr
  store i32 0, ptr %p564, align 4, !alias.scope !3, !noalias !4
  %v565 = load i64, ptr %slot6, align 8
  %p566 = inttoptr i64 %v565 to ptr
  store i32 1, ptr %p566, align 4, !alias.scope !3, !noalias !4
  %v567 = load i64, ptr %slot92, align 8
  %p568 = inttoptr i64 %v567 to ptr
  %ld569 = load i64, ptr %p568, align 8, !alias.scope !3, !noalias !4
  store i64 %ld569, ptr %slot95, align 8
  %v570 = load i64, ptr %slot95, align 8
  %v571 = load i64, ptr %slot17, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i64 %v570, ptr %p572, align 8, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot20, align 8
  store i64 %v573, ptr %slot96, align 8
  %v574 = load i64, ptr %slot96, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i64 0, ptr %p575, align 8, !alias.scope !3, !noalias !4
  %v576 = load i64, ptr %slot96, align 8
  %p578 = inttoptr i64 %v576 to ptr
  %gep579 = getelementptr i8, ptr %p578, i64 8
  %op577 = ptrtoint ptr %gep579 to i64
  store i64 %op577, ptr %slot97, align 8
  %v580 = load i64, ptr %slot97, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i64 0, ptr %p581, align 8, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot96, align 8
  %p583 = inttoptr i64 %v582 to ptr
  store i32 1, ptr %p583, align 4, !alias.scope !3, !noalias !4
  %v584 = load i64, ptr %slot10, align 8
  %p585 = inttoptr i64 %v584 to ptr
  store i32 1, ptr %p585, align 4, !alias.scope !3, !noalias !4
  %v586 = load i64, ptr %slot17, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %ld588 = load i64, ptr %p587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld588, ptr %slot98, align 8
  %v589 = load i64, ptr %slot98, align 8
  %v590 = load i64, ptr %slot12, align 8
  %p591 = inttoptr i64 %v590 to ptr
  store i64 %v589, ptr %p591, align 8, !alias.scope !3, !noalias !4
  %v592 = load i64, ptr %slot12, align 8
  store i64 %v592, ptr %slot99, align 8
  %v593 = load i64, ptr %slot96, align 8
  %p595 = inttoptr i64 %v593 to ptr
  %gep596 = getelementptr i8, ptr %p595, i64 8
  %op594 = ptrtoint ptr %gep596 to i64
  store i64 %op594, ptr %slot100, align 8
  %v597 = load i64, ptr %slot23, align 8
  store i64 %v597, ptr %slot101, align 8
  %v598 = load i64, ptr %slot17, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i64, ptr %p599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld600, ptr %slot102, align 8
  %v601 = load i64, ptr %slot102, align 8
  %v602 = load i64, ptr %slot12, align 8
  %p603 = inttoptr i64 %v602 to ptr
  store i64 %v601, ptr %p603, align 8, !alias.scope !3, !noalias !4
  %v604 = load i64, ptr %slot12, align 8
  store i64 %v604, ptr %slot103, align 8
  %v605 = load i64, ptr %slot13, align 8
  store i64 %v605, ptr %slot104, align 8
  %v606 = load i64, ptr %slot23, align 8
  store i64 %v606, ptr %slot105, align 8
  %v607 = load i64, ptr %slot103, align 8
  %p609 = inttoptr i64 %v607 to ptr
  %gep610 = getelementptr i8, ptr %p609, i64 0
  %op608 = ptrtoint ptr %gep610 to i64
  store i64 %op608, ptr %slot106, align 8
  %v611 = load i64, ptr %slot106, align 8
  %p612 = inttoptr i64 %v611 to ptr
  %ld613 = load i64, ptr %p612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld613, ptr %slot107, align 8
  %v614 = load i64, ptr %slot107, align 8
  %cmp615 = icmp ne i64 %v614, 0
  %cv616 = zext i1 %cmp615 to i32
  store i32 %cv616, ptr %slot108, align 8
  %v617 = load i32, ptr %slot108, align 8
  %cv618 = zext i32 %v617 to i64
  %cond619 = icmp ne i64 %cv618, 0
  br i1 %cond619, label %bb_rcmoveheader122, label %bb_rcmovenext122
bb_rcmoveheader122:
  %v620 = load i64, ptr %slot107, align 8
  %op621 = sub i64 %v620, 16
  store i64 %op621, ptr %slot109, align 8
  %v622 = load i64, ptr %slot107, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %rgep624 = getelementptr i8, ptr %p623, i64 -16
  %ld625 = load i64, ptr %rgep624, align 8, !alias.scope !9, !noalias !10
  store i64 %ld625, ptr %slot110, align 8
  %v626 = load i64, ptr %slot110, align 8
  %op627 = and i64 %v626, 5764607523034234881
  store i64 %op627, ptr %slot111, align 8
  %v628 = load i64, ptr %slot111, align 8
  %cmp629 = icmp ne i64 %v628, 0
  %cv630 = zext i1 %cmp629 to i32
  store i32 %cv630, ptr %slot112, align 8
  %v631 = load i32, ptr %slot112, align 8
  %cv632 = zext i32 %v631 to i64
  %cond633 = icmp ne i64 %cv632, 0
  br i1 %cond633, label %bb_rcmoveslow119, label %bb_rcmovenext122
bb_rcmovenext122:
  %v634 = load i64, ptr %slot103, align 8
  %v635 = load i64, ptr %slot104, align 8
  %p636 = inttoptr i64 %v634 to ptr
  %p637 = inttoptr i64 %v635 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p637, ptr %p636, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot103, align 8
  %p639 = inttoptr i64 %v638 to ptr
  store i64 0, ptr %p639, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved119
bb_rcmoveslow119:
  %v640 = load i64, ptr %slot22, align 8
  %v641 = load i64, ptr %slot104, align 8
  %v642 = load i64, ptr %slot103, align 8
  %v643 = load i64, ptr %slot105, align 8
  %cv644 = trunc i64 %v643 to i32
  %call645 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v640, i64 %v641, i64 %v642, i32 %cv644) nomerge, !dbg !118
  store i32 %call645, ptr %slot113, align 8
  %v646 = load i32, ptr %slot113, align 8
  %cv647 = zext i32 %v646 to i64
  %cond648 = icmp ne i64 %cv647, 0
  br i1 %cond648, label %bb_rcsuccess129, label %bb_rcfailure129
bb_rcfailure129:
  %v649 = load i64, ptr %slot22, align 8
  %p650 = inttoptr i64 %v649 to ptr
  %call651 = call i32 @myl_rc_take_failure(ptr %p650) nomerge, !dbg !118
  store i32 %call651, ptr %slot114, align 8
  %v652 = load i64, ptr %slot1, align 8
  %p653 = inttoptr i64 %v652 to ptr
  %v654 = load i32, ptr %slot114, align 8
  %call655 = call i32 @myl_qbe_rc_status(ptr %p653, i32 %v654) nomerge, !dbg !118
  store i32 %call655, ptr %slot115, align 8
  br label %bb_failure
bb_rcsuccess129:
  br label %bb_rcmoved119
bb_rcmoved119:
  %v656 = load i64, ptr %slot6, align 8
  %p657 = inttoptr i64 %v656 to ptr
  store i32 0, ptr %p657, align 4, !alias.scope !3, !noalias !4
  %v658 = load i64, ptr %slot9, align 8
  %p659 = inttoptr i64 %v658 to ptr
  store i32 2, ptr %p659, align 4, !alias.scope !3, !noalias !4
  %v660 = load i64, ptr %slot8, align 8
  %p661 = inttoptr i64 %v660 to ptr
  store i32 1, ptr %p661, align 4, !alias.scope !3, !noalias !4
  %v662 = load i64, ptr %slot13, align 8
  store i64 %v662, ptr %slot116, align 8
  %v663 = load i64, ptr %slot116, align 8
  %v664 = load i64, ptr %slot100, align 8
  %p665 = inttoptr i64 %v663 to ptr
  %p666 = inttoptr i64 %v664 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p666, ptr %p665, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot8, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i32 0, ptr %p668, align 4, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot96, align 8
  %v670 = load i64, ptr %slot17, align 8
  %p671 = inttoptr i64 %v670 to ptr
  store i64 %v669, ptr %p671, align 8, !alias.scope !3, !noalias !4
  %p672 = inttoptr i64 ptrtoint (ptr @myl_f_47bdcefe480293c0ff174f7f6719709c24d40be527b15c6437d9047585527b43_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p672, i64 17) "call-inline-cost"="0", !dbg !118
  %v673 = load i64, ptr %slot17, align 8
  %p674 = inttoptr i64 %v673 to ptr
  %ld675 = load i64, ptr %p674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld675, ptr %slot117, align 8
  %v676 = load i64, ptr %slot11, align 8
  store i64 %v676, ptr %slot118, align 8
  %v677 = load i64, ptr %slot117, align 8
  %v678 = load i64, ptr %slot118, align 8
  %p679 = inttoptr i64 %v677 to ptr
  %p680 = inttoptr i64 %v678 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p680, ptr %p679, i64 16, i1 false)
  %v681 = load i64, ptr %slot7, align 8
  %p682 = inttoptr i64 %v681 to ptr
  store i32 2, ptr %p682, align 4, !alias.scope !3, !noalias !4
  %v683 = load i64, ptr %slot6, align 8
  %p684 = inttoptr i64 %v683 to ptr
  store i32 1, ptr %p684, align 4, !alias.scope !3, !noalias !4
  %v685 = load i64, ptr %slot118, align 8
  %v686 = load i64, ptr %slot17, align 8
  %p687 = inttoptr i64 %v686 to ptr
  store i64 %v685, ptr %p687, align 8, !alias.scope !3, !noalias !4
  %v688 = load i64, ptr %slot17, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %ld690 = load i64, ptr %p689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld690, ptr %slot119, align 8
  %v691 = load i64, ptr %slot17, align 8
  %p692 = inttoptr i64 %v691 to ptr
  %ld693 = load i64, ptr %p692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld693, ptr %slot120, align 8
  %v694 = load i64, ptr %slot13, align 8
  store i64 %v694, ptr %slot121, align 8
  %v695 = load i64, ptr %slot23, align 8
  store i64 %v695, ptr %slot122, align 8
  %v696 = load i64, ptr %slot22, align 8
  %v697 = load i64, ptr %slot121, align 8
  %v698 = load i64, ptr %slot120, align 8
  %v699 = load i64, ptr %slot122, align 8
  %cv700 = trunc i64 %v699 to i32
  %call701 = call i32 @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_take(i64 %v696, i64 %v697, i64 %v698, i32 %cv700) nomerge, !dbg !120
  store i32 %call701, ptr %slot123, align 8
  %v702 = load i32, ptr %slot123, align 8
  %cv703 = zext i32 %v702 to i64
  %cond704 = icmp ne i64 %cv703, 0
  br i1 %cond704, label %bb_rcsuccess146, label %bb_rcfailure146
bb_rcfailure146:
  %v705 = load i64, ptr %slot22, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %call707 = call i32 @myl_rc_take_failure(ptr %p706) nomerge, !dbg !120
  store i32 %call707, ptr %slot124, align 8
  %v708 = load i64, ptr %slot1, align 8
  %p709 = inttoptr i64 %v708 to ptr
  %v710 = load i32, ptr %slot124, align 8
  %call711 = call i32 @myl_qbe_rc_status(ptr %p709, i32 %v710) nomerge, !dbg !120
  store i32 %call711, ptr %slot125, align 8
  br label %bb_failure
bb_rcsuccess146:
  %v712 = load i64, ptr %slot6, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i32 0, ptr %p713, align 4, !alias.scope !3, !noalias !4
  %v714 = load i64, ptr %slot9, align 8
  %p715 = inttoptr i64 %v714 to ptr
  store i32 2, ptr %p715, align 4, !alias.scope !3, !noalias !4
  %v716 = load i64, ptr %slot8, align 8
  %p717 = inttoptr i64 %v716 to ptr
  store i32 1, ptr %p717, align 4, !alias.scope !3, !noalias !4
  %v718 = load i64, ptr %slot13, align 8
  store i64 %v718, ptr %slot126, align 8
  %v719 = load i64, ptr %slot8, align 8
  %p720 = inttoptr i64 %v719 to ptr
  store i32 0, ptr %p720, align 4, !alias.scope !3, !noalias !4
  %v721 = load i64, ptr %slot6, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i32, ptr %p722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld723, ptr %slot127, align 8
  %v724 = load i32, ptr %slot127, align 8
  %cv725 = zext i32 %v724 to i64
  %cond726 = icmp ne i64 %cv725, 0
  br i1 %cond726, label %bb_rcslotdrop156, label %bb_rcslotdone156
bb_rcslotdrop156:
  %v727 = load i64, ptr %slot6, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i32 0, ptr %p728, align 4, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot11, align 8
  store i64 %v729, ptr %slot128, align 8
  %v730 = load i64, ptr %slot7, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i32, ptr %p731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld732, ptr %slot129, align 8
  %v733 = load i32, ptr %slot129, align 8
  %op734 = and i32 %v733, 28
  store i32 %op734, ptr %slot130, align 8
  %v735 = load i32, ptr %slot130, align 8
  %cv736 = zext i32 %v735 to i64
  %cond737 = icmp ne i64 %cv736, 0
  br i1 %cond737, label %bb_rcslotrole156, label %bb_rcslotowner156
bb_rcslotrole156:
  %v738 = load i64, ptr %slot22, align 8
  store i64 %v738, ptr %slot131, align 8
  %v739 = load i64, ptr %slot131, align 8
  %v740 = load i64, ptr %slot128, align 8
  call void @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_unloan(i64 %v739, i64 %v740) nomerge, !dbg !120
  br label %bb_rcslotdone156
bb_rcslotowner156:
  %v741 = load i64, ptr %slot22, align 8
  store i64 %v741, ptr %slot132, align 8
  %v742 = load i64, ptr %slot132, align 8
  %v743 = load i64, ptr %slot128, align 8
  call void @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_drop(i64 %v742, i64 %v743) nomerge, !dbg !120
  br label %bb_rcslotdone156
bb_rcslotdone156:
  %v744 = load i64, ptr %slot126, align 8
  %p745 = inttoptr i64 %v744 to ptr
  %ret746 = load { i64, i64 }, ptr %p745, align 8
  ret { i64, i64 } %ret746
bb_i19:
  %v747 = load i64, ptr %slot17, align 8
  %p748 = inttoptr i64 %v747 to ptr
  store i64 0, ptr %p748, align 8, !alias.scope !3, !noalias !4
  %v749 = load i64, ptr %slot21, align 8
  store i64 %v749, ptr %slot133, align 8
  %v750 = load i64, ptr %slot133, align 8
  %p751 = inttoptr i64 %v750 to ptr
  store i64 0, ptr %p751, align 8, !alias.scope !3, !noalias !4
  %v752 = load i64, ptr %slot133, align 8
  %p754 = inttoptr i64 %v752 to ptr
  %gep755 = getelementptr i8, ptr %p754, i64 8
  %op753 = ptrtoint ptr %gep755 to i64
  store i64 %op753, ptr %slot134, align 8
  %v756 = load i64, ptr %slot134, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i64 0, ptr %p757, align 8, !alias.scope !3, !noalias !4
  %v758 = load i64, ptr %slot133, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i32 0, ptr %p759, align 4, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot10, align 8
  %p761 = inttoptr i64 %v760 to ptr
  store i32 1, ptr %p761, align 4, !alias.scope !3, !noalias !4
  %v762 = load i64, ptr %slot17, align 8
  store i64 %v762, ptr %slot135, align 8
  %v763 = load i64, ptr %slot133, align 8
  %p765 = inttoptr i64 %v763 to ptr
  %gep766 = getelementptr i8, ptr %p765, i64 8
  %op764 = ptrtoint ptr %gep766 to i64
  store i64 %op764, ptr %slot136, align 8
  %v767 = load i64, ptr %slot23, align 8
  store i64 %v767, ptr %slot137, align 8
  store i64 0, ptr %slot138, align 8
  %v768 = load i64, ptr %slot133, align 8
  %v769 = load i64, ptr %slot17, align 8
  %p770 = inttoptr i64 %v769 to ptr
  store i64 %v768, ptr %p770, align 8, !alias.scope !3, !noalias !4
  %v771 = load i64, ptr %slot17, align 8
  %p772 = inttoptr i64 %v771 to ptr
  %ld773 = load i64, ptr %p772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld773, ptr %slot139, align 8
  %v774 = load i64, ptr %slot11, align 8
  store i64 %v774, ptr %slot140, align 8
  %v775 = load i64, ptr %slot139, align 8
  %v776 = load i64, ptr %slot140, align 8
  %p777 = inttoptr i64 %v775 to ptr
  %p778 = inttoptr i64 %v776 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p778, ptr %p777, i64 16, i1 false)
  %v779 = load i64, ptr %slot7, align 8
  %p780 = inttoptr i64 %v779 to ptr
  store i32 2, ptr %p780, align 4, !alias.scope !3, !noalias !4
  %v781 = load i64, ptr %slot6, align 8
  %p782 = inttoptr i64 %v781 to ptr
  store i32 1, ptr %p782, align 4, !alias.scope !3, !noalias !4
  %v783 = load i64, ptr %slot140, align 8
  %v784 = load i64, ptr %slot17, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i64 %v783, ptr %p785, align 8, !alias.scope !3, !noalias !4
  %v786 = load i64, ptr %slot17, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i64, ptr %p787, align 8, !alias.scope !3, !noalias !4
  store i64 %ld788, ptr %slot141, align 8
  %v789 = load i64, ptr %slot17, align 8
  %p790 = inttoptr i64 %v789 to ptr
  %ld791 = load i64, ptr %p790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld791, ptr %slot142, align 8
  %v792 = load i64, ptr %slot13, align 8
  store i64 %v792, ptr %slot143, align 8
  %v793 = load i64, ptr %slot23, align 8
  store i64 %v793, ptr %slot144, align 8
  %v794 = load i64, ptr %slot22, align 8
  %v795 = load i64, ptr %slot143, align 8
  %v796 = load i64, ptr %slot142, align 8
  %v797 = load i64, ptr %slot144, align 8
  %cv798 = trunc i64 %v797 to i32
  %call799 = call i32 @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_take(i64 %v794, i64 %v795, i64 %v796, i32 %cv798) nomerge, !dbg !122
  store i32 %call799, ptr %slot145, align 8
  %v800 = load i32, ptr %slot145, align 8
  %cv801 = zext i32 %v800 to i64
  %cond802 = icmp ne i64 %cv801, 0
  br i1 %cond802, label %bb_rcsuccess180, label %bb_rcfailure180
bb_rcfailure180:
  %v803 = load i64, ptr %slot22, align 8
  %p804 = inttoptr i64 %v803 to ptr
  %call805 = call i32 @myl_rc_take_failure(ptr %p804) nomerge, !dbg !122
  store i32 %call805, ptr %slot146, align 8
  %v806 = load i64, ptr %slot1, align 8
  %p807 = inttoptr i64 %v806 to ptr
  %v808 = load i32, ptr %slot146, align 8
  %call809 = call i32 @myl_qbe_rc_status(ptr %p807, i32 %v808) nomerge, !dbg !122
  store i32 %call809, ptr %slot147, align 8
  br label %bb_failure
bb_rcsuccess180:
  %v810 = load i64, ptr %slot6, align 8
  %p811 = inttoptr i64 %v810 to ptr
  store i32 0, ptr %p811, align 4, !alias.scope !3, !noalias !4
  %v812 = load i64, ptr %slot9, align 8
  %p813 = inttoptr i64 %v812 to ptr
  store i32 2, ptr %p813, align 4, !alias.scope !3, !noalias !4
  %v814 = load i64, ptr %slot8, align 8
  %p815 = inttoptr i64 %v814 to ptr
  store i32 1, ptr %p815, align 4, !alias.scope !3, !noalias !4
  %v816 = load i64, ptr %slot13, align 8
  store i64 %v816, ptr %slot148, align 8
  %v817 = load i64, ptr %slot8, align 8
  %p818 = inttoptr i64 %v817 to ptr
  store i32 0, ptr %p818, align 4, !alias.scope !3, !noalias !4
  %v819 = load i64, ptr %slot6, align 8
  %p820 = inttoptr i64 %v819 to ptr
  %ld821 = load i32, ptr %p820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld821, ptr %slot149, align 8
  %v822 = load i32, ptr %slot149, align 8
  %cv823 = zext i32 %v822 to i64
  %cond824 = icmp ne i64 %cv823, 0
  br i1 %cond824, label %bb_rcslotdrop190, label %bb_rcslotdone190
bb_rcslotdrop190:
  %v825 = load i64, ptr %slot6, align 8
  %p826 = inttoptr i64 %v825 to ptr
  store i32 0, ptr %p826, align 4, !alias.scope !3, !noalias !4
  %v827 = load i64, ptr %slot11, align 8
  store i64 %v827, ptr %slot150, align 8
  %v828 = load i64, ptr %slot7, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %ld830 = load i32, ptr %p829, align 4, !alias.scope !3, !noalias !4
  store i32 %ld830, ptr %slot151, align 8
  %v831 = load i32, ptr %slot151, align 8
  %op832 = and i32 %v831, 28
  store i32 %op832, ptr %slot152, align 8
  %v833 = load i32, ptr %slot152, align 8
  %cv834 = zext i32 %v833 to i64
  %cond835 = icmp ne i64 %cv834, 0
  br i1 %cond835, label %bb_rcslotrole190, label %bb_rcslotowner190
bb_rcslotrole190:
  %v836 = load i64, ptr %slot22, align 8
  store i64 %v836, ptr %slot153, align 8
  %v837 = load i64, ptr %slot153, align 8
  %v838 = load i64, ptr %slot150, align 8
  call void @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_unloan(i64 %v837, i64 %v838) nomerge, !dbg !122
  br label %bb_rcslotdone190
bb_rcslotowner190:
  %v839 = load i64, ptr %slot22, align 8
  store i64 %v839, ptr %slot154, align 8
  %v840 = load i64, ptr %slot154, align 8
  %v841 = load i64, ptr %slot150, align 8
  call void @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_drop(i64 %v840, i64 %v841) nomerge, !dbg !122
  br label %bb_rcslotdone190
bb_rcslotdone190:
  %v842 = load i64, ptr %slot148, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %ret844 = load { i64, i64 }, ptr %p843, align 8
  ret { i64, i64 } %ret844
bb_failure:
  %v845 = load i64, ptr %slot5, align 8
  %p846 = inttoptr i64 %v845 to ptr
  call void @llvm.memset.p0.i64(ptr %p846, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v847 = load i64, ptr %slot5, align 8
  %p848 = inttoptr i64 %v847 to ptr
  %ret849 = load { i64, i64 }, ptr %p848, align 8
  ret { i64, i64 } %ret849
bb_entry_failure:
  %v850 = load i64, ptr %slot5, align 8
  %p851 = inttoptr i64 %v850 to ptr
  call void @llvm.memset.p0.i64(ptr %p851, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !122
  %v852 = load i64, ptr %slot5, align 8
  %p853 = inttoptr i64 %v852 to ptr
  %ret854 = load { i64, i64 }, ptr %p853, align 8
  ret { i64, i64 } %ret854
}

@myl_f_47bdcefe480293c0ff174f7f6719709c24d40be527b15c6437d9047585527b43_meta = external global i8, align 8
@myl_lit_0fd5cd837248232ba0243aa952e6cae898dcaf640f99b606fe3db33b738ccc18 = external global i8, align 8
@myl_lit_39b669ecaea859d8e7dd47a58db57c5345b1deb3ccc2541b691370cc2f5b7110 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare i64 @myl_qbe_clock_advance(ptr, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_drop(i64, i64)
declare i32 @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_dcf64ccb6a161c9b43e667bff6d3ab2dcf7b976bfb53763233702c41b89caa4a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_47bdcefe480293c0ff174f7f6719709c24d40be527b15c6437d9047585527b43", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_47bdcefe480293c0ff174f7f6719709c24d40be527b15c6437d9047585527b43", linkageName: "myl_f_47bdcefe480293c0ff174f7f6719709c24d40be527b15c6437d9047585527b43", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16357252056488969855, i64 0, !"myl_f_47bdcefe480293c0ff174f7f6719709c24d40be527b15c6437d9047585527b43"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!112 = !DILocation(line: 4, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!114 = !DILocation(line: 11, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!116 = !DILocation(line: 12, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!118 = !DILocation(line: 18, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!120 = !DILocation(line: 19, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!122 = !DILocation(line: 22, column: 0, scope: !123)
