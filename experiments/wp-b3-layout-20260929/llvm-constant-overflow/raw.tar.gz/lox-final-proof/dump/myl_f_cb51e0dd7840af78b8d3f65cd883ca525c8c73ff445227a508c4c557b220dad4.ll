target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_cb51e0dd7840af78b8d3f65cd883ca525c8c73ff445227a508c4c557b220dad4(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v52 = load i64, ptr %slot1, align 8
  %op53 = add i64 %v52, 32
  store i64 %op53, ptr %slot3, align 8
  %mem54 = alloca i8, i64 16, align 8
  %ptr55 = ptrtoint ptr %mem54 to i64
  store i64 %ptr55, ptr %slot4, align 8
  %mem56 = alloca i8, i64 8, align 8
  %ptr57 = ptrtoint ptr %mem56 to i64
  store i64 %ptr57, ptr %slot5, align 8
  %mem58 = alloca i8, i64 8, align 8
  %ptr59 = ptrtoint ptr %mem58 to i64
  store i64 %ptr59, ptr %slot6, align 8
  %mem60 = alloca i8, i64 8, align 8
  %ptr61 = ptrtoint ptr %mem60 to i64
  store i64 %ptr61, ptr %slot7, align 8
  %mem62 = alloca i8, i64 8, align 8
  %ptr63 = ptrtoint ptr %mem62 to i64
  store i64 %ptr63, ptr %slot8, align 8
  %mem64 = alloca i8, i64 8, align 8
  %ptr65 = ptrtoint ptr %mem64 to i64
  store i64 %ptr65, ptr %slot9, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem66 = alloca i8, i64 8, align 8
  %ptr67 = ptrtoint ptr %mem66 to i64
  store i64 %ptr67, ptr %slot10, align 8
  %v68 = load i64, ptr %slot1, align 8
  %op69 = add i64 %v68, 64
  store i64 %op69, ptr %slot11, align 8
  %v70 = load i64, ptr %slot11, align 8
  %p71 = inttoptr i64 %v70 to ptr
  %ld72 = load i64, ptr %p71, align 8, !alias.scope !4, !noalias !3
  store i64 %ld72, ptr %slot12, align 8
  %stack73 = call ptr @llvm.stacksave()
  %stackaddr74 = ptrtoint ptr %stack73 to i64
  %v75 = load i64, ptr %slot12, align 8
  %cmp76 = icmp ult i64 %stackaddr74, %v75
  %cv77 = zext i1 %cmp76 to i64
  store i64 %cv77, ptr %slot13, align 8
  %v78 = load i64, ptr %slot13, align 8
  %cond79 = icmp ne i64 %v78, 0
  br i1 %cond79, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v80 = load i64, ptr %slot1, align 8
  %p81 = inttoptr i64 %v80 to ptr
  call void @myl_qbe_fail_frame(ptr %p81) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v82 = load i64, ptr %slot6, align 8
  %p83 = inttoptr i64 %v82 to ptr
  store i64 0, ptr %p83, align 8, !alias.scope !3, !noalias !4
  %v84 = load i64, ptr %slot2, align 8
  %v85 = load i64, ptr %slot5, align 8
  %p86 = inttoptr i64 %v85 to ptr
  store i64 %v84, ptr %p86, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v87 = load i64, ptr %slot5, align 8
  %p88 = inttoptr i64 %v87 to ptr
  %ld89 = load i64, ptr %p88, align 8, !alias.scope !3, !noalias !4
  store i64 %ld89, ptr %slot14, align 8
  %v90 = load i64, ptr %slot14, align 8
  %v91 = load i64, ptr %slot8, align 8
  %p92 = inttoptr i64 %v91 to ptr
  store i64 %v90, ptr %p92, align 8, !alias.scope !3, !noalias !4
  %v93 = load i64, ptr %slot8, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %ld95 = load i64, ptr %p94, align 8, !alias.scope !3, !noalias !4
  store i64 %ld95, ptr %slot15, align 8
  %v96 = load i64, ptr %slot15, align 8
  %op97 = add i64 %v96, 0
  store i64 %op97, ptr %slot16, align 8
  %v98 = load i64, ptr %slot16, align 8
  %p99 = inttoptr i64 %v98 to ptr
  %ld100 = load i64, ptr %p99, align 8, !alias.scope !4, !noalias !3
  store i64 %ld100, ptr %slot17, align 8
  %v101 = load i64, ptr %slot17, align 8
  %v102 = load i64, ptr %slot8, align 8
  %p103 = inttoptr i64 %v102 to ptr
  store i64 %v101, ptr %p103, align 8, !alias.scope !3, !noalias !4
  %v104 = load i64, ptr %slot8, align 8
  %p105 = inttoptr i64 %v104 to ptr
  %ld106 = load i64, ptr %p105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld106, ptr %slot18, align 8
  %v107 = load i64, ptr %slot18, align 8
  %v108 = load i64, ptr %slot6, align 8
  %p109 = inttoptr i64 %v108 to ptr
  store i64 %v107, ptr %p109, align 8, !alias.scope !3, !noalias !4
  %v110 = load i64, ptr %slot5, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld112, ptr %slot19, align 8
  %v113 = load i64, ptr %slot19, align 8
  %v114 = load i64, ptr %slot8, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 %v113, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot8, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot20, align 8
  %v119 = load i64, ptr %slot1, align 8
  %v120 = load i64, ptr %slot20, align 8
  %call121 = call i64 @myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2(i64 %v119, i64 %v120) nomerge, !dbg !112
  store i64 %call121, ptr %slot21, align 8
  %v122 = load i64, ptr %slot21, align 8
  %v123 = load i64, ptr %slot8, align 8
  %p124 = inttoptr i64 %v123 to ptr
  store i64 %v122, ptr %p124, align 8, !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot8, align 8
  %p126 = inttoptr i64 %v125 to ptr
  %ld127 = load i64, ptr %p126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld127, ptr %slot22, align 8
  %v128 = load i64, ptr %slot22, align 8
  %v129 = load i64, ptr %slot7, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i64 %v128, ptr %p130, align 8, !alias.scope !3, !noalias !4
  %v131 = load i64, ptr %slot7, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %ld133 = load i64, ptr %p132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld133, ptr %slot23, align 8
  %v134 = load i64, ptr %slot23, align 8
  %v135 = load i64, ptr %slot8, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i64 %v134, ptr %p136, align 8, !alias.scope !3, !noalias !4
  %v137 = load i64, ptr %slot9, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 0, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot9, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot24, align 8
  %v142 = load i64, ptr %slot8, align 8
  %p143 = inttoptr i64 %v142 to ptr
  %ld144 = load i64, ptr %p143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld144, ptr %slot25, align 8
  %v145 = load i64, ptr %slot25, align 8
  %v146 = load i64, ptr %slot24, align 8
  %cmp147 = icmp slt i64 %v145, %v146
  %cv148 = zext i1 %cmp147 to i64
  store i64 %cv148, ptr %slot26, align 8
  %v149 = load i64, ptr %slot26, align 8
  %v150 = load i64, ptr %slot8, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot8, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot27, align 8
  %v155 = load i64, ptr %slot27, align 8
  %cond156 = icmp ne i64 %v155, 0
  br i1 %cond156, label %bb_next41, label %bb_i15
bb_next41:
  %v157 = load i64, ptr %slot6, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %ld159 = load i64, ptr %p158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld159, ptr %slot28, align 8
  %v160 = load i64, ptr %slot28, align 8
  %op161 = add i64 %v160, 0
  store i64 %op161, ptr %slot29, align 8
  %v162 = load i64, ptr %slot29, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !6, !noalias !7
  store i64 %ld164, ptr %slot30, align 8
  %v165 = load i64, ptr %slot30, align 8
  %v166 = load i64, ptr %slot8, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot8, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot31, align 8
  %v171 = load i64, ptr %slot31, align 8
  %cmp172 = icmp ugt i64 %v171, 9223372036854775807
  %cv173 = zext i1 %cmp172 to i64
  store i64 %cv173, ptr %slot32, align 8
  %v174 = load i64, ptr %slot32, align 8
  %cond175 = icmp ne i64 %v174, 0
  br i1 %cond175, label %bb_cast_overflow46, label %bb_cast_ok46
bb_cast_overflow46:
  %v176 = load i64, ptr %slot1, align 8
  %p177 = inttoptr i64 %v176 to ptr
  %v178 = load i64, ptr %slot31, align 8
  call void @myl_qbe_fail_cast(ptr %p177, i64 %v178, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok46:
  %v179 = load i64, ptr %slot31, align 8
  %v180 = load i64, ptr %slot8, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i64 %v179, ptr %p181, align 8, !alias.scope !3, !noalias !4
  %v182 = load i64, ptr %slot7, align 8
  %p183 = inttoptr i64 %v182 to ptr
  %ld184 = load i64, ptr %p183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld184, ptr %slot33, align 8
  %v185 = load i64, ptr %slot33, align 8
  %v186 = load i64, ptr %slot9, align 8
  %p187 = inttoptr i64 %v186 to ptr
  store i64 %v185, ptr %p187, align 8, !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot9, align 8
  %p189 = inttoptr i64 %v188 to ptr
  %ld190 = load i64, ptr %p189, align 8, !alias.scope !3, !noalias !4
  store i64 %ld190, ptr %slot34, align 8
  %v191 = load i64, ptr %slot8, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i64, ptr %p192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld193, ptr %slot35, align 8
  %v194 = load i64, ptr %slot35, align 8
  %v195 = load i64, ptr %slot34, align 8
  %ovpair197 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v194, i64 %v195)
  %op196 = extractvalue { i64, i1 } %ovpair197, 0
  %ov198 = extractvalue { i64, i1 } %ovpair197, 1
  store i64 %op196, ptr %slot36, align 8
  %v199 = load i64, ptr %slot35, align 8
  %v200 = load i64, ptr %slot36, align 8
  %op201 = xor i64 %v199, %v200
  store i64 %op201, ptr %slot37, align 8
  %v202 = load i64, ptr %slot34, align 8
  %v203 = load i64, ptr %slot36, align 8
  %op204 = xor i64 %v202, %v203
  store i64 %op204, ptr %slot38, align 8
  %v205 = load i64, ptr %slot37, align 8
  %v206 = load i64, ptr %slot38, align 8
  %op207 = and i64 %v205, %v206
  store i64 %op207, ptr %slot39, align 8
  %cv208 = zext i1 %ov198 to i64
  store i64 %cv208, ptr %slot40, align 8
  %v209 = load i64, ptr %slot40, align 8
  %cond210 = icmp ne i64 %v209, 0
  br i1 %cond210, label %bb_overflow50, label %bb_checked50
bb_overflow50:
  %v211 = load i64, ptr %slot1, align 8
  %p212 = inttoptr i64 %v211 to ptr
  %v213 = load i64, ptr %slot35, align 8
  %v214 = load i64, ptr %slot34, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p212, i64 0, i64 %v213, i64 %v214, i64 64) nomerge, !dbg !116
  unreachable
bb_checked50:
  %v215 = load i64, ptr %slot36, align 8
  %v216 = load i64, ptr %slot8, align 8
  %p217 = inttoptr i64 %v216 to ptr
  store i64 %v215, ptr %p217, align 8, !alias.scope !3, !noalias !4
  %v218 = load i64, ptr %slot8, align 8
  %p219 = inttoptr i64 %v218 to ptr
  %ld220 = load i64, ptr %p219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld220, ptr %slot41, align 8
  %v221 = load i64, ptr %slot41, align 8
  %v222 = load i64, ptr %slot7, align 8
  %p223 = inttoptr i64 %v222 to ptr
  store i64 %v221, ptr %p223, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v224 = load i64, ptr %slot7, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i64, ptr %p225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld226, ptr %slot42, align 8
  %v227 = load i64, ptr %slot42, align 8
  %v228 = load i64, ptr %slot8, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i64 %v227, ptr %p229, align 8, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot6, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot43, align 8
  %v233 = load i64, ptr %slot8, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot44, align 8
  %v236 = load i64, ptr %slot43, align 8
  %p237 = inttoptr i64 %v236 to ptr
  %ld238 = load i64, ptr %p237, align 8, !alias.scope !6, !noalias !7
  store i64 %ld238, ptr %slot45, align 8
  %v239 = load i64, ptr %slot44, align 8
  %v240 = load i64, ptr %slot45, align 8
  %cmp241 = icmp ult i64 %v239, %v240
  %cv242 = zext i1 %cmp241 to i64
  store i64 %cv242, ptr %slot46, align 8
  %v243 = load i64, ptr %slot46, align 8
  %cond244 = icmp ne i64 %v243, 0
  br i1 %cond244, label %bb_success62, label %bb_failed62
bb_failed62:
  %v245 = load i64, ptr %slot1, align 8
  %p246 = inttoptr i64 %v245 to ptr
  %v247 = load i64, ptr %slot44, align 8
  %v248 = load i64, ptr %slot45, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p246, i64 %v247, i64 %v248) nomerge, !dbg !118
  unreachable
bb_success62:
  %v249 = load i64, ptr %slot43, align 8
  %op250 = add i64 %v249, 32
  store i64 %op250, ptr %slot47, align 8
  %v251 = load i64, ptr %slot47, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i64, ptr %p252, align 8, !alias.scope !6, !noalias !7
  store i64 %ld253, ptr %slot48, align 8
  %v254 = load i64, ptr %slot44, align 8
  %op255 = mul i64 %v254, 16
  store i64 %op255, ptr %slot49, align 8
  %v256 = load i64, ptr %slot48, align 8
  %v257 = load i64, ptr %slot49, align 8
  %op258 = add i64 %v256, %v257
  store i64 %op258, ptr %slot50, align 8
  %v259 = load i64, ptr %slot50, align 8
  %v260 = load i64, ptr %slot8, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i64 %v259, ptr %p261, align 8, !alias.scope !3, !noalias !4
  %v262 = load i64, ptr %slot8, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %ld264 = load i64, ptr %p263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld264, ptr %slot51, align 8
  %v265 = load i64, ptr %slot51, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ret267 = load { i64, i64 }, ptr %p266, align 8
  ret { i64, i64 } %ret267
bb_failure:
  %v268 = load i64, ptr %slot4, align 8
  %p269 = inttoptr i64 %v268 to ptr
  call void @llvm.memset.p0.i64(ptr %p269, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v270 = load i64, ptr %slot4, align 8
  %p271 = inttoptr i64 %v270 to ptr
  %ret272 = load { i64, i64 }, ptr %p271, align 8
  ret { i64, i64 } %ret272
bb_entry_failure:
  %v273 = load i64, ptr %slot4, align 8
  %p274 = inttoptr i64 %v273 to ptr
  call void @llvm.memset.p0.i64(ptr %p274, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !120
  %v275 = load i64, ptr %slot4, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ret277 = load { i64, i64 }, ptr %p276, align 8
  ret { i64, i64 } %ret277
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_fa0a495025828a635f8203a4c546663c235c2574b972f1294569bb6fadb2fcc2(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_cb51e0dd7840af78b8d3f65cd883ca525c8c73ff445227a508c4c557b220dad4", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_cb51e0dd7840af78b8d3f65cd883ca525c8c73ff445227a508c4c557b220dad4", linkageName: "myl_f_cb51e0dd7840af78b8d3f65cd883ca525c8c73ff445227a508c4c557b220dad4", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 4181864839916009005, i64 0, !"myl_f_cb51e0dd7840af78b8d3f65cd883ca525c8c73ff445227a508c4c557b220dad4"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!112 = !DILocation(line: 5, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!114 = !DILocation(line: 12, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!116 = !DILocation(line: 14, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!118 = !DILocation(line: 17, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!120 = !DILocation(line: 18, column: 0, scope: !121)
