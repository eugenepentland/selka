target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i32, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i32, align 8
  %slot27 = alloca i32, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v116 = load i64, ptr %slot1, align 8
  %op117 = add i64 %v116, 32
  store i64 %op117, ptr %slot3, align 8
  %mem118 = alloca i8, i64 88, align 8
  %ptr119 = ptrtoint ptr %mem118 to i64
  store i64 %ptr119, ptr %slot4, align 8
  %mem120 = alloca i8, i64 8, align 8
  %ptr121 = ptrtoint ptr %mem120 to i64
  store i64 %ptr121, ptr %slot5, align 8
  %mem122 = alloca i8, i64 8, align 8
  %ptr123 = ptrtoint ptr %mem122 to i64
  store i64 %ptr123, ptr %slot6, align 8
  %mem124 = alloca i8, i64 8, align 8
  %ptr125 = ptrtoint ptr %mem124 to i64
  store i64 %ptr125, ptr %slot7, align 8
  %mem126 = alloca i8, i64 8, align 8
  %ptr127 = ptrtoint ptr %mem126 to i64
  store i64 %ptr127, ptr %slot8, align 8
  %mem128 = alloca i8, i64 392, align 8
  %ptr129 = ptrtoint ptr %mem128 to i64
  store i64 %ptr129, ptr %slot9, align 8
  %mem130 = alloca i8, i64 392, align 8
  %ptr131 = ptrtoint ptr %mem130 to i64
  store i64 %ptr131, ptr %slot10, align 8
  %mem132 = alloca i8, i64 8, align 8
  %ptr133 = ptrtoint ptr %mem132 to i64
  store i64 %ptr133, ptr %slot11, align 8
  %mem134 = alloca i8, i64 8, align 8
  %ptr135 = ptrtoint ptr %mem134 to i64
  store i64 %ptr135, ptr %slot12, align 8
  %mem136 = alloca i8, i64 8, align 8
  %ptr137 = ptrtoint ptr %mem136 to i64
  store i64 %ptr137, ptr %slot13, align 8
  %mem138 = alloca i8, i64 8, align 8
  %ptr139 = ptrtoint ptr %mem138 to i64
  store i64 %ptr139, ptr %slot14, align 8
  %mem140 = alloca i8, i64 8, align 8
  %ptr141 = ptrtoint ptr %mem140 to i64
  store i64 %ptr141, ptr %slot15, align 8
  %mem142 = alloca i8, i64 8, align 8
  %ptr143 = ptrtoint ptr %mem142 to i64
  store i64 %ptr143, ptr %slot16, align 8
  %mem144 = alloca i8, i64 88, align 8
  %ptr145 = ptrtoint ptr %mem144 to i64
  store i64 %ptr145, ptr %slot17, align 8
  %v146 = load i64, ptr %slot12, align 8
  %p147 = inttoptr i64 %v146 to ptr
  store i64 0, ptr %p147, align 8, !alias.scope !3, !noalias !4
  %v148 = load i64, ptr %slot13, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i64 0, ptr %p149, align 8, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot2, align 8
  %v151 = load i64, ptr %slot11, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i64 %v150, ptr %p152, align 8, !alias.scope !3, !noalias !4
  %v153 = load i64, ptr %slot1, align 8
  %p154 = inttoptr i64 %v153 to ptr
  %call155 = call ptr @myl_qbe_heap(ptr %p154) nomerge, !dbg !110
  %calladdr156 = ptrtoint ptr %call155 to i64
  store i64 %calladdr156, ptr %slot18, align 8
  %v157 = load i64, ptr %slot1, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %call159 = call i64 @myl_qbe_region_mark(ptr %p158) nomerge, !dbg !110
  store i64 %call159, ptr %slot19, align 8
  %v160 = load i64, ptr %slot5, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i32 0, ptr %p161, align 4, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot6, align 8
  %p163 = inttoptr i64 %v162 to ptr
  store i32 0, ptr %p163, align 4, !alias.scope !3, !noalias !4
  %v164 = load i64, ptr %slot7, align 8
  %p165 = inttoptr i64 %v164 to ptr
  store i32 0, ptr %p165, align 4, !alias.scope !3, !noalias !4
  %v166 = load i64, ptr %slot8, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i32 0, ptr %p167, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v168 = load i64, ptr %slot11, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot20, align 8
  %v171 = load i64, ptr %slot20, align 8
  %v172 = load i64, ptr %slot15, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i64 %v171, ptr %p173, align 8, !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot15, align 8
  %p175 = inttoptr i64 %v174 to ptr
  %ld176 = load i64, ptr %p175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld176, ptr %slot21, align 8
  %v177 = load i64, ptr %slot21, align 8
  %op178 = add i64 %v177, 376
  store i64 %op178, ptr %slot22, align 8
  %v179 = load i64, ptr %slot22, align 8
  %p180 = inttoptr i64 %v179 to ptr
  %ld181 = load i64, ptr %p180, align 8, !alias.scope !4, !noalias !3
  store i64 %ld181, ptr %slot23, align 8
  %v182 = load i64, ptr %slot23, align 8
  %v183 = load i64, ptr %slot15, align 8
  %p184 = inttoptr i64 %v183 to ptr
  store i64 %v182, ptr %p184, align 8, !alias.scope !3, !noalias !4
  %v185 = load i64, ptr %slot5, align 8
  %p186 = inttoptr i64 %v185 to ptr
  %ld187 = load i32, ptr %p186, align 4, !alias.scope !3, !noalias !4
  store i32 %ld187, ptr %slot24, align 8
  %v188 = load i32, ptr %slot24, align 8
  %cv189 = zext i32 %v188 to i64
  %cond190 = icmp ne i64 %cv189, 0
  br i1 %cond190, label %bb_rcslotdrop9, label %bb_rcslotdone9
bb_rcslotdrop9:
  %v191 = load i64, ptr %slot5, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i32 0, ptr %p192, align 4, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot9, align 8
  store i64 %v193, ptr %slot25, align 8
  %v194 = load i64, ptr %slot6, align 8
  %p195 = inttoptr i64 %v194 to ptr
  %ld196 = load i32, ptr %p195, align 4, !alias.scope !3, !noalias !4
  store i32 %ld196, ptr %slot26, align 8
  %v197 = load i32, ptr %slot26, align 8
  %op198 = and i32 %v197, 28
  store i32 %op198, ptr %slot27, align 8
  %v199 = load i32, ptr %slot27, align 8
  %cv200 = zext i32 %v199 to i64
  %cond201 = icmp ne i64 %cv200, 0
  br i1 %cond201, label %bb_rcslotrole9, label %bb_rcslotowner9
bb_rcslotrole9:
  %v202 = load i64, ptr %slot18, align 8
  store i64 %v202, ptr %slot28, align 8
  %v203 = load i64, ptr %slot28, align 8
  %v204 = load i64, ptr %slot25, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v203, i64 %v204) nomerge, !dbg !112
  br label %bb_rcslotdone9
bb_rcslotowner9:
  %v205 = load i64, ptr %slot18, align 8
  store i64 %v205, ptr %slot29, align 8
  %v206 = load i64, ptr %slot29, align 8
  %v207 = load i64, ptr %slot25, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v206, i64 %v207) nomerge, !dbg !112
  br label %bb_rcslotdone9
bb_rcslotdone9:
  %v208 = load i64, ptr %slot15, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot30, align 8
  %v211 = load i64, ptr %slot30, align 8
  %v212 = load i64, ptr %slot13, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot11, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot31, align 8
  %v217 = load i64, ptr %slot31, align 8
  %v218 = load i64, ptr %slot15, align 8
  %p219 = inttoptr i64 %v218 to ptr
  store i64 %v217, ptr %p219, align 8, !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot15, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i64, ptr %p221, align 8, !alias.scope !3, !noalias !4
  store i64 %ld222, ptr %slot32, align 8
  %v223 = load i64, ptr %slot32, align 8
  %op224 = add i64 %v223, 376
  store i64 %op224, ptr %slot33, align 8
  %v225 = load i64, ptr %slot33, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !4, !noalias !3
  store i64 %ld227, ptr %slot34, align 8
  %v228 = load i64, ptr %slot34, align 8
  %v229 = load i64, ptr %slot15, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i64 %v228, ptr %p230, align 8, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot5, align 8
  %p232 = inttoptr i64 %v231 to ptr
  %ld233 = load i32, ptr %p232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld233, ptr %slot35, align 8
  %v234 = load i32, ptr %slot35, align 8
  %cv235 = zext i32 %v234 to i64
  %cond236 = icmp ne i64 %cv235, 0
  br i1 %cond236, label %bb_rcslotdrop23, label %bb_rcslotdone23
bb_rcslotdrop23:
  %v237 = load i64, ptr %slot5, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i32 0, ptr %p238, align 4, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot9, align 8
  store i64 %v239, ptr %slot36, align 8
  %v240 = load i64, ptr %slot6, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i32, ptr %p241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld242, ptr %slot37, align 8
  %v243 = load i32, ptr %slot37, align 8
  %op244 = and i32 %v243, 28
  store i32 %op244, ptr %slot38, align 8
  %v245 = load i32, ptr %slot38, align 8
  %cv246 = zext i32 %v245 to i64
  %cond247 = icmp ne i64 %cv246, 0
  br i1 %cond247, label %bb_rcslotrole23, label %bb_rcslotowner23
bb_rcslotrole23:
  %v248 = load i64, ptr %slot18, align 8
  store i64 %v248, ptr %slot39, align 8
  %v249 = load i64, ptr %slot39, align 8
  %v250 = load i64, ptr %slot36, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v249, i64 %v250) nomerge, !dbg !114
  br label %bb_rcslotdone23
bb_rcslotowner23:
  %v251 = load i64, ptr %slot18, align 8
  store i64 %v251, ptr %slot40, align 8
  %v252 = load i64, ptr %slot40, align 8
  %v253 = load i64, ptr %slot36, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v252, i64 %v253) nomerge, !dbg !114
  br label %bb_rcslotdone23
bb_rcslotdone23:
  %v254 = load i64, ptr %slot15, align 8
  %p255 = inttoptr i64 %v254 to ptr
  %ld256 = load i64, ptr %p255, align 8, !alias.scope !3, !noalias !4
  store i64 %ld256, ptr %slot41, align 8
  %v257 = load i64, ptr %slot41, align 8
  %v258 = load i64, ptr %slot12, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i64 %v257, ptr %p259, align 8, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot12, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i64, ptr %p261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld262, ptr %slot42, align 8
  %v263 = load i64, ptr %slot42, align 8
  %op264 = add i64 %v263, 0
  store i64 %op264, ptr %slot43, align 8
  %v265 = load i64, ptr %slot43, align 8
  %p266 = inttoptr i64 %v265 to ptr
  %ld267 = load i64, ptr %p266, align 8, !alias.scope !6, !noalias !7
  store i64 %ld267, ptr %slot44, align 8
  %v268 = load i64, ptr %slot44, align 8
  %v269 = load i64, ptr %slot15, align 8
  %p270 = inttoptr i64 %v269 to ptr
  store i64 %v268, ptr %p270, align 8, !alias.scope !3, !noalias !4
  %v271 = load i64, ptr %slot15, align 8
  %p272 = inttoptr i64 %v271 to ptr
  %ld273 = load i64, ptr %p272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld273, ptr %slot45, align 8
  %v274 = load i64, ptr %slot45, align 8
  %cmp275 = icmp ugt i64 %v274, 9223372036854775807
  %cv276 = zext i1 %cmp275 to i64
  store i64 %cv276, ptr %slot46, align 8
  %v277 = load i64, ptr %slot46, align 8
  %cond278 = icmp ne i64 %v277, 0
  br i1 %cond278, label %bb_cast_overflow36, label %bb_cast_ok36
bb_cast_overflow36:
  %v279 = load i64, ptr %slot1, align 8
  %p280 = inttoptr i64 %v279 to ptr
  %v281 = load i64, ptr %slot45, align 8
  call void @myl_qbe_fail_cast(ptr %p280, i64 %v281, i64 320) nomerge, !dbg !116
  unreachable
bb_cast_ok36:
  %v282 = load i64, ptr %slot45, align 8
  %v283 = load i64, ptr %slot15, align 8
  %p284 = inttoptr i64 %v283 to ptr
  store i64 %v282, ptr %p284, align 8, !alias.scope !3, !noalias !4
  %v285 = load i64, ptr %slot16, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i64 1, ptr %p286, align 8, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot16, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot47, align 8
  %v290 = load i64, ptr %slot15, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i64, ptr %p291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld292, ptr %slot48, align 8
  %v293 = load i64, ptr %slot48, align 8
  %v294 = load i64, ptr %slot47, align 8
  %ovpair296 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v293, i64 %v294)
  %op295 = extractvalue { i64, i1 } %ovpair296, 0
  %ov297 = extractvalue { i64, i1 } %ovpair296, 1
  store i64 %op295, ptr %slot49, align 8
  %cv298 = zext i1 %ov297 to i64
  store i64 %cv298, ptr %slot50, align 8
  %v299 = load i64, ptr %slot50, align 8
  %cond300 = icmp ne i64 %v299, 0
  br i1 %cond300, label %bb_overflow39, label %bb_checked39
bb_overflow39:
  %v301 = load i64, ptr %slot1, align 8
  %p302 = inttoptr i64 %v301 to ptr
  %v303 = load i64, ptr %slot48, align 8
  %v304 = load i64, ptr %slot47, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p302, i64 1, i64 %v303, i64 %v304, i64 64) nomerge, !dbg !118
  unreachable
bb_checked39:
  %v305 = load i64, ptr %slot49, align 8
  %v306 = load i64, ptr %slot15, align 8
  %p307 = inttoptr i64 %v306 to ptr
  store i64 %v305, ptr %p307, align 8, !alias.scope !3, !noalias !4
  %v308 = load i64, ptr %slot15, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %ld310 = load i64, ptr %p309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld310, ptr %slot51, align 8
  %v311 = load i64, ptr %slot51, align 8
  %v312 = load i64, ptr %slot14, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i64 %v311, ptr %p313, align 8, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot14, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %ld316 = load i64, ptr %p315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld316, ptr %slot52, align 8
  %v317 = load i64, ptr %slot52, align 8
  %v318 = load i64, ptr %slot15, align 8
  %p319 = inttoptr i64 %v318 to ptr
  store i64 %v317, ptr %p319, align 8, !alias.scope !3, !noalias !4
  %v320 = load i64, ptr %slot16, align 8
  %p321 = inttoptr i64 %v320 to ptr
  store i64 0, ptr %p321, align 8, !alias.scope !3, !noalias !4
  %v322 = load i64, ptr %slot16, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %ld324 = load i64, ptr %p323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld324, ptr %slot53, align 8
  %v325 = load i64, ptr %slot15, align 8
  %p326 = inttoptr i64 %v325 to ptr
  %ld327 = load i64, ptr %p326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld327, ptr %slot54, align 8
  %v328 = load i64, ptr %slot54, align 8
  %v329 = load i64, ptr %slot53, align 8
  %cmp330 = icmp slt i64 %v328, %v329
  %cv331 = zext i1 %cmp330 to i64
  store i64 %cv331, ptr %slot55, align 8
  %v332 = load i64, ptr %slot55, align 8
  %v333 = load i64, ptr %slot15, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 %v332, ptr %p334, align 8, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot15, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %ld337 = load i64, ptr %p336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld337, ptr %slot56, align 8
  %v338 = load i64, ptr %slot56, align 8
  %cond339 = icmp ne i64 %v338, 0
  br i1 %cond339, label %bb_next47, label %bb_i20
bb_next47:
  %v340 = load i64, ptr %slot13, align 8
  %p341 = inttoptr i64 %v340 to ptr
  %ld342 = load i64, ptr %p341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld342, ptr %slot57, align 8
  %v343 = load i64, ptr %slot57, align 8
  %op344 = add i64 %v343, 0
  store i64 %op344, ptr %slot58, align 8
  %v345 = load i64, ptr %slot58, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !6, !noalias !7
  store i64 %ld347, ptr %slot59, align 8
  %v348 = load i64, ptr %slot59, align 8
  %v349 = load i64, ptr %slot15, align 8
  %p350 = inttoptr i64 %v349 to ptr
  store i64 %v348, ptr %p350, align 8, !alias.scope !3, !noalias !4
  %v351 = load i64, ptr %slot15, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %ld353 = load i64, ptr %p352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld353, ptr %slot60, align 8
  %v354 = load i64, ptr %slot60, align 8
  %cmp355 = icmp ugt i64 %v354, 9223372036854775807
  %cv356 = zext i1 %cmp355 to i64
  store i64 %cv356, ptr %slot61, align 8
  %v357 = load i64, ptr %slot61, align 8
  %cond358 = icmp ne i64 %v357, 0
  br i1 %cond358, label %bb_cast_overflow52, label %bb_cast_ok52
bb_cast_overflow52:
  %v359 = load i64, ptr %slot1, align 8
  %p360 = inttoptr i64 %v359 to ptr
  %v361 = load i64, ptr %slot60, align 8
  call void @myl_qbe_fail_cast(ptr %p360, i64 %v361, i64 320) nomerge, !dbg !120
  unreachable
bb_cast_ok52:
  %v362 = load i64, ptr %slot60, align 8
  %v363 = load i64, ptr %slot15, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i64 %v362, ptr %p364, align 8, !alias.scope !3, !noalias !4
  %v365 = load i64, ptr %slot14, align 8
  %p366 = inttoptr i64 %v365 to ptr
  %ld367 = load i64, ptr %p366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld367, ptr %slot62, align 8
  %v368 = load i64, ptr %slot62, align 8
  %v369 = load i64, ptr %slot16, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i64 %v368, ptr %p370, align 8, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot16, align 8
  %p372 = inttoptr i64 %v371 to ptr
  %ld373 = load i64, ptr %p372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld373, ptr %slot63, align 8
  %v374 = load i64, ptr %slot15, align 8
  %p375 = inttoptr i64 %v374 to ptr
  %ld376 = load i64, ptr %p375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld376, ptr %slot64, align 8
  %v377 = load i64, ptr %slot64, align 8
  %v378 = load i64, ptr %slot63, align 8
  %ovpair380 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v377, i64 %v378)
  %op379 = extractvalue { i64, i1 } %ovpair380, 0
  %ov381 = extractvalue { i64, i1 } %ovpair380, 1
  store i64 %op379, ptr %slot65, align 8
  %v382 = load i64, ptr %slot64, align 8
  %v383 = load i64, ptr %slot65, align 8
  %op384 = xor i64 %v382, %v383
  store i64 %op384, ptr %slot66, align 8
  %v385 = load i64, ptr %slot63, align 8
  %v386 = load i64, ptr %slot65, align 8
  %op387 = xor i64 %v385, %v386
  store i64 %op387, ptr %slot67, align 8
  %v388 = load i64, ptr %slot66, align 8
  %v389 = load i64, ptr %slot67, align 8
  %op390 = and i64 %v388, %v389
  store i64 %op390, ptr %slot68, align 8
  %cv391 = zext i1 %ov381 to i64
  store i64 %cv391, ptr %slot69, align 8
  %v392 = load i64, ptr %slot69, align 8
  %cond393 = icmp ne i64 %v392, 0
  br i1 %cond393, label %bb_overflow56, label %bb_checked56
bb_overflow56:
  %v394 = load i64, ptr %slot1, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %v396 = load i64, ptr %slot64, align 8
  %v397 = load i64, ptr %slot63, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p395, i64 0, i64 %v396, i64 %v397, i64 64) nomerge, !dbg !122
  unreachable
bb_checked56:
  %v398 = load i64, ptr %slot65, align 8
  %v399 = load i64, ptr %slot15, align 8
  %p400 = inttoptr i64 %v399 to ptr
  store i64 %v398, ptr %p400, align 8, !alias.scope !3, !noalias !4
  %v401 = load i64, ptr %slot15, align 8
  %p402 = inttoptr i64 %v401 to ptr
  %ld403 = load i64, ptr %p402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld403, ptr %slot70, align 8
  %v404 = load i64, ptr %slot70, align 8
  %v405 = load i64, ptr %slot14, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 %v404, ptr %p406, align 8, !alias.scope !3, !noalias !4
  br label %bb_i20
bb_i20:
  %v407 = load i64, ptr %slot14, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i64, ptr %p408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld409, ptr %slot71, align 8
  %v410 = load i64, ptr %slot71, align 8
  %v411 = load i64, ptr %slot15, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i64 %v410, ptr %p412, align 8, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot13, align 8
  %p414 = inttoptr i64 %v413 to ptr
  %ld415 = load i64, ptr %p414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld415, ptr %slot72, align 8
  %v416 = load i64, ptr %slot15, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %ld418 = load i64, ptr %p417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld418, ptr %slot73, align 8
  %v419 = load i64, ptr %slot72, align 8
  %p420 = inttoptr i64 %v419 to ptr
  %ld421 = load i64, ptr %p420, align 8, !alias.scope !6, !noalias !7
  store i64 %ld421, ptr %slot74, align 8
  %v422 = load i64, ptr %slot73, align 8
  %v423 = load i64, ptr %slot74, align 8
  %cmp424 = icmp ult i64 %v422, %v423
  %cv425 = zext i1 %cmp424 to i64
  store i64 %cv425, ptr %slot75, align 8
  %v426 = load i64, ptr %slot75, align 8
  %cond427 = icmp ne i64 %v426, 0
  br i1 %cond427, label %bb_success68, label %bb_failed68
bb_failed68:
  %v428 = load i64, ptr %slot1, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %v430 = load i64, ptr %slot73, align 8
  %v431 = load i64, ptr %slot74, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p429, i64 %v430, i64 %v431) nomerge, !dbg !124
  unreachable
bb_success68:
  %v432 = load i64, ptr %slot72, align 8
  %op433 = add i64 %v432, 32
  store i64 %op433, ptr %slot76, align 8
  %v434 = load i64, ptr %slot76, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %ld436 = load i64, ptr %p435, align 8, !alias.scope !6, !noalias !7
  store i64 %ld436, ptr %slot77, align 8
  %v437 = load i64, ptr %slot73, align 8
  %op438 = mul i64 %v437, 88
  store i64 %op438, ptr %slot78, align 8
  %v439 = load i64, ptr %slot77, align 8
  %v440 = load i64, ptr %slot78, align 8
  %op441 = add i64 %v439, %v440
  store i64 %op441, ptr %slot79, align 8
  %v442 = load i64, ptr %slot17, align 8
  store i64 %v442, ptr %slot80, align 8
  %v443 = load i64, ptr %slot79, align 8
  %v444 = load i64, ptr %slot80, align 8
  %p445 = inttoptr i64 %v443 to ptr
  %p446 = inttoptr i64 %v444 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p446, ptr %p445, i64 88, i1 false), !alias.scope !10000000
  %v447 = load i64, ptr %slot80, align 8
  %v448 = load i64, ptr %slot15, align 8
  %p449 = inttoptr i64 %v448 to ptr
  store i64 %v447, ptr %p449, align 8, !alias.scope !3, !noalias !4
  %v450 = load i64, ptr %slot15, align 8
  %p451 = inttoptr i64 %v450 to ptr
  %ld452 = load i64, ptr %p451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld452, ptr %slot81, align 8
  %v453 = load i64, ptr %slot5, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %ld455 = load i32, ptr %p454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld455, ptr %slot82, align 8
  %v456 = load i64, ptr %slot6, align 8
  %p457 = inttoptr i64 %v456 to ptr
  %ld458 = load i32, ptr %p457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld458, ptr %slot83, align 8
  %v459 = load i32, ptr %slot83, align 8
  %op460 = and i32 %v459, 24
  store i32 %op460, ptr %slot83, align 8
  %v461 = load i32, ptr %slot83, align 8
  %cmp462 = icmp eq i32 %v461, 0
  %cv463 = zext i1 %cmp462 to i32
  store i32 %cv463, ptr %slot84, align 8
  %v464 = load i32, ptr %slot82, align 8
  %v465 = load i32, ptr %slot84, align 8
  %op466 = and i32 %v464, %v465
  store i32 %op466, ptr %slot85, align 8
  %v467 = load i64, ptr %slot19, align 8
  store i64 %v467, ptr %slot86, align 8
  %v468 = load i32, ptr %slot85, align 8
  %op469 = mul i32 %v468, 4
  store i32 %op469, ptr %slot87, align 8
  %v470 = load i32, ptr %slot87, align 8
  %op471 = or i32 %v470, 0
  store i32 %op471, ptr %slot88, align 8
  %v472 = load i64, ptr %slot10, align 8
  store i64 %v472, ptr %slot89, align 8
  %v473 = load i64, ptr %slot18, align 8
  %v474 = load i64, ptr %slot89, align 8
  %v475 = load i64, ptr %slot81, align 8
  %v476 = load i64, ptr %slot86, align 8
  %cv477 = trunc i64 %v476 to i32
  %v478 = load i32, ptr %slot88, align 8
  %call479 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v473, i64 %v474, i64 %v475, i32 %cv477, i32 %v478) nomerge, !dbg !126
  store i32 %call479, ptr %slot90, align 8
  %v480 = load i32, ptr %slot90, align 8
  %cv481 = zext i32 %v480 to i64
  %cond482 = icmp ne i64 %cv481, 0
  br i1 %cond482, label %bb_rcsuccess88, label %bb_rcfailure88
bb_rcfailure88:
  %v483 = load i64, ptr %slot18, align 8
  %p484 = inttoptr i64 %v483 to ptr
  %call485 = call i32 @myl_rc_take_failure(ptr %p484) nomerge, !dbg !126
  store i32 %call485, ptr %slot91, align 8
  %v486 = load i64, ptr %slot1, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %v488 = load i32, ptr %slot91, align 8
  %call489 = call i32 @myl_qbe_rc_status(ptr %p487, i32 %v488) nomerge, !dbg !126
  store i32 %call489, ptr %slot92, align 8
  br label %bb_failure
bb_rcsuccess88:
  %v490 = load i32, ptr %slot85, align 8
  %cv491 = zext i32 %v490 to i64
  %cond492 = icmp ne i64 %cv491, 0
  br i1 %cond492, label %bb_rchtaken91, label %bb_rchcopied91
bb_rchcopied91:
  %v493 = load i64, ptr %slot5, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %ld495 = load i32, ptr %p494, align 4, !alias.scope !3, !noalias !4
  store i32 %ld495, ptr %slot93, align 8
  %v496 = load i32, ptr %slot93, align 8
  %cv497 = zext i32 %v496 to i64
  %cond498 = icmp ne i64 %cv497, 0
  br i1 %cond498, label %bb_rcslotdrop94, label %bb_rcslotdone94
bb_rcslotdrop94:
  %v499 = load i64, ptr %slot5, align 8
  %p500 = inttoptr i64 %v499 to ptr
  store i32 0, ptr %p500, align 4, !alias.scope !3, !noalias !4
  %v501 = load i64, ptr %slot9, align 8
  store i64 %v501, ptr %slot94, align 8
  %v502 = load i64, ptr %slot6, align 8
  %p503 = inttoptr i64 %v502 to ptr
  %ld504 = load i32, ptr %p503, align 4, !alias.scope !3, !noalias !4
  store i32 %ld504, ptr %slot95, align 8
  %v505 = load i32, ptr %slot95, align 8
  %op506 = and i32 %v505, 28
  store i32 %op506, ptr %slot96, align 8
  %v507 = load i32, ptr %slot96, align 8
  %cv508 = zext i32 %v507 to i64
  %cond509 = icmp ne i64 %cv508, 0
  br i1 %cond509, label %bb_rcslotrole94, label %bb_rcslotowner94
bb_rcslotrole94:
  %v510 = load i64, ptr %slot18, align 8
  store i64 %v510, ptr %slot97, align 8
  %v511 = load i64, ptr %slot97, align 8
  %v512 = load i64, ptr %slot94, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v511, i64 %v512) nomerge, !dbg !126
  br label %bb_rcslotdone94
bb_rcslotowner94:
  %v513 = load i64, ptr %slot18, align 8
  store i64 %v513, ptr %slot98, align 8
  %v514 = load i64, ptr %slot98, align 8
  %v515 = load i64, ptr %slot94, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v514, i64 %v515) nomerge, !dbg !126
  br label %bb_rcslotdone94
bb_rcslotdone94:
  br label %bb_rchprepared91
bb_rchtaken91:
  %v516 = load i64, ptr %slot5, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i32 0, ptr %p517, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared91
bb_rchprepared91:
  %v518 = load i64, ptr %slot8, align 8
  %p519 = inttoptr i64 %v518 to ptr
  store i32 2, ptr %p519, align 4, !alias.scope !3, !noalias !4
  %v520 = load i64, ptr %slot7, align 8
  %p521 = inttoptr i64 %v520 to ptr
  store i32 1, ptr %p521, align 4, !alias.scope !3, !noalias !4
  %v522 = load i64, ptr %slot9, align 8
  store i64 %v522, ptr %slot99, align 8
  %v523 = load i64, ptr %slot10, align 8
  store i64 %v523, ptr %slot100, align 8
  %v524 = load i64, ptr %slot100, align 8
  %v525 = load i64, ptr %slot99, align 8
  %p526 = inttoptr i64 %v524 to ptr
  %p527 = inttoptr i64 %v525 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p527, ptr %p526, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v528 = load i64, ptr %slot6, align 8
  %p529 = inttoptr i64 %v528 to ptr
  store i32 2, ptr %p529, align 4, !alias.scope !3, !noalias !4
  %v530 = load i64, ptr %slot8, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i32, ptr %p531, align 4, !alias.scope !3, !noalias !4
  store i32 %ld532, ptr %slot101, align 8
  %v533 = load i32, ptr %slot101, align 8
  %v534 = load i64, ptr %slot6, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i32 %v533, ptr %p535, align 4, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot7, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i32 0, ptr %p537, align 4, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot5, align 8
  %p539 = inttoptr i64 %v538 to ptr
  store i32 1, ptr %p539, align 4, !alias.scope !3, !noalias !4
  %v540 = load i64, ptr %slot99, align 8
  %v541 = load i64, ptr %slot15, align 8
  %p542 = inttoptr i64 %v541 to ptr
  store i64 %v540, ptr %p542, align 8, !alias.scope !3, !noalias !4
  %v543 = load i64, ptr %slot15, align 8
  %p544 = inttoptr i64 %v543 to ptr
  %ld545 = load i64, ptr %p544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld545, ptr %slot102, align 8
  %v546 = load i64, ptr %slot15, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %ld548 = load i64, ptr %p547, align 8, !alias.scope !3, !noalias !4
  store i64 %ld548, ptr %slot103, align 8
  %v549 = load i64, ptr %slot10, align 8
  store i64 %v549, ptr %slot104, align 8
  %v550 = load i64, ptr %slot19, align 8
  store i64 %v550, ptr %slot105, align 8
  %v551 = load i64, ptr %slot18, align 8
  %v552 = load i64, ptr %slot104, align 8
  %v553 = load i64, ptr %slot103, align 8
  %v554 = load i64, ptr %slot105, align 8
  %cv555 = trunc i64 %v554 to i32
  %call556 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v551, i64 %v552, i64 %v553, i32 %cv555) nomerge, !dbg !128
  store i32 %call556, ptr %slot106, align 8
  %v557 = load i32, ptr %slot106, align 8
  %cv558 = zext i32 %v557 to i64
  %cond559 = icmp ne i64 %cv558, 0
  br i1 %cond559, label %bb_rcsuccess117, label %bb_rcfailure117
bb_rcfailure117:
  %v560 = load i64, ptr %slot18, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %call562 = call i32 @myl_rc_take_failure(ptr %p561) nomerge, !dbg !128
  store i32 %call562, ptr %slot107, align 8
  %v563 = load i64, ptr %slot1, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %v565 = load i32, ptr %slot107, align 8
  %call566 = call i32 @myl_qbe_rc_status(ptr %p564, i32 %v565) nomerge, !dbg !128
  store i32 %call566, ptr %slot108, align 8
  br label %bb_failure
bb_rcsuccess117:
  %v567 = load i64, ptr %slot5, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i32 0, ptr %p568, align 4, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot8, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i32 2, ptr %p570, align 4, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot7, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i32 1, ptr %p572, align 4, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot10, align 8
  store i64 %v573, ptr %slot109, align 8
  %v574 = load i64, ptr %slot7, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i32 0, ptr %p575, align 4, !alias.scope !3, !noalias !4
  %v576 = load i64, ptr %slot5, align 8
  %p577 = inttoptr i64 %v576 to ptr
  %ld578 = load i32, ptr %p577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld578, ptr %slot110, align 8
  %v579 = load i32, ptr %slot110, align 8
  %cv580 = zext i32 %v579 to i64
  %cond581 = icmp ne i64 %cv580, 0
  br i1 %cond581, label %bb_rcslotdrop127, label %bb_rcslotdone127
bb_rcslotdrop127:
  %v582 = load i64, ptr %slot5, align 8
  %p583 = inttoptr i64 %v582 to ptr
  store i32 0, ptr %p583, align 4, !alias.scope !3, !noalias !4
  %v584 = load i64, ptr %slot9, align 8
  store i64 %v584, ptr %slot111, align 8
  %v585 = load i64, ptr %slot6, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %ld587 = load i32, ptr %p586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld587, ptr %slot112, align 8
  %v588 = load i32, ptr %slot112, align 8
  %op589 = and i32 %v588, 28
  store i32 %op589, ptr %slot113, align 8
  %v590 = load i32, ptr %slot113, align 8
  %cv591 = zext i32 %v590 to i64
  %cond592 = icmp ne i64 %cv591, 0
  br i1 %cond592, label %bb_rcslotrole127, label %bb_rcslotowner127
bb_rcslotrole127:
  %v593 = load i64, ptr %slot18, align 8
  store i64 %v593, ptr %slot114, align 8
  %v594 = load i64, ptr %slot114, align 8
  %v595 = load i64, ptr %slot111, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v594, i64 %v595) nomerge, !dbg !128
  br label %bb_rcslotdone127
bb_rcslotowner127:
  %v596 = load i64, ptr %slot18, align 8
  store i64 %v596, ptr %slot115, align 8
  %v597 = load i64, ptr %slot115, align 8
  %v598 = load i64, ptr %slot111, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v597, i64 %v598) nomerge, !dbg !128
  br label %bb_rcslotdone127
bb_rcslotdone127:
  %v599 = load i64, ptr %slot109, align 8
  %p600 = inttoptr i64 %v599 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p600, i64 88, i1 false)
  ret void
bb_failure:
  %v601 = load i64, ptr %slot4, align 8
  %p602 = inttoptr i64 %v601 to ptr
  call void @llvm.memset.p0.i64(ptr %p602, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !128
  %v603 = load i64, ptr %slot4, align 8
  %p604 = inttoptr i64 %v603 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p604, i64 88, i1 false)
  ret void
bb_entry_failure:
  %v605 = load i64, ptr %slot4, align 8
  %p606 = inttoptr i64 %v605 to ptr
  call void @llvm.memset.p0.i64(ptr %p606, i8 0, i64 88, i1 false), !alias.scope !3, !noalias !4, !dbg !128
  %v607 = load i64, ptr %slot4, align 8
  %p608 = inttoptr i64 %v607 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p608, i64 88, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!11 = distinct !{!11, !0, !"element 88v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3", linkageName: "myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3927106948756611331, i64 0, !"myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!116 = !DILocation(line: 8, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!120 = !DILocation(line: 17, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!122 = !DILocation(line: 19, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!124 = !DILocation(line: 22, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!128 = !DILocation(line: 24, column: 0, scope: !129)
