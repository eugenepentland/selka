target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191(ptr sret([32 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i32, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i32, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v490 = load i64, ptr %slot1, align 8
  %op491 = add i64 %v490, 32
  store i64 %op491, ptr %slot4, align 8
  %mem492 = alloca i8, i64 32, align 8
  %ptr493 = ptrtoint ptr %mem492 to i64
  store i64 %ptr493, ptr %slot5, align 8
  %mem494 = alloca i8, i64 8, align 8
  %ptr495 = ptrtoint ptr %mem494 to i64
  store i64 %ptr495, ptr %slot6, align 8
  %mem496 = alloca i8, i64 8, align 8
  %ptr497 = ptrtoint ptr %mem496 to i64
  store i64 %ptr497, ptr %slot7, align 8
  %mem498 = alloca i8, i64 8, align 8
  %ptr499 = ptrtoint ptr %mem498 to i64
  store i64 %ptr499, ptr %slot8, align 8
  %mem500 = alloca i8, i64 8, align 8
  %ptr501 = ptrtoint ptr %mem500 to i64
  store i64 %ptr501, ptr %slot9, align 8
  %mem502 = alloca i8, i64 8, align 8
  %ptr503 = ptrtoint ptr %mem502 to i64
  store i64 %ptr503, ptr %slot10, align 8
  %mem504 = alloca i8, i64 208, align 8
  %ptr505 = ptrtoint ptr %mem504 to i64
  store i64 %ptr505, ptr %slot11, align 8
  %mem506 = alloca i8, i64 208, align 8
  %ptr507 = ptrtoint ptr %mem506 to i64
  store i64 %ptr507, ptr %slot12, align 8
  %mem508 = alloca i8, i64 8, align 8
  %ptr509 = ptrtoint ptr %mem508 to i64
  store i64 %ptr509, ptr %slot13, align 8
  %mem510 = alloca i8, i64 8, align 8
  %ptr511 = ptrtoint ptr %mem510 to i64
  store i64 %ptr511, ptr %slot14, align 8
  %mem512 = alloca i8, i64 8, align 8
  %ptr513 = ptrtoint ptr %mem512 to i64
  store i64 %ptr513, ptr %slot15, align 8
  %mem514 = alloca i8, i64 8, align 8
  %ptr515 = ptrtoint ptr %mem514 to i64
  store i64 %ptr515, ptr %slot16, align 8
  %mem516 = alloca i8, i64 8, align 8
  %ptr517 = ptrtoint ptr %mem516 to i64
  store i64 %ptr517, ptr %slot17, align 8
  %mem518 = alloca i8, i64 24, align 8
  %ptr519 = ptrtoint ptr %mem518 to i64
  store i64 %ptr519, ptr %slot18, align 8
  %mem520 = alloca i8, i64 8, align 8
  %ptr521 = ptrtoint ptr %mem520 to i64
  store i64 %ptr521, ptr %slot19, align 8
  %mem522 = alloca i8, i64 8, align 8
  %ptr523 = ptrtoint ptr %mem522 to i64
  store i64 %ptr523, ptr %slot20, align 8
  %mem524 = alloca i8, i64 32, align 8
  %ptr525 = ptrtoint ptr %mem524 to i64
  store i64 %ptr525, ptr %slot21, align 8
  %mem526 = alloca i8, i64 32, align 8
  %ptr527 = ptrtoint ptr %mem526 to i64
  store i64 %ptr527, ptr %slot22, align 8
  %mem528 = alloca i8, i64 32, align 8
  %ptr529 = ptrtoint ptr %mem528 to i64
  store i64 %ptr529, ptr %slot23, align 8
  %mem530 = alloca i8, i64 32, align 8
  %ptr531 = ptrtoint ptr %mem530 to i64
  store i64 %ptr531, ptr %slot24, align 8
  %mem532 = alloca i8, i64 32, align 8
  %ptr533 = ptrtoint ptr %mem532 to i64
  store i64 %ptr533, ptr %slot25, align 8
  %mem534 = alloca i8, i64 32, align 8
  %ptr535 = ptrtoint ptr %mem534 to i64
  store i64 %ptr535, ptr %slot26, align 8
  %mem536 = alloca i8, i64 32, align 8
  %ptr537 = ptrtoint ptr %mem536 to i64
  store i64 %ptr537, ptr %slot27, align 8
  %mem538 = alloca i8, i64 32, align 8
  %ptr539 = ptrtoint ptr %mem538 to i64
  store i64 %ptr539, ptr %slot28, align 8
  %mem540 = alloca i8, i64 32, align 8
  %ptr541 = ptrtoint ptr %mem540 to i64
  store i64 %ptr541, ptr %slot29, align 8
  %mem542 = alloca i8, i64 32, align 8
  %ptr543 = ptrtoint ptr %mem542 to i64
  store i64 %ptr543, ptr %slot30, align 8
  %mem544 = alloca i8, i64 32, align 8
  %ptr545 = ptrtoint ptr %mem544 to i64
  store i64 %ptr545, ptr %slot31, align 8
  %mem546 = alloca i8, i64 32, align 8
  %ptr547 = ptrtoint ptr %mem546 to i64
  store i64 %ptr547, ptr %slot32, align 8
  %mem548 = alloca i8, i64 32, align 8
  %ptr549 = ptrtoint ptr %mem548 to i64
  store i64 %ptr549, ptr %slot33, align 8
  %mem550 = alloca i8, i64 32, align 8
  %ptr551 = ptrtoint ptr %mem550 to i64
  store i64 %ptr551, ptr %slot34, align 8
  %v552 = load i64, ptr %slot16, align 8
  %p553 = inttoptr i64 %v552 to ptr
  store i64 0, ptr %p553, align 8, !alias.scope !3, !noalias !4
  %v554 = load i64, ptr %slot2, align 8
  %v555 = load i64, ptr %slot13, align 8
  %p556 = inttoptr i64 %v555 to ptr
  store i64 %v554, ptr %p556, align 8, !alias.scope !3, !noalias !4
  %v557 = load i64, ptr %slot3, align 8
  %v558 = load i64, ptr %slot14, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i64 %v557, ptr %p559, align 8, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot1, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %call562 = call ptr @myl_qbe_heap(ptr %p561) nomerge, !dbg !110
  %calladdr563 = ptrtoint ptr %call562 to i64
  store i64 %calladdr563, ptr %slot35, align 8
  %v564 = load i64, ptr %slot1, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %call566 = call i64 @myl_qbe_region_mark(ptr %p565) nomerge, !dbg !110
  store i64 %call566, ptr %slot36, align 8
  %v567 = load i64, ptr %slot6, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i32 0, ptr %p568, align 4, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot7, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i32 0, ptr %p570, align 4, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot8, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i32 0, ptr %p572, align 4, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot9, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i32 0, ptr %p574, align 4, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot10, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i32 0, ptr %p576, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v577 = load i64, ptr %slot14, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld579, ptr %slot37, align 8
  %v580 = load i64, ptr %slot37, align 8
  %v581 = load i64, ptr %slot19, align 8
  %p582 = inttoptr i64 %v581 to ptr
  store i64 %v580, ptr %p582, align 8, !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot19, align 8
  %p584 = inttoptr i64 %v583 to ptr
  %ld585 = load i64, ptr %p584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld585, ptr %slot38, align 8
  %v586 = load i64, ptr %slot38, align 8
  %p587 = inttoptr i64 %v586 to ptr
  %ld588 = load i32, ptr %p587, align 4, !alias.scope !4, !noalias !3
  %ext589 = zext i32 %ld588 to i64
  store i64 %ext589, ptr %slot39, align 8
  %v590 = load i64, ptr %slot39, align 8
  %cmp591 = icmp eq i64 %v590, 0
  %cv592 = zext i1 %cmp591 to i64
  store i64 %cv592, ptr %slot40, align 8
  %v593 = load i64, ptr %slot40, align 8
  %cond594 = icmp ne i64 %v593, 0
  br i1 %cond594, label %bb_rcarm6, label %bb_rcarmnext6
bb_rcarm6:
  br label %bb_i46
bb_rcarmnext6:
  %v595 = load i64, ptr %slot39, align 8
  %cmp596 = icmp eq i64 %v595, 1
  %cv597 = zext i1 %cmp596 to i64
  store i64 %cv597, ptr %slot41, align 8
  %v598 = load i64, ptr %slot41, align 8
  %cond599 = icmp ne i64 %v598, 0
  br i1 %cond599, label %bb_rcarm7, label %bb_rcarmnext7
bb_rcarm7:
  br label %bb_i48
bb_rcarmnext7:
  %v600 = load i64, ptr %slot39, align 8
  %cmp601 = icmp eq i64 %v600, 2
  %cv602 = zext i1 %cmp601 to i64
  store i64 %cv602, ptr %slot42, align 8
  %v603 = load i64, ptr %slot42, align 8
  %cond604 = icmp ne i64 %v603, 0
  br i1 %cond604, label %bb_rcarm8, label %bb_rcarmnext8
bb_rcarm8:
  br label %bb_i50
bb_rcarmnext8:
  %v605 = load i64, ptr %slot39, align 8
  %cmp606 = icmp eq i64 %v605, 3
  %cv607 = zext i1 %cmp606 to i64
  store i64 %cv607, ptr %slot43, align 8
  %v608 = load i64, ptr %slot43, align 8
  %cond609 = icmp ne i64 %v608, 0
  br i1 %cond609, label %bb_rcarm9, label %bb_rcarmnext9
bb_rcarm9:
  %v610 = load i64, ptr %slot12, align 8
  store i64 %v610, ptr %slot44, align 8
  %v611 = load i64, ptr %slot38, align 8
  %op612 = add i64 %v611, 8
  store i64 %op612, ptr %slot45, align 8
  %v613 = load i64, ptr %slot36, align 8
  store i64 %v613, ptr %slot46, align 8
  %v614 = load i64, ptr %slot45, align 8
  %p615 = inttoptr i64 %v614 to ptr
  %ld616 = load i64, ptr %p615, align 8, !alias.scope !4, !noalias !3
  store i64 %ld616, ptr %slot47, align 8
  %v617 = load i64, ptr %slot47, align 8
  %v618 = load i64, ptr %slot44, align 8
  %p619 = inttoptr i64 %v618 to ptr
  store i64 %v617, ptr %p619, align 8, !alias.scope !3, !noalias !4
  %v620 = load i64, ptr %slot9, align 8
  %p621 = inttoptr i64 %v620 to ptr
  store i32 0, ptr %p621, align 4, !alias.scope !3, !noalias !4
  %v622 = load i64, ptr %slot8, align 8
  %p623 = inttoptr i64 %v622 to ptr
  store i32 1, ptr %p623, align 4, !alias.scope !3, !noalias !4
  %v624 = load i64, ptr %slot44, align 8
  %p625 = inttoptr i64 %v624 to ptr
  %ld626 = load i64, ptr %p625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld626, ptr %slot48, align 8
  %v627 = load i64, ptr %slot48, align 8
  %v628 = load i64, ptr %slot15, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i64 %v627, ptr %p629, align 8, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot8, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i32 0, ptr %p631, align 4, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_rcarmnext9:
  br label %bb_failure
bb_i2:
  %v632 = load i64, ptr %slot13, align 8
  %p633 = inttoptr i64 %v632 to ptr
  %ld634 = load i64, ptr %p633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld634, ptr %slot49, align 8
  %v635 = load i64, ptr %slot49, align 8
  %v636 = load i64, ptr %slot19, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i64 %v635, ptr %p637, align 8, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot19, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %ld640 = load i64, ptr %p639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld640, ptr %slot50, align 8
  %v641 = load i64, ptr %slot50, align 8
  %op642 = add i64 %v641, 0
  store i64 %op642, ptr %slot51, align 8
  %v643 = load i64, ptr %slot51, align 8
  %p644 = inttoptr i64 %v643 to ptr
  %ld645 = load i64, ptr %p644, align 8, !alias.scope !4, !noalias !3
  store i64 %ld645, ptr %slot52, align 8
  %v646 = load i64, ptr %slot52, align 8
  %v647 = load i64, ptr %slot19, align 8
  %p648 = inttoptr i64 %v647 to ptr
  store i64 %v646, ptr %p648, align 8, !alias.scope !3, !noalias !4
  %v649 = load i64, ptr %slot6, align 8
  %p650 = inttoptr i64 %v649 to ptr
  %ld651 = load i32, ptr %p650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld651, ptr %slot53, align 8
  %v652 = load i32, ptr %slot53, align 8
  %cv653 = zext i32 %v652 to i64
  %cond654 = icmp ne i64 %cv653, 0
  br i1 %cond654, label %bb_rcslotdrop24, label %bb_rcslotdone24
bb_rcslotdrop24:
  %v655 = load i64, ptr %slot6, align 8
  %p656 = inttoptr i64 %v655 to ptr
  store i32 0, ptr %p656, align 4, !alias.scope !3, !noalias !4
  %v657 = load i64, ptr %slot11, align 8
  store i64 %v657, ptr %slot54, align 8
  %v658 = load i64, ptr %slot7, align 8
  %p659 = inttoptr i64 %v658 to ptr
  %ld660 = load i32, ptr %p659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld660, ptr %slot55, align 8
  %v661 = load i32, ptr %slot55, align 8
  %op662 = and i32 %v661, 28
  store i32 %op662, ptr %slot56, align 8
  %v663 = load i32, ptr %slot56, align 8
  %cv664 = zext i32 %v663 to i64
  %cond665 = icmp ne i64 %cv664, 0
  br i1 %cond665, label %bb_rcslotrole24, label %bb_rcslotowner24
bb_rcslotrole24:
  %v666 = load i64, ptr %slot35, align 8
  store i64 %v666, ptr %slot57, align 8
  %v667 = load i64, ptr %slot57, align 8
  %v668 = load i64, ptr %slot54, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v667, i64 %v668) nomerge, !dbg !112
  br label %bb_rcslotdone24
bb_rcslotowner24:
  %v669 = load i64, ptr %slot35, align 8
  store i64 %v669, ptr %slot58, align 8
  %v670 = load i64, ptr %slot58, align 8
  %v671 = load i64, ptr %slot54, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v670, i64 %v671) nomerge, !dbg !112
  br label %bb_rcslotdone24
bb_rcslotdone24:
  %v672 = load i64, ptr %slot19, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %ld674 = load i64, ptr %p673, align 8, !alias.scope !3, !noalias !4
  store i64 %ld674, ptr %slot59, align 8
  %v675 = load i64, ptr %slot59, align 8
  %v676 = load i64, ptr %slot16, align 8
  %p677 = inttoptr i64 %v676 to ptr
  store i64 %v675, ptr %p677, align 8, !alias.scope !3, !noalias !4
  %v678 = load i64, ptr %slot15, align 8
  %p679 = inttoptr i64 %v678 to ptr
  %ld680 = load i64, ptr %p679, align 8, !alias.scope !3, !noalias !4
  store i64 %ld680, ptr %slot60, align 8
  %v681 = load i64, ptr %slot60, align 8
  %v682 = load i64, ptr %slot19, align 8
  %p683 = inttoptr i64 %v682 to ptr
  store i64 %v681, ptr %p683, align 8, !alias.scope !3, !noalias !4
  %v684 = load i64, ptr %slot19, align 8
  %p685 = inttoptr i64 %v684 to ptr
  %ld686 = load i64, ptr %p685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld686, ptr %slot61, align 8
  %v687 = load i64, ptr %slot61, align 8
  %v688 = load i64, ptr %slot17, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i64 %v687, ptr %p689, align 8, !alias.scope !3, !noalias !4
  %v690 = load i64, ptr %slot17, align 8
  %p691 = inttoptr i64 %v690 to ptr
  %ld692 = load i64, ptr %p691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld692, ptr %slot62, align 8
  %v693 = load i64, ptr %slot62, align 8
  %v694 = load i64, ptr %slot19, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i64 %v693, ptr %p695, align 8, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot20, align 8
  %p697 = inttoptr i64 %v696 to ptr
  store i64 0, ptr %p697, align 8, !alias.scope !3, !noalias !4
  %v698 = load i64, ptr %slot20, align 8
  %p699 = inttoptr i64 %v698 to ptr
  %ld700 = load i64, ptr %p699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld700, ptr %slot63, align 8
  %v701 = load i64, ptr %slot19, align 8
  %p702 = inttoptr i64 %v701 to ptr
  %ld703 = load i64, ptr %p702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld703, ptr %slot64, align 8
  %v704 = load i64, ptr %slot64, align 8
  %v705 = load i64, ptr %slot63, align 8
  %cmp706 = icmp slt i64 %v704, %v705
  %cv707 = zext i1 %cmp706 to i64
  store i64 %cv707, ptr %slot65, align 8
  %v708 = load i64, ptr %slot65, align 8
  %v709 = load i64, ptr %slot19, align 8
  %p710 = inttoptr i64 %v709 to ptr
  store i64 %v708, ptr %p710, align 8, !alias.scope !3, !noalias !4
  %v711 = load i64, ptr %slot19, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %ld713 = load i64, ptr %p712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld713, ptr %slot66, align 8
  %v714 = load i64, ptr %slot66, align 8
  %cond715 = icmp ne i64 %v714, 0
  br i1 %cond715, label %bb_next39, label %bb_i16
bb_next39:
  %v716 = load i64, ptr %slot16, align 8
  %p717 = inttoptr i64 %v716 to ptr
  %ld718 = load i64, ptr %p717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld718, ptr %slot67, align 8
  %v719 = load i64, ptr %slot67, align 8
  %op720 = add i64 %v719, 0
  store i64 %op720, ptr %slot68, align 8
  %v721 = load i64, ptr %slot68, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i64, ptr %p722, align 8, !alias.scope !6, !noalias !7
  store i64 %ld723, ptr %slot69, align 8
  %v724 = load i64, ptr %slot69, align 8
  %v725 = load i64, ptr %slot19, align 8
  %p726 = inttoptr i64 %v725 to ptr
  store i64 %v724, ptr %p726, align 8, !alias.scope !3, !noalias !4
  %v727 = load i64, ptr %slot19, align 8
  %p728 = inttoptr i64 %v727 to ptr
  %ld729 = load i64, ptr %p728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld729, ptr %slot70, align 8
  %v730 = load i64, ptr %slot70, align 8
  %cmp731 = icmp ugt i64 %v730, 9223372036854775807
  %cv732 = zext i1 %cmp731 to i64
  store i64 %cv732, ptr %slot71, align 8
  %v733 = load i64, ptr %slot71, align 8
  %cond734 = icmp ne i64 %v733, 0
  br i1 %cond734, label %bb_cast_overflow44, label %bb_cast_ok44
bb_cast_overflow44:
  %v735 = load i64, ptr %slot1, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %v737 = load i64, ptr %slot70, align 8
  call void @myl_qbe_fail_cast(ptr %p736, i64 %v737, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok44:
  %v738 = load i64, ptr %slot70, align 8
  %v739 = load i64, ptr %slot19, align 8
  %p740 = inttoptr i64 %v739 to ptr
  store i64 %v738, ptr %p740, align 8, !alias.scope !3, !noalias !4
  %v741 = load i64, ptr %slot17, align 8
  %p742 = inttoptr i64 %v741 to ptr
  %ld743 = load i64, ptr %p742, align 8, !alias.scope !3, !noalias !4
  store i64 %ld743, ptr %slot72, align 8
  %v744 = load i64, ptr %slot72, align 8
  %v745 = load i64, ptr %slot20, align 8
  %p746 = inttoptr i64 %v745 to ptr
  store i64 %v744, ptr %p746, align 8, !alias.scope !3, !noalias !4
  %v747 = load i64, ptr %slot20, align 8
  %p748 = inttoptr i64 %v747 to ptr
  %ld749 = load i64, ptr %p748, align 8, !alias.scope !3, !noalias !4
  store i64 %ld749, ptr %slot73, align 8
  %v750 = load i64, ptr %slot19, align 8
  %p751 = inttoptr i64 %v750 to ptr
  %ld752 = load i64, ptr %p751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld752, ptr %slot74, align 8
  %v753 = load i64, ptr %slot74, align 8
  %v754 = load i64, ptr %slot73, align 8
  %ovpair756 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v753, i64 %v754)
  %op755 = extractvalue { i64, i1 } %ovpair756, 0
  %ov757 = extractvalue { i64, i1 } %ovpair756, 1
  store i64 %op755, ptr %slot75, align 8
  %v758 = load i64, ptr %slot74, align 8
  %v759 = load i64, ptr %slot75, align 8
  %op760 = xor i64 %v758, %v759
  store i64 %op760, ptr %slot76, align 8
  %v761 = load i64, ptr %slot73, align 8
  %v762 = load i64, ptr %slot75, align 8
  %op763 = xor i64 %v761, %v762
  store i64 %op763, ptr %slot77, align 8
  %v764 = load i64, ptr %slot76, align 8
  %v765 = load i64, ptr %slot77, align 8
  %op766 = and i64 %v764, %v765
  store i64 %op766, ptr %slot78, align 8
  %cv767 = zext i1 %ov757 to i64
  store i64 %cv767, ptr %slot79, align 8
  %v768 = load i64, ptr %slot79, align 8
  %cond769 = icmp ne i64 %v768, 0
  br i1 %cond769, label %bb_overflow48, label %bb_checked48
bb_overflow48:
  %v770 = load i64, ptr %slot1, align 8
  %p771 = inttoptr i64 %v770 to ptr
  %v772 = load i64, ptr %slot74, align 8
  %v773 = load i64, ptr %slot73, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p771, i64 0, i64 %v772, i64 %v773, i64 64) nomerge, !dbg !116
  unreachable
bb_checked48:
  %v774 = load i64, ptr %slot75, align 8
  %v775 = load i64, ptr %slot19, align 8
  %p776 = inttoptr i64 %v775 to ptr
  store i64 %v774, ptr %p776, align 8, !alias.scope !3, !noalias !4
  %v777 = load i64, ptr %slot19, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i64, ptr %p778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld779, ptr %slot80, align 8
  %v780 = load i64, ptr %slot80, align 8
  %v781 = load i64, ptr %slot17, align 8
  %p782 = inttoptr i64 %v781 to ptr
  store i64 %v780, ptr %p782, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i16:
  %v783 = load i64, ptr %slot17, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %ld785 = load i64, ptr %p784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld785, ptr %slot81, align 8
  %v786 = load i64, ptr %slot81, align 8
  %v787 = load i64, ptr %slot19, align 8
  %p788 = inttoptr i64 %v787 to ptr
  store i64 %v786, ptr %p788, align 8, !alias.scope !3, !noalias !4
  %v789 = load i64, ptr %slot16, align 8
  %p790 = inttoptr i64 %v789 to ptr
  %ld791 = load i64, ptr %p790, align 8, !alias.scope !3, !noalias !4
  store i64 %ld791, ptr %slot82, align 8
  %v792 = load i64, ptr %slot19, align 8
  %p793 = inttoptr i64 %v792 to ptr
  %ld794 = load i64, ptr %p793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld794, ptr %slot83, align 8
  %v795 = load i64, ptr %slot82, align 8
  %p796 = inttoptr i64 %v795 to ptr
  %ld797 = load i64, ptr %p796, align 8, !alias.scope !6, !noalias !7
  store i64 %ld797, ptr %slot84, align 8
  %v798 = load i64, ptr %slot83, align 8
  %v799 = load i64, ptr %slot84, align 8
  %cmp800 = icmp ult i64 %v798, %v799
  %cv801 = zext i1 %cmp800 to i64
  store i64 %cv801, ptr %slot85, align 8
  %v802 = load i64, ptr %slot85, align 8
  %cond803 = icmp ne i64 %v802, 0
  br i1 %cond803, label %bb_success60, label %bb_failed60
bb_failed60:
  %v804 = load i64, ptr %slot1, align 8
  %p805 = inttoptr i64 %v804 to ptr
  %v806 = load i64, ptr %slot83, align 8
  %v807 = load i64, ptr %slot84, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p805, i64 %v806, i64 %v807) nomerge, !dbg !118
  unreachable
bb_success60:
  %v808 = load i64, ptr %slot82, align 8
  %op809 = add i64 %v808, 32
  store i64 %op809, ptr %slot86, align 8
  %v810 = load i64, ptr %slot86, align 8
  %p811 = inttoptr i64 %v810 to ptr
  %ld812 = load i64, ptr %p811, align 8, !alias.scope !6, !noalias !7
  store i64 %ld812, ptr %slot87, align 8
  %v813 = load i64, ptr %slot83, align 8
  %op814 = mul i64 %v813, 56
  store i64 %op814, ptr %slot88, align 8
  %v815 = load i64, ptr %slot87, align 8
  %v816 = load i64, ptr %slot88, align 8
  %op817 = add i64 %v815, %v816
  store i64 %op817, ptr %slot89, align 8
  %v818 = load i64, ptr %slot89, align 8
  %v819 = load i64, ptr %slot19, align 8
  %p820 = inttoptr i64 %v819 to ptr
  store i64 %v818, ptr %p820, align 8, !alias.scope !3, !noalias !4
  %v821 = load i64, ptr %slot19, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %ld823 = load i64, ptr %p822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld823, ptr %slot90, align 8
  %v824 = load i64, ptr %slot90, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %ld826 = load i32, ptr %p825, align 4, !alias.scope !12, !noalias !13
  %ext827 = zext i32 %ld826 to i64
  store i64 %ext827, ptr %slot91, align 8
  %v828 = load i64, ptr %slot91, align 8
  %cmp829 = icmp eq i64 %v828, 0
  %cv830 = zext i1 %cmp829 to i64
  store i64 %cv830, ptr %slot92, align 8
  %v831 = load i64, ptr %slot92, align 8
  %cond832 = icmp ne i64 %v831, 0
  br i1 %cond832, label %bb_rcarm67, label %bb_rcarmnext67
bb_rcarm67:
  %v833 = load i64, ptr %slot6, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %ld835 = load i32, ptr %p834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld835, ptr %slot93, align 8
  %v836 = load i32, ptr %slot93, align 8
  %cv837 = zext i32 %v836 to i64
  %cond838 = icmp ne i64 %cv837, 0
  br i1 %cond838, label %bb_rcslotdrop70, label %bb_rcslotdone70
bb_rcslotdrop70:
  %v839 = load i64, ptr %slot6, align 8
  %p840 = inttoptr i64 %v839 to ptr
  store i32 0, ptr %p840, align 4, !alias.scope !3, !noalias !4
  %v841 = load i64, ptr %slot11, align 8
  store i64 %v841, ptr %slot94, align 8
  %v842 = load i64, ptr %slot7, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %ld844 = load i32, ptr %p843, align 4, !alias.scope !3, !noalias !4
  store i32 %ld844, ptr %slot95, align 8
  %v845 = load i32, ptr %slot95, align 8
  %op846 = and i32 %v845, 28
  store i32 %op846, ptr %slot96, align 8
  %v847 = load i32, ptr %slot96, align 8
  %cv848 = zext i32 %v847 to i64
  %cond849 = icmp ne i64 %cv848, 0
  br i1 %cond849, label %bb_rcslotrole70, label %bb_rcslotowner70
bb_rcslotrole70:
  %v850 = load i64, ptr %slot35, align 8
  store i64 %v850, ptr %slot97, align 8
  %v851 = load i64, ptr %slot97, align 8
  %v852 = load i64, ptr %slot94, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v851, i64 %v852) nomerge, !dbg !120
  br label %bb_rcslotdone70
bb_rcslotowner70:
  %v853 = load i64, ptr %slot35, align 8
  store i64 %v853, ptr %slot98, align 8
  %v854 = load i64, ptr %slot98, align 8
  %v855 = load i64, ptr %slot94, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v854, i64 %v855) nomerge, !dbg !120
  br label %bb_rcslotdone70
bb_rcslotdone70:
  br label %bb_i26
bb_rcarmnext67:
  %v856 = load i64, ptr %slot91, align 8
  %cmp857 = icmp eq i64 %v856, 1
  %cv858 = zext i1 %cmp857 to i64
  store i64 %cv858, ptr %slot99, align 8
  %v859 = load i64, ptr %slot99, align 8
  %cond860 = icmp ne i64 %v859, 0
  br i1 %cond860, label %bb_rcarm77, label %bb_rcarmnext77
bb_rcarm77:
  %v861 = load i64, ptr %slot6, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %ld863 = load i32, ptr %p862, align 4, !alias.scope !3, !noalias !4
  store i32 %ld863, ptr %slot100, align 8
  %v864 = load i32, ptr %slot100, align 8
  %cv865 = zext i32 %v864 to i64
  %cond866 = icmp ne i64 %cv865, 0
  br i1 %cond866, label %bb_rcslotdrop80, label %bb_rcslotdone80
bb_rcslotdrop80:
  %v867 = load i64, ptr %slot6, align 8
  %p868 = inttoptr i64 %v867 to ptr
  store i32 0, ptr %p868, align 4, !alias.scope !3, !noalias !4
  %v869 = load i64, ptr %slot11, align 8
  store i64 %v869, ptr %slot101, align 8
  %v870 = load i64, ptr %slot7, align 8
  %p871 = inttoptr i64 %v870 to ptr
  %ld872 = load i32, ptr %p871, align 4, !alias.scope !3, !noalias !4
  store i32 %ld872, ptr %slot102, align 8
  %v873 = load i32, ptr %slot102, align 8
  %op874 = and i32 %v873, 28
  store i32 %op874, ptr %slot103, align 8
  %v875 = load i32, ptr %slot103, align 8
  %cv876 = zext i32 %v875 to i64
  %cond877 = icmp ne i64 %cv876, 0
  br i1 %cond877, label %bb_rcslotrole80, label %bb_rcslotowner80
bb_rcslotrole80:
  %v878 = load i64, ptr %slot35, align 8
  store i64 %v878, ptr %slot104, align 8
  %v879 = load i64, ptr %slot104, align 8
  %v880 = load i64, ptr %slot101, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v879, i64 %v880) nomerge, !dbg !120
  br label %bb_rcslotdone80
bb_rcslotowner80:
  %v881 = load i64, ptr %slot35, align 8
  store i64 %v881, ptr %slot105, align 8
  %v882 = load i64, ptr %slot105, align 8
  %v883 = load i64, ptr %slot101, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v882, i64 %v883) nomerge, !dbg !120
  br label %bb_rcslotdone80
bb_rcslotdone80:
  br label %bb_i28
bb_rcarmnext77:
  %v884 = load i64, ptr %slot91, align 8
  %cmp885 = icmp eq i64 %v884, 2
  %cv886 = zext i1 %cmp885 to i64
  store i64 %cv886, ptr %slot106, align 8
  %v887 = load i64, ptr %slot106, align 8
  %cond888 = icmp ne i64 %v887, 0
  br i1 %cond888, label %bb_rcarm87, label %bb_rcarmnext87
bb_rcarm87:
  %v889 = load i64, ptr %slot6, align 8
  %p890 = inttoptr i64 %v889 to ptr
  %ld891 = load i32, ptr %p890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld891, ptr %slot107, align 8
  %v892 = load i32, ptr %slot107, align 8
  %cv893 = zext i32 %v892 to i64
  %cond894 = icmp ne i64 %cv893, 0
  br i1 %cond894, label %bb_rcslotdrop90, label %bb_rcslotdone90
bb_rcslotdrop90:
  %v895 = load i64, ptr %slot6, align 8
  %p896 = inttoptr i64 %v895 to ptr
  store i32 0, ptr %p896, align 4, !alias.scope !3, !noalias !4
  %v897 = load i64, ptr %slot11, align 8
  store i64 %v897, ptr %slot108, align 8
  %v898 = load i64, ptr %slot7, align 8
  %p899 = inttoptr i64 %v898 to ptr
  %ld900 = load i32, ptr %p899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld900, ptr %slot109, align 8
  %v901 = load i32, ptr %slot109, align 8
  %op902 = and i32 %v901, 28
  store i32 %op902, ptr %slot110, align 8
  %v903 = load i32, ptr %slot110, align 8
  %cv904 = zext i32 %v903 to i64
  %cond905 = icmp ne i64 %cv904, 0
  br i1 %cond905, label %bb_rcslotrole90, label %bb_rcslotowner90
bb_rcslotrole90:
  %v906 = load i64, ptr %slot35, align 8
  store i64 %v906, ptr %slot111, align 8
  %v907 = load i64, ptr %slot111, align 8
  %v908 = load i64, ptr %slot108, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v907, i64 %v908) nomerge, !dbg !120
  br label %bb_rcslotdone90
bb_rcslotowner90:
  %v909 = load i64, ptr %slot35, align 8
  store i64 %v909, ptr %slot112, align 8
  %v910 = load i64, ptr %slot112, align 8
  %v911 = load i64, ptr %slot108, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v910, i64 %v911) nomerge, !dbg !120
  br label %bb_rcslotdone90
bb_rcslotdone90:
  br label %bb_i30
bb_rcarmnext87:
  %v912 = load i64, ptr %slot91, align 8
  %cmp913 = icmp eq i64 %v912, 3
  %cv914 = zext i1 %cmp913 to i64
  store i64 %cv914, ptr %slot113, align 8
  %v915 = load i64, ptr %slot113, align 8
  %cond916 = icmp ne i64 %v915, 0
  br i1 %cond916, label %bb_rcarm97, label %bb_rcarmnext97
bb_rcarm97:
  %v917 = load i64, ptr %slot6, align 8
  %p918 = inttoptr i64 %v917 to ptr
  %ld919 = load i32, ptr %p918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld919, ptr %slot114, align 8
  %v920 = load i32, ptr %slot114, align 8
  %cv921 = zext i32 %v920 to i64
  %cond922 = icmp ne i64 %cv921, 0
  br i1 %cond922, label %bb_rcslotdrop100, label %bb_rcslotdone100
bb_rcslotdrop100:
  %v923 = load i64, ptr %slot6, align 8
  %p924 = inttoptr i64 %v923 to ptr
  store i32 0, ptr %p924, align 4, !alias.scope !3, !noalias !4
  %v925 = load i64, ptr %slot11, align 8
  store i64 %v925, ptr %slot115, align 8
  %v926 = load i64, ptr %slot7, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i32, ptr %p927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld928, ptr %slot116, align 8
  %v929 = load i32, ptr %slot116, align 8
  %op930 = and i32 %v929, 28
  store i32 %op930, ptr %slot117, align 8
  %v931 = load i32, ptr %slot117, align 8
  %cv932 = zext i32 %v931 to i64
  %cond933 = icmp ne i64 %cv932, 0
  br i1 %cond933, label %bb_rcslotrole100, label %bb_rcslotowner100
bb_rcslotrole100:
  %v934 = load i64, ptr %slot35, align 8
  store i64 %v934, ptr %slot118, align 8
  %v935 = load i64, ptr %slot118, align 8
  %v936 = load i64, ptr %slot115, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v935, i64 %v936) nomerge, !dbg !120
  br label %bb_rcslotdone100
bb_rcslotowner100:
  %v937 = load i64, ptr %slot35, align 8
  store i64 %v937, ptr %slot119, align 8
  %v938 = load i64, ptr %slot119, align 8
  %v939 = load i64, ptr %slot115, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v938, i64 %v939) nomerge, !dbg !120
  br label %bb_rcslotdone100
bb_rcslotdone100:
  br label %bb_i32
bb_rcarmnext97:
  %v940 = load i64, ptr %slot91, align 8
  %cmp941 = icmp eq i64 %v940, 4
  %cv942 = zext i1 %cmp941 to i64
  store i64 %cv942, ptr %slot120, align 8
  %v943 = load i64, ptr %slot120, align 8
  %cond944 = icmp ne i64 %v943, 0
  br i1 %cond944, label %bb_rcarm107, label %bb_rcarmnext107
bb_rcarm107:
  %v945 = load i64, ptr %slot6, align 8
  %p946 = inttoptr i64 %v945 to ptr
  %ld947 = load i32, ptr %p946, align 4, !alias.scope !3, !noalias !4
  store i32 %ld947, ptr %slot121, align 8
  %v948 = load i32, ptr %slot121, align 8
  %cv949 = zext i32 %v948 to i64
  %cond950 = icmp ne i64 %cv949, 0
  br i1 %cond950, label %bb_rcslotdrop110, label %bb_rcslotdone110
bb_rcslotdrop110:
  %v951 = load i64, ptr %slot6, align 8
  %p952 = inttoptr i64 %v951 to ptr
  store i32 0, ptr %p952, align 4, !alias.scope !3, !noalias !4
  %v953 = load i64, ptr %slot11, align 8
  store i64 %v953, ptr %slot122, align 8
  %v954 = load i64, ptr %slot7, align 8
  %p955 = inttoptr i64 %v954 to ptr
  %ld956 = load i32, ptr %p955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld956, ptr %slot123, align 8
  %v957 = load i32, ptr %slot123, align 8
  %op958 = and i32 %v957, 28
  store i32 %op958, ptr %slot124, align 8
  %v959 = load i32, ptr %slot124, align 8
  %cv960 = zext i32 %v959 to i64
  %cond961 = icmp ne i64 %cv960, 0
  br i1 %cond961, label %bb_rcslotrole110, label %bb_rcslotowner110
bb_rcslotrole110:
  %v962 = load i64, ptr %slot35, align 8
  store i64 %v962, ptr %slot125, align 8
  %v963 = load i64, ptr %slot125, align 8
  %v964 = load i64, ptr %slot122, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v963, i64 %v964) nomerge, !dbg !120
  br label %bb_rcslotdone110
bb_rcslotowner110:
  %v965 = load i64, ptr %slot35, align 8
  store i64 %v965, ptr %slot126, align 8
  %v966 = load i64, ptr %slot126, align 8
  %v967 = load i64, ptr %slot122, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v966, i64 %v967) nomerge, !dbg !120
  br label %bb_rcslotdone110
bb_rcslotdone110:
  br label %bb_i34
bb_rcarmnext107:
  %v968 = load i64, ptr %slot91, align 8
  %cmp969 = icmp eq i64 %v968, 5
  %cv970 = zext i1 %cmp969 to i64
  store i64 %cv970, ptr %slot127, align 8
  %v971 = load i64, ptr %slot127, align 8
  %cond972 = icmp ne i64 %v971, 0
  br i1 %cond972, label %bb_rcarm117, label %bb_rcarmnext117
bb_rcarm117:
  %v973 = load i64, ptr %slot6, align 8
  %p974 = inttoptr i64 %v973 to ptr
  %ld975 = load i32, ptr %p974, align 4, !alias.scope !3, !noalias !4
  store i32 %ld975, ptr %slot128, align 8
  %v976 = load i32, ptr %slot128, align 8
  %cv977 = zext i32 %v976 to i64
  %cond978 = icmp ne i64 %cv977, 0
  br i1 %cond978, label %bb_rcslotdrop120, label %bb_rcslotdone120
bb_rcslotdrop120:
  %v979 = load i64, ptr %slot6, align 8
  %p980 = inttoptr i64 %v979 to ptr
  store i32 0, ptr %p980, align 4, !alias.scope !3, !noalias !4
  %v981 = load i64, ptr %slot11, align 8
  store i64 %v981, ptr %slot129, align 8
  %v982 = load i64, ptr %slot7, align 8
  %p983 = inttoptr i64 %v982 to ptr
  %ld984 = load i32, ptr %p983, align 4, !alias.scope !3, !noalias !4
  store i32 %ld984, ptr %slot130, align 8
  %v985 = load i32, ptr %slot130, align 8
  %op986 = and i32 %v985, 28
  store i32 %op986, ptr %slot131, align 8
  %v987 = load i32, ptr %slot131, align 8
  %cv988 = zext i32 %v987 to i64
  %cond989 = icmp ne i64 %cv988, 0
  br i1 %cond989, label %bb_rcslotrole120, label %bb_rcslotowner120
bb_rcslotrole120:
  %v990 = load i64, ptr %slot35, align 8
  store i64 %v990, ptr %slot132, align 8
  %v991 = load i64, ptr %slot132, align 8
  %v992 = load i64, ptr %slot129, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v991, i64 %v992) nomerge, !dbg !120
  br label %bb_rcslotdone120
bb_rcslotowner120:
  %v993 = load i64, ptr %slot35, align 8
  store i64 %v993, ptr %slot133, align 8
  %v994 = load i64, ptr %slot133, align 8
  %v995 = load i64, ptr %slot129, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v994, i64 %v995) nomerge, !dbg !120
  br label %bb_rcslotdone120
bb_rcslotdone120:
  br label %bb_i36
bb_rcarmnext117:
  %v996 = load i64, ptr %slot91, align 8
  %cmp997 = icmp eq i64 %v996, 6
  %cv998 = zext i1 %cmp997 to i64
  store i64 %cv998, ptr %slot134, align 8
  %v999 = load i64, ptr %slot134, align 8
  %cond1000 = icmp ne i64 %v999, 0
  br i1 %cond1000, label %bb_rcarm127, label %bb_rcarmnext127
bb_rcarm127:
  %v1001 = load i64, ptr %slot6, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  %ld1003 = load i32, ptr %p1002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1003, ptr %slot135, align 8
  %v1004 = load i32, ptr %slot135, align 8
  %cv1005 = zext i32 %v1004 to i64
  %cond1006 = icmp ne i64 %cv1005, 0
  br i1 %cond1006, label %bb_rcslotdrop130, label %bb_rcslotdone130
bb_rcslotdrop130:
  %v1007 = load i64, ptr %slot6, align 8
  %p1008 = inttoptr i64 %v1007 to ptr
  store i32 0, ptr %p1008, align 4, !alias.scope !3, !noalias !4
  %v1009 = load i64, ptr %slot11, align 8
  store i64 %v1009, ptr %slot136, align 8
  %v1010 = load i64, ptr %slot7, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  %ld1012 = load i32, ptr %p1011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1012, ptr %slot137, align 8
  %v1013 = load i32, ptr %slot137, align 8
  %op1014 = and i32 %v1013, 28
  store i32 %op1014, ptr %slot138, align 8
  %v1015 = load i32, ptr %slot138, align 8
  %cv1016 = zext i32 %v1015 to i64
  %cond1017 = icmp ne i64 %cv1016, 0
  br i1 %cond1017, label %bb_rcslotrole130, label %bb_rcslotowner130
bb_rcslotrole130:
  %v1018 = load i64, ptr %slot35, align 8
  store i64 %v1018, ptr %slot139, align 8
  %v1019 = load i64, ptr %slot139, align 8
  %v1020 = load i64, ptr %slot136, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1019, i64 %v1020) nomerge, !dbg !120
  br label %bb_rcslotdone130
bb_rcslotowner130:
  %v1021 = load i64, ptr %slot35, align 8
  store i64 %v1021, ptr %slot140, align 8
  %v1022 = load i64, ptr %slot140, align 8
  %v1023 = load i64, ptr %slot136, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1022, i64 %v1023) nomerge, !dbg !120
  br label %bb_rcslotdone130
bb_rcslotdone130:
  br label %bb_i38
bb_rcarmnext127:
  %v1024 = load i64, ptr %slot91, align 8
  %cmp1025 = icmp eq i64 %v1024, 7
  %cv1026 = zext i1 %cmp1025 to i64
  store i64 %cv1026, ptr %slot141, align 8
  %v1027 = load i64, ptr %slot141, align 8
  %cond1028 = icmp ne i64 %v1027, 0
  br i1 %cond1028, label %bb_rcarm137, label %bb_rcarmnext137
bb_rcarm137:
  %v1029 = load i64, ptr %slot90, align 8
  %op1030 = add i64 %v1029, 8
  store i64 %op1030, ptr %slot142, align 8
  %v1031 = load i64, ptr %slot142, align 8
  %v1032 = load i64, ptr %slot18, align 8
  %p1033 = inttoptr i64 %v1031 to ptr
  %p1034 = inttoptr i64 %v1032 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1034, ptr %p1033, i64 24, i1 false), !alias.scope !10000000
  %v1035 = load i64, ptr %slot6, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  %ld1037 = load i32, ptr %p1036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1037, ptr %slot143, align 8
  %v1038 = load i32, ptr %slot143, align 8
  %cv1039 = zext i32 %v1038 to i64
  %cond1040 = icmp ne i64 %cv1039, 0
  br i1 %cond1040, label %bb_rcslotdrop151, label %bb_rcslotdone151
bb_rcslotdrop151:
  %v1041 = load i64, ptr %slot6, align 8
  %p1042 = inttoptr i64 %v1041 to ptr
  store i32 0, ptr %p1042, align 4, !alias.scope !3, !noalias !4
  %v1043 = load i64, ptr %slot11, align 8
  store i64 %v1043, ptr %slot144, align 8
  %v1044 = load i64, ptr %slot7, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  %ld1046 = load i32, ptr %p1045, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1046, ptr %slot145, align 8
  %v1047 = load i32, ptr %slot145, align 8
  %op1048 = and i32 %v1047, 28
  store i32 %op1048, ptr %slot146, align 8
  %v1049 = load i32, ptr %slot146, align 8
  %cv1050 = zext i32 %v1049 to i64
  %cond1051 = icmp ne i64 %cv1050, 0
  br i1 %cond1051, label %bb_rcslotrole151, label %bb_rcslotowner151
bb_rcslotrole151:
  %v1052 = load i64, ptr %slot35, align 8
  store i64 %v1052, ptr %slot147, align 8
  %v1053 = load i64, ptr %slot147, align 8
  %v1054 = load i64, ptr %slot144, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1053, i64 %v1054) nomerge, !dbg !120
  br label %bb_rcslotdone151
bb_rcslotowner151:
  %v1055 = load i64, ptr %slot35, align 8
  store i64 %v1055, ptr %slot148, align 8
  %v1056 = load i64, ptr %slot148, align 8
  %v1057 = load i64, ptr %slot144, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1056, i64 %v1057) nomerge, !dbg !120
  br label %bb_rcslotdone151
bb_rcslotdone151:
  br label %bb_i19
bb_rcarmnext137:
  %v1058 = load i64, ptr %slot91, align 8
  %cmp1059 = icmp eq i64 %v1058, 8
  %cv1060 = zext i1 %cmp1059 to i64
  store i64 %cv1060, ptr %slot149, align 8
  %v1061 = load i64, ptr %slot149, align 8
  %cond1062 = icmp ne i64 %v1061, 0
  br i1 %cond1062, label %bb_rcarm158, label %bb_rcarmnext158
bb_rcarm158:
  %v1063 = load i64, ptr %slot6, align 8
  %p1064 = inttoptr i64 %v1063 to ptr
  %ld1065 = load i32, ptr %p1064, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1065, ptr %slot150, align 8
  %v1066 = load i32, ptr %slot150, align 8
  %cv1067 = zext i32 %v1066 to i64
  %cond1068 = icmp ne i64 %cv1067, 0
  br i1 %cond1068, label %bb_rcslotdrop161, label %bb_rcslotdone161
bb_rcslotdrop161:
  %v1069 = load i64, ptr %slot6, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  store i32 0, ptr %p1070, align 4, !alias.scope !3, !noalias !4
  %v1071 = load i64, ptr %slot11, align 8
  store i64 %v1071, ptr %slot151, align 8
  %v1072 = load i64, ptr %slot7, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i32, ptr %p1073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1074, ptr %slot152, align 8
  %v1075 = load i32, ptr %slot152, align 8
  %op1076 = and i32 %v1075, 28
  store i32 %op1076, ptr %slot153, align 8
  %v1077 = load i32, ptr %slot153, align 8
  %cv1078 = zext i32 %v1077 to i64
  %cond1079 = icmp ne i64 %cv1078, 0
  br i1 %cond1079, label %bb_rcslotrole161, label %bb_rcslotowner161
bb_rcslotrole161:
  %v1080 = load i64, ptr %slot35, align 8
  store i64 %v1080, ptr %slot154, align 8
  %v1081 = load i64, ptr %slot154, align 8
  %v1082 = load i64, ptr %slot151, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1081, i64 %v1082) nomerge, !dbg !120
  br label %bb_rcslotdone161
bb_rcslotowner161:
  %v1083 = load i64, ptr %slot35, align 8
  store i64 %v1083, ptr %slot155, align 8
  %v1084 = load i64, ptr %slot155, align 8
  %v1085 = load i64, ptr %slot151, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1084, i64 %v1085) nomerge, !dbg !120
  br label %bb_rcslotdone161
bb_rcslotdone161:
  br label %bb_i40
bb_rcarmnext158:
  %v1086 = load i64, ptr %slot91, align 8
  %cmp1087 = icmp eq i64 %v1086, 9
  %cv1088 = zext i1 %cmp1087 to i64
  store i64 %cv1088, ptr %slot156, align 8
  %v1089 = load i64, ptr %slot156, align 8
  %cond1090 = icmp ne i64 %v1089, 0
  br i1 %cond1090, label %bb_rcarm168, label %bb_rcarmnext168
bb_rcarm168:
  %v1091 = load i64, ptr %slot6, align 8
  %p1092 = inttoptr i64 %v1091 to ptr
  %ld1093 = load i32, ptr %p1092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1093, ptr %slot157, align 8
  %v1094 = load i32, ptr %slot157, align 8
  %cv1095 = zext i32 %v1094 to i64
  %cond1096 = icmp ne i64 %cv1095, 0
  br i1 %cond1096, label %bb_rcslotdrop171, label %bb_rcslotdone171
bb_rcslotdrop171:
  %v1097 = load i64, ptr %slot6, align 8
  %p1098 = inttoptr i64 %v1097 to ptr
  store i32 0, ptr %p1098, align 4, !alias.scope !3, !noalias !4
  %v1099 = load i64, ptr %slot11, align 8
  store i64 %v1099, ptr %slot158, align 8
  %v1100 = load i64, ptr %slot7, align 8
  %p1101 = inttoptr i64 %v1100 to ptr
  %ld1102 = load i32, ptr %p1101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1102, ptr %slot159, align 8
  %v1103 = load i32, ptr %slot159, align 8
  %op1104 = and i32 %v1103, 28
  store i32 %op1104, ptr %slot160, align 8
  %v1105 = load i32, ptr %slot160, align 8
  %cv1106 = zext i32 %v1105 to i64
  %cond1107 = icmp ne i64 %cv1106, 0
  br i1 %cond1107, label %bb_rcslotrole171, label %bb_rcslotowner171
bb_rcslotrole171:
  %v1108 = load i64, ptr %slot35, align 8
  store i64 %v1108, ptr %slot161, align 8
  %v1109 = load i64, ptr %slot161, align 8
  %v1110 = load i64, ptr %slot158, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1109, i64 %v1110) nomerge, !dbg !120
  br label %bb_rcslotdone171
bb_rcslotowner171:
  %v1111 = load i64, ptr %slot35, align 8
  store i64 %v1111, ptr %slot162, align 8
  %v1112 = load i64, ptr %slot162, align 8
  %v1113 = load i64, ptr %slot158, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1112, i64 %v1113) nomerge, !dbg !120
  br label %bb_rcslotdone171
bb_rcslotdone171:
  br label %bb_i42
bb_rcarmnext168:
  %v1114 = load i64, ptr %slot91, align 8
  %cmp1115 = icmp eq i64 %v1114, 10
  %cv1116 = zext i1 %cmp1115 to i64
  store i64 %cv1116, ptr %slot163, align 8
  %v1117 = load i64, ptr %slot163, align 8
  %cond1118 = icmp ne i64 %v1117, 0
  br i1 %cond1118, label %bb_rcarm178, label %bb_rcarmnext178
bb_rcarm178:
  %v1119 = load i64, ptr %slot6, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  %ld1121 = load i32, ptr %p1120, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1121, ptr %slot164, align 8
  %v1122 = load i32, ptr %slot164, align 8
  %cv1123 = zext i32 %v1122 to i64
  %cond1124 = icmp ne i64 %cv1123, 0
  br i1 %cond1124, label %bb_rcslotdrop181, label %bb_rcslotdone181
bb_rcslotdrop181:
  %v1125 = load i64, ptr %slot6, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  store i32 0, ptr %p1126, align 4, !alias.scope !3, !noalias !4
  %v1127 = load i64, ptr %slot11, align 8
  store i64 %v1127, ptr %slot165, align 8
  %v1128 = load i64, ptr %slot7, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %ld1130 = load i32, ptr %p1129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1130, ptr %slot166, align 8
  %v1131 = load i32, ptr %slot166, align 8
  %op1132 = and i32 %v1131, 28
  store i32 %op1132, ptr %slot167, align 8
  %v1133 = load i32, ptr %slot167, align 8
  %cv1134 = zext i32 %v1133 to i64
  %cond1135 = icmp ne i64 %cv1134, 0
  br i1 %cond1135, label %bb_rcslotrole181, label %bb_rcslotowner181
bb_rcslotrole181:
  %v1136 = load i64, ptr %slot35, align 8
  store i64 %v1136, ptr %slot168, align 8
  %v1137 = load i64, ptr %slot168, align 8
  %v1138 = load i64, ptr %slot165, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v1137, i64 %v1138) nomerge, !dbg !120
  br label %bb_rcslotdone181
bb_rcslotowner181:
  %v1139 = load i64, ptr %slot35, align 8
  store i64 %v1139, ptr %slot169, align 8
  %v1140 = load i64, ptr %slot169, align 8
  %v1141 = load i64, ptr %slot165, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v1140, i64 %v1141) nomerge, !dbg !120
  br label %bb_rcslotdone181
bb_rcslotdone181:
  br label %bb_i44
bb_rcarmnext178:
  br label %bb_failure
bb_i19:
  %v1142 = load i64, ptr %slot18, align 8
  %v1143 = load i64, ptr %slot19, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i64 %v1142, ptr %p1144, align 8, !alias.scope !3, !noalias !4
  %v1145 = load i64, ptr %slot18, align 8
  %v1146 = load i64, ptr %slot19, align 8
  %p1147 = inttoptr i64 %v1146 to ptr
  store i64 %v1145, ptr %p1147, align 8, !alias.scope !3, !noalias !4
  %v1148 = load i64, ptr %slot19, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  %ld1150 = load i64, ptr %p1149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1150, ptr %slot170, align 8
  %v1151 = load i64, ptr %slot6, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  %ld1153 = load i32, ptr %p1152, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1153, ptr %slot171, align 8
  %v1154 = load i64, ptr %slot7, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  %ld1156 = load i32, ptr %p1155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1156, ptr %slot172, align 8
  %v1157 = load i32, ptr %slot172, align 8
  %op1158 = and i32 %v1157, 24
  store i32 %op1158, ptr %slot172, align 8
  %v1159 = load i32, ptr %slot172, align 8
  %cmp1160 = icmp eq i32 %v1159, 0
  %cv1161 = zext i1 %cmp1160 to i32
  store i32 %cv1161, ptr %slot173, align 8
  %v1162 = load i32, ptr %slot171, align 8
  %v1163 = load i32, ptr %slot173, align 8
  %op1164 = and i32 %v1162, %v1163
  store i32 %op1164, ptr %slot174, align 8
  %v1165 = load i64, ptr %slot36, align 8
  store i64 %v1165, ptr %slot175, align 8
  %v1166 = load i32, ptr %slot174, align 8
  %op1167 = mul i32 %v1166, 4
  store i32 %op1167, ptr %slot176, align 8
  %v1168 = load i32, ptr %slot176, align 8
  %op1169 = or i32 %v1168, 0
  store i32 %op1169, ptr %slot177, align 8
  %v1170 = load i64, ptr %slot12, align 8
  store i64 %v1170, ptr %slot178, align 8
  %v1171 = load i64, ptr %slot35, align 8
  %v1172 = load i64, ptr %slot178, align 8
  %v1173 = load i64, ptr %slot170, align 8
  %v1174 = load i64, ptr %slot175, align 8
  %cv1175 = trunc i64 %v1174 to i32
  %v1176 = load i32, ptr %slot177, align 8
  %call1177 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_publish(i64 %v1171, i64 %v1172, i64 %v1173, i32 %cv1175, i32 %v1176) nomerge, !dbg !122
  store i32 %call1177, ptr %slot179, align 8
  %v1178 = load i32, ptr %slot179, align 8
  %cv1179 = zext i32 %v1178 to i64
  %cond1180 = icmp ne i64 %cv1179, 0
  br i1 %cond1180, label %bb_rcsuccess202, label %bb_rcfailure202
bb_rcfailure202:
  %v1181 = load i64, ptr %slot35, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %call1183 = call i32 @myl_rc_take_failure(ptr %p1182) nomerge, !dbg !122
  store i32 %call1183, ptr %slot180, align 8
  %v1184 = load i64, ptr %slot1, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  %v1186 = load i32, ptr %slot180, align 8
  %call1187 = call i32 @myl_qbe_rc_status(ptr %p1185, i32 %v1186) nomerge, !dbg !122
  store i32 %call1187, ptr %slot181, align 8
  br label %bb_failure
bb_rcsuccess202:
  %v1188 = load i32, ptr %slot174, align 8
  %cv1189 = zext i32 %v1188 to i64
  %cond1190 = icmp ne i64 %cv1189, 0
  br i1 %cond1190, label %bb_rchtaken205, label %bb_rchcopied205
bb_rchcopied205:
  %v1191 = load i64, ptr %slot6, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  %ld1193 = load i32, ptr %p1192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1193, ptr %slot182, align 8
  %v1194 = load i32, ptr %slot182, align 8
  %cv1195 = zext i32 %v1194 to i64
  %cond1196 = icmp ne i64 %cv1195, 0
  br i1 %cond1196, label %bb_rcslotdrop208, label %bb_rcslotdone208
bb_rcslotdrop208:
  %v1197 = load i64, ptr %slot6, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  store i32 0, ptr %p1198, align 4, !alias.scope !3, !noalias !4
  %v1199 = load i64, ptr %slot11, align 8
  store i64 %v1199, ptr %slot183, align 8
  %v1200 = load i64, ptr %slot7, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  %ld1202 = load i32, ptr %p1201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1202, ptr %slot184, align 8
  %v1203 = load i32, ptr %slot184, align 8
  %op1204 = and i32 %v1203, 28
  store i32 %op1204, ptr %slot185, align 8
  %v1205 = load i32, ptr %slot185, align 8
  %cv1206 = zext i32 %v1205 to i64
  %cond1207 = icmp ne i64 %cv1206, 0
  br i1 %cond1207, label %bb_rcslotrole208, label %bb_rcslotowner208
bb_rcslotrole208:
  %v1208 = load i64, ptr %slot35, align 8
  store i64 %v1208, ptr %slot186, align 8
  %v1209 = load i64, ptr %slot186, align 8
  %v1210 = load i64, ptr %slot183, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64 %v1209, i64 %v1210) nomerge, !dbg !122
  br label %bb_rcslotdone208
bb_rcslotowner208:
  %v1211 = load i64, ptr %slot35, align 8
  store i64 %v1211, ptr %slot187, align 8
  %v1212 = load i64, ptr %slot187, align 8
  %v1213 = load i64, ptr %slot183, align 8
  call void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64 %v1212, i64 %v1213) nomerge, !dbg !122
  br label %bb_rcslotdone208
bb_rcslotdone208:
  br label %bb_rchprepared205
bb_rchtaken205:
  %v1214 = load i64, ptr %slot6, align 8
  %p1215 = inttoptr i64 %v1214 to ptr
  store i32 0, ptr %p1215, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared205
bb_rchprepared205:
  %v1216 = load i64, ptr %slot9, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  store i32 2, ptr %p1217, align 4, !alias.scope !3, !noalias !4
  %v1218 = load i64, ptr %slot8, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  store i32 1, ptr %p1219, align 4, !alias.scope !3, !noalias !4
  %v1220 = load i64, ptr %slot11, align 8
  store i64 %v1220, ptr %slot188, align 8
  %v1221 = load i64, ptr %slot12, align 8
  store i64 %v1221, ptr %slot189, align 8
  %v1222 = load i64, ptr %slot189, align 8
  %v1223 = load i64, ptr %slot188, align 8
  %p1224 = inttoptr i64 %v1222 to ptr
  %p1225 = inttoptr i64 %v1223 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1225, ptr %p1224, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot7, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  store i32 2, ptr %p1227, align 4, !alias.scope !3, !noalias !4
  %v1228 = load i64, ptr %slot9, align 8
  %p1229 = inttoptr i64 %v1228 to ptr
  %ld1230 = load i32, ptr %p1229, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1230, ptr %slot190, align 8
  %v1231 = load i32, ptr %slot190, align 8
  %v1232 = load i64, ptr %slot7, align 8
  %p1233 = inttoptr i64 %v1232 to ptr
  store i32 %v1231, ptr %p1233, align 4, !alias.scope !3, !noalias !4
  %v1234 = load i64, ptr %slot8, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  store i32 0, ptr %p1235, align 4, !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot6, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i32 1, ptr %p1237, align 4, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot188, align 8
  %v1239 = load i64, ptr %slot19, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  store i64 %v1238, ptr %p1240, align 8, !alias.scope !3, !noalias !4
  %v1241 = load i64, ptr %slot21, align 8
  store i64 %v1241, ptr %slot191, align 8
  %v1242 = load i64, ptr %slot191, align 8
  %p1243 = inttoptr i64 %v1242 to ptr
  store i64 0, ptr %p1243, align 8, !alias.scope !3, !noalias !4
  %v1244 = load i64, ptr %slot191, align 8
  %p1246 = inttoptr i64 %v1244 to ptr
  %gep1247 = getelementptr i8, ptr %p1246, i64 8
  %op1245 = ptrtoint ptr %gep1247 to i64
  store i64 %op1245, ptr %slot192, align 8
  %v1248 = load i64, ptr %slot192, align 8
  %p1249 = inttoptr i64 %v1248 to ptr
  store i64 0, ptr %p1249, align 8, !alias.scope !3, !noalias !4
  %v1250 = load i64, ptr %slot191, align 8
  %p1252 = inttoptr i64 %v1250 to ptr
  %gep1253 = getelementptr i8, ptr %p1252, i64 16
  %op1251 = ptrtoint ptr %gep1253 to i64
  store i64 %op1251, ptr %slot193, align 8
  %v1254 = load i64, ptr %slot193, align 8
  %p1255 = inttoptr i64 %v1254 to ptr
  store i64 0, ptr %p1255, align 8, !alias.scope !3, !noalias !4
  %v1256 = load i64, ptr %slot191, align 8
  %p1258 = inttoptr i64 %v1256 to ptr
  %gep1259 = getelementptr i8, ptr %p1258, i64 24
  %op1257 = ptrtoint ptr %gep1259 to i64
  store i64 %op1257, ptr %slot194, align 8
  %v1260 = load i64, ptr %slot194, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  store i64 0, ptr %p1261, align 8, !alias.scope !3, !noalias !4
  %v1262 = load i64, ptr %slot191, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  store i32 1, ptr %p1263, align 4, !alias.scope !3, !noalias !4
  %v1264 = load i64, ptr %slot10, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  store i32 1, ptr %p1265, align 4, !alias.scope !3, !noalias !4
  %v1266 = load i64, ptr %slot19, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %ld1268 = load i64, ptr %p1267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1268, ptr %slot195, align 8
  %v1269 = load i64, ptr %slot191, align 8
  %p1271 = inttoptr i64 %v1269 to ptr
  %gep1272 = getelementptr i8, ptr %p1271, i64 8
  %op1270 = ptrtoint ptr %gep1272 to i64
  store i64 %op1270, ptr %slot196, align 8
  %v1273 = load i64, ptr %slot36, align 8
  store i64 %v1273, ptr %slot197, align 8
  %v1274 = load i64, ptr %slot19, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  %ld1276 = load i64, ptr %p1275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1276, ptr %slot198, align 8
  %v1277 = load i64, ptr %slot12, align 8
  store i64 %v1277, ptr %slot199, align 8
  %v1278 = load i64, ptr %slot36, align 8
  store i64 %v1278, ptr %slot200, align 8
  %v1279 = load i64, ptr %slot198, align 8
  %op1280 = add i64 %v1279, 8
  store i64 %op1280, ptr %slot201, align 8
  %v1281 = load i64, ptr %slot201, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  %ld1283 = load i64, ptr %p1282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1283, ptr %slot202, align 8
  %v1284 = load i64, ptr %slot202, align 8
  %cmp1285 = icmp ne i64 %v1284, 0
  %cv1286 = zext i1 %cmp1285 to i32
  store i32 %cv1286, ptr %slot203, align 8
  %v1287 = load i32, ptr %slot203, align 8
  %cv1288 = zext i32 %v1287 to i64
  %cond1289 = icmp ne i64 %cv1288, 0
  br i1 %cond1289, label %bb_rcmoveheader241, label %bb_rcmovenext241
bb_rcmoveheader241:
  %v1290 = load i64, ptr %slot202, align 8
  %op1291 = sub i64 %v1290, 16
  store i64 %op1291, ptr %slot204, align 8
  %v1292 = load i64, ptr %slot202, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  %rgep1294 = getelementptr i8, ptr %p1293, i64 -16
  %ld1295 = load i64, ptr %rgep1294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1295, ptr %slot205, align 8
  %v1296 = load i64, ptr %slot205, align 8
  %op1297 = and i64 %v1296, 5764607523034234881
  store i64 %op1297, ptr %slot206, align 8
  %v1298 = load i64, ptr %slot206, align 8
  %cmp1299 = icmp ne i64 %v1298, 0
  %cv1300 = zext i1 %cmp1299 to i32
  store i32 %cv1300, ptr %slot207, align 8
  %v1301 = load i32, ptr %slot207, align 8
  %cv1302 = zext i32 %v1301 to i64
  %cond1303 = icmp ne i64 %cv1302, 0
  br i1 %cond1303, label %bb_rcmoveslow238, label %bb_rcmovenext241
bb_rcmovenext241:
  %v1304 = load i64, ptr %slot198, align 8
  %v1305 = load i64, ptr %slot199, align 8
  %p1306 = inttoptr i64 %v1304 to ptr
  %p1307 = inttoptr i64 %v1305 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1307, ptr %p1306, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1308 = load i64, ptr %slot198, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  store i64 0, ptr %p1309, align 8, !alias.scope !3, !noalias !4
  %v1310 = load i64, ptr %slot198, align 8
  %op1311 = add i64 %v1310, 8
  store i64 %op1311, ptr %slot208, align 8
  %v1312 = load i64, ptr %slot208, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  store i64 0, ptr %p1313, align 8, !alias.scope !3, !noalias !4
  %v1314 = load i64, ptr %slot198, align 8
  %op1315 = add i64 %v1314, 16
  store i64 %op1315, ptr %slot209, align 8
  %v1316 = load i64, ptr %slot209, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  store i64 0, ptr %p1317, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved238
bb_rcmoveslow238:
  %v1318 = load i64, ptr %slot35, align 8
  %v1319 = load i64, ptr %slot199, align 8
  %v1320 = load i64, ptr %slot198, align 8
  %v1321 = load i64, ptr %slot200, align 8
  %cv1322 = trunc i64 %v1321 to i32
  %call1323 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v1318, i64 %v1319, i64 %v1320, i32 %cv1322) nomerge, !dbg !124
  store i32 %call1323, ptr %slot210, align 8
  %v1324 = load i32, ptr %slot210, align 8
  %cv1325 = zext i32 %v1324 to i64
  %cond1326 = icmp ne i64 %cv1325, 0
  br i1 %cond1326, label %bb_rcsuccess250, label %bb_rcfailure250
bb_rcfailure250:
  %v1327 = load i64, ptr %slot35, align 8
  %p1328 = inttoptr i64 %v1327 to ptr
  %call1329 = call i32 @myl_rc_take_failure(ptr %p1328) nomerge, !dbg !124
  store i32 %call1329, ptr %slot211, align 8
  %v1330 = load i64, ptr %slot1, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  %v1332 = load i32, ptr %slot211, align 8
  %call1333 = call i32 @myl_qbe_rc_status(ptr %p1331, i32 %v1332) nomerge, !dbg !124
  store i32 %call1333, ptr %slot212, align 8
  br label %bb_failure
bb_rcsuccess250:
  br label %bb_rcmoved238
bb_rcmoved238:
  %v1334 = load i64, ptr %slot6, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i32 0, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot9, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  store i32 2, ptr %p1337, align 4, !alias.scope !3, !noalias !4
  %v1338 = load i64, ptr %slot8, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  store i32 1, ptr %p1339, align 4, !alias.scope !3, !noalias !4
  %v1340 = load i64, ptr %slot12, align 8
  store i64 %v1340, ptr %slot213, align 8
  %v1341 = load i64, ptr %slot213, align 8
  %v1342 = load i64, ptr %slot196, align 8
  %p1343 = inttoptr i64 %v1341 to ptr
  %p1344 = inttoptr i64 %v1342 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1344, ptr %p1343, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1345 = load i64, ptr %slot8, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  store i32 0, ptr %p1346, align 4, !alias.scope !3, !noalias !4
  %v1347 = load i64, ptr %slot191, align 8
  %v1348 = load i64, ptr %slot19, align 8
  %p1349 = inttoptr i64 %v1348 to ptr
  store i64 %v1347, ptr %p1349, align 8, !alias.scope !3, !noalias !4
  %v1350 = load i64, ptr %slot19, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  %ld1352 = load i64, ptr %p1351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1352, ptr %slot214, align 8
  %v1353 = load i64, ptr %slot11, align 8
  store i64 %v1353, ptr %slot215, align 8
  %v1354 = load i64, ptr %slot214, align 8
  %v1355 = load i64, ptr %slot215, align 8
  %p1356 = inttoptr i64 %v1354 to ptr
  %p1357 = inttoptr i64 %v1355 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1357, ptr %p1356, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1358 = load i64, ptr %slot7, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  store i32 2, ptr %p1359, align 4, !alias.scope !3, !noalias !4
  %v1360 = load i64, ptr %slot6, align 8
  %p1361 = inttoptr i64 %v1360 to ptr
  store i32 1, ptr %p1361, align 4, !alias.scope !3, !noalias !4
  %v1362 = load i64, ptr %slot215, align 8
  %v1363 = load i64, ptr %slot19, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  store i64 %v1362, ptr %p1364, align 8, !alias.scope !3, !noalias !4
  %v1365 = load i64, ptr %slot19, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  %ld1367 = load i64, ptr %p1366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1367, ptr %slot216, align 8
  %v1368 = load i64, ptr %slot19, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  %ld1370 = load i64, ptr %p1369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1370, ptr %slot217, align 8
  %v1371 = load i64, ptr %slot12, align 8
  store i64 %v1371, ptr %slot218, align 8
  %v1372 = load i64, ptr %slot36, align 8
  store i64 %v1372, ptr %slot219, align 8
  %v1373 = load i64, ptr %slot35, align 8
  %v1374 = load i64, ptr %slot218, align 8
  %v1375 = load i64, ptr %slot217, align 8
  %v1376 = load i64, ptr %slot219, align 8
  %cv1377 = trunc i64 %v1376 to i32
  %call1378 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v1373, i64 %v1374, i64 %v1375, i32 %cv1377) nomerge, !dbg !126
  store i32 %call1378, ptr %slot220, align 8
  %v1379 = load i32, ptr %slot220, align 8
  %cv1380 = zext i32 %v1379 to i64
  %cond1381 = icmp ne i64 %cv1380, 0
  br i1 %cond1381, label %bb_rcsuccess267, label %bb_rcfailure267
bb_rcfailure267:
  %v1382 = load i64, ptr %slot35, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %call1384 = call i32 @myl_rc_take_failure(ptr %p1383) nomerge, !dbg !126
  store i32 %call1384, ptr %slot221, align 8
  %v1385 = load i64, ptr %slot1, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  %v1387 = load i32, ptr %slot221, align 8
  %call1388 = call i32 @myl_qbe_rc_status(ptr %p1386, i32 %v1387) nomerge, !dbg !126
  store i32 %call1388, ptr %slot222, align 8
  br label %bb_failure
bb_rcsuccess267:
  %v1389 = load i64, ptr %slot6, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  store i32 0, ptr %p1390, align 4, !alias.scope !3, !noalias !4
  %v1391 = load i64, ptr %slot9, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  store i32 2, ptr %p1392, align 4, !alias.scope !3, !noalias !4
  %v1393 = load i64, ptr %slot8, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  store i32 1, ptr %p1394, align 4, !alias.scope !3, !noalias !4
  %v1395 = load i64, ptr %slot12, align 8
  store i64 %v1395, ptr %slot223, align 8
  %v1396 = load i64, ptr %slot8, align 8
  %p1397 = inttoptr i64 %v1396 to ptr
  store i32 0, ptr %p1397, align 4, !alias.scope !3, !noalias !4
  %v1398 = load i64, ptr %slot6, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  %ld1400 = load i32, ptr %p1399, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1400, ptr %slot224, align 8
  %v1401 = load i32, ptr %slot224, align 8
  %cv1402 = zext i32 %v1401 to i64
  %cond1403 = icmp ne i64 %cv1402, 0
  br i1 %cond1403, label %bb_rcslotdrop277, label %bb_rcslotdone277
bb_rcslotdrop277:
  %v1404 = load i64, ptr %slot6, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  store i32 0, ptr %p1405, align 4, !alias.scope !3, !noalias !4
  %v1406 = load i64, ptr %slot11, align 8
  store i64 %v1406, ptr %slot225, align 8
  %v1407 = load i64, ptr %slot7, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  %ld1409 = load i32, ptr %p1408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1409, ptr %slot226, align 8
  %v1410 = load i32, ptr %slot226, align 8
  %op1411 = and i32 %v1410, 28
  store i32 %op1411, ptr %slot227, align 8
  %v1412 = load i32, ptr %slot227, align 8
  %cv1413 = zext i32 %v1412 to i64
  %cond1414 = icmp ne i64 %cv1413, 0
  br i1 %cond1414, label %bb_rcslotrole277, label %bb_rcslotowner277
bb_rcslotrole277:
  %v1415 = load i64, ptr %slot35, align 8
  store i64 %v1415, ptr %slot228, align 8
  %v1416 = load i64, ptr %slot228, align 8
  %v1417 = load i64, ptr %slot225, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v1416, i64 %v1417) nomerge, !dbg !126
  br label %bb_rcslotdone277
bb_rcslotowner277:
  %v1418 = load i64, ptr %slot35, align 8
  store i64 %v1418, ptr %slot229, align 8
  %v1419 = load i64, ptr %slot229, align 8
  %v1420 = load i64, ptr %slot225, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v1419, i64 %v1420) nomerge, !dbg !126
  br label %bb_rcslotdone277
bb_rcslotdone277:
  %v1421 = load i64, ptr %slot223, align 8
  %p1422 = inttoptr i64 %v1421 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1422, i64 32, i1 false)
  ret void
bb_i26:
  %v1423 = load i64, ptr %slot22, align 8
  store i64 %v1423, ptr %slot230, align 8
  %v1424 = load i64, ptr %slot230, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i64 0, ptr %p1425, align 8, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot230, align 8
  %p1428 = inttoptr i64 %v1426 to ptr
  %gep1429 = getelementptr i8, ptr %p1428, i64 8
  %op1427 = ptrtoint ptr %gep1429 to i64
  store i64 %op1427, ptr %slot231, align 8
  %v1430 = load i64, ptr %slot231, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  store i64 0, ptr %p1431, align 8, !alias.scope !3, !noalias !4
  %v1432 = load i64, ptr %slot230, align 8
  %p1434 = inttoptr i64 %v1432 to ptr
  %gep1435 = getelementptr i8, ptr %p1434, i64 16
  %op1433 = ptrtoint ptr %gep1435 to i64
  store i64 %op1433, ptr %slot232, align 8
  %v1436 = load i64, ptr %slot232, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  store i64 0, ptr %p1437, align 8, !alias.scope !3, !noalias !4
  %v1438 = load i64, ptr %slot230, align 8
  %p1440 = inttoptr i64 %v1438 to ptr
  %gep1441 = getelementptr i8, ptr %p1440, i64 24
  %op1439 = ptrtoint ptr %gep1441 to i64
  store i64 %op1439, ptr %slot233, align 8
  %v1442 = load i64, ptr %slot233, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  store i64 0, ptr %p1443, align 8, !alias.scope !3, !noalias !4
  %v1444 = load i64, ptr %slot230, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i32 0, ptr %p1445, align 4, !alias.scope !3, !noalias !4
  %v1446 = load i64, ptr %slot230, align 8
  %v1447 = load i64, ptr %slot19, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  store i64 %v1446, ptr %p1448, align 8, !alias.scope !3, !noalias !4
  %v1449 = load i64, ptr %slot19, align 8
  %p1450 = inttoptr i64 %v1449 to ptr
  %ld1451 = load i64, ptr %p1450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1451, ptr %slot234, align 8
  %v1452 = load i64, ptr %slot11, align 8
  store i64 %v1452, ptr %slot235, align 8
  %v1453 = load i64, ptr %slot234, align 8
  %v1454 = load i64, ptr %slot235, align 8
  %p1455 = inttoptr i64 %v1453 to ptr
  %p1456 = inttoptr i64 %v1454 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1456, ptr %p1455, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1457 = load i64, ptr %slot7, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  store i32 2, ptr %p1458, align 4, !alias.scope !3, !noalias !4
  %v1459 = load i64, ptr %slot6, align 8
  %p1460 = inttoptr i64 %v1459 to ptr
  store i32 1, ptr %p1460, align 4, !alias.scope !3, !noalias !4
  %v1461 = load i64, ptr %slot235, align 8
  %v1462 = load i64, ptr %slot19, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  store i64 %v1461, ptr %p1463, align 8, !alias.scope !3, !noalias !4
  %v1464 = load i64, ptr %slot19, align 8
  %p1465 = inttoptr i64 %v1464 to ptr
  %ld1466 = load i64, ptr %p1465, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1466, ptr %slot236, align 8
  %v1467 = load i64, ptr %slot19, align 8
  %p1468 = inttoptr i64 %v1467 to ptr
  %ld1469 = load i64, ptr %p1468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1469, ptr %slot237, align 8
  %v1470 = load i64, ptr %slot12, align 8
  store i64 %v1470, ptr %slot238, align 8
  %v1471 = load i64, ptr %slot36, align 8
  store i64 %v1471, ptr %slot239, align 8
  %v1472 = load i64, ptr %slot35, align 8
  %v1473 = load i64, ptr %slot238, align 8
  %v1474 = load i64, ptr %slot237, align 8
  %v1475 = load i64, ptr %slot239, align 8
  %cv1476 = trunc i64 %v1475 to i32
  %call1477 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v1472, i64 %v1473, i64 %v1474, i32 %cv1476) nomerge, !dbg !128
  store i32 %call1477, ptr %slot240, align 8
  %v1478 = load i32, ptr %slot240, align 8
  %cv1479 = zext i32 %v1478 to i64
  %cond1480 = icmp ne i64 %cv1479, 0
  br i1 %cond1480, label %bb_rcsuccess352, label %bb_rcfailure352
bb_rcfailure352:
  %v1481 = load i64, ptr %slot35, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  %call1483 = call i32 @myl_rc_take_failure(ptr %p1482) nomerge, !dbg !128
  store i32 %call1483, ptr %slot241, align 8
  %v1484 = load i64, ptr %slot1, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  %v1486 = load i32, ptr %slot241, align 8
  %call1487 = call i32 @myl_qbe_rc_status(ptr %p1485, i32 %v1486) nomerge, !dbg !128
  store i32 %call1487, ptr %slot242, align 8
  br label %bb_failure
bb_rcsuccess352:
  %v1488 = load i64, ptr %slot6, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  store i32 0, ptr %p1489, align 4, !alias.scope !3, !noalias !4
  %v1490 = load i64, ptr %slot9, align 8
  %p1491 = inttoptr i64 %v1490 to ptr
  store i32 2, ptr %p1491, align 4, !alias.scope !3, !noalias !4
  %v1492 = load i64, ptr %slot8, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  store i32 1, ptr %p1493, align 4, !alias.scope !3, !noalias !4
  %v1494 = load i64, ptr %slot12, align 8
  store i64 %v1494, ptr %slot243, align 8
  %v1495 = load i64, ptr %slot8, align 8
  %p1496 = inttoptr i64 %v1495 to ptr
  store i32 0, ptr %p1496, align 4, !alias.scope !3, !noalias !4
  %v1497 = load i64, ptr %slot6, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  %ld1499 = load i32, ptr %p1498, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1499, ptr %slot244, align 8
  %v1500 = load i32, ptr %slot244, align 8
  %cv1501 = zext i32 %v1500 to i64
  %cond1502 = icmp ne i64 %cv1501, 0
  br i1 %cond1502, label %bb_rcslotdrop362, label %bb_rcslotdone362
bb_rcslotdrop362:
  %v1503 = load i64, ptr %slot6, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  store i32 0, ptr %p1504, align 4, !alias.scope !3, !noalias !4
  %v1505 = load i64, ptr %slot11, align 8
  store i64 %v1505, ptr %slot245, align 8
  %v1506 = load i64, ptr %slot7, align 8
  %p1507 = inttoptr i64 %v1506 to ptr
  %ld1508 = load i32, ptr %p1507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1508, ptr %slot246, align 8
  %v1509 = load i32, ptr %slot246, align 8
  %op1510 = and i32 %v1509, 28
  store i32 %op1510, ptr %slot247, align 8
  %v1511 = load i32, ptr %slot247, align 8
  %cv1512 = zext i32 %v1511 to i64
  %cond1513 = icmp ne i64 %cv1512, 0
  br i1 %cond1513, label %bb_rcslotrole362, label %bb_rcslotowner362
bb_rcslotrole362:
  %v1514 = load i64, ptr %slot35, align 8
  store i64 %v1514, ptr %slot248, align 8
  %v1515 = load i64, ptr %slot248, align 8
  %v1516 = load i64, ptr %slot245, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v1515, i64 %v1516) nomerge, !dbg !128
  br label %bb_rcslotdone362
bb_rcslotowner362:
  %v1517 = load i64, ptr %slot35, align 8
  store i64 %v1517, ptr %slot249, align 8
  %v1518 = load i64, ptr %slot249, align 8
  %v1519 = load i64, ptr %slot245, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v1518, i64 %v1519) nomerge, !dbg !128
  br label %bb_rcslotdone362
bb_rcslotdone362:
  %v1520 = load i64, ptr %slot243, align 8
  %p1521 = inttoptr i64 %v1520 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1521, i64 32, i1 false)
  ret void
bb_i28:
  %v1522 = load i64, ptr %slot23, align 8
  store i64 %v1522, ptr %slot250, align 8
  %v1523 = load i64, ptr %slot250, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i64 0, ptr %p1524, align 8, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot250, align 8
  %p1527 = inttoptr i64 %v1525 to ptr
  %gep1528 = getelementptr i8, ptr %p1527, i64 8
  %op1526 = ptrtoint ptr %gep1528 to i64
  store i64 %op1526, ptr %slot251, align 8
  %v1529 = load i64, ptr %slot251, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  store i64 0, ptr %p1530, align 8, !alias.scope !3, !noalias !4
  %v1531 = load i64, ptr %slot250, align 8
  %p1533 = inttoptr i64 %v1531 to ptr
  %gep1534 = getelementptr i8, ptr %p1533, i64 16
  %op1532 = ptrtoint ptr %gep1534 to i64
  store i64 %op1532, ptr %slot252, align 8
  %v1535 = load i64, ptr %slot252, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  store i64 0, ptr %p1536, align 8, !alias.scope !3, !noalias !4
  %v1537 = load i64, ptr %slot250, align 8
  %p1539 = inttoptr i64 %v1537 to ptr
  %gep1540 = getelementptr i8, ptr %p1539, i64 24
  %op1538 = ptrtoint ptr %gep1540 to i64
  store i64 %op1538, ptr %slot253, align 8
  %v1541 = load i64, ptr %slot253, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  store i64 0, ptr %p1542, align 8, !alias.scope !3, !noalias !4
  %v1543 = load i64, ptr %slot250, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  store i32 0, ptr %p1544, align 4, !alias.scope !3, !noalias !4
  %v1545 = load i64, ptr %slot250, align 8
  %v1546 = load i64, ptr %slot19, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  store i64 %v1545, ptr %p1547, align 8, !alias.scope !3, !noalias !4
  %v1548 = load i64, ptr %slot19, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  %ld1550 = load i64, ptr %p1549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1550, ptr %slot254, align 8
  %v1551 = load i64, ptr %slot11, align 8
  store i64 %v1551, ptr %slot255, align 8
  %v1552 = load i64, ptr %slot254, align 8
  %v1553 = load i64, ptr %slot255, align 8
  %p1554 = inttoptr i64 %v1552 to ptr
  %p1555 = inttoptr i64 %v1553 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1555, ptr %p1554, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1556 = load i64, ptr %slot7, align 8
  %p1557 = inttoptr i64 %v1556 to ptr
  store i32 2, ptr %p1557, align 4, !alias.scope !3, !noalias !4
  %v1558 = load i64, ptr %slot6, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  store i32 1, ptr %p1559, align 4, !alias.scope !3, !noalias !4
  %v1560 = load i64, ptr %slot255, align 8
  %v1561 = load i64, ptr %slot19, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  store i64 %v1560, ptr %p1562, align 8, !alias.scope !3, !noalias !4
  %v1563 = load i64, ptr %slot19, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  %ld1565 = load i64, ptr %p1564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1565, ptr %slot256, align 8
  %v1566 = load i64, ptr %slot19, align 8
  %p1567 = inttoptr i64 %v1566 to ptr
  %ld1568 = load i64, ptr %p1567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1568, ptr %slot257, align 8
  %v1569 = load i64, ptr %slot12, align 8
  store i64 %v1569, ptr %slot258, align 8
  %v1570 = load i64, ptr %slot36, align 8
  store i64 %v1570, ptr %slot259, align 8
  %v1571 = load i64, ptr %slot35, align 8
  %v1572 = load i64, ptr %slot258, align 8
  %v1573 = load i64, ptr %slot257, align 8
  %v1574 = load i64, ptr %slot259, align 8
  %cv1575 = trunc i64 %v1574 to i32
  %call1576 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v1571, i64 %v1572, i64 %v1573, i32 %cv1575) nomerge, !dbg !130
  store i32 %call1576, ptr %slot260, align 8
  %v1577 = load i32, ptr %slot260, align 8
  %cv1578 = zext i32 %v1577 to i64
  %cond1579 = icmp ne i64 %cv1578, 0
  br i1 %cond1579, label %bb_rcsuccess437, label %bb_rcfailure437
bb_rcfailure437:
  %v1580 = load i64, ptr %slot35, align 8
  %p1581 = inttoptr i64 %v1580 to ptr
  %call1582 = call i32 @myl_rc_take_failure(ptr %p1581) nomerge, !dbg !130
  store i32 %call1582, ptr %slot261, align 8
  %v1583 = load i64, ptr %slot1, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %v1585 = load i32, ptr %slot261, align 8
  %call1586 = call i32 @myl_qbe_rc_status(ptr %p1584, i32 %v1585) nomerge, !dbg !130
  store i32 %call1586, ptr %slot262, align 8
  br label %bb_failure
bb_rcsuccess437:
  %v1587 = load i64, ptr %slot6, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  store i32 0, ptr %p1588, align 4, !alias.scope !3, !noalias !4
  %v1589 = load i64, ptr %slot9, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  store i32 2, ptr %p1590, align 4, !alias.scope !3, !noalias !4
  %v1591 = load i64, ptr %slot8, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i32 1, ptr %p1592, align 4, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot12, align 8
  store i64 %v1593, ptr %slot263, align 8
  %v1594 = load i64, ptr %slot8, align 8
  %p1595 = inttoptr i64 %v1594 to ptr
  store i32 0, ptr %p1595, align 4, !alias.scope !3, !noalias !4
  %v1596 = load i64, ptr %slot6, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %ld1598 = load i32, ptr %p1597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1598, ptr %slot264, align 8
  %v1599 = load i32, ptr %slot264, align 8
  %cv1600 = zext i32 %v1599 to i64
  %cond1601 = icmp ne i64 %cv1600, 0
  br i1 %cond1601, label %bb_rcslotdrop447, label %bb_rcslotdone447
bb_rcslotdrop447:
  %v1602 = load i64, ptr %slot6, align 8
  %p1603 = inttoptr i64 %v1602 to ptr
  store i32 0, ptr %p1603, align 4, !alias.scope !3, !noalias !4
  %v1604 = load i64, ptr %slot11, align 8
  store i64 %v1604, ptr %slot265, align 8
  %v1605 = load i64, ptr %slot7, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  %ld1607 = load i32, ptr %p1606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1607, ptr %slot266, align 8
  %v1608 = load i32, ptr %slot266, align 8
  %op1609 = and i32 %v1608, 28
  store i32 %op1609, ptr %slot267, align 8
  %v1610 = load i32, ptr %slot267, align 8
  %cv1611 = zext i32 %v1610 to i64
  %cond1612 = icmp ne i64 %cv1611, 0
  br i1 %cond1612, label %bb_rcslotrole447, label %bb_rcslotowner447
bb_rcslotrole447:
  %v1613 = load i64, ptr %slot35, align 8
  store i64 %v1613, ptr %slot268, align 8
  %v1614 = load i64, ptr %slot268, align 8
  %v1615 = load i64, ptr %slot265, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v1614, i64 %v1615) nomerge, !dbg !130
  br label %bb_rcslotdone447
bb_rcslotowner447:
  %v1616 = load i64, ptr %slot35, align 8
  store i64 %v1616, ptr %slot269, align 8
  %v1617 = load i64, ptr %slot269, align 8
  %v1618 = load i64, ptr %slot265, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v1617, i64 %v1618) nomerge, !dbg !130
  br label %bb_rcslotdone447
bb_rcslotdone447:
  %v1619 = load i64, ptr %slot263, align 8
  %p1620 = inttoptr i64 %v1619 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1620, i64 32, i1 false)
  ret void
bb_i30:
  %v1621 = load i64, ptr %slot24, align 8
  store i64 %v1621, ptr %slot270, align 8
  %v1622 = load i64, ptr %slot270, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i64 0, ptr %p1623, align 8, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot270, align 8
  %p1626 = inttoptr i64 %v1624 to ptr
  %gep1627 = getelementptr i8, ptr %p1626, i64 8
  %op1625 = ptrtoint ptr %gep1627 to i64
  store i64 %op1625, ptr %slot271, align 8
  %v1628 = load i64, ptr %slot271, align 8
  %p1629 = inttoptr i64 %v1628 to ptr
  store i64 0, ptr %p1629, align 8, !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot270, align 8
  %p1632 = inttoptr i64 %v1630 to ptr
  %gep1633 = getelementptr i8, ptr %p1632, i64 16
  %op1631 = ptrtoint ptr %gep1633 to i64
  store i64 %op1631, ptr %slot272, align 8
  %v1634 = load i64, ptr %slot272, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  store i64 0, ptr %p1635, align 8, !alias.scope !3, !noalias !4
  %v1636 = load i64, ptr %slot270, align 8
  %p1638 = inttoptr i64 %v1636 to ptr
  %gep1639 = getelementptr i8, ptr %p1638, i64 24
  %op1637 = ptrtoint ptr %gep1639 to i64
  store i64 %op1637, ptr %slot273, align 8
  %v1640 = load i64, ptr %slot273, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  store i64 0, ptr %p1641, align 8, !alias.scope !3, !noalias !4
  %v1642 = load i64, ptr %slot270, align 8
  %p1643 = inttoptr i64 %v1642 to ptr
  store i32 0, ptr %p1643, align 4, !alias.scope !3, !noalias !4
  %v1644 = load i64, ptr %slot270, align 8
  %v1645 = load i64, ptr %slot19, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  store i64 %v1644, ptr %p1646, align 8, !alias.scope !3, !noalias !4
  %v1647 = load i64, ptr %slot19, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %ld1649 = load i64, ptr %p1648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1649, ptr %slot274, align 8
  %v1650 = load i64, ptr %slot11, align 8
  store i64 %v1650, ptr %slot275, align 8
  %v1651 = load i64, ptr %slot274, align 8
  %v1652 = load i64, ptr %slot275, align 8
  %p1653 = inttoptr i64 %v1651 to ptr
  %p1654 = inttoptr i64 %v1652 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1654, ptr %p1653, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1655 = load i64, ptr %slot7, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  store i32 2, ptr %p1656, align 4, !alias.scope !3, !noalias !4
  %v1657 = load i64, ptr %slot6, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  store i32 1, ptr %p1658, align 4, !alias.scope !3, !noalias !4
  %v1659 = load i64, ptr %slot275, align 8
  %v1660 = load i64, ptr %slot19, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  store i64 %v1659, ptr %p1661, align 8, !alias.scope !3, !noalias !4
  %v1662 = load i64, ptr %slot19, align 8
  %p1663 = inttoptr i64 %v1662 to ptr
  %ld1664 = load i64, ptr %p1663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1664, ptr %slot276, align 8
  %v1665 = load i64, ptr %slot19, align 8
  %p1666 = inttoptr i64 %v1665 to ptr
  %ld1667 = load i64, ptr %p1666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1667, ptr %slot277, align 8
  %v1668 = load i64, ptr %slot12, align 8
  store i64 %v1668, ptr %slot278, align 8
  %v1669 = load i64, ptr %slot36, align 8
  store i64 %v1669, ptr %slot279, align 8
  %v1670 = load i64, ptr %slot35, align 8
  %v1671 = load i64, ptr %slot278, align 8
  %v1672 = load i64, ptr %slot277, align 8
  %v1673 = load i64, ptr %slot279, align 8
  %cv1674 = trunc i64 %v1673 to i32
  %call1675 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v1670, i64 %v1671, i64 %v1672, i32 %cv1674) nomerge, !dbg !132
  store i32 %call1675, ptr %slot280, align 8
  %v1676 = load i32, ptr %slot280, align 8
  %cv1677 = zext i32 %v1676 to i64
  %cond1678 = icmp ne i64 %cv1677, 0
  br i1 %cond1678, label %bb_rcsuccess522, label %bb_rcfailure522
bb_rcfailure522:
  %v1679 = load i64, ptr %slot35, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  %call1681 = call i32 @myl_rc_take_failure(ptr %p1680) nomerge, !dbg !132
  store i32 %call1681, ptr %slot281, align 8
  %v1682 = load i64, ptr %slot1, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  %v1684 = load i32, ptr %slot281, align 8
  %call1685 = call i32 @myl_qbe_rc_status(ptr %p1683, i32 %v1684) nomerge, !dbg !132
  store i32 %call1685, ptr %slot282, align 8
  br label %bb_failure
bb_rcsuccess522:
  %v1686 = load i64, ptr %slot6, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  store i32 0, ptr %p1687, align 4, !alias.scope !3, !noalias !4
  %v1688 = load i64, ptr %slot9, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  store i32 2, ptr %p1689, align 4, !alias.scope !3, !noalias !4
  %v1690 = load i64, ptr %slot8, align 8
  %p1691 = inttoptr i64 %v1690 to ptr
  store i32 1, ptr %p1691, align 4, !alias.scope !3, !noalias !4
  %v1692 = load i64, ptr %slot12, align 8
  store i64 %v1692, ptr %slot283, align 8
  %v1693 = load i64, ptr %slot8, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i32 0, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  %v1695 = load i64, ptr %slot6, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  %ld1697 = load i32, ptr %p1696, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1697, ptr %slot284, align 8
  %v1698 = load i32, ptr %slot284, align 8
  %cv1699 = zext i32 %v1698 to i64
  %cond1700 = icmp ne i64 %cv1699, 0
  br i1 %cond1700, label %bb_rcslotdrop532, label %bb_rcslotdone532
bb_rcslotdrop532:
  %v1701 = load i64, ptr %slot6, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  store i32 0, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  %v1703 = load i64, ptr %slot11, align 8
  store i64 %v1703, ptr %slot285, align 8
  %v1704 = load i64, ptr %slot7, align 8
  %p1705 = inttoptr i64 %v1704 to ptr
  %ld1706 = load i32, ptr %p1705, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1706, ptr %slot286, align 8
  %v1707 = load i32, ptr %slot286, align 8
  %op1708 = and i32 %v1707, 28
  store i32 %op1708, ptr %slot287, align 8
  %v1709 = load i32, ptr %slot287, align 8
  %cv1710 = zext i32 %v1709 to i64
  %cond1711 = icmp ne i64 %cv1710, 0
  br i1 %cond1711, label %bb_rcslotrole532, label %bb_rcslotowner532
bb_rcslotrole532:
  %v1712 = load i64, ptr %slot35, align 8
  store i64 %v1712, ptr %slot288, align 8
  %v1713 = load i64, ptr %slot288, align 8
  %v1714 = load i64, ptr %slot285, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v1713, i64 %v1714) nomerge, !dbg !132
  br label %bb_rcslotdone532
bb_rcslotowner532:
  %v1715 = load i64, ptr %slot35, align 8
  store i64 %v1715, ptr %slot289, align 8
  %v1716 = load i64, ptr %slot289, align 8
  %v1717 = load i64, ptr %slot285, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v1716, i64 %v1717) nomerge, !dbg !132
  br label %bb_rcslotdone532
bb_rcslotdone532:
  %v1718 = load i64, ptr %slot283, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1719, i64 32, i1 false)
  ret void
bb_i32:
  %v1720 = load i64, ptr %slot25, align 8
  store i64 %v1720, ptr %slot290, align 8
  %v1721 = load i64, ptr %slot290, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  store i64 0, ptr %p1722, align 8, !alias.scope !3, !noalias !4
  %v1723 = load i64, ptr %slot290, align 8
  %p1725 = inttoptr i64 %v1723 to ptr
  %gep1726 = getelementptr i8, ptr %p1725, i64 8
  %op1724 = ptrtoint ptr %gep1726 to i64
  store i64 %op1724, ptr %slot291, align 8
  %v1727 = load i64, ptr %slot291, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i64 0, ptr %p1728, align 8, !alias.scope !3, !noalias !4
  %v1729 = load i64, ptr %slot290, align 8
  %p1731 = inttoptr i64 %v1729 to ptr
  %gep1732 = getelementptr i8, ptr %p1731, i64 16
  %op1730 = ptrtoint ptr %gep1732 to i64
  store i64 %op1730, ptr %slot292, align 8
  %v1733 = load i64, ptr %slot292, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i64 0, ptr %p1734, align 8, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot290, align 8
  %p1737 = inttoptr i64 %v1735 to ptr
  %gep1738 = getelementptr i8, ptr %p1737, i64 24
  %op1736 = ptrtoint ptr %gep1738 to i64
  store i64 %op1736, ptr %slot293, align 8
  %v1739 = load i64, ptr %slot293, align 8
  %p1740 = inttoptr i64 %v1739 to ptr
  store i64 0, ptr %p1740, align 8, !alias.scope !3, !noalias !4
  %v1741 = load i64, ptr %slot290, align 8
  %p1742 = inttoptr i64 %v1741 to ptr
  store i32 0, ptr %p1742, align 4, !alias.scope !3, !noalias !4
  %v1743 = load i64, ptr %slot290, align 8
  %v1744 = load i64, ptr %slot19, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  store i64 %v1743, ptr %p1745, align 8, !alias.scope !3, !noalias !4
  %v1746 = load i64, ptr %slot19, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %ld1748 = load i64, ptr %p1747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1748, ptr %slot294, align 8
  %v1749 = load i64, ptr %slot11, align 8
  store i64 %v1749, ptr %slot295, align 8
  %v1750 = load i64, ptr %slot294, align 8
  %v1751 = load i64, ptr %slot295, align 8
  %p1752 = inttoptr i64 %v1750 to ptr
  %p1753 = inttoptr i64 %v1751 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1753, ptr %p1752, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot7, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  store i32 2, ptr %p1755, align 4, !alias.scope !3, !noalias !4
  %v1756 = load i64, ptr %slot6, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  store i32 1, ptr %p1757, align 4, !alias.scope !3, !noalias !4
  %v1758 = load i64, ptr %slot295, align 8
  %v1759 = load i64, ptr %slot19, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  store i64 %v1758, ptr %p1760, align 8, !alias.scope !3, !noalias !4
  %v1761 = load i64, ptr %slot19, align 8
  %p1762 = inttoptr i64 %v1761 to ptr
  %ld1763 = load i64, ptr %p1762, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1763, ptr %slot296, align 8
  %v1764 = load i64, ptr %slot19, align 8
  %p1765 = inttoptr i64 %v1764 to ptr
  %ld1766 = load i64, ptr %p1765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1766, ptr %slot297, align 8
  %v1767 = load i64, ptr %slot12, align 8
  store i64 %v1767, ptr %slot298, align 8
  %v1768 = load i64, ptr %slot36, align 8
  store i64 %v1768, ptr %slot299, align 8
  %v1769 = load i64, ptr %slot35, align 8
  %v1770 = load i64, ptr %slot298, align 8
  %v1771 = load i64, ptr %slot297, align 8
  %v1772 = load i64, ptr %slot299, align 8
  %cv1773 = trunc i64 %v1772 to i32
  %call1774 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v1769, i64 %v1770, i64 %v1771, i32 %cv1773) nomerge, !dbg !134
  store i32 %call1774, ptr %slot300, align 8
  %v1775 = load i32, ptr %slot300, align 8
  %cv1776 = zext i32 %v1775 to i64
  %cond1777 = icmp ne i64 %cv1776, 0
  br i1 %cond1777, label %bb_rcsuccess607, label %bb_rcfailure607
bb_rcfailure607:
  %v1778 = load i64, ptr %slot35, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  %call1780 = call i32 @myl_rc_take_failure(ptr %p1779) nomerge, !dbg !134
  store i32 %call1780, ptr %slot301, align 8
  %v1781 = load i64, ptr %slot1, align 8
  %p1782 = inttoptr i64 %v1781 to ptr
  %v1783 = load i32, ptr %slot301, align 8
  %call1784 = call i32 @myl_qbe_rc_status(ptr %p1782, i32 %v1783) nomerge, !dbg !134
  store i32 %call1784, ptr %slot302, align 8
  br label %bb_failure
bb_rcsuccess607:
  %v1785 = load i64, ptr %slot6, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  store i32 0, ptr %p1786, align 4, !alias.scope !3, !noalias !4
  %v1787 = load i64, ptr %slot9, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  store i32 2, ptr %p1788, align 4, !alias.scope !3, !noalias !4
  %v1789 = load i64, ptr %slot8, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  store i32 1, ptr %p1790, align 4, !alias.scope !3, !noalias !4
  %v1791 = load i64, ptr %slot12, align 8
  store i64 %v1791, ptr %slot303, align 8
  %v1792 = load i64, ptr %slot8, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  store i32 0, ptr %p1793, align 4, !alias.scope !3, !noalias !4
  %v1794 = load i64, ptr %slot6, align 8
  %p1795 = inttoptr i64 %v1794 to ptr
  %ld1796 = load i32, ptr %p1795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1796, ptr %slot304, align 8
  %v1797 = load i32, ptr %slot304, align 8
  %cv1798 = zext i32 %v1797 to i64
  %cond1799 = icmp ne i64 %cv1798, 0
  br i1 %cond1799, label %bb_rcslotdrop617, label %bb_rcslotdone617
bb_rcslotdrop617:
  %v1800 = load i64, ptr %slot6, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  store i32 0, ptr %p1801, align 4, !alias.scope !3, !noalias !4
  %v1802 = load i64, ptr %slot11, align 8
  store i64 %v1802, ptr %slot305, align 8
  %v1803 = load i64, ptr %slot7, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %ld1805 = load i32, ptr %p1804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1805, ptr %slot306, align 8
  %v1806 = load i32, ptr %slot306, align 8
  %op1807 = and i32 %v1806, 28
  store i32 %op1807, ptr %slot307, align 8
  %v1808 = load i32, ptr %slot307, align 8
  %cv1809 = zext i32 %v1808 to i64
  %cond1810 = icmp ne i64 %cv1809, 0
  br i1 %cond1810, label %bb_rcslotrole617, label %bb_rcslotowner617
bb_rcslotrole617:
  %v1811 = load i64, ptr %slot35, align 8
  store i64 %v1811, ptr %slot308, align 8
  %v1812 = load i64, ptr %slot308, align 8
  %v1813 = load i64, ptr %slot305, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v1812, i64 %v1813) nomerge, !dbg !134
  br label %bb_rcslotdone617
bb_rcslotowner617:
  %v1814 = load i64, ptr %slot35, align 8
  store i64 %v1814, ptr %slot309, align 8
  %v1815 = load i64, ptr %slot309, align 8
  %v1816 = load i64, ptr %slot305, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v1815, i64 %v1816) nomerge, !dbg !134
  br label %bb_rcslotdone617
bb_rcslotdone617:
  %v1817 = load i64, ptr %slot303, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1818, i64 32, i1 false)
  ret void
bb_i34:
  %v1819 = load i64, ptr %slot26, align 8
  store i64 %v1819, ptr %slot310, align 8
  %v1820 = load i64, ptr %slot310, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i64 0, ptr %p1821, align 8, !alias.scope !3, !noalias !4
  %v1822 = load i64, ptr %slot310, align 8
  %p1824 = inttoptr i64 %v1822 to ptr
  %gep1825 = getelementptr i8, ptr %p1824, i64 8
  %op1823 = ptrtoint ptr %gep1825 to i64
  store i64 %op1823, ptr %slot311, align 8
  %v1826 = load i64, ptr %slot311, align 8
  %p1827 = inttoptr i64 %v1826 to ptr
  store i64 0, ptr %p1827, align 8, !alias.scope !3, !noalias !4
  %v1828 = load i64, ptr %slot310, align 8
  %p1830 = inttoptr i64 %v1828 to ptr
  %gep1831 = getelementptr i8, ptr %p1830, i64 16
  %op1829 = ptrtoint ptr %gep1831 to i64
  store i64 %op1829, ptr %slot312, align 8
  %v1832 = load i64, ptr %slot312, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  store i64 0, ptr %p1833, align 8, !alias.scope !3, !noalias !4
  %v1834 = load i64, ptr %slot310, align 8
  %p1836 = inttoptr i64 %v1834 to ptr
  %gep1837 = getelementptr i8, ptr %p1836, i64 24
  %op1835 = ptrtoint ptr %gep1837 to i64
  store i64 %op1835, ptr %slot313, align 8
  %v1838 = load i64, ptr %slot313, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  store i64 0, ptr %p1839, align 8, !alias.scope !3, !noalias !4
  %v1840 = load i64, ptr %slot310, align 8
  %p1841 = inttoptr i64 %v1840 to ptr
  store i32 0, ptr %p1841, align 4, !alias.scope !3, !noalias !4
  %v1842 = load i64, ptr %slot310, align 8
  %v1843 = load i64, ptr %slot19, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  store i64 %v1842, ptr %p1844, align 8, !alias.scope !3, !noalias !4
  %v1845 = load i64, ptr %slot19, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  %ld1847 = load i64, ptr %p1846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1847, ptr %slot314, align 8
  %v1848 = load i64, ptr %slot11, align 8
  store i64 %v1848, ptr %slot315, align 8
  %v1849 = load i64, ptr %slot314, align 8
  %v1850 = load i64, ptr %slot315, align 8
  %p1851 = inttoptr i64 %v1849 to ptr
  %p1852 = inttoptr i64 %v1850 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1852, ptr %p1851, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1853 = load i64, ptr %slot7, align 8
  %p1854 = inttoptr i64 %v1853 to ptr
  store i32 2, ptr %p1854, align 4, !alias.scope !3, !noalias !4
  %v1855 = load i64, ptr %slot6, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  store i32 1, ptr %p1856, align 4, !alias.scope !3, !noalias !4
  %v1857 = load i64, ptr %slot315, align 8
  %v1858 = load i64, ptr %slot19, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  store i64 %v1857, ptr %p1859, align 8, !alias.scope !3, !noalias !4
  %v1860 = load i64, ptr %slot19, align 8
  %p1861 = inttoptr i64 %v1860 to ptr
  %ld1862 = load i64, ptr %p1861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1862, ptr %slot316, align 8
  %v1863 = load i64, ptr %slot19, align 8
  %p1864 = inttoptr i64 %v1863 to ptr
  %ld1865 = load i64, ptr %p1864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1865, ptr %slot317, align 8
  %v1866 = load i64, ptr %slot12, align 8
  store i64 %v1866, ptr %slot318, align 8
  %v1867 = load i64, ptr %slot36, align 8
  store i64 %v1867, ptr %slot319, align 8
  %v1868 = load i64, ptr %slot35, align 8
  %v1869 = load i64, ptr %slot318, align 8
  %v1870 = load i64, ptr %slot317, align 8
  %v1871 = load i64, ptr %slot319, align 8
  %cv1872 = trunc i64 %v1871 to i32
  %call1873 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v1868, i64 %v1869, i64 %v1870, i32 %cv1872) nomerge, !dbg !136
  store i32 %call1873, ptr %slot320, align 8
  %v1874 = load i32, ptr %slot320, align 8
  %cv1875 = zext i32 %v1874 to i64
  %cond1876 = icmp ne i64 %cv1875, 0
  br i1 %cond1876, label %bb_rcsuccess692, label %bb_rcfailure692
bb_rcfailure692:
  %v1877 = load i64, ptr %slot35, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %call1879 = call i32 @myl_rc_take_failure(ptr %p1878) nomerge, !dbg !136
  store i32 %call1879, ptr %slot321, align 8
  %v1880 = load i64, ptr %slot1, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  %v1882 = load i32, ptr %slot321, align 8
  %call1883 = call i32 @myl_qbe_rc_status(ptr %p1881, i32 %v1882) nomerge, !dbg !136
  store i32 %call1883, ptr %slot322, align 8
  br label %bb_failure
bb_rcsuccess692:
  %v1884 = load i64, ptr %slot6, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i32 0, ptr %p1885, align 4, !alias.scope !3, !noalias !4
  %v1886 = load i64, ptr %slot9, align 8
  %p1887 = inttoptr i64 %v1886 to ptr
  store i32 2, ptr %p1887, align 4, !alias.scope !3, !noalias !4
  %v1888 = load i64, ptr %slot8, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i32 1, ptr %p1889, align 4, !alias.scope !3, !noalias !4
  %v1890 = load i64, ptr %slot12, align 8
  store i64 %v1890, ptr %slot323, align 8
  %v1891 = load i64, ptr %slot8, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  store i32 0, ptr %p1892, align 4, !alias.scope !3, !noalias !4
  %v1893 = load i64, ptr %slot6, align 8
  %p1894 = inttoptr i64 %v1893 to ptr
  %ld1895 = load i32, ptr %p1894, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1895, ptr %slot324, align 8
  %v1896 = load i32, ptr %slot324, align 8
  %cv1897 = zext i32 %v1896 to i64
  %cond1898 = icmp ne i64 %cv1897, 0
  br i1 %cond1898, label %bb_rcslotdrop702, label %bb_rcslotdone702
bb_rcslotdrop702:
  %v1899 = load i64, ptr %slot6, align 8
  %p1900 = inttoptr i64 %v1899 to ptr
  store i32 0, ptr %p1900, align 4, !alias.scope !3, !noalias !4
  %v1901 = load i64, ptr %slot11, align 8
  store i64 %v1901, ptr %slot325, align 8
  %v1902 = load i64, ptr %slot7, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  %ld1904 = load i32, ptr %p1903, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1904, ptr %slot326, align 8
  %v1905 = load i32, ptr %slot326, align 8
  %op1906 = and i32 %v1905, 28
  store i32 %op1906, ptr %slot327, align 8
  %v1907 = load i32, ptr %slot327, align 8
  %cv1908 = zext i32 %v1907 to i64
  %cond1909 = icmp ne i64 %cv1908, 0
  br i1 %cond1909, label %bb_rcslotrole702, label %bb_rcslotowner702
bb_rcslotrole702:
  %v1910 = load i64, ptr %slot35, align 8
  store i64 %v1910, ptr %slot328, align 8
  %v1911 = load i64, ptr %slot328, align 8
  %v1912 = load i64, ptr %slot325, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v1911, i64 %v1912) nomerge, !dbg !136
  br label %bb_rcslotdone702
bb_rcslotowner702:
  %v1913 = load i64, ptr %slot35, align 8
  store i64 %v1913, ptr %slot329, align 8
  %v1914 = load i64, ptr %slot329, align 8
  %v1915 = load i64, ptr %slot325, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v1914, i64 %v1915) nomerge, !dbg !136
  br label %bb_rcslotdone702
bb_rcslotdone702:
  %v1916 = load i64, ptr %slot323, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1917, i64 32, i1 false)
  ret void
bb_i36:
  %v1918 = load i64, ptr %slot27, align 8
  store i64 %v1918, ptr %slot330, align 8
  %v1919 = load i64, ptr %slot330, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  store i64 0, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  %v1921 = load i64, ptr %slot330, align 8
  %p1923 = inttoptr i64 %v1921 to ptr
  %gep1924 = getelementptr i8, ptr %p1923, i64 8
  %op1922 = ptrtoint ptr %gep1924 to i64
  store i64 %op1922, ptr %slot331, align 8
  %v1925 = load i64, ptr %slot331, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  store i64 0, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  %v1927 = load i64, ptr %slot330, align 8
  %p1929 = inttoptr i64 %v1927 to ptr
  %gep1930 = getelementptr i8, ptr %p1929, i64 16
  %op1928 = ptrtoint ptr %gep1930 to i64
  store i64 %op1928, ptr %slot332, align 8
  %v1931 = load i64, ptr %slot332, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  store i64 0, ptr %p1932, align 8, !alias.scope !3, !noalias !4
  %v1933 = load i64, ptr %slot330, align 8
  %p1935 = inttoptr i64 %v1933 to ptr
  %gep1936 = getelementptr i8, ptr %p1935, i64 24
  %op1934 = ptrtoint ptr %gep1936 to i64
  store i64 %op1934, ptr %slot333, align 8
  %v1937 = load i64, ptr %slot333, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  store i64 0, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  %v1939 = load i64, ptr %slot330, align 8
  %p1940 = inttoptr i64 %v1939 to ptr
  store i32 0, ptr %p1940, align 4, !alias.scope !3, !noalias !4
  %v1941 = load i64, ptr %slot330, align 8
  %v1942 = load i64, ptr %slot19, align 8
  %p1943 = inttoptr i64 %v1942 to ptr
  store i64 %v1941, ptr %p1943, align 8, !alias.scope !3, !noalias !4
  %v1944 = load i64, ptr %slot19, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  %ld1946 = load i64, ptr %p1945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1946, ptr %slot334, align 8
  %v1947 = load i64, ptr %slot11, align 8
  store i64 %v1947, ptr %slot335, align 8
  %v1948 = load i64, ptr %slot334, align 8
  %v1949 = load i64, ptr %slot335, align 8
  %p1950 = inttoptr i64 %v1948 to ptr
  %p1951 = inttoptr i64 %v1949 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1951, ptr %p1950, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v1952 = load i64, ptr %slot7, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  store i32 2, ptr %p1953, align 4, !alias.scope !3, !noalias !4
  %v1954 = load i64, ptr %slot6, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  store i32 1, ptr %p1955, align 4, !alias.scope !3, !noalias !4
  %v1956 = load i64, ptr %slot335, align 8
  %v1957 = load i64, ptr %slot19, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  store i64 %v1956, ptr %p1958, align 8, !alias.scope !3, !noalias !4
  %v1959 = load i64, ptr %slot19, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  %ld1961 = load i64, ptr %p1960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1961, ptr %slot336, align 8
  %v1962 = load i64, ptr %slot19, align 8
  %p1963 = inttoptr i64 %v1962 to ptr
  %ld1964 = load i64, ptr %p1963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1964, ptr %slot337, align 8
  %v1965 = load i64, ptr %slot12, align 8
  store i64 %v1965, ptr %slot338, align 8
  %v1966 = load i64, ptr %slot36, align 8
  store i64 %v1966, ptr %slot339, align 8
  %v1967 = load i64, ptr %slot35, align 8
  %v1968 = load i64, ptr %slot338, align 8
  %v1969 = load i64, ptr %slot337, align 8
  %v1970 = load i64, ptr %slot339, align 8
  %cv1971 = trunc i64 %v1970 to i32
  %call1972 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v1967, i64 %v1968, i64 %v1969, i32 %cv1971) nomerge, !dbg !138
  store i32 %call1972, ptr %slot340, align 8
  %v1973 = load i32, ptr %slot340, align 8
  %cv1974 = zext i32 %v1973 to i64
  %cond1975 = icmp ne i64 %cv1974, 0
  br i1 %cond1975, label %bb_rcsuccess777, label %bb_rcfailure777
bb_rcfailure777:
  %v1976 = load i64, ptr %slot35, align 8
  %p1977 = inttoptr i64 %v1976 to ptr
  %call1978 = call i32 @myl_rc_take_failure(ptr %p1977) nomerge, !dbg !138
  store i32 %call1978, ptr %slot341, align 8
  %v1979 = load i64, ptr %slot1, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  %v1981 = load i32, ptr %slot341, align 8
  %call1982 = call i32 @myl_qbe_rc_status(ptr %p1980, i32 %v1981) nomerge, !dbg !138
  store i32 %call1982, ptr %slot342, align 8
  br label %bb_failure
bb_rcsuccess777:
  %v1983 = load i64, ptr %slot6, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  store i32 0, ptr %p1984, align 4, !alias.scope !3, !noalias !4
  %v1985 = load i64, ptr %slot9, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  store i32 2, ptr %p1986, align 4, !alias.scope !3, !noalias !4
  %v1987 = load i64, ptr %slot8, align 8
  %p1988 = inttoptr i64 %v1987 to ptr
  store i32 1, ptr %p1988, align 4, !alias.scope !3, !noalias !4
  %v1989 = load i64, ptr %slot12, align 8
  store i64 %v1989, ptr %slot343, align 8
  %v1990 = load i64, ptr %slot8, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  store i32 0, ptr %p1991, align 4, !alias.scope !3, !noalias !4
  %v1992 = load i64, ptr %slot6, align 8
  %p1993 = inttoptr i64 %v1992 to ptr
  %ld1994 = load i32, ptr %p1993, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1994, ptr %slot344, align 8
  %v1995 = load i32, ptr %slot344, align 8
  %cv1996 = zext i32 %v1995 to i64
  %cond1997 = icmp ne i64 %cv1996, 0
  br i1 %cond1997, label %bb_rcslotdrop787, label %bb_rcslotdone787
bb_rcslotdrop787:
  %v1998 = load i64, ptr %slot6, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  store i32 0, ptr %p1999, align 4, !alias.scope !3, !noalias !4
  %v2000 = load i64, ptr %slot11, align 8
  store i64 %v2000, ptr %slot345, align 8
  %v2001 = load i64, ptr %slot7, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  %ld2003 = load i32, ptr %p2002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2003, ptr %slot346, align 8
  %v2004 = load i32, ptr %slot346, align 8
  %op2005 = and i32 %v2004, 28
  store i32 %op2005, ptr %slot347, align 8
  %v2006 = load i32, ptr %slot347, align 8
  %cv2007 = zext i32 %v2006 to i64
  %cond2008 = icmp ne i64 %cv2007, 0
  br i1 %cond2008, label %bb_rcslotrole787, label %bb_rcslotowner787
bb_rcslotrole787:
  %v2009 = load i64, ptr %slot35, align 8
  store i64 %v2009, ptr %slot348, align 8
  %v2010 = load i64, ptr %slot348, align 8
  %v2011 = load i64, ptr %slot345, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2010, i64 %v2011) nomerge, !dbg !138
  br label %bb_rcslotdone787
bb_rcslotowner787:
  %v2012 = load i64, ptr %slot35, align 8
  store i64 %v2012, ptr %slot349, align 8
  %v2013 = load i64, ptr %slot349, align 8
  %v2014 = load i64, ptr %slot345, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2013, i64 %v2014) nomerge, !dbg !138
  br label %bb_rcslotdone787
bb_rcslotdone787:
  %v2015 = load i64, ptr %slot343, align 8
  %p2016 = inttoptr i64 %v2015 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2016, i64 32, i1 false)
  ret void
bb_i38:
  %v2017 = load i64, ptr %slot28, align 8
  store i64 %v2017, ptr %slot350, align 8
  %v2018 = load i64, ptr %slot350, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i64 0, ptr %p2019, align 8, !alias.scope !3, !noalias !4
  %v2020 = load i64, ptr %slot350, align 8
  %p2022 = inttoptr i64 %v2020 to ptr
  %gep2023 = getelementptr i8, ptr %p2022, i64 8
  %op2021 = ptrtoint ptr %gep2023 to i64
  store i64 %op2021, ptr %slot351, align 8
  %v2024 = load i64, ptr %slot351, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  store i64 0, ptr %p2025, align 8, !alias.scope !3, !noalias !4
  %v2026 = load i64, ptr %slot350, align 8
  %p2028 = inttoptr i64 %v2026 to ptr
  %gep2029 = getelementptr i8, ptr %p2028, i64 16
  %op2027 = ptrtoint ptr %gep2029 to i64
  store i64 %op2027, ptr %slot352, align 8
  %v2030 = load i64, ptr %slot352, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  store i64 0, ptr %p2031, align 8, !alias.scope !3, !noalias !4
  %v2032 = load i64, ptr %slot350, align 8
  %p2034 = inttoptr i64 %v2032 to ptr
  %gep2035 = getelementptr i8, ptr %p2034, i64 24
  %op2033 = ptrtoint ptr %gep2035 to i64
  store i64 %op2033, ptr %slot353, align 8
  %v2036 = load i64, ptr %slot353, align 8
  %p2037 = inttoptr i64 %v2036 to ptr
  store i64 0, ptr %p2037, align 8, !alias.scope !3, !noalias !4
  %v2038 = load i64, ptr %slot350, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  store i32 0, ptr %p2039, align 4, !alias.scope !3, !noalias !4
  %v2040 = load i64, ptr %slot350, align 8
  %v2041 = load i64, ptr %slot19, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  store i64 %v2040, ptr %p2042, align 8, !alias.scope !3, !noalias !4
  %v2043 = load i64, ptr %slot19, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %ld2045 = load i64, ptr %p2044, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2045, ptr %slot354, align 8
  %v2046 = load i64, ptr %slot11, align 8
  store i64 %v2046, ptr %slot355, align 8
  %v2047 = load i64, ptr %slot354, align 8
  %v2048 = load i64, ptr %slot355, align 8
  %p2049 = inttoptr i64 %v2047 to ptr
  %p2050 = inttoptr i64 %v2048 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2050, ptr %p2049, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2051 = load i64, ptr %slot7, align 8
  %p2052 = inttoptr i64 %v2051 to ptr
  store i32 2, ptr %p2052, align 4, !alias.scope !3, !noalias !4
  %v2053 = load i64, ptr %slot6, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  store i32 1, ptr %p2054, align 4, !alias.scope !3, !noalias !4
  %v2055 = load i64, ptr %slot355, align 8
  %v2056 = load i64, ptr %slot19, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  store i64 %v2055, ptr %p2057, align 8, !alias.scope !3, !noalias !4
  %v2058 = load i64, ptr %slot19, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  %ld2060 = load i64, ptr %p2059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2060, ptr %slot356, align 8
  %v2061 = load i64, ptr %slot19, align 8
  %p2062 = inttoptr i64 %v2061 to ptr
  %ld2063 = load i64, ptr %p2062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2063, ptr %slot357, align 8
  %v2064 = load i64, ptr %slot12, align 8
  store i64 %v2064, ptr %slot358, align 8
  %v2065 = load i64, ptr %slot36, align 8
  store i64 %v2065, ptr %slot359, align 8
  %v2066 = load i64, ptr %slot35, align 8
  %v2067 = load i64, ptr %slot358, align 8
  %v2068 = load i64, ptr %slot357, align 8
  %v2069 = load i64, ptr %slot359, align 8
  %cv2070 = trunc i64 %v2069 to i32
  %call2071 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v2066, i64 %v2067, i64 %v2068, i32 %cv2070) nomerge, !dbg !140
  store i32 %call2071, ptr %slot360, align 8
  %v2072 = load i32, ptr %slot360, align 8
  %cv2073 = zext i32 %v2072 to i64
  %cond2074 = icmp ne i64 %cv2073, 0
  br i1 %cond2074, label %bb_rcsuccess862, label %bb_rcfailure862
bb_rcfailure862:
  %v2075 = load i64, ptr %slot35, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %call2077 = call i32 @myl_rc_take_failure(ptr %p2076) nomerge, !dbg !140
  store i32 %call2077, ptr %slot361, align 8
  %v2078 = load i64, ptr %slot1, align 8
  %p2079 = inttoptr i64 %v2078 to ptr
  %v2080 = load i32, ptr %slot361, align 8
  %call2081 = call i32 @myl_qbe_rc_status(ptr %p2079, i32 %v2080) nomerge, !dbg !140
  store i32 %call2081, ptr %slot362, align 8
  br label %bb_failure
bb_rcsuccess862:
  %v2082 = load i64, ptr %slot6, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  store i32 0, ptr %p2083, align 4, !alias.scope !3, !noalias !4
  %v2084 = load i64, ptr %slot9, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  store i32 2, ptr %p2085, align 4, !alias.scope !3, !noalias !4
  %v2086 = load i64, ptr %slot8, align 8
  %p2087 = inttoptr i64 %v2086 to ptr
  store i32 1, ptr %p2087, align 4, !alias.scope !3, !noalias !4
  %v2088 = load i64, ptr %slot12, align 8
  store i64 %v2088, ptr %slot363, align 8
  %v2089 = load i64, ptr %slot8, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  store i32 0, ptr %p2090, align 4, !alias.scope !3, !noalias !4
  %v2091 = load i64, ptr %slot6, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  %ld2093 = load i32, ptr %p2092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2093, ptr %slot364, align 8
  %v2094 = load i32, ptr %slot364, align 8
  %cv2095 = zext i32 %v2094 to i64
  %cond2096 = icmp ne i64 %cv2095, 0
  br i1 %cond2096, label %bb_rcslotdrop872, label %bb_rcslotdone872
bb_rcslotdrop872:
  %v2097 = load i64, ptr %slot6, align 8
  %p2098 = inttoptr i64 %v2097 to ptr
  store i32 0, ptr %p2098, align 4, !alias.scope !3, !noalias !4
  %v2099 = load i64, ptr %slot11, align 8
  store i64 %v2099, ptr %slot365, align 8
  %v2100 = load i64, ptr %slot7, align 8
  %p2101 = inttoptr i64 %v2100 to ptr
  %ld2102 = load i32, ptr %p2101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2102, ptr %slot366, align 8
  %v2103 = load i32, ptr %slot366, align 8
  %op2104 = and i32 %v2103, 28
  store i32 %op2104, ptr %slot367, align 8
  %v2105 = load i32, ptr %slot367, align 8
  %cv2106 = zext i32 %v2105 to i64
  %cond2107 = icmp ne i64 %cv2106, 0
  br i1 %cond2107, label %bb_rcslotrole872, label %bb_rcslotowner872
bb_rcslotrole872:
  %v2108 = load i64, ptr %slot35, align 8
  store i64 %v2108, ptr %slot368, align 8
  %v2109 = load i64, ptr %slot368, align 8
  %v2110 = load i64, ptr %slot365, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2109, i64 %v2110) nomerge, !dbg !140
  br label %bb_rcslotdone872
bb_rcslotowner872:
  %v2111 = load i64, ptr %slot35, align 8
  store i64 %v2111, ptr %slot369, align 8
  %v2112 = load i64, ptr %slot369, align 8
  %v2113 = load i64, ptr %slot365, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2112, i64 %v2113) nomerge, !dbg !140
  br label %bb_rcslotdone872
bb_rcslotdone872:
  %v2114 = load i64, ptr %slot363, align 8
  %p2115 = inttoptr i64 %v2114 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2115, i64 32, i1 false)
  ret void
bb_i40:
  %v2116 = load i64, ptr %slot29, align 8
  store i64 %v2116, ptr %slot370, align 8
  %v2117 = load i64, ptr %slot370, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  store i64 0, ptr %p2118, align 8, !alias.scope !3, !noalias !4
  %v2119 = load i64, ptr %slot370, align 8
  %p2121 = inttoptr i64 %v2119 to ptr
  %gep2122 = getelementptr i8, ptr %p2121, i64 8
  %op2120 = ptrtoint ptr %gep2122 to i64
  store i64 %op2120, ptr %slot371, align 8
  %v2123 = load i64, ptr %slot371, align 8
  %p2124 = inttoptr i64 %v2123 to ptr
  store i64 0, ptr %p2124, align 8, !alias.scope !3, !noalias !4
  %v2125 = load i64, ptr %slot370, align 8
  %p2127 = inttoptr i64 %v2125 to ptr
  %gep2128 = getelementptr i8, ptr %p2127, i64 16
  %op2126 = ptrtoint ptr %gep2128 to i64
  store i64 %op2126, ptr %slot372, align 8
  %v2129 = load i64, ptr %slot372, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  store i64 0, ptr %p2130, align 8, !alias.scope !3, !noalias !4
  %v2131 = load i64, ptr %slot370, align 8
  %p2133 = inttoptr i64 %v2131 to ptr
  %gep2134 = getelementptr i8, ptr %p2133, i64 24
  %op2132 = ptrtoint ptr %gep2134 to i64
  store i64 %op2132, ptr %slot373, align 8
  %v2135 = load i64, ptr %slot373, align 8
  %p2136 = inttoptr i64 %v2135 to ptr
  store i64 0, ptr %p2136, align 8, !alias.scope !3, !noalias !4
  %v2137 = load i64, ptr %slot370, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  store i32 0, ptr %p2138, align 4, !alias.scope !3, !noalias !4
  %v2139 = load i64, ptr %slot370, align 8
  %v2140 = load i64, ptr %slot19, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  store i64 %v2139, ptr %p2141, align 8, !alias.scope !3, !noalias !4
  %v2142 = load i64, ptr %slot19, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  %ld2144 = load i64, ptr %p2143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2144, ptr %slot374, align 8
  %v2145 = load i64, ptr %slot11, align 8
  store i64 %v2145, ptr %slot375, align 8
  %v2146 = load i64, ptr %slot374, align 8
  %v2147 = load i64, ptr %slot375, align 8
  %p2148 = inttoptr i64 %v2146 to ptr
  %p2149 = inttoptr i64 %v2147 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2149, ptr %p2148, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2150 = load i64, ptr %slot7, align 8
  %p2151 = inttoptr i64 %v2150 to ptr
  store i32 2, ptr %p2151, align 4, !alias.scope !3, !noalias !4
  %v2152 = load i64, ptr %slot6, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  store i32 1, ptr %p2153, align 4, !alias.scope !3, !noalias !4
  %v2154 = load i64, ptr %slot375, align 8
  %v2155 = load i64, ptr %slot19, align 8
  %p2156 = inttoptr i64 %v2155 to ptr
  store i64 %v2154, ptr %p2156, align 8, !alias.scope !3, !noalias !4
  %v2157 = load i64, ptr %slot19, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  %ld2159 = load i64, ptr %p2158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2159, ptr %slot376, align 8
  %v2160 = load i64, ptr %slot19, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  %ld2162 = load i64, ptr %p2161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2162, ptr %slot377, align 8
  %v2163 = load i64, ptr %slot12, align 8
  store i64 %v2163, ptr %slot378, align 8
  %v2164 = load i64, ptr %slot36, align 8
  store i64 %v2164, ptr %slot379, align 8
  %v2165 = load i64, ptr %slot35, align 8
  %v2166 = load i64, ptr %slot378, align 8
  %v2167 = load i64, ptr %slot377, align 8
  %v2168 = load i64, ptr %slot379, align 8
  %cv2169 = trunc i64 %v2168 to i32
  %call2170 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v2165, i64 %v2166, i64 %v2167, i32 %cv2169) nomerge, !dbg !142
  store i32 %call2170, ptr %slot380, align 8
  %v2171 = load i32, ptr %slot380, align 8
  %cv2172 = zext i32 %v2171 to i64
  %cond2173 = icmp ne i64 %cv2172, 0
  br i1 %cond2173, label %bb_rcsuccess947, label %bb_rcfailure947
bb_rcfailure947:
  %v2174 = load i64, ptr %slot35, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  %call2176 = call i32 @myl_rc_take_failure(ptr %p2175) nomerge, !dbg !142
  store i32 %call2176, ptr %slot381, align 8
  %v2177 = load i64, ptr %slot1, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  %v2179 = load i32, ptr %slot381, align 8
  %call2180 = call i32 @myl_qbe_rc_status(ptr %p2178, i32 %v2179) nomerge, !dbg !142
  store i32 %call2180, ptr %slot382, align 8
  br label %bb_failure
bb_rcsuccess947:
  %v2181 = load i64, ptr %slot6, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  store i32 0, ptr %p2182, align 4, !alias.scope !3, !noalias !4
  %v2183 = load i64, ptr %slot9, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  store i32 2, ptr %p2184, align 4, !alias.scope !3, !noalias !4
  %v2185 = load i64, ptr %slot8, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  store i32 1, ptr %p2186, align 4, !alias.scope !3, !noalias !4
  %v2187 = load i64, ptr %slot12, align 8
  store i64 %v2187, ptr %slot383, align 8
  %v2188 = load i64, ptr %slot8, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  store i32 0, ptr %p2189, align 4, !alias.scope !3, !noalias !4
  %v2190 = load i64, ptr %slot6, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  %ld2192 = load i32, ptr %p2191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2192, ptr %slot384, align 8
  %v2193 = load i32, ptr %slot384, align 8
  %cv2194 = zext i32 %v2193 to i64
  %cond2195 = icmp ne i64 %cv2194, 0
  br i1 %cond2195, label %bb_rcslotdrop957, label %bb_rcslotdone957
bb_rcslotdrop957:
  %v2196 = load i64, ptr %slot6, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  store i32 0, ptr %p2197, align 4, !alias.scope !3, !noalias !4
  %v2198 = load i64, ptr %slot11, align 8
  store i64 %v2198, ptr %slot385, align 8
  %v2199 = load i64, ptr %slot7, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i32, ptr %p2200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2201, ptr %slot386, align 8
  %v2202 = load i32, ptr %slot386, align 8
  %op2203 = and i32 %v2202, 28
  store i32 %op2203, ptr %slot387, align 8
  %v2204 = load i32, ptr %slot387, align 8
  %cv2205 = zext i32 %v2204 to i64
  %cond2206 = icmp ne i64 %cv2205, 0
  br i1 %cond2206, label %bb_rcslotrole957, label %bb_rcslotowner957
bb_rcslotrole957:
  %v2207 = load i64, ptr %slot35, align 8
  store i64 %v2207, ptr %slot388, align 8
  %v2208 = load i64, ptr %slot388, align 8
  %v2209 = load i64, ptr %slot385, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2208, i64 %v2209) nomerge, !dbg !142
  br label %bb_rcslotdone957
bb_rcslotowner957:
  %v2210 = load i64, ptr %slot35, align 8
  store i64 %v2210, ptr %slot389, align 8
  %v2211 = load i64, ptr %slot389, align 8
  %v2212 = load i64, ptr %slot385, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2211, i64 %v2212) nomerge, !dbg !142
  br label %bb_rcslotdone957
bb_rcslotdone957:
  %v2213 = load i64, ptr %slot383, align 8
  %p2214 = inttoptr i64 %v2213 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2214, i64 32, i1 false)
  ret void
bb_i42:
  %v2215 = load i64, ptr %slot30, align 8
  store i64 %v2215, ptr %slot390, align 8
  %v2216 = load i64, ptr %slot390, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  store i64 0, ptr %p2217, align 8, !alias.scope !3, !noalias !4
  %v2218 = load i64, ptr %slot390, align 8
  %p2220 = inttoptr i64 %v2218 to ptr
  %gep2221 = getelementptr i8, ptr %p2220, i64 8
  %op2219 = ptrtoint ptr %gep2221 to i64
  store i64 %op2219, ptr %slot391, align 8
  %v2222 = load i64, ptr %slot391, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  store i64 0, ptr %p2223, align 8, !alias.scope !3, !noalias !4
  %v2224 = load i64, ptr %slot390, align 8
  %p2226 = inttoptr i64 %v2224 to ptr
  %gep2227 = getelementptr i8, ptr %p2226, i64 16
  %op2225 = ptrtoint ptr %gep2227 to i64
  store i64 %op2225, ptr %slot392, align 8
  %v2228 = load i64, ptr %slot392, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  store i64 0, ptr %p2229, align 8, !alias.scope !3, !noalias !4
  %v2230 = load i64, ptr %slot390, align 8
  %p2232 = inttoptr i64 %v2230 to ptr
  %gep2233 = getelementptr i8, ptr %p2232, i64 24
  %op2231 = ptrtoint ptr %gep2233 to i64
  store i64 %op2231, ptr %slot393, align 8
  %v2234 = load i64, ptr %slot393, align 8
  %p2235 = inttoptr i64 %v2234 to ptr
  store i64 0, ptr %p2235, align 8, !alias.scope !3, !noalias !4
  %v2236 = load i64, ptr %slot390, align 8
  %p2237 = inttoptr i64 %v2236 to ptr
  store i32 0, ptr %p2237, align 4, !alias.scope !3, !noalias !4
  %v2238 = load i64, ptr %slot390, align 8
  %v2239 = load i64, ptr %slot19, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  store i64 %v2238, ptr %p2240, align 8, !alias.scope !3, !noalias !4
  %v2241 = load i64, ptr %slot19, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  %ld2243 = load i64, ptr %p2242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2243, ptr %slot394, align 8
  %v2244 = load i64, ptr %slot11, align 8
  store i64 %v2244, ptr %slot395, align 8
  %v2245 = load i64, ptr %slot394, align 8
  %v2246 = load i64, ptr %slot395, align 8
  %p2247 = inttoptr i64 %v2245 to ptr
  %p2248 = inttoptr i64 %v2246 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2248, ptr %p2247, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2249 = load i64, ptr %slot7, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  store i32 2, ptr %p2250, align 4, !alias.scope !3, !noalias !4
  %v2251 = load i64, ptr %slot6, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i32 1, ptr %p2252, align 4, !alias.scope !3, !noalias !4
  %v2253 = load i64, ptr %slot395, align 8
  %v2254 = load i64, ptr %slot19, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  store i64 %v2253, ptr %p2255, align 8, !alias.scope !3, !noalias !4
  %v2256 = load i64, ptr %slot19, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %ld2258 = load i64, ptr %p2257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2258, ptr %slot396, align 8
  %v2259 = load i64, ptr %slot19, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  %ld2261 = load i64, ptr %p2260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2261, ptr %slot397, align 8
  %v2262 = load i64, ptr %slot12, align 8
  store i64 %v2262, ptr %slot398, align 8
  %v2263 = load i64, ptr %slot36, align 8
  store i64 %v2263, ptr %slot399, align 8
  %v2264 = load i64, ptr %slot35, align 8
  %v2265 = load i64, ptr %slot398, align 8
  %v2266 = load i64, ptr %slot397, align 8
  %v2267 = load i64, ptr %slot399, align 8
  %cv2268 = trunc i64 %v2267 to i32
  %call2269 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v2264, i64 %v2265, i64 %v2266, i32 %cv2268) nomerge, !dbg !144
  store i32 %call2269, ptr %slot400, align 8
  %v2270 = load i32, ptr %slot400, align 8
  %cv2271 = zext i32 %v2270 to i64
  %cond2272 = icmp ne i64 %cv2271, 0
  br i1 %cond2272, label %bb_rcsuccess1032, label %bb_rcfailure1032
bb_rcfailure1032:
  %v2273 = load i64, ptr %slot35, align 8
  %p2274 = inttoptr i64 %v2273 to ptr
  %call2275 = call i32 @myl_rc_take_failure(ptr %p2274) nomerge, !dbg !144
  store i32 %call2275, ptr %slot401, align 8
  %v2276 = load i64, ptr %slot1, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  %v2278 = load i32, ptr %slot401, align 8
  %call2279 = call i32 @myl_qbe_rc_status(ptr %p2277, i32 %v2278) nomerge, !dbg !144
  store i32 %call2279, ptr %slot402, align 8
  br label %bb_failure
bb_rcsuccess1032:
  %v2280 = load i64, ptr %slot6, align 8
  %p2281 = inttoptr i64 %v2280 to ptr
  store i32 0, ptr %p2281, align 4, !alias.scope !3, !noalias !4
  %v2282 = load i64, ptr %slot9, align 8
  %p2283 = inttoptr i64 %v2282 to ptr
  store i32 2, ptr %p2283, align 4, !alias.scope !3, !noalias !4
  %v2284 = load i64, ptr %slot8, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i32 1, ptr %p2285, align 4, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot12, align 8
  store i64 %v2286, ptr %slot403, align 8
  %v2287 = load i64, ptr %slot8, align 8
  %p2288 = inttoptr i64 %v2287 to ptr
  store i32 0, ptr %p2288, align 4, !alias.scope !3, !noalias !4
  %v2289 = load i64, ptr %slot6, align 8
  %p2290 = inttoptr i64 %v2289 to ptr
  %ld2291 = load i32, ptr %p2290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2291, ptr %slot404, align 8
  %v2292 = load i32, ptr %slot404, align 8
  %cv2293 = zext i32 %v2292 to i64
  %cond2294 = icmp ne i64 %cv2293, 0
  br i1 %cond2294, label %bb_rcslotdrop1042, label %bb_rcslotdone1042
bb_rcslotdrop1042:
  %v2295 = load i64, ptr %slot6, align 8
  %p2296 = inttoptr i64 %v2295 to ptr
  store i32 0, ptr %p2296, align 4, !alias.scope !3, !noalias !4
  %v2297 = load i64, ptr %slot11, align 8
  store i64 %v2297, ptr %slot405, align 8
  %v2298 = load i64, ptr %slot7, align 8
  %p2299 = inttoptr i64 %v2298 to ptr
  %ld2300 = load i32, ptr %p2299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2300, ptr %slot406, align 8
  %v2301 = load i32, ptr %slot406, align 8
  %op2302 = and i32 %v2301, 28
  store i32 %op2302, ptr %slot407, align 8
  %v2303 = load i32, ptr %slot407, align 8
  %cv2304 = zext i32 %v2303 to i64
  %cond2305 = icmp ne i64 %cv2304, 0
  br i1 %cond2305, label %bb_rcslotrole1042, label %bb_rcslotowner1042
bb_rcslotrole1042:
  %v2306 = load i64, ptr %slot35, align 8
  store i64 %v2306, ptr %slot408, align 8
  %v2307 = load i64, ptr %slot408, align 8
  %v2308 = load i64, ptr %slot405, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2307, i64 %v2308) nomerge, !dbg !144
  br label %bb_rcslotdone1042
bb_rcslotowner1042:
  %v2309 = load i64, ptr %slot35, align 8
  store i64 %v2309, ptr %slot409, align 8
  %v2310 = load i64, ptr %slot409, align 8
  %v2311 = load i64, ptr %slot405, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2310, i64 %v2311) nomerge, !dbg !144
  br label %bb_rcslotdone1042
bb_rcslotdone1042:
  %v2312 = load i64, ptr %slot403, align 8
  %p2313 = inttoptr i64 %v2312 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2313, i64 32, i1 false)
  ret void
bb_i44:
  %v2314 = load i64, ptr %slot31, align 8
  store i64 %v2314, ptr %slot410, align 8
  %v2315 = load i64, ptr %slot410, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  store i64 0, ptr %p2316, align 8, !alias.scope !3, !noalias !4
  %v2317 = load i64, ptr %slot410, align 8
  %p2319 = inttoptr i64 %v2317 to ptr
  %gep2320 = getelementptr i8, ptr %p2319, i64 8
  %op2318 = ptrtoint ptr %gep2320 to i64
  store i64 %op2318, ptr %slot411, align 8
  %v2321 = load i64, ptr %slot411, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  store i64 0, ptr %p2322, align 8, !alias.scope !3, !noalias !4
  %v2323 = load i64, ptr %slot410, align 8
  %p2325 = inttoptr i64 %v2323 to ptr
  %gep2326 = getelementptr i8, ptr %p2325, i64 16
  %op2324 = ptrtoint ptr %gep2326 to i64
  store i64 %op2324, ptr %slot412, align 8
  %v2327 = load i64, ptr %slot412, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  store i64 0, ptr %p2328, align 8, !alias.scope !3, !noalias !4
  %v2329 = load i64, ptr %slot410, align 8
  %p2331 = inttoptr i64 %v2329 to ptr
  %gep2332 = getelementptr i8, ptr %p2331, i64 24
  %op2330 = ptrtoint ptr %gep2332 to i64
  store i64 %op2330, ptr %slot413, align 8
  %v2333 = load i64, ptr %slot413, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  store i64 0, ptr %p2334, align 8, !alias.scope !3, !noalias !4
  %v2335 = load i64, ptr %slot410, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  store i32 0, ptr %p2336, align 4, !alias.scope !3, !noalias !4
  %v2337 = load i64, ptr %slot410, align 8
  %v2338 = load i64, ptr %slot19, align 8
  %p2339 = inttoptr i64 %v2338 to ptr
  store i64 %v2337, ptr %p2339, align 8, !alias.scope !3, !noalias !4
  %v2340 = load i64, ptr %slot19, align 8
  %p2341 = inttoptr i64 %v2340 to ptr
  %ld2342 = load i64, ptr %p2341, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2342, ptr %slot414, align 8
  %v2343 = load i64, ptr %slot11, align 8
  store i64 %v2343, ptr %slot415, align 8
  %v2344 = load i64, ptr %slot414, align 8
  %v2345 = load i64, ptr %slot415, align 8
  %p2346 = inttoptr i64 %v2344 to ptr
  %p2347 = inttoptr i64 %v2345 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2347, ptr %p2346, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2348 = load i64, ptr %slot7, align 8
  %p2349 = inttoptr i64 %v2348 to ptr
  store i32 2, ptr %p2349, align 4, !alias.scope !3, !noalias !4
  %v2350 = load i64, ptr %slot6, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  store i32 1, ptr %p2351, align 4, !alias.scope !3, !noalias !4
  %v2352 = load i64, ptr %slot415, align 8
  %v2353 = load i64, ptr %slot19, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  store i64 %v2352, ptr %p2354, align 8, !alias.scope !3, !noalias !4
  %v2355 = load i64, ptr %slot19, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  %ld2357 = load i64, ptr %p2356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2357, ptr %slot416, align 8
  %v2358 = load i64, ptr %slot19, align 8
  %p2359 = inttoptr i64 %v2358 to ptr
  %ld2360 = load i64, ptr %p2359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2360, ptr %slot417, align 8
  %v2361 = load i64, ptr %slot12, align 8
  store i64 %v2361, ptr %slot418, align 8
  %v2362 = load i64, ptr %slot36, align 8
  store i64 %v2362, ptr %slot419, align 8
  %v2363 = load i64, ptr %slot35, align 8
  %v2364 = load i64, ptr %slot418, align 8
  %v2365 = load i64, ptr %slot417, align 8
  %v2366 = load i64, ptr %slot419, align 8
  %cv2367 = trunc i64 %v2366 to i32
  %call2368 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v2363, i64 %v2364, i64 %v2365, i32 %cv2367) nomerge, !dbg !146
  store i32 %call2368, ptr %slot420, align 8
  %v2369 = load i32, ptr %slot420, align 8
  %cv2370 = zext i32 %v2369 to i64
  %cond2371 = icmp ne i64 %cv2370, 0
  br i1 %cond2371, label %bb_rcsuccess1117, label %bb_rcfailure1117
bb_rcfailure1117:
  %v2372 = load i64, ptr %slot35, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  %call2374 = call i32 @myl_rc_take_failure(ptr %p2373) nomerge, !dbg !146
  store i32 %call2374, ptr %slot421, align 8
  %v2375 = load i64, ptr %slot1, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  %v2377 = load i32, ptr %slot421, align 8
  %call2378 = call i32 @myl_qbe_rc_status(ptr %p2376, i32 %v2377) nomerge, !dbg !146
  store i32 %call2378, ptr %slot422, align 8
  br label %bb_failure
bb_rcsuccess1117:
  %v2379 = load i64, ptr %slot6, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  store i32 0, ptr %p2380, align 4, !alias.scope !3, !noalias !4
  %v2381 = load i64, ptr %slot9, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  store i32 2, ptr %p2382, align 4, !alias.scope !3, !noalias !4
  %v2383 = load i64, ptr %slot8, align 8
  %p2384 = inttoptr i64 %v2383 to ptr
  store i32 1, ptr %p2384, align 4, !alias.scope !3, !noalias !4
  %v2385 = load i64, ptr %slot12, align 8
  store i64 %v2385, ptr %slot423, align 8
  %v2386 = load i64, ptr %slot8, align 8
  %p2387 = inttoptr i64 %v2386 to ptr
  store i32 0, ptr %p2387, align 4, !alias.scope !3, !noalias !4
  %v2388 = load i64, ptr %slot6, align 8
  %p2389 = inttoptr i64 %v2388 to ptr
  %ld2390 = load i32, ptr %p2389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2390, ptr %slot424, align 8
  %v2391 = load i32, ptr %slot424, align 8
  %cv2392 = zext i32 %v2391 to i64
  %cond2393 = icmp ne i64 %cv2392, 0
  br i1 %cond2393, label %bb_rcslotdrop1127, label %bb_rcslotdone1127
bb_rcslotdrop1127:
  %v2394 = load i64, ptr %slot6, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  store i32 0, ptr %p2395, align 4, !alias.scope !3, !noalias !4
  %v2396 = load i64, ptr %slot11, align 8
  store i64 %v2396, ptr %slot425, align 8
  %v2397 = load i64, ptr %slot7, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  %ld2399 = load i32, ptr %p2398, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2399, ptr %slot426, align 8
  %v2400 = load i32, ptr %slot426, align 8
  %op2401 = and i32 %v2400, 28
  store i32 %op2401, ptr %slot427, align 8
  %v2402 = load i32, ptr %slot427, align 8
  %cv2403 = zext i32 %v2402 to i64
  %cond2404 = icmp ne i64 %cv2403, 0
  br i1 %cond2404, label %bb_rcslotrole1127, label %bb_rcslotowner1127
bb_rcslotrole1127:
  %v2405 = load i64, ptr %slot35, align 8
  store i64 %v2405, ptr %slot428, align 8
  %v2406 = load i64, ptr %slot428, align 8
  %v2407 = load i64, ptr %slot425, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2406, i64 %v2407) nomerge, !dbg !146
  br label %bb_rcslotdone1127
bb_rcslotowner1127:
  %v2408 = load i64, ptr %slot35, align 8
  store i64 %v2408, ptr %slot429, align 8
  %v2409 = load i64, ptr %slot429, align 8
  %v2410 = load i64, ptr %slot425, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2409, i64 %v2410) nomerge, !dbg !146
  br label %bb_rcslotdone1127
bb_rcslotdone1127:
  %v2411 = load i64, ptr %slot423, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2412, i64 32, i1 false)
  ret void
bb_i46:
  %v2413 = load i64, ptr %slot32, align 8
  store i64 %v2413, ptr %slot430, align 8
  %v2414 = load i64, ptr %slot430, align 8
  %p2415 = inttoptr i64 %v2414 to ptr
  store i64 0, ptr %p2415, align 8, !alias.scope !3, !noalias !4
  %v2416 = load i64, ptr %slot430, align 8
  %p2418 = inttoptr i64 %v2416 to ptr
  %gep2419 = getelementptr i8, ptr %p2418, i64 8
  %op2417 = ptrtoint ptr %gep2419 to i64
  store i64 %op2417, ptr %slot431, align 8
  %v2420 = load i64, ptr %slot431, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  store i64 0, ptr %p2421, align 8, !alias.scope !3, !noalias !4
  %v2422 = load i64, ptr %slot430, align 8
  %p2424 = inttoptr i64 %v2422 to ptr
  %gep2425 = getelementptr i8, ptr %p2424, i64 16
  %op2423 = ptrtoint ptr %gep2425 to i64
  store i64 %op2423, ptr %slot432, align 8
  %v2426 = load i64, ptr %slot432, align 8
  %p2427 = inttoptr i64 %v2426 to ptr
  store i64 0, ptr %p2427, align 8, !alias.scope !3, !noalias !4
  %v2428 = load i64, ptr %slot430, align 8
  %p2430 = inttoptr i64 %v2428 to ptr
  %gep2431 = getelementptr i8, ptr %p2430, i64 24
  %op2429 = ptrtoint ptr %gep2431 to i64
  store i64 %op2429, ptr %slot433, align 8
  %v2432 = load i64, ptr %slot433, align 8
  %p2433 = inttoptr i64 %v2432 to ptr
  store i64 0, ptr %p2433, align 8, !alias.scope !3, !noalias !4
  %v2434 = load i64, ptr %slot430, align 8
  %p2435 = inttoptr i64 %v2434 to ptr
  store i32 0, ptr %p2435, align 4, !alias.scope !3, !noalias !4
  %v2436 = load i64, ptr %slot430, align 8
  %v2437 = load i64, ptr %slot19, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  store i64 %v2436, ptr %p2438, align 8, !alias.scope !3, !noalias !4
  %v2439 = load i64, ptr %slot19, align 8
  %p2440 = inttoptr i64 %v2439 to ptr
  %ld2441 = load i64, ptr %p2440, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2441, ptr %slot434, align 8
  %v2442 = load i64, ptr %slot11, align 8
  store i64 %v2442, ptr %slot435, align 8
  %v2443 = load i64, ptr %slot434, align 8
  %v2444 = load i64, ptr %slot435, align 8
  %p2445 = inttoptr i64 %v2443 to ptr
  %p2446 = inttoptr i64 %v2444 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2446, ptr %p2445, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2447 = load i64, ptr %slot7, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  store i32 2, ptr %p2448, align 4, !alias.scope !3, !noalias !4
  %v2449 = load i64, ptr %slot6, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  store i32 1, ptr %p2450, align 4, !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot435, align 8
  %v2452 = load i64, ptr %slot19, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  store i64 %v2451, ptr %p2453, align 8, !alias.scope !3, !noalias !4
  %v2454 = load i64, ptr %slot19, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %ld2456 = load i64, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2456, ptr %slot436, align 8
  %v2457 = load i64, ptr %slot19, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  %ld2459 = load i64, ptr %p2458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2459, ptr %slot437, align 8
  %v2460 = load i64, ptr %slot12, align 8
  store i64 %v2460, ptr %slot438, align 8
  %v2461 = load i64, ptr %slot36, align 8
  store i64 %v2461, ptr %slot439, align 8
  %v2462 = load i64, ptr %slot35, align 8
  %v2463 = load i64, ptr %slot438, align 8
  %v2464 = load i64, ptr %slot437, align 8
  %v2465 = load i64, ptr %slot439, align 8
  %cv2466 = trunc i64 %v2465 to i32
  %call2467 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v2462, i64 %v2463, i64 %v2464, i32 %cv2466) nomerge, !dbg !148
  store i32 %call2467, ptr %slot440, align 8
  %v2468 = load i32, ptr %slot440, align 8
  %cv2469 = zext i32 %v2468 to i64
  %cond2470 = icmp ne i64 %cv2469, 0
  br i1 %cond2470, label %bb_rcsuccess1202, label %bb_rcfailure1202
bb_rcfailure1202:
  %v2471 = load i64, ptr %slot35, align 8
  %p2472 = inttoptr i64 %v2471 to ptr
  %call2473 = call i32 @myl_rc_take_failure(ptr %p2472) nomerge, !dbg !148
  store i32 %call2473, ptr %slot441, align 8
  %v2474 = load i64, ptr %slot1, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  %v2476 = load i32, ptr %slot441, align 8
  %call2477 = call i32 @myl_qbe_rc_status(ptr %p2475, i32 %v2476) nomerge, !dbg !148
  store i32 %call2477, ptr %slot442, align 8
  br label %bb_failure
bb_rcsuccess1202:
  %v2478 = load i64, ptr %slot6, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  store i32 0, ptr %p2479, align 4, !alias.scope !3, !noalias !4
  %v2480 = load i64, ptr %slot9, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  store i32 2, ptr %p2481, align 4, !alias.scope !3, !noalias !4
  %v2482 = load i64, ptr %slot8, align 8
  %p2483 = inttoptr i64 %v2482 to ptr
  store i32 1, ptr %p2483, align 4, !alias.scope !3, !noalias !4
  %v2484 = load i64, ptr %slot12, align 8
  store i64 %v2484, ptr %slot443, align 8
  %v2485 = load i64, ptr %slot8, align 8
  %p2486 = inttoptr i64 %v2485 to ptr
  store i32 0, ptr %p2486, align 4, !alias.scope !3, !noalias !4
  %v2487 = load i64, ptr %slot6, align 8
  %p2488 = inttoptr i64 %v2487 to ptr
  %ld2489 = load i32, ptr %p2488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2489, ptr %slot444, align 8
  %v2490 = load i32, ptr %slot444, align 8
  %cv2491 = zext i32 %v2490 to i64
  %cond2492 = icmp ne i64 %cv2491, 0
  br i1 %cond2492, label %bb_rcslotdrop1212, label %bb_rcslotdone1212
bb_rcslotdrop1212:
  %v2493 = load i64, ptr %slot6, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  store i32 0, ptr %p2494, align 4, !alias.scope !3, !noalias !4
  %v2495 = load i64, ptr %slot11, align 8
  store i64 %v2495, ptr %slot445, align 8
  %v2496 = load i64, ptr %slot7, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  %ld2498 = load i32, ptr %p2497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2498, ptr %slot446, align 8
  %v2499 = load i32, ptr %slot446, align 8
  %op2500 = and i32 %v2499, 28
  store i32 %op2500, ptr %slot447, align 8
  %v2501 = load i32, ptr %slot447, align 8
  %cv2502 = zext i32 %v2501 to i64
  %cond2503 = icmp ne i64 %cv2502, 0
  br i1 %cond2503, label %bb_rcslotrole1212, label %bb_rcslotowner1212
bb_rcslotrole1212:
  %v2504 = load i64, ptr %slot35, align 8
  store i64 %v2504, ptr %slot448, align 8
  %v2505 = load i64, ptr %slot448, align 8
  %v2506 = load i64, ptr %slot445, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2505, i64 %v2506) nomerge, !dbg !148
  br label %bb_rcslotdone1212
bb_rcslotowner1212:
  %v2507 = load i64, ptr %slot35, align 8
  store i64 %v2507, ptr %slot449, align 8
  %v2508 = load i64, ptr %slot449, align 8
  %v2509 = load i64, ptr %slot445, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2508, i64 %v2509) nomerge, !dbg !148
  br label %bb_rcslotdone1212
bb_rcslotdone1212:
  %v2510 = load i64, ptr %slot443, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2511, i64 32, i1 false)
  ret void
bb_i48:
  %v2512 = load i64, ptr %slot33, align 8
  store i64 %v2512, ptr %slot450, align 8
  %v2513 = load i64, ptr %slot450, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  store i64 0, ptr %p2514, align 8, !alias.scope !3, !noalias !4
  %v2515 = load i64, ptr %slot450, align 8
  %p2517 = inttoptr i64 %v2515 to ptr
  %gep2518 = getelementptr i8, ptr %p2517, i64 8
  %op2516 = ptrtoint ptr %gep2518 to i64
  store i64 %op2516, ptr %slot451, align 8
  %v2519 = load i64, ptr %slot451, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  store i64 0, ptr %p2520, align 8, !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot450, align 8
  %p2523 = inttoptr i64 %v2521 to ptr
  %gep2524 = getelementptr i8, ptr %p2523, i64 16
  %op2522 = ptrtoint ptr %gep2524 to i64
  store i64 %op2522, ptr %slot452, align 8
  %v2525 = load i64, ptr %slot452, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  store i64 0, ptr %p2526, align 8, !alias.scope !3, !noalias !4
  %v2527 = load i64, ptr %slot450, align 8
  %p2529 = inttoptr i64 %v2527 to ptr
  %gep2530 = getelementptr i8, ptr %p2529, i64 24
  %op2528 = ptrtoint ptr %gep2530 to i64
  store i64 %op2528, ptr %slot453, align 8
  %v2531 = load i64, ptr %slot453, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  store i64 0, ptr %p2532, align 8, !alias.scope !3, !noalias !4
  %v2533 = load i64, ptr %slot450, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  store i32 0, ptr %p2534, align 4, !alias.scope !3, !noalias !4
  %v2535 = load i64, ptr %slot450, align 8
  %v2536 = load i64, ptr %slot19, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  store i64 %v2535, ptr %p2537, align 8, !alias.scope !3, !noalias !4
  %v2538 = load i64, ptr %slot19, align 8
  %p2539 = inttoptr i64 %v2538 to ptr
  %ld2540 = load i64, ptr %p2539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2540, ptr %slot454, align 8
  %v2541 = load i64, ptr %slot11, align 8
  store i64 %v2541, ptr %slot455, align 8
  %v2542 = load i64, ptr %slot454, align 8
  %v2543 = load i64, ptr %slot455, align 8
  %p2544 = inttoptr i64 %v2542 to ptr
  %p2545 = inttoptr i64 %v2543 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2545, ptr %p2544, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2546 = load i64, ptr %slot7, align 8
  %p2547 = inttoptr i64 %v2546 to ptr
  store i32 2, ptr %p2547, align 4, !alias.scope !3, !noalias !4
  %v2548 = load i64, ptr %slot6, align 8
  %p2549 = inttoptr i64 %v2548 to ptr
  store i32 1, ptr %p2549, align 4, !alias.scope !3, !noalias !4
  %v2550 = load i64, ptr %slot455, align 8
  %v2551 = load i64, ptr %slot19, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  store i64 %v2550, ptr %p2552, align 8, !alias.scope !3, !noalias !4
  %v2553 = load i64, ptr %slot19, align 8
  %p2554 = inttoptr i64 %v2553 to ptr
  %ld2555 = load i64, ptr %p2554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2555, ptr %slot456, align 8
  %v2556 = load i64, ptr %slot19, align 8
  %p2557 = inttoptr i64 %v2556 to ptr
  %ld2558 = load i64, ptr %p2557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2558, ptr %slot457, align 8
  %v2559 = load i64, ptr %slot12, align 8
  store i64 %v2559, ptr %slot458, align 8
  %v2560 = load i64, ptr %slot36, align 8
  store i64 %v2560, ptr %slot459, align 8
  %v2561 = load i64, ptr %slot35, align 8
  %v2562 = load i64, ptr %slot458, align 8
  %v2563 = load i64, ptr %slot457, align 8
  %v2564 = load i64, ptr %slot459, align 8
  %cv2565 = trunc i64 %v2564 to i32
  %call2566 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v2561, i64 %v2562, i64 %v2563, i32 %cv2565) nomerge, !dbg !150
  store i32 %call2566, ptr %slot460, align 8
  %v2567 = load i32, ptr %slot460, align 8
  %cv2568 = zext i32 %v2567 to i64
  %cond2569 = icmp ne i64 %cv2568, 0
  br i1 %cond2569, label %bb_rcsuccess1287, label %bb_rcfailure1287
bb_rcfailure1287:
  %v2570 = load i64, ptr %slot35, align 8
  %p2571 = inttoptr i64 %v2570 to ptr
  %call2572 = call i32 @myl_rc_take_failure(ptr %p2571) nomerge, !dbg !150
  store i32 %call2572, ptr %slot461, align 8
  %v2573 = load i64, ptr %slot1, align 8
  %p2574 = inttoptr i64 %v2573 to ptr
  %v2575 = load i32, ptr %slot461, align 8
  %call2576 = call i32 @myl_qbe_rc_status(ptr %p2574, i32 %v2575) nomerge, !dbg !150
  store i32 %call2576, ptr %slot462, align 8
  br label %bb_failure
bb_rcsuccess1287:
  %v2577 = load i64, ptr %slot6, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  store i32 0, ptr %p2578, align 4, !alias.scope !3, !noalias !4
  %v2579 = load i64, ptr %slot9, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  store i32 2, ptr %p2580, align 4, !alias.scope !3, !noalias !4
  %v2581 = load i64, ptr %slot8, align 8
  %p2582 = inttoptr i64 %v2581 to ptr
  store i32 1, ptr %p2582, align 4, !alias.scope !3, !noalias !4
  %v2583 = load i64, ptr %slot12, align 8
  store i64 %v2583, ptr %slot463, align 8
  %v2584 = load i64, ptr %slot8, align 8
  %p2585 = inttoptr i64 %v2584 to ptr
  store i32 0, ptr %p2585, align 4, !alias.scope !3, !noalias !4
  %v2586 = load i64, ptr %slot6, align 8
  %p2587 = inttoptr i64 %v2586 to ptr
  %ld2588 = load i32, ptr %p2587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2588, ptr %slot464, align 8
  %v2589 = load i32, ptr %slot464, align 8
  %cv2590 = zext i32 %v2589 to i64
  %cond2591 = icmp ne i64 %cv2590, 0
  br i1 %cond2591, label %bb_rcslotdrop1297, label %bb_rcslotdone1297
bb_rcslotdrop1297:
  %v2592 = load i64, ptr %slot6, align 8
  %p2593 = inttoptr i64 %v2592 to ptr
  store i32 0, ptr %p2593, align 4, !alias.scope !3, !noalias !4
  %v2594 = load i64, ptr %slot11, align 8
  store i64 %v2594, ptr %slot465, align 8
  %v2595 = load i64, ptr %slot7, align 8
  %p2596 = inttoptr i64 %v2595 to ptr
  %ld2597 = load i32, ptr %p2596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2597, ptr %slot466, align 8
  %v2598 = load i32, ptr %slot466, align 8
  %op2599 = and i32 %v2598, 28
  store i32 %op2599, ptr %slot467, align 8
  %v2600 = load i32, ptr %slot467, align 8
  %cv2601 = zext i32 %v2600 to i64
  %cond2602 = icmp ne i64 %cv2601, 0
  br i1 %cond2602, label %bb_rcslotrole1297, label %bb_rcslotowner1297
bb_rcslotrole1297:
  %v2603 = load i64, ptr %slot35, align 8
  store i64 %v2603, ptr %slot468, align 8
  %v2604 = load i64, ptr %slot468, align 8
  %v2605 = load i64, ptr %slot465, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2604, i64 %v2605) nomerge, !dbg !150
  br label %bb_rcslotdone1297
bb_rcslotowner1297:
  %v2606 = load i64, ptr %slot35, align 8
  store i64 %v2606, ptr %slot469, align 8
  %v2607 = load i64, ptr %slot469, align 8
  %v2608 = load i64, ptr %slot465, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2607, i64 %v2608) nomerge, !dbg !150
  br label %bb_rcslotdone1297
bb_rcslotdone1297:
  %v2609 = load i64, ptr %slot463, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2610, i64 32, i1 false)
  ret void
bb_i50:
  %v2611 = load i64, ptr %slot34, align 8
  store i64 %v2611, ptr %slot470, align 8
  %v2612 = load i64, ptr %slot470, align 8
  %p2613 = inttoptr i64 %v2612 to ptr
  store i64 0, ptr %p2613, align 8, !alias.scope !3, !noalias !4
  %v2614 = load i64, ptr %slot470, align 8
  %p2616 = inttoptr i64 %v2614 to ptr
  %gep2617 = getelementptr i8, ptr %p2616, i64 8
  %op2615 = ptrtoint ptr %gep2617 to i64
  store i64 %op2615, ptr %slot471, align 8
  %v2618 = load i64, ptr %slot471, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  store i64 0, ptr %p2619, align 8, !alias.scope !3, !noalias !4
  %v2620 = load i64, ptr %slot470, align 8
  %p2622 = inttoptr i64 %v2620 to ptr
  %gep2623 = getelementptr i8, ptr %p2622, i64 16
  %op2621 = ptrtoint ptr %gep2623 to i64
  store i64 %op2621, ptr %slot472, align 8
  %v2624 = load i64, ptr %slot472, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  store i64 0, ptr %p2625, align 8, !alias.scope !3, !noalias !4
  %v2626 = load i64, ptr %slot470, align 8
  %p2628 = inttoptr i64 %v2626 to ptr
  %gep2629 = getelementptr i8, ptr %p2628, i64 24
  %op2627 = ptrtoint ptr %gep2629 to i64
  store i64 %op2627, ptr %slot473, align 8
  %v2630 = load i64, ptr %slot473, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  store i64 0, ptr %p2631, align 8, !alias.scope !3, !noalias !4
  %v2632 = load i64, ptr %slot470, align 8
  %p2633 = inttoptr i64 %v2632 to ptr
  store i32 0, ptr %p2633, align 4, !alias.scope !3, !noalias !4
  %v2634 = load i64, ptr %slot470, align 8
  %v2635 = load i64, ptr %slot19, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  store i64 %v2634, ptr %p2636, align 8, !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot19, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %ld2639 = load i64, ptr %p2638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2639, ptr %slot474, align 8
  %v2640 = load i64, ptr %slot11, align 8
  store i64 %v2640, ptr %slot475, align 8
  %v2641 = load i64, ptr %slot474, align 8
  %v2642 = load i64, ptr %slot475, align 8
  %p2643 = inttoptr i64 %v2641 to ptr
  %p2644 = inttoptr i64 %v2642 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2644, ptr %p2643, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot7, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  store i32 2, ptr %p2646, align 4, !alias.scope !3, !noalias !4
  %v2647 = load i64, ptr %slot6, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  store i32 1, ptr %p2648, align 4, !alias.scope !3, !noalias !4
  %v2649 = load i64, ptr %slot475, align 8
  %v2650 = load i64, ptr %slot19, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  store i64 %v2649, ptr %p2651, align 8, !alias.scope !3, !noalias !4
  %v2652 = load i64, ptr %slot19, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  %ld2654 = load i64, ptr %p2653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2654, ptr %slot476, align 8
  %v2655 = load i64, ptr %slot19, align 8
  %p2656 = inttoptr i64 %v2655 to ptr
  %ld2657 = load i64, ptr %p2656, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2657, ptr %slot477, align 8
  %v2658 = load i64, ptr %slot12, align 8
  store i64 %v2658, ptr %slot478, align 8
  %v2659 = load i64, ptr %slot36, align 8
  store i64 %v2659, ptr %slot479, align 8
  %v2660 = load i64, ptr %slot35, align 8
  %v2661 = load i64, ptr %slot478, align 8
  %v2662 = load i64, ptr %slot477, align 8
  %v2663 = load i64, ptr %slot479, align 8
  %cv2664 = trunc i64 %v2663 to i32
  %call2665 = call i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64 %v2660, i64 %v2661, i64 %v2662, i32 %cv2664) nomerge, !dbg !152
  store i32 %call2665, ptr %slot480, align 8
  %v2666 = load i32, ptr %slot480, align 8
  %cv2667 = zext i32 %v2666 to i64
  %cond2668 = icmp ne i64 %cv2667, 0
  br i1 %cond2668, label %bb_rcsuccess1372, label %bb_rcfailure1372
bb_rcfailure1372:
  %v2669 = load i64, ptr %slot35, align 8
  %p2670 = inttoptr i64 %v2669 to ptr
  %call2671 = call i32 @myl_rc_take_failure(ptr %p2670) nomerge, !dbg !152
  store i32 %call2671, ptr %slot481, align 8
  %v2672 = load i64, ptr %slot1, align 8
  %p2673 = inttoptr i64 %v2672 to ptr
  %v2674 = load i32, ptr %slot481, align 8
  %call2675 = call i32 @myl_qbe_rc_status(ptr %p2673, i32 %v2674) nomerge, !dbg !152
  store i32 %call2675, ptr %slot482, align 8
  br label %bb_failure
bb_rcsuccess1372:
  %v2676 = load i64, ptr %slot6, align 8
  %p2677 = inttoptr i64 %v2676 to ptr
  store i32 0, ptr %p2677, align 4, !alias.scope !3, !noalias !4
  %v2678 = load i64, ptr %slot9, align 8
  %p2679 = inttoptr i64 %v2678 to ptr
  store i32 2, ptr %p2679, align 4, !alias.scope !3, !noalias !4
  %v2680 = load i64, ptr %slot8, align 8
  %p2681 = inttoptr i64 %v2680 to ptr
  store i32 1, ptr %p2681, align 4, !alias.scope !3, !noalias !4
  %v2682 = load i64, ptr %slot12, align 8
  store i64 %v2682, ptr %slot483, align 8
  %v2683 = load i64, ptr %slot8, align 8
  %p2684 = inttoptr i64 %v2683 to ptr
  store i32 0, ptr %p2684, align 4, !alias.scope !3, !noalias !4
  %v2685 = load i64, ptr %slot6, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %ld2687 = load i32, ptr %p2686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2687, ptr %slot484, align 8
  %v2688 = load i32, ptr %slot484, align 8
  %cv2689 = zext i32 %v2688 to i64
  %cond2690 = icmp ne i64 %cv2689, 0
  br i1 %cond2690, label %bb_rcslotdrop1382, label %bb_rcslotdone1382
bb_rcslotdrop1382:
  %v2691 = load i64, ptr %slot6, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  store i32 0, ptr %p2692, align 4, !alias.scope !3, !noalias !4
  %v2693 = load i64, ptr %slot11, align 8
  store i64 %v2693, ptr %slot485, align 8
  %v2694 = load i64, ptr %slot7, align 8
  %p2695 = inttoptr i64 %v2694 to ptr
  %ld2696 = load i32, ptr %p2695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2696, ptr %slot486, align 8
  %v2697 = load i32, ptr %slot486, align 8
  %op2698 = and i32 %v2697, 28
  store i32 %op2698, ptr %slot487, align 8
  %v2699 = load i32, ptr %slot487, align 8
  %cv2700 = zext i32 %v2699 to i64
  %cond2701 = icmp ne i64 %cv2700, 0
  br i1 %cond2701, label %bb_rcslotrole1382, label %bb_rcslotowner1382
bb_rcslotrole1382:
  %v2702 = load i64, ptr %slot35, align 8
  store i64 %v2702, ptr %slot488, align 8
  %v2703 = load i64, ptr %slot488, align 8
  %v2704 = load i64, ptr %slot485, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64 %v2703, i64 %v2704) nomerge, !dbg !152
  br label %bb_rcslotdone1382
bb_rcslotowner1382:
  %v2705 = load i64, ptr %slot35, align 8
  store i64 %v2705, ptr %slot489, align 8
  %v2706 = load i64, ptr %slot489, align 8
  %v2707 = load i64, ptr %slot485, align 8
  call void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64 %v2706, i64 %v2707) nomerge, !dbg !152
  br label %bb_rcslotdone1382
bb_rcslotdone1382:
  %v2708 = load i64, ptr %slot483, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2709, i64 32, i1 false)
  ret void
bb_failure:
  %v2710 = load i64, ptr %slot5, align 8
  %p2711 = inttoptr i64 %v2710 to ptr
  call void @llvm.memset.p0.i64(ptr %p2711, i8 0, i64 32, i1 false), !alias.scope !3, !noalias !4, !dbg !152
  %v2712 = load i64, ptr %slot5, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2713, i64 32, i1 false)
  ret void
bb_entry_failure:
  %v2714 = load i64, ptr %slot5, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  call void @llvm.memset.p0.i64(ptr %p2715, i8 0, i64 32, i1 false), !alias.scope !3, !noalias !4, !dbg !152
  %v2716 = load i64, ptr %slot5, align 8
  %p2717 = inttoptr i64 %v2716 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p2717, i64 32, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_drop(i64, i64)
declare i32 @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_take(i64, i64, i64, i32)
declare void @myl_t_475cbf5edb59f2a736878a748259477909f6fceb445c19791a554895a7d7347e_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_drop(i64, i64)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64, i64, i64, i32)
declare void @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191", linkageName: "myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 8840644549513821758, i64 0, !"myl_f_840f290de93a8e53b6339337bb7ea61e9f30c97f2b0a4c6bc273ad3fd22ad191"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!112 = !DILocation(line: 4, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!114 = !DILocation(line: 13, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!116 = !DILocation(line: 15, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!118 = !DILocation(line: 18, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!120 = !DILocation(line: 19, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!122 = !DILocation(line: 24, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!124 = !DILocation(line: 25, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!126 = !DILocation(line: 26, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!128 = !DILocation(line: 28, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!130 = !DILocation(line: 30, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!132 = !DILocation(line: 32, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!134 = !DILocation(line: 34, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646823)
!136 = !DILocation(line: 36, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!138 = !DILocation(line: 38, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!140 = !DILocation(line: 40, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!142 = !DILocation(line: 42, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!144 = !DILocation(line: 44, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!146 = !DILocation(line: 46, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!148 = !DILocation(line: 48, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!150 = !DILocation(line: 50, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!152 = !DILocation(line: 52, column: 0, scope: !153)
