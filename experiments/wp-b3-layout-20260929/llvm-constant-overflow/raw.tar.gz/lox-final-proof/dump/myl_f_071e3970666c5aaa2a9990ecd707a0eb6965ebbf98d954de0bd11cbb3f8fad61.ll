target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v40 = load i64, ptr %slot1, align 8
  %op41 = add i64 %v40, 32
  store i64 %op41, ptr %slot5, align 8
  %mem42 = alloca i8, i64 8, align 8
  %ptr43 = ptrtoint ptr %mem42 to i64
  store i64 %ptr43, ptr %slot6, align 8
  %mem44 = alloca i8, i64 8, align 8
  %ptr45 = ptrtoint ptr %mem44 to i64
  store i64 %ptr45, ptr %slot7, align 8
  %mem46 = alloca i8, i64 8, align 8
  %ptr47 = ptrtoint ptr %mem46 to i64
  store i64 %ptr47, ptr %slot8, align 8
  %mem48 = alloca i8, i64 8, align 8
  %ptr49 = ptrtoint ptr %mem48 to i64
  store i64 %ptr49, ptr %slot9, align 8
  %mem50 = alloca i8, i64 8, align 8
  %ptr51 = ptrtoint ptr %mem50 to i64
  store i64 %ptr51, ptr %slot10, align 8
  %mem52 = alloca i8, i64 40, align 8
  %ptr53 = ptrtoint ptr %mem52 to i64
  store i64 %ptr53, ptr %slot11, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem54 = alloca i8, i64 8, align 8
  %ptr55 = ptrtoint ptr %mem54 to i64
  store i64 %ptr55, ptr %slot12, align 8
  %v56 = load i64, ptr %slot1, align 8
  %op57 = add i64 %v56, 64
  store i64 %op57, ptr %slot13, align 8
  %v58 = load i64, ptr %slot13, align 8
  %p59 = inttoptr i64 %v58 to ptr
  %ld60 = load i64, ptr %p59, align 8, !alias.scope !4, !noalias !3
  store i64 %ld60, ptr %slot14, align 8
  %stack61 = call ptr @llvm.stacksave()
  %stackaddr62 = ptrtoint ptr %stack61 to i64
  %v63 = load i64, ptr %slot14, align 8
  %cmp64 = icmp ult i64 %stackaddr62, %v63
  %cv65 = zext i1 %cmp64 to i64
  store i64 %cv65, ptr %slot15, align 8
  %v66 = load i64, ptr %slot15, align 8
  %cond67 = icmp ne i64 %v66, 0
  br i1 %cond67, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v68 = load i64, ptr %slot1, align 8
  %p69 = inttoptr i64 %v68 to ptr
  call void @myl_qbe_fail_frame(ptr %p69) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v70 = load i64, ptr %slot2, align 8
  %v71 = load i64, ptr %slot6, align 8
  %p72 = inttoptr i64 %v71 to ptr
  store i64 %v70, ptr %p72, align 8, !alias.scope !3, !noalias !4
  %v73 = load i64, ptr %slot3, align 8
  %v74 = load i64, ptr %slot7, align 8
  %p75 = inttoptr i64 %v74 to ptr
  store i64 %v73, ptr %p75, align 8, !alias.scope !3, !noalias !4
  %v76 = load i64, ptr %slot4, align 8
  %v77 = load i64, ptr %slot8, align 8
  %p78 = inttoptr i64 %v77 to ptr
  store i64 %v76, ptr %p78, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v79 = load i64, ptr %slot6, align 8
  %p80 = inttoptr i64 %v79 to ptr
  %ld81 = load i64, ptr %p80, align 8, !alias.scope !3, !noalias !4
  store i64 %ld81, ptr %slot16, align 8
  %v82 = load i64, ptr %slot16, align 8
  %v83 = load i64, ptr %slot9, align 8
  %p84 = inttoptr i64 %v83 to ptr
  store i64 %v82, ptr %p84, align 8, !alias.scope !3, !noalias !4
  %v85 = load i64, ptr %slot9, align 8
  %p86 = inttoptr i64 %v85 to ptr
  %ld87 = load i64, ptr %p86, align 8, !alias.scope !3, !noalias !4
  store i64 %ld87, ptr %slot17, align 8
  %v88 = load i64, ptr %slot17, align 8
  %op89 = add i64 %v88, 288
  store i64 %op89, ptr %slot18, align 8
  %v90 = load i64, ptr %slot18, align 8
  %v91 = load i64, ptr %slot9, align 8
  %p92 = inttoptr i64 %v91 to ptr
  store i64 %v90, ptr %p92, align 8, !alias.scope !3, !noalias !4
  %v93 = load i64, ptr %slot9, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %ld95 = load i64, ptr %p94, align 8, !alias.scope !3, !noalias !4
  store i64 %ld95, ptr %slot19, align 8
  %v96 = load i64, ptr %slot19, align 8
  %op97 = add i64 %v96, 0
  store i64 %op97, ptr %slot20, align 8
  %v98 = load i64, ptr %slot20, align 8
  %v99 = load i64, ptr %slot9, align 8
  %p100 = inttoptr i64 %v99 to ptr
  store i64 %v98, ptr %p100, align 8, !alias.scope !3, !noalias !4
  %v101 = load i64, ptr %slot9, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %ld103 = load i64, ptr %p102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld103, ptr %slot21, align 8
  %v104 = load i64, ptr %slot11, align 8
  store i64 %v104, ptr %slot22, align 8
  %v105 = load i64, ptr %slot21, align 8
  %v106 = load i64, ptr %slot22, align 8
  %p107 = inttoptr i64 %v105 to ptr
  %p108 = inttoptr i64 %v106 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p108, ptr %p107, i64 4, i1 false), !alias.scope !10000000
  %v109 = load i64, ptr %slot22, align 8
  %v110 = load i64, ptr %slot9, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 %v109, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot7, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld114, ptr %slot23, align 8
  %v115 = load i64, ptr %slot23, align 8
  %v116 = load i64, ptr %slot10, align 8
  %p117 = inttoptr i64 %v116 to ptr
  store i64 %v115, ptr %p117, align 8, !alias.scope !3, !noalias !4
  %v118 = load i64, ptr %slot10, align 8
  %p119 = inttoptr i64 %v118 to ptr
  %ld120 = load i64, ptr %p119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld120, ptr %slot24, align 8
  %v121 = load i64, ptr %slot9, align 8
  %p122 = inttoptr i64 %v121 to ptr
  %ld123 = load i64, ptr %p122, align 8, !alias.scope !3, !noalias !4
  store i64 %ld123, ptr %slot25, align 8
  %v124 = load i64, ptr %slot25, align 8
  %p125 = inttoptr i64 %v124 to ptr
  %ld126 = load i32, ptr %p125, align 4, !alias.scope !3, !noalias !4
  %ext127 = zext i32 %ld126 to i64
  store i64 %ext127, ptr %slot26, align 8
  %v128 = load i64, ptr %slot24, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i32, ptr %p129, align 4, !alias.scope !4, !noalias !3
  %ext131 = zext i32 %ld130 to i64
  store i64 %ext131, ptr %slot27, align 8
  %v132 = load i64, ptr %slot26, align 8
  %v133 = load i64, ptr %slot27, align 8
  %cmp134 = icmp eq i64 %v132, %v133
  %cv135 = zext i1 %cmp134 to i64
  store i64 %cv135, ptr %slot28, align 8
  %v136 = load i64, ptr %slot28, align 8
  %v137 = load i64, ptr %slot9, align 8
  %p138 = inttoptr i64 %v137 to ptr
  store i64 %v136, ptr %p138, align 8, !alias.scope !3, !noalias !4
  %v139 = load i64, ptr %slot9, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot29, align 8
  %v142 = load i64, ptr %slot29, align 8
  %cond143 = icmp ne i64 %v142, 0
  br i1 %cond143, label %bb_next41, label %bb_i11
bb_next41:
  %v144 = load i64, ptr %slot6, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld146, ptr %slot30, align 8
  %v147 = load i64, ptr %slot30, align 8
  %v148 = load i64, ptr %slot9, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i64 %v147, ptr %p149, align 8, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot9, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld152, ptr %slot31, align 8
  %v153 = load i64, ptr %slot1, align 8
  %v154 = load i64, ptr %slot31, align 8
  %call155 = call i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64 %v153, i64 %v154) nomerge, !dbg !112
  store i64 %call155, ptr %slot32, align 8
  %v156 = load i64, ptr %slot32, align 8
  %v157 = load i64, ptr %slot9, align 8
  %p158 = inttoptr i64 %v157 to ptr
  store i64 %v156, ptr %p158, align 8, !alias.scope !3, !noalias !4
  %v159 = load i64, ptr %slot9, align 8
  %p160 = inttoptr i64 %v159 to ptr
  store i64 0, ptr %p160, align 8, !alias.scope !3, !noalias !4
  %v161 = load i64, ptr %slot9, align 8
  %p162 = inttoptr i64 %v161 to ptr
  %ld163 = load i64, ptr %p162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld163, ptr %slot33, align 8
  %v164 = load i64, ptr %slot33, align 8
  ret i64 %v164
bb_i11:
  %v165 = load i64, ptr %slot6, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld167, ptr %slot34, align 8
  %v168 = load i64, ptr %slot34, align 8
  %v169 = load i64, ptr %slot9, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i64 %v168, ptr %p170, align 8, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot8, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot35, align 8
  %v174 = load i64, ptr %slot35, align 8
  %v175 = load i64, ptr %slot10, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i64 %v174, ptr %p176, align 8, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot9, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot36, align 8
  %v180 = load i64, ptr %slot10, align 8
  %p181 = inttoptr i64 %v180 to ptr
  %ld182 = load i64, ptr %p181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld182, ptr %slot37, align 8
  %v183 = load i64, ptr %slot1, align 8
  %v184 = load i64, ptr %slot36, align 8
  %v185 = load i64, ptr %slot37, align 8
  %call186 = call i64 @myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58(i64 %v183, i64 %v184, i64 %v185) nomerge, !dbg !114
  store i64 %call186, ptr %slot38, align 8
  %v187 = load i64, ptr %slot38, align 8
  %v188 = load i64, ptr %slot9, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot9, align 8
  %p191 = inttoptr i64 %v190 to ptr
  store i64 0, ptr %p191, align 8, !alias.scope !3, !noalias !4
  %v192 = load i64, ptr %slot9, align 8
  %p193 = inttoptr i64 %v192 to ptr
  %ld194 = load i64, ptr %p193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld194, ptr %slot39, align 8
  %v195 = load i64, ptr %slot39, align 8
  ret i64 %v195
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_6817be4bfc3d7710cd67fd764ec13d1eb7a19d691e453a6438bf533c5691fddf(i64, i64)
declare i64 @myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61", linkageName: "myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15991426334793407254, i64 0, !"myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!112 = !DILocation(line: 8, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!114 = !DILocation(line: 14, column: 0, scope: !115)
