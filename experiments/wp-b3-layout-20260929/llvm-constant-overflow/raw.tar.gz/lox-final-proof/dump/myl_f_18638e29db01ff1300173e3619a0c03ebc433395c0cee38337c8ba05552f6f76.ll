target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %callresult53 = alloca [88 x i8], align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v179 = load i64, ptr %slot1, align 8
  %op180 = add i64 %v179, 32
  store i64 %op180, ptr %slot4, align 8
  %mem181 = alloca i8, i64 8, align 8
  %ptr182 = ptrtoint ptr %mem181 to i64
  store i64 %ptr182, ptr %slot5, align 8
  %mem183 = alloca i8, i64 8, align 8
  %ptr184 = ptrtoint ptr %mem183 to i64
  store i64 %ptr184, ptr %slot6, align 8
  %mem185 = alloca i8, i64 8, align 8
  %ptr186 = ptrtoint ptr %mem185 to i64
  store i64 %ptr186, ptr %slot7, align 8
  %mem187 = alloca i8, i64 8, align 8
  %ptr188 = ptrtoint ptr %mem187 to i64
  store i64 %ptr188, ptr %slot8, align 8
  %mem189 = alloca i8, i64 8, align 8
  %ptr190 = ptrtoint ptr %mem189 to i64
  store i64 %ptr190, ptr %slot9, align 8
  %mem191 = alloca i8, i64 8, align 8
  %ptr192 = ptrtoint ptr %mem191 to i64
  store i64 %ptr192, ptr %slot10, align 8
  %mem193 = alloca i8, i64 392, align 8
  %ptr194 = ptrtoint ptr %mem193 to i64
  store i64 %ptr194, ptr %slot11, align 8
  %mem195 = alloca i8, i64 392, align 8
  %ptr196 = ptrtoint ptr %mem195 to i64
  store i64 %ptr196, ptr %slot12, align 8
  %mem197 = alloca i8, i64 8, align 8
  %ptr198 = ptrtoint ptr %mem197 to i64
  store i64 %ptr198, ptr %slot13, align 8
  %mem199 = alloca i8, i64 392, align 8
  %ptr200 = ptrtoint ptr %mem199 to i64
  store i64 %ptr200, ptr %slot14, align 8
  %mem201 = alloca i8, i64 8, align 8
  %ptr202 = ptrtoint ptr %mem201 to i64
  store i64 %ptr202, ptr %slot15, align 8
  %mem203 = alloca i8, i64 8, align 8
  %ptr204 = ptrtoint ptr %mem203 to i64
  store i64 %ptr204, ptr %slot16, align 8
  %mem205 = alloca i8, i64 8, align 8
  %ptr206 = ptrtoint ptr %mem205 to i64
  store i64 %ptr206, ptr %slot17, align 8
  %mem207 = alloca i8, i64 8, align 8
  %ptr208 = ptrtoint ptr %mem207 to i64
  store i64 %ptr208, ptr %slot18, align 8
  %mem209 = alloca i8, i64 8, align 8
  %ptr210 = ptrtoint ptr %mem209 to i64
  store i64 %ptr210, ptr %slot19, align 8
  %mem211 = alloca i8, i64 392, align 8
  %ptr212 = ptrtoint ptr %mem211 to i64
  store i64 %ptr212, ptr %slot20, align 8
  %mem213 = alloca i8, i64 392, align 8
  %ptr214 = ptrtoint ptr %mem213 to i64
  store i64 %ptr214, ptr %slot21, align 8
  %mem215 = alloca i8, i64 392, align 8
  %ptr216 = ptrtoint ptr %mem215 to i64
  store i64 %ptr216, ptr %slot22, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem217 = alloca i8, i64 8, align 8
  %ptr218 = ptrtoint ptr %mem217 to i64
  store i64 %ptr218, ptr %slot23, align 8
  %v219 = load i64, ptr %slot1, align 8
  %op220 = add i64 %v219, 64
  store i64 %op220, ptr %slot24, align 8
  %v221 = load i64, ptr %slot24, align 8
  %p222 = inttoptr i64 %v221 to ptr
  %ld223 = load i64, ptr %p222, align 8, !alias.scope !4, !noalias !3
  store i64 %ld223, ptr %slot25, align 8
  %stack224 = call ptr @llvm.stacksave()
  %stackaddr225 = ptrtoint ptr %stack224 to i64
  %v226 = load i64, ptr %slot25, align 8
  %cmp227 = icmp ult i64 %stackaddr225, %v226
  %cv228 = zext i1 %cmp227 to i64
  store i64 %cv228, ptr %slot26, align 8
  %v229 = load i64, ptr %slot26, align 8
  %cond230 = icmp ne i64 %v229, 0
  br i1 %cond230, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v231 = load i64, ptr %slot1, align 8
  %p232 = inttoptr i64 %v231 to ptr
  call void @myl_qbe_fail_frame(ptr %p232) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v233 = load i64, ptr %slot2, align 8
  %v234 = load i64, ptr %slot15, align 8
  %p235 = inttoptr i64 %v234 to ptr
  store i64 %v233, ptr %p235, align 8, !alias.scope !3, !noalias !4
  %v236 = load i64, ptr %slot3, align 8
  %v237 = load i64, ptr %slot16, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot1, align 8
  %p240 = inttoptr i64 %v239 to ptr
  %call241 = call ptr @myl_qbe_heap(ptr %p240) nomerge, !dbg !112
  %calladdr242 = ptrtoint ptr %call241 to i64
  store i64 %calladdr242, ptr %slot27, align 8
  %v243 = load i64, ptr %slot5, align 8
  %p244 = inttoptr i64 %v243 to ptr
  store i32 0, ptr %p244, align 4, !alias.scope !3, !noalias !4
  %v245 = load i64, ptr %slot6, align 8
  %p246 = inttoptr i64 %v245 to ptr
  store i32 0, ptr %p246, align 4, !alias.scope !3, !noalias !4
  %v247 = load i64, ptr %slot7, align 8
  %p248 = inttoptr i64 %v247 to ptr
  store i32 0, ptr %p248, align 4, !alias.scope !3, !noalias !4
  %v249 = load i64, ptr %slot8, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i32 0, ptr %p250, align 4, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot9, align 8
  %p252 = inttoptr i64 %v251 to ptr
  store i32 0, ptr %p252, align 4, !alias.scope !3, !noalias !4
  %v253 = load i64, ptr %slot10, align 8
  %p254 = inttoptr i64 %v253 to ptr
  store i32 0, ptr %p254, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v255 = load i64, ptr %slot15, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %ld257 = load i64, ptr %p256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld257, ptr %slot28, align 8
  %v258 = load i64, ptr %slot28, align 8
  %v259 = load i64, ptr %slot17, align 8
  %p260 = inttoptr i64 %v259 to ptr
  store i64 %v258, ptr %p260, align 8, !alias.scope !3, !noalias !4
  %v261 = load i64, ptr %slot20, align 8
  store i64 %v261, ptr %slot29, align 8
  %v262 = load i64, ptr %slot29, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i32 0, ptr %p263, align 4, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot29, align 8
  %p265 = inttoptr i64 %v264 to ptr
  store i32 19, ptr %p265, align 4, !alias.scope !3, !noalias !4
  %v266 = load i64, ptr %slot29, align 8
  %v267 = load i64, ptr %slot18, align 8
  %p268 = inttoptr i64 %v267 to ptr
  store i64 %v266, ptr %p268, align 8, !alias.scope !3, !noalias !4
  %v269 = load i64, ptr %slot16, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld271, ptr %slot30, align 8
  %v272 = load i64, ptr %slot30, align 8
  %v273 = load i64, ptr %slot19, align 8
  %p274 = inttoptr i64 %v273 to ptr
  store i64 %v272, ptr %p274, align 8, !alias.scope !3, !noalias !4
  %v275 = load i64, ptr %slot17, align 8
  %p276 = inttoptr i64 %v275 to ptr
  %ld277 = load i64, ptr %p276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld277, ptr %slot31, align 8
  %v278 = load i64, ptr %slot18, align 8
  %p279 = inttoptr i64 %v278 to ptr
  %ld280 = load i64, ptr %p279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld280, ptr %slot32, align 8
  %v281 = load i64, ptr %slot19, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld283, ptr %slot33, align 8
  %v284 = load i64, ptr %slot1, align 8
  %v285 = load i64, ptr %slot31, align 8
  %v286 = load i64, ptr %slot32, align 8
  %v287 = load i64, ptr %slot33, align 8
  %call288 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v284, i64 %v285, i64 %v286, i64 %v287) nomerge, !dbg !114
  store i64 %call288, ptr %slot34, align 8
  %v289 = load i64, ptr %slot34, align 8
  %v290 = load i64, ptr %slot17, align 8
  %p291 = inttoptr i64 %v290 to ptr
  store i64 %v289, ptr %p291, align 8, !alias.scope !3, !noalias !4
  %v292 = load i64, ptr %slot5, align 8
  %p293 = inttoptr i64 %v292 to ptr
  %ld294 = load i32, ptr %p293, align 4, !alias.scope !3, !noalias !4
  store i32 %ld294, ptr %slot35, align 8
  %v295 = load i32, ptr %slot35, align 8
  %cv296 = zext i32 %v295 to i64
  %cond297 = icmp ne i64 %cv296, 0
  br i1 %cond297, label %bb_rcslotdrop18, label %bb_rcslotdone18
bb_rcslotdrop18:
  %v298 = load i64, ptr %slot5, align 8
  %p299 = inttoptr i64 %v298 to ptr
  store i32 0, ptr %p299, align 4, !alias.scope !3, !noalias !4
  %v300 = load i64, ptr %slot11, align 8
  store i64 %v300, ptr %slot36, align 8
  %v301 = load i64, ptr %slot6, align 8
  %p302 = inttoptr i64 %v301 to ptr
  %ld303 = load i32, ptr %p302, align 4, !alias.scope !3, !noalias !4
  store i32 %ld303, ptr %slot37, align 8
  %v304 = load i32, ptr %slot37, align 8
  %op305 = and i32 %v304, 28
  store i32 %op305, ptr %slot38, align 8
  %v306 = load i32, ptr %slot38, align 8
  %cv307 = zext i32 %v306 to i64
  %cond308 = icmp ne i64 %cv307, 0
  br i1 %cond308, label %bb_rcslotrole18, label %bb_rcslotowner18
bb_rcslotrole18:
  %v309 = load i64, ptr %slot27, align 8
  store i64 %v309, ptr %slot39, align 8
  %v310 = load i64, ptr %slot39, align 8
  %v311 = load i64, ptr %slot36, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v310, i64 %v311) nomerge, !dbg !114
  br label %bb_rcslotdone18
bb_rcslotowner18:
  %v312 = load i64, ptr %slot27, align 8
  store i64 %v312, ptr %slot40, align 8
  %v313 = load i64, ptr %slot40, align 8
  %v314 = load i64, ptr %slot36, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v313, i64 %v314) nomerge, !dbg !114
  br label %bb_rcslotdone18
bb_rcslotdone18:
  %v315 = load i64, ptr %slot15, align 8
  %p316 = inttoptr i64 %v315 to ptr
  %ld317 = load i64, ptr %p316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld317, ptr %slot41, align 8
  %v318 = load i64, ptr %slot41, align 8
  %v319 = load i64, ptr %slot17, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i64 %v318, ptr %p320, align 8, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot17, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %ld323 = load i64, ptr %p322, align 8, !alias.scope !3, !noalias !4
  store i64 %ld323, ptr %slot42, align 8
  %v324 = load i64, ptr %slot1, align 8
  %v325 = load i64, ptr %slot42, align 8
  %call326 = call i64 @myl_f_23e1bebda3014162640000246e37fa23a2bbf174be368d790fda65af887cf148(i64 %v324, i64 %v325) nomerge, !dbg !116
  store i64 %call326, ptr %slot43, align 8
  %v327 = load i64, ptr %slot43, align 8
  %v328 = load i64, ptr %slot17, align 8
  %p329 = inttoptr i64 %v328 to ptr
  store i64 %v327, ptr %p329, align 8, !alias.scope !3, !noalias !4
  %v330 = load i64, ptr %slot5, align 8
  %p331 = inttoptr i64 %v330 to ptr
  %ld332 = load i32, ptr %p331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld332, ptr %slot44, align 8
  %v333 = load i32, ptr %slot44, align 8
  %cv334 = zext i32 %v333 to i64
  %cond335 = icmp ne i64 %cv334, 0
  br i1 %cond335, label %bb_rcslotdrop67, label %bb_rcslotdone67
bb_rcslotdrop67:
  %v336 = load i64, ptr %slot5, align 8
  %p337 = inttoptr i64 %v336 to ptr
  store i32 0, ptr %p337, align 4, !alias.scope !3, !noalias !4
  %v338 = load i64, ptr %slot11, align 8
  store i64 %v338, ptr %slot45, align 8
  %v339 = load i64, ptr %slot6, align 8
  %p340 = inttoptr i64 %v339 to ptr
  %ld341 = load i32, ptr %p340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld341, ptr %slot46, align 8
  %v342 = load i32, ptr %slot46, align 8
  %op343 = and i32 %v342, 28
  store i32 %op343, ptr %slot47, align 8
  %v344 = load i32, ptr %slot47, align 8
  %cv345 = zext i32 %v344 to i64
  %cond346 = icmp ne i64 %cv345, 0
  br i1 %cond346, label %bb_rcslotrole67, label %bb_rcslotowner67
bb_rcslotrole67:
  %v347 = load i64, ptr %slot27, align 8
  store i64 %v347, ptr %slot48, align 8
  %v348 = load i64, ptr %slot48, align 8
  %v349 = load i64, ptr %slot45, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v348, i64 %v349) nomerge, !dbg !116
  br label %bb_rcslotdone67
bb_rcslotowner67:
  %v350 = load i64, ptr %slot27, align 8
  store i64 %v350, ptr %slot49, align 8
  %v351 = load i64, ptr %slot49, align 8
  %v352 = load i64, ptr %slot45, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v351, i64 %v352) nomerge, !dbg !116
  br label %bb_rcslotdone67
bb_rcslotdone67:
  %v353 = load i64, ptr %slot15, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %ld355 = load i64, ptr %p354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld355, ptr %slot50, align 8
  %v356 = load i64, ptr %slot50, align 8
  %v357 = load i64, ptr %slot17, align 8
  %p358 = inttoptr i64 %v357 to ptr
  store i64 %v356, ptr %p358, align 8, !alias.scope !3, !noalias !4
  %v359 = load i64, ptr %slot17, align 8
  %p360 = inttoptr i64 %v359 to ptr
  %ld361 = load i64, ptr %p360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld361, ptr %slot51, align 8
  %v362 = load i64, ptr %slot1, align 8
  %v363 = load i64, ptr %slot51, align 8
  call void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8 %callresult53, i64 %v362, i64 %v363) nomerge, !dbg !118
  %addr364 = ptrtoint ptr %callresult53 to i64
  store i64 %addr364, ptr %slot52, align 8
  %v365 = load i64, ptr %slot52, align 8
  %v366 = load i64, ptr %slot17, align 8
  %p367 = inttoptr i64 %v366 to ptr
  store i64 %v365, ptr %p367, align 8, !alias.scope !3, !noalias !4
  %v368 = load i64, ptr %slot17, align 8
  %p369 = inttoptr i64 %v368 to ptr
  %ld370 = load i64, ptr %p369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld370, ptr %slot54, align 8
  %v371 = load i64, ptr %slot14, align 8
  store i64 %v371, ptr %slot55, align 8
  %v372 = load i64, ptr %slot54, align 8
  %v373 = load i64, ptr %slot55, align 8
  %p374 = inttoptr i64 %v372 to ptr
  %p375 = inttoptr i64 %v373 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p375, ptr %p374, i64 88, i1 false)
  %v376 = load i64, ptr %slot10, align 8
  %p377 = inttoptr i64 %v376 to ptr
  store i32 2, ptr %p377, align 4, !alias.scope !3, !noalias !4
  %v378 = load i64, ptr %slot9, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i32 1, ptr %p379, align 4, !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot5, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i32, ptr %p381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld382, ptr %slot56, align 8
  %v383 = load i32, ptr %slot56, align 8
  %cv384 = zext i32 %v383 to i64
  %cond385 = icmp ne i64 %cv384, 0
  br i1 %cond385, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v386 = load i64, ptr %slot5, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i32 0, ptr %p387, align 4, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot11, align 8
  store i64 %v388, ptr %slot57, align 8
  %v389 = load i64, ptr %slot6, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %ld391 = load i32, ptr %p390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld391, ptr %slot58, align 8
  %v392 = load i32, ptr %slot58, align 8
  %op393 = and i32 %v392, 28
  store i32 %op393, ptr %slot59, align 8
  %v394 = load i32, ptr %slot59, align 8
  %cv395 = zext i32 %v394 to i64
  %cond396 = icmp ne i64 %cv395, 0
  br i1 %cond396, label %bb_rcslotrole83, label %bb_rcslotowner83
bb_rcslotrole83:
  %v397 = load i64, ptr %slot27, align 8
  store i64 %v397, ptr %slot60, align 8
  %v398 = load i64, ptr %slot60, align 8
  %v399 = load i64, ptr %slot57, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v398, i64 %v399) nomerge, !dbg !118
  br label %bb_rcslotdone83
bb_rcslotowner83:
  %v400 = load i64, ptr %slot27, align 8
  store i64 %v400, ptr %slot61, align 8
  %v401 = load i64, ptr %slot61, align 8
  %v402 = load i64, ptr %slot57, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v401, i64 %v402) nomerge, !dbg !118
  br label %bb_rcslotdone83
bb_rcslotdone83:
  %v403 = load i64, ptr %slot11, align 8
  store i64 %v403, ptr %slot62, align 8
  %v404 = load i64, ptr %slot14, align 8
  store i64 %v404, ptr %slot63, align 8
  %v405 = load i64, ptr %slot63, align 8
  %v406 = load i64, ptr %slot62, align 8
  %p407 = inttoptr i64 %v405 to ptr
  %p408 = inttoptr i64 %v406 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p408, ptr %p407, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v409 = load i64, ptr %slot6, align 8
  %p410 = inttoptr i64 %v409 to ptr
  store i32 2, ptr %p410, align 4, !alias.scope !3, !noalias !4
  %v411 = load i64, ptr %slot10, align 8
  %p412 = inttoptr i64 %v411 to ptr
  %ld413 = load i32, ptr %p412, align 4, !alias.scope !3, !noalias !4
  store i32 %ld413, ptr %slot64, align 8
  %v414 = load i32, ptr %slot64, align 8
  %v415 = load i64, ptr %slot6, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i32 %v414, ptr %p416, align 4, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot9, align 8
  %p418 = inttoptr i64 %v417 to ptr
  store i32 0, ptr %p418, align 4, !alias.scope !3, !noalias !4
  %v419 = load i64, ptr %slot5, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i32 1, ptr %p420, align 4, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot62, align 8
  %v422 = load i64, ptr %slot17, align 8
  %p423 = inttoptr i64 %v422 to ptr
  store i64 %v421, ptr %p423, align 8, !alias.scope !3, !noalias !4
  %v424 = load i64, ptr %slot17, align 8
  %p425 = inttoptr i64 %v424 to ptr
  %ld426 = load i64, ptr %p425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld426, ptr %slot65, align 8
  %v427 = load i64, ptr %slot65, align 8
  %op428 = add i64 %v427, 80
  store i64 %op428, ptr %slot66, align 8
  %v429 = load i64, ptr %slot66, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot67, align 8
  %v432 = load i64, ptr %slot67, align 8
  %v433 = load i64, ptr %slot17, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i64 %v432, ptr %p434, align 8, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot5, align 8
  %p436 = inttoptr i64 %v435 to ptr
  %ld437 = load i32, ptr %p436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld437, ptr %slot68, align 8
  %v438 = load i32, ptr %slot68, align 8
  %cv439 = zext i32 %v438 to i64
  %cond440 = icmp ne i64 %cv439, 0
  br i1 %cond440, label %bb_rcslotdrop103, label %bb_rcslotdone103
bb_rcslotdrop103:
  %v441 = load i64, ptr %slot5, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i32 0, ptr %p442, align 4, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot11, align 8
  store i64 %v443, ptr %slot69, align 8
  %v444 = load i64, ptr %slot6, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i32, ptr %p445, align 4, !alias.scope !3, !noalias !4
  store i32 %ld446, ptr %slot70, align 8
  %v447 = load i32, ptr %slot70, align 8
  %op448 = and i32 %v447, 28
  store i32 %op448, ptr %slot71, align 8
  %v449 = load i32, ptr %slot71, align 8
  %cv450 = zext i32 %v449 to i64
  %cond451 = icmp ne i64 %cv450, 0
  br i1 %cond451, label %bb_rcslotrole103, label %bb_rcslotowner103
bb_rcslotrole103:
  %v452 = load i64, ptr %slot27, align 8
  store i64 %v452, ptr %slot72, align 8
  %v453 = load i64, ptr %slot72, align 8
  %v454 = load i64, ptr %slot69, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v453, i64 %v454) nomerge, !dbg !120
  br label %bb_rcslotdone103
bb_rcslotowner103:
  %v455 = load i64, ptr %slot27, align 8
  store i64 %v455, ptr %slot73, align 8
  %v456 = load i64, ptr %slot73, align 8
  %v457 = load i64, ptr %slot69, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v456, i64 %v457) nomerge, !dbg !120
  br label %bb_rcslotdone103
bb_rcslotdone103:
  %v458 = load i64, ptr %slot18, align 8
  %p459 = inttoptr i64 %v458 to ptr
  store i64 0, ptr %p459, align 8, !alias.scope !3, !noalias !4
  %v460 = load i64, ptr %slot18, align 8
  %p461 = inttoptr i64 %v460 to ptr
  %ld462 = load i64, ptr %p461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld462, ptr %slot74, align 8
  %v463 = load i64, ptr %slot17, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %ld465 = load i64, ptr %p464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld465, ptr %slot75, align 8
  %v466 = load i64, ptr %slot75, align 8
  %v467 = load i64, ptr %slot74, align 8
  %cmp468 = icmp sgt i64 %v466, %v467
  %cv469 = zext i1 %cmp468 to i64
  store i64 %cv469, ptr %slot76, align 8
  %v470 = load i64, ptr %slot76, align 8
  %v471 = load i64, ptr %slot17, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i64 %v470, ptr %p472, align 8, !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot17, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %ld475 = load i64, ptr %p474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld475, ptr %slot77, align 8
  %v476 = load i64, ptr %slot77, align 8
  %cond477 = icmp ne i64 %v476, 0
  br i1 %cond477, label %bb_next114, label %bb_i16
bb_next114:
  %v478 = load i64, ptr %slot17, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i64 0, ptr %p479, align 8, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot17, align 8
  %p481 = inttoptr i64 %v480 to ptr
  %ld482 = load i64, ptr %p481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld482, ptr %slot78, align 8
  %v483 = load i64, ptr %slot5, align 8
  %p484 = inttoptr i64 %v483 to ptr
  %ld485 = load i32, ptr %p484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld485, ptr %slot79, align 8
  %v486 = load i32, ptr %slot79, align 8
  %cv487 = zext i32 %v486 to i64
  %cond488 = icmp ne i64 %cv487, 0
  br i1 %cond488, label %bb_rcslotdrop117, label %bb_rcslotdone117
bb_rcslotdrop117:
  %v489 = load i64, ptr %slot5, align 8
  %p490 = inttoptr i64 %v489 to ptr
  store i32 0, ptr %p490, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone117
bb_rcslotdone117:
  %v491 = load i64, ptr %slot78, align 8
  ret i64 %v491
bb_i16:
  %v492 = load i64, ptr %slot15, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %ld494 = load i64, ptr %p493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld494, ptr %slot80, align 8
  %v495 = load i64, ptr %slot80, align 8
  %v496 = load i64, ptr %slot17, align 8
  %p497 = inttoptr i64 %v496 to ptr
  store i64 %v495, ptr %p497, align 8, !alias.scope !3, !noalias !4
  %v498 = load i64, ptr %slot15, align 8
  %p499 = inttoptr i64 %v498 to ptr
  %ld500 = load i64, ptr %p499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld500, ptr %slot81, align 8
  %v501 = load i64, ptr %slot81, align 8
  %v502 = load i64, ptr %slot21, align 8
  %p503 = inttoptr i64 %v501 to ptr
  %p504 = inttoptr i64 %v502 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p504, ptr %p503, i64 392, i1 false), !alias.scope !10000000
  %v505 = load i64, ptr %slot21, align 8
  %v506 = load i64, ptr %slot18, align 8
  %p507 = inttoptr i64 %v506 to ptr
  store i64 %v505, ptr %p507, align 8, !alias.scope !3, !noalias !4
  %v508 = load i64, ptr %slot18, align 8
  %p509 = inttoptr i64 %v508 to ptr
  %ld510 = load i64, ptr %p509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld510, ptr %slot82, align 8
  %v511 = load i64, ptr %slot82, align 8
  %op512 = add i64 %v511, 248
  store i64 %op512, ptr %slot83, align 8
  %v513 = load i64, ptr %slot83, align 8
  %p514 = inttoptr i64 %v513 to ptr
  %ld515 = load i64, ptr %p514, align 8, !alias.scope !3, !noalias !4
  store i64 %ld515, ptr %slot84, align 8
  %v516 = load i64, ptr %slot84, align 8
  %v517 = load i64, ptr %slot18, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i64 %v516, ptr %p518, align 8, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot7, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %ld521 = load i32, ptr %p520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld521, ptr %slot85, align 8
  %v522 = load i32, ptr %slot85, align 8
  %cv523 = zext i32 %v522 to i64
  %cond524 = icmp ne i64 %cv523, 0
  br i1 %cond524, label %bb_rcslotdrop171, label %bb_rcslotdone171
bb_rcslotdrop171:
  %v525 = load i64, ptr %slot7, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 0, ptr %p526, align 4, !alias.scope !3, !noalias !4
  %v527 = load i64, ptr %slot12, align 8
  store i64 %v527, ptr %slot86, align 8
  %v528 = load i64, ptr %slot8, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i32, ptr %p529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld530, ptr %slot87, align 8
  %v531 = load i32, ptr %slot87, align 8
  %op532 = and i32 %v531, 28
  store i32 %op532, ptr %slot88, align 8
  %v533 = load i32, ptr %slot88, align 8
  %cv534 = zext i32 %v533 to i64
  %cond535 = icmp ne i64 %cv534, 0
  br i1 %cond535, label %bb_rcslotrole171, label %bb_rcslotowner171
bb_rcslotrole171:
  %v536 = load i64, ptr %slot27, align 8
  store i64 %v536, ptr %slot89, align 8
  %v537 = load i64, ptr %slot89, align 8
  %v538 = load i64, ptr %slot86, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v537, i64 %v538) nomerge, !dbg !122
  br label %bb_rcslotdone171
bb_rcslotowner171:
  %v539 = load i64, ptr %slot27, align 8
  store i64 %v539, ptr %slot90, align 8
  %v540 = load i64, ptr %slot90, align 8
  %v541 = load i64, ptr %slot86, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v540, i64 %v541) nomerge, !dbg !122
  br label %bb_rcslotdone171
bb_rcslotdone171:
  %v542 = load i64, ptr %slot15, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld544, ptr %slot91, align 8
  %v545 = load i64, ptr %slot91, align 8
  %v546 = load i64, ptr %slot22, align 8
  %p547 = inttoptr i64 %v545 to ptr
  %p548 = inttoptr i64 %v546 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p548, ptr %p547, i64 392, i1 false), !alias.scope !10000000
  %v549 = load i64, ptr %slot22, align 8
  %v550 = load i64, ptr %slot19, align 8
  %p551 = inttoptr i64 %v550 to ptr
  store i64 %v549, ptr %p551, align 8, !alias.scope !3, !noalias !4
  %v552 = load i64, ptr %slot19, align 8
  %p553 = inttoptr i64 %v552 to ptr
  %ld554 = load i64, ptr %p553, align 8, !alias.scope !3, !noalias !4
  store i64 %ld554, ptr %slot92, align 8
  %v555 = load i64, ptr %slot92, align 8
  %op556 = add i64 %v555, 328
  store i64 %op556, ptr %slot93, align 8
  %v557 = load i64, ptr %slot93, align 8
  %v558 = load i64, ptr %slot19, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i64 %v557, ptr %p559, align 8, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot18, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %ld562 = load i64, ptr %p561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld562, ptr %slot94, align 8
  %v563 = load i64, ptr %slot19, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld565, ptr %slot95, align 8
  %v566 = load i64, ptr %slot1, align 8
  %v567 = load i64, ptr %slot94, align 8
  %v568 = load i64, ptr %slot95, align 8
  %call569 = call i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64 %v566, i64 %v567, i64 %v568) nomerge, !dbg !124
  store i64 %call569, ptr %slot96, align 8
  %v570 = load i64, ptr %slot96, align 8
  %v571 = load i64, ptr %slot18, align 8
  %p572 = inttoptr i64 %v571 to ptr
  store i64 %v570, ptr %p572, align 8, !alias.scope !3, !noalias !4
  %v573 = load i64, ptr %slot18, align 8
  %p574 = inttoptr i64 %v573 to ptr
  %ld575 = load i64, ptr %p574, align 8, !alias.scope !3, !noalias !4
  store i64 %ld575, ptr %slot97, align 8
  %v576 = load i64, ptr %slot97, align 8
  %v577 = load i64, ptr %slot13, align 8
  %p578 = inttoptr i64 %v577 to ptr
  store i64 %v576, ptr %p578, align 8, !alias.scope !3, !noalias !4
  %v579 = load i64, ptr %slot13, align 8
  store i64 %v579, ptr %slot98, align 8
  %v580 = load i64, ptr %slot14, align 8
  store i64 %v580, ptr %slot99, align 8
  %v581 = load i64, ptr %slot98, align 8
  %v582 = load i64, ptr %slot99, align 8
  %p583 = inttoptr i64 %v581 to ptr
  %p584 = inttoptr i64 %v582 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p584, ptr %p583, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot10, align 8
  %p586 = inttoptr i64 %v585 to ptr
  store i32 2, ptr %p586, align 4, !alias.scope !3, !noalias !4
  %v587 = load i64, ptr %slot9, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i32 1, ptr %p588, align 4, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot7, align 8
  %p590 = inttoptr i64 %v589 to ptr
  %ld591 = load i32, ptr %p590, align 4, !alias.scope !3, !noalias !4
  store i32 %ld591, ptr %slot100, align 8
  %v592 = load i32, ptr %slot100, align 8
  %cv593 = zext i32 %v592 to i64
  %cond594 = icmp ne i64 %cv593, 0
  br i1 %cond594, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v595 = load i64, ptr %slot7, align 8
  %p596 = inttoptr i64 %v595 to ptr
  store i32 0, ptr %p596, align 4, !alias.scope !3, !noalias !4
  %v597 = load i64, ptr %slot12, align 8
  store i64 %v597, ptr %slot101, align 8
  %v598 = load i64, ptr %slot8, align 8
  %p599 = inttoptr i64 %v598 to ptr
  %ld600 = load i32, ptr %p599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld600, ptr %slot102, align 8
  %v601 = load i32, ptr %slot102, align 8
  %op602 = and i32 %v601, 28
  store i32 %op602, ptr %slot103, align 8
  %v603 = load i32, ptr %slot103, align 8
  %cv604 = zext i32 %v603 to i64
  %cond605 = icmp ne i64 %cv604, 0
  br i1 %cond605, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v606 = load i64, ptr %slot27, align 8
  store i64 %v606, ptr %slot104, align 8
  %v607 = load i64, ptr %slot101, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i64, ptr %p608, align 8, !alias.scope !3, !noalias !4
  store i64 %ld609, ptr %slot105, align 8
  %v610 = load i64, ptr %slot105, align 8
  %cmp611 = icmp ne i64 %v610, 0
  %cv612 = zext i1 %cmp611 to i32
  store i32 %cv612, ptr %slot106, align 8
  %v613 = load i32, ptr %slot106, align 8
  %cv614 = zext i32 %v613 to i64
  %cond615 = icmp ne i64 %cv614, 0
  br i1 %cond615, label %bb_rcgnn216, label %bb_rcgdone216
bb_rcgnn216:
  %v616 = load i64, ptr %slot105, align 8
  %op617 = sub i64 %v616, 16
  store i64 %op617, ptr %slot107, align 8
  %v618 = load i64, ptr %slot105, align 8
  %p619 = inttoptr i64 %v618 to ptr
  %rgep620 = getelementptr i8, ptr %p619, i64 -16
  %ld621 = load i64, ptr %rgep620, align 8, !alias.scope !9, !noalias !10
  store i64 %ld621, ptr %slot108, align 8
  %v622 = load i64, ptr %slot108, align 8
  %op623 = and i64 %v622, 4611686018427387906
  store i64 %op623, ptr %slot109, align 8
  %v624 = load i64, ptr %slot109, align 8
  %cmp625 = icmp ne i64 %v624, 0
  %cv626 = zext i1 %cmp625 to i32
  store i32 %cv626, ptr %slot110, align 8
  %v627 = load i32, ptr %slot110, align 8
  %cv628 = zext i32 %v627 to i64
  %cond629 = icmp ne i64 %cv628, 0
  br i1 %cond629, label %bb_rcgclear216, label %bb_rcgcounted216
bb_rcgcounted216:
  %v630 = load i64, ptr %slot105, align 8
  %op631 = sub i64 %v630, 24
  store i64 %op631, ptr %slot111, align 8
  %v632 = load i64, ptr %slot105, align 8
  %p633 = inttoptr i64 %v632 to ptr
  %rgep634 = getelementptr i8, ptr %p633, i64 -24
  %ld635 = load i64, ptr %rgep634, align 8, !alias.scope !9, !noalias !10
  store i64 %ld635, ptr %slot112, align 8
  %v636 = load i64, ptr %slot112, align 8
  %op637 = sub i64 %v636, 1
  store i64 %op637, ptr %slot113, align 8
  %v638 = load i64, ptr %slot113, align 8
  %cmp639 = icmp eq i64 %v638, 0
  %cv640 = zext i1 %cmp639 to i32
  store i32 %cv640, ptr %slot114, align 8
  %v641 = load i32, ptr %slot114, align 8
  %cv642 = zext i32 %v641 to i64
  %cond643 = icmp ne i64 %cv642, 0
  br i1 %cond643, label %bb_rcglast216, label %bb_rcgdec216
bb_rcglast216:
  %v644 = load i64, ptr %slot105, align 8
  %op645 = sub i64 %v644, 32
  store i64 %op645, ptr %slot115, align 8
  %v646 = load i64, ptr %slot105, align 8
  %p647 = inttoptr i64 %v646 to ptr
  %rgep648 = getelementptr i8, ptr %p647, i64 -32
  %ld649 = load i64, ptr %rgep648, align 8, !alias.scope !9, !noalias !10
  store i64 %ld649, ptr %slot116, align 8
  %v650 = load i64, ptr %slot116, align 8
  %cmp651 = icmp ne i64 %v650, 0
  %cv652 = zext i1 %cmp651 to i32
  store i32 %cv652, ptr %slot117, align 8
  %v653 = load i32, ptr %slot117, align 8
  %cv654 = zext i32 %v653 to i64
  %cond655 = icmp ne i64 %cv654, 0
  br i1 %cond655, label %bb_rcgdec216, label %bb_rcgslow216
bb_rcgslow216:
  %v656 = load i64, ptr %slot104, align 8
  %v657 = load i64, ptr %slot101, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v656, i64 %v657) nomerge, !dbg !124
  br label %bb_rcgdone216
bb_rcgdec216:
  %v658 = load i64, ptr %slot113, align 8
  %v659 = load i64, ptr %slot105, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %rgep661 = getelementptr i8, ptr %p660, i64 -24
  store i64 %v658, ptr %rgep661, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear216
bb_rcgclear216:
  %v662 = load i64, ptr %slot101, align 8
  %p663 = inttoptr i64 %v662 to ptr
  store i64 0, ptr %p663, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone216
bb_rcgdone216:
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v664 = load i64, ptr %slot27, align 8
  store i64 %v664, ptr %slot118, align 8
  %v665 = load i64, ptr %slot101, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %ld667 = load i64, ptr %p666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld667, ptr %slot119, align 8
  %v668 = load i64, ptr %slot119, align 8
  %cmp669 = icmp ne i64 %v668, 0
  %cv670 = zext i1 %cmp669 to i32
  store i32 %cv670, ptr %slot120, align 8
  %v671 = load i32, ptr %slot120, align 8
  %cv672 = zext i32 %v671 to i64
  %cond673 = icmp ne i64 %cv672, 0
  br i1 %cond673, label %bb_rcgnn231, label %bb_rcgdone231
bb_rcgnn231:
  %v674 = load i64, ptr %slot119, align 8
  %op675 = sub i64 %v674, 16
  store i64 %op675, ptr %slot121, align 8
  %v676 = load i64, ptr %slot119, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %rgep678 = getelementptr i8, ptr %p677, i64 -16
  %ld679 = load i64, ptr %rgep678, align 8, !alias.scope !9, !noalias !10
  store i64 %ld679, ptr %slot122, align 8
  %v680 = load i64, ptr %slot122, align 8
  %op681 = and i64 %v680, 4611686018427387906
  store i64 %op681, ptr %slot123, align 8
  %v682 = load i64, ptr %slot123, align 8
  %cmp683 = icmp ne i64 %v682, 0
  %cv684 = zext i1 %cmp683 to i32
  store i32 %cv684, ptr %slot124, align 8
  %v685 = load i32, ptr %slot124, align 8
  %cv686 = zext i32 %v685 to i64
  %cond687 = icmp ne i64 %cv686, 0
  br i1 %cond687, label %bb_rcgclear231, label %bb_rcgcounted231
bb_rcgcounted231:
  %v688 = load i64, ptr %slot119, align 8
  %op689 = sub i64 %v688, 32
  store i64 %op689, ptr %slot125, align 8
  %v690 = load i64, ptr %slot119, align 8
  %p691 = inttoptr i64 %v690 to ptr
  %rgep692 = getelementptr i8, ptr %p691, i64 -32
  %ld693 = load i64, ptr %rgep692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld693, ptr %slot126, align 8
  %v694 = load i64, ptr %slot126, align 8
  %op695 = sub i64 %v694, 1
  store i64 %op695, ptr %slot127, align 8
  %v696 = load i64, ptr %slot127, align 8
  %cmp697 = icmp eq i64 %v696, 0
  %cv698 = zext i1 %cmp697 to i32
  store i32 %cv698, ptr %slot128, align 8
  %v699 = load i32, ptr %slot128, align 8
  %cv700 = zext i32 %v699 to i64
  %cond701 = icmp ne i64 %cv700, 0
  br i1 %cond701, label %bb_rcglast231, label %bb_rcgdec231
bb_rcglast231:
  %v702 = load i64, ptr %slot119, align 8
  %op703 = sub i64 %v702, 24
  store i64 %op703, ptr %slot129, align 8
  %v704 = load i64, ptr %slot119, align 8
  %p705 = inttoptr i64 %v704 to ptr
  %rgep706 = getelementptr i8, ptr %p705, i64 -24
  %ld707 = load i64, ptr %rgep706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld707, ptr %slot130, align 8
  %v708 = load i64, ptr %slot130, align 8
  %cmp709 = icmp ne i64 %v708, 0
  %cv710 = zext i1 %cmp709 to i32
  store i32 %cv710, ptr %slot131, align 8
  %v711 = load i32, ptr %slot131, align 8
  %cv712 = zext i32 %v711 to i64
  %cond713 = icmp ne i64 %cv712, 0
  br i1 %cond713, label %bb_rcgdec231, label %bb_rcgslow231
bb_rcgslow231:
  %v714 = load i64, ptr %slot118, align 8
  %v715 = load i64, ptr %slot101, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v714, i64 %v715) nomerge, !dbg !124
  br label %bb_rcgdone231
bb_rcgdec231:
  %v716 = load i64, ptr %slot127, align 8
  %v717 = load i64, ptr %slot119, align 8
  %p718 = inttoptr i64 %v717 to ptr
  %rgep719 = getelementptr i8, ptr %p718, i64 -32
  store i64 %v716, ptr %rgep719, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear231
bb_rcgclear231:
  %v720 = load i64, ptr %slot101, align 8
  %p721 = inttoptr i64 %v720 to ptr
  store i64 0, ptr %p721, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone231
bb_rcgdone231:
  br label %bb_rcslotdone200
bb_rcslotdone200:
  %v722 = load i64, ptr %slot12, align 8
  store i64 %v722, ptr %slot132, align 8
  %v723 = load i64, ptr %slot14, align 8
  store i64 %v723, ptr %slot133, align 8
  %v724 = load i64, ptr %slot133, align 8
  %v725 = load i64, ptr %slot132, align 8
  %p726 = inttoptr i64 %v724 to ptr
  %p727 = inttoptr i64 %v725 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p727, ptr %p726, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v728 = load i64, ptr %slot8, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i32 2, ptr %p729, align 4, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot10, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i32, ptr %p731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld732, ptr %slot134, align 8
  %v733 = load i32, ptr %slot134, align 8
  %v734 = load i64, ptr %slot8, align 8
  %p735 = inttoptr i64 %v734 to ptr
  store i32 %v733, ptr %p735, align 4, !alias.scope !3, !noalias !4
  %v736 = load i64, ptr %slot9, align 8
  %p737 = inttoptr i64 %v736 to ptr
  store i32 0, ptr %p737, align 4, !alias.scope !3, !noalias !4
  %v738 = load i64, ptr %slot7, align 8
  %p739 = inttoptr i64 %v738 to ptr
  store i32 1, ptr %p739, align 4, !alias.scope !3, !noalias !4
  %v740 = load i64, ptr %slot132, align 8
  %p741 = inttoptr i64 %v740 to ptr
  %ld742 = load i64, ptr %p741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld742, ptr %slot135, align 8
  %v743 = load i64, ptr %slot135, align 8
  %v744 = load i64, ptr %slot18, align 8
  %p745 = inttoptr i64 %v744 to ptr
  store i64 %v743, ptr %p745, align 8, !alias.scope !3, !noalias !4
  %v746 = load i64, ptr %slot17, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %ld748 = load i64, ptr %p747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld748, ptr %slot136, align 8
  %v749 = load i64, ptr %slot18, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %ld751 = load i64, ptr %p750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld751, ptr %slot137, align 8
  %v752 = load i64, ptr %slot1, align 8
  %v753 = load i64, ptr %slot136, align 8
  %v754 = load i64, ptr %slot137, align 8
  %call755 = call i64 @myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18(i64 %v752, i64 %v753, i64 %v754) nomerge, !dbg !126
  store i64 %call755, ptr %slot138, align 8
  %v756 = load i64, ptr %slot138, align 8
  %v757 = load i64, ptr %slot17, align 8
  %p758 = inttoptr i64 %v757 to ptr
  store i64 %v756, ptr %p758, align 8, !alias.scope !3, !noalias !4
  %v759 = load i64, ptr %slot5, align 8
  %p760 = inttoptr i64 %v759 to ptr
  %ld761 = load i32, ptr %p760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld761, ptr %slot139, align 8
  %v762 = load i32, ptr %slot139, align 8
  %cv763 = zext i32 %v762 to i64
  %cond764 = icmp ne i64 %cv763, 0
  br i1 %cond764, label %bb_rcslotdrop258, label %bb_rcslotdone258
bb_rcslotdrop258:
  %v765 = load i64, ptr %slot5, align 8
  %p766 = inttoptr i64 %v765 to ptr
  store i32 0, ptr %p766, align 4, !alias.scope !3, !noalias !4
  %v767 = load i64, ptr %slot11, align 8
  store i64 %v767, ptr %slot140, align 8
  %v768 = load i64, ptr %slot6, align 8
  %p769 = inttoptr i64 %v768 to ptr
  %ld770 = load i32, ptr %p769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld770, ptr %slot141, align 8
  %v771 = load i32, ptr %slot141, align 8
  %op772 = and i32 %v771, 28
  store i32 %op772, ptr %slot142, align 8
  %v773 = load i32, ptr %slot142, align 8
  %cv774 = zext i32 %v773 to i64
  %cond775 = icmp ne i64 %cv774, 0
  br i1 %cond775, label %bb_rcslotrole258, label %bb_rcslotowner258
bb_rcslotrole258:
  %v776 = load i64, ptr %slot27, align 8
  store i64 %v776, ptr %slot143, align 8
  %v777 = load i64, ptr %slot143, align 8
  %v778 = load i64, ptr %slot140, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v777, i64 %v778) nomerge, !dbg !126
  br label %bb_rcslotdone258
bb_rcslotowner258:
  %v779 = load i64, ptr %slot27, align 8
  store i64 %v779, ptr %slot144, align 8
  %v780 = load i64, ptr %slot144, align 8
  %v781 = load i64, ptr %slot140, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v780, i64 %v781) nomerge, !dbg !126
  br label %bb_rcslotdone258
bb_rcslotdone258:
  %v782 = load i64, ptr %slot7, align 8
  %p783 = inttoptr i64 %v782 to ptr
  %ld784 = load i32, ptr %p783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld784, ptr %slot145, align 8
  %v785 = load i32, ptr %slot145, align 8
  %cv786 = zext i32 %v785 to i64
  %cond787 = icmp ne i64 %cv786, 0
  br i1 %cond787, label %bb_rcslotdrop267, label %bb_rcslotdone267
bb_rcslotdrop267:
  %v788 = load i64, ptr %slot7, align 8
  %p789 = inttoptr i64 %v788 to ptr
  store i32 0, ptr %p789, align 4, !alias.scope !3, !noalias !4
  %v790 = load i64, ptr %slot12, align 8
  store i64 %v790, ptr %slot146, align 8
  %v791 = load i64, ptr %slot8, align 8
  %p792 = inttoptr i64 %v791 to ptr
  %ld793 = load i32, ptr %p792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld793, ptr %slot147, align 8
  %v794 = load i32, ptr %slot147, align 8
  %op795 = and i32 %v794, 28
  store i32 %op795, ptr %slot148, align 8
  %v796 = load i32, ptr %slot148, align 8
  %cv797 = zext i32 %v796 to i64
  %cond798 = icmp ne i64 %cv797, 0
  br i1 %cond798, label %bb_rcslotrole267, label %bb_rcslotowner267
bb_rcslotrole267:
  %v799 = load i64, ptr %slot27, align 8
  store i64 %v799, ptr %slot149, align 8
  %v800 = load i64, ptr %slot146, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i64, ptr %p801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld802, ptr %slot150, align 8
  %v803 = load i64, ptr %slot150, align 8
  %cmp804 = icmp ne i64 %v803, 0
  %cv805 = zext i1 %cmp804 to i32
  store i32 %cv805, ptr %slot151, align 8
  %v806 = load i32, ptr %slot151, align 8
  %cv807 = zext i32 %v806 to i64
  %cond808 = icmp ne i64 %cv807, 0
  br i1 %cond808, label %bb_rcgnn283, label %bb_rcgdone283
bb_rcgnn283:
  %v809 = load i64, ptr %slot150, align 8
  %op810 = sub i64 %v809, 16
  store i64 %op810, ptr %slot152, align 8
  %v811 = load i64, ptr %slot150, align 8
  %p812 = inttoptr i64 %v811 to ptr
  %rgep813 = getelementptr i8, ptr %p812, i64 -16
  %ld814 = load i64, ptr %rgep813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld814, ptr %slot153, align 8
  %v815 = load i64, ptr %slot153, align 8
  %op816 = and i64 %v815, 4611686018427387906
  store i64 %op816, ptr %slot154, align 8
  %v817 = load i64, ptr %slot154, align 8
  %cmp818 = icmp ne i64 %v817, 0
  %cv819 = zext i1 %cmp818 to i32
  store i32 %cv819, ptr %slot155, align 8
  %v820 = load i32, ptr %slot155, align 8
  %cv821 = zext i32 %v820 to i64
  %cond822 = icmp ne i64 %cv821, 0
  br i1 %cond822, label %bb_rcgclear283, label %bb_rcgcounted283
bb_rcgcounted283:
  %v823 = load i64, ptr %slot150, align 8
  %op824 = sub i64 %v823, 24
  store i64 %op824, ptr %slot156, align 8
  %v825 = load i64, ptr %slot150, align 8
  %p826 = inttoptr i64 %v825 to ptr
  %rgep827 = getelementptr i8, ptr %p826, i64 -24
  %ld828 = load i64, ptr %rgep827, align 8, !alias.scope !9, !noalias !10
  store i64 %ld828, ptr %slot157, align 8
  %v829 = load i64, ptr %slot157, align 8
  %op830 = sub i64 %v829, 1
  store i64 %op830, ptr %slot158, align 8
  %v831 = load i64, ptr %slot158, align 8
  %cmp832 = icmp eq i64 %v831, 0
  %cv833 = zext i1 %cmp832 to i32
  store i32 %cv833, ptr %slot159, align 8
  %v834 = load i32, ptr %slot159, align 8
  %cv835 = zext i32 %v834 to i64
  %cond836 = icmp ne i64 %cv835, 0
  br i1 %cond836, label %bb_rcglast283, label %bb_rcgdec283
bb_rcglast283:
  %v837 = load i64, ptr %slot150, align 8
  %op838 = sub i64 %v837, 32
  store i64 %op838, ptr %slot160, align 8
  %v839 = load i64, ptr %slot150, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %rgep841 = getelementptr i8, ptr %p840, i64 -32
  %ld842 = load i64, ptr %rgep841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld842, ptr %slot161, align 8
  %v843 = load i64, ptr %slot161, align 8
  %cmp844 = icmp ne i64 %v843, 0
  %cv845 = zext i1 %cmp844 to i32
  store i32 %cv845, ptr %slot162, align 8
  %v846 = load i32, ptr %slot162, align 8
  %cv847 = zext i32 %v846 to i64
  %cond848 = icmp ne i64 %cv847, 0
  br i1 %cond848, label %bb_rcgdec283, label %bb_rcgslow283
bb_rcgslow283:
  %v849 = load i64, ptr %slot149, align 8
  %v850 = load i64, ptr %slot146, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v849, i64 %v850) nomerge, !dbg !126
  br label %bb_rcgdone283
bb_rcgdec283:
  %v851 = load i64, ptr %slot158, align 8
  %v852 = load i64, ptr %slot150, align 8
  %p853 = inttoptr i64 %v852 to ptr
  %rgep854 = getelementptr i8, ptr %p853, i64 -24
  store i64 %v851, ptr %rgep854, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear283
bb_rcgclear283:
  %v855 = load i64, ptr %slot146, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i64 0, ptr %p856, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone283
bb_rcgdone283:
  br label %bb_rcslotdone267
bb_rcslotowner267:
  %v857 = load i64, ptr %slot27, align 8
  store i64 %v857, ptr %slot163, align 8
  %v858 = load i64, ptr %slot146, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %ld860 = load i64, ptr %p859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld860, ptr %slot164, align 8
  %v861 = load i64, ptr %slot164, align 8
  %cmp862 = icmp ne i64 %v861, 0
  %cv863 = zext i1 %cmp862 to i32
  store i32 %cv863, ptr %slot165, align 8
  %v864 = load i32, ptr %slot165, align 8
  %cv865 = zext i32 %v864 to i64
  %cond866 = icmp ne i64 %cv865, 0
  br i1 %cond866, label %bb_rcgnn298, label %bb_rcgdone298
bb_rcgnn298:
  %v867 = load i64, ptr %slot164, align 8
  %op868 = sub i64 %v867, 16
  store i64 %op868, ptr %slot166, align 8
  %v869 = load i64, ptr %slot164, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %rgep871 = getelementptr i8, ptr %p870, i64 -16
  %ld872 = load i64, ptr %rgep871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld872, ptr %slot167, align 8
  %v873 = load i64, ptr %slot167, align 8
  %op874 = and i64 %v873, 4611686018427387906
  store i64 %op874, ptr %slot168, align 8
  %v875 = load i64, ptr %slot168, align 8
  %cmp876 = icmp ne i64 %v875, 0
  %cv877 = zext i1 %cmp876 to i32
  store i32 %cv877, ptr %slot169, align 8
  %v878 = load i32, ptr %slot169, align 8
  %cv879 = zext i32 %v878 to i64
  %cond880 = icmp ne i64 %cv879, 0
  br i1 %cond880, label %bb_rcgclear298, label %bb_rcgcounted298
bb_rcgcounted298:
  %v881 = load i64, ptr %slot164, align 8
  %op882 = sub i64 %v881, 32
  store i64 %op882, ptr %slot170, align 8
  %v883 = load i64, ptr %slot164, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %rgep885 = getelementptr i8, ptr %p884, i64 -32
  %ld886 = load i64, ptr %rgep885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld886, ptr %slot171, align 8
  %v887 = load i64, ptr %slot171, align 8
  %op888 = sub i64 %v887, 1
  store i64 %op888, ptr %slot172, align 8
  %v889 = load i64, ptr %slot172, align 8
  %cmp890 = icmp eq i64 %v889, 0
  %cv891 = zext i1 %cmp890 to i32
  store i32 %cv891, ptr %slot173, align 8
  %v892 = load i32, ptr %slot173, align 8
  %cv893 = zext i32 %v892 to i64
  %cond894 = icmp ne i64 %cv893, 0
  br i1 %cond894, label %bb_rcglast298, label %bb_rcgdec298
bb_rcglast298:
  %v895 = load i64, ptr %slot164, align 8
  %op896 = sub i64 %v895, 24
  store i64 %op896, ptr %slot174, align 8
  %v897 = load i64, ptr %slot164, align 8
  %p898 = inttoptr i64 %v897 to ptr
  %rgep899 = getelementptr i8, ptr %p898, i64 -24
  %ld900 = load i64, ptr %rgep899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld900, ptr %slot175, align 8
  %v901 = load i64, ptr %slot175, align 8
  %cmp902 = icmp ne i64 %v901, 0
  %cv903 = zext i1 %cmp902 to i32
  store i32 %cv903, ptr %slot176, align 8
  %v904 = load i32, ptr %slot176, align 8
  %cv905 = zext i32 %v904 to i64
  %cond906 = icmp ne i64 %cv905, 0
  br i1 %cond906, label %bb_rcgdec298, label %bb_rcgslow298
bb_rcgslow298:
  %v907 = load i64, ptr %slot163, align 8
  %v908 = load i64, ptr %slot146, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v907, i64 %v908) nomerge, !dbg !126
  br label %bb_rcgdone298
bb_rcgdec298:
  %v909 = load i64, ptr %slot172, align 8
  %v910 = load i64, ptr %slot164, align 8
  %p911 = inttoptr i64 %v910 to ptr
  %rgep912 = getelementptr i8, ptr %p911, i64 -32
  store i64 %v909, ptr %rgep912, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear298
bb_rcgclear298:
  %v913 = load i64, ptr %slot146, align 8
  %p914 = inttoptr i64 %v913 to ptr
  store i64 0, ptr %p914, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone298
bb_rcgdone298:
  br label %bb_rcslotdone267
bb_rcslotdone267:
  %v915 = load i64, ptr %slot17, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %ld917 = load i64, ptr %p916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld917, ptr %slot177, align 8
  %v918 = load i64, ptr %slot5, align 8
  %p919 = inttoptr i64 %v918 to ptr
  %ld920 = load i32, ptr %p919, align 4, !alias.scope !3, !noalias !4
  store i32 %ld920, ptr %slot178, align 8
  %v921 = load i32, ptr %slot178, align 8
  %cv922 = zext i32 %v921 to i64
  %cond923 = icmp ne i64 %cv922, 0
  br i1 %cond923, label %bb_rcslotdrop305, label %bb_rcslotdone305
bb_rcslotdrop305:
  %v924 = load i64, ptr %slot5, align 8
  %p925 = inttoptr i64 %v924 to ptr
  store i32 0, ptr %p925, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone305
bb_rcslotdone305:
  %v926 = load i64, ptr %slot177, align 8
  ret i64 %v926
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64, i64, i64, i64)
declare i64 @myl_f_23e1bebda3014162640000246e37fa23a2bbf174be368d790fda65af887cf148(i64, i64)
declare void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8, i64, i64)
declare i64 @myl_f_965f856661cc748509663eb198e40efe7122dbf3a3aa8f9715e477a659f7ab18(i64, i64, i64)
declare i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76", linkageName: "myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 6481047454939993917, i64 0, !"myl_f_18638e29db01ff1300173e3619a0c03ebc433395c0cee38337c8ba05552f6f76"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!120 = !DILocation(line: 11, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!122 = !DILocation(line: 19, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!124 = !DILocation(line: 22, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
