target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc(ptr sret([32 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v138 = load i64, ptr %slot1, align 8
  %op139 = add i64 %v138, 32
  store i64 %op139, ptr %slot3, align 8
  %mem140 = alloca i8, i64 32, align 8
  %ptr141 = ptrtoint ptr %mem140 to i64
  store i64 %ptr141, ptr %slot4, align 8
  %mem142 = alloca i8, i64 8, align 8
  %ptr143 = ptrtoint ptr %mem142 to i64
  store i64 %ptr143, ptr %slot5, align 8
  %mem144 = alloca i8, i64 8, align 8
  %ptr145 = ptrtoint ptr %mem144 to i64
  store i64 %ptr145, ptr %slot6, align 8
  %mem146 = alloca i8, i64 8, align 8
  %ptr147 = ptrtoint ptr %mem146 to i64
  store i64 %ptr147, ptr %slot7, align 8
  %mem148 = alloca i8, i64 8, align 8
  %ptr149 = ptrtoint ptr %mem148 to i64
  store i64 %ptr149, ptr %slot8, align 8
  %mem150 = alloca i8, i64 32, align 8
  %ptr151 = ptrtoint ptr %mem150 to i64
  store i64 %ptr151, ptr %slot9, align 8
  %mem152 = alloca i8, i64 8, align 8
  %ptr153 = ptrtoint ptr %mem152 to i64
  store i64 %ptr153, ptr %slot10, align 8
  %mem154 = alloca i8, i64 32, align 8
  %ptr155 = ptrtoint ptr %mem154 to i64
  store i64 %ptr155, ptr %slot11, align 8
  %mem156 = alloca i8, i64 8, align 8
  %ptr157 = ptrtoint ptr %mem156 to i64
  store i64 %ptr157, ptr %slot12, align 8
  %mem158 = alloca i8, i64 8, align 8
  %ptr159 = ptrtoint ptr %mem158 to i64
  store i64 %ptr159, ptr %slot13, align 8
  %mem160 = alloca i8, i64 8, align 8
  %ptr161 = ptrtoint ptr %mem160 to i64
  store i64 %ptr161, ptr %slot14, align 8
  %mem162 = alloca i8, i64 8, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot15, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot16, align 8
  %mem166 = alloca i8, i64 32, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot17, align 8
  %v168 = load i64, ptr %slot2, align 8
  %v169 = load i64, ptr %slot12, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i64 %v168, ptr %p170, align 8, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot1, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %call173 = call ptr @myl_qbe_heap(ptr %p172) nomerge, !dbg !110
  %calladdr174 = ptrtoint ptr %call173 to i64
  store i64 %calladdr174, ptr %slot18, align 8
  %v175 = load i64, ptr %slot1, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %call177 = call i64 @myl_qbe_region_mark(ptr %p176) nomerge, !dbg !110
  store i64 %call177, ptr %slot19, align 8
  %v178 = load i64, ptr %slot5, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i32 0, ptr %p179, align 4, !alias.scope !3, !noalias !4
  %v180 = load i64, ptr %slot6, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i32 0, ptr %p181, align 4, !alias.scope !3, !noalias !4
  %v182 = load i64, ptr %slot7, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i32 0, ptr %p183, align 4, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot8, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i32 0, ptr %p185, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v186 = load i64, ptr %slot12, align 8
  %p187 = inttoptr i64 %v186 to ptr
  %ld188 = load i64, ptr %p187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld188, ptr %slot20, align 8
  %v189 = load i64, ptr %slot20, align 8
  %v190 = load i64, ptr %slot13, align 8
  %p191 = inttoptr i64 %v190 to ptr
  store i64 %v189, ptr %p191, align 8, !alias.scope !3, !noalias !4
  %v192 = load i64, ptr %slot14, align 8
  %p193 = inttoptr i64 %v192 to ptr
  store i64 0, ptr %p193, align 8, !alias.scope !3, !noalias !4
  %v194 = load i64, ptr %slot15, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 0, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot16, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 1, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot17, align 8
  store i64 %v198, ptr %slot21, align 8
  %v199 = load i64, ptr %slot21, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 0, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot21, align 8
  %p203 = inttoptr i64 %v201 to ptr
  %gep204 = getelementptr i8, ptr %p203, i64 8
  %op202 = ptrtoint ptr %gep204 to i64
  store i64 %op202, ptr %slot22, align 8
  %v205 = load i64, ptr %slot22, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i64 0, ptr %p206, align 8, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot21, align 8
  %p209 = inttoptr i64 %v207 to ptr
  %gep210 = getelementptr i8, ptr %p209, i64 16
  %op208 = ptrtoint ptr %gep210 to i64
  store i64 %op208, ptr %slot23, align 8
  %v211 = load i64, ptr %slot23, align 8
  %p212 = inttoptr i64 %v211 to ptr
  store i64 0, ptr %p212, align 8, !alias.scope !3, !noalias !4
  %v213 = load i64, ptr %slot21, align 8
  %p215 = inttoptr i64 %v213 to ptr
  %gep216 = getelementptr i8, ptr %p215, i64 24
  %op214 = ptrtoint ptr %gep216 to i64
  store i64 %op214, ptr %slot24, align 8
  %v217 = load i64, ptr %slot24, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 0, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot8, align 8
  %p220 = inttoptr i64 %v219 to ptr
  store i32 1, ptr %p220, align 4, !alias.scope !3, !noalias !4
  %v221 = load i64, ptr %slot19, align 8
  store i64 %v221, ptr %slot25, align 8
  %v222 = load i64, ptr %slot13, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %ld224 = load i64, ptr %p223, align 8, !alias.scope !3, !noalias !4
  store i64 %ld224, ptr %slot26, align 8
  %v225 = load i64, ptr %slot26, align 8
  %v226 = load i64, ptr %slot10, align 8
  %p227 = inttoptr i64 %v226 to ptr
  store i64 %v225, ptr %p227, align 8, !alias.scope !3, !noalias !4
  %v228 = load i64, ptr %slot10, align 8
  store i64 %v228, ptr %slot27, align 8
  %v229 = load i64, ptr %slot21, align 8
  %p231 = inttoptr i64 %v229 to ptr
  %gep232 = getelementptr i8, ptr %p231, i64 0
  %op230 = ptrtoint ptr %gep232 to i64
  store i64 %op230, ptr %slot28, align 8
  %v233 = load i64, ptr %slot13, align 8
  %p234 = inttoptr i64 %v233 to ptr
  %ld235 = load i64, ptr %p234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld235, ptr %slot29, align 8
  %v236 = load i64, ptr %slot29, align 8
  %v237 = load i64, ptr %slot10, align 8
  %p238 = inttoptr i64 %v237 to ptr
  store i64 %v236, ptr %p238, align 8, !alias.scope !3, !noalias !4
  %v239 = load i64, ptr %slot10, align 8
  store i64 %v239, ptr %slot30, align 8
  %v240 = load i64, ptr %slot5, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i32, ptr %p241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld242, ptr %slot31, align 8
  %v243 = load i64, ptr %slot6, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i32, ptr %p244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld245, ptr %slot32, align 8
  %v246 = load i32, ptr %slot32, align 8
  %op247 = and i32 %v246, 24
  store i32 %op247, ptr %slot32, align 8
  %v248 = load i32, ptr %slot32, align 8
  %cmp249 = icmp eq i32 %v248, 0
  %cv250 = zext i1 %cmp249 to i32
  store i32 %cv250, ptr %slot33, align 8
  %v251 = load i32, ptr %slot31, align 8
  %v252 = load i32, ptr %slot33, align 8
  %op253 = and i32 %v251, %v252
  store i32 %op253, ptr %slot34, align 8
  %v254 = load i32, ptr %slot34, align 8
  %cv255 = zext i32 %v254 to i64
  %cond256 = icmp ne i64 %cv255, 0
  br i1 %cond256, label %bb_rctake14, label %bb_rccopy14
bb_rctake14:
  %v257 = load i64, ptr %slot11, align 8
  store i64 %v257, ptr %slot35, align 8
  %v258 = load i64, ptr %slot19, align 8
  store i64 %v258, ptr %slot36, align 8
  %v259 = load i64, ptr %slot30, align 8
  %v260 = load i64, ptr %slot35, align 8
  %op261 = sub i64 %v259, %v260
  store i64 %op261, ptr %slot37, align 8
  %v262 = load i64, ptr %slot35, align 8
  %v263 = load i64, ptr %slot30, align 8
  %op264 = sub i64 %v262, %v263
  store i64 %op264, ptr %slot38, align 8
  %v265 = load i64, ptr %slot37, align 8
  %cmp266 = icmp ult i64 %v265, 8
  %cv267 = zext i1 %cmp266 to i32
  store i32 %cv267, ptr %slot39, align 8
  %v268 = load i64, ptr %slot38, align 8
  %cmp269 = icmp ult i64 %v268, 8
  %cv270 = zext i1 %cmp269 to i32
  store i32 %cv270, ptr %slot40, align 8
  %v271 = load i32, ptr %slot39, align 8
  %v272 = load i32, ptr %slot40, align 8
  %op273 = or i32 %v271, %v272
  store i32 %op273, ptr %slot41, align 8
  %v274 = load i32, ptr %slot41, align 8
  %cv275 = zext i32 %v274 to i64
  %cond276 = icmp ne i64 %cv275, 0
  br i1 %cond276, label %bb_rcmoveslow23, label %bb_rcmovecheck23
bb_rcmovecheck23:
  %v277 = load i64, ptr %slot30, align 8
  %p279 = inttoptr i64 %v277 to ptr
  %gep280 = getelementptr i8, ptr %p279, i64 0
  %op278 = ptrtoint ptr %gep280 to i64
  store i64 %op278, ptr %slot42, align 8
  %v281 = load i64, ptr %slot42, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld283, ptr %slot43, align 8
  %v284 = load i64, ptr %slot43, align 8
  %cmp285 = icmp ne i64 %v284, 0
  %cv286 = zext i1 %cmp285 to i32
  store i32 %cv286, ptr %slot44, align 8
  %v287 = load i32, ptr %slot44, align 8
  %cv288 = zext i32 %v287 to i64
  %cond289 = icmp ne i64 %cv288, 0
  br i1 %cond289, label %bb_rcmoveheader31, label %bb_rcmovenext31
bb_rcmoveheader31:
  %v290 = load i64, ptr %slot43, align 8
  %op291 = sub i64 %v290, 16
  store i64 %op291, ptr %slot45, align 8
  %v292 = load i64, ptr %slot43, align 8
  %p293 = inttoptr i64 %v292 to ptr
  %rgep294 = getelementptr i8, ptr %p293, i64 -16
  %ld295 = load i64, ptr %rgep294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld295, ptr %slot46, align 8
  %v296 = load i64, ptr %slot46, align 8
  %op297 = and i64 %v296, 5764607523034234881
  store i64 %op297, ptr %slot47, align 8
  %v298 = load i64, ptr %slot47, align 8
  %cmp299 = icmp ne i64 %v298, 0
  %cv300 = zext i1 %cmp299 to i32
  store i32 %cv300, ptr %slot48, align 8
  %v301 = load i32, ptr %slot48, align 8
  %cv302 = zext i32 %v301 to i64
  %cond303 = icmp ne i64 %cv302, 0
  br i1 %cond303, label %bb_rcmoveslow23, label %bb_rcmovenext31
bb_rcmovenext31:
  %v304 = load i64, ptr %slot30, align 8
  %v305 = load i64, ptr %slot35, align 8
  %p306 = inttoptr i64 %v304 to ptr
  %p307 = inttoptr i64 %v305 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p307, ptr %p306, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v308 = load i64, ptr %slot30, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 0, ptr %p309, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved23
bb_rcmoveslow23:
  %v310 = load i64, ptr %slot18, align 8
  %v311 = load i64, ptr %slot35, align 8
  %v312 = load i64, ptr %slot30, align 8
  %v313 = load i64, ptr %slot36, align 8
  %cv314 = trunc i64 %v313 to i32
  %call315 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v310, i64 %v311, i64 %v312, i32 %cv314) nomerge, !dbg !112
  store i32 %call315, ptr %slot49, align 8
  %v316 = load i32, ptr %slot49, align 8
  %cv317 = zext i32 %v316 to i64
  %cond318 = icmp ne i64 %cv317, 0
  br i1 %cond318, label %bb_rcsuccess38, label %bb_rcfailure38
bb_rcfailure38:
  %v319 = load i64, ptr %slot18, align 8
  %p320 = inttoptr i64 %v319 to ptr
  %call321 = call i32 @myl_rc_take_failure(ptr %p320) nomerge, !dbg !112
  store i32 %call321, ptr %slot50, align 8
  %v322 = load i64, ptr %slot1, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %v324 = load i32, ptr %slot50, align 8
  %call325 = call i32 @myl_qbe_rc_status(ptr %p323, i32 %v324) nomerge, !dbg !112
  store i32 %call325, ptr %slot51, align 8
  br label %bb_failure
bb_rcsuccess38:
  br label %bb_rcmoved23
bb_rcmoved23:
  %v326 = load i64, ptr %slot5, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i32 0, ptr %p327, align 4, !alias.scope !3, !noalias !4
  %v328 = load i64, ptr %slot7, align 8
  %p329 = inttoptr i64 %v328 to ptr
  store i32 1, ptr %p329, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared14
bb_rccopy14:
  %v330 = load i64, ptr %slot11, align 8
  store i64 %v330, ptr %slot52, align 8
  %v331 = load i64, ptr %slot19, align 8
  store i64 %v331, ptr %slot53, align 8
  %v332 = load i64, ptr %slot30, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %ld334 = load i64, ptr %p333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld334, ptr %slot54, align 8
  %v335 = load i64, ptr %slot54, align 8
  %cmp336 = icmp ne i64 %v335, 0
  %cv337 = zext i1 %cmp336 to i32
  store i32 %cv337, ptr %slot55, align 8
  %v338 = load i32, ptr %slot55, align 8
  %cv339 = zext i32 %v338 to i64
  %cond340 = icmp ne i64 %cv339, 0
  br i1 %cond340, label %bb_rcgnn47, label %bb_rcgplain47
bb_rcgnn47:
  %v341 = load i64, ptr %slot54, align 8
  %op342 = sub i64 %v341, 16
  store i64 %op342, ptr %slot56, align 8
  %v343 = load i64, ptr %slot54, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %rgep345 = getelementptr i8, ptr %p344, i64 -16
  %ld346 = load i64, ptr %rgep345, align 8, !alias.scope !9, !noalias !10
  store i64 %ld346, ptr %slot57, align 8
  %v347 = load i64, ptr %slot57, align 8
  %op348 = and i64 %v347, 4611686018427387906
  store i64 %op348, ptr %slot58, align 8
  %v349 = load i64, ptr %slot58, align 8
  %cmp350 = icmp ne i64 %v349, 0
  %cv351 = zext i1 %cmp350 to i32
  store i32 %cv351, ptr %slot59, align 8
  %v352 = load i32, ptr %slot59, align 8
  %cv353 = zext i32 %v352 to i64
  %cond354 = icmp ne i64 %cv353, 0
  br i1 %cond354, label %bb_rcgspecial47, label %bb_rcginc47
bb_rcginc47:
  %v355 = load i64, ptr %slot54, align 8
  %op356 = sub i64 %v355, 32
  store i64 %op356, ptr %slot60, align 8
  %v357 = load i64, ptr %slot54, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %rgep359 = getelementptr i8, ptr %p358, i64 -32
  %ld360 = load i64, ptr %rgep359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld360, ptr %slot61, align 8
  %v361 = load i64, ptr %slot61, align 8
  %op362 = add i64 %v361, 1
  store i64 %op362, ptr %slot62, align 8
  %v363 = load i64, ptr %slot62, align 8
  %cmp364 = icmp eq i64 %v363, 0
  %cv365 = zext i1 %cmp364 to i32
  store i32 %cv365, ptr %slot63, align 8
  %v366 = load i32, ptr %slot63, align 8
  %cv367 = zext i32 %v366 to i64
  %cond368 = icmp ne i64 %cv367, 0
  br i1 %cond368, label %bb_rcglimit47, label %bb_rcgcapacity47
bb_rcglimit47:
  %v369 = load i64, ptr %slot1, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %call371 = call i32 @myl_qbe_rc_status(ptr %p370, i32 2) nomerge, !dbg !112
  store i32 %call371, ptr %slot64, align 8
  br label %bb_failure
bb_rcgcapacity47:
  %v372 = load i64, ptr %slot62, align 8
  %v373 = load i64, ptr %slot54, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %rgep375 = getelementptr i8, ptr %p374, i64 -32
  store i64 %v372, ptr %rgep375, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain47
bb_rcgspecial47:
  %v376 = load i64, ptr %slot57, align 8
  %op377 = and i64 %v376, 4611686018427387904
  store i64 %op377, ptr %slot65, align 8
  %v378 = load i64, ptr %slot65, align 8
  %cmp379 = icmp ne i64 %v378, 0
  %cv380 = zext i1 %cmp379 to i32
  store i32 %cv380, ptr %slot66, align 8
  %v381 = load i32, ptr %slot66, align 8
  %cv382 = zext i32 %v381 to i64
  %cond383 = icmp ne i64 %cv382, 0
  br i1 %cond383, label %bb_rcgslow47, label %bb_rcgplain47
bb_rcgslow47:
  %v384 = load i64, ptr %slot18, align 8
  %v385 = load i64, ptr %slot52, align 8
  %v386 = load i64, ptr %slot30, align 8
  %v387 = load i64, ptr %slot53, align 8
  %cv388 = trunc i64 %v387 to i32
  %call389 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v384, i64 %v385, i64 %v386, i32 %cv388) nomerge, !dbg !112
  store i32 %call389, ptr %slot67, align 8
  %v390 = load i32, ptr %slot67, align 8
  %cv391 = zext i32 %v390 to i64
  %cond392 = icmp ne i64 %cv391, 0
  br i1 %cond392, label %bb_rcsuccess61, label %bb_rcfailure61
bb_rcfailure61:
  %v393 = load i64, ptr %slot18, align 8
  %p394 = inttoptr i64 %v393 to ptr
  %call395 = call i32 @myl_rc_take_failure(ptr %p394) nomerge, !dbg !112
  store i32 %call395, ptr %slot68, align 8
  %v396 = load i64, ptr %slot1, align 8
  %p397 = inttoptr i64 %v396 to ptr
  %v398 = load i32, ptr %slot68, align 8
  %call399 = call i32 @myl_qbe_rc_status(ptr %p397, i32 %v398) nomerge, !dbg !112
  store i32 %call399, ptr %slot69, align 8
  br label %bb_failure
bb_rcsuccess61:
  br label %bb_rcgdone47
bb_rcgplain47:
  %v400 = load i64, ptr %slot54, align 8
  %v401 = load i64, ptr %slot52, align 8
  %p402 = inttoptr i64 %v401 to ptr
  store i64 %v400, ptr %p402, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone47
bb_rcgdone47:
  %v403 = load i64, ptr %slot7, align 8
  %p404 = inttoptr i64 %v403 to ptr
  store i32 1, ptr %p404, align 4, !alias.scope !3, !noalias !4
  %v405 = load i64, ptr %slot5, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i32, ptr %p406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld407, ptr %slot70, align 8
  %v408 = load i32, ptr %slot70, align 8
  %cv409 = zext i32 %v408 to i64
  %cond410 = icmp ne i64 %cv409, 0
  br i1 %cond410, label %bb_rcslotdrop68, label %bb_rcslotdone68
bb_rcslotdrop68:
  %v411 = load i64, ptr %slot5, align 8
  %p412 = inttoptr i64 %v411 to ptr
  store i32 0, ptr %p412, align 4, !alias.scope !3, !noalias !4
  %v413 = load i64, ptr %slot9, align 8
  store i64 %v413, ptr %slot71, align 8
  %v414 = load i64, ptr %slot6, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i32, ptr %p415, align 4, !alias.scope !3, !noalias !4
  store i32 %ld416, ptr %slot72, align 8
  %v417 = load i32, ptr %slot72, align 8
  %op418 = and i32 %v417, 28
  store i32 %op418, ptr %slot73, align 8
  %v419 = load i32, ptr %slot73, align 8
  %cv420 = zext i32 %v419 to i64
  %cond421 = icmp ne i64 %cv420, 0
  br i1 %cond421, label %bb_rcslotrole68, label %bb_rcslotowner68
bb_rcslotrole68:
  %v422 = load i64, ptr %slot18, align 8
  store i64 %v422, ptr %slot74, align 8
  %v423 = load i64, ptr %slot71, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot75, align 8
  %v426 = load i64, ptr %slot75, align 8
  %cmp427 = icmp ne i64 %v426, 0
  %cv428 = zext i1 %cmp427 to i32
  store i32 %cv428, ptr %slot76, align 8
  %v429 = load i32, ptr %slot76, align 8
  %cv430 = zext i32 %v429 to i64
  %cond431 = icmp ne i64 %cv430, 0
  br i1 %cond431, label %bb_rcgnn84, label %bb_rcgdone84
bb_rcgnn84:
  %v432 = load i64, ptr %slot75, align 8
  %op433 = sub i64 %v432, 16
  store i64 %op433, ptr %slot77, align 8
  %v434 = load i64, ptr %slot75, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %rgep436 = getelementptr i8, ptr %p435, i64 -16
  %ld437 = load i64, ptr %rgep436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld437, ptr %slot78, align 8
  %v438 = load i64, ptr %slot78, align 8
  %op439 = and i64 %v438, 4611686018427387906
  store i64 %op439, ptr %slot79, align 8
  %v440 = load i64, ptr %slot79, align 8
  %cmp441 = icmp ne i64 %v440, 0
  %cv442 = zext i1 %cmp441 to i32
  store i32 %cv442, ptr %slot80, align 8
  %v443 = load i32, ptr %slot80, align 8
  %cv444 = zext i32 %v443 to i64
  %cond445 = icmp ne i64 %cv444, 0
  br i1 %cond445, label %bb_rcgclear84, label %bb_rcgcounted84
bb_rcgcounted84:
  %v446 = load i64, ptr %slot75, align 8
  %op447 = sub i64 %v446, 24
  store i64 %op447, ptr %slot81, align 8
  %v448 = load i64, ptr %slot75, align 8
  %p449 = inttoptr i64 %v448 to ptr
  %rgep450 = getelementptr i8, ptr %p449, i64 -24
  %ld451 = load i64, ptr %rgep450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld451, ptr %slot82, align 8
  %v452 = load i64, ptr %slot82, align 8
  %op453 = sub i64 %v452, 1
  store i64 %op453, ptr %slot83, align 8
  %v454 = load i64, ptr %slot83, align 8
  %cmp455 = icmp eq i64 %v454, 0
  %cv456 = zext i1 %cmp455 to i32
  store i32 %cv456, ptr %slot84, align 8
  %v457 = load i32, ptr %slot84, align 8
  %cv458 = zext i32 %v457 to i64
  %cond459 = icmp ne i64 %cv458, 0
  br i1 %cond459, label %bb_rcglast84, label %bb_rcgdec84
bb_rcglast84:
  %v460 = load i64, ptr %slot75, align 8
  %op461 = sub i64 %v460, 32
  store i64 %op461, ptr %slot85, align 8
  %v462 = load i64, ptr %slot75, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %rgep464 = getelementptr i8, ptr %p463, i64 -32
  %ld465 = load i64, ptr %rgep464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld465, ptr %slot86, align 8
  %v466 = load i64, ptr %slot86, align 8
  %cmp467 = icmp ne i64 %v466, 0
  %cv468 = zext i1 %cmp467 to i32
  store i32 %cv468, ptr %slot87, align 8
  %v469 = load i32, ptr %slot87, align 8
  %cv470 = zext i32 %v469 to i64
  %cond471 = icmp ne i64 %cv470, 0
  br i1 %cond471, label %bb_rcgdec84, label %bb_rcgslow84
bb_rcgslow84:
  %v472 = load i64, ptr %slot74, align 8
  %v473 = load i64, ptr %slot71, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v472, i64 %v473) nomerge, !dbg !112
  br label %bb_rcgdone84
bb_rcgdec84:
  %v474 = load i64, ptr %slot83, align 8
  %v475 = load i64, ptr %slot75, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %rgep477 = getelementptr i8, ptr %p476, i64 -24
  store i64 %v474, ptr %rgep477, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear84
bb_rcgclear84:
  %v478 = load i64, ptr %slot71, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i64 0, ptr %p479, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone84
bb_rcgdone84:
  br label %bb_rcslotdone68
bb_rcslotowner68:
  %v480 = load i64, ptr %slot18, align 8
  store i64 %v480, ptr %slot88, align 8
  %v481 = load i64, ptr %slot71, align 8
  %p482 = inttoptr i64 %v481 to ptr
  %ld483 = load i64, ptr %p482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld483, ptr %slot89, align 8
  %v484 = load i64, ptr %slot89, align 8
  %cmp485 = icmp ne i64 %v484, 0
  %cv486 = zext i1 %cmp485 to i32
  store i32 %cv486, ptr %slot90, align 8
  %v487 = load i32, ptr %slot90, align 8
  %cv488 = zext i32 %v487 to i64
  %cond489 = icmp ne i64 %cv488, 0
  br i1 %cond489, label %bb_rcgnn99, label %bb_rcgdone99
bb_rcgnn99:
  %v490 = load i64, ptr %slot89, align 8
  %op491 = sub i64 %v490, 16
  store i64 %op491, ptr %slot91, align 8
  %v492 = load i64, ptr %slot89, align 8
  %p493 = inttoptr i64 %v492 to ptr
  %rgep494 = getelementptr i8, ptr %p493, i64 -16
  %ld495 = load i64, ptr %rgep494, align 8, !alias.scope !9, !noalias !10
  store i64 %ld495, ptr %slot92, align 8
  %v496 = load i64, ptr %slot92, align 8
  %op497 = and i64 %v496, 4611686018427387906
  store i64 %op497, ptr %slot93, align 8
  %v498 = load i64, ptr %slot93, align 8
  %cmp499 = icmp ne i64 %v498, 0
  %cv500 = zext i1 %cmp499 to i32
  store i32 %cv500, ptr %slot94, align 8
  %v501 = load i32, ptr %slot94, align 8
  %cv502 = zext i32 %v501 to i64
  %cond503 = icmp ne i64 %cv502, 0
  br i1 %cond503, label %bb_rcgclear99, label %bb_rcgcounted99
bb_rcgcounted99:
  %v504 = load i64, ptr %slot89, align 8
  %op505 = sub i64 %v504, 32
  store i64 %op505, ptr %slot95, align 8
  %v506 = load i64, ptr %slot89, align 8
  %p507 = inttoptr i64 %v506 to ptr
  %rgep508 = getelementptr i8, ptr %p507, i64 -32
  %ld509 = load i64, ptr %rgep508, align 8, !alias.scope !9, !noalias !10
  store i64 %ld509, ptr %slot96, align 8
  %v510 = load i64, ptr %slot96, align 8
  %op511 = sub i64 %v510, 1
  store i64 %op511, ptr %slot97, align 8
  %v512 = load i64, ptr %slot97, align 8
  %cmp513 = icmp eq i64 %v512, 0
  %cv514 = zext i1 %cmp513 to i32
  store i32 %cv514, ptr %slot98, align 8
  %v515 = load i32, ptr %slot98, align 8
  %cv516 = zext i32 %v515 to i64
  %cond517 = icmp ne i64 %cv516, 0
  br i1 %cond517, label %bb_rcglast99, label %bb_rcgdec99
bb_rcglast99:
  %v518 = load i64, ptr %slot89, align 8
  %op519 = sub i64 %v518, 24
  store i64 %op519, ptr %slot99, align 8
  %v520 = load i64, ptr %slot89, align 8
  %p521 = inttoptr i64 %v520 to ptr
  %rgep522 = getelementptr i8, ptr %p521, i64 -24
  %ld523 = load i64, ptr %rgep522, align 8, !alias.scope !9, !noalias !10
  store i64 %ld523, ptr %slot100, align 8
  %v524 = load i64, ptr %slot100, align 8
  %cmp525 = icmp ne i64 %v524, 0
  %cv526 = zext i1 %cmp525 to i32
  store i32 %cv526, ptr %slot101, align 8
  %v527 = load i32, ptr %slot101, align 8
  %cv528 = zext i32 %v527 to i64
  %cond529 = icmp ne i64 %cv528, 0
  br i1 %cond529, label %bb_rcgdec99, label %bb_rcgslow99
bb_rcgslow99:
  %v530 = load i64, ptr %slot88, align 8
  %v531 = load i64, ptr %slot71, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v530, i64 %v531) nomerge, !dbg !112
  br label %bb_rcgdone99
bb_rcgdec99:
  %v532 = load i64, ptr %slot97, align 8
  %v533 = load i64, ptr %slot89, align 8
  %p534 = inttoptr i64 %v533 to ptr
  %rgep535 = getelementptr i8, ptr %p534, i64 -32
  store i64 %v532, ptr %rgep535, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear99
bb_rcgclear99:
  %v536 = load i64, ptr %slot71, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i64 0, ptr %p537, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone99
bb_rcgdone99:
  br label %bb_rcslotdone68
bb_rcslotdone68:
  br label %bb_rcprepared14
bb_rcprepared14:
  %v538 = load i64, ptr %slot11, align 8
  store i64 %v538, ptr %slot102, align 8
  %v539 = load i64, ptr %slot102, align 8
  %v540 = load i64, ptr %slot28, align 8
  %p541 = inttoptr i64 %v539 to ptr
  %p542 = inttoptr i64 %v540 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p542, ptr %p541, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v543 = load i64, ptr %slot7, align 8
  %p544 = inttoptr i64 %v543 to ptr
  store i32 0, ptr %p544, align 4, !alias.scope !3, !noalias !4
  %v545 = load i64, ptr %slot14, align 8
  store i64 %v545, ptr %slot103, align 8
  %v546 = load i64, ptr %slot21, align 8
  %p548 = inttoptr i64 %v546 to ptr
  %gep549 = getelementptr i8, ptr %p548, i64 8
  %op547 = ptrtoint ptr %gep549 to i64
  store i64 %op547, ptr %slot104, align 8
  %v550 = load i64, ptr %slot103, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot105, align 8
  %v553 = load i64, ptr %slot105, align 8
  %v554 = load i64, ptr %slot104, align 8
  %p555 = inttoptr i64 %v554 to ptr
  store i64 %v553, ptr %p555, align 8, !alias.scope !3, !noalias !4
  %v556 = load i64, ptr %slot15, align 8
  store i64 %v556, ptr %slot106, align 8
  %v557 = load i64, ptr %slot21, align 8
  %p559 = inttoptr i64 %v557 to ptr
  %gep560 = getelementptr i8, ptr %p559, i64 16
  %op558 = ptrtoint ptr %gep560 to i64
  store i64 %op558, ptr %slot107, align 8
  %v561 = load i64, ptr %slot106, align 8
  %p562 = inttoptr i64 %v561 to ptr
  %ld563 = load i64, ptr %p562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld563, ptr %slot108, align 8
  %v564 = load i64, ptr %slot108, align 8
  %v565 = load i64, ptr %slot107, align 8
  %p566 = inttoptr i64 %v565 to ptr
  store i64 %v564, ptr %p566, align 8, !alias.scope !3, !noalias !4
  %v567 = load i64, ptr %slot16, align 8
  store i64 %v567, ptr %slot109, align 8
  %v568 = load i64, ptr %slot21, align 8
  %p570 = inttoptr i64 %v568 to ptr
  %gep571 = getelementptr i8, ptr %p570, i64 24
  %op569 = ptrtoint ptr %gep571 to i64
  store i64 %op569, ptr %slot110, align 8
  %v572 = load i64, ptr %slot109, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %ld574 = load i64, ptr %p573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld574, ptr %slot111, align 8
  %v575 = load i64, ptr %slot111, align 8
  %v576 = load i64, ptr %slot110, align 8
  %p577 = inttoptr i64 %v576 to ptr
  store i64 %v575, ptr %p577, align 8, !alias.scope !3, !noalias !4
  %v578 = load i64, ptr %slot21, align 8
  %v579 = load i64, ptr %slot13, align 8
  %p580 = inttoptr i64 %v579 to ptr
  store i64 %v578, ptr %p580, align 8, !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot13, align 8
  %p582 = inttoptr i64 %v581 to ptr
  %ld583 = load i64, ptr %p582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld583, ptr %slot112, align 8
  %v584 = load i64, ptr %slot9, align 8
  store i64 %v584, ptr %slot113, align 8
  %v585 = load i64, ptr %slot112, align 8
  %v586 = load i64, ptr %slot113, align 8
  %p587 = inttoptr i64 %v585 to ptr
  %p588 = inttoptr i64 %v586 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p588, ptr %p587, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot6, align 8
  %p590 = inttoptr i64 %v589 to ptr
  store i32 2, ptr %p590, align 4, !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot5, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i32 1, ptr %p592, align 4, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot113, align 8
  %v594 = load i64, ptr %slot13, align 8
  %p595 = inttoptr i64 %v594 to ptr
  store i64 %v593, ptr %p595, align 8, !alias.scope !3, !noalias !4
  %v596 = load i64, ptr %slot13, align 8
  %p597 = inttoptr i64 %v596 to ptr
  %ld598 = load i64, ptr %p597, align 8, !alias.scope !3, !noalias !4
  store i64 %ld598, ptr %slot114, align 8
  %v599 = load i64, ptr %slot13, align 8
  %p600 = inttoptr i64 %v599 to ptr
  %ld601 = load i64, ptr %p600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld601, ptr %slot115, align 8
  %v602 = load i64, ptr %slot11, align 8
  store i64 %v602, ptr %slot116, align 8
  %v603 = load i64, ptr %slot19, align 8
  store i64 %v603, ptr %slot117, align 8
  %v604 = load i64, ptr %slot115, align 8
  %op605 = add i64 %v604, 0
  store i64 %op605, ptr %slot118, align 8
  %v606 = load i64, ptr %slot118, align 8
  %p607 = inttoptr i64 %v606 to ptr
  %ld608 = load i64, ptr %p607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld608, ptr %slot119, align 8
  %v609 = load i64, ptr %slot119, align 8
  %cmp610 = icmp ne i64 %v609, 0
  %cv611 = zext i1 %cmp610 to i32
  store i32 %cv611, ptr %slot120, align 8
  %v612 = load i32, ptr %slot120, align 8
  %cv613 = zext i32 %v612 to i64
  %cond614 = icmp ne i64 %cv613, 0
  br i1 %cond614, label %bb_rcmoveheader125, label %bb_rcmovenext125
bb_rcmoveheader125:
  %v615 = load i64, ptr %slot119, align 8
  %op616 = sub i64 %v615, 16
  store i64 %op616, ptr %slot121, align 8
  %v617 = load i64, ptr %slot119, align 8
  %p618 = inttoptr i64 %v617 to ptr
  %rgep619 = getelementptr i8, ptr %p618, i64 -16
  %ld620 = load i64, ptr %rgep619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld620, ptr %slot122, align 8
  %v621 = load i64, ptr %slot122, align 8
  %op622 = and i64 %v621, 5764607523034234881
  store i64 %op622, ptr %slot123, align 8
  %v623 = load i64, ptr %slot123, align 8
  %cmp624 = icmp ne i64 %v623, 0
  %cv625 = zext i1 %cmp624 to i32
  store i32 %cv625, ptr %slot124, align 8
  %v626 = load i32, ptr %slot124, align 8
  %cv627 = zext i32 %v626 to i64
  %cond628 = icmp ne i64 %cv627, 0
  br i1 %cond628, label %bb_rcmoveslow122, label %bb_rcmovenext125
bb_rcmovenext125:
  %v629 = load i64, ptr %slot115, align 8
  %v630 = load i64, ptr %slot116, align 8
  %p631 = inttoptr i64 %v629 to ptr
  %p632 = inttoptr i64 %v630 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p632, ptr %p631, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v633 = load i64, ptr %slot115, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i64 0, ptr %p634, align 8, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot115, align 8
  %op636 = add i64 %v635, 8
  store i64 %op636, ptr %slot125, align 8
  %v637 = load i64, ptr %slot125, align 8
  %p638 = inttoptr i64 %v637 to ptr
  store i64 0, ptr %p638, align 8, !alias.scope !3, !noalias !4
  %v639 = load i64, ptr %slot115, align 8
  %op640 = add i64 %v639, 16
  store i64 %op640, ptr %slot126, align 8
  %v641 = load i64, ptr %slot126, align 8
  %p642 = inttoptr i64 %v641 to ptr
  store i64 0, ptr %p642, align 8, !alias.scope !3, !noalias !4
  %v643 = load i64, ptr %slot115, align 8
  %op644 = add i64 %v643, 24
  store i64 %op644, ptr %slot127, align 8
  %v645 = load i64, ptr %slot127, align 8
  %p646 = inttoptr i64 %v645 to ptr
  store i64 0, ptr %p646, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved122
bb_rcmoveslow122:
  %v647 = load i64, ptr %slot18, align 8
  %v648 = load i64, ptr %slot116, align 8
  %v649 = load i64, ptr %slot115, align 8
  %v650 = load i64, ptr %slot117, align 8
  %cv651 = trunc i64 %v650 to i32
  %call652 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v647, i64 %v648, i64 %v649, i32 %cv651) nomerge, !dbg !114
  store i32 %call652, ptr %slot128, align 8
  %v653 = load i32, ptr %slot128, align 8
  %cv654 = zext i32 %v653 to i64
  %cond655 = icmp ne i64 %cv654, 0
  br i1 %cond655, label %bb_rcsuccess135, label %bb_rcfailure135
bb_rcfailure135:
  %v656 = load i64, ptr %slot18, align 8
  %p657 = inttoptr i64 %v656 to ptr
  %call658 = call i32 @myl_rc_take_failure(ptr %p657) nomerge, !dbg !114
  store i32 %call658, ptr %slot129, align 8
  %v659 = load i64, ptr %slot1, align 8
  %p660 = inttoptr i64 %v659 to ptr
  %v661 = load i32, ptr %slot129, align 8
  %call662 = call i32 @myl_qbe_rc_status(ptr %p660, i32 %v661) nomerge, !dbg !114
  store i32 %call662, ptr %slot130, align 8
  br label %bb_failure
bb_rcsuccess135:
  br label %bb_rcmoved122
bb_rcmoved122:
  %v663 = load i64, ptr %slot5, align 8
  %p664 = inttoptr i64 %v663 to ptr
  store i32 0, ptr %p664, align 4, !alias.scope !3, !noalias !4
  %v665 = load i64, ptr %slot7, align 8
  %p666 = inttoptr i64 %v665 to ptr
  store i32 1, ptr %p666, align 4, !alias.scope !3, !noalias !4
  %v667 = load i64, ptr %slot11, align 8
  store i64 %v667, ptr %slot131, align 8
  %v668 = load i64, ptr %slot7, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i32 0, ptr %p669, align 4, !alias.scope !3, !noalias !4
  %v670 = load i64, ptr %slot5, align 8
  %p671 = inttoptr i64 %v670 to ptr
  %ld672 = load i32, ptr %p671, align 4, !alias.scope !3, !noalias !4
  store i32 %ld672, ptr %slot132, align 8
  %v673 = load i32, ptr %slot132, align 8
  %cv674 = zext i32 %v673 to i64
  %cond675 = icmp ne i64 %cv674, 0
  br i1 %cond675, label %bb_rcslotdrop145, label %bb_rcslotdone145
bb_rcslotdrop145:
  %v676 = load i64, ptr %slot5, align 8
  %p677 = inttoptr i64 %v676 to ptr
  store i32 0, ptr %p677, align 4, !alias.scope !3, !noalias !4
  %v678 = load i64, ptr %slot9, align 8
  store i64 %v678, ptr %slot133, align 8
  %v679 = load i64, ptr %slot6, align 8
  %p680 = inttoptr i64 %v679 to ptr
  %ld681 = load i32, ptr %p680, align 4, !alias.scope !3, !noalias !4
  store i32 %ld681, ptr %slot134, align 8
  %v682 = load i32, ptr %slot134, align 8
  %op683 = and i32 %v682, 28
  store i32 %op683, ptr %slot135, align 8
  %v684 = load i32, ptr %slot135, align 8
  %cv685 = zext i32 %v684 to i64
  %cond686 = icmp ne i64 %cv685, 0
  br i1 %cond686, label %bb_rcslotrole145, label %bb_rcslotowner145
bb_rcslotrole145:
  %v687 = load i64, ptr %slot18, align 8
  store i64 %v687, ptr %slot136, align 8
  %v688 = load i64, ptr %slot136, align 8
  %v689 = load i64, ptr %slot133, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v688, i64 %v689) nomerge, !dbg !114
  br label %bb_rcslotdone145
bb_rcslotowner145:
  %v690 = load i64, ptr %slot18, align 8
  store i64 %v690, ptr %slot137, align 8
  %v691 = load i64, ptr %slot137, align 8
  %v692 = load i64, ptr %slot133, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v691, i64 %v692) nomerge, !dbg !114
  br label %bb_rcslotdone145
bb_rcslotdone145:
  %v693 = load i64, ptr %slot131, align 8
  %p694 = inttoptr i64 %v693 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p694, i64 32, i1 false)
  ret void
bb_failure:
  %v695 = load i64, ptr %slot4, align 8
  %p696 = inttoptr i64 %v695 to ptr
  call void @llvm.memset.p0.i64(ptr %p696, i8 0, i64 32, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v697 = load i64, ptr %slot4, align 8
  %p698 = inttoptr i64 %v697 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p698, i64 32, i1 false)
  ret void
bb_entry_failure:
  %v699 = load i64, ptr %slot4, align 8
  %p700 = inttoptr i64 %v699 to ptr
  call void @llvm.memset.p0.i64(ptr %p700, i8 0, i64 32, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v701 = load i64, ptr %slot4, align 8
  %p702 = inttoptr i64 %v701 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p702, i64 32, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc", linkageName: "myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11836526195630411685, i64 0, !"myl_f_a3d9e75f7b182afffdd53288aeac5ea47784246147a0af8828948f65aec268cc"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!112 = !DILocation(line: 5, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
