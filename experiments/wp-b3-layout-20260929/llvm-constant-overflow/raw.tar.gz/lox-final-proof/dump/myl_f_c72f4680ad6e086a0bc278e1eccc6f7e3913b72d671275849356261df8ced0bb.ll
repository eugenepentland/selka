target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_c72f4680ad6e086a0bc278e1eccc6f7e3913b72d671275849356261df8ced0bb(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %callresult35 = alloca [16 x i8], align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %callresult79 = alloca [40 x i8], align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %callresult127 = alloca [16 x i8], align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v186 = load i64, ptr %slot1, align 8
  %op187 = add i64 %v186, 32
  store i64 %op187, ptr %slot3, align 8
  %mem188 = alloca i8, i64 16, align 8
  %ptr189 = ptrtoint ptr %mem188 to i64
  store i64 %ptr189, ptr %slot4, align 8
  %mem190 = alloca i8, i64 8, align 8
  %ptr191 = ptrtoint ptr %mem190 to i64
  store i64 %ptr191, ptr %slot5, align 8
  %mem192 = alloca i8, i64 8, align 8
  %ptr193 = ptrtoint ptr %mem192 to i64
  store i64 %ptr193, ptr %slot6, align 8
  %mem194 = alloca i8, i64 8, align 8
  %ptr195 = ptrtoint ptr %mem194 to i64
  store i64 %ptr195, ptr %slot7, align 8
  %mem196 = alloca i8, i64 8, align 8
  %ptr197 = ptrtoint ptr %mem196 to i64
  store i64 %ptr197, ptr %slot8, align 8
  %mem198 = alloca i8, i64 8, align 8
  %ptr199 = ptrtoint ptr %mem198 to i64
  store i64 %ptr199, ptr %slot9, align 8
  %mem200 = alloca i8, i64 8, align 8
  %ptr201 = ptrtoint ptr %mem200 to i64
  store i64 %ptr201, ptr %slot10, align 8
  %mem202 = alloca i8, i64 8, align 8
  %ptr203 = ptrtoint ptr %mem202 to i64
  store i64 %ptr203, ptr %slot11, align 8
  %mem204 = alloca i8, i64 312, align 8
  %ptr205 = ptrtoint ptr %mem204 to i64
  store i64 %ptr205, ptr %slot12, align 8
  %mem206 = alloca i8, i64 312, align 8
  %ptr207 = ptrtoint ptr %mem206 to i64
  store i64 %ptr207, ptr %slot13, align 8
  %mem208 = alloca i8, i64 8, align 8
  %ptr209 = ptrtoint ptr %mem208 to i64
  store i64 %ptr209, ptr %slot14, align 8
  %mem210 = alloca i8, i64 8, align 8
  %ptr211 = ptrtoint ptr %mem210 to i64
  store i64 %ptr211, ptr %slot15, align 8
  %mem212 = alloca i8, i64 40, align 8
  %ptr213 = ptrtoint ptr %mem212 to i64
  store i64 %ptr213, ptr %slot16, align 8
  %mem214 = alloca i8, i64 8, align 8
  %ptr215 = ptrtoint ptr %mem214 to i64
  store i64 %ptr215, ptr %slot17, align 8
  %mem216 = alloca i8, i64 8, align 8
  %ptr217 = ptrtoint ptr %mem216 to i64
  store i64 %ptr217, ptr %slot18, align 8
  %mem218 = alloca i8, i64 8, align 8
  %ptr219 = ptrtoint ptr %mem218 to i64
  store i64 %ptr219, ptr %slot19, align 8
  %mem220 = alloca i8, i64 8, align 8
  %ptr221 = ptrtoint ptr %mem220 to i64
  store i64 %ptr221, ptr %slot20, align 8
  %mem222 = alloca i8, i64 8, align 8
  %ptr223 = ptrtoint ptr %mem222 to i64
  store i64 %ptr223, ptr %slot21, align 8
  %mem224 = alloca i8, i64 16, align 8
  %ptr225 = ptrtoint ptr %mem224 to i64
  store i64 %ptr225, ptr %slot22, align 8
  %mem226 = alloca i8, i64 312, align 8
  %ptr227 = ptrtoint ptr %mem226 to i64
  store i64 %ptr227, ptr %slot23, align 8
  %mem228 = alloca i8, i64 16, align 8
  %ptr229 = ptrtoint ptr %mem228 to i64
  store i64 %ptr229, ptr %slot24, align 8
  %mem230 = alloca i8, i64 16, align 8
  %ptr231 = ptrtoint ptr %mem230 to i64
  store i64 %ptr231, ptr %slot25, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem232 = alloca i8, i64 8, align 8
  %ptr233 = ptrtoint ptr %mem232 to i64
  store i64 %ptr233, ptr %slot26, align 8
  %v234 = load i64, ptr %slot1, align 8
  %op235 = add i64 %v234, 64
  store i64 %op235, ptr %slot27, align 8
  %v236 = load i64, ptr %slot27, align 8
  %p237 = inttoptr i64 %v236 to ptr
  %ld238 = load i64, ptr %p237, align 8, !alias.scope !4, !noalias !3
  store i64 %ld238, ptr %slot28, align 8
  %stack239 = call ptr @llvm.stacksave()
  %stackaddr240 = ptrtoint ptr %stack239 to i64
  %v241 = load i64, ptr %slot28, align 8
  %cmp242 = icmp ult i64 %stackaddr240, %v241
  %cv243 = zext i1 %cmp242 to i64
  store i64 %cv243, ptr %slot29, align 8
  %v244 = load i64, ptr %slot29, align 8
  %cond245 = icmp ne i64 %v244, 0
  br i1 %cond245, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v246 = load i64, ptr %slot1, align 8
  %p247 = inttoptr i64 %v246 to ptr
  call void @myl_qbe_fail_frame(ptr %p247) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v248 = load i64, ptr %slot2, align 8
  %v249 = load i64, ptr %slot14, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 %v248, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot1, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %call253 = call ptr @myl_qbe_heap(ptr %p252) nomerge, !dbg !112
  %calladdr254 = ptrtoint ptr %call253 to i64
  store i64 %calladdr254, ptr %slot30, align 8
  %v255 = load i64, ptr %slot1, align 8
  %p256 = inttoptr i64 %v255 to ptr
  %call257 = call i64 @myl_qbe_region_mark(ptr %p256) nomerge, !dbg !112
  store i64 %call257, ptr %slot31, align 8
  %v258 = load i64, ptr %slot5, align 8
  %p259 = inttoptr i64 %v258 to ptr
  store i32 0, ptr %p259, align 4, !alias.scope !3, !noalias !4
  %v260 = load i64, ptr %slot6, align 8
  %p261 = inttoptr i64 %v260 to ptr
  store i32 0, ptr %p261, align 4, !alias.scope !3, !noalias !4
  %v262 = load i64, ptr %slot7, align 8
  %p263 = inttoptr i64 %v262 to ptr
  store i32 0, ptr %p263, align 4, !alias.scope !3, !noalias !4
  %v264 = load i64, ptr %slot8, align 8
  %p265 = inttoptr i64 %v264 to ptr
  store i32 0, ptr %p265, align 4, !alias.scope !3, !noalias !4
  %v266 = load i64, ptr %slot9, align 8
  %p267 = inttoptr i64 %v266 to ptr
  store i32 0, ptr %p267, align 4, !alias.scope !3, !noalias !4
  %v268 = load i64, ptr %slot10, align 8
  %p269 = inttoptr i64 %v268 to ptr
  store i32 0, ptr %p269, align 4, !alias.scope !3, !noalias !4
  %v270 = load i64, ptr %slot11, align 8
  %p271 = inttoptr i64 %v270 to ptr
  store i32 0, ptr %p271, align 4, !alias.scope !3, !noalias !4
  %v272 = load i64, ptr %slot6, align 8
  %p273 = inttoptr i64 %v272 to ptr
  store i32 2, ptr %p273, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v274 = load i64, ptr %slot14, align 8
  %p275 = inttoptr i64 %v274 to ptr
  %ld276 = load i64, ptr %p275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld276, ptr %slot32, align 8
  %v277 = load i64, ptr %slot32, align 8
  %v278 = load i64, ptr %slot18, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 %v277, ptr %p279, align 8, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot18, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot33, align 8
  %v283 = load i64, ptr %slot1, align 8
  %v284 = load i64, ptr %slot33, align 8
  %call285 = call { i64, i64 } @myl_f_583ad2677b3f70fd855649dc3cdc4baa6574e2c61238282a21733d7400b58689(i64 %v283, i64 %v284) nomerge, !dbg !114
  store { i64, i64 } %call285, ptr %callresult35, align 8
  %addr286 = ptrtoint ptr %callresult35 to i64
  store i64 %addr286, ptr %slot34, align 8
  %v287 = load i64, ptr %slot34, align 8
  %v288 = load i64, ptr %slot18, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i64 %v287, ptr %p289, align 8, !alias.scope !3, !noalias !4
  %v290 = load i64, ptr %slot7, align 8
  %p291 = inttoptr i64 %v290 to ptr
  %ld292 = load i32, ptr %p291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld292, ptr %slot36, align 8
  %v293 = load i32, ptr %slot36, align 8
  %cv294 = zext i32 %v293 to i64
  %cond295 = icmp ne i64 %cv294, 0
  br i1 %cond295, label %bb_rcslotdrop14, label %bb_rcslotdone14
bb_rcslotdrop14:
  %v296 = load i64, ptr %slot7, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i32 0, ptr %p297, align 4, !alias.scope !3, !noalias !4
  %v298 = load i64, ptr %slot12, align 8
  store i64 %v298, ptr %slot37, align 8
  %v299 = load i64, ptr %slot8, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i32, ptr %p300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld301, ptr %slot38, align 8
  %v302 = load i32, ptr %slot38, align 8
  %op303 = and i32 %v302, 28
  store i32 %op303, ptr %slot39, align 8
  %v304 = load i32, ptr %slot39, align 8
  %cv305 = zext i32 %v304 to i64
  %cond306 = icmp ne i64 %cv305, 0
  br i1 %cond306, label %bb_rcslotrole14, label %bb_rcslotowner14
bb_rcslotrole14:
  %v307 = load i64, ptr %slot30, align 8
  store i64 %v307, ptr %slot40, align 8
  %v308 = load i64, ptr %slot40, align 8
  %v309 = load i64, ptr %slot37, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v308, i64 %v309) nomerge, !dbg !114
  br label %bb_rcslotdone14
bb_rcslotowner14:
  %v310 = load i64, ptr %slot30, align 8
  store i64 %v310, ptr %slot41, align 8
  %v311 = load i64, ptr %slot41, align 8
  %v312 = load i64, ptr %slot37, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v311, i64 %v312) nomerge, !dbg !114
  br label %bb_rcslotdone14
bb_rcslotdone14:
  %v313 = load i64, ptr %slot18, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !3, !noalias !4
  store i64 %ld315, ptr %slot42, align 8
  %v316 = load i64, ptr %slot42, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %ld318 = load i32, ptr %p317, align 4
  %ext319 = zext i32 %ld318 to i64
  store i64 %ext319, ptr %slot43, align 8
  %v320 = load i64, ptr %slot43, align 8
  %cmp321 = icmp eq i64 %v320, 0
  %cv322 = zext i1 %cmp321 to i64
  store i64 %cv322, ptr %slot44, align 8
  %v323 = load i64, ptr %slot44, align 8
  %cond324 = icmp ne i64 %v323, 0
  br i1 %cond324, label %bb_rctryok22, label %bb_rctryerror22
bb_rctryerror22:
  %p325 = inttoptr i64 ptrtoint (ptr @myl_f_c72f4680ad6e086a0bc278e1eccc6f7e3913b72d671275849356261df8ced0bb_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p325, i64 12884901890) "call-inline-cost"="0", !dbg !116
  %v326 = load i64, ptr %slot42, align 8
  %op327 = add i64 %v326, 8
  store i64 %op327, ptr %slot45, align 8
  %v328 = load i64, ptr %slot22, align 8
  store i64 %v328, ptr %slot46, align 8
  %v329 = load i64, ptr %slot46, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i64 0, ptr %p330, align 8, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot46, align 8
  %p333 = inttoptr i64 %v331 to ptr
  %gep334 = getelementptr i8, ptr %p333, i64 8
  %op332 = ptrtoint ptr %gep334 to i64
  store i64 %op332, ptr %slot47, align 8
  %v335 = load i64, ptr %slot47, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 0, ptr %p336, align 8, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot46, align 8
  %p338 = inttoptr i64 %v337 to ptr
  store i32 1, ptr %p338, align 4, !alias.scope !3, !noalias !4
  %v339 = load i64, ptr %slot46, align 8
  %p341 = inttoptr i64 %v339 to ptr
  %gep342 = getelementptr i8, ptr %p341, i64 8
  %op340 = ptrtoint ptr %gep342 to i64
  store i64 %op340, ptr %slot48, align 8
  %v343 = load i64, ptr %slot11, align 8
  %p344 = inttoptr i64 %v343 to ptr
  store i32 1, ptr %p344, align 4, !alias.scope !3, !noalias !4
  %v345 = load i64, ptr %slot31, align 8
  store i64 %v345, ptr %slot49, align 8
  %v346 = load i64, ptr %slot46, align 8
  %v347 = load i64, ptr %slot18, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i64 %v346, ptr %p348, align 8, !alias.scope !3, !noalias !4
  br label %bb_i4
bb_rctryok22:
  %v349 = load i64, ptr %slot22, align 8
  store i64 %v349, ptr %slot50, align 8
  %v350 = load i64, ptr %slot50, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i64 0, ptr %p351, align 8, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot11, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 1, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot42, align 8
  %op355 = add i64 %v354, 8
  store i64 %op355, ptr %slot51, align 8
  %v356 = load i64, ptr %slot31, align 8
  store i64 %v356, ptr %slot52, align 8
  %v357 = load i64, ptr %slot51, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %ld359 = load i64, ptr %p358, align 8
  store i64 %ld359, ptr %slot53, align 8
  %v360 = load i64, ptr %slot53, align 8
  %v361 = load i64, ptr %slot50, align 8
  %p362 = inttoptr i64 %v361 to ptr
  store i64 %v360, ptr %p362, align 8, !alias.scope !3, !noalias !4
  %v363 = load i64, ptr %slot50, align 8
  %p364 = inttoptr i64 %v363 to ptr
  %ld365 = load i64, ptr %p364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld365, ptr %slot54, align 8
  %v366 = load i64, ptr %slot54, align 8
  %v367 = load i64, ptr %slot18, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i64 %v366, ptr %p368, align 8, !alias.scope !3, !noalias !4
  br label %bb_i5
bb_i4:
  %v369 = load i64, ptr %slot18, align 8
  %p370 = inttoptr i64 %v369 to ptr
  %ld371 = load i64, ptr %p370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld371, ptr %slot55, align 8
  %v372 = load i64, ptr %slot7, align 8
  %p373 = inttoptr i64 %v372 to ptr
  %ld374 = load i32, ptr %p373, align 4, !alias.scope !3, !noalias !4
  store i32 %ld374, ptr %slot56, align 8
  %v375 = load i32, ptr %slot56, align 8
  %cv376 = zext i32 %v375 to i64
  %cond377 = icmp ne i64 %cv376, 0
  br i1 %cond377, label %bb_rcslotdrop41, label %bb_rcslotdone41
bb_rcslotdrop41:
  %v378 = load i64, ptr %slot7, align 8
  %p379 = inttoptr i64 %v378 to ptr
  store i32 0, ptr %p379, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone41
bb_rcslotdone41:
  %v380 = load i64, ptr %slot5, align 8
  %p381 = inttoptr i64 %v380 to ptr
  %ld382 = load i32, ptr %p381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld382, ptr %slot57, align 8
  %v383 = load i32, ptr %slot57, align 8
  %cv384 = zext i32 %v383 to i64
  %cond385 = icmp ne i64 %cv384, 0
  br i1 %cond385, label %bb_rcslotdrop44, label %bb_rcslotdone44
bb_rcslotdrop44:
  %v386 = load i64, ptr %slot5, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i32 0, ptr %p387, align 4, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot16, align 8
  store i64 %v388, ptr %slot58, align 8
  %v389 = load i64, ptr %slot6, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %ld391 = load i32, ptr %p390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld391, ptr %slot59, align 8
  %v392 = load i32, ptr %slot59, align 8
  %op393 = and i32 %v392, 28
  store i32 %op393, ptr %slot60, align 8
  %v394 = load i32, ptr %slot60, align 8
  %cv395 = zext i32 %v394 to i64
  %cond396 = icmp ne i64 %cv395, 0
  br i1 %cond396, label %bb_rcslotrole44, label %bb_rcslotowner44
bb_rcslotrole44:
  %v397 = load i64, ptr %slot30, align 8
  store i64 %v397, ptr %slot61, align 8
  %v398 = load i64, ptr %slot61, align 8
  %v399 = load i64, ptr %slot58, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v398, i64 %v399) nomerge, !dbg !118
  br label %bb_rcslotdone44
bb_rcslotowner44:
  %v400 = load i64, ptr %slot30, align 8
  store i64 %v400, ptr %slot62, align 8
  %v401 = load i64, ptr %slot62, align 8
  %v402 = load i64, ptr %slot58, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v401, i64 %v402) nomerge, !dbg !118
  br label %bb_rcslotdone44
bb_rcslotdone44:
  %v403 = load i64, ptr %slot55, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ret405 = load { i64, i64 }, ptr %p404, align 8
  ret { i64, i64 } %ret405
bb_i5:
  %v406 = load i64, ptr %slot18, align 8
  %p407 = inttoptr i64 %v406 to ptr
  %ld408 = load i64, ptr %p407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld408, ptr %slot63, align 8
  %v409 = load i64, ptr %slot63, align 8
  %v410 = load i64, ptr %slot15, align 8
  %p411 = inttoptr i64 %v410 to ptr
  store i64 %v409, ptr %p411, align 8, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_i6:
  %v412 = load i64, ptr %slot14, align 8
  %p413 = inttoptr i64 %v412 to ptr
  %ld414 = load i64, ptr %p413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld414, ptr %slot64, align 8
  %v415 = load i64, ptr %slot64, align 8
  %v416 = load i64, ptr %slot18, align 8
  %p417 = inttoptr i64 %v416 to ptr
  store i64 %v415, ptr %p417, align 8, !alias.scope !3, !noalias !4
  %v418 = load i64, ptr %slot23, align 8
  store i64 %v418, ptr %slot65, align 8
  %v419 = load i64, ptr %slot65, align 8
  %p420 = inttoptr i64 %v419 to ptr
  store i32 0, ptr %p420, align 4, !alias.scope !3, !noalias !4
  %v421 = load i64, ptr %slot65, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i32 30, ptr %p422, align 4, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot65, align 8
  %v424 = load i64, ptr %slot19, align 8
  %p425 = inttoptr i64 %v424 to ptr
  store i64 %v423, ptr %p425, align 8, !alias.scope !3, !noalias !4
  %v426 = load i64, ptr %slot18, align 8
  %p427 = inttoptr i64 %v426 to ptr
  %ld428 = load i64, ptr %p427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld428, ptr %slot66, align 8
  %v429 = load i64, ptr %slot19, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot67, align 8
  %v432 = load i64, ptr %slot1, align 8
  %v433 = load i64, ptr %slot66, align 8
  %v434 = load i64, ptr %slot67, align 8
  %call435 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v432, i64 %v433, i64 %v434) nomerge, !dbg !120
  store i64 %call435, ptr %slot68, align 8
  %v436 = load i64, ptr %slot68, align 8
  %v437 = load i64, ptr %slot18, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i64 %v436, ptr %p438, align 8, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot7, align 8
  %p440 = inttoptr i64 %v439 to ptr
  %ld441 = load i32, ptr %p440, align 4, !alias.scope !3, !noalias !4
  store i32 %ld441, ptr %slot69, align 8
  %v442 = load i32, ptr %slot69, align 8
  %cv443 = zext i32 %v442 to i64
  %cond444 = icmp ne i64 %cv443, 0
  br i1 %cond444, label %bb_rcslotdrop68, label %bb_rcslotdone68
bb_rcslotdrop68:
  %v445 = load i64, ptr %slot7, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i32 0, ptr %p446, align 4, !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot12, align 8
  store i64 %v447, ptr %slot70, align 8
  %v448 = load i64, ptr %slot8, align 8
  %p449 = inttoptr i64 %v448 to ptr
  %ld450 = load i32, ptr %p449, align 4, !alias.scope !3, !noalias !4
  store i32 %ld450, ptr %slot71, align 8
  %v451 = load i32, ptr %slot71, align 8
  %op452 = and i32 %v451, 28
  store i32 %op452, ptr %slot72, align 8
  %v453 = load i32, ptr %slot72, align 8
  %cv454 = zext i32 %v453 to i64
  %cond455 = icmp ne i64 %cv454, 0
  br i1 %cond455, label %bb_rcslotrole68, label %bb_rcslotowner68
bb_rcslotrole68:
  %v456 = load i64, ptr %slot30, align 8
  store i64 %v456, ptr %slot73, align 8
  %v457 = load i64, ptr %slot73, align 8
  %v458 = load i64, ptr %slot70, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v457, i64 %v458) nomerge, !dbg !120
  br label %bb_rcslotdone68
bb_rcslotowner68:
  %v459 = load i64, ptr %slot30, align 8
  store i64 %v459, ptr %slot74, align 8
  %v460 = load i64, ptr %slot74, align 8
  %v461 = load i64, ptr %slot70, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v460, i64 %v461) nomerge, !dbg !120
  br label %bb_rcslotdone68
bb_rcslotdone68:
  %v462 = load i64, ptr %slot18, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i64, ptr %p463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld464, ptr %slot75, align 8
  %v465 = load i64, ptr %slot75, align 8
  %cond466 = icmp ne i64 %v465, 0
  br i1 %cond466, label %bb_next76, label %bb_i26
bb_next76:
  %v467 = load i64, ptr %slot14, align 8
  %p468 = inttoptr i64 %v467 to ptr
  %ld469 = load i64, ptr %p468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld469, ptr %slot76, align 8
  %v470 = load i64, ptr %slot76, align 8
  %v471 = load i64, ptr %slot18, align 8
  %p472 = inttoptr i64 %v471 to ptr
  store i64 %v470, ptr %p472, align 8, !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot18, align 8
  %p474 = inttoptr i64 %v473 to ptr
  %ld475 = load i64, ptr %p474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld475, ptr %slot77, align 8
  %v476 = load i64, ptr %slot1, align 8
  %v477 = load i64, ptr %slot77, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult79, i64 %v476, i64 %v477) nomerge, !dbg !122
  %addr478 = ptrtoint ptr %callresult79 to i64
  store i64 %addr478, ptr %slot78, align 8
  %v479 = load i64, ptr %slot78, align 8
  %v480 = load i64, ptr %slot18, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i64 %v479, ptr %p481, align 8, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot18, align 8
  %p483 = inttoptr i64 %v482 to ptr
  %ld484 = load i64, ptr %p483, align 8, !alias.scope !3, !noalias !4
  store i64 %ld484, ptr %slot80, align 8
  %v485 = load i64, ptr %slot13, align 8
  store i64 %v485, ptr %slot81, align 8
  %v486 = load i64, ptr %slot30, align 8
  %v487 = load i64, ptr %slot81, align 8
  %v488 = load i64, ptr %slot80, align 8
  %call489 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v486, i64 %v487, i64 %v488) nomerge, !dbg !122
  store i32 %call489, ptr %slot82, align 8
  %v490 = load i32, ptr %slot82, align 8
  %cv491 = zext i32 %v490 to i64
  %cond492 = icmp ne i64 %cv491, 0
  br i1 %cond492, label %bb_rcsuccess82, label %bb_rcfailure82
bb_rcfailure82:
  %v493 = load i64, ptr %slot30, align 8
  %p494 = inttoptr i64 %v493 to ptr
  %call495 = call i32 @myl_rc_take_failure(ptr %p494) nomerge, !dbg !122
  store i32 %call495, ptr %slot83, align 8
  %v496 = load i64, ptr %slot1, align 8
  %p497 = inttoptr i64 %v496 to ptr
  %v498 = load i32, ptr %slot83, align 8
  %call499 = call i32 @myl_qbe_rc_status(ptr %p497, i32 %v498) nomerge, !dbg !122
  store i32 %call499, ptr %slot84, align 8
  br label %bb_failure
bb_rcsuccess82:
  %v500 = load i64, ptr %slot10, align 8
  %p501 = inttoptr i64 %v500 to ptr
  store i32 2, ptr %p501, align 4, !alias.scope !3, !noalias !4
  %v502 = load i64, ptr %slot10, align 8
  %p503 = inttoptr i64 %v502 to ptr
  store i32 16, ptr %p503, align 4, !alias.scope !3, !noalias !4
  %v504 = load i64, ptr %slot9, align 8
  %p505 = inttoptr i64 %v504 to ptr
  store i32 1, ptr %p505, align 4, !alias.scope !3, !noalias !4
  %v506 = load i64, ptr %slot7, align 8
  %p507 = inttoptr i64 %v506 to ptr
  %ld508 = load i32, ptr %p507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld508, ptr %slot85, align 8
  %v509 = load i32, ptr %slot85, align 8
  %cv510 = zext i32 %v509 to i64
  %cond511 = icmp ne i64 %cv510, 0
  br i1 %cond511, label %bb_rcslotdrop90, label %bb_rcslotdone90
bb_rcslotdrop90:
  %v512 = load i64, ptr %slot7, align 8
  %p513 = inttoptr i64 %v512 to ptr
  store i32 0, ptr %p513, align 4, !alias.scope !3, !noalias !4
  %v514 = load i64, ptr %slot12, align 8
  store i64 %v514, ptr %slot86, align 8
  %v515 = load i64, ptr %slot8, align 8
  %p516 = inttoptr i64 %v515 to ptr
  %ld517 = load i32, ptr %p516, align 4, !alias.scope !3, !noalias !4
  store i32 %ld517, ptr %slot87, align 8
  %v518 = load i32, ptr %slot87, align 8
  %op519 = and i32 %v518, 28
  store i32 %op519, ptr %slot88, align 8
  %v520 = load i32, ptr %slot88, align 8
  %cv521 = zext i32 %v520 to i64
  %cond522 = icmp ne i64 %cv521, 0
  br i1 %cond522, label %bb_rcslotrole90, label %bb_rcslotowner90
bb_rcslotrole90:
  %v523 = load i64, ptr %slot30, align 8
  store i64 %v523, ptr %slot89, align 8
  %v524 = load i64, ptr %slot89, align 8
  %v525 = load i64, ptr %slot86, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v524, i64 %v525) nomerge, !dbg !122
  br label %bb_rcslotdone90
bb_rcslotowner90:
  %v526 = load i64, ptr %slot30, align 8
  store i64 %v526, ptr %slot90, align 8
  %v527 = load i64, ptr %slot90, align 8
  %v528 = load i64, ptr %slot86, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v527, i64 %v528) nomerge, !dbg !122
  br label %bb_rcslotdone90
bb_rcslotdone90:
  %v529 = load i64, ptr %slot12, align 8
  store i64 %v529, ptr %slot91, align 8
  %v530 = load i64, ptr %slot13, align 8
  store i64 %v530, ptr %slot92, align 8
  %v531 = load i64, ptr %slot92, align 8
  %v532 = load i64, ptr %slot91, align 8
  %p533 = inttoptr i64 %v531 to ptr
  %p534 = inttoptr i64 %v532 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p534, ptr %p533, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v535 = load i64, ptr %slot8, align 8
  %p536 = inttoptr i64 %v535 to ptr
  store i32 2, ptr %p536, align 4, !alias.scope !3, !noalias !4
  %v537 = load i64, ptr %slot10, align 8
  %p538 = inttoptr i64 %v537 to ptr
  %ld539 = load i32, ptr %p538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld539, ptr %slot93, align 8
  %v540 = load i32, ptr %slot93, align 8
  %v541 = load i64, ptr %slot8, align 8
  %p542 = inttoptr i64 %v541 to ptr
  store i32 %v540, ptr %p542, align 4, !alias.scope !3, !noalias !4
  %v543 = load i64, ptr %slot9, align 8
  %p544 = inttoptr i64 %v543 to ptr
  store i32 0, ptr %p544, align 4, !alias.scope !3, !noalias !4
  %v545 = load i64, ptr %slot7, align 8
  %p546 = inttoptr i64 %v545 to ptr
  store i32 1, ptr %p546, align 4, !alias.scope !3, !noalias !4
  %v547 = load i64, ptr %slot91, align 8
  %v548 = load i64, ptr %slot18, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i64 %v547, ptr %p549, align 8, !alias.scope !3, !noalias !4
  %v550 = load i64, ptr %slot18, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot94, align 8
  %v553 = load i64, ptr %slot7, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i32, ptr %p554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld555, ptr %slot95, align 8
  %v556 = load i64, ptr %slot8, align 8
  %p557 = inttoptr i64 %v556 to ptr
  %ld558 = load i32, ptr %p557, align 4, !alias.scope !3, !noalias !4
  store i32 %ld558, ptr %slot96, align 8
  %v559 = load i32, ptr %slot96, align 8
  %op560 = and i32 %v559, 24
  store i32 %op560, ptr %slot96, align 8
  %v561 = load i32, ptr %slot96, align 8
  %cmp562 = icmp eq i32 %v561, 0
  %cv563 = zext i1 %cmp562 to i32
  store i32 %cv563, ptr %slot97, align 8
  %v564 = load i32, ptr %slot95, align 8
  %v565 = load i32, ptr %slot97, align 8
  %op566 = and i32 %v564, %v565
  store i32 %op566, ptr %slot98, align 8
  %v567 = load i32, ptr %slot98, align 8
  %cv568 = zext i32 %v567 to i64
  %cond569 = icmp ne i64 %cv568, 0
  br i1 %cond569, label %bb_rctake106, label %bb_rccopy106
bb_rctake106:
  %v570 = load i64, ptr %slot13, align 8
  store i64 %v570, ptr %slot99, align 8
  %v571 = load i64, ptr %slot31, align 8
  store i64 %v571, ptr %slot100, align 8
  %v572 = load i64, ptr %slot30, align 8
  %v573 = load i64, ptr %slot99, align 8
  %v574 = load i64, ptr %slot94, align 8
  %v575 = load i64, ptr %slot100, align 8
  %cv576 = trunc i64 %v575 to i32
  %call577 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v572, i64 %v573, i64 %v574, i32 %cv576) nomerge, !dbg !124
  store i32 %call577, ptr %slot101, align 8
  %v578 = load i32, ptr %slot101, align 8
  %cv579 = zext i32 %v578 to i64
  %cond580 = icmp ne i64 %cv579, 0
  br i1 %cond580, label %bb_rcsuccess116, label %bb_rcfailure116
bb_rcfailure116:
  %v581 = load i64, ptr %slot30, align 8
  %p582 = inttoptr i64 %v581 to ptr
  %call583 = call i32 @myl_rc_take_failure(ptr %p582) nomerge, !dbg !124
  store i32 %call583, ptr %slot102, align 8
  %v584 = load i64, ptr %slot1, align 8
  %p585 = inttoptr i64 %v584 to ptr
  %v586 = load i32, ptr %slot102, align 8
  %call587 = call i32 @myl_qbe_rc_status(ptr %p585, i32 %v586) nomerge, !dbg !124
  store i32 %call587, ptr %slot103, align 8
  br label %bb_failure
bb_rcsuccess116:
  %v588 = load i64, ptr %slot7, align 8
  %p589 = inttoptr i64 %v588 to ptr
  store i32 0, ptr %p589, align 4, !alias.scope !3, !noalias !4
  %v590 = load i64, ptr %slot10, align 8
  %p591 = inttoptr i64 %v590 to ptr
  store i32 2, ptr %p591, align 4, !alias.scope !3, !noalias !4
  %v592 = load i64, ptr %slot9, align 8
  %p593 = inttoptr i64 %v592 to ptr
  store i32 1, ptr %p593, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared106
bb_rccopy106:
  %v594 = load i64, ptr %slot13, align 8
  store i64 %v594, ptr %slot104, align 8
  %v595 = load i64, ptr %slot31, align 8
  store i64 %v595, ptr %slot105, align 8
  %v596 = load i64, ptr %slot30, align 8
  %v597 = load i64, ptr %slot104, align 8
  %v598 = load i64, ptr %slot94, align 8
  %v599 = load i64, ptr %slot105, align 8
  %cv600 = trunc i64 %v599 to i32
  %call601 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v596, i64 %v597, i64 %v598, i32 %cv600) nomerge, !dbg !124
  store i32 %call601, ptr %slot106, align 8
  %v602 = load i32, ptr %slot106, align 8
  %cv603 = zext i32 %v602 to i64
  %cond604 = icmp ne i64 %cv603, 0
  br i1 %cond604, label %bb_rcsuccess125, label %bb_rcfailure125
bb_rcfailure125:
  %v605 = load i64, ptr %slot30, align 8
  %p606 = inttoptr i64 %v605 to ptr
  %call607 = call i32 @myl_rc_take_failure(ptr %p606) nomerge, !dbg !124
  store i32 %call607, ptr %slot107, align 8
  %v608 = load i64, ptr %slot1, align 8
  %p609 = inttoptr i64 %v608 to ptr
  %v610 = load i32, ptr %slot107, align 8
  %call611 = call i32 @myl_qbe_rc_status(ptr %p609, i32 %v610) nomerge, !dbg !124
  store i32 %call611, ptr %slot108, align 8
  br label %bb_failure
bb_rcsuccess125:
  %v612 = load i64, ptr %slot10, align 8
  %p613 = inttoptr i64 %v612 to ptr
  store i32 2, ptr %p613, align 4, !alias.scope !3, !noalias !4
  %v614 = load i64, ptr %slot9, align 8
  %p615 = inttoptr i64 %v614 to ptr
  store i32 1, ptr %p615, align 4, !alias.scope !3, !noalias !4
  %v616 = load i64, ptr %slot7, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i32, ptr %p617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld618, ptr %slot109, align 8
  %v619 = load i32, ptr %slot109, align 8
  %cv620 = zext i32 %v619 to i64
  %cond621 = icmp ne i64 %cv620, 0
  br i1 %cond621, label %bb_rcslotdrop132, label %bb_rcslotdone132
bb_rcslotdrop132:
  %v622 = load i64, ptr %slot7, align 8
  %p623 = inttoptr i64 %v622 to ptr
  store i32 0, ptr %p623, align 4, !alias.scope !3, !noalias !4
  %v624 = load i64, ptr %slot12, align 8
  store i64 %v624, ptr %slot110, align 8
  %v625 = load i64, ptr %slot8, align 8
  %p626 = inttoptr i64 %v625 to ptr
  %ld627 = load i32, ptr %p626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld627, ptr %slot111, align 8
  %v628 = load i32, ptr %slot111, align 8
  %op629 = and i32 %v628, 28
  store i32 %op629, ptr %slot112, align 8
  %v630 = load i32, ptr %slot112, align 8
  %cv631 = zext i32 %v630 to i64
  %cond632 = icmp ne i64 %cv631, 0
  br i1 %cond632, label %bb_rcslotrole132, label %bb_rcslotowner132
bb_rcslotrole132:
  %v633 = load i64, ptr %slot30, align 8
  store i64 %v633, ptr %slot113, align 8
  %v634 = load i64, ptr %slot113, align 8
  %v635 = load i64, ptr %slot110, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v634, i64 %v635) nomerge, !dbg !124
  br label %bb_rcslotdone132
bb_rcslotowner132:
  %v636 = load i64, ptr %slot30, align 8
  store i64 %v636, ptr %slot114, align 8
  %v637 = load i64, ptr %slot114, align 8
  %v638 = load i64, ptr %slot110, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v637, i64 %v638) nomerge, !dbg !124
  br label %bb_rcslotdone132
bb_rcslotdone132:
  br label %bb_rcprepared106
bb_rcprepared106:
  %v639 = load i64, ptr %slot5, align 8
  %p640 = inttoptr i64 %v639 to ptr
  %ld641 = load i32, ptr %p640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld641, ptr %slot115, align 8
  %v642 = load i32, ptr %slot115, align 8
  %cv643 = zext i32 %v642 to i64
  %cond644 = icmp ne i64 %cv643, 0
  br i1 %cond644, label %bb_rcslotdrop142, label %bb_rcslotdone142
bb_rcslotdrop142:
  %v645 = load i64, ptr %slot5, align 8
  %p646 = inttoptr i64 %v645 to ptr
  store i32 0, ptr %p646, align 4, !alias.scope !3, !noalias !4
  %v647 = load i64, ptr %slot16, align 8
  store i64 %v647, ptr %slot116, align 8
  %v648 = load i64, ptr %slot6, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i32, ptr %p649, align 4, !alias.scope !3, !noalias !4
  store i32 %ld650, ptr %slot117, align 8
  %v651 = load i32, ptr %slot117, align 8
  %op652 = and i32 %v651, 28
  store i32 %op652, ptr %slot118, align 8
  %v653 = load i32, ptr %slot118, align 8
  %cv654 = zext i32 %v653 to i64
  %cond655 = icmp ne i64 %cv654, 0
  br i1 %cond655, label %bb_rcslotrole142, label %bb_rcslotowner142
bb_rcslotrole142:
  %v656 = load i64, ptr %slot30, align 8
  store i64 %v656, ptr %slot119, align 8
  %v657 = load i64, ptr %slot119, align 8
  %v658 = load i64, ptr %slot116, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v657, i64 %v658) nomerge, !dbg !124
  br label %bb_rcslotdone142
bb_rcslotowner142:
  %v659 = load i64, ptr %slot30, align 8
  store i64 %v659, ptr %slot120, align 8
  %v660 = load i64, ptr %slot120, align 8
  %v661 = load i64, ptr %slot116, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v660, i64 %v661) nomerge, !dbg !124
  br label %bb_rcslotdone142
bb_rcslotdone142:
  %v662 = load i64, ptr %slot16, align 8
  store i64 %v662, ptr %slot121, align 8
  %v663 = load i64, ptr %slot13, align 8
  store i64 %v663, ptr %slot122, align 8
  %v664 = load i64, ptr %slot122, align 8
  %v665 = load i64, ptr %slot121, align 8
  %p666 = inttoptr i64 %v664 to ptr
  %p667 = inttoptr i64 %v665 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p667, ptr %p666, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v668 = load i64, ptr %slot9, align 8
  %p669 = inttoptr i64 %v668 to ptr
  store i32 0, ptr %p669, align 4, !alias.scope !3, !noalias !4
  %v670 = load i64, ptr %slot6, align 8
  %p671 = inttoptr i64 %v670 to ptr
  store i32 2, ptr %p671, align 4, !alias.scope !3, !noalias !4
  %v672 = load i64, ptr %slot10, align 8
  %p673 = inttoptr i64 %v672 to ptr
  %ld674 = load i32, ptr %p673, align 4, !alias.scope !3, !noalias !4
  store i32 %ld674, ptr %slot123, align 8
  %v675 = load i32, ptr %slot123, align 8
  %v676 = load i64, ptr %slot6, align 8
  %p677 = inttoptr i64 %v676 to ptr
  store i32 %v675, ptr %p677, align 4, !alias.scope !3, !noalias !4
  %v678 = load i64, ptr %slot5, align 8
  %p679 = inttoptr i64 %v678 to ptr
  store i32 1, ptr %p679, align 4, !alias.scope !3, !noalias !4
  %v680 = load i64, ptr %slot14, align 8
  %p681 = inttoptr i64 %v680 to ptr
  %ld682 = load i64, ptr %p681, align 8, !alias.scope !3, !noalias !4
  store i64 %ld682, ptr %slot124, align 8
  %v683 = load i64, ptr %slot124, align 8
  %v684 = load i64, ptr %slot18, align 8
  %p685 = inttoptr i64 %v684 to ptr
  store i64 %v683, ptr %p685, align 8, !alias.scope !3, !noalias !4
  %v686 = load i64, ptr %slot18, align 8
  %p687 = inttoptr i64 %v686 to ptr
  %ld688 = load i64, ptr %p687, align 8, !alias.scope !3, !noalias !4
  store i64 %ld688, ptr %slot125, align 8
  %v689 = load i64, ptr %slot1, align 8
  %v690 = load i64, ptr %slot125, align 8
  %call691 = call { i64, i64 } @myl_f_583ad2677b3f70fd855649dc3cdc4baa6574e2c61238282a21733d7400b58689(i64 %v689, i64 %v690) nomerge, !dbg !126
  store { i64, i64 } %call691, ptr %callresult127, align 8
  %addr692 = ptrtoint ptr %callresult127 to i64
  store i64 %addr692, ptr %slot126, align 8
  %v693 = load i64, ptr %slot126, align 8
  %v694 = load i64, ptr %slot18, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i64 %v693, ptr %p695, align 8, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot7, align 8
  %p697 = inttoptr i64 %v696 to ptr
  %ld698 = load i32, ptr %p697, align 4, !alias.scope !3, !noalias !4
  store i32 %ld698, ptr %slot128, align 8
  %v699 = load i32, ptr %slot128, align 8
  %cv700 = zext i32 %v699 to i64
  %cond701 = icmp ne i64 %cv700, 0
  br i1 %cond701, label %bb_rcslotdrop161, label %bb_rcslotdone161
bb_rcslotdrop161:
  %v702 = load i64, ptr %slot7, align 8
  %p703 = inttoptr i64 %v702 to ptr
  store i32 0, ptr %p703, align 4, !alias.scope !3, !noalias !4
  %v704 = load i64, ptr %slot12, align 8
  store i64 %v704, ptr %slot129, align 8
  %v705 = load i64, ptr %slot8, align 8
  %p706 = inttoptr i64 %v705 to ptr
  %ld707 = load i32, ptr %p706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld707, ptr %slot130, align 8
  %v708 = load i32, ptr %slot130, align 8
  %op709 = and i32 %v708, 28
  store i32 %op709, ptr %slot131, align 8
  %v710 = load i32, ptr %slot131, align 8
  %cv711 = zext i32 %v710 to i64
  %cond712 = icmp ne i64 %cv711, 0
  br i1 %cond712, label %bb_rcslotrole161, label %bb_rcslotowner161
bb_rcslotrole161:
  %v713 = load i64, ptr %slot30, align 8
  store i64 %v713, ptr %slot132, align 8
  %v714 = load i64, ptr %slot132, align 8
  %v715 = load i64, ptr %slot129, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v714, i64 %v715) nomerge, !dbg !126
  br label %bb_rcslotdone161
bb_rcslotowner161:
  %v716 = load i64, ptr %slot30, align 8
  store i64 %v716, ptr %slot133, align 8
  %v717 = load i64, ptr %slot133, align 8
  %v718 = load i64, ptr %slot129, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v717, i64 %v718) nomerge, !dbg !126
  br label %bb_rcslotdone161
bb_rcslotdone161:
  %v719 = load i64, ptr %slot18, align 8
  %p720 = inttoptr i64 %v719 to ptr
  %ld721 = load i64, ptr %p720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld721, ptr %slot134, align 8
  %v722 = load i64, ptr %slot134, align 8
  %p723 = inttoptr i64 %v722 to ptr
  %ld724 = load i32, ptr %p723, align 4
  %ext725 = zext i32 %ld724 to i64
  store i64 %ext725, ptr %slot135, align 8
  %v726 = load i64, ptr %slot135, align 8
  %cmp727 = icmp eq i64 %v726, 0
  %cv728 = zext i1 %cmp727 to i64
  store i64 %cv728, ptr %slot136, align 8
  %v729 = load i64, ptr %slot136, align 8
  %cond730 = icmp ne i64 %v729, 0
  br i1 %cond730, label %bb_rctryok169, label %bb_rctryerror169
bb_rctryerror169:
  %p731 = inttoptr i64 ptrtoint (ptr @myl_f_c72f4680ad6e086a0bc278e1eccc6f7e3913b72d671275849356261df8ced0bb_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p731, i64 12884901903) "call-inline-cost"="0", !dbg !128
  %v732 = load i64, ptr %slot134, align 8
  %op733 = add i64 %v732, 8
  store i64 %op733, ptr %slot137, align 8
  %v734 = load i64, ptr %slot24, align 8
  store i64 %v734, ptr %slot138, align 8
  %v735 = load i64, ptr %slot138, align 8
  %p736 = inttoptr i64 %v735 to ptr
  store i64 0, ptr %p736, align 8, !alias.scope !3, !noalias !4
  %v737 = load i64, ptr %slot138, align 8
  %p739 = inttoptr i64 %v737 to ptr
  %gep740 = getelementptr i8, ptr %p739, i64 8
  %op738 = ptrtoint ptr %gep740 to i64
  store i64 %op738, ptr %slot139, align 8
  %v741 = load i64, ptr %slot139, align 8
  %p742 = inttoptr i64 %v741 to ptr
  store i64 0, ptr %p742, align 8, !alias.scope !3, !noalias !4
  %v743 = load i64, ptr %slot138, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i32 1, ptr %p744, align 4, !alias.scope !3, !noalias !4
  %v745 = load i64, ptr %slot138, align 8
  %p747 = inttoptr i64 %v745 to ptr
  %gep748 = getelementptr i8, ptr %p747, i64 8
  %op746 = ptrtoint ptr %gep748 to i64
  store i64 %op746, ptr %slot140, align 8
  %v749 = load i64, ptr %slot11, align 8
  %p750 = inttoptr i64 %v749 to ptr
  store i32 1, ptr %p750, align 4, !alias.scope !3, !noalias !4
  %v751 = load i64, ptr %slot31, align 8
  store i64 %v751, ptr %slot141, align 8
  %v752 = load i64, ptr %slot138, align 8
  %v753 = load i64, ptr %slot18, align 8
  %p754 = inttoptr i64 %v753 to ptr
  store i64 %v752, ptr %p754, align 8, !alias.scope !3, !noalias !4
  br label %bb_i17
bb_rctryok169:
  %v755 = load i64, ptr %slot24, align 8
  store i64 %v755, ptr %slot142, align 8
  %v756 = load i64, ptr %slot142, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i64 0, ptr %p757, align 8, !alias.scope !3, !noalias !4
  %v758 = load i64, ptr %slot11, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i32 1, ptr %p759, align 4, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot134, align 8
  %op761 = add i64 %v760, 8
  store i64 %op761, ptr %slot143, align 8
  %v762 = load i64, ptr %slot31, align 8
  store i64 %v762, ptr %slot144, align 8
  %v763 = load i64, ptr %slot143, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %ld765 = load i64, ptr %p764, align 8
  store i64 %ld765, ptr %slot145, align 8
  %v766 = load i64, ptr %slot145, align 8
  %v767 = load i64, ptr %slot142, align 8
  %p768 = inttoptr i64 %v767 to ptr
  store i64 %v766, ptr %p768, align 8, !alias.scope !3, !noalias !4
  %v769 = load i64, ptr %slot142, align 8
  %p770 = inttoptr i64 %v769 to ptr
  %ld771 = load i64, ptr %p770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld771, ptr %slot146, align 8
  %v772 = load i64, ptr %slot146, align 8
  %v773 = load i64, ptr %slot18, align 8
  %p774 = inttoptr i64 %v773 to ptr
  store i64 %v772, ptr %p774, align 8, !alias.scope !3, !noalias !4
  br label %bb_i18
bb_i17:
  %v775 = load i64, ptr %slot18, align 8
  %p776 = inttoptr i64 %v775 to ptr
  %ld777 = load i64, ptr %p776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld777, ptr %slot147, align 8
  %v778 = load i64, ptr %slot7, align 8
  %p779 = inttoptr i64 %v778 to ptr
  %ld780 = load i32, ptr %p779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld780, ptr %slot148, align 8
  %v781 = load i32, ptr %slot148, align 8
  %cv782 = zext i32 %v781 to i64
  %cond783 = icmp ne i64 %cv782, 0
  br i1 %cond783, label %bb_rcslotdrop188, label %bb_rcslotdone188
bb_rcslotdrop188:
  %v784 = load i64, ptr %slot7, align 8
  %p785 = inttoptr i64 %v784 to ptr
  store i32 0, ptr %p785, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone188
bb_rcslotdone188:
  %v786 = load i64, ptr %slot5, align 8
  %p787 = inttoptr i64 %v786 to ptr
  %ld788 = load i32, ptr %p787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld788, ptr %slot149, align 8
  %v789 = load i32, ptr %slot149, align 8
  %cv790 = zext i32 %v789 to i64
  %cond791 = icmp ne i64 %cv790, 0
  br i1 %cond791, label %bb_rcslotdrop191, label %bb_rcslotdone191
bb_rcslotdrop191:
  %v792 = load i64, ptr %slot5, align 8
  %p793 = inttoptr i64 %v792 to ptr
  store i32 0, ptr %p793, align 4, !alias.scope !3, !noalias !4
  %v794 = load i64, ptr %slot16, align 8
  store i64 %v794, ptr %slot150, align 8
  %v795 = load i64, ptr %slot6, align 8
  %p796 = inttoptr i64 %v795 to ptr
  %ld797 = load i32, ptr %p796, align 4, !alias.scope !3, !noalias !4
  store i32 %ld797, ptr %slot151, align 8
  %v798 = load i32, ptr %slot151, align 8
  %op799 = and i32 %v798, 28
  store i32 %op799, ptr %slot152, align 8
  %v800 = load i32, ptr %slot152, align 8
  %cv801 = zext i32 %v800 to i64
  %cond802 = icmp ne i64 %cv801, 0
  br i1 %cond802, label %bb_rcslotrole191, label %bb_rcslotowner191
bb_rcslotrole191:
  %v803 = load i64, ptr %slot30, align 8
  store i64 %v803, ptr %slot153, align 8
  %v804 = load i64, ptr %slot153, align 8
  %v805 = load i64, ptr %slot150, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v804, i64 %v805) nomerge, !dbg !130
  br label %bb_rcslotdone191
bb_rcslotowner191:
  %v806 = load i64, ptr %slot30, align 8
  store i64 %v806, ptr %slot154, align 8
  %v807 = load i64, ptr %slot154, align 8
  %v808 = load i64, ptr %slot150, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v807, i64 %v808) nomerge, !dbg !130
  br label %bb_rcslotdone191
bb_rcslotdone191:
  %v809 = load i64, ptr %slot147, align 8
  %p810 = inttoptr i64 %v809 to ptr
  %ret811 = load { i64, i64 }, ptr %p810, align 8
  ret { i64, i64 } %ret811
bb_i18:
  %v812 = load i64, ptr %slot18, align 8
  %p813 = inttoptr i64 %v812 to ptr
  %ld814 = load i64, ptr %p813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld814, ptr %slot155, align 8
  %v815 = load i64, ptr %slot155, align 8
  %v816 = load i64, ptr %slot17, align 8
  %p817 = inttoptr i64 %v816 to ptr
  store i64 %v815, ptr %p817, align 8, !alias.scope !3, !noalias !4
  %v818 = load i64, ptr %slot14, align 8
  %p819 = inttoptr i64 %v818 to ptr
  %ld820 = load i64, ptr %p819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld820, ptr %slot156, align 8
  %v821 = load i64, ptr %slot156, align 8
  %v822 = load i64, ptr %slot18, align 8
  %p823 = inttoptr i64 %v822 to ptr
  store i64 %v821, ptr %p823, align 8, !alias.scope !3, !noalias !4
  %v824 = load i64, ptr %slot15, align 8
  %p825 = inttoptr i64 %v824 to ptr
  %ld826 = load i64, ptr %p825, align 8, !alias.scope !3, !noalias !4
  store i64 %ld826, ptr %slot157, align 8
  %v827 = load i64, ptr %slot157, align 8
  %v828 = load i64, ptr %slot19, align 8
  %p829 = inttoptr i64 %v828 to ptr
  store i64 %v827, ptr %p829, align 8, !alias.scope !3, !noalias !4
  %v830 = load i64, ptr %slot16, align 8
  %v831 = load i64, ptr %slot20, align 8
  %p832 = inttoptr i64 %v831 to ptr
  store i64 %v830, ptr %p832, align 8, !alias.scope !3, !noalias !4
  %v833 = load i64, ptr %slot17, align 8
  %p834 = inttoptr i64 %v833 to ptr
  %ld835 = load i64, ptr %p834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld835, ptr %slot158, align 8
  %v836 = load i64, ptr %slot158, align 8
  %v837 = load i64, ptr %slot21, align 8
  %p838 = inttoptr i64 %v837 to ptr
  store i64 %v836, ptr %p838, align 8, !alias.scope !3, !noalias !4
  %v839 = load i64, ptr %slot18, align 8
  %p840 = inttoptr i64 %v839 to ptr
  %ld841 = load i64, ptr %p840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld841, ptr %slot159, align 8
  %v842 = load i64, ptr %slot19, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %ld844 = load i64, ptr %p843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld844, ptr %slot160, align 8
  %v845 = load i64, ptr %slot20, align 8
  %p846 = inttoptr i64 %v845 to ptr
  %ld847 = load i64, ptr %p846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld847, ptr %slot161, align 8
  %v848 = load i64, ptr %slot21, align 8
  %p849 = inttoptr i64 %v848 to ptr
  %ld850 = load i64, ptr %p849, align 8, !alias.scope !3, !noalias !4
  store i64 %ld850, ptr %slot162, align 8
  %v851 = load i64, ptr %slot1, align 8
  %v852 = load i64, ptr %slot159, align 8
  %v853 = load i64, ptr %slot160, align 8
  %v854 = load i64, ptr %slot161, align 8
  %v855 = load i64, ptr %slot162, align 8
  %call856 = call i64 @myl_f_63a79f85e2cfd9d95a63e6425b05d9c83f6e1f99caa17f3cc7496bf1c073cf9b(i64 %v851, i64 %v852, i64 %v853, i64 %v854, i64 %v855) nomerge, !dbg !132
  store i64 %call856, ptr %slot163, align 8
  %v857 = load i64, ptr %slot163, align 8
  %v858 = load i64, ptr %slot18, align 8
  %p859 = inttoptr i64 %v858 to ptr
  store i64 %v857, ptr %p859, align 8, !alias.scope !3, !noalias !4
  %v860 = load i64, ptr %slot7, align 8
  %p861 = inttoptr i64 %v860 to ptr
  %ld862 = load i32, ptr %p861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld862, ptr %slot164, align 8
  %v863 = load i32, ptr %slot164, align 8
  %cv864 = zext i32 %v863 to i64
  %cond865 = icmp ne i64 %cv864, 0
  br i1 %cond865, label %bb_rcslotdrop218, label %bb_rcslotdone218
bb_rcslotdrop218:
  %v866 = load i64, ptr %slot7, align 8
  %p867 = inttoptr i64 %v866 to ptr
  store i32 0, ptr %p867, align 4, !alias.scope !3, !noalias !4
  %v868 = load i64, ptr %slot12, align 8
  store i64 %v868, ptr %slot165, align 8
  %v869 = load i64, ptr %slot8, align 8
  %p870 = inttoptr i64 %v869 to ptr
  %ld871 = load i32, ptr %p870, align 4, !alias.scope !3, !noalias !4
  store i32 %ld871, ptr %slot166, align 8
  %v872 = load i32, ptr %slot166, align 8
  %op873 = and i32 %v872, 28
  store i32 %op873, ptr %slot167, align 8
  %v874 = load i32, ptr %slot167, align 8
  %cv875 = zext i32 %v874 to i64
  %cond876 = icmp ne i64 %cv875, 0
  br i1 %cond876, label %bb_rcslotrole218, label %bb_rcslotowner218
bb_rcslotrole218:
  %v877 = load i64, ptr %slot30, align 8
  store i64 %v877, ptr %slot168, align 8
  %v878 = load i64, ptr %slot168, align 8
  %v879 = load i64, ptr %slot165, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v878, i64 %v879) nomerge, !dbg !132
  br label %bb_rcslotdone218
bb_rcslotowner218:
  %v880 = load i64, ptr %slot30, align 8
  store i64 %v880, ptr %slot169, align 8
  %v881 = load i64, ptr %slot169, align 8
  %v882 = load i64, ptr %slot165, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v881, i64 %v882) nomerge, !dbg !132
  br label %bb_rcslotdone218
bb_rcslotdone218:
  %v883 = load i64, ptr %slot18, align 8
  %p884 = inttoptr i64 %v883 to ptr
  %ld885 = load i64, ptr %p884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld885, ptr %slot170, align 8
  %v886 = load i64, ptr %slot170, align 8
  %v887 = load i64, ptr %slot15, align 8
  %p888 = inttoptr i64 %v887 to ptr
  store i64 %v886, ptr %p888, align 8, !alias.scope !3, !noalias !4
  br label %bb_i6
bb_i26:
  %v889 = load i64, ptr %slot15, align 8
  %p890 = inttoptr i64 %v889 to ptr
  %ld891 = load i64, ptr %p890, align 8, !alias.scope !3, !noalias !4
  store i64 %ld891, ptr %slot171, align 8
  %v892 = load i64, ptr %slot171, align 8
  %v893 = load i64, ptr %slot18, align 8
  %p894 = inttoptr i64 %v893 to ptr
  store i64 %v892, ptr %p894, align 8, !alias.scope !3, !noalias !4
  %v895 = load i64, ptr %slot25, align 8
  store i64 %v895, ptr %slot172, align 8
  %v896 = load i64, ptr %slot172, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i64 0, ptr %p897, align 8, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot172, align 8
  %p900 = inttoptr i64 %v898 to ptr
  %gep901 = getelementptr i8, ptr %p900, i64 8
  %op899 = ptrtoint ptr %gep901 to i64
  store i64 %op899, ptr %slot173, align 8
  %v902 = load i64, ptr %slot173, align 8
  %p903 = inttoptr i64 %v902 to ptr
  store i64 0, ptr %p903, align 8, !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot172, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i32 0, ptr %p905, align 4, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot11, align 8
  %p907 = inttoptr i64 %v906 to ptr
  store i32 1, ptr %p907, align 4, !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot18, align 8
  store i64 %v908, ptr %slot174, align 8
  %v909 = load i64, ptr %slot172, align 8
  %p911 = inttoptr i64 %v909 to ptr
  %gep912 = getelementptr i8, ptr %p911, i64 8
  %op910 = ptrtoint ptr %gep912 to i64
  store i64 %op910, ptr %slot175, align 8
  %v913 = load i64, ptr %slot31, align 8
  store i64 %v913, ptr %slot176, align 8
  %v914 = load i64, ptr %slot174, align 8
  %p915 = inttoptr i64 %v914 to ptr
  %ld916 = load i64, ptr %p915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld916, ptr %slot177, align 8
  %v917 = load i64, ptr %slot177, align 8
  %v918 = load i64, ptr %slot175, align 8
  %p919 = inttoptr i64 %v918 to ptr
  store i64 %v917, ptr %p919, align 8, !alias.scope !3, !noalias !4
  %v920 = load i64, ptr %slot172, align 8
  %v921 = load i64, ptr %slot18, align 8
  %p922 = inttoptr i64 %v921 to ptr
  store i64 %v920, ptr %p922, align 8, !alias.scope !3, !noalias !4
  %v923 = load i64, ptr %slot18, align 8
  %p924 = inttoptr i64 %v923 to ptr
  %ld925 = load i64, ptr %p924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld925, ptr %slot178, align 8
  %v926 = load i64, ptr %slot7, align 8
  %p927 = inttoptr i64 %v926 to ptr
  %ld928 = load i32, ptr %p927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld928, ptr %slot179, align 8
  %v929 = load i32, ptr %slot179, align 8
  %cv930 = zext i32 %v929 to i64
  %cond931 = icmp ne i64 %cv930, 0
  br i1 %cond931, label %bb_rcslotdrop247, label %bb_rcslotdone247
bb_rcslotdrop247:
  %v932 = load i64, ptr %slot7, align 8
  %p933 = inttoptr i64 %v932 to ptr
  store i32 0, ptr %p933, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone247
bb_rcslotdone247:
  %v934 = load i64, ptr %slot5, align 8
  %p935 = inttoptr i64 %v934 to ptr
  %ld936 = load i32, ptr %p935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld936, ptr %slot180, align 8
  %v937 = load i32, ptr %slot180, align 8
  %cv938 = zext i32 %v937 to i64
  %cond939 = icmp ne i64 %cv938, 0
  br i1 %cond939, label %bb_rcslotdrop250, label %bb_rcslotdone250
bb_rcslotdrop250:
  %v940 = load i64, ptr %slot5, align 8
  %p941 = inttoptr i64 %v940 to ptr
  store i32 0, ptr %p941, align 4, !alias.scope !3, !noalias !4
  %v942 = load i64, ptr %slot16, align 8
  store i64 %v942, ptr %slot181, align 8
  %v943 = load i64, ptr %slot6, align 8
  %p944 = inttoptr i64 %v943 to ptr
  %ld945 = load i32, ptr %p944, align 4, !alias.scope !3, !noalias !4
  store i32 %ld945, ptr %slot182, align 8
  %v946 = load i32, ptr %slot182, align 8
  %op947 = and i32 %v946, 28
  store i32 %op947, ptr %slot183, align 8
  %v948 = load i32, ptr %slot183, align 8
  %cv949 = zext i32 %v948 to i64
  %cond950 = icmp ne i64 %cv949, 0
  br i1 %cond950, label %bb_rcslotrole250, label %bb_rcslotowner250
bb_rcslotrole250:
  %v951 = load i64, ptr %slot30, align 8
  store i64 %v951, ptr %slot184, align 8
  %v952 = load i64, ptr %slot184, align 8
  %v953 = load i64, ptr %slot181, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v952, i64 %v953) nomerge, !dbg !134
  br label %bb_rcslotdone250
bb_rcslotowner250:
  %v954 = load i64, ptr %slot30, align 8
  store i64 %v954, ptr %slot185, align 8
  %v955 = load i64, ptr %slot185, align 8
  %v956 = load i64, ptr %slot181, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v955, i64 %v956) nomerge, !dbg !134
  br label %bb_rcslotdone250
bb_rcslotdone250:
  %v957 = load i64, ptr %slot178, align 8
  %p958 = inttoptr i64 %v957 to ptr
  %ret959 = load { i64, i64 }, ptr %p958, align 8
  ret { i64, i64 } %ret959
bb_failure:
  %v960 = load i64, ptr %slot4, align 8
  %p961 = inttoptr i64 %v960 to ptr
  call void @llvm.memset.p0.i64(ptr %p961, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v962 = load i64, ptr %slot4, align 8
  %p963 = inttoptr i64 %v962 to ptr
  %ret964 = load { i64, i64 }, ptr %p963, align 8
  ret { i64, i64 } %ret964
bb_entry_failure:
  %v965 = load i64, ptr %slot4, align 8
  %p966 = inttoptr i64 %v965 to ptr
  call void @llvm.memset.p0.i64(ptr %p966, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !134
  %v967 = load i64, ptr %slot4, align 8
  %p968 = inttoptr i64 %v967 to ptr
  %ret969 = load { i64, i64 }, ptr %p968, align 8
  ret { i64, i64 } %ret969
}

@myl_f_c72f4680ad6e086a0bc278e1eccc6f7e3913b72d671275849356261df8ced0bb_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare { i64, i64 } @myl_f_583ad2677b3f70fd855649dc3cdc4baa6574e2c61238282a21733d7400b58689(i64, i64)
declare i64 @myl_f_63a79f85e2cfd9d95a63e6425b05d9c83f6e1f99caa17f3cc7496bf1c073cf9b(i64, i64, i64, i64, i64)
declare i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_c72f4680ad6e086a0bc278e1eccc6f7e3913b72d671275849356261df8ced0bb", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_c72f4680ad6e086a0bc278e1eccc6f7e3913b72d671275849356261df8ced0bb", linkageName: "myl_f_c72f4680ad6e086a0bc278e1eccc6f7e3913b72d671275849356261df8ced0bb", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 1273785240860218203, i64 0, !"myl_f_c72f4680ad6e086a0bc278e1eccc6f7e3913b72d671275849356261df8ced0bb"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!122 = !DILocation(line: 12, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!124 = !DILocation(line: 13, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!126 = !DILocation(line: 15, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!128 = !DILocation(line: 16, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!130 = !DILocation(line: 18, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!132 = !DILocation(line: 24, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!134 = !DILocation(line: 29, column: 0, scope: !135)
