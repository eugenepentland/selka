target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_549c194dd59052d6a584a91a45f8e27a465f53a107227cc684c6aadde33da3a0(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca double, align 8
  %slot118 = alloca double, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca double, align 8
  %slot133 = alloca double, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca double, align 8
  %slot148 = alloca double, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca double, align 8
  %slot163 = alloca double, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca double, align 8
  %slot178 = alloca double, align 8
  %slot179 = alloca double, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca double, align 8
  %slot194 = alloca double, align 8
  %slot195 = alloca double, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca double, align 8
  %slot210 = alloca double, align 8
  %slot211 = alloca double, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca double, align 8
  %slot226 = alloca double, align 8
  %slot227 = alloca double, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca double, align 8
  %slot242 = alloca double, align 8
  %slot243 = alloca double, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca double, align 8
  %slot258 = alloca double, align 8
  %slot259 = alloca double, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca double, align 8
  %slot274 = alloca double, align 8
  %slot275 = alloca double, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca double, align 8
  %slot290 = alloca double, align 8
  %slot291 = alloca double, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca double, align 8
  %slot306 = alloca double, align 8
  %slot307 = alloca double, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca double, align 8
  %slot322 = alloca double, align 8
  %slot323 = alloca double, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca double, align 8
  %slot338 = alloca double, align 8
  %slot339 = alloca double, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca double, align 8
  %slot354 = alloca double, align 8
  %slot355 = alloca double, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca double, align 8
  %slot370 = alloca double, align 8
  %slot371 = alloca double, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca double, align 8
  %slot386 = alloca double, align 8
  %slot387 = alloca double, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca double, align 8
  %slot402 = alloca double, align 8
  %slot403 = alloca double, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca double, align 8
  %slot418 = alloca double, align 8
  %slot419 = alloca double, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca double, align 8
  %slot434 = alloca double, align 8
  %slot435 = alloca double, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca double, align 8
  %slot450 = alloca double, align 8
  %slot451 = alloca double, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca double, align 8
  %slot466 = alloca double, align 8
  %slot467 = alloca double, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca double, align 8
  %slot482 = alloca double, align 8
  %slot483 = alloca double, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca double, align 8
  %slot498 = alloca double, align 8
  %slot499 = alloca double, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca double, align 8
  %slot514 = alloca double, align 8
  %slot515 = alloca double, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca double, align 8
  %slot530 = alloca double, align 8
  %slot531 = alloca double, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca double, align 8
  %slot546 = alloca double, align 8
  %slot547 = alloca double, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca double, align 8
  %slot562 = alloca double, align 8
  %slot563 = alloca double, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca double, align 8
  %slot578 = alloca double, align 8
  %slot579 = alloca double, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca double, align 8
  %slot594 = alloca double, align 8
  %slot595 = alloca double, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca double, align 8
  %slot610 = alloca double, align 8
  %slot611 = alloca double, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca double, align 8
  %slot626 = alloca double, align 8
  %slot627 = alloca double, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca double, align 8
  %slot642 = alloca double, align 8
  %slot643 = alloca double, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca double, align 8
  %slot658 = alloca double, align 8
  %slot659 = alloca double, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca double, align 8
  %slot674 = alloca double, align 8
  %slot675 = alloca double, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca double, align 8
  %slot690 = alloca double, align 8
  %slot691 = alloca double, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca double, align 8
  %slot706 = alloca double, align 8
  %slot707 = alloca double, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca double, align 8
  %slot722 = alloca double, align 8
  %slot723 = alloca double, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca double, align 8
  %slot738 = alloca double, align 8
  %slot739 = alloca double, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v745 = load i64, ptr %slot1, align 8
  %op746 = add i64 %v745, 32
  store i64 %op746, ptr %slot5, align 8
  %mem747 = alloca i8, i64 16, align 8
  %ptr748 = ptrtoint ptr %mem747 to i64
  store i64 %ptr748, ptr %slot6, align 8
  %mem749 = alloca i8, i64 8, align 8
  %ptr750 = ptrtoint ptr %mem749 to i64
  store i64 %ptr750, ptr %slot7, align 8
  %mem751 = alloca i8, i64 8, align 8
  %ptr752 = ptrtoint ptr %mem751 to i64
  store i64 %ptr752, ptr %slot8, align 8
  %mem753 = alloca i8, i64 8, align 8
  %ptr754 = ptrtoint ptr %mem753 to i64
  store i64 %ptr754, ptr %slot9, align 8
  %mem755 = alloca i8, i64 8, align 8
  %ptr756 = ptrtoint ptr %mem755 to i64
  store i64 %ptr756, ptr %slot10, align 8
  %mem757 = alloca i8, i64 8, align 8
  %ptr758 = ptrtoint ptr %mem757 to i64
  store i64 %ptr758, ptr %slot11, align 8
  %mem759 = alloca i8, i64 8, align 8
  %ptr760 = ptrtoint ptr %mem759 to i64
  store i64 %ptr760, ptr %slot12, align 8
  %mem761 = alloca i8, i64 8, align 8
  %ptr762 = ptrtoint ptr %mem761 to i64
  store i64 %ptr762, ptr %slot13, align 8
  %mem763 = alloca i8, i64 8, align 8
  %ptr764 = ptrtoint ptr %mem763 to i64
  store i64 %ptr764, ptr %slot14, align 8
  %mem765 = alloca i8, i64 8, align 8
  %ptr766 = ptrtoint ptr %mem765 to i64
  store i64 %ptr766, ptr %slot15, align 8
  %mem767 = alloca i8, i64 8, align 8
  %ptr768 = ptrtoint ptr %mem767 to i64
  store i64 %ptr768, ptr %slot16, align 8
  %mem769 = alloca i8, i64 8, align 8
  %ptr770 = ptrtoint ptr %mem769 to i64
  store i64 %ptr770, ptr %slot17, align 8
  %mem771 = alloca i8, i64 8, align 8
  %ptr772 = ptrtoint ptr %mem771 to i64
  store i64 %ptr772, ptr %slot18, align 8
  %mem773 = alloca i8, i64 8, align 8
  %ptr774 = ptrtoint ptr %mem773 to i64
  store i64 %ptr774, ptr %slot19, align 8
  %mem775 = alloca i8, i64 8, align 8
  %ptr776 = ptrtoint ptr %mem775 to i64
  store i64 %ptr776, ptr %slot20, align 8
  %mem777 = alloca i8, i64 8, align 8
  %ptr778 = ptrtoint ptr %mem777 to i64
  store i64 %ptr778, ptr %slot21, align 8
  %mem779 = alloca i8, i64 8, align 8
  %ptr780 = ptrtoint ptr %mem779 to i64
  store i64 %ptr780, ptr %slot22, align 8
  %mem781 = alloca i8, i64 8, align 8
  %ptr782 = ptrtoint ptr %mem781 to i64
  store i64 %ptr782, ptr %slot23, align 8
  %mem783 = alloca i8, i64 8, align 8
  %ptr784 = ptrtoint ptr %mem783 to i64
  store i64 %ptr784, ptr %slot24, align 8
  %mem785 = alloca i8, i64 8, align 8
  %ptr786 = ptrtoint ptr %mem785 to i64
  store i64 %ptr786, ptr %slot25, align 8
  %mem787 = alloca i8, i64 16, align 8
  %ptr788 = ptrtoint ptr %mem787 to i64
  store i64 %ptr788, ptr %slot26, align 8
  %mem789 = alloca i8, i64 16, align 8
  %ptr790 = ptrtoint ptr %mem789 to i64
  store i64 %ptr790, ptr %slot27, align 8
  %mem791 = alloca i8, i64 16, align 8
  %ptr792 = ptrtoint ptr %mem791 to i64
  store i64 %ptr792, ptr %slot28, align 8
  %mem793 = alloca i8, i64 16, align 8
  %ptr794 = ptrtoint ptr %mem793 to i64
  store i64 %ptr794, ptr %slot29, align 8
  %mem795 = alloca i8, i64 16, align 8
  %ptr796 = ptrtoint ptr %mem795 to i64
  store i64 %ptr796, ptr %slot30, align 8
  %mem797 = alloca i8, i64 16, align 8
  %ptr798 = ptrtoint ptr %mem797 to i64
  store i64 %ptr798, ptr %slot31, align 8
  %mem799 = alloca i8, i64 16, align 8
  %ptr800 = ptrtoint ptr %mem799 to i64
  store i64 %ptr800, ptr %slot32, align 8
  %mem801 = alloca i8, i64 16, align 8
  %ptr802 = ptrtoint ptr %mem801 to i64
  store i64 %ptr802, ptr %slot33, align 8
  %mem803 = alloca i8, i64 16, align 8
  %ptr804 = ptrtoint ptr %mem803 to i64
  store i64 %ptr804, ptr %slot34, align 8
  %mem805 = alloca i8, i64 16, align 8
  %ptr806 = ptrtoint ptr %mem805 to i64
  store i64 %ptr806, ptr %slot35, align 8
  %mem807 = alloca i8, i64 16, align 8
  %ptr808 = ptrtoint ptr %mem807 to i64
  store i64 %ptr808, ptr %slot36, align 8
  %mem809 = alloca i8, i64 16, align 8
  %ptr810 = ptrtoint ptr %mem809 to i64
  store i64 %ptr810, ptr %slot37, align 8
  %mem811 = alloca i8, i64 16, align 8
  %ptr812 = ptrtoint ptr %mem811 to i64
  store i64 %ptr812, ptr %slot38, align 8
  %mem813 = alloca i8, i64 16, align 8
  %ptr814 = ptrtoint ptr %mem813 to i64
  store i64 %ptr814, ptr %slot39, align 8
  %mem815 = alloca i8, i64 16, align 8
  %ptr816 = ptrtoint ptr %mem815 to i64
  store i64 %ptr816, ptr %slot40, align 8
  %mem817 = alloca i8, i64 16, align 8
  %ptr818 = ptrtoint ptr %mem817 to i64
  store i64 %ptr818, ptr %slot41, align 8
  %mem819 = alloca i8, i64 16, align 8
  %ptr820 = ptrtoint ptr %mem819 to i64
  store i64 %ptr820, ptr %slot42, align 8
  %mem821 = alloca i8, i64 16, align 8
  %ptr822 = ptrtoint ptr %mem821 to i64
  store i64 %ptr822, ptr %slot43, align 8
  %mem823 = alloca i8, i64 16, align 8
  %ptr824 = ptrtoint ptr %mem823 to i64
  store i64 %ptr824, ptr %slot44, align 8
  %mem825 = alloca i8, i64 16, align 8
  %ptr826 = ptrtoint ptr %mem825 to i64
  store i64 %ptr826, ptr %slot45, align 8
  %mem827 = alloca i8, i64 16, align 8
  %ptr828 = ptrtoint ptr %mem827 to i64
  store i64 %ptr828, ptr %slot46, align 8
  %mem829 = alloca i8, i64 16, align 8
  %ptr830 = ptrtoint ptr %mem829 to i64
  store i64 %ptr830, ptr %slot47, align 8
  %mem831 = alloca i8, i64 16, align 8
  %ptr832 = ptrtoint ptr %mem831 to i64
  store i64 %ptr832, ptr %slot48, align 8
  %mem833 = alloca i8, i64 16, align 8
  %ptr834 = ptrtoint ptr %mem833 to i64
  store i64 %ptr834, ptr %slot49, align 8
  %mem835 = alloca i8, i64 16, align 8
  %ptr836 = ptrtoint ptr %mem835 to i64
  store i64 %ptr836, ptr %slot50, align 8
  %mem837 = alloca i8, i64 16, align 8
  %ptr838 = ptrtoint ptr %mem837 to i64
  store i64 %ptr838, ptr %slot51, align 8
  %mem839 = alloca i8, i64 16, align 8
  %ptr840 = ptrtoint ptr %mem839 to i64
  store i64 %ptr840, ptr %slot52, align 8
  %mem841 = alloca i8, i64 16, align 8
  %ptr842 = ptrtoint ptr %mem841 to i64
  store i64 %ptr842, ptr %slot53, align 8
  %mem843 = alloca i8, i64 16, align 8
  %ptr844 = ptrtoint ptr %mem843 to i64
  store i64 %ptr844, ptr %slot54, align 8
  %mem845 = alloca i8, i64 16, align 8
  %ptr846 = ptrtoint ptr %mem845 to i64
  store i64 %ptr846, ptr %slot55, align 8
  %mem847 = alloca i8, i64 16, align 8
  %ptr848 = ptrtoint ptr %mem847 to i64
  store i64 %ptr848, ptr %slot56, align 8
  %mem849 = alloca i8, i64 16, align 8
  %ptr850 = ptrtoint ptr %mem849 to i64
  store i64 %ptr850, ptr %slot57, align 8
  %mem851 = alloca i8, i64 16, align 8
  %ptr852 = ptrtoint ptr %mem851 to i64
  store i64 %ptr852, ptr %slot58, align 8
  %mem853 = alloca i8, i64 16, align 8
  %ptr854 = ptrtoint ptr %mem853 to i64
  store i64 %ptr854, ptr %slot59, align 8
  %mem855 = alloca i8, i64 16, align 8
  %ptr856 = ptrtoint ptr %mem855 to i64
  store i64 %ptr856, ptr %slot60, align 8
  %mem857 = alloca i8, i64 16, align 8
  %ptr858 = ptrtoint ptr %mem857 to i64
  store i64 %ptr858, ptr %slot61, align 8
  %mem859 = alloca i8, i64 16, align 8
  %ptr860 = ptrtoint ptr %mem859 to i64
  store i64 %ptr860, ptr %slot62, align 8
  %mem861 = alloca i8, i64 16, align 8
  %ptr862 = ptrtoint ptr %mem861 to i64
  store i64 %ptr862, ptr %slot63, align 8
  %mem863 = alloca i8, i64 16, align 8
  %ptr864 = ptrtoint ptr %mem863 to i64
  store i64 %ptr864, ptr %slot64, align 8
  %mem865 = alloca i8, i64 16, align 8
  %ptr866 = ptrtoint ptr %mem865 to i64
  store i64 %ptr866, ptr %slot65, align 8
  %v867 = load i64, ptr %slot2, align 8
  %v868 = load i64, ptr %slot7, align 8
  %p869 = inttoptr i64 %v868 to ptr
  store i64 %v867, ptr %p869, align 8, !alias.scope !3, !noalias !4
  %v870 = load i64, ptr %slot3, align 8
  %v871 = load i64, ptr %slot8, align 8
  %p872 = inttoptr i64 %v871 to ptr
  store i64 %v870, ptr %p872, align 8, !alias.scope !3, !noalias !4
  %v873 = load i64, ptr %slot4, align 8
  %v874 = load i64, ptr %slot9, align 8
  %p875 = inttoptr i64 %v874 to ptr
  store i64 %v873, ptr %p875, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v876 = load i64, ptr %slot7, align 8
  %p877 = inttoptr i64 %v876 to ptr
  %ld878 = load i64, ptr %p877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld878, ptr %slot66, align 8
  %v879 = load i64, ptr %slot66, align 8
  %v880 = load i64, ptr %slot24, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i64 %v879, ptr %p881, align 8, !alias.scope !3, !noalias !4
  %v882 = load i64, ptr %slot24, align 8
  %p883 = inttoptr i64 %v882 to ptr
  %ld884 = load i64, ptr %p883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld884, ptr %slot67, align 8
  %v885 = load i64, ptr %slot67, align 8
  %p886 = inttoptr i64 %v885 to ptr
  %ld887 = load i32, ptr %p886, align 4, !alias.scope !4, !noalias !3
  %ext888 = zext i32 %ld887 to i64
  store i64 %ext888, ptr %slot68, align 8
  %v889 = load i64, ptr %slot68, align 8
  %cmp890 = icmp eq i64 %v889, 0
  %cv891 = zext i1 %cmp890 to i64
  store i64 %cv891, ptr %slot69, align 8
  %v892 = load i64, ptr %slot69, align 8
  %cond893 = icmp ne i64 %v892, 0
  br i1 %cond893, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i70
bb_armnext3:
  %v894 = load i64, ptr %slot68, align 8
  %cmp895 = icmp eq i64 %v894, 1
  %cv896 = zext i1 %cmp895 to i64
  store i64 %cv896, ptr %slot70, align 8
  %v897 = load i64, ptr %slot70, align 8
  %cond898 = icmp ne i64 %v897, 0
  br i1 %cond898, label %bb_arm4, label %bb_armnext4
bb_arm4:
  br label %bb_i82
bb_armnext4:
  %v899 = load i64, ptr %slot68, align 8
  %cmp900 = icmp eq i64 %v899, 2
  %cv901 = zext i1 %cmp900 to i64
  store i64 %cv901, ptr %slot71, align 8
  %v902 = load i64, ptr %slot71, align 8
  %cond903 = icmp ne i64 %v902, 0
  br i1 %cond903, label %bb_arm5, label %bb_armnext5
bb_arm5:
  br label %bb_i94
bb_armnext5:
  %v904 = load i64, ptr %slot68, align 8
  %cmp905 = icmp eq i64 %v904, 3
  %cv906 = zext i1 %cmp905 to i64
  store i64 %cv906, ptr %slot72, align 8
  %v907 = load i64, ptr %slot72, align 8
  %cond908 = icmp ne i64 %v907, 0
  br i1 %cond908, label %bb_arm6, label %bb_armnext6
bb_arm6:
  br label %bb_i106
bb_armnext6:
  %v909 = load i64, ptr %slot68, align 8
  %cmp910 = icmp eq i64 %v909, 4
  %cv911 = zext i1 %cmp910 to i64
  store i64 %cv911, ptr %slot73, align 8
  %v912 = load i64, ptr %slot73, align 8
  %cond913 = icmp ne i64 %v912, 0
  br i1 %cond913, label %bb_arm7, label %bb_armnext7
bb_arm7:
  br label %bb_i118
bb_armnext7:
  %v914 = load i64, ptr %slot68, align 8
  %cmp915 = icmp eq i64 %v914, 5
  %cv916 = zext i1 %cmp915 to i64
  store i64 %cv916, ptr %slot74, align 8
  %v917 = load i64, ptr %slot74, align 8
  %cond918 = icmp ne i64 %v917, 0
  br i1 %cond918, label %bb_arm8, label %bb_armnext8
bb_arm8:
  br label %bb_i130
bb_armnext8:
  %v919 = load i64, ptr %slot68, align 8
  %cmp920 = icmp eq i64 %v919, 6
  %cv921 = zext i1 %cmp920 to i64
  store i64 %cv921, ptr %slot75, align 8
  %v922 = load i64, ptr %slot75, align 8
  %cond923 = icmp ne i64 %v922, 0
  br i1 %cond923, label %bb_arm9, label %bb_armnext9
bb_arm9:
  br label %bb_i46
bb_armnext9:
  %v924 = load i64, ptr %slot68, align 8
  %cmp925 = icmp eq i64 %v924, 7
  %cv926 = zext i1 %cmp925 to i64
  store i64 %cv926, ptr %slot76, align 8
  %v927 = load i64, ptr %slot76, align 8
  %cond928 = icmp ne i64 %v927, 0
  br i1 %cond928, label %bb_arm10, label %bb_armnext10
bb_arm10:
  br label %bb_i142
bb_armnext10:
  %v929 = load i64, ptr %slot68, align 8
  %cmp930 = icmp eq i64 %v929, 8
  %cv931 = zext i1 %cmp930 to i64
  store i64 %cv931, ptr %slot77, align 8
  %v932 = load i64, ptr %slot77, align 8
  %cond933 = icmp ne i64 %v932, 0
  br i1 %cond933, label %bb_arm11, label %bb_armnext11
bb_arm11:
  br label %bb_i154
bb_armnext11:
  %v934 = load i64, ptr %slot68, align 8
  %cmp935 = icmp eq i64 %v934, 9
  %cv936 = zext i1 %cmp935 to i64
  store i64 %cv936, ptr %slot78, align 8
  %v937 = load i64, ptr %slot78, align 8
  %cond938 = icmp ne i64 %v937, 0
  br i1 %cond938, label %bb_arm12, label %bb_armnext12
bb_arm12:
  br label %bb_i58
bb_armnext12:
  %v939 = load i64, ptr %slot68, align 8
  %cmp940 = icmp eq i64 %v939, 10
  %cv941 = zext i1 %cmp940 to i64
  store i64 %cv941, ptr %slot79, align 8
  %v942 = load i64, ptr %slot79, align 8
  %cond943 = icmp ne i64 %v942, 0
  br i1 %cond943, label %bb_arm13, label %bb_armnext13
bb_arm13:
  br label %bb_i166
bb_armnext13:
  %v944 = load i64, ptr %slot68, align 8
  %cmp945 = icmp eq i64 %v944, 11
  %cv946 = zext i1 %cmp945 to i64
  store i64 %cv946, ptr %slot80, align 8
  %v947 = load i64, ptr %slot80, align 8
  %cond948 = icmp ne i64 %v947, 0
  br i1 %cond948, label %bb_arm14, label %bb_armnext14
bb_arm14:
  br label %bb_i178
bb_armnext14:
  %v949 = load i64, ptr %slot68, align 8
  %cmp950 = icmp eq i64 %v949, 12
  %cv951 = zext i1 %cmp950 to i64
  store i64 %cv951, ptr %slot81, align 8
  %v952 = load i64, ptr %slot81, align 8
  %cond953 = icmp ne i64 %v952, 0
  br i1 %cond953, label %bb_arm15, label %bb_armnext15
bb_arm15:
  br label %bb_i190
bb_armnext15:
  %v954 = load i64, ptr %slot68, align 8
  %cmp955 = icmp eq i64 %v954, 13
  %cv956 = zext i1 %cmp955 to i64
  store i64 %cv956, ptr %slot82, align 8
  %v957 = load i64, ptr %slot82, align 8
  %cond958 = icmp ne i64 %v957, 0
  br i1 %cond958, label %bb_arm16, label %bb_armnext16
bb_arm16:
  br label %bb_i202
bb_armnext16:
  %v959 = load i64, ptr %slot68, align 8
  %cmp960 = icmp eq i64 %v959, 14
  %cv961 = zext i1 %cmp960 to i64
  store i64 %cv961, ptr %slot83, align 8
  %v962 = load i64, ptr %slot83, align 8
  %cond963 = icmp ne i64 %v962, 0
  br i1 %cond963, label %bb_arm17, label %bb_armnext17
bb_arm17:
  br label %bb_i214
bb_armnext17:
  %v964 = load i64, ptr %slot68, align 8
  %cmp965 = icmp eq i64 %v964, 15
  %cv966 = zext i1 %cmp965 to i64
  store i64 %cv966, ptr %slot84, align 8
  %v967 = load i64, ptr %slot84, align 8
  %cond968 = icmp ne i64 %v967, 0
  br i1 %cond968, label %bb_arm18, label %bb_armnext18
bb_arm18:
  br label %bb_i2
bb_armnext18:
  %v969 = load i64, ptr %slot68, align 8
  %cmp970 = icmp eq i64 %v969, 16
  %cv971 = zext i1 %cmp970 to i64
  store i64 %cv971, ptr %slot85, align 8
  %v972 = load i64, ptr %slot85, align 8
  %cond973 = icmp ne i64 %v972, 0
  br i1 %cond973, label %bb_arm19, label %bb_armnext19
bb_arm19:
  br label %bb_i13
bb_armnext19:
  %v974 = load i64, ptr %slot68, align 8
  %cmp975 = icmp eq i64 %v974, 17
  %cv976 = zext i1 %cmp975 to i64
  store i64 %cv976, ptr %slot86, align 8
  %v977 = load i64, ptr %slot86, align 8
  %cond978 = icmp ne i64 %v977, 0
  br i1 %cond978, label %bb_arm20, label %bb_armnext20
bb_arm20:
  br label %bb_i24
bb_armnext20:
  %v979 = load i64, ptr %slot68, align 8
  %cmp980 = icmp eq i64 %v979, 18
  %cv981 = zext i1 %cmp980 to i64
  store i64 %cv981, ptr %slot87, align 8
  %v982 = load i64, ptr %slot87, align 8
  %cond983 = icmp ne i64 %v982, 0
  br i1 %cond983, label %bb_arm21, label %bb_armnext21
bb_arm21:
  br label %bb_i35
bb_armnext21:
  %v984 = load i64, ptr %slot68, align 8
  %cmp985 = icmp eq i64 %v984, 19
  %cv986 = zext i1 %cmp985 to i64
  store i64 %cv986, ptr %slot88, align 8
  %v987 = load i64, ptr %slot88, align 8
  %cond988 = icmp ne i64 %v987, 0
  br i1 %cond988, label %bb_arm22, label %bb_armnext22
bb_arm22:
  br label %bb_i226
bb_armnext22:
  %v989 = load i64, ptr %slot68, align 8
  %cmp990 = icmp eq i64 %v989, 20
  %cv991 = zext i1 %cmp990 to i64
  store i64 %cv991, ptr %slot89, align 8
  %v992 = load i64, ptr %slot89, align 8
  %cond993 = icmp ne i64 %v992, 0
  br i1 %cond993, label %bb_arm23, label %bb_armnext23
bb_arm23:
  br label %bb_i238
bb_armnext23:
  %v994 = load i64, ptr %slot68, align 8
  %cmp995 = icmp eq i64 %v994, 21
  %cv996 = zext i1 %cmp995 to i64
  store i64 %cv996, ptr %slot90, align 8
  %v997 = load i64, ptr %slot90, align 8
  %cond998 = icmp ne i64 %v997, 0
  br i1 %cond998, label %bb_arm24, label %bb_armnext24
bb_arm24:
  br label %bb_i250
bb_armnext24:
  %v999 = load i64, ptr %slot68, align 8
  %cmp1000 = icmp eq i64 %v999, 22
  %cv1001 = zext i1 %cmp1000 to i64
  store i64 %cv1001, ptr %slot91, align 8
  %v1002 = load i64, ptr %slot91, align 8
  %cond1003 = icmp ne i64 %v1002, 0
  br i1 %cond1003, label %bb_arm25, label %bb_armnext25
bb_arm25:
  br label %bb_i262
bb_armnext25:
  %v1004 = load i64, ptr %slot68, align 8
  %cmp1005 = icmp eq i64 %v1004, 23
  %cv1006 = zext i1 %cmp1005 to i64
  store i64 %cv1006, ptr %slot92, align 8
  %v1007 = load i64, ptr %slot92, align 8
  %cond1008 = icmp ne i64 %v1007, 0
  br i1 %cond1008, label %bb_arm26, label %bb_armnext26
bb_arm26:
  br label %bb_i274
bb_armnext26:
  %v1009 = load i64, ptr %slot68, align 8
  %cmp1010 = icmp eq i64 %v1009, 24
  %cv1011 = zext i1 %cmp1010 to i64
  store i64 %cv1011, ptr %slot93, align 8
  %v1012 = load i64, ptr %slot93, align 8
  %cond1013 = icmp ne i64 %v1012, 0
  br i1 %cond1013, label %bb_arm27, label %bb_armnext27
bb_arm27:
  br label %bb_i286
bb_armnext27:
  %v1014 = load i64, ptr %slot68, align 8
  %cmp1015 = icmp eq i64 %v1014, 25
  %cv1016 = zext i1 %cmp1015 to i64
  store i64 %cv1016, ptr %slot94, align 8
  %v1017 = load i64, ptr %slot94, align 8
  %cond1018 = icmp ne i64 %v1017, 0
  br i1 %cond1018, label %bb_arm28, label %bb_armnext28
bb_arm28:
  br label %bb_i298
bb_armnext28:
  %v1019 = load i64, ptr %slot68, align 8
  %cmp1020 = icmp eq i64 %v1019, 26
  %cv1021 = zext i1 %cmp1020 to i64
  store i64 %cv1021, ptr %slot95, align 8
  %v1022 = load i64, ptr %slot95, align 8
  %cond1023 = icmp ne i64 %v1022, 0
  br i1 %cond1023, label %bb_arm29, label %bb_armnext29
bb_arm29:
  br label %bb_i310
bb_armnext29:
  %v1024 = load i64, ptr %slot68, align 8
  %cmp1025 = icmp eq i64 %v1024, 27
  %cv1026 = zext i1 %cmp1025 to i64
  store i64 %cv1026, ptr %slot96, align 8
  %v1027 = load i64, ptr %slot96, align 8
  %cond1028 = icmp ne i64 %v1027, 0
  br i1 %cond1028, label %bb_arm30, label %bb_armnext30
bb_arm30:
  br label %bb_i322
bb_armnext30:
  %v1029 = load i64, ptr %slot68, align 8
  %cmp1030 = icmp eq i64 %v1029, 28
  %cv1031 = zext i1 %cmp1030 to i64
  store i64 %cv1031, ptr %slot97, align 8
  %v1032 = load i64, ptr %slot97, align 8
  %cond1033 = icmp ne i64 %v1032, 0
  br i1 %cond1033, label %bb_arm31, label %bb_armnext31
bb_arm31:
  br label %bb_i334
bb_armnext31:
  %v1034 = load i64, ptr %slot68, align 8
  %cmp1035 = icmp eq i64 %v1034, 29
  %cv1036 = zext i1 %cmp1035 to i64
  store i64 %cv1036, ptr %slot98, align 8
  %v1037 = load i64, ptr %slot98, align 8
  %cond1038 = icmp ne i64 %v1037, 0
  br i1 %cond1038, label %bb_arm32, label %bb_armnext32
bb_arm32:
  br label %bb_i346
bb_armnext32:
  %v1039 = load i64, ptr %slot68, align 8
  %cmp1040 = icmp eq i64 %v1039, 30
  %cv1041 = zext i1 %cmp1040 to i64
  store i64 %cv1041, ptr %slot99, align 8
  %v1042 = load i64, ptr %slot99, align 8
  %cond1043 = icmp ne i64 %v1042, 0
  br i1 %cond1043, label %bb_arm33, label %bb_armnext33
bb_arm33:
  br label %bb_i358
bb_armnext33:
  %v1044 = load i64, ptr %slot68, align 8
  %cmp1045 = icmp eq i64 %v1044, 31
  %cv1046 = zext i1 %cmp1045 to i64
  store i64 %cv1046, ptr %slot100, align 8
  %v1047 = load i64, ptr %slot100, align 8
  %cond1048 = icmp ne i64 %v1047, 0
  br i1 %cond1048, label %bb_arm34, label %bb_armnext34
bb_arm34:
  br label %bb_i370
bb_armnext34:
  %v1049 = load i64, ptr %slot68, align 8
  %cmp1050 = icmp eq i64 %v1049, 32
  %cv1051 = zext i1 %cmp1050 to i64
  store i64 %cv1051, ptr %slot101, align 8
  %v1052 = load i64, ptr %slot101, align 8
  %cond1053 = icmp ne i64 %v1052, 0
  br i1 %cond1053, label %bb_arm35, label %bb_armnext35
bb_arm35:
  br label %bb_i382
bb_armnext35:
  %v1054 = load i64, ptr %slot68, align 8
  %cmp1055 = icmp eq i64 %v1054, 33
  %cv1056 = zext i1 %cmp1055 to i64
  store i64 %cv1056, ptr %slot102, align 8
  %v1057 = load i64, ptr %slot102, align 8
  %cond1058 = icmp ne i64 %v1057, 0
  br i1 %cond1058, label %bb_arm36, label %bb_armnext36
bb_arm36:
  br label %bb_i394
bb_armnext36:
  %v1059 = load i64, ptr %slot68, align 8
  %cmp1060 = icmp eq i64 %v1059, 34
  %cv1061 = zext i1 %cmp1060 to i64
  store i64 %cv1061, ptr %slot103, align 8
  %v1062 = load i64, ptr %slot103, align 8
  %cond1063 = icmp ne i64 %v1062, 0
  br i1 %cond1063, label %bb_arm37, label %bb_armnext37
bb_arm37:
  br label %bb_i406
bb_armnext37:
  %v1064 = load i64, ptr %slot68, align 8
  %cmp1065 = icmp eq i64 %v1064, 35
  %cv1066 = zext i1 %cmp1065 to i64
  store i64 %cv1066, ptr %slot104, align 8
  %v1067 = load i64, ptr %slot104, align 8
  %cond1068 = icmp ne i64 %v1067, 0
  br i1 %cond1068, label %bb_arm38, label %bb_armnext38
bb_arm38:
  br label %bb_i418
bb_armnext38:
  %v1069 = load i64, ptr %slot68, align 8
  %cmp1070 = icmp eq i64 %v1069, 36
  %cv1071 = zext i1 %cmp1070 to i64
  store i64 %cv1071, ptr %slot105, align 8
  %v1072 = load i64, ptr %slot105, align 8
  %cond1073 = icmp ne i64 %v1072, 0
  br i1 %cond1073, label %bb_arm39, label %bb_armnext39
bb_arm39:
  br label %bb_i430
bb_armnext39:
  %v1074 = load i64, ptr %slot68, align 8
  %cmp1075 = icmp eq i64 %v1074, 37
  %cv1076 = zext i1 %cmp1075 to i64
  store i64 %cv1076, ptr %slot106, align 8
  %v1077 = load i64, ptr %slot106, align 8
  %cond1078 = icmp ne i64 %v1077, 0
  br i1 %cond1078, label %bb_arm40, label %bb_armnext40
bb_arm40:
  br label %bb_i442
bb_armnext40:
  %v1079 = load i64, ptr %slot68, align 8
  %cmp1080 = icmp eq i64 %v1079, 38
  %cv1081 = zext i1 %cmp1080 to i64
  store i64 %cv1081, ptr %slot107, align 8
  %v1082 = load i64, ptr %slot107, align 8
  %cond1083 = icmp ne i64 %v1082, 0
  br i1 %cond1083, label %bb_arm41, label %bb_armnext41
bb_arm41:
  br label %bb_i454
bb_armnext41:
  %v1084 = load i64, ptr %slot68, align 8
  %cmp1085 = icmp eq i64 %v1084, 39
  %cv1086 = zext i1 %cmp1085 to i64
  store i64 %cv1086, ptr %slot108, align 8
  %v1087 = load i64, ptr %slot108, align 8
  %cond1088 = icmp ne i64 %v1087, 0
  br i1 %cond1088, label %bb_arm42, label %bb_armnext42
bb_arm42:
  br label %bb_i466
bb_armnext42:
  br label %bb_failure
bb_i2:
  %v1089 = load i64, ptr %slot8, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  %ld1091 = load i64, ptr %p1090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1091, ptr %slot109, align 8
  %v1092 = load i64, ptr %slot109, align 8
  %v1093 = load i64, ptr %slot24, align 8
  %p1094 = inttoptr i64 %v1093 to ptr
  store i64 %v1092, ptr %p1094, align 8, !alias.scope !3, !noalias !4
  %v1095 = load i64, ptr %slot24, align 8
  %p1096 = inttoptr i64 %v1095 to ptr
  %ld1097 = load i64, ptr %p1096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1097, ptr %slot110, align 8
  %v1098 = load i64, ptr %slot110, align 8
  %v1099 = load i64, ptr %slot10, align 8
  %p1100 = inttoptr i64 %v1099 to ptr
  store i64 %v1098, ptr %p1100, align 8, !alias.scope !3, !noalias !4
  %v1101 = load i64, ptr %slot9, align 8
  %p1102 = inttoptr i64 %v1101 to ptr
  %ld1103 = load i64, ptr %p1102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1103, ptr %slot111, align 8
  %v1104 = load i64, ptr %slot111, align 8
  %v1105 = load i64, ptr %slot24, align 8
  %p1106 = inttoptr i64 %v1105 to ptr
  store i64 %v1104, ptr %p1106, align 8, !alias.scope !3, !noalias !4
  %v1107 = load i64, ptr %slot24, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  %ld1109 = load i64, ptr %p1108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1109, ptr %slot112, align 8
  %v1110 = load i64, ptr %slot112, align 8
  %v1111 = load i64, ptr %slot11, align 8
  %p1112 = inttoptr i64 %v1111 to ptr
  store i64 %v1110, ptr %p1112, align 8, !alias.scope !3, !noalias !4
  %v1113 = load i64, ptr %slot11, align 8
  %p1114 = inttoptr i64 %v1113 to ptr
  %ld1115 = load i64, ptr %p1114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1115, ptr %slot113, align 8
  %v1116 = load i64, ptr %slot113, align 8
  %v1117 = load i64, ptr %slot24, align 8
  %p1118 = inttoptr i64 %v1117 to ptr
  store i64 %v1116, ptr %p1118, align 8, !alias.scope !3, !noalias !4
  %v1119 = load i64, ptr %slot10, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  %ld1121 = load i64, ptr %p1120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1121, ptr %slot114, align 8
  %v1122 = load i64, ptr %slot114, align 8
  %v1123 = load i64, ptr %slot25, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  store i64 %v1122, ptr %p1124, align 8, !alias.scope !3, !noalias !4
  %v1125 = load i64, ptr %slot25, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  %ld1127 = load i64, ptr %p1126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1127, ptr %slot115, align 8
  %v1128 = load i64, ptr %slot24, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %ld1130 = load i64, ptr %p1129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1130, ptr %slot116, align 8
  %v1131 = load i64, ptr %slot116, align 8
  %cast1132 = bitcast i64 %v1131 to double
  store double %cast1132, ptr %slot117, align 8
  %v1133 = load i64, ptr %slot115, align 8
  %cast1134 = bitcast i64 %v1133 to double
  store double %cast1134, ptr %slot118, align 8
  %v1135 = load double, ptr %slot117, align 8
  %v1136 = load double, ptr %slot118, align 8
  %cmp1137 = fcmp olt double %v1135, %v1136
  %cv1138 = zext i1 %cmp1137 to i64
  store i64 %cv1138, ptr %slot119, align 8
  %v1139 = load i64, ptr %slot119, align 8
  %v1140 = load i64, ptr %slot24, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  store i64 %v1139, ptr %p1141, align 8, !alias.scope !3, !noalias !4
  %v1142 = load i64, ptr %slot26, align 8
  store i64 %v1142, ptr %slot120, align 8
  %v1143 = load i64, ptr %slot120, align 8
  %p1144 = inttoptr i64 %v1143 to ptr
  store i32 1, ptr %p1144, align 4, !alias.scope !3, !noalias !4
  %v1145 = load i64, ptr %slot120, align 8
  %p1147 = inttoptr i64 %v1145 to ptr
  %gep1148 = getelementptr i8, ptr %p1147, i64 8
  %op1146 = ptrtoint ptr %gep1148 to i64
  store i64 %op1146, ptr %slot121, align 8
  %v1149 = load i64, ptr %slot24, align 8
  %p1150 = inttoptr i64 %v1149 to ptr
  %ld1151 = load i64, ptr %p1150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1151, ptr %slot122, align 8
  %v1152 = load i64, ptr %slot122, align 8
  %cv1153 = trunc i64 %v1152 to i8
  %v1154 = load i64, ptr %slot121, align 8
  %p1155 = inttoptr i64 %v1154 to ptr
  store i8 %cv1153, ptr %p1155, align 1, !alias.scope !3, !noalias !4
  %v1156 = load i64, ptr %slot120, align 8
  %v1157 = load i64, ptr %slot24, align 8
  %p1158 = inttoptr i64 %v1157 to ptr
  store i64 %v1156, ptr %p1158, align 8, !alias.scope !3, !noalias !4
  %v1159 = load i64, ptr %slot24, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  %ld1161 = load i64, ptr %p1160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1161, ptr %slot123, align 8
  %v1162 = load i64, ptr %slot123, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  %ret1164 = load { i64, i64 }, ptr %p1163, align 8
  ret { i64, i64 } %ret1164
bb_i13:
  %v1165 = load i64, ptr %slot8, align 8
  %p1166 = inttoptr i64 %v1165 to ptr
  %ld1167 = load i64, ptr %p1166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1167, ptr %slot124, align 8
  %v1168 = load i64, ptr %slot124, align 8
  %v1169 = load i64, ptr %slot24, align 8
  %p1170 = inttoptr i64 %v1169 to ptr
  store i64 %v1168, ptr %p1170, align 8, !alias.scope !3, !noalias !4
  %v1171 = load i64, ptr %slot24, align 8
  %p1172 = inttoptr i64 %v1171 to ptr
  %ld1173 = load i64, ptr %p1172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1173, ptr %slot125, align 8
  %v1174 = load i64, ptr %slot125, align 8
  %v1175 = load i64, ptr %slot12, align 8
  %p1176 = inttoptr i64 %v1175 to ptr
  store i64 %v1174, ptr %p1176, align 8, !alias.scope !3, !noalias !4
  %v1177 = load i64, ptr %slot9, align 8
  %p1178 = inttoptr i64 %v1177 to ptr
  %ld1179 = load i64, ptr %p1178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1179, ptr %slot126, align 8
  %v1180 = load i64, ptr %slot126, align 8
  %v1181 = load i64, ptr %slot24, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  store i64 %v1180, ptr %p1182, align 8, !alias.scope !3, !noalias !4
  %v1183 = load i64, ptr %slot24, align 8
  %p1184 = inttoptr i64 %v1183 to ptr
  %ld1185 = load i64, ptr %p1184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1185, ptr %slot127, align 8
  %v1186 = load i64, ptr %slot127, align 8
  %v1187 = load i64, ptr %slot13, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  store i64 %v1186, ptr %p1188, align 8, !alias.scope !3, !noalias !4
  %v1189 = load i64, ptr %slot13, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  %ld1191 = load i64, ptr %p1190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1191, ptr %slot128, align 8
  %v1192 = load i64, ptr %slot128, align 8
  %v1193 = load i64, ptr %slot24, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i64 %v1192, ptr %p1194, align 8, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot12, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %ld1197 = load i64, ptr %p1196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1197, ptr %slot129, align 8
  %v1198 = load i64, ptr %slot129, align 8
  %v1199 = load i64, ptr %slot25, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  store i64 %v1198, ptr %p1200, align 8, !alias.scope !3, !noalias !4
  %v1201 = load i64, ptr %slot25, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %ld1203 = load i64, ptr %p1202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1203, ptr %slot130, align 8
  %v1204 = load i64, ptr %slot24, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  %ld1206 = load i64, ptr %p1205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1206, ptr %slot131, align 8
  %v1207 = load i64, ptr %slot131, align 8
  %cast1208 = bitcast i64 %v1207 to double
  store double %cast1208, ptr %slot132, align 8
  %v1209 = load i64, ptr %slot130, align 8
  %cast1210 = bitcast i64 %v1209 to double
  store double %cast1210, ptr %slot133, align 8
  %v1211 = load double, ptr %slot132, align 8
  %v1212 = load double, ptr %slot133, align 8
  %cmp1213 = fcmp ole double %v1211, %v1212
  %cv1214 = zext i1 %cmp1213 to i64
  store i64 %cv1214, ptr %slot134, align 8
  %v1215 = load i64, ptr %slot134, align 8
  %v1216 = load i64, ptr %slot24, align 8
  %p1217 = inttoptr i64 %v1216 to ptr
  store i64 %v1215, ptr %p1217, align 8, !alias.scope !3, !noalias !4
  %v1218 = load i64, ptr %slot27, align 8
  store i64 %v1218, ptr %slot135, align 8
  %v1219 = load i64, ptr %slot135, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  store i32 1, ptr %p1220, align 4, !alias.scope !3, !noalias !4
  %v1221 = load i64, ptr %slot135, align 8
  %p1223 = inttoptr i64 %v1221 to ptr
  %gep1224 = getelementptr i8, ptr %p1223, i64 8
  %op1222 = ptrtoint ptr %gep1224 to i64
  store i64 %op1222, ptr %slot136, align 8
  %v1225 = load i64, ptr %slot24, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  %ld1227 = load i64, ptr %p1226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1227, ptr %slot137, align 8
  %v1228 = load i64, ptr %slot137, align 8
  %cv1229 = trunc i64 %v1228 to i8
  %v1230 = load i64, ptr %slot136, align 8
  %p1231 = inttoptr i64 %v1230 to ptr
  store i8 %cv1229, ptr %p1231, align 1, !alias.scope !3, !noalias !4
  %v1232 = load i64, ptr %slot135, align 8
  %v1233 = load i64, ptr %slot24, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  store i64 %v1232, ptr %p1234, align 8, !alias.scope !3, !noalias !4
  %v1235 = load i64, ptr %slot24, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  %ld1237 = load i64, ptr %p1236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1237, ptr %slot138, align 8
  %v1238 = load i64, ptr %slot138, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  %ret1240 = load { i64, i64 }, ptr %p1239, align 8
  ret { i64, i64 } %ret1240
bb_i24:
  %v1241 = load i64, ptr %slot8, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %ld1243 = load i64, ptr %p1242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1243, ptr %slot139, align 8
  %v1244 = load i64, ptr %slot139, align 8
  %v1245 = load i64, ptr %slot24, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  store i64 %v1244, ptr %p1246, align 8, !alias.scope !3, !noalias !4
  %v1247 = load i64, ptr %slot24, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  %ld1249 = load i64, ptr %p1248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1249, ptr %slot140, align 8
  %v1250 = load i64, ptr %slot140, align 8
  %v1251 = load i64, ptr %slot14, align 8
  %p1252 = inttoptr i64 %v1251 to ptr
  store i64 %v1250, ptr %p1252, align 8, !alias.scope !3, !noalias !4
  %v1253 = load i64, ptr %slot9, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  %ld1255 = load i64, ptr %p1254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1255, ptr %slot141, align 8
  %v1256 = load i64, ptr %slot141, align 8
  %v1257 = load i64, ptr %slot24, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  store i64 %v1256, ptr %p1258, align 8, !alias.scope !3, !noalias !4
  %v1259 = load i64, ptr %slot24, align 8
  %p1260 = inttoptr i64 %v1259 to ptr
  %ld1261 = load i64, ptr %p1260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1261, ptr %slot142, align 8
  %v1262 = load i64, ptr %slot142, align 8
  %v1263 = load i64, ptr %slot15, align 8
  %p1264 = inttoptr i64 %v1263 to ptr
  store i64 %v1262, ptr %p1264, align 8, !alias.scope !3, !noalias !4
  %v1265 = load i64, ptr %slot14, align 8
  %p1266 = inttoptr i64 %v1265 to ptr
  %ld1267 = load i64, ptr %p1266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1267, ptr %slot143, align 8
  %v1268 = load i64, ptr %slot143, align 8
  %v1269 = load i64, ptr %slot24, align 8
  %p1270 = inttoptr i64 %v1269 to ptr
  store i64 %v1268, ptr %p1270, align 8, !alias.scope !3, !noalias !4
  %v1271 = load i64, ptr %slot15, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  %ld1273 = load i64, ptr %p1272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1273, ptr %slot144, align 8
  %v1274 = load i64, ptr %slot144, align 8
  %v1275 = load i64, ptr %slot25, align 8
  %p1276 = inttoptr i64 %v1275 to ptr
  store i64 %v1274, ptr %p1276, align 8, !alias.scope !3, !noalias !4
  %v1277 = load i64, ptr %slot25, align 8
  %p1278 = inttoptr i64 %v1277 to ptr
  %ld1279 = load i64, ptr %p1278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1279, ptr %slot145, align 8
  %v1280 = load i64, ptr %slot24, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  %ld1282 = load i64, ptr %p1281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1282, ptr %slot146, align 8
  %v1283 = load i64, ptr %slot146, align 8
  %cast1284 = bitcast i64 %v1283 to double
  store double %cast1284, ptr %slot147, align 8
  %v1285 = load i64, ptr %slot145, align 8
  %cast1286 = bitcast i64 %v1285 to double
  store double %cast1286, ptr %slot148, align 8
  %v1287 = load double, ptr %slot147, align 8
  %v1288 = load double, ptr %slot148, align 8
  %cmp1289 = fcmp olt double %v1287, %v1288
  %cv1290 = zext i1 %cmp1289 to i64
  store i64 %cv1290, ptr %slot149, align 8
  %v1291 = load i64, ptr %slot149, align 8
  %v1292 = load i64, ptr %slot24, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  store i64 %v1291, ptr %p1293, align 8, !alias.scope !3, !noalias !4
  %v1294 = load i64, ptr %slot28, align 8
  store i64 %v1294, ptr %slot150, align 8
  %v1295 = load i64, ptr %slot150, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  store i32 1, ptr %p1296, align 4, !alias.scope !3, !noalias !4
  %v1297 = load i64, ptr %slot150, align 8
  %p1299 = inttoptr i64 %v1297 to ptr
  %gep1300 = getelementptr i8, ptr %p1299, i64 8
  %op1298 = ptrtoint ptr %gep1300 to i64
  store i64 %op1298, ptr %slot151, align 8
  %v1301 = load i64, ptr %slot24, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  %ld1303 = load i64, ptr %p1302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1303, ptr %slot152, align 8
  %v1304 = load i64, ptr %slot152, align 8
  %cv1305 = trunc i64 %v1304 to i8
  %v1306 = load i64, ptr %slot151, align 8
  %p1307 = inttoptr i64 %v1306 to ptr
  store i8 %cv1305, ptr %p1307, align 1, !alias.scope !3, !noalias !4
  %v1308 = load i64, ptr %slot150, align 8
  %v1309 = load i64, ptr %slot24, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  store i64 %v1308, ptr %p1310, align 8, !alias.scope !3, !noalias !4
  %v1311 = load i64, ptr %slot24, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  %ld1313 = load i64, ptr %p1312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1313, ptr %slot153, align 8
  %v1314 = load i64, ptr %slot153, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %ret1316 = load { i64, i64 }, ptr %p1315, align 8
  ret { i64, i64 } %ret1316
bb_i35:
  %v1317 = load i64, ptr %slot8, align 8
  %p1318 = inttoptr i64 %v1317 to ptr
  %ld1319 = load i64, ptr %p1318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1319, ptr %slot154, align 8
  %v1320 = load i64, ptr %slot154, align 8
  %v1321 = load i64, ptr %slot24, align 8
  %p1322 = inttoptr i64 %v1321 to ptr
  store i64 %v1320, ptr %p1322, align 8, !alias.scope !3, !noalias !4
  %v1323 = load i64, ptr %slot24, align 8
  %p1324 = inttoptr i64 %v1323 to ptr
  %ld1325 = load i64, ptr %p1324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1325, ptr %slot155, align 8
  %v1326 = load i64, ptr %slot155, align 8
  %v1327 = load i64, ptr %slot16, align 8
  %p1328 = inttoptr i64 %v1327 to ptr
  store i64 %v1326, ptr %p1328, align 8, !alias.scope !3, !noalias !4
  %v1329 = load i64, ptr %slot9, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  %ld1331 = load i64, ptr %p1330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1331, ptr %slot156, align 8
  %v1332 = load i64, ptr %slot156, align 8
  %v1333 = load i64, ptr %slot24, align 8
  %p1334 = inttoptr i64 %v1333 to ptr
  store i64 %v1332, ptr %p1334, align 8, !alias.scope !3, !noalias !4
  %v1335 = load i64, ptr %slot24, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  %ld1337 = load i64, ptr %p1336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1337, ptr %slot157, align 8
  %v1338 = load i64, ptr %slot157, align 8
  %v1339 = load i64, ptr %slot17, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  store i64 %v1338, ptr %p1340, align 8, !alias.scope !3, !noalias !4
  %v1341 = load i64, ptr %slot16, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  %ld1343 = load i64, ptr %p1342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1343, ptr %slot158, align 8
  %v1344 = load i64, ptr %slot158, align 8
  %v1345 = load i64, ptr %slot24, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  store i64 %v1344, ptr %p1346, align 8, !alias.scope !3, !noalias !4
  %v1347 = load i64, ptr %slot17, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  %ld1349 = load i64, ptr %p1348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1349, ptr %slot159, align 8
  %v1350 = load i64, ptr %slot159, align 8
  %v1351 = load i64, ptr %slot25, align 8
  %p1352 = inttoptr i64 %v1351 to ptr
  store i64 %v1350, ptr %p1352, align 8, !alias.scope !3, !noalias !4
  %v1353 = load i64, ptr %slot25, align 8
  %p1354 = inttoptr i64 %v1353 to ptr
  %ld1355 = load i64, ptr %p1354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1355, ptr %slot160, align 8
  %v1356 = load i64, ptr %slot24, align 8
  %p1357 = inttoptr i64 %v1356 to ptr
  %ld1358 = load i64, ptr %p1357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1358, ptr %slot161, align 8
  %v1359 = load i64, ptr %slot161, align 8
  %cast1360 = bitcast i64 %v1359 to double
  store double %cast1360, ptr %slot162, align 8
  %v1361 = load i64, ptr %slot160, align 8
  %cast1362 = bitcast i64 %v1361 to double
  store double %cast1362, ptr %slot163, align 8
  %v1363 = load double, ptr %slot162, align 8
  %v1364 = load double, ptr %slot163, align 8
  %cmp1365 = fcmp ole double %v1363, %v1364
  %cv1366 = zext i1 %cmp1365 to i64
  store i64 %cv1366, ptr %slot164, align 8
  %v1367 = load i64, ptr %slot164, align 8
  %v1368 = load i64, ptr %slot24, align 8
  %p1369 = inttoptr i64 %v1368 to ptr
  store i64 %v1367, ptr %p1369, align 8, !alias.scope !3, !noalias !4
  %v1370 = load i64, ptr %slot29, align 8
  store i64 %v1370, ptr %slot165, align 8
  %v1371 = load i64, ptr %slot165, align 8
  %p1372 = inttoptr i64 %v1371 to ptr
  store i32 1, ptr %p1372, align 4, !alias.scope !3, !noalias !4
  %v1373 = load i64, ptr %slot165, align 8
  %p1375 = inttoptr i64 %v1373 to ptr
  %gep1376 = getelementptr i8, ptr %p1375, i64 8
  %op1374 = ptrtoint ptr %gep1376 to i64
  store i64 %op1374, ptr %slot166, align 8
  %v1377 = load i64, ptr %slot24, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  %ld1379 = load i64, ptr %p1378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1379, ptr %slot167, align 8
  %v1380 = load i64, ptr %slot167, align 8
  %cv1381 = trunc i64 %v1380 to i8
  %v1382 = load i64, ptr %slot166, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  store i8 %cv1381, ptr %p1383, align 1, !alias.scope !3, !noalias !4
  %v1384 = load i64, ptr %slot165, align 8
  %v1385 = load i64, ptr %slot24, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  store i64 %v1384, ptr %p1386, align 8, !alias.scope !3, !noalias !4
  %v1387 = load i64, ptr %slot24, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  %ld1389 = load i64, ptr %p1388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1389, ptr %slot168, align 8
  %v1390 = load i64, ptr %slot168, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  %ret1392 = load { i64, i64 }, ptr %p1391, align 8
  ret { i64, i64 } %ret1392
bb_i46:
  %v1393 = load i64, ptr %slot8, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  %ld1395 = load i64, ptr %p1394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1395, ptr %slot169, align 8
  %v1396 = load i64, ptr %slot169, align 8
  %v1397 = load i64, ptr %slot24, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i64 %v1396, ptr %p1398, align 8, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot24, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  %ld1401 = load i64, ptr %p1400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1401, ptr %slot170, align 8
  %v1402 = load i64, ptr %slot170, align 8
  %v1403 = load i64, ptr %slot18, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  store i64 %v1402, ptr %p1404, align 8, !alias.scope !3, !noalias !4
  %v1405 = load i64, ptr %slot9, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  %ld1407 = load i64, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1407, ptr %slot171, align 8
  %v1408 = load i64, ptr %slot171, align 8
  %v1409 = load i64, ptr %slot24, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  store i64 %v1408, ptr %p1410, align 8, !alias.scope !3, !noalias !4
  %v1411 = load i64, ptr %slot24, align 8
  %p1412 = inttoptr i64 %v1411 to ptr
  %ld1413 = load i64, ptr %p1412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1413, ptr %slot172, align 8
  %v1414 = load i64, ptr %slot172, align 8
  %v1415 = load i64, ptr %slot19, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  store i64 %v1414, ptr %p1416, align 8, !alias.scope !3, !noalias !4
  %v1417 = load i64, ptr %slot18, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  %ld1419 = load i64, ptr %p1418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1419, ptr %slot173, align 8
  %v1420 = load i64, ptr %slot173, align 8
  %v1421 = load i64, ptr %slot24, align 8
  %p1422 = inttoptr i64 %v1421 to ptr
  store i64 %v1420, ptr %p1422, align 8, !alias.scope !3, !noalias !4
  %v1423 = load i64, ptr %slot19, align 8
  %p1424 = inttoptr i64 %v1423 to ptr
  %ld1425 = load i64, ptr %p1424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1425, ptr %slot174, align 8
  %v1426 = load i64, ptr %slot174, align 8
  %v1427 = load i64, ptr %slot25, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i64 %v1426, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot25, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot175, align 8
  %v1432 = load i64, ptr %slot24, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  %ld1434 = load i64, ptr %p1433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1434, ptr %slot176, align 8
  %v1435 = load i64, ptr %slot176, align 8
  %cast1436 = bitcast i64 %v1435 to double
  store double %cast1436, ptr %slot177, align 8
  %v1437 = load i64, ptr %slot175, align 8
  %cast1438 = bitcast i64 %v1437 to double
  store double %cast1438, ptr %slot178, align 8
  %v1439 = load double, ptr %slot177, align 8
  %v1440 = load double, ptr %slot178, align 8
  %op1441 = fsub double %v1439, %v1440
  store double %op1441, ptr %slot179, align 8
  %v1442 = load double, ptr %slot179, align 8
  %cast1443 = bitcast double %v1442 to i64
  store i64 %cast1443, ptr %slot180, align 8
  %v1444 = load i64, ptr %slot180, align 8
  %v1445 = load i64, ptr %slot24, align 8
  %p1446 = inttoptr i64 %v1445 to ptr
  store i64 %v1444, ptr %p1446, align 8, !alias.scope !3, !noalias !4
  %v1447 = load i64, ptr %slot30, align 8
  store i64 %v1447, ptr %slot181, align 8
  %v1448 = load i64, ptr %slot181, align 8
  %p1449 = inttoptr i64 %v1448 to ptr
  store i32 2, ptr %p1449, align 4, !alias.scope !3, !noalias !4
  %v1450 = load i64, ptr %slot181, align 8
  %p1452 = inttoptr i64 %v1450 to ptr
  %gep1453 = getelementptr i8, ptr %p1452, i64 8
  %op1451 = ptrtoint ptr %gep1453 to i64
  store i64 %op1451, ptr %slot182, align 8
  %v1454 = load i64, ptr %slot24, align 8
  %p1455 = inttoptr i64 %v1454 to ptr
  %ld1456 = load i64, ptr %p1455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1456, ptr %slot183, align 8
  %v1457 = load i64, ptr %slot183, align 8
  %v1458 = load i64, ptr %slot182, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i64 %v1457, ptr %p1459, align 8, !alias.scope !3, !noalias !4
  %v1460 = load i64, ptr %slot181, align 8
  %v1461 = load i64, ptr %slot24, align 8
  %p1462 = inttoptr i64 %v1461 to ptr
  store i64 %v1460, ptr %p1462, align 8, !alias.scope !3, !noalias !4
  %v1463 = load i64, ptr %slot24, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  %ld1465 = load i64, ptr %p1464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1465, ptr %slot184, align 8
  %v1466 = load i64, ptr %slot184, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  %ret1468 = load { i64, i64 }, ptr %p1467, align 8
  ret { i64, i64 } %ret1468
bb_i58:
  %v1469 = load i64, ptr %slot8, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i64, ptr %p1470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1471, ptr %slot185, align 8
  %v1472 = load i64, ptr %slot185, align 8
  %v1473 = load i64, ptr %slot24, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  store i64 %v1472, ptr %p1474, align 8, !alias.scope !3, !noalias !4
  %v1475 = load i64, ptr %slot24, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ld1477 = load i64, ptr %p1476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1477, ptr %slot186, align 8
  %v1478 = load i64, ptr %slot186, align 8
  %v1479 = load i64, ptr %slot20, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  store i64 %v1478, ptr %p1480, align 8, !alias.scope !3, !noalias !4
  %v1481 = load i64, ptr %slot9, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  %ld1483 = load i64, ptr %p1482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1483, ptr %slot187, align 8
  %v1484 = load i64, ptr %slot187, align 8
  %v1485 = load i64, ptr %slot24, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  store i64 %v1484, ptr %p1486, align 8, !alias.scope !3, !noalias !4
  %v1487 = load i64, ptr %slot24, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  %ld1489 = load i64, ptr %p1488, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1489, ptr %slot188, align 8
  %v1490 = load i64, ptr %slot188, align 8
  %v1491 = load i64, ptr %slot21, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  store i64 %v1490, ptr %p1492, align 8, !alias.scope !3, !noalias !4
  %v1493 = load i64, ptr %slot20, align 8
  %p1494 = inttoptr i64 %v1493 to ptr
  %ld1495 = load i64, ptr %p1494, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1495, ptr %slot189, align 8
  %v1496 = load i64, ptr %slot189, align 8
  %v1497 = load i64, ptr %slot24, align 8
  %p1498 = inttoptr i64 %v1497 to ptr
  store i64 %v1496, ptr %p1498, align 8, !alias.scope !3, !noalias !4
  %v1499 = load i64, ptr %slot21, align 8
  %p1500 = inttoptr i64 %v1499 to ptr
  %ld1501 = load i64, ptr %p1500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1501, ptr %slot190, align 8
  %v1502 = load i64, ptr %slot190, align 8
  %v1503 = load i64, ptr %slot25, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  store i64 %v1502, ptr %p1504, align 8, !alias.scope !3, !noalias !4
  %v1505 = load i64, ptr %slot25, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  %ld1507 = load i64, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1507, ptr %slot191, align 8
  %v1508 = load i64, ptr %slot24, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  %ld1510 = load i64, ptr %p1509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1510, ptr %slot192, align 8
  %v1511 = load i64, ptr %slot192, align 8
  %cast1512 = bitcast i64 %v1511 to double
  store double %cast1512, ptr %slot193, align 8
  %v1513 = load i64, ptr %slot191, align 8
  %cast1514 = bitcast i64 %v1513 to double
  store double %cast1514, ptr %slot194, align 8
  %v1515 = load double, ptr %slot193, align 8
  %v1516 = load double, ptr %slot194, align 8
  %op1517 = fdiv double %v1515, %v1516
  store double %op1517, ptr %slot195, align 8
  %v1518 = load double, ptr %slot195, align 8
  %cast1519 = bitcast double %v1518 to i64
  store i64 %cast1519, ptr %slot196, align 8
  %v1520 = load i64, ptr %slot196, align 8
  %v1521 = load i64, ptr %slot24, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  store i64 %v1520, ptr %p1522, align 8, !alias.scope !3, !noalias !4
  %v1523 = load i64, ptr %slot31, align 8
  store i64 %v1523, ptr %slot197, align 8
  %v1524 = load i64, ptr %slot197, align 8
  %p1525 = inttoptr i64 %v1524 to ptr
  store i32 2, ptr %p1525, align 4, !alias.scope !3, !noalias !4
  %v1526 = load i64, ptr %slot197, align 8
  %p1528 = inttoptr i64 %v1526 to ptr
  %gep1529 = getelementptr i8, ptr %p1528, i64 8
  %op1527 = ptrtoint ptr %gep1529 to i64
  store i64 %op1527, ptr %slot198, align 8
  %v1530 = load i64, ptr %slot24, align 8
  %p1531 = inttoptr i64 %v1530 to ptr
  %ld1532 = load i64, ptr %p1531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1532, ptr %slot199, align 8
  %v1533 = load i64, ptr %slot199, align 8
  %v1534 = load i64, ptr %slot198, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  store i64 %v1533, ptr %p1535, align 8, !alias.scope !3, !noalias !4
  %v1536 = load i64, ptr %slot197, align 8
  %v1537 = load i64, ptr %slot24, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  store i64 %v1536, ptr %p1538, align 8, !alias.scope !3, !noalias !4
  %v1539 = load i64, ptr %slot24, align 8
  %p1540 = inttoptr i64 %v1539 to ptr
  %ld1541 = load i64, ptr %p1540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1541, ptr %slot200, align 8
  %v1542 = load i64, ptr %slot200, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  %ret1544 = load { i64, i64 }, ptr %p1543, align 8
  ret { i64, i64 } %ret1544
bb_i70:
  %v1545 = load i64, ptr %slot8, align 8
  %p1546 = inttoptr i64 %v1545 to ptr
  %ld1547 = load i64, ptr %p1546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1547, ptr %slot201, align 8
  %v1548 = load i64, ptr %slot201, align 8
  %v1549 = load i64, ptr %slot24, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  store i64 %v1548, ptr %p1550, align 8, !alias.scope !3, !noalias !4
  %v1551 = load i64, ptr %slot24, align 8
  %p1552 = inttoptr i64 %v1551 to ptr
  %ld1553 = load i64, ptr %p1552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1553, ptr %slot202, align 8
  %v1554 = load i64, ptr %slot202, align 8
  %v1555 = load i64, ptr %slot22, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  store i64 %v1554, ptr %p1556, align 8, !alias.scope !3, !noalias !4
  %v1557 = load i64, ptr %slot9, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  %ld1559 = load i64, ptr %p1558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1559, ptr %slot203, align 8
  %v1560 = load i64, ptr %slot203, align 8
  %v1561 = load i64, ptr %slot24, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  store i64 %v1560, ptr %p1562, align 8, !alias.scope !3, !noalias !4
  %v1563 = load i64, ptr %slot24, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  %ld1565 = load i64, ptr %p1564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1565, ptr %slot204, align 8
  %v1566 = load i64, ptr %slot204, align 8
  %v1567 = load i64, ptr %slot23, align 8
  %p1568 = inttoptr i64 %v1567 to ptr
  store i64 %v1566, ptr %p1568, align 8, !alias.scope !3, !noalias !4
  %v1569 = load i64, ptr %slot22, align 8
  %p1570 = inttoptr i64 %v1569 to ptr
  %ld1571 = load i64, ptr %p1570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1571, ptr %slot205, align 8
  %v1572 = load i64, ptr %slot205, align 8
  %v1573 = load i64, ptr %slot24, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i64 %v1572, ptr %p1574, align 8, !alias.scope !3, !noalias !4
  %v1575 = load i64, ptr %slot23, align 8
  %p1576 = inttoptr i64 %v1575 to ptr
  %ld1577 = load i64, ptr %p1576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1577, ptr %slot206, align 8
  %v1578 = load i64, ptr %slot206, align 8
  %v1579 = load i64, ptr %slot25, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  store i64 %v1578, ptr %p1580, align 8, !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot25, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  %ld1583 = load i64, ptr %p1582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1583, ptr %slot207, align 8
  %v1584 = load i64, ptr %slot24, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %ld1586 = load i64, ptr %p1585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1586, ptr %slot208, align 8
  %v1587 = load i64, ptr %slot208, align 8
  %cast1588 = bitcast i64 %v1587 to double
  store double %cast1588, ptr %slot209, align 8
  %v1589 = load i64, ptr %slot207, align 8
  %cast1590 = bitcast i64 %v1589 to double
  store double %cast1590, ptr %slot210, align 8
  %v1591 = load double, ptr %slot209, align 8
  %v1592 = load double, ptr %slot210, align 8
  %op1593 = fmul double %v1591, %v1592
  store double %op1593, ptr %slot211, align 8
  %v1594 = load double, ptr %slot211, align 8
  %cast1595 = bitcast double %v1594 to i64
  store i64 %cast1595, ptr %slot212, align 8
  %v1596 = load i64, ptr %slot212, align 8
  %v1597 = load i64, ptr %slot24, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  store i64 %v1596, ptr %p1598, align 8, !alias.scope !3, !noalias !4
  %v1599 = load i64, ptr %slot32, align 8
  store i64 %v1599, ptr %slot213, align 8
  %v1600 = load i64, ptr %slot213, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  store i32 2, ptr %p1601, align 4, !alias.scope !3, !noalias !4
  %v1602 = load i64, ptr %slot213, align 8
  %p1604 = inttoptr i64 %v1602 to ptr
  %gep1605 = getelementptr i8, ptr %p1604, i64 8
  %op1603 = ptrtoint ptr %gep1605 to i64
  store i64 %op1603, ptr %slot214, align 8
  %v1606 = load i64, ptr %slot24, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %ld1608 = load i64, ptr %p1607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1608, ptr %slot215, align 8
  %v1609 = load i64, ptr %slot215, align 8
  %v1610 = load i64, ptr %slot214, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  store i64 %v1609, ptr %p1611, align 8, !alias.scope !3, !noalias !4
  %v1612 = load i64, ptr %slot213, align 8
  %v1613 = load i64, ptr %slot24, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  store i64 %v1612, ptr %p1614, align 8, !alias.scope !3, !noalias !4
  %v1615 = load i64, ptr %slot24, align 8
  %p1616 = inttoptr i64 %v1615 to ptr
  %ld1617 = load i64, ptr %p1616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1617, ptr %slot216, align 8
  %v1618 = load i64, ptr %slot216, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  %ret1620 = load { i64, i64 }, ptr %p1619, align 8
  ret { i64, i64 } %ret1620
bb_i82:
  %v1621 = load i64, ptr %slot8, align 8
  %p1622 = inttoptr i64 %v1621 to ptr
  %ld1623 = load i64, ptr %p1622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1623, ptr %slot217, align 8
  %v1624 = load i64, ptr %slot217, align 8
  %v1625 = load i64, ptr %slot24, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  store i64 %v1624, ptr %p1626, align 8, !alias.scope !3, !noalias !4
  %v1627 = load i64, ptr %slot24, align 8
  %p1628 = inttoptr i64 %v1627 to ptr
  %ld1629 = load i64, ptr %p1628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1629, ptr %slot218, align 8
  %v1630 = load i64, ptr %slot218, align 8
  %v1631 = load i64, ptr %slot22, align 8
  %p1632 = inttoptr i64 %v1631 to ptr
  store i64 %v1630, ptr %p1632, align 8, !alias.scope !3, !noalias !4
  %v1633 = load i64, ptr %slot9, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  %ld1635 = load i64, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1635, ptr %slot219, align 8
  %v1636 = load i64, ptr %slot219, align 8
  %v1637 = load i64, ptr %slot24, align 8
  %p1638 = inttoptr i64 %v1637 to ptr
  store i64 %v1636, ptr %p1638, align 8, !alias.scope !3, !noalias !4
  %v1639 = load i64, ptr %slot24, align 8
  %p1640 = inttoptr i64 %v1639 to ptr
  %ld1641 = load i64, ptr %p1640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1641, ptr %slot220, align 8
  %v1642 = load i64, ptr %slot220, align 8
  %v1643 = load i64, ptr %slot23, align 8
  %p1644 = inttoptr i64 %v1643 to ptr
  store i64 %v1642, ptr %p1644, align 8, !alias.scope !3, !noalias !4
  %v1645 = load i64, ptr %slot22, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  %ld1647 = load i64, ptr %p1646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1647, ptr %slot221, align 8
  %v1648 = load i64, ptr %slot221, align 8
  %v1649 = load i64, ptr %slot24, align 8
  %p1650 = inttoptr i64 %v1649 to ptr
  store i64 %v1648, ptr %p1650, align 8, !alias.scope !3, !noalias !4
  %v1651 = load i64, ptr %slot23, align 8
  %p1652 = inttoptr i64 %v1651 to ptr
  %ld1653 = load i64, ptr %p1652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1653, ptr %slot222, align 8
  %v1654 = load i64, ptr %slot222, align 8
  %v1655 = load i64, ptr %slot25, align 8
  %p1656 = inttoptr i64 %v1655 to ptr
  store i64 %v1654, ptr %p1656, align 8, !alias.scope !3, !noalias !4
  %v1657 = load i64, ptr %slot25, align 8
  %p1658 = inttoptr i64 %v1657 to ptr
  %ld1659 = load i64, ptr %p1658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1659, ptr %slot223, align 8
  %v1660 = load i64, ptr %slot24, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  %ld1662 = load i64, ptr %p1661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1662, ptr %slot224, align 8
  %v1663 = load i64, ptr %slot224, align 8
  %cast1664 = bitcast i64 %v1663 to double
  store double %cast1664, ptr %slot225, align 8
  %v1665 = load i64, ptr %slot223, align 8
  %cast1666 = bitcast i64 %v1665 to double
  store double %cast1666, ptr %slot226, align 8
  %v1667 = load double, ptr %slot225, align 8
  %v1668 = load double, ptr %slot226, align 8
  %op1669 = fmul double %v1667, %v1668
  store double %op1669, ptr %slot227, align 8
  %v1670 = load double, ptr %slot227, align 8
  %cast1671 = bitcast double %v1670 to i64
  store i64 %cast1671, ptr %slot228, align 8
  %v1672 = load i64, ptr %slot228, align 8
  %v1673 = load i64, ptr %slot24, align 8
  %p1674 = inttoptr i64 %v1673 to ptr
  store i64 %v1672, ptr %p1674, align 8, !alias.scope !3, !noalias !4
  %v1675 = load i64, ptr %slot33, align 8
  store i64 %v1675, ptr %slot229, align 8
  %v1676 = load i64, ptr %slot229, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  store i32 2, ptr %p1677, align 4, !alias.scope !3, !noalias !4
  %v1678 = load i64, ptr %slot229, align 8
  %p1680 = inttoptr i64 %v1678 to ptr
  %gep1681 = getelementptr i8, ptr %p1680, i64 8
  %op1679 = ptrtoint ptr %gep1681 to i64
  store i64 %op1679, ptr %slot230, align 8
  %v1682 = load i64, ptr %slot24, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  %ld1684 = load i64, ptr %p1683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1684, ptr %slot231, align 8
  %v1685 = load i64, ptr %slot231, align 8
  %v1686 = load i64, ptr %slot230, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  store i64 %v1685, ptr %p1687, align 8, !alias.scope !3, !noalias !4
  %v1688 = load i64, ptr %slot229, align 8
  %v1689 = load i64, ptr %slot24, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i64 %v1688, ptr %p1690, align 8, !alias.scope !3, !noalias !4
  %v1691 = load i64, ptr %slot24, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %ld1693 = load i64, ptr %p1692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1693, ptr %slot232, align 8
  %v1694 = load i64, ptr %slot232, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  %ret1696 = load { i64, i64 }, ptr %p1695, align 8
  ret { i64, i64 } %ret1696
bb_i94:
  %v1697 = load i64, ptr %slot8, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  %ld1699 = load i64, ptr %p1698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1699, ptr %slot233, align 8
  %v1700 = load i64, ptr %slot233, align 8
  %v1701 = load i64, ptr %slot24, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  store i64 %v1700, ptr %p1702, align 8, !alias.scope !3, !noalias !4
  %v1703 = load i64, ptr %slot24, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  %ld1705 = load i64, ptr %p1704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1705, ptr %slot234, align 8
  %v1706 = load i64, ptr %slot234, align 8
  %v1707 = load i64, ptr %slot22, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  store i64 %v1706, ptr %p1708, align 8, !alias.scope !3, !noalias !4
  %v1709 = load i64, ptr %slot9, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  %ld1711 = load i64, ptr %p1710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1711, ptr %slot235, align 8
  %v1712 = load i64, ptr %slot235, align 8
  %v1713 = load i64, ptr %slot24, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  store i64 %v1712, ptr %p1714, align 8, !alias.scope !3, !noalias !4
  %v1715 = load i64, ptr %slot24, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  %ld1717 = load i64, ptr %p1716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1717, ptr %slot236, align 8
  %v1718 = load i64, ptr %slot236, align 8
  %v1719 = load i64, ptr %slot23, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  store i64 %v1718, ptr %p1720, align 8, !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot22, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  %ld1723 = load i64, ptr %p1722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1723, ptr %slot237, align 8
  %v1724 = load i64, ptr %slot237, align 8
  %v1725 = load i64, ptr %slot24, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i64 %v1724, ptr %p1726, align 8, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot23, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  %ld1729 = load i64, ptr %p1728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1729, ptr %slot238, align 8
  %v1730 = load i64, ptr %slot238, align 8
  %v1731 = load i64, ptr %slot25, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i64 %v1730, ptr %p1732, align 8, !alias.scope !3, !noalias !4
  %v1733 = load i64, ptr %slot25, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  %ld1735 = load i64, ptr %p1734, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1735, ptr %slot239, align 8
  %v1736 = load i64, ptr %slot24, align 8
  %p1737 = inttoptr i64 %v1736 to ptr
  %ld1738 = load i64, ptr %p1737, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1738, ptr %slot240, align 8
  %v1739 = load i64, ptr %slot240, align 8
  %cast1740 = bitcast i64 %v1739 to double
  store double %cast1740, ptr %slot241, align 8
  %v1741 = load i64, ptr %slot239, align 8
  %cast1742 = bitcast i64 %v1741 to double
  store double %cast1742, ptr %slot242, align 8
  %v1743 = load double, ptr %slot241, align 8
  %v1744 = load double, ptr %slot242, align 8
  %op1745 = fmul double %v1743, %v1744
  store double %op1745, ptr %slot243, align 8
  %v1746 = load double, ptr %slot243, align 8
  %cast1747 = bitcast double %v1746 to i64
  store i64 %cast1747, ptr %slot244, align 8
  %v1748 = load i64, ptr %slot244, align 8
  %v1749 = load i64, ptr %slot24, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  store i64 %v1748, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  %v1751 = load i64, ptr %slot34, align 8
  store i64 %v1751, ptr %slot245, align 8
  %v1752 = load i64, ptr %slot245, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i32 2, ptr %p1753, align 4, !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot245, align 8
  %p1756 = inttoptr i64 %v1754 to ptr
  %gep1757 = getelementptr i8, ptr %p1756, i64 8
  %op1755 = ptrtoint ptr %gep1757 to i64
  store i64 %op1755, ptr %slot246, align 8
  %v1758 = load i64, ptr %slot24, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %ld1760 = load i64, ptr %p1759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1760, ptr %slot247, align 8
  %v1761 = load i64, ptr %slot247, align 8
  %v1762 = load i64, ptr %slot246, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  store i64 %v1761, ptr %p1763, align 8, !alias.scope !3, !noalias !4
  %v1764 = load i64, ptr %slot245, align 8
  %v1765 = load i64, ptr %slot24, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  store i64 %v1764, ptr %p1766, align 8, !alias.scope !3, !noalias !4
  %v1767 = load i64, ptr %slot24, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %ld1769 = load i64, ptr %p1768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1769, ptr %slot248, align 8
  %v1770 = load i64, ptr %slot248, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  %ret1772 = load { i64, i64 }, ptr %p1771, align 8
  ret { i64, i64 } %ret1772
bb_i106:
  %v1773 = load i64, ptr %slot8, align 8
  %p1774 = inttoptr i64 %v1773 to ptr
  %ld1775 = load i64, ptr %p1774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1775, ptr %slot249, align 8
  %v1776 = load i64, ptr %slot249, align 8
  %v1777 = load i64, ptr %slot24, align 8
  %p1778 = inttoptr i64 %v1777 to ptr
  store i64 %v1776, ptr %p1778, align 8, !alias.scope !3, !noalias !4
  %v1779 = load i64, ptr %slot24, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  %ld1781 = load i64, ptr %p1780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1781, ptr %slot250, align 8
  %v1782 = load i64, ptr %slot250, align 8
  %v1783 = load i64, ptr %slot22, align 8
  %p1784 = inttoptr i64 %v1783 to ptr
  store i64 %v1782, ptr %p1784, align 8, !alias.scope !3, !noalias !4
  %v1785 = load i64, ptr %slot9, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  %ld1787 = load i64, ptr %p1786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1787, ptr %slot251, align 8
  %v1788 = load i64, ptr %slot251, align 8
  %v1789 = load i64, ptr %slot24, align 8
  %p1790 = inttoptr i64 %v1789 to ptr
  store i64 %v1788, ptr %p1790, align 8, !alias.scope !3, !noalias !4
  %v1791 = load i64, ptr %slot24, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  %ld1793 = load i64, ptr %p1792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1793, ptr %slot252, align 8
  %v1794 = load i64, ptr %slot252, align 8
  %v1795 = load i64, ptr %slot23, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  store i64 %v1794, ptr %p1796, align 8, !alias.scope !3, !noalias !4
  %v1797 = load i64, ptr %slot22, align 8
  %p1798 = inttoptr i64 %v1797 to ptr
  %ld1799 = load i64, ptr %p1798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1799, ptr %slot253, align 8
  %v1800 = load i64, ptr %slot253, align 8
  %v1801 = load i64, ptr %slot24, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  store i64 %v1800, ptr %p1802, align 8, !alias.scope !3, !noalias !4
  %v1803 = load i64, ptr %slot23, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  %ld1805 = load i64, ptr %p1804, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1805, ptr %slot254, align 8
  %v1806 = load i64, ptr %slot254, align 8
  %v1807 = load i64, ptr %slot25, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i64 %v1806, ptr %p1808, align 8, !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot25, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  %ld1811 = load i64, ptr %p1810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1811, ptr %slot255, align 8
  %v1812 = load i64, ptr %slot24, align 8
  %p1813 = inttoptr i64 %v1812 to ptr
  %ld1814 = load i64, ptr %p1813, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1814, ptr %slot256, align 8
  %v1815 = load i64, ptr %slot256, align 8
  %cast1816 = bitcast i64 %v1815 to double
  store double %cast1816, ptr %slot257, align 8
  %v1817 = load i64, ptr %slot255, align 8
  %cast1818 = bitcast i64 %v1817 to double
  store double %cast1818, ptr %slot258, align 8
  %v1819 = load double, ptr %slot257, align 8
  %v1820 = load double, ptr %slot258, align 8
  %op1821 = fmul double %v1819, %v1820
  store double %op1821, ptr %slot259, align 8
  %v1822 = load double, ptr %slot259, align 8
  %cast1823 = bitcast double %v1822 to i64
  store i64 %cast1823, ptr %slot260, align 8
  %v1824 = load i64, ptr %slot260, align 8
  %v1825 = load i64, ptr %slot24, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  store i64 %v1824, ptr %p1826, align 8, !alias.scope !3, !noalias !4
  %v1827 = load i64, ptr %slot35, align 8
  store i64 %v1827, ptr %slot261, align 8
  %v1828 = load i64, ptr %slot261, align 8
  %p1829 = inttoptr i64 %v1828 to ptr
  store i32 2, ptr %p1829, align 4, !alias.scope !3, !noalias !4
  %v1830 = load i64, ptr %slot261, align 8
  %p1832 = inttoptr i64 %v1830 to ptr
  %gep1833 = getelementptr i8, ptr %p1832, i64 8
  %op1831 = ptrtoint ptr %gep1833 to i64
  store i64 %op1831, ptr %slot262, align 8
  %v1834 = load i64, ptr %slot24, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  %ld1836 = load i64, ptr %p1835, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1836, ptr %slot263, align 8
  %v1837 = load i64, ptr %slot263, align 8
  %v1838 = load i64, ptr %slot262, align 8
  %p1839 = inttoptr i64 %v1838 to ptr
  store i64 %v1837, ptr %p1839, align 8, !alias.scope !3, !noalias !4
  %v1840 = load i64, ptr %slot261, align 8
  %v1841 = load i64, ptr %slot24, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  store i64 %v1840, ptr %p1842, align 8, !alias.scope !3, !noalias !4
  %v1843 = load i64, ptr %slot24, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  %ld1845 = load i64, ptr %p1844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1845, ptr %slot264, align 8
  %v1846 = load i64, ptr %slot264, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  %ret1848 = load { i64, i64 }, ptr %p1847, align 8
  ret { i64, i64 } %ret1848
bb_i118:
  %v1849 = load i64, ptr %slot8, align 8
  %p1850 = inttoptr i64 %v1849 to ptr
  %ld1851 = load i64, ptr %p1850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1851, ptr %slot265, align 8
  %v1852 = load i64, ptr %slot265, align 8
  %v1853 = load i64, ptr %slot24, align 8
  %p1854 = inttoptr i64 %v1853 to ptr
  store i64 %v1852, ptr %p1854, align 8, !alias.scope !3, !noalias !4
  %v1855 = load i64, ptr %slot24, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %ld1857 = load i64, ptr %p1856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1857, ptr %slot266, align 8
  %v1858 = load i64, ptr %slot266, align 8
  %v1859 = load i64, ptr %slot22, align 8
  %p1860 = inttoptr i64 %v1859 to ptr
  store i64 %v1858, ptr %p1860, align 8, !alias.scope !3, !noalias !4
  %v1861 = load i64, ptr %slot9, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  %ld1863 = load i64, ptr %p1862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1863, ptr %slot267, align 8
  %v1864 = load i64, ptr %slot267, align 8
  %v1865 = load i64, ptr %slot24, align 8
  %p1866 = inttoptr i64 %v1865 to ptr
  store i64 %v1864, ptr %p1866, align 8, !alias.scope !3, !noalias !4
  %v1867 = load i64, ptr %slot24, align 8
  %p1868 = inttoptr i64 %v1867 to ptr
  %ld1869 = load i64, ptr %p1868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1869, ptr %slot268, align 8
  %v1870 = load i64, ptr %slot268, align 8
  %v1871 = load i64, ptr %slot23, align 8
  %p1872 = inttoptr i64 %v1871 to ptr
  store i64 %v1870, ptr %p1872, align 8, !alias.scope !3, !noalias !4
  %v1873 = load i64, ptr %slot22, align 8
  %p1874 = inttoptr i64 %v1873 to ptr
  %ld1875 = load i64, ptr %p1874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1875, ptr %slot269, align 8
  %v1876 = load i64, ptr %slot269, align 8
  %v1877 = load i64, ptr %slot24, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  store i64 %v1876, ptr %p1878, align 8, !alias.scope !3, !noalias !4
  %v1879 = load i64, ptr %slot23, align 8
  %p1880 = inttoptr i64 %v1879 to ptr
  %ld1881 = load i64, ptr %p1880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1881, ptr %slot270, align 8
  %v1882 = load i64, ptr %slot270, align 8
  %v1883 = load i64, ptr %slot25, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  store i64 %v1882, ptr %p1884, align 8, !alias.scope !3, !noalias !4
  %v1885 = load i64, ptr %slot25, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  %ld1887 = load i64, ptr %p1886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1887, ptr %slot271, align 8
  %v1888 = load i64, ptr %slot24, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  %ld1890 = load i64, ptr %p1889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1890, ptr %slot272, align 8
  %v1891 = load i64, ptr %slot272, align 8
  %cast1892 = bitcast i64 %v1891 to double
  store double %cast1892, ptr %slot273, align 8
  %v1893 = load i64, ptr %slot271, align 8
  %cast1894 = bitcast i64 %v1893 to double
  store double %cast1894, ptr %slot274, align 8
  %v1895 = load double, ptr %slot273, align 8
  %v1896 = load double, ptr %slot274, align 8
  %op1897 = fmul double %v1895, %v1896
  store double %op1897, ptr %slot275, align 8
  %v1898 = load double, ptr %slot275, align 8
  %cast1899 = bitcast double %v1898 to i64
  store i64 %cast1899, ptr %slot276, align 8
  %v1900 = load i64, ptr %slot276, align 8
  %v1901 = load i64, ptr %slot24, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  store i64 %v1900, ptr %p1902, align 8, !alias.scope !3, !noalias !4
  %v1903 = load i64, ptr %slot36, align 8
  store i64 %v1903, ptr %slot277, align 8
  %v1904 = load i64, ptr %slot277, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  store i32 2, ptr %p1905, align 4, !alias.scope !3, !noalias !4
  %v1906 = load i64, ptr %slot277, align 8
  %p1908 = inttoptr i64 %v1906 to ptr
  %gep1909 = getelementptr i8, ptr %p1908, i64 8
  %op1907 = ptrtoint ptr %gep1909 to i64
  store i64 %op1907, ptr %slot278, align 8
  %v1910 = load i64, ptr %slot24, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  %ld1912 = load i64, ptr %p1911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1912, ptr %slot279, align 8
  %v1913 = load i64, ptr %slot279, align 8
  %v1914 = load i64, ptr %slot278, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i64 %v1913, ptr %p1915, align 8, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot277, align 8
  %v1917 = load i64, ptr %slot24, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  store i64 %v1916, ptr %p1918, align 8, !alias.scope !3, !noalias !4
  %v1919 = load i64, ptr %slot24, align 8
  %p1920 = inttoptr i64 %v1919 to ptr
  %ld1921 = load i64, ptr %p1920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1921, ptr %slot280, align 8
  %v1922 = load i64, ptr %slot280, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  %ret1924 = load { i64, i64 }, ptr %p1923, align 8
  ret { i64, i64 } %ret1924
bb_i130:
  %v1925 = load i64, ptr %slot8, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %ld1927 = load i64, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1927, ptr %slot281, align 8
  %v1928 = load i64, ptr %slot281, align 8
  %v1929 = load i64, ptr %slot24, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  store i64 %v1928, ptr %p1930, align 8, !alias.scope !3, !noalias !4
  %v1931 = load i64, ptr %slot24, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  %ld1933 = load i64, ptr %p1932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1933, ptr %slot282, align 8
  %v1934 = load i64, ptr %slot282, align 8
  %v1935 = load i64, ptr %slot22, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  store i64 %v1934, ptr %p1936, align 8, !alias.scope !3, !noalias !4
  %v1937 = load i64, ptr %slot9, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %ld1939 = load i64, ptr %p1938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1939, ptr %slot283, align 8
  %v1940 = load i64, ptr %slot283, align 8
  %v1941 = load i64, ptr %slot24, align 8
  %p1942 = inttoptr i64 %v1941 to ptr
  store i64 %v1940, ptr %p1942, align 8, !alias.scope !3, !noalias !4
  %v1943 = load i64, ptr %slot24, align 8
  %p1944 = inttoptr i64 %v1943 to ptr
  %ld1945 = load i64, ptr %p1944, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1945, ptr %slot284, align 8
  %v1946 = load i64, ptr %slot284, align 8
  %v1947 = load i64, ptr %slot23, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  store i64 %v1946, ptr %p1948, align 8, !alias.scope !3, !noalias !4
  %v1949 = load i64, ptr %slot22, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %ld1951 = load i64, ptr %p1950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1951, ptr %slot285, align 8
  %v1952 = load i64, ptr %slot285, align 8
  %v1953 = load i64, ptr %slot24, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i64 %v1952, ptr %p1954, align 8, !alias.scope !3, !noalias !4
  %v1955 = load i64, ptr %slot23, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  %ld1957 = load i64, ptr %p1956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1957, ptr %slot286, align 8
  %v1958 = load i64, ptr %slot286, align 8
  %v1959 = load i64, ptr %slot25, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  store i64 %v1958, ptr %p1960, align 8, !alias.scope !3, !noalias !4
  %v1961 = load i64, ptr %slot25, align 8
  %p1962 = inttoptr i64 %v1961 to ptr
  %ld1963 = load i64, ptr %p1962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1963, ptr %slot287, align 8
  %v1964 = load i64, ptr %slot24, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %ld1966 = load i64, ptr %p1965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1966, ptr %slot288, align 8
  %v1967 = load i64, ptr %slot288, align 8
  %cast1968 = bitcast i64 %v1967 to double
  store double %cast1968, ptr %slot289, align 8
  %v1969 = load i64, ptr %slot287, align 8
  %cast1970 = bitcast i64 %v1969 to double
  store double %cast1970, ptr %slot290, align 8
  %v1971 = load double, ptr %slot289, align 8
  %v1972 = load double, ptr %slot290, align 8
  %op1973 = fmul double %v1971, %v1972
  store double %op1973, ptr %slot291, align 8
  %v1974 = load double, ptr %slot291, align 8
  %cast1975 = bitcast double %v1974 to i64
  store i64 %cast1975, ptr %slot292, align 8
  %v1976 = load i64, ptr %slot292, align 8
  %v1977 = load i64, ptr %slot24, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  store i64 %v1976, ptr %p1978, align 8, !alias.scope !3, !noalias !4
  %v1979 = load i64, ptr %slot37, align 8
  store i64 %v1979, ptr %slot293, align 8
  %v1980 = load i64, ptr %slot293, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  store i32 2, ptr %p1981, align 4, !alias.scope !3, !noalias !4
  %v1982 = load i64, ptr %slot293, align 8
  %p1984 = inttoptr i64 %v1982 to ptr
  %gep1985 = getelementptr i8, ptr %p1984, i64 8
  %op1983 = ptrtoint ptr %gep1985 to i64
  store i64 %op1983, ptr %slot294, align 8
  %v1986 = load i64, ptr %slot24, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  %ld1988 = load i64, ptr %p1987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1988, ptr %slot295, align 8
  %v1989 = load i64, ptr %slot295, align 8
  %v1990 = load i64, ptr %slot294, align 8
  %p1991 = inttoptr i64 %v1990 to ptr
  store i64 %v1989, ptr %p1991, align 8, !alias.scope !3, !noalias !4
  %v1992 = load i64, ptr %slot293, align 8
  %v1993 = load i64, ptr %slot24, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  store i64 %v1992, ptr %p1994, align 8, !alias.scope !3, !noalias !4
  %v1995 = load i64, ptr %slot24, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  %ld1997 = load i64, ptr %p1996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1997, ptr %slot296, align 8
  %v1998 = load i64, ptr %slot296, align 8
  %p1999 = inttoptr i64 %v1998 to ptr
  %ret2000 = load { i64, i64 }, ptr %p1999, align 8
  ret { i64, i64 } %ret2000
bb_i142:
  %v2001 = load i64, ptr %slot8, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  %ld2003 = load i64, ptr %p2002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2003, ptr %slot297, align 8
  %v2004 = load i64, ptr %slot297, align 8
  %v2005 = load i64, ptr %slot24, align 8
  %p2006 = inttoptr i64 %v2005 to ptr
  store i64 %v2004, ptr %p2006, align 8, !alias.scope !3, !noalias !4
  %v2007 = load i64, ptr %slot24, align 8
  %p2008 = inttoptr i64 %v2007 to ptr
  %ld2009 = load i64, ptr %p2008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2009, ptr %slot298, align 8
  %v2010 = load i64, ptr %slot298, align 8
  %v2011 = load i64, ptr %slot22, align 8
  %p2012 = inttoptr i64 %v2011 to ptr
  store i64 %v2010, ptr %p2012, align 8, !alias.scope !3, !noalias !4
  %v2013 = load i64, ptr %slot9, align 8
  %p2014 = inttoptr i64 %v2013 to ptr
  %ld2015 = load i64, ptr %p2014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2015, ptr %slot299, align 8
  %v2016 = load i64, ptr %slot299, align 8
  %v2017 = load i64, ptr %slot24, align 8
  %p2018 = inttoptr i64 %v2017 to ptr
  store i64 %v2016, ptr %p2018, align 8, !alias.scope !3, !noalias !4
  %v2019 = load i64, ptr %slot24, align 8
  %p2020 = inttoptr i64 %v2019 to ptr
  %ld2021 = load i64, ptr %p2020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2021, ptr %slot300, align 8
  %v2022 = load i64, ptr %slot300, align 8
  %v2023 = load i64, ptr %slot23, align 8
  %p2024 = inttoptr i64 %v2023 to ptr
  store i64 %v2022, ptr %p2024, align 8, !alias.scope !3, !noalias !4
  %v2025 = load i64, ptr %slot22, align 8
  %p2026 = inttoptr i64 %v2025 to ptr
  %ld2027 = load i64, ptr %p2026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2027, ptr %slot301, align 8
  %v2028 = load i64, ptr %slot301, align 8
  %v2029 = load i64, ptr %slot24, align 8
  %p2030 = inttoptr i64 %v2029 to ptr
  store i64 %v2028, ptr %p2030, align 8, !alias.scope !3, !noalias !4
  %v2031 = load i64, ptr %slot23, align 8
  %p2032 = inttoptr i64 %v2031 to ptr
  %ld2033 = load i64, ptr %p2032, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2033, ptr %slot302, align 8
  %v2034 = load i64, ptr %slot302, align 8
  %v2035 = load i64, ptr %slot25, align 8
  %p2036 = inttoptr i64 %v2035 to ptr
  store i64 %v2034, ptr %p2036, align 8, !alias.scope !3, !noalias !4
  %v2037 = load i64, ptr %slot25, align 8
  %p2038 = inttoptr i64 %v2037 to ptr
  %ld2039 = load i64, ptr %p2038, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2039, ptr %slot303, align 8
  %v2040 = load i64, ptr %slot24, align 8
  %p2041 = inttoptr i64 %v2040 to ptr
  %ld2042 = load i64, ptr %p2041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2042, ptr %slot304, align 8
  %v2043 = load i64, ptr %slot304, align 8
  %cast2044 = bitcast i64 %v2043 to double
  store double %cast2044, ptr %slot305, align 8
  %v2045 = load i64, ptr %slot303, align 8
  %cast2046 = bitcast i64 %v2045 to double
  store double %cast2046, ptr %slot306, align 8
  %v2047 = load double, ptr %slot305, align 8
  %v2048 = load double, ptr %slot306, align 8
  %op2049 = fmul double %v2047, %v2048
  store double %op2049, ptr %slot307, align 8
  %v2050 = load double, ptr %slot307, align 8
  %cast2051 = bitcast double %v2050 to i64
  store i64 %cast2051, ptr %slot308, align 8
  %v2052 = load i64, ptr %slot308, align 8
  %v2053 = load i64, ptr %slot24, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  store i64 %v2052, ptr %p2054, align 8, !alias.scope !3, !noalias !4
  %v2055 = load i64, ptr %slot38, align 8
  store i64 %v2055, ptr %slot309, align 8
  %v2056 = load i64, ptr %slot309, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  store i32 2, ptr %p2057, align 4, !alias.scope !3, !noalias !4
  %v2058 = load i64, ptr %slot309, align 8
  %p2060 = inttoptr i64 %v2058 to ptr
  %gep2061 = getelementptr i8, ptr %p2060, i64 8
  %op2059 = ptrtoint ptr %gep2061 to i64
  store i64 %op2059, ptr %slot310, align 8
  %v2062 = load i64, ptr %slot24, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  %ld2064 = load i64, ptr %p2063, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2064, ptr %slot311, align 8
  %v2065 = load i64, ptr %slot311, align 8
  %v2066 = load i64, ptr %slot310, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  store i64 %v2065, ptr %p2067, align 8, !alias.scope !3, !noalias !4
  %v2068 = load i64, ptr %slot309, align 8
  %v2069 = load i64, ptr %slot24, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  store i64 %v2068, ptr %p2070, align 8, !alias.scope !3, !noalias !4
  %v2071 = load i64, ptr %slot24, align 8
  %p2072 = inttoptr i64 %v2071 to ptr
  %ld2073 = load i64, ptr %p2072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2073, ptr %slot312, align 8
  %v2074 = load i64, ptr %slot312, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  %ret2076 = load { i64, i64 }, ptr %p2075, align 8
  ret { i64, i64 } %ret2076
bb_i154:
  %v2077 = load i64, ptr %slot8, align 8
  %p2078 = inttoptr i64 %v2077 to ptr
  %ld2079 = load i64, ptr %p2078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2079, ptr %slot313, align 8
  %v2080 = load i64, ptr %slot313, align 8
  %v2081 = load i64, ptr %slot24, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i64 %v2080, ptr %p2082, align 8, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot24, align 8
  %p2084 = inttoptr i64 %v2083 to ptr
  %ld2085 = load i64, ptr %p2084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2085, ptr %slot314, align 8
  %v2086 = load i64, ptr %slot314, align 8
  %v2087 = load i64, ptr %slot22, align 8
  %p2088 = inttoptr i64 %v2087 to ptr
  store i64 %v2086, ptr %p2088, align 8, !alias.scope !3, !noalias !4
  %v2089 = load i64, ptr %slot9, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  %ld2091 = load i64, ptr %p2090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2091, ptr %slot315, align 8
  %v2092 = load i64, ptr %slot315, align 8
  %v2093 = load i64, ptr %slot24, align 8
  %p2094 = inttoptr i64 %v2093 to ptr
  store i64 %v2092, ptr %p2094, align 8, !alias.scope !3, !noalias !4
  %v2095 = load i64, ptr %slot24, align 8
  %p2096 = inttoptr i64 %v2095 to ptr
  %ld2097 = load i64, ptr %p2096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2097, ptr %slot316, align 8
  %v2098 = load i64, ptr %slot316, align 8
  %v2099 = load i64, ptr %slot23, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  store i64 %v2098, ptr %p2100, align 8, !alias.scope !3, !noalias !4
  %v2101 = load i64, ptr %slot22, align 8
  %p2102 = inttoptr i64 %v2101 to ptr
  %ld2103 = load i64, ptr %p2102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2103, ptr %slot317, align 8
  %v2104 = load i64, ptr %slot317, align 8
  %v2105 = load i64, ptr %slot24, align 8
  %p2106 = inttoptr i64 %v2105 to ptr
  store i64 %v2104, ptr %p2106, align 8, !alias.scope !3, !noalias !4
  %v2107 = load i64, ptr %slot23, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  %ld2109 = load i64, ptr %p2108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2109, ptr %slot318, align 8
  %v2110 = load i64, ptr %slot318, align 8
  %v2111 = load i64, ptr %slot25, align 8
  %p2112 = inttoptr i64 %v2111 to ptr
  store i64 %v2110, ptr %p2112, align 8, !alias.scope !3, !noalias !4
  %v2113 = load i64, ptr %slot25, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %ld2115 = load i64, ptr %p2114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2115, ptr %slot319, align 8
  %v2116 = load i64, ptr %slot24, align 8
  %p2117 = inttoptr i64 %v2116 to ptr
  %ld2118 = load i64, ptr %p2117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2118, ptr %slot320, align 8
  %v2119 = load i64, ptr %slot320, align 8
  %cast2120 = bitcast i64 %v2119 to double
  store double %cast2120, ptr %slot321, align 8
  %v2121 = load i64, ptr %slot319, align 8
  %cast2122 = bitcast i64 %v2121 to double
  store double %cast2122, ptr %slot322, align 8
  %v2123 = load double, ptr %slot321, align 8
  %v2124 = load double, ptr %slot322, align 8
  %op2125 = fmul double %v2123, %v2124
  store double %op2125, ptr %slot323, align 8
  %v2126 = load double, ptr %slot323, align 8
  %cast2127 = bitcast double %v2126 to i64
  store i64 %cast2127, ptr %slot324, align 8
  %v2128 = load i64, ptr %slot324, align 8
  %v2129 = load i64, ptr %slot24, align 8
  %p2130 = inttoptr i64 %v2129 to ptr
  store i64 %v2128, ptr %p2130, align 8, !alias.scope !3, !noalias !4
  %v2131 = load i64, ptr %slot39, align 8
  store i64 %v2131, ptr %slot325, align 8
  %v2132 = load i64, ptr %slot325, align 8
  %p2133 = inttoptr i64 %v2132 to ptr
  store i32 2, ptr %p2133, align 4, !alias.scope !3, !noalias !4
  %v2134 = load i64, ptr %slot325, align 8
  %p2136 = inttoptr i64 %v2134 to ptr
  %gep2137 = getelementptr i8, ptr %p2136, i64 8
  %op2135 = ptrtoint ptr %gep2137 to i64
  store i64 %op2135, ptr %slot326, align 8
  %v2138 = load i64, ptr %slot24, align 8
  %p2139 = inttoptr i64 %v2138 to ptr
  %ld2140 = load i64, ptr %p2139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2140, ptr %slot327, align 8
  %v2141 = load i64, ptr %slot327, align 8
  %v2142 = load i64, ptr %slot326, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  store i64 %v2141, ptr %p2143, align 8, !alias.scope !3, !noalias !4
  %v2144 = load i64, ptr %slot325, align 8
  %v2145 = load i64, ptr %slot24, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  store i64 %v2144, ptr %p2146, align 8, !alias.scope !3, !noalias !4
  %v2147 = load i64, ptr %slot24, align 8
  %p2148 = inttoptr i64 %v2147 to ptr
  %ld2149 = load i64, ptr %p2148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2149, ptr %slot328, align 8
  %v2150 = load i64, ptr %slot328, align 8
  %p2151 = inttoptr i64 %v2150 to ptr
  %ret2152 = load { i64, i64 }, ptr %p2151, align 8
  ret { i64, i64 } %ret2152
bb_i166:
  %v2153 = load i64, ptr %slot8, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %ld2155 = load i64, ptr %p2154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2155, ptr %slot329, align 8
  %v2156 = load i64, ptr %slot329, align 8
  %v2157 = load i64, ptr %slot24, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i64 %v2156, ptr %p2158, align 8, !alias.scope !3, !noalias !4
  %v2159 = load i64, ptr %slot24, align 8
  %p2160 = inttoptr i64 %v2159 to ptr
  %ld2161 = load i64, ptr %p2160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2161, ptr %slot330, align 8
  %v2162 = load i64, ptr %slot330, align 8
  %v2163 = load i64, ptr %slot22, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  store i64 %v2162, ptr %p2164, align 8, !alias.scope !3, !noalias !4
  %v2165 = load i64, ptr %slot9, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %ld2167 = load i64, ptr %p2166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2167, ptr %slot331, align 8
  %v2168 = load i64, ptr %slot331, align 8
  %v2169 = load i64, ptr %slot24, align 8
  %p2170 = inttoptr i64 %v2169 to ptr
  store i64 %v2168, ptr %p2170, align 8, !alias.scope !3, !noalias !4
  %v2171 = load i64, ptr %slot24, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %ld2173 = load i64, ptr %p2172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2173, ptr %slot332, align 8
  %v2174 = load i64, ptr %slot332, align 8
  %v2175 = load i64, ptr %slot23, align 8
  %p2176 = inttoptr i64 %v2175 to ptr
  store i64 %v2174, ptr %p2176, align 8, !alias.scope !3, !noalias !4
  %v2177 = load i64, ptr %slot22, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  %ld2179 = load i64, ptr %p2178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2179, ptr %slot333, align 8
  %v2180 = load i64, ptr %slot333, align 8
  %v2181 = load i64, ptr %slot24, align 8
  %p2182 = inttoptr i64 %v2181 to ptr
  store i64 %v2180, ptr %p2182, align 8, !alias.scope !3, !noalias !4
  %v2183 = load i64, ptr %slot23, align 8
  %p2184 = inttoptr i64 %v2183 to ptr
  %ld2185 = load i64, ptr %p2184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2185, ptr %slot334, align 8
  %v2186 = load i64, ptr %slot334, align 8
  %v2187 = load i64, ptr %slot25, align 8
  %p2188 = inttoptr i64 %v2187 to ptr
  store i64 %v2186, ptr %p2188, align 8, !alias.scope !3, !noalias !4
  %v2189 = load i64, ptr %slot25, align 8
  %p2190 = inttoptr i64 %v2189 to ptr
  %ld2191 = load i64, ptr %p2190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2191, ptr %slot335, align 8
  %v2192 = load i64, ptr %slot24, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %ld2194 = load i64, ptr %p2193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2194, ptr %slot336, align 8
  %v2195 = load i64, ptr %slot336, align 8
  %cast2196 = bitcast i64 %v2195 to double
  store double %cast2196, ptr %slot337, align 8
  %v2197 = load i64, ptr %slot335, align 8
  %cast2198 = bitcast i64 %v2197 to double
  store double %cast2198, ptr %slot338, align 8
  %v2199 = load double, ptr %slot337, align 8
  %v2200 = load double, ptr %slot338, align 8
  %op2201 = fmul double %v2199, %v2200
  store double %op2201, ptr %slot339, align 8
  %v2202 = load double, ptr %slot339, align 8
  %cast2203 = bitcast double %v2202 to i64
  store i64 %cast2203, ptr %slot340, align 8
  %v2204 = load i64, ptr %slot340, align 8
  %v2205 = load i64, ptr %slot24, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  store i64 %v2204, ptr %p2206, align 8, !alias.scope !3, !noalias !4
  %v2207 = load i64, ptr %slot40, align 8
  store i64 %v2207, ptr %slot341, align 8
  %v2208 = load i64, ptr %slot341, align 8
  %p2209 = inttoptr i64 %v2208 to ptr
  store i32 2, ptr %p2209, align 4, !alias.scope !3, !noalias !4
  %v2210 = load i64, ptr %slot341, align 8
  %p2212 = inttoptr i64 %v2210 to ptr
  %gep2213 = getelementptr i8, ptr %p2212, i64 8
  %op2211 = ptrtoint ptr %gep2213 to i64
  store i64 %op2211, ptr %slot342, align 8
  %v2214 = load i64, ptr %slot24, align 8
  %p2215 = inttoptr i64 %v2214 to ptr
  %ld2216 = load i64, ptr %p2215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2216, ptr %slot343, align 8
  %v2217 = load i64, ptr %slot343, align 8
  %v2218 = load i64, ptr %slot342, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  store i64 %v2217, ptr %p2219, align 8, !alias.scope !3, !noalias !4
  %v2220 = load i64, ptr %slot341, align 8
  %v2221 = load i64, ptr %slot24, align 8
  %p2222 = inttoptr i64 %v2221 to ptr
  store i64 %v2220, ptr %p2222, align 8, !alias.scope !3, !noalias !4
  %v2223 = load i64, ptr %slot24, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  %ld2225 = load i64, ptr %p2224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2225, ptr %slot344, align 8
  %v2226 = load i64, ptr %slot344, align 8
  %p2227 = inttoptr i64 %v2226 to ptr
  %ret2228 = load { i64, i64 }, ptr %p2227, align 8
  ret { i64, i64 } %ret2228
bb_i178:
  %v2229 = load i64, ptr %slot8, align 8
  %p2230 = inttoptr i64 %v2229 to ptr
  %ld2231 = load i64, ptr %p2230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2231, ptr %slot345, align 8
  %v2232 = load i64, ptr %slot345, align 8
  %v2233 = load i64, ptr %slot24, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  store i64 %v2232, ptr %p2234, align 8, !alias.scope !3, !noalias !4
  %v2235 = load i64, ptr %slot24, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %ld2237 = load i64, ptr %p2236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2237, ptr %slot346, align 8
  %v2238 = load i64, ptr %slot346, align 8
  %v2239 = load i64, ptr %slot22, align 8
  %p2240 = inttoptr i64 %v2239 to ptr
  store i64 %v2238, ptr %p2240, align 8, !alias.scope !3, !noalias !4
  %v2241 = load i64, ptr %slot9, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  %ld2243 = load i64, ptr %p2242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2243, ptr %slot347, align 8
  %v2244 = load i64, ptr %slot347, align 8
  %v2245 = load i64, ptr %slot24, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  store i64 %v2244, ptr %p2246, align 8, !alias.scope !3, !noalias !4
  %v2247 = load i64, ptr %slot24, align 8
  %p2248 = inttoptr i64 %v2247 to ptr
  %ld2249 = load i64, ptr %p2248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2249, ptr %slot348, align 8
  %v2250 = load i64, ptr %slot348, align 8
  %v2251 = load i64, ptr %slot23, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  store i64 %v2250, ptr %p2252, align 8, !alias.scope !3, !noalias !4
  %v2253 = load i64, ptr %slot22, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  %ld2255 = load i64, ptr %p2254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2255, ptr %slot349, align 8
  %v2256 = load i64, ptr %slot349, align 8
  %v2257 = load i64, ptr %slot24, align 8
  %p2258 = inttoptr i64 %v2257 to ptr
  store i64 %v2256, ptr %p2258, align 8, !alias.scope !3, !noalias !4
  %v2259 = load i64, ptr %slot23, align 8
  %p2260 = inttoptr i64 %v2259 to ptr
  %ld2261 = load i64, ptr %p2260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2261, ptr %slot350, align 8
  %v2262 = load i64, ptr %slot350, align 8
  %v2263 = load i64, ptr %slot25, align 8
  %p2264 = inttoptr i64 %v2263 to ptr
  store i64 %v2262, ptr %p2264, align 8, !alias.scope !3, !noalias !4
  %v2265 = load i64, ptr %slot25, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  %ld2267 = load i64, ptr %p2266, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2267, ptr %slot351, align 8
  %v2268 = load i64, ptr %slot24, align 8
  %p2269 = inttoptr i64 %v2268 to ptr
  %ld2270 = load i64, ptr %p2269, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2270, ptr %slot352, align 8
  %v2271 = load i64, ptr %slot352, align 8
  %cast2272 = bitcast i64 %v2271 to double
  store double %cast2272, ptr %slot353, align 8
  %v2273 = load i64, ptr %slot351, align 8
  %cast2274 = bitcast i64 %v2273 to double
  store double %cast2274, ptr %slot354, align 8
  %v2275 = load double, ptr %slot353, align 8
  %v2276 = load double, ptr %slot354, align 8
  %op2277 = fmul double %v2275, %v2276
  store double %op2277, ptr %slot355, align 8
  %v2278 = load double, ptr %slot355, align 8
  %cast2279 = bitcast double %v2278 to i64
  store i64 %cast2279, ptr %slot356, align 8
  %v2280 = load i64, ptr %slot356, align 8
  %v2281 = load i64, ptr %slot24, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  store i64 %v2280, ptr %p2282, align 8, !alias.scope !3, !noalias !4
  %v2283 = load i64, ptr %slot41, align 8
  store i64 %v2283, ptr %slot357, align 8
  %v2284 = load i64, ptr %slot357, align 8
  %p2285 = inttoptr i64 %v2284 to ptr
  store i32 2, ptr %p2285, align 4, !alias.scope !3, !noalias !4
  %v2286 = load i64, ptr %slot357, align 8
  %p2288 = inttoptr i64 %v2286 to ptr
  %gep2289 = getelementptr i8, ptr %p2288, i64 8
  %op2287 = ptrtoint ptr %gep2289 to i64
  store i64 %op2287, ptr %slot358, align 8
  %v2290 = load i64, ptr %slot24, align 8
  %p2291 = inttoptr i64 %v2290 to ptr
  %ld2292 = load i64, ptr %p2291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2292, ptr %slot359, align 8
  %v2293 = load i64, ptr %slot359, align 8
  %v2294 = load i64, ptr %slot358, align 8
  %p2295 = inttoptr i64 %v2294 to ptr
  store i64 %v2293, ptr %p2295, align 8, !alias.scope !3, !noalias !4
  %v2296 = load i64, ptr %slot357, align 8
  %v2297 = load i64, ptr %slot24, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  store i64 %v2296, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  %v2299 = load i64, ptr %slot24, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %ld2301 = load i64, ptr %p2300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2301, ptr %slot360, align 8
  %v2302 = load i64, ptr %slot360, align 8
  %p2303 = inttoptr i64 %v2302 to ptr
  %ret2304 = load { i64, i64 }, ptr %p2303, align 8
  ret { i64, i64 } %ret2304
bb_i190:
  %v2305 = load i64, ptr %slot8, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  %ld2307 = load i64, ptr %p2306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2307, ptr %slot361, align 8
  %v2308 = load i64, ptr %slot361, align 8
  %v2309 = load i64, ptr %slot24, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  store i64 %v2308, ptr %p2310, align 8, !alias.scope !3, !noalias !4
  %v2311 = load i64, ptr %slot24, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %ld2313 = load i64, ptr %p2312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2313, ptr %slot362, align 8
  %v2314 = load i64, ptr %slot362, align 8
  %v2315 = load i64, ptr %slot22, align 8
  %p2316 = inttoptr i64 %v2315 to ptr
  store i64 %v2314, ptr %p2316, align 8, !alias.scope !3, !noalias !4
  %v2317 = load i64, ptr %slot9, align 8
  %p2318 = inttoptr i64 %v2317 to ptr
  %ld2319 = load i64, ptr %p2318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2319, ptr %slot363, align 8
  %v2320 = load i64, ptr %slot363, align 8
  %v2321 = load i64, ptr %slot24, align 8
  %p2322 = inttoptr i64 %v2321 to ptr
  store i64 %v2320, ptr %p2322, align 8, !alias.scope !3, !noalias !4
  %v2323 = load i64, ptr %slot24, align 8
  %p2324 = inttoptr i64 %v2323 to ptr
  %ld2325 = load i64, ptr %p2324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2325, ptr %slot364, align 8
  %v2326 = load i64, ptr %slot364, align 8
  %v2327 = load i64, ptr %slot23, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  store i64 %v2326, ptr %p2328, align 8, !alias.scope !3, !noalias !4
  %v2329 = load i64, ptr %slot22, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  %ld2331 = load i64, ptr %p2330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2331, ptr %slot365, align 8
  %v2332 = load i64, ptr %slot365, align 8
  %v2333 = load i64, ptr %slot24, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  store i64 %v2332, ptr %p2334, align 8, !alias.scope !3, !noalias !4
  %v2335 = load i64, ptr %slot23, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  %ld2337 = load i64, ptr %p2336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2337, ptr %slot366, align 8
  %v2338 = load i64, ptr %slot366, align 8
  %v2339 = load i64, ptr %slot25, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  store i64 %v2338, ptr %p2340, align 8, !alias.scope !3, !noalias !4
  %v2341 = load i64, ptr %slot25, align 8
  %p2342 = inttoptr i64 %v2341 to ptr
  %ld2343 = load i64, ptr %p2342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2343, ptr %slot367, align 8
  %v2344 = load i64, ptr %slot24, align 8
  %p2345 = inttoptr i64 %v2344 to ptr
  %ld2346 = load i64, ptr %p2345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2346, ptr %slot368, align 8
  %v2347 = load i64, ptr %slot368, align 8
  %cast2348 = bitcast i64 %v2347 to double
  store double %cast2348, ptr %slot369, align 8
  %v2349 = load i64, ptr %slot367, align 8
  %cast2350 = bitcast i64 %v2349 to double
  store double %cast2350, ptr %slot370, align 8
  %v2351 = load double, ptr %slot369, align 8
  %v2352 = load double, ptr %slot370, align 8
  %op2353 = fmul double %v2351, %v2352
  store double %op2353, ptr %slot371, align 8
  %v2354 = load double, ptr %slot371, align 8
  %cast2355 = bitcast double %v2354 to i64
  store i64 %cast2355, ptr %slot372, align 8
  %v2356 = load i64, ptr %slot372, align 8
  %v2357 = load i64, ptr %slot24, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i64 %v2356, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  %v2359 = load i64, ptr %slot42, align 8
  store i64 %v2359, ptr %slot373, align 8
  %v2360 = load i64, ptr %slot373, align 8
  %p2361 = inttoptr i64 %v2360 to ptr
  store i32 2, ptr %p2361, align 4, !alias.scope !3, !noalias !4
  %v2362 = load i64, ptr %slot373, align 8
  %p2364 = inttoptr i64 %v2362 to ptr
  %gep2365 = getelementptr i8, ptr %p2364, i64 8
  %op2363 = ptrtoint ptr %gep2365 to i64
  store i64 %op2363, ptr %slot374, align 8
  %v2366 = load i64, ptr %slot24, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  %ld2368 = load i64, ptr %p2367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2368, ptr %slot375, align 8
  %v2369 = load i64, ptr %slot375, align 8
  %v2370 = load i64, ptr %slot374, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  store i64 %v2369, ptr %p2371, align 8, !alias.scope !3, !noalias !4
  %v2372 = load i64, ptr %slot373, align 8
  %v2373 = load i64, ptr %slot24, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  store i64 %v2372, ptr %p2374, align 8, !alias.scope !3, !noalias !4
  %v2375 = load i64, ptr %slot24, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  %ld2377 = load i64, ptr %p2376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2377, ptr %slot376, align 8
  %v2378 = load i64, ptr %slot376, align 8
  %p2379 = inttoptr i64 %v2378 to ptr
  %ret2380 = load { i64, i64 }, ptr %p2379, align 8
  ret { i64, i64 } %ret2380
bb_i202:
  %v2381 = load i64, ptr %slot8, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  %ld2383 = load i64, ptr %p2382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2383, ptr %slot377, align 8
  %v2384 = load i64, ptr %slot377, align 8
  %v2385 = load i64, ptr %slot24, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  store i64 %v2384, ptr %p2386, align 8, !alias.scope !3, !noalias !4
  %v2387 = load i64, ptr %slot24, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  %ld2389 = load i64, ptr %p2388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2389, ptr %slot378, align 8
  %v2390 = load i64, ptr %slot378, align 8
  %v2391 = load i64, ptr %slot22, align 8
  %p2392 = inttoptr i64 %v2391 to ptr
  store i64 %v2390, ptr %p2392, align 8, !alias.scope !3, !noalias !4
  %v2393 = load i64, ptr %slot9, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  %ld2395 = load i64, ptr %p2394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2395, ptr %slot379, align 8
  %v2396 = load i64, ptr %slot379, align 8
  %v2397 = load i64, ptr %slot24, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  store i64 %v2396, ptr %p2398, align 8, !alias.scope !3, !noalias !4
  %v2399 = load i64, ptr %slot24, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %ld2401 = load i64, ptr %p2400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2401, ptr %slot380, align 8
  %v2402 = load i64, ptr %slot380, align 8
  %v2403 = load i64, ptr %slot23, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  store i64 %v2402, ptr %p2404, align 8, !alias.scope !3, !noalias !4
  %v2405 = load i64, ptr %slot22, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  %ld2407 = load i64, ptr %p2406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2407, ptr %slot381, align 8
  %v2408 = load i64, ptr %slot381, align 8
  %v2409 = load i64, ptr %slot24, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  store i64 %v2408, ptr %p2410, align 8, !alias.scope !3, !noalias !4
  %v2411 = load i64, ptr %slot23, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  %ld2413 = load i64, ptr %p2412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2413, ptr %slot382, align 8
  %v2414 = load i64, ptr %slot382, align 8
  %v2415 = load i64, ptr %slot25, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  store i64 %v2414, ptr %p2416, align 8, !alias.scope !3, !noalias !4
  %v2417 = load i64, ptr %slot25, align 8
  %p2418 = inttoptr i64 %v2417 to ptr
  %ld2419 = load i64, ptr %p2418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2419, ptr %slot383, align 8
  %v2420 = load i64, ptr %slot24, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  %ld2422 = load i64, ptr %p2421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2422, ptr %slot384, align 8
  %v2423 = load i64, ptr %slot384, align 8
  %cast2424 = bitcast i64 %v2423 to double
  store double %cast2424, ptr %slot385, align 8
  %v2425 = load i64, ptr %slot383, align 8
  %cast2426 = bitcast i64 %v2425 to double
  store double %cast2426, ptr %slot386, align 8
  %v2427 = load double, ptr %slot385, align 8
  %v2428 = load double, ptr %slot386, align 8
  %op2429 = fmul double %v2427, %v2428
  store double %op2429, ptr %slot387, align 8
  %v2430 = load double, ptr %slot387, align 8
  %cast2431 = bitcast double %v2430 to i64
  store i64 %cast2431, ptr %slot388, align 8
  %v2432 = load i64, ptr %slot388, align 8
  %v2433 = load i64, ptr %slot24, align 8
  %p2434 = inttoptr i64 %v2433 to ptr
  store i64 %v2432, ptr %p2434, align 8, !alias.scope !3, !noalias !4
  %v2435 = load i64, ptr %slot43, align 8
  store i64 %v2435, ptr %slot389, align 8
  %v2436 = load i64, ptr %slot389, align 8
  %p2437 = inttoptr i64 %v2436 to ptr
  store i32 2, ptr %p2437, align 4, !alias.scope !3, !noalias !4
  %v2438 = load i64, ptr %slot389, align 8
  %p2440 = inttoptr i64 %v2438 to ptr
  %gep2441 = getelementptr i8, ptr %p2440, i64 8
  %op2439 = ptrtoint ptr %gep2441 to i64
  store i64 %op2439, ptr %slot390, align 8
  %v2442 = load i64, ptr %slot24, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  %ld2444 = load i64, ptr %p2443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2444, ptr %slot391, align 8
  %v2445 = load i64, ptr %slot391, align 8
  %v2446 = load i64, ptr %slot390, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  store i64 %v2445, ptr %p2447, align 8, !alias.scope !3, !noalias !4
  %v2448 = load i64, ptr %slot389, align 8
  %v2449 = load i64, ptr %slot24, align 8
  %p2450 = inttoptr i64 %v2449 to ptr
  store i64 %v2448, ptr %p2450, align 8, !alias.scope !3, !noalias !4
  %v2451 = load i64, ptr %slot24, align 8
  %p2452 = inttoptr i64 %v2451 to ptr
  %ld2453 = load i64, ptr %p2452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2453, ptr %slot392, align 8
  %v2454 = load i64, ptr %slot392, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %ret2456 = load { i64, i64 }, ptr %p2455, align 8
  ret { i64, i64 } %ret2456
bb_i214:
  %v2457 = load i64, ptr %slot8, align 8
  %p2458 = inttoptr i64 %v2457 to ptr
  %ld2459 = load i64, ptr %p2458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2459, ptr %slot393, align 8
  %v2460 = load i64, ptr %slot393, align 8
  %v2461 = load i64, ptr %slot24, align 8
  %p2462 = inttoptr i64 %v2461 to ptr
  store i64 %v2460, ptr %p2462, align 8, !alias.scope !3, !noalias !4
  %v2463 = load i64, ptr %slot24, align 8
  %p2464 = inttoptr i64 %v2463 to ptr
  %ld2465 = load i64, ptr %p2464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2465, ptr %slot394, align 8
  %v2466 = load i64, ptr %slot394, align 8
  %v2467 = load i64, ptr %slot22, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  store i64 %v2466, ptr %p2468, align 8, !alias.scope !3, !noalias !4
  %v2469 = load i64, ptr %slot9, align 8
  %p2470 = inttoptr i64 %v2469 to ptr
  %ld2471 = load i64, ptr %p2470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2471, ptr %slot395, align 8
  %v2472 = load i64, ptr %slot395, align 8
  %v2473 = load i64, ptr %slot24, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  store i64 %v2472, ptr %p2474, align 8, !alias.scope !3, !noalias !4
  %v2475 = load i64, ptr %slot24, align 8
  %p2476 = inttoptr i64 %v2475 to ptr
  %ld2477 = load i64, ptr %p2476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2477, ptr %slot396, align 8
  %v2478 = load i64, ptr %slot396, align 8
  %v2479 = load i64, ptr %slot23, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  store i64 %v2478, ptr %p2480, align 8, !alias.scope !3, !noalias !4
  %v2481 = load i64, ptr %slot22, align 8
  %p2482 = inttoptr i64 %v2481 to ptr
  %ld2483 = load i64, ptr %p2482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2483, ptr %slot397, align 8
  %v2484 = load i64, ptr %slot397, align 8
  %v2485 = load i64, ptr %slot24, align 8
  %p2486 = inttoptr i64 %v2485 to ptr
  store i64 %v2484, ptr %p2486, align 8, !alias.scope !3, !noalias !4
  %v2487 = load i64, ptr %slot23, align 8
  %p2488 = inttoptr i64 %v2487 to ptr
  %ld2489 = load i64, ptr %p2488, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2489, ptr %slot398, align 8
  %v2490 = load i64, ptr %slot398, align 8
  %v2491 = load i64, ptr %slot25, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  store i64 %v2490, ptr %p2492, align 8, !alias.scope !3, !noalias !4
  %v2493 = load i64, ptr %slot25, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  %ld2495 = load i64, ptr %p2494, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2495, ptr %slot399, align 8
  %v2496 = load i64, ptr %slot24, align 8
  %p2497 = inttoptr i64 %v2496 to ptr
  %ld2498 = load i64, ptr %p2497, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2498, ptr %slot400, align 8
  %v2499 = load i64, ptr %slot400, align 8
  %cast2500 = bitcast i64 %v2499 to double
  store double %cast2500, ptr %slot401, align 8
  %v2501 = load i64, ptr %slot399, align 8
  %cast2502 = bitcast i64 %v2501 to double
  store double %cast2502, ptr %slot402, align 8
  %v2503 = load double, ptr %slot401, align 8
  %v2504 = load double, ptr %slot402, align 8
  %op2505 = fmul double %v2503, %v2504
  store double %op2505, ptr %slot403, align 8
  %v2506 = load double, ptr %slot403, align 8
  %cast2507 = bitcast double %v2506 to i64
  store i64 %cast2507, ptr %slot404, align 8
  %v2508 = load i64, ptr %slot404, align 8
  %v2509 = load i64, ptr %slot24, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  store i64 %v2508, ptr %p2510, align 8, !alias.scope !3, !noalias !4
  %v2511 = load i64, ptr %slot44, align 8
  store i64 %v2511, ptr %slot405, align 8
  %v2512 = load i64, ptr %slot405, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  store i32 2, ptr %p2513, align 4, !alias.scope !3, !noalias !4
  %v2514 = load i64, ptr %slot405, align 8
  %p2516 = inttoptr i64 %v2514 to ptr
  %gep2517 = getelementptr i8, ptr %p2516, i64 8
  %op2515 = ptrtoint ptr %gep2517 to i64
  store i64 %op2515, ptr %slot406, align 8
  %v2518 = load i64, ptr %slot24, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  %ld2520 = load i64, ptr %p2519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2520, ptr %slot407, align 8
  %v2521 = load i64, ptr %slot407, align 8
  %v2522 = load i64, ptr %slot406, align 8
  %p2523 = inttoptr i64 %v2522 to ptr
  store i64 %v2521, ptr %p2523, align 8, !alias.scope !3, !noalias !4
  %v2524 = load i64, ptr %slot405, align 8
  %v2525 = load i64, ptr %slot24, align 8
  %p2526 = inttoptr i64 %v2525 to ptr
  store i64 %v2524, ptr %p2526, align 8, !alias.scope !3, !noalias !4
  %v2527 = load i64, ptr %slot24, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  %ld2529 = load i64, ptr %p2528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2529, ptr %slot408, align 8
  %v2530 = load i64, ptr %slot408, align 8
  %p2531 = inttoptr i64 %v2530 to ptr
  %ret2532 = load { i64, i64 }, ptr %p2531, align 8
  ret { i64, i64 } %ret2532
bb_i226:
  %v2533 = load i64, ptr %slot8, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  %ld2535 = load i64, ptr %p2534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2535, ptr %slot409, align 8
  %v2536 = load i64, ptr %slot409, align 8
  %v2537 = load i64, ptr %slot24, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i64 %v2536, ptr %p2538, align 8, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot24, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  %ld2541 = load i64, ptr %p2540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2541, ptr %slot410, align 8
  %v2542 = load i64, ptr %slot410, align 8
  %v2543 = load i64, ptr %slot22, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  store i64 %v2542, ptr %p2544, align 8, !alias.scope !3, !noalias !4
  %v2545 = load i64, ptr %slot9, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  %ld2547 = load i64, ptr %p2546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2547, ptr %slot411, align 8
  %v2548 = load i64, ptr %slot411, align 8
  %v2549 = load i64, ptr %slot24, align 8
  %p2550 = inttoptr i64 %v2549 to ptr
  store i64 %v2548, ptr %p2550, align 8, !alias.scope !3, !noalias !4
  %v2551 = load i64, ptr %slot24, align 8
  %p2552 = inttoptr i64 %v2551 to ptr
  %ld2553 = load i64, ptr %p2552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2553, ptr %slot412, align 8
  %v2554 = load i64, ptr %slot412, align 8
  %v2555 = load i64, ptr %slot23, align 8
  %p2556 = inttoptr i64 %v2555 to ptr
  store i64 %v2554, ptr %p2556, align 8, !alias.scope !3, !noalias !4
  %v2557 = load i64, ptr %slot22, align 8
  %p2558 = inttoptr i64 %v2557 to ptr
  %ld2559 = load i64, ptr %p2558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2559, ptr %slot413, align 8
  %v2560 = load i64, ptr %slot413, align 8
  %v2561 = load i64, ptr %slot24, align 8
  %p2562 = inttoptr i64 %v2561 to ptr
  store i64 %v2560, ptr %p2562, align 8, !alias.scope !3, !noalias !4
  %v2563 = load i64, ptr %slot23, align 8
  %p2564 = inttoptr i64 %v2563 to ptr
  %ld2565 = load i64, ptr %p2564, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2565, ptr %slot414, align 8
  %v2566 = load i64, ptr %slot414, align 8
  %v2567 = load i64, ptr %slot25, align 8
  %p2568 = inttoptr i64 %v2567 to ptr
  store i64 %v2566, ptr %p2568, align 8, !alias.scope !3, !noalias !4
  %v2569 = load i64, ptr %slot25, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  %ld2571 = load i64, ptr %p2570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2571, ptr %slot415, align 8
  %v2572 = load i64, ptr %slot24, align 8
  %p2573 = inttoptr i64 %v2572 to ptr
  %ld2574 = load i64, ptr %p2573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2574, ptr %slot416, align 8
  %v2575 = load i64, ptr %slot416, align 8
  %cast2576 = bitcast i64 %v2575 to double
  store double %cast2576, ptr %slot417, align 8
  %v2577 = load i64, ptr %slot415, align 8
  %cast2578 = bitcast i64 %v2577 to double
  store double %cast2578, ptr %slot418, align 8
  %v2579 = load double, ptr %slot417, align 8
  %v2580 = load double, ptr %slot418, align 8
  %op2581 = fmul double %v2579, %v2580
  store double %op2581, ptr %slot419, align 8
  %v2582 = load double, ptr %slot419, align 8
  %cast2583 = bitcast double %v2582 to i64
  store i64 %cast2583, ptr %slot420, align 8
  %v2584 = load i64, ptr %slot420, align 8
  %v2585 = load i64, ptr %slot24, align 8
  %p2586 = inttoptr i64 %v2585 to ptr
  store i64 %v2584, ptr %p2586, align 8, !alias.scope !3, !noalias !4
  %v2587 = load i64, ptr %slot45, align 8
  store i64 %v2587, ptr %slot421, align 8
  %v2588 = load i64, ptr %slot421, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  store i32 2, ptr %p2589, align 4, !alias.scope !3, !noalias !4
  %v2590 = load i64, ptr %slot421, align 8
  %p2592 = inttoptr i64 %v2590 to ptr
  %gep2593 = getelementptr i8, ptr %p2592, i64 8
  %op2591 = ptrtoint ptr %gep2593 to i64
  store i64 %op2591, ptr %slot422, align 8
  %v2594 = load i64, ptr %slot24, align 8
  %p2595 = inttoptr i64 %v2594 to ptr
  %ld2596 = load i64, ptr %p2595, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2596, ptr %slot423, align 8
  %v2597 = load i64, ptr %slot423, align 8
  %v2598 = load i64, ptr %slot422, align 8
  %p2599 = inttoptr i64 %v2598 to ptr
  store i64 %v2597, ptr %p2599, align 8, !alias.scope !3, !noalias !4
  %v2600 = load i64, ptr %slot421, align 8
  %v2601 = load i64, ptr %slot24, align 8
  %p2602 = inttoptr i64 %v2601 to ptr
  store i64 %v2600, ptr %p2602, align 8, !alias.scope !3, !noalias !4
  %v2603 = load i64, ptr %slot24, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  %ld2605 = load i64, ptr %p2604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2605, ptr %slot424, align 8
  %v2606 = load i64, ptr %slot424, align 8
  %p2607 = inttoptr i64 %v2606 to ptr
  %ret2608 = load { i64, i64 }, ptr %p2607, align 8
  ret { i64, i64 } %ret2608
bb_i238:
  %v2609 = load i64, ptr %slot8, align 8
  %p2610 = inttoptr i64 %v2609 to ptr
  %ld2611 = load i64, ptr %p2610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2611, ptr %slot425, align 8
  %v2612 = load i64, ptr %slot425, align 8
  %v2613 = load i64, ptr %slot24, align 8
  %p2614 = inttoptr i64 %v2613 to ptr
  store i64 %v2612, ptr %p2614, align 8, !alias.scope !3, !noalias !4
  %v2615 = load i64, ptr %slot24, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  %ld2617 = load i64, ptr %p2616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2617, ptr %slot426, align 8
  %v2618 = load i64, ptr %slot426, align 8
  %v2619 = load i64, ptr %slot22, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  store i64 %v2618, ptr %p2620, align 8, !alias.scope !3, !noalias !4
  %v2621 = load i64, ptr %slot9, align 8
  %p2622 = inttoptr i64 %v2621 to ptr
  %ld2623 = load i64, ptr %p2622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2623, ptr %slot427, align 8
  %v2624 = load i64, ptr %slot427, align 8
  %v2625 = load i64, ptr %slot24, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  store i64 %v2624, ptr %p2626, align 8, !alias.scope !3, !noalias !4
  %v2627 = load i64, ptr %slot24, align 8
  %p2628 = inttoptr i64 %v2627 to ptr
  %ld2629 = load i64, ptr %p2628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2629, ptr %slot428, align 8
  %v2630 = load i64, ptr %slot428, align 8
  %v2631 = load i64, ptr %slot23, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  store i64 %v2630, ptr %p2632, align 8, !alias.scope !3, !noalias !4
  %v2633 = load i64, ptr %slot22, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  %ld2635 = load i64, ptr %p2634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2635, ptr %slot429, align 8
  %v2636 = load i64, ptr %slot429, align 8
  %v2637 = load i64, ptr %slot24, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  store i64 %v2636, ptr %p2638, align 8, !alias.scope !3, !noalias !4
  %v2639 = load i64, ptr %slot23, align 8
  %p2640 = inttoptr i64 %v2639 to ptr
  %ld2641 = load i64, ptr %p2640, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2641, ptr %slot430, align 8
  %v2642 = load i64, ptr %slot430, align 8
  %v2643 = load i64, ptr %slot25, align 8
  %p2644 = inttoptr i64 %v2643 to ptr
  store i64 %v2642, ptr %p2644, align 8, !alias.scope !3, !noalias !4
  %v2645 = load i64, ptr %slot25, align 8
  %p2646 = inttoptr i64 %v2645 to ptr
  %ld2647 = load i64, ptr %p2646, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2647, ptr %slot431, align 8
  %v2648 = load i64, ptr %slot24, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  %ld2650 = load i64, ptr %p2649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2650, ptr %slot432, align 8
  %v2651 = load i64, ptr %slot432, align 8
  %cast2652 = bitcast i64 %v2651 to double
  store double %cast2652, ptr %slot433, align 8
  %v2653 = load i64, ptr %slot431, align 8
  %cast2654 = bitcast i64 %v2653 to double
  store double %cast2654, ptr %slot434, align 8
  %v2655 = load double, ptr %slot433, align 8
  %v2656 = load double, ptr %slot434, align 8
  %op2657 = fmul double %v2655, %v2656
  store double %op2657, ptr %slot435, align 8
  %v2658 = load double, ptr %slot435, align 8
  %cast2659 = bitcast double %v2658 to i64
  store i64 %cast2659, ptr %slot436, align 8
  %v2660 = load i64, ptr %slot436, align 8
  %v2661 = load i64, ptr %slot24, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  store i64 %v2660, ptr %p2662, align 8, !alias.scope !3, !noalias !4
  %v2663 = load i64, ptr %slot46, align 8
  store i64 %v2663, ptr %slot437, align 8
  %v2664 = load i64, ptr %slot437, align 8
  %p2665 = inttoptr i64 %v2664 to ptr
  store i32 2, ptr %p2665, align 4, !alias.scope !3, !noalias !4
  %v2666 = load i64, ptr %slot437, align 8
  %p2668 = inttoptr i64 %v2666 to ptr
  %gep2669 = getelementptr i8, ptr %p2668, i64 8
  %op2667 = ptrtoint ptr %gep2669 to i64
  store i64 %op2667, ptr %slot438, align 8
  %v2670 = load i64, ptr %slot24, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  %ld2672 = load i64, ptr %p2671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2672, ptr %slot439, align 8
  %v2673 = load i64, ptr %slot439, align 8
  %v2674 = load i64, ptr %slot438, align 8
  %p2675 = inttoptr i64 %v2674 to ptr
  store i64 %v2673, ptr %p2675, align 8, !alias.scope !3, !noalias !4
  %v2676 = load i64, ptr %slot437, align 8
  %v2677 = load i64, ptr %slot24, align 8
  %p2678 = inttoptr i64 %v2677 to ptr
  store i64 %v2676, ptr %p2678, align 8, !alias.scope !3, !noalias !4
  %v2679 = load i64, ptr %slot24, align 8
  %p2680 = inttoptr i64 %v2679 to ptr
  %ld2681 = load i64, ptr %p2680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2681, ptr %slot440, align 8
  %v2682 = load i64, ptr %slot440, align 8
  %p2683 = inttoptr i64 %v2682 to ptr
  %ret2684 = load { i64, i64 }, ptr %p2683, align 8
  ret { i64, i64 } %ret2684
bb_i250:
  %v2685 = load i64, ptr %slot8, align 8
  %p2686 = inttoptr i64 %v2685 to ptr
  %ld2687 = load i64, ptr %p2686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2687, ptr %slot441, align 8
  %v2688 = load i64, ptr %slot441, align 8
  %v2689 = load i64, ptr %slot24, align 8
  %p2690 = inttoptr i64 %v2689 to ptr
  store i64 %v2688, ptr %p2690, align 8, !alias.scope !3, !noalias !4
  %v2691 = load i64, ptr %slot24, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  %ld2693 = load i64, ptr %p2692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2693, ptr %slot442, align 8
  %v2694 = load i64, ptr %slot442, align 8
  %v2695 = load i64, ptr %slot22, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  store i64 %v2694, ptr %p2696, align 8, !alias.scope !3, !noalias !4
  %v2697 = load i64, ptr %slot9, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  %ld2699 = load i64, ptr %p2698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2699, ptr %slot443, align 8
  %v2700 = load i64, ptr %slot443, align 8
  %v2701 = load i64, ptr %slot24, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  store i64 %v2700, ptr %p2702, align 8, !alias.scope !3, !noalias !4
  %v2703 = load i64, ptr %slot24, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  %ld2705 = load i64, ptr %p2704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2705, ptr %slot444, align 8
  %v2706 = load i64, ptr %slot444, align 8
  %v2707 = load i64, ptr %slot23, align 8
  %p2708 = inttoptr i64 %v2707 to ptr
  store i64 %v2706, ptr %p2708, align 8, !alias.scope !3, !noalias !4
  %v2709 = load i64, ptr %slot22, align 8
  %p2710 = inttoptr i64 %v2709 to ptr
  %ld2711 = load i64, ptr %p2710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2711, ptr %slot445, align 8
  %v2712 = load i64, ptr %slot445, align 8
  %v2713 = load i64, ptr %slot24, align 8
  %p2714 = inttoptr i64 %v2713 to ptr
  store i64 %v2712, ptr %p2714, align 8, !alias.scope !3, !noalias !4
  %v2715 = load i64, ptr %slot23, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  %ld2717 = load i64, ptr %p2716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2717, ptr %slot446, align 8
  %v2718 = load i64, ptr %slot446, align 8
  %v2719 = load i64, ptr %slot25, align 8
  %p2720 = inttoptr i64 %v2719 to ptr
  store i64 %v2718, ptr %p2720, align 8, !alias.scope !3, !noalias !4
  %v2721 = load i64, ptr %slot25, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  %ld2723 = load i64, ptr %p2722, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2723, ptr %slot447, align 8
  %v2724 = load i64, ptr %slot24, align 8
  %p2725 = inttoptr i64 %v2724 to ptr
  %ld2726 = load i64, ptr %p2725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2726, ptr %slot448, align 8
  %v2727 = load i64, ptr %slot448, align 8
  %cast2728 = bitcast i64 %v2727 to double
  store double %cast2728, ptr %slot449, align 8
  %v2729 = load i64, ptr %slot447, align 8
  %cast2730 = bitcast i64 %v2729 to double
  store double %cast2730, ptr %slot450, align 8
  %v2731 = load double, ptr %slot449, align 8
  %v2732 = load double, ptr %slot450, align 8
  %op2733 = fmul double %v2731, %v2732
  store double %op2733, ptr %slot451, align 8
  %v2734 = load double, ptr %slot451, align 8
  %cast2735 = bitcast double %v2734 to i64
  store i64 %cast2735, ptr %slot452, align 8
  %v2736 = load i64, ptr %slot452, align 8
  %v2737 = load i64, ptr %slot24, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  store i64 %v2736, ptr %p2738, align 8, !alias.scope !3, !noalias !4
  %v2739 = load i64, ptr %slot47, align 8
  store i64 %v2739, ptr %slot453, align 8
  %v2740 = load i64, ptr %slot453, align 8
  %p2741 = inttoptr i64 %v2740 to ptr
  store i32 2, ptr %p2741, align 4, !alias.scope !3, !noalias !4
  %v2742 = load i64, ptr %slot453, align 8
  %p2744 = inttoptr i64 %v2742 to ptr
  %gep2745 = getelementptr i8, ptr %p2744, i64 8
  %op2743 = ptrtoint ptr %gep2745 to i64
  store i64 %op2743, ptr %slot454, align 8
  %v2746 = load i64, ptr %slot24, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  %ld2748 = load i64, ptr %p2747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2748, ptr %slot455, align 8
  %v2749 = load i64, ptr %slot455, align 8
  %v2750 = load i64, ptr %slot454, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  store i64 %v2749, ptr %p2751, align 8, !alias.scope !3, !noalias !4
  %v2752 = load i64, ptr %slot453, align 8
  %v2753 = load i64, ptr %slot24, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  store i64 %v2752, ptr %p2754, align 8, !alias.scope !3, !noalias !4
  %v2755 = load i64, ptr %slot24, align 8
  %p2756 = inttoptr i64 %v2755 to ptr
  %ld2757 = load i64, ptr %p2756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2757, ptr %slot456, align 8
  %v2758 = load i64, ptr %slot456, align 8
  %p2759 = inttoptr i64 %v2758 to ptr
  %ret2760 = load { i64, i64 }, ptr %p2759, align 8
  ret { i64, i64 } %ret2760
bb_i262:
  %v2761 = load i64, ptr %slot8, align 8
  %p2762 = inttoptr i64 %v2761 to ptr
  %ld2763 = load i64, ptr %p2762, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2763, ptr %slot457, align 8
  %v2764 = load i64, ptr %slot457, align 8
  %v2765 = load i64, ptr %slot24, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  store i64 %v2764, ptr %p2766, align 8, !alias.scope !3, !noalias !4
  %v2767 = load i64, ptr %slot24, align 8
  %p2768 = inttoptr i64 %v2767 to ptr
  %ld2769 = load i64, ptr %p2768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2769, ptr %slot458, align 8
  %v2770 = load i64, ptr %slot458, align 8
  %v2771 = load i64, ptr %slot22, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  store i64 %v2770, ptr %p2772, align 8, !alias.scope !3, !noalias !4
  %v2773 = load i64, ptr %slot9, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  %ld2775 = load i64, ptr %p2774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2775, ptr %slot459, align 8
  %v2776 = load i64, ptr %slot459, align 8
  %v2777 = load i64, ptr %slot24, align 8
  %p2778 = inttoptr i64 %v2777 to ptr
  store i64 %v2776, ptr %p2778, align 8, !alias.scope !3, !noalias !4
  %v2779 = load i64, ptr %slot24, align 8
  %p2780 = inttoptr i64 %v2779 to ptr
  %ld2781 = load i64, ptr %p2780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2781, ptr %slot460, align 8
  %v2782 = load i64, ptr %slot460, align 8
  %v2783 = load i64, ptr %slot23, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  store i64 %v2782, ptr %p2784, align 8, !alias.scope !3, !noalias !4
  %v2785 = load i64, ptr %slot22, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  %ld2787 = load i64, ptr %p2786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2787, ptr %slot461, align 8
  %v2788 = load i64, ptr %slot461, align 8
  %v2789 = load i64, ptr %slot24, align 8
  %p2790 = inttoptr i64 %v2789 to ptr
  store i64 %v2788, ptr %p2790, align 8, !alias.scope !3, !noalias !4
  %v2791 = load i64, ptr %slot23, align 8
  %p2792 = inttoptr i64 %v2791 to ptr
  %ld2793 = load i64, ptr %p2792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2793, ptr %slot462, align 8
  %v2794 = load i64, ptr %slot462, align 8
  %v2795 = load i64, ptr %slot25, align 8
  %p2796 = inttoptr i64 %v2795 to ptr
  store i64 %v2794, ptr %p2796, align 8, !alias.scope !3, !noalias !4
  %v2797 = load i64, ptr %slot25, align 8
  %p2798 = inttoptr i64 %v2797 to ptr
  %ld2799 = load i64, ptr %p2798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2799, ptr %slot463, align 8
  %v2800 = load i64, ptr %slot24, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i64, ptr %p2801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2802, ptr %slot464, align 8
  %v2803 = load i64, ptr %slot464, align 8
  %cast2804 = bitcast i64 %v2803 to double
  store double %cast2804, ptr %slot465, align 8
  %v2805 = load i64, ptr %slot463, align 8
  %cast2806 = bitcast i64 %v2805 to double
  store double %cast2806, ptr %slot466, align 8
  %v2807 = load double, ptr %slot465, align 8
  %v2808 = load double, ptr %slot466, align 8
  %op2809 = fmul double %v2807, %v2808
  store double %op2809, ptr %slot467, align 8
  %v2810 = load double, ptr %slot467, align 8
  %cast2811 = bitcast double %v2810 to i64
  store i64 %cast2811, ptr %slot468, align 8
  %v2812 = load i64, ptr %slot468, align 8
  %v2813 = load i64, ptr %slot24, align 8
  %p2814 = inttoptr i64 %v2813 to ptr
  store i64 %v2812, ptr %p2814, align 8, !alias.scope !3, !noalias !4
  %v2815 = load i64, ptr %slot48, align 8
  store i64 %v2815, ptr %slot469, align 8
  %v2816 = load i64, ptr %slot469, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  store i32 2, ptr %p2817, align 4, !alias.scope !3, !noalias !4
  %v2818 = load i64, ptr %slot469, align 8
  %p2820 = inttoptr i64 %v2818 to ptr
  %gep2821 = getelementptr i8, ptr %p2820, i64 8
  %op2819 = ptrtoint ptr %gep2821 to i64
  store i64 %op2819, ptr %slot470, align 8
  %v2822 = load i64, ptr %slot24, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  %ld2824 = load i64, ptr %p2823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2824, ptr %slot471, align 8
  %v2825 = load i64, ptr %slot471, align 8
  %v2826 = load i64, ptr %slot470, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  store i64 %v2825, ptr %p2827, align 8, !alias.scope !3, !noalias !4
  %v2828 = load i64, ptr %slot469, align 8
  %v2829 = load i64, ptr %slot24, align 8
  %p2830 = inttoptr i64 %v2829 to ptr
  store i64 %v2828, ptr %p2830, align 8, !alias.scope !3, !noalias !4
  %v2831 = load i64, ptr %slot24, align 8
  %p2832 = inttoptr i64 %v2831 to ptr
  %ld2833 = load i64, ptr %p2832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2833, ptr %slot472, align 8
  %v2834 = load i64, ptr %slot472, align 8
  %p2835 = inttoptr i64 %v2834 to ptr
  %ret2836 = load { i64, i64 }, ptr %p2835, align 8
  ret { i64, i64 } %ret2836
bb_i274:
  %v2837 = load i64, ptr %slot8, align 8
  %p2838 = inttoptr i64 %v2837 to ptr
  %ld2839 = load i64, ptr %p2838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2839, ptr %slot473, align 8
  %v2840 = load i64, ptr %slot473, align 8
  %v2841 = load i64, ptr %slot24, align 8
  %p2842 = inttoptr i64 %v2841 to ptr
  store i64 %v2840, ptr %p2842, align 8, !alias.scope !3, !noalias !4
  %v2843 = load i64, ptr %slot24, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  %ld2845 = load i64, ptr %p2844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2845, ptr %slot474, align 8
  %v2846 = load i64, ptr %slot474, align 8
  %v2847 = load i64, ptr %slot22, align 8
  %p2848 = inttoptr i64 %v2847 to ptr
  store i64 %v2846, ptr %p2848, align 8, !alias.scope !3, !noalias !4
  %v2849 = load i64, ptr %slot9, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  %ld2851 = load i64, ptr %p2850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2851, ptr %slot475, align 8
  %v2852 = load i64, ptr %slot475, align 8
  %v2853 = load i64, ptr %slot24, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  store i64 %v2852, ptr %p2854, align 8, !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot24, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  %ld2857 = load i64, ptr %p2856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2857, ptr %slot476, align 8
  %v2858 = load i64, ptr %slot476, align 8
  %v2859 = load i64, ptr %slot23, align 8
  %p2860 = inttoptr i64 %v2859 to ptr
  store i64 %v2858, ptr %p2860, align 8, !alias.scope !3, !noalias !4
  %v2861 = load i64, ptr %slot22, align 8
  %p2862 = inttoptr i64 %v2861 to ptr
  %ld2863 = load i64, ptr %p2862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2863, ptr %slot477, align 8
  %v2864 = load i64, ptr %slot477, align 8
  %v2865 = load i64, ptr %slot24, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  store i64 %v2864, ptr %p2866, align 8, !alias.scope !3, !noalias !4
  %v2867 = load i64, ptr %slot23, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  %ld2869 = load i64, ptr %p2868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2869, ptr %slot478, align 8
  %v2870 = load i64, ptr %slot478, align 8
  %v2871 = load i64, ptr %slot25, align 8
  %p2872 = inttoptr i64 %v2871 to ptr
  store i64 %v2870, ptr %p2872, align 8, !alias.scope !3, !noalias !4
  %v2873 = load i64, ptr %slot25, align 8
  %p2874 = inttoptr i64 %v2873 to ptr
  %ld2875 = load i64, ptr %p2874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2875, ptr %slot479, align 8
  %v2876 = load i64, ptr %slot24, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  %ld2878 = load i64, ptr %p2877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2878, ptr %slot480, align 8
  %v2879 = load i64, ptr %slot480, align 8
  %cast2880 = bitcast i64 %v2879 to double
  store double %cast2880, ptr %slot481, align 8
  %v2881 = load i64, ptr %slot479, align 8
  %cast2882 = bitcast i64 %v2881 to double
  store double %cast2882, ptr %slot482, align 8
  %v2883 = load double, ptr %slot481, align 8
  %v2884 = load double, ptr %slot482, align 8
  %op2885 = fmul double %v2883, %v2884
  store double %op2885, ptr %slot483, align 8
  %v2886 = load double, ptr %slot483, align 8
  %cast2887 = bitcast double %v2886 to i64
  store i64 %cast2887, ptr %slot484, align 8
  %v2888 = load i64, ptr %slot484, align 8
  %v2889 = load i64, ptr %slot24, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  store i64 %v2888, ptr %p2890, align 8, !alias.scope !3, !noalias !4
  %v2891 = load i64, ptr %slot49, align 8
  store i64 %v2891, ptr %slot485, align 8
  %v2892 = load i64, ptr %slot485, align 8
  %p2893 = inttoptr i64 %v2892 to ptr
  store i32 2, ptr %p2893, align 4, !alias.scope !3, !noalias !4
  %v2894 = load i64, ptr %slot485, align 8
  %p2896 = inttoptr i64 %v2894 to ptr
  %gep2897 = getelementptr i8, ptr %p2896, i64 8
  %op2895 = ptrtoint ptr %gep2897 to i64
  store i64 %op2895, ptr %slot486, align 8
  %v2898 = load i64, ptr %slot24, align 8
  %p2899 = inttoptr i64 %v2898 to ptr
  %ld2900 = load i64, ptr %p2899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2900, ptr %slot487, align 8
  %v2901 = load i64, ptr %slot487, align 8
  %v2902 = load i64, ptr %slot486, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  store i64 %v2901, ptr %p2903, align 8, !alias.scope !3, !noalias !4
  %v2904 = load i64, ptr %slot485, align 8
  %v2905 = load i64, ptr %slot24, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  store i64 %v2904, ptr %p2906, align 8, !alias.scope !3, !noalias !4
  %v2907 = load i64, ptr %slot24, align 8
  %p2908 = inttoptr i64 %v2907 to ptr
  %ld2909 = load i64, ptr %p2908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2909, ptr %slot488, align 8
  %v2910 = load i64, ptr %slot488, align 8
  %p2911 = inttoptr i64 %v2910 to ptr
  %ret2912 = load { i64, i64 }, ptr %p2911, align 8
  ret { i64, i64 } %ret2912
bb_i286:
  %v2913 = load i64, ptr %slot8, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  %ld2915 = load i64, ptr %p2914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2915, ptr %slot489, align 8
  %v2916 = load i64, ptr %slot489, align 8
  %v2917 = load i64, ptr %slot24, align 8
  %p2918 = inttoptr i64 %v2917 to ptr
  store i64 %v2916, ptr %p2918, align 8, !alias.scope !3, !noalias !4
  %v2919 = load i64, ptr %slot24, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  %ld2921 = load i64, ptr %p2920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2921, ptr %slot490, align 8
  %v2922 = load i64, ptr %slot490, align 8
  %v2923 = load i64, ptr %slot22, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  store i64 %v2922, ptr %p2924, align 8, !alias.scope !3, !noalias !4
  %v2925 = load i64, ptr %slot9, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  %ld2927 = load i64, ptr %p2926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2927, ptr %slot491, align 8
  %v2928 = load i64, ptr %slot491, align 8
  %v2929 = load i64, ptr %slot24, align 8
  %p2930 = inttoptr i64 %v2929 to ptr
  store i64 %v2928, ptr %p2930, align 8, !alias.scope !3, !noalias !4
  %v2931 = load i64, ptr %slot24, align 8
  %p2932 = inttoptr i64 %v2931 to ptr
  %ld2933 = load i64, ptr %p2932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2933, ptr %slot492, align 8
  %v2934 = load i64, ptr %slot492, align 8
  %v2935 = load i64, ptr %slot23, align 8
  %p2936 = inttoptr i64 %v2935 to ptr
  store i64 %v2934, ptr %p2936, align 8, !alias.scope !3, !noalias !4
  %v2937 = load i64, ptr %slot22, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  %ld2939 = load i64, ptr %p2938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2939, ptr %slot493, align 8
  %v2940 = load i64, ptr %slot493, align 8
  %v2941 = load i64, ptr %slot24, align 8
  %p2942 = inttoptr i64 %v2941 to ptr
  store i64 %v2940, ptr %p2942, align 8, !alias.scope !3, !noalias !4
  %v2943 = load i64, ptr %slot23, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  %ld2945 = load i64, ptr %p2944, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2945, ptr %slot494, align 8
  %v2946 = load i64, ptr %slot494, align 8
  %v2947 = load i64, ptr %slot25, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  store i64 %v2946, ptr %p2948, align 8, !alias.scope !3, !noalias !4
  %v2949 = load i64, ptr %slot25, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  %ld2951 = load i64, ptr %p2950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2951, ptr %slot495, align 8
  %v2952 = load i64, ptr %slot24, align 8
  %p2953 = inttoptr i64 %v2952 to ptr
  %ld2954 = load i64, ptr %p2953, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2954, ptr %slot496, align 8
  %v2955 = load i64, ptr %slot496, align 8
  %cast2956 = bitcast i64 %v2955 to double
  store double %cast2956, ptr %slot497, align 8
  %v2957 = load i64, ptr %slot495, align 8
  %cast2958 = bitcast i64 %v2957 to double
  store double %cast2958, ptr %slot498, align 8
  %v2959 = load double, ptr %slot497, align 8
  %v2960 = load double, ptr %slot498, align 8
  %op2961 = fmul double %v2959, %v2960
  store double %op2961, ptr %slot499, align 8
  %v2962 = load double, ptr %slot499, align 8
  %cast2963 = bitcast double %v2962 to i64
  store i64 %cast2963, ptr %slot500, align 8
  %v2964 = load i64, ptr %slot500, align 8
  %v2965 = load i64, ptr %slot24, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  store i64 %v2964, ptr %p2966, align 8, !alias.scope !3, !noalias !4
  %v2967 = load i64, ptr %slot50, align 8
  store i64 %v2967, ptr %slot501, align 8
  %v2968 = load i64, ptr %slot501, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  store i32 2, ptr %p2969, align 4, !alias.scope !3, !noalias !4
  %v2970 = load i64, ptr %slot501, align 8
  %p2972 = inttoptr i64 %v2970 to ptr
  %gep2973 = getelementptr i8, ptr %p2972, i64 8
  %op2971 = ptrtoint ptr %gep2973 to i64
  store i64 %op2971, ptr %slot502, align 8
  %v2974 = load i64, ptr %slot24, align 8
  %p2975 = inttoptr i64 %v2974 to ptr
  %ld2976 = load i64, ptr %p2975, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2976, ptr %slot503, align 8
  %v2977 = load i64, ptr %slot503, align 8
  %v2978 = load i64, ptr %slot502, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  store i64 %v2977, ptr %p2979, align 8, !alias.scope !3, !noalias !4
  %v2980 = load i64, ptr %slot501, align 8
  %v2981 = load i64, ptr %slot24, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  store i64 %v2980, ptr %p2982, align 8, !alias.scope !3, !noalias !4
  %v2983 = load i64, ptr %slot24, align 8
  %p2984 = inttoptr i64 %v2983 to ptr
  %ld2985 = load i64, ptr %p2984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2985, ptr %slot504, align 8
  %v2986 = load i64, ptr %slot504, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  %ret2988 = load { i64, i64 }, ptr %p2987, align 8
  ret { i64, i64 } %ret2988
bb_i298:
  %v2989 = load i64, ptr %slot8, align 8
  %p2990 = inttoptr i64 %v2989 to ptr
  %ld2991 = load i64, ptr %p2990, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2991, ptr %slot505, align 8
  %v2992 = load i64, ptr %slot505, align 8
  %v2993 = load i64, ptr %slot24, align 8
  %p2994 = inttoptr i64 %v2993 to ptr
  store i64 %v2992, ptr %p2994, align 8, !alias.scope !3, !noalias !4
  %v2995 = load i64, ptr %slot24, align 8
  %p2996 = inttoptr i64 %v2995 to ptr
  %ld2997 = load i64, ptr %p2996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2997, ptr %slot506, align 8
  %v2998 = load i64, ptr %slot506, align 8
  %v2999 = load i64, ptr %slot22, align 8
  %p3000 = inttoptr i64 %v2999 to ptr
  store i64 %v2998, ptr %p3000, align 8, !alias.scope !3, !noalias !4
  %v3001 = load i64, ptr %slot9, align 8
  %p3002 = inttoptr i64 %v3001 to ptr
  %ld3003 = load i64, ptr %p3002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3003, ptr %slot507, align 8
  %v3004 = load i64, ptr %slot507, align 8
  %v3005 = load i64, ptr %slot24, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  store i64 %v3004, ptr %p3006, align 8, !alias.scope !3, !noalias !4
  %v3007 = load i64, ptr %slot24, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  %ld3009 = load i64, ptr %p3008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3009, ptr %slot508, align 8
  %v3010 = load i64, ptr %slot508, align 8
  %v3011 = load i64, ptr %slot23, align 8
  %p3012 = inttoptr i64 %v3011 to ptr
  store i64 %v3010, ptr %p3012, align 8, !alias.scope !3, !noalias !4
  %v3013 = load i64, ptr %slot22, align 8
  %p3014 = inttoptr i64 %v3013 to ptr
  %ld3015 = load i64, ptr %p3014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3015, ptr %slot509, align 8
  %v3016 = load i64, ptr %slot509, align 8
  %v3017 = load i64, ptr %slot24, align 8
  %p3018 = inttoptr i64 %v3017 to ptr
  store i64 %v3016, ptr %p3018, align 8, !alias.scope !3, !noalias !4
  %v3019 = load i64, ptr %slot23, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %ld3021 = load i64, ptr %p3020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3021, ptr %slot510, align 8
  %v3022 = load i64, ptr %slot510, align 8
  %v3023 = load i64, ptr %slot25, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  store i64 %v3022, ptr %p3024, align 8, !alias.scope !3, !noalias !4
  %v3025 = load i64, ptr %slot25, align 8
  %p3026 = inttoptr i64 %v3025 to ptr
  %ld3027 = load i64, ptr %p3026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3027, ptr %slot511, align 8
  %v3028 = load i64, ptr %slot24, align 8
  %p3029 = inttoptr i64 %v3028 to ptr
  %ld3030 = load i64, ptr %p3029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3030, ptr %slot512, align 8
  %v3031 = load i64, ptr %slot512, align 8
  %cast3032 = bitcast i64 %v3031 to double
  store double %cast3032, ptr %slot513, align 8
  %v3033 = load i64, ptr %slot511, align 8
  %cast3034 = bitcast i64 %v3033 to double
  store double %cast3034, ptr %slot514, align 8
  %v3035 = load double, ptr %slot513, align 8
  %v3036 = load double, ptr %slot514, align 8
  %op3037 = fmul double %v3035, %v3036
  store double %op3037, ptr %slot515, align 8
  %v3038 = load double, ptr %slot515, align 8
  %cast3039 = bitcast double %v3038 to i64
  store i64 %cast3039, ptr %slot516, align 8
  %v3040 = load i64, ptr %slot516, align 8
  %v3041 = load i64, ptr %slot24, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  store i64 %v3040, ptr %p3042, align 8, !alias.scope !3, !noalias !4
  %v3043 = load i64, ptr %slot51, align 8
  store i64 %v3043, ptr %slot517, align 8
  %v3044 = load i64, ptr %slot517, align 8
  %p3045 = inttoptr i64 %v3044 to ptr
  store i32 2, ptr %p3045, align 4, !alias.scope !3, !noalias !4
  %v3046 = load i64, ptr %slot517, align 8
  %p3048 = inttoptr i64 %v3046 to ptr
  %gep3049 = getelementptr i8, ptr %p3048, i64 8
  %op3047 = ptrtoint ptr %gep3049 to i64
  store i64 %op3047, ptr %slot518, align 8
  %v3050 = load i64, ptr %slot24, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %ld3052 = load i64, ptr %p3051, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3052, ptr %slot519, align 8
  %v3053 = load i64, ptr %slot519, align 8
  %v3054 = load i64, ptr %slot518, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  store i64 %v3053, ptr %p3055, align 8, !alias.scope !3, !noalias !4
  %v3056 = load i64, ptr %slot517, align 8
  %v3057 = load i64, ptr %slot24, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  store i64 %v3056, ptr %p3058, align 8, !alias.scope !3, !noalias !4
  %v3059 = load i64, ptr %slot24, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  %ld3061 = load i64, ptr %p3060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3061, ptr %slot520, align 8
  %v3062 = load i64, ptr %slot520, align 8
  %p3063 = inttoptr i64 %v3062 to ptr
  %ret3064 = load { i64, i64 }, ptr %p3063, align 8
  ret { i64, i64 } %ret3064
bb_i310:
  %v3065 = load i64, ptr %slot8, align 8
  %p3066 = inttoptr i64 %v3065 to ptr
  %ld3067 = load i64, ptr %p3066, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3067, ptr %slot521, align 8
  %v3068 = load i64, ptr %slot521, align 8
  %v3069 = load i64, ptr %slot24, align 8
  %p3070 = inttoptr i64 %v3069 to ptr
  store i64 %v3068, ptr %p3070, align 8, !alias.scope !3, !noalias !4
  %v3071 = load i64, ptr %slot24, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  %ld3073 = load i64, ptr %p3072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3073, ptr %slot522, align 8
  %v3074 = load i64, ptr %slot522, align 8
  %v3075 = load i64, ptr %slot22, align 8
  %p3076 = inttoptr i64 %v3075 to ptr
  store i64 %v3074, ptr %p3076, align 8, !alias.scope !3, !noalias !4
  %v3077 = load i64, ptr %slot9, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  %ld3079 = load i64, ptr %p3078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3079, ptr %slot523, align 8
  %v3080 = load i64, ptr %slot523, align 8
  %v3081 = load i64, ptr %slot24, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  store i64 %v3080, ptr %p3082, align 8, !alias.scope !3, !noalias !4
  %v3083 = load i64, ptr %slot24, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  %ld3085 = load i64, ptr %p3084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3085, ptr %slot524, align 8
  %v3086 = load i64, ptr %slot524, align 8
  %v3087 = load i64, ptr %slot23, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  store i64 %v3086, ptr %p3088, align 8, !alias.scope !3, !noalias !4
  %v3089 = load i64, ptr %slot22, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %ld3091 = load i64, ptr %p3090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3091, ptr %slot525, align 8
  %v3092 = load i64, ptr %slot525, align 8
  %v3093 = load i64, ptr %slot24, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  store i64 %v3092, ptr %p3094, align 8, !alias.scope !3, !noalias !4
  %v3095 = load i64, ptr %slot23, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  %ld3097 = load i64, ptr %p3096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3097, ptr %slot526, align 8
  %v3098 = load i64, ptr %slot526, align 8
  %v3099 = load i64, ptr %slot25, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  store i64 %v3098, ptr %p3100, align 8, !alias.scope !3, !noalias !4
  %v3101 = load i64, ptr %slot25, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %ld3103 = load i64, ptr %p3102, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3103, ptr %slot527, align 8
  %v3104 = load i64, ptr %slot24, align 8
  %p3105 = inttoptr i64 %v3104 to ptr
  %ld3106 = load i64, ptr %p3105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3106, ptr %slot528, align 8
  %v3107 = load i64, ptr %slot528, align 8
  %cast3108 = bitcast i64 %v3107 to double
  store double %cast3108, ptr %slot529, align 8
  %v3109 = load i64, ptr %slot527, align 8
  %cast3110 = bitcast i64 %v3109 to double
  store double %cast3110, ptr %slot530, align 8
  %v3111 = load double, ptr %slot529, align 8
  %v3112 = load double, ptr %slot530, align 8
  %op3113 = fmul double %v3111, %v3112
  store double %op3113, ptr %slot531, align 8
  %v3114 = load double, ptr %slot531, align 8
  %cast3115 = bitcast double %v3114 to i64
  store i64 %cast3115, ptr %slot532, align 8
  %v3116 = load i64, ptr %slot532, align 8
  %v3117 = load i64, ptr %slot24, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  store i64 %v3116, ptr %p3118, align 8, !alias.scope !3, !noalias !4
  %v3119 = load i64, ptr %slot52, align 8
  store i64 %v3119, ptr %slot533, align 8
  %v3120 = load i64, ptr %slot533, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  store i32 2, ptr %p3121, align 4, !alias.scope !3, !noalias !4
  %v3122 = load i64, ptr %slot533, align 8
  %p3124 = inttoptr i64 %v3122 to ptr
  %gep3125 = getelementptr i8, ptr %p3124, i64 8
  %op3123 = ptrtoint ptr %gep3125 to i64
  store i64 %op3123, ptr %slot534, align 8
  %v3126 = load i64, ptr %slot24, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  %ld3128 = load i64, ptr %p3127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3128, ptr %slot535, align 8
  %v3129 = load i64, ptr %slot535, align 8
  %v3130 = load i64, ptr %slot534, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  store i64 %v3129, ptr %p3131, align 8, !alias.scope !3, !noalias !4
  %v3132 = load i64, ptr %slot533, align 8
  %v3133 = load i64, ptr %slot24, align 8
  %p3134 = inttoptr i64 %v3133 to ptr
  store i64 %v3132, ptr %p3134, align 8, !alias.scope !3, !noalias !4
  %v3135 = load i64, ptr %slot24, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  %ld3137 = load i64, ptr %p3136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3137, ptr %slot536, align 8
  %v3138 = load i64, ptr %slot536, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  %ret3140 = load { i64, i64 }, ptr %p3139, align 8
  ret { i64, i64 } %ret3140
bb_i322:
  %v3141 = load i64, ptr %slot8, align 8
  %p3142 = inttoptr i64 %v3141 to ptr
  %ld3143 = load i64, ptr %p3142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3143, ptr %slot537, align 8
  %v3144 = load i64, ptr %slot537, align 8
  %v3145 = load i64, ptr %slot24, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  store i64 %v3144, ptr %p3146, align 8, !alias.scope !3, !noalias !4
  %v3147 = load i64, ptr %slot24, align 8
  %p3148 = inttoptr i64 %v3147 to ptr
  %ld3149 = load i64, ptr %p3148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3149, ptr %slot538, align 8
  %v3150 = load i64, ptr %slot538, align 8
  %v3151 = load i64, ptr %slot22, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  store i64 %v3150, ptr %p3152, align 8, !alias.scope !3, !noalias !4
  %v3153 = load i64, ptr %slot9, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  %ld3155 = load i64, ptr %p3154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3155, ptr %slot539, align 8
  %v3156 = load i64, ptr %slot539, align 8
  %v3157 = load i64, ptr %slot24, align 8
  %p3158 = inttoptr i64 %v3157 to ptr
  store i64 %v3156, ptr %p3158, align 8, !alias.scope !3, !noalias !4
  %v3159 = load i64, ptr %slot24, align 8
  %p3160 = inttoptr i64 %v3159 to ptr
  %ld3161 = load i64, ptr %p3160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3161, ptr %slot540, align 8
  %v3162 = load i64, ptr %slot540, align 8
  %v3163 = load i64, ptr %slot23, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  store i64 %v3162, ptr %p3164, align 8, !alias.scope !3, !noalias !4
  %v3165 = load i64, ptr %slot22, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %ld3167 = load i64, ptr %p3166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3167, ptr %slot541, align 8
  %v3168 = load i64, ptr %slot541, align 8
  %v3169 = load i64, ptr %slot24, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  store i64 %v3168, ptr %p3170, align 8, !alias.scope !3, !noalias !4
  %v3171 = load i64, ptr %slot23, align 8
  %p3172 = inttoptr i64 %v3171 to ptr
  %ld3173 = load i64, ptr %p3172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3173, ptr %slot542, align 8
  %v3174 = load i64, ptr %slot542, align 8
  %v3175 = load i64, ptr %slot25, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  store i64 %v3174, ptr %p3176, align 8, !alias.scope !3, !noalias !4
  %v3177 = load i64, ptr %slot25, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %ld3179 = load i64, ptr %p3178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3179, ptr %slot543, align 8
  %v3180 = load i64, ptr %slot24, align 8
  %p3181 = inttoptr i64 %v3180 to ptr
  %ld3182 = load i64, ptr %p3181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3182, ptr %slot544, align 8
  %v3183 = load i64, ptr %slot544, align 8
  %cast3184 = bitcast i64 %v3183 to double
  store double %cast3184, ptr %slot545, align 8
  %v3185 = load i64, ptr %slot543, align 8
  %cast3186 = bitcast i64 %v3185 to double
  store double %cast3186, ptr %slot546, align 8
  %v3187 = load double, ptr %slot545, align 8
  %v3188 = load double, ptr %slot546, align 8
  %op3189 = fmul double %v3187, %v3188
  store double %op3189, ptr %slot547, align 8
  %v3190 = load double, ptr %slot547, align 8
  %cast3191 = bitcast double %v3190 to i64
  store i64 %cast3191, ptr %slot548, align 8
  %v3192 = load i64, ptr %slot548, align 8
  %v3193 = load i64, ptr %slot24, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  store i64 %v3192, ptr %p3194, align 8, !alias.scope !3, !noalias !4
  %v3195 = load i64, ptr %slot53, align 8
  store i64 %v3195, ptr %slot549, align 8
  %v3196 = load i64, ptr %slot549, align 8
  %p3197 = inttoptr i64 %v3196 to ptr
  store i32 2, ptr %p3197, align 4, !alias.scope !3, !noalias !4
  %v3198 = load i64, ptr %slot549, align 8
  %p3200 = inttoptr i64 %v3198 to ptr
  %gep3201 = getelementptr i8, ptr %p3200, i64 8
  %op3199 = ptrtoint ptr %gep3201 to i64
  store i64 %op3199, ptr %slot550, align 8
  %v3202 = load i64, ptr %slot24, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  %ld3204 = load i64, ptr %p3203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3204, ptr %slot551, align 8
  %v3205 = load i64, ptr %slot551, align 8
  %v3206 = load i64, ptr %slot550, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  store i64 %v3205, ptr %p3207, align 8, !alias.scope !3, !noalias !4
  %v3208 = load i64, ptr %slot549, align 8
  %v3209 = load i64, ptr %slot24, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  store i64 %v3208, ptr %p3210, align 8, !alias.scope !3, !noalias !4
  %v3211 = load i64, ptr %slot24, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  %ld3213 = load i64, ptr %p3212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3213, ptr %slot552, align 8
  %v3214 = load i64, ptr %slot552, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  %ret3216 = load { i64, i64 }, ptr %p3215, align 8
  ret { i64, i64 } %ret3216
bb_i334:
  %v3217 = load i64, ptr %slot8, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  %ld3219 = load i64, ptr %p3218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3219, ptr %slot553, align 8
  %v3220 = load i64, ptr %slot553, align 8
  %v3221 = load i64, ptr %slot24, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  store i64 %v3220, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  %v3223 = load i64, ptr %slot24, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %ld3225 = load i64, ptr %p3224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3225, ptr %slot554, align 8
  %v3226 = load i64, ptr %slot554, align 8
  %v3227 = load i64, ptr %slot22, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  store i64 %v3226, ptr %p3228, align 8, !alias.scope !3, !noalias !4
  %v3229 = load i64, ptr %slot9, align 8
  %p3230 = inttoptr i64 %v3229 to ptr
  %ld3231 = load i64, ptr %p3230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3231, ptr %slot555, align 8
  %v3232 = load i64, ptr %slot555, align 8
  %v3233 = load i64, ptr %slot24, align 8
  %p3234 = inttoptr i64 %v3233 to ptr
  store i64 %v3232, ptr %p3234, align 8, !alias.scope !3, !noalias !4
  %v3235 = load i64, ptr %slot24, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  %ld3237 = load i64, ptr %p3236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3237, ptr %slot556, align 8
  %v3238 = load i64, ptr %slot556, align 8
  %v3239 = load i64, ptr %slot23, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  store i64 %v3238, ptr %p3240, align 8, !alias.scope !3, !noalias !4
  %v3241 = load i64, ptr %slot22, align 8
  %p3242 = inttoptr i64 %v3241 to ptr
  %ld3243 = load i64, ptr %p3242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3243, ptr %slot557, align 8
  %v3244 = load i64, ptr %slot557, align 8
  %v3245 = load i64, ptr %slot24, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  store i64 %v3244, ptr %p3246, align 8, !alias.scope !3, !noalias !4
  %v3247 = load i64, ptr %slot23, align 8
  %p3248 = inttoptr i64 %v3247 to ptr
  %ld3249 = load i64, ptr %p3248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3249, ptr %slot558, align 8
  %v3250 = load i64, ptr %slot558, align 8
  %v3251 = load i64, ptr %slot25, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  store i64 %v3250, ptr %p3252, align 8, !alias.scope !3, !noalias !4
  %v3253 = load i64, ptr %slot25, align 8
  %p3254 = inttoptr i64 %v3253 to ptr
  %ld3255 = load i64, ptr %p3254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3255, ptr %slot559, align 8
  %v3256 = load i64, ptr %slot24, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  %ld3258 = load i64, ptr %p3257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3258, ptr %slot560, align 8
  %v3259 = load i64, ptr %slot560, align 8
  %cast3260 = bitcast i64 %v3259 to double
  store double %cast3260, ptr %slot561, align 8
  %v3261 = load i64, ptr %slot559, align 8
  %cast3262 = bitcast i64 %v3261 to double
  store double %cast3262, ptr %slot562, align 8
  %v3263 = load double, ptr %slot561, align 8
  %v3264 = load double, ptr %slot562, align 8
  %op3265 = fmul double %v3263, %v3264
  store double %op3265, ptr %slot563, align 8
  %v3266 = load double, ptr %slot563, align 8
  %cast3267 = bitcast double %v3266 to i64
  store i64 %cast3267, ptr %slot564, align 8
  %v3268 = load i64, ptr %slot564, align 8
  %v3269 = load i64, ptr %slot24, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  store i64 %v3268, ptr %p3270, align 8, !alias.scope !3, !noalias !4
  %v3271 = load i64, ptr %slot54, align 8
  store i64 %v3271, ptr %slot565, align 8
  %v3272 = load i64, ptr %slot565, align 8
  %p3273 = inttoptr i64 %v3272 to ptr
  store i32 2, ptr %p3273, align 4, !alias.scope !3, !noalias !4
  %v3274 = load i64, ptr %slot565, align 8
  %p3276 = inttoptr i64 %v3274 to ptr
  %gep3277 = getelementptr i8, ptr %p3276, i64 8
  %op3275 = ptrtoint ptr %gep3277 to i64
  store i64 %op3275, ptr %slot566, align 8
  %v3278 = load i64, ptr %slot24, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  %ld3280 = load i64, ptr %p3279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3280, ptr %slot567, align 8
  %v3281 = load i64, ptr %slot567, align 8
  %v3282 = load i64, ptr %slot566, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  store i64 %v3281, ptr %p3283, align 8, !alias.scope !3, !noalias !4
  %v3284 = load i64, ptr %slot565, align 8
  %v3285 = load i64, ptr %slot24, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  store i64 %v3284, ptr %p3286, align 8, !alias.scope !3, !noalias !4
  %v3287 = load i64, ptr %slot24, align 8
  %p3288 = inttoptr i64 %v3287 to ptr
  %ld3289 = load i64, ptr %p3288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3289, ptr %slot568, align 8
  %v3290 = load i64, ptr %slot568, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  %ret3292 = load { i64, i64 }, ptr %p3291, align 8
  ret { i64, i64 } %ret3292
bb_i346:
  %v3293 = load i64, ptr %slot8, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  %ld3295 = load i64, ptr %p3294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3295, ptr %slot569, align 8
  %v3296 = load i64, ptr %slot569, align 8
  %v3297 = load i64, ptr %slot24, align 8
  %p3298 = inttoptr i64 %v3297 to ptr
  store i64 %v3296, ptr %p3298, align 8, !alias.scope !3, !noalias !4
  %v3299 = load i64, ptr %slot24, align 8
  %p3300 = inttoptr i64 %v3299 to ptr
  %ld3301 = load i64, ptr %p3300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3301, ptr %slot570, align 8
  %v3302 = load i64, ptr %slot570, align 8
  %v3303 = load i64, ptr %slot22, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  store i64 %v3302, ptr %p3304, align 8, !alias.scope !3, !noalias !4
  %v3305 = load i64, ptr %slot9, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  %ld3307 = load i64, ptr %p3306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3307, ptr %slot571, align 8
  %v3308 = load i64, ptr %slot571, align 8
  %v3309 = load i64, ptr %slot24, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  store i64 %v3308, ptr %p3310, align 8, !alias.scope !3, !noalias !4
  %v3311 = load i64, ptr %slot24, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  %ld3313 = load i64, ptr %p3312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3313, ptr %slot572, align 8
  %v3314 = load i64, ptr %slot572, align 8
  %v3315 = load i64, ptr %slot23, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  store i64 %v3314, ptr %p3316, align 8, !alias.scope !3, !noalias !4
  %v3317 = load i64, ptr %slot22, align 8
  %p3318 = inttoptr i64 %v3317 to ptr
  %ld3319 = load i64, ptr %p3318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3319, ptr %slot573, align 8
  %v3320 = load i64, ptr %slot573, align 8
  %v3321 = load i64, ptr %slot24, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  store i64 %v3320, ptr %p3322, align 8, !alias.scope !3, !noalias !4
  %v3323 = load i64, ptr %slot23, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  %ld3325 = load i64, ptr %p3324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3325, ptr %slot574, align 8
  %v3326 = load i64, ptr %slot574, align 8
  %v3327 = load i64, ptr %slot25, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  store i64 %v3326, ptr %p3328, align 8, !alias.scope !3, !noalias !4
  %v3329 = load i64, ptr %slot25, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  %ld3331 = load i64, ptr %p3330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3331, ptr %slot575, align 8
  %v3332 = load i64, ptr %slot24, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i64, ptr %p3333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3334, ptr %slot576, align 8
  %v3335 = load i64, ptr %slot576, align 8
  %cast3336 = bitcast i64 %v3335 to double
  store double %cast3336, ptr %slot577, align 8
  %v3337 = load i64, ptr %slot575, align 8
  %cast3338 = bitcast i64 %v3337 to double
  store double %cast3338, ptr %slot578, align 8
  %v3339 = load double, ptr %slot577, align 8
  %v3340 = load double, ptr %slot578, align 8
  %op3341 = fmul double %v3339, %v3340
  store double %op3341, ptr %slot579, align 8
  %v3342 = load double, ptr %slot579, align 8
  %cast3343 = bitcast double %v3342 to i64
  store i64 %cast3343, ptr %slot580, align 8
  %v3344 = load i64, ptr %slot580, align 8
  %v3345 = load i64, ptr %slot24, align 8
  %p3346 = inttoptr i64 %v3345 to ptr
  store i64 %v3344, ptr %p3346, align 8, !alias.scope !3, !noalias !4
  %v3347 = load i64, ptr %slot55, align 8
  store i64 %v3347, ptr %slot581, align 8
  %v3348 = load i64, ptr %slot581, align 8
  %p3349 = inttoptr i64 %v3348 to ptr
  store i32 2, ptr %p3349, align 4, !alias.scope !3, !noalias !4
  %v3350 = load i64, ptr %slot581, align 8
  %p3352 = inttoptr i64 %v3350 to ptr
  %gep3353 = getelementptr i8, ptr %p3352, i64 8
  %op3351 = ptrtoint ptr %gep3353 to i64
  store i64 %op3351, ptr %slot582, align 8
  %v3354 = load i64, ptr %slot24, align 8
  %p3355 = inttoptr i64 %v3354 to ptr
  %ld3356 = load i64, ptr %p3355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3356, ptr %slot583, align 8
  %v3357 = load i64, ptr %slot583, align 8
  %v3358 = load i64, ptr %slot582, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  store i64 %v3357, ptr %p3359, align 8, !alias.scope !3, !noalias !4
  %v3360 = load i64, ptr %slot581, align 8
  %v3361 = load i64, ptr %slot24, align 8
  %p3362 = inttoptr i64 %v3361 to ptr
  store i64 %v3360, ptr %p3362, align 8, !alias.scope !3, !noalias !4
  %v3363 = load i64, ptr %slot24, align 8
  %p3364 = inttoptr i64 %v3363 to ptr
  %ld3365 = load i64, ptr %p3364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3365, ptr %slot584, align 8
  %v3366 = load i64, ptr %slot584, align 8
  %p3367 = inttoptr i64 %v3366 to ptr
  %ret3368 = load { i64, i64 }, ptr %p3367, align 8
  ret { i64, i64 } %ret3368
bb_i358:
  %v3369 = load i64, ptr %slot8, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  %ld3371 = load i64, ptr %p3370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3371, ptr %slot585, align 8
  %v3372 = load i64, ptr %slot585, align 8
  %v3373 = load i64, ptr %slot24, align 8
  %p3374 = inttoptr i64 %v3373 to ptr
  store i64 %v3372, ptr %p3374, align 8, !alias.scope !3, !noalias !4
  %v3375 = load i64, ptr %slot24, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  %ld3377 = load i64, ptr %p3376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3377, ptr %slot586, align 8
  %v3378 = load i64, ptr %slot586, align 8
  %v3379 = load i64, ptr %slot22, align 8
  %p3380 = inttoptr i64 %v3379 to ptr
  store i64 %v3378, ptr %p3380, align 8, !alias.scope !3, !noalias !4
  %v3381 = load i64, ptr %slot9, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  %ld3383 = load i64, ptr %p3382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3383, ptr %slot587, align 8
  %v3384 = load i64, ptr %slot587, align 8
  %v3385 = load i64, ptr %slot24, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  store i64 %v3384, ptr %p3386, align 8, !alias.scope !3, !noalias !4
  %v3387 = load i64, ptr %slot24, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  %ld3389 = load i64, ptr %p3388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3389, ptr %slot588, align 8
  %v3390 = load i64, ptr %slot588, align 8
  %v3391 = load i64, ptr %slot23, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  store i64 %v3390, ptr %p3392, align 8, !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot22, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  %ld3395 = load i64, ptr %p3394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3395, ptr %slot589, align 8
  %v3396 = load i64, ptr %slot589, align 8
  %v3397 = load i64, ptr %slot24, align 8
  %p3398 = inttoptr i64 %v3397 to ptr
  store i64 %v3396, ptr %p3398, align 8, !alias.scope !3, !noalias !4
  %v3399 = load i64, ptr %slot23, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  %ld3401 = load i64, ptr %p3400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3401, ptr %slot590, align 8
  %v3402 = load i64, ptr %slot590, align 8
  %v3403 = load i64, ptr %slot25, align 8
  %p3404 = inttoptr i64 %v3403 to ptr
  store i64 %v3402, ptr %p3404, align 8, !alias.scope !3, !noalias !4
  %v3405 = load i64, ptr %slot25, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  %ld3407 = load i64, ptr %p3406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3407, ptr %slot591, align 8
  %v3408 = load i64, ptr %slot24, align 8
  %p3409 = inttoptr i64 %v3408 to ptr
  %ld3410 = load i64, ptr %p3409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3410, ptr %slot592, align 8
  %v3411 = load i64, ptr %slot592, align 8
  %cast3412 = bitcast i64 %v3411 to double
  store double %cast3412, ptr %slot593, align 8
  %v3413 = load i64, ptr %slot591, align 8
  %cast3414 = bitcast i64 %v3413 to double
  store double %cast3414, ptr %slot594, align 8
  %v3415 = load double, ptr %slot593, align 8
  %v3416 = load double, ptr %slot594, align 8
  %op3417 = fmul double %v3415, %v3416
  store double %op3417, ptr %slot595, align 8
  %v3418 = load double, ptr %slot595, align 8
  %cast3419 = bitcast double %v3418 to i64
  store i64 %cast3419, ptr %slot596, align 8
  %v3420 = load i64, ptr %slot596, align 8
  %v3421 = load i64, ptr %slot24, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  store i64 %v3420, ptr %p3422, align 8, !alias.scope !3, !noalias !4
  %v3423 = load i64, ptr %slot56, align 8
  store i64 %v3423, ptr %slot597, align 8
  %v3424 = load i64, ptr %slot597, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  store i32 2, ptr %p3425, align 4, !alias.scope !3, !noalias !4
  %v3426 = load i64, ptr %slot597, align 8
  %p3428 = inttoptr i64 %v3426 to ptr
  %gep3429 = getelementptr i8, ptr %p3428, i64 8
  %op3427 = ptrtoint ptr %gep3429 to i64
  store i64 %op3427, ptr %slot598, align 8
  %v3430 = load i64, ptr %slot24, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %ld3432 = load i64, ptr %p3431, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3432, ptr %slot599, align 8
  %v3433 = load i64, ptr %slot599, align 8
  %v3434 = load i64, ptr %slot598, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  store i64 %v3433, ptr %p3435, align 8, !alias.scope !3, !noalias !4
  %v3436 = load i64, ptr %slot597, align 8
  %v3437 = load i64, ptr %slot24, align 8
  %p3438 = inttoptr i64 %v3437 to ptr
  store i64 %v3436, ptr %p3438, align 8, !alias.scope !3, !noalias !4
  %v3439 = load i64, ptr %slot24, align 8
  %p3440 = inttoptr i64 %v3439 to ptr
  %ld3441 = load i64, ptr %p3440, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3441, ptr %slot600, align 8
  %v3442 = load i64, ptr %slot600, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  %ret3444 = load { i64, i64 }, ptr %p3443, align 8
  ret { i64, i64 } %ret3444
bb_i370:
  %v3445 = load i64, ptr %slot8, align 8
  %p3446 = inttoptr i64 %v3445 to ptr
  %ld3447 = load i64, ptr %p3446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3447, ptr %slot601, align 8
  %v3448 = load i64, ptr %slot601, align 8
  %v3449 = load i64, ptr %slot24, align 8
  %p3450 = inttoptr i64 %v3449 to ptr
  store i64 %v3448, ptr %p3450, align 8, !alias.scope !3, !noalias !4
  %v3451 = load i64, ptr %slot24, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  %ld3453 = load i64, ptr %p3452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3453, ptr %slot602, align 8
  %v3454 = load i64, ptr %slot602, align 8
  %v3455 = load i64, ptr %slot22, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  store i64 %v3454, ptr %p3456, align 8, !alias.scope !3, !noalias !4
  %v3457 = load i64, ptr %slot9, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  %ld3459 = load i64, ptr %p3458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3459, ptr %slot603, align 8
  %v3460 = load i64, ptr %slot603, align 8
  %v3461 = load i64, ptr %slot24, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  store i64 %v3460, ptr %p3462, align 8, !alias.scope !3, !noalias !4
  %v3463 = load i64, ptr %slot24, align 8
  %p3464 = inttoptr i64 %v3463 to ptr
  %ld3465 = load i64, ptr %p3464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3465, ptr %slot604, align 8
  %v3466 = load i64, ptr %slot604, align 8
  %v3467 = load i64, ptr %slot23, align 8
  %p3468 = inttoptr i64 %v3467 to ptr
  store i64 %v3466, ptr %p3468, align 8, !alias.scope !3, !noalias !4
  %v3469 = load i64, ptr %slot22, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  %ld3471 = load i64, ptr %p3470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3471, ptr %slot605, align 8
  %v3472 = load i64, ptr %slot605, align 8
  %v3473 = load i64, ptr %slot24, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  store i64 %v3472, ptr %p3474, align 8, !alias.scope !3, !noalias !4
  %v3475 = load i64, ptr %slot23, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  %ld3477 = load i64, ptr %p3476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3477, ptr %slot606, align 8
  %v3478 = load i64, ptr %slot606, align 8
  %v3479 = load i64, ptr %slot25, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  store i64 %v3478, ptr %p3480, align 8, !alias.scope !3, !noalias !4
  %v3481 = load i64, ptr %slot25, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  %ld3483 = load i64, ptr %p3482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3483, ptr %slot607, align 8
  %v3484 = load i64, ptr %slot24, align 8
  %p3485 = inttoptr i64 %v3484 to ptr
  %ld3486 = load i64, ptr %p3485, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3486, ptr %slot608, align 8
  %v3487 = load i64, ptr %slot608, align 8
  %cast3488 = bitcast i64 %v3487 to double
  store double %cast3488, ptr %slot609, align 8
  %v3489 = load i64, ptr %slot607, align 8
  %cast3490 = bitcast i64 %v3489 to double
  store double %cast3490, ptr %slot610, align 8
  %v3491 = load double, ptr %slot609, align 8
  %v3492 = load double, ptr %slot610, align 8
  %op3493 = fmul double %v3491, %v3492
  store double %op3493, ptr %slot611, align 8
  %v3494 = load double, ptr %slot611, align 8
  %cast3495 = bitcast double %v3494 to i64
  store i64 %cast3495, ptr %slot612, align 8
  %v3496 = load i64, ptr %slot612, align 8
  %v3497 = load i64, ptr %slot24, align 8
  %p3498 = inttoptr i64 %v3497 to ptr
  store i64 %v3496, ptr %p3498, align 8, !alias.scope !3, !noalias !4
  %v3499 = load i64, ptr %slot57, align 8
  store i64 %v3499, ptr %slot613, align 8
  %v3500 = load i64, ptr %slot613, align 8
  %p3501 = inttoptr i64 %v3500 to ptr
  store i32 2, ptr %p3501, align 4, !alias.scope !3, !noalias !4
  %v3502 = load i64, ptr %slot613, align 8
  %p3504 = inttoptr i64 %v3502 to ptr
  %gep3505 = getelementptr i8, ptr %p3504, i64 8
  %op3503 = ptrtoint ptr %gep3505 to i64
  store i64 %op3503, ptr %slot614, align 8
  %v3506 = load i64, ptr %slot24, align 8
  %p3507 = inttoptr i64 %v3506 to ptr
  %ld3508 = load i64, ptr %p3507, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3508, ptr %slot615, align 8
  %v3509 = load i64, ptr %slot615, align 8
  %v3510 = load i64, ptr %slot614, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  store i64 %v3509, ptr %p3511, align 8, !alias.scope !3, !noalias !4
  %v3512 = load i64, ptr %slot613, align 8
  %v3513 = load i64, ptr %slot24, align 8
  %p3514 = inttoptr i64 %v3513 to ptr
  store i64 %v3512, ptr %p3514, align 8, !alias.scope !3, !noalias !4
  %v3515 = load i64, ptr %slot24, align 8
  %p3516 = inttoptr i64 %v3515 to ptr
  %ld3517 = load i64, ptr %p3516, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3517, ptr %slot616, align 8
  %v3518 = load i64, ptr %slot616, align 8
  %p3519 = inttoptr i64 %v3518 to ptr
  %ret3520 = load { i64, i64 }, ptr %p3519, align 8
  ret { i64, i64 } %ret3520
bb_i382:
  %v3521 = load i64, ptr %slot8, align 8
  %p3522 = inttoptr i64 %v3521 to ptr
  %ld3523 = load i64, ptr %p3522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3523, ptr %slot617, align 8
  %v3524 = load i64, ptr %slot617, align 8
  %v3525 = load i64, ptr %slot24, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  store i64 %v3524, ptr %p3526, align 8, !alias.scope !3, !noalias !4
  %v3527 = load i64, ptr %slot24, align 8
  %p3528 = inttoptr i64 %v3527 to ptr
  %ld3529 = load i64, ptr %p3528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3529, ptr %slot618, align 8
  %v3530 = load i64, ptr %slot618, align 8
  %v3531 = load i64, ptr %slot22, align 8
  %p3532 = inttoptr i64 %v3531 to ptr
  store i64 %v3530, ptr %p3532, align 8, !alias.scope !3, !noalias !4
  %v3533 = load i64, ptr %slot9, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  %ld3535 = load i64, ptr %p3534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3535, ptr %slot619, align 8
  %v3536 = load i64, ptr %slot619, align 8
  %v3537 = load i64, ptr %slot24, align 8
  %p3538 = inttoptr i64 %v3537 to ptr
  store i64 %v3536, ptr %p3538, align 8, !alias.scope !3, !noalias !4
  %v3539 = load i64, ptr %slot24, align 8
  %p3540 = inttoptr i64 %v3539 to ptr
  %ld3541 = load i64, ptr %p3540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3541, ptr %slot620, align 8
  %v3542 = load i64, ptr %slot620, align 8
  %v3543 = load i64, ptr %slot23, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  store i64 %v3542, ptr %p3544, align 8, !alias.scope !3, !noalias !4
  %v3545 = load i64, ptr %slot22, align 8
  %p3546 = inttoptr i64 %v3545 to ptr
  %ld3547 = load i64, ptr %p3546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3547, ptr %slot621, align 8
  %v3548 = load i64, ptr %slot621, align 8
  %v3549 = load i64, ptr %slot24, align 8
  %p3550 = inttoptr i64 %v3549 to ptr
  store i64 %v3548, ptr %p3550, align 8, !alias.scope !3, !noalias !4
  %v3551 = load i64, ptr %slot23, align 8
  %p3552 = inttoptr i64 %v3551 to ptr
  %ld3553 = load i64, ptr %p3552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3553, ptr %slot622, align 8
  %v3554 = load i64, ptr %slot622, align 8
  %v3555 = load i64, ptr %slot25, align 8
  %p3556 = inttoptr i64 %v3555 to ptr
  store i64 %v3554, ptr %p3556, align 8, !alias.scope !3, !noalias !4
  %v3557 = load i64, ptr %slot25, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  %ld3559 = load i64, ptr %p3558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3559, ptr %slot623, align 8
  %v3560 = load i64, ptr %slot24, align 8
  %p3561 = inttoptr i64 %v3560 to ptr
  %ld3562 = load i64, ptr %p3561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3562, ptr %slot624, align 8
  %v3563 = load i64, ptr %slot624, align 8
  %cast3564 = bitcast i64 %v3563 to double
  store double %cast3564, ptr %slot625, align 8
  %v3565 = load i64, ptr %slot623, align 8
  %cast3566 = bitcast i64 %v3565 to double
  store double %cast3566, ptr %slot626, align 8
  %v3567 = load double, ptr %slot625, align 8
  %v3568 = load double, ptr %slot626, align 8
  %op3569 = fmul double %v3567, %v3568
  store double %op3569, ptr %slot627, align 8
  %v3570 = load double, ptr %slot627, align 8
  %cast3571 = bitcast double %v3570 to i64
  store i64 %cast3571, ptr %slot628, align 8
  %v3572 = load i64, ptr %slot628, align 8
  %v3573 = load i64, ptr %slot24, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  store i64 %v3572, ptr %p3574, align 8, !alias.scope !3, !noalias !4
  %v3575 = load i64, ptr %slot58, align 8
  store i64 %v3575, ptr %slot629, align 8
  %v3576 = load i64, ptr %slot629, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  store i32 2, ptr %p3577, align 4, !alias.scope !3, !noalias !4
  %v3578 = load i64, ptr %slot629, align 8
  %p3580 = inttoptr i64 %v3578 to ptr
  %gep3581 = getelementptr i8, ptr %p3580, i64 8
  %op3579 = ptrtoint ptr %gep3581 to i64
  store i64 %op3579, ptr %slot630, align 8
  %v3582 = load i64, ptr %slot24, align 8
  %p3583 = inttoptr i64 %v3582 to ptr
  %ld3584 = load i64, ptr %p3583, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3584, ptr %slot631, align 8
  %v3585 = load i64, ptr %slot631, align 8
  %v3586 = load i64, ptr %slot630, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  store i64 %v3585, ptr %p3587, align 8, !alias.scope !3, !noalias !4
  %v3588 = load i64, ptr %slot629, align 8
  %v3589 = load i64, ptr %slot24, align 8
  %p3590 = inttoptr i64 %v3589 to ptr
  store i64 %v3588, ptr %p3590, align 8, !alias.scope !3, !noalias !4
  %v3591 = load i64, ptr %slot24, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  %ld3593 = load i64, ptr %p3592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3593, ptr %slot632, align 8
  %v3594 = load i64, ptr %slot632, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  %ret3596 = load { i64, i64 }, ptr %p3595, align 8
  ret { i64, i64 } %ret3596
bb_i394:
  %v3597 = load i64, ptr %slot8, align 8
  %p3598 = inttoptr i64 %v3597 to ptr
  %ld3599 = load i64, ptr %p3598, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3599, ptr %slot633, align 8
  %v3600 = load i64, ptr %slot633, align 8
  %v3601 = load i64, ptr %slot24, align 8
  %p3602 = inttoptr i64 %v3601 to ptr
  store i64 %v3600, ptr %p3602, align 8, !alias.scope !3, !noalias !4
  %v3603 = load i64, ptr %slot24, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  %ld3605 = load i64, ptr %p3604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3605, ptr %slot634, align 8
  %v3606 = load i64, ptr %slot634, align 8
  %v3607 = load i64, ptr %slot22, align 8
  %p3608 = inttoptr i64 %v3607 to ptr
  store i64 %v3606, ptr %p3608, align 8, !alias.scope !3, !noalias !4
  %v3609 = load i64, ptr %slot9, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  %ld3611 = load i64, ptr %p3610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3611, ptr %slot635, align 8
  %v3612 = load i64, ptr %slot635, align 8
  %v3613 = load i64, ptr %slot24, align 8
  %p3614 = inttoptr i64 %v3613 to ptr
  store i64 %v3612, ptr %p3614, align 8, !alias.scope !3, !noalias !4
  %v3615 = load i64, ptr %slot24, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  %ld3617 = load i64, ptr %p3616, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3617, ptr %slot636, align 8
  %v3618 = load i64, ptr %slot636, align 8
  %v3619 = load i64, ptr %slot23, align 8
  %p3620 = inttoptr i64 %v3619 to ptr
  store i64 %v3618, ptr %p3620, align 8, !alias.scope !3, !noalias !4
  %v3621 = load i64, ptr %slot22, align 8
  %p3622 = inttoptr i64 %v3621 to ptr
  %ld3623 = load i64, ptr %p3622, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3623, ptr %slot637, align 8
  %v3624 = load i64, ptr %slot637, align 8
  %v3625 = load i64, ptr %slot24, align 8
  %p3626 = inttoptr i64 %v3625 to ptr
  store i64 %v3624, ptr %p3626, align 8, !alias.scope !3, !noalias !4
  %v3627 = load i64, ptr %slot23, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  %ld3629 = load i64, ptr %p3628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3629, ptr %slot638, align 8
  %v3630 = load i64, ptr %slot638, align 8
  %v3631 = load i64, ptr %slot25, align 8
  %p3632 = inttoptr i64 %v3631 to ptr
  store i64 %v3630, ptr %p3632, align 8, !alias.scope !3, !noalias !4
  %v3633 = load i64, ptr %slot25, align 8
  %p3634 = inttoptr i64 %v3633 to ptr
  %ld3635 = load i64, ptr %p3634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3635, ptr %slot639, align 8
  %v3636 = load i64, ptr %slot24, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  %ld3638 = load i64, ptr %p3637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3638, ptr %slot640, align 8
  %v3639 = load i64, ptr %slot640, align 8
  %cast3640 = bitcast i64 %v3639 to double
  store double %cast3640, ptr %slot641, align 8
  %v3641 = load i64, ptr %slot639, align 8
  %cast3642 = bitcast i64 %v3641 to double
  store double %cast3642, ptr %slot642, align 8
  %v3643 = load double, ptr %slot641, align 8
  %v3644 = load double, ptr %slot642, align 8
  %op3645 = fmul double %v3643, %v3644
  store double %op3645, ptr %slot643, align 8
  %v3646 = load double, ptr %slot643, align 8
  %cast3647 = bitcast double %v3646 to i64
  store i64 %cast3647, ptr %slot644, align 8
  %v3648 = load i64, ptr %slot644, align 8
  %v3649 = load i64, ptr %slot24, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  store i64 %v3648, ptr %p3650, align 8, !alias.scope !3, !noalias !4
  %v3651 = load i64, ptr %slot59, align 8
  store i64 %v3651, ptr %slot645, align 8
  %v3652 = load i64, ptr %slot645, align 8
  %p3653 = inttoptr i64 %v3652 to ptr
  store i32 2, ptr %p3653, align 4, !alias.scope !3, !noalias !4
  %v3654 = load i64, ptr %slot645, align 8
  %p3656 = inttoptr i64 %v3654 to ptr
  %gep3657 = getelementptr i8, ptr %p3656, i64 8
  %op3655 = ptrtoint ptr %gep3657 to i64
  store i64 %op3655, ptr %slot646, align 8
  %v3658 = load i64, ptr %slot24, align 8
  %p3659 = inttoptr i64 %v3658 to ptr
  %ld3660 = load i64, ptr %p3659, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3660, ptr %slot647, align 8
  %v3661 = load i64, ptr %slot647, align 8
  %v3662 = load i64, ptr %slot646, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  store i64 %v3661, ptr %p3663, align 8, !alias.scope !3, !noalias !4
  %v3664 = load i64, ptr %slot645, align 8
  %v3665 = load i64, ptr %slot24, align 8
  %p3666 = inttoptr i64 %v3665 to ptr
  store i64 %v3664, ptr %p3666, align 8, !alias.scope !3, !noalias !4
  %v3667 = load i64, ptr %slot24, align 8
  %p3668 = inttoptr i64 %v3667 to ptr
  %ld3669 = load i64, ptr %p3668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3669, ptr %slot648, align 8
  %v3670 = load i64, ptr %slot648, align 8
  %p3671 = inttoptr i64 %v3670 to ptr
  %ret3672 = load { i64, i64 }, ptr %p3671, align 8
  ret { i64, i64 } %ret3672
bb_i406:
  %v3673 = load i64, ptr %slot8, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %ld3675 = load i64, ptr %p3674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3675, ptr %slot649, align 8
  %v3676 = load i64, ptr %slot649, align 8
  %v3677 = load i64, ptr %slot24, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  store i64 %v3676, ptr %p3678, align 8, !alias.scope !3, !noalias !4
  %v3679 = load i64, ptr %slot24, align 8
  %p3680 = inttoptr i64 %v3679 to ptr
  %ld3681 = load i64, ptr %p3680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3681, ptr %slot650, align 8
  %v3682 = load i64, ptr %slot650, align 8
  %v3683 = load i64, ptr %slot22, align 8
  %p3684 = inttoptr i64 %v3683 to ptr
  store i64 %v3682, ptr %p3684, align 8, !alias.scope !3, !noalias !4
  %v3685 = load i64, ptr %slot9, align 8
  %p3686 = inttoptr i64 %v3685 to ptr
  %ld3687 = load i64, ptr %p3686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3687, ptr %slot651, align 8
  %v3688 = load i64, ptr %slot651, align 8
  %v3689 = load i64, ptr %slot24, align 8
  %p3690 = inttoptr i64 %v3689 to ptr
  store i64 %v3688, ptr %p3690, align 8, !alias.scope !3, !noalias !4
  %v3691 = load i64, ptr %slot24, align 8
  %p3692 = inttoptr i64 %v3691 to ptr
  %ld3693 = load i64, ptr %p3692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3693, ptr %slot652, align 8
  %v3694 = load i64, ptr %slot652, align 8
  %v3695 = load i64, ptr %slot23, align 8
  %p3696 = inttoptr i64 %v3695 to ptr
  store i64 %v3694, ptr %p3696, align 8, !alias.scope !3, !noalias !4
  %v3697 = load i64, ptr %slot22, align 8
  %p3698 = inttoptr i64 %v3697 to ptr
  %ld3699 = load i64, ptr %p3698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3699, ptr %slot653, align 8
  %v3700 = load i64, ptr %slot653, align 8
  %v3701 = load i64, ptr %slot24, align 8
  %p3702 = inttoptr i64 %v3701 to ptr
  store i64 %v3700, ptr %p3702, align 8, !alias.scope !3, !noalias !4
  %v3703 = load i64, ptr %slot23, align 8
  %p3704 = inttoptr i64 %v3703 to ptr
  %ld3705 = load i64, ptr %p3704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3705, ptr %slot654, align 8
  %v3706 = load i64, ptr %slot654, align 8
  %v3707 = load i64, ptr %slot25, align 8
  %p3708 = inttoptr i64 %v3707 to ptr
  store i64 %v3706, ptr %p3708, align 8, !alias.scope !3, !noalias !4
  %v3709 = load i64, ptr %slot25, align 8
  %p3710 = inttoptr i64 %v3709 to ptr
  %ld3711 = load i64, ptr %p3710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3711, ptr %slot655, align 8
  %v3712 = load i64, ptr %slot24, align 8
  %p3713 = inttoptr i64 %v3712 to ptr
  %ld3714 = load i64, ptr %p3713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3714, ptr %slot656, align 8
  %v3715 = load i64, ptr %slot656, align 8
  %cast3716 = bitcast i64 %v3715 to double
  store double %cast3716, ptr %slot657, align 8
  %v3717 = load i64, ptr %slot655, align 8
  %cast3718 = bitcast i64 %v3717 to double
  store double %cast3718, ptr %slot658, align 8
  %v3719 = load double, ptr %slot657, align 8
  %v3720 = load double, ptr %slot658, align 8
  %op3721 = fmul double %v3719, %v3720
  store double %op3721, ptr %slot659, align 8
  %v3722 = load double, ptr %slot659, align 8
  %cast3723 = bitcast double %v3722 to i64
  store i64 %cast3723, ptr %slot660, align 8
  %v3724 = load i64, ptr %slot660, align 8
  %v3725 = load i64, ptr %slot24, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  store i64 %v3724, ptr %p3726, align 8, !alias.scope !3, !noalias !4
  %v3727 = load i64, ptr %slot60, align 8
  store i64 %v3727, ptr %slot661, align 8
  %v3728 = load i64, ptr %slot661, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  store i32 2, ptr %p3729, align 4, !alias.scope !3, !noalias !4
  %v3730 = load i64, ptr %slot661, align 8
  %p3732 = inttoptr i64 %v3730 to ptr
  %gep3733 = getelementptr i8, ptr %p3732, i64 8
  %op3731 = ptrtoint ptr %gep3733 to i64
  store i64 %op3731, ptr %slot662, align 8
  %v3734 = load i64, ptr %slot24, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  %ld3736 = load i64, ptr %p3735, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3736, ptr %slot663, align 8
  %v3737 = load i64, ptr %slot663, align 8
  %v3738 = load i64, ptr %slot662, align 8
  %p3739 = inttoptr i64 %v3738 to ptr
  store i64 %v3737, ptr %p3739, align 8, !alias.scope !3, !noalias !4
  %v3740 = load i64, ptr %slot661, align 8
  %v3741 = load i64, ptr %slot24, align 8
  %p3742 = inttoptr i64 %v3741 to ptr
  store i64 %v3740, ptr %p3742, align 8, !alias.scope !3, !noalias !4
  %v3743 = load i64, ptr %slot24, align 8
  %p3744 = inttoptr i64 %v3743 to ptr
  %ld3745 = load i64, ptr %p3744, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3745, ptr %slot664, align 8
  %v3746 = load i64, ptr %slot664, align 8
  %p3747 = inttoptr i64 %v3746 to ptr
  %ret3748 = load { i64, i64 }, ptr %p3747, align 8
  ret { i64, i64 } %ret3748
bb_i418:
  %v3749 = load i64, ptr %slot8, align 8
  %p3750 = inttoptr i64 %v3749 to ptr
  %ld3751 = load i64, ptr %p3750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3751, ptr %slot665, align 8
  %v3752 = load i64, ptr %slot665, align 8
  %v3753 = load i64, ptr %slot24, align 8
  %p3754 = inttoptr i64 %v3753 to ptr
  store i64 %v3752, ptr %p3754, align 8, !alias.scope !3, !noalias !4
  %v3755 = load i64, ptr %slot24, align 8
  %p3756 = inttoptr i64 %v3755 to ptr
  %ld3757 = load i64, ptr %p3756, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3757, ptr %slot666, align 8
  %v3758 = load i64, ptr %slot666, align 8
  %v3759 = load i64, ptr %slot22, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  store i64 %v3758, ptr %p3760, align 8, !alias.scope !3, !noalias !4
  %v3761 = load i64, ptr %slot9, align 8
  %p3762 = inttoptr i64 %v3761 to ptr
  %ld3763 = load i64, ptr %p3762, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3763, ptr %slot667, align 8
  %v3764 = load i64, ptr %slot667, align 8
  %v3765 = load i64, ptr %slot24, align 8
  %p3766 = inttoptr i64 %v3765 to ptr
  store i64 %v3764, ptr %p3766, align 8, !alias.scope !3, !noalias !4
  %v3767 = load i64, ptr %slot24, align 8
  %p3768 = inttoptr i64 %v3767 to ptr
  %ld3769 = load i64, ptr %p3768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3769, ptr %slot668, align 8
  %v3770 = load i64, ptr %slot668, align 8
  %v3771 = load i64, ptr %slot23, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  store i64 %v3770, ptr %p3772, align 8, !alias.scope !3, !noalias !4
  %v3773 = load i64, ptr %slot22, align 8
  %p3774 = inttoptr i64 %v3773 to ptr
  %ld3775 = load i64, ptr %p3774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3775, ptr %slot669, align 8
  %v3776 = load i64, ptr %slot669, align 8
  %v3777 = load i64, ptr %slot24, align 8
  %p3778 = inttoptr i64 %v3777 to ptr
  store i64 %v3776, ptr %p3778, align 8, !alias.scope !3, !noalias !4
  %v3779 = load i64, ptr %slot23, align 8
  %p3780 = inttoptr i64 %v3779 to ptr
  %ld3781 = load i64, ptr %p3780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3781, ptr %slot670, align 8
  %v3782 = load i64, ptr %slot670, align 8
  %v3783 = load i64, ptr %slot25, align 8
  %p3784 = inttoptr i64 %v3783 to ptr
  store i64 %v3782, ptr %p3784, align 8, !alias.scope !3, !noalias !4
  %v3785 = load i64, ptr %slot25, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i64, ptr %p3786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3787, ptr %slot671, align 8
  %v3788 = load i64, ptr %slot24, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  %ld3790 = load i64, ptr %p3789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3790, ptr %slot672, align 8
  %v3791 = load i64, ptr %slot672, align 8
  %cast3792 = bitcast i64 %v3791 to double
  store double %cast3792, ptr %slot673, align 8
  %v3793 = load i64, ptr %slot671, align 8
  %cast3794 = bitcast i64 %v3793 to double
  store double %cast3794, ptr %slot674, align 8
  %v3795 = load double, ptr %slot673, align 8
  %v3796 = load double, ptr %slot674, align 8
  %op3797 = fmul double %v3795, %v3796
  store double %op3797, ptr %slot675, align 8
  %v3798 = load double, ptr %slot675, align 8
  %cast3799 = bitcast double %v3798 to i64
  store i64 %cast3799, ptr %slot676, align 8
  %v3800 = load i64, ptr %slot676, align 8
  %v3801 = load i64, ptr %slot24, align 8
  %p3802 = inttoptr i64 %v3801 to ptr
  store i64 %v3800, ptr %p3802, align 8, !alias.scope !3, !noalias !4
  %v3803 = load i64, ptr %slot61, align 8
  store i64 %v3803, ptr %slot677, align 8
  %v3804 = load i64, ptr %slot677, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  store i32 2, ptr %p3805, align 4, !alias.scope !3, !noalias !4
  %v3806 = load i64, ptr %slot677, align 8
  %p3808 = inttoptr i64 %v3806 to ptr
  %gep3809 = getelementptr i8, ptr %p3808, i64 8
  %op3807 = ptrtoint ptr %gep3809 to i64
  store i64 %op3807, ptr %slot678, align 8
  %v3810 = load i64, ptr %slot24, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  %ld3812 = load i64, ptr %p3811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3812, ptr %slot679, align 8
  %v3813 = load i64, ptr %slot679, align 8
  %v3814 = load i64, ptr %slot678, align 8
  %p3815 = inttoptr i64 %v3814 to ptr
  store i64 %v3813, ptr %p3815, align 8, !alias.scope !3, !noalias !4
  %v3816 = load i64, ptr %slot677, align 8
  %v3817 = load i64, ptr %slot24, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  store i64 %v3816, ptr %p3818, align 8, !alias.scope !3, !noalias !4
  %v3819 = load i64, ptr %slot24, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %ld3821 = load i64, ptr %p3820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3821, ptr %slot680, align 8
  %v3822 = load i64, ptr %slot680, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %ret3824 = load { i64, i64 }, ptr %p3823, align 8
  ret { i64, i64 } %ret3824
bb_i430:
  %v3825 = load i64, ptr %slot8, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  %ld3827 = load i64, ptr %p3826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3827, ptr %slot681, align 8
  %v3828 = load i64, ptr %slot681, align 8
  %v3829 = load i64, ptr %slot24, align 8
  %p3830 = inttoptr i64 %v3829 to ptr
  store i64 %v3828, ptr %p3830, align 8, !alias.scope !3, !noalias !4
  %v3831 = load i64, ptr %slot24, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %ld3833 = load i64, ptr %p3832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3833, ptr %slot682, align 8
  %v3834 = load i64, ptr %slot682, align 8
  %v3835 = load i64, ptr %slot22, align 8
  %p3836 = inttoptr i64 %v3835 to ptr
  store i64 %v3834, ptr %p3836, align 8, !alias.scope !3, !noalias !4
  %v3837 = load i64, ptr %slot9, align 8
  %p3838 = inttoptr i64 %v3837 to ptr
  %ld3839 = load i64, ptr %p3838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3839, ptr %slot683, align 8
  %v3840 = load i64, ptr %slot683, align 8
  %v3841 = load i64, ptr %slot24, align 8
  %p3842 = inttoptr i64 %v3841 to ptr
  store i64 %v3840, ptr %p3842, align 8, !alias.scope !3, !noalias !4
  %v3843 = load i64, ptr %slot24, align 8
  %p3844 = inttoptr i64 %v3843 to ptr
  %ld3845 = load i64, ptr %p3844, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3845, ptr %slot684, align 8
  %v3846 = load i64, ptr %slot684, align 8
  %v3847 = load i64, ptr %slot23, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  store i64 %v3846, ptr %p3848, align 8, !alias.scope !3, !noalias !4
  %v3849 = load i64, ptr %slot22, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  %ld3851 = load i64, ptr %p3850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3851, ptr %slot685, align 8
  %v3852 = load i64, ptr %slot685, align 8
  %v3853 = load i64, ptr %slot24, align 8
  %p3854 = inttoptr i64 %v3853 to ptr
  store i64 %v3852, ptr %p3854, align 8, !alias.scope !3, !noalias !4
  %v3855 = load i64, ptr %slot23, align 8
  %p3856 = inttoptr i64 %v3855 to ptr
  %ld3857 = load i64, ptr %p3856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3857, ptr %slot686, align 8
  %v3858 = load i64, ptr %slot686, align 8
  %v3859 = load i64, ptr %slot25, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  store i64 %v3858, ptr %p3860, align 8, !alias.scope !3, !noalias !4
  %v3861 = load i64, ptr %slot25, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  %ld3863 = load i64, ptr %p3862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3863, ptr %slot687, align 8
  %v3864 = load i64, ptr %slot24, align 8
  %p3865 = inttoptr i64 %v3864 to ptr
  %ld3866 = load i64, ptr %p3865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3866, ptr %slot688, align 8
  %v3867 = load i64, ptr %slot688, align 8
  %cast3868 = bitcast i64 %v3867 to double
  store double %cast3868, ptr %slot689, align 8
  %v3869 = load i64, ptr %slot687, align 8
  %cast3870 = bitcast i64 %v3869 to double
  store double %cast3870, ptr %slot690, align 8
  %v3871 = load double, ptr %slot689, align 8
  %v3872 = load double, ptr %slot690, align 8
  %op3873 = fmul double %v3871, %v3872
  store double %op3873, ptr %slot691, align 8
  %v3874 = load double, ptr %slot691, align 8
  %cast3875 = bitcast double %v3874 to i64
  store i64 %cast3875, ptr %slot692, align 8
  %v3876 = load i64, ptr %slot692, align 8
  %v3877 = load i64, ptr %slot24, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  store i64 %v3876, ptr %p3878, align 8, !alias.scope !3, !noalias !4
  %v3879 = load i64, ptr %slot62, align 8
  store i64 %v3879, ptr %slot693, align 8
  %v3880 = load i64, ptr %slot693, align 8
  %p3881 = inttoptr i64 %v3880 to ptr
  store i32 2, ptr %p3881, align 4, !alias.scope !3, !noalias !4
  %v3882 = load i64, ptr %slot693, align 8
  %p3884 = inttoptr i64 %v3882 to ptr
  %gep3885 = getelementptr i8, ptr %p3884, i64 8
  %op3883 = ptrtoint ptr %gep3885 to i64
  store i64 %op3883, ptr %slot694, align 8
  %v3886 = load i64, ptr %slot24, align 8
  %p3887 = inttoptr i64 %v3886 to ptr
  %ld3888 = load i64, ptr %p3887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3888, ptr %slot695, align 8
  %v3889 = load i64, ptr %slot695, align 8
  %v3890 = load i64, ptr %slot694, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  store i64 %v3889, ptr %p3891, align 8, !alias.scope !3, !noalias !4
  %v3892 = load i64, ptr %slot693, align 8
  %v3893 = load i64, ptr %slot24, align 8
  %p3894 = inttoptr i64 %v3893 to ptr
  store i64 %v3892, ptr %p3894, align 8, !alias.scope !3, !noalias !4
  %v3895 = load i64, ptr %slot24, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  %ld3897 = load i64, ptr %p3896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3897, ptr %slot696, align 8
  %v3898 = load i64, ptr %slot696, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  %ret3900 = load { i64, i64 }, ptr %p3899, align 8
  ret { i64, i64 } %ret3900
bb_i442:
  %v3901 = load i64, ptr %slot8, align 8
  %p3902 = inttoptr i64 %v3901 to ptr
  %ld3903 = load i64, ptr %p3902, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3903, ptr %slot697, align 8
  %v3904 = load i64, ptr %slot697, align 8
  %v3905 = load i64, ptr %slot24, align 8
  %p3906 = inttoptr i64 %v3905 to ptr
  store i64 %v3904, ptr %p3906, align 8, !alias.scope !3, !noalias !4
  %v3907 = load i64, ptr %slot24, align 8
  %p3908 = inttoptr i64 %v3907 to ptr
  %ld3909 = load i64, ptr %p3908, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3909, ptr %slot698, align 8
  %v3910 = load i64, ptr %slot698, align 8
  %v3911 = load i64, ptr %slot22, align 8
  %p3912 = inttoptr i64 %v3911 to ptr
  store i64 %v3910, ptr %p3912, align 8, !alias.scope !3, !noalias !4
  %v3913 = load i64, ptr %slot9, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  %ld3915 = load i64, ptr %p3914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3915, ptr %slot699, align 8
  %v3916 = load i64, ptr %slot699, align 8
  %v3917 = load i64, ptr %slot24, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  store i64 %v3916, ptr %p3918, align 8, !alias.scope !3, !noalias !4
  %v3919 = load i64, ptr %slot24, align 8
  %p3920 = inttoptr i64 %v3919 to ptr
  %ld3921 = load i64, ptr %p3920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3921, ptr %slot700, align 8
  %v3922 = load i64, ptr %slot700, align 8
  %v3923 = load i64, ptr %slot23, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  store i64 %v3922, ptr %p3924, align 8, !alias.scope !3, !noalias !4
  %v3925 = load i64, ptr %slot22, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  %ld3927 = load i64, ptr %p3926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3927, ptr %slot701, align 8
  %v3928 = load i64, ptr %slot701, align 8
  %v3929 = load i64, ptr %slot24, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  store i64 %v3928, ptr %p3930, align 8, !alias.scope !3, !noalias !4
  %v3931 = load i64, ptr %slot23, align 8
  %p3932 = inttoptr i64 %v3931 to ptr
  %ld3933 = load i64, ptr %p3932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3933, ptr %slot702, align 8
  %v3934 = load i64, ptr %slot702, align 8
  %v3935 = load i64, ptr %slot25, align 8
  %p3936 = inttoptr i64 %v3935 to ptr
  store i64 %v3934, ptr %p3936, align 8, !alias.scope !3, !noalias !4
  %v3937 = load i64, ptr %slot25, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  %ld3939 = load i64, ptr %p3938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3939, ptr %slot703, align 8
  %v3940 = load i64, ptr %slot24, align 8
  %p3941 = inttoptr i64 %v3940 to ptr
  %ld3942 = load i64, ptr %p3941, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3942, ptr %slot704, align 8
  %v3943 = load i64, ptr %slot704, align 8
  %cast3944 = bitcast i64 %v3943 to double
  store double %cast3944, ptr %slot705, align 8
  %v3945 = load i64, ptr %slot703, align 8
  %cast3946 = bitcast i64 %v3945 to double
  store double %cast3946, ptr %slot706, align 8
  %v3947 = load double, ptr %slot705, align 8
  %v3948 = load double, ptr %slot706, align 8
  %op3949 = fmul double %v3947, %v3948
  store double %op3949, ptr %slot707, align 8
  %v3950 = load double, ptr %slot707, align 8
  %cast3951 = bitcast double %v3950 to i64
  store i64 %cast3951, ptr %slot708, align 8
  %v3952 = load i64, ptr %slot708, align 8
  %v3953 = load i64, ptr %slot24, align 8
  %p3954 = inttoptr i64 %v3953 to ptr
  store i64 %v3952, ptr %p3954, align 8, !alias.scope !3, !noalias !4
  %v3955 = load i64, ptr %slot63, align 8
  store i64 %v3955, ptr %slot709, align 8
  %v3956 = load i64, ptr %slot709, align 8
  %p3957 = inttoptr i64 %v3956 to ptr
  store i32 2, ptr %p3957, align 4, !alias.scope !3, !noalias !4
  %v3958 = load i64, ptr %slot709, align 8
  %p3960 = inttoptr i64 %v3958 to ptr
  %gep3961 = getelementptr i8, ptr %p3960, i64 8
  %op3959 = ptrtoint ptr %gep3961 to i64
  store i64 %op3959, ptr %slot710, align 8
  %v3962 = load i64, ptr %slot24, align 8
  %p3963 = inttoptr i64 %v3962 to ptr
  %ld3964 = load i64, ptr %p3963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3964, ptr %slot711, align 8
  %v3965 = load i64, ptr %slot711, align 8
  %v3966 = load i64, ptr %slot710, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  store i64 %v3965, ptr %p3967, align 8, !alias.scope !3, !noalias !4
  %v3968 = load i64, ptr %slot709, align 8
  %v3969 = load i64, ptr %slot24, align 8
  %p3970 = inttoptr i64 %v3969 to ptr
  store i64 %v3968, ptr %p3970, align 8, !alias.scope !3, !noalias !4
  %v3971 = load i64, ptr %slot24, align 8
  %p3972 = inttoptr i64 %v3971 to ptr
  %ld3973 = load i64, ptr %p3972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3973, ptr %slot712, align 8
  %v3974 = load i64, ptr %slot712, align 8
  %p3975 = inttoptr i64 %v3974 to ptr
  %ret3976 = load { i64, i64 }, ptr %p3975, align 8
  ret { i64, i64 } %ret3976
bb_i454:
  %v3977 = load i64, ptr %slot8, align 8
  %p3978 = inttoptr i64 %v3977 to ptr
  %ld3979 = load i64, ptr %p3978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3979, ptr %slot713, align 8
  %v3980 = load i64, ptr %slot713, align 8
  %v3981 = load i64, ptr %slot24, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  store i64 %v3980, ptr %p3982, align 8, !alias.scope !3, !noalias !4
  %v3983 = load i64, ptr %slot24, align 8
  %p3984 = inttoptr i64 %v3983 to ptr
  %ld3985 = load i64, ptr %p3984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3985, ptr %slot714, align 8
  %v3986 = load i64, ptr %slot714, align 8
  %v3987 = load i64, ptr %slot22, align 8
  %p3988 = inttoptr i64 %v3987 to ptr
  store i64 %v3986, ptr %p3988, align 8, !alias.scope !3, !noalias !4
  %v3989 = load i64, ptr %slot9, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  %ld3991 = load i64, ptr %p3990, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3991, ptr %slot715, align 8
  %v3992 = load i64, ptr %slot715, align 8
  %v3993 = load i64, ptr %slot24, align 8
  %p3994 = inttoptr i64 %v3993 to ptr
  store i64 %v3992, ptr %p3994, align 8, !alias.scope !3, !noalias !4
  %v3995 = load i64, ptr %slot24, align 8
  %p3996 = inttoptr i64 %v3995 to ptr
  %ld3997 = load i64, ptr %p3996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3997, ptr %slot716, align 8
  %v3998 = load i64, ptr %slot716, align 8
  %v3999 = load i64, ptr %slot23, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  store i64 %v3998, ptr %p4000, align 8, !alias.scope !3, !noalias !4
  %v4001 = load i64, ptr %slot22, align 8
  %p4002 = inttoptr i64 %v4001 to ptr
  %ld4003 = load i64, ptr %p4002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4003, ptr %slot717, align 8
  %v4004 = load i64, ptr %slot717, align 8
  %v4005 = load i64, ptr %slot24, align 8
  %p4006 = inttoptr i64 %v4005 to ptr
  store i64 %v4004, ptr %p4006, align 8, !alias.scope !3, !noalias !4
  %v4007 = load i64, ptr %slot23, align 8
  %p4008 = inttoptr i64 %v4007 to ptr
  %ld4009 = load i64, ptr %p4008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4009, ptr %slot718, align 8
  %v4010 = load i64, ptr %slot718, align 8
  %v4011 = load i64, ptr %slot25, align 8
  %p4012 = inttoptr i64 %v4011 to ptr
  store i64 %v4010, ptr %p4012, align 8, !alias.scope !3, !noalias !4
  %v4013 = load i64, ptr %slot25, align 8
  %p4014 = inttoptr i64 %v4013 to ptr
  %ld4015 = load i64, ptr %p4014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4015, ptr %slot719, align 8
  %v4016 = load i64, ptr %slot24, align 8
  %p4017 = inttoptr i64 %v4016 to ptr
  %ld4018 = load i64, ptr %p4017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4018, ptr %slot720, align 8
  %v4019 = load i64, ptr %slot720, align 8
  %cast4020 = bitcast i64 %v4019 to double
  store double %cast4020, ptr %slot721, align 8
  %v4021 = load i64, ptr %slot719, align 8
  %cast4022 = bitcast i64 %v4021 to double
  store double %cast4022, ptr %slot722, align 8
  %v4023 = load double, ptr %slot721, align 8
  %v4024 = load double, ptr %slot722, align 8
  %op4025 = fmul double %v4023, %v4024
  store double %op4025, ptr %slot723, align 8
  %v4026 = load double, ptr %slot723, align 8
  %cast4027 = bitcast double %v4026 to i64
  store i64 %cast4027, ptr %slot724, align 8
  %v4028 = load i64, ptr %slot724, align 8
  %v4029 = load i64, ptr %slot24, align 8
  %p4030 = inttoptr i64 %v4029 to ptr
  store i64 %v4028, ptr %p4030, align 8, !alias.scope !3, !noalias !4
  %v4031 = load i64, ptr %slot64, align 8
  store i64 %v4031, ptr %slot725, align 8
  %v4032 = load i64, ptr %slot725, align 8
  %p4033 = inttoptr i64 %v4032 to ptr
  store i32 2, ptr %p4033, align 4, !alias.scope !3, !noalias !4
  %v4034 = load i64, ptr %slot725, align 8
  %p4036 = inttoptr i64 %v4034 to ptr
  %gep4037 = getelementptr i8, ptr %p4036, i64 8
  %op4035 = ptrtoint ptr %gep4037 to i64
  store i64 %op4035, ptr %slot726, align 8
  %v4038 = load i64, ptr %slot24, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  %ld4040 = load i64, ptr %p4039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4040, ptr %slot727, align 8
  %v4041 = load i64, ptr %slot727, align 8
  %v4042 = load i64, ptr %slot726, align 8
  %p4043 = inttoptr i64 %v4042 to ptr
  store i64 %v4041, ptr %p4043, align 8, !alias.scope !3, !noalias !4
  %v4044 = load i64, ptr %slot725, align 8
  %v4045 = load i64, ptr %slot24, align 8
  %p4046 = inttoptr i64 %v4045 to ptr
  store i64 %v4044, ptr %p4046, align 8, !alias.scope !3, !noalias !4
  %v4047 = load i64, ptr %slot24, align 8
  %p4048 = inttoptr i64 %v4047 to ptr
  %ld4049 = load i64, ptr %p4048, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4049, ptr %slot728, align 8
  %v4050 = load i64, ptr %slot728, align 8
  %p4051 = inttoptr i64 %v4050 to ptr
  %ret4052 = load { i64, i64 }, ptr %p4051, align 8
  ret { i64, i64 } %ret4052
bb_i466:
  %v4053 = load i64, ptr %slot8, align 8
  %p4054 = inttoptr i64 %v4053 to ptr
  %ld4055 = load i64, ptr %p4054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4055, ptr %slot729, align 8
  %v4056 = load i64, ptr %slot729, align 8
  %v4057 = load i64, ptr %slot24, align 8
  %p4058 = inttoptr i64 %v4057 to ptr
  store i64 %v4056, ptr %p4058, align 8, !alias.scope !3, !noalias !4
  %v4059 = load i64, ptr %slot24, align 8
  %p4060 = inttoptr i64 %v4059 to ptr
  %ld4061 = load i64, ptr %p4060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4061, ptr %slot730, align 8
  %v4062 = load i64, ptr %slot730, align 8
  %v4063 = load i64, ptr %slot22, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  store i64 %v4062, ptr %p4064, align 8, !alias.scope !3, !noalias !4
  %v4065 = load i64, ptr %slot9, align 8
  %p4066 = inttoptr i64 %v4065 to ptr
  %ld4067 = load i64, ptr %p4066, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4067, ptr %slot731, align 8
  %v4068 = load i64, ptr %slot731, align 8
  %v4069 = load i64, ptr %slot24, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  store i64 %v4068, ptr %p4070, align 8, !alias.scope !3, !noalias !4
  %v4071 = load i64, ptr %slot24, align 8
  %p4072 = inttoptr i64 %v4071 to ptr
  %ld4073 = load i64, ptr %p4072, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4073, ptr %slot732, align 8
  %v4074 = load i64, ptr %slot732, align 8
  %v4075 = load i64, ptr %slot23, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  store i64 %v4074, ptr %p4076, align 8, !alias.scope !3, !noalias !4
  %v4077 = load i64, ptr %slot22, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  %ld4079 = load i64, ptr %p4078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4079, ptr %slot733, align 8
  %v4080 = load i64, ptr %slot733, align 8
  %v4081 = load i64, ptr %slot24, align 8
  %p4082 = inttoptr i64 %v4081 to ptr
  store i64 %v4080, ptr %p4082, align 8, !alias.scope !3, !noalias !4
  %v4083 = load i64, ptr %slot23, align 8
  %p4084 = inttoptr i64 %v4083 to ptr
  %ld4085 = load i64, ptr %p4084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4085, ptr %slot734, align 8
  %v4086 = load i64, ptr %slot734, align 8
  %v4087 = load i64, ptr %slot25, align 8
  %p4088 = inttoptr i64 %v4087 to ptr
  store i64 %v4086, ptr %p4088, align 8, !alias.scope !3, !noalias !4
  %v4089 = load i64, ptr %slot25, align 8
  %p4090 = inttoptr i64 %v4089 to ptr
  %ld4091 = load i64, ptr %p4090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4091, ptr %slot735, align 8
  %v4092 = load i64, ptr %slot24, align 8
  %p4093 = inttoptr i64 %v4092 to ptr
  %ld4094 = load i64, ptr %p4093, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4094, ptr %slot736, align 8
  %v4095 = load i64, ptr %slot736, align 8
  %cast4096 = bitcast i64 %v4095 to double
  store double %cast4096, ptr %slot737, align 8
  %v4097 = load i64, ptr %slot735, align 8
  %cast4098 = bitcast i64 %v4097 to double
  store double %cast4098, ptr %slot738, align 8
  %v4099 = load double, ptr %slot737, align 8
  %v4100 = load double, ptr %slot738, align 8
  %op4101 = fmul double %v4099, %v4100
  store double %op4101, ptr %slot739, align 8
  %v4102 = load double, ptr %slot739, align 8
  %cast4103 = bitcast double %v4102 to i64
  store i64 %cast4103, ptr %slot740, align 8
  %v4104 = load i64, ptr %slot740, align 8
  %v4105 = load i64, ptr %slot24, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  store i64 %v4104, ptr %p4106, align 8, !alias.scope !3, !noalias !4
  %v4107 = load i64, ptr %slot65, align 8
  store i64 %v4107, ptr %slot741, align 8
  %v4108 = load i64, ptr %slot741, align 8
  %p4109 = inttoptr i64 %v4108 to ptr
  store i32 2, ptr %p4109, align 4, !alias.scope !3, !noalias !4
  %v4110 = load i64, ptr %slot741, align 8
  %p4112 = inttoptr i64 %v4110 to ptr
  %gep4113 = getelementptr i8, ptr %p4112, i64 8
  %op4111 = ptrtoint ptr %gep4113 to i64
  store i64 %op4111, ptr %slot742, align 8
  %v4114 = load i64, ptr %slot24, align 8
  %p4115 = inttoptr i64 %v4114 to ptr
  %ld4116 = load i64, ptr %p4115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4116, ptr %slot743, align 8
  %v4117 = load i64, ptr %slot743, align 8
  %v4118 = load i64, ptr %slot742, align 8
  %p4119 = inttoptr i64 %v4118 to ptr
  store i64 %v4117, ptr %p4119, align 8, !alias.scope !3, !noalias !4
  %v4120 = load i64, ptr %slot741, align 8
  %v4121 = load i64, ptr %slot24, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  store i64 %v4120, ptr %p4122, align 8, !alias.scope !3, !noalias !4
  %v4123 = load i64, ptr %slot24, align 8
  %p4124 = inttoptr i64 %v4123 to ptr
  %ld4125 = load i64, ptr %p4124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4125, ptr %slot744, align 8
  %v4126 = load i64, ptr %slot744, align 8
  %p4127 = inttoptr i64 %v4126 to ptr
  %ret4128 = load { i64, i64 }, ptr %p4127, align 8
  ret { i64, i64 } %ret4128
bb_failure:
  %v4129 = load i64, ptr %slot6, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  call void @llvm.memset.p0.i64(ptr %p4130, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v4131 = load i64, ptr %slot6, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  %ret4133 = load { i64, i64 }, ptr %p4132, align 8
  ret { i64, i64 } %ret4133
bb_entry_failure:
  %v4134 = load i64, ptr %slot6, align 8
  %p4135 = inttoptr i64 %v4134 to ptr
  call void @llvm.memset.p0.i64(ptr %p4135, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v4136 = load i64, ptr %slot6, align 8
  %p4137 = inttoptr i64 %v4136 to ptr
  %ret4138 = load { i64, i64 }, ptr %p4137, align 8
  ret { i64, i64 } %ret4138
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_549c194dd59052d6a584a91a45f8e27a465f53a107227cc684c6aadde33da3a0", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_549c194dd59052d6a584a91a45f8e27a465f53a107227cc684c6aadde33da3a0", linkageName: "myl_f_549c194dd59052d6a584a91a45f8e27a465f53a107227cc684c6aadde33da3a0", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17705808327912816253, i64 0, !"myl_f_549c194dd59052d6a584a91a45f8e27a465f53a107227cc684c6aadde33da3a0"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186650359)
!110 = !DILocation(line: 478, column: 0, scope: !111)
