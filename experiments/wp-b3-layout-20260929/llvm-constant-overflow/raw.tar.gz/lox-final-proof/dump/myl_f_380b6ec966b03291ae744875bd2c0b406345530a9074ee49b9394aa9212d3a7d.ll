target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_380b6ec966b03291ae744875bd2c0b406345530a9074ee49b9394aa9212d3a7d(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i32, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i32, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i32, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v306 = load i64, ptr %slot1, align 8
  %op307 = add i64 %v306, 32
  store i64 %op307, ptr %slot4, align 8
  %mem308 = alloca i8, i64 8, align 8
  %ptr309 = ptrtoint ptr %mem308 to i64
  store i64 %ptr309, ptr %slot5, align 8
  %mem310 = alloca i8, i64 8, align 8
  %ptr311 = ptrtoint ptr %mem310 to i64
  store i64 %ptr311, ptr %slot6, align 8
  %mem312 = alloca i8, i64 8, align 8
  %ptr313 = ptrtoint ptr %mem312 to i64
  store i64 %ptr313, ptr %slot7, align 8
  %mem314 = alloca i8, i64 8, align 8
  %ptr315 = ptrtoint ptr %mem314 to i64
  store i64 %ptr315, ptr %slot8, align 8
  %mem316 = alloca i8, i64 8, align 8
  %ptr317 = ptrtoint ptr %mem316 to i64
  store i64 %ptr317, ptr %slot9, align 8
  %mem318 = alloca i8, i64 8, align 8
  %ptr319 = ptrtoint ptr %mem318 to i64
  store i64 %ptr319, ptr %slot10, align 8
  %mem320 = alloca i8, i64 8, align 8
  %ptr321 = ptrtoint ptr %mem320 to i64
  store i64 %ptr321, ptr %slot11, align 8
  %mem322 = alloca i8, i64 8, align 8
  %ptr323 = ptrtoint ptr %mem322 to i64
  store i64 %ptr323, ptr %slot12, align 8
  %mem324 = alloca i8, i64 32, align 8
  %ptr325 = ptrtoint ptr %mem324 to i64
  store i64 %ptr325, ptr %slot13, align 8
  %mem326 = alloca i8, i64 32, align 8
  %ptr327 = ptrtoint ptr %mem326 to i64
  store i64 %ptr327, ptr %slot14, align 8
  %mem328 = alloca i8, i64 8, align 8
  %ptr329 = ptrtoint ptr %mem328 to i64
  store i64 %ptr329, ptr %slot15, align 8
  %mem330 = alloca i8, i64 8, align 8
  %ptr331 = ptrtoint ptr %mem330 to i64
  store i64 %ptr331, ptr %slot16, align 8
  %mem332 = alloca i8, i64 32, align 8
  %ptr333 = ptrtoint ptr %mem332 to i64
  store i64 %ptr333, ptr %slot17, align 8
  %mem334 = alloca i8, i64 8, align 8
  %ptr335 = ptrtoint ptr %mem334 to i64
  store i64 %ptr335, ptr %slot18, align 8
  %mem336 = alloca i8, i64 8, align 8
  %ptr337 = ptrtoint ptr %mem336 to i64
  store i64 %ptr337, ptr %slot19, align 8
  %mem338 = alloca i8, i64 8, align 8
  %ptr339 = ptrtoint ptr %mem338 to i64
  store i64 %ptr339, ptr %slot20, align 8
  %mem340 = alloca i8, i64 32, align 8
  %ptr341 = ptrtoint ptr %mem340 to i64
  store i64 %ptr341, ptr %slot21, align 8
  %mem342 = alloca i8, i64 8, align 8
  %ptr343 = ptrtoint ptr %mem342 to i64
  store i64 %ptr343, ptr %slot22, align 8
  %mem344 = alloca i8, i64 8, align 8
  %ptr345 = ptrtoint ptr %mem344 to i64
  store i64 %ptr345, ptr %slot23, align 8
  %v346 = load i64, ptr %slot2, align 8
  %v347 = load i64, ptr %slot18, align 8
  %p348 = inttoptr i64 %v347 to ptr
  store i64 %v346, ptr %p348, align 8, !alias.scope !3, !noalias !4
  %v349 = load i64, ptr %slot3, align 8
  %v350 = load i64, ptr %slot19, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i64 %v349, ptr %p351, align 8, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot1, align 8
  %p353 = inttoptr i64 %v352 to ptr
  %call354 = call ptr @myl_qbe_heap(ptr %p353) nomerge, !dbg !110
  %calladdr355 = ptrtoint ptr %call354 to i64
  store i64 %calladdr355, ptr %slot24, align 8
  %v356 = load i64, ptr %slot1, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %call358 = call i64 @myl_qbe_region_mark(ptr %p357) nomerge, !dbg !110
  store i64 %call358, ptr %slot25, align 8
  %v359 = load i64, ptr %slot5, align 8
  %p360 = inttoptr i64 %v359 to ptr
  store i32 0, ptr %p360, align 4, !alias.scope !3, !noalias !4
  %v361 = load i64, ptr %slot6, align 8
  %p362 = inttoptr i64 %v361 to ptr
  store i32 0, ptr %p362, align 4, !alias.scope !3, !noalias !4
  %v363 = load i64, ptr %slot7, align 8
  %p364 = inttoptr i64 %v363 to ptr
  store i32 0, ptr %p364, align 4, !alias.scope !3, !noalias !4
  %v365 = load i64, ptr %slot8, align 8
  %p366 = inttoptr i64 %v365 to ptr
  store i32 0, ptr %p366, align 4, !alias.scope !3, !noalias !4
  %v367 = load i64, ptr %slot9, align 8
  %p368 = inttoptr i64 %v367 to ptr
  store i32 0, ptr %p368, align 4, !alias.scope !3, !noalias !4
  %v369 = load i64, ptr %slot10, align 8
  %p370 = inttoptr i64 %v369 to ptr
  store i32 0, ptr %p370, align 4, !alias.scope !3, !noalias !4
  %v371 = load i64, ptr %slot11, align 8
  %p372 = inttoptr i64 %v371 to ptr
  store i32 0, ptr %p372, align 4, !alias.scope !3, !noalias !4
  %v373 = load i64, ptr %slot12, align 8
  %p374 = inttoptr i64 %v373 to ptr
  store i32 0, ptr %p374, align 4, !alias.scope !3, !noalias !4
  %v375 = load i64, ptr %slot6, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i32 2, ptr %p376, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v377 = load i64, ptr %slot18, align 8
  %p378 = inttoptr i64 %v377 to ptr
  %ld379 = load i64, ptr %p378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld379, ptr %slot26, align 8
  %v380 = load i64, ptr %slot26, align 8
  %v381 = load i64, ptr %slot22, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 %v380, ptr %p382, align 8, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot22, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot27, align 8
  %v386 = load i64, ptr %slot7, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i32, ptr %p387, align 4, !alias.scope !3, !noalias !4
  store i32 %ld388, ptr %slot28, align 8
  %v389 = load i64, ptr %slot8, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %ld391 = load i32, ptr %p390, align 4, !alias.scope !3, !noalias !4
  store i32 %ld391, ptr %slot29, align 8
  %v392 = load i32, ptr %slot29, align 8
  %op393 = and i32 %v392, 24
  store i32 %op393, ptr %slot29, align 8
  %v394 = load i32, ptr %slot29, align 8
  %cmp395 = icmp eq i32 %v394, 0
  %cv396 = zext i1 %cmp395 to i32
  store i32 %cv396, ptr %slot30, align 8
  %v397 = load i32, ptr %slot28, align 8
  %v398 = load i32, ptr %slot30, align 8
  %op399 = and i32 %v397, %v398
  store i32 %op399, ptr %slot31, align 8
  %v400 = load i32, ptr %slot31, align 8
  %cv401 = zext i32 %v400 to i64
  %cond402 = icmp ne i64 %cv401, 0
  br i1 %cond402, label %bb_rctake5, label %bb_rccopy5
bb_rctake5:
  %v403 = load i64, ptr %slot17, align 8
  store i64 %v403, ptr %slot32, align 8
  %v404 = load i64, ptr %slot25, align 8
  store i64 %v404, ptr %slot33, align 8
  %v405 = load i64, ptr %slot27, align 8
  %v406 = load i64, ptr %slot32, align 8
  %op407 = sub i64 %v405, %v406
  store i64 %op407, ptr %slot34, align 8
  %v408 = load i64, ptr %slot32, align 8
  %v409 = load i64, ptr %slot27, align 8
  %op410 = sub i64 %v408, %v409
  store i64 %op410, ptr %slot35, align 8
  %v411 = load i64, ptr %slot34, align 8
  %cmp412 = icmp ult i64 %v411, 32
  %cv413 = zext i1 %cmp412 to i32
  store i32 %cv413, ptr %slot36, align 8
  %v414 = load i64, ptr %slot35, align 8
  %cmp415 = icmp ult i64 %v414, 32
  %cv416 = zext i1 %cmp415 to i32
  store i32 %cv416, ptr %slot37, align 8
  %v417 = load i32, ptr %slot36, align 8
  %v418 = load i32, ptr %slot37, align 8
  %op419 = or i32 %v417, %v418
  store i32 %op419, ptr %slot38, align 8
  %v420 = load i32, ptr %slot38, align 8
  %cv421 = zext i32 %v420 to i64
  %cond422 = icmp ne i64 %cv421, 0
  br i1 %cond422, label %bb_rcmoveslow14, label %bb_rcmovecheck14
bb_rcmovecheck14:
  %v423 = load i64, ptr %slot27, align 8
  %op424 = add i64 %v423, 0
  store i64 %op424, ptr %slot39, align 8
  %v425 = load i64, ptr %slot39, align 8
  %p426 = inttoptr i64 %v425 to ptr
  %ld427 = load i64, ptr %p426, align 8, !alias.scope !4, !noalias !3
  store i64 %ld427, ptr %slot40, align 8
  %v428 = load i64, ptr %slot40, align 8
  %cmp429 = icmp ne i64 %v428, 0
  %cv430 = zext i1 %cmp429 to i32
  store i32 %cv430, ptr %slot41, align 8
  %v431 = load i32, ptr %slot41, align 8
  %cv432 = zext i32 %v431 to i64
  %cond433 = icmp ne i64 %cv432, 0
  br i1 %cond433, label %bb_rcmoveheader22, label %bb_rcmovenext22
bb_rcmoveheader22:
  %v434 = load i64, ptr %slot40, align 8
  %op435 = sub i64 %v434, 16
  store i64 %op435, ptr %slot42, align 8
  %v436 = load i64, ptr %slot40, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %rgep438 = getelementptr i8, ptr %p437, i64 -16
  %ld439 = load i64, ptr %rgep438, align 8, !alias.scope !9, !noalias !10
  store i64 %ld439, ptr %slot43, align 8
  %v440 = load i64, ptr %slot43, align 8
  %op441 = and i64 %v440, 5764607523034234881
  store i64 %op441, ptr %slot44, align 8
  %v442 = load i64, ptr %slot44, align 8
  %cmp443 = icmp ne i64 %v442, 0
  %cv444 = zext i1 %cmp443 to i32
  store i32 %cv444, ptr %slot45, align 8
  %v445 = load i32, ptr %slot45, align 8
  %cv446 = zext i32 %v445 to i64
  %cond447 = icmp ne i64 %cv446, 0
  br i1 %cond447, label %bb_rcmoveslow14, label %bb_rcmovenext22
bb_rcmovenext22:
  %v448 = load i64, ptr %slot27, align 8
  %v449 = load i64, ptr %slot32, align 8
  %p450 = inttoptr i64 %v448 to ptr
  %p451 = inttoptr i64 %v449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p451, ptr %p450, i64 32, i1 false), !alias.scope !10000000
  %v452 = load i64, ptr %slot27, align 8
  %p453 = inttoptr i64 %v452 to ptr
  store i64 0, ptr %p453, align 8, !alias.scope !4, !noalias !3
  %v454 = load i64, ptr %slot27, align 8
  %op455 = add i64 %v454, 8
  store i64 %op455, ptr %slot46, align 8
  %v456 = load i64, ptr %slot46, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i64 0, ptr %p457, align 8, !alias.scope !4, !noalias !3
  %v458 = load i64, ptr %slot27, align 8
  %op459 = add i64 %v458, 16
  store i64 %op459, ptr %slot47, align 8
  %v460 = load i64, ptr %slot47, align 8
  %p461 = inttoptr i64 %v460 to ptr
  store i64 0, ptr %p461, align 8, !alias.scope !4, !noalias !3
  %v462 = load i64, ptr %slot27, align 8
  %op463 = add i64 %v462, 24
  store i64 %op463, ptr %slot48, align 8
  %v464 = load i64, ptr %slot48, align 8
  %p465 = inttoptr i64 %v464 to ptr
  store i64 0, ptr %p465, align 8, !alias.scope !4, !noalias !3
  br label %bb_rcmoved14
bb_rcmoveslow14:
  %v466 = load i64, ptr %slot24, align 8
  %v467 = load i64, ptr %slot32, align 8
  %v468 = load i64, ptr %slot27, align 8
  %v469 = load i64, ptr %slot33, align 8
  %cv470 = trunc i64 %v469 to i32
  %call471 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64 %v466, i64 %v467, i64 %v468, i32 %cv470) nomerge, !dbg !112
  store i32 %call471, ptr %slot49, align 8
  %v472 = load i32, ptr %slot49, align 8
  %cv473 = zext i32 %v472 to i64
  %cond474 = icmp ne i64 %cv473, 0
  br i1 %cond474, label %bb_rcsuccess32, label %bb_rcfailure32
bb_rcfailure32:
  %v475 = load i64, ptr %slot24, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %call477 = call i32 @myl_rc_take_failure(ptr %p476) nomerge, !dbg !112
  store i32 %call477, ptr %slot50, align 8
  %v478 = load i64, ptr %slot1, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %v480 = load i32, ptr %slot50, align 8
  %call481 = call i32 @myl_qbe_rc_status(ptr %p479, i32 %v480) nomerge, !dbg !112
  store i32 %call481, ptr %slot51, align 8
  br label %bb_failure
bb_rcsuccess32:
  br label %bb_rcmoved14
bb_rcmoved14:
  %v482 = load i64, ptr %slot7, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 0, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot12, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 2, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot11, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 1, ptr %p487, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared5
bb_rccopy5:
  %v488 = load i64, ptr %slot17, align 8
  store i64 %v488, ptr %slot52, align 8
  %v489 = load i64, ptr %slot25, align 8
  store i64 %v489, ptr %slot53, align 8
  %v490 = load i64, ptr %slot24, align 8
  %v491 = load i64, ptr %slot52, align 8
  %v492 = load i64, ptr %slot27, align 8
  %v493 = load i64, ptr %slot53, align 8
  %cv494 = trunc i64 %v493 to i32
  %call495 = call i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64 %v490, i64 %v491, i64 %v492, i32 %cv494) nomerge, !dbg !112
  store i32 %call495, ptr %slot54, align 8
  %v496 = load i32, ptr %slot54, align 8
  %cv497 = zext i32 %v496 to i64
  %cond498 = icmp ne i64 %cv497, 0
  br i1 %cond498, label %bb_rcsuccess41, label %bb_rcfailure41
bb_rcfailure41:
  %v499 = load i64, ptr %slot24, align 8
  %p500 = inttoptr i64 %v499 to ptr
  %call501 = call i32 @myl_rc_take_failure(ptr %p500) nomerge, !dbg !112
  store i32 %call501, ptr %slot55, align 8
  %v502 = load i64, ptr %slot1, align 8
  %p503 = inttoptr i64 %v502 to ptr
  %v504 = load i32, ptr %slot55, align 8
  %call505 = call i32 @myl_qbe_rc_status(ptr %p503, i32 %v504) nomerge, !dbg !112
  store i32 %call505, ptr %slot56, align 8
  br label %bb_failure
bb_rcsuccess41:
  %v506 = load i64, ptr %slot12, align 8
  %p507 = inttoptr i64 %v506 to ptr
  store i32 2, ptr %p507, align 4, !alias.scope !3, !noalias !4
  %v508 = load i64, ptr %slot11, align 8
  %p509 = inttoptr i64 %v508 to ptr
  store i32 1, ptr %p509, align 4, !alias.scope !3, !noalias !4
  %v510 = load i64, ptr %slot7, align 8
  %p511 = inttoptr i64 %v510 to ptr
  %ld512 = load i32, ptr %p511, align 4, !alias.scope !3, !noalias !4
  store i32 %ld512, ptr %slot57, align 8
  %v513 = load i32, ptr %slot57, align 8
  %cv514 = zext i32 %v513 to i64
  %cond515 = icmp ne i64 %cv514, 0
  br i1 %cond515, label %bb_rcslotdrop48, label %bb_rcslotdone48
bb_rcslotdrop48:
  %v516 = load i64, ptr %slot7, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i32 0, ptr %p517, align 4, !alias.scope !3, !noalias !4
  %v518 = load i64, ptr %slot13, align 8
  store i64 %v518, ptr %slot58, align 8
  %v519 = load i64, ptr %slot8, align 8
  %p520 = inttoptr i64 %v519 to ptr
  %ld521 = load i32, ptr %p520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld521, ptr %slot59, align 8
  %v522 = load i32, ptr %slot59, align 8
  %op523 = and i32 %v522, 28
  store i32 %op523, ptr %slot60, align 8
  %v524 = load i32, ptr %slot60, align 8
  %cv525 = zext i32 %v524 to i64
  %cond526 = icmp ne i64 %cv525, 0
  br i1 %cond526, label %bb_rcslotrole48, label %bb_rcslotowner48
bb_rcslotrole48:
  %v527 = load i64, ptr %slot24, align 8
  store i64 %v527, ptr %slot61, align 8
  %v528 = load i64, ptr %slot61, align 8
  %v529 = load i64, ptr %slot58, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v528, i64 %v529) nomerge, !dbg !112
  br label %bb_rcslotdone48
bb_rcslotowner48:
  %v530 = load i64, ptr %slot58, align 8
  %p532 = inttoptr i64 %v530 to ptr
  %gep533 = getelementptr i8, ptr %p532, i64 0
  %op531 = ptrtoint ptr %gep533 to i64
  store i64 %op531, ptr %slot62, align 8
  %v534 = load i64, ptr %slot24, align 8
  store i64 %v534, ptr %slot63, align 8
  %v535 = load i64, ptr %slot62, align 8
  %p536 = inttoptr i64 %v535 to ptr
  %ld537 = load i64, ptr %p536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld537, ptr %slot64, align 8
  %v538 = load i64, ptr %slot64, align 8
  %cmp539 = icmp ne i64 %v538, 0
  %cv540 = zext i1 %cmp539 to i32
  store i32 %cv540, ptr %slot65, align 8
  %v541 = load i32, ptr %slot65, align 8
  %cv542 = zext i32 %v541 to i64
  %cond543 = icmp ne i64 %cv542, 0
  br i1 %cond543, label %bb_rcgnn66, label %bb_rcgdone66
bb_rcgnn66:
  %v544 = load i64, ptr %slot64, align 8
  %op545 = sub i64 %v544, 16
  store i64 %op545, ptr %slot66, align 8
  %v546 = load i64, ptr %slot64, align 8
  %p547 = inttoptr i64 %v546 to ptr
  %rgep548 = getelementptr i8, ptr %p547, i64 -16
  %ld549 = load i64, ptr %rgep548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld549, ptr %slot67, align 8
  %v550 = load i64, ptr %slot67, align 8
  %op551 = and i64 %v550, 4611686018427387906
  store i64 %op551, ptr %slot68, align 8
  %v552 = load i64, ptr %slot68, align 8
  %cmp553 = icmp ne i64 %v552, 0
  %cv554 = zext i1 %cmp553 to i32
  store i32 %cv554, ptr %slot69, align 8
  %v555 = load i32, ptr %slot69, align 8
  %cv556 = zext i32 %v555 to i64
  %cond557 = icmp ne i64 %cv556, 0
  br i1 %cond557, label %bb_rcgclear66, label %bb_rcgcounted66
bb_rcgcounted66:
  %v558 = load i64, ptr %slot64, align 8
  %op559 = sub i64 %v558, 32
  store i64 %op559, ptr %slot70, align 8
  %v560 = load i64, ptr %slot64, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %rgep562 = getelementptr i8, ptr %p561, i64 -32
  %ld563 = load i64, ptr %rgep562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld563, ptr %slot71, align 8
  %v564 = load i64, ptr %slot71, align 8
  %op565 = sub i64 %v564, 1
  store i64 %op565, ptr %slot72, align 8
  %v566 = load i64, ptr %slot72, align 8
  %cmp567 = icmp eq i64 %v566, 0
  %cv568 = zext i1 %cmp567 to i32
  store i32 %cv568, ptr %slot73, align 8
  %v569 = load i32, ptr %slot73, align 8
  %cv570 = zext i32 %v569 to i64
  %cond571 = icmp ne i64 %cv570, 0
  br i1 %cond571, label %bb_rcglast66, label %bb_rcgdec66
bb_rcglast66:
  %v572 = load i64, ptr %slot64, align 8
  %op573 = sub i64 %v572, 24
  store i64 %op573, ptr %slot74, align 8
  %v574 = load i64, ptr %slot64, align 8
  %p575 = inttoptr i64 %v574 to ptr
  %rgep576 = getelementptr i8, ptr %p575, i64 -24
  %ld577 = load i64, ptr %rgep576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld577, ptr %slot75, align 8
  %v578 = load i64, ptr %slot75, align 8
  %cmp579 = icmp ne i64 %v578, 0
  %cv580 = zext i1 %cmp579 to i32
  store i32 %cv580, ptr %slot76, align 8
  %v581 = load i32, ptr %slot76, align 8
  %cv582 = zext i32 %v581 to i64
  %cond583 = icmp ne i64 %cv582, 0
  br i1 %cond583, label %bb_rcgdec66, label %bb_rcgslow66
bb_rcgslow66:
  %v584 = load i64, ptr %slot63, align 8
  %v585 = load i64, ptr %slot62, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v584, i64 %v585) nomerge, !dbg !112
  br label %bb_rcgdone66
bb_rcgdec66:
  %v586 = load i64, ptr %slot72, align 8
  %v587 = load i64, ptr %slot64, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %rgep589 = getelementptr i8, ptr %p588, i64 -32
  store i64 %v586, ptr %rgep589, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear66
bb_rcgclear66:
  %v590 = load i64, ptr %slot62, align 8
  %p591 = inttoptr i64 %v590 to ptr
  store i64 0, ptr %p591, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone66
bb_rcgdone66:
  %v592 = load i64, ptr %slot58, align 8
  %p593 = inttoptr i64 %v592 to ptr
  store i64 0, ptr %p593, align 8, !alias.scope !3, !noalias !4
  %v594 = load i64, ptr %slot58, align 8
  %p596 = inttoptr i64 %v594 to ptr
  %gep597 = getelementptr i8, ptr %p596, i64 8
  %op595 = ptrtoint ptr %gep597 to i64
  store i64 %op595, ptr %slot77, align 8
  %v598 = load i64, ptr %slot77, align 8
  %p599 = inttoptr i64 %v598 to ptr
  store i64 0, ptr %p599, align 8, !alias.scope !3, !noalias !4
  %v600 = load i64, ptr %slot58, align 8
  %p602 = inttoptr i64 %v600 to ptr
  %gep603 = getelementptr i8, ptr %p602, i64 16
  %op601 = ptrtoint ptr %gep603 to i64
  store i64 %op601, ptr %slot78, align 8
  %v604 = load i64, ptr %slot78, align 8
  %p605 = inttoptr i64 %v604 to ptr
  store i64 0, ptr %p605, align 8, !alias.scope !3, !noalias !4
  %v606 = load i64, ptr %slot58, align 8
  %p608 = inttoptr i64 %v606 to ptr
  %gep609 = getelementptr i8, ptr %p608, i64 24
  %op607 = ptrtoint ptr %gep609 to i64
  store i64 %op607, ptr %slot79, align 8
  %v610 = load i64, ptr %slot79, align 8
  %p611 = inttoptr i64 %v610 to ptr
  store i64 0, ptr %p611, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone48
bb_rcslotdone48:
  br label %bb_rcprepared5
bb_rcprepared5:
  %v612 = load i64, ptr %slot5, align 8
  %p613 = inttoptr i64 %v612 to ptr
  %ld614 = load i32, ptr %p613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld614, ptr %slot80, align 8
  %v615 = load i32, ptr %slot80, align 8
  %cv616 = zext i32 %v615 to i64
  %cond617 = icmp ne i64 %cv616, 0
  br i1 %cond617, label %bb_rcslotdrop76, label %bb_rcslotdone76
bb_rcslotdrop76:
  %v618 = load i64, ptr %slot5, align 8
  %p619 = inttoptr i64 %v618 to ptr
  store i32 0, ptr %p619, align 4, !alias.scope !3, !noalias !4
  %v620 = load i64, ptr %slot21, align 8
  store i64 %v620, ptr %slot81, align 8
  %v621 = load i64, ptr %slot6, align 8
  %p622 = inttoptr i64 %v621 to ptr
  %ld623 = load i32, ptr %p622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld623, ptr %slot82, align 8
  %v624 = load i32, ptr %slot82, align 8
  %op625 = and i32 %v624, 28
  store i32 %op625, ptr %slot83, align 8
  %v626 = load i32, ptr %slot83, align 8
  %cv627 = zext i32 %v626 to i64
  %cond628 = icmp ne i64 %cv627, 0
  br i1 %cond628, label %bb_rcslotrole76, label %bb_rcslotowner76
bb_rcslotrole76:
  %v629 = load i64, ptr %slot24, align 8
  store i64 %v629, ptr %slot84, align 8
  %v630 = load i64, ptr %slot84, align 8
  %v631 = load i64, ptr %slot81, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v630, i64 %v631) nomerge, !dbg !112
  br label %bb_rcslotdone76
bb_rcslotowner76:
  %v632 = load i64, ptr %slot81, align 8
  %p634 = inttoptr i64 %v632 to ptr
  %gep635 = getelementptr i8, ptr %p634, i64 0
  %op633 = ptrtoint ptr %gep635 to i64
  store i64 %op633, ptr %slot85, align 8
  %v636 = load i64, ptr %slot24, align 8
  store i64 %v636, ptr %slot86, align 8
  %v637 = load i64, ptr %slot85, align 8
  %p638 = inttoptr i64 %v637 to ptr
  %ld639 = load i64, ptr %p638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld639, ptr %slot87, align 8
  %v640 = load i64, ptr %slot87, align 8
  %cmp641 = icmp ne i64 %v640, 0
  %cv642 = zext i1 %cmp641 to i32
  store i32 %cv642, ptr %slot88, align 8
  %v643 = load i32, ptr %slot88, align 8
  %cv644 = zext i32 %v643 to i64
  %cond645 = icmp ne i64 %cv644, 0
  br i1 %cond645, label %bb_rcgnn94, label %bb_rcgdone94
bb_rcgnn94:
  %v646 = load i64, ptr %slot87, align 8
  %op647 = sub i64 %v646, 16
  store i64 %op647, ptr %slot89, align 8
  %v648 = load i64, ptr %slot87, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %rgep650 = getelementptr i8, ptr %p649, i64 -16
  %ld651 = load i64, ptr %rgep650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld651, ptr %slot90, align 8
  %v652 = load i64, ptr %slot90, align 8
  %op653 = and i64 %v652, 4611686018427387906
  store i64 %op653, ptr %slot91, align 8
  %v654 = load i64, ptr %slot91, align 8
  %cmp655 = icmp ne i64 %v654, 0
  %cv656 = zext i1 %cmp655 to i32
  store i32 %cv656, ptr %slot92, align 8
  %v657 = load i32, ptr %slot92, align 8
  %cv658 = zext i32 %v657 to i64
  %cond659 = icmp ne i64 %cv658, 0
  br i1 %cond659, label %bb_rcgclear94, label %bb_rcgcounted94
bb_rcgcounted94:
  %v660 = load i64, ptr %slot87, align 8
  %op661 = sub i64 %v660, 32
  store i64 %op661, ptr %slot93, align 8
  %v662 = load i64, ptr %slot87, align 8
  %p663 = inttoptr i64 %v662 to ptr
  %rgep664 = getelementptr i8, ptr %p663, i64 -32
  %ld665 = load i64, ptr %rgep664, align 8, !alias.scope !9, !noalias !10
  store i64 %ld665, ptr %slot94, align 8
  %v666 = load i64, ptr %slot94, align 8
  %op667 = sub i64 %v666, 1
  store i64 %op667, ptr %slot95, align 8
  %v668 = load i64, ptr %slot95, align 8
  %cmp669 = icmp eq i64 %v668, 0
  %cv670 = zext i1 %cmp669 to i32
  store i32 %cv670, ptr %slot96, align 8
  %v671 = load i32, ptr %slot96, align 8
  %cv672 = zext i32 %v671 to i64
  %cond673 = icmp ne i64 %cv672, 0
  br i1 %cond673, label %bb_rcglast94, label %bb_rcgdec94
bb_rcglast94:
  %v674 = load i64, ptr %slot87, align 8
  %op675 = sub i64 %v674, 24
  store i64 %op675, ptr %slot97, align 8
  %v676 = load i64, ptr %slot87, align 8
  %p677 = inttoptr i64 %v676 to ptr
  %rgep678 = getelementptr i8, ptr %p677, i64 -24
  %ld679 = load i64, ptr %rgep678, align 8, !alias.scope !9, !noalias !10
  store i64 %ld679, ptr %slot98, align 8
  %v680 = load i64, ptr %slot98, align 8
  %cmp681 = icmp ne i64 %v680, 0
  %cv682 = zext i1 %cmp681 to i32
  store i32 %cv682, ptr %slot99, align 8
  %v683 = load i32, ptr %slot99, align 8
  %cv684 = zext i32 %v683 to i64
  %cond685 = icmp ne i64 %cv684, 0
  br i1 %cond685, label %bb_rcgdec94, label %bb_rcgslow94
bb_rcgslow94:
  %v686 = load i64, ptr %slot86, align 8
  %v687 = load i64, ptr %slot85, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v686, i64 %v687) nomerge, !dbg !112
  br label %bb_rcgdone94
bb_rcgdec94:
  %v688 = load i64, ptr %slot95, align 8
  %v689 = load i64, ptr %slot87, align 8
  %p690 = inttoptr i64 %v689 to ptr
  %rgep691 = getelementptr i8, ptr %p690, i64 -32
  store i64 %v688, ptr %rgep691, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear94
bb_rcgclear94:
  %v692 = load i64, ptr %slot85, align 8
  %p693 = inttoptr i64 %v692 to ptr
  store i64 0, ptr %p693, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone94
bb_rcgdone94:
  %v694 = load i64, ptr %slot81, align 8
  %p695 = inttoptr i64 %v694 to ptr
  store i64 0, ptr %p695, align 8, !alias.scope !3, !noalias !4
  %v696 = load i64, ptr %slot81, align 8
  %p698 = inttoptr i64 %v696 to ptr
  %gep699 = getelementptr i8, ptr %p698, i64 8
  %op697 = ptrtoint ptr %gep699 to i64
  store i64 %op697, ptr %slot100, align 8
  %v700 = load i64, ptr %slot100, align 8
  %p701 = inttoptr i64 %v700 to ptr
  store i64 0, ptr %p701, align 8, !alias.scope !3, !noalias !4
  %v702 = load i64, ptr %slot81, align 8
  %p704 = inttoptr i64 %v702 to ptr
  %gep705 = getelementptr i8, ptr %p704, i64 16
  %op703 = ptrtoint ptr %gep705 to i64
  store i64 %op703, ptr %slot101, align 8
  %v706 = load i64, ptr %slot101, align 8
  %p707 = inttoptr i64 %v706 to ptr
  store i64 0, ptr %p707, align 8, !alias.scope !3, !noalias !4
  %v708 = load i64, ptr %slot81, align 8
  %p710 = inttoptr i64 %v708 to ptr
  %gep711 = getelementptr i8, ptr %p710, i64 24
  %op709 = ptrtoint ptr %gep711 to i64
  store i64 %op709, ptr %slot102, align 8
  %v712 = load i64, ptr %slot102, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i64 0, ptr %p713, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone76
bb_rcslotdone76:
  %v714 = load i64, ptr %slot21, align 8
  store i64 %v714, ptr %slot103, align 8
  %v715 = load i64, ptr %slot17, align 8
  store i64 %v715, ptr %slot104, align 8
  %v716 = load i64, ptr %slot104, align 8
  %v717 = load i64, ptr %slot103, align 8
  %p718 = inttoptr i64 %v716 to ptr
  %p719 = inttoptr i64 %v717 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p719, ptr %p718, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v720 = load i64, ptr %slot11, align 8
  %p721 = inttoptr i64 %v720 to ptr
  store i32 0, ptr %p721, align 4, !alias.scope !3, !noalias !4
  %v722 = load i64, ptr %slot6, align 8
  %p723 = inttoptr i64 %v722 to ptr
  store i32 2, ptr %p723, align 4, !alias.scope !3, !noalias !4
  %v724 = load i64, ptr %slot12, align 8
  %p725 = inttoptr i64 %v724 to ptr
  %ld726 = load i32, ptr %p725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld726, ptr %slot105, align 8
  %v727 = load i32, ptr %slot105, align 8
  %v728 = load i64, ptr %slot6, align 8
  %p729 = inttoptr i64 %v728 to ptr
  store i32 %v727, ptr %p729, align 4, !alias.scope !3, !noalias !4
  %v730 = load i64, ptr %slot5, align 8
  %p731 = inttoptr i64 %v730 to ptr
  store i32 1, ptr %p731, align 4, !alias.scope !3, !noalias !4
  %v732 = load i64, ptr %slot21, align 8
  %v733 = load i64, ptr %slot22, align 8
  %p734 = inttoptr i64 %v733 to ptr
  store i64 %v732, ptr %p734, align 8, !alias.scope !3, !noalias !4
  %v735 = load i64, ptr %slot22, align 8
  %p736 = inttoptr i64 %v735 to ptr
  %ld737 = load i64, ptr %p736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld737, ptr %slot106, align 8
  %v738 = load i64, ptr %slot106, align 8
  %op739 = add i64 %v738, 16
  store i64 %op739, ptr %slot107, align 8
  %v740 = load i64, ptr %slot107, align 8
  %p741 = inttoptr i64 %v740 to ptr
  %ld742 = load i64, ptr %p741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld742, ptr %slot108, align 8
  %v743 = load i64, ptr %slot108, align 8
  %v744 = load i64, ptr %slot22, align 8
  %p745 = inttoptr i64 %v744 to ptr
  store i64 %v743, ptr %p745, align 8, !alias.scope !3, !noalias !4
  %v746 = load i64, ptr %slot7, align 8
  %p747 = inttoptr i64 %v746 to ptr
  %ld748 = load i32, ptr %p747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld748, ptr %slot109, align 8
  %v749 = load i32, ptr %slot109, align 8
  %cv750 = zext i32 %v749 to i64
  %cond751 = icmp ne i64 %cv750, 0
  br i1 %cond751, label %bb_rcslotdrop113, label %bb_rcslotdone113
bb_rcslotdrop113:
  %v752 = load i64, ptr %slot7, align 8
  %p753 = inttoptr i64 %v752 to ptr
  store i32 0, ptr %p753, align 4, !alias.scope !3, !noalias !4
  %v754 = load i64, ptr %slot13, align 8
  store i64 %v754, ptr %slot110, align 8
  %v755 = load i64, ptr %slot8, align 8
  %p756 = inttoptr i64 %v755 to ptr
  %ld757 = load i32, ptr %p756, align 4, !alias.scope !3, !noalias !4
  store i32 %ld757, ptr %slot111, align 8
  %v758 = load i32, ptr %slot111, align 8
  %op759 = and i32 %v758, 28
  store i32 %op759, ptr %slot112, align 8
  %v760 = load i32, ptr %slot112, align 8
  %cv761 = zext i32 %v760 to i64
  %cond762 = icmp ne i64 %cv761, 0
  br i1 %cond762, label %bb_rcslotrole113, label %bb_rcslotowner113
bb_rcslotrole113:
  %v763 = load i64, ptr %slot24, align 8
  store i64 %v763, ptr %slot113, align 8
  %v764 = load i64, ptr %slot113, align 8
  %v765 = load i64, ptr %slot110, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v764, i64 %v765) nomerge, !dbg !114
  br label %bb_rcslotdone113
bb_rcslotowner113:
  %v766 = load i64, ptr %slot24, align 8
  store i64 %v766, ptr %slot114, align 8
  %v767 = load i64, ptr %slot114, align 8
  %v768 = load i64, ptr %slot110, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v767, i64 %v768) nomerge, !dbg !114
  br label %bb_rcslotdone113
bb_rcslotdone113:
  %v769 = load i64, ptr %slot21, align 8
  %v770 = load i64, ptr %slot23, align 8
  %p771 = inttoptr i64 %v770 to ptr
  store i64 %v769, ptr %p771, align 8, !alias.scope !3, !noalias !4
  %v772 = load i64, ptr %slot23, align 8
  %p773 = inttoptr i64 %v772 to ptr
  %ld774 = load i64, ptr %p773, align 8, !alias.scope !3, !noalias !4
  store i64 %ld774, ptr %slot115, align 8
  %v775 = load i64, ptr %slot115, align 8
  %op776 = add i64 %v775, 0
  store i64 %op776, ptr %slot116, align 8
  %v777 = load i64, ptr %slot116, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %ld779 = load i64, ptr %p778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld779, ptr %slot117, align 8
  %v780 = load i64, ptr %slot117, align 8
  %v781 = load i64, ptr %slot23, align 8
  %p782 = inttoptr i64 %v781 to ptr
  store i64 %v780, ptr %p782, align 8, !alias.scope !3, !noalias !4
  %v783 = load i64, ptr %slot23, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %ld785 = load i64, ptr %p784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld785, ptr %slot118, align 8
  %v786 = load i64, ptr %slot118, align 8
  %v787 = load i64, ptr %slot16, align 8
  %p788 = inttoptr i64 %v787 to ptr
  store i64 %v786, ptr %p788, align 8, !alias.scope !3, !noalias !4
  %v789 = load i64, ptr %slot16, align 8
  store i64 %v789, ptr %slot119, align 8
  %v790 = load i64, ptr %slot17, align 8
  store i64 %v790, ptr %slot120, align 8
  %v791 = load i64, ptr %slot119, align 8
  %p792 = inttoptr i64 %v791 to ptr
  %ld793 = load i64, ptr %p792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld793, ptr %slot121, align 8
  %v794 = load i64, ptr %slot121, align 8
  %cmp795 = icmp ne i64 %v794, 0
  %cv796 = zext i1 %cmp795 to i32
  store i32 %cv796, ptr %slot122, align 8
  %v797 = load i32, ptr %slot122, align 8
  %cv798 = zext i32 %v797 to i64
  %cond799 = icmp ne i64 %cv798, 0
  br i1 %cond799, label %bb_rcgnn127, label %bb_rcgstore127
bb_rcgnn127:
  %v800 = load i64, ptr %slot121, align 8
  %op801 = sub i64 %v800, 16
  store i64 %op801, ptr %slot123, align 8
  %v802 = load i64, ptr %slot121, align 8
  %p803 = inttoptr i64 %v802 to ptr
  %rgep804 = getelementptr i8, ptr %p803, i64 -16
  %ld805 = load i64, ptr %rgep804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld805, ptr %slot124, align 8
  %v806 = load i64, ptr %slot124, align 8
  %op807 = and i64 %v806, 4611686018427387906
  store i64 %op807, ptr %slot125, align 8
  %v808 = load i64, ptr %slot125, align 8
  %cmp809 = icmp ne i64 %v808, 0
  %cv810 = zext i1 %cmp809 to i32
  store i32 %cv810, ptr %slot126, align 8
  %v811 = load i32, ptr %slot126, align 8
  %cv812 = zext i32 %v811 to i64
  %cond813 = icmp ne i64 %cv812, 0
  br i1 %cond813, label %bb_rcgstore127, label %bb_rcginc127
bb_rcginc127:
  %v814 = load i64, ptr %slot121, align 8
  %op815 = sub i64 %v814, 24
  store i64 %op815, ptr %slot127, align 8
  %v816 = load i64, ptr %slot121, align 8
  %p817 = inttoptr i64 %v816 to ptr
  %rgep818 = getelementptr i8, ptr %p817, i64 -24
  %ld819 = load i64, ptr %rgep818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld819, ptr %slot128, align 8
  %v820 = load i64, ptr %slot128, align 8
  %op821 = add i64 %v820, 1
  store i64 %op821, ptr %slot129, align 8
  %v822 = load i64, ptr %slot129, align 8
  %cmp823 = icmp eq i64 %v822, 0
  %cv824 = zext i1 %cmp823 to i32
  store i32 %cv824, ptr %slot130, align 8
  %v825 = load i32, ptr %slot130, align 8
  %cv826 = zext i32 %v825 to i64
  %cond827 = icmp ne i64 %cv826, 0
  br i1 %cond827, label %bb_rcglimit127, label %bb_rcgcapacity127
bb_rcglimit127:
  %v828 = load i64, ptr %slot1, align 8
  %p829 = inttoptr i64 %v828 to ptr
  %call830 = call i32 @myl_qbe_rc_status(ptr %p829, i32 2) nomerge, !dbg !116
  store i32 %call830, ptr %slot131, align 8
  br label %bb_failure
bb_rcgcapacity127:
  %v831 = load i64, ptr %slot129, align 8
  %v832 = load i64, ptr %slot121, align 8
  %p833 = inttoptr i64 %v832 to ptr
  %rgep834 = getelementptr i8, ptr %p833, i64 -24
  store i64 %v831, ptr %rgep834, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore127
bb_rcgstore127:
  %v835 = load i64, ptr %slot121, align 8
  %v836 = load i64, ptr %slot120, align 8
  %p837 = inttoptr i64 %v836 to ptr
  store i64 %v835, ptr %p837, align 8, !alias.scope !3, !noalias !4
  %v838 = load i64, ptr %slot12, align 8
  %p839 = inttoptr i64 %v838 to ptr
  store i32 2, ptr %p839, align 4, !alias.scope !3, !noalias !4
  %v840 = load i64, ptr %slot12, align 8
  %p841 = inttoptr i64 %v840 to ptr
  store i32 16, ptr %p841, align 4, !alias.scope !3, !noalias !4
  %v842 = load i64, ptr %slot11, align 8
  %p843 = inttoptr i64 %v842 to ptr
  store i32 1, ptr %p843, align 4, !alias.scope !3, !noalias !4
  %v844 = load i64, ptr %slot9, align 8
  %p845 = inttoptr i64 %v844 to ptr
  %ld846 = load i32, ptr %p845, align 4, !alias.scope !3, !noalias !4
  store i32 %ld846, ptr %slot132, align 8
  %v847 = load i32, ptr %slot132, align 8
  %cv848 = zext i32 %v847 to i64
  %cond849 = icmp ne i64 %cv848, 0
  br i1 %cond849, label %bb_rcslotdrop143, label %bb_rcslotdone143
bb_rcslotdrop143:
  %v850 = load i64, ptr %slot9, align 8
  %p851 = inttoptr i64 %v850 to ptr
  store i32 0, ptr %p851, align 4, !alias.scope !3, !noalias !4
  %v852 = load i64, ptr %slot14, align 8
  store i64 %v852, ptr %slot133, align 8
  %v853 = load i64, ptr %slot10, align 8
  %p854 = inttoptr i64 %v853 to ptr
  %ld855 = load i32, ptr %p854, align 4, !alias.scope !3, !noalias !4
  store i32 %ld855, ptr %slot134, align 8
  %v856 = load i32, ptr %slot134, align 8
  %op857 = and i32 %v856, 28
  store i32 %op857, ptr %slot135, align 8
  %v858 = load i32, ptr %slot135, align 8
  %cv859 = zext i32 %v858 to i64
  %cond860 = icmp ne i64 %cv859, 0
  br i1 %cond860, label %bb_rcslotrole143, label %bb_rcslotowner143
bb_rcslotrole143:
  %v861 = load i64, ptr %slot24, align 8
  store i64 %v861, ptr %slot136, align 8
  %v862 = load i64, ptr %slot136, align 8
  %v863 = load i64, ptr %slot133, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v862, i64 %v863) nomerge, !dbg !116
  br label %bb_rcslotdone143
bb_rcslotowner143:
  %v864 = load i64, ptr %slot24, align 8
  store i64 %v864, ptr %slot137, align 8
  %v865 = load i64, ptr %slot137, align 8
  %v866 = load i64, ptr %slot133, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v865, i64 %v866) nomerge, !dbg !116
  br label %bb_rcslotdone143
bb_rcslotdone143:
  %v867 = load i64, ptr %slot14, align 8
  store i64 %v867, ptr %slot138, align 8
  %v868 = load i64, ptr %slot17, align 8
  store i64 %v868, ptr %slot139, align 8
  %v869 = load i64, ptr %slot139, align 8
  %v870 = load i64, ptr %slot138, align 8
  %p871 = inttoptr i64 %v869 to ptr
  %p872 = inttoptr i64 %v870 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p872, ptr %p871, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v873 = load i64, ptr %slot10, align 8
  %p874 = inttoptr i64 %v873 to ptr
  store i32 2, ptr %p874, align 4, !alias.scope !3, !noalias !4
  %v875 = load i64, ptr %slot12, align 8
  %p876 = inttoptr i64 %v875 to ptr
  %ld877 = load i32, ptr %p876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld877, ptr %slot140, align 8
  %v878 = load i32, ptr %slot140, align 8
  %v879 = load i64, ptr %slot10, align 8
  %p880 = inttoptr i64 %v879 to ptr
  store i32 %v878, ptr %p880, align 4, !alias.scope !3, !noalias !4
  %v881 = load i64, ptr %slot11, align 8
  %p882 = inttoptr i64 %v881 to ptr
  store i32 0, ptr %p882, align 4, !alias.scope !3, !noalias !4
  %v883 = load i64, ptr %slot9, align 8
  %p884 = inttoptr i64 %v883 to ptr
  store i32 1, ptr %p884, align 4, !alias.scope !3, !noalias !4
  %v885 = load i64, ptr %slot138, align 8
  %p886 = inttoptr i64 %v885 to ptr
  %ld887 = load i64, ptr %p886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld887, ptr %slot141, align 8
  %v888 = load i64, ptr %slot141, align 8
  %v889 = load i64, ptr %slot23, align 8
  %p890 = inttoptr i64 %v889 to ptr
  store i64 %v888, ptr %p890, align 8, !alias.scope !3, !noalias !4
  %v891 = load i64, ptr %slot23, align 8
  %p892 = inttoptr i64 %v891 to ptr
  %ld893 = load i64, ptr %p892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld893, ptr %slot142, align 8
  %v894 = load i64, ptr %slot142, align 8
  %p895 = inttoptr i64 %v894 to ptr
  %ld896 = load i64, ptr %p895, align 8, !alias.scope !6, !noalias !7
  store i64 %ld896, ptr %slot143, align 8
  %v897 = load i64, ptr %slot143, align 8
  %v898 = load i64, ptr %slot23, align 8
  %p899 = inttoptr i64 %v898 to ptr
  store i64 %v897, ptr %p899, align 8, !alias.scope !3, !noalias !4
  %v900 = load i64, ptr %slot9, align 8
  %p901 = inttoptr i64 %v900 to ptr
  %ld902 = load i32, ptr %p901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld902, ptr %slot144, align 8
  %v903 = load i32, ptr %slot144, align 8
  %cv904 = zext i32 %v903 to i64
  %cond905 = icmp ne i64 %cv904, 0
  br i1 %cond905, label %bb_rcslotdrop163, label %bb_rcslotdone163
bb_rcslotdrop163:
  %v906 = load i64, ptr %slot9, align 8
  %p907 = inttoptr i64 %v906 to ptr
  store i32 0, ptr %p907, align 4, !alias.scope !3, !noalias !4
  %v908 = load i64, ptr %slot14, align 8
  store i64 %v908, ptr %slot145, align 8
  %v909 = load i64, ptr %slot10, align 8
  %p910 = inttoptr i64 %v909 to ptr
  %ld911 = load i32, ptr %p910, align 4, !alias.scope !3, !noalias !4
  store i32 %ld911, ptr %slot146, align 8
  %v912 = load i32, ptr %slot146, align 8
  %op913 = and i32 %v912, 28
  store i32 %op913, ptr %slot147, align 8
  %v914 = load i32, ptr %slot147, align 8
  %cv915 = zext i32 %v914 to i64
  %cond916 = icmp ne i64 %cv915, 0
  br i1 %cond916, label %bb_rcslotrole163, label %bb_rcslotowner163
bb_rcslotrole163:
  %v917 = load i64, ptr %slot24, align 8
  store i64 %v917, ptr %slot148, align 8
  %v918 = load i64, ptr %slot145, align 8
  %p919 = inttoptr i64 %v918 to ptr
  %ld920 = load i64, ptr %p919, align 8, !alias.scope !3, !noalias !4
  store i64 %ld920, ptr %slot149, align 8
  %v921 = load i64, ptr %slot149, align 8
  %cmp922 = icmp ne i64 %v921, 0
  %cv923 = zext i1 %cmp922 to i32
  store i32 %cv923, ptr %slot150, align 8
  %v924 = load i32, ptr %slot150, align 8
  %cv925 = zext i32 %v924 to i64
  %cond926 = icmp ne i64 %cv925, 0
  br i1 %cond926, label %bb_rcgnn179, label %bb_rcgdone179
bb_rcgnn179:
  %v927 = load i64, ptr %slot149, align 8
  %op928 = sub i64 %v927, 16
  store i64 %op928, ptr %slot151, align 8
  %v929 = load i64, ptr %slot149, align 8
  %p930 = inttoptr i64 %v929 to ptr
  %rgep931 = getelementptr i8, ptr %p930, i64 -16
  %ld932 = load i64, ptr %rgep931, align 8, !alias.scope !9, !noalias !10
  store i64 %ld932, ptr %slot152, align 8
  %v933 = load i64, ptr %slot152, align 8
  %op934 = and i64 %v933, 4611686018427387906
  store i64 %op934, ptr %slot153, align 8
  %v935 = load i64, ptr %slot153, align 8
  %cmp936 = icmp ne i64 %v935, 0
  %cv937 = zext i1 %cmp936 to i32
  store i32 %cv937, ptr %slot154, align 8
  %v938 = load i32, ptr %slot154, align 8
  %cv939 = zext i32 %v938 to i64
  %cond940 = icmp ne i64 %cv939, 0
  br i1 %cond940, label %bb_rcgclear179, label %bb_rcgcounted179
bb_rcgcounted179:
  %v941 = load i64, ptr %slot149, align 8
  %op942 = sub i64 %v941, 24
  store i64 %op942, ptr %slot155, align 8
  %v943 = load i64, ptr %slot149, align 8
  %p944 = inttoptr i64 %v943 to ptr
  %rgep945 = getelementptr i8, ptr %p944, i64 -24
  %ld946 = load i64, ptr %rgep945, align 8, !alias.scope !9, !noalias !10
  store i64 %ld946, ptr %slot156, align 8
  %v947 = load i64, ptr %slot156, align 8
  %op948 = sub i64 %v947, 1
  store i64 %op948, ptr %slot157, align 8
  %v949 = load i64, ptr %slot157, align 8
  %cmp950 = icmp eq i64 %v949, 0
  %cv951 = zext i1 %cmp950 to i32
  store i32 %cv951, ptr %slot158, align 8
  %v952 = load i32, ptr %slot158, align 8
  %cv953 = zext i32 %v952 to i64
  %cond954 = icmp ne i64 %cv953, 0
  br i1 %cond954, label %bb_rcglast179, label %bb_rcgdec179
bb_rcglast179:
  %v955 = load i64, ptr %slot149, align 8
  %op956 = sub i64 %v955, 32
  store i64 %op956, ptr %slot159, align 8
  %v957 = load i64, ptr %slot149, align 8
  %p958 = inttoptr i64 %v957 to ptr
  %rgep959 = getelementptr i8, ptr %p958, i64 -32
  %ld960 = load i64, ptr %rgep959, align 8, !alias.scope !9, !noalias !10
  store i64 %ld960, ptr %slot160, align 8
  %v961 = load i64, ptr %slot160, align 8
  %cmp962 = icmp ne i64 %v961, 0
  %cv963 = zext i1 %cmp962 to i32
  store i32 %cv963, ptr %slot161, align 8
  %v964 = load i32, ptr %slot161, align 8
  %cv965 = zext i32 %v964 to i64
  %cond966 = icmp ne i64 %cv965, 0
  br i1 %cond966, label %bb_rcgdec179, label %bb_rcgslow179
bb_rcgslow179:
  %v967 = load i64, ptr %slot148, align 8
  %v968 = load i64, ptr %slot145, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v967, i64 %v968) nomerge, !dbg !118
  br label %bb_rcgdone179
bb_rcgdec179:
  %v969 = load i64, ptr %slot157, align 8
  %v970 = load i64, ptr %slot149, align 8
  %p971 = inttoptr i64 %v970 to ptr
  %rgep972 = getelementptr i8, ptr %p971, i64 -24
  store i64 %v969, ptr %rgep972, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear179
bb_rcgclear179:
  %v973 = load i64, ptr %slot145, align 8
  %p974 = inttoptr i64 %v973 to ptr
  store i64 0, ptr %p974, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone179
bb_rcgdone179:
  br label %bb_rcslotdone163
bb_rcslotowner163:
  %v975 = load i64, ptr %slot24, align 8
  store i64 %v975, ptr %slot162, align 8
  %v976 = load i64, ptr %slot145, align 8
  %p977 = inttoptr i64 %v976 to ptr
  %ld978 = load i64, ptr %p977, align 8, !alias.scope !3, !noalias !4
  store i64 %ld978, ptr %slot163, align 8
  %v979 = load i64, ptr %slot163, align 8
  %cmp980 = icmp ne i64 %v979, 0
  %cv981 = zext i1 %cmp980 to i32
  store i32 %cv981, ptr %slot164, align 8
  %v982 = load i32, ptr %slot164, align 8
  %cv983 = zext i32 %v982 to i64
  %cond984 = icmp ne i64 %cv983, 0
  br i1 %cond984, label %bb_rcgnn194, label %bb_rcgdone194
bb_rcgnn194:
  %v985 = load i64, ptr %slot163, align 8
  %op986 = sub i64 %v985, 16
  store i64 %op986, ptr %slot165, align 8
  %v987 = load i64, ptr %slot163, align 8
  %p988 = inttoptr i64 %v987 to ptr
  %rgep989 = getelementptr i8, ptr %p988, i64 -16
  %ld990 = load i64, ptr %rgep989, align 8, !alias.scope !9, !noalias !10
  store i64 %ld990, ptr %slot166, align 8
  %v991 = load i64, ptr %slot166, align 8
  %op992 = and i64 %v991, 4611686018427387906
  store i64 %op992, ptr %slot167, align 8
  %v993 = load i64, ptr %slot167, align 8
  %cmp994 = icmp ne i64 %v993, 0
  %cv995 = zext i1 %cmp994 to i32
  store i32 %cv995, ptr %slot168, align 8
  %v996 = load i32, ptr %slot168, align 8
  %cv997 = zext i32 %v996 to i64
  %cond998 = icmp ne i64 %cv997, 0
  br i1 %cond998, label %bb_rcgclear194, label %bb_rcgcounted194
bb_rcgcounted194:
  %v999 = load i64, ptr %slot163, align 8
  %op1000 = sub i64 %v999, 32
  store i64 %op1000, ptr %slot169, align 8
  %v1001 = load i64, ptr %slot163, align 8
  %p1002 = inttoptr i64 %v1001 to ptr
  %rgep1003 = getelementptr i8, ptr %p1002, i64 -32
  %ld1004 = load i64, ptr %rgep1003, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1004, ptr %slot170, align 8
  %v1005 = load i64, ptr %slot170, align 8
  %op1006 = sub i64 %v1005, 1
  store i64 %op1006, ptr %slot171, align 8
  %v1007 = load i64, ptr %slot171, align 8
  %cmp1008 = icmp eq i64 %v1007, 0
  %cv1009 = zext i1 %cmp1008 to i32
  store i32 %cv1009, ptr %slot172, align 8
  %v1010 = load i32, ptr %slot172, align 8
  %cv1011 = zext i32 %v1010 to i64
  %cond1012 = icmp ne i64 %cv1011, 0
  br i1 %cond1012, label %bb_rcglast194, label %bb_rcgdec194
bb_rcglast194:
  %v1013 = load i64, ptr %slot163, align 8
  %op1014 = sub i64 %v1013, 24
  store i64 %op1014, ptr %slot173, align 8
  %v1015 = load i64, ptr %slot163, align 8
  %p1016 = inttoptr i64 %v1015 to ptr
  %rgep1017 = getelementptr i8, ptr %p1016, i64 -24
  %ld1018 = load i64, ptr %rgep1017, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1018, ptr %slot174, align 8
  %v1019 = load i64, ptr %slot174, align 8
  %cmp1020 = icmp ne i64 %v1019, 0
  %cv1021 = zext i1 %cmp1020 to i32
  store i32 %cv1021, ptr %slot175, align 8
  %v1022 = load i32, ptr %slot175, align 8
  %cv1023 = zext i32 %v1022 to i64
  %cond1024 = icmp ne i64 %cv1023, 0
  br i1 %cond1024, label %bb_rcgdec194, label %bb_rcgslow194
bb_rcgslow194:
  %v1025 = load i64, ptr %slot162, align 8
  %v1026 = load i64, ptr %slot145, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1025, i64 %v1026) nomerge, !dbg !118
  br label %bb_rcgdone194
bb_rcgdec194:
  %v1027 = load i64, ptr %slot171, align 8
  %v1028 = load i64, ptr %slot163, align 8
  %p1029 = inttoptr i64 %v1028 to ptr
  %rgep1030 = getelementptr i8, ptr %p1029, i64 -32
  store i64 %v1027, ptr %rgep1030, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear194
bb_rcgclear194:
  %v1031 = load i64, ptr %slot145, align 8
  %p1032 = inttoptr i64 %v1031 to ptr
  store i64 0, ptr %p1032, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone194
bb_rcgdone194:
  br label %bb_rcslotdone163
bb_rcslotdone163:
  %v1033 = load i64, ptr %slot23, align 8
  %p1034 = inttoptr i64 %v1033 to ptr
  %ld1035 = load i64, ptr %p1034, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1035, ptr %slot176, align 8
  %v1036 = load i64, ptr %slot22, align 8
  %p1037 = inttoptr i64 %v1036 to ptr
  %ld1038 = load i64, ptr %p1037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1038, ptr %slot177, align 8
  %v1039 = load i64, ptr %slot177, align 8
  %v1040 = load i64, ptr %slot176, align 8
  %cmp1041 = icmp sge i64 %v1039, %v1040
  %cv1042 = zext i1 %cmp1041 to i64
  store i64 %cv1042, ptr %slot178, align 8
  %v1043 = load i64, ptr %slot178, align 8
  %v1044 = load i64, ptr %slot22, align 8
  %p1045 = inttoptr i64 %v1044 to ptr
  store i64 %v1043, ptr %p1045, align 8, !alias.scope !3, !noalias !4
  br label %bb_i9
bb_i9:
  %v1046 = load i64, ptr %slot22, align 8
  %p1047 = inttoptr i64 %v1046 to ptr
  %ld1048 = load i64, ptr %p1047, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1048, ptr %slot179, align 8
  %v1049 = load i64, ptr %slot179, align 8
  %cond1050 = icmp ne i64 %v1049, 0
  br i1 %cond1050, label %bb_next202, label %bb_i12
bb_next202:
  %v1051 = load i64, ptr %slot22, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  store i64 1, ptr %p1052, align 8, !alias.scope !3, !noalias !4
  br label %bb_i20
bb_i12:
  %v1053 = load i64, ptr %slot18, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  %ld1055 = load i64, ptr %p1054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1055, ptr %slot180, align 8
  %v1056 = load i64, ptr %slot180, align 8
  %v1057 = load i64, ptr %slot22, align 8
  %p1058 = inttoptr i64 %v1057 to ptr
  store i64 %v1056, ptr %p1058, align 8, !alias.scope !3, !noalias !4
  %v1059 = load i64, ptr %slot22, align 8
  %p1060 = inttoptr i64 %v1059 to ptr
  %ld1061 = load i64, ptr %p1060, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1061, ptr %slot181, align 8
  %v1062 = load i64, ptr %slot181, align 8
  %op1063 = add i64 %v1062, 0
  store i64 %op1063, ptr %slot182, align 8
  %v1064 = load i64, ptr %slot182, align 8
  %p1065 = inttoptr i64 %v1064 to ptr
  %ld1066 = load i64, ptr %p1065, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1066, ptr %slot183, align 8
  %v1067 = load i64, ptr %slot183, align 8
  %v1068 = load i64, ptr %slot22, align 8
  %p1069 = inttoptr i64 %v1068 to ptr
  store i64 %v1067, ptr %p1069, align 8, !alias.scope !3, !noalias !4
  %v1070 = load i64, ptr %slot22, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  %ld1072 = load i64, ptr %p1071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1072, ptr %slot184, align 8
  %v1073 = load i64, ptr %slot184, align 8
  %v1074 = load i64, ptr %slot15, align 8
  %p1075 = inttoptr i64 %v1074 to ptr
  store i64 %v1073, ptr %p1075, align 8, !alias.scope !3, !noalias !4
  %v1076 = load i64, ptr %slot15, align 8
  store i64 %v1076, ptr %slot185, align 8
  %v1077 = load i64, ptr %slot17, align 8
  store i64 %v1077, ptr %slot186, align 8
  %v1078 = load i64, ptr %slot185, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  %ld1080 = load i64, ptr %p1079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1080, ptr %slot187, align 8
  %v1081 = load i64, ptr %slot187, align 8
  %cmp1082 = icmp ne i64 %v1081, 0
  %cv1083 = zext i1 %cmp1082 to i32
  store i32 %cv1083, ptr %slot188, align 8
  %v1084 = load i32, ptr %slot188, align 8
  %cv1085 = zext i32 %v1084 to i64
  %cond1086 = icmp ne i64 %cv1085, 0
  br i1 %cond1086, label %bb_rcgnn210, label %bb_rcgstore210
bb_rcgnn210:
  %v1087 = load i64, ptr %slot187, align 8
  %op1088 = sub i64 %v1087, 16
  store i64 %op1088, ptr %slot189, align 8
  %v1089 = load i64, ptr %slot187, align 8
  %p1090 = inttoptr i64 %v1089 to ptr
  %rgep1091 = getelementptr i8, ptr %p1090, i64 -16
  %ld1092 = load i64, ptr %rgep1091, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1092, ptr %slot190, align 8
  %v1093 = load i64, ptr %slot190, align 8
  %op1094 = and i64 %v1093, 4611686018427387906
  store i64 %op1094, ptr %slot191, align 8
  %v1095 = load i64, ptr %slot191, align 8
  %cmp1096 = icmp ne i64 %v1095, 0
  %cv1097 = zext i1 %cmp1096 to i32
  store i32 %cv1097, ptr %slot192, align 8
  %v1098 = load i32, ptr %slot192, align 8
  %cv1099 = zext i32 %v1098 to i64
  %cond1100 = icmp ne i64 %cv1099, 0
  br i1 %cond1100, label %bb_rcgstore210, label %bb_rcginc210
bb_rcginc210:
  %v1101 = load i64, ptr %slot187, align 8
  %op1102 = sub i64 %v1101, 24
  store i64 %op1102, ptr %slot193, align 8
  %v1103 = load i64, ptr %slot187, align 8
  %p1104 = inttoptr i64 %v1103 to ptr
  %rgep1105 = getelementptr i8, ptr %p1104, i64 -24
  %ld1106 = load i64, ptr %rgep1105, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1106, ptr %slot194, align 8
  %v1107 = load i64, ptr %slot194, align 8
  %op1108 = add i64 %v1107, 1
  store i64 %op1108, ptr %slot195, align 8
  %v1109 = load i64, ptr %slot195, align 8
  %cmp1110 = icmp eq i64 %v1109, 0
  %cv1111 = zext i1 %cmp1110 to i32
  store i32 %cv1111, ptr %slot196, align 8
  %v1112 = load i32, ptr %slot196, align 8
  %cv1113 = zext i32 %v1112 to i64
  %cond1114 = icmp ne i64 %cv1113, 0
  br i1 %cond1114, label %bb_rcglimit210, label %bb_rcgcapacity210
bb_rcglimit210:
  %v1115 = load i64, ptr %slot1, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  %call1117 = call i32 @myl_qbe_rc_status(ptr %p1116, i32 2) nomerge, !dbg !120
  store i32 %call1117, ptr %slot197, align 8
  br label %bb_failure
bb_rcgcapacity210:
  %v1118 = load i64, ptr %slot195, align 8
  %v1119 = load i64, ptr %slot187, align 8
  %p1120 = inttoptr i64 %v1119 to ptr
  %rgep1121 = getelementptr i8, ptr %p1120, i64 -24
  store i64 %v1118, ptr %rgep1121, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore210
bb_rcgstore210:
  %v1122 = load i64, ptr %slot187, align 8
  %v1123 = load i64, ptr %slot186, align 8
  %p1124 = inttoptr i64 %v1123 to ptr
  store i64 %v1122, ptr %p1124, align 8, !alias.scope !3, !noalias !4
  %v1125 = load i64, ptr %slot12, align 8
  %p1126 = inttoptr i64 %v1125 to ptr
  store i32 2, ptr %p1126, align 4, !alias.scope !3, !noalias !4
  %v1127 = load i64, ptr %slot12, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  store i32 16, ptr %p1128, align 4, !alias.scope !3, !noalias !4
  %v1129 = load i64, ptr %slot11, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  store i32 1, ptr %p1130, align 4, !alias.scope !3, !noalias !4
  %v1131 = load i64, ptr %slot7, align 8
  %p1132 = inttoptr i64 %v1131 to ptr
  %ld1133 = load i32, ptr %p1132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1133, ptr %slot198, align 8
  %v1134 = load i32, ptr %slot198, align 8
  %cv1135 = zext i32 %v1134 to i64
  %cond1136 = icmp ne i64 %cv1135, 0
  br i1 %cond1136, label %bb_rcslotdrop226, label %bb_rcslotdone226
bb_rcslotdrop226:
  %v1137 = load i64, ptr %slot7, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  store i32 0, ptr %p1138, align 4, !alias.scope !3, !noalias !4
  %v1139 = load i64, ptr %slot13, align 8
  store i64 %v1139, ptr %slot199, align 8
  %v1140 = load i64, ptr %slot8, align 8
  %p1141 = inttoptr i64 %v1140 to ptr
  %ld1142 = load i32, ptr %p1141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1142, ptr %slot200, align 8
  %v1143 = load i32, ptr %slot200, align 8
  %op1144 = and i32 %v1143, 28
  store i32 %op1144, ptr %slot201, align 8
  %v1145 = load i32, ptr %slot201, align 8
  %cv1146 = zext i32 %v1145 to i64
  %cond1147 = icmp ne i64 %cv1146, 0
  br i1 %cond1147, label %bb_rcslotrole226, label %bb_rcslotowner226
bb_rcslotrole226:
  %v1148 = load i64, ptr %slot24, align 8
  store i64 %v1148, ptr %slot202, align 8
  %v1149 = load i64, ptr %slot202, align 8
  %v1150 = load i64, ptr %slot199, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1149, i64 %v1150) nomerge, !dbg !120
  br label %bb_rcslotdone226
bb_rcslotowner226:
  %v1151 = load i64, ptr %slot24, align 8
  store i64 %v1151, ptr %slot203, align 8
  %v1152 = load i64, ptr %slot203, align 8
  %v1153 = load i64, ptr %slot199, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v1152, i64 %v1153) nomerge, !dbg !120
  br label %bb_rcslotdone226
bb_rcslotdone226:
  %v1154 = load i64, ptr %slot13, align 8
  store i64 %v1154, ptr %slot204, align 8
  %v1155 = load i64, ptr %slot17, align 8
  store i64 %v1155, ptr %slot205, align 8
  %v1156 = load i64, ptr %slot205, align 8
  %v1157 = load i64, ptr %slot204, align 8
  %p1158 = inttoptr i64 %v1156 to ptr
  %p1159 = inttoptr i64 %v1157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1159, ptr %p1158, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1160 = load i64, ptr %slot8, align 8
  %p1161 = inttoptr i64 %v1160 to ptr
  store i32 2, ptr %p1161, align 4, !alias.scope !3, !noalias !4
  %v1162 = load i64, ptr %slot12, align 8
  %p1163 = inttoptr i64 %v1162 to ptr
  %ld1164 = load i32, ptr %p1163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1164, ptr %slot206, align 8
  %v1165 = load i32, ptr %slot206, align 8
  %v1166 = load i64, ptr %slot8, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  store i32 %v1165, ptr %p1167, align 4, !alias.scope !3, !noalias !4
  %v1168 = load i64, ptr %slot11, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  store i32 0, ptr %p1169, align 4, !alias.scope !3, !noalias !4
  %v1170 = load i64, ptr %slot7, align 8
  %p1171 = inttoptr i64 %v1170 to ptr
  store i32 1, ptr %p1171, align 4, !alias.scope !3, !noalias !4
  %v1172 = load i64, ptr %slot204, align 8
  %p1173 = inttoptr i64 %v1172 to ptr
  %ld1174 = load i64, ptr %p1173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1174, ptr %slot207, align 8
  %v1175 = load i64, ptr %slot207, align 8
  %v1176 = load i64, ptr %slot22, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i64 %v1175, ptr %p1177, align 8, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot18, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  %ld1180 = load i64, ptr %p1179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1180, ptr %slot208, align 8
  %v1181 = load i64, ptr %slot208, align 8
  %v1182 = load i64, ptr %slot23, align 8
  %p1183 = inttoptr i64 %v1182 to ptr
  store i64 %v1181, ptr %p1183, align 8, !alias.scope !3, !noalias !4
  %v1184 = load i64, ptr %slot23, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  %ld1186 = load i64, ptr %p1185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1186, ptr %slot209, align 8
  %v1187 = load i64, ptr %slot209, align 8
  %op1188 = add i64 %v1187, 16
  store i64 %op1188, ptr %slot210, align 8
  %v1189 = load i64, ptr %slot210, align 8
  %p1190 = inttoptr i64 %v1189 to ptr
  %ld1191 = load i64, ptr %p1190, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1191, ptr %slot211, align 8
  %v1192 = load i64, ptr %slot211, align 8
  %v1193 = load i64, ptr %slot23, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i64 %v1192, ptr %p1194, align 8, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot9, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  %ld1197 = load i32, ptr %p1196, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1197, ptr %slot212, align 8
  %v1198 = load i32, ptr %slot212, align 8
  %cv1199 = zext i32 %v1198 to i64
  %cond1200 = icmp ne i64 %cv1199, 0
  br i1 %cond1200, label %bb_rcslotdrop248, label %bb_rcslotdone248
bb_rcslotdrop248:
  %v1201 = load i64, ptr %slot9, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  store i32 0, ptr %p1202, align 4, !alias.scope !3, !noalias !4
  %v1203 = load i64, ptr %slot14, align 8
  store i64 %v1203, ptr %slot213, align 8
  %v1204 = load i64, ptr %slot10, align 8
  %p1205 = inttoptr i64 %v1204 to ptr
  %ld1206 = load i32, ptr %p1205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1206, ptr %slot214, align 8
  %v1207 = load i32, ptr %slot214, align 8
  %op1208 = and i32 %v1207, 28
  store i32 %op1208, ptr %slot215, align 8
  %v1209 = load i32, ptr %slot215, align 8
  %cv1210 = zext i32 %v1209 to i64
  %cond1211 = icmp ne i64 %cv1210, 0
  br i1 %cond1211, label %bb_rcslotrole248, label %bb_rcslotowner248
bb_rcslotrole248:
  %v1212 = load i64, ptr %slot24, align 8
  store i64 %v1212, ptr %slot216, align 8
  %v1213 = load i64, ptr %slot216, align 8
  %v1214 = load i64, ptr %slot213, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1213, i64 %v1214) nomerge, !dbg !122
  br label %bb_rcslotdone248
bb_rcslotowner248:
  %v1215 = load i64, ptr %slot24, align 8
  store i64 %v1215, ptr %slot217, align 8
  %v1216 = load i64, ptr %slot217, align 8
  %v1217 = load i64, ptr %slot213, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v1216, i64 %v1217) nomerge, !dbg !122
  br label %bb_rcslotdone248
bb_rcslotdone248:
  %v1218 = load i64, ptr %slot22, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  %ld1220 = load i64, ptr %p1219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1220, ptr %slot218, align 8
  %v1221 = load i64, ptr %slot23, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  %ld1223 = load i64, ptr %p1222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1223, ptr %slot219, align 8
  %v1224 = load i64, ptr %slot218, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  %ld1226 = load i64, ptr %p1225, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1226, ptr %slot220, align 8
  %v1227 = load i64, ptr %slot219, align 8
  %op1228 = ashr i64 %v1227, 63
  store i64 %op1228, ptr %slot221, align 8
  %v1229 = load i64, ptr %slot221, align 8
  %v1230 = load i64, ptr %slot220, align 8
  %op1231 = and i64 %v1229, %v1230
  store i64 %op1231, ptr %slot222, align 8
  %v1232 = load i64, ptr %slot219, align 8
  %v1233 = load i64, ptr %slot222, align 8
  %op1234 = add i64 %v1232, %v1233
  store i64 %op1234, ptr %slot223, align 8
  %v1235 = load i64, ptr %slot223, align 8
  %v1236 = load i64, ptr %slot220, align 8
  %cmp1237 = icmp ult i64 %v1235, %v1236
  %cv1238 = zext i1 %cmp1237 to i64
  store i64 %cv1238, ptr %slot224, align 8
  %v1239 = load i64, ptr %slot224, align 8
  %cond1240 = icmp ne i64 %v1239, 0
  br i1 %cond1240, label %bb_success263, label %bb_failed263
bb_failed263:
  %v1241 = load i64, ptr %slot1, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %v1243 = load i64, ptr %slot219, align 8
  %v1244 = load i64, ptr %slot220, align 8
  call void @myl_qbe_fail_index_bounds(ptr %p1242, i64 %v1243, i64 %v1244) nomerge, !dbg !124
  unreachable
bb_success263:
  %v1245 = load i64, ptr %slot218, align 8
  %op1246 = add i64 %v1245, 32
  store i64 %op1246, ptr %slot225, align 8
  %v1247 = load i64, ptr %slot225, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  %ld1249 = load i64, ptr %p1248, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1249, ptr %slot226, align 8
  %v1250 = load i64, ptr %slot226, align 8
  %v1251 = load i64, ptr %slot223, align 8
  %op1252 = add i64 %v1250, %v1251
  store i64 %op1252, ptr %slot227, align 8
  %v1253 = load i64, ptr %slot226, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  %v1255 = load i64, ptr %slot223, align 8
  %egep1256 = getelementptr i8, ptr %p1254, i64 %v1255
  %ld1257 = load i8, ptr %egep1256, align 1, !alias.scope !12, !noalias !13
  %ext1258 = zext i8 %ld1257 to i64
  store i64 %ext1258, ptr %slot228, align 8
  %v1259 = load i64, ptr %slot228, align 8
  %v1260 = load i64, ptr %slot22, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  store i64 %v1259, ptr %p1261, align 8, !alias.scope !3, !noalias !4
  %v1262 = load i64, ptr %slot7, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %ld1264 = load i32, ptr %p1263, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1264, ptr %slot229, align 8
  %v1265 = load i32, ptr %slot229, align 8
  %cv1266 = zext i32 %v1265 to i64
  %cond1267 = icmp ne i64 %cv1266, 0
  br i1 %cond1267, label %bb_rcslotdrop271, label %bb_rcslotdone271
bb_rcslotdrop271:
  %v1268 = load i64, ptr %slot7, align 8
  %p1269 = inttoptr i64 %v1268 to ptr
  store i32 0, ptr %p1269, align 4, !alias.scope !3, !noalias !4
  %v1270 = load i64, ptr %slot13, align 8
  store i64 %v1270, ptr %slot230, align 8
  %v1271 = load i64, ptr %slot8, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  %ld1273 = load i32, ptr %p1272, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1273, ptr %slot231, align 8
  %v1274 = load i32, ptr %slot231, align 8
  %op1275 = and i32 %v1274, 28
  store i32 %op1275, ptr %slot232, align 8
  %v1276 = load i32, ptr %slot232, align 8
  %cv1277 = zext i32 %v1276 to i64
  %cond1278 = icmp ne i64 %cv1277, 0
  br i1 %cond1278, label %bb_rcslotrole271, label %bb_rcslotowner271
bb_rcslotrole271:
  %v1279 = load i64, ptr %slot24, align 8
  store i64 %v1279, ptr %slot233, align 8
  %v1280 = load i64, ptr %slot230, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  %ld1282 = load i64, ptr %p1281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1282, ptr %slot234, align 8
  %v1283 = load i64, ptr %slot234, align 8
  %cmp1284 = icmp ne i64 %v1283, 0
  %cv1285 = zext i1 %cmp1284 to i32
  store i32 %cv1285, ptr %slot235, align 8
  %v1286 = load i32, ptr %slot235, align 8
  %cv1287 = zext i32 %v1286 to i64
  %cond1288 = icmp ne i64 %cv1287, 0
  br i1 %cond1288, label %bb_rcgnn287, label %bb_rcgdone287
bb_rcgnn287:
  %v1289 = load i64, ptr %slot234, align 8
  %op1290 = sub i64 %v1289, 16
  store i64 %op1290, ptr %slot236, align 8
  %v1291 = load i64, ptr %slot234, align 8
  %p1292 = inttoptr i64 %v1291 to ptr
  %rgep1293 = getelementptr i8, ptr %p1292, i64 -16
  %ld1294 = load i64, ptr %rgep1293, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1294, ptr %slot237, align 8
  %v1295 = load i64, ptr %slot237, align 8
  %op1296 = and i64 %v1295, 4611686018427387906
  store i64 %op1296, ptr %slot238, align 8
  %v1297 = load i64, ptr %slot238, align 8
  %cmp1298 = icmp ne i64 %v1297, 0
  %cv1299 = zext i1 %cmp1298 to i32
  store i32 %cv1299, ptr %slot239, align 8
  %v1300 = load i32, ptr %slot239, align 8
  %cv1301 = zext i32 %v1300 to i64
  %cond1302 = icmp ne i64 %cv1301, 0
  br i1 %cond1302, label %bb_rcgclear287, label %bb_rcgcounted287
bb_rcgcounted287:
  %v1303 = load i64, ptr %slot234, align 8
  %op1304 = sub i64 %v1303, 24
  store i64 %op1304, ptr %slot240, align 8
  %v1305 = load i64, ptr %slot234, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %rgep1307 = getelementptr i8, ptr %p1306, i64 -24
  %ld1308 = load i64, ptr %rgep1307, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1308, ptr %slot241, align 8
  %v1309 = load i64, ptr %slot241, align 8
  %op1310 = sub i64 %v1309, 1
  store i64 %op1310, ptr %slot242, align 8
  %v1311 = load i64, ptr %slot242, align 8
  %cmp1312 = icmp eq i64 %v1311, 0
  %cv1313 = zext i1 %cmp1312 to i32
  store i32 %cv1313, ptr %slot243, align 8
  %v1314 = load i32, ptr %slot243, align 8
  %cv1315 = zext i32 %v1314 to i64
  %cond1316 = icmp ne i64 %cv1315, 0
  br i1 %cond1316, label %bb_rcglast287, label %bb_rcgdec287
bb_rcglast287:
  %v1317 = load i64, ptr %slot234, align 8
  %op1318 = sub i64 %v1317, 32
  store i64 %op1318, ptr %slot244, align 8
  %v1319 = load i64, ptr %slot234, align 8
  %p1320 = inttoptr i64 %v1319 to ptr
  %rgep1321 = getelementptr i8, ptr %p1320, i64 -32
  %ld1322 = load i64, ptr %rgep1321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1322, ptr %slot245, align 8
  %v1323 = load i64, ptr %slot245, align 8
  %cmp1324 = icmp ne i64 %v1323, 0
  %cv1325 = zext i1 %cmp1324 to i32
  store i32 %cv1325, ptr %slot246, align 8
  %v1326 = load i32, ptr %slot246, align 8
  %cv1327 = zext i32 %v1326 to i64
  %cond1328 = icmp ne i64 %cv1327, 0
  br i1 %cond1328, label %bb_rcgdec287, label %bb_rcgslow287
bb_rcgslow287:
  %v1329 = load i64, ptr %slot233, align 8
  %v1330 = load i64, ptr %slot230, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1329, i64 %v1330) nomerge, !dbg !124
  br label %bb_rcgdone287
bb_rcgdec287:
  %v1331 = load i64, ptr %slot242, align 8
  %v1332 = load i64, ptr %slot234, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  %rgep1334 = getelementptr i8, ptr %p1333, i64 -24
  store i64 %v1331, ptr %rgep1334, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear287
bb_rcgclear287:
  %v1335 = load i64, ptr %slot230, align 8
  %p1336 = inttoptr i64 %v1335 to ptr
  store i64 0, ptr %p1336, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone287
bb_rcgdone287:
  br label %bb_rcslotdone271
bb_rcslotowner271:
  %v1337 = load i64, ptr %slot24, align 8
  store i64 %v1337, ptr %slot247, align 8
  %v1338 = load i64, ptr %slot230, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  %ld1340 = load i64, ptr %p1339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1340, ptr %slot248, align 8
  %v1341 = load i64, ptr %slot248, align 8
  %cmp1342 = icmp ne i64 %v1341, 0
  %cv1343 = zext i1 %cmp1342 to i32
  store i32 %cv1343, ptr %slot249, align 8
  %v1344 = load i32, ptr %slot249, align 8
  %cv1345 = zext i32 %v1344 to i64
  %cond1346 = icmp ne i64 %cv1345, 0
  br i1 %cond1346, label %bb_rcgnn302, label %bb_rcgdone302
bb_rcgnn302:
  %v1347 = load i64, ptr %slot248, align 8
  %op1348 = sub i64 %v1347, 16
  store i64 %op1348, ptr %slot250, align 8
  %v1349 = load i64, ptr %slot248, align 8
  %p1350 = inttoptr i64 %v1349 to ptr
  %rgep1351 = getelementptr i8, ptr %p1350, i64 -16
  %ld1352 = load i64, ptr %rgep1351, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1352, ptr %slot251, align 8
  %v1353 = load i64, ptr %slot251, align 8
  %op1354 = and i64 %v1353, 4611686018427387906
  store i64 %op1354, ptr %slot252, align 8
  %v1355 = load i64, ptr %slot252, align 8
  %cmp1356 = icmp ne i64 %v1355, 0
  %cv1357 = zext i1 %cmp1356 to i32
  store i32 %cv1357, ptr %slot253, align 8
  %v1358 = load i32, ptr %slot253, align 8
  %cv1359 = zext i32 %v1358 to i64
  %cond1360 = icmp ne i64 %cv1359, 0
  br i1 %cond1360, label %bb_rcgclear302, label %bb_rcgcounted302
bb_rcgcounted302:
  %v1361 = load i64, ptr %slot248, align 8
  %op1362 = sub i64 %v1361, 32
  store i64 %op1362, ptr %slot254, align 8
  %v1363 = load i64, ptr %slot248, align 8
  %p1364 = inttoptr i64 %v1363 to ptr
  %rgep1365 = getelementptr i8, ptr %p1364, i64 -32
  %ld1366 = load i64, ptr %rgep1365, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1366, ptr %slot255, align 8
  %v1367 = load i64, ptr %slot255, align 8
  %op1368 = sub i64 %v1367, 1
  store i64 %op1368, ptr %slot256, align 8
  %v1369 = load i64, ptr %slot256, align 8
  %cmp1370 = icmp eq i64 %v1369, 0
  %cv1371 = zext i1 %cmp1370 to i32
  store i32 %cv1371, ptr %slot257, align 8
  %v1372 = load i32, ptr %slot257, align 8
  %cv1373 = zext i32 %v1372 to i64
  %cond1374 = icmp ne i64 %cv1373, 0
  br i1 %cond1374, label %bb_rcglast302, label %bb_rcgdec302
bb_rcglast302:
  %v1375 = load i64, ptr %slot248, align 8
  %op1376 = sub i64 %v1375, 24
  store i64 %op1376, ptr %slot258, align 8
  %v1377 = load i64, ptr %slot248, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  %rgep1379 = getelementptr i8, ptr %p1378, i64 -24
  %ld1380 = load i64, ptr %rgep1379, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1380, ptr %slot259, align 8
  %v1381 = load i64, ptr %slot259, align 8
  %cmp1382 = icmp ne i64 %v1381, 0
  %cv1383 = zext i1 %cmp1382 to i32
  store i32 %cv1383, ptr %slot260, align 8
  %v1384 = load i32, ptr %slot260, align 8
  %cv1385 = zext i32 %v1384 to i64
  %cond1386 = icmp ne i64 %cv1385, 0
  br i1 %cond1386, label %bb_rcgdec302, label %bb_rcgslow302
bb_rcgslow302:
  %v1387 = load i64, ptr %slot247, align 8
  %v1388 = load i64, ptr %slot230, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1387, i64 %v1388) nomerge, !dbg !124
  br label %bb_rcgdone302
bb_rcgdec302:
  %v1389 = load i64, ptr %slot256, align 8
  %v1390 = load i64, ptr %slot248, align 8
  %p1391 = inttoptr i64 %v1390 to ptr
  %rgep1392 = getelementptr i8, ptr %p1391, i64 -32
  store i64 %v1389, ptr %rgep1392, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear302
bb_rcgclear302:
  %v1393 = load i64, ptr %slot230, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  store i64 0, ptr %p1394, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone302
bb_rcgdone302:
  br label %bb_rcslotdone271
bb_rcslotdone271:
  %v1395 = load i64, ptr %slot22, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  %ld1397 = load i64, ptr %p1396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1397, ptr %slot261, align 8
  %v1398 = load i64, ptr %slot261, align 8
  %v1399 = load i64, ptr %slot22, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  store i64 %v1398, ptr %p1400, align 8, !alias.scope !3, !noalias !4
  %v1401 = load i64, ptr %slot19, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  %ld1403 = load i64, ptr %p1402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1403, ptr %slot262, align 8
  %v1404 = load i64, ptr %slot262, align 8
  %v1405 = load i64, ptr %slot23, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  store i64 %v1404, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  %v1407 = load i64, ptr %slot23, align 8
  %p1408 = inttoptr i64 %v1407 to ptr
  %ld1409 = load i64, ptr %p1408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1409, ptr %slot263, align 8
  %v1410 = load i64, ptr %slot22, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  %ld1412 = load i64, ptr %p1411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1412, ptr %slot264, align 8
  %v1413 = load i64, ptr %slot264, align 8
  %v1414 = load i64, ptr %slot263, align 8
  %cmp1415 = icmp ne i64 %v1413, %v1414
  %cv1416 = zext i1 %cmp1415 to i64
  store i64 %cv1416, ptr %slot265, align 8
  %v1417 = load i64, ptr %slot265, align 8
  %v1418 = load i64, ptr %slot22, align 8
  %p1419 = inttoptr i64 %v1418 to ptr
  store i64 %v1417, ptr %p1419, align 8, !alias.scope !3, !noalias !4
  br label %bb_i20
bb_i20:
  %v1420 = load i64, ptr %slot22, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  %ld1422 = load i64, ptr %p1421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1422, ptr %slot266, align 8
  %v1423 = load i64, ptr %slot266, align 8
  %cond1424 = icmp ne i64 %v1423, 0
  br i1 %cond1424, label %bb_next312, label %bb_i23
bb_next312:
  %v1425 = load i64, ptr %slot22, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  store i64 0, ptr %p1426, align 8, !alias.scope !3, !noalias !4
  %v1427 = load i64, ptr %slot22, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  %ld1429 = load i64, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1429, ptr %slot267, align 8
  %v1430 = load i64, ptr %slot7, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  %ld1432 = load i32, ptr %p1431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1432, ptr %slot268, align 8
  %v1433 = load i32, ptr %slot268, align 8
  %cv1434 = zext i32 %v1433 to i64
  %cond1435 = icmp ne i64 %cv1434, 0
  br i1 %cond1435, label %bb_rcslotdrop315, label %bb_rcslotdone315
bb_rcslotdrop315:
  %v1436 = load i64, ptr %slot7, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  store i32 0, ptr %p1437, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone315
bb_rcslotdone315:
  %v1438 = load i64, ptr %slot5, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  %ld1440 = load i32, ptr %p1439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1440, ptr %slot269, align 8
  %v1441 = load i32, ptr %slot269, align 8
  %cv1442 = zext i32 %v1441 to i64
  %cond1443 = icmp ne i64 %cv1442, 0
  br i1 %cond1443, label %bb_rcslotdrop318, label %bb_rcslotdone318
bb_rcslotdrop318:
  %v1444 = load i64, ptr %slot5, align 8
  %p1445 = inttoptr i64 %v1444 to ptr
  store i32 0, ptr %p1445, align 4, !alias.scope !3, !noalias !4
  %v1446 = load i64, ptr %slot21, align 8
  store i64 %v1446, ptr %slot270, align 8
  %v1447 = load i64, ptr %slot6, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  %ld1449 = load i32, ptr %p1448, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1449, ptr %slot271, align 8
  %v1450 = load i32, ptr %slot271, align 8
  %op1451 = and i32 %v1450, 28
  store i32 %op1451, ptr %slot272, align 8
  %v1452 = load i32, ptr %slot272, align 8
  %cv1453 = zext i32 %v1452 to i64
  %cond1454 = icmp ne i64 %cv1453, 0
  br i1 %cond1454, label %bb_rcslotrole318, label %bb_rcslotowner318
bb_rcslotrole318:
  %v1455 = load i64, ptr %slot24, align 8
  store i64 %v1455, ptr %slot273, align 8
  %v1456 = load i64, ptr %slot273, align 8
  %v1457 = load i64, ptr %slot270, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1456, i64 %v1457) nomerge, !dbg !126
  br label %bb_rcslotdone318
bb_rcslotowner318:
  %v1458 = load i64, ptr %slot24, align 8
  store i64 %v1458, ptr %slot274, align 8
  %v1459 = load i64, ptr %slot274, align 8
  %v1460 = load i64, ptr %slot270, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v1459, i64 %v1460) nomerge, !dbg !126
  br label %bb_rcslotdone318
bb_rcslotdone318:
  %v1461 = load i64, ptr %slot267, align 8
  ret i64 %v1461
bb_i23:
  %v1462 = load i64, ptr %slot18, align 8
  %p1463 = inttoptr i64 %v1462 to ptr
  %ld1464 = load i64, ptr %p1463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1464, ptr %slot275, align 8
  %v1465 = load i64, ptr %slot275, align 8
  %v1466 = load i64, ptr %slot22, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  store i64 %v1465, ptr %p1467, align 8, !alias.scope !3, !noalias !4
  %v1468 = load i64, ptr %slot22, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  %ld1470 = load i64, ptr %p1469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1470, ptr %slot276, align 8
  %v1471 = load i64, ptr %slot276, align 8
  %op1472 = add i64 %v1471, 16
  store i64 %op1472, ptr %slot277, align 8
  %v1473 = load i64, ptr %slot277, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  %ld1475 = load i64, ptr %p1474, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1475, ptr %slot278, align 8
  %v1476 = load i64, ptr %slot278, align 8
  %v1477 = load i64, ptr %slot22, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  store i64 %v1476, ptr %p1478, align 8, !alias.scope !3, !noalias !4
  %v1479 = load i64, ptr %slot7, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  %ld1481 = load i32, ptr %p1480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1481, ptr %slot279, align 8
  %v1482 = load i32, ptr %slot279, align 8
  %cv1483 = zext i32 %v1482 to i64
  %cond1484 = icmp ne i64 %cv1483, 0
  br i1 %cond1484, label %bb_rcslotdrop349, label %bb_rcslotdone349
bb_rcslotdrop349:
  %v1485 = load i64, ptr %slot7, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  store i32 0, ptr %p1486, align 4, !alias.scope !3, !noalias !4
  %v1487 = load i64, ptr %slot13, align 8
  store i64 %v1487, ptr %slot280, align 8
  %v1488 = load i64, ptr %slot8, align 8
  %p1489 = inttoptr i64 %v1488 to ptr
  %ld1490 = load i32, ptr %p1489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1490, ptr %slot281, align 8
  %v1491 = load i32, ptr %slot281, align 8
  %op1492 = and i32 %v1491, 28
  store i32 %op1492, ptr %slot282, align 8
  %v1493 = load i32, ptr %slot282, align 8
  %cv1494 = zext i32 %v1493 to i64
  %cond1495 = icmp ne i64 %cv1494, 0
  br i1 %cond1495, label %bb_rcslotrole349, label %bb_rcslotowner349
bb_rcslotrole349:
  %v1496 = load i64, ptr %slot24, align 8
  store i64 %v1496, ptr %slot283, align 8
  %v1497 = load i64, ptr %slot283, align 8
  %v1498 = load i64, ptr %slot280, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1497, i64 %v1498) nomerge, !dbg !128
  br label %bb_rcslotdone349
bb_rcslotowner349:
  %v1499 = load i64, ptr %slot24, align 8
  store i64 %v1499, ptr %slot284, align 8
  %v1500 = load i64, ptr %slot284, align 8
  %v1501 = load i64, ptr %slot280, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v1500, i64 %v1501) nomerge, !dbg !128
  br label %bb_rcslotdone349
bb_rcslotdone349:
  %v1502 = load i64, ptr %slot23, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  store i64 1, ptr %p1503, align 8, !alias.scope !3, !noalias !4
  %v1504 = load i64, ptr %slot23, align 8
  %p1505 = inttoptr i64 %v1504 to ptr
  %ld1506 = load i64, ptr %p1505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1506, ptr %slot285, align 8
  %v1507 = load i64, ptr %slot22, align 8
  %p1508 = inttoptr i64 %v1507 to ptr
  %ld1509 = load i64, ptr %p1508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1509, ptr %slot286, align 8
  %v1510 = load i64, ptr %slot286, align 8
  %v1511 = load i64, ptr %slot285, align 8
  %ovpair1513 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1510, i64 %v1511)
  %op1512 = extractvalue { i64, i1 } %ovpair1513, 0
  %ov1514 = extractvalue { i64, i1 } %ovpair1513, 1
  store i64 %op1512, ptr %slot287, align 8
  %cv1515 = zext i1 %ov1514 to i64
  store i64 %cv1515, ptr %slot288, align 8
  %v1516 = load i64, ptr %slot288, align 8
  %cond1517 = icmp ne i64 %v1516, 0
  br i1 %cond1517, label %bb_overflow358, label %bb_checked358
bb_overflow358:
  %v1518 = load i64, ptr %slot1, align 8
  %p1519 = inttoptr i64 %v1518 to ptr
  %v1520 = load i64, ptr %slot286, align 8
  %v1521 = load i64, ptr %slot285, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1519, i64 0, i64 %v1520, i64 %v1521, i64 64) nomerge, !dbg !130
  unreachable
bb_checked358:
  %v1522 = load i64, ptr %slot287, align 8
  %v1523 = load i64, ptr %slot22, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i64 %v1522, ptr %p1524, align 8, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot22, align 8
  %p1526 = inttoptr i64 %v1525 to ptr
  %ld1527 = load i64, ptr %p1526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1527, ptr %slot289, align 8
  %v1528 = load i64, ptr %slot289, align 8
  %v1529 = load i64, ptr %slot20, align 8
  %p1530 = inttoptr i64 %v1529 to ptr
  store i64 %v1528, ptr %p1530, align 8, !alias.scope !3, !noalias !4
  %v1531 = load i64, ptr %slot18, align 8
  %p1532 = inttoptr i64 %v1531 to ptr
  %ld1533 = load i64, ptr %p1532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1533, ptr %slot290, align 8
  %v1534 = load i64, ptr %slot290, align 8
  %v1535 = load i64, ptr %slot22, align 8
  %p1536 = inttoptr i64 %v1535 to ptr
  store i64 %v1534, ptr %p1536, align 8, !alias.scope !3, !noalias !4
  %v1537 = load i64, ptr %slot18, align 8
  %p1538 = inttoptr i64 %v1537 to ptr
  %ld1539 = load i64, ptr %p1538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1539, ptr %slot291, align 8
  %v1540 = load i64, ptr %slot291, align 8
  %v1541 = load i64, ptr %slot22, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  store i64 %v1540, ptr %p1542, align 8, !alias.scope !3, !noalias !4
  %v1543 = load i64, ptr %slot18, align 8
  %p1544 = inttoptr i64 %v1543 to ptr
  %ld1545 = load i64, ptr %p1544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1545, ptr %slot292, align 8
  %v1546 = load i64, ptr %slot292, align 8
  %v1547 = load i64, ptr %slot22, align 8
  %p1548 = inttoptr i64 %v1547 to ptr
  store i64 %v1546, ptr %p1548, align 8, !alias.scope !3, !noalias !4
  %v1549 = load i64, ptr %slot20, align 8
  %p1550 = inttoptr i64 %v1549 to ptr
  %ld1551 = load i64, ptr %p1550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1551, ptr %slot293, align 8
  %v1552 = load i64, ptr %slot293, align 8
  %v1553 = load i64, ptr %slot23, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  store i64 %v1552, ptr %p1554, align 8, !alias.scope !3, !noalias !4
  %v1555 = load i64, ptr %slot18, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  %ld1557 = load i64, ptr %p1556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1557, ptr %slot294, align 8
  %v1558 = load i64, ptr %slot294, align 8
  %v1559 = load i64, ptr %slot22, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  store i64 %v1558, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  %v1561 = load i64, ptr %slot20, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %ld1563 = load i64, ptr %p1562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1563, ptr %slot295, align 8
  %v1564 = load i64, ptr %slot18, align 8
  %p1565 = inttoptr i64 %v1564 to ptr
  %ld1566 = load i64, ptr %p1565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1566, ptr %slot296, align 8
  %v1567 = load i64, ptr %slot296, align 8
  %op1568 = add i64 %v1567, 16
  store i64 %op1568, ptr %slot297, align 8
  %v1569 = load i64, ptr %slot295, align 8
  %v1570 = load i64, ptr %slot297, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  store i64 %v1569, ptr %p1571, align 8, !alias.scope !4, !noalias !3
  %v1572 = load i64, ptr %slot22, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i64 0, ptr %p1573, align 8, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot22, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i64 1, ptr %p1575, align 8, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot22, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  %ld1578 = load i64, ptr %p1577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1578, ptr %slot298, align 8
  %v1579 = load i64, ptr %slot7, align 8
  %p1580 = inttoptr i64 %v1579 to ptr
  %ld1581 = load i32, ptr %p1580, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1581, ptr %slot299, align 8
  %v1582 = load i32, ptr %slot299, align 8
  %cv1583 = zext i32 %v1582 to i64
  %cond1584 = icmp ne i64 %cv1583, 0
  br i1 %cond1584, label %bb_rcslotdrop372, label %bb_rcslotdone372
bb_rcslotdrop372:
  %v1585 = load i64, ptr %slot7, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  store i32 0, ptr %p1586, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone372
bb_rcslotdone372:
  %v1587 = load i64, ptr %slot5, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  %ld1589 = load i32, ptr %p1588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1589, ptr %slot300, align 8
  %v1590 = load i32, ptr %slot300, align 8
  %cv1591 = zext i32 %v1590 to i64
  %cond1592 = icmp ne i64 %cv1591, 0
  br i1 %cond1592, label %bb_rcslotdrop375, label %bb_rcslotdone375
bb_rcslotdrop375:
  %v1593 = load i64, ptr %slot5, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  store i32 0, ptr %p1594, align 4, !alias.scope !3, !noalias !4
  %v1595 = load i64, ptr %slot21, align 8
  store i64 %v1595, ptr %slot301, align 8
  %v1596 = load i64, ptr %slot6, align 8
  %p1597 = inttoptr i64 %v1596 to ptr
  %ld1598 = load i32, ptr %p1597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1598, ptr %slot302, align 8
  %v1599 = load i32, ptr %slot302, align 8
  %op1600 = and i32 %v1599, 28
  store i32 %op1600, ptr %slot303, align 8
  %v1601 = load i32, ptr %slot303, align 8
  %cv1602 = zext i32 %v1601 to i64
  %cond1603 = icmp ne i64 %cv1602, 0
  br i1 %cond1603, label %bb_rcslotrole375, label %bb_rcslotowner375
bb_rcslotrole375:
  %v1604 = load i64, ptr %slot24, align 8
  store i64 %v1604, ptr %slot304, align 8
  %v1605 = load i64, ptr %slot304, align 8
  %v1606 = load i64, ptr %slot301, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64 %v1605, i64 %v1606) nomerge, !dbg !132
  br label %bb_rcslotdone375
bb_rcslotowner375:
  %v1607 = load i64, ptr %slot24, align 8
  store i64 %v1607, ptr %slot305, align 8
  %v1608 = load i64, ptr %slot305, align 8
  %v1609 = load i64, ptr %slot301, align 8
  call void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64 %v1608, i64 %v1609) nomerge, !dbg !132
  br label %bb_rcslotdone375
bb_rcslotdone375:
  %v1610 = load i64, ptr %slot298, align 8
  ret i64 %v1610
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_drop(i64, i64)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_379d6f721fb3ad00ff3e57ffc26178acf57b32530ce60519d4dde221097cbd7a_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_380b6ec966b03291ae744875bd2c0b406345530a9074ee49b9394aa9212d3a7d", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_380b6ec966b03291ae744875bd2c0b406345530a9074ee49b9394aa9212d3a7d", linkageName: "myl_f_380b6ec966b03291ae744875bd2c0b406345530a9074ee49b9394aa9212d3a7d", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 12417831074717760300, i64 0, !"myl_f_380b6ec966b03291ae744875bd2c0b406345530a9074ee49b9394aa9212d3a7d"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!122 = !DILocation(line: 16, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!124 = !DILocation(line: 17, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!128 = !DILocation(line: 25, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!130 = !DILocation(line: 27, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!132 = !DILocation(line: 40, column: 0, scope: !133)
