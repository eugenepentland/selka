target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_a931877b11ea3aa7de37854bbbc13e6f0160c87ee24000d47530697609fa185a(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i32, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v79 = load i64, ptr %slot1, align 8
  %op80 = add i64 %v79, 32
  store i64 %op80, ptr %slot5, align 8
  %mem81 = alloca i8, i64 8, align 8
  %ptr82 = ptrtoint ptr %mem81 to i64
  store i64 %ptr82, ptr %slot6, align 8
  %mem83 = alloca i8, i64 8, align 8
  %ptr84 = ptrtoint ptr %mem83 to i64
  store i64 %ptr84, ptr %slot7, align 8
  %mem85 = alloca i8, i64 8, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot8, align 8
  %mem87 = alloca i8, i64 8, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot9, align 8
  %mem89 = alloca i8, i64 208, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot10, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot11, align 8
  %mem93 = alloca i8, i64 208, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot12, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot13, align 8
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot14, align 8
  %mem99 = alloca i8, i64 8, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot15, align 8
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot16, align 8
  %mem103 = alloca i8, i64 8, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot17, align 8
  %mem105 = alloca i8, i64 8, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot18, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem107 = alloca i8, i64 8, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot19, align 8
  %v109 = load i64, ptr %slot1, align 8
  %op110 = add i64 %v109, 64
  store i64 %op110, ptr %slot20, align 8
  %v111 = load i64, ptr %slot20, align 8
  %p112 = inttoptr i64 %v111 to ptr
  %ld113 = load i64, ptr %p112, align 8, !alias.scope !4, !noalias !3
  store i64 %ld113, ptr %slot21, align 8
  %stack114 = call ptr @llvm.stacksave()
  %stackaddr115 = ptrtoint ptr %stack114 to i64
  %v116 = load i64, ptr %slot21, align 8
  %cmp117 = icmp ult i64 %stackaddr115, %v116
  %cv118 = zext i1 %cmp117 to i64
  store i64 %cv118, ptr %slot22, align 8
  %v119 = load i64, ptr %slot22, align 8
  %cond120 = icmp ne i64 %v119, 0
  br i1 %cond120, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v121 = load i64, ptr %slot1, align 8
  %p122 = inttoptr i64 %v121 to ptr
  call void @myl_qbe_fail_frame(ptr %p122) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v123 = load i64, ptr %slot2, align 8
  %v124 = load i64, ptr %slot13, align 8
  %p125 = inttoptr i64 %v124 to ptr
  store i64 %v123, ptr %p125, align 8, !alias.scope !3, !noalias !4
  %v126 = load i64, ptr %slot3, align 8
  %v127 = load i64, ptr %slot14, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 %v126, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot4, align 8
  %v130 = load i64, ptr %slot15, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i64 %v129, ptr %p131, align 8, !alias.scope !3, !noalias !4
  %v132 = load i64, ptr %slot1, align 8
  %p133 = inttoptr i64 %v132 to ptr
  %call134 = call ptr @myl_qbe_heap(ptr %p133) nomerge, !dbg !112
  %calladdr135 = ptrtoint ptr %call134 to i64
  store i64 %calladdr135, ptr %slot23, align 8
  %v136 = load i64, ptr %slot6, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i32 0, ptr %p137, align 4, !alias.scope !3, !noalias !4
  %v138 = load i64, ptr %slot7, align 8
  %p139 = inttoptr i64 %v138 to ptr
  store i32 0, ptr %p139, align 4, !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot8, align 8
  %p141 = inttoptr i64 %v140 to ptr
  store i32 0, ptr %p141, align 4, !alias.scope !3, !noalias !4
  %v142 = load i64, ptr %slot9, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i32 0, ptr %p143, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v144 = load i64, ptr %slot14, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld146, ptr %slot24, align 8
  %v147 = load i64, ptr %slot24, align 8
  %v148 = load i64, ptr %slot16, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i64 %v147, ptr %p149, align 8, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot13, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld152, ptr %slot25, align 8
  %v153 = load i64, ptr %slot25, align 8
  %v154 = load i64, ptr %slot17, align 8
  %p155 = inttoptr i64 %v154 to ptr
  store i64 %v153, ptr %p155, align 8, !alias.scope !3, !noalias !4
  %v156 = load i64, ptr %slot15, align 8
  %p157 = inttoptr i64 %v156 to ptr
  %ld158 = load i64, ptr %p157, align 8, !alias.scope !3, !noalias !4
  store i64 %ld158, ptr %slot26, align 8
  %v159 = load i64, ptr %slot26, align 8
  %v160 = load i64, ptr %slot18, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i64 %v159, ptr %p161, align 8, !alias.scope !3, !noalias !4
  %v162 = load i64, ptr %slot17, align 8
  %p163 = inttoptr i64 %v162 to ptr
  %ld164 = load i64, ptr %p163, align 8, !alias.scope !3, !noalias !4
  store i64 %ld164, ptr %slot27, align 8
  %v165 = load i64, ptr %slot18, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld167, ptr %slot28, align 8
  %v168 = load i64, ptr %slot1, align 8
  %v169 = load i64, ptr %slot27, align 8
  %v170 = load i64, ptr %slot28, align 8
  %call171 = call i64 @myl_f_970e0dc3f593c24fdaed2cf51ef1f8fb9885a8d7740bb3e56a50f330a177f25b(i64 %v168, i64 %v169, i64 %v170) nomerge, !dbg !114
  store i64 %call171, ptr %slot29, align 8
  %v172 = load i64, ptr %slot29, align 8
  %v173 = load i64, ptr %slot17, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i64 %v172, ptr %p174, align 8, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot17, align 8
  %p176 = inttoptr i64 %v175 to ptr
  %ld177 = load i64, ptr %p176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld177, ptr %slot30, align 8
  %v178 = load i64, ptr %slot30, align 8
  %v179 = load i64, ptr %slot11, align 8
  %p180 = inttoptr i64 %v179 to ptr
  store i64 %v178, ptr %p180, align 8, !alias.scope !3, !noalias !4
  %v181 = load i64, ptr %slot11, align 8
  store i64 %v181, ptr %slot31, align 8
  %v182 = load i64, ptr %slot12, align 8
  store i64 %v182, ptr %slot32, align 8
  %v183 = load i64, ptr %slot31, align 8
  %v184 = load i64, ptr %slot32, align 8
  %p185 = inttoptr i64 %v183 to ptr
  %p186 = inttoptr i64 %v184 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p186, ptr %p185, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v187 = load i64, ptr %slot9, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i32 2, ptr %p188, align 4, !alias.scope !3, !noalias !4
  %v189 = load i64, ptr %slot8, align 8
  %p190 = inttoptr i64 %v189 to ptr
  store i32 1, ptr %p190, align 4, !alias.scope !3, !noalias !4
  %v191 = load i64, ptr %slot6, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %ld193 = load i32, ptr %p192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld193, ptr %slot33, align 8
  %v194 = load i32, ptr %slot33, align 8
  %cv195 = zext i32 %v194 to i64
  %cond196 = icmp ne i64 %cv195, 0
  br i1 %cond196, label %bb_rcslotdrop22, label %bb_rcslotdone22
bb_rcslotdrop22:
  %v197 = load i64, ptr %slot6, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i32 0, ptr %p198, align 4, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot10, align 8
  store i64 %v199, ptr %slot34, align 8
  %v200 = load i64, ptr %slot7, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i32, ptr %p201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld202, ptr %slot35, align 8
  %v203 = load i32, ptr %slot35, align 8
  %op204 = and i32 %v203, 28
  store i32 %op204, ptr %slot36, align 8
  %v205 = load i32, ptr %slot36, align 8
  %cv206 = zext i32 %v205 to i64
  %cond207 = icmp ne i64 %cv206, 0
  br i1 %cond207, label %bb_rcslotrole22, label %bb_rcslotowner22
bb_rcslotrole22:
  %v208 = load i64, ptr %slot23, align 8
  store i64 %v208, ptr %slot37, align 8
  %v209 = load i64, ptr %slot37, align 8
  %v210 = load i64, ptr %slot34, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v209, i64 %v210) nomerge, !dbg !114
  br label %bb_rcslotdone22
bb_rcslotowner22:
  %v211 = load i64, ptr %slot23, align 8
  store i64 %v211, ptr %slot38, align 8
  %v212 = load i64, ptr %slot38, align 8
  %v213 = load i64, ptr %slot34, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v212, i64 %v213) nomerge, !dbg !114
  br label %bb_rcslotdone22
bb_rcslotdone22:
  %v214 = load i64, ptr %slot10, align 8
  store i64 %v214, ptr %slot39, align 8
  %v215 = load i64, ptr %slot12, align 8
  store i64 %v215, ptr %slot40, align 8
  %v216 = load i64, ptr %slot40, align 8
  %v217 = load i64, ptr %slot39, align 8
  %p218 = inttoptr i64 %v216 to ptr
  %p219 = inttoptr i64 %v217 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p219, ptr %p218, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v220 = load i64, ptr %slot7, align 8
  %p221 = inttoptr i64 %v220 to ptr
  store i32 2, ptr %p221, align 4, !alias.scope !3, !noalias !4
  %v222 = load i64, ptr %slot9, align 8
  %p223 = inttoptr i64 %v222 to ptr
  %ld224 = load i32, ptr %p223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld224, ptr %slot41, align 8
  %v225 = load i32, ptr %slot41, align 8
  %v226 = load i64, ptr %slot7, align 8
  %p227 = inttoptr i64 %v226 to ptr
  store i32 %v225, ptr %p227, align 4, !alias.scope !3, !noalias !4
  %v228 = load i64, ptr %slot8, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i32 0, ptr %p229, align 4, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot6, align 8
  %p231 = inttoptr i64 %v230 to ptr
  store i32 1, ptr %p231, align 4, !alias.scope !3, !noalias !4
  %v232 = load i64, ptr %slot39, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i64, ptr %p233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld234, ptr %slot42, align 8
  %v235 = load i64, ptr %slot42, align 8
  %v236 = load i64, ptr %slot17, align 8
  %p237 = inttoptr i64 %v236 to ptr
  store i64 %v235, ptr %p237, align 8, !alias.scope !3, !noalias !4
  %v238 = load i64, ptr %slot16, align 8
  %p239 = inttoptr i64 %v238 to ptr
  %ld240 = load i64, ptr %p239, align 8, !alias.scope !3, !noalias !4
  store i64 %ld240, ptr %slot43, align 8
  %v241 = load i64, ptr %slot17, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld243, ptr %slot44, align 8
  %v244 = load i64, ptr %slot1, align 8
  %v245 = load i64, ptr %slot43, align 8
  %v246 = load i64, ptr %slot44, align 8
  %call247 = call i64 @myl_f_2e3fe9cac3f7ede77d2e8e30ca7f4e92f54f4ec3d827d9a3c154aad9d70d084a(i64 %v244, i64 %v245, i64 %v246) nomerge, !dbg !116
  store i64 %call247, ptr %slot45, align 8
  %v248 = load i64, ptr %slot45, align 8
  %v249 = load i64, ptr %slot16, align 8
  %p250 = inttoptr i64 %v249 to ptr
  store i64 %v248, ptr %p250, align 8, !alias.scope !3, !noalias !4
  %v251 = load i64, ptr %slot6, align 8
  %p252 = inttoptr i64 %v251 to ptr
  %ld253 = load i32, ptr %p252, align 4, !alias.scope !3, !noalias !4
  store i32 %ld253, ptr %slot46, align 8
  %v254 = load i32, ptr %slot46, align 8
  %cv255 = zext i32 %v254 to i64
  %cond256 = icmp ne i64 %cv255, 0
  br i1 %cond256, label %bb_rcslotdrop52, label %bb_rcslotdone52
bb_rcslotdrop52:
  %v257 = load i64, ptr %slot6, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i32 0, ptr %p258, align 4, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot10, align 8
  store i64 %v259, ptr %slot47, align 8
  %v260 = load i64, ptr %slot7, align 8
  %p261 = inttoptr i64 %v260 to ptr
  %ld262 = load i32, ptr %p261, align 4, !alias.scope !3, !noalias !4
  store i32 %ld262, ptr %slot48, align 8
  %v263 = load i32, ptr %slot48, align 8
  %op264 = and i32 %v263, 28
  store i32 %op264, ptr %slot49, align 8
  %v265 = load i32, ptr %slot49, align 8
  %cv266 = zext i32 %v265 to i64
  %cond267 = icmp ne i64 %cv266, 0
  br i1 %cond267, label %bb_rcslotrole52, label %bb_rcslotowner52
bb_rcslotrole52:
  %v268 = load i64, ptr %slot23, align 8
  store i64 %v268, ptr %slot50, align 8
  %v269 = load i64, ptr %slot47, align 8
  %p270 = inttoptr i64 %v269 to ptr
  %ld271 = load i64, ptr %p270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld271, ptr %slot51, align 8
  %v272 = load i64, ptr %slot51, align 8
  %cmp273 = icmp ne i64 %v272, 0
  %cv274 = zext i1 %cmp273 to i32
  store i32 %cv274, ptr %slot52, align 8
  %v275 = load i32, ptr %slot52, align 8
  %cv276 = zext i32 %v275 to i64
  %cond277 = icmp ne i64 %cv276, 0
  br i1 %cond277, label %bb_rcgnn68, label %bb_rcgdone68
bb_rcgnn68:
  %v278 = load i64, ptr %slot51, align 8
  %op279 = sub i64 %v278, 16
  store i64 %op279, ptr %slot53, align 8
  %v280 = load i64, ptr %slot51, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %rgep282 = getelementptr i8, ptr %p281, i64 -16
  %ld283 = load i64, ptr %rgep282, align 8, !alias.scope !9, !noalias !10
  store i64 %ld283, ptr %slot54, align 8
  %v284 = load i64, ptr %slot54, align 8
  %op285 = and i64 %v284, 4611686018427387906
  store i64 %op285, ptr %slot55, align 8
  %v286 = load i64, ptr %slot55, align 8
  %cmp287 = icmp ne i64 %v286, 0
  %cv288 = zext i1 %cmp287 to i32
  store i32 %cv288, ptr %slot56, align 8
  %v289 = load i32, ptr %slot56, align 8
  %cv290 = zext i32 %v289 to i64
  %cond291 = icmp ne i64 %cv290, 0
  br i1 %cond291, label %bb_rcgclear68, label %bb_rcgcounted68
bb_rcgcounted68:
  %v292 = load i64, ptr %slot51, align 8
  %op293 = sub i64 %v292, 24
  store i64 %op293, ptr %slot57, align 8
  %v294 = load i64, ptr %slot51, align 8
  %p295 = inttoptr i64 %v294 to ptr
  %rgep296 = getelementptr i8, ptr %p295, i64 -24
  %ld297 = load i64, ptr %rgep296, align 8, !alias.scope !9, !noalias !10
  store i64 %ld297, ptr %slot58, align 8
  %v298 = load i64, ptr %slot58, align 8
  %op299 = sub i64 %v298, 1
  store i64 %op299, ptr %slot59, align 8
  %v300 = load i64, ptr %slot59, align 8
  %cmp301 = icmp eq i64 %v300, 0
  %cv302 = zext i1 %cmp301 to i32
  store i32 %cv302, ptr %slot60, align 8
  %v303 = load i32, ptr %slot60, align 8
  %cv304 = zext i32 %v303 to i64
  %cond305 = icmp ne i64 %cv304, 0
  br i1 %cond305, label %bb_rcglast68, label %bb_rcgdec68
bb_rcglast68:
  %v306 = load i64, ptr %slot51, align 8
  %op307 = sub i64 %v306, 32
  store i64 %op307, ptr %slot61, align 8
  %v308 = load i64, ptr %slot51, align 8
  %p309 = inttoptr i64 %v308 to ptr
  %rgep310 = getelementptr i8, ptr %p309, i64 -32
  %ld311 = load i64, ptr %rgep310, align 8, !alias.scope !9, !noalias !10
  store i64 %ld311, ptr %slot62, align 8
  %v312 = load i64, ptr %slot62, align 8
  %cmp313 = icmp ne i64 %v312, 0
  %cv314 = zext i1 %cmp313 to i32
  store i32 %cv314, ptr %slot63, align 8
  %v315 = load i32, ptr %slot63, align 8
  %cv316 = zext i32 %v315 to i64
  %cond317 = icmp ne i64 %cv316, 0
  br i1 %cond317, label %bb_rcgdec68, label %bb_rcgslow68
bb_rcgslow68:
  %v318 = load i64, ptr %slot50, align 8
  %v319 = load i64, ptr %slot47, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v318, i64 %v319) nomerge, !dbg !116
  br label %bb_rcgdone68
bb_rcgdec68:
  %v320 = load i64, ptr %slot59, align 8
  %v321 = load i64, ptr %slot51, align 8
  %p322 = inttoptr i64 %v321 to ptr
  %rgep323 = getelementptr i8, ptr %p322, i64 -24
  store i64 %v320, ptr %rgep323, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear68
bb_rcgclear68:
  %v324 = load i64, ptr %slot47, align 8
  %p325 = inttoptr i64 %v324 to ptr
  store i64 0, ptr %p325, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone68
bb_rcgdone68:
  br label %bb_rcslotdone52
bb_rcslotowner52:
  %v326 = load i64, ptr %slot23, align 8
  store i64 %v326, ptr %slot64, align 8
  %v327 = load i64, ptr %slot47, align 8
  %p328 = inttoptr i64 %v327 to ptr
  %ld329 = load i64, ptr %p328, align 8, !alias.scope !3, !noalias !4
  store i64 %ld329, ptr %slot65, align 8
  %v330 = load i64, ptr %slot65, align 8
  %cmp331 = icmp ne i64 %v330, 0
  %cv332 = zext i1 %cmp331 to i32
  store i32 %cv332, ptr %slot66, align 8
  %v333 = load i32, ptr %slot66, align 8
  %cv334 = zext i32 %v333 to i64
  %cond335 = icmp ne i64 %cv334, 0
  br i1 %cond335, label %bb_rcgnn83, label %bb_rcgdone83
bb_rcgnn83:
  %v336 = load i64, ptr %slot65, align 8
  %op337 = sub i64 %v336, 16
  store i64 %op337, ptr %slot67, align 8
  %v338 = load i64, ptr %slot65, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %rgep340 = getelementptr i8, ptr %p339, i64 -16
  %ld341 = load i64, ptr %rgep340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld341, ptr %slot68, align 8
  %v342 = load i64, ptr %slot68, align 8
  %op343 = and i64 %v342, 4611686018427387906
  store i64 %op343, ptr %slot69, align 8
  %v344 = load i64, ptr %slot69, align 8
  %cmp345 = icmp ne i64 %v344, 0
  %cv346 = zext i1 %cmp345 to i32
  store i32 %cv346, ptr %slot70, align 8
  %v347 = load i32, ptr %slot70, align 8
  %cv348 = zext i32 %v347 to i64
  %cond349 = icmp ne i64 %cv348, 0
  br i1 %cond349, label %bb_rcgclear83, label %bb_rcgcounted83
bb_rcgcounted83:
  %v350 = load i64, ptr %slot65, align 8
  %op351 = sub i64 %v350, 32
  store i64 %op351, ptr %slot71, align 8
  %v352 = load i64, ptr %slot65, align 8
  %p353 = inttoptr i64 %v352 to ptr
  %rgep354 = getelementptr i8, ptr %p353, i64 -32
  %ld355 = load i64, ptr %rgep354, align 8, !alias.scope !9, !noalias !10
  store i64 %ld355, ptr %slot72, align 8
  %v356 = load i64, ptr %slot72, align 8
  %op357 = sub i64 %v356, 1
  store i64 %op357, ptr %slot73, align 8
  %v358 = load i64, ptr %slot73, align 8
  %cmp359 = icmp eq i64 %v358, 0
  %cv360 = zext i1 %cmp359 to i32
  store i32 %cv360, ptr %slot74, align 8
  %v361 = load i32, ptr %slot74, align 8
  %cv362 = zext i32 %v361 to i64
  %cond363 = icmp ne i64 %cv362, 0
  br i1 %cond363, label %bb_rcglast83, label %bb_rcgdec83
bb_rcglast83:
  %v364 = load i64, ptr %slot65, align 8
  %op365 = sub i64 %v364, 24
  store i64 %op365, ptr %slot75, align 8
  %v366 = load i64, ptr %slot65, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %rgep368 = getelementptr i8, ptr %p367, i64 -24
  %ld369 = load i64, ptr %rgep368, align 8, !alias.scope !9, !noalias !10
  store i64 %ld369, ptr %slot76, align 8
  %v370 = load i64, ptr %slot76, align 8
  %cmp371 = icmp ne i64 %v370, 0
  %cv372 = zext i1 %cmp371 to i32
  store i32 %cv372, ptr %slot77, align 8
  %v373 = load i32, ptr %slot77, align 8
  %cv374 = zext i32 %v373 to i64
  %cond375 = icmp ne i64 %cv374, 0
  br i1 %cond375, label %bb_rcgdec83, label %bb_rcgslow83
bb_rcgslow83:
  %v376 = load i64, ptr %slot64, align 8
  %v377 = load i64, ptr %slot47, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v376, i64 %v377) nomerge, !dbg !116
  br label %bb_rcgdone83
bb_rcgdec83:
  %v378 = load i64, ptr %slot73, align 8
  %v379 = load i64, ptr %slot65, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %rgep381 = getelementptr i8, ptr %p380, i64 -32
  store i64 %v378, ptr %rgep381, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear83
bb_rcgclear83:
  %v382 = load i64, ptr %slot47, align 8
  %p383 = inttoptr i64 %v382 to ptr
  store i64 0, ptr %p383, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone83
bb_rcgdone83:
  br label %bb_rcslotdone52
bb_rcslotdone52:
  %v384 = load i64, ptr %slot16, align 8
  %p385 = inttoptr i64 %v384 to ptr
  store i64 0, ptr %p385, align 8, !alias.scope !3, !noalias !4
  %v386 = load i64, ptr %slot16, align 8
  %p387 = inttoptr i64 %v386 to ptr
  %ld388 = load i64, ptr %p387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld388, ptr %slot78, align 8
  %v389 = load i64, ptr %slot78, align 8
  ret i64 %v389
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_2e3fe9cac3f7ede77d2e8e30ca7f4e92f54f4ec3d827d9a3c154aad9d70d084a(i64, i64, i64)
declare i64 @myl_f_970e0dc3f593c24fdaed2cf51ef1f8fb9885a8d7740bb3e56a50f330a177f25b(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a931877b11ea3aa7de37854bbbc13e6f0160c87ee24000d47530697609fa185a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a931877b11ea3aa7de37854bbbc13e6f0160c87ee24000d47530697609fa185a", linkageName: "myl_f_a931877b11ea3aa7de37854bbbc13e6f0160c87ee24000d47530697609fa185a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11193476199721228887, i64 0, !"myl_f_a931877b11ea3aa7de37854bbbc13e6f0160c87ee24000d47530697609fa185a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
