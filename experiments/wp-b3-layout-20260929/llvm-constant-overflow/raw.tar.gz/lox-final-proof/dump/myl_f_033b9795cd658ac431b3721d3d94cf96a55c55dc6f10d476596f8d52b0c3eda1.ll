target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_033b9795cd658ac431b3721d3d94cf96a55c55dc6f10d476596f8d52b0c3eda1(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v38 = load i64, ptr %slot1, align 8
  %op39 = add i64 %v38, 32
  store i64 %op39, ptr %slot3, align 8
  %mem40 = alloca i8, i64 8, align 8
  %ptr41 = ptrtoint ptr %mem40 to i64
  store i64 %ptr41, ptr %slot4, align 8
  %mem42 = alloca i8, i64 8, align 8
  %ptr43 = ptrtoint ptr %mem42 to i64
  store i64 %ptr43, ptr %slot5, align 8
  %mem44 = alloca i8, i64 8, align 8
  %ptr45 = ptrtoint ptr %mem44 to i64
  store i64 %ptr45, ptr %slot6, align 8
  %mem46 = alloca i8, i64 8, align 8
  %ptr47 = ptrtoint ptr %mem46 to i64
  store i64 %ptr47, ptr %slot7, align 8
  %mem48 = alloca i8, i64 8, align 8
  %ptr49 = ptrtoint ptr %mem48 to i64
  store i64 %ptr49, ptr %slot8, align 8
  %mem50 = alloca i8, i64 8, align 8
  %ptr51 = ptrtoint ptr %mem50 to i64
  store i64 %ptr51, ptr %slot9, align 8
  %v52 = load i64, ptr %slot2, align 8
  %v53 = load i64, ptr %slot4, align 8
  %p54 = inttoptr i64 %v53 to ptr
  store i64 %v52, ptr %p54, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v55 = load i64, ptr %slot8, align 8
  %p56 = inttoptr i64 %v55 to ptr
  store i64 0, ptr %p56, align 8, !alias.scope !3, !noalias !4
  %v57 = load i64, ptr %slot8, align 8
  %p58 = inttoptr i64 %v57 to ptr
  %ld59 = load i64, ptr %p58, align 8, !alias.scope !3, !noalias !4
  store i64 %ld59, ptr %slot10, align 8
  %v60 = load i64, ptr %slot10, align 8
  %v61 = load i64, ptr %slot5, align 8
  %p62 = inttoptr i64 %v61 to ptr
  store i64 %v60, ptr %p62, align 8, !alias.scope !3, !noalias !4
  %v63 = load i64, ptr %slot4, align 8
  %p64 = inttoptr i64 %v63 to ptr
  %ld65 = load i64, ptr %p64, align 8, !alias.scope !3, !noalias !4
  store i64 %ld65, ptr %slot11, align 8
  %v66 = load i64, ptr %slot11, align 8
  %v67 = load i64, ptr %slot8, align 8
  %p68 = inttoptr i64 %v67 to ptr
  store i64 %v66, ptr %p68, align 8, !alias.scope !3, !noalias !4
  %v69 = load i64, ptr %slot4, align 8
  %p70 = inttoptr i64 %v69 to ptr
  %ld71 = load i64, ptr %p70, align 8, !alias.scope !3, !noalias !4
  store i64 %ld71, ptr %slot12, align 8
  %v72 = load i64, ptr %slot12, align 8
  %v73 = load i64, ptr %slot8, align 8
  %p74 = inttoptr i64 %v73 to ptr
  store i64 %v72, ptr %p74, align 8, !alias.scope !3, !noalias !4
  %v75 = load i64, ptr %slot4, align 8
  %p76 = inttoptr i64 %v75 to ptr
  %ld77 = load i64, ptr %p76, align 8, !alias.scope !3, !noalias !4
  store i64 %ld77, ptr %slot13, align 8
  %v78 = load i64, ptr %slot13, align 8
  %v79 = load i64, ptr %slot8, align 8
  %p80 = inttoptr i64 %v79 to ptr
  store i64 %v78, ptr %p80, align 8, !alias.scope !3, !noalias !4
  %v81 = load i64, ptr %slot5, align 8
  %p82 = inttoptr i64 %v81 to ptr
  %ld83 = load i64, ptr %p82, align 8, !alias.scope !3, !noalias !4
  store i64 %ld83, ptr %slot14, align 8
  %v84 = load i64, ptr %slot14, align 8
  %v85 = load i64, ptr %slot9, align 8
  %p86 = inttoptr i64 %v85 to ptr
  store i64 %v84, ptr %p86, align 8, !alias.scope !3, !noalias !4
  %v87 = load i64, ptr %slot4, align 8
  %p88 = inttoptr i64 %v87 to ptr
  %ld89 = load i64, ptr %p88, align 8, !alias.scope !3, !noalias !4
  store i64 %ld89, ptr %slot15, align 8
  %v90 = load i64, ptr %slot15, align 8
  %v91 = load i64, ptr %slot8, align 8
  %p92 = inttoptr i64 %v91 to ptr
  store i64 %v90, ptr %p92, align 8, !alias.scope !3, !noalias !4
  %v93 = load i64, ptr %slot5, align 8
  %p94 = inttoptr i64 %v93 to ptr
  %ld95 = load i64, ptr %p94, align 8, !alias.scope !3, !noalias !4
  store i64 %ld95, ptr %slot16, align 8
  %v96 = load i64, ptr %slot4, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot17, align 8
  %v99 = load i64, ptr %slot17, align 8
  %op100 = add i64 %v99, 128
  store i64 %op100, ptr %slot18, align 8
  %v101 = load i64, ptr %slot16, align 8
  %v102 = load i64, ptr %slot18, align 8
  %p103 = inttoptr i64 %v102 to ptr
  store i64 %v101, ptr %p103, align 8, !alias.scope !4, !noalias !3
  %v104 = load i64, ptr %slot8, align 8
  %p105 = inttoptr i64 %v104 to ptr
  store i64 0, ptr %p105, align 8, !alias.scope !3, !noalias !4
  %v106 = load i64, ptr %slot8, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i64 0, ptr %p107, align 8, !alias.scope !3, !noalias !4
  %v108 = load i64, ptr %slot8, align 8
  %p109 = inttoptr i64 %v108 to ptr
  %ld110 = load i64, ptr %p109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld110, ptr %slot19, align 8
  %v111 = load i64, ptr %slot19, align 8
  %v112 = load i64, ptr %slot6, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 %v111, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot4, align 8
  %p115 = inttoptr i64 %v114 to ptr
  %ld116 = load i64, ptr %p115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld116, ptr %slot20, align 8
  %v117 = load i64, ptr %slot20, align 8
  %v118 = load i64, ptr %slot8, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot4, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %ld122 = load i64, ptr %p121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot21, align 8
  %v123 = load i64, ptr %slot21, align 8
  %v124 = load i64, ptr %slot8, align 8
  %p125 = inttoptr i64 %v124 to ptr
  store i64 %v123, ptr %p125, align 8, !alias.scope !3, !noalias !4
  %v126 = load i64, ptr %slot4, align 8
  %p127 = inttoptr i64 %v126 to ptr
  %ld128 = load i64, ptr %p127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld128, ptr %slot22, align 8
  %v129 = load i64, ptr %slot22, align 8
  %v130 = load i64, ptr %slot8, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i64 %v129, ptr %p131, align 8, !alias.scope !3, !noalias !4
  %v132 = load i64, ptr %slot6, align 8
  %p133 = inttoptr i64 %v132 to ptr
  %ld134 = load i64, ptr %p133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld134, ptr %slot23, align 8
  %v135 = load i64, ptr %slot23, align 8
  %v136 = load i64, ptr %slot9, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i64 %v135, ptr %p137, align 8, !alias.scope !3, !noalias !4
  %v138 = load i64, ptr %slot4, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i64, ptr %p139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot24, align 8
  %v141 = load i64, ptr %slot24, align 8
  %v142 = load i64, ptr %slot8, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i64 %v141, ptr %p143, align 8, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot6, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld146, ptr %slot25, align 8
  %v147 = load i64, ptr %slot4, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot26, align 8
  %v150 = load i64, ptr %slot26, align 8
  %op151 = add i64 %v150, 144
  store i64 %op151, ptr %slot27, align 8
  %v152 = load i64, ptr %slot25, align 8
  %v153 = load i64, ptr %slot27, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 %v152, ptr %p154, align 8, !alias.scope !4, !noalias !3
  %v155 = load i64, ptr %slot8, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i64 0, ptr %p156, align 8, !alias.scope !3, !noalias !4
  %v157 = load i64, ptr %slot8, align 8
  %p158 = inttoptr i64 %v157 to ptr
  store i64 18446744073709551615, ptr %p158, align 8, !alias.scope !3, !noalias !4
  %v159 = load i64, ptr %slot8, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %ld161 = load i64, ptr %p160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld161, ptr %slot28, align 8
  %v162 = load i64, ptr %slot28, align 8
  %v163 = load i64, ptr %slot7, align 8
  %p164 = inttoptr i64 %v163 to ptr
  store i64 %v162, ptr %p164, align 8, !alias.scope !3, !noalias !4
  %v165 = load i64, ptr %slot4, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ld167 = load i64, ptr %p166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld167, ptr %slot29, align 8
  %v168 = load i64, ptr %slot29, align 8
  %v169 = load i64, ptr %slot8, align 8
  %p170 = inttoptr i64 %v169 to ptr
  store i64 %v168, ptr %p170, align 8, !alias.scope !3, !noalias !4
  %v171 = load i64, ptr %slot4, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld173, ptr %slot30, align 8
  %v174 = load i64, ptr %slot30, align 8
  %v175 = load i64, ptr %slot8, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i64 %v174, ptr %p176, align 8, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot4, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot31, align 8
  %v180 = load i64, ptr %slot31, align 8
  %v181 = load i64, ptr %slot8, align 8
  %p182 = inttoptr i64 %v181 to ptr
  store i64 %v180, ptr %p182, align 8, !alias.scope !3, !noalias !4
  %v183 = load i64, ptr %slot7, align 8
  %p184 = inttoptr i64 %v183 to ptr
  %ld185 = load i64, ptr %p184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld185, ptr %slot32, align 8
  %v186 = load i64, ptr %slot32, align 8
  %v187 = load i64, ptr %slot9, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i64 %v186, ptr %p188, align 8, !alias.scope !3, !noalias !4
  %v189 = load i64, ptr %slot4, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %ld191 = load i64, ptr %p190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld191, ptr %slot33, align 8
  %v192 = load i64, ptr %slot33, align 8
  %v193 = load i64, ptr %slot8, align 8
  %p194 = inttoptr i64 %v193 to ptr
  store i64 %v192, ptr %p194, align 8, !alias.scope !3, !noalias !4
  %v195 = load i64, ptr %slot7, align 8
  %p196 = inttoptr i64 %v195 to ptr
  %ld197 = load i64, ptr %p196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld197, ptr %slot34, align 8
  %v198 = load i64, ptr %slot4, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot35, align 8
  %v201 = load i64, ptr %slot35, align 8
  %op202 = add i64 %v201, 152
  store i64 %op202, ptr %slot36, align 8
  %v203 = load i64, ptr %slot34, align 8
  %v204 = load i64, ptr %slot36, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !4, !noalias !3
  %v206 = load i64, ptr %slot8, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 0, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot8, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i64 0, ptr %p209, align 8, !alias.scope !3, !noalias !4
  %v210 = load i64, ptr %slot8, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i64, ptr %p211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld212, ptr %slot37, align 8
  %v213 = load i64, ptr %slot37, align 8
  ret i64 %v213
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_033b9795cd658ac431b3721d3d94cf96a55c55dc6f10d476596f8d52b0c3eda1", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_033b9795cd658ac431b3721d3d94cf96a55c55dc6f10d476596f8d52b0c3eda1", linkageName: "myl_f_033b9795cd658ac431b3721d3d94cf96a55c55dc6f10d476596f8d52b0c3eda1", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3511102572542297228, i64 0, !"myl_f_033b9795cd658ac431b3721d3d94cf96a55c55dc6f10d476596f8d52b0c3eda1"}
