target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_033327c3cc9b9ba3b7a1753abed1536d1ef3ef2614b836b864b5345cb9070eec(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i32, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v267 = load i64, ptr %slot1, align 8
  %op268 = add i64 %v267, 32
  store i64 %op268, ptr %slot5, align 8
  %mem269 = alloca i8, i64 8, align 8
  %ptr270 = ptrtoint ptr %mem269 to i64
  store i64 %ptr270, ptr %slot6, align 8
  %mem271 = alloca i8, i64 8, align 8
  %ptr272 = ptrtoint ptr %mem271 to i64
  store i64 %ptr272, ptr %slot7, align 8
  %mem273 = alloca i8, i64 8, align 8
  %ptr274 = ptrtoint ptr %mem273 to i64
  store i64 %ptr274, ptr %slot8, align 8
  %mem275 = alloca i8, i64 8, align 8
  %ptr276 = ptrtoint ptr %mem275 to i64
  store i64 %ptr276, ptr %slot9, align 8
  %mem277 = alloca i8, i64 8, align 8
  %ptr278 = ptrtoint ptr %mem277 to i64
  store i64 %ptr278, ptr %slot10, align 8
  %mem279 = alloca i8, i64 8, align 8
  %ptr280 = ptrtoint ptr %mem279 to i64
  store i64 %ptr280, ptr %slot11, align 8
  %mem281 = alloca i8, i64 8, align 8
  %ptr282 = ptrtoint ptr %mem281 to i64
  store i64 %ptr282, ptr %slot12, align 8
  %mem283 = alloca i8, i64 208, align 8
  %ptr284 = ptrtoint ptr %mem283 to i64
  store i64 %ptr284, ptr %slot13, align 8
  %mem285 = alloca i8, i64 8, align 8
  %ptr286 = ptrtoint ptr %mem285 to i64
  store i64 %ptr286, ptr %slot14, align 8
  %mem287 = alloca i8, i64 8, align 8
  %ptr288 = ptrtoint ptr %mem287 to i64
  store i64 %ptr288, ptr %slot15, align 8
  %mem289 = alloca i8, i64 208, align 8
  %ptr290 = ptrtoint ptr %mem289 to i64
  store i64 %ptr290, ptr %slot16, align 8
  %mem291 = alloca i8, i64 8, align 8
  %ptr292 = ptrtoint ptr %mem291 to i64
  store i64 %ptr292, ptr %slot17, align 8
  %mem293 = alloca i8, i64 8, align 8
  %ptr294 = ptrtoint ptr %mem293 to i64
  store i64 %ptr294, ptr %slot18, align 8
  %mem295 = alloca i8, i64 8, align 8
  %ptr296 = ptrtoint ptr %mem295 to i64
  store i64 %ptr296, ptr %slot19, align 8
  %mem297 = alloca i8, i64 8, align 8
  %ptr298 = ptrtoint ptr %mem297 to i64
  store i64 %ptr298, ptr %slot20, align 8
  %mem299 = alloca i8, i64 8, align 8
  %ptr300 = ptrtoint ptr %mem299 to i64
  store i64 %ptr300, ptr %slot21, align 8
  %mem301 = alloca i8, i64 8, align 8
  %ptr302 = ptrtoint ptr %mem301 to i64
  store i64 %ptr302, ptr %slot22, align 8
  %mem303 = alloca i8, i64 8, align 8
  %ptr304 = ptrtoint ptr %mem303 to i64
  store i64 %ptr304, ptr %slot23, align 8
  %mem305 = alloca i8, i64 8, align 8
  %ptr306 = ptrtoint ptr %mem305 to i64
  store i64 %ptr306, ptr %slot24, align 8
  %mem307 = alloca i8, i64 208, align 8
  %ptr308 = ptrtoint ptr %mem307 to i64
  store i64 %ptr308, ptr %slot25, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem309 = alloca i8, i64 8, align 8
  %ptr310 = ptrtoint ptr %mem309 to i64
  store i64 %ptr310, ptr %slot26, align 8
  %v311 = load i64, ptr %slot1, align 8
  %op312 = add i64 %v311, 64
  store i64 %op312, ptr %slot27, align 8
  %v313 = load i64, ptr %slot27, align 8
  %p314 = inttoptr i64 %v313 to ptr
  %ld315 = load i64, ptr %p314, align 8, !alias.scope !4, !noalias !3
  store i64 %ld315, ptr %slot28, align 8
  %stack316 = call ptr @llvm.stacksave()
  %stackaddr317 = ptrtoint ptr %stack316 to i64
  %v318 = load i64, ptr %slot28, align 8
  %cmp319 = icmp ult i64 %stackaddr317, %v318
  %cv320 = zext i1 %cmp319 to i64
  store i64 %cv320, ptr %slot29, align 8
  %v321 = load i64, ptr %slot29, align 8
  %cond322 = icmp ne i64 %v321, 0
  br i1 %cond322, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v323 = load i64, ptr %slot1, align 8
  %p324 = inttoptr i64 %v323 to ptr
  call void @myl_qbe_fail_frame(ptr %p324) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v325 = load i64, ptr %slot2, align 8
  %v326 = load i64, ptr %slot17, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i64 %v325, ptr %p327, align 8, !alias.scope !3, !noalias !4
  %v328 = load i64, ptr %slot3, align 8
  %v329 = load i64, ptr %slot18, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i64 %v328, ptr %p330, align 8, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot4, align 8
  %v332 = load i64, ptr %slot19, align 8
  %p333 = inttoptr i64 %v332 to ptr
  store i64 %v331, ptr %p333, align 8, !alias.scope !3, !noalias !4
  %v334 = load i64, ptr %slot1, align 8
  %p335 = inttoptr i64 %v334 to ptr
  %call336 = call ptr @myl_qbe_heap(ptr %p335) nomerge, !dbg !112
  %calladdr337 = ptrtoint ptr %call336 to i64
  store i64 %calladdr337, ptr %slot30, align 8
  %v338 = load i64, ptr %slot6, align 8
  %p339 = inttoptr i64 %v338 to ptr
  store i32 0, ptr %p339, align 4, !alias.scope !3, !noalias !4
  %v340 = load i64, ptr %slot7, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i32 0, ptr %p341, align 4, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot8, align 8
  %p343 = inttoptr i64 %v342 to ptr
  store i32 0, ptr %p343, align 4, !alias.scope !3, !noalias !4
  %v344 = load i64, ptr %slot9, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i32 0, ptr %p345, align 4, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot10, align 8
  %p347 = inttoptr i64 %v346 to ptr
  store i32 0, ptr %p347, align 4, !alias.scope !3, !noalias !4
  %v348 = load i64, ptr %slot11, align 8
  %p349 = inttoptr i64 %v348 to ptr
  store i32 0, ptr %p349, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v350 = load i64, ptr %slot17, align 8
  %p351 = inttoptr i64 %v350 to ptr
  %ld352 = load i64, ptr %p351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld352, ptr %slot31, align 8
  %v353 = load i64, ptr %slot31, align 8
  %v354 = load i64, ptr %slot20, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i64 %v353, ptr %p355, align 8, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot18, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i64, ptr %p357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld358, ptr %slot32, align 8
  %v359 = load i64, ptr %slot32, align 8
  %v360 = load i64, ptr %slot21, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i64 %v359, ptr %p361, align 8, !alias.scope !3, !noalias !4
  %p362 = inttoptr i64 ptrtoint (ptr @myl_lit_ccec7865dc7b502581d71aee3367b2a04dffea764d540fdcda9a17841514ad4f to i64) to ptr
  %ld363 = load i64, ptr %p362, align 8, !alias.scope !4, !noalias !3
  store i64 %ld363, ptr %slot33, align 8
  %v364 = load i64, ptr %slot33, align 8
  %v365 = load i64, ptr %slot22, align 8
  %p366 = inttoptr i64 %v365 to ptr
  store i64 %v364, ptr %p366, align 8, !alias.scope !3, !noalias !4
  %v367 = load i64, ptr %slot22, align 8
  %p368 = inttoptr i64 %v367 to ptr
  %ld369 = load i64, ptr %p368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld369, ptr %slot34, align 8
  %v370 = load i64, ptr %slot34, align 8
  %v371 = load i64, ptr %slot14, align 8
  %p372 = inttoptr i64 %v371 to ptr
  store i64 %v370, ptr %p372, align 8, !alias.scope !3, !noalias !4
  %v373 = load i64, ptr %slot14, align 8
  store i64 %v373, ptr %slot35, align 8
  %v374 = load i64, ptr %slot16, align 8
  store i64 %v374, ptr %slot36, align 8
  %v375 = load i64, ptr %slot35, align 8
  %v376 = load i64, ptr %slot36, align 8
  %p377 = inttoptr i64 %v375 to ptr
  %p378 = inttoptr i64 %v376 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p378, ptr %p377, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot11, align 8
  %p380 = inttoptr i64 %v379 to ptr
  store i32 2, ptr %p380, align 4, !alias.scope !3, !noalias !4
  %v381 = load i64, ptr %slot10, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i32 1, ptr %p382, align 4, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot12, align 8
  store i64 %v383, ptr %slot37, align 8
  %v384 = load i64, ptr %slot16, align 8
  store i64 %v384, ptr %slot38, align 8
  %v385 = load i64, ptr %slot38, align 8
  %v386 = load i64, ptr %slot37, align 8
  %p387 = inttoptr i64 %v385 to ptr
  %p388 = inttoptr i64 %v386 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p388, ptr %p387, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v389 = load i64, ptr %slot7, align 8
  %p390 = inttoptr i64 %v389 to ptr
  store i32 2, ptr %p390, align 4, !alias.scope !3, !noalias !4
  %v391 = load i64, ptr %slot11, align 8
  %p392 = inttoptr i64 %v391 to ptr
  %ld393 = load i32, ptr %p392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld393, ptr %slot39, align 8
  %v394 = load i32, ptr %slot39, align 8
  %v395 = load i64, ptr %slot7, align 8
  %p396 = inttoptr i64 %v395 to ptr
  store i32 %v394, ptr %p396, align 4, !alias.scope !3, !noalias !4
  %v397 = load i64, ptr %slot10, align 8
  %p398 = inttoptr i64 %v397 to ptr
  store i32 0, ptr %p398, align 4, !alias.scope !3, !noalias !4
  %v399 = load i64, ptr %slot6, align 8
  %p400 = inttoptr i64 %v399 to ptr
  store i32 1, ptr %p400, align 4, !alias.scope !3, !noalias !4
  %v401 = load i64, ptr %slot37, align 8
  %p402 = inttoptr i64 %v401 to ptr
  %ld403 = load i64, ptr %p402, align 8, !alias.scope !3, !noalias !4
  store i64 %ld403, ptr %slot40, align 8
  %v404 = load i64, ptr %slot40, align 8
  %v405 = load i64, ptr %slot22, align 8
  %p406 = inttoptr i64 %v405 to ptr
  store i64 %v404, ptr %p406, align 8, !alias.scope !3, !noalias !4
  %v407 = load i64, ptr %slot17, align 8
  %p408 = inttoptr i64 %v407 to ptr
  %ld409 = load i64, ptr %p408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld409, ptr %slot41, align 8
  %v410 = load i64, ptr %slot41, align 8
  %v411 = load i64, ptr %slot25, align 8
  %p412 = inttoptr i64 %v410 to ptr
  %p413 = inttoptr i64 %v411 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p413, ptr %p412, i64 208, i1 false), !alias.scope !10000000
  %v414 = load i64, ptr %slot25, align 8
  %v415 = load i64, ptr %slot23, align 8
  %p416 = inttoptr i64 %v415 to ptr
  store i64 %v414, ptr %p416, align 8, !alias.scope !3, !noalias !4
  %v417 = load i64, ptr %slot19, align 8
  %p418 = inttoptr i64 %v417 to ptr
  %ld419 = load i64, ptr %p418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld419, ptr %slot42, align 8
  %v420 = load i64, ptr %slot42, align 8
  %v421 = load i64, ptr %slot24, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i64 %v420, ptr %p422, align 8, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot23, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot43, align 8
  %v426 = load i64, ptr %slot24, align 8
  %p427 = inttoptr i64 %v426 to ptr
  %ld428 = load i64, ptr %p427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld428, ptr %slot44, align 8
  %v429 = load i64, ptr %slot1, align 8
  %v430 = load i64, ptr %slot43, align 8
  %v431 = load i64, ptr %slot44, align 8
  %call432 = call i64 @myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow(i64 %v429, i64 %v430, i64 %v431) nomerge, !dbg !114
  store i64 %call432, ptr %slot45, align 8
  %v433 = load i64, ptr %slot45, align 8
  %v434 = load i64, ptr %slot23, align 8
  %p435 = inttoptr i64 %v434 to ptr
  store i64 %v433, ptr %p435, align 8, !alias.scope !3, !noalias !4
  %v436 = load i64, ptr %slot23, align 8
  %p437 = inttoptr i64 %v436 to ptr
  %ld438 = load i64, ptr %p437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld438, ptr %slot46, align 8
  %v439 = load i64, ptr %slot46, align 8
  %v440 = load i64, ptr %slot15, align 8
  %p441 = inttoptr i64 %v440 to ptr
  store i64 %v439, ptr %p441, align 8, !alias.scope !3, !noalias !4
  %v442 = load i64, ptr %slot15, align 8
  store i64 %v442, ptr %slot47, align 8
  %v443 = load i64, ptr %slot16, align 8
  store i64 %v443, ptr %slot48, align 8
  %v444 = load i64, ptr %slot47, align 8
  %p445 = inttoptr i64 %v444 to ptr
  %ld446 = load i64, ptr %p445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld446, ptr %slot49, align 8
  %v447 = load i64, ptr %slot49, align 8
  %cmp448 = icmp ne i64 %v447, 0
  %cv449 = zext i1 %cmp448 to i32
  store i32 %cv449, ptr %slot50, align 8
  %v450 = load i32, ptr %slot50, align 8
  %cv451 = zext i32 %v450 to i64
  %cond452 = icmp ne i64 %cv451, 0
  br i1 %cond452, label %bb_rcgnn36, label %bb_rcgstore36
bb_rcgnn36:
  %v453 = load i64, ptr %slot49, align 8
  %op454 = sub i64 %v453, 16
  store i64 %op454, ptr %slot51, align 8
  %v455 = load i64, ptr %slot49, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %rgep457 = getelementptr i8, ptr %p456, i64 -16
  %ld458 = load i64, ptr %rgep457, align 8, !alias.scope !9, !noalias !10
  store i64 %ld458, ptr %slot52, align 8
  %v459 = load i64, ptr %slot52, align 8
  %op460 = and i64 %v459, 4611686018427387906
  store i64 %op460, ptr %slot53, align 8
  %v461 = load i64, ptr %slot53, align 8
  %cmp462 = icmp ne i64 %v461, 0
  %cv463 = zext i1 %cmp462 to i32
  store i32 %cv463, ptr %slot54, align 8
  %v464 = load i32, ptr %slot54, align 8
  %cv465 = zext i32 %v464 to i64
  %cond466 = icmp ne i64 %cv465, 0
  br i1 %cond466, label %bb_rcgstore36, label %bb_rcginc36
bb_rcginc36:
  %v467 = load i64, ptr %slot49, align 8
  %op468 = sub i64 %v467, 24
  store i64 %op468, ptr %slot55, align 8
  %v469 = load i64, ptr %slot49, align 8
  %p470 = inttoptr i64 %v469 to ptr
  %rgep471 = getelementptr i8, ptr %p470, i64 -24
  %ld472 = load i64, ptr %rgep471, align 8, !alias.scope !9, !noalias !10
  store i64 %ld472, ptr %slot56, align 8
  %v473 = load i64, ptr %slot56, align 8
  %op474 = add i64 %v473, 1
  store i64 %op474, ptr %slot57, align 8
  %v475 = load i64, ptr %slot57, align 8
  %cmp476 = icmp eq i64 %v475, 0
  %cv477 = zext i1 %cmp476 to i32
  store i32 %cv477, ptr %slot58, align 8
  %v478 = load i32, ptr %slot58, align 8
  %cv479 = zext i32 %v478 to i64
  %cond480 = icmp ne i64 %cv479, 0
  br i1 %cond480, label %bb_rcglimit36, label %bb_rcgcapacity36
bb_rcglimit36:
  %v481 = load i64, ptr %slot1, align 8
  %p482 = inttoptr i64 %v481 to ptr
  %call483 = call i32 @myl_qbe_rc_status(ptr %p482, i32 2) nomerge, !dbg !114
  store i32 %call483, ptr %slot59, align 8
  br label %bb_failure
bb_rcgcapacity36:
  %v484 = load i64, ptr %slot57, align 8
  %v485 = load i64, ptr %slot49, align 8
  %p486 = inttoptr i64 %v485 to ptr
  %rgep487 = getelementptr i8, ptr %p486, i64 -24
  store i64 %v484, ptr %rgep487, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore36
bb_rcgstore36:
  %v488 = load i64, ptr %slot49, align 8
  %v489 = load i64, ptr %slot48, align 8
  %p490 = inttoptr i64 %v489 to ptr
  store i64 %v488, ptr %p490, align 8, !alias.scope !3, !noalias !4
  %v491 = load i64, ptr %slot11, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i32 2, ptr %p492, align 4, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot11, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i32 16, ptr %p494, align 4, !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot10, align 8
  %p496 = inttoptr i64 %v495 to ptr
  store i32 1, ptr %p496, align 4, !alias.scope !3, !noalias !4
  %v497 = load i64, ptr %slot8, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %ld499 = load i32, ptr %p498, align 4, !alias.scope !3, !noalias !4
  store i32 %ld499, ptr %slot60, align 8
  %v500 = load i32, ptr %slot60, align 8
  %cv501 = zext i32 %v500 to i64
  %cond502 = icmp ne i64 %cv501, 0
  br i1 %cond502, label %bb_rcslotdrop52, label %bb_rcslotdone52
bb_rcslotdrop52:
  %v503 = load i64, ptr %slot8, align 8
  %p504 = inttoptr i64 %v503 to ptr
  store i32 0, ptr %p504, align 4, !alias.scope !3, !noalias !4
  %v505 = load i64, ptr %slot13, align 8
  store i64 %v505, ptr %slot61, align 8
  %v506 = load i64, ptr %slot9, align 8
  %p507 = inttoptr i64 %v506 to ptr
  %ld508 = load i32, ptr %p507, align 4, !alias.scope !3, !noalias !4
  store i32 %ld508, ptr %slot62, align 8
  %v509 = load i32, ptr %slot62, align 8
  %op510 = and i32 %v509, 28
  store i32 %op510, ptr %slot63, align 8
  %v511 = load i32, ptr %slot63, align 8
  %cv512 = zext i32 %v511 to i64
  %cond513 = icmp ne i64 %cv512, 0
  br i1 %cond513, label %bb_rcslotrole52, label %bb_rcslotowner52
bb_rcslotrole52:
  %v514 = load i64, ptr %slot30, align 8
  store i64 %v514, ptr %slot64, align 8
  %v515 = load i64, ptr %slot64, align 8
  %v516 = load i64, ptr %slot61, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v515, i64 %v516) nomerge, !dbg !114
  br label %bb_rcslotdone52
bb_rcslotowner52:
  %v517 = load i64, ptr %slot30, align 8
  store i64 %v517, ptr %slot65, align 8
  %v518 = load i64, ptr %slot65, align 8
  %v519 = load i64, ptr %slot61, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v518, i64 %v519) nomerge, !dbg !114
  br label %bb_rcslotdone52
bb_rcslotdone52:
  %v520 = load i64, ptr %slot13, align 8
  store i64 %v520, ptr %slot66, align 8
  %v521 = load i64, ptr %slot16, align 8
  store i64 %v521, ptr %slot67, align 8
  %v522 = load i64, ptr %slot67, align 8
  %v523 = load i64, ptr %slot66, align 8
  %p524 = inttoptr i64 %v522 to ptr
  %p525 = inttoptr i64 %v523 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p525, ptr %p524, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v526 = load i64, ptr %slot9, align 8
  %p527 = inttoptr i64 %v526 to ptr
  store i32 2, ptr %p527, align 4, !alias.scope !3, !noalias !4
  %v528 = load i64, ptr %slot11, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i32, ptr %p529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld530, ptr %slot68, align 8
  %v531 = load i32, ptr %slot68, align 8
  %v532 = load i64, ptr %slot9, align 8
  %p533 = inttoptr i64 %v532 to ptr
  store i32 %v531, ptr %p533, align 4, !alias.scope !3, !noalias !4
  %v534 = load i64, ptr %slot10, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i32 0, ptr %p535, align 4, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot8, align 8
  %p537 = inttoptr i64 %v536 to ptr
  store i32 1, ptr %p537, align 4, !alias.scope !3, !noalias !4
  %v538 = load i64, ptr %slot66, align 8
  %p539 = inttoptr i64 %v538 to ptr
  %ld540 = load i64, ptr %p539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld540, ptr %slot69, align 8
  %v541 = load i64, ptr %slot69, align 8
  %v542 = load i64, ptr %slot23, align 8
  %p543 = inttoptr i64 %v542 to ptr
  store i64 %v541, ptr %p543, align 8, !alias.scope !3, !noalias !4
  %v544 = load i64, ptr %slot22, align 8
  %p545 = inttoptr i64 %v544 to ptr
  %ld546 = load i64, ptr %p545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld546, ptr %slot70, align 8
  %v547 = load i64, ptr %slot23, align 8
  %p548 = inttoptr i64 %v547 to ptr
  %ld549 = load i64, ptr %p548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld549, ptr %slot71, align 8
  %v550 = load i64, ptr %slot22, align 8
  %p551 = inttoptr i64 %v550 to ptr
  %ld552 = load i64, ptr %p551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld552, ptr %slot72, align 8
  %v553 = load i64, ptr %slot23, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %ld555 = load i64, ptr %p554, align 8, !alias.scope !3, !noalias !4
  store i64 %ld555, ptr %slot73, align 8
  %v556 = load i64, ptr %slot30, align 8
  %p557 = inttoptr i64 %v556 to ptr
  %v558 = load i64, ptr %slot72, align 8
  %p559 = inttoptr i64 %v558 to ptr
  %v560 = load i64, ptr %slot73, align 8
  %p561 = inttoptr i64 %v560 to ptr
  %call562 = call ptr @myl_native_bytes_concat(ptr %p557, ptr %p559, ptr %p561) nomerge, !dbg !116
  %calladdr563 = ptrtoint ptr %call562 to i64
  store i64 %calladdr563, ptr %slot74, align 8
  %v564 = load i64, ptr %slot74, align 8
  %cond565 = icmp ne i64 %v564, 0
  br i1 %cond565, label %bb_success74, label %bb_failed74
bb_failed74:
  %v566 = load i64, ptr %slot1, align 8
  %p567 = inttoptr i64 %v566 to ptr
  call void @myl_qbe_fail_allocation(ptr %p567) nomerge, !dbg !116
  unreachable
bb_success74:
  %v568 = load i64, ptr %slot74, align 8
  %v569 = load i64, ptr %slot22, align 8
  %p570 = inttoptr i64 %v569 to ptr
  store i64 %v568, ptr %p570, align 8, !alias.scope !3, !noalias !4
  %v571 = load i64, ptr %slot22, align 8
  %p572 = inttoptr i64 %v571 to ptr
  %ld573 = load i64, ptr %p572, align 8, !alias.scope !3, !noalias !4
  store i64 %ld573, ptr %slot75, align 8
  %v574 = load i64, ptr %slot75, align 8
  %v575 = load i64, ptr %slot14, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i64 %v574, ptr %p576, align 8, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot14, align 8
  store i64 %v577, ptr %slot76, align 8
  %v578 = load i64, ptr %slot16, align 8
  store i64 %v578, ptr %slot77, align 8
  %v579 = load i64, ptr %slot76, align 8
  %v580 = load i64, ptr %slot77, align 8
  %p581 = inttoptr i64 %v579 to ptr
  %p582 = inttoptr i64 %v580 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p582, ptr %p581, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v583 = load i64, ptr %slot11, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i32 2, ptr %p584, align 4, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot10, align 8
  %p586 = inttoptr i64 %v585 to ptr
  store i32 1, ptr %p586, align 4, !alias.scope !3, !noalias !4
  %v587 = load i64, ptr %slot6, align 8
  %p588 = inttoptr i64 %v587 to ptr
  %ld589 = load i32, ptr %p588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld589, ptr %slot78, align 8
  %v590 = load i32, ptr %slot78, align 8
  %cv591 = zext i32 %v590 to i64
  %cond592 = icmp ne i64 %cv591, 0
  br i1 %cond592, label %bb_rcslotdrop82, label %bb_rcslotdone82
bb_rcslotdrop82:
  %v593 = load i64, ptr %slot6, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i32 0, ptr %p594, align 4, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot12, align 8
  store i64 %v595, ptr %slot79, align 8
  %v596 = load i64, ptr %slot7, align 8
  %p597 = inttoptr i64 %v596 to ptr
  %ld598 = load i32, ptr %p597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld598, ptr %slot80, align 8
  %v599 = load i32, ptr %slot80, align 8
  %op600 = and i32 %v599, 28
  store i32 %op600, ptr %slot81, align 8
  %v601 = load i32, ptr %slot81, align 8
  %cv602 = zext i32 %v601 to i64
  %cond603 = icmp ne i64 %cv602, 0
  br i1 %cond603, label %bb_rcslotrole82, label %bb_rcslotowner82
bb_rcslotrole82:
  %v604 = load i64, ptr %slot30, align 8
  store i64 %v604, ptr %slot82, align 8
  %v605 = load i64, ptr %slot79, align 8
  %p606 = inttoptr i64 %v605 to ptr
  %ld607 = load i64, ptr %p606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld607, ptr %slot83, align 8
  %v608 = load i64, ptr %slot83, align 8
  %cmp609 = icmp ne i64 %v608, 0
  %cv610 = zext i1 %cmp609 to i32
  store i32 %cv610, ptr %slot84, align 8
  %v611 = load i32, ptr %slot84, align 8
  %cv612 = zext i32 %v611 to i64
  %cond613 = icmp ne i64 %cv612, 0
  br i1 %cond613, label %bb_rcgnn98, label %bb_rcgdone98
bb_rcgnn98:
  %v614 = load i64, ptr %slot83, align 8
  %op615 = sub i64 %v614, 16
  store i64 %op615, ptr %slot85, align 8
  %v616 = load i64, ptr %slot83, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %rgep618 = getelementptr i8, ptr %p617, i64 -16
  %ld619 = load i64, ptr %rgep618, align 8, !alias.scope !9, !noalias !10
  store i64 %ld619, ptr %slot86, align 8
  %v620 = load i64, ptr %slot86, align 8
  %op621 = and i64 %v620, 4611686018427387906
  store i64 %op621, ptr %slot87, align 8
  %v622 = load i64, ptr %slot87, align 8
  %cmp623 = icmp ne i64 %v622, 0
  %cv624 = zext i1 %cmp623 to i32
  store i32 %cv624, ptr %slot88, align 8
  %v625 = load i32, ptr %slot88, align 8
  %cv626 = zext i32 %v625 to i64
  %cond627 = icmp ne i64 %cv626, 0
  br i1 %cond627, label %bb_rcgclear98, label %bb_rcgcounted98
bb_rcgcounted98:
  %v628 = load i64, ptr %slot83, align 8
  %op629 = sub i64 %v628, 24
  store i64 %op629, ptr %slot89, align 8
  %v630 = load i64, ptr %slot83, align 8
  %p631 = inttoptr i64 %v630 to ptr
  %rgep632 = getelementptr i8, ptr %p631, i64 -24
  %ld633 = load i64, ptr %rgep632, align 8, !alias.scope !9, !noalias !10
  store i64 %ld633, ptr %slot90, align 8
  %v634 = load i64, ptr %slot90, align 8
  %op635 = sub i64 %v634, 1
  store i64 %op635, ptr %slot91, align 8
  %v636 = load i64, ptr %slot91, align 8
  %cmp637 = icmp eq i64 %v636, 0
  %cv638 = zext i1 %cmp637 to i32
  store i32 %cv638, ptr %slot92, align 8
  %v639 = load i32, ptr %slot92, align 8
  %cv640 = zext i32 %v639 to i64
  %cond641 = icmp ne i64 %cv640, 0
  br i1 %cond641, label %bb_rcglast98, label %bb_rcgdec98
bb_rcglast98:
  %v642 = load i64, ptr %slot83, align 8
  %op643 = sub i64 %v642, 32
  store i64 %op643, ptr %slot93, align 8
  %v644 = load i64, ptr %slot83, align 8
  %p645 = inttoptr i64 %v644 to ptr
  %rgep646 = getelementptr i8, ptr %p645, i64 -32
  %ld647 = load i64, ptr %rgep646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld647, ptr %slot94, align 8
  %v648 = load i64, ptr %slot94, align 8
  %cmp649 = icmp ne i64 %v648, 0
  %cv650 = zext i1 %cmp649 to i32
  store i32 %cv650, ptr %slot95, align 8
  %v651 = load i32, ptr %slot95, align 8
  %cv652 = zext i32 %v651 to i64
  %cond653 = icmp ne i64 %cv652, 0
  br i1 %cond653, label %bb_rcgdec98, label %bb_rcgslow98
bb_rcgslow98:
  %v654 = load i64, ptr %slot82, align 8
  %v655 = load i64, ptr %slot79, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v654, i64 %v655) nomerge, !dbg !116
  br label %bb_rcgdone98
bb_rcgdec98:
  %v656 = load i64, ptr %slot91, align 8
  %v657 = load i64, ptr %slot83, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %rgep659 = getelementptr i8, ptr %p658, i64 -24
  store i64 %v656, ptr %rgep659, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear98
bb_rcgclear98:
  %v660 = load i64, ptr %slot79, align 8
  %p661 = inttoptr i64 %v660 to ptr
  store i64 0, ptr %p661, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone98
bb_rcgdone98:
  br label %bb_rcslotdone82
bb_rcslotowner82:
  %v662 = load i64, ptr %slot30, align 8
  store i64 %v662, ptr %slot96, align 8
  %v663 = load i64, ptr %slot79, align 8
  %p664 = inttoptr i64 %v663 to ptr
  %ld665 = load i64, ptr %p664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld665, ptr %slot97, align 8
  %v666 = load i64, ptr %slot97, align 8
  %cmp667 = icmp ne i64 %v666, 0
  %cv668 = zext i1 %cmp667 to i32
  store i32 %cv668, ptr %slot98, align 8
  %v669 = load i32, ptr %slot98, align 8
  %cv670 = zext i32 %v669 to i64
  %cond671 = icmp ne i64 %cv670, 0
  br i1 %cond671, label %bb_rcgnn113, label %bb_rcgdone113
bb_rcgnn113:
  %v672 = load i64, ptr %slot97, align 8
  %op673 = sub i64 %v672, 16
  store i64 %op673, ptr %slot99, align 8
  %v674 = load i64, ptr %slot97, align 8
  %p675 = inttoptr i64 %v674 to ptr
  %rgep676 = getelementptr i8, ptr %p675, i64 -16
  %ld677 = load i64, ptr %rgep676, align 8, !alias.scope !9, !noalias !10
  store i64 %ld677, ptr %slot100, align 8
  %v678 = load i64, ptr %slot100, align 8
  %op679 = and i64 %v678, 4611686018427387906
  store i64 %op679, ptr %slot101, align 8
  %v680 = load i64, ptr %slot101, align 8
  %cmp681 = icmp ne i64 %v680, 0
  %cv682 = zext i1 %cmp681 to i32
  store i32 %cv682, ptr %slot102, align 8
  %v683 = load i32, ptr %slot102, align 8
  %cv684 = zext i32 %v683 to i64
  %cond685 = icmp ne i64 %cv684, 0
  br i1 %cond685, label %bb_rcgclear113, label %bb_rcgcounted113
bb_rcgcounted113:
  %v686 = load i64, ptr %slot97, align 8
  %op687 = sub i64 %v686, 32
  store i64 %op687, ptr %slot103, align 8
  %v688 = load i64, ptr %slot97, align 8
  %p689 = inttoptr i64 %v688 to ptr
  %rgep690 = getelementptr i8, ptr %p689, i64 -32
  %ld691 = load i64, ptr %rgep690, align 8, !alias.scope !9, !noalias !10
  store i64 %ld691, ptr %slot104, align 8
  %v692 = load i64, ptr %slot104, align 8
  %op693 = sub i64 %v692, 1
  store i64 %op693, ptr %slot105, align 8
  %v694 = load i64, ptr %slot105, align 8
  %cmp695 = icmp eq i64 %v694, 0
  %cv696 = zext i1 %cmp695 to i32
  store i32 %cv696, ptr %slot106, align 8
  %v697 = load i32, ptr %slot106, align 8
  %cv698 = zext i32 %v697 to i64
  %cond699 = icmp ne i64 %cv698, 0
  br i1 %cond699, label %bb_rcglast113, label %bb_rcgdec113
bb_rcglast113:
  %v700 = load i64, ptr %slot97, align 8
  %op701 = sub i64 %v700, 24
  store i64 %op701, ptr %slot107, align 8
  %v702 = load i64, ptr %slot97, align 8
  %p703 = inttoptr i64 %v702 to ptr
  %rgep704 = getelementptr i8, ptr %p703, i64 -24
  %ld705 = load i64, ptr %rgep704, align 8, !alias.scope !9, !noalias !10
  store i64 %ld705, ptr %slot108, align 8
  %v706 = load i64, ptr %slot108, align 8
  %cmp707 = icmp ne i64 %v706, 0
  %cv708 = zext i1 %cmp707 to i32
  store i32 %cv708, ptr %slot109, align 8
  %v709 = load i32, ptr %slot109, align 8
  %cv710 = zext i32 %v709 to i64
  %cond711 = icmp ne i64 %cv710, 0
  br i1 %cond711, label %bb_rcgdec113, label %bb_rcgslow113
bb_rcgslow113:
  %v712 = load i64, ptr %slot96, align 8
  %v713 = load i64, ptr %slot79, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v712, i64 %v713) nomerge, !dbg !116
  br label %bb_rcgdone113
bb_rcgdec113:
  %v714 = load i64, ptr %slot105, align 8
  %v715 = load i64, ptr %slot97, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %rgep717 = getelementptr i8, ptr %p716, i64 -32
  store i64 %v714, ptr %rgep717, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear113
bb_rcgclear113:
  %v718 = load i64, ptr %slot79, align 8
  %p719 = inttoptr i64 %v718 to ptr
  store i64 0, ptr %p719, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone113
bb_rcgdone113:
  br label %bb_rcslotdone82
bb_rcslotdone82:
  %v720 = load i64, ptr %slot8, align 8
  %p721 = inttoptr i64 %v720 to ptr
  %ld722 = load i32, ptr %p721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld722, ptr %slot110, align 8
  %v723 = load i32, ptr %slot110, align 8
  %cv724 = zext i32 %v723 to i64
  %cond725 = icmp ne i64 %cv724, 0
  br i1 %cond725, label %bb_rcslotdrop119, label %bb_rcslotdone119
bb_rcslotdrop119:
  %v726 = load i64, ptr %slot8, align 8
  %p727 = inttoptr i64 %v726 to ptr
  store i32 0, ptr %p727, align 4, !alias.scope !3, !noalias !4
  %v728 = load i64, ptr %slot13, align 8
  store i64 %v728, ptr %slot111, align 8
  %v729 = load i64, ptr %slot9, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %ld731 = load i32, ptr %p730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld731, ptr %slot112, align 8
  %v732 = load i32, ptr %slot112, align 8
  %op733 = and i32 %v732, 28
  store i32 %op733, ptr %slot113, align 8
  %v734 = load i32, ptr %slot113, align 8
  %cv735 = zext i32 %v734 to i64
  %cond736 = icmp ne i64 %cv735, 0
  br i1 %cond736, label %bb_rcslotrole119, label %bb_rcslotowner119
bb_rcslotrole119:
  %v737 = load i64, ptr %slot30, align 8
  store i64 %v737, ptr %slot114, align 8
  %v738 = load i64, ptr %slot111, align 8
  %p739 = inttoptr i64 %v738 to ptr
  %ld740 = load i64, ptr %p739, align 8, !alias.scope !3, !noalias !4
  store i64 %ld740, ptr %slot115, align 8
  %v741 = load i64, ptr %slot115, align 8
  %cmp742 = icmp ne i64 %v741, 0
  %cv743 = zext i1 %cmp742 to i32
  store i32 %cv743, ptr %slot116, align 8
  %v744 = load i32, ptr %slot116, align 8
  %cv745 = zext i32 %v744 to i64
  %cond746 = icmp ne i64 %cv745, 0
  br i1 %cond746, label %bb_rcgnn135, label %bb_rcgdone135
bb_rcgnn135:
  %v747 = load i64, ptr %slot115, align 8
  %op748 = sub i64 %v747, 16
  store i64 %op748, ptr %slot117, align 8
  %v749 = load i64, ptr %slot115, align 8
  %p750 = inttoptr i64 %v749 to ptr
  %rgep751 = getelementptr i8, ptr %p750, i64 -16
  %ld752 = load i64, ptr %rgep751, align 8, !alias.scope !9, !noalias !10
  store i64 %ld752, ptr %slot118, align 8
  %v753 = load i64, ptr %slot118, align 8
  %op754 = and i64 %v753, 4611686018427387906
  store i64 %op754, ptr %slot119, align 8
  %v755 = load i64, ptr %slot119, align 8
  %cmp756 = icmp ne i64 %v755, 0
  %cv757 = zext i1 %cmp756 to i32
  store i32 %cv757, ptr %slot120, align 8
  %v758 = load i32, ptr %slot120, align 8
  %cv759 = zext i32 %v758 to i64
  %cond760 = icmp ne i64 %cv759, 0
  br i1 %cond760, label %bb_rcgclear135, label %bb_rcgcounted135
bb_rcgcounted135:
  %v761 = load i64, ptr %slot115, align 8
  %op762 = sub i64 %v761, 24
  store i64 %op762, ptr %slot121, align 8
  %v763 = load i64, ptr %slot115, align 8
  %p764 = inttoptr i64 %v763 to ptr
  %rgep765 = getelementptr i8, ptr %p764, i64 -24
  %ld766 = load i64, ptr %rgep765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld766, ptr %slot122, align 8
  %v767 = load i64, ptr %slot122, align 8
  %op768 = sub i64 %v767, 1
  store i64 %op768, ptr %slot123, align 8
  %v769 = load i64, ptr %slot123, align 8
  %cmp770 = icmp eq i64 %v769, 0
  %cv771 = zext i1 %cmp770 to i32
  store i32 %cv771, ptr %slot124, align 8
  %v772 = load i32, ptr %slot124, align 8
  %cv773 = zext i32 %v772 to i64
  %cond774 = icmp ne i64 %cv773, 0
  br i1 %cond774, label %bb_rcglast135, label %bb_rcgdec135
bb_rcglast135:
  %v775 = load i64, ptr %slot115, align 8
  %op776 = sub i64 %v775, 32
  store i64 %op776, ptr %slot125, align 8
  %v777 = load i64, ptr %slot115, align 8
  %p778 = inttoptr i64 %v777 to ptr
  %rgep779 = getelementptr i8, ptr %p778, i64 -32
  %ld780 = load i64, ptr %rgep779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld780, ptr %slot126, align 8
  %v781 = load i64, ptr %slot126, align 8
  %cmp782 = icmp ne i64 %v781, 0
  %cv783 = zext i1 %cmp782 to i32
  store i32 %cv783, ptr %slot127, align 8
  %v784 = load i32, ptr %slot127, align 8
  %cv785 = zext i32 %v784 to i64
  %cond786 = icmp ne i64 %cv785, 0
  br i1 %cond786, label %bb_rcgdec135, label %bb_rcgslow135
bb_rcgslow135:
  %v787 = load i64, ptr %slot114, align 8
  %v788 = load i64, ptr %slot111, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v787, i64 %v788) nomerge, !dbg !116
  br label %bb_rcgdone135
bb_rcgdec135:
  %v789 = load i64, ptr %slot123, align 8
  %v790 = load i64, ptr %slot115, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %rgep792 = getelementptr i8, ptr %p791, i64 -24
  store i64 %v789, ptr %rgep792, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear135
bb_rcgclear135:
  %v793 = load i64, ptr %slot111, align 8
  %p794 = inttoptr i64 %v793 to ptr
  store i64 0, ptr %p794, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone135
bb_rcgdone135:
  br label %bb_rcslotdone119
bb_rcslotowner119:
  %v795 = load i64, ptr %slot30, align 8
  store i64 %v795, ptr %slot128, align 8
  %v796 = load i64, ptr %slot111, align 8
  %p797 = inttoptr i64 %v796 to ptr
  %ld798 = load i64, ptr %p797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld798, ptr %slot129, align 8
  %v799 = load i64, ptr %slot129, align 8
  %cmp800 = icmp ne i64 %v799, 0
  %cv801 = zext i1 %cmp800 to i32
  store i32 %cv801, ptr %slot130, align 8
  %v802 = load i32, ptr %slot130, align 8
  %cv803 = zext i32 %v802 to i64
  %cond804 = icmp ne i64 %cv803, 0
  br i1 %cond804, label %bb_rcgnn150, label %bb_rcgdone150
bb_rcgnn150:
  %v805 = load i64, ptr %slot129, align 8
  %op806 = sub i64 %v805, 16
  store i64 %op806, ptr %slot131, align 8
  %v807 = load i64, ptr %slot129, align 8
  %p808 = inttoptr i64 %v807 to ptr
  %rgep809 = getelementptr i8, ptr %p808, i64 -16
  %ld810 = load i64, ptr %rgep809, align 8, !alias.scope !9, !noalias !10
  store i64 %ld810, ptr %slot132, align 8
  %v811 = load i64, ptr %slot132, align 8
  %op812 = and i64 %v811, 4611686018427387906
  store i64 %op812, ptr %slot133, align 8
  %v813 = load i64, ptr %slot133, align 8
  %cmp814 = icmp ne i64 %v813, 0
  %cv815 = zext i1 %cmp814 to i32
  store i32 %cv815, ptr %slot134, align 8
  %v816 = load i32, ptr %slot134, align 8
  %cv817 = zext i32 %v816 to i64
  %cond818 = icmp ne i64 %cv817, 0
  br i1 %cond818, label %bb_rcgclear150, label %bb_rcgcounted150
bb_rcgcounted150:
  %v819 = load i64, ptr %slot129, align 8
  %op820 = sub i64 %v819, 32
  store i64 %op820, ptr %slot135, align 8
  %v821 = load i64, ptr %slot129, align 8
  %p822 = inttoptr i64 %v821 to ptr
  %rgep823 = getelementptr i8, ptr %p822, i64 -32
  %ld824 = load i64, ptr %rgep823, align 8, !alias.scope !9, !noalias !10
  store i64 %ld824, ptr %slot136, align 8
  %v825 = load i64, ptr %slot136, align 8
  %op826 = sub i64 %v825, 1
  store i64 %op826, ptr %slot137, align 8
  %v827 = load i64, ptr %slot137, align 8
  %cmp828 = icmp eq i64 %v827, 0
  %cv829 = zext i1 %cmp828 to i32
  store i32 %cv829, ptr %slot138, align 8
  %v830 = load i32, ptr %slot138, align 8
  %cv831 = zext i32 %v830 to i64
  %cond832 = icmp ne i64 %cv831, 0
  br i1 %cond832, label %bb_rcglast150, label %bb_rcgdec150
bb_rcglast150:
  %v833 = load i64, ptr %slot129, align 8
  %op834 = sub i64 %v833, 24
  store i64 %op834, ptr %slot139, align 8
  %v835 = load i64, ptr %slot129, align 8
  %p836 = inttoptr i64 %v835 to ptr
  %rgep837 = getelementptr i8, ptr %p836, i64 -24
  %ld838 = load i64, ptr %rgep837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld838, ptr %slot140, align 8
  %v839 = load i64, ptr %slot140, align 8
  %cmp840 = icmp ne i64 %v839, 0
  %cv841 = zext i1 %cmp840 to i32
  store i32 %cv841, ptr %slot141, align 8
  %v842 = load i32, ptr %slot141, align 8
  %cv843 = zext i32 %v842 to i64
  %cond844 = icmp ne i64 %cv843, 0
  br i1 %cond844, label %bb_rcgdec150, label %bb_rcgslow150
bb_rcgslow150:
  %v845 = load i64, ptr %slot128, align 8
  %v846 = load i64, ptr %slot111, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v845, i64 %v846) nomerge, !dbg !116
  br label %bb_rcgdone150
bb_rcgdec150:
  %v847 = load i64, ptr %slot137, align 8
  %v848 = load i64, ptr %slot129, align 8
  %p849 = inttoptr i64 %v848 to ptr
  %rgep850 = getelementptr i8, ptr %p849, i64 -32
  store i64 %v847, ptr %rgep850, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear150
bb_rcgclear150:
  %v851 = load i64, ptr %slot111, align 8
  %p852 = inttoptr i64 %v851 to ptr
  store i64 0, ptr %p852, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone150
bb_rcgdone150:
  br label %bb_rcslotdone119
bb_rcslotdone119:
  %v853 = load i64, ptr %slot12, align 8
  store i64 %v853, ptr %slot142, align 8
  %v854 = load i64, ptr %slot16, align 8
  store i64 %v854, ptr %slot143, align 8
  %v855 = load i64, ptr %slot143, align 8
  %v856 = load i64, ptr %slot142, align 8
  %p857 = inttoptr i64 %v855 to ptr
  %p858 = inttoptr i64 %v856 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p858, ptr %p857, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v859 = load i64, ptr %slot7, align 8
  %p860 = inttoptr i64 %v859 to ptr
  store i32 2, ptr %p860, align 4, !alias.scope !3, !noalias !4
  %v861 = load i64, ptr %slot11, align 8
  %p862 = inttoptr i64 %v861 to ptr
  %ld863 = load i32, ptr %p862, align 4, !alias.scope !3, !noalias !4
  store i32 %ld863, ptr %slot144, align 8
  %v864 = load i32, ptr %slot144, align 8
  %v865 = load i64, ptr %slot7, align 8
  %p866 = inttoptr i64 %v865 to ptr
  store i32 %v864, ptr %p866, align 4, !alias.scope !3, !noalias !4
  %v867 = load i64, ptr %slot10, align 8
  %p868 = inttoptr i64 %v867 to ptr
  store i32 0, ptr %p868, align 4, !alias.scope !3, !noalias !4
  %v869 = load i64, ptr %slot6, align 8
  %p870 = inttoptr i64 %v869 to ptr
  store i32 1, ptr %p870, align 4, !alias.scope !3, !noalias !4
  %v871 = load i64, ptr %slot142, align 8
  %p872 = inttoptr i64 %v871 to ptr
  %ld873 = load i64, ptr %p872, align 8, !alias.scope !3, !noalias !4
  store i64 %ld873, ptr %slot145, align 8
  %v874 = load i64, ptr %slot145, align 8
  %v875 = load i64, ptr %slot22, align 8
  %p876 = inttoptr i64 %v875 to ptr
  store i64 %v874, ptr %p876, align 8, !alias.scope !3, !noalias !4
  %p877 = inttoptr i64 ptrtoint (ptr @myl_lit_98968328545e4811811c73fe69d48e58491f56e2b2f7d6631801ce7f303a42f6 to i64) to ptr
  %ld878 = load i64, ptr %p877, align 8, !alias.scope !4, !noalias !3
  store i64 %ld878, ptr %slot146, align 8
  %v879 = load i64, ptr %slot146, align 8
  %v880 = load i64, ptr %slot23, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i64 %v879, ptr %p881, align 8, !alias.scope !3, !noalias !4
  %v882 = load i64, ptr %slot23, align 8
  %p883 = inttoptr i64 %v882 to ptr
  %ld884 = load i64, ptr %p883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld884, ptr %slot147, align 8
  %v885 = load i64, ptr %slot147, align 8
  %v886 = load i64, ptr %slot15, align 8
  %p887 = inttoptr i64 %v886 to ptr
  store i64 %v885, ptr %p887, align 8, !alias.scope !3, !noalias !4
  %v888 = load i64, ptr %slot15, align 8
  store i64 %v888, ptr %slot148, align 8
  %v889 = load i64, ptr %slot16, align 8
  store i64 %v889, ptr %slot149, align 8
  %v890 = load i64, ptr %slot148, align 8
  %v891 = load i64, ptr %slot149, align 8
  %p892 = inttoptr i64 %v890 to ptr
  %p893 = inttoptr i64 %v891 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p893, ptr %p892, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v894 = load i64, ptr %slot11, align 8
  %p895 = inttoptr i64 %v894 to ptr
  store i32 2, ptr %p895, align 4, !alias.scope !3, !noalias !4
  %v896 = load i64, ptr %slot10, align 8
  %p897 = inttoptr i64 %v896 to ptr
  store i32 1, ptr %p897, align 4, !alias.scope !3, !noalias !4
  %v898 = load i64, ptr %slot13, align 8
  store i64 %v898, ptr %slot150, align 8
  %v899 = load i64, ptr %slot16, align 8
  store i64 %v899, ptr %slot151, align 8
  %v900 = load i64, ptr %slot151, align 8
  %v901 = load i64, ptr %slot150, align 8
  %p902 = inttoptr i64 %v900 to ptr
  %p903 = inttoptr i64 %v901 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p903, ptr %p902, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v904 = load i64, ptr %slot9, align 8
  %p905 = inttoptr i64 %v904 to ptr
  store i32 2, ptr %p905, align 4, !alias.scope !3, !noalias !4
  %v906 = load i64, ptr %slot11, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %ld908 = load i32, ptr %p907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld908, ptr %slot152, align 8
  %v909 = load i32, ptr %slot152, align 8
  %v910 = load i64, ptr %slot9, align 8
  %p911 = inttoptr i64 %v910 to ptr
  store i32 %v909, ptr %p911, align 4, !alias.scope !3, !noalias !4
  %v912 = load i64, ptr %slot10, align 8
  %p913 = inttoptr i64 %v912 to ptr
  store i32 0, ptr %p913, align 4, !alias.scope !3, !noalias !4
  %v914 = load i64, ptr %slot8, align 8
  %p915 = inttoptr i64 %v914 to ptr
  store i32 1, ptr %p915, align 4, !alias.scope !3, !noalias !4
  %v916 = load i64, ptr %slot150, align 8
  %p917 = inttoptr i64 %v916 to ptr
  %ld918 = load i64, ptr %p917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld918, ptr %slot153, align 8
  %v919 = load i64, ptr %slot153, align 8
  %v920 = load i64, ptr %slot23, align 8
  %p921 = inttoptr i64 %v920 to ptr
  store i64 %v919, ptr %p921, align 8, !alias.scope !3, !noalias !4
  %v922 = load i64, ptr %slot22, align 8
  %p923 = inttoptr i64 %v922 to ptr
  %ld924 = load i64, ptr %p923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld924, ptr %slot154, align 8
  %v925 = load i64, ptr %slot23, align 8
  %p926 = inttoptr i64 %v925 to ptr
  %ld927 = load i64, ptr %p926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld927, ptr %slot155, align 8
  %v928 = load i64, ptr %slot22, align 8
  %p929 = inttoptr i64 %v928 to ptr
  %ld930 = load i64, ptr %p929, align 8, !alias.scope !3, !noalias !4
  store i64 %ld930, ptr %slot156, align 8
  %v931 = load i64, ptr %slot23, align 8
  %p932 = inttoptr i64 %v931 to ptr
  %ld933 = load i64, ptr %p932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld933, ptr %slot157, align 8
  %v934 = load i64, ptr %slot30, align 8
  %p935 = inttoptr i64 %v934 to ptr
  %v936 = load i64, ptr %slot156, align 8
  %p937 = inttoptr i64 %v936 to ptr
  %v938 = load i64, ptr %slot157, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %call940 = call ptr @myl_native_bytes_concat(ptr %p935, ptr %p937, ptr %p939) nomerge, !dbg !118
  %calladdr941 = ptrtoint ptr %call940 to i64
  store i64 %calladdr941, ptr %slot158, align 8
  %v942 = load i64, ptr %slot158, align 8
  %cond943 = icmp ne i64 %v942, 0
  br i1 %cond943, label %bb_success185, label %bb_failed185
bb_failed185:
  %v944 = load i64, ptr %slot1, align 8
  %p945 = inttoptr i64 %v944 to ptr
  call void @myl_qbe_fail_allocation(ptr %p945) nomerge, !dbg !118
  unreachable
bb_success185:
  %v946 = load i64, ptr %slot158, align 8
  %v947 = load i64, ptr %slot22, align 8
  %p948 = inttoptr i64 %v947 to ptr
  store i64 %v946, ptr %p948, align 8, !alias.scope !3, !noalias !4
  %v949 = load i64, ptr %slot22, align 8
  %p950 = inttoptr i64 %v949 to ptr
  %ld951 = load i64, ptr %p950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld951, ptr %slot159, align 8
  %v952 = load i64, ptr %slot159, align 8
  %v953 = load i64, ptr %slot14, align 8
  %p954 = inttoptr i64 %v953 to ptr
  store i64 %v952, ptr %p954, align 8, !alias.scope !3, !noalias !4
  %v955 = load i64, ptr %slot14, align 8
  store i64 %v955, ptr %slot160, align 8
  %v956 = load i64, ptr %slot16, align 8
  store i64 %v956, ptr %slot161, align 8
  %v957 = load i64, ptr %slot160, align 8
  %v958 = load i64, ptr %slot161, align 8
  %p959 = inttoptr i64 %v957 to ptr
  %p960 = inttoptr i64 %v958 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p960, ptr %p959, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v961 = load i64, ptr %slot11, align 8
  %p962 = inttoptr i64 %v961 to ptr
  store i32 2, ptr %p962, align 4, !alias.scope !3, !noalias !4
  %v963 = load i64, ptr %slot10, align 8
  %p964 = inttoptr i64 %v963 to ptr
  store i32 1, ptr %p964, align 4, !alias.scope !3, !noalias !4
  %v965 = load i64, ptr %slot6, align 8
  %p966 = inttoptr i64 %v965 to ptr
  %ld967 = load i32, ptr %p966, align 4, !alias.scope !3, !noalias !4
  store i32 %ld967, ptr %slot162, align 8
  %v968 = load i32, ptr %slot162, align 8
  %cv969 = zext i32 %v968 to i64
  %cond970 = icmp ne i64 %cv969, 0
  br i1 %cond970, label %bb_rcslotdrop193, label %bb_rcslotdone193
bb_rcslotdrop193:
  %v971 = load i64, ptr %slot6, align 8
  %p972 = inttoptr i64 %v971 to ptr
  store i32 0, ptr %p972, align 4, !alias.scope !3, !noalias !4
  %v973 = load i64, ptr %slot12, align 8
  store i64 %v973, ptr %slot163, align 8
  %v974 = load i64, ptr %slot7, align 8
  %p975 = inttoptr i64 %v974 to ptr
  %ld976 = load i32, ptr %p975, align 4, !alias.scope !3, !noalias !4
  store i32 %ld976, ptr %slot164, align 8
  %v977 = load i32, ptr %slot164, align 8
  %op978 = and i32 %v977, 28
  store i32 %op978, ptr %slot165, align 8
  %v979 = load i32, ptr %slot165, align 8
  %cv980 = zext i32 %v979 to i64
  %cond981 = icmp ne i64 %cv980, 0
  br i1 %cond981, label %bb_rcslotrole193, label %bb_rcslotowner193
bb_rcslotrole193:
  %v982 = load i64, ptr %slot30, align 8
  store i64 %v982, ptr %slot166, align 8
  %v983 = load i64, ptr %slot163, align 8
  %p984 = inttoptr i64 %v983 to ptr
  %ld985 = load i64, ptr %p984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld985, ptr %slot167, align 8
  %v986 = load i64, ptr %slot167, align 8
  %cmp987 = icmp ne i64 %v986, 0
  %cv988 = zext i1 %cmp987 to i32
  store i32 %cv988, ptr %slot168, align 8
  %v989 = load i32, ptr %slot168, align 8
  %cv990 = zext i32 %v989 to i64
  %cond991 = icmp ne i64 %cv990, 0
  br i1 %cond991, label %bb_rcgnn209, label %bb_rcgdone209
bb_rcgnn209:
  %v992 = load i64, ptr %slot167, align 8
  %op993 = sub i64 %v992, 16
  store i64 %op993, ptr %slot169, align 8
  %v994 = load i64, ptr %slot167, align 8
  %p995 = inttoptr i64 %v994 to ptr
  %rgep996 = getelementptr i8, ptr %p995, i64 -16
  %ld997 = load i64, ptr %rgep996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld997, ptr %slot170, align 8
  %v998 = load i64, ptr %slot170, align 8
  %op999 = and i64 %v998, 4611686018427387906
  store i64 %op999, ptr %slot171, align 8
  %v1000 = load i64, ptr %slot171, align 8
  %cmp1001 = icmp ne i64 %v1000, 0
  %cv1002 = zext i1 %cmp1001 to i32
  store i32 %cv1002, ptr %slot172, align 8
  %v1003 = load i32, ptr %slot172, align 8
  %cv1004 = zext i32 %v1003 to i64
  %cond1005 = icmp ne i64 %cv1004, 0
  br i1 %cond1005, label %bb_rcgclear209, label %bb_rcgcounted209
bb_rcgcounted209:
  %v1006 = load i64, ptr %slot167, align 8
  %op1007 = sub i64 %v1006, 24
  store i64 %op1007, ptr %slot173, align 8
  %v1008 = load i64, ptr %slot167, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  %rgep1010 = getelementptr i8, ptr %p1009, i64 -24
  %ld1011 = load i64, ptr %rgep1010, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1011, ptr %slot174, align 8
  %v1012 = load i64, ptr %slot174, align 8
  %op1013 = sub i64 %v1012, 1
  store i64 %op1013, ptr %slot175, align 8
  %v1014 = load i64, ptr %slot175, align 8
  %cmp1015 = icmp eq i64 %v1014, 0
  %cv1016 = zext i1 %cmp1015 to i32
  store i32 %cv1016, ptr %slot176, align 8
  %v1017 = load i32, ptr %slot176, align 8
  %cv1018 = zext i32 %v1017 to i64
  %cond1019 = icmp ne i64 %cv1018, 0
  br i1 %cond1019, label %bb_rcglast209, label %bb_rcgdec209
bb_rcglast209:
  %v1020 = load i64, ptr %slot167, align 8
  %op1021 = sub i64 %v1020, 32
  store i64 %op1021, ptr %slot177, align 8
  %v1022 = load i64, ptr %slot167, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  %rgep1024 = getelementptr i8, ptr %p1023, i64 -32
  %ld1025 = load i64, ptr %rgep1024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1025, ptr %slot178, align 8
  %v1026 = load i64, ptr %slot178, align 8
  %cmp1027 = icmp ne i64 %v1026, 0
  %cv1028 = zext i1 %cmp1027 to i32
  store i32 %cv1028, ptr %slot179, align 8
  %v1029 = load i32, ptr %slot179, align 8
  %cv1030 = zext i32 %v1029 to i64
  %cond1031 = icmp ne i64 %cv1030, 0
  br i1 %cond1031, label %bb_rcgdec209, label %bb_rcgslow209
bb_rcgslow209:
  %v1032 = load i64, ptr %slot166, align 8
  %v1033 = load i64, ptr %slot163, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1032, i64 %v1033) nomerge, !dbg !118
  br label %bb_rcgdone209
bb_rcgdec209:
  %v1034 = load i64, ptr %slot175, align 8
  %v1035 = load i64, ptr %slot167, align 8
  %p1036 = inttoptr i64 %v1035 to ptr
  %rgep1037 = getelementptr i8, ptr %p1036, i64 -24
  store i64 %v1034, ptr %rgep1037, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear209
bb_rcgclear209:
  %v1038 = load i64, ptr %slot163, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  store i64 0, ptr %p1039, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone209
bb_rcgdone209:
  br label %bb_rcslotdone193
bb_rcslotowner193:
  %v1040 = load i64, ptr %slot30, align 8
  store i64 %v1040, ptr %slot180, align 8
  %v1041 = load i64, ptr %slot163, align 8
  %p1042 = inttoptr i64 %v1041 to ptr
  %ld1043 = load i64, ptr %p1042, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1043, ptr %slot181, align 8
  %v1044 = load i64, ptr %slot181, align 8
  %cmp1045 = icmp ne i64 %v1044, 0
  %cv1046 = zext i1 %cmp1045 to i32
  store i32 %cv1046, ptr %slot182, align 8
  %v1047 = load i32, ptr %slot182, align 8
  %cv1048 = zext i32 %v1047 to i64
  %cond1049 = icmp ne i64 %cv1048, 0
  br i1 %cond1049, label %bb_rcgnn224, label %bb_rcgdone224
bb_rcgnn224:
  %v1050 = load i64, ptr %slot181, align 8
  %op1051 = sub i64 %v1050, 16
  store i64 %op1051, ptr %slot183, align 8
  %v1052 = load i64, ptr %slot181, align 8
  %p1053 = inttoptr i64 %v1052 to ptr
  %rgep1054 = getelementptr i8, ptr %p1053, i64 -16
  %ld1055 = load i64, ptr %rgep1054, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1055, ptr %slot184, align 8
  %v1056 = load i64, ptr %slot184, align 8
  %op1057 = and i64 %v1056, 4611686018427387906
  store i64 %op1057, ptr %slot185, align 8
  %v1058 = load i64, ptr %slot185, align 8
  %cmp1059 = icmp ne i64 %v1058, 0
  %cv1060 = zext i1 %cmp1059 to i32
  store i32 %cv1060, ptr %slot186, align 8
  %v1061 = load i32, ptr %slot186, align 8
  %cv1062 = zext i32 %v1061 to i64
  %cond1063 = icmp ne i64 %cv1062, 0
  br i1 %cond1063, label %bb_rcgclear224, label %bb_rcgcounted224
bb_rcgcounted224:
  %v1064 = load i64, ptr %slot181, align 8
  %op1065 = sub i64 %v1064, 32
  store i64 %op1065, ptr %slot187, align 8
  %v1066 = load i64, ptr %slot181, align 8
  %p1067 = inttoptr i64 %v1066 to ptr
  %rgep1068 = getelementptr i8, ptr %p1067, i64 -32
  %ld1069 = load i64, ptr %rgep1068, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1069, ptr %slot188, align 8
  %v1070 = load i64, ptr %slot188, align 8
  %op1071 = sub i64 %v1070, 1
  store i64 %op1071, ptr %slot189, align 8
  %v1072 = load i64, ptr %slot189, align 8
  %cmp1073 = icmp eq i64 %v1072, 0
  %cv1074 = zext i1 %cmp1073 to i32
  store i32 %cv1074, ptr %slot190, align 8
  %v1075 = load i32, ptr %slot190, align 8
  %cv1076 = zext i32 %v1075 to i64
  %cond1077 = icmp ne i64 %cv1076, 0
  br i1 %cond1077, label %bb_rcglast224, label %bb_rcgdec224
bb_rcglast224:
  %v1078 = load i64, ptr %slot181, align 8
  %op1079 = sub i64 %v1078, 24
  store i64 %op1079, ptr %slot191, align 8
  %v1080 = load i64, ptr %slot181, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  %rgep1082 = getelementptr i8, ptr %p1081, i64 -24
  %ld1083 = load i64, ptr %rgep1082, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1083, ptr %slot192, align 8
  %v1084 = load i64, ptr %slot192, align 8
  %cmp1085 = icmp ne i64 %v1084, 0
  %cv1086 = zext i1 %cmp1085 to i32
  store i32 %cv1086, ptr %slot193, align 8
  %v1087 = load i32, ptr %slot193, align 8
  %cv1088 = zext i32 %v1087 to i64
  %cond1089 = icmp ne i64 %cv1088, 0
  br i1 %cond1089, label %bb_rcgdec224, label %bb_rcgslow224
bb_rcgslow224:
  %v1090 = load i64, ptr %slot180, align 8
  %v1091 = load i64, ptr %slot163, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1090, i64 %v1091) nomerge, !dbg !118
  br label %bb_rcgdone224
bb_rcgdec224:
  %v1092 = load i64, ptr %slot189, align 8
  %v1093 = load i64, ptr %slot181, align 8
  %p1094 = inttoptr i64 %v1093 to ptr
  %rgep1095 = getelementptr i8, ptr %p1094, i64 -32
  store i64 %v1092, ptr %rgep1095, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear224
bb_rcgclear224:
  %v1096 = load i64, ptr %slot163, align 8
  %p1097 = inttoptr i64 %v1096 to ptr
  store i64 0, ptr %p1097, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone224
bb_rcgdone224:
  br label %bb_rcslotdone193
bb_rcslotdone193:
  %v1098 = load i64, ptr %slot8, align 8
  %p1099 = inttoptr i64 %v1098 to ptr
  %ld1100 = load i32, ptr %p1099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1100, ptr %slot194, align 8
  %v1101 = load i32, ptr %slot194, align 8
  %cv1102 = zext i32 %v1101 to i64
  %cond1103 = icmp ne i64 %cv1102, 0
  br i1 %cond1103, label %bb_rcslotdrop230, label %bb_rcslotdone230
bb_rcslotdrop230:
  %v1104 = load i64, ptr %slot8, align 8
  %p1105 = inttoptr i64 %v1104 to ptr
  store i32 0, ptr %p1105, align 4, !alias.scope !3, !noalias !4
  %v1106 = load i64, ptr %slot13, align 8
  store i64 %v1106, ptr %slot195, align 8
  %v1107 = load i64, ptr %slot9, align 8
  %p1108 = inttoptr i64 %v1107 to ptr
  %ld1109 = load i32, ptr %p1108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1109, ptr %slot196, align 8
  %v1110 = load i32, ptr %slot196, align 8
  %op1111 = and i32 %v1110, 28
  store i32 %op1111, ptr %slot197, align 8
  %v1112 = load i32, ptr %slot197, align 8
  %cv1113 = zext i32 %v1112 to i64
  %cond1114 = icmp ne i64 %cv1113, 0
  br i1 %cond1114, label %bb_rcslotrole230, label %bb_rcslotowner230
bb_rcslotrole230:
  %v1115 = load i64, ptr %slot30, align 8
  store i64 %v1115, ptr %slot198, align 8
  %v1116 = load i64, ptr %slot195, align 8
  %p1117 = inttoptr i64 %v1116 to ptr
  %ld1118 = load i64, ptr %p1117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1118, ptr %slot199, align 8
  %v1119 = load i64, ptr %slot199, align 8
  %cmp1120 = icmp ne i64 %v1119, 0
  %cv1121 = zext i1 %cmp1120 to i32
  store i32 %cv1121, ptr %slot200, align 8
  %v1122 = load i32, ptr %slot200, align 8
  %cv1123 = zext i32 %v1122 to i64
  %cond1124 = icmp ne i64 %cv1123, 0
  br i1 %cond1124, label %bb_rcgnn246, label %bb_rcgdone246
bb_rcgnn246:
  %v1125 = load i64, ptr %slot199, align 8
  %op1126 = sub i64 %v1125, 16
  store i64 %op1126, ptr %slot201, align 8
  %v1127 = load i64, ptr %slot199, align 8
  %p1128 = inttoptr i64 %v1127 to ptr
  %rgep1129 = getelementptr i8, ptr %p1128, i64 -16
  %ld1130 = load i64, ptr %rgep1129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1130, ptr %slot202, align 8
  %v1131 = load i64, ptr %slot202, align 8
  %op1132 = and i64 %v1131, 4611686018427387906
  store i64 %op1132, ptr %slot203, align 8
  %v1133 = load i64, ptr %slot203, align 8
  %cmp1134 = icmp ne i64 %v1133, 0
  %cv1135 = zext i1 %cmp1134 to i32
  store i32 %cv1135, ptr %slot204, align 8
  %v1136 = load i32, ptr %slot204, align 8
  %cv1137 = zext i32 %v1136 to i64
  %cond1138 = icmp ne i64 %cv1137, 0
  br i1 %cond1138, label %bb_rcgclear246, label %bb_rcgcounted246
bb_rcgcounted246:
  %v1139 = load i64, ptr %slot199, align 8
  %op1140 = sub i64 %v1139, 24
  store i64 %op1140, ptr %slot205, align 8
  %v1141 = load i64, ptr %slot199, align 8
  %p1142 = inttoptr i64 %v1141 to ptr
  %rgep1143 = getelementptr i8, ptr %p1142, i64 -24
  %ld1144 = load i64, ptr %rgep1143, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1144, ptr %slot206, align 8
  %v1145 = load i64, ptr %slot206, align 8
  %op1146 = sub i64 %v1145, 1
  store i64 %op1146, ptr %slot207, align 8
  %v1147 = load i64, ptr %slot207, align 8
  %cmp1148 = icmp eq i64 %v1147, 0
  %cv1149 = zext i1 %cmp1148 to i32
  store i32 %cv1149, ptr %slot208, align 8
  %v1150 = load i32, ptr %slot208, align 8
  %cv1151 = zext i32 %v1150 to i64
  %cond1152 = icmp ne i64 %cv1151, 0
  br i1 %cond1152, label %bb_rcglast246, label %bb_rcgdec246
bb_rcglast246:
  %v1153 = load i64, ptr %slot199, align 8
  %op1154 = sub i64 %v1153, 32
  store i64 %op1154, ptr %slot209, align 8
  %v1155 = load i64, ptr %slot199, align 8
  %p1156 = inttoptr i64 %v1155 to ptr
  %rgep1157 = getelementptr i8, ptr %p1156, i64 -32
  %ld1158 = load i64, ptr %rgep1157, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1158, ptr %slot210, align 8
  %v1159 = load i64, ptr %slot210, align 8
  %cmp1160 = icmp ne i64 %v1159, 0
  %cv1161 = zext i1 %cmp1160 to i32
  store i32 %cv1161, ptr %slot211, align 8
  %v1162 = load i32, ptr %slot211, align 8
  %cv1163 = zext i32 %v1162 to i64
  %cond1164 = icmp ne i64 %cv1163, 0
  br i1 %cond1164, label %bb_rcgdec246, label %bb_rcgslow246
bb_rcgslow246:
  %v1165 = load i64, ptr %slot198, align 8
  %v1166 = load i64, ptr %slot195, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1165, i64 %v1166) nomerge, !dbg !118
  br label %bb_rcgdone246
bb_rcgdec246:
  %v1167 = load i64, ptr %slot207, align 8
  %v1168 = load i64, ptr %slot199, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %rgep1170 = getelementptr i8, ptr %p1169, i64 -24
  store i64 %v1167, ptr %rgep1170, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear246
bb_rcgclear246:
  %v1171 = load i64, ptr %slot195, align 8
  %p1172 = inttoptr i64 %v1171 to ptr
  store i64 0, ptr %p1172, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone246
bb_rcgdone246:
  br label %bb_rcslotdone230
bb_rcslotowner230:
  %v1173 = load i64, ptr %slot30, align 8
  store i64 %v1173, ptr %slot212, align 8
  %v1174 = load i64, ptr %slot195, align 8
  %p1175 = inttoptr i64 %v1174 to ptr
  %ld1176 = load i64, ptr %p1175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1176, ptr %slot213, align 8
  %v1177 = load i64, ptr %slot213, align 8
  %cmp1178 = icmp ne i64 %v1177, 0
  %cv1179 = zext i1 %cmp1178 to i32
  store i32 %cv1179, ptr %slot214, align 8
  %v1180 = load i32, ptr %slot214, align 8
  %cv1181 = zext i32 %v1180 to i64
  %cond1182 = icmp ne i64 %cv1181, 0
  br i1 %cond1182, label %bb_rcgnn261, label %bb_rcgdone261
bb_rcgnn261:
  %v1183 = load i64, ptr %slot213, align 8
  %op1184 = sub i64 %v1183, 16
  store i64 %op1184, ptr %slot215, align 8
  %v1185 = load i64, ptr %slot213, align 8
  %p1186 = inttoptr i64 %v1185 to ptr
  %rgep1187 = getelementptr i8, ptr %p1186, i64 -16
  %ld1188 = load i64, ptr %rgep1187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1188, ptr %slot216, align 8
  %v1189 = load i64, ptr %slot216, align 8
  %op1190 = and i64 %v1189, 4611686018427387906
  store i64 %op1190, ptr %slot217, align 8
  %v1191 = load i64, ptr %slot217, align 8
  %cmp1192 = icmp ne i64 %v1191, 0
  %cv1193 = zext i1 %cmp1192 to i32
  store i32 %cv1193, ptr %slot218, align 8
  %v1194 = load i32, ptr %slot218, align 8
  %cv1195 = zext i32 %v1194 to i64
  %cond1196 = icmp ne i64 %cv1195, 0
  br i1 %cond1196, label %bb_rcgclear261, label %bb_rcgcounted261
bb_rcgcounted261:
  %v1197 = load i64, ptr %slot213, align 8
  %op1198 = sub i64 %v1197, 32
  store i64 %op1198, ptr %slot219, align 8
  %v1199 = load i64, ptr %slot213, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  %rgep1201 = getelementptr i8, ptr %p1200, i64 -32
  %ld1202 = load i64, ptr %rgep1201, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1202, ptr %slot220, align 8
  %v1203 = load i64, ptr %slot220, align 8
  %op1204 = sub i64 %v1203, 1
  store i64 %op1204, ptr %slot221, align 8
  %v1205 = load i64, ptr %slot221, align 8
  %cmp1206 = icmp eq i64 %v1205, 0
  %cv1207 = zext i1 %cmp1206 to i32
  store i32 %cv1207, ptr %slot222, align 8
  %v1208 = load i32, ptr %slot222, align 8
  %cv1209 = zext i32 %v1208 to i64
  %cond1210 = icmp ne i64 %cv1209, 0
  br i1 %cond1210, label %bb_rcglast261, label %bb_rcgdec261
bb_rcglast261:
  %v1211 = load i64, ptr %slot213, align 8
  %op1212 = sub i64 %v1211, 24
  store i64 %op1212, ptr %slot223, align 8
  %v1213 = load i64, ptr %slot213, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  %rgep1215 = getelementptr i8, ptr %p1214, i64 -24
  %ld1216 = load i64, ptr %rgep1215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1216, ptr %slot224, align 8
  %v1217 = load i64, ptr %slot224, align 8
  %cmp1218 = icmp ne i64 %v1217, 0
  %cv1219 = zext i1 %cmp1218 to i32
  store i32 %cv1219, ptr %slot225, align 8
  %v1220 = load i32, ptr %slot225, align 8
  %cv1221 = zext i32 %v1220 to i64
  %cond1222 = icmp ne i64 %cv1221, 0
  br i1 %cond1222, label %bb_rcgdec261, label %bb_rcgslow261
bb_rcgslow261:
  %v1223 = load i64, ptr %slot212, align 8
  %v1224 = load i64, ptr %slot195, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1223, i64 %v1224) nomerge, !dbg !118
  br label %bb_rcgdone261
bb_rcgdec261:
  %v1225 = load i64, ptr %slot221, align 8
  %v1226 = load i64, ptr %slot213, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  %rgep1228 = getelementptr i8, ptr %p1227, i64 -32
  store i64 %v1225, ptr %rgep1228, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear261
bb_rcgclear261:
  %v1229 = load i64, ptr %slot195, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  store i64 0, ptr %p1230, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone261
bb_rcgdone261:
  br label %bb_rcslotdone230
bb_rcslotdone230:
  %v1231 = load i64, ptr %slot12, align 8
  store i64 %v1231, ptr %slot226, align 8
  %v1232 = load i64, ptr %slot16, align 8
  store i64 %v1232, ptr %slot227, align 8
  %v1233 = load i64, ptr %slot227, align 8
  %v1234 = load i64, ptr %slot226, align 8
  %p1235 = inttoptr i64 %v1233 to ptr
  %p1236 = inttoptr i64 %v1234 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1236, ptr %p1235, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1237 = load i64, ptr %slot7, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  store i32 2, ptr %p1238, align 4, !alias.scope !3, !noalias !4
  %v1239 = load i64, ptr %slot11, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %ld1241 = load i32, ptr %p1240, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1241, ptr %slot228, align 8
  %v1242 = load i32, ptr %slot228, align 8
  %v1243 = load i64, ptr %slot7, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  store i32 %v1242, ptr %p1244, align 4, !alias.scope !3, !noalias !4
  %v1245 = load i64, ptr %slot10, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  store i32 0, ptr %p1246, align 4, !alias.scope !3, !noalias !4
  %v1247 = load i64, ptr %slot6, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  store i32 1, ptr %p1248, align 4, !alias.scope !3, !noalias !4
  %v1249 = load i64, ptr %slot226, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %ld1251 = load i64, ptr %p1250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1251, ptr %slot229, align 8
  %v1252 = load i64, ptr %slot229, align 8
  %v1253 = load i64, ptr %slot22, align 8
  %p1254 = inttoptr i64 %v1253 to ptr
  store i64 %v1252, ptr %p1254, align 8, !alias.scope !3, !noalias !4
  %v1255 = load i64, ptr %slot20, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  %ld1257 = load i64, ptr %p1256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1257, ptr %slot230, align 8
  %v1258 = load i64, ptr %slot21, align 8
  %p1259 = inttoptr i64 %v1258 to ptr
  %ld1260 = load i64, ptr %p1259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1260, ptr %slot231, align 8
  %v1261 = load i64, ptr %slot22, align 8
  %p1262 = inttoptr i64 %v1261 to ptr
  %ld1263 = load i64, ptr %p1262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1263, ptr %slot232, align 8
  %v1264 = load i64, ptr %slot1, align 8
  %v1265 = load i64, ptr %slot230, align 8
  %v1266 = load i64, ptr %slot231, align 8
  %v1267 = load i64, ptr %slot232, align 8
  %call1268 = call i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64 %v1264, i64 %v1265, i64 %v1266, i64 %v1267) nomerge, !dbg !120
  store i64 %call1268, ptr %slot233, align 8
  %v1269 = load i64, ptr %slot233, align 8
  %v1270 = load i64, ptr %slot20, align 8
  %p1271 = inttoptr i64 %v1270 to ptr
  store i64 %v1269, ptr %p1271, align 8, !alias.scope !3, !noalias !4
  %v1272 = load i64, ptr %slot6, align 8
  %p1273 = inttoptr i64 %v1272 to ptr
  %ld1274 = load i32, ptr %p1273, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1274, ptr %slot234, align 8
  %v1275 = load i32, ptr %slot234, align 8
  %cv1276 = zext i32 %v1275 to i64
  %cond1277 = icmp ne i64 %cv1276, 0
  br i1 %cond1277, label %bb_rcslotdrop298, label %bb_rcslotdone298
bb_rcslotdrop298:
  %v1278 = load i64, ptr %slot6, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  store i32 0, ptr %p1279, align 4, !alias.scope !3, !noalias !4
  %v1280 = load i64, ptr %slot12, align 8
  store i64 %v1280, ptr %slot235, align 8
  %v1281 = load i64, ptr %slot7, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  %ld1283 = load i32, ptr %p1282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1283, ptr %slot236, align 8
  %v1284 = load i32, ptr %slot236, align 8
  %op1285 = and i32 %v1284, 28
  store i32 %op1285, ptr %slot237, align 8
  %v1286 = load i32, ptr %slot237, align 8
  %cv1287 = zext i32 %v1286 to i64
  %cond1288 = icmp ne i64 %cv1287, 0
  br i1 %cond1288, label %bb_rcslotrole298, label %bb_rcslotowner298
bb_rcslotrole298:
  %v1289 = load i64, ptr %slot30, align 8
  store i64 %v1289, ptr %slot238, align 8
  %v1290 = load i64, ptr %slot235, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  %ld1292 = load i64, ptr %p1291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1292, ptr %slot239, align 8
  %v1293 = load i64, ptr %slot239, align 8
  %cmp1294 = icmp ne i64 %v1293, 0
  %cv1295 = zext i1 %cmp1294 to i32
  store i32 %cv1295, ptr %slot240, align 8
  %v1296 = load i32, ptr %slot240, align 8
  %cv1297 = zext i32 %v1296 to i64
  %cond1298 = icmp ne i64 %cv1297, 0
  br i1 %cond1298, label %bb_rcgnn314, label %bb_rcgdone314
bb_rcgnn314:
  %v1299 = load i64, ptr %slot239, align 8
  %op1300 = sub i64 %v1299, 16
  store i64 %op1300, ptr %slot241, align 8
  %v1301 = load i64, ptr %slot239, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  %rgep1303 = getelementptr i8, ptr %p1302, i64 -16
  %ld1304 = load i64, ptr %rgep1303, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1304, ptr %slot242, align 8
  %v1305 = load i64, ptr %slot242, align 8
  %op1306 = and i64 %v1305, 4611686018427387906
  store i64 %op1306, ptr %slot243, align 8
  %v1307 = load i64, ptr %slot243, align 8
  %cmp1308 = icmp ne i64 %v1307, 0
  %cv1309 = zext i1 %cmp1308 to i32
  store i32 %cv1309, ptr %slot244, align 8
  %v1310 = load i32, ptr %slot244, align 8
  %cv1311 = zext i32 %v1310 to i64
  %cond1312 = icmp ne i64 %cv1311, 0
  br i1 %cond1312, label %bb_rcgclear314, label %bb_rcgcounted314
bb_rcgcounted314:
  %v1313 = load i64, ptr %slot239, align 8
  %op1314 = sub i64 %v1313, 24
  store i64 %op1314, ptr %slot245, align 8
  %v1315 = load i64, ptr %slot239, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  %rgep1317 = getelementptr i8, ptr %p1316, i64 -24
  %ld1318 = load i64, ptr %rgep1317, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1318, ptr %slot246, align 8
  %v1319 = load i64, ptr %slot246, align 8
  %op1320 = sub i64 %v1319, 1
  store i64 %op1320, ptr %slot247, align 8
  %v1321 = load i64, ptr %slot247, align 8
  %cmp1322 = icmp eq i64 %v1321, 0
  %cv1323 = zext i1 %cmp1322 to i32
  store i32 %cv1323, ptr %slot248, align 8
  %v1324 = load i32, ptr %slot248, align 8
  %cv1325 = zext i32 %v1324 to i64
  %cond1326 = icmp ne i64 %cv1325, 0
  br i1 %cond1326, label %bb_rcglast314, label %bb_rcgdec314
bb_rcglast314:
  %v1327 = load i64, ptr %slot239, align 8
  %op1328 = sub i64 %v1327, 32
  store i64 %op1328, ptr %slot249, align 8
  %v1329 = load i64, ptr %slot239, align 8
  %p1330 = inttoptr i64 %v1329 to ptr
  %rgep1331 = getelementptr i8, ptr %p1330, i64 -32
  %ld1332 = load i64, ptr %rgep1331, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1332, ptr %slot250, align 8
  %v1333 = load i64, ptr %slot250, align 8
  %cmp1334 = icmp ne i64 %v1333, 0
  %cv1335 = zext i1 %cmp1334 to i32
  store i32 %cv1335, ptr %slot251, align 8
  %v1336 = load i32, ptr %slot251, align 8
  %cv1337 = zext i32 %v1336 to i64
  %cond1338 = icmp ne i64 %cv1337, 0
  br i1 %cond1338, label %bb_rcgdec314, label %bb_rcgslow314
bb_rcgslow314:
  %v1339 = load i64, ptr %slot238, align 8
  %v1340 = load i64, ptr %slot235, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1339, i64 %v1340) nomerge, !dbg !120
  br label %bb_rcgdone314
bb_rcgdec314:
  %v1341 = load i64, ptr %slot247, align 8
  %v1342 = load i64, ptr %slot239, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %rgep1344 = getelementptr i8, ptr %p1343, i64 -24
  store i64 %v1341, ptr %rgep1344, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear314
bb_rcgclear314:
  %v1345 = load i64, ptr %slot235, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  store i64 0, ptr %p1346, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone314
bb_rcgdone314:
  br label %bb_rcslotdone298
bb_rcslotowner298:
  %v1347 = load i64, ptr %slot30, align 8
  store i64 %v1347, ptr %slot252, align 8
  %v1348 = load i64, ptr %slot235, align 8
  %p1349 = inttoptr i64 %v1348 to ptr
  %ld1350 = load i64, ptr %p1349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1350, ptr %slot253, align 8
  %v1351 = load i64, ptr %slot253, align 8
  %cmp1352 = icmp ne i64 %v1351, 0
  %cv1353 = zext i1 %cmp1352 to i32
  store i32 %cv1353, ptr %slot254, align 8
  %v1354 = load i32, ptr %slot254, align 8
  %cv1355 = zext i32 %v1354 to i64
  %cond1356 = icmp ne i64 %cv1355, 0
  br i1 %cond1356, label %bb_rcgnn329, label %bb_rcgdone329
bb_rcgnn329:
  %v1357 = load i64, ptr %slot253, align 8
  %op1358 = sub i64 %v1357, 16
  store i64 %op1358, ptr %slot255, align 8
  %v1359 = load i64, ptr %slot253, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  %rgep1361 = getelementptr i8, ptr %p1360, i64 -16
  %ld1362 = load i64, ptr %rgep1361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1362, ptr %slot256, align 8
  %v1363 = load i64, ptr %slot256, align 8
  %op1364 = and i64 %v1363, 4611686018427387906
  store i64 %op1364, ptr %slot257, align 8
  %v1365 = load i64, ptr %slot257, align 8
  %cmp1366 = icmp ne i64 %v1365, 0
  %cv1367 = zext i1 %cmp1366 to i32
  store i32 %cv1367, ptr %slot258, align 8
  %v1368 = load i32, ptr %slot258, align 8
  %cv1369 = zext i32 %v1368 to i64
  %cond1370 = icmp ne i64 %cv1369, 0
  br i1 %cond1370, label %bb_rcgclear329, label %bb_rcgcounted329
bb_rcgcounted329:
  %v1371 = load i64, ptr %slot253, align 8
  %op1372 = sub i64 %v1371, 32
  store i64 %op1372, ptr %slot259, align 8
  %v1373 = load i64, ptr %slot253, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  %rgep1375 = getelementptr i8, ptr %p1374, i64 -32
  %ld1376 = load i64, ptr %rgep1375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1376, ptr %slot260, align 8
  %v1377 = load i64, ptr %slot260, align 8
  %op1378 = sub i64 %v1377, 1
  store i64 %op1378, ptr %slot261, align 8
  %v1379 = load i64, ptr %slot261, align 8
  %cmp1380 = icmp eq i64 %v1379, 0
  %cv1381 = zext i1 %cmp1380 to i32
  store i32 %cv1381, ptr %slot262, align 8
  %v1382 = load i32, ptr %slot262, align 8
  %cv1383 = zext i32 %v1382 to i64
  %cond1384 = icmp ne i64 %cv1383, 0
  br i1 %cond1384, label %bb_rcglast329, label %bb_rcgdec329
bb_rcglast329:
  %v1385 = load i64, ptr %slot253, align 8
  %op1386 = sub i64 %v1385, 24
  store i64 %op1386, ptr %slot263, align 8
  %v1387 = load i64, ptr %slot253, align 8
  %p1388 = inttoptr i64 %v1387 to ptr
  %rgep1389 = getelementptr i8, ptr %p1388, i64 -24
  %ld1390 = load i64, ptr %rgep1389, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1390, ptr %slot264, align 8
  %v1391 = load i64, ptr %slot264, align 8
  %cmp1392 = icmp ne i64 %v1391, 0
  %cv1393 = zext i1 %cmp1392 to i32
  store i32 %cv1393, ptr %slot265, align 8
  %v1394 = load i32, ptr %slot265, align 8
  %cv1395 = zext i32 %v1394 to i64
  %cond1396 = icmp ne i64 %cv1395, 0
  br i1 %cond1396, label %bb_rcgdec329, label %bb_rcgslow329
bb_rcgslow329:
  %v1397 = load i64, ptr %slot252, align 8
  %v1398 = load i64, ptr %slot235, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1397, i64 %v1398) nomerge, !dbg !120
  br label %bb_rcgdone329
bb_rcgdec329:
  %v1399 = load i64, ptr %slot261, align 8
  %v1400 = load i64, ptr %slot253, align 8
  %p1401 = inttoptr i64 %v1400 to ptr
  %rgep1402 = getelementptr i8, ptr %p1401, i64 -32
  store i64 %v1399, ptr %rgep1402, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear329
bb_rcgclear329:
  %v1403 = load i64, ptr %slot235, align 8
  %p1404 = inttoptr i64 %v1403 to ptr
  store i64 0, ptr %p1404, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone329
bb_rcgdone329:
  br label %bb_rcslotdone298
bb_rcslotdone298:
  %v1405 = load i64, ptr %slot20, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  %ld1407 = load i64, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1407, ptr %slot266, align 8
  %v1408 = load i64, ptr %slot266, align 8
  ret i64 %v1408
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_98968328545e4811811c73fe69d48e58491f56e2b2f7d6631801ce7f303a42f6 = external global i8, align 8
@myl_lit_ccec7865dc7b502581d71aee3367b2a04dffea764d540fdcda9a17841514ad4f = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_8855e2338a0239644fa6d8638afc594de302f594debc25ce542a382b2a6572a1(i64, i64, i64, i64)
declare i64 @myl_f_ab81b26532e457905c5a882f705500b82d28df11ed7643c58b2c964282242537_rc_borrow(i64, i64, i64)
declare ptr @myl_native_bytes_concat(ptr, ptr, ptr)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_033327c3cc9b9ba3b7a1753abed1536d1ef3ef2614b836b864b5345cb9070eec", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_033327c3cc9b9ba3b7a1753abed1536d1ef3ef2614b836b864b5345cb9070eec", linkageName: "myl_f_033327c3cc9b9ba3b7a1753abed1536d1ef3ef2614b836b864b5345cb9070eec", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3837195223390902020, i64 0, !"myl_f_033327c3cc9b9ba3b7a1753abed1536d1ef3ef2614b836b864b5345cb9070eec"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!118 = !DILocation(line: 9, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
