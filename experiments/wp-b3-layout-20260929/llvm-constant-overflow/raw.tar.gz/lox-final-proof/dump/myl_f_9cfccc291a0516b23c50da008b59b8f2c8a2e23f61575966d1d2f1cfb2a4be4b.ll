target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i32, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i32, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v89 = load i64, ptr %slot1, align 8
  %op90 = add i64 %v89, 32
  store i64 %op90, ptr %slot4, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot5, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot6, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot7, align 8
  %mem97 = alloca i8, i64 16, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot8, align 8
  %mem99 = alloca i8, i64 8, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot9, align 8
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot10, align 8
  %mem103 = alloca i8, i64 8, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot11, align 8
  %mem105 = alloca i8, i64 8, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot12, align 8
  %mem107 = alloca i8, i64 16, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot13, align 8
  %v109 = load i64, ptr %slot7, align 8
  %p110 = inttoptr i64 %v109 to ptr
  store i64 0, ptr %p110, align 8, !alias.scope !3, !noalias !4
  %v111 = load i64, ptr %slot2, align 8
  %v112 = load i64, ptr %slot5, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 %v111, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot3, align 8
  %v115 = load i64, ptr %slot6, align 8
  %p116 = inttoptr i64 %v115 to ptr
  store i64 %v114, ptr %p116, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v117 = load i64, ptr %slot6, align 8
  %p118 = inttoptr i64 %v117 to ptr
  %ld119 = load i64, ptr %p118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld119, ptr %slot14, align 8
  %v120 = load i64, ptr %slot14, align 8
  %v121 = load i64, ptr %slot11, align 8
  %p122 = inttoptr i64 %v121 to ptr
  store i64 %v120, ptr %p122, align 8, !alias.scope !3, !noalias !4
  %v123 = load i64, ptr %slot11, align 8
  %p124 = inttoptr i64 %v123 to ptr
  %ld125 = load i64, ptr %p124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld125, ptr %slot15, align 8
  %v126 = load i64, ptr %slot15, align 8
  %v127 = load i64, ptr %slot8, align 8
  %p128 = inttoptr i64 %v126 to ptr
  %p129 = inttoptr i64 %v127 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p129, ptr %p128, i64 16, i1 false), !alias.scope !10000000
  %v130 = load i64, ptr %slot5, align 8
  %p131 = inttoptr i64 %v130 to ptr
  %ld132 = load i64, ptr %p131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld132, ptr %slot16, align 8
  %v133 = load i64, ptr %slot16, align 8
  %v134 = load i64, ptr %slot11, align 8
  %p135 = inttoptr i64 %v134 to ptr
  store i64 %v133, ptr %p135, align 8, !alias.scope !3, !noalias !4
  %v136 = load i64, ptr %slot11, align 8
  %p137 = inttoptr i64 %v136 to ptr
  %ld138 = load i64, ptr %p137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld138, ptr %slot17, align 8
  %v139 = load i64, ptr %slot17, align 8
  %op140 = add i64 %v139, 120
  store i64 %op140, ptr %slot18, align 8
  %v141 = load i64, ptr %slot18, align 8
  %p142 = inttoptr i64 %v141 to ptr
  %ld143 = load i64, ptr %p142, align 8, !alias.scope !4, !noalias !3
  store i64 %ld143, ptr %slot19, align 8
  %v144 = load i64, ptr %slot19, align 8
  %v145 = load i64, ptr %slot11, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot11, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot20, align 8
  %v150 = load i64, ptr %slot5, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld152, ptr %slot21, align 8
  %v153 = load i64, ptr %slot21, align 8
  %op154 = add i64 %v153, 120
  store i64 %op154, ptr %slot22, align 8
  store i64 0, ptr %slot23, align 8
  %v155 = load i64, ptr %slot22, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ld157 = load i64, ptr %p156, align 8, !alias.scope !4, !noalias !3
  store i64 %ld157, ptr %slot24, align 8
  %v158 = load i64, ptr %slot24, align 8
  %cmp159 = icmp ne i64 %v158, 0
  %cv160 = zext i1 %cmp159 to i32
  store i32 %cv160, ptr %slot25, align 8
  %v161 = load i32, ptr %slot25, align 8
  %cv162 = zext i32 %v161 to i64
  %cond163 = icmp ne i64 %cv162, 0
  br i1 %cond163, label %bb_rcguniquenn59, label %bb_rcgunique59
bb_rcguniquenn59:
  %v164 = load i64, ptr %slot24, align 8
  %op165 = sub i64 %v164, 16
  store i64 %op165, ptr %slot26, align 8
  %v166 = load i64, ptr %slot24, align 8
  %p167 = inttoptr i64 %v166 to ptr
  %rgep168 = getelementptr i8, ptr %p167, i64 -16
  %ld169 = load i64, ptr %rgep168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld169, ptr %slot27, align 8
  %v170 = load i64, ptr %slot27, align 8
  %op171 = and i64 %v170, 6917529027641081858
  store i64 %op171, ptr %slot28, align 8
  %v172 = load i64, ptr %slot28, align 8
  %cmp173 = icmp ne i64 %v172, 0
  %cv174 = zext i1 %cmp173 to i32
  store i32 %cv174, ptr %slot29, align 8
  %v175 = load i32, ptr %slot29, align 8
  %cv176 = zext i32 %v175 to i64
  %cond177 = icmp ne i64 %cv176, 0
  br i1 %cond177, label %bb_rcguniqueslow59, label %bb_rcguniquecount59
bb_rcguniquecount59:
  %v178 = load i64, ptr %slot24, align 8
  %op179 = sub i64 %v178, 32
  store i64 %op179, ptr %slot30, align 8
  %v180 = load i64, ptr %slot24, align 8
  %p181 = inttoptr i64 %v180 to ptr
  %rgep182 = getelementptr i8, ptr %p181, i64 -32
  %ld183 = load i64, ptr %rgep182, align 8, !alias.scope !9, !noalias !10
  store i64 %ld183, ptr %slot31, align 8
  %v184 = load i64, ptr %slot31, align 8
  %cmp185 = icmp ult i64 %v184, 2
  %cv186 = zext i1 %cmp185 to i32
  store i32 %cv186, ptr %slot32, align 8
  %v187 = load i32, ptr %slot32, align 8
  %cv188 = zext i32 %v187 to i64
  %cond189 = icmp ne i64 %cv188, 0
  br i1 %cond189, label %bb_rcgunique59, label %bb_rcguniqueslow59
bb_rcguniqueslow59:
  %v190 = load i64, ptr %slot1, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %p192 = inttoptr i64 ptrtoint (ptr @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a to i64) to ptr
  %v193 = load i64, ptr %slot22, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %v195 = load i64, ptr %slot23, align 8
  %p196 = inttoptr i64 %v195 to ptr
  %call197 = call i32 @myl_qbe_rc_unique_field(ptr %p191, ptr %p192, ptr %p194, ptr %p196) nomerge, !dbg !110
  store i32 %call197, ptr %slot33, align 8
  %v198 = load i32, ptr %slot33, align 8
  %cv199 = zext i32 %v198 to i64
  %cond200 = icmp ne i64 %cv199, 0
  br i1 %cond200, label %bb_rcunique69, label %bb_failure
bb_rcunique69:
  br label %bb_rcgunique59
bb_rcgunique59:
  %v201 = load i64, ptr %slot22, align 8
  %p202 = inttoptr i64 %v201 to ptr
  %ld203 = load i64, ptr %p202, align 8, !alias.scope !4, !noalias !3
  store i64 %ld203, ptr %slot34, align 8
  %v204 = load i64, ptr %slot34, align 8
  %v205 = load i64, ptr %slot11, align 8
  %p206 = inttoptr i64 %v205 to ptr
  store i64 %v204, ptr %p206, align 8, !alias.scope !3, !noalias !4
  %v207 = load i64, ptr %slot11, align 8
  %p208 = inttoptr i64 %v207 to ptr
  %ld209 = load i64, ptr %p208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld209, ptr %slot35, align 8
  %v210 = load i64, ptr %slot35, align 8
  %v211 = load i64, ptr %slot7, align 8
  %p212 = inttoptr i64 %v211 to ptr
  store i64 %v210, ptr %p212, align 8, !alias.scope !3, !noalias !4
  %v213 = load i64, ptr %slot5, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i64, ptr %p214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld215, ptr %slot36, align 8
  %v216 = load i64, ptr %slot36, align 8
  %v217 = load i64, ptr %slot11, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 %v216, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot11, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !3, !noalias !4
  store i64 %ld221, ptr %slot37, align 8
  %v222 = load i64, ptr %slot37, align 8
  %op223 = add i64 %v222, 128
  store i64 %op223, ptr %slot38, align 8
  %v224 = load i64, ptr %slot38, align 8
  %p225 = inttoptr i64 %v224 to ptr
  %ld226 = load i64, ptr %p225, align 8, !alias.scope !4, !noalias !3
  store i64 %ld226, ptr %slot39, align 8
  %v227 = load i64, ptr %slot39, align 8
  %v228 = load i64, ptr %slot11, align 8
  %p229 = inttoptr i64 %v228 to ptr
  store i64 %v227, ptr %p229, align 8, !alias.scope !3, !noalias !4
  %v230 = load i64, ptr %slot11, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot40, align 8
  %v233 = load i64, ptr %slot40, align 8
  %v234 = load i64, ptr %slot9, align 8
  %p235 = inttoptr i64 %v234 to ptr
  store i64 %v233, ptr %p235, align 8, !alias.scope !3, !noalias !4
  %v236 = load i64, ptr %slot9, align 8
  %p237 = inttoptr i64 %v236 to ptr
  %ld238 = load i64, ptr %p237, align 8, !alias.scope !3, !noalias !4
  store i64 %ld238, ptr %slot41, align 8
  %v239 = load i64, ptr %slot41, align 8
  %v240 = load i64, ptr %slot11, align 8
  %p241 = inttoptr i64 %v240 to ptr
  store i64 %v239, ptr %p241, align 8, !alias.scope !3, !noalias !4
  %v242 = load i64, ptr %slot12, align 8
  %p243 = inttoptr i64 %v242 to ptr
  store i64 0, ptr %p243, align 8, !alias.scope !3, !noalias !4
  %v244 = load i64, ptr %slot12, align 8
  %p245 = inttoptr i64 %v244 to ptr
  %ld246 = load i64, ptr %p245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld246, ptr %slot42, align 8
  %v247 = load i64, ptr %slot11, align 8
  %p248 = inttoptr i64 %v247 to ptr
  %ld249 = load i64, ptr %p248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld249, ptr %slot43, align 8
  %v250 = load i64, ptr %slot43, align 8
  %v251 = load i64, ptr %slot42, align 8
  %cmp252 = icmp slt i64 %v250, %v251
  %cv253 = zext i1 %cmp252 to i64
  store i64 %cv253, ptr %slot44, align 8
  %v254 = load i64, ptr %slot44, align 8
  %v255 = load i64, ptr %slot11, align 8
  %p256 = inttoptr i64 %v255 to ptr
  store i64 %v254, ptr %p256, align 8, !alias.scope !3, !noalias !4
  %v257 = load i64, ptr %slot11, align 8
  %p258 = inttoptr i64 %v257 to ptr
  %ld259 = load i64, ptr %p258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld259, ptr %slot45, align 8
  %v260 = load i64, ptr %slot45, align 8
  %cond261 = icmp ne i64 %v260, 0
  br i1 %cond261, label %bb_next91, label %bb_i17
bb_next91:
  %v262 = load i64, ptr %slot7, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %ld264 = load i64, ptr %p263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld264, ptr %slot46, align 8
  %v265 = load i64, ptr %slot46, align 8
  %op266 = add i64 %v265, 0
  store i64 %op266, ptr %slot47, align 8
  %v267 = load i64, ptr %slot47, align 8
  %p268 = inttoptr i64 %v267 to ptr
  %ld269 = load i64, ptr %p268, align 8, !alias.scope !6, !noalias !7
  store i64 %ld269, ptr %slot48, align 8
  %v270 = load i64, ptr %slot48, align 8
  %v271 = load i64, ptr %slot11, align 8
  %p272 = inttoptr i64 %v271 to ptr
  store i64 %v270, ptr %p272, align 8, !alias.scope !3, !noalias !4
  %v273 = load i64, ptr %slot11, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %ld275 = load i64, ptr %p274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld275, ptr %slot49, align 8
  %v276 = load i64, ptr %slot49, align 8
  %cmp277 = icmp ugt i64 %v276, 9223372036854775807
  %cv278 = zext i1 %cmp277 to i64
  store i64 %cv278, ptr %slot50, align 8
  %v279 = load i64, ptr %slot50, align 8
  %cond280 = icmp ne i64 %v279, 0
  br i1 %cond280, label %bb_cast_overflow96, label %bb_cast_ok96
bb_cast_overflow96:
  %v281 = load i64, ptr %slot1, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %v283 = load i64, ptr %slot49, align 8
  call void @myl_qbe_fail_cast(ptr %p282, i64 %v283, i64 320) nomerge, !dbg !112
  unreachable
bb_cast_ok96:
  %v284 = load i64, ptr %slot49, align 8
  %v285 = load i64, ptr %slot11, align 8
  %p286 = inttoptr i64 %v285 to ptr
  store i64 %v284, ptr %p286, align 8, !alias.scope !3, !noalias !4
  %v287 = load i64, ptr %slot9, align 8
  %p288 = inttoptr i64 %v287 to ptr
  %ld289 = load i64, ptr %p288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld289, ptr %slot51, align 8
  %v290 = load i64, ptr %slot51, align 8
  %v291 = load i64, ptr %slot12, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i64 %v290, ptr %p292, align 8, !alias.scope !3, !noalias !4
  %v293 = load i64, ptr %slot12, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot52, align 8
  %v296 = load i64, ptr %slot11, align 8
  %p297 = inttoptr i64 %v296 to ptr
  %ld298 = load i64, ptr %p297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld298, ptr %slot53, align 8
  %v299 = load i64, ptr %slot53, align 8
  %v300 = load i64, ptr %slot52, align 8
  %ovpair302 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v299, i64 %v300)
  %op301 = extractvalue { i64, i1 } %ovpair302, 0
  %ov303 = extractvalue { i64, i1 } %ovpair302, 1
  store i64 %op301, ptr %slot54, align 8
  %v304 = load i64, ptr %slot53, align 8
  %v305 = load i64, ptr %slot54, align 8
  %op306 = xor i64 %v304, %v305
  store i64 %op306, ptr %slot55, align 8
  %v307 = load i64, ptr %slot52, align 8
  %v308 = load i64, ptr %slot54, align 8
  %op309 = xor i64 %v307, %v308
  store i64 %op309, ptr %slot56, align 8
  %v310 = load i64, ptr %slot55, align 8
  %v311 = load i64, ptr %slot56, align 8
  %op312 = and i64 %v310, %v311
  store i64 %op312, ptr %slot57, align 8
  %cv313 = zext i1 %ov303 to i64
  store i64 %cv313, ptr %slot58, align 8
  %v314 = load i64, ptr %slot58, align 8
  %cond315 = icmp ne i64 %v314, 0
  br i1 %cond315, label %bb_overflow100, label %bb_checked100
bb_overflow100:
  %v316 = load i64, ptr %slot1, align 8
  %p317 = inttoptr i64 %v316 to ptr
  %v318 = load i64, ptr %slot53, align 8
  %v319 = load i64, ptr %slot52, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p317, i64 0, i64 %v318, i64 %v319, i64 64) nomerge, !dbg !114
  unreachable
bb_checked100:
  %v320 = load i64, ptr %slot54, align 8
  %v321 = load i64, ptr %slot11, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i64 %v320, ptr %p322, align 8, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot11, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %ld325 = load i64, ptr %p324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld325, ptr %slot59, align 8
  %v326 = load i64, ptr %slot59, align 8
  %v327 = load i64, ptr %slot9, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i64 %v326, ptr %p328, align 8, !alias.scope !3, !noalias !4
  br label %bb_i17
bb_i17:
  %v329 = load i64, ptr %slot9, align 8
  %p330 = inttoptr i64 %v329 to ptr
  %ld331 = load i64, ptr %p330, align 8, !alias.scope !3, !noalias !4
  store i64 %ld331, ptr %slot60, align 8
  %v332 = load i64, ptr %slot60, align 8
  %v333 = load i64, ptr %slot11, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 %v332, ptr %p334, align 8, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot8, align 8
  %v336 = load i64, ptr %slot13, align 8
  %p337 = inttoptr i64 %v335 to ptr
  %p338 = inttoptr i64 %v336 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p338, ptr %p337, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v339 = load i64, ptr %slot13, align 8
  %v340 = load i64, ptr %slot12, align 8
  %p341 = inttoptr i64 %v340 to ptr
  store i64 %v339, ptr %p341, align 8, !alias.scope !3, !noalias !4
  %v342 = load i64, ptr %slot7, align 8
  %p343 = inttoptr i64 %v342 to ptr
  %ld344 = load i64, ptr %p343, align 8, !alias.scope !3, !noalias !4
  store i64 %ld344, ptr %slot61, align 8
  %v345 = load i64, ptr %slot12, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %ld347 = load i64, ptr %p346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld347, ptr %slot62, align 8
  %v348 = load i64, ptr %slot11, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i64, ptr %p349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld350, ptr %slot63, align 8
  %v351 = load i64, ptr %slot61, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %ld353 = load i64, ptr %p352, align 8, !alias.scope !6, !noalias !7
  store i64 %ld353, ptr %slot64, align 8
  %v354 = load i64, ptr %slot63, align 8
  %v355 = load i64, ptr %slot64, align 8
  %cmp356 = icmp ult i64 %v354, %v355
  %cv357 = zext i1 %cmp356 to i64
  store i64 %cv357, ptr %slot65, align 8
  %v358 = load i64, ptr %slot65, align 8
  %cond359 = icmp ne i64 %v358, 0
  br i1 %cond359, label %bb_success113, label %bb_failed113
bb_failed113:
  %v360 = load i64, ptr %slot1, align 8
  %p361 = inttoptr i64 %v360 to ptr
  %v362 = load i64, ptr %slot63, align 8
  %v363 = load i64, ptr %slot64, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p361, i64 %v362, i64 %v363) nomerge, !dbg !116
  unreachable
bb_success113:
  %v364 = load i64, ptr %slot61, align 8
  %op365 = add i64 %v364, 32
  store i64 %op365, ptr %slot66, align 8
  %v366 = load i64, ptr %slot66, align 8
  %p367 = inttoptr i64 %v366 to ptr
  %ld368 = load i64, ptr %p367, align 8, !alias.scope !6, !noalias !7
  store i64 %ld368, ptr %slot67, align 8
  %v369 = load i64, ptr %slot63, align 8
  %op370 = mul i64 %v369, 16
  store i64 %op370, ptr %slot68, align 8
  %v371 = load i64, ptr %slot67, align 8
  %v372 = load i64, ptr %slot68, align 8
  %op373 = add i64 %v371, %v372
  store i64 %op373, ptr %slot69, align 8
  %v374 = load i64, ptr %slot12, align 8
  %p375 = inttoptr i64 %v374 to ptr
  %ld376 = load i64, ptr %p375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld376, ptr %slot70, align 8
  %v377 = load i64, ptr %slot70, align 8
  %v378 = load i64, ptr %slot69, align 8
  %p379 = inttoptr i64 %v377 to ptr
  %p380 = inttoptr i64 %v378 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p380, ptr %p379, i64 16, i1 false), !alias.scope !10000001
  %v381 = load i64, ptr %slot11, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 0, ptr %p382, align 8, !alias.scope !3, !noalias !4
  %v383 = load i64, ptr %slot5, align 8
  %p384 = inttoptr i64 %v383 to ptr
  %ld385 = load i64, ptr %p384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld385, ptr %slot71, align 8
  %v386 = load i64, ptr %slot71, align 8
  %v387 = load i64, ptr %slot11, align 8
  %p388 = inttoptr i64 %v387 to ptr
  store i64 %v386, ptr %p388, align 8, !alias.scope !3, !noalias !4
  %v389 = load i64, ptr %slot11, align 8
  %p390 = inttoptr i64 %v389 to ptr
  %ld391 = load i64, ptr %p390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld391, ptr %slot72, align 8
  %v392 = load i64, ptr %slot72, align 8
  %op393 = add i64 %v392, 128
  store i64 %op393, ptr %slot73, align 8
  %v394 = load i64, ptr %slot73, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i64, ptr %p395, align 8, !alias.scope !4, !noalias !3
  store i64 %ld396, ptr %slot74, align 8
  %v397 = load i64, ptr %slot74, align 8
  %v398 = load i64, ptr %slot11, align 8
  %p399 = inttoptr i64 %v398 to ptr
  store i64 %v397, ptr %p399, align 8, !alias.scope !3, !noalias !4
  %v400 = load i64, ptr %slot12, align 8
  %p401 = inttoptr i64 %v400 to ptr
  store i64 1, ptr %p401, align 8, !alias.scope !3, !noalias !4
  %v402 = load i64, ptr %slot12, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %ld404 = load i64, ptr %p403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld404, ptr %slot75, align 8
  %v405 = load i64, ptr %slot11, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i64, ptr %p406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld407, ptr %slot76, align 8
  %v408 = load i64, ptr %slot76, align 8
  %v409 = load i64, ptr %slot75, align 8
  %ovpair411 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v408, i64 %v409)
  %op410 = extractvalue { i64, i1 } %ovpair411, 0
  %ov412 = extractvalue { i64, i1 } %ovpair411, 1
  store i64 %op410, ptr %slot77, align 8
  %cv413 = zext i1 %ov412 to i64
  store i64 %cv413, ptr %slot78, align 8
  %v414 = load i64, ptr %slot78, align 8
  %cond415 = icmp ne i64 %v414, 0
  br i1 %cond415, label %bb_overflow134, label %bb_checked134
bb_overflow134:
  %v416 = load i64, ptr %slot1, align 8
  %p417 = inttoptr i64 %v416 to ptr
  %v418 = load i64, ptr %slot76, align 8
  %v419 = load i64, ptr %slot75, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p417, i64 0, i64 %v418, i64 %v419, i64 64) nomerge, !dbg !118
  unreachable
bb_checked134:
  %v420 = load i64, ptr %slot77, align 8
  %v421 = load i64, ptr %slot11, align 8
  %p422 = inttoptr i64 %v421 to ptr
  store i64 %v420, ptr %p422, align 8, !alias.scope !3, !noalias !4
  %v423 = load i64, ptr %slot11, align 8
  %p424 = inttoptr i64 %v423 to ptr
  %ld425 = load i64, ptr %p424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld425, ptr %slot79, align 8
  %v426 = load i64, ptr %slot79, align 8
  %v427 = load i64, ptr %slot10, align 8
  %p428 = inttoptr i64 %v427 to ptr
  store i64 %v426, ptr %p428, align 8, !alias.scope !3, !noalias !4
  %v429 = load i64, ptr %slot5, align 8
  %p430 = inttoptr i64 %v429 to ptr
  %ld431 = load i64, ptr %p430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld431, ptr %slot80, align 8
  %v432 = load i64, ptr %slot80, align 8
  %v433 = load i64, ptr %slot11, align 8
  %p434 = inttoptr i64 %v433 to ptr
  store i64 %v432, ptr %p434, align 8, !alias.scope !3, !noalias !4
  %v435 = load i64, ptr %slot5, align 8
  %p436 = inttoptr i64 %v435 to ptr
  %ld437 = load i64, ptr %p436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld437, ptr %slot81, align 8
  %v438 = load i64, ptr %slot81, align 8
  %v439 = load i64, ptr %slot11, align 8
  %p440 = inttoptr i64 %v439 to ptr
  store i64 %v438, ptr %p440, align 8, !alias.scope !3, !noalias !4
  %v441 = load i64, ptr %slot5, align 8
  %p442 = inttoptr i64 %v441 to ptr
  %ld443 = load i64, ptr %p442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld443, ptr %slot82, align 8
  %v444 = load i64, ptr %slot82, align 8
  %v445 = load i64, ptr %slot11, align 8
  %p446 = inttoptr i64 %v445 to ptr
  store i64 %v444, ptr %p446, align 8, !alias.scope !3, !noalias !4
  %v447 = load i64, ptr %slot10, align 8
  %p448 = inttoptr i64 %v447 to ptr
  %ld449 = load i64, ptr %p448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld449, ptr %slot83, align 8
  %v450 = load i64, ptr %slot83, align 8
  %v451 = load i64, ptr %slot12, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i64 %v450, ptr %p452, align 8, !alias.scope !3, !noalias !4
  %v453 = load i64, ptr %slot5, align 8
  %p454 = inttoptr i64 %v453 to ptr
  %ld455 = load i64, ptr %p454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld455, ptr %slot84, align 8
  %v456 = load i64, ptr %slot84, align 8
  %v457 = load i64, ptr %slot11, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i64 %v456, ptr %p458, align 8, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot10, align 8
  %p460 = inttoptr i64 %v459 to ptr
  %ld461 = load i64, ptr %p460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld461, ptr %slot85, align 8
  %v462 = load i64, ptr %slot5, align 8
  %p463 = inttoptr i64 %v462 to ptr
  %ld464 = load i64, ptr %p463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld464, ptr %slot86, align 8
  %v465 = load i64, ptr %slot86, align 8
  %op466 = add i64 %v465, 128
  store i64 %op466, ptr %slot87, align 8
  %v467 = load i64, ptr %slot85, align 8
  %v468 = load i64, ptr %slot87, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i64 %v467, ptr %p469, align 8, !alias.scope !4, !noalias !3
  %v470 = load i64, ptr %slot11, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i64 0, ptr %p471, align 8, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot11, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i64 0, ptr %p473, align 8, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot11, align 8
  %p475 = inttoptr i64 %v474 to ptr
  %ld476 = load i64, ptr %p475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld476, ptr %slot88, align 8
  %v477 = load i64, ptr %slot88, align 8
  ret i64 %v477
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 16v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!10000001 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b", linkageName: "myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17178790505397280554, i64 0, !"myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!110 = !DILocation(line: 5, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!112 = !DILocation(line: 14, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!114 = !DILocation(line: 16, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!116 = !DILocation(line: 20, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646735)
!118 = !DILocation(line: 25, column: 0, scope: !119)
