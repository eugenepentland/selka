target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %p_ctx) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i32, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i32, align 8
  %slot35 = alloca i32, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i32, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i32, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i32, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  %v276 = load i64, ptr %slot1, align 8
  %op277 = add i64 %v276, 32
  store i64 %op277, ptr %slot2, align 8
  %mem278 = alloca i8, i64 16, align 8
  %ptr279 = ptrtoint ptr %mem278 to i64
  store i64 %ptr279, ptr %slot3, align 8
  %mem280 = alloca i8, i64 8, align 8
  %ptr281 = ptrtoint ptr %mem280 to i64
  store i64 %ptr281, ptr %slot4, align 8
  %mem282 = alloca i8, i64 8, align 8
  %ptr283 = ptrtoint ptr %mem282 to i64
  store i64 %ptr283, ptr %slot5, align 8
  %mem284 = alloca i8, i64 8, align 8
  %ptr285 = ptrtoint ptr %mem284 to i64
  store i64 %ptr285, ptr %slot6, align 8
  %mem286 = alloca i8, i64 8, align 8
  %ptr287 = ptrtoint ptr %mem286 to i64
  store i64 %ptr287, ptr %slot7, align 8
  %mem288 = alloca i8, i64 8, align 8
  %ptr289 = ptrtoint ptr %mem288 to i64
  store i64 %ptr289, ptr %slot8, align 8
  %mem290 = alloca i8, i64 8, align 8
  %ptr291 = ptrtoint ptr %mem290 to i64
  store i64 %ptr291, ptr %slot9, align 8
  %mem292 = alloca i8, i64 8, align 8
  %ptr293 = ptrtoint ptr %mem292 to i64
  store i64 %ptr293, ptr %slot10, align 8
  %mem294 = alloca i8, i64 16, align 8
  %ptr295 = ptrtoint ptr %mem294 to i64
  store i64 %ptr295, ptr %slot11, align 8
  %mem296 = alloca i8, i64 8, align 8
  %ptr297 = ptrtoint ptr %mem296 to i64
  store i64 %ptr297, ptr %slot12, align 8
  %mem298 = alloca i8, i64 16, align 8
  %ptr299 = ptrtoint ptr %mem298 to i64
  store i64 %ptr299, ptr %slot13, align 8
  %mem300 = alloca i8, i64 8, align 8
  %ptr301 = ptrtoint ptr %mem300 to i64
  store i64 %ptr301, ptr %slot14, align 8
  %mem302 = alloca i8, i64 8, align 8
  %ptr303 = ptrtoint ptr %mem302 to i64
  store i64 %ptr303, ptr %slot15, align 8
  %mem304 = alloca i8, i64 8, align 8
  %ptr305 = ptrtoint ptr %mem304 to i64
  store i64 %ptr305, ptr %slot16, align 8
  %mem306 = alloca i8, i64 16, align 8
  %ptr307 = ptrtoint ptr %mem306 to i64
  store i64 %ptr307, ptr %slot17, align 8
  %v308 = load i64, ptr %slot14, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i64 0, ptr %p309, align 8, !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot1, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %call312 = call ptr @myl_qbe_heap(ptr %p311) nomerge, !dbg !110
  %calladdr313 = ptrtoint ptr %call312 to i64
  store i64 %calladdr313, ptr %slot18, align 8
  %v314 = load i64, ptr %slot1, align 8
  %p315 = inttoptr i64 %v314 to ptr
  %call316 = call i64 @myl_qbe_region_mark(ptr %p315) nomerge, !dbg !110
  store i64 %call316, ptr %slot19, align 8
  %v317 = load i64, ptr %slot4, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i32 0, ptr %p318, align 4, !alias.scope !3, !noalias !4
  %v319 = load i64, ptr %slot5, align 8
  %p320 = inttoptr i64 %v319 to ptr
  store i32 0, ptr %p320, align 4, !alias.scope !3, !noalias !4
  %v321 = load i64, ptr %slot6, align 8
  %p322 = inttoptr i64 %v321 to ptr
  store i32 0, ptr %p322, align 4, !alias.scope !3, !noalias !4
  %v323 = load i64, ptr %slot7, align 8
  %p324 = inttoptr i64 %v323 to ptr
  store i32 0, ptr %p324, align 4, !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot8, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i32 0, ptr %p326, align 4, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot9, align 8
  %p328 = inttoptr i64 %v327 to ptr
  store i32 0, ptr %p328, align 4, !alias.scope !3, !noalias !4
  %v329 = load i64, ptr %slot10, align 8
  %p330 = inttoptr i64 %v329 to ptr
  store i32 0, ptr %p330, align 4, !alias.scope !3, !noalias !4
  %v331 = load i64, ptr %slot5, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i32 2, ptr %p332, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v333 = load i64, ptr %slot15, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i64 0, ptr %p334, align 8, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot15, align 8
  %p336 = inttoptr i64 %v335 to ptr
  %ld337 = load i64, ptr %p336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld337, ptr %slot20, align 8
  %v338 = load i64, ptr %slot20, align 8
  %cmp339 = icmp sge i64 %v338, 0
  %cv340 = zext i1 %cmp339 to i64
  store i64 %cv340, ptr %slot21, align 8
  %v341 = load i64, ptr %slot21, align 8
  %cond342 = icmp ne i64 %v341, 0
  br i1 %cond342, label %bb_success3, label %bb_failed3
bb_failed3:
  %v343 = load i64, ptr %slot1, align 8
  %p344 = inttoptr i64 %v343 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p344) nomerge, !dbg !112
  unreachable
bb_success3:
  %v345 = load i64, ptr %slot18, align 8
  %p346 = inttoptr i64 %v345 to ptr
  %p347 = inttoptr i64 ptrtoint (ptr @myl_t_6443eeba4e1a2dfcf7724374c49aee7d6088d8d2ed268a8e00cf676e7411a0da to i64) to ptr
  %v348 = load i64, ptr %slot20, align 8
  %call349 = call ptr @myl_native_list_new(ptr %p346, ptr %p347, i64 %v348) nomerge, !dbg !112
  %calladdr350 = ptrtoint ptr %call349 to i64
  store i64 %calladdr350, ptr %slot22, align 8
  %v351 = load i64, ptr %slot22, align 8
  %cond352 = icmp ne i64 %v351, 0
  br i1 %cond352, label %bb_success5, label %bb_failed5
bb_failed5:
  %v353 = load i64, ptr %slot1, align 8
  %p354 = inttoptr i64 %v353 to ptr
  call void @myl_qbe_fail_allocation(ptr %p354) nomerge, !dbg !112
  unreachable
bb_success5:
  %v355 = load i64, ptr %slot22, align 8
  %v356 = load i64, ptr %slot15, align 8
  %p357 = inttoptr i64 %v356 to ptr
  store i64 %v355, ptr %p357, align 8, !alias.scope !3, !noalias !4
  %v358 = load i64, ptr %slot15, align 8
  %p359 = inttoptr i64 %v358 to ptr
  %ld360 = load i64, ptr %p359, align 8, !alias.scope !3, !noalias !4
  store i64 %ld360, ptr %slot23, align 8
  %v361 = load i64, ptr %slot23, align 8
  %v362 = load i64, ptr %slot12, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i64 %v361, ptr %p363, align 8, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot12, align 8
  store i64 %v364, ptr %slot24, align 8
  %v365 = load i64, ptr %slot13, align 8
  store i64 %v365, ptr %slot25, align 8
  %v366 = load i64, ptr %slot24, align 8
  %v367 = load i64, ptr %slot25, align 8
  %p368 = inttoptr i64 %v366 to ptr
  %p369 = inttoptr i64 %v367 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p369, ptr %p368, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v370 = load i64, ptr %slot9, align 8
  %p371 = inttoptr i64 %v370 to ptr
  store i32 2, ptr %p371, align 4, !alias.scope !3, !noalias !4
  %v372 = load i64, ptr %slot8, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i32 1, ptr %p373, align 4, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot11, align 8
  store i64 %v374, ptr %slot26, align 8
  %v375 = load i64, ptr %slot13, align 8
  store i64 %v375, ptr %slot27, align 8
  %v376 = load i64, ptr %slot27, align 8
  %v377 = load i64, ptr %slot26, align 8
  %p378 = inttoptr i64 %v376 to ptr
  %p379 = inttoptr i64 %v377 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p379, ptr %p378, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v380 = load i64, ptr %slot7, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i32 2, ptr %p381, align 4, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot9, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i32, ptr %p383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld384, ptr %slot28, align 8
  %v385 = load i32, ptr %slot28, align 8
  %v386 = load i64, ptr %slot7, align 8
  %p387 = inttoptr i64 %v386 to ptr
  store i32 %v385, ptr %p387, align 4, !alias.scope !3, !noalias !4
  %v388 = load i64, ptr %slot8, align 8
  %p389 = inttoptr i64 %v388 to ptr
  store i32 0, ptr %p389, align 4, !alias.scope !3, !noalias !4
  %v390 = load i64, ptr %slot6, align 8
  %p391 = inttoptr i64 %v390 to ptr
  store i32 1, ptr %p391, align 4, !alias.scope !3, !noalias !4
  %v392 = load i64, ptr %slot26, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %ld394 = load i64, ptr %p393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld394, ptr %slot29, align 8
  %v395 = load i64, ptr %slot29, align 8
  %v396 = load i64, ptr %slot15, align 8
  %p397 = inttoptr i64 %v396 to ptr
  store i64 %v395, ptr %p397, align 8, !alias.scope !3, !noalias !4
  %v398 = load i64, ptr %slot15, align 8
  %p399 = inttoptr i64 %v398 to ptr
  %ld400 = load i64, ptr %p399, align 8, !alias.scope !3, !noalias !4
  store i64 %ld400, ptr %slot30, align 8
  %v401 = load i64, ptr %slot30, align 8
  %v402 = load i64, ptr %slot12, align 8
  %p403 = inttoptr i64 %v402 to ptr
  store i64 %v401, ptr %p403, align 8, !alias.scope !3, !noalias !4
  %v404 = load i64, ptr %slot12, align 8
  store i64 %v404, ptr %slot31, align 8
  %v405 = load i64, ptr %slot6, align 8
  %p406 = inttoptr i64 %v405 to ptr
  %ld407 = load i32, ptr %p406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld407, ptr %slot32, align 8
  %v408 = load i64, ptr %slot7, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i32, ptr %p409, align 4, !alias.scope !3, !noalias !4
  store i32 %ld410, ptr %slot33, align 8
  %v411 = load i32, ptr %slot33, align 8
  %op412 = and i32 %v411, 24
  store i32 %op412, ptr %slot33, align 8
  %v413 = load i32, ptr %slot33, align 8
  %cmp414 = icmp eq i32 %v413, 0
  %cv415 = zext i1 %cmp414 to i32
  store i32 %cv415, ptr %slot34, align 8
  %v416 = load i32, ptr %slot32, align 8
  %v417 = load i32, ptr %slot34, align 8
  %op418 = and i32 %v416, %v417
  store i32 %op418, ptr %slot35, align 8
  %v419 = load i32, ptr %slot35, align 8
  %cv420 = zext i32 %v419 to i64
  %cond421 = icmp ne i64 %cv420, 0
  br i1 %cond421, label %bb_rcprivateown28, label %bb_rcprivateloan28
bb_rcprivateown28:
  %v422 = load i64, ptr %slot13, align 8
  store i64 %v422, ptr %slot36, align 8
  %v423 = load i64, ptr %slot19, align 8
  store i64 %v423, ptr %slot37, align 8
  %v424 = load i64, ptr %slot31, align 8
  %v425 = load i64, ptr %slot36, align 8
  %op426 = sub i64 %v424, %v425
  store i64 %op426, ptr %slot38, align 8
  %v427 = load i64, ptr %slot36, align 8
  %v428 = load i64, ptr %slot31, align 8
  %op429 = sub i64 %v427, %v428
  store i64 %op429, ptr %slot39, align 8
  %v430 = load i64, ptr %slot38, align 8
  %cmp431 = icmp ult i64 %v430, 8
  %cv432 = zext i1 %cmp431 to i32
  store i32 %cv432, ptr %slot40, align 8
  %v433 = load i64, ptr %slot39, align 8
  %cmp434 = icmp ult i64 %v433, 8
  %cv435 = zext i1 %cmp434 to i32
  store i32 %cv435, ptr %slot41, align 8
  %v436 = load i32, ptr %slot40, align 8
  %v437 = load i32, ptr %slot41, align 8
  %op438 = or i32 %v436, %v437
  store i32 %op438, ptr %slot42, align 8
  %v439 = load i32, ptr %slot42, align 8
  %cv440 = zext i32 %v439 to i64
  %cond441 = icmp ne i64 %cv440, 0
  br i1 %cond441, label %bb_rcmoveslow31, label %bb_rcmovecheck31
bb_rcmovecheck31:
  %v442 = load i64, ptr %slot31, align 8
  %p444 = inttoptr i64 %v442 to ptr
  %gep445 = getelementptr i8, ptr %p444, i64 0
  %op443 = ptrtoint ptr %gep445 to i64
  store i64 %op443, ptr %slot43, align 8
  %v446 = load i64, ptr %slot43, align 8
  %p447 = inttoptr i64 %v446 to ptr
  %ld448 = load i64, ptr %p447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld448, ptr %slot44, align 8
  %v449 = load i64, ptr %slot44, align 8
  %cmp450 = icmp ne i64 %v449, 0
  %cv451 = zext i1 %cmp450 to i32
  store i32 %cv451, ptr %slot45, align 8
  %v452 = load i32, ptr %slot45, align 8
  %cv453 = zext i32 %v452 to i64
  %cond454 = icmp ne i64 %cv453, 0
  br i1 %cond454, label %bb_rcmoveheader39, label %bb_rcmovenext39
bb_rcmoveheader39:
  %v455 = load i64, ptr %slot44, align 8
  %op456 = sub i64 %v455, 16
  store i64 %op456, ptr %slot46, align 8
  %v457 = load i64, ptr %slot44, align 8
  %p458 = inttoptr i64 %v457 to ptr
  %rgep459 = getelementptr i8, ptr %p458, i64 -16
  %ld460 = load i64, ptr %rgep459, align 8, !alias.scope !9, !noalias !10
  store i64 %ld460, ptr %slot47, align 8
  %v461 = load i64, ptr %slot47, align 8
  %op462 = and i64 %v461, 5764607523034234881
  store i64 %op462, ptr %slot48, align 8
  %v463 = load i64, ptr %slot48, align 8
  %cmp464 = icmp ne i64 %v463, 0
  %cv465 = zext i1 %cmp464 to i32
  store i32 %cv465, ptr %slot49, align 8
  %v466 = load i32, ptr %slot49, align 8
  %cv467 = zext i32 %v466 to i64
  %cond468 = icmp ne i64 %cv467, 0
  br i1 %cond468, label %bb_rcmoveslow31, label %bb_rcmovenext39
bb_rcmovenext39:
  %v469 = load i64, ptr %slot31, align 8
  %v470 = load i64, ptr %slot36, align 8
  %p471 = inttoptr i64 %v469 to ptr
  %p472 = inttoptr i64 %v470 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p472, ptr %p471, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v473 = load i64, ptr %slot31, align 8
  %p474 = inttoptr i64 %v473 to ptr
  store i64 0, ptr %p474, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved31
bb_rcmoveslow31:
  %v475 = load i64, ptr %slot18, align 8
  %v476 = load i64, ptr %slot36, align 8
  %v477 = load i64, ptr %slot31, align 8
  %v478 = load i64, ptr %slot37, align 8
  %cv479 = trunc i64 %v478 to i32
  %call480 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v475, i64 %v476, i64 %v477, i32 %cv479) nomerge, !dbg !114
  store i32 %call480, ptr %slot50, align 8
  %v481 = load i32, ptr %slot50, align 8
  %cv482 = zext i32 %v481 to i64
  %cond483 = icmp ne i64 %cv482, 0
  br i1 %cond483, label %bb_rcsuccess46, label %bb_rcfailure46
bb_rcfailure46:
  %v484 = load i64, ptr %slot18, align 8
  %p485 = inttoptr i64 %v484 to ptr
  %call486 = call i32 @myl_rc_take_failure(ptr %p485) nomerge, !dbg !114
  store i32 %call486, ptr %slot51, align 8
  %v487 = load i64, ptr %slot1, align 8
  %p488 = inttoptr i64 %v487 to ptr
  %v489 = load i32, ptr %slot51, align 8
  %call490 = call i32 @myl_qbe_rc_status(ptr %p488, i32 %v489) nomerge, !dbg !114
  store i32 %call490, ptr %slot52, align 8
  br label %bb_failure
bb_rcsuccess46:
  br label %bb_rcmoved31
bb_rcmoved31:
  %v491 = load i64, ptr %slot6, align 8
  %p492 = inttoptr i64 %v491 to ptr
  store i32 0, ptr %p492, align 4, !alias.scope !3, !noalias !4
  %v493 = load i64, ptr %slot9, align 8
  %p494 = inttoptr i64 %v493 to ptr
  store i32 2, ptr %p494, align 4, !alias.scope !3, !noalias !4
  %v495 = load i64, ptr %slot8, align 8
  %p496 = inttoptr i64 %v495 to ptr
  store i32 1, ptr %p496, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared28
bb_rcprivateloan28:
  %v497 = load i64, ptr %slot6, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %ld499 = load i32, ptr %p498, align 4, !alias.scope !3, !noalias !4
  store i32 %ld499, ptr %slot53, align 8
  %v500 = load i64, ptr %slot7, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i32, ptr %p501, align 4, !alias.scope !3, !noalias !4
  store i32 %ld502, ptr %slot54, align 8
  %v503 = load i32, ptr %slot54, align 8
  %cmp504 = icmp eq i32 %v503, 16
  %cv505 = zext i1 %cmp504 to i32
  store i32 %cv505, ptr %slot55, align 8
  %v506 = load i32, ptr %slot55, align 8
  %v507 = load i32, ptr %slot53, align 8
  %op508 = and i32 %v506, %v507
  store i32 %op508, ptr %slot55, align 8
  %v509 = load i32, ptr %slot55, align 8
  %cv510 = zext i32 %v509 to i64
  %cond511 = icmp ne i64 %cv510, 0
  br i1 %cond511, label %bb_rcprivatemove28, label %bb_rcprivatenew28
bb_rcprivatemove28:
  %v512 = load i64, ptr %slot13, align 8
  store i64 %v512, ptr %slot56, align 8
  %v513 = load i64, ptr %slot31, align 8
  %v514 = load i64, ptr %slot56, align 8
  %p515 = inttoptr i64 %v513 to ptr
  %p516 = inttoptr i64 %v514 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p516, ptr %p515, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v517 = load i64, ptr %slot31, align 8
  %p518 = inttoptr i64 %v517 to ptr
  store i64 0, ptr %p518, align 8, !alias.scope !3, !noalias !4
  %v519 = load i64, ptr %slot9, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i32 2, ptr %p520, align 4, !alias.scope !3, !noalias !4
  %v521 = load i64, ptr %slot9, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i32 16, ptr %p522, align 4, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot8, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 1, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot6, align 8
  %p526 = inttoptr i64 %v525 to ptr
  store i32 0, ptr %p526, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared28
bb_rcprivatenew28:
  %v527 = load i64, ptr %slot13, align 8
  store i64 %v527, ptr %slot57, align 8
  %v528 = load i64, ptr %slot31, align 8
  %p529 = inttoptr i64 %v528 to ptr
  %ld530 = load i64, ptr %p529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld530, ptr %slot58, align 8
  %v531 = load i64, ptr %slot58, align 8
  %cmp532 = icmp ne i64 %v531, 0
  %cv533 = zext i1 %cmp532 to i32
  store i32 %cv533, ptr %slot59, align 8
  %v534 = load i32, ptr %slot59, align 8
  %cv535 = zext i32 %v534 to i64
  %cond536 = icmp ne i64 %cv535, 0
  br i1 %cond536, label %bb_rcgnn64, label %bb_rcgstore64
bb_rcgnn64:
  %v537 = load i64, ptr %slot58, align 8
  %op538 = sub i64 %v537, 16
  store i64 %op538, ptr %slot60, align 8
  %v539 = load i64, ptr %slot58, align 8
  %p540 = inttoptr i64 %v539 to ptr
  %rgep541 = getelementptr i8, ptr %p540, i64 -16
  %ld542 = load i64, ptr %rgep541, align 8, !alias.scope !9, !noalias !10
  store i64 %ld542, ptr %slot61, align 8
  %v543 = load i64, ptr %slot61, align 8
  %op544 = and i64 %v543, 4611686018427387906
  store i64 %op544, ptr %slot62, align 8
  %v545 = load i64, ptr %slot62, align 8
  %cmp546 = icmp ne i64 %v545, 0
  %cv547 = zext i1 %cmp546 to i32
  store i32 %cv547, ptr %slot63, align 8
  %v548 = load i32, ptr %slot63, align 8
  %cv549 = zext i32 %v548 to i64
  %cond550 = icmp ne i64 %cv549, 0
  br i1 %cond550, label %bb_rcgstore64, label %bb_rcginc64
bb_rcginc64:
  %v551 = load i64, ptr %slot58, align 8
  %op552 = sub i64 %v551, 24
  store i64 %op552, ptr %slot64, align 8
  %v553 = load i64, ptr %slot58, align 8
  %p554 = inttoptr i64 %v553 to ptr
  %rgep555 = getelementptr i8, ptr %p554, i64 -24
  %ld556 = load i64, ptr %rgep555, align 8, !alias.scope !9, !noalias !10
  store i64 %ld556, ptr %slot65, align 8
  %v557 = load i64, ptr %slot65, align 8
  %op558 = add i64 %v557, 1
  store i64 %op558, ptr %slot66, align 8
  %v559 = load i64, ptr %slot66, align 8
  %cmp560 = icmp eq i64 %v559, 0
  %cv561 = zext i1 %cmp560 to i32
  store i32 %cv561, ptr %slot67, align 8
  %v562 = load i32, ptr %slot67, align 8
  %cv563 = zext i32 %v562 to i64
  %cond564 = icmp ne i64 %cv563, 0
  br i1 %cond564, label %bb_rcglimit64, label %bb_rcgcapacity64
bb_rcglimit64:
  %v565 = load i64, ptr %slot1, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %call567 = call i32 @myl_qbe_rc_status(ptr %p566, i32 2) nomerge, !dbg !114
  store i32 %call567, ptr %slot68, align 8
  br label %bb_failure
bb_rcgcapacity64:
  %v568 = load i64, ptr %slot66, align 8
  %v569 = load i64, ptr %slot58, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %rgep571 = getelementptr i8, ptr %p570, i64 -24
  store i64 %v568, ptr %rgep571, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore64
bb_rcgstore64:
  %v572 = load i64, ptr %slot58, align 8
  %v573 = load i64, ptr %slot57, align 8
  %p574 = inttoptr i64 %v573 to ptr
  store i64 %v572, ptr %p574, align 8, !alias.scope !3, !noalias !4
  %v575 = load i64, ptr %slot9, align 8
  %p576 = inttoptr i64 %v575 to ptr
  store i32 2, ptr %p576, align 4, !alias.scope !3, !noalias !4
  %v577 = load i64, ptr %slot9, align 8
  %p578 = inttoptr i64 %v577 to ptr
  store i32 16, ptr %p578, align 4, !alias.scope !3, !noalias !4
  %v579 = load i64, ptr %slot8, align 8
  %p580 = inttoptr i64 %v579 to ptr
  store i32 1, ptr %p580, align 4, !alias.scope !3, !noalias !4
  %v581 = load i64, ptr %slot6, align 8
  %p582 = inttoptr i64 %v581 to ptr
  %ld583 = load i32, ptr %p582, align 4, !alias.scope !3, !noalias !4
  store i32 %ld583, ptr %slot69, align 8
  %v584 = load i32, ptr %slot69, align 8
  %cv585 = zext i32 %v584 to i64
  %cond586 = icmp ne i64 %cv585, 0
  br i1 %cond586, label %bb_rcslotdrop80, label %bb_rcslotdone80
bb_rcslotdrop80:
  %v587 = load i64, ptr %slot6, align 8
  %p588 = inttoptr i64 %v587 to ptr
  store i32 0, ptr %p588, align 4, !alias.scope !3, !noalias !4
  %v589 = load i64, ptr %slot11, align 8
  store i64 %v589, ptr %slot70, align 8
  %v590 = load i64, ptr %slot7, align 8
  %p591 = inttoptr i64 %v590 to ptr
  %ld592 = load i32, ptr %p591, align 4, !alias.scope !3, !noalias !4
  store i32 %ld592, ptr %slot71, align 8
  %v593 = load i32, ptr %slot71, align 8
  %op594 = and i32 %v593, 28
  store i32 %op594, ptr %slot72, align 8
  %v595 = load i32, ptr %slot72, align 8
  %cv596 = zext i32 %v595 to i64
  %cond597 = icmp ne i64 %cv596, 0
  br i1 %cond597, label %bb_rcslotrole80, label %bb_rcslotowner80
bb_rcslotrole80:
  %v598 = load i64, ptr %slot18, align 8
  store i64 %v598, ptr %slot73, align 8
  %v599 = load i64, ptr %slot70, align 8
  %p600 = inttoptr i64 %v599 to ptr
  %ld601 = load i64, ptr %p600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld601, ptr %slot74, align 8
  %v602 = load i64, ptr %slot74, align 8
  %cmp603 = icmp ne i64 %v602, 0
  %cv604 = zext i1 %cmp603 to i32
  store i32 %cv604, ptr %slot75, align 8
  %v605 = load i32, ptr %slot75, align 8
  %cv606 = zext i32 %v605 to i64
  %cond607 = icmp ne i64 %cv606, 0
  br i1 %cond607, label %bb_rcgnn96, label %bb_rcgdone96
bb_rcgnn96:
  %v608 = load i64, ptr %slot74, align 8
  %op609 = sub i64 %v608, 16
  store i64 %op609, ptr %slot76, align 8
  %v610 = load i64, ptr %slot74, align 8
  %p611 = inttoptr i64 %v610 to ptr
  %rgep612 = getelementptr i8, ptr %p611, i64 -16
  %ld613 = load i64, ptr %rgep612, align 8, !alias.scope !9, !noalias !10
  store i64 %ld613, ptr %slot77, align 8
  %v614 = load i64, ptr %slot77, align 8
  %op615 = and i64 %v614, 4611686018427387906
  store i64 %op615, ptr %slot78, align 8
  %v616 = load i64, ptr %slot78, align 8
  %cmp617 = icmp ne i64 %v616, 0
  %cv618 = zext i1 %cmp617 to i32
  store i32 %cv618, ptr %slot79, align 8
  %v619 = load i32, ptr %slot79, align 8
  %cv620 = zext i32 %v619 to i64
  %cond621 = icmp ne i64 %cv620, 0
  br i1 %cond621, label %bb_rcgclear96, label %bb_rcgcounted96
bb_rcgcounted96:
  %v622 = load i64, ptr %slot74, align 8
  %op623 = sub i64 %v622, 24
  store i64 %op623, ptr %slot80, align 8
  %v624 = load i64, ptr %slot74, align 8
  %p625 = inttoptr i64 %v624 to ptr
  %rgep626 = getelementptr i8, ptr %p625, i64 -24
  %ld627 = load i64, ptr %rgep626, align 8, !alias.scope !9, !noalias !10
  store i64 %ld627, ptr %slot81, align 8
  %v628 = load i64, ptr %slot81, align 8
  %op629 = sub i64 %v628, 1
  store i64 %op629, ptr %slot82, align 8
  %v630 = load i64, ptr %slot82, align 8
  %cmp631 = icmp eq i64 %v630, 0
  %cv632 = zext i1 %cmp631 to i32
  store i32 %cv632, ptr %slot83, align 8
  %v633 = load i32, ptr %slot83, align 8
  %cv634 = zext i32 %v633 to i64
  %cond635 = icmp ne i64 %cv634, 0
  br i1 %cond635, label %bb_rcglast96, label %bb_rcgdec96
bb_rcglast96:
  %v636 = load i64, ptr %slot74, align 8
  %op637 = sub i64 %v636, 32
  store i64 %op637, ptr %slot84, align 8
  %v638 = load i64, ptr %slot74, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %rgep640 = getelementptr i8, ptr %p639, i64 -32
  %ld641 = load i64, ptr %rgep640, align 8, !alias.scope !9, !noalias !10
  store i64 %ld641, ptr %slot85, align 8
  %v642 = load i64, ptr %slot85, align 8
  %cmp643 = icmp ne i64 %v642, 0
  %cv644 = zext i1 %cmp643 to i32
  store i32 %cv644, ptr %slot86, align 8
  %v645 = load i32, ptr %slot86, align 8
  %cv646 = zext i32 %v645 to i64
  %cond647 = icmp ne i64 %cv646, 0
  br i1 %cond647, label %bb_rcgdec96, label %bb_rcgslow96
bb_rcgslow96:
  %v648 = load i64, ptr %slot73, align 8
  %v649 = load i64, ptr %slot70, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v648, i64 %v649) nomerge, !dbg !114
  br label %bb_rcgdone96
bb_rcgdec96:
  %v650 = load i64, ptr %slot82, align 8
  %v651 = load i64, ptr %slot74, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %rgep653 = getelementptr i8, ptr %p652, i64 -24
  store i64 %v650, ptr %rgep653, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear96
bb_rcgclear96:
  %v654 = load i64, ptr %slot70, align 8
  %p655 = inttoptr i64 %v654 to ptr
  store i64 0, ptr %p655, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone96
bb_rcgdone96:
  br label %bb_rcslotdone80
bb_rcslotowner80:
  %v656 = load i64, ptr %slot18, align 8
  store i64 %v656, ptr %slot87, align 8
  %v657 = load i64, ptr %slot70, align 8
  %p658 = inttoptr i64 %v657 to ptr
  %ld659 = load i64, ptr %p658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld659, ptr %slot88, align 8
  %v660 = load i64, ptr %slot88, align 8
  %cmp661 = icmp ne i64 %v660, 0
  %cv662 = zext i1 %cmp661 to i32
  store i32 %cv662, ptr %slot89, align 8
  %v663 = load i32, ptr %slot89, align 8
  %cv664 = zext i32 %v663 to i64
  %cond665 = icmp ne i64 %cv664, 0
  br i1 %cond665, label %bb_rcgnn111, label %bb_rcgdone111
bb_rcgnn111:
  %v666 = load i64, ptr %slot88, align 8
  %op667 = sub i64 %v666, 16
  store i64 %op667, ptr %slot90, align 8
  %v668 = load i64, ptr %slot88, align 8
  %p669 = inttoptr i64 %v668 to ptr
  %rgep670 = getelementptr i8, ptr %p669, i64 -16
  %ld671 = load i64, ptr %rgep670, align 8, !alias.scope !9, !noalias !10
  store i64 %ld671, ptr %slot91, align 8
  %v672 = load i64, ptr %slot91, align 8
  %op673 = and i64 %v672, 4611686018427387906
  store i64 %op673, ptr %slot92, align 8
  %v674 = load i64, ptr %slot92, align 8
  %cmp675 = icmp ne i64 %v674, 0
  %cv676 = zext i1 %cmp675 to i32
  store i32 %cv676, ptr %slot93, align 8
  %v677 = load i32, ptr %slot93, align 8
  %cv678 = zext i32 %v677 to i64
  %cond679 = icmp ne i64 %cv678, 0
  br i1 %cond679, label %bb_rcgclear111, label %bb_rcgcounted111
bb_rcgcounted111:
  %v680 = load i64, ptr %slot88, align 8
  %op681 = sub i64 %v680, 32
  store i64 %op681, ptr %slot94, align 8
  %v682 = load i64, ptr %slot88, align 8
  %p683 = inttoptr i64 %v682 to ptr
  %rgep684 = getelementptr i8, ptr %p683, i64 -32
  %ld685 = load i64, ptr %rgep684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld685, ptr %slot95, align 8
  %v686 = load i64, ptr %slot95, align 8
  %op687 = sub i64 %v686, 1
  store i64 %op687, ptr %slot96, align 8
  %v688 = load i64, ptr %slot96, align 8
  %cmp689 = icmp eq i64 %v688, 0
  %cv690 = zext i1 %cmp689 to i32
  store i32 %cv690, ptr %slot97, align 8
  %v691 = load i32, ptr %slot97, align 8
  %cv692 = zext i32 %v691 to i64
  %cond693 = icmp ne i64 %cv692, 0
  br i1 %cond693, label %bb_rcglast111, label %bb_rcgdec111
bb_rcglast111:
  %v694 = load i64, ptr %slot88, align 8
  %op695 = sub i64 %v694, 24
  store i64 %op695, ptr %slot98, align 8
  %v696 = load i64, ptr %slot88, align 8
  %p697 = inttoptr i64 %v696 to ptr
  %rgep698 = getelementptr i8, ptr %p697, i64 -24
  %ld699 = load i64, ptr %rgep698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld699, ptr %slot99, align 8
  %v700 = load i64, ptr %slot99, align 8
  %cmp701 = icmp ne i64 %v700, 0
  %cv702 = zext i1 %cmp701 to i32
  store i32 %cv702, ptr %slot100, align 8
  %v703 = load i32, ptr %slot100, align 8
  %cv704 = zext i32 %v703 to i64
  %cond705 = icmp ne i64 %cv704, 0
  br i1 %cond705, label %bb_rcgdec111, label %bb_rcgslow111
bb_rcgslow111:
  %v706 = load i64, ptr %slot87, align 8
  %v707 = load i64, ptr %slot70, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v706, i64 %v707) nomerge, !dbg !114
  br label %bb_rcgdone111
bb_rcgdec111:
  %v708 = load i64, ptr %slot96, align 8
  %v709 = load i64, ptr %slot88, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %rgep711 = getelementptr i8, ptr %p710, i64 -32
  store i64 %v708, ptr %rgep711, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear111
bb_rcgclear111:
  %v712 = load i64, ptr %slot70, align 8
  %p713 = inttoptr i64 %v712 to ptr
  store i64 0, ptr %p713, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone111
bb_rcgdone111:
  br label %bb_rcslotdone80
bb_rcslotdone80:
  br label %bb_rcprivateprepared28
bb_rcprivateprepared28:
  %v714 = load i64, ptr %slot4, align 8
  %p715 = inttoptr i64 %v714 to ptr
  %ld716 = load i32, ptr %p715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld716, ptr %slot101, align 8
  %v717 = load i32, ptr %slot101, align 8
  %cv718 = zext i32 %v717 to i64
  %cond719 = icmp ne i64 %cv718, 0
  br i1 %cond719, label %bb_rcslotdrop118, label %bb_rcslotdone118
bb_rcslotdrop118:
  %v720 = load i64, ptr %slot4, align 8
  %p721 = inttoptr i64 %v720 to ptr
  store i32 0, ptr %p721, align 4, !alias.scope !3, !noalias !4
  %v722 = load i64, ptr %slot14, align 8
  store i64 %v722, ptr %slot102, align 8
  %v723 = load i64, ptr %slot5, align 8
  %p724 = inttoptr i64 %v723 to ptr
  %ld725 = load i32, ptr %p724, align 4, !alias.scope !3, !noalias !4
  store i32 %ld725, ptr %slot103, align 8
  %v726 = load i32, ptr %slot103, align 8
  %op727 = and i32 %v726, 28
  store i32 %op727, ptr %slot104, align 8
  %v728 = load i32, ptr %slot104, align 8
  %cv729 = zext i32 %v728 to i64
  %cond730 = icmp ne i64 %cv729, 0
  br i1 %cond730, label %bb_rcslotrole118, label %bb_rcslotowner118
bb_rcslotrole118:
  %v731 = load i64, ptr %slot18, align 8
  store i64 %v731, ptr %slot105, align 8
  %v732 = load i64, ptr %slot102, align 8
  %p733 = inttoptr i64 %v732 to ptr
  %ld734 = load i64, ptr %p733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld734, ptr %slot106, align 8
  %v735 = load i64, ptr %slot106, align 8
  %cmp736 = icmp ne i64 %v735, 0
  %cv737 = zext i1 %cmp736 to i32
  store i32 %cv737, ptr %slot107, align 8
  %v738 = load i32, ptr %slot107, align 8
  %cv739 = zext i32 %v738 to i64
  %cond740 = icmp ne i64 %cv739, 0
  br i1 %cond740, label %bb_rcgnn134, label %bb_rcgdone134
bb_rcgnn134:
  %v741 = load i64, ptr %slot106, align 8
  %op742 = sub i64 %v741, 16
  store i64 %op742, ptr %slot108, align 8
  %v743 = load i64, ptr %slot106, align 8
  %p744 = inttoptr i64 %v743 to ptr
  %rgep745 = getelementptr i8, ptr %p744, i64 -16
  %ld746 = load i64, ptr %rgep745, align 8, !alias.scope !9, !noalias !10
  store i64 %ld746, ptr %slot109, align 8
  %v747 = load i64, ptr %slot109, align 8
  %op748 = and i64 %v747, 4611686018427387906
  store i64 %op748, ptr %slot110, align 8
  %v749 = load i64, ptr %slot110, align 8
  %cmp750 = icmp ne i64 %v749, 0
  %cv751 = zext i1 %cmp750 to i32
  store i32 %cv751, ptr %slot111, align 8
  %v752 = load i32, ptr %slot111, align 8
  %cv753 = zext i32 %v752 to i64
  %cond754 = icmp ne i64 %cv753, 0
  br i1 %cond754, label %bb_rcgclear134, label %bb_rcgcounted134
bb_rcgcounted134:
  %v755 = load i64, ptr %slot106, align 8
  %op756 = sub i64 %v755, 24
  store i64 %op756, ptr %slot112, align 8
  %v757 = load i64, ptr %slot106, align 8
  %p758 = inttoptr i64 %v757 to ptr
  %rgep759 = getelementptr i8, ptr %p758, i64 -24
  %ld760 = load i64, ptr %rgep759, align 8, !alias.scope !9, !noalias !10
  store i64 %ld760, ptr %slot113, align 8
  %v761 = load i64, ptr %slot113, align 8
  %op762 = sub i64 %v761, 1
  store i64 %op762, ptr %slot114, align 8
  %v763 = load i64, ptr %slot114, align 8
  %cmp764 = icmp eq i64 %v763, 0
  %cv765 = zext i1 %cmp764 to i32
  store i32 %cv765, ptr %slot115, align 8
  %v766 = load i32, ptr %slot115, align 8
  %cv767 = zext i32 %v766 to i64
  %cond768 = icmp ne i64 %cv767, 0
  br i1 %cond768, label %bb_rcglast134, label %bb_rcgdec134
bb_rcglast134:
  %v769 = load i64, ptr %slot106, align 8
  %op770 = sub i64 %v769, 32
  store i64 %op770, ptr %slot116, align 8
  %v771 = load i64, ptr %slot106, align 8
  %p772 = inttoptr i64 %v771 to ptr
  %rgep773 = getelementptr i8, ptr %p772, i64 -32
  %ld774 = load i64, ptr %rgep773, align 8, !alias.scope !9, !noalias !10
  store i64 %ld774, ptr %slot117, align 8
  %v775 = load i64, ptr %slot117, align 8
  %cmp776 = icmp ne i64 %v775, 0
  %cv777 = zext i1 %cmp776 to i32
  store i32 %cv777, ptr %slot118, align 8
  %v778 = load i32, ptr %slot118, align 8
  %cv779 = zext i32 %v778 to i64
  %cond780 = icmp ne i64 %cv779, 0
  br i1 %cond780, label %bb_rcgdec134, label %bb_rcgslow134
bb_rcgslow134:
  %v781 = load i64, ptr %slot105, align 8
  %v782 = load i64, ptr %slot102, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v781, i64 %v782) nomerge, !dbg !114
  br label %bb_rcgdone134
bb_rcgdec134:
  %v783 = load i64, ptr %slot114, align 8
  %v784 = load i64, ptr %slot106, align 8
  %p785 = inttoptr i64 %v784 to ptr
  %rgep786 = getelementptr i8, ptr %p785, i64 -24
  store i64 %v783, ptr %rgep786, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear134
bb_rcgclear134:
  %v787 = load i64, ptr %slot102, align 8
  %p788 = inttoptr i64 %v787 to ptr
  store i64 0, ptr %p788, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone134
bb_rcgdone134:
  br label %bb_rcslotdone118
bb_rcslotowner118:
  %v789 = load i64, ptr %slot18, align 8
  store i64 %v789, ptr %slot119, align 8
  %v790 = load i64, ptr %slot102, align 8
  %p791 = inttoptr i64 %v790 to ptr
  %ld792 = load i64, ptr %p791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld792, ptr %slot120, align 8
  %v793 = load i64, ptr %slot120, align 8
  %cmp794 = icmp ne i64 %v793, 0
  %cv795 = zext i1 %cmp794 to i32
  store i32 %cv795, ptr %slot121, align 8
  %v796 = load i32, ptr %slot121, align 8
  %cv797 = zext i32 %v796 to i64
  %cond798 = icmp ne i64 %cv797, 0
  br i1 %cond798, label %bb_rcgnn149, label %bb_rcgdone149
bb_rcgnn149:
  %v799 = load i64, ptr %slot120, align 8
  %op800 = sub i64 %v799, 16
  store i64 %op800, ptr %slot122, align 8
  %v801 = load i64, ptr %slot120, align 8
  %p802 = inttoptr i64 %v801 to ptr
  %rgep803 = getelementptr i8, ptr %p802, i64 -16
  %ld804 = load i64, ptr %rgep803, align 8, !alias.scope !9, !noalias !10
  store i64 %ld804, ptr %slot123, align 8
  %v805 = load i64, ptr %slot123, align 8
  %op806 = and i64 %v805, 4611686018427387906
  store i64 %op806, ptr %slot124, align 8
  %v807 = load i64, ptr %slot124, align 8
  %cmp808 = icmp ne i64 %v807, 0
  %cv809 = zext i1 %cmp808 to i32
  store i32 %cv809, ptr %slot125, align 8
  %v810 = load i32, ptr %slot125, align 8
  %cv811 = zext i32 %v810 to i64
  %cond812 = icmp ne i64 %cv811, 0
  br i1 %cond812, label %bb_rcgclear149, label %bb_rcgcounted149
bb_rcgcounted149:
  %v813 = load i64, ptr %slot120, align 8
  %op814 = sub i64 %v813, 32
  store i64 %op814, ptr %slot126, align 8
  %v815 = load i64, ptr %slot120, align 8
  %p816 = inttoptr i64 %v815 to ptr
  %rgep817 = getelementptr i8, ptr %p816, i64 -32
  %ld818 = load i64, ptr %rgep817, align 8, !alias.scope !9, !noalias !10
  store i64 %ld818, ptr %slot127, align 8
  %v819 = load i64, ptr %slot127, align 8
  %op820 = sub i64 %v819, 1
  store i64 %op820, ptr %slot128, align 8
  %v821 = load i64, ptr %slot128, align 8
  %cmp822 = icmp eq i64 %v821, 0
  %cv823 = zext i1 %cmp822 to i32
  store i32 %cv823, ptr %slot129, align 8
  %v824 = load i32, ptr %slot129, align 8
  %cv825 = zext i32 %v824 to i64
  %cond826 = icmp ne i64 %cv825, 0
  br i1 %cond826, label %bb_rcglast149, label %bb_rcgdec149
bb_rcglast149:
  %v827 = load i64, ptr %slot120, align 8
  %op828 = sub i64 %v827, 24
  store i64 %op828, ptr %slot130, align 8
  %v829 = load i64, ptr %slot120, align 8
  %p830 = inttoptr i64 %v829 to ptr
  %rgep831 = getelementptr i8, ptr %p830, i64 -24
  %ld832 = load i64, ptr %rgep831, align 8, !alias.scope !9, !noalias !10
  store i64 %ld832, ptr %slot131, align 8
  %v833 = load i64, ptr %slot131, align 8
  %cmp834 = icmp ne i64 %v833, 0
  %cv835 = zext i1 %cmp834 to i32
  store i32 %cv835, ptr %slot132, align 8
  %v836 = load i32, ptr %slot132, align 8
  %cv837 = zext i32 %v836 to i64
  %cond838 = icmp ne i64 %cv837, 0
  br i1 %cond838, label %bb_rcgdec149, label %bb_rcgslow149
bb_rcgslow149:
  %v839 = load i64, ptr %slot119, align 8
  %v840 = load i64, ptr %slot102, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v839, i64 %v840) nomerge, !dbg !114
  br label %bb_rcgdone149
bb_rcgdec149:
  %v841 = load i64, ptr %slot128, align 8
  %v842 = load i64, ptr %slot120, align 8
  %p843 = inttoptr i64 %v842 to ptr
  %rgep844 = getelementptr i8, ptr %p843, i64 -32
  store i64 %v841, ptr %rgep844, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear149
bb_rcgclear149:
  %v845 = load i64, ptr %slot102, align 8
  %p846 = inttoptr i64 %v845 to ptr
  store i64 0, ptr %p846, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone149
bb_rcgdone149:
  br label %bb_rcslotdone118
bb_rcslotdone118:
  %v847 = load i64, ptr %slot14, align 8
  store i64 %v847, ptr %slot133, align 8
  %v848 = load i64, ptr %slot13, align 8
  store i64 %v848, ptr %slot134, align 8
  %v849 = load i64, ptr %slot134, align 8
  %v850 = load i64, ptr %slot133, align 8
  %p851 = inttoptr i64 %v849 to ptr
  %p852 = inttoptr i64 %v850 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p852, ptr %p851, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v853 = load i64, ptr %slot8, align 8
  %p854 = inttoptr i64 %v853 to ptr
  store i32 0, ptr %p854, align 4, !alias.scope !3, !noalias !4
  %v855 = load i64, ptr %slot5, align 8
  %p856 = inttoptr i64 %v855 to ptr
  store i32 2, ptr %p856, align 4, !alias.scope !3, !noalias !4
  %v857 = load i64, ptr %slot9, align 8
  %p858 = inttoptr i64 %v857 to ptr
  %ld859 = load i32, ptr %p858, align 4, !alias.scope !3, !noalias !4
  store i32 %ld859, ptr %slot135, align 8
  %v860 = load i32, ptr %slot135, align 8
  %v861 = load i64, ptr %slot5, align 8
  %p862 = inttoptr i64 %v861 to ptr
  store i32 %v860, ptr %p862, align 4, !alias.scope !3, !noalias !4
  %v863 = load i64, ptr %slot4, align 8
  %p864 = inttoptr i64 %v863 to ptr
  store i32 1, ptr %p864, align 4, !alias.scope !3, !noalias !4
  %v865 = load i64, ptr %slot14, align 8
  %p866 = inttoptr i64 %v865 to ptr
  %ld867 = load i64, ptr %p866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld867, ptr %slot136, align 8
  %v868 = load i64, ptr %slot136, align 8
  %v869 = load i64, ptr %slot15, align 8
  %p870 = inttoptr i64 %v869 to ptr
  store i64 %v868, ptr %p870, align 8, !alias.scope !3, !noalias !4
  %v871 = load i64, ptr %slot16, align 8
  %p872 = inttoptr i64 %v871 to ptr
  store i64 0, ptr %p872, align 8, !alias.scope !3, !noalias !4
  %v873 = load i64, ptr %slot17, align 8
  store i64 %v873, ptr %slot137, align 8
  %v874 = load i64, ptr %slot137, align 8
  %p875 = inttoptr i64 %v874 to ptr
  store i64 0, ptr %p875, align 8, !alias.scope !3, !noalias !4
  %v876 = load i64, ptr %slot137, align 8
  %p878 = inttoptr i64 %v876 to ptr
  %gep879 = getelementptr i8, ptr %p878, i64 8
  %op877 = ptrtoint ptr %gep879 to i64
  store i64 %op877, ptr %slot138, align 8
  %v880 = load i64, ptr %slot138, align 8
  %p881 = inttoptr i64 %v880 to ptr
  store i64 0, ptr %p881, align 8, !alias.scope !3, !noalias !4
  %v882 = load i64, ptr %slot10, align 8
  %p883 = inttoptr i64 %v882 to ptr
  store i32 1, ptr %p883, align 4, !alias.scope !3, !noalias !4
  %v884 = load i64, ptr %slot19, align 8
  store i64 %v884, ptr %slot139, align 8
  %v885 = load i64, ptr %slot15, align 8
  %p886 = inttoptr i64 %v885 to ptr
  %ld887 = load i64, ptr %p886, align 8, !alias.scope !3, !noalias !4
  store i64 %ld887, ptr %slot140, align 8
  %v888 = load i64, ptr %slot140, align 8
  %v889 = load i64, ptr %slot12, align 8
  %p890 = inttoptr i64 %v889 to ptr
  store i64 %v888, ptr %p890, align 8, !alias.scope !3, !noalias !4
  %v891 = load i64, ptr %slot12, align 8
  store i64 %v891, ptr %slot141, align 8
  %v892 = load i64, ptr %slot137, align 8
  %p894 = inttoptr i64 %v892 to ptr
  %gep895 = getelementptr i8, ptr %p894, i64 0
  %op893 = ptrtoint ptr %gep895 to i64
  store i64 %op893, ptr %slot142, align 8
  %v896 = load i64, ptr %slot15, align 8
  %p897 = inttoptr i64 %v896 to ptr
  %ld898 = load i64, ptr %p897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld898, ptr %slot143, align 8
  %v899 = load i64, ptr %slot143, align 8
  %v900 = load i64, ptr %slot12, align 8
  %p901 = inttoptr i64 %v900 to ptr
  store i64 %v899, ptr %p901, align 8, !alias.scope !3, !noalias !4
  %v902 = load i64, ptr %slot12, align 8
  store i64 %v902, ptr %slot144, align 8
  %v903 = load i64, ptr %slot6, align 8
  %p904 = inttoptr i64 %v903 to ptr
  %ld905 = load i32, ptr %p904, align 4, !alias.scope !3, !noalias !4
  store i32 %ld905, ptr %slot145, align 8
  %v906 = load i64, ptr %slot7, align 8
  %p907 = inttoptr i64 %v906 to ptr
  %ld908 = load i32, ptr %p907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld908, ptr %slot146, align 8
  %v909 = load i32, ptr %slot146, align 8
  %op910 = and i32 %v909, 24
  store i32 %op910, ptr %slot146, align 8
  %v911 = load i32, ptr %slot146, align 8
  %cmp912 = icmp eq i32 %v911, 0
  %cv913 = zext i1 %cmp912 to i32
  store i32 %cv913, ptr %slot147, align 8
  %v914 = load i32, ptr %slot145, align 8
  %v915 = load i32, ptr %slot147, align 8
  %op916 = and i32 %v914, %v915
  store i32 %op916, ptr %slot148, align 8
  %v917 = load i32, ptr %slot148, align 8
  %cv918 = zext i32 %v917 to i64
  %cond919 = icmp ne i64 %cv918, 0
  br i1 %cond919, label %bb_rctake171, label %bb_rccopy171
bb_rctake171:
  %v920 = load i64, ptr %slot13, align 8
  store i64 %v920, ptr %slot149, align 8
  %v921 = load i64, ptr %slot19, align 8
  store i64 %v921, ptr %slot150, align 8
  %v922 = load i64, ptr %slot144, align 8
  %v923 = load i64, ptr %slot149, align 8
  %op924 = sub i64 %v922, %v923
  store i64 %op924, ptr %slot151, align 8
  %v925 = load i64, ptr %slot149, align 8
  %v926 = load i64, ptr %slot144, align 8
  %op927 = sub i64 %v925, %v926
  store i64 %op927, ptr %slot152, align 8
  %v928 = load i64, ptr %slot151, align 8
  %cmp929 = icmp ult i64 %v928, 8
  %cv930 = zext i1 %cmp929 to i32
  store i32 %cv930, ptr %slot153, align 8
  %v931 = load i64, ptr %slot152, align 8
  %cmp932 = icmp ult i64 %v931, 8
  %cv933 = zext i1 %cmp932 to i32
  store i32 %cv933, ptr %slot154, align 8
  %v934 = load i32, ptr %slot153, align 8
  %v935 = load i32, ptr %slot154, align 8
  %op936 = or i32 %v934, %v935
  store i32 %op936, ptr %slot155, align 8
  %v937 = load i32, ptr %slot155, align 8
  %cv938 = zext i32 %v937 to i64
  %cond939 = icmp ne i64 %cv938, 0
  br i1 %cond939, label %bb_rcmoveslow180, label %bb_rcmovecheck180
bb_rcmovecheck180:
  %v940 = load i64, ptr %slot144, align 8
  %p942 = inttoptr i64 %v940 to ptr
  %gep943 = getelementptr i8, ptr %p942, i64 0
  %op941 = ptrtoint ptr %gep943 to i64
  store i64 %op941, ptr %slot156, align 8
  %v944 = load i64, ptr %slot156, align 8
  %p945 = inttoptr i64 %v944 to ptr
  %ld946 = load i64, ptr %p945, align 8, !alias.scope !3, !noalias !4
  store i64 %ld946, ptr %slot157, align 8
  %v947 = load i64, ptr %slot157, align 8
  %cmp948 = icmp ne i64 %v947, 0
  %cv949 = zext i1 %cmp948 to i32
  store i32 %cv949, ptr %slot158, align 8
  %v950 = load i32, ptr %slot158, align 8
  %cv951 = zext i32 %v950 to i64
  %cond952 = icmp ne i64 %cv951, 0
  br i1 %cond952, label %bb_rcmoveheader188, label %bb_rcmovenext188
bb_rcmoveheader188:
  %v953 = load i64, ptr %slot157, align 8
  %op954 = sub i64 %v953, 16
  store i64 %op954, ptr %slot159, align 8
  %v955 = load i64, ptr %slot157, align 8
  %p956 = inttoptr i64 %v955 to ptr
  %rgep957 = getelementptr i8, ptr %p956, i64 -16
  %ld958 = load i64, ptr %rgep957, align 8, !alias.scope !9, !noalias !10
  store i64 %ld958, ptr %slot160, align 8
  %v959 = load i64, ptr %slot160, align 8
  %op960 = and i64 %v959, 5764607523034234881
  store i64 %op960, ptr %slot161, align 8
  %v961 = load i64, ptr %slot161, align 8
  %cmp962 = icmp ne i64 %v961, 0
  %cv963 = zext i1 %cmp962 to i32
  store i32 %cv963, ptr %slot162, align 8
  %v964 = load i32, ptr %slot162, align 8
  %cv965 = zext i32 %v964 to i64
  %cond966 = icmp ne i64 %cv965, 0
  br i1 %cond966, label %bb_rcmoveslow180, label %bb_rcmovenext188
bb_rcmovenext188:
  %v967 = load i64, ptr %slot144, align 8
  %v968 = load i64, ptr %slot149, align 8
  %p969 = inttoptr i64 %v967 to ptr
  %p970 = inttoptr i64 %v968 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p970, ptr %p969, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v971 = load i64, ptr %slot144, align 8
  %p972 = inttoptr i64 %v971 to ptr
  store i64 0, ptr %p972, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved180
bb_rcmoveslow180:
  %v973 = load i64, ptr %slot18, align 8
  %v974 = load i64, ptr %slot149, align 8
  %v975 = load i64, ptr %slot144, align 8
  %v976 = load i64, ptr %slot150, align 8
  %cv977 = trunc i64 %v976 to i32
  %call978 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64 %v973, i64 %v974, i64 %v975, i32 %cv977) nomerge, !dbg !116
  store i32 %call978, ptr %slot163, align 8
  %v979 = load i32, ptr %slot163, align 8
  %cv980 = zext i32 %v979 to i64
  %cond981 = icmp ne i64 %cv980, 0
  br i1 %cond981, label %bb_rcsuccess195, label %bb_rcfailure195
bb_rcfailure195:
  %v982 = load i64, ptr %slot18, align 8
  %p983 = inttoptr i64 %v982 to ptr
  %call984 = call i32 @myl_rc_take_failure(ptr %p983) nomerge, !dbg !116
  store i32 %call984, ptr %slot164, align 8
  %v985 = load i64, ptr %slot1, align 8
  %p986 = inttoptr i64 %v985 to ptr
  %v987 = load i32, ptr %slot164, align 8
  %call988 = call i32 @myl_qbe_rc_status(ptr %p986, i32 %v987) nomerge, !dbg !116
  store i32 %call988, ptr %slot165, align 8
  br label %bb_failure
bb_rcsuccess195:
  br label %bb_rcmoved180
bb_rcmoved180:
  %v989 = load i64, ptr %slot6, align 8
  %p990 = inttoptr i64 %v989 to ptr
  store i32 0, ptr %p990, align 4, !alias.scope !3, !noalias !4
  %v991 = load i64, ptr %slot9, align 8
  %p992 = inttoptr i64 %v991 to ptr
  store i32 2, ptr %p992, align 4, !alias.scope !3, !noalias !4
  %v993 = load i64, ptr %slot8, align 8
  %p994 = inttoptr i64 %v993 to ptr
  store i32 1, ptr %p994, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared171
bb_rccopy171:
  %v995 = load i64, ptr %slot13, align 8
  store i64 %v995, ptr %slot166, align 8
  %v996 = load i64, ptr %slot19, align 8
  store i64 %v996, ptr %slot167, align 8
  %v997 = load i64, ptr %slot144, align 8
  %p998 = inttoptr i64 %v997 to ptr
  %ld999 = load i64, ptr %p998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld999, ptr %slot168, align 8
  %v1000 = load i64, ptr %slot168, align 8
  %cmp1001 = icmp ne i64 %v1000, 0
  %cv1002 = zext i1 %cmp1001 to i32
  store i32 %cv1002, ptr %slot169, align 8
  %v1003 = load i32, ptr %slot169, align 8
  %cv1004 = zext i32 %v1003 to i64
  %cond1005 = icmp ne i64 %cv1004, 0
  br i1 %cond1005, label %bb_rcgnn204, label %bb_rcgplain204
bb_rcgnn204:
  %v1006 = load i64, ptr %slot168, align 8
  %op1007 = sub i64 %v1006, 16
  store i64 %op1007, ptr %slot170, align 8
  %v1008 = load i64, ptr %slot168, align 8
  %p1009 = inttoptr i64 %v1008 to ptr
  %rgep1010 = getelementptr i8, ptr %p1009, i64 -16
  %ld1011 = load i64, ptr %rgep1010, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1011, ptr %slot171, align 8
  %v1012 = load i64, ptr %slot171, align 8
  %op1013 = and i64 %v1012, 4611686018427387906
  store i64 %op1013, ptr %slot172, align 8
  %v1014 = load i64, ptr %slot172, align 8
  %cmp1015 = icmp ne i64 %v1014, 0
  %cv1016 = zext i1 %cmp1015 to i32
  store i32 %cv1016, ptr %slot173, align 8
  %v1017 = load i32, ptr %slot173, align 8
  %cv1018 = zext i32 %v1017 to i64
  %cond1019 = icmp ne i64 %cv1018, 0
  br i1 %cond1019, label %bb_rcgspecial204, label %bb_rcginc204
bb_rcginc204:
  %v1020 = load i64, ptr %slot168, align 8
  %op1021 = sub i64 %v1020, 32
  store i64 %op1021, ptr %slot174, align 8
  %v1022 = load i64, ptr %slot168, align 8
  %p1023 = inttoptr i64 %v1022 to ptr
  %rgep1024 = getelementptr i8, ptr %p1023, i64 -32
  %ld1025 = load i64, ptr %rgep1024, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1025, ptr %slot175, align 8
  %v1026 = load i64, ptr %slot175, align 8
  %op1027 = add i64 %v1026, 1
  store i64 %op1027, ptr %slot176, align 8
  %v1028 = load i64, ptr %slot176, align 8
  %cmp1029 = icmp eq i64 %v1028, 0
  %cv1030 = zext i1 %cmp1029 to i32
  store i32 %cv1030, ptr %slot177, align 8
  %v1031 = load i32, ptr %slot177, align 8
  %cv1032 = zext i32 %v1031 to i64
  %cond1033 = icmp ne i64 %cv1032, 0
  br i1 %cond1033, label %bb_rcglimit204, label %bb_rcgcapacity204
bb_rcglimit204:
  %v1034 = load i64, ptr %slot1, align 8
  %p1035 = inttoptr i64 %v1034 to ptr
  %call1036 = call i32 @myl_qbe_rc_status(ptr %p1035, i32 2) nomerge, !dbg !116
  store i32 %call1036, ptr %slot178, align 8
  br label %bb_failure
bb_rcgcapacity204:
  %v1037 = load i64, ptr %slot176, align 8
  %v1038 = load i64, ptr %slot168, align 8
  %p1039 = inttoptr i64 %v1038 to ptr
  %rgep1040 = getelementptr i8, ptr %p1039, i64 -32
  store i64 %v1037, ptr %rgep1040, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain204
bb_rcgspecial204:
  %v1041 = load i64, ptr %slot171, align 8
  %op1042 = and i64 %v1041, 4611686018427387904
  store i64 %op1042, ptr %slot179, align 8
  %v1043 = load i64, ptr %slot179, align 8
  %cmp1044 = icmp ne i64 %v1043, 0
  %cv1045 = zext i1 %cmp1044 to i32
  store i32 %cv1045, ptr %slot180, align 8
  %v1046 = load i32, ptr %slot180, align 8
  %cv1047 = zext i32 %v1046 to i64
  %cond1048 = icmp ne i64 %cv1047, 0
  br i1 %cond1048, label %bb_rcgslow204, label %bb_rcgplain204
bb_rcgslow204:
  %v1049 = load i64, ptr %slot18, align 8
  %v1050 = load i64, ptr %slot166, align 8
  %v1051 = load i64, ptr %slot144, align 8
  %v1052 = load i64, ptr %slot167, align 8
  %cv1053 = trunc i64 %v1052 to i32
  %call1054 = call i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64 %v1049, i64 %v1050, i64 %v1051, i32 %cv1053) nomerge, !dbg !116
  store i32 %call1054, ptr %slot181, align 8
  %v1055 = load i32, ptr %slot181, align 8
  %cv1056 = zext i32 %v1055 to i64
  %cond1057 = icmp ne i64 %cv1056, 0
  br i1 %cond1057, label %bb_rcsuccess218, label %bb_rcfailure218
bb_rcfailure218:
  %v1058 = load i64, ptr %slot18, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %call1060 = call i32 @myl_rc_take_failure(ptr %p1059) nomerge, !dbg !116
  store i32 %call1060, ptr %slot182, align 8
  %v1061 = load i64, ptr %slot1, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  %v1063 = load i32, ptr %slot182, align 8
  %call1064 = call i32 @myl_qbe_rc_status(ptr %p1062, i32 %v1063) nomerge, !dbg !116
  store i32 %call1064, ptr %slot183, align 8
  br label %bb_failure
bb_rcsuccess218:
  br label %bb_rcgdone204
bb_rcgplain204:
  %v1065 = load i64, ptr %slot168, align 8
  %v1066 = load i64, ptr %slot166, align 8
  %p1067 = inttoptr i64 %v1066 to ptr
  store i64 %v1065, ptr %p1067, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone204
bb_rcgdone204:
  %v1068 = load i64, ptr %slot9, align 8
  %p1069 = inttoptr i64 %v1068 to ptr
  store i32 2, ptr %p1069, align 4, !alias.scope !3, !noalias !4
  %v1070 = load i64, ptr %slot8, align 8
  %p1071 = inttoptr i64 %v1070 to ptr
  store i32 1, ptr %p1071, align 4, !alias.scope !3, !noalias !4
  %v1072 = load i64, ptr %slot6, align 8
  %p1073 = inttoptr i64 %v1072 to ptr
  %ld1074 = load i32, ptr %p1073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1074, ptr %slot184, align 8
  %v1075 = load i32, ptr %slot184, align 8
  %cv1076 = zext i32 %v1075 to i64
  %cond1077 = icmp ne i64 %cv1076, 0
  br i1 %cond1077, label %bb_rcslotdrop225, label %bb_rcslotdone225
bb_rcslotdrop225:
  %v1078 = load i64, ptr %slot6, align 8
  %p1079 = inttoptr i64 %v1078 to ptr
  store i32 0, ptr %p1079, align 4, !alias.scope !3, !noalias !4
  %v1080 = load i64, ptr %slot11, align 8
  store i64 %v1080, ptr %slot185, align 8
  %v1081 = load i64, ptr %slot7, align 8
  %p1082 = inttoptr i64 %v1081 to ptr
  %ld1083 = load i32, ptr %p1082, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1083, ptr %slot186, align 8
  %v1084 = load i32, ptr %slot186, align 8
  %op1085 = and i32 %v1084, 28
  store i32 %op1085, ptr %slot187, align 8
  %v1086 = load i32, ptr %slot187, align 8
  %cv1087 = zext i32 %v1086 to i64
  %cond1088 = icmp ne i64 %cv1087, 0
  br i1 %cond1088, label %bb_rcslotrole225, label %bb_rcslotowner225
bb_rcslotrole225:
  %v1089 = load i64, ptr %slot18, align 8
  store i64 %v1089, ptr %slot188, align 8
  %v1090 = load i64, ptr %slot185, align 8
  %p1091 = inttoptr i64 %v1090 to ptr
  %ld1092 = load i64, ptr %p1091, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1092, ptr %slot189, align 8
  %v1093 = load i64, ptr %slot189, align 8
  %cmp1094 = icmp ne i64 %v1093, 0
  %cv1095 = zext i1 %cmp1094 to i32
  store i32 %cv1095, ptr %slot190, align 8
  %v1096 = load i32, ptr %slot190, align 8
  %cv1097 = zext i32 %v1096 to i64
  %cond1098 = icmp ne i64 %cv1097, 0
  br i1 %cond1098, label %bb_rcgnn241, label %bb_rcgdone241
bb_rcgnn241:
  %v1099 = load i64, ptr %slot189, align 8
  %op1100 = sub i64 %v1099, 16
  store i64 %op1100, ptr %slot191, align 8
  %v1101 = load i64, ptr %slot189, align 8
  %p1102 = inttoptr i64 %v1101 to ptr
  %rgep1103 = getelementptr i8, ptr %p1102, i64 -16
  %ld1104 = load i64, ptr %rgep1103, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1104, ptr %slot192, align 8
  %v1105 = load i64, ptr %slot192, align 8
  %op1106 = and i64 %v1105, 4611686018427387906
  store i64 %op1106, ptr %slot193, align 8
  %v1107 = load i64, ptr %slot193, align 8
  %cmp1108 = icmp ne i64 %v1107, 0
  %cv1109 = zext i1 %cmp1108 to i32
  store i32 %cv1109, ptr %slot194, align 8
  %v1110 = load i32, ptr %slot194, align 8
  %cv1111 = zext i32 %v1110 to i64
  %cond1112 = icmp ne i64 %cv1111, 0
  br i1 %cond1112, label %bb_rcgclear241, label %bb_rcgcounted241
bb_rcgcounted241:
  %v1113 = load i64, ptr %slot189, align 8
  %op1114 = sub i64 %v1113, 24
  store i64 %op1114, ptr %slot195, align 8
  %v1115 = load i64, ptr %slot189, align 8
  %p1116 = inttoptr i64 %v1115 to ptr
  %rgep1117 = getelementptr i8, ptr %p1116, i64 -24
  %ld1118 = load i64, ptr %rgep1117, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1118, ptr %slot196, align 8
  %v1119 = load i64, ptr %slot196, align 8
  %op1120 = sub i64 %v1119, 1
  store i64 %op1120, ptr %slot197, align 8
  %v1121 = load i64, ptr %slot197, align 8
  %cmp1122 = icmp eq i64 %v1121, 0
  %cv1123 = zext i1 %cmp1122 to i32
  store i32 %cv1123, ptr %slot198, align 8
  %v1124 = load i32, ptr %slot198, align 8
  %cv1125 = zext i32 %v1124 to i64
  %cond1126 = icmp ne i64 %cv1125, 0
  br i1 %cond1126, label %bb_rcglast241, label %bb_rcgdec241
bb_rcglast241:
  %v1127 = load i64, ptr %slot189, align 8
  %op1128 = sub i64 %v1127, 32
  store i64 %op1128, ptr %slot199, align 8
  %v1129 = load i64, ptr %slot189, align 8
  %p1130 = inttoptr i64 %v1129 to ptr
  %rgep1131 = getelementptr i8, ptr %p1130, i64 -32
  %ld1132 = load i64, ptr %rgep1131, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1132, ptr %slot200, align 8
  %v1133 = load i64, ptr %slot200, align 8
  %cmp1134 = icmp ne i64 %v1133, 0
  %cv1135 = zext i1 %cmp1134 to i32
  store i32 %cv1135, ptr %slot201, align 8
  %v1136 = load i32, ptr %slot201, align 8
  %cv1137 = zext i32 %v1136 to i64
  %cond1138 = icmp ne i64 %cv1137, 0
  br i1 %cond1138, label %bb_rcgdec241, label %bb_rcgslow241
bb_rcgslow241:
  %v1139 = load i64, ptr %slot188, align 8
  %v1140 = load i64, ptr %slot185, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v1139, i64 %v1140) nomerge, !dbg !116
  br label %bb_rcgdone241
bb_rcgdec241:
  %v1141 = load i64, ptr %slot197, align 8
  %v1142 = load i64, ptr %slot189, align 8
  %p1143 = inttoptr i64 %v1142 to ptr
  %rgep1144 = getelementptr i8, ptr %p1143, i64 -24
  store i64 %v1141, ptr %rgep1144, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear241
bb_rcgclear241:
  %v1145 = load i64, ptr %slot185, align 8
  %p1146 = inttoptr i64 %v1145 to ptr
  store i64 0, ptr %p1146, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone241
bb_rcgdone241:
  br label %bb_rcslotdone225
bb_rcslotowner225:
  %v1147 = load i64, ptr %slot18, align 8
  store i64 %v1147, ptr %slot202, align 8
  %v1148 = load i64, ptr %slot185, align 8
  %p1149 = inttoptr i64 %v1148 to ptr
  %ld1150 = load i64, ptr %p1149, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1150, ptr %slot203, align 8
  %v1151 = load i64, ptr %slot203, align 8
  %cmp1152 = icmp ne i64 %v1151, 0
  %cv1153 = zext i1 %cmp1152 to i32
  store i32 %cv1153, ptr %slot204, align 8
  %v1154 = load i32, ptr %slot204, align 8
  %cv1155 = zext i32 %v1154 to i64
  %cond1156 = icmp ne i64 %cv1155, 0
  br i1 %cond1156, label %bb_rcgnn256, label %bb_rcgdone256
bb_rcgnn256:
  %v1157 = load i64, ptr %slot203, align 8
  %op1158 = sub i64 %v1157, 16
  store i64 %op1158, ptr %slot205, align 8
  %v1159 = load i64, ptr %slot203, align 8
  %p1160 = inttoptr i64 %v1159 to ptr
  %rgep1161 = getelementptr i8, ptr %p1160, i64 -16
  %ld1162 = load i64, ptr %rgep1161, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1162, ptr %slot206, align 8
  %v1163 = load i64, ptr %slot206, align 8
  %op1164 = and i64 %v1163, 4611686018427387906
  store i64 %op1164, ptr %slot207, align 8
  %v1165 = load i64, ptr %slot207, align 8
  %cmp1166 = icmp ne i64 %v1165, 0
  %cv1167 = zext i1 %cmp1166 to i32
  store i32 %cv1167, ptr %slot208, align 8
  %v1168 = load i32, ptr %slot208, align 8
  %cv1169 = zext i32 %v1168 to i64
  %cond1170 = icmp ne i64 %cv1169, 0
  br i1 %cond1170, label %bb_rcgclear256, label %bb_rcgcounted256
bb_rcgcounted256:
  %v1171 = load i64, ptr %slot203, align 8
  %op1172 = sub i64 %v1171, 32
  store i64 %op1172, ptr %slot209, align 8
  %v1173 = load i64, ptr %slot203, align 8
  %p1174 = inttoptr i64 %v1173 to ptr
  %rgep1175 = getelementptr i8, ptr %p1174, i64 -32
  %ld1176 = load i64, ptr %rgep1175, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1176, ptr %slot210, align 8
  %v1177 = load i64, ptr %slot210, align 8
  %op1178 = sub i64 %v1177, 1
  store i64 %op1178, ptr %slot211, align 8
  %v1179 = load i64, ptr %slot211, align 8
  %cmp1180 = icmp eq i64 %v1179, 0
  %cv1181 = zext i1 %cmp1180 to i32
  store i32 %cv1181, ptr %slot212, align 8
  %v1182 = load i32, ptr %slot212, align 8
  %cv1183 = zext i32 %v1182 to i64
  %cond1184 = icmp ne i64 %cv1183, 0
  br i1 %cond1184, label %bb_rcglast256, label %bb_rcgdec256
bb_rcglast256:
  %v1185 = load i64, ptr %slot203, align 8
  %op1186 = sub i64 %v1185, 24
  store i64 %op1186, ptr %slot213, align 8
  %v1187 = load i64, ptr %slot203, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %rgep1189 = getelementptr i8, ptr %p1188, i64 -24
  %ld1190 = load i64, ptr %rgep1189, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1190, ptr %slot214, align 8
  %v1191 = load i64, ptr %slot214, align 8
  %cmp1192 = icmp ne i64 %v1191, 0
  %cv1193 = zext i1 %cmp1192 to i32
  store i32 %cv1193, ptr %slot215, align 8
  %v1194 = load i32, ptr %slot215, align 8
  %cv1195 = zext i32 %v1194 to i64
  %cond1196 = icmp ne i64 %cv1195, 0
  br i1 %cond1196, label %bb_rcgdec256, label %bb_rcgslow256
bb_rcgslow256:
  %v1197 = load i64, ptr %slot202, align 8
  %v1198 = load i64, ptr %slot185, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1197, i64 %v1198) nomerge, !dbg !116
  br label %bb_rcgdone256
bb_rcgdec256:
  %v1199 = load i64, ptr %slot211, align 8
  %v1200 = load i64, ptr %slot203, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  %rgep1202 = getelementptr i8, ptr %p1201, i64 -32
  store i64 %v1199, ptr %rgep1202, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear256
bb_rcgclear256:
  %v1203 = load i64, ptr %slot185, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  store i64 0, ptr %p1204, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone256
bb_rcgdone256:
  br label %bb_rcslotdone225
bb_rcslotdone225:
  br label %bb_rcprepared171
bb_rcprepared171:
  %v1205 = load i64, ptr %slot13, align 8
  store i64 %v1205, ptr %slot216, align 8
  %v1206 = load i64, ptr %slot216, align 8
  %v1207 = load i64, ptr %slot142, align 8
  %p1208 = inttoptr i64 %v1206 to ptr
  %p1209 = inttoptr i64 %v1207 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1209, ptr %p1208, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1210 = load i64, ptr %slot8, align 8
  %p1211 = inttoptr i64 %v1210 to ptr
  store i32 0, ptr %p1211, align 4, !alias.scope !3, !noalias !4
  %v1212 = load i64, ptr %slot16, align 8
  store i64 %v1212, ptr %slot217, align 8
  %v1213 = load i64, ptr %slot137, align 8
  %p1215 = inttoptr i64 %v1213 to ptr
  %gep1216 = getelementptr i8, ptr %p1215, i64 8
  %op1214 = ptrtoint ptr %gep1216 to i64
  store i64 %op1214, ptr %slot218, align 8
  %v1217 = load i64, ptr %slot217, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  %ld1219 = load i64, ptr %p1218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1219, ptr %slot219, align 8
  %v1220 = load i64, ptr %slot219, align 8
  %v1221 = load i64, ptr %slot218, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  store i64 %v1220, ptr %p1222, align 8, !alias.scope !3, !noalias !4
  %v1223 = load i64, ptr %slot137, align 8
  %v1224 = load i64, ptr %slot15, align 8
  %p1225 = inttoptr i64 %v1224 to ptr
  store i64 %v1223, ptr %p1225, align 8, !alias.scope !3, !noalias !4
  %v1226 = load i64, ptr %slot15, align 8
  %p1227 = inttoptr i64 %v1226 to ptr
  %ld1228 = load i64, ptr %p1227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1228, ptr %slot220, align 8
  %v1229 = load i64, ptr %slot11, align 8
  store i64 %v1229, ptr %slot221, align 8
  %v1230 = load i64, ptr %slot220, align 8
  %v1231 = load i64, ptr %slot221, align 8
  %p1232 = inttoptr i64 %v1230 to ptr
  %p1233 = inttoptr i64 %v1231 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1233, ptr %p1232, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1234 = load i64, ptr %slot7, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  store i32 2, ptr %p1235, align 4, !alias.scope !3, !noalias !4
  %v1236 = load i64, ptr %slot6, align 8
  %p1237 = inttoptr i64 %v1236 to ptr
  store i32 1, ptr %p1237, align 4, !alias.scope !3, !noalias !4
  %v1238 = load i64, ptr %slot221, align 8
  %v1239 = load i64, ptr %slot15, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  store i64 %v1238, ptr %p1240, align 8, !alias.scope !3, !noalias !4
  %v1241 = load i64, ptr %slot15, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  %ld1243 = load i64, ptr %p1242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1243, ptr %slot222, align 8
  %v1244 = load i64, ptr %slot15, align 8
  %p1245 = inttoptr i64 %v1244 to ptr
  %ld1246 = load i64, ptr %p1245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1246, ptr %slot223, align 8
  %v1247 = load i64, ptr %slot13, align 8
  store i64 %v1247, ptr %slot224, align 8
  %v1248 = load i64, ptr %slot19, align 8
  store i64 %v1248, ptr %slot225, align 8
  %v1249 = load i64, ptr %slot223, align 8
  %op1250 = add i64 %v1249, 0
  store i64 %op1250, ptr %slot226, align 8
  %v1251 = load i64, ptr %slot226, align 8
  %p1252 = inttoptr i64 %v1251 to ptr
  %ld1253 = load i64, ptr %p1252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1253, ptr %slot227, align 8
  %v1254 = load i64, ptr %slot227, align 8
  %cmp1255 = icmp ne i64 %v1254, 0
  %cv1256 = zext i1 %cmp1255 to i32
  store i32 %cv1256, ptr %slot228, align 8
  %v1257 = load i32, ptr %slot228, align 8
  %cv1258 = zext i32 %v1257 to i64
  %cond1259 = icmp ne i64 %cv1258, 0
  br i1 %cond1259, label %bb_rcmoveheader276, label %bb_rcmovenext276
bb_rcmoveheader276:
  %v1260 = load i64, ptr %slot227, align 8
  %op1261 = sub i64 %v1260, 16
  store i64 %op1261, ptr %slot229, align 8
  %v1262 = load i64, ptr %slot227, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %rgep1264 = getelementptr i8, ptr %p1263, i64 -16
  %ld1265 = load i64, ptr %rgep1264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1265, ptr %slot230, align 8
  %v1266 = load i64, ptr %slot230, align 8
  %op1267 = and i64 %v1266, 5764607523034234881
  store i64 %op1267, ptr %slot231, align 8
  %v1268 = load i64, ptr %slot231, align 8
  %cmp1269 = icmp ne i64 %v1268, 0
  %cv1270 = zext i1 %cmp1269 to i32
  store i32 %cv1270, ptr %slot232, align 8
  %v1271 = load i32, ptr %slot232, align 8
  %cv1272 = zext i32 %v1271 to i64
  %cond1273 = icmp ne i64 %cv1272, 0
  br i1 %cond1273, label %bb_rcmoveslow273, label %bb_rcmovenext276
bb_rcmovenext276:
  %v1274 = load i64, ptr %slot223, align 8
  %v1275 = load i64, ptr %slot224, align 8
  %p1276 = inttoptr i64 %v1274 to ptr
  %p1277 = inttoptr i64 %v1275 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1277, ptr %p1276, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot223, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  store i64 0, ptr %p1279, align 8, !alias.scope !3, !noalias !4
  %v1280 = load i64, ptr %slot223, align 8
  %op1281 = add i64 %v1280, 8
  store i64 %op1281, ptr %slot233, align 8
  %v1282 = load i64, ptr %slot233, align 8
  %p1283 = inttoptr i64 %v1282 to ptr
  store i64 0, ptr %p1283, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved273
bb_rcmoveslow273:
  %v1284 = load i64, ptr %slot18, align 8
  %v1285 = load i64, ptr %slot224, align 8
  %v1286 = load i64, ptr %slot223, align 8
  %v1287 = load i64, ptr %slot225, align 8
  %cv1288 = trunc i64 %v1287 to i32
  %call1289 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v1284, i64 %v1285, i64 %v1286, i32 %cv1288) nomerge, !dbg !118
  store i32 %call1289, ptr %slot234, align 8
  %v1290 = load i32, ptr %slot234, align 8
  %cv1291 = zext i32 %v1290 to i64
  %cond1292 = icmp ne i64 %cv1291, 0
  br i1 %cond1292, label %bb_rcsuccess284, label %bb_rcfailure284
bb_rcfailure284:
  %v1293 = load i64, ptr %slot18, align 8
  %p1294 = inttoptr i64 %v1293 to ptr
  %call1295 = call i32 @myl_rc_take_failure(ptr %p1294) nomerge, !dbg !118
  store i32 %call1295, ptr %slot235, align 8
  %v1296 = load i64, ptr %slot1, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  %v1298 = load i32, ptr %slot235, align 8
  %call1299 = call i32 @myl_qbe_rc_status(ptr %p1297, i32 %v1298) nomerge, !dbg !118
  store i32 %call1299, ptr %slot236, align 8
  br label %bb_failure
bb_rcsuccess284:
  br label %bb_rcmoved273
bb_rcmoved273:
  %v1300 = load i64, ptr %slot6, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i32 0, ptr %p1301, align 4, !alias.scope !3, !noalias !4
  %v1302 = load i64, ptr %slot9, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  store i32 2, ptr %p1303, align 4, !alias.scope !3, !noalias !4
  %v1304 = load i64, ptr %slot8, align 8
  %p1305 = inttoptr i64 %v1304 to ptr
  store i32 1, ptr %p1305, align 4, !alias.scope !3, !noalias !4
  %v1306 = load i64, ptr %slot13, align 8
  store i64 %v1306, ptr %slot237, align 8
  %v1307 = load i64, ptr %slot8, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  store i32 0, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  %v1309 = load i64, ptr %slot6, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  %ld1311 = load i32, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1311, ptr %slot238, align 8
  %v1312 = load i32, ptr %slot238, align 8
  %cv1313 = zext i32 %v1312 to i64
  %cond1314 = icmp ne i64 %cv1313, 0
  br i1 %cond1314, label %bb_rcslotdrop294, label %bb_rcslotdone294
bb_rcslotdrop294:
  %v1315 = load i64, ptr %slot6, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  store i32 0, ptr %p1316, align 4, !alias.scope !3, !noalias !4
  %v1317 = load i64, ptr %slot11, align 8
  store i64 %v1317, ptr %slot239, align 8
  %v1318 = load i64, ptr %slot7, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  %ld1320 = load i32, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1320, ptr %slot240, align 8
  %v1321 = load i32, ptr %slot240, align 8
  %op1322 = and i32 %v1321, 28
  store i32 %op1322, ptr %slot241, align 8
  %v1323 = load i32, ptr %slot241, align 8
  %cv1324 = zext i32 %v1323 to i64
  %cond1325 = icmp ne i64 %cv1324, 0
  br i1 %cond1325, label %bb_rcslotrole294, label %bb_rcslotowner294
bb_rcslotrole294:
  %v1326 = load i64, ptr %slot18, align 8
  store i64 %v1326, ptr %slot242, align 8
  %v1327 = load i64, ptr %slot242, align 8
  %v1328 = load i64, ptr %slot239, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v1327, i64 %v1328) nomerge, !dbg !118
  br label %bb_rcslotdone294
bb_rcslotowner294:
  %v1329 = load i64, ptr %slot18, align 8
  store i64 %v1329, ptr %slot243, align 8
  %v1330 = load i64, ptr %slot243, align 8
  %v1331 = load i64, ptr %slot239, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v1330, i64 %v1331) nomerge, !dbg !118
  br label %bb_rcslotdone294
bb_rcslotdone294:
  %v1332 = load i64, ptr %slot4, align 8
  %p1333 = inttoptr i64 %v1332 to ptr
  %ld1334 = load i32, ptr %p1333, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1334, ptr %slot244, align 8
  %v1335 = load i32, ptr %slot244, align 8
  %cv1336 = zext i32 %v1335 to i64
  %cond1337 = icmp ne i64 %cv1336, 0
  br i1 %cond1337, label %bb_rcslotdrop303, label %bb_rcslotdone303
bb_rcslotdrop303:
  %v1338 = load i64, ptr %slot4, align 8
  %p1339 = inttoptr i64 %v1338 to ptr
  store i32 0, ptr %p1339, align 4, !alias.scope !3, !noalias !4
  %v1340 = load i64, ptr %slot14, align 8
  store i64 %v1340, ptr %slot245, align 8
  %v1341 = load i64, ptr %slot5, align 8
  %p1342 = inttoptr i64 %v1341 to ptr
  %ld1343 = load i32, ptr %p1342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1343, ptr %slot246, align 8
  %v1344 = load i32, ptr %slot246, align 8
  %op1345 = and i32 %v1344, 28
  store i32 %op1345, ptr %slot247, align 8
  %v1346 = load i32, ptr %slot247, align 8
  %cv1347 = zext i32 %v1346 to i64
  %cond1348 = icmp ne i64 %cv1347, 0
  br i1 %cond1348, label %bb_rcslotrole303, label %bb_rcslotowner303
bb_rcslotrole303:
  %v1349 = load i64, ptr %slot18, align 8
  store i64 %v1349, ptr %slot248, align 8
  %v1350 = load i64, ptr %slot245, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  %ld1352 = load i64, ptr %p1351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1352, ptr %slot249, align 8
  %v1353 = load i64, ptr %slot249, align 8
  %cmp1354 = icmp ne i64 %v1353, 0
  %cv1355 = zext i1 %cmp1354 to i32
  store i32 %cv1355, ptr %slot250, align 8
  %v1356 = load i32, ptr %slot250, align 8
  %cv1357 = zext i32 %v1356 to i64
  %cond1358 = icmp ne i64 %cv1357, 0
  br i1 %cond1358, label %bb_rcgnn319, label %bb_rcgdone319
bb_rcgnn319:
  %v1359 = load i64, ptr %slot249, align 8
  %op1360 = sub i64 %v1359, 16
  store i64 %op1360, ptr %slot251, align 8
  %v1361 = load i64, ptr %slot249, align 8
  %p1362 = inttoptr i64 %v1361 to ptr
  %rgep1363 = getelementptr i8, ptr %p1362, i64 -16
  %ld1364 = load i64, ptr %rgep1363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1364, ptr %slot252, align 8
  %v1365 = load i64, ptr %slot252, align 8
  %op1366 = and i64 %v1365, 4611686018427387906
  store i64 %op1366, ptr %slot253, align 8
  %v1367 = load i64, ptr %slot253, align 8
  %cmp1368 = icmp ne i64 %v1367, 0
  %cv1369 = zext i1 %cmp1368 to i32
  store i32 %cv1369, ptr %slot254, align 8
  %v1370 = load i32, ptr %slot254, align 8
  %cv1371 = zext i32 %v1370 to i64
  %cond1372 = icmp ne i64 %cv1371, 0
  br i1 %cond1372, label %bb_rcgclear319, label %bb_rcgcounted319
bb_rcgcounted319:
  %v1373 = load i64, ptr %slot249, align 8
  %op1374 = sub i64 %v1373, 24
  store i64 %op1374, ptr %slot255, align 8
  %v1375 = load i64, ptr %slot249, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %rgep1377 = getelementptr i8, ptr %p1376, i64 -24
  %ld1378 = load i64, ptr %rgep1377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1378, ptr %slot256, align 8
  %v1379 = load i64, ptr %slot256, align 8
  %op1380 = sub i64 %v1379, 1
  store i64 %op1380, ptr %slot257, align 8
  %v1381 = load i64, ptr %slot257, align 8
  %cmp1382 = icmp eq i64 %v1381, 0
  %cv1383 = zext i1 %cmp1382 to i32
  store i32 %cv1383, ptr %slot258, align 8
  %v1384 = load i32, ptr %slot258, align 8
  %cv1385 = zext i32 %v1384 to i64
  %cond1386 = icmp ne i64 %cv1385, 0
  br i1 %cond1386, label %bb_rcglast319, label %bb_rcgdec319
bb_rcglast319:
  %v1387 = load i64, ptr %slot249, align 8
  %op1388 = sub i64 %v1387, 32
  store i64 %op1388, ptr %slot259, align 8
  %v1389 = load i64, ptr %slot249, align 8
  %p1390 = inttoptr i64 %v1389 to ptr
  %rgep1391 = getelementptr i8, ptr %p1390, i64 -32
  %ld1392 = load i64, ptr %rgep1391, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1392, ptr %slot260, align 8
  %v1393 = load i64, ptr %slot260, align 8
  %cmp1394 = icmp ne i64 %v1393, 0
  %cv1395 = zext i1 %cmp1394 to i32
  store i32 %cv1395, ptr %slot261, align 8
  %v1396 = load i32, ptr %slot261, align 8
  %cv1397 = zext i32 %v1396 to i64
  %cond1398 = icmp ne i64 %cv1397, 0
  br i1 %cond1398, label %bb_rcgdec319, label %bb_rcgslow319
bb_rcgslow319:
  %v1399 = load i64, ptr %slot248, align 8
  %v1400 = load i64, ptr %slot245, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64 %v1399, i64 %v1400) nomerge, !dbg !118
  br label %bb_rcgdone319
bb_rcgdec319:
  %v1401 = load i64, ptr %slot257, align 8
  %v1402 = load i64, ptr %slot249, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  %rgep1404 = getelementptr i8, ptr %p1403, i64 -24
  store i64 %v1401, ptr %rgep1404, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear319
bb_rcgclear319:
  %v1405 = load i64, ptr %slot245, align 8
  %p1406 = inttoptr i64 %v1405 to ptr
  store i64 0, ptr %p1406, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone319
bb_rcgdone319:
  br label %bb_rcslotdone303
bb_rcslotowner303:
  %v1407 = load i64, ptr %slot18, align 8
  store i64 %v1407, ptr %slot262, align 8
  %v1408 = load i64, ptr %slot245, align 8
  %p1409 = inttoptr i64 %v1408 to ptr
  %ld1410 = load i64, ptr %p1409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1410, ptr %slot263, align 8
  %v1411 = load i64, ptr %slot263, align 8
  %cmp1412 = icmp ne i64 %v1411, 0
  %cv1413 = zext i1 %cmp1412 to i32
  store i32 %cv1413, ptr %slot264, align 8
  %v1414 = load i32, ptr %slot264, align 8
  %cv1415 = zext i32 %v1414 to i64
  %cond1416 = icmp ne i64 %cv1415, 0
  br i1 %cond1416, label %bb_rcgnn334, label %bb_rcgdone334
bb_rcgnn334:
  %v1417 = load i64, ptr %slot263, align 8
  %op1418 = sub i64 %v1417, 16
  store i64 %op1418, ptr %slot265, align 8
  %v1419 = load i64, ptr %slot263, align 8
  %p1420 = inttoptr i64 %v1419 to ptr
  %rgep1421 = getelementptr i8, ptr %p1420, i64 -16
  %ld1422 = load i64, ptr %rgep1421, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1422, ptr %slot266, align 8
  %v1423 = load i64, ptr %slot266, align 8
  %op1424 = and i64 %v1423, 4611686018427387906
  store i64 %op1424, ptr %slot267, align 8
  %v1425 = load i64, ptr %slot267, align 8
  %cmp1426 = icmp ne i64 %v1425, 0
  %cv1427 = zext i1 %cmp1426 to i32
  store i32 %cv1427, ptr %slot268, align 8
  %v1428 = load i32, ptr %slot268, align 8
  %cv1429 = zext i32 %v1428 to i64
  %cond1430 = icmp ne i64 %cv1429, 0
  br i1 %cond1430, label %bb_rcgclear334, label %bb_rcgcounted334
bb_rcgcounted334:
  %v1431 = load i64, ptr %slot263, align 8
  %op1432 = sub i64 %v1431, 32
  store i64 %op1432, ptr %slot269, align 8
  %v1433 = load i64, ptr %slot263, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  %rgep1435 = getelementptr i8, ptr %p1434, i64 -32
  %ld1436 = load i64, ptr %rgep1435, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1436, ptr %slot270, align 8
  %v1437 = load i64, ptr %slot270, align 8
  %op1438 = sub i64 %v1437, 1
  store i64 %op1438, ptr %slot271, align 8
  %v1439 = load i64, ptr %slot271, align 8
  %cmp1440 = icmp eq i64 %v1439, 0
  %cv1441 = zext i1 %cmp1440 to i32
  store i32 %cv1441, ptr %slot272, align 8
  %v1442 = load i32, ptr %slot272, align 8
  %cv1443 = zext i32 %v1442 to i64
  %cond1444 = icmp ne i64 %cv1443, 0
  br i1 %cond1444, label %bb_rcglast334, label %bb_rcgdec334
bb_rcglast334:
  %v1445 = load i64, ptr %slot263, align 8
  %op1446 = sub i64 %v1445, 24
  store i64 %op1446, ptr %slot273, align 8
  %v1447 = load i64, ptr %slot263, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  %rgep1449 = getelementptr i8, ptr %p1448, i64 -24
  %ld1450 = load i64, ptr %rgep1449, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1450, ptr %slot274, align 8
  %v1451 = load i64, ptr %slot274, align 8
  %cmp1452 = icmp ne i64 %v1451, 0
  %cv1453 = zext i1 %cmp1452 to i32
  store i32 %cv1453, ptr %slot275, align 8
  %v1454 = load i32, ptr %slot275, align 8
  %cv1455 = zext i32 %v1454 to i64
  %cond1456 = icmp ne i64 %cv1455, 0
  br i1 %cond1456, label %bb_rcgdec334, label %bb_rcgslow334
bb_rcgslow334:
  %v1457 = load i64, ptr %slot262, align 8
  %v1458 = load i64, ptr %slot245, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v1457, i64 %v1458) nomerge, !dbg !118
  br label %bb_rcgdone334
bb_rcgdec334:
  %v1459 = load i64, ptr %slot271, align 8
  %v1460 = load i64, ptr %slot263, align 8
  %p1461 = inttoptr i64 %v1460 to ptr
  %rgep1462 = getelementptr i8, ptr %p1461, i64 -32
  store i64 %v1459, ptr %rgep1462, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear334
bb_rcgclear334:
  %v1463 = load i64, ptr %slot245, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  store i64 0, ptr %p1464, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone334
bb_rcgdone334:
  br label %bb_rcslotdone303
bb_rcslotdone303:
  %v1465 = load i64, ptr %slot237, align 8
  %p1466 = inttoptr i64 %v1465 to ptr
  %ret1467 = load { i64, i64 }, ptr %p1466, align 8
  ret { i64, i64 } %ret1467
bb_failure:
  %v1468 = load i64, ptr %slot3, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  call void @llvm.memset.p0.i64(ptr %p1469, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v1470 = load i64, ptr %slot3, align 8
  %p1471 = inttoptr i64 %v1470 to ptr
  %ret1472 = load { i64, i64 }, ptr %p1471, align 8
  ret { i64, i64 } %ret1472
bb_entry_failure:
  %v1473 = load i64, ptr %slot3, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  call void @llvm.memset.p0.i64(ptr %p1474, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !118
  %v1475 = load i64, ptr %slot3, align 8
  %p1476 = inttoptr i64 %v1475 to ptr
  %ret1477 = load { i64, i64 }, ptr %p1476, align 8
  ret { i64, i64 } %ret1477
}

@myl_t_6443eeba4e1a2dfcf7724374c49aee7d6088d8d2ed268a8e00cf676e7411a0da = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216", linkageName: "myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 18007137697684349965, i64 0, !"myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!118 = !DILocation(line: 8, column: 0, scope: !119)
