target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_6ebf82ddbc9178c16b7df30bf24fbe017e8b8f1c3e98435ddaa9d24a62c703dc(ptr sret([208 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i32, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i32, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i32, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i32, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i32, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i32, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i32, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i32, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i32, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i32, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i32, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i32, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i32, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i32, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i32, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i32, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i32, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i32, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i32, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i32, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i32, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i32, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i32, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i64, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i32, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i32, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i32, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i32, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i32, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i32, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i32, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i32, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i32, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i32, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i32, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i32, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i32, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i32, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i32, align 8
  %slot1214 = alloca i32, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i32, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i32, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i32, align 8
  %slot1231 = alloca i32, align 8
  %slot1232 = alloca i32, align 8
  %slot1233 = alloca i32, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i32, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i32, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i32, align 8
  %slot1253 = alloca i32, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i32, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i32, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i32, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i32, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i32, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i32, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i32, align 8
  %slot1285 = alloca i32, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i32, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i32, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i32, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i32, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i32, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i32, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %callresult1319 = alloca [16 x i8], align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i64, align 8
  %callresult1326 = alloca [16 x i8], align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i32, align 8
  %slot1332 = alloca i64, align 8
  %slot1333 = alloca i64, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i32, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i32, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i32, align 8
  %slot1351 = alloca i64, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i32, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i32, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i32, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i32, align 8
  %slot1365 = alloca i32, align 8
  %slot1366 = alloca i32, align 8
  %slot1367 = alloca i32, align 8
  %slot1368 = alloca i32, align 8
  %slot1369 = alloca i32, align 8
  %slot1370 = alloca i32, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i32, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i32, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i32, align 8
  %slot1383 = alloca i32, align 8
  %slot1384 = alloca i32, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i32, align 8
  %slot1387 = alloca i32, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i32, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i32, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i32, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i32, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i64, align 8
  %slot1412 = alloca i32, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i32, align 8
  %slot1416 = alloca i32, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i32, align 8
  %slot1419 = alloca i32, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i32, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i64, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i32, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i32, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i32, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i32, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i32, align 8
  %slot1441 = alloca i64, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i32, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i32, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i64, align 8
  %slot1450 = alloca i32, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i64, align 8
  %slot1459 = alloca i64, align 8
  %slot1460 = alloca i32, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i64, align 8
  %slot1463 = alloca i64, align 8
  %slot1464 = alloca i32, align 8
  %slot1465 = alloca i32, align 8
  %slot1466 = alloca i32, align 8
  %slot1467 = alloca i32, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i32, align 8
  %slot1473 = alloca i32, align 8
  %slot1474 = alloca i32, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i64, align 8
  %slot1477 = alloca i32, align 8
  %slot1478 = alloca i64, align 8
  %slot1479 = alloca i64, align 8
  %slot1480 = alloca i64, align 8
  %slot1481 = alloca i32, align 8
  %slot1482 = alloca i32, align 8
  %slot1483 = alloca i32, align 8
  %slot1484 = alloca i32, align 8
  %slot1485 = alloca i32, align 8
  %slot1486 = alloca i32, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i64, align 8
  %slot1491 = alloca i32, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i32, align 8
  %slot1496 = alloca i64, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i32, align 8
  %slot1500 = alloca i32, align 8
  %slot1501 = alloca i32, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i32, align 8
  %slot1504 = alloca i32, align 8
  %slot1505 = alloca i64, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i32, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i64, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i32, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i32, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i32, align 8
  %slot1519 = alloca i64, align 8
  %slot1520 = alloca i64, align 8
  %slot1521 = alloca i32, align 8
  %slot1522 = alloca i64, align 8
  %slot1523 = alloca i64, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i32, align 8
  %slot1526 = alloca i64, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i64, align 8
  %slot1529 = alloca i32, align 8
  %slot1530 = alloca i64, align 8
  %slot1531 = alloca i64, align 8
  %slot1532 = alloca i32, align 8
  %slot1533 = alloca i32, align 8
  %slot1534 = alloca i64, align 8
  %slot1535 = alloca i32, align 8
  %slot1536 = alloca i32, align 8
  %slot1537 = alloca i64, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i32, align 8
  %slot1540 = alloca i64, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i32, align 8
  %slot1544 = alloca i64, align 8
  %slot1545 = alloca i64, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i32, align 8
  %slot1548 = alloca i64, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i32, align 8
  %slot1551 = alloca i64, align 8
  %slot1552 = alloca i64, align 8
  %slot1553 = alloca i32, align 8
  %slot1554 = alloca i64, align 8
  %slot1555 = alloca i64, align 8
  %slot1556 = alloca i64, align 8
  %slot1557 = alloca i32, align 8
  %slot1558 = alloca i64, align 8
  %slot1559 = alloca i64, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i32, align 8
  %slot1562 = alloca i64, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i32, align 8
  %slot1565 = alloca i64, align 8
  %slot1566 = alloca i64, align 8
  %slot1567 = alloca i32, align 8
  %slot1568 = alloca i64, align 8
  %slot1569 = alloca i64, align 8
  %slot1570 = alloca i64, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i64, align 8
  %slot1573 = alloca i64, align 8
  %slot1574 = alloca i64, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i64, align 8
  %slot1577 = alloca i32, align 8
  %slot1578 = alloca i64, align 8
  %slot1579 = alloca i64, align 8
  %slot1580 = alloca i64, align 8
  %slot1581 = alloca i32, align 8
  %slot1582 = alloca i32, align 8
  %slot1583 = alloca i32, align 8
  %slot1584 = alloca i32, align 8
  %slot1585 = alloca i64, align 8
  %slot1586 = alloca i64, align 8
  %slot1587 = alloca i64, align 8
  %slot1588 = alloca i64, align 8
  %slot1589 = alloca i32, align 8
  %slot1590 = alloca i32, align 8
  %slot1591 = alloca i32, align 8
  %slot1592 = alloca i64, align 8
  %slot1593 = alloca i64, align 8
  %slot1594 = alloca i32, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i64, align 8
  %slot1597 = alloca i64, align 8
  %slot1598 = alloca i32, align 8
  %slot1599 = alloca i32, align 8
  %slot1600 = alloca i32, align 8
  %slot1601 = alloca i32, align 8
  %slot1602 = alloca i32, align 8
  %slot1603 = alloca i32, align 8
  %slot1604 = alloca i32, align 8
  %slot1605 = alloca i64, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i64, align 8
  %slot1608 = alloca i32, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i64, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i32, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i64, align 8
  %slot1616 = alloca i32, align 8
  %slot1617 = alloca i32, align 8
  %slot1618 = alloca i32, align 8
  %slot1619 = alloca i64, align 8
  %slot1620 = alloca i32, align 8
  %slot1621 = alloca i32, align 8
  %slot1622 = alloca i64, align 8
  %slot1623 = alloca i64, align 8
  %slot1624 = alloca i32, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i64, align 8
  %slot1627 = alloca i64, align 8
  %slot1628 = alloca i32, align 8
  %slot1629 = alloca i64, align 8
  %slot1630 = alloca i64, align 8
  %slot1631 = alloca i64, align 8
  %slot1632 = alloca i32, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i64, align 8
  %slot1635 = alloca i32, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i64, align 8
  %slot1638 = alloca i32, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i64, align 8
  %slot1641 = alloca i64, align 8
  %slot1642 = alloca i32, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i64, align 8
  %slot1645 = alloca i64, align 8
  %slot1646 = alloca i32, align 8
  %slot1647 = alloca i64, align 8
  %slot1648 = alloca i64, align 8
  %slot1649 = alloca i32, align 8
  %slot1650 = alloca i32, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i32, align 8
  %slot1653 = alloca i32, align 8
  %slot1654 = alloca i64, align 8
  %slot1655 = alloca i64, align 8
  %slot1656 = alloca i32, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i64, align 8
  %slot1659 = alloca i64, align 8
  %slot1660 = alloca i32, align 8
  %slot1661 = alloca i64, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i64, align 8
  %slot1664 = alloca i32, align 8
  %slot1665 = alloca i64, align 8
  %slot1666 = alloca i64, align 8
  %slot1667 = alloca i32, align 8
  %slot1668 = alloca i64, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i32, align 8
  %slot1671 = alloca i64, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i64, align 8
  %slot1674 = alloca i32, align 8
  %slot1675 = alloca i64, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i64, align 8
  %slot1678 = alloca i32, align 8
  %slot1679 = alloca i64, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i32, align 8
  %slot1682 = alloca i64, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i32, align 8
  %slot1685 = alloca i64, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i64, align 8
  %slot1688 = alloca i64, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i64, align 8
  %slot1692 = alloca i64, align 8
  %slot1693 = alloca i64, align 8
  %slot1694 = alloca i32, align 8
  %slot1695 = alloca i32, align 8
  %slot1696 = alloca i32, align 8
  %slot1697 = alloca i32, align 8
  %slot1698 = alloca i64, align 8
  %slot1699 = alloca i64, align 8
  %slot1700 = alloca i64, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i32, align 8
  %slot1703 = alloca i32, align 8
  %slot1704 = alloca i32, align 8
  %slot1705 = alloca i64, align 8
  %slot1706 = alloca i64, align 8
  %slot1707 = alloca i32, align 8
  %slot1708 = alloca i64, align 8
  %slot1709 = alloca i64, align 8
  %slot1710 = alloca i64, align 8
  %slot1711 = alloca i32, align 8
  %slot1712 = alloca i32, align 8
  %slot1713 = alloca i32, align 8
  %slot1714 = alloca i32, align 8
  %slot1715 = alloca i64, align 8
  %slot1716 = alloca i64, align 8
  %slot1717 = alloca i64, align 8
  %slot1718 = alloca i32, align 8
  %slot1719 = alloca i64, align 8
  %slot1720 = alloca i64, align 8
  %slot1721 = alloca i64, align 8
  %slot1722 = alloca i32, align 8
  %slot1723 = alloca i64, align 8
  %slot1724 = alloca i64, align 8
  %slot1725 = alloca i64, align 8
  %slot1726 = alloca i32, align 8
  %slot1727 = alloca i32, align 8
  %slot1728 = alloca i64, align 8
  %slot1729 = alloca i32, align 8
  %slot1730 = alloca i32, align 8
  %slot1731 = alloca i32, align 8
  %slot1732 = alloca i32, align 8
  %slot1733 = alloca i32, align 8
  %slot1734 = alloca i64, align 8
  %slot1735 = alloca i32, align 8
  %slot1736 = alloca i32, align 8
  %slot1737 = alloca i64, align 8
  %slot1738 = alloca i64, align 8
  %slot1739 = alloca i32, align 8
  %slot1740 = alloca i64, align 8
  %slot1741 = alloca i64, align 8
  %slot1742 = alloca i64, align 8
  %slot1743 = alloca i32, align 8
  %slot1744 = alloca i64, align 8
  %slot1745 = alloca i64, align 8
  %slot1746 = alloca i64, align 8
  %slot1747 = alloca i32, align 8
  %slot1748 = alloca i64, align 8
  %slot1749 = alloca i64, align 8
  %slot1750 = alloca i32, align 8
  %slot1751 = alloca i64, align 8
  %slot1752 = alloca i64, align 8
  %slot1753 = alloca i32, align 8
  %slot1754 = alloca i64, align 8
  %slot1755 = alloca i64, align 8
  %slot1756 = alloca i64, align 8
  %slot1757 = alloca i32, align 8
  %slot1758 = alloca i64, align 8
  %slot1759 = alloca i64, align 8
  %slot1760 = alloca i64, align 8
  %slot1761 = alloca i32, align 8
  %slot1762 = alloca i64, align 8
  %slot1763 = alloca i64, align 8
  %slot1764 = alloca i32, align 8
  %slot1765 = alloca i64, align 8
  %slot1766 = alloca i64, align 8
  %slot1767 = alloca i64, align 8
  %slot1768 = alloca i64, align 8
  %slot1769 = alloca i32, align 8
  %slot1770 = alloca i32, align 8
  %slot1771 = alloca i32, align 8
  %slot1772 = alloca i32, align 8
  %slot1773 = alloca i64, align 8
  %slot1774 = alloca i64, align 8
  %slot1775 = alloca i64, align 8
  %slot1776 = alloca i64, align 8
  %slot1777 = alloca i32, align 8
  %slot1778 = alloca i32, align 8
  %slot1779 = alloca i32, align 8
  %slot1780 = alloca i64, align 8
  %slot1781 = alloca i64, align 8
  %slot1782 = alloca i32, align 8
  %slot1783 = alloca i64, align 8
  %slot1784 = alloca i64, align 8
  %slot1785 = alloca i64, align 8
  %slot1786 = alloca i32, align 8
  %slot1787 = alloca i64, align 8
  %slot1788 = alloca i64, align 8
  %slot1789 = alloca i32, align 8
  %slot1790 = alloca i64, align 8
  %slot1791 = alloca i64, align 8
  %slot1792 = alloca i64, align 8
  %slot1793 = alloca i32, align 8
  %slot1794 = alloca i64, align 8
  %slot1795 = alloca i32, align 8
  %slot1796 = alloca i32, align 8
  %slot1797 = alloca i32, align 8
  %slot1798 = alloca i64, align 8
  %slot1799 = alloca i64, align 8
  %slot1800 = alloca i32, align 8
  %slot1801 = alloca i32, align 8
  %slot1802 = alloca i32, align 8
  %slot1803 = alloca i32, align 8
  %slot1804 = alloca i64, align 8
  %slot1805 = alloca i32, align 8
  %slot1806 = alloca i32, align 8
  %slot1807 = alloca i64, align 8
  %slot1808 = alloca i64, align 8
  %slot1809 = alloca i64, align 8
  %slot1810 = alloca i64, align 8
  %slot1811 = alloca i64, align 8
  %slot1812 = alloca i64, align 8
  %slot1813 = alloca i64, align 8
  %slot1814 = alloca i64, align 8
  %slot1815 = alloca i32, align 8
  %slot1816 = alloca i32, align 8
  %slot1817 = alloca i32, align 8
  %slot1818 = alloca i32, align 8
  %slot1819 = alloca i64, align 8
  %slot1820 = alloca i64, align 8
  %slot1821 = alloca i64, align 8
  %slot1822 = alloca i64, align 8
  %slot1823 = alloca i32, align 8
  %slot1824 = alloca i32, align 8
  %slot1825 = alloca i32, align 8
  %slot1826 = alloca i64, align 8
  %slot1827 = alloca i64, align 8
  %slot1828 = alloca i32, align 8
  %slot1829 = alloca i64, align 8
  %slot1830 = alloca i64, align 8
  %slot1831 = alloca i64, align 8
  %slot1832 = alloca i32, align 8
  %slot1833 = alloca i32, align 8
  %slot1834 = alloca i32, align 8
  %slot1835 = alloca i32, align 8
  %slot1836 = alloca i64, align 8
  %slot1837 = alloca i64, align 8
  %slot1838 = alloca i64, align 8
  %slot1839 = alloca i32, align 8
  %slot1840 = alloca i64, align 8
  %slot1841 = alloca i64, align 8
  %slot1842 = alloca i64, align 8
  %slot1843 = alloca i32, align 8
  %slot1844 = alloca i64, align 8
  %slot1845 = alloca i64, align 8
  %slot1846 = alloca i64, align 8
  %slot1847 = alloca i32, align 8
  %slot1848 = alloca i32, align 8
  %slot1849 = alloca i64, align 8
  %slot1850 = alloca i32, align 8
  %slot1851 = alloca i32, align 8
  %slot1852 = alloca i32, align 8
  %slot1853 = alloca i32, align 8
  %slot1854 = alloca i32, align 8
  %slot1855 = alloca i64, align 8
  %slot1856 = alloca i32, align 8
  %slot1857 = alloca i32, align 8
  %slot1858 = alloca i64, align 8
  %slot1859 = alloca i64, align 8
  %slot1860 = alloca i32, align 8
  %slot1861 = alloca i64, align 8
  %slot1862 = alloca i64, align 8
  %slot1863 = alloca i64, align 8
  %slot1864 = alloca i32, align 8
  %slot1865 = alloca i64, align 8
  %slot1866 = alloca i64, align 8
  %slot1867 = alloca i64, align 8
  %slot1868 = alloca i32, align 8
  %slot1869 = alloca i64, align 8
  %slot1870 = alloca i64, align 8
  %slot1871 = alloca i32, align 8
  %slot1872 = alloca i64, align 8
  %slot1873 = alloca i64, align 8
  %slot1874 = alloca i32, align 8
  %slot1875 = alloca i64, align 8
  %slot1876 = alloca i64, align 8
  %slot1877 = alloca i64, align 8
  %slot1878 = alloca i32, align 8
  %slot1879 = alloca i64, align 8
  %slot1880 = alloca i64, align 8
  %slot1881 = alloca i64, align 8
  %slot1882 = alloca i32, align 8
  %slot1883 = alloca i64, align 8
  %slot1884 = alloca i64, align 8
  %slot1885 = alloca i32, align 8
  %slot1886 = alloca i64, align 8
  %slot1887 = alloca i64, align 8
  %slot1888 = alloca i64, align 8
  %slot1889 = alloca i64, align 8
  %slot1890 = alloca i32, align 8
  %slot1891 = alloca i32, align 8
  %slot1892 = alloca i32, align 8
  %slot1893 = alloca i32, align 8
  %slot1894 = alloca i64, align 8
  %slot1895 = alloca i64, align 8
  %slot1896 = alloca i64, align 8
  %slot1897 = alloca i64, align 8
  %slot1898 = alloca i32, align 8
  %slot1899 = alloca i32, align 8
  %slot1900 = alloca i32, align 8
  %slot1901 = alloca i64, align 8
  %slot1902 = alloca i64, align 8
  %slot1903 = alloca i32, align 8
  %slot1904 = alloca i64, align 8
  %slot1905 = alloca i64, align 8
  %slot1906 = alloca i64, align 8
  %slot1907 = alloca i32, align 8
  %slot1908 = alloca i64, align 8
  %slot1909 = alloca i32, align 8
  %slot1910 = alloca i32, align 8
  %slot1911 = alloca i32, align 8
  %slot1912 = alloca i64, align 8
  %slot1913 = alloca i64, align 8
  %slot1914 = alloca i32, align 8
  %slot1915 = alloca i32, align 8
  %slot1916 = alloca i32, align 8
  %slot1917 = alloca i32, align 8
  %slot1918 = alloca i64, align 8
  %slot1919 = alloca i32, align 8
  %slot1920 = alloca i32, align 8
  %slot1921 = alloca i64, align 8
  %slot1922 = alloca i64, align 8
  %slot1923 = alloca i64, align 8
  %slot1924 = alloca i64, align 8
  %slot1925 = alloca i64, align 8
  %slot1926 = alloca i64, align 8
  %slot1927 = alloca i32, align 8
  %slot1928 = alloca i32, align 8
  %slot1929 = alloca i32, align 8
  %slot1930 = alloca i32, align 8
  %slot1931 = alloca i64, align 8
  %slot1932 = alloca i64, align 8
  %slot1933 = alloca i64, align 8
  %slot1934 = alloca i64, align 8
  %slot1935 = alloca i32, align 8
  %slot1936 = alloca i32, align 8
  %slot1937 = alloca i32, align 8
  %slot1938 = alloca i64, align 8
  %slot1939 = alloca i64, align 8
  %slot1940 = alloca i32, align 8
  %slot1941 = alloca i64, align 8
  %slot1942 = alloca i64, align 8
  %slot1943 = alloca i64, align 8
  %slot1944 = alloca i32, align 8
  %slot1945 = alloca i64, align 8
  %slot1946 = alloca i32, align 8
  %slot1947 = alloca i32, align 8
  %slot1948 = alloca i32, align 8
  %slot1949 = alloca i64, align 8
  %slot1950 = alloca i64, align 8
  %slot1951 = alloca i32, align 8
  %slot1952 = alloca i32, align 8
  %slot1953 = alloca i32, align 8
  %slot1954 = alloca i32, align 8
  %slot1955 = alloca i64, align 8
  %slot1956 = alloca i32, align 8
  %slot1957 = alloca i32, align 8
  %slot1958 = alloca i64, align 8
  %slot1959 = alloca i64, align 8
  %slot1960 = alloca i64, align 8
  %slot1961 = alloca i64, align 8
  %slot1962 = alloca i64, align 8
  %slot1963 = alloca i64, align 8
  %slot1964 = alloca i64, align 8
  %slot1965 = alloca i64, align 8
  %slot1966 = alloca i64, align 8
  %slot1967 = alloca i64, align 8
  %slot1968 = alloca i64, align 8
  %slot1969 = alloca i64, align 8
  %slot1970 = alloca i64, align 8
  %slot1971 = alloca i64, align 8
  %slot1972 = alloca i64, align 8
  %slot1973 = alloca i64, align 8
  %slot1974 = alloca i64, align 8
  %slot1975 = alloca i64, align 8
  %slot1976 = alloca i64, align 8
  %slot1977 = alloca i64, align 8
  %slot1978 = alloca i64, align 8
  %slot1979 = alloca i64, align 8
  %slot1980 = alloca i64, align 8
  %slot1981 = alloca i64, align 8
  %slot1982 = alloca i64, align 8
  %slot1983 = alloca i64, align 8
  %slot1984 = alloca i64, align 8
  %slot1985 = alloca i64, align 8
  %slot1986 = alloca i64, align 8
  %slot1987 = alloca i32, align 8
  %slot1988 = alloca i32, align 8
  %slot1989 = alloca i32, align 8
  %slot1990 = alloca i32, align 8
  %slot1991 = alloca i64, align 8
  %slot1992 = alloca i64, align 8
  %slot1993 = alloca i64, align 8
  %slot1994 = alloca i64, align 8
  %slot1995 = alloca i32, align 8
  %slot1996 = alloca i32, align 8
  %slot1997 = alloca i32, align 8
  %slot1998 = alloca i64, align 8
  %slot1999 = alloca i64, align 8
  %slot2000 = alloca i32, align 8
  %slot2001 = alloca i64, align 8
  %slot2002 = alloca i64, align 8
  %slot2003 = alloca i64, align 8
  %slot2004 = alloca i32, align 8
  %slot2005 = alloca i32, align 8
  %slot2006 = alloca i32, align 8
  %slot2007 = alloca i32, align 8
  %slot2008 = alloca i64, align 8
  %slot2009 = alloca i64, align 8
  %slot2010 = alloca i64, align 8
  %slot2011 = alloca i32, align 8
  %slot2012 = alloca i64, align 8
  %slot2013 = alloca i64, align 8
  %slot2014 = alloca i64, align 8
  %slot2015 = alloca i32, align 8
  %slot2016 = alloca i64, align 8
  %slot2017 = alloca i64, align 8
  %slot2018 = alloca i64, align 8
  %slot2019 = alloca i32, align 8
  %slot2020 = alloca i32, align 8
  %slot2021 = alloca i64, align 8
  %slot2022 = alloca i32, align 8
  %slot2023 = alloca i32, align 8
  %slot2024 = alloca i32, align 8
  %slot2025 = alloca i32, align 8
  %slot2026 = alloca i64, align 8
  %slot2027 = alloca i64, align 8
  %slot2028 = alloca i64, align 8
  %slot2029 = alloca i64, align 8
  %slot2030 = alloca i64, align 8
  %slot2031 = alloca i64, align 8
  %slot2032 = alloca i64, align 8
  %slot2033 = alloca i64, align 8
  %slot2034 = alloca i64, align 8
  %slot2035 = alloca i32, align 8
  %slot2036 = alloca i32, align 8
  %slot2037 = alloca i32, align 8
  %slot2038 = alloca i32, align 8
  %slot2039 = alloca i64, align 8
  %slot2040 = alloca i64, align 8
  %slot2041 = alloca i64, align 8
  %slot2042 = alloca i64, align 8
  %slot2043 = alloca i32, align 8
  %slot2044 = alloca i32, align 8
  %slot2045 = alloca i32, align 8
  %slot2046 = alloca i64, align 8
  %slot2047 = alloca i64, align 8
  %slot2048 = alloca i32, align 8
  %slot2049 = alloca i64, align 8
  %slot2050 = alloca i64, align 8
  %slot2051 = alloca i64, align 8
  %slot2052 = alloca i32, align 8
  %slot2053 = alloca i32, align 8
  %slot2054 = alloca i32, align 8
  %slot2055 = alloca i32, align 8
  %slot2056 = alloca i64, align 8
  %slot2057 = alloca i64, align 8
  %slot2058 = alloca i64, align 8
  %slot2059 = alloca i32, align 8
  %slot2060 = alloca i64, align 8
  %slot2061 = alloca i64, align 8
  %slot2062 = alloca i64, align 8
  %slot2063 = alloca i32, align 8
  %slot2064 = alloca i64, align 8
  %slot2065 = alloca i64, align 8
  %slot2066 = alloca i64, align 8
  %slot2067 = alloca i32, align 8
  %slot2068 = alloca i32, align 8
  %slot2069 = alloca i64, align 8
  %slot2070 = alloca i32, align 8
  %slot2071 = alloca i32, align 8
  %slot2072 = alloca i32, align 8
  %slot2073 = alloca i32, align 8
  %slot2074 = alloca i64, align 8
  %slot2075 = alloca i64, align 8
  %slot2076 = alloca i64, align 8
  %slot2077 = alloca i64, align 8
  %slot2078 = alloca i64, align 8
  %slot2079 = alloca i64, align 8
  %slot2080 = alloca i64, align 8
  %slot2081 = alloca i64, align 8
  %slot2082 = alloca i64, align 8
  %slot2083 = alloca i64, align 8
  %slot2084 = alloca i64, align 8
  %slot2085 = alloca i64, align 8
  %slot2086 = alloca i32, align 8
  %slot2087 = alloca i32, align 8
  %slot2088 = alloca i32, align 8
  %slot2089 = alloca i32, align 8
  %slot2090 = alloca i64, align 8
  %slot2091 = alloca i64, align 8
  %slot2092 = alloca i64, align 8
  %slot2093 = alloca i64, align 8
  %slot2094 = alloca i32, align 8
  %slot2095 = alloca i32, align 8
  %slot2096 = alloca i32, align 8
  %slot2097 = alloca i64, align 8
  %slot2098 = alloca i64, align 8
  %slot2099 = alloca i32, align 8
  %slot2100 = alloca i64, align 8
  %slot2101 = alloca i64, align 8
  %slot2102 = alloca i64, align 8
  %slot2103 = alloca i32, align 8
  %slot2104 = alloca i32, align 8
  %slot2105 = alloca i32, align 8
  %slot2106 = alloca i32, align 8
  %slot2107 = alloca i64, align 8
  %slot2108 = alloca i64, align 8
  %slot2109 = alloca i64, align 8
  %slot2110 = alloca i32, align 8
  %slot2111 = alloca i64, align 8
  %slot2112 = alloca i64, align 8
  %slot2113 = alloca i64, align 8
  %slot2114 = alloca i32, align 8
  %slot2115 = alloca i64, align 8
  %slot2116 = alloca i64, align 8
  %slot2117 = alloca i64, align 8
  %slot2118 = alloca i32, align 8
  %slot2119 = alloca i32, align 8
  %slot2120 = alloca i64, align 8
  %slot2121 = alloca i32, align 8
  %slot2122 = alloca i32, align 8
  %slot2123 = alloca i32, align 8
  %slot2124 = alloca i32, align 8
  %slot2125 = alloca i32, align 8
  %slot2126 = alloca i64, align 8
  %slot2127 = alloca i32, align 8
  %slot2128 = alloca i32, align 8
  %slot2129 = alloca i64, align 8
  %slot2130 = alloca i64, align 8
  %slot2131 = alloca i32, align 8
  %slot2132 = alloca i64, align 8
  %slot2133 = alloca i64, align 8
  %slot2134 = alloca i64, align 8
  %slot2135 = alloca i32, align 8
  %slot2136 = alloca i64, align 8
  %slot2137 = alloca i64, align 8
  %slot2138 = alloca i64, align 8
  %slot2139 = alloca i32, align 8
  %slot2140 = alloca i64, align 8
  %slot2141 = alloca i64, align 8
  %slot2142 = alloca i32, align 8
  %slot2143 = alloca i64, align 8
  %slot2144 = alloca i64, align 8
  %slot2145 = alloca i32, align 8
  %slot2146 = alloca i64, align 8
  %slot2147 = alloca i64, align 8
  %slot2148 = alloca i64, align 8
  %slot2149 = alloca i32, align 8
  %slot2150 = alloca i64, align 8
  %slot2151 = alloca i64, align 8
  %slot2152 = alloca i64, align 8
  %slot2153 = alloca i32, align 8
  %slot2154 = alloca i64, align 8
  %slot2155 = alloca i64, align 8
  %slot2156 = alloca i32, align 8
  %slot2157 = alloca i64, align 8
  %slot2158 = alloca i64, align 8
  %slot2159 = alloca i64, align 8
  %slot2160 = alloca i64, align 8
  %slot2161 = alloca i64, align 8
  %slot2162 = alloca i64, align 8
  %slot2163 = alloca i64, align 8
  %slot2164 = alloca i64, align 8
  %slot2165 = alloca i64, align 8
  %slot2166 = alloca i32, align 8
  %slot2167 = alloca i32, align 8
  %slot2168 = alloca i32, align 8
  %slot2169 = alloca i32, align 8
  %slot2170 = alloca i64, align 8
  %slot2171 = alloca i64, align 8
  %slot2172 = alloca i64, align 8
  %slot2173 = alloca i64, align 8
  %slot2174 = alloca i32, align 8
  %slot2175 = alloca i32, align 8
  %slot2176 = alloca i32, align 8
  %slot2177 = alloca i64, align 8
  %slot2178 = alloca i64, align 8
  %slot2179 = alloca i32, align 8
  %slot2180 = alloca i64, align 8
  %slot2181 = alloca i64, align 8
  %slot2182 = alloca i64, align 8
  %slot2183 = alloca i32, align 8
  %slot2184 = alloca i32, align 8
  %slot2185 = alloca i32, align 8
  %slot2186 = alloca i32, align 8
  %slot2187 = alloca i64, align 8
  %slot2188 = alloca i64, align 8
  %slot2189 = alloca i64, align 8
  %slot2190 = alloca i32, align 8
  %slot2191 = alloca i64, align 8
  %slot2192 = alloca i64, align 8
  %slot2193 = alloca i64, align 8
  %slot2194 = alloca i32, align 8
  %slot2195 = alloca i64, align 8
  %slot2196 = alloca i64, align 8
  %slot2197 = alloca i64, align 8
  %slot2198 = alloca i32, align 8
  %slot2199 = alloca i32, align 8
  %slot2200 = alloca i64, align 8
  %slot2201 = alloca i32, align 8
  %slot2202 = alloca i32, align 8
  %slot2203 = alloca i32, align 8
  %slot2204 = alloca i32, align 8
  %slot2205 = alloca i32, align 8
  %slot2206 = alloca i64, align 8
  %slot2207 = alloca i32, align 8
  %slot2208 = alloca i32, align 8
  %slot2209 = alloca i64, align 8
  %slot2210 = alloca i64, align 8
  %slot2211 = alloca i32, align 8
  %slot2212 = alloca i64, align 8
  %slot2213 = alloca i64, align 8
  %slot2214 = alloca i64, align 8
  %slot2215 = alloca i32, align 8
  %slot2216 = alloca i64, align 8
  %slot2217 = alloca i64, align 8
  %slot2218 = alloca i64, align 8
  %slot2219 = alloca i32, align 8
  %slot2220 = alloca i64, align 8
  %slot2221 = alloca i64, align 8
  %slot2222 = alloca i32, align 8
  %slot2223 = alloca i64, align 8
  %slot2224 = alloca i64, align 8
  %slot2225 = alloca i32, align 8
  %slot2226 = alloca i64, align 8
  %slot2227 = alloca i64, align 8
  %slot2228 = alloca i64, align 8
  %slot2229 = alloca i32, align 8
  %slot2230 = alloca i64, align 8
  %slot2231 = alloca i64, align 8
  %slot2232 = alloca i64, align 8
  %slot2233 = alloca i32, align 8
  %slot2234 = alloca i64, align 8
  %slot2235 = alloca i64, align 8
  %slot2236 = alloca i32, align 8
  %slot2237 = alloca i64, align 8
  %slot2238 = alloca i64, align 8
  %slot2239 = alloca i64, align 8
  %slot2240 = alloca i64, align 8
  %slot2241 = alloca i64, align 8
  %slot2242 = alloca i64, align 8
  %slot2243 = alloca i32, align 8
  %slot2244 = alloca i32, align 8
  %slot2245 = alloca i32, align 8
  %slot2246 = alloca i32, align 8
  %slot2247 = alloca i64, align 8
  %slot2248 = alloca i64, align 8
  %slot2249 = alloca i64, align 8
  %slot2250 = alloca i64, align 8
  %slot2251 = alloca i32, align 8
  %slot2252 = alloca i32, align 8
  %slot2253 = alloca i32, align 8
  %slot2254 = alloca i64, align 8
  %slot2255 = alloca i64, align 8
  %slot2256 = alloca i32, align 8
  %slot2257 = alloca i64, align 8
  %slot2258 = alloca i64, align 8
  %slot2259 = alloca i64, align 8
  %slot2260 = alloca i32, align 8
  %slot2261 = alloca i32, align 8
  %slot2262 = alloca i32, align 8
  %slot2263 = alloca i32, align 8
  %slot2264 = alloca i64, align 8
  %slot2265 = alloca i64, align 8
  %slot2266 = alloca i64, align 8
  %slot2267 = alloca i32, align 8
  %slot2268 = alloca i64, align 8
  %slot2269 = alloca i64, align 8
  %slot2270 = alloca i64, align 8
  %slot2271 = alloca i32, align 8
  %slot2272 = alloca i64, align 8
  %slot2273 = alloca i64, align 8
  %slot2274 = alloca i64, align 8
  %slot2275 = alloca i32, align 8
  %slot2276 = alloca i32, align 8
  %slot2277 = alloca i64, align 8
  %slot2278 = alloca i32, align 8
  %slot2279 = alloca i32, align 8
  %slot2280 = alloca i32, align 8
  %slot2281 = alloca i32, align 8
  %slot2282 = alloca i32, align 8
  %slot2283 = alloca i64, align 8
  %slot2284 = alloca i32, align 8
  %slot2285 = alloca i32, align 8
  %slot2286 = alloca i64, align 8
  %slot2287 = alloca i64, align 8
  %slot2288 = alloca i32, align 8
  %slot2289 = alloca i64, align 8
  %slot2290 = alloca i64, align 8
  %slot2291 = alloca i64, align 8
  %slot2292 = alloca i32, align 8
  %slot2293 = alloca i64, align 8
  %slot2294 = alloca i64, align 8
  %slot2295 = alloca i64, align 8
  %slot2296 = alloca i32, align 8
  %slot2297 = alloca i64, align 8
  %slot2298 = alloca i64, align 8
  %slot2299 = alloca i32, align 8
  %slot2300 = alloca i64, align 8
  %slot2301 = alloca i64, align 8
  %slot2302 = alloca i32, align 8
  %slot2303 = alloca i64, align 8
  %slot2304 = alloca i64, align 8
  %slot2305 = alloca i64, align 8
  %slot2306 = alloca i32, align 8
  %slot2307 = alloca i64, align 8
  %slot2308 = alloca i64, align 8
  %slot2309 = alloca i64, align 8
  %slot2310 = alloca i32, align 8
  %slot2311 = alloca i64, align 8
  %slot2312 = alloca i64, align 8
  %slot2313 = alloca i32, align 8
  %slot2314 = alloca i64, align 8
  %slot2315 = alloca i64, align 8
  %slot2316 = alloca i64, align 8
  %slot2317 = alloca i64, align 8
  %slot2318 = alloca i64, align 8
  %slot2319 = alloca i64, align 8
  %slot2320 = alloca i64, align 8
  %slot2321 = alloca i64, align 8
  %slot2322 = alloca i64, align 8
  %slot2323 = alloca i32, align 8
  %slot2324 = alloca i32, align 8
  %slot2325 = alloca i32, align 8
  %slot2326 = alloca i64, align 8
  %slot2327 = alloca i32, align 8
  %slot2328 = alloca i64, align 8
  %slot2329 = alloca i32, align 8
  %slot2330 = alloca i32, align 8
  %slot2331 = alloca i64, align 8
  %slot2332 = alloca i64, align 8
  %slot2333 = alloca i32, align 8
  %slot2334 = alloca i64, align 8
  %slot2335 = alloca i32, align 8
  %slot2336 = alloca i32, align 8
  %slot2337 = alloca i64, align 8
  %slot2338 = alloca i64, align 8
  %slot2339 = alloca i32, align 8
  %slot2340 = alloca i64, align 8
  %slot2341 = alloca i64, align 8
  %slot2342 = alloca i64, align 8
  %slot2343 = alloca i32, align 8
  %slot2344 = alloca i64, align 8
  %slot2345 = alloca i64, align 8
  %slot2346 = alloca i64, align 8
  %slot2347 = alloca i32, align 8
  %slot2348 = alloca i64, align 8
  %slot2349 = alloca i64, align 8
  %slot2350 = alloca i32, align 8
  %slot2351 = alloca i64, align 8
  %slot2352 = alloca i64, align 8
  %slot2353 = alloca i32, align 8
  %slot2354 = alloca i64, align 8
  %slot2355 = alloca i64, align 8
  %slot2356 = alloca i64, align 8
  %slot2357 = alloca i32, align 8
  %slot2358 = alloca i64, align 8
  %slot2359 = alloca i64, align 8
  %slot2360 = alloca i64, align 8
  %slot2361 = alloca i32, align 8
  %slot2362 = alloca i64, align 8
  %slot2363 = alloca i64, align 8
  %slot2364 = alloca i32, align 8
  %slot2365 = alloca i32, align 8
  %slot2366 = alloca i64, align 8
  %slot2367 = alloca i32, align 8
  %slot2368 = alloca i32, align 8
  %slot2369 = alloca i64, align 8
  %slot2370 = alloca i64, align 8
  %slot2371 = alloca i32, align 8
  %slot2372 = alloca i64, align 8
  %slot2373 = alloca i64, align 8
  %slot2374 = alloca i64, align 8
  %slot2375 = alloca i32, align 8
  %slot2376 = alloca i64, align 8
  %slot2377 = alloca i64, align 8
  %slot2378 = alloca i64, align 8
  %slot2379 = alloca i32, align 8
  %slot2380 = alloca i64, align 8
  %slot2381 = alloca i64, align 8
  %slot2382 = alloca i32, align 8
  %slot2383 = alloca i64, align 8
  %slot2384 = alloca i64, align 8
  %slot2385 = alloca i32, align 8
  %slot2386 = alloca i64, align 8
  %slot2387 = alloca i64, align 8
  %slot2388 = alloca i64, align 8
  %slot2389 = alloca i32, align 8
  %slot2390 = alloca i64, align 8
  %slot2391 = alloca i64, align 8
  %slot2392 = alloca i64, align 8
  %slot2393 = alloca i32, align 8
  %slot2394 = alloca i64, align 8
  %slot2395 = alloca i64, align 8
  %slot2396 = alloca i32, align 8
  %slot2397 = alloca i32, align 8
  %slot2398 = alloca i64, align 8
  %slot2399 = alloca i32, align 8
  %slot2400 = alloca i32, align 8
  %slot2401 = alloca i64, align 8
  %slot2402 = alloca i64, align 8
  %slot2403 = alloca i32, align 8
  %slot2404 = alloca i64, align 8
  %slot2405 = alloca i64, align 8
  %slot2406 = alloca i64, align 8
  %slot2407 = alloca i32, align 8
  %slot2408 = alloca i64, align 8
  %slot2409 = alloca i64, align 8
  %slot2410 = alloca i64, align 8
  %slot2411 = alloca i32, align 8
  %slot2412 = alloca i64, align 8
  %slot2413 = alloca i64, align 8
  %slot2414 = alloca i32, align 8
  %slot2415 = alloca i64, align 8
  %slot2416 = alloca i64, align 8
  %slot2417 = alloca i32, align 8
  %slot2418 = alloca i64, align 8
  %slot2419 = alloca i64, align 8
  %slot2420 = alloca i64, align 8
  %slot2421 = alloca i32, align 8
  %slot2422 = alloca i64, align 8
  %slot2423 = alloca i64, align 8
  %slot2424 = alloca i64, align 8
  %slot2425 = alloca i32, align 8
  %slot2426 = alloca i64, align 8
  %slot2427 = alloca i64, align 8
  %slot2428 = alloca i32, align 8
  %slot2429 = alloca i32, align 8
  %slot2430 = alloca i64, align 8
  %slot2431 = alloca i32, align 8
  %slot2432 = alloca i32, align 8
  %slot2433 = alloca i64, align 8
  %slot2434 = alloca i64, align 8
  %slot2435 = alloca i32, align 8
  %slot2436 = alloca i64, align 8
  %slot2437 = alloca i64, align 8
  %slot2438 = alloca i64, align 8
  %slot2439 = alloca i32, align 8
  %slot2440 = alloca i64, align 8
  %slot2441 = alloca i64, align 8
  %slot2442 = alloca i64, align 8
  %slot2443 = alloca i32, align 8
  %slot2444 = alloca i64, align 8
  %slot2445 = alloca i64, align 8
  %slot2446 = alloca i32, align 8
  %slot2447 = alloca i64, align 8
  %slot2448 = alloca i64, align 8
  %slot2449 = alloca i32, align 8
  %slot2450 = alloca i64, align 8
  %slot2451 = alloca i64, align 8
  %slot2452 = alloca i64, align 8
  %slot2453 = alloca i32, align 8
  %slot2454 = alloca i64, align 8
  %slot2455 = alloca i64, align 8
  %slot2456 = alloca i64, align 8
  %slot2457 = alloca i32, align 8
  %slot2458 = alloca i64, align 8
  %slot2459 = alloca i64, align 8
  %slot2460 = alloca i32, align 8
  %slot2461 = alloca i32, align 8
  %slot2462 = alloca i64, align 8
  %slot2463 = alloca i32, align 8
  %slot2464 = alloca i32, align 8
  %slot2465 = alloca i64, align 8
  %slot2466 = alloca i64, align 8
  %slot2467 = alloca i32, align 8
  %slot2468 = alloca i64, align 8
  %slot2469 = alloca i64, align 8
  %slot2470 = alloca i64, align 8
  %slot2471 = alloca i32, align 8
  %slot2472 = alloca i64, align 8
  %slot2473 = alloca i64, align 8
  %slot2474 = alloca i64, align 8
  %slot2475 = alloca i32, align 8
  %slot2476 = alloca i64, align 8
  %slot2477 = alloca i64, align 8
  %slot2478 = alloca i32, align 8
  %slot2479 = alloca i64, align 8
  %slot2480 = alloca i64, align 8
  %slot2481 = alloca i32, align 8
  %slot2482 = alloca i64, align 8
  %slot2483 = alloca i64, align 8
  %slot2484 = alloca i64, align 8
  %slot2485 = alloca i32, align 8
  %slot2486 = alloca i64, align 8
  %slot2487 = alloca i64, align 8
  %slot2488 = alloca i64, align 8
  %slot2489 = alloca i32, align 8
  %slot2490 = alloca i64, align 8
  %slot2491 = alloca i64, align 8
  %slot2492 = alloca i32, align 8
  %slot2493 = alloca i32, align 8
  %slot2494 = alloca i64, align 8
  %slot2495 = alloca i32, align 8
  %slot2496 = alloca i32, align 8
  %slot2497 = alloca i64, align 8
  %slot2498 = alloca i64, align 8
  %slot2499 = alloca i32, align 8
  %slot2500 = alloca i64, align 8
  %slot2501 = alloca i64, align 8
  %slot2502 = alloca i64, align 8
  %slot2503 = alloca i32, align 8
  %slot2504 = alloca i64, align 8
  %slot2505 = alloca i64, align 8
  %slot2506 = alloca i64, align 8
  %slot2507 = alloca i32, align 8
  %slot2508 = alloca i64, align 8
  %slot2509 = alloca i64, align 8
  %slot2510 = alloca i32, align 8
  %slot2511 = alloca i64, align 8
  %slot2512 = alloca i64, align 8
  %slot2513 = alloca i32, align 8
  %slot2514 = alloca i64, align 8
  %slot2515 = alloca i64, align 8
  %slot2516 = alloca i64, align 8
  %slot2517 = alloca i32, align 8
  %slot2518 = alloca i64, align 8
  %slot2519 = alloca i64, align 8
  %slot2520 = alloca i64, align 8
  %slot2521 = alloca i32, align 8
  %slot2522 = alloca i64, align 8
  %slot2523 = alloca i64, align 8
  %slot2524 = alloca i32, align 8
  %slot2525 = alloca i32, align 8
  %slot2526 = alloca i64, align 8
  %slot2527 = alloca i32, align 8
  %slot2528 = alloca i32, align 8
  %slot2529 = alloca i64, align 8
  %slot2530 = alloca i64, align 8
  %slot2531 = alloca i32, align 8
  %slot2532 = alloca i64, align 8
  %slot2533 = alloca i64, align 8
  %slot2534 = alloca i64, align 8
  %slot2535 = alloca i32, align 8
  %slot2536 = alloca i64, align 8
  %slot2537 = alloca i64, align 8
  %slot2538 = alloca i64, align 8
  %slot2539 = alloca i32, align 8
  %slot2540 = alloca i64, align 8
  %slot2541 = alloca i64, align 8
  %slot2542 = alloca i32, align 8
  %slot2543 = alloca i64, align 8
  %slot2544 = alloca i64, align 8
  %slot2545 = alloca i32, align 8
  %slot2546 = alloca i64, align 8
  %slot2547 = alloca i64, align 8
  %slot2548 = alloca i64, align 8
  %slot2549 = alloca i32, align 8
  %slot2550 = alloca i64, align 8
  %slot2551 = alloca i64, align 8
  %slot2552 = alloca i64, align 8
  %slot2553 = alloca i32, align 8
  %slot2554 = alloca i64, align 8
  %slot2555 = alloca i64, align 8
  %slot2556 = alloca i32, align 8
  %slot2557 = alloca i32, align 8
  %slot2558 = alloca i64, align 8
  %slot2559 = alloca i32, align 8
  %slot2560 = alloca i32, align 8
  %slot2561 = alloca i64, align 8
  %slot2562 = alloca i64, align 8
  %slot2563 = alloca i32, align 8
  %slot2564 = alloca i64, align 8
  %slot2565 = alloca i64, align 8
  %slot2566 = alloca i64, align 8
  %slot2567 = alloca i32, align 8
  %slot2568 = alloca i64, align 8
  %slot2569 = alloca i64, align 8
  %slot2570 = alloca i64, align 8
  %slot2571 = alloca i32, align 8
  %slot2572 = alloca i64, align 8
  %slot2573 = alloca i64, align 8
  %slot2574 = alloca i32, align 8
  %slot2575 = alloca i64, align 8
  %slot2576 = alloca i64, align 8
  %slot2577 = alloca i32, align 8
  %slot2578 = alloca i64, align 8
  %slot2579 = alloca i64, align 8
  %slot2580 = alloca i64, align 8
  %slot2581 = alloca i32, align 8
  %slot2582 = alloca i64, align 8
  %slot2583 = alloca i64, align 8
  %slot2584 = alloca i64, align 8
  %slot2585 = alloca i32, align 8
  %slot2586 = alloca i64, align 8
  %slot2587 = alloca i64, align 8
  %slot2588 = alloca i32, align 8
  %slot2589 = alloca i32, align 8
  %slot2590 = alloca i64, align 8
  %slot2591 = alloca i32, align 8
  %slot2592 = alloca i32, align 8
  %slot2593 = alloca i64, align 8
  %slot2594 = alloca i64, align 8
  %slot2595 = alloca i32, align 8
  %slot2596 = alloca i64, align 8
  %slot2597 = alloca i64, align 8
  %slot2598 = alloca i64, align 8
  %slot2599 = alloca i32, align 8
  %slot2600 = alloca i64, align 8
  %slot2601 = alloca i64, align 8
  %slot2602 = alloca i64, align 8
  %slot2603 = alloca i32, align 8
  %slot2604 = alloca i64, align 8
  %slot2605 = alloca i64, align 8
  %slot2606 = alloca i32, align 8
  %slot2607 = alloca i64, align 8
  %slot2608 = alloca i64, align 8
  %slot2609 = alloca i32, align 8
  %slot2610 = alloca i64, align 8
  %slot2611 = alloca i64, align 8
  %slot2612 = alloca i64, align 8
  %slot2613 = alloca i32, align 8
  %slot2614 = alloca i64, align 8
  %slot2615 = alloca i64, align 8
  %slot2616 = alloca i64, align 8
  %slot2617 = alloca i32, align 8
  %slot2618 = alloca i64, align 8
  %slot2619 = alloca i64, align 8
  %slot2620 = alloca i32, align 8
  %slot2621 = alloca i32, align 8
  %slot2622 = alloca i64, align 8
  %slot2623 = alloca i32, align 8
  %slot2624 = alloca i32, align 8
  %slot2625 = alloca i64, align 8
  %slot2626 = alloca i64, align 8
  %slot2627 = alloca i32, align 8
  %slot2628 = alloca i64, align 8
  %slot2629 = alloca i64, align 8
  %slot2630 = alloca i64, align 8
  %slot2631 = alloca i32, align 8
  %slot2632 = alloca i64, align 8
  %slot2633 = alloca i64, align 8
  %slot2634 = alloca i64, align 8
  %slot2635 = alloca i32, align 8
  %slot2636 = alloca i64, align 8
  %slot2637 = alloca i64, align 8
  %slot2638 = alloca i32, align 8
  %slot2639 = alloca i64, align 8
  %slot2640 = alloca i64, align 8
  %slot2641 = alloca i32, align 8
  %slot2642 = alloca i64, align 8
  %slot2643 = alloca i64, align 8
  %slot2644 = alloca i64, align 8
  %slot2645 = alloca i32, align 8
  %slot2646 = alloca i64, align 8
  %slot2647 = alloca i64, align 8
  %slot2648 = alloca i64, align 8
  %slot2649 = alloca i32, align 8
  %slot2650 = alloca i64, align 8
  %slot2651 = alloca i64, align 8
  %slot2652 = alloca i32, align 8
  %slot2653 = alloca i32, align 8
  %slot2654 = alloca i64, align 8
  %slot2655 = alloca i32, align 8
  %slot2656 = alloca i32, align 8
  %slot2657 = alloca i64, align 8
  %slot2658 = alloca i64, align 8
  %slot2659 = alloca i32, align 8
  %slot2660 = alloca i64, align 8
  %slot2661 = alloca i64, align 8
  %slot2662 = alloca i64, align 8
  %slot2663 = alloca i32, align 8
  %slot2664 = alloca i64, align 8
  %slot2665 = alloca i64, align 8
  %slot2666 = alloca i64, align 8
  %slot2667 = alloca i32, align 8
  %slot2668 = alloca i64, align 8
  %slot2669 = alloca i64, align 8
  %slot2670 = alloca i32, align 8
  %slot2671 = alloca i64, align 8
  %slot2672 = alloca i64, align 8
  %slot2673 = alloca i32, align 8
  %slot2674 = alloca i64, align 8
  %slot2675 = alloca i64, align 8
  %slot2676 = alloca i64, align 8
  %slot2677 = alloca i32, align 8
  %slot2678 = alloca i64, align 8
  %slot2679 = alloca i64, align 8
  %slot2680 = alloca i64, align 8
  %slot2681 = alloca i32, align 8
  %slot2682 = alloca i64, align 8
  %slot2683 = alloca i64, align 8
  %slot2684 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v2685 = load i64, ptr %slot1, align 8
  %op2686 = add i64 %v2685, 32
  store i64 %op2686, ptr %slot4, align 8
  %mem2687 = alloca i8, i64 208, align 8
  %ptr2688 = ptrtoint ptr %mem2687 to i64
  store i64 %ptr2688, ptr %slot5, align 8
  %mem2689 = alloca i8, i64 8, align 8
  %ptr2690 = ptrtoint ptr %mem2689 to i64
  store i64 %ptr2690, ptr %slot6, align 8
  %mem2691 = alloca i8, i64 8, align 8
  %ptr2692 = ptrtoint ptr %mem2691 to i64
  store i64 %ptr2692, ptr %slot7, align 8
  %mem2693 = alloca i8, i64 8, align 8
  %ptr2694 = ptrtoint ptr %mem2693 to i64
  store i64 %ptr2694, ptr %slot8, align 8
  %mem2695 = alloca i8, i64 8, align 8
  %ptr2696 = ptrtoint ptr %mem2695 to i64
  store i64 %ptr2696, ptr %slot9, align 8
  %mem2697 = alloca i8, i64 8, align 8
  %ptr2698 = ptrtoint ptr %mem2697 to i64
  store i64 %ptr2698, ptr %slot10, align 8
  %mem2699 = alloca i8, i64 8, align 8
  %ptr2700 = ptrtoint ptr %mem2699 to i64
  store i64 %ptr2700, ptr %slot11, align 8
  %mem2701 = alloca i8, i64 8, align 8
  %ptr2702 = ptrtoint ptr %mem2701 to i64
  store i64 %ptr2702, ptr %slot12, align 8
  %mem2703 = alloca i8, i64 8, align 8
  %ptr2704 = ptrtoint ptr %mem2703 to i64
  store i64 %ptr2704, ptr %slot13, align 8
  %mem2705 = alloca i8, i64 8, align 8
  %ptr2706 = ptrtoint ptr %mem2705 to i64
  store i64 %ptr2706, ptr %slot14, align 8
  %mem2707 = alloca i8, i64 8, align 8
  %ptr2708 = ptrtoint ptr %mem2707 to i64
  store i64 %ptr2708, ptr %slot15, align 8
  %mem2709 = alloca i8, i64 8, align 8
  %ptr2710 = ptrtoint ptr %mem2709 to i64
  store i64 %ptr2710, ptr %slot16, align 8
  %mem2711 = alloca i8, i64 8, align 8
  %ptr2712 = ptrtoint ptr %mem2711 to i64
  store i64 %ptr2712, ptr %slot17, align 8
  %mem2713 = alloca i8, i64 8, align 8
  %ptr2714 = ptrtoint ptr %mem2713 to i64
  store i64 %ptr2714, ptr %slot18, align 8
  %mem2715 = alloca i8, i64 8, align 8
  %ptr2716 = ptrtoint ptr %mem2715 to i64
  store i64 %ptr2716, ptr %slot19, align 8
  %mem2717 = alloca i8, i64 8, align 8
  %ptr2718 = ptrtoint ptr %mem2717 to i64
  store i64 %ptr2718, ptr %slot20, align 8
  %mem2719 = alloca i8, i64 8, align 8
  %ptr2720 = ptrtoint ptr %mem2719 to i64
  store i64 %ptr2720, ptr %slot21, align 8
  %mem2721 = alloca i8, i64 8, align 8
  %ptr2722 = ptrtoint ptr %mem2721 to i64
  store i64 %ptr2722, ptr %slot22, align 8
  %mem2723 = alloca i8, i64 8, align 8
  %ptr2724 = ptrtoint ptr %mem2723 to i64
  store i64 %ptr2724, ptr %slot23, align 8
  %mem2725 = alloca i8, i64 8, align 8
  %ptr2726 = ptrtoint ptr %mem2725 to i64
  store i64 %ptr2726, ptr %slot24, align 8
  %mem2727 = alloca i8, i64 8, align 8
  %ptr2728 = ptrtoint ptr %mem2727 to i64
  store i64 %ptr2728, ptr %slot25, align 8
  %mem2729 = alloca i8, i64 8, align 8
  %ptr2730 = ptrtoint ptr %mem2729 to i64
  store i64 %ptr2730, ptr %slot26, align 8
  %mem2731 = alloca i8, i64 8, align 8
  %ptr2732 = ptrtoint ptr %mem2731 to i64
  store i64 %ptr2732, ptr %slot27, align 8
  %mem2733 = alloca i8, i64 8, align 8
  %ptr2734 = ptrtoint ptr %mem2733 to i64
  store i64 %ptr2734, ptr %slot28, align 8
  %mem2735 = alloca i8, i64 8, align 8
  %ptr2736 = ptrtoint ptr %mem2735 to i64
  store i64 %ptr2736, ptr %slot29, align 8
  %mem2737 = alloca i8, i64 8, align 8
  %ptr2738 = ptrtoint ptr %mem2737 to i64
  store i64 %ptr2738, ptr %slot30, align 8
  %mem2739 = alloca i8, i64 8, align 8
  %ptr2740 = ptrtoint ptr %mem2739 to i64
  store i64 %ptr2740, ptr %slot31, align 8
  %mem2741 = alloca i8, i64 8, align 8
  %ptr2742 = ptrtoint ptr %mem2741 to i64
  store i64 %ptr2742, ptr %slot32, align 8
  %mem2743 = alloca i8, i64 8, align 8
  %ptr2744 = ptrtoint ptr %mem2743 to i64
  store i64 %ptr2744, ptr %slot33, align 8
  %mem2745 = alloca i8, i64 8, align 8
  %ptr2746 = ptrtoint ptr %mem2745 to i64
  store i64 %ptr2746, ptr %slot34, align 8
  %mem2747 = alloca i8, i64 8, align 8
  %ptr2748 = ptrtoint ptr %mem2747 to i64
  store i64 %ptr2748, ptr %slot35, align 8
  %mem2749 = alloca i8, i64 8, align 8
  %ptr2750 = ptrtoint ptr %mem2749 to i64
  store i64 %ptr2750, ptr %slot36, align 8
  %mem2751 = alloca i8, i64 8, align 8
  %ptr2752 = ptrtoint ptr %mem2751 to i64
  store i64 %ptr2752, ptr %slot37, align 8
  %mem2753 = alloca i8, i64 8, align 8
  %ptr2754 = ptrtoint ptr %mem2753 to i64
  store i64 %ptr2754, ptr %slot38, align 8
  %mem2755 = alloca i8, i64 8, align 8
  %ptr2756 = ptrtoint ptr %mem2755 to i64
  store i64 %ptr2756, ptr %slot39, align 8
  %mem2757 = alloca i8, i64 8, align 8
  %ptr2758 = ptrtoint ptr %mem2757 to i64
  store i64 %ptr2758, ptr %slot40, align 8
  %mem2759 = alloca i8, i64 8, align 8
  %ptr2760 = ptrtoint ptr %mem2759 to i64
  store i64 %ptr2760, ptr %slot41, align 8
  %mem2761 = alloca i8, i64 8, align 8
  %ptr2762 = ptrtoint ptr %mem2761 to i64
  store i64 %ptr2762, ptr %slot42, align 8
  %mem2763 = alloca i8, i64 8, align 8
  %ptr2764 = ptrtoint ptr %mem2763 to i64
  store i64 %ptr2764, ptr %slot43, align 8
  %mem2765 = alloca i8, i64 8, align 8
  %ptr2766 = ptrtoint ptr %mem2765 to i64
  store i64 %ptr2766, ptr %slot44, align 8
  %mem2767 = alloca i8, i64 8, align 8
  %ptr2768 = ptrtoint ptr %mem2767 to i64
  store i64 %ptr2768, ptr %slot45, align 8
  %mem2769 = alloca i8, i64 8, align 8
  %ptr2770 = ptrtoint ptr %mem2769 to i64
  store i64 %ptr2770, ptr %slot46, align 8
  %mem2771 = alloca i8, i64 8, align 8
  %ptr2772 = ptrtoint ptr %mem2771 to i64
  store i64 %ptr2772, ptr %slot47, align 8
  %mem2773 = alloca i8, i64 8, align 8
  %ptr2774 = ptrtoint ptr %mem2773 to i64
  store i64 %ptr2774, ptr %slot48, align 8
  %mem2775 = alloca i8, i64 208, align 8
  %ptr2776 = ptrtoint ptr %mem2775 to i64
  store i64 %ptr2776, ptr %slot49, align 8
  %mem2777 = alloca i8, i64 16, align 8
  %ptr2778 = ptrtoint ptr %mem2777 to i64
  store i64 %ptr2778, ptr %slot50, align 8
  %mem2779 = alloca i8, i64 8, align 8
  %ptr2780 = ptrtoint ptr %mem2779 to i64
  store i64 %ptr2780, ptr %slot51, align 8
  %mem2781 = alloca i8, i64 16, align 8
  %ptr2782 = ptrtoint ptr %mem2781 to i64
  store i64 %ptr2782, ptr %slot52, align 8
  %mem2783 = alloca i8, i64 16, align 8
  %ptr2784 = ptrtoint ptr %mem2783 to i64
  store i64 %ptr2784, ptr %slot53, align 8
  %mem2785 = alloca i8, i64 8, align 8
  %ptr2786 = ptrtoint ptr %mem2785 to i64
  store i64 %ptr2786, ptr %slot54, align 8
  %mem2787 = alloca i8, i64 8, align 8
  %ptr2788 = ptrtoint ptr %mem2787 to i64
  store i64 %ptr2788, ptr %slot55, align 8
  %mem2789 = alloca i8, i64 8, align 8
  %ptr2790 = ptrtoint ptr %mem2789 to i64
  store i64 %ptr2790, ptr %slot56, align 8
  %mem2791 = alloca i8, i64 8, align 8
  %ptr2792 = ptrtoint ptr %mem2791 to i64
  store i64 %ptr2792, ptr %slot57, align 8
  %mem2793 = alloca i8, i64 8, align 8
  %ptr2794 = ptrtoint ptr %mem2793 to i64
  store i64 %ptr2794, ptr %slot58, align 8
  %mem2795 = alloca i8, i64 8, align 8
  %ptr2796 = ptrtoint ptr %mem2795 to i64
  store i64 %ptr2796, ptr %slot59, align 8
  %mem2797 = alloca i8, i64 8, align 8
  %ptr2798 = ptrtoint ptr %mem2797 to i64
  store i64 %ptr2798, ptr %slot60, align 8
  %mem2799 = alloca i8, i64 8, align 8
  %ptr2800 = ptrtoint ptr %mem2799 to i64
  store i64 %ptr2800, ptr %slot61, align 8
  %mem2801 = alloca i8, i64 8, align 8
  %ptr2802 = ptrtoint ptr %mem2801 to i64
  store i64 %ptr2802, ptr %slot62, align 8
  %mem2803 = alloca i8, i64 8, align 8
  %ptr2804 = ptrtoint ptr %mem2803 to i64
  store i64 %ptr2804, ptr %slot63, align 8
  %mem2805 = alloca i8, i64 8, align 8
  %ptr2806 = ptrtoint ptr %mem2805 to i64
  store i64 %ptr2806, ptr %slot64, align 8
  %mem2807 = alloca i8, i64 208, align 8
  %ptr2808 = ptrtoint ptr %mem2807 to i64
  store i64 %ptr2808, ptr %slot65, align 8
  %mem2809 = alloca i8, i64 8, align 8
  %ptr2810 = ptrtoint ptr %mem2809 to i64
  store i64 %ptr2810, ptr %slot66, align 8
  %mem2811 = alloca i8, i64 8, align 8
  %ptr2812 = ptrtoint ptr %mem2811 to i64
  store i64 %ptr2812, ptr %slot67, align 8
  %mem2813 = alloca i8, i64 8, align 8
  %ptr2814 = ptrtoint ptr %mem2813 to i64
  store i64 %ptr2814, ptr %slot68, align 8
  %mem2815 = alloca i8, i64 8, align 8
  %ptr2816 = ptrtoint ptr %mem2815 to i64
  store i64 %ptr2816, ptr %slot69, align 8
  %mem2817 = alloca i8, i64 8, align 8
  %ptr2818 = ptrtoint ptr %mem2817 to i64
  store i64 %ptr2818, ptr %slot70, align 8
  %mem2819 = alloca i8, i64 8, align 8
  %ptr2820 = ptrtoint ptr %mem2819 to i64
  store i64 %ptr2820, ptr %slot71, align 8
  %mem2821 = alloca i8, i64 8, align 8
  %ptr2822 = ptrtoint ptr %mem2821 to i64
  store i64 %ptr2822, ptr %slot72, align 8
  %mem2823 = alloca i8, i64 8, align 8
  %ptr2824 = ptrtoint ptr %mem2823 to i64
  store i64 %ptr2824, ptr %slot73, align 8
  %mem2825 = alloca i8, i64 8, align 8
  %ptr2826 = ptrtoint ptr %mem2825 to i64
  store i64 %ptr2826, ptr %slot74, align 8
  %mem2827 = alloca i8, i64 8, align 8
  %ptr2828 = ptrtoint ptr %mem2827 to i64
  store i64 %ptr2828, ptr %slot75, align 8
  %mem2829 = alloca i8, i64 8, align 8
  %ptr2830 = ptrtoint ptr %mem2829 to i64
  store i64 %ptr2830, ptr %slot76, align 8
  %mem2831 = alloca i8, i64 8, align 8
  %ptr2832 = ptrtoint ptr %mem2831 to i64
  store i64 %ptr2832, ptr %slot77, align 8
  %mem2833 = alloca i8, i64 8, align 8
  %ptr2834 = ptrtoint ptr %mem2833 to i64
  store i64 %ptr2834, ptr %slot78, align 8
  %mem2835 = alloca i8, i64 8, align 8
  %ptr2836 = ptrtoint ptr %mem2835 to i64
  store i64 %ptr2836, ptr %slot79, align 8
  %mem2837 = alloca i8, i64 8, align 8
  %ptr2838 = ptrtoint ptr %mem2837 to i64
  store i64 %ptr2838, ptr %slot80, align 8
  %mem2839 = alloca i8, i64 8, align 8
  %ptr2840 = ptrtoint ptr %mem2839 to i64
  store i64 %ptr2840, ptr %slot81, align 8
  %mem2841 = alloca i8, i64 8, align 8
  %ptr2842 = ptrtoint ptr %mem2841 to i64
  store i64 %ptr2842, ptr %slot82, align 8
  %mem2843 = alloca i8, i64 8, align 8
  %ptr2844 = ptrtoint ptr %mem2843 to i64
  store i64 %ptr2844, ptr %slot83, align 8
  %mem2845 = alloca i8, i64 8, align 8
  %ptr2846 = ptrtoint ptr %mem2845 to i64
  store i64 %ptr2846, ptr %slot84, align 8
  %mem2847 = alloca i8, i64 8, align 8
  %ptr2848 = ptrtoint ptr %mem2847 to i64
  store i64 %ptr2848, ptr %slot85, align 8
  %mem2849 = alloca i8, i64 8, align 8
  %ptr2850 = ptrtoint ptr %mem2849 to i64
  store i64 %ptr2850, ptr %slot86, align 8
  %mem2851 = alloca i8, i64 8, align 8
  %ptr2852 = ptrtoint ptr %mem2851 to i64
  store i64 %ptr2852, ptr %slot87, align 8
  %mem2853 = alloca i8, i64 8, align 8
  %ptr2854 = ptrtoint ptr %mem2853 to i64
  store i64 %ptr2854, ptr %slot88, align 8
  %mem2855 = alloca i8, i64 8, align 8
  %ptr2856 = ptrtoint ptr %mem2855 to i64
  store i64 %ptr2856, ptr %slot89, align 8
  %mem2857 = alloca i8, i64 8, align 8
  %ptr2858 = ptrtoint ptr %mem2857 to i64
  store i64 %ptr2858, ptr %slot90, align 8
  %mem2859 = alloca i8, i64 8, align 8
  %ptr2860 = ptrtoint ptr %mem2859 to i64
  store i64 %ptr2860, ptr %slot91, align 8
  %mem2861 = alloca i8, i64 8, align 8
  %ptr2862 = ptrtoint ptr %mem2861 to i64
  store i64 %ptr2862, ptr %slot92, align 8
  %mem2863 = alloca i8, i64 8, align 8
  %ptr2864 = ptrtoint ptr %mem2863 to i64
  store i64 %ptr2864, ptr %slot93, align 8
  %mem2865 = alloca i8, i64 8, align 8
  %ptr2866 = ptrtoint ptr %mem2865 to i64
  store i64 %ptr2866, ptr %slot94, align 8
  %mem2867 = alloca i8, i64 8, align 8
  %ptr2868 = ptrtoint ptr %mem2867 to i64
  store i64 %ptr2868, ptr %slot95, align 8
  %mem2869 = alloca i8, i64 8, align 8
  %ptr2870 = ptrtoint ptr %mem2869 to i64
  store i64 %ptr2870, ptr %slot96, align 8
  %mem2871 = alloca i8, i64 8, align 8
  %ptr2872 = ptrtoint ptr %mem2871 to i64
  store i64 %ptr2872, ptr %slot97, align 8
  %mem2873 = alloca i8, i64 8, align 8
  %ptr2874 = ptrtoint ptr %mem2873 to i64
  store i64 %ptr2874, ptr %slot98, align 8
  %mem2875 = alloca i8, i64 8, align 8
  %ptr2876 = ptrtoint ptr %mem2875 to i64
  store i64 %ptr2876, ptr %slot99, align 8
  %mem2877 = alloca i8, i64 8, align 8
  %ptr2878 = ptrtoint ptr %mem2877 to i64
  store i64 %ptr2878, ptr %slot100, align 8
  %mem2879 = alloca i8, i64 8, align 8
  %ptr2880 = ptrtoint ptr %mem2879 to i64
  store i64 %ptr2880, ptr %slot101, align 8
  %mem2881 = alloca i8, i64 16, align 8
  %ptr2882 = ptrtoint ptr %mem2881 to i64
  store i64 %ptr2882, ptr %slot102, align 8
  %mem2883 = alloca i8, i64 24, align 8
  %ptr2884 = ptrtoint ptr %mem2883 to i64
  store i64 %ptr2884, ptr %slot103, align 8
  %mem2885 = alloca i8, i64 16, align 8
  %ptr2886 = ptrtoint ptr %mem2885 to i64
  store i64 %ptr2886, ptr %slot104, align 8
  %mem2887 = alloca i8, i64 208, align 8
  %ptr2888 = ptrtoint ptr %mem2887 to i64
  store i64 %ptr2888, ptr %slot105, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem2889 = alloca i8, i64 8, align 8
  %ptr2890 = ptrtoint ptr %mem2889 to i64
  store i64 %ptr2890, ptr %slot106, align 8
  %v2891 = load i64, ptr %slot1, align 8
  %op2892 = add i64 %v2891, 64
  store i64 %op2892, ptr %slot107, align 8
  %v2893 = load i64, ptr %slot107, align 8
  %p2894 = inttoptr i64 %v2893 to ptr
  %ld2895 = load i64, ptr %p2894, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2895, ptr %slot108, align 8
  %stack2896 = call ptr @llvm.stacksave()
  %stackaddr2897 = ptrtoint ptr %stack2896 to i64
  %v2898 = load i64, ptr %slot108, align 8
  %cmp2899 = icmp ult i64 %stackaddr2897, %v2898
  %cv2900 = zext i1 %cmp2899 to i64
  store i64 %cv2900, ptr %slot109, align 8
  %v2901 = load i64, ptr %slot109, align 8
  %cond2902 = icmp ne i64 %v2901, 0
  br i1 %cond2902, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v2903 = load i64, ptr %slot1, align 8
  %p2904 = inttoptr i64 %v2903 to ptr
  call void @myl_qbe_fail_frame(ptr %p2904) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v2905 = load i64, ptr %slot68, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  store i64 0, ptr %p2906, align 8, !alias.scope !3, !noalias !4
  %v2907 = load i64, ptr %slot69, align 8
  %p2908 = inttoptr i64 %v2907 to ptr
  store i64 0, ptr %p2908, align 8, !alias.scope !3, !noalias !4
  %v2909 = load i64, ptr %slot71, align 8
  %p2910 = inttoptr i64 %v2909 to ptr
  store i64 0, ptr %p2910, align 8, !alias.scope !3, !noalias !4
  %v2911 = load i64, ptr %slot72, align 8
  %p2912 = inttoptr i64 %v2911 to ptr
  store i64 0, ptr %p2912, align 8, !alias.scope !3, !noalias !4
  %v2913 = load i64, ptr %slot73, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  store i64 0, ptr %p2914, align 8, !alias.scope !3, !noalias !4
  %v2915 = load i64, ptr %slot74, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  store i64 0, ptr %p2916, align 8, !alias.scope !3, !noalias !4
  %v2917 = load i64, ptr %slot75, align 8
  %p2918 = inttoptr i64 %v2917 to ptr
  store i64 0, ptr %p2918, align 8, !alias.scope !3, !noalias !4
  %v2919 = load i64, ptr %slot76, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  store i64 0, ptr %p2920, align 8, !alias.scope !3, !noalias !4
  %v2921 = load i64, ptr %slot77, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  store i64 0, ptr %p2922, align 8, !alias.scope !3, !noalias !4
  %v2923 = load i64, ptr %slot78, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  store i64 0, ptr %p2924, align 8, !alias.scope !3, !noalias !4
  %v2925 = load i64, ptr %slot79, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  store i64 0, ptr %p2926, align 8, !alias.scope !3, !noalias !4
  %v2927 = load i64, ptr %slot2, align 8
  %v2928 = load i64, ptr %slot66, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  store i64 %v2927, ptr %p2929, align 8, !alias.scope !3, !noalias !4
  %v2930 = load i64, ptr %slot3, align 8
  %v2931 = load i64, ptr %slot67, align 8
  %p2932 = inttoptr i64 %v2931 to ptr
  store i64 %v2930, ptr %p2932, align 8, !alias.scope !3, !noalias !4
  %v2933 = load i64, ptr %slot1, align 8
  %p2934 = inttoptr i64 %v2933 to ptr
  %call2935 = call ptr @myl_qbe_heap(ptr %p2934) nomerge, !dbg !112
  %calladdr2936 = ptrtoint ptr %call2935 to i64
  store i64 %calladdr2936, ptr %slot110, align 8
  %v2937 = load i64, ptr %slot1, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  %call2939 = call i64 @myl_qbe_region_mark(ptr %p2938) nomerge, !dbg !112
  store i64 %call2939, ptr %slot111, align 8
  %v2940 = load i64, ptr %slot6, align 8
  %p2941 = inttoptr i64 %v2940 to ptr
  store i32 0, ptr %p2941, align 4, !alias.scope !3, !noalias !4
  %v2942 = load i64, ptr %slot7, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  store i32 0, ptr %p2943, align 4, !alias.scope !3, !noalias !4
  %v2944 = load i64, ptr %slot8, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  store i32 0, ptr %p2945, align 4, !alias.scope !3, !noalias !4
  %v2946 = load i64, ptr %slot9, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  store i32 0, ptr %p2947, align 4, !alias.scope !3, !noalias !4
  %v2948 = load i64, ptr %slot10, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  store i32 0, ptr %p2949, align 4, !alias.scope !3, !noalias !4
  %v2950 = load i64, ptr %slot11, align 8
  %p2951 = inttoptr i64 %v2950 to ptr
  store i32 0, ptr %p2951, align 4, !alias.scope !3, !noalias !4
  %v2952 = load i64, ptr %slot12, align 8
  %p2953 = inttoptr i64 %v2952 to ptr
  store i32 0, ptr %p2953, align 4, !alias.scope !3, !noalias !4
  %v2954 = load i64, ptr %slot13, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  store i32 0, ptr %p2955, align 4, !alias.scope !3, !noalias !4
  %v2956 = load i64, ptr %slot14, align 8
  %p2957 = inttoptr i64 %v2956 to ptr
  store i32 0, ptr %p2957, align 4, !alias.scope !3, !noalias !4
  %v2958 = load i64, ptr %slot15, align 8
  %p2959 = inttoptr i64 %v2958 to ptr
  store i32 0, ptr %p2959, align 4, !alias.scope !3, !noalias !4
  %v2960 = load i64, ptr %slot16, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  store i32 0, ptr %p2961, align 4, !alias.scope !3, !noalias !4
  %v2962 = load i64, ptr %slot17, align 8
  %p2963 = inttoptr i64 %v2962 to ptr
  store i32 0, ptr %p2963, align 4, !alias.scope !3, !noalias !4
  %v2964 = load i64, ptr %slot18, align 8
  %p2965 = inttoptr i64 %v2964 to ptr
  store i32 0, ptr %p2965, align 4, !alias.scope !3, !noalias !4
  %v2966 = load i64, ptr %slot19, align 8
  %p2967 = inttoptr i64 %v2966 to ptr
  store i32 0, ptr %p2967, align 4, !alias.scope !3, !noalias !4
  %v2968 = load i64, ptr %slot20, align 8
  %p2969 = inttoptr i64 %v2968 to ptr
  store i32 0, ptr %p2969, align 4, !alias.scope !3, !noalias !4
  %v2970 = load i64, ptr %slot21, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  store i32 0, ptr %p2971, align 4, !alias.scope !3, !noalias !4
  %v2972 = load i64, ptr %slot22, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  store i32 0, ptr %p2973, align 4, !alias.scope !3, !noalias !4
  %v2974 = load i64, ptr %slot23, align 8
  %p2975 = inttoptr i64 %v2974 to ptr
  store i32 0, ptr %p2975, align 4, !alias.scope !3, !noalias !4
  %v2976 = load i64, ptr %slot24, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  store i32 0, ptr %p2977, align 4, !alias.scope !3, !noalias !4
  %v2978 = load i64, ptr %slot25, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  store i32 0, ptr %p2979, align 4, !alias.scope !3, !noalias !4
  %v2980 = load i64, ptr %slot26, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  store i32 0, ptr %p2981, align 4, !alias.scope !3, !noalias !4
  %v2982 = load i64, ptr %slot27, align 8
  %p2983 = inttoptr i64 %v2982 to ptr
  store i32 0, ptr %p2983, align 4, !alias.scope !3, !noalias !4
  %v2984 = load i64, ptr %slot28, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  store i32 0, ptr %p2985, align 4, !alias.scope !3, !noalias !4
  %v2986 = load i64, ptr %slot29, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  store i32 0, ptr %p2987, align 4, !alias.scope !3, !noalias !4
  %v2988 = load i64, ptr %slot30, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  store i32 0, ptr %p2989, align 4, !alias.scope !3, !noalias !4
  %v2990 = load i64, ptr %slot31, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  store i32 0, ptr %p2991, align 4, !alias.scope !3, !noalias !4
  %v2992 = load i64, ptr %slot32, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  store i32 0, ptr %p2993, align 4, !alias.scope !3, !noalias !4
  %v2994 = load i64, ptr %slot33, align 8
  %p2995 = inttoptr i64 %v2994 to ptr
  store i32 0, ptr %p2995, align 4, !alias.scope !3, !noalias !4
  %v2996 = load i64, ptr %slot34, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  store i32 0, ptr %p2997, align 4, !alias.scope !3, !noalias !4
  %v2998 = load i64, ptr %slot35, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  store i32 0, ptr %p2999, align 4, !alias.scope !3, !noalias !4
  %v3000 = load i64, ptr %slot36, align 8
  %p3001 = inttoptr i64 %v3000 to ptr
  store i32 0, ptr %p3001, align 4, !alias.scope !3, !noalias !4
  %v3002 = load i64, ptr %slot37, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  store i32 0, ptr %p3003, align 4, !alias.scope !3, !noalias !4
  %v3004 = load i64, ptr %slot38, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  store i32 0, ptr %p3005, align 4, !alias.scope !3, !noalias !4
  %v3006 = load i64, ptr %slot39, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  store i32 0, ptr %p3007, align 4, !alias.scope !3, !noalias !4
  %v3008 = load i64, ptr %slot40, align 8
  %p3009 = inttoptr i64 %v3008 to ptr
  store i32 0, ptr %p3009, align 4, !alias.scope !3, !noalias !4
  %v3010 = load i64, ptr %slot41, align 8
  %p3011 = inttoptr i64 %v3010 to ptr
  store i32 0, ptr %p3011, align 4, !alias.scope !3, !noalias !4
  %v3012 = load i64, ptr %slot42, align 8
  %p3013 = inttoptr i64 %v3012 to ptr
  store i32 0, ptr %p3013, align 4, !alias.scope !3, !noalias !4
  %v3014 = load i64, ptr %slot43, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  store i32 0, ptr %p3015, align 4, !alias.scope !3, !noalias !4
  %v3016 = load i64, ptr %slot44, align 8
  %p3017 = inttoptr i64 %v3016 to ptr
  store i32 0, ptr %p3017, align 4, !alias.scope !3, !noalias !4
  %v3018 = load i64, ptr %slot45, align 8
  %p3019 = inttoptr i64 %v3018 to ptr
  store i32 0, ptr %p3019, align 4, !alias.scope !3, !noalias !4
  %v3020 = load i64, ptr %slot46, align 8
  %p3021 = inttoptr i64 %v3020 to ptr
  store i32 0, ptr %p3021, align 4, !alias.scope !3, !noalias !4
  %v3022 = load i64, ptr %slot47, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  store i32 0, ptr %p3023, align 4, !alias.scope !3, !noalias !4
  %v3024 = load i64, ptr %slot48, align 8
  %p3025 = inttoptr i64 %v3024 to ptr
  store i32 0, ptr %p3025, align 4, !alias.scope !3, !noalias !4
  %v3026 = load i64, ptr %slot7, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  store i32 2, ptr %p3027, align 4, !alias.scope !3, !noalias !4
  %v3028 = load i64, ptr %slot9, align 8
  %p3029 = inttoptr i64 %v3028 to ptr
  store i32 2, ptr %p3029, align 4, !alias.scope !3, !noalias !4
  %v3030 = load i64, ptr %slot11, align 8
  %p3031 = inttoptr i64 %v3030 to ptr
  store i32 2, ptr %p3031, align 4, !alias.scope !3, !noalias !4
  %v3032 = load i64, ptr %slot13, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  store i32 2, ptr %p3033, align 4, !alias.scope !3, !noalias !4
  %v3034 = load i64, ptr %slot15, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  store i32 2, ptr %p3035, align 4, !alias.scope !3, !noalias !4
  %v3036 = load i64, ptr %slot17, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  store i32 2, ptr %p3037, align 4, !alias.scope !3, !noalias !4
  %v3038 = load i64, ptr %slot19, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  store i32 2, ptr %p3039, align 4, !alias.scope !3, !noalias !4
  %v3040 = load i64, ptr %slot21, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  store i32 2, ptr %p3041, align 4, !alias.scope !3, !noalias !4
  %v3042 = load i64, ptr %slot23, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  store i32 2, ptr %p3043, align 4, !alias.scope !3, !noalias !4
  %v3044 = load i64, ptr %slot25, align 8
  %p3045 = inttoptr i64 %v3044 to ptr
  store i32 2, ptr %p3045, align 4, !alias.scope !3, !noalias !4
  %v3046 = load i64, ptr %slot27, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  store i32 2, ptr %p3047, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v3048 = load i64, ptr %slot80, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  store i64 0, ptr %p3049, align 8, !alias.scope !3, !noalias !4
  %v3050 = load i64, ptr %slot80, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %ld3052 = load i64, ptr %p3051, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3052, ptr %slot112, align 8
  %v3053 = load i64, ptr %slot112, align 8
  %cmp3054 = icmp sge i64 %v3053, 0
  %cv3055 = zext i1 %cmp3054 to i64
  store i64 %cv3055, ptr %slot113, align 8
  %v3056 = load i64, ptr %slot113, align 8
  %cond3057 = icmp ne i64 %v3056, 0
  br i1 %cond3057, label %bb_success20, label %bb_failed20
bb_failed20:
  %v3058 = load i64, ptr %slot1, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p3059) nomerge, !dbg !114
  unreachable
bb_success20:
  %v3060 = load i64, ptr %slot110, align 8
  %p3061 = inttoptr i64 %v3060 to ptr
  %p3062 = inttoptr i64 ptrtoint (ptr @myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47 to i64) to ptr
  %v3063 = load i64, ptr %slot112, align 8
  %call3064 = call ptr @myl_native_list_new(ptr %p3061, ptr %p3062, i64 %v3063) nomerge, !dbg !114
  %calladdr3065 = ptrtoint ptr %call3064 to i64
  store i64 %calladdr3065, ptr %slot114, align 8
  %v3066 = load i64, ptr %slot114, align 8
  %cond3067 = icmp ne i64 %v3066, 0
  br i1 %cond3067, label %bb_success22, label %bb_failed22
bb_failed22:
  %v3068 = load i64, ptr %slot1, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3069) nomerge, !dbg !114
  unreachable
bb_success22:
  %v3070 = load i64, ptr %slot114, align 8
  %v3071 = load i64, ptr %slot80, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  store i64 %v3070, ptr %p3072, align 8, !alias.scope !3, !noalias !4
  %v3073 = load i64, ptr %slot80, align 8
  %p3074 = inttoptr i64 %v3073 to ptr
  %ld3075 = load i64, ptr %p3074, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3075, ptr %slot115, align 8
  %v3076 = load i64, ptr %slot115, align 8
  %v3077 = load i64, ptr %slot57, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  store i64 %v3076, ptr %p3078, align 8, !alias.scope !3, !noalias !4
  %v3079 = load i64, ptr %slot57, align 8
  store i64 %v3079, ptr %slot116, align 8
  %v3080 = load i64, ptr %slot65, align 8
  store i64 %v3080, ptr %slot117, align 8
  %v3081 = load i64, ptr %slot116, align 8
  %v3082 = load i64, ptr %slot117, align 8
  %p3083 = inttoptr i64 %v3081 to ptr
  %p3084 = inttoptr i64 %v3082 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3084, ptr %p3083, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3085 = load i64, ptr %slot47, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  store i32 2, ptr %p3086, align 4, !alias.scope !3, !noalias !4
  %v3087 = load i64, ptr %slot46, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  store i32 1, ptr %p3088, align 4, !alias.scope !3, !noalias !4
  %v3089 = load i64, ptr %slot49, align 8
  store i64 %v3089, ptr %slot118, align 8
  %v3090 = load i64, ptr %slot65, align 8
  store i64 %v3090, ptr %slot119, align 8
  %v3091 = load i64, ptr %slot119, align 8
  %v3092 = load i64, ptr %slot118, align 8
  %p3093 = inttoptr i64 %v3091 to ptr
  %p3094 = inttoptr i64 %v3092 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3094, ptr %p3093, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3095 = load i64, ptr %slot29, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  store i32 2, ptr %p3096, align 4, !alias.scope !3, !noalias !4
  %v3097 = load i64, ptr %slot47, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  %ld3099 = load i32, ptr %p3098, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3099, ptr %slot120, align 8
  %v3100 = load i32, ptr %slot120, align 8
  %v3101 = load i64, ptr %slot29, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  store i32 %v3100, ptr %p3102, align 4, !alias.scope !3, !noalias !4
  %v3103 = load i64, ptr %slot46, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  store i32 0, ptr %p3104, align 4, !alias.scope !3, !noalias !4
  %v3105 = load i64, ptr %slot28, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  store i32 1, ptr %p3106, align 4, !alias.scope !3, !noalias !4
  %v3107 = load i64, ptr %slot118, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  %ld3109 = load i64, ptr %p3108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3109, ptr %slot121, align 8
  %v3110 = load i64, ptr %slot121, align 8
  %v3111 = load i64, ptr %slot80, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  store i64 %v3110, ptr %p3112, align 8, !alias.scope !3, !noalias !4
  %v3113 = load i64, ptr %slot80, align 8
  %p3114 = inttoptr i64 %v3113 to ptr
  %ld3115 = load i64, ptr %p3114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3115, ptr %slot122, align 8
  %v3116 = load i64, ptr %slot122, align 8
  %v3117 = load i64, ptr %slot57, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  store i64 %v3116, ptr %p3118, align 8, !alias.scope !3, !noalias !4
  %v3119 = load i64, ptr %slot57, align 8
  store i64 %v3119, ptr %slot123, align 8
  %v3120 = load i64, ptr %slot28, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  %ld3122 = load i32, ptr %p3121, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3122, ptr %slot124, align 8
  %v3123 = load i64, ptr %slot29, align 8
  %p3124 = inttoptr i64 %v3123 to ptr
  %ld3125 = load i32, ptr %p3124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3125, ptr %slot125, align 8
  %v3126 = load i32, ptr %slot125, align 8
  %op3127 = and i32 %v3126, 24
  store i32 %op3127, ptr %slot125, align 8
  %v3128 = load i32, ptr %slot125, align 8
  %cmp3129 = icmp eq i32 %v3128, 0
  %cv3130 = zext i1 %cmp3129 to i32
  store i32 %cv3130, ptr %slot126, align 8
  %v3131 = load i32, ptr %slot124, align 8
  %v3132 = load i32, ptr %slot126, align 8
  %op3133 = and i32 %v3131, %v3132
  store i32 %op3133, ptr %slot127, align 8
  %v3134 = load i32, ptr %slot127, align 8
  %cv3135 = zext i32 %v3134 to i64
  %cond3136 = icmp ne i64 %cv3135, 0
  br i1 %cond3136, label %bb_rcprivateown45, label %bb_rcprivateloan45
bb_rcprivateown45:
  %v3137 = load i64, ptr %slot65, align 8
  store i64 %v3137, ptr %slot128, align 8
  %v3138 = load i64, ptr %slot111, align 8
  store i64 %v3138, ptr %slot129, align 8
  %v3139 = load i64, ptr %slot123, align 8
  %v3140 = load i64, ptr %slot128, align 8
  %op3141 = sub i64 %v3139, %v3140
  store i64 %op3141, ptr %slot130, align 8
  %v3142 = load i64, ptr %slot128, align 8
  %v3143 = load i64, ptr %slot123, align 8
  %op3144 = sub i64 %v3142, %v3143
  store i64 %op3144, ptr %slot131, align 8
  %v3145 = load i64, ptr %slot130, align 8
  %cmp3146 = icmp ult i64 %v3145, 8
  %cv3147 = zext i1 %cmp3146 to i32
  store i32 %cv3147, ptr %slot132, align 8
  %v3148 = load i64, ptr %slot131, align 8
  %cmp3149 = icmp ult i64 %v3148, 8
  %cv3150 = zext i1 %cmp3149 to i32
  store i32 %cv3150, ptr %slot133, align 8
  %v3151 = load i32, ptr %slot132, align 8
  %v3152 = load i32, ptr %slot133, align 8
  %op3153 = or i32 %v3151, %v3152
  store i32 %op3153, ptr %slot134, align 8
  %v3154 = load i32, ptr %slot134, align 8
  %cv3155 = zext i32 %v3154 to i64
  %cond3156 = icmp ne i64 %cv3155, 0
  br i1 %cond3156, label %bb_rcmoveslow48, label %bb_rcmovecheck48
bb_rcmovecheck48:
  %v3157 = load i64, ptr %slot123, align 8
  %p3159 = inttoptr i64 %v3157 to ptr
  %gep3160 = getelementptr i8, ptr %p3159, i64 0
  %op3158 = ptrtoint ptr %gep3160 to i64
  store i64 %op3158, ptr %slot135, align 8
  %v3161 = load i64, ptr %slot135, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  %ld3163 = load i64, ptr %p3162, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3163, ptr %slot136, align 8
  %v3164 = load i64, ptr %slot136, align 8
  %cmp3165 = icmp ne i64 %v3164, 0
  %cv3166 = zext i1 %cmp3165 to i32
  store i32 %cv3166, ptr %slot137, align 8
  %v3167 = load i32, ptr %slot137, align 8
  %cv3168 = zext i32 %v3167 to i64
  %cond3169 = icmp ne i64 %cv3168, 0
  br i1 %cond3169, label %bb_rcmoveheader56, label %bb_rcmovenext56
bb_rcmoveheader56:
  %v3170 = load i64, ptr %slot136, align 8
  %op3171 = sub i64 %v3170, 16
  store i64 %op3171, ptr %slot138, align 8
  %v3172 = load i64, ptr %slot136, align 8
  %p3173 = inttoptr i64 %v3172 to ptr
  %rgep3174 = getelementptr i8, ptr %p3173, i64 -16
  %ld3175 = load i64, ptr %rgep3174, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3175, ptr %slot139, align 8
  %v3176 = load i64, ptr %slot139, align 8
  %op3177 = and i64 %v3176, 5764607523034234881
  store i64 %op3177, ptr %slot140, align 8
  %v3178 = load i64, ptr %slot140, align 8
  %cmp3179 = icmp ne i64 %v3178, 0
  %cv3180 = zext i1 %cmp3179 to i32
  store i32 %cv3180, ptr %slot141, align 8
  %v3181 = load i32, ptr %slot141, align 8
  %cv3182 = zext i32 %v3181 to i64
  %cond3183 = icmp ne i64 %cv3182, 0
  br i1 %cond3183, label %bb_rcmoveslow48, label %bb_rcmovenext56
bb_rcmovenext56:
  %v3184 = load i64, ptr %slot123, align 8
  %v3185 = load i64, ptr %slot128, align 8
  %p3186 = inttoptr i64 %v3184 to ptr
  %p3187 = inttoptr i64 %v3185 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3187, ptr %p3186, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3188 = load i64, ptr %slot123, align 8
  %p3189 = inttoptr i64 %v3188 to ptr
  store i64 0, ptr %p3189, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved48
bb_rcmoveslow48:
  %v3190 = load i64, ptr %slot110, align 8
  %v3191 = load i64, ptr %slot128, align 8
  %v3192 = load i64, ptr %slot123, align 8
  %v3193 = load i64, ptr %slot129, align 8
  %cv3194 = trunc i64 %v3193 to i32
  %call3195 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64 %v3190, i64 %v3191, i64 %v3192, i32 %cv3194) nomerge, !dbg !116
  store i32 %call3195, ptr %slot142, align 8
  %v3196 = load i32, ptr %slot142, align 8
  %cv3197 = zext i32 %v3196 to i64
  %cond3198 = icmp ne i64 %cv3197, 0
  br i1 %cond3198, label %bb_rcsuccess63, label %bb_rcfailure63
bb_rcfailure63:
  %v3199 = load i64, ptr %slot110, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  %call3201 = call i32 @myl_rc_take_failure(ptr %p3200) nomerge, !dbg !116
  store i32 %call3201, ptr %slot143, align 8
  %v3202 = load i64, ptr %slot1, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  %v3204 = load i32, ptr %slot143, align 8
  %call3205 = call i32 @myl_qbe_rc_status(ptr %p3203, i32 %v3204) nomerge, !dbg !116
  store i32 %call3205, ptr %slot144, align 8
  br label %bb_failure
bb_rcsuccess63:
  br label %bb_rcmoved48
bb_rcmoved48:
  %v3206 = load i64, ptr %slot28, align 8
  %p3207 = inttoptr i64 %v3206 to ptr
  store i32 0, ptr %p3207, align 4, !alias.scope !3, !noalias !4
  %v3208 = load i64, ptr %slot47, align 8
  %p3209 = inttoptr i64 %v3208 to ptr
  store i32 2, ptr %p3209, align 4, !alias.scope !3, !noalias !4
  %v3210 = load i64, ptr %slot46, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  store i32 1, ptr %p3211, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared45
bb_rcprivateloan45:
  %v3212 = load i64, ptr %slot28, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %ld3214 = load i32, ptr %p3213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3214, ptr %slot145, align 8
  %v3215 = load i64, ptr %slot29, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  %ld3217 = load i32, ptr %p3216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3217, ptr %slot146, align 8
  %v3218 = load i32, ptr %slot146, align 8
  %cmp3219 = icmp eq i32 %v3218, 16
  %cv3220 = zext i1 %cmp3219 to i32
  store i32 %cv3220, ptr %slot147, align 8
  %v3221 = load i32, ptr %slot147, align 8
  %v3222 = load i32, ptr %slot145, align 8
  %op3223 = and i32 %v3221, %v3222
  store i32 %op3223, ptr %slot147, align 8
  %v3224 = load i32, ptr %slot147, align 8
  %cv3225 = zext i32 %v3224 to i64
  %cond3226 = icmp ne i64 %cv3225, 0
  br i1 %cond3226, label %bb_rcprivatemove45, label %bb_rcprivatenew45
bb_rcprivatemove45:
  %v3227 = load i64, ptr %slot65, align 8
  store i64 %v3227, ptr %slot148, align 8
  %v3228 = load i64, ptr %slot123, align 8
  %v3229 = load i64, ptr %slot148, align 8
  %p3230 = inttoptr i64 %v3228 to ptr
  %p3231 = inttoptr i64 %v3229 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3231, ptr %p3230, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3232 = load i64, ptr %slot123, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i64 0, ptr %p3233, align 8, !alias.scope !3, !noalias !4
  %v3234 = load i64, ptr %slot47, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  store i32 2, ptr %p3235, align 4, !alias.scope !3, !noalias !4
  %v3236 = load i64, ptr %slot47, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  store i32 16, ptr %p3237, align 4, !alias.scope !3, !noalias !4
  %v3238 = load i64, ptr %slot46, align 8
  %p3239 = inttoptr i64 %v3238 to ptr
  store i32 1, ptr %p3239, align 4, !alias.scope !3, !noalias !4
  %v3240 = load i64, ptr %slot28, align 8
  %p3241 = inttoptr i64 %v3240 to ptr
  store i32 0, ptr %p3241, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared45
bb_rcprivatenew45:
  %v3242 = load i64, ptr %slot65, align 8
  store i64 %v3242, ptr %slot149, align 8
  %v3243 = load i64, ptr %slot123, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  %ld3245 = load i64, ptr %p3244, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3245, ptr %slot150, align 8
  %v3246 = load i64, ptr %slot150, align 8
  %cmp3247 = icmp ne i64 %v3246, 0
  %cv3248 = zext i1 %cmp3247 to i32
  store i32 %cv3248, ptr %slot151, align 8
  %v3249 = load i32, ptr %slot151, align 8
  %cv3250 = zext i32 %v3249 to i64
  %cond3251 = icmp ne i64 %cv3250, 0
  br i1 %cond3251, label %bb_rcgnn81, label %bb_rcgstore81
bb_rcgnn81:
  %v3252 = load i64, ptr %slot150, align 8
  %op3253 = sub i64 %v3252, 16
  store i64 %op3253, ptr %slot152, align 8
  %v3254 = load i64, ptr %slot150, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  %rgep3256 = getelementptr i8, ptr %p3255, i64 -16
  %ld3257 = load i64, ptr %rgep3256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3257, ptr %slot153, align 8
  %v3258 = load i64, ptr %slot153, align 8
  %op3259 = and i64 %v3258, 4611686018427387906
  store i64 %op3259, ptr %slot154, align 8
  %v3260 = load i64, ptr %slot154, align 8
  %cmp3261 = icmp ne i64 %v3260, 0
  %cv3262 = zext i1 %cmp3261 to i32
  store i32 %cv3262, ptr %slot155, align 8
  %v3263 = load i32, ptr %slot155, align 8
  %cv3264 = zext i32 %v3263 to i64
  %cond3265 = icmp ne i64 %cv3264, 0
  br i1 %cond3265, label %bb_rcgstore81, label %bb_rcginc81
bb_rcginc81:
  %v3266 = load i64, ptr %slot150, align 8
  %op3267 = sub i64 %v3266, 24
  store i64 %op3267, ptr %slot156, align 8
  %v3268 = load i64, ptr %slot150, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %rgep3270 = getelementptr i8, ptr %p3269, i64 -24
  %ld3271 = load i64, ptr %rgep3270, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3271, ptr %slot157, align 8
  %v3272 = load i64, ptr %slot157, align 8
  %op3273 = add i64 %v3272, 1
  store i64 %op3273, ptr %slot158, align 8
  %v3274 = load i64, ptr %slot158, align 8
  %cmp3275 = icmp eq i64 %v3274, 0
  %cv3276 = zext i1 %cmp3275 to i32
  store i32 %cv3276, ptr %slot159, align 8
  %v3277 = load i32, ptr %slot159, align 8
  %cv3278 = zext i32 %v3277 to i64
  %cond3279 = icmp ne i64 %cv3278, 0
  br i1 %cond3279, label %bb_rcglimit81, label %bb_rcgcapacity81
bb_rcglimit81:
  %v3280 = load i64, ptr %slot1, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  %call3282 = call i32 @myl_qbe_rc_status(ptr %p3281, i32 2) nomerge, !dbg !116
  store i32 %call3282, ptr %slot160, align 8
  br label %bb_failure
bb_rcgcapacity81:
  %v3283 = load i64, ptr %slot158, align 8
  %v3284 = load i64, ptr %slot150, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  %rgep3286 = getelementptr i8, ptr %p3285, i64 -24
  store i64 %v3283, ptr %rgep3286, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore81
bb_rcgstore81:
  %v3287 = load i64, ptr %slot150, align 8
  %v3288 = load i64, ptr %slot149, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  store i64 %v3287, ptr %p3289, align 8, !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot47, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  store i32 2, ptr %p3291, align 4, !alias.scope !3, !noalias !4
  %v3292 = load i64, ptr %slot47, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  store i32 16, ptr %p3293, align 4, !alias.scope !3, !noalias !4
  %v3294 = load i64, ptr %slot46, align 8
  %p3295 = inttoptr i64 %v3294 to ptr
  store i32 1, ptr %p3295, align 4, !alias.scope !3, !noalias !4
  %v3296 = load i64, ptr %slot28, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  %ld3298 = load i32, ptr %p3297, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3298, ptr %slot161, align 8
  %v3299 = load i32, ptr %slot161, align 8
  %cv3300 = zext i32 %v3299 to i64
  %cond3301 = icmp ne i64 %cv3300, 0
  br i1 %cond3301, label %bb_rcslotdrop97, label %bb_rcslotdone97
bb_rcslotdrop97:
  %v3302 = load i64, ptr %slot28, align 8
  %p3303 = inttoptr i64 %v3302 to ptr
  store i32 0, ptr %p3303, align 4, !alias.scope !3, !noalias !4
  %v3304 = load i64, ptr %slot49, align 8
  store i64 %v3304, ptr %slot162, align 8
  %v3305 = load i64, ptr %slot29, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  %ld3307 = load i32, ptr %p3306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3307, ptr %slot163, align 8
  %v3308 = load i32, ptr %slot163, align 8
  %op3309 = and i32 %v3308, 28
  store i32 %op3309, ptr %slot164, align 8
  %v3310 = load i32, ptr %slot164, align 8
  %cv3311 = zext i32 %v3310 to i64
  %cond3312 = icmp ne i64 %cv3311, 0
  br i1 %cond3312, label %bb_rcslotrole97, label %bb_rcslotowner97
bb_rcslotrole97:
  %v3313 = load i64, ptr %slot110, align 8
  store i64 %v3313, ptr %slot165, align 8
  %v3314 = load i64, ptr %slot162, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  %ld3316 = load i64, ptr %p3315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3316, ptr %slot166, align 8
  %v3317 = load i64, ptr %slot166, align 8
  %cmp3318 = icmp ne i64 %v3317, 0
  %cv3319 = zext i1 %cmp3318 to i32
  store i32 %cv3319, ptr %slot167, align 8
  %v3320 = load i32, ptr %slot167, align 8
  %cv3321 = zext i32 %v3320 to i64
  %cond3322 = icmp ne i64 %cv3321, 0
  br i1 %cond3322, label %bb_rcgnn113, label %bb_rcgdone113
bb_rcgnn113:
  %v3323 = load i64, ptr %slot166, align 8
  %op3324 = sub i64 %v3323, 16
  store i64 %op3324, ptr %slot168, align 8
  %v3325 = load i64, ptr %slot166, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  %rgep3327 = getelementptr i8, ptr %p3326, i64 -16
  %ld3328 = load i64, ptr %rgep3327, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3328, ptr %slot169, align 8
  %v3329 = load i64, ptr %slot169, align 8
  %op3330 = and i64 %v3329, 4611686018427387906
  store i64 %op3330, ptr %slot170, align 8
  %v3331 = load i64, ptr %slot170, align 8
  %cmp3332 = icmp ne i64 %v3331, 0
  %cv3333 = zext i1 %cmp3332 to i32
  store i32 %cv3333, ptr %slot171, align 8
  %v3334 = load i32, ptr %slot171, align 8
  %cv3335 = zext i32 %v3334 to i64
  %cond3336 = icmp ne i64 %cv3335, 0
  br i1 %cond3336, label %bb_rcgclear113, label %bb_rcgcounted113
bb_rcgcounted113:
  %v3337 = load i64, ptr %slot166, align 8
  %op3338 = sub i64 %v3337, 24
  store i64 %op3338, ptr %slot172, align 8
  %v3339 = load i64, ptr %slot166, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  %rgep3341 = getelementptr i8, ptr %p3340, i64 -24
  %ld3342 = load i64, ptr %rgep3341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3342, ptr %slot173, align 8
  %v3343 = load i64, ptr %slot173, align 8
  %op3344 = sub i64 %v3343, 1
  store i64 %op3344, ptr %slot174, align 8
  %v3345 = load i64, ptr %slot174, align 8
  %cmp3346 = icmp eq i64 %v3345, 0
  %cv3347 = zext i1 %cmp3346 to i32
  store i32 %cv3347, ptr %slot175, align 8
  %v3348 = load i32, ptr %slot175, align 8
  %cv3349 = zext i32 %v3348 to i64
  %cond3350 = icmp ne i64 %cv3349, 0
  br i1 %cond3350, label %bb_rcglast113, label %bb_rcgdec113
bb_rcglast113:
  %v3351 = load i64, ptr %slot166, align 8
  %op3352 = sub i64 %v3351, 32
  store i64 %op3352, ptr %slot176, align 8
  %v3353 = load i64, ptr %slot166, align 8
  %p3354 = inttoptr i64 %v3353 to ptr
  %rgep3355 = getelementptr i8, ptr %p3354, i64 -32
  %ld3356 = load i64, ptr %rgep3355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3356, ptr %slot177, align 8
  %v3357 = load i64, ptr %slot177, align 8
  %cmp3358 = icmp ne i64 %v3357, 0
  %cv3359 = zext i1 %cmp3358 to i32
  store i32 %cv3359, ptr %slot178, align 8
  %v3360 = load i32, ptr %slot178, align 8
  %cv3361 = zext i32 %v3360 to i64
  %cond3362 = icmp ne i64 %cv3361, 0
  br i1 %cond3362, label %bb_rcgdec113, label %bb_rcgslow113
bb_rcgslow113:
  %v3363 = load i64, ptr %slot165, align 8
  %v3364 = load i64, ptr %slot162, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3363, i64 %v3364) nomerge, !dbg !116
  br label %bb_rcgdone113
bb_rcgdec113:
  %v3365 = load i64, ptr %slot174, align 8
  %v3366 = load i64, ptr %slot166, align 8
  %p3367 = inttoptr i64 %v3366 to ptr
  %rgep3368 = getelementptr i8, ptr %p3367, i64 -24
  store i64 %v3365, ptr %rgep3368, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear113
bb_rcgclear113:
  %v3369 = load i64, ptr %slot162, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  store i64 0, ptr %p3370, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone113
bb_rcgdone113:
  br label %bb_rcslotdone97
bb_rcslotowner97:
  %v3371 = load i64, ptr %slot110, align 8
  store i64 %v3371, ptr %slot179, align 8
  %v3372 = load i64, ptr %slot162, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  %ld3374 = load i64, ptr %p3373, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3374, ptr %slot180, align 8
  %v3375 = load i64, ptr %slot180, align 8
  %cmp3376 = icmp ne i64 %v3375, 0
  %cv3377 = zext i1 %cmp3376 to i32
  store i32 %cv3377, ptr %slot181, align 8
  %v3378 = load i32, ptr %slot181, align 8
  %cv3379 = zext i32 %v3378 to i64
  %cond3380 = icmp ne i64 %cv3379, 0
  br i1 %cond3380, label %bb_rcgnn128, label %bb_rcgdone128
bb_rcgnn128:
  %v3381 = load i64, ptr %slot180, align 8
  %op3382 = sub i64 %v3381, 16
  store i64 %op3382, ptr %slot182, align 8
  %v3383 = load i64, ptr %slot180, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  %rgep3385 = getelementptr i8, ptr %p3384, i64 -16
  %ld3386 = load i64, ptr %rgep3385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3386, ptr %slot183, align 8
  %v3387 = load i64, ptr %slot183, align 8
  %op3388 = and i64 %v3387, 4611686018427387906
  store i64 %op3388, ptr %slot184, align 8
  %v3389 = load i64, ptr %slot184, align 8
  %cmp3390 = icmp ne i64 %v3389, 0
  %cv3391 = zext i1 %cmp3390 to i32
  store i32 %cv3391, ptr %slot185, align 8
  %v3392 = load i32, ptr %slot185, align 8
  %cv3393 = zext i32 %v3392 to i64
  %cond3394 = icmp ne i64 %cv3393, 0
  br i1 %cond3394, label %bb_rcgclear128, label %bb_rcgcounted128
bb_rcgcounted128:
  %v3395 = load i64, ptr %slot180, align 8
  %op3396 = sub i64 %v3395, 32
  store i64 %op3396, ptr %slot186, align 8
  %v3397 = load i64, ptr %slot180, align 8
  %p3398 = inttoptr i64 %v3397 to ptr
  %rgep3399 = getelementptr i8, ptr %p3398, i64 -32
  %ld3400 = load i64, ptr %rgep3399, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3400, ptr %slot187, align 8
  %v3401 = load i64, ptr %slot187, align 8
  %op3402 = sub i64 %v3401, 1
  store i64 %op3402, ptr %slot188, align 8
  %v3403 = load i64, ptr %slot188, align 8
  %cmp3404 = icmp eq i64 %v3403, 0
  %cv3405 = zext i1 %cmp3404 to i32
  store i32 %cv3405, ptr %slot189, align 8
  %v3406 = load i32, ptr %slot189, align 8
  %cv3407 = zext i32 %v3406 to i64
  %cond3408 = icmp ne i64 %cv3407, 0
  br i1 %cond3408, label %bb_rcglast128, label %bb_rcgdec128
bb_rcglast128:
  %v3409 = load i64, ptr %slot180, align 8
  %op3410 = sub i64 %v3409, 24
  store i64 %op3410, ptr %slot190, align 8
  %v3411 = load i64, ptr %slot180, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  %rgep3413 = getelementptr i8, ptr %p3412, i64 -24
  %ld3414 = load i64, ptr %rgep3413, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3414, ptr %slot191, align 8
  %v3415 = load i64, ptr %slot191, align 8
  %cmp3416 = icmp ne i64 %v3415, 0
  %cv3417 = zext i1 %cmp3416 to i32
  store i32 %cv3417, ptr %slot192, align 8
  %v3418 = load i32, ptr %slot192, align 8
  %cv3419 = zext i32 %v3418 to i64
  %cond3420 = icmp ne i64 %cv3419, 0
  br i1 %cond3420, label %bb_rcgdec128, label %bb_rcgslow128
bb_rcgslow128:
  %v3421 = load i64, ptr %slot179, align 8
  %v3422 = load i64, ptr %slot162, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3421, i64 %v3422) nomerge, !dbg !116
  br label %bb_rcgdone128
bb_rcgdec128:
  %v3423 = load i64, ptr %slot188, align 8
  %v3424 = load i64, ptr %slot180, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  %rgep3426 = getelementptr i8, ptr %p3425, i64 -32
  store i64 %v3423, ptr %rgep3426, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear128
bb_rcgclear128:
  %v3427 = load i64, ptr %slot162, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  store i64 0, ptr %p3428, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone128
bb_rcgdone128:
  br label %bb_rcslotdone97
bb_rcslotdone97:
  br label %bb_rcprivateprepared45
bb_rcprivateprepared45:
  %v3429 = load i64, ptr %slot6, align 8
  %p3430 = inttoptr i64 %v3429 to ptr
  %ld3431 = load i32, ptr %p3430, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3431, ptr %slot193, align 8
  %v3432 = load i32, ptr %slot193, align 8
  %cv3433 = zext i32 %v3432 to i64
  %cond3434 = icmp ne i64 %cv3433, 0
  br i1 %cond3434, label %bb_rcslotdrop135, label %bb_rcslotdone135
bb_rcslotdrop135:
  %v3435 = load i64, ptr %slot6, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  store i32 0, ptr %p3436, align 4, !alias.scope !3, !noalias !4
  %v3437 = load i64, ptr %slot68, align 8
  store i64 %v3437, ptr %slot194, align 8
  %v3438 = load i64, ptr %slot7, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  %ld3440 = load i32, ptr %p3439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3440, ptr %slot195, align 8
  %v3441 = load i32, ptr %slot195, align 8
  %op3442 = and i32 %v3441, 28
  store i32 %op3442, ptr %slot196, align 8
  %v3443 = load i32, ptr %slot196, align 8
  %cv3444 = zext i32 %v3443 to i64
  %cond3445 = icmp ne i64 %cv3444, 0
  br i1 %cond3445, label %bb_rcslotrole135, label %bb_rcslotowner135
bb_rcslotrole135:
  %v3446 = load i64, ptr %slot110, align 8
  store i64 %v3446, ptr %slot197, align 8
  %v3447 = load i64, ptr %slot194, align 8
  %p3448 = inttoptr i64 %v3447 to ptr
  %ld3449 = load i64, ptr %p3448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3449, ptr %slot198, align 8
  %v3450 = load i64, ptr %slot198, align 8
  %cmp3451 = icmp ne i64 %v3450, 0
  %cv3452 = zext i1 %cmp3451 to i32
  store i32 %cv3452, ptr %slot199, align 8
  %v3453 = load i32, ptr %slot199, align 8
  %cv3454 = zext i32 %v3453 to i64
  %cond3455 = icmp ne i64 %cv3454, 0
  br i1 %cond3455, label %bb_rcgnn151, label %bb_rcgdone151
bb_rcgnn151:
  %v3456 = load i64, ptr %slot198, align 8
  %op3457 = sub i64 %v3456, 16
  store i64 %op3457, ptr %slot200, align 8
  %v3458 = load i64, ptr %slot198, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  %rgep3460 = getelementptr i8, ptr %p3459, i64 -16
  %ld3461 = load i64, ptr %rgep3460, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3461, ptr %slot201, align 8
  %v3462 = load i64, ptr %slot201, align 8
  %op3463 = and i64 %v3462, 4611686018427387906
  store i64 %op3463, ptr %slot202, align 8
  %v3464 = load i64, ptr %slot202, align 8
  %cmp3465 = icmp ne i64 %v3464, 0
  %cv3466 = zext i1 %cmp3465 to i32
  store i32 %cv3466, ptr %slot203, align 8
  %v3467 = load i32, ptr %slot203, align 8
  %cv3468 = zext i32 %v3467 to i64
  %cond3469 = icmp ne i64 %cv3468, 0
  br i1 %cond3469, label %bb_rcgclear151, label %bb_rcgcounted151
bb_rcgcounted151:
  %v3470 = load i64, ptr %slot198, align 8
  %op3471 = sub i64 %v3470, 24
  store i64 %op3471, ptr %slot204, align 8
  %v3472 = load i64, ptr %slot198, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %rgep3474 = getelementptr i8, ptr %p3473, i64 -24
  %ld3475 = load i64, ptr %rgep3474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3475, ptr %slot205, align 8
  %v3476 = load i64, ptr %slot205, align 8
  %op3477 = sub i64 %v3476, 1
  store i64 %op3477, ptr %slot206, align 8
  %v3478 = load i64, ptr %slot206, align 8
  %cmp3479 = icmp eq i64 %v3478, 0
  %cv3480 = zext i1 %cmp3479 to i32
  store i32 %cv3480, ptr %slot207, align 8
  %v3481 = load i32, ptr %slot207, align 8
  %cv3482 = zext i32 %v3481 to i64
  %cond3483 = icmp ne i64 %cv3482, 0
  br i1 %cond3483, label %bb_rcglast151, label %bb_rcgdec151
bb_rcglast151:
  %v3484 = load i64, ptr %slot198, align 8
  %op3485 = sub i64 %v3484, 32
  store i64 %op3485, ptr %slot208, align 8
  %v3486 = load i64, ptr %slot198, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  %rgep3488 = getelementptr i8, ptr %p3487, i64 -32
  %ld3489 = load i64, ptr %rgep3488, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3489, ptr %slot209, align 8
  %v3490 = load i64, ptr %slot209, align 8
  %cmp3491 = icmp ne i64 %v3490, 0
  %cv3492 = zext i1 %cmp3491 to i32
  store i32 %cv3492, ptr %slot210, align 8
  %v3493 = load i32, ptr %slot210, align 8
  %cv3494 = zext i32 %v3493 to i64
  %cond3495 = icmp ne i64 %cv3494, 0
  br i1 %cond3495, label %bb_rcgdec151, label %bb_rcgslow151
bb_rcgslow151:
  %v3496 = load i64, ptr %slot197, align 8
  %v3497 = load i64, ptr %slot194, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3496, i64 %v3497) nomerge, !dbg !116
  br label %bb_rcgdone151
bb_rcgdec151:
  %v3498 = load i64, ptr %slot206, align 8
  %v3499 = load i64, ptr %slot198, align 8
  %p3500 = inttoptr i64 %v3499 to ptr
  %rgep3501 = getelementptr i8, ptr %p3500, i64 -24
  store i64 %v3498, ptr %rgep3501, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear151
bb_rcgclear151:
  %v3502 = load i64, ptr %slot194, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  store i64 0, ptr %p3503, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone151
bb_rcgdone151:
  br label %bb_rcslotdone135
bb_rcslotowner135:
  %v3504 = load i64, ptr %slot110, align 8
  store i64 %v3504, ptr %slot211, align 8
  %v3505 = load i64, ptr %slot194, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  %ld3507 = load i64, ptr %p3506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3507, ptr %slot212, align 8
  %v3508 = load i64, ptr %slot212, align 8
  %cmp3509 = icmp ne i64 %v3508, 0
  %cv3510 = zext i1 %cmp3509 to i32
  store i32 %cv3510, ptr %slot213, align 8
  %v3511 = load i32, ptr %slot213, align 8
  %cv3512 = zext i32 %v3511 to i64
  %cond3513 = icmp ne i64 %cv3512, 0
  br i1 %cond3513, label %bb_rcgnn166, label %bb_rcgdone166
bb_rcgnn166:
  %v3514 = load i64, ptr %slot212, align 8
  %op3515 = sub i64 %v3514, 16
  store i64 %op3515, ptr %slot214, align 8
  %v3516 = load i64, ptr %slot212, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  %rgep3518 = getelementptr i8, ptr %p3517, i64 -16
  %ld3519 = load i64, ptr %rgep3518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3519, ptr %slot215, align 8
  %v3520 = load i64, ptr %slot215, align 8
  %op3521 = and i64 %v3520, 4611686018427387906
  store i64 %op3521, ptr %slot216, align 8
  %v3522 = load i64, ptr %slot216, align 8
  %cmp3523 = icmp ne i64 %v3522, 0
  %cv3524 = zext i1 %cmp3523 to i32
  store i32 %cv3524, ptr %slot217, align 8
  %v3525 = load i32, ptr %slot217, align 8
  %cv3526 = zext i32 %v3525 to i64
  %cond3527 = icmp ne i64 %cv3526, 0
  br i1 %cond3527, label %bb_rcgclear166, label %bb_rcgcounted166
bb_rcgcounted166:
  %v3528 = load i64, ptr %slot212, align 8
  %op3529 = sub i64 %v3528, 32
  store i64 %op3529, ptr %slot218, align 8
  %v3530 = load i64, ptr %slot212, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  %rgep3532 = getelementptr i8, ptr %p3531, i64 -32
  %ld3533 = load i64, ptr %rgep3532, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3533, ptr %slot219, align 8
  %v3534 = load i64, ptr %slot219, align 8
  %op3535 = sub i64 %v3534, 1
  store i64 %op3535, ptr %slot220, align 8
  %v3536 = load i64, ptr %slot220, align 8
  %cmp3537 = icmp eq i64 %v3536, 0
  %cv3538 = zext i1 %cmp3537 to i32
  store i32 %cv3538, ptr %slot221, align 8
  %v3539 = load i32, ptr %slot221, align 8
  %cv3540 = zext i32 %v3539 to i64
  %cond3541 = icmp ne i64 %cv3540, 0
  br i1 %cond3541, label %bb_rcglast166, label %bb_rcgdec166
bb_rcglast166:
  %v3542 = load i64, ptr %slot212, align 8
  %op3543 = sub i64 %v3542, 24
  store i64 %op3543, ptr %slot222, align 8
  %v3544 = load i64, ptr %slot212, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  %rgep3546 = getelementptr i8, ptr %p3545, i64 -24
  %ld3547 = load i64, ptr %rgep3546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3547, ptr %slot223, align 8
  %v3548 = load i64, ptr %slot223, align 8
  %cmp3549 = icmp ne i64 %v3548, 0
  %cv3550 = zext i1 %cmp3549 to i32
  store i32 %cv3550, ptr %slot224, align 8
  %v3551 = load i32, ptr %slot224, align 8
  %cv3552 = zext i32 %v3551 to i64
  %cond3553 = icmp ne i64 %cv3552, 0
  br i1 %cond3553, label %bb_rcgdec166, label %bb_rcgslow166
bb_rcgslow166:
  %v3554 = load i64, ptr %slot211, align 8
  %v3555 = load i64, ptr %slot194, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3554, i64 %v3555) nomerge, !dbg !116
  br label %bb_rcgdone166
bb_rcgdec166:
  %v3556 = load i64, ptr %slot220, align 8
  %v3557 = load i64, ptr %slot212, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  %rgep3559 = getelementptr i8, ptr %p3558, i64 -32
  store i64 %v3556, ptr %rgep3559, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear166
bb_rcgclear166:
  %v3560 = load i64, ptr %slot194, align 8
  %p3561 = inttoptr i64 %v3560 to ptr
  store i64 0, ptr %p3561, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone166
bb_rcgdone166:
  br label %bb_rcslotdone135
bb_rcslotdone135:
  %v3562 = load i64, ptr %slot68, align 8
  store i64 %v3562, ptr %slot225, align 8
  %v3563 = load i64, ptr %slot65, align 8
  store i64 %v3563, ptr %slot226, align 8
  %v3564 = load i64, ptr %slot226, align 8
  %v3565 = load i64, ptr %slot225, align 8
  %p3566 = inttoptr i64 %v3564 to ptr
  %p3567 = inttoptr i64 %v3565 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3567, ptr %p3566, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3568 = load i64, ptr %slot46, align 8
  %p3569 = inttoptr i64 %v3568 to ptr
  store i32 0, ptr %p3569, align 4, !alias.scope !3, !noalias !4
  %v3570 = load i64, ptr %slot7, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  store i32 2, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  %v3572 = load i64, ptr %slot47, align 8
  %p3573 = inttoptr i64 %v3572 to ptr
  %ld3574 = load i32, ptr %p3573, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3574, ptr %slot227, align 8
  %v3575 = load i32, ptr %slot227, align 8
  %v3576 = load i64, ptr %slot7, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  store i32 %v3575, ptr %p3577, align 4, !alias.scope !3, !noalias !4
  %v3578 = load i64, ptr %slot6, align 8
  %p3579 = inttoptr i64 %v3578 to ptr
  store i32 1, ptr %p3579, align 4, !alias.scope !3, !noalias !4
  %v3580 = load i64, ptr %slot68, align 8
  %p3581 = inttoptr i64 %v3580 to ptr
  %ld3582 = load i64, ptr %p3581, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3582, ptr %slot228, align 8
  %v3583 = load i64, ptr %slot228, align 8
  %v3584 = load i64, ptr %slot80, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  store i64 %v3583, ptr %p3585, align 8, !alias.scope !3, !noalias !4
  %v3586 = load i64, ptr %slot80, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  %ld3588 = load i64, ptr %p3587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3588, ptr %slot229, align 8
  %v3589 = load i64, ptr %slot229, align 8
  %v3590 = load i64, ptr %slot57, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  store i64 %v3589, ptr %p3591, align 8, !alias.scope !3, !noalias !4
  %v3592 = load i64, ptr %slot57, align 8
  store i64 %v3592, ptr %slot230, align 8
  %v3593 = load i64, ptr %slot28, align 8
  %p3594 = inttoptr i64 %v3593 to ptr
  %ld3595 = load i32, ptr %p3594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3595, ptr %slot231, align 8
  %v3596 = load i64, ptr %slot29, align 8
  %p3597 = inttoptr i64 %v3596 to ptr
  %ld3598 = load i32, ptr %p3597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3598, ptr %slot232, align 8
  %v3599 = load i32, ptr %slot232, align 8
  %op3600 = and i32 %v3599, 24
  store i32 %op3600, ptr %slot232, align 8
  %v3601 = load i32, ptr %slot232, align 8
  %cmp3602 = icmp eq i32 %v3601, 0
  %cv3603 = zext i1 %cmp3602 to i32
  store i32 %cv3603, ptr %slot233, align 8
  %v3604 = load i32, ptr %slot231, align 8
  %v3605 = load i32, ptr %slot233, align 8
  %op3606 = and i32 %v3604, %v3605
  store i32 %op3606, ptr %slot234, align 8
  %v3607 = load i32, ptr %slot234, align 8
  %cv3608 = zext i32 %v3607 to i64
  %cond3609 = icmp ne i64 %cv3608, 0
  br i1 %cond3609, label %bb_rctake180, label %bb_rccopy180
bb_rctake180:
  %v3610 = load i64, ptr %slot65, align 8
  store i64 %v3610, ptr %slot235, align 8
  %v3611 = load i64, ptr %slot111, align 8
  store i64 %v3611, ptr %slot236, align 8
  %v3612 = load i64, ptr %slot230, align 8
  %v3613 = load i64, ptr %slot235, align 8
  %op3614 = sub i64 %v3612, %v3613
  store i64 %op3614, ptr %slot237, align 8
  %v3615 = load i64, ptr %slot235, align 8
  %v3616 = load i64, ptr %slot230, align 8
  %op3617 = sub i64 %v3615, %v3616
  store i64 %op3617, ptr %slot238, align 8
  %v3618 = load i64, ptr %slot237, align 8
  %cmp3619 = icmp ult i64 %v3618, 8
  %cv3620 = zext i1 %cmp3619 to i32
  store i32 %cv3620, ptr %slot239, align 8
  %v3621 = load i64, ptr %slot238, align 8
  %cmp3622 = icmp ult i64 %v3621, 8
  %cv3623 = zext i1 %cmp3622 to i32
  store i32 %cv3623, ptr %slot240, align 8
  %v3624 = load i32, ptr %slot239, align 8
  %v3625 = load i32, ptr %slot240, align 8
  %op3626 = or i32 %v3624, %v3625
  store i32 %op3626, ptr %slot241, align 8
  %v3627 = load i32, ptr %slot241, align 8
  %cv3628 = zext i32 %v3627 to i64
  %cond3629 = icmp ne i64 %cv3628, 0
  br i1 %cond3629, label %bb_rcmoveslow189, label %bb_rcmovecheck189
bb_rcmovecheck189:
  %v3630 = load i64, ptr %slot230, align 8
  %p3632 = inttoptr i64 %v3630 to ptr
  %gep3633 = getelementptr i8, ptr %p3632, i64 0
  %op3631 = ptrtoint ptr %gep3633 to i64
  store i64 %op3631, ptr %slot242, align 8
  %v3634 = load i64, ptr %slot242, align 8
  %p3635 = inttoptr i64 %v3634 to ptr
  %ld3636 = load i64, ptr %p3635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3636, ptr %slot243, align 8
  %v3637 = load i64, ptr %slot243, align 8
  %cmp3638 = icmp ne i64 %v3637, 0
  %cv3639 = zext i1 %cmp3638 to i32
  store i32 %cv3639, ptr %slot244, align 8
  %v3640 = load i32, ptr %slot244, align 8
  %cv3641 = zext i32 %v3640 to i64
  %cond3642 = icmp ne i64 %cv3641, 0
  br i1 %cond3642, label %bb_rcmoveheader197, label %bb_rcmovenext197
bb_rcmoveheader197:
  %v3643 = load i64, ptr %slot243, align 8
  %op3644 = sub i64 %v3643, 16
  store i64 %op3644, ptr %slot245, align 8
  %v3645 = load i64, ptr %slot243, align 8
  %p3646 = inttoptr i64 %v3645 to ptr
  %rgep3647 = getelementptr i8, ptr %p3646, i64 -16
  %ld3648 = load i64, ptr %rgep3647, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3648, ptr %slot246, align 8
  %v3649 = load i64, ptr %slot246, align 8
  %op3650 = and i64 %v3649, 5764607523034234881
  store i64 %op3650, ptr %slot247, align 8
  %v3651 = load i64, ptr %slot247, align 8
  %cmp3652 = icmp ne i64 %v3651, 0
  %cv3653 = zext i1 %cmp3652 to i32
  store i32 %cv3653, ptr %slot248, align 8
  %v3654 = load i32, ptr %slot248, align 8
  %cv3655 = zext i32 %v3654 to i64
  %cond3656 = icmp ne i64 %cv3655, 0
  br i1 %cond3656, label %bb_rcmoveslow189, label %bb_rcmovenext197
bb_rcmovenext197:
  %v3657 = load i64, ptr %slot230, align 8
  %v3658 = load i64, ptr %slot235, align 8
  %p3659 = inttoptr i64 %v3657 to ptr
  %p3660 = inttoptr i64 %v3658 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3660, ptr %p3659, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3661 = load i64, ptr %slot230, align 8
  %p3662 = inttoptr i64 %v3661 to ptr
  store i64 0, ptr %p3662, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved189
bb_rcmoveslow189:
  %v3663 = load i64, ptr %slot110, align 8
  %v3664 = load i64, ptr %slot235, align 8
  %v3665 = load i64, ptr %slot230, align 8
  %v3666 = load i64, ptr %slot236, align 8
  %cv3667 = trunc i64 %v3666 to i32
  %call3668 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64 %v3663, i64 %v3664, i64 %v3665, i32 %cv3667) nomerge, !dbg !118
  store i32 %call3668, ptr %slot249, align 8
  %v3669 = load i32, ptr %slot249, align 8
  %cv3670 = zext i32 %v3669 to i64
  %cond3671 = icmp ne i64 %cv3670, 0
  br i1 %cond3671, label %bb_rcsuccess204, label %bb_rcfailure204
bb_rcfailure204:
  %v3672 = load i64, ptr %slot110, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  %call3674 = call i32 @myl_rc_take_failure(ptr %p3673) nomerge, !dbg !118
  store i32 %call3674, ptr %slot250, align 8
  %v3675 = load i64, ptr %slot1, align 8
  %p3676 = inttoptr i64 %v3675 to ptr
  %v3677 = load i32, ptr %slot250, align 8
  %call3678 = call i32 @myl_qbe_rc_status(ptr %p3676, i32 %v3677) nomerge, !dbg !118
  store i32 %call3678, ptr %slot251, align 8
  br label %bb_failure
bb_rcsuccess204:
  br label %bb_rcmoved189
bb_rcmoved189:
  %v3679 = load i64, ptr %slot28, align 8
  %p3680 = inttoptr i64 %v3679 to ptr
  store i32 0, ptr %p3680, align 4, !alias.scope !3, !noalias !4
  %v3681 = load i64, ptr %slot47, align 8
  %p3682 = inttoptr i64 %v3681 to ptr
  store i32 2, ptr %p3682, align 4, !alias.scope !3, !noalias !4
  %v3683 = load i64, ptr %slot46, align 8
  %p3684 = inttoptr i64 %v3683 to ptr
  store i32 1, ptr %p3684, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared180
bb_rccopy180:
  %v3685 = load i64, ptr %slot65, align 8
  store i64 %v3685, ptr %slot252, align 8
  %v3686 = load i64, ptr %slot111, align 8
  store i64 %v3686, ptr %slot253, align 8
  %v3687 = load i64, ptr %slot230, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %ld3689 = load i64, ptr %p3688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3689, ptr %slot254, align 8
  %v3690 = load i64, ptr %slot254, align 8
  %cmp3691 = icmp ne i64 %v3690, 0
  %cv3692 = zext i1 %cmp3691 to i32
  store i32 %cv3692, ptr %slot255, align 8
  %v3693 = load i32, ptr %slot255, align 8
  %cv3694 = zext i32 %v3693 to i64
  %cond3695 = icmp ne i64 %cv3694, 0
  br i1 %cond3695, label %bb_rcgnn213, label %bb_rcgplain213
bb_rcgnn213:
  %v3696 = load i64, ptr %slot254, align 8
  %op3697 = sub i64 %v3696, 16
  store i64 %op3697, ptr %slot256, align 8
  %v3698 = load i64, ptr %slot254, align 8
  %p3699 = inttoptr i64 %v3698 to ptr
  %rgep3700 = getelementptr i8, ptr %p3699, i64 -16
  %ld3701 = load i64, ptr %rgep3700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3701, ptr %slot257, align 8
  %v3702 = load i64, ptr %slot257, align 8
  %op3703 = and i64 %v3702, 4611686018427387906
  store i64 %op3703, ptr %slot258, align 8
  %v3704 = load i64, ptr %slot258, align 8
  %cmp3705 = icmp ne i64 %v3704, 0
  %cv3706 = zext i1 %cmp3705 to i32
  store i32 %cv3706, ptr %slot259, align 8
  %v3707 = load i32, ptr %slot259, align 8
  %cv3708 = zext i32 %v3707 to i64
  %cond3709 = icmp ne i64 %cv3708, 0
  br i1 %cond3709, label %bb_rcgspecial213, label %bb_rcginc213
bb_rcginc213:
  %v3710 = load i64, ptr %slot254, align 8
  %op3711 = sub i64 %v3710, 32
  store i64 %op3711, ptr %slot260, align 8
  %v3712 = load i64, ptr %slot254, align 8
  %p3713 = inttoptr i64 %v3712 to ptr
  %rgep3714 = getelementptr i8, ptr %p3713, i64 -32
  %ld3715 = load i64, ptr %rgep3714, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3715, ptr %slot261, align 8
  %v3716 = load i64, ptr %slot261, align 8
  %op3717 = add i64 %v3716, 1
  store i64 %op3717, ptr %slot262, align 8
  %v3718 = load i64, ptr %slot262, align 8
  %cmp3719 = icmp eq i64 %v3718, 0
  %cv3720 = zext i1 %cmp3719 to i32
  store i32 %cv3720, ptr %slot263, align 8
  %v3721 = load i32, ptr %slot263, align 8
  %cv3722 = zext i32 %v3721 to i64
  %cond3723 = icmp ne i64 %cv3722, 0
  br i1 %cond3723, label %bb_rcglimit213, label %bb_rcgcapacity213
bb_rcglimit213:
  %v3724 = load i64, ptr %slot1, align 8
  %p3725 = inttoptr i64 %v3724 to ptr
  %call3726 = call i32 @myl_qbe_rc_status(ptr %p3725, i32 2) nomerge, !dbg !118
  store i32 %call3726, ptr %slot264, align 8
  br label %bb_failure
bb_rcgcapacity213:
  %v3727 = load i64, ptr %slot262, align 8
  %v3728 = load i64, ptr %slot254, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  %rgep3730 = getelementptr i8, ptr %p3729, i64 -32
  store i64 %v3727, ptr %rgep3730, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain213
bb_rcgspecial213:
  %v3731 = load i64, ptr %slot257, align 8
  %op3732 = and i64 %v3731, 4611686018427387904
  store i64 %op3732, ptr %slot265, align 8
  %v3733 = load i64, ptr %slot265, align 8
  %cmp3734 = icmp ne i64 %v3733, 0
  %cv3735 = zext i1 %cmp3734 to i32
  store i32 %cv3735, ptr %slot266, align 8
  %v3736 = load i32, ptr %slot266, align 8
  %cv3737 = zext i32 %v3736 to i64
  %cond3738 = icmp ne i64 %cv3737, 0
  br i1 %cond3738, label %bb_rcgslow213, label %bb_rcgplain213
bb_rcgslow213:
  %v3739 = load i64, ptr %slot110, align 8
  %v3740 = load i64, ptr %slot252, align 8
  %v3741 = load i64, ptr %slot230, align 8
  %v3742 = load i64, ptr %slot253, align 8
  %cv3743 = trunc i64 %v3742 to i32
  %call3744 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_retain(i64 %v3739, i64 %v3740, i64 %v3741, i32 %cv3743) nomerge, !dbg !118
  store i32 %call3744, ptr %slot267, align 8
  %v3745 = load i32, ptr %slot267, align 8
  %cv3746 = zext i32 %v3745 to i64
  %cond3747 = icmp ne i64 %cv3746, 0
  br i1 %cond3747, label %bb_rcsuccess227, label %bb_rcfailure227
bb_rcfailure227:
  %v3748 = load i64, ptr %slot110, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  %call3750 = call i32 @myl_rc_take_failure(ptr %p3749) nomerge, !dbg !118
  store i32 %call3750, ptr %slot268, align 8
  %v3751 = load i64, ptr %slot1, align 8
  %p3752 = inttoptr i64 %v3751 to ptr
  %v3753 = load i32, ptr %slot268, align 8
  %call3754 = call i32 @myl_qbe_rc_status(ptr %p3752, i32 %v3753) nomerge, !dbg !118
  store i32 %call3754, ptr %slot269, align 8
  br label %bb_failure
bb_rcsuccess227:
  br label %bb_rcgdone213
bb_rcgplain213:
  %v3755 = load i64, ptr %slot254, align 8
  %v3756 = load i64, ptr %slot252, align 8
  %p3757 = inttoptr i64 %v3756 to ptr
  store i64 %v3755, ptr %p3757, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone213
bb_rcgdone213:
  %v3758 = load i64, ptr %slot47, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  store i32 2, ptr %p3759, align 4, !alias.scope !3, !noalias !4
  %v3760 = load i64, ptr %slot46, align 8
  %p3761 = inttoptr i64 %v3760 to ptr
  store i32 1, ptr %p3761, align 4, !alias.scope !3, !noalias !4
  %v3762 = load i64, ptr %slot28, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %ld3764 = load i32, ptr %p3763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3764, ptr %slot270, align 8
  %v3765 = load i32, ptr %slot270, align 8
  %cv3766 = zext i32 %v3765 to i64
  %cond3767 = icmp ne i64 %cv3766, 0
  br i1 %cond3767, label %bb_rcslotdrop234, label %bb_rcslotdone234
bb_rcslotdrop234:
  %v3768 = load i64, ptr %slot28, align 8
  %p3769 = inttoptr i64 %v3768 to ptr
  store i32 0, ptr %p3769, align 4, !alias.scope !3, !noalias !4
  %v3770 = load i64, ptr %slot49, align 8
  store i64 %v3770, ptr %slot271, align 8
  %v3771 = load i64, ptr %slot29, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  %ld3773 = load i32, ptr %p3772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3773, ptr %slot272, align 8
  %v3774 = load i32, ptr %slot272, align 8
  %op3775 = and i32 %v3774, 28
  store i32 %op3775, ptr %slot273, align 8
  %v3776 = load i32, ptr %slot273, align 8
  %cv3777 = zext i32 %v3776 to i64
  %cond3778 = icmp ne i64 %cv3777, 0
  br i1 %cond3778, label %bb_rcslotrole234, label %bb_rcslotowner234
bb_rcslotrole234:
  %v3779 = load i64, ptr %slot110, align 8
  store i64 %v3779, ptr %slot274, align 8
  %v3780 = load i64, ptr %slot271, align 8
  %p3781 = inttoptr i64 %v3780 to ptr
  %ld3782 = load i64, ptr %p3781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3782, ptr %slot275, align 8
  %v3783 = load i64, ptr %slot275, align 8
  %cmp3784 = icmp ne i64 %v3783, 0
  %cv3785 = zext i1 %cmp3784 to i32
  store i32 %cv3785, ptr %slot276, align 8
  %v3786 = load i32, ptr %slot276, align 8
  %cv3787 = zext i32 %v3786 to i64
  %cond3788 = icmp ne i64 %cv3787, 0
  br i1 %cond3788, label %bb_rcgnn250, label %bb_rcgdone250
bb_rcgnn250:
  %v3789 = load i64, ptr %slot275, align 8
  %op3790 = sub i64 %v3789, 16
  store i64 %op3790, ptr %slot277, align 8
  %v3791 = load i64, ptr %slot275, align 8
  %p3792 = inttoptr i64 %v3791 to ptr
  %rgep3793 = getelementptr i8, ptr %p3792, i64 -16
  %ld3794 = load i64, ptr %rgep3793, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3794, ptr %slot278, align 8
  %v3795 = load i64, ptr %slot278, align 8
  %op3796 = and i64 %v3795, 4611686018427387906
  store i64 %op3796, ptr %slot279, align 8
  %v3797 = load i64, ptr %slot279, align 8
  %cmp3798 = icmp ne i64 %v3797, 0
  %cv3799 = zext i1 %cmp3798 to i32
  store i32 %cv3799, ptr %slot280, align 8
  %v3800 = load i32, ptr %slot280, align 8
  %cv3801 = zext i32 %v3800 to i64
  %cond3802 = icmp ne i64 %cv3801, 0
  br i1 %cond3802, label %bb_rcgclear250, label %bb_rcgcounted250
bb_rcgcounted250:
  %v3803 = load i64, ptr %slot275, align 8
  %op3804 = sub i64 %v3803, 24
  store i64 %op3804, ptr %slot281, align 8
  %v3805 = load i64, ptr %slot275, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %rgep3807 = getelementptr i8, ptr %p3806, i64 -24
  %ld3808 = load i64, ptr %rgep3807, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3808, ptr %slot282, align 8
  %v3809 = load i64, ptr %slot282, align 8
  %op3810 = sub i64 %v3809, 1
  store i64 %op3810, ptr %slot283, align 8
  %v3811 = load i64, ptr %slot283, align 8
  %cmp3812 = icmp eq i64 %v3811, 0
  %cv3813 = zext i1 %cmp3812 to i32
  store i32 %cv3813, ptr %slot284, align 8
  %v3814 = load i32, ptr %slot284, align 8
  %cv3815 = zext i32 %v3814 to i64
  %cond3816 = icmp ne i64 %cv3815, 0
  br i1 %cond3816, label %bb_rcglast250, label %bb_rcgdec250
bb_rcglast250:
  %v3817 = load i64, ptr %slot275, align 8
  %op3818 = sub i64 %v3817, 32
  store i64 %op3818, ptr %slot285, align 8
  %v3819 = load i64, ptr %slot275, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %rgep3821 = getelementptr i8, ptr %p3820, i64 -32
  %ld3822 = load i64, ptr %rgep3821, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3822, ptr %slot286, align 8
  %v3823 = load i64, ptr %slot286, align 8
  %cmp3824 = icmp ne i64 %v3823, 0
  %cv3825 = zext i1 %cmp3824 to i32
  store i32 %cv3825, ptr %slot287, align 8
  %v3826 = load i32, ptr %slot287, align 8
  %cv3827 = zext i32 %v3826 to i64
  %cond3828 = icmp ne i64 %cv3827, 0
  br i1 %cond3828, label %bb_rcgdec250, label %bb_rcgslow250
bb_rcgslow250:
  %v3829 = load i64, ptr %slot274, align 8
  %v3830 = load i64, ptr %slot271, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3829, i64 %v3830) nomerge, !dbg !118
  br label %bb_rcgdone250
bb_rcgdec250:
  %v3831 = load i64, ptr %slot283, align 8
  %v3832 = load i64, ptr %slot275, align 8
  %p3833 = inttoptr i64 %v3832 to ptr
  %rgep3834 = getelementptr i8, ptr %p3833, i64 -24
  store i64 %v3831, ptr %rgep3834, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear250
bb_rcgclear250:
  %v3835 = load i64, ptr %slot271, align 8
  %p3836 = inttoptr i64 %v3835 to ptr
  store i64 0, ptr %p3836, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone250
bb_rcgdone250:
  br label %bb_rcslotdone234
bb_rcslotowner234:
  %v3837 = load i64, ptr %slot110, align 8
  store i64 %v3837, ptr %slot288, align 8
  %v3838 = load i64, ptr %slot271, align 8
  %p3839 = inttoptr i64 %v3838 to ptr
  %ld3840 = load i64, ptr %p3839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3840, ptr %slot289, align 8
  %v3841 = load i64, ptr %slot289, align 8
  %cmp3842 = icmp ne i64 %v3841, 0
  %cv3843 = zext i1 %cmp3842 to i32
  store i32 %cv3843, ptr %slot290, align 8
  %v3844 = load i32, ptr %slot290, align 8
  %cv3845 = zext i32 %v3844 to i64
  %cond3846 = icmp ne i64 %cv3845, 0
  br i1 %cond3846, label %bb_rcgnn265, label %bb_rcgdone265
bb_rcgnn265:
  %v3847 = load i64, ptr %slot289, align 8
  %op3848 = sub i64 %v3847, 16
  store i64 %op3848, ptr %slot291, align 8
  %v3849 = load i64, ptr %slot289, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  %rgep3851 = getelementptr i8, ptr %p3850, i64 -16
  %ld3852 = load i64, ptr %rgep3851, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3852, ptr %slot292, align 8
  %v3853 = load i64, ptr %slot292, align 8
  %op3854 = and i64 %v3853, 4611686018427387906
  store i64 %op3854, ptr %slot293, align 8
  %v3855 = load i64, ptr %slot293, align 8
  %cmp3856 = icmp ne i64 %v3855, 0
  %cv3857 = zext i1 %cmp3856 to i32
  store i32 %cv3857, ptr %slot294, align 8
  %v3858 = load i32, ptr %slot294, align 8
  %cv3859 = zext i32 %v3858 to i64
  %cond3860 = icmp ne i64 %cv3859, 0
  br i1 %cond3860, label %bb_rcgclear265, label %bb_rcgcounted265
bb_rcgcounted265:
  %v3861 = load i64, ptr %slot289, align 8
  %op3862 = sub i64 %v3861, 32
  store i64 %op3862, ptr %slot295, align 8
  %v3863 = load i64, ptr %slot289, align 8
  %p3864 = inttoptr i64 %v3863 to ptr
  %rgep3865 = getelementptr i8, ptr %p3864, i64 -32
  %ld3866 = load i64, ptr %rgep3865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3866, ptr %slot296, align 8
  %v3867 = load i64, ptr %slot296, align 8
  %op3868 = sub i64 %v3867, 1
  store i64 %op3868, ptr %slot297, align 8
  %v3869 = load i64, ptr %slot297, align 8
  %cmp3870 = icmp eq i64 %v3869, 0
  %cv3871 = zext i1 %cmp3870 to i32
  store i32 %cv3871, ptr %slot298, align 8
  %v3872 = load i32, ptr %slot298, align 8
  %cv3873 = zext i32 %v3872 to i64
  %cond3874 = icmp ne i64 %cv3873, 0
  br i1 %cond3874, label %bb_rcglast265, label %bb_rcgdec265
bb_rcglast265:
  %v3875 = load i64, ptr %slot289, align 8
  %op3876 = sub i64 %v3875, 24
  store i64 %op3876, ptr %slot299, align 8
  %v3877 = load i64, ptr %slot289, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  %rgep3879 = getelementptr i8, ptr %p3878, i64 -24
  %ld3880 = load i64, ptr %rgep3879, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3880, ptr %slot300, align 8
  %v3881 = load i64, ptr %slot300, align 8
  %cmp3882 = icmp ne i64 %v3881, 0
  %cv3883 = zext i1 %cmp3882 to i32
  store i32 %cv3883, ptr %slot301, align 8
  %v3884 = load i32, ptr %slot301, align 8
  %cv3885 = zext i32 %v3884 to i64
  %cond3886 = icmp ne i64 %cv3885, 0
  br i1 %cond3886, label %bb_rcgdec265, label %bb_rcgslow265
bb_rcgslow265:
  %v3887 = load i64, ptr %slot288, align 8
  %v3888 = load i64, ptr %slot271, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3887, i64 %v3888) nomerge, !dbg !118
  br label %bb_rcgdone265
bb_rcgdec265:
  %v3889 = load i64, ptr %slot297, align 8
  %v3890 = load i64, ptr %slot289, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  %rgep3892 = getelementptr i8, ptr %p3891, i64 -32
  store i64 %v3889, ptr %rgep3892, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear265
bb_rcgclear265:
  %v3893 = load i64, ptr %slot271, align 8
  %p3894 = inttoptr i64 %v3893 to ptr
  store i64 0, ptr %p3894, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone265
bb_rcgdone265:
  br label %bb_rcslotdone234
bb_rcslotdone234:
  br label %bb_rcprepared180
bb_rcprepared180:
  %v3895 = load i64, ptr %slot8, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  %ld3897 = load i32, ptr %p3896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3897, ptr %slot302, align 8
  %v3898 = load i32, ptr %slot302, align 8
  %cv3899 = zext i32 %v3898 to i64
  %cond3900 = icmp ne i64 %cv3899, 0
  br i1 %cond3900, label %bb_rcslotdrop272, label %bb_rcslotdone272
bb_rcslotdrop272:
  %v3901 = load i64, ptr %slot8, align 8
  %p3902 = inttoptr i64 %v3901 to ptr
  store i32 0, ptr %p3902, align 4, !alias.scope !3, !noalias !4
  %v3903 = load i64, ptr %slot69, align 8
  store i64 %v3903, ptr %slot303, align 8
  %v3904 = load i64, ptr %slot9, align 8
  %p3905 = inttoptr i64 %v3904 to ptr
  %ld3906 = load i32, ptr %p3905, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3906, ptr %slot304, align 8
  %v3907 = load i32, ptr %slot304, align 8
  %op3908 = and i32 %v3907, 28
  store i32 %op3908, ptr %slot305, align 8
  %v3909 = load i32, ptr %slot305, align 8
  %cv3910 = zext i32 %v3909 to i64
  %cond3911 = icmp ne i64 %cv3910, 0
  br i1 %cond3911, label %bb_rcslotrole272, label %bb_rcslotowner272
bb_rcslotrole272:
  %v3912 = load i64, ptr %slot110, align 8
  store i64 %v3912, ptr %slot306, align 8
  %v3913 = load i64, ptr %slot303, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  %ld3915 = load i64, ptr %p3914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3915, ptr %slot307, align 8
  %v3916 = load i64, ptr %slot307, align 8
  %cmp3917 = icmp ne i64 %v3916, 0
  %cv3918 = zext i1 %cmp3917 to i32
  store i32 %cv3918, ptr %slot308, align 8
  %v3919 = load i32, ptr %slot308, align 8
  %cv3920 = zext i32 %v3919 to i64
  %cond3921 = icmp ne i64 %cv3920, 0
  br i1 %cond3921, label %bb_rcgnn288, label %bb_rcgdone288
bb_rcgnn288:
  %v3922 = load i64, ptr %slot307, align 8
  %op3923 = sub i64 %v3922, 16
  store i64 %op3923, ptr %slot309, align 8
  %v3924 = load i64, ptr %slot307, align 8
  %p3925 = inttoptr i64 %v3924 to ptr
  %rgep3926 = getelementptr i8, ptr %p3925, i64 -16
  %ld3927 = load i64, ptr %rgep3926, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3927, ptr %slot310, align 8
  %v3928 = load i64, ptr %slot310, align 8
  %op3929 = and i64 %v3928, 4611686018427387906
  store i64 %op3929, ptr %slot311, align 8
  %v3930 = load i64, ptr %slot311, align 8
  %cmp3931 = icmp ne i64 %v3930, 0
  %cv3932 = zext i1 %cmp3931 to i32
  store i32 %cv3932, ptr %slot312, align 8
  %v3933 = load i32, ptr %slot312, align 8
  %cv3934 = zext i32 %v3933 to i64
  %cond3935 = icmp ne i64 %cv3934, 0
  br i1 %cond3935, label %bb_rcgclear288, label %bb_rcgcounted288
bb_rcgcounted288:
  %v3936 = load i64, ptr %slot307, align 8
  %op3937 = sub i64 %v3936, 24
  store i64 %op3937, ptr %slot313, align 8
  %v3938 = load i64, ptr %slot307, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  %rgep3940 = getelementptr i8, ptr %p3939, i64 -24
  %ld3941 = load i64, ptr %rgep3940, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3941, ptr %slot314, align 8
  %v3942 = load i64, ptr %slot314, align 8
  %op3943 = sub i64 %v3942, 1
  store i64 %op3943, ptr %slot315, align 8
  %v3944 = load i64, ptr %slot315, align 8
  %cmp3945 = icmp eq i64 %v3944, 0
  %cv3946 = zext i1 %cmp3945 to i32
  store i32 %cv3946, ptr %slot316, align 8
  %v3947 = load i32, ptr %slot316, align 8
  %cv3948 = zext i32 %v3947 to i64
  %cond3949 = icmp ne i64 %cv3948, 0
  br i1 %cond3949, label %bb_rcglast288, label %bb_rcgdec288
bb_rcglast288:
  %v3950 = load i64, ptr %slot307, align 8
  %op3951 = sub i64 %v3950, 32
  store i64 %op3951, ptr %slot317, align 8
  %v3952 = load i64, ptr %slot307, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  %rgep3954 = getelementptr i8, ptr %p3953, i64 -32
  %ld3955 = load i64, ptr %rgep3954, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3955, ptr %slot318, align 8
  %v3956 = load i64, ptr %slot318, align 8
  %cmp3957 = icmp ne i64 %v3956, 0
  %cv3958 = zext i1 %cmp3957 to i32
  store i32 %cv3958, ptr %slot319, align 8
  %v3959 = load i32, ptr %slot319, align 8
  %cv3960 = zext i32 %v3959 to i64
  %cond3961 = icmp ne i64 %cv3960, 0
  br i1 %cond3961, label %bb_rcgdec288, label %bb_rcgslow288
bb_rcgslow288:
  %v3962 = load i64, ptr %slot306, align 8
  %v3963 = load i64, ptr %slot303, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3962, i64 %v3963) nomerge, !dbg !118
  br label %bb_rcgdone288
bb_rcgdec288:
  %v3964 = load i64, ptr %slot315, align 8
  %v3965 = load i64, ptr %slot307, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  %rgep3967 = getelementptr i8, ptr %p3966, i64 -24
  store i64 %v3964, ptr %rgep3967, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear288
bb_rcgclear288:
  %v3968 = load i64, ptr %slot303, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  store i64 0, ptr %p3969, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone288
bb_rcgdone288:
  br label %bb_rcslotdone272
bb_rcslotowner272:
  %v3970 = load i64, ptr %slot110, align 8
  store i64 %v3970, ptr %slot320, align 8
  %v3971 = load i64, ptr %slot303, align 8
  %p3972 = inttoptr i64 %v3971 to ptr
  %ld3973 = load i64, ptr %p3972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3973, ptr %slot321, align 8
  %v3974 = load i64, ptr %slot321, align 8
  %cmp3975 = icmp ne i64 %v3974, 0
  %cv3976 = zext i1 %cmp3975 to i32
  store i32 %cv3976, ptr %slot322, align 8
  %v3977 = load i32, ptr %slot322, align 8
  %cv3978 = zext i32 %v3977 to i64
  %cond3979 = icmp ne i64 %cv3978, 0
  br i1 %cond3979, label %bb_rcgnn303, label %bb_rcgdone303
bb_rcgnn303:
  %v3980 = load i64, ptr %slot321, align 8
  %op3981 = sub i64 %v3980, 16
  store i64 %op3981, ptr %slot323, align 8
  %v3982 = load i64, ptr %slot321, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  %rgep3984 = getelementptr i8, ptr %p3983, i64 -16
  %ld3985 = load i64, ptr %rgep3984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3985, ptr %slot324, align 8
  %v3986 = load i64, ptr %slot324, align 8
  %op3987 = and i64 %v3986, 4611686018427387906
  store i64 %op3987, ptr %slot325, align 8
  %v3988 = load i64, ptr %slot325, align 8
  %cmp3989 = icmp ne i64 %v3988, 0
  %cv3990 = zext i1 %cmp3989 to i32
  store i32 %cv3990, ptr %slot326, align 8
  %v3991 = load i32, ptr %slot326, align 8
  %cv3992 = zext i32 %v3991 to i64
  %cond3993 = icmp ne i64 %cv3992, 0
  br i1 %cond3993, label %bb_rcgclear303, label %bb_rcgcounted303
bb_rcgcounted303:
  %v3994 = load i64, ptr %slot321, align 8
  %op3995 = sub i64 %v3994, 32
  store i64 %op3995, ptr %slot327, align 8
  %v3996 = load i64, ptr %slot321, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  %rgep3998 = getelementptr i8, ptr %p3997, i64 -32
  %ld3999 = load i64, ptr %rgep3998, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3999, ptr %slot328, align 8
  %v4000 = load i64, ptr %slot328, align 8
  %op4001 = sub i64 %v4000, 1
  store i64 %op4001, ptr %slot329, align 8
  %v4002 = load i64, ptr %slot329, align 8
  %cmp4003 = icmp eq i64 %v4002, 0
  %cv4004 = zext i1 %cmp4003 to i32
  store i32 %cv4004, ptr %slot330, align 8
  %v4005 = load i32, ptr %slot330, align 8
  %cv4006 = zext i32 %v4005 to i64
  %cond4007 = icmp ne i64 %cv4006, 0
  br i1 %cond4007, label %bb_rcglast303, label %bb_rcgdec303
bb_rcglast303:
  %v4008 = load i64, ptr %slot321, align 8
  %op4009 = sub i64 %v4008, 24
  store i64 %op4009, ptr %slot331, align 8
  %v4010 = load i64, ptr %slot321, align 8
  %p4011 = inttoptr i64 %v4010 to ptr
  %rgep4012 = getelementptr i8, ptr %p4011, i64 -24
  %ld4013 = load i64, ptr %rgep4012, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4013, ptr %slot332, align 8
  %v4014 = load i64, ptr %slot332, align 8
  %cmp4015 = icmp ne i64 %v4014, 0
  %cv4016 = zext i1 %cmp4015 to i32
  store i32 %cv4016, ptr %slot333, align 8
  %v4017 = load i32, ptr %slot333, align 8
  %cv4018 = zext i32 %v4017 to i64
  %cond4019 = icmp ne i64 %cv4018, 0
  br i1 %cond4019, label %bb_rcgdec303, label %bb_rcgslow303
bb_rcgslow303:
  %v4020 = load i64, ptr %slot320, align 8
  %v4021 = load i64, ptr %slot303, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v4020, i64 %v4021) nomerge, !dbg !118
  br label %bb_rcgdone303
bb_rcgdec303:
  %v4022 = load i64, ptr %slot329, align 8
  %v4023 = load i64, ptr %slot321, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  %rgep4025 = getelementptr i8, ptr %p4024, i64 -32
  store i64 %v4022, ptr %rgep4025, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear303
bb_rcgclear303:
  %v4026 = load i64, ptr %slot303, align 8
  %p4027 = inttoptr i64 %v4026 to ptr
  store i64 0, ptr %p4027, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone303
bb_rcgdone303:
  br label %bb_rcslotdone272
bb_rcslotdone272:
  %v4028 = load i64, ptr %slot69, align 8
  store i64 %v4028, ptr %slot334, align 8
  %v4029 = load i64, ptr %slot65, align 8
  store i64 %v4029, ptr %slot335, align 8
  %v4030 = load i64, ptr %slot335, align 8
  %v4031 = load i64, ptr %slot334, align 8
  %p4032 = inttoptr i64 %v4030 to ptr
  %p4033 = inttoptr i64 %v4031 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4033, ptr %p4032, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4034 = load i64, ptr %slot46, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  store i32 0, ptr %p4035, align 4, !alias.scope !3, !noalias !4
  %v4036 = load i64, ptr %slot9, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  store i32 2, ptr %p4037, align 4, !alias.scope !3, !noalias !4
  %v4038 = load i64, ptr %slot47, align 8
  %p4039 = inttoptr i64 %v4038 to ptr
  %ld4040 = load i32, ptr %p4039, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4040, ptr %slot336, align 8
  %v4041 = load i32, ptr %slot336, align 8
  %v4042 = load i64, ptr %slot9, align 8
  %p4043 = inttoptr i64 %v4042 to ptr
  store i32 %v4041, ptr %p4043, align 4, !alias.scope !3, !noalias !4
  %v4044 = load i64, ptr %slot8, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  store i32 1, ptr %p4045, align 4, !alias.scope !3, !noalias !4
  %v4046 = load i64, ptr %slot6, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  %ld4048 = load i32, ptr %p4047, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4048, ptr %slot337, align 8
  %v4049 = load i32, ptr %slot337, align 8
  %cv4050 = zext i32 %v4049 to i64
  %cond4051 = icmp ne i64 %cv4050, 0
  br i1 %cond4051, label %bb_rcslotdrop316, label %bb_rcslotdone316
bb_rcslotdrop316:
  %v4052 = load i64, ptr %slot6, align 8
  %p4053 = inttoptr i64 %v4052 to ptr
  store i32 0, ptr %p4053, align 4, !alias.scope !3, !noalias !4
  %v4054 = load i64, ptr %slot68, align 8
  store i64 %v4054, ptr %slot338, align 8
  %v4055 = load i64, ptr %slot7, align 8
  %p4056 = inttoptr i64 %v4055 to ptr
  %ld4057 = load i32, ptr %p4056, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4057, ptr %slot339, align 8
  %v4058 = load i32, ptr %slot339, align 8
  %op4059 = and i32 %v4058, 28
  store i32 %op4059, ptr %slot340, align 8
  %v4060 = load i32, ptr %slot340, align 8
  %cv4061 = zext i32 %v4060 to i64
  %cond4062 = icmp ne i64 %cv4061, 0
  br i1 %cond4062, label %bb_rcslotrole316, label %bb_rcslotowner316
bb_rcslotrole316:
  %v4063 = load i64, ptr %slot110, align 8
  store i64 %v4063, ptr %slot341, align 8
  %v4064 = load i64, ptr %slot338, align 8
  %p4065 = inttoptr i64 %v4064 to ptr
  %ld4066 = load i64, ptr %p4065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4066, ptr %slot342, align 8
  %v4067 = load i64, ptr %slot342, align 8
  %cmp4068 = icmp ne i64 %v4067, 0
  %cv4069 = zext i1 %cmp4068 to i32
  store i32 %cv4069, ptr %slot343, align 8
  %v4070 = load i32, ptr %slot343, align 8
  %cv4071 = zext i32 %v4070 to i64
  %cond4072 = icmp ne i64 %cv4071, 0
  br i1 %cond4072, label %bb_rcgnn332, label %bb_rcgdone332
bb_rcgnn332:
  %v4073 = load i64, ptr %slot342, align 8
  %op4074 = sub i64 %v4073, 16
  store i64 %op4074, ptr %slot344, align 8
  %v4075 = load i64, ptr %slot342, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  %rgep4077 = getelementptr i8, ptr %p4076, i64 -16
  %ld4078 = load i64, ptr %rgep4077, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4078, ptr %slot345, align 8
  %v4079 = load i64, ptr %slot345, align 8
  %op4080 = and i64 %v4079, 4611686018427387906
  store i64 %op4080, ptr %slot346, align 8
  %v4081 = load i64, ptr %slot346, align 8
  %cmp4082 = icmp ne i64 %v4081, 0
  %cv4083 = zext i1 %cmp4082 to i32
  store i32 %cv4083, ptr %slot347, align 8
  %v4084 = load i32, ptr %slot347, align 8
  %cv4085 = zext i32 %v4084 to i64
  %cond4086 = icmp ne i64 %cv4085, 0
  br i1 %cond4086, label %bb_rcgclear332, label %bb_rcgcounted332
bb_rcgcounted332:
  %v4087 = load i64, ptr %slot342, align 8
  %op4088 = sub i64 %v4087, 24
  store i64 %op4088, ptr %slot348, align 8
  %v4089 = load i64, ptr %slot342, align 8
  %p4090 = inttoptr i64 %v4089 to ptr
  %rgep4091 = getelementptr i8, ptr %p4090, i64 -24
  %ld4092 = load i64, ptr %rgep4091, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4092, ptr %slot349, align 8
  %v4093 = load i64, ptr %slot349, align 8
  %op4094 = sub i64 %v4093, 1
  store i64 %op4094, ptr %slot350, align 8
  %v4095 = load i64, ptr %slot350, align 8
  %cmp4096 = icmp eq i64 %v4095, 0
  %cv4097 = zext i1 %cmp4096 to i32
  store i32 %cv4097, ptr %slot351, align 8
  %v4098 = load i32, ptr %slot351, align 8
  %cv4099 = zext i32 %v4098 to i64
  %cond4100 = icmp ne i64 %cv4099, 0
  br i1 %cond4100, label %bb_rcglast332, label %bb_rcgdec332
bb_rcglast332:
  %v4101 = load i64, ptr %slot342, align 8
  %op4102 = sub i64 %v4101, 32
  store i64 %op4102, ptr %slot352, align 8
  %v4103 = load i64, ptr %slot342, align 8
  %p4104 = inttoptr i64 %v4103 to ptr
  %rgep4105 = getelementptr i8, ptr %p4104, i64 -32
  %ld4106 = load i64, ptr %rgep4105, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4106, ptr %slot353, align 8
  %v4107 = load i64, ptr %slot353, align 8
  %cmp4108 = icmp ne i64 %v4107, 0
  %cv4109 = zext i1 %cmp4108 to i32
  store i32 %cv4109, ptr %slot354, align 8
  %v4110 = load i32, ptr %slot354, align 8
  %cv4111 = zext i32 %v4110 to i64
  %cond4112 = icmp ne i64 %cv4111, 0
  br i1 %cond4112, label %bb_rcgdec332, label %bb_rcgslow332
bb_rcgslow332:
  %v4113 = load i64, ptr %slot341, align 8
  %v4114 = load i64, ptr %slot338, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v4113, i64 %v4114) nomerge, !dbg !118
  br label %bb_rcgdone332
bb_rcgdec332:
  %v4115 = load i64, ptr %slot350, align 8
  %v4116 = load i64, ptr %slot342, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  %rgep4118 = getelementptr i8, ptr %p4117, i64 -24
  store i64 %v4115, ptr %rgep4118, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear332
bb_rcgclear332:
  %v4119 = load i64, ptr %slot338, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  store i64 0, ptr %p4120, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone332
bb_rcgdone332:
  br label %bb_rcslotdone316
bb_rcslotowner316:
  %v4121 = load i64, ptr %slot110, align 8
  store i64 %v4121, ptr %slot355, align 8
  %v4122 = load i64, ptr %slot338, align 8
  %p4123 = inttoptr i64 %v4122 to ptr
  %ld4124 = load i64, ptr %p4123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4124, ptr %slot356, align 8
  %v4125 = load i64, ptr %slot356, align 8
  %cmp4126 = icmp ne i64 %v4125, 0
  %cv4127 = zext i1 %cmp4126 to i32
  store i32 %cv4127, ptr %slot357, align 8
  %v4128 = load i32, ptr %slot357, align 8
  %cv4129 = zext i32 %v4128 to i64
  %cond4130 = icmp ne i64 %cv4129, 0
  br i1 %cond4130, label %bb_rcgnn347, label %bb_rcgdone347
bb_rcgnn347:
  %v4131 = load i64, ptr %slot356, align 8
  %op4132 = sub i64 %v4131, 16
  store i64 %op4132, ptr %slot358, align 8
  %v4133 = load i64, ptr %slot356, align 8
  %p4134 = inttoptr i64 %v4133 to ptr
  %rgep4135 = getelementptr i8, ptr %p4134, i64 -16
  %ld4136 = load i64, ptr %rgep4135, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4136, ptr %slot359, align 8
  %v4137 = load i64, ptr %slot359, align 8
  %op4138 = and i64 %v4137, 4611686018427387906
  store i64 %op4138, ptr %slot360, align 8
  %v4139 = load i64, ptr %slot360, align 8
  %cmp4140 = icmp ne i64 %v4139, 0
  %cv4141 = zext i1 %cmp4140 to i32
  store i32 %cv4141, ptr %slot361, align 8
  %v4142 = load i32, ptr %slot361, align 8
  %cv4143 = zext i32 %v4142 to i64
  %cond4144 = icmp ne i64 %cv4143, 0
  br i1 %cond4144, label %bb_rcgclear347, label %bb_rcgcounted347
bb_rcgcounted347:
  %v4145 = load i64, ptr %slot356, align 8
  %op4146 = sub i64 %v4145, 32
  store i64 %op4146, ptr %slot362, align 8
  %v4147 = load i64, ptr %slot356, align 8
  %p4148 = inttoptr i64 %v4147 to ptr
  %rgep4149 = getelementptr i8, ptr %p4148, i64 -32
  %ld4150 = load i64, ptr %rgep4149, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4150, ptr %slot363, align 8
  %v4151 = load i64, ptr %slot363, align 8
  %op4152 = sub i64 %v4151, 1
  store i64 %op4152, ptr %slot364, align 8
  %v4153 = load i64, ptr %slot364, align 8
  %cmp4154 = icmp eq i64 %v4153, 0
  %cv4155 = zext i1 %cmp4154 to i32
  store i32 %cv4155, ptr %slot365, align 8
  %v4156 = load i32, ptr %slot365, align 8
  %cv4157 = zext i32 %v4156 to i64
  %cond4158 = icmp ne i64 %cv4157, 0
  br i1 %cond4158, label %bb_rcglast347, label %bb_rcgdec347
bb_rcglast347:
  %v4159 = load i64, ptr %slot356, align 8
  %op4160 = sub i64 %v4159, 24
  store i64 %op4160, ptr %slot366, align 8
  %v4161 = load i64, ptr %slot356, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %rgep4163 = getelementptr i8, ptr %p4162, i64 -24
  %ld4164 = load i64, ptr %rgep4163, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4164, ptr %slot367, align 8
  %v4165 = load i64, ptr %slot367, align 8
  %cmp4166 = icmp ne i64 %v4165, 0
  %cv4167 = zext i1 %cmp4166 to i32
  store i32 %cv4167, ptr %slot368, align 8
  %v4168 = load i32, ptr %slot368, align 8
  %cv4169 = zext i32 %v4168 to i64
  %cond4170 = icmp ne i64 %cv4169, 0
  br i1 %cond4170, label %bb_rcgdec347, label %bb_rcgslow347
bb_rcgslow347:
  %v4171 = load i64, ptr %slot355, align 8
  %v4172 = load i64, ptr %slot338, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v4171, i64 %v4172) nomerge, !dbg !118
  br label %bb_rcgdone347
bb_rcgdec347:
  %v4173 = load i64, ptr %slot364, align 8
  %v4174 = load i64, ptr %slot356, align 8
  %p4175 = inttoptr i64 %v4174 to ptr
  %rgep4176 = getelementptr i8, ptr %p4175, i64 -32
  store i64 %v4173, ptr %rgep4176, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear347
bb_rcgclear347:
  %v4177 = load i64, ptr %slot338, align 8
  %p4178 = inttoptr i64 %v4177 to ptr
  store i64 0, ptr %p4178, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone347
bb_rcgdone347:
  br label %bb_rcslotdone316
bb_rcslotdone316:
  %v4179 = load i64, ptr %slot80, align 8
  %p4180 = inttoptr i64 %v4179 to ptr
  store i64 0, ptr %p4180, align 8, !alias.scope !3, !noalias !4
  %v4181 = load i64, ptr %slot80, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  %ld4183 = load i64, ptr %p4182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4183, ptr %slot369, align 8
  %v4184 = load i64, ptr %slot369, align 8
  %v4185 = load i64, ptr %slot70, align 8
  %p4186 = inttoptr i64 %v4185 to ptr
  store i64 %v4184, ptr %p4186, align 8, !alias.scope !3, !noalias !4
  br label %bb_i8
bb_i8:
  %v4187 = load i64, ptr %slot70, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  %ld4189 = load i64, ptr %p4188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4189, ptr %slot370, align 8
  %v4190 = load i64, ptr %slot370, align 8
  %v4191 = load i64, ptr %slot80, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  store i64 %v4190, ptr %p4192, align 8, !alias.scope !3, !noalias !4
  %v4193 = load i64, ptr %slot81, align 8
  %p4194 = inttoptr i64 %v4193 to ptr
  store i64 16384, ptr %p4194, align 8, !alias.scope !3, !noalias !4
  %v4195 = load i64, ptr %slot81, align 8
  %p4196 = inttoptr i64 %v4195 to ptr
  %ld4197 = load i64, ptr %p4196, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4197, ptr %slot371, align 8
  %v4198 = load i64, ptr %slot80, align 8
  %p4199 = inttoptr i64 %v4198 to ptr
  %ld4200 = load i64, ptr %p4199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4200, ptr %slot372, align 8
  %v4201 = load i64, ptr %slot372, align 8
  %v4202 = load i64, ptr %slot371, align 8
  %cmp4203 = icmp slt i64 %v4201, %v4202
  %cv4204 = zext i1 %cmp4203 to i64
  store i64 %cv4204, ptr %slot373, align 8
  %v4205 = load i64, ptr %slot373, align 8
  %v4206 = load i64, ptr %slot80, align 8
  %p4207 = inttoptr i64 %v4206 to ptr
  store i64 %v4205, ptr %p4207, align 8, !alias.scope !3, !noalias !4
  %v4208 = load i64, ptr %slot80, align 8
  %p4209 = inttoptr i64 %v4208 to ptr
  %ld4210 = load i64, ptr %p4209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4210, ptr %slot374, align 8
  %v4211 = load i64, ptr %slot374, align 8
  %cond4212 = icmp ne i64 %v4211, 0
  br i1 %cond4212, label %bb_next357, label %bb_i20
bb_next357:
  %v4213 = load i64, ptr %slot102, align 8
  store i64 %v4213, ptr %slot375, align 8
  %v4214 = load i64, ptr %slot375, align 8
  %p4215 = inttoptr i64 %v4214 to ptr
  store i64 0, ptr %p4215, align 8, !alias.scope !3, !noalias !4
  %v4216 = load i64, ptr %slot375, align 8
  %p4218 = inttoptr i64 %v4216 to ptr
  %gep4219 = getelementptr i8, ptr %p4218, i64 8
  %op4217 = ptrtoint ptr %gep4219 to i64
  store i64 %op4217, ptr %slot376, align 8
  %v4220 = load i64, ptr %slot376, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  store i64 0, ptr %p4221, align 8, !alias.scope !3, !noalias !4
  %v4222 = load i64, ptr %slot375, align 8
  %p4223 = inttoptr i64 %v4222 to ptr
  store i32 0, ptr %p4223, align 4, !alias.scope !3, !noalias !4
  %v4224 = load i64, ptr %slot375, align 8
  %v4225 = load i64, ptr %slot80, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  store i64 %v4224, ptr %p4226, align 8, !alias.scope !3, !noalias !4
  %v4227 = load i64, ptr %slot69, align 8
  store i64 %v4227, ptr %slot377, align 8
  %v4228 = load i64, ptr %slot9, align 8
  %p4229 = inttoptr i64 %v4228 to ptr
  store i32 2, ptr %p4229, align 4, !alias.scope !3, !noalias !4
  %v4230 = load i64, ptr %slot377, align 8
  %p4231 = inttoptr i64 %v4230 to ptr
  %ld4232 = load i64, ptr %p4231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4232, ptr %slot378, align 8
  %v4233 = load i64, ptr %slot378, align 8
  %cmp4234 = icmp ne i64 %v4233, 0
  %cv4235 = zext i1 %cmp4234 to i32
  store i32 %cv4235, ptr %slot379, align 8
  %v4236 = load i32, ptr %slot379, align 8
  %cv4237 = zext i32 %v4236 to i64
  %cond4238 = icmp ne i64 %cv4237, 0
  br i1 %cond4238, label %bb_rcguniquenn362, label %bb_rcgunique362
bb_rcguniquenn362:
  %v4239 = load i64, ptr %slot378, align 8
  %op4240 = sub i64 %v4239, 16
  store i64 %op4240, ptr %slot380, align 8
  %v4241 = load i64, ptr %slot378, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  %rgep4243 = getelementptr i8, ptr %p4242, i64 -16
  %ld4244 = load i64, ptr %rgep4243, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4244, ptr %slot381, align 8
  %v4245 = load i64, ptr %slot381, align 8
  %op4246 = and i64 %v4245, 6917529027641081858
  store i64 %op4246, ptr %slot382, align 8
  %v4247 = load i64, ptr %slot382, align 8
  %cmp4248 = icmp ne i64 %v4247, 0
  %cv4249 = zext i1 %cmp4248 to i32
  store i32 %cv4249, ptr %slot383, align 8
  %v4250 = load i32, ptr %slot383, align 8
  %cv4251 = zext i32 %v4250 to i64
  %cond4252 = icmp ne i64 %cv4251, 0
  br i1 %cond4252, label %bb_rcguniqueslow362, label %bb_rcguniquecount362
bb_rcguniquecount362:
  %v4253 = load i64, ptr %slot378, align 8
  %op4254 = sub i64 %v4253, 32
  store i64 %op4254, ptr %slot384, align 8
  %v4255 = load i64, ptr %slot378, align 8
  %p4256 = inttoptr i64 %v4255 to ptr
  %rgep4257 = getelementptr i8, ptr %p4256, i64 -32
  %ld4258 = load i64, ptr %rgep4257, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4258, ptr %slot385, align 8
  %v4259 = load i64, ptr %slot385, align 8
  %cmp4260 = icmp ult i64 %v4259, 2
  %cv4261 = zext i1 %cmp4260 to i32
  store i32 %cv4261, ptr %slot386, align 8
  %v4262 = load i32, ptr %slot386, align 8
  %cv4263 = zext i32 %v4262 to i64
  %cond4264 = icmp ne i64 %cv4263, 0
  br i1 %cond4264, label %bb_rcgunique362, label %bb_rcguniqueslow362
bb_rcguniqueslow362:
  %v4265 = load i64, ptr %slot1, align 8
  %p4266 = inttoptr i64 %v4265 to ptr
  %p4267 = inttoptr i64 ptrtoint (ptr @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a to i64) to ptr
  %v4268 = load i64, ptr %slot377, align 8
  %p4269 = inttoptr i64 %v4268 to ptr
  %v4270 = load i64, ptr %slot8, align 8
  %p4271 = inttoptr i64 %v4270 to ptr
  %call4272 = call i32 @myl_qbe_rc_unique_local(ptr %p4266, ptr %p4267, ptr %p4269, ptr %p4271) nomerge, !dbg !120
  store i32 %call4272, ptr %slot387, align 8
  %v4273 = load i32, ptr %slot387, align 8
  %cv4274 = zext i32 %v4273 to i64
  %cond4275 = icmp ne i64 %cv4274, 0
  br i1 %cond4275, label %bb_rcunique373, label %bb_failure
bb_rcunique373:
  br label %bb_rcgunique362
bb_rcgunique362:
  %v4276 = load i64, ptr %slot69, align 8
  %p4277 = inttoptr i64 %v4276 to ptr
  %ld4278 = load i64, ptr %p4277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4278, ptr %slot388, align 8
  %v4279 = load i64, ptr %slot80, align 8
  %p4280 = inttoptr i64 %v4279 to ptr
  %ld4281 = load i64, ptr %p4280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4281, ptr %slot389, align 8
  %v4282 = load i64, ptr %slot110, align 8
  %v4283 = load i64, ptr %slot388, align 8
  %v4284 = load i64, ptr %slot389, align 8
  %call4285 = call i32 @myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47_rcg_list_append(i64 %v4282, i64 %v4283, i64 %v4284) nomerge, !dbg !120
  store i32 %call4285, ptr %slot390, align 8
  %v4286 = load i32, ptr %slot390, align 8
  %cv4287 = zext i32 %v4286 to i64
  %cond4288 = icmp ne i64 %cv4287, 0
  br i1 %cond4288, label %bb_success377, label %bb_failed377
bb_failed377:
  %v4289 = load i64, ptr %slot1, align 8
  %p4290 = inttoptr i64 %v4289 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4290) nomerge, !dbg !120
  unreachable
bb_success377:
  %v4291 = load i64, ptr %slot80, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  store i64 0, ptr %p4292, align 8, !alias.scope !3, !noalias !4
  %v4293 = load i64, ptr %slot70, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  %ld4295 = load i64, ptr %p4294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4295, ptr %slot391, align 8
  %v4296 = load i64, ptr %slot391, align 8
  %v4297 = load i64, ptr %slot80, align 8
  %p4298 = inttoptr i64 %v4297 to ptr
  store i64 %v4296, ptr %p4298, align 8, !alias.scope !3, !noalias !4
  %v4299 = load i64, ptr %slot81, align 8
  %p4300 = inttoptr i64 %v4299 to ptr
  store i64 1, ptr %p4300, align 8, !alias.scope !3, !noalias !4
  %v4301 = load i64, ptr %slot81, align 8
  %p4302 = inttoptr i64 %v4301 to ptr
  %ld4303 = load i64, ptr %p4302, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4303, ptr %slot392, align 8
  %v4304 = load i64, ptr %slot80, align 8
  %p4305 = inttoptr i64 %v4304 to ptr
  %ld4306 = load i64, ptr %p4305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4306, ptr %slot393, align 8
  %v4307 = load i64, ptr %slot393, align 8
  %v4308 = load i64, ptr %slot392, align 8
  %ovpair4310 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4307, i64 %v4308)
  %op4309 = extractvalue { i64, i1 } %ovpair4310, 0
  %ov4311 = extractvalue { i64, i1 } %ovpair4310, 1
  store i64 %op4309, ptr %slot394, align 8
  %cv4312 = zext i1 %ov4311 to i64
  store i64 %cv4312, ptr %slot395, align 8
  %v4313 = load i64, ptr %slot395, align 8
  %cond4314 = icmp ne i64 %v4313, 0
  br i1 %cond4314, label %bb_overflow381, label %bb_checked381
bb_overflow381:
  %v4315 = load i64, ptr %slot1, align 8
  %p4316 = inttoptr i64 %v4315 to ptr
  %v4317 = load i64, ptr %slot393, align 8
  %v4318 = load i64, ptr %slot392, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4316, i64 0, i64 %v4317, i64 %v4318, i64 64) nomerge, !dbg !122
  unreachable
bb_checked381:
  %v4319 = load i64, ptr %slot394, align 8
  %v4320 = load i64, ptr %slot80, align 8
  %p4321 = inttoptr i64 %v4320 to ptr
  store i64 %v4319, ptr %p4321, align 8, !alias.scope !3, !noalias !4
  %v4322 = load i64, ptr %slot80, align 8
  %p4323 = inttoptr i64 %v4322 to ptr
  %ld4324 = load i64, ptr %p4323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4324, ptr %slot396, align 8
  %v4325 = load i64, ptr %slot396, align 8
  %v4326 = load i64, ptr %slot70, align 8
  %p4327 = inttoptr i64 %v4326 to ptr
  store i64 %v4325, ptr %p4327, align 8, !alias.scope !3, !noalias !4
  br label %bb_i8
bb_i20:
  %v4328 = load i64, ptr %slot80, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  store i64 0, ptr %p4329, align 8, !alias.scope !3, !noalias !4
  %v4330 = load i64, ptr %slot80, align 8
  %p4331 = inttoptr i64 %v4330 to ptr
  %ld4332 = load i64, ptr %p4331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4332, ptr %slot397, align 8
  %v4333 = load i64, ptr %slot397, align 8
  %cmp4334 = icmp sge i64 %v4333, 0
  %cv4335 = zext i1 %cmp4334 to i64
  store i64 %cv4335, ptr %slot398, align 8
  %v4336 = load i64, ptr %slot398, align 8
  %cond4337 = icmp ne i64 %v4336, 0
  br i1 %cond4337, label %bb_success386, label %bb_failed386
bb_failed386:
  %v4338 = load i64, ptr %slot1, align 8
  %p4339 = inttoptr i64 %v4338 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p4339) nomerge, !dbg !124
  unreachable
bb_success386:
  %v4340 = load i64, ptr %slot110, align 8
  %p4341 = inttoptr i64 %v4340 to ptr
  %p4342 = inttoptr i64 ptrtoint (ptr @myl_t_135c20434b3e567dc9f56890b2e744a3921cd3f40404c14f8a6e8ab4481a5802 to i64) to ptr
  %v4343 = load i64, ptr %slot397, align 8
  %call4344 = call ptr @myl_native_list_new(ptr %p4341, ptr %p4342, i64 %v4343) nomerge, !dbg !124
  %calladdr4345 = ptrtoint ptr %call4344 to i64
  store i64 %calladdr4345, ptr %slot399, align 8
  %v4346 = load i64, ptr %slot399, align 8
  %cond4347 = icmp ne i64 %v4346, 0
  br i1 %cond4347, label %bb_success388, label %bb_failed388
bb_failed388:
  %v4348 = load i64, ptr %slot1, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4349) nomerge, !dbg !124
  unreachable
bb_success388:
  %v4350 = load i64, ptr %slot399, align 8
  %v4351 = load i64, ptr %slot80, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  store i64 %v4350, ptr %p4352, align 8, !alias.scope !3, !noalias !4
  %v4353 = load i64, ptr %slot80, align 8
  %p4354 = inttoptr i64 %v4353 to ptr
  %ld4355 = load i64, ptr %p4354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4355, ptr %slot400, align 8
  %v4356 = load i64, ptr %slot400, align 8
  %v4357 = load i64, ptr %slot57, align 8
  %p4358 = inttoptr i64 %v4357 to ptr
  store i64 %v4356, ptr %p4358, align 8, !alias.scope !3, !noalias !4
  %v4359 = load i64, ptr %slot57, align 8
  store i64 %v4359, ptr %slot401, align 8
  %v4360 = load i64, ptr %slot65, align 8
  store i64 %v4360, ptr %slot402, align 8
  %v4361 = load i64, ptr %slot401, align 8
  %v4362 = load i64, ptr %slot402, align 8
  %p4363 = inttoptr i64 %v4361 to ptr
  %p4364 = inttoptr i64 %v4362 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4364, ptr %p4363, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4365 = load i64, ptr %slot47, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  store i32 2, ptr %p4366, align 4, !alias.scope !3, !noalias !4
  %v4367 = load i64, ptr %slot46, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  store i32 1, ptr %p4368, align 4, !alias.scope !3, !noalias !4
  %v4369 = load i64, ptr %slot49, align 8
  store i64 %v4369, ptr %slot403, align 8
  %v4370 = load i64, ptr %slot65, align 8
  store i64 %v4370, ptr %slot404, align 8
  %v4371 = load i64, ptr %slot404, align 8
  %v4372 = load i64, ptr %slot403, align 8
  %p4373 = inttoptr i64 %v4371 to ptr
  %p4374 = inttoptr i64 %v4372 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4374, ptr %p4373, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4375 = load i64, ptr %slot29, align 8
  %p4376 = inttoptr i64 %v4375 to ptr
  store i32 2, ptr %p4376, align 4, !alias.scope !3, !noalias !4
  %v4377 = load i64, ptr %slot47, align 8
  %p4378 = inttoptr i64 %v4377 to ptr
  %ld4379 = load i32, ptr %p4378, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4379, ptr %slot405, align 8
  %v4380 = load i32, ptr %slot405, align 8
  %v4381 = load i64, ptr %slot29, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  store i32 %v4380, ptr %p4382, align 4, !alias.scope !3, !noalias !4
  %v4383 = load i64, ptr %slot46, align 8
  %p4384 = inttoptr i64 %v4383 to ptr
  store i32 0, ptr %p4384, align 4, !alias.scope !3, !noalias !4
  %v4385 = load i64, ptr %slot28, align 8
  %p4386 = inttoptr i64 %v4385 to ptr
  store i32 1, ptr %p4386, align 4, !alias.scope !3, !noalias !4
  %v4387 = load i64, ptr %slot403, align 8
  %p4388 = inttoptr i64 %v4387 to ptr
  %ld4389 = load i64, ptr %p4388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4389, ptr %slot406, align 8
  %v4390 = load i64, ptr %slot406, align 8
  %v4391 = load i64, ptr %slot80, align 8
  %p4392 = inttoptr i64 %v4391 to ptr
  store i64 %v4390, ptr %p4392, align 8, !alias.scope !3, !noalias !4
  %v4393 = load i64, ptr %slot80, align 8
  %p4394 = inttoptr i64 %v4393 to ptr
  %ld4395 = load i64, ptr %p4394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4395, ptr %slot407, align 8
  %v4396 = load i64, ptr %slot407, align 8
  %v4397 = load i64, ptr %slot57, align 8
  %p4398 = inttoptr i64 %v4397 to ptr
  store i64 %v4396, ptr %p4398, align 8, !alias.scope !3, !noalias !4
  %v4399 = load i64, ptr %slot57, align 8
  store i64 %v4399, ptr %slot408, align 8
  %v4400 = load i64, ptr %slot28, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  %ld4402 = load i32, ptr %p4401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4402, ptr %slot409, align 8
  %v4403 = load i64, ptr %slot29, align 8
  %p4404 = inttoptr i64 %v4403 to ptr
  %ld4405 = load i32, ptr %p4404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4405, ptr %slot410, align 8
  %v4406 = load i32, ptr %slot410, align 8
  %op4407 = and i32 %v4406, 24
  store i32 %op4407, ptr %slot410, align 8
  %v4408 = load i32, ptr %slot410, align 8
  %cmp4409 = icmp eq i32 %v4408, 0
  %cv4410 = zext i1 %cmp4409 to i32
  store i32 %cv4410, ptr %slot411, align 8
  %v4411 = load i32, ptr %slot409, align 8
  %v4412 = load i32, ptr %slot411, align 8
  %op4413 = and i32 %v4411, %v4412
  store i32 %op4413, ptr %slot412, align 8
  %v4414 = load i32, ptr %slot412, align 8
  %cv4415 = zext i32 %v4414 to i64
  %cond4416 = icmp ne i64 %cv4415, 0
  br i1 %cond4416, label %bb_rcprivateown411, label %bb_rcprivateloan411
bb_rcprivateown411:
  %v4417 = load i64, ptr %slot65, align 8
  store i64 %v4417, ptr %slot413, align 8
  %v4418 = load i64, ptr %slot111, align 8
  store i64 %v4418, ptr %slot414, align 8
  %v4419 = load i64, ptr %slot408, align 8
  %v4420 = load i64, ptr %slot413, align 8
  %op4421 = sub i64 %v4419, %v4420
  store i64 %op4421, ptr %slot415, align 8
  %v4422 = load i64, ptr %slot413, align 8
  %v4423 = load i64, ptr %slot408, align 8
  %op4424 = sub i64 %v4422, %v4423
  store i64 %op4424, ptr %slot416, align 8
  %v4425 = load i64, ptr %slot415, align 8
  %cmp4426 = icmp ult i64 %v4425, 8
  %cv4427 = zext i1 %cmp4426 to i32
  store i32 %cv4427, ptr %slot417, align 8
  %v4428 = load i64, ptr %slot416, align 8
  %cmp4429 = icmp ult i64 %v4428, 8
  %cv4430 = zext i1 %cmp4429 to i32
  store i32 %cv4430, ptr %slot418, align 8
  %v4431 = load i32, ptr %slot417, align 8
  %v4432 = load i32, ptr %slot418, align 8
  %op4433 = or i32 %v4431, %v4432
  store i32 %op4433, ptr %slot419, align 8
  %v4434 = load i32, ptr %slot419, align 8
  %cv4435 = zext i32 %v4434 to i64
  %cond4436 = icmp ne i64 %cv4435, 0
  br i1 %cond4436, label %bb_rcmoveslow414, label %bb_rcmovecheck414
bb_rcmovecheck414:
  %v4437 = load i64, ptr %slot408, align 8
  %p4439 = inttoptr i64 %v4437 to ptr
  %gep4440 = getelementptr i8, ptr %p4439, i64 0
  %op4438 = ptrtoint ptr %gep4440 to i64
  store i64 %op4438, ptr %slot420, align 8
  %v4441 = load i64, ptr %slot420, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  %ld4443 = load i64, ptr %p4442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4443, ptr %slot421, align 8
  %v4444 = load i64, ptr %slot421, align 8
  %cmp4445 = icmp ne i64 %v4444, 0
  %cv4446 = zext i1 %cmp4445 to i32
  store i32 %cv4446, ptr %slot422, align 8
  %v4447 = load i32, ptr %slot422, align 8
  %cv4448 = zext i32 %v4447 to i64
  %cond4449 = icmp ne i64 %cv4448, 0
  br i1 %cond4449, label %bb_rcmoveheader422, label %bb_rcmovenext422
bb_rcmoveheader422:
  %v4450 = load i64, ptr %slot421, align 8
  %op4451 = sub i64 %v4450, 16
  store i64 %op4451, ptr %slot423, align 8
  %v4452 = load i64, ptr %slot421, align 8
  %p4453 = inttoptr i64 %v4452 to ptr
  %rgep4454 = getelementptr i8, ptr %p4453, i64 -16
  %ld4455 = load i64, ptr %rgep4454, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4455, ptr %slot424, align 8
  %v4456 = load i64, ptr %slot424, align 8
  %op4457 = and i64 %v4456, 5764607523034234881
  store i64 %op4457, ptr %slot425, align 8
  %v4458 = load i64, ptr %slot425, align 8
  %cmp4459 = icmp ne i64 %v4458, 0
  %cv4460 = zext i1 %cmp4459 to i32
  store i32 %cv4460, ptr %slot426, align 8
  %v4461 = load i32, ptr %slot426, align 8
  %cv4462 = zext i32 %v4461 to i64
  %cond4463 = icmp ne i64 %cv4462, 0
  br i1 %cond4463, label %bb_rcmoveslow414, label %bb_rcmovenext422
bb_rcmovenext422:
  %v4464 = load i64, ptr %slot408, align 8
  %v4465 = load i64, ptr %slot413, align 8
  %p4466 = inttoptr i64 %v4464 to ptr
  %p4467 = inttoptr i64 %v4465 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4467, ptr %p4466, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4468 = load i64, ptr %slot408, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  store i64 0, ptr %p4469, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved414
bb_rcmoveslow414:
  %v4470 = load i64, ptr %slot110, align 8
  %v4471 = load i64, ptr %slot413, align 8
  %v4472 = load i64, ptr %slot408, align 8
  %v4473 = load i64, ptr %slot414, align 8
  %cv4474 = trunc i64 %v4473 to i32
  %call4475 = call i32 @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_take(i64 %v4470, i64 %v4471, i64 %v4472, i32 %cv4474) nomerge, !dbg !126
  store i32 %call4475, ptr %slot427, align 8
  %v4476 = load i32, ptr %slot427, align 8
  %cv4477 = zext i32 %v4476 to i64
  %cond4478 = icmp ne i64 %cv4477, 0
  br i1 %cond4478, label %bb_rcsuccess429, label %bb_rcfailure429
bb_rcfailure429:
  %v4479 = load i64, ptr %slot110, align 8
  %p4480 = inttoptr i64 %v4479 to ptr
  %call4481 = call i32 @myl_rc_take_failure(ptr %p4480) nomerge, !dbg !126
  store i32 %call4481, ptr %slot428, align 8
  %v4482 = load i64, ptr %slot1, align 8
  %p4483 = inttoptr i64 %v4482 to ptr
  %v4484 = load i32, ptr %slot428, align 8
  %call4485 = call i32 @myl_qbe_rc_status(ptr %p4483, i32 %v4484) nomerge, !dbg !126
  store i32 %call4485, ptr %slot429, align 8
  br label %bb_failure
bb_rcsuccess429:
  br label %bb_rcmoved414
bb_rcmoved414:
  %v4486 = load i64, ptr %slot28, align 8
  %p4487 = inttoptr i64 %v4486 to ptr
  store i32 0, ptr %p4487, align 4, !alias.scope !3, !noalias !4
  %v4488 = load i64, ptr %slot47, align 8
  %p4489 = inttoptr i64 %v4488 to ptr
  store i32 2, ptr %p4489, align 4, !alias.scope !3, !noalias !4
  %v4490 = load i64, ptr %slot46, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  store i32 1, ptr %p4491, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared411
bb_rcprivateloan411:
  %v4492 = load i64, ptr %slot28, align 8
  %p4493 = inttoptr i64 %v4492 to ptr
  %ld4494 = load i32, ptr %p4493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4494, ptr %slot430, align 8
  %v4495 = load i64, ptr %slot29, align 8
  %p4496 = inttoptr i64 %v4495 to ptr
  %ld4497 = load i32, ptr %p4496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4497, ptr %slot431, align 8
  %v4498 = load i32, ptr %slot431, align 8
  %cmp4499 = icmp eq i32 %v4498, 16
  %cv4500 = zext i1 %cmp4499 to i32
  store i32 %cv4500, ptr %slot432, align 8
  %v4501 = load i32, ptr %slot432, align 8
  %v4502 = load i32, ptr %slot430, align 8
  %op4503 = and i32 %v4501, %v4502
  store i32 %op4503, ptr %slot432, align 8
  %v4504 = load i32, ptr %slot432, align 8
  %cv4505 = zext i32 %v4504 to i64
  %cond4506 = icmp ne i64 %cv4505, 0
  br i1 %cond4506, label %bb_rcprivatemove411, label %bb_rcprivatenew411
bb_rcprivatemove411:
  %v4507 = load i64, ptr %slot65, align 8
  store i64 %v4507, ptr %slot433, align 8
  %v4508 = load i64, ptr %slot408, align 8
  %v4509 = load i64, ptr %slot433, align 8
  %p4510 = inttoptr i64 %v4508 to ptr
  %p4511 = inttoptr i64 %v4509 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4511, ptr %p4510, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4512 = load i64, ptr %slot408, align 8
  %p4513 = inttoptr i64 %v4512 to ptr
  store i64 0, ptr %p4513, align 8, !alias.scope !3, !noalias !4
  %v4514 = load i64, ptr %slot47, align 8
  %p4515 = inttoptr i64 %v4514 to ptr
  store i32 2, ptr %p4515, align 4, !alias.scope !3, !noalias !4
  %v4516 = load i64, ptr %slot47, align 8
  %p4517 = inttoptr i64 %v4516 to ptr
  store i32 16, ptr %p4517, align 4, !alias.scope !3, !noalias !4
  %v4518 = load i64, ptr %slot46, align 8
  %p4519 = inttoptr i64 %v4518 to ptr
  store i32 1, ptr %p4519, align 4, !alias.scope !3, !noalias !4
  %v4520 = load i64, ptr %slot28, align 8
  %p4521 = inttoptr i64 %v4520 to ptr
  store i32 0, ptr %p4521, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared411
bb_rcprivatenew411:
  %v4522 = load i64, ptr %slot65, align 8
  store i64 %v4522, ptr %slot434, align 8
  %v4523 = load i64, ptr %slot408, align 8
  %p4524 = inttoptr i64 %v4523 to ptr
  %ld4525 = load i64, ptr %p4524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4525, ptr %slot435, align 8
  %v4526 = load i64, ptr %slot435, align 8
  %cmp4527 = icmp ne i64 %v4526, 0
  %cv4528 = zext i1 %cmp4527 to i32
  store i32 %cv4528, ptr %slot436, align 8
  %v4529 = load i32, ptr %slot436, align 8
  %cv4530 = zext i32 %v4529 to i64
  %cond4531 = icmp ne i64 %cv4530, 0
  br i1 %cond4531, label %bb_rcgnn447, label %bb_rcgstore447
bb_rcgnn447:
  %v4532 = load i64, ptr %slot435, align 8
  %op4533 = sub i64 %v4532, 16
  store i64 %op4533, ptr %slot437, align 8
  %v4534 = load i64, ptr %slot435, align 8
  %p4535 = inttoptr i64 %v4534 to ptr
  %rgep4536 = getelementptr i8, ptr %p4535, i64 -16
  %ld4537 = load i64, ptr %rgep4536, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4537, ptr %slot438, align 8
  %v4538 = load i64, ptr %slot438, align 8
  %op4539 = and i64 %v4538, 4611686018427387906
  store i64 %op4539, ptr %slot439, align 8
  %v4540 = load i64, ptr %slot439, align 8
  %cmp4541 = icmp ne i64 %v4540, 0
  %cv4542 = zext i1 %cmp4541 to i32
  store i32 %cv4542, ptr %slot440, align 8
  %v4543 = load i32, ptr %slot440, align 8
  %cv4544 = zext i32 %v4543 to i64
  %cond4545 = icmp ne i64 %cv4544, 0
  br i1 %cond4545, label %bb_rcgstore447, label %bb_rcginc447
bb_rcginc447:
  %v4546 = load i64, ptr %slot435, align 8
  %op4547 = sub i64 %v4546, 24
  store i64 %op4547, ptr %slot441, align 8
  %v4548 = load i64, ptr %slot435, align 8
  %p4549 = inttoptr i64 %v4548 to ptr
  %rgep4550 = getelementptr i8, ptr %p4549, i64 -24
  %ld4551 = load i64, ptr %rgep4550, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4551, ptr %slot442, align 8
  %v4552 = load i64, ptr %slot442, align 8
  %op4553 = add i64 %v4552, 1
  store i64 %op4553, ptr %slot443, align 8
  %v4554 = load i64, ptr %slot443, align 8
  %cmp4555 = icmp eq i64 %v4554, 0
  %cv4556 = zext i1 %cmp4555 to i32
  store i32 %cv4556, ptr %slot444, align 8
  %v4557 = load i32, ptr %slot444, align 8
  %cv4558 = zext i32 %v4557 to i64
  %cond4559 = icmp ne i64 %cv4558, 0
  br i1 %cond4559, label %bb_rcglimit447, label %bb_rcgcapacity447
bb_rcglimit447:
  %v4560 = load i64, ptr %slot1, align 8
  %p4561 = inttoptr i64 %v4560 to ptr
  %call4562 = call i32 @myl_qbe_rc_status(ptr %p4561, i32 2) nomerge, !dbg !126
  store i32 %call4562, ptr %slot445, align 8
  br label %bb_failure
bb_rcgcapacity447:
  %v4563 = load i64, ptr %slot443, align 8
  %v4564 = load i64, ptr %slot435, align 8
  %p4565 = inttoptr i64 %v4564 to ptr
  %rgep4566 = getelementptr i8, ptr %p4565, i64 -24
  store i64 %v4563, ptr %rgep4566, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore447
bb_rcgstore447:
  %v4567 = load i64, ptr %slot435, align 8
  %v4568 = load i64, ptr %slot434, align 8
  %p4569 = inttoptr i64 %v4568 to ptr
  store i64 %v4567, ptr %p4569, align 8, !alias.scope !3, !noalias !4
  %v4570 = load i64, ptr %slot47, align 8
  %p4571 = inttoptr i64 %v4570 to ptr
  store i32 2, ptr %p4571, align 4, !alias.scope !3, !noalias !4
  %v4572 = load i64, ptr %slot47, align 8
  %p4573 = inttoptr i64 %v4572 to ptr
  store i32 16, ptr %p4573, align 4, !alias.scope !3, !noalias !4
  %v4574 = load i64, ptr %slot46, align 8
  %p4575 = inttoptr i64 %v4574 to ptr
  store i32 1, ptr %p4575, align 4, !alias.scope !3, !noalias !4
  %v4576 = load i64, ptr %slot28, align 8
  %p4577 = inttoptr i64 %v4576 to ptr
  %ld4578 = load i32, ptr %p4577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4578, ptr %slot446, align 8
  %v4579 = load i32, ptr %slot446, align 8
  %cv4580 = zext i32 %v4579 to i64
  %cond4581 = icmp ne i64 %cv4580, 0
  br i1 %cond4581, label %bb_rcslotdrop463, label %bb_rcslotdone463
bb_rcslotdrop463:
  %v4582 = load i64, ptr %slot28, align 8
  %p4583 = inttoptr i64 %v4582 to ptr
  store i32 0, ptr %p4583, align 4, !alias.scope !3, !noalias !4
  %v4584 = load i64, ptr %slot49, align 8
  store i64 %v4584, ptr %slot447, align 8
  %v4585 = load i64, ptr %slot29, align 8
  %p4586 = inttoptr i64 %v4585 to ptr
  %ld4587 = load i32, ptr %p4586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4587, ptr %slot448, align 8
  %v4588 = load i32, ptr %slot448, align 8
  %op4589 = and i32 %v4588, 28
  store i32 %op4589, ptr %slot449, align 8
  %v4590 = load i32, ptr %slot449, align 8
  %cv4591 = zext i32 %v4590 to i64
  %cond4592 = icmp ne i64 %cv4591, 0
  br i1 %cond4592, label %bb_rcslotrole463, label %bb_rcslotowner463
bb_rcslotrole463:
  %v4593 = load i64, ptr %slot110, align 8
  store i64 %v4593, ptr %slot450, align 8
  %v4594 = load i64, ptr %slot447, align 8
  %p4595 = inttoptr i64 %v4594 to ptr
  %ld4596 = load i64, ptr %p4595, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4596, ptr %slot451, align 8
  %v4597 = load i64, ptr %slot451, align 8
  %cmp4598 = icmp ne i64 %v4597, 0
  %cv4599 = zext i1 %cmp4598 to i32
  store i32 %cv4599, ptr %slot452, align 8
  %v4600 = load i32, ptr %slot452, align 8
  %cv4601 = zext i32 %v4600 to i64
  %cond4602 = icmp ne i64 %cv4601, 0
  br i1 %cond4602, label %bb_rcgnn479, label %bb_rcgdone479
bb_rcgnn479:
  %v4603 = load i64, ptr %slot451, align 8
  %op4604 = sub i64 %v4603, 16
  store i64 %op4604, ptr %slot453, align 8
  %v4605 = load i64, ptr %slot451, align 8
  %p4606 = inttoptr i64 %v4605 to ptr
  %rgep4607 = getelementptr i8, ptr %p4606, i64 -16
  %ld4608 = load i64, ptr %rgep4607, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4608, ptr %slot454, align 8
  %v4609 = load i64, ptr %slot454, align 8
  %op4610 = and i64 %v4609, 4611686018427387906
  store i64 %op4610, ptr %slot455, align 8
  %v4611 = load i64, ptr %slot455, align 8
  %cmp4612 = icmp ne i64 %v4611, 0
  %cv4613 = zext i1 %cmp4612 to i32
  store i32 %cv4613, ptr %slot456, align 8
  %v4614 = load i32, ptr %slot456, align 8
  %cv4615 = zext i32 %v4614 to i64
  %cond4616 = icmp ne i64 %cv4615, 0
  br i1 %cond4616, label %bb_rcgclear479, label %bb_rcgcounted479
bb_rcgcounted479:
  %v4617 = load i64, ptr %slot451, align 8
  %op4618 = sub i64 %v4617, 24
  store i64 %op4618, ptr %slot457, align 8
  %v4619 = load i64, ptr %slot451, align 8
  %p4620 = inttoptr i64 %v4619 to ptr
  %rgep4621 = getelementptr i8, ptr %p4620, i64 -24
  %ld4622 = load i64, ptr %rgep4621, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4622, ptr %slot458, align 8
  %v4623 = load i64, ptr %slot458, align 8
  %op4624 = sub i64 %v4623, 1
  store i64 %op4624, ptr %slot459, align 8
  %v4625 = load i64, ptr %slot459, align 8
  %cmp4626 = icmp eq i64 %v4625, 0
  %cv4627 = zext i1 %cmp4626 to i32
  store i32 %cv4627, ptr %slot460, align 8
  %v4628 = load i32, ptr %slot460, align 8
  %cv4629 = zext i32 %v4628 to i64
  %cond4630 = icmp ne i64 %cv4629, 0
  br i1 %cond4630, label %bb_rcglast479, label %bb_rcgdec479
bb_rcglast479:
  %v4631 = load i64, ptr %slot451, align 8
  %op4632 = sub i64 %v4631, 32
  store i64 %op4632, ptr %slot461, align 8
  %v4633 = load i64, ptr %slot451, align 8
  %p4634 = inttoptr i64 %v4633 to ptr
  %rgep4635 = getelementptr i8, ptr %p4634, i64 -32
  %ld4636 = load i64, ptr %rgep4635, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4636, ptr %slot462, align 8
  %v4637 = load i64, ptr %slot462, align 8
  %cmp4638 = icmp ne i64 %v4637, 0
  %cv4639 = zext i1 %cmp4638 to i32
  store i32 %cv4639, ptr %slot463, align 8
  %v4640 = load i32, ptr %slot463, align 8
  %cv4641 = zext i32 %v4640 to i64
  %cond4642 = icmp ne i64 %cv4641, 0
  br i1 %cond4642, label %bb_rcgdec479, label %bb_rcgslow479
bb_rcgslow479:
  %v4643 = load i64, ptr %slot450, align 8
  %v4644 = load i64, ptr %slot447, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_unloan(i64 %v4643, i64 %v4644) nomerge, !dbg !126
  br label %bb_rcgdone479
bb_rcgdec479:
  %v4645 = load i64, ptr %slot459, align 8
  %v4646 = load i64, ptr %slot451, align 8
  %p4647 = inttoptr i64 %v4646 to ptr
  %rgep4648 = getelementptr i8, ptr %p4647, i64 -24
  store i64 %v4645, ptr %rgep4648, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear479
bb_rcgclear479:
  %v4649 = load i64, ptr %slot447, align 8
  %p4650 = inttoptr i64 %v4649 to ptr
  store i64 0, ptr %p4650, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone479
bb_rcgdone479:
  br label %bb_rcslotdone463
bb_rcslotowner463:
  %v4651 = load i64, ptr %slot110, align 8
  store i64 %v4651, ptr %slot464, align 8
  %v4652 = load i64, ptr %slot447, align 8
  %p4653 = inttoptr i64 %v4652 to ptr
  %ld4654 = load i64, ptr %p4653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4654, ptr %slot465, align 8
  %v4655 = load i64, ptr %slot465, align 8
  %cmp4656 = icmp ne i64 %v4655, 0
  %cv4657 = zext i1 %cmp4656 to i32
  store i32 %cv4657, ptr %slot466, align 8
  %v4658 = load i32, ptr %slot466, align 8
  %cv4659 = zext i32 %v4658 to i64
  %cond4660 = icmp ne i64 %cv4659, 0
  br i1 %cond4660, label %bb_rcgnn494, label %bb_rcgdone494
bb_rcgnn494:
  %v4661 = load i64, ptr %slot465, align 8
  %op4662 = sub i64 %v4661, 16
  store i64 %op4662, ptr %slot467, align 8
  %v4663 = load i64, ptr %slot465, align 8
  %p4664 = inttoptr i64 %v4663 to ptr
  %rgep4665 = getelementptr i8, ptr %p4664, i64 -16
  %ld4666 = load i64, ptr %rgep4665, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4666, ptr %slot468, align 8
  %v4667 = load i64, ptr %slot468, align 8
  %op4668 = and i64 %v4667, 4611686018427387906
  store i64 %op4668, ptr %slot469, align 8
  %v4669 = load i64, ptr %slot469, align 8
  %cmp4670 = icmp ne i64 %v4669, 0
  %cv4671 = zext i1 %cmp4670 to i32
  store i32 %cv4671, ptr %slot470, align 8
  %v4672 = load i32, ptr %slot470, align 8
  %cv4673 = zext i32 %v4672 to i64
  %cond4674 = icmp ne i64 %cv4673, 0
  br i1 %cond4674, label %bb_rcgclear494, label %bb_rcgcounted494
bb_rcgcounted494:
  %v4675 = load i64, ptr %slot465, align 8
  %op4676 = sub i64 %v4675, 32
  store i64 %op4676, ptr %slot471, align 8
  %v4677 = load i64, ptr %slot465, align 8
  %p4678 = inttoptr i64 %v4677 to ptr
  %rgep4679 = getelementptr i8, ptr %p4678, i64 -32
  %ld4680 = load i64, ptr %rgep4679, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4680, ptr %slot472, align 8
  %v4681 = load i64, ptr %slot472, align 8
  %op4682 = sub i64 %v4681, 1
  store i64 %op4682, ptr %slot473, align 8
  %v4683 = load i64, ptr %slot473, align 8
  %cmp4684 = icmp eq i64 %v4683, 0
  %cv4685 = zext i1 %cmp4684 to i32
  store i32 %cv4685, ptr %slot474, align 8
  %v4686 = load i32, ptr %slot474, align 8
  %cv4687 = zext i32 %v4686 to i64
  %cond4688 = icmp ne i64 %cv4687, 0
  br i1 %cond4688, label %bb_rcglast494, label %bb_rcgdec494
bb_rcglast494:
  %v4689 = load i64, ptr %slot465, align 8
  %op4690 = sub i64 %v4689, 24
  store i64 %op4690, ptr %slot475, align 8
  %v4691 = load i64, ptr %slot465, align 8
  %p4692 = inttoptr i64 %v4691 to ptr
  %rgep4693 = getelementptr i8, ptr %p4692, i64 -24
  %ld4694 = load i64, ptr %rgep4693, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4694, ptr %slot476, align 8
  %v4695 = load i64, ptr %slot476, align 8
  %cmp4696 = icmp ne i64 %v4695, 0
  %cv4697 = zext i1 %cmp4696 to i32
  store i32 %cv4697, ptr %slot477, align 8
  %v4698 = load i32, ptr %slot477, align 8
  %cv4699 = zext i32 %v4698 to i64
  %cond4700 = icmp ne i64 %cv4699, 0
  br i1 %cond4700, label %bb_rcgdec494, label %bb_rcgslow494
bb_rcgslow494:
  %v4701 = load i64, ptr %slot464, align 8
  %v4702 = load i64, ptr %slot447, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_drop(i64 %v4701, i64 %v4702) nomerge, !dbg !126
  br label %bb_rcgdone494
bb_rcgdec494:
  %v4703 = load i64, ptr %slot473, align 8
  %v4704 = load i64, ptr %slot465, align 8
  %p4705 = inttoptr i64 %v4704 to ptr
  %rgep4706 = getelementptr i8, ptr %p4705, i64 -32
  store i64 %v4703, ptr %rgep4706, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear494
bb_rcgclear494:
  %v4707 = load i64, ptr %slot447, align 8
  %p4708 = inttoptr i64 %v4707 to ptr
  store i64 0, ptr %p4708, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone494
bb_rcgdone494:
  br label %bb_rcslotdone463
bb_rcslotdone463:
  br label %bb_rcprivateprepared411
bb_rcprivateprepared411:
  %v4709 = load i64, ptr %slot10, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  %ld4711 = load i32, ptr %p4710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4711, ptr %slot478, align 8
  %v4712 = load i32, ptr %slot478, align 8
  %cv4713 = zext i32 %v4712 to i64
  %cond4714 = icmp ne i64 %cv4713, 0
  br i1 %cond4714, label %bb_rcslotdrop501, label %bb_rcslotdone501
bb_rcslotdrop501:
  %v4715 = load i64, ptr %slot10, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  store i32 0, ptr %p4716, align 4, !alias.scope !3, !noalias !4
  %v4717 = load i64, ptr %slot71, align 8
  store i64 %v4717, ptr %slot479, align 8
  %v4718 = load i64, ptr %slot11, align 8
  %p4719 = inttoptr i64 %v4718 to ptr
  %ld4720 = load i32, ptr %p4719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4720, ptr %slot480, align 8
  %v4721 = load i32, ptr %slot480, align 8
  %op4722 = and i32 %v4721, 28
  store i32 %op4722, ptr %slot481, align 8
  %v4723 = load i32, ptr %slot481, align 8
  %cv4724 = zext i32 %v4723 to i64
  %cond4725 = icmp ne i64 %cv4724, 0
  br i1 %cond4725, label %bb_rcslotrole501, label %bb_rcslotowner501
bb_rcslotrole501:
  %v4726 = load i64, ptr %slot110, align 8
  store i64 %v4726, ptr %slot482, align 8
  %v4727 = load i64, ptr %slot479, align 8
  %p4728 = inttoptr i64 %v4727 to ptr
  %ld4729 = load i64, ptr %p4728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4729, ptr %slot483, align 8
  %v4730 = load i64, ptr %slot483, align 8
  %cmp4731 = icmp ne i64 %v4730, 0
  %cv4732 = zext i1 %cmp4731 to i32
  store i32 %cv4732, ptr %slot484, align 8
  %v4733 = load i32, ptr %slot484, align 8
  %cv4734 = zext i32 %v4733 to i64
  %cond4735 = icmp ne i64 %cv4734, 0
  br i1 %cond4735, label %bb_rcgnn517, label %bb_rcgdone517
bb_rcgnn517:
  %v4736 = load i64, ptr %slot483, align 8
  %op4737 = sub i64 %v4736, 16
  store i64 %op4737, ptr %slot485, align 8
  %v4738 = load i64, ptr %slot483, align 8
  %p4739 = inttoptr i64 %v4738 to ptr
  %rgep4740 = getelementptr i8, ptr %p4739, i64 -16
  %ld4741 = load i64, ptr %rgep4740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4741, ptr %slot486, align 8
  %v4742 = load i64, ptr %slot486, align 8
  %op4743 = and i64 %v4742, 4611686018427387906
  store i64 %op4743, ptr %slot487, align 8
  %v4744 = load i64, ptr %slot487, align 8
  %cmp4745 = icmp ne i64 %v4744, 0
  %cv4746 = zext i1 %cmp4745 to i32
  store i32 %cv4746, ptr %slot488, align 8
  %v4747 = load i32, ptr %slot488, align 8
  %cv4748 = zext i32 %v4747 to i64
  %cond4749 = icmp ne i64 %cv4748, 0
  br i1 %cond4749, label %bb_rcgclear517, label %bb_rcgcounted517
bb_rcgcounted517:
  %v4750 = load i64, ptr %slot483, align 8
  %op4751 = sub i64 %v4750, 24
  store i64 %op4751, ptr %slot489, align 8
  %v4752 = load i64, ptr %slot483, align 8
  %p4753 = inttoptr i64 %v4752 to ptr
  %rgep4754 = getelementptr i8, ptr %p4753, i64 -24
  %ld4755 = load i64, ptr %rgep4754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4755, ptr %slot490, align 8
  %v4756 = load i64, ptr %slot490, align 8
  %op4757 = sub i64 %v4756, 1
  store i64 %op4757, ptr %slot491, align 8
  %v4758 = load i64, ptr %slot491, align 8
  %cmp4759 = icmp eq i64 %v4758, 0
  %cv4760 = zext i1 %cmp4759 to i32
  store i32 %cv4760, ptr %slot492, align 8
  %v4761 = load i32, ptr %slot492, align 8
  %cv4762 = zext i32 %v4761 to i64
  %cond4763 = icmp ne i64 %cv4762, 0
  br i1 %cond4763, label %bb_rcglast517, label %bb_rcgdec517
bb_rcglast517:
  %v4764 = load i64, ptr %slot483, align 8
  %op4765 = sub i64 %v4764, 32
  store i64 %op4765, ptr %slot493, align 8
  %v4766 = load i64, ptr %slot483, align 8
  %p4767 = inttoptr i64 %v4766 to ptr
  %rgep4768 = getelementptr i8, ptr %p4767, i64 -32
  %ld4769 = load i64, ptr %rgep4768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4769, ptr %slot494, align 8
  %v4770 = load i64, ptr %slot494, align 8
  %cmp4771 = icmp ne i64 %v4770, 0
  %cv4772 = zext i1 %cmp4771 to i32
  store i32 %cv4772, ptr %slot495, align 8
  %v4773 = load i32, ptr %slot495, align 8
  %cv4774 = zext i32 %v4773 to i64
  %cond4775 = icmp ne i64 %cv4774, 0
  br i1 %cond4775, label %bb_rcgdec517, label %bb_rcgslow517
bb_rcgslow517:
  %v4776 = load i64, ptr %slot482, align 8
  %v4777 = load i64, ptr %slot479, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_unloan(i64 %v4776, i64 %v4777) nomerge, !dbg !126
  br label %bb_rcgdone517
bb_rcgdec517:
  %v4778 = load i64, ptr %slot491, align 8
  %v4779 = load i64, ptr %slot483, align 8
  %p4780 = inttoptr i64 %v4779 to ptr
  %rgep4781 = getelementptr i8, ptr %p4780, i64 -24
  store i64 %v4778, ptr %rgep4781, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear517
bb_rcgclear517:
  %v4782 = load i64, ptr %slot479, align 8
  %p4783 = inttoptr i64 %v4782 to ptr
  store i64 0, ptr %p4783, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone517
bb_rcgdone517:
  br label %bb_rcslotdone501
bb_rcslotowner501:
  %v4784 = load i64, ptr %slot110, align 8
  store i64 %v4784, ptr %slot496, align 8
  %v4785 = load i64, ptr %slot479, align 8
  %p4786 = inttoptr i64 %v4785 to ptr
  %ld4787 = load i64, ptr %p4786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4787, ptr %slot497, align 8
  %v4788 = load i64, ptr %slot497, align 8
  %cmp4789 = icmp ne i64 %v4788, 0
  %cv4790 = zext i1 %cmp4789 to i32
  store i32 %cv4790, ptr %slot498, align 8
  %v4791 = load i32, ptr %slot498, align 8
  %cv4792 = zext i32 %v4791 to i64
  %cond4793 = icmp ne i64 %cv4792, 0
  br i1 %cond4793, label %bb_rcgnn532, label %bb_rcgdone532
bb_rcgnn532:
  %v4794 = load i64, ptr %slot497, align 8
  %op4795 = sub i64 %v4794, 16
  store i64 %op4795, ptr %slot499, align 8
  %v4796 = load i64, ptr %slot497, align 8
  %p4797 = inttoptr i64 %v4796 to ptr
  %rgep4798 = getelementptr i8, ptr %p4797, i64 -16
  %ld4799 = load i64, ptr %rgep4798, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4799, ptr %slot500, align 8
  %v4800 = load i64, ptr %slot500, align 8
  %op4801 = and i64 %v4800, 4611686018427387906
  store i64 %op4801, ptr %slot501, align 8
  %v4802 = load i64, ptr %slot501, align 8
  %cmp4803 = icmp ne i64 %v4802, 0
  %cv4804 = zext i1 %cmp4803 to i32
  store i32 %cv4804, ptr %slot502, align 8
  %v4805 = load i32, ptr %slot502, align 8
  %cv4806 = zext i32 %v4805 to i64
  %cond4807 = icmp ne i64 %cv4806, 0
  br i1 %cond4807, label %bb_rcgclear532, label %bb_rcgcounted532
bb_rcgcounted532:
  %v4808 = load i64, ptr %slot497, align 8
  %op4809 = sub i64 %v4808, 32
  store i64 %op4809, ptr %slot503, align 8
  %v4810 = load i64, ptr %slot497, align 8
  %p4811 = inttoptr i64 %v4810 to ptr
  %rgep4812 = getelementptr i8, ptr %p4811, i64 -32
  %ld4813 = load i64, ptr %rgep4812, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4813, ptr %slot504, align 8
  %v4814 = load i64, ptr %slot504, align 8
  %op4815 = sub i64 %v4814, 1
  store i64 %op4815, ptr %slot505, align 8
  %v4816 = load i64, ptr %slot505, align 8
  %cmp4817 = icmp eq i64 %v4816, 0
  %cv4818 = zext i1 %cmp4817 to i32
  store i32 %cv4818, ptr %slot506, align 8
  %v4819 = load i32, ptr %slot506, align 8
  %cv4820 = zext i32 %v4819 to i64
  %cond4821 = icmp ne i64 %cv4820, 0
  br i1 %cond4821, label %bb_rcglast532, label %bb_rcgdec532
bb_rcglast532:
  %v4822 = load i64, ptr %slot497, align 8
  %op4823 = sub i64 %v4822, 24
  store i64 %op4823, ptr %slot507, align 8
  %v4824 = load i64, ptr %slot497, align 8
  %p4825 = inttoptr i64 %v4824 to ptr
  %rgep4826 = getelementptr i8, ptr %p4825, i64 -24
  %ld4827 = load i64, ptr %rgep4826, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4827, ptr %slot508, align 8
  %v4828 = load i64, ptr %slot508, align 8
  %cmp4829 = icmp ne i64 %v4828, 0
  %cv4830 = zext i1 %cmp4829 to i32
  store i32 %cv4830, ptr %slot509, align 8
  %v4831 = load i32, ptr %slot509, align 8
  %cv4832 = zext i32 %v4831 to i64
  %cond4833 = icmp ne i64 %cv4832, 0
  br i1 %cond4833, label %bb_rcgdec532, label %bb_rcgslow532
bb_rcgslow532:
  %v4834 = load i64, ptr %slot496, align 8
  %v4835 = load i64, ptr %slot479, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_drop(i64 %v4834, i64 %v4835) nomerge, !dbg !126
  br label %bb_rcgdone532
bb_rcgdec532:
  %v4836 = load i64, ptr %slot505, align 8
  %v4837 = load i64, ptr %slot497, align 8
  %p4838 = inttoptr i64 %v4837 to ptr
  %rgep4839 = getelementptr i8, ptr %p4838, i64 -32
  store i64 %v4836, ptr %rgep4839, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear532
bb_rcgclear532:
  %v4840 = load i64, ptr %slot479, align 8
  %p4841 = inttoptr i64 %v4840 to ptr
  store i64 0, ptr %p4841, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone532
bb_rcgdone532:
  br label %bb_rcslotdone501
bb_rcslotdone501:
  %v4842 = load i64, ptr %slot71, align 8
  store i64 %v4842, ptr %slot510, align 8
  %v4843 = load i64, ptr %slot65, align 8
  store i64 %v4843, ptr %slot511, align 8
  %v4844 = load i64, ptr %slot511, align 8
  %v4845 = load i64, ptr %slot510, align 8
  %p4846 = inttoptr i64 %v4844 to ptr
  %p4847 = inttoptr i64 %v4845 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4847, ptr %p4846, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4848 = load i64, ptr %slot46, align 8
  %p4849 = inttoptr i64 %v4848 to ptr
  store i32 0, ptr %p4849, align 4, !alias.scope !3, !noalias !4
  %v4850 = load i64, ptr %slot11, align 8
  %p4851 = inttoptr i64 %v4850 to ptr
  store i32 2, ptr %p4851, align 4, !alias.scope !3, !noalias !4
  %v4852 = load i64, ptr %slot47, align 8
  %p4853 = inttoptr i64 %v4852 to ptr
  %ld4854 = load i32, ptr %p4853, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4854, ptr %slot512, align 8
  %v4855 = load i32, ptr %slot512, align 8
  %v4856 = load i64, ptr %slot11, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  store i32 %v4855, ptr %p4857, align 4, !alias.scope !3, !noalias !4
  %v4858 = load i64, ptr %slot10, align 8
  %p4859 = inttoptr i64 %v4858 to ptr
  store i32 1, ptr %p4859, align 4, !alias.scope !3, !noalias !4
  %v4860 = load i64, ptr %slot71, align 8
  %p4861 = inttoptr i64 %v4860 to ptr
  %ld4862 = load i64, ptr %p4861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4862, ptr %slot513, align 8
  %v4863 = load i64, ptr %slot513, align 8
  %v4864 = load i64, ptr %slot80, align 8
  %p4865 = inttoptr i64 %v4864 to ptr
  store i64 %v4863, ptr %p4865, align 8, !alias.scope !3, !noalias !4
  %v4866 = load i64, ptr %slot80, align 8
  %p4867 = inttoptr i64 %v4866 to ptr
  %ld4868 = load i64, ptr %p4867, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4868, ptr %slot514, align 8
  %v4869 = load i64, ptr %slot514, align 8
  %v4870 = load i64, ptr %slot57, align 8
  %p4871 = inttoptr i64 %v4870 to ptr
  store i64 %v4869, ptr %p4871, align 8, !alias.scope !3, !noalias !4
  %v4872 = load i64, ptr %slot57, align 8
  store i64 %v4872, ptr %slot515, align 8
  %v4873 = load i64, ptr %slot28, align 8
  %p4874 = inttoptr i64 %v4873 to ptr
  %ld4875 = load i32, ptr %p4874, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4875, ptr %slot516, align 8
  %v4876 = load i64, ptr %slot29, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %ld4878 = load i32, ptr %p4877, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4878, ptr %slot517, align 8
  %v4879 = load i32, ptr %slot517, align 8
  %op4880 = and i32 %v4879, 24
  store i32 %op4880, ptr %slot517, align 8
  %v4881 = load i32, ptr %slot517, align 8
  %cmp4882 = icmp eq i32 %v4881, 0
  %cv4883 = zext i1 %cmp4882 to i32
  store i32 %cv4883, ptr %slot518, align 8
  %v4884 = load i32, ptr %slot516, align 8
  %v4885 = load i32, ptr %slot518, align 8
  %op4886 = and i32 %v4884, %v4885
  store i32 %op4886, ptr %slot519, align 8
  %v4887 = load i32, ptr %slot519, align 8
  %cv4888 = zext i32 %v4887 to i64
  %cond4889 = icmp ne i64 %cv4888, 0
  br i1 %cond4889, label %bb_rctake546, label %bb_rccopy546
bb_rctake546:
  %v4890 = load i64, ptr %slot65, align 8
  store i64 %v4890, ptr %slot520, align 8
  %v4891 = load i64, ptr %slot111, align 8
  store i64 %v4891, ptr %slot521, align 8
  %v4892 = load i64, ptr %slot515, align 8
  %v4893 = load i64, ptr %slot520, align 8
  %op4894 = sub i64 %v4892, %v4893
  store i64 %op4894, ptr %slot522, align 8
  %v4895 = load i64, ptr %slot520, align 8
  %v4896 = load i64, ptr %slot515, align 8
  %op4897 = sub i64 %v4895, %v4896
  store i64 %op4897, ptr %slot523, align 8
  %v4898 = load i64, ptr %slot522, align 8
  %cmp4899 = icmp ult i64 %v4898, 8
  %cv4900 = zext i1 %cmp4899 to i32
  store i32 %cv4900, ptr %slot524, align 8
  %v4901 = load i64, ptr %slot523, align 8
  %cmp4902 = icmp ult i64 %v4901, 8
  %cv4903 = zext i1 %cmp4902 to i32
  store i32 %cv4903, ptr %slot525, align 8
  %v4904 = load i32, ptr %slot524, align 8
  %v4905 = load i32, ptr %slot525, align 8
  %op4906 = or i32 %v4904, %v4905
  store i32 %op4906, ptr %slot526, align 8
  %v4907 = load i32, ptr %slot526, align 8
  %cv4908 = zext i32 %v4907 to i64
  %cond4909 = icmp ne i64 %cv4908, 0
  br i1 %cond4909, label %bb_rcmoveslow555, label %bb_rcmovecheck555
bb_rcmovecheck555:
  %v4910 = load i64, ptr %slot515, align 8
  %p4912 = inttoptr i64 %v4910 to ptr
  %gep4913 = getelementptr i8, ptr %p4912, i64 0
  %op4911 = ptrtoint ptr %gep4913 to i64
  store i64 %op4911, ptr %slot527, align 8
  %v4914 = load i64, ptr %slot527, align 8
  %p4915 = inttoptr i64 %v4914 to ptr
  %ld4916 = load i64, ptr %p4915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4916, ptr %slot528, align 8
  %v4917 = load i64, ptr %slot528, align 8
  %cmp4918 = icmp ne i64 %v4917, 0
  %cv4919 = zext i1 %cmp4918 to i32
  store i32 %cv4919, ptr %slot529, align 8
  %v4920 = load i32, ptr %slot529, align 8
  %cv4921 = zext i32 %v4920 to i64
  %cond4922 = icmp ne i64 %cv4921, 0
  br i1 %cond4922, label %bb_rcmoveheader563, label %bb_rcmovenext563
bb_rcmoveheader563:
  %v4923 = load i64, ptr %slot528, align 8
  %op4924 = sub i64 %v4923, 16
  store i64 %op4924, ptr %slot530, align 8
  %v4925 = load i64, ptr %slot528, align 8
  %p4926 = inttoptr i64 %v4925 to ptr
  %rgep4927 = getelementptr i8, ptr %p4926, i64 -16
  %ld4928 = load i64, ptr %rgep4927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4928, ptr %slot531, align 8
  %v4929 = load i64, ptr %slot531, align 8
  %op4930 = and i64 %v4929, 5764607523034234881
  store i64 %op4930, ptr %slot532, align 8
  %v4931 = load i64, ptr %slot532, align 8
  %cmp4932 = icmp ne i64 %v4931, 0
  %cv4933 = zext i1 %cmp4932 to i32
  store i32 %cv4933, ptr %slot533, align 8
  %v4934 = load i32, ptr %slot533, align 8
  %cv4935 = zext i32 %v4934 to i64
  %cond4936 = icmp ne i64 %cv4935, 0
  br i1 %cond4936, label %bb_rcmoveslow555, label %bb_rcmovenext563
bb_rcmovenext563:
  %v4937 = load i64, ptr %slot515, align 8
  %v4938 = load i64, ptr %slot520, align 8
  %p4939 = inttoptr i64 %v4937 to ptr
  %p4940 = inttoptr i64 %v4938 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4940, ptr %p4939, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4941 = load i64, ptr %slot515, align 8
  %p4942 = inttoptr i64 %v4941 to ptr
  store i64 0, ptr %p4942, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved555
bb_rcmoveslow555:
  %v4943 = load i64, ptr %slot110, align 8
  %v4944 = load i64, ptr %slot520, align 8
  %v4945 = load i64, ptr %slot515, align 8
  %v4946 = load i64, ptr %slot521, align 8
  %cv4947 = trunc i64 %v4946 to i32
  %call4948 = call i32 @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_take(i64 %v4943, i64 %v4944, i64 %v4945, i32 %cv4947) nomerge, !dbg !128
  store i32 %call4948, ptr %slot534, align 8
  %v4949 = load i32, ptr %slot534, align 8
  %cv4950 = zext i32 %v4949 to i64
  %cond4951 = icmp ne i64 %cv4950, 0
  br i1 %cond4951, label %bb_rcsuccess570, label %bb_rcfailure570
bb_rcfailure570:
  %v4952 = load i64, ptr %slot110, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %call4954 = call i32 @myl_rc_take_failure(ptr %p4953) nomerge, !dbg !128
  store i32 %call4954, ptr %slot535, align 8
  %v4955 = load i64, ptr %slot1, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  %v4957 = load i32, ptr %slot535, align 8
  %call4958 = call i32 @myl_qbe_rc_status(ptr %p4956, i32 %v4957) nomerge, !dbg !128
  store i32 %call4958, ptr %slot536, align 8
  br label %bb_failure
bb_rcsuccess570:
  br label %bb_rcmoved555
bb_rcmoved555:
  %v4959 = load i64, ptr %slot28, align 8
  %p4960 = inttoptr i64 %v4959 to ptr
  store i32 0, ptr %p4960, align 4, !alias.scope !3, !noalias !4
  %v4961 = load i64, ptr %slot47, align 8
  %p4962 = inttoptr i64 %v4961 to ptr
  store i32 2, ptr %p4962, align 4, !alias.scope !3, !noalias !4
  %v4963 = load i64, ptr %slot46, align 8
  %p4964 = inttoptr i64 %v4963 to ptr
  store i32 1, ptr %p4964, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared546
bb_rccopy546:
  %v4965 = load i64, ptr %slot65, align 8
  store i64 %v4965, ptr %slot537, align 8
  %v4966 = load i64, ptr %slot111, align 8
  store i64 %v4966, ptr %slot538, align 8
  %v4967 = load i64, ptr %slot515, align 8
  %p4968 = inttoptr i64 %v4967 to ptr
  %ld4969 = load i64, ptr %p4968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4969, ptr %slot539, align 8
  %v4970 = load i64, ptr %slot539, align 8
  %cmp4971 = icmp ne i64 %v4970, 0
  %cv4972 = zext i1 %cmp4971 to i32
  store i32 %cv4972, ptr %slot540, align 8
  %v4973 = load i32, ptr %slot540, align 8
  %cv4974 = zext i32 %v4973 to i64
  %cond4975 = icmp ne i64 %cv4974, 0
  br i1 %cond4975, label %bb_rcgnn579, label %bb_rcgplain579
bb_rcgnn579:
  %v4976 = load i64, ptr %slot539, align 8
  %op4977 = sub i64 %v4976, 16
  store i64 %op4977, ptr %slot541, align 8
  %v4978 = load i64, ptr %slot539, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  %rgep4980 = getelementptr i8, ptr %p4979, i64 -16
  %ld4981 = load i64, ptr %rgep4980, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4981, ptr %slot542, align 8
  %v4982 = load i64, ptr %slot542, align 8
  %op4983 = and i64 %v4982, 4611686018427387906
  store i64 %op4983, ptr %slot543, align 8
  %v4984 = load i64, ptr %slot543, align 8
  %cmp4985 = icmp ne i64 %v4984, 0
  %cv4986 = zext i1 %cmp4985 to i32
  store i32 %cv4986, ptr %slot544, align 8
  %v4987 = load i32, ptr %slot544, align 8
  %cv4988 = zext i32 %v4987 to i64
  %cond4989 = icmp ne i64 %cv4988, 0
  br i1 %cond4989, label %bb_rcgspecial579, label %bb_rcginc579
bb_rcginc579:
  %v4990 = load i64, ptr %slot539, align 8
  %op4991 = sub i64 %v4990, 32
  store i64 %op4991, ptr %slot545, align 8
  %v4992 = load i64, ptr %slot539, align 8
  %p4993 = inttoptr i64 %v4992 to ptr
  %rgep4994 = getelementptr i8, ptr %p4993, i64 -32
  %ld4995 = load i64, ptr %rgep4994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4995, ptr %slot546, align 8
  %v4996 = load i64, ptr %slot546, align 8
  %op4997 = add i64 %v4996, 1
  store i64 %op4997, ptr %slot547, align 8
  %v4998 = load i64, ptr %slot547, align 8
  %cmp4999 = icmp eq i64 %v4998, 0
  %cv5000 = zext i1 %cmp4999 to i32
  store i32 %cv5000, ptr %slot548, align 8
  %v5001 = load i32, ptr %slot548, align 8
  %cv5002 = zext i32 %v5001 to i64
  %cond5003 = icmp ne i64 %cv5002, 0
  br i1 %cond5003, label %bb_rcglimit579, label %bb_rcgcapacity579
bb_rcglimit579:
  %v5004 = load i64, ptr %slot1, align 8
  %p5005 = inttoptr i64 %v5004 to ptr
  %call5006 = call i32 @myl_qbe_rc_status(ptr %p5005, i32 2) nomerge, !dbg !128
  store i32 %call5006, ptr %slot549, align 8
  br label %bb_failure
bb_rcgcapacity579:
  %v5007 = load i64, ptr %slot547, align 8
  %v5008 = load i64, ptr %slot539, align 8
  %p5009 = inttoptr i64 %v5008 to ptr
  %rgep5010 = getelementptr i8, ptr %p5009, i64 -32
  store i64 %v5007, ptr %rgep5010, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain579
bb_rcgspecial579:
  %v5011 = load i64, ptr %slot542, align 8
  %op5012 = and i64 %v5011, 4611686018427387904
  store i64 %op5012, ptr %slot550, align 8
  %v5013 = load i64, ptr %slot550, align 8
  %cmp5014 = icmp ne i64 %v5013, 0
  %cv5015 = zext i1 %cmp5014 to i32
  store i32 %cv5015, ptr %slot551, align 8
  %v5016 = load i32, ptr %slot551, align 8
  %cv5017 = zext i32 %v5016 to i64
  %cond5018 = icmp ne i64 %cv5017, 0
  br i1 %cond5018, label %bb_rcgslow579, label %bb_rcgplain579
bb_rcgslow579:
  %v5019 = load i64, ptr %slot110, align 8
  %v5020 = load i64, ptr %slot537, align 8
  %v5021 = load i64, ptr %slot515, align 8
  %v5022 = load i64, ptr %slot538, align 8
  %cv5023 = trunc i64 %v5022 to i32
  %call5024 = call i32 @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_retain(i64 %v5019, i64 %v5020, i64 %v5021, i32 %cv5023) nomerge, !dbg !128
  store i32 %call5024, ptr %slot552, align 8
  %v5025 = load i32, ptr %slot552, align 8
  %cv5026 = zext i32 %v5025 to i64
  %cond5027 = icmp ne i64 %cv5026, 0
  br i1 %cond5027, label %bb_rcsuccess593, label %bb_rcfailure593
bb_rcfailure593:
  %v5028 = load i64, ptr %slot110, align 8
  %p5029 = inttoptr i64 %v5028 to ptr
  %call5030 = call i32 @myl_rc_take_failure(ptr %p5029) nomerge, !dbg !128
  store i32 %call5030, ptr %slot553, align 8
  %v5031 = load i64, ptr %slot1, align 8
  %p5032 = inttoptr i64 %v5031 to ptr
  %v5033 = load i32, ptr %slot553, align 8
  %call5034 = call i32 @myl_qbe_rc_status(ptr %p5032, i32 %v5033) nomerge, !dbg !128
  store i32 %call5034, ptr %slot554, align 8
  br label %bb_failure
bb_rcsuccess593:
  br label %bb_rcgdone579
bb_rcgplain579:
  %v5035 = load i64, ptr %slot539, align 8
  %v5036 = load i64, ptr %slot537, align 8
  %p5037 = inttoptr i64 %v5036 to ptr
  store i64 %v5035, ptr %p5037, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone579
bb_rcgdone579:
  %v5038 = load i64, ptr %slot47, align 8
  %p5039 = inttoptr i64 %v5038 to ptr
  store i32 2, ptr %p5039, align 4, !alias.scope !3, !noalias !4
  %v5040 = load i64, ptr %slot46, align 8
  %p5041 = inttoptr i64 %v5040 to ptr
  store i32 1, ptr %p5041, align 4, !alias.scope !3, !noalias !4
  %v5042 = load i64, ptr %slot28, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  %ld5044 = load i32, ptr %p5043, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5044, ptr %slot555, align 8
  %v5045 = load i32, ptr %slot555, align 8
  %cv5046 = zext i32 %v5045 to i64
  %cond5047 = icmp ne i64 %cv5046, 0
  br i1 %cond5047, label %bb_rcslotdrop600, label %bb_rcslotdone600
bb_rcslotdrop600:
  %v5048 = load i64, ptr %slot28, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  store i32 0, ptr %p5049, align 4, !alias.scope !3, !noalias !4
  %v5050 = load i64, ptr %slot49, align 8
  store i64 %v5050, ptr %slot556, align 8
  %v5051 = load i64, ptr %slot29, align 8
  %p5052 = inttoptr i64 %v5051 to ptr
  %ld5053 = load i32, ptr %p5052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5053, ptr %slot557, align 8
  %v5054 = load i32, ptr %slot557, align 8
  %op5055 = and i32 %v5054, 28
  store i32 %op5055, ptr %slot558, align 8
  %v5056 = load i32, ptr %slot558, align 8
  %cv5057 = zext i32 %v5056 to i64
  %cond5058 = icmp ne i64 %cv5057, 0
  br i1 %cond5058, label %bb_rcslotrole600, label %bb_rcslotowner600
bb_rcslotrole600:
  %v5059 = load i64, ptr %slot110, align 8
  store i64 %v5059, ptr %slot559, align 8
  %v5060 = load i64, ptr %slot556, align 8
  %p5061 = inttoptr i64 %v5060 to ptr
  %ld5062 = load i64, ptr %p5061, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5062, ptr %slot560, align 8
  %v5063 = load i64, ptr %slot560, align 8
  %cmp5064 = icmp ne i64 %v5063, 0
  %cv5065 = zext i1 %cmp5064 to i32
  store i32 %cv5065, ptr %slot561, align 8
  %v5066 = load i32, ptr %slot561, align 8
  %cv5067 = zext i32 %v5066 to i64
  %cond5068 = icmp ne i64 %cv5067, 0
  br i1 %cond5068, label %bb_rcgnn616, label %bb_rcgdone616
bb_rcgnn616:
  %v5069 = load i64, ptr %slot560, align 8
  %op5070 = sub i64 %v5069, 16
  store i64 %op5070, ptr %slot562, align 8
  %v5071 = load i64, ptr %slot560, align 8
  %p5072 = inttoptr i64 %v5071 to ptr
  %rgep5073 = getelementptr i8, ptr %p5072, i64 -16
  %ld5074 = load i64, ptr %rgep5073, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5074, ptr %slot563, align 8
  %v5075 = load i64, ptr %slot563, align 8
  %op5076 = and i64 %v5075, 4611686018427387906
  store i64 %op5076, ptr %slot564, align 8
  %v5077 = load i64, ptr %slot564, align 8
  %cmp5078 = icmp ne i64 %v5077, 0
  %cv5079 = zext i1 %cmp5078 to i32
  store i32 %cv5079, ptr %slot565, align 8
  %v5080 = load i32, ptr %slot565, align 8
  %cv5081 = zext i32 %v5080 to i64
  %cond5082 = icmp ne i64 %cv5081, 0
  br i1 %cond5082, label %bb_rcgclear616, label %bb_rcgcounted616
bb_rcgcounted616:
  %v5083 = load i64, ptr %slot560, align 8
  %op5084 = sub i64 %v5083, 24
  store i64 %op5084, ptr %slot566, align 8
  %v5085 = load i64, ptr %slot560, align 8
  %p5086 = inttoptr i64 %v5085 to ptr
  %rgep5087 = getelementptr i8, ptr %p5086, i64 -24
  %ld5088 = load i64, ptr %rgep5087, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5088, ptr %slot567, align 8
  %v5089 = load i64, ptr %slot567, align 8
  %op5090 = sub i64 %v5089, 1
  store i64 %op5090, ptr %slot568, align 8
  %v5091 = load i64, ptr %slot568, align 8
  %cmp5092 = icmp eq i64 %v5091, 0
  %cv5093 = zext i1 %cmp5092 to i32
  store i32 %cv5093, ptr %slot569, align 8
  %v5094 = load i32, ptr %slot569, align 8
  %cv5095 = zext i32 %v5094 to i64
  %cond5096 = icmp ne i64 %cv5095, 0
  br i1 %cond5096, label %bb_rcglast616, label %bb_rcgdec616
bb_rcglast616:
  %v5097 = load i64, ptr %slot560, align 8
  %op5098 = sub i64 %v5097, 32
  store i64 %op5098, ptr %slot570, align 8
  %v5099 = load i64, ptr %slot560, align 8
  %p5100 = inttoptr i64 %v5099 to ptr
  %rgep5101 = getelementptr i8, ptr %p5100, i64 -32
  %ld5102 = load i64, ptr %rgep5101, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5102, ptr %slot571, align 8
  %v5103 = load i64, ptr %slot571, align 8
  %cmp5104 = icmp ne i64 %v5103, 0
  %cv5105 = zext i1 %cmp5104 to i32
  store i32 %cv5105, ptr %slot572, align 8
  %v5106 = load i32, ptr %slot572, align 8
  %cv5107 = zext i32 %v5106 to i64
  %cond5108 = icmp ne i64 %cv5107, 0
  br i1 %cond5108, label %bb_rcgdec616, label %bb_rcgslow616
bb_rcgslow616:
  %v5109 = load i64, ptr %slot559, align 8
  %v5110 = load i64, ptr %slot556, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_unloan(i64 %v5109, i64 %v5110) nomerge, !dbg !128
  br label %bb_rcgdone616
bb_rcgdec616:
  %v5111 = load i64, ptr %slot568, align 8
  %v5112 = load i64, ptr %slot560, align 8
  %p5113 = inttoptr i64 %v5112 to ptr
  %rgep5114 = getelementptr i8, ptr %p5113, i64 -24
  store i64 %v5111, ptr %rgep5114, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear616
bb_rcgclear616:
  %v5115 = load i64, ptr %slot556, align 8
  %p5116 = inttoptr i64 %v5115 to ptr
  store i64 0, ptr %p5116, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone616
bb_rcgdone616:
  br label %bb_rcslotdone600
bb_rcslotowner600:
  %v5117 = load i64, ptr %slot110, align 8
  store i64 %v5117, ptr %slot573, align 8
  %v5118 = load i64, ptr %slot556, align 8
  %p5119 = inttoptr i64 %v5118 to ptr
  %ld5120 = load i64, ptr %p5119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5120, ptr %slot574, align 8
  %v5121 = load i64, ptr %slot574, align 8
  %cmp5122 = icmp ne i64 %v5121, 0
  %cv5123 = zext i1 %cmp5122 to i32
  store i32 %cv5123, ptr %slot575, align 8
  %v5124 = load i32, ptr %slot575, align 8
  %cv5125 = zext i32 %v5124 to i64
  %cond5126 = icmp ne i64 %cv5125, 0
  br i1 %cond5126, label %bb_rcgnn631, label %bb_rcgdone631
bb_rcgnn631:
  %v5127 = load i64, ptr %slot574, align 8
  %op5128 = sub i64 %v5127, 16
  store i64 %op5128, ptr %slot576, align 8
  %v5129 = load i64, ptr %slot574, align 8
  %p5130 = inttoptr i64 %v5129 to ptr
  %rgep5131 = getelementptr i8, ptr %p5130, i64 -16
  %ld5132 = load i64, ptr %rgep5131, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5132, ptr %slot577, align 8
  %v5133 = load i64, ptr %slot577, align 8
  %op5134 = and i64 %v5133, 4611686018427387906
  store i64 %op5134, ptr %slot578, align 8
  %v5135 = load i64, ptr %slot578, align 8
  %cmp5136 = icmp ne i64 %v5135, 0
  %cv5137 = zext i1 %cmp5136 to i32
  store i32 %cv5137, ptr %slot579, align 8
  %v5138 = load i32, ptr %slot579, align 8
  %cv5139 = zext i32 %v5138 to i64
  %cond5140 = icmp ne i64 %cv5139, 0
  br i1 %cond5140, label %bb_rcgclear631, label %bb_rcgcounted631
bb_rcgcounted631:
  %v5141 = load i64, ptr %slot574, align 8
  %op5142 = sub i64 %v5141, 32
  store i64 %op5142, ptr %slot580, align 8
  %v5143 = load i64, ptr %slot574, align 8
  %p5144 = inttoptr i64 %v5143 to ptr
  %rgep5145 = getelementptr i8, ptr %p5144, i64 -32
  %ld5146 = load i64, ptr %rgep5145, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5146, ptr %slot581, align 8
  %v5147 = load i64, ptr %slot581, align 8
  %op5148 = sub i64 %v5147, 1
  store i64 %op5148, ptr %slot582, align 8
  %v5149 = load i64, ptr %slot582, align 8
  %cmp5150 = icmp eq i64 %v5149, 0
  %cv5151 = zext i1 %cmp5150 to i32
  store i32 %cv5151, ptr %slot583, align 8
  %v5152 = load i32, ptr %slot583, align 8
  %cv5153 = zext i32 %v5152 to i64
  %cond5154 = icmp ne i64 %cv5153, 0
  br i1 %cond5154, label %bb_rcglast631, label %bb_rcgdec631
bb_rcglast631:
  %v5155 = load i64, ptr %slot574, align 8
  %op5156 = sub i64 %v5155, 24
  store i64 %op5156, ptr %slot584, align 8
  %v5157 = load i64, ptr %slot574, align 8
  %p5158 = inttoptr i64 %v5157 to ptr
  %rgep5159 = getelementptr i8, ptr %p5158, i64 -24
  %ld5160 = load i64, ptr %rgep5159, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5160, ptr %slot585, align 8
  %v5161 = load i64, ptr %slot585, align 8
  %cmp5162 = icmp ne i64 %v5161, 0
  %cv5163 = zext i1 %cmp5162 to i32
  store i32 %cv5163, ptr %slot586, align 8
  %v5164 = load i32, ptr %slot586, align 8
  %cv5165 = zext i32 %v5164 to i64
  %cond5166 = icmp ne i64 %cv5165, 0
  br i1 %cond5166, label %bb_rcgdec631, label %bb_rcgslow631
bb_rcgslow631:
  %v5167 = load i64, ptr %slot573, align 8
  %v5168 = load i64, ptr %slot556, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_drop(i64 %v5167, i64 %v5168) nomerge, !dbg !128
  br label %bb_rcgdone631
bb_rcgdec631:
  %v5169 = load i64, ptr %slot582, align 8
  %v5170 = load i64, ptr %slot574, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  %rgep5172 = getelementptr i8, ptr %p5171, i64 -32
  store i64 %v5169, ptr %rgep5172, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear631
bb_rcgclear631:
  %v5173 = load i64, ptr %slot556, align 8
  %p5174 = inttoptr i64 %v5173 to ptr
  store i64 0, ptr %p5174, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone631
bb_rcgdone631:
  br label %bb_rcslotdone600
bb_rcslotdone600:
  br label %bb_rcprepared546
bb_rcprepared546:
  %v5175 = load i64, ptr %slot12, align 8
  %p5176 = inttoptr i64 %v5175 to ptr
  %ld5177 = load i32, ptr %p5176, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5177, ptr %slot587, align 8
  %v5178 = load i32, ptr %slot587, align 8
  %cv5179 = zext i32 %v5178 to i64
  %cond5180 = icmp ne i64 %cv5179, 0
  br i1 %cond5180, label %bb_rcslotdrop638, label %bb_rcslotdone638
bb_rcslotdrop638:
  %v5181 = load i64, ptr %slot12, align 8
  %p5182 = inttoptr i64 %v5181 to ptr
  store i32 0, ptr %p5182, align 4, !alias.scope !3, !noalias !4
  %v5183 = load i64, ptr %slot72, align 8
  store i64 %v5183, ptr %slot588, align 8
  %v5184 = load i64, ptr %slot13, align 8
  %p5185 = inttoptr i64 %v5184 to ptr
  %ld5186 = load i32, ptr %p5185, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5186, ptr %slot589, align 8
  %v5187 = load i32, ptr %slot589, align 8
  %op5188 = and i32 %v5187, 28
  store i32 %op5188, ptr %slot590, align 8
  %v5189 = load i32, ptr %slot590, align 8
  %cv5190 = zext i32 %v5189 to i64
  %cond5191 = icmp ne i64 %cv5190, 0
  br i1 %cond5191, label %bb_rcslotrole638, label %bb_rcslotowner638
bb_rcslotrole638:
  %v5192 = load i64, ptr %slot110, align 8
  store i64 %v5192, ptr %slot591, align 8
  %v5193 = load i64, ptr %slot588, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  %ld5195 = load i64, ptr %p5194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5195, ptr %slot592, align 8
  %v5196 = load i64, ptr %slot592, align 8
  %cmp5197 = icmp ne i64 %v5196, 0
  %cv5198 = zext i1 %cmp5197 to i32
  store i32 %cv5198, ptr %slot593, align 8
  %v5199 = load i32, ptr %slot593, align 8
  %cv5200 = zext i32 %v5199 to i64
  %cond5201 = icmp ne i64 %cv5200, 0
  br i1 %cond5201, label %bb_rcgnn654, label %bb_rcgdone654
bb_rcgnn654:
  %v5202 = load i64, ptr %slot592, align 8
  %op5203 = sub i64 %v5202, 16
  store i64 %op5203, ptr %slot594, align 8
  %v5204 = load i64, ptr %slot592, align 8
  %p5205 = inttoptr i64 %v5204 to ptr
  %rgep5206 = getelementptr i8, ptr %p5205, i64 -16
  %ld5207 = load i64, ptr %rgep5206, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5207, ptr %slot595, align 8
  %v5208 = load i64, ptr %slot595, align 8
  %op5209 = and i64 %v5208, 4611686018427387906
  store i64 %op5209, ptr %slot596, align 8
  %v5210 = load i64, ptr %slot596, align 8
  %cmp5211 = icmp ne i64 %v5210, 0
  %cv5212 = zext i1 %cmp5211 to i32
  store i32 %cv5212, ptr %slot597, align 8
  %v5213 = load i32, ptr %slot597, align 8
  %cv5214 = zext i32 %v5213 to i64
  %cond5215 = icmp ne i64 %cv5214, 0
  br i1 %cond5215, label %bb_rcgclear654, label %bb_rcgcounted654
bb_rcgcounted654:
  %v5216 = load i64, ptr %slot592, align 8
  %op5217 = sub i64 %v5216, 24
  store i64 %op5217, ptr %slot598, align 8
  %v5218 = load i64, ptr %slot592, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  %rgep5220 = getelementptr i8, ptr %p5219, i64 -24
  %ld5221 = load i64, ptr %rgep5220, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5221, ptr %slot599, align 8
  %v5222 = load i64, ptr %slot599, align 8
  %op5223 = sub i64 %v5222, 1
  store i64 %op5223, ptr %slot600, align 8
  %v5224 = load i64, ptr %slot600, align 8
  %cmp5225 = icmp eq i64 %v5224, 0
  %cv5226 = zext i1 %cmp5225 to i32
  store i32 %cv5226, ptr %slot601, align 8
  %v5227 = load i32, ptr %slot601, align 8
  %cv5228 = zext i32 %v5227 to i64
  %cond5229 = icmp ne i64 %cv5228, 0
  br i1 %cond5229, label %bb_rcglast654, label %bb_rcgdec654
bb_rcglast654:
  %v5230 = load i64, ptr %slot592, align 8
  %op5231 = sub i64 %v5230, 32
  store i64 %op5231, ptr %slot602, align 8
  %v5232 = load i64, ptr %slot592, align 8
  %p5233 = inttoptr i64 %v5232 to ptr
  %rgep5234 = getelementptr i8, ptr %p5233, i64 -32
  %ld5235 = load i64, ptr %rgep5234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5235, ptr %slot603, align 8
  %v5236 = load i64, ptr %slot603, align 8
  %cmp5237 = icmp ne i64 %v5236, 0
  %cv5238 = zext i1 %cmp5237 to i32
  store i32 %cv5238, ptr %slot604, align 8
  %v5239 = load i32, ptr %slot604, align 8
  %cv5240 = zext i32 %v5239 to i64
  %cond5241 = icmp ne i64 %cv5240, 0
  br i1 %cond5241, label %bb_rcgdec654, label %bb_rcgslow654
bb_rcgslow654:
  %v5242 = load i64, ptr %slot591, align 8
  %v5243 = load i64, ptr %slot588, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_unloan(i64 %v5242, i64 %v5243) nomerge, !dbg !128
  br label %bb_rcgdone654
bb_rcgdec654:
  %v5244 = load i64, ptr %slot600, align 8
  %v5245 = load i64, ptr %slot592, align 8
  %p5246 = inttoptr i64 %v5245 to ptr
  %rgep5247 = getelementptr i8, ptr %p5246, i64 -24
  store i64 %v5244, ptr %rgep5247, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear654
bb_rcgclear654:
  %v5248 = load i64, ptr %slot588, align 8
  %p5249 = inttoptr i64 %v5248 to ptr
  store i64 0, ptr %p5249, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone654
bb_rcgdone654:
  br label %bb_rcslotdone638
bb_rcslotowner638:
  %v5250 = load i64, ptr %slot110, align 8
  store i64 %v5250, ptr %slot605, align 8
  %v5251 = load i64, ptr %slot588, align 8
  %p5252 = inttoptr i64 %v5251 to ptr
  %ld5253 = load i64, ptr %p5252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5253, ptr %slot606, align 8
  %v5254 = load i64, ptr %slot606, align 8
  %cmp5255 = icmp ne i64 %v5254, 0
  %cv5256 = zext i1 %cmp5255 to i32
  store i32 %cv5256, ptr %slot607, align 8
  %v5257 = load i32, ptr %slot607, align 8
  %cv5258 = zext i32 %v5257 to i64
  %cond5259 = icmp ne i64 %cv5258, 0
  br i1 %cond5259, label %bb_rcgnn669, label %bb_rcgdone669
bb_rcgnn669:
  %v5260 = load i64, ptr %slot606, align 8
  %op5261 = sub i64 %v5260, 16
  store i64 %op5261, ptr %slot608, align 8
  %v5262 = load i64, ptr %slot606, align 8
  %p5263 = inttoptr i64 %v5262 to ptr
  %rgep5264 = getelementptr i8, ptr %p5263, i64 -16
  %ld5265 = load i64, ptr %rgep5264, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5265, ptr %slot609, align 8
  %v5266 = load i64, ptr %slot609, align 8
  %op5267 = and i64 %v5266, 4611686018427387906
  store i64 %op5267, ptr %slot610, align 8
  %v5268 = load i64, ptr %slot610, align 8
  %cmp5269 = icmp ne i64 %v5268, 0
  %cv5270 = zext i1 %cmp5269 to i32
  store i32 %cv5270, ptr %slot611, align 8
  %v5271 = load i32, ptr %slot611, align 8
  %cv5272 = zext i32 %v5271 to i64
  %cond5273 = icmp ne i64 %cv5272, 0
  br i1 %cond5273, label %bb_rcgclear669, label %bb_rcgcounted669
bb_rcgcounted669:
  %v5274 = load i64, ptr %slot606, align 8
  %op5275 = sub i64 %v5274, 32
  store i64 %op5275, ptr %slot612, align 8
  %v5276 = load i64, ptr %slot606, align 8
  %p5277 = inttoptr i64 %v5276 to ptr
  %rgep5278 = getelementptr i8, ptr %p5277, i64 -32
  %ld5279 = load i64, ptr %rgep5278, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5279, ptr %slot613, align 8
  %v5280 = load i64, ptr %slot613, align 8
  %op5281 = sub i64 %v5280, 1
  store i64 %op5281, ptr %slot614, align 8
  %v5282 = load i64, ptr %slot614, align 8
  %cmp5283 = icmp eq i64 %v5282, 0
  %cv5284 = zext i1 %cmp5283 to i32
  store i32 %cv5284, ptr %slot615, align 8
  %v5285 = load i32, ptr %slot615, align 8
  %cv5286 = zext i32 %v5285 to i64
  %cond5287 = icmp ne i64 %cv5286, 0
  br i1 %cond5287, label %bb_rcglast669, label %bb_rcgdec669
bb_rcglast669:
  %v5288 = load i64, ptr %slot606, align 8
  %op5289 = sub i64 %v5288, 24
  store i64 %op5289, ptr %slot616, align 8
  %v5290 = load i64, ptr %slot606, align 8
  %p5291 = inttoptr i64 %v5290 to ptr
  %rgep5292 = getelementptr i8, ptr %p5291, i64 -24
  %ld5293 = load i64, ptr %rgep5292, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5293, ptr %slot617, align 8
  %v5294 = load i64, ptr %slot617, align 8
  %cmp5295 = icmp ne i64 %v5294, 0
  %cv5296 = zext i1 %cmp5295 to i32
  store i32 %cv5296, ptr %slot618, align 8
  %v5297 = load i32, ptr %slot618, align 8
  %cv5298 = zext i32 %v5297 to i64
  %cond5299 = icmp ne i64 %cv5298, 0
  br i1 %cond5299, label %bb_rcgdec669, label %bb_rcgslow669
bb_rcgslow669:
  %v5300 = load i64, ptr %slot605, align 8
  %v5301 = load i64, ptr %slot588, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_drop(i64 %v5300, i64 %v5301) nomerge, !dbg !128
  br label %bb_rcgdone669
bb_rcgdec669:
  %v5302 = load i64, ptr %slot614, align 8
  %v5303 = load i64, ptr %slot606, align 8
  %p5304 = inttoptr i64 %v5303 to ptr
  %rgep5305 = getelementptr i8, ptr %p5304, i64 -32
  store i64 %v5302, ptr %rgep5305, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear669
bb_rcgclear669:
  %v5306 = load i64, ptr %slot588, align 8
  %p5307 = inttoptr i64 %v5306 to ptr
  store i64 0, ptr %p5307, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone669
bb_rcgdone669:
  br label %bb_rcslotdone638
bb_rcslotdone638:
  %v5308 = load i64, ptr %slot72, align 8
  store i64 %v5308, ptr %slot619, align 8
  %v5309 = load i64, ptr %slot65, align 8
  store i64 %v5309, ptr %slot620, align 8
  %v5310 = load i64, ptr %slot620, align 8
  %v5311 = load i64, ptr %slot619, align 8
  %p5312 = inttoptr i64 %v5310 to ptr
  %p5313 = inttoptr i64 %v5311 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5313, ptr %p5312, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5314 = load i64, ptr %slot46, align 8
  %p5315 = inttoptr i64 %v5314 to ptr
  store i32 0, ptr %p5315, align 4, !alias.scope !3, !noalias !4
  %v5316 = load i64, ptr %slot13, align 8
  %p5317 = inttoptr i64 %v5316 to ptr
  store i32 2, ptr %p5317, align 4, !alias.scope !3, !noalias !4
  %v5318 = load i64, ptr %slot47, align 8
  %p5319 = inttoptr i64 %v5318 to ptr
  %ld5320 = load i32, ptr %p5319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5320, ptr %slot621, align 8
  %v5321 = load i32, ptr %slot621, align 8
  %v5322 = load i64, ptr %slot13, align 8
  %p5323 = inttoptr i64 %v5322 to ptr
  store i32 %v5321, ptr %p5323, align 4, !alias.scope !3, !noalias !4
  %v5324 = load i64, ptr %slot12, align 8
  %p5325 = inttoptr i64 %v5324 to ptr
  store i32 1, ptr %p5325, align 4, !alias.scope !3, !noalias !4
  %v5326 = load i64, ptr %slot10, align 8
  %p5327 = inttoptr i64 %v5326 to ptr
  %ld5328 = load i32, ptr %p5327, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5328, ptr %slot622, align 8
  %v5329 = load i32, ptr %slot622, align 8
  %cv5330 = zext i32 %v5329 to i64
  %cond5331 = icmp ne i64 %cv5330, 0
  br i1 %cond5331, label %bb_rcslotdrop682, label %bb_rcslotdone682
bb_rcslotdrop682:
  %v5332 = load i64, ptr %slot10, align 8
  %p5333 = inttoptr i64 %v5332 to ptr
  store i32 0, ptr %p5333, align 4, !alias.scope !3, !noalias !4
  %v5334 = load i64, ptr %slot71, align 8
  store i64 %v5334, ptr %slot623, align 8
  %v5335 = load i64, ptr %slot11, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  %ld5337 = load i32, ptr %p5336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5337, ptr %slot624, align 8
  %v5338 = load i32, ptr %slot624, align 8
  %op5339 = and i32 %v5338, 28
  store i32 %op5339, ptr %slot625, align 8
  %v5340 = load i32, ptr %slot625, align 8
  %cv5341 = zext i32 %v5340 to i64
  %cond5342 = icmp ne i64 %cv5341, 0
  br i1 %cond5342, label %bb_rcslotrole682, label %bb_rcslotowner682
bb_rcslotrole682:
  %v5343 = load i64, ptr %slot110, align 8
  store i64 %v5343, ptr %slot626, align 8
  %v5344 = load i64, ptr %slot623, align 8
  %p5345 = inttoptr i64 %v5344 to ptr
  %ld5346 = load i64, ptr %p5345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5346, ptr %slot627, align 8
  %v5347 = load i64, ptr %slot627, align 8
  %cmp5348 = icmp ne i64 %v5347, 0
  %cv5349 = zext i1 %cmp5348 to i32
  store i32 %cv5349, ptr %slot628, align 8
  %v5350 = load i32, ptr %slot628, align 8
  %cv5351 = zext i32 %v5350 to i64
  %cond5352 = icmp ne i64 %cv5351, 0
  br i1 %cond5352, label %bb_rcgnn698, label %bb_rcgdone698
bb_rcgnn698:
  %v5353 = load i64, ptr %slot627, align 8
  %op5354 = sub i64 %v5353, 16
  store i64 %op5354, ptr %slot629, align 8
  %v5355 = load i64, ptr %slot627, align 8
  %p5356 = inttoptr i64 %v5355 to ptr
  %rgep5357 = getelementptr i8, ptr %p5356, i64 -16
  %ld5358 = load i64, ptr %rgep5357, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5358, ptr %slot630, align 8
  %v5359 = load i64, ptr %slot630, align 8
  %op5360 = and i64 %v5359, 4611686018427387906
  store i64 %op5360, ptr %slot631, align 8
  %v5361 = load i64, ptr %slot631, align 8
  %cmp5362 = icmp ne i64 %v5361, 0
  %cv5363 = zext i1 %cmp5362 to i32
  store i32 %cv5363, ptr %slot632, align 8
  %v5364 = load i32, ptr %slot632, align 8
  %cv5365 = zext i32 %v5364 to i64
  %cond5366 = icmp ne i64 %cv5365, 0
  br i1 %cond5366, label %bb_rcgclear698, label %bb_rcgcounted698
bb_rcgcounted698:
  %v5367 = load i64, ptr %slot627, align 8
  %op5368 = sub i64 %v5367, 24
  store i64 %op5368, ptr %slot633, align 8
  %v5369 = load i64, ptr %slot627, align 8
  %p5370 = inttoptr i64 %v5369 to ptr
  %rgep5371 = getelementptr i8, ptr %p5370, i64 -24
  %ld5372 = load i64, ptr %rgep5371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5372, ptr %slot634, align 8
  %v5373 = load i64, ptr %slot634, align 8
  %op5374 = sub i64 %v5373, 1
  store i64 %op5374, ptr %slot635, align 8
  %v5375 = load i64, ptr %slot635, align 8
  %cmp5376 = icmp eq i64 %v5375, 0
  %cv5377 = zext i1 %cmp5376 to i32
  store i32 %cv5377, ptr %slot636, align 8
  %v5378 = load i32, ptr %slot636, align 8
  %cv5379 = zext i32 %v5378 to i64
  %cond5380 = icmp ne i64 %cv5379, 0
  br i1 %cond5380, label %bb_rcglast698, label %bb_rcgdec698
bb_rcglast698:
  %v5381 = load i64, ptr %slot627, align 8
  %op5382 = sub i64 %v5381, 32
  store i64 %op5382, ptr %slot637, align 8
  %v5383 = load i64, ptr %slot627, align 8
  %p5384 = inttoptr i64 %v5383 to ptr
  %rgep5385 = getelementptr i8, ptr %p5384, i64 -32
  %ld5386 = load i64, ptr %rgep5385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5386, ptr %slot638, align 8
  %v5387 = load i64, ptr %slot638, align 8
  %cmp5388 = icmp ne i64 %v5387, 0
  %cv5389 = zext i1 %cmp5388 to i32
  store i32 %cv5389, ptr %slot639, align 8
  %v5390 = load i32, ptr %slot639, align 8
  %cv5391 = zext i32 %v5390 to i64
  %cond5392 = icmp ne i64 %cv5391, 0
  br i1 %cond5392, label %bb_rcgdec698, label %bb_rcgslow698
bb_rcgslow698:
  %v5393 = load i64, ptr %slot626, align 8
  %v5394 = load i64, ptr %slot623, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_unloan(i64 %v5393, i64 %v5394) nomerge, !dbg !128
  br label %bb_rcgdone698
bb_rcgdec698:
  %v5395 = load i64, ptr %slot635, align 8
  %v5396 = load i64, ptr %slot627, align 8
  %p5397 = inttoptr i64 %v5396 to ptr
  %rgep5398 = getelementptr i8, ptr %p5397, i64 -24
  store i64 %v5395, ptr %rgep5398, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear698
bb_rcgclear698:
  %v5399 = load i64, ptr %slot623, align 8
  %p5400 = inttoptr i64 %v5399 to ptr
  store i64 0, ptr %p5400, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone698
bb_rcgdone698:
  br label %bb_rcslotdone682
bb_rcslotowner682:
  %v5401 = load i64, ptr %slot110, align 8
  store i64 %v5401, ptr %slot640, align 8
  %v5402 = load i64, ptr %slot623, align 8
  %p5403 = inttoptr i64 %v5402 to ptr
  %ld5404 = load i64, ptr %p5403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5404, ptr %slot641, align 8
  %v5405 = load i64, ptr %slot641, align 8
  %cmp5406 = icmp ne i64 %v5405, 0
  %cv5407 = zext i1 %cmp5406 to i32
  store i32 %cv5407, ptr %slot642, align 8
  %v5408 = load i32, ptr %slot642, align 8
  %cv5409 = zext i32 %v5408 to i64
  %cond5410 = icmp ne i64 %cv5409, 0
  br i1 %cond5410, label %bb_rcgnn713, label %bb_rcgdone713
bb_rcgnn713:
  %v5411 = load i64, ptr %slot641, align 8
  %op5412 = sub i64 %v5411, 16
  store i64 %op5412, ptr %slot643, align 8
  %v5413 = load i64, ptr %slot641, align 8
  %p5414 = inttoptr i64 %v5413 to ptr
  %rgep5415 = getelementptr i8, ptr %p5414, i64 -16
  %ld5416 = load i64, ptr %rgep5415, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5416, ptr %slot644, align 8
  %v5417 = load i64, ptr %slot644, align 8
  %op5418 = and i64 %v5417, 4611686018427387906
  store i64 %op5418, ptr %slot645, align 8
  %v5419 = load i64, ptr %slot645, align 8
  %cmp5420 = icmp ne i64 %v5419, 0
  %cv5421 = zext i1 %cmp5420 to i32
  store i32 %cv5421, ptr %slot646, align 8
  %v5422 = load i32, ptr %slot646, align 8
  %cv5423 = zext i32 %v5422 to i64
  %cond5424 = icmp ne i64 %cv5423, 0
  br i1 %cond5424, label %bb_rcgclear713, label %bb_rcgcounted713
bb_rcgcounted713:
  %v5425 = load i64, ptr %slot641, align 8
  %op5426 = sub i64 %v5425, 32
  store i64 %op5426, ptr %slot647, align 8
  %v5427 = load i64, ptr %slot641, align 8
  %p5428 = inttoptr i64 %v5427 to ptr
  %rgep5429 = getelementptr i8, ptr %p5428, i64 -32
  %ld5430 = load i64, ptr %rgep5429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5430, ptr %slot648, align 8
  %v5431 = load i64, ptr %slot648, align 8
  %op5432 = sub i64 %v5431, 1
  store i64 %op5432, ptr %slot649, align 8
  %v5433 = load i64, ptr %slot649, align 8
  %cmp5434 = icmp eq i64 %v5433, 0
  %cv5435 = zext i1 %cmp5434 to i32
  store i32 %cv5435, ptr %slot650, align 8
  %v5436 = load i32, ptr %slot650, align 8
  %cv5437 = zext i32 %v5436 to i64
  %cond5438 = icmp ne i64 %cv5437, 0
  br i1 %cond5438, label %bb_rcglast713, label %bb_rcgdec713
bb_rcglast713:
  %v5439 = load i64, ptr %slot641, align 8
  %op5440 = sub i64 %v5439, 24
  store i64 %op5440, ptr %slot651, align 8
  %v5441 = load i64, ptr %slot641, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  %rgep5443 = getelementptr i8, ptr %p5442, i64 -24
  %ld5444 = load i64, ptr %rgep5443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5444, ptr %slot652, align 8
  %v5445 = load i64, ptr %slot652, align 8
  %cmp5446 = icmp ne i64 %v5445, 0
  %cv5447 = zext i1 %cmp5446 to i32
  store i32 %cv5447, ptr %slot653, align 8
  %v5448 = load i32, ptr %slot653, align 8
  %cv5449 = zext i32 %v5448 to i64
  %cond5450 = icmp ne i64 %cv5449, 0
  br i1 %cond5450, label %bb_rcgdec713, label %bb_rcgslow713
bb_rcgslow713:
  %v5451 = load i64, ptr %slot640, align 8
  %v5452 = load i64, ptr %slot623, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_drop(i64 %v5451, i64 %v5452) nomerge, !dbg !128
  br label %bb_rcgdone713
bb_rcgdec713:
  %v5453 = load i64, ptr %slot649, align 8
  %v5454 = load i64, ptr %slot641, align 8
  %p5455 = inttoptr i64 %v5454 to ptr
  %rgep5456 = getelementptr i8, ptr %p5455, i64 -32
  store i64 %v5453, ptr %rgep5456, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear713
bb_rcgclear713:
  %v5457 = load i64, ptr %slot623, align 8
  %p5458 = inttoptr i64 %v5457 to ptr
  store i64 0, ptr %p5458, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone713
bb_rcgdone713:
  br label %bb_rcslotdone682
bb_rcslotdone682:
  %v5459 = load i64, ptr %slot80, align 8
  %p5460 = inttoptr i64 %v5459 to ptr
  store i64 0, ptr %p5460, align 8, !alias.scope !3, !noalias !4
  %v5461 = load i64, ptr %slot80, align 8
  %p5462 = inttoptr i64 %v5461 to ptr
  %ld5463 = load i64, ptr %p5462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5463, ptr %slot654, align 8
  %v5464 = load i64, ptr %slot654, align 8
  %v5465 = load i64, ptr %slot70, align 8
  %p5466 = inttoptr i64 %v5465 to ptr
  store i64 %v5464, ptr %p5466, align 8, !alias.scope !3, !noalias !4
  br label %bb_ce28
bb_ce28:
  %v5467 = load i64, ptr %slot72, align 8
  store i64 %v5467, ptr %slot655, align 8
  %v5468 = load i64, ptr %slot13, align 8
  %p5469 = inttoptr i64 %v5468 to ptr
  store i32 2, ptr %p5469, align 4, !alias.scope !3, !noalias !4
  %v5470 = load i64, ptr %slot655, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  %ld5472 = load i64, ptr %p5471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5472, ptr %slot656, align 8
  %v5473 = load i64, ptr %slot656, align 8
  %cmp5474 = icmp ne i64 %v5473, 0
  %cv5475 = zext i1 %cmp5474 to i32
  store i32 %cv5475, ptr %slot657, align 8
  %v5476 = load i32, ptr %slot657, align 8
  %cv5477 = zext i32 %v5476 to i64
  %cond5478 = icmp ne i64 %cv5477, 0
  br i1 %cond5478, label %bb_rcguniquenn721, label %bb_rcgunique721
bb_rcguniquenn721:
  %v5479 = load i64, ptr %slot656, align 8
  %op5480 = sub i64 %v5479, 16
  store i64 %op5480, ptr %slot658, align 8
  %v5481 = load i64, ptr %slot656, align 8
  %p5482 = inttoptr i64 %v5481 to ptr
  %rgep5483 = getelementptr i8, ptr %p5482, i64 -16
  %ld5484 = load i64, ptr %rgep5483, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5484, ptr %slot659, align 8
  %v5485 = load i64, ptr %slot659, align 8
  %op5486 = and i64 %v5485, 6917529027641081858
  store i64 %op5486, ptr %slot660, align 8
  %v5487 = load i64, ptr %slot660, align 8
  %cmp5488 = icmp ne i64 %v5487, 0
  %cv5489 = zext i1 %cmp5488 to i32
  store i32 %cv5489, ptr %slot661, align 8
  %v5490 = load i32, ptr %slot661, align 8
  %cv5491 = zext i32 %v5490 to i64
  %cond5492 = icmp ne i64 %cv5491, 0
  br i1 %cond5492, label %bb_rcguniqueslow721, label %bb_rcguniquecount721
bb_rcguniquecount721:
  %v5493 = load i64, ptr %slot656, align 8
  %op5494 = sub i64 %v5493, 32
  store i64 %op5494, ptr %slot662, align 8
  %v5495 = load i64, ptr %slot656, align 8
  %p5496 = inttoptr i64 %v5495 to ptr
  %rgep5497 = getelementptr i8, ptr %p5496, i64 -32
  %ld5498 = load i64, ptr %rgep5497, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5498, ptr %slot663, align 8
  %v5499 = load i64, ptr %slot663, align 8
  %cmp5500 = icmp ult i64 %v5499, 2
  %cv5501 = zext i1 %cmp5500 to i32
  store i32 %cv5501, ptr %slot664, align 8
  %v5502 = load i32, ptr %slot664, align 8
  %cv5503 = zext i32 %v5502 to i64
  %cond5504 = icmp ne i64 %cv5503, 0
  br i1 %cond5504, label %bb_rcgunique721, label %bb_rcguniqueslow721
bb_rcguniqueslow721:
  %v5505 = load i64, ptr %slot1, align 8
  %p5506 = inttoptr i64 %v5505 to ptr
  %p5507 = inttoptr i64 ptrtoint (ptr @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0 to i64) to ptr
  %v5508 = load i64, ptr %slot655, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  %v5510 = load i64, ptr %slot12, align 8
  %p5511 = inttoptr i64 %v5510 to ptr
  %call5512 = call i32 @myl_qbe_rc_unique_local(ptr %p5506, ptr %p5507, ptr %p5509, ptr %p5511) nomerge, !dbg !130
  store i32 %call5512, ptr %slot665, align 8
  %v5513 = load i32, ptr %slot665, align 8
  %cv5514 = zext i32 %v5513 to i64
  %cond5515 = icmp ne i64 %cv5514, 0
  br i1 %cond5515, label %bb_rcunique732, label %bb_failure
bb_rcunique732:
  br label %bb_rcgunique721
bb_rcgunique721:
  br label %bb_i28
bb_i28:
  %v5516 = load i64, ptr %slot70, align 8
  %p5517 = inttoptr i64 %v5516 to ptr
  %ld5518 = load i64, ptr %p5517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5518, ptr %slot666, align 8
  %v5519 = load i64, ptr %slot666, align 8
  %v5520 = load i64, ptr %slot80, align 8
  %p5521 = inttoptr i64 %v5520 to ptr
  store i64 %v5519, ptr %p5521, align 8, !alias.scope !3, !noalias !4
  %v5522 = load i64, ptr %slot81, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  store i64 64, ptr %p5523, align 8, !alias.scope !3, !noalias !4
  %v5524 = load i64, ptr %slot81, align 8
  %p5525 = inttoptr i64 %v5524 to ptr
  %ld5526 = load i64, ptr %p5525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5526, ptr %slot667, align 8
  %v5527 = load i64, ptr %slot80, align 8
  %p5528 = inttoptr i64 %v5527 to ptr
  %ld5529 = load i64, ptr %p5528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5529, ptr %slot668, align 8
  %v5530 = load i64, ptr %slot668, align 8
  %v5531 = load i64, ptr %slot667, align 8
  %cmp5532 = icmp slt i64 %v5530, %v5531
  %cv5533 = zext i1 %cmp5532 to i64
  store i64 %cv5533, ptr %slot669, align 8
  %v5534 = load i64, ptr %slot669, align 8
  %v5535 = load i64, ptr %slot80, align 8
  %p5536 = inttoptr i64 %v5535 to ptr
  store i64 %v5534, ptr %p5536, align 8, !alias.scope !3, !noalias !4
  %v5537 = load i64, ptr %slot80, align 8
  %p5538 = inttoptr i64 %v5537 to ptr
  %ld5539 = load i64, ptr %p5538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5539, ptr %slot670, align 8
  %v5540 = load i64, ptr %slot670, align 8
  %cond5541 = icmp ne i64 %v5540, 0
  br i1 %cond5541, label %bb_next738, label %bb_i43
bb_next738:
  %v5542 = load i64, ptr %slot80, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  store i64 18446744073709551615, ptr %p5543, align 8, !alias.scope !3, !noalias !4
  %v5544 = load i64, ptr %slot81, align 8
  %p5545 = inttoptr i64 %v5544 to ptr
  store i64 0, ptr %p5545, align 8, !alias.scope !3, !noalias !4
  %v5546 = load i64, ptr %slot82, align 8
  %p5547 = inttoptr i64 %v5546 to ptr
  store i64 0, ptr %p5547, align 8, !alias.scope !3, !noalias !4
  %v5548 = load i64, ptr %slot103, align 8
  store i64 %v5548, ptr %slot671, align 8
  %v5549 = load i64, ptr %slot111, align 8
  store i64 %v5549, ptr %slot672, align 8
  %v5550 = load i64, ptr %slot80, align 8
  store i64 %v5550, ptr %slot673, align 8
  %v5551 = load i64, ptr %slot671, align 8
  %p5553 = inttoptr i64 %v5551 to ptr
  %gep5554 = getelementptr i8, ptr %p5553, i64 0
  %op5552 = ptrtoint ptr %gep5554 to i64
  store i64 %op5552, ptr %slot674, align 8
  %v5555 = load i64, ptr %slot673, align 8
  %p5556 = inttoptr i64 %v5555 to ptr
  %ld5557 = load i64, ptr %p5556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5557, ptr %slot675, align 8
  %v5558 = load i64, ptr %slot675, align 8
  %v5559 = load i64, ptr %slot674, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  store i64 %v5558, ptr %p5560, align 8, !alias.scope !3, !noalias !4
  %v5561 = load i64, ptr %slot81, align 8
  store i64 %v5561, ptr %slot676, align 8
  %v5562 = load i64, ptr %slot671, align 8
  %p5564 = inttoptr i64 %v5562 to ptr
  %gep5565 = getelementptr i8, ptr %p5564, i64 8
  %op5563 = ptrtoint ptr %gep5565 to i64
  store i64 %op5563, ptr %slot677, align 8
  %v5566 = load i64, ptr %slot676, align 8
  %p5567 = inttoptr i64 %v5566 to ptr
  %ld5568 = load i64, ptr %p5567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5568, ptr %slot678, align 8
  %v5569 = load i64, ptr %slot678, align 8
  %v5570 = load i64, ptr %slot677, align 8
  %p5571 = inttoptr i64 %v5570 to ptr
  store i64 %v5569, ptr %p5571, align 8, !alias.scope !3, !noalias !4
  %v5572 = load i64, ptr %slot82, align 8
  store i64 %v5572, ptr %slot679, align 8
  %v5573 = load i64, ptr %slot671, align 8
  %p5575 = inttoptr i64 %v5573 to ptr
  %gep5576 = getelementptr i8, ptr %p5575, i64 16
  %op5574 = ptrtoint ptr %gep5576 to i64
  store i64 %op5574, ptr %slot680, align 8
  %v5577 = load i64, ptr %slot679, align 8
  %p5578 = inttoptr i64 %v5577 to ptr
  %ld5579 = load i64, ptr %p5578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5579, ptr %slot681, align 8
  %v5580 = load i64, ptr %slot681, align 8
  %v5581 = load i64, ptr %slot680, align 8
  %p5582 = inttoptr i64 %v5581 to ptr
  store i64 %v5580, ptr %p5582, align 8, !alias.scope !3, !noalias !4
  %v5583 = load i64, ptr %slot671, align 8
  %v5584 = load i64, ptr %slot80, align 8
  %p5585 = inttoptr i64 %v5584 to ptr
  store i64 %v5583, ptr %p5585, align 8, !alias.scope !3, !noalias !4
  %v5586 = load i64, ptr %slot72, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %ld5588 = load i64, ptr %p5587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5588, ptr %slot682, align 8
  %v5589 = load i64, ptr %slot80, align 8
  %p5590 = inttoptr i64 %v5589 to ptr
  %ld5591 = load i64, ptr %p5590, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5591, ptr %slot683, align 8
  %v5592 = load i64, ptr %slot110, align 8
  %v5593 = load i64, ptr %slot682, align 8
  %v5594 = load i64, ptr %slot683, align 8
  %call5595 = call i32 @myl_t_135c20434b3e567dc9f56890b2e744a3921cd3f40404c14f8a6e8ab4481a5802_rcg_list_append(i64 %v5592, i64 %v5593, i64 %v5594) nomerge, !dbg !132
  store i32 %call5595, ptr %slot684, align 8
  %v5596 = load i32, ptr %slot684, align 8
  %cv5597 = zext i32 %v5596 to i64
  %cond5598 = icmp ne i64 %cv5597, 0
  br i1 %cond5598, label %bb_success752, label %bb_failed752
bb_failed752:
  %v5599 = load i64, ptr %slot1, align 8
  %p5600 = inttoptr i64 %v5599 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5600) nomerge, !dbg !132
  unreachable
bb_success752:
  %v5601 = load i64, ptr %slot80, align 8
  %p5602 = inttoptr i64 %v5601 to ptr
  store i64 0, ptr %p5602, align 8, !alias.scope !3, !noalias !4
  %v5603 = load i64, ptr %slot70, align 8
  %p5604 = inttoptr i64 %v5603 to ptr
  %ld5605 = load i64, ptr %p5604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5605, ptr %slot685, align 8
  %v5606 = load i64, ptr %slot685, align 8
  %v5607 = load i64, ptr %slot80, align 8
  %p5608 = inttoptr i64 %v5607 to ptr
  store i64 %v5606, ptr %p5608, align 8, !alias.scope !3, !noalias !4
  %v5609 = load i64, ptr %slot81, align 8
  %p5610 = inttoptr i64 %v5609 to ptr
  store i64 1, ptr %p5610, align 8, !alias.scope !3, !noalias !4
  %v5611 = load i64, ptr %slot81, align 8
  %p5612 = inttoptr i64 %v5611 to ptr
  %ld5613 = load i64, ptr %p5612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5613, ptr %slot686, align 8
  %v5614 = load i64, ptr %slot80, align 8
  %p5615 = inttoptr i64 %v5614 to ptr
  %ld5616 = load i64, ptr %p5615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5616, ptr %slot687, align 8
  %v5617 = load i64, ptr %slot687, align 8
  %v5618 = load i64, ptr %slot686, align 8
  %ovpair5620 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5617, i64 %v5618)
  %op5619 = extractvalue { i64, i1 } %ovpair5620, 0
  %ov5621 = extractvalue { i64, i1 } %ovpair5620, 1
  store i64 %op5619, ptr %slot688, align 8
  %cv5622 = zext i1 %ov5621 to i64
  store i64 %cv5622, ptr %slot689, align 8
  %v5623 = load i64, ptr %slot689, align 8
  %cond5624 = icmp ne i64 %v5623, 0
  br i1 %cond5624, label %bb_overflow756, label %bb_checked756
bb_overflow756:
  %v5625 = load i64, ptr %slot1, align 8
  %p5626 = inttoptr i64 %v5625 to ptr
  %v5627 = load i64, ptr %slot687, align 8
  %v5628 = load i64, ptr %slot686, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5626, i64 0, i64 %v5627, i64 %v5628, i64 64) nomerge, !dbg !134
  unreachable
bb_checked756:
  %v5629 = load i64, ptr %slot688, align 8
  %v5630 = load i64, ptr %slot80, align 8
  %p5631 = inttoptr i64 %v5630 to ptr
  store i64 %v5629, ptr %p5631, align 8, !alias.scope !3, !noalias !4
  %v5632 = load i64, ptr %slot80, align 8
  %p5633 = inttoptr i64 %v5632 to ptr
  %ld5634 = load i64, ptr %p5633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5634, ptr %slot690, align 8
  %v5635 = load i64, ptr %slot690, align 8
  %v5636 = load i64, ptr %slot70, align 8
  %p5637 = inttoptr i64 %v5636 to ptr
  store i64 %v5635, ptr %p5637, align 8, !alias.scope !3, !noalias !4
  br label %bb_i28
bb_i43:
  %v5638 = load i64, ptr %slot80, align 8
  %p5639 = inttoptr i64 %v5638 to ptr
  store i64 0, ptr %p5639, align 8, !alias.scope !3, !noalias !4
  %v5640 = load i64, ptr %slot80, align 8
  %p5641 = inttoptr i64 %v5640 to ptr
  %ld5642 = load i64, ptr %p5641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5642, ptr %slot691, align 8
  %v5643 = load i64, ptr %slot691, align 8
  %cmp5644 = icmp sge i64 %v5643, 0
  %cv5645 = zext i1 %cmp5644 to i64
  store i64 %cv5645, ptr %slot692, align 8
  %v5646 = load i64, ptr %slot692, align 8
  %cond5647 = icmp ne i64 %v5646, 0
  br i1 %cond5647, label %bb_success761, label %bb_failed761
bb_failed761:
  %v5648 = load i64, ptr %slot1, align 8
  %p5649 = inttoptr i64 %v5648 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p5649) nomerge, !dbg !136
  unreachable
bb_success761:
  %v5650 = load i64, ptr %slot110, align 8
  %p5651 = inttoptr i64 %v5650 to ptr
  %p5652 = inttoptr i64 ptrtoint (ptr @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14 to i64) to ptr
  %v5653 = load i64, ptr %slot691, align 8
  %call5654 = call ptr @myl_native_list_new(ptr %p5651, ptr %p5652, i64 %v5653) nomerge, !dbg !136
  %calladdr5655 = ptrtoint ptr %call5654 to i64
  store i64 %calladdr5655, ptr %slot693, align 8
  %v5656 = load i64, ptr %slot693, align 8
  %cond5657 = icmp ne i64 %v5656, 0
  br i1 %cond5657, label %bb_success763, label %bb_failed763
bb_failed763:
  %v5658 = load i64, ptr %slot1, align 8
  %p5659 = inttoptr i64 %v5658 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5659) nomerge, !dbg !136
  unreachable
bb_success763:
  %v5660 = load i64, ptr %slot693, align 8
  %v5661 = load i64, ptr %slot80, align 8
  %p5662 = inttoptr i64 %v5661 to ptr
  store i64 %v5660, ptr %p5662, align 8, !alias.scope !3, !noalias !4
  %v5663 = load i64, ptr %slot80, align 8
  %p5664 = inttoptr i64 %v5663 to ptr
  %ld5665 = load i64, ptr %p5664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5665, ptr %slot694, align 8
  %v5666 = load i64, ptr %slot694, align 8
  %v5667 = load i64, ptr %slot57, align 8
  %p5668 = inttoptr i64 %v5667 to ptr
  store i64 %v5666, ptr %p5668, align 8, !alias.scope !3, !noalias !4
  %v5669 = load i64, ptr %slot57, align 8
  store i64 %v5669, ptr %slot695, align 8
  %v5670 = load i64, ptr %slot65, align 8
  store i64 %v5670, ptr %slot696, align 8
  %v5671 = load i64, ptr %slot695, align 8
  %v5672 = load i64, ptr %slot696, align 8
  %p5673 = inttoptr i64 %v5671 to ptr
  %p5674 = inttoptr i64 %v5672 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5674, ptr %p5673, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5675 = load i64, ptr %slot47, align 8
  %p5676 = inttoptr i64 %v5675 to ptr
  store i32 2, ptr %p5676, align 4, !alias.scope !3, !noalias !4
  %v5677 = load i64, ptr %slot46, align 8
  %p5678 = inttoptr i64 %v5677 to ptr
  store i32 1, ptr %p5678, align 4, !alias.scope !3, !noalias !4
  %v5679 = load i64, ptr %slot49, align 8
  store i64 %v5679, ptr %slot697, align 8
  %v5680 = load i64, ptr %slot65, align 8
  store i64 %v5680, ptr %slot698, align 8
  %v5681 = load i64, ptr %slot698, align 8
  %v5682 = load i64, ptr %slot697, align 8
  %p5683 = inttoptr i64 %v5681 to ptr
  %p5684 = inttoptr i64 %v5682 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5684, ptr %p5683, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5685 = load i64, ptr %slot29, align 8
  %p5686 = inttoptr i64 %v5685 to ptr
  store i32 2, ptr %p5686, align 4, !alias.scope !3, !noalias !4
  %v5687 = load i64, ptr %slot47, align 8
  %p5688 = inttoptr i64 %v5687 to ptr
  %ld5689 = load i32, ptr %p5688, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5689, ptr %slot699, align 8
  %v5690 = load i32, ptr %slot699, align 8
  %v5691 = load i64, ptr %slot29, align 8
  %p5692 = inttoptr i64 %v5691 to ptr
  store i32 %v5690, ptr %p5692, align 4, !alias.scope !3, !noalias !4
  %v5693 = load i64, ptr %slot46, align 8
  %p5694 = inttoptr i64 %v5693 to ptr
  store i32 0, ptr %p5694, align 4, !alias.scope !3, !noalias !4
  %v5695 = load i64, ptr %slot28, align 8
  %p5696 = inttoptr i64 %v5695 to ptr
  store i32 1, ptr %p5696, align 4, !alias.scope !3, !noalias !4
  %v5697 = load i64, ptr %slot697, align 8
  %p5698 = inttoptr i64 %v5697 to ptr
  %ld5699 = load i64, ptr %p5698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5699, ptr %slot700, align 8
  %v5700 = load i64, ptr %slot700, align 8
  %v5701 = load i64, ptr %slot80, align 8
  %p5702 = inttoptr i64 %v5701 to ptr
  store i64 %v5700, ptr %p5702, align 8, !alias.scope !3, !noalias !4
  %v5703 = load i64, ptr %slot80, align 8
  %p5704 = inttoptr i64 %v5703 to ptr
  %ld5705 = load i64, ptr %p5704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5705, ptr %slot701, align 8
  %v5706 = load i64, ptr %slot701, align 8
  %v5707 = load i64, ptr %slot57, align 8
  %p5708 = inttoptr i64 %v5707 to ptr
  store i64 %v5706, ptr %p5708, align 8, !alias.scope !3, !noalias !4
  %v5709 = load i64, ptr %slot57, align 8
  store i64 %v5709, ptr %slot702, align 8
  %v5710 = load i64, ptr %slot28, align 8
  %p5711 = inttoptr i64 %v5710 to ptr
  %ld5712 = load i32, ptr %p5711, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5712, ptr %slot703, align 8
  %v5713 = load i64, ptr %slot29, align 8
  %p5714 = inttoptr i64 %v5713 to ptr
  %ld5715 = load i32, ptr %p5714, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5715, ptr %slot704, align 8
  %v5716 = load i32, ptr %slot704, align 8
  %op5717 = and i32 %v5716, 24
  store i32 %op5717, ptr %slot704, align 8
  %v5718 = load i32, ptr %slot704, align 8
  %cmp5719 = icmp eq i32 %v5718, 0
  %cv5720 = zext i1 %cmp5719 to i32
  store i32 %cv5720, ptr %slot705, align 8
  %v5721 = load i32, ptr %slot703, align 8
  %v5722 = load i32, ptr %slot705, align 8
  %op5723 = and i32 %v5721, %v5722
  store i32 %op5723, ptr %slot706, align 8
  %v5724 = load i32, ptr %slot706, align 8
  %cv5725 = zext i32 %v5724 to i64
  %cond5726 = icmp ne i64 %cv5725, 0
  br i1 %cond5726, label %bb_rcprivateown786, label %bb_rcprivateloan786
bb_rcprivateown786:
  %v5727 = load i64, ptr %slot65, align 8
  store i64 %v5727, ptr %slot707, align 8
  %v5728 = load i64, ptr %slot111, align 8
  store i64 %v5728, ptr %slot708, align 8
  %v5729 = load i64, ptr %slot702, align 8
  %v5730 = load i64, ptr %slot707, align 8
  %op5731 = sub i64 %v5729, %v5730
  store i64 %op5731, ptr %slot709, align 8
  %v5732 = load i64, ptr %slot707, align 8
  %v5733 = load i64, ptr %slot702, align 8
  %op5734 = sub i64 %v5732, %v5733
  store i64 %op5734, ptr %slot710, align 8
  %v5735 = load i64, ptr %slot709, align 8
  %cmp5736 = icmp ult i64 %v5735, 8
  %cv5737 = zext i1 %cmp5736 to i32
  store i32 %cv5737, ptr %slot711, align 8
  %v5738 = load i64, ptr %slot710, align 8
  %cmp5739 = icmp ult i64 %v5738, 8
  %cv5740 = zext i1 %cmp5739 to i32
  store i32 %cv5740, ptr %slot712, align 8
  %v5741 = load i32, ptr %slot711, align 8
  %v5742 = load i32, ptr %slot712, align 8
  %op5743 = or i32 %v5741, %v5742
  store i32 %op5743, ptr %slot713, align 8
  %v5744 = load i32, ptr %slot713, align 8
  %cv5745 = zext i32 %v5744 to i64
  %cond5746 = icmp ne i64 %cv5745, 0
  br i1 %cond5746, label %bb_rcmoveslow789, label %bb_rcmovecheck789
bb_rcmovecheck789:
  %v5747 = load i64, ptr %slot702, align 8
  %p5749 = inttoptr i64 %v5747 to ptr
  %gep5750 = getelementptr i8, ptr %p5749, i64 0
  %op5748 = ptrtoint ptr %gep5750 to i64
  store i64 %op5748, ptr %slot714, align 8
  %v5751 = load i64, ptr %slot714, align 8
  %p5752 = inttoptr i64 %v5751 to ptr
  %ld5753 = load i64, ptr %p5752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5753, ptr %slot715, align 8
  %v5754 = load i64, ptr %slot715, align 8
  %cmp5755 = icmp ne i64 %v5754, 0
  %cv5756 = zext i1 %cmp5755 to i32
  store i32 %cv5756, ptr %slot716, align 8
  %v5757 = load i32, ptr %slot716, align 8
  %cv5758 = zext i32 %v5757 to i64
  %cond5759 = icmp ne i64 %cv5758, 0
  br i1 %cond5759, label %bb_rcmoveheader797, label %bb_rcmovenext797
bb_rcmoveheader797:
  %v5760 = load i64, ptr %slot715, align 8
  %op5761 = sub i64 %v5760, 16
  store i64 %op5761, ptr %slot717, align 8
  %v5762 = load i64, ptr %slot715, align 8
  %p5763 = inttoptr i64 %v5762 to ptr
  %rgep5764 = getelementptr i8, ptr %p5763, i64 -16
  %ld5765 = load i64, ptr %rgep5764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5765, ptr %slot718, align 8
  %v5766 = load i64, ptr %slot718, align 8
  %op5767 = and i64 %v5766, 5764607523034234881
  store i64 %op5767, ptr %slot719, align 8
  %v5768 = load i64, ptr %slot719, align 8
  %cmp5769 = icmp ne i64 %v5768, 0
  %cv5770 = zext i1 %cmp5769 to i32
  store i32 %cv5770, ptr %slot720, align 8
  %v5771 = load i32, ptr %slot720, align 8
  %cv5772 = zext i32 %v5771 to i64
  %cond5773 = icmp ne i64 %cv5772, 0
  br i1 %cond5773, label %bb_rcmoveslow789, label %bb_rcmovenext797
bb_rcmovenext797:
  %v5774 = load i64, ptr %slot702, align 8
  %v5775 = load i64, ptr %slot707, align 8
  %p5776 = inttoptr i64 %v5774 to ptr
  %p5777 = inttoptr i64 %v5775 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5777, ptr %p5776, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5778 = load i64, ptr %slot702, align 8
  %p5779 = inttoptr i64 %v5778 to ptr
  store i64 0, ptr %p5779, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved789
bb_rcmoveslow789:
  %v5780 = load i64, ptr %slot110, align 8
  %v5781 = load i64, ptr %slot707, align 8
  %v5782 = load i64, ptr %slot702, align 8
  %v5783 = load i64, ptr %slot708, align 8
  %cv5784 = trunc i64 %v5783 to i32
  %call5785 = call i32 @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_take(i64 %v5780, i64 %v5781, i64 %v5782, i32 %cv5784) nomerge, !dbg !138
  store i32 %call5785, ptr %slot721, align 8
  %v5786 = load i32, ptr %slot721, align 8
  %cv5787 = zext i32 %v5786 to i64
  %cond5788 = icmp ne i64 %cv5787, 0
  br i1 %cond5788, label %bb_rcsuccess804, label %bb_rcfailure804
bb_rcfailure804:
  %v5789 = load i64, ptr %slot110, align 8
  %p5790 = inttoptr i64 %v5789 to ptr
  %call5791 = call i32 @myl_rc_take_failure(ptr %p5790) nomerge, !dbg !138
  store i32 %call5791, ptr %slot722, align 8
  %v5792 = load i64, ptr %slot1, align 8
  %p5793 = inttoptr i64 %v5792 to ptr
  %v5794 = load i32, ptr %slot722, align 8
  %call5795 = call i32 @myl_qbe_rc_status(ptr %p5793, i32 %v5794) nomerge, !dbg !138
  store i32 %call5795, ptr %slot723, align 8
  br label %bb_failure
bb_rcsuccess804:
  br label %bb_rcmoved789
bb_rcmoved789:
  %v5796 = load i64, ptr %slot28, align 8
  %p5797 = inttoptr i64 %v5796 to ptr
  store i32 0, ptr %p5797, align 4, !alias.scope !3, !noalias !4
  %v5798 = load i64, ptr %slot47, align 8
  %p5799 = inttoptr i64 %v5798 to ptr
  store i32 2, ptr %p5799, align 4, !alias.scope !3, !noalias !4
  %v5800 = load i64, ptr %slot46, align 8
  %p5801 = inttoptr i64 %v5800 to ptr
  store i32 1, ptr %p5801, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared786
bb_rcprivateloan786:
  %v5802 = load i64, ptr %slot28, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  %ld5804 = load i32, ptr %p5803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5804, ptr %slot724, align 8
  %v5805 = load i64, ptr %slot29, align 8
  %p5806 = inttoptr i64 %v5805 to ptr
  %ld5807 = load i32, ptr %p5806, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5807, ptr %slot725, align 8
  %v5808 = load i32, ptr %slot725, align 8
  %cmp5809 = icmp eq i32 %v5808, 16
  %cv5810 = zext i1 %cmp5809 to i32
  store i32 %cv5810, ptr %slot726, align 8
  %v5811 = load i32, ptr %slot726, align 8
  %v5812 = load i32, ptr %slot724, align 8
  %op5813 = and i32 %v5811, %v5812
  store i32 %op5813, ptr %slot726, align 8
  %v5814 = load i32, ptr %slot726, align 8
  %cv5815 = zext i32 %v5814 to i64
  %cond5816 = icmp ne i64 %cv5815, 0
  br i1 %cond5816, label %bb_rcprivatemove786, label %bb_rcprivatenew786
bb_rcprivatemove786:
  %v5817 = load i64, ptr %slot65, align 8
  store i64 %v5817, ptr %slot727, align 8
  %v5818 = load i64, ptr %slot702, align 8
  %v5819 = load i64, ptr %slot727, align 8
  %p5820 = inttoptr i64 %v5818 to ptr
  %p5821 = inttoptr i64 %v5819 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5821, ptr %p5820, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5822 = load i64, ptr %slot702, align 8
  %p5823 = inttoptr i64 %v5822 to ptr
  store i64 0, ptr %p5823, align 8, !alias.scope !3, !noalias !4
  %v5824 = load i64, ptr %slot47, align 8
  %p5825 = inttoptr i64 %v5824 to ptr
  store i32 2, ptr %p5825, align 4, !alias.scope !3, !noalias !4
  %v5826 = load i64, ptr %slot47, align 8
  %p5827 = inttoptr i64 %v5826 to ptr
  store i32 16, ptr %p5827, align 4, !alias.scope !3, !noalias !4
  %v5828 = load i64, ptr %slot46, align 8
  %p5829 = inttoptr i64 %v5828 to ptr
  store i32 1, ptr %p5829, align 4, !alias.scope !3, !noalias !4
  %v5830 = load i64, ptr %slot28, align 8
  %p5831 = inttoptr i64 %v5830 to ptr
  store i32 0, ptr %p5831, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared786
bb_rcprivatenew786:
  %v5832 = load i64, ptr %slot65, align 8
  store i64 %v5832, ptr %slot728, align 8
  %v5833 = load i64, ptr %slot702, align 8
  %p5834 = inttoptr i64 %v5833 to ptr
  %ld5835 = load i64, ptr %p5834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5835, ptr %slot729, align 8
  %v5836 = load i64, ptr %slot729, align 8
  %cmp5837 = icmp ne i64 %v5836, 0
  %cv5838 = zext i1 %cmp5837 to i32
  store i32 %cv5838, ptr %slot730, align 8
  %v5839 = load i32, ptr %slot730, align 8
  %cv5840 = zext i32 %v5839 to i64
  %cond5841 = icmp ne i64 %cv5840, 0
  br i1 %cond5841, label %bb_rcgnn822, label %bb_rcgstore822
bb_rcgnn822:
  %v5842 = load i64, ptr %slot729, align 8
  %op5843 = sub i64 %v5842, 16
  store i64 %op5843, ptr %slot731, align 8
  %v5844 = load i64, ptr %slot729, align 8
  %p5845 = inttoptr i64 %v5844 to ptr
  %rgep5846 = getelementptr i8, ptr %p5845, i64 -16
  %ld5847 = load i64, ptr %rgep5846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5847, ptr %slot732, align 8
  %v5848 = load i64, ptr %slot732, align 8
  %op5849 = and i64 %v5848, 4611686018427387906
  store i64 %op5849, ptr %slot733, align 8
  %v5850 = load i64, ptr %slot733, align 8
  %cmp5851 = icmp ne i64 %v5850, 0
  %cv5852 = zext i1 %cmp5851 to i32
  store i32 %cv5852, ptr %slot734, align 8
  %v5853 = load i32, ptr %slot734, align 8
  %cv5854 = zext i32 %v5853 to i64
  %cond5855 = icmp ne i64 %cv5854, 0
  br i1 %cond5855, label %bb_rcgstore822, label %bb_rcginc822
bb_rcginc822:
  %v5856 = load i64, ptr %slot729, align 8
  %op5857 = sub i64 %v5856, 24
  store i64 %op5857, ptr %slot735, align 8
  %v5858 = load i64, ptr %slot729, align 8
  %p5859 = inttoptr i64 %v5858 to ptr
  %rgep5860 = getelementptr i8, ptr %p5859, i64 -24
  %ld5861 = load i64, ptr %rgep5860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5861, ptr %slot736, align 8
  %v5862 = load i64, ptr %slot736, align 8
  %op5863 = add i64 %v5862, 1
  store i64 %op5863, ptr %slot737, align 8
  %v5864 = load i64, ptr %slot737, align 8
  %cmp5865 = icmp eq i64 %v5864, 0
  %cv5866 = zext i1 %cmp5865 to i32
  store i32 %cv5866, ptr %slot738, align 8
  %v5867 = load i32, ptr %slot738, align 8
  %cv5868 = zext i32 %v5867 to i64
  %cond5869 = icmp ne i64 %cv5868, 0
  br i1 %cond5869, label %bb_rcglimit822, label %bb_rcgcapacity822
bb_rcglimit822:
  %v5870 = load i64, ptr %slot1, align 8
  %p5871 = inttoptr i64 %v5870 to ptr
  %call5872 = call i32 @myl_qbe_rc_status(ptr %p5871, i32 2) nomerge, !dbg !138
  store i32 %call5872, ptr %slot739, align 8
  br label %bb_failure
bb_rcgcapacity822:
  %v5873 = load i64, ptr %slot737, align 8
  %v5874 = load i64, ptr %slot729, align 8
  %p5875 = inttoptr i64 %v5874 to ptr
  %rgep5876 = getelementptr i8, ptr %p5875, i64 -24
  store i64 %v5873, ptr %rgep5876, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore822
bb_rcgstore822:
  %v5877 = load i64, ptr %slot729, align 8
  %v5878 = load i64, ptr %slot728, align 8
  %p5879 = inttoptr i64 %v5878 to ptr
  store i64 %v5877, ptr %p5879, align 8, !alias.scope !3, !noalias !4
  %v5880 = load i64, ptr %slot47, align 8
  %p5881 = inttoptr i64 %v5880 to ptr
  store i32 2, ptr %p5881, align 4, !alias.scope !3, !noalias !4
  %v5882 = load i64, ptr %slot47, align 8
  %p5883 = inttoptr i64 %v5882 to ptr
  store i32 16, ptr %p5883, align 4, !alias.scope !3, !noalias !4
  %v5884 = load i64, ptr %slot46, align 8
  %p5885 = inttoptr i64 %v5884 to ptr
  store i32 1, ptr %p5885, align 4, !alias.scope !3, !noalias !4
  %v5886 = load i64, ptr %slot28, align 8
  %p5887 = inttoptr i64 %v5886 to ptr
  %ld5888 = load i32, ptr %p5887, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5888, ptr %slot740, align 8
  %v5889 = load i32, ptr %slot740, align 8
  %cv5890 = zext i32 %v5889 to i64
  %cond5891 = icmp ne i64 %cv5890, 0
  br i1 %cond5891, label %bb_rcslotdrop838, label %bb_rcslotdone838
bb_rcslotdrop838:
  %v5892 = load i64, ptr %slot28, align 8
  %p5893 = inttoptr i64 %v5892 to ptr
  store i32 0, ptr %p5893, align 4, !alias.scope !3, !noalias !4
  %v5894 = load i64, ptr %slot49, align 8
  store i64 %v5894, ptr %slot741, align 8
  %v5895 = load i64, ptr %slot29, align 8
  %p5896 = inttoptr i64 %v5895 to ptr
  %ld5897 = load i32, ptr %p5896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5897, ptr %slot742, align 8
  %v5898 = load i32, ptr %slot742, align 8
  %op5899 = and i32 %v5898, 28
  store i32 %op5899, ptr %slot743, align 8
  %v5900 = load i32, ptr %slot743, align 8
  %cv5901 = zext i32 %v5900 to i64
  %cond5902 = icmp ne i64 %cv5901, 0
  br i1 %cond5902, label %bb_rcslotrole838, label %bb_rcslotowner838
bb_rcslotrole838:
  %v5903 = load i64, ptr %slot110, align 8
  store i64 %v5903, ptr %slot744, align 8
  %v5904 = load i64, ptr %slot741, align 8
  %p5905 = inttoptr i64 %v5904 to ptr
  %ld5906 = load i64, ptr %p5905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5906, ptr %slot745, align 8
  %v5907 = load i64, ptr %slot745, align 8
  %cmp5908 = icmp ne i64 %v5907, 0
  %cv5909 = zext i1 %cmp5908 to i32
  store i32 %cv5909, ptr %slot746, align 8
  %v5910 = load i32, ptr %slot746, align 8
  %cv5911 = zext i32 %v5910 to i64
  %cond5912 = icmp ne i64 %cv5911, 0
  br i1 %cond5912, label %bb_rcgnn854, label %bb_rcgdone854
bb_rcgnn854:
  %v5913 = load i64, ptr %slot745, align 8
  %op5914 = sub i64 %v5913, 16
  store i64 %op5914, ptr %slot747, align 8
  %v5915 = load i64, ptr %slot745, align 8
  %p5916 = inttoptr i64 %v5915 to ptr
  %rgep5917 = getelementptr i8, ptr %p5916, i64 -16
  %ld5918 = load i64, ptr %rgep5917, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5918, ptr %slot748, align 8
  %v5919 = load i64, ptr %slot748, align 8
  %op5920 = and i64 %v5919, 4611686018427387906
  store i64 %op5920, ptr %slot749, align 8
  %v5921 = load i64, ptr %slot749, align 8
  %cmp5922 = icmp ne i64 %v5921, 0
  %cv5923 = zext i1 %cmp5922 to i32
  store i32 %cv5923, ptr %slot750, align 8
  %v5924 = load i32, ptr %slot750, align 8
  %cv5925 = zext i32 %v5924 to i64
  %cond5926 = icmp ne i64 %cv5925, 0
  br i1 %cond5926, label %bb_rcgclear854, label %bb_rcgcounted854
bb_rcgcounted854:
  %v5927 = load i64, ptr %slot745, align 8
  %op5928 = sub i64 %v5927, 24
  store i64 %op5928, ptr %slot751, align 8
  %v5929 = load i64, ptr %slot745, align 8
  %p5930 = inttoptr i64 %v5929 to ptr
  %rgep5931 = getelementptr i8, ptr %p5930, i64 -24
  %ld5932 = load i64, ptr %rgep5931, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5932, ptr %slot752, align 8
  %v5933 = load i64, ptr %slot752, align 8
  %op5934 = sub i64 %v5933, 1
  store i64 %op5934, ptr %slot753, align 8
  %v5935 = load i64, ptr %slot753, align 8
  %cmp5936 = icmp eq i64 %v5935, 0
  %cv5937 = zext i1 %cmp5936 to i32
  store i32 %cv5937, ptr %slot754, align 8
  %v5938 = load i32, ptr %slot754, align 8
  %cv5939 = zext i32 %v5938 to i64
  %cond5940 = icmp ne i64 %cv5939, 0
  br i1 %cond5940, label %bb_rcglast854, label %bb_rcgdec854
bb_rcglast854:
  %v5941 = load i64, ptr %slot745, align 8
  %op5942 = sub i64 %v5941, 32
  store i64 %op5942, ptr %slot755, align 8
  %v5943 = load i64, ptr %slot745, align 8
  %p5944 = inttoptr i64 %v5943 to ptr
  %rgep5945 = getelementptr i8, ptr %p5944, i64 -32
  %ld5946 = load i64, ptr %rgep5945, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5946, ptr %slot756, align 8
  %v5947 = load i64, ptr %slot756, align 8
  %cmp5948 = icmp ne i64 %v5947, 0
  %cv5949 = zext i1 %cmp5948 to i32
  store i32 %cv5949, ptr %slot757, align 8
  %v5950 = load i32, ptr %slot757, align 8
  %cv5951 = zext i32 %v5950 to i64
  %cond5952 = icmp ne i64 %cv5951, 0
  br i1 %cond5952, label %bb_rcgdec854, label %bb_rcgslow854
bb_rcgslow854:
  %v5953 = load i64, ptr %slot744, align 8
  %v5954 = load i64, ptr %slot741, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v5953, i64 %v5954) nomerge, !dbg !138
  br label %bb_rcgdone854
bb_rcgdec854:
  %v5955 = load i64, ptr %slot753, align 8
  %v5956 = load i64, ptr %slot745, align 8
  %p5957 = inttoptr i64 %v5956 to ptr
  %rgep5958 = getelementptr i8, ptr %p5957, i64 -24
  store i64 %v5955, ptr %rgep5958, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear854
bb_rcgclear854:
  %v5959 = load i64, ptr %slot741, align 8
  %p5960 = inttoptr i64 %v5959 to ptr
  store i64 0, ptr %p5960, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone854
bb_rcgdone854:
  br label %bb_rcslotdone838
bb_rcslotowner838:
  %v5961 = load i64, ptr %slot110, align 8
  store i64 %v5961, ptr %slot758, align 8
  %v5962 = load i64, ptr %slot741, align 8
  %p5963 = inttoptr i64 %v5962 to ptr
  %ld5964 = load i64, ptr %p5963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5964, ptr %slot759, align 8
  %v5965 = load i64, ptr %slot759, align 8
  %cmp5966 = icmp ne i64 %v5965, 0
  %cv5967 = zext i1 %cmp5966 to i32
  store i32 %cv5967, ptr %slot760, align 8
  %v5968 = load i32, ptr %slot760, align 8
  %cv5969 = zext i32 %v5968 to i64
  %cond5970 = icmp ne i64 %cv5969, 0
  br i1 %cond5970, label %bb_rcgnn869, label %bb_rcgdone869
bb_rcgnn869:
  %v5971 = load i64, ptr %slot759, align 8
  %op5972 = sub i64 %v5971, 16
  store i64 %op5972, ptr %slot761, align 8
  %v5973 = load i64, ptr %slot759, align 8
  %p5974 = inttoptr i64 %v5973 to ptr
  %rgep5975 = getelementptr i8, ptr %p5974, i64 -16
  %ld5976 = load i64, ptr %rgep5975, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5976, ptr %slot762, align 8
  %v5977 = load i64, ptr %slot762, align 8
  %op5978 = and i64 %v5977, 4611686018427387906
  store i64 %op5978, ptr %slot763, align 8
  %v5979 = load i64, ptr %slot763, align 8
  %cmp5980 = icmp ne i64 %v5979, 0
  %cv5981 = zext i1 %cmp5980 to i32
  store i32 %cv5981, ptr %slot764, align 8
  %v5982 = load i32, ptr %slot764, align 8
  %cv5983 = zext i32 %v5982 to i64
  %cond5984 = icmp ne i64 %cv5983, 0
  br i1 %cond5984, label %bb_rcgclear869, label %bb_rcgcounted869
bb_rcgcounted869:
  %v5985 = load i64, ptr %slot759, align 8
  %op5986 = sub i64 %v5985, 32
  store i64 %op5986, ptr %slot765, align 8
  %v5987 = load i64, ptr %slot759, align 8
  %p5988 = inttoptr i64 %v5987 to ptr
  %rgep5989 = getelementptr i8, ptr %p5988, i64 -32
  %ld5990 = load i64, ptr %rgep5989, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5990, ptr %slot766, align 8
  %v5991 = load i64, ptr %slot766, align 8
  %op5992 = sub i64 %v5991, 1
  store i64 %op5992, ptr %slot767, align 8
  %v5993 = load i64, ptr %slot767, align 8
  %cmp5994 = icmp eq i64 %v5993, 0
  %cv5995 = zext i1 %cmp5994 to i32
  store i32 %cv5995, ptr %slot768, align 8
  %v5996 = load i32, ptr %slot768, align 8
  %cv5997 = zext i32 %v5996 to i64
  %cond5998 = icmp ne i64 %cv5997, 0
  br i1 %cond5998, label %bb_rcglast869, label %bb_rcgdec869
bb_rcglast869:
  %v5999 = load i64, ptr %slot759, align 8
  %op6000 = sub i64 %v5999, 24
  store i64 %op6000, ptr %slot769, align 8
  %v6001 = load i64, ptr %slot759, align 8
  %p6002 = inttoptr i64 %v6001 to ptr
  %rgep6003 = getelementptr i8, ptr %p6002, i64 -24
  %ld6004 = load i64, ptr %rgep6003, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6004, ptr %slot770, align 8
  %v6005 = load i64, ptr %slot770, align 8
  %cmp6006 = icmp ne i64 %v6005, 0
  %cv6007 = zext i1 %cmp6006 to i32
  store i32 %cv6007, ptr %slot771, align 8
  %v6008 = load i32, ptr %slot771, align 8
  %cv6009 = zext i32 %v6008 to i64
  %cond6010 = icmp ne i64 %cv6009, 0
  br i1 %cond6010, label %bb_rcgdec869, label %bb_rcgslow869
bb_rcgslow869:
  %v6011 = load i64, ptr %slot758, align 8
  %v6012 = load i64, ptr %slot741, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v6011, i64 %v6012) nomerge, !dbg !138
  br label %bb_rcgdone869
bb_rcgdec869:
  %v6013 = load i64, ptr %slot767, align 8
  %v6014 = load i64, ptr %slot759, align 8
  %p6015 = inttoptr i64 %v6014 to ptr
  %rgep6016 = getelementptr i8, ptr %p6015, i64 -32
  store i64 %v6013, ptr %rgep6016, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear869
bb_rcgclear869:
  %v6017 = load i64, ptr %slot741, align 8
  %p6018 = inttoptr i64 %v6017 to ptr
  store i64 0, ptr %p6018, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone869
bb_rcgdone869:
  br label %bb_rcslotdone838
bb_rcslotdone838:
  br label %bb_rcprivateprepared786
bb_rcprivateprepared786:
  %v6019 = load i64, ptr %slot14, align 8
  %p6020 = inttoptr i64 %v6019 to ptr
  %ld6021 = load i32, ptr %p6020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6021, ptr %slot772, align 8
  %v6022 = load i32, ptr %slot772, align 8
  %cv6023 = zext i32 %v6022 to i64
  %cond6024 = icmp ne i64 %cv6023, 0
  br i1 %cond6024, label %bb_rcslotdrop876, label %bb_rcslotdone876
bb_rcslotdrop876:
  %v6025 = load i64, ptr %slot14, align 8
  %p6026 = inttoptr i64 %v6025 to ptr
  store i32 0, ptr %p6026, align 4, !alias.scope !3, !noalias !4
  %v6027 = load i64, ptr %slot73, align 8
  store i64 %v6027, ptr %slot773, align 8
  %v6028 = load i64, ptr %slot15, align 8
  %p6029 = inttoptr i64 %v6028 to ptr
  %ld6030 = load i32, ptr %p6029, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6030, ptr %slot774, align 8
  %v6031 = load i32, ptr %slot774, align 8
  %op6032 = and i32 %v6031, 28
  store i32 %op6032, ptr %slot775, align 8
  %v6033 = load i32, ptr %slot775, align 8
  %cv6034 = zext i32 %v6033 to i64
  %cond6035 = icmp ne i64 %cv6034, 0
  br i1 %cond6035, label %bb_rcslotrole876, label %bb_rcslotowner876
bb_rcslotrole876:
  %v6036 = load i64, ptr %slot110, align 8
  store i64 %v6036, ptr %slot776, align 8
  %v6037 = load i64, ptr %slot773, align 8
  %p6038 = inttoptr i64 %v6037 to ptr
  %ld6039 = load i64, ptr %p6038, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6039, ptr %slot777, align 8
  %v6040 = load i64, ptr %slot777, align 8
  %cmp6041 = icmp ne i64 %v6040, 0
  %cv6042 = zext i1 %cmp6041 to i32
  store i32 %cv6042, ptr %slot778, align 8
  %v6043 = load i32, ptr %slot778, align 8
  %cv6044 = zext i32 %v6043 to i64
  %cond6045 = icmp ne i64 %cv6044, 0
  br i1 %cond6045, label %bb_rcgnn892, label %bb_rcgdone892
bb_rcgnn892:
  %v6046 = load i64, ptr %slot777, align 8
  %op6047 = sub i64 %v6046, 16
  store i64 %op6047, ptr %slot779, align 8
  %v6048 = load i64, ptr %slot777, align 8
  %p6049 = inttoptr i64 %v6048 to ptr
  %rgep6050 = getelementptr i8, ptr %p6049, i64 -16
  %ld6051 = load i64, ptr %rgep6050, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6051, ptr %slot780, align 8
  %v6052 = load i64, ptr %slot780, align 8
  %op6053 = and i64 %v6052, 4611686018427387906
  store i64 %op6053, ptr %slot781, align 8
  %v6054 = load i64, ptr %slot781, align 8
  %cmp6055 = icmp ne i64 %v6054, 0
  %cv6056 = zext i1 %cmp6055 to i32
  store i32 %cv6056, ptr %slot782, align 8
  %v6057 = load i32, ptr %slot782, align 8
  %cv6058 = zext i32 %v6057 to i64
  %cond6059 = icmp ne i64 %cv6058, 0
  br i1 %cond6059, label %bb_rcgclear892, label %bb_rcgcounted892
bb_rcgcounted892:
  %v6060 = load i64, ptr %slot777, align 8
  %op6061 = sub i64 %v6060, 24
  store i64 %op6061, ptr %slot783, align 8
  %v6062 = load i64, ptr %slot777, align 8
  %p6063 = inttoptr i64 %v6062 to ptr
  %rgep6064 = getelementptr i8, ptr %p6063, i64 -24
  %ld6065 = load i64, ptr %rgep6064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6065, ptr %slot784, align 8
  %v6066 = load i64, ptr %slot784, align 8
  %op6067 = sub i64 %v6066, 1
  store i64 %op6067, ptr %slot785, align 8
  %v6068 = load i64, ptr %slot785, align 8
  %cmp6069 = icmp eq i64 %v6068, 0
  %cv6070 = zext i1 %cmp6069 to i32
  store i32 %cv6070, ptr %slot786, align 8
  %v6071 = load i32, ptr %slot786, align 8
  %cv6072 = zext i32 %v6071 to i64
  %cond6073 = icmp ne i64 %cv6072, 0
  br i1 %cond6073, label %bb_rcglast892, label %bb_rcgdec892
bb_rcglast892:
  %v6074 = load i64, ptr %slot777, align 8
  %op6075 = sub i64 %v6074, 32
  store i64 %op6075, ptr %slot787, align 8
  %v6076 = load i64, ptr %slot777, align 8
  %p6077 = inttoptr i64 %v6076 to ptr
  %rgep6078 = getelementptr i8, ptr %p6077, i64 -32
  %ld6079 = load i64, ptr %rgep6078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6079, ptr %slot788, align 8
  %v6080 = load i64, ptr %slot788, align 8
  %cmp6081 = icmp ne i64 %v6080, 0
  %cv6082 = zext i1 %cmp6081 to i32
  store i32 %cv6082, ptr %slot789, align 8
  %v6083 = load i32, ptr %slot789, align 8
  %cv6084 = zext i32 %v6083 to i64
  %cond6085 = icmp ne i64 %cv6084, 0
  br i1 %cond6085, label %bb_rcgdec892, label %bb_rcgslow892
bb_rcgslow892:
  %v6086 = load i64, ptr %slot776, align 8
  %v6087 = load i64, ptr %slot773, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v6086, i64 %v6087) nomerge, !dbg !138
  br label %bb_rcgdone892
bb_rcgdec892:
  %v6088 = load i64, ptr %slot785, align 8
  %v6089 = load i64, ptr %slot777, align 8
  %p6090 = inttoptr i64 %v6089 to ptr
  %rgep6091 = getelementptr i8, ptr %p6090, i64 -24
  store i64 %v6088, ptr %rgep6091, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear892
bb_rcgclear892:
  %v6092 = load i64, ptr %slot773, align 8
  %p6093 = inttoptr i64 %v6092 to ptr
  store i64 0, ptr %p6093, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone892
bb_rcgdone892:
  br label %bb_rcslotdone876
bb_rcslotowner876:
  %v6094 = load i64, ptr %slot110, align 8
  store i64 %v6094, ptr %slot790, align 8
  %v6095 = load i64, ptr %slot773, align 8
  %p6096 = inttoptr i64 %v6095 to ptr
  %ld6097 = load i64, ptr %p6096, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6097, ptr %slot791, align 8
  %v6098 = load i64, ptr %slot791, align 8
  %cmp6099 = icmp ne i64 %v6098, 0
  %cv6100 = zext i1 %cmp6099 to i32
  store i32 %cv6100, ptr %slot792, align 8
  %v6101 = load i32, ptr %slot792, align 8
  %cv6102 = zext i32 %v6101 to i64
  %cond6103 = icmp ne i64 %cv6102, 0
  br i1 %cond6103, label %bb_rcgnn907, label %bb_rcgdone907
bb_rcgnn907:
  %v6104 = load i64, ptr %slot791, align 8
  %op6105 = sub i64 %v6104, 16
  store i64 %op6105, ptr %slot793, align 8
  %v6106 = load i64, ptr %slot791, align 8
  %p6107 = inttoptr i64 %v6106 to ptr
  %rgep6108 = getelementptr i8, ptr %p6107, i64 -16
  %ld6109 = load i64, ptr %rgep6108, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6109, ptr %slot794, align 8
  %v6110 = load i64, ptr %slot794, align 8
  %op6111 = and i64 %v6110, 4611686018427387906
  store i64 %op6111, ptr %slot795, align 8
  %v6112 = load i64, ptr %slot795, align 8
  %cmp6113 = icmp ne i64 %v6112, 0
  %cv6114 = zext i1 %cmp6113 to i32
  store i32 %cv6114, ptr %slot796, align 8
  %v6115 = load i32, ptr %slot796, align 8
  %cv6116 = zext i32 %v6115 to i64
  %cond6117 = icmp ne i64 %cv6116, 0
  br i1 %cond6117, label %bb_rcgclear907, label %bb_rcgcounted907
bb_rcgcounted907:
  %v6118 = load i64, ptr %slot791, align 8
  %op6119 = sub i64 %v6118, 32
  store i64 %op6119, ptr %slot797, align 8
  %v6120 = load i64, ptr %slot791, align 8
  %p6121 = inttoptr i64 %v6120 to ptr
  %rgep6122 = getelementptr i8, ptr %p6121, i64 -32
  %ld6123 = load i64, ptr %rgep6122, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6123, ptr %slot798, align 8
  %v6124 = load i64, ptr %slot798, align 8
  %op6125 = sub i64 %v6124, 1
  store i64 %op6125, ptr %slot799, align 8
  %v6126 = load i64, ptr %slot799, align 8
  %cmp6127 = icmp eq i64 %v6126, 0
  %cv6128 = zext i1 %cmp6127 to i32
  store i32 %cv6128, ptr %slot800, align 8
  %v6129 = load i32, ptr %slot800, align 8
  %cv6130 = zext i32 %v6129 to i64
  %cond6131 = icmp ne i64 %cv6130, 0
  br i1 %cond6131, label %bb_rcglast907, label %bb_rcgdec907
bb_rcglast907:
  %v6132 = load i64, ptr %slot791, align 8
  %op6133 = sub i64 %v6132, 24
  store i64 %op6133, ptr %slot801, align 8
  %v6134 = load i64, ptr %slot791, align 8
  %p6135 = inttoptr i64 %v6134 to ptr
  %rgep6136 = getelementptr i8, ptr %p6135, i64 -24
  %ld6137 = load i64, ptr %rgep6136, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6137, ptr %slot802, align 8
  %v6138 = load i64, ptr %slot802, align 8
  %cmp6139 = icmp ne i64 %v6138, 0
  %cv6140 = zext i1 %cmp6139 to i32
  store i32 %cv6140, ptr %slot803, align 8
  %v6141 = load i32, ptr %slot803, align 8
  %cv6142 = zext i32 %v6141 to i64
  %cond6143 = icmp ne i64 %cv6142, 0
  br i1 %cond6143, label %bb_rcgdec907, label %bb_rcgslow907
bb_rcgslow907:
  %v6144 = load i64, ptr %slot790, align 8
  %v6145 = load i64, ptr %slot773, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v6144, i64 %v6145) nomerge, !dbg !138
  br label %bb_rcgdone907
bb_rcgdec907:
  %v6146 = load i64, ptr %slot799, align 8
  %v6147 = load i64, ptr %slot791, align 8
  %p6148 = inttoptr i64 %v6147 to ptr
  %rgep6149 = getelementptr i8, ptr %p6148, i64 -32
  store i64 %v6146, ptr %rgep6149, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear907
bb_rcgclear907:
  %v6150 = load i64, ptr %slot773, align 8
  %p6151 = inttoptr i64 %v6150 to ptr
  store i64 0, ptr %p6151, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone907
bb_rcgdone907:
  br label %bb_rcslotdone876
bb_rcslotdone876:
  %v6152 = load i64, ptr %slot73, align 8
  store i64 %v6152, ptr %slot804, align 8
  %v6153 = load i64, ptr %slot65, align 8
  store i64 %v6153, ptr %slot805, align 8
  %v6154 = load i64, ptr %slot805, align 8
  %v6155 = load i64, ptr %slot804, align 8
  %p6156 = inttoptr i64 %v6154 to ptr
  %p6157 = inttoptr i64 %v6155 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6157, ptr %p6156, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6158 = load i64, ptr %slot46, align 8
  %p6159 = inttoptr i64 %v6158 to ptr
  store i32 0, ptr %p6159, align 4, !alias.scope !3, !noalias !4
  %v6160 = load i64, ptr %slot15, align 8
  %p6161 = inttoptr i64 %v6160 to ptr
  store i32 2, ptr %p6161, align 4, !alias.scope !3, !noalias !4
  %v6162 = load i64, ptr %slot47, align 8
  %p6163 = inttoptr i64 %v6162 to ptr
  %ld6164 = load i32, ptr %p6163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6164, ptr %slot806, align 8
  %v6165 = load i32, ptr %slot806, align 8
  %v6166 = load i64, ptr %slot15, align 8
  %p6167 = inttoptr i64 %v6166 to ptr
  store i32 %v6165, ptr %p6167, align 4, !alias.scope !3, !noalias !4
  %v6168 = load i64, ptr %slot14, align 8
  %p6169 = inttoptr i64 %v6168 to ptr
  store i32 1, ptr %p6169, align 4, !alias.scope !3, !noalias !4
  %v6170 = load i64, ptr %slot73, align 8
  %p6171 = inttoptr i64 %v6170 to ptr
  %ld6172 = load i64, ptr %p6171, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6172, ptr %slot807, align 8
  %v6173 = load i64, ptr %slot807, align 8
  %v6174 = load i64, ptr %slot80, align 8
  %p6175 = inttoptr i64 %v6174 to ptr
  store i64 %v6173, ptr %p6175, align 8, !alias.scope !3, !noalias !4
  %v6176 = load i64, ptr %slot81, align 8
  %p6177 = inttoptr i64 %v6176 to ptr
  store i64 0, ptr %p6177, align 8, !alias.scope !3, !noalias !4
  %v6178 = load i64, ptr %slot81, align 8
  %p6179 = inttoptr i64 %v6178 to ptr
  %ld6180 = load i64, ptr %p6179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6180, ptr %slot808, align 8
  %v6181 = load i64, ptr %slot808, align 8
  %cmp6182 = icmp sge i64 %v6181, 0
  %cv6183 = zext i1 %cmp6182 to i64
  store i64 %cv6183, ptr %slot809, align 8
  %v6184 = load i64, ptr %slot809, align 8
  %cond6185 = icmp ne i64 %v6184, 0
  br i1 %cond6185, label %bb_success921, label %bb_failed921
bb_failed921:
  %v6186 = load i64, ptr %slot1, align 8
  %p6187 = inttoptr i64 %v6186 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p6187) nomerge, !dbg !140
  unreachable
bb_success921:
  %v6188 = load i64, ptr %slot110, align 8
  %p6189 = inttoptr i64 %v6188 to ptr
  %p6190 = inttoptr i64 ptrtoint (ptr @myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903 to i64) to ptr
  %v6191 = load i64, ptr %slot808, align 8
  %call6192 = call ptr @myl_native_list_new(ptr %p6189, ptr %p6190, i64 %v6191) nomerge, !dbg !140
  %calladdr6193 = ptrtoint ptr %call6192 to i64
  store i64 %calladdr6193, ptr %slot810, align 8
  %v6194 = load i64, ptr %slot810, align 8
  %cond6195 = icmp ne i64 %v6194, 0
  br i1 %cond6195, label %bb_success923, label %bb_failed923
bb_failed923:
  %v6196 = load i64, ptr %slot1, align 8
  %p6197 = inttoptr i64 %v6196 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6197) nomerge, !dbg !140
  unreachable
bb_success923:
  %v6198 = load i64, ptr %slot810, align 8
  %v6199 = load i64, ptr %slot81, align 8
  %p6200 = inttoptr i64 %v6199 to ptr
  store i64 %v6198, ptr %p6200, align 8, !alias.scope !3, !noalias !4
  %v6201 = load i64, ptr %slot81, align 8
  %p6202 = inttoptr i64 %v6201 to ptr
  %ld6203 = load i64, ptr %p6202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6203, ptr %slot811, align 8
  %v6204 = load i64, ptr %slot811, align 8
  %v6205 = load i64, ptr %slot58, align 8
  %p6206 = inttoptr i64 %v6205 to ptr
  store i64 %v6204, ptr %p6206, align 8, !alias.scope !3, !noalias !4
  %v6207 = load i64, ptr %slot58, align 8
  store i64 %v6207, ptr %slot812, align 8
  %v6208 = load i64, ptr %slot65, align 8
  store i64 %v6208, ptr %slot813, align 8
  %v6209 = load i64, ptr %slot812, align 8
  %v6210 = load i64, ptr %slot813, align 8
  %p6211 = inttoptr i64 %v6209 to ptr
  %p6212 = inttoptr i64 %v6210 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6212, ptr %p6211, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6213 = load i64, ptr %slot47, align 8
  %p6214 = inttoptr i64 %v6213 to ptr
  store i32 2, ptr %p6214, align 4, !alias.scope !3, !noalias !4
  %v6215 = load i64, ptr %slot46, align 8
  %p6216 = inttoptr i64 %v6215 to ptr
  store i32 1, ptr %p6216, align 4, !alias.scope !3, !noalias !4
  %v6217 = load i64, ptr %slot50, align 8
  store i64 %v6217, ptr %slot814, align 8
  %v6218 = load i64, ptr %slot65, align 8
  store i64 %v6218, ptr %slot815, align 8
  %v6219 = load i64, ptr %slot815, align 8
  %v6220 = load i64, ptr %slot814, align 8
  %p6221 = inttoptr i64 %v6219 to ptr
  %p6222 = inttoptr i64 %v6220 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6222, ptr %p6221, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6223 = load i64, ptr %slot31, align 8
  %p6224 = inttoptr i64 %v6223 to ptr
  store i32 2, ptr %p6224, align 4, !alias.scope !3, !noalias !4
  %v6225 = load i64, ptr %slot47, align 8
  %p6226 = inttoptr i64 %v6225 to ptr
  %ld6227 = load i32, ptr %p6226, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6227, ptr %slot816, align 8
  %v6228 = load i32, ptr %slot816, align 8
  %v6229 = load i64, ptr %slot31, align 8
  %p6230 = inttoptr i64 %v6229 to ptr
  store i32 %v6228, ptr %p6230, align 4, !alias.scope !3, !noalias !4
  %v6231 = load i64, ptr %slot46, align 8
  %p6232 = inttoptr i64 %v6231 to ptr
  store i32 0, ptr %p6232, align 4, !alias.scope !3, !noalias !4
  %v6233 = load i64, ptr %slot30, align 8
  %p6234 = inttoptr i64 %v6233 to ptr
  store i32 1, ptr %p6234, align 4, !alias.scope !3, !noalias !4
  %v6235 = load i64, ptr %slot814, align 8
  %p6236 = inttoptr i64 %v6235 to ptr
  %ld6237 = load i64, ptr %p6236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6237, ptr %slot817, align 8
  %v6238 = load i64, ptr %slot817, align 8
  %v6239 = load i64, ptr %slot81, align 8
  %p6240 = inttoptr i64 %v6239 to ptr
  store i64 %v6238, ptr %p6240, align 8, !alias.scope !3, !noalias !4
  %v6241 = load i64, ptr %slot81, align 8
  %p6242 = inttoptr i64 %v6241 to ptr
  %ld6243 = load i64, ptr %p6242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6243, ptr %slot818, align 8
  %v6244 = load i64, ptr %slot818, align 8
  %v6245 = load i64, ptr %slot58, align 8
  %p6246 = inttoptr i64 %v6245 to ptr
  store i64 %v6244, ptr %p6246, align 8, !alias.scope !3, !noalias !4
  %v6247 = load i64, ptr %slot58, align 8
  store i64 %v6247, ptr %slot819, align 8
  %v6248 = load i64, ptr %slot30, align 8
  %p6249 = inttoptr i64 %v6248 to ptr
  %ld6250 = load i32, ptr %p6249, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6250, ptr %slot820, align 8
  %v6251 = load i64, ptr %slot31, align 8
  %p6252 = inttoptr i64 %v6251 to ptr
  %ld6253 = load i32, ptr %p6252, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6253, ptr %slot821, align 8
  %v6254 = load i32, ptr %slot821, align 8
  %op6255 = and i32 %v6254, 24
  store i32 %op6255, ptr %slot821, align 8
  %v6256 = load i32, ptr %slot821, align 8
  %cmp6257 = icmp eq i32 %v6256, 0
  %cv6258 = zext i1 %cmp6257 to i32
  store i32 %cv6258, ptr %slot822, align 8
  %v6259 = load i32, ptr %slot820, align 8
  %v6260 = load i32, ptr %slot822, align 8
  %op6261 = and i32 %v6259, %v6260
  store i32 %op6261, ptr %slot823, align 8
  %v6262 = load i32, ptr %slot823, align 8
  %cv6263 = zext i32 %v6262 to i64
  %cond6264 = icmp ne i64 %cv6263, 0
  br i1 %cond6264, label %bb_rcprivateown946, label %bb_rcprivateloan946
bb_rcprivateown946:
  %v6265 = load i64, ptr %slot65, align 8
  store i64 %v6265, ptr %slot824, align 8
  %v6266 = load i64, ptr %slot111, align 8
  store i64 %v6266, ptr %slot825, align 8
  %v6267 = load i64, ptr %slot819, align 8
  %v6268 = load i64, ptr %slot824, align 8
  %op6269 = sub i64 %v6267, %v6268
  store i64 %op6269, ptr %slot826, align 8
  %v6270 = load i64, ptr %slot824, align 8
  %v6271 = load i64, ptr %slot819, align 8
  %op6272 = sub i64 %v6270, %v6271
  store i64 %op6272, ptr %slot827, align 8
  %v6273 = load i64, ptr %slot826, align 8
  %cmp6274 = icmp ult i64 %v6273, 8
  %cv6275 = zext i1 %cmp6274 to i32
  store i32 %cv6275, ptr %slot828, align 8
  %v6276 = load i64, ptr %slot827, align 8
  %cmp6277 = icmp ult i64 %v6276, 8
  %cv6278 = zext i1 %cmp6277 to i32
  store i32 %cv6278, ptr %slot829, align 8
  %v6279 = load i32, ptr %slot828, align 8
  %v6280 = load i32, ptr %slot829, align 8
  %op6281 = or i32 %v6279, %v6280
  store i32 %op6281, ptr %slot830, align 8
  %v6282 = load i32, ptr %slot830, align 8
  %cv6283 = zext i32 %v6282 to i64
  %cond6284 = icmp ne i64 %cv6283, 0
  br i1 %cond6284, label %bb_rcmoveslow949, label %bb_rcmovecheck949
bb_rcmovecheck949:
  %v6285 = load i64, ptr %slot819, align 8
  %p6287 = inttoptr i64 %v6285 to ptr
  %gep6288 = getelementptr i8, ptr %p6287, i64 0
  %op6286 = ptrtoint ptr %gep6288 to i64
  store i64 %op6286, ptr %slot831, align 8
  %v6289 = load i64, ptr %slot831, align 8
  %p6290 = inttoptr i64 %v6289 to ptr
  %ld6291 = load i64, ptr %p6290, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6291, ptr %slot832, align 8
  %v6292 = load i64, ptr %slot832, align 8
  %cmp6293 = icmp ne i64 %v6292, 0
  %cv6294 = zext i1 %cmp6293 to i32
  store i32 %cv6294, ptr %slot833, align 8
  %v6295 = load i32, ptr %slot833, align 8
  %cv6296 = zext i32 %v6295 to i64
  %cond6297 = icmp ne i64 %cv6296, 0
  br i1 %cond6297, label %bb_rcmoveheader957, label %bb_rcmovenext957
bb_rcmoveheader957:
  %v6298 = load i64, ptr %slot832, align 8
  %op6299 = sub i64 %v6298, 16
  store i64 %op6299, ptr %slot834, align 8
  %v6300 = load i64, ptr %slot832, align 8
  %p6301 = inttoptr i64 %v6300 to ptr
  %rgep6302 = getelementptr i8, ptr %p6301, i64 -16
  %ld6303 = load i64, ptr %rgep6302, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6303, ptr %slot835, align 8
  %v6304 = load i64, ptr %slot835, align 8
  %op6305 = and i64 %v6304, 5764607523034234881
  store i64 %op6305, ptr %slot836, align 8
  %v6306 = load i64, ptr %slot836, align 8
  %cmp6307 = icmp ne i64 %v6306, 0
  %cv6308 = zext i1 %cmp6307 to i32
  store i32 %cv6308, ptr %slot837, align 8
  %v6309 = load i32, ptr %slot837, align 8
  %cv6310 = zext i32 %v6309 to i64
  %cond6311 = icmp ne i64 %cv6310, 0
  br i1 %cond6311, label %bb_rcmoveslow949, label %bb_rcmovenext957
bb_rcmovenext957:
  %v6312 = load i64, ptr %slot819, align 8
  %v6313 = load i64, ptr %slot824, align 8
  %p6314 = inttoptr i64 %v6312 to ptr
  %p6315 = inttoptr i64 %v6313 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6315, ptr %p6314, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6316 = load i64, ptr %slot819, align 8
  %p6317 = inttoptr i64 %v6316 to ptr
  store i64 0, ptr %p6317, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved949
bb_rcmoveslow949:
  %v6318 = load i64, ptr %slot110, align 8
  %v6319 = load i64, ptr %slot824, align 8
  %v6320 = load i64, ptr %slot819, align 8
  %v6321 = load i64, ptr %slot825, align 8
  %cv6322 = trunc i64 %v6321 to i32
  %call6323 = call i32 @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_take(i64 %v6318, i64 %v6319, i64 %v6320, i32 %cv6322) nomerge, !dbg !142
  store i32 %call6323, ptr %slot838, align 8
  %v6324 = load i32, ptr %slot838, align 8
  %cv6325 = zext i32 %v6324 to i64
  %cond6326 = icmp ne i64 %cv6325, 0
  br i1 %cond6326, label %bb_rcsuccess964, label %bb_rcfailure964
bb_rcfailure964:
  %v6327 = load i64, ptr %slot110, align 8
  %p6328 = inttoptr i64 %v6327 to ptr
  %call6329 = call i32 @myl_rc_take_failure(ptr %p6328) nomerge, !dbg !142
  store i32 %call6329, ptr %slot839, align 8
  %v6330 = load i64, ptr %slot1, align 8
  %p6331 = inttoptr i64 %v6330 to ptr
  %v6332 = load i32, ptr %slot839, align 8
  %call6333 = call i32 @myl_qbe_rc_status(ptr %p6331, i32 %v6332) nomerge, !dbg !142
  store i32 %call6333, ptr %slot840, align 8
  br label %bb_failure
bb_rcsuccess964:
  br label %bb_rcmoved949
bb_rcmoved949:
  %v6334 = load i64, ptr %slot30, align 8
  %p6335 = inttoptr i64 %v6334 to ptr
  store i32 0, ptr %p6335, align 4, !alias.scope !3, !noalias !4
  %v6336 = load i64, ptr %slot47, align 8
  %p6337 = inttoptr i64 %v6336 to ptr
  store i32 2, ptr %p6337, align 4, !alias.scope !3, !noalias !4
  %v6338 = load i64, ptr %slot46, align 8
  %p6339 = inttoptr i64 %v6338 to ptr
  store i32 1, ptr %p6339, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared946
bb_rcprivateloan946:
  %v6340 = load i64, ptr %slot30, align 8
  %p6341 = inttoptr i64 %v6340 to ptr
  %ld6342 = load i32, ptr %p6341, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6342, ptr %slot841, align 8
  %v6343 = load i64, ptr %slot31, align 8
  %p6344 = inttoptr i64 %v6343 to ptr
  %ld6345 = load i32, ptr %p6344, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6345, ptr %slot842, align 8
  %v6346 = load i32, ptr %slot842, align 8
  %cmp6347 = icmp eq i32 %v6346, 16
  %cv6348 = zext i1 %cmp6347 to i32
  store i32 %cv6348, ptr %slot843, align 8
  %v6349 = load i32, ptr %slot843, align 8
  %v6350 = load i32, ptr %slot841, align 8
  %op6351 = and i32 %v6349, %v6350
  store i32 %op6351, ptr %slot843, align 8
  %v6352 = load i32, ptr %slot843, align 8
  %cv6353 = zext i32 %v6352 to i64
  %cond6354 = icmp ne i64 %cv6353, 0
  br i1 %cond6354, label %bb_rcprivatemove946, label %bb_rcprivatenew946
bb_rcprivatemove946:
  %v6355 = load i64, ptr %slot65, align 8
  store i64 %v6355, ptr %slot844, align 8
  %v6356 = load i64, ptr %slot819, align 8
  %v6357 = load i64, ptr %slot844, align 8
  %p6358 = inttoptr i64 %v6356 to ptr
  %p6359 = inttoptr i64 %v6357 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6359, ptr %p6358, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6360 = load i64, ptr %slot819, align 8
  %p6361 = inttoptr i64 %v6360 to ptr
  store i64 0, ptr %p6361, align 8, !alias.scope !3, !noalias !4
  %v6362 = load i64, ptr %slot47, align 8
  %p6363 = inttoptr i64 %v6362 to ptr
  store i32 2, ptr %p6363, align 4, !alias.scope !3, !noalias !4
  %v6364 = load i64, ptr %slot47, align 8
  %p6365 = inttoptr i64 %v6364 to ptr
  store i32 16, ptr %p6365, align 4, !alias.scope !3, !noalias !4
  %v6366 = load i64, ptr %slot46, align 8
  %p6367 = inttoptr i64 %v6366 to ptr
  store i32 1, ptr %p6367, align 4, !alias.scope !3, !noalias !4
  %v6368 = load i64, ptr %slot30, align 8
  %p6369 = inttoptr i64 %v6368 to ptr
  store i32 0, ptr %p6369, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared946
bb_rcprivatenew946:
  %v6370 = load i64, ptr %slot65, align 8
  store i64 %v6370, ptr %slot845, align 8
  %v6371 = load i64, ptr %slot819, align 8
  %p6372 = inttoptr i64 %v6371 to ptr
  %ld6373 = load i64, ptr %p6372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6373, ptr %slot846, align 8
  %v6374 = load i64, ptr %slot846, align 8
  %cmp6375 = icmp ne i64 %v6374, 0
  %cv6376 = zext i1 %cmp6375 to i32
  store i32 %cv6376, ptr %slot847, align 8
  %v6377 = load i32, ptr %slot847, align 8
  %cv6378 = zext i32 %v6377 to i64
  %cond6379 = icmp ne i64 %cv6378, 0
  br i1 %cond6379, label %bb_rcgnn982, label %bb_rcgstore982
bb_rcgnn982:
  %v6380 = load i64, ptr %slot846, align 8
  %op6381 = sub i64 %v6380, 16
  store i64 %op6381, ptr %slot848, align 8
  %v6382 = load i64, ptr %slot846, align 8
  %p6383 = inttoptr i64 %v6382 to ptr
  %rgep6384 = getelementptr i8, ptr %p6383, i64 -16
  %ld6385 = load i64, ptr %rgep6384, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6385, ptr %slot849, align 8
  %v6386 = load i64, ptr %slot849, align 8
  %op6387 = and i64 %v6386, 4611686018427387906
  store i64 %op6387, ptr %slot850, align 8
  %v6388 = load i64, ptr %slot850, align 8
  %cmp6389 = icmp ne i64 %v6388, 0
  %cv6390 = zext i1 %cmp6389 to i32
  store i32 %cv6390, ptr %slot851, align 8
  %v6391 = load i32, ptr %slot851, align 8
  %cv6392 = zext i32 %v6391 to i64
  %cond6393 = icmp ne i64 %cv6392, 0
  br i1 %cond6393, label %bb_rcgstore982, label %bb_rcginc982
bb_rcginc982:
  %v6394 = load i64, ptr %slot846, align 8
  %op6395 = sub i64 %v6394, 24
  store i64 %op6395, ptr %slot852, align 8
  %v6396 = load i64, ptr %slot846, align 8
  %p6397 = inttoptr i64 %v6396 to ptr
  %rgep6398 = getelementptr i8, ptr %p6397, i64 -24
  %ld6399 = load i64, ptr %rgep6398, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6399, ptr %slot853, align 8
  %v6400 = load i64, ptr %slot853, align 8
  %op6401 = add i64 %v6400, 1
  store i64 %op6401, ptr %slot854, align 8
  %v6402 = load i64, ptr %slot854, align 8
  %cmp6403 = icmp eq i64 %v6402, 0
  %cv6404 = zext i1 %cmp6403 to i32
  store i32 %cv6404, ptr %slot855, align 8
  %v6405 = load i32, ptr %slot855, align 8
  %cv6406 = zext i32 %v6405 to i64
  %cond6407 = icmp ne i64 %cv6406, 0
  br i1 %cond6407, label %bb_rcglimit982, label %bb_rcgcapacity982
bb_rcglimit982:
  %v6408 = load i64, ptr %slot1, align 8
  %p6409 = inttoptr i64 %v6408 to ptr
  %call6410 = call i32 @myl_qbe_rc_status(ptr %p6409, i32 2) nomerge, !dbg !142
  store i32 %call6410, ptr %slot856, align 8
  br label %bb_failure
bb_rcgcapacity982:
  %v6411 = load i64, ptr %slot854, align 8
  %v6412 = load i64, ptr %slot846, align 8
  %p6413 = inttoptr i64 %v6412 to ptr
  %rgep6414 = getelementptr i8, ptr %p6413, i64 -24
  store i64 %v6411, ptr %rgep6414, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore982
bb_rcgstore982:
  %v6415 = load i64, ptr %slot846, align 8
  %v6416 = load i64, ptr %slot845, align 8
  %p6417 = inttoptr i64 %v6416 to ptr
  store i64 %v6415, ptr %p6417, align 8, !alias.scope !3, !noalias !4
  %v6418 = load i64, ptr %slot47, align 8
  %p6419 = inttoptr i64 %v6418 to ptr
  store i32 2, ptr %p6419, align 4, !alias.scope !3, !noalias !4
  %v6420 = load i64, ptr %slot47, align 8
  %p6421 = inttoptr i64 %v6420 to ptr
  store i32 16, ptr %p6421, align 4, !alias.scope !3, !noalias !4
  %v6422 = load i64, ptr %slot46, align 8
  %p6423 = inttoptr i64 %v6422 to ptr
  store i32 1, ptr %p6423, align 4, !alias.scope !3, !noalias !4
  %v6424 = load i64, ptr %slot30, align 8
  %p6425 = inttoptr i64 %v6424 to ptr
  %ld6426 = load i32, ptr %p6425, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6426, ptr %slot857, align 8
  %v6427 = load i32, ptr %slot857, align 8
  %cv6428 = zext i32 %v6427 to i64
  %cond6429 = icmp ne i64 %cv6428, 0
  br i1 %cond6429, label %bb_rcslotdrop998, label %bb_rcslotdone998
bb_rcslotdrop998:
  %v6430 = load i64, ptr %slot30, align 8
  %p6431 = inttoptr i64 %v6430 to ptr
  store i32 0, ptr %p6431, align 4, !alias.scope !3, !noalias !4
  %v6432 = load i64, ptr %slot50, align 8
  store i64 %v6432, ptr %slot858, align 8
  %v6433 = load i64, ptr %slot31, align 8
  %p6434 = inttoptr i64 %v6433 to ptr
  %ld6435 = load i32, ptr %p6434, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6435, ptr %slot859, align 8
  %v6436 = load i32, ptr %slot859, align 8
  %op6437 = and i32 %v6436, 28
  store i32 %op6437, ptr %slot860, align 8
  %v6438 = load i32, ptr %slot860, align 8
  %cv6439 = zext i32 %v6438 to i64
  %cond6440 = icmp ne i64 %cv6439, 0
  br i1 %cond6440, label %bb_rcslotrole998, label %bb_rcslotowner998
bb_rcslotrole998:
  %v6441 = load i64, ptr %slot110, align 8
  store i64 %v6441, ptr %slot861, align 8
  %v6442 = load i64, ptr %slot858, align 8
  %p6443 = inttoptr i64 %v6442 to ptr
  %ld6444 = load i64, ptr %p6443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6444, ptr %slot862, align 8
  %v6445 = load i64, ptr %slot862, align 8
  %cmp6446 = icmp ne i64 %v6445, 0
  %cv6447 = zext i1 %cmp6446 to i32
  store i32 %cv6447, ptr %slot863, align 8
  %v6448 = load i32, ptr %slot863, align 8
  %cv6449 = zext i32 %v6448 to i64
  %cond6450 = icmp ne i64 %cv6449, 0
  br i1 %cond6450, label %bb_rcgnn1014, label %bb_rcgdone1014
bb_rcgnn1014:
  %v6451 = load i64, ptr %slot862, align 8
  %op6452 = sub i64 %v6451, 16
  store i64 %op6452, ptr %slot864, align 8
  %v6453 = load i64, ptr %slot862, align 8
  %p6454 = inttoptr i64 %v6453 to ptr
  %rgep6455 = getelementptr i8, ptr %p6454, i64 -16
  %ld6456 = load i64, ptr %rgep6455, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6456, ptr %slot865, align 8
  %v6457 = load i64, ptr %slot865, align 8
  %op6458 = and i64 %v6457, 4611686018427387906
  store i64 %op6458, ptr %slot866, align 8
  %v6459 = load i64, ptr %slot866, align 8
  %cmp6460 = icmp ne i64 %v6459, 0
  %cv6461 = zext i1 %cmp6460 to i32
  store i32 %cv6461, ptr %slot867, align 8
  %v6462 = load i32, ptr %slot867, align 8
  %cv6463 = zext i32 %v6462 to i64
  %cond6464 = icmp ne i64 %cv6463, 0
  br i1 %cond6464, label %bb_rcgclear1014, label %bb_rcgcounted1014
bb_rcgcounted1014:
  %v6465 = load i64, ptr %slot862, align 8
  %op6466 = sub i64 %v6465, 24
  store i64 %op6466, ptr %slot868, align 8
  %v6467 = load i64, ptr %slot862, align 8
  %p6468 = inttoptr i64 %v6467 to ptr
  %rgep6469 = getelementptr i8, ptr %p6468, i64 -24
  %ld6470 = load i64, ptr %rgep6469, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6470, ptr %slot869, align 8
  %v6471 = load i64, ptr %slot869, align 8
  %op6472 = sub i64 %v6471, 1
  store i64 %op6472, ptr %slot870, align 8
  %v6473 = load i64, ptr %slot870, align 8
  %cmp6474 = icmp eq i64 %v6473, 0
  %cv6475 = zext i1 %cmp6474 to i32
  store i32 %cv6475, ptr %slot871, align 8
  %v6476 = load i32, ptr %slot871, align 8
  %cv6477 = zext i32 %v6476 to i64
  %cond6478 = icmp ne i64 %cv6477, 0
  br i1 %cond6478, label %bb_rcglast1014, label %bb_rcgdec1014
bb_rcglast1014:
  %v6479 = load i64, ptr %slot862, align 8
  %op6480 = sub i64 %v6479, 32
  store i64 %op6480, ptr %slot872, align 8
  %v6481 = load i64, ptr %slot862, align 8
  %p6482 = inttoptr i64 %v6481 to ptr
  %rgep6483 = getelementptr i8, ptr %p6482, i64 -32
  %ld6484 = load i64, ptr %rgep6483, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6484, ptr %slot873, align 8
  %v6485 = load i64, ptr %slot873, align 8
  %cmp6486 = icmp ne i64 %v6485, 0
  %cv6487 = zext i1 %cmp6486 to i32
  store i32 %cv6487, ptr %slot874, align 8
  %v6488 = load i32, ptr %slot874, align 8
  %cv6489 = zext i32 %v6488 to i64
  %cond6490 = icmp ne i64 %cv6489, 0
  br i1 %cond6490, label %bb_rcgdec1014, label %bb_rcgslow1014
bb_rcgslow1014:
  %v6491 = load i64, ptr %slot861, align 8
  %v6492 = load i64, ptr %slot858, align 8
  call void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_unloan(i64 %v6491, i64 %v6492) nomerge, !dbg !142
  br label %bb_rcgdone1014
bb_rcgdec1014:
  %v6493 = load i64, ptr %slot870, align 8
  %v6494 = load i64, ptr %slot862, align 8
  %p6495 = inttoptr i64 %v6494 to ptr
  %rgep6496 = getelementptr i8, ptr %p6495, i64 -24
  store i64 %v6493, ptr %rgep6496, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1014
bb_rcgclear1014:
  %v6497 = load i64, ptr %slot858, align 8
  %p6498 = inttoptr i64 %v6497 to ptr
  store i64 0, ptr %p6498, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1014
bb_rcgdone1014:
  br label %bb_rcslotdone998
bb_rcslotowner998:
  %v6499 = load i64, ptr %slot110, align 8
  store i64 %v6499, ptr %slot875, align 8
  %v6500 = load i64, ptr %slot858, align 8
  %p6501 = inttoptr i64 %v6500 to ptr
  %ld6502 = load i64, ptr %p6501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6502, ptr %slot876, align 8
  %v6503 = load i64, ptr %slot876, align 8
  %cmp6504 = icmp ne i64 %v6503, 0
  %cv6505 = zext i1 %cmp6504 to i32
  store i32 %cv6505, ptr %slot877, align 8
  %v6506 = load i32, ptr %slot877, align 8
  %cv6507 = zext i32 %v6506 to i64
  %cond6508 = icmp ne i64 %cv6507, 0
  br i1 %cond6508, label %bb_rcgnn1029, label %bb_rcgdone1029
bb_rcgnn1029:
  %v6509 = load i64, ptr %slot876, align 8
  %op6510 = sub i64 %v6509, 16
  store i64 %op6510, ptr %slot878, align 8
  %v6511 = load i64, ptr %slot876, align 8
  %p6512 = inttoptr i64 %v6511 to ptr
  %rgep6513 = getelementptr i8, ptr %p6512, i64 -16
  %ld6514 = load i64, ptr %rgep6513, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6514, ptr %slot879, align 8
  %v6515 = load i64, ptr %slot879, align 8
  %op6516 = and i64 %v6515, 4611686018427387906
  store i64 %op6516, ptr %slot880, align 8
  %v6517 = load i64, ptr %slot880, align 8
  %cmp6518 = icmp ne i64 %v6517, 0
  %cv6519 = zext i1 %cmp6518 to i32
  store i32 %cv6519, ptr %slot881, align 8
  %v6520 = load i32, ptr %slot881, align 8
  %cv6521 = zext i32 %v6520 to i64
  %cond6522 = icmp ne i64 %cv6521, 0
  br i1 %cond6522, label %bb_rcgclear1029, label %bb_rcgcounted1029
bb_rcgcounted1029:
  %v6523 = load i64, ptr %slot876, align 8
  %op6524 = sub i64 %v6523, 32
  store i64 %op6524, ptr %slot882, align 8
  %v6525 = load i64, ptr %slot876, align 8
  %p6526 = inttoptr i64 %v6525 to ptr
  %rgep6527 = getelementptr i8, ptr %p6526, i64 -32
  %ld6528 = load i64, ptr %rgep6527, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6528, ptr %slot883, align 8
  %v6529 = load i64, ptr %slot883, align 8
  %op6530 = sub i64 %v6529, 1
  store i64 %op6530, ptr %slot884, align 8
  %v6531 = load i64, ptr %slot884, align 8
  %cmp6532 = icmp eq i64 %v6531, 0
  %cv6533 = zext i1 %cmp6532 to i32
  store i32 %cv6533, ptr %slot885, align 8
  %v6534 = load i32, ptr %slot885, align 8
  %cv6535 = zext i32 %v6534 to i64
  %cond6536 = icmp ne i64 %cv6535, 0
  br i1 %cond6536, label %bb_rcglast1029, label %bb_rcgdec1029
bb_rcglast1029:
  %v6537 = load i64, ptr %slot876, align 8
  %op6538 = sub i64 %v6537, 24
  store i64 %op6538, ptr %slot886, align 8
  %v6539 = load i64, ptr %slot876, align 8
  %p6540 = inttoptr i64 %v6539 to ptr
  %rgep6541 = getelementptr i8, ptr %p6540, i64 -24
  %ld6542 = load i64, ptr %rgep6541, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6542, ptr %slot887, align 8
  %v6543 = load i64, ptr %slot887, align 8
  %cmp6544 = icmp ne i64 %v6543, 0
  %cv6545 = zext i1 %cmp6544 to i32
  store i32 %cv6545, ptr %slot888, align 8
  %v6546 = load i32, ptr %slot888, align 8
  %cv6547 = zext i32 %v6546 to i64
  %cond6548 = icmp ne i64 %cv6547, 0
  br i1 %cond6548, label %bb_rcgdec1029, label %bb_rcgslow1029
bb_rcgslow1029:
  %v6549 = load i64, ptr %slot875, align 8
  %v6550 = load i64, ptr %slot858, align 8
  call void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_drop(i64 %v6549, i64 %v6550) nomerge, !dbg !142
  br label %bb_rcgdone1029
bb_rcgdec1029:
  %v6551 = load i64, ptr %slot884, align 8
  %v6552 = load i64, ptr %slot876, align 8
  %p6553 = inttoptr i64 %v6552 to ptr
  %rgep6554 = getelementptr i8, ptr %p6553, i64 -32
  store i64 %v6551, ptr %rgep6554, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1029
bb_rcgclear1029:
  %v6555 = load i64, ptr %slot858, align 8
  %p6556 = inttoptr i64 %v6555 to ptr
  store i64 0, ptr %p6556, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1029
bb_rcgdone1029:
  br label %bb_rcslotdone998
bb_rcslotdone998:
  br label %bb_rcprivateprepared946
bb_rcprivateprepared946:
  %v6557 = load i64, ptr %slot16, align 8
  %p6558 = inttoptr i64 %v6557 to ptr
  %ld6559 = load i32, ptr %p6558, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6559, ptr %slot889, align 8
  %v6560 = load i32, ptr %slot889, align 8
  %cv6561 = zext i32 %v6560 to i64
  %cond6562 = icmp ne i64 %cv6561, 0
  br i1 %cond6562, label %bb_rcslotdrop1036, label %bb_rcslotdone1036
bb_rcslotdrop1036:
  %v6563 = load i64, ptr %slot16, align 8
  %p6564 = inttoptr i64 %v6563 to ptr
  store i32 0, ptr %p6564, align 4, !alias.scope !3, !noalias !4
  %v6565 = load i64, ptr %slot74, align 8
  store i64 %v6565, ptr %slot890, align 8
  %v6566 = load i64, ptr %slot17, align 8
  %p6567 = inttoptr i64 %v6566 to ptr
  %ld6568 = load i32, ptr %p6567, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6568, ptr %slot891, align 8
  %v6569 = load i32, ptr %slot891, align 8
  %op6570 = and i32 %v6569, 28
  store i32 %op6570, ptr %slot892, align 8
  %v6571 = load i32, ptr %slot892, align 8
  %cv6572 = zext i32 %v6571 to i64
  %cond6573 = icmp ne i64 %cv6572, 0
  br i1 %cond6573, label %bb_rcslotrole1036, label %bb_rcslotowner1036
bb_rcslotrole1036:
  %v6574 = load i64, ptr %slot110, align 8
  store i64 %v6574, ptr %slot893, align 8
  %v6575 = load i64, ptr %slot890, align 8
  %p6576 = inttoptr i64 %v6575 to ptr
  %ld6577 = load i64, ptr %p6576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6577, ptr %slot894, align 8
  %v6578 = load i64, ptr %slot894, align 8
  %cmp6579 = icmp ne i64 %v6578, 0
  %cv6580 = zext i1 %cmp6579 to i32
  store i32 %cv6580, ptr %slot895, align 8
  %v6581 = load i32, ptr %slot895, align 8
  %cv6582 = zext i32 %v6581 to i64
  %cond6583 = icmp ne i64 %cv6582, 0
  br i1 %cond6583, label %bb_rcgnn1052, label %bb_rcgdone1052
bb_rcgnn1052:
  %v6584 = load i64, ptr %slot894, align 8
  %op6585 = sub i64 %v6584, 16
  store i64 %op6585, ptr %slot896, align 8
  %v6586 = load i64, ptr %slot894, align 8
  %p6587 = inttoptr i64 %v6586 to ptr
  %rgep6588 = getelementptr i8, ptr %p6587, i64 -16
  %ld6589 = load i64, ptr %rgep6588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6589, ptr %slot897, align 8
  %v6590 = load i64, ptr %slot897, align 8
  %op6591 = and i64 %v6590, 4611686018427387906
  store i64 %op6591, ptr %slot898, align 8
  %v6592 = load i64, ptr %slot898, align 8
  %cmp6593 = icmp ne i64 %v6592, 0
  %cv6594 = zext i1 %cmp6593 to i32
  store i32 %cv6594, ptr %slot899, align 8
  %v6595 = load i32, ptr %slot899, align 8
  %cv6596 = zext i32 %v6595 to i64
  %cond6597 = icmp ne i64 %cv6596, 0
  br i1 %cond6597, label %bb_rcgclear1052, label %bb_rcgcounted1052
bb_rcgcounted1052:
  %v6598 = load i64, ptr %slot894, align 8
  %op6599 = sub i64 %v6598, 24
  store i64 %op6599, ptr %slot900, align 8
  %v6600 = load i64, ptr %slot894, align 8
  %p6601 = inttoptr i64 %v6600 to ptr
  %rgep6602 = getelementptr i8, ptr %p6601, i64 -24
  %ld6603 = load i64, ptr %rgep6602, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6603, ptr %slot901, align 8
  %v6604 = load i64, ptr %slot901, align 8
  %op6605 = sub i64 %v6604, 1
  store i64 %op6605, ptr %slot902, align 8
  %v6606 = load i64, ptr %slot902, align 8
  %cmp6607 = icmp eq i64 %v6606, 0
  %cv6608 = zext i1 %cmp6607 to i32
  store i32 %cv6608, ptr %slot903, align 8
  %v6609 = load i32, ptr %slot903, align 8
  %cv6610 = zext i32 %v6609 to i64
  %cond6611 = icmp ne i64 %cv6610, 0
  br i1 %cond6611, label %bb_rcglast1052, label %bb_rcgdec1052
bb_rcglast1052:
  %v6612 = load i64, ptr %slot894, align 8
  %op6613 = sub i64 %v6612, 32
  store i64 %op6613, ptr %slot904, align 8
  %v6614 = load i64, ptr %slot894, align 8
  %p6615 = inttoptr i64 %v6614 to ptr
  %rgep6616 = getelementptr i8, ptr %p6615, i64 -32
  %ld6617 = load i64, ptr %rgep6616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6617, ptr %slot905, align 8
  %v6618 = load i64, ptr %slot905, align 8
  %cmp6619 = icmp ne i64 %v6618, 0
  %cv6620 = zext i1 %cmp6619 to i32
  store i32 %cv6620, ptr %slot906, align 8
  %v6621 = load i32, ptr %slot906, align 8
  %cv6622 = zext i32 %v6621 to i64
  %cond6623 = icmp ne i64 %cv6622, 0
  br i1 %cond6623, label %bb_rcgdec1052, label %bb_rcgslow1052
bb_rcgslow1052:
  %v6624 = load i64, ptr %slot893, align 8
  %v6625 = load i64, ptr %slot890, align 8
  call void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_unloan(i64 %v6624, i64 %v6625) nomerge, !dbg !142
  br label %bb_rcgdone1052
bb_rcgdec1052:
  %v6626 = load i64, ptr %slot902, align 8
  %v6627 = load i64, ptr %slot894, align 8
  %p6628 = inttoptr i64 %v6627 to ptr
  %rgep6629 = getelementptr i8, ptr %p6628, i64 -24
  store i64 %v6626, ptr %rgep6629, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1052
bb_rcgclear1052:
  %v6630 = load i64, ptr %slot890, align 8
  %p6631 = inttoptr i64 %v6630 to ptr
  store i64 0, ptr %p6631, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1052
bb_rcgdone1052:
  br label %bb_rcslotdone1036
bb_rcslotowner1036:
  %v6632 = load i64, ptr %slot110, align 8
  store i64 %v6632, ptr %slot907, align 8
  %v6633 = load i64, ptr %slot890, align 8
  %p6634 = inttoptr i64 %v6633 to ptr
  %ld6635 = load i64, ptr %p6634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6635, ptr %slot908, align 8
  %v6636 = load i64, ptr %slot908, align 8
  %cmp6637 = icmp ne i64 %v6636, 0
  %cv6638 = zext i1 %cmp6637 to i32
  store i32 %cv6638, ptr %slot909, align 8
  %v6639 = load i32, ptr %slot909, align 8
  %cv6640 = zext i32 %v6639 to i64
  %cond6641 = icmp ne i64 %cv6640, 0
  br i1 %cond6641, label %bb_rcgnn1067, label %bb_rcgdone1067
bb_rcgnn1067:
  %v6642 = load i64, ptr %slot908, align 8
  %op6643 = sub i64 %v6642, 16
  store i64 %op6643, ptr %slot910, align 8
  %v6644 = load i64, ptr %slot908, align 8
  %p6645 = inttoptr i64 %v6644 to ptr
  %rgep6646 = getelementptr i8, ptr %p6645, i64 -16
  %ld6647 = load i64, ptr %rgep6646, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6647, ptr %slot911, align 8
  %v6648 = load i64, ptr %slot911, align 8
  %op6649 = and i64 %v6648, 4611686018427387906
  store i64 %op6649, ptr %slot912, align 8
  %v6650 = load i64, ptr %slot912, align 8
  %cmp6651 = icmp ne i64 %v6650, 0
  %cv6652 = zext i1 %cmp6651 to i32
  store i32 %cv6652, ptr %slot913, align 8
  %v6653 = load i32, ptr %slot913, align 8
  %cv6654 = zext i32 %v6653 to i64
  %cond6655 = icmp ne i64 %cv6654, 0
  br i1 %cond6655, label %bb_rcgclear1067, label %bb_rcgcounted1067
bb_rcgcounted1067:
  %v6656 = load i64, ptr %slot908, align 8
  %op6657 = sub i64 %v6656, 32
  store i64 %op6657, ptr %slot914, align 8
  %v6658 = load i64, ptr %slot908, align 8
  %p6659 = inttoptr i64 %v6658 to ptr
  %rgep6660 = getelementptr i8, ptr %p6659, i64 -32
  %ld6661 = load i64, ptr %rgep6660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6661, ptr %slot915, align 8
  %v6662 = load i64, ptr %slot915, align 8
  %op6663 = sub i64 %v6662, 1
  store i64 %op6663, ptr %slot916, align 8
  %v6664 = load i64, ptr %slot916, align 8
  %cmp6665 = icmp eq i64 %v6664, 0
  %cv6666 = zext i1 %cmp6665 to i32
  store i32 %cv6666, ptr %slot917, align 8
  %v6667 = load i32, ptr %slot917, align 8
  %cv6668 = zext i32 %v6667 to i64
  %cond6669 = icmp ne i64 %cv6668, 0
  br i1 %cond6669, label %bb_rcglast1067, label %bb_rcgdec1067
bb_rcglast1067:
  %v6670 = load i64, ptr %slot908, align 8
  %op6671 = sub i64 %v6670, 24
  store i64 %op6671, ptr %slot918, align 8
  %v6672 = load i64, ptr %slot908, align 8
  %p6673 = inttoptr i64 %v6672 to ptr
  %rgep6674 = getelementptr i8, ptr %p6673, i64 -24
  %ld6675 = load i64, ptr %rgep6674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6675, ptr %slot919, align 8
  %v6676 = load i64, ptr %slot919, align 8
  %cmp6677 = icmp ne i64 %v6676, 0
  %cv6678 = zext i1 %cmp6677 to i32
  store i32 %cv6678, ptr %slot920, align 8
  %v6679 = load i32, ptr %slot920, align 8
  %cv6680 = zext i32 %v6679 to i64
  %cond6681 = icmp ne i64 %cv6680, 0
  br i1 %cond6681, label %bb_rcgdec1067, label %bb_rcgslow1067
bb_rcgslow1067:
  %v6682 = load i64, ptr %slot907, align 8
  %v6683 = load i64, ptr %slot890, align 8
  call void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_drop(i64 %v6682, i64 %v6683) nomerge, !dbg !142
  br label %bb_rcgdone1067
bb_rcgdec1067:
  %v6684 = load i64, ptr %slot916, align 8
  %v6685 = load i64, ptr %slot908, align 8
  %p6686 = inttoptr i64 %v6685 to ptr
  %rgep6687 = getelementptr i8, ptr %p6686, i64 -32
  store i64 %v6684, ptr %rgep6687, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1067
bb_rcgclear1067:
  %v6688 = load i64, ptr %slot890, align 8
  %p6689 = inttoptr i64 %v6688 to ptr
  store i64 0, ptr %p6689, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1067
bb_rcgdone1067:
  br label %bb_rcslotdone1036
bb_rcslotdone1036:
  %v6690 = load i64, ptr %slot74, align 8
  store i64 %v6690, ptr %slot921, align 8
  %v6691 = load i64, ptr %slot65, align 8
  store i64 %v6691, ptr %slot922, align 8
  %v6692 = load i64, ptr %slot922, align 8
  %v6693 = load i64, ptr %slot921, align 8
  %p6694 = inttoptr i64 %v6692 to ptr
  %p6695 = inttoptr i64 %v6693 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6695, ptr %p6694, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6696 = load i64, ptr %slot46, align 8
  %p6697 = inttoptr i64 %v6696 to ptr
  store i32 0, ptr %p6697, align 4, !alias.scope !3, !noalias !4
  %v6698 = load i64, ptr %slot17, align 8
  %p6699 = inttoptr i64 %v6698 to ptr
  store i32 2, ptr %p6699, align 4, !alias.scope !3, !noalias !4
  %v6700 = load i64, ptr %slot47, align 8
  %p6701 = inttoptr i64 %v6700 to ptr
  %ld6702 = load i32, ptr %p6701, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6702, ptr %slot923, align 8
  %v6703 = load i32, ptr %slot923, align 8
  %v6704 = load i64, ptr %slot17, align 8
  %p6705 = inttoptr i64 %v6704 to ptr
  store i32 %v6703, ptr %p6705, align 4, !alias.scope !3, !noalias !4
  %v6706 = load i64, ptr %slot16, align 8
  %p6707 = inttoptr i64 %v6706 to ptr
  store i32 1, ptr %p6707, align 4, !alias.scope !3, !noalias !4
  %v6708 = load i64, ptr %slot74, align 8
  %p6709 = inttoptr i64 %v6708 to ptr
  %ld6710 = load i64, ptr %p6709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6710, ptr %slot924, align 8
  %v6711 = load i64, ptr %slot924, align 8
  %v6712 = load i64, ptr %slot81, align 8
  %p6713 = inttoptr i64 %v6712 to ptr
  store i64 %v6711, ptr %p6713, align 8, !alias.scope !3, !noalias !4
  %v6714 = load i64, ptr %slot82, align 8
  %p6715 = inttoptr i64 %v6714 to ptr
  store i64 0, ptr %p6715, align 8, !alias.scope !3, !noalias !4
  %v6716 = load i64, ptr %slot82, align 8
  %p6717 = inttoptr i64 %v6716 to ptr
  %ld6718 = load i64, ptr %p6717, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6718, ptr %slot925, align 8
  %v6719 = load i64, ptr %slot925, align 8
  %cmp6720 = icmp sge i64 %v6719, 0
  %cv6721 = zext i1 %cmp6720 to i64
  store i64 %cv6721, ptr %slot926, align 8
  %v6722 = load i64, ptr %slot926, align 8
  %cond6723 = icmp ne i64 %v6722, 0
  br i1 %cond6723, label %bb_success1081, label %bb_failed1081
bb_failed1081:
  %v6724 = load i64, ptr %slot1, align 8
  %p6725 = inttoptr i64 %v6724 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p6725) nomerge, !dbg !144
  unreachable
bb_success1081:
  %v6726 = load i64, ptr %slot110, align 8
  %p6727 = inttoptr i64 %v6726 to ptr
  %p6728 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v6729 = load i64, ptr %slot925, align 8
  %call6730 = call ptr @myl_native_list_new(ptr %p6727, ptr %p6728, i64 %v6729) nomerge, !dbg !144
  %calladdr6731 = ptrtoint ptr %call6730 to i64
  store i64 %calladdr6731, ptr %slot927, align 8
  %v6732 = load i64, ptr %slot927, align 8
  %cond6733 = icmp ne i64 %v6732, 0
  br i1 %cond6733, label %bb_success1083, label %bb_failed1083
bb_failed1083:
  %v6734 = load i64, ptr %slot1, align 8
  %p6735 = inttoptr i64 %v6734 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6735) nomerge, !dbg !144
  unreachable
bb_success1083:
  %v6736 = load i64, ptr %slot927, align 8
  %v6737 = load i64, ptr %slot82, align 8
  %p6738 = inttoptr i64 %v6737 to ptr
  store i64 %v6736, ptr %p6738, align 8, !alias.scope !3, !noalias !4
  %v6739 = load i64, ptr %slot82, align 8
  %p6740 = inttoptr i64 %v6739 to ptr
  %ld6741 = load i64, ptr %p6740, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6741, ptr %slot928, align 8
  %v6742 = load i64, ptr %slot928, align 8
  %v6743 = load i64, ptr %slot59, align 8
  %p6744 = inttoptr i64 %v6743 to ptr
  store i64 %v6742, ptr %p6744, align 8, !alias.scope !3, !noalias !4
  %v6745 = load i64, ptr %slot59, align 8
  store i64 %v6745, ptr %slot929, align 8
  %v6746 = load i64, ptr %slot65, align 8
  store i64 %v6746, ptr %slot930, align 8
  %v6747 = load i64, ptr %slot929, align 8
  %v6748 = load i64, ptr %slot930, align 8
  %p6749 = inttoptr i64 %v6747 to ptr
  %p6750 = inttoptr i64 %v6748 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6750, ptr %p6749, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6751 = load i64, ptr %slot47, align 8
  %p6752 = inttoptr i64 %v6751 to ptr
  store i32 2, ptr %p6752, align 4, !alias.scope !3, !noalias !4
  %v6753 = load i64, ptr %slot46, align 8
  %p6754 = inttoptr i64 %v6753 to ptr
  store i32 1, ptr %p6754, align 4, !alias.scope !3, !noalias !4
  %v6755 = load i64, ptr %slot51, align 8
  store i64 %v6755, ptr %slot931, align 8
  %v6756 = load i64, ptr %slot65, align 8
  store i64 %v6756, ptr %slot932, align 8
  %v6757 = load i64, ptr %slot932, align 8
  %v6758 = load i64, ptr %slot931, align 8
  %p6759 = inttoptr i64 %v6757 to ptr
  %p6760 = inttoptr i64 %v6758 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6760, ptr %p6759, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6761 = load i64, ptr %slot33, align 8
  %p6762 = inttoptr i64 %v6761 to ptr
  store i32 2, ptr %p6762, align 4, !alias.scope !3, !noalias !4
  %v6763 = load i64, ptr %slot47, align 8
  %p6764 = inttoptr i64 %v6763 to ptr
  %ld6765 = load i32, ptr %p6764, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6765, ptr %slot933, align 8
  %v6766 = load i32, ptr %slot933, align 8
  %v6767 = load i64, ptr %slot33, align 8
  %p6768 = inttoptr i64 %v6767 to ptr
  store i32 %v6766, ptr %p6768, align 4, !alias.scope !3, !noalias !4
  %v6769 = load i64, ptr %slot46, align 8
  %p6770 = inttoptr i64 %v6769 to ptr
  store i32 0, ptr %p6770, align 4, !alias.scope !3, !noalias !4
  %v6771 = load i64, ptr %slot32, align 8
  %p6772 = inttoptr i64 %v6771 to ptr
  store i32 1, ptr %p6772, align 4, !alias.scope !3, !noalias !4
  %v6773 = load i64, ptr %slot931, align 8
  %p6774 = inttoptr i64 %v6773 to ptr
  %ld6775 = load i64, ptr %p6774, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6775, ptr %slot934, align 8
  %v6776 = load i64, ptr %slot934, align 8
  %v6777 = load i64, ptr %slot82, align 8
  %p6778 = inttoptr i64 %v6777 to ptr
  store i64 %v6776, ptr %p6778, align 8, !alias.scope !3, !noalias !4
  %v6779 = load i64, ptr %slot82, align 8
  %p6780 = inttoptr i64 %v6779 to ptr
  %ld6781 = load i64, ptr %p6780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6781, ptr %slot935, align 8
  %v6782 = load i64, ptr %slot935, align 8
  %v6783 = load i64, ptr %slot59, align 8
  %p6784 = inttoptr i64 %v6783 to ptr
  store i64 %v6782, ptr %p6784, align 8, !alias.scope !3, !noalias !4
  %v6785 = load i64, ptr %slot59, align 8
  store i64 %v6785, ptr %slot936, align 8
  %v6786 = load i64, ptr %slot32, align 8
  %p6787 = inttoptr i64 %v6786 to ptr
  %ld6788 = load i32, ptr %p6787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6788, ptr %slot937, align 8
  %v6789 = load i64, ptr %slot33, align 8
  %p6790 = inttoptr i64 %v6789 to ptr
  %ld6791 = load i32, ptr %p6790, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6791, ptr %slot938, align 8
  %v6792 = load i32, ptr %slot938, align 8
  %op6793 = and i32 %v6792, 24
  store i32 %op6793, ptr %slot938, align 8
  %v6794 = load i32, ptr %slot938, align 8
  %cmp6795 = icmp eq i32 %v6794, 0
  %cv6796 = zext i1 %cmp6795 to i32
  store i32 %cv6796, ptr %slot939, align 8
  %v6797 = load i32, ptr %slot937, align 8
  %v6798 = load i32, ptr %slot939, align 8
  %op6799 = and i32 %v6797, %v6798
  store i32 %op6799, ptr %slot940, align 8
  %v6800 = load i32, ptr %slot940, align 8
  %cv6801 = zext i32 %v6800 to i64
  %cond6802 = icmp ne i64 %cv6801, 0
  br i1 %cond6802, label %bb_rcprivateown1106, label %bb_rcprivateloan1106
bb_rcprivateown1106:
  %v6803 = load i64, ptr %slot65, align 8
  store i64 %v6803, ptr %slot941, align 8
  %v6804 = load i64, ptr %slot111, align 8
  store i64 %v6804, ptr %slot942, align 8
  %v6805 = load i64, ptr %slot936, align 8
  %v6806 = load i64, ptr %slot941, align 8
  %op6807 = sub i64 %v6805, %v6806
  store i64 %op6807, ptr %slot943, align 8
  %v6808 = load i64, ptr %slot941, align 8
  %v6809 = load i64, ptr %slot936, align 8
  %op6810 = sub i64 %v6808, %v6809
  store i64 %op6810, ptr %slot944, align 8
  %v6811 = load i64, ptr %slot943, align 8
  %cmp6812 = icmp ult i64 %v6811, 8
  %cv6813 = zext i1 %cmp6812 to i32
  store i32 %cv6813, ptr %slot945, align 8
  %v6814 = load i64, ptr %slot944, align 8
  %cmp6815 = icmp ult i64 %v6814, 8
  %cv6816 = zext i1 %cmp6815 to i32
  store i32 %cv6816, ptr %slot946, align 8
  %v6817 = load i32, ptr %slot945, align 8
  %v6818 = load i32, ptr %slot946, align 8
  %op6819 = or i32 %v6817, %v6818
  store i32 %op6819, ptr %slot947, align 8
  %v6820 = load i32, ptr %slot947, align 8
  %cv6821 = zext i32 %v6820 to i64
  %cond6822 = icmp ne i64 %cv6821, 0
  br i1 %cond6822, label %bb_rcmoveslow1109, label %bb_rcmovecheck1109
bb_rcmovecheck1109:
  %v6823 = load i64, ptr %slot936, align 8
  %p6825 = inttoptr i64 %v6823 to ptr
  %gep6826 = getelementptr i8, ptr %p6825, i64 0
  %op6824 = ptrtoint ptr %gep6826 to i64
  store i64 %op6824, ptr %slot948, align 8
  %v6827 = load i64, ptr %slot948, align 8
  %p6828 = inttoptr i64 %v6827 to ptr
  %ld6829 = load i64, ptr %p6828, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6829, ptr %slot949, align 8
  %v6830 = load i64, ptr %slot949, align 8
  %cmp6831 = icmp ne i64 %v6830, 0
  %cv6832 = zext i1 %cmp6831 to i32
  store i32 %cv6832, ptr %slot950, align 8
  %v6833 = load i32, ptr %slot950, align 8
  %cv6834 = zext i32 %v6833 to i64
  %cond6835 = icmp ne i64 %cv6834, 0
  br i1 %cond6835, label %bb_rcmoveheader1117, label %bb_rcmovenext1117
bb_rcmoveheader1117:
  %v6836 = load i64, ptr %slot949, align 8
  %op6837 = sub i64 %v6836, 16
  store i64 %op6837, ptr %slot951, align 8
  %v6838 = load i64, ptr %slot949, align 8
  %p6839 = inttoptr i64 %v6838 to ptr
  %rgep6840 = getelementptr i8, ptr %p6839, i64 -16
  %ld6841 = load i64, ptr %rgep6840, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6841, ptr %slot952, align 8
  %v6842 = load i64, ptr %slot952, align 8
  %op6843 = and i64 %v6842, 5764607523034234881
  store i64 %op6843, ptr %slot953, align 8
  %v6844 = load i64, ptr %slot953, align 8
  %cmp6845 = icmp ne i64 %v6844, 0
  %cv6846 = zext i1 %cmp6845 to i32
  store i32 %cv6846, ptr %slot954, align 8
  %v6847 = load i32, ptr %slot954, align 8
  %cv6848 = zext i32 %v6847 to i64
  %cond6849 = icmp ne i64 %cv6848, 0
  br i1 %cond6849, label %bb_rcmoveslow1109, label %bb_rcmovenext1117
bb_rcmovenext1117:
  %v6850 = load i64, ptr %slot936, align 8
  %v6851 = load i64, ptr %slot941, align 8
  %p6852 = inttoptr i64 %v6850 to ptr
  %p6853 = inttoptr i64 %v6851 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6853, ptr %p6852, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6854 = load i64, ptr %slot936, align 8
  %p6855 = inttoptr i64 %v6854 to ptr
  store i64 0, ptr %p6855, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1109
bb_rcmoveslow1109:
  %v6856 = load i64, ptr %slot110, align 8
  %v6857 = load i64, ptr %slot941, align 8
  %v6858 = load i64, ptr %slot936, align 8
  %v6859 = load i64, ptr %slot942, align 8
  %cv6860 = trunc i64 %v6859 to i32
  %call6861 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v6856, i64 %v6857, i64 %v6858, i32 %cv6860) nomerge, !dbg !146
  store i32 %call6861, ptr %slot955, align 8
  %v6862 = load i32, ptr %slot955, align 8
  %cv6863 = zext i32 %v6862 to i64
  %cond6864 = icmp ne i64 %cv6863, 0
  br i1 %cond6864, label %bb_rcsuccess1124, label %bb_rcfailure1124
bb_rcfailure1124:
  %v6865 = load i64, ptr %slot110, align 8
  %p6866 = inttoptr i64 %v6865 to ptr
  %call6867 = call i32 @myl_rc_take_failure(ptr %p6866) nomerge, !dbg !146
  store i32 %call6867, ptr %slot956, align 8
  %v6868 = load i64, ptr %slot1, align 8
  %p6869 = inttoptr i64 %v6868 to ptr
  %v6870 = load i32, ptr %slot956, align 8
  %call6871 = call i32 @myl_qbe_rc_status(ptr %p6869, i32 %v6870) nomerge, !dbg !146
  store i32 %call6871, ptr %slot957, align 8
  br label %bb_failure
bb_rcsuccess1124:
  br label %bb_rcmoved1109
bb_rcmoved1109:
  %v6872 = load i64, ptr %slot32, align 8
  %p6873 = inttoptr i64 %v6872 to ptr
  store i32 0, ptr %p6873, align 4, !alias.scope !3, !noalias !4
  %v6874 = load i64, ptr %slot47, align 8
  %p6875 = inttoptr i64 %v6874 to ptr
  store i32 2, ptr %p6875, align 4, !alias.scope !3, !noalias !4
  %v6876 = load i64, ptr %slot46, align 8
  %p6877 = inttoptr i64 %v6876 to ptr
  store i32 1, ptr %p6877, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1106
bb_rcprivateloan1106:
  %v6878 = load i64, ptr %slot32, align 8
  %p6879 = inttoptr i64 %v6878 to ptr
  %ld6880 = load i32, ptr %p6879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6880, ptr %slot958, align 8
  %v6881 = load i64, ptr %slot33, align 8
  %p6882 = inttoptr i64 %v6881 to ptr
  %ld6883 = load i32, ptr %p6882, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6883, ptr %slot959, align 8
  %v6884 = load i32, ptr %slot959, align 8
  %cmp6885 = icmp eq i32 %v6884, 16
  %cv6886 = zext i1 %cmp6885 to i32
  store i32 %cv6886, ptr %slot960, align 8
  %v6887 = load i32, ptr %slot960, align 8
  %v6888 = load i32, ptr %slot958, align 8
  %op6889 = and i32 %v6887, %v6888
  store i32 %op6889, ptr %slot960, align 8
  %v6890 = load i32, ptr %slot960, align 8
  %cv6891 = zext i32 %v6890 to i64
  %cond6892 = icmp ne i64 %cv6891, 0
  br i1 %cond6892, label %bb_rcprivatemove1106, label %bb_rcprivatenew1106
bb_rcprivatemove1106:
  %v6893 = load i64, ptr %slot65, align 8
  store i64 %v6893, ptr %slot961, align 8
  %v6894 = load i64, ptr %slot936, align 8
  %v6895 = load i64, ptr %slot961, align 8
  %p6896 = inttoptr i64 %v6894 to ptr
  %p6897 = inttoptr i64 %v6895 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6897, ptr %p6896, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6898 = load i64, ptr %slot936, align 8
  %p6899 = inttoptr i64 %v6898 to ptr
  store i64 0, ptr %p6899, align 8, !alias.scope !3, !noalias !4
  %v6900 = load i64, ptr %slot47, align 8
  %p6901 = inttoptr i64 %v6900 to ptr
  store i32 2, ptr %p6901, align 4, !alias.scope !3, !noalias !4
  %v6902 = load i64, ptr %slot47, align 8
  %p6903 = inttoptr i64 %v6902 to ptr
  store i32 16, ptr %p6903, align 4, !alias.scope !3, !noalias !4
  %v6904 = load i64, ptr %slot46, align 8
  %p6905 = inttoptr i64 %v6904 to ptr
  store i32 1, ptr %p6905, align 4, !alias.scope !3, !noalias !4
  %v6906 = load i64, ptr %slot32, align 8
  %p6907 = inttoptr i64 %v6906 to ptr
  store i32 0, ptr %p6907, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1106
bb_rcprivatenew1106:
  %v6908 = load i64, ptr %slot65, align 8
  store i64 %v6908, ptr %slot962, align 8
  %v6909 = load i64, ptr %slot936, align 8
  %p6910 = inttoptr i64 %v6909 to ptr
  %ld6911 = load i64, ptr %p6910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6911, ptr %slot963, align 8
  %v6912 = load i64, ptr %slot963, align 8
  %cmp6913 = icmp ne i64 %v6912, 0
  %cv6914 = zext i1 %cmp6913 to i32
  store i32 %cv6914, ptr %slot964, align 8
  %v6915 = load i32, ptr %slot964, align 8
  %cv6916 = zext i32 %v6915 to i64
  %cond6917 = icmp ne i64 %cv6916, 0
  br i1 %cond6917, label %bb_rcgnn1142, label %bb_rcgstore1142
bb_rcgnn1142:
  %v6918 = load i64, ptr %slot963, align 8
  %op6919 = sub i64 %v6918, 16
  store i64 %op6919, ptr %slot965, align 8
  %v6920 = load i64, ptr %slot963, align 8
  %p6921 = inttoptr i64 %v6920 to ptr
  %rgep6922 = getelementptr i8, ptr %p6921, i64 -16
  %ld6923 = load i64, ptr %rgep6922, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6923, ptr %slot966, align 8
  %v6924 = load i64, ptr %slot966, align 8
  %op6925 = and i64 %v6924, 4611686018427387906
  store i64 %op6925, ptr %slot967, align 8
  %v6926 = load i64, ptr %slot967, align 8
  %cmp6927 = icmp ne i64 %v6926, 0
  %cv6928 = zext i1 %cmp6927 to i32
  store i32 %cv6928, ptr %slot968, align 8
  %v6929 = load i32, ptr %slot968, align 8
  %cv6930 = zext i32 %v6929 to i64
  %cond6931 = icmp ne i64 %cv6930, 0
  br i1 %cond6931, label %bb_rcgstore1142, label %bb_rcginc1142
bb_rcginc1142:
  %v6932 = load i64, ptr %slot963, align 8
  %op6933 = sub i64 %v6932, 24
  store i64 %op6933, ptr %slot969, align 8
  %v6934 = load i64, ptr %slot963, align 8
  %p6935 = inttoptr i64 %v6934 to ptr
  %rgep6936 = getelementptr i8, ptr %p6935, i64 -24
  %ld6937 = load i64, ptr %rgep6936, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6937, ptr %slot970, align 8
  %v6938 = load i64, ptr %slot970, align 8
  %op6939 = add i64 %v6938, 1
  store i64 %op6939, ptr %slot971, align 8
  %v6940 = load i64, ptr %slot971, align 8
  %cmp6941 = icmp eq i64 %v6940, 0
  %cv6942 = zext i1 %cmp6941 to i32
  store i32 %cv6942, ptr %slot972, align 8
  %v6943 = load i32, ptr %slot972, align 8
  %cv6944 = zext i32 %v6943 to i64
  %cond6945 = icmp ne i64 %cv6944, 0
  br i1 %cond6945, label %bb_rcglimit1142, label %bb_rcgcapacity1142
bb_rcglimit1142:
  %v6946 = load i64, ptr %slot1, align 8
  %p6947 = inttoptr i64 %v6946 to ptr
  %call6948 = call i32 @myl_qbe_rc_status(ptr %p6947, i32 2) nomerge, !dbg !146
  store i32 %call6948, ptr %slot973, align 8
  br label %bb_failure
bb_rcgcapacity1142:
  %v6949 = load i64, ptr %slot971, align 8
  %v6950 = load i64, ptr %slot963, align 8
  %p6951 = inttoptr i64 %v6950 to ptr
  %rgep6952 = getelementptr i8, ptr %p6951, i64 -24
  store i64 %v6949, ptr %rgep6952, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1142
bb_rcgstore1142:
  %v6953 = load i64, ptr %slot963, align 8
  %v6954 = load i64, ptr %slot962, align 8
  %p6955 = inttoptr i64 %v6954 to ptr
  store i64 %v6953, ptr %p6955, align 8, !alias.scope !3, !noalias !4
  %v6956 = load i64, ptr %slot47, align 8
  %p6957 = inttoptr i64 %v6956 to ptr
  store i32 2, ptr %p6957, align 4, !alias.scope !3, !noalias !4
  %v6958 = load i64, ptr %slot47, align 8
  %p6959 = inttoptr i64 %v6958 to ptr
  store i32 16, ptr %p6959, align 4, !alias.scope !3, !noalias !4
  %v6960 = load i64, ptr %slot46, align 8
  %p6961 = inttoptr i64 %v6960 to ptr
  store i32 1, ptr %p6961, align 4, !alias.scope !3, !noalias !4
  %v6962 = load i64, ptr %slot32, align 8
  %p6963 = inttoptr i64 %v6962 to ptr
  %ld6964 = load i32, ptr %p6963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6964, ptr %slot974, align 8
  %v6965 = load i32, ptr %slot974, align 8
  %cv6966 = zext i32 %v6965 to i64
  %cond6967 = icmp ne i64 %cv6966, 0
  br i1 %cond6967, label %bb_rcslotdrop1158, label %bb_rcslotdone1158
bb_rcslotdrop1158:
  %v6968 = load i64, ptr %slot32, align 8
  %p6969 = inttoptr i64 %v6968 to ptr
  store i32 0, ptr %p6969, align 4, !alias.scope !3, !noalias !4
  %v6970 = load i64, ptr %slot51, align 8
  store i64 %v6970, ptr %slot975, align 8
  %v6971 = load i64, ptr %slot33, align 8
  %p6972 = inttoptr i64 %v6971 to ptr
  %ld6973 = load i32, ptr %p6972, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6973, ptr %slot976, align 8
  %v6974 = load i32, ptr %slot976, align 8
  %op6975 = and i32 %v6974, 28
  store i32 %op6975, ptr %slot977, align 8
  %v6976 = load i32, ptr %slot977, align 8
  %cv6977 = zext i32 %v6976 to i64
  %cond6978 = icmp ne i64 %cv6977, 0
  br i1 %cond6978, label %bb_rcslotrole1158, label %bb_rcslotowner1158
bb_rcslotrole1158:
  %v6979 = load i64, ptr %slot110, align 8
  store i64 %v6979, ptr %slot978, align 8
  %v6980 = load i64, ptr %slot975, align 8
  %p6981 = inttoptr i64 %v6980 to ptr
  %ld6982 = load i64, ptr %p6981, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6982, ptr %slot979, align 8
  %v6983 = load i64, ptr %slot979, align 8
  %cmp6984 = icmp ne i64 %v6983, 0
  %cv6985 = zext i1 %cmp6984 to i32
  store i32 %cv6985, ptr %slot980, align 8
  %v6986 = load i32, ptr %slot980, align 8
  %cv6987 = zext i32 %v6986 to i64
  %cond6988 = icmp ne i64 %cv6987, 0
  br i1 %cond6988, label %bb_rcgnn1174, label %bb_rcgdone1174
bb_rcgnn1174:
  %v6989 = load i64, ptr %slot979, align 8
  %op6990 = sub i64 %v6989, 16
  store i64 %op6990, ptr %slot981, align 8
  %v6991 = load i64, ptr %slot979, align 8
  %p6992 = inttoptr i64 %v6991 to ptr
  %rgep6993 = getelementptr i8, ptr %p6992, i64 -16
  %ld6994 = load i64, ptr %rgep6993, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6994, ptr %slot982, align 8
  %v6995 = load i64, ptr %slot982, align 8
  %op6996 = and i64 %v6995, 4611686018427387906
  store i64 %op6996, ptr %slot983, align 8
  %v6997 = load i64, ptr %slot983, align 8
  %cmp6998 = icmp ne i64 %v6997, 0
  %cv6999 = zext i1 %cmp6998 to i32
  store i32 %cv6999, ptr %slot984, align 8
  %v7000 = load i32, ptr %slot984, align 8
  %cv7001 = zext i32 %v7000 to i64
  %cond7002 = icmp ne i64 %cv7001, 0
  br i1 %cond7002, label %bb_rcgclear1174, label %bb_rcgcounted1174
bb_rcgcounted1174:
  %v7003 = load i64, ptr %slot979, align 8
  %op7004 = sub i64 %v7003, 24
  store i64 %op7004, ptr %slot985, align 8
  %v7005 = load i64, ptr %slot979, align 8
  %p7006 = inttoptr i64 %v7005 to ptr
  %rgep7007 = getelementptr i8, ptr %p7006, i64 -24
  %ld7008 = load i64, ptr %rgep7007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7008, ptr %slot986, align 8
  %v7009 = load i64, ptr %slot986, align 8
  %op7010 = sub i64 %v7009, 1
  store i64 %op7010, ptr %slot987, align 8
  %v7011 = load i64, ptr %slot987, align 8
  %cmp7012 = icmp eq i64 %v7011, 0
  %cv7013 = zext i1 %cmp7012 to i32
  store i32 %cv7013, ptr %slot988, align 8
  %v7014 = load i32, ptr %slot988, align 8
  %cv7015 = zext i32 %v7014 to i64
  %cond7016 = icmp ne i64 %cv7015, 0
  br i1 %cond7016, label %bb_rcglast1174, label %bb_rcgdec1174
bb_rcglast1174:
  %v7017 = load i64, ptr %slot979, align 8
  %op7018 = sub i64 %v7017, 32
  store i64 %op7018, ptr %slot989, align 8
  %v7019 = load i64, ptr %slot979, align 8
  %p7020 = inttoptr i64 %v7019 to ptr
  %rgep7021 = getelementptr i8, ptr %p7020, i64 -32
  %ld7022 = load i64, ptr %rgep7021, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7022, ptr %slot990, align 8
  %v7023 = load i64, ptr %slot990, align 8
  %cmp7024 = icmp ne i64 %v7023, 0
  %cv7025 = zext i1 %cmp7024 to i32
  store i32 %cv7025, ptr %slot991, align 8
  %v7026 = load i32, ptr %slot991, align 8
  %cv7027 = zext i32 %v7026 to i64
  %cond7028 = icmp ne i64 %cv7027, 0
  br i1 %cond7028, label %bb_rcgdec1174, label %bb_rcgslow1174
bb_rcgslow1174:
  %v7029 = load i64, ptr %slot978, align 8
  %v7030 = load i64, ptr %slot975, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v7029, i64 %v7030) nomerge, !dbg !146
  br label %bb_rcgdone1174
bb_rcgdec1174:
  %v7031 = load i64, ptr %slot987, align 8
  %v7032 = load i64, ptr %slot979, align 8
  %p7033 = inttoptr i64 %v7032 to ptr
  %rgep7034 = getelementptr i8, ptr %p7033, i64 -24
  store i64 %v7031, ptr %rgep7034, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1174
bb_rcgclear1174:
  %v7035 = load i64, ptr %slot975, align 8
  %p7036 = inttoptr i64 %v7035 to ptr
  store i64 0, ptr %p7036, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1174
bb_rcgdone1174:
  br label %bb_rcslotdone1158
bb_rcslotowner1158:
  %v7037 = load i64, ptr %slot110, align 8
  store i64 %v7037, ptr %slot992, align 8
  %v7038 = load i64, ptr %slot975, align 8
  %p7039 = inttoptr i64 %v7038 to ptr
  %ld7040 = load i64, ptr %p7039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7040, ptr %slot993, align 8
  %v7041 = load i64, ptr %slot993, align 8
  %cmp7042 = icmp ne i64 %v7041, 0
  %cv7043 = zext i1 %cmp7042 to i32
  store i32 %cv7043, ptr %slot994, align 8
  %v7044 = load i32, ptr %slot994, align 8
  %cv7045 = zext i32 %v7044 to i64
  %cond7046 = icmp ne i64 %cv7045, 0
  br i1 %cond7046, label %bb_rcgnn1189, label %bb_rcgdone1189
bb_rcgnn1189:
  %v7047 = load i64, ptr %slot993, align 8
  %op7048 = sub i64 %v7047, 16
  store i64 %op7048, ptr %slot995, align 8
  %v7049 = load i64, ptr %slot993, align 8
  %p7050 = inttoptr i64 %v7049 to ptr
  %rgep7051 = getelementptr i8, ptr %p7050, i64 -16
  %ld7052 = load i64, ptr %rgep7051, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7052, ptr %slot996, align 8
  %v7053 = load i64, ptr %slot996, align 8
  %op7054 = and i64 %v7053, 4611686018427387906
  store i64 %op7054, ptr %slot997, align 8
  %v7055 = load i64, ptr %slot997, align 8
  %cmp7056 = icmp ne i64 %v7055, 0
  %cv7057 = zext i1 %cmp7056 to i32
  store i32 %cv7057, ptr %slot998, align 8
  %v7058 = load i32, ptr %slot998, align 8
  %cv7059 = zext i32 %v7058 to i64
  %cond7060 = icmp ne i64 %cv7059, 0
  br i1 %cond7060, label %bb_rcgclear1189, label %bb_rcgcounted1189
bb_rcgcounted1189:
  %v7061 = load i64, ptr %slot993, align 8
  %op7062 = sub i64 %v7061, 32
  store i64 %op7062, ptr %slot999, align 8
  %v7063 = load i64, ptr %slot993, align 8
  %p7064 = inttoptr i64 %v7063 to ptr
  %rgep7065 = getelementptr i8, ptr %p7064, i64 -32
  %ld7066 = load i64, ptr %rgep7065, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7066, ptr %slot1000, align 8
  %v7067 = load i64, ptr %slot1000, align 8
  %op7068 = sub i64 %v7067, 1
  store i64 %op7068, ptr %slot1001, align 8
  %v7069 = load i64, ptr %slot1001, align 8
  %cmp7070 = icmp eq i64 %v7069, 0
  %cv7071 = zext i1 %cmp7070 to i32
  store i32 %cv7071, ptr %slot1002, align 8
  %v7072 = load i32, ptr %slot1002, align 8
  %cv7073 = zext i32 %v7072 to i64
  %cond7074 = icmp ne i64 %cv7073, 0
  br i1 %cond7074, label %bb_rcglast1189, label %bb_rcgdec1189
bb_rcglast1189:
  %v7075 = load i64, ptr %slot993, align 8
  %op7076 = sub i64 %v7075, 24
  store i64 %op7076, ptr %slot1003, align 8
  %v7077 = load i64, ptr %slot993, align 8
  %p7078 = inttoptr i64 %v7077 to ptr
  %rgep7079 = getelementptr i8, ptr %p7078, i64 -24
  %ld7080 = load i64, ptr %rgep7079, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7080, ptr %slot1004, align 8
  %v7081 = load i64, ptr %slot1004, align 8
  %cmp7082 = icmp ne i64 %v7081, 0
  %cv7083 = zext i1 %cmp7082 to i32
  store i32 %cv7083, ptr %slot1005, align 8
  %v7084 = load i32, ptr %slot1005, align 8
  %cv7085 = zext i32 %v7084 to i64
  %cond7086 = icmp ne i64 %cv7085, 0
  br i1 %cond7086, label %bb_rcgdec1189, label %bb_rcgslow1189
bb_rcgslow1189:
  %v7087 = load i64, ptr %slot992, align 8
  %v7088 = load i64, ptr %slot975, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v7087, i64 %v7088) nomerge, !dbg !146
  br label %bb_rcgdone1189
bb_rcgdec1189:
  %v7089 = load i64, ptr %slot1001, align 8
  %v7090 = load i64, ptr %slot993, align 8
  %p7091 = inttoptr i64 %v7090 to ptr
  %rgep7092 = getelementptr i8, ptr %p7091, i64 -32
  store i64 %v7089, ptr %rgep7092, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1189
bb_rcgclear1189:
  %v7093 = load i64, ptr %slot975, align 8
  %p7094 = inttoptr i64 %v7093 to ptr
  store i64 0, ptr %p7094, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1189
bb_rcgdone1189:
  br label %bb_rcslotdone1158
bb_rcslotdone1158:
  br label %bb_rcprivateprepared1106
bb_rcprivateprepared1106:
  %v7095 = load i64, ptr %slot18, align 8
  %p7096 = inttoptr i64 %v7095 to ptr
  %ld7097 = load i32, ptr %p7096, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7097, ptr %slot1006, align 8
  %v7098 = load i32, ptr %slot1006, align 8
  %cv7099 = zext i32 %v7098 to i64
  %cond7100 = icmp ne i64 %cv7099, 0
  br i1 %cond7100, label %bb_rcslotdrop1196, label %bb_rcslotdone1196
bb_rcslotdrop1196:
  %v7101 = load i64, ptr %slot18, align 8
  %p7102 = inttoptr i64 %v7101 to ptr
  store i32 0, ptr %p7102, align 4, !alias.scope !3, !noalias !4
  %v7103 = load i64, ptr %slot75, align 8
  store i64 %v7103, ptr %slot1007, align 8
  %v7104 = load i64, ptr %slot19, align 8
  %p7105 = inttoptr i64 %v7104 to ptr
  %ld7106 = load i32, ptr %p7105, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7106, ptr %slot1008, align 8
  %v7107 = load i32, ptr %slot1008, align 8
  %op7108 = and i32 %v7107, 28
  store i32 %op7108, ptr %slot1009, align 8
  %v7109 = load i32, ptr %slot1009, align 8
  %cv7110 = zext i32 %v7109 to i64
  %cond7111 = icmp ne i64 %cv7110, 0
  br i1 %cond7111, label %bb_rcslotrole1196, label %bb_rcslotowner1196
bb_rcslotrole1196:
  %v7112 = load i64, ptr %slot110, align 8
  store i64 %v7112, ptr %slot1010, align 8
  %v7113 = load i64, ptr %slot1007, align 8
  %p7114 = inttoptr i64 %v7113 to ptr
  %ld7115 = load i64, ptr %p7114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7115, ptr %slot1011, align 8
  %v7116 = load i64, ptr %slot1011, align 8
  %cmp7117 = icmp ne i64 %v7116, 0
  %cv7118 = zext i1 %cmp7117 to i32
  store i32 %cv7118, ptr %slot1012, align 8
  %v7119 = load i32, ptr %slot1012, align 8
  %cv7120 = zext i32 %v7119 to i64
  %cond7121 = icmp ne i64 %cv7120, 0
  br i1 %cond7121, label %bb_rcgnn1212, label %bb_rcgdone1212
bb_rcgnn1212:
  %v7122 = load i64, ptr %slot1011, align 8
  %op7123 = sub i64 %v7122, 16
  store i64 %op7123, ptr %slot1013, align 8
  %v7124 = load i64, ptr %slot1011, align 8
  %p7125 = inttoptr i64 %v7124 to ptr
  %rgep7126 = getelementptr i8, ptr %p7125, i64 -16
  %ld7127 = load i64, ptr %rgep7126, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7127, ptr %slot1014, align 8
  %v7128 = load i64, ptr %slot1014, align 8
  %op7129 = and i64 %v7128, 4611686018427387906
  store i64 %op7129, ptr %slot1015, align 8
  %v7130 = load i64, ptr %slot1015, align 8
  %cmp7131 = icmp ne i64 %v7130, 0
  %cv7132 = zext i1 %cmp7131 to i32
  store i32 %cv7132, ptr %slot1016, align 8
  %v7133 = load i32, ptr %slot1016, align 8
  %cv7134 = zext i32 %v7133 to i64
  %cond7135 = icmp ne i64 %cv7134, 0
  br i1 %cond7135, label %bb_rcgclear1212, label %bb_rcgcounted1212
bb_rcgcounted1212:
  %v7136 = load i64, ptr %slot1011, align 8
  %op7137 = sub i64 %v7136, 24
  store i64 %op7137, ptr %slot1017, align 8
  %v7138 = load i64, ptr %slot1011, align 8
  %p7139 = inttoptr i64 %v7138 to ptr
  %rgep7140 = getelementptr i8, ptr %p7139, i64 -24
  %ld7141 = load i64, ptr %rgep7140, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7141, ptr %slot1018, align 8
  %v7142 = load i64, ptr %slot1018, align 8
  %op7143 = sub i64 %v7142, 1
  store i64 %op7143, ptr %slot1019, align 8
  %v7144 = load i64, ptr %slot1019, align 8
  %cmp7145 = icmp eq i64 %v7144, 0
  %cv7146 = zext i1 %cmp7145 to i32
  store i32 %cv7146, ptr %slot1020, align 8
  %v7147 = load i32, ptr %slot1020, align 8
  %cv7148 = zext i32 %v7147 to i64
  %cond7149 = icmp ne i64 %cv7148, 0
  br i1 %cond7149, label %bb_rcglast1212, label %bb_rcgdec1212
bb_rcglast1212:
  %v7150 = load i64, ptr %slot1011, align 8
  %op7151 = sub i64 %v7150, 32
  store i64 %op7151, ptr %slot1021, align 8
  %v7152 = load i64, ptr %slot1011, align 8
  %p7153 = inttoptr i64 %v7152 to ptr
  %rgep7154 = getelementptr i8, ptr %p7153, i64 -32
  %ld7155 = load i64, ptr %rgep7154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7155, ptr %slot1022, align 8
  %v7156 = load i64, ptr %slot1022, align 8
  %cmp7157 = icmp ne i64 %v7156, 0
  %cv7158 = zext i1 %cmp7157 to i32
  store i32 %cv7158, ptr %slot1023, align 8
  %v7159 = load i32, ptr %slot1023, align 8
  %cv7160 = zext i32 %v7159 to i64
  %cond7161 = icmp ne i64 %cv7160, 0
  br i1 %cond7161, label %bb_rcgdec1212, label %bb_rcgslow1212
bb_rcgslow1212:
  %v7162 = load i64, ptr %slot1010, align 8
  %v7163 = load i64, ptr %slot1007, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v7162, i64 %v7163) nomerge, !dbg !146
  br label %bb_rcgdone1212
bb_rcgdec1212:
  %v7164 = load i64, ptr %slot1019, align 8
  %v7165 = load i64, ptr %slot1011, align 8
  %p7166 = inttoptr i64 %v7165 to ptr
  %rgep7167 = getelementptr i8, ptr %p7166, i64 -24
  store i64 %v7164, ptr %rgep7167, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1212
bb_rcgclear1212:
  %v7168 = load i64, ptr %slot1007, align 8
  %p7169 = inttoptr i64 %v7168 to ptr
  store i64 0, ptr %p7169, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1212
bb_rcgdone1212:
  br label %bb_rcslotdone1196
bb_rcslotowner1196:
  %v7170 = load i64, ptr %slot110, align 8
  store i64 %v7170, ptr %slot1024, align 8
  %v7171 = load i64, ptr %slot1007, align 8
  %p7172 = inttoptr i64 %v7171 to ptr
  %ld7173 = load i64, ptr %p7172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7173, ptr %slot1025, align 8
  %v7174 = load i64, ptr %slot1025, align 8
  %cmp7175 = icmp ne i64 %v7174, 0
  %cv7176 = zext i1 %cmp7175 to i32
  store i32 %cv7176, ptr %slot1026, align 8
  %v7177 = load i32, ptr %slot1026, align 8
  %cv7178 = zext i32 %v7177 to i64
  %cond7179 = icmp ne i64 %cv7178, 0
  br i1 %cond7179, label %bb_rcgnn1227, label %bb_rcgdone1227
bb_rcgnn1227:
  %v7180 = load i64, ptr %slot1025, align 8
  %op7181 = sub i64 %v7180, 16
  store i64 %op7181, ptr %slot1027, align 8
  %v7182 = load i64, ptr %slot1025, align 8
  %p7183 = inttoptr i64 %v7182 to ptr
  %rgep7184 = getelementptr i8, ptr %p7183, i64 -16
  %ld7185 = load i64, ptr %rgep7184, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7185, ptr %slot1028, align 8
  %v7186 = load i64, ptr %slot1028, align 8
  %op7187 = and i64 %v7186, 4611686018427387906
  store i64 %op7187, ptr %slot1029, align 8
  %v7188 = load i64, ptr %slot1029, align 8
  %cmp7189 = icmp ne i64 %v7188, 0
  %cv7190 = zext i1 %cmp7189 to i32
  store i32 %cv7190, ptr %slot1030, align 8
  %v7191 = load i32, ptr %slot1030, align 8
  %cv7192 = zext i32 %v7191 to i64
  %cond7193 = icmp ne i64 %cv7192, 0
  br i1 %cond7193, label %bb_rcgclear1227, label %bb_rcgcounted1227
bb_rcgcounted1227:
  %v7194 = load i64, ptr %slot1025, align 8
  %op7195 = sub i64 %v7194, 32
  store i64 %op7195, ptr %slot1031, align 8
  %v7196 = load i64, ptr %slot1025, align 8
  %p7197 = inttoptr i64 %v7196 to ptr
  %rgep7198 = getelementptr i8, ptr %p7197, i64 -32
  %ld7199 = load i64, ptr %rgep7198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7199, ptr %slot1032, align 8
  %v7200 = load i64, ptr %slot1032, align 8
  %op7201 = sub i64 %v7200, 1
  store i64 %op7201, ptr %slot1033, align 8
  %v7202 = load i64, ptr %slot1033, align 8
  %cmp7203 = icmp eq i64 %v7202, 0
  %cv7204 = zext i1 %cmp7203 to i32
  store i32 %cv7204, ptr %slot1034, align 8
  %v7205 = load i32, ptr %slot1034, align 8
  %cv7206 = zext i32 %v7205 to i64
  %cond7207 = icmp ne i64 %cv7206, 0
  br i1 %cond7207, label %bb_rcglast1227, label %bb_rcgdec1227
bb_rcglast1227:
  %v7208 = load i64, ptr %slot1025, align 8
  %op7209 = sub i64 %v7208, 24
  store i64 %op7209, ptr %slot1035, align 8
  %v7210 = load i64, ptr %slot1025, align 8
  %p7211 = inttoptr i64 %v7210 to ptr
  %rgep7212 = getelementptr i8, ptr %p7211, i64 -24
  %ld7213 = load i64, ptr %rgep7212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7213, ptr %slot1036, align 8
  %v7214 = load i64, ptr %slot1036, align 8
  %cmp7215 = icmp ne i64 %v7214, 0
  %cv7216 = zext i1 %cmp7215 to i32
  store i32 %cv7216, ptr %slot1037, align 8
  %v7217 = load i32, ptr %slot1037, align 8
  %cv7218 = zext i32 %v7217 to i64
  %cond7219 = icmp ne i64 %cv7218, 0
  br i1 %cond7219, label %bb_rcgdec1227, label %bb_rcgslow1227
bb_rcgslow1227:
  %v7220 = load i64, ptr %slot1024, align 8
  %v7221 = load i64, ptr %slot1007, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v7220, i64 %v7221) nomerge, !dbg !146
  br label %bb_rcgdone1227
bb_rcgdec1227:
  %v7222 = load i64, ptr %slot1033, align 8
  %v7223 = load i64, ptr %slot1025, align 8
  %p7224 = inttoptr i64 %v7223 to ptr
  %rgep7225 = getelementptr i8, ptr %p7224, i64 -32
  store i64 %v7222, ptr %rgep7225, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1227
bb_rcgclear1227:
  %v7226 = load i64, ptr %slot1007, align 8
  %p7227 = inttoptr i64 %v7226 to ptr
  store i64 0, ptr %p7227, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1227
bb_rcgdone1227:
  br label %bb_rcslotdone1196
bb_rcslotdone1196:
  %v7228 = load i64, ptr %slot75, align 8
  store i64 %v7228, ptr %slot1038, align 8
  %v7229 = load i64, ptr %slot65, align 8
  store i64 %v7229, ptr %slot1039, align 8
  %v7230 = load i64, ptr %slot1039, align 8
  %v7231 = load i64, ptr %slot1038, align 8
  %p7232 = inttoptr i64 %v7230 to ptr
  %p7233 = inttoptr i64 %v7231 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7233, ptr %p7232, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7234 = load i64, ptr %slot46, align 8
  %p7235 = inttoptr i64 %v7234 to ptr
  store i32 0, ptr %p7235, align 4, !alias.scope !3, !noalias !4
  %v7236 = load i64, ptr %slot19, align 8
  %p7237 = inttoptr i64 %v7236 to ptr
  store i32 2, ptr %p7237, align 4, !alias.scope !3, !noalias !4
  %v7238 = load i64, ptr %slot47, align 8
  %p7239 = inttoptr i64 %v7238 to ptr
  %ld7240 = load i32, ptr %p7239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7240, ptr %slot1040, align 8
  %v7241 = load i32, ptr %slot1040, align 8
  %v7242 = load i64, ptr %slot19, align 8
  %p7243 = inttoptr i64 %v7242 to ptr
  store i32 %v7241, ptr %p7243, align 4, !alias.scope !3, !noalias !4
  %v7244 = load i64, ptr %slot18, align 8
  %p7245 = inttoptr i64 %v7244 to ptr
  store i32 1, ptr %p7245, align 4, !alias.scope !3, !noalias !4
  %v7246 = load i64, ptr %slot75, align 8
  %p7247 = inttoptr i64 %v7246 to ptr
  %ld7248 = load i64, ptr %p7247, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7248, ptr %slot1041, align 8
  %v7249 = load i64, ptr %slot1041, align 8
  %v7250 = load i64, ptr %slot82, align 8
  %p7251 = inttoptr i64 %v7250 to ptr
  store i64 %v7249, ptr %p7251, align 8, !alias.scope !3, !noalias !4
  %v7252 = load i64, ptr %slot104, align 8
  store i64 %v7252, ptr %slot1042, align 8
  %v7253 = load i64, ptr %slot1042, align 8
  %p7254 = inttoptr i64 %v7253 to ptr
  store i64 0, ptr %p7254, align 8, !alias.scope !3, !noalias !4
  %v7255 = load i64, ptr %slot1042, align 8
  %p7257 = inttoptr i64 %v7255 to ptr
  %gep7258 = getelementptr i8, ptr %p7257, i64 8
  %op7256 = ptrtoint ptr %gep7258 to i64
  store i64 %op7256, ptr %slot1043, align 8
  %v7259 = load i64, ptr %slot1043, align 8
  %p7260 = inttoptr i64 %v7259 to ptr
  store i64 0, ptr %p7260, align 8, !alias.scope !3, !noalias !4
  %v7261 = load i64, ptr %slot48, align 8
  %p7262 = inttoptr i64 %v7261 to ptr
  store i32 1, ptr %p7262, align 4, !alias.scope !3, !noalias !4
  %v7263 = load i64, ptr %slot111, align 8
  store i64 %v7263, ptr %slot1044, align 8
  %v7264 = load i64, ptr %slot81, align 8
  %p7265 = inttoptr i64 %v7264 to ptr
  %ld7266 = load i64, ptr %p7265, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7266, ptr %slot1045, align 8
  %v7267 = load i64, ptr %slot1045, align 8
  %v7268 = load i64, ptr %slot58, align 8
  %p7269 = inttoptr i64 %v7268 to ptr
  store i64 %v7267, ptr %p7269, align 8, !alias.scope !3, !noalias !4
  %v7270 = load i64, ptr %slot58, align 8
  store i64 %v7270, ptr %slot1046, align 8
  %v7271 = load i64, ptr %slot1042, align 8
  %p7273 = inttoptr i64 %v7271 to ptr
  %gep7274 = getelementptr i8, ptr %p7273, i64 0
  %op7272 = ptrtoint ptr %gep7274 to i64
  store i64 %op7272, ptr %slot1047, align 8
  %v7275 = load i64, ptr %slot81, align 8
  %p7276 = inttoptr i64 %v7275 to ptr
  %ld7277 = load i64, ptr %p7276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7277, ptr %slot1048, align 8
  %v7278 = load i64, ptr %slot1048, align 8
  %v7279 = load i64, ptr %slot58, align 8
  %p7280 = inttoptr i64 %v7279 to ptr
  store i64 %v7278, ptr %p7280, align 8, !alias.scope !3, !noalias !4
  %v7281 = load i64, ptr %slot58, align 8
  store i64 %v7281, ptr %slot1049, align 8
  %v7282 = load i64, ptr %slot30, align 8
  %p7283 = inttoptr i64 %v7282 to ptr
  %ld7284 = load i32, ptr %p7283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7284, ptr %slot1050, align 8
  %v7285 = load i64, ptr %slot31, align 8
  %p7286 = inttoptr i64 %v7285 to ptr
  %ld7287 = load i32, ptr %p7286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7287, ptr %slot1051, align 8
  %v7288 = load i32, ptr %slot1051, align 8
  %op7289 = and i32 %v7288, 24
  store i32 %op7289, ptr %slot1051, align 8
  %v7290 = load i32, ptr %slot1051, align 8
  %cmp7291 = icmp eq i32 %v7290, 0
  %cv7292 = zext i1 %cmp7291 to i32
  store i32 %cv7292, ptr %slot1052, align 8
  %v7293 = load i32, ptr %slot1050, align 8
  %v7294 = load i32, ptr %slot1052, align 8
  %op7295 = and i32 %v7293, %v7294
  store i32 %op7295, ptr %slot1053, align 8
  %v7296 = load i32, ptr %slot1053, align 8
  %cv7297 = zext i32 %v7296 to i64
  %cond7298 = icmp ne i64 %cv7297, 0
  br i1 %cond7298, label %bb_rctake1249, label %bb_rccopy1249
bb_rctake1249:
  %v7299 = load i64, ptr %slot65, align 8
  store i64 %v7299, ptr %slot1054, align 8
  %v7300 = load i64, ptr %slot111, align 8
  store i64 %v7300, ptr %slot1055, align 8
  %v7301 = load i64, ptr %slot1049, align 8
  %v7302 = load i64, ptr %slot1054, align 8
  %op7303 = sub i64 %v7301, %v7302
  store i64 %op7303, ptr %slot1056, align 8
  %v7304 = load i64, ptr %slot1054, align 8
  %v7305 = load i64, ptr %slot1049, align 8
  %op7306 = sub i64 %v7304, %v7305
  store i64 %op7306, ptr %slot1057, align 8
  %v7307 = load i64, ptr %slot1056, align 8
  %cmp7308 = icmp ult i64 %v7307, 8
  %cv7309 = zext i1 %cmp7308 to i32
  store i32 %cv7309, ptr %slot1058, align 8
  %v7310 = load i64, ptr %slot1057, align 8
  %cmp7311 = icmp ult i64 %v7310, 8
  %cv7312 = zext i1 %cmp7311 to i32
  store i32 %cv7312, ptr %slot1059, align 8
  %v7313 = load i32, ptr %slot1058, align 8
  %v7314 = load i32, ptr %slot1059, align 8
  %op7315 = or i32 %v7313, %v7314
  store i32 %op7315, ptr %slot1060, align 8
  %v7316 = load i32, ptr %slot1060, align 8
  %cv7317 = zext i32 %v7316 to i64
  %cond7318 = icmp ne i64 %cv7317, 0
  br i1 %cond7318, label %bb_rcmoveslow1258, label %bb_rcmovecheck1258
bb_rcmovecheck1258:
  %v7319 = load i64, ptr %slot1049, align 8
  %p7321 = inttoptr i64 %v7319 to ptr
  %gep7322 = getelementptr i8, ptr %p7321, i64 0
  %op7320 = ptrtoint ptr %gep7322 to i64
  store i64 %op7320, ptr %slot1061, align 8
  %v7323 = load i64, ptr %slot1061, align 8
  %p7324 = inttoptr i64 %v7323 to ptr
  %ld7325 = load i64, ptr %p7324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7325, ptr %slot1062, align 8
  %v7326 = load i64, ptr %slot1062, align 8
  %cmp7327 = icmp ne i64 %v7326, 0
  %cv7328 = zext i1 %cmp7327 to i32
  store i32 %cv7328, ptr %slot1063, align 8
  %v7329 = load i32, ptr %slot1063, align 8
  %cv7330 = zext i32 %v7329 to i64
  %cond7331 = icmp ne i64 %cv7330, 0
  br i1 %cond7331, label %bb_rcmoveheader1266, label %bb_rcmovenext1266
bb_rcmoveheader1266:
  %v7332 = load i64, ptr %slot1062, align 8
  %op7333 = sub i64 %v7332, 16
  store i64 %op7333, ptr %slot1064, align 8
  %v7334 = load i64, ptr %slot1062, align 8
  %p7335 = inttoptr i64 %v7334 to ptr
  %rgep7336 = getelementptr i8, ptr %p7335, i64 -16
  %ld7337 = load i64, ptr %rgep7336, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7337, ptr %slot1065, align 8
  %v7338 = load i64, ptr %slot1065, align 8
  %op7339 = and i64 %v7338, 5764607523034234881
  store i64 %op7339, ptr %slot1066, align 8
  %v7340 = load i64, ptr %slot1066, align 8
  %cmp7341 = icmp ne i64 %v7340, 0
  %cv7342 = zext i1 %cmp7341 to i32
  store i32 %cv7342, ptr %slot1067, align 8
  %v7343 = load i32, ptr %slot1067, align 8
  %cv7344 = zext i32 %v7343 to i64
  %cond7345 = icmp ne i64 %cv7344, 0
  br i1 %cond7345, label %bb_rcmoveslow1258, label %bb_rcmovenext1266
bb_rcmovenext1266:
  %v7346 = load i64, ptr %slot1049, align 8
  %v7347 = load i64, ptr %slot1054, align 8
  %p7348 = inttoptr i64 %v7346 to ptr
  %p7349 = inttoptr i64 %v7347 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7349, ptr %p7348, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7350 = load i64, ptr %slot1049, align 8
  %p7351 = inttoptr i64 %v7350 to ptr
  store i64 0, ptr %p7351, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1258
bb_rcmoveslow1258:
  %v7352 = load i64, ptr %slot110, align 8
  %v7353 = load i64, ptr %slot1054, align 8
  %v7354 = load i64, ptr %slot1049, align 8
  %v7355 = load i64, ptr %slot1055, align 8
  %cv7356 = trunc i64 %v7355 to i32
  %call7357 = call i32 @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_take(i64 %v7352, i64 %v7353, i64 %v7354, i32 %cv7356) nomerge, !dbg !148
  store i32 %call7357, ptr %slot1068, align 8
  %v7358 = load i32, ptr %slot1068, align 8
  %cv7359 = zext i32 %v7358 to i64
  %cond7360 = icmp ne i64 %cv7359, 0
  br i1 %cond7360, label %bb_rcsuccess1273, label %bb_rcfailure1273
bb_rcfailure1273:
  %v7361 = load i64, ptr %slot110, align 8
  %p7362 = inttoptr i64 %v7361 to ptr
  %call7363 = call i32 @myl_rc_take_failure(ptr %p7362) nomerge, !dbg !148
  store i32 %call7363, ptr %slot1069, align 8
  %v7364 = load i64, ptr %slot1, align 8
  %p7365 = inttoptr i64 %v7364 to ptr
  %v7366 = load i32, ptr %slot1069, align 8
  %call7367 = call i32 @myl_qbe_rc_status(ptr %p7365, i32 %v7366) nomerge, !dbg !148
  store i32 %call7367, ptr %slot1070, align 8
  br label %bb_failure
bb_rcsuccess1273:
  br label %bb_rcmoved1258
bb_rcmoved1258:
  %v7368 = load i64, ptr %slot30, align 8
  %p7369 = inttoptr i64 %v7368 to ptr
  store i32 0, ptr %p7369, align 4, !alias.scope !3, !noalias !4
  %v7370 = load i64, ptr %slot47, align 8
  %p7371 = inttoptr i64 %v7370 to ptr
  store i32 2, ptr %p7371, align 4, !alias.scope !3, !noalias !4
  %v7372 = load i64, ptr %slot46, align 8
  %p7373 = inttoptr i64 %v7372 to ptr
  store i32 1, ptr %p7373, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1249
bb_rccopy1249:
  %v7374 = load i64, ptr %slot65, align 8
  store i64 %v7374, ptr %slot1071, align 8
  %v7375 = load i64, ptr %slot111, align 8
  store i64 %v7375, ptr %slot1072, align 8
  %v7376 = load i64, ptr %slot1049, align 8
  %p7377 = inttoptr i64 %v7376 to ptr
  %ld7378 = load i64, ptr %p7377, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7378, ptr %slot1073, align 8
  %v7379 = load i64, ptr %slot1073, align 8
  %cmp7380 = icmp ne i64 %v7379, 0
  %cv7381 = zext i1 %cmp7380 to i32
  store i32 %cv7381, ptr %slot1074, align 8
  %v7382 = load i32, ptr %slot1074, align 8
  %cv7383 = zext i32 %v7382 to i64
  %cond7384 = icmp ne i64 %cv7383, 0
  br i1 %cond7384, label %bb_rcgnn1282, label %bb_rcgplain1282
bb_rcgnn1282:
  %v7385 = load i64, ptr %slot1073, align 8
  %op7386 = sub i64 %v7385, 16
  store i64 %op7386, ptr %slot1075, align 8
  %v7387 = load i64, ptr %slot1073, align 8
  %p7388 = inttoptr i64 %v7387 to ptr
  %rgep7389 = getelementptr i8, ptr %p7388, i64 -16
  %ld7390 = load i64, ptr %rgep7389, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7390, ptr %slot1076, align 8
  %v7391 = load i64, ptr %slot1076, align 8
  %op7392 = and i64 %v7391, 4611686018427387906
  store i64 %op7392, ptr %slot1077, align 8
  %v7393 = load i64, ptr %slot1077, align 8
  %cmp7394 = icmp ne i64 %v7393, 0
  %cv7395 = zext i1 %cmp7394 to i32
  store i32 %cv7395, ptr %slot1078, align 8
  %v7396 = load i32, ptr %slot1078, align 8
  %cv7397 = zext i32 %v7396 to i64
  %cond7398 = icmp ne i64 %cv7397, 0
  br i1 %cond7398, label %bb_rcgspecial1282, label %bb_rcginc1282
bb_rcginc1282:
  %v7399 = load i64, ptr %slot1073, align 8
  %op7400 = sub i64 %v7399, 32
  store i64 %op7400, ptr %slot1079, align 8
  %v7401 = load i64, ptr %slot1073, align 8
  %p7402 = inttoptr i64 %v7401 to ptr
  %rgep7403 = getelementptr i8, ptr %p7402, i64 -32
  %ld7404 = load i64, ptr %rgep7403, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7404, ptr %slot1080, align 8
  %v7405 = load i64, ptr %slot1080, align 8
  %op7406 = add i64 %v7405, 1
  store i64 %op7406, ptr %slot1081, align 8
  %v7407 = load i64, ptr %slot1081, align 8
  %cmp7408 = icmp eq i64 %v7407, 0
  %cv7409 = zext i1 %cmp7408 to i32
  store i32 %cv7409, ptr %slot1082, align 8
  %v7410 = load i32, ptr %slot1082, align 8
  %cv7411 = zext i32 %v7410 to i64
  %cond7412 = icmp ne i64 %cv7411, 0
  br i1 %cond7412, label %bb_rcglimit1282, label %bb_rcgcapacity1282
bb_rcglimit1282:
  %v7413 = load i64, ptr %slot1, align 8
  %p7414 = inttoptr i64 %v7413 to ptr
  %call7415 = call i32 @myl_qbe_rc_status(ptr %p7414, i32 2) nomerge, !dbg !148
  store i32 %call7415, ptr %slot1083, align 8
  br label %bb_failure
bb_rcgcapacity1282:
  %v7416 = load i64, ptr %slot1081, align 8
  %v7417 = load i64, ptr %slot1073, align 8
  %p7418 = inttoptr i64 %v7417 to ptr
  %rgep7419 = getelementptr i8, ptr %p7418, i64 -32
  store i64 %v7416, ptr %rgep7419, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1282
bb_rcgspecial1282:
  %v7420 = load i64, ptr %slot1076, align 8
  %op7421 = and i64 %v7420, 4611686018427387904
  store i64 %op7421, ptr %slot1084, align 8
  %v7422 = load i64, ptr %slot1084, align 8
  %cmp7423 = icmp ne i64 %v7422, 0
  %cv7424 = zext i1 %cmp7423 to i32
  store i32 %cv7424, ptr %slot1085, align 8
  %v7425 = load i32, ptr %slot1085, align 8
  %cv7426 = zext i32 %v7425 to i64
  %cond7427 = icmp ne i64 %cv7426, 0
  br i1 %cond7427, label %bb_rcgslow1282, label %bb_rcgplain1282
bb_rcgslow1282:
  %v7428 = load i64, ptr %slot110, align 8
  %v7429 = load i64, ptr %slot1071, align 8
  %v7430 = load i64, ptr %slot1049, align 8
  %v7431 = load i64, ptr %slot1072, align 8
  %cv7432 = trunc i64 %v7431 to i32
  %call7433 = call i32 @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_retain(i64 %v7428, i64 %v7429, i64 %v7430, i32 %cv7432) nomerge, !dbg !148
  store i32 %call7433, ptr %slot1086, align 8
  %v7434 = load i32, ptr %slot1086, align 8
  %cv7435 = zext i32 %v7434 to i64
  %cond7436 = icmp ne i64 %cv7435, 0
  br i1 %cond7436, label %bb_rcsuccess1296, label %bb_rcfailure1296
bb_rcfailure1296:
  %v7437 = load i64, ptr %slot110, align 8
  %p7438 = inttoptr i64 %v7437 to ptr
  %call7439 = call i32 @myl_rc_take_failure(ptr %p7438) nomerge, !dbg !148
  store i32 %call7439, ptr %slot1087, align 8
  %v7440 = load i64, ptr %slot1, align 8
  %p7441 = inttoptr i64 %v7440 to ptr
  %v7442 = load i32, ptr %slot1087, align 8
  %call7443 = call i32 @myl_qbe_rc_status(ptr %p7441, i32 %v7442) nomerge, !dbg !148
  store i32 %call7443, ptr %slot1088, align 8
  br label %bb_failure
bb_rcsuccess1296:
  br label %bb_rcgdone1282
bb_rcgplain1282:
  %v7444 = load i64, ptr %slot1073, align 8
  %v7445 = load i64, ptr %slot1071, align 8
  %p7446 = inttoptr i64 %v7445 to ptr
  store i64 %v7444, ptr %p7446, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1282
bb_rcgdone1282:
  %v7447 = load i64, ptr %slot47, align 8
  %p7448 = inttoptr i64 %v7447 to ptr
  store i32 2, ptr %p7448, align 4, !alias.scope !3, !noalias !4
  %v7449 = load i64, ptr %slot46, align 8
  %p7450 = inttoptr i64 %v7449 to ptr
  store i32 1, ptr %p7450, align 4, !alias.scope !3, !noalias !4
  %v7451 = load i64, ptr %slot30, align 8
  %p7452 = inttoptr i64 %v7451 to ptr
  %ld7453 = load i32, ptr %p7452, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7453, ptr %slot1089, align 8
  %v7454 = load i32, ptr %slot1089, align 8
  %cv7455 = zext i32 %v7454 to i64
  %cond7456 = icmp ne i64 %cv7455, 0
  br i1 %cond7456, label %bb_rcslotdrop1303, label %bb_rcslotdone1303
bb_rcslotdrop1303:
  %v7457 = load i64, ptr %slot30, align 8
  %p7458 = inttoptr i64 %v7457 to ptr
  store i32 0, ptr %p7458, align 4, !alias.scope !3, !noalias !4
  %v7459 = load i64, ptr %slot50, align 8
  store i64 %v7459, ptr %slot1090, align 8
  %v7460 = load i64, ptr %slot31, align 8
  %p7461 = inttoptr i64 %v7460 to ptr
  %ld7462 = load i32, ptr %p7461, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7462, ptr %slot1091, align 8
  %v7463 = load i32, ptr %slot1091, align 8
  %op7464 = and i32 %v7463, 28
  store i32 %op7464, ptr %slot1092, align 8
  %v7465 = load i32, ptr %slot1092, align 8
  %cv7466 = zext i32 %v7465 to i64
  %cond7467 = icmp ne i64 %cv7466, 0
  br i1 %cond7467, label %bb_rcslotrole1303, label %bb_rcslotowner1303
bb_rcslotrole1303:
  %v7468 = load i64, ptr %slot110, align 8
  store i64 %v7468, ptr %slot1093, align 8
  %v7469 = load i64, ptr %slot1090, align 8
  %p7470 = inttoptr i64 %v7469 to ptr
  %ld7471 = load i64, ptr %p7470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7471, ptr %slot1094, align 8
  %v7472 = load i64, ptr %slot1094, align 8
  %cmp7473 = icmp ne i64 %v7472, 0
  %cv7474 = zext i1 %cmp7473 to i32
  store i32 %cv7474, ptr %slot1095, align 8
  %v7475 = load i32, ptr %slot1095, align 8
  %cv7476 = zext i32 %v7475 to i64
  %cond7477 = icmp ne i64 %cv7476, 0
  br i1 %cond7477, label %bb_rcgnn1319, label %bb_rcgdone1319
bb_rcgnn1319:
  %v7478 = load i64, ptr %slot1094, align 8
  %op7479 = sub i64 %v7478, 16
  store i64 %op7479, ptr %slot1096, align 8
  %v7480 = load i64, ptr %slot1094, align 8
  %p7481 = inttoptr i64 %v7480 to ptr
  %rgep7482 = getelementptr i8, ptr %p7481, i64 -16
  %ld7483 = load i64, ptr %rgep7482, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7483, ptr %slot1097, align 8
  %v7484 = load i64, ptr %slot1097, align 8
  %op7485 = and i64 %v7484, 4611686018427387906
  store i64 %op7485, ptr %slot1098, align 8
  %v7486 = load i64, ptr %slot1098, align 8
  %cmp7487 = icmp ne i64 %v7486, 0
  %cv7488 = zext i1 %cmp7487 to i32
  store i32 %cv7488, ptr %slot1099, align 8
  %v7489 = load i32, ptr %slot1099, align 8
  %cv7490 = zext i32 %v7489 to i64
  %cond7491 = icmp ne i64 %cv7490, 0
  br i1 %cond7491, label %bb_rcgclear1319, label %bb_rcgcounted1319
bb_rcgcounted1319:
  %v7492 = load i64, ptr %slot1094, align 8
  %op7493 = sub i64 %v7492, 24
  store i64 %op7493, ptr %slot1100, align 8
  %v7494 = load i64, ptr %slot1094, align 8
  %p7495 = inttoptr i64 %v7494 to ptr
  %rgep7496 = getelementptr i8, ptr %p7495, i64 -24
  %ld7497 = load i64, ptr %rgep7496, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7497, ptr %slot1101, align 8
  %v7498 = load i64, ptr %slot1101, align 8
  %op7499 = sub i64 %v7498, 1
  store i64 %op7499, ptr %slot1102, align 8
  %v7500 = load i64, ptr %slot1102, align 8
  %cmp7501 = icmp eq i64 %v7500, 0
  %cv7502 = zext i1 %cmp7501 to i32
  store i32 %cv7502, ptr %slot1103, align 8
  %v7503 = load i32, ptr %slot1103, align 8
  %cv7504 = zext i32 %v7503 to i64
  %cond7505 = icmp ne i64 %cv7504, 0
  br i1 %cond7505, label %bb_rcglast1319, label %bb_rcgdec1319
bb_rcglast1319:
  %v7506 = load i64, ptr %slot1094, align 8
  %op7507 = sub i64 %v7506, 32
  store i64 %op7507, ptr %slot1104, align 8
  %v7508 = load i64, ptr %slot1094, align 8
  %p7509 = inttoptr i64 %v7508 to ptr
  %rgep7510 = getelementptr i8, ptr %p7509, i64 -32
  %ld7511 = load i64, ptr %rgep7510, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7511, ptr %slot1105, align 8
  %v7512 = load i64, ptr %slot1105, align 8
  %cmp7513 = icmp ne i64 %v7512, 0
  %cv7514 = zext i1 %cmp7513 to i32
  store i32 %cv7514, ptr %slot1106, align 8
  %v7515 = load i32, ptr %slot1106, align 8
  %cv7516 = zext i32 %v7515 to i64
  %cond7517 = icmp ne i64 %cv7516, 0
  br i1 %cond7517, label %bb_rcgdec1319, label %bb_rcgslow1319
bb_rcgslow1319:
  %v7518 = load i64, ptr %slot1093, align 8
  %v7519 = load i64, ptr %slot1090, align 8
  call void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_unloan(i64 %v7518, i64 %v7519) nomerge, !dbg !148
  br label %bb_rcgdone1319
bb_rcgdec1319:
  %v7520 = load i64, ptr %slot1102, align 8
  %v7521 = load i64, ptr %slot1094, align 8
  %p7522 = inttoptr i64 %v7521 to ptr
  %rgep7523 = getelementptr i8, ptr %p7522, i64 -24
  store i64 %v7520, ptr %rgep7523, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1319
bb_rcgclear1319:
  %v7524 = load i64, ptr %slot1090, align 8
  %p7525 = inttoptr i64 %v7524 to ptr
  store i64 0, ptr %p7525, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1319
bb_rcgdone1319:
  br label %bb_rcslotdone1303
bb_rcslotowner1303:
  %v7526 = load i64, ptr %slot110, align 8
  store i64 %v7526, ptr %slot1107, align 8
  %v7527 = load i64, ptr %slot1090, align 8
  %p7528 = inttoptr i64 %v7527 to ptr
  %ld7529 = load i64, ptr %p7528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7529, ptr %slot1108, align 8
  %v7530 = load i64, ptr %slot1108, align 8
  %cmp7531 = icmp ne i64 %v7530, 0
  %cv7532 = zext i1 %cmp7531 to i32
  store i32 %cv7532, ptr %slot1109, align 8
  %v7533 = load i32, ptr %slot1109, align 8
  %cv7534 = zext i32 %v7533 to i64
  %cond7535 = icmp ne i64 %cv7534, 0
  br i1 %cond7535, label %bb_rcgnn1334, label %bb_rcgdone1334
bb_rcgnn1334:
  %v7536 = load i64, ptr %slot1108, align 8
  %op7537 = sub i64 %v7536, 16
  store i64 %op7537, ptr %slot1110, align 8
  %v7538 = load i64, ptr %slot1108, align 8
  %p7539 = inttoptr i64 %v7538 to ptr
  %rgep7540 = getelementptr i8, ptr %p7539, i64 -16
  %ld7541 = load i64, ptr %rgep7540, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7541, ptr %slot1111, align 8
  %v7542 = load i64, ptr %slot1111, align 8
  %op7543 = and i64 %v7542, 4611686018427387906
  store i64 %op7543, ptr %slot1112, align 8
  %v7544 = load i64, ptr %slot1112, align 8
  %cmp7545 = icmp ne i64 %v7544, 0
  %cv7546 = zext i1 %cmp7545 to i32
  store i32 %cv7546, ptr %slot1113, align 8
  %v7547 = load i32, ptr %slot1113, align 8
  %cv7548 = zext i32 %v7547 to i64
  %cond7549 = icmp ne i64 %cv7548, 0
  br i1 %cond7549, label %bb_rcgclear1334, label %bb_rcgcounted1334
bb_rcgcounted1334:
  %v7550 = load i64, ptr %slot1108, align 8
  %op7551 = sub i64 %v7550, 32
  store i64 %op7551, ptr %slot1114, align 8
  %v7552 = load i64, ptr %slot1108, align 8
  %p7553 = inttoptr i64 %v7552 to ptr
  %rgep7554 = getelementptr i8, ptr %p7553, i64 -32
  %ld7555 = load i64, ptr %rgep7554, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7555, ptr %slot1115, align 8
  %v7556 = load i64, ptr %slot1115, align 8
  %op7557 = sub i64 %v7556, 1
  store i64 %op7557, ptr %slot1116, align 8
  %v7558 = load i64, ptr %slot1116, align 8
  %cmp7559 = icmp eq i64 %v7558, 0
  %cv7560 = zext i1 %cmp7559 to i32
  store i32 %cv7560, ptr %slot1117, align 8
  %v7561 = load i32, ptr %slot1117, align 8
  %cv7562 = zext i32 %v7561 to i64
  %cond7563 = icmp ne i64 %cv7562, 0
  br i1 %cond7563, label %bb_rcglast1334, label %bb_rcgdec1334
bb_rcglast1334:
  %v7564 = load i64, ptr %slot1108, align 8
  %op7565 = sub i64 %v7564, 24
  store i64 %op7565, ptr %slot1118, align 8
  %v7566 = load i64, ptr %slot1108, align 8
  %p7567 = inttoptr i64 %v7566 to ptr
  %rgep7568 = getelementptr i8, ptr %p7567, i64 -24
  %ld7569 = load i64, ptr %rgep7568, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7569, ptr %slot1119, align 8
  %v7570 = load i64, ptr %slot1119, align 8
  %cmp7571 = icmp ne i64 %v7570, 0
  %cv7572 = zext i1 %cmp7571 to i32
  store i32 %cv7572, ptr %slot1120, align 8
  %v7573 = load i32, ptr %slot1120, align 8
  %cv7574 = zext i32 %v7573 to i64
  %cond7575 = icmp ne i64 %cv7574, 0
  br i1 %cond7575, label %bb_rcgdec1334, label %bb_rcgslow1334
bb_rcgslow1334:
  %v7576 = load i64, ptr %slot1107, align 8
  %v7577 = load i64, ptr %slot1090, align 8
  call void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_drop(i64 %v7576, i64 %v7577) nomerge, !dbg !148
  br label %bb_rcgdone1334
bb_rcgdec1334:
  %v7578 = load i64, ptr %slot1116, align 8
  %v7579 = load i64, ptr %slot1108, align 8
  %p7580 = inttoptr i64 %v7579 to ptr
  %rgep7581 = getelementptr i8, ptr %p7580, i64 -32
  store i64 %v7578, ptr %rgep7581, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1334
bb_rcgclear1334:
  %v7582 = load i64, ptr %slot1090, align 8
  %p7583 = inttoptr i64 %v7582 to ptr
  store i64 0, ptr %p7583, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1334
bb_rcgdone1334:
  br label %bb_rcslotdone1303
bb_rcslotdone1303:
  br label %bb_rcprepared1249
bb_rcprepared1249:
  %v7584 = load i64, ptr %slot65, align 8
  store i64 %v7584, ptr %slot1121, align 8
  %v7585 = load i64, ptr %slot1121, align 8
  %v7586 = load i64, ptr %slot1047, align 8
  %p7587 = inttoptr i64 %v7585 to ptr
  %p7588 = inttoptr i64 %v7586 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7588, ptr %p7587, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7589 = load i64, ptr %slot46, align 8
  %p7590 = inttoptr i64 %v7589 to ptr
  store i32 0, ptr %p7590, align 4, !alias.scope !3, !noalias !4
  %v7591 = load i64, ptr %slot82, align 8
  %p7592 = inttoptr i64 %v7591 to ptr
  %ld7593 = load i64, ptr %p7592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7593, ptr %slot1122, align 8
  %v7594 = load i64, ptr %slot1122, align 8
  %v7595 = load i64, ptr %slot59, align 8
  %p7596 = inttoptr i64 %v7595 to ptr
  store i64 %v7594, ptr %p7596, align 8, !alias.scope !3, !noalias !4
  %v7597 = load i64, ptr %slot59, align 8
  store i64 %v7597, ptr %slot1123, align 8
  %v7598 = load i64, ptr %slot1042, align 8
  %p7600 = inttoptr i64 %v7598 to ptr
  %gep7601 = getelementptr i8, ptr %p7600, i64 8
  %op7599 = ptrtoint ptr %gep7601 to i64
  store i64 %op7599, ptr %slot1124, align 8
  %v7602 = load i64, ptr %slot82, align 8
  %p7603 = inttoptr i64 %v7602 to ptr
  %ld7604 = load i64, ptr %p7603, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7604, ptr %slot1125, align 8
  %v7605 = load i64, ptr %slot1125, align 8
  %v7606 = load i64, ptr %slot59, align 8
  %p7607 = inttoptr i64 %v7606 to ptr
  store i64 %v7605, ptr %p7607, align 8, !alias.scope !3, !noalias !4
  %v7608 = load i64, ptr %slot59, align 8
  store i64 %v7608, ptr %slot1126, align 8
  %v7609 = load i64, ptr %slot32, align 8
  %p7610 = inttoptr i64 %v7609 to ptr
  %ld7611 = load i32, ptr %p7610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7611, ptr %slot1127, align 8
  %v7612 = load i64, ptr %slot33, align 8
  %p7613 = inttoptr i64 %v7612 to ptr
  %ld7614 = load i32, ptr %p7613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7614, ptr %slot1128, align 8
  %v7615 = load i32, ptr %slot1128, align 8
  %op7616 = and i32 %v7615, 24
  store i32 %op7616, ptr %slot1128, align 8
  %v7617 = load i32, ptr %slot1128, align 8
  %cmp7618 = icmp eq i32 %v7617, 0
  %cv7619 = zext i1 %cmp7618 to i32
  store i32 %cv7619, ptr %slot1129, align 8
  %v7620 = load i32, ptr %slot1127, align 8
  %v7621 = load i32, ptr %slot1129, align 8
  %op7622 = and i32 %v7620, %v7621
  store i32 %op7622, ptr %slot1130, align 8
  %v7623 = load i32, ptr %slot1130, align 8
  %cv7624 = zext i32 %v7623 to i64
  %cond7625 = icmp ne i64 %cv7624, 0
  br i1 %cond7625, label %bb_rctake1345, label %bb_rccopy1345
bb_rctake1345:
  %v7626 = load i64, ptr %slot65, align 8
  store i64 %v7626, ptr %slot1131, align 8
  %v7627 = load i64, ptr %slot111, align 8
  store i64 %v7627, ptr %slot1132, align 8
  %v7628 = load i64, ptr %slot1126, align 8
  %v7629 = load i64, ptr %slot1131, align 8
  %op7630 = sub i64 %v7628, %v7629
  store i64 %op7630, ptr %slot1133, align 8
  %v7631 = load i64, ptr %slot1131, align 8
  %v7632 = load i64, ptr %slot1126, align 8
  %op7633 = sub i64 %v7631, %v7632
  store i64 %op7633, ptr %slot1134, align 8
  %v7634 = load i64, ptr %slot1133, align 8
  %cmp7635 = icmp ult i64 %v7634, 8
  %cv7636 = zext i1 %cmp7635 to i32
  store i32 %cv7636, ptr %slot1135, align 8
  %v7637 = load i64, ptr %slot1134, align 8
  %cmp7638 = icmp ult i64 %v7637, 8
  %cv7639 = zext i1 %cmp7638 to i32
  store i32 %cv7639, ptr %slot1136, align 8
  %v7640 = load i32, ptr %slot1135, align 8
  %v7641 = load i32, ptr %slot1136, align 8
  %op7642 = or i32 %v7640, %v7641
  store i32 %op7642, ptr %slot1137, align 8
  %v7643 = load i32, ptr %slot1137, align 8
  %cv7644 = zext i32 %v7643 to i64
  %cond7645 = icmp ne i64 %cv7644, 0
  br i1 %cond7645, label %bb_rcmoveslow1354, label %bb_rcmovecheck1354
bb_rcmovecheck1354:
  %v7646 = load i64, ptr %slot1126, align 8
  %p7648 = inttoptr i64 %v7646 to ptr
  %gep7649 = getelementptr i8, ptr %p7648, i64 0
  %op7647 = ptrtoint ptr %gep7649 to i64
  store i64 %op7647, ptr %slot1138, align 8
  %v7650 = load i64, ptr %slot1138, align 8
  %p7651 = inttoptr i64 %v7650 to ptr
  %ld7652 = load i64, ptr %p7651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7652, ptr %slot1139, align 8
  %v7653 = load i64, ptr %slot1139, align 8
  %cmp7654 = icmp ne i64 %v7653, 0
  %cv7655 = zext i1 %cmp7654 to i32
  store i32 %cv7655, ptr %slot1140, align 8
  %v7656 = load i32, ptr %slot1140, align 8
  %cv7657 = zext i32 %v7656 to i64
  %cond7658 = icmp ne i64 %cv7657, 0
  br i1 %cond7658, label %bb_rcmoveheader1362, label %bb_rcmovenext1362
bb_rcmoveheader1362:
  %v7659 = load i64, ptr %slot1139, align 8
  %op7660 = sub i64 %v7659, 16
  store i64 %op7660, ptr %slot1141, align 8
  %v7661 = load i64, ptr %slot1139, align 8
  %p7662 = inttoptr i64 %v7661 to ptr
  %rgep7663 = getelementptr i8, ptr %p7662, i64 -16
  %ld7664 = load i64, ptr %rgep7663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7664, ptr %slot1142, align 8
  %v7665 = load i64, ptr %slot1142, align 8
  %op7666 = and i64 %v7665, 5764607523034234881
  store i64 %op7666, ptr %slot1143, align 8
  %v7667 = load i64, ptr %slot1143, align 8
  %cmp7668 = icmp ne i64 %v7667, 0
  %cv7669 = zext i1 %cmp7668 to i32
  store i32 %cv7669, ptr %slot1144, align 8
  %v7670 = load i32, ptr %slot1144, align 8
  %cv7671 = zext i32 %v7670 to i64
  %cond7672 = icmp ne i64 %cv7671, 0
  br i1 %cond7672, label %bb_rcmoveslow1354, label %bb_rcmovenext1362
bb_rcmovenext1362:
  %v7673 = load i64, ptr %slot1126, align 8
  %v7674 = load i64, ptr %slot1131, align 8
  %p7675 = inttoptr i64 %v7673 to ptr
  %p7676 = inttoptr i64 %v7674 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7676, ptr %p7675, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7677 = load i64, ptr %slot1126, align 8
  %p7678 = inttoptr i64 %v7677 to ptr
  store i64 0, ptr %p7678, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1354
bb_rcmoveslow1354:
  %v7679 = load i64, ptr %slot110, align 8
  %v7680 = load i64, ptr %slot1131, align 8
  %v7681 = load i64, ptr %slot1126, align 8
  %v7682 = load i64, ptr %slot1132, align 8
  %cv7683 = trunc i64 %v7682 to i32
  %call7684 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v7679, i64 %v7680, i64 %v7681, i32 %cv7683) nomerge, !dbg !148
  store i32 %call7684, ptr %slot1145, align 8
  %v7685 = load i32, ptr %slot1145, align 8
  %cv7686 = zext i32 %v7685 to i64
  %cond7687 = icmp ne i64 %cv7686, 0
  br i1 %cond7687, label %bb_rcsuccess1369, label %bb_rcfailure1369
bb_rcfailure1369:
  %v7688 = load i64, ptr %slot110, align 8
  %p7689 = inttoptr i64 %v7688 to ptr
  %call7690 = call i32 @myl_rc_take_failure(ptr %p7689) nomerge, !dbg !148
  store i32 %call7690, ptr %slot1146, align 8
  %v7691 = load i64, ptr %slot1, align 8
  %p7692 = inttoptr i64 %v7691 to ptr
  %v7693 = load i32, ptr %slot1146, align 8
  %call7694 = call i32 @myl_qbe_rc_status(ptr %p7692, i32 %v7693) nomerge, !dbg !148
  store i32 %call7694, ptr %slot1147, align 8
  br label %bb_failure
bb_rcsuccess1369:
  br label %bb_rcmoved1354
bb_rcmoved1354:
  %v7695 = load i64, ptr %slot32, align 8
  %p7696 = inttoptr i64 %v7695 to ptr
  store i32 0, ptr %p7696, align 4, !alias.scope !3, !noalias !4
  %v7697 = load i64, ptr %slot47, align 8
  %p7698 = inttoptr i64 %v7697 to ptr
  store i32 2, ptr %p7698, align 4, !alias.scope !3, !noalias !4
  %v7699 = load i64, ptr %slot46, align 8
  %p7700 = inttoptr i64 %v7699 to ptr
  store i32 1, ptr %p7700, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1345
bb_rccopy1345:
  %v7701 = load i64, ptr %slot65, align 8
  store i64 %v7701, ptr %slot1148, align 8
  %v7702 = load i64, ptr %slot111, align 8
  store i64 %v7702, ptr %slot1149, align 8
  %v7703 = load i64, ptr %slot1126, align 8
  %p7704 = inttoptr i64 %v7703 to ptr
  %ld7705 = load i64, ptr %p7704, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7705, ptr %slot1150, align 8
  %v7706 = load i64, ptr %slot1150, align 8
  %cmp7707 = icmp ne i64 %v7706, 0
  %cv7708 = zext i1 %cmp7707 to i32
  store i32 %cv7708, ptr %slot1151, align 8
  %v7709 = load i32, ptr %slot1151, align 8
  %cv7710 = zext i32 %v7709 to i64
  %cond7711 = icmp ne i64 %cv7710, 0
  br i1 %cond7711, label %bb_rcgnn1378, label %bb_rcgplain1378
bb_rcgnn1378:
  %v7712 = load i64, ptr %slot1150, align 8
  %op7713 = sub i64 %v7712, 16
  store i64 %op7713, ptr %slot1152, align 8
  %v7714 = load i64, ptr %slot1150, align 8
  %p7715 = inttoptr i64 %v7714 to ptr
  %rgep7716 = getelementptr i8, ptr %p7715, i64 -16
  %ld7717 = load i64, ptr %rgep7716, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7717, ptr %slot1153, align 8
  %v7718 = load i64, ptr %slot1153, align 8
  %op7719 = and i64 %v7718, 4611686018427387906
  store i64 %op7719, ptr %slot1154, align 8
  %v7720 = load i64, ptr %slot1154, align 8
  %cmp7721 = icmp ne i64 %v7720, 0
  %cv7722 = zext i1 %cmp7721 to i32
  store i32 %cv7722, ptr %slot1155, align 8
  %v7723 = load i32, ptr %slot1155, align 8
  %cv7724 = zext i32 %v7723 to i64
  %cond7725 = icmp ne i64 %cv7724, 0
  br i1 %cond7725, label %bb_rcgspecial1378, label %bb_rcginc1378
bb_rcginc1378:
  %v7726 = load i64, ptr %slot1150, align 8
  %op7727 = sub i64 %v7726, 32
  store i64 %op7727, ptr %slot1156, align 8
  %v7728 = load i64, ptr %slot1150, align 8
  %p7729 = inttoptr i64 %v7728 to ptr
  %rgep7730 = getelementptr i8, ptr %p7729, i64 -32
  %ld7731 = load i64, ptr %rgep7730, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7731, ptr %slot1157, align 8
  %v7732 = load i64, ptr %slot1157, align 8
  %op7733 = add i64 %v7732, 1
  store i64 %op7733, ptr %slot1158, align 8
  %v7734 = load i64, ptr %slot1158, align 8
  %cmp7735 = icmp eq i64 %v7734, 0
  %cv7736 = zext i1 %cmp7735 to i32
  store i32 %cv7736, ptr %slot1159, align 8
  %v7737 = load i32, ptr %slot1159, align 8
  %cv7738 = zext i32 %v7737 to i64
  %cond7739 = icmp ne i64 %cv7738, 0
  br i1 %cond7739, label %bb_rcglimit1378, label %bb_rcgcapacity1378
bb_rcglimit1378:
  %v7740 = load i64, ptr %slot1, align 8
  %p7741 = inttoptr i64 %v7740 to ptr
  %call7742 = call i32 @myl_qbe_rc_status(ptr %p7741, i32 2) nomerge, !dbg !148
  store i32 %call7742, ptr %slot1160, align 8
  br label %bb_failure
bb_rcgcapacity1378:
  %v7743 = load i64, ptr %slot1158, align 8
  %v7744 = load i64, ptr %slot1150, align 8
  %p7745 = inttoptr i64 %v7744 to ptr
  %rgep7746 = getelementptr i8, ptr %p7745, i64 -32
  store i64 %v7743, ptr %rgep7746, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1378
bb_rcgspecial1378:
  %v7747 = load i64, ptr %slot1153, align 8
  %op7748 = and i64 %v7747, 4611686018427387904
  store i64 %op7748, ptr %slot1161, align 8
  %v7749 = load i64, ptr %slot1161, align 8
  %cmp7750 = icmp ne i64 %v7749, 0
  %cv7751 = zext i1 %cmp7750 to i32
  store i32 %cv7751, ptr %slot1162, align 8
  %v7752 = load i32, ptr %slot1162, align 8
  %cv7753 = zext i32 %v7752 to i64
  %cond7754 = icmp ne i64 %cv7753, 0
  br i1 %cond7754, label %bb_rcgslow1378, label %bb_rcgplain1378
bb_rcgslow1378:
  %v7755 = load i64, ptr %slot110, align 8
  %v7756 = load i64, ptr %slot1148, align 8
  %v7757 = load i64, ptr %slot1126, align 8
  %v7758 = load i64, ptr %slot1149, align 8
  %cv7759 = trunc i64 %v7758 to i32
  %call7760 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v7755, i64 %v7756, i64 %v7757, i32 %cv7759) nomerge, !dbg !148
  store i32 %call7760, ptr %slot1163, align 8
  %v7761 = load i32, ptr %slot1163, align 8
  %cv7762 = zext i32 %v7761 to i64
  %cond7763 = icmp ne i64 %cv7762, 0
  br i1 %cond7763, label %bb_rcsuccess1392, label %bb_rcfailure1392
bb_rcfailure1392:
  %v7764 = load i64, ptr %slot110, align 8
  %p7765 = inttoptr i64 %v7764 to ptr
  %call7766 = call i32 @myl_rc_take_failure(ptr %p7765) nomerge, !dbg !148
  store i32 %call7766, ptr %slot1164, align 8
  %v7767 = load i64, ptr %slot1, align 8
  %p7768 = inttoptr i64 %v7767 to ptr
  %v7769 = load i32, ptr %slot1164, align 8
  %call7770 = call i32 @myl_qbe_rc_status(ptr %p7768, i32 %v7769) nomerge, !dbg !148
  store i32 %call7770, ptr %slot1165, align 8
  br label %bb_failure
bb_rcsuccess1392:
  br label %bb_rcgdone1378
bb_rcgplain1378:
  %v7771 = load i64, ptr %slot1150, align 8
  %v7772 = load i64, ptr %slot1148, align 8
  %p7773 = inttoptr i64 %v7772 to ptr
  store i64 %v7771, ptr %p7773, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1378
bb_rcgdone1378:
  %v7774 = load i64, ptr %slot47, align 8
  %p7775 = inttoptr i64 %v7774 to ptr
  store i32 2, ptr %p7775, align 4, !alias.scope !3, !noalias !4
  %v7776 = load i64, ptr %slot46, align 8
  %p7777 = inttoptr i64 %v7776 to ptr
  store i32 1, ptr %p7777, align 4, !alias.scope !3, !noalias !4
  %v7778 = load i64, ptr %slot32, align 8
  %p7779 = inttoptr i64 %v7778 to ptr
  %ld7780 = load i32, ptr %p7779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7780, ptr %slot1166, align 8
  %v7781 = load i32, ptr %slot1166, align 8
  %cv7782 = zext i32 %v7781 to i64
  %cond7783 = icmp ne i64 %cv7782, 0
  br i1 %cond7783, label %bb_rcslotdrop1399, label %bb_rcslotdone1399
bb_rcslotdrop1399:
  %v7784 = load i64, ptr %slot32, align 8
  %p7785 = inttoptr i64 %v7784 to ptr
  store i32 0, ptr %p7785, align 4, !alias.scope !3, !noalias !4
  %v7786 = load i64, ptr %slot51, align 8
  store i64 %v7786, ptr %slot1167, align 8
  %v7787 = load i64, ptr %slot33, align 8
  %p7788 = inttoptr i64 %v7787 to ptr
  %ld7789 = load i32, ptr %p7788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7789, ptr %slot1168, align 8
  %v7790 = load i32, ptr %slot1168, align 8
  %op7791 = and i32 %v7790, 28
  store i32 %op7791, ptr %slot1169, align 8
  %v7792 = load i32, ptr %slot1169, align 8
  %cv7793 = zext i32 %v7792 to i64
  %cond7794 = icmp ne i64 %cv7793, 0
  br i1 %cond7794, label %bb_rcslotrole1399, label %bb_rcslotowner1399
bb_rcslotrole1399:
  %v7795 = load i64, ptr %slot110, align 8
  store i64 %v7795, ptr %slot1170, align 8
  %v7796 = load i64, ptr %slot1167, align 8
  %p7797 = inttoptr i64 %v7796 to ptr
  %ld7798 = load i64, ptr %p7797, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7798, ptr %slot1171, align 8
  %v7799 = load i64, ptr %slot1171, align 8
  %cmp7800 = icmp ne i64 %v7799, 0
  %cv7801 = zext i1 %cmp7800 to i32
  store i32 %cv7801, ptr %slot1172, align 8
  %v7802 = load i32, ptr %slot1172, align 8
  %cv7803 = zext i32 %v7802 to i64
  %cond7804 = icmp ne i64 %cv7803, 0
  br i1 %cond7804, label %bb_rcgnn1415, label %bb_rcgdone1415
bb_rcgnn1415:
  %v7805 = load i64, ptr %slot1171, align 8
  %op7806 = sub i64 %v7805, 16
  store i64 %op7806, ptr %slot1173, align 8
  %v7807 = load i64, ptr %slot1171, align 8
  %p7808 = inttoptr i64 %v7807 to ptr
  %rgep7809 = getelementptr i8, ptr %p7808, i64 -16
  %ld7810 = load i64, ptr %rgep7809, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7810, ptr %slot1174, align 8
  %v7811 = load i64, ptr %slot1174, align 8
  %op7812 = and i64 %v7811, 4611686018427387906
  store i64 %op7812, ptr %slot1175, align 8
  %v7813 = load i64, ptr %slot1175, align 8
  %cmp7814 = icmp ne i64 %v7813, 0
  %cv7815 = zext i1 %cmp7814 to i32
  store i32 %cv7815, ptr %slot1176, align 8
  %v7816 = load i32, ptr %slot1176, align 8
  %cv7817 = zext i32 %v7816 to i64
  %cond7818 = icmp ne i64 %cv7817, 0
  br i1 %cond7818, label %bb_rcgclear1415, label %bb_rcgcounted1415
bb_rcgcounted1415:
  %v7819 = load i64, ptr %slot1171, align 8
  %op7820 = sub i64 %v7819, 24
  store i64 %op7820, ptr %slot1177, align 8
  %v7821 = load i64, ptr %slot1171, align 8
  %p7822 = inttoptr i64 %v7821 to ptr
  %rgep7823 = getelementptr i8, ptr %p7822, i64 -24
  %ld7824 = load i64, ptr %rgep7823, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7824, ptr %slot1178, align 8
  %v7825 = load i64, ptr %slot1178, align 8
  %op7826 = sub i64 %v7825, 1
  store i64 %op7826, ptr %slot1179, align 8
  %v7827 = load i64, ptr %slot1179, align 8
  %cmp7828 = icmp eq i64 %v7827, 0
  %cv7829 = zext i1 %cmp7828 to i32
  store i32 %cv7829, ptr %slot1180, align 8
  %v7830 = load i32, ptr %slot1180, align 8
  %cv7831 = zext i32 %v7830 to i64
  %cond7832 = icmp ne i64 %cv7831, 0
  br i1 %cond7832, label %bb_rcglast1415, label %bb_rcgdec1415
bb_rcglast1415:
  %v7833 = load i64, ptr %slot1171, align 8
  %op7834 = sub i64 %v7833, 32
  store i64 %op7834, ptr %slot1181, align 8
  %v7835 = load i64, ptr %slot1171, align 8
  %p7836 = inttoptr i64 %v7835 to ptr
  %rgep7837 = getelementptr i8, ptr %p7836, i64 -32
  %ld7838 = load i64, ptr %rgep7837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7838, ptr %slot1182, align 8
  %v7839 = load i64, ptr %slot1182, align 8
  %cmp7840 = icmp ne i64 %v7839, 0
  %cv7841 = zext i1 %cmp7840 to i32
  store i32 %cv7841, ptr %slot1183, align 8
  %v7842 = load i32, ptr %slot1183, align 8
  %cv7843 = zext i32 %v7842 to i64
  %cond7844 = icmp ne i64 %cv7843, 0
  br i1 %cond7844, label %bb_rcgdec1415, label %bb_rcgslow1415
bb_rcgslow1415:
  %v7845 = load i64, ptr %slot1170, align 8
  %v7846 = load i64, ptr %slot1167, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v7845, i64 %v7846) nomerge, !dbg !148
  br label %bb_rcgdone1415
bb_rcgdec1415:
  %v7847 = load i64, ptr %slot1179, align 8
  %v7848 = load i64, ptr %slot1171, align 8
  %p7849 = inttoptr i64 %v7848 to ptr
  %rgep7850 = getelementptr i8, ptr %p7849, i64 -24
  store i64 %v7847, ptr %rgep7850, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1415
bb_rcgclear1415:
  %v7851 = load i64, ptr %slot1167, align 8
  %p7852 = inttoptr i64 %v7851 to ptr
  store i64 0, ptr %p7852, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1415
bb_rcgdone1415:
  br label %bb_rcslotdone1399
bb_rcslotowner1399:
  %v7853 = load i64, ptr %slot110, align 8
  store i64 %v7853, ptr %slot1184, align 8
  %v7854 = load i64, ptr %slot1167, align 8
  %p7855 = inttoptr i64 %v7854 to ptr
  %ld7856 = load i64, ptr %p7855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7856, ptr %slot1185, align 8
  %v7857 = load i64, ptr %slot1185, align 8
  %cmp7858 = icmp ne i64 %v7857, 0
  %cv7859 = zext i1 %cmp7858 to i32
  store i32 %cv7859, ptr %slot1186, align 8
  %v7860 = load i32, ptr %slot1186, align 8
  %cv7861 = zext i32 %v7860 to i64
  %cond7862 = icmp ne i64 %cv7861, 0
  br i1 %cond7862, label %bb_rcgnn1430, label %bb_rcgdone1430
bb_rcgnn1430:
  %v7863 = load i64, ptr %slot1185, align 8
  %op7864 = sub i64 %v7863, 16
  store i64 %op7864, ptr %slot1187, align 8
  %v7865 = load i64, ptr %slot1185, align 8
  %p7866 = inttoptr i64 %v7865 to ptr
  %rgep7867 = getelementptr i8, ptr %p7866, i64 -16
  %ld7868 = load i64, ptr %rgep7867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7868, ptr %slot1188, align 8
  %v7869 = load i64, ptr %slot1188, align 8
  %op7870 = and i64 %v7869, 4611686018427387906
  store i64 %op7870, ptr %slot1189, align 8
  %v7871 = load i64, ptr %slot1189, align 8
  %cmp7872 = icmp ne i64 %v7871, 0
  %cv7873 = zext i1 %cmp7872 to i32
  store i32 %cv7873, ptr %slot1190, align 8
  %v7874 = load i32, ptr %slot1190, align 8
  %cv7875 = zext i32 %v7874 to i64
  %cond7876 = icmp ne i64 %cv7875, 0
  br i1 %cond7876, label %bb_rcgclear1430, label %bb_rcgcounted1430
bb_rcgcounted1430:
  %v7877 = load i64, ptr %slot1185, align 8
  %op7878 = sub i64 %v7877, 32
  store i64 %op7878, ptr %slot1191, align 8
  %v7879 = load i64, ptr %slot1185, align 8
  %p7880 = inttoptr i64 %v7879 to ptr
  %rgep7881 = getelementptr i8, ptr %p7880, i64 -32
  %ld7882 = load i64, ptr %rgep7881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7882, ptr %slot1192, align 8
  %v7883 = load i64, ptr %slot1192, align 8
  %op7884 = sub i64 %v7883, 1
  store i64 %op7884, ptr %slot1193, align 8
  %v7885 = load i64, ptr %slot1193, align 8
  %cmp7886 = icmp eq i64 %v7885, 0
  %cv7887 = zext i1 %cmp7886 to i32
  store i32 %cv7887, ptr %slot1194, align 8
  %v7888 = load i32, ptr %slot1194, align 8
  %cv7889 = zext i32 %v7888 to i64
  %cond7890 = icmp ne i64 %cv7889, 0
  br i1 %cond7890, label %bb_rcglast1430, label %bb_rcgdec1430
bb_rcglast1430:
  %v7891 = load i64, ptr %slot1185, align 8
  %op7892 = sub i64 %v7891, 24
  store i64 %op7892, ptr %slot1195, align 8
  %v7893 = load i64, ptr %slot1185, align 8
  %p7894 = inttoptr i64 %v7893 to ptr
  %rgep7895 = getelementptr i8, ptr %p7894, i64 -24
  %ld7896 = load i64, ptr %rgep7895, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7896, ptr %slot1196, align 8
  %v7897 = load i64, ptr %slot1196, align 8
  %cmp7898 = icmp ne i64 %v7897, 0
  %cv7899 = zext i1 %cmp7898 to i32
  store i32 %cv7899, ptr %slot1197, align 8
  %v7900 = load i32, ptr %slot1197, align 8
  %cv7901 = zext i32 %v7900 to i64
  %cond7902 = icmp ne i64 %cv7901, 0
  br i1 %cond7902, label %bb_rcgdec1430, label %bb_rcgslow1430
bb_rcgslow1430:
  %v7903 = load i64, ptr %slot1184, align 8
  %v7904 = load i64, ptr %slot1167, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v7903, i64 %v7904) nomerge, !dbg !148
  br label %bb_rcgdone1430
bb_rcgdec1430:
  %v7905 = load i64, ptr %slot1193, align 8
  %v7906 = load i64, ptr %slot1185, align 8
  %p7907 = inttoptr i64 %v7906 to ptr
  %rgep7908 = getelementptr i8, ptr %p7907, i64 -32
  store i64 %v7905, ptr %rgep7908, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1430
bb_rcgclear1430:
  %v7909 = load i64, ptr %slot1167, align 8
  %p7910 = inttoptr i64 %v7909 to ptr
  store i64 0, ptr %p7910, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1430
bb_rcgdone1430:
  br label %bb_rcslotdone1399
bb_rcslotdone1399:
  br label %bb_rcprepared1345
bb_rcprepared1345:
  %v7911 = load i64, ptr %slot65, align 8
  store i64 %v7911, ptr %slot1198, align 8
  %v7912 = load i64, ptr %slot1198, align 8
  %v7913 = load i64, ptr %slot1124, align 8
  %p7914 = inttoptr i64 %v7912 to ptr
  %p7915 = inttoptr i64 %v7913 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7915, ptr %p7914, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7916 = load i64, ptr %slot46, align 8
  %p7917 = inttoptr i64 %v7916 to ptr
  store i32 0, ptr %p7917, align 4, !alias.scope !3, !noalias !4
  %v7918 = load i64, ptr %slot1042, align 8
  %v7919 = load i64, ptr %slot81, align 8
  %p7920 = inttoptr i64 %v7919 to ptr
  store i64 %v7918, ptr %p7920, align 8, !alias.scope !3, !noalias !4
  %v7921 = load i64, ptr %slot81, align 8
  %p7922 = inttoptr i64 %v7921 to ptr
  %ld7923 = load i64, ptr %p7922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7923, ptr %slot1199, align 8
  %v7924 = load i64, ptr %slot50, align 8
  store i64 %v7924, ptr %slot1200, align 8
  %v7925 = load i64, ptr %slot1199, align 8
  %v7926 = load i64, ptr %slot1200, align 8
  %p7927 = inttoptr i64 %v7925 to ptr
  %p7928 = inttoptr i64 %v7926 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7928, ptr %p7927, i64 16, i1 false)
  %v7929 = load i64, ptr %slot31, align 8
  %p7930 = inttoptr i64 %v7929 to ptr
  store i32 2, ptr %p7930, align 4, !alias.scope !3, !noalias !4
  %v7931 = load i64, ptr %slot30, align 8
  %p7932 = inttoptr i64 %v7931 to ptr
  store i32 1, ptr %p7932, align 4, !alias.scope !3, !noalias !4
  %v7933 = load i64, ptr %slot1200, align 8
  %v7934 = load i64, ptr %slot81, align 8
  %p7935 = inttoptr i64 %v7934 to ptr
  store i64 %v7933, ptr %p7935, align 8, !alias.scope !3, !noalias !4
  %v7936 = load i64, ptr %slot82, align 8
  %p7937 = inttoptr i64 %v7936 to ptr
  store i64 0, ptr %p7937, align 8, !alias.scope !3, !noalias !4
  %v7938 = load i64, ptr %slot82, align 8
  %p7939 = inttoptr i64 %v7938 to ptr
  %ld7940 = load i64, ptr %p7939, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7940, ptr %slot1201, align 8
  %v7941 = load i64, ptr %slot1201, align 8
  %cmp7942 = icmp sge i64 %v7941, 0
  %cv7943 = zext i1 %cmp7942 to i64
  store i64 %cv7943, ptr %slot1202, align 8
  %v7944 = load i64, ptr %slot1202, align 8
  %cond7945 = icmp ne i64 %v7944, 0
  br i1 %cond7945, label %bb_success1442, label %bb_failed1442
bb_failed1442:
  %v7946 = load i64, ptr %slot1, align 8
  %p7947 = inttoptr i64 %v7946 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p7947) nomerge, !dbg !150
  unreachable
bb_success1442:
  %v7948 = load i64, ptr %slot110, align 8
  %p7949 = inttoptr i64 %v7948 to ptr
  %p7950 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v7951 = load i64, ptr %slot1201, align 8
  %call7952 = call ptr @myl_native_list_new(ptr %p7949, ptr %p7950, i64 %v7951) nomerge, !dbg !150
  %calladdr7953 = ptrtoint ptr %call7952 to i64
  store i64 %calladdr7953, ptr %slot1203, align 8
  %v7954 = load i64, ptr %slot1203, align 8
  %cond7955 = icmp ne i64 %v7954, 0
  br i1 %cond7955, label %bb_success1444, label %bb_failed1444
bb_failed1444:
  %v7956 = load i64, ptr %slot1, align 8
  %p7957 = inttoptr i64 %v7956 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7957) nomerge, !dbg !150
  unreachable
bb_success1444:
  %v7958 = load i64, ptr %slot1203, align 8
  %v7959 = load i64, ptr %slot82, align 8
  %p7960 = inttoptr i64 %v7959 to ptr
  store i64 %v7958, ptr %p7960, align 8, !alias.scope !3, !noalias !4
  %v7961 = load i64, ptr %slot82, align 8
  %p7962 = inttoptr i64 %v7961 to ptr
  %ld7963 = load i64, ptr %p7962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7963, ptr %slot1204, align 8
  %v7964 = load i64, ptr %slot1204, align 8
  %v7965 = load i64, ptr %slot59, align 8
  %p7966 = inttoptr i64 %v7965 to ptr
  store i64 %v7964, ptr %p7966, align 8, !alias.scope !3, !noalias !4
  %v7967 = load i64, ptr %slot59, align 8
  store i64 %v7967, ptr %slot1205, align 8
  %v7968 = load i64, ptr %slot65, align 8
  store i64 %v7968, ptr %slot1206, align 8
  %v7969 = load i64, ptr %slot1205, align 8
  %v7970 = load i64, ptr %slot1206, align 8
  %p7971 = inttoptr i64 %v7969 to ptr
  %p7972 = inttoptr i64 %v7970 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7972, ptr %p7971, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7973 = load i64, ptr %slot47, align 8
  %p7974 = inttoptr i64 %v7973 to ptr
  store i32 2, ptr %p7974, align 4, !alias.scope !3, !noalias !4
  %v7975 = load i64, ptr %slot46, align 8
  %p7976 = inttoptr i64 %v7975 to ptr
  store i32 1, ptr %p7976, align 4, !alias.scope !3, !noalias !4
  %v7977 = load i64, ptr %slot51, align 8
  store i64 %v7977, ptr %slot1207, align 8
  %v7978 = load i64, ptr %slot65, align 8
  store i64 %v7978, ptr %slot1208, align 8
  %v7979 = load i64, ptr %slot1208, align 8
  %v7980 = load i64, ptr %slot1207, align 8
  %p7981 = inttoptr i64 %v7979 to ptr
  %p7982 = inttoptr i64 %v7980 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7982, ptr %p7981, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7983 = load i64, ptr %slot33, align 8
  %p7984 = inttoptr i64 %v7983 to ptr
  store i32 2, ptr %p7984, align 4, !alias.scope !3, !noalias !4
  %v7985 = load i64, ptr %slot47, align 8
  %p7986 = inttoptr i64 %v7985 to ptr
  %ld7987 = load i32, ptr %p7986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7987, ptr %slot1209, align 8
  %v7988 = load i32, ptr %slot1209, align 8
  %v7989 = load i64, ptr %slot33, align 8
  %p7990 = inttoptr i64 %v7989 to ptr
  store i32 %v7988, ptr %p7990, align 4, !alias.scope !3, !noalias !4
  %v7991 = load i64, ptr %slot46, align 8
  %p7992 = inttoptr i64 %v7991 to ptr
  store i32 0, ptr %p7992, align 4, !alias.scope !3, !noalias !4
  %v7993 = load i64, ptr %slot32, align 8
  %p7994 = inttoptr i64 %v7993 to ptr
  store i32 1, ptr %p7994, align 4, !alias.scope !3, !noalias !4
  %v7995 = load i64, ptr %slot1207, align 8
  %p7996 = inttoptr i64 %v7995 to ptr
  %ld7997 = load i64, ptr %p7996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7997, ptr %slot1210, align 8
  %v7998 = load i64, ptr %slot1210, align 8
  %v7999 = load i64, ptr %slot82, align 8
  %p8000 = inttoptr i64 %v7999 to ptr
  store i64 %v7998, ptr %p8000, align 8, !alias.scope !3, !noalias !4
  %v8001 = load i64, ptr %slot82, align 8
  %p8002 = inttoptr i64 %v8001 to ptr
  %ld8003 = load i64, ptr %p8002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8003, ptr %slot1211, align 8
  %v8004 = load i64, ptr %slot1211, align 8
  %v8005 = load i64, ptr %slot59, align 8
  %p8006 = inttoptr i64 %v8005 to ptr
  store i64 %v8004, ptr %p8006, align 8, !alias.scope !3, !noalias !4
  %v8007 = load i64, ptr %slot59, align 8
  store i64 %v8007, ptr %slot1212, align 8
  %v8008 = load i64, ptr %slot32, align 8
  %p8009 = inttoptr i64 %v8008 to ptr
  %ld8010 = load i32, ptr %p8009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8010, ptr %slot1213, align 8
  %v8011 = load i64, ptr %slot33, align 8
  %p8012 = inttoptr i64 %v8011 to ptr
  %ld8013 = load i32, ptr %p8012, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8013, ptr %slot1214, align 8
  %v8014 = load i32, ptr %slot1214, align 8
  %op8015 = and i32 %v8014, 24
  store i32 %op8015, ptr %slot1214, align 8
  %v8016 = load i32, ptr %slot1214, align 8
  %cmp8017 = icmp eq i32 %v8016, 0
  %cv8018 = zext i1 %cmp8017 to i32
  store i32 %cv8018, ptr %slot1215, align 8
  %v8019 = load i32, ptr %slot1213, align 8
  %v8020 = load i32, ptr %slot1215, align 8
  %op8021 = and i32 %v8019, %v8020
  store i32 %op8021, ptr %slot1216, align 8
  %v8022 = load i32, ptr %slot1216, align 8
  %cv8023 = zext i32 %v8022 to i64
  %cond8024 = icmp ne i64 %cv8023, 0
  br i1 %cond8024, label %bb_rcprivateown1467, label %bb_rcprivateloan1467
bb_rcprivateown1467:
  %v8025 = load i64, ptr %slot65, align 8
  store i64 %v8025, ptr %slot1217, align 8
  %v8026 = load i64, ptr %slot111, align 8
  store i64 %v8026, ptr %slot1218, align 8
  %v8027 = load i64, ptr %slot1212, align 8
  %v8028 = load i64, ptr %slot1217, align 8
  %op8029 = sub i64 %v8027, %v8028
  store i64 %op8029, ptr %slot1219, align 8
  %v8030 = load i64, ptr %slot1217, align 8
  %v8031 = load i64, ptr %slot1212, align 8
  %op8032 = sub i64 %v8030, %v8031
  store i64 %op8032, ptr %slot1220, align 8
  %v8033 = load i64, ptr %slot1219, align 8
  %cmp8034 = icmp ult i64 %v8033, 8
  %cv8035 = zext i1 %cmp8034 to i32
  store i32 %cv8035, ptr %slot1221, align 8
  %v8036 = load i64, ptr %slot1220, align 8
  %cmp8037 = icmp ult i64 %v8036, 8
  %cv8038 = zext i1 %cmp8037 to i32
  store i32 %cv8038, ptr %slot1222, align 8
  %v8039 = load i32, ptr %slot1221, align 8
  %v8040 = load i32, ptr %slot1222, align 8
  %op8041 = or i32 %v8039, %v8040
  store i32 %op8041, ptr %slot1223, align 8
  %v8042 = load i32, ptr %slot1223, align 8
  %cv8043 = zext i32 %v8042 to i64
  %cond8044 = icmp ne i64 %cv8043, 0
  br i1 %cond8044, label %bb_rcmoveslow1470, label %bb_rcmovecheck1470
bb_rcmovecheck1470:
  %v8045 = load i64, ptr %slot1212, align 8
  %p8047 = inttoptr i64 %v8045 to ptr
  %gep8048 = getelementptr i8, ptr %p8047, i64 0
  %op8046 = ptrtoint ptr %gep8048 to i64
  store i64 %op8046, ptr %slot1224, align 8
  %v8049 = load i64, ptr %slot1224, align 8
  %p8050 = inttoptr i64 %v8049 to ptr
  %ld8051 = load i64, ptr %p8050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8051, ptr %slot1225, align 8
  %v8052 = load i64, ptr %slot1225, align 8
  %cmp8053 = icmp ne i64 %v8052, 0
  %cv8054 = zext i1 %cmp8053 to i32
  store i32 %cv8054, ptr %slot1226, align 8
  %v8055 = load i32, ptr %slot1226, align 8
  %cv8056 = zext i32 %v8055 to i64
  %cond8057 = icmp ne i64 %cv8056, 0
  br i1 %cond8057, label %bb_rcmoveheader1478, label %bb_rcmovenext1478
bb_rcmoveheader1478:
  %v8058 = load i64, ptr %slot1225, align 8
  %op8059 = sub i64 %v8058, 16
  store i64 %op8059, ptr %slot1227, align 8
  %v8060 = load i64, ptr %slot1225, align 8
  %p8061 = inttoptr i64 %v8060 to ptr
  %rgep8062 = getelementptr i8, ptr %p8061, i64 -16
  %ld8063 = load i64, ptr %rgep8062, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8063, ptr %slot1228, align 8
  %v8064 = load i64, ptr %slot1228, align 8
  %op8065 = and i64 %v8064, 5764607523034234881
  store i64 %op8065, ptr %slot1229, align 8
  %v8066 = load i64, ptr %slot1229, align 8
  %cmp8067 = icmp ne i64 %v8066, 0
  %cv8068 = zext i1 %cmp8067 to i32
  store i32 %cv8068, ptr %slot1230, align 8
  %v8069 = load i32, ptr %slot1230, align 8
  %cv8070 = zext i32 %v8069 to i64
  %cond8071 = icmp ne i64 %cv8070, 0
  br i1 %cond8071, label %bb_rcmoveslow1470, label %bb_rcmovenext1478
bb_rcmovenext1478:
  %v8072 = load i64, ptr %slot1212, align 8
  %v8073 = load i64, ptr %slot1217, align 8
  %p8074 = inttoptr i64 %v8072 to ptr
  %p8075 = inttoptr i64 %v8073 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8075, ptr %p8074, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8076 = load i64, ptr %slot1212, align 8
  %p8077 = inttoptr i64 %v8076 to ptr
  store i64 0, ptr %p8077, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1470
bb_rcmoveslow1470:
  %v8078 = load i64, ptr %slot110, align 8
  %v8079 = load i64, ptr %slot1217, align 8
  %v8080 = load i64, ptr %slot1212, align 8
  %v8081 = load i64, ptr %slot1218, align 8
  %cv8082 = trunc i64 %v8081 to i32
  %call8083 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v8078, i64 %v8079, i64 %v8080, i32 %cv8082) nomerge, !dbg !152
  store i32 %call8083, ptr %slot1231, align 8
  %v8084 = load i32, ptr %slot1231, align 8
  %cv8085 = zext i32 %v8084 to i64
  %cond8086 = icmp ne i64 %cv8085, 0
  br i1 %cond8086, label %bb_rcsuccess1485, label %bb_rcfailure1485
bb_rcfailure1485:
  %v8087 = load i64, ptr %slot110, align 8
  %p8088 = inttoptr i64 %v8087 to ptr
  %call8089 = call i32 @myl_rc_take_failure(ptr %p8088) nomerge, !dbg !152
  store i32 %call8089, ptr %slot1232, align 8
  %v8090 = load i64, ptr %slot1, align 8
  %p8091 = inttoptr i64 %v8090 to ptr
  %v8092 = load i32, ptr %slot1232, align 8
  %call8093 = call i32 @myl_qbe_rc_status(ptr %p8091, i32 %v8092) nomerge, !dbg !152
  store i32 %call8093, ptr %slot1233, align 8
  br label %bb_failure
bb_rcsuccess1485:
  br label %bb_rcmoved1470
bb_rcmoved1470:
  %v8094 = load i64, ptr %slot32, align 8
  %p8095 = inttoptr i64 %v8094 to ptr
  store i32 0, ptr %p8095, align 4, !alias.scope !3, !noalias !4
  %v8096 = load i64, ptr %slot47, align 8
  %p8097 = inttoptr i64 %v8096 to ptr
  store i32 2, ptr %p8097, align 4, !alias.scope !3, !noalias !4
  %v8098 = load i64, ptr %slot46, align 8
  %p8099 = inttoptr i64 %v8098 to ptr
  store i32 1, ptr %p8099, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1467
bb_rcprivateloan1467:
  %v8100 = load i64, ptr %slot32, align 8
  %p8101 = inttoptr i64 %v8100 to ptr
  %ld8102 = load i32, ptr %p8101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8102, ptr %slot1234, align 8
  %v8103 = load i64, ptr %slot33, align 8
  %p8104 = inttoptr i64 %v8103 to ptr
  %ld8105 = load i32, ptr %p8104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8105, ptr %slot1235, align 8
  %v8106 = load i32, ptr %slot1235, align 8
  %cmp8107 = icmp eq i32 %v8106, 16
  %cv8108 = zext i1 %cmp8107 to i32
  store i32 %cv8108, ptr %slot1236, align 8
  %v8109 = load i32, ptr %slot1236, align 8
  %v8110 = load i32, ptr %slot1234, align 8
  %op8111 = and i32 %v8109, %v8110
  store i32 %op8111, ptr %slot1236, align 8
  %v8112 = load i32, ptr %slot1236, align 8
  %cv8113 = zext i32 %v8112 to i64
  %cond8114 = icmp ne i64 %cv8113, 0
  br i1 %cond8114, label %bb_rcprivatemove1467, label %bb_rcprivatenew1467
bb_rcprivatemove1467:
  %v8115 = load i64, ptr %slot65, align 8
  store i64 %v8115, ptr %slot1237, align 8
  %v8116 = load i64, ptr %slot1212, align 8
  %v8117 = load i64, ptr %slot1237, align 8
  %p8118 = inttoptr i64 %v8116 to ptr
  %p8119 = inttoptr i64 %v8117 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8119, ptr %p8118, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8120 = load i64, ptr %slot1212, align 8
  %p8121 = inttoptr i64 %v8120 to ptr
  store i64 0, ptr %p8121, align 8, !alias.scope !3, !noalias !4
  %v8122 = load i64, ptr %slot47, align 8
  %p8123 = inttoptr i64 %v8122 to ptr
  store i32 2, ptr %p8123, align 4, !alias.scope !3, !noalias !4
  %v8124 = load i64, ptr %slot47, align 8
  %p8125 = inttoptr i64 %v8124 to ptr
  store i32 16, ptr %p8125, align 4, !alias.scope !3, !noalias !4
  %v8126 = load i64, ptr %slot46, align 8
  %p8127 = inttoptr i64 %v8126 to ptr
  store i32 1, ptr %p8127, align 4, !alias.scope !3, !noalias !4
  %v8128 = load i64, ptr %slot32, align 8
  %p8129 = inttoptr i64 %v8128 to ptr
  store i32 0, ptr %p8129, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1467
bb_rcprivatenew1467:
  %v8130 = load i64, ptr %slot65, align 8
  store i64 %v8130, ptr %slot1238, align 8
  %v8131 = load i64, ptr %slot1212, align 8
  %p8132 = inttoptr i64 %v8131 to ptr
  %ld8133 = load i64, ptr %p8132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8133, ptr %slot1239, align 8
  %v8134 = load i64, ptr %slot1239, align 8
  %cmp8135 = icmp ne i64 %v8134, 0
  %cv8136 = zext i1 %cmp8135 to i32
  store i32 %cv8136, ptr %slot1240, align 8
  %v8137 = load i32, ptr %slot1240, align 8
  %cv8138 = zext i32 %v8137 to i64
  %cond8139 = icmp ne i64 %cv8138, 0
  br i1 %cond8139, label %bb_rcgnn1503, label %bb_rcgstore1503
bb_rcgnn1503:
  %v8140 = load i64, ptr %slot1239, align 8
  %op8141 = sub i64 %v8140, 16
  store i64 %op8141, ptr %slot1241, align 8
  %v8142 = load i64, ptr %slot1239, align 8
  %p8143 = inttoptr i64 %v8142 to ptr
  %rgep8144 = getelementptr i8, ptr %p8143, i64 -16
  %ld8145 = load i64, ptr %rgep8144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8145, ptr %slot1242, align 8
  %v8146 = load i64, ptr %slot1242, align 8
  %op8147 = and i64 %v8146, 4611686018427387906
  store i64 %op8147, ptr %slot1243, align 8
  %v8148 = load i64, ptr %slot1243, align 8
  %cmp8149 = icmp ne i64 %v8148, 0
  %cv8150 = zext i1 %cmp8149 to i32
  store i32 %cv8150, ptr %slot1244, align 8
  %v8151 = load i32, ptr %slot1244, align 8
  %cv8152 = zext i32 %v8151 to i64
  %cond8153 = icmp ne i64 %cv8152, 0
  br i1 %cond8153, label %bb_rcgstore1503, label %bb_rcginc1503
bb_rcginc1503:
  %v8154 = load i64, ptr %slot1239, align 8
  %op8155 = sub i64 %v8154, 24
  store i64 %op8155, ptr %slot1245, align 8
  %v8156 = load i64, ptr %slot1239, align 8
  %p8157 = inttoptr i64 %v8156 to ptr
  %rgep8158 = getelementptr i8, ptr %p8157, i64 -24
  %ld8159 = load i64, ptr %rgep8158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8159, ptr %slot1246, align 8
  %v8160 = load i64, ptr %slot1246, align 8
  %op8161 = add i64 %v8160, 1
  store i64 %op8161, ptr %slot1247, align 8
  %v8162 = load i64, ptr %slot1247, align 8
  %cmp8163 = icmp eq i64 %v8162, 0
  %cv8164 = zext i1 %cmp8163 to i32
  store i32 %cv8164, ptr %slot1248, align 8
  %v8165 = load i32, ptr %slot1248, align 8
  %cv8166 = zext i32 %v8165 to i64
  %cond8167 = icmp ne i64 %cv8166, 0
  br i1 %cond8167, label %bb_rcglimit1503, label %bb_rcgcapacity1503
bb_rcglimit1503:
  %v8168 = load i64, ptr %slot1, align 8
  %p8169 = inttoptr i64 %v8168 to ptr
  %call8170 = call i32 @myl_qbe_rc_status(ptr %p8169, i32 2) nomerge, !dbg !152
  store i32 %call8170, ptr %slot1249, align 8
  br label %bb_failure
bb_rcgcapacity1503:
  %v8171 = load i64, ptr %slot1247, align 8
  %v8172 = load i64, ptr %slot1239, align 8
  %p8173 = inttoptr i64 %v8172 to ptr
  %rgep8174 = getelementptr i8, ptr %p8173, i64 -24
  store i64 %v8171, ptr %rgep8174, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1503
bb_rcgstore1503:
  %v8175 = load i64, ptr %slot1239, align 8
  %v8176 = load i64, ptr %slot1238, align 8
  %p8177 = inttoptr i64 %v8176 to ptr
  store i64 %v8175, ptr %p8177, align 8, !alias.scope !3, !noalias !4
  %v8178 = load i64, ptr %slot47, align 8
  %p8179 = inttoptr i64 %v8178 to ptr
  store i32 2, ptr %p8179, align 4, !alias.scope !3, !noalias !4
  %v8180 = load i64, ptr %slot47, align 8
  %p8181 = inttoptr i64 %v8180 to ptr
  store i32 16, ptr %p8181, align 4, !alias.scope !3, !noalias !4
  %v8182 = load i64, ptr %slot46, align 8
  %p8183 = inttoptr i64 %v8182 to ptr
  store i32 1, ptr %p8183, align 4, !alias.scope !3, !noalias !4
  %v8184 = load i64, ptr %slot32, align 8
  %p8185 = inttoptr i64 %v8184 to ptr
  %ld8186 = load i32, ptr %p8185, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8186, ptr %slot1250, align 8
  %v8187 = load i32, ptr %slot1250, align 8
  %cv8188 = zext i32 %v8187 to i64
  %cond8189 = icmp ne i64 %cv8188, 0
  br i1 %cond8189, label %bb_rcslotdrop1519, label %bb_rcslotdone1519
bb_rcslotdrop1519:
  %v8190 = load i64, ptr %slot32, align 8
  %p8191 = inttoptr i64 %v8190 to ptr
  store i32 0, ptr %p8191, align 4, !alias.scope !3, !noalias !4
  %v8192 = load i64, ptr %slot51, align 8
  store i64 %v8192, ptr %slot1251, align 8
  %v8193 = load i64, ptr %slot33, align 8
  %p8194 = inttoptr i64 %v8193 to ptr
  %ld8195 = load i32, ptr %p8194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8195, ptr %slot1252, align 8
  %v8196 = load i32, ptr %slot1252, align 8
  %op8197 = and i32 %v8196, 28
  store i32 %op8197, ptr %slot1253, align 8
  %v8198 = load i32, ptr %slot1253, align 8
  %cv8199 = zext i32 %v8198 to i64
  %cond8200 = icmp ne i64 %cv8199, 0
  br i1 %cond8200, label %bb_rcslotrole1519, label %bb_rcslotowner1519
bb_rcslotrole1519:
  %v8201 = load i64, ptr %slot110, align 8
  store i64 %v8201, ptr %slot1254, align 8
  %v8202 = load i64, ptr %slot1251, align 8
  %p8203 = inttoptr i64 %v8202 to ptr
  %ld8204 = load i64, ptr %p8203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8204, ptr %slot1255, align 8
  %v8205 = load i64, ptr %slot1255, align 8
  %cmp8206 = icmp ne i64 %v8205, 0
  %cv8207 = zext i1 %cmp8206 to i32
  store i32 %cv8207, ptr %slot1256, align 8
  %v8208 = load i32, ptr %slot1256, align 8
  %cv8209 = zext i32 %v8208 to i64
  %cond8210 = icmp ne i64 %cv8209, 0
  br i1 %cond8210, label %bb_rcgnn1535, label %bb_rcgdone1535
bb_rcgnn1535:
  %v8211 = load i64, ptr %slot1255, align 8
  %op8212 = sub i64 %v8211, 16
  store i64 %op8212, ptr %slot1257, align 8
  %v8213 = load i64, ptr %slot1255, align 8
  %p8214 = inttoptr i64 %v8213 to ptr
  %rgep8215 = getelementptr i8, ptr %p8214, i64 -16
  %ld8216 = load i64, ptr %rgep8215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8216, ptr %slot1258, align 8
  %v8217 = load i64, ptr %slot1258, align 8
  %op8218 = and i64 %v8217, 4611686018427387906
  store i64 %op8218, ptr %slot1259, align 8
  %v8219 = load i64, ptr %slot1259, align 8
  %cmp8220 = icmp ne i64 %v8219, 0
  %cv8221 = zext i1 %cmp8220 to i32
  store i32 %cv8221, ptr %slot1260, align 8
  %v8222 = load i32, ptr %slot1260, align 8
  %cv8223 = zext i32 %v8222 to i64
  %cond8224 = icmp ne i64 %cv8223, 0
  br i1 %cond8224, label %bb_rcgclear1535, label %bb_rcgcounted1535
bb_rcgcounted1535:
  %v8225 = load i64, ptr %slot1255, align 8
  %op8226 = sub i64 %v8225, 24
  store i64 %op8226, ptr %slot1261, align 8
  %v8227 = load i64, ptr %slot1255, align 8
  %p8228 = inttoptr i64 %v8227 to ptr
  %rgep8229 = getelementptr i8, ptr %p8228, i64 -24
  %ld8230 = load i64, ptr %rgep8229, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8230, ptr %slot1262, align 8
  %v8231 = load i64, ptr %slot1262, align 8
  %op8232 = sub i64 %v8231, 1
  store i64 %op8232, ptr %slot1263, align 8
  %v8233 = load i64, ptr %slot1263, align 8
  %cmp8234 = icmp eq i64 %v8233, 0
  %cv8235 = zext i1 %cmp8234 to i32
  store i32 %cv8235, ptr %slot1264, align 8
  %v8236 = load i32, ptr %slot1264, align 8
  %cv8237 = zext i32 %v8236 to i64
  %cond8238 = icmp ne i64 %cv8237, 0
  br i1 %cond8238, label %bb_rcglast1535, label %bb_rcgdec1535
bb_rcglast1535:
  %v8239 = load i64, ptr %slot1255, align 8
  %op8240 = sub i64 %v8239, 32
  store i64 %op8240, ptr %slot1265, align 8
  %v8241 = load i64, ptr %slot1255, align 8
  %p8242 = inttoptr i64 %v8241 to ptr
  %rgep8243 = getelementptr i8, ptr %p8242, i64 -32
  %ld8244 = load i64, ptr %rgep8243, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8244, ptr %slot1266, align 8
  %v8245 = load i64, ptr %slot1266, align 8
  %cmp8246 = icmp ne i64 %v8245, 0
  %cv8247 = zext i1 %cmp8246 to i32
  store i32 %cv8247, ptr %slot1267, align 8
  %v8248 = load i32, ptr %slot1267, align 8
  %cv8249 = zext i32 %v8248 to i64
  %cond8250 = icmp ne i64 %cv8249, 0
  br i1 %cond8250, label %bb_rcgdec1535, label %bb_rcgslow1535
bb_rcgslow1535:
  %v8251 = load i64, ptr %slot1254, align 8
  %v8252 = load i64, ptr %slot1251, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v8251, i64 %v8252) nomerge, !dbg !152
  br label %bb_rcgdone1535
bb_rcgdec1535:
  %v8253 = load i64, ptr %slot1263, align 8
  %v8254 = load i64, ptr %slot1255, align 8
  %p8255 = inttoptr i64 %v8254 to ptr
  %rgep8256 = getelementptr i8, ptr %p8255, i64 -24
  store i64 %v8253, ptr %rgep8256, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1535
bb_rcgclear1535:
  %v8257 = load i64, ptr %slot1251, align 8
  %p8258 = inttoptr i64 %v8257 to ptr
  store i64 0, ptr %p8258, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1535
bb_rcgdone1535:
  br label %bb_rcslotdone1519
bb_rcslotowner1519:
  %v8259 = load i64, ptr %slot110, align 8
  store i64 %v8259, ptr %slot1268, align 8
  %v8260 = load i64, ptr %slot1251, align 8
  %p8261 = inttoptr i64 %v8260 to ptr
  %ld8262 = load i64, ptr %p8261, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8262, ptr %slot1269, align 8
  %v8263 = load i64, ptr %slot1269, align 8
  %cmp8264 = icmp ne i64 %v8263, 0
  %cv8265 = zext i1 %cmp8264 to i32
  store i32 %cv8265, ptr %slot1270, align 8
  %v8266 = load i32, ptr %slot1270, align 8
  %cv8267 = zext i32 %v8266 to i64
  %cond8268 = icmp ne i64 %cv8267, 0
  br i1 %cond8268, label %bb_rcgnn1550, label %bb_rcgdone1550
bb_rcgnn1550:
  %v8269 = load i64, ptr %slot1269, align 8
  %op8270 = sub i64 %v8269, 16
  store i64 %op8270, ptr %slot1271, align 8
  %v8271 = load i64, ptr %slot1269, align 8
  %p8272 = inttoptr i64 %v8271 to ptr
  %rgep8273 = getelementptr i8, ptr %p8272, i64 -16
  %ld8274 = load i64, ptr %rgep8273, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8274, ptr %slot1272, align 8
  %v8275 = load i64, ptr %slot1272, align 8
  %op8276 = and i64 %v8275, 4611686018427387906
  store i64 %op8276, ptr %slot1273, align 8
  %v8277 = load i64, ptr %slot1273, align 8
  %cmp8278 = icmp ne i64 %v8277, 0
  %cv8279 = zext i1 %cmp8278 to i32
  store i32 %cv8279, ptr %slot1274, align 8
  %v8280 = load i32, ptr %slot1274, align 8
  %cv8281 = zext i32 %v8280 to i64
  %cond8282 = icmp ne i64 %cv8281, 0
  br i1 %cond8282, label %bb_rcgclear1550, label %bb_rcgcounted1550
bb_rcgcounted1550:
  %v8283 = load i64, ptr %slot1269, align 8
  %op8284 = sub i64 %v8283, 32
  store i64 %op8284, ptr %slot1275, align 8
  %v8285 = load i64, ptr %slot1269, align 8
  %p8286 = inttoptr i64 %v8285 to ptr
  %rgep8287 = getelementptr i8, ptr %p8286, i64 -32
  %ld8288 = load i64, ptr %rgep8287, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8288, ptr %slot1276, align 8
  %v8289 = load i64, ptr %slot1276, align 8
  %op8290 = sub i64 %v8289, 1
  store i64 %op8290, ptr %slot1277, align 8
  %v8291 = load i64, ptr %slot1277, align 8
  %cmp8292 = icmp eq i64 %v8291, 0
  %cv8293 = zext i1 %cmp8292 to i32
  store i32 %cv8293, ptr %slot1278, align 8
  %v8294 = load i32, ptr %slot1278, align 8
  %cv8295 = zext i32 %v8294 to i64
  %cond8296 = icmp ne i64 %cv8295, 0
  br i1 %cond8296, label %bb_rcglast1550, label %bb_rcgdec1550
bb_rcglast1550:
  %v8297 = load i64, ptr %slot1269, align 8
  %op8298 = sub i64 %v8297, 24
  store i64 %op8298, ptr %slot1279, align 8
  %v8299 = load i64, ptr %slot1269, align 8
  %p8300 = inttoptr i64 %v8299 to ptr
  %rgep8301 = getelementptr i8, ptr %p8300, i64 -24
  %ld8302 = load i64, ptr %rgep8301, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8302, ptr %slot1280, align 8
  %v8303 = load i64, ptr %slot1280, align 8
  %cmp8304 = icmp ne i64 %v8303, 0
  %cv8305 = zext i1 %cmp8304 to i32
  store i32 %cv8305, ptr %slot1281, align 8
  %v8306 = load i32, ptr %slot1281, align 8
  %cv8307 = zext i32 %v8306 to i64
  %cond8308 = icmp ne i64 %cv8307, 0
  br i1 %cond8308, label %bb_rcgdec1550, label %bb_rcgslow1550
bb_rcgslow1550:
  %v8309 = load i64, ptr %slot1268, align 8
  %v8310 = load i64, ptr %slot1251, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v8309, i64 %v8310) nomerge, !dbg !152
  br label %bb_rcgdone1550
bb_rcgdec1550:
  %v8311 = load i64, ptr %slot1277, align 8
  %v8312 = load i64, ptr %slot1269, align 8
  %p8313 = inttoptr i64 %v8312 to ptr
  %rgep8314 = getelementptr i8, ptr %p8313, i64 -32
  store i64 %v8311, ptr %rgep8314, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1550
bb_rcgclear1550:
  %v8315 = load i64, ptr %slot1251, align 8
  %p8316 = inttoptr i64 %v8315 to ptr
  store i64 0, ptr %p8316, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1550
bb_rcgdone1550:
  br label %bb_rcslotdone1519
bb_rcslotdone1519:
  br label %bb_rcprivateprepared1467
bb_rcprivateprepared1467:
  %v8317 = load i64, ptr %slot20, align 8
  %p8318 = inttoptr i64 %v8317 to ptr
  %ld8319 = load i32, ptr %p8318, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8319, ptr %slot1282, align 8
  %v8320 = load i32, ptr %slot1282, align 8
  %cv8321 = zext i32 %v8320 to i64
  %cond8322 = icmp ne i64 %cv8321, 0
  br i1 %cond8322, label %bb_rcslotdrop1557, label %bb_rcslotdone1557
bb_rcslotdrop1557:
  %v8323 = load i64, ptr %slot20, align 8
  %p8324 = inttoptr i64 %v8323 to ptr
  store i32 0, ptr %p8324, align 4, !alias.scope !3, !noalias !4
  %v8325 = load i64, ptr %slot76, align 8
  store i64 %v8325, ptr %slot1283, align 8
  %v8326 = load i64, ptr %slot21, align 8
  %p8327 = inttoptr i64 %v8326 to ptr
  %ld8328 = load i32, ptr %p8327, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8328, ptr %slot1284, align 8
  %v8329 = load i32, ptr %slot1284, align 8
  %op8330 = and i32 %v8329, 28
  store i32 %op8330, ptr %slot1285, align 8
  %v8331 = load i32, ptr %slot1285, align 8
  %cv8332 = zext i32 %v8331 to i64
  %cond8333 = icmp ne i64 %cv8332, 0
  br i1 %cond8333, label %bb_rcslotrole1557, label %bb_rcslotowner1557
bb_rcslotrole1557:
  %v8334 = load i64, ptr %slot110, align 8
  store i64 %v8334, ptr %slot1286, align 8
  %v8335 = load i64, ptr %slot1283, align 8
  %p8336 = inttoptr i64 %v8335 to ptr
  %ld8337 = load i64, ptr %p8336, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8337, ptr %slot1287, align 8
  %v8338 = load i64, ptr %slot1287, align 8
  %cmp8339 = icmp ne i64 %v8338, 0
  %cv8340 = zext i1 %cmp8339 to i32
  store i32 %cv8340, ptr %slot1288, align 8
  %v8341 = load i32, ptr %slot1288, align 8
  %cv8342 = zext i32 %v8341 to i64
  %cond8343 = icmp ne i64 %cv8342, 0
  br i1 %cond8343, label %bb_rcgnn1573, label %bb_rcgdone1573
bb_rcgnn1573:
  %v8344 = load i64, ptr %slot1287, align 8
  %op8345 = sub i64 %v8344, 16
  store i64 %op8345, ptr %slot1289, align 8
  %v8346 = load i64, ptr %slot1287, align 8
  %p8347 = inttoptr i64 %v8346 to ptr
  %rgep8348 = getelementptr i8, ptr %p8347, i64 -16
  %ld8349 = load i64, ptr %rgep8348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8349, ptr %slot1290, align 8
  %v8350 = load i64, ptr %slot1290, align 8
  %op8351 = and i64 %v8350, 4611686018427387906
  store i64 %op8351, ptr %slot1291, align 8
  %v8352 = load i64, ptr %slot1291, align 8
  %cmp8353 = icmp ne i64 %v8352, 0
  %cv8354 = zext i1 %cmp8353 to i32
  store i32 %cv8354, ptr %slot1292, align 8
  %v8355 = load i32, ptr %slot1292, align 8
  %cv8356 = zext i32 %v8355 to i64
  %cond8357 = icmp ne i64 %cv8356, 0
  br i1 %cond8357, label %bb_rcgclear1573, label %bb_rcgcounted1573
bb_rcgcounted1573:
  %v8358 = load i64, ptr %slot1287, align 8
  %op8359 = sub i64 %v8358, 24
  store i64 %op8359, ptr %slot1293, align 8
  %v8360 = load i64, ptr %slot1287, align 8
  %p8361 = inttoptr i64 %v8360 to ptr
  %rgep8362 = getelementptr i8, ptr %p8361, i64 -24
  %ld8363 = load i64, ptr %rgep8362, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8363, ptr %slot1294, align 8
  %v8364 = load i64, ptr %slot1294, align 8
  %op8365 = sub i64 %v8364, 1
  store i64 %op8365, ptr %slot1295, align 8
  %v8366 = load i64, ptr %slot1295, align 8
  %cmp8367 = icmp eq i64 %v8366, 0
  %cv8368 = zext i1 %cmp8367 to i32
  store i32 %cv8368, ptr %slot1296, align 8
  %v8369 = load i32, ptr %slot1296, align 8
  %cv8370 = zext i32 %v8369 to i64
  %cond8371 = icmp ne i64 %cv8370, 0
  br i1 %cond8371, label %bb_rcglast1573, label %bb_rcgdec1573
bb_rcglast1573:
  %v8372 = load i64, ptr %slot1287, align 8
  %op8373 = sub i64 %v8372, 32
  store i64 %op8373, ptr %slot1297, align 8
  %v8374 = load i64, ptr %slot1287, align 8
  %p8375 = inttoptr i64 %v8374 to ptr
  %rgep8376 = getelementptr i8, ptr %p8375, i64 -32
  %ld8377 = load i64, ptr %rgep8376, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8377, ptr %slot1298, align 8
  %v8378 = load i64, ptr %slot1298, align 8
  %cmp8379 = icmp ne i64 %v8378, 0
  %cv8380 = zext i1 %cmp8379 to i32
  store i32 %cv8380, ptr %slot1299, align 8
  %v8381 = load i32, ptr %slot1299, align 8
  %cv8382 = zext i32 %v8381 to i64
  %cond8383 = icmp ne i64 %cv8382, 0
  br i1 %cond8383, label %bb_rcgdec1573, label %bb_rcgslow1573
bb_rcgslow1573:
  %v8384 = load i64, ptr %slot1286, align 8
  %v8385 = load i64, ptr %slot1283, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v8384, i64 %v8385) nomerge, !dbg !152
  br label %bb_rcgdone1573
bb_rcgdec1573:
  %v8386 = load i64, ptr %slot1295, align 8
  %v8387 = load i64, ptr %slot1287, align 8
  %p8388 = inttoptr i64 %v8387 to ptr
  %rgep8389 = getelementptr i8, ptr %p8388, i64 -24
  store i64 %v8386, ptr %rgep8389, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1573
bb_rcgclear1573:
  %v8390 = load i64, ptr %slot1283, align 8
  %p8391 = inttoptr i64 %v8390 to ptr
  store i64 0, ptr %p8391, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1573
bb_rcgdone1573:
  br label %bb_rcslotdone1557
bb_rcslotowner1557:
  %v8392 = load i64, ptr %slot110, align 8
  store i64 %v8392, ptr %slot1300, align 8
  %v8393 = load i64, ptr %slot1283, align 8
  %p8394 = inttoptr i64 %v8393 to ptr
  %ld8395 = load i64, ptr %p8394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8395, ptr %slot1301, align 8
  %v8396 = load i64, ptr %slot1301, align 8
  %cmp8397 = icmp ne i64 %v8396, 0
  %cv8398 = zext i1 %cmp8397 to i32
  store i32 %cv8398, ptr %slot1302, align 8
  %v8399 = load i32, ptr %slot1302, align 8
  %cv8400 = zext i32 %v8399 to i64
  %cond8401 = icmp ne i64 %cv8400, 0
  br i1 %cond8401, label %bb_rcgnn1588, label %bb_rcgdone1588
bb_rcgnn1588:
  %v8402 = load i64, ptr %slot1301, align 8
  %op8403 = sub i64 %v8402, 16
  store i64 %op8403, ptr %slot1303, align 8
  %v8404 = load i64, ptr %slot1301, align 8
  %p8405 = inttoptr i64 %v8404 to ptr
  %rgep8406 = getelementptr i8, ptr %p8405, i64 -16
  %ld8407 = load i64, ptr %rgep8406, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8407, ptr %slot1304, align 8
  %v8408 = load i64, ptr %slot1304, align 8
  %op8409 = and i64 %v8408, 4611686018427387906
  store i64 %op8409, ptr %slot1305, align 8
  %v8410 = load i64, ptr %slot1305, align 8
  %cmp8411 = icmp ne i64 %v8410, 0
  %cv8412 = zext i1 %cmp8411 to i32
  store i32 %cv8412, ptr %slot1306, align 8
  %v8413 = load i32, ptr %slot1306, align 8
  %cv8414 = zext i32 %v8413 to i64
  %cond8415 = icmp ne i64 %cv8414, 0
  br i1 %cond8415, label %bb_rcgclear1588, label %bb_rcgcounted1588
bb_rcgcounted1588:
  %v8416 = load i64, ptr %slot1301, align 8
  %op8417 = sub i64 %v8416, 32
  store i64 %op8417, ptr %slot1307, align 8
  %v8418 = load i64, ptr %slot1301, align 8
  %p8419 = inttoptr i64 %v8418 to ptr
  %rgep8420 = getelementptr i8, ptr %p8419, i64 -32
  %ld8421 = load i64, ptr %rgep8420, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8421, ptr %slot1308, align 8
  %v8422 = load i64, ptr %slot1308, align 8
  %op8423 = sub i64 %v8422, 1
  store i64 %op8423, ptr %slot1309, align 8
  %v8424 = load i64, ptr %slot1309, align 8
  %cmp8425 = icmp eq i64 %v8424, 0
  %cv8426 = zext i1 %cmp8425 to i32
  store i32 %cv8426, ptr %slot1310, align 8
  %v8427 = load i32, ptr %slot1310, align 8
  %cv8428 = zext i32 %v8427 to i64
  %cond8429 = icmp ne i64 %cv8428, 0
  br i1 %cond8429, label %bb_rcglast1588, label %bb_rcgdec1588
bb_rcglast1588:
  %v8430 = load i64, ptr %slot1301, align 8
  %op8431 = sub i64 %v8430, 24
  store i64 %op8431, ptr %slot1311, align 8
  %v8432 = load i64, ptr %slot1301, align 8
  %p8433 = inttoptr i64 %v8432 to ptr
  %rgep8434 = getelementptr i8, ptr %p8433, i64 -24
  %ld8435 = load i64, ptr %rgep8434, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8435, ptr %slot1312, align 8
  %v8436 = load i64, ptr %slot1312, align 8
  %cmp8437 = icmp ne i64 %v8436, 0
  %cv8438 = zext i1 %cmp8437 to i32
  store i32 %cv8438, ptr %slot1313, align 8
  %v8439 = load i32, ptr %slot1313, align 8
  %cv8440 = zext i32 %v8439 to i64
  %cond8441 = icmp ne i64 %cv8440, 0
  br i1 %cond8441, label %bb_rcgdec1588, label %bb_rcgslow1588
bb_rcgslow1588:
  %v8442 = load i64, ptr %slot1300, align 8
  %v8443 = load i64, ptr %slot1283, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v8442, i64 %v8443) nomerge, !dbg !152
  br label %bb_rcgdone1588
bb_rcgdec1588:
  %v8444 = load i64, ptr %slot1309, align 8
  %v8445 = load i64, ptr %slot1301, align 8
  %p8446 = inttoptr i64 %v8445 to ptr
  %rgep8447 = getelementptr i8, ptr %p8446, i64 -32
  store i64 %v8444, ptr %rgep8447, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1588
bb_rcgclear1588:
  %v8448 = load i64, ptr %slot1283, align 8
  %p8449 = inttoptr i64 %v8448 to ptr
  store i64 0, ptr %p8449, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1588
bb_rcgdone1588:
  br label %bb_rcslotdone1557
bb_rcslotdone1557:
  %v8450 = load i64, ptr %slot76, align 8
  store i64 %v8450, ptr %slot1314, align 8
  %v8451 = load i64, ptr %slot65, align 8
  store i64 %v8451, ptr %slot1315, align 8
  %v8452 = load i64, ptr %slot1315, align 8
  %v8453 = load i64, ptr %slot1314, align 8
  %p8454 = inttoptr i64 %v8452 to ptr
  %p8455 = inttoptr i64 %v8453 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8455, ptr %p8454, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8456 = load i64, ptr %slot46, align 8
  %p8457 = inttoptr i64 %v8456 to ptr
  store i32 0, ptr %p8457, align 4, !alias.scope !3, !noalias !4
  %v8458 = load i64, ptr %slot21, align 8
  %p8459 = inttoptr i64 %v8458 to ptr
  store i32 2, ptr %p8459, align 4, !alias.scope !3, !noalias !4
  %v8460 = load i64, ptr %slot47, align 8
  %p8461 = inttoptr i64 %v8460 to ptr
  %ld8462 = load i32, ptr %p8461, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8462, ptr %slot1316, align 8
  %v8463 = load i32, ptr %slot1316, align 8
  %v8464 = load i64, ptr %slot21, align 8
  %p8465 = inttoptr i64 %v8464 to ptr
  store i32 %v8463, ptr %p8465, align 4, !alias.scope !3, !noalias !4
  %v8466 = load i64, ptr %slot20, align 8
  %p8467 = inttoptr i64 %v8466 to ptr
  store i32 1, ptr %p8467, align 4, !alias.scope !3, !noalias !4
  %v8468 = load i64, ptr %slot76, align 8
  %p8469 = inttoptr i64 %v8468 to ptr
  %ld8470 = load i64, ptr %p8469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8470, ptr %slot1317, align 8
  %v8471 = load i64, ptr %slot1317, align 8
  %v8472 = load i64, ptr %slot82, align 8
  %p8473 = inttoptr i64 %v8472 to ptr
  store i64 %v8471, ptr %p8473, align 8, !alias.scope !3, !noalias !4
  %v8474 = load i64, ptr %slot1, align 8
  %call8475 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v8474) nomerge, !dbg !154
  store { i64, i64 } %call8475, ptr %callresult1319, align 8
  %addr8476 = ptrtoint ptr %callresult1319 to i64
  store i64 %addr8476, ptr %slot1318, align 8
  %v8477 = load i64, ptr %slot1318, align 8
  %v8478 = load i64, ptr %slot83, align 8
  %p8479 = inttoptr i64 %v8478 to ptr
  store i64 %v8477, ptr %p8479, align 8, !alias.scope !3, !noalias !4
  %v8480 = load i64, ptr %slot83, align 8
  %p8481 = inttoptr i64 %v8480 to ptr
  %ld8482 = load i64, ptr %p8481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8482, ptr %slot1320, align 8
  %v8483 = load i64, ptr %slot65, align 8
  store i64 %v8483, ptr %slot1321, align 8
  %v8484 = load i64, ptr %slot1320, align 8
  %v8485 = load i64, ptr %slot1321, align 8
  %p8486 = inttoptr i64 %v8484 to ptr
  %p8487 = inttoptr i64 %v8485 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8487, ptr %p8486, i64 16, i1 false)
  %v8488 = load i64, ptr %slot47, align 8
  %p8489 = inttoptr i64 %v8488 to ptr
  store i32 2, ptr %p8489, align 4, !alias.scope !3, !noalias !4
  %v8490 = load i64, ptr %slot46, align 8
  %p8491 = inttoptr i64 %v8490 to ptr
  store i32 1, ptr %p8491, align 4, !alias.scope !3, !noalias !4
  %v8492 = load i64, ptr %slot52, align 8
  store i64 %v8492, ptr %slot1322, align 8
  %v8493 = load i64, ptr %slot65, align 8
  store i64 %v8493, ptr %slot1323, align 8
  %v8494 = load i64, ptr %slot1323, align 8
  %v8495 = load i64, ptr %slot1322, align 8
  %p8496 = inttoptr i64 %v8494 to ptr
  %p8497 = inttoptr i64 %v8495 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8497, ptr %p8496, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v8498 = load i64, ptr %slot35, align 8
  %p8499 = inttoptr i64 %v8498 to ptr
  store i32 2, ptr %p8499, align 4, !alias.scope !3, !noalias !4
  %v8500 = load i64, ptr %slot47, align 8
  %p8501 = inttoptr i64 %v8500 to ptr
  %ld8502 = load i32, ptr %p8501, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8502, ptr %slot1324, align 8
  %v8503 = load i32, ptr %slot1324, align 8
  %v8504 = load i64, ptr %slot35, align 8
  %p8505 = inttoptr i64 %v8504 to ptr
  store i32 %v8503, ptr %p8505, align 4, !alias.scope !3, !noalias !4
  %v8506 = load i64, ptr %slot46, align 8
  %p8507 = inttoptr i64 %v8506 to ptr
  store i32 0, ptr %p8507, align 4, !alias.scope !3, !noalias !4
  %v8508 = load i64, ptr %slot34, align 8
  %p8509 = inttoptr i64 %v8508 to ptr
  store i32 1, ptr %p8509, align 4, !alias.scope !3, !noalias !4
  %v8510 = load i64, ptr %slot1322, align 8
  %v8511 = load i64, ptr %slot83, align 8
  %p8512 = inttoptr i64 %v8511 to ptr
  store i64 %v8510, ptr %p8512, align 8, !alias.scope !3, !noalias !4
  %v8513 = load i64, ptr %slot1, align 8
  %call8514 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v8513) nomerge, !dbg !156
  store { i64, i64 } %call8514, ptr %callresult1326, align 8
  %addr8515 = ptrtoint ptr %callresult1326 to i64
  store i64 %addr8515, ptr %slot1325, align 8
  %v8516 = load i64, ptr %slot1325, align 8
  %v8517 = load i64, ptr %slot84, align 8
  %p8518 = inttoptr i64 %v8517 to ptr
  store i64 %v8516, ptr %p8518, align 8, !alias.scope !3, !noalias !4
  %v8519 = load i64, ptr %slot84, align 8
  %p8520 = inttoptr i64 %v8519 to ptr
  %ld8521 = load i64, ptr %p8520, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8521, ptr %slot1327, align 8
  %v8522 = load i64, ptr %slot65, align 8
  store i64 %v8522, ptr %slot1328, align 8
  %v8523 = load i64, ptr %slot1327, align 8
  %v8524 = load i64, ptr %slot1328, align 8
  %p8525 = inttoptr i64 %v8523 to ptr
  %p8526 = inttoptr i64 %v8524 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8526, ptr %p8525, i64 16, i1 false)
  %v8527 = load i64, ptr %slot47, align 8
  %p8528 = inttoptr i64 %v8527 to ptr
  store i32 2, ptr %p8528, align 4, !alias.scope !3, !noalias !4
  %v8529 = load i64, ptr %slot46, align 8
  %p8530 = inttoptr i64 %v8529 to ptr
  store i32 1, ptr %p8530, align 4, !alias.scope !3, !noalias !4
  %v8531 = load i64, ptr %slot53, align 8
  store i64 %v8531, ptr %slot1329, align 8
  %v8532 = load i64, ptr %slot65, align 8
  store i64 %v8532, ptr %slot1330, align 8
  %v8533 = load i64, ptr %slot1330, align 8
  %v8534 = load i64, ptr %slot1329, align 8
  %p8535 = inttoptr i64 %v8533 to ptr
  %p8536 = inttoptr i64 %v8534 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8536, ptr %p8535, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v8537 = load i64, ptr %slot37, align 8
  %p8538 = inttoptr i64 %v8537 to ptr
  store i32 2, ptr %p8538, align 4, !alias.scope !3, !noalias !4
  %v8539 = load i64, ptr %slot47, align 8
  %p8540 = inttoptr i64 %v8539 to ptr
  %ld8541 = load i32, ptr %p8540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8541, ptr %slot1331, align 8
  %v8542 = load i32, ptr %slot1331, align 8
  %v8543 = load i64, ptr %slot37, align 8
  %p8544 = inttoptr i64 %v8543 to ptr
  store i32 %v8542, ptr %p8544, align 4, !alias.scope !3, !noalias !4
  %v8545 = load i64, ptr %slot46, align 8
  %p8546 = inttoptr i64 %v8545 to ptr
  store i32 0, ptr %p8546, align 4, !alias.scope !3, !noalias !4
  %v8547 = load i64, ptr %slot36, align 8
  %p8548 = inttoptr i64 %v8547 to ptr
  store i32 1, ptr %p8548, align 4, !alias.scope !3, !noalias !4
  %v8549 = load i64, ptr %slot1329, align 8
  %v8550 = load i64, ptr %slot84, align 8
  %p8551 = inttoptr i64 %v8550 to ptr
  store i64 %v8549, ptr %p8551, align 8, !alias.scope !3, !noalias !4
  %v8552 = load i64, ptr %slot85, align 8
  %p8553 = inttoptr i64 %v8552 to ptr
  store i64 18446744073709551615, ptr %p8553, align 8, !alias.scope !3, !noalias !4
  %v8554 = load i64, ptr %slot66, align 8
  %p8555 = inttoptr i64 %v8554 to ptr
  %ld8556 = load i64, ptr %p8555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8556, ptr %slot1332, align 8
  %v8557 = load i64, ptr %slot1332, align 8
  %v8558 = load i64, ptr %slot86, align 8
  %p8559 = inttoptr i64 %v8558 to ptr
  store i64 %v8557, ptr %p8559, align 8, !alias.scope !3, !noalias !4
  %v8560 = load i64, ptr %slot87, align 8
  %p8561 = inttoptr i64 %v8560 to ptr
  store i64 0, ptr %p8561, align 8, !alias.scope !3, !noalias !4
  %v8562 = load i64, ptr %slot88, align 8
  %p8563 = inttoptr i64 %v8562 to ptr
  store i64 1048576, ptr %p8563, align 8, !alias.scope !3, !noalias !4
  %v8564 = load i64, ptr %slot89, align 8
  %p8565 = inttoptr i64 %v8564 to ptr
  store i64 0, ptr %p8565, align 8, !alias.scope !3, !noalias !4
  %v8566 = load i64, ptr %slot90, align 8
  %p8567 = inttoptr i64 %v8566 to ptr
  store i64 0, ptr %p8567, align 8, !alias.scope !3, !noalias !4
  %v8568 = load i64, ptr %slot91, align 8
  %p8569 = inttoptr i64 %v8568 to ptr
  store i64 0, ptr %p8569, align 8, !alias.scope !3, !noalias !4
  %v8570 = load i64, ptr %slot69, align 8
  %p8571 = inttoptr i64 %v8570 to ptr
  %ld8572 = load i64, ptr %p8571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8572, ptr %slot1333, align 8
  %v8573 = load i64, ptr %slot1333, align 8
  %v8574 = load i64, ptr %slot92, align 8
  %p8575 = inttoptr i64 %v8574 to ptr
  store i64 %v8573, ptr %p8575, align 8, !alias.scope !3, !noalias !4
  %v8576 = load i64, ptr %slot93, align 8
  %p8577 = inttoptr i64 %v8576 to ptr
  store i64 0, ptr %p8577, align 8, !alias.scope !3, !noalias !4
  %v8578 = load i64, ptr %slot72, align 8
  %p8579 = inttoptr i64 %v8578 to ptr
  %ld8580 = load i64, ptr %p8579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8580, ptr %slot1334, align 8
  %v8581 = load i64, ptr %slot1334, align 8
  %v8582 = load i64, ptr %slot94, align 8
  %p8583 = inttoptr i64 %v8582 to ptr
  store i64 %v8581, ptr %p8583, align 8, !alias.scope !3, !noalias !4
  %v8584 = load i64, ptr %slot95, align 8
  %p8585 = inttoptr i64 %v8584 to ptr
  store i64 0, ptr %p8585, align 8, !alias.scope !3, !noalias !4
  %v8586 = load i64, ptr %slot96, align 8
  %p8587 = inttoptr i64 %v8586 to ptr
  store i64 18446744073709551615, ptr %p8587, align 8, !alias.scope !3, !noalias !4
  %v8588 = load i64, ptr %slot97, align 8
  %p8589 = inttoptr i64 %v8588 to ptr
  store i64 0, ptr %p8589, align 8, !alias.scope !3, !noalias !4
  %v8590 = load i64, ptr %slot97, align 8
  %p8591 = inttoptr i64 %v8590 to ptr
  %ld8592 = load i64, ptr %p8591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8592, ptr %slot1335, align 8
  %v8593 = load i64, ptr %slot1335, align 8
  %cmp8594 = icmp sge i64 %v8593, 0
  %cv8595 = zext i1 %cmp8594 to i64
  store i64 %cv8595, ptr %slot1336, align 8
  %v8596 = load i64, ptr %slot1336, align 8
  %cond8597 = icmp ne i64 %v8596, 0
  br i1 %cond8597, label %bb_success1631, label %bb_failed1631
bb_failed1631:
  %v8598 = load i64, ptr %slot1, align 8
  %p8599 = inttoptr i64 %v8598 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p8599) nomerge, !dbg !158
  unreachable
bb_success1631:
  %v8600 = load i64, ptr %slot110, align 8
  %p8601 = inttoptr i64 %v8600 to ptr
  %p8602 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v8603 = load i64, ptr %slot1335, align 8
  %call8604 = call ptr @myl_native_list_new(ptr %p8601, ptr %p8602, i64 %v8603) nomerge, !dbg !158
  %calladdr8605 = ptrtoint ptr %call8604 to i64
  store i64 %calladdr8605, ptr %slot1337, align 8
  %v8606 = load i64, ptr %slot1337, align 8
  %cond8607 = icmp ne i64 %v8606, 0
  br i1 %cond8607, label %bb_success1633, label %bb_failed1633
bb_failed1633:
  %v8608 = load i64, ptr %slot1, align 8
  %p8609 = inttoptr i64 %v8608 to ptr
  call void @myl_qbe_fail_allocation(ptr %p8609) nomerge, !dbg !158
  unreachable
bb_success1633:
  %v8610 = load i64, ptr %slot1337, align 8
  %v8611 = load i64, ptr %slot97, align 8
  %p8612 = inttoptr i64 %v8611 to ptr
  store i64 %v8610, ptr %p8612, align 8, !alias.scope !3, !noalias !4
  %v8613 = load i64, ptr %slot97, align 8
  %p8614 = inttoptr i64 %v8613 to ptr
  %ld8615 = load i64, ptr %p8614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8615, ptr %slot1338, align 8
  %v8616 = load i64, ptr %slot1338, align 8
  %v8617 = load i64, ptr %slot62, align 8
  %p8618 = inttoptr i64 %v8617 to ptr
  store i64 %v8616, ptr %p8618, align 8, !alias.scope !3, !noalias !4
  %v8619 = load i64, ptr %slot62, align 8
  store i64 %v8619, ptr %slot1339, align 8
  %v8620 = load i64, ptr %slot65, align 8
  store i64 %v8620, ptr %slot1340, align 8
  %v8621 = load i64, ptr %slot1339, align 8
  %v8622 = load i64, ptr %slot1340, align 8
  %p8623 = inttoptr i64 %v8621 to ptr
  %p8624 = inttoptr i64 %v8622 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8624, ptr %p8623, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8625 = load i64, ptr %slot47, align 8
  %p8626 = inttoptr i64 %v8625 to ptr
  store i32 2, ptr %p8626, align 4, !alias.scope !3, !noalias !4
  %v8627 = load i64, ptr %slot46, align 8
  %p8628 = inttoptr i64 %v8627 to ptr
  store i32 1, ptr %p8628, align 4, !alias.scope !3, !noalias !4
  %v8629 = load i64, ptr %slot54, align 8
  store i64 %v8629, ptr %slot1341, align 8
  %v8630 = load i64, ptr %slot65, align 8
  store i64 %v8630, ptr %slot1342, align 8
  %v8631 = load i64, ptr %slot1342, align 8
  %v8632 = load i64, ptr %slot1341, align 8
  %p8633 = inttoptr i64 %v8631 to ptr
  %p8634 = inttoptr i64 %v8632 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8634, ptr %p8633, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8635 = load i64, ptr %slot41, align 8
  %p8636 = inttoptr i64 %v8635 to ptr
  store i32 2, ptr %p8636, align 4, !alias.scope !3, !noalias !4
  %v8637 = load i64, ptr %slot47, align 8
  %p8638 = inttoptr i64 %v8637 to ptr
  %ld8639 = load i32, ptr %p8638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8639, ptr %slot1343, align 8
  %v8640 = load i32, ptr %slot1343, align 8
  %v8641 = load i64, ptr %slot41, align 8
  %p8642 = inttoptr i64 %v8641 to ptr
  store i32 %v8640, ptr %p8642, align 4, !alias.scope !3, !noalias !4
  %v8643 = load i64, ptr %slot46, align 8
  %p8644 = inttoptr i64 %v8643 to ptr
  store i32 0, ptr %p8644, align 4, !alias.scope !3, !noalias !4
  %v8645 = load i64, ptr %slot40, align 8
  %p8646 = inttoptr i64 %v8645 to ptr
  store i32 1, ptr %p8646, align 4, !alias.scope !3, !noalias !4
  %v8647 = load i64, ptr %slot1341, align 8
  %p8648 = inttoptr i64 %v8647 to ptr
  %ld8649 = load i64, ptr %p8648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8649, ptr %slot1344, align 8
  %v8650 = load i64, ptr %slot1344, align 8
  %v8651 = load i64, ptr %slot97, align 8
  %p8652 = inttoptr i64 %v8651 to ptr
  store i64 %v8650, ptr %p8652, align 8, !alias.scope !3, !noalias !4
  %v8653 = load i64, ptr %slot97, align 8
  %p8654 = inttoptr i64 %v8653 to ptr
  %ld8655 = load i64, ptr %p8654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8655, ptr %slot1345, align 8
  %v8656 = load i64, ptr %slot1345, align 8
  %v8657 = load i64, ptr %slot62, align 8
  %p8658 = inttoptr i64 %v8657 to ptr
  store i64 %v8656, ptr %p8658, align 8, !alias.scope !3, !noalias !4
  %v8659 = load i64, ptr %slot62, align 8
  store i64 %v8659, ptr %slot1346, align 8
  %v8660 = load i64, ptr %slot40, align 8
  %p8661 = inttoptr i64 %v8660 to ptr
  %ld8662 = load i32, ptr %p8661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8662, ptr %slot1347, align 8
  %v8663 = load i64, ptr %slot41, align 8
  %p8664 = inttoptr i64 %v8663 to ptr
  %ld8665 = load i32, ptr %p8664, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8665, ptr %slot1348, align 8
  %v8666 = load i32, ptr %slot1348, align 8
  %op8667 = and i32 %v8666, 24
  store i32 %op8667, ptr %slot1348, align 8
  %v8668 = load i32, ptr %slot1348, align 8
  %cmp8669 = icmp eq i32 %v8668, 0
  %cv8670 = zext i1 %cmp8669 to i32
  store i32 %cv8670, ptr %slot1349, align 8
  %v8671 = load i32, ptr %slot1347, align 8
  %v8672 = load i32, ptr %slot1349, align 8
  %op8673 = and i32 %v8671, %v8672
  store i32 %op8673, ptr %slot1350, align 8
  %v8674 = load i32, ptr %slot1350, align 8
  %cv8675 = zext i32 %v8674 to i64
  %cond8676 = icmp ne i64 %cv8675, 0
  br i1 %cond8676, label %bb_rcprivateown1656, label %bb_rcprivateloan1656
bb_rcprivateown1656:
  %v8677 = load i64, ptr %slot65, align 8
  store i64 %v8677, ptr %slot1351, align 8
  %v8678 = load i64, ptr %slot111, align 8
  store i64 %v8678, ptr %slot1352, align 8
  %v8679 = load i64, ptr %slot1346, align 8
  %v8680 = load i64, ptr %slot1351, align 8
  %op8681 = sub i64 %v8679, %v8680
  store i64 %op8681, ptr %slot1353, align 8
  %v8682 = load i64, ptr %slot1351, align 8
  %v8683 = load i64, ptr %slot1346, align 8
  %op8684 = sub i64 %v8682, %v8683
  store i64 %op8684, ptr %slot1354, align 8
  %v8685 = load i64, ptr %slot1353, align 8
  %cmp8686 = icmp ult i64 %v8685, 8
  %cv8687 = zext i1 %cmp8686 to i32
  store i32 %cv8687, ptr %slot1355, align 8
  %v8688 = load i64, ptr %slot1354, align 8
  %cmp8689 = icmp ult i64 %v8688, 8
  %cv8690 = zext i1 %cmp8689 to i32
  store i32 %cv8690, ptr %slot1356, align 8
  %v8691 = load i32, ptr %slot1355, align 8
  %v8692 = load i32, ptr %slot1356, align 8
  %op8693 = or i32 %v8691, %v8692
  store i32 %op8693, ptr %slot1357, align 8
  %v8694 = load i32, ptr %slot1357, align 8
  %cv8695 = zext i32 %v8694 to i64
  %cond8696 = icmp ne i64 %cv8695, 0
  br i1 %cond8696, label %bb_rcmoveslow1659, label %bb_rcmovecheck1659
bb_rcmovecheck1659:
  %v8697 = load i64, ptr %slot1346, align 8
  %p8699 = inttoptr i64 %v8697 to ptr
  %gep8700 = getelementptr i8, ptr %p8699, i64 0
  %op8698 = ptrtoint ptr %gep8700 to i64
  store i64 %op8698, ptr %slot1358, align 8
  %v8701 = load i64, ptr %slot1358, align 8
  %p8702 = inttoptr i64 %v8701 to ptr
  %ld8703 = load i64, ptr %p8702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8703, ptr %slot1359, align 8
  %v8704 = load i64, ptr %slot1359, align 8
  %cmp8705 = icmp ne i64 %v8704, 0
  %cv8706 = zext i1 %cmp8705 to i32
  store i32 %cv8706, ptr %slot1360, align 8
  %v8707 = load i32, ptr %slot1360, align 8
  %cv8708 = zext i32 %v8707 to i64
  %cond8709 = icmp ne i64 %cv8708, 0
  br i1 %cond8709, label %bb_rcmoveheader1667, label %bb_rcmovenext1667
bb_rcmoveheader1667:
  %v8710 = load i64, ptr %slot1359, align 8
  %op8711 = sub i64 %v8710, 16
  store i64 %op8711, ptr %slot1361, align 8
  %v8712 = load i64, ptr %slot1359, align 8
  %p8713 = inttoptr i64 %v8712 to ptr
  %rgep8714 = getelementptr i8, ptr %p8713, i64 -16
  %ld8715 = load i64, ptr %rgep8714, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8715, ptr %slot1362, align 8
  %v8716 = load i64, ptr %slot1362, align 8
  %op8717 = and i64 %v8716, 5764607523034234881
  store i64 %op8717, ptr %slot1363, align 8
  %v8718 = load i64, ptr %slot1363, align 8
  %cmp8719 = icmp ne i64 %v8718, 0
  %cv8720 = zext i1 %cmp8719 to i32
  store i32 %cv8720, ptr %slot1364, align 8
  %v8721 = load i32, ptr %slot1364, align 8
  %cv8722 = zext i32 %v8721 to i64
  %cond8723 = icmp ne i64 %cv8722, 0
  br i1 %cond8723, label %bb_rcmoveslow1659, label %bb_rcmovenext1667
bb_rcmovenext1667:
  %v8724 = load i64, ptr %slot1346, align 8
  %v8725 = load i64, ptr %slot1351, align 8
  %p8726 = inttoptr i64 %v8724 to ptr
  %p8727 = inttoptr i64 %v8725 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8727, ptr %p8726, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8728 = load i64, ptr %slot1346, align 8
  %p8729 = inttoptr i64 %v8728 to ptr
  store i64 0, ptr %p8729, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1659
bb_rcmoveslow1659:
  %v8730 = load i64, ptr %slot110, align 8
  %v8731 = load i64, ptr %slot1351, align 8
  %v8732 = load i64, ptr %slot1346, align 8
  %v8733 = load i64, ptr %slot1352, align 8
  %cv8734 = trunc i64 %v8733 to i32
  %call8735 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v8730, i64 %v8731, i64 %v8732, i32 %cv8734) nomerge, !dbg !160
  store i32 %call8735, ptr %slot1365, align 8
  %v8736 = load i32, ptr %slot1365, align 8
  %cv8737 = zext i32 %v8736 to i64
  %cond8738 = icmp ne i64 %cv8737, 0
  br i1 %cond8738, label %bb_rcsuccess1674, label %bb_rcfailure1674
bb_rcfailure1674:
  %v8739 = load i64, ptr %slot110, align 8
  %p8740 = inttoptr i64 %v8739 to ptr
  %call8741 = call i32 @myl_rc_take_failure(ptr %p8740) nomerge, !dbg !160
  store i32 %call8741, ptr %slot1366, align 8
  %v8742 = load i64, ptr %slot1, align 8
  %p8743 = inttoptr i64 %v8742 to ptr
  %v8744 = load i32, ptr %slot1366, align 8
  %call8745 = call i32 @myl_qbe_rc_status(ptr %p8743, i32 %v8744) nomerge, !dbg !160
  store i32 %call8745, ptr %slot1367, align 8
  br label %bb_failure
bb_rcsuccess1674:
  br label %bb_rcmoved1659
bb_rcmoved1659:
  %v8746 = load i64, ptr %slot40, align 8
  %p8747 = inttoptr i64 %v8746 to ptr
  store i32 0, ptr %p8747, align 4, !alias.scope !3, !noalias !4
  %v8748 = load i64, ptr %slot47, align 8
  %p8749 = inttoptr i64 %v8748 to ptr
  store i32 2, ptr %p8749, align 4, !alias.scope !3, !noalias !4
  %v8750 = load i64, ptr %slot46, align 8
  %p8751 = inttoptr i64 %v8750 to ptr
  store i32 1, ptr %p8751, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1656
bb_rcprivateloan1656:
  %v8752 = load i64, ptr %slot40, align 8
  %p8753 = inttoptr i64 %v8752 to ptr
  %ld8754 = load i32, ptr %p8753, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8754, ptr %slot1368, align 8
  %v8755 = load i64, ptr %slot41, align 8
  %p8756 = inttoptr i64 %v8755 to ptr
  %ld8757 = load i32, ptr %p8756, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8757, ptr %slot1369, align 8
  %v8758 = load i32, ptr %slot1369, align 8
  %cmp8759 = icmp eq i32 %v8758, 16
  %cv8760 = zext i1 %cmp8759 to i32
  store i32 %cv8760, ptr %slot1370, align 8
  %v8761 = load i32, ptr %slot1370, align 8
  %v8762 = load i32, ptr %slot1368, align 8
  %op8763 = and i32 %v8761, %v8762
  store i32 %op8763, ptr %slot1370, align 8
  %v8764 = load i32, ptr %slot1370, align 8
  %cv8765 = zext i32 %v8764 to i64
  %cond8766 = icmp ne i64 %cv8765, 0
  br i1 %cond8766, label %bb_rcprivatemove1656, label %bb_rcprivatenew1656
bb_rcprivatemove1656:
  %v8767 = load i64, ptr %slot65, align 8
  store i64 %v8767, ptr %slot1371, align 8
  %v8768 = load i64, ptr %slot1346, align 8
  %v8769 = load i64, ptr %slot1371, align 8
  %p8770 = inttoptr i64 %v8768 to ptr
  %p8771 = inttoptr i64 %v8769 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8771, ptr %p8770, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8772 = load i64, ptr %slot1346, align 8
  %p8773 = inttoptr i64 %v8772 to ptr
  store i64 0, ptr %p8773, align 8, !alias.scope !3, !noalias !4
  %v8774 = load i64, ptr %slot47, align 8
  %p8775 = inttoptr i64 %v8774 to ptr
  store i32 2, ptr %p8775, align 4, !alias.scope !3, !noalias !4
  %v8776 = load i64, ptr %slot47, align 8
  %p8777 = inttoptr i64 %v8776 to ptr
  store i32 16, ptr %p8777, align 4, !alias.scope !3, !noalias !4
  %v8778 = load i64, ptr %slot46, align 8
  %p8779 = inttoptr i64 %v8778 to ptr
  store i32 1, ptr %p8779, align 4, !alias.scope !3, !noalias !4
  %v8780 = load i64, ptr %slot40, align 8
  %p8781 = inttoptr i64 %v8780 to ptr
  store i32 0, ptr %p8781, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1656
bb_rcprivatenew1656:
  %v8782 = load i64, ptr %slot65, align 8
  store i64 %v8782, ptr %slot1372, align 8
  %v8783 = load i64, ptr %slot1346, align 8
  %p8784 = inttoptr i64 %v8783 to ptr
  %ld8785 = load i64, ptr %p8784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8785, ptr %slot1373, align 8
  %v8786 = load i64, ptr %slot1373, align 8
  %cmp8787 = icmp ne i64 %v8786, 0
  %cv8788 = zext i1 %cmp8787 to i32
  store i32 %cv8788, ptr %slot1374, align 8
  %v8789 = load i32, ptr %slot1374, align 8
  %cv8790 = zext i32 %v8789 to i64
  %cond8791 = icmp ne i64 %cv8790, 0
  br i1 %cond8791, label %bb_rcgnn1692, label %bb_rcgstore1692
bb_rcgnn1692:
  %v8792 = load i64, ptr %slot1373, align 8
  %op8793 = sub i64 %v8792, 16
  store i64 %op8793, ptr %slot1375, align 8
  %v8794 = load i64, ptr %slot1373, align 8
  %p8795 = inttoptr i64 %v8794 to ptr
  %rgep8796 = getelementptr i8, ptr %p8795, i64 -16
  %ld8797 = load i64, ptr %rgep8796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8797, ptr %slot1376, align 8
  %v8798 = load i64, ptr %slot1376, align 8
  %op8799 = and i64 %v8798, 4611686018427387906
  store i64 %op8799, ptr %slot1377, align 8
  %v8800 = load i64, ptr %slot1377, align 8
  %cmp8801 = icmp ne i64 %v8800, 0
  %cv8802 = zext i1 %cmp8801 to i32
  store i32 %cv8802, ptr %slot1378, align 8
  %v8803 = load i32, ptr %slot1378, align 8
  %cv8804 = zext i32 %v8803 to i64
  %cond8805 = icmp ne i64 %cv8804, 0
  br i1 %cond8805, label %bb_rcgstore1692, label %bb_rcginc1692
bb_rcginc1692:
  %v8806 = load i64, ptr %slot1373, align 8
  %op8807 = sub i64 %v8806, 24
  store i64 %op8807, ptr %slot1379, align 8
  %v8808 = load i64, ptr %slot1373, align 8
  %p8809 = inttoptr i64 %v8808 to ptr
  %rgep8810 = getelementptr i8, ptr %p8809, i64 -24
  %ld8811 = load i64, ptr %rgep8810, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8811, ptr %slot1380, align 8
  %v8812 = load i64, ptr %slot1380, align 8
  %op8813 = add i64 %v8812, 1
  store i64 %op8813, ptr %slot1381, align 8
  %v8814 = load i64, ptr %slot1381, align 8
  %cmp8815 = icmp eq i64 %v8814, 0
  %cv8816 = zext i1 %cmp8815 to i32
  store i32 %cv8816, ptr %slot1382, align 8
  %v8817 = load i32, ptr %slot1382, align 8
  %cv8818 = zext i32 %v8817 to i64
  %cond8819 = icmp ne i64 %cv8818, 0
  br i1 %cond8819, label %bb_rcglimit1692, label %bb_rcgcapacity1692
bb_rcglimit1692:
  %v8820 = load i64, ptr %slot1, align 8
  %p8821 = inttoptr i64 %v8820 to ptr
  %call8822 = call i32 @myl_qbe_rc_status(ptr %p8821, i32 2) nomerge, !dbg !160
  store i32 %call8822, ptr %slot1383, align 8
  br label %bb_failure
bb_rcgcapacity1692:
  %v8823 = load i64, ptr %slot1381, align 8
  %v8824 = load i64, ptr %slot1373, align 8
  %p8825 = inttoptr i64 %v8824 to ptr
  %rgep8826 = getelementptr i8, ptr %p8825, i64 -24
  store i64 %v8823, ptr %rgep8826, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1692
bb_rcgstore1692:
  %v8827 = load i64, ptr %slot1373, align 8
  %v8828 = load i64, ptr %slot1372, align 8
  %p8829 = inttoptr i64 %v8828 to ptr
  store i64 %v8827, ptr %p8829, align 8, !alias.scope !3, !noalias !4
  %v8830 = load i64, ptr %slot47, align 8
  %p8831 = inttoptr i64 %v8830 to ptr
  store i32 2, ptr %p8831, align 4, !alias.scope !3, !noalias !4
  %v8832 = load i64, ptr %slot47, align 8
  %p8833 = inttoptr i64 %v8832 to ptr
  store i32 16, ptr %p8833, align 4, !alias.scope !3, !noalias !4
  %v8834 = load i64, ptr %slot46, align 8
  %p8835 = inttoptr i64 %v8834 to ptr
  store i32 1, ptr %p8835, align 4, !alias.scope !3, !noalias !4
  %v8836 = load i64, ptr %slot40, align 8
  %p8837 = inttoptr i64 %v8836 to ptr
  %ld8838 = load i32, ptr %p8837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8838, ptr %slot1384, align 8
  %v8839 = load i32, ptr %slot1384, align 8
  %cv8840 = zext i32 %v8839 to i64
  %cond8841 = icmp ne i64 %cv8840, 0
  br i1 %cond8841, label %bb_rcslotdrop1708, label %bb_rcslotdone1708
bb_rcslotdrop1708:
  %v8842 = load i64, ptr %slot40, align 8
  %p8843 = inttoptr i64 %v8842 to ptr
  store i32 0, ptr %p8843, align 4, !alias.scope !3, !noalias !4
  %v8844 = load i64, ptr %slot54, align 8
  store i64 %v8844, ptr %slot1385, align 8
  %v8845 = load i64, ptr %slot41, align 8
  %p8846 = inttoptr i64 %v8845 to ptr
  %ld8847 = load i32, ptr %p8846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8847, ptr %slot1386, align 8
  %v8848 = load i32, ptr %slot1386, align 8
  %op8849 = and i32 %v8848, 28
  store i32 %op8849, ptr %slot1387, align 8
  %v8850 = load i32, ptr %slot1387, align 8
  %cv8851 = zext i32 %v8850 to i64
  %cond8852 = icmp ne i64 %cv8851, 0
  br i1 %cond8852, label %bb_rcslotrole1708, label %bb_rcslotowner1708
bb_rcslotrole1708:
  %v8853 = load i64, ptr %slot110, align 8
  store i64 %v8853, ptr %slot1388, align 8
  %v8854 = load i64, ptr %slot1385, align 8
  %p8855 = inttoptr i64 %v8854 to ptr
  %ld8856 = load i64, ptr %p8855, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8856, ptr %slot1389, align 8
  %v8857 = load i64, ptr %slot1389, align 8
  %cmp8858 = icmp ne i64 %v8857, 0
  %cv8859 = zext i1 %cmp8858 to i32
  store i32 %cv8859, ptr %slot1390, align 8
  %v8860 = load i32, ptr %slot1390, align 8
  %cv8861 = zext i32 %v8860 to i64
  %cond8862 = icmp ne i64 %cv8861, 0
  br i1 %cond8862, label %bb_rcgnn1724, label %bb_rcgdone1724
bb_rcgnn1724:
  %v8863 = load i64, ptr %slot1389, align 8
  %op8864 = sub i64 %v8863, 16
  store i64 %op8864, ptr %slot1391, align 8
  %v8865 = load i64, ptr %slot1389, align 8
  %p8866 = inttoptr i64 %v8865 to ptr
  %rgep8867 = getelementptr i8, ptr %p8866, i64 -16
  %ld8868 = load i64, ptr %rgep8867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8868, ptr %slot1392, align 8
  %v8869 = load i64, ptr %slot1392, align 8
  %op8870 = and i64 %v8869, 4611686018427387906
  store i64 %op8870, ptr %slot1393, align 8
  %v8871 = load i64, ptr %slot1393, align 8
  %cmp8872 = icmp ne i64 %v8871, 0
  %cv8873 = zext i1 %cmp8872 to i32
  store i32 %cv8873, ptr %slot1394, align 8
  %v8874 = load i32, ptr %slot1394, align 8
  %cv8875 = zext i32 %v8874 to i64
  %cond8876 = icmp ne i64 %cv8875, 0
  br i1 %cond8876, label %bb_rcgclear1724, label %bb_rcgcounted1724
bb_rcgcounted1724:
  %v8877 = load i64, ptr %slot1389, align 8
  %op8878 = sub i64 %v8877, 24
  store i64 %op8878, ptr %slot1395, align 8
  %v8879 = load i64, ptr %slot1389, align 8
  %p8880 = inttoptr i64 %v8879 to ptr
  %rgep8881 = getelementptr i8, ptr %p8880, i64 -24
  %ld8882 = load i64, ptr %rgep8881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8882, ptr %slot1396, align 8
  %v8883 = load i64, ptr %slot1396, align 8
  %op8884 = sub i64 %v8883, 1
  store i64 %op8884, ptr %slot1397, align 8
  %v8885 = load i64, ptr %slot1397, align 8
  %cmp8886 = icmp eq i64 %v8885, 0
  %cv8887 = zext i1 %cmp8886 to i32
  store i32 %cv8887, ptr %slot1398, align 8
  %v8888 = load i32, ptr %slot1398, align 8
  %cv8889 = zext i32 %v8888 to i64
  %cond8890 = icmp ne i64 %cv8889, 0
  br i1 %cond8890, label %bb_rcglast1724, label %bb_rcgdec1724
bb_rcglast1724:
  %v8891 = load i64, ptr %slot1389, align 8
  %op8892 = sub i64 %v8891, 32
  store i64 %op8892, ptr %slot1399, align 8
  %v8893 = load i64, ptr %slot1389, align 8
  %p8894 = inttoptr i64 %v8893 to ptr
  %rgep8895 = getelementptr i8, ptr %p8894, i64 -32
  %ld8896 = load i64, ptr %rgep8895, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8896, ptr %slot1400, align 8
  %v8897 = load i64, ptr %slot1400, align 8
  %cmp8898 = icmp ne i64 %v8897, 0
  %cv8899 = zext i1 %cmp8898 to i32
  store i32 %cv8899, ptr %slot1401, align 8
  %v8900 = load i32, ptr %slot1401, align 8
  %cv8901 = zext i32 %v8900 to i64
  %cond8902 = icmp ne i64 %cv8901, 0
  br i1 %cond8902, label %bb_rcgdec1724, label %bb_rcgslow1724
bb_rcgslow1724:
  %v8903 = load i64, ptr %slot1388, align 8
  %v8904 = load i64, ptr %slot1385, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v8903, i64 %v8904) nomerge, !dbg !160
  br label %bb_rcgdone1724
bb_rcgdec1724:
  %v8905 = load i64, ptr %slot1397, align 8
  %v8906 = load i64, ptr %slot1389, align 8
  %p8907 = inttoptr i64 %v8906 to ptr
  %rgep8908 = getelementptr i8, ptr %p8907, i64 -24
  store i64 %v8905, ptr %rgep8908, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1724
bb_rcgclear1724:
  %v8909 = load i64, ptr %slot1385, align 8
  %p8910 = inttoptr i64 %v8909 to ptr
  store i64 0, ptr %p8910, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1724
bb_rcgdone1724:
  br label %bb_rcslotdone1708
bb_rcslotowner1708:
  %v8911 = load i64, ptr %slot110, align 8
  store i64 %v8911, ptr %slot1402, align 8
  %v8912 = load i64, ptr %slot1385, align 8
  %p8913 = inttoptr i64 %v8912 to ptr
  %ld8914 = load i64, ptr %p8913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8914, ptr %slot1403, align 8
  %v8915 = load i64, ptr %slot1403, align 8
  %cmp8916 = icmp ne i64 %v8915, 0
  %cv8917 = zext i1 %cmp8916 to i32
  store i32 %cv8917, ptr %slot1404, align 8
  %v8918 = load i32, ptr %slot1404, align 8
  %cv8919 = zext i32 %v8918 to i64
  %cond8920 = icmp ne i64 %cv8919, 0
  br i1 %cond8920, label %bb_rcgnn1739, label %bb_rcgdone1739
bb_rcgnn1739:
  %v8921 = load i64, ptr %slot1403, align 8
  %op8922 = sub i64 %v8921, 16
  store i64 %op8922, ptr %slot1405, align 8
  %v8923 = load i64, ptr %slot1403, align 8
  %p8924 = inttoptr i64 %v8923 to ptr
  %rgep8925 = getelementptr i8, ptr %p8924, i64 -16
  %ld8926 = load i64, ptr %rgep8925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8926, ptr %slot1406, align 8
  %v8927 = load i64, ptr %slot1406, align 8
  %op8928 = and i64 %v8927, 4611686018427387906
  store i64 %op8928, ptr %slot1407, align 8
  %v8929 = load i64, ptr %slot1407, align 8
  %cmp8930 = icmp ne i64 %v8929, 0
  %cv8931 = zext i1 %cmp8930 to i32
  store i32 %cv8931, ptr %slot1408, align 8
  %v8932 = load i32, ptr %slot1408, align 8
  %cv8933 = zext i32 %v8932 to i64
  %cond8934 = icmp ne i64 %cv8933, 0
  br i1 %cond8934, label %bb_rcgclear1739, label %bb_rcgcounted1739
bb_rcgcounted1739:
  %v8935 = load i64, ptr %slot1403, align 8
  %op8936 = sub i64 %v8935, 32
  store i64 %op8936, ptr %slot1409, align 8
  %v8937 = load i64, ptr %slot1403, align 8
  %p8938 = inttoptr i64 %v8937 to ptr
  %rgep8939 = getelementptr i8, ptr %p8938, i64 -32
  %ld8940 = load i64, ptr %rgep8939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8940, ptr %slot1410, align 8
  %v8941 = load i64, ptr %slot1410, align 8
  %op8942 = sub i64 %v8941, 1
  store i64 %op8942, ptr %slot1411, align 8
  %v8943 = load i64, ptr %slot1411, align 8
  %cmp8944 = icmp eq i64 %v8943, 0
  %cv8945 = zext i1 %cmp8944 to i32
  store i32 %cv8945, ptr %slot1412, align 8
  %v8946 = load i32, ptr %slot1412, align 8
  %cv8947 = zext i32 %v8946 to i64
  %cond8948 = icmp ne i64 %cv8947, 0
  br i1 %cond8948, label %bb_rcglast1739, label %bb_rcgdec1739
bb_rcglast1739:
  %v8949 = load i64, ptr %slot1403, align 8
  %op8950 = sub i64 %v8949, 24
  store i64 %op8950, ptr %slot1413, align 8
  %v8951 = load i64, ptr %slot1403, align 8
  %p8952 = inttoptr i64 %v8951 to ptr
  %rgep8953 = getelementptr i8, ptr %p8952, i64 -24
  %ld8954 = load i64, ptr %rgep8953, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8954, ptr %slot1414, align 8
  %v8955 = load i64, ptr %slot1414, align 8
  %cmp8956 = icmp ne i64 %v8955, 0
  %cv8957 = zext i1 %cmp8956 to i32
  store i32 %cv8957, ptr %slot1415, align 8
  %v8958 = load i32, ptr %slot1415, align 8
  %cv8959 = zext i32 %v8958 to i64
  %cond8960 = icmp ne i64 %cv8959, 0
  br i1 %cond8960, label %bb_rcgdec1739, label %bb_rcgslow1739
bb_rcgslow1739:
  %v8961 = load i64, ptr %slot1402, align 8
  %v8962 = load i64, ptr %slot1385, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v8961, i64 %v8962) nomerge, !dbg !160
  br label %bb_rcgdone1739
bb_rcgdec1739:
  %v8963 = load i64, ptr %slot1411, align 8
  %v8964 = load i64, ptr %slot1403, align 8
  %p8965 = inttoptr i64 %v8964 to ptr
  %rgep8966 = getelementptr i8, ptr %p8965, i64 -32
  store i64 %v8963, ptr %rgep8966, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1739
bb_rcgclear1739:
  %v8967 = load i64, ptr %slot1385, align 8
  %p8968 = inttoptr i64 %v8967 to ptr
  store i64 0, ptr %p8968, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1739
bb_rcgdone1739:
  br label %bb_rcslotdone1708
bb_rcslotdone1708:
  br label %bb_rcprivateprepared1656
bb_rcprivateprepared1656:
  %v8969 = load i64, ptr %slot22, align 8
  %p8970 = inttoptr i64 %v8969 to ptr
  %ld8971 = load i32, ptr %p8970, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8971, ptr %slot1416, align 8
  %v8972 = load i32, ptr %slot1416, align 8
  %cv8973 = zext i32 %v8972 to i64
  %cond8974 = icmp ne i64 %cv8973, 0
  br i1 %cond8974, label %bb_rcslotdrop1746, label %bb_rcslotdone1746
bb_rcslotdrop1746:
  %v8975 = load i64, ptr %slot22, align 8
  %p8976 = inttoptr i64 %v8975 to ptr
  store i32 0, ptr %p8976, align 4, !alias.scope !3, !noalias !4
  %v8977 = load i64, ptr %slot77, align 8
  store i64 %v8977, ptr %slot1417, align 8
  %v8978 = load i64, ptr %slot23, align 8
  %p8979 = inttoptr i64 %v8978 to ptr
  %ld8980 = load i32, ptr %p8979, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8980, ptr %slot1418, align 8
  %v8981 = load i32, ptr %slot1418, align 8
  %op8982 = and i32 %v8981, 28
  store i32 %op8982, ptr %slot1419, align 8
  %v8983 = load i32, ptr %slot1419, align 8
  %cv8984 = zext i32 %v8983 to i64
  %cond8985 = icmp ne i64 %cv8984, 0
  br i1 %cond8985, label %bb_rcslotrole1746, label %bb_rcslotowner1746
bb_rcslotrole1746:
  %v8986 = load i64, ptr %slot110, align 8
  store i64 %v8986, ptr %slot1420, align 8
  %v8987 = load i64, ptr %slot1417, align 8
  %p8988 = inttoptr i64 %v8987 to ptr
  %ld8989 = load i64, ptr %p8988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8989, ptr %slot1421, align 8
  %v8990 = load i64, ptr %slot1421, align 8
  %cmp8991 = icmp ne i64 %v8990, 0
  %cv8992 = zext i1 %cmp8991 to i32
  store i32 %cv8992, ptr %slot1422, align 8
  %v8993 = load i32, ptr %slot1422, align 8
  %cv8994 = zext i32 %v8993 to i64
  %cond8995 = icmp ne i64 %cv8994, 0
  br i1 %cond8995, label %bb_rcgnn1762, label %bb_rcgdone1762
bb_rcgnn1762:
  %v8996 = load i64, ptr %slot1421, align 8
  %op8997 = sub i64 %v8996, 16
  store i64 %op8997, ptr %slot1423, align 8
  %v8998 = load i64, ptr %slot1421, align 8
  %p8999 = inttoptr i64 %v8998 to ptr
  %rgep9000 = getelementptr i8, ptr %p8999, i64 -16
  %ld9001 = load i64, ptr %rgep9000, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9001, ptr %slot1424, align 8
  %v9002 = load i64, ptr %slot1424, align 8
  %op9003 = and i64 %v9002, 4611686018427387906
  store i64 %op9003, ptr %slot1425, align 8
  %v9004 = load i64, ptr %slot1425, align 8
  %cmp9005 = icmp ne i64 %v9004, 0
  %cv9006 = zext i1 %cmp9005 to i32
  store i32 %cv9006, ptr %slot1426, align 8
  %v9007 = load i32, ptr %slot1426, align 8
  %cv9008 = zext i32 %v9007 to i64
  %cond9009 = icmp ne i64 %cv9008, 0
  br i1 %cond9009, label %bb_rcgclear1762, label %bb_rcgcounted1762
bb_rcgcounted1762:
  %v9010 = load i64, ptr %slot1421, align 8
  %op9011 = sub i64 %v9010, 24
  store i64 %op9011, ptr %slot1427, align 8
  %v9012 = load i64, ptr %slot1421, align 8
  %p9013 = inttoptr i64 %v9012 to ptr
  %rgep9014 = getelementptr i8, ptr %p9013, i64 -24
  %ld9015 = load i64, ptr %rgep9014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9015, ptr %slot1428, align 8
  %v9016 = load i64, ptr %slot1428, align 8
  %op9017 = sub i64 %v9016, 1
  store i64 %op9017, ptr %slot1429, align 8
  %v9018 = load i64, ptr %slot1429, align 8
  %cmp9019 = icmp eq i64 %v9018, 0
  %cv9020 = zext i1 %cmp9019 to i32
  store i32 %cv9020, ptr %slot1430, align 8
  %v9021 = load i32, ptr %slot1430, align 8
  %cv9022 = zext i32 %v9021 to i64
  %cond9023 = icmp ne i64 %cv9022, 0
  br i1 %cond9023, label %bb_rcglast1762, label %bb_rcgdec1762
bb_rcglast1762:
  %v9024 = load i64, ptr %slot1421, align 8
  %op9025 = sub i64 %v9024, 32
  store i64 %op9025, ptr %slot1431, align 8
  %v9026 = load i64, ptr %slot1421, align 8
  %p9027 = inttoptr i64 %v9026 to ptr
  %rgep9028 = getelementptr i8, ptr %p9027, i64 -32
  %ld9029 = load i64, ptr %rgep9028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9029, ptr %slot1432, align 8
  %v9030 = load i64, ptr %slot1432, align 8
  %cmp9031 = icmp ne i64 %v9030, 0
  %cv9032 = zext i1 %cmp9031 to i32
  store i32 %cv9032, ptr %slot1433, align 8
  %v9033 = load i32, ptr %slot1433, align 8
  %cv9034 = zext i32 %v9033 to i64
  %cond9035 = icmp ne i64 %cv9034, 0
  br i1 %cond9035, label %bb_rcgdec1762, label %bb_rcgslow1762
bb_rcgslow1762:
  %v9036 = load i64, ptr %slot1420, align 8
  %v9037 = load i64, ptr %slot1417, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v9036, i64 %v9037) nomerge, !dbg !160
  br label %bb_rcgdone1762
bb_rcgdec1762:
  %v9038 = load i64, ptr %slot1429, align 8
  %v9039 = load i64, ptr %slot1421, align 8
  %p9040 = inttoptr i64 %v9039 to ptr
  %rgep9041 = getelementptr i8, ptr %p9040, i64 -24
  store i64 %v9038, ptr %rgep9041, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1762
bb_rcgclear1762:
  %v9042 = load i64, ptr %slot1417, align 8
  %p9043 = inttoptr i64 %v9042 to ptr
  store i64 0, ptr %p9043, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1762
bb_rcgdone1762:
  br label %bb_rcslotdone1746
bb_rcslotowner1746:
  %v9044 = load i64, ptr %slot110, align 8
  store i64 %v9044, ptr %slot1434, align 8
  %v9045 = load i64, ptr %slot1417, align 8
  %p9046 = inttoptr i64 %v9045 to ptr
  %ld9047 = load i64, ptr %p9046, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9047, ptr %slot1435, align 8
  %v9048 = load i64, ptr %slot1435, align 8
  %cmp9049 = icmp ne i64 %v9048, 0
  %cv9050 = zext i1 %cmp9049 to i32
  store i32 %cv9050, ptr %slot1436, align 8
  %v9051 = load i32, ptr %slot1436, align 8
  %cv9052 = zext i32 %v9051 to i64
  %cond9053 = icmp ne i64 %cv9052, 0
  br i1 %cond9053, label %bb_rcgnn1777, label %bb_rcgdone1777
bb_rcgnn1777:
  %v9054 = load i64, ptr %slot1435, align 8
  %op9055 = sub i64 %v9054, 16
  store i64 %op9055, ptr %slot1437, align 8
  %v9056 = load i64, ptr %slot1435, align 8
  %p9057 = inttoptr i64 %v9056 to ptr
  %rgep9058 = getelementptr i8, ptr %p9057, i64 -16
  %ld9059 = load i64, ptr %rgep9058, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9059, ptr %slot1438, align 8
  %v9060 = load i64, ptr %slot1438, align 8
  %op9061 = and i64 %v9060, 4611686018427387906
  store i64 %op9061, ptr %slot1439, align 8
  %v9062 = load i64, ptr %slot1439, align 8
  %cmp9063 = icmp ne i64 %v9062, 0
  %cv9064 = zext i1 %cmp9063 to i32
  store i32 %cv9064, ptr %slot1440, align 8
  %v9065 = load i32, ptr %slot1440, align 8
  %cv9066 = zext i32 %v9065 to i64
  %cond9067 = icmp ne i64 %cv9066, 0
  br i1 %cond9067, label %bb_rcgclear1777, label %bb_rcgcounted1777
bb_rcgcounted1777:
  %v9068 = load i64, ptr %slot1435, align 8
  %op9069 = sub i64 %v9068, 32
  store i64 %op9069, ptr %slot1441, align 8
  %v9070 = load i64, ptr %slot1435, align 8
  %p9071 = inttoptr i64 %v9070 to ptr
  %rgep9072 = getelementptr i8, ptr %p9071, i64 -32
  %ld9073 = load i64, ptr %rgep9072, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9073, ptr %slot1442, align 8
  %v9074 = load i64, ptr %slot1442, align 8
  %op9075 = sub i64 %v9074, 1
  store i64 %op9075, ptr %slot1443, align 8
  %v9076 = load i64, ptr %slot1443, align 8
  %cmp9077 = icmp eq i64 %v9076, 0
  %cv9078 = zext i1 %cmp9077 to i32
  store i32 %cv9078, ptr %slot1444, align 8
  %v9079 = load i32, ptr %slot1444, align 8
  %cv9080 = zext i32 %v9079 to i64
  %cond9081 = icmp ne i64 %cv9080, 0
  br i1 %cond9081, label %bb_rcglast1777, label %bb_rcgdec1777
bb_rcglast1777:
  %v9082 = load i64, ptr %slot1435, align 8
  %op9083 = sub i64 %v9082, 24
  store i64 %op9083, ptr %slot1445, align 8
  %v9084 = load i64, ptr %slot1435, align 8
  %p9085 = inttoptr i64 %v9084 to ptr
  %rgep9086 = getelementptr i8, ptr %p9085, i64 -24
  %ld9087 = load i64, ptr %rgep9086, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9087, ptr %slot1446, align 8
  %v9088 = load i64, ptr %slot1446, align 8
  %cmp9089 = icmp ne i64 %v9088, 0
  %cv9090 = zext i1 %cmp9089 to i32
  store i32 %cv9090, ptr %slot1447, align 8
  %v9091 = load i32, ptr %slot1447, align 8
  %cv9092 = zext i32 %v9091 to i64
  %cond9093 = icmp ne i64 %cv9092, 0
  br i1 %cond9093, label %bb_rcgdec1777, label %bb_rcgslow1777
bb_rcgslow1777:
  %v9094 = load i64, ptr %slot1434, align 8
  %v9095 = load i64, ptr %slot1417, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v9094, i64 %v9095) nomerge, !dbg !160
  br label %bb_rcgdone1777
bb_rcgdec1777:
  %v9096 = load i64, ptr %slot1443, align 8
  %v9097 = load i64, ptr %slot1435, align 8
  %p9098 = inttoptr i64 %v9097 to ptr
  %rgep9099 = getelementptr i8, ptr %p9098, i64 -32
  store i64 %v9096, ptr %rgep9099, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1777
bb_rcgclear1777:
  %v9100 = load i64, ptr %slot1417, align 8
  %p9101 = inttoptr i64 %v9100 to ptr
  store i64 0, ptr %p9101, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1777
bb_rcgdone1777:
  br label %bb_rcslotdone1746
bb_rcslotdone1746:
  %v9102 = load i64, ptr %slot77, align 8
  store i64 %v9102, ptr %slot1448, align 8
  %v9103 = load i64, ptr %slot65, align 8
  store i64 %v9103, ptr %slot1449, align 8
  %v9104 = load i64, ptr %slot1449, align 8
  %v9105 = load i64, ptr %slot1448, align 8
  %p9106 = inttoptr i64 %v9104 to ptr
  %p9107 = inttoptr i64 %v9105 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9107, ptr %p9106, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9108 = load i64, ptr %slot46, align 8
  %p9109 = inttoptr i64 %v9108 to ptr
  store i32 0, ptr %p9109, align 4, !alias.scope !3, !noalias !4
  %v9110 = load i64, ptr %slot23, align 8
  %p9111 = inttoptr i64 %v9110 to ptr
  store i32 2, ptr %p9111, align 4, !alias.scope !3, !noalias !4
  %v9112 = load i64, ptr %slot47, align 8
  %p9113 = inttoptr i64 %v9112 to ptr
  %ld9114 = load i32, ptr %p9113, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9114, ptr %slot1450, align 8
  %v9115 = load i32, ptr %slot1450, align 8
  %v9116 = load i64, ptr %slot23, align 8
  %p9117 = inttoptr i64 %v9116 to ptr
  store i32 %v9115, ptr %p9117, align 4, !alias.scope !3, !noalias !4
  %v9118 = load i64, ptr %slot22, align 8
  %p9119 = inttoptr i64 %v9118 to ptr
  store i32 1, ptr %p9119, align 4, !alias.scope !3, !noalias !4
  %v9120 = load i64, ptr %slot77, align 8
  %p9121 = inttoptr i64 %v9120 to ptr
  %ld9122 = load i64, ptr %p9121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9122, ptr %slot1451, align 8
  %v9123 = load i64, ptr %slot1451, align 8
  %v9124 = load i64, ptr %slot97, align 8
  %p9125 = inttoptr i64 %v9124 to ptr
  store i64 %v9123, ptr %p9125, align 8, !alias.scope !3, !noalias !4
  %v9126 = load i64, ptr %slot98, align 8
  %p9127 = inttoptr i64 %v9126 to ptr
  store i64 18446744073709551615, ptr %p9127, align 8, !alias.scope !3, !noalias !4
  %v9128 = load i64, ptr %slot99, align 8
  %p9129 = inttoptr i64 %v9128 to ptr
  store i64 0, ptr %p9129, align 8, !alias.scope !3, !noalias !4
  %v9130 = load i64, ptr %slot99, align 8
  %p9131 = inttoptr i64 %v9130 to ptr
  %ld9132 = load i64, ptr %p9131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9132, ptr %slot1452, align 8
  %v9133 = load i64, ptr %slot1452, align 8
  %cmp9134 = icmp sge i64 %v9133, 0
  %cv9135 = zext i1 %cmp9134 to i64
  store i64 %cv9135, ptr %slot1453, align 8
  %v9136 = load i64, ptr %slot1453, align 8
  %cond9137 = icmp ne i64 %v9136, 0
  br i1 %cond9137, label %bb_success1791, label %bb_failed1791
bb_failed1791:
  %v9138 = load i64, ptr %slot1, align 8
  %p9139 = inttoptr i64 %v9138 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p9139) nomerge, !dbg !162
  unreachable
bb_success1791:
  %v9140 = load i64, ptr %slot110, align 8
  %p9141 = inttoptr i64 %v9140 to ptr
  %p9142 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v9143 = load i64, ptr %slot1452, align 8
  %call9144 = call ptr @myl_native_list_new(ptr %p9141, ptr %p9142, i64 %v9143) nomerge, !dbg !162
  %calladdr9145 = ptrtoint ptr %call9144 to i64
  store i64 %calladdr9145, ptr %slot1454, align 8
  %v9146 = load i64, ptr %slot1454, align 8
  %cond9147 = icmp ne i64 %v9146, 0
  br i1 %cond9147, label %bb_success1793, label %bb_failed1793
bb_failed1793:
  %v9148 = load i64, ptr %slot1, align 8
  %p9149 = inttoptr i64 %v9148 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9149) nomerge, !dbg !162
  unreachable
bb_success1793:
  %v9150 = load i64, ptr %slot1454, align 8
  %v9151 = load i64, ptr %slot99, align 8
  %p9152 = inttoptr i64 %v9151 to ptr
  store i64 %v9150, ptr %p9152, align 8, !alias.scope !3, !noalias !4
  %v9153 = load i64, ptr %slot99, align 8
  %p9154 = inttoptr i64 %v9153 to ptr
  %ld9155 = load i64, ptr %p9154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9155, ptr %slot1455, align 8
  %v9156 = load i64, ptr %slot1455, align 8
  %v9157 = load i64, ptr %slot63, align 8
  %p9158 = inttoptr i64 %v9157 to ptr
  store i64 %v9156, ptr %p9158, align 8, !alias.scope !3, !noalias !4
  %v9159 = load i64, ptr %slot63, align 8
  store i64 %v9159, ptr %slot1456, align 8
  %v9160 = load i64, ptr %slot65, align 8
  store i64 %v9160, ptr %slot1457, align 8
  %v9161 = load i64, ptr %slot1456, align 8
  %v9162 = load i64, ptr %slot1457, align 8
  %p9163 = inttoptr i64 %v9161 to ptr
  %p9164 = inttoptr i64 %v9162 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9164, ptr %p9163, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9165 = load i64, ptr %slot47, align 8
  %p9166 = inttoptr i64 %v9165 to ptr
  store i32 2, ptr %p9166, align 4, !alias.scope !3, !noalias !4
  %v9167 = load i64, ptr %slot46, align 8
  %p9168 = inttoptr i64 %v9167 to ptr
  store i32 1, ptr %p9168, align 4, !alias.scope !3, !noalias !4
  %v9169 = load i64, ptr %slot55, align 8
  store i64 %v9169, ptr %slot1458, align 8
  %v9170 = load i64, ptr %slot65, align 8
  store i64 %v9170, ptr %slot1459, align 8
  %v9171 = load i64, ptr %slot1459, align 8
  %v9172 = load i64, ptr %slot1458, align 8
  %p9173 = inttoptr i64 %v9171 to ptr
  %p9174 = inttoptr i64 %v9172 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9174, ptr %p9173, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9175 = load i64, ptr %slot43, align 8
  %p9176 = inttoptr i64 %v9175 to ptr
  store i32 2, ptr %p9176, align 4, !alias.scope !3, !noalias !4
  %v9177 = load i64, ptr %slot47, align 8
  %p9178 = inttoptr i64 %v9177 to ptr
  %ld9179 = load i32, ptr %p9178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9179, ptr %slot1460, align 8
  %v9180 = load i32, ptr %slot1460, align 8
  %v9181 = load i64, ptr %slot43, align 8
  %p9182 = inttoptr i64 %v9181 to ptr
  store i32 %v9180, ptr %p9182, align 4, !alias.scope !3, !noalias !4
  %v9183 = load i64, ptr %slot46, align 8
  %p9184 = inttoptr i64 %v9183 to ptr
  store i32 0, ptr %p9184, align 4, !alias.scope !3, !noalias !4
  %v9185 = load i64, ptr %slot42, align 8
  %p9186 = inttoptr i64 %v9185 to ptr
  store i32 1, ptr %p9186, align 4, !alias.scope !3, !noalias !4
  %v9187 = load i64, ptr %slot1458, align 8
  %p9188 = inttoptr i64 %v9187 to ptr
  %ld9189 = load i64, ptr %p9188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9189, ptr %slot1461, align 8
  %v9190 = load i64, ptr %slot1461, align 8
  %v9191 = load i64, ptr %slot99, align 8
  %p9192 = inttoptr i64 %v9191 to ptr
  store i64 %v9190, ptr %p9192, align 8, !alias.scope !3, !noalias !4
  %v9193 = load i64, ptr %slot99, align 8
  %p9194 = inttoptr i64 %v9193 to ptr
  %ld9195 = load i64, ptr %p9194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9195, ptr %slot1462, align 8
  %v9196 = load i64, ptr %slot1462, align 8
  %v9197 = load i64, ptr %slot63, align 8
  %p9198 = inttoptr i64 %v9197 to ptr
  store i64 %v9196, ptr %p9198, align 8, !alias.scope !3, !noalias !4
  %v9199 = load i64, ptr %slot63, align 8
  store i64 %v9199, ptr %slot1463, align 8
  %v9200 = load i64, ptr %slot42, align 8
  %p9201 = inttoptr i64 %v9200 to ptr
  %ld9202 = load i32, ptr %p9201, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9202, ptr %slot1464, align 8
  %v9203 = load i64, ptr %slot43, align 8
  %p9204 = inttoptr i64 %v9203 to ptr
  %ld9205 = load i32, ptr %p9204, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9205, ptr %slot1465, align 8
  %v9206 = load i32, ptr %slot1465, align 8
  %op9207 = and i32 %v9206, 24
  store i32 %op9207, ptr %slot1465, align 8
  %v9208 = load i32, ptr %slot1465, align 8
  %cmp9209 = icmp eq i32 %v9208, 0
  %cv9210 = zext i1 %cmp9209 to i32
  store i32 %cv9210, ptr %slot1466, align 8
  %v9211 = load i32, ptr %slot1464, align 8
  %v9212 = load i32, ptr %slot1466, align 8
  %op9213 = and i32 %v9211, %v9212
  store i32 %op9213, ptr %slot1467, align 8
  %v9214 = load i32, ptr %slot1467, align 8
  %cv9215 = zext i32 %v9214 to i64
  %cond9216 = icmp ne i64 %cv9215, 0
  br i1 %cond9216, label %bb_rcprivateown1816, label %bb_rcprivateloan1816
bb_rcprivateown1816:
  %v9217 = load i64, ptr %slot65, align 8
  store i64 %v9217, ptr %slot1468, align 8
  %v9218 = load i64, ptr %slot111, align 8
  store i64 %v9218, ptr %slot1469, align 8
  %v9219 = load i64, ptr %slot1463, align 8
  %v9220 = load i64, ptr %slot1468, align 8
  %op9221 = sub i64 %v9219, %v9220
  store i64 %op9221, ptr %slot1470, align 8
  %v9222 = load i64, ptr %slot1468, align 8
  %v9223 = load i64, ptr %slot1463, align 8
  %op9224 = sub i64 %v9222, %v9223
  store i64 %op9224, ptr %slot1471, align 8
  %v9225 = load i64, ptr %slot1470, align 8
  %cmp9226 = icmp ult i64 %v9225, 8
  %cv9227 = zext i1 %cmp9226 to i32
  store i32 %cv9227, ptr %slot1472, align 8
  %v9228 = load i64, ptr %slot1471, align 8
  %cmp9229 = icmp ult i64 %v9228, 8
  %cv9230 = zext i1 %cmp9229 to i32
  store i32 %cv9230, ptr %slot1473, align 8
  %v9231 = load i32, ptr %slot1472, align 8
  %v9232 = load i32, ptr %slot1473, align 8
  %op9233 = or i32 %v9231, %v9232
  store i32 %op9233, ptr %slot1474, align 8
  %v9234 = load i32, ptr %slot1474, align 8
  %cv9235 = zext i32 %v9234 to i64
  %cond9236 = icmp ne i64 %cv9235, 0
  br i1 %cond9236, label %bb_rcmoveslow1819, label %bb_rcmovecheck1819
bb_rcmovecheck1819:
  %v9237 = load i64, ptr %slot1463, align 8
  %p9239 = inttoptr i64 %v9237 to ptr
  %gep9240 = getelementptr i8, ptr %p9239, i64 0
  %op9238 = ptrtoint ptr %gep9240 to i64
  store i64 %op9238, ptr %slot1475, align 8
  %v9241 = load i64, ptr %slot1475, align 8
  %p9242 = inttoptr i64 %v9241 to ptr
  %ld9243 = load i64, ptr %p9242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9243, ptr %slot1476, align 8
  %v9244 = load i64, ptr %slot1476, align 8
  %cmp9245 = icmp ne i64 %v9244, 0
  %cv9246 = zext i1 %cmp9245 to i32
  store i32 %cv9246, ptr %slot1477, align 8
  %v9247 = load i32, ptr %slot1477, align 8
  %cv9248 = zext i32 %v9247 to i64
  %cond9249 = icmp ne i64 %cv9248, 0
  br i1 %cond9249, label %bb_rcmoveheader1827, label %bb_rcmovenext1827
bb_rcmoveheader1827:
  %v9250 = load i64, ptr %slot1476, align 8
  %op9251 = sub i64 %v9250, 16
  store i64 %op9251, ptr %slot1478, align 8
  %v9252 = load i64, ptr %slot1476, align 8
  %p9253 = inttoptr i64 %v9252 to ptr
  %rgep9254 = getelementptr i8, ptr %p9253, i64 -16
  %ld9255 = load i64, ptr %rgep9254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9255, ptr %slot1479, align 8
  %v9256 = load i64, ptr %slot1479, align 8
  %op9257 = and i64 %v9256, 5764607523034234881
  store i64 %op9257, ptr %slot1480, align 8
  %v9258 = load i64, ptr %slot1480, align 8
  %cmp9259 = icmp ne i64 %v9258, 0
  %cv9260 = zext i1 %cmp9259 to i32
  store i32 %cv9260, ptr %slot1481, align 8
  %v9261 = load i32, ptr %slot1481, align 8
  %cv9262 = zext i32 %v9261 to i64
  %cond9263 = icmp ne i64 %cv9262, 0
  br i1 %cond9263, label %bb_rcmoveslow1819, label %bb_rcmovenext1827
bb_rcmovenext1827:
  %v9264 = load i64, ptr %slot1463, align 8
  %v9265 = load i64, ptr %slot1468, align 8
  %p9266 = inttoptr i64 %v9264 to ptr
  %p9267 = inttoptr i64 %v9265 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9267, ptr %p9266, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9268 = load i64, ptr %slot1463, align 8
  %p9269 = inttoptr i64 %v9268 to ptr
  store i64 0, ptr %p9269, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1819
bb_rcmoveslow1819:
  %v9270 = load i64, ptr %slot110, align 8
  %v9271 = load i64, ptr %slot1468, align 8
  %v9272 = load i64, ptr %slot1463, align 8
  %v9273 = load i64, ptr %slot1469, align 8
  %cv9274 = trunc i64 %v9273 to i32
  %call9275 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v9270, i64 %v9271, i64 %v9272, i32 %cv9274) nomerge, !dbg !164
  store i32 %call9275, ptr %slot1482, align 8
  %v9276 = load i32, ptr %slot1482, align 8
  %cv9277 = zext i32 %v9276 to i64
  %cond9278 = icmp ne i64 %cv9277, 0
  br i1 %cond9278, label %bb_rcsuccess1834, label %bb_rcfailure1834
bb_rcfailure1834:
  %v9279 = load i64, ptr %slot110, align 8
  %p9280 = inttoptr i64 %v9279 to ptr
  %call9281 = call i32 @myl_rc_take_failure(ptr %p9280) nomerge, !dbg !164
  store i32 %call9281, ptr %slot1483, align 8
  %v9282 = load i64, ptr %slot1, align 8
  %p9283 = inttoptr i64 %v9282 to ptr
  %v9284 = load i32, ptr %slot1483, align 8
  %call9285 = call i32 @myl_qbe_rc_status(ptr %p9283, i32 %v9284) nomerge, !dbg !164
  store i32 %call9285, ptr %slot1484, align 8
  br label %bb_failure
bb_rcsuccess1834:
  br label %bb_rcmoved1819
bb_rcmoved1819:
  %v9286 = load i64, ptr %slot42, align 8
  %p9287 = inttoptr i64 %v9286 to ptr
  store i32 0, ptr %p9287, align 4, !alias.scope !3, !noalias !4
  %v9288 = load i64, ptr %slot47, align 8
  %p9289 = inttoptr i64 %v9288 to ptr
  store i32 2, ptr %p9289, align 4, !alias.scope !3, !noalias !4
  %v9290 = load i64, ptr %slot46, align 8
  %p9291 = inttoptr i64 %v9290 to ptr
  store i32 1, ptr %p9291, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1816
bb_rcprivateloan1816:
  %v9292 = load i64, ptr %slot42, align 8
  %p9293 = inttoptr i64 %v9292 to ptr
  %ld9294 = load i32, ptr %p9293, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9294, ptr %slot1485, align 8
  %v9295 = load i64, ptr %slot43, align 8
  %p9296 = inttoptr i64 %v9295 to ptr
  %ld9297 = load i32, ptr %p9296, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9297, ptr %slot1486, align 8
  %v9298 = load i32, ptr %slot1486, align 8
  %cmp9299 = icmp eq i32 %v9298, 16
  %cv9300 = zext i1 %cmp9299 to i32
  store i32 %cv9300, ptr %slot1487, align 8
  %v9301 = load i32, ptr %slot1487, align 8
  %v9302 = load i32, ptr %slot1485, align 8
  %op9303 = and i32 %v9301, %v9302
  store i32 %op9303, ptr %slot1487, align 8
  %v9304 = load i32, ptr %slot1487, align 8
  %cv9305 = zext i32 %v9304 to i64
  %cond9306 = icmp ne i64 %cv9305, 0
  br i1 %cond9306, label %bb_rcprivatemove1816, label %bb_rcprivatenew1816
bb_rcprivatemove1816:
  %v9307 = load i64, ptr %slot65, align 8
  store i64 %v9307, ptr %slot1488, align 8
  %v9308 = load i64, ptr %slot1463, align 8
  %v9309 = load i64, ptr %slot1488, align 8
  %p9310 = inttoptr i64 %v9308 to ptr
  %p9311 = inttoptr i64 %v9309 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9311, ptr %p9310, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9312 = load i64, ptr %slot1463, align 8
  %p9313 = inttoptr i64 %v9312 to ptr
  store i64 0, ptr %p9313, align 8, !alias.scope !3, !noalias !4
  %v9314 = load i64, ptr %slot47, align 8
  %p9315 = inttoptr i64 %v9314 to ptr
  store i32 2, ptr %p9315, align 4, !alias.scope !3, !noalias !4
  %v9316 = load i64, ptr %slot47, align 8
  %p9317 = inttoptr i64 %v9316 to ptr
  store i32 16, ptr %p9317, align 4, !alias.scope !3, !noalias !4
  %v9318 = load i64, ptr %slot46, align 8
  %p9319 = inttoptr i64 %v9318 to ptr
  store i32 1, ptr %p9319, align 4, !alias.scope !3, !noalias !4
  %v9320 = load i64, ptr %slot42, align 8
  %p9321 = inttoptr i64 %v9320 to ptr
  store i32 0, ptr %p9321, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1816
bb_rcprivatenew1816:
  %v9322 = load i64, ptr %slot65, align 8
  store i64 %v9322, ptr %slot1489, align 8
  %v9323 = load i64, ptr %slot1463, align 8
  %p9324 = inttoptr i64 %v9323 to ptr
  %ld9325 = load i64, ptr %p9324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9325, ptr %slot1490, align 8
  %v9326 = load i64, ptr %slot1490, align 8
  %cmp9327 = icmp ne i64 %v9326, 0
  %cv9328 = zext i1 %cmp9327 to i32
  store i32 %cv9328, ptr %slot1491, align 8
  %v9329 = load i32, ptr %slot1491, align 8
  %cv9330 = zext i32 %v9329 to i64
  %cond9331 = icmp ne i64 %cv9330, 0
  br i1 %cond9331, label %bb_rcgnn1852, label %bb_rcgstore1852
bb_rcgnn1852:
  %v9332 = load i64, ptr %slot1490, align 8
  %op9333 = sub i64 %v9332, 16
  store i64 %op9333, ptr %slot1492, align 8
  %v9334 = load i64, ptr %slot1490, align 8
  %p9335 = inttoptr i64 %v9334 to ptr
  %rgep9336 = getelementptr i8, ptr %p9335, i64 -16
  %ld9337 = load i64, ptr %rgep9336, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9337, ptr %slot1493, align 8
  %v9338 = load i64, ptr %slot1493, align 8
  %op9339 = and i64 %v9338, 4611686018427387906
  store i64 %op9339, ptr %slot1494, align 8
  %v9340 = load i64, ptr %slot1494, align 8
  %cmp9341 = icmp ne i64 %v9340, 0
  %cv9342 = zext i1 %cmp9341 to i32
  store i32 %cv9342, ptr %slot1495, align 8
  %v9343 = load i32, ptr %slot1495, align 8
  %cv9344 = zext i32 %v9343 to i64
  %cond9345 = icmp ne i64 %cv9344, 0
  br i1 %cond9345, label %bb_rcgstore1852, label %bb_rcginc1852
bb_rcginc1852:
  %v9346 = load i64, ptr %slot1490, align 8
  %op9347 = sub i64 %v9346, 24
  store i64 %op9347, ptr %slot1496, align 8
  %v9348 = load i64, ptr %slot1490, align 8
  %p9349 = inttoptr i64 %v9348 to ptr
  %rgep9350 = getelementptr i8, ptr %p9349, i64 -24
  %ld9351 = load i64, ptr %rgep9350, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9351, ptr %slot1497, align 8
  %v9352 = load i64, ptr %slot1497, align 8
  %op9353 = add i64 %v9352, 1
  store i64 %op9353, ptr %slot1498, align 8
  %v9354 = load i64, ptr %slot1498, align 8
  %cmp9355 = icmp eq i64 %v9354, 0
  %cv9356 = zext i1 %cmp9355 to i32
  store i32 %cv9356, ptr %slot1499, align 8
  %v9357 = load i32, ptr %slot1499, align 8
  %cv9358 = zext i32 %v9357 to i64
  %cond9359 = icmp ne i64 %cv9358, 0
  br i1 %cond9359, label %bb_rcglimit1852, label %bb_rcgcapacity1852
bb_rcglimit1852:
  %v9360 = load i64, ptr %slot1, align 8
  %p9361 = inttoptr i64 %v9360 to ptr
  %call9362 = call i32 @myl_qbe_rc_status(ptr %p9361, i32 2) nomerge, !dbg !164
  store i32 %call9362, ptr %slot1500, align 8
  br label %bb_failure
bb_rcgcapacity1852:
  %v9363 = load i64, ptr %slot1498, align 8
  %v9364 = load i64, ptr %slot1490, align 8
  %p9365 = inttoptr i64 %v9364 to ptr
  %rgep9366 = getelementptr i8, ptr %p9365, i64 -24
  store i64 %v9363, ptr %rgep9366, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1852
bb_rcgstore1852:
  %v9367 = load i64, ptr %slot1490, align 8
  %v9368 = load i64, ptr %slot1489, align 8
  %p9369 = inttoptr i64 %v9368 to ptr
  store i64 %v9367, ptr %p9369, align 8, !alias.scope !3, !noalias !4
  %v9370 = load i64, ptr %slot47, align 8
  %p9371 = inttoptr i64 %v9370 to ptr
  store i32 2, ptr %p9371, align 4, !alias.scope !3, !noalias !4
  %v9372 = load i64, ptr %slot47, align 8
  %p9373 = inttoptr i64 %v9372 to ptr
  store i32 16, ptr %p9373, align 4, !alias.scope !3, !noalias !4
  %v9374 = load i64, ptr %slot46, align 8
  %p9375 = inttoptr i64 %v9374 to ptr
  store i32 1, ptr %p9375, align 4, !alias.scope !3, !noalias !4
  %v9376 = load i64, ptr %slot42, align 8
  %p9377 = inttoptr i64 %v9376 to ptr
  %ld9378 = load i32, ptr %p9377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9378, ptr %slot1501, align 8
  %v9379 = load i32, ptr %slot1501, align 8
  %cv9380 = zext i32 %v9379 to i64
  %cond9381 = icmp ne i64 %cv9380, 0
  br i1 %cond9381, label %bb_rcslotdrop1868, label %bb_rcslotdone1868
bb_rcslotdrop1868:
  %v9382 = load i64, ptr %slot42, align 8
  %p9383 = inttoptr i64 %v9382 to ptr
  store i32 0, ptr %p9383, align 4, !alias.scope !3, !noalias !4
  %v9384 = load i64, ptr %slot55, align 8
  store i64 %v9384, ptr %slot1502, align 8
  %v9385 = load i64, ptr %slot43, align 8
  %p9386 = inttoptr i64 %v9385 to ptr
  %ld9387 = load i32, ptr %p9386, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9387, ptr %slot1503, align 8
  %v9388 = load i32, ptr %slot1503, align 8
  %op9389 = and i32 %v9388, 28
  store i32 %op9389, ptr %slot1504, align 8
  %v9390 = load i32, ptr %slot1504, align 8
  %cv9391 = zext i32 %v9390 to i64
  %cond9392 = icmp ne i64 %cv9391, 0
  br i1 %cond9392, label %bb_rcslotrole1868, label %bb_rcslotowner1868
bb_rcslotrole1868:
  %v9393 = load i64, ptr %slot110, align 8
  store i64 %v9393, ptr %slot1505, align 8
  %v9394 = load i64, ptr %slot1502, align 8
  %p9395 = inttoptr i64 %v9394 to ptr
  %ld9396 = load i64, ptr %p9395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9396, ptr %slot1506, align 8
  %v9397 = load i64, ptr %slot1506, align 8
  %cmp9398 = icmp ne i64 %v9397, 0
  %cv9399 = zext i1 %cmp9398 to i32
  store i32 %cv9399, ptr %slot1507, align 8
  %v9400 = load i32, ptr %slot1507, align 8
  %cv9401 = zext i32 %v9400 to i64
  %cond9402 = icmp ne i64 %cv9401, 0
  br i1 %cond9402, label %bb_rcgnn1884, label %bb_rcgdone1884
bb_rcgnn1884:
  %v9403 = load i64, ptr %slot1506, align 8
  %op9404 = sub i64 %v9403, 16
  store i64 %op9404, ptr %slot1508, align 8
  %v9405 = load i64, ptr %slot1506, align 8
  %p9406 = inttoptr i64 %v9405 to ptr
  %rgep9407 = getelementptr i8, ptr %p9406, i64 -16
  %ld9408 = load i64, ptr %rgep9407, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9408, ptr %slot1509, align 8
  %v9409 = load i64, ptr %slot1509, align 8
  %op9410 = and i64 %v9409, 4611686018427387906
  store i64 %op9410, ptr %slot1510, align 8
  %v9411 = load i64, ptr %slot1510, align 8
  %cmp9412 = icmp ne i64 %v9411, 0
  %cv9413 = zext i1 %cmp9412 to i32
  store i32 %cv9413, ptr %slot1511, align 8
  %v9414 = load i32, ptr %slot1511, align 8
  %cv9415 = zext i32 %v9414 to i64
  %cond9416 = icmp ne i64 %cv9415, 0
  br i1 %cond9416, label %bb_rcgclear1884, label %bb_rcgcounted1884
bb_rcgcounted1884:
  %v9417 = load i64, ptr %slot1506, align 8
  %op9418 = sub i64 %v9417, 24
  store i64 %op9418, ptr %slot1512, align 8
  %v9419 = load i64, ptr %slot1506, align 8
  %p9420 = inttoptr i64 %v9419 to ptr
  %rgep9421 = getelementptr i8, ptr %p9420, i64 -24
  %ld9422 = load i64, ptr %rgep9421, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9422, ptr %slot1513, align 8
  %v9423 = load i64, ptr %slot1513, align 8
  %op9424 = sub i64 %v9423, 1
  store i64 %op9424, ptr %slot1514, align 8
  %v9425 = load i64, ptr %slot1514, align 8
  %cmp9426 = icmp eq i64 %v9425, 0
  %cv9427 = zext i1 %cmp9426 to i32
  store i32 %cv9427, ptr %slot1515, align 8
  %v9428 = load i32, ptr %slot1515, align 8
  %cv9429 = zext i32 %v9428 to i64
  %cond9430 = icmp ne i64 %cv9429, 0
  br i1 %cond9430, label %bb_rcglast1884, label %bb_rcgdec1884
bb_rcglast1884:
  %v9431 = load i64, ptr %slot1506, align 8
  %op9432 = sub i64 %v9431, 32
  store i64 %op9432, ptr %slot1516, align 8
  %v9433 = load i64, ptr %slot1506, align 8
  %p9434 = inttoptr i64 %v9433 to ptr
  %rgep9435 = getelementptr i8, ptr %p9434, i64 -32
  %ld9436 = load i64, ptr %rgep9435, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9436, ptr %slot1517, align 8
  %v9437 = load i64, ptr %slot1517, align 8
  %cmp9438 = icmp ne i64 %v9437, 0
  %cv9439 = zext i1 %cmp9438 to i32
  store i32 %cv9439, ptr %slot1518, align 8
  %v9440 = load i32, ptr %slot1518, align 8
  %cv9441 = zext i32 %v9440 to i64
  %cond9442 = icmp ne i64 %cv9441, 0
  br i1 %cond9442, label %bb_rcgdec1884, label %bb_rcgslow1884
bb_rcgslow1884:
  %v9443 = load i64, ptr %slot1505, align 8
  %v9444 = load i64, ptr %slot1502, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v9443, i64 %v9444) nomerge, !dbg !164
  br label %bb_rcgdone1884
bb_rcgdec1884:
  %v9445 = load i64, ptr %slot1514, align 8
  %v9446 = load i64, ptr %slot1506, align 8
  %p9447 = inttoptr i64 %v9446 to ptr
  %rgep9448 = getelementptr i8, ptr %p9447, i64 -24
  store i64 %v9445, ptr %rgep9448, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1884
bb_rcgclear1884:
  %v9449 = load i64, ptr %slot1502, align 8
  %p9450 = inttoptr i64 %v9449 to ptr
  store i64 0, ptr %p9450, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1884
bb_rcgdone1884:
  br label %bb_rcslotdone1868
bb_rcslotowner1868:
  %v9451 = load i64, ptr %slot110, align 8
  store i64 %v9451, ptr %slot1519, align 8
  %v9452 = load i64, ptr %slot1502, align 8
  %p9453 = inttoptr i64 %v9452 to ptr
  %ld9454 = load i64, ptr %p9453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9454, ptr %slot1520, align 8
  %v9455 = load i64, ptr %slot1520, align 8
  %cmp9456 = icmp ne i64 %v9455, 0
  %cv9457 = zext i1 %cmp9456 to i32
  store i32 %cv9457, ptr %slot1521, align 8
  %v9458 = load i32, ptr %slot1521, align 8
  %cv9459 = zext i32 %v9458 to i64
  %cond9460 = icmp ne i64 %cv9459, 0
  br i1 %cond9460, label %bb_rcgnn1899, label %bb_rcgdone1899
bb_rcgnn1899:
  %v9461 = load i64, ptr %slot1520, align 8
  %op9462 = sub i64 %v9461, 16
  store i64 %op9462, ptr %slot1522, align 8
  %v9463 = load i64, ptr %slot1520, align 8
  %p9464 = inttoptr i64 %v9463 to ptr
  %rgep9465 = getelementptr i8, ptr %p9464, i64 -16
  %ld9466 = load i64, ptr %rgep9465, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9466, ptr %slot1523, align 8
  %v9467 = load i64, ptr %slot1523, align 8
  %op9468 = and i64 %v9467, 4611686018427387906
  store i64 %op9468, ptr %slot1524, align 8
  %v9469 = load i64, ptr %slot1524, align 8
  %cmp9470 = icmp ne i64 %v9469, 0
  %cv9471 = zext i1 %cmp9470 to i32
  store i32 %cv9471, ptr %slot1525, align 8
  %v9472 = load i32, ptr %slot1525, align 8
  %cv9473 = zext i32 %v9472 to i64
  %cond9474 = icmp ne i64 %cv9473, 0
  br i1 %cond9474, label %bb_rcgclear1899, label %bb_rcgcounted1899
bb_rcgcounted1899:
  %v9475 = load i64, ptr %slot1520, align 8
  %op9476 = sub i64 %v9475, 32
  store i64 %op9476, ptr %slot1526, align 8
  %v9477 = load i64, ptr %slot1520, align 8
  %p9478 = inttoptr i64 %v9477 to ptr
  %rgep9479 = getelementptr i8, ptr %p9478, i64 -32
  %ld9480 = load i64, ptr %rgep9479, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9480, ptr %slot1527, align 8
  %v9481 = load i64, ptr %slot1527, align 8
  %op9482 = sub i64 %v9481, 1
  store i64 %op9482, ptr %slot1528, align 8
  %v9483 = load i64, ptr %slot1528, align 8
  %cmp9484 = icmp eq i64 %v9483, 0
  %cv9485 = zext i1 %cmp9484 to i32
  store i32 %cv9485, ptr %slot1529, align 8
  %v9486 = load i32, ptr %slot1529, align 8
  %cv9487 = zext i32 %v9486 to i64
  %cond9488 = icmp ne i64 %cv9487, 0
  br i1 %cond9488, label %bb_rcglast1899, label %bb_rcgdec1899
bb_rcglast1899:
  %v9489 = load i64, ptr %slot1520, align 8
  %op9490 = sub i64 %v9489, 24
  store i64 %op9490, ptr %slot1530, align 8
  %v9491 = load i64, ptr %slot1520, align 8
  %p9492 = inttoptr i64 %v9491 to ptr
  %rgep9493 = getelementptr i8, ptr %p9492, i64 -24
  %ld9494 = load i64, ptr %rgep9493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9494, ptr %slot1531, align 8
  %v9495 = load i64, ptr %slot1531, align 8
  %cmp9496 = icmp ne i64 %v9495, 0
  %cv9497 = zext i1 %cmp9496 to i32
  store i32 %cv9497, ptr %slot1532, align 8
  %v9498 = load i32, ptr %slot1532, align 8
  %cv9499 = zext i32 %v9498 to i64
  %cond9500 = icmp ne i64 %cv9499, 0
  br i1 %cond9500, label %bb_rcgdec1899, label %bb_rcgslow1899
bb_rcgslow1899:
  %v9501 = load i64, ptr %slot1519, align 8
  %v9502 = load i64, ptr %slot1502, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v9501, i64 %v9502) nomerge, !dbg !164
  br label %bb_rcgdone1899
bb_rcgdec1899:
  %v9503 = load i64, ptr %slot1528, align 8
  %v9504 = load i64, ptr %slot1520, align 8
  %p9505 = inttoptr i64 %v9504 to ptr
  %rgep9506 = getelementptr i8, ptr %p9505, i64 -32
  store i64 %v9503, ptr %rgep9506, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1899
bb_rcgclear1899:
  %v9507 = load i64, ptr %slot1502, align 8
  %p9508 = inttoptr i64 %v9507 to ptr
  store i64 0, ptr %p9508, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1899
bb_rcgdone1899:
  br label %bb_rcslotdone1868
bb_rcslotdone1868:
  br label %bb_rcprivateprepared1816
bb_rcprivateprepared1816:
  %v9509 = load i64, ptr %slot24, align 8
  %p9510 = inttoptr i64 %v9509 to ptr
  %ld9511 = load i32, ptr %p9510, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9511, ptr %slot1533, align 8
  %v9512 = load i32, ptr %slot1533, align 8
  %cv9513 = zext i32 %v9512 to i64
  %cond9514 = icmp ne i64 %cv9513, 0
  br i1 %cond9514, label %bb_rcslotdrop1906, label %bb_rcslotdone1906
bb_rcslotdrop1906:
  %v9515 = load i64, ptr %slot24, align 8
  %p9516 = inttoptr i64 %v9515 to ptr
  store i32 0, ptr %p9516, align 4, !alias.scope !3, !noalias !4
  %v9517 = load i64, ptr %slot78, align 8
  store i64 %v9517, ptr %slot1534, align 8
  %v9518 = load i64, ptr %slot25, align 8
  %p9519 = inttoptr i64 %v9518 to ptr
  %ld9520 = load i32, ptr %p9519, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9520, ptr %slot1535, align 8
  %v9521 = load i32, ptr %slot1535, align 8
  %op9522 = and i32 %v9521, 28
  store i32 %op9522, ptr %slot1536, align 8
  %v9523 = load i32, ptr %slot1536, align 8
  %cv9524 = zext i32 %v9523 to i64
  %cond9525 = icmp ne i64 %cv9524, 0
  br i1 %cond9525, label %bb_rcslotrole1906, label %bb_rcslotowner1906
bb_rcslotrole1906:
  %v9526 = load i64, ptr %slot110, align 8
  store i64 %v9526, ptr %slot1537, align 8
  %v9527 = load i64, ptr %slot1534, align 8
  %p9528 = inttoptr i64 %v9527 to ptr
  %ld9529 = load i64, ptr %p9528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9529, ptr %slot1538, align 8
  %v9530 = load i64, ptr %slot1538, align 8
  %cmp9531 = icmp ne i64 %v9530, 0
  %cv9532 = zext i1 %cmp9531 to i32
  store i32 %cv9532, ptr %slot1539, align 8
  %v9533 = load i32, ptr %slot1539, align 8
  %cv9534 = zext i32 %v9533 to i64
  %cond9535 = icmp ne i64 %cv9534, 0
  br i1 %cond9535, label %bb_rcgnn1922, label %bb_rcgdone1922
bb_rcgnn1922:
  %v9536 = load i64, ptr %slot1538, align 8
  %op9537 = sub i64 %v9536, 16
  store i64 %op9537, ptr %slot1540, align 8
  %v9538 = load i64, ptr %slot1538, align 8
  %p9539 = inttoptr i64 %v9538 to ptr
  %rgep9540 = getelementptr i8, ptr %p9539, i64 -16
  %ld9541 = load i64, ptr %rgep9540, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9541, ptr %slot1541, align 8
  %v9542 = load i64, ptr %slot1541, align 8
  %op9543 = and i64 %v9542, 4611686018427387906
  store i64 %op9543, ptr %slot1542, align 8
  %v9544 = load i64, ptr %slot1542, align 8
  %cmp9545 = icmp ne i64 %v9544, 0
  %cv9546 = zext i1 %cmp9545 to i32
  store i32 %cv9546, ptr %slot1543, align 8
  %v9547 = load i32, ptr %slot1543, align 8
  %cv9548 = zext i32 %v9547 to i64
  %cond9549 = icmp ne i64 %cv9548, 0
  br i1 %cond9549, label %bb_rcgclear1922, label %bb_rcgcounted1922
bb_rcgcounted1922:
  %v9550 = load i64, ptr %slot1538, align 8
  %op9551 = sub i64 %v9550, 24
  store i64 %op9551, ptr %slot1544, align 8
  %v9552 = load i64, ptr %slot1538, align 8
  %p9553 = inttoptr i64 %v9552 to ptr
  %rgep9554 = getelementptr i8, ptr %p9553, i64 -24
  %ld9555 = load i64, ptr %rgep9554, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9555, ptr %slot1545, align 8
  %v9556 = load i64, ptr %slot1545, align 8
  %op9557 = sub i64 %v9556, 1
  store i64 %op9557, ptr %slot1546, align 8
  %v9558 = load i64, ptr %slot1546, align 8
  %cmp9559 = icmp eq i64 %v9558, 0
  %cv9560 = zext i1 %cmp9559 to i32
  store i32 %cv9560, ptr %slot1547, align 8
  %v9561 = load i32, ptr %slot1547, align 8
  %cv9562 = zext i32 %v9561 to i64
  %cond9563 = icmp ne i64 %cv9562, 0
  br i1 %cond9563, label %bb_rcglast1922, label %bb_rcgdec1922
bb_rcglast1922:
  %v9564 = load i64, ptr %slot1538, align 8
  %op9565 = sub i64 %v9564, 32
  store i64 %op9565, ptr %slot1548, align 8
  %v9566 = load i64, ptr %slot1538, align 8
  %p9567 = inttoptr i64 %v9566 to ptr
  %rgep9568 = getelementptr i8, ptr %p9567, i64 -32
  %ld9569 = load i64, ptr %rgep9568, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9569, ptr %slot1549, align 8
  %v9570 = load i64, ptr %slot1549, align 8
  %cmp9571 = icmp ne i64 %v9570, 0
  %cv9572 = zext i1 %cmp9571 to i32
  store i32 %cv9572, ptr %slot1550, align 8
  %v9573 = load i32, ptr %slot1550, align 8
  %cv9574 = zext i32 %v9573 to i64
  %cond9575 = icmp ne i64 %cv9574, 0
  br i1 %cond9575, label %bb_rcgdec1922, label %bb_rcgslow1922
bb_rcgslow1922:
  %v9576 = load i64, ptr %slot1537, align 8
  %v9577 = load i64, ptr %slot1534, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v9576, i64 %v9577) nomerge, !dbg !164
  br label %bb_rcgdone1922
bb_rcgdec1922:
  %v9578 = load i64, ptr %slot1546, align 8
  %v9579 = load i64, ptr %slot1538, align 8
  %p9580 = inttoptr i64 %v9579 to ptr
  %rgep9581 = getelementptr i8, ptr %p9580, i64 -24
  store i64 %v9578, ptr %rgep9581, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1922
bb_rcgclear1922:
  %v9582 = load i64, ptr %slot1534, align 8
  %p9583 = inttoptr i64 %v9582 to ptr
  store i64 0, ptr %p9583, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1922
bb_rcgdone1922:
  br label %bb_rcslotdone1906
bb_rcslotowner1906:
  %v9584 = load i64, ptr %slot110, align 8
  store i64 %v9584, ptr %slot1551, align 8
  %v9585 = load i64, ptr %slot1534, align 8
  %p9586 = inttoptr i64 %v9585 to ptr
  %ld9587 = load i64, ptr %p9586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9587, ptr %slot1552, align 8
  %v9588 = load i64, ptr %slot1552, align 8
  %cmp9589 = icmp ne i64 %v9588, 0
  %cv9590 = zext i1 %cmp9589 to i32
  store i32 %cv9590, ptr %slot1553, align 8
  %v9591 = load i32, ptr %slot1553, align 8
  %cv9592 = zext i32 %v9591 to i64
  %cond9593 = icmp ne i64 %cv9592, 0
  br i1 %cond9593, label %bb_rcgnn1937, label %bb_rcgdone1937
bb_rcgnn1937:
  %v9594 = load i64, ptr %slot1552, align 8
  %op9595 = sub i64 %v9594, 16
  store i64 %op9595, ptr %slot1554, align 8
  %v9596 = load i64, ptr %slot1552, align 8
  %p9597 = inttoptr i64 %v9596 to ptr
  %rgep9598 = getelementptr i8, ptr %p9597, i64 -16
  %ld9599 = load i64, ptr %rgep9598, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9599, ptr %slot1555, align 8
  %v9600 = load i64, ptr %slot1555, align 8
  %op9601 = and i64 %v9600, 4611686018427387906
  store i64 %op9601, ptr %slot1556, align 8
  %v9602 = load i64, ptr %slot1556, align 8
  %cmp9603 = icmp ne i64 %v9602, 0
  %cv9604 = zext i1 %cmp9603 to i32
  store i32 %cv9604, ptr %slot1557, align 8
  %v9605 = load i32, ptr %slot1557, align 8
  %cv9606 = zext i32 %v9605 to i64
  %cond9607 = icmp ne i64 %cv9606, 0
  br i1 %cond9607, label %bb_rcgclear1937, label %bb_rcgcounted1937
bb_rcgcounted1937:
  %v9608 = load i64, ptr %slot1552, align 8
  %op9609 = sub i64 %v9608, 32
  store i64 %op9609, ptr %slot1558, align 8
  %v9610 = load i64, ptr %slot1552, align 8
  %p9611 = inttoptr i64 %v9610 to ptr
  %rgep9612 = getelementptr i8, ptr %p9611, i64 -32
  %ld9613 = load i64, ptr %rgep9612, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9613, ptr %slot1559, align 8
  %v9614 = load i64, ptr %slot1559, align 8
  %op9615 = sub i64 %v9614, 1
  store i64 %op9615, ptr %slot1560, align 8
  %v9616 = load i64, ptr %slot1560, align 8
  %cmp9617 = icmp eq i64 %v9616, 0
  %cv9618 = zext i1 %cmp9617 to i32
  store i32 %cv9618, ptr %slot1561, align 8
  %v9619 = load i32, ptr %slot1561, align 8
  %cv9620 = zext i32 %v9619 to i64
  %cond9621 = icmp ne i64 %cv9620, 0
  br i1 %cond9621, label %bb_rcglast1937, label %bb_rcgdec1937
bb_rcglast1937:
  %v9622 = load i64, ptr %slot1552, align 8
  %op9623 = sub i64 %v9622, 24
  store i64 %op9623, ptr %slot1562, align 8
  %v9624 = load i64, ptr %slot1552, align 8
  %p9625 = inttoptr i64 %v9624 to ptr
  %rgep9626 = getelementptr i8, ptr %p9625, i64 -24
  %ld9627 = load i64, ptr %rgep9626, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9627, ptr %slot1563, align 8
  %v9628 = load i64, ptr %slot1563, align 8
  %cmp9629 = icmp ne i64 %v9628, 0
  %cv9630 = zext i1 %cmp9629 to i32
  store i32 %cv9630, ptr %slot1564, align 8
  %v9631 = load i32, ptr %slot1564, align 8
  %cv9632 = zext i32 %v9631 to i64
  %cond9633 = icmp ne i64 %cv9632, 0
  br i1 %cond9633, label %bb_rcgdec1937, label %bb_rcgslow1937
bb_rcgslow1937:
  %v9634 = load i64, ptr %slot1551, align 8
  %v9635 = load i64, ptr %slot1534, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v9634, i64 %v9635) nomerge, !dbg !164
  br label %bb_rcgdone1937
bb_rcgdec1937:
  %v9636 = load i64, ptr %slot1560, align 8
  %v9637 = load i64, ptr %slot1552, align 8
  %p9638 = inttoptr i64 %v9637 to ptr
  %rgep9639 = getelementptr i8, ptr %p9638, i64 -32
  store i64 %v9636, ptr %rgep9639, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1937
bb_rcgclear1937:
  %v9640 = load i64, ptr %slot1534, align 8
  %p9641 = inttoptr i64 %v9640 to ptr
  store i64 0, ptr %p9641, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1937
bb_rcgdone1937:
  br label %bb_rcslotdone1906
bb_rcslotdone1906:
  %v9642 = load i64, ptr %slot78, align 8
  store i64 %v9642, ptr %slot1565, align 8
  %v9643 = load i64, ptr %slot65, align 8
  store i64 %v9643, ptr %slot1566, align 8
  %v9644 = load i64, ptr %slot1566, align 8
  %v9645 = load i64, ptr %slot1565, align 8
  %p9646 = inttoptr i64 %v9644 to ptr
  %p9647 = inttoptr i64 %v9645 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9647, ptr %p9646, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9648 = load i64, ptr %slot46, align 8
  %p9649 = inttoptr i64 %v9648 to ptr
  store i32 0, ptr %p9649, align 4, !alias.scope !3, !noalias !4
  %v9650 = load i64, ptr %slot25, align 8
  %p9651 = inttoptr i64 %v9650 to ptr
  store i32 2, ptr %p9651, align 4, !alias.scope !3, !noalias !4
  %v9652 = load i64, ptr %slot47, align 8
  %p9653 = inttoptr i64 %v9652 to ptr
  %ld9654 = load i32, ptr %p9653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9654, ptr %slot1567, align 8
  %v9655 = load i32, ptr %slot1567, align 8
  %v9656 = load i64, ptr %slot25, align 8
  %p9657 = inttoptr i64 %v9656 to ptr
  store i32 %v9655, ptr %p9657, align 4, !alias.scope !3, !noalias !4
  %v9658 = load i64, ptr %slot24, align 8
  %p9659 = inttoptr i64 %v9658 to ptr
  store i32 1, ptr %p9659, align 4, !alias.scope !3, !noalias !4
  %v9660 = load i64, ptr %slot78, align 8
  %p9661 = inttoptr i64 %v9660 to ptr
  %ld9662 = load i64, ptr %p9661, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9662, ptr %slot1568, align 8
  %v9663 = load i64, ptr %slot1568, align 8
  %v9664 = load i64, ptr %slot99, align 8
  %p9665 = inttoptr i64 %v9664 to ptr
  store i64 %v9663, ptr %p9665, align 8, !alias.scope !3, !noalias !4
  %v9666 = load i64, ptr %slot100, align 8
  %p9667 = inttoptr i64 %v9666 to ptr
  store i64 0, ptr %p9667, align 8, !alias.scope !3, !noalias !4
  %v9668 = load i64, ptr %slot100, align 8
  %p9669 = inttoptr i64 %v9668 to ptr
  %ld9670 = load i64, ptr %p9669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9670, ptr %slot1569, align 8
  %v9671 = load i64, ptr %slot1569, align 8
  %cmp9672 = icmp sge i64 %v9671, 0
  %cv9673 = zext i1 %cmp9672 to i64
  store i64 %cv9673, ptr %slot1570, align 8
  %v9674 = load i64, ptr %slot1570, align 8
  %cond9675 = icmp ne i64 %v9674, 0
  br i1 %cond9675, label %bb_success1951, label %bb_failed1951
bb_failed1951:
  %v9676 = load i64, ptr %slot1, align 8
  %p9677 = inttoptr i64 %v9676 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p9677) nomerge, !dbg !166
  unreachable
bb_success1951:
  %v9678 = load i64, ptr %slot110, align 8
  %p9679 = inttoptr i64 %v9678 to ptr
  %p9680 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v9681 = load i64, ptr %slot1569, align 8
  %call9682 = call ptr @myl_native_list_new(ptr %p9679, ptr %p9680, i64 %v9681) nomerge, !dbg !166
  %calladdr9683 = ptrtoint ptr %call9682 to i64
  store i64 %calladdr9683, ptr %slot1571, align 8
  %v9684 = load i64, ptr %slot1571, align 8
  %cond9685 = icmp ne i64 %v9684, 0
  br i1 %cond9685, label %bb_success1953, label %bb_failed1953
bb_failed1953:
  %v9686 = load i64, ptr %slot1, align 8
  %p9687 = inttoptr i64 %v9686 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9687) nomerge, !dbg !166
  unreachable
bb_success1953:
  %v9688 = load i64, ptr %slot1571, align 8
  %v9689 = load i64, ptr %slot100, align 8
  %p9690 = inttoptr i64 %v9689 to ptr
  store i64 %v9688, ptr %p9690, align 8, !alias.scope !3, !noalias !4
  %v9691 = load i64, ptr %slot100, align 8
  %p9692 = inttoptr i64 %v9691 to ptr
  %ld9693 = load i64, ptr %p9692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9693, ptr %slot1572, align 8
  %v9694 = load i64, ptr %slot1572, align 8
  %v9695 = load i64, ptr %slot64, align 8
  %p9696 = inttoptr i64 %v9695 to ptr
  store i64 %v9694, ptr %p9696, align 8, !alias.scope !3, !noalias !4
  %v9697 = load i64, ptr %slot64, align 8
  store i64 %v9697, ptr %slot1573, align 8
  %v9698 = load i64, ptr %slot65, align 8
  store i64 %v9698, ptr %slot1574, align 8
  %v9699 = load i64, ptr %slot1573, align 8
  %v9700 = load i64, ptr %slot1574, align 8
  %p9701 = inttoptr i64 %v9699 to ptr
  %p9702 = inttoptr i64 %v9700 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9702, ptr %p9701, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9703 = load i64, ptr %slot47, align 8
  %p9704 = inttoptr i64 %v9703 to ptr
  store i32 2, ptr %p9704, align 4, !alias.scope !3, !noalias !4
  %v9705 = load i64, ptr %slot46, align 8
  %p9706 = inttoptr i64 %v9705 to ptr
  store i32 1, ptr %p9706, align 4, !alias.scope !3, !noalias !4
  %v9707 = load i64, ptr %slot56, align 8
  store i64 %v9707, ptr %slot1575, align 8
  %v9708 = load i64, ptr %slot65, align 8
  store i64 %v9708, ptr %slot1576, align 8
  %v9709 = load i64, ptr %slot1576, align 8
  %v9710 = load i64, ptr %slot1575, align 8
  %p9711 = inttoptr i64 %v9709 to ptr
  %p9712 = inttoptr i64 %v9710 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9712, ptr %p9711, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9713 = load i64, ptr %slot45, align 8
  %p9714 = inttoptr i64 %v9713 to ptr
  store i32 2, ptr %p9714, align 4, !alias.scope !3, !noalias !4
  %v9715 = load i64, ptr %slot47, align 8
  %p9716 = inttoptr i64 %v9715 to ptr
  %ld9717 = load i32, ptr %p9716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9717, ptr %slot1577, align 8
  %v9718 = load i32, ptr %slot1577, align 8
  %v9719 = load i64, ptr %slot45, align 8
  %p9720 = inttoptr i64 %v9719 to ptr
  store i32 %v9718, ptr %p9720, align 4, !alias.scope !3, !noalias !4
  %v9721 = load i64, ptr %slot46, align 8
  %p9722 = inttoptr i64 %v9721 to ptr
  store i32 0, ptr %p9722, align 4, !alias.scope !3, !noalias !4
  %v9723 = load i64, ptr %slot44, align 8
  %p9724 = inttoptr i64 %v9723 to ptr
  store i32 1, ptr %p9724, align 4, !alias.scope !3, !noalias !4
  %v9725 = load i64, ptr %slot1575, align 8
  %p9726 = inttoptr i64 %v9725 to ptr
  %ld9727 = load i64, ptr %p9726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9727, ptr %slot1578, align 8
  %v9728 = load i64, ptr %slot1578, align 8
  %v9729 = load i64, ptr %slot100, align 8
  %p9730 = inttoptr i64 %v9729 to ptr
  store i64 %v9728, ptr %p9730, align 8, !alias.scope !3, !noalias !4
  %v9731 = load i64, ptr %slot100, align 8
  %p9732 = inttoptr i64 %v9731 to ptr
  %ld9733 = load i64, ptr %p9732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9733, ptr %slot1579, align 8
  %v9734 = load i64, ptr %slot1579, align 8
  %v9735 = load i64, ptr %slot64, align 8
  %p9736 = inttoptr i64 %v9735 to ptr
  store i64 %v9734, ptr %p9736, align 8, !alias.scope !3, !noalias !4
  %v9737 = load i64, ptr %slot64, align 8
  store i64 %v9737, ptr %slot1580, align 8
  %v9738 = load i64, ptr %slot44, align 8
  %p9739 = inttoptr i64 %v9738 to ptr
  %ld9740 = load i32, ptr %p9739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9740, ptr %slot1581, align 8
  %v9741 = load i64, ptr %slot45, align 8
  %p9742 = inttoptr i64 %v9741 to ptr
  %ld9743 = load i32, ptr %p9742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9743, ptr %slot1582, align 8
  %v9744 = load i32, ptr %slot1582, align 8
  %op9745 = and i32 %v9744, 24
  store i32 %op9745, ptr %slot1582, align 8
  %v9746 = load i32, ptr %slot1582, align 8
  %cmp9747 = icmp eq i32 %v9746, 0
  %cv9748 = zext i1 %cmp9747 to i32
  store i32 %cv9748, ptr %slot1583, align 8
  %v9749 = load i32, ptr %slot1581, align 8
  %v9750 = load i32, ptr %slot1583, align 8
  %op9751 = and i32 %v9749, %v9750
  store i32 %op9751, ptr %slot1584, align 8
  %v9752 = load i32, ptr %slot1584, align 8
  %cv9753 = zext i32 %v9752 to i64
  %cond9754 = icmp ne i64 %cv9753, 0
  br i1 %cond9754, label %bb_rcprivateown1976, label %bb_rcprivateloan1976
bb_rcprivateown1976:
  %v9755 = load i64, ptr %slot65, align 8
  store i64 %v9755, ptr %slot1585, align 8
  %v9756 = load i64, ptr %slot111, align 8
  store i64 %v9756, ptr %slot1586, align 8
  %v9757 = load i64, ptr %slot1580, align 8
  %v9758 = load i64, ptr %slot1585, align 8
  %op9759 = sub i64 %v9757, %v9758
  store i64 %op9759, ptr %slot1587, align 8
  %v9760 = load i64, ptr %slot1585, align 8
  %v9761 = load i64, ptr %slot1580, align 8
  %op9762 = sub i64 %v9760, %v9761
  store i64 %op9762, ptr %slot1588, align 8
  %v9763 = load i64, ptr %slot1587, align 8
  %cmp9764 = icmp ult i64 %v9763, 8
  %cv9765 = zext i1 %cmp9764 to i32
  store i32 %cv9765, ptr %slot1589, align 8
  %v9766 = load i64, ptr %slot1588, align 8
  %cmp9767 = icmp ult i64 %v9766, 8
  %cv9768 = zext i1 %cmp9767 to i32
  store i32 %cv9768, ptr %slot1590, align 8
  %v9769 = load i32, ptr %slot1589, align 8
  %v9770 = load i32, ptr %slot1590, align 8
  %op9771 = or i32 %v9769, %v9770
  store i32 %op9771, ptr %slot1591, align 8
  %v9772 = load i32, ptr %slot1591, align 8
  %cv9773 = zext i32 %v9772 to i64
  %cond9774 = icmp ne i64 %cv9773, 0
  br i1 %cond9774, label %bb_rcmoveslow1979, label %bb_rcmovecheck1979
bb_rcmovecheck1979:
  %v9775 = load i64, ptr %slot1580, align 8
  %p9777 = inttoptr i64 %v9775 to ptr
  %gep9778 = getelementptr i8, ptr %p9777, i64 0
  %op9776 = ptrtoint ptr %gep9778 to i64
  store i64 %op9776, ptr %slot1592, align 8
  %v9779 = load i64, ptr %slot1592, align 8
  %p9780 = inttoptr i64 %v9779 to ptr
  %ld9781 = load i64, ptr %p9780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9781, ptr %slot1593, align 8
  %v9782 = load i64, ptr %slot1593, align 8
  %cmp9783 = icmp ne i64 %v9782, 0
  %cv9784 = zext i1 %cmp9783 to i32
  store i32 %cv9784, ptr %slot1594, align 8
  %v9785 = load i32, ptr %slot1594, align 8
  %cv9786 = zext i32 %v9785 to i64
  %cond9787 = icmp ne i64 %cv9786, 0
  br i1 %cond9787, label %bb_rcmoveheader1987, label %bb_rcmovenext1987
bb_rcmoveheader1987:
  %v9788 = load i64, ptr %slot1593, align 8
  %op9789 = sub i64 %v9788, 16
  store i64 %op9789, ptr %slot1595, align 8
  %v9790 = load i64, ptr %slot1593, align 8
  %p9791 = inttoptr i64 %v9790 to ptr
  %rgep9792 = getelementptr i8, ptr %p9791, i64 -16
  %ld9793 = load i64, ptr %rgep9792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9793, ptr %slot1596, align 8
  %v9794 = load i64, ptr %slot1596, align 8
  %op9795 = and i64 %v9794, 5764607523034234881
  store i64 %op9795, ptr %slot1597, align 8
  %v9796 = load i64, ptr %slot1597, align 8
  %cmp9797 = icmp ne i64 %v9796, 0
  %cv9798 = zext i1 %cmp9797 to i32
  store i32 %cv9798, ptr %slot1598, align 8
  %v9799 = load i32, ptr %slot1598, align 8
  %cv9800 = zext i32 %v9799 to i64
  %cond9801 = icmp ne i64 %cv9800, 0
  br i1 %cond9801, label %bb_rcmoveslow1979, label %bb_rcmovenext1987
bb_rcmovenext1987:
  %v9802 = load i64, ptr %slot1580, align 8
  %v9803 = load i64, ptr %slot1585, align 8
  %p9804 = inttoptr i64 %v9802 to ptr
  %p9805 = inttoptr i64 %v9803 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9805, ptr %p9804, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9806 = load i64, ptr %slot1580, align 8
  %p9807 = inttoptr i64 %v9806 to ptr
  store i64 0, ptr %p9807, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1979
bb_rcmoveslow1979:
  %v9808 = load i64, ptr %slot110, align 8
  %v9809 = load i64, ptr %slot1585, align 8
  %v9810 = load i64, ptr %slot1580, align 8
  %v9811 = load i64, ptr %slot1586, align 8
  %cv9812 = trunc i64 %v9811 to i32
  %call9813 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v9808, i64 %v9809, i64 %v9810, i32 %cv9812) nomerge, !dbg !168
  store i32 %call9813, ptr %slot1599, align 8
  %v9814 = load i32, ptr %slot1599, align 8
  %cv9815 = zext i32 %v9814 to i64
  %cond9816 = icmp ne i64 %cv9815, 0
  br i1 %cond9816, label %bb_rcsuccess1994, label %bb_rcfailure1994
bb_rcfailure1994:
  %v9817 = load i64, ptr %slot110, align 8
  %p9818 = inttoptr i64 %v9817 to ptr
  %call9819 = call i32 @myl_rc_take_failure(ptr %p9818) nomerge, !dbg !168
  store i32 %call9819, ptr %slot1600, align 8
  %v9820 = load i64, ptr %slot1, align 8
  %p9821 = inttoptr i64 %v9820 to ptr
  %v9822 = load i32, ptr %slot1600, align 8
  %call9823 = call i32 @myl_qbe_rc_status(ptr %p9821, i32 %v9822) nomerge, !dbg !168
  store i32 %call9823, ptr %slot1601, align 8
  br label %bb_failure
bb_rcsuccess1994:
  br label %bb_rcmoved1979
bb_rcmoved1979:
  %v9824 = load i64, ptr %slot44, align 8
  %p9825 = inttoptr i64 %v9824 to ptr
  store i32 0, ptr %p9825, align 4, !alias.scope !3, !noalias !4
  %v9826 = load i64, ptr %slot47, align 8
  %p9827 = inttoptr i64 %v9826 to ptr
  store i32 2, ptr %p9827, align 4, !alias.scope !3, !noalias !4
  %v9828 = load i64, ptr %slot46, align 8
  %p9829 = inttoptr i64 %v9828 to ptr
  store i32 1, ptr %p9829, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1976
bb_rcprivateloan1976:
  %v9830 = load i64, ptr %slot44, align 8
  %p9831 = inttoptr i64 %v9830 to ptr
  %ld9832 = load i32, ptr %p9831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9832, ptr %slot1602, align 8
  %v9833 = load i64, ptr %slot45, align 8
  %p9834 = inttoptr i64 %v9833 to ptr
  %ld9835 = load i32, ptr %p9834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9835, ptr %slot1603, align 8
  %v9836 = load i32, ptr %slot1603, align 8
  %cmp9837 = icmp eq i32 %v9836, 16
  %cv9838 = zext i1 %cmp9837 to i32
  store i32 %cv9838, ptr %slot1604, align 8
  %v9839 = load i32, ptr %slot1604, align 8
  %v9840 = load i32, ptr %slot1602, align 8
  %op9841 = and i32 %v9839, %v9840
  store i32 %op9841, ptr %slot1604, align 8
  %v9842 = load i32, ptr %slot1604, align 8
  %cv9843 = zext i32 %v9842 to i64
  %cond9844 = icmp ne i64 %cv9843, 0
  br i1 %cond9844, label %bb_rcprivatemove1976, label %bb_rcprivatenew1976
bb_rcprivatemove1976:
  %v9845 = load i64, ptr %slot65, align 8
  store i64 %v9845, ptr %slot1605, align 8
  %v9846 = load i64, ptr %slot1580, align 8
  %v9847 = load i64, ptr %slot1605, align 8
  %p9848 = inttoptr i64 %v9846 to ptr
  %p9849 = inttoptr i64 %v9847 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9849, ptr %p9848, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9850 = load i64, ptr %slot1580, align 8
  %p9851 = inttoptr i64 %v9850 to ptr
  store i64 0, ptr %p9851, align 8, !alias.scope !3, !noalias !4
  %v9852 = load i64, ptr %slot47, align 8
  %p9853 = inttoptr i64 %v9852 to ptr
  store i32 2, ptr %p9853, align 4, !alias.scope !3, !noalias !4
  %v9854 = load i64, ptr %slot47, align 8
  %p9855 = inttoptr i64 %v9854 to ptr
  store i32 16, ptr %p9855, align 4, !alias.scope !3, !noalias !4
  %v9856 = load i64, ptr %slot46, align 8
  %p9857 = inttoptr i64 %v9856 to ptr
  store i32 1, ptr %p9857, align 4, !alias.scope !3, !noalias !4
  %v9858 = load i64, ptr %slot44, align 8
  %p9859 = inttoptr i64 %v9858 to ptr
  store i32 0, ptr %p9859, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1976
bb_rcprivatenew1976:
  %v9860 = load i64, ptr %slot65, align 8
  store i64 %v9860, ptr %slot1606, align 8
  %v9861 = load i64, ptr %slot1580, align 8
  %p9862 = inttoptr i64 %v9861 to ptr
  %ld9863 = load i64, ptr %p9862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9863, ptr %slot1607, align 8
  %v9864 = load i64, ptr %slot1607, align 8
  %cmp9865 = icmp ne i64 %v9864, 0
  %cv9866 = zext i1 %cmp9865 to i32
  store i32 %cv9866, ptr %slot1608, align 8
  %v9867 = load i32, ptr %slot1608, align 8
  %cv9868 = zext i32 %v9867 to i64
  %cond9869 = icmp ne i64 %cv9868, 0
  br i1 %cond9869, label %bb_rcgnn2012, label %bb_rcgstore2012
bb_rcgnn2012:
  %v9870 = load i64, ptr %slot1607, align 8
  %op9871 = sub i64 %v9870, 16
  store i64 %op9871, ptr %slot1609, align 8
  %v9872 = load i64, ptr %slot1607, align 8
  %p9873 = inttoptr i64 %v9872 to ptr
  %rgep9874 = getelementptr i8, ptr %p9873, i64 -16
  %ld9875 = load i64, ptr %rgep9874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9875, ptr %slot1610, align 8
  %v9876 = load i64, ptr %slot1610, align 8
  %op9877 = and i64 %v9876, 4611686018427387906
  store i64 %op9877, ptr %slot1611, align 8
  %v9878 = load i64, ptr %slot1611, align 8
  %cmp9879 = icmp ne i64 %v9878, 0
  %cv9880 = zext i1 %cmp9879 to i32
  store i32 %cv9880, ptr %slot1612, align 8
  %v9881 = load i32, ptr %slot1612, align 8
  %cv9882 = zext i32 %v9881 to i64
  %cond9883 = icmp ne i64 %cv9882, 0
  br i1 %cond9883, label %bb_rcgstore2012, label %bb_rcginc2012
bb_rcginc2012:
  %v9884 = load i64, ptr %slot1607, align 8
  %op9885 = sub i64 %v9884, 24
  store i64 %op9885, ptr %slot1613, align 8
  %v9886 = load i64, ptr %slot1607, align 8
  %p9887 = inttoptr i64 %v9886 to ptr
  %rgep9888 = getelementptr i8, ptr %p9887, i64 -24
  %ld9889 = load i64, ptr %rgep9888, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9889, ptr %slot1614, align 8
  %v9890 = load i64, ptr %slot1614, align 8
  %op9891 = add i64 %v9890, 1
  store i64 %op9891, ptr %slot1615, align 8
  %v9892 = load i64, ptr %slot1615, align 8
  %cmp9893 = icmp eq i64 %v9892, 0
  %cv9894 = zext i1 %cmp9893 to i32
  store i32 %cv9894, ptr %slot1616, align 8
  %v9895 = load i32, ptr %slot1616, align 8
  %cv9896 = zext i32 %v9895 to i64
  %cond9897 = icmp ne i64 %cv9896, 0
  br i1 %cond9897, label %bb_rcglimit2012, label %bb_rcgcapacity2012
bb_rcglimit2012:
  %v9898 = load i64, ptr %slot1, align 8
  %p9899 = inttoptr i64 %v9898 to ptr
  %call9900 = call i32 @myl_qbe_rc_status(ptr %p9899, i32 2) nomerge, !dbg !168
  store i32 %call9900, ptr %slot1617, align 8
  br label %bb_failure
bb_rcgcapacity2012:
  %v9901 = load i64, ptr %slot1615, align 8
  %v9902 = load i64, ptr %slot1607, align 8
  %p9903 = inttoptr i64 %v9902 to ptr
  %rgep9904 = getelementptr i8, ptr %p9903, i64 -24
  store i64 %v9901, ptr %rgep9904, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore2012
bb_rcgstore2012:
  %v9905 = load i64, ptr %slot1607, align 8
  %v9906 = load i64, ptr %slot1606, align 8
  %p9907 = inttoptr i64 %v9906 to ptr
  store i64 %v9905, ptr %p9907, align 8, !alias.scope !3, !noalias !4
  %v9908 = load i64, ptr %slot47, align 8
  %p9909 = inttoptr i64 %v9908 to ptr
  store i32 2, ptr %p9909, align 4, !alias.scope !3, !noalias !4
  %v9910 = load i64, ptr %slot47, align 8
  %p9911 = inttoptr i64 %v9910 to ptr
  store i32 16, ptr %p9911, align 4, !alias.scope !3, !noalias !4
  %v9912 = load i64, ptr %slot46, align 8
  %p9913 = inttoptr i64 %v9912 to ptr
  store i32 1, ptr %p9913, align 4, !alias.scope !3, !noalias !4
  %v9914 = load i64, ptr %slot44, align 8
  %p9915 = inttoptr i64 %v9914 to ptr
  %ld9916 = load i32, ptr %p9915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9916, ptr %slot1618, align 8
  %v9917 = load i32, ptr %slot1618, align 8
  %cv9918 = zext i32 %v9917 to i64
  %cond9919 = icmp ne i64 %cv9918, 0
  br i1 %cond9919, label %bb_rcslotdrop2028, label %bb_rcslotdone2028
bb_rcslotdrop2028:
  %v9920 = load i64, ptr %slot44, align 8
  %p9921 = inttoptr i64 %v9920 to ptr
  store i32 0, ptr %p9921, align 4, !alias.scope !3, !noalias !4
  %v9922 = load i64, ptr %slot56, align 8
  store i64 %v9922, ptr %slot1619, align 8
  %v9923 = load i64, ptr %slot45, align 8
  %p9924 = inttoptr i64 %v9923 to ptr
  %ld9925 = load i32, ptr %p9924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9925, ptr %slot1620, align 8
  %v9926 = load i32, ptr %slot1620, align 8
  %op9927 = and i32 %v9926, 28
  store i32 %op9927, ptr %slot1621, align 8
  %v9928 = load i32, ptr %slot1621, align 8
  %cv9929 = zext i32 %v9928 to i64
  %cond9930 = icmp ne i64 %cv9929, 0
  br i1 %cond9930, label %bb_rcslotrole2028, label %bb_rcslotowner2028
bb_rcslotrole2028:
  %v9931 = load i64, ptr %slot110, align 8
  store i64 %v9931, ptr %slot1622, align 8
  %v9932 = load i64, ptr %slot1619, align 8
  %p9933 = inttoptr i64 %v9932 to ptr
  %ld9934 = load i64, ptr %p9933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9934, ptr %slot1623, align 8
  %v9935 = load i64, ptr %slot1623, align 8
  %cmp9936 = icmp ne i64 %v9935, 0
  %cv9937 = zext i1 %cmp9936 to i32
  store i32 %cv9937, ptr %slot1624, align 8
  %v9938 = load i32, ptr %slot1624, align 8
  %cv9939 = zext i32 %v9938 to i64
  %cond9940 = icmp ne i64 %cv9939, 0
  br i1 %cond9940, label %bb_rcgnn2044, label %bb_rcgdone2044
bb_rcgnn2044:
  %v9941 = load i64, ptr %slot1623, align 8
  %op9942 = sub i64 %v9941, 16
  store i64 %op9942, ptr %slot1625, align 8
  %v9943 = load i64, ptr %slot1623, align 8
  %p9944 = inttoptr i64 %v9943 to ptr
  %rgep9945 = getelementptr i8, ptr %p9944, i64 -16
  %ld9946 = load i64, ptr %rgep9945, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9946, ptr %slot1626, align 8
  %v9947 = load i64, ptr %slot1626, align 8
  %op9948 = and i64 %v9947, 4611686018427387906
  store i64 %op9948, ptr %slot1627, align 8
  %v9949 = load i64, ptr %slot1627, align 8
  %cmp9950 = icmp ne i64 %v9949, 0
  %cv9951 = zext i1 %cmp9950 to i32
  store i32 %cv9951, ptr %slot1628, align 8
  %v9952 = load i32, ptr %slot1628, align 8
  %cv9953 = zext i32 %v9952 to i64
  %cond9954 = icmp ne i64 %cv9953, 0
  br i1 %cond9954, label %bb_rcgclear2044, label %bb_rcgcounted2044
bb_rcgcounted2044:
  %v9955 = load i64, ptr %slot1623, align 8
  %op9956 = sub i64 %v9955, 24
  store i64 %op9956, ptr %slot1629, align 8
  %v9957 = load i64, ptr %slot1623, align 8
  %p9958 = inttoptr i64 %v9957 to ptr
  %rgep9959 = getelementptr i8, ptr %p9958, i64 -24
  %ld9960 = load i64, ptr %rgep9959, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9960, ptr %slot1630, align 8
  %v9961 = load i64, ptr %slot1630, align 8
  %op9962 = sub i64 %v9961, 1
  store i64 %op9962, ptr %slot1631, align 8
  %v9963 = load i64, ptr %slot1631, align 8
  %cmp9964 = icmp eq i64 %v9963, 0
  %cv9965 = zext i1 %cmp9964 to i32
  store i32 %cv9965, ptr %slot1632, align 8
  %v9966 = load i32, ptr %slot1632, align 8
  %cv9967 = zext i32 %v9966 to i64
  %cond9968 = icmp ne i64 %cv9967, 0
  br i1 %cond9968, label %bb_rcglast2044, label %bb_rcgdec2044
bb_rcglast2044:
  %v9969 = load i64, ptr %slot1623, align 8
  %op9970 = sub i64 %v9969, 32
  store i64 %op9970, ptr %slot1633, align 8
  %v9971 = load i64, ptr %slot1623, align 8
  %p9972 = inttoptr i64 %v9971 to ptr
  %rgep9973 = getelementptr i8, ptr %p9972, i64 -32
  %ld9974 = load i64, ptr %rgep9973, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9974, ptr %slot1634, align 8
  %v9975 = load i64, ptr %slot1634, align 8
  %cmp9976 = icmp ne i64 %v9975, 0
  %cv9977 = zext i1 %cmp9976 to i32
  store i32 %cv9977, ptr %slot1635, align 8
  %v9978 = load i32, ptr %slot1635, align 8
  %cv9979 = zext i32 %v9978 to i64
  %cond9980 = icmp ne i64 %cv9979, 0
  br i1 %cond9980, label %bb_rcgdec2044, label %bb_rcgslow2044
bb_rcgslow2044:
  %v9981 = load i64, ptr %slot1622, align 8
  %v9982 = load i64, ptr %slot1619, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v9981, i64 %v9982) nomerge, !dbg !168
  br label %bb_rcgdone2044
bb_rcgdec2044:
  %v9983 = load i64, ptr %slot1631, align 8
  %v9984 = load i64, ptr %slot1623, align 8
  %p9985 = inttoptr i64 %v9984 to ptr
  %rgep9986 = getelementptr i8, ptr %p9985, i64 -24
  store i64 %v9983, ptr %rgep9986, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2044
bb_rcgclear2044:
  %v9987 = load i64, ptr %slot1619, align 8
  %p9988 = inttoptr i64 %v9987 to ptr
  store i64 0, ptr %p9988, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2044
bb_rcgdone2044:
  br label %bb_rcslotdone2028
bb_rcslotowner2028:
  %v9989 = load i64, ptr %slot110, align 8
  store i64 %v9989, ptr %slot1636, align 8
  %v9990 = load i64, ptr %slot1619, align 8
  %p9991 = inttoptr i64 %v9990 to ptr
  %ld9992 = load i64, ptr %p9991, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9992, ptr %slot1637, align 8
  %v9993 = load i64, ptr %slot1637, align 8
  %cmp9994 = icmp ne i64 %v9993, 0
  %cv9995 = zext i1 %cmp9994 to i32
  store i32 %cv9995, ptr %slot1638, align 8
  %v9996 = load i32, ptr %slot1638, align 8
  %cv9997 = zext i32 %v9996 to i64
  %cond9998 = icmp ne i64 %cv9997, 0
  br i1 %cond9998, label %bb_rcgnn2059, label %bb_rcgdone2059
bb_rcgnn2059:
  %v9999 = load i64, ptr %slot1637, align 8
  %op10000 = sub i64 %v9999, 16
  store i64 %op10000, ptr %slot1639, align 8
  %v10001 = load i64, ptr %slot1637, align 8
  %p10002 = inttoptr i64 %v10001 to ptr
  %rgep10003 = getelementptr i8, ptr %p10002, i64 -16
  %ld10004 = load i64, ptr %rgep10003, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10004, ptr %slot1640, align 8
  %v10005 = load i64, ptr %slot1640, align 8
  %op10006 = and i64 %v10005, 4611686018427387906
  store i64 %op10006, ptr %slot1641, align 8
  %v10007 = load i64, ptr %slot1641, align 8
  %cmp10008 = icmp ne i64 %v10007, 0
  %cv10009 = zext i1 %cmp10008 to i32
  store i32 %cv10009, ptr %slot1642, align 8
  %v10010 = load i32, ptr %slot1642, align 8
  %cv10011 = zext i32 %v10010 to i64
  %cond10012 = icmp ne i64 %cv10011, 0
  br i1 %cond10012, label %bb_rcgclear2059, label %bb_rcgcounted2059
bb_rcgcounted2059:
  %v10013 = load i64, ptr %slot1637, align 8
  %op10014 = sub i64 %v10013, 32
  store i64 %op10014, ptr %slot1643, align 8
  %v10015 = load i64, ptr %slot1637, align 8
  %p10016 = inttoptr i64 %v10015 to ptr
  %rgep10017 = getelementptr i8, ptr %p10016, i64 -32
  %ld10018 = load i64, ptr %rgep10017, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10018, ptr %slot1644, align 8
  %v10019 = load i64, ptr %slot1644, align 8
  %op10020 = sub i64 %v10019, 1
  store i64 %op10020, ptr %slot1645, align 8
  %v10021 = load i64, ptr %slot1645, align 8
  %cmp10022 = icmp eq i64 %v10021, 0
  %cv10023 = zext i1 %cmp10022 to i32
  store i32 %cv10023, ptr %slot1646, align 8
  %v10024 = load i32, ptr %slot1646, align 8
  %cv10025 = zext i32 %v10024 to i64
  %cond10026 = icmp ne i64 %cv10025, 0
  br i1 %cond10026, label %bb_rcglast2059, label %bb_rcgdec2059
bb_rcglast2059:
  %v10027 = load i64, ptr %slot1637, align 8
  %op10028 = sub i64 %v10027, 24
  store i64 %op10028, ptr %slot1647, align 8
  %v10029 = load i64, ptr %slot1637, align 8
  %p10030 = inttoptr i64 %v10029 to ptr
  %rgep10031 = getelementptr i8, ptr %p10030, i64 -24
  %ld10032 = load i64, ptr %rgep10031, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10032, ptr %slot1648, align 8
  %v10033 = load i64, ptr %slot1648, align 8
  %cmp10034 = icmp ne i64 %v10033, 0
  %cv10035 = zext i1 %cmp10034 to i32
  store i32 %cv10035, ptr %slot1649, align 8
  %v10036 = load i32, ptr %slot1649, align 8
  %cv10037 = zext i32 %v10036 to i64
  %cond10038 = icmp ne i64 %cv10037, 0
  br i1 %cond10038, label %bb_rcgdec2059, label %bb_rcgslow2059
bb_rcgslow2059:
  %v10039 = load i64, ptr %slot1636, align 8
  %v10040 = load i64, ptr %slot1619, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v10039, i64 %v10040) nomerge, !dbg !168
  br label %bb_rcgdone2059
bb_rcgdec2059:
  %v10041 = load i64, ptr %slot1645, align 8
  %v10042 = load i64, ptr %slot1637, align 8
  %p10043 = inttoptr i64 %v10042 to ptr
  %rgep10044 = getelementptr i8, ptr %p10043, i64 -32
  store i64 %v10041, ptr %rgep10044, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2059
bb_rcgclear2059:
  %v10045 = load i64, ptr %slot1619, align 8
  %p10046 = inttoptr i64 %v10045 to ptr
  store i64 0, ptr %p10046, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2059
bb_rcgdone2059:
  br label %bb_rcslotdone2028
bb_rcslotdone2028:
  br label %bb_rcprivateprepared1976
bb_rcprivateprepared1976:
  %v10047 = load i64, ptr %slot26, align 8
  %p10048 = inttoptr i64 %v10047 to ptr
  %ld10049 = load i32, ptr %p10048, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10049, ptr %slot1650, align 8
  %v10050 = load i32, ptr %slot1650, align 8
  %cv10051 = zext i32 %v10050 to i64
  %cond10052 = icmp ne i64 %cv10051, 0
  br i1 %cond10052, label %bb_rcslotdrop2066, label %bb_rcslotdone2066
bb_rcslotdrop2066:
  %v10053 = load i64, ptr %slot26, align 8
  %p10054 = inttoptr i64 %v10053 to ptr
  store i32 0, ptr %p10054, align 4, !alias.scope !3, !noalias !4
  %v10055 = load i64, ptr %slot79, align 8
  store i64 %v10055, ptr %slot1651, align 8
  %v10056 = load i64, ptr %slot27, align 8
  %p10057 = inttoptr i64 %v10056 to ptr
  %ld10058 = load i32, ptr %p10057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10058, ptr %slot1652, align 8
  %v10059 = load i32, ptr %slot1652, align 8
  %op10060 = and i32 %v10059, 28
  store i32 %op10060, ptr %slot1653, align 8
  %v10061 = load i32, ptr %slot1653, align 8
  %cv10062 = zext i32 %v10061 to i64
  %cond10063 = icmp ne i64 %cv10062, 0
  br i1 %cond10063, label %bb_rcslotrole2066, label %bb_rcslotowner2066
bb_rcslotrole2066:
  %v10064 = load i64, ptr %slot110, align 8
  store i64 %v10064, ptr %slot1654, align 8
  %v10065 = load i64, ptr %slot1651, align 8
  %p10066 = inttoptr i64 %v10065 to ptr
  %ld10067 = load i64, ptr %p10066, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10067, ptr %slot1655, align 8
  %v10068 = load i64, ptr %slot1655, align 8
  %cmp10069 = icmp ne i64 %v10068, 0
  %cv10070 = zext i1 %cmp10069 to i32
  store i32 %cv10070, ptr %slot1656, align 8
  %v10071 = load i32, ptr %slot1656, align 8
  %cv10072 = zext i32 %v10071 to i64
  %cond10073 = icmp ne i64 %cv10072, 0
  br i1 %cond10073, label %bb_rcgnn2082, label %bb_rcgdone2082
bb_rcgnn2082:
  %v10074 = load i64, ptr %slot1655, align 8
  %op10075 = sub i64 %v10074, 16
  store i64 %op10075, ptr %slot1657, align 8
  %v10076 = load i64, ptr %slot1655, align 8
  %p10077 = inttoptr i64 %v10076 to ptr
  %rgep10078 = getelementptr i8, ptr %p10077, i64 -16
  %ld10079 = load i64, ptr %rgep10078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10079, ptr %slot1658, align 8
  %v10080 = load i64, ptr %slot1658, align 8
  %op10081 = and i64 %v10080, 4611686018427387906
  store i64 %op10081, ptr %slot1659, align 8
  %v10082 = load i64, ptr %slot1659, align 8
  %cmp10083 = icmp ne i64 %v10082, 0
  %cv10084 = zext i1 %cmp10083 to i32
  store i32 %cv10084, ptr %slot1660, align 8
  %v10085 = load i32, ptr %slot1660, align 8
  %cv10086 = zext i32 %v10085 to i64
  %cond10087 = icmp ne i64 %cv10086, 0
  br i1 %cond10087, label %bb_rcgclear2082, label %bb_rcgcounted2082
bb_rcgcounted2082:
  %v10088 = load i64, ptr %slot1655, align 8
  %op10089 = sub i64 %v10088, 24
  store i64 %op10089, ptr %slot1661, align 8
  %v10090 = load i64, ptr %slot1655, align 8
  %p10091 = inttoptr i64 %v10090 to ptr
  %rgep10092 = getelementptr i8, ptr %p10091, i64 -24
  %ld10093 = load i64, ptr %rgep10092, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10093, ptr %slot1662, align 8
  %v10094 = load i64, ptr %slot1662, align 8
  %op10095 = sub i64 %v10094, 1
  store i64 %op10095, ptr %slot1663, align 8
  %v10096 = load i64, ptr %slot1663, align 8
  %cmp10097 = icmp eq i64 %v10096, 0
  %cv10098 = zext i1 %cmp10097 to i32
  store i32 %cv10098, ptr %slot1664, align 8
  %v10099 = load i32, ptr %slot1664, align 8
  %cv10100 = zext i32 %v10099 to i64
  %cond10101 = icmp ne i64 %cv10100, 0
  br i1 %cond10101, label %bb_rcglast2082, label %bb_rcgdec2082
bb_rcglast2082:
  %v10102 = load i64, ptr %slot1655, align 8
  %op10103 = sub i64 %v10102, 32
  store i64 %op10103, ptr %slot1665, align 8
  %v10104 = load i64, ptr %slot1655, align 8
  %p10105 = inttoptr i64 %v10104 to ptr
  %rgep10106 = getelementptr i8, ptr %p10105, i64 -32
  %ld10107 = load i64, ptr %rgep10106, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10107, ptr %slot1666, align 8
  %v10108 = load i64, ptr %slot1666, align 8
  %cmp10109 = icmp ne i64 %v10108, 0
  %cv10110 = zext i1 %cmp10109 to i32
  store i32 %cv10110, ptr %slot1667, align 8
  %v10111 = load i32, ptr %slot1667, align 8
  %cv10112 = zext i32 %v10111 to i64
  %cond10113 = icmp ne i64 %cv10112, 0
  br i1 %cond10113, label %bb_rcgdec2082, label %bb_rcgslow2082
bb_rcgslow2082:
  %v10114 = load i64, ptr %slot1654, align 8
  %v10115 = load i64, ptr %slot1651, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v10114, i64 %v10115) nomerge, !dbg !168
  br label %bb_rcgdone2082
bb_rcgdec2082:
  %v10116 = load i64, ptr %slot1663, align 8
  %v10117 = load i64, ptr %slot1655, align 8
  %p10118 = inttoptr i64 %v10117 to ptr
  %rgep10119 = getelementptr i8, ptr %p10118, i64 -24
  store i64 %v10116, ptr %rgep10119, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2082
bb_rcgclear2082:
  %v10120 = load i64, ptr %slot1651, align 8
  %p10121 = inttoptr i64 %v10120 to ptr
  store i64 0, ptr %p10121, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2082
bb_rcgdone2082:
  br label %bb_rcslotdone2066
bb_rcslotowner2066:
  %v10122 = load i64, ptr %slot110, align 8
  store i64 %v10122, ptr %slot1668, align 8
  %v10123 = load i64, ptr %slot1651, align 8
  %p10124 = inttoptr i64 %v10123 to ptr
  %ld10125 = load i64, ptr %p10124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10125, ptr %slot1669, align 8
  %v10126 = load i64, ptr %slot1669, align 8
  %cmp10127 = icmp ne i64 %v10126, 0
  %cv10128 = zext i1 %cmp10127 to i32
  store i32 %cv10128, ptr %slot1670, align 8
  %v10129 = load i32, ptr %slot1670, align 8
  %cv10130 = zext i32 %v10129 to i64
  %cond10131 = icmp ne i64 %cv10130, 0
  br i1 %cond10131, label %bb_rcgnn2097, label %bb_rcgdone2097
bb_rcgnn2097:
  %v10132 = load i64, ptr %slot1669, align 8
  %op10133 = sub i64 %v10132, 16
  store i64 %op10133, ptr %slot1671, align 8
  %v10134 = load i64, ptr %slot1669, align 8
  %p10135 = inttoptr i64 %v10134 to ptr
  %rgep10136 = getelementptr i8, ptr %p10135, i64 -16
  %ld10137 = load i64, ptr %rgep10136, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10137, ptr %slot1672, align 8
  %v10138 = load i64, ptr %slot1672, align 8
  %op10139 = and i64 %v10138, 4611686018427387906
  store i64 %op10139, ptr %slot1673, align 8
  %v10140 = load i64, ptr %slot1673, align 8
  %cmp10141 = icmp ne i64 %v10140, 0
  %cv10142 = zext i1 %cmp10141 to i32
  store i32 %cv10142, ptr %slot1674, align 8
  %v10143 = load i32, ptr %slot1674, align 8
  %cv10144 = zext i32 %v10143 to i64
  %cond10145 = icmp ne i64 %cv10144, 0
  br i1 %cond10145, label %bb_rcgclear2097, label %bb_rcgcounted2097
bb_rcgcounted2097:
  %v10146 = load i64, ptr %slot1669, align 8
  %op10147 = sub i64 %v10146, 32
  store i64 %op10147, ptr %slot1675, align 8
  %v10148 = load i64, ptr %slot1669, align 8
  %p10149 = inttoptr i64 %v10148 to ptr
  %rgep10150 = getelementptr i8, ptr %p10149, i64 -32
  %ld10151 = load i64, ptr %rgep10150, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10151, ptr %slot1676, align 8
  %v10152 = load i64, ptr %slot1676, align 8
  %op10153 = sub i64 %v10152, 1
  store i64 %op10153, ptr %slot1677, align 8
  %v10154 = load i64, ptr %slot1677, align 8
  %cmp10155 = icmp eq i64 %v10154, 0
  %cv10156 = zext i1 %cmp10155 to i32
  store i32 %cv10156, ptr %slot1678, align 8
  %v10157 = load i32, ptr %slot1678, align 8
  %cv10158 = zext i32 %v10157 to i64
  %cond10159 = icmp ne i64 %cv10158, 0
  br i1 %cond10159, label %bb_rcglast2097, label %bb_rcgdec2097
bb_rcglast2097:
  %v10160 = load i64, ptr %slot1669, align 8
  %op10161 = sub i64 %v10160, 24
  store i64 %op10161, ptr %slot1679, align 8
  %v10162 = load i64, ptr %slot1669, align 8
  %p10163 = inttoptr i64 %v10162 to ptr
  %rgep10164 = getelementptr i8, ptr %p10163, i64 -24
  %ld10165 = load i64, ptr %rgep10164, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10165, ptr %slot1680, align 8
  %v10166 = load i64, ptr %slot1680, align 8
  %cmp10167 = icmp ne i64 %v10166, 0
  %cv10168 = zext i1 %cmp10167 to i32
  store i32 %cv10168, ptr %slot1681, align 8
  %v10169 = load i32, ptr %slot1681, align 8
  %cv10170 = zext i32 %v10169 to i64
  %cond10171 = icmp ne i64 %cv10170, 0
  br i1 %cond10171, label %bb_rcgdec2097, label %bb_rcgslow2097
bb_rcgslow2097:
  %v10172 = load i64, ptr %slot1668, align 8
  %v10173 = load i64, ptr %slot1651, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v10172, i64 %v10173) nomerge, !dbg !168
  br label %bb_rcgdone2097
bb_rcgdec2097:
  %v10174 = load i64, ptr %slot1677, align 8
  %v10175 = load i64, ptr %slot1669, align 8
  %p10176 = inttoptr i64 %v10175 to ptr
  %rgep10177 = getelementptr i8, ptr %p10176, i64 -32
  store i64 %v10174, ptr %rgep10177, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2097
bb_rcgclear2097:
  %v10178 = load i64, ptr %slot1651, align 8
  %p10179 = inttoptr i64 %v10178 to ptr
  store i64 0, ptr %p10179, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2097
bb_rcgdone2097:
  br label %bb_rcslotdone2066
bb_rcslotdone2066:
  %v10180 = load i64, ptr %slot79, align 8
  store i64 %v10180, ptr %slot1682, align 8
  %v10181 = load i64, ptr %slot65, align 8
  store i64 %v10181, ptr %slot1683, align 8
  %v10182 = load i64, ptr %slot1683, align 8
  %v10183 = load i64, ptr %slot1682, align 8
  %p10184 = inttoptr i64 %v10182 to ptr
  %p10185 = inttoptr i64 %v10183 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10185, ptr %p10184, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10186 = load i64, ptr %slot46, align 8
  %p10187 = inttoptr i64 %v10186 to ptr
  store i32 0, ptr %p10187, align 4, !alias.scope !3, !noalias !4
  %v10188 = load i64, ptr %slot27, align 8
  %p10189 = inttoptr i64 %v10188 to ptr
  store i32 2, ptr %p10189, align 4, !alias.scope !3, !noalias !4
  %v10190 = load i64, ptr %slot47, align 8
  %p10191 = inttoptr i64 %v10190 to ptr
  %ld10192 = load i32, ptr %p10191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10192, ptr %slot1684, align 8
  %v10193 = load i32, ptr %slot1684, align 8
  %v10194 = load i64, ptr %slot27, align 8
  %p10195 = inttoptr i64 %v10194 to ptr
  store i32 %v10193, ptr %p10195, align 4, !alias.scope !3, !noalias !4
  %v10196 = load i64, ptr %slot26, align 8
  %p10197 = inttoptr i64 %v10196 to ptr
  store i32 1, ptr %p10197, align 4, !alias.scope !3, !noalias !4
  %v10198 = load i64, ptr %slot79, align 8
  %p10199 = inttoptr i64 %v10198 to ptr
  %ld10200 = load i64, ptr %p10199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10200, ptr %slot1685, align 8
  %v10201 = load i64, ptr %slot1685, align 8
  %v10202 = load i64, ptr %slot100, align 8
  %p10203 = inttoptr i64 %v10202 to ptr
  store i64 %v10201, ptr %p10203, align 8, !alias.scope !3, !noalias !4
  %v10204 = load i64, ptr %slot67, align 8
  %p10205 = inttoptr i64 %v10204 to ptr
  %ld10206 = load i64, ptr %p10205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10206, ptr %slot1686, align 8
  %v10207 = load i64, ptr %slot1686, align 8
  %v10208 = load i64, ptr %slot101, align 8
  %p10209 = inttoptr i64 %v10208 to ptr
  store i64 %v10207, ptr %p10209, align 8, !alias.scope !3, !noalias !4
  %v10210 = load i64, ptr %slot105, align 8
  store i64 %v10210, ptr %slot1687, align 8
  %v10211 = load i64, ptr %slot1687, align 8
  %p10212 = inttoptr i64 %v10211 to ptr
  call void @llvm.memset.p0.i64(ptr %p10212, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !170
  %v10213 = load i64, ptr %slot48, align 8
  %p10214 = inttoptr i64 %v10213 to ptr
  store i32 1, ptr %p10214, align 4, !alias.scope !3, !noalias !4
  %v10215 = load i64, ptr %slot111, align 8
  store i64 %v10215, ptr %slot1688, align 8
  %v10216 = load i64, ptr %slot80, align 8
  %p10217 = inttoptr i64 %v10216 to ptr
  %ld10218 = load i64, ptr %p10217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10218, ptr %slot1689, align 8
  %v10219 = load i64, ptr %slot1689, align 8
  %v10220 = load i64, ptr %slot57, align 8
  %p10221 = inttoptr i64 %v10220 to ptr
  store i64 %v10219, ptr %p10221, align 8, !alias.scope !3, !noalias !4
  %v10222 = load i64, ptr %slot57, align 8
  store i64 %v10222, ptr %slot1690, align 8
  %v10223 = load i64, ptr %slot1687, align 8
  %p10225 = inttoptr i64 %v10223 to ptr
  %gep10226 = getelementptr i8, ptr %p10225, i64 0
  %op10224 = ptrtoint ptr %gep10226 to i64
  store i64 %op10224, ptr %slot1691, align 8
  %v10227 = load i64, ptr %slot80, align 8
  %p10228 = inttoptr i64 %v10227 to ptr
  %ld10229 = load i64, ptr %p10228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10229, ptr %slot1692, align 8
  %v10230 = load i64, ptr %slot1692, align 8
  %v10231 = load i64, ptr %slot57, align 8
  %p10232 = inttoptr i64 %v10231 to ptr
  store i64 %v10230, ptr %p10232, align 8, !alias.scope !3, !noalias !4
  %v10233 = load i64, ptr %slot57, align 8
  store i64 %v10233, ptr %slot1693, align 8
  %v10234 = load i64, ptr %slot28, align 8
  %p10235 = inttoptr i64 %v10234 to ptr
  %ld10236 = load i32, ptr %p10235, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10236, ptr %slot1694, align 8
  %v10237 = load i64, ptr %slot29, align 8
  %p10238 = inttoptr i64 %v10237 to ptr
  %ld10239 = load i32, ptr %p10238, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10239, ptr %slot1695, align 8
  %v10240 = load i32, ptr %slot1695, align 8
  %op10241 = and i32 %v10240, 24
  store i32 %op10241, ptr %slot1695, align 8
  %v10242 = load i32, ptr %slot1695, align 8
  %cmp10243 = icmp eq i32 %v10242, 0
  %cv10244 = zext i1 %cmp10243 to i32
  store i32 %cv10244, ptr %slot1696, align 8
  %v10245 = load i32, ptr %slot1694, align 8
  %v10246 = load i32, ptr %slot1696, align 8
  %op10247 = and i32 %v10245, %v10246
  store i32 %op10247, ptr %slot1697, align 8
  %v10248 = load i32, ptr %slot1697, align 8
  %cv10249 = zext i32 %v10248 to i64
  %cond10250 = icmp ne i64 %cv10249, 0
  br i1 %cond10250, label %bb_rctake2119, label %bb_rccopy2119
bb_rctake2119:
  %v10251 = load i64, ptr %slot65, align 8
  store i64 %v10251, ptr %slot1698, align 8
  %v10252 = load i64, ptr %slot111, align 8
  store i64 %v10252, ptr %slot1699, align 8
  %v10253 = load i64, ptr %slot1693, align 8
  %v10254 = load i64, ptr %slot1698, align 8
  %op10255 = sub i64 %v10253, %v10254
  store i64 %op10255, ptr %slot1700, align 8
  %v10256 = load i64, ptr %slot1698, align 8
  %v10257 = load i64, ptr %slot1693, align 8
  %op10258 = sub i64 %v10256, %v10257
  store i64 %op10258, ptr %slot1701, align 8
  %v10259 = load i64, ptr %slot1700, align 8
  %cmp10260 = icmp ult i64 %v10259, 8
  %cv10261 = zext i1 %cmp10260 to i32
  store i32 %cv10261, ptr %slot1702, align 8
  %v10262 = load i64, ptr %slot1701, align 8
  %cmp10263 = icmp ult i64 %v10262, 8
  %cv10264 = zext i1 %cmp10263 to i32
  store i32 %cv10264, ptr %slot1703, align 8
  %v10265 = load i32, ptr %slot1702, align 8
  %v10266 = load i32, ptr %slot1703, align 8
  %op10267 = or i32 %v10265, %v10266
  store i32 %op10267, ptr %slot1704, align 8
  %v10268 = load i32, ptr %slot1704, align 8
  %cv10269 = zext i32 %v10268 to i64
  %cond10270 = icmp ne i64 %cv10269, 0
  br i1 %cond10270, label %bb_rcmoveslow2128, label %bb_rcmovecheck2128
bb_rcmovecheck2128:
  %v10271 = load i64, ptr %slot1693, align 8
  %p10273 = inttoptr i64 %v10271 to ptr
  %gep10274 = getelementptr i8, ptr %p10273, i64 0
  %op10272 = ptrtoint ptr %gep10274 to i64
  store i64 %op10272, ptr %slot1705, align 8
  %v10275 = load i64, ptr %slot1705, align 8
  %p10276 = inttoptr i64 %v10275 to ptr
  %ld10277 = load i64, ptr %p10276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10277, ptr %slot1706, align 8
  %v10278 = load i64, ptr %slot1706, align 8
  %cmp10279 = icmp ne i64 %v10278, 0
  %cv10280 = zext i1 %cmp10279 to i32
  store i32 %cv10280, ptr %slot1707, align 8
  %v10281 = load i32, ptr %slot1707, align 8
  %cv10282 = zext i32 %v10281 to i64
  %cond10283 = icmp ne i64 %cv10282, 0
  br i1 %cond10283, label %bb_rcmoveheader2136, label %bb_rcmovenext2136
bb_rcmoveheader2136:
  %v10284 = load i64, ptr %slot1706, align 8
  %op10285 = sub i64 %v10284, 16
  store i64 %op10285, ptr %slot1708, align 8
  %v10286 = load i64, ptr %slot1706, align 8
  %p10287 = inttoptr i64 %v10286 to ptr
  %rgep10288 = getelementptr i8, ptr %p10287, i64 -16
  %ld10289 = load i64, ptr %rgep10288, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10289, ptr %slot1709, align 8
  %v10290 = load i64, ptr %slot1709, align 8
  %op10291 = and i64 %v10290, 5764607523034234881
  store i64 %op10291, ptr %slot1710, align 8
  %v10292 = load i64, ptr %slot1710, align 8
  %cmp10293 = icmp ne i64 %v10292, 0
  %cv10294 = zext i1 %cmp10293 to i32
  store i32 %cv10294, ptr %slot1711, align 8
  %v10295 = load i32, ptr %slot1711, align 8
  %cv10296 = zext i32 %v10295 to i64
  %cond10297 = icmp ne i64 %cv10296, 0
  br i1 %cond10297, label %bb_rcmoveslow2128, label %bb_rcmovenext2136
bb_rcmovenext2136:
  %v10298 = load i64, ptr %slot1693, align 8
  %v10299 = load i64, ptr %slot1698, align 8
  %p10300 = inttoptr i64 %v10298 to ptr
  %p10301 = inttoptr i64 %v10299 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10301, ptr %p10300, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10302 = load i64, ptr %slot1693, align 8
  %p10303 = inttoptr i64 %v10302 to ptr
  store i64 0, ptr %p10303, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2128
bb_rcmoveslow2128:
  %v10304 = load i64, ptr %slot110, align 8
  %v10305 = load i64, ptr %slot1698, align 8
  %v10306 = load i64, ptr %slot1693, align 8
  %v10307 = load i64, ptr %slot1699, align 8
  %cv10308 = trunc i64 %v10307 to i32
  %call10309 = call i32 @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_take(i64 %v10304, i64 %v10305, i64 %v10306, i32 %cv10308) nomerge, !dbg !170
  store i32 %call10309, ptr %slot1712, align 8
  %v10310 = load i32, ptr %slot1712, align 8
  %cv10311 = zext i32 %v10310 to i64
  %cond10312 = icmp ne i64 %cv10311, 0
  br i1 %cond10312, label %bb_rcsuccess2143, label %bb_rcfailure2143
bb_rcfailure2143:
  %v10313 = load i64, ptr %slot110, align 8
  %p10314 = inttoptr i64 %v10313 to ptr
  %call10315 = call i32 @myl_rc_take_failure(ptr %p10314) nomerge, !dbg !170
  store i32 %call10315, ptr %slot1713, align 8
  %v10316 = load i64, ptr %slot1, align 8
  %p10317 = inttoptr i64 %v10316 to ptr
  %v10318 = load i32, ptr %slot1713, align 8
  %call10319 = call i32 @myl_qbe_rc_status(ptr %p10317, i32 %v10318) nomerge, !dbg !170
  store i32 %call10319, ptr %slot1714, align 8
  br label %bb_failure
bb_rcsuccess2143:
  br label %bb_rcmoved2128
bb_rcmoved2128:
  %v10320 = load i64, ptr %slot28, align 8
  %p10321 = inttoptr i64 %v10320 to ptr
  store i32 0, ptr %p10321, align 4, !alias.scope !3, !noalias !4
  %v10322 = load i64, ptr %slot47, align 8
  %p10323 = inttoptr i64 %v10322 to ptr
  store i32 2, ptr %p10323, align 4, !alias.scope !3, !noalias !4
  %v10324 = load i64, ptr %slot46, align 8
  %p10325 = inttoptr i64 %v10324 to ptr
  store i32 1, ptr %p10325, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2119
bb_rccopy2119:
  %v10326 = load i64, ptr %slot65, align 8
  store i64 %v10326, ptr %slot1715, align 8
  %v10327 = load i64, ptr %slot111, align 8
  store i64 %v10327, ptr %slot1716, align 8
  %v10328 = load i64, ptr %slot1693, align 8
  %p10329 = inttoptr i64 %v10328 to ptr
  %ld10330 = load i64, ptr %p10329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10330, ptr %slot1717, align 8
  %v10331 = load i64, ptr %slot1717, align 8
  %cmp10332 = icmp ne i64 %v10331, 0
  %cv10333 = zext i1 %cmp10332 to i32
  store i32 %cv10333, ptr %slot1718, align 8
  %v10334 = load i32, ptr %slot1718, align 8
  %cv10335 = zext i32 %v10334 to i64
  %cond10336 = icmp ne i64 %cv10335, 0
  br i1 %cond10336, label %bb_rcgnn2152, label %bb_rcgplain2152
bb_rcgnn2152:
  %v10337 = load i64, ptr %slot1717, align 8
  %op10338 = sub i64 %v10337, 16
  store i64 %op10338, ptr %slot1719, align 8
  %v10339 = load i64, ptr %slot1717, align 8
  %p10340 = inttoptr i64 %v10339 to ptr
  %rgep10341 = getelementptr i8, ptr %p10340, i64 -16
  %ld10342 = load i64, ptr %rgep10341, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10342, ptr %slot1720, align 8
  %v10343 = load i64, ptr %slot1720, align 8
  %op10344 = and i64 %v10343, 4611686018427387906
  store i64 %op10344, ptr %slot1721, align 8
  %v10345 = load i64, ptr %slot1721, align 8
  %cmp10346 = icmp ne i64 %v10345, 0
  %cv10347 = zext i1 %cmp10346 to i32
  store i32 %cv10347, ptr %slot1722, align 8
  %v10348 = load i32, ptr %slot1722, align 8
  %cv10349 = zext i32 %v10348 to i64
  %cond10350 = icmp ne i64 %cv10349, 0
  br i1 %cond10350, label %bb_rcgspecial2152, label %bb_rcginc2152
bb_rcginc2152:
  %v10351 = load i64, ptr %slot1717, align 8
  %op10352 = sub i64 %v10351, 32
  store i64 %op10352, ptr %slot1723, align 8
  %v10353 = load i64, ptr %slot1717, align 8
  %p10354 = inttoptr i64 %v10353 to ptr
  %rgep10355 = getelementptr i8, ptr %p10354, i64 -32
  %ld10356 = load i64, ptr %rgep10355, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10356, ptr %slot1724, align 8
  %v10357 = load i64, ptr %slot1724, align 8
  %op10358 = add i64 %v10357, 1
  store i64 %op10358, ptr %slot1725, align 8
  %v10359 = load i64, ptr %slot1725, align 8
  %cmp10360 = icmp eq i64 %v10359, 0
  %cv10361 = zext i1 %cmp10360 to i32
  store i32 %cv10361, ptr %slot1726, align 8
  %v10362 = load i32, ptr %slot1726, align 8
  %cv10363 = zext i32 %v10362 to i64
  %cond10364 = icmp ne i64 %cv10363, 0
  br i1 %cond10364, label %bb_rcglimit2152, label %bb_rcgcapacity2152
bb_rcglimit2152:
  %v10365 = load i64, ptr %slot1, align 8
  %p10366 = inttoptr i64 %v10365 to ptr
  %call10367 = call i32 @myl_qbe_rc_status(ptr %p10366, i32 2) nomerge, !dbg !170
  store i32 %call10367, ptr %slot1727, align 8
  br label %bb_failure
bb_rcgcapacity2152:
  %v10368 = load i64, ptr %slot1725, align 8
  %v10369 = load i64, ptr %slot1717, align 8
  %p10370 = inttoptr i64 %v10369 to ptr
  %rgep10371 = getelementptr i8, ptr %p10370, i64 -32
  store i64 %v10368, ptr %rgep10371, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2152
bb_rcgspecial2152:
  %v10372 = load i64, ptr %slot1720, align 8
  %op10373 = and i64 %v10372, 4611686018427387904
  store i64 %op10373, ptr %slot1728, align 8
  %v10374 = load i64, ptr %slot1728, align 8
  %cmp10375 = icmp ne i64 %v10374, 0
  %cv10376 = zext i1 %cmp10375 to i32
  store i32 %cv10376, ptr %slot1729, align 8
  %v10377 = load i32, ptr %slot1729, align 8
  %cv10378 = zext i32 %v10377 to i64
  %cond10379 = icmp ne i64 %cv10378, 0
  br i1 %cond10379, label %bb_rcgslow2152, label %bb_rcgplain2152
bb_rcgslow2152:
  %v10380 = load i64, ptr %slot110, align 8
  %v10381 = load i64, ptr %slot1715, align 8
  %v10382 = load i64, ptr %slot1693, align 8
  %v10383 = load i64, ptr %slot1716, align 8
  %cv10384 = trunc i64 %v10383 to i32
  %call10385 = call i32 @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_retain(i64 %v10380, i64 %v10381, i64 %v10382, i32 %cv10384) nomerge, !dbg !170
  store i32 %call10385, ptr %slot1730, align 8
  %v10386 = load i32, ptr %slot1730, align 8
  %cv10387 = zext i32 %v10386 to i64
  %cond10388 = icmp ne i64 %cv10387, 0
  br i1 %cond10388, label %bb_rcsuccess2166, label %bb_rcfailure2166
bb_rcfailure2166:
  %v10389 = load i64, ptr %slot110, align 8
  %p10390 = inttoptr i64 %v10389 to ptr
  %call10391 = call i32 @myl_rc_take_failure(ptr %p10390) nomerge, !dbg !170
  store i32 %call10391, ptr %slot1731, align 8
  %v10392 = load i64, ptr %slot1, align 8
  %p10393 = inttoptr i64 %v10392 to ptr
  %v10394 = load i32, ptr %slot1731, align 8
  %call10395 = call i32 @myl_qbe_rc_status(ptr %p10393, i32 %v10394) nomerge, !dbg !170
  store i32 %call10395, ptr %slot1732, align 8
  br label %bb_failure
bb_rcsuccess2166:
  br label %bb_rcgdone2152
bb_rcgplain2152:
  %v10396 = load i64, ptr %slot1717, align 8
  %v10397 = load i64, ptr %slot1715, align 8
  %p10398 = inttoptr i64 %v10397 to ptr
  store i64 %v10396, ptr %p10398, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2152
bb_rcgdone2152:
  %v10399 = load i64, ptr %slot47, align 8
  %p10400 = inttoptr i64 %v10399 to ptr
  store i32 2, ptr %p10400, align 4, !alias.scope !3, !noalias !4
  %v10401 = load i64, ptr %slot46, align 8
  %p10402 = inttoptr i64 %v10401 to ptr
  store i32 1, ptr %p10402, align 4, !alias.scope !3, !noalias !4
  %v10403 = load i64, ptr %slot28, align 8
  %p10404 = inttoptr i64 %v10403 to ptr
  %ld10405 = load i32, ptr %p10404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10405, ptr %slot1733, align 8
  %v10406 = load i32, ptr %slot1733, align 8
  %cv10407 = zext i32 %v10406 to i64
  %cond10408 = icmp ne i64 %cv10407, 0
  br i1 %cond10408, label %bb_rcslotdrop2173, label %bb_rcslotdone2173
bb_rcslotdrop2173:
  %v10409 = load i64, ptr %slot28, align 8
  %p10410 = inttoptr i64 %v10409 to ptr
  store i32 0, ptr %p10410, align 4, !alias.scope !3, !noalias !4
  %v10411 = load i64, ptr %slot49, align 8
  store i64 %v10411, ptr %slot1734, align 8
  %v10412 = load i64, ptr %slot29, align 8
  %p10413 = inttoptr i64 %v10412 to ptr
  %ld10414 = load i32, ptr %p10413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10414, ptr %slot1735, align 8
  %v10415 = load i32, ptr %slot1735, align 8
  %op10416 = and i32 %v10415, 28
  store i32 %op10416, ptr %slot1736, align 8
  %v10417 = load i32, ptr %slot1736, align 8
  %cv10418 = zext i32 %v10417 to i64
  %cond10419 = icmp ne i64 %cv10418, 0
  br i1 %cond10419, label %bb_rcslotrole2173, label %bb_rcslotowner2173
bb_rcslotrole2173:
  %v10420 = load i64, ptr %slot110, align 8
  store i64 %v10420, ptr %slot1737, align 8
  %v10421 = load i64, ptr %slot1734, align 8
  %p10422 = inttoptr i64 %v10421 to ptr
  %ld10423 = load i64, ptr %p10422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10423, ptr %slot1738, align 8
  %v10424 = load i64, ptr %slot1738, align 8
  %cmp10425 = icmp ne i64 %v10424, 0
  %cv10426 = zext i1 %cmp10425 to i32
  store i32 %cv10426, ptr %slot1739, align 8
  %v10427 = load i32, ptr %slot1739, align 8
  %cv10428 = zext i32 %v10427 to i64
  %cond10429 = icmp ne i64 %cv10428, 0
  br i1 %cond10429, label %bb_rcgnn2189, label %bb_rcgdone2189
bb_rcgnn2189:
  %v10430 = load i64, ptr %slot1738, align 8
  %op10431 = sub i64 %v10430, 16
  store i64 %op10431, ptr %slot1740, align 8
  %v10432 = load i64, ptr %slot1738, align 8
  %p10433 = inttoptr i64 %v10432 to ptr
  %rgep10434 = getelementptr i8, ptr %p10433, i64 -16
  %ld10435 = load i64, ptr %rgep10434, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10435, ptr %slot1741, align 8
  %v10436 = load i64, ptr %slot1741, align 8
  %op10437 = and i64 %v10436, 4611686018427387906
  store i64 %op10437, ptr %slot1742, align 8
  %v10438 = load i64, ptr %slot1742, align 8
  %cmp10439 = icmp ne i64 %v10438, 0
  %cv10440 = zext i1 %cmp10439 to i32
  store i32 %cv10440, ptr %slot1743, align 8
  %v10441 = load i32, ptr %slot1743, align 8
  %cv10442 = zext i32 %v10441 to i64
  %cond10443 = icmp ne i64 %cv10442, 0
  br i1 %cond10443, label %bb_rcgclear2189, label %bb_rcgcounted2189
bb_rcgcounted2189:
  %v10444 = load i64, ptr %slot1738, align 8
  %op10445 = sub i64 %v10444, 24
  store i64 %op10445, ptr %slot1744, align 8
  %v10446 = load i64, ptr %slot1738, align 8
  %p10447 = inttoptr i64 %v10446 to ptr
  %rgep10448 = getelementptr i8, ptr %p10447, i64 -24
  %ld10449 = load i64, ptr %rgep10448, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10449, ptr %slot1745, align 8
  %v10450 = load i64, ptr %slot1745, align 8
  %op10451 = sub i64 %v10450, 1
  store i64 %op10451, ptr %slot1746, align 8
  %v10452 = load i64, ptr %slot1746, align 8
  %cmp10453 = icmp eq i64 %v10452, 0
  %cv10454 = zext i1 %cmp10453 to i32
  store i32 %cv10454, ptr %slot1747, align 8
  %v10455 = load i32, ptr %slot1747, align 8
  %cv10456 = zext i32 %v10455 to i64
  %cond10457 = icmp ne i64 %cv10456, 0
  br i1 %cond10457, label %bb_rcglast2189, label %bb_rcgdec2189
bb_rcglast2189:
  %v10458 = load i64, ptr %slot1738, align 8
  %op10459 = sub i64 %v10458, 32
  store i64 %op10459, ptr %slot1748, align 8
  %v10460 = load i64, ptr %slot1738, align 8
  %p10461 = inttoptr i64 %v10460 to ptr
  %rgep10462 = getelementptr i8, ptr %p10461, i64 -32
  %ld10463 = load i64, ptr %rgep10462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10463, ptr %slot1749, align 8
  %v10464 = load i64, ptr %slot1749, align 8
  %cmp10465 = icmp ne i64 %v10464, 0
  %cv10466 = zext i1 %cmp10465 to i32
  store i32 %cv10466, ptr %slot1750, align 8
  %v10467 = load i32, ptr %slot1750, align 8
  %cv10468 = zext i32 %v10467 to i64
  %cond10469 = icmp ne i64 %cv10468, 0
  br i1 %cond10469, label %bb_rcgdec2189, label %bb_rcgslow2189
bb_rcgslow2189:
  %v10470 = load i64, ptr %slot1737, align 8
  %v10471 = load i64, ptr %slot1734, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v10470, i64 %v10471) nomerge, !dbg !170
  br label %bb_rcgdone2189
bb_rcgdec2189:
  %v10472 = load i64, ptr %slot1746, align 8
  %v10473 = load i64, ptr %slot1738, align 8
  %p10474 = inttoptr i64 %v10473 to ptr
  %rgep10475 = getelementptr i8, ptr %p10474, i64 -24
  store i64 %v10472, ptr %rgep10475, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2189
bb_rcgclear2189:
  %v10476 = load i64, ptr %slot1734, align 8
  %p10477 = inttoptr i64 %v10476 to ptr
  store i64 0, ptr %p10477, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2189
bb_rcgdone2189:
  br label %bb_rcslotdone2173
bb_rcslotowner2173:
  %v10478 = load i64, ptr %slot110, align 8
  store i64 %v10478, ptr %slot1751, align 8
  %v10479 = load i64, ptr %slot1734, align 8
  %p10480 = inttoptr i64 %v10479 to ptr
  %ld10481 = load i64, ptr %p10480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10481, ptr %slot1752, align 8
  %v10482 = load i64, ptr %slot1752, align 8
  %cmp10483 = icmp ne i64 %v10482, 0
  %cv10484 = zext i1 %cmp10483 to i32
  store i32 %cv10484, ptr %slot1753, align 8
  %v10485 = load i32, ptr %slot1753, align 8
  %cv10486 = zext i32 %v10485 to i64
  %cond10487 = icmp ne i64 %cv10486, 0
  br i1 %cond10487, label %bb_rcgnn2204, label %bb_rcgdone2204
bb_rcgnn2204:
  %v10488 = load i64, ptr %slot1752, align 8
  %op10489 = sub i64 %v10488, 16
  store i64 %op10489, ptr %slot1754, align 8
  %v10490 = load i64, ptr %slot1752, align 8
  %p10491 = inttoptr i64 %v10490 to ptr
  %rgep10492 = getelementptr i8, ptr %p10491, i64 -16
  %ld10493 = load i64, ptr %rgep10492, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10493, ptr %slot1755, align 8
  %v10494 = load i64, ptr %slot1755, align 8
  %op10495 = and i64 %v10494, 4611686018427387906
  store i64 %op10495, ptr %slot1756, align 8
  %v10496 = load i64, ptr %slot1756, align 8
  %cmp10497 = icmp ne i64 %v10496, 0
  %cv10498 = zext i1 %cmp10497 to i32
  store i32 %cv10498, ptr %slot1757, align 8
  %v10499 = load i32, ptr %slot1757, align 8
  %cv10500 = zext i32 %v10499 to i64
  %cond10501 = icmp ne i64 %cv10500, 0
  br i1 %cond10501, label %bb_rcgclear2204, label %bb_rcgcounted2204
bb_rcgcounted2204:
  %v10502 = load i64, ptr %slot1752, align 8
  %op10503 = sub i64 %v10502, 32
  store i64 %op10503, ptr %slot1758, align 8
  %v10504 = load i64, ptr %slot1752, align 8
  %p10505 = inttoptr i64 %v10504 to ptr
  %rgep10506 = getelementptr i8, ptr %p10505, i64 -32
  %ld10507 = load i64, ptr %rgep10506, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10507, ptr %slot1759, align 8
  %v10508 = load i64, ptr %slot1759, align 8
  %op10509 = sub i64 %v10508, 1
  store i64 %op10509, ptr %slot1760, align 8
  %v10510 = load i64, ptr %slot1760, align 8
  %cmp10511 = icmp eq i64 %v10510, 0
  %cv10512 = zext i1 %cmp10511 to i32
  store i32 %cv10512, ptr %slot1761, align 8
  %v10513 = load i32, ptr %slot1761, align 8
  %cv10514 = zext i32 %v10513 to i64
  %cond10515 = icmp ne i64 %cv10514, 0
  br i1 %cond10515, label %bb_rcglast2204, label %bb_rcgdec2204
bb_rcglast2204:
  %v10516 = load i64, ptr %slot1752, align 8
  %op10517 = sub i64 %v10516, 24
  store i64 %op10517, ptr %slot1762, align 8
  %v10518 = load i64, ptr %slot1752, align 8
  %p10519 = inttoptr i64 %v10518 to ptr
  %rgep10520 = getelementptr i8, ptr %p10519, i64 -24
  %ld10521 = load i64, ptr %rgep10520, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10521, ptr %slot1763, align 8
  %v10522 = load i64, ptr %slot1763, align 8
  %cmp10523 = icmp ne i64 %v10522, 0
  %cv10524 = zext i1 %cmp10523 to i32
  store i32 %cv10524, ptr %slot1764, align 8
  %v10525 = load i32, ptr %slot1764, align 8
  %cv10526 = zext i32 %v10525 to i64
  %cond10527 = icmp ne i64 %cv10526, 0
  br i1 %cond10527, label %bb_rcgdec2204, label %bb_rcgslow2204
bb_rcgslow2204:
  %v10528 = load i64, ptr %slot1751, align 8
  %v10529 = load i64, ptr %slot1734, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v10528, i64 %v10529) nomerge, !dbg !170
  br label %bb_rcgdone2204
bb_rcgdec2204:
  %v10530 = load i64, ptr %slot1760, align 8
  %v10531 = load i64, ptr %slot1752, align 8
  %p10532 = inttoptr i64 %v10531 to ptr
  %rgep10533 = getelementptr i8, ptr %p10532, i64 -32
  store i64 %v10530, ptr %rgep10533, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2204
bb_rcgclear2204:
  %v10534 = load i64, ptr %slot1734, align 8
  %p10535 = inttoptr i64 %v10534 to ptr
  store i64 0, ptr %p10535, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2204
bb_rcgdone2204:
  br label %bb_rcslotdone2173
bb_rcslotdone2173:
  br label %bb_rcprepared2119
bb_rcprepared2119:
  %v10536 = load i64, ptr %slot65, align 8
  store i64 %v10536, ptr %slot1765, align 8
  %v10537 = load i64, ptr %slot1765, align 8
  %v10538 = load i64, ptr %slot1691, align 8
  %p10539 = inttoptr i64 %v10537 to ptr
  %p10540 = inttoptr i64 %v10538 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10540, ptr %p10539, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10541 = load i64, ptr %slot46, align 8
  %p10542 = inttoptr i64 %v10541 to ptr
  store i32 0, ptr %p10542, align 4, !alias.scope !3, !noalias !4
  %v10543 = load i64, ptr %slot81, align 8
  %p10544 = inttoptr i64 %v10543 to ptr
  %ld10545 = load i64, ptr %p10544, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10545, ptr %slot1766, align 8
  %v10546 = load i64, ptr %slot1687, align 8
  %p10548 = inttoptr i64 %v10546 to ptr
  %gep10549 = getelementptr i8, ptr %p10548, i64 8
  %op10547 = ptrtoint ptr %gep10549 to i64
  store i64 %op10547, ptr %slot1767, align 8
  %v10550 = load i64, ptr %slot81, align 8
  %p10551 = inttoptr i64 %v10550 to ptr
  %ld10552 = load i64, ptr %p10551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10552, ptr %slot1768, align 8
  %v10553 = load i64, ptr %slot30, align 8
  %p10554 = inttoptr i64 %v10553 to ptr
  %ld10555 = load i32, ptr %p10554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10555, ptr %slot1769, align 8
  %v10556 = load i64, ptr %slot31, align 8
  %p10557 = inttoptr i64 %v10556 to ptr
  %ld10558 = load i32, ptr %p10557, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10558, ptr %slot1770, align 8
  %v10559 = load i32, ptr %slot1770, align 8
  %op10560 = and i32 %v10559, 24
  store i32 %op10560, ptr %slot1770, align 8
  %v10561 = load i32, ptr %slot1770, align 8
  %cmp10562 = icmp eq i32 %v10561, 0
  %cv10563 = zext i1 %cmp10562 to i32
  store i32 %cv10563, ptr %slot1771, align 8
  %v10564 = load i32, ptr %slot1769, align 8
  %v10565 = load i32, ptr %slot1771, align 8
  %op10566 = and i32 %v10564, %v10565
  store i32 %op10566, ptr %slot1772, align 8
  %v10567 = load i32, ptr %slot1772, align 8
  %cv10568 = zext i32 %v10567 to i64
  %cond10569 = icmp ne i64 %cv10568, 0
  br i1 %cond10569, label %bb_rctake2213, label %bb_rccopy2213
bb_rctake2213:
  %v10570 = load i64, ptr %slot65, align 8
  store i64 %v10570, ptr %slot1773, align 8
  %v10571 = load i64, ptr %slot111, align 8
  store i64 %v10571, ptr %slot1774, align 8
  %v10572 = load i64, ptr %slot1768, align 8
  %v10573 = load i64, ptr %slot1773, align 8
  %op10574 = sub i64 %v10572, %v10573
  store i64 %op10574, ptr %slot1775, align 8
  %v10575 = load i64, ptr %slot1773, align 8
  %v10576 = load i64, ptr %slot1768, align 8
  %op10577 = sub i64 %v10575, %v10576
  store i64 %op10577, ptr %slot1776, align 8
  %v10578 = load i64, ptr %slot1775, align 8
  %cmp10579 = icmp ult i64 %v10578, 16
  %cv10580 = zext i1 %cmp10579 to i32
  store i32 %cv10580, ptr %slot1777, align 8
  %v10581 = load i64, ptr %slot1776, align 8
  %cmp10582 = icmp ult i64 %v10581, 16
  %cv10583 = zext i1 %cmp10582 to i32
  store i32 %cv10583, ptr %slot1778, align 8
  %v10584 = load i32, ptr %slot1777, align 8
  %v10585 = load i32, ptr %slot1778, align 8
  %op10586 = or i32 %v10584, %v10585
  store i32 %op10586, ptr %slot1779, align 8
  %v10587 = load i32, ptr %slot1779, align 8
  %cv10588 = zext i32 %v10587 to i64
  %cond10589 = icmp ne i64 %cv10588, 0
  br i1 %cond10589, label %bb_rcmoveslow2222, label %bb_rcmovecheck2222
bb_rcmovecheck2222:
  %v10590 = load i64, ptr %slot1768, align 8
  %op10591 = add i64 %v10590, 0
  store i64 %op10591, ptr %slot1780, align 8
  %v10592 = load i64, ptr %slot1780, align 8
  %p10593 = inttoptr i64 %v10592 to ptr
  %ld10594 = load i64, ptr %p10593, align 8
  store i64 %ld10594, ptr %slot1781, align 8
  %v10595 = load i64, ptr %slot1781, align 8
  %cmp10596 = icmp ne i64 %v10595, 0
  %cv10597 = zext i1 %cmp10596 to i32
  store i32 %cv10597, ptr %slot1782, align 8
  %v10598 = load i32, ptr %slot1782, align 8
  %cv10599 = zext i32 %v10598 to i64
  %cond10600 = icmp ne i64 %cv10599, 0
  br i1 %cond10600, label %bb_rcmoveheader2230, label %bb_rcmovenext2230
bb_rcmoveheader2230:
  %v10601 = load i64, ptr %slot1781, align 8
  %op10602 = sub i64 %v10601, 16
  store i64 %op10602, ptr %slot1783, align 8
  %v10603 = load i64, ptr %slot1781, align 8
  %p10604 = inttoptr i64 %v10603 to ptr
  %rgep10605 = getelementptr i8, ptr %p10604, i64 -16
  %ld10606 = load i64, ptr %rgep10605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10606, ptr %slot1784, align 8
  %v10607 = load i64, ptr %slot1784, align 8
  %op10608 = and i64 %v10607, 5764607523034234881
  store i64 %op10608, ptr %slot1785, align 8
  %v10609 = load i64, ptr %slot1785, align 8
  %cmp10610 = icmp ne i64 %v10609, 0
  %cv10611 = zext i1 %cmp10610 to i32
  store i32 %cv10611, ptr %slot1786, align 8
  %v10612 = load i32, ptr %slot1786, align 8
  %cv10613 = zext i32 %v10612 to i64
  %cond10614 = icmp ne i64 %cv10613, 0
  br i1 %cond10614, label %bb_rcmoveslow2222, label %bb_rcmovenext2230
bb_rcmovenext2230:
  %v10615 = load i64, ptr %slot1768, align 8
  %op10616 = add i64 %v10615, 8
  store i64 %op10616, ptr %slot1787, align 8
  %v10617 = load i64, ptr %slot1787, align 8
  %p10618 = inttoptr i64 %v10617 to ptr
  %ld10619 = load i64, ptr %p10618, align 8
  store i64 %ld10619, ptr %slot1788, align 8
  %v10620 = load i64, ptr %slot1788, align 8
  %cmp10621 = icmp ne i64 %v10620, 0
  %cv10622 = zext i1 %cmp10621 to i32
  store i32 %cv10622, ptr %slot1789, align 8
  %v10623 = load i32, ptr %slot1789, align 8
  %cv10624 = zext i32 %v10623 to i64
  %cond10625 = icmp ne i64 %cv10624, 0
  br i1 %cond10625, label %bb_rcmoveheader2238, label %bb_rcmovenext2238
bb_rcmoveheader2238:
  %v10626 = load i64, ptr %slot1788, align 8
  %op10627 = sub i64 %v10626, 16
  store i64 %op10627, ptr %slot1790, align 8
  %v10628 = load i64, ptr %slot1788, align 8
  %p10629 = inttoptr i64 %v10628 to ptr
  %rgep10630 = getelementptr i8, ptr %p10629, i64 -16
  %ld10631 = load i64, ptr %rgep10630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10631, ptr %slot1791, align 8
  %v10632 = load i64, ptr %slot1791, align 8
  %op10633 = and i64 %v10632, 5764607523034234881
  store i64 %op10633, ptr %slot1792, align 8
  %v10634 = load i64, ptr %slot1792, align 8
  %cmp10635 = icmp ne i64 %v10634, 0
  %cv10636 = zext i1 %cmp10635 to i32
  store i32 %cv10636, ptr %slot1793, align 8
  %v10637 = load i32, ptr %slot1793, align 8
  %cv10638 = zext i32 %v10637 to i64
  %cond10639 = icmp ne i64 %cv10638, 0
  br i1 %cond10639, label %bb_rcmoveslow2222, label %bb_rcmovenext2238
bb_rcmovenext2238:
  %v10640 = load i64, ptr %slot1768, align 8
  %v10641 = load i64, ptr %slot1773, align 8
  %p10642 = inttoptr i64 %v10640 to ptr
  %p10643 = inttoptr i64 %v10641 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10643, ptr %p10642, i64 16, i1 false)
  %v10644 = load i64, ptr %slot1768, align 8
  %p10645 = inttoptr i64 %v10644 to ptr
  store i64 0, ptr %p10645, align 8
  %v10646 = load i64, ptr %slot1768, align 8
  %op10647 = add i64 %v10646, 8
  store i64 %op10647, ptr %slot1794, align 8
  %v10648 = load i64, ptr %slot1794, align 8
  %p10649 = inttoptr i64 %v10648 to ptr
  store i64 0, ptr %p10649, align 8
  br label %bb_rcmoved2222
bb_rcmoveslow2222:
  %v10650 = load i64, ptr %slot110, align 8
  %v10651 = load i64, ptr %slot1773, align 8
  %v10652 = load i64, ptr %slot1768, align 8
  %v10653 = load i64, ptr %slot1774, align 8
  %cv10654 = trunc i64 %v10653 to i32
  %call10655 = call i32 @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_take(i64 %v10650, i64 %v10651, i64 %v10652, i32 %cv10654) nomerge, !dbg !170
  store i32 %call10655, ptr %slot1795, align 8
  %v10656 = load i32, ptr %slot1795, align 8
  %cv10657 = zext i32 %v10656 to i64
  %cond10658 = icmp ne i64 %cv10657, 0
  br i1 %cond10658, label %bb_rcsuccess2246, label %bb_rcfailure2246
bb_rcfailure2246:
  %v10659 = load i64, ptr %slot110, align 8
  %p10660 = inttoptr i64 %v10659 to ptr
  %call10661 = call i32 @myl_rc_take_failure(ptr %p10660) nomerge, !dbg !170
  store i32 %call10661, ptr %slot1796, align 8
  %v10662 = load i64, ptr %slot1, align 8
  %p10663 = inttoptr i64 %v10662 to ptr
  %v10664 = load i32, ptr %slot1796, align 8
  %call10665 = call i32 @myl_qbe_rc_status(ptr %p10663, i32 %v10664) nomerge, !dbg !170
  store i32 %call10665, ptr %slot1797, align 8
  br label %bb_failure
bb_rcsuccess2246:
  br label %bb_rcmoved2222
bb_rcmoved2222:
  %v10666 = load i64, ptr %slot30, align 8
  %p10667 = inttoptr i64 %v10666 to ptr
  store i32 0, ptr %p10667, align 4, !alias.scope !3, !noalias !4
  %v10668 = load i64, ptr %slot47, align 8
  %p10669 = inttoptr i64 %v10668 to ptr
  store i32 2, ptr %p10669, align 4, !alias.scope !3, !noalias !4
  %v10670 = load i64, ptr %slot46, align 8
  %p10671 = inttoptr i64 %v10670 to ptr
  store i32 1, ptr %p10671, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2213
bb_rccopy2213:
  %v10672 = load i64, ptr %slot65, align 8
  store i64 %v10672, ptr %slot1798, align 8
  %v10673 = load i64, ptr %slot111, align 8
  store i64 %v10673, ptr %slot1799, align 8
  %v10674 = load i64, ptr %slot110, align 8
  %v10675 = load i64, ptr %slot1798, align 8
  %v10676 = load i64, ptr %slot1768, align 8
  %v10677 = load i64, ptr %slot1799, align 8
  %cv10678 = trunc i64 %v10677 to i32
  %call10679 = call i32 @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_retain(i64 %v10674, i64 %v10675, i64 %v10676, i32 %cv10678) nomerge, !dbg !170
  store i32 %call10679, ptr %slot1800, align 8
  %v10680 = load i32, ptr %slot1800, align 8
  %cv10681 = zext i32 %v10680 to i64
  %cond10682 = icmp ne i64 %cv10681, 0
  br i1 %cond10682, label %bb_rcsuccess2255, label %bb_rcfailure2255
bb_rcfailure2255:
  %v10683 = load i64, ptr %slot110, align 8
  %p10684 = inttoptr i64 %v10683 to ptr
  %call10685 = call i32 @myl_rc_take_failure(ptr %p10684) nomerge, !dbg !170
  store i32 %call10685, ptr %slot1801, align 8
  %v10686 = load i64, ptr %slot1, align 8
  %p10687 = inttoptr i64 %v10686 to ptr
  %v10688 = load i32, ptr %slot1801, align 8
  %call10689 = call i32 @myl_qbe_rc_status(ptr %p10687, i32 %v10688) nomerge, !dbg !170
  store i32 %call10689, ptr %slot1802, align 8
  br label %bb_failure
bb_rcsuccess2255:
  %v10690 = load i64, ptr %slot47, align 8
  %p10691 = inttoptr i64 %v10690 to ptr
  store i32 2, ptr %p10691, align 4, !alias.scope !3, !noalias !4
  %v10692 = load i64, ptr %slot46, align 8
  %p10693 = inttoptr i64 %v10692 to ptr
  store i32 1, ptr %p10693, align 4, !alias.scope !3, !noalias !4
  %v10694 = load i64, ptr %slot30, align 8
  %p10695 = inttoptr i64 %v10694 to ptr
  %ld10696 = load i32, ptr %p10695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10696, ptr %slot1803, align 8
  %v10697 = load i32, ptr %slot1803, align 8
  %cv10698 = zext i32 %v10697 to i64
  %cond10699 = icmp ne i64 %cv10698, 0
  br i1 %cond10699, label %bb_rcslotdrop2262, label %bb_rcslotdone2262
bb_rcslotdrop2262:
  %v10700 = load i64, ptr %slot30, align 8
  %p10701 = inttoptr i64 %v10700 to ptr
  store i32 0, ptr %p10701, align 4, !alias.scope !3, !noalias !4
  %v10702 = load i64, ptr %slot50, align 8
  store i64 %v10702, ptr %slot1804, align 8
  %v10703 = load i64, ptr %slot31, align 8
  %p10704 = inttoptr i64 %v10703 to ptr
  %ld10705 = load i32, ptr %p10704, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10705, ptr %slot1805, align 8
  %v10706 = load i32, ptr %slot1805, align 8
  %op10707 = and i32 %v10706, 28
  store i32 %op10707, ptr %slot1806, align 8
  %v10708 = load i32, ptr %slot1806, align 8
  %cv10709 = zext i32 %v10708 to i64
  %cond10710 = icmp ne i64 %cv10709, 0
  br i1 %cond10710, label %bb_rcslotrole2262, label %bb_rcslotowner2262
bb_rcslotrole2262:
  %v10711 = load i64, ptr %slot110, align 8
  store i64 %v10711, ptr %slot1807, align 8
  %v10712 = load i64, ptr %slot1807, align 8
  %v10713 = load i64, ptr %slot1804, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64 %v10712, i64 %v10713) nomerge, !dbg !170
  br label %bb_rcslotdone2262
bb_rcslotowner2262:
  %v10714 = load i64, ptr %slot110, align 8
  store i64 %v10714, ptr %slot1808, align 8
  %v10715 = load i64, ptr %slot1808, align 8
  %v10716 = load i64, ptr %slot1804, align 8
  call void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64 %v10715, i64 %v10716) nomerge, !dbg !170
  br label %bb_rcslotdone2262
bb_rcslotdone2262:
  br label %bb_rcprepared2213
bb_rcprepared2213:
  %v10717 = load i64, ptr %slot65, align 8
  store i64 %v10717, ptr %slot1809, align 8
  %v10718 = load i64, ptr %slot1809, align 8
  %v10719 = load i64, ptr %slot1767, align 8
  %p10720 = inttoptr i64 %v10718 to ptr
  %p10721 = inttoptr i64 %v10719 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10721, ptr %p10720, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v10722 = load i64, ptr %slot46, align 8
  %p10723 = inttoptr i64 %v10722 to ptr
  store i32 0, ptr %p10723, align 4, !alias.scope !3, !noalias !4
  %v10724 = load i64, ptr %slot82, align 8
  %p10725 = inttoptr i64 %v10724 to ptr
  %ld10726 = load i64, ptr %p10725, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10726, ptr %slot1810, align 8
  %v10727 = load i64, ptr %slot1810, align 8
  %v10728 = load i64, ptr %slot59, align 8
  %p10729 = inttoptr i64 %v10728 to ptr
  store i64 %v10727, ptr %p10729, align 8, !alias.scope !3, !noalias !4
  %v10730 = load i64, ptr %slot59, align 8
  store i64 %v10730, ptr %slot1811, align 8
  %v10731 = load i64, ptr %slot1687, align 8
  %p10733 = inttoptr i64 %v10731 to ptr
  %gep10734 = getelementptr i8, ptr %p10733, i64 24
  %op10732 = ptrtoint ptr %gep10734 to i64
  store i64 %op10732, ptr %slot1812, align 8
  %v10735 = load i64, ptr %slot82, align 8
  %p10736 = inttoptr i64 %v10735 to ptr
  %ld10737 = load i64, ptr %p10736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10737, ptr %slot1813, align 8
  %v10738 = load i64, ptr %slot1813, align 8
  %v10739 = load i64, ptr %slot59, align 8
  %p10740 = inttoptr i64 %v10739 to ptr
  store i64 %v10738, ptr %p10740, align 8, !alias.scope !3, !noalias !4
  %v10741 = load i64, ptr %slot59, align 8
  store i64 %v10741, ptr %slot1814, align 8
  %v10742 = load i64, ptr %slot32, align 8
  %p10743 = inttoptr i64 %v10742 to ptr
  %ld10744 = load i32, ptr %p10743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10744, ptr %slot1815, align 8
  %v10745 = load i64, ptr %slot33, align 8
  %p10746 = inttoptr i64 %v10745 to ptr
  %ld10747 = load i32, ptr %p10746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10747, ptr %slot1816, align 8
  %v10748 = load i32, ptr %slot1816, align 8
  %op10749 = and i32 %v10748, 24
  store i32 %op10749, ptr %slot1816, align 8
  %v10750 = load i32, ptr %slot1816, align 8
  %cmp10751 = icmp eq i32 %v10750, 0
  %cv10752 = zext i1 %cmp10751 to i32
  store i32 %cv10752, ptr %slot1817, align 8
  %v10753 = load i32, ptr %slot1815, align 8
  %v10754 = load i32, ptr %slot1817, align 8
  %op10755 = and i32 %v10753, %v10754
  store i32 %op10755, ptr %slot1818, align 8
  %v10756 = load i32, ptr %slot1818, align 8
  %cv10757 = zext i32 %v10756 to i64
  %cond10758 = icmp ne i64 %cv10757, 0
  br i1 %cond10758, label %bb_rctake2276, label %bb_rccopy2276
bb_rctake2276:
  %v10759 = load i64, ptr %slot65, align 8
  store i64 %v10759, ptr %slot1819, align 8
  %v10760 = load i64, ptr %slot111, align 8
  store i64 %v10760, ptr %slot1820, align 8
  %v10761 = load i64, ptr %slot1814, align 8
  %v10762 = load i64, ptr %slot1819, align 8
  %op10763 = sub i64 %v10761, %v10762
  store i64 %op10763, ptr %slot1821, align 8
  %v10764 = load i64, ptr %slot1819, align 8
  %v10765 = load i64, ptr %slot1814, align 8
  %op10766 = sub i64 %v10764, %v10765
  store i64 %op10766, ptr %slot1822, align 8
  %v10767 = load i64, ptr %slot1821, align 8
  %cmp10768 = icmp ult i64 %v10767, 8
  %cv10769 = zext i1 %cmp10768 to i32
  store i32 %cv10769, ptr %slot1823, align 8
  %v10770 = load i64, ptr %slot1822, align 8
  %cmp10771 = icmp ult i64 %v10770, 8
  %cv10772 = zext i1 %cmp10771 to i32
  store i32 %cv10772, ptr %slot1824, align 8
  %v10773 = load i32, ptr %slot1823, align 8
  %v10774 = load i32, ptr %slot1824, align 8
  %op10775 = or i32 %v10773, %v10774
  store i32 %op10775, ptr %slot1825, align 8
  %v10776 = load i32, ptr %slot1825, align 8
  %cv10777 = zext i32 %v10776 to i64
  %cond10778 = icmp ne i64 %cv10777, 0
  br i1 %cond10778, label %bb_rcmoveslow2285, label %bb_rcmovecheck2285
bb_rcmovecheck2285:
  %v10779 = load i64, ptr %slot1814, align 8
  %p10781 = inttoptr i64 %v10779 to ptr
  %gep10782 = getelementptr i8, ptr %p10781, i64 0
  %op10780 = ptrtoint ptr %gep10782 to i64
  store i64 %op10780, ptr %slot1826, align 8
  %v10783 = load i64, ptr %slot1826, align 8
  %p10784 = inttoptr i64 %v10783 to ptr
  %ld10785 = load i64, ptr %p10784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10785, ptr %slot1827, align 8
  %v10786 = load i64, ptr %slot1827, align 8
  %cmp10787 = icmp ne i64 %v10786, 0
  %cv10788 = zext i1 %cmp10787 to i32
  store i32 %cv10788, ptr %slot1828, align 8
  %v10789 = load i32, ptr %slot1828, align 8
  %cv10790 = zext i32 %v10789 to i64
  %cond10791 = icmp ne i64 %cv10790, 0
  br i1 %cond10791, label %bb_rcmoveheader2293, label %bb_rcmovenext2293
bb_rcmoveheader2293:
  %v10792 = load i64, ptr %slot1827, align 8
  %op10793 = sub i64 %v10792, 16
  store i64 %op10793, ptr %slot1829, align 8
  %v10794 = load i64, ptr %slot1827, align 8
  %p10795 = inttoptr i64 %v10794 to ptr
  %rgep10796 = getelementptr i8, ptr %p10795, i64 -16
  %ld10797 = load i64, ptr %rgep10796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10797, ptr %slot1830, align 8
  %v10798 = load i64, ptr %slot1830, align 8
  %op10799 = and i64 %v10798, 5764607523034234881
  store i64 %op10799, ptr %slot1831, align 8
  %v10800 = load i64, ptr %slot1831, align 8
  %cmp10801 = icmp ne i64 %v10800, 0
  %cv10802 = zext i1 %cmp10801 to i32
  store i32 %cv10802, ptr %slot1832, align 8
  %v10803 = load i32, ptr %slot1832, align 8
  %cv10804 = zext i32 %v10803 to i64
  %cond10805 = icmp ne i64 %cv10804, 0
  br i1 %cond10805, label %bb_rcmoveslow2285, label %bb_rcmovenext2293
bb_rcmovenext2293:
  %v10806 = load i64, ptr %slot1814, align 8
  %v10807 = load i64, ptr %slot1819, align 8
  %p10808 = inttoptr i64 %v10806 to ptr
  %p10809 = inttoptr i64 %v10807 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10809, ptr %p10808, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10810 = load i64, ptr %slot1814, align 8
  %p10811 = inttoptr i64 %v10810 to ptr
  store i64 0, ptr %p10811, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2285
bb_rcmoveslow2285:
  %v10812 = load i64, ptr %slot110, align 8
  %v10813 = load i64, ptr %slot1819, align 8
  %v10814 = load i64, ptr %slot1814, align 8
  %v10815 = load i64, ptr %slot1820, align 8
  %cv10816 = trunc i64 %v10815 to i32
  %call10817 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v10812, i64 %v10813, i64 %v10814, i32 %cv10816) nomerge, !dbg !170
  store i32 %call10817, ptr %slot1833, align 8
  %v10818 = load i32, ptr %slot1833, align 8
  %cv10819 = zext i32 %v10818 to i64
  %cond10820 = icmp ne i64 %cv10819, 0
  br i1 %cond10820, label %bb_rcsuccess2300, label %bb_rcfailure2300
bb_rcfailure2300:
  %v10821 = load i64, ptr %slot110, align 8
  %p10822 = inttoptr i64 %v10821 to ptr
  %call10823 = call i32 @myl_rc_take_failure(ptr %p10822) nomerge, !dbg !170
  store i32 %call10823, ptr %slot1834, align 8
  %v10824 = load i64, ptr %slot1, align 8
  %p10825 = inttoptr i64 %v10824 to ptr
  %v10826 = load i32, ptr %slot1834, align 8
  %call10827 = call i32 @myl_qbe_rc_status(ptr %p10825, i32 %v10826) nomerge, !dbg !170
  store i32 %call10827, ptr %slot1835, align 8
  br label %bb_failure
bb_rcsuccess2300:
  br label %bb_rcmoved2285
bb_rcmoved2285:
  %v10828 = load i64, ptr %slot32, align 8
  %p10829 = inttoptr i64 %v10828 to ptr
  store i32 0, ptr %p10829, align 4, !alias.scope !3, !noalias !4
  %v10830 = load i64, ptr %slot47, align 8
  %p10831 = inttoptr i64 %v10830 to ptr
  store i32 2, ptr %p10831, align 4, !alias.scope !3, !noalias !4
  %v10832 = load i64, ptr %slot46, align 8
  %p10833 = inttoptr i64 %v10832 to ptr
  store i32 1, ptr %p10833, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2276
bb_rccopy2276:
  %v10834 = load i64, ptr %slot65, align 8
  store i64 %v10834, ptr %slot1836, align 8
  %v10835 = load i64, ptr %slot111, align 8
  store i64 %v10835, ptr %slot1837, align 8
  %v10836 = load i64, ptr %slot1814, align 8
  %p10837 = inttoptr i64 %v10836 to ptr
  %ld10838 = load i64, ptr %p10837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10838, ptr %slot1838, align 8
  %v10839 = load i64, ptr %slot1838, align 8
  %cmp10840 = icmp ne i64 %v10839, 0
  %cv10841 = zext i1 %cmp10840 to i32
  store i32 %cv10841, ptr %slot1839, align 8
  %v10842 = load i32, ptr %slot1839, align 8
  %cv10843 = zext i32 %v10842 to i64
  %cond10844 = icmp ne i64 %cv10843, 0
  br i1 %cond10844, label %bb_rcgnn2309, label %bb_rcgplain2309
bb_rcgnn2309:
  %v10845 = load i64, ptr %slot1838, align 8
  %op10846 = sub i64 %v10845, 16
  store i64 %op10846, ptr %slot1840, align 8
  %v10847 = load i64, ptr %slot1838, align 8
  %p10848 = inttoptr i64 %v10847 to ptr
  %rgep10849 = getelementptr i8, ptr %p10848, i64 -16
  %ld10850 = load i64, ptr %rgep10849, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10850, ptr %slot1841, align 8
  %v10851 = load i64, ptr %slot1841, align 8
  %op10852 = and i64 %v10851, 4611686018427387906
  store i64 %op10852, ptr %slot1842, align 8
  %v10853 = load i64, ptr %slot1842, align 8
  %cmp10854 = icmp ne i64 %v10853, 0
  %cv10855 = zext i1 %cmp10854 to i32
  store i32 %cv10855, ptr %slot1843, align 8
  %v10856 = load i32, ptr %slot1843, align 8
  %cv10857 = zext i32 %v10856 to i64
  %cond10858 = icmp ne i64 %cv10857, 0
  br i1 %cond10858, label %bb_rcgspecial2309, label %bb_rcginc2309
bb_rcginc2309:
  %v10859 = load i64, ptr %slot1838, align 8
  %op10860 = sub i64 %v10859, 32
  store i64 %op10860, ptr %slot1844, align 8
  %v10861 = load i64, ptr %slot1838, align 8
  %p10862 = inttoptr i64 %v10861 to ptr
  %rgep10863 = getelementptr i8, ptr %p10862, i64 -32
  %ld10864 = load i64, ptr %rgep10863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10864, ptr %slot1845, align 8
  %v10865 = load i64, ptr %slot1845, align 8
  %op10866 = add i64 %v10865, 1
  store i64 %op10866, ptr %slot1846, align 8
  %v10867 = load i64, ptr %slot1846, align 8
  %cmp10868 = icmp eq i64 %v10867, 0
  %cv10869 = zext i1 %cmp10868 to i32
  store i32 %cv10869, ptr %slot1847, align 8
  %v10870 = load i32, ptr %slot1847, align 8
  %cv10871 = zext i32 %v10870 to i64
  %cond10872 = icmp ne i64 %cv10871, 0
  br i1 %cond10872, label %bb_rcglimit2309, label %bb_rcgcapacity2309
bb_rcglimit2309:
  %v10873 = load i64, ptr %slot1, align 8
  %p10874 = inttoptr i64 %v10873 to ptr
  %call10875 = call i32 @myl_qbe_rc_status(ptr %p10874, i32 2) nomerge, !dbg !170
  store i32 %call10875, ptr %slot1848, align 8
  br label %bb_failure
bb_rcgcapacity2309:
  %v10876 = load i64, ptr %slot1846, align 8
  %v10877 = load i64, ptr %slot1838, align 8
  %p10878 = inttoptr i64 %v10877 to ptr
  %rgep10879 = getelementptr i8, ptr %p10878, i64 -32
  store i64 %v10876, ptr %rgep10879, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2309
bb_rcgspecial2309:
  %v10880 = load i64, ptr %slot1841, align 8
  %op10881 = and i64 %v10880, 4611686018427387904
  store i64 %op10881, ptr %slot1849, align 8
  %v10882 = load i64, ptr %slot1849, align 8
  %cmp10883 = icmp ne i64 %v10882, 0
  %cv10884 = zext i1 %cmp10883 to i32
  store i32 %cv10884, ptr %slot1850, align 8
  %v10885 = load i32, ptr %slot1850, align 8
  %cv10886 = zext i32 %v10885 to i64
  %cond10887 = icmp ne i64 %cv10886, 0
  br i1 %cond10887, label %bb_rcgslow2309, label %bb_rcgplain2309
bb_rcgslow2309:
  %v10888 = load i64, ptr %slot110, align 8
  %v10889 = load i64, ptr %slot1836, align 8
  %v10890 = load i64, ptr %slot1814, align 8
  %v10891 = load i64, ptr %slot1837, align 8
  %cv10892 = trunc i64 %v10891 to i32
  %call10893 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v10888, i64 %v10889, i64 %v10890, i32 %cv10892) nomerge, !dbg !170
  store i32 %call10893, ptr %slot1851, align 8
  %v10894 = load i32, ptr %slot1851, align 8
  %cv10895 = zext i32 %v10894 to i64
  %cond10896 = icmp ne i64 %cv10895, 0
  br i1 %cond10896, label %bb_rcsuccess2323, label %bb_rcfailure2323
bb_rcfailure2323:
  %v10897 = load i64, ptr %slot110, align 8
  %p10898 = inttoptr i64 %v10897 to ptr
  %call10899 = call i32 @myl_rc_take_failure(ptr %p10898) nomerge, !dbg !170
  store i32 %call10899, ptr %slot1852, align 8
  %v10900 = load i64, ptr %slot1, align 8
  %p10901 = inttoptr i64 %v10900 to ptr
  %v10902 = load i32, ptr %slot1852, align 8
  %call10903 = call i32 @myl_qbe_rc_status(ptr %p10901, i32 %v10902) nomerge, !dbg !170
  store i32 %call10903, ptr %slot1853, align 8
  br label %bb_failure
bb_rcsuccess2323:
  br label %bb_rcgdone2309
bb_rcgplain2309:
  %v10904 = load i64, ptr %slot1838, align 8
  %v10905 = load i64, ptr %slot1836, align 8
  %p10906 = inttoptr i64 %v10905 to ptr
  store i64 %v10904, ptr %p10906, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2309
bb_rcgdone2309:
  %v10907 = load i64, ptr %slot47, align 8
  %p10908 = inttoptr i64 %v10907 to ptr
  store i32 2, ptr %p10908, align 4, !alias.scope !3, !noalias !4
  %v10909 = load i64, ptr %slot46, align 8
  %p10910 = inttoptr i64 %v10909 to ptr
  store i32 1, ptr %p10910, align 4, !alias.scope !3, !noalias !4
  %v10911 = load i64, ptr %slot32, align 8
  %p10912 = inttoptr i64 %v10911 to ptr
  %ld10913 = load i32, ptr %p10912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10913, ptr %slot1854, align 8
  %v10914 = load i32, ptr %slot1854, align 8
  %cv10915 = zext i32 %v10914 to i64
  %cond10916 = icmp ne i64 %cv10915, 0
  br i1 %cond10916, label %bb_rcslotdrop2330, label %bb_rcslotdone2330
bb_rcslotdrop2330:
  %v10917 = load i64, ptr %slot32, align 8
  %p10918 = inttoptr i64 %v10917 to ptr
  store i32 0, ptr %p10918, align 4, !alias.scope !3, !noalias !4
  %v10919 = load i64, ptr %slot51, align 8
  store i64 %v10919, ptr %slot1855, align 8
  %v10920 = load i64, ptr %slot33, align 8
  %p10921 = inttoptr i64 %v10920 to ptr
  %ld10922 = load i32, ptr %p10921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10922, ptr %slot1856, align 8
  %v10923 = load i32, ptr %slot1856, align 8
  %op10924 = and i32 %v10923, 28
  store i32 %op10924, ptr %slot1857, align 8
  %v10925 = load i32, ptr %slot1857, align 8
  %cv10926 = zext i32 %v10925 to i64
  %cond10927 = icmp ne i64 %cv10926, 0
  br i1 %cond10927, label %bb_rcslotrole2330, label %bb_rcslotowner2330
bb_rcslotrole2330:
  %v10928 = load i64, ptr %slot110, align 8
  store i64 %v10928, ptr %slot1858, align 8
  %v10929 = load i64, ptr %slot1855, align 8
  %p10930 = inttoptr i64 %v10929 to ptr
  %ld10931 = load i64, ptr %p10930, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10931, ptr %slot1859, align 8
  %v10932 = load i64, ptr %slot1859, align 8
  %cmp10933 = icmp ne i64 %v10932, 0
  %cv10934 = zext i1 %cmp10933 to i32
  store i32 %cv10934, ptr %slot1860, align 8
  %v10935 = load i32, ptr %slot1860, align 8
  %cv10936 = zext i32 %v10935 to i64
  %cond10937 = icmp ne i64 %cv10936, 0
  br i1 %cond10937, label %bb_rcgnn2346, label %bb_rcgdone2346
bb_rcgnn2346:
  %v10938 = load i64, ptr %slot1859, align 8
  %op10939 = sub i64 %v10938, 16
  store i64 %op10939, ptr %slot1861, align 8
  %v10940 = load i64, ptr %slot1859, align 8
  %p10941 = inttoptr i64 %v10940 to ptr
  %rgep10942 = getelementptr i8, ptr %p10941, i64 -16
  %ld10943 = load i64, ptr %rgep10942, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10943, ptr %slot1862, align 8
  %v10944 = load i64, ptr %slot1862, align 8
  %op10945 = and i64 %v10944, 4611686018427387906
  store i64 %op10945, ptr %slot1863, align 8
  %v10946 = load i64, ptr %slot1863, align 8
  %cmp10947 = icmp ne i64 %v10946, 0
  %cv10948 = zext i1 %cmp10947 to i32
  store i32 %cv10948, ptr %slot1864, align 8
  %v10949 = load i32, ptr %slot1864, align 8
  %cv10950 = zext i32 %v10949 to i64
  %cond10951 = icmp ne i64 %cv10950, 0
  br i1 %cond10951, label %bb_rcgclear2346, label %bb_rcgcounted2346
bb_rcgcounted2346:
  %v10952 = load i64, ptr %slot1859, align 8
  %op10953 = sub i64 %v10952, 24
  store i64 %op10953, ptr %slot1865, align 8
  %v10954 = load i64, ptr %slot1859, align 8
  %p10955 = inttoptr i64 %v10954 to ptr
  %rgep10956 = getelementptr i8, ptr %p10955, i64 -24
  %ld10957 = load i64, ptr %rgep10956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10957, ptr %slot1866, align 8
  %v10958 = load i64, ptr %slot1866, align 8
  %op10959 = sub i64 %v10958, 1
  store i64 %op10959, ptr %slot1867, align 8
  %v10960 = load i64, ptr %slot1867, align 8
  %cmp10961 = icmp eq i64 %v10960, 0
  %cv10962 = zext i1 %cmp10961 to i32
  store i32 %cv10962, ptr %slot1868, align 8
  %v10963 = load i32, ptr %slot1868, align 8
  %cv10964 = zext i32 %v10963 to i64
  %cond10965 = icmp ne i64 %cv10964, 0
  br i1 %cond10965, label %bb_rcglast2346, label %bb_rcgdec2346
bb_rcglast2346:
  %v10966 = load i64, ptr %slot1859, align 8
  %op10967 = sub i64 %v10966, 32
  store i64 %op10967, ptr %slot1869, align 8
  %v10968 = load i64, ptr %slot1859, align 8
  %p10969 = inttoptr i64 %v10968 to ptr
  %rgep10970 = getelementptr i8, ptr %p10969, i64 -32
  %ld10971 = load i64, ptr %rgep10970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10971, ptr %slot1870, align 8
  %v10972 = load i64, ptr %slot1870, align 8
  %cmp10973 = icmp ne i64 %v10972, 0
  %cv10974 = zext i1 %cmp10973 to i32
  store i32 %cv10974, ptr %slot1871, align 8
  %v10975 = load i32, ptr %slot1871, align 8
  %cv10976 = zext i32 %v10975 to i64
  %cond10977 = icmp ne i64 %cv10976, 0
  br i1 %cond10977, label %bb_rcgdec2346, label %bb_rcgslow2346
bb_rcgslow2346:
  %v10978 = load i64, ptr %slot1858, align 8
  %v10979 = load i64, ptr %slot1855, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v10978, i64 %v10979) nomerge, !dbg !170
  br label %bb_rcgdone2346
bb_rcgdec2346:
  %v10980 = load i64, ptr %slot1867, align 8
  %v10981 = load i64, ptr %slot1859, align 8
  %p10982 = inttoptr i64 %v10981 to ptr
  %rgep10983 = getelementptr i8, ptr %p10982, i64 -24
  store i64 %v10980, ptr %rgep10983, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2346
bb_rcgclear2346:
  %v10984 = load i64, ptr %slot1855, align 8
  %p10985 = inttoptr i64 %v10984 to ptr
  store i64 0, ptr %p10985, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2346
bb_rcgdone2346:
  br label %bb_rcslotdone2330
bb_rcslotowner2330:
  %v10986 = load i64, ptr %slot110, align 8
  store i64 %v10986, ptr %slot1872, align 8
  %v10987 = load i64, ptr %slot1855, align 8
  %p10988 = inttoptr i64 %v10987 to ptr
  %ld10989 = load i64, ptr %p10988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10989, ptr %slot1873, align 8
  %v10990 = load i64, ptr %slot1873, align 8
  %cmp10991 = icmp ne i64 %v10990, 0
  %cv10992 = zext i1 %cmp10991 to i32
  store i32 %cv10992, ptr %slot1874, align 8
  %v10993 = load i32, ptr %slot1874, align 8
  %cv10994 = zext i32 %v10993 to i64
  %cond10995 = icmp ne i64 %cv10994, 0
  br i1 %cond10995, label %bb_rcgnn2361, label %bb_rcgdone2361
bb_rcgnn2361:
  %v10996 = load i64, ptr %slot1873, align 8
  %op10997 = sub i64 %v10996, 16
  store i64 %op10997, ptr %slot1875, align 8
  %v10998 = load i64, ptr %slot1873, align 8
  %p10999 = inttoptr i64 %v10998 to ptr
  %rgep11000 = getelementptr i8, ptr %p10999, i64 -16
  %ld11001 = load i64, ptr %rgep11000, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11001, ptr %slot1876, align 8
  %v11002 = load i64, ptr %slot1876, align 8
  %op11003 = and i64 %v11002, 4611686018427387906
  store i64 %op11003, ptr %slot1877, align 8
  %v11004 = load i64, ptr %slot1877, align 8
  %cmp11005 = icmp ne i64 %v11004, 0
  %cv11006 = zext i1 %cmp11005 to i32
  store i32 %cv11006, ptr %slot1878, align 8
  %v11007 = load i32, ptr %slot1878, align 8
  %cv11008 = zext i32 %v11007 to i64
  %cond11009 = icmp ne i64 %cv11008, 0
  br i1 %cond11009, label %bb_rcgclear2361, label %bb_rcgcounted2361
bb_rcgcounted2361:
  %v11010 = load i64, ptr %slot1873, align 8
  %op11011 = sub i64 %v11010, 32
  store i64 %op11011, ptr %slot1879, align 8
  %v11012 = load i64, ptr %slot1873, align 8
  %p11013 = inttoptr i64 %v11012 to ptr
  %rgep11014 = getelementptr i8, ptr %p11013, i64 -32
  %ld11015 = load i64, ptr %rgep11014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11015, ptr %slot1880, align 8
  %v11016 = load i64, ptr %slot1880, align 8
  %op11017 = sub i64 %v11016, 1
  store i64 %op11017, ptr %slot1881, align 8
  %v11018 = load i64, ptr %slot1881, align 8
  %cmp11019 = icmp eq i64 %v11018, 0
  %cv11020 = zext i1 %cmp11019 to i32
  store i32 %cv11020, ptr %slot1882, align 8
  %v11021 = load i32, ptr %slot1882, align 8
  %cv11022 = zext i32 %v11021 to i64
  %cond11023 = icmp ne i64 %cv11022, 0
  br i1 %cond11023, label %bb_rcglast2361, label %bb_rcgdec2361
bb_rcglast2361:
  %v11024 = load i64, ptr %slot1873, align 8
  %op11025 = sub i64 %v11024, 24
  store i64 %op11025, ptr %slot1883, align 8
  %v11026 = load i64, ptr %slot1873, align 8
  %p11027 = inttoptr i64 %v11026 to ptr
  %rgep11028 = getelementptr i8, ptr %p11027, i64 -24
  %ld11029 = load i64, ptr %rgep11028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11029, ptr %slot1884, align 8
  %v11030 = load i64, ptr %slot1884, align 8
  %cmp11031 = icmp ne i64 %v11030, 0
  %cv11032 = zext i1 %cmp11031 to i32
  store i32 %cv11032, ptr %slot1885, align 8
  %v11033 = load i32, ptr %slot1885, align 8
  %cv11034 = zext i32 %v11033 to i64
  %cond11035 = icmp ne i64 %cv11034, 0
  br i1 %cond11035, label %bb_rcgdec2361, label %bb_rcgslow2361
bb_rcgslow2361:
  %v11036 = load i64, ptr %slot1872, align 8
  %v11037 = load i64, ptr %slot1855, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v11036, i64 %v11037) nomerge, !dbg !170
  br label %bb_rcgdone2361
bb_rcgdec2361:
  %v11038 = load i64, ptr %slot1881, align 8
  %v11039 = load i64, ptr %slot1873, align 8
  %p11040 = inttoptr i64 %v11039 to ptr
  %rgep11041 = getelementptr i8, ptr %p11040, i64 -32
  store i64 %v11038, ptr %rgep11041, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2361
bb_rcgclear2361:
  %v11042 = load i64, ptr %slot1855, align 8
  %p11043 = inttoptr i64 %v11042 to ptr
  store i64 0, ptr %p11043, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2361
bb_rcgdone2361:
  br label %bb_rcslotdone2330
bb_rcslotdone2330:
  br label %bb_rcprepared2276
bb_rcprepared2276:
  %v11044 = load i64, ptr %slot65, align 8
  store i64 %v11044, ptr %slot1886, align 8
  %v11045 = load i64, ptr %slot1886, align 8
  %v11046 = load i64, ptr %slot1812, align 8
  %p11047 = inttoptr i64 %v11045 to ptr
  %p11048 = inttoptr i64 %v11046 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11048, ptr %p11047, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11049 = load i64, ptr %slot46, align 8
  %p11050 = inttoptr i64 %v11049 to ptr
  store i32 0, ptr %p11050, align 4, !alias.scope !3, !noalias !4
  %v11051 = load i64, ptr %slot83, align 8
  %p11052 = inttoptr i64 %v11051 to ptr
  %ld11053 = load i64, ptr %p11052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11053, ptr %slot1887, align 8
  %v11054 = load i64, ptr %slot1687, align 8
  %p11056 = inttoptr i64 %v11054 to ptr
  %gep11057 = getelementptr i8, ptr %p11056, i64 32
  %op11055 = ptrtoint ptr %gep11057 to i64
  store i64 %op11055, ptr %slot1888, align 8
  %v11058 = load i64, ptr %slot83, align 8
  %p11059 = inttoptr i64 %v11058 to ptr
  %ld11060 = load i64, ptr %p11059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11060, ptr %slot1889, align 8
  %v11061 = load i64, ptr %slot34, align 8
  %p11062 = inttoptr i64 %v11061 to ptr
  %ld11063 = load i32, ptr %p11062, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11063, ptr %slot1890, align 8
  %v11064 = load i64, ptr %slot35, align 8
  %p11065 = inttoptr i64 %v11064 to ptr
  %ld11066 = load i32, ptr %p11065, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11066, ptr %slot1891, align 8
  %v11067 = load i32, ptr %slot1891, align 8
  %op11068 = and i32 %v11067, 24
  store i32 %op11068, ptr %slot1891, align 8
  %v11069 = load i32, ptr %slot1891, align 8
  %cmp11070 = icmp eq i32 %v11069, 0
  %cv11071 = zext i1 %cmp11070 to i32
  store i32 %cv11071, ptr %slot1892, align 8
  %v11072 = load i32, ptr %slot1890, align 8
  %v11073 = load i32, ptr %slot1892, align 8
  %op11074 = and i32 %v11072, %v11073
  store i32 %op11074, ptr %slot1893, align 8
  %v11075 = load i32, ptr %slot1893, align 8
  %cv11076 = zext i32 %v11075 to i64
  %cond11077 = icmp ne i64 %cv11076, 0
  br i1 %cond11077, label %bb_rctake2370, label %bb_rccopy2370
bb_rctake2370:
  %v11078 = load i64, ptr %slot65, align 8
  store i64 %v11078, ptr %slot1894, align 8
  %v11079 = load i64, ptr %slot111, align 8
  store i64 %v11079, ptr %slot1895, align 8
  %v11080 = load i64, ptr %slot1889, align 8
  %v11081 = load i64, ptr %slot1894, align 8
  %op11082 = sub i64 %v11080, %v11081
  store i64 %op11082, ptr %slot1896, align 8
  %v11083 = load i64, ptr %slot1894, align 8
  %v11084 = load i64, ptr %slot1889, align 8
  %op11085 = sub i64 %v11083, %v11084
  store i64 %op11085, ptr %slot1897, align 8
  %v11086 = load i64, ptr %slot1896, align 8
  %cmp11087 = icmp ult i64 %v11086, 16
  %cv11088 = zext i1 %cmp11087 to i32
  store i32 %cv11088, ptr %slot1898, align 8
  %v11089 = load i64, ptr %slot1897, align 8
  %cmp11090 = icmp ult i64 %v11089, 16
  %cv11091 = zext i1 %cmp11090 to i32
  store i32 %cv11091, ptr %slot1899, align 8
  %v11092 = load i32, ptr %slot1898, align 8
  %v11093 = load i32, ptr %slot1899, align 8
  %op11094 = or i32 %v11092, %v11093
  store i32 %op11094, ptr %slot1900, align 8
  %v11095 = load i32, ptr %slot1900, align 8
  %cv11096 = zext i32 %v11095 to i64
  %cond11097 = icmp ne i64 %cv11096, 0
  br i1 %cond11097, label %bb_rcmoveslow2379, label %bb_rcmovecheck2379
bb_rcmovecheck2379:
  %v11098 = load i64, ptr %slot1889, align 8
  %op11099 = add i64 %v11098, 0
  store i64 %op11099, ptr %slot1901, align 8
  %v11100 = load i64, ptr %slot1901, align 8
  %p11101 = inttoptr i64 %v11100 to ptr
  %ld11102 = load i64, ptr %p11101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11102, ptr %slot1902, align 8
  %v11103 = load i64, ptr %slot1902, align 8
  %cmp11104 = icmp ne i64 %v11103, 0
  %cv11105 = zext i1 %cmp11104 to i32
  store i32 %cv11105, ptr %slot1903, align 8
  %v11106 = load i32, ptr %slot1903, align 8
  %cv11107 = zext i32 %v11106 to i64
  %cond11108 = icmp ne i64 %cv11107, 0
  br i1 %cond11108, label %bb_rcmoveheader2387, label %bb_rcmovenext2387
bb_rcmoveheader2387:
  %v11109 = load i64, ptr %slot1902, align 8
  %op11110 = sub i64 %v11109, 16
  store i64 %op11110, ptr %slot1904, align 8
  %v11111 = load i64, ptr %slot1902, align 8
  %p11112 = inttoptr i64 %v11111 to ptr
  %rgep11113 = getelementptr i8, ptr %p11112, i64 -16
  %ld11114 = load i64, ptr %rgep11113, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11114, ptr %slot1905, align 8
  %v11115 = load i64, ptr %slot1905, align 8
  %op11116 = and i64 %v11115, 5764607523034234881
  store i64 %op11116, ptr %slot1906, align 8
  %v11117 = load i64, ptr %slot1906, align 8
  %cmp11118 = icmp ne i64 %v11117, 0
  %cv11119 = zext i1 %cmp11118 to i32
  store i32 %cv11119, ptr %slot1907, align 8
  %v11120 = load i32, ptr %slot1907, align 8
  %cv11121 = zext i32 %v11120 to i64
  %cond11122 = icmp ne i64 %cv11121, 0
  br i1 %cond11122, label %bb_rcmoveslow2379, label %bb_rcmovenext2387
bb_rcmovenext2387:
  %v11123 = load i64, ptr %slot1889, align 8
  %v11124 = load i64, ptr %slot1894, align 8
  %p11125 = inttoptr i64 %v11123 to ptr
  %p11126 = inttoptr i64 %v11124 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11126, ptr %p11125, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v11127 = load i64, ptr %slot1889, align 8
  %p11128 = inttoptr i64 %v11127 to ptr
  store i64 0, ptr %p11128, align 8, !alias.scope !3, !noalias !4
  %v11129 = load i64, ptr %slot1889, align 8
  %op11130 = add i64 %v11129, 8
  store i64 %op11130, ptr %slot1908, align 8
  %v11131 = load i64, ptr %slot1908, align 8
  %p11132 = inttoptr i64 %v11131 to ptr
  store i64 0, ptr %p11132, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2379
bb_rcmoveslow2379:
  %v11133 = load i64, ptr %slot110, align 8
  %v11134 = load i64, ptr %slot1894, align 8
  %v11135 = load i64, ptr %slot1889, align 8
  %v11136 = load i64, ptr %slot1895, align 8
  %cv11137 = trunc i64 %v11136 to i32
  %call11138 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v11133, i64 %v11134, i64 %v11135, i32 %cv11137) nomerge, !dbg !170
  store i32 %call11138, ptr %slot1909, align 8
  %v11139 = load i32, ptr %slot1909, align 8
  %cv11140 = zext i32 %v11139 to i64
  %cond11141 = icmp ne i64 %cv11140, 0
  br i1 %cond11141, label %bb_rcsuccess2395, label %bb_rcfailure2395
bb_rcfailure2395:
  %v11142 = load i64, ptr %slot110, align 8
  %p11143 = inttoptr i64 %v11142 to ptr
  %call11144 = call i32 @myl_rc_take_failure(ptr %p11143) nomerge, !dbg !170
  store i32 %call11144, ptr %slot1910, align 8
  %v11145 = load i64, ptr %slot1, align 8
  %p11146 = inttoptr i64 %v11145 to ptr
  %v11147 = load i32, ptr %slot1910, align 8
  %call11148 = call i32 @myl_qbe_rc_status(ptr %p11146, i32 %v11147) nomerge, !dbg !170
  store i32 %call11148, ptr %slot1911, align 8
  br label %bb_failure
bb_rcsuccess2395:
  br label %bb_rcmoved2379
bb_rcmoved2379:
  %v11149 = load i64, ptr %slot34, align 8
  %p11150 = inttoptr i64 %v11149 to ptr
  store i32 0, ptr %p11150, align 4, !alias.scope !3, !noalias !4
  %v11151 = load i64, ptr %slot47, align 8
  %p11152 = inttoptr i64 %v11151 to ptr
  store i32 2, ptr %p11152, align 4, !alias.scope !3, !noalias !4
  %v11153 = load i64, ptr %slot46, align 8
  %p11154 = inttoptr i64 %v11153 to ptr
  store i32 1, ptr %p11154, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2370
bb_rccopy2370:
  %v11155 = load i64, ptr %slot65, align 8
  store i64 %v11155, ptr %slot1912, align 8
  %v11156 = load i64, ptr %slot111, align 8
  store i64 %v11156, ptr %slot1913, align 8
  %v11157 = load i64, ptr %slot110, align 8
  %v11158 = load i64, ptr %slot1912, align 8
  %v11159 = load i64, ptr %slot1889, align 8
  %v11160 = load i64, ptr %slot1913, align 8
  %cv11161 = trunc i64 %v11160 to i32
  %call11162 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v11157, i64 %v11158, i64 %v11159, i32 %cv11161) nomerge, !dbg !170
  store i32 %call11162, ptr %slot1914, align 8
  %v11163 = load i32, ptr %slot1914, align 8
  %cv11164 = zext i32 %v11163 to i64
  %cond11165 = icmp ne i64 %cv11164, 0
  br i1 %cond11165, label %bb_rcsuccess2404, label %bb_rcfailure2404
bb_rcfailure2404:
  %v11166 = load i64, ptr %slot110, align 8
  %p11167 = inttoptr i64 %v11166 to ptr
  %call11168 = call i32 @myl_rc_take_failure(ptr %p11167) nomerge, !dbg !170
  store i32 %call11168, ptr %slot1915, align 8
  %v11169 = load i64, ptr %slot1, align 8
  %p11170 = inttoptr i64 %v11169 to ptr
  %v11171 = load i32, ptr %slot1915, align 8
  %call11172 = call i32 @myl_qbe_rc_status(ptr %p11170, i32 %v11171) nomerge, !dbg !170
  store i32 %call11172, ptr %slot1916, align 8
  br label %bb_failure
bb_rcsuccess2404:
  %v11173 = load i64, ptr %slot47, align 8
  %p11174 = inttoptr i64 %v11173 to ptr
  store i32 2, ptr %p11174, align 4, !alias.scope !3, !noalias !4
  %v11175 = load i64, ptr %slot46, align 8
  %p11176 = inttoptr i64 %v11175 to ptr
  store i32 1, ptr %p11176, align 4, !alias.scope !3, !noalias !4
  %v11177 = load i64, ptr %slot34, align 8
  %p11178 = inttoptr i64 %v11177 to ptr
  %ld11179 = load i32, ptr %p11178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11179, ptr %slot1917, align 8
  %v11180 = load i32, ptr %slot1917, align 8
  %cv11181 = zext i32 %v11180 to i64
  %cond11182 = icmp ne i64 %cv11181, 0
  br i1 %cond11182, label %bb_rcslotdrop2411, label %bb_rcslotdone2411
bb_rcslotdrop2411:
  %v11183 = load i64, ptr %slot34, align 8
  %p11184 = inttoptr i64 %v11183 to ptr
  store i32 0, ptr %p11184, align 4, !alias.scope !3, !noalias !4
  %v11185 = load i64, ptr %slot52, align 8
  store i64 %v11185, ptr %slot1918, align 8
  %v11186 = load i64, ptr %slot35, align 8
  %p11187 = inttoptr i64 %v11186 to ptr
  %ld11188 = load i32, ptr %p11187, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11188, ptr %slot1919, align 8
  %v11189 = load i32, ptr %slot1919, align 8
  %op11190 = and i32 %v11189, 28
  store i32 %op11190, ptr %slot1920, align 8
  %v11191 = load i32, ptr %slot1920, align 8
  %cv11192 = zext i32 %v11191 to i64
  %cond11193 = icmp ne i64 %cv11192, 0
  br i1 %cond11193, label %bb_rcslotrole2411, label %bb_rcslotowner2411
bb_rcslotrole2411:
  %v11194 = load i64, ptr %slot110, align 8
  store i64 %v11194, ptr %slot1921, align 8
  %v11195 = load i64, ptr %slot1921, align 8
  %v11196 = load i64, ptr %slot1918, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v11195, i64 %v11196) nomerge, !dbg !170
  br label %bb_rcslotdone2411
bb_rcslotowner2411:
  %v11197 = load i64, ptr %slot110, align 8
  store i64 %v11197, ptr %slot1922, align 8
  %v11198 = load i64, ptr %slot1922, align 8
  %v11199 = load i64, ptr %slot1918, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v11198, i64 %v11199) nomerge, !dbg !170
  br label %bb_rcslotdone2411
bb_rcslotdone2411:
  br label %bb_rcprepared2370
bb_rcprepared2370:
  %v11200 = load i64, ptr %slot65, align 8
  store i64 %v11200, ptr %slot1923, align 8
  %v11201 = load i64, ptr %slot1923, align 8
  %v11202 = load i64, ptr %slot1888, align 8
  %p11203 = inttoptr i64 %v11201 to ptr
  %p11204 = inttoptr i64 %v11202 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11204, ptr %p11203, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v11205 = load i64, ptr %slot46, align 8
  %p11206 = inttoptr i64 %v11205 to ptr
  store i32 0, ptr %p11206, align 4, !alias.scope !3, !noalias !4
  %v11207 = load i64, ptr %slot84, align 8
  %p11208 = inttoptr i64 %v11207 to ptr
  %ld11209 = load i64, ptr %p11208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11209, ptr %slot1924, align 8
  %v11210 = load i64, ptr %slot1687, align 8
  %p11212 = inttoptr i64 %v11210 to ptr
  %gep11213 = getelementptr i8, ptr %p11212, i64 48
  %op11211 = ptrtoint ptr %gep11213 to i64
  store i64 %op11211, ptr %slot1925, align 8
  %v11214 = load i64, ptr %slot84, align 8
  %p11215 = inttoptr i64 %v11214 to ptr
  %ld11216 = load i64, ptr %p11215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11216, ptr %slot1926, align 8
  %v11217 = load i64, ptr %slot36, align 8
  %p11218 = inttoptr i64 %v11217 to ptr
  %ld11219 = load i32, ptr %p11218, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11219, ptr %slot1927, align 8
  %v11220 = load i64, ptr %slot37, align 8
  %p11221 = inttoptr i64 %v11220 to ptr
  %ld11222 = load i32, ptr %p11221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11222, ptr %slot1928, align 8
  %v11223 = load i32, ptr %slot1928, align 8
  %op11224 = and i32 %v11223, 24
  store i32 %op11224, ptr %slot1928, align 8
  %v11225 = load i32, ptr %slot1928, align 8
  %cmp11226 = icmp eq i32 %v11225, 0
  %cv11227 = zext i1 %cmp11226 to i32
  store i32 %cv11227, ptr %slot1929, align 8
  %v11228 = load i32, ptr %slot1927, align 8
  %v11229 = load i32, ptr %slot1929, align 8
  %op11230 = and i32 %v11228, %v11229
  store i32 %op11230, ptr %slot1930, align 8
  %v11231 = load i32, ptr %slot1930, align 8
  %cv11232 = zext i32 %v11231 to i64
  %cond11233 = icmp ne i64 %cv11232, 0
  br i1 %cond11233, label %bb_rctake2423, label %bb_rccopy2423
bb_rctake2423:
  %v11234 = load i64, ptr %slot65, align 8
  store i64 %v11234, ptr %slot1931, align 8
  %v11235 = load i64, ptr %slot111, align 8
  store i64 %v11235, ptr %slot1932, align 8
  %v11236 = load i64, ptr %slot1926, align 8
  %v11237 = load i64, ptr %slot1931, align 8
  %op11238 = sub i64 %v11236, %v11237
  store i64 %op11238, ptr %slot1933, align 8
  %v11239 = load i64, ptr %slot1931, align 8
  %v11240 = load i64, ptr %slot1926, align 8
  %op11241 = sub i64 %v11239, %v11240
  store i64 %op11241, ptr %slot1934, align 8
  %v11242 = load i64, ptr %slot1933, align 8
  %cmp11243 = icmp ult i64 %v11242, 16
  %cv11244 = zext i1 %cmp11243 to i32
  store i32 %cv11244, ptr %slot1935, align 8
  %v11245 = load i64, ptr %slot1934, align 8
  %cmp11246 = icmp ult i64 %v11245, 16
  %cv11247 = zext i1 %cmp11246 to i32
  store i32 %cv11247, ptr %slot1936, align 8
  %v11248 = load i32, ptr %slot1935, align 8
  %v11249 = load i32, ptr %slot1936, align 8
  %op11250 = or i32 %v11248, %v11249
  store i32 %op11250, ptr %slot1937, align 8
  %v11251 = load i32, ptr %slot1937, align 8
  %cv11252 = zext i32 %v11251 to i64
  %cond11253 = icmp ne i64 %cv11252, 0
  br i1 %cond11253, label %bb_rcmoveslow2432, label %bb_rcmovecheck2432
bb_rcmovecheck2432:
  %v11254 = load i64, ptr %slot1926, align 8
  %op11255 = add i64 %v11254, 0
  store i64 %op11255, ptr %slot1938, align 8
  %v11256 = load i64, ptr %slot1938, align 8
  %p11257 = inttoptr i64 %v11256 to ptr
  %ld11258 = load i64, ptr %p11257, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11258, ptr %slot1939, align 8
  %v11259 = load i64, ptr %slot1939, align 8
  %cmp11260 = icmp ne i64 %v11259, 0
  %cv11261 = zext i1 %cmp11260 to i32
  store i32 %cv11261, ptr %slot1940, align 8
  %v11262 = load i32, ptr %slot1940, align 8
  %cv11263 = zext i32 %v11262 to i64
  %cond11264 = icmp ne i64 %cv11263, 0
  br i1 %cond11264, label %bb_rcmoveheader2440, label %bb_rcmovenext2440
bb_rcmoveheader2440:
  %v11265 = load i64, ptr %slot1939, align 8
  %op11266 = sub i64 %v11265, 16
  store i64 %op11266, ptr %slot1941, align 8
  %v11267 = load i64, ptr %slot1939, align 8
  %p11268 = inttoptr i64 %v11267 to ptr
  %rgep11269 = getelementptr i8, ptr %p11268, i64 -16
  %ld11270 = load i64, ptr %rgep11269, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11270, ptr %slot1942, align 8
  %v11271 = load i64, ptr %slot1942, align 8
  %op11272 = and i64 %v11271, 5764607523034234881
  store i64 %op11272, ptr %slot1943, align 8
  %v11273 = load i64, ptr %slot1943, align 8
  %cmp11274 = icmp ne i64 %v11273, 0
  %cv11275 = zext i1 %cmp11274 to i32
  store i32 %cv11275, ptr %slot1944, align 8
  %v11276 = load i32, ptr %slot1944, align 8
  %cv11277 = zext i32 %v11276 to i64
  %cond11278 = icmp ne i64 %cv11277, 0
  br i1 %cond11278, label %bb_rcmoveslow2432, label %bb_rcmovenext2440
bb_rcmovenext2440:
  %v11279 = load i64, ptr %slot1926, align 8
  %v11280 = load i64, ptr %slot1931, align 8
  %p11281 = inttoptr i64 %v11279 to ptr
  %p11282 = inttoptr i64 %v11280 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11282, ptr %p11281, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v11283 = load i64, ptr %slot1926, align 8
  %p11284 = inttoptr i64 %v11283 to ptr
  store i64 0, ptr %p11284, align 8, !alias.scope !3, !noalias !4
  %v11285 = load i64, ptr %slot1926, align 8
  %op11286 = add i64 %v11285, 8
  store i64 %op11286, ptr %slot1945, align 8
  %v11287 = load i64, ptr %slot1945, align 8
  %p11288 = inttoptr i64 %v11287 to ptr
  store i64 0, ptr %p11288, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2432
bb_rcmoveslow2432:
  %v11289 = load i64, ptr %slot110, align 8
  %v11290 = load i64, ptr %slot1931, align 8
  %v11291 = load i64, ptr %slot1926, align 8
  %v11292 = load i64, ptr %slot1932, align 8
  %cv11293 = trunc i64 %v11292 to i32
  %call11294 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v11289, i64 %v11290, i64 %v11291, i32 %cv11293) nomerge, !dbg !170
  store i32 %call11294, ptr %slot1946, align 8
  %v11295 = load i32, ptr %slot1946, align 8
  %cv11296 = zext i32 %v11295 to i64
  %cond11297 = icmp ne i64 %cv11296, 0
  br i1 %cond11297, label %bb_rcsuccess2448, label %bb_rcfailure2448
bb_rcfailure2448:
  %v11298 = load i64, ptr %slot110, align 8
  %p11299 = inttoptr i64 %v11298 to ptr
  %call11300 = call i32 @myl_rc_take_failure(ptr %p11299) nomerge, !dbg !170
  store i32 %call11300, ptr %slot1947, align 8
  %v11301 = load i64, ptr %slot1, align 8
  %p11302 = inttoptr i64 %v11301 to ptr
  %v11303 = load i32, ptr %slot1947, align 8
  %call11304 = call i32 @myl_qbe_rc_status(ptr %p11302, i32 %v11303) nomerge, !dbg !170
  store i32 %call11304, ptr %slot1948, align 8
  br label %bb_failure
bb_rcsuccess2448:
  br label %bb_rcmoved2432
bb_rcmoved2432:
  %v11305 = load i64, ptr %slot36, align 8
  %p11306 = inttoptr i64 %v11305 to ptr
  store i32 0, ptr %p11306, align 4, !alias.scope !3, !noalias !4
  %v11307 = load i64, ptr %slot47, align 8
  %p11308 = inttoptr i64 %v11307 to ptr
  store i32 2, ptr %p11308, align 4, !alias.scope !3, !noalias !4
  %v11309 = load i64, ptr %slot46, align 8
  %p11310 = inttoptr i64 %v11309 to ptr
  store i32 1, ptr %p11310, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2423
bb_rccopy2423:
  %v11311 = load i64, ptr %slot65, align 8
  store i64 %v11311, ptr %slot1949, align 8
  %v11312 = load i64, ptr %slot111, align 8
  store i64 %v11312, ptr %slot1950, align 8
  %v11313 = load i64, ptr %slot110, align 8
  %v11314 = load i64, ptr %slot1949, align 8
  %v11315 = load i64, ptr %slot1926, align 8
  %v11316 = load i64, ptr %slot1950, align 8
  %cv11317 = trunc i64 %v11316 to i32
  %call11318 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v11313, i64 %v11314, i64 %v11315, i32 %cv11317) nomerge, !dbg !170
  store i32 %call11318, ptr %slot1951, align 8
  %v11319 = load i32, ptr %slot1951, align 8
  %cv11320 = zext i32 %v11319 to i64
  %cond11321 = icmp ne i64 %cv11320, 0
  br i1 %cond11321, label %bb_rcsuccess2457, label %bb_rcfailure2457
bb_rcfailure2457:
  %v11322 = load i64, ptr %slot110, align 8
  %p11323 = inttoptr i64 %v11322 to ptr
  %call11324 = call i32 @myl_rc_take_failure(ptr %p11323) nomerge, !dbg !170
  store i32 %call11324, ptr %slot1952, align 8
  %v11325 = load i64, ptr %slot1, align 8
  %p11326 = inttoptr i64 %v11325 to ptr
  %v11327 = load i32, ptr %slot1952, align 8
  %call11328 = call i32 @myl_qbe_rc_status(ptr %p11326, i32 %v11327) nomerge, !dbg !170
  store i32 %call11328, ptr %slot1953, align 8
  br label %bb_failure
bb_rcsuccess2457:
  %v11329 = load i64, ptr %slot47, align 8
  %p11330 = inttoptr i64 %v11329 to ptr
  store i32 2, ptr %p11330, align 4, !alias.scope !3, !noalias !4
  %v11331 = load i64, ptr %slot46, align 8
  %p11332 = inttoptr i64 %v11331 to ptr
  store i32 1, ptr %p11332, align 4, !alias.scope !3, !noalias !4
  %v11333 = load i64, ptr %slot36, align 8
  %p11334 = inttoptr i64 %v11333 to ptr
  %ld11335 = load i32, ptr %p11334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11335, ptr %slot1954, align 8
  %v11336 = load i32, ptr %slot1954, align 8
  %cv11337 = zext i32 %v11336 to i64
  %cond11338 = icmp ne i64 %cv11337, 0
  br i1 %cond11338, label %bb_rcslotdrop2464, label %bb_rcslotdone2464
bb_rcslotdrop2464:
  %v11339 = load i64, ptr %slot36, align 8
  %p11340 = inttoptr i64 %v11339 to ptr
  store i32 0, ptr %p11340, align 4, !alias.scope !3, !noalias !4
  %v11341 = load i64, ptr %slot53, align 8
  store i64 %v11341, ptr %slot1955, align 8
  %v11342 = load i64, ptr %slot37, align 8
  %p11343 = inttoptr i64 %v11342 to ptr
  %ld11344 = load i32, ptr %p11343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11344, ptr %slot1956, align 8
  %v11345 = load i32, ptr %slot1956, align 8
  %op11346 = and i32 %v11345, 28
  store i32 %op11346, ptr %slot1957, align 8
  %v11347 = load i32, ptr %slot1957, align 8
  %cv11348 = zext i32 %v11347 to i64
  %cond11349 = icmp ne i64 %cv11348, 0
  br i1 %cond11349, label %bb_rcslotrole2464, label %bb_rcslotowner2464
bb_rcslotrole2464:
  %v11350 = load i64, ptr %slot110, align 8
  store i64 %v11350, ptr %slot1958, align 8
  %v11351 = load i64, ptr %slot1958, align 8
  %v11352 = load i64, ptr %slot1955, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v11351, i64 %v11352) nomerge, !dbg !170
  br label %bb_rcslotdone2464
bb_rcslotowner2464:
  %v11353 = load i64, ptr %slot110, align 8
  store i64 %v11353, ptr %slot1959, align 8
  %v11354 = load i64, ptr %slot1959, align 8
  %v11355 = load i64, ptr %slot1955, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v11354, i64 %v11355) nomerge, !dbg !170
  br label %bb_rcslotdone2464
bb_rcslotdone2464:
  br label %bb_rcprepared2423
bb_rcprepared2423:
  %v11356 = load i64, ptr %slot65, align 8
  store i64 %v11356, ptr %slot1960, align 8
  %v11357 = load i64, ptr %slot1960, align 8
  %v11358 = load i64, ptr %slot1925, align 8
  %p11359 = inttoptr i64 %v11357 to ptr
  %p11360 = inttoptr i64 %v11358 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11360, ptr %p11359, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v11361 = load i64, ptr %slot46, align 8
  %p11362 = inttoptr i64 %v11361 to ptr
  store i32 0, ptr %p11362, align 4, !alias.scope !3, !noalias !4
  %v11363 = load i64, ptr %slot85, align 8
  store i64 %v11363, ptr %slot1961, align 8
  %v11364 = load i64, ptr %slot1687, align 8
  %p11366 = inttoptr i64 %v11364 to ptr
  %gep11367 = getelementptr i8, ptr %p11366, i64 64
  %op11365 = ptrtoint ptr %gep11367 to i64
  store i64 %op11365, ptr %slot1962, align 8
  %v11368 = load i64, ptr %slot1961, align 8
  %p11369 = inttoptr i64 %v11368 to ptr
  %ld11370 = load i64, ptr %p11369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11370, ptr %slot1963, align 8
  %v11371 = load i64, ptr %slot1963, align 8
  %v11372 = load i64, ptr %slot1962, align 8
  %p11373 = inttoptr i64 %v11372 to ptr
  store i64 %v11371, ptr %p11373, align 8, !alias.scope !3, !noalias !4
  %v11374 = load i64, ptr %slot86, align 8
  store i64 %v11374, ptr %slot1964, align 8
  %v11375 = load i64, ptr %slot1687, align 8
  %p11377 = inttoptr i64 %v11375 to ptr
  %gep11378 = getelementptr i8, ptr %p11377, i64 72
  %op11376 = ptrtoint ptr %gep11378 to i64
  store i64 %op11376, ptr %slot1965, align 8
  %v11379 = load i64, ptr %slot1964, align 8
  %p11380 = inttoptr i64 %v11379 to ptr
  %ld11381 = load i8, ptr %p11380, align 1, !alias.scope !3, !noalias !4
  %ext11382 = zext i8 %ld11381 to i64
  store i64 %ext11382, ptr %slot1966, align 8
  %v11383 = load i64, ptr %slot1966, align 8
  %cv11384 = trunc i64 %v11383 to i8
  %v11385 = load i64, ptr %slot1965, align 8
  %p11386 = inttoptr i64 %v11385 to ptr
  store i8 %cv11384, ptr %p11386, align 1, !alias.scope !3, !noalias !4
  %v11387 = load i64, ptr %slot87, align 8
  store i64 %v11387, ptr %slot1967, align 8
  %v11388 = load i64, ptr %slot1687, align 8
  %p11390 = inttoptr i64 %v11388 to ptr
  %gep11391 = getelementptr i8, ptr %p11390, i64 80
  %op11389 = ptrtoint ptr %gep11391 to i64
  store i64 %op11389, ptr %slot1968, align 8
  %v11392 = load i64, ptr %slot1967, align 8
  %p11393 = inttoptr i64 %v11392 to ptr
  %ld11394 = load i64, ptr %p11393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11394, ptr %slot1969, align 8
  %v11395 = load i64, ptr %slot1969, align 8
  %v11396 = load i64, ptr %slot1968, align 8
  %p11397 = inttoptr i64 %v11396 to ptr
  store i64 %v11395, ptr %p11397, align 8, !alias.scope !3, !noalias !4
  %v11398 = load i64, ptr %slot88, align 8
  store i64 %v11398, ptr %slot1970, align 8
  %v11399 = load i64, ptr %slot1687, align 8
  %p11401 = inttoptr i64 %v11399 to ptr
  %gep11402 = getelementptr i8, ptr %p11401, i64 88
  %op11400 = ptrtoint ptr %gep11402 to i64
  store i64 %op11400, ptr %slot1971, align 8
  %v11403 = load i64, ptr %slot1970, align 8
  %p11404 = inttoptr i64 %v11403 to ptr
  %ld11405 = load i64, ptr %p11404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11405, ptr %slot1972, align 8
  %v11406 = load i64, ptr %slot1972, align 8
  %v11407 = load i64, ptr %slot1971, align 8
  %p11408 = inttoptr i64 %v11407 to ptr
  store i64 %v11406, ptr %p11408, align 8, !alias.scope !3, !noalias !4
  %v11409 = load i64, ptr %slot89, align 8
  store i64 %v11409, ptr %slot1973, align 8
  %v11410 = load i64, ptr %slot1687, align 8
  %p11412 = inttoptr i64 %v11410 to ptr
  %gep11413 = getelementptr i8, ptr %p11412, i64 96
  %op11411 = ptrtoint ptr %gep11413 to i64
  store i64 %op11411, ptr %slot1974, align 8
  %v11414 = load i64, ptr %slot1973, align 8
  %p11415 = inttoptr i64 %v11414 to ptr
  %ld11416 = load i64, ptr %p11415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11416, ptr %slot1975, align 8
  %v11417 = load i64, ptr %slot1975, align 8
  %v11418 = load i64, ptr %slot1974, align 8
  %p11419 = inttoptr i64 %v11418 to ptr
  store i64 %v11417, ptr %p11419, align 8, !alias.scope !3, !noalias !4
  %v11420 = load i64, ptr %slot90, align 8
  store i64 %v11420, ptr %slot1976, align 8
  %v11421 = load i64, ptr %slot1687, align 8
  %p11423 = inttoptr i64 %v11421 to ptr
  %gep11424 = getelementptr i8, ptr %p11423, i64 104
  %op11422 = ptrtoint ptr %gep11424 to i64
  store i64 %op11422, ptr %slot1977, align 8
  %v11425 = load i64, ptr %slot1976, align 8
  %p11426 = inttoptr i64 %v11425 to ptr
  %ld11427 = load i64, ptr %p11426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11427, ptr %slot1978, align 8
  %v11428 = load i64, ptr %slot1978, align 8
  %v11429 = load i64, ptr %slot1977, align 8
  %p11430 = inttoptr i64 %v11429 to ptr
  store i64 %v11428, ptr %p11430, align 8, !alias.scope !3, !noalias !4
  %v11431 = load i64, ptr %slot91, align 8
  store i64 %v11431, ptr %slot1979, align 8
  %v11432 = load i64, ptr %slot1687, align 8
  %p11434 = inttoptr i64 %v11432 to ptr
  %gep11435 = getelementptr i8, ptr %p11434, i64 112
  %op11433 = ptrtoint ptr %gep11435 to i64
  store i64 %op11433, ptr %slot1980, align 8
  %v11436 = load i64, ptr %slot1979, align 8
  %p11437 = inttoptr i64 %v11436 to ptr
  %ld11438 = load i64, ptr %p11437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11438, ptr %slot1981, align 8
  %v11439 = load i64, ptr %slot1981, align 8
  %v11440 = load i64, ptr %slot1980, align 8
  %p11441 = inttoptr i64 %v11440 to ptr
  store i64 %v11439, ptr %p11441, align 8, !alias.scope !3, !noalias !4
  %v11442 = load i64, ptr %slot92, align 8
  %p11443 = inttoptr i64 %v11442 to ptr
  %ld11444 = load i64, ptr %p11443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11444, ptr %slot1982, align 8
  %v11445 = load i64, ptr %slot1982, align 8
  %v11446 = load i64, ptr %slot60, align 8
  %p11447 = inttoptr i64 %v11446 to ptr
  store i64 %v11445, ptr %p11447, align 8, !alias.scope !3, !noalias !4
  %v11448 = load i64, ptr %slot60, align 8
  store i64 %v11448, ptr %slot1983, align 8
  %v11449 = load i64, ptr %slot1687, align 8
  %p11451 = inttoptr i64 %v11449 to ptr
  %gep11452 = getelementptr i8, ptr %p11451, i64 120
  %op11450 = ptrtoint ptr %gep11452 to i64
  store i64 %op11450, ptr %slot1984, align 8
  %v11453 = load i64, ptr %slot92, align 8
  %p11454 = inttoptr i64 %v11453 to ptr
  %ld11455 = load i64, ptr %p11454, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11455, ptr %slot1985, align 8
  %v11456 = load i64, ptr %slot1985, align 8
  %v11457 = load i64, ptr %slot60, align 8
  %p11458 = inttoptr i64 %v11457 to ptr
  store i64 %v11456, ptr %p11458, align 8, !alias.scope !3, !noalias !4
  %v11459 = load i64, ptr %slot60, align 8
  store i64 %v11459, ptr %slot1986, align 8
  store i32 0, ptr %slot1987, align 8
  %v11460 = load i64, ptr %slot38, align 8
  %p11461 = inttoptr i64 %v11460 to ptr
  %ld11462 = load i32, ptr %p11461, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11462, ptr %slot1988, align 8
  %v11463 = load i32, ptr %slot1988, align 8
  %op11464 = and i32 %v11463, 24
  store i32 %op11464, ptr %slot1988, align 8
  %v11465 = load i32, ptr %slot1988, align 8
  %cmp11466 = icmp eq i32 %v11465, 0
  %cv11467 = zext i1 %cmp11466 to i32
  store i32 %cv11467, ptr %slot1989, align 8
  %v11468 = load i32, ptr %slot1987, align 8
  %v11469 = load i32, ptr %slot1989, align 8
  %op11470 = and i32 %v11468, %v11469
  store i32 %op11470, ptr %slot1990, align 8
  %v11471 = load i32, ptr %slot1990, align 8
  %cv11472 = zext i32 %v11471 to i64
  %cond11473 = icmp ne i64 %cv11472, 0
  br i1 %cond11473, label %bb_rctake2499, label %bb_rccopy2499
bb_rctake2499:
  %v11474 = load i64, ptr %slot65, align 8
  store i64 %v11474, ptr %slot1991, align 8
  %v11475 = load i64, ptr %slot111, align 8
  store i64 %v11475, ptr %slot1992, align 8
  %v11476 = load i64, ptr %slot1986, align 8
  %v11477 = load i64, ptr %slot1991, align 8
  %op11478 = sub i64 %v11476, %v11477
  store i64 %op11478, ptr %slot1993, align 8
  %v11479 = load i64, ptr %slot1991, align 8
  %v11480 = load i64, ptr %slot1986, align 8
  %op11481 = sub i64 %v11479, %v11480
  store i64 %op11481, ptr %slot1994, align 8
  %v11482 = load i64, ptr %slot1993, align 8
  %cmp11483 = icmp ult i64 %v11482, 8
  %cv11484 = zext i1 %cmp11483 to i32
  store i32 %cv11484, ptr %slot1995, align 8
  %v11485 = load i64, ptr %slot1994, align 8
  %cmp11486 = icmp ult i64 %v11485, 8
  %cv11487 = zext i1 %cmp11486 to i32
  store i32 %cv11487, ptr %slot1996, align 8
  %v11488 = load i32, ptr %slot1995, align 8
  %v11489 = load i32, ptr %slot1996, align 8
  %op11490 = or i32 %v11488, %v11489
  store i32 %op11490, ptr %slot1997, align 8
  %v11491 = load i32, ptr %slot1997, align 8
  %cv11492 = zext i32 %v11491 to i64
  %cond11493 = icmp ne i64 %cv11492, 0
  br i1 %cond11493, label %bb_rcmoveslow2508, label %bb_rcmovecheck2508
bb_rcmovecheck2508:
  %v11494 = load i64, ptr %slot1986, align 8
  %p11496 = inttoptr i64 %v11494 to ptr
  %gep11497 = getelementptr i8, ptr %p11496, i64 0
  %op11495 = ptrtoint ptr %gep11497 to i64
  store i64 %op11495, ptr %slot1998, align 8
  %v11498 = load i64, ptr %slot1998, align 8
  %p11499 = inttoptr i64 %v11498 to ptr
  %ld11500 = load i64, ptr %p11499, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11500, ptr %slot1999, align 8
  %v11501 = load i64, ptr %slot1999, align 8
  %cmp11502 = icmp ne i64 %v11501, 0
  %cv11503 = zext i1 %cmp11502 to i32
  store i32 %cv11503, ptr %slot2000, align 8
  %v11504 = load i32, ptr %slot2000, align 8
  %cv11505 = zext i32 %v11504 to i64
  %cond11506 = icmp ne i64 %cv11505, 0
  br i1 %cond11506, label %bb_rcmoveheader2516, label %bb_rcmovenext2516
bb_rcmoveheader2516:
  %v11507 = load i64, ptr %slot1999, align 8
  %op11508 = sub i64 %v11507, 16
  store i64 %op11508, ptr %slot2001, align 8
  %v11509 = load i64, ptr %slot1999, align 8
  %p11510 = inttoptr i64 %v11509 to ptr
  %rgep11511 = getelementptr i8, ptr %p11510, i64 -16
  %ld11512 = load i64, ptr %rgep11511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11512, ptr %slot2002, align 8
  %v11513 = load i64, ptr %slot2002, align 8
  %op11514 = and i64 %v11513, 5764607523034234881
  store i64 %op11514, ptr %slot2003, align 8
  %v11515 = load i64, ptr %slot2003, align 8
  %cmp11516 = icmp ne i64 %v11515, 0
  %cv11517 = zext i1 %cmp11516 to i32
  store i32 %cv11517, ptr %slot2004, align 8
  %v11518 = load i32, ptr %slot2004, align 8
  %cv11519 = zext i32 %v11518 to i64
  %cond11520 = icmp ne i64 %cv11519, 0
  br i1 %cond11520, label %bb_rcmoveslow2508, label %bb_rcmovenext2516
bb_rcmovenext2516:
  %v11521 = load i64, ptr %slot1986, align 8
  %v11522 = load i64, ptr %slot1991, align 8
  %p11523 = inttoptr i64 %v11521 to ptr
  %p11524 = inttoptr i64 %v11522 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11524, ptr %p11523, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11525 = load i64, ptr %slot1986, align 8
  %p11526 = inttoptr i64 %v11525 to ptr
  store i64 0, ptr %p11526, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2508
bb_rcmoveslow2508:
  %v11527 = load i64, ptr %slot110, align 8
  %v11528 = load i64, ptr %slot1991, align 8
  %v11529 = load i64, ptr %slot1986, align 8
  %v11530 = load i64, ptr %slot1992, align 8
  %cv11531 = trunc i64 %v11530 to i32
  %call11532 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64 %v11527, i64 %v11528, i64 %v11529, i32 %cv11531) nomerge, !dbg !170
  store i32 %call11532, ptr %slot2005, align 8
  %v11533 = load i32, ptr %slot2005, align 8
  %cv11534 = zext i32 %v11533 to i64
  %cond11535 = icmp ne i64 %cv11534, 0
  br i1 %cond11535, label %bb_rcsuccess2523, label %bb_rcfailure2523
bb_rcfailure2523:
  %v11536 = load i64, ptr %slot110, align 8
  %p11537 = inttoptr i64 %v11536 to ptr
  %call11538 = call i32 @myl_rc_take_failure(ptr %p11537) nomerge, !dbg !170
  store i32 %call11538, ptr %slot2006, align 8
  %v11539 = load i64, ptr %slot1, align 8
  %p11540 = inttoptr i64 %v11539 to ptr
  %v11541 = load i32, ptr %slot2006, align 8
  %call11542 = call i32 @myl_qbe_rc_status(ptr %p11540, i32 %v11541) nomerge, !dbg !170
  store i32 %call11542, ptr %slot2007, align 8
  br label %bb_failure
bb_rcsuccess2523:
  br label %bb_rcmoved2508
bb_rcmoved2508:
  %v11543 = load i64, ptr %slot47, align 8
  %p11544 = inttoptr i64 %v11543 to ptr
  store i32 2, ptr %p11544, align 4, !alias.scope !3, !noalias !4
  %v11545 = load i64, ptr %slot46, align 8
  %p11546 = inttoptr i64 %v11545 to ptr
  store i32 1, ptr %p11546, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2499
bb_rccopy2499:
  %v11547 = load i64, ptr %slot65, align 8
  store i64 %v11547, ptr %slot2008, align 8
  %v11548 = load i64, ptr %slot111, align 8
  store i64 %v11548, ptr %slot2009, align 8
  %v11549 = load i64, ptr %slot1986, align 8
  %p11550 = inttoptr i64 %v11549 to ptr
  %ld11551 = load i64, ptr %p11550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11551, ptr %slot2010, align 8
  %v11552 = load i64, ptr %slot2010, align 8
  %cmp11553 = icmp ne i64 %v11552, 0
  %cv11554 = zext i1 %cmp11553 to i32
  store i32 %cv11554, ptr %slot2011, align 8
  %v11555 = load i32, ptr %slot2011, align 8
  %cv11556 = zext i32 %v11555 to i64
  %cond11557 = icmp ne i64 %cv11556, 0
  br i1 %cond11557, label %bb_rcgnn2532, label %bb_rcgplain2532
bb_rcgnn2532:
  %v11558 = load i64, ptr %slot2010, align 8
  %op11559 = sub i64 %v11558, 16
  store i64 %op11559, ptr %slot2012, align 8
  %v11560 = load i64, ptr %slot2010, align 8
  %p11561 = inttoptr i64 %v11560 to ptr
  %rgep11562 = getelementptr i8, ptr %p11561, i64 -16
  %ld11563 = load i64, ptr %rgep11562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11563, ptr %slot2013, align 8
  %v11564 = load i64, ptr %slot2013, align 8
  %op11565 = and i64 %v11564, 4611686018427387906
  store i64 %op11565, ptr %slot2014, align 8
  %v11566 = load i64, ptr %slot2014, align 8
  %cmp11567 = icmp ne i64 %v11566, 0
  %cv11568 = zext i1 %cmp11567 to i32
  store i32 %cv11568, ptr %slot2015, align 8
  %v11569 = load i32, ptr %slot2015, align 8
  %cv11570 = zext i32 %v11569 to i64
  %cond11571 = icmp ne i64 %cv11570, 0
  br i1 %cond11571, label %bb_rcgspecial2532, label %bb_rcginc2532
bb_rcginc2532:
  %v11572 = load i64, ptr %slot2010, align 8
  %op11573 = sub i64 %v11572, 32
  store i64 %op11573, ptr %slot2016, align 8
  %v11574 = load i64, ptr %slot2010, align 8
  %p11575 = inttoptr i64 %v11574 to ptr
  %rgep11576 = getelementptr i8, ptr %p11575, i64 -32
  %ld11577 = load i64, ptr %rgep11576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11577, ptr %slot2017, align 8
  %v11578 = load i64, ptr %slot2017, align 8
  %op11579 = add i64 %v11578, 1
  store i64 %op11579, ptr %slot2018, align 8
  %v11580 = load i64, ptr %slot2018, align 8
  %cmp11581 = icmp eq i64 %v11580, 0
  %cv11582 = zext i1 %cmp11581 to i32
  store i32 %cv11582, ptr %slot2019, align 8
  %v11583 = load i32, ptr %slot2019, align 8
  %cv11584 = zext i32 %v11583 to i64
  %cond11585 = icmp ne i64 %cv11584, 0
  br i1 %cond11585, label %bb_rcglimit2532, label %bb_rcgcapacity2532
bb_rcglimit2532:
  %v11586 = load i64, ptr %slot1, align 8
  %p11587 = inttoptr i64 %v11586 to ptr
  %call11588 = call i32 @myl_qbe_rc_status(ptr %p11587, i32 2) nomerge, !dbg !170
  store i32 %call11588, ptr %slot2020, align 8
  br label %bb_failure
bb_rcgcapacity2532:
  %v11589 = load i64, ptr %slot2018, align 8
  %v11590 = load i64, ptr %slot2010, align 8
  %p11591 = inttoptr i64 %v11590 to ptr
  %rgep11592 = getelementptr i8, ptr %p11591, i64 -32
  store i64 %v11589, ptr %rgep11592, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2532
bb_rcgspecial2532:
  %v11593 = load i64, ptr %slot2013, align 8
  %op11594 = and i64 %v11593, 4611686018427387904
  store i64 %op11594, ptr %slot2021, align 8
  %v11595 = load i64, ptr %slot2021, align 8
  %cmp11596 = icmp ne i64 %v11595, 0
  %cv11597 = zext i1 %cmp11596 to i32
  store i32 %cv11597, ptr %slot2022, align 8
  %v11598 = load i32, ptr %slot2022, align 8
  %cv11599 = zext i32 %v11598 to i64
  %cond11600 = icmp ne i64 %cv11599, 0
  br i1 %cond11600, label %bb_rcgslow2532, label %bb_rcgplain2532
bb_rcgslow2532:
  %v11601 = load i64, ptr %slot110, align 8
  %v11602 = load i64, ptr %slot2008, align 8
  %v11603 = load i64, ptr %slot1986, align 8
  %v11604 = load i64, ptr %slot2009, align 8
  %cv11605 = trunc i64 %v11604 to i32
  %call11606 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_retain(i64 %v11601, i64 %v11602, i64 %v11603, i32 %cv11605) nomerge, !dbg !170
  store i32 %call11606, ptr %slot2023, align 8
  %v11607 = load i32, ptr %slot2023, align 8
  %cv11608 = zext i32 %v11607 to i64
  %cond11609 = icmp ne i64 %cv11608, 0
  br i1 %cond11609, label %bb_rcsuccess2546, label %bb_rcfailure2546
bb_rcfailure2546:
  %v11610 = load i64, ptr %slot110, align 8
  %p11611 = inttoptr i64 %v11610 to ptr
  %call11612 = call i32 @myl_rc_take_failure(ptr %p11611) nomerge, !dbg !170
  store i32 %call11612, ptr %slot2024, align 8
  %v11613 = load i64, ptr %slot1, align 8
  %p11614 = inttoptr i64 %v11613 to ptr
  %v11615 = load i32, ptr %slot2024, align 8
  %call11616 = call i32 @myl_qbe_rc_status(ptr %p11614, i32 %v11615) nomerge, !dbg !170
  store i32 %call11616, ptr %slot2025, align 8
  br label %bb_failure
bb_rcsuccess2546:
  br label %bb_rcgdone2532
bb_rcgplain2532:
  %v11617 = load i64, ptr %slot2010, align 8
  %v11618 = load i64, ptr %slot2008, align 8
  %p11619 = inttoptr i64 %v11618 to ptr
  store i64 %v11617, ptr %p11619, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2532
bb_rcgdone2532:
  %v11620 = load i64, ptr %slot47, align 8
  %p11621 = inttoptr i64 %v11620 to ptr
  store i32 2, ptr %p11621, align 4, !alias.scope !3, !noalias !4
  %v11622 = load i64, ptr %slot46, align 8
  %p11623 = inttoptr i64 %v11622 to ptr
  store i32 1, ptr %p11623, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2499
bb_rcprepared2499:
  %v11624 = load i64, ptr %slot65, align 8
  store i64 %v11624, ptr %slot2026, align 8
  %v11625 = load i64, ptr %slot2026, align 8
  %v11626 = load i64, ptr %slot1984, align 8
  %p11627 = inttoptr i64 %v11625 to ptr
  %p11628 = inttoptr i64 %v11626 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11628, ptr %p11627, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11629 = load i64, ptr %slot46, align 8
  %p11630 = inttoptr i64 %v11629 to ptr
  store i32 0, ptr %p11630, align 4, !alias.scope !3, !noalias !4
  %v11631 = load i64, ptr %slot93, align 8
  store i64 %v11631, ptr %slot2027, align 8
  %v11632 = load i64, ptr %slot1687, align 8
  %p11634 = inttoptr i64 %v11632 to ptr
  %gep11635 = getelementptr i8, ptr %p11634, i64 128
  %op11633 = ptrtoint ptr %gep11635 to i64
  store i64 %op11633, ptr %slot2028, align 8
  %v11636 = load i64, ptr %slot2027, align 8
  %p11637 = inttoptr i64 %v11636 to ptr
  %ld11638 = load i64, ptr %p11637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11638, ptr %slot2029, align 8
  %v11639 = load i64, ptr %slot2029, align 8
  %v11640 = load i64, ptr %slot2028, align 8
  %p11641 = inttoptr i64 %v11640 to ptr
  store i64 %v11639, ptr %p11641, align 8, !alias.scope !3, !noalias !4
  %v11642 = load i64, ptr %slot94, align 8
  %p11643 = inttoptr i64 %v11642 to ptr
  %ld11644 = load i64, ptr %p11643, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11644, ptr %slot2030, align 8
  %v11645 = load i64, ptr %slot2030, align 8
  %v11646 = load i64, ptr %slot61, align 8
  %p11647 = inttoptr i64 %v11646 to ptr
  store i64 %v11645, ptr %p11647, align 8, !alias.scope !3, !noalias !4
  %v11648 = load i64, ptr %slot61, align 8
  store i64 %v11648, ptr %slot2031, align 8
  %v11649 = load i64, ptr %slot1687, align 8
  %p11651 = inttoptr i64 %v11649 to ptr
  %gep11652 = getelementptr i8, ptr %p11651, i64 136
  %op11650 = ptrtoint ptr %gep11652 to i64
  store i64 %op11650, ptr %slot2032, align 8
  %v11653 = load i64, ptr %slot94, align 8
  %p11654 = inttoptr i64 %v11653 to ptr
  %ld11655 = load i64, ptr %p11654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11655, ptr %slot2033, align 8
  %v11656 = load i64, ptr %slot2033, align 8
  %v11657 = load i64, ptr %slot61, align 8
  %p11658 = inttoptr i64 %v11657 to ptr
  store i64 %v11656, ptr %p11658, align 8, !alias.scope !3, !noalias !4
  %v11659 = load i64, ptr %slot61, align 8
  store i64 %v11659, ptr %slot2034, align 8
  store i32 0, ptr %slot2035, align 8
  %v11660 = load i64, ptr %slot39, align 8
  %p11661 = inttoptr i64 %v11660 to ptr
  %ld11662 = load i32, ptr %p11661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11662, ptr %slot2036, align 8
  %v11663 = load i32, ptr %slot2036, align 8
  %op11664 = and i32 %v11663, 24
  store i32 %op11664, ptr %slot2036, align 8
  %v11665 = load i32, ptr %slot2036, align 8
  %cmp11666 = icmp eq i32 %v11665, 0
  %cv11667 = zext i1 %cmp11666 to i32
  store i32 %cv11667, ptr %slot2037, align 8
  %v11668 = load i32, ptr %slot2035, align 8
  %v11669 = load i32, ptr %slot2037, align 8
  %op11670 = and i32 %v11668, %v11669
  store i32 %op11670, ptr %slot2038, align 8
  %v11671 = load i32, ptr %slot2038, align 8
  %cv11672 = zext i32 %v11671 to i64
  %cond11673 = icmp ne i64 %cv11672, 0
  br i1 %cond11673, label %bb_rctake2598, label %bb_rccopy2598
bb_rctake2598:
  %v11674 = load i64, ptr %slot65, align 8
  store i64 %v11674, ptr %slot2039, align 8
  %v11675 = load i64, ptr %slot111, align 8
  store i64 %v11675, ptr %slot2040, align 8
  %v11676 = load i64, ptr %slot2034, align 8
  %v11677 = load i64, ptr %slot2039, align 8
  %op11678 = sub i64 %v11676, %v11677
  store i64 %op11678, ptr %slot2041, align 8
  %v11679 = load i64, ptr %slot2039, align 8
  %v11680 = load i64, ptr %slot2034, align 8
  %op11681 = sub i64 %v11679, %v11680
  store i64 %op11681, ptr %slot2042, align 8
  %v11682 = load i64, ptr %slot2041, align 8
  %cmp11683 = icmp ult i64 %v11682, 8
  %cv11684 = zext i1 %cmp11683 to i32
  store i32 %cv11684, ptr %slot2043, align 8
  %v11685 = load i64, ptr %slot2042, align 8
  %cmp11686 = icmp ult i64 %v11685, 8
  %cv11687 = zext i1 %cmp11686 to i32
  store i32 %cv11687, ptr %slot2044, align 8
  %v11688 = load i32, ptr %slot2043, align 8
  %v11689 = load i32, ptr %slot2044, align 8
  %op11690 = or i32 %v11688, %v11689
  store i32 %op11690, ptr %slot2045, align 8
  %v11691 = load i32, ptr %slot2045, align 8
  %cv11692 = zext i32 %v11691 to i64
  %cond11693 = icmp ne i64 %cv11692, 0
  br i1 %cond11693, label %bb_rcmoveslow2607, label %bb_rcmovecheck2607
bb_rcmovecheck2607:
  %v11694 = load i64, ptr %slot2034, align 8
  %p11696 = inttoptr i64 %v11694 to ptr
  %gep11697 = getelementptr i8, ptr %p11696, i64 0
  %op11695 = ptrtoint ptr %gep11697 to i64
  store i64 %op11695, ptr %slot2046, align 8
  %v11698 = load i64, ptr %slot2046, align 8
  %p11699 = inttoptr i64 %v11698 to ptr
  %ld11700 = load i64, ptr %p11699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11700, ptr %slot2047, align 8
  %v11701 = load i64, ptr %slot2047, align 8
  %cmp11702 = icmp ne i64 %v11701, 0
  %cv11703 = zext i1 %cmp11702 to i32
  store i32 %cv11703, ptr %slot2048, align 8
  %v11704 = load i32, ptr %slot2048, align 8
  %cv11705 = zext i32 %v11704 to i64
  %cond11706 = icmp ne i64 %cv11705, 0
  br i1 %cond11706, label %bb_rcmoveheader2615, label %bb_rcmovenext2615
bb_rcmoveheader2615:
  %v11707 = load i64, ptr %slot2047, align 8
  %op11708 = sub i64 %v11707, 16
  store i64 %op11708, ptr %slot2049, align 8
  %v11709 = load i64, ptr %slot2047, align 8
  %p11710 = inttoptr i64 %v11709 to ptr
  %rgep11711 = getelementptr i8, ptr %p11710, i64 -16
  %ld11712 = load i64, ptr %rgep11711, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11712, ptr %slot2050, align 8
  %v11713 = load i64, ptr %slot2050, align 8
  %op11714 = and i64 %v11713, 5764607523034234881
  store i64 %op11714, ptr %slot2051, align 8
  %v11715 = load i64, ptr %slot2051, align 8
  %cmp11716 = icmp ne i64 %v11715, 0
  %cv11717 = zext i1 %cmp11716 to i32
  store i32 %cv11717, ptr %slot2052, align 8
  %v11718 = load i32, ptr %slot2052, align 8
  %cv11719 = zext i32 %v11718 to i64
  %cond11720 = icmp ne i64 %cv11719, 0
  br i1 %cond11720, label %bb_rcmoveslow2607, label %bb_rcmovenext2615
bb_rcmovenext2615:
  %v11721 = load i64, ptr %slot2034, align 8
  %v11722 = load i64, ptr %slot2039, align 8
  %p11723 = inttoptr i64 %v11721 to ptr
  %p11724 = inttoptr i64 %v11722 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11724, ptr %p11723, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11725 = load i64, ptr %slot2034, align 8
  %p11726 = inttoptr i64 %v11725 to ptr
  store i64 0, ptr %p11726, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2607
bb_rcmoveslow2607:
  %v11727 = load i64, ptr %slot110, align 8
  %v11728 = load i64, ptr %slot2039, align 8
  %v11729 = load i64, ptr %slot2034, align 8
  %v11730 = load i64, ptr %slot2040, align 8
  %cv11731 = trunc i64 %v11730 to i32
  %call11732 = call i32 @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_take(i64 %v11727, i64 %v11728, i64 %v11729, i32 %cv11731) nomerge, !dbg !170
  store i32 %call11732, ptr %slot2053, align 8
  %v11733 = load i32, ptr %slot2053, align 8
  %cv11734 = zext i32 %v11733 to i64
  %cond11735 = icmp ne i64 %cv11734, 0
  br i1 %cond11735, label %bb_rcsuccess2622, label %bb_rcfailure2622
bb_rcfailure2622:
  %v11736 = load i64, ptr %slot110, align 8
  %p11737 = inttoptr i64 %v11736 to ptr
  %call11738 = call i32 @myl_rc_take_failure(ptr %p11737) nomerge, !dbg !170
  store i32 %call11738, ptr %slot2054, align 8
  %v11739 = load i64, ptr %slot1, align 8
  %p11740 = inttoptr i64 %v11739 to ptr
  %v11741 = load i32, ptr %slot2054, align 8
  %call11742 = call i32 @myl_qbe_rc_status(ptr %p11740, i32 %v11741) nomerge, !dbg !170
  store i32 %call11742, ptr %slot2055, align 8
  br label %bb_failure
bb_rcsuccess2622:
  br label %bb_rcmoved2607
bb_rcmoved2607:
  %v11743 = load i64, ptr %slot47, align 8
  %p11744 = inttoptr i64 %v11743 to ptr
  store i32 2, ptr %p11744, align 4, !alias.scope !3, !noalias !4
  %v11745 = load i64, ptr %slot46, align 8
  %p11746 = inttoptr i64 %v11745 to ptr
  store i32 1, ptr %p11746, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2598
bb_rccopy2598:
  %v11747 = load i64, ptr %slot65, align 8
  store i64 %v11747, ptr %slot2056, align 8
  %v11748 = load i64, ptr %slot111, align 8
  store i64 %v11748, ptr %slot2057, align 8
  %v11749 = load i64, ptr %slot2034, align 8
  %p11750 = inttoptr i64 %v11749 to ptr
  %ld11751 = load i64, ptr %p11750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11751, ptr %slot2058, align 8
  %v11752 = load i64, ptr %slot2058, align 8
  %cmp11753 = icmp ne i64 %v11752, 0
  %cv11754 = zext i1 %cmp11753 to i32
  store i32 %cv11754, ptr %slot2059, align 8
  %v11755 = load i32, ptr %slot2059, align 8
  %cv11756 = zext i32 %v11755 to i64
  %cond11757 = icmp ne i64 %cv11756, 0
  br i1 %cond11757, label %bb_rcgnn2631, label %bb_rcgplain2631
bb_rcgnn2631:
  %v11758 = load i64, ptr %slot2058, align 8
  %op11759 = sub i64 %v11758, 16
  store i64 %op11759, ptr %slot2060, align 8
  %v11760 = load i64, ptr %slot2058, align 8
  %p11761 = inttoptr i64 %v11760 to ptr
  %rgep11762 = getelementptr i8, ptr %p11761, i64 -16
  %ld11763 = load i64, ptr %rgep11762, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11763, ptr %slot2061, align 8
  %v11764 = load i64, ptr %slot2061, align 8
  %op11765 = and i64 %v11764, 4611686018427387906
  store i64 %op11765, ptr %slot2062, align 8
  %v11766 = load i64, ptr %slot2062, align 8
  %cmp11767 = icmp ne i64 %v11766, 0
  %cv11768 = zext i1 %cmp11767 to i32
  store i32 %cv11768, ptr %slot2063, align 8
  %v11769 = load i32, ptr %slot2063, align 8
  %cv11770 = zext i32 %v11769 to i64
  %cond11771 = icmp ne i64 %cv11770, 0
  br i1 %cond11771, label %bb_rcgspecial2631, label %bb_rcginc2631
bb_rcginc2631:
  %v11772 = load i64, ptr %slot2058, align 8
  %op11773 = sub i64 %v11772, 32
  store i64 %op11773, ptr %slot2064, align 8
  %v11774 = load i64, ptr %slot2058, align 8
  %p11775 = inttoptr i64 %v11774 to ptr
  %rgep11776 = getelementptr i8, ptr %p11775, i64 -32
  %ld11777 = load i64, ptr %rgep11776, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11777, ptr %slot2065, align 8
  %v11778 = load i64, ptr %slot2065, align 8
  %op11779 = add i64 %v11778, 1
  store i64 %op11779, ptr %slot2066, align 8
  %v11780 = load i64, ptr %slot2066, align 8
  %cmp11781 = icmp eq i64 %v11780, 0
  %cv11782 = zext i1 %cmp11781 to i32
  store i32 %cv11782, ptr %slot2067, align 8
  %v11783 = load i32, ptr %slot2067, align 8
  %cv11784 = zext i32 %v11783 to i64
  %cond11785 = icmp ne i64 %cv11784, 0
  br i1 %cond11785, label %bb_rcglimit2631, label %bb_rcgcapacity2631
bb_rcglimit2631:
  %v11786 = load i64, ptr %slot1, align 8
  %p11787 = inttoptr i64 %v11786 to ptr
  %call11788 = call i32 @myl_qbe_rc_status(ptr %p11787, i32 2) nomerge, !dbg !170
  store i32 %call11788, ptr %slot2068, align 8
  br label %bb_failure
bb_rcgcapacity2631:
  %v11789 = load i64, ptr %slot2066, align 8
  %v11790 = load i64, ptr %slot2058, align 8
  %p11791 = inttoptr i64 %v11790 to ptr
  %rgep11792 = getelementptr i8, ptr %p11791, i64 -32
  store i64 %v11789, ptr %rgep11792, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2631
bb_rcgspecial2631:
  %v11793 = load i64, ptr %slot2061, align 8
  %op11794 = and i64 %v11793, 4611686018427387904
  store i64 %op11794, ptr %slot2069, align 8
  %v11795 = load i64, ptr %slot2069, align 8
  %cmp11796 = icmp ne i64 %v11795, 0
  %cv11797 = zext i1 %cmp11796 to i32
  store i32 %cv11797, ptr %slot2070, align 8
  %v11798 = load i32, ptr %slot2070, align 8
  %cv11799 = zext i32 %v11798 to i64
  %cond11800 = icmp ne i64 %cv11799, 0
  br i1 %cond11800, label %bb_rcgslow2631, label %bb_rcgplain2631
bb_rcgslow2631:
  %v11801 = load i64, ptr %slot110, align 8
  %v11802 = load i64, ptr %slot2056, align 8
  %v11803 = load i64, ptr %slot2034, align 8
  %v11804 = load i64, ptr %slot2057, align 8
  %cv11805 = trunc i64 %v11804 to i32
  %call11806 = call i32 @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_retain(i64 %v11801, i64 %v11802, i64 %v11803, i32 %cv11805) nomerge, !dbg !170
  store i32 %call11806, ptr %slot2071, align 8
  %v11807 = load i32, ptr %slot2071, align 8
  %cv11808 = zext i32 %v11807 to i64
  %cond11809 = icmp ne i64 %cv11808, 0
  br i1 %cond11809, label %bb_rcsuccess2645, label %bb_rcfailure2645
bb_rcfailure2645:
  %v11810 = load i64, ptr %slot110, align 8
  %p11811 = inttoptr i64 %v11810 to ptr
  %call11812 = call i32 @myl_rc_take_failure(ptr %p11811) nomerge, !dbg !170
  store i32 %call11812, ptr %slot2072, align 8
  %v11813 = load i64, ptr %slot1, align 8
  %p11814 = inttoptr i64 %v11813 to ptr
  %v11815 = load i32, ptr %slot2072, align 8
  %call11816 = call i32 @myl_qbe_rc_status(ptr %p11814, i32 %v11815) nomerge, !dbg !170
  store i32 %call11816, ptr %slot2073, align 8
  br label %bb_failure
bb_rcsuccess2645:
  br label %bb_rcgdone2631
bb_rcgplain2631:
  %v11817 = load i64, ptr %slot2058, align 8
  %v11818 = load i64, ptr %slot2056, align 8
  %p11819 = inttoptr i64 %v11818 to ptr
  store i64 %v11817, ptr %p11819, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2631
bb_rcgdone2631:
  %v11820 = load i64, ptr %slot47, align 8
  %p11821 = inttoptr i64 %v11820 to ptr
  store i32 2, ptr %p11821, align 4, !alias.scope !3, !noalias !4
  %v11822 = load i64, ptr %slot46, align 8
  %p11823 = inttoptr i64 %v11822 to ptr
  store i32 1, ptr %p11823, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2598
bb_rcprepared2598:
  %v11824 = load i64, ptr %slot65, align 8
  store i64 %v11824, ptr %slot2074, align 8
  %v11825 = load i64, ptr %slot2074, align 8
  %v11826 = load i64, ptr %slot2032, align 8
  %p11827 = inttoptr i64 %v11825 to ptr
  %p11828 = inttoptr i64 %v11826 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11828, ptr %p11827, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11829 = load i64, ptr %slot46, align 8
  %p11830 = inttoptr i64 %v11829 to ptr
  store i32 0, ptr %p11830, align 4, !alias.scope !3, !noalias !4
  %v11831 = load i64, ptr %slot95, align 8
  store i64 %v11831, ptr %slot2075, align 8
  %v11832 = load i64, ptr %slot1687, align 8
  %p11834 = inttoptr i64 %v11832 to ptr
  %gep11835 = getelementptr i8, ptr %p11834, i64 144
  %op11833 = ptrtoint ptr %gep11835 to i64
  store i64 %op11833, ptr %slot2076, align 8
  %v11836 = load i64, ptr %slot2075, align 8
  %p11837 = inttoptr i64 %v11836 to ptr
  %ld11838 = load i64, ptr %p11837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11838, ptr %slot2077, align 8
  %v11839 = load i64, ptr %slot2077, align 8
  %v11840 = load i64, ptr %slot2076, align 8
  %p11841 = inttoptr i64 %v11840 to ptr
  store i64 %v11839, ptr %p11841, align 8, !alias.scope !3, !noalias !4
  %v11842 = load i64, ptr %slot96, align 8
  store i64 %v11842, ptr %slot2078, align 8
  %v11843 = load i64, ptr %slot1687, align 8
  %p11845 = inttoptr i64 %v11843 to ptr
  %gep11846 = getelementptr i8, ptr %p11845, i64 152
  %op11844 = ptrtoint ptr %gep11846 to i64
  store i64 %op11844, ptr %slot2079, align 8
  %v11847 = load i64, ptr %slot2078, align 8
  %p11848 = inttoptr i64 %v11847 to ptr
  %ld11849 = load i64, ptr %p11848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11849, ptr %slot2080, align 8
  %v11850 = load i64, ptr %slot2080, align 8
  %v11851 = load i64, ptr %slot2079, align 8
  %p11852 = inttoptr i64 %v11851 to ptr
  store i64 %v11850, ptr %p11852, align 8, !alias.scope !3, !noalias !4
  %v11853 = load i64, ptr %slot97, align 8
  %p11854 = inttoptr i64 %v11853 to ptr
  %ld11855 = load i64, ptr %p11854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11855, ptr %slot2081, align 8
  %v11856 = load i64, ptr %slot2081, align 8
  %v11857 = load i64, ptr %slot62, align 8
  %p11858 = inttoptr i64 %v11857 to ptr
  store i64 %v11856, ptr %p11858, align 8, !alias.scope !3, !noalias !4
  %v11859 = load i64, ptr %slot62, align 8
  store i64 %v11859, ptr %slot2082, align 8
  %v11860 = load i64, ptr %slot1687, align 8
  %p11862 = inttoptr i64 %v11860 to ptr
  %gep11863 = getelementptr i8, ptr %p11862, i64 160
  %op11861 = ptrtoint ptr %gep11863 to i64
  store i64 %op11861, ptr %slot2083, align 8
  %v11864 = load i64, ptr %slot97, align 8
  %p11865 = inttoptr i64 %v11864 to ptr
  %ld11866 = load i64, ptr %p11865, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11866, ptr %slot2084, align 8
  %v11867 = load i64, ptr %slot2084, align 8
  %v11868 = load i64, ptr %slot62, align 8
  %p11869 = inttoptr i64 %v11868 to ptr
  store i64 %v11867, ptr %p11869, align 8, !alias.scope !3, !noalias !4
  %v11870 = load i64, ptr %slot62, align 8
  store i64 %v11870, ptr %slot2085, align 8
  %v11871 = load i64, ptr %slot40, align 8
  %p11872 = inttoptr i64 %v11871 to ptr
  %ld11873 = load i32, ptr %p11872, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11873, ptr %slot2086, align 8
  %v11874 = load i64, ptr %slot41, align 8
  %p11875 = inttoptr i64 %v11874 to ptr
  %ld11876 = load i32, ptr %p11875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11876, ptr %slot2087, align 8
  %v11877 = load i32, ptr %slot2087, align 8
  %op11878 = and i32 %v11877, 24
  store i32 %op11878, ptr %slot2087, align 8
  %v11879 = load i32, ptr %slot2087, align 8
  %cmp11880 = icmp eq i32 %v11879, 0
  %cv11881 = zext i1 %cmp11880 to i32
  store i32 %cv11881, ptr %slot2088, align 8
  %v11882 = load i32, ptr %slot2086, align 8
  %v11883 = load i32, ptr %slot2088, align 8
  %op11884 = and i32 %v11882, %v11883
  store i32 %op11884, ptr %slot2089, align 8
  %v11885 = load i32, ptr %slot2089, align 8
  %cv11886 = zext i32 %v11885 to i64
  %cond11887 = icmp ne i64 %cv11886, 0
  br i1 %cond11887, label %bb_rctake2700, label %bb_rccopy2700
bb_rctake2700:
  %v11888 = load i64, ptr %slot65, align 8
  store i64 %v11888, ptr %slot2090, align 8
  %v11889 = load i64, ptr %slot111, align 8
  store i64 %v11889, ptr %slot2091, align 8
  %v11890 = load i64, ptr %slot2085, align 8
  %v11891 = load i64, ptr %slot2090, align 8
  %op11892 = sub i64 %v11890, %v11891
  store i64 %op11892, ptr %slot2092, align 8
  %v11893 = load i64, ptr %slot2090, align 8
  %v11894 = load i64, ptr %slot2085, align 8
  %op11895 = sub i64 %v11893, %v11894
  store i64 %op11895, ptr %slot2093, align 8
  %v11896 = load i64, ptr %slot2092, align 8
  %cmp11897 = icmp ult i64 %v11896, 8
  %cv11898 = zext i1 %cmp11897 to i32
  store i32 %cv11898, ptr %slot2094, align 8
  %v11899 = load i64, ptr %slot2093, align 8
  %cmp11900 = icmp ult i64 %v11899, 8
  %cv11901 = zext i1 %cmp11900 to i32
  store i32 %cv11901, ptr %slot2095, align 8
  %v11902 = load i32, ptr %slot2094, align 8
  %v11903 = load i32, ptr %slot2095, align 8
  %op11904 = or i32 %v11902, %v11903
  store i32 %op11904, ptr %slot2096, align 8
  %v11905 = load i32, ptr %slot2096, align 8
  %cv11906 = zext i32 %v11905 to i64
  %cond11907 = icmp ne i64 %cv11906, 0
  br i1 %cond11907, label %bb_rcmoveslow2709, label %bb_rcmovecheck2709
bb_rcmovecheck2709:
  %v11908 = load i64, ptr %slot2085, align 8
  %p11910 = inttoptr i64 %v11908 to ptr
  %gep11911 = getelementptr i8, ptr %p11910, i64 0
  %op11909 = ptrtoint ptr %gep11911 to i64
  store i64 %op11909, ptr %slot2097, align 8
  %v11912 = load i64, ptr %slot2097, align 8
  %p11913 = inttoptr i64 %v11912 to ptr
  %ld11914 = load i64, ptr %p11913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11914, ptr %slot2098, align 8
  %v11915 = load i64, ptr %slot2098, align 8
  %cmp11916 = icmp ne i64 %v11915, 0
  %cv11917 = zext i1 %cmp11916 to i32
  store i32 %cv11917, ptr %slot2099, align 8
  %v11918 = load i32, ptr %slot2099, align 8
  %cv11919 = zext i32 %v11918 to i64
  %cond11920 = icmp ne i64 %cv11919, 0
  br i1 %cond11920, label %bb_rcmoveheader2717, label %bb_rcmovenext2717
bb_rcmoveheader2717:
  %v11921 = load i64, ptr %slot2098, align 8
  %op11922 = sub i64 %v11921, 16
  store i64 %op11922, ptr %slot2100, align 8
  %v11923 = load i64, ptr %slot2098, align 8
  %p11924 = inttoptr i64 %v11923 to ptr
  %rgep11925 = getelementptr i8, ptr %p11924, i64 -16
  %ld11926 = load i64, ptr %rgep11925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11926, ptr %slot2101, align 8
  %v11927 = load i64, ptr %slot2101, align 8
  %op11928 = and i64 %v11927, 5764607523034234881
  store i64 %op11928, ptr %slot2102, align 8
  %v11929 = load i64, ptr %slot2102, align 8
  %cmp11930 = icmp ne i64 %v11929, 0
  %cv11931 = zext i1 %cmp11930 to i32
  store i32 %cv11931, ptr %slot2103, align 8
  %v11932 = load i32, ptr %slot2103, align 8
  %cv11933 = zext i32 %v11932 to i64
  %cond11934 = icmp ne i64 %cv11933, 0
  br i1 %cond11934, label %bb_rcmoveslow2709, label %bb_rcmovenext2717
bb_rcmovenext2717:
  %v11935 = load i64, ptr %slot2085, align 8
  %v11936 = load i64, ptr %slot2090, align 8
  %p11937 = inttoptr i64 %v11935 to ptr
  %p11938 = inttoptr i64 %v11936 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11938, ptr %p11937, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11939 = load i64, ptr %slot2085, align 8
  %p11940 = inttoptr i64 %v11939 to ptr
  store i64 0, ptr %p11940, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2709
bb_rcmoveslow2709:
  %v11941 = load i64, ptr %slot110, align 8
  %v11942 = load i64, ptr %slot2090, align 8
  %v11943 = load i64, ptr %slot2085, align 8
  %v11944 = load i64, ptr %slot2091, align 8
  %cv11945 = trunc i64 %v11944 to i32
  %call11946 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v11941, i64 %v11942, i64 %v11943, i32 %cv11945) nomerge, !dbg !170
  store i32 %call11946, ptr %slot2104, align 8
  %v11947 = load i32, ptr %slot2104, align 8
  %cv11948 = zext i32 %v11947 to i64
  %cond11949 = icmp ne i64 %cv11948, 0
  br i1 %cond11949, label %bb_rcsuccess2724, label %bb_rcfailure2724
bb_rcfailure2724:
  %v11950 = load i64, ptr %slot110, align 8
  %p11951 = inttoptr i64 %v11950 to ptr
  %call11952 = call i32 @myl_rc_take_failure(ptr %p11951) nomerge, !dbg !170
  store i32 %call11952, ptr %slot2105, align 8
  %v11953 = load i64, ptr %slot1, align 8
  %p11954 = inttoptr i64 %v11953 to ptr
  %v11955 = load i32, ptr %slot2105, align 8
  %call11956 = call i32 @myl_qbe_rc_status(ptr %p11954, i32 %v11955) nomerge, !dbg !170
  store i32 %call11956, ptr %slot2106, align 8
  br label %bb_failure
bb_rcsuccess2724:
  br label %bb_rcmoved2709
bb_rcmoved2709:
  %v11957 = load i64, ptr %slot40, align 8
  %p11958 = inttoptr i64 %v11957 to ptr
  store i32 0, ptr %p11958, align 4, !alias.scope !3, !noalias !4
  %v11959 = load i64, ptr %slot47, align 8
  %p11960 = inttoptr i64 %v11959 to ptr
  store i32 2, ptr %p11960, align 4, !alias.scope !3, !noalias !4
  %v11961 = load i64, ptr %slot46, align 8
  %p11962 = inttoptr i64 %v11961 to ptr
  store i32 1, ptr %p11962, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2700
bb_rccopy2700:
  %v11963 = load i64, ptr %slot65, align 8
  store i64 %v11963, ptr %slot2107, align 8
  %v11964 = load i64, ptr %slot111, align 8
  store i64 %v11964, ptr %slot2108, align 8
  %v11965 = load i64, ptr %slot2085, align 8
  %p11966 = inttoptr i64 %v11965 to ptr
  %ld11967 = load i64, ptr %p11966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11967, ptr %slot2109, align 8
  %v11968 = load i64, ptr %slot2109, align 8
  %cmp11969 = icmp ne i64 %v11968, 0
  %cv11970 = zext i1 %cmp11969 to i32
  store i32 %cv11970, ptr %slot2110, align 8
  %v11971 = load i32, ptr %slot2110, align 8
  %cv11972 = zext i32 %v11971 to i64
  %cond11973 = icmp ne i64 %cv11972, 0
  br i1 %cond11973, label %bb_rcgnn2733, label %bb_rcgplain2733
bb_rcgnn2733:
  %v11974 = load i64, ptr %slot2109, align 8
  %op11975 = sub i64 %v11974, 16
  store i64 %op11975, ptr %slot2111, align 8
  %v11976 = load i64, ptr %slot2109, align 8
  %p11977 = inttoptr i64 %v11976 to ptr
  %rgep11978 = getelementptr i8, ptr %p11977, i64 -16
  %ld11979 = load i64, ptr %rgep11978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11979, ptr %slot2112, align 8
  %v11980 = load i64, ptr %slot2112, align 8
  %op11981 = and i64 %v11980, 4611686018427387906
  store i64 %op11981, ptr %slot2113, align 8
  %v11982 = load i64, ptr %slot2113, align 8
  %cmp11983 = icmp ne i64 %v11982, 0
  %cv11984 = zext i1 %cmp11983 to i32
  store i32 %cv11984, ptr %slot2114, align 8
  %v11985 = load i32, ptr %slot2114, align 8
  %cv11986 = zext i32 %v11985 to i64
  %cond11987 = icmp ne i64 %cv11986, 0
  br i1 %cond11987, label %bb_rcgspecial2733, label %bb_rcginc2733
bb_rcginc2733:
  %v11988 = load i64, ptr %slot2109, align 8
  %op11989 = sub i64 %v11988, 32
  store i64 %op11989, ptr %slot2115, align 8
  %v11990 = load i64, ptr %slot2109, align 8
  %p11991 = inttoptr i64 %v11990 to ptr
  %rgep11992 = getelementptr i8, ptr %p11991, i64 -32
  %ld11993 = load i64, ptr %rgep11992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11993, ptr %slot2116, align 8
  %v11994 = load i64, ptr %slot2116, align 8
  %op11995 = add i64 %v11994, 1
  store i64 %op11995, ptr %slot2117, align 8
  %v11996 = load i64, ptr %slot2117, align 8
  %cmp11997 = icmp eq i64 %v11996, 0
  %cv11998 = zext i1 %cmp11997 to i32
  store i32 %cv11998, ptr %slot2118, align 8
  %v11999 = load i32, ptr %slot2118, align 8
  %cv12000 = zext i32 %v11999 to i64
  %cond12001 = icmp ne i64 %cv12000, 0
  br i1 %cond12001, label %bb_rcglimit2733, label %bb_rcgcapacity2733
bb_rcglimit2733:
  %v12002 = load i64, ptr %slot1, align 8
  %p12003 = inttoptr i64 %v12002 to ptr
  %call12004 = call i32 @myl_qbe_rc_status(ptr %p12003, i32 2) nomerge, !dbg !170
  store i32 %call12004, ptr %slot2119, align 8
  br label %bb_failure
bb_rcgcapacity2733:
  %v12005 = load i64, ptr %slot2117, align 8
  %v12006 = load i64, ptr %slot2109, align 8
  %p12007 = inttoptr i64 %v12006 to ptr
  %rgep12008 = getelementptr i8, ptr %p12007, i64 -32
  store i64 %v12005, ptr %rgep12008, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2733
bb_rcgspecial2733:
  %v12009 = load i64, ptr %slot2112, align 8
  %op12010 = and i64 %v12009, 4611686018427387904
  store i64 %op12010, ptr %slot2120, align 8
  %v12011 = load i64, ptr %slot2120, align 8
  %cmp12012 = icmp ne i64 %v12011, 0
  %cv12013 = zext i1 %cmp12012 to i32
  store i32 %cv12013, ptr %slot2121, align 8
  %v12014 = load i32, ptr %slot2121, align 8
  %cv12015 = zext i32 %v12014 to i64
  %cond12016 = icmp ne i64 %cv12015, 0
  br i1 %cond12016, label %bb_rcgslow2733, label %bb_rcgplain2733
bb_rcgslow2733:
  %v12017 = load i64, ptr %slot110, align 8
  %v12018 = load i64, ptr %slot2107, align 8
  %v12019 = load i64, ptr %slot2085, align 8
  %v12020 = load i64, ptr %slot2108, align 8
  %cv12021 = trunc i64 %v12020 to i32
  %call12022 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v12017, i64 %v12018, i64 %v12019, i32 %cv12021) nomerge, !dbg !170
  store i32 %call12022, ptr %slot2122, align 8
  %v12023 = load i32, ptr %slot2122, align 8
  %cv12024 = zext i32 %v12023 to i64
  %cond12025 = icmp ne i64 %cv12024, 0
  br i1 %cond12025, label %bb_rcsuccess2747, label %bb_rcfailure2747
bb_rcfailure2747:
  %v12026 = load i64, ptr %slot110, align 8
  %p12027 = inttoptr i64 %v12026 to ptr
  %call12028 = call i32 @myl_rc_take_failure(ptr %p12027) nomerge, !dbg !170
  store i32 %call12028, ptr %slot2123, align 8
  %v12029 = load i64, ptr %slot1, align 8
  %p12030 = inttoptr i64 %v12029 to ptr
  %v12031 = load i32, ptr %slot2123, align 8
  %call12032 = call i32 @myl_qbe_rc_status(ptr %p12030, i32 %v12031) nomerge, !dbg !170
  store i32 %call12032, ptr %slot2124, align 8
  br label %bb_failure
bb_rcsuccess2747:
  br label %bb_rcgdone2733
bb_rcgplain2733:
  %v12033 = load i64, ptr %slot2109, align 8
  %v12034 = load i64, ptr %slot2107, align 8
  %p12035 = inttoptr i64 %v12034 to ptr
  store i64 %v12033, ptr %p12035, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2733
bb_rcgdone2733:
  %v12036 = load i64, ptr %slot47, align 8
  %p12037 = inttoptr i64 %v12036 to ptr
  store i32 2, ptr %p12037, align 4, !alias.scope !3, !noalias !4
  %v12038 = load i64, ptr %slot46, align 8
  %p12039 = inttoptr i64 %v12038 to ptr
  store i32 1, ptr %p12039, align 4, !alias.scope !3, !noalias !4
  %v12040 = load i64, ptr %slot40, align 8
  %p12041 = inttoptr i64 %v12040 to ptr
  %ld12042 = load i32, ptr %p12041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12042, ptr %slot2125, align 8
  %v12043 = load i32, ptr %slot2125, align 8
  %cv12044 = zext i32 %v12043 to i64
  %cond12045 = icmp ne i64 %cv12044, 0
  br i1 %cond12045, label %bb_rcslotdrop2754, label %bb_rcslotdone2754
bb_rcslotdrop2754:
  %v12046 = load i64, ptr %slot40, align 8
  %p12047 = inttoptr i64 %v12046 to ptr
  store i32 0, ptr %p12047, align 4, !alias.scope !3, !noalias !4
  %v12048 = load i64, ptr %slot54, align 8
  store i64 %v12048, ptr %slot2126, align 8
  %v12049 = load i64, ptr %slot41, align 8
  %p12050 = inttoptr i64 %v12049 to ptr
  %ld12051 = load i32, ptr %p12050, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12051, ptr %slot2127, align 8
  %v12052 = load i32, ptr %slot2127, align 8
  %op12053 = and i32 %v12052, 28
  store i32 %op12053, ptr %slot2128, align 8
  %v12054 = load i32, ptr %slot2128, align 8
  %cv12055 = zext i32 %v12054 to i64
  %cond12056 = icmp ne i64 %cv12055, 0
  br i1 %cond12056, label %bb_rcslotrole2754, label %bb_rcslotowner2754
bb_rcslotrole2754:
  %v12057 = load i64, ptr %slot110, align 8
  store i64 %v12057, ptr %slot2129, align 8
  %v12058 = load i64, ptr %slot2126, align 8
  %p12059 = inttoptr i64 %v12058 to ptr
  %ld12060 = load i64, ptr %p12059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12060, ptr %slot2130, align 8
  %v12061 = load i64, ptr %slot2130, align 8
  %cmp12062 = icmp ne i64 %v12061, 0
  %cv12063 = zext i1 %cmp12062 to i32
  store i32 %cv12063, ptr %slot2131, align 8
  %v12064 = load i32, ptr %slot2131, align 8
  %cv12065 = zext i32 %v12064 to i64
  %cond12066 = icmp ne i64 %cv12065, 0
  br i1 %cond12066, label %bb_rcgnn2770, label %bb_rcgdone2770
bb_rcgnn2770:
  %v12067 = load i64, ptr %slot2130, align 8
  %op12068 = sub i64 %v12067, 16
  store i64 %op12068, ptr %slot2132, align 8
  %v12069 = load i64, ptr %slot2130, align 8
  %p12070 = inttoptr i64 %v12069 to ptr
  %rgep12071 = getelementptr i8, ptr %p12070, i64 -16
  %ld12072 = load i64, ptr %rgep12071, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12072, ptr %slot2133, align 8
  %v12073 = load i64, ptr %slot2133, align 8
  %op12074 = and i64 %v12073, 4611686018427387906
  store i64 %op12074, ptr %slot2134, align 8
  %v12075 = load i64, ptr %slot2134, align 8
  %cmp12076 = icmp ne i64 %v12075, 0
  %cv12077 = zext i1 %cmp12076 to i32
  store i32 %cv12077, ptr %slot2135, align 8
  %v12078 = load i32, ptr %slot2135, align 8
  %cv12079 = zext i32 %v12078 to i64
  %cond12080 = icmp ne i64 %cv12079, 0
  br i1 %cond12080, label %bb_rcgclear2770, label %bb_rcgcounted2770
bb_rcgcounted2770:
  %v12081 = load i64, ptr %slot2130, align 8
  %op12082 = sub i64 %v12081, 24
  store i64 %op12082, ptr %slot2136, align 8
  %v12083 = load i64, ptr %slot2130, align 8
  %p12084 = inttoptr i64 %v12083 to ptr
  %rgep12085 = getelementptr i8, ptr %p12084, i64 -24
  %ld12086 = load i64, ptr %rgep12085, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12086, ptr %slot2137, align 8
  %v12087 = load i64, ptr %slot2137, align 8
  %op12088 = sub i64 %v12087, 1
  store i64 %op12088, ptr %slot2138, align 8
  %v12089 = load i64, ptr %slot2138, align 8
  %cmp12090 = icmp eq i64 %v12089, 0
  %cv12091 = zext i1 %cmp12090 to i32
  store i32 %cv12091, ptr %slot2139, align 8
  %v12092 = load i32, ptr %slot2139, align 8
  %cv12093 = zext i32 %v12092 to i64
  %cond12094 = icmp ne i64 %cv12093, 0
  br i1 %cond12094, label %bb_rcglast2770, label %bb_rcgdec2770
bb_rcglast2770:
  %v12095 = load i64, ptr %slot2130, align 8
  %op12096 = sub i64 %v12095, 32
  store i64 %op12096, ptr %slot2140, align 8
  %v12097 = load i64, ptr %slot2130, align 8
  %p12098 = inttoptr i64 %v12097 to ptr
  %rgep12099 = getelementptr i8, ptr %p12098, i64 -32
  %ld12100 = load i64, ptr %rgep12099, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12100, ptr %slot2141, align 8
  %v12101 = load i64, ptr %slot2141, align 8
  %cmp12102 = icmp ne i64 %v12101, 0
  %cv12103 = zext i1 %cmp12102 to i32
  store i32 %cv12103, ptr %slot2142, align 8
  %v12104 = load i32, ptr %slot2142, align 8
  %cv12105 = zext i32 %v12104 to i64
  %cond12106 = icmp ne i64 %cv12105, 0
  br i1 %cond12106, label %bb_rcgdec2770, label %bb_rcgslow2770
bb_rcgslow2770:
  %v12107 = load i64, ptr %slot2129, align 8
  %v12108 = load i64, ptr %slot2126, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v12107, i64 %v12108) nomerge, !dbg !170
  br label %bb_rcgdone2770
bb_rcgdec2770:
  %v12109 = load i64, ptr %slot2138, align 8
  %v12110 = load i64, ptr %slot2130, align 8
  %p12111 = inttoptr i64 %v12110 to ptr
  %rgep12112 = getelementptr i8, ptr %p12111, i64 -24
  store i64 %v12109, ptr %rgep12112, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2770
bb_rcgclear2770:
  %v12113 = load i64, ptr %slot2126, align 8
  %p12114 = inttoptr i64 %v12113 to ptr
  store i64 0, ptr %p12114, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2770
bb_rcgdone2770:
  br label %bb_rcslotdone2754
bb_rcslotowner2754:
  %v12115 = load i64, ptr %slot110, align 8
  store i64 %v12115, ptr %slot2143, align 8
  %v12116 = load i64, ptr %slot2126, align 8
  %p12117 = inttoptr i64 %v12116 to ptr
  %ld12118 = load i64, ptr %p12117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12118, ptr %slot2144, align 8
  %v12119 = load i64, ptr %slot2144, align 8
  %cmp12120 = icmp ne i64 %v12119, 0
  %cv12121 = zext i1 %cmp12120 to i32
  store i32 %cv12121, ptr %slot2145, align 8
  %v12122 = load i32, ptr %slot2145, align 8
  %cv12123 = zext i32 %v12122 to i64
  %cond12124 = icmp ne i64 %cv12123, 0
  br i1 %cond12124, label %bb_rcgnn2785, label %bb_rcgdone2785
bb_rcgnn2785:
  %v12125 = load i64, ptr %slot2144, align 8
  %op12126 = sub i64 %v12125, 16
  store i64 %op12126, ptr %slot2146, align 8
  %v12127 = load i64, ptr %slot2144, align 8
  %p12128 = inttoptr i64 %v12127 to ptr
  %rgep12129 = getelementptr i8, ptr %p12128, i64 -16
  %ld12130 = load i64, ptr %rgep12129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12130, ptr %slot2147, align 8
  %v12131 = load i64, ptr %slot2147, align 8
  %op12132 = and i64 %v12131, 4611686018427387906
  store i64 %op12132, ptr %slot2148, align 8
  %v12133 = load i64, ptr %slot2148, align 8
  %cmp12134 = icmp ne i64 %v12133, 0
  %cv12135 = zext i1 %cmp12134 to i32
  store i32 %cv12135, ptr %slot2149, align 8
  %v12136 = load i32, ptr %slot2149, align 8
  %cv12137 = zext i32 %v12136 to i64
  %cond12138 = icmp ne i64 %cv12137, 0
  br i1 %cond12138, label %bb_rcgclear2785, label %bb_rcgcounted2785
bb_rcgcounted2785:
  %v12139 = load i64, ptr %slot2144, align 8
  %op12140 = sub i64 %v12139, 32
  store i64 %op12140, ptr %slot2150, align 8
  %v12141 = load i64, ptr %slot2144, align 8
  %p12142 = inttoptr i64 %v12141 to ptr
  %rgep12143 = getelementptr i8, ptr %p12142, i64 -32
  %ld12144 = load i64, ptr %rgep12143, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12144, ptr %slot2151, align 8
  %v12145 = load i64, ptr %slot2151, align 8
  %op12146 = sub i64 %v12145, 1
  store i64 %op12146, ptr %slot2152, align 8
  %v12147 = load i64, ptr %slot2152, align 8
  %cmp12148 = icmp eq i64 %v12147, 0
  %cv12149 = zext i1 %cmp12148 to i32
  store i32 %cv12149, ptr %slot2153, align 8
  %v12150 = load i32, ptr %slot2153, align 8
  %cv12151 = zext i32 %v12150 to i64
  %cond12152 = icmp ne i64 %cv12151, 0
  br i1 %cond12152, label %bb_rcglast2785, label %bb_rcgdec2785
bb_rcglast2785:
  %v12153 = load i64, ptr %slot2144, align 8
  %op12154 = sub i64 %v12153, 24
  store i64 %op12154, ptr %slot2154, align 8
  %v12155 = load i64, ptr %slot2144, align 8
  %p12156 = inttoptr i64 %v12155 to ptr
  %rgep12157 = getelementptr i8, ptr %p12156, i64 -24
  %ld12158 = load i64, ptr %rgep12157, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12158, ptr %slot2155, align 8
  %v12159 = load i64, ptr %slot2155, align 8
  %cmp12160 = icmp ne i64 %v12159, 0
  %cv12161 = zext i1 %cmp12160 to i32
  store i32 %cv12161, ptr %slot2156, align 8
  %v12162 = load i32, ptr %slot2156, align 8
  %cv12163 = zext i32 %v12162 to i64
  %cond12164 = icmp ne i64 %cv12163, 0
  br i1 %cond12164, label %bb_rcgdec2785, label %bb_rcgslow2785
bb_rcgslow2785:
  %v12165 = load i64, ptr %slot2143, align 8
  %v12166 = load i64, ptr %slot2126, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v12165, i64 %v12166) nomerge, !dbg !170
  br label %bb_rcgdone2785
bb_rcgdec2785:
  %v12167 = load i64, ptr %slot2152, align 8
  %v12168 = load i64, ptr %slot2144, align 8
  %p12169 = inttoptr i64 %v12168 to ptr
  %rgep12170 = getelementptr i8, ptr %p12169, i64 -32
  store i64 %v12167, ptr %rgep12170, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2785
bb_rcgclear2785:
  %v12171 = load i64, ptr %slot2126, align 8
  %p12172 = inttoptr i64 %v12171 to ptr
  store i64 0, ptr %p12172, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2785
bb_rcgdone2785:
  br label %bb_rcslotdone2754
bb_rcslotdone2754:
  br label %bb_rcprepared2700
bb_rcprepared2700:
  %v12173 = load i64, ptr %slot65, align 8
  store i64 %v12173, ptr %slot2157, align 8
  %v12174 = load i64, ptr %slot2157, align 8
  %v12175 = load i64, ptr %slot2083, align 8
  %p12176 = inttoptr i64 %v12174 to ptr
  %p12177 = inttoptr i64 %v12175 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12177, ptr %p12176, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v12178 = load i64, ptr %slot46, align 8
  %p12179 = inttoptr i64 %v12178 to ptr
  store i32 0, ptr %p12179, align 4, !alias.scope !3, !noalias !4
  %v12180 = load i64, ptr %slot98, align 8
  store i64 %v12180, ptr %slot2158, align 8
  %v12181 = load i64, ptr %slot1687, align 8
  %p12183 = inttoptr i64 %v12181 to ptr
  %gep12184 = getelementptr i8, ptr %p12183, i64 168
  %op12182 = ptrtoint ptr %gep12184 to i64
  store i64 %op12182, ptr %slot2159, align 8
  %v12185 = load i64, ptr %slot2158, align 8
  %p12186 = inttoptr i64 %v12185 to ptr
  %ld12187 = load i64, ptr %p12186, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12187, ptr %slot2160, align 8
  %v12188 = load i64, ptr %slot2160, align 8
  %v12189 = load i64, ptr %slot2159, align 8
  %p12190 = inttoptr i64 %v12189 to ptr
  store i64 %v12188, ptr %p12190, align 8, !alias.scope !3, !noalias !4
  %v12191 = load i64, ptr %slot99, align 8
  %p12192 = inttoptr i64 %v12191 to ptr
  %ld12193 = load i64, ptr %p12192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12193, ptr %slot2161, align 8
  %v12194 = load i64, ptr %slot2161, align 8
  %v12195 = load i64, ptr %slot63, align 8
  %p12196 = inttoptr i64 %v12195 to ptr
  store i64 %v12194, ptr %p12196, align 8, !alias.scope !3, !noalias !4
  %v12197 = load i64, ptr %slot63, align 8
  store i64 %v12197, ptr %slot2162, align 8
  %v12198 = load i64, ptr %slot1687, align 8
  %p12200 = inttoptr i64 %v12198 to ptr
  %gep12201 = getelementptr i8, ptr %p12200, i64 176
  %op12199 = ptrtoint ptr %gep12201 to i64
  store i64 %op12199, ptr %slot2163, align 8
  %v12202 = load i64, ptr %slot99, align 8
  %p12203 = inttoptr i64 %v12202 to ptr
  %ld12204 = load i64, ptr %p12203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12204, ptr %slot2164, align 8
  %v12205 = load i64, ptr %slot2164, align 8
  %v12206 = load i64, ptr %slot63, align 8
  %p12207 = inttoptr i64 %v12206 to ptr
  store i64 %v12205, ptr %p12207, align 8, !alias.scope !3, !noalias !4
  %v12208 = load i64, ptr %slot63, align 8
  store i64 %v12208, ptr %slot2165, align 8
  %v12209 = load i64, ptr %slot42, align 8
  %p12210 = inttoptr i64 %v12209 to ptr
  %ld12211 = load i32, ptr %p12210, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12211, ptr %slot2166, align 8
  %v12212 = load i64, ptr %slot43, align 8
  %p12213 = inttoptr i64 %v12212 to ptr
  %ld12214 = load i32, ptr %p12213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12214, ptr %slot2167, align 8
  %v12215 = load i32, ptr %slot2167, align 8
  %op12216 = and i32 %v12215, 24
  store i32 %op12216, ptr %slot2167, align 8
  %v12217 = load i32, ptr %slot2167, align 8
  %cmp12218 = icmp eq i32 %v12217, 0
  %cv12219 = zext i1 %cmp12218 to i32
  store i32 %cv12219, ptr %slot2168, align 8
  %v12220 = load i32, ptr %slot2166, align 8
  %v12221 = load i32, ptr %slot2168, align 8
  %op12222 = and i32 %v12220, %v12221
  store i32 %op12222, ptr %slot2169, align 8
  %v12223 = load i32, ptr %slot2169, align 8
  %cv12224 = zext i32 %v12223 to i64
  %cond12225 = icmp ne i64 %cv12224, 0
  br i1 %cond12225, label %bb_rctake2799, label %bb_rccopy2799
bb_rctake2799:
  %v12226 = load i64, ptr %slot65, align 8
  store i64 %v12226, ptr %slot2170, align 8
  %v12227 = load i64, ptr %slot111, align 8
  store i64 %v12227, ptr %slot2171, align 8
  %v12228 = load i64, ptr %slot2165, align 8
  %v12229 = load i64, ptr %slot2170, align 8
  %op12230 = sub i64 %v12228, %v12229
  store i64 %op12230, ptr %slot2172, align 8
  %v12231 = load i64, ptr %slot2170, align 8
  %v12232 = load i64, ptr %slot2165, align 8
  %op12233 = sub i64 %v12231, %v12232
  store i64 %op12233, ptr %slot2173, align 8
  %v12234 = load i64, ptr %slot2172, align 8
  %cmp12235 = icmp ult i64 %v12234, 8
  %cv12236 = zext i1 %cmp12235 to i32
  store i32 %cv12236, ptr %slot2174, align 8
  %v12237 = load i64, ptr %slot2173, align 8
  %cmp12238 = icmp ult i64 %v12237, 8
  %cv12239 = zext i1 %cmp12238 to i32
  store i32 %cv12239, ptr %slot2175, align 8
  %v12240 = load i32, ptr %slot2174, align 8
  %v12241 = load i32, ptr %slot2175, align 8
  %op12242 = or i32 %v12240, %v12241
  store i32 %op12242, ptr %slot2176, align 8
  %v12243 = load i32, ptr %slot2176, align 8
  %cv12244 = zext i32 %v12243 to i64
  %cond12245 = icmp ne i64 %cv12244, 0
  br i1 %cond12245, label %bb_rcmoveslow2808, label %bb_rcmovecheck2808
bb_rcmovecheck2808:
  %v12246 = load i64, ptr %slot2165, align 8
  %p12248 = inttoptr i64 %v12246 to ptr
  %gep12249 = getelementptr i8, ptr %p12248, i64 0
  %op12247 = ptrtoint ptr %gep12249 to i64
  store i64 %op12247, ptr %slot2177, align 8
  %v12250 = load i64, ptr %slot2177, align 8
  %p12251 = inttoptr i64 %v12250 to ptr
  %ld12252 = load i64, ptr %p12251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12252, ptr %slot2178, align 8
  %v12253 = load i64, ptr %slot2178, align 8
  %cmp12254 = icmp ne i64 %v12253, 0
  %cv12255 = zext i1 %cmp12254 to i32
  store i32 %cv12255, ptr %slot2179, align 8
  %v12256 = load i32, ptr %slot2179, align 8
  %cv12257 = zext i32 %v12256 to i64
  %cond12258 = icmp ne i64 %cv12257, 0
  br i1 %cond12258, label %bb_rcmoveheader2816, label %bb_rcmovenext2816
bb_rcmoveheader2816:
  %v12259 = load i64, ptr %slot2178, align 8
  %op12260 = sub i64 %v12259, 16
  store i64 %op12260, ptr %slot2180, align 8
  %v12261 = load i64, ptr %slot2178, align 8
  %p12262 = inttoptr i64 %v12261 to ptr
  %rgep12263 = getelementptr i8, ptr %p12262, i64 -16
  %ld12264 = load i64, ptr %rgep12263, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12264, ptr %slot2181, align 8
  %v12265 = load i64, ptr %slot2181, align 8
  %op12266 = and i64 %v12265, 5764607523034234881
  store i64 %op12266, ptr %slot2182, align 8
  %v12267 = load i64, ptr %slot2182, align 8
  %cmp12268 = icmp ne i64 %v12267, 0
  %cv12269 = zext i1 %cmp12268 to i32
  store i32 %cv12269, ptr %slot2183, align 8
  %v12270 = load i32, ptr %slot2183, align 8
  %cv12271 = zext i32 %v12270 to i64
  %cond12272 = icmp ne i64 %cv12271, 0
  br i1 %cond12272, label %bb_rcmoveslow2808, label %bb_rcmovenext2816
bb_rcmovenext2816:
  %v12273 = load i64, ptr %slot2165, align 8
  %v12274 = load i64, ptr %slot2170, align 8
  %p12275 = inttoptr i64 %v12273 to ptr
  %p12276 = inttoptr i64 %v12274 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12276, ptr %p12275, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v12277 = load i64, ptr %slot2165, align 8
  %p12278 = inttoptr i64 %v12277 to ptr
  store i64 0, ptr %p12278, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2808
bb_rcmoveslow2808:
  %v12279 = load i64, ptr %slot110, align 8
  %v12280 = load i64, ptr %slot2170, align 8
  %v12281 = load i64, ptr %slot2165, align 8
  %v12282 = load i64, ptr %slot2171, align 8
  %cv12283 = trunc i64 %v12282 to i32
  %call12284 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v12279, i64 %v12280, i64 %v12281, i32 %cv12283) nomerge, !dbg !170
  store i32 %call12284, ptr %slot2184, align 8
  %v12285 = load i32, ptr %slot2184, align 8
  %cv12286 = zext i32 %v12285 to i64
  %cond12287 = icmp ne i64 %cv12286, 0
  br i1 %cond12287, label %bb_rcsuccess2823, label %bb_rcfailure2823
bb_rcfailure2823:
  %v12288 = load i64, ptr %slot110, align 8
  %p12289 = inttoptr i64 %v12288 to ptr
  %call12290 = call i32 @myl_rc_take_failure(ptr %p12289) nomerge, !dbg !170
  store i32 %call12290, ptr %slot2185, align 8
  %v12291 = load i64, ptr %slot1, align 8
  %p12292 = inttoptr i64 %v12291 to ptr
  %v12293 = load i32, ptr %slot2185, align 8
  %call12294 = call i32 @myl_qbe_rc_status(ptr %p12292, i32 %v12293) nomerge, !dbg !170
  store i32 %call12294, ptr %slot2186, align 8
  br label %bb_failure
bb_rcsuccess2823:
  br label %bb_rcmoved2808
bb_rcmoved2808:
  %v12295 = load i64, ptr %slot42, align 8
  %p12296 = inttoptr i64 %v12295 to ptr
  store i32 0, ptr %p12296, align 4, !alias.scope !3, !noalias !4
  %v12297 = load i64, ptr %slot47, align 8
  %p12298 = inttoptr i64 %v12297 to ptr
  store i32 2, ptr %p12298, align 4, !alias.scope !3, !noalias !4
  %v12299 = load i64, ptr %slot46, align 8
  %p12300 = inttoptr i64 %v12299 to ptr
  store i32 1, ptr %p12300, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2799
bb_rccopy2799:
  %v12301 = load i64, ptr %slot65, align 8
  store i64 %v12301, ptr %slot2187, align 8
  %v12302 = load i64, ptr %slot111, align 8
  store i64 %v12302, ptr %slot2188, align 8
  %v12303 = load i64, ptr %slot2165, align 8
  %p12304 = inttoptr i64 %v12303 to ptr
  %ld12305 = load i64, ptr %p12304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12305, ptr %slot2189, align 8
  %v12306 = load i64, ptr %slot2189, align 8
  %cmp12307 = icmp ne i64 %v12306, 0
  %cv12308 = zext i1 %cmp12307 to i32
  store i32 %cv12308, ptr %slot2190, align 8
  %v12309 = load i32, ptr %slot2190, align 8
  %cv12310 = zext i32 %v12309 to i64
  %cond12311 = icmp ne i64 %cv12310, 0
  br i1 %cond12311, label %bb_rcgnn2832, label %bb_rcgplain2832
bb_rcgnn2832:
  %v12312 = load i64, ptr %slot2189, align 8
  %op12313 = sub i64 %v12312, 16
  store i64 %op12313, ptr %slot2191, align 8
  %v12314 = load i64, ptr %slot2189, align 8
  %p12315 = inttoptr i64 %v12314 to ptr
  %rgep12316 = getelementptr i8, ptr %p12315, i64 -16
  %ld12317 = load i64, ptr %rgep12316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12317, ptr %slot2192, align 8
  %v12318 = load i64, ptr %slot2192, align 8
  %op12319 = and i64 %v12318, 4611686018427387906
  store i64 %op12319, ptr %slot2193, align 8
  %v12320 = load i64, ptr %slot2193, align 8
  %cmp12321 = icmp ne i64 %v12320, 0
  %cv12322 = zext i1 %cmp12321 to i32
  store i32 %cv12322, ptr %slot2194, align 8
  %v12323 = load i32, ptr %slot2194, align 8
  %cv12324 = zext i32 %v12323 to i64
  %cond12325 = icmp ne i64 %cv12324, 0
  br i1 %cond12325, label %bb_rcgspecial2832, label %bb_rcginc2832
bb_rcginc2832:
  %v12326 = load i64, ptr %slot2189, align 8
  %op12327 = sub i64 %v12326, 32
  store i64 %op12327, ptr %slot2195, align 8
  %v12328 = load i64, ptr %slot2189, align 8
  %p12329 = inttoptr i64 %v12328 to ptr
  %rgep12330 = getelementptr i8, ptr %p12329, i64 -32
  %ld12331 = load i64, ptr %rgep12330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12331, ptr %slot2196, align 8
  %v12332 = load i64, ptr %slot2196, align 8
  %op12333 = add i64 %v12332, 1
  store i64 %op12333, ptr %slot2197, align 8
  %v12334 = load i64, ptr %slot2197, align 8
  %cmp12335 = icmp eq i64 %v12334, 0
  %cv12336 = zext i1 %cmp12335 to i32
  store i32 %cv12336, ptr %slot2198, align 8
  %v12337 = load i32, ptr %slot2198, align 8
  %cv12338 = zext i32 %v12337 to i64
  %cond12339 = icmp ne i64 %cv12338, 0
  br i1 %cond12339, label %bb_rcglimit2832, label %bb_rcgcapacity2832
bb_rcglimit2832:
  %v12340 = load i64, ptr %slot1, align 8
  %p12341 = inttoptr i64 %v12340 to ptr
  %call12342 = call i32 @myl_qbe_rc_status(ptr %p12341, i32 2) nomerge, !dbg !170
  store i32 %call12342, ptr %slot2199, align 8
  br label %bb_failure
bb_rcgcapacity2832:
  %v12343 = load i64, ptr %slot2197, align 8
  %v12344 = load i64, ptr %slot2189, align 8
  %p12345 = inttoptr i64 %v12344 to ptr
  %rgep12346 = getelementptr i8, ptr %p12345, i64 -32
  store i64 %v12343, ptr %rgep12346, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2832
bb_rcgspecial2832:
  %v12347 = load i64, ptr %slot2192, align 8
  %op12348 = and i64 %v12347, 4611686018427387904
  store i64 %op12348, ptr %slot2200, align 8
  %v12349 = load i64, ptr %slot2200, align 8
  %cmp12350 = icmp ne i64 %v12349, 0
  %cv12351 = zext i1 %cmp12350 to i32
  store i32 %cv12351, ptr %slot2201, align 8
  %v12352 = load i32, ptr %slot2201, align 8
  %cv12353 = zext i32 %v12352 to i64
  %cond12354 = icmp ne i64 %cv12353, 0
  br i1 %cond12354, label %bb_rcgslow2832, label %bb_rcgplain2832
bb_rcgslow2832:
  %v12355 = load i64, ptr %slot110, align 8
  %v12356 = load i64, ptr %slot2187, align 8
  %v12357 = load i64, ptr %slot2165, align 8
  %v12358 = load i64, ptr %slot2188, align 8
  %cv12359 = trunc i64 %v12358 to i32
  %call12360 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v12355, i64 %v12356, i64 %v12357, i32 %cv12359) nomerge, !dbg !170
  store i32 %call12360, ptr %slot2202, align 8
  %v12361 = load i32, ptr %slot2202, align 8
  %cv12362 = zext i32 %v12361 to i64
  %cond12363 = icmp ne i64 %cv12362, 0
  br i1 %cond12363, label %bb_rcsuccess2846, label %bb_rcfailure2846
bb_rcfailure2846:
  %v12364 = load i64, ptr %slot110, align 8
  %p12365 = inttoptr i64 %v12364 to ptr
  %call12366 = call i32 @myl_rc_take_failure(ptr %p12365) nomerge, !dbg !170
  store i32 %call12366, ptr %slot2203, align 8
  %v12367 = load i64, ptr %slot1, align 8
  %p12368 = inttoptr i64 %v12367 to ptr
  %v12369 = load i32, ptr %slot2203, align 8
  %call12370 = call i32 @myl_qbe_rc_status(ptr %p12368, i32 %v12369) nomerge, !dbg !170
  store i32 %call12370, ptr %slot2204, align 8
  br label %bb_failure
bb_rcsuccess2846:
  br label %bb_rcgdone2832
bb_rcgplain2832:
  %v12371 = load i64, ptr %slot2189, align 8
  %v12372 = load i64, ptr %slot2187, align 8
  %p12373 = inttoptr i64 %v12372 to ptr
  store i64 %v12371, ptr %p12373, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2832
bb_rcgdone2832:
  %v12374 = load i64, ptr %slot47, align 8
  %p12375 = inttoptr i64 %v12374 to ptr
  store i32 2, ptr %p12375, align 4, !alias.scope !3, !noalias !4
  %v12376 = load i64, ptr %slot46, align 8
  %p12377 = inttoptr i64 %v12376 to ptr
  store i32 1, ptr %p12377, align 4, !alias.scope !3, !noalias !4
  %v12378 = load i64, ptr %slot42, align 8
  %p12379 = inttoptr i64 %v12378 to ptr
  %ld12380 = load i32, ptr %p12379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12380, ptr %slot2205, align 8
  %v12381 = load i32, ptr %slot2205, align 8
  %cv12382 = zext i32 %v12381 to i64
  %cond12383 = icmp ne i64 %cv12382, 0
  br i1 %cond12383, label %bb_rcslotdrop2853, label %bb_rcslotdone2853
bb_rcslotdrop2853:
  %v12384 = load i64, ptr %slot42, align 8
  %p12385 = inttoptr i64 %v12384 to ptr
  store i32 0, ptr %p12385, align 4, !alias.scope !3, !noalias !4
  %v12386 = load i64, ptr %slot55, align 8
  store i64 %v12386, ptr %slot2206, align 8
  %v12387 = load i64, ptr %slot43, align 8
  %p12388 = inttoptr i64 %v12387 to ptr
  %ld12389 = load i32, ptr %p12388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12389, ptr %slot2207, align 8
  %v12390 = load i32, ptr %slot2207, align 8
  %op12391 = and i32 %v12390, 28
  store i32 %op12391, ptr %slot2208, align 8
  %v12392 = load i32, ptr %slot2208, align 8
  %cv12393 = zext i32 %v12392 to i64
  %cond12394 = icmp ne i64 %cv12393, 0
  br i1 %cond12394, label %bb_rcslotrole2853, label %bb_rcslotowner2853
bb_rcslotrole2853:
  %v12395 = load i64, ptr %slot110, align 8
  store i64 %v12395, ptr %slot2209, align 8
  %v12396 = load i64, ptr %slot2206, align 8
  %p12397 = inttoptr i64 %v12396 to ptr
  %ld12398 = load i64, ptr %p12397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12398, ptr %slot2210, align 8
  %v12399 = load i64, ptr %slot2210, align 8
  %cmp12400 = icmp ne i64 %v12399, 0
  %cv12401 = zext i1 %cmp12400 to i32
  store i32 %cv12401, ptr %slot2211, align 8
  %v12402 = load i32, ptr %slot2211, align 8
  %cv12403 = zext i32 %v12402 to i64
  %cond12404 = icmp ne i64 %cv12403, 0
  br i1 %cond12404, label %bb_rcgnn2869, label %bb_rcgdone2869
bb_rcgnn2869:
  %v12405 = load i64, ptr %slot2210, align 8
  %op12406 = sub i64 %v12405, 16
  store i64 %op12406, ptr %slot2212, align 8
  %v12407 = load i64, ptr %slot2210, align 8
  %p12408 = inttoptr i64 %v12407 to ptr
  %rgep12409 = getelementptr i8, ptr %p12408, i64 -16
  %ld12410 = load i64, ptr %rgep12409, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12410, ptr %slot2213, align 8
  %v12411 = load i64, ptr %slot2213, align 8
  %op12412 = and i64 %v12411, 4611686018427387906
  store i64 %op12412, ptr %slot2214, align 8
  %v12413 = load i64, ptr %slot2214, align 8
  %cmp12414 = icmp ne i64 %v12413, 0
  %cv12415 = zext i1 %cmp12414 to i32
  store i32 %cv12415, ptr %slot2215, align 8
  %v12416 = load i32, ptr %slot2215, align 8
  %cv12417 = zext i32 %v12416 to i64
  %cond12418 = icmp ne i64 %cv12417, 0
  br i1 %cond12418, label %bb_rcgclear2869, label %bb_rcgcounted2869
bb_rcgcounted2869:
  %v12419 = load i64, ptr %slot2210, align 8
  %op12420 = sub i64 %v12419, 24
  store i64 %op12420, ptr %slot2216, align 8
  %v12421 = load i64, ptr %slot2210, align 8
  %p12422 = inttoptr i64 %v12421 to ptr
  %rgep12423 = getelementptr i8, ptr %p12422, i64 -24
  %ld12424 = load i64, ptr %rgep12423, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12424, ptr %slot2217, align 8
  %v12425 = load i64, ptr %slot2217, align 8
  %op12426 = sub i64 %v12425, 1
  store i64 %op12426, ptr %slot2218, align 8
  %v12427 = load i64, ptr %slot2218, align 8
  %cmp12428 = icmp eq i64 %v12427, 0
  %cv12429 = zext i1 %cmp12428 to i32
  store i32 %cv12429, ptr %slot2219, align 8
  %v12430 = load i32, ptr %slot2219, align 8
  %cv12431 = zext i32 %v12430 to i64
  %cond12432 = icmp ne i64 %cv12431, 0
  br i1 %cond12432, label %bb_rcglast2869, label %bb_rcgdec2869
bb_rcglast2869:
  %v12433 = load i64, ptr %slot2210, align 8
  %op12434 = sub i64 %v12433, 32
  store i64 %op12434, ptr %slot2220, align 8
  %v12435 = load i64, ptr %slot2210, align 8
  %p12436 = inttoptr i64 %v12435 to ptr
  %rgep12437 = getelementptr i8, ptr %p12436, i64 -32
  %ld12438 = load i64, ptr %rgep12437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12438, ptr %slot2221, align 8
  %v12439 = load i64, ptr %slot2221, align 8
  %cmp12440 = icmp ne i64 %v12439, 0
  %cv12441 = zext i1 %cmp12440 to i32
  store i32 %cv12441, ptr %slot2222, align 8
  %v12442 = load i32, ptr %slot2222, align 8
  %cv12443 = zext i32 %v12442 to i64
  %cond12444 = icmp ne i64 %cv12443, 0
  br i1 %cond12444, label %bb_rcgdec2869, label %bb_rcgslow2869
bb_rcgslow2869:
  %v12445 = load i64, ptr %slot2209, align 8
  %v12446 = load i64, ptr %slot2206, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v12445, i64 %v12446) nomerge, !dbg !170
  br label %bb_rcgdone2869
bb_rcgdec2869:
  %v12447 = load i64, ptr %slot2218, align 8
  %v12448 = load i64, ptr %slot2210, align 8
  %p12449 = inttoptr i64 %v12448 to ptr
  %rgep12450 = getelementptr i8, ptr %p12449, i64 -24
  store i64 %v12447, ptr %rgep12450, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2869
bb_rcgclear2869:
  %v12451 = load i64, ptr %slot2206, align 8
  %p12452 = inttoptr i64 %v12451 to ptr
  store i64 0, ptr %p12452, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2869
bb_rcgdone2869:
  br label %bb_rcslotdone2853
bb_rcslotowner2853:
  %v12453 = load i64, ptr %slot110, align 8
  store i64 %v12453, ptr %slot2223, align 8
  %v12454 = load i64, ptr %slot2206, align 8
  %p12455 = inttoptr i64 %v12454 to ptr
  %ld12456 = load i64, ptr %p12455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12456, ptr %slot2224, align 8
  %v12457 = load i64, ptr %slot2224, align 8
  %cmp12458 = icmp ne i64 %v12457, 0
  %cv12459 = zext i1 %cmp12458 to i32
  store i32 %cv12459, ptr %slot2225, align 8
  %v12460 = load i32, ptr %slot2225, align 8
  %cv12461 = zext i32 %v12460 to i64
  %cond12462 = icmp ne i64 %cv12461, 0
  br i1 %cond12462, label %bb_rcgnn2884, label %bb_rcgdone2884
bb_rcgnn2884:
  %v12463 = load i64, ptr %slot2224, align 8
  %op12464 = sub i64 %v12463, 16
  store i64 %op12464, ptr %slot2226, align 8
  %v12465 = load i64, ptr %slot2224, align 8
  %p12466 = inttoptr i64 %v12465 to ptr
  %rgep12467 = getelementptr i8, ptr %p12466, i64 -16
  %ld12468 = load i64, ptr %rgep12467, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12468, ptr %slot2227, align 8
  %v12469 = load i64, ptr %slot2227, align 8
  %op12470 = and i64 %v12469, 4611686018427387906
  store i64 %op12470, ptr %slot2228, align 8
  %v12471 = load i64, ptr %slot2228, align 8
  %cmp12472 = icmp ne i64 %v12471, 0
  %cv12473 = zext i1 %cmp12472 to i32
  store i32 %cv12473, ptr %slot2229, align 8
  %v12474 = load i32, ptr %slot2229, align 8
  %cv12475 = zext i32 %v12474 to i64
  %cond12476 = icmp ne i64 %cv12475, 0
  br i1 %cond12476, label %bb_rcgclear2884, label %bb_rcgcounted2884
bb_rcgcounted2884:
  %v12477 = load i64, ptr %slot2224, align 8
  %op12478 = sub i64 %v12477, 32
  store i64 %op12478, ptr %slot2230, align 8
  %v12479 = load i64, ptr %slot2224, align 8
  %p12480 = inttoptr i64 %v12479 to ptr
  %rgep12481 = getelementptr i8, ptr %p12480, i64 -32
  %ld12482 = load i64, ptr %rgep12481, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12482, ptr %slot2231, align 8
  %v12483 = load i64, ptr %slot2231, align 8
  %op12484 = sub i64 %v12483, 1
  store i64 %op12484, ptr %slot2232, align 8
  %v12485 = load i64, ptr %slot2232, align 8
  %cmp12486 = icmp eq i64 %v12485, 0
  %cv12487 = zext i1 %cmp12486 to i32
  store i32 %cv12487, ptr %slot2233, align 8
  %v12488 = load i32, ptr %slot2233, align 8
  %cv12489 = zext i32 %v12488 to i64
  %cond12490 = icmp ne i64 %cv12489, 0
  br i1 %cond12490, label %bb_rcglast2884, label %bb_rcgdec2884
bb_rcglast2884:
  %v12491 = load i64, ptr %slot2224, align 8
  %op12492 = sub i64 %v12491, 24
  store i64 %op12492, ptr %slot2234, align 8
  %v12493 = load i64, ptr %slot2224, align 8
  %p12494 = inttoptr i64 %v12493 to ptr
  %rgep12495 = getelementptr i8, ptr %p12494, i64 -24
  %ld12496 = load i64, ptr %rgep12495, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12496, ptr %slot2235, align 8
  %v12497 = load i64, ptr %slot2235, align 8
  %cmp12498 = icmp ne i64 %v12497, 0
  %cv12499 = zext i1 %cmp12498 to i32
  store i32 %cv12499, ptr %slot2236, align 8
  %v12500 = load i32, ptr %slot2236, align 8
  %cv12501 = zext i32 %v12500 to i64
  %cond12502 = icmp ne i64 %cv12501, 0
  br i1 %cond12502, label %bb_rcgdec2884, label %bb_rcgslow2884
bb_rcgslow2884:
  %v12503 = load i64, ptr %slot2223, align 8
  %v12504 = load i64, ptr %slot2206, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v12503, i64 %v12504) nomerge, !dbg !170
  br label %bb_rcgdone2884
bb_rcgdec2884:
  %v12505 = load i64, ptr %slot2232, align 8
  %v12506 = load i64, ptr %slot2224, align 8
  %p12507 = inttoptr i64 %v12506 to ptr
  %rgep12508 = getelementptr i8, ptr %p12507, i64 -32
  store i64 %v12505, ptr %rgep12508, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2884
bb_rcgclear2884:
  %v12509 = load i64, ptr %slot2206, align 8
  %p12510 = inttoptr i64 %v12509 to ptr
  store i64 0, ptr %p12510, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2884
bb_rcgdone2884:
  br label %bb_rcslotdone2853
bb_rcslotdone2853:
  br label %bb_rcprepared2799
bb_rcprepared2799:
  %v12511 = load i64, ptr %slot65, align 8
  store i64 %v12511, ptr %slot2237, align 8
  %v12512 = load i64, ptr %slot2237, align 8
  %v12513 = load i64, ptr %slot2163, align 8
  %p12514 = inttoptr i64 %v12512 to ptr
  %p12515 = inttoptr i64 %v12513 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12515, ptr %p12514, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v12516 = load i64, ptr %slot46, align 8
  %p12517 = inttoptr i64 %v12516 to ptr
  store i32 0, ptr %p12517, align 4, !alias.scope !3, !noalias !4
  %v12518 = load i64, ptr %slot100, align 8
  %p12519 = inttoptr i64 %v12518 to ptr
  %ld12520 = load i64, ptr %p12519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12520, ptr %slot2238, align 8
  %v12521 = load i64, ptr %slot2238, align 8
  %v12522 = load i64, ptr %slot64, align 8
  %p12523 = inttoptr i64 %v12522 to ptr
  store i64 %v12521, ptr %p12523, align 8, !alias.scope !3, !noalias !4
  %v12524 = load i64, ptr %slot64, align 8
  store i64 %v12524, ptr %slot2239, align 8
  %v12525 = load i64, ptr %slot1687, align 8
  %p12527 = inttoptr i64 %v12525 to ptr
  %gep12528 = getelementptr i8, ptr %p12527, i64 184
  %op12526 = ptrtoint ptr %gep12528 to i64
  store i64 %op12526, ptr %slot2240, align 8
  %v12529 = load i64, ptr %slot100, align 8
  %p12530 = inttoptr i64 %v12529 to ptr
  %ld12531 = load i64, ptr %p12530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12531, ptr %slot2241, align 8
  %v12532 = load i64, ptr %slot2241, align 8
  %v12533 = load i64, ptr %slot64, align 8
  %p12534 = inttoptr i64 %v12533 to ptr
  store i64 %v12532, ptr %p12534, align 8, !alias.scope !3, !noalias !4
  %v12535 = load i64, ptr %slot64, align 8
  store i64 %v12535, ptr %slot2242, align 8
  %v12536 = load i64, ptr %slot44, align 8
  %p12537 = inttoptr i64 %v12536 to ptr
  %ld12538 = load i32, ptr %p12537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12538, ptr %slot2243, align 8
  %v12539 = load i64, ptr %slot45, align 8
  %p12540 = inttoptr i64 %v12539 to ptr
  %ld12541 = load i32, ptr %p12540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12541, ptr %slot2244, align 8
  %v12542 = load i32, ptr %slot2244, align 8
  %op12543 = and i32 %v12542, 24
  store i32 %op12543, ptr %slot2244, align 8
  %v12544 = load i32, ptr %slot2244, align 8
  %cmp12545 = icmp eq i32 %v12544, 0
  %cv12546 = zext i1 %cmp12545 to i32
  store i32 %cv12546, ptr %slot2245, align 8
  %v12547 = load i32, ptr %slot2243, align 8
  %v12548 = load i32, ptr %slot2245, align 8
  %op12549 = and i32 %v12547, %v12548
  store i32 %op12549, ptr %slot2246, align 8
  %v12550 = load i32, ptr %slot2246, align 8
  %cv12551 = zext i32 %v12550 to i64
  %cond12552 = icmp ne i64 %cv12551, 0
  br i1 %cond12552, label %bb_rctake2895, label %bb_rccopy2895
bb_rctake2895:
  %v12553 = load i64, ptr %slot65, align 8
  store i64 %v12553, ptr %slot2247, align 8
  %v12554 = load i64, ptr %slot111, align 8
  store i64 %v12554, ptr %slot2248, align 8
  %v12555 = load i64, ptr %slot2242, align 8
  %v12556 = load i64, ptr %slot2247, align 8
  %op12557 = sub i64 %v12555, %v12556
  store i64 %op12557, ptr %slot2249, align 8
  %v12558 = load i64, ptr %slot2247, align 8
  %v12559 = load i64, ptr %slot2242, align 8
  %op12560 = sub i64 %v12558, %v12559
  store i64 %op12560, ptr %slot2250, align 8
  %v12561 = load i64, ptr %slot2249, align 8
  %cmp12562 = icmp ult i64 %v12561, 8
  %cv12563 = zext i1 %cmp12562 to i32
  store i32 %cv12563, ptr %slot2251, align 8
  %v12564 = load i64, ptr %slot2250, align 8
  %cmp12565 = icmp ult i64 %v12564, 8
  %cv12566 = zext i1 %cmp12565 to i32
  store i32 %cv12566, ptr %slot2252, align 8
  %v12567 = load i32, ptr %slot2251, align 8
  %v12568 = load i32, ptr %slot2252, align 8
  %op12569 = or i32 %v12567, %v12568
  store i32 %op12569, ptr %slot2253, align 8
  %v12570 = load i32, ptr %slot2253, align 8
  %cv12571 = zext i32 %v12570 to i64
  %cond12572 = icmp ne i64 %cv12571, 0
  br i1 %cond12572, label %bb_rcmoveslow2904, label %bb_rcmovecheck2904
bb_rcmovecheck2904:
  %v12573 = load i64, ptr %slot2242, align 8
  %p12575 = inttoptr i64 %v12573 to ptr
  %gep12576 = getelementptr i8, ptr %p12575, i64 0
  %op12574 = ptrtoint ptr %gep12576 to i64
  store i64 %op12574, ptr %slot2254, align 8
  %v12577 = load i64, ptr %slot2254, align 8
  %p12578 = inttoptr i64 %v12577 to ptr
  %ld12579 = load i64, ptr %p12578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12579, ptr %slot2255, align 8
  %v12580 = load i64, ptr %slot2255, align 8
  %cmp12581 = icmp ne i64 %v12580, 0
  %cv12582 = zext i1 %cmp12581 to i32
  store i32 %cv12582, ptr %slot2256, align 8
  %v12583 = load i32, ptr %slot2256, align 8
  %cv12584 = zext i32 %v12583 to i64
  %cond12585 = icmp ne i64 %cv12584, 0
  br i1 %cond12585, label %bb_rcmoveheader2912, label %bb_rcmovenext2912
bb_rcmoveheader2912:
  %v12586 = load i64, ptr %slot2255, align 8
  %op12587 = sub i64 %v12586, 16
  store i64 %op12587, ptr %slot2257, align 8
  %v12588 = load i64, ptr %slot2255, align 8
  %p12589 = inttoptr i64 %v12588 to ptr
  %rgep12590 = getelementptr i8, ptr %p12589, i64 -16
  %ld12591 = load i64, ptr %rgep12590, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12591, ptr %slot2258, align 8
  %v12592 = load i64, ptr %slot2258, align 8
  %op12593 = and i64 %v12592, 5764607523034234881
  store i64 %op12593, ptr %slot2259, align 8
  %v12594 = load i64, ptr %slot2259, align 8
  %cmp12595 = icmp ne i64 %v12594, 0
  %cv12596 = zext i1 %cmp12595 to i32
  store i32 %cv12596, ptr %slot2260, align 8
  %v12597 = load i32, ptr %slot2260, align 8
  %cv12598 = zext i32 %v12597 to i64
  %cond12599 = icmp ne i64 %cv12598, 0
  br i1 %cond12599, label %bb_rcmoveslow2904, label %bb_rcmovenext2912
bb_rcmovenext2912:
  %v12600 = load i64, ptr %slot2242, align 8
  %v12601 = load i64, ptr %slot2247, align 8
  %p12602 = inttoptr i64 %v12600 to ptr
  %p12603 = inttoptr i64 %v12601 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12603, ptr %p12602, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v12604 = load i64, ptr %slot2242, align 8
  %p12605 = inttoptr i64 %v12604 to ptr
  store i64 0, ptr %p12605, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2904
bb_rcmoveslow2904:
  %v12606 = load i64, ptr %slot110, align 8
  %v12607 = load i64, ptr %slot2247, align 8
  %v12608 = load i64, ptr %slot2242, align 8
  %v12609 = load i64, ptr %slot2248, align 8
  %cv12610 = trunc i64 %v12609 to i32
  %call12611 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v12606, i64 %v12607, i64 %v12608, i32 %cv12610) nomerge, !dbg !170
  store i32 %call12611, ptr %slot2261, align 8
  %v12612 = load i32, ptr %slot2261, align 8
  %cv12613 = zext i32 %v12612 to i64
  %cond12614 = icmp ne i64 %cv12613, 0
  br i1 %cond12614, label %bb_rcsuccess2919, label %bb_rcfailure2919
bb_rcfailure2919:
  %v12615 = load i64, ptr %slot110, align 8
  %p12616 = inttoptr i64 %v12615 to ptr
  %call12617 = call i32 @myl_rc_take_failure(ptr %p12616) nomerge, !dbg !170
  store i32 %call12617, ptr %slot2262, align 8
  %v12618 = load i64, ptr %slot1, align 8
  %p12619 = inttoptr i64 %v12618 to ptr
  %v12620 = load i32, ptr %slot2262, align 8
  %call12621 = call i32 @myl_qbe_rc_status(ptr %p12619, i32 %v12620) nomerge, !dbg !170
  store i32 %call12621, ptr %slot2263, align 8
  br label %bb_failure
bb_rcsuccess2919:
  br label %bb_rcmoved2904
bb_rcmoved2904:
  %v12622 = load i64, ptr %slot44, align 8
  %p12623 = inttoptr i64 %v12622 to ptr
  store i32 0, ptr %p12623, align 4, !alias.scope !3, !noalias !4
  %v12624 = load i64, ptr %slot47, align 8
  %p12625 = inttoptr i64 %v12624 to ptr
  store i32 2, ptr %p12625, align 4, !alias.scope !3, !noalias !4
  %v12626 = load i64, ptr %slot46, align 8
  %p12627 = inttoptr i64 %v12626 to ptr
  store i32 1, ptr %p12627, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2895
bb_rccopy2895:
  %v12628 = load i64, ptr %slot65, align 8
  store i64 %v12628, ptr %slot2264, align 8
  %v12629 = load i64, ptr %slot111, align 8
  store i64 %v12629, ptr %slot2265, align 8
  %v12630 = load i64, ptr %slot2242, align 8
  %p12631 = inttoptr i64 %v12630 to ptr
  %ld12632 = load i64, ptr %p12631, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12632, ptr %slot2266, align 8
  %v12633 = load i64, ptr %slot2266, align 8
  %cmp12634 = icmp ne i64 %v12633, 0
  %cv12635 = zext i1 %cmp12634 to i32
  store i32 %cv12635, ptr %slot2267, align 8
  %v12636 = load i32, ptr %slot2267, align 8
  %cv12637 = zext i32 %v12636 to i64
  %cond12638 = icmp ne i64 %cv12637, 0
  br i1 %cond12638, label %bb_rcgnn2928, label %bb_rcgplain2928
bb_rcgnn2928:
  %v12639 = load i64, ptr %slot2266, align 8
  %op12640 = sub i64 %v12639, 16
  store i64 %op12640, ptr %slot2268, align 8
  %v12641 = load i64, ptr %slot2266, align 8
  %p12642 = inttoptr i64 %v12641 to ptr
  %rgep12643 = getelementptr i8, ptr %p12642, i64 -16
  %ld12644 = load i64, ptr %rgep12643, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12644, ptr %slot2269, align 8
  %v12645 = load i64, ptr %slot2269, align 8
  %op12646 = and i64 %v12645, 4611686018427387906
  store i64 %op12646, ptr %slot2270, align 8
  %v12647 = load i64, ptr %slot2270, align 8
  %cmp12648 = icmp ne i64 %v12647, 0
  %cv12649 = zext i1 %cmp12648 to i32
  store i32 %cv12649, ptr %slot2271, align 8
  %v12650 = load i32, ptr %slot2271, align 8
  %cv12651 = zext i32 %v12650 to i64
  %cond12652 = icmp ne i64 %cv12651, 0
  br i1 %cond12652, label %bb_rcgspecial2928, label %bb_rcginc2928
bb_rcginc2928:
  %v12653 = load i64, ptr %slot2266, align 8
  %op12654 = sub i64 %v12653, 32
  store i64 %op12654, ptr %slot2272, align 8
  %v12655 = load i64, ptr %slot2266, align 8
  %p12656 = inttoptr i64 %v12655 to ptr
  %rgep12657 = getelementptr i8, ptr %p12656, i64 -32
  %ld12658 = load i64, ptr %rgep12657, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12658, ptr %slot2273, align 8
  %v12659 = load i64, ptr %slot2273, align 8
  %op12660 = add i64 %v12659, 1
  store i64 %op12660, ptr %slot2274, align 8
  %v12661 = load i64, ptr %slot2274, align 8
  %cmp12662 = icmp eq i64 %v12661, 0
  %cv12663 = zext i1 %cmp12662 to i32
  store i32 %cv12663, ptr %slot2275, align 8
  %v12664 = load i32, ptr %slot2275, align 8
  %cv12665 = zext i32 %v12664 to i64
  %cond12666 = icmp ne i64 %cv12665, 0
  br i1 %cond12666, label %bb_rcglimit2928, label %bb_rcgcapacity2928
bb_rcglimit2928:
  %v12667 = load i64, ptr %slot1, align 8
  %p12668 = inttoptr i64 %v12667 to ptr
  %call12669 = call i32 @myl_qbe_rc_status(ptr %p12668, i32 2) nomerge, !dbg !170
  store i32 %call12669, ptr %slot2276, align 8
  br label %bb_failure
bb_rcgcapacity2928:
  %v12670 = load i64, ptr %slot2274, align 8
  %v12671 = load i64, ptr %slot2266, align 8
  %p12672 = inttoptr i64 %v12671 to ptr
  %rgep12673 = getelementptr i8, ptr %p12672, i64 -32
  store i64 %v12670, ptr %rgep12673, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2928
bb_rcgspecial2928:
  %v12674 = load i64, ptr %slot2269, align 8
  %op12675 = and i64 %v12674, 4611686018427387904
  store i64 %op12675, ptr %slot2277, align 8
  %v12676 = load i64, ptr %slot2277, align 8
  %cmp12677 = icmp ne i64 %v12676, 0
  %cv12678 = zext i1 %cmp12677 to i32
  store i32 %cv12678, ptr %slot2278, align 8
  %v12679 = load i32, ptr %slot2278, align 8
  %cv12680 = zext i32 %v12679 to i64
  %cond12681 = icmp ne i64 %cv12680, 0
  br i1 %cond12681, label %bb_rcgslow2928, label %bb_rcgplain2928
bb_rcgslow2928:
  %v12682 = load i64, ptr %slot110, align 8
  %v12683 = load i64, ptr %slot2264, align 8
  %v12684 = load i64, ptr %slot2242, align 8
  %v12685 = load i64, ptr %slot2265, align 8
  %cv12686 = trunc i64 %v12685 to i32
  %call12687 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v12682, i64 %v12683, i64 %v12684, i32 %cv12686) nomerge, !dbg !170
  store i32 %call12687, ptr %slot2279, align 8
  %v12688 = load i32, ptr %slot2279, align 8
  %cv12689 = zext i32 %v12688 to i64
  %cond12690 = icmp ne i64 %cv12689, 0
  br i1 %cond12690, label %bb_rcsuccess2942, label %bb_rcfailure2942
bb_rcfailure2942:
  %v12691 = load i64, ptr %slot110, align 8
  %p12692 = inttoptr i64 %v12691 to ptr
  %call12693 = call i32 @myl_rc_take_failure(ptr %p12692) nomerge, !dbg !170
  store i32 %call12693, ptr %slot2280, align 8
  %v12694 = load i64, ptr %slot1, align 8
  %p12695 = inttoptr i64 %v12694 to ptr
  %v12696 = load i32, ptr %slot2280, align 8
  %call12697 = call i32 @myl_qbe_rc_status(ptr %p12695, i32 %v12696) nomerge, !dbg !170
  store i32 %call12697, ptr %slot2281, align 8
  br label %bb_failure
bb_rcsuccess2942:
  br label %bb_rcgdone2928
bb_rcgplain2928:
  %v12698 = load i64, ptr %slot2266, align 8
  %v12699 = load i64, ptr %slot2264, align 8
  %p12700 = inttoptr i64 %v12699 to ptr
  store i64 %v12698, ptr %p12700, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2928
bb_rcgdone2928:
  %v12701 = load i64, ptr %slot47, align 8
  %p12702 = inttoptr i64 %v12701 to ptr
  store i32 2, ptr %p12702, align 4, !alias.scope !3, !noalias !4
  %v12703 = load i64, ptr %slot46, align 8
  %p12704 = inttoptr i64 %v12703 to ptr
  store i32 1, ptr %p12704, align 4, !alias.scope !3, !noalias !4
  %v12705 = load i64, ptr %slot44, align 8
  %p12706 = inttoptr i64 %v12705 to ptr
  %ld12707 = load i32, ptr %p12706, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12707, ptr %slot2282, align 8
  %v12708 = load i32, ptr %slot2282, align 8
  %cv12709 = zext i32 %v12708 to i64
  %cond12710 = icmp ne i64 %cv12709, 0
  br i1 %cond12710, label %bb_rcslotdrop2949, label %bb_rcslotdone2949
bb_rcslotdrop2949:
  %v12711 = load i64, ptr %slot44, align 8
  %p12712 = inttoptr i64 %v12711 to ptr
  store i32 0, ptr %p12712, align 4, !alias.scope !3, !noalias !4
  %v12713 = load i64, ptr %slot56, align 8
  store i64 %v12713, ptr %slot2283, align 8
  %v12714 = load i64, ptr %slot45, align 8
  %p12715 = inttoptr i64 %v12714 to ptr
  %ld12716 = load i32, ptr %p12715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12716, ptr %slot2284, align 8
  %v12717 = load i32, ptr %slot2284, align 8
  %op12718 = and i32 %v12717, 28
  store i32 %op12718, ptr %slot2285, align 8
  %v12719 = load i32, ptr %slot2285, align 8
  %cv12720 = zext i32 %v12719 to i64
  %cond12721 = icmp ne i64 %cv12720, 0
  br i1 %cond12721, label %bb_rcslotrole2949, label %bb_rcslotowner2949
bb_rcslotrole2949:
  %v12722 = load i64, ptr %slot110, align 8
  store i64 %v12722, ptr %slot2286, align 8
  %v12723 = load i64, ptr %slot2283, align 8
  %p12724 = inttoptr i64 %v12723 to ptr
  %ld12725 = load i64, ptr %p12724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12725, ptr %slot2287, align 8
  %v12726 = load i64, ptr %slot2287, align 8
  %cmp12727 = icmp ne i64 %v12726, 0
  %cv12728 = zext i1 %cmp12727 to i32
  store i32 %cv12728, ptr %slot2288, align 8
  %v12729 = load i32, ptr %slot2288, align 8
  %cv12730 = zext i32 %v12729 to i64
  %cond12731 = icmp ne i64 %cv12730, 0
  br i1 %cond12731, label %bb_rcgnn2965, label %bb_rcgdone2965
bb_rcgnn2965:
  %v12732 = load i64, ptr %slot2287, align 8
  %op12733 = sub i64 %v12732, 16
  store i64 %op12733, ptr %slot2289, align 8
  %v12734 = load i64, ptr %slot2287, align 8
  %p12735 = inttoptr i64 %v12734 to ptr
  %rgep12736 = getelementptr i8, ptr %p12735, i64 -16
  %ld12737 = load i64, ptr %rgep12736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12737, ptr %slot2290, align 8
  %v12738 = load i64, ptr %slot2290, align 8
  %op12739 = and i64 %v12738, 4611686018427387906
  store i64 %op12739, ptr %slot2291, align 8
  %v12740 = load i64, ptr %slot2291, align 8
  %cmp12741 = icmp ne i64 %v12740, 0
  %cv12742 = zext i1 %cmp12741 to i32
  store i32 %cv12742, ptr %slot2292, align 8
  %v12743 = load i32, ptr %slot2292, align 8
  %cv12744 = zext i32 %v12743 to i64
  %cond12745 = icmp ne i64 %cv12744, 0
  br i1 %cond12745, label %bb_rcgclear2965, label %bb_rcgcounted2965
bb_rcgcounted2965:
  %v12746 = load i64, ptr %slot2287, align 8
  %op12747 = sub i64 %v12746, 24
  store i64 %op12747, ptr %slot2293, align 8
  %v12748 = load i64, ptr %slot2287, align 8
  %p12749 = inttoptr i64 %v12748 to ptr
  %rgep12750 = getelementptr i8, ptr %p12749, i64 -24
  %ld12751 = load i64, ptr %rgep12750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12751, ptr %slot2294, align 8
  %v12752 = load i64, ptr %slot2294, align 8
  %op12753 = sub i64 %v12752, 1
  store i64 %op12753, ptr %slot2295, align 8
  %v12754 = load i64, ptr %slot2295, align 8
  %cmp12755 = icmp eq i64 %v12754, 0
  %cv12756 = zext i1 %cmp12755 to i32
  store i32 %cv12756, ptr %slot2296, align 8
  %v12757 = load i32, ptr %slot2296, align 8
  %cv12758 = zext i32 %v12757 to i64
  %cond12759 = icmp ne i64 %cv12758, 0
  br i1 %cond12759, label %bb_rcglast2965, label %bb_rcgdec2965
bb_rcglast2965:
  %v12760 = load i64, ptr %slot2287, align 8
  %op12761 = sub i64 %v12760, 32
  store i64 %op12761, ptr %slot2297, align 8
  %v12762 = load i64, ptr %slot2287, align 8
  %p12763 = inttoptr i64 %v12762 to ptr
  %rgep12764 = getelementptr i8, ptr %p12763, i64 -32
  %ld12765 = load i64, ptr %rgep12764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12765, ptr %slot2298, align 8
  %v12766 = load i64, ptr %slot2298, align 8
  %cmp12767 = icmp ne i64 %v12766, 0
  %cv12768 = zext i1 %cmp12767 to i32
  store i32 %cv12768, ptr %slot2299, align 8
  %v12769 = load i32, ptr %slot2299, align 8
  %cv12770 = zext i32 %v12769 to i64
  %cond12771 = icmp ne i64 %cv12770, 0
  br i1 %cond12771, label %bb_rcgdec2965, label %bb_rcgslow2965
bb_rcgslow2965:
  %v12772 = load i64, ptr %slot2286, align 8
  %v12773 = load i64, ptr %slot2283, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v12772, i64 %v12773) nomerge, !dbg !170
  br label %bb_rcgdone2965
bb_rcgdec2965:
  %v12774 = load i64, ptr %slot2295, align 8
  %v12775 = load i64, ptr %slot2287, align 8
  %p12776 = inttoptr i64 %v12775 to ptr
  %rgep12777 = getelementptr i8, ptr %p12776, i64 -24
  store i64 %v12774, ptr %rgep12777, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2965
bb_rcgclear2965:
  %v12778 = load i64, ptr %slot2283, align 8
  %p12779 = inttoptr i64 %v12778 to ptr
  store i64 0, ptr %p12779, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2965
bb_rcgdone2965:
  br label %bb_rcslotdone2949
bb_rcslotowner2949:
  %v12780 = load i64, ptr %slot110, align 8
  store i64 %v12780, ptr %slot2300, align 8
  %v12781 = load i64, ptr %slot2283, align 8
  %p12782 = inttoptr i64 %v12781 to ptr
  %ld12783 = load i64, ptr %p12782, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12783, ptr %slot2301, align 8
  %v12784 = load i64, ptr %slot2301, align 8
  %cmp12785 = icmp ne i64 %v12784, 0
  %cv12786 = zext i1 %cmp12785 to i32
  store i32 %cv12786, ptr %slot2302, align 8
  %v12787 = load i32, ptr %slot2302, align 8
  %cv12788 = zext i32 %v12787 to i64
  %cond12789 = icmp ne i64 %cv12788, 0
  br i1 %cond12789, label %bb_rcgnn2980, label %bb_rcgdone2980
bb_rcgnn2980:
  %v12790 = load i64, ptr %slot2301, align 8
  %op12791 = sub i64 %v12790, 16
  store i64 %op12791, ptr %slot2303, align 8
  %v12792 = load i64, ptr %slot2301, align 8
  %p12793 = inttoptr i64 %v12792 to ptr
  %rgep12794 = getelementptr i8, ptr %p12793, i64 -16
  %ld12795 = load i64, ptr %rgep12794, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12795, ptr %slot2304, align 8
  %v12796 = load i64, ptr %slot2304, align 8
  %op12797 = and i64 %v12796, 4611686018427387906
  store i64 %op12797, ptr %slot2305, align 8
  %v12798 = load i64, ptr %slot2305, align 8
  %cmp12799 = icmp ne i64 %v12798, 0
  %cv12800 = zext i1 %cmp12799 to i32
  store i32 %cv12800, ptr %slot2306, align 8
  %v12801 = load i32, ptr %slot2306, align 8
  %cv12802 = zext i32 %v12801 to i64
  %cond12803 = icmp ne i64 %cv12802, 0
  br i1 %cond12803, label %bb_rcgclear2980, label %bb_rcgcounted2980
bb_rcgcounted2980:
  %v12804 = load i64, ptr %slot2301, align 8
  %op12805 = sub i64 %v12804, 32
  store i64 %op12805, ptr %slot2307, align 8
  %v12806 = load i64, ptr %slot2301, align 8
  %p12807 = inttoptr i64 %v12806 to ptr
  %rgep12808 = getelementptr i8, ptr %p12807, i64 -32
  %ld12809 = load i64, ptr %rgep12808, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12809, ptr %slot2308, align 8
  %v12810 = load i64, ptr %slot2308, align 8
  %op12811 = sub i64 %v12810, 1
  store i64 %op12811, ptr %slot2309, align 8
  %v12812 = load i64, ptr %slot2309, align 8
  %cmp12813 = icmp eq i64 %v12812, 0
  %cv12814 = zext i1 %cmp12813 to i32
  store i32 %cv12814, ptr %slot2310, align 8
  %v12815 = load i32, ptr %slot2310, align 8
  %cv12816 = zext i32 %v12815 to i64
  %cond12817 = icmp ne i64 %cv12816, 0
  br i1 %cond12817, label %bb_rcglast2980, label %bb_rcgdec2980
bb_rcglast2980:
  %v12818 = load i64, ptr %slot2301, align 8
  %op12819 = sub i64 %v12818, 24
  store i64 %op12819, ptr %slot2311, align 8
  %v12820 = load i64, ptr %slot2301, align 8
  %p12821 = inttoptr i64 %v12820 to ptr
  %rgep12822 = getelementptr i8, ptr %p12821, i64 -24
  %ld12823 = load i64, ptr %rgep12822, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12823, ptr %slot2312, align 8
  %v12824 = load i64, ptr %slot2312, align 8
  %cmp12825 = icmp ne i64 %v12824, 0
  %cv12826 = zext i1 %cmp12825 to i32
  store i32 %cv12826, ptr %slot2313, align 8
  %v12827 = load i32, ptr %slot2313, align 8
  %cv12828 = zext i32 %v12827 to i64
  %cond12829 = icmp ne i64 %cv12828, 0
  br i1 %cond12829, label %bb_rcgdec2980, label %bb_rcgslow2980
bb_rcgslow2980:
  %v12830 = load i64, ptr %slot2300, align 8
  %v12831 = load i64, ptr %slot2283, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v12830, i64 %v12831) nomerge, !dbg !170
  br label %bb_rcgdone2980
bb_rcgdec2980:
  %v12832 = load i64, ptr %slot2309, align 8
  %v12833 = load i64, ptr %slot2301, align 8
  %p12834 = inttoptr i64 %v12833 to ptr
  %rgep12835 = getelementptr i8, ptr %p12834, i64 -32
  store i64 %v12832, ptr %rgep12835, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2980
bb_rcgclear2980:
  %v12836 = load i64, ptr %slot2283, align 8
  %p12837 = inttoptr i64 %v12836 to ptr
  store i64 0, ptr %p12837, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2980
bb_rcgdone2980:
  br label %bb_rcslotdone2949
bb_rcslotdone2949:
  br label %bb_rcprepared2895
bb_rcprepared2895:
  %v12838 = load i64, ptr %slot65, align 8
  store i64 %v12838, ptr %slot2314, align 8
  %v12839 = load i64, ptr %slot2314, align 8
  %v12840 = load i64, ptr %slot2240, align 8
  %p12841 = inttoptr i64 %v12839 to ptr
  %p12842 = inttoptr i64 %v12840 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12842, ptr %p12841, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v12843 = load i64, ptr %slot46, align 8
  %p12844 = inttoptr i64 %v12843 to ptr
  store i32 0, ptr %p12844, align 4, !alias.scope !3, !noalias !4
  %v12845 = load i64, ptr %slot101, align 8
  %p12846 = inttoptr i64 %v12845 to ptr
  %ld12847 = load i64, ptr %p12846, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12847, ptr %slot2315, align 8
  %v12848 = load i64, ptr %slot1687, align 8
  %p12850 = inttoptr i64 %v12848 to ptr
  %gep12851 = getelementptr i8, ptr %p12850, i64 192
  %op12849 = ptrtoint ptr %gep12851 to i64
  store i64 %op12849, ptr %slot2316, align 8
  %v12852 = load i64, ptr %slot2315, align 8
  %v12853 = load i64, ptr %slot2316, align 8
  %p12854 = inttoptr i64 %v12852 to ptr
  %p12855 = inttoptr i64 %v12853 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12855, ptr %p12854, i64 16, i1 false), !alias.scope !10000000
  %v12856 = load i64, ptr %slot1687, align 8
  %v12857 = load i64, ptr %slot80, align 8
  %p12858 = inttoptr i64 %v12857 to ptr
  store i64 %v12856, ptr %p12858, align 8, !alias.scope !3, !noalias !4
  %v12859 = load i64, ptr %slot80, align 8
  %p12860 = inttoptr i64 %v12859 to ptr
  %ld12861 = load i64, ptr %p12860, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12861, ptr %slot2317, align 8
  %v12862 = load i64, ptr %slot49, align 8
  store i64 %v12862, ptr %slot2318, align 8
  %v12863 = load i64, ptr %slot2317, align 8
  %v12864 = load i64, ptr %slot2318, align 8
  %p12865 = inttoptr i64 %v12863 to ptr
  %p12866 = inttoptr i64 %v12864 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12866, ptr %p12865, i64 208, i1 false)
  %v12867 = load i64, ptr %slot29, align 8
  %p12868 = inttoptr i64 %v12867 to ptr
  store i32 2, ptr %p12868, align 4, !alias.scope !3, !noalias !4
  %v12869 = load i64, ptr %slot28, align 8
  %p12870 = inttoptr i64 %v12869 to ptr
  store i32 1, ptr %p12870, align 4, !alias.scope !3, !noalias !4
  %v12871 = load i64, ptr %slot2318, align 8
  %v12872 = load i64, ptr %slot80, align 8
  %p12873 = inttoptr i64 %v12872 to ptr
  store i64 %v12871, ptr %p12873, align 8, !alias.scope !3, !noalias !4
  %v12874 = load i64, ptr %slot80, align 8
  %p12875 = inttoptr i64 %v12874 to ptr
  %ld12876 = load i64, ptr %p12875, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12876, ptr %slot2319, align 8
  %v12877 = load i64, ptr %slot80, align 8
  %p12878 = inttoptr i64 %v12877 to ptr
  %ld12879 = load i64, ptr %p12878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12879, ptr %slot2320, align 8
  %v12880 = load i64, ptr %slot65, align 8
  store i64 %v12880, ptr %slot2321, align 8
  %v12881 = load i64, ptr %slot111, align 8
  store i64 %v12881, ptr %slot2322, align 8
  %v12882 = load i64, ptr %slot110, align 8
  %v12883 = load i64, ptr %slot2321, align 8
  %v12884 = load i64, ptr %slot2320, align 8
  %v12885 = load i64, ptr %slot2322, align 8
  %cv12886 = trunc i64 %v12885 to i32
  %call12887 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64 %v12882, i64 %v12883, i64 %v12884, i32 %cv12886) nomerge, !dbg !172
  store i32 %call12887, ptr %slot2323, align 8
  %v12888 = load i32, ptr %slot2323, align 8
  %cv12889 = zext i32 %v12888 to i64
  %cond12890 = icmp ne i64 %cv12889, 0
  br i1 %cond12890, label %bb_rcsuccess2997, label %bb_rcfailure2997
bb_rcfailure2997:
  %v12891 = load i64, ptr %slot110, align 8
  %p12892 = inttoptr i64 %v12891 to ptr
  %call12893 = call i32 @myl_rc_take_failure(ptr %p12892) nomerge, !dbg !172
  store i32 %call12893, ptr %slot2324, align 8
  %v12894 = load i64, ptr %slot1, align 8
  %p12895 = inttoptr i64 %v12894 to ptr
  %v12896 = load i32, ptr %slot2324, align 8
  %call12897 = call i32 @myl_qbe_rc_status(ptr %p12895, i32 %v12896) nomerge, !dbg !172
  store i32 %call12897, ptr %slot2325, align 8
  br label %bb_failure
bb_rcsuccess2997:
  %v12898 = load i64, ptr %slot28, align 8
  %p12899 = inttoptr i64 %v12898 to ptr
  store i32 0, ptr %p12899, align 4, !alias.scope !3, !noalias !4
  %v12900 = load i64, ptr %slot47, align 8
  %p12901 = inttoptr i64 %v12900 to ptr
  store i32 2, ptr %p12901, align 4, !alias.scope !3, !noalias !4
  %v12902 = load i64, ptr %slot46, align 8
  %p12903 = inttoptr i64 %v12902 to ptr
  store i32 1, ptr %p12903, align 4, !alias.scope !3, !noalias !4
  %v12904 = load i64, ptr %slot65, align 8
  store i64 %v12904, ptr %slot2326, align 8
  %v12905 = load i64, ptr %slot46, align 8
  %p12906 = inttoptr i64 %v12905 to ptr
  store i32 0, ptr %p12906, align 4, !alias.scope !3, !noalias !4
  %v12907 = load i64, ptr %slot28, align 8
  %p12908 = inttoptr i64 %v12907 to ptr
  %ld12909 = load i32, ptr %p12908, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12909, ptr %slot2327, align 8
  %v12910 = load i32, ptr %slot2327, align 8
  %cv12911 = zext i32 %v12910 to i64
  %cond12912 = icmp ne i64 %cv12911, 0
  br i1 %cond12912, label %bb_rcslotdrop3007, label %bb_rcslotdone3007
bb_rcslotdrop3007:
  %v12913 = load i64, ptr %slot28, align 8
  %p12914 = inttoptr i64 %v12913 to ptr
  store i32 0, ptr %p12914, align 4, !alias.scope !3, !noalias !4
  %v12915 = load i64, ptr %slot49, align 8
  store i64 %v12915, ptr %slot2328, align 8
  %v12916 = load i64, ptr %slot29, align 8
  %p12917 = inttoptr i64 %v12916 to ptr
  %ld12918 = load i32, ptr %p12917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12918, ptr %slot2329, align 8
  %v12919 = load i32, ptr %slot2329, align 8
  %op12920 = and i32 %v12919, 28
  store i32 %op12920, ptr %slot2330, align 8
  %v12921 = load i32, ptr %slot2330, align 8
  %cv12922 = zext i32 %v12921 to i64
  %cond12923 = icmp ne i64 %cv12922, 0
  br i1 %cond12923, label %bb_rcslotrole3007, label %bb_rcslotowner3007
bb_rcslotrole3007:
  %v12924 = load i64, ptr %slot110, align 8
  store i64 %v12924, ptr %slot2331, align 8
  %v12925 = load i64, ptr %slot2331, align 8
  %v12926 = load i64, ptr %slot2328, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12925, i64 %v12926) nomerge, !dbg !172
  br label %bb_rcslotdone3007
bb_rcslotowner3007:
  %v12927 = load i64, ptr %slot110, align 8
  store i64 %v12927, ptr %slot2332, align 8
  %v12928 = load i64, ptr %slot2332, align 8
  %v12929 = load i64, ptr %slot2328, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12928, i64 %v12929) nomerge, !dbg !172
  br label %bb_rcslotdone3007
bb_rcslotdone3007:
  %v12930 = load i64, ptr %slot26, align 8
  %p12931 = inttoptr i64 %v12930 to ptr
  %ld12932 = load i32, ptr %p12931, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12932, ptr %slot2333, align 8
  %v12933 = load i32, ptr %slot2333, align 8
  %cv12934 = zext i32 %v12933 to i64
  %cond12935 = icmp ne i64 %cv12934, 0
  br i1 %cond12935, label %bb_rcslotdrop3016, label %bb_rcslotdone3016
bb_rcslotdrop3016:
  %v12936 = load i64, ptr %slot26, align 8
  %p12937 = inttoptr i64 %v12936 to ptr
  store i32 0, ptr %p12937, align 4, !alias.scope !3, !noalias !4
  %v12938 = load i64, ptr %slot79, align 8
  store i64 %v12938, ptr %slot2334, align 8
  %v12939 = load i64, ptr %slot27, align 8
  %p12940 = inttoptr i64 %v12939 to ptr
  %ld12941 = load i32, ptr %p12940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12941, ptr %slot2335, align 8
  %v12942 = load i32, ptr %slot2335, align 8
  %op12943 = and i32 %v12942, 28
  store i32 %op12943, ptr %slot2336, align 8
  %v12944 = load i32, ptr %slot2336, align 8
  %cv12945 = zext i32 %v12944 to i64
  %cond12946 = icmp ne i64 %cv12945, 0
  br i1 %cond12946, label %bb_rcslotrole3016, label %bb_rcslotowner3016
bb_rcslotrole3016:
  %v12947 = load i64, ptr %slot110, align 8
  store i64 %v12947, ptr %slot2337, align 8
  %v12948 = load i64, ptr %slot2334, align 8
  %p12949 = inttoptr i64 %v12948 to ptr
  %ld12950 = load i64, ptr %p12949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12950, ptr %slot2338, align 8
  %v12951 = load i64, ptr %slot2338, align 8
  %cmp12952 = icmp ne i64 %v12951, 0
  %cv12953 = zext i1 %cmp12952 to i32
  store i32 %cv12953, ptr %slot2339, align 8
  %v12954 = load i32, ptr %slot2339, align 8
  %cv12955 = zext i32 %v12954 to i64
  %cond12956 = icmp ne i64 %cv12955, 0
  br i1 %cond12956, label %bb_rcgnn3032, label %bb_rcgdone3032
bb_rcgnn3032:
  %v12957 = load i64, ptr %slot2338, align 8
  %op12958 = sub i64 %v12957, 16
  store i64 %op12958, ptr %slot2340, align 8
  %v12959 = load i64, ptr %slot2338, align 8
  %p12960 = inttoptr i64 %v12959 to ptr
  %rgep12961 = getelementptr i8, ptr %p12960, i64 -16
  %ld12962 = load i64, ptr %rgep12961, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12962, ptr %slot2341, align 8
  %v12963 = load i64, ptr %slot2341, align 8
  %op12964 = and i64 %v12963, 4611686018427387906
  store i64 %op12964, ptr %slot2342, align 8
  %v12965 = load i64, ptr %slot2342, align 8
  %cmp12966 = icmp ne i64 %v12965, 0
  %cv12967 = zext i1 %cmp12966 to i32
  store i32 %cv12967, ptr %slot2343, align 8
  %v12968 = load i32, ptr %slot2343, align 8
  %cv12969 = zext i32 %v12968 to i64
  %cond12970 = icmp ne i64 %cv12969, 0
  br i1 %cond12970, label %bb_rcgclear3032, label %bb_rcgcounted3032
bb_rcgcounted3032:
  %v12971 = load i64, ptr %slot2338, align 8
  %op12972 = sub i64 %v12971, 24
  store i64 %op12972, ptr %slot2344, align 8
  %v12973 = load i64, ptr %slot2338, align 8
  %p12974 = inttoptr i64 %v12973 to ptr
  %rgep12975 = getelementptr i8, ptr %p12974, i64 -24
  %ld12976 = load i64, ptr %rgep12975, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12976, ptr %slot2345, align 8
  %v12977 = load i64, ptr %slot2345, align 8
  %op12978 = sub i64 %v12977, 1
  store i64 %op12978, ptr %slot2346, align 8
  %v12979 = load i64, ptr %slot2346, align 8
  %cmp12980 = icmp eq i64 %v12979, 0
  %cv12981 = zext i1 %cmp12980 to i32
  store i32 %cv12981, ptr %slot2347, align 8
  %v12982 = load i32, ptr %slot2347, align 8
  %cv12983 = zext i32 %v12982 to i64
  %cond12984 = icmp ne i64 %cv12983, 0
  br i1 %cond12984, label %bb_rcglast3032, label %bb_rcgdec3032
bb_rcglast3032:
  %v12985 = load i64, ptr %slot2338, align 8
  %op12986 = sub i64 %v12985, 32
  store i64 %op12986, ptr %slot2348, align 8
  %v12987 = load i64, ptr %slot2338, align 8
  %p12988 = inttoptr i64 %v12987 to ptr
  %rgep12989 = getelementptr i8, ptr %p12988, i64 -32
  %ld12990 = load i64, ptr %rgep12989, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12990, ptr %slot2349, align 8
  %v12991 = load i64, ptr %slot2349, align 8
  %cmp12992 = icmp ne i64 %v12991, 0
  %cv12993 = zext i1 %cmp12992 to i32
  store i32 %cv12993, ptr %slot2350, align 8
  %v12994 = load i32, ptr %slot2350, align 8
  %cv12995 = zext i32 %v12994 to i64
  %cond12996 = icmp ne i64 %cv12995, 0
  br i1 %cond12996, label %bb_rcgdec3032, label %bb_rcgslow3032
bb_rcgslow3032:
  %v12997 = load i64, ptr %slot2337, align 8
  %v12998 = load i64, ptr %slot2334, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v12997, i64 %v12998) nomerge, !dbg !172
  br label %bb_rcgdone3032
bb_rcgdec3032:
  %v12999 = load i64, ptr %slot2346, align 8
  %v13000 = load i64, ptr %slot2338, align 8
  %p13001 = inttoptr i64 %v13000 to ptr
  %rgep13002 = getelementptr i8, ptr %p13001, i64 -24
  store i64 %v12999, ptr %rgep13002, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3032
bb_rcgclear3032:
  %v13003 = load i64, ptr %slot2334, align 8
  %p13004 = inttoptr i64 %v13003 to ptr
  store i64 0, ptr %p13004, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3032
bb_rcgdone3032:
  br label %bb_rcslotdone3016
bb_rcslotowner3016:
  %v13005 = load i64, ptr %slot110, align 8
  store i64 %v13005, ptr %slot2351, align 8
  %v13006 = load i64, ptr %slot2334, align 8
  %p13007 = inttoptr i64 %v13006 to ptr
  %ld13008 = load i64, ptr %p13007, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13008, ptr %slot2352, align 8
  %v13009 = load i64, ptr %slot2352, align 8
  %cmp13010 = icmp ne i64 %v13009, 0
  %cv13011 = zext i1 %cmp13010 to i32
  store i32 %cv13011, ptr %slot2353, align 8
  %v13012 = load i32, ptr %slot2353, align 8
  %cv13013 = zext i32 %v13012 to i64
  %cond13014 = icmp ne i64 %cv13013, 0
  br i1 %cond13014, label %bb_rcgnn3047, label %bb_rcgdone3047
bb_rcgnn3047:
  %v13015 = load i64, ptr %slot2352, align 8
  %op13016 = sub i64 %v13015, 16
  store i64 %op13016, ptr %slot2354, align 8
  %v13017 = load i64, ptr %slot2352, align 8
  %p13018 = inttoptr i64 %v13017 to ptr
  %rgep13019 = getelementptr i8, ptr %p13018, i64 -16
  %ld13020 = load i64, ptr %rgep13019, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13020, ptr %slot2355, align 8
  %v13021 = load i64, ptr %slot2355, align 8
  %op13022 = and i64 %v13021, 4611686018427387906
  store i64 %op13022, ptr %slot2356, align 8
  %v13023 = load i64, ptr %slot2356, align 8
  %cmp13024 = icmp ne i64 %v13023, 0
  %cv13025 = zext i1 %cmp13024 to i32
  store i32 %cv13025, ptr %slot2357, align 8
  %v13026 = load i32, ptr %slot2357, align 8
  %cv13027 = zext i32 %v13026 to i64
  %cond13028 = icmp ne i64 %cv13027, 0
  br i1 %cond13028, label %bb_rcgclear3047, label %bb_rcgcounted3047
bb_rcgcounted3047:
  %v13029 = load i64, ptr %slot2352, align 8
  %op13030 = sub i64 %v13029, 32
  store i64 %op13030, ptr %slot2358, align 8
  %v13031 = load i64, ptr %slot2352, align 8
  %p13032 = inttoptr i64 %v13031 to ptr
  %rgep13033 = getelementptr i8, ptr %p13032, i64 -32
  %ld13034 = load i64, ptr %rgep13033, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13034, ptr %slot2359, align 8
  %v13035 = load i64, ptr %slot2359, align 8
  %op13036 = sub i64 %v13035, 1
  store i64 %op13036, ptr %slot2360, align 8
  %v13037 = load i64, ptr %slot2360, align 8
  %cmp13038 = icmp eq i64 %v13037, 0
  %cv13039 = zext i1 %cmp13038 to i32
  store i32 %cv13039, ptr %slot2361, align 8
  %v13040 = load i32, ptr %slot2361, align 8
  %cv13041 = zext i32 %v13040 to i64
  %cond13042 = icmp ne i64 %cv13041, 0
  br i1 %cond13042, label %bb_rcglast3047, label %bb_rcgdec3047
bb_rcglast3047:
  %v13043 = load i64, ptr %slot2352, align 8
  %op13044 = sub i64 %v13043, 24
  store i64 %op13044, ptr %slot2362, align 8
  %v13045 = load i64, ptr %slot2352, align 8
  %p13046 = inttoptr i64 %v13045 to ptr
  %rgep13047 = getelementptr i8, ptr %p13046, i64 -24
  %ld13048 = load i64, ptr %rgep13047, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13048, ptr %slot2363, align 8
  %v13049 = load i64, ptr %slot2363, align 8
  %cmp13050 = icmp ne i64 %v13049, 0
  %cv13051 = zext i1 %cmp13050 to i32
  store i32 %cv13051, ptr %slot2364, align 8
  %v13052 = load i32, ptr %slot2364, align 8
  %cv13053 = zext i32 %v13052 to i64
  %cond13054 = icmp ne i64 %cv13053, 0
  br i1 %cond13054, label %bb_rcgdec3047, label %bb_rcgslow3047
bb_rcgslow3047:
  %v13055 = load i64, ptr %slot2351, align 8
  %v13056 = load i64, ptr %slot2334, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v13055, i64 %v13056) nomerge, !dbg !172
  br label %bb_rcgdone3047
bb_rcgdec3047:
  %v13057 = load i64, ptr %slot2360, align 8
  %v13058 = load i64, ptr %slot2352, align 8
  %p13059 = inttoptr i64 %v13058 to ptr
  %rgep13060 = getelementptr i8, ptr %p13059, i64 -32
  store i64 %v13057, ptr %rgep13060, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3047
bb_rcgclear3047:
  %v13061 = load i64, ptr %slot2334, align 8
  %p13062 = inttoptr i64 %v13061 to ptr
  store i64 0, ptr %p13062, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3047
bb_rcgdone3047:
  br label %bb_rcslotdone3016
bb_rcslotdone3016:
  %v13063 = load i64, ptr %slot24, align 8
  %p13064 = inttoptr i64 %v13063 to ptr
  %ld13065 = load i32, ptr %p13064, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13065, ptr %slot2365, align 8
  %v13066 = load i32, ptr %slot2365, align 8
  %cv13067 = zext i32 %v13066 to i64
  %cond13068 = icmp ne i64 %cv13067, 0
  br i1 %cond13068, label %bb_rcslotdrop3053, label %bb_rcslotdone3053
bb_rcslotdrop3053:
  %v13069 = load i64, ptr %slot24, align 8
  %p13070 = inttoptr i64 %v13069 to ptr
  store i32 0, ptr %p13070, align 4, !alias.scope !3, !noalias !4
  %v13071 = load i64, ptr %slot78, align 8
  store i64 %v13071, ptr %slot2366, align 8
  %v13072 = load i64, ptr %slot25, align 8
  %p13073 = inttoptr i64 %v13072 to ptr
  %ld13074 = load i32, ptr %p13073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13074, ptr %slot2367, align 8
  %v13075 = load i32, ptr %slot2367, align 8
  %op13076 = and i32 %v13075, 28
  store i32 %op13076, ptr %slot2368, align 8
  %v13077 = load i32, ptr %slot2368, align 8
  %cv13078 = zext i32 %v13077 to i64
  %cond13079 = icmp ne i64 %cv13078, 0
  br i1 %cond13079, label %bb_rcslotrole3053, label %bb_rcslotowner3053
bb_rcslotrole3053:
  %v13080 = load i64, ptr %slot110, align 8
  store i64 %v13080, ptr %slot2369, align 8
  %v13081 = load i64, ptr %slot2366, align 8
  %p13082 = inttoptr i64 %v13081 to ptr
  %ld13083 = load i64, ptr %p13082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13083, ptr %slot2370, align 8
  %v13084 = load i64, ptr %slot2370, align 8
  %cmp13085 = icmp ne i64 %v13084, 0
  %cv13086 = zext i1 %cmp13085 to i32
  store i32 %cv13086, ptr %slot2371, align 8
  %v13087 = load i32, ptr %slot2371, align 8
  %cv13088 = zext i32 %v13087 to i64
  %cond13089 = icmp ne i64 %cv13088, 0
  br i1 %cond13089, label %bb_rcgnn3069, label %bb_rcgdone3069
bb_rcgnn3069:
  %v13090 = load i64, ptr %slot2370, align 8
  %op13091 = sub i64 %v13090, 16
  store i64 %op13091, ptr %slot2372, align 8
  %v13092 = load i64, ptr %slot2370, align 8
  %p13093 = inttoptr i64 %v13092 to ptr
  %rgep13094 = getelementptr i8, ptr %p13093, i64 -16
  %ld13095 = load i64, ptr %rgep13094, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13095, ptr %slot2373, align 8
  %v13096 = load i64, ptr %slot2373, align 8
  %op13097 = and i64 %v13096, 4611686018427387906
  store i64 %op13097, ptr %slot2374, align 8
  %v13098 = load i64, ptr %slot2374, align 8
  %cmp13099 = icmp ne i64 %v13098, 0
  %cv13100 = zext i1 %cmp13099 to i32
  store i32 %cv13100, ptr %slot2375, align 8
  %v13101 = load i32, ptr %slot2375, align 8
  %cv13102 = zext i32 %v13101 to i64
  %cond13103 = icmp ne i64 %cv13102, 0
  br i1 %cond13103, label %bb_rcgclear3069, label %bb_rcgcounted3069
bb_rcgcounted3069:
  %v13104 = load i64, ptr %slot2370, align 8
  %op13105 = sub i64 %v13104, 24
  store i64 %op13105, ptr %slot2376, align 8
  %v13106 = load i64, ptr %slot2370, align 8
  %p13107 = inttoptr i64 %v13106 to ptr
  %rgep13108 = getelementptr i8, ptr %p13107, i64 -24
  %ld13109 = load i64, ptr %rgep13108, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13109, ptr %slot2377, align 8
  %v13110 = load i64, ptr %slot2377, align 8
  %op13111 = sub i64 %v13110, 1
  store i64 %op13111, ptr %slot2378, align 8
  %v13112 = load i64, ptr %slot2378, align 8
  %cmp13113 = icmp eq i64 %v13112, 0
  %cv13114 = zext i1 %cmp13113 to i32
  store i32 %cv13114, ptr %slot2379, align 8
  %v13115 = load i32, ptr %slot2379, align 8
  %cv13116 = zext i32 %v13115 to i64
  %cond13117 = icmp ne i64 %cv13116, 0
  br i1 %cond13117, label %bb_rcglast3069, label %bb_rcgdec3069
bb_rcglast3069:
  %v13118 = load i64, ptr %slot2370, align 8
  %op13119 = sub i64 %v13118, 32
  store i64 %op13119, ptr %slot2380, align 8
  %v13120 = load i64, ptr %slot2370, align 8
  %p13121 = inttoptr i64 %v13120 to ptr
  %rgep13122 = getelementptr i8, ptr %p13121, i64 -32
  %ld13123 = load i64, ptr %rgep13122, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13123, ptr %slot2381, align 8
  %v13124 = load i64, ptr %slot2381, align 8
  %cmp13125 = icmp ne i64 %v13124, 0
  %cv13126 = zext i1 %cmp13125 to i32
  store i32 %cv13126, ptr %slot2382, align 8
  %v13127 = load i32, ptr %slot2382, align 8
  %cv13128 = zext i32 %v13127 to i64
  %cond13129 = icmp ne i64 %cv13128, 0
  br i1 %cond13129, label %bb_rcgdec3069, label %bb_rcgslow3069
bb_rcgslow3069:
  %v13130 = load i64, ptr %slot2369, align 8
  %v13131 = load i64, ptr %slot2366, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v13130, i64 %v13131) nomerge, !dbg !172
  br label %bb_rcgdone3069
bb_rcgdec3069:
  %v13132 = load i64, ptr %slot2378, align 8
  %v13133 = load i64, ptr %slot2370, align 8
  %p13134 = inttoptr i64 %v13133 to ptr
  %rgep13135 = getelementptr i8, ptr %p13134, i64 -24
  store i64 %v13132, ptr %rgep13135, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3069
bb_rcgclear3069:
  %v13136 = load i64, ptr %slot2366, align 8
  %p13137 = inttoptr i64 %v13136 to ptr
  store i64 0, ptr %p13137, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3069
bb_rcgdone3069:
  br label %bb_rcslotdone3053
bb_rcslotowner3053:
  %v13138 = load i64, ptr %slot110, align 8
  store i64 %v13138, ptr %slot2383, align 8
  %v13139 = load i64, ptr %slot2366, align 8
  %p13140 = inttoptr i64 %v13139 to ptr
  %ld13141 = load i64, ptr %p13140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13141, ptr %slot2384, align 8
  %v13142 = load i64, ptr %slot2384, align 8
  %cmp13143 = icmp ne i64 %v13142, 0
  %cv13144 = zext i1 %cmp13143 to i32
  store i32 %cv13144, ptr %slot2385, align 8
  %v13145 = load i32, ptr %slot2385, align 8
  %cv13146 = zext i32 %v13145 to i64
  %cond13147 = icmp ne i64 %cv13146, 0
  br i1 %cond13147, label %bb_rcgnn3084, label %bb_rcgdone3084
bb_rcgnn3084:
  %v13148 = load i64, ptr %slot2384, align 8
  %op13149 = sub i64 %v13148, 16
  store i64 %op13149, ptr %slot2386, align 8
  %v13150 = load i64, ptr %slot2384, align 8
  %p13151 = inttoptr i64 %v13150 to ptr
  %rgep13152 = getelementptr i8, ptr %p13151, i64 -16
  %ld13153 = load i64, ptr %rgep13152, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13153, ptr %slot2387, align 8
  %v13154 = load i64, ptr %slot2387, align 8
  %op13155 = and i64 %v13154, 4611686018427387906
  store i64 %op13155, ptr %slot2388, align 8
  %v13156 = load i64, ptr %slot2388, align 8
  %cmp13157 = icmp ne i64 %v13156, 0
  %cv13158 = zext i1 %cmp13157 to i32
  store i32 %cv13158, ptr %slot2389, align 8
  %v13159 = load i32, ptr %slot2389, align 8
  %cv13160 = zext i32 %v13159 to i64
  %cond13161 = icmp ne i64 %cv13160, 0
  br i1 %cond13161, label %bb_rcgclear3084, label %bb_rcgcounted3084
bb_rcgcounted3084:
  %v13162 = load i64, ptr %slot2384, align 8
  %op13163 = sub i64 %v13162, 32
  store i64 %op13163, ptr %slot2390, align 8
  %v13164 = load i64, ptr %slot2384, align 8
  %p13165 = inttoptr i64 %v13164 to ptr
  %rgep13166 = getelementptr i8, ptr %p13165, i64 -32
  %ld13167 = load i64, ptr %rgep13166, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13167, ptr %slot2391, align 8
  %v13168 = load i64, ptr %slot2391, align 8
  %op13169 = sub i64 %v13168, 1
  store i64 %op13169, ptr %slot2392, align 8
  %v13170 = load i64, ptr %slot2392, align 8
  %cmp13171 = icmp eq i64 %v13170, 0
  %cv13172 = zext i1 %cmp13171 to i32
  store i32 %cv13172, ptr %slot2393, align 8
  %v13173 = load i32, ptr %slot2393, align 8
  %cv13174 = zext i32 %v13173 to i64
  %cond13175 = icmp ne i64 %cv13174, 0
  br i1 %cond13175, label %bb_rcglast3084, label %bb_rcgdec3084
bb_rcglast3084:
  %v13176 = load i64, ptr %slot2384, align 8
  %op13177 = sub i64 %v13176, 24
  store i64 %op13177, ptr %slot2394, align 8
  %v13178 = load i64, ptr %slot2384, align 8
  %p13179 = inttoptr i64 %v13178 to ptr
  %rgep13180 = getelementptr i8, ptr %p13179, i64 -24
  %ld13181 = load i64, ptr %rgep13180, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13181, ptr %slot2395, align 8
  %v13182 = load i64, ptr %slot2395, align 8
  %cmp13183 = icmp ne i64 %v13182, 0
  %cv13184 = zext i1 %cmp13183 to i32
  store i32 %cv13184, ptr %slot2396, align 8
  %v13185 = load i32, ptr %slot2396, align 8
  %cv13186 = zext i32 %v13185 to i64
  %cond13187 = icmp ne i64 %cv13186, 0
  br i1 %cond13187, label %bb_rcgdec3084, label %bb_rcgslow3084
bb_rcgslow3084:
  %v13188 = load i64, ptr %slot2383, align 8
  %v13189 = load i64, ptr %slot2366, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v13188, i64 %v13189) nomerge, !dbg !172
  br label %bb_rcgdone3084
bb_rcgdec3084:
  %v13190 = load i64, ptr %slot2392, align 8
  %v13191 = load i64, ptr %slot2384, align 8
  %p13192 = inttoptr i64 %v13191 to ptr
  %rgep13193 = getelementptr i8, ptr %p13192, i64 -32
  store i64 %v13190, ptr %rgep13193, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3084
bb_rcgclear3084:
  %v13194 = load i64, ptr %slot2366, align 8
  %p13195 = inttoptr i64 %v13194 to ptr
  store i64 0, ptr %p13195, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3084
bb_rcgdone3084:
  br label %bb_rcslotdone3053
bb_rcslotdone3053:
  %v13196 = load i64, ptr %slot22, align 8
  %p13197 = inttoptr i64 %v13196 to ptr
  %ld13198 = load i32, ptr %p13197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13198, ptr %slot2397, align 8
  %v13199 = load i32, ptr %slot2397, align 8
  %cv13200 = zext i32 %v13199 to i64
  %cond13201 = icmp ne i64 %cv13200, 0
  br i1 %cond13201, label %bb_rcslotdrop3090, label %bb_rcslotdone3090
bb_rcslotdrop3090:
  %v13202 = load i64, ptr %slot22, align 8
  %p13203 = inttoptr i64 %v13202 to ptr
  store i32 0, ptr %p13203, align 4, !alias.scope !3, !noalias !4
  %v13204 = load i64, ptr %slot77, align 8
  store i64 %v13204, ptr %slot2398, align 8
  %v13205 = load i64, ptr %slot23, align 8
  %p13206 = inttoptr i64 %v13205 to ptr
  %ld13207 = load i32, ptr %p13206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13207, ptr %slot2399, align 8
  %v13208 = load i32, ptr %slot2399, align 8
  %op13209 = and i32 %v13208, 28
  store i32 %op13209, ptr %slot2400, align 8
  %v13210 = load i32, ptr %slot2400, align 8
  %cv13211 = zext i32 %v13210 to i64
  %cond13212 = icmp ne i64 %cv13211, 0
  br i1 %cond13212, label %bb_rcslotrole3090, label %bb_rcslotowner3090
bb_rcslotrole3090:
  %v13213 = load i64, ptr %slot110, align 8
  store i64 %v13213, ptr %slot2401, align 8
  %v13214 = load i64, ptr %slot2398, align 8
  %p13215 = inttoptr i64 %v13214 to ptr
  %ld13216 = load i64, ptr %p13215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13216, ptr %slot2402, align 8
  %v13217 = load i64, ptr %slot2402, align 8
  %cmp13218 = icmp ne i64 %v13217, 0
  %cv13219 = zext i1 %cmp13218 to i32
  store i32 %cv13219, ptr %slot2403, align 8
  %v13220 = load i32, ptr %slot2403, align 8
  %cv13221 = zext i32 %v13220 to i64
  %cond13222 = icmp ne i64 %cv13221, 0
  br i1 %cond13222, label %bb_rcgnn3106, label %bb_rcgdone3106
bb_rcgnn3106:
  %v13223 = load i64, ptr %slot2402, align 8
  %op13224 = sub i64 %v13223, 16
  store i64 %op13224, ptr %slot2404, align 8
  %v13225 = load i64, ptr %slot2402, align 8
  %p13226 = inttoptr i64 %v13225 to ptr
  %rgep13227 = getelementptr i8, ptr %p13226, i64 -16
  %ld13228 = load i64, ptr %rgep13227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13228, ptr %slot2405, align 8
  %v13229 = load i64, ptr %slot2405, align 8
  %op13230 = and i64 %v13229, 4611686018427387906
  store i64 %op13230, ptr %slot2406, align 8
  %v13231 = load i64, ptr %slot2406, align 8
  %cmp13232 = icmp ne i64 %v13231, 0
  %cv13233 = zext i1 %cmp13232 to i32
  store i32 %cv13233, ptr %slot2407, align 8
  %v13234 = load i32, ptr %slot2407, align 8
  %cv13235 = zext i32 %v13234 to i64
  %cond13236 = icmp ne i64 %cv13235, 0
  br i1 %cond13236, label %bb_rcgclear3106, label %bb_rcgcounted3106
bb_rcgcounted3106:
  %v13237 = load i64, ptr %slot2402, align 8
  %op13238 = sub i64 %v13237, 24
  store i64 %op13238, ptr %slot2408, align 8
  %v13239 = load i64, ptr %slot2402, align 8
  %p13240 = inttoptr i64 %v13239 to ptr
  %rgep13241 = getelementptr i8, ptr %p13240, i64 -24
  %ld13242 = load i64, ptr %rgep13241, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13242, ptr %slot2409, align 8
  %v13243 = load i64, ptr %slot2409, align 8
  %op13244 = sub i64 %v13243, 1
  store i64 %op13244, ptr %slot2410, align 8
  %v13245 = load i64, ptr %slot2410, align 8
  %cmp13246 = icmp eq i64 %v13245, 0
  %cv13247 = zext i1 %cmp13246 to i32
  store i32 %cv13247, ptr %slot2411, align 8
  %v13248 = load i32, ptr %slot2411, align 8
  %cv13249 = zext i32 %v13248 to i64
  %cond13250 = icmp ne i64 %cv13249, 0
  br i1 %cond13250, label %bb_rcglast3106, label %bb_rcgdec3106
bb_rcglast3106:
  %v13251 = load i64, ptr %slot2402, align 8
  %op13252 = sub i64 %v13251, 32
  store i64 %op13252, ptr %slot2412, align 8
  %v13253 = load i64, ptr %slot2402, align 8
  %p13254 = inttoptr i64 %v13253 to ptr
  %rgep13255 = getelementptr i8, ptr %p13254, i64 -32
  %ld13256 = load i64, ptr %rgep13255, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13256, ptr %slot2413, align 8
  %v13257 = load i64, ptr %slot2413, align 8
  %cmp13258 = icmp ne i64 %v13257, 0
  %cv13259 = zext i1 %cmp13258 to i32
  store i32 %cv13259, ptr %slot2414, align 8
  %v13260 = load i32, ptr %slot2414, align 8
  %cv13261 = zext i32 %v13260 to i64
  %cond13262 = icmp ne i64 %cv13261, 0
  br i1 %cond13262, label %bb_rcgdec3106, label %bb_rcgslow3106
bb_rcgslow3106:
  %v13263 = load i64, ptr %slot2401, align 8
  %v13264 = load i64, ptr %slot2398, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v13263, i64 %v13264) nomerge, !dbg !172
  br label %bb_rcgdone3106
bb_rcgdec3106:
  %v13265 = load i64, ptr %slot2410, align 8
  %v13266 = load i64, ptr %slot2402, align 8
  %p13267 = inttoptr i64 %v13266 to ptr
  %rgep13268 = getelementptr i8, ptr %p13267, i64 -24
  store i64 %v13265, ptr %rgep13268, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3106
bb_rcgclear3106:
  %v13269 = load i64, ptr %slot2398, align 8
  %p13270 = inttoptr i64 %v13269 to ptr
  store i64 0, ptr %p13270, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3106
bb_rcgdone3106:
  br label %bb_rcslotdone3090
bb_rcslotowner3090:
  %v13271 = load i64, ptr %slot110, align 8
  store i64 %v13271, ptr %slot2415, align 8
  %v13272 = load i64, ptr %slot2398, align 8
  %p13273 = inttoptr i64 %v13272 to ptr
  %ld13274 = load i64, ptr %p13273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13274, ptr %slot2416, align 8
  %v13275 = load i64, ptr %slot2416, align 8
  %cmp13276 = icmp ne i64 %v13275, 0
  %cv13277 = zext i1 %cmp13276 to i32
  store i32 %cv13277, ptr %slot2417, align 8
  %v13278 = load i32, ptr %slot2417, align 8
  %cv13279 = zext i32 %v13278 to i64
  %cond13280 = icmp ne i64 %cv13279, 0
  br i1 %cond13280, label %bb_rcgnn3121, label %bb_rcgdone3121
bb_rcgnn3121:
  %v13281 = load i64, ptr %slot2416, align 8
  %op13282 = sub i64 %v13281, 16
  store i64 %op13282, ptr %slot2418, align 8
  %v13283 = load i64, ptr %slot2416, align 8
  %p13284 = inttoptr i64 %v13283 to ptr
  %rgep13285 = getelementptr i8, ptr %p13284, i64 -16
  %ld13286 = load i64, ptr %rgep13285, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13286, ptr %slot2419, align 8
  %v13287 = load i64, ptr %slot2419, align 8
  %op13288 = and i64 %v13287, 4611686018427387906
  store i64 %op13288, ptr %slot2420, align 8
  %v13289 = load i64, ptr %slot2420, align 8
  %cmp13290 = icmp ne i64 %v13289, 0
  %cv13291 = zext i1 %cmp13290 to i32
  store i32 %cv13291, ptr %slot2421, align 8
  %v13292 = load i32, ptr %slot2421, align 8
  %cv13293 = zext i32 %v13292 to i64
  %cond13294 = icmp ne i64 %cv13293, 0
  br i1 %cond13294, label %bb_rcgclear3121, label %bb_rcgcounted3121
bb_rcgcounted3121:
  %v13295 = load i64, ptr %slot2416, align 8
  %op13296 = sub i64 %v13295, 32
  store i64 %op13296, ptr %slot2422, align 8
  %v13297 = load i64, ptr %slot2416, align 8
  %p13298 = inttoptr i64 %v13297 to ptr
  %rgep13299 = getelementptr i8, ptr %p13298, i64 -32
  %ld13300 = load i64, ptr %rgep13299, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13300, ptr %slot2423, align 8
  %v13301 = load i64, ptr %slot2423, align 8
  %op13302 = sub i64 %v13301, 1
  store i64 %op13302, ptr %slot2424, align 8
  %v13303 = load i64, ptr %slot2424, align 8
  %cmp13304 = icmp eq i64 %v13303, 0
  %cv13305 = zext i1 %cmp13304 to i32
  store i32 %cv13305, ptr %slot2425, align 8
  %v13306 = load i32, ptr %slot2425, align 8
  %cv13307 = zext i32 %v13306 to i64
  %cond13308 = icmp ne i64 %cv13307, 0
  br i1 %cond13308, label %bb_rcglast3121, label %bb_rcgdec3121
bb_rcglast3121:
  %v13309 = load i64, ptr %slot2416, align 8
  %op13310 = sub i64 %v13309, 24
  store i64 %op13310, ptr %slot2426, align 8
  %v13311 = load i64, ptr %slot2416, align 8
  %p13312 = inttoptr i64 %v13311 to ptr
  %rgep13313 = getelementptr i8, ptr %p13312, i64 -24
  %ld13314 = load i64, ptr %rgep13313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13314, ptr %slot2427, align 8
  %v13315 = load i64, ptr %slot2427, align 8
  %cmp13316 = icmp ne i64 %v13315, 0
  %cv13317 = zext i1 %cmp13316 to i32
  store i32 %cv13317, ptr %slot2428, align 8
  %v13318 = load i32, ptr %slot2428, align 8
  %cv13319 = zext i32 %v13318 to i64
  %cond13320 = icmp ne i64 %cv13319, 0
  br i1 %cond13320, label %bb_rcgdec3121, label %bb_rcgslow3121
bb_rcgslow3121:
  %v13321 = load i64, ptr %slot2415, align 8
  %v13322 = load i64, ptr %slot2398, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v13321, i64 %v13322) nomerge, !dbg !172
  br label %bb_rcgdone3121
bb_rcgdec3121:
  %v13323 = load i64, ptr %slot2424, align 8
  %v13324 = load i64, ptr %slot2416, align 8
  %p13325 = inttoptr i64 %v13324 to ptr
  %rgep13326 = getelementptr i8, ptr %p13325, i64 -32
  store i64 %v13323, ptr %rgep13326, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3121
bb_rcgclear3121:
  %v13327 = load i64, ptr %slot2398, align 8
  %p13328 = inttoptr i64 %v13327 to ptr
  store i64 0, ptr %p13328, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3121
bb_rcgdone3121:
  br label %bb_rcslotdone3090
bb_rcslotdone3090:
  %v13329 = load i64, ptr %slot20, align 8
  %p13330 = inttoptr i64 %v13329 to ptr
  %ld13331 = load i32, ptr %p13330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13331, ptr %slot2429, align 8
  %v13332 = load i32, ptr %slot2429, align 8
  %cv13333 = zext i32 %v13332 to i64
  %cond13334 = icmp ne i64 %cv13333, 0
  br i1 %cond13334, label %bb_rcslotdrop3127, label %bb_rcslotdone3127
bb_rcslotdrop3127:
  %v13335 = load i64, ptr %slot20, align 8
  %p13336 = inttoptr i64 %v13335 to ptr
  store i32 0, ptr %p13336, align 4, !alias.scope !3, !noalias !4
  %v13337 = load i64, ptr %slot76, align 8
  store i64 %v13337, ptr %slot2430, align 8
  %v13338 = load i64, ptr %slot21, align 8
  %p13339 = inttoptr i64 %v13338 to ptr
  %ld13340 = load i32, ptr %p13339, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13340, ptr %slot2431, align 8
  %v13341 = load i32, ptr %slot2431, align 8
  %op13342 = and i32 %v13341, 28
  store i32 %op13342, ptr %slot2432, align 8
  %v13343 = load i32, ptr %slot2432, align 8
  %cv13344 = zext i32 %v13343 to i64
  %cond13345 = icmp ne i64 %cv13344, 0
  br i1 %cond13345, label %bb_rcslotrole3127, label %bb_rcslotowner3127
bb_rcslotrole3127:
  %v13346 = load i64, ptr %slot110, align 8
  store i64 %v13346, ptr %slot2433, align 8
  %v13347 = load i64, ptr %slot2430, align 8
  %p13348 = inttoptr i64 %v13347 to ptr
  %ld13349 = load i64, ptr %p13348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13349, ptr %slot2434, align 8
  %v13350 = load i64, ptr %slot2434, align 8
  %cmp13351 = icmp ne i64 %v13350, 0
  %cv13352 = zext i1 %cmp13351 to i32
  store i32 %cv13352, ptr %slot2435, align 8
  %v13353 = load i32, ptr %slot2435, align 8
  %cv13354 = zext i32 %v13353 to i64
  %cond13355 = icmp ne i64 %cv13354, 0
  br i1 %cond13355, label %bb_rcgnn3143, label %bb_rcgdone3143
bb_rcgnn3143:
  %v13356 = load i64, ptr %slot2434, align 8
  %op13357 = sub i64 %v13356, 16
  store i64 %op13357, ptr %slot2436, align 8
  %v13358 = load i64, ptr %slot2434, align 8
  %p13359 = inttoptr i64 %v13358 to ptr
  %rgep13360 = getelementptr i8, ptr %p13359, i64 -16
  %ld13361 = load i64, ptr %rgep13360, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13361, ptr %slot2437, align 8
  %v13362 = load i64, ptr %slot2437, align 8
  %op13363 = and i64 %v13362, 4611686018427387906
  store i64 %op13363, ptr %slot2438, align 8
  %v13364 = load i64, ptr %slot2438, align 8
  %cmp13365 = icmp ne i64 %v13364, 0
  %cv13366 = zext i1 %cmp13365 to i32
  store i32 %cv13366, ptr %slot2439, align 8
  %v13367 = load i32, ptr %slot2439, align 8
  %cv13368 = zext i32 %v13367 to i64
  %cond13369 = icmp ne i64 %cv13368, 0
  br i1 %cond13369, label %bb_rcgclear3143, label %bb_rcgcounted3143
bb_rcgcounted3143:
  %v13370 = load i64, ptr %slot2434, align 8
  %op13371 = sub i64 %v13370, 24
  store i64 %op13371, ptr %slot2440, align 8
  %v13372 = load i64, ptr %slot2434, align 8
  %p13373 = inttoptr i64 %v13372 to ptr
  %rgep13374 = getelementptr i8, ptr %p13373, i64 -24
  %ld13375 = load i64, ptr %rgep13374, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13375, ptr %slot2441, align 8
  %v13376 = load i64, ptr %slot2441, align 8
  %op13377 = sub i64 %v13376, 1
  store i64 %op13377, ptr %slot2442, align 8
  %v13378 = load i64, ptr %slot2442, align 8
  %cmp13379 = icmp eq i64 %v13378, 0
  %cv13380 = zext i1 %cmp13379 to i32
  store i32 %cv13380, ptr %slot2443, align 8
  %v13381 = load i32, ptr %slot2443, align 8
  %cv13382 = zext i32 %v13381 to i64
  %cond13383 = icmp ne i64 %cv13382, 0
  br i1 %cond13383, label %bb_rcglast3143, label %bb_rcgdec3143
bb_rcglast3143:
  %v13384 = load i64, ptr %slot2434, align 8
  %op13385 = sub i64 %v13384, 32
  store i64 %op13385, ptr %slot2444, align 8
  %v13386 = load i64, ptr %slot2434, align 8
  %p13387 = inttoptr i64 %v13386 to ptr
  %rgep13388 = getelementptr i8, ptr %p13387, i64 -32
  %ld13389 = load i64, ptr %rgep13388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13389, ptr %slot2445, align 8
  %v13390 = load i64, ptr %slot2445, align 8
  %cmp13391 = icmp ne i64 %v13390, 0
  %cv13392 = zext i1 %cmp13391 to i32
  store i32 %cv13392, ptr %slot2446, align 8
  %v13393 = load i32, ptr %slot2446, align 8
  %cv13394 = zext i32 %v13393 to i64
  %cond13395 = icmp ne i64 %cv13394, 0
  br i1 %cond13395, label %bb_rcgdec3143, label %bb_rcgslow3143
bb_rcgslow3143:
  %v13396 = load i64, ptr %slot2433, align 8
  %v13397 = load i64, ptr %slot2430, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v13396, i64 %v13397) nomerge, !dbg !172
  br label %bb_rcgdone3143
bb_rcgdec3143:
  %v13398 = load i64, ptr %slot2442, align 8
  %v13399 = load i64, ptr %slot2434, align 8
  %p13400 = inttoptr i64 %v13399 to ptr
  %rgep13401 = getelementptr i8, ptr %p13400, i64 -24
  store i64 %v13398, ptr %rgep13401, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3143
bb_rcgclear3143:
  %v13402 = load i64, ptr %slot2430, align 8
  %p13403 = inttoptr i64 %v13402 to ptr
  store i64 0, ptr %p13403, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3143
bb_rcgdone3143:
  br label %bb_rcslotdone3127
bb_rcslotowner3127:
  %v13404 = load i64, ptr %slot110, align 8
  store i64 %v13404, ptr %slot2447, align 8
  %v13405 = load i64, ptr %slot2430, align 8
  %p13406 = inttoptr i64 %v13405 to ptr
  %ld13407 = load i64, ptr %p13406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13407, ptr %slot2448, align 8
  %v13408 = load i64, ptr %slot2448, align 8
  %cmp13409 = icmp ne i64 %v13408, 0
  %cv13410 = zext i1 %cmp13409 to i32
  store i32 %cv13410, ptr %slot2449, align 8
  %v13411 = load i32, ptr %slot2449, align 8
  %cv13412 = zext i32 %v13411 to i64
  %cond13413 = icmp ne i64 %cv13412, 0
  br i1 %cond13413, label %bb_rcgnn3158, label %bb_rcgdone3158
bb_rcgnn3158:
  %v13414 = load i64, ptr %slot2448, align 8
  %op13415 = sub i64 %v13414, 16
  store i64 %op13415, ptr %slot2450, align 8
  %v13416 = load i64, ptr %slot2448, align 8
  %p13417 = inttoptr i64 %v13416 to ptr
  %rgep13418 = getelementptr i8, ptr %p13417, i64 -16
  %ld13419 = load i64, ptr %rgep13418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13419, ptr %slot2451, align 8
  %v13420 = load i64, ptr %slot2451, align 8
  %op13421 = and i64 %v13420, 4611686018427387906
  store i64 %op13421, ptr %slot2452, align 8
  %v13422 = load i64, ptr %slot2452, align 8
  %cmp13423 = icmp ne i64 %v13422, 0
  %cv13424 = zext i1 %cmp13423 to i32
  store i32 %cv13424, ptr %slot2453, align 8
  %v13425 = load i32, ptr %slot2453, align 8
  %cv13426 = zext i32 %v13425 to i64
  %cond13427 = icmp ne i64 %cv13426, 0
  br i1 %cond13427, label %bb_rcgclear3158, label %bb_rcgcounted3158
bb_rcgcounted3158:
  %v13428 = load i64, ptr %slot2448, align 8
  %op13429 = sub i64 %v13428, 32
  store i64 %op13429, ptr %slot2454, align 8
  %v13430 = load i64, ptr %slot2448, align 8
  %p13431 = inttoptr i64 %v13430 to ptr
  %rgep13432 = getelementptr i8, ptr %p13431, i64 -32
  %ld13433 = load i64, ptr %rgep13432, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13433, ptr %slot2455, align 8
  %v13434 = load i64, ptr %slot2455, align 8
  %op13435 = sub i64 %v13434, 1
  store i64 %op13435, ptr %slot2456, align 8
  %v13436 = load i64, ptr %slot2456, align 8
  %cmp13437 = icmp eq i64 %v13436, 0
  %cv13438 = zext i1 %cmp13437 to i32
  store i32 %cv13438, ptr %slot2457, align 8
  %v13439 = load i32, ptr %slot2457, align 8
  %cv13440 = zext i32 %v13439 to i64
  %cond13441 = icmp ne i64 %cv13440, 0
  br i1 %cond13441, label %bb_rcglast3158, label %bb_rcgdec3158
bb_rcglast3158:
  %v13442 = load i64, ptr %slot2448, align 8
  %op13443 = sub i64 %v13442, 24
  store i64 %op13443, ptr %slot2458, align 8
  %v13444 = load i64, ptr %slot2448, align 8
  %p13445 = inttoptr i64 %v13444 to ptr
  %rgep13446 = getelementptr i8, ptr %p13445, i64 -24
  %ld13447 = load i64, ptr %rgep13446, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13447, ptr %slot2459, align 8
  %v13448 = load i64, ptr %slot2459, align 8
  %cmp13449 = icmp ne i64 %v13448, 0
  %cv13450 = zext i1 %cmp13449 to i32
  store i32 %cv13450, ptr %slot2460, align 8
  %v13451 = load i32, ptr %slot2460, align 8
  %cv13452 = zext i32 %v13451 to i64
  %cond13453 = icmp ne i64 %cv13452, 0
  br i1 %cond13453, label %bb_rcgdec3158, label %bb_rcgslow3158
bb_rcgslow3158:
  %v13454 = load i64, ptr %slot2447, align 8
  %v13455 = load i64, ptr %slot2430, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v13454, i64 %v13455) nomerge, !dbg !172
  br label %bb_rcgdone3158
bb_rcgdec3158:
  %v13456 = load i64, ptr %slot2456, align 8
  %v13457 = load i64, ptr %slot2448, align 8
  %p13458 = inttoptr i64 %v13457 to ptr
  %rgep13459 = getelementptr i8, ptr %p13458, i64 -32
  store i64 %v13456, ptr %rgep13459, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3158
bb_rcgclear3158:
  %v13460 = load i64, ptr %slot2430, align 8
  %p13461 = inttoptr i64 %v13460 to ptr
  store i64 0, ptr %p13461, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3158
bb_rcgdone3158:
  br label %bb_rcslotdone3127
bb_rcslotdone3127:
  %v13462 = load i64, ptr %slot18, align 8
  %p13463 = inttoptr i64 %v13462 to ptr
  %ld13464 = load i32, ptr %p13463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13464, ptr %slot2461, align 8
  %v13465 = load i32, ptr %slot2461, align 8
  %cv13466 = zext i32 %v13465 to i64
  %cond13467 = icmp ne i64 %cv13466, 0
  br i1 %cond13467, label %bb_rcslotdrop3164, label %bb_rcslotdone3164
bb_rcslotdrop3164:
  %v13468 = load i64, ptr %slot18, align 8
  %p13469 = inttoptr i64 %v13468 to ptr
  store i32 0, ptr %p13469, align 4, !alias.scope !3, !noalias !4
  %v13470 = load i64, ptr %slot75, align 8
  store i64 %v13470, ptr %slot2462, align 8
  %v13471 = load i64, ptr %slot19, align 8
  %p13472 = inttoptr i64 %v13471 to ptr
  %ld13473 = load i32, ptr %p13472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13473, ptr %slot2463, align 8
  %v13474 = load i32, ptr %slot2463, align 8
  %op13475 = and i32 %v13474, 28
  store i32 %op13475, ptr %slot2464, align 8
  %v13476 = load i32, ptr %slot2464, align 8
  %cv13477 = zext i32 %v13476 to i64
  %cond13478 = icmp ne i64 %cv13477, 0
  br i1 %cond13478, label %bb_rcslotrole3164, label %bb_rcslotowner3164
bb_rcslotrole3164:
  %v13479 = load i64, ptr %slot110, align 8
  store i64 %v13479, ptr %slot2465, align 8
  %v13480 = load i64, ptr %slot2462, align 8
  %p13481 = inttoptr i64 %v13480 to ptr
  %ld13482 = load i64, ptr %p13481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13482, ptr %slot2466, align 8
  %v13483 = load i64, ptr %slot2466, align 8
  %cmp13484 = icmp ne i64 %v13483, 0
  %cv13485 = zext i1 %cmp13484 to i32
  store i32 %cv13485, ptr %slot2467, align 8
  %v13486 = load i32, ptr %slot2467, align 8
  %cv13487 = zext i32 %v13486 to i64
  %cond13488 = icmp ne i64 %cv13487, 0
  br i1 %cond13488, label %bb_rcgnn3180, label %bb_rcgdone3180
bb_rcgnn3180:
  %v13489 = load i64, ptr %slot2466, align 8
  %op13490 = sub i64 %v13489, 16
  store i64 %op13490, ptr %slot2468, align 8
  %v13491 = load i64, ptr %slot2466, align 8
  %p13492 = inttoptr i64 %v13491 to ptr
  %rgep13493 = getelementptr i8, ptr %p13492, i64 -16
  %ld13494 = load i64, ptr %rgep13493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13494, ptr %slot2469, align 8
  %v13495 = load i64, ptr %slot2469, align 8
  %op13496 = and i64 %v13495, 4611686018427387906
  store i64 %op13496, ptr %slot2470, align 8
  %v13497 = load i64, ptr %slot2470, align 8
  %cmp13498 = icmp ne i64 %v13497, 0
  %cv13499 = zext i1 %cmp13498 to i32
  store i32 %cv13499, ptr %slot2471, align 8
  %v13500 = load i32, ptr %slot2471, align 8
  %cv13501 = zext i32 %v13500 to i64
  %cond13502 = icmp ne i64 %cv13501, 0
  br i1 %cond13502, label %bb_rcgclear3180, label %bb_rcgcounted3180
bb_rcgcounted3180:
  %v13503 = load i64, ptr %slot2466, align 8
  %op13504 = sub i64 %v13503, 24
  store i64 %op13504, ptr %slot2472, align 8
  %v13505 = load i64, ptr %slot2466, align 8
  %p13506 = inttoptr i64 %v13505 to ptr
  %rgep13507 = getelementptr i8, ptr %p13506, i64 -24
  %ld13508 = load i64, ptr %rgep13507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13508, ptr %slot2473, align 8
  %v13509 = load i64, ptr %slot2473, align 8
  %op13510 = sub i64 %v13509, 1
  store i64 %op13510, ptr %slot2474, align 8
  %v13511 = load i64, ptr %slot2474, align 8
  %cmp13512 = icmp eq i64 %v13511, 0
  %cv13513 = zext i1 %cmp13512 to i32
  store i32 %cv13513, ptr %slot2475, align 8
  %v13514 = load i32, ptr %slot2475, align 8
  %cv13515 = zext i32 %v13514 to i64
  %cond13516 = icmp ne i64 %cv13515, 0
  br i1 %cond13516, label %bb_rcglast3180, label %bb_rcgdec3180
bb_rcglast3180:
  %v13517 = load i64, ptr %slot2466, align 8
  %op13518 = sub i64 %v13517, 32
  store i64 %op13518, ptr %slot2476, align 8
  %v13519 = load i64, ptr %slot2466, align 8
  %p13520 = inttoptr i64 %v13519 to ptr
  %rgep13521 = getelementptr i8, ptr %p13520, i64 -32
  %ld13522 = load i64, ptr %rgep13521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13522, ptr %slot2477, align 8
  %v13523 = load i64, ptr %slot2477, align 8
  %cmp13524 = icmp ne i64 %v13523, 0
  %cv13525 = zext i1 %cmp13524 to i32
  store i32 %cv13525, ptr %slot2478, align 8
  %v13526 = load i32, ptr %slot2478, align 8
  %cv13527 = zext i32 %v13526 to i64
  %cond13528 = icmp ne i64 %cv13527, 0
  br i1 %cond13528, label %bb_rcgdec3180, label %bb_rcgslow3180
bb_rcgslow3180:
  %v13529 = load i64, ptr %slot2465, align 8
  %v13530 = load i64, ptr %slot2462, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v13529, i64 %v13530) nomerge, !dbg !172
  br label %bb_rcgdone3180
bb_rcgdec3180:
  %v13531 = load i64, ptr %slot2474, align 8
  %v13532 = load i64, ptr %slot2466, align 8
  %p13533 = inttoptr i64 %v13532 to ptr
  %rgep13534 = getelementptr i8, ptr %p13533, i64 -24
  store i64 %v13531, ptr %rgep13534, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3180
bb_rcgclear3180:
  %v13535 = load i64, ptr %slot2462, align 8
  %p13536 = inttoptr i64 %v13535 to ptr
  store i64 0, ptr %p13536, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3180
bb_rcgdone3180:
  br label %bb_rcslotdone3164
bb_rcslotowner3164:
  %v13537 = load i64, ptr %slot110, align 8
  store i64 %v13537, ptr %slot2479, align 8
  %v13538 = load i64, ptr %slot2462, align 8
  %p13539 = inttoptr i64 %v13538 to ptr
  %ld13540 = load i64, ptr %p13539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13540, ptr %slot2480, align 8
  %v13541 = load i64, ptr %slot2480, align 8
  %cmp13542 = icmp ne i64 %v13541, 0
  %cv13543 = zext i1 %cmp13542 to i32
  store i32 %cv13543, ptr %slot2481, align 8
  %v13544 = load i32, ptr %slot2481, align 8
  %cv13545 = zext i32 %v13544 to i64
  %cond13546 = icmp ne i64 %cv13545, 0
  br i1 %cond13546, label %bb_rcgnn3195, label %bb_rcgdone3195
bb_rcgnn3195:
  %v13547 = load i64, ptr %slot2480, align 8
  %op13548 = sub i64 %v13547, 16
  store i64 %op13548, ptr %slot2482, align 8
  %v13549 = load i64, ptr %slot2480, align 8
  %p13550 = inttoptr i64 %v13549 to ptr
  %rgep13551 = getelementptr i8, ptr %p13550, i64 -16
  %ld13552 = load i64, ptr %rgep13551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13552, ptr %slot2483, align 8
  %v13553 = load i64, ptr %slot2483, align 8
  %op13554 = and i64 %v13553, 4611686018427387906
  store i64 %op13554, ptr %slot2484, align 8
  %v13555 = load i64, ptr %slot2484, align 8
  %cmp13556 = icmp ne i64 %v13555, 0
  %cv13557 = zext i1 %cmp13556 to i32
  store i32 %cv13557, ptr %slot2485, align 8
  %v13558 = load i32, ptr %slot2485, align 8
  %cv13559 = zext i32 %v13558 to i64
  %cond13560 = icmp ne i64 %cv13559, 0
  br i1 %cond13560, label %bb_rcgclear3195, label %bb_rcgcounted3195
bb_rcgcounted3195:
  %v13561 = load i64, ptr %slot2480, align 8
  %op13562 = sub i64 %v13561, 32
  store i64 %op13562, ptr %slot2486, align 8
  %v13563 = load i64, ptr %slot2480, align 8
  %p13564 = inttoptr i64 %v13563 to ptr
  %rgep13565 = getelementptr i8, ptr %p13564, i64 -32
  %ld13566 = load i64, ptr %rgep13565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13566, ptr %slot2487, align 8
  %v13567 = load i64, ptr %slot2487, align 8
  %op13568 = sub i64 %v13567, 1
  store i64 %op13568, ptr %slot2488, align 8
  %v13569 = load i64, ptr %slot2488, align 8
  %cmp13570 = icmp eq i64 %v13569, 0
  %cv13571 = zext i1 %cmp13570 to i32
  store i32 %cv13571, ptr %slot2489, align 8
  %v13572 = load i32, ptr %slot2489, align 8
  %cv13573 = zext i32 %v13572 to i64
  %cond13574 = icmp ne i64 %cv13573, 0
  br i1 %cond13574, label %bb_rcglast3195, label %bb_rcgdec3195
bb_rcglast3195:
  %v13575 = load i64, ptr %slot2480, align 8
  %op13576 = sub i64 %v13575, 24
  store i64 %op13576, ptr %slot2490, align 8
  %v13577 = load i64, ptr %slot2480, align 8
  %p13578 = inttoptr i64 %v13577 to ptr
  %rgep13579 = getelementptr i8, ptr %p13578, i64 -24
  %ld13580 = load i64, ptr %rgep13579, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13580, ptr %slot2491, align 8
  %v13581 = load i64, ptr %slot2491, align 8
  %cmp13582 = icmp ne i64 %v13581, 0
  %cv13583 = zext i1 %cmp13582 to i32
  store i32 %cv13583, ptr %slot2492, align 8
  %v13584 = load i32, ptr %slot2492, align 8
  %cv13585 = zext i32 %v13584 to i64
  %cond13586 = icmp ne i64 %cv13585, 0
  br i1 %cond13586, label %bb_rcgdec3195, label %bb_rcgslow3195
bb_rcgslow3195:
  %v13587 = load i64, ptr %slot2479, align 8
  %v13588 = load i64, ptr %slot2462, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v13587, i64 %v13588) nomerge, !dbg !172
  br label %bb_rcgdone3195
bb_rcgdec3195:
  %v13589 = load i64, ptr %slot2488, align 8
  %v13590 = load i64, ptr %slot2480, align 8
  %p13591 = inttoptr i64 %v13590 to ptr
  %rgep13592 = getelementptr i8, ptr %p13591, i64 -32
  store i64 %v13589, ptr %rgep13592, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3195
bb_rcgclear3195:
  %v13593 = load i64, ptr %slot2462, align 8
  %p13594 = inttoptr i64 %v13593 to ptr
  store i64 0, ptr %p13594, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3195
bb_rcgdone3195:
  br label %bb_rcslotdone3164
bb_rcslotdone3164:
  %v13595 = load i64, ptr %slot16, align 8
  %p13596 = inttoptr i64 %v13595 to ptr
  %ld13597 = load i32, ptr %p13596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13597, ptr %slot2493, align 8
  %v13598 = load i32, ptr %slot2493, align 8
  %cv13599 = zext i32 %v13598 to i64
  %cond13600 = icmp ne i64 %cv13599, 0
  br i1 %cond13600, label %bb_rcslotdrop3201, label %bb_rcslotdone3201
bb_rcslotdrop3201:
  %v13601 = load i64, ptr %slot16, align 8
  %p13602 = inttoptr i64 %v13601 to ptr
  store i32 0, ptr %p13602, align 4, !alias.scope !3, !noalias !4
  %v13603 = load i64, ptr %slot74, align 8
  store i64 %v13603, ptr %slot2494, align 8
  %v13604 = load i64, ptr %slot17, align 8
  %p13605 = inttoptr i64 %v13604 to ptr
  %ld13606 = load i32, ptr %p13605, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13606, ptr %slot2495, align 8
  %v13607 = load i32, ptr %slot2495, align 8
  %op13608 = and i32 %v13607, 28
  store i32 %op13608, ptr %slot2496, align 8
  %v13609 = load i32, ptr %slot2496, align 8
  %cv13610 = zext i32 %v13609 to i64
  %cond13611 = icmp ne i64 %cv13610, 0
  br i1 %cond13611, label %bb_rcslotrole3201, label %bb_rcslotowner3201
bb_rcslotrole3201:
  %v13612 = load i64, ptr %slot110, align 8
  store i64 %v13612, ptr %slot2497, align 8
  %v13613 = load i64, ptr %slot2494, align 8
  %p13614 = inttoptr i64 %v13613 to ptr
  %ld13615 = load i64, ptr %p13614, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13615, ptr %slot2498, align 8
  %v13616 = load i64, ptr %slot2498, align 8
  %cmp13617 = icmp ne i64 %v13616, 0
  %cv13618 = zext i1 %cmp13617 to i32
  store i32 %cv13618, ptr %slot2499, align 8
  %v13619 = load i32, ptr %slot2499, align 8
  %cv13620 = zext i32 %v13619 to i64
  %cond13621 = icmp ne i64 %cv13620, 0
  br i1 %cond13621, label %bb_rcgnn3217, label %bb_rcgdone3217
bb_rcgnn3217:
  %v13622 = load i64, ptr %slot2498, align 8
  %op13623 = sub i64 %v13622, 16
  store i64 %op13623, ptr %slot2500, align 8
  %v13624 = load i64, ptr %slot2498, align 8
  %p13625 = inttoptr i64 %v13624 to ptr
  %rgep13626 = getelementptr i8, ptr %p13625, i64 -16
  %ld13627 = load i64, ptr %rgep13626, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13627, ptr %slot2501, align 8
  %v13628 = load i64, ptr %slot2501, align 8
  %op13629 = and i64 %v13628, 4611686018427387906
  store i64 %op13629, ptr %slot2502, align 8
  %v13630 = load i64, ptr %slot2502, align 8
  %cmp13631 = icmp ne i64 %v13630, 0
  %cv13632 = zext i1 %cmp13631 to i32
  store i32 %cv13632, ptr %slot2503, align 8
  %v13633 = load i32, ptr %slot2503, align 8
  %cv13634 = zext i32 %v13633 to i64
  %cond13635 = icmp ne i64 %cv13634, 0
  br i1 %cond13635, label %bb_rcgclear3217, label %bb_rcgcounted3217
bb_rcgcounted3217:
  %v13636 = load i64, ptr %slot2498, align 8
  %op13637 = sub i64 %v13636, 24
  store i64 %op13637, ptr %slot2504, align 8
  %v13638 = load i64, ptr %slot2498, align 8
  %p13639 = inttoptr i64 %v13638 to ptr
  %rgep13640 = getelementptr i8, ptr %p13639, i64 -24
  %ld13641 = load i64, ptr %rgep13640, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13641, ptr %slot2505, align 8
  %v13642 = load i64, ptr %slot2505, align 8
  %op13643 = sub i64 %v13642, 1
  store i64 %op13643, ptr %slot2506, align 8
  %v13644 = load i64, ptr %slot2506, align 8
  %cmp13645 = icmp eq i64 %v13644, 0
  %cv13646 = zext i1 %cmp13645 to i32
  store i32 %cv13646, ptr %slot2507, align 8
  %v13647 = load i32, ptr %slot2507, align 8
  %cv13648 = zext i32 %v13647 to i64
  %cond13649 = icmp ne i64 %cv13648, 0
  br i1 %cond13649, label %bb_rcglast3217, label %bb_rcgdec3217
bb_rcglast3217:
  %v13650 = load i64, ptr %slot2498, align 8
  %op13651 = sub i64 %v13650, 32
  store i64 %op13651, ptr %slot2508, align 8
  %v13652 = load i64, ptr %slot2498, align 8
  %p13653 = inttoptr i64 %v13652 to ptr
  %rgep13654 = getelementptr i8, ptr %p13653, i64 -32
  %ld13655 = load i64, ptr %rgep13654, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13655, ptr %slot2509, align 8
  %v13656 = load i64, ptr %slot2509, align 8
  %cmp13657 = icmp ne i64 %v13656, 0
  %cv13658 = zext i1 %cmp13657 to i32
  store i32 %cv13658, ptr %slot2510, align 8
  %v13659 = load i32, ptr %slot2510, align 8
  %cv13660 = zext i32 %v13659 to i64
  %cond13661 = icmp ne i64 %cv13660, 0
  br i1 %cond13661, label %bb_rcgdec3217, label %bb_rcgslow3217
bb_rcgslow3217:
  %v13662 = load i64, ptr %slot2497, align 8
  %v13663 = load i64, ptr %slot2494, align 8
  call void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_unloan(i64 %v13662, i64 %v13663) nomerge, !dbg !172
  br label %bb_rcgdone3217
bb_rcgdec3217:
  %v13664 = load i64, ptr %slot2506, align 8
  %v13665 = load i64, ptr %slot2498, align 8
  %p13666 = inttoptr i64 %v13665 to ptr
  %rgep13667 = getelementptr i8, ptr %p13666, i64 -24
  store i64 %v13664, ptr %rgep13667, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3217
bb_rcgclear3217:
  %v13668 = load i64, ptr %slot2494, align 8
  %p13669 = inttoptr i64 %v13668 to ptr
  store i64 0, ptr %p13669, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3217
bb_rcgdone3217:
  br label %bb_rcslotdone3201
bb_rcslotowner3201:
  %v13670 = load i64, ptr %slot110, align 8
  store i64 %v13670, ptr %slot2511, align 8
  %v13671 = load i64, ptr %slot2494, align 8
  %p13672 = inttoptr i64 %v13671 to ptr
  %ld13673 = load i64, ptr %p13672, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13673, ptr %slot2512, align 8
  %v13674 = load i64, ptr %slot2512, align 8
  %cmp13675 = icmp ne i64 %v13674, 0
  %cv13676 = zext i1 %cmp13675 to i32
  store i32 %cv13676, ptr %slot2513, align 8
  %v13677 = load i32, ptr %slot2513, align 8
  %cv13678 = zext i32 %v13677 to i64
  %cond13679 = icmp ne i64 %cv13678, 0
  br i1 %cond13679, label %bb_rcgnn3232, label %bb_rcgdone3232
bb_rcgnn3232:
  %v13680 = load i64, ptr %slot2512, align 8
  %op13681 = sub i64 %v13680, 16
  store i64 %op13681, ptr %slot2514, align 8
  %v13682 = load i64, ptr %slot2512, align 8
  %p13683 = inttoptr i64 %v13682 to ptr
  %rgep13684 = getelementptr i8, ptr %p13683, i64 -16
  %ld13685 = load i64, ptr %rgep13684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13685, ptr %slot2515, align 8
  %v13686 = load i64, ptr %slot2515, align 8
  %op13687 = and i64 %v13686, 4611686018427387906
  store i64 %op13687, ptr %slot2516, align 8
  %v13688 = load i64, ptr %slot2516, align 8
  %cmp13689 = icmp ne i64 %v13688, 0
  %cv13690 = zext i1 %cmp13689 to i32
  store i32 %cv13690, ptr %slot2517, align 8
  %v13691 = load i32, ptr %slot2517, align 8
  %cv13692 = zext i32 %v13691 to i64
  %cond13693 = icmp ne i64 %cv13692, 0
  br i1 %cond13693, label %bb_rcgclear3232, label %bb_rcgcounted3232
bb_rcgcounted3232:
  %v13694 = load i64, ptr %slot2512, align 8
  %op13695 = sub i64 %v13694, 32
  store i64 %op13695, ptr %slot2518, align 8
  %v13696 = load i64, ptr %slot2512, align 8
  %p13697 = inttoptr i64 %v13696 to ptr
  %rgep13698 = getelementptr i8, ptr %p13697, i64 -32
  %ld13699 = load i64, ptr %rgep13698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13699, ptr %slot2519, align 8
  %v13700 = load i64, ptr %slot2519, align 8
  %op13701 = sub i64 %v13700, 1
  store i64 %op13701, ptr %slot2520, align 8
  %v13702 = load i64, ptr %slot2520, align 8
  %cmp13703 = icmp eq i64 %v13702, 0
  %cv13704 = zext i1 %cmp13703 to i32
  store i32 %cv13704, ptr %slot2521, align 8
  %v13705 = load i32, ptr %slot2521, align 8
  %cv13706 = zext i32 %v13705 to i64
  %cond13707 = icmp ne i64 %cv13706, 0
  br i1 %cond13707, label %bb_rcglast3232, label %bb_rcgdec3232
bb_rcglast3232:
  %v13708 = load i64, ptr %slot2512, align 8
  %op13709 = sub i64 %v13708, 24
  store i64 %op13709, ptr %slot2522, align 8
  %v13710 = load i64, ptr %slot2512, align 8
  %p13711 = inttoptr i64 %v13710 to ptr
  %rgep13712 = getelementptr i8, ptr %p13711, i64 -24
  %ld13713 = load i64, ptr %rgep13712, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13713, ptr %slot2523, align 8
  %v13714 = load i64, ptr %slot2523, align 8
  %cmp13715 = icmp ne i64 %v13714, 0
  %cv13716 = zext i1 %cmp13715 to i32
  store i32 %cv13716, ptr %slot2524, align 8
  %v13717 = load i32, ptr %slot2524, align 8
  %cv13718 = zext i32 %v13717 to i64
  %cond13719 = icmp ne i64 %cv13718, 0
  br i1 %cond13719, label %bb_rcgdec3232, label %bb_rcgslow3232
bb_rcgslow3232:
  %v13720 = load i64, ptr %slot2511, align 8
  %v13721 = load i64, ptr %slot2494, align 8
  call void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_drop(i64 %v13720, i64 %v13721) nomerge, !dbg !172
  br label %bb_rcgdone3232
bb_rcgdec3232:
  %v13722 = load i64, ptr %slot2520, align 8
  %v13723 = load i64, ptr %slot2512, align 8
  %p13724 = inttoptr i64 %v13723 to ptr
  %rgep13725 = getelementptr i8, ptr %p13724, i64 -32
  store i64 %v13722, ptr %rgep13725, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3232
bb_rcgclear3232:
  %v13726 = load i64, ptr %slot2494, align 8
  %p13727 = inttoptr i64 %v13726 to ptr
  store i64 0, ptr %p13727, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3232
bb_rcgdone3232:
  br label %bb_rcslotdone3201
bb_rcslotdone3201:
  %v13728 = load i64, ptr %slot14, align 8
  %p13729 = inttoptr i64 %v13728 to ptr
  %ld13730 = load i32, ptr %p13729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13730, ptr %slot2525, align 8
  %v13731 = load i32, ptr %slot2525, align 8
  %cv13732 = zext i32 %v13731 to i64
  %cond13733 = icmp ne i64 %cv13732, 0
  br i1 %cond13733, label %bb_rcslotdrop3238, label %bb_rcslotdone3238
bb_rcslotdrop3238:
  %v13734 = load i64, ptr %slot14, align 8
  %p13735 = inttoptr i64 %v13734 to ptr
  store i32 0, ptr %p13735, align 4, !alias.scope !3, !noalias !4
  %v13736 = load i64, ptr %slot73, align 8
  store i64 %v13736, ptr %slot2526, align 8
  %v13737 = load i64, ptr %slot15, align 8
  %p13738 = inttoptr i64 %v13737 to ptr
  %ld13739 = load i32, ptr %p13738, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13739, ptr %slot2527, align 8
  %v13740 = load i32, ptr %slot2527, align 8
  %op13741 = and i32 %v13740, 28
  store i32 %op13741, ptr %slot2528, align 8
  %v13742 = load i32, ptr %slot2528, align 8
  %cv13743 = zext i32 %v13742 to i64
  %cond13744 = icmp ne i64 %cv13743, 0
  br i1 %cond13744, label %bb_rcslotrole3238, label %bb_rcslotowner3238
bb_rcslotrole3238:
  %v13745 = load i64, ptr %slot110, align 8
  store i64 %v13745, ptr %slot2529, align 8
  %v13746 = load i64, ptr %slot2526, align 8
  %p13747 = inttoptr i64 %v13746 to ptr
  %ld13748 = load i64, ptr %p13747, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13748, ptr %slot2530, align 8
  %v13749 = load i64, ptr %slot2530, align 8
  %cmp13750 = icmp ne i64 %v13749, 0
  %cv13751 = zext i1 %cmp13750 to i32
  store i32 %cv13751, ptr %slot2531, align 8
  %v13752 = load i32, ptr %slot2531, align 8
  %cv13753 = zext i32 %v13752 to i64
  %cond13754 = icmp ne i64 %cv13753, 0
  br i1 %cond13754, label %bb_rcgnn3254, label %bb_rcgdone3254
bb_rcgnn3254:
  %v13755 = load i64, ptr %slot2530, align 8
  %op13756 = sub i64 %v13755, 16
  store i64 %op13756, ptr %slot2532, align 8
  %v13757 = load i64, ptr %slot2530, align 8
  %p13758 = inttoptr i64 %v13757 to ptr
  %rgep13759 = getelementptr i8, ptr %p13758, i64 -16
  %ld13760 = load i64, ptr %rgep13759, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13760, ptr %slot2533, align 8
  %v13761 = load i64, ptr %slot2533, align 8
  %op13762 = and i64 %v13761, 4611686018427387906
  store i64 %op13762, ptr %slot2534, align 8
  %v13763 = load i64, ptr %slot2534, align 8
  %cmp13764 = icmp ne i64 %v13763, 0
  %cv13765 = zext i1 %cmp13764 to i32
  store i32 %cv13765, ptr %slot2535, align 8
  %v13766 = load i32, ptr %slot2535, align 8
  %cv13767 = zext i32 %v13766 to i64
  %cond13768 = icmp ne i64 %cv13767, 0
  br i1 %cond13768, label %bb_rcgclear3254, label %bb_rcgcounted3254
bb_rcgcounted3254:
  %v13769 = load i64, ptr %slot2530, align 8
  %op13770 = sub i64 %v13769, 24
  store i64 %op13770, ptr %slot2536, align 8
  %v13771 = load i64, ptr %slot2530, align 8
  %p13772 = inttoptr i64 %v13771 to ptr
  %rgep13773 = getelementptr i8, ptr %p13772, i64 -24
  %ld13774 = load i64, ptr %rgep13773, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13774, ptr %slot2537, align 8
  %v13775 = load i64, ptr %slot2537, align 8
  %op13776 = sub i64 %v13775, 1
  store i64 %op13776, ptr %slot2538, align 8
  %v13777 = load i64, ptr %slot2538, align 8
  %cmp13778 = icmp eq i64 %v13777, 0
  %cv13779 = zext i1 %cmp13778 to i32
  store i32 %cv13779, ptr %slot2539, align 8
  %v13780 = load i32, ptr %slot2539, align 8
  %cv13781 = zext i32 %v13780 to i64
  %cond13782 = icmp ne i64 %cv13781, 0
  br i1 %cond13782, label %bb_rcglast3254, label %bb_rcgdec3254
bb_rcglast3254:
  %v13783 = load i64, ptr %slot2530, align 8
  %op13784 = sub i64 %v13783, 32
  store i64 %op13784, ptr %slot2540, align 8
  %v13785 = load i64, ptr %slot2530, align 8
  %p13786 = inttoptr i64 %v13785 to ptr
  %rgep13787 = getelementptr i8, ptr %p13786, i64 -32
  %ld13788 = load i64, ptr %rgep13787, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13788, ptr %slot2541, align 8
  %v13789 = load i64, ptr %slot2541, align 8
  %cmp13790 = icmp ne i64 %v13789, 0
  %cv13791 = zext i1 %cmp13790 to i32
  store i32 %cv13791, ptr %slot2542, align 8
  %v13792 = load i32, ptr %slot2542, align 8
  %cv13793 = zext i32 %v13792 to i64
  %cond13794 = icmp ne i64 %cv13793, 0
  br i1 %cond13794, label %bb_rcgdec3254, label %bb_rcgslow3254
bb_rcgslow3254:
  %v13795 = load i64, ptr %slot2529, align 8
  %v13796 = load i64, ptr %slot2526, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v13795, i64 %v13796) nomerge, !dbg !172
  br label %bb_rcgdone3254
bb_rcgdec3254:
  %v13797 = load i64, ptr %slot2538, align 8
  %v13798 = load i64, ptr %slot2530, align 8
  %p13799 = inttoptr i64 %v13798 to ptr
  %rgep13800 = getelementptr i8, ptr %p13799, i64 -24
  store i64 %v13797, ptr %rgep13800, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3254
bb_rcgclear3254:
  %v13801 = load i64, ptr %slot2526, align 8
  %p13802 = inttoptr i64 %v13801 to ptr
  store i64 0, ptr %p13802, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3254
bb_rcgdone3254:
  br label %bb_rcslotdone3238
bb_rcslotowner3238:
  %v13803 = load i64, ptr %slot110, align 8
  store i64 %v13803, ptr %slot2543, align 8
  %v13804 = load i64, ptr %slot2526, align 8
  %p13805 = inttoptr i64 %v13804 to ptr
  %ld13806 = load i64, ptr %p13805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13806, ptr %slot2544, align 8
  %v13807 = load i64, ptr %slot2544, align 8
  %cmp13808 = icmp ne i64 %v13807, 0
  %cv13809 = zext i1 %cmp13808 to i32
  store i32 %cv13809, ptr %slot2545, align 8
  %v13810 = load i32, ptr %slot2545, align 8
  %cv13811 = zext i32 %v13810 to i64
  %cond13812 = icmp ne i64 %cv13811, 0
  br i1 %cond13812, label %bb_rcgnn3269, label %bb_rcgdone3269
bb_rcgnn3269:
  %v13813 = load i64, ptr %slot2544, align 8
  %op13814 = sub i64 %v13813, 16
  store i64 %op13814, ptr %slot2546, align 8
  %v13815 = load i64, ptr %slot2544, align 8
  %p13816 = inttoptr i64 %v13815 to ptr
  %rgep13817 = getelementptr i8, ptr %p13816, i64 -16
  %ld13818 = load i64, ptr %rgep13817, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13818, ptr %slot2547, align 8
  %v13819 = load i64, ptr %slot2547, align 8
  %op13820 = and i64 %v13819, 4611686018427387906
  store i64 %op13820, ptr %slot2548, align 8
  %v13821 = load i64, ptr %slot2548, align 8
  %cmp13822 = icmp ne i64 %v13821, 0
  %cv13823 = zext i1 %cmp13822 to i32
  store i32 %cv13823, ptr %slot2549, align 8
  %v13824 = load i32, ptr %slot2549, align 8
  %cv13825 = zext i32 %v13824 to i64
  %cond13826 = icmp ne i64 %cv13825, 0
  br i1 %cond13826, label %bb_rcgclear3269, label %bb_rcgcounted3269
bb_rcgcounted3269:
  %v13827 = load i64, ptr %slot2544, align 8
  %op13828 = sub i64 %v13827, 32
  store i64 %op13828, ptr %slot2550, align 8
  %v13829 = load i64, ptr %slot2544, align 8
  %p13830 = inttoptr i64 %v13829 to ptr
  %rgep13831 = getelementptr i8, ptr %p13830, i64 -32
  %ld13832 = load i64, ptr %rgep13831, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13832, ptr %slot2551, align 8
  %v13833 = load i64, ptr %slot2551, align 8
  %op13834 = sub i64 %v13833, 1
  store i64 %op13834, ptr %slot2552, align 8
  %v13835 = load i64, ptr %slot2552, align 8
  %cmp13836 = icmp eq i64 %v13835, 0
  %cv13837 = zext i1 %cmp13836 to i32
  store i32 %cv13837, ptr %slot2553, align 8
  %v13838 = load i32, ptr %slot2553, align 8
  %cv13839 = zext i32 %v13838 to i64
  %cond13840 = icmp ne i64 %cv13839, 0
  br i1 %cond13840, label %bb_rcglast3269, label %bb_rcgdec3269
bb_rcglast3269:
  %v13841 = load i64, ptr %slot2544, align 8
  %op13842 = sub i64 %v13841, 24
  store i64 %op13842, ptr %slot2554, align 8
  %v13843 = load i64, ptr %slot2544, align 8
  %p13844 = inttoptr i64 %v13843 to ptr
  %rgep13845 = getelementptr i8, ptr %p13844, i64 -24
  %ld13846 = load i64, ptr %rgep13845, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13846, ptr %slot2555, align 8
  %v13847 = load i64, ptr %slot2555, align 8
  %cmp13848 = icmp ne i64 %v13847, 0
  %cv13849 = zext i1 %cmp13848 to i32
  store i32 %cv13849, ptr %slot2556, align 8
  %v13850 = load i32, ptr %slot2556, align 8
  %cv13851 = zext i32 %v13850 to i64
  %cond13852 = icmp ne i64 %cv13851, 0
  br i1 %cond13852, label %bb_rcgdec3269, label %bb_rcgslow3269
bb_rcgslow3269:
  %v13853 = load i64, ptr %slot2543, align 8
  %v13854 = load i64, ptr %slot2526, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v13853, i64 %v13854) nomerge, !dbg !172
  br label %bb_rcgdone3269
bb_rcgdec3269:
  %v13855 = load i64, ptr %slot2552, align 8
  %v13856 = load i64, ptr %slot2544, align 8
  %p13857 = inttoptr i64 %v13856 to ptr
  %rgep13858 = getelementptr i8, ptr %p13857, i64 -32
  store i64 %v13855, ptr %rgep13858, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3269
bb_rcgclear3269:
  %v13859 = load i64, ptr %slot2526, align 8
  %p13860 = inttoptr i64 %v13859 to ptr
  store i64 0, ptr %p13860, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3269
bb_rcgdone3269:
  br label %bb_rcslotdone3238
bb_rcslotdone3238:
  %v13861 = load i64, ptr %slot12, align 8
  %p13862 = inttoptr i64 %v13861 to ptr
  %ld13863 = load i32, ptr %p13862, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13863, ptr %slot2557, align 8
  %v13864 = load i32, ptr %slot2557, align 8
  %cv13865 = zext i32 %v13864 to i64
  %cond13866 = icmp ne i64 %cv13865, 0
  br i1 %cond13866, label %bb_rcslotdrop3275, label %bb_rcslotdone3275
bb_rcslotdrop3275:
  %v13867 = load i64, ptr %slot12, align 8
  %p13868 = inttoptr i64 %v13867 to ptr
  store i32 0, ptr %p13868, align 4, !alias.scope !3, !noalias !4
  %v13869 = load i64, ptr %slot72, align 8
  store i64 %v13869, ptr %slot2558, align 8
  %v13870 = load i64, ptr %slot13, align 8
  %p13871 = inttoptr i64 %v13870 to ptr
  %ld13872 = load i32, ptr %p13871, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13872, ptr %slot2559, align 8
  %v13873 = load i32, ptr %slot2559, align 8
  %op13874 = and i32 %v13873, 28
  store i32 %op13874, ptr %slot2560, align 8
  %v13875 = load i32, ptr %slot2560, align 8
  %cv13876 = zext i32 %v13875 to i64
  %cond13877 = icmp ne i64 %cv13876, 0
  br i1 %cond13877, label %bb_rcslotrole3275, label %bb_rcslotowner3275
bb_rcslotrole3275:
  %v13878 = load i64, ptr %slot110, align 8
  store i64 %v13878, ptr %slot2561, align 8
  %v13879 = load i64, ptr %slot2558, align 8
  %p13880 = inttoptr i64 %v13879 to ptr
  %ld13881 = load i64, ptr %p13880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13881, ptr %slot2562, align 8
  %v13882 = load i64, ptr %slot2562, align 8
  %cmp13883 = icmp ne i64 %v13882, 0
  %cv13884 = zext i1 %cmp13883 to i32
  store i32 %cv13884, ptr %slot2563, align 8
  %v13885 = load i32, ptr %slot2563, align 8
  %cv13886 = zext i32 %v13885 to i64
  %cond13887 = icmp ne i64 %cv13886, 0
  br i1 %cond13887, label %bb_rcgnn3291, label %bb_rcgdone3291
bb_rcgnn3291:
  %v13888 = load i64, ptr %slot2562, align 8
  %op13889 = sub i64 %v13888, 16
  store i64 %op13889, ptr %slot2564, align 8
  %v13890 = load i64, ptr %slot2562, align 8
  %p13891 = inttoptr i64 %v13890 to ptr
  %rgep13892 = getelementptr i8, ptr %p13891, i64 -16
  %ld13893 = load i64, ptr %rgep13892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13893, ptr %slot2565, align 8
  %v13894 = load i64, ptr %slot2565, align 8
  %op13895 = and i64 %v13894, 4611686018427387906
  store i64 %op13895, ptr %slot2566, align 8
  %v13896 = load i64, ptr %slot2566, align 8
  %cmp13897 = icmp ne i64 %v13896, 0
  %cv13898 = zext i1 %cmp13897 to i32
  store i32 %cv13898, ptr %slot2567, align 8
  %v13899 = load i32, ptr %slot2567, align 8
  %cv13900 = zext i32 %v13899 to i64
  %cond13901 = icmp ne i64 %cv13900, 0
  br i1 %cond13901, label %bb_rcgclear3291, label %bb_rcgcounted3291
bb_rcgcounted3291:
  %v13902 = load i64, ptr %slot2562, align 8
  %op13903 = sub i64 %v13902, 24
  store i64 %op13903, ptr %slot2568, align 8
  %v13904 = load i64, ptr %slot2562, align 8
  %p13905 = inttoptr i64 %v13904 to ptr
  %rgep13906 = getelementptr i8, ptr %p13905, i64 -24
  %ld13907 = load i64, ptr %rgep13906, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13907, ptr %slot2569, align 8
  %v13908 = load i64, ptr %slot2569, align 8
  %op13909 = sub i64 %v13908, 1
  store i64 %op13909, ptr %slot2570, align 8
  %v13910 = load i64, ptr %slot2570, align 8
  %cmp13911 = icmp eq i64 %v13910, 0
  %cv13912 = zext i1 %cmp13911 to i32
  store i32 %cv13912, ptr %slot2571, align 8
  %v13913 = load i32, ptr %slot2571, align 8
  %cv13914 = zext i32 %v13913 to i64
  %cond13915 = icmp ne i64 %cv13914, 0
  br i1 %cond13915, label %bb_rcglast3291, label %bb_rcgdec3291
bb_rcglast3291:
  %v13916 = load i64, ptr %slot2562, align 8
  %op13917 = sub i64 %v13916, 32
  store i64 %op13917, ptr %slot2572, align 8
  %v13918 = load i64, ptr %slot2562, align 8
  %p13919 = inttoptr i64 %v13918 to ptr
  %rgep13920 = getelementptr i8, ptr %p13919, i64 -32
  %ld13921 = load i64, ptr %rgep13920, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13921, ptr %slot2573, align 8
  %v13922 = load i64, ptr %slot2573, align 8
  %cmp13923 = icmp ne i64 %v13922, 0
  %cv13924 = zext i1 %cmp13923 to i32
  store i32 %cv13924, ptr %slot2574, align 8
  %v13925 = load i32, ptr %slot2574, align 8
  %cv13926 = zext i32 %v13925 to i64
  %cond13927 = icmp ne i64 %cv13926, 0
  br i1 %cond13927, label %bb_rcgdec3291, label %bb_rcgslow3291
bb_rcgslow3291:
  %v13928 = load i64, ptr %slot2561, align 8
  %v13929 = load i64, ptr %slot2558, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_unloan(i64 %v13928, i64 %v13929) nomerge, !dbg !172
  br label %bb_rcgdone3291
bb_rcgdec3291:
  %v13930 = load i64, ptr %slot2570, align 8
  %v13931 = load i64, ptr %slot2562, align 8
  %p13932 = inttoptr i64 %v13931 to ptr
  %rgep13933 = getelementptr i8, ptr %p13932, i64 -24
  store i64 %v13930, ptr %rgep13933, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3291
bb_rcgclear3291:
  %v13934 = load i64, ptr %slot2558, align 8
  %p13935 = inttoptr i64 %v13934 to ptr
  store i64 0, ptr %p13935, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3291
bb_rcgdone3291:
  br label %bb_rcslotdone3275
bb_rcslotowner3275:
  %v13936 = load i64, ptr %slot110, align 8
  store i64 %v13936, ptr %slot2575, align 8
  %v13937 = load i64, ptr %slot2558, align 8
  %p13938 = inttoptr i64 %v13937 to ptr
  %ld13939 = load i64, ptr %p13938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13939, ptr %slot2576, align 8
  %v13940 = load i64, ptr %slot2576, align 8
  %cmp13941 = icmp ne i64 %v13940, 0
  %cv13942 = zext i1 %cmp13941 to i32
  store i32 %cv13942, ptr %slot2577, align 8
  %v13943 = load i32, ptr %slot2577, align 8
  %cv13944 = zext i32 %v13943 to i64
  %cond13945 = icmp ne i64 %cv13944, 0
  br i1 %cond13945, label %bb_rcgnn3306, label %bb_rcgdone3306
bb_rcgnn3306:
  %v13946 = load i64, ptr %slot2576, align 8
  %op13947 = sub i64 %v13946, 16
  store i64 %op13947, ptr %slot2578, align 8
  %v13948 = load i64, ptr %slot2576, align 8
  %p13949 = inttoptr i64 %v13948 to ptr
  %rgep13950 = getelementptr i8, ptr %p13949, i64 -16
  %ld13951 = load i64, ptr %rgep13950, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13951, ptr %slot2579, align 8
  %v13952 = load i64, ptr %slot2579, align 8
  %op13953 = and i64 %v13952, 4611686018427387906
  store i64 %op13953, ptr %slot2580, align 8
  %v13954 = load i64, ptr %slot2580, align 8
  %cmp13955 = icmp ne i64 %v13954, 0
  %cv13956 = zext i1 %cmp13955 to i32
  store i32 %cv13956, ptr %slot2581, align 8
  %v13957 = load i32, ptr %slot2581, align 8
  %cv13958 = zext i32 %v13957 to i64
  %cond13959 = icmp ne i64 %cv13958, 0
  br i1 %cond13959, label %bb_rcgclear3306, label %bb_rcgcounted3306
bb_rcgcounted3306:
  %v13960 = load i64, ptr %slot2576, align 8
  %op13961 = sub i64 %v13960, 32
  store i64 %op13961, ptr %slot2582, align 8
  %v13962 = load i64, ptr %slot2576, align 8
  %p13963 = inttoptr i64 %v13962 to ptr
  %rgep13964 = getelementptr i8, ptr %p13963, i64 -32
  %ld13965 = load i64, ptr %rgep13964, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13965, ptr %slot2583, align 8
  %v13966 = load i64, ptr %slot2583, align 8
  %op13967 = sub i64 %v13966, 1
  store i64 %op13967, ptr %slot2584, align 8
  %v13968 = load i64, ptr %slot2584, align 8
  %cmp13969 = icmp eq i64 %v13968, 0
  %cv13970 = zext i1 %cmp13969 to i32
  store i32 %cv13970, ptr %slot2585, align 8
  %v13971 = load i32, ptr %slot2585, align 8
  %cv13972 = zext i32 %v13971 to i64
  %cond13973 = icmp ne i64 %cv13972, 0
  br i1 %cond13973, label %bb_rcglast3306, label %bb_rcgdec3306
bb_rcglast3306:
  %v13974 = load i64, ptr %slot2576, align 8
  %op13975 = sub i64 %v13974, 24
  store i64 %op13975, ptr %slot2586, align 8
  %v13976 = load i64, ptr %slot2576, align 8
  %p13977 = inttoptr i64 %v13976 to ptr
  %rgep13978 = getelementptr i8, ptr %p13977, i64 -24
  %ld13979 = load i64, ptr %rgep13978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13979, ptr %slot2587, align 8
  %v13980 = load i64, ptr %slot2587, align 8
  %cmp13981 = icmp ne i64 %v13980, 0
  %cv13982 = zext i1 %cmp13981 to i32
  store i32 %cv13982, ptr %slot2588, align 8
  %v13983 = load i32, ptr %slot2588, align 8
  %cv13984 = zext i32 %v13983 to i64
  %cond13985 = icmp ne i64 %cv13984, 0
  br i1 %cond13985, label %bb_rcgdec3306, label %bb_rcgslow3306
bb_rcgslow3306:
  %v13986 = load i64, ptr %slot2575, align 8
  %v13987 = load i64, ptr %slot2558, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_drop(i64 %v13986, i64 %v13987) nomerge, !dbg !172
  br label %bb_rcgdone3306
bb_rcgdec3306:
  %v13988 = load i64, ptr %slot2584, align 8
  %v13989 = load i64, ptr %slot2576, align 8
  %p13990 = inttoptr i64 %v13989 to ptr
  %rgep13991 = getelementptr i8, ptr %p13990, i64 -32
  store i64 %v13988, ptr %rgep13991, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3306
bb_rcgclear3306:
  %v13992 = load i64, ptr %slot2558, align 8
  %p13993 = inttoptr i64 %v13992 to ptr
  store i64 0, ptr %p13993, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3306
bb_rcgdone3306:
  br label %bb_rcslotdone3275
bb_rcslotdone3275:
  %v13994 = load i64, ptr %slot10, align 8
  %p13995 = inttoptr i64 %v13994 to ptr
  %ld13996 = load i32, ptr %p13995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13996, ptr %slot2589, align 8
  %v13997 = load i32, ptr %slot2589, align 8
  %cv13998 = zext i32 %v13997 to i64
  %cond13999 = icmp ne i64 %cv13998, 0
  br i1 %cond13999, label %bb_rcslotdrop3312, label %bb_rcslotdone3312
bb_rcslotdrop3312:
  %v14000 = load i64, ptr %slot10, align 8
  %p14001 = inttoptr i64 %v14000 to ptr
  store i32 0, ptr %p14001, align 4, !alias.scope !3, !noalias !4
  %v14002 = load i64, ptr %slot71, align 8
  store i64 %v14002, ptr %slot2590, align 8
  %v14003 = load i64, ptr %slot11, align 8
  %p14004 = inttoptr i64 %v14003 to ptr
  %ld14005 = load i32, ptr %p14004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14005, ptr %slot2591, align 8
  %v14006 = load i32, ptr %slot2591, align 8
  %op14007 = and i32 %v14006, 28
  store i32 %op14007, ptr %slot2592, align 8
  %v14008 = load i32, ptr %slot2592, align 8
  %cv14009 = zext i32 %v14008 to i64
  %cond14010 = icmp ne i64 %cv14009, 0
  br i1 %cond14010, label %bb_rcslotrole3312, label %bb_rcslotowner3312
bb_rcslotrole3312:
  %v14011 = load i64, ptr %slot110, align 8
  store i64 %v14011, ptr %slot2593, align 8
  %v14012 = load i64, ptr %slot2590, align 8
  %p14013 = inttoptr i64 %v14012 to ptr
  %ld14014 = load i64, ptr %p14013, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14014, ptr %slot2594, align 8
  %v14015 = load i64, ptr %slot2594, align 8
  %cmp14016 = icmp ne i64 %v14015, 0
  %cv14017 = zext i1 %cmp14016 to i32
  store i32 %cv14017, ptr %slot2595, align 8
  %v14018 = load i32, ptr %slot2595, align 8
  %cv14019 = zext i32 %v14018 to i64
  %cond14020 = icmp ne i64 %cv14019, 0
  br i1 %cond14020, label %bb_rcgnn3328, label %bb_rcgdone3328
bb_rcgnn3328:
  %v14021 = load i64, ptr %slot2594, align 8
  %op14022 = sub i64 %v14021, 16
  store i64 %op14022, ptr %slot2596, align 8
  %v14023 = load i64, ptr %slot2594, align 8
  %p14024 = inttoptr i64 %v14023 to ptr
  %rgep14025 = getelementptr i8, ptr %p14024, i64 -16
  %ld14026 = load i64, ptr %rgep14025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14026, ptr %slot2597, align 8
  %v14027 = load i64, ptr %slot2597, align 8
  %op14028 = and i64 %v14027, 4611686018427387906
  store i64 %op14028, ptr %slot2598, align 8
  %v14029 = load i64, ptr %slot2598, align 8
  %cmp14030 = icmp ne i64 %v14029, 0
  %cv14031 = zext i1 %cmp14030 to i32
  store i32 %cv14031, ptr %slot2599, align 8
  %v14032 = load i32, ptr %slot2599, align 8
  %cv14033 = zext i32 %v14032 to i64
  %cond14034 = icmp ne i64 %cv14033, 0
  br i1 %cond14034, label %bb_rcgclear3328, label %bb_rcgcounted3328
bb_rcgcounted3328:
  %v14035 = load i64, ptr %slot2594, align 8
  %op14036 = sub i64 %v14035, 24
  store i64 %op14036, ptr %slot2600, align 8
  %v14037 = load i64, ptr %slot2594, align 8
  %p14038 = inttoptr i64 %v14037 to ptr
  %rgep14039 = getelementptr i8, ptr %p14038, i64 -24
  %ld14040 = load i64, ptr %rgep14039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14040, ptr %slot2601, align 8
  %v14041 = load i64, ptr %slot2601, align 8
  %op14042 = sub i64 %v14041, 1
  store i64 %op14042, ptr %slot2602, align 8
  %v14043 = load i64, ptr %slot2602, align 8
  %cmp14044 = icmp eq i64 %v14043, 0
  %cv14045 = zext i1 %cmp14044 to i32
  store i32 %cv14045, ptr %slot2603, align 8
  %v14046 = load i32, ptr %slot2603, align 8
  %cv14047 = zext i32 %v14046 to i64
  %cond14048 = icmp ne i64 %cv14047, 0
  br i1 %cond14048, label %bb_rcglast3328, label %bb_rcgdec3328
bb_rcglast3328:
  %v14049 = load i64, ptr %slot2594, align 8
  %op14050 = sub i64 %v14049, 32
  store i64 %op14050, ptr %slot2604, align 8
  %v14051 = load i64, ptr %slot2594, align 8
  %p14052 = inttoptr i64 %v14051 to ptr
  %rgep14053 = getelementptr i8, ptr %p14052, i64 -32
  %ld14054 = load i64, ptr %rgep14053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14054, ptr %slot2605, align 8
  %v14055 = load i64, ptr %slot2605, align 8
  %cmp14056 = icmp ne i64 %v14055, 0
  %cv14057 = zext i1 %cmp14056 to i32
  store i32 %cv14057, ptr %slot2606, align 8
  %v14058 = load i32, ptr %slot2606, align 8
  %cv14059 = zext i32 %v14058 to i64
  %cond14060 = icmp ne i64 %cv14059, 0
  br i1 %cond14060, label %bb_rcgdec3328, label %bb_rcgslow3328
bb_rcgslow3328:
  %v14061 = load i64, ptr %slot2593, align 8
  %v14062 = load i64, ptr %slot2590, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_unloan(i64 %v14061, i64 %v14062) nomerge, !dbg !172
  br label %bb_rcgdone3328
bb_rcgdec3328:
  %v14063 = load i64, ptr %slot2602, align 8
  %v14064 = load i64, ptr %slot2594, align 8
  %p14065 = inttoptr i64 %v14064 to ptr
  %rgep14066 = getelementptr i8, ptr %p14065, i64 -24
  store i64 %v14063, ptr %rgep14066, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3328
bb_rcgclear3328:
  %v14067 = load i64, ptr %slot2590, align 8
  %p14068 = inttoptr i64 %v14067 to ptr
  store i64 0, ptr %p14068, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3328
bb_rcgdone3328:
  br label %bb_rcslotdone3312
bb_rcslotowner3312:
  %v14069 = load i64, ptr %slot110, align 8
  store i64 %v14069, ptr %slot2607, align 8
  %v14070 = load i64, ptr %slot2590, align 8
  %p14071 = inttoptr i64 %v14070 to ptr
  %ld14072 = load i64, ptr %p14071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14072, ptr %slot2608, align 8
  %v14073 = load i64, ptr %slot2608, align 8
  %cmp14074 = icmp ne i64 %v14073, 0
  %cv14075 = zext i1 %cmp14074 to i32
  store i32 %cv14075, ptr %slot2609, align 8
  %v14076 = load i32, ptr %slot2609, align 8
  %cv14077 = zext i32 %v14076 to i64
  %cond14078 = icmp ne i64 %cv14077, 0
  br i1 %cond14078, label %bb_rcgnn3343, label %bb_rcgdone3343
bb_rcgnn3343:
  %v14079 = load i64, ptr %slot2608, align 8
  %op14080 = sub i64 %v14079, 16
  store i64 %op14080, ptr %slot2610, align 8
  %v14081 = load i64, ptr %slot2608, align 8
  %p14082 = inttoptr i64 %v14081 to ptr
  %rgep14083 = getelementptr i8, ptr %p14082, i64 -16
  %ld14084 = load i64, ptr %rgep14083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14084, ptr %slot2611, align 8
  %v14085 = load i64, ptr %slot2611, align 8
  %op14086 = and i64 %v14085, 4611686018427387906
  store i64 %op14086, ptr %slot2612, align 8
  %v14087 = load i64, ptr %slot2612, align 8
  %cmp14088 = icmp ne i64 %v14087, 0
  %cv14089 = zext i1 %cmp14088 to i32
  store i32 %cv14089, ptr %slot2613, align 8
  %v14090 = load i32, ptr %slot2613, align 8
  %cv14091 = zext i32 %v14090 to i64
  %cond14092 = icmp ne i64 %cv14091, 0
  br i1 %cond14092, label %bb_rcgclear3343, label %bb_rcgcounted3343
bb_rcgcounted3343:
  %v14093 = load i64, ptr %slot2608, align 8
  %op14094 = sub i64 %v14093, 32
  store i64 %op14094, ptr %slot2614, align 8
  %v14095 = load i64, ptr %slot2608, align 8
  %p14096 = inttoptr i64 %v14095 to ptr
  %rgep14097 = getelementptr i8, ptr %p14096, i64 -32
  %ld14098 = load i64, ptr %rgep14097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14098, ptr %slot2615, align 8
  %v14099 = load i64, ptr %slot2615, align 8
  %op14100 = sub i64 %v14099, 1
  store i64 %op14100, ptr %slot2616, align 8
  %v14101 = load i64, ptr %slot2616, align 8
  %cmp14102 = icmp eq i64 %v14101, 0
  %cv14103 = zext i1 %cmp14102 to i32
  store i32 %cv14103, ptr %slot2617, align 8
  %v14104 = load i32, ptr %slot2617, align 8
  %cv14105 = zext i32 %v14104 to i64
  %cond14106 = icmp ne i64 %cv14105, 0
  br i1 %cond14106, label %bb_rcglast3343, label %bb_rcgdec3343
bb_rcglast3343:
  %v14107 = load i64, ptr %slot2608, align 8
  %op14108 = sub i64 %v14107, 24
  store i64 %op14108, ptr %slot2618, align 8
  %v14109 = load i64, ptr %slot2608, align 8
  %p14110 = inttoptr i64 %v14109 to ptr
  %rgep14111 = getelementptr i8, ptr %p14110, i64 -24
  %ld14112 = load i64, ptr %rgep14111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14112, ptr %slot2619, align 8
  %v14113 = load i64, ptr %slot2619, align 8
  %cmp14114 = icmp ne i64 %v14113, 0
  %cv14115 = zext i1 %cmp14114 to i32
  store i32 %cv14115, ptr %slot2620, align 8
  %v14116 = load i32, ptr %slot2620, align 8
  %cv14117 = zext i32 %v14116 to i64
  %cond14118 = icmp ne i64 %cv14117, 0
  br i1 %cond14118, label %bb_rcgdec3343, label %bb_rcgslow3343
bb_rcgslow3343:
  %v14119 = load i64, ptr %slot2607, align 8
  %v14120 = load i64, ptr %slot2590, align 8
  call void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_drop(i64 %v14119, i64 %v14120) nomerge, !dbg !172
  br label %bb_rcgdone3343
bb_rcgdec3343:
  %v14121 = load i64, ptr %slot2616, align 8
  %v14122 = load i64, ptr %slot2608, align 8
  %p14123 = inttoptr i64 %v14122 to ptr
  %rgep14124 = getelementptr i8, ptr %p14123, i64 -32
  store i64 %v14121, ptr %rgep14124, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3343
bb_rcgclear3343:
  %v14125 = load i64, ptr %slot2590, align 8
  %p14126 = inttoptr i64 %v14125 to ptr
  store i64 0, ptr %p14126, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3343
bb_rcgdone3343:
  br label %bb_rcslotdone3312
bb_rcslotdone3312:
  %v14127 = load i64, ptr %slot8, align 8
  %p14128 = inttoptr i64 %v14127 to ptr
  %ld14129 = load i32, ptr %p14128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14129, ptr %slot2621, align 8
  %v14130 = load i32, ptr %slot2621, align 8
  %cv14131 = zext i32 %v14130 to i64
  %cond14132 = icmp ne i64 %cv14131, 0
  br i1 %cond14132, label %bb_rcslotdrop3349, label %bb_rcslotdone3349
bb_rcslotdrop3349:
  %v14133 = load i64, ptr %slot8, align 8
  %p14134 = inttoptr i64 %v14133 to ptr
  store i32 0, ptr %p14134, align 4, !alias.scope !3, !noalias !4
  %v14135 = load i64, ptr %slot69, align 8
  store i64 %v14135, ptr %slot2622, align 8
  %v14136 = load i64, ptr %slot9, align 8
  %p14137 = inttoptr i64 %v14136 to ptr
  %ld14138 = load i32, ptr %p14137, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14138, ptr %slot2623, align 8
  %v14139 = load i32, ptr %slot2623, align 8
  %op14140 = and i32 %v14139, 28
  store i32 %op14140, ptr %slot2624, align 8
  %v14141 = load i32, ptr %slot2624, align 8
  %cv14142 = zext i32 %v14141 to i64
  %cond14143 = icmp ne i64 %cv14142, 0
  br i1 %cond14143, label %bb_rcslotrole3349, label %bb_rcslotowner3349
bb_rcslotrole3349:
  %v14144 = load i64, ptr %slot110, align 8
  store i64 %v14144, ptr %slot2625, align 8
  %v14145 = load i64, ptr %slot2622, align 8
  %p14146 = inttoptr i64 %v14145 to ptr
  %ld14147 = load i64, ptr %p14146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14147, ptr %slot2626, align 8
  %v14148 = load i64, ptr %slot2626, align 8
  %cmp14149 = icmp ne i64 %v14148, 0
  %cv14150 = zext i1 %cmp14149 to i32
  store i32 %cv14150, ptr %slot2627, align 8
  %v14151 = load i32, ptr %slot2627, align 8
  %cv14152 = zext i32 %v14151 to i64
  %cond14153 = icmp ne i64 %cv14152, 0
  br i1 %cond14153, label %bb_rcgnn3365, label %bb_rcgdone3365
bb_rcgnn3365:
  %v14154 = load i64, ptr %slot2626, align 8
  %op14155 = sub i64 %v14154, 16
  store i64 %op14155, ptr %slot2628, align 8
  %v14156 = load i64, ptr %slot2626, align 8
  %p14157 = inttoptr i64 %v14156 to ptr
  %rgep14158 = getelementptr i8, ptr %p14157, i64 -16
  %ld14159 = load i64, ptr %rgep14158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14159, ptr %slot2629, align 8
  %v14160 = load i64, ptr %slot2629, align 8
  %op14161 = and i64 %v14160, 4611686018427387906
  store i64 %op14161, ptr %slot2630, align 8
  %v14162 = load i64, ptr %slot2630, align 8
  %cmp14163 = icmp ne i64 %v14162, 0
  %cv14164 = zext i1 %cmp14163 to i32
  store i32 %cv14164, ptr %slot2631, align 8
  %v14165 = load i32, ptr %slot2631, align 8
  %cv14166 = zext i32 %v14165 to i64
  %cond14167 = icmp ne i64 %cv14166, 0
  br i1 %cond14167, label %bb_rcgclear3365, label %bb_rcgcounted3365
bb_rcgcounted3365:
  %v14168 = load i64, ptr %slot2626, align 8
  %op14169 = sub i64 %v14168, 24
  store i64 %op14169, ptr %slot2632, align 8
  %v14170 = load i64, ptr %slot2626, align 8
  %p14171 = inttoptr i64 %v14170 to ptr
  %rgep14172 = getelementptr i8, ptr %p14171, i64 -24
  %ld14173 = load i64, ptr %rgep14172, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14173, ptr %slot2633, align 8
  %v14174 = load i64, ptr %slot2633, align 8
  %op14175 = sub i64 %v14174, 1
  store i64 %op14175, ptr %slot2634, align 8
  %v14176 = load i64, ptr %slot2634, align 8
  %cmp14177 = icmp eq i64 %v14176, 0
  %cv14178 = zext i1 %cmp14177 to i32
  store i32 %cv14178, ptr %slot2635, align 8
  %v14179 = load i32, ptr %slot2635, align 8
  %cv14180 = zext i32 %v14179 to i64
  %cond14181 = icmp ne i64 %cv14180, 0
  br i1 %cond14181, label %bb_rcglast3365, label %bb_rcgdec3365
bb_rcglast3365:
  %v14182 = load i64, ptr %slot2626, align 8
  %op14183 = sub i64 %v14182, 32
  store i64 %op14183, ptr %slot2636, align 8
  %v14184 = load i64, ptr %slot2626, align 8
  %p14185 = inttoptr i64 %v14184 to ptr
  %rgep14186 = getelementptr i8, ptr %p14185, i64 -32
  %ld14187 = load i64, ptr %rgep14186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14187, ptr %slot2637, align 8
  %v14188 = load i64, ptr %slot2637, align 8
  %cmp14189 = icmp ne i64 %v14188, 0
  %cv14190 = zext i1 %cmp14189 to i32
  store i32 %cv14190, ptr %slot2638, align 8
  %v14191 = load i32, ptr %slot2638, align 8
  %cv14192 = zext i32 %v14191 to i64
  %cond14193 = icmp ne i64 %cv14192, 0
  br i1 %cond14193, label %bb_rcgdec3365, label %bb_rcgslow3365
bb_rcgslow3365:
  %v14194 = load i64, ptr %slot2625, align 8
  %v14195 = load i64, ptr %slot2622, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v14194, i64 %v14195) nomerge, !dbg !172
  br label %bb_rcgdone3365
bb_rcgdec3365:
  %v14196 = load i64, ptr %slot2634, align 8
  %v14197 = load i64, ptr %slot2626, align 8
  %p14198 = inttoptr i64 %v14197 to ptr
  %rgep14199 = getelementptr i8, ptr %p14198, i64 -24
  store i64 %v14196, ptr %rgep14199, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3365
bb_rcgclear3365:
  %v14200 = load i64, ptr %slot2622, align 8
  %p14201 = inttoptr i64 %v14200 to ptr
  store i64 0, ptr %p14201, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3365
bb_rcgdone3365:
  br label %bb_rcslotdone3349
bb_rcslotowner3349:
  %v14202 = load i64, ptr %slot110, align 8
  store i64 %v14202, ptr %slot2639, align 8
  %v14203 = load i64, ptr %slot2622, align 8
  %p14204 = inttoptr i64 %v14203 to ptr
  %ld14205 = load i64, ptr %p14204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14205, ptr %slot2640, align 8
  %v14206 = load i64, ptr %slot2640, align 8
  %cmp14207 = icmp ne i64 %v14206, 0
  %cv14208 = zext i1 %cmp14207 to i32
  store i32 %cv14208, ptr %slot2641, align 8
  %v14209 = load i32, ptr %slot2641, align 8
  %cv14210 = zext i32 %v14209 to i64
  %cond14211 = icmp ne i64 %cv14210, 0
  br i1 %cond14211, label %bb_rcgnn3380, label %bb_rcgdone3380
bb_rcgnn3380:
  %v14212 = load i64, ptr %slot2640, align 8
  %op14213 = sub i64 %v14212, 16
  store i64 %op14213, ptr %slot2642, align 8
  %v14214 = load i64, ptr %slot2640, align 8
  %p14215 = inttoptr i64 %v14214 to ptr
  %rgep14216 = getelementptr i8, ptr %p14215, i64 -16
  %ld14217 = load i64, ptr %rgep14216, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14217, ptr %slot2643, align 8
  %v14218 = load i64, ptr %slot2643, align 8
  %op14219 = and i64 %v14218, 4611686018427387906
  store i64 %op14219, ptr %slot2644, align 8
  %v14220 = load i64, ptr %slot2644, align 8
  %cmp14221 = icmp ne i64 %v14220, 0
  %cv14222 = zext i1 %cmp14221 to i32
  store i32 %cv14222, ptr %slot2645, align 8
  %v14223 = load i32, ptr %slot2645, align 8
  %cv14224 = zext i32 %v14223 to i64
  %cond14225 = icmp ne i64 %cv14224, 0
  br i1 %cond14225, label %bb_rcgclear3380, label %bb_rcgcounted3380
bb_rcgcounted3380:
  %v14226 = load i64, ptr %slot2640, align 8
  %op14227 = sub i64 %v14226, 32
  store i64 %op14227, ptr %slot2646, align 8
  %v14228 = load i64, ptr %slot2640, align 8
  %p14229 = inttoptr i64 %v14228 to ptr
  %rgep14230 = getelementptr i8, ptr %p14229, i64 -32
  %ld14231 = load i64, ptr %rgep14230, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14231, ptr %slot2647, align 8
  %v14232 = load i64, ptr %slot2647, align 8
  %op14233 = sub i64 %v14232, 1
  store i64 %op14233, ptr %slot2648, align 8
  %v14234 = load i64, ptr %slot2648, align 8
  %cmp14235 = icmp eq i64 %v14234, 0
  %cv14236 = zext i1 %cmp14235 to i32
  store i32 %cv14236, ptr %slot2649, align 8
  %v14237 = load i32, ptr %slot2649, align 8
  %cv14238 = zext i32 %v14237 to i64
  %cond14239 = icmp ne i64 %cv14238, 0
  br i1 %cond14239, label %bb_rcglast3380, label %bb_rcgdec3380
bb_rcglast3380:
  %v14240 = load i64, ptr %slot2640, align 8
  %op14241 = sub i64 %v14240, 24
  store i64 %op14241, ptr %slot2650, align 8
  %v14242 = load i64, ptr %slot2640, align 8
  %p14243 = inttoptr i64 %v14242 to ptr
  %rgep14244 = getelementptr i8, ptr %p14243, i64 -24
  %ld14245 = load i64, ptr %rgep14244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14245, ptr %slot2651, align 8
  %v14246 = load i64, ptr %slot2651, align 8
  %cmp14247 = icmp ne i64 %v14246, 0
  %cv14248 = zext i1 %cmp14247 to i32
  store i32 %cv14248, ptr %slot2652, align 8
  %v14249 = load i32, ptr %slot2652, align 8
  %cv14250 = zext i32 %v14249 to i64
  %cond14251 = icmp ne i64 %cv14250, 0
  br i1 %cond14251, label %bb_rcgdec3380, label %bb_rcgslow3380
bb_rcgslow3380:
  %v14252 = load i64, ptr %slot2639, align 8
  %v14253 = load i64, ptr %slot2622, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v14252, i64 %v14253) nomerge, !dbg !172
  br label %bb_rcgdone3380
bb_rcgdec3380:
  %v14254 = load i64, ptr %slot2648, align 8
  %v14255 = load i64, ptr %slot2640, align 8
  %p14256 = inttoptr i64 %v14255 to ptr
  %rgep14257 = getelementptr i8, ptr %p14256, i64 -32
  store i64 %v14254, ptr %rgep14257, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3380
bb_rcgclear3380:
  %v14258 = load i64, ptr %slot2622, align 8
  %p14259 = inttoptr i64 %v14258 to ptr
  store i64 0, ptr %p14259, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3380
bb_rcgdone3380:
  br label %bb_rcslotdone3349
bb_rcslotdone3349:
  %v14260 = load i64, ptr %slot6, align 8
  %p14261 = inttoptr i64 %v14260 to ptr
  %ld14262 = load i32, ptr %p14261, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14262, ptr %slot2653, align 8
  %v14263 = load i32, ptr %slot2653, align 8
  %cv14264 = zext i32 %v14263 to i64
  %cond14265 = icmp ne i64 %cv14264, 0
  br i1 %cond14265, label %bb_rcslotdrop3386, label %bb_rcslotdone3386
bb_rcslotdrop3386:
  %v14266 = load i64, ptr %slot6, align 8
  %p14267 = inttoptr i64 %v14266 to ptr
  store i32 0, ptr %p14267, align 4, !alias.scope !3, !noalias !4
  %v14268 = load i64, ptr %slot68, align 8
  store i64 %v14268, ptr %slot2654, align 8
  %v14269 = load i64, ptr %slot7, align 8
  %p14270 = inttoptr i64 %v14269 to ptr
  %ld14271 = load i32, ptr %p14270, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14271, ptr %slot2655, align 8
  %v14272 = load i32, ptr %slot2655, align 8
  %op14273 = and i32 %v14272, 28
  store i32 %op14273, ptr %slot2656, align 8
  %v14274 = load i32, ptr %slot2656, align 8
  %cv14275 = zext i32 %v14274 to i64
  %cond14276 = icmp ne i64 %cv14275, 0
  br i1 %cond14276, label %bb_rcslotrole3386, label %bb_rcslotowner3386
bb_rcslotrole3386:
  %v14277 = load i64, ptr %slot110, align 8
  store i64 %v14277, ptr %slot2657, align 8
  %v14278 = load i64, ptr %slot2654, align 8
  %p14279 = inttoptr i64 %v14278 to ptr
  %ld14280 = load i64, ptr %p14279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14280, ptr %slot2658, align 8
  %v14281 = load i64, ptr %slot2658, align 8
  %cmp14282 = icmp ne i64 %v14281, 0
  %cv14283 = zext i1 %cmp14282 to i32
  store i32 %cv14283, ptr %slot2659, align 8
  %v14284 = load i32, ptr %slot2659, align 8
  %cv14285 = zext i32 %v14284 to i64
  %cond14286 = icmp ne i64 %cv14285, 0
  br i1 %cond14286, label %bb_rcgnn3402, label %bb_rcgdone3402
bb_rcgnn3402:
  %v14287 = load i64, ptr %slot2658, align 8
  %op14288 = sub i64 %v14287, 16
  store i64 %op14288, ptr %slot2660, align 8
  %v14289 = load i64, ptr %slot2658, align 8
  %p14290 = inttoptr i64 %v14289 to ptr
  %rgep14291 = getelementptr i8, ptr %p14290, i64 -16
  %ld14292 = load i64, ptr %rgep14291, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14292, ptr %slot2661, align 8
  %v14293 = load i64, ptr %slot2661, align 8
  %op14294 = and i64 %v14293, 4611686018427387906
  store i64 %op14294, ptr %slot2662, align 8
  %v14295 = load i64, ptr %slot2662, align 8
  %cmp14296 = icmp ne i64 %v14295, 0
  %cv14297 = zext i1 %cmp14296 to i32
  store i32 %cv14297, ptr %slot2663, align 8
  %v14298 = load i32, ptr %slot2663, align 8
  %cv14299 = zext i32 %v14298 to i64
  %cond14300 = icmp ne i64 %cv14299, 0
  br i1 %cond14300, label %bb_rcgclear3402, label %bb_rcgcounted3402
bb_rcgcounted3402:
  %v14301 = load i64, ptr %slot2658, align 8
  %op14302 = sub i64 %v14301, 24
  store i64 %op14302, ptr %slot2664, align 8
  %v14303 = load i64, ptr %slot2658, align 8
  %p14304 = inttoptr i64 %v14303 to ptr
  %rgep14305 = getelementptr i8, ptr %p14304, i64 -24
  %ld14306 = load i64, ptr %rgep14305, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14306, ptr %slot2665, align 8
  %v14307 = load i64, ptr %slot2665, align 8
  %op14308 = sub i64 %v14307, 1
  store i64 %op14308, ptr %slot2666, align 8
  %v14309 = load i64, ptr %slot2666, align 8
  %cmp14310 = icmp eq i64 %v14309, 0
  %cv14311 = zext i1 %cmp14310 to i32
  store i32 %cv14311, ptr %slot2667, align 8
  %v14312 = load i32, ptr %slot2667, align 8
  %cv14313 = zext i32 %v14312 to i64
  %cond14314 = icmp ne i64 %cv14313, 0
  br i1 %cond14314, label %bb_rcglast3402, label %bb_rcgdec3402
bb_rcglast3402:
  %v14315 = load i64, ptr %slot2658, align 8
  %op14316 = sub i64 %v14315, 32
  store i64 %op14316, ptr %slot2668, align 8
  %v14317 = load i64, ptr %slot2658, align 8
  %p14318 = inttoptr i64 %v14317 to ptr
  %rgep14319 = getelementptr i8, ptr %p14318, i64 -32
  %ld14320 = load i64, ptr %rgep14319, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14320, ptr %slot2669, align 8
  %v14321 = load i64, ptr %slot2669, align 8
  %cmp14322 = icmp ne i64 %v14321, 0
  %cv14323 = zext i1 %cmp14322 to i32
  store i32 %cv14323, ptr %slot2670, align 8
  %v14324 = load i32, ptr %slot2670, align 8
  %cv14325 = zext i32 %v14324 to i64
  %cond14326 = icmp ne i64 %cv14325, 0
  br i1 %cond14326, label %bb_rcgdec3402, label %bb_rcgslow3402
bb_rcgslow3402:
  %v14327 = load i64, ptr %slot2657, align 8
  %v14328 = load i64, ptr %slot2654, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v14327, i64 %v14328) nomerge, !dbg !172
  br label %bb_rcgdone3402
bb_rcgdec3402:
  %v14329 = load i64, ptr %slot2666, align 8
  %v14330 = load i64, ptr %slot2658, align 8
  %p14331 = inttoptr i64 %v14330 to ptr
  %rgep14332 = getelementptr i8, ptr %p14331, i64 -24
  store i64 %v14329, ptr %rgep14332, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3402
bb_rcgclear3402:
  %v14333 = load i64, ptr %slot2654, align 8
  %p14334 = inttoptr i64 %v14333 to ptr
  store i64 0, ptr %p14334, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3402
bb_rcgdone3402:
  br label %bb_rcslotdone3386
bb_rcslotowner3386:
  %v14335 = load i64, ptr %slot110, align 8
  store i64 %v14335, ptr %slot2671, align 8
  %v14336 = load i64, ptr %slot2654, align 8
  %p14337 = inttoptr i64 %v14336 to ptr
  %ld14338 = load i64, ptr %p14337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14338, ptr %slot2672, align 8
  %v14339 = load i64, ptr %slot2672, align 8
  %cmp14340 = icmp ne i64 %v14339, 0
  %cv14341 = zext i1 %cmp14340 to i32
  store i32 %cv14341, ptr %slot2673, align 8
  %v14342 = load i32, ptr %slot2673, align 8
  %cv14343 = zext i32 %v14342 to i64
  %cond14344 = icmp ne i64 %cv14343, 0
  br i1 %cond14344, label %bb_rcgnn3417, label %bb_rcgdone3417
bb_rcgnn3417:
  %v14345 = load i64, ptr %slot2672, align 8
  %op14346 = sub i64 %v14345, 16
  store i64 %op14346, ptr %slot2674, align 8
  %v14347 = load i64, ptr %slot2672, align 8
  %p14348 = inttoptr i64 %v14347 to ptr
  %rgep14349 = getelementptr i8, ptr %p14348, i64 -16
  %ld14350 = load i64, ptr %rgep14349, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14350, ptr %slot2675, align 8
  %v14351 = load i64, ptr %slot2675, align 8
  %op14352 = and i64 %v14351, 4611686018427387906
  store i64 %op14352, ptr %slot2676, align 8
  %v14353 = load i64, ptr %slot2676, align 8
  %cmp14354 = icmp ne i64 %v14353, 0
  %cv14355 = zext i1 %cmp14354 to i32
  store i32 %cv14355, ptr %slot2677, align 8
  %v14356 = load i32, ptr %slot2677, align 8
  %cv14357 = zext i32 %v14356 to i64
  %cond14358 = icmp ne i64 %cv14357, 0
  br i1 %cond14358, label %bb_rcgclear3417, label %bb_rcgcounted3417
bb_rcgcounted3417:
  %v14359 = load i64, ptr %slot2672, align 8
  %op14360 = sub i64 %v14359, 32
  store i64 %op14360, ptr %slot2678, align 8
  %v14361 = load i64, ptr %slot2672, align 8
  %p14362 = inttoptr i64 %v14361 to ptr
  %rgep14363 = getelementptr i8, ptr %p14362, i64 -32
  %ld14364 = load i64, ptr %rgep14363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14364, ptr %slot2679, align 8
  %v14365 = load i64, ptr %slot2679, align 8
  %op14366 = sub i64 %v14365, 1
  store i64 %op14366, ptr %slot2680, align 8
  %v14367 = load i64, ptr %slot2680, align 8
  %cmp14368 = icmp eq i64 %v14367, 0
  %cv14369 = zext i1 %cmp14368 to i32
  store i32 %cv14369, ptr %slot2681, align 8
  %v14370 = load i32, ptr %slot2681, align 8
  %cv14371 = zext i32 %v14370 to i64
  %cond14372 = icmp ne i64 %cv14371, 0
  br i1 %cond14372, label %bb_rcglast3417, label %bb_rcgdec3417
bb_rcglast3417:
  %v14373 = load i64, ptr %slot2672, align 8
  %op14374 = sub i64 %v14373, 24
  store i64 %op14374, ptr %slot2682, align 8
  %v14375 = load i64, ptr %slot2672, align 8
  %p14376 = inttoptr i64 %v14375 to ptr
  %rgep14377 = getelementptr i8, ptr %p14376, i64 -24
  %ld14378 = load i64, ptr %rgep14377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14378, ptr %slot2683, align 8
  %v14379 = load i64, ptr %slot2683, align 8
  %cmp14380 = icmp ne i64 %v14379, 0
  %cv14381 = zext i1 %cmp14380 to i32
  store i32 %cv14381, ptr %slot2684, align 8
  %v14382 = load i32, ptr %slot2684, align 8
  %cv14383 = zext i32 %v14382 to i64
  %cond14384 = icmp ne i64 %cv14383, 0
  br i1 %cond14384, label %bb_rcgdec3417, label %bb_rcgslow3417
bb_rcgslow3417:
  %v14385 = load i64, ptr %slot2671, align 8
  %v14386 = load i64, ptr %slot2654, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v14385, i64 %v14386) nomerge, !dbg !172
  br label %bb_rcgdone3417
bb_rcgdec3417:
  %v14387 = load i64, ptr %slot2680, align 8
  %v14388 = load i64, ptr %slot2672, align 8
  %p14389 = inttoptr i64 %v14388 to ptr
  %rgep14390 = getelementptr i8, ptr %p14389, i64 -32
  store i64 %v14387, ptr %rgep14390, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3417
bb_rcgclear3417:
  %v14391 = load i64, ptr %slot2654, align 8
  %p14392 = inttoptr i64 %v14391 to ptr
  store i64 0, ptr %p14392, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3417
bb_rcgdone3417:
  br label %bb_rcslotdone3386
bb_rcslotdone3386:
  %v14393 = load i64, ptr %slot2326, align 8
  %p14394 = inttoptr i64 %v14393 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p14394, i64 208, i1 false)
  ret void
bb_failure:
  %v14395 = load i64, ptr %slot5, align 8
  %p14396 = inttoptr i64 %v14395 to ptr
  call void @llvm.memset.p0.i64(ptr %p14396, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !172
  %v14397 = load i64, ptr %slot5, align 8
  %p14398 = inttoptr i64 %v14397 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p14398, i64 208, i1 false)
  ret void
bb_entry_failure:
  %v14399 = load i64, ptr %slot5, align 8
  %p14400 = inttoptr i64 %v14399 to ptr
  call void @llvm.memset.p0.i64(ptr %p14400, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !172
  %v14401 = load i64, ptr %slot5, align 8
  %p14402 = inttoptr i64 %v14401 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p14402, i64 208, i1 false)
  ret void
}

@myl_t_135c20434b3e567dc9f56890b2e744a3921cd3f40404c14f8a6e8ab4481a5802 = external global i8, align 8
@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8
@myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a = external global i8, align 8
@myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0 = external global i8, align 8
@myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14 = external global i8, align 8
@myl_t_b760f44fa5965c2474a3b471467a22c43185152129295af588b022ae50b50903 = external global i8, align 8
@myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare i32 @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_take(i64, i64, i64, i32)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_drop(i64, i64)
declare i32 @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_take(i64, i64, i64, i32)
declare void @myl_t_12abec789c7063ff9d862d612862ddf291cccb0806223b60031080bfec0cbd15_rcg_unloan(i64, i64)
declare i32 @myl_t_135c20434b3e567dc9f56890b2e744a3921cd3f40404c14f8a6e8ab4481a5802_rcg_list_append(i64, i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64, i64, i64, i32)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_drop(i64, i64)
declare i32 @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_9c418158b00420f461fdb922d52a07584437421adca396d7c839874586e1aea9_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64, i64)
declare void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_drop(i64, i64)
declare i32 @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a76886878581aa149dcc111e15b8fc4762d047b1328eba92f48178c36cc2bfb0_rcg_unloan(i64, i64)
declare i32 @myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47_rcg_list_append(i64, i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_6ebf82ddbc9178c16b7df30bf24fbe017e8b8f1c3e98435ddaa9d24a62c703dc", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_6ebf82ddbc9178c16b7df30bf24fbe017e8b8f1c3e98435ddaa9d24a62c703dc", linkageName: "myl_f_6ebf82ddbc9178c16b7df30bf24fbe017e8b8f1c3e98435ddaa9d24a62c703dc", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 17136459568972720197, i64 0, !"myl_f_6ebf82ddbc9178c16b7df30bf24fbe017e8b8f1c3e98435ddaa9d24a62c703dc"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!120 = !DILocation(line: 14, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!122 = !DILocation(line: 18, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!124 = !DILocation(line: 22, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!126 = !DILocation(line: 23, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!128 = !DILocation(line: 26, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!130 = !DILocation(line: 29, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!132 = !DILocation(line: 37, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!134 = !DILocation(line: 41, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!136 = !DILocation(line: 45, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!138 = !DILocation(line: 46, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!140 = !DILocation(line: 50, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!142 = !DILocation(line: 51, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!144 = !DILocation(line: 55, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!146 = !DILocation(line: 56, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!148 = !DILocation(line: 59, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!150 = !DILocation(line: 61, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!152 = !DILocation(line: 62, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!154 = !DILocation(line: 65, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!156 = !DILocation(line: 66, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!158 = !DILocation(line: 82, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647199)
!160 = !DILocation(line: 83, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647239)
!162 = !DILocation(line: 88, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647247)
!164 = !DILocation(line: 89, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647279)
!166 = !DILocation(line: 93, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647287)
!168 = !DILocation(line: 94, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647319)
!170 = !DILocation(line: 98, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!172 = !DILocation(line: 99, column: 0, scope: !173)
