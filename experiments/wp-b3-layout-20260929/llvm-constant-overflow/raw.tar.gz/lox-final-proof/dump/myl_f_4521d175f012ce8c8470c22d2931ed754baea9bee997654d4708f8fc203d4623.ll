target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623(i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i32, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i32, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i32, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v83 = load i64, ptr %slot1, align 8
  %op84 = add i64 %v83, 32
  store i64 %op84, ptr %slot5, align 8
  %mem85 = alloca i8, i64 8, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot6, align 8
  %mem87 = alloca i8, i64 8, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot7, align 8
  %mem89 = alloca i8, i64 8, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot8, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot9, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot10, align 8
  %mem95 = alloca i8, i64 112, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot11, align 8
  %mem97 = alloca i8, i64 312, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot12, align 8
  %mem99 = alloca i8, i64 8, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot13, align 8
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot14, align 8
  %mem103 = alloca i8, i64 8, align 8
  %ptr104 = ptrtoint ptr %mem103 to i64
  store i64 %ptr104, ptr %slot15, align 8
  %mem105 = alloca i8, i64 8, align 8
  %ptr106 = ptrtoint ptr %mem105 to i64
  store i64 %ptr106, ptr %slot16, align 8
  %mem107 = alloca i8, i64 8, align 8
  %ptr108 = ptrtoint ptr %mem107 to i64
  store i64 %ptr108, ptr %slot17, align 8
  %mem109 = alloca i8, i64 8, align 8
  %ptr110 = ptrtoint ptr %mem109 to i64
  store i64 %ptr110, ptr %slot18, align 8
  %mem111 = alloca i8, i64 312, align 8
  %ptr112 = ptrtoint ptr %mem111 to i64
  store i64 %ptr112, ptr %slot19, align 8
  %mem113 = alloca i8, i64 312, align 8
  %ptr114 = ptrtoint ptr %mem113 to i64
  store i64 %ptr114, ptr %slot20, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem115 = alloca i8, i64 8, align 8
  %ptr116 = ptrtoint ptr %mem115 to i64
  store i64 %ptr116, ptr %slot21, align 8
  %v117 = load i64, ptr %slot1, align 8
  %op118 = add i64 %v117, 64
  store i64 %op118, ptr %slot22, align 8
  %v119 = load i64, ptr %slot22, align 8
  %p120 = inttoptr i64 %v119 to ptr
  %ld121 = load i64, ptr %p120, align 8, !alias.scope !4, !noalias !3
  store i64 %ld121, ptr %slot23, align 8
  %stack122 = call ptr @llvm.stacksave()
  %stackaddr123 = ptrtoint ptr %stack122 to i64
  %v124 = load i64, ptr %slot23, align 8
  %cmp125 = icmp ult i64 %stackaddr123, %v124
  %cv126 = zext i1 %cmp125 to i64
  store i64 %cv126, ptr %slot24, align 8
  %v127 = load i64, ptr %slot24, align 8
  %cond128 = icmp ne i64 %v127, 0
  br i1 %cond128, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v129 = load i64, ptr %slot1, align 8
  %p130 = inttoptr i64 %v129 to ptr
  call void @myl_qbe_fail_frame(ptr %p130) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v131 = load i64, ptr %slot2, align 8
  %v132 = load i64, ptr %slot13, align 8
  %p133 = inttoptr i64 %v132 to ptr
  store i64 %v131, ptr %p133, align 8, !alias.scope !3, !noalias !4
  %v134 = load i64, ptr %slot3, align 8
  %v135 = load i64, ptr %slot14, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i64 %v134, ptr %p136, align 8, !alias.scope !3, !noalias !4
  %v137 = load i64, ptr %slot4, align 8
  %v138 = load i64, ptr %slot15, align 8
  %p139 = inttoptr i64 %v138 to ptr
  store i64 %v137, ptr %p139, align 8, !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot1, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %call142 = call ptr @myl_qbe_heap(ptr %p141) nomerge, !dbg !112
  %calladdr143 = ptrtoint ptr %call142 to i64
  store i64 %calladdr143, ptr %slot25, align 8
  %v144 = load i64, ptr %slot1, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %call146 = call i64 @myl_qbe_region_mark(ptr %p145) nomerge, !dbg !112
  store i64 %call146, ptr %slot26, align 8
  %v147 = load i64, ptr %slot6, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i32 0, ptr %p148, align 4, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot7, align 8
  %p150 = inttoptr i64 %v149 to ptr
  store i32 0, ptr %p150, align 4, !alias.scope !3, !noalias !4
  %v151 = load i64, ptr %slot8, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i32 0, ptr %p152, align 4, !alias.scope !3, !noalias !4
  %v153 = load i64, ptr %slot9, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i32 0, ptr %p154, align 4, !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot10, align 8
  %p156 = inttoptr i64 %v155 to ptr
  store i32 0, ptr %p156, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v157 = load i64, ptr %slot13, align 8
  %p158 = inttoptr i64 %v157 to ptr
  %ld159 = load i64, ptr %p158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld159, ptr %slot27, align 8
  %v160 = load i64, ptr %slot27, align 8
  %v161 = load i64, ptr %slot16, align 8
  %p162 = inttoptr i64 %v161 to ptr
  store i64 %v160, ptr %p162, align 8, !alias.scope !3, !noalias !4
  %v163 = load i64, ptr %slot14, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld165, ptr %slot28, align 8
  %v166 = load i64, ptr %slot28, align 8
  %v167 = load i64, ptr %slot17, align 8
  %p168 = inttoptr i64 %v167 to ptr
  store i64 %v166, ptr %p168, align 8, !alias.scope !3, !noalias !4
  %v169 = load i64, ptr %slot15, align 8
  %p170 = inttoptr i64 %v169 to ptr
  %ld171 = load i64, ptr %p170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld171, ptr %slot29, align 8
  %v172 = load i64, ptr %slot29, align 8
  %v173 = load i64, ptr %slot18, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i64 %v172, ptr %p174, align 8, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot19, align 8
  store i64 %v175, ptr %slot30, align 8
  %v176 = load i64, ptr %slot30, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i64 0, ptr %p177, align 8, !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot30, align 8
  %p180 = inttoptr i64 %v178 to ptr
  %gep181 = getelementptr i8, ptr %p180, i64 8
  %op179 = ptrtoint ptr %gep181 to i64
  store i64 %op179, ptr %slot31, align 8
  %v182 = load i64, ptr %slot31, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 0, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot30, align 8
  %p186 = inttoptr i64 %v184 to ptr
  %gep187 = getelementptr i8, ptr %p186, i64 16
  %op185 = ptrtoint ptr %gep187 to i64
  store i64 %op185, ptr %slot32, align 8
  %v188 = load i64, ptr %slot32, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 0, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot30, align 8
  %p192 = inttoptr i64 %v190 to ptr
  %gep193 = getelementptr i8, ptr %p192, i64 24
  %op191 = ptrtoint ptr %gep193 to i64
  store i64 %op191, ptr %slot33, align 8
  %v194 = load i64, ptr %slot33, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 0, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot30, align 8
  %p198 = inttoptr i64 %v196 to ptr
  %gep199 = getelementptr i8, ptr %p198, i64 32
  %op197 = ptrtoint ptr %gep199 to i64
  store i64 %op197, ptr %slot34, align 8
  %v200 = load i64, ptr %slot34, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i64 0, ptr %p201, align 8, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot30, align 8
  %p204 = inttoptr i64 %v202 to ptr
  %gep205 = getelementptr i8, ptr %p204, i64 40
  %op203 = ptrtoint ptr %gep205 to i64
  store i64 %op203, ptr %slot35, align 8
  %v206 = load i64, ptr %slot35, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 0, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot30, align 8
  %p210 = inttoptr i64 %v208 to ptr
  %gep211 = getelementptr i8, ptr %p210, i64 48
  %op209 = ptrtoint ptr %gep211 to i64
  store i64 %op209, ptr %slot36, align 8
  %v212 = load i64, ptr %slot36, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 0, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot10, align 8
  %p215 = inttoptr i64 %v214 to ptr
  store i32 1, ptr %p215, align 4, !alias.scope !3, !noalias !4
  %v216 = load i64, ptr %slot26, align 8
  store i64 %v216, ptr %slot37, align 8
  %v217 = load i64, ptr %slot17, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !3, !noalias !4
  store i64 %ld219, ptr %slot38, align 8
  %v220 = load i64, ptr %slot30, align 8
  %p222 = inttoptr i64 %v220 to ptr
  %gep223 = getelementptr i8, ptr %p222, i64 0
  %op221 = ptrtoint ptr %gep223 to i64
  store i64 %op221, ptr %slot39, align 8
  %v224 = load i64, ptr %slot38, align 8
  %v225 = load i64, ptr %slot39, align 8
  %p226 = inttoptr i64 %v224 to ptr
  %p227 = inttoptr i64 %v225 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p227, ptr %p226, i64 16, i1 false), !alias.scope !10000000
  %v228 = load i64, ptr %slot18, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %ld230 = load i64, ptr %p229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld230, ptr %slot40, align 8
  %v231 = load i64, ptr %slot30, align 8
  %p233 = inttoptr i64 %v231 to ptr
  %gep234 = getelementptr i8, ptr %p233, i64 16
  %op232 = ptrtoint ptr %gep234 to i64
  store i64 %op232, ptr %slot41, align 8
  %v235 = load i64, ptr %slot18, align 8
  %p236 = inttoptr i64 %v235 to ptr
  %ld237 = load i64, ptr %p236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld237, ptr %slot42, align 8
  store i32 0, ptr %slot43, align 8
  %v238 = load i64, ptr %slot8, align 8
  %p239 = inttoptr i64 %v238 to ptr
  %ld240 = load i32, ptr %p239, align 4, !alias.scope !3, !noalias !4
  store i32 %ld240, ptr %slot44, align 8
  %v241 = load i32, ptr %slot44, align 8
  %op242 = and i32 %v241, 24
  store i32 %op242, ptr %slot44, align 8
  %v243 = load i32, ptr %slot44, align 8
  %cmp244 = icmp eq i32 %v243, 0
  %cv245 = zext i1 %cmp244 to i32
  store i32 %cv245, ptr %slot45, align 8
  %v246 = load i32, ptr %slot43, align 8
  %v247 = load i32, ptr %slot45, align 8
  %op248 = and i32 %v246, %v247
  store i32 %op248, ptr %slot46, align 8
  %v249 = load i32, ptr %slot46, align 8
  %cv250 = zext i32 %v249 to i64
  %cond251 = icmp ne i64 %cv250, 0
  br i1 %cond251, label %bb_rctake27, label %bb_rccopy27
bb_rctake27:
  %v252 = load i64, ptr %slot12, align 8
  store i64 %v252, ptr %slot47, align 8
  %v253 = load i64, ptr %slot26, align 8
  store i64 %v253, ptr %slot48, align 8
  %v254 = load i64, ptr %slot25, align 8
  %v255 = load i64, ptr %slot47, align 8
  %v256 = load i64, ptr %slot42, align 8
  %v257 = load i64, ptr %slot48, align 8
  %cv258 = trunc i64 %v257 to i32
  %call259 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v254, i64 %v255, i64 %v256, i32 %cv258) nomerge, !dbg !114
  store i32 %call259, ptr %slot49, align 8
  %v260 = load i32, ptr %slot49, align 8
  %cv261 = zext i32 %v260 to i64
  %cond262 = icmp ne i64 %cv261, 0
  br i1 %cond262, label %bb_rcsuccess37, label %bb_rcfailure37
bb_rcfailure37:
  %v263 = load i64, ptr %slot25, align 8
  %p264 = inttoptr i64 %v263 to ptr
  %call265 = call i32 @myl_rc_take_failure(ptr %p264) nomerge, !dbg !114
  store i32 %call265, ptr %slot50, align 8
  %v266 = load i64, ptr %slot1, align 8
  %p267 = inttoptr i64 %v266 to ptr
  %v268 = load i32, ptr %slot50, align 8
  %call269 = call i32 @myl_qbe_rc_status(ptr %p267, i32 %v268) nomerge, !dbg !114
  store i32 %call269, ptr %slot51, align 8
  br label %bb_failure
bb_rcsuccess37:
  %v270 = load i64, ptr %slot9, align 8
  %p271 = inttoptr i64 %v270 to ptr
  store i32 1, ptr %p271, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared27
bb_rccopy27:
  %v272 = load i64, ptr %slot12, align 8
  store i64 %v272, ptr %slot52, align 8
  %v273 = load i64, ptr %slot26, align 8
  store i64 %v273, ptr %slot53, align 8
  %v274 = load i64, ptr %slot25, align 8
  %v275 = load i64, ptr %slot52, align 8
  %v276 = load i64, ptr %slot42, align 8
  %v277 = load i64, ptr %slot53, align 8
  %cv278 = trunc i64 %v277 to i32
  %call279 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v274, i64 %v275, i64 %v276, i32 %cv278) nomerge, !dbg !114
  store i32 %call279, ptr %slot54, align 8
  %v280 = load i32, ptr %slot54, align 8
  %cv281 = zext i32 %v280 to i64
  %cond282 = icmp ne i64 %cv281, 0
  br i1 %cond282, label %bb_rcsuccess46, label %bb_rcfailure46
bb_rcfailure46:
  %v283 = load i64, ptr %slot25, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %call285 = call i32 @myl_rc_take_failure(ptr %p284) nomerge, !dbg !114
  store i32 %call285, ptr %slot55, align 8
  %v286 = load i64, ptr %slot1, align 8
  %p287 = inttoptr i64 %v286 to ptr
  %v288 = load i32, ptr %slot55, align 8
  %call289 = call i32 @myl_qbe_rc_status(ptr %p287, i32 %v288) nomerge, !dbg !114
  store i32 %call289, ptr %slot56, align 8
  br label %bb_failure
bb_rcsuccess46:
  %v290 = load i64, ptr %slot9, align 8
  %p291 = inttoptr i64 %v290 to ptr
  store i32 1, ptr %p291, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared27
bb_rcprepared27:
  %v292 = load i64, ptr %slot12, align 8
  store i64 %v292, ptr %slot57, align 8
  %v293 = load i64, ptr %slot57, align 8
  %v294 = load i64, ptr %slot41, align 8
  %p295 = inttoptr i64 %v293 to ptr
  %p296 = inttoptr i64 %v294 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p296, ptr %p295, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v297 = load i64, ptr %slot9, align 8
  %p298 = inttoptr i64 %v297 to ptr
  store i32 0, ptr %p298, align 4, !alias.scope !3, !noalias !4
  %v299 = load i64, ptr %slot30, align 8
  %v300 = load i64, ptr %slot17, align 8
  %p301 = inttoptr i64 %v300 to ptr
  store i64 %v299, ptr %p301, align 8, !alias.scope !3, !noalias !4
  %v302 = load i64, ptr %slot17, align 8
  %p303 = inttoptr i64 %v302 to ptr
  %ld304 = load i64, ptr %p303, align 8, !alias.scope !3, !noalias !4
  store i64 %ld304, ptr %slot58, align 8
  %v305 = load i64, ptr %slot11, align 8
  store i64 %v305, ptr %slot59, align 8
  %v306 = load i64, ptr %slot58, align 8
  %v307 = load i64, ptr %slot59, align 8
  %p308 = inttoptr i64 %v306 to ptr
  %p309 = inttoptr i64 %v307 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p309, ptr %p308, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v310 = load i64, ptr %slot7, align 8
  %p311 = inttoptr i64 %v310 to ptr
  store i32 2, ptr %p311, align 4, !alias.scope !3, !noalias !4
  %v312 = load i64, ptr %slot6, align 8
  %p313 = inttoptr i64 %v312 to ptr
  store i32 1, ptr %p313, align 4, !alias.scope !3, !noalias !4
  %v314 = load i64, ptr %slot59, align 8
  %v315 = load i64, ptr %slot17, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 %v314, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot20, align 8
  store i64 %v317, ptr %slot60, align 8
  %v318 = load i64, ptr %slot60, align 8
  %p319 = inttoptr i64 %v318 to ptr
  call void @llvm.memset.p0.i64(ptr %p319, i8 0, i64 112, i1 false), !alias.scope !3, !noalias !4, !dbg !116
  %v320 = load i64, ptr %slot60, align 8
  %p321 = inttoptr i64 %v320 to ptr
  store i32 5, ptr %p321, align 4, !alias.scope !3, !noalias !4
  %v322 = load i64, ptr %slot10, align 8
  %p323 = inttoptr i64 %v322 to ptr
  store i32 1, ptr %p323, align 4, !alias.scope !3, !noalias !4
  %v324 = load i64, ptr %slot17, align 8
  %p325 = inttoptr i64 %v324 to ptr
  %ld326 = load i64, ptr %p325, align 8, !alias.scope !3, !noalias !4
  store i64 %ld326, ptr %slot61, align 8
  %v327 = load i64, ptr %slot60, align 8
  %p329 = inttoptr i64 %v327 to ptr
  %gep330 = getelementptr i8, ptr %p329, i64 8
  %op328 = ptrtoint ptr %gep330 to i64
  store i64 %op328, ptr %slot62, align 8
  %v331 = load i64, ptr %slot26, align 8
  store i64 %v331, ptr %slot63, align 8
  %v332 = load i64, ptr %slot17, align 8
  %p333 = inttoptr i64 %v332 to ptr
  %ld334 = load i64, ptr %p333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld334, ptr %slot64, align 8
  %v335 = load i64, ptr %slot12, align 8
  store i64 %v335, ptr %slot65, align 8
  %v336 = load i64, ptr %slot26, align 8
  store i64 %v336, ptr %slot66, align 8
  %v337 = load i64, ptr %slot25, align 8
  %v338 = load i64, ptr %slot65, align 8
  %v339 = load i64, ptr %slot64, align 8
  %v340 = load i64, ptr %slot66, align 8
  %cv341 = trunc i64 %v340 to i32
  %call342 = call i32 @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_take(i64 %v337, i64 %v338, i64 %v339, i32 %cv341) nomerge, !dbg !116
  store i32 %call342, ptr %slot67, align 8
  %v343 = load i32, ptr %slot67, align 8
  %cv344 = zext i32 %v343 to i64
  %cond345 = icmp ne i64 %cv344, 0
  br i1 %cond345, label %bb_rcsuccess76, label %bb_rcfailure76
bb_rcfailure76:
  %v346 = load i64, ptr %slot25, align 8
  %p347 = inttoptr i64 %v346 to ptr
  %call348 = call i32 @myl_rc_take_failure(ptr %p347) nomerge, !dbg !116
  store i32 %call348, ptr %slot68, align 8
  %v349 = load i64, ptr %slot1, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %v351 = load i32, ptr %slot68, align 8
  %call352 = call i32 @myl_qbe_rc_status(ptr %p350, i32 %v351) nomerge, !dbg !116
  store i32 %call352, ptr %slot69, align 8
  br label %bb_failure
bb_rcsuccess76:
  %v353 = load i64, ptr %slot6, align 8
  %p354 = inttoptr i64 %v353 to ptr
  store i32 0, ptr %p354, align 4, !alias.scope !3, !noalias !4
  %v355 = load i64, ptr %slot9, align 8
  %p356 = inttoptr i64 %v355 to ptr
  store i32 1, ptr %p356, align 4, !alias.scope !3, !noalias !4
  %v357 = load i64, ptr %slot12, align 8
  store i64 %v357, ptr %slot70, align 8
  %v358 = load i64, ptr %slot70, align 8
  %v359 = load i64, ptr %slot62, align 8
  %p360 = inttoptr i64 %v358 to ptr
  %p361 = inttoptr i64 %v359 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p361, ptr %p360, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot9, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i32 0, ptr %p363, align 4, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot60, align 8
  %v365 = load i64, ptr %slot17, align 8
  %p366 = inttoptr i64 %v365 to ptr
  store i64 %v364, ptr %p366, align 8, !alias.scope !3, !noalias !4
  %v367 = load i64, ptr %slot17, align 8
  %p368 = inttoptr i64 %v367 to ptr
  %ld369 = load i64, ptr %p368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld369, ptr %slot71, align 8
  %v370 = load i64, ptr %slot11, align 8
  store i64 %v370, ptr %slot72, align 8
  %v371 = load i64, ptr %slot71, align 8
  %v372 = load i64, ptr %slot72, align 8
  %p373 = inttoptr i64 %v371 to ptr
  %p374 = inttoptr i64 %v372 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p374, ptr %p373, i64 112, i1 false), !alias.scope !3, !noalias !4
  %v375 = load i64, ptr %slot7, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i32 2, ptr %p376, align 4, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot6, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i32 1, ptr %p378, align 4, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot72, align 8
  %v380 = load i64, ptr %slot17, align 8
  %p381 = inttoptr i64 %v380 to ptr
  store i64 %v379, ptr %p381, align 8, !alias.scope !3, !noalias !4
  %v382 = load i64, ptr %slot16, align 8
  %p383 = inttoptr i64 %v382 to ptr
  %ld384 = load i64, ptr %p383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld384, ptr %slot73, align 8
  %v385 = load i64, ptr %slot17, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %ld387 = load i64, ptr %p386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld387, ptr %slot74, align 8
  %v388 = load i64, ptr %slot1, align 8
  %v389 = load i64, ptr %slot73, align 8
  %v390 = load i64, ptr %slot74, align 8
  %call391 = call i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64 %v388, i64 %v389, i64 %v390) nomerge, !dbg !118
  store i64 %call391, ptr %slot75, align 8
  %v392 = load i64, ptr %slot75, align 8
  %v393 = load i64, ptr %slot16, align 8
  %p394 = inttoptr i64 %v393 to ptr
  store i64 %v392, ptr %p394, align 8, !alias.scope !3, !noalias !4
  %v395 = load i64, ptr %slot6, align 8
  %p396 = inttoptr i64 %v395 to ptr
  %ld397 = load i32, ptr %p396, align 4, !alias.scope !3, !noalias !4
  store i32 %ld397, ptr %slot76, align 8
  %v398 = load i32, ptr %slot76, align 8
  %cv399 = zext i32 %v398 to i64
  %cond400 = icmp ne i64 %cv399, 0
  br i1 %cond400, label %bb_rcslotdrop102, label %bb_rcslotdone102
bb_rcslotdrop102:
  %v401 = load i64, ptr %slot6, align 8
  %p402 = inttoptr i64 %v401 to ptr
  store i32 0, ptr %p402, align 4, !alias.scope !3, !noalias !4
  %v403 = load i64, ptr %slot11, align 8
  store i64 %v403, ptr %slot77, align 8
  %v404 = load i64, ptr %slot7, align 8
  %p405 = inttoptr i64 %v404 to ptr
  %ld406 = load i32, ptr %p405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld406, ptr %slot78, align 8
  %v407 = load i32, ptr %slot78, align 8
  %op408 = and i32 %v407, 28
  store i32 %op408, ptr %slot79, align 8
  %v409 = load i32, ptr %slot79, align 8
  %cv410 = zext i32 %v409 to i64
  %cond411 = icmp ne i64 %cv410, 0
  br i1 %cond411, label %bb_rcslotrole102, label %bb_rcslotowner102
bb_rcslotrole102:
  %v412 = load i64, ptr %slot25, align 8
  store i64 %v412, ptr %slot80, align 8
  %v413 = load i64, ptr %slot80, align 8
  %v414 = load i64, ptr %slot77, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v413, i64 %v414) nomerge, !dbg !118
  br label %bb_rcslotdone102
bb_rcslotowner102:
  %v415 = load i64, ptr %slot25, align 8
  store i64 %v415, ptr %slot81, align 8
  %v416 = load i64, ptr %slot81, align 8
  %v417 = load i64, ptr %slot77, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v416, i64 %v417) nomerge, !dbg !118
  br label %bb_rcslotdone102
bb_rcslotdone102:
  %v418 = load i64, ptr %slot16, align 8
  %p419 = inttoptr i64 %v418 to ptr
  %ld420 = load i64, ptr %p419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld420, ptr %slot82, align 8
  %v421 = load i64, ptr %slot82, align 8
  ret i64 %v421
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare i32 @myl_t_cbad636043bfc65ab333b2fde11e1288541f880848a209b50ad0e1b9e7ab9354_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623", linkageName: "myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 7106495066398206135, i64 0, !"myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!116 = !DILocation(line: 5, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
