target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v24 = load i64, ptr %slot1, align 8
  %op25 = add i64 %v24, 32
  store i64 %op25, ptr %slot3, align 8
  %mem26 = alloca i8, i64 8, align 8
  %ptr27 = ptrtoint ptr %mem26 to i64
  store i64 %ptr27, ptr %slot4, align 8
  %mem28 = alloca i8, i64 8, align 8
  %ptr29 = ptrtoint ptr %mem28 to i64
  store i64 %ptr29, ptr %slot5, align 8
  %mem30 = alloca i8, i64 8, align 8
  %ptr31 = ptrtoint ptr %mem30 to i64
  store i64 %ptr31, ptr %slot6, align 8
  %v32 = load i64, ptr %slot2, align 8
  %v33 = load i64, ptr %slot4, align 8
  %p34 = inttoptr i64 %v33 to ptr
  store i64 %v32, ptr %p34, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v35 = load i64, ptr %slot4, align 8
  %p36 = inttoptr i64 %v35 to ptr
  %ld37 = load i64, ptr %p36, align 8, !alias.scope !3, !noalias !4
  store i64 %ld37, ptr %slot7, align 8
  %v38 = load i64, ptr %slot7, align 8
  %v39 = load i64, ptr %slot6, align 8
  %p40 = inttoptr i64 %v39 to ptr
  store i64 %v38, ptr %p40, align 8, !alias.scope !3, !noalias !4
  %v41 = load i64, ptr %slot6, align 8
  %p42 = inttoptr i64 %v41 to ptr
  %ld43 = load i64, ptr %p42, align 8, !alias.scope !3, !noalias !4
  store i64 %ld43, ptr %slot8, align 8
  %v44 = load i64, ptr %slot8, align 8
  %p45 = inttoptr i64 %v44 to ptr
  %ld46 = load i32, ptr %p45, align 4, !alias.scope !4, !noalias !3
  %ext47 = zext i32 %ld46 to i64
  store i64 %ext47, ptr %slot9, align 8
  %v48 = load i64, ptr %slot9, align 8
  %cmp49 = icmp eq i64 %v48, 0
  %cv50 = zext i1 %cmp49 to i64
  store i64 %cv50, ptr %slot10, align 8
  %v51 = load i64, ptr %slot10, align 8
  %cond52 = icmp ne i64 %v51, 0
  br i1 %cond52, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i4
bb_armnext3:
  %v53 = load i64, ptr %slot9, align 8
  %cmp54 = icmp eq i64 %v53, 1
  %cv55 = zext i1 %cmp54 to i64
  store i64 %cv55, ptr %slot11, align 8
  %v56 = load i64, ptr %slot11, align 8
  %cond57 = icmp ne i64 %v56, 0
  br i1 %cond57, label %bb_arm4, label %bb_armnext4
bb_arm4:
  br label %bb_i8
bb_armnext4:
  %v58 = load i64, ptr %slot9, align 8
  %cmp59 = icmp eq i64 %v58, 2
  %cv60 = zext i1 %cmp59 to i64
  store i64 %cv60, ptr %slot12, align 8
  %v61 = load i64, ptr %slot12, align 8
  %cond62 = icmp ne i64 %v61, 0
  br i1 %cond62, label %bb_arm5, label %bb_armnext5
bb_arm5:
  br label %bb_i12
bb_armnext5:
  %v63 = load i64, ptr %slot9, align 8
  %cmp64 = icmp eq i64 %v63, 3
  %cv65 = zext i1 %cmp64 to i64
  store i64 %cv65, ptr %slot13, align 8
  %v66 = load i64, ptr %slot13, align 8
  %cond67 = icmp ne i64 %v66, 0
  br i1 %cond67, label %bb_arm6, label %bb_armnext6
bb_arm6:
  %v68 = load i64, ptr %slot8, align 8
  %op69 = add i64 %v68, 8
  store i64 %op69, ptr %slot14, align 8
  %v70 = load i64, ptr %slot14, align 8
  %p71 = inttoptr i64 %v70 to ptr
  %ld72 = load i64, ptr %p71, align 8, !alias.scope !4, !noalias !3
  store i64 %ld72, ptr %slot15, align 8
  %v73 = load i64, ptr %slot15, align 8
  %v74 = load i64, ptr %slot5, align 8
  %p75 = inttoptr i64 %v74 to ptr
  store i64 %v73, ptr %p75, align 8, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_armnext6:
  br label %bb_failure
bb_i2:
  %v76 = load i64, ptr %slot5, align 8
  %p77 = inttoptr i64 %v76 to ptr
  %ld78 = load i64, ptr %p77, align 8, !alias.scope !3, !noalias !4
  store i64 %ld78, ptr %slot16, align 8
  %v79 = load i64, ptr %slot16, align 8
  %v80 = load i64, ptr %slot6, align 8
  %p81 = inttoptr i64 %v80 to ptr
  store i64 %v79, ptr %p81, align 8, !alias.scope !3, !noalias !4
  %v82 = load i64, ptr %slot6, align 8
  %p83 = inttoptr i64 %v82 to ptr
  %ld84 = load i64, ptr %p83, align 8, !alias.scope !3, !noalias !4
  store i64 %ld84, ptr %slot17, align 8
  %v85 = load i64, ptr %slot17, align 8
  ret i64 %v85
bb_i4:
  %v86 = load i64, ptr %slot6, align 8
  %p87 = inttoptr i64 %v86 to ptr
  store i64 0, ptr %p87, align 8, !alias.scope !3, !noalias !4
  %v88 = load i64, ptr %slot6, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !3, !noalias !4
  store i64 %ld90, ptr %slot18, align 8
  %v91 = load i64, ptr %slot18, align 8
  %cond92 = icmp ne i64 %v91, 0
  br i1 %cond92, label %bb_success12, label %bb_failed12
bb_failed12:
  %v93 = load i64, ptr %slot1, align 8
  %p94 = inttoptr i64 %v93 to ptr
  call void @myl_qbe_fail_assert(ptr %p94) nomerge, !dbg !110
  unreachable
bb_success12:
  %v95 = load i64, ptr %slot6, align 8
  %p96 = inttoptr i64 %v95 to ptr
  store i64 18446744073709551615, ptr %p96, align 8, !alias.scope !3, !noalias !4
  %v97 = load i64, ptr %slot6, align 8
  %p98 = inttoptr i64 %v97 to ptr
  %ld99 = load i64, ptr %p98, align 8, !alias.scope !3, !noalias !4
  store i64 %ld99, ptr %slot19, align 8
  %v100 = load i64, ptr %slot19, align 8
  ret i64 %v100
bb_i8:
  %v101 = load i64, ptr %slot6, align 8
  %p102 = inttoptr i64 %v101 to ptr
  store i64 0, ptr %p102, align 8, !alias.scope !3, !noalias !4
  %v103 = load i64, ptr %slot6, align 8
  %p104 = inttoptr i64 %v103 to ptr
  %ld105 = load i64, ptr %p104, align 8, !alias.scope !3, !noalias !4
  store i64 %ld105, ptr %slot20, align 8
  %v106 = load i64, ptr %slot20, align 8
  %cond107 = icmp ne i64 %v106, 0
  br i1 %cond107, label %bb_success15, label %bb_failed15
bb_failed15:
  %v108 = load i64, ptr %slot1, align 8
  %p109 = inttoptr i64 %v108 to ptr
  call void @myl_qbe_fail_assert(ptr %p109) nomerge, !dbg !112
  unreachable
bb_success15:
  %v110 = load i64, ptr %slot6, align 8
  %p111 = inttoptr i64 %v110 to ptr
  store i64 18446744073709551615, ptr %p111, align 8, !alias.scope !3, !noalias !4
  %v112 = load i64, ptr %slot6, align 8
  %p113 = inttoptr i64 %v112 to ptr
  %ld114 = load i64, ptr %p113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld114, ptr %slot21, align 8
  %v115 = load i64, ptr %slot21, align 8
  ret i64 %v115
bb_i12:
  %v116 = load i64, ptr %slot6, align 8
  %p117 = inttoptr i64 %v116 to ptr
  store i64 0, ptr %p117, align 8, !alias.scope !3, !noalias !4
  %v118 = load i64, ptr %slot6, align 8
  %p119 = inttoptr i64 %v118 to ptr
  %ld120 = load i64, ptr %p119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld120, ptr %slot22, align 8
  %v121 = load i64, ptr %slot22, align 8
  %cond122 = icmp ne i64 %v121, 0
  br i1 %cond122, label %bb_success18, label %bb_failed18
bb_failed18:
  %v123 = load i64, ptr %slot1, align 8
  %p124 = inttoptr i64 %v123 to ptr
  call void @myl_qbe_fail_assert(ptr %p124) nomerge, !dbg !114
  unreachable
bb_success18:
  %v125 = load i64, ptr %slot6, align 8
  %p126 = inttoptr i64 %v125 to ptr
  store i64 18446744073709551615, ptr %p126, align 8, !alias.scope !3, !noalias !4
  %v127 = load i64, ptr %slot6, align 8
  %p128 = inttoptr i64 %v127 to ptr
  %ld129 = load i64, ptr %p128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld129, ptr %slot23, align 8
  %v130 = load i64, ptr %slot23, align 8
  ret i64 %v130
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @myl_qbe_fail_assert(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40", linkageName: "myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3043179287137645326, i64 0, !"myl_f_a9f74430ee4e948451728b3abe4d648b4eecdee44abb338e15267f988b669b40"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!110 = !DILocation(line: 6, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!112 = !DILocation(line: 10, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!114 = !DILocation(line: 14, column: 0, scope: !115)
