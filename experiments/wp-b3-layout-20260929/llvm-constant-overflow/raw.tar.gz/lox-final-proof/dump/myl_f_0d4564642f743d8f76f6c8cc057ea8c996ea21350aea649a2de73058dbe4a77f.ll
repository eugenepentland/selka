target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %callresult71 = alloca [24 x i8], align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i32, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i32, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i32, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i32, align 8
  %slot438 = alloca i32, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i32, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i32, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i32, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i32, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i64, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i32, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i32, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i32, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i32, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i32, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i32, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i32, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i32, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i32, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i32, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i32, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i32, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i32, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i32, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i32, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i32, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i32, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i32, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i64, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i32, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i32, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i32, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i32, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i32, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i32, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i32, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i32, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i32, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i32, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i32, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i32, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i32, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i32, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i32, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i32, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i64, align 8
  %slot1137 = alloca i32, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i32, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i32, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i32, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i32, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i32, align 8
  %slot1197 = alloca i32, align 8
  %slot1198 = alloca i32, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i32, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i32, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i32, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i32, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i64, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i32, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i32, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i32, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i32, align 8
  %slot1299 = alloca i64, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i32, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i32, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i32, align 8
  %slot1318 = alloca i32, align 8
  %slot1319 = alloca i32, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i32, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i64, align 8
  %slot1326 = alloca i32, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i32, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i32, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i32, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i64, align 8
  %slot1342 = alloca i64, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i64, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i64, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i64, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i64, align 8
  %slot1361 = alloca i64, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i32, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i32, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i32, align 8
  %slot1388 = alloca i32, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i32, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i32, align 8
  %slot1394 = alloca i32, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i32, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i64, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i32, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i32, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i32, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i32, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i64, align 8
  %slot1425 = alloca i32, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i32, align 8
  %slot1428 = alloca i32, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i32, align 8
  %slot1432 = alloca i32, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i32, align 8
  %slot1435 = alloca i32, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i32, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i32, align 8
  %slot1441 = alloca i32, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i32, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i32, align 8
  %slot1447 = alloca i32, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i64, align 8
  %slot1450 = alloca i32, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i32, align 8
  %slot1453 = alloca i32, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i32, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i32, align 8
  %slot1459 = alloca i32, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i32, align 8
  %slot1463 = alloca i64, align 8
  %slot1464 = alloca i32, align 8
  %slot1465 = alloca i32, align 8
  %slot1466 = alloca i64, align 8
  %slot1467 = alloca i64, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i32, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i32, align 8
  %slot1474 = alloca i32, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i64, align 8
  %slot1477 = alloca i32, align 8
  %slot1478 = alloca i32, align 8
  %slot1479 = alloca i64, align 8
  %slot1480 = alloca i32, align 8
  %slot1481 = alloca i32, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i32, align 8
  %slot1485 = alloca i64, align 8
  %slot1486 = alloca i32, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i32, align 8
  %slot1491 = alloca i64, align 8
  %slot1492 = alloca i32, align 8
  %slot1493 = alloca i32, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i64, align 8
  %slot1496 = alloca i32, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i32, align 8
  %slot1499 = alloca i32, align 8
  %slot1500 = alloca i64, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i32, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i32, align 8
  %slot1505 = alloca i32, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i32, align 8
  %slot1509 = alloca i64, align 8
  %slot1510 = alloca i32, align 8
  %slot1511 = alloca i32, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1514 = load i64, ptr %slot1, align 8
  %op1515 = add i64 %v1514, 32
  store i64 %op1515, ptr %slot4, align 8
  %mem1516 = alloca i8, i64 8, align 8
  %ptr1517 = ptrtoint ptr %mem1516 to i64
  store i64 %ptr1517, ptr %slot5, align 8
  %mem1518 = alloca i8, i64 8, align 8
  %ptr1519 = ptrtoint ptr %mem1518 to i64
  store i64 %ptr1519, ptr %slot6, align 8
  %mem1520 = alloca i8, i64 8, align 8
  %ptr1521 = ptrtoint ptr %mem1520 to i64
  store i64 %ptr1521, ptr %slot7, align 8
  %mem1522 = alloca i8, i64 8, align 8
  %ptr1523 = ptrtoint ptr %mem1522 to i64
  store i64 %ptr1523, ptr %slot8, align 8
  %mem1524 = alloca i8, i64 8, align 8
  %ptr1525 = ptrtoint ptr %mem1524 to i64
  store i64 %ptr1525, ptr %slot9, align 8
  %mem1526 = alloca i8, i64 8, align 8
  %ptr1527 = ptrtoint ptr %mem1526 to i64
  store i64 %ptr1527, ptr %slot10, align 8
  %mem1528 = alloca i8, i64 8, align 8
  %ptr1529 = ptrtoint ptr %mem1528 to i64
  store i64 %ptr1529, ptr %slot11, align 8
  %mem1530 = alloca i8, i64 8, align 8
  %ptr1531 = ptrtoint ptr %mem1530 to i64
  store i64 %ptr1531, ptr %slot12, align 8
  %mem1532 = alloca i8, i64 8, align 8
  %ptr1533 = ptrtoint ptr %mem1532 to i64
  store i64 %ptr1533, ptr %slot13, align 8
  %mem1534 = alloca i8, i64 8, align 8
  %ptr1535 = ptrtoint ptr %mem1534 to i64
  store i64 %ptr1535, ptr %slot14, align 8
  %mem1536 = alloca i8, i64 8, align 8
  %ptr1537 = ptrtoint ptr %mem1536 to i64
  store i64 %ptr1537, ptr %slot15, align 8
  %mem1538 = alloca i8, i64 8, align 8
  %ptr1539 = ptrtoint ptr %mem1538 to i64
  store i64 %ptr1539, ptr %slot16, align 8
  %mem1540 = alloca i8, i64 8, align 8
  %ptr1541 = ptrtoint ptr %mem1540 to i64
  store i64 %ptr1541, ptr %slot17, align 8
  %mem1542 = alloca i8, i64 8, align 8
  %ptr1543 = ptrtoint ptr %mem1542 to i64
  store i64 %ptr1543, ptr %slot18, align 8
  %mem1544 = alloca i8, i64 8, align 8
  %ptr1545 = ptrtoint ptr %mem1544 to i64
  store i64 %ptr1545, ptr %slot19, align 8
  %mem1546 = alloca i8, i64 8, align 8
  %ptr1547 = ptrtoint ptr %mem1546 to i64
  store i64 %ptr1547, ptr %slot20, align 8
  %mem1548 = alloca i8, i64 8, align 8
  %ptr1549 = ptrtoint ptr %mem1548 to i64
  store i64 %ptr1549, ptr %slot21, align 8
  %mem1550 = alloca i8, i64 8, align 8
  %ptr1551 = ptrtoint ptr %mem1550 to i64
  store i64 %ptr1551, ptr %slot22, align 8
  %mem1552 = alloca i8, i64 8, align 8
  %ptr1553 = ptrtoint ptr %mem1552 to i64
  store i64 %ptr1553, ptr %slot23, align 8
  %mem1554 = alloca i8, i64 8, align 8
  %ptr1555 = ptrtoint ptr %mem1554 to i64
  store i64 %ptr1555, ptr %slot24, align 8
  %mem1556 = alloca i8, i64 8, align 8
  %ptr1557 = ptrtoint ptr %mem1556 to i64
  store i64 %ptr1557, ptr %slot25, align 8
  %mem1558 = alloca i8, i64 392, align 8
  %ptr1559 = ptrtoint ptr %mem1558 to i64
  store i64 %ptr1559, ptr %slot26, align 8
  %mem1560 = alloca i8, i64 88, align 8
  %ptr1561 = ptrtoint ptr %mem1560 to i64
  store i64 %ptr1561, ptr %slot27, align 8
  %mem1562 = alloca i8, i64 24, align 8
  %ptr1563 = ptrtoint ptr %mem1562 to i64
  store i64 %ptr1563, ptr %slot28, align 8
  %mem1564 = alloca i8, i64 8, align 8
  %ptr1565 = ptrtoint ptr %mem1564 to i64
  store i64 %ptr1565, ptr %slot29, align 8
  %mem1566 = alloca i8, i64 8, align 8
  %ptr1567 = ptrtoint ptr %mem1566 to i64
  store i64 %ptr1567, ptr %slot30, align 8
  %mem1568 = alloca i8, i64 392, align 8
  %ptr1569 = ptrtoint ptr %mem1568 to i64
  store i64 %ptr1569, ptr %slot31, align 8
  %mem1570 = alloca i8, i64 32, align 8
  %ptr1571 = ptrtoint ptr %mem1570 to i64
  store i64 %ptr1571, ptr %slot32, align 8
  %v1572 = load i64, ptr %slot32, align 8
  %p1574 = inttoptr i64 %v1572 to ptr
  %gep1575 = getelementptr i8, ptr %p1574, i64 24
  %op1573 = ptrtoint ptr %gep1575 to i64
  store i64 %op1573, ptr %slot33, align 8
  %v1576 = load i64, ptr %slot33, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  store i64 0, ptr %p1577, align 8, !alias.scope !3, !noalias !4
  %mem1578 = alloca i8, i64 32, align 8
  %ptr1579 = ptrtoint ptr %mem1578 to i64
  store i64 %ptr1579, ptr %slot34, align 8
  %v1580 = load i64, ptr %slot34, align 8
  %p1582 = inttoptr i64 %v1580 to ptr
  %gep1583 = getelementptr i8, ptr %p1582, i64 24
  %op1581 = ptrtoint ptr %gep1583 to i64
  store i64 %op1581, ptr %slot35, align 8
  %v1584 = load i64, ptr %slot35, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  store i64 0, ptr %p1585, align 8, !alias.scope !3, !noalias !4
  %mem1586 = alloca i8, i64 16, align 8
  %ptr1587 = ptrtoint ptr %mem1586 to i64
  store i64 %ptr1587, ptr %slot36, align 8
  %mem1588 = alloca i8, i64 8, align 8
  %ptr1589 = ptrtoint ptr %mem1588 to i64
  store i64 %ptr1589, ptr %slot37, align 8
  %mem1590 = alloca i8, i64 8, align 8
  %ptr1591 = ptrtoint ptr %mem1590 to i64
  store i64 %ptr1591, ptr %slot38, align 8
  %mem1592 = alloca i8, i64 24, align 8
  %ptr1593 = ptrtoint ptr %mem1592 to i64
  store i64 %ptr1593, ptr %slot39, align 8
  %mem1594 = alloca i8, i64 8, align 8
  %ptr1595 = ptrtoint ptr %mem1594 to i64
  store i64 %ptr1595, ptr %slot40, align 8
  %mem1596 = alloca i8, i64 8, align 8
  %ptr1597 = ptrtoint ptr %mem1596 to i64
  store i64 %ptr1597, ptr %slot41, align 8
  %mem1598 = alloca i8, i64 8, align 8
  %ptr1599 = ptrtoint ptr %mem1598 to i64
  store i64 %ptr1599, ptr %slot42, align 8
  %mem1600 = alloca i8, i64 8, align 8
  %ptr1601 = ptrtoint ptr %mem1600 to i64
  store i64 %ptr1601, ptr %slot43, align 8
  %mem1602 = alloca i8, i64 8, align 8
  %ptr1603 = ptrtoint ptr %mem1602 to i64
  store i64 %ptr1603, ptr %slot44, align 8
  %mem1604 = alloca i8, i64 88, align 8
  %ptr1605 = ptrtoint ptr %mem1604 to i64
  store i64 %ptr1605, ptr %slot45, align 8
  %mem1606 = alloca i8, i64 88, align 8
  %ptr1607 = ptrtoint ptr %mem1606 to i64
  store i64 %ptr1607, ptr %slot46, align 8
  %mem1608 = alloca i8, i64 24, align 8
  %ptr1609 = ptrtoint ptr %mem1608 to i64
  store i64 %ptr1609, ptr %slot47, align 8
  %mem1610 = alloca i8, i64 8, align 8
  %ptr1611 = ptrtoint ptr %mem1610 to i64
  store i64 %ptr1611, ptr %slot48, align 8
  %mem1612 = alloca i8, i64 88, align 8
  %ptr1613 = ptrtoint ptr %mem1612 to i64
  store i64 %ptr1613, ptr %slot49, align 8
  %mem1614 = alloca i8, i64 8, align 8
  %ptr1615 = ptrtoint ptr %mem1614 to i64
  store i64 %ptr1615, ptr %slot50, align 8
  %mem1616 = alloca i8, i64 8, align 8
  %ptr1617 = ptrtoint ptr %mem1616 to i64
  store i64 %ptr1617, ptr %slot51, align 8
  %mem1618 = alloca i8, i64 56, align 8
  %ptr1619 = ptrtoint ptr %mem1618 to i64
  store i64 %ptr1619, ptr %slot52, align 8
  %mem1620 = alloca i8, i64 8, align 8
  %ptr1621 = ptrtoint ptr %mem1620 to i64
  store i64 %ptr1621, ptr %slot53, align 8
  %mem1622 = alloca i8, i64 8, align 8
  %ptr1623 = ptrtoint ptr %mem1622 to i64
  store i64 %ptr1623, ptr %slot54, align 8
  %mem1624 = alloca i8, i64 8, align 8
  %ptr1625 = ptrtoint ptr %mem1624 to i64
  store i64 %ptr1625, ptr %slot55, align 8
  %mem1626 = alloca i8, i64 8, align 8
  %ptr1627 = ptrtoint ptr %mem1626 to i64
  store i64 %ptr1627, ptr %slot56, align 8
  %mem1628 = alloca i8, i64 88, align 8
  %ptr1629 = ptrtoint ptr %mem1628 to i64
  store i64 %ptr1629, ptr %slot57, align 8
  %mem1630 = alloca i8, i64 88, align 8
  %ptr1631 = ptrtoint ptr %mem1630 to i64
  store i64 %ptr1631, ptr %slot58, align 8
  %mem1632 = alloca i8, i64 56, align 8
  %ptr1633 = ptrtoint ptr %mem1632 to i64
  store i64 %ptr1633, ptr %slot59, align 8
  %mem1634 = alloca i8, i64 56, align 8
  %ptr1635 = ptrtoint ptr %mem1634 to i64
  store i64 %ptr1635, ptr %slot60, align 8
  br label %bb_frameadmit2
bb_frameadmit2:
  %mem1636 = alloca i8, i64 8, align 8
  %ptr1637 = ptrtoint ptr %mem1636 to i64
  store i64 %ptr1637, ptr %slot61, align 8
  %v1638 = load i64, ptr %slot1, align 8
  %op1639 = add i64 %v1638, 64
  store i64 %op1639, ptr %slot62, align 8
  %v1640 = load i64, ptr %slot62, align 8
  %p1641 = inttoptr i64 %v1640 to ptr
  %ld1642 = load i64, ptr %p1641, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1642, ptr %slot63, align 8
  %stack1643 = call ptr @llvm.stacksave()
  %stackaddr1644 = ptrtoint ptr %stack1643 to i64
  %v1645 = load i64, ptr %slot63, align 8
  %cmp1646 = icmp ult i64 %stackaddr1644, %v1645
  %cv1647 = zext i1 %cmp1646 to i64
  store i64 %cv1647, ptr %slot64, align 8
  %v1648 = load i64, ptr %slot64, align 8
  %cond1649 = icmp ne i64 %v1648, 0
  br i1 %cond1649, label %bb_floorfail4, label %bb_stackadmit3
bb_floorfail4:
  %v1650 = load i64, ptr %slot1, align 8
  %p1651 = inttoptr i64 %v1650 to ptr
  call void @myl_qbe_fail_frame(ptr %p1651) nomerge, !dbg !110
  unreachable
bb_stackadmit3:
  %mem1652 = alloca i8, i64 88, align 8
  %ptr1653 = ptrtoint ptr %mem1652 to i64
  store i64 %ptr1653, ptr %slot65, align 8
  %v1654 = load i64, ptr %slot41, align 8
  %p1655 = inttoptr i64 %v1654 to ptr
  store i64 0, ptr %p1655, align 8, !alias.scope !3, !noalias !4
  %v1656 = load i64, ptr %slot43, align 8
  %p1657 = inttoptr i64 %v1656 to ptr
  store i64 0, ptr %p1657, align 8, !alias.scope !3, !noalias !4
  %v1658 = load i64, ptr %slot48, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  store i64 0, ptr %p1659, align 8, !alias.scope !3, !noalias !4
  %v1660 = load i64, ptr %slot51, align 8
  %p1661 = inttoptr i64 %v1660 to ptr
  store i64 0, ptr %p1661, align 8, !alias.scope !3, !noalias !4
  %v1662 = load i64, ptr %slot2, align 8
  %v1663 = load i64, ptr %slot37, align 8
  %p1664 = inttoptr i64 %v1663 to ptr
  store i64 %v1662, ptr %p1664, align 8, !alias.scope !3, !noalias !4
  %v1665 = load i64, ptr %slot3, align 8
  %v1666 = load i64, ptr %slot38, align 8
  %p1667 = inttoptr i64 %v1666 to ptr
  store i64 %v1665, ptr %p1667, align 8, !alias.scope !3, !noalias !4
  %v1668 = load i64, ptr %slot1, align 8
  %p1669 = inttoptr i64 %v1668 to ptr
  %call1670 = call ptr @myl_qbe_heap(ptr %p1669) nomerge, !dbg !112
  %calladdr1671 = ptrtoint ptr %call1670 to i64
  store i64 %calladdr1671, ptr %slot66, align 8
  %v1672 = load i64, ptr %slot1, align 8
  %p1673 = inttoptr i64 %v1672 to ptr
  %call1674 = call i64 @myl_qbe_region_mark(ptr %p1673) nomerge, !dbg !112
  store i64 %call1674, ptr %slot67, align 8
  %v1675 = load i64, ptr %slot5, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  store i32 0, ptr %p1676, align 4, !alias.scope !3, !noalias !4
  %v1677 = load i64, ptr %slot6, align 8
  %p1678 = inttoptr i64 %v1677 to ptr
  store i32 0, ptr %p1678, align 4, !alias.scope !3, !noalias !4
  %v1679 = load i64, ptr %slot7, align 8
  %p1680 = inttoptr i64 %v1679 to ptr
  store i32 0, ptr %p1680, align 4, !alias.scope !3, !noalias !4
  %v1681 = load i64, ptr %slot8, align 8
  %p1682 = inttoptr i64 %v1681 to ptr
  store i32 0, ptr %p1682, align 4, !alias.scope !3, !noalias !4
  %v1683 = load i64, ptr %slot9, align 8
  %p1684 = inttoptr i64 %v1683 to ptr
  store i32 0, ptr %p1684, align 4, !alias.scope !3, !noalias !4
  %v1685 = load i64, ptr %slot10, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  store i32 0, ptr %p1686, align 4, !alias.scope !3, !noalias !4
  %v1687 = load i64, ptr %slot11, align 8
  %p1688 = inttoptr i64 %v1687 to ptr
  store i32 0, ptr %p1688, align 4, !alias.scope !3, !noalias !4
  %v1689 = load i64, ptr %slot12, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i32 0, ptr %p1690, align 4, !alias.scope !3, !noalias !4
  %v1691 = load i64, ptr %slot13, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  store i32 0, ptr %p1692, align 4, !alias.scope !3, !noalias !4
  %v1693 = load i64, ptr %slot14, align 8
  %p1694 = inttoptr i64 %v1693 to ptr
  store i32 0, ptr %p1694, align 4, !alias.scope !3, !noalias !4
  %v1695 = load i64, ptr %slot15, align 8
  %p1696 = inttoptr i64 %v1695 to ptr
  store i32 0, ptr %p1696, align 4, !alias.scope !3, !noalias !4
  %v1697 = load i64, ptr %slot16, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  store i32 0, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  %v1699 = load i64, ptr %slot17, align 8
  %p1700 = inttoptr i64 %v1699 to ptr
  store i32 0, ptr %p1700, align 4, !alias.scope !3, !noalias !4
  %v1701 = load i64, ptr %slot18, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  store i32 0, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  %v1703 = load i64, ptr %slot19, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  store i32 0, ptr %p1704, align 4, !alias.scope !3, !noalias !4
  %v1705 = load i64, ptr %slot20, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  store i32 0, ptr %p1706, align 4, !alias.scope !3, !noalias !4
  %v1707 = load i64, ptr %slot21, align 8
  %p1708 = inttoptr i64 %v1707 to ptr
  store i32 0, ptr %p1708, align 4, !alias.scope !3, !noalias !4
  %v1709 = load i64, ptr %slot22, align 8
  %p1710 = inttoptr i64 %v1709 to ptr
  store i32 0, ptr %p1710, align 4, !alias.scope !3, !noalias !4
  %v1711 = load i64, ptr %slot23, align 8
  %p1712 = inttoptr i64 %v1711 to ptr
  store i32 0, ptr %p1712, align 4, !alias.scope !3, !noalias !4
  %v1713 = load i64, ptr %slot24, align 8
  %p1714 = inttoptr i64 %v1713 to ptr
  store i32 0, ptr %p1714, align 4, !alias.scope !3, !noalias !4
  %v1715 = load i64, ptr %slot25, align 8
  %p1716 = inttoptr i64 %v1715 to ptr
  store i32 0, ptr %p1716, align 4, !alias.scope !3, !noalias !4
  %v1717 = load i64, ptr %slot6, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  store i32 2, ptr %p1718, align 4, !alias.scope !3, !noalias !4
  %v1719 = load i64, ptr %slot8, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  store i32 2, ptr %p1720, align 4, !alias.scope !3, !noalias !4
  %v1721 = load i64, ptr %slot10, align 8
  %p1722 = inttoptr i64 %v1721 to ptr
  store i32 2, ptr %p1722, align 4, !alias.scope !3, !noalias !4
  %v1723 = load i64, ptr %slot12, align 8
  %p1724 = inttoptr i64 %v1723 to ptr
  store i32 2, ptr %p1724, align 4, !alias.scope !3, !noalias !4
  %v1725 = load i64, ptr %slot14, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  store i32 2, ptr %p1726, align 4, !alias.scope !3, !noalias !4
  %v1727 = load i64, ptr %slot16, align 8
  %p1728 = inttoptr i64 %v1727 to ptr
  store i32 2, ptr %p1728, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1729 = load i64, ptr %slot37, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %ld1731 = load i64, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1731, ptr %slot68, align 8
  %v1732 = load i64, ptr %slot68, align 8
  %v1733 = load i64, ptr %slot54, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i64 %v1732, ptr %p1734, align 8, !alias.scope !3, !noalias !4
  %v1735 = load i64, ptr %slot54, align 8
  %p1736 = inttoptr i64 %v1735 to ptr
  %ld1737 = load i64, ptr %p1736, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1737, ptr %slot69, align 8
  %v1738 = load i64, ptr %slot1, align 8
  %v1739 = load i64, ptr %slot69, align 8
  call void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8 %callresult71, i64 %v1738, i64 %v1739) nomerge, !dbg !114
  %addr1740 = ptrtoint ptr %callresult71 to i64
  store i64 %addr1740, ptr %slot70, align 8
  %v1741 = load i64, ptr %slot70, align 8
  %v1742 = load i64, ptr %slot54, align 8
  %p1743 = inttoptr i64 %v1742 to ptr
  store i64 %v1741, ptr %p1743, align 8, !alias.scope !3, !noalias !4
  %v1744 = load i64, ptr %slot54, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  %ld1746 = load i64, ptr %p1745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1746, ptr %slot72, align 8
  %v1747 = load i64, ptr %slot31, align 8
  store i64 %v1747, ptr %slot73, align 8
  %v1748 = load i64, ptr %slot72, align 8
  %v1749 = load i64, ptr %slot73, align 8
  %p1750 = inttoptr i64 %v1748 to ptr
  %p1751 = inttoptr i64 %v1749 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1751, ptr %p1750, i64 24, i1 false)
  %v1752 = load i64, ptr %slot24, align 8
  %p1753 = inttoptr i64 %v1752 to ptr
  store i32 2, ptr %p1753, align 4, !alias.scope !3, !noalias !4
  %v1754 = load i64, ptr %slot23, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  store i32 1, ptr %p1755, align 4, !alias.scope !3, !noalias !4
  %v1756 = load i64, ptr %slot17, align 8
  %p1757 = inttoptr i64 %v1756 to ptr
  %ld1758 = load i32, ptr %p1757, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1758, ptr %slot74, align 8
  %v1759 = load i32, ptr %slot74, align 8
  %cv1760 = zext i32 %v1759 to i64
  %cond1761 = icmp ne i64 %cv1760, 0
  br i1 %cond1761, label %bb_rcslotdrop29, label %bb_rcslotdone29
bb_rcslotdrop29:
  %v1762 = load i64, ptr %slot17, align 8
  %p1763 = inttoptr i64 %v1762 to ptr
  store i32 0, ptr %p1763, align 4, !alias.scope !3, !noalias !4
  %v1764 = load i64, ptr %slot26, align 8
  store i64 %v1764, ptr %slot75, align 8
  %v1765 = load i64, ptr %slot18, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  %ld1767 = load i32, ptr %p1766, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1767, ptr %slot76, align 8
  %v1768 = load i32, ptr %slot76, align 8
  %op1769 = and i32 %v1768, 28
  store i32 %op1769, ptr %slot77, align 8
  %v1770 = load i32, ptr %slot77, align 8
  %cv1771 = zext i32 %v1770 to i64
  %cond1772 = icmp ne i64 %cv1771, 0
  br i1 %cond1772, label %bb_rcslotrole29, label %bb_rcslotowner29
bb_rcslotrole29:
  %v1773 = load i64, ptr %slot66, align 8
  store i64 %v1773, ptr %slot78, align 8
  %v1774 = load i64, ptr %slot78, align 8
  %v1775 = load i64, ptr %slot75, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1774, i64 %v1775) nomerge, !dbg !114
  br label %bb_rcslotdone29
bb_rcslotowner29:
  %v1776 = load i64, ptr %slot66, align 8
  store i64 %v1776, ptr %slot79, align 8
  %v1777 = load i64, ptr %slot79, align 8
  %v1778 = load i64, ptr %slot75, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1777, i64 %v1778) nomerge, !dbg !114
  br label %bb_rcslotdone29
bb_rcslotdone29:
  %v1779 = load i64, ptr %slot26, align 8
  store i64 %v1779, ptr %slot80, align 8
  %v1780 = load i64, ptr %slot31, align 8
  store i64 %v1780, ptr %slot81, align 8
  %v1781 = load i64, ptr %slot81, align 8
  %v1782 = load i64, ptr %slot80, align 8
  %p1783 = inttoptr i64 %v1781 to ptr
  %p1784 = inttoptr i64 %v1782 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1784, ptr %p1783, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1785 = load i64, ptr %slot18, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  store i32 2, ptr %p1786, align 4, !alias.scope !3, !noalias !4
  %v1787 = load i64, ptr %slot24, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  %ld1789 = load i32, ptr %p1788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1789, ptr %slot82, align 8
  %v1790 = load i32, ptr %slot82, align 8
  %v1791 = load i64, ptr %slot18, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  store i32 %v1790, ptr %p1792, align 4, !alias.scope !3, !noalias !4
  %v1793 = load i64, ptr %slot23, align 8
  %p1794 = inttoptr i64 %v1793 to ptr
  store i32 0, ptr %p1794, align 4, !alias.scope !3, !noalias !4
  %v1795 = load i64, ptr %slot17, align 8
  %p1796 = inttoptr i64 %v1795 to ptr
  store i32 1, ptr %p1796, align 4, !alias.scope !3, !noalias !4
  %v1797 = load i64, ptr %slot80, align 8
  %v1798 = load i64, ptr %slot54, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  store i64 %v1797, ptr %p1799, align 8, !alias.scope !3, !noalias !4
  %v1800 = load i64, ptr %slot54, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %ld1802 = load i64, ptr %p1801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1802, ptr %slot83, align 8
  %v1803 = load i64, ptr %slot31, align 8
  store i64 %v1803, ptr %slot84, align 8
  %v1804 = load i64, ptr %slot67, align 8
  store i64 %v1804, ptr %slot85, align 8
  %v1805 = load i64, ptr %slot83, align 8
  %op1806 = add i64 %v1805, 0
  store i64 %op1806, ptr %slot86, align 8
  %v1807 = load i64, ptr %slot86, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  %ld1809 = load i64, ptr %p1808, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1809, ptr %slot87, align 8
  %v1810 = load i64, ptr %slot87, align 8
  %cmp1811 = icmp ne i64 %v1810, 0
  %cv1812 = zext i1 %cmp1811 to i32
  store i32 %cv1812, ptr %slot88, align 8
  %v1813 = load i32, ptr %slot88, align 8
  %cv1814 = zext i32 %v1813 to i64
  %cond1815 = icmp ne i64 %cv1814, 0
  br i1 %cond1815, label %bb_rcmoveheader50, label %bb_rcmovenext50
bb_rcmoveheader50:
  %v1816 = load i64, ptr %slot87, align 8
  %op1817 = sub i64 %v1816, 16
  store i64 %op1817, ptr %slot89, align 8
  %v1818 = load i64, ptr %slot87, align 8
  %p1819 = inttoptr i64 %v1818 to ptr
  %rgep1820 = getelementptr i8, ptr %p1819, i64 -16
  %ld1821 = load i64, ptr %rgep1820, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1821, ptr %slot90, align 8
  %v1822 = load i64, ptr %slot90, align 8
  %op1823 = and i64 %v1822, 5764607523034234881
  store i64 %op1823, ptr %slot91, align 8
  %v1824 = load i64, ptr %slot91, align 8
  %cmp1825 = icmp ne i64 %v1824, 0
  %cv1826 = zext i1 %cmp1825 to i32
  store i32 %cv1826, ptr %slot92, align 8
  %v1827 = load i32, ptr %slot92, align 8
  %cv1828 = zext i32 %v1827 to i64
  %cond1829 = icmp ne i64 %cv1828, 0
  br i1 %cond1829, label %bb_rcmoveslow47, label %bb_rcmovenext50
bb_rcmovenext50:
  %v1830 = load i64, ptr %slot83, align 8
  %op1831 = add i64 %v1830, 8
  store i64 %op1831, ptr %slot93, align 8
  %v1832 = load i64, ptr %slot93, align 8
  %p1833 = inttoptr i64 %v1832 to ptr
  %ld1834 = load i64, ptr %p1833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1834, ptr %slot94, align 8
  %v1835 = load i64, ptr %slot94, align 8
  %cmp1836 = icmp ne i64 %v1835, 0
  %cv1837 = zext i1 %cmp1836 to i32
  store i32 %cv1837, ptr %slot95, align 8
  %v1838 = load i32, ptr %slot95, align 8
  %cv1839 = zext i32 %v1838 to i64
  %cond1840 = icmp ne i64 %cv1839, 0
  br i1 %cond1840, label %bb_rcmoveheader58, label %bb_rcmovenext58
bb_rcmoveheader58:
  %v1841 = load i64, ptr %slot94, align 8
  %op1842 = sub i64 %v1841, 16
  store i64 %op1842, ptr %slot96, align 8
  %v1843 = load i64, ptr %slot94, align 8
  %p1844 = inttoptr i64 %v1843 to ptr
  %rgep1845 = getelementptr i8, ptr %p1844, i64 -16
  %ld1846 = load i64, ptr %rgep1845, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1846, ptr %slot97, align 8
  %v1847 = load i64, ptr %slot97, align 8
  %op1848 = and i64 %v1847, 5764607523034234881
  store i64 %op1848, ptr %slot98, align 8
  %v1849 = load i64, ptr %slot98, align 8
  %cmp1850 = icmp ne i64 %v1849, 0
  %cv1851 = zext i1 %cmp1850 to i32
  store i32 %cv1851, ptr %slot99, align 8
  %v1852 = load i32, ptr %slot99, align 8
  %cv1853 = zext i32 %v1852 to i64
  %cond1854 = icmp ne i64 %cv1853, 0
  br i1 %cond1854, label %bb_rcmoveslow47, label %bb_rcmovenext58
bb_rcmovenext58:
  %v1855 = load i64, ptr %slot83, align 8
  %op1856 = add i64 %v1855, 16
  store i64 %op1856, ptr %slot100, align 8
  %v1857 = load i64, ptr %slot100, align 8
  %p1858 = inttoptr i64 %v1857 to ptr
  %ld1859 = load i64, ptr %p1858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1859, ptr %slot101, align 8
  %v1860 = load i64, ptr %slot101, align 8
  %cmp1861 = icmp ne i64 %v1860, 0
  %cv1862 = zext i1 %cmp1861 to i32
  store i32 %cv1862, ptr %slot102, align 8
  %v1863 = load i32, ptr %slot102, align 8
  %cv1864 = zext i32 %v1863 to i64
  %cond1865 = icmp ne i64 %cv1864, 0
  br i1 %cond1865, label %bb_rcmoveheader66, label %bb_rcmovenext66
bb_rcmoveheader66:
  %v1866 = load i64, ptr %slot101, align 8
  %op1867 = sub i64 %v1866, 16
  store i64 %op1867, ptr %slot103, align 8
  %v1868 = load i64, ptr %slot101, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  %rgep1870 = getelementptr i8, ptr %p1869, i64 -16
  %ld1871 = load i64, ptr %rgep1870, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1871, ptr %slot104, align 8
  %v1872 = load i64, ptr %slot104, align 8
  %op1873 = and i64 %v1872, 5764607523034234881
  store i64 %op1873, ptr %slot105, align 8
  %v1874 = load i64, ptr %slot105, align 8
  %cmp1875 = icmp ne i64 %v1874, 0
  %cv1876 = zext i1 %cmp1875 to i32
  store i32 %cv1876, ptr %slot106, align 8
  %v1877 = load i32, ptr %slot106, align 8
  %cv1878 = zext i32 %v1877 to i64
  %cond1879 = icmp ne i64 %cv1878, 0
  br i1 %cond1879, label %bb_rcmoveslow47, label %bb_rcmovenext66
bb_rcmovenext66:
  %v1880 = load i64, ptr %slot83, align 8
  %v1881 = load i64, ptr %slot84, align 8
  %p1882 = inttoptr i64 %v1880 to ptr
  %p1883 = inttoptr i64 %v1881 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1883, ptr %p1882, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1884 = load i64, ptr %slot83, align 8
  %p1885 = inttoptr i64 %v1884 to ptr
  store i64 0, ptr %p1885, align 8, !alias.scope !3, !noalias !4
  %v1886 = load i64, ptr %slot83, align 8
  %op1887 = add i64 %v1886, 8
  store i64 %op1887, ptr %slot107, align 8
  %v1888 = load i64, ptr %slot107, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i64 0, ptr %p1889, align 8, !alias.scope !3, !noalias !4
  %v1890 = load i64, ptr %slot83, align 8
  %op1891 = add i64 %v1890, 16
  store i64 %op1891, ptr %slot108, align 8
  %v1892 = load i64, ptr %slot108, align 8
  %p1893 = inttoptr i64 %v1892 to ptr
  store i64 0, ptr %p1893, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved47
bb_rcmoveslow47:
  %v1894 = load i64, ptr %slot66, align 8
  %v1895 = load i64, ptr %slot84, align 8
  %v1896 = load i64, ptr %slot83, align 8
  %v1897 = load i64, ptr %slot85, align 8
  %cv1898 = trunc i64 %v1897 to i32
  %call1899 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v1894, i64 %v1895, i64 %v1896, i32 %cv1898) nomerge, !dbg !116
  store i32 %call1899, ptr %slot109, align 8
  %v1900 = load i32, ptr %slot109, align 8
  %cv1901 = zext i32 %v1900 to i64
  %cond1902 = icmp ne i64 %cv1901, 0
  br i1 %cond1902, label %bb_rcsuccess75, label %bb_rcfailure75
bb_rcfailure75:
  %v1903 = load i64, ptr %slot66, align 8
  %p1904 = inttoptr i64 %v1903 to ptr
  %call1905 = call i32 @myl_rc_take_failure(ptr %p1904) nomerge, !dbg !116
  store i32 %call1905, ptr %slot110, align 8
  %v1906 = load i64, ptr %slot1, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  %v1908 = load i32, ptr %slot110, align 8
  %call1909 = call i32 @myl_qbe_rc_status(ptr %p1907, i32 %v1908) nomerge, !dbg !116
  store i32 %call1909, ptr %slot111, align 8
  br label %bb_failure
bb_rcsuccess75:
  br label %bb_rcmoved47
bb_rcmoved47:
  %v1910 = load i64, ptr %slot17, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i32 0, ptr %p1911, align 4, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot24, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  store i32 2, ptr %p1913, align 4, !alias.scope !3, !noalias !4
  %v1914 = load i64, ptr %slot23, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i32 1, ptr %p1915, align 4, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot5, align 8
  %p1917 = inttoptr i64 %v1916 to ptr
  %ld1918 = load i32, ptr %p1917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1918, ptr %slot112, align 8
  %v1919 = load i32, ptr %slot112, align 8
  %cv1920 = zext i32 %v1919 to i64
  %cond1921 = icmp ne i64 %cv1920, 0
  br i1 %cond1921, label %bb_rcslotdrop84, label %bb_rcslotdone84
bb_rcslotdrop84:
  %v1922 = load i64, ptr %slot5, align 8
  %p1923 = inttoptr i64 %v1922 to ptr
  store i32 0, ptr %p1923, align 4, !alias.scope !3, !noalias !4
  %v1924 = load i64, ptr %slot39, align 8
  store i64 %v1924, ptr %slot113, align 8
  %v1925 = load i64, ptr %slot6, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %ld1927 = load i32, ptr %p1926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1927, ptr %slot114, align 8
  %v1928 = load i32, ptr %slot114, align 8
  %op1929 = and i32 %v1928, 28
  store i32 %op1929, ptr %slot115, align 8
  %v1930 = load i32, ptr %slot115, align 8
  %cv1931 = zext i32 %v1930 to i64
  %cond1932 = icmp ne i64 %cv1931, 0
  br i1 %cond1932, label %bb_rcslotrole84, label %bb_rcslotowner84
bb_rcslotrole84:
  %v1933 = load i64, ptr %slot66, align 8
  store i64 %v1933, ptr %slot116, align 8
  %v1934 = load i64, ptr %slot116, align 8
  %v1935 = load i64, ptr %slot113, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v1934, i64 %v1935) nomerge, !dbg !116
  br label %bb_rcslotdone84
bb_rcslotowner84:
  %v1936 = load i64, ptr %slot113, align 8
  %p1938 = inttoptr i64 %v1936 to ptr
  %gep1939 = getelementptr i8, ptr %p1938, i64 0
  %op1937 = ptrtoint ptr %gep1939 to i64
  store i64 %op1937, ptr %slot117, align 8
  %v1940 = load i64, ptr %slot66, align 8
  store i64 %v1940, ptr %slot118, align 8
  %v1941 = load i64, ptr %slot117, align 8
  %p1942 = inttoptr i64 %v1941 to ptr
  %ld1943 = load i64, ptr %p1942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1943, ptr %slot119, align 8
  %v1944 = load i64, ptr %slot119, align 8
  %cmp1945 = icmp ne i64 %v1944, 0
  %cv1946 = zext i1 %cmp1945 to i32
  store i32 %cv1946, ptr %slot120, align 8
  %v1947 = load i32, ptr %slot120, align 8
  %cv1948 = zext i32 %v1947 to i64
  %cond1949 = icmp ne i64 %cv1948, 0
  br i1 %cond1949, label %bb_rcgnn102, label %bb_rcgdone102
bb_rcgnn102:
  %v1950 = load i64, ptr %slot119, align 8
  %op1951 = sub i64 %v1950, 16
  store i64 %op1951, ptr %slot121, align 8
  %v1952 = load i64, ptr %slot119, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  %rgep1954 = getelementptr i8, ptr %p1953, i64 -16
  %ld1955 = load i64, ptr %rgep1954, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1955, ptr %slot122, align 8
  %v1956 = load i64, ptr %slot122, align 8
  %op1957 = and i64 %v1956, 4611686018427387906
  store i64 %op1957, ptr %slot123, align 8
  %v1958 = load i64, ptr %slot123, align 8
  %cmp1959 = icmp ne i64 %v1958, 0
  %cv1960 = zext i1 %cmp1959 to i32
  store i32 %cv1960, ptr %slot124, align 8
  %v1961 = load i32, ptr %slot124, align 8
  %cv1962 = zext i32 %v1961 to i64
  %cond1963 = icmp ne i64 %cv1962, 0
  br i1 %cond1963, label %bb_rcgclear102, label %bb_rcgcounted102
bb_rcgcounted102:
  %v1964 = load i64, ptr %slot119, align 8
  %op1965 = sub i64 %v1964, 32
  store i64 %op1965, ptr %slot125, align 8
  %v1966 = load i64, ptr %slot119, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  %rgep1968 = getelementptr i8, ptr %p1967, i64 -32
  %ld1969 = load i64, ptr %rgep1968, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1969, ptr %slot126, align 8
  %v1970 = load i64, ptr %slot126, align 8
  %op1971 = sub i64 %v1970, 1
  store i64 %op1971, ptr %slot127, align 8
  %v1972 = load i64, ptr %slot127, align 8
  %cmp1973 = icmp eq i64 %v1972, 0
  %cv1974 = zext i1 %cmp1973 to i32
  store i32 %cv1974, ptr %slot128, align 8
  %v1975 = load i32, ptr %slot128, align 8
  %cv1976 = zext i32 %v1975 to i64
  %cond1977 = icmp ne i64 %cv1976, 0
  br i1 %cond1977, label %bb_rcglast102, label %bb_rcgdec102
bb_rcglast102:
  %v1978 = load i64, ptr %slot119, align 8
  %op1979 = sub i64 %v1978, 24
  store i64 %op1979, ptr %slot129, align 8
  %v1980 = load i64, ptr %slot119, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  %rgep1982 = getelementptr i8, ptr %p1981, i64 -24
  %ld1983 = load i64, ptr %rgep1982, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1983, ptr %slot130, align 8
  %v1984 = load i64, ptr %slot130, align 8
  %cmp1985 = icmp ne i64 %v1984, 0
  %cv1986 = zext i1 %cmp1985 to i32
  store i32 %cv1986, ptr %slot131, align 8
  %v1987 = load i32, ptr %slot131, align 8
  %cv1988 = zext i32 %v1987 to i64
  %cond1989 = icmp ne i64 %cv1988, 0
  br i1 %cond1989, label %bb_rcgdec102, label %bb_rcgslow102
bb_rcgslow102:
  %v1990 = load i64, ptr %slot118, align 8
  %v1991 = load i64, ptr %slot117, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1990, i64 %v1991) nomerge, !dbg !116
  br label %bb_rcgdone102
bb_rcgdec102:
  %v1992 = load i64, ptr %slot127, align 8
  %v1993 = load i64, ptr %slot119, align 8
  %p1994 = inttoptr i64 %v1993 to ptr
  %rgep1995 = getelementptr i8, ptr %p1994, i64 -32
  store i64 %v1992, ptr %rgep1995, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear102
bb_rcgclear102:
  %v1996 = load i64, ptr %slot117, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  store i64 0, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone102
bb_rcgdone102:
  %v1998 = load i64, ptr %slot113, align 8
  %p2000 = inttoptr i64 %v1998 to ptr
  %gep2001 = getelementptr i8, ptr %p2000, i64 8
  %op1999 = ptrtoint ptr %gep2001 to i64
  store i64 %op1999, ptr %slot132, align 8
  %v2002 = load i64, ptr %slot66, align 8
  store i64 %v2002, ptr %slot133, align 8
  %v2003 = load i64, ptr %slot132, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  %ld2005 = load i64, ptr %p2004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2005, ptr %slot134, align 8
  %v2006 = load i64, ptr %slot134, align 8
  %cmp2007 = icmp ne i64 %v2006, 0
  %cv2008 = zext i1 %cmp2007 to i32
  store i32 %cv2008, ptr %slot135, align 8
  %v2009 = load i32, ptr %slot135, align 8
  %cv2010 = zext i32 %v2009 to i64
  %cond2011 = icmp ne i64 %cv2010, 0
  br i1 %cond2011, label %bb_rcgnn118, label %bb_rcgdone118
bb_rcgnn118:
  %v2012 = load i64, ptr %slot134, align 8
  %op2013 = sub i64 %v2012, 16
  store i64 %op2013, ptr %slot136, align 8
  %v2014 = load i64, ptr %slot134, align 8
  %p2015 = inttoptr i64 %v2014 to ptr
  %rgep2016 = getelementptr i8, ptr %p2015, i64 -16
  %ld2017 = load i64, ptr %rgep2016, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2017, ptr %slot137, align 8
  %v2018 = load i64, ptr %slot137, align 8
  %op2019 = and i64 %v2018, 4611686018427387906
  store i64 %op2019, ptr %slot138, align 8
  %v2020 = load i64, ptr %slot138, align 8
  %cmp2021 = icmp ne i64 %v2020, 0
  %cv2022 = zext i1 %cmp2021 to i32
  store i32 %cv2022, ptr %slot139, align 8
  %v2023 = load i32, ptr %slot139, align 8
  %cv2024 = zext i32 %v2023 to i64
  %cond2025 = icmp ne i64 %cv2024, 0
  br i1 %cond2025, label %bb_rcgclear118, label %bb_rcgcounted118
bb_rcgcounted118:
  %v2026 = load i64, ptr %slot134, align 8
  %op2027 = sub i64 %v2026, 32
  store i64 %op2027, ptr %slot140, align 8
  %v2028 = load i64, ptr %slot134, align 8
  %p2029 = inttoptr i64 %v2028 to ptr
  %rgep2030 = getelementptr i8, ptr %p2029, i64 -32
  %ld2031 = load i64, ptr %rgep2030, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2031, ptr %slot141, align 8
  %v2032 = load i64, ptr %slot141, align 8
  %op2033 = sub i64 %v2032, 1
  store i64 %op2033, ptr %slot142, align 8
  %v2034 = load i64, ptr %slot142, align 8
  %cmp2035 = icmp eq i64 %v2034, 0
  %cv2036 = zext i1 %cmp2035 to i32
  store i32 %cv2036, ptr %slot143, align 8
  %v2037 = load i32, ptr %slot143, align 8
  %cv2038 = zext i32 %v2037 to i64
  %cond2039 = icmp ne i64 %cv2038, 0
  br i1 %cond2039, label %bb_rcglast118, label %bb_rcgdec118
bb_rcglast118:
  %v2040 = load i64, ptr %slot134, align 8
  %op2041 = sub i64 %v2040, 24
  store i64 %op2041, ptr %slot144, align 8
  %v2042 = load i64, ptr %slot134, align 8
  %p2043 = inttoptr i64 %v2042 to ptr
  %rgep2044 = getelementptr i8, ptr %p2043, i64 -24
  %ld2045 = load i64, ptr %rgep2044, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2045, ptr %slot145, align 8
  %v2046 = load i64, ptr %slot145, align 8
  %cmp2047 = icmp ne i64 %v2046, 0
  %cv2048 = zext i1 %cmp2047 to i32
  store i32 %cv2048, ptr %slot146, align 8
  %v2049 = load i32, ptr %slot146, align 8
  %cv2050 = zext i32 %v2049 to i64
  %cond2051 = icmp ne i64 %cv2050, 0
  br i1 %cond2051, label %bb_rcgdec118, label %bb_rcgslow118
bb_rcgslow118:
  %v2052 = load i64, ptr %slot133, align 8
  %v2053 = load i64, ptr %slot132, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2052, i64 %v2053) nomerge, !dbg !116
  br label %bb_rcgdone118
bb_rcgdec118:
  %v2054 = load i64, ptr %slot142, align 8
  %v2055 = load i64, ptr %slot134, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  %rgep2057 = getelementptr i8, ptr %p2056, i64 -32
  store i64 %v2054, ptr %rgep2057, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear118
bb_rcgclear118:
  %v2058 = load i64, ptr %slot132, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  store i64 0, ptr %p2059, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone118
bb_rcgdone118:
  %v2060 = load i64, ptr %slot113, align 8
  %p2062 = inttoptr i64 %v2060 to ptr
  %gep2063 = getelementptr i8, ptr %p2062, i64 16
  %op2061 = ptrtoint ptr %gep2063 to i64
  store i64 %op2061, ptr %slot147, align 8
  %v2064 = load i64, ptr %slot66, align 8
  store i64 %v2064, ptr %slot148, align 8
  %v2065 = load i64, ptr %slot147, align 8
  %p2066 = inttoptr i64 %v2065 to ptr
  %ld2067 = load i64, ptr %p2066, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2067, ptr %slot149, align 8
  %v2068 = load i64, ptr %slot149, align 8
  %cmp2069 = icmp ne i64 %v2068, 0
  %cv2070 = zext i1 %cmp2069 to i32
  store i32 %cv2070, ptr %slot150, align 8
  %v2071 = load i32, ptr %slot150, align 8
  %cv2072 = zext i32 %v2071 to i64
  %cond2073 = icmp ne i64 %cv2072, 0
  br i1 %cond2073, label %bb_rcgnn134, label %bb_rcgdone134
bb_rcgnn134:
  %v2074 = load i64, ptr %slot149, align 8
  %op2075 = sub i64 %v2074, 16
  store i64 %op2075, ptr %slot151, align 8
  %v2076 = load i64, ptr %slot149, align 8
  %p2077 = inttoptr i64 %v2076 to ptr
  %rgep2078 = getelementptr i8, ptr %p2077, i64 -16
  %ld2079 = load i64, ptr %rgep2078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2079, ptr %slot152, align 8
  %v2080 = load i64, ptr %slot152, align 8
  %op2081 = and i64 %v2080, 4611686018427387906
  store i64 %op2081, ptr %slot153, align 8
  %v2082 = load i64, ptr %slot153, align 8
  %cmp2083 = icmp ne i64 %v2082, 0
  %cv2084 = zext i1 %cmp2083 to i32
  store i32 %cv2084, ptr %slot154, align 8
  %v2085 = load i32, ptr %slot154, align 8
  %cv2086 = zext i32 %v2085 to i64
  %cond2087 = icmp ne i64 %cv2086, 0
  br i1 %cond2087, label %bb_rcgclear134, label %bb_rcgcounted134
bb_rcgcounted134:
  %v2088 = load i64, ptr %slot149, align 8
  %op2089 = sub i64 %v2088, 32
  store i64 %op2089, ptr %slot155, align 8
  %v2090 = load i64, ptr %slot149, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  %rgep2092 = getelementptr i8, ptr %p2091, i64 -32
  %ld2093 = load i64, ptr %rgep2092, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2093, ptr %slot156, align 8
  %v2094 = load i64, ptr %slot156, align 8
  %op2095 = sub i64 %v2094, 1
  store i64 %op2095, ptr %slot157, align 8
  %v2096 = load i64, ptr %slot157, align 8
  %cmp2097 = icmp eq i64 %v2096, 0
  %cv2098 = zext i1 %cmp2097 to i32
  store i32 %cv2098, ptr %slot158, align 8
  %v2099 = load i32, ptr %slot158, align 8
  %cv2100 = zext i32 %v2099 to i64
  %cond2101 = icmp ne i64 %cv2100, 0
  br i1 %cond2101, label %bb_rcglast134, label %bb_rcgdec134
bb_rcglast134:
  %v2102 = load i64, ptr %slot149, align 8
  %op2103 = sub i64 %v2102, 24
  store i64 %op2103, ptr %slot159, align 8
  %v2104 = load i64, ptr %slot149, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  %rgep2106 = getelementptr i8, ptr %p2105, i64 -24
  %ld2107 = load i64, ptr %rgep2106, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2107, ptr %slot160, align 8
  %v2108 = load i64, ptr %slot160, align 8
  %cmp2109 = icmp ne i64 %v2108, 0
  %cv2110 = zext i1 %cmp2109 to i32
  store i32 %cv2110, ptr %slot161, align 8
  %v2111 = load i32, ptr %slot161, align 8
  %cv2112 = zext i32 %v2111 to i64
  %cond2113 = icmp ne i64 %cv2112, 0
  br i1 %cond2113, label %bb_rcgdec134, label %bb_rcgslow134
bb_rcgslow134:
  %v2114 = load i64, ptr %slot148, align 8
  %v2115 = load i64, ptr %slot147, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v2114, i64 %v2115) nomerge, !dbg !116
  br label %bb_rcgdone134
bb_rcgdec134:
  %v2116 = load i64, ptr %slot157, align 8
  %v2117 = load i64, ptr %slot149, align 8
  %p2118 = inttoptr i64 %v2117 to ptr
  %rgep2119 = getelementptr i8, ptr %p2118, i64 -32
  store i64 %v2116, ptr %rgep2119, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear134
bb_rcgclear134:
  %v2120 = load i64, ptr %slot147, align 8
  %p2121 = inttoptr i64 %v2120 to ptr
  store i64 0, ptr %p2121, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone134
bb_rcgdone134:
  %v2122 = load i64, ptr %slot113, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  store i64 0, ptr %p2123, align 8, !alias.scope !3, !noalias !4
  %v2124 = load i64, ptr %slot113, align 8
  %p2126 = inttoptr i64 %v2124 to ptr
  %gep2127 = getelementptr i8, ptr %p2126, i64 8
  %op2125 = ptrtoint ptr %gep2127 to i64
  store i64 %op2125, ptr %slot162, align 8
  %v2128 = load i64, ptr %slot162, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  store i64 0, ptr %p2129, align 8, !alias.scope !3, !noalias !4
  %v2130 = load i64, ptr %slot113, align 8
  %p2132 = inttoptr i64 %v2130 to ptr
  %gep2133 = getelementptr i8, ptr %p2132, i64 16
  %op2131 = ptrtoint ptr %gep2133 to i64
  store i64 %op2131, ptr %slot163, align 8
  %v2134 = load i64, ptr %slot163, align 8
  %p2135 = inttoptr i64 %v2134 to ptr
  store i64 0, ptr %p2135, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone84
bb_rcslotdone84:
  %v2136 = load i64, ptr %slot39, align 8
  store i64 %v2136, ptr %slot164, align 8
  %v2137 = load i64, ptr %slot31, align 8
  store i64 %v2137, ptr %slot165, align 8
  %v2138 = load i64, ptr %slot165, align 8
  %v2139 = load i64, ptr %slot164, align 8
  %p2140 = inttoptr i64 %v2138 to ptr
  %p2141 = inttoptr i64 %v2139 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2141, ptr %p2140, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2142 = load i64, ptr %slot23, align 8
  %p2143 = inttoptr i64 %v2142 to ptr
  store i32 0, ptr %p2143, align 4, !alias.scope !3, !noalias !4
  %v2144 = load i64, ptr %slot6, align 8
  %p2145 = inttoptr i64 %v2144 to ptr
  store i32 2, ptr %p2145, align 4, !alias.scope !3, !noalias !4
  %v2146 = load i64, ptr %slot24, align 8
  %p2147 = inttoptr i64 %v2146 to ptr
  %ld2148 = load i32, ptr %p2147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2148, ptr %slot166, align 8
  %v2149 = load i32, ptr %slot166, align 8
  %v2150 = load i64, ptr %slot6, align 8
  %p2151 = inttoptr i64 %v2150 to ptr
  store i32 %v2149, ptr %p2151, align 4, !alias.scope !3, !noalias !4
  %v2152 = load i64, ptr %slot5, align 8
  %p2153 = inttoptr i64 %v2152 to ptr
  store i32 1, ptr %p2153, align 4, !alias.scope !3, !noalias !4
  %v2154 = load i64, ptr %slot39, align 8
  %v2155 = load i64, ptr %slot54, align 8
  %p2156 = inttoptr i64 %v2155 to ptr
  store i64 %v2154, ptr %p2156, align 8, !alias.scope !3, !noalias !4
  %v2157 = load i64, ptr %slot38, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  %ld2159 = load i64, ptr %p2158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2159, ptr %slot167, align 8
  %v2160 = load i64, ptr %slot167, align 8
  %v2161 = load i64, ptr %slot55, align 8
  %p2162 = inttoptr i64 %v2161 to ptr
  store i64 %v2160, ptr %p2162, align 8, !alias.scope !3, !noalias !4
  %v2163 = load i64, ptr %slot54, align 8
  %p2164 = inttoptr i64 %v2163 to ptr
  %ld2165 = load i64, ptr %p2164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2165, ptr %slot168, align 8
  %v2166 = load i64, ptr %slot55, align 8
  %p2167 = inttoptr i64 %v2166 to ptr
  %ld2168 = load i64, ptr %p2167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2168, ptr %slot169, align 8
  %v2169 = load i64, ptr %slot1, align 8
  %v2170 = load i64, ptr %slot168, align 8
  %v2171 = load i64, ptr %slot169, align 8
  %call2172 = call i64 @myl_f_05fc0e6538ca8f4b665e96a95caffae09d28186d2951c07629014719c7522651(i64 %v2169, i64 %v2170, i64 %v2171) nomerge, !dbg !118
  store i64 %call2172, ptr %slot170, align 8
  %v2173 = load i64, ptr %slot170, align 8
  %v2174 = load i64, ptr %slot54, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i64 %v2173, ptr %p2175, align 8, !alias.scope !3, !noalias !4
  %v2176 = load i64, ptr %slot17, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i32, ptr %p2177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2178, ptr %slot171, align 8
  %v2179 = load i32, ptr %slot171, align 8
  %cv2180 = zext i32 %v2179 to i64
  %cond2181 = icmp ne i64 %cv2180, 0
  br i1 %cond2181, label %bb_rcslotdrop153, label %bb_rcslotdone153
bb_rcslotdrop153:
  %v2182 = load i64, ptr %slot17, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i32 0, ptr %p2183, align 4, !alias.scope !3, !noalias !4
  %v2184 = load i64, ptr %slot26, align 8
  store i64 %v2184, ptr %slot172, align 8
  %v2185 = load i64, ptr %slot18, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %ld2187 = load i32, ptr %p2186, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2187, ptr %slot173, align 8
  %v2188 = load i32, ptr %slot173, align 8
  %op2189 = and i32 %v2188, 28
  store i32 %op2189, ptr %slot174, align 8
  %v2190 = load i32, ptr %slot174, align 8
  %cv2191 = zext i32 %v2190 to i64
  %cond2192 = icmp ne i64 %cv2191, 0
  br i1 %cond2192, label %bb_rcslotrole153, label %bb_rcslotowner153
bb_rcslotrole153:
  %v2193 = load i64, ptr %slot66, align 8
  store i64 %v2193, ptr %slot175, align 8
  %v2194 = load i64, ptr %slot175, align 8
  %v2195 = load i64, ptr %slot172, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v2194, i64 %v2195) nomerge, !dbg !118
  br label %bb_rcslotdone153
bb_rcslotowner153:
  %v2196 = load i64, ptr %slot66, align 8
  store i64 %v2196, ptr %slot176, align 8
  %v2197 = load i64, ptr %slot176, align 8
  %v2198 = load i64, ptr %slot172, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v2197, i64 %v2198) nomerge, !dbg !118
  br label %bb_rcslotdone153
bb_rcslotdone153:
  %v2199 = load i64, ptr %slot54, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %ld2201 = load i64, ptr %p2200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2201, ptr %slot177, align 8
  %v2202 = load i64, ptr %slot177, align 8
  %v2203 = load i64, ptr %slot40, align 8
  %p2204 = inttoptr i64 %v2203 to ptr
  store i64 %v2202, ptr %p2204, align 8, !alias.scope !3, !noalias !4
  %v2205 = load i64, ptr %slot37, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  %ld2207 = load i64, ptr %p2206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2207, ptr %slot178, align 8
  %v2208 = load i64, ptr %slot178, align 8
  %v2209 = load i64, ptr %slot54, align 8
  %p2210 = inttoptr i64 %v2209 to ptr
  store i64 %v2208, ptr %p2210, align 8, !alias.scope !3, !noalias !4
  %v2211 = load i64, ptr %slot54, align 8
  %p2212 = inttoptr i64 %v2211 to ptr
  %ld2213 = load i64, ptr %p2212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2213, ptr %slot179, align 8
  %v2214 = load i64, ptr %slot179, align 8
  %op2215 = add i64 %v2214, 376
  store i64 %op2215, ptr %slot180, align 8
  %v2216 = load i64, ptr %slot180, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  %ld2218 = load i64, ptr %p2217, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2218, ptr %slot181, align 8
  %v2219 = load i64, ptr %slot181, align 8
  %v2220 = load i64, ptr %slot54, align 8
  %p2221 = inttoptr i64 %v2220 to ptr
  store i64 %v2219, ptr %p2221, align 8, !alias.scope !3, !noalias !4
  %v2222 = load i64, ptr %slot17, align 8
  %p2223 = inttoptr i64 %v2222 to ptr
  %ld2224 = load i32, ptr %p2223, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2224, ptr %slot182, align 8
  %v2225 = load i32, ptr %slot182, align 8
  %cv2226 = zext i32 %v2225 to i64
  %cond2227 = icmp ne i64 %cv2226, 0
  br i1 %cond2227, label %bb_rcslotdrop167, label %bb_rcslotdone167
bb_rcslotdrop167:
  %v2228 = load i64, ptr %slot17, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  store i32 0, ptr %p2229, align 4, !alias.scope !3, !noalias !4
  %v2230 = load i64, ptr %slot26, align 8
  store i64 %v2230, ptr %slot183, align 8
  %v2231 = load i64, ptr %slot18, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  %ld2233 = load i32, ptr %p2232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2233, ptr %slot184, align 8
  %v2234 = load i32, ptr %slot184, align 8
  %op2235 = and i32 %v2234, 28
  store i32 %op2235, ptr %slot185, align 8
  %v2236 = load i32, ptr %slot185, align 8
  %cv2237 = zext i32 %v2236 to i64
  %cond2238 = icmp ne i64 %cv2237, 0
  br i1 %cond2238, label %bb_rcslotrole167, label %bb_rcslotowner167
bb_rcslotrole167:
  %v2239 = load i64, ptr %slot66, align 8
  store i64 %v2239, ptr %slot186, align 8
  %v2240 = load i64, ptr %slot186, align 8
  %v2241 = load i64, ptr %slot183, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2240, i64 %v2241) nomerge, !dbg !120
  br label %bb_rcslotdone167
bb_rcslotowner167:
  %v2242 = load i64, ptr %slot66, align 8
  store i64 %v2242, ptr %slot187, align 8
  %v2243 = load i64, ptr %slot187, align 8
  %v2244 = load i64, ptr %slot183, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2243, i64 %v2244) nomerge, !dbg !120
  br label %bb_rcslotdone167
bb_rcslotdone167:
  %v2245 = load i64, ptr %slot54, align 8
  %p2246 = inttoptr i64 %v2245 to ptr
  %ld2247 = load i64, ptr %p2246, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2247, ptr %slot188, align 8
  %v2248 = load i64, ptr %slot188, align 8
  %v2249 = load i64, ptr %slot41, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  store i64 %v2248, ptr %p2250, align 8, !alias.scope !3, !noalias !4
  %v2251 = load i64, ptr %slot41, align 8
  %p2252 = inttoptr i64 %v2251 to ptr
  %ld2253 = load i64, ptr %p2252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2253, ptr %slot189, align 8
  %v2254 = load i64, ptr %slot189, align 8
  %op2255 = add i64 %v2254, 0
  store i64 %op2255, ptr %slot190, align 8
  %v2256 = load i64, ptr %slot190, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %ld2258 = load i64, ptr %p2257, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2258, ptr %slot191, align 8
  %v2259 = load i64, ptr %slot191, align 8
  %v2260 = load i64, ptr %slot54, align 8
  %p2261 = inttoptr i64 %v2260 to ptr
  store i64 %v2259, ptr %p2261, align 8, !alias.scope !3, !noalias !4
  %v2262 = load i64, ptr %slot54, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  %ld2264 = load i64, ptr %p2263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2264, ptr %slot192, align 8
  %v2265 = load i64, ptr %slot192, align 8
  %cmp2266 = icmp ugt i64 %v2265, 9223372036854775807
  %cv2267 = zext i1 %cmp2266 to i64
  store i64 %cv2267, ptr %slot193, align 8
  %v2268 = load i64, ptr %slot193, align 8
  %cond2269 = icmp ne i64 %v2268, 0
  br i1 %cond2269, label %bb_cast_overflow180, label %bb_cast_ok180
bb_cast_overflow180:
  %v2270 = load i64, ptr %slot1, align 8
  %p2271 = inttoptr i64 %v2270 to ptr
  %v2272 = load i64, ptr %slot192, align 8
  call void @myl_qbe_fail_cast(ptr %p2271, i64 %v2272, i64 320) nomerge, !dbg !122
  unreachable
bb_cast_ok180:
  %v2273 = load i64, ptr %slot192, align 8
  %v2274 = load i64, ptr %slot54, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  store i64 %v2273, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  %v2276 = load i64, ptr %slot55, align 8
  %p2277 = inttoptr i64 %v2276 to ptr
  store i64 1, ptr %p2277, align 8, !alias.scope !3, !noalias !4
  %v2278 = load i64, ptr %slot55, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  %ld2280 = load i64, ptr %p2279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2280, ptr %slot194, align 8
  %v2281 = load i64, ptr %slot54, align 8
  %p2282 = inttoptr i64 %v2281 to ptr
  %ld2283 = load i64, ptr %p2282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2283, ptr %slot195, align 8
  %v2284 = load i64, ptr %slot195, align 8
  %v2285 = load i64, ptr %slot194, align 8
  %ovpair2287 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2284, i64 %v2285)
  %op2286 = extractvalue { i64, i1 } %ovpair2287, 0
  %ov2288 = extractvalue { i64, i1 } %ovpair2287, 1
  store i64 %op2286, ptr %slot196, align 8
  %cv2289 = zext i1 %ov2288 to i64
  store i64 %cv2289, ptr %slot197, align 8
  %v2290 = load i64, ptr %slot197, align 8
  %cond2291 = icmp ne i64 %v2290, 0
  br i1 %cond2291, label %bb_overflow183, label %bb_checked183
bb_overflow183:
  %v2292 = load i64, ptr %slot1, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  %v2294 = load i64, ptr %slot195, align 8
  %v2295 = load i64, ptr %slot194, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2293, i64 1, i64 %v2294, i64 %v2295, i64 64) nomerge, !dbg !124
  unreachable
bb_checked183:
  %v2296 = load i64, ptr %slot196, align 8
  %v2297 = load i64, ptr %slot54, align 8
  %p2298 = inttoptr i64 %v2297 to ptr
  store i64 %v2296, ptr %p2298, align 8, !alias.scope !3, !noalias !4
  %v2299 = load i64, ptr %slot54, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %ld2301 = load i64, ptr %p2300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2301, ptr %slot198, align 8
  %v2302 = load i64, ptr %slot198, align 8
  %v2303 = load i64, ptr %slot42, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  store i64 %v2302, ptr %p2304, align 8, !alias.scope !3, !noalias !4
  %v2305 = load i64, ptr %slot37, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  %ld2307 = load i64, ptr %p2306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2307, ptr %slot199, align 8
  %v2308 = load i64, ptr %slot199, align 8
  %v2309 = load i64, ptr %slot54, align 8
  %p2310 = inttoptr i64 %v2309 to ptr
  store i64 %v2308, ptr %p2310, align 8, !alias.scope !3, !noalias !4
  %v2311 = load i64, ptr %slot54, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %ld2313 = load i64, ptr %p2312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2313, ptr %slot200, align 8
  %v2314 = load i64, ptr %slot200, align 8
  %op2315 = add i64 %v2314, 376
  store i64 %op2315, ptr %slot201, align 8
  %v2316 = load i64, ptr %slot201, align 8
  %p2317 = inttoptr i64 %v2316 to ptr
  %ld2318 = load i64, ptr %p2317, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2318, ptr %slot202, align 8
  %v2319 = load i64, ptr %slot202, align 8
  %v2320 = load i64, ptr %slot54, align 8
  %p2321 = inttoptr i64 %v2320 to ptr
  store i64 %v2319, ptr %p2321, align 8, !alias.scope !3, !noalias !4
  %v2322 = load i64, ptr %slot17, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  %ld2324 = load i32, ptr %p2323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2324, ptr %slot203, align 8
  %v2325 = load i32, ptr %slot203, align 8
  %cv2326 = zext i32 %v2325 to i64
  %cond2327 = icmp ne i64 %cv2326, 0
  br i1 %cond2327, label %bb_rcslotdrop192, label %bb_rcslotdone192
bb_rcslotdrop192:
  %v2328 = load i64, ptr %slot17, align 8
  %p2329 = inttoptr i64 %v2328 to ptr
  store i32 0, ptr %p2329, align 4, !alias.scope !3, !noalias !4
  %v2330 = load i64, ptr %slot26, align 8
  store i64 %v2330, ptr %slot204, align 8
  %v2331 = load i64, ptr %slot18, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  %ld2333 = load i32, ptr %p2332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2333, ptr %slot205, align 8
  %v2334 = load i32, ptr %slot205, align 8
  %op2335 = and i32 %v2334, 28
  store i32 %op2335, ptr %slot206, align 8
  %v2336 = load i32, ptr %slot206, align 8
  %cv2337 = zext i32 %v2336 to i64
  %cond2338 = icmp ne i64 %cv2337, 0
  br i1 %cond2338, label %bb_rcslotrole192, label %bb_rcslotowner192
bb_rcslotrole192:
  %v2339 = load i64, ptr %slot66, align 8
  store i64 %v2339, ptr %slot207, align 8
  %v2340 = load i64, ptr %slot207, align 8
  %v2341 = load i64, ptr %slot204, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v2340, i64 %v2341) nomerge, !dbg !126
  br label %bb_rcslotdone192
bb_rcslotowner192:
  %v2342 = load i64, ptr %slot66, align 8
  store i64 %v2342, ptr %slot208, align 8
  %v2343 = load i64, ptr %slot208, align 8
  %v2344 = load i64, ptr %slot204, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v2343, i64 %v2344) nomerge, !dbg !126
  br label %bb_rcslotdone192
bb_rcslotdone192:
  %v2345 = load i64, ptr %slot54, align 8
  %p2346 = inttoptr i64 %v2345 to ptr
  %ld2347 = load i64, ptr %p2346, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2347, ptr %slot209, align 8
  %v2348 = load i64, ptr %slot209, align 8
  %v2349 = load i64, ptr %slot43, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  store i64 %v2348, ptr %p2350, align 8, !alias.scope !3, !noalias !4
  %v2351 = load i64, ptr %slot42, align 8
  %p2352 = inttoptr i64 %v2351 to ptr
  %ld2353 = load i64, ptr %p2352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2353, ptr %slot210, align 8
  %v2354 = load i64, ptr %slot210, align 8
  %v2355 = load i64, ptr %slot54, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i64 %v2354, ptr %p2356, align 8, !alias.scope !3, !noalias !4
  %v2357 = load i64, ptr %slot54, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %ld2359 = load i64, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2359, ptr %slot211, align 8
  %v2360 = load i64, ptr %slot211, align 8
  %v2361 = load i64, ptr %slot44, align 8
  %p2362 = inttoptr i64 %v2361 to ptr
  store i64 %v2360, ptr %p2362, align 8, !alias.scope !3, !noalias !4
  %v2363 = load i64, ptr %slot44, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  %ld2365 = load i64, ptr %p2364, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2365, ptr %slot212, align 8
  %v2366 = load i64, ptr %slot212, align 8
  %v2367 = load i64, ptr %slot54, align 8
  %p2368 = inttoptr i64 %v2367 to ptr
  store i64 %v2366, ptr %p2368, align 8, !alias.scope !3, !noalias !4
  %v2369 = load i64, ptr %slot55, align 8
  %p2370 = inttoptr i64 %v2369 to ptr
  store i64 0, ptr %p2370, align 8, !alias.scope !3, !noalias !4
  %v2371 = load i64, ptr %slot55, align 8
  %p2372 = inttoptr i64 %v2371 to ptr
  %ld2373 = load i64, ptr %p2372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2373, ptr %slot213, align 8
  %v2374 = load i64, ptr %slot54, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  %ld2376 = load i64, ptr %p2375, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2376, ptr %slot214, align 8
  %v2377 = load i64, ptr %slot214, align 8
  %v2378 = load i64, ptr %slot213, align 8
  %cmp2379 = icmp slt i64 %v2377, %v2378
  %cv2380 = zext i1 %cmp2379 to i64
  store i64 %cv2380, ptr %slot215, align 8
  %v2381 = load i64, ptr %slot215, align 8
  %v2382 = load i64, ptr %slot54, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  store i64 %v2381, ptr %p2383, align 8, !alias.scope !3, !noalias !4
  %v2384 = load i64, ptr %slot54, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  %ld2386 = load i64, ptr %p2385, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2386, ptr %slot216, align 8
  %v2387 = load i64, ptr %slot216, align 8
  %cond2388 = icmp ne i64 %v2387, 0
  br i1 %cond2388, label %bb_next207, label %bb_i29
bb_next207:
  %v2389 = load i64, ptr %slot43, align 8
  %p2390 = inttoptr i64 %v2389 to ptr
  %ld2391 = load i64, ptr %p2390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2391, ptr %slot217, align 8
  %v2392 = load i64, ptr %slot217, align 8
  %op2393 = add i64 %v2392, 0
  store i64 %op2393, ptr %slot218, align 8
  %v2394 = load i64, ptr %slot218, align 8
  %p2395 = inttoptr i64 %v2394 to ptr
  %ld2396 = load i64, ptr %p2395, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2396, ptr %slot219, align 8
  %v2397 = load i64, ptr %slot219, align 8
  %v2398 = load i64, ptr %slot54, align 8
  %p2399 = inttoptr i64 %v2398 to ptr
  store i64 %v2397, ptr %p2399, align 8, !alias.scope !3, !noalias !4
  %v2400 = load i64, ptr %slot54, align 8
  %p2401 = inttoptr i64 %v2400 to ptr
  %ld2402 = load i64, ptr %p2401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2402, ptr %slot220, align 8
  %v2403 = load i64, ptr %slot220, align 8
  %cmp2404 = icmp ugt i64 %v2403, 9223372036854775807
  %cv2405 = zext i1 %cmp2404 to i64
  store i64 %cv2405, ptr %slot221, align 8
  %v2406 = load i64, ptr %slot221, align 8
  %cond2407 = icmp ne i64 %v2406, 0
  br i1 %cond2407, label %bb_cast_overflow212, label %bb_cast_ok212
bb_cast_overflow212:
  %v2408 = load i64, ptr %slot1, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  %v2410 = load i64, ptr %slot220, align 8
  call void @myl_qbe_fail_cast(ptr %p2409, i64 %v2410, i64 320) nomerge, !dbg !128
  unreachable
bb_cast_ok212:
  %v2411 = load i64, ptr %slot220, align 8
  %v2412 = load i64, ptr %slot54, align 8
  %p2413 = inttoptr i64 %v2412 to ptr
  store i64 %v2411, ptr %p2413, align 8, !alias.scope !3, !noalias !4
  %v2414 = load i64, ptr %slot44, align 8
  %p2415 = inttoptr i64 %v2414 to ptr
  %ld2416 = load i64, ptr %p2415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2416, ptr %slot222, align 8
  %v2417 = load i64, ptr %slot222, align 8
  %v2418 = load i64, ptr %slot55, align 8
  %p2419 = inttoptr i64 %v2418 to ptr
  store i64 %v2417, ptr %p2419, align 8, !alias.scope !3, !noalias !4
  %v2420 = load i64, ptr %slot55, align 8
  %p2421 = inttoptr i64 %v2420 to ptr
  %ld2422 = load i64, ptr %p2421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2422, ptr %slot223, align 8
  %v2423 = load i64, ptr %slot54, align 8
  %p2424 = inttoptr i64 %v2423 to ptr
  %ld2425 = load i64, ptr %p2424, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2425, ptr %slot224, align 8
  %v2426 = load i64, ptr %slot224, align 8
  %v2427 = load i64, ptr %slot223, align 8
  %ovpair2429 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2426, i64 %v2427)
  %op2428 = extractvalue { i64, i1 } %ovpair2429, 0
  %ov2430 = extractvalue { i64, i1 } %ovpair2429, 1
  store i64 %op2428, ptr %slot225, align 8
  %v2431 = load i64, ptr %slot224, align 8
  %v2432 = load i64, ptr %slot225, align 8
  %op2433 = xor i64 %v2431, %v2432
  store i64 %op2433, ptr %slot226, align 8
  %v2434 = load i64, ptr %slot223, align 8
  %v2435 = load i64, ptr %slot225, align 8
  %op2436 = xor i64 %v2434, %v2435
  store i64 %op2436, ptr %slot227, align 8
  %v2437 = load i64, ptr %slot226, align 8
  %v2438 = load i64, ptr %slot227, align 8
  %op2439 = and i64 %v2437, %v2438
  store i64 %op2439, ptr %slot228, align 8
  %cv2440 = zext i1 %ov2430 to i64
  store i64 %cv2440, ptr %slot229, align 8
  %v2441 = load i64, ptr %slot229, align 8
  %cond2442 = icmp ne i64 %v2441, 0
  br i1 %cond2442, label %bb_overflow216, label %bb_checked216
bb_overflow216:
  %v2443 = load i64, ptr %slot1, align 8
  %p2444 = inttoptr i64 %v2443 to ptr
  %v2445 = load i64, ptr %slot224, align 8
  %v2446 = load i64, ptr %slot223, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2444, i64 0, i64 %v2445, i64 %v2446, i64 64) nomerge, !dbg !130
  unreachable
bb_checked216:
  %v2447 = load i64, ptr %slot225, align 8
  %v2448 = load i64, ptr %slot54, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  store i64 %v2447, ptr %p2449, align 8, !alias.scope !3, !noalias !4
  %v2450 = load i64, ptr %slot54, align 8
  %p2451 = inttoptr i64 %v2450 to ptr
  %ld2452 = load i64, ptr %p2451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2452, ptr %slot230, align 8
  %v2453 = load i64, ptr %slot230, align 8
  %v2454 = load i64, ptr %slot44, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  store i64 %v2453, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  br label %bb_i29
bb_i29:
  %v2456 = load i64, ptr %slot44, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  %ld2458 = load i64, ptr %p2457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2458, ptr %slot231, align 8
  %v2459 = load i64, ptr %slot231, align 8
  %v2460 = load i64, ptr %slot54, align 8
  %p2461 = inttoptr i64 %v2460 to ptr
  store i64 %v2459, ptr %p2461, align 8, !alias.scope !3, !noalias !4
  %v2462 = load i64, ptr %slot43, align 8
  %p2463 = inttoptr i64 %v2462 to ptr
  %ld2464 = load i64, ptr %p2463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2464, ptr %slot232, align 8
  %v2465 = load i64, ptr %slot54, align 8
  %p2466 = inttoptr i64 %v2465 to ptr
  %ld2467 = load i64, ptr %p2466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2467, ptr %slot233, align 8
  %v2468 = load i64, ptr %slot232, align 8
  %p2469 = inttoptr i64 %v2468 to ptr
  %ld2470 = load i64, ptr %p2469, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2470, ptr %slot234, align 8
  %v2471 = load i64, ptr %slot233, align 8
  %v2472 = load i64, ptr %slot234, align 8
  %cmp2473 = icmp ult i64 %v2471, %v2472
  %cv2474 = zext i1 %cmp2473 to i64
  store i64 %cv2474, ptr %slot235, align 8
  %v2475 = load i64, ptr %slot235, align 8
  %cond2476 = icmp ne i64 %v2475, 0
  br i1 %cond2476, label %bb_success228, label %bb_failed228
bb_failed228:
  %v2477 = load i64, ptr %slot1, align 8
  %p2478 = inttoptr i64 %v2477 to ptr
  %v2479 = load i64, ptr %slot233, align 8
  %v2480 = load i64, ptr %slot234, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2478, i64 %v2479, i64 %v2480) nomerge, !dbg !132
  unreachable
bb_success228:
  %v2481 = load i64, ptr %slot232, align 8
  %op2482 = add i64 %v2481, 32
  store i64 %op2482, ptr %slot236, align 8
  %v2483 = load i64, ptr %slot236, align 8
  %p2484 = inttoptr i64 %v2483 to ptr
  %ld2485 = load i64, ptr %p2484, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2485, ptr %slot237, align 8
  %v2486 = load i64, ptr %slot233, align 8
  %op2487 = mul i64 %v2486, 88
  store i64 %op2487, ptr %slot238, align 8
  %v2488 = load i64, ptr %slot237, align 8
  %v2489 = load i64, ptr %slot238, align 8
  %op2490 = add i64 %v2488, %v2489
  store i64 %op2490, ptr %slot239, align 8
  %v2491 = load i64, ptr %slot65, align 8
  store i64 %v2491, ptr %slot240, align 8
  %v2492 = load i64, ptr %slot239, align 8
  %v2493 = load i64, ptr %slot240, align 8
  %p2494 = inttoptr i64 %v2492 to ptr
  %p2495 = inttoptr i64 %v2493 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2495, ptr %p2494, i64 88, i1 false), !alias.scope !10000000
  %v2496 = load i64, ptr %slot240, align 8
  %v2497 = load i64, ptr %slot54, align 8
  %p2498 = inttoptr i64 %v2497 to ptr
  store i64 %v2496, ptr %p2498, align 8, !alias.scope !3, !noalias !4
  %v2499 = load i64, ptr %slot54, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  %ld2501 = load i64, ptr %p2500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2501, ptr %slot241, align 8
  %v2502 = load i64, ptr %slot31, align 8
  store i64 %v2502, ptr %slot242, align 8
  %v2503 = load i64, ptr %slot66, align 8
  %v2504 = load i64, ptr %slot242, align 8
  %v2505 = load i64, ptr %slot241, align 8
  %call2506 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v2503, i64 %v2504, i64 %v2505) nomerge, !dbg !132
  store i32 %call2506, ptr %slot243, align 8
  %v2507 = load i32, ptr %slot243, align 8
  %cv2508 = zext i32 %v2507 to i64
  %cond2509 = icmp ne i64 %cv2508, 0
  br i1 %cond2509, label %bb_rcsuccess237, label %bb_rcfailure237
bb_rcfailure237:
  %v2510 = load i64, ptr %slot66, align 8
  %p2511 = inttoptr i64 %v2510 to ptr
  %call2512 = call i32 @myl_rc_take_failure(ptr %p2511) nomerge, !dbg !132
  store i32 %call2512, ptr %slot244, align 8
  %v2513 = load i64, ptr %slot1, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  %v2515 = load i32, ptr %slot244, align 8
  %call2516 = call i32 @myl_qbe_rc_status(ptr %p2514, i32 %v2515) nomerge, !dbg !132
  store i32 %call2516, ptr %slot245, align 8
  br label %bb_failure
bb_rcsuccess237:
  %v2517 = load i64, ptr %slot24, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  store i32 2, ptr %p2518, align 4, !alias.scope !3, !noalias !4
  %v2519 = load i64, ptr %slot24, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  store i32 16, ptr %p2520, align 4, !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot23, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i32 1, ptr %p2522, align 4, !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot26, align 8
  store i64 %v2523, ptr %slot246, align 8
  %v2524 = load i64, ptr %slot31, align 8
  store i64 %v2524, ptr %slot247, align 8
  %v2525 = load i64, ptr %slot247, align 8
  %v2526 = load i64, ptr %slot246, align 8
  %p2527 = inttoptr i64 %v2525 to ptr
  %p2528 = inttoptr i64 %v2526 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2528, ptr %p2527, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot18, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  store i32 2, ptr %p2530, align 4, !alias.scope !3, !noalias !4
  %v2531 = load i64, ptr %slot24, align 8
  %p2532 = inttoptr i64 %v2531 to ptr
  %ld2533 = load i32, ptr %p2532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2533, ptr %slot248, align 8
  %v2534 = load i32, ptr %slot248, align 8
  %v2535 = load i64, ptr %slot18, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i32 %v2534, ptr %p2536, align 4, !alias.scope !3, !noalias !4
  %v2537 = load i64, ptr %slot23, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  store i32 0, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  %v2539 = load i64, ptr %slot17, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  store i32 1, ptr %p2540, align 4, !alias.scope !3, !noalias !4
  %v2541 = load i64, ptr %slot246, align 8
  %v2542 = load i64, ptr %slot54, align 8
  %p2543 = inttoptr i64 %v2542 to ptr
  store i64 %v2541, ptr %p2543, align 8, !alias.scope !3, !noalias !4
  %v2544 = load i64, ptr %slot54, align 8
  %p2545 = inttoptr i64 %v2544 to ptr
  %ld2546 = load i64, ptr %p2545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2546, ptr %slot249, align 8
  %v2547 = load i64, ptr %slot17, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  %ld2549 = load i32, ptr %p2548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2549, ptr %slot250, align 8
  %v2550 = load i64, ptr %slot18, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  %ld2552 = load i32, ptr %p2551, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2552, ptr %slot251, align 8
  %v2553 = load i32, ptr %slot251, align 8
  %op2554 = and i32 %v2553, 24
  store i32 %op2554, ptr %slot251, align 8
  %v2555 = load i32, ptr %slot251, align 8
  %cmp2556 = icmp eq i32 %v2555, 0
  %cv2557 = zext i1 %cmp2556 to i32
  store i32 %cv2557, ptr %slot252, align 8
  %v2558 = load i32, ptr %slot250, align 8
  %v2559 = load i32, ptr %slot252, align 8
  %op2560 = and i32 %v2558, %v2559
  store i32 %op2560, ptr %slot253, align 8
  %v2561 = load i64, ptr %slot67, align 8
  store i64 %v2561, ptr %slot254, align 8
  %v2562 = load i32, ptr %slot253, align 8
  %op2563 = mul i32 %v2562, 4
  store i32 %op2563, ptr %slot255, align 8
  %v2564 = load i32, ptr %slot255, align 8
  %op2565 = or i32 %v2564, 0
  store i32 %op2565, ptr %slot256, align 8
  %v2566 = load i64, ptr %slot31, align 8
  store i64 %v2566, ptr %slot257, align 8
  %v2567 = load i64, ptr %slot66, align 8
  %v2568 = load i64, ptr %slot257, align 8
  %v2569 = load i64, ptr %slot249, align 8
  %v2570 = load i64, ptr %slot254, align 8
  %cv2571 = trunc i64 %v2570 to i32
  %v2572 = load i32, ptr %slot256, align 8
  %call2573 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v2567, i64 %v2568, i64 %v2569, i32 %cv2571, i32 %v2572) nomerge, !dbg !134
  store i32 %call2573, ptr %slot258, align 8
  %v2574 = load i32, ptr %slot258, align 8
  %cv2575 = zext i32 %v2574 to i64
  %cond2576 = icmp ne i64 %cv2575, 0
  br i1 %cond2576, label %bb_rcsuccess265, label %bb_rcfailure265
bb_rcfailure265:
  %v2577 = load i64, ptr %slot66, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %call2579 = call i32 @myl_rc_take_failure(ptr %p2578) nomerge, !dbg !134
  store i32 %call2579, ptr %slot259, align 8
  %v2580 = load i64, ptr %slot1, align 8
  %p2581 = inttoptr i64 %v2580 to ptr
  %v2582 = load i32, ptr %slot259, align 8
  %call2583 = call i32 @myl_qbe_rc_status(ptr %p2581, i32 %v2582) nomerge, !dbg !134
  store i32 %call2583, ptr %slot260, align 8
  br label %bb_failure
bb_rcsuccess265:
  %v2584 = load i32, ptr %slot253, align 8
  %cv2585 = zext i32 %v2584 to i64
  %cond2586 = icmp ne i64 %cv2585, 0
  br i1 %cond2586, label %bb_rchtaken268, label %bb_rchcopied268
bb_rchcopied268:
  %v2587 = load i64, ptr %slot17, align 8
  %p2588 = inttoptr i64 %v2587 to ptr
  %ld2589 = load i32, ptr %p2588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2589, ptr %slot261, align 8
  %v2590 = load i32, ptr %slot261, align 8
  %cv2591 = zext i32 %v2590 to i64
  %cond2592 = icmp ne i64 %cv2591, 0
  br i1 %cond2592, label %bb_rcslotdrop271, label %bb_rcslotdone271
bb_rcslotdrop271:
  %v2593 = load i64, ptr %slot17, align 8
  %p2594 = inttoptr i64 %v2593 to ptr
  store i32 0, ptr %p2594, align 4, !alias.scope !3, !noalias !4
  %v2595 = load i64, ptr %slot26, align 8
  store i64 %v2595, ptr %slot262, align 8
  %v2596 = load i64, ptr %slot18, align 8
  %p2597 = inttoptr i64 %v2596 to ptr
  %ld2598 = load i32, ptr %p2597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2598, ptr %slot263, align 8
  %v2599 = load i32, ptr %slot263, align 8
  %op2600 = and i32 %v2599, 28
  store i32 %op2600, ptr %slot264, align 8
  %v2601 = load i32, ptr %slot264, align 8
  %cv2602 = zext i32 %v2601 to i64
  %cond2603 = icmp ne i64 %cv2602, 0
  br i1 %cond2603, label %bb_rcslotrole271, label %bb_rcslotowner271
bb_rcslotrole271:
  %v2604 = load i64, ptr %slot66, align 8
  store i64 %v2604, ptr %slot265, align 8
  %v2605 = load i64, ptr %slot265, align 8
  %v2606 = load i64, ptr %slot262, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2605, i64 %v2606) nomerge, !dbg !134
  br label %bb_rcslotdone271
bb_rcslotowner271:
  %v2607 = load i64, ptr %slot66, align 8
  store i64 %v2607, ptr %slot266, align 8
  %v2608 = load i64, ptr %slot266, align 8
  %v2609 = load i64, ptr %slot262, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2608, i64 %v2609) nomerge, !dbg !134
  br label %bb_rcslotdone271
bb_rcslotdone271:
  br label %bb_rchprepared268
bb_rchtaken268:
  %v2610 = load i64, ptr %slot17, align 8
  %p2611 = inttoptr i64 %v2610 to ptr
  store i32 0, ptr %p2611, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared268
bb_rchprepared268:
  %v2612 = load i64, ptr %slot24, align 8
  %p2613 = inttoptr i64 %v2612 to ptr
  store i32 2, ptr %p2613, align 4, !alias.scope !3, !noalias !4
  %v2614 = load i64, ptr %slot23, align 8
  %p2615 = inttoptr i64 %v2614 to ptr
  store i32 1, ptr %p2615, align 4, !alias.scope !3, !noalias !4
  %v2616 = load i64, ptr %slot26, align 8
  store i64 %v2616, ptr %slot267, align 8
  %v2617 = load i64, ptr %slot31, align 8
  store i64 %v2617, ptr %slot268, align 8
  %v2618 = load i64, ptr %slot268, align 8
  %v2619 = load i64, ptr %slot267, align 8
  %p2620 = inttoptr i64 %v2618 to ptr
  %p2621 = inttoptr i64 %v2619 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2621, ptr %p2620, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2622 = load i64, ptr %slot18, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  store i32 2, ptr %p2623, align 4, !alias.scope !3, !noalias !4
  %v2624 = load i64, ptr %slot24, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  %ld2626 = load i32, ptr %p2625, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2626, ptr %slot269, align 8
  %v2627 = load i32, ptr %slot269, align 8
  %v2628 = load i64, ptr %slot18, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  store i32 %v2627, ptr %p2629, align 4, !alias.scope !3, !noalias !4
  %v2630 = load i64, ptr %slot23, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  store i32 0, ptr %p2631, align 4, !alias.scope !3, !noalias !4
  %v2632 = load i64, ptr %slot17, align 8
  %p2633 = inttoptr i64 %v2632 to ptr
  store i32 1, ptr %p2633, align 4, !alias.scope !3, !noalias !4
  %v2634 = load i64, ptr %slot267, align 8
  %v2635 = load i64, ptr %slot54, align 8
  %p2636 = inttoptr i64 %v2635 to ptr
  store i64 %v2634, ptr %p2636, align 8, !alias.scope !3, !noalias !4
  %v2637 = load i64, ptr %slot54, align 8
  %p2638 = inttoptr i64 %v2637 to ptr
  %ld2639 = load i64, ptr %p2638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2639, ptr %slot270, align 8
  %v2640 = load i64, ptr %slot31, align 8
  store i64 %v2640, ptr %slot271, align 8
  %v2641 = load i64, ptr %slot67, align 8
  store i64 %v2641, ptr %slot272, align 8
  %v2642 = load i64, ptr %slot66, align 8
  %v2643 = load i64, ptr %slot271, align 8
  %v2644 = load i64, ptr %slot270, align 8
  %v2645 = load i64, ptr %slot272, align 8
  %cv2646 = trunc i64 %v2645 to i32
  %call2647 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v2642, i64 %v2643, i64 %v2644, i32 %cv2646) nomerge, !dbg !136
  store i32 %call2647, ptr %slot273, align 8
  %v2648 = load i32, ptr %slot273, align 8
  %cv2649 = zext i32 %v2648 to i64
  %cond2650 = icmp ne i64 %cv2649, 0
  br i1 %cond2650, label %bb_rcsuccess293, label %bb_rcfailure293
bb_rcfailure293:
  %v2651 = load i64, ptr %slot66, align 8
  %p2652 = inttoptr i64 %v2651 to ptr
  %call2653 = call i32 @myl_rc_take_failure(ptr %p2652) nomerge, !dbg !136
  store i32 %call2653, ptr %slot274, align 8
  %v2654 = load i64, ptr %slot1, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  %v2656 = load i32, ptr %slot274, align 8
  %call2657 = call i32 @myl_qbe_rc_status(ptr %p2655, i32 %v2656) nomerge, !dbg !136
  store i32 %call2657, ptr %slot275, align 8
  br label %bb_failure
bb_rcsuccess293:
  %v2658 = load i64, ptr %slot17, align 8
  %p2659 = inttoptr i64 %v2658 to ptr
  store i32 0, ptr %p2659, align 4, !alias.scope !3, !noalias !4
  %v2660 = load i64, ptr %slot24, align 8
  %p2661 = inttoptr i64 %v2660 to ptr
  store i32 2, ptr %p2661, align 4, !alias.scope !3, !noalias !4
  %v2662 = load i64, ptr %slot23, align 8
  %p2663 = inttoptr i64 %v2662 to ptr
  store i32 1, ptr %p2663, align 4, !alias.scope !3, !noalias !4
  %v2664 = load i64, ptr %slot7, align 8
  %p2665 = inttoptr i64 %v2664 to ptr
  %ld2666 = load i32, ptr %p2665, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2666, ptr %slot276, align 8
  %v2667 = load i32, ptr %slot276, align 8
  %cv2668 = zext i32 %v2667 to i64
  %cond2669 = icmp ne i64 %cv2668, 0
  br i1 %cond2669, label %bb_rcslotdrop302, label %bb_rcslotdone302
bb_rcslotdrop302:
  %v2670 = load i64, ptr %slot7, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  store i32 0, ptr %p2671, align 4, !alias.scope !3, !noalias !4
  %v2672 = load i64, ptr %slot45, align 8
  store i64 %v2672, ptr %slot277, align 8
  %v2673 = load i64, ptr %slot8, align 8
  %p2674 = inttoptr i64 %v2673 to ptr
  %ld2675 = load i32, ptr %p2674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2675, ptr %slot278, align 8
  %v2676 = load i32, ptr %slot278, align 8
  %op2677 = and i32 %v2676, 28
  store i32 %op2677, ptr %slot279, align 8
  %v2678 = load i32, ptr %slot279, align 8
  %cv2679 = zext i32 %v2678 to i64
  %cond2680 = icmp ne i64 %cv2679, 0
  br i1 %cond2680, label %bb_rcslotrole302, label %bb_rcslotowner302
bb_rcslotrole302:
  %v2681 = load i64, ptr %slot66, align 8
  store i64 %v2681, ptr %slot280, align 8
  %v2682 = load i64, ptr %slot280, align 8
  %v2683 = load i64, ptr %slot277, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2682, i64 %v2683) nomerge, !dbg !136
  br label %bb_rcslotdone302
bb_rcslotowner302:
  %v2684 = load i64, ptr %slot66, align 8
  store i64 %v2684, ptr %slot281, align 8
  %v2685 = load i64, ptr %slot281, align 8
  %v2686 = load i64, ptr %slot277, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2685, i64 %v2686) nomerge, !dbg !136
  br label %bb_rcslotdone302
bb_rcslotdone302:
  %v2687 = load i64, ptr %slot45, align 8
  store i64 %v2687, ptr %slot282, align 8
  %v2688 = load i64, ptr %slot31, align 8
  store i64 %v2688, ptr %slot283, align 8
  %v2689 = load i64, ptr %slot283, align 8
  %v2690 = load i64, ptr %slot282, align 8
  %p2691 = inttoptr i64 %v2689 to ptr
  %p2692 = inttoptr i64 %v2690 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2692, ptr %p2691, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v2693 = load i64, ptr %slot23, align 8
  %p2694 = inttoptr i64 %v2693 to ptr
  store i32 0, ptr %p2694, align 4, !alias.scope !3, !noalias !4
  %v2695 = load i64, ptr %slot8, align 8
  %p2696 = inttoptr i64 %v2695 to ptr
  store i32 2, ptr %p2696, align 4, !alias.scope !3, !noalias !4
  %v2697 = load i64, ptr %slot24, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  %ld2699 = load i32, ptr %p2698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2699, ptr %slot284, align 8
  %v2700 = load i32, ptr %slot284, align 8
  %v2701 = load i64, ptr %slot8, align 8
  %p2702 = inttoptr i64 %v2701 to ptr
  store i32 %v2700, ptr %p2702, align 4, !alias.scope !3, !noalias !4
  %v2703 = load i64, ptr %slot7, align 8
  %p2704 = inttoptr i64 %v2703 to ptr
  store i32 1, ptr %p2704, align 4, !alias.scope !3, !noalias !4
  %v2705 = load i64, ptr %slot39, align 8
  %v2706 = load i64, ptr %slot54, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  store i64 %v2705, ptr %p2707, align 8, !alias.scope !3, !noalias !4
  %v2708 = load i64, ptr %slot54, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  %ld2710 = load i64, ptr %p2709, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2710, ptr %slot285, align 8
  %v2711 = load i64, ptr %slot17, align 8
  %p2712 = inttoptr i64 %v2711 to ptr
  %ld2713 = load i32, ptr %p2712, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2713, ptr %slot286, align 8
  %v2714 = load i64, ptr %slot18, align 8
  %p2715 = inttoptr i64 %v2714 to ptr
  %ld2716 = load i32, ptr %p2715, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2716, ptr %slot287, align 8
  %v2717 = load i32, ptr %slot287, align 8
  %op2718 = and i32 %v2717, 24
  store i32 %op2718, ptr %slot287, align 8
  %v2719 = load i32, ptr %slot287, align 8
  %cmp2720 = icmp eq i32 %v2719, 0
  %cv2721 = zext i1 %cmp2720 to i32
  store i32 %cv2721, ptr %slot288, align 8
  %v2722 = load i32, ptr %slot286, align 8
  %v2723 = load i32, ptr %slot288, align 8
  %op2724 = and i32 %v2722, %v2723
  store i32 %op2724, ptr %slot289, align 8
  %v2725 = load i32, ptr %slot289, align 8
  %cv2726 = zext i32 %v2725 to i64
  %cond2727 = icmp ne i64 %cv2726, 0
  br i1 %cond2727, label %bb_rcprivateown323, label %bb_rcprivateloan323
bb_rcprivateown323:
  %v2728 = load i64, ptr %slot31, align 8
  store i64 %v2728, ptr %slot290, align 8
  %v2729 = load i64, ptr %slot67, align 8
  store i64 %v2729, ptr %slot291, align 8
  %v2730 = load i64, ptr %slot285, align 8
  %v2731 = load i64, ptr %slot290, align 8
  %op2732 = sub i64 %v2730, %v2731
  store i64 %op2732, ptr %slot292, align 8
  %v2733 = load i64, ptr %slot290, align 8
  %v2734 = load i64, ptr %slot285, align 8
  %op2735 = sub i64 %v2733, %v2734
  store i64 %op2735, ptr %slot293, align 8
  %v2736 = load i64, ptr %slot292, align 8
  %cmp2737 = icmp ult i64 %v2736, 24
  %cv2738 = zext i1 %cmp2737 to i32
  store i32 %cv2738, ptr %slot294, align 8
  %v2739 = load i64, ptr %slot293, align 8
  %cmp2740 = icmp ult i64 %v2739, 24
  %cv2741 = zext i1 %cmp2740 to i32
  store i32 %cv2741, ptr %slot295, align 8
  %v2742 = load i32, ptr %slot294, align 8
  %v2743 = load i32, ptr %slot295, align 8
  %op2744 = or i32 %v2742, %v2743
  store i32 %op2744, ptr %slot296, align 8
  %v2745 = load i32, ptr %slot296, align 8
  %cv2746 = zext i32 %v2745 to i64
  %cond2747 = icmp ne i64 %cv2746, 0
  br i1 %cond2747, label %bb_rcmoveslow326, label %bb_rcmovecheck326
bb_rcmovecheck326:
  %v2748 = load i64, ptr %slot285, align 8
  %op2749 = add i64 %v2748, 0
  store i64 %op2749, ptr %slot297, align 8
  %v2750 = load i64, ptr %slot297, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  %ld2752 = load i64, ptr %p2751, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2752, ptr %slot298, align 8
  %v2753 = load i64, ptr %slot298, align 8
  %cmp2754 = icmp ne i64 %v2753, 0
  %cv2755 = zext i1 %cmp2754 to i32
  store i32 %cv2755, ptr %slot299, align 8
  %v2756 = load i32, ptr %slot299, align 8
  %cv2757 = zext i32 %v2756 to i64
  %cond2758 = icmp ne i64 %cv2757, 0
  br i1 %cond2758, label %bb_rcmoveheader334, label %bb_rcmovenext334
bb_rcmoveheader334:
  %v2759 = load i64, ptr %slot298, align 8
  %op2760 = sub i64 %v2759, 16
  store i64 %op2760, ptr %slot300, align 8
  %v2761 = load i64, ptr %slot298, align 8
  %p2762 = inttoptr i64 %v2761 to ptr
  %rgep2763 = getelementptr i8, ptr %p2762, i64 -16
  %ld2764 = load i64, ptr %rgep2763, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2764, ptr %slot301, align 8
  %v2765 = load i64, ptr %slot301, align 8
  %op2766 = and i64 %v2765, 5764607523034234881
  store i64 %op2766, ptr %slot302, align 8
  %v2767 = load i64, ptr %slot302, align 8
  %cmp2768 = icmp ne i64 %v2767, 0
  %cv2769 = zext i1 %cmp2768 to i32
  store i32 %cv2769, ptr %slot303, align 8
  %v2770 = load i32, ptr %slot303, align 8
  %cv2771 = zext i32 %v2770 to i64
  %cond2772 = icmp ne i64 %cv2771, 0
  br i1 %cond2772, label %bb_rcmoveslow326, label %bb_rcmovenext334
bb_rcmovenext334:
  %v2773 = load i64, ptr %slot285, align 8
  %op2774 = add i64 %v2773, 8
  store i64 %op2774, ptr %slot304, align 8
  %v2775 = load i64, ptr %slot304, align 8
  %p2776 = inttoptr i64 %v2775 to ptr
  %ld2777 = load i64, ptr %p2776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2777, ptr %slot305, align 8
  %v2778 = load i64, ptr %slot305, align 8
  %cmp2779 = icmp ne i64 %v2778, 0
  %cv2780 = zext i1 %cmp2779 to i32
  store i32 %cv2780, ptr %slot306, align 8
  %v2781 = load i32, ptr %slot306, align 8
  %cv2782 = zext i32 %v2781 to i64
  %cond2783 = icmp ne i64 %cv2782, 0
  br i1 %cond2783, label %bb_rcmoveheader342, label %bb_rcmovenext342
bb_rcmoveheader342:
  %v2784 = load i64, ptr %slot305, align 8
  %op2785 = sub i64 %v2784, 16
  store i64 %op2785, ptr %slot307, align 8
  %v2786 = load i64, ptr %slot305, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  %rgep2788 = getelementptr i8, ptr %p2787, i64 -16
  %ld2789 = load i64, ptr %rgep2788, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2789, ptr %slot308, align 8
  %v2790 = load i64, ptr %slot308, align 8
  %op2791 = and i64 %v2790, 5764607523034234881
  store i64 %op2791, ptr %slot309, align 8
  %v2792 = load i64, ptr %slot309, align 8
  %cmp2793 = icmp ne i64 %v2792, 0
  %cv2794 = zext i1 %cmp2793 to i32
  store i32 %cv2794, ptr %slot310, align 8
  %v2795 = load i32, ptr %slot310, align 8
  %cv2796 = zext i32 %v2795 to i64
  %cond2797 = icmp ne i64 %cv2796, 0
  br i1 %cond2797, label %bb_rcmoveslow326, label %bb_rcmovenext342
bb_rcmovenext342:
  %v2798 = load i64, ptr %slot285, align 8
  %op2799 = add i64 %v2798, 16
  store i64 %op2799, ptr %slot311, align 8
  %v2800 = load i64, ptr %slot311, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  %ld2802 = load i64, ptr %p2801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2802, ptr %slot312, align 8
  %v2803 = load i64, ptr %slot312, align 8
  %cmp2804 = icmp ne i64 %v2803, 0
  %cv2805 = zext i1 %cmp2804 to i32
  store i32 %cv2805, ptr %slot313, align 8
  %v2806 = load i32, ptr %slot313, align 8
  %cv2807 = zext i32 %v2806 to i64
  %cond2808 = icmp ne i64 %cv2807, 0
  br i1 %cond2808, label %bb_rcmoveheader350, label %bb_rcmovenext350
bb_rcmoveheader350:
  %v2809 = load i64, ptr %slot312, align 8
  %op2810 = sub i64 %v2809, 16
  store i64 %op2810, ptr %slot314, align 8
  %v2811 = load i64, ptr %slot312, align 8
  %p2812 = inttoptr i64 %v2811 to ptr
  %rgep2813 = getelementptr i8, ptr %p2812, i64 -16
  %ld2814 = load i64, ptr %rgep2813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2814, ptr %slot315, align 8
  %v2815 = load i64, ptr %slot315, align 8
  %op2816 = and i64 %v2815, 5764607523034234881
  store i64 %op2816, ptr %slot316, align 8
  %v2817 = load i64, ptr %slot316, align 8
  %cmp2818 = icmp ne i64 %v2817, 0
  %cv2819 = zext i1 %cmp2818 to i32
  store i32 %cv2819, ptr %slot317, align 8
  %v2820 = load i32, ptr %slot317, align 8
  %cv2821 = zext i32 %v2820 to i64
  %cond2822 = icmp ne i64 %cv2821, 0
  br i1 %cond2822, label %bb_rcmoveslow326, label %bb_rcmovenext350
bb_rcmovenext350:
  %v2823 = load i64, ptr %slot285, align 8
  %v2824 = load i64, ptr %slot290, align 8
  %p2825 = inttoptr i64 %v2823 to ptr
  %p2826 = inttoptr i64 %v2824 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2826, ptr %p2825, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v2827 = load i64, ptr %slot285, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  store i64 0, ptr %p2828, align 8, !alias.scope !3, !noalias !4
  %v2829 = load i64, ptr %slot285, align 8
  %op2830 = add i64 %v2829, 8
  store i64 %op2830, ptr %slot318, align 8
  %v2831 = load i64, ptr %slot318, align 8
  %p2832 = inttoptr i64 %v2831 to ptr
  store i64 0, ptr %p2832, align 8, !alias.scope !3, !noalias !4
  %v2833 = load i64, ptr %slot285, align 8
  %op2834 = add i64 %v2833, 16
  store i64 %op2834, ptr %slot319, align 8
  %v2835 = load i64, ptr %slot319, align 8
  %p2836 = inttoptr i64 %v2835 to ptr
  store i64 0, ptr %p2836, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved326
bb_rcmoveslow326:
  %v2837 = load i64, ptr %slot66, align 8
  %v2838 = load i64, ptr %slot290, align 8
  %v2839 = load i64, ptr %slot285, align 8
  %v2840 = load i64, ptr %slot291, align 8
  %cv2841 = trunc i64 %v2840 to i32
  %call2842 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v2837, i64 %v2838, i64 %v2839, i32 %cv2841) nomerge, !dbg !138
  store i32 %call2842, ptr %slot320, align 8
  %v2843 = load i32, ptr %slot320, align 8
  %cv2844 = zext i32 %v2843 to i64
  %cond2845 = icmp ne i64 %cv2844, 0
  br i1 %cond2845, label %bb_rcsuccess359, label %bb_rcfailure359
bb_rcfailure359:
  %v2846 = load i64, ptr %slot66, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  %call2848 = call i32 @myl_rc_take_failure(ptr %p2847) nomerge, !dbg !138
  store i32 %call2848, ptr %slot321, align 8
  %v2849 = load i64, ptr %slot1, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  %v2851 = load i32, ptr %slot321, align 8
  %call2852 = call i32 @myl_qbe_rc_status(ptr %p2850, i32 %v2851) nomerge, !dbg !138
  store i32 %call2852, ptr %slot322, align 8
  br label %bb_failure
bb_rcsuccess359:
  br label %bb_rcmoved326
bb_rcmoved326:
  %v2853 = load i64, ptr %slot17, align 8
  %p2854 = inttoptr i64 %v2853 to ptr
  store i32 0, ptr %p2854, align 4, !alias.scope !3, !noalias !4
  %v2855 = load i64, ptr %slot24, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  store i32 2, ptr %p2856, align 4, !alias.scope !3, !noalias !4
  %v2857 = load i64, ptr %slot23, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  store i32 1, ptr %p2858, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared323
bb_rcprivateloan323:
  %v2859 = load i64, ptr %slot31, align 8
  store i64 %v2859, ptr %slot323, align 8
  %v2860 = load i64, ptr %slot66, align 8
  %v2861 = load i64, ptr %slot323, align 8
  %v2862 = load i64, ptr %slot285, align 8
  %call2863 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_loan(i64 %v2860, i64 %v2861, i64 %v2862) nomerge, !dbg !138
  store i32 %call2863, ptr %slot324, align 8
  %v2864 = load i32, ptr %slot324, align 8
  %cv2865 = zext i32 %v2864 to i64
  %cond2866 = icmp ne i64 %cv2865, 0
  br i1 %cond2866, label %bb_rcsuccess367, label %bb_rcfailure367
bb_rcfailure367:
  %v2867 = load i64, ptr %slot66, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  %call2869 = call i32 @myl_rc_take_failure(ptr %p2868) nomerge, !dbg !138
  store i32 %call2869, ptr %slot325, align 8
  %v2870 = load i64, ptr %slot1, align 8
  %p2871 = inttoptr i64 %v2870 to ptr
  %v2872 = load i32, ptr %slot325, align 8
  %call2873 = call i32 @myl_qbe_rc_status(ptr %p2871, i32 %v2872) nomerge, !dbg !138
  store i32 %call2873, ptr %slot326, align 8
  br label %bb_failure
bb_rcsuccess367:
  %v2874 = load i64, ptr %slot24, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  store i32 2, ptr %p2875, align 4, !alias.scope !3, !noalias !4
  %v2876 = load i64, ptr %slot24, align 8
  %p2877 = inttoptr i64 %v2876 to ptr
  store i32 16, ptr %p2877, align 4, !alias.scope !3, !noalias !4
  %v2878 = load i64, ptr %slot23, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  store i32 1, ptr %p2879, align 4, !alias.scope !3, !noalias !4
  %v2880 = load i64, ptr %slot17, align 8
  %p2881 = inttoptr i64 %v2880 to ptr
  %ld2882 = load i32, ptr %p2881, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2882, ptr %slot327, align 8
  %v2883 = load i32, ptr %slot327, align 8
  %cv2884 = zext i32 %v2883 to i64
  %cond2885 = icmp ne i64 %cv2884, 0
  br i1 %cond2885, label %bb_rcslotdrop375, label %bb_rcslotdone375
bb_rcslotdrop375:
  %v2886 = load i64, ptr %slot17, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  store i32 0, ptr %p2887, align 4, !alias.scope !3, !noalias !4
  %v2888 = load i64, ptr %slot26, align 8
  store i64 %v2888, ptr %slot328, align 8
  %v2889 = load i64, ptr %slot18, align 8
  %p2890 = inttoptr i64 %v2889 to ptr
  %ld2891 = load i32, ptr %p2890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2891, ptr %slot329, align 8
  %v2892 = load i32, ptr %slot329, align 8
  %op2893 = and i32 %v2892, 28
  store i32 %op2893, ptr %slot330, align 8
  %v2894 = load i32, ptr %slot330, align 8
  %cv2895 = zext i32 %v2894 to i64
  %cond2896 = icmp ne i64 %cv2895, 0
  br i1 %cond2896, label %bb_rcslotrole375, label %bb_rcslotowner375
bb_rcslotrole375:
  %v2897 = load i64, ptr %slot66, align 8
  store i64 %v2897, ptr %slot331, align 8
  %v2898 = load i64, ptr %slot331, align 8
  %v2899 = load i64, ptr %slot328, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v2898, i64 %v2899) nomerge, !dbg !138
  br label %bb_rcslotdone375
bb_rcslotowner375:
  %v2900 = load i64, ptr %slot328, align 8
  %p2902 = inttoptr i64 %v2900 to ptr
  %gep2903 = getelementptr i8, ptr %p2902, i64 0
  %op2901 = ptrtoint ptr %gep2903 to i64
  store i64 %op2901, ptr %slot332, align 8
  %v2904 = load i64, ptr %slot66, align 8
  store i64 %v2904, ptr %slot333, align 8
  %v2905 = load i64, ptr %slot332, align 8
  %p2906 = inttoptr i64 %v2905 to ptr
  %ld2907 = load i64, ptr %p2906, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2907, ptr %slot334, align 8
  %v2908 = load i64, ptr %slot334, align 8
  %cmp2909 = icmp ne i64 %v2908, 0
  %cv2910 = zext i1 %cmp2909 to i32
  store i32 %cv2910, ptr %slot335, align 8
  %v2911 = load i32, ptr %slot335, align 8
  %cv2912 = zext i32 %v2911 to i64
  %cond2913 = icmp ne i64 %cv2912, 0
  br i1 %cond2913, label %bb_rcgnn393, label %bb_rcgdone393
bb_rcgnn393:
  %v2914 = load i64, ptr %slot334, align 8
  %op2915 = sub i64 %v2914, 16
  store i64 %op2915, ptr %slot336, align 8
  %v2916 = load i64, ptr %slot334, align 8
  %p2917 = inttoptr i64 %v2916 to ptr
  %rgep2918 = getelementptr i8, ptr %p2917, i64 -16
  %ld2919 = load i64, ptr %rgep2918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2919, ptr %slot337, align 8
  %v2920 = load i64, ptr %slot337, align 8
  %op2921 = and i64 %v2920, 4611686018427387906
  store i64 %op2921, ptr %slot338, align 8
  %v2922 = load i64, ptr %slot338, align 8
  %cmp2923 = icmp ne i64 %v2922, 0
  %cv2924 = zext i1 %cmp2923 to i32
  store i32 %cv2924, ptr %slot339, align 8
  %v2925 = load i32, ptr %slot339, align 8
  %cv2926 = zext i32 %v2925 to i64
  %cond2927 = icmp ne i64 %cv2926, 0
  br i1 %cond2927, label %bb_rcgclear393, label %bb_rcgcounted393
bb_rcgcounted393:
  %v2928 = load i64, ptr %slot334, align 8
  %op2929 = sub i64 %v2928, 32
  store i64 %op2929, ptr %slot340, align 8
  %v2930 = load i64, ptr %slot334, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  %rgep2932 = getelementptr i8, ptr %p2931, i64 -32
  %ld2933 = load i64, ptr %rgep2932, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2933, ptr %slot341, align 8
  %v2934 = load i64, ptr %slot341, align 8
  %op2935 = sub i64 %v2934, 1
  store i64 %op2935, ptr %slot342, align 8
  %v2936 = load i64, ptr %slot342, align 8
  %cmp2937 = icmp eq i64 %v2936, 0
  %cv2938 = zext i1 %cmp2937 to i32
  store i32 %cv2938, ptr %slot343, align 8
  %v2939 = load i32, ptr %slot343, align 8
  %cv2940 = zext i32 %v2939 to i64
  %cond2941 = icmp ne i64 %cv2940, 0
  br i1 %cond2941, label %bb_rcglast393, label %bb_rcgdec393
bb_rcglast393:
  %v2942 = load i64, ptr %slot334, align 8
  %op2943 = sub i64 %v2942, 24
  store i64 %op2943, ptr %slot344, align 8
  %v2944 = load i64, ptr %slot334, align 8
  %p2945 = inttoptr i64 %v2944 to ptr
  %rgep2946 = getelementptr i8, ptr %p2945, i64 -24
  %ld2947 = load i64, ptr %rgep2946, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2947, ptr %slot345, align 8
  %v2948 = load i64, ptr %slot345, align 8
  %cmp2949 = icmp ne i64 %v2948, 0
  %cv2950 = zext i1 %cmp2949 to i32
  store i32 %cv2950, ptr %slot346, align 8
  %v2951 = load i32, ptr %slot346, align 8
  %cv2952 = zext i32 %v2951 to i64
  %cond2953 = icmp ne i64 %cv2952, 0
  br i1 %cond2953, label %bb_rcgdec393, label %bb_rcgslow393
bb_rcgslow393:
  %v2954 = load i64, ptr %slot333, align 8
  %v2955 = load i64, ptr %slot332, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2954, i64 %v2955) nomerge, !dbg !138
  br label %bb_rcgdone393
bb_rcgdec393:
  %v2956 = load i64, ptr %slot342, align 8
  %v2957 = load i64, ptr %slot334, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  %rgep2959 = getelementptr i8, ptr %p2958, i64 -32
  store i64 %v2956, ptr %rgep2959, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear393
bb_rcgclear393:
  %v2960 = load i64, ptr %slot332, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  store i64 0, ptr %p2961, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone393
bb_rcgdone393:
  %v2962 = load i64, ptr %slot328, align 8
  %p2964 = inttoptr i64 %v2962 to ptr
  %gep2965 = getelementptr i8, ptr %p2964, i64 8
  %op2963 = ptrtoint ptr %gep2965 to i64
  store i64 %op2963, ptr %slot347, align 8
  %v2966 = load i64, ptr %slot66, align 8
  store i64 %v2966, ptr %slot348, align 8
  %v2967 = load i64, ptr %slot347, align 8
  %p2968 = inttoptr i64 %v2967 to ptr
  %ld2969 = load i64, ptr %p2968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2969, ptr %slot349, align 8
  %v2970 = load i64, ptr %slot349, align 8
  %cmp2971 = icmp ne i64 %v2970, 0
  %cv2972 = zext i1 %cmp2971 to i32
  store i32 %cv2972, ptr %slot350, align 8
  %v2973 = load i32, ptr %slot350, align 8
  %cv2974 = zext i32 %v2973 to i64
  %cond2975 = icmp ne i64 %cv2974, 0
  br i1 %cond2975, label %bb_rcgnn409, label %bb_rcgdone409
bb_rcgnn409:
  %v2976 = load i64, ptr %slot349, align 8
  %op2977 = sub i64 %v2976, 16
  store i64 %op2977, ptr %slot351, align 8
  %v2978 = load i64, ptr %slot349, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  %rgep2980 = getelementptr i8, ptr %p2979, i64 -16
  %ld2981 = load i64, ptr %rgep2980, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2981, ptr %slot352, align 8
  %v2982 = load i64, ptr %slot352, align 8
  %op2983 = and i64 %v2982, 4611686018427387906
  store i64 %op2983, ptr %slot353, align 8
  %v2984 = load i64, ptr %slot353, align 8
  %cmp2985 = icmp ne i64 %v2984, 0
  %cv2986 = zext i1 %cmp2985 to i32
  store i32 %cv2986, ptr %slot354, align 8
  %v2987 = load i32, ptr %slot354, align 8
  %cv2988 = zext i32 %v2987 to i64
  %cond2989 = icmp ne i64 %cv2988, 0
  br i1 %cond2989, label %bb_rcgclear409, label %bb_rcgcounted409
bb_rcgcounted409:
  %v2990 = load i64, ptr %slot349, align 8
  %op2991 = sub i64 %v2990, 32
  store i64 %op2991, ptr %slot355, align 8
  %v2992 = load i64, ptr %slot349, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  %rgep2994 = getelementptr i8, ptr %p2993, i64 -32
  %ld2995 = load i64, ptr %rgep2994, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2995, ptr %slot356, align 8
  %v2996 = load i64, ptr %slot356, align 8
  %op2997 = sub i64 %v2996, 1
  store i64 %op2997, ptr %slot357, align 8
  %v2998 = load i64, ptr %slot357, align 8
  %cmp2999 = icmp eq i64 %v2998, 0
  %cv3000 = zext i1 %cmp2999 to i32
  store i32 %cv3000, ptr %slot358, align 8
  %v3001 = load i32, ptr %slot358, align 8
  %cv3002 = zext i32 %v3001 to i64
  %cond3003 = icmp ne i64 %cv3002, 0
  br i1 %cond3003, label %bb_rcglast409, label %bb_rcgdec409
bb_rcglast409:
  %v3004 = load i64, ptr %slot349, align 8
  %op3005 = sub i64 %v3004, 24
  store i64 %op3005, ptr %slot359, align 8
  %v3006 = load i64, ptr %slot349, align 8
  %p3007 = inttoptr i64 %v3006 to ptr
  %rgep3008 = getelementptr i8, ptr %p3007, i64 -24
  %ld3009 = load i64, ptr %rgep3008, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3009, ptr %slot360, align 8
  %v3010 = load i64, ptr %slot360, align 8
  %cmp3011 = icmp ne i64 %v3010, 0
  %cv3012 = zext i1 %cmp3011 to i32
  store i32 %cv3012, ptr %slot361, align 8
  %v3013 = load i32, ptr %slot361, align 8
  %cv3014 = zext i32 %v3013 to i64
  %cond3015 = icmp ne i64 %cv3014, 0
  br i1 %cond3015, label %bb_rcgdec409, label %bb_rcgslow409
bb_rcgslow409:
  %v3016 = load i64, ptr %slot348, align 8
  %v3017 = load i64, ptr %slot347, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3016, i64 %v3017) nomerge, !dbg !138
  br label %bb_rcgdone409
bb_rcgdec409:
  %v3018 = load i64, ptr %slot357, align 8
  %v3019 = load i64, ptr %slot349, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %rgep3021 = getelementptr i8, ptr %p3020, i64 -32
  store i64 %v3018, ptr %rgep3021, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear409
bb_rcgclear409:
  %v3022 = load i64, ptr %slot347, align 8
  %p3023 = inttoptr i64 %v3022 to ptr
  store i64 0, ptr %p3023, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone409
bb_rcgdone409:
  %v3024 = load i64, ptr %slot328, align 8
  %p3026 = inttoptr i64 %v3024 to ptr
  %gep3027 = getelementptr i8, ptr %p3026, i64 16
  %op3025 = ptrtoint ptr %gep3027 to i64
  store i64 %op3025, ptr %slot362, align 8
  %v3028 = load i64, ptr %slot66, align 8
  store i64 %v3028, ptr %slot363, align 8
  %v3029 = load i64, ptr %slot362, align 8
  %p3030 = inttoptr i64 %v3029 to ptr
  %ld3031 = load i64, ptr %p3030, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3031, ptr %slot364, align 8
  %v3032 = load i64, ptr %slot364, align 8
  %cmp3033 = icmp ne i64 %v3032, 0
  %cv3034 = zext i1 %cmp3033 to i32
  store i32 %cv3034, ptr %slot365, align 8
  %v3035 = load i32, ptr %slot365, align 8
  %cv3036 = zext i32 %v3035 to i64
  %cond3037 = icmp ne i64 %cv3036, 0
  br i1 %cond3037, label %bb_rcgnn425, label %bb_rcgdone425
bb_rcgnn425:
  %v3038 = load i64, ptr %slot364, align 8
  %op3039 = sub i64 %v3038, 16
  store i64 %op3039, ptr %slot366, align 8
  %v3040 = load i64, ptr %slot364, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  %rgep3042 = getelementptr i8, ptr %p3041, i64 -16
  %ld3043 = load i64, ptr %rgep3042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3043, ptr %slot367, align 8
  %v3044 = load i64, ptr %slot367, align 8
  %op3045 = and i64 %v3044, 4611686018427387906
  store i64 %op3045, ptr %slot368, align 8
  %v3046 = load i64, ptr %slot368, align 8
  %cmp3047 = icmp ne i64 %v3046, 0
  %cv3048 = zext i1 %cmp3047 to i32
  store i32 %cv3048, ptr %slot369, align 8
  %v3049 = load i32, ptr %slot369, align 8
  %cv3050 = zext i32 %v3049 to i64
  %cond3051 = icmp ne i64 %cv3050, 0
  br i1 %cond3051, label %bb_rcgclear425, label %bb_rcgcounted425
bb_rcgcounted425:
  %v3052 = load i64, ptr %slot364, align 8
  %op3053 = sub i64 %v3052, 32
  store i64 %op3053, ptr %slot370, align 8
  %v3054 = load i64, ptr %slot364, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  %rgep3056 = getelementptr i8, ptr %p3055, i64 -32
  %ld3057 = load i64, ptr %rgep3056, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3057, ptr %slot371, align 8
  %v3058 = load i64, ptr %slot371, align 8
  %op3059 = sub i64 %v3058, 1
  store i64 %op3059, ptr %slot372, align 8
  %v3060 = load i64, ptr %slot372, align 8
  %cmp3061 = icmp eq i64 %v3060, 0
  %cv3062 = zext i1 %cmp3061 to i32
  store i32 %cv3062, ptr %slot373, align 8
  %v3063 = load i32, ptr %slot373, align 8
  %cv3064 = zext i32 %v3063 to i64
  %cond3065 = icmp ne i64 %cv3064, 0
  br i1 %cond3065, label %bb_rcglast425, label %bb_rcgdec425
bb_rcglast425:
  %v3066 = load i64, ptr %slot364, align 8
  %op3067 = sub i64 %v3066, 24
  store i64 %op3067, ptr %slot374, align 8
  %v3068 = load i64, ptr %slot364, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %rgep3070 = getelementptr i8, ptr %p3069, i64 -24
  %ld3071 = load i64, ptr %rgep3070, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3071, ptr %slot375, align 8
  %v3072 = load i64, ptr %slot375, align 8
  %cmp3073 = icmp ne i64 %v3072, 0
  %cv3074 = zext i1 %cmp3073 to i32
  store i32 %cv3074, ptr %slot376, align 8
  %v3075 = load i32, ptr %slot376, align 8
  %cv3076 = zext i32 %v3075 to i64
  %cond3077 = icmp ne i64 %cv3076, 0
  br i1 %cond3077, label %bb_rcgdec425, label %bb_rcgslow425
bb_rcgslow425:
  %v3078 = load i64, ptr %slot363, align 8
  %v3079 = load i64, ptr %slot362, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3078, i64 %v3079) nomerge, !dbg !138
  br label %bb_rcgdone425
bb_rcgdec425:
  %v3080 = load i64, ptr %slot372, align 8
  %v3081 = load i64, ptr %slot364, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  %rgep3083 = getelementptr i8, ptr %p3082, i64 -32
  store i64 %v3080, ptr %rgep3083, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear425
bb_rcgclear425:
  %v3084 = load i64, ptr %slot362, align 8
  %p3085 = inttoptr i64 %v3084 to ptr
  store i64 0, ptr %p3085, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone425
bb_rcgdone425:
  %v3086 = load i64, ptr %slot328, align 8
  %p3087 = inttoptr i64 %v3086 to ptr
  store i64 0, ptr %p3087, align 8, !alias.scope !3, !noalias !4
  %v3088 = load i64, ptr %slot328, align 8
  %p3090 = inttoptr i64 %v3088 to ptr
  %gep3091 = getelementptr i8, ptr %p3090, i64 8
  %op3089 = ptrtoint ptr %gep3091 to i64
  store i64 %op3089, ptr %slot377, align 8
  %v3092 = load i64, ptr %slot377, align 8
  %p3093 = inttoptr i64 %v3092 to ptr
  store i64 0, ptr %p3093, align 8, !alias.scope !3, !noalias !4
  %v3094 = load i64, ptr %slot328, align 8
  %p3096 = inttoptr i64 %v3094 to ptr
  %gep3097 = getelementptr i8, ptr %p3096, i64 16
  %op3095 = ptrtoint ptr %gep3097 to i64
  store i64 %op3095, ptr %slot378, align 8
  %v3098 = load i64, ptr %slot378, align 8
  %p3099 = inttoptr i64 %v3098 to ptr
  store i64 0, ptr %p3099, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone375
bb_rcslotdone375:
  br label %bb_rcprivateprepared323
bb_rcprivateprepared323:
  %v3100 = load i64, ptr %slot11, align 8
  %p3101 = inttoptr i64 %v3100 to ptr
  %ld3102 = load i32, ptr %p3101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3102, ptr %slot379, align 8
  %v3103 = load i32, ptr %slot379, align 8
  %cv3104 = zext i32 %v3103 to i64
  %cond3105 = icmp ne i64 %cv3104, 0
  br i1 %cond3105, label %bb_rcslotdrop434, label %bb_rcslotdone434
bb_rcslotdrop434:
  %v3106 = load i64, ptr %slot11, align 8
  %p3107 = inttoptr i64 %v3106 to ptr
  store i32 0, ptr %p3107, align 4, !alias.scope !3, !noalias !4
  %v3108 = load i64, ptr %slot47, align 8
  store i64 %v3108, ptr %slot380, align 8
  %v3109 = load i64, ptr %slot12, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  %ld3111 = load i32, ptr %p3110, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3111, ptr %slot381, align 8
  %v3112 = load i32, ptr %slot381, align 8
  %op3113 = and i32 %v3112, 28
  store i32 %op3113, ptr %slot382, align 8
  %v3114 = load i32, ptr %slot382, align 8
  %cv3115 = zext i32 %v3114 to i64
  %cond3116 = icmp ne i64 %cv3115, 0
  br i1 %cond3116, label %bb_rcslotrole434, label %bb_rcslotowner434
bb_rcslotrole434:
  %v3117 = load i64, ptr %slot66, align 8
  store i64 %v3117, ptr %slot383, align 8
  %v3118 = load i64, ptr %slot383, align 8
  %v3119 = load i64, ptr %slot380, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v3118, i64 %v3119) nomerge, !dbg !138
  br label %bb_rcslotdone434
bb_rcslotowner434:
  %v3120 = load i64, ptr %slot380, align 8
  %p3122 = inttoptr i64 %v3120 to ptr
  %gep3123 = getelementptr i8, ptr %p3122, i64 0
  %op3121 = ptrtoint ptr %gep3123 to i64
  store i64 %op3121, ptr %slot384, align 8
  %v3124 = load i64, ptr %slot66, align 8
  store i64 %v3124, ptr %slot385, align 8
  %v3125 = load i64, ptr %slot384, align 8
  %p3126 = inttoptr i64 %v3125 to ptr
  %ld3127 = load i64, ptr %p3126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3127, ptr %slot386, align 8
  %v3128 = load i64, ptr %slot386, align 8
  %cmp3129 = icmp ne i64 %v3128, 0
  %cv3130 = zext i1 %cmp3129 to i32
  store i32 %cv3130, ptr %slot387, align 8
  %v3131 = load i32, ptr %slot387, align 8
  %cv3132 = zext i32 %v3131 to i64
  %cond3133 = icmp ne i64 %cv3132, 0
  br i1 %cond3133, label %bb_rcgnn452, label %bb_rcgdone452
bb_rcgnn452:
  %v3134 = load i64, ptr %slot386, align 8
  %op3135 = sub i64 %v3134, 16
  store i64 %op3135, ptr %slot388, align 8
  %v3136 = load i64, ptr %slot386, align 8
  %p3137 = inttoptr i64 %v3136 to ptr
  %rgep3138 = getelementptr i8, ptr %p3137, i64 -16
  %ld3139 = load i64, ptr %rgep3138, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3139, ptr %slot389, align 8
  %v3140 = load i64, ptr %slot389, align 8
  %op3141 = and i64 %v3140, 4611686018427387906
  store i64 %op3141, ptr %slot390, align 8
  %v3142 = load i64, ptr %slot390, align 8
  %cmp3143 = icmp ne i64 %v3142, 0
  %cv3144 = zext i1 %cmp3143 to i32
  store i32 %cv3144, ptr %slot391, align 8
  %v3145 = load i32, ptr %slot391, align 8
  %cv3146 = zext i32 %v3145 to i64
  %cond3147 = icmp ne i64 %cv3146, 0
  br i1 %cond3147, label %bb_rcgclear452, label %bb_rcgcounted452
bb_rcgcounted452:
  %v3148 = load i64, ptr %slot386, align 8
  %op3149 = sub i64 %v3148, 32
  store i64 %op3149, ptr %slot392, align 8
  %v3150 = load i64, ptr %slot386, align 8
  %p3151 = inttoptr i64 %v3150 to ptr
  %rgep3152 = getelementptr i8, ptr %p3151, i64 -32
  %ld3153 = load i64, ptr %rgep3152, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3153, ptr %slot393, align 8
  %v3154 = load i64, ptr %slot393, align 8
  %op3155 = sub i64 %v3154, 1
  store i64 %op3155, ptr %slot394, align 8
  %v3156 = load i64, ptr %slot394, align 8
  %cmp3157 = icmp eq i64 %v3156, 0
  %cv3158 = zext i1 %cmp3157 to i32
  store i32 %cv3158, ptr %slot395, align 8
  %v3159 = load i32, ptr %slot395, align 8
  %cv3160 = zext i32 %v3159 to i64
  %cond3161 = icmp ne i64 %cv3160, 0
  br i1 %cond3161, label %bb_rcglast452, label %bb_rcgdec452
bb_rcglast452:
  %v3162 = load i64, ptr %slot386, align 8
  %op3163 = sub i64 %v3162, 24
  store i64 %op3163, ptr %slot396, align 8
  %v3164 = load i64, ptr %slot386, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  %rgep3166 = getelementptr i8, ptr %p3165, i64 -24
  %ld3167 = load i64, ptr %rgep3166, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3167, ptr %slot397, align 8
  %v3168 = load i64, ptr %slot397, align 8
  %cmp3169 = icmp ne i64 %v3168, 0
  %cv3170 = zext i1 %cmp3169 to i32
  store i32 %cv3170, ptr %slot398, align 8
  %v3171 = load i32, ptr %slot398, align 8
  %cv3172 = zext i32 %v3171 to i64
  %cond3173 = icmp ne i64 %cv3172, 0
  br i1 %cond3173, label %bb_rcgdec452, label %bb_rcgslow452
bb_rcgslow452:
  %v3174 = load i64, ptr %slot385, align 8
  %v3175 = load i64, ptr %slot384, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3174, i64 %v3175) nomerge, !dbg !138
  br label %bb_rcgdone452
bb_rcgdec452:
  %v3176 = load i64, ptr %slot394, align 8
  %v3177 = load i64, ptr %slot386, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %rgep3179 = getelementptr i8, ptr %p3178, i64 -32
  store i64 %v3176, ptr %rgep3179, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear452
bb_rcgclear452:
  %v3180 = load i64, ptr %slot384, align 8
  %p3181 = inttoptr i64 %v3180 to ptr
  store i64 0, ptr %p3181, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone452
bb_rcgdone452:
  %v3182 = load i64, ptr %slot380, align 8
  %p3184 = inttoptr i64 %v3182 to ptr
  %gep3185 = getelementptr i8, ptr %p3184, i64 8
  %op3183 = ptrtoint ptr %gep3185 to i64
  store i64 %op3183, ptr %slot399, align 8
  %v3186 = load i64, ptr %slot66, align 8
  store i64 %v3186, ptr %slot400, align 8
  %v3187 = load i64, ptr %slot399, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  %ld3189 = load i64, ptr %p3188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3189, ptr %slot401, align 8
  %v3190 = load i64, ptr %slot401, align 8
  %cmp3191 = icmp ne i64 %v3190, 0
  %cv3192 = zext i1 %cmp3191 to i32
  store i32 %cv3192, ptr %slot402, align 8
  %v3193 = load i32, ptr %slot402, align 8
  %cv3194 = zext i32 %v3193 to i64
  %cond3195 = icmp ne i64 %cv3194, 0
  br i1 %cond3195, label %bb_rcgnn468, label %bb_rcgdone468
bb_rcgnn468:
  %v3196 = load i64, ptr %slot401, align 8
  %op3197 = sub i64 %v3196, 16
  store i64 %op3197, ptr %slot403, align 8
  %v3198 = load i64, ptr %slot401, align 8
  %p3199 = inttoptr i64 %v3198 to ptr
  %rgep3200 = getelementptr i8, ptr %p3199, i64 -16
  %ld3201 = load i64, ptr %rgep3200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3201, ptr %slot404, align 8
  %v3202 = load i64, ptr %slot404, align 8
  %op3203 = and i64 %v3202, 4611686018427387906
  store i64 %op3203, ptr %slot405, align 8
  %v3204 = load i64, ptr %slot405, align 8
  %cmp3205 = icmp ne i64 %v3204, 0
  %cv3206 = zext i1 %cmp3205 to i32
  store i32 %cv3206, ptr %slot406, align 8
  %v3207 = load i32, ptr %slot406, align 8
  %cv3208 = zext i32 %v3207 to i64
  %cond3209 = icmp ne i64 %cv3208, 0
  br i1 %cond3209, label %bb_rcgclear468, label %bb_rcgcounted468
bb_rcgcounted468:
  %v3210 = load i64, ptr %slot401, align 8
  %op3211 = sub i64 %v3210, 32
  store i64 %op3211, ptr %slot407, align 8
  %v3212 = load i64, ptr %slot401, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %rgep3214 = getelementptr i8, ptr %p3213, i64 -32
  %ld3215 = load i64, ptr %rgep3214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3215, ptr %slot408, align 8
  %v3216 = load i64, ptr %slot408, align 8
  %op3217 = sub i64 %v3216, 1
  store i64 %op3217, ptr %slot409, align 8
  %v3218 = load i64, ptr %slot409, align 8
  %cmp3219 = icmp eq i64 %v3218, 0
  %cv3220 = zext i1 %cmp3219 to i32
  store i32 %cv3220, ptr %slot410, align 8
  %v3221 = load i32, ptr %slot410, align 8
  %cv3222 = zext i32 %v3221 to i64
  %cond3223 = icmp ne i64 %cv3222, 0
  br i1 %cond3223, label %bb_rcglast468, label %bb_rcgdec468
bb_rcglast468:
  %v3224 = load i64, ptr %slot401, align 8
  %op3225 = sub i64 %v3224, 24
  store i64 %op3225, ptr %slot411, align 8
  %v3226 = load i64, ptr %slot401, align 8
  %p3227 = inttoptr i64 %v3226 to ptr
  %rgep3228 = getelementptr i8, ptr %p3227, i64 -24
  %ld3229 = load i64, ptr %rgep3228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3229, ptr %slot412, align 8
  %v3230 = load i64, ptr %slot412, align 8
  %cmp3231 = icmp ne i64 %v3230, 0
  %cv3232 = zext i1 %cmp3231 to i32
  store i32 %cv3232, ptr %slot413, align 8
  %v3233 = load i32, ptr %slot413, align 8
  %cv3234 = zext i32 %v3233 to i64
  %cond3235 = icmp ne i64 %cv3234, 0
  br i1 %cond3235, label %bb_rcgdec468, label %bb_rcgslow468
bb_rcgslow468:
  %v3236 = load i64, ptr %slot400, align 8
  %v3237 = load i64, ptr %slot399, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3236, i64 %v3237) nomerge, !dbg !138
  br label %bb_rcgdone468
bb_rcgdec468:
  %v3238 = load i64, ptr %slot409, align 8
  %v3239 = load i64, ptr %slot401, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  %rgep3241 = getelementptr i8, ptr %p3240, i64 -32
  store i64 %v3238, ptr %rgep3241, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear468
bb_rcgclear468:
  %v3242 = load i64, ptr %slot399, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  store i64 0, ptr %p3243, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone468
bb_rcgdone468:
  %v3244 = load i64, ptr %slot380, align 8
  %p3246 = inttoptr i64 %v3244 to ptr
  %gep3247 = getelementptr i8, ptr %p3246, i64 16
  %op3245 = ptrtoint ptr %gep3247 to i64
  store i64 %op3245, ptr %slot414, align 8
  %v3248 = load i64, ptr %slot66, align 8
  store i64 %v3248, ptr %slot415, align 8
  %v3249 = load i64, ptr %slot414, align 8
  %p3250 = inttoptr i64 %v3249 to ptr
  %ld3251 = load i64, ptr %p3250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3251, ptr %slot416, align 8
  %v3252 = load i64, ptr %slot416, align 8
  %cmp3253 = icmp ne i64 %v3252, 0
  %cv3254 = zext i1 %cmp3253 to i32
  store i32 %cv3254, ptr %slot417, align 8
  %v3255 = load i32, ptr %slot417, align 8
  %cv3256 = zext i32 %v3255 to i64
  %cond3257 = icmp ne i64 %cv3256, 0
  br i1 %cond3257, label %bb_rcgnn484, label %bb_rcgdone484
bb_rcgnn484:
  %v3258 = load i64, ptr %slot416, align 8
  %op3259 = sub i64 %v3258, 16
  store i64 %op3259, ptr %slot418, align 8
  %v3260 = load i64, ptr %slot416, align 8
  %p3261 = inttoptr i64 %v3260 to ptr
  %rgep3262 = getelementptr i8, ptr %p3261, i64 -16
  %ld3263 = load i64, ptr %rgep3262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3263, ptr %slot419, align 8
  %v3264 = load i64, ptr %slot419, align 8
  %op3265 = and i64 %v3264, 4611686018427387906
  store i64 %op3265, ptr %slot420, align 8
  %v3266 = load i64, ptr %slot420, align 8
  %cmp3267 = icmp ne i64 %v3266, 0
  %cv3268 = zext i1 %cmp3267 to i32
  store i32 %cv3268, ptr %slot421, align 8
  %v3269 = load i32, ptr %slot421, align 8
  %cv3270 = zext i32 %v3269 to i64
  %cond3271 = icmp ne i64 %cv3270, 0
  br i1 %cond3271, label %bb_rcgclear484, label %bb_rcgcounted484
bb_rcgcounted484:
  %v3272 = load i64, ptr %slot416, align 8
  %op3273 = sub i64 %v3272, 32
  store i64 %op3273, ptr %slot422, align 8
  %v3274 = load i64, ptr %slot416, align 8
  %p3275 = inttoptr i64 %v3274 to ptr
  %rgep3276 = getelementptr i8, ptr %p3275, i64 -32
  %ld3277 = load i64, ptr %rgep3276, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3277, ptr %slot423, align 8
  %v3278 = load i64, ptr %slot423, align 8
  %op3279 = sub i64 %v3278, 1
  store i64 %op3279, ptr %slot424, align 8
  %v3280 = load i64, ptr %slot424, align 8
  %cmp3281 = icmp eq i64 %v3280, 0
  %cv3282 = zext i1 %cmp3281 to i32
  store i32 %cv3282, ptr %slot425, align 8
  %v3283 = load i32, ptr %slot425, align 8
  %cv3284 = zext i32 %v3283 to i64
  %cond3285 = icmp ne i64 %cv3284, 0
  br i1 %cond3285, label %bb_rcglast484, label %bb_rcgdec484
bb_rcglast484:
  %v3286 = load i64, ptr %slot416, align 8
  %op3287 = sub i64 %v3286, 24
  store i64 %op3287, ptr %slot426, align 8
  %v3288 = load i64, ptr %slot416, align 8
  %p3289 = inttoptr i64 %v3288 to ptr
  %rgep3290 = getelementptr i8, ptr %p3289, i64 -24
  %ld3291 = load i64, ptr %rgep3290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3291, ptr %slot427, align 8
  %v3292 = load i64, ptr %slot427, align 8
  %cmp3293 = icmp ne i64 %v3292, 0
  %cv3294 = zext i1 %cmp3293 to i32
  store i32 %cv3294, ptr %slot428, align 8
  %v3295 = load i32, ptr %slot428, align 8
  %cv3296 = zext i32 %v3295 to i64
  %cond3297 = icmp ne i64 %cv3296, 0
  br i1 %cond3297, label %bb_rcgdec484, label %bb_rcgslow484
bb_rcgslow484:
  %v3298 = load i64, ptr %slot415, align 8
  %v3299 = load i64, ptr %slot414, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3298, i64 %v3299) nomerge, !dbg !138
  br label %bb_rcgdone484
bb_rcgdec484:
  %v3300 = load i64, ptr %slot424, align 8
  %v3301 = load i64, ptr %slot416, align 8
  %p3302 = inttoptr i64 %v3301 to ptr
  %rgep3303 = getelementptr i8, ptr %p3302, i64 -32
  store i64 %v3300, ptr %rgep3303, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear484
bb_rcgclear484:
  %v3304 = load i64, ptr %slot414, align 8
  %p3305 = inttoptr i64 %v3304 to ptr
  store i64 0, ptr %p3305, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone484
bb_rcgdone484:
  %v3306 = load i64, ptr %slot380, align 8
  %p3307 = inttoptr i64 %v3306 to ptr
  store i64 0, ptr %p3307, align 8, !alias.scope !3, !noalias !4
  %v3308 = load i64, ptr %slot380, align 8
  %p3310 = inttoptr i64 %v3308 to ptr
  %gep3311 = getelementptr i8, ptr %p3310, i64 8
  %op3309 = ptrtoint ptr %gep3311 to i64
  store i64 %op3309, ptr %slot429, align 8
  %v3312 = load i64, ptr %slot429, align 8
  %p3313 = inttoptr i64 %v3312 to ptr
  store i64 0, ptr %p3313, align 8, !alias.scope !3, !noalias !4
  %v3314 = load i64, ptr %slot380, align 8
  %p3316 = inttoptr i64 %v3314 to ptr
  %gep3317 = getelementptr i8, ptr %p3316, i64 16
  %op3315 = ptrtoint ptr %gep3317 to i64
  store i64 %op3315, ptr %slot430, align 8
  %v3318 = load i64, ptr %slot430, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  store i64 0, ptr %p3319, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone434
bb_rcslotdone434:
  %v3320 = load i64, ptr %slot47, align 8
  store i64 %v3320, ptr %slot431, align 8
  %v3321 = load i64, ptr %slot31, align 8
  store i64 %v3321, ptr %slot432, align 8
  %v3322 = load i64, ptr %slot432, align 8
  %v3323 = load i64, ptr %slot431, align 8
  %p3324 = inttoptr i64 %v3322 to ptr
  %p3325 = inttoptr i64 %v3323 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3325, ptr %p3324, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3326 = load i64, ptr %slot23, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  store i32 0, ptr %p3327, align 4, !alias.scope !3, !noalias !4
  %v3328 = load i64, ptr %slot12, align 8
  %p3329 = inttoptr i64 %v3328 to ptr
  store i32 2, ptr %p3329, align 4, !alias.scope !3, !noalias !4
  %v3330 = load i64, ptr %slot24, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  %ld3332 = load i32, ptr %p3331, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3332, ptr %slot433, align 8
  %v3333 = load i32, ptr %slot433, align 8
  %v3334 = load i64, ptr %slot12, align 8
  %p3335 = inttoptr i64 %v3334 to ptr
  store i32 %v3333, ptr %p3335, align 4, !alias.scope !3, !noalias !4
  %v3336 = load i64, ptr %slot11, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  store i32 1, ptr %p3337, align 4, !alias.scope !3, !noalias !4
  %v3338 = load i64, ptr %slot45, align 8
  %v3339 = load i64, ptr %slot54, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i64 %v3338, ptr %p3340, align 8, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot54, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %ld3343 = load i64, ptr %p3342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3343, ptr %slot434, align 8
  %v3344 = load i64, ptr %slot17, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  %ld3346 = load i32, ptr %p3345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3346, ptr %slot435, align 8
  %v3347 = load i64, ptr %slot18, align 8
  %p3348 = inttoptr i64 %v3347 to ptr
  %ld3349 = load i32, ptr %p3348, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3349, ptr %slot436, align 8
  %v3350 = load i32, ptr %slot436, align 8
  %op3351 = and i32 %v3350, 24
  store i32 %op3351, ptr %slot436, align 8
  %v3352 = load i32, ptr %slot436, align 8
  %cmp3353 = icmp eq i32 %v3352, 0
  %cv3354 = zext i1 %cmp3353 to i32
  store i32 %cv3354, ptr %slot437, align 8
  %v3355 = load i32, ptr %slot435, align 8
  %v3356 = load i32, ptr %slot437, align 8
  %op3357 = and i32 %v3355, %v3356
  store i32 %op3357, ptr %slot438, align 8
  %v3358 = load i32, ptr %slot438, align 8
  %cv3359 = zext i32 %v3358 to i64
  %cond3360 = icmp ne i64 %cv3359, 0
  br i1 %cond3360, label %bb_rcprivateown504, label %bb_rcprivateloan504
bb_rcprivateown504:
  %v3361 = load i64, ptr %slot31, align 8
  store i64 %v3361, ptr %slot439, align 8
  %v3362 = load i64, ptr %slot67, align 8
  store i64 %v3362, ptr %slot440, align 8
  %v3363 = load i64, ptr %slot66, align 8
  %v3364 = load i64, ptr %slot439, align 8
  %v3365 = load i64, ptr %slot434, align 8
  %v3366 = load i64, ptr %slot440, align 8
  %cv3367 = trunc i64 %v3366 to i32
  %call3368 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v3363, i64 %v3364, i64 %v3365, i32 %cv3367) nomerge, !dbg !140
  store i32 %call3368, ptr %slot441, align 8
  %v3369 = load i32, ptr %slot441, align 8
  %cv3370 = zext i32 %v3369 to i64
  %cond3371 = icmp ne i64 %cv3370, 0
  br i1 %cond3371, label %bb_rcsuccess508, label %bb_rcfailure508
bb_rcfailure508:
  %v3372 = load i64, ptr %slot66, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  %call3374 = call i32 @myl_rc_take_failure(ptr %p3373) nomerge, !dbg !140
  store i32 %call3374, ptr %slot442, align 8
  %v3375 = load i64, ptr %slot1, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  %v3377 = load i32, ptr %slot442, align 8
  %call3378 = call i32 @myl_qbe_rc_status(ptr %p3376, i32 %v3377) nomerge, !dbg !140
  store i32 %call3378, ptr %slot443, align 8
  br label %bb_failure
bb_rcsuccess508:
  %v3379 = load i64, ptr %slot17, align 8
  %p3380 = inttoptr i64 %v3379 to ptr
  store i32 0, ptr %p3380, align 4, !alias.scope !3, !noalias !4
  %v3381 = load i64, ptr %slot24, align 8
  %p3382 = inttoptr i64 %v3381 to ptr
  store i32 2, ptr %p3382, align 4, !alias.scope !3, !noalias !4
  %v3383 = load i64, ptr %slot23, align 8
  %p3384 = inttoptr i64 %v3383 to ptr
  store i32 1, ptr %p3384, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared504
bb_rcprivateloan504:
  %v3385 = load i64, ptr %slot31, align 8
  store i64 %v3385, ptr %slot444, align 8
  %v3386 = load i64, ptr %slot66, align 8
  %v3387 = load i64, ptr %slot444, align 8
  %v3388 = load i64, ptr %slot434, align 8
  %call3389 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v3386, i64 %v3387, i64 %v3388) nomerge, !dbg !140
  store i32 %call3389, ptr %slot445, align 8
  %v3390 = load i32, ptr %slot445, align 8
  %cv3391 = zext i32 %v3390 to i64
  %cond3392 = icmp ne i64 %cv3391, 0
  br i1 %cond3392, label %bb_rcsuccess516, label %bb_rcfailure516
bb_rcfailure516:
  %v3393 = load i64, ptr %slot66, align 8
  %p3394 = inttoptr i64 %v3393 to ptr
  %call3395 = call i32 @myl_rc_take_failure(ptr %p3394) nomerge, !dbg !140
  store i32 %call3395, ptr %slot446, align 8
  %v3396 = load i64, ptr %slot1, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  %v3398 = load i32, ptr %slot446, align 8
  %call3399 = call i32 @myl_qbe_rc_status(ptr %p3397, i32 %v3398) nomerge, !dbg !140
  store i32 %call3399, ptr %slot447, align 8
  br label %bb_failure
bb_rcsuccess516:
  %v3400 = load i64, ptr %slot24, align 8
  %p3401 = inttoptr i64 %v3400 to ptr
  store i32 2, ptr %p3401, align 4, !alias.scope !3, !noalias !4
  %v3402 = load i64, ptr %slot24, align 8
  %p3403 = inttoptr i64 %v3402 to ptr
  store i32 16, ptr %p3403, align 4, !alias.scope !3, !noalias !4
  %v3404 = load i64, ptr %slot23, align 8
  %p3405 = inttoptr i64 %v3404 to ptr
  store i32 1, ptr %p3405, align 4, !alias.scope !3, !noalias !4
  %v3406 = load i64, ptr %slot17, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  %ld3408 = load i32, ptr %p3407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3408, ptr %slot448, align 8
  %v3409 = load i32, ptr %slot448, align 8
  %cv3410 = zext i32 %v3409 to i64
  %cond3411 = icmp ne i64 %cv3410, 0
  br i1 %cond3411, label %bb_rcslotdrop524, label %bb_rcslotdone524
bb_rcslotdrop524:
  %v3412 = load i64, ptr %slot17, align 8
  %p3413 = inttoptr i64 %v3412 to ptr
  store i32 0, ptr %p3413, align 4, !alias.scope !3, !noalias !4
  %v3414 = load i64, ptr %slot26, align 8
  store i64 %v3414, ptr %slot449, align 8
  %v3415 = load i64, ptr %slot18, align 8
  %p3416 = inttoptr i64 %v3415 to ptr
  %ld3417 = load i32, ptr %p3416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3417, ptr %slot450, align 8
  %v3418 = load i32, ptr %slot450, align 8
  %op3419 = and i32 %v3418, 28
  store i32 %op3419, ptr %slot451, align 8
  %v3420 = load i32, ptr %slot451, align 8
  %cv3421 = zext i32 %v3420 to i64
  %cond3422 = icmp ne i64 %cv3421, 0
  br i1 %cond3422, label %bb_rcslotrole524, label %bb_rcslotowner524
bb_rcslotrole524:
  %v3423 = load i64, ptr %slot66, align 8
  store i64 %v3423, ptr %slot452, align 8
  %v3424 = load i64, ptr %slot452, align 8
  %v3425 = load i64, ptr %slot449, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3424, i64 %v3425) nomerge, !dbg !140
  br label %bb_rcslotdone524
bb_rcslotowner524:
  %v3426 = load i64, ptr %slot66, align 8
  store i64 %v3426, ptr %slot453, align 8
  %v3427 = load i64, ptr %slot453, align 8
  %v3428 = load i64, ptr %slot449, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3427, i64 %v3428) nomerge, !dbg !140
  br label %bb_rcslotdone524
bb_rcslotdone524:
  br label %bb_rcprivateprepared504
bb_rcprivateprepared504:
  %v3429 = load i64, ptr %slot9, align 8
  %p3430 = inttoptr i64 %v3429 to ptr
  %ld3431 = load i32, ptr %p3430, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3431, ptr %slot454, align 8
  %v3432 = load i32, ptr %slot454, align 8
  %cv3433 = zext i32 %v3432 to i64
  %cond3434 = icmp ne i64 %cv3433, 0
  br i1 %cond3434, label %bb_rcslotdrop534, label %bb_rcslotdone534
bb_rcslotdrop534:
  %v3435 = load i64, ptr %slot9, align 8
  %p3436 = inttoptr i64 %v3435 to ptr
  store i32 0, ptr %p3436, align 4, !alias.scope !3, !noalias !4
  %v3437 = load i64, ptr %slot46, align 8
  store i64 %v3437, ptr %slot455, align 8
  %v3438 = load i64, ptr %slot10, align 8
  %p3439 = inttoptr i64 %v3438 to ptr
  %ld3440 = load i32, ptr %p3439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3440, ptr %slot456, align 8
  %v3441 = load i32, ptr %slot456, align 8
  %op3442 = and i32 %v3441, 28
  store i32 %op3442, ptr %slot457, align 8
  %v3443 = load i32, ptr %slot457, align 8
  %cv3444 = zext i32 %v3443 to i64
  %cond3445 = icmp ne i64 %cv3444, 0
  br i1 %cond3445, label %bb_rcslotrole534, label %bb_rcslotowner534
bb_rcslotrole534:
  %v3446 = load i64, ptr %slot66, align 8
  store i64 %v3446, ptr %slot458, align 8
  %v3447 = load i64, ptr %slot458, align 8
  %v3448 = load i64, ptr %slot455, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3447, i64 %v3448) nomerge, !dbg !140
  br label %bb_rcslotdone534
bb_rcslotowner534:
  %v3449 = load i64, ptr %slot66, align 8
  store i64 %v3449, ptr %slot459, align 8
  %v3450 = load i64, ptr %slot459, align 8
  %v3451 = load i64, ptr %slot455, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3450, i64 %v3451) nomerge, !dbg !140
  br label %bb_rcslotdone534
bb_rcslotdone534:
  %v3452 = load i64, ptr %slot46, align 8
  store i64 %v3452, ptr %slot460, align 8
  %v3453 = load i64, ptr %slot31, align 8
  store i64 %v3453, ptr %slot461, align 8
  %v3454 = load i64, ptr %slot461, align 8
  %v3455 = load i64, ptr %slot460, align 8
  %p3456 = inttoptr i64 %v3454 to ptr
  %p3457 = inttoptr i64 %v3455 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3457, ptr %p3456, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3458 = load i64, ptr %slot23, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  store i32 0, ptr %p3459, align 4, !alias.scope !3, !noalias !4
  %v3460 = load i64, ptr %slot10, align 8
  %p3461 = inttoptr i64 %v3460 to ptr
  store i32 2, ptr %p3461, align 4, !alias.scope !3, !noalias !4
  %v3462 = load i64, ptr %slot24, align 8
  %p3463 = inttoptr i64 %v3462 to ptr
  %ld3464 = load i32, ptr %p3463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3464, ptr %slot462, align 8
  %v3465 = load i32, ptr %slot462, align 8
  %v3466 = load i64, ptr %slot10, align 8
  %p3467 = inttoptr i64 %v3466 to ptr
  store i32 %v3465, ptr %p3467, align 4, !alias.scope !3, !noalias !4
  %v3468 = load i64, ptr %slot9, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  store i32 1, ptr %p3469, align 4, !alias.scope !3, !noalias !4
  %v3470 = load i64, ptr %slot45, align 8
  %v3471 = load i64, ptr %slot54, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  store i64 %v3470, ptr %p3472, align 8, !alias.scope !3, !noalias !4
  %v3473 = load i64, ptr %slot54, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  %ld3475 = load i64, ptr %p3474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3475, ptr %slot463, align 8
  %v3476 = load i64, ptr %slot17, align 8
  %p3477 = inttoptr i64 %v3476 to ptr
  %ld3478 = load i32, ptr %p3477, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3478, ptr %slot464, align 8
  %v3479 = load i64, ptr %slot18, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  %ld3481 = load i32, ptr %p3480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3481, ptr %slot465, align 8
  %v3482 = load i32, ptr %slot465, align 8
  %op3483 = and i32 %v3482, 24
  store i32 %op3483, ptr %slot465, align 8
  %v3484 = load i32, ptr %slot465, align 8
  %cmp3485 = icmp eq i32 %v3484, 0
  %cv3486 = zext i1 %cmp3485 to i32
  store i32 %cv3486, ptr %slot466, align 8
  %v3487 = load i32, ptr %slot464, align 8
  %v3488 = load i32, ptr %slot466, align 8
  %op3489 = and i32 %v3487, %v3488
  store i32 %op3489, ptr %slot467, align 8
  %v3490 = load i32, ptr %slot467, align 8
  %cv3491 = zext i32 %v3490 to i64
  %cond3492 = icmp ne i64 %cv3491, 0
  br i1 %cond3492, label %bb_rcprivateown555, label %bb_rcprivateloan555
bb_rcprivateown555:
  %v3493 = load i64, ptr %slot31, align 8
  store i64 %v3493, ptr %slot468, align 8
  %v3494 = load i64, ptr %slot67, align 8
  store i64 %v3494, ptr %slot469, align 8
  %v3495 = load i64, ptr %slot66, align 8
  %v3496 = load i64, ptr %slot468, align 8
  %v3497 = load i64, ptr %slot463, align 8
  %v3498 = load i64, ptr %slot469, align 8
  %cv3499 = trunc i64 %v3498 to i32
  %call3500 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v3495, i64 %v3496, i64 %v3497, i32 %cv3499) nomerge, !dbg !142
  store i32 %call3500, ptr %slot470, align 8
  %v3501 = load i32, ptr %slot470, align 8
  %cv3502 = zext i32 %v3501 to i64
  %cond3503 = icmp ne i64 %cv3502, 0
  br i1 %cond3503, label %bb_rcsuccess559, label %bb_rcfailure559
bb_rcfailure559:
  %v3504 = load i64, ptr %slot66, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  %call3506 = call i32 @myl_rc_take_failure(ptr %p3505) nomerge, !dbg !142
  store i32 %call3506, ptr %slot471, align 8
  %v3507 = load i64, ptr %slot1, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %v3509 = load i32, ptr %slot471, align 8
  %call3510 = call i32 @myl_qbe_rc_status(ptr %p3508, i32 %v3509) nomerge, !dbg !142
  store i32 %call3510, ptr %slot472, align 8
  br label %bb_failure
bb_rcsuccess559:
  %v3511 = load i64, ptr %slot17, align 8
  %p3512 = inttoptr i64 %v3511 to ptr
  store i32 0, ptr %p3512, align 4, !alias.scope !3, !noalias !4
  %v3513 = load i64, ptr %slot24, align 8
  %p3514 = inttoptr i64 %v3513 to ptr
  store i32 2, ptr %p3514, align 4, !alias.scope !3, !noalias !4
  %v3515 = load i64, ptr %slot23, align 8
  %p3516 = inttoptr i64 %v3515 to ptr
  store i32 1, ptr %p3516, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared555
bb_rcprivateloan555:
  %v3517 = load i64, ptr %slot31, align 8
  store i64 %v3517, ptr %slot473, align 8
  %v3518 = load i64, ptr %slot66, align 8
  %v3519 = load i64, ptr %slot473, align 8
  %v3520 = load i64, ptr %slot463, align 8
  %call3521 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v3518, i64 %v3519, i64 %v3520) nomerge, !dbg !142
  store i32 %call3521, ptr %slot474, align 8
  %v3522 = load i32, ptr %slot474, align 8
  %cv3523 = zext i32 %v3522 to i64
  %cond3524 = icmp ne i64 %cv3523, 0
  br i1 %cond3524, label %bb_rcsuccess567, label %bb_rcfailure567
bb_rcfailure567:
  %v3525 = load i64, ptr %slot66, align 8
  %p3526 = inttoptr i64 %v3525 to ptr
  %call3527 = call i32 @myl_rc_take_failure(ptr %p3526) nomerge, !dbg !142
  store i32 %call3527, ptr %slot475, align 8
  %v3528 = load i64, ptr %slot1, align 8
  %p3529 = inttoptr i64 %v3528 to ptr
  %v3530 = load i32, ptr %slot475, align 8
  %call3531 = call i32 @myl_qbe_rc_status(ptr %p3529, i32 %v3530) nomerge, !dbg !142
  store i32 %call3531, ptr %slot476, align 8
  br label %bb_failure
bb_rcsuccess567:
  %v3532 = load i64, ptr %slot24, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  store i32 2, ptr %p3533, align 4, !alias.scope !3, !noalias !4
  %v3534 = load i64, ptr %slot24, align 8
  %p3535 = inttoptr i64 %v3534 to ptr
  store i32 16, ptr %p3535, align 4, !alias.scope !3, !noalias !4
  %v3536 = load i64, ptr %slot23, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  store i32 1, ptr %p3537, align 4, !alias.scope !3, !noalias !4
  %v3538 = load i64, ptr %slot17, align 8
  %p3539 = inttoptr i64 %v3538 to ptr
  %ld3540 = load i32, ptr %p3539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3540, ptr %slot477, align 8
  %v3541 = load i32, ptr %slot477, align 8
  %cv3542 = zext i32 %v3541 to i64
  %cond3543 = icmp ne i64 %cv3542, 0
  br i1 %cond3543, label %bb_rcslotdrop575, label %bb_rcslotdone575
bb_rcslotdrop575:
  %v3544 = load i64, ptr %slot17, align 8
  %p3545 = inttoptr i64 %v3544 to ptr
  store i32 0, ptr %p3545, align 4, !alias.scope !3, !noalias !4
  %v3546 = load i64, ptr %slot26, align 8
  store i64 %v3546, ptr %slot478, align 8
  %v3547 = load i64, ptr %slot18, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  %ld3549 = load i32, ptr %p3548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3549, ptr %slot479, align 8
  %v3550 = load i32, ptr %slot479, align 8
  %op3551 = and i32 %v3550, 28
  store i32 %op3551, ptr %slot480, align 8
  %v3552 = load i32, ptr %slot480, align 8
  %cv3553 = zext i32 %v3552 to i64
  %cond3554 = icmp ne i64 %cv3553, 0
  br i1 %cond3554, label %bb_rcslotrole575, label %bb_rcslotowner575
bb_rcslotrole575:
  %v3555 = load i64, ptr %slot66, align 8
  store i64 %v3555, ptr %slot481, align 8
  %v3556 = load i64, ptr %slot481, align 8
  %v3557 = load i64, ptr %slot478, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3556, i64 %v3557) nomerge, !dbg !142
  br label %bb_rcslotdone575
bb_rcslotowner575:
  %v3558 = load i64, ptr %slot66, align 8
  store i64 %v3558, ptr %slot482, align 8
  %v3559 = load i64, ptr %slot482, align 8
  %v3560 = load i64, ptr %slot478, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3559, i64 %v3560) nomerge, !dbg !142
  br label %bb_rcslotdone575
bb_rcslotdone575:
  br label %bb_rcprivateprepared555
bb_rcprivateprepared555:
  %v3561 = load i64, ptr %slot9, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  %ld3563 = load i32, ptr %p3562, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3563, ptr %slot483, align 8
  %v3564 = load i32, ptr %slot483, align 8
  %cv3565 = zext i32 %v3564 to i64
  %cond3566 = icmp ne i64 %cv3565, 0
  br i1 %cond3566, label %bb_rcslotdrop585, label %bb_rcslotdone585
bb_rcslotdrop585:
  %v3567 = load i64, ptr %slot9, align 8
  %p3568 = inttoptr i64 %v3567 to ptr
  store i32 0, ptr %p3568, align 4, !alias.scope !3, !noalias !4
  %v3569 = load i64, ptr %slot46, align 8
  store i64 %v3569, ptr %slot484, align 8
  %v3570 = load i64, ptr %slot10, align 8
  %p3571 = inttoptr i64 %v3570 to ptr
  %ld3572 = load i32, ptr %p3571, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3572, ptr %slot485, align 8
  %v3573 = load i32, ptr %slot485, align 8
  %op3574 = and i32 %v3573, 28
  store i32 %op3574, ptr %slot486, align 8
  %v3575 = load i32, ptr %slot486, align 8
  %cv3576 = zext i32 %v3575 to i64
  %cond3577 = icmp ne i64 %cv3576, 0
  br i1 %cond3577, label %bb_rcslotrole585, label %bb_rcslotowner585
bb_rcslotrole585:
  %v3578 = load i64, ptr %slot66, align 8
  store i64 %v3578, ptr %slot487, align 8
  %v3579 = load i64, ptr %slot487, align 8
  %v3580 = load i64, ptr %slot484, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3579, i64 %v3580) nomerge, !dbg !142
  br label %bb_rcslotdone585
bb_rcslotowner585:
  %v3581 = load i64, ptr %slot66, align 8
  store i64 %v3581, ptr %slot488, align 8
  %v3582 = load i64, ptr %slot488, align 8
  %v3583 = load i64, ptr %slot484, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3582, i64 %v3583) nomerge, !dbg !142
  br label %bb_rcslotdone585
bb_rcslotdone585:
  %v3584 = load i64, ptr %slot46, align 8
  store i64 %v3584, ptr %slot489, align 8
  %v3585 = load i64, ptr %slot31, align 8
  store i64 %v3585, ptr %slot490, align 8
  %v3586 = load i64, ptr %slot490, align 8
  %v3587 = load i64, ptr %slot489, align 8
  %p3588 = inttoptr i64 %v3586 to ptr
  %p3589 = inttoptr i64 %v3587 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3589, ptr %p3588, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v3590 = load i64, ptr %slot23, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  store i32 0, ptr %p3591, align 4, !alias.scope !3, !noalias !4
  %v3592 = load i64, ptr %slot10, align 8
  %p3593 = inttoptr i64 %v3592 to ptr
  store i32 2, ptr %p3593, align 4, !alias.scope !3, !noalias !4
  %v3594 = load i64, ptr %slot24, align 8
  %p3595 = inttoptr i64 %v3594 to ptr
  %ld3596 = load i32, ptr %p3595, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3596, ptr %slot491, align 8
  %v3597 = load i32, ptr %slot491, align 8
  %v3598 = load i64, ptr %slot10, align 8
  %p3599 = inttoptr i64 %v3598 to ptr
  store i32 %v3597, ptr %p3599, align 4, !alias.scope !3, !noalias !4
  %v3600 = load i64, ptr %slot9, align 8
  %p3601 = inttoptr i64 %v3600 to ptr
  store i32 1, ptr %p3601, align 4, !alias.scope !3, !noalias !4
  %v3602 = load i64, ptr %slot46, align 8
  %v3603 = load i64, ptr %slot54, align 8
  %p3604 = inttoptr i64 %v3603 to ptr
  store i64 %v3602, ptr %p3604, align 8, !alias.scope !3, !noalias !4
  %v3605 = load i64, ptr %slot46, align 8
  %v3606 = load i64, ptr %slot55, align 8
  %p3607 = inttoptr i64 %v3606 to ptr
  store i64 %v3605, ptr %p3607, align 8, !alias.scope !3, !noalias !4
  %v3608 = load i64, ptr %slot55, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  %ld3610 = load i64, ptr %p3609, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3610, ptr %slot492, align 8
  %v3611 = load i64, ptr %slot492, align 8
  %op3612 = add i64 %v3611, 0
  store i64 %op3612, ptr %slot493, align 8
  %v3613 = load i64, ptr %slot493, align 8
  %v3614 = load i64, ptr %slot55, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  store i64 %v3613, ptr %p3615, align 8, !alias.scope !3, !noalias !4
  %v3616 = load i64, ptr %slot55, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  %ld3618 = load i64, ptr %p3617, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3618, ptr %slot494, align 8
  %v3619 = load i64, ptr %slot31, align 8
  store i64 %v3619, ptr %slot495, align 8
  %v3620 = load i64, ptr %slot66, align 8
  %v3621 = load i64, ptr %slot495, align 8
  %v3622 = load i64, ptr %slot494, align 8
  %call3623 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64 %v3620, i64 %v3621, i64 %v3622) nomerge, !dbg !144
  store i32 %call3623, ptr %slot496, align 8
  %v3624 = load i32, ptr %slot496, align 8
  %cv3625 = zext i32 %v3624 to i64
  %cond3626 = icmp ne i64 %cv3625, 0
  br i1 %cond3626, label %bb_rcsuccess604, label %bb_rcfailure604
bb_rcfailure604:
  %v3627 = load i64, ptr %slot66, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  %call3629 = call i32 @myl_rc_take_failure(ptr %p3628) nomerge, !dbg !144
  store i32 %call3629, ptr %slot497, align 8
  %v3630 = load i64, ptr %slot1, align 8
  %p3631 = inttoptr i64 %v3630 to ptr
  %v3632 = load i32, ptr %slot497, align 8
  %call3633 = call i32 @myl_qbe_rc_status(ptr %p3631, i32 %v3632) nomerge, !dbg !144
  store i32 %call3633, ptr %slot498, align 8
  br label %bb_failure
bb_rcsuccess604:
  %v3634 = load i64, ptr %slot24, align 8
  %p3635 = inttoptr i64 %v3634 to ptr
  store i32 2, ptr %p3635, align 4, !alias.scope !3, !noalias !4
  %v3636 = load i64, ptr %slot24, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  store i32 16, ptr %p3637, align 4, !alias.scope !3, !noalias !4
  %v3638 = load i64, ptr %slot23, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  store i32 1, ptr %p3639, align 4, !alias.scope !3, !noalias !4
  %v3640 = load i64, ptr %slot19, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %ld3642 = load i32, ptr %p3641, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3642, ptr %slot499, align 8
  %v3643 = load i32, ptr %slot499, align 8
  %cv3644 = zext i32 %v3643 to i64
  %cond3645 = icmp ne i64 %cv3644, 0
  br i1 %cond3645, label %bb_rcslotdrop612, label %bb_rcslotdone612
bb_rcslotdrop612:
  %v3646 = load i64, ptr %slot19, align 8
  %p3647 = inttoptr i64 %v3646 to ptr
  store i32 0, ptr %p3647, align 4, !alias.scope !3, !noalias !4
  %v3648 = load i64, ptr %slot27, align 8
  store i64 %v3648, ptr %slot500, align 8
  %v3649 = load i64, ptr %slot20, align 8
  %p3650 = inttoptr i64 %v3649 to ptr
  %ld3651 = load i32, ptr %p3650, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3651, ptr %slot501, align 8
  %v3652 = load i32, ptr %slot501, align 8
  %op3653 = and i32 %v3652, 28
  store i32 %op3653, ptr %slot502, align 8
  %v3654 = load i32, ptr %slot502, align 8
  %cv3655 = zext i32 %v3654 to i64
  %cond3656 = icmp ne i64 %cv3655, 0
  br i1 %cond3656, label %bb_rcslotrole612, label %bb_rcslotowner612
bb_rcslotrole612:
  %v3657 = load i64, ptr %slot66, align 8
  store i64 %v3657, ptr %slot503, align 8
  %v3658 = load i64, ptr %slot503, align 8
  %v3659 = load i64, ptr %slot500, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3658, i64 %v3659) nomerge, !dbg !144
  br label %bb_rcslotdone612
bb_rcslotowner612:
  %v3660 = load i64, ptr %slot66, align 8
  store i64 %v3660, ptr %slot504, align 8
  %v3661 = load i64, ptr %slot504, align 8
  %v3662 = load i64, ptr %slot500, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3661, i64 %v3662) nomerge, !dbg !144
  br label %bb_rcslotdone612
bb_rcslotdone612:
  %v3663 = load i64, ptr %slot27, align 8
  store i64 %v3663, ptr %slot505, align 8
  %v3664 = load i64, ptr %slot31, align 8
  store i64 %v3664, ptr %slot506, align 8
  %v3665 = load i64, ptr %slot506, align 8
  %v3666 = load i64, ptr %slot505, align 8
  %p3667 = inttoptr i64 %v3665 to ptr
  %p3668 = inttoptr i64 %v3666 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3668, ptr %p3667, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3669 = load i64, ptr %slot20, align 8
  %p3670 = inttoptr i64 %v3669 to ptr
  store i32 2, ptr %p3670, align 4, !alias.scope !3, !noalias !4
  %v3671 = load i64, ptr %slot24, align 8
  %p3672 = inttoptr i64 %v3671 to ptr
  %ld3673 = load i32, ptr %p3672, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3673, ptr %slot507, align 8
  %v3674 = load i32, ptr %slot507, align 8
  %v3675 = load i64, ptr %slot20, align 8
  %p3676 = inttoptr i64 %v3675 to ptr
  store i32 %v3674, ptr %p3676, align 4, !alias.scope !3, !noalias !4
  %v3677 = load i64, ptr %slot23, align 8
  %p3678 = inttoptr i64 %v3677 to ptr
  store i32 0, ptr %p3678, align 4, !alias.scope !3, !noalias !4
  %v3679 = load i64, ptr %slot19, align 8
  %p3680 = inttoptr i64 %v3679 to ptr
  store i32 1, ptr %p3680, align 4, !alias.scope !3, !noalias !4
  %v3681 = load i64, ptr %slot505, align 8
  %v3682 = load i64, ptr %slot55, align 8
  %p3683 = inttoptr i64 %v3682 to ptr
  store i64 %v3681, ptr %p3683, align 8, !alias.scope !3, !noalias !4
  %v3684 = load i64, ptr %slot47, align 8
  %v3685 = load i64, ptr %slot56, align 8
  %p3686 = inttoptr i64 %v3685 to ptr
  store i64 %v3684, ptr %p3686, align 8, !alias.scope !3, !noalias !4
  %v3687 = load i64, ptr %slot56, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %ld3689 = load i64, ptr %p3688, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3689, ptr %slot508, align 8
  %v3690 = load i64, ptr %slot21, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  %ld3692 = load i32, ptr %p3691, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3692, ptr %slot509, align 8
  %v3693 = load i64, ptr %slot22, align 8
  %p3694 = inttoptr i64 %v3693 to ptr
  %ld3695 = load i32, ptr %p3694, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3695, ptr %slot510, align 8
  %v3696 = load i32, ptr %slot510, align 8
  %op3697 = and i32 %v3696, 24
  store i32 %op3697, ptr %slot510, align 8
  %v3698 = load i32, ptr %slot510, align 8
  %cmp3699 = icmp eq i32 %v3698, 0
  %cv3700 = zext i1 %cmp3699 to i32
  store i32 %cv3700, ptr %slot511, align 8
  %v3701 = load i32, ptr %slot509, align 8
  %v3702 = load i32, ptr %slot511, align 8
  %op3703 = and i32 %v3701, %v3702
  store i32 %op3703, ptr %slot512, align 8
  %v3704 = load i64, ptr %slot67, align 8
  store i64 %v3704, ptr %slot513, align 8
  %v3705 = load i32, ptr %slot512, align 8
  %op3706 = mul i32 %v3705, 4
  store i32 %op3706, ptr %slot514, align 8
  %v3707 = load i32, ptr %slot514, align 8
  %op3708 = or i32 %v3707, 0
  store i32 %op3708, ptr %slot515, align 8
  %v3709 = load i64, ptr %slot31, align 8
  store i64 %v3709, ptr %slot516, align 8
  %v3710 = load i64, ptr %slot66, align 8
  %v3711 = load i64, ptr %slot516, align 8
  %v3712 = load i64, ptr %slot508, align 8
  %v3713 = load i64, ptr %slot513, align 8
  %cv3714 = trunc i64 %v3713 to i32
  %v3715 = load i32, ptr %slot515, align 8
  %call3716 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_publish(i64 %v3710, i64 %v3711, i64 %v3712, i32 %cv3714, i32 %v3715) nomerge, !dbg !146
  store i32 %call3716, ptr %slot517, align 8
  %v3717 = load i32, ptr %slot517, align 8
  %cv3718 = zext i32 %v3717 to i64
  %cond3719 = icmp ne i64 %cv3718, 0
  br i1 %cond3719, label %bb_rcsuccess641, label %bb_rcfailure641
bb_rcfailure641:
  %v3720 = load i64, ptr %slot66, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  %call3722 = call i32 @myl_rc_take_failure(ptr %p3721) nomerge, !dbg !146
  store i32 %call3722, ptr %slot518, align 8
  %v3723 = load i64, ptr %slot1, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %v3725 = load i32, ptr %slot518, align 8
  %call3726 = call i32 @myl_qbe_rc_status(ptr %p3724, i32 %v3725) nomerge, !dbg !146
  store i32 %call3726, ptr %slot519, align 8
  br label %bb_failure
bb_rcsuccess641:
  %v3727 = load i32, ptr %slot512, align 8
  %cv3728 = zext i32 %v3727 to i64
  %cond3729 = icmp ne i64 %cv3728, 0
  br i1 %cond3729, label %bb_rchtaken644, label %bb_rchcopied644
bb_rchcopied644:
  %v3730 = load i64, ptr %slot21, align 8
  %p3731 = inttoptr i64 %v3730 to ptr
  %ld3732 = load i32, ptr %p3731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3732, ptr %slot520, align 8
  %v3733 = load i32, ptr %slot520, align 8
  %cv3734 = zext i32 %v3733 to i64
  %cond3735 = icmp ne i64 %cv3734, 0
  br i1 %cond3735, label %bb_rcslotdrop647, label %bb_rcslotdone647
bb_rcslotdrop647:
  %v3736 = load i64, ptr %slot21, align 8
  %p3737 = inttoptr i64 %v3736 to ptr
  store i32 0, ptr %p3737, align 4, !alias.scope !3, !noalias !4
  %v3738 = load i64, ptr %slot28, align 8
  store i64 %v3738, ptr %slot521, align 8
  %v3739 = load i64, ptr %slot22, align 8
  %p3740 = inttoptr i64 %v3739 to ptr
  %ld3741 = load i32, ptr %p3740, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3741, ptr %slot522, align 8
  %v3742 = load i32, ptr %slot522, align 8
  %op3743 = and i32 %v3742, 28
  store i32 %op3743, ptr %slot523, align 8
  %v3744 = load i32, ptr %slot523, align 8
  %cv3745 = zext i32 %v3744 to i64
  %cond3746 = icmp ne i64 %cv3745, 0
  br i1 %cond3746, label %bb_rcslotrole647, label %bb_rcslotowner647
bb_rcslotrole647:
  %v3747 = load i64, ptr %slot66, align 8
  store i64 %v3747, ptr %slot524, align 8
  %v3748 = load i64, ptr %slot524, align 8
  %v3749 = load i64, ptr %slot521, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v3748, i64 %v3749) nomerge, !dbg !146
  br label %bb_rcslotdone647
bb_rcslotowner647:
  %v3750 = load i64, ptr %slot66, align 8
  store i64 %v3750, ptr %slot525, align 8
  %v3751 = load i64, ptr %slot525, align 8
  %v3752 = load i64, ptr %slot521, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v3751, i64 %v3752) nomerge, !dbg !146
  br label %bb_rcslotdone647
bb_rcslotdone647:
  br label %bb_rchprepared644
bb_rchtaken644:
  %v3753 = load i64, ptr %slot21, align 8
  %p3754 = inttoptr i64 %v3753 to ptr
  store i32 0, ptr %p3754, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared644
bb_rchprepared644:
  %v3755 = load i64, ptr %slot24, align 8
  %p3756 = inttoptr i64 %v3755 to ptr
  store i32 2, ptr %p3756, align 4, !alias.scope !3, !noalias !4
  %v3757 = load i64, ptr %slot23, align 8
  %p3758 = inttoptr i64 %v3757 to ptr
  store i32 1, ptr %p3758, align 4, !alias.scope !3, !noalias !4
  %v3759 = load i64, ptr %slot28, align 8
  store i64 %v3759, ptr %slot526, align 8
  %v3760 = load i64, ptr %slot31, align 8
  store i64 %v3760, ptr %slot527, align 8
  %v3761 = load i64, ptr %slot527, align 8
  %v3762 = load i64, ptr %slot526, align 8
  %p3763 = inttoptr i64 %v3761 to ptr
  %p3764 = inttoptr i64 %v3762 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3764, ptr %p3763, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3765 = load i64, ptr %slot22, align 8
  %p3766 = inttoptr i64 %v3765 to ptr
  store i32 2, ptr %p3766, align 4, !alias.scope !3, !noalias !4
  %v3767 = load i64, ptr %slot24, align 8
  %p3768 = inttoptr i64 %v3767 to ptr
  %ld3769 = load i32, ptr %p3768, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3769, ptr %slot528, align 8
  %v3770 = load i32, ptr %slot528, align 8
  %v3771 = load i64, ptr %slot22, align 8
  %p3772 = inttoptr i64 %v3771 to ptr
  store i32 %v3770, ptr %p3772, align 4, !alias.scope !3, !noalias !4
  %v3773 = load i64, ptr %slot23, align 8
  %p3774 = inttoptr i64 %v3773 to ptr
  store i32 0, ptr %p3774, align 4, !alias.scope !3, !noalias !4
  %v3775 = load i64, ptr %slot21, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  store i32 1, ptr %p3776, align 4, !alias.scope !3, !noalias !4
  %v3777 = load i64, ptr %slot526, align 8
  %v3778 = load i64, ptr %slot56, align 8
  %p3779 = inttoptr i64 %v3778 to ptr
  store i64 %v3777, ptr %p3779, align 8, !alias.scope !3, !noalias !4
  %v3780 = load i64, ptr %slot55, align 8
  %p3781 = inttoptr i64 %v3780 to ptr
  %ld3782 = load i64, ptr %p3781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3782, ptr %slot529, align 8
  %v3783 = load i64, ptr %slot19, align 8
  %p3784 = inttoptr i64 %v3783 to ptr
  %ld3785 = load i32, ptr %p3784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3785, ptr %slot530, align 8
  %v3786 = load i64, ptr %slot20, align 8
  %p3787 = inttoptr i64 %v3786 to ptr
  %ld3788 = load i32, ptr %p3787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3788, ptr %slot531, align 8
  %v3789 = load i32, ptr %slot531, align 8
  %op3790 = and i32 %v3789, 24
  store i32 %op3790, ptr %slot531, align 8
  %v3791 = load i32, ptr %slot531, align 8
  %cmp3792 = icmp eq i32 %v3791, 0
  %cv3793 = zext i1 %cmp3792 to i32
  store i32 %cv3793, ptr %slot532, align 8
  %v3794 = load i32, ptr %slot530, align 8
  %v3795 = load i32, ptr %slot532, align 8
  %op3796 = and i32 %v3794, %v3795
  store i32 %op3796, ptr %slot533, align 8
  %v3797 = load i32, ptr %slot533, align 8
  %cv3798 = zext i32 %v3797 to i64
  %cond3799 = icmp ne i64 %cv3798, 0
  br i1 %cond3799, label %bb_rctake666, label %bb_rccopy666
bb_rctake666:
  %v3800 = load i64, ptr %slot31, align 8
  store i64 %v3800, ptr %slot534, align 8
  %v3801 = load i64, ptr %slot67, align 8
  store i64 %v3801, ptr %slot535, align 8
  %v3802 = load i64, ptr %slot529, align 8
  %v3803 = load i64, ptr %slot534, align 8
  %op3804 = sub i64 %v3802, %v3803
  store i64 %op3804, ptr %slot536, align 8
  %v3805 = load i64, ptr %slot534, align 8
  %v3806 = load i64, ptr %slot529, align 8
  %op3807 = sub i64 %v3805, %v3806
  store i64 %op3807, ptr %slot537, align 8
  %v3808 = load i64, ptr %slot536, align 8
  %cmp3809 = icmp ult i64 %v3808, 48
  %cv3810 = zext i1 %cmp3809 to i32
  store i32 %cv3810, ptr %slot538, align 8
  %v3811 = load i64, ptr %slot537, align 8
  %cmp3812 = icmp ult i64 %v3811, 48
  %cv3813 = zext i1 %cmp3812 to i32
  store i32 %cv3813, ptr %slot539, align 8
  %v3814 = load i32, ptr %slot538, align 8
  %v3815 = load i32, ptr %slot539, align 8
  %op3816 = or i32 %v3814, %v3815
  store i32 %op3816, ptr %slot540, align 8
  %v3817 = load i32, ptr %slot540, align 8
  %cv3818 = zext i32 %v3817 to i64
  %cond3819 = icmp ne i64 %cv3818, 0
  br i1 %cond3819, label %bb_rcmoveslow675, label %bb_rcmovecheck675
bb_rcmovecheck675:
  %v3820 = load i64, ptr %slot529, align 8
  %op3821 = add i64 %v3820, 16
  store i64 %op3821, ptr %slot541, align 8
  %v3822 = load i64, ptr %slot541, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %ld3824 = load i64, ptr %p3823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3824, ptr %slot542, align 8
  %v3825 = load i64, ptr %slot542, align 8
  %cmp3826 = icmp ne i64 %v3825, 0
  %cv3827 = zext i1 %cmp3826 to i32
  store i32 %cv3827, ptr %slot543, align 8
  %v3828 = load i32, ptr %slot543, align 8
  %cv3829 = zext i32 %v3828 to i64
  %cond3830 = icmp ne i64 %cv3829, 0
  br i1 %cond3830, label %bb_rcmoveheader683, label %bb_rcmovenext683
bb_rcmoveheader683:
  %v3831 = load i64, ptr %slot542, align 8
  %op3832 = sub i64 %v3831, 16
  store i64 %op3832, ptr %slot544, align 8
  %v3833 = load i64, ptr %slot542, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  %rgep3835 = getelementptr i8, ptr %p3834, i64 -16
  %ld3836 = load i64, ptr %rgep3835, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3836, ptr %slot545, align 8
  %v3837 = load i64, ptr %slot545, align 8
  %op3838 = and i64 %v3837, 5764607523034234881
  store i64 %op3838, ptr %slot546, align 8
  %v3839 = load i64, ptr %slot546, align 8
  %cmp3840 = icmp ne i64 %v3839, 0
  %cv3841 = zext i1 %cmp3840 to i32
  store i32 %cv3841, ptr %slot547, align 8
  %v3842 = load i32, ptr %slot547, align 8
  %cv3843 = zext i32 %v3842 to i64
  %cond3844 = icmp ne i64 %cv3843, 0
  br i1 %cond3844, label %bb_rcmoveslow675, label %bb_rcmovenext683
bb_rcmovenext683:
  %v3845 = load i64, ptr %slot529, align 8
  %op3846 = add i64 %v3845, 24
  store i64 %op3846, ptr %slot548, align 8
  %v3847 = load i64, ptr %slot548, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  %ld3849 = load i64, ptr %p3848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3849, ptr %slot549, align 8
  %v3850 = load i64, ptr %slot549, align 8
  %cmp3851 = icmp ne i64 %v3850, 0
  %cv3852 = zext i1 %cmp3851 to i32
  store i32 %cv3852, ptr %slot550, align 8
  %v3853 = load i32, ptr %slot550, align 8
  %cv3854 = zext i32 %v3853 to i64
  %cond3855 = icmp ne i64 %cv3854, 0
  br i1 %cond3855, label %bb_rcmoveheader691, label %bb_rcmovenext691
bb_rcmoveheader691:
  %v3856 = load i64, ptr %slot549, align 8
  %op3857 = sub i64 %v3856, 16
  store i64 %op3857, ptr %slot551, align 8
  %v3858 = load i64, ptr %slot549, align 8
  %p3859 = inttoptr i64 %v3858 to ptr
  %rgep3860 = getelementptr i8, ptr %p3859, i64 -16
  %ld3861 = load i64, ptr %rgep3860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3861, ptr %slot552, align 8
  %v3862 = load i64, ptr %slot552, align 8
  %op3863 = and i64 %v3862, 5764607523034234881
  store i64 %op3863, ptr %slot553, align 8
  %v3864 = load i64, ptr %slot553, align 8
  %cmp3865 = icmp ne i64 %v3864, 0
  %cv3866 = zext i1 %cmp3865 to i32
  store i32 %cv3866, ptr %slot554, align 8
  %v3867 = load i32, ptr %slot554, align 8
  %cv3868 = zext i32 %v3867 to i64
  %cond3869 = icmp ne i64 %cv3868, 0
  br i1 %cond3869, label %bb_rcmoveslow675, label %bb_rcmovenext691
bb_rcmovenext691:
  %v3870 = load i64, ptr %slot529, align 8
  %op3871 = add i64 %v3870, 32
  store i64 %op3871, ptr %slot555, align 8
  %v3872 = load i64, ptr %slot555, align 8
  %p3873 = inttoptr i64 %v3872 to ptr
  %ld3874 = load i64, ptr %p3873, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3874, ptr %slot556, align 8
  %v3875 = load i64, ptr %slot556, align 8
  %cmp3876 = icmp ne i64 %v3875, 0
  %cv3877 = zext i1 %cmp3876 to i32
  store i32 %cv3877, ptr %slot557, align 8
  %v3878 = load i32, ptr %slot557, align 8
  %cv3879 = zext i32 %v3878 to i64
  %cond3880 = icmp ne i64 %cv3879, 0
  br i1 %cond3880, label %bb_rcmoveheader699, label %bb_rcmovenext699
bb_rcmoveheader699:
  %v3881 = load i64, ptr %slot556, align 8
  %op3882 = sub i64 %v3881, 16
  store i64 %op3882, ptr %slot558, align 8
  %v3883 = load i64, ptr %slot556, align 8
  %p3884 = inttoptr i64 %v3883 to ptr
  %rgep3885 = getelementptr i8, ptr %p3884, i64 -16
  %ld3886 = load i64, ptr %rgep3885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3886, ptr %slot559, align 8
  %v3887 = load i64, ptr %slot559, align 8
  %op3888 = and i64 %v3887, 5764607523034234881
  store i64 %op3888, ptr %slot560, align 8
  %v3889 = load i64, ptr %slot560, align 8
  %cmp3890 = icmp ne i64 %v3889, 0
  %cv3891 = zext i1 %cmp3890 to i32
  store i32 %cv3891, ptr %slot561, align 8
  %v3892 = load i32, ptr %slot561, align 8
  %cv3893 = zext i32 %v3892 to i64
  %cond3894 = icmp ne i64 %cv3893, 0
  br i1 %cond3894, label %bb_rcmoveslow675, label %bb_rcmovenext699
bb_rcmovenext699:
  %v3895 = load i64, ptr %slot529, align 8
  %v3896 = load i64, ptr %slot534, align 8
  %p3897 = inttoptr i64 %v3895 to ptr
  %p3898 = inttoptr i64 %v3896 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3898, ptr %p3897, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3899 = load i64, ptr %slot529, align 8
  %p3900 = inttoptr i64 %v3899 to ptr
  store i64 0, ptr %p3900, align 8, !alias.scope !3, !noalias !4
  %v3901 = load i64, ptr %slot529, align 8
  %op3902 = add i64 %v3901, 8
  store i64 %op3902, ptr %slot562, align 8
  %v3903 = load i64, ptr %slot562, align 8
  %p3904 = inttoptr i64 %v3903 to ptr
  store i64 0, ptr %p3904, align 8, !alias.scope !3, !noalias !4
  %v3905 = load i64, ptr %slot529, align 8
  %op3906 = add i64 %v3905, 16
  store i64 %op3906, ptr %slot563, align 8
  %v3907 = load i64, ptr %slot563, align 8
  %p3908 = inttoptr i64 %v3907 to ptr
  store i64 0, ptr %p3908, align 8, !alias.scope !3, !noalias !4
  %v3909 = load i64, ptr %slot529, align 8
  %op3910 = add i64 %v3909, 24
  store i64 %op3910, ptr %slot564, align 8
  %v3911 = load i64, ptr %slot564, align 8
  %p3912 = inttoptr i64 %v3911 to ptr
  store i64 0, ptr %p3912, align 8, !alias.scope !3, !noalias !4
  %v3913 = load i64, ptr %slot529, align 8
  %op3914 = add i64 %v3913, 32
  store i64 %op3914, ptr %slot565, align 8
  %v3915 = load i64, ptr %slot565, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  store i64 0, ptr %p3916, align 8, !alias.scope !3, !noalias !4
  %v3917 = load i64, ptr %slot529, align 8
  %op3918 = add i64 %v3917, 40
  store i64 %op3918, ptr %slot566, align 8
  %v3919 = load i64, ptr %slot566, align 8
  %p3920 = inttoptr i64 %v3919 to ptr
  store i64 0, ptr %p3920, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved675
bb_rcmoveslow675:
  %v3921 = load i64, ptr %slot66, align 8
  %v3922 = load i64, ptr %slot534, align 8
  %v3923 = load i64, ptr %slot529, align 8
  %v3924 = load i64, ptr %slot535, align 8
  %cv3925 = trunc i64 %v3924 to i32
  %call3926 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v3921, i64 %v3922, i64 %v3923, i32 %cv3925) nomerge, !dbg !148
  store i32 %call3926, ptr %slot567, align 8
  %v3927 = load i32, ptr %slot567, align 8
  %cv3928 = zext i32 %v3927 to i64
  %cond3929 = icmp ne i64 %cv3928, 0
  br i1 %cond3929, label %bb_rcsuccess711, label %bb_rcfailure711
bb_rcfailure711:
  %v3930 = load i64, ptr %slot66, align 8
  %p3931 = inttoptr i64 %v3930 to ptr
  %call3932 = call i32 @myl_rc_take_failure(ptr %p3931) nomerge, !dbg !148
  store i32 %call3932, ptr %slot568, align 8
  %v3933 = load i64, ptr %slot1, align 8
  %p3934 = inttoptr i64 %v3933 to ptr
  %v3935 = load i32, ptr %slot568, align 8
  %call3936 = call i32 @myl_qbe_rc_status(ptr %p3934, i32 %v3935) nomerge, !dbg !148
  store i32 %call3936, ptr %slot569, align 8
  br label %bb_failure
bb_rcsuccess711:
  br label %bb_rcmoved675
bb_rcmoved675:
  %v3937 = load i64, ptr %slot19, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  store i32 0, ptr %p3938, align 4, !alias.scope !3, !noalias !4
  %v3939 = load i64, ptr %slot24, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  store i32 2, ptr %p3940, align 4, !alias.scope !3, !noalias !4
  %v3941 = load i64, ptr %slot23, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  store i32 1, ptr %p3942, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared666
bb_rccopy666:
  %v3943 = load i64, ptr %slot31, align 8
  store i64 %v3943, ptr %slot570, align 8
  %v3944 = load i64, ptr %slot67, align 8
  store i64 %v3944, ptr %slot571, align 8
  %v3945 = load i64, ptr %slot66, align 8
  %v3946 = load i64, ptr %slot570, align 8
  %v3947 = load i64, ptr %slot529, align 8
  %v3948 = load i64, ptr %slot571, align 8
  %cv3949 = trunc i64 %v3948 to i32
  %call3950 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64 %v3945, i64 %v3946, i64 %v3947, i32 %cv3949) nomerge, !dbg !148
  store i32 %call3950, ptr %slot572, align 8
  %v3951 = load i32, ptr %slot572, align 8
  %cv3952 = zext i32 %v3951 to i64
  %cond3953 = icmp ne i64 %cv3952, 0
  br i1 %cond3953, label %bb_rcsuccess720, label %bb_rcfailure720
bb_rcfailure720:
  %v3954 = load i64, ptr %slot66, align 8
  %p3955 = inttoptr i64 %v3954 to ptr
  %call3956 = call i32 @myl_rc_take_failure(ptr %p3955) nomerge, !dbg !148
  store i32 %call3956, ptr %slot573, align 8
  %v3957 = load i64, ptr %slot1, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  %v3959 = load i32, ptr %slot573, align 8
  %call3960 = call i32 @myl_qbe_rc_status(ptr %p3958, i32 %v3959) nomerge, !dbg !148
  store i32 %call3960, ptr %slot574, align 8
  br label %bb_failure
bb_rcsuccess720:
  %v3961 = load i64, ptr %slot24, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  store i32 2, ptr %p3962, align 4, !alias.scope !3, !noalias !4
  %v3963 = load i64, ptr %slot23, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  store i32 1, ptr %p3964, align 4, !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot19, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  %ld3967 = load i32, ptr %p3966, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3967, ptr %slot575, align 8
  %v3968 = load i32, ptr %slot575, align 8
  %cv3969 = zext i32 %v3968 to i64
  %cond3970 = icmp ne i64 %cv3969, 0
  br i1 %cond3970, label %bb_rcslotdrop727, label %bb_rcslotdone727
bb_rcslotdrop727:
  %v3971 = load i64, ptr %slot19, align 8
  %p3972 = inttoptr i64 %v3971 to ptr
  store i32 0, ptr %p3972, align 4, !alias.scope !3, !noalias !4
  %v3973 = load i64, ptr %slot27, align 8
  store i64 %v3973, ptr %slot576, align 8
  %v3974 = load i64, ptr %slot20, align 8
  %p3975 = inttoptr i64 %v3974 to ptr
  %ld3976 = load i32, ptr %p3975, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3976, ptr %slot577, align 8
  %v3977 = load i32, ptr %slot577, align 8
  %op3978 = and i32 %v3977, 28
  store i32 %op3978, ptr %slot578, align 8
  %v3979 = load i32, ptr %slot578, align 8
  %cv3980 = zext i32 %v3979 to i64
  %cond3981 = icmp ne i64 %cv3980, 0
  br i1 %cond3981, label %bb_rcslotrole727, label %bb_rcslotowner727
bb_rcslotrole727:
  %v3982 = load i64, ptr %slot66, align 8
  store i64 %v3982, ptr %slot579, align 8
  %v3983 = load i64, ptr %slot579, align 8
  %v3984 = load i64, ptr %slot576, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v3983, i64 %v3984) nomerge, !dbg !148
  br label %bb_rcslotdone727
bb_rcslotowner727:
  %v3985 = load i64, ptr %slot66, align 8
  store i64 %v3985, ptr %slot580, align 8
  %v3986 = load i64, ptr %slot580, align 8
  %v3987 = load i64, ptr %slot576, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v3986, i64 %v3987) nomerge, !dbg !148
  br label %bb_rcslotdone727
bb_rcslotdone727:
  br label %bb_rcprepared666
bb_rcprepared666:
  %v3988 = load i64, ptr %slot31, align 8
  store i64 %v3988, ptr %slot581, align 8
  %v3989 = load i64, ptr %slot57, align 8
  store i64 %v3989, ptr %slot582, align 8
  %v3990 = load i64, ptr %slot581, align 8
  %v3991 = load i64, ptr %slot582, align 8
  %p3992 = inttoptr i64 %v3990 to ptr
  %p3993 = inttoptr i64 %v3991 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3993, ptr %p3992, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v3994 = load i64, ptr %slot23, align 8
  %p3995 = inttoptr i64 %v3994 to ptr
  store i32 0, ptr %p3995, align 4, !alias.scope !3, !noalias !4
  %v3996 = load i64, ptr %slot25, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  store i32 1, ptr %p3997, align 4, !alias.scope !3, !noalias !4
  %v3998 = load i64, ptr %slot67, align 8
  store i64 %v3998, ptr %slot583, align 8
  %v3999 = load i64, ptr %slot56, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  %ld4001 = load i64, ptr %p4000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4001, ptr %slot584, align 8
  %v4002 = load i64, ptr %slot582, align 8
  %p4004 = inttoptr i64 %v4002 to ptr
  %gep4005 = getelementptr i8, ptr %p4004, i64 16
  %op4003 = ptrtoint ptr %gep4005 to i64
  store i64 %op4003, ptr %slot585, align 8
  %v4006 = load i64, ptr %slot31, align 8
  store i64 %v4006, ptr %slot586, align 8
  %v4007 = load i64, ptr %slot56, align 8
  %p4008 = inttoptr i64 %v4007 to ptr
  %ld4009 = load i64, ptr %p4008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4009, ptr %slot587, align 8
  %v4010 = load i64, ptr %slot31, align 8
  store i64 %v4010, ptr %slot588, align 8
  %v4011 = load i64, ptr %slot67, align 8
  store i64 %v4011, ptr %slot589, align 8
  %v4012 = load i64, ptr %slot587, align 8
  %op4013 = add i64 %v4012, 0
  store i64 %op4013, ptr %slot590, align 8
  %v4014 = load i64, ptr %slot590, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  %ld4016 = load i64, ptr %p4015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4016, ptr %slot591, align 8
  %v4017 = load i64, ptr %slot591, align 8
  %cmp4018 = icmp ne i64 %v4017, 0
  %cv4019 = zext i1 %cmp4018 to i32
  store i32 %cv4019, ptr %slot592, align 8
  %v4020 = load i32, ptr %slot592, align 8
  %cv4021 = zext i32 %v4020 to i64
  %cond4022 = icmp ne i64 %cv4021, 0
  br i1 %cond4022, label %bb_rcmoveheader749, label %bb_rcmovenext749
bb_rcmoveheader749:
  %v4023 = load i64, ptr %slot591, align 8
  %op4024 = sub i64 %v4023, 16
  store i64 %op4024, ptr %slot593, align 8
  %v4025 = load i64, ptr %slot591, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  %rgep4027 = getelementptr i8, ptr %p4026, i64 -16
  %ld4028 = load i64, ptr %rgep4027, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4028, ptr %slot594, align 8
  %v4029 = load i64, ptr %slot594, align 8
  %op4030 = and i64 %v4029, 5764607523034234881
  store i64 %op4030, ptr %slot595, align 8
  %v4031 = load i64, ptr %slot595, align 8
  %cmp4032 = icmp ne i64 %v4031, 0
  %cv4033 = zext i1 %cmp4032 to i32
  store i32 %cv4033, ptr %slot596, align 8
  %v4034 = load i32, ptr %slot596, align 8
  %cv4035 = zext i32 %v4034 to i64
  %cond4036 = icmp ne i64 %cv4035, 0
  br i1 %cond4036, label %bb_rcmoveslow746, label %bb_rcmovenext749
bb_rcmovenext749:
  %v4037 = load i64, ptr %slot587, align 8
  %op4038 = add i64 %v4037, 8
  store i64 %op4038, ptr %slot597, align 8
  %v4039 = load i64, ptr %slot597, align 8
  %p4040 = inttoptr i64 %v4039 to ptr
  %ld4041 = load i64, ptr %p4040, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4041, ptr %slot598, align 8
  %v4042 = load i64, ptr %slot598, align 8
  %cmp4043 = icmp ne i64 %v4042, 0
  %cv4044 = zext i1 %cmp4043 to i32
  store i32 %cv4044, ptr %slot599, align 8
  %v4045 = load i32, ptr %slot599, align 8
  %cv4046 = zext i32 %v4045 to i64
  %cond4047 = icmp ne i64 %cv4046, 0
  br i1 %cond4047, label %bb_rcmoveheader757, label %bb_rcmovenext757
bb_rcmoveheader757:
  %v4048 = load i64, ptr %slot598, align 8
  %op4049 = sub i64 %v4048, 16
  store i64 %op4049, ptr %slot600, align 8
  %v4050 = load i64, ptr %slot598, align 8
  %p4051 = inttoptr i64 %v4050 to ptr
  %rgep4052 = getelementptr i8, ptr %p4051, i64 -16
  %ld4053 = load i64, ptr %rgep4052, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4053, ptr %slot601, align 8
  %v4054 = load i64, ptr %slot601, align 8
  %op4055 = and i64 %v4054, 5764607523034234881
  store i64 %op4055, ptr %slot602, align 8
  %v4056 = load i64, ptr %slot602, align 8
  %cmp4057 = icmp ne i64 %v4056, 0
  %cv4058 = zext i1 %cmp4057 to i32
  store i32 %cv4058, ptr %slot603, align 8
  %v4059 = load i32, ptr %slot603, align 8
  %cv4060 = zext i32 %v4059 to i64
  %cond4061 = icmp ne i64 %cv4060, 0
  br i1 %cond4061, label %bb_rcmoveslow746, label %bb_rcmovenext757
bb_rcmovenext757:
  %v4062 = load i64, ptr %slot587, align 8
  %op4063 = add i64 %v4062, 16
  store i64 %op4063, ptr %slot604, align 8
  %v4064 = load i64, ptr %slot604, align 8
  %p4065 = inttoptr i64 %v4064 to ptr
  %ld4066 = load i64, ptr %p4065, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4066, ptr %slot605, align 8
  %v4067 = load i64, ptr %slot605, align 8
  %cmp4068 = icmp ne i64 %v4067, 0
  %cv4069 = zext i1 %cmp4068 to i32
  store i32 %cv4069, ptr %slot606, align 8
  %v4070 = load i32, ptr %slot606, align 8
  %cv4071 = zext i32 %v4070 to i64
  %cond4072 = icmp ne i64 %cv4071, 0
  br i1 %cond4072, label %bb_rcmoveheader765, label %bb_rcmovenext765
bb_rcmoveheader765:
  %v4073 = load i64, ptr %slot605, align 8
  %op4074 = sub i64 %v4073, 16
  store i64 %op4074, ptr %slot607, align 8
  %v4075 = load i64, ptr %slot605, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  %rgep4077 = getelementptr i8, ptr %p4076, i64 -16
  %ld4078 = load i64, ptr %rgep4077, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4078, ptr %slot608, align 8
  %v4079 = load i64, ptr %slot608, align 8
  %op4080 = and i64 %v4079, 5764607523034234881
  store i64 %op4080, ptr %slot609, align 8
  %v4081 = load i64, ptr %slot609, align 8
  %cmp4082 = icmp ne i64 %v4081, 0
  %cv4083 = zext i1 %cmp4082 to i32
  store i32 %cv4083, ptr %slot610, align 8
  %v4084 = load i32, ptr %slot610, align 8
  %cv4085 = zext i32 %v4084 to i64
  %cond4086 = icmp ne i64 %cv4085, 0
  br i1 %cond4086, label %bb_rcmoveslow746, label %bb_rcmovenext765
bb_rcmovenext765:
  %v4087 = load i64, ptr %slot587, align 8
  %v4088 = load i64, ptr %slot588, align 8
  %p4089 = inttoptr i64 %v4087 to ptr
  %p4090 = inttoptr i64 %v4088 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4090, ptr %p4089, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4091 = load i64, ptr %slot587, align 8
  %p4092 = inttoptr i64 %v4091 to ptr
  store i64 0, ptr %p4092, align 8, !alias.scope !3, !noalias !4
  %v4093 = load i64, ptr %slot587, align 8
  %op4094 = add i64 %v4093, 8
  store i64 %op4094, ptr %slot611, align 8
  %v4095 = load i64, ptr %slot611, align 8
  %p4096 = inttoptr i64 %v4095 to ptr
  store i64 0, ptr %p4096, align 8, !alias.scope !3, !noalias !4
  %v4097 = load i64, ptr %slot587, align 8
  %op4098 = add i64 %v4097, 16
  store i64 %op4098, ptr %slot612, align 8
  %v4099 = load i64, ptr %slot612, align 8
  %p4100 = inttoptr i64 %v4099 to ptr
  store i64 0, ptr %p4100, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved746
bb_rcmoveslow746:
  %v4101 = load i64, ptr %slot66, align 8
  %v4102 = load i64, ptr %slot588, align 8
  %v4103 = load i64, ptr %slot587, align 8
  %v4104 = load i64, ptr %slot589, align 8
  %cv4105 = trunc i64 %v4104 to i32
  %call4106 = call i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64 %v4101, i64 %v4102, i64 %v4103, i32 %cv4105) nomerge, !dbg !148
  store i32 %call4106, ptr %slot613, align 8
  %v4107 = load i32, ptr %slot613, align 8
  %cv4108 = zext i32 %v4107 to i64
  %cond4109 = icmp ne i64 %cv4108, 0
  br i1 %cond4109, label %bb_rcsuccess774, label %bb_rcfailure774
bb_rcfailure774:
  %v4110 = load i64, ptr %slot66, align 8
  %p4111 = inttoptr i64 %v4110 to ptr
  %call4112 = call i32 @myl_rc_take_failure(ptr %p4111) nomerge, !dbg !148
  store i32 %call4112, ptr %slot614, align 8
  %v4113 = load i64, ptr %slot1, align 8
  %p4114 = inttoptr i64 %v4113 to ptr
  %v4115 = load i32, ptr %slot614, align 8
  %call4116 = call i32 @myl_qbe_rc_status(ptr %p4114, i32 %v4115) nomerge, !dbg !148
  store i32 %call4116, ptr %slot615, align 8
  br label %bb_failure
bb_rcsuccess774:
  br label %bb_rcmoved746
bb_rcmoved746:
  %v4117 = load i64, ptr %slot21, align 8
  %p4118 = inttoptr i64 %v4117 to ptr
  store i32 0, ptr %p4118, align 4, !alias.scope !3, !noalias !4
  %v4119 = load i64, ptr %slot24, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  store i32 2, ptr %p4120, align 4, !alias.scope !3, !noalias !4
  %v4121 = load i64, ptr %slot23, align 8
  %p4122 = inttoptr i64 %v4121 to ptr
  store i32 1, ptr %p4122, align 4, !alias.scope !3, !noalias !4
  %v4123 = load i64, ptr %slot31, align 8
  store i64 %v4123, ptr %slot616, align 8
  %v4124 = load i64, ptr %slot616, align 8
  %v4125 = load i64, ptr %slot586, align 8
  %p4126 = inttoptr i64 %v4124 to ptr
  %p4127 = inttoptr i64 %v4125 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4127, ptr %p4126, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4128 = load i64, ptr %slot23, align 8
  %p4129 = inttoptr i64 %v4128 to ptr
  store i32 0, ptr %p4129, align 4, !alias.scope !3, !noalias !4
  %v4130 = load i64, ptr %slot24, align 8
  %p4131 = inttoptr i64 %v4130 to ptr
  store i32 2, ptr %p4131, align 4, !alias.scope !3, !noalias !4
  %v4132 = load i64, ptr %slot23, align 8
  %p4133 = inttoptr i64 %v4132 to ptr
  store i32 1, ptr %p4133, align 4, !alias.scope !3, !noalias !4
  %v4134 = load i64, ptr %slot66, align 8
  store i64 %v4134, ptr %slot617, align 8
  %v4135 = load i64, ptr %slot617, align 8
  %v4136 = load i64, ptr %slot585, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v4135, i64 %v4136) nomerge, !dbg !148
  %v4137 = load i64, ptr %slot586, align 8
  %v4138 = load i64, ptr %slot585, align 8
  %p4139 = inttoptr i64 %v4137 to ptr
  %p4140 = inttoptr i64 %v4138 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4140, ptr %p4139, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4141 = load i64, ptr %slot23, align 8
  %p4142 = inttoptr i64 %v4141 to ptr
  store i32 0, ptr %p4142, align 4, !alias.scope !3, !noalias !4
  %v4143 = load i64, ptr %slot582, align 8
  %v4144 = load i64, ptr %slot55, align 8
  %p4145 = inttoptr i64 %v4144 to ptr
  store i64 %v4143, ptr %p4145, align 8, !alias.scope !3, !noalias !4
  %v4146 = load i64, ptr %slot55, align 8
  %p4147 = inttoptr i64 %v4146 to ptr
  %ld4148 = load i64, ptr %p4147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4148, ptr %slot618, align 8
  %v4149 = load i64, ptr %slot31, align 8
  store i64 %v4149, ptr %slot619, align 8
  %v4150 = load i64, ptr %slot618, align 8
  %v4151 = load i64, ptr %slot619, align 8
  %p4152 = inttoptr i64 %v4150 to ptr
  %p4153 = inttoptr i64 %v4151 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4153, ptr %p4152, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4154 = load i64, ptr %slot24, align 8
  %p4155 = inttoptr i64 %v4154 to ptr
  store i32 2, ptr %p4155, align 4, !alias.scope !3, !noalias !4
  %v4156 = load i64, ptr %slot23, align 8
  %p4157 = inttoptr i64 %v4156 to ptr
  store i32 1, ptr %p4157, align 4, !alias.scope !3, !noalias !4
  %v4158 = load i64, ptr %slot19, align 8
  %p4159 = inttoptr i64 %v4158 to ptr
  %ld4160 = load i32, ptr %p4159, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4160, ptr %slot620, align 8
  %v4161 = load i32, ptr %slot620, align 8
  %cv4162 = zext i32 %v4161 to i64
  %cond4163 = icmp ne i64 %cv4162, 0
  br i1 %cond4163, label %bb_rcslotdrop792, label %bb_rcslotdone792
bb_rcslotdrop792:
  %v4164 = load i64, ptr %slot19, align 8
  %p4165 = inttoptr i64 %v4164 to ptr
  store i32 0, ptr %p4165, align 4, !alias.scope !3, !noalias !4
  %v4166 = load i64, ptr %slot27, align 8
  store i64 %v4166, ptr %slot621, align 8
  %v4167 = load i64, ptr %slot20, align 8
  %p4168 = inttoptr i64 %v4167 to ptr
  %ld4169 = load i32, ptr %p4168, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4169, ptr %slot622, align 8
  %v4170 = load i32, ptr %slot622, align 8
  %op4171 = and i32 %v4170, 28
  store i32 %op4171, ptr %slot623, align 8
  %v4172 = load i32, ptr %slot623, align 8
  %cv4173 = zext i32 %v4172 to i64
  %cond4174 = icmp ne i64 %cv4173, 0
  br i1 %cond4174, label %bb_rcslotrole792, label %bb_rcslotowner792
bb_rcslotrole792:
  %v4175 = load i64, ptr %slot66, align 8
  store i64 %v4175, ptr %slot624, align 8
  %v4176 = load i64, ptr %slot624, align 8
  %v4177 = load i64, ptr %slot621, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v4176, i64 %v4177) nomerge, !dbg !148
  br label %bb_rcslotdone792
bb_rcslotowner792:
  %v4178 = load i64, ptr %slot66, align 8
  store i64 %v4178, ptr %slot625, align 8
  %v4179 = load i64, ptr %slot625, align 8
  %v4180 = load i64, ptr %slot621, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4179, i64 %v4180) nomerge, !dbg !148
  br label %bb_rcslotdone792
bb_rcslotdone792:
  %v4181 = load i64, ptr %slot21, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  %ld4183 = load i32, ptr %p4182, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4183, ptr %slot626, align 8
  %v4184 = load i32, ptr %slot626, align 8
  %cv4185 = zext i32 %v4184 to i64
  %cond4186 = icmp ne i64 %cv4185, 0
  br i1 %cond4186, label %bb_rcslotdrop801, label %bb_rcslotdone801
bb_rcslotdrop801:
  %v4187 = load i64, ptr %slot21, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  store i32 0, ptr %p4188, align 4, !alias.scope !3, !noalias !4
  %v4189 = load i64, ptr %slot28, align 8
  store i64 %v4189, ptr %slot627, align 8
  %v4190 = load i64, ptr %slot22, align 8
  %p4191 = inttoptr i64 %v4190 to ptr
  %ld4192 = load i32, ptr %p4191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4192, ptr %slot628, align 8
  %v4193 = load i32, ptr %slot628, align 8
  %op4194 = and i32 %v4193, 28
  store i32 %op4194, ptr %slot629, align 8
  %v4195 = load i32, ptr %slot629, align 8
  %cv4196 = zext i32 %v4195 to i64
  %cond4197 = icmp ne i64 %cv4196, 0
  br i1 %cond4197, label %bb_rcslotrole801, label %bb_rcslotowner801
bb_rcslotrole801:
  %v4198 = load i64, ptr %slot66, align 8
  store i64 %v4198, ptr %slot630, align 8
  %v4199 = load i64, ptr %slot630, align 8
  %v4200 = load i64, ptr %slot627, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v4199, i64 %v4200) nomerge, !dbg !148
  br label %bb_rcslotdone801
bb_rcslotowner801:
  %v4201 = load i64, ptr %slot66, align 8
  store i64 %v4201, ptr %slot631, align 8
  %v4202 = load i64, ptr %slot631, align 8
  %v4203 = load i64, ptr %slot627, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v4202, i64 %v4203) nomerge, !dbg !148
  br label %bb_rcslotdone801
bb_rcslotdone801:
  %v4204 = load i64, ptr %slot27, align 8
  store i64 %v4204, ptr %slot632, align 8
  %v4205 = load i64, ptr %slot31, align 8
  store i64 %v4205, ptr %slot633, align 8
  %v4206 = load i64, ptr %slot633, align 8
  %v4207 = load i64, ptr %slot632, align 8
  %p4208 = inttoptr i64 %v4206 to ptr
  %p4209 = inttoptr i64 %v4207 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4209, ptr %p4208, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4210 = load i64, ptr %slot20, align 8
  %p4211 = inttoptr i64 %v4210 to ptr
  store i32 2, ptr %p4211, align 4, !alias.scope !3, !noalias !4
  %v4212 = load i64, ptr %slot24, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  %ld4214 = load i32, ptr %p4213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4214, ptr %slot634, align 8
  %v4215 = load i32, ptr %slot634, align 8
  %v4216 = load i64, ptr %slot20, align 8
  %p4217 = inttoptr i64 %v4216 to ptr
  store i32 %v4215, ptr %p4217, align 4, !alias.scope !3, !noalias !4
  %v4218 = load i64, ptr %slot23, align 8
  %p4219 = inttoptr i64 %v4218 to ptr
  store i32 0, ptr %p4219, align 4, !alias.scope !3, !noalias !4
  %v4220 = load i64, ptr %slot19, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  store i32 1, ptr %p4221, align 4, !alias.scope !3, !noalias !4
  %v4222 = load i64, ptr %slot632, align 8
  %v4223 = load i64, ptr %slot55, align 8
  %p4224 = inttoptr i64 %v4223 to ptr
  store i64 %v4222, ptr %p4224, align 8, !alias.scope !3, !noalias !4
  %v4225 = load i64, ptr %slot55, align 8
  %p4226 = inttoptr i64 %v4225 to ptr
  %ld4227 = load i64, ptr %p4226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4227, ptr %slot635, align 8
  %v4228 = load i64, ptr %slot19, align 8
  %p4229 = inttoptr i64 %v4228 to ptr
  %ld4230 = load i32, ptr %p4229, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4230, ptr %slot636, align 8
  %v4231 = load i64, ptr %slot20, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %ld4233 = load i32, ptr %p4232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4233, ptr %slot637, align 8
  %v4234 = load i32, ptr %slot637, align 8
  %op4235 = and i32 %v4234, 24
  store i32 %op4235, ptr %slot637, align 8
  %v4236 = load i32, ptr %slot637, align 8
  %cmp4237 = icmp eq i32 %v4236, 0
  %cv4238 = zext i1 %cmp4237 to i32
  store i32 %cv4238, ptr %slot638, align 8
  %v4239 = load i32, ptr %slot636, align 8
  %v4240 = load i32, ptr %slot638, align 8
  %op4241 = and i32 %v4239, %v4240
  store i32 %op4241, ptr %slot639, align 8
  %v4242 = load i64, ptr %slot67, align 8
  store i64 %v4242, ptr %slot640, align 8
  %v4243 = load i32, ptr %slot639, align 8
  %op4244 = mul i32 %v4243, 4
  store i32 %op4244, ptr %slot641, align 8
  %v4245 = load i32, ptr %slot641, align 8
  %op4246 = or i32 %v4245, 0
  store i32 %op4246, ptr %slot642, align 8
  %v4247 = load i64, ptr %slot31, align 8
  store i64 %v4247, ptr %slot643, align 8
  %v4248 = load i64, ptr %slot66, align 8
  %v4249 = load i64, ptr %slot643, align 8
  %v4250 = load i64, ptr %slot635, align 8
  %v4251 = load i64, ptr %slot640, align 8
  %cv4252 = trunc i64 %v4251 to i32
  %v4253 = load i32, ptr %slot642, align 8
  %call4254 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v4248, i64 %v4249, i64 %v4250, i32 %cv4252, i32 %v4253) nomerge, !dbg !150
  store i32 %call4254, ptr %slot644, align 8
  %v4255 = load i32, ptr %slot644, align 8
  %cv4256 = zext i32 %v4255 to i64
  %cond4257 = icmp ne i64 %cv4256, 0
  br i1 %cond4257, label %bb_rcsuccess830, label %bb_rcfailure830
bb_rcfailure830:
  %v4258 = load i64, ptr %slot66, align 8
  %p4259 = inttoptr i64 %v4258 to ptr
  %call4260 = call i32 @myl_rc_take_failure(ptr %p4259) nomerge, !dbg !150
  store i32 %call4260, ptr %slot645, align 8
  %v4261 = load i64, ptr %slot1, align 8
  %p4262 = inttoptr i64 %v4261 to ptr
  %v4263 = load i32, ptr %slot645, align 8
  %call4264 = call i32 @myl_qbe_rc_status(ptr %p4262, i32 %v4263) nomerge, !dbg !150
  store i32 %call4264, ptr %slot646, align 8
  br label %bb_failure
bb_rcsuccess830:
  %v4265 = load i32, ptr %slot639, align 8
  %cv4266 = zext i32 %v4265 to i64
  %cond4267 = icmp ne i64 %cv4266, 0
  br i1 %cond4267, label %bb_rchtaken833, label %bb_rchcopied833
bb_rchcopied833:
  %v4268 = load i64, ptr %slot19, align 8
  %p4269 = inttoptr i64 %v4268 to ptr
  %ld4270 = load i32, ptr %p4269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4270, ptr %slot647, align 8
  %v4271 = load i32, ptr %slot647, align 8
  %cv4272 = zext i32 %v4271 to i64
  %cond4273 = icmp ne i64 %cv4272, 0
  br i1 %cond4273, label %bb_rcslotdrop836, label %bb_rcslotdone836
bb_rcslotdrop836:
  %v4274 = load i64, ptr %slot19, align 8
  %p4275 = inttoptr i64 %v4274 to ptr
  store i32 0, ptr %p4275, align 4, !alias.scope !3, !noalias !4
  %v4276 = load i64, ptr %slot27, align 8
  store i64 %v4276, ptr %slot648, align 8
  %v4277 = load i64, ptr %slot20, align 8
  %p4278 = inttoptr i64 %v4277 to ptr
  %ld4279 = load i32, ptr %p4278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4279, ptr %slot649, align 8
  %v4280 = load i32, ptr %slot649, align 8
  %op4281 = and i32 %v4280, 28
  store i32 %op4281, ptr %slot650, align 8
  %v4282 = load i32, ptr %slot650, align 8
  %cv4283 = zext i32 %v4282 to i64
  %cond4284 = icmp ne i64 %cv4283, 0
  br i1 %cond4284, label %bb_rcslotrole836, label %bb_rcslotowner836
bb_rcslotrole836:
  %v4285 = load i64, ptr %slot66, align 8
  store i64 %v4285, ptr %slot651, align 8
  %v4286 = load i64, ptr %slot651, align 8
  %v4287 = load i64, ptr %slot648, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v4286, i64 %v4287) nomerge, !dbg !150
  br label %bb_rcslotdone836
bb_rcslotowner836:
  %v4288 = load i64, ptr %slot66, align 8
  store i64 %v4288, ptr %slot652, align 8
  %v4289 = load i64, ptr %slot652, align 8
  %v4290 = load i64, ptr %slot648, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4289, i64 %v4290) nomerge, !dbg !150
  br label %bb_rcslotdone836
bb_rcslotdone836:
  br label %bb_rchprepared833
bb_rchtaken833:
  %v4291 = load i64, ptr %slot19, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  store i32 0, ptr %p4292, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared833
bb_rchprepared833:
  %v4293 = load i64, ptr %slot24, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  store i32 2, ptr %p4294, align 4, !alias.scope !3, !noalias !4
  %v4295 = load i64, ptr %slot23, align 8
  %p4296 = inttoptr i64 %v4295 to ptr
  store i32 1, ptr %p4296, align 4, !alias.scope !3, !noalias !4
  %v4297 = load i64, ptr %slot27, align 8
  store i64 %v4297, ptr %slot653, align 8
  %v4298 = load i64, ptr %slot31, align 8
  store i64 %v4298, ptr %slot654, align 8
  %v4299 = load i64, ptr %slot654, align 8
  %v4300 = load i64, ptr %slot653, align 8
  %p4301 = inttoptr i64 %v4299 to ptr
  %p4302 = inttoptr i64 %v4300 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4302, ptr %p4301, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4303 = load i64, ptr %slot20, align 8
  %p4304 = inttoptr i64 %v4303 to ptr
  store i32 2, ptr %p4304, align 4, !alias.scope !3, !noalias !4
  %v4305 = load i64, ptr %slot24, align 8
  %p4306 = inttoptr i64 %v4305 to ptr
  %ld4307 = load i32, ptr %p4306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4307, ptr %slot655, align 8
  %v4308 = load i32, ptr %slot655, align 8
  %v4309 = load i64, ptr %slot20, align 8
  %p4310 = inttoptr i64 %v4309 to ptr
  store i32 %v4308, ptr %p4310, align 4, !alias.scope !3, !noalias !4
  %v4311 = load i64, ptr %slot23, align 8
  %p4312 = inttoptr i64 %v4311 to ptr
  store i32 0, ptr %p4312, align 4, !alias.scope !3, !noalias !4
  %v4313 = load i64, ptr %slot19, align 8
  %p4314 = inttoptr i64 %v4313 to ptr
  store i32 1, ptr %p4314, align 4, !alias.scope !3, !noalias !4
  %v4315 = load i64, ptr %slot653, align 8
  %v4316 = load i64, ptr %slot55, align 8
  %p4317 = inttoptr i64 %v4316 to ptr
  store i64 %v4315, ptr %p4317, align 8, !alias.scope !3, !noalias !4
  %v4318 = load i64, ptr %slot54, align 8
  %p4319 = inttoptr i64 %v4318 to ptr
  %ld4320 = load i64, ptr %p4319, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4320, ptr %slot656, align 8
  %v4321 = load i64, ptr %slot17, align 8
  %p4322 = inttoptr i64 %v4321 to ptr
  %ld4323 = load i32, ptr %p4322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4323, ptr %slot657, align 8
  %v4324 = load i64, ptr %slot18, align 8
  %p4325 = inttoptr i64 %v4324 to ptr
  %ld4326 = load i32, ptr %p4325, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4326, ptr %slot658, align 8
  %v4327 = load i32, ptr %slot658, align 8
  %op4328 = and i32 %v4327, 24
  store i32 %op4328, ptr %slot658, align 8
  %v4329 = load i32, ptr %slot658, align 8
  %cmp4330 = icmp eq i32 %v4329, 0
  %cv4331 = zext i1 %cmp4330 to i32
  store i32 %cv4331, ptr %slot659, align 8
  %v4332 = load i32, ptr %slot657, align 8
  %v4333 = load i32, ptr %slot659, align 8
  %op4334 = and i32 %v4332, %v4333
  store i32 %op4334, ptr %slot660, align 8
  %v4335 = load i32, ptr %slot660, align 8
  %cv4336 = zext i32 %v4335 to i64
  %cond4337 = icmp ne i64 %cv4336, 0
  br i1 %cond4337, label %bb_rctake855, label %bb_rccopy855
bb_rctake855:
  %v4338 = load i64, ptr %slot31, align 8
  store i64 %v4338, ptr %slot661, align 8
  %v4339 = load i64, ptr %slot67, align 8
  store i64 %v4339, ptr %slot662, align 8
  %v4340 = load i64, ptr %slot66, align 8
  %v4341 = load i64, ptr %slot661, align 8
  %v4342 = load i64, ptr %slot656, align 8
  %v4343 = load i64, ptr %slot662, align 8
  %cv4344 = trunc i64 %v4343 to i32
  %call4345 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v4340, i64 %v4341, i64 %v4342, i32 %cv4344) nomerge, !dbg !152
  store i32 %call4345, ptr %slot663, align 8
  %v4346 = load i32, ptr %slot663, align 8
  %cv4347 = zext i32 %v4346 to i64
  %cond4348 = icmp ne i64 %cv4347, 0
  br i1 %cond4348, label %bb_rcsuccess865, label %bb_rcfailure865
bb_rcfailure865:
  %v4349 = load i64, ptr %slot66, align 8
  %p4350 = inttoptr i64 %v4349 to ptr
  %call4351 = call i32 @myl_rc_take_failure(ptr %p4350) nomerge, !dbg !152
  store i32 %call4351, ptr %slot664, align 8
  %v4352 = load i64, ptr %slot1, align 8
  %p4353 = inttoptr i64 %v4352 to ptr
  %v4354 = load i32, ptr %slot664, align 8
  %call4355 = call i32 @myl_qbe_rc_status(ptr %p4353, i32 %v4354) nomerge, !dbg !152
  store i32 %call4355, ptr %slot665, align 8
  br label %bb_failure
bb_rcsuccess865:
  %v4356 = load i64, ptr %slot17, align 8
  %p4357 = inttoptr i64 %v4356 to ptr
  store i32 0, ptr %p4357, align 4, !alias.scope !3, !noalias !4
  %v4358 = load i64, ptr %slot24, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  store i32 2, ptr %p4359, align 4, !alias.scope !3, !noalias !4
  %v4360 = load i64, ptr %slot23, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  store i32 1, ptr %p4361, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared855
bb_rccopy855:
  %v4362 = load i64, ptr %slot31, align 8
  store i64 %v4362, ptr %slot666, align 8
  %v4363 = load i64, ptr %slot67, align 8
  store i64 %v4363, ptr %slot667, align 8
  %v4364 = load i64, ptr %slot66, align 8
  %v4365 = load i64, ptr %slot666, align 8
  %v4366 = load i64, ptr %slot656, align 8
  %v4367 = load i64, ptr %slot667, align 8
  %cv4368 = trunc i64 %v4367 to i32
  %call4369 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v4364, i64 %v4365, i64 %v4366, i32 %cv4368) nomerge, !dbg !152
  store i32 %call4369, ptr %slot668, align 8
  %v4370 = load i32, ptr %slot668, align 8
  %cv4371 = zext i32 %v4370 to i64
  %cond4372 = icmp ne i64 %cv4371, 0
  br i1 %cond4372, label %bb_rcsuccess874, label %bb_rcfailure874
bb_rcfailure874:
  %v4373 = load i64, ptr %slot66, align 8
  %p4374 = inttoptr i64 %v4373 to ptr
  %call4375 = call i32 @myl_rc_take_failure(ptr %p4374) nomerge, !dbg !152
  store i32 %call4375, ptr %slot669, align 8
  %v4376 = load i64, ptr %slot1, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %v4378 = load i32, ptr %slot669, align 8
  %call4379 = call i32 @myl_qbe_rc_status(ptr %p4377, i32 %v4378) nomerge, !dbg !152
  store i32 %call4379, ptr %slot670, align 8
  br label %bb_failure
bb_rcsuccess874:
  %v4380 = load i64, ptr %slot24, align 8
  %p4381 = inttoptr i64 %v4380 to ptr
  store i32 2, ptr %p4381, align 4, !alias.scope !3, !noalias !4
  %v4382 = load i64, ptr %slot23, align 8
  %p4383 = inttoptr i64 %v4382 to ptr
  store i32 1, ptr %p4383, align 4, !alias.scope !3, !noalias !4
  %v4384 = load i64, ptr %slot17, align 8
  %p4385 = inttoptr i64 %v4384 to ptr
  %ld4386 = load i32, ptr %p4385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4386, ptr %slot671, align 8
  %v4387 = load i32, ptr %slot671, align 8
  %cv4388 = zext i32 %v4387 to i64
  %cond4389 = icmp ne i64 %cv4388, 0
  br i1 %cond4389, label %bb_rcslotdrop881, label %bb_rcslotdone881
bb_rcslotdrop881:
  %v4390 = load i64, ptr %slot17, align 8
  %p4391 = inttoptr i64 %v4390 to ptr
  store i32 0, ptr %p4391, align 4, !alias.scope !3, !noalias !4
  %v4392 = load i64, ptr %slot26, align 8
  store i64 %v4392, ptr %slot672, align 8
  %v4393 = load i64, ptr %slot18, align 8
  %p4394 = inttoptr i64 %v4393 to ptr
  %ld4395 = load i32, ptr %p4394, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4395, ptr %slot673, align 8
  %v4396 = load i32, ptr %slot673, align 8
  %op4397 = and i32 %v4396, 28
  store i32 %op4397, ptr %slot674, align 8
  %v4398 = load i32, ptr %slot674, align 8
  %cv4399 = zext i32 %v4398 to i64
  %cond4400 = icmp ne i64 %cv4399, 0
  br i1 %cond4400, label %bb_rcslotrole881, label %bb_rcslotowner881
bb_rcslotrole881:
  %v4401 = load i64, ptr %slot66, align 8
  store i64 %v4401, ptr %slot675, align 8
  %v4402 = load i64, ptr %slot675, align 8
  %v4403 = load i64, ptr %slot672, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4402, i64 %v4403) nomerge, !dbg !152
  br label %bb_rcslotdone881
bb_rcslotowner881:
  %v4404 = load i64, ptr %slot66, align 8
  store i64 %v4404, ptr %slot676, align 8
  %v4405 = load i64, ptr %slot676, align 8
  %v4406 = load i64, ptr %slot672, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4405, i64 %v4406) nomerge, !dbg !152
  br label %bb_rcslotdone881
bb_rcslotdone881:
  br label %bb_rcprepared855
bb_rcprepared855:
  %v4407 = load i64, ptr %slot31, align 8
  store i64 %v4407, ptr %slot677, align 8
  %v4408 = load i64, ptr %slot58, align 8
  store i64 %v4408, ptr %slot678, align 8
  %v4409 = load i64, ptr %slot677, align 8
  %v4410 = load i64, ptr %slot678, align 8
  %p4411 = inttoptr i64 %v4409 to ptr
  %p4412 = inttoptr i64 %v4410 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4412, ptr %p4411, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4413 = load i64, ptr %slot23, align 8
  %p4414 = inttoptr i64 %v4413 to ptr
  store i32 0, ptr %p4414, align 4, !alias.scope !3, !noalias !4
  %v4415 = load i64, ptr %slot25, align 8
  %p4416 = inttoptr i64 %v4415 to ptr
  store i32 1, ptr %p4416, align 4, !alias.scope !3, !noalias !4
  %v4417 = load i64, ptr %slot67, align 8
  store i64 %v4417, ptr %slot679, align 8
  %v4418 = load i64, ptr %slot55, align 8
  %p4419 = inttoptr i64 %v4418 to ptr
  %ld4420 = load i64, ptr %p4419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4420, ptr %slot680, align 8
  %v4421 = load i64, ptr %slot678, align 8
  %p4423 = inttoptr i64 %v4421 to ptr
  %gep4424 = getelementptr i8, ptr %p4423, i64 0
  %op4422 = ptrtoint ptr %gep4424 to i64
  store i64 %op4422, ptr %slot681, align 8
  %v4425 = load i64, ptr %slot31, align 8
  store i64 %v4425, ptr %slot682, align 8
  %v4426 = load i64, ptr %slot55, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  %ld4428 = load i64, ptr %p4427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4428, ptr %slot683, align 8
  %v4429 = load i64, ptr %slot31, align 8
  store i64 %v4429, ptr %slot684, align 8
  %v4430 = load i64, ptr %slot67, align 8
  store i64 %v4430, ptr %slot685, align 8
  %v4431 = load i64, ptr %slot683, align 8
  %op4432 = add i64 %v4431, 16
  store i64 %op4432, ptr %slot686, align 8
  %v4433 = load i64, ptr %slot686, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  %ld4435 = load i64, ptr %p4434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4435, ptr %slot687, align 8
  %v4436 = load i64, ptr %slot687, align 8
  %cmp4437 = icmp ne i64 %v4436, 0
  %cv4438 = zext i1 %cmp4437 to i32
  store i32 %cv4438, ptr %slot688, align 8
  %v4439 = load i32, ptr %slot688, align 8
  %cv4440 = zext i32 %v4439 to i64
  %cond4441 = icmp ne i64 %cv4440, 0
  br i1 %cond4441, label %bb_rcmoveheader903, label %bb_rcmovenext903
bb_rcmoveheader903:
  %v4442 = load i64, ptr %slot687, align 8
  %op4443 = sub i64 %v4442, 16
  store i64 %op4443, ptr %slot689, align 8
  %v4444 = load i64, ptr %slot687, align 8
  %p4445 = inttoptr i64 %v4444 to ptr
  %rgep4446 = getelementptr i8, ptr %p4445, i64 -16
  %ld4447 = load i64, ptr %rgep4446, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4447, ptr %slot690, align 8
  %v4448 = load i64, ptr %slot690, align 8
  %op4449 = and i64 %v4448, 5764607523034234881
  store i64 %op4449, ptr %slot691, align 8
  %v4450 = load i64, ptr %slot691, align 8
  %cmp4451 = icmp ne i64 %v4450, 0
  %cv4452 = zext i1 %cmp4451 to i32
  store i32 %cv4452, ptr %slot692, align 8
  %v4453 = load i32, ptr %slot692, align 8
  %cv4454 = zext i32 %v4453 to i64
  %cond4455 = icmp ne i64 %cv4454, 0
  br i1 %cond4455, label %bb_rcmoveslow900, label %bb_rcmovenext903
bb_rcmovenext903:
  %v4456 = load i64, ptr %slot683, align 8
  %op4457 = add i64 %v4456, 24
  store i64 %op4457, ptr %slot693, align 8
  %v4458 = load i64, ptr %slot693, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  %ld4460 = load i64, ptr %p4459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4460, ptr %slot694, align 8
  %v4461 = load i64, ptr %slot694, align 8
  %cmp4462 = icmp ne i64 %v4461, 0
  %cv4463 = zext i1 %cmp4462 to i32
  store i32 %cv4463, ptr %slot695, align 8
  %v4464 = load i32, ptr %slot695, align 8
  %cv4465 = zext i32 %v4464 to i64
  %cond4466 = icmp ne i64 %cv4465, 0
  br i1 %cond4466, label %bb_rcmoveheader911, label %bb_rcmovenext911
bb_rcmoveheader911:
  %v4467 = load i64, ptr %slot694, align 8
  %op4468 = sub i64 %v4467, 16
  store i64 %op4468, ptr %slot696, align 8
  %v4469 = load i64, ptr %slot694, align 8
  %p4470 = inttoptr i64 %v4469 to ptr
  %rgep4471 = getelementptr i8, ptr %p4470, i64 -16
  %ld4472 = load i64, ptr %rgep4471, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4472, ptr %slot697, align 8
  %v4473 = load i64, ptr %slot697, align 8
  %op4474 = and i64 %v4473, 5764607523034234881
  store i64 %op4474, ptr %slot698, align 8
  %v4475 = load i64, ptr %slot698, align 8
  %cmp4476 = icmp ne i64 %v4475, 0
  %cv4477 = zext i1 %cmp4476 to i32
  store i32 %cv4477, ptr %slot699, align 8
  %v4478 = load i32, ptr %slot699, align 8
  %cv4479 = zext i32 %v4478 to i64
  %cond4480 = icmp ne i64 %cv4479, 0
  br i1 %cond4480, label %bb_rcmoveslow900, label %bb_rcmovenext911
bb_rcmovenext911:
  %v4481 = load i64, ptr %slot683, align 8
  %op4482 = add i64 %v4481, 32
  store i64 %op4482, ptr %slot700, align 8
  %v4483 = load i64, ptr %slot700, align 8
  %p4484 = inttoptr i64 %v4483 to ptr
  %ld4485 = load i64, ptr %p4484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4485, ptr %slot701, align 8
  %v4486 = load i64, ptr %slot701, align 8
  %cmp4487 = icmp ne i64 %v4486, 0
  %cv4488 = zext i1 %cmp4487 to i32
  store i32 %cv4488, ptr %slot702, align 8
  %v4489 = load i32, ptr %slot702, align 8
  %cv4490 = zext i32 %v4489 to i64
  %cond4491 = icmp ne i64 %cv4490, 0
  br i1 %cond4491, label %bb_rcmoveheader919, label %bb_rcmovenext919
bb_rcmoveheader919:
  %v4492 = load i64, ptr %slot701, align 8
  %op4493 = sub i64 %v4492, 16
  store i64 %op4493, ptr %slot703, align 8
  %v4494 = load i64, ptr %slot701, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  %rgep4496 = getelementptr i8, ptr %p4495, i64 -16
  %ld4497 = load i64, ptr %rgep4496, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4497, ptr %slot704, align 8
  %v4498 = load i64, ptr %slot704, align 8
  %op4499 = and i64 %v4498, 5764607523034234881
  store i64 %op4499, ptr %slot705, align 8
  %v4500 = load i64, ptr %slot705, align 8
  %cmp4501 = icmp ne i64 %v4500, 0
  %cv4502 = zext i1 %cmp4501 to i32
  store i32 %cv4502, ptr %slot706, align 8
  %v4503 = load i32, ptr %slot706, align 8
  %cv4504 = zext i32 %v4503 to i64
  %cond4505 = icmp ne i64 %cv4504, 0
  br i1 %cond4505, label %bb_rcmoveslow900, label %bb_rcmovenext919
bb_rcmovenext919:
  %v4506 = load i64, ptr %slot683, align 8
  %v4507 = load i64, ptr %slot684, align 8
  %p4508 = inttoptr i64 %v4506 to ptr
  %p4509 = inttoptr i64 %v4507 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4509, ptr %p4508, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4510 = load i64, ptr %slot683, align 8
  %p4511 = inttoptr i64 %v4510 to ptr
  store i64 0, ptr %p4511, align 8, !alias.scope !3, !noalias !4
  %v4512 = load i64, ptr %slot683, align 8
  %op4513 = add i64 %v4512, 8
  store i64 %op4513, ptr %slot707, align 8
  %v4514 = load i64, ptr %slot707, align 8
  %p4515 = inttoptr i64 %v4514 to ptr
  store i64 0, ptr %p4515, align 8, !alias.scope !3, !noalias !4
  %v4516 = load i64, ptr %slot683, align 8
  %op4517 = add i64 %v4516, 16
  store i64 %op4517, ptr %slot708, align 8
  %v4518 = load i64, ptr %slot708, align 8
  %p4519 = inttoptr i64 %v4518 to ptr
  store i64 0, ptr %p4519, align 8, !alias.scope !3, !noalias !4
  %v4520 = load i64, ptr %slot683, align 8
  %op4521 = add i64 %v4520, 24
  store i64 %op4521, ptr %slot709, align 8
  %v4522 = load i64, ptr %slot709, align 8
  %p4523 = inttoptr i64 %v4522 to ptr
  store i64 0, ptr %p4523, align 8, !alias.scope !3, !noalias !4
  %v4524 = load i64, ptr %slot683, align 8
  %op4525 = add i64 %v4524, 32
  store i64 %op4525, ptr %slot710, align 8
  %v4526 = load i64, ptr %slot710, align 8
  %p4527 = inttoptr i64 %v4526 to ptr
  store i64 0, ptr %p4527, align 8, !alias.scope !3, !noalias !4
  %v4528 = load i64, ptr %slot683, align 8
  %op4529 = add i64 %v4528, 40
  store i64 %op4529, ptr %slot711, align 8
  %v4530 = load i64, ptr %slot711, align 8
  %p4531 = inttoptr i64 %v4530 to ptr
  store i64 0, ptr %p4531, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved900
bb_rcmoveslow900:
  %v4532 = load i64, ptr %slot66, align 8
  %v4533 = load i64, ptr %slot684, align 8
  %v4534 = load i64, ptr %slot683, align 8
  %v4535 = load i64, ptr %slot685, align 8
  %cv4536 = trunc i64 %v4535 to i32
  %call4537 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v4532, i64 %v4533, i64 %v4534, i32 %cv4536) nomerge, !dbg !152
  store i32 %call4537, ptr %slot712, align 8
  %v4538 = load i32, ptr %slot712, align 8
  %cv4539 = zext i32 %v4538 to i64
  %cond4540 = icmp ne i64 %cv4539, 0
  br i1 %cond4540, label %bb_rcsuccess931, label %bb_rcfailure931
bb_rcfailure931:
  %v4541 = load i64, ptr %slot66, align 8
  %p4542 = inttoptr i64 %v4541 to ptr
  %call4543 = call i32 @myl_rc_take_failure(ptr %p4542) nomerge, !dbg !152
  store i32 %call4543, ptr %slot713, align 8
  %v4544 = load i64, ptr %slot1, align 8
  %p4545 = inttoptr i64 %v4544 to ptr
  %v4546 = load i32, ptr %slot713, align 8
  %call4547 = call i32 @myl_qbe_rc_status(ptr %p4545, i32 %v4546) nomerge, !dbg !152
  store i32 %call4547, ptr %slot714, align 8
  br label %bb_failure
bb_rcsuccess931:
  br label %bb_rcmoved900
bb_rcmoved900:
  %v4548 = load i64, ptr %slot19, align 8
  %p4549 = inttoptr i64 %v4548 to ptr
  store i32 0, ptr %p4549, align 4, !alias.scope !3, !noalias !4
  %v4550 = load i64, ptr %slot24, align 8
  %p4551 = inttoptr i64 %v4550 to ptr
  store i32 2, ptr %p4551, align 4, !alias.scope !3, !noalias !4
  %v4552 = load i64, ptr %slot23, align 8
  %p4553 = inttoptr i64 %v4552 to ptr
  store i32 1, ptr %p4553, align 4, !alias.scope !3, !noalias !4
  %v4554 = load i64, ptr %slot31, align 8
  store i64 %v4554, ptr %slot715, align 8
  %v4555 = load i64, ptr %slot715, align 8
  %v4556 = load i64, ptr %slot682, align 8
  %p4557 = inttoptr i64 %v4555 to ptr
  %p4558 = inttoptr i64 %v4556 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4558, ptr %p4557, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4559 = load i64, ptr %slot23, align 8
  %p4560 = inttoptr i64 %v4559 to ptr
  store i32 0, ptr %p4560, align 4, !alias.scope !3, !noalias !4
  %v4561 = load i64, ptr %slot24, align 8
  %p4562 = inttoptr i64 %v4561 to ptr
  store i32 2, ptr %p4562, align 4, !alias.scope !3, !noalias !4
  %v4563 = load i64, ptr %slot23, align 8
  %p4564 = inttoptr i64 %v4563 to ptr
  store i32 1, ptr %p4564, align 4, !alias.scope !3, !noalias !4
  %v4565 = load i64, ptr %slot66, align 8
  store i64 %v4565, ptr %slot716, align 8
  %v4566 = load i64, ptr %slot716, align 8
  %v4567 = load i64, ptr %slot681, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4566, i64 %v4567) nomerge, !dbg !152
  %v4568 = load i64, ptr %slot682, align 8
  %v4569 = load i64, ptr %slot681, align 8
  %p4570 = inttoptr i64 %v4568 to ptr
  %p4571 = inttoptr i64 %v4569 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4571, ptr %p4570, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4572 = load i64, ptr %slot23, align 8
  %p4573 = inttoptr i64 %v4572 to ptr
  store i32 0, ptr %p4573, align 4, !alias.scope !3, !noalias !4
  %v4574 = load i64, ptr %slot678, align 8
  %v4575 = load i64, ptr %slot54, align 8
  %p4576 = inttoptr i64 %v4575 to ptr
  store i64 %v4574, ptr %p4576, align 8, !alias.scope !3, !noalias !4
  %v4577 = load i64, ptr %slot54, align 8
  %p4578 = inttoptr i64 %v4577 to ptr
  %ld4579 = load i64, ptr %p4578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4579, ptr %slot717, align 8
  %v4580 = load i64, ptr %slot31, align 8
  store i64 %v4580, ptr %slot718, align 8
  %v4581 = load i64, ptr %slot717, align 8
  %v4582 = load i64, ptr %slot718, align 8
  %p4583 = inttoptr i64 %v4581 to ptr
  %p4584 = inttoptr i64 %v4582 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4584, ptr %p4583, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4585 = load i64, ptr %slot24, align 8
  %p4586 = inttoptr i64 %v4585 to ptr
  store i32 2, ptr %p4586, align 4, !alias.scope !3, !noalias !4
  %v4587 = load i64, ptr %slot23, align 8
  %p4588 = inttoptr i64 %v4587 to ptr
  store i32 1, ptr %p4588, align 4, !alias.scope !3, !noalias !4
  %v4589 = load i64, ptr %slot17, align 8
  %p4590 = inttoptr i64 %v4589 to ptr
  %ld4591 = load i32, ptr %p4590, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4591, ptr %slot719, align 8
  %v4592 = load i32, ptr %slot719, align 8
  %cv4593 = zext i32 %v4592 to i64
  %cond4594 = icmp ne i64 %cv4593, 0
  br i1 %cond4594, label %bb_rcslotdrop949, label %bb_rcslotdone949
bb_rcslotdrop949:
  %v4595 = load i64, ptr %slot17, align 8
  %p4596 = inttoptr i64 %v4595 to ptr
  store i32 0, ptr %p4596, align 4, !alias.scope !3, !noalias !4
  %v4597 = load i64, ptr %slot26, align 8
  store i64 %v4597, ptr %slot720, align 8
  %v4598 = load i64, ptr %slot18, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %ld4600 = load i32, ptr %p4599, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4600, ptr %slot721, align 8
  %v4601 = load i32, ptr %slot721, align 8
  %op4602 = and i32 %v4601, 28
  store i32 %op4602, ptr %slot722, align 8
  %v4603 = load i32, ptr %slot722, align 8
  %cv4604 = zext i32 %v4603 to i64
  %cond4605 = icmp ne i64 %cv4604, 0
  br i1 %cond4605, label %bb_rcslotrole949, label %bb_rcslotowner949
bb_rcslotrole949:
  %v4606 = load i64, ptr %slot66, align 8
  store i64 %v4606, ptr %slot723, align 8
  %v4607 = load i64, ptr %slot723, align 8
  %v4608 = load i64, ptr %slot720, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4607, i64 %v4608) nomerge, !dbg !152
  br label %bb_rcslotdone949
bb_rcslotowner949:
  %v4609 = load i64, ptr %slot66, align 8
  store i64 %v4609, ptr %slot724, align 8
  %v4610 = load i64, ptr %slot724, align 8
  %v4611 = load i64, ptr %slot720, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4610, i64 %v4611) nomerge, !dbg !152
  br label %bb_rcslotdone949
bb_rcslotdone949:
  %v4612 = load i64, ptr %slot19, align 8
  %p4613 = inttoptr i64 %v4612 to ptr
  %ld4614 = load i32, ptr %p4613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4614, ptr %slot725, align 8
  %v4615 = load i32, ptr %slot725, align 8
  %cv4616 = zext i32 %v4615 to i64
  %cond4617 = icmp ne i64 %cv4616, 0
  br i1 %cond4617, label %bb_rcslotdrop958, label %bb_rcslotdone958
bb_rcslotdrop958:
  %v4618 = load i64, ptr %slot19, align 8
  %p4619 = inttoptr i64 %v4618 to ptr
  store i32 0, ptr %p4619, align 4, !alias.scope !3, !noalias !4
  %v4620 = load i64, ptr %slot27, align 8
  store i64 %v4620, ptr %slot726, align 8
  %v4621 = load i64, ptr %slot20, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  %ld4623 = load i32, ptr %p4622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4623, ptr %slot727, align 8
  %v4624 = load i32, ptr %slot727, align 8
  %op4625 = and i32 %v4624, 28
  store i32 %op4625, ptr %slot728, align 8
  %v4626 = load i32, ptr %slot728, align 8
  %cv4627 = zext i32 %v4626 to i64
  %cond4628 = icmp ne i64 %cv4627, 0
  br i1 %cond4628, label %bb_rcslotrole958, label %bb_rcslotowner958
bb_rcslotrole958:
  %v4629 = load i64, ptr %slot66, align 8
  store i64 %v4629, ptr %slot729, align 8
  %v4630 = load i64, ptr %slot729, align 8
  %v4631 = load i64, ptr %slot726, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v4630, i64 %v4631) nomerge, !dbg !152
  br label %bb_rcslotdone958
bb_rcslotowner958:
  %v4632 = load i64, ptr %slot66, align 8
  store i64 %v4632, ptr %slot730, align 8
  %v4633 = load i64, ptr %slot730, align 8
  %v4634 = load i64, ptr %slot726, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v4633, i64 %v4634) nomerge, !dbg !152
  br label %bb_rcslotdone958
bb_rcslotdone958:
  %v4635 = load i64, ptr %slot26, align 8
  store i64 %v4635, ptr %slot731, align 8
  %v4636 = load i64, ptr %slot31, align 8
  store i64 %v4636, ptr %slot732, align 8
  %v4637 = load i64, ptr %slot732, align 8
  %v4638 = load i64, ptr %slot731, align 8
  %p4639 = inttoptr i64 %v4637 to ptr
  %p4640 = inttoptr i64 %v4638 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4640, ptr %p4639, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4641 = load i64, ptr %slot18, align 8
  %p4642 = inttoptr i64 %v4641 to ptr
  store i32 2, ptr %p4642, align 4, !alias.scope !3, !noalias !4
  %v4643 = load i64, ptr %slot24, align 8
  %p4644 = inttoptr i64 %v4643 to ptr
  %ld4645 = load i32, ptr %p4644, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4645, ptr %slot733, align 8
  %v4646 = load i32, ptr %slot733, align 8
  %v4647 = load i64, ptr %slot18, align 8
  %p4648 = inttoptr i64 %v4647 to ptr
  store i32 %v4646, ptr %p4648, align 4, !alias.scope !3, !noalias !4
  %v4649 = load i64, ptr %slot23, align 8
  %p4650 = inttoptr i64 %v4649 to ptr
  store i32 0, ptr %p4650, align 4, !alias.scope !3, !noalias !4
  %v4651 = load i64, ptr %slot17, align 8
  %p4652 = inttoptr i64 %v4651 to ptr
  store i32 1, ptr %p4652, align 4, !alias.scope !3, !noalias !4
  %v4653 = load i64, ptr %slot731, align 8
  %v4654 = load i64, ptr %slot54, align 8
  %p4655 = inttoptr i64 %v4654 to ptr
  store i64 %v4653, ptr %p4655, align 8, !alias.scope !3, !noalias !4
  %v4656 = load i64, ptr %slot54, align 8
  %p4657 = inttoptr i64 %v4656 to ptr
  %ld4658 = load i64, ptr %p4657, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4658, ptr %slot734, align 8
  %v4659 = load i64, ptr %slot17, align 8
  %p4660 = inttoptr i64 %v4659 to ptr
  %ld4661 = load i32, ptr %p4660, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4661, ptr %slot735, align 8
  %v4662 = load i64, ptr %slot18, align 8
  %p4663 = inttoptr i64 %v4662 to ptr
  %ld4664 = load i32, ptr %p4663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4664, ptr %slot736, align 8
  %v4665 = load i32, ptr %slot736, align 8
  %op4666 = and i32 %v4665, 24
  store i32 %op4666, ptr %slot736, align 8
  %v4667 = load i32, ptr %slot736, align 8
  %cmp4668 = icmp eq i32 %v4667, 0
  %cv4669 = zext i1 %cmp4668 to i32
  store i32 %cv4669, ptr %slot737, align 8
  %v4670 = load i32, ptr %slot735, align 8
  %v4671 = load i32, ptr %slot737, align 8
  %op4672 = and i32 %v4670, %v4671
  store i32 %op4672, ptr %slot738, align 8
  %v4673 = load i32, ptr %slot738, align 8
  %cv4674 = zext i32 %v4673 to i64
  %cond4675 = icmp ne i64 %cv4674, 0
  br i1 %cond4675, label %bb_rctake974, label %bb_rccopy974
bb_rctake974:
  %v4676 = load i64, ptr %slot31, align 8
  store i64 %v4676, ptr %slot739, align 8
  %v4677 = load i64, ptr %slot67, align 8
  store i64 %v4677, ptr %slot740, align 8
  %v4678 = load i64, ptr %slot66, align 8
  %v4679 = load i64, ptr %slot739, align 8
  %v4680 = load i64, ptr %slot734, align 8
  %v4681 = load i64, ptr %slot740, align 8
  %cv4682 = trunc i64 %v4681 to i32
  %call4683 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v4678, i64 %v4679, i64 %v4680, i32 %cv4682) nomerge, !dbg !154
  store i32 %call4683, ptr %slot741, align 8
  %v4684 = load i32, ptr %slot741, align 8
  %cv4685 = zext i32 %v4684 to i64
  %cond4686 = icmp ne i64 %cv4685, 0
  br i1 %cond4686, label %bb_rcsuccess984, label %bb_rcfailure984
bb_rcfailure984:
  %v4687 = load i64, ptr %slot66, align 8
  %p4688 = inttoptr i64 %v4687 to ptr
  %call4689 = call i32 @myl_rc_take_failure(ptr %p4688) nomerge, !dbg !154
  store i32 %call4689, ptr %slot742, align 8
  %v4690 = load i64, ptr %slot1, align 8
  %p4691 = inttoptr i64 %v4690 to ptr
  %v4692 = load i32, ptr %slot742, align 8
  %call4693 = call i32 @myl_qbe_rc_status(ptr %p4691, i32 %v4692) nomerge, !dbg !154
  store i32 %call4693, ptr %slot743, align 8
  br label %bb_failure
bb_rcsuccess984:
  %v4694 = load i64, ptr %slot17, align 8
  %p4695 = inttoptr i64 %v4694 to ptr
  store i32 0, ptr %p4695, align 4, !alias.scope !3, !noalias !4
  %v4696 = load i64, ptr %slot24, align 8
  %p4697 = inttoptr i64 %v4696 to ptr
  store i32 2, ptr %p4697, align 4, !alias.scope !3, !noalias !4
  %v4698 = load i64, ptr %slot23, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  store i32 1, ptr %p4699, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared974
bb_rccopy974:
  %v4700 = load i64, ptr %slot31, align 8
  store i64 %v4700, ptr %slot744, align 8
  %v4701 = load i64, ptr %slot67, align 8
  store i64 %v4701, ptr %slot745, align 8
  %v4702 = load i64, ptr %slot66, align 8
  %v4703 = load i64, ptr %slot744, align 8
  %v4704 = load i64, ptr %slot734, align 8
  %v4705 = load i64, ptr %slot745, align 8
  %cv4706 = trunc i64 %v4705 to i32
  %call4707 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64 %v4702, i64 %v4703, i64 %v4704, i32 %cv4706) nomerge, !dbg !154
  store i32 %call4707, ptr %slot746, align 8
  %v4708 = load i32, ptr %slot746, align 8
  %cv4709 = zext i32 %v4708 to i64
  %cond4710 = icmp ne i64 %cv4709, 0
  br i1 %cond4710, label %bb_rcsuccess993, label %bb_rcfailure993
bb_rcfailure993:
  %v4711 = load i64, ptr %slot66, align 8
  %p4712 = inttoptr i64 %v4711 to ptr
  %call4713 = call i32 @myl_rc_take_failure(ptr %p4712) nomerge, !dbg !154
  store i32 %call4713, ptr %slot747, align 8
  %v4714 = load i64, ptr %slot1, align 8
  %p4715 = inttoptr i64 %v4714 to ptr
  %v4716 = load i32, ptr %slot747, align 8
  %call4717 = call i32 @myl_qbe_rc_status(ptr %p4715, i32 %v4716) nomerge, !dbg !154
  store i32 %call4717, ptr %slot748, align 8
  br label %bb_failure
bb_rcsuccess993:
  %v4718 = load i64, ptr %slot24, align 8
  %p4719 = inttoptr i64 %v4718 to ptr
  store i32 2, ptr %p4719, align 4, !alias.scope !3, !noalias !4
  %v4720 = load i64, ptr %slot23, align 8
  %p4721 = inttoptr i64 %v4720 to ptr
  store i32 1, ptr %p4721, align 4, !alias.scope !3, !noalias !4
  %v4722 = load i64, ptr %slot17, align 8
  %p4723 = inttoptr i64 %v4722 to ptr
  %ld4724 = load i32, ptr %p4723, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4724, ptr %slot749, align 8
  %v4725 = load i32, ptr %slot749, align 8
  %cv4726 = zext i32 %v4725 to i64
  %cond4727 = icmp ne i64 %cv4726, 0
  br i1 %cond4727, label %bb_rcslotdrop1000, label %bb_rcslotdone1000
bb_rcslotdrop1000:
  %v4728 = load i64, ptr %slot17, align 8
  %p4729 = inttoptr i64 %v4728 to ptr
  store i32 0, ptr %p4729, align 4, !alias.scope !3, !noalias !4
  %v4730 = load i64, ptr %slot26, align 8
  store i64 %v4730, ptr %slot750, align 8
  %v4731 = load i64, ptr %slot18, align 8
  %p4732 = inttoptr i64 %v4731 to ptr
  %ld4733 = load i32, ptr %p4732, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4733, ptr %slot751, align 8
  %v4734 = load i32, ptr %slot751, align 8
  %op4735 = and i32 %v4734, 28
  store i32 %op4735, ptr %slot752, align 8
  %v4736 = load i32, ptr %slot752, align 8
  %cv4737 = zext i32 %v4736 to i64
  %cond4738 = icmp ne i64 %cv4737, 0
  br i1 %cond4738, label %bb_rcslotrole1000, label %bb_rcslotowner1000
bb_rcslotrole1000:
  %v4739 = load i64, ptr %slot66, align 8
  store i64 %v4739, ptr %slot753, align 8
  %v4740 = load i64, ptr %slot753, align 8
  %v4741 = load i64, ptr %slot750, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4740, i64 %v4741) nomerge, !dbg !154
  br label %bb_rcslotdone1000
bb_rcslotowner1000:
  %v4742 = load i64, ptr %slot66, align 8
  store i64 %v4742, ptr %slot754, align 8
  %v4743 = load i64, ptr %slot754, align 8
  %v4744 = load i64, ptr %slot750, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4743, i64 %v4744) nomerge, !dbg !154
  br label %bb_rcslotdone1000
bb_rcslotdone1000:
  br label %bb_rcprepared974
bb_rcprepared974:
  %v4745 = load i64, ptr %slot7, align 8
  %p4746 = inttoptr i64 %v4745 to ptr
  %ld4747 = load i32, ptr %p4746, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4747, ptr %slot755, align 8
  %v4748 = load i32, ptr %slot755, align 8
  %cv4749 = zext i32 %v4748 to i64
  %cond4750 = icmp ne i64 %cv4749, 0
  br i1 %cond4750, label %bb_rcslotdrop1010, label %bb_rcslotdone1010
bb_rcslotdrop1010:
  %v4751 = load i64, ptr %slot7, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  store i32 0, ptr %p4752, align 4, !alias.scope !3, !noalias !4
  %v4753 = load i64, ptr %slot45, align 8
  store i64 %v4753, ptr %slot756, align 8
  %v4754 = load i64, ptr %slot8, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  %ld4756 = load i32, ptr %p4755, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4756, ptr %slot757, align 8
  %v4757 = load i32, ptr %slot757, align 8
  %op4758 = and i32 %v4757, 28
  store i32 %op4758, ptr %slot758, align 8
  %v4759 = load i32, ptr %slot758, align 8
  %cv4760 = zext i32 %v4759 to i64
  %cond4761 = icmp ne i64 %cv4760, 0
  br i1 %cond4761, label %bb_rcslotrole1010, label %bb_rcslotowner1010
bb_rcslotrole1010:
  %v4762 = load i64, ptr %slot66, align 8
  store i64 %v4762, ptr %slot759, align 8
  %v4763 = load i64, ptr %slot759, align 8
  %v4764 = load i64, ptr %slot756, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4763, i64 %v4764) nomerge, !dbg !154
  br label %bb_rcslotdone1010
bb_rcslotowner1010:
  %v4765 = load i64, ptr %slot66, align 8
  store i64 %v4765, ptr %slot760, align 8
  %v4766 = load i64, ptr %slot760, align 8
  %v4767 = load i64, ptr %slot756, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4766, i64 %v4767) nomerge, !dbg !154
  br label %bb_rcslotdone1010
bb_rcslotdone1010:
  %v4768 = load i64, ptr %slot45, align 8
  store i64 %v4768, ptr %slot761, align 8
  %v4769 = load i64, ptr %slot31, align 8
  store i64 %v4769, ptr %slot762, align 8
  %v4770 = load i64, ptr %slot762, align 8
  %v4771 = load i64, ptr %slot761, align 8
  %p4772 = inttoptr i64 %v4770 to ptr
  %p4773 = inttoptr i64 %v4771 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4773, ptr %p4772, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4774 = load i64, ptr %slot23, align 8
  %p4775 = inttoptr i64 %v4774 to ptr
  store i32 0, ptr %p4775, align 4, !alias.scope !3, !noalias !4
  %v4776 = load i64, ptr %slot8, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  store i32 2, ptr %p4777, align 4, !alias.scope !3, !noalias !4
  %v4778 = load i64, ptr %slot24, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  %ld4780 = load i32, ptr %p4779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4780, ptr %slot763, align 8
  %v4781 = load i32, ptr %slot763, align 8
  %v4782 = load i64, ptr %slot8, align 8
  %p4783 = inttoptr i64 %v4782 to ptr
  store i32 %v4781, ptr %p4783, align 4, !alias.scope !3, !noalias !4
  %v4784 = load i64, ptr %slot7, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  store i32 1, ptr %p4785, align 4, !alias.scope !3, !noalias !4
  %v4786 = load i64, ptr %slot54, align 8
  %p4787 = inttoptr i64 %v4786 to ptr
  store i64 0, ptr %p4787, align 8, !alias.scope !3, !noalias !4
  %v4788 = load i64, ptr %slot45, align 8
  %v4789 = load i64, ptr %slot54, align 8
  %p4790 = inttoptr i64 %v4789 to ptr
  store i64 %v4788, ptr %p4790, align 8, !alias.scope !3, !noalias !4
  %v4791 = load i64, ptr %slot54, align 8
  %p4792 = inttoptr i64 %v4791 to ptr
  %ld4793 = load i64, ptr %p4792, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4793, ptr %slot764, align 8
  %v4794 = load i64, ptr %slot17, align 8
  %p4795 = inttoptr i64 %v4794 to ptr
  %ld4796 = load i32, ptr %p4795, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4796, ptr %slot765, align 8
  %v4797 = load i64, ptr %slot18, align 8
  %p4798 = inttoptr i64 %v4797 to ptr
  %ld4799 = load i32, ptr %p4798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4799, ptr %slot766, align 8
  %v4800 = load i32, ptr %slot766, align 8
  %op4801 = and i32 %v4800, 24
  store i32 %op4801, ptr %slot766, align 8
  %v4802 = load i32, ptr %slot766, align 8
  %cmp4803 = icmp eq i32 %v4802, 0
  %cv4804 = zext i1 %cmp4803 to i32
  store i32 %cv4804, ptr %slot767, align 8
  %v4805 = load i32, ptr %slot765, align 8
  %v4806 = load i32, ptr %slot767, align 8
  %op4807 = and i32 %v4805, %v4806
  store i32 %op4807, ptr %slot768, align 8
  %v4808 = load i32, ptr %slot768, align 8
  %cv4809 = zext i32 %v4808 to i64
  %cond4810 = icmp ne i64 %cv4809, 0
  br i1 %cond4810, label %bb_rcprivateown1031, label %bb_rcprivateloan1031
bb_rcprivateown1031:
  %v4811 = load i64, ptr %slot31, align 8
  store i64 %v4811, ptr %slot769, align 8
  %v4812 = load i64, ptr %slot67, align 8
  store i64 %v4812, ptr %slot770, align 8
  %v4813 = load i64, ptr %slot66, align 8
  %v4814 = load i64, ptr %slot769, align 8
  %v4815 = load i64, ptr %slot764, align 8
  %v4816 = load i64, ptr %slot770, align 8
  %cv4817 = trunc i64 %v4816 to i32
  %call4818 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v4813, i64 %v4814, i64 %v4815, i32 %cv4817) nomerge, !dbg !156
  store i32 %call4818, ptr %slot771, align 8
  %v4819 = load i32, ptr %slot771, align 8
  %cv4820 = zext i32 %v4819 to i64
  %cond4821 = icmp ne i64 %cv4820, 0
  br i1 %cond4821, label %bb_rcsuccess1035, label %bb_rcfailure1035
bb_rcfailure1035:
  %v4822 = load i64, ptr %slot66, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  %call4824 = call i32 @myl_rc_take_failure(ptr %p4823) nomerge, !dbg !156
  store i32 %call4824, ptr %slot772, align 8
  %v4825 = load i64, ptr %slot1, align 8
  %p4826 = inttoptr i64 %v4825 to ptr
  %v4827 = load i32, ptr %slot772, align 8
  %call4828 = call i32 @myl_qbe_rc_status(ptr %p4826, i32 %v4827) nomerge, !dbg !156
  store i32 %call4828, ptr %slot773, align 8
  br label %bb_failure
bb_rcsuccess1035:
  %v4829 = load i64, ptr %slot17, align 8
  %p4830 = inttoptr i64 %v4829 to ptr
  store i32 0, ptr %p4830, align 4, !alias.scope !3, !noalias !4
  %v4831 = load i64, ptr %slot24, align 8
  %p4832 = inttoptr i64 %v4831 to ptr
  store i32 2, ptr %p4832, align 4, !alias.scope !3, !noalias !4
  %v4833 = load i64, ptr %slot23, align 8
  %p4834 = inttoptr i64 %v4833 to ptr
  store i32 1, ptr %p4834, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1031
bb_rcprivateloan1031:
  %v4835 = load i64, ptr %slot31, align 8
  store i64 %v4835, ptr %slot774, align 8
  %v4836 = load i64, ptr %slot66, align 8
  %v4837 = load i64, ptr %slot774, align 8
  %v4838 = load i64, ptr %slot764, align 8
  %call4839 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64 %v4836, i64 %v4837, i64 %v4838) nomerge, !dbg !156
  store i32 %call4839, ptr %slot775, align 8
  %v4840 = load i32, ptr %slot775, align 8
  %cv4841 = zext i32 %v4840 to i64
  %cond4842 = icmp ne i64 %cv4841, 0
  br i1 %cond4842, label %bb_rcsuccess1043, label %bb_rcfailure1043
bb_rcfailure1043:
  %v4843 = load i64, ptr %slot66, align 8
  %p4844 = inttoptr i64 %v4843 to ptr
  %call4845 = call i32 @myl_rc_take_failure(ptr %p4844) nomerge, !dbg !156
  store i32 %call4845, ptr %slot776, align 8
  %v4846 = load i64, ptr %slot1, align 8
  %p4847 = inttoptr i64 %v4846 to ptr
  %v4848 = load i32, ptr %slot776, align 8
  %call4849 = call i32 @myl_qbe_rc_status(ptr %p4847, i32 %v4848) nomerge, !dbg !156
  store i32 %call4849, ptr %slot777, align 8
  br label %bb_failure
bb_rcsuccess1043:
  %v4850 = load i64, ptr %slot24, align 8
  %p4851 = inttoptr i64 %v4850 to ptr
  store i32 2, ptr %p4851, align 4, !alias.scope !3, !noalias !4
  %v4852 = load i64, ptr %slot24, align 8
  %p4853 = inttoptr i64 %v4852 to ptr
  store i32 16, ptr %p4853, align 4, !alias.scope !3, !noalias !4
  %v4854 = load i64, ptr %slot23, align 8
  %p4855 = inttoptr i64 %v4854 to ptr
  store i32 1, ptr %p4855, align 4, !alias.scope !3, !noalias !4
  %v4856 = load i64, ptr %slot17, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  %ld4858 = load i32, ptr %p4857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4858, ptr %slot778, align 8
  %v4859 = load i32, ptr %slot778, align 8
  %cv4860 = zext i32 %v4859 to i64
  %cond4861 = icmp ne i64 %cv4860, 0
  br i1 %cond4861, label %bb_rcslotdrop1051, label %bb_rcslotdone1051
bb_rcslotdrop1051:
  %v4862 = load i64, ptr %slot17, align 8
  %p4863 = inttoptr i64 %v4862 to ptr
  store i32 0, ptr %p4863, align 4, !alias.scope !3, !noalias !4
  %v4864 = load i64, ptr %slot26, align 8
  store i64 %v4864, ptr %slot779, align 8
  %v4865 = load i64, ptr %slot18, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  %ld4867 = load i32, ptr %p4866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4867, ptr %slot780, align 8
  %v4868 = load i32, ptr %slot780, align 8
  %op4869 = and i32 %v4868, 28
  store i32 %op4869, ptr %slot781, align 8
  %v4870 = load i32, ptr %slot781, align 8
  %cv4871 = zext i32 %v4870 to i64
  %cond4872 = icmp ne i64 %cv4871, 0
  br i1 %cond4872, label %bb_rcslotrole1051, label %bb_rcslotowner1051
bb_rcslotrole1051:
  %v4873 = load i64, ptr %slot66, align 8
  store i64 %v4873, ptr %slot782, align 8
  %v4874 = load i64, ptr %slot782, align 8
  %v4875 = load i64, ptr %slot779, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4874, i64 %v4875) nomerge, !dbg !156
  br label %bb_rcslotdone1051
bb_rcslotowner1051:
  %v4876 = load i64, ptr %slot66, align 8
  store i64 %v4876, ptr %slot783, align 8
  %v4877 = load i64, ptr %slot783, align 8
  %v4878 = load i64, ptr %slot779, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4877, i64 %v4878) nomerge, !dbg !156
  br label %bb_rcslotdone1051
bb_rcslotdone1051:
  br label %bb_rcprivateprepared1031
bb_rcprivateprepared1031:
  %v4879 = load i64, ptr %slot13, align 8
  %p4880 = inttoptr i64 %v4879 to ptr
  %ld4881 = load i32, ptr %p4880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4881, ptr %slot784, align 8
  %v4882 = load i32, ptr %slot784, align 8
  %cv4883 = zext i32 %v4882 to i64
  %cond4884 = icmp ne i64 %cv4883, 0
  br i1 %cond4884, label %bb_rcslotdrop1061, label %bb_rcslotdone1061
bb_rcslotdrop1061:
  %v4885 = load i64, ptr %slot13, align 8
  %p4886 = inttoptr i64 %v4885 to ptr
  store i32 0, ptr %p4886, align 4, !alias.scope !3, !noalias !4
  %v4887 = load i64, ptr %slot49, align 8
  store i64 %v4887, ptr %slot785, align 8
  %v4888 = load i64, ptr %slot14, align 8
  %p4889 = inttoptr i64 %v4888 to ptr
  %ld4890 = load i32, ptr %p4889, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4890, ptr %slot786, align 8
  %v4891 = load i32, ptr %slot786, align 8
  %op4892 = and i32 %v4891, 28
  store i32 %op4892, ptr %slot787, align 8
  %v4893 = load i32, ptr %slot787, align 8
  %cv4894 = zext i32 %v4893 to i64
  %cond4895 = icmp ne i64 %cv4894, 0
  br i1 %cond4895, label %bb_rcslotrole1061, label %bb_rcslotowner1061
bb_rcslotrole1061:
  %v4896 = load i64, ptr %slot66, align 8
  store i64 %v4896, ptr %slot788, align 8
  %v4897 = load i64, ptr %slot788, align 8
  %v4898 = load i64, ptr %slot785, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4897, i64 %v4898) nomerge, !dbg !156
  br label %bb_rcslotdone1061
bb_rcslotowner1061:
  %v4899 = load i64, ptr %slot66, align 8
  store i64 %v4899, ptr %slot789, align 8
  %v4900 = load i64, ptr %slot789, align 8
  %v4901 = load i64, ptr %slot785, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4900, i64 %v4901) nomerge, !dbg !156
  br label %bb_rcslotdone1061
bb_rcslotdone1061:
  %v4902 = load i64, ptr %slot49, align 8
  store i64 %v4902, ptr %slot790, align 8
  %v4903 = load i64, ptr %slot31, align 8
  store i64 %v4903, ptr %slot791, align 8
  %v4904 = load i64, ptr %slot791, align 8
  %v4905 = load i64, ptr %slot790, align 8
  %p4906 = inttoptr i64 %v4904 to ptr
  %p4907 = inttoptr i64 %v4905 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4907, ptr %p4906, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v4908 = load i64, ptr %slot23, align 8
  %p4909 = inttoptr i64 %v4908 to ptr
  store i32 0, ptr %p4909, align 4, !alias.scope !3, !noalias !4
  %v4910 = load i64, ptr %slot14, align 8
  %p4911 = inttoptr i64 %v4910 to ptr
  store i32 2, ptr %p4911, align 4, !alias.scope !3, !noalias !4
  %v4912 = load i64, ptr %slot24, align 8
  %p4913 = inttoptr i64 %v4912 to ptr
  %ld4914 = load i32, ptr %p4913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4914, ptr %slot792, align 8
  %v4915 = load i32, ptr %slot792, align 8
  %v4916 = load i64, ptr %slot14, align 8
  %p4917 = inttoptr i64 %v4916 to ptr
  store i32 %v4915, ptr %p4917, align 4, !alias.scope !3, !noalias !4
  %v4918 = load i64, ptr %slot13, align 8
  %p4919 = inttoptr i64 %v4918 to ptr
  store i32 1, ptr %p4919, align 4, !alias.scope !3, !noalias !4
  %v4920 = load i64, ptr %slot37, align 8
  %p4921 = inttoptr i64 %v4920 to ptr
  %ld4922 = load i64, ptr %p4921, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4922, ptr %slot793, align 8
  %v4923 = load i64, ptr %slot793, align 8
  %v4924 = load i64, ptr %slot54, align 8
  %p4925 = inttoptr i64 %v4924 to ptr
  store i64 %v4923, ptr %p4925, align 8, !alias.scope !3, !noalias !4
  %v4926 = load i64, ptr %slot54, align 8
  %p4927 = inttoptr i64 %v4926 to ptr
  %ld4928 = load i64, ptr %p4927, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4928, ptr %slot794, align 8
  %v4929 = load i64, ptr %slot794, align 8
  %op4930 = add i64 %v4929, 376
  store i64 %op4930, ptr %slot795, align 8
  %v4931 = load i64, ptr %slot795, align 8
  %p4932 = inttoptr i64 %v4931 to ptr
  %ld4933 = load i64, ptr %p4932, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4933, ptr %slot796, align 8
  %v4934 = load i64, ptr %slot796, align 8
  %v4935 = load i64, ptr %slot54, align 8
  %p4936 = inttoptr i64 %v4935 to ptr
  store i64 %v4934, ptr %p4936, align 8, !alias.scope !3, !noalias !4
  %v4937 = load i64, ptr %slot17, align 8
  %p4938 = inttoptr i64 %v4937 to ptr
  %ld4939 = load i32, ptr %p4938, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4939, ptr %slot797, align 8
  %v4940 = load i32, ptr %slot797, align 8
  %cv4941 = zext i32 %v4940 to i64
  %cond4942 = icmp ne i64 %cv4941, 0
  br i1 %cond4942, label %bb_rcslotdrop1081, label %bb_rcslotdone1081
bb_rcslotdrop1081:
  %v4943 = load i64, ptr %slot17, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  store i32 0, ptr %p4944, align 4, !alias.scope !3, !noalias !4
  %v4945 = load i64, ptr %slot26, align 8
  store i64 %v4945, ptr %slot798, align 8
  %v4946 = load i64, ptr %slot18, align 8
  %p4947 = inttoptr i64 %v4946 to ptr
  %ld4948 = load i32, ptr %p4947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4948, ptr %slot799, align 8
  %v4949 = load i32, ptr %slot799, align 8
  %op4950 = and i32 %v4949, 28
  store i32 %op4950, ptr %slot800, align 8
  %v4951 = load i32, ptr %slot800, align 8
  %cv4952 = zext i32 %v4951 to i64
  %cond4953 = icmp ne i64 %cv4952, 0
  br i1 %cond4953, label %bb_rcslotrole1081, label %bb_rcslotowner1081
bb_rcslotrole1081:
  %v4954 = load i64, ptr %slot66, align 8
  store i64 %v4954, ptr %slot801, align 8
  %v4955 = load i64, ptr %slot801, align 8
  %v4956 = load i64, ptr %slot798, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v4955, i64 %v4956) nomerge, !dbg !158
  br label %bb_rcslotdone1081
bb_rcslotowner1081:
  %v4957 = load i64, ptr %slot66, align 8
  store i64 %v4957, ptr %slot802, align 8
  %v4958 = load i64, ptr %slot802, align 8
  %v4959 = load i64, ptr %slot798, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v4958, i64 %v4959) nomerge, !dbg !158
  br label %bb_rcslotdone1081
bb_rcslotdone1081:
  %v4960 = load i64, ptr %slot54, align 8
  %p4961 = inttoptr i64 %v4960 to ptr
  %ld4962 = load i64, ptr %p4961, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4962, ptr %slot803, align 8
  %v4963 = load i64, ptr %slot37, align 8
  %p4964 = inttoptr i64 %v4963 to ptr
  %ld4965 = load i64, ptr %p4964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4965, ptr %slot804, align 8
  %v4966 = load i64, ptr %slot17, align 8
  %p4967 = inttoptr i64 %v4966 to ptr
  %ld4968 = load i32, ptr %p4967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4968, ptr %slot805, align 8
  %v4969 = load i32, ptr %slot805, align 8
  %cv4970 = zext i32 %v4969 to i64
  %cond4971 = icmp ne i64 %cv4970, 0
  br i1 %cond4971, label %bb_rcslotdrop1093, label %bb_rcslotdone1093
bb_rcslotdrop1093:
  %v4972 = load i64, ptr %slot17, align 8
  %p4973 = inttoptr i64 %v4972 to ptr
  store i32 0, ptr %p4973, align 4, !alias.scope !3, !noalias !4
  %v4974 = load i64, ptr %slot26, align 8
  store i64 %v4974, ptr %slot806, align 8
  %v4975 = load i64, ptr %slot18, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  %ld4977 = load i32, ptr %p4976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4977, ptr %slot807, align 8
  %v4978 = load i32, ptr %slot807, align 8
  %op4979 = and i32 %v4978, 28
  store i32 %op4979, ptr %slot808, align 8
  %v4980 = load i32, ptr %slot808, align 8
  %cv4981 = zext i32 %v4980 to i64
  %cond4982 = icmp ne i64 %cv4981, 0
  br i1 %cond4982, label %bb_rcslotrole1093, label %bb_rcslotowner1093
bb_rcslotrole1093:
  %v4983 = load i64, ptr %slot66, align 8
  store i64 %v4983, ptr %slot809, align 8
  %v4984 = load i64, ptr %slot806, align 8
  %p4985 = inttoptr i64 %v4984 to ptr
  %ld4986 = load i64, ptr %p4985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4986, ptr %slot810, align 8
  %v4987 = load i64, ptr %slot810, align 8
  %cmp4988 = icmp ne i64 %v4987, 0
  %cv4989 = zext i1 %cmp4988 to i32
  store i32 %cv4989, ptr %slot811, align 8
  %v4990 = load i32, ptr %slot811, align 8
  %cv4991 = zext i32 %v4990 to i64
  %cond4992 = icmp ne i64 %cv4991, 0
  br i1 %cond4992, label %bb_rcgnn1109, label %bb_rcgdone1109
bb_rcgnn1109:
  %v4993 = load i64, ptr %slot810, align 8
  %op4994 = sub i64 %v4993, 16
  store i64 %op4994, ptr %slot812, align 8
  %v4995 = load i64, ptr %slot810, align 8
  %p4996 = inttoptr i64 %v4995 to ptr
  %rgep4997 = getelementptr i8, ptr %p4996, i64 -16
  %ld4998 = load i64, ptr %rgep4997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4998, ptr %slot813, align 8
  %v4999 = load i64, ptr %slot813, align 8
  %op5000 = and i64 %v4999, 4611686018427387906
  store i64 %op5000, ptr %slot814, align 8
  %v5001 = load i64, ptr %slot814, align 8
  %cmp5002 = icmp ne i64 %v5001, 0
  %cv5003 = zext i1 %cmp5002 to i32
  store i32 %cv5003, ptr %slot815, align 8
  %v5004 = load i32, ptr %slot815, align 8
  %cv5005 = zext i32 %v5004 to i64
  %cond5006 = icmp ne i64 %cv5005, 0
  br i1 %cond5006, label %bb_rcgclear1109, label %bb_rcgcounted1109
bb_rcgcounted1109:
  %v5007 = load i64, ptr %slot810, align 8
  %op5008 = sub i64 %v5007, 24
  store i64 %op5008, ptr %slot816, align 8
  %v5009 = load i64, ptr %slot810, align 8
  %p5010 = inttoptr i64 %v5009 to ptr
  %rgep5011 = getelementptr i8, ptr %p5010, i64 -24
  %ld5012 = load i64, ptr %rgep5011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5012, ptr %slot817, align 8
  %v5013 = load i64, ptr %slot817, align 8
  %op5014 = sub i64 %v5013, 1
  store i64 %op5014, ptr %slot818, align 8
  %v5015 = load i64, ptr %slot818, align 8
  %cmp5016 = icmp eq i64 %v5015, 0
  %cv5017 = zext i1 %cmp5016 to i32
  store i32 %cv5017, ptr %slot819, align 8
  %v5018 = load i32, ptr %slot819, align 8
  %cv5019 = zext i32 %v5018 to i64
  %cond5020 = icmp ne i64 %cv5019, 0
  br i1 %cond5020, label %bb_rcglast1109, label %bb_rcgdec1109
bb_rcglast1109:
  %v5021 = load i64, ptr %slot810, align 8
  %op5022 = sub i64 %v5021, 32
  store i64 %op5022, ptr %slot820, align 8
  %v5023 = load i64, ptr %slot810, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  %rgep5025 = getelementptr i8, ptr %p5024, i64 -32
  %ld5026 = load i64, ptr %rgep5025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5026, ptr %slot821, align 8
  %v5027 = load i64, ptr %slot821, align 8
  %cmp5028 = icmp ne i64 %v5027, 0
  %cv5029 = zext i1 %cmp5028 to i32
  store i32 %cv5029, ptr %slot822, align 8
  %v5030 = load i32, ptr %slot822, align 8
  %cv5031 = zext i32 %v5030 to i64
  %cond5032 = icmp ne i64 %cv5031, 0
  br i1 %cond5032, label %bb_rcgdec1109, label %bb_rcgslow1109
bb_rcgslow1109:
  %v5033 = load i64, ptr %slot809, align 8
  %v5034 = load i64, ptr %slot806, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v5033, i64 %v5034) nomerge, !dbg !160
  br label %bb_rcgdone1109
bb_rcgdec1109:
  %v5035 = load i64, ptr %slot818, align 8
  %v5036 = load i64, ptr %slot810, align 8
  %p5037 = inttoptr i64 %v5036 to ptr
  %rgep5038 = getelementptr i8, ptr %p5037, i64 -24
  store i64 %v5035, ptr %rgep5038, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1109
bb_rcgclear1109:
  %v5039 = load i64, ptr %slot806, align 8
  %p5040 = inttoptr i64 %v5039 to ptr
  store i64 0, ptr %p5040, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1109
bb_rcgdone1109:
  br label %bb_rcslotdone1093
bb_rcslotowner1093:
  %v5041 = load i64, ptr %slot66, align 8
  store i64 %v5041, ptr %slot823, align 8
  %v5042 = load i64, ptr %slot806, align 8
  %p5043 = inttoptr i64 %v5042 to ptr
  %ld5044 = load i64, ptr %p5043, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5044, ptr %slot824, align 8
  %v5045 = load i64, ptr %slot824, align 8
  %cmp5046 = icmp ne i64 %v5045, 0
  %cv5047 = zext i1 %cmp5046 to i32
  store i32 %cv5047, ptr %slot825, align 8
  %v5048 = load i32, ptr %slot825, align 8
  %cv5049 = zext i32 %v5048 to i64
  %cond5050 = icmp ne i64 %cv5049, 0
  br i1 %cond5050, label %bb_rcgnn1124, label %bb_rcgdone1124
bb_rcgnn1124:
  %v5051 = load i64, ptr %slot824, align 8
  %op5052 = sub i64 %v5051, 16
  store i64 %op5052, ptr %slot826, align 8
  %v5053 = load i64, ptr %slot824, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  %rgep5055 = getelementptr i8, ptr %p5054, i64 -16
  %ld5056 = load i64, ptr %rgep5055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5056, ptr %slot827, align 8
  %v5057 = load i64, ptr %slot827, align 8
  %op5058 = and i64 %v5057, 4611686018427387906
  store i64 %op5058, ptr %slot828, align 8
  %v5059 = load i64, ptr %slot828, align 8
  %cmp5060 = icmp ne i64 %v5059, 0
  %cv5061 = zext i1 %cmp5060 to i32
  store i32 %cv5061, ptr %slot829, align 8
  %v5062 = load i32, ptr %slot829, align 8
  %cv5063 = zext i32 %v5062 to i64
  %cond5064 = icmp ne i64 %cv5063, 0
  br i1 %cond5064, label %bb_rcgclear1124, label %bb_rcgcounted1124
bb_rcgcounted1124:
  %v5065 = load i64, ptr %slot824, align 8
  %op5066 = sub i64 %v5065, 32
  store i64 %op5066, ptr %slot830, align 8
  %v5067 = load i64, ptr %slot824, align 8
  %p5068 = inttoptr i64 %v5067 to ptr
  %rgep5069 = getelementptr i8, ptr %p5068, i64 -32
  %ld5070 = load i64, ptr %rgep5069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5070, ptr %slot831, align 8
  %v5071 = load i64, ptr %slot831, align 8
  %op5072 = sub i64 %v5071, 1
  store i64 %op5072, ptr %slot832, align 8
  %v5073 = load i64, ptr %slot832, align 8
  %cmp5074 = icmp eq i64 %v5073, 0
  %cv5075 = zext i1 %cmp5074 to i32
  store i32 %cv5075, ptr %slot833, align 8
  %v5076 = load i32, ptr %slot833, align 8
  %cv5077 = zext i32 %v5076 to i64
  %cond5078 = icmp ne i64 %cv5077, 0
  br i1 %cond5078, label %bb_rcglast1124, label %bb_rcgdec1124
bb_rcglast1124:
  %v5079 = load i64, ptr %slot824, align 8
  %op5080 = sub i64 %v5079, 24
  store i64 %op5080, ptr %slot834, align 8
  %v5081 = load i64, ptr %slot824, align 8
  %p5082 = inttoptr i64 %v5081 to ptr
  %rgep5083 = getelementptr i8, ptr %p5082, i64 -24
  %ld5084 = load i64, ptr %rgep5083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5084, ptr %slot835, align 8
  %v5085 = load i64, ptr %slot835, align 8
  %cmp5086 = icmp ne i64 %v5085, 0
  %cv5087 = zext i1 %cmp5086 to i32
  store i32 %cv5087, ptr %slot836, align 8
  %v5088 = load i32, ptr %slot836, align 8
  %cv5089 = zext i32 %v5088 to i64
  %cond5090 = icmp ne i64 %cv5089, 0
  br i1 %cond5090, label %bb_rcgdec1124, label %bb_rcgslow1124
bb_rcgslow1124:
  %v5091 = load i64, ptr %slot823, align 8
  %v5092 = load i64, ptr %slot806, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v5091, i64 %v5092) nomerge, !dbg !160
  br label %bb_rcgdone1124
bb_rcgdec1124:
  %v5093 = load i64, ptr %slot832, align 8
  %v5094 = load i64, ptr %slot824, align 8
  %p5095 = inttoptr i64 %v5094 to ptr
  %rgep5096 = getelementptr i8, ptr %p5095, i64 -32
  store i64 %v5093, ptr %rgep5096, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1124
bb_rcgclear1124:
  %v5097 = load i64, ptr %slot806, align 8
  %p5098 = inttoptr i64 %v5097 to ptr
  store i64 0, ptr %p5098, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1124
bb_rcgdone1124:
  br label %bb_rcslotdone1093
bb_rcslotdone1093:
  %v5099 = load i64, ptr %slot804, align 8
  %op5100 = add i64 %v5099, 376
  store i64 %op5100, ptr %slot837, align 8
  store i64 0, ptr %slot838, align 8
  %v5101 = load i64, ptr %slot837, align 8
  %p5102 = inttoptr i64 %v5101 to ptr
  %ld5103 = load i64, ptr %p5102, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5103, ptr %slot839, align 8
  %v5104 = load i64, ptr %slot839, align 8
  %cmp5105 = icmp ne i64 %v5104, 0
  %cv5106 = zext i1 %cmp5105 to i32
  store i32 %cv5106, ptr %slot840, align 8
  %v5107 = load i32, ptr %slot840, align 8
  %cv5108 = zext i32 %v5107 to i64
  %cond5109 = icmp ne i64 %cv5108, 0
  br i1 %cond5109, label %bb_rcguniquenn1130, label %bb_rcgunique1130
bb_rcguniquenn1130:
  %v5110 = load i64, ptr %slot839, align 8
  %op5111 = sub i64 %v5110, 16
  store i64 %op5111, ptr %slot841, align 8
  %v5112 = load i64, ptr %slot839, align 8
  %p5113 = inttoptr i64 %v5112 to ptr
  %rgep5114 = getelementptr i8, ptr %p5113, i64 -16
  %ld5115 = load i64, ptr %rgep5114, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5115, ptr %slot842, align 8
  %v5116 = load i64, ptr %slot842, align 8
  %op5117 = and i64 %v5116, 6917529027641081858
  store i64 %op5117, ptr %slot843, align 8
  %v5118 = load i64, ptr %slot843, align 8
  %cmp5119 = icmp ne i64 %v5118, 0
  %cv5120 = zext i1 %cmp5119 to i32
  store i32 %cv5120, ptr %slot844, align 8
  %v5121 = load i32, ptr %slot844, align 8
  %cv5122 = zext i32 %v5121 to i64
  %cond5123 = icmp ne i64 %cv5122, 0
  br i1 %cond5123, label %bb_rcguniqueslow1130, label %bb_rcguniquecount1130
bb_rcguniquecount1130:
  %v5124 = load i64, ptr %slot839, align 8
  %op5125 = sub i64 %v5124, 32
  store i64 %op5125, ptr %slot845, align 8
  %v5126 = load i64, ptr %slot839, align 8
  %p5127 = inttoptr i64 %v5126 to ptr
  %rgep5128 = getelementptr i8, ptr %p5127, i64 -32
  %ld5129 = load i64, ptr %rgep5128, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5129, ptr %slot846, align 8
  %v5130 = load i64, ptr %slot846, align 8
  %cmp5131 = icmp ult i64 %v5130, 2
  %cv5132 = zext i1 %cmp5131 to i32
  store i32 %cv5132, ptr %slot847, align 8
  %v5133 = load i32, ptr %slot847, align 8
  %cv5134 = zext i32 %v5133 to i64
  %cond5135 = icmp ne i64 %cv5134, 0
  br i1 %cond5135, label %bb_rcgunique1130, label %bb_rcguniqueslow1130
bb_rcguniqueslow1130:
  %v5136 = load i64, ptr %slot1, align 8
  %p5137 = inttoptr i64 %v5136 to ptr
  %p5138 = inttoptr i64 ptrtoint (ptr @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda to i64) to ptr
  %v5139 = load i64, ptr %slot837, align 8
  %p5140 = inttoptr i64 %v5139 to ptr
  %v5141 = load i64, ptr %slot838, align 8
  %p5142 = inttoptr i64 %v5141 to ptr
  %call5143 = call i32 @myl_qbe_rc_unique_field(ptr %p5137, ptr %p5138, ptr %p5140, ptr %p5142) nomerge, !dbg !160
  store i32 %call5143, ptr %slot848, align 8
  %v5144 = load i32, ptr %slot848, align 8
  %cv5145 = zext i32 %v5144 to i64
  %cond5146 = icmp ne i64 %cv5145, 0
  br i1 %cond5146, label %bb_rcunique1140, label %bb_failure
bb_rcunique1140:
  br label %bb_rcgunique1130
bb_rcgunique1130:
  %v5147 = load i64, ptr %slot837, align 8
  %p5148 = inttoptr i64 %v5147 to ptr
  %ld5149 = load i64, ptr %p5148, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5149, ptr %slot849, align 8
  %v5150 = load i64, ptr %slot849, align 8
  %v5151 = load i64, ptr %slot54, align 8
  %p5152 = inttoptr i64 %v5151 to ptr
  store i64 %v5150, ptr %p5152, align 8, !alias.scope !3, !noalias !4
  %v5153 = load i64, ptr %slot54, align 8
  %p5154 = inttoptr i64 %v5153 to ptr
  %ld5155 = load i64, ptr %p5154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5155, ptr %slot850, align 8
  %v5156 = load i64, ptr %slot17, align 8
  %p5157 = inttoptr i64 %v5156 to ptr
  %ld5158 = load i32, ptr %p5157, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5158, ptr %slot851, align 8
  %v5159 = load i32, ptr %slot851, align 8
  %cv5160 = zext i32 %v5159 to i64
  %cond5161 = icmp ne i64 %cv5160, 0
  br i1 %cond5161, label %bb_rcslotdrop1145, label %bb_rcslotdone1145
bb_rcslotdrop1145:
  %v5162 = load i64, ptr %slot17, align 8
  %p5163 = inttoptr i64 %v5162 to ptr
  store i32 0, ptr %p5163, align 4, !alias.scope !3, !noalias !4
  %v5164 = load i64, ptr %slot26, align 8
  store i64 %v5164, ptr %slot852, align 8
  %v5165 = load i64, ptr %slot18, align 8
  %p5166 = inttoptr i64 %v5165 to ptr
  %ld5167 = load i32, ptr %p5166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5167, ptr %slot853, align 8
  %v5168 = load i32, ptr %slot853, align 8
  %op5169 = and i32 %v5168, 28
  store i32 %op5169, ptr %slot854, align 8
  %v5170 = load i32, ptr %slot854, align 8
  %cv5171 = zext i32 %v5170 to i64
  %cond5172 = icmp ne i64 %cv5171, 0
  br i1 %cond5172, label %bb_rcslotrole1145, label %bb_rcslotowner1145
bb_rcslotrole1145:
  %v5173 = load i64, ptr %slot66, align 8
  store i64 %v5173, ptr %slot855, align 8
  %v5174 = load i64, ptr %slot852, align 8
  %p5175 = inttoptr i64 %v5174 to ptr
  %ld5176 = load i64, ptr %p5175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5176, ptr %slot856, align 8
  %v5177 = load i64, ptr %slot856, align 8
  %cmp5178 = icmp ne i64 %v5177, 0
  %cv5179 = zext i1 %cmp5178 to i32
  store i32 %cv5179, ptr %slot857, align 8
  %v5180 = load i32, ptr %slot857, align 8
  %cv5181 = zext i32 %v5180 to i64
  %cond5182 = icmp ne i64 %cv5181, 0
  br i1 %cond5182, label %bb_rcgnn1161, label %bb_rcgdone1161
bb_rcgnn1161:
  %v5183 = load i64, ptr %slot856, align 8
  %op5184 = sub i64 %v5183, 16
  store i64 %op5184, ptr %slot858, align 8
  %v5185 = load i64, ptr %slot856, align 8
  %p5186 = inttoptr i64 %v5185 to ptr
  %rgep5187 = getelementptr i8, ptr %p5186, i64 -16
  %ld5188 = load i64, ptr %rgep5187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5188, ptr %slot859, align 8
  %v5189 = load i64, ptr %slot859, align 8
  %op5190 = and i64 %v5189, 4611686018427387906
  store i64 %op5190, ptr %slot860, align 8
  %v5191 = load i64, ptr %slot860, align 8
  %cmp5192 = icmp ne i64 %v5191, 0
  %cv5193 = zext i1 %cmp5192 to i32
  store i32 %cv5193, ptr %slot861, align 8
  %v5194 = load i32, ptr %slot861, align 8
  %cv5195 = zext i32 %v5194 to i64
  %cond5196 = icmp ne i64 %cv5195, 0
  br i1 %cond5196, label %bb_rcgclear1161, label %bb_rcgcounted1161
bb_rcgcounted1161:
  %v5197 = load i64, ptr %slot856, align 8
  %op5198 = sub i64 %v5197, 24
  store i64 %op5198, ptr %slot862, align 8
  %v5199 = load i64, ptr %slot856, align 8
  %p5200 = inttoptr i64 %v5199 to ptr
  %rgep5201 = getelementptr i8, ptr %p5200, i64 -24
  %ld5202 = load i64, ptr %rgep5201, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5202, ptr %slot863, align 8
  %v5203 = load i64, ptr %slot863, align 8
  %op5204 = sub i64 %v5203, 1
  store i64 %op5204, ptr %slot864, align 8
  %v5205 = load i64, ptr %slot864, align 8
  %cmp5206 = icmp eq i64 %v5205, 0
  %cv5207 = zext i1 %cmp5206 to i32
  store i32 %cv5207, ptr %slot865, align 8
  %v5208 = load i32, ptr %slot865, align 8
  %cv5209 = zext i32 %v5208 to i64
  %cond5210 = icmp ne i64 %cv5209, 0
  br i1 %cond5210, label %bb_rcglast1161, label %bb_rcgdec1161
bb_rcglast1161:
  %v5211 = load i64, ptr %slot856, align 8
  %op5212 = sub i64 %v5211, 32
  store i64 %op5212, ptr %slot866, align 8
  %v5213 = load i64, ptr %slot856, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  %rgep5215 = getelementptr i8, ptr %p5214, i64 -32
  %ld5216 = load i64, ptr %rgep5215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5216, ptr %slot867, align 8
  %v5217 = load i64, ptr %slot867, align 8
  %cmp5218 = icmp ne i64 %v5217, 0
  %cv5219 = zext i1 %cmp5218 to i32
  store i32 %cv5219, ptr %slot868, align 8
  %v5220 = load i32, ptr %slot868, align 8
  %cv5221 = zext i32 %v5220 to i64
  %cond5222 = icmp ne i64 %cv5221, 0
  br i1 %cond5222, label %bb_rcgdec1161, label %bb_rcgslow1161
bb_rcgslow1161:
  %v5223 = load i64, ptr %slot855, align 8
  %v5224 = load i64, ptr %slot852, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64 %v5223, i64 %v5224) nomerge, !dbg !160
  br label %bb_rcgdone1161
bb_rcgdec1161:
  %v5225 = load i64, ptr %slot864, align 8
  %v5226 = load i64, ptr %slot856, align 8
  %p5227 = inttoptr i64 %v5226 to ptr
  %rgep5228 = getelementptr i8, ptr %p5227, i64 -24
  store i64 %v5225, ptr %rgep5228, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1161
bb_rcgclear1161:
  %v5229 = load i64, ptr %slot852, align 8
  %p5230 = inttoptr i64 %v5229 to ptr
  store i64 0, ptr %p5230, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1161
bb_rcgdone1161:
  br label %bb_rcslotdone1145
bb_rcslotowner1145:
  %v5231 = load i64, ptr %slot66, align 8
  store i64 %v5231, ptr %slot869, align 8
  %v5232 = load i64, ptr %slot852, align 8
  %p5233 = inttoptr i64 %v5232 to ptr
  %ld5234 = load i64, ptr %p5233, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5234, ptr %slot870, align 8
  %v5235 = load i64, ptr %slot870, align 8
  %cmp5236 = icmp ne i64 %v5235, 0
  %cv5237 = zext i1 %cmp5236 to i32
  store i32 %cv5237, ptr %slot871, align 8
  %v5238 = load i32, ptr %slot871, align 8
  %cv5239 = zext i32 %v5238 to i64
  %cond5240 = icmp ne i64 %cv5239, 0
  br i1 %cond5240, label %bb_rcgnn1176, label %bb_rcgdone1176
bb_rcgnn1176:
  %v5241 = load i64, ptr %slot870, align 8
  %op5242 = sub i64 %v5241, 16
  store i64 %op5242, ptr %slot872, align 8
  %v5243 = load i64, ptr %slot870, align 8
  %p5244 = inttoptr i64 %v5243 to ptr
  %rgep5245 = getelementptr i8, ptr %p5244, i64 -16
  %ld5246 = load i64, ptr %rgep5245, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5246, ptr %slot873, align 8
  %v5247 = load i64, ptr %slot873, align 8
  %op5248 = and i64 %v5247, 4611686018427387906
  store i64 %op5248, ptr %slot874, align 8
  %v5249 = load i64, ptr %slot874, align 8
  %cmp5250 = icmp ne i64 %v5249, 0
  %cv5251 = zext i1 %cmp5250 to i32
  store i32 %cv5251, ptr %slot875, align 8
  %v5252 = load i32, ptr %slot875, align 8
  %cv5253 = zext i32 %v5252 to i64
  %cond5254 = icmp ne i64 %cv5253, 0
  br i1 %cond5254, label %bb_rcgclear1176, label %bb_rcgcounted1176
bb_rcgcounted1176:
  %v5255 = load i64, ptr %slot870, align 8
  %op5256 = sub i64 %v5255, 32
  store i64 %op5256, ptr %slot876, align 8
  %v5257 = load i64, ptr %slot870, align 8
  %p5258 = inttoptr i64 %v5257 to ptr
  %rgep5259 = getelementptr i8, ptr %p5258, i64 -32
  %ld5260 = load i64, ptr %rgep5259, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5260, ptr %slot877, align 8
  %v5261 = load i64, ptr %slot877, align 8
  %op5262 = sub i64 %v5261, 1
  store i64 %op5262, ptr %slot878, align 8
  %v5263 = load i64, ptr %slot878, align 8
  %cmp5264 = icmp eq i64 %v5263, 0
  %cv5265 = zext i1 %cmp5264 to i32
  store i32 %cv5265, ptr %slot879, align 8
  %v5266 = load i32, ptr %slot879, align 8
  %cv5267 = zext i32 %v5266 to i64
  %cond5268 = icmp ne i64 %cv5267, 0
  br i1 %cond5268, label %bb_rcglast1176, label %bb_rcgdec1176
bb_rcglast1176:
  %v5269 = load i64, ptr %slot870, align 8
  %op5270 = sub i64 %v5269, 24
  store i64 %op5270, ptr %slot880, align 8
  %v5271 = load i64, ptr %slot870, align 8
  %p5272 = inttoptr i64 %v5271 to ptr
  %rgep5273 = getelementptr i8, ptr %p5272, i64 -24
  %ld5274 = load i64, ptr %rgep5273, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5274, ptr %slot881, align 8
  %v5275 = load i64, ptr %slot881, align 8
  %cmp5276 = icmp ne i64 %v5275, 0
  %cv5277 = zext i1 %cmp5276 to i32
  store i32 %cv5277, ptr %slot882, align 8
  %v5278 = load i32, ptr %slot882, align 8
  %cv5279 = zext i32 %v5278 to i64
  %cond5280 = icmp ne i64 %cv5279, 0
  br i1 %cond5280, label %bb_rcgdec1176, label %bb_rcgslow1176
bb_rcgslow1176:
  %v5281 = load i64, ptr %slot869, align 8
  %v5282 = load i64, ptr %slot852, align 8
  call void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64 %v5281, i64 %v5282) nomerge, !dbg !160
  br label %bb_rcgdone1176
bb_rcgdec1176:
  %v5283 = load i64, ptr %slot878, align 8
  %v5284 = load i64, ptr %slot870, align 8
  %p5285 = inttoptr i64 %v5284 to ptr
  %rgep5286 = getelementptr i8, ptr %p5285, i64 -32
  store i64 %v5283, ptr %rgep5286, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1176
bb_rcgclear1176:
  %v5287 = load i64, ptr %slot852, align 8
  %p5288 = inttoptr i64 %v5287 to ptr
  store i64 0, ptr %p5288, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1176
bb_rcgdone1176:
  br label %bb_rcslotdone1145
bb_rcslotdone1145:
  %v5289 = load i64, ptr %slot850, align 8
  %v5290 = load i64, ptr %slot48, align 8
  %p5291 = inttoptr i64 %v5290 to ptr
  store i64 %v5289, ptr %p5291, align 8, !alias.scope !3, !noalias !4
  %v5292 = load i64, ptr %slot42, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  %ld5294 = load i64, ptr %p5293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5294, ptr %slot883, align 8
  %v5295 = load i64, ptr %slot883, align 8
  %v5296 = load i64, ptr %slot54, align 8
  %p5297 = inttoptr i64 %v5296 to ptr
  store i64 %v5295, ptr %p5297, align 8, !alias.scope !3, !noalias !4
  %v5298 = load i64, ptr %slot54, align 8
  %p5299 = inttoptr i64 %v5298 to ptr
  %ld5300 = load i64, ptr %p5299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5300, ptr %slot884, align 8
  %v5301 = load i64, ptr %slot884, align 8
  %v5302 = load i64, ptr %slot50, align 8
  %p5303 = inttoptr i64 %v5302 to ptr
  store i64 %v5301, ptr %p5303, align 8, !alias.scope !3, !noalias !4
  %v5304 = load i64, ptr %slot50, align 8
  %p5305 = inttoptr i64 %v5304 to ptr
  %ld5306 = load i64, ptr %p5305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5306, ptr %slot885, align 8
  %v5307 = load i64, ptr %slot885, align 8
  %v5308 = load i64, ptr %slot54, align 8
  %p5309 = inttoptr i64 %v5308 to ptr
  store i64 %v5307, ptr %p5309, align 8, !alias.scope !3, !noalias !4
  %v5310 = load i64, ptr %slot55, align 8
  %p5311 = inttoptr i64 %v5310 to ptr
  store i64 0, ptr %p5311, align 8, !alias.scope !3, !noalias !4
  %v5312 = load i64, ptr %slot55, align 8
  %p5313 = inttoptr i64 %v5312 to ptr
  %ld5314 = load i64, ptr %p5313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5314, ptr %slot886, align 8
  %v5315 = load i64, ptr %slot54, align 8
  %p5316 = inttoptr i64 %v5315 to ptr
  %ld5317 = load i64, ptr %p5316, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5317, ptr %slot887, align 8
  %v5318 = load i64, ptr %slot887, align 8
  %v5319 = load i64, ptr %slot886, align 8
  %cmp5320 = icmp slt i64 %v5318, %v5319
  %cv5321 = zext i1 %cmp5320 to i64
  store i64 %cv5321, ptr %slot888, align 8
  %v5322 = load i64, ptr %slot888, align 8
  %v5323 = load i64, ptr %slot54, align 8
  %p5324 = inttoptr i64 %v5323 to ptr
  store i64 %v5322, ptr %p5324, align 8, !alias.scope !3, !noalias !4
  %v5325 = load i64, ptr %slot54, align 8
  %p5326 = inttoptr i64 %v5325 to ptr
  %ld5327 = load i64, ptr %p5326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5327, ptr %slot889, align 8
  %v5328 = load i64, ptr %slot889, align 8
  %cond5329 = icmp ne i64 %v5328, 0
  br i1 %cond5329, label %bb_next1224, label %bb_i66
bb_next1224:
  %v5330 = load i64, ptr %slot48, align 8
  %p5331 = inttoptr i64 %v5330 to ptr
  %ld5332 = load i64, ptr %p5331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5332, ptr %slot890, align 8
  %v5333 = load i64, ptr %slot890, align 8
  %op5334 = add i64 %v5333, 0
  store i64 %op5334, ptr %slot891, align 8
  %v5335 = load i64, ptr %slot891, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  %ld5337 = load i64, ptr %p5336, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5337, ptr %slot892, align 8
  %v5338 = load i64, ptr %slot892, align 8
  %v5339 = load i64, ptr %slot54, align 8
  %p5340 = inttoptr i64 %v5339 to ptr
  store i64 %v5338, ptr %p5340, align 8, !alias.scope !3, !noalias !4
  %v5341 = load i64, ptr %slot54, align 8
  %p5342 = inttoptr i64 %v5341 to ptr
  %ld5343 = load i64, ptr %p5342, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5343, ptr %slot893, align 8
  %v5344 = load i64, ptr %slot893, align 8
  %cmp5345 = icmp ugt i64 %v5344, 9223372036854775807
  %cv5346 = zext i1 %cmp5345 to i64
  store i64 %cv5346, ptr %slot894, align 8
  %v5347 = load i64, ptr %slot894, align 8
  %cond5348 = icmp ne i64 %v5347, 0
  br i1 %cond5348, label %bb_cast_overflow1229, label %bb_cast_ok1229
bb_cast_overflow1229:
  %v5349 = load i64, ptr %slot1, align 8
  %p5350 = inttoptr i64 %v5349 to ptr
  %v5351 = load i64, ptr %slot893, align 8
  call void @myl_qbe_fail_cast(ptr %p5350, i64 %v5351, i64 320) nomerge, !dbg !162
  unreachable
bb_cast_ok1229:
  %v5352 = load i64, ptr %slot893, align 8
  %v5353 = load i64, ptr %slot54, align 8
  %p5354 = inttoptr i64 %v5353 to ptr
  store i64 %v5352, ptr %p5354, align 8, !alias.scope !3, !noalias !4
  %v5355 = load i64, ptr %slot50, align 8
  %p5356 = inttoptr i64 %v5355 to ptr
  %ld5357 = load i64, ptr %p5356, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5357, ptr %slot895, align 8
  %v5358 = load i64, ptr %slot895, align 8
  %v5359 = load i64, ptr %slot55, align 8
  %p5360 = inttoptr i64 %v5359 to ptr
  store i64 %v5358, ptr %p5360, align 8, !alias.scope !3, !noalias !4
  %v5361 = load i64, ptr %slot55, align 8
  %p5362 = inttoptr i64 %v5361 to ptr
  %ld5363 = load i64, ptr %p5362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5363, ptr %slot896, align 8
  %v5364 = load i64, ptr %slot54, align 8
  %p5365 = inttoptr i64 %v5364 to ptr
  %ld5366 = load i64, ptr %p5365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5366, ptr %slot897, align 8
  %v5367 = load i64, ptr %slot897, align 8
  %v5368 = load i64, ptr %slot896, align 8
  %ovpair5370 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5367, i64 %v5368)
  %op5369 = extractvalue { i64, i1 } %ovpair5370, 0
  %ov5371 = extractvalue { i64, i1 } %ovpair5370, 1
  store i64 %op5369, ptr %slot898, align 8
  %v5372 = load i64, ptr %slot897, align 8
  %v5373 = load i64, ptr %slot898, align 8
  %op5374 = xor i64 %v5372, %v5373
  store i64 %op5374, ptr %slot899, align 8
  %v5375 = load i64, ptr %slot896, align 8
  %v5376 = load i64, ptr %slot898, align 8
  %op5377 = xor i64 %v5375, %v5376
  store i64 %op5377, ptr %slot900, align 8
  %v5378 = load i64, ptr %slot899, align 8
  %v5379 = load i64, ptr %slot900, align 8
  %op5380 = and i64 %v5378, %v5379
  store i64 %op5380, ptr %slot901, align 8
  %cv5381 = zext i1 %ov5371 to i64
  store i64 %cv5381, ptr %slot902, align 8
  %v5382 = load i64, ptr %slot902, align 8
  %cond5383 = icmp ne i64 %v5382, 0
  br i1 %cond5383, label %bb_overflow1233, label %bb_checked1233
bb_overflow1233:
  %v5384 = load i64, ptr %slot1, align 8
  %p5385 = inttoptr i64 %v5384 to ptr
  %v5386 = load i64, ptr %slot897, align 8
  %v5387 = load i64, ptr %slot896, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5385, i64 0, i64 %v5386, i64 %v5387, i64 64) nomerge, !dbg !164
  unreachable
bb_checked1233:
  %v5388 = load i64, ptr %slot898, align 8
  %v5389 = load i64, ptr %slot54, align 8
  %p5390 = inttoptr i64 %v5389 to ptr
  store i64 %v5388, ptr %p5390, align 8, !alias.scope !3, !noalias !4
  %v5391 = load i64, ptr %slot54, align 8
  %p5392 = inttoptr i64 %v5391 to ptr
  %ld5393 = load i64, ptr %p5392, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5393, ptr %slot903, align 8
  %v5394 = load i64, ptr %slot903, align 8
  %v5395 = load i64, ptr %slot50, align 8
  %p5396 = inttoptr i64 %v5395 to ptr
  store i64 %v5394, ptr %p5396, align 8, !alias.scope !3, !noalias !4
  br label %bb_i66
bb_i66:
  %v5397 = load i64, ptr %slot50, align 8
  %p5398 = inttoptr i64 %v5397 to ptr
  %ld5399 = load i64, ptr %p5398, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5399, ptr %slot904, align 8
  %v5400 = load i64, ptr %slot904, align 8
  %v5401 = load i64, ptr %slot54, align 8
  %p5402 = inttoptr i64 %v5401 to ptr
  store i64 %v5400, ptr %p5402, align 8, !alias.scope !3, !noalias !4
  %v5403 = load i64, ptr %slot49, align 8
  %v5404 = load i64, ptr %slot55, align 8
  %p5405 = inttoptr i64 %v5404 to ptr
  store i64 %v5403, ptr %p5405, align 8, !alias.scope !3, !noalias !4
  %v5406 = load i64, ptr %slot55, align 8
  %p5407 = inttoptr i64 %v5406 to ptr
  %ld5408 = load i64, ptr %p5407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5408, ptr %slot905, align 8
  %v5409 = load i64, ptr %slot19, align 8
  %p5410 = inttoptr i64 %v5409 to ptr
  %ld5411 = load i32, ptr %p5410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5411, ptr %slot906, align 8
  %v5412 = load i64, ptr %slot20, align 8
  %p5413 = inttoptr i64 %v5412 to ptr
  %ld5414 = load i32, ptr %p5413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5414, ptr %slot907, align 8
  %v5415 = load i32, ptr %slot907, align 8
  %op5416 = and i32 %v5415, 24
  store i32 %op5416, ptr %slot907, align 8
  %v5417 = load i32, ptr %slot907, align 8
  %cmp5418 = icmp eq i32 %v5417, 0
  %cv5419 = zext i1 %cmp5418 to i32
  store i32 %cv5419, ptr %slot908, align 8
  %v5420 = load i32, ptr %slot906, align 8
  %v5421 = load i32, ptr %slot908, align 8
  %op5422 = and i32 %v5420, %v5421
  store i32 %op5422, ptr %slot909, align 8
  %v5423 = load i64, ptr %slot67, align 8
  store i64 %v5423, ptr %slot910, align 8
  %v5424 = load i32, ptr %slot909, align 8
  %op5425 = mul i32 %v5424, 4
  store i32 %op5425, ptr %slot911, align 8
  %v5426 = load i32, ptr %slot911, align 8
  %op5427 = or i32 %v5426, 0
  store i32 %op5427, ptr %slot912, align 8
  %v5428 = load i64, ptr %slot31, align 8
  store i64 %v5428, ptr %slot913, align 8
  %v5429 = load i64, ptr %slot66, align 8
  %v5430 = load i64, ptr %slot913, align 8
  %v5431 = load i64, ptr %slot905, align 8
  %v5432 = load i64, ptr %slot910, align 8
  %cv5433 = trunc i64 %v5432 to i32
  %v5434 = load i32, ptr %slot912, align 8
  %call5435 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64 %v5429, i64 %v5430, i64 %v5431, i32 %cv5433, i32 %v5434) nomerge, !dbg !166
  store i32 %call5435, ptr %slot914, align 8
  %v5436 = load i32, ptr %slot914, align 8
  %cv5437 = zext i32 %v5436 to i64
  %cond5438 = icmp ne i64 %cv5437, 0
  br i1 %cond5438, label %bb_rcsuccess1254, label %bb_rcfailure1254
bb_rcfailure1254:
  %v5439 = load i64, ptr %slot66, align 8
  %p5440 = inttoptr i64 %v5439 to ptr
  %call5441 = call i32 @myl_rc_take_failure(ptr %p5440) nomerge, !dbg !166
  store i32 %call5441, ptr %slot915, align 8
  %v5442 = load i64, ptr %slot1, align 8
  %p5443 = inttoptr i64 %v5442 to ptr
  %v5444 = load i32, ptr %slot915, align 8
  %call5445 = call i32 @myl_qbe_rc_status(ptr %p5443, i32 %v5444) nomerge, !dbg !166
  store i32 %call5445, ptr %slot916, align 8
  br label %bb_failure
bb_rcsuccess1254:
  %v5446 = load i32, ptr %slot909, align 8
  %cv5447 = zext i32 %v5446 to i64
  %cond5448 = icmp ne i64 %cv5447, 0
  br i1 %cond5448, label %bb_rchtaken1257, label %bb_rchcopied1257
bb_rchcopied1257:
  %v5449 = load i64, ptr %slot19, align 8
  %p5450 = inttoptr i64 %v5449 to ptr
  %ld5451 = load i32, ptr %p5450, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5451, ptr %slot917, align 8
  %v5452 = load i32, ptr %slot917, align 8
  %cv5453 = zext i32 %v5452 to i64
  %cond5454 = icmp ne i64 %cv5453, 0
  br i1 %cond5454, label %bb_rcslotdrop1260, label %bb_rcslotdone1260
bb_rcslotdrop1260:
  %v5455 = load i64, ptr %slot19, align 8
  %p5456 = inttoptr i64 %v5455 to ptr
  store i32 0, ptr %p5456, align 4, !alias.scope !3, !noalias !4
  %v5457 = load i64, ptr %slot27, align 8
  store i64 %v5457, ptr %slot918, align 8
  %v5458 = load i64, ptr %slot20, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  %ld5460 = load i32, ptr %p5459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5460, ptr %slot919, align 8
  %v5461 = load i32, ptr %slot919, align 8
  %op5462 = and i32 %v5461, 28
  store i32 %op5462, ptr %slot920, align 8
  %v5463 = load i32, ptr %slot920, align 8
  %cv5464 = zext i32 %v5463 to i64
  %cond5465 = icmp ne i64 %cv5464, 0
  br i1 %cond5465, label %bb_rcslotrole1260, label %bb_rcslotowner1260
bb_rcslotrole1260:
  %v5466 = load i64, ptr %slot66, align 8
  store i64 %v5466, ptr %slot921, align 8
  %v5467 = load i64, ptr %slot921, align 8
  %v5468 = load i64, ptr %slot918, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5467, i64 %v5468) nomerge, !dbg !166
  br label %bb_rcslotdone1260
bb_rcslotowner1260:
  %v5469 = load i64, ptr %slot66, align 8
  store i64 %v5469, ptr %slot922, align 8
  %v5470 = load i64, ptr %slot922, align 8
  %v5471 = load i64, ptr %slot918, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5470, i64 %v5471) nomerge, !dbg !166
  br label %bb_rcslotdone1260
bb_rcslotdone1260:
  br label %bb_rchprepared1257
bb_rchtaken1257:
  %v5472 = load i64, ptr %slot19, align 8
  %p5473 = inttoptr i64 %v5472 to ptr
  store i32 0, ptr %p5473, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1257
bb_rchprepared1257:
  %v5474 = load i64, ptr %slot24, align 8
  %p5475 = inttoptr i64 %v5474 to ptr
  store i32 2, ptr %p5475, align 4, !alias.scope !3, !noalias !4
  %v5476 = load i64, ptr %slot23, align 8
  %p5477 = inttoptr i64 %v5476 to ptr
  store i32 1, ptr %p5477, align 4, !alias.scope !3, !noalias !4
  %v5478 = load i64, ptr %slot27, align 8
  store i64 %v5478, ptr %slot923, align 8
  %v5479 = load i64, ptr %slot31, align 8
  store i64 %v5479, ptr %slot924, align 8
  %v5480 = load i64, ptr %slot924, align 8
  %v5481 = load i64, ptr %slot923, align 8
  %p5482 = inttoptr i64 %v5480 to ptr
  %p5483 = inttoptr i64 %v5481 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5483, ptr %p5482, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v5484 = load i64, ptr %slot20, align 8
  %p5485 = inttoptr i64 %v5484 to ptr
  store i32 2, ptr %p5485, align 4, !alias.scope !3, !noalias !4
  %v5486 = load i64, ptr %slot24, align 8
  %p5487 = inttoptr i64 %v5486 to ptr
  %ld5488 = load i32, ptr %p5487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5488, ptr %slot925, align 8
  %v5489 = load i32, ptr %slot925, align 8
  %v5490 = load i64, ptr %slot20, align 8
  %p5491 = inttoptr i64 %v5490 to ptr
  store i32 %v5489, ptr %p5491, align 4, !alias.scope !3, !noalias !4
  %v5492 = load i64, ptr %slot23, align 8
  %p5493 = inttoptr i64 %v5492 to ptr
  store i32 0, ptr %p5493, align 4, !alias.scope !3, !noalias !4
  %v5494 = load i64, ptr %slot19, align 8
  %p5495 = inttoptr i64 %v5494 to ptr
  store i32 1, ptr %p5495, align 4, !alias.scope !3, !noalias !4
  %v5496 = load i64, ptr %slot923, align 8
  %v5497 = load i64, ptr %slot55, align 8
  %p5498 = inttoptr i64 %v5497 to ptr
  store i64 %v5496, ptr %p5498, align 8, !alias.scope !3, !noalias !4
  %v5499 = load i64, ptr %slot48, align 8
  %p5500 = inttoptr i64 %v5499 to ptr
  %ld5501 = load i64, ptr %p5500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5501, ptr %slot926, align 8
  %v5502 = load i64, ptr %slot55, align 8
  %p5503 = inttoptr i64 %v5502 to ptr
  %ld5504 = load i64, ptr %p5503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5504, ptr %slot927, align 8
  %v5505 = load i64, ptr %slot54, align 8
  %p5506 = inttoptr i64 %v5505 to ptr
  %ld5507 = load i64, ptr %p5506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5507, ptr %slot928, align 8
  %v5508 = load i64, ptr %slot926, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  %ld5510 = load i64, ptr %p5509, align 8, !alias.scope !6, !noalias !7
  store i64 %ld5510, ptr %slot929, align 8
  %v5511 = load i64, ptr %slot928, align 8
  %v5512 = load i64, ptr %slot929, align 8
  %cmp5513 = icmp ult i64 %v5511, %v5512
  %cv5514 = zext i1 %cmp5513 to i64
  store i64 %cv5514, ptr %slot930, align 8
  %v5515 = load i64, ptr %slot930, align 8
  %cond5516 = icmp ne i64 %v5515, 0
  br i1 %cond5516, label %bb_success1284, label %bb_failed1284
bb_failed1284:
  %v5517 = load i64, ptr %slot1, align 8
  %p5518 = inttoptr i64 %v5517 to ptr
  %v5519 = load i64, ptr %slot928, align 8
  %v5520 = load i64, ptr %slot929, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p5518, i64 %v5519, i64 %v5520) nomerge, !dbg !168
  unreachable
bb_success1284:
  %v5521 = load i64, ptr %slot55, align 8
  %p5522 = inttoptr i64 %v5521 to ptr
  %ld5523 = load i64, ptr %p5522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5523, ptr %slot931, align 8
  %v5524 = load i64, ptr %slot66, align 8
  %v5525 = load i64, ptr %slot926, align 8
  %v5526 = load i64, ptr %slot928, align 8
  %v5527 = load i64, ptr %slot931, align 8
  %call5528 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64 %v5524, i64 %v5525, i64 %v5526, i64 %v5527) nomerge, !dbg !168
  store i32 %call5528, ptr %slot932, align 8
  %v5529 = load i32, ptr %slot932, align 8
  %cv5530 = zext i32 %v5529 to i64
  %cond5531 = icmp ne i64 %cv5530, 0
  br i1 %cond5531, label %bb_success1287, label %bb_failed1287
bb_failed1287:
  %v5532 = load i64, ptr %slot1, align 8
  %p5533 = inttoptr i64 %v5532 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5533) nomerge, !dbg !168
  unreachable
bb_success1287:
  %v5534 = load i64, ptr %slot54, align 8
  %p5535 = inttoptr i64 %v5534 to ptr
  store i64 0, ptr %p5535, align 8, !alias.scope !3, !noalias !4
  %v5536 = load i64, ptr %slot19, align 8
  %p5537 = inttoptr i64 %v5536 to ptr
  %ld5538 = load i32, ptr %p5537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5538, ptr %slot933, align 8
  %v5539 = load i32, ptr %slot933, align 8
  %cv5540 = zext i32 %v5539 to i64
  %cond5541 = icmp ne i64 %cv5540, 0
  br i1 %cond5541, label %bb_rcslotdrop1290, label %bb_rcslotdone1290
bb_rcslotdrop1290:
  %v5542 = load i64, ptr %slot19, align 8
  %p5543 = inttoptr i64 %v5542 to ptr
  store i32 0, ptr %p5543, align 4, !alias.scope !3, !noalias !4
  %v5544 = load i64, ptr %slot27, align 8
  store i64 %v5544, ptr %slot934, align 8
  %v5545 = load i64, ptr %slot20, align 8
  %p5546 = inttoptr i64 %v5545 to ptr
  %ld5547 = load i32, ptr %p5546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5547, ptr %slot935, align 8
  %v5548 = load i32, ptr %slot935, align 8
  %op5549 = and i32 %v5548, 28
  store i32 %op5549, ptr %slot936, align 8
  %v5550 = load i32, ptr %slot936, align 8
  %cv5551 = zext i32 %v5550 to i64
  %cond5552 = icmp ne i64 %cv5551, 0
  br i1 %cond5552, label %bb_rcslotrole1290, label %bb_rcslotowner1290
bb_rcslotrole1290:
  %v5553 = load i64, ptr %slot66, align 8
  store i64 %v5553, ptr %slot937, align 8
  %v5554 = load i64, ptr %slot937, align 8
  %v5555 = load i64, ptr %slot934, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5554, i64 %v5555) nomerge, !dbg !168
  br label %bb_rcslotdone1290
bb_rcslotowner1290:
  %v5556 = load i64, ptr %slot66, align 8
  store i64 %v5556, ptr %slot938, align 8
  %v5557 = load i64, ptr %slot938, align 8
  %v5558 = load i64, ptr %slot934, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5557, i64 %v5558) nomerge, !dbg !168
  br label %bb_rcslotdone1290
bb_rcslotdone1290:
  %v5559 = load i64, ptr %slot45, align 8
  %v5560 = load i64, ptr %slot54, align 8
  %p5561 = inttoptr i64 %v5560 to ptr
  store i64 %v5559, ptr %p5561, align 8, !alias.scope !3, !noalias !4
  %v5562 = load i64, ptr %slot54, align 8
  %p5563 = inttoptr i64 %v5562 to ptr
  %ld5564 = load i64, ptr %p5563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5564, ptr %slot939, align 8
  %v5565 = load i64, ptr %slot939, align 8
  %op5566 = add i64 %v5565, 0
  store i64 %op5566, ptr %slot940, align 8
  %v5567 = load i64, ptr %slot940, align 8
  %v5568 = load i64, ptr %slot54, align 8
  %p5569 = inttoptr i64 %v5568 to ptr
  store i64 %v5567, ptr %p5569, align 8, !alias.scope !3, !noalias !4
  %v5570 = load i64, ptr %slot17, align 8
  %p5571 = inttoptr i64 %v5570 to ptr
  %ld5572 = load i32, ptr %p5571, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5572, ptr %slot941, align 8
  %v5573 = load i32, ptr %slot941, align 8
  %cv5574 = zext i32 %v5573 to i64
  %cond5575 = icmp ne i64 %cv5574, 0
  br i1 %cond5575, label %bb_rcslotdrop1301, label %bb_rcslotdone1301
bb_rcslotdrop1301:
  %v5576 = load i64, ptr %slot17, align 8
  %p5577 = inttoptr i64 %v5576 to ptr
  store i32 0, ptr %p5577, align 4, !alias.scope !3, !noalias !4
  %v5578 = load i64, ptr %slot26, align 8
  store i64 %v5578, ptr %slot942, align 8
  %v5579 = load i64, ptr %slot18, align 8
  %p5580 = inttoptr i64 %v5579 to ptr
  %ld5581 = load i32, ptr %p5580, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5581, ptr %slot943, align 8
  %v5582 = load i32, ptr %slot943, align 8
  %op5583 = and i32 %v5582, 28
  store i32 %op5583, ptr %slot944, align 8
  %v5584 = load i32, ptr %slot944, align 8
  %cv5585 = zext i32 %v5584 to i64
  %cond5586 = icmp ne i64 %cv5585, 0
  br i1 %cond5586, label %bb_rcslotrole1301, label %bb_rcslotowner1301
bb_rcslotrole1301:
  %v5587 = load i64, ptr %slot66, align 8
  store i64 %v5587, ptr %slot945, align 8
  %v5588 = load i64, ptr %slot945, align 8
  %v5589 = load i64, ptr %slot942, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5588, i64 %v5589) nomerge, !dbg !170
  br label %bb_rcslotdone1301
bb_rcslotowner1301:
  %v5590 = load i64, ptr %slot66, align 8
  store i64 %v5590, ptr %slot946, align 8
  %v5591 = load i64, ptr %slot946, align 8
  %v5592 = load i64, ptr %slot942, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5591, i64 %v5592) nomerge, !dbg !170
  br label %bb_rcslotdone1301
bb_rcslotdone1301:
  %v5593 = load i64, ptr %slot54, align 8
  %p5594 = inttoptr i64 %v5593 to ptr
  %ld5595 = load i64, ptr %p5594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5595, ptr %slot947, align 8
  %v5596 = load i64, ptr %slot17, align 8
  %p5597 = inttoptr i64 %v5596 to ptr
  %ld5598 = load i32, ptr %p5597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5598, ptr %slot948, align 8
  %v5599 = load i64, ptr %slot18, align 8
  %p5600 = inttoptr i64 %v5599 to ptr
  %ld5601 = load i32, ptr %p5600, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5601, ptr %slot949, align 8
  %v5602 = load i32, ptr %slot949, align 8
  %op5603 = and i32 %v5602, 24
  store i32 %op5603, ptr %slot949, align 8
  %v5604 = load i32, ptr %slot949, align 8
  %cmp5605 = icmp eq i32 %v5604, 0
  %cv5606 = zext i1 %cmp5605 to i32
  store i32 %cv5606, ptr %slot950, align 8
  %v5607 = load i32, ptr %slot948, align 8
  %v5608 = load i32, ptr %slot950, align 8
  %op5609 = and i32 %v5607, %v5608
  store i32 %op5609, ptr %slot951, align 8
  %v5610 = load i64, ptr %slot67, align 8
  store i64 %v5610, ptr %slot952, align 8
  %v5611 = load i32, ptr %slot951, align 8
  %op5612 = mul i32 %v5611, 4
  store i32 %op5612, ptr %slot953, align 8
  %v5613 = load i32, ptr %slot953, align 8
  %op5614 = or i32 %v5613, 0
  store i32 %op5614, ptr %slot954, align 8
  %v5615 = load i64, ptr %slot31, align 8
  store i64 %v5615, ptr %slot955, align 8
  %v5616 = load i64, ptr %slot66, align 8
  %v5617 = load i64, ptr %slot955, align 8
  %v5618 = load i64, ptr %slot947, align 8
  %v5619 = load i64, ptr %slot952, align 8
  %cv5620 = trunc i64 %v5619 to i32
  %v5621 = load i32, ptr %slot954, align 8
  %call5622 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64 %v5616, i64 %v5617, i64 %v5618, i32 %cv5620, i32 %v5621) nomerge, !dbg !172
  store i32 %call5622, ptr %slot956, align 8
  %v5623 = load i32, ptr %slot956, align 8
  %cv5624 = zext i32 %v5623 to i64
  %cond5625 = icmp ne i64 %cv5624, 0
  br i1 %cond5625, label %bb_rcsuccess1322, label %bb_rcfailure1322
bb_rcfailure1322:
  %v5626 = load i64, ptr %slot66, align 8
  %p5627 = inttoptr i64 %v5626 to ptr
  %call5628 = call i32 @myl_rc_take_failure(ptr %p5627) nomerge, !dbg !172
  store i32 %call5628, ptr %slot957, align 8
  %v5629 = load i64, ptr %slot1, align 8
  %p5630 = inttoptr i64 %v5629 to ptr
  %v5631 = load i32, ptr %slot957, align 8
  %call5632 = call i32 @myl_qbe_rc_status(ptr %p5630, i32 %v5631) nomerge, !dbg !172
  store i32 %call5632, ptr %slot958, align 8
  br label %bb_failure
bb_rcsuccess1322:
  %v5633 = load i32, ptr %slot951, align 8
  %cv5634 = zext i32 %v5633 to i64
  %cond5635 = icmp ne i64 %cv5634, 0
  br i1 %cond5635, label %bb_rchtaken1325, label %bb_rchcopied1325
bb_rchcopied1325:
  %v5636 = load i64, ptr %slot17, align 8
  %p5637 = inttoptr i64 %v5636 to ptr
  %ld5638 = load i32, ptr %p5637, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5638, ptr %slot959, align 8
  %v5639 = load i32, ptr %slot959, align 8
  %cv5640 = zext i32 %v5639 to i64
  %cond5641 = icmp ne i64 %cv5640, 0
  br i1 %cond5641, label %bb_rcslotdrop1328, label %bb_rcslotdone1328
bb_rcslotdrop1328:
  %v5642 = load i64, ptr %slot17, align 8
  %p5643 = inttoptr i64 %v5642 to ptr
  store i32 0, ptr %p5643, align 4, !alias.scope !3, !noalias !4
  %v5644 = load i64, ptr %slot26, align 8
  store i64 %v5644, ptr %slot960, align 8
  %v5645 = load i64, ptr %slot18, align 8
  %p5646 = inttoptr i64 %v5645 to ptr
  %ld5647 = load i32, ptr %p5646, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5647, ptr %slot961, align 8
  %v5648 = load i32, ptr %slot961, align 8
  %op5649 = and i32 %v5648, 28
  store i32 %op5649, ptr %slot962, align 8
  %v5650 = load i32, ptr %slot962, align 8
  %cv5651 = zext i32 %v5650 to i64
  %cond5652 = icmp ne i64 %cv5651, 0
  br i1 %cond5652, label %bb_rcslotrole1328, label %bb_rcslotowner1328
bb_rcslotrole1328:
  %v5653 = load i64, ptr %slot66, align 8
  store i64 %v5653, ptr %slot963, align 8
  %v5654 = load i64, ptr %slot963, align 8
  %v5655 = load i64, ptr %slot960, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v5654, i64 %v5655) nomerge, !dbg !172
  br label %bb_rcslotdone1328
bb_rcslotowner1328:
  %v5656 = load i64, ptr %slot66, align 8
  store i64 %v5656, ptr %slot964, align 8
  %v5657 = load i64, ptr %slot964, align 8
  %v5658 = load i64, ptr %slot960, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v5657, i64 %v5658) nomerge, !dbg !172
  br label %bb_rcslotdone1328
bb_rcslotdone1328:
  br label %bb_rchprepared1325
bb_rchtaken1325:
  %v5659 = load i64, ptr %slot17, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  store i32 0, ptr %p5660, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1325
bb_rchprepared1325:
  %v5661 = load i64, ptr %slot24, align 8
  %p5662 = inttoptr i64 %v5661 to ptr
  store i32 2, ptr %p5662, align 4, !alias.scope !3, !noalias !4
  %v5663 = load i64, ptr %slot23, align 8
  %p5664 = inttoptr i64 %v5663 to ptr
  store i32 1, ptr %p5664, align 4, !alias.scope !3, !noalias !4
  %v5665 = load i64, ptr %slot26, align 8
  store i64 %v5665, ptr %slot965, align 8
  %v5666 = load i64, ptr %slot31, align 8
  store i64 %v5666, ptr %slot966, align 8
  %v5667 = load i64, ptr %slot966, align 8
  %v5668 = load i64, ptr %slot965, align 8
  %p5669 = inttoptr i64 %v5667 to ptr
  %p5670 = inttoptr i64 %v5668 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5670, ptr %p5669, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v5671 = load i64, ptr %slot18, align 8
  %p5672 = inttoptr i64 %v5671 to ptr
  store i32 2, ptr %p5672, align 4, !alias.scope !3, !noalias !4
  %v5673 = load i64, ptr %slot24, align 8
  %p5674 = inttoptr i64 %v5673 to ptr
  %ld5675 = load i32, ptr %p5674, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5675, ptr %slot967, align 8
  %v5676 = load i32, ptr %slot967, align 8
  %v5677 = load i64, ptr %slot18, align 8
  %p5678 = inttoptr i64 %v5677 to ptr
  store i32 %v5676, ptr %p5678, align 4, !alias.scope !3, !noalias !4
  %v5679 = load i64, ptr %slot23, align 8
  %p5680 = inttoptr i64 %v5679 to ptr
  store i32 0, ptr %p5680, align 4, !alias.scope !3, !noalias !4
  %v5681 = load i64, ptr %slot17, align 8
  %p5682 = inttoptr i64 %v5681 to ptr
  store i32 1, ptr %p5682, align 4, !alias.scope !3, !noalias !4
  %v5683 = load i64, ptr %slot965, align 8
  %v5684 = load i64, ptr %slot54, align 8
  %p5685 = inttoptr i64 %v5684 to ptr
  store i64 %v5683, ptr %p5685, align 8, !alias.scope !3, !noalias !4
  %v5686 = load i64, ptr %slot59, align 8
  store i64 %v5686, ptr %slot968, align 8
  %v5687 = load i64, ptr %slot968, align 8
  %p5688 = inttoptr i64 %v5687 to ptr
  store i64 0, ptr %p5688, align 8, !alias.scope !3, !noalias !4
  %v5689 = load i64, ptr %slot968, align 8
  %p5691 = inttoptr i64 %v5689 to ptr
  %gep5692 = getelementptr i8, ptr %p5691, i64 8
  %op5690 = ptrtoint ptr %gep5692 to i64
  store i64 %op5690, ptr %slot969, align 8
  %v5693 = load i64, ptr %slot969, align 8
  %p5694 = inttoptr i64 %v5693 to ptr
  store i64 0, ptr %p5694, align 8, !alias.scope !3, !noalias !4
  %v5695 = load i64, ptr %slot968, align 8
  %p5697 = inttoptr i64 %v5695 to ptr
  %gep5698 = getelementptr i8, ptr %p5697, i64 16
  %op5696 = ptrtoint ptr %gep5698 to i64
  store i64 %op5696, ptr %slot970, align 8
  %v5699 = load i64, ptr %slot970, align 8
  %p5700 = inttoptr i64 %v5699 to ptr
  store i64 0, ptr %p5700, align 8, !alias.scope !3, !noalias !4
  %v5701 = load i64, ptr %slot968, align 8
  %p5703 = inttoptr i64 %v5701 to ptr
  %gep5704 = getelementptr i8, ptr %p5703, i64 24
  %op5702 = ptrtoint ptr %gep5704 to i64
  store i64 %op5702, ptr %slot971, align 8
  %v5705 = load i64, ptr %slot971, align 8
  %p5706 = inttoptr i64 %v5705 to ptr
  store i64 0, ptr %p5706, align 8, !alias.scope !3, !noalias !4
  %v5707 = load i64, ptr %slot968, align 8
  %p5709 = inttoptr i64 %v5707 to ptr
  %gep5710 = getelementptr i8, ptr %p5709, i64 32
  %op5708 = ptrtoint ptr %gep5710 to i64
  store i64 %op5708, ptr %slot972, align 8
  %v5711 = load i64, ptr %slot972, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  store i64 0, ptr %p5712, align 8, !alias.scope !3, !noalias !4
  %v5713 = load i64, ptr %slot968, align 8
  %p5715 = inttoptr i64 %v5713 to ptr
  %gep5716 = getelementptr i8, ptr %p5715, i64 40
  %op5714 = ptrtoint ptr %gep5716 to i64
  store i64 %op5714, ptr %slot973, align 8
  %v5717 = load i64, ptr %slot973, align 8
  %p5718 = inttoptr i64 %v5717 to ptr
  store i64 0, ptr %p5718, align 8, !alias.scope !3, !noalias !4
  %v5719 = load i64, ptr %slot968, align 8
  %p5721 = inttoptr i64 %v5719 to ptr
  %gep5722 = getelementptr i8, ptr %p5721, i64 48
  %op5720 = ptrtoint ptr %gep5722 to i64
  store i64 %op5720, ptr %slot974, align 8
  %v5723 = load i64, ptr %slot974, align 8
  %p5724 = inttoptr i64 %v5723 to ptr
  store i64 0, ptr %p5724, align 8, !alias.scope !3, !noalias !4
  %v5725 = load i64, ptr %slot968, align 8
  %p5726 = inttoptr i64 %v5725 to ptr
  store i32 2, ptr %p5726, align 4, !alias.scope !3, !noalias !4
  %v5727 = load i64, ptr %slot25, align 8
  %p5728 = inttoptr i64 %v5727 to ptr
  store i32 1, ptr %p5728, align 4, !alias.scope !3, !noalias !4
  %v5729 = load i64, ptr %slot54, align 8
  %p5730 = inttoptr i64 %v5729 to ptr
  %ld5731 = load i64, ptr %p5730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5731, ptr %slot975, align 8
  %v5732 = load i64, ptr %slot968, align 8
  %p5734 = inttoptr i64 %v5732 to ptr
  %gep5735 = getelementptr i8, ptr %p5734, i64 8
  %op5733 = ptrtoint ptr %gep5735 to i64
  store i64 %op5733, ptr %slot976, align 8
  %v5736 = load i64, ptr %slot67, align 8
  store i64 %v5736, ptr %slot977, align 8
  %v5737 = load i64, ptr %slot54, align 8
  %p5738 = inttoptr i64 %v5737 to ptr
  %ld5739 = load i64, ptr %p5738, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5739, ptr %slot978, align 8
  %v5740 = load i64, ptr %slot31, align 8
  store i64 %v5740, ptr %slot979, align 8
  %v5741 = load i64, ptr %slot67, align 8
  store i64 %v5741, ptr %slot980, align 8
  %v5742 = load i64, ptr %slot978, align 8
  %op5743 = add i64 %v5742, 16
  store i64 %op5743, ptr %slot981, align 8
  %v5744 = load i64, ptr %slot981, align 8
  %p5745 = inttoptr i64 %v5744 to ptr
  %ld5746 = load i64, ptr %p5745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5746, ptr %slot982, align 8
  %v5747 = load i64, ptr %slot982, align 8
  %cmp5748 = icmp ne i64 %v5747, 0
  %cv5749 = zext i1 %cmp5748 to i32
  store i32 %cv5749, ptr %slot983, align 8
  %v5750 = load i32, ptr %slot983, align 8
  %cv5751 = zext i32 %v5750 to i64
  %cond5752 = icmp ne i64 %cv5751, 0
  br i1 %cond5752, label %bb_rcmoveheader1364, label %bb_rcmovenext1364
bb_rcmoveheader1364:
  %v5753 = load i64, ptr %slot982, align 8
  %op5754 = sub i64 %v5753, 16
  store i64 %op5754, ptr %slot984, align 8
  %v5755 = load i64, ptr %slot982, align 8
  %p5756 = inttoptr i64 %v5755 to ptr
  %rgep5757 = getelementptr i8, ptr %p5756, i64 -16
  %ld5758 = load i64, ptr %rgep5757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5758, ptr %slot985, align 8
  %v5759 = load i64, ptr %slot985, align 8
  %op5760 = and i64 %v5759, 5764607523034234881
  store i64 %op5760, ptr %slot986, align 8
  %v5761 = load i64, ptr %slot986, align 8
  %cmp5762 = icmp ne i64 %v5761, 0
  %cv5763 = zext i1 %cmp5762 to i32
  store i32 %cv5763, ptr %slot987, align 8
  %v5764 = load i32, ptr %slot987, align 8
  %cv5765 = zext i32 %v5764 to i64
  %cond5766 = icmp ne i64 %cv5765, 0
  br i1 %cond5766, label %bb_rcmoveslow1361, label %bb_rcmovenext1364
bb_rcmovenext1364:
  %v5767 = load i64, ptr %slot978, align 8
  %op5768 = add i64 %v5767, 24
  store i64 %op5768, ptr %slot988, align 8
  %v5769 = load i64, ptr %slot988, align 8
  %p5770 = inttoptr i64 %v5769 to ptr
  %ld5771 = load i64, ptr %p5770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5771, ptr %slot989, align 8
  %v5772 = load i64, ptr %slot989, align 8
  %cmp5773 = icmp ne i64 %v5772, 0
  %cv5774 = zext i1 %cmp5773 to i32
  store i32 %cv5774, ptr %slot990, align 8
  %v5775 = load i32, ptr %slot990, align 8
  %cv5776 = zext i32 %v5775 to i64
  %cond5777 = icmp ne i64 %cv5776, 0
  br i1 %cond5777, label %bb_rcmoveheader1372, label %bb_rcmovenext1372
bb_rcmoveheader1372:
  %v5778 = load i64, ptr %slot989, align 8
  %op5779 = sub i64 %v5778, 16
  store i64 %op5779, ptr %slot991, align 8
  %v5780 = load i64, ptr %slot989, align 8
  %p5781 = inttoptr i64 %v5780 to ptr
  %rgep5782 = getelementptr i8, ptr %p5781, i64 -16
  %ld5783 = load i64, ptr %rgep5782, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5783, ptr %slot992, align 8
  %v5784 = load i64, ptr %slot992, align 8
  %op5785 = and i64 %v5784, 5764607523034234881
  store i64 %op5785, ptr %slot993, align 8
  %v5786 = load i64, ptr %slot993, align 8
  %cmp5787 = icmp ne i64 %v5786, 0
  %cv5788 = zext i1 %cmp5787 to i32
  store i32 %cv5788, ptr %slot994, align 8
  %v5789 = load i32, ptr %slot994, align 8
  %cv5790 = zext i32 %v5789 to i64
  %cond5791 = icmp ne i64 %cv5790, 0
  br i1 %cond5791, label %bb_rcmoveslow1361, label %bb_rcmovenext1372
bb_rcmovenext1372:
  %v5792 = load i64, ptr %slot978, align 8
  %op5793 = add i64 %v5792, 32
  store i64 %op5793, ptr %slot995, align 8
  %v5794 = load i64, ptr %slot995, align 8
  %p5795 = inttoptr i64 %v5794 to ptr
  %ld5796 = load i64, ptr %p5795, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5796, ptr %slot996, align 8
  %v5797 = load i64, ptr %slot996, align 8
  %cmp5798 = icmp ne i64 %v5797, 0
  %cv5799 = zext i1 %cmp5798 to i32
  store i32 %cv5799, ptr %slot997, align 8
  %v5800 = load i32, ptr %slot997, align 8
  %cv5801 = zext i32 %v5800 to i64
  %cond5802 = icmp ne i64 %cv5801, 0
  br i1 %cond5802, label %bb_rcmoveheader1380, label %bb_rcmovenext1380
bb_rcmoveheader1380:
  %v5803 = load i64, ptr %slot996, align 8
  %op5804 = sub i64 %v5803, 16
  store i64 %op5804, ptr %slot998, align 8
  %v5805 = load i64, ptr %slot996, align 8
  %p5806 = inttoptr i64 %v5805 to ptr
  %rgep5807 = getelementptr i8, ptr %p5806, i64 -16
  %ld5808 = load i64, ptr %rgep5807, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5808, ptr %slot999, align 8
  %v5809 = load i64, ptr %slot999, align 8
  %op5810 = and i64 %v5809, 5764607523034234881
  store i64 %op5810, ptr %slot1000, align 8
  %v5811 = load i64, ptr %slot1000, align 8
  %cmp5812 = icmp ne i64 %v5811, 0
  %cv5813 = zext i1 %cmp5812 to i32
  store i32 %cv5813, ptr %slot1001, align 8
  %v5814 = load i32, ptr %slot1001, align 8
  %cv5815 = zext i32 %v5814 to i64
  %cond5816 = icmp ne i64 %cv5815, 0
  br i1 %cond5816, label %bb_rcmoveslow1361, label %bb_rcmovenext1380
bb_rcmovenext1380:
  %v5817 = load i64, ptr %slot978, align 8
  %v5818 = load i64, ptr %slot979, align 8
  %p5819 = inttoptr i64 %v5817 to ptr
  %p5820 = inttoptr i64 %v5818 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5820, ptr %p5819, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v5821 = load i64, ptr %slot978, align 8
  %p5822 = inttoptr i64 %v5821 to ptr
  store i64 0, ptr %p5822, align 8, !alias.scope !3, !noalias !4
  %v5823 = load i64, ptr %slot978, align 8
  %op5824 = add i64 %v5823, 8
  store i64 %op5824, ptr %slot1002, align 8
  %v5825 = load i64, ptr %slot1002, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  store i64 0, ptr %p5826, align 8, !alias.scope !3, !noalias !4
  %v5827 = load i64, ptr %slot978, align 8
  %op5828 = add i64 %v5827, 16
  store i64 %op5828, ptr %slot1003, align 8
  %v5829 = load i64, ptr %slot1003, align 8
  %p5830 = inttoptr i64 %v5829 to ptr
  store i64 0, ptr %p5830, align 8, !alias.scope !3, !noalias !4
  %v5831 = load i64, ptr %slot978, align 8
  %op5832 = add i64 %v5831, 24
  store i64 %op5832, ptr %slot1004, align 8
  %v5833 = load i64, ptr %slot1004, align 8
  %p5834 = inttoptr i64 %v5833 to ptr
  store i64 0, ptr %p5834, align 8, !alias.scope !3, !noalias !4
  %v5835 = load i64, ptr %slot978, align 8
  %op5836 = add i64 %v5835, 32
  store i64 %op5836, ptr %slot1005, align 8
  %v5837 = load i64, ptr %slot1005, align 8
  %p5838 = inttoptr i64 %v5837 to ptr
  store i64 0, ptr %p5838, align 8, !alias.scope !3, !noalias !4
  %v5839 = load i64, ptr %slot978, align 8
  %op5840 = add i64 %v5839, 40
  store i64 %op5840, ptr %slot1006, align 8
  %v5841 = load i64, ptr %slot1006, align 8
  %p5842 = inttoptr i64 %v5841 to ptr
  store i64 0, ptr %p5842, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1361
bb_rcmoveslow1361:
  %v5843 = load i64, ptr %slot66, align 8
  %v5844 = load i64, ptr %slot979, align 8
  %v5845 = load i64, ptr %slot978, align 8
  %v5846 = load i64, ptr %slot980, align 8
  %cv5847 = trunc i64 %v5846 to i32
  %call5848 = call i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64 %v5843, i64 %v5844, i64 %v5845, i32 %cv5847) nomerge, !dbg !174
  store i32 %call5848, ptr %slot1007, align 8
  %v5849 = load i32, ptr %slot1007, align 8
  %cv5850 = zext i32 %v5849 to i64
  %cond5851 = icmp ne i64 %cv5850, 0
  br i1 %cond5851, label %bb_rcsuccess1392, label %bb_rcfailure1392
bb_rcfailure1392:
  %v5852 = load i64, ptr %slot66, align 8
  %p5853 = inttoptr i64 %v5852 to ptr
  %call5854 = call i32 @myl_rc_take_failure(ptr %p5853) nomerge, !dbg !174
  store i32 %call5854, ptr %slot1008, align 8
  %v5855 = load i64, ptr %slot1, align 8
  %p5856 = inttoptr i64 %v5855 to ptr
  %v5857 = load i32, ptr %slot1008, align 8
  %call5858 = call i32 @myl_qbe_rc_status(ptr %p5856, i32 %v5857) nomerge, !dbg !174
  store i32 %call5858, ptr %slot1009, align 8
  br label %bb_failure
bb_rcsuccess1392:
  br label %bb_rcmoved1361
bb_rcmoved1361:
  %v5859 = load i64, ptr %slot17, align 8
  %p5860 = inttoptr i64 %v5859 to ptr
  store i32 0, ptr %p5860, align 4, !alias.scope !3, !noalias !4
  %v5861 = load i64, ptr %slot24, align 8
  %p5862 = inttoptr i64 %v5861 to ptr
  store i32 2, ptr %p5862, align 4, !alias.scope !3, !noalias !4
  %v5863 = load i64, ptr %slot23, align 8
  %p5864 = inttoptr i64 %v5863 to ptr
  store i32 1, ptr %p5864, align 4, !alias.scope !3, !noalias !4
  %v5865 = load i64, ptr %slot31, align 8
  store i64 %v5865, ptr %slot1010, align 8
  %v5866 = load i64, ptr %slot1010, align 8
  %v5867 = load i64, ptr %slot976, align 8
  %p5868 = inttoptr i64 %v5866 to ptr
  %p5869 = inttoptr i64 %v5867 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5869, ptr %p5868, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v5870 = load i64, ptr %slot23, align 8
  %p5871 = inttoptr i64 %v5870 to ptr
  store i32 0, ptr %p5871, align 4, !alias.scope !3, !noalias !4
  %v5872 = load i64, ptr %slot968, align 8
  %v5873 = load i64, ptr %slot54, align 8
  %p5874 = inttoptr i64 %v5873 to ptr
  store i64 %v5872, ptr %p5874, align 8, !alias.scope !3, !noalias !4
  %v5875 = load i64, ptr %slot54, align 8
  %p5876 = inttoptr i64 %v5875 to ptr
  %ld5877 = load i64, ptr %p5876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5877, ptr %slot1011, align 8
  %v5878 = load i64, ptr %slot26, align 8
  store i64 %v5878, ptr %slot1012, align 8
  %v5879 = load i64, ptr %slot1011, align 8
  %v5880 = load i64, ptr %slot1012, align 8
  %p5881 = inttoptr i64 %v5879 to ptr
  %p5882 = inttoptr i64 %v5880 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5882, ptr %p5881, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v5883 = load i64, ptr %slot18, align 8
  %p5884 = inttoptr i64 %v5883 to ptr
  store i32 2, ptr %p5884, align 4, !alias.scope !3, !noalias !4
  %v5885 = load i64, ptr %slot17, align 8
  %p5886 = inttoptr i64 %v5885 to ptr
  store i32 1, ptr %p5886, align 4, !alias.scope !3, !noalias !4
  %v5887 = load i64, ptr %slot1012, align 8
  %v5888 = load i64, ptr %slot54, align 8
  %p5889 = inttoptr i64 %v5888 to ptr
  store i64 %v5887, ptr %p5889, align 8, !alias.scope !3, !noalias !4
  %v5890 = load i64, ptr %slot54, align 8
  %p5891 = inttoptr i64 %v5890 to ptr
  %ld5892 = load i64, ptr %p5891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5892, ptr %slot1013, align 8
  %v5893 = load i64, ptr %slot17, align 8
  %p5894 = inttoptr i64 %v5893 to ptr
  %ld5895 = load i32, ptr %p5894, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5895, ptr %slot1014, align 8
  %v5896 = load i64, ptr %slot18, align 8
  %p5897 = inttoptr i64 %v5896 to ptr
  %ld5898 = load i32, ptr %p5897, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5898, ptr %slot1015, align 8
  %v5899 = load i32, ptr %slot1015, align 8
  %op5900 = and i32 %v5899, 24
  store i32 %op5900, ptr %slot1015, align 8
  %v5901 = load i32, ptr %slot1015, align 8
  %cmp5902 = icmp eq i32 %v5901, 0
  %cv5903 = zext i1 %cmp5902 to i32
  store i32 %cv5903, ptr %slot1016, align 8
  %v5904 = load i32, ptr %slot1014, align 8
  %v5905 = load i32, ptr %slot1016, align 8
  %op5906 = and i32 %v5904, %v5905
  store i32 %op5906, ptr %slot1017, align 8
  %v5907 = load i32, ptr %slot1017, align 8
  %cv5908 = zext i32 %v5907 to i64
  %cond5909 = icmp ne i64 %cv5908, 0
  br i1 %cond5909, label %bb_rcprivateown1411, label %bb_rcprivateloan1411
bb_rcprivateown1411:
  %v5910 = load i64, ptr %slot31, align 8
  store i64 %v5910, ptr %slot1018, align 8
  %v5911 = load i64, ptr %slot67, align 8
  store i64 %v5911, ptr %slot1019, align 8
  %v5912 = load i64, ptr %slot66, align 8
  %v5913 = load i64, ptr %slot1018, align 8
  %v5914 = load i64, ptr %slot1013, align 8
  %v5915 = load i64, ptr %slot1019, align 8
  %cv5916 = trunc i64 %v5915 to i32
  %call5917 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64 %v5912, i64 %v5913, i64 %v5914, i32 %cv5916) nomerge, !dbg !176
  store i32 %call5917, ptr %slot1020, align 8
  %v5918 = load i32, ptr %slot1020, align 8
  %cv5919 = zext i32 %v5918 to i64
  %cond5920 = icmp ne i64 %cv5919, 0
  br i1 %cond5920, label %bb_rcsuccess1415, label %bb_rcfailure1415
bb_rcfailure1415:
  %v5921 = load i64, ptr %slot66, align 8
  %p5922 = inttoptr i64 %v5921 to ptr
  %call5923 = call i32 @myl_rc_take_failure(ptr %p5922) nomerge, !dbg !176
  store i32 %call5923, ptr %slot1021, align 8
  %v5924 = load i64, ptr %slot1, align 8
  %p5925 = inttoptr i64 %v5924 to ptr
  %v5926 = load i32, ptr %slot1021, align 8
  %call5927 = call i32 @myl_qbe_rc_status(ptr %p5925, i32 %v5926) nomerge, !dbg !176
  store i32 %call5927, ptr %slot1022, align 8
  br label %bb_failure
bb_rcsuccess1415:
  %v5928 = load i64, ptr %slot17, align 8
  %p5929 = inttoptr i64 %v5928 to ptr
  store i32 0, ptr %p5929, align 4, !alias.scope !3, !noalias !4
  %v5930 = load i64, ptr %slot24, align 8
  %p5931 = inttoptr i64 %v5930 to ptr
  store i32 2, ptr %p5931, align 4, !alias.scope !3, !noalias !4
  %v5932 = load i64, ptr %slot23, align 8
  %p5933 = inttoptr i64 %v5932 to ptr
  store i32 1, ptr %p5933, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1411
bb_rcprivateloan1411:
  %v5934 = load i64, ptr %slot17, align 8
  %p5935 = inttoptr i64 %v5934 to ptr
  %ld5936 = load i32, ptr %p5935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5936, ptr %slot1023, align 8
  %v5937 = load i64, ptr %slot18, align 8
  %p5938 = inttoptr i64 %v5937 to ptr
  %ld5939 = load i32, ptr %p5938, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5939, ptr %slot1024, align 8
  %v5940 = load i32, ptr %slot1024, align 8
  %cmp5941 = icmp eq i32 %v5940, 16
  %cv5942 = zext i1 %cmp5941 to i32
  store i32 %cv5942, ptr %slot1025, align 8
  %v5943 = load i32, ptr %slot1025, align 8
  %v5944 = load i32, ptr %slot1023, align 8
  %op5945 = and i32 %v5943, %v5944
  store i32 %op5945, ptr %slot1025, align 8
  %v5946 = load i32, ptr %slot1025, align 8
  %cv5947 = zext i32 %v5946 to i64
  %cond5948 = icmp ne i64 %cv5947, 0
  br i1 %cond5948, label %bb_rcprivatemove1411, label %bb_rcprivatenew1411
bb_rcprivatemove1411:
  %v5949 = load i64, ptr %slot31, align 8
  store i64 %v5949, ptr %slot1026, align 8
  %v5950 = load i64, ptr %slot1013, align 8
  %v5951 = load i64, ptr %slot1026, align 8
  %p5952 = inttoptr i64 %v5950 to ptr
  %p5953 = inttoptr i64 %v5951 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5953, ptr %p5952, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v5954 = load i64, ptr %slot1013, align 8
  %p5955 = inttoptr i64 %v5954 to ptr
  call void @llvm.memset.p0.i64(ptr %p5955, i8 0, i64 56, i1 false), !alias.scope !3, !noalias !4, !dbg !176
  %v5956 = load i64, ptr %slot24, align 8
  %p5957 = inttoptr i64 %v5956 to ptr
  store i32 2, ptr %p5957, align 4, !alias.scope !3, !noalias !4
  %v5958 = load i64, ptr %slot24, align 8
  %p5959 = inttoptr i64 %v5958 to ptr
  store i32 16, ptr %p5959, align 4, !alias.scope !3, !noalias !4
  %v5960 = load i64, ptr %slot23, align 8
  %p5961 = inttoptr i64 %v5960 to ptr
  store i32 1, ptr %p5961, align 4, !alias.scope !3, !noalias !4
  %v5962 = load i64, ptr %slot17, align 8
  %p5963 = inttoptr i64 %v5962 to ptr
  store i32 0, ptr %p5963, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1411
bb_rcprivatenew1411:
  %v5964 = load i64, ptr %slot31, align 8
  store i64 %v5964, ptr %slot1027, align 8
  %v5965 = load i64, ptr %slot66, align 8
  %v5966 = load i64, ptr %slot1027, align 8
  %v5967 = load i64, ptr %slot1013, align 8
  %call5968 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64 %v5965, i64 %v5966, i64 %v5967) nomerge, !dbg !176
  store i32 %call5968, ptr %slot1028, align 8
  %v5969 = load i32, ptr %slot1028, align 8
  %cv5970 = zext i32 %v5969 to i64
  %cond5971 = icmp ne i64 %cv5970, 0
  br i1 %cond5971, label %bb_rcsuccess1433, label %bb_rcfailure1433
bb_rcfailure1433:
  %v5972 = load i64, ptr %slot66, align 8
  %p5973 = inttoptr i64 %v5972 to ptr
  %call5974 = call i32 @myl_rc_take_failure(ptr %p5973) nomerge, !dbg !176
  store i32 %call5974, ptr %slot1029, align 8
  %v5975 = load i64, ptr %slot1, align 8
  %p5976 = inttoptr i64 %v5975 to ptr
  %v5977 = load i32, ptr %slot1029, align 8
  %call5978 = call i32 @myl_qbe_rc_status(ptr %p5976, i32 %v5977) nomerge, !dbg !176
  store i32 %call5978, ptr %slot1030, align 8
  br label %bb_failure
bb_rcsuccess1433:
  %v5979 = load i64, ptr %slot24, align 8
  %p5980 = inttoptr i64 %v5979 to ptr
  store i32 2, ptr %p5980, align 4, !alias.scope !3, !noalias !4
  %v5981 = load i64, ptr %slot24, align 8
  %p5982 = inttoptr i64 %v5981 to ptr
  store i32 16, ptr %p5982, align 4, !alias.scope !3, !noalias !4
  %v5983 = load i64, ptr %slot23, align 8
  %p5984 = inttoptr i64 %v5983 to ptr
  store i32 1, ptr %p5984, align 4, !alias.scope !3, !noalias !4
  %v5985 = load i64, ptr %slot17, align 8
  %p5986 = inttoptr i64 %v5985 to ptr
  %ld5987 = load i32, ptr %p5986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5987, ptr %slot1031, align 8
  %v5988 = load i32, ptr %slot1031, align 8
  %cv5989 = zext i32 %v5988 to i64
  %cond5990 = icmp ne i64 %cv5989, 0
  br i1 %cond5990, label %bb_rcslotdrop1441, label %bb_rcslotdone1441
bb_rcslotdrop1441:
  %v5991 = load i64, ptr %slot17, align 8
  %p5992 = inttoptr i64 %v5991 to ptr
  store i32 0, ptr %p5992, align 4, !alias.scope !3, !noalias !4
  %v5993 = load i64, ptr %slot26, align 8
  store i64 %v5993, ptr %slot1032, align 8
  %v5994 = load i64, ptr %slot18, align 8
  %p5995 = inttoptr i64 %v5994 to ptr
  %ld5996 = load i32, ptr %p5995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5996, ptr %slot1033, align 8
  %v5997 = load i32, ptr %slot1033, align 8
  %op5998 = and i32 %v5997, 28
  store i32 %op5998, ptr %slot1034, align 8
  %v5999 = load i32, ptr %slot1034, align 8
  %cv6000 = zext i32 %v5999 to i64
  %cond6001 = icmp ne i64 %cv6000, 0
  br i1 %cond6001, label %bb_rcslotrole1441, label %bb_rcslotowner1441
bb_rcslotrole1441:
  %v6002 = load i64, ptr %slot66, align 8
  store i64 %v6002, ptr %slot1035, align 8
  %v6003 = load i64, ptr %slot1035, align 8
  %v6004 = load i64, ptr %slot1032, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v6003, i64 %v6004) nomerge, !dbg !176
  br label %bb_rcslotdone1441
bb_rcslotowner1441:
  %v6005 = load i64, ptr %slot66, align 8
  store i64 %v6005, ptr %slot1036, align 8
  %v6006 = load i64, ptr %slot1036, align 8
  %v6007 = load i64, ptr %slot1032, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v6006, i64 %v6007) nomerge, !dbg !176
  br label %bb_rcslotdone1441
bb_rcslotdone1441:
  br label %bb_rcprivateprepared1411
bb_rcprivateprepared1411:
  %v6008 = load i64, ptr %slot15, align 8
  %p6009 = inttoptr i64 %v6008 to ptr
  %ld6010 = load i32, ptr %p6009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6010, ptr %slot1037, align 8
  %v6011 = load i32, ptr %slot1037, align 8
  %cv6012 = zext i32 %v6011 to i64
  %cond6013 = icmp ne i64 %cv6012, 0
  br i1 %cond6013, label %bb_rcslotdrop1451, label %bb_rcslotdone1451
bb_rcslotdrop1451:
  %v6014 = load i64, ptr %slot15, align 8
  %p6015 = inttoptr i64 %v6014 to ptr
  store i32 0, ptr %p6015, align 4, !alias.scope !3, !noalias !4
  %v6016 = load i64, ptr %slot52, align 8
  store i64 %v6016, ptr %slot1038, align 8
  %v6017 = load i64, ptr %slot16, align 8
  %p6018 = inttoptr i64 %v6017 to ptr
  %ld6019 = load i32, ptr %p6018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6019, ptr %slot1039, align 8
  %v6020 = load i32, ptr %slot1039, align 8
  %op6021 = and i32 %v6020, 28
  store i32 %op6021, ptr %slot1040, align 8
  %v6022 = load i32, ptr %slot1040, align 8
  %cv6023 = zext i32 %v6022 to i64
  %cond6024 = icmp ne i64 %cv6023, 0
  br i1 %cond6024, label %bb_rcslotrole1451, label %bb_rcslotowner1451
bb_rcslotrole1451:
  %v6025 = load i64, ptr %slot66, align 8
  store i64 %v6025, ptr %slot1041, align 8
  %v6026 = load i64, ptr %slot1041, align 8
  %v6027 = load i64, ptr %slot1038, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v6026, i64 %v6027) nomerge, !dbg !176
  br label %bb_rcslotdone1451
bb_rcslotowner1451:
  %v6028 = load i64, ptr %slot66, align 8
  store i64 %v6028, ptr %slot1042, align 8
  %v6029 = load i64, ptr %slot1042, align 8
  %v6030 = load i64, ptr %slot1038, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v6029, i64 %v6030) nomerge, !dbg !176
  br label %bb_rcslotdone1451
bb_rcslotdone1451:
  %v6031 = load i64, ptr %slot52, align 8
  store i64 %v6031, ptr %slot1043, align 8
  %v6032 = load i64, ptr %slot31, align 8
  store i64 %v6032, ptr %slot1044, align 8
  %v6033 = load i64, ptr %slot1044, align 8
  %v6034 = load i64, ptr %slot1043, align 8
  %p6035 = inttoptr i64 %v6033 to ptr
  %p6036 = inttoptr i64 %v6034 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6036, ptr %p6035, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v6037 = load i64, ptr %slot23, align 8
  %p6038 = inttoptr i64 %v6037 to ptr
  store i32 0, ptr %p6038, align 4, !alias.scope !3, !noalias !4
  %v6039 = load i64, ptr %slot16, align 8
  %p6040 = inttoptr i64 %v6039 to ptr
  store i32 2, ptr %p6040, align 4, !alias.scope !3, !noalias !4
  %v6041 = load i64, ptr %slot24, align 8
  %p6042 = inttoptr i64 %v6041 to ptr
  %ld6043 = load i32, ptr %p6042, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6043, ptr %slot1045, align 8
  %v6044 = load i32, ptr %slot1045, align 8
  %v6045 = load i64, ptr %slot16, align 8
  %p6046 = inttoptr i64 %v6045 to ptr
  store i32 %v6044, ptr %p6046, align 4, !alias.scope !3, !noalias !4
  %v6047 = load i64, ptr %slot15, align 8
  %p6048 = inttoptr i64 %v6047 to ptr
  store i32 1, ptr %p6048, align 4, !alias.scope !3, !noalias !4
  %v6049 = load i64, ptr %slot37, align 8
  %p6050 = inttoptr i64 %v6049 to ptr
  %ld6051 = load i64, ptr %p6050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6051, ptr %slot1046, align 8
  %v6052 = load i64, ptr %slot1046, align 8
  %v6053 = load i64, ptr %slot54, align 8
  %p6054 = inttoptr i64 %v6053 to ptr
  store i64 %v6052, ptr %p6054, align 8, !alias.scope !3, !noalias !4
  %v6055 = load i64, ptr %slot54, align 8
  %p6056 = inttoptr i64 %v6055 to ptr
  %ld6057 = load i64, ptr %p6056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6057, ptr %slot1047, align 8
  %v6058 = load i64, ptr %slot1047, align 8
  %op6059 = add i64 %v6058, 0
  store i64 %op6059, ptr %slot1048, align 8
  %v6060 = load i64, ptr %slot1048, align 8
  %v6061 = load i64, ptr %slot54, align 8
  %p6062 = inttoptr i64 %v6061 to ptr
  store i64 %v6060, ptr %p6062, align 8, !alias.scope !3, !noalias !4
  %v6063 = load i64, ptr %slot17, align 8
  %p6064 = inttoptr i64 %v6063 to ptr
  %ld6065 = load i32, ptr %p6064, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6065, ptr %slot1049, align 8
  %v6066 = load i32, ptr %slot1049, align 8
  %cv6067 = zext i32 %v6066 to i64
  %cond6068 = icmp ne i64 %cv6067, 0
  br i1 %cond6068, label %bb_rcslotdrop1470, label %bb_rcslotdone1470
bb_rcslotdrop1470:
  %v6069 = load i64, ptr %slot17, align 8
  %p6070 = inttoptr i64 %v6069 to ptr
  store i32 0, ptr %p6070, align 4, !alias.scope !3, !noalias !4
  %v6071 = load i64, ptr %slot26, align 8
  store i64 %v6071, ptr %slot1050, align 8
  %v6072 = load i64, ptr %slot18, align 8
  %p6073 = inttoptr i64 %v6072 to ptr
  %ld6074 = load i32, ptr %p6073, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6074, ptr %slot1051, align 8
  %v6075 = load i32, ptr %slot1051, align 8
  %op6076 = and i32 %v6075, 28
  store i32 %op6076, ptr %slot1052, align 8
  %v6077 = load i32, ptr %slot1052, align 8
  %cv6078 = zext i32 %v6077 to i64
  %cond6079 = icmp ne i64 %cv6078, 0
  br i1 %cond6079, label %bb_rcslotrole1470, label %bb_rcslotowner1470
bb_rcslotrole1470:
  %v6080 = load i64, ptr %slot66, align 8
  store i64 %v6080, ptr %slot1053, align 8
  %v6081 = load i64, ptr %slot1053, align 8
  %v6082 = load i64, ptr %slot1050, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v6081, i64 %v6082) nomerge, !dbg !178
  br label %bb_rcslotdone1470
bb_rcslotowner1470:
  %v6083 = load i64, ptr %slot66, align 8
  store i64 %v6083, ptr %slot1054, align 8
  %v6084 = load i64, ptr %slot1054, align 8
  %v6085 = load i64, ptr %slot1050, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v6084, i64 %v6085) nomerge, !dbg !178
  br label %bb_rcslotdone1470
bb_rcslotdone1470:
  %v6086 = load i64, ptr %slot54, align 8
  %p6087 = inttoptr i64 %v6086 to ptr
  %ld6088 = load i64, ptr %p6087, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6088, ptr %slot1055, align 8
  %v6089 = load i64, ptr %slot1055, align 8
  %op6090 = add i64 %v6089, 0
  store i64 %op6090, ptr %slot1056, align 8
  %v6091 = load i64, ptr %slot1056, align 8
  %p6092 = inttoptr i64 %v6091 to ptr
  %ld6093 = load i64, ptr %p6092, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6093, ptr %slot1057, align 8
  %v6094 = load i64, ptr %slot1057, align 8
  %v6095 = load i64, ptr %slot54, align 8
  %p6096 = inttoptr i64 %v6095 to ptr
  store i64 %v6094, ptr %p6096, align 8, !alias.scope !3, !noalias !4
  %v6097 = load i64, ptr %slot54, align 8
  %p6098 = inttoptr i64 %v6097 to ptr
  %ld6099 = load i64, ptr %p6098, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6099, ptr %slot1058, align 8
  %v6100 = load i64, ptr %slot1058, align 8
  %v6101 = load i64, ptr %slot29, align 8
  %p6102 = inttoptr i64 %v6101 to ptr
  store i64 %v6100, ptr %p6102, align 8, !alias.scope !3, !noalias !4
  %v6103 = load i64, ptr %slot29, align 8
  store i64 %v6103, ptr %slot1059, align 8
  %v6104 = load i64, ptr %slot31, align 8
  store i64 %v6104, ptr %slot1060, align 8
  %v6105 = load i64, ptr %slot1059, align 8
  %p6106 = inttoptr i64 %v6105 to ptr
  %ld6107 = load i64, ptr %p6106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6107, ptr %slot1061, align 8
  %v6108 = load i64, ptr %slot1061, align 8
  %cmp6109 = icmp ne i64 %v6108, 0
  %cv6110 = zext i1 %cmp6109 to i32
  store i32 %cv6110, ptr %slot1062, align 8
  %v6111 = load i32, ptr %slot1062, align 8
  %cv6112 = zext i32 %v6111 to i64
  %cond6113 = icmp ne i64 %cv6112, 0
  br i1 %cond6113, label %bb_rcgnn1484, label %bb_rcgstore1484
bb_rcgnn1484:
  %v6114 = load i64, ptr %slot1061, align 8
  %op6115 = sub i64 %v6114, 16
  store i64 %op6115, ptr %slot1063, align 8
  %v6116 = load i64, ptr %slot1061, align 8
  %p6117 = inttoptr i64 %v6116 to ptr
  %rgep6118 = getelementptr i8, ptr %p6117, i64 -16
  %ld6119 = load i64, ptr %rgep6118, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6119, ptr %slot1064, align 8
  %v6120 = load i64, ptr %slot1064, align 8
  %op6121 = and i64 %v6120, 4611686018427387906
  store i64 %op6121, ptr %slot1065, align 8
  %v6122 = load i64, ptr %slot1065, align 8
  %cmp6123 = icmp ne i64 %v6122, 0
  %cv6124 = zext i1 %cmp6123 to i32
  store i32 %cv6124, ptr %slot1066, align 8
  %v6125 = load i32, ptr %slot1066, align 8
  %cv6126 = zext i32 %v6125 to i64
  %cond6127 = icmp ne i64 %cv6126, 0
  br i1 %cond6127, label %bb_rcgstore1484, label %bb_rcginc1484
bb_rcginc1484:
  %v6128 = load i64, ptr %slot1061, align 8
  %op6129 = sub i64 %v6128, 24
  store i64 %op6129, ptr %slot1067, align 8
  %v6130 = load i64, ptr %slot1061, align 8
  %p6131 = inttoptr i64 %v6130 to ptr
  %rgep6132 = getelementptr i8, ptr %p6131, i64 -24
  %ld6133 = load i64, ptr %rgep6132, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6133, ptr %slot1068, align 8
  %v6134 = load i64, ptr %slot1068, align 8
  %op6135 = add i64 %v6134, 1
  store i64 %op6135, ptr %slot1069, align 8
  %v6136 = load i64, ptr %slot1069, align 8
  %cmp6137 = icmp eq i64 %v6136, 0
  %cv6138 = zext i1 %cmp6137 to i32
  store i32 %cv6138, ptr %slot1070, align 8
  %v6139 = load i32, ptr %slot1070, align 8
  %cv6140 = zext i32 %v6139 to i64
  %cond6141 = icmp ne i64 %cv6140, 0
  br i1 %cond6141, label %bb_rcglimit1484, label %bb_rcgcapacity1484
bb_rcglimit1484:
  %v6142 = load i64, ptr %slot1, align 8
  %p6143 = inttoptr i64 %v6142 to ptr
  %call6144 = call i32 @myl_qbe_rc_status(ptr %p6143, i32 2) nomerge, !dbg !180
  store i32 %call6144, ptr %slot1071, align 8
  br label %bb_failure
bb_rcgcapacity1484:
  %v6145 = load i64, ptr %slot1069, align 8
  %v6146 = load i64, ptr %slot1061, align 8
  %p6147 = inttoptr i64 %v6146 to ptr
  %rgep6148 = getelementptr i8, ptr %p6147, i64 -24
  store i64 %v6145, ptr %rgep6148, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1484
bb_rcgstore1484:
  %v6149 = load i64, ptr %slot1061, align 8
  %v6150 = load i64, ptr %slot1060, align 8
  %p6151 = inttoptr i64 %v6150 to ptr
  store i64 %v6149, ptr %p6151, align 8, !alias.scope !3, !noalias !4
  %v6152 = load i64, ptr %slot24, align 8
  %p6153 = inttoptr i64 %v6152 to ptr
  store i32 2, ptr %p6153, align 4, !alias.scope !3, !noalias !4
  %v6154 = load i64, ptr %slot24, align 8
  %p6155 = inttoptr i64 %v6154 to ptr
  store i32 16, ptr %p6155, align 4, !alias.scope !3, !noalias !4
  %v6156 = load i64, ptr %slot23, align 8
  %p6157 = inttoptr i64 %v6156 to ptr
  store i32 1, ptr %p6157, align 4, !alias.scope !3, !noalias !4
  %v6158 = load i64, ptr %slot17, align 8
  %p6159 = inttoptr i64 %v6158 to ptr
  %ld6160 = load i32, ptr %p6159, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6160, ptr %slot1072, align 8
  %v6161 = load i32, ptr %slot1072, align 8
  %cv6162 = zext i32 %v6161 to i64
  %cond6163 = icmp ne i64 %cv6162, 0
  br i1 %cond6163, label %bb_rcslotdrop1500, label %bb_rcslotdone1500
bb_rcslotdrop1500:
  %v6164 = load i64, ptr %slot17, align 8
  %p6165 = inttoptr i64 %v6164 to ptr
  store i32 0, ptr %p6165, align 4, !alias.scope !3, !noalias !4
  %v6166 = load i64, ptr %slot26, align 8
  store i64 %v6166, ptr %slot1073, align 8
  %v6167 = load i64, ptr %slot18, align 8
  %p6168 = inttoptr i64 %v6167 to ptr
  %ld6169 = load i32, ptr %p6168, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6169, ptr %slot1074, align 8
  %v6170 = load i32, ptr %slot1074, align 8
  %op6171 = and i32 %v6170, 28
  store i32 %op6171, ptr %slot1075, align 8
  %v6172 = load i32, ptr %slot1075, align 8
  %cv6173 = zext i32 %v6172 to i64
  %cond6174 = icmp ne i64 %cv6173, 0
  br i1 %cond6174, label %bb_rcslotrole1500, label %bb_rcslotowner1500
bb_rcslotrole1500:
  %v6175 = load i64, ptr %slot66, align 8
  store i64 %v6175, ptr %slot1076, align 8
  %v6176 = load i64, ptr %slot1076, align 8
  %v6177 = load i64, ptr %slot1073, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6176, i64 %v6177) nomerge, !dbg !180
  br label %bb_rcslotdone1500
bb_rcslotowner1500:
  %v6178 = load i64, ptr %slot66, align 8
  store i64 %v6178, ptr %slot1077, align 8
  %v6179 = load i64, ptr %slot1077, align 8
  %v6180 = load i64, ptr %slot1073, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6179, i64 %v6180) nomerge, !dbg !180
  br label %bb_rcslotdone1500
bb_rcslotdone1500:
  %v6181 = load i64, ptr %slot26, align 8
  store i64 %v6181, ptr %slot1078, align 8
  %v6182 = load i64, ptr %slot31, align 8
  store i64 %v6182, ptr %slot1079, align 8
  %v6183 = load i64, ptr %slot1079, align 8
  %v6184 = load i64, ptr %slot1078, align 8
  %p6185 = inttoptr i64 %v6183 to ptr
  %p6186 = inttoptr i64 %v6184 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6186, ptr %p6185, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6187 = load i64, ptr %slot18, align 8
  %p6188 = inttoptr i64 %v6187 to ptr
  store i32 2, ptr %p6188, align 4, !alias.scope !3, !noalias !4
  %v6189 = load i64, ptr %slot24, align 8
  %p6190 = inttoptr i64 %v6189 to ptr
  %ld6191 = load i32, ptr %p6190, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6191, ptr %slot1080, align 8
  %v6192 = load i32, ptr %slot1080, align 8
  %v6193 = load i64, ptr %slot18, align 8
  %p6194 = inttoptr i64 %v6193 to ptr
  store i32 %v6192, ptr %p6194, align 4, !alias.scope !3, !noalias !4
  %v6195 = load i64, ptr %slot23, align 8
  %p6196 = inttoptr i64 %v6195 to ptr
  store i32 0, ptr %p6196, align 4, !alias.scope !3, !noalias !4
  %v6197 = load i64, ptr %slot17, align 8
  %p6198 = inttoptr i64 %v6197 to ptr
  store i32 1, ptr %p6198, align 4, !alias.scope !3, !noalias !4
  %v6199 = load i64, ptr %slot1078, align 8
  %p6200 = inttoptr i64 %v6199 to ptr
  %ld6201 = load i64, ptr %p6200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6201, ptr %slot1081, align 8
  %v6202 = load i64, ptr %slot1081, align 8
  %v6203 = load i64, ptr %slot54, align 8
  %p6204 = inttoptr i64 %v6203 to ptr
  store i64 %v6202, ptr %p6204, align 8, !alias.scope !3, !noalias !4
  %v6205 = load i64, ptr %slot54, align 8
  %p6206 = inttoptr i64 %v6205 to ptr
  %ld6207 = load i64, ptr %p6206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6207, ptr %slot1082, align 8
  %v6208 = load i64, ptr %slot37, align 8
  %p6209 = inttoptr i64 %v6208 to ptr
  %ld6210 = load i64, ptr %p6209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6210, ptr %slot1083, align 8
  %v6211 = load i64, ptr %slot17, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  %ld6213 = load i32, ptr %p6212, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6213, ptr %slot1084, align 8
  %v6214 = load i32, ptr %slot1084, align 8
  %cv6215 = zext i32 %v6214 to i64
  %cond6216 = icmp ne i64 %cv6215, 0
  br i1 %cond6216, label %bb_rcslotdrop1521, label %bb_rcslotdone1521
bb_rcslotdrop1521:
  %v6217 = load i64, ptr %slot17, align 8
  %p6218 = inttoptr i64 %v6217 to ptr
  store i32 0, ptr %p6218, align 4, !alias.scope !3, !noalias !4
  %v6219 = load i64, ptr %slot26, align 8
  store i64 %v6219, ptr %slot1085, align 8
  %v6220 = load i64, ptr %slot18, align 8
  %p6221 = inttoptr i64 %v6220 to ptr
  %ld6222 = load i32, ptr %p6221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6222, ptr %slot1086, align 8
  %v6223 = load i32, ptr %slot1086, align 8
  %op6224 = and i32 %v6223, 28
  store i32 %op6224, ptr %slot1087, align 8
  %v6225 = load i32, ptr %slot1087, align 8
  %cv6226 = zext i32 %v6225 to i64
  %cond6227 = icmp ne i64 %cv6226, 0
  br i1 %cond6227, label %bb_rcslotrole1521, label %bb_rcslotowner1521
bb_rcslotrole1521:
  %v6228 = load i64, ptr %slot66, align 8
  store i64 %v6228, ptr %slot1088, align 8
  %v6229 = load i64, ptr %slot1085, align 8
  %p6230 = inttoptr i64 %v6229 to ptr
  %ld6231 = load i64, ptr %p6230, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6231, ptr %slot1089, align 8
  %v6232 = load i64, ptr %slot1089, align 8
  %cmp6233 = icmp ne i64 %v6232, 0
  %cv6234 = zext i1 %cmp6233 to i32
  store i32 %cv6234, ptr %slot1090, align 8
  %v6235 = load i32, ptr %slot1090, align 8
  %cv6236 = zext i32 %v6235 to i64
  %cond6237 = icmp ne i64 %cv6236, 0
  br i1 %cond6237, label %bb_rcgnn1537, label %bb_rcgdone1537
bb_rcgnn1537:
  %v6238 = load i64, ptr %slot1089, align 8
  %op6239 = sub i64 %v6238, 16
  store i64 %op6239, ptr %slot1091, align 8
  %v6240 = load i64, ptr %slot1089, align 8
  %p6241 = inttoptr i64 %v6240 to ptr
  %rgep6242 = getelementptr i8, ptr %p6241, i64 -16
  %ld6243 = load i64, ptr %rgep6242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6243, ptr %slot1092, align 8
  %v6244 = load i64, ptr %slot1092, align 8
  %op6245 = and i64 %v6244, 4611686018427387906
  store i64 %op6245, ptr %slot1093, align 8
  %v6246 = load i64, ptr %slot1093, align 8
  %cmp6247 = icmp ne i64 %v6246, 0
  %cv6248 = zext i1 %cmp6247 to i32
  store i32 %cv6248, ptr %slot1094, align 8
  %v6249 = load i32, ptr %slot1094, align 8
  %cv6250 = zext i32 %v6249 to i64
  %cond6251 = icmp ne i64 %cv6250, 0
  br i1 %cond6251, label %bb_rcgclear1537, label %bb_rcgcounted1537
bb_rcgcounted1537:
  %v6252 = load i64, ptr %slot1089, align 8
  %op6253 = sub i64 %v6252, 24
  store i64 %op6253, ptr %slot1095, align 8
  %v6254 = load i64, ptr %slot1089, align 8
  %p6255 = inttoptr i64 %v6254 to ptr
  %rgep6256 = getelementptr i8, ptr %p6255, i64 -24
  %ld6257 = load i64, ptr %rgep6256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6257, ptr %slot1096, align 8
  %v6258 = load i64, ptr %slot1096, align 8
  %op6259 = sub i64 %v6258, 1
  store i64 %op6259, ptr %slot1097, align 8
  %v6260 = load i64, ptr %slot1097, align 8
  %cmp6261 = icmp eq i64 %v6260, 0
  %cv6262 = zext i1 %cmp6261 to i32
  store i32 %cv6262, ptr %slot1098, align 8
  %v6263 = load i32, ptr %slot1098, align 8
  %cv6264 = zext i32 %v6263 to i64
  %cond6265 = icmp ne i64 %cv6264, 0
  br i1 %cond6265, label %bb_rcglast1537, label %bb_rcgdec1537
bb_rcglast1537:
  %v6266 = load i64, ptr %slot1089, align 8
  %op6267 = sub i64 %v6266, 32
  store i64 %op6267, ptr %slot1099, align 8
  %v6268 = load i64, ptr %slot1089, align 8
  %p6269 = inttoptr i64 %v6268 to ptr
  %rgep6270 = getelementptr i8, ptr %p6269, i64 -32
  %ld6271 = load i64, ptr %rgep6270, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6271, ptr %slot1100, align 8
  %v6272 = load i64, ptr %slot1100, align 8
  %cmp6273 = icmp ne i64 %v6272, 0
  %cv6274 = zext i1 %cmp6273 to i32
  store i32 %cv6274, ptr %slot1101, align 8
  %v6275 = load i32, ptr %slot1101, align 8
  %cv6276 = zext i32 %v6275 to i64
  %cond6277 = icmp ne i64 %cv6276, 0
  br i1 %cond6277, label %bb_rcgdec1537, label %bb_rcgslow1537
bb_rcgslow1537:
  %v6278 = load i64, ptr %slot1088, align 8
  %v6279 = load i64, ptr %slot1085, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v6278, i64 %v6279) nomerge, !dbg !182
  br label %bb_rcgdone1537
bb_rcgdec1537:
  %v6280 = load i64, ptr %slot1097, align 8
  %v6281 = load i64, ptr %slot1089, align 8
  %p6282 = inttoptr i64 %v6281 to ptr
  %rgep6283 = getelementptr i8, ptr %p6282, i64 -24
  store i64 %v6280, ptr %rgep6283, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1537
bb_rcgclear1537:
  %v6284 = load i64, ptr %slot1085, align 8
  %p6285 = inttoptr i64 %v6284 to ptr
  store i64 0, ptr %p6285, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1537
bb_rcgdone1537:
  br label %bb_rcslotdone1521
bb_rcslotowner1521:
  %v6286 = load i64, ptr %slot66, align 8
  store i64 %v6286, ptr %slot1102, align 8
  %v6287 = load i64, ptr %slot1085, align 8
  %p6288 = inttoptr i64 %v6287 to ptr
  %ld6289 = load i64, ptr %p6288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6289, ptr %slot1103, align 8
  %v6290 = load i64, ptr %slot1103, align 8
  %cmp6291 = icmp ne i64 %v6290, 0
  %cv6292 = zext i1 %cmp6291 to i32
  store i32 %cv6292, ptr %slot1104, align 8
  %v6293 = load i32, ptr %slot1104, align 8
  %cv6294 = zext i32 %v6293 to i64
  %cond6295 = icmp ne i64 %cv6294, 0
  br i1 %cond6295, label %bb_rcgnn1552, label %bb_rcgdone1552
bb_rcgnn1552:
  %v6296 = load i64, ptr %slot1103, align 8
  %op6297 = sub i64 %v6296, 16
  store i64 %op6297, ptr %slot1105, align 8
  %v6298 = load i64, ptr %slot1103, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  %rgep6300 = getelementptr i8, ptr %p6299, i64 -16
  %ld6301 = load i64, ptr %rgep6300, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6301, ptr %slot1106, align 8
  %v6302 = load i64, ptr %slot1106, align 8
  %op6303 = and i64 %v6302, 4611686018427387906
  store i64 %op6303, ptr %slot1107, align 8
  %v6304 = load i64, ptr %slot1107, align 8
  %cmp6305 = icmp ne i64 %v6304, 0
  %cv6306 = zext i1 %cmp6305 to i32
  store i32 %cv6306, ptr %slot1108, align 8
  %v6307 = load i32, ptr %slot1108, align 8
  %cv6308 = zext i32 %v6307 to i64
  %cond6309 = icmp ne i64 %cv6308, 0
  br i1 %cond6309, label %bb_rcgclear1552, label %bb_rcgcounted1552
bb_rcgcounted1552:
  %v6310 = load i64, ptr %slot1103, align 8
  %op6311 = sub i64 %v6310, 32
  store i64 %op6311, ptr %slot1109, align 8
  %v6312 = load i64, ptr %slot1103, align 8
  %p6313 = inttoptr i64 %v6312 to ptr
  %rgep6314 = getelementptr i8, ptr %p6313, i64 -32
  %ld6315 = load i64, ptr %rgep6314, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6315, ptr %slot1110, align 8
  %v6316 = load i64, ptr %slot1110, align 8
  %op6317 = sub i64 %v6316, 1
  store i64 %op6317, ptr %slot1111, align 8
  %v6318 = load i64, ptr %slot1111, align 8
  %cmp6319 = icmp eq i64 %v6318, 0
  %cv6320 = zext i1 %cmp6319 to i32
  store i32 %cv6320, ptr %slot1112, align 8
  %v6321 = load i32, ptr %slot1112, align 8
  %cv6322 = zext i32 %v6321 to i64
  %cond6323 = icmp ne i64 %cv6322, 0
  br i1 %cond6323, label %bb_rcglast1552, label %bb_rcgdec1552
bb_rcglast1552:
  %v6324 = load i64, ptr %slot1103, align 8
  %op6325 = sub i64 %v6324, 24
  store i64 %op6325, ptr %slot1113, align 8
  %v6326 = load i64, ptr %slot1103, align 8
  %p6327 = inttoptr i64 %v6326 to ptr
  %rgep6328 = getelementptr i8, ptr %p6327, i64 -24
  %ld6329 = load i64, ptr %rgep6328, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6329, ptr %slot1114, align 8
  %v6330 = load i64, ptr %slot1114, align 8
  %cmp6331 = icmp ne i64 %v6330, 0
  %cv6332 = zext i1 %cmp6331 to i32
  store i32 %cv6332, ptr %slot1115, align 8
  %v6333 = load i32, ptr %slot1115, align 8
  %cv6334 = zext i32 %v6333 to i64
  %cond6335 = icmp ne i64 %cv6334, 0
  br i1 %cond6335, label %bb_rcgdec1552, label %bb_rcgslow1552
bb_rcgslow1552:
  %v6336 = load i64, ptr %slot1102, align 8
  %v6337 = load i64, ptr %slot1085, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v6336, i64 %v6337) nomerge, !dbg !182
  br label %bb_rcgdone1552
bb_rcgdec1552:
  %v6338 = load i64, ptr %slot1111, align 8
  %v6339 = load i64, ptr %slot1103, align 8
  %p6340 = inttoptr i64 %v6339 to ptr
  %rgep6341 = getelementptr i8, ptr %p6340, i64 -32
  store i64 %v6338, ptr %rgep6341, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1552
bb_rcgclear1552:
  %v6342 = load i64, ptr %slot1085, align 8
  %p6343 = inttoptr i64 %v6342 to ptr
  store i64 0, ptr %p6343, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1552
bb_rcgdone1552:
  br label %bb_rcslotdone1521
bb_rcslotdone1521:
  %v6344 = load i64, ptr %slot1083, align 8
  %op6345 = add i64 %v6344, 0
  store i64 %op6345, ptr %slot1116, align 8
  %v6346 = load i64, ptr %slot1116, align 8
  %op6347 = add i64 %v6346, 0
  store i64 %op6347, ptr %slot1117, align 8
  store i64 0, ptr %slot1118, align 8
  %v6348 = load i64, ptr %slot1117, align 8
  %p6349 = inttoptr i64 %v6348 to ptr
  %ld6350 = load i64, ptr %p6349, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6350, ptr %slot1119, align 8
  %v6351 = load i64, ptr %slot1119, align 8
  %cmp6352 = icmp ne i64 %v6351, 0
  %cv6353 = zext i1 %cmp6352 to i32
  store i32 %cv6353, ptr %slot1120, align 8
  %v6354 = load i32, ptr %slot1120, align 8
  %cv6355 = zext i32 %v6354 to i64
  %cond6356 = icmp ne i64 %cv6355, 0
  br i1 %cond6356, label %bb_rcguniquenn1559, label %bb_rcgunique1559
bb_rcguniquenn1559:
  %v6357 = load i64, ptr %slot1119, align 8
  %op6358 = sub i64 %v6357, 16
  store i64 %op6358, ptr %slot1121, align 8
  %v6359 = load i64, ptr %slot1119, align 8
  %p6360 = inttoptr i64 %v6359 to ptr
  %rgep6361 = getelementptr i8, ptr %p6360, i64 -16
  %ld6362 = load i64, ptr %rgep6361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6362, ptr %slot1122, align 8
  %v6363 = load i64, ptr %slot1122, align 8
  %op6364 = and i64 %v6363, 6917529027641081858
  store i64 %op6364, ptr %slot1123, align 8
  %v6365 = load i64, ptr %slot1123, align 8
  %cmp6366 = icmp ne i64 %v6365, 0
  %cv6367 = zext i1 %cmp6366 to i32
  store i32 %cv6367, ptr %slot1124, align 8
  %v6368 = load i32, ptr %slot1124, align 8
  %cv6369 = zext i32 %v6368 to i64
  %cond6370 = icmp ne i64 %cv6369, 0
  br i1 %cond6370, label %bb_rcguniqueslow1559, label %bb_rcguniquecount1559
bb_rcguniquecount1559:
  %v6371 = load i64, ptr %slot1119, align 8
  %op6372 = sub i64 %v6371, 32
  store i64 %op6372, ptr %slot1125, align 8
  %v6373 = load i64, ptr %slot1119, align 8
  %p6374 = inttoptr i64 %v6373 to ptr
  %rgep6375 = getelementptr i8, ptr %p6374, i64 -32
  %ld6376 = load i64, ptr %rgep6375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6376, ptr %slot1126, align 8
  %v6377 = load i64, ptr %slot1126, align 8
  %cmp6378 = icmp ult i64 %v6377, 2
  %cv6379 = zext i1 %cmp6378 to i32
  store i32 %cv6379, ptr %slot1127, align 8
  %v6380 = load i32, ptr %slot1127, align 8
  %cv6381 = zext i32 %v6380 to i64
  %cond6382 = icmp ne i64 %cv6381, 0
  br i1 %cond6382, label %bb_rcgunique1559, label %bb_rcguniqueslow1559
bb_rcguniqueslow1559:
  %v6383 = load i64, ptr %slot1, align 8
  %p6384 = inttoptr i64 %v6383 to ptr
  %p6385 = inttoptr i64 ptrtoint (ptr @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 to i64) to ptr
  %v6386 = load i64, ptr %slot1117, align 8
  %p6387 = inttoptr i64 %v6386 to ptr
  %v6388 = load i64, ptr %slot1118, align 8
  %p6389 = inttoptr i64 %v6388 to ptr
  %call6390 = call i32 @myl_qbe_rc_unique_field(ptr %p6384, ptr %p6385, ptr %p6387, ptr %p6389) nomerge, !dbg !182
  store i32 %call6390, ptr %slot1128, align 8
  %v6391 = load i32, ptr %slot1128, align 8
  %cv6392 = zext i32 %v6391 to i64
  %cond6393 = icmp ne i64 %cv6392, 0
  br i1 %cond6393, label %bb_rcunique1569, label %bb_failure
bb_rcunique1569:
  br label %bb_rcgunique1559
bb_rcgunique1559:
  %v6394 = load i64, ptr %slot1117, align 8
  %p6395 = inttoptr i64 %v6394 to ptr
  %ld6396 = load i64, ptr %p6395, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6396, ptr %slot1129, align 8
  %v6397 = load i64, ptr %slot1129, align 8
  %v6398 = load i64, ptr %slot54, align 8
  %p6399 = inttoptr i64 %v6398 to ptr
  store i64 %v6397, ptr %p6399, align 8, !alias.scope !3, !noalias !4
  %v6400 = load i64, ptr %slot54, align 8
  %p6401 = inttoptr i64 %v6400 to ptr
  %ld6402 = load i64, ptr %p6401, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6402, ptr %slot1130, align 8
  %v6403 = load i64, ptr %slot17, align 8
  %p6404 = inttoptr i64 %v6403 to ptr
  %ld6405 = load i32, ptr %p6404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6405, ptr %slot1131, align 8
  %v6406 = load i32, ptr %slot1131, align 8
  %cv6407 = zext i32 %v6406 to i64
  %cond6408 = icmp ne i64 %cv6407, 0
  br i1 %cond6408, label %bb_rcslotdrop1574, label %bb_rcslotdone1574
bb_rcslotdrop1574:
  %v6409 = load i64, ptr %slot17, align 8
  %p6410 = inttoptr i64 %v6409 to ptr
  store i32 0, ptr %p6410, align 4, !alias.scope !3, !noalias !4
  %v6411 = load i64, ptr %slot26, align 8
  store i64 %v6411, ptr %slot1132, align 8
  %v6412 = load i64, ptr %slot18, align 8
  %p6413 = inttoptr i64 %v6412 to ptr
  %ld6414 = load i32, ptr %p6413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6414, ptr %slot1133, align 8
  %v6415 = load i32, ptr %slot1133, align 8
  %op6416 = and i32 %v6415, 28
  store i32 %op6416, ptr %slot1134, align 8
  %v6417 = load i32, ptr %slot1134, align 8
  %cv6418 = zext i32 %v6417 to i64
  %cond6419 = icmp ne i64 %cv6418, 0
  br i1 %cond6419, label %bb_rcslotrole1574, label %bb_rcslotowner1574
bb_rcslotrole1574:
  %v6420 = load i64, ptr %slot66, align 8
  store i64 %v6420, ptr %slot1135, align 8
  %v6421 = load i64, ptr %slot1132, align 8
  %p6422 = inttoptr i64 %v6421 to ptr
  %ld6423 = load i64, ptr %p6422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6423, ptr %slot1136, align 8
  %v6424 = load i64, ptr %slot1136, align 8
  %cmp6425 = icmp ne i64 %v6424, 0
  %cv6426 = zext i1 %cmp6425 to i32
  store i32 %cv6426, ptr %slot1137, align 8
  %v6427 = load i32, ptr %slot1137, align 8
  %cv6428 = zext i32 %v6427 to i64
  %cond6429 = icmp ne i64 %cv6428, 0
  br i1 %cond6429, label %bb_rcgnn1590, label %bb_rcgdone1590
bb_rcgnn1590:
  %v6430 = load i64, ptr %slot1136, align 8
  %op6431 = sub i64 %v6430, 16
  store i64 %op6431, ptr %slot1138, align 8
  %v6432 = load i64, ptr %slot1136, align 8
  %p6433 = inttoptr i64 %v6432 to ptr
  %rgep6434 = getelementptr i8, ptr %p6433, i64 -16
  %ld6435 = load i64, ptr %rgep6434, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6435, ptr %slot1139, align 8
  %v6436 = load i64, ptr %slot1139, align 8
  %op6437 = and i64 %v6436, 4611686018427387906
  store i64 %op6437, ptr %slot1140, align 8
  %v6438 = load i64, ptr %slot1140, align 8
  %cmp6439 = icmp ne i64 %v6438, 0
  %cv6440 = zext i1 %cmp6439 to i32
  store i32 %cv6440, ptr %slot1141, align 8
  %v6441 = load i32, ptr %slot1141, align 8
  %cv6442 = zext i32 %v6441 to i64
  %cond6443 = icmp ne i64 %cv6442, 0
  br i1 %cond6443, label %bb_rcgclear1590, label %bb_rcgcounted1590
bb_rcgcounted1590:
  %v6444 = load i64, ptr %slot1136, align 8
  %op6445 = sub i64 %v6444, 24
  store i64 %op6445, ptr %slot1142, align 8
  %v6446 = load i64, ptr %slot1136, align 8
  %p6447 = inttoptr i64 %v6446 to ptr
  %rgep6448 = getelementptr i8, ptr %p6447, i64 -24
  %ld6449 = load i64, ptr %rgep6448, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6449, ptr %slot1143, align 8
  %v6450 = load i64, ptr %slot1143, align 8
  %op6451 = sub i64 %v6450, 1
  store i64 %op6451, ptr %slot1144, align 8
  %v6452 = load i64, ptr %slot1144, align 8
  %cmp6453 = icmp eq i64 %v6452, 0
  %cv6454 = zext i1 %cmp6453 to i32
  store i32 %cv6454, ptr %slot1145, align 8
  %v6455 = load i32, ptr %slot1145, align 8
  %cv6456 = zext i32 %v6455 to i64
  %cond6457 = icmp ne i64 %cv6456, 0
  br i1 %cond6457, label %bb_rcglast1590, label %bb_rcgdec1590
bb_rcglast1590:
  %v6458 = load i64, ptr %slot1136, align 8
  %op6459 = sub i64 %v6458, 32
  store i64 %op6459, ptr %slot1146, align 8
  %v6460 = load i64, ptr %slot1136, align 8
  %p6461 = inttoptr i64 %v6460 to ptr
  %rgep6462 = getelementptr i8, ptr %p6461, i64 -32
  %ld6463 = load i64, ptr %rgep6462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6463, ptr %slot1147, align 8
  %v6464 = load i64, ptr %slot1147, align 8
  %cmp6465 = icmp ne i64 %v6464, 0
  %cv6466 = zext i1 %cmp6465 to i32
  store i32 %cv6466, ptr %slot1148, align 8
  %v6467 = load i32, ptr %slot1148, align 8
  %cv6468 = zext i32 %v6467 to i64
  %cond6469 = icmp ne i64 %cv6468, 0
  br i1 %cond6469, label %bb_rcgdec1590, label %bb_rcgslow1590
bb_rcgslow1590:
  %v6470 = load i64, ptr %slot1135, align 8
  %v6471 = load i64, ptr %slot1132, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64 %v6470, i64 %v6471) nomerge, !dbg !182
  br label %bb_rcgdone1590
bb_rcgdec1590:
  %v6472 = load i64, ptr %slot1144, align 8
  %v6473 = load i64, ptr %slot1136, align 8
  %p6474 = inttoptr i64 %v6473 to ptr
  %rgep6475 = getelementptr i8, ptr %p6474, i64 -24
  store i64 %v6472, ptr %rgep6475, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1590
bb_rcgclear1590:
  %v6476 = load i64, ptr %slot1132, align 8
  %p6477 = inttoptr i64 %v6476 to ptr
  store i64 0, ptr %p6477, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1590
bb_rcgdone1590:
  br label %bb_rcslotdone1574
bb_rcslotowner1574:
  %v6478 = load i64, ptr %slot66, align 8
  store i64 %v6478, ptr %slot1149, align 8
  %v6479 = load i64, ptr %slot1132, align 8
  %p6480 = inttoptr i64 %v6479 to ptr
  %ld6481 = load i64, ptr %p6480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6481, ptr %slot1150, align 8
  %v6482 = load i64, ptr %slot1150, align 8
  %cmp6483 = icmp ne i64 %v6482, 0
  %cv6484 = zext i1 %cmp6483 to i32
  store i32 %cv6484, ptr %slot1151, align 8
  %v6485 = load i32, ptr %slot1151, align 8
  %cv6486 = zext i32 %v6485 to i64
  %cond6487 = icmp ne i64 %cv6486, 0
  br i1 %cond6487, label %bb_rcgnn1605, label %bb_rcgdone1605
bb_rcgnn1605:
  %v6488 = load i64, ptr %slot1150, align 8
  %op6489 = sub i64 %v6488, 16
  store i64 %op6489, ptr %slot1152, align 8
  %v6490 = load i64, ptr %slot1150, align 8
  %p6491 = inttoptr i64 %v6490 to ptr
  %rgep6492 = getelementptr i8, ptr %p6491, i64 -16
  %ld6493 = load i64, ptr %rgep6492, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6493, ptr %slot1153, align 8
  %v6494 = load i64, ptr %slot1153, align 8
  %op6495 = and i64 %v6494, 4611686018427387906
  store i64 %op6495, ptr %slot1154, align 8
  %v6496 = load i64, ptr %slot1154, align 8
  %cmp6497 = icmp ne i64 %v6496, 0
  %cv6498 = zext i1 %cmp6497 to i32
  store i32 %cv6498, ptr %slot1155, align 8
  %v6499 = load i32, ptr %slot1155, align 8
  %cv6500 = zext i32 %v6499 to i64
  %cond6501 = icmp ne i64 %cv6500, 0
  br i1 %cond6501, label %bb_rcgclear1605, label %bb_rcgcounted1605
bb_rcgcounted1605:
  %v6502 = load i64, ptr %slot1150, align 8
  %op6503 = sub i64 %v6502, 32
  store i64 %op6503, ptr %slot1156, align 8
  %v6504 = load i64, ptr %slot1150, align 8
  %p6505 = inttoptr i64 %v6504 to ptr
  %rgep6506 = getelementptr i8, ptr %p6505, i64 -32
  %ld6507 = load i64, ptr %rgep6506, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6507, ptr %slot1157, align 8
  %v6508 = load i64, ptr %slot1157, align 8
  %op6509 = sub i64 %v6508, 1
  store i64 %op6509, ptr %slot1158, align 8
  %v6510 = load i64, ptr %slot1158, align 8
  %cmp6511 = icmp eq i64 %v6510, 0
  %cv6512 = zext i1 %cmp6511 to i32
  store i32 %cv6512, ptr %slot1159, align 8
  %v6513 = load i32, ptr %slot1159, align 8
  %cv6514 = zext i32 %v6513 to i64
  %cond6515 = icmp ne i64 %cv6514, 0
  br i1 %cond6515, label %bb_rcglast1605, label %bb_rcgdec1605
bb_rcglast1605:
  %v6516 = load i64, ptr %slot1150, align 8
  %op6517 = sub i64 %v6516, 24
  store i64 %op6517, ptr %slot1160, align 8
  %v6518 = load i64, ptr %slot1150, align 8
  %p6519 = inttoptr i64 %v6518 to ptr
  %rgep6520 = getelementptr i8, ptr %p6519, i64 -24
  %ld6521 = load i64, ptr %rgep6520, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6521, ptr %slot1161, align 8
  %v6522 = load i64, ptr %slot1161, align 8
  %cmp6523 = icmp ne i64 %v6522, 0
  %cv6524 = zext i1 %cmp6523 to i32
  store i32 %cv6524, ptr %slot1162, align 8
  %v6525 = load i32, ptr %slot1162, align 8
  %cv6526 = zext i32 %v6525 to i64
  %cond6527 = icmp ne i64 %cv6526, 0
  br i1 %cond6527, label %bb_rcgdec1605, label %bb_rcgslow1605
bb_rcgslow1605:
  %v6528 = load i64, ptr %slot1149, align 8
  %v6529 = load i64, ptr %slot1132, align 8
  call void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64 %v6528, i64 %v6529) nomerge, !dbg !182
  br label %bb_rcgdone1605
bb_rcgdec1605:
  %v6530 = load i64, ptr %slot1158, align 8
  %v6531 = load i64, ptr %slot1150, align 8
  %p6532 = inttoptr i64 %v6531 to ptr
  %rgep6533 = getelementptr i8, ptr %p6532, i64 -32
  store i64 %v6530, ptr %rgep6533, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1605
bb_rcgclear1605:
  %v6534 = load i64, ptr %slot1132, align 8
  %p6535 = inttoptr i64 %v6534 to ptr
  store i64 0, ptr %p6535, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1605
bb_rcgdone1605:
  br label %bb_rcslotdone1574
bb_rcslotdone1574:
  %v6536 = load i64, ptr %slot34, align 8
  store i64 %v6536, ptr %slot1163, align 8
  %v6537 = load i64, ptr %slot66, align 8
  %v6538 = load i64, ptr %slot1163, align 8
  %p6539 = inttoptr i64 %v6538 to ptr
  store i64 %v6537, ptr %p6539, align 8, !alias.scope !3, !noalias !4
  %v6540 = load i64, ptr %slot66, align 8
  %p6542 = inttoptr i64 %v6540 to ptr
  %gep6543 = getelementptr i8, ptr %p6542, i64 5640
  %op6541 = ptrtoint ptr %gep6543 to i64
  store i64 %op6541, ptr %slot1164, align 8
  %v6544 = load i64, ptr %slot1164, align 8
  %p6545 = inttoptr i64 %v6544 to ptr
  %ld6546 = load i64, ptr %p6545, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6546, ptr %slot1165, align 8
  %v6547 = load i64, ptr %slot1165, align 8
  %op6548 = add i64 %v6547, 248
  store i64 %op6548, ptr %slot1166, align 8
  %v6549 = load i64, ptr %slot1166, align 8
  %p6550 = inttoptr i64 %v6549 to ptr
  %ld6551 = load i64, ptr %p6550, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6551, ptr %slot1167, align 8
  %v6552 = load i64, ptr %slot1163, align 8
  %p6554 = inttoptr i64 %v6552 to ptr
  %gep6555 = getelementptr i8, ptr %p6554, i64 8
  %op6553 = ptrtoint ptr %gep6555 to i64
  store i64 %op6553, ptr %slot1168, align 8
  %v6556 = load i64, ptr %slot1167, align 8
  %v6557 = load i64, ptr %slot1168, align 8
  %p6558 = inttoptr i64 %v6557 to ptr
  store i64 %v6556, ptr %p6558, align 8, !alias.scope !3, !noalias !4
  %v6559 = load i64, ptr %slot1163, align 8
  %p6561 = inttoptr i64 %v6559 to ptr
  %gep6562 = getelementptr i8, ptr %p6561, i64 16
  %op6560 = ptrtoint ptr %gep6562 to i64
  store i64 %op6560, ptr %slot1169, align 8
  %v6563 = load i64, ptr %slot1169, align 8
  %p6564 = inttoptr i64 %v6563 to ptr
  store i64 0, ptr %p6564, align 8, !alias.scope !3, !noalias !4
  %v6565 = load i64, ptr %slot66, align 8
  %p6567 = inttoptr i64 %v6565 to ptr
  %gep6568 = getelementptr i8, ptr %p6567, i64 112
  %op6566 = ptrtoint ptr %gep6568 to i64
  store i64 %op6566, ptr %slot1170, align 8
  %v6569 = load i64, ptr %slot1163, align 8
  %p6571 = inttoptr i64 %v6569 to ptr
  %gep6572 = getelementptr i8, ptr %p6571, i64 24
  %op6570 = ptrtoint ptr %gep6572 to i64
  store i64 %op6570, ptr %slot1171, align 8
  %v6573 = load i64, ptr %slot1163, align 8
  %p6575 = inttoptr i64 %v6573 to ptr
  %gep6576 = getelementptr i8, ptr %p6575, i64 28
  %op6574 = ptrtoint ptr %gep6576 to i64
  store i64 %op6574, ptr %slot1172, align 8
  %v6577 = load i64, ptr %slot1170, align 8
  %p6578 = inttoptr i64 %v6577 to ptr
  %ld6579 = load i32, ptr %p6578, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld6579, ptr %slot1173, align 8
  %v6580 = load i64, ptr %slot1171, align 8
  %p6581 = inttoptr i64 %v6580 to ptr
  store i32 1, ptr %p6581, align 4, !alias.scope !3, !noalias !4
  %v6582 = load i32, ptr %slot1173, align 8
  %v6583 = load i64, ptr %slot1172, align 8
  %p6584 = inttoptr i64 %v6583 to ptr
  store i32 %v6582, ptr %p6584, align 4, !alias.scope !3, !noalias !4
  %v6585 = load i64, ptr %slot1163, align 8
  %v6586 = load i64, ptr %slot1166, align 8
  %p6587 = inttoptr i64 %v6586 to ptr
  store i64 %v6585, ptr %p6587, align 8, !alias.scope !9999998, !noalias !9999999
  %v6588 = load i64, ptr %slot1130, align 8
  %cmp6589 = icmp ne i64 %v6588, 0
  %cv6590 = zext i1 %cmp6589 to i32
  store i32 %cv6590, ptr %slot1174, align 8
  %v6591 = load i32, ptr %slot1174, align 8
  %cv6592 = zext i32 %v6591 to i64
  %cond6593 = icmp ne i64 %cv6592, 0
  br i1 %cond6593, label %bb_rcspinmark1657, label %bb_rcspindone1657
bb_rcspinmark1657:
  %v6594 = load i64, ptr %slot1130, align 8
  %op6595 = sub i64 %v6594, 16
  store i64 %op6595, ptr %slot1175, align 8
  %v6596 = load i64, ptr %slot1130, align 8
  %p6597 = inttoptr i64 %v6596 to ptr
  %rgep6598 = getelementptr i8, ptr %p6597, i64 -16
  %ld6599 = load i64, ptr %rgep6598, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6599, ptr %slot1176, align 8
  %v6600 = load i64, ptr %slot1176, align 8
  %op6601 = and i64 %v6600, 2
  store i64 %op6601, ptr %slot1177, align 8
  %v6602 = load i64, ptr %slot1177, align 8
  %cmp6603 = icmp ne i64 %v6602, 0
  %cv6604 = zext i1 %cmp6603 to i32
  store i32 %cv6604, ptr %slot1178, align 8
  %v6605 = load i32, ptr %slot1178, align 8
  %cv6606 = zext i32 %v6605 to i64
  %cond6607 = icmp ne i64 %cv6606, 0
  br i1 %cond6607, label %bb_rcspindone1657, label %bb_rcspintype1657
bb_rcspintype1657:
  %v6608 = load i64, ptr %slot1176, align 8
  %op6609 = and i64 %v6608, 4611686018427387907
  store i64 %op6609, ptr %slot1179, align 8
  %v6610 = load i64, ptr %slot1179, align 8
  %cmp6611 = icmp eq i64 %v6610, 0
  %cv6612 = zext i1 %cmp6611 to i32
  store i32 %cv6612, ptr %slot1180, align 8
  %v6613 = load i32, ptr %slot1180, align 8
  %cv6614 = zext i32 %v6613 to i64
  %cond6615 = icmp ne i64 %cv6614, 0
  br i1 %cond6615, label %bb_rcs1665, label %bb_rcspinslow1657
bb_rcs1665:
  %v6616 = load i64, ptr %slot1130, align 8
  %op6617 = sub i64 %v6616, 8
  store i64 %op6617, ptr %slot1181, align 8
  %v6618 = load i64, ptr %slot1130, align 8
  %p6619 = inttoptr i64 %v6618 to ptr
  %rgep6620 = getelementptr i8, ptr %p6619, i64 -8
  %ld6621 = load i64, ptr %rgep6620, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6621, ptr %slot1182, align 8
  %p6622 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld6623 = load i64, ptr %p6622, align 8, !alias.scope !4, !noalias !3
  store i64 %ld6623, ptr %slot1183, align 8
  %v6624 = load i64, ptr %slot1182, align 8
  %v6625 = load i64, ptr %slot1183, align 8
  %cmp6626 = icmp eq i64 %v6624, %v6625
  %cv6627 = zext i1 %cmp6626 to i32
  store i32 %cv6627, ptr %slot1184, align 8
  %v6628 = load i32, ptr %slot1184, align 8
  %cv6629 = zext i32 %v6628 to i64
  %cond6630 = icmp ne i64 %cv6629, 0
  br i1 %cond6630, label %bb_rcs1670, label %bb_rcspinslow1657
bb_rcs1670:
  %v6631 = load i64, ptr %slot66, align 8
  %p6633 = inttoptr i64 %v6631 to ptr
  %gep6634 = getelementptr i8, ptr %p6633, i64 5640
  %op6632 = ptrtoint ptr %gep6634 to i64
  store i64 %op6632, ptr %slot1185, align 8
  %v6635 = load i64, ptr %slot1185, align 8
  %p6636 = inttoptr i64 %v6635 to ptr
  %ld6637 = load i64, ptr %p6636, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6637, ptr %slot1186, align 8
  %v6638 = load i64, ptr %slot1186, align 8
  %op6639 = add i64 %v6638, 256
  store i64 %op6639, ptr %slot1187, align 8
  %v6640 = load i64, ptr %slot1187, align 8
  %p6641 = inttoptr i64 %v6640 to ptr
  %ld6642 = load i64, ptr %p6641, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6642, ptr %slot1188, align 8
  %v6643 = load i64, ptr %slot1188, align 8
  %cmp6644 = icmp ne i64 %v6643, 0
  %cv6645 = zext i1 %cmp6644 to i32
  store i32 %cv6645, ptr %slot1189, align 8
  %v6646 = load i32, ptr %slot1189, align 8
  %cv6647 = zext i32 %v6646 to i64
  %cond6648 = icmp ne i64 %cv6647, 0
  br i1 %cond6648, label %bb_rcs1676, label %bb_rcspinslow1657
bb_rcs1676:
  %v6649 = load i64, ptr %slot66, align 8
  %p6651 = inttoptr i64 %v6649 to ptr
  %gep6652 = getelementptr i8, ptr %p6651, i64 24
  %op6650 = ptrtoint ptr %gep6652 to i64
  store i64 %op6650, ptr %slot1190, align 8
  %v6653 = load i64, ptr %slot1190, align 8
  %p6654 = inttoptr i64 %v6653 to ptr
  %ld6655 = load i64, ptr %p6654, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6655, ptr %slot1191, align 8
  %v6656 = load i64, ptr %slot1191, align 8
  %op6657 = add i64 %v6656, 40
  store i64 %op6657, ptr %slot1192, align 8
  %v6658 = load i64, ptr %slot1192, align 8
  %v6659 = load i64, ptr %slot1191, align 8
  %cmp6660 = icmp uge i64 %v6658, %v6659
  %cv6661 = zext i1 %cmp6660 to i32
  store i32 %cv6661, ptr %slot1193, align 8
  %v6662 = load i32, ptr %slot1193, align 8
  %cv6663 = zext i32 %v6662 to i64
  %cond6664 = icmp ne i64 %cv6663, 0
  br i1 %cond6664, label %bb_rcs1681, label %bb_rcspinslow1657
bb_rcs1681:
  %v6665 = load i64, ptr %slot66, align 8
  %p6667 = inttoptr i64 %v6665 to ptr
  %gep6668 = getelementptr i8, ptr %p6667, i64 88
  %op6666 = ptrtoint ptr %gep6668 to i64
  store i64 %op6666, ptr %slot1194, align 8
  %v6669 = load i64, ptr %slot1194, align 8
  %p6670 = inttoptr i64 %v6669 to ptr
  %ld6671 = load i64, ptr %p6670, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6671, ptr %slot1195, align 8
  %v6672 = load i64, ptr %slot1195, align 8
  %cmp6673 = icmp eq i64 %v6672, 0
  %cv6674 = zext i1 %cmp6673 to i32
  store i32 %cv6674, ptr %slot1196, align 8
  %v6675 = load i64, ptr %slot1192, align 8
  %v6676 = load i64, ptr %slot1195, align 8
  %cmp6677 = icmp ule i64 %v6675, %v6676
  %cv6678 = zext i1 %cmp6677 to i32
  store i32 %cv6678, ptr %slot1197, align 8
  %v6679 = load i32, ptr %slot1196, align 8
  %v6680 = load i32, ptr %slot1197, align 8
  %op6681 = or i32 %v6679, %v6680
  store i32 %op6681, ptr %slot1198, align 8
  %v6682 = load i32, ptr %slot1198, align 8
  %cv6683 = zext i32 %v6682 to i64
  %cond6684 = icmp ne i64 %cv6683, 0
  br i1 %cond6684, label %bb_rcs1687, label %bb_rcspinslow1657
bb_rcs1687:
  %v6685 = load i64, ptr %slot1130, align 8
  %op6686 = sub i64 %v6685, 24
  store i64 %op6686, ptr %slot1199, align 8
  %v6687 = load i64, ptr %slot1130, align 8
  %p6688 = inttoptr i64 %v6687 to ptr
  %rgep6689 = getelementptr i8, ptr %p6688, i64 -24
  %ld6690 = load i64, ptr %rgep6689, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6690, ptr %slot1200, align 8
  %v6691 = load i64, ptr %slot1200, align 8
  %cmp6692 = icmp ne i64 %v6691, 18446744073709551615
  %cv6693 = zext i1 %cmp6692 to i32
  store i32 %cv6693, ptr %slot1201, align 8
  %v6694 = load i32, ptr %slot1201, align 8
  %cv6695 = zext i32 %v6694 to i64
  %cond6696 = icmp ne i64 %cv6695, 0
  br i1 %cond6696, label %bb_rcs1691, label %bb_rcspinslow1657
bb_rcs1691:
  %v6697 = load i64, ptr %slot1130, align 8
  %op6698 = add i64 %v6697, 32
  store i64 %op6698, ptr %slot1202, align 8
  %v6699 = load i64, ptr %slot1202, align 8
  %p6700 = inttoptr i64 %v6699 to ptr
  %ld6701 = load i64, ptr %p6700, align 8
  store i64 %ld6701, ptr %slot1203, align 8
  %v6702 = load i64, ptr %slot1203, align 8
  %cmp6703 = icmp ne i64 %v6702, 0
  %cv6704 = zext i1 %cmp6703 to i32
  store i32 %cv6704, ptr %slot1204, align 8
  %v6705 = load i32, ptr %slot1204, align 8
  %cv6706 = zext i32 %v6705 to i64
  %cond6707 = icmp ne i64 %cv6706, 0
  br i1 %cond6707, label %bb_rcspinbacking1657, label %bb_rcspincommit1657
bb_rcspinbacking1657:
  %v6708 = load i64, ptr %slot1203, align 8
  %op6709 = sub i64 %v6708, 16
  store i64 %op6709, ptr %slot1205, align 8
  %v6710 = load i64, ptr %slot1203, align 8
  %p6711 = inttoptr i64 %v6710 to ptr
  %rgep6712 = getelementptr i8, ptr %p6711, i64 -16
  %ld6713 = load i64, ptr %rgep6712, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6713, ptr %slot1206, align 8
  %v6714 = load i64, ptr %slot1206, align 8
  %op6715 = and i64 %v6714, 4611686018427387907
  store i64 %op6715, ptr %slot1207, align 8
  %v6716 = load i64, ptr %slot1207, align 8
  %cmp6717 = icmp eq i64 %v6716, 0
  %cv6718 = zext i1 %cmp6717 to i32
  store i32 %cv6718, ptr %slot1208, align 8
  %v6719 = load i32, ptr %slot1208, align 8
  %cv6720 = zext i32 %v6719 to i64
  %cond6721 = icmp ne i64 %cv6720, 0
  br i1 %cond6721, label %bb_rcs1699, label %bb_rcspinslow1657
bb_rcs1699:
  %v6722 = load i64, ptr %slot1203, align 8
  %op6723 = sub i64 %v6722, 24
  store i64 %op6723, ptr %slot1209, align 8
  %v6724 = load i64, ptr %slot1203, align 8
  %p6725 = inttoptr i64 %v6724 to ptr
  %rgep6726 = getelementptr i8, ptr %p6725, i64 -24
  %ld6727 = load i64, ptr %rgep6726, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6727, ptr %slot1210, align 8
  %v6728 = load i64, ptr %slot1210, align 8
  %cmp6729 = icmp ne i64 %v6728, 18446744073709551615
  %cv6730 = zext i1 %cmp6729 to i32
  store i32 %cv6730, ptr %slot1211, align 8
  %v6731 = load i32, ptr %slot1211, align 8
  %cv6732 = zext i32 %v6731 to i64
  %cond6733 = icmp ne i64 %cv6732, 0
  br i1 %cond6733, label %bb_rcs1703, label %bb_rcspinslow1657
bb_rcs1703:
  br label %bb_rcspincommit1657
bb_rcspincommit1657:
  %v6734 = load i64, ptr %slot1188, align 8
  %p6735 = inttoptr i64 %v6734 to ptr
  %ld6736 = load i64, ptr %p6735, align 8
  store i64 %ld6736, ptr %slot1212, align 8
  %v6737 = load i64, ptr %slot1186, align 8
  %op6738 = add i64 %v6737, 256
  store i64 %op6738, ptr %slot1213, align 8
  %v6739 = load i64, ptr %slot1212, align 8
  %v6740 = load i64, ptr %slot1213, align 8
  %p6741 = inttoptr i64 %v6740 to ptr
  store i64 %v6739, ptr %p6741, align 8, !alias.scope !9999998, !noalias !9999999
  %v6742 = load i64, ptr %slot1186, align 8
  %op6743 = add i64 %v6742, 264
  store i64 %op6743, ptr %slot1214, align 8
  %v6744 = load i64, ptr %slot1214, align 8
  %p6745 = inttoptr i64 %v6744 to ptr
  %ld6746 = load i64, ptr %p6745, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6746, ptr %slot1215, align 8
  %v6747 = load i64, ptr %slot1215, align 8
  %op6748 = add i64 %v6747, 18446744073709551615
  store i64 %op6748, ptr %slot1216, align 8
  %v6749 = load i64, ptr %slot1216, align 8
  %v6750 = load i64, ptr %slot1214, align 8
  %p6751 = inttoptr i64 %v6750 to ptr
  store i64 %v6749, ptr %p6751, align 8, !alias.scope !9999998, !noalias !9999999
  %v6752 = load i64, ptr %slot66, align 8
  %p6754 = inttoptr i64 %v6752 to ptr
  %gep6755 = getelementptr i8, ptr %p6754, i64 24
  %op6753 = ptrtoint ptr %gep6755 to i64
  store i64 %op6753, ptr %slot1217, align 8
  %v6756 = load i64, ptr %slot1217, align 8
  %p6757 = inttoptr i64 %v6756 to ptr
  %ld6758 = load i64, ptr %p6757, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6758, ptr %slot1218, align 8
  %v6759 = load i64, ptr %slot1218, align 8
  %op6760 = add i64 %v6759, 40
  store i64 %op6760, ptr %slot1219, align 8
  %v6761 = load i64, ptr %slot1219, align 8
  %v6762 = load i64, ptr %slot1217, align 8
  %p6763 = inttoptr i64 %v6762 to ptr
  store i64 %v6761, ptr %p6763, align 8, !alias.scope !9999998, !noalias !9999999
  %v6764 = load i64, ptr %slot1186, align 8
  %op6765 = add i64 %v6764, 48
  store i64 %op6765, ptr %slot1220, align 8
  %v6766 = load i64, ptr %slot1220, align 8
  %p6767 = inttoptr i64 %v6766 to ptr
  %ld6768 = load i64, ptr %p6767, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld6768, ptr %slot1221, align 8
  %v6769 = load i64, ptr %slot1221, align 8
  %op6770 = add i64 %v6769, 40
  store i64 %op6770, ptr %slot1222, align 8
  %v6771 = load i64, ptr %slot1222, align 8
  %v6772 = load i64, ptr %slot1220, align 8
  %p6773 = inttoptr i64 %v6772 to ptr
  store i64 %v6771, ptr %p6773, align 8, !alias.scope !9999998, !noalias !9999999
  %v6774 = load i64, ptr %slot1130, align 8
  %op6775 = sub i64 %v6774, 24
  store i64 %op6775, ptr %slot1223, align 8
  %v6776 = load i64, ptr %slot1130, align 8
  %p6777 = inttoptr i64 %v6776 to ptr
  %rgep6778 = getelementptr i8, ptr %p6777, i64 -24
  %ld6779 = load i64, ptr %rgep6778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6779, ptr %slot1224, align 8
  %v6780 = load i64, ptr %slot1224, align 8
  %op6781 = add i64 %v6780, 1
  store i64 %op6781, ptr %slot1225, align 8
  %v6782 = load i64, ptr %slot1225, align 8
  %v6783 = load i64, ptr %slot1130, align 8
  %p6784 = inttoptr i64 %v6783 to ptr
  %rgep6785 = getelementptr i8, ptr %p6784, i64 -24
  store i64 %v6782, ptr %rgep6785, align 8, !alias.scope !9, !noalias !10
  %v6786 = load i64, ptr %slot1203, align 8
  %cmp6787 = icmp ne i64 %v6786, 0
  %cv6788 = zext i1 %cmp6787 to i32
  store i32 %cv6788, ptr %slot1226, align 8
  %v6789 = load i32, ptr %slot1226, align 8
  %cv6790 = zext i32 %v6789 to i64
  %cond6791 = icmp ne i64 %cv6790, 0
  br i1 %cond6791, label %bb_rcspinhold1657, label %bb_rcspinjournal1657
bb_rcspinhold1657:
  %v6792 = load i64, ptr %slot1203, align 8
  %op6793 = sub i64 %v6792, 24
  store i64 %op6793, ptr %slot1227, align 8
  %v6794 = load i64, ptr %slot1203, align 8
  %p6795 = inttoptr i64 %v6794 to ptr
  %rgep6796 = getelementptr i8, ptr %p6795, i64 -24
  %ld6797 = load i64, ptr %rgep6796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6797, ptr %slot1228, align 8
  %v6798 = load i64, ptr %slot1228, align 8
  %op6799 = add i64 %v6798, 1
  store i64 %op6799, ptr %slot1229, align 8
  %v6800 = load i64, ptr %slot1229, align 8
  %v6801 = load i64, ptr %slot1203, align 8
  %p6802 = inttoptr i64 %v6801 to ptr
  %rgep6803 = getelementptr i8, ptr %p6802, i64 -24
  store i64 %v6800, ptr %rgep6803, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal1657
bb_rcspinjournal1657:
  %v6804 = load i64, ptr %slot1176, align 8
  %op6805 = and i64 %v6804, 1152921504606846976
  store i64 %op6805, ptr %slot1230, align 8
  %v6806 = load i64, ptr %slot1176, align 8
  %op6807 = or i64 %v6806, 1152921504606846976
  store i64 %op6807, ptr %slot1231, align 8
  %v6808 = load i64, ptr %slot1130, align 8
  %op6809 = sub i64 %v6808, 16
  store i64 %op6809, ptr %slot1232, align 8
  %v6810 = load i64, ptr %slot1231, align 8
  %v6811 = load i64, ptr %slot1130, align 8
  %p6812 = inttoptr i64 %v6811 to ptr
  %rgep6813 = getelementptr i8, ptr %p6812, i64 -16
  store i64 %v6810, ptr %rgep6813, align 8, !alias.scope !9, !noalias !10
  %v6814 = load i64, ptr %slot1163, align 8
  %p6816 = inttoptr i64 %v6814 to ptr
  %gep6817 = getelementptr i8, ptr %p6816, i64 16
  %op6815 = ptrtoint ptr %gep6817 to i64
  store i64 %op6815, ptr %slot1233, align 8
  %v6818 = load i64, ptr %slot1233, align 8
  %p6819 = inttoptr i64 %v6818 to ptr
  %ld6820 = load i64, ptr %p6819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6820, ptr %slot1234, align 8
  %v6821 = load i64, ptr %slot1188, align 8
  %op6822 = add i64 %v6821, 0
  store i64 %op6822, ptr %slot1235, align 8
  %v6823 = load i64, ptr %slot1234, align 8
  %v6824 = load i64, ptr %slot1235, align 8
  %p6825 = inttoptr i64 %v6824 to ptr
  store i64 %v6823, ptr %p6825, align 8, !alias.scope !9999998, !noalias !9999999
  %v6826 = load i64, ptr %slot1188, align 8
  %op6827 = add i64 %v6826, 8
  store i64 %op6827, ptr %slot1236, align 8
  %v6828 = load i64, ptr %slot1130, align 8
  %v6829 = load i64, ptr %slot1236, align 8
  %p6830 = inttoptr i64 %v6829 to ptr
  store i64 %v6828, ptr %p6830, align 8, !alias.scope !9999998, !noalias !9999999
  %v6831 = load i64, ptr %slot1188, align 8
  %op6832 = add i64 %v6831, 16
  store i64 %op6832, ptr %slot1237, align 8
  %v6833 = load i64, ptr %slot1230, align 8
  %v6834 = load i64, ptr %slot1237, align 8
  %p6835 = inttoptr i64 %v6834 to ptr
  store i64 %v6833, ptr %p6835, align 8, !alias.scope !9999998, !noalias !9999999
  %v6836 = load i64, ptr %slot1188, align 8
  %op6837 = add i64 %v6836, 24
  store i64 %op6837, ptr %slot1238, align 8
  %v6838 = load i64, ptr %slot1238, align 8
  %p6839 = inttoptr i64 %v6838 to ptr
  store i32 1, ptr %p6839, align 4, !alias.scope !9999998, !noalias !9999999
  %v6840 = load i64, ptr %slot1188, align 8
  %op6841 = add i64 %v6840, 32
  store i64 %op6841, ptr %slot1239, align 8
  %v6842 = load i64, ptr %slot1203, align 8
  %v6843 = load i64, ptr %slot1239, align 8
  %p6844 = inttoptr i64 %v6843 to ptr
  store i64 %v6842, ptr %p6844, align 8, !alias.scope !9999998, !noalias !9999999
  %v6845 = load i64, ptr %slot1163, align 8
  %p6847 = inttoptr i64 %v6845 to ptr
  %gep6848 = getelementptr i8, ptr %p6847, i64 16
  %op6846 = ptrtoint ptr %gep6848 to i64
  store i64 %op6846, ptr %slot1240, align 8
  %v6849 = load i64, ptr %slot1188, align 8
  %v6850 = load i64, ptr %slot1240, align 8
  %p6851 = inttoptr i64 %v6850 to ptr
  store i64 %v6849, ptr %p6851, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone1657
bb_rcspinslow1657:
  %v6852 = load i64, ptr %slot1, align 8
  %p6853 = inttoptr i64 %v6852 to ptr
  %v6854 = load i64, ptr %slot1163, align 8
  %p6855 = inttoptr i64 %v6854 to ptr
  %v6856 = load i64, ptr %slot1130, align 8
  %p6857 = inttoptr i64 %v6856 to ptr
  %call6858 = call i32 @myl_qbe_rc_scope_pin(ptr %p6853, ptr %p6855, ptr %p6857) nomerge, !dbg !182
  store i32 %call6858, ptr %slot1241, align 8
  %v6859 = load i32, ptr %slot1241, align 8
  %cv6860 = zext i32 %v6859 to i64
  %cond6861 = icmp ne i64 %cv6860, 0
  br i1 %cond6861, label %bb_rcunique1734, label %bb_failure
bb_rcunique1734:
  br label %bb_rcspindone1657
bb_rcspindone1657:
  %v6862 = load i64, ptr %slot1130, align 8
  %v6863 = load i64, ptr %slot51, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  store i64 %v6862, ptr %p6864, align 8, !alias.scope !3, !noalias !4
  %v6865 = load i64, ptr %slot45, align 8
  %v6866 = load i64, ptr %slot54, align 8
  %p6867 = inttoptr i64 %v6866 to ptr
  store i64 %v6865, ptr %p6867, align 8, !alias.scope !3, !noalias !4
  %v6868 = load i64, ptr %slot54, align 8
  %p6869 = inttoptr i64 %v6868 to ptr
  %ld6870 = load i64, ptr %p6869, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6870, ptr %slot1242, align 8
  %v6871 = load i64, ptr %slot1242, align 8
  %op6872 = add i64 %v6871, 48
  store i64 %op6872, ptr %slot1243, align 8
  %v6873 = load i64, ptr %slot1243, align 8
  %p6874 = inttoptr i64 %v6873 to ptr
  %ld6875 = load i64, ptr %p6874, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6875, ptr %slot1244, align 8
  %v6876 = load i64, ptr %slot1244, align 8
  %v6877 = load i64, ptr %slot54, align 8
  %p6878 = inttoptr i64 %v6877 to ptr
  store i64 %v6876, ptr %p6878, align 8, !alias.scope !3, !noalias !4
  %v6879 = load i64, ptr %slot17, align 8
  %p6880 = inttoptr i64 %v6879 to ptr
  %ld6881 = load i32, ptr %p6880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6881, ptr %slot1245, align 8
  %v6882 = load i32, ptr %slot1245, align 8
  %cv6883 = zext i32 %v6882 to i64
  %cond6884 = icmp ne i64 %cv6883, 0
  br i1 %cond6884, label %bb_rcslotdrop1740, label %bb_rcslotdone1740
bb_rcslotdrop1740:
  %v6885 = load i64, ptr %slot17, align 8
  %p6886 = inttoptr i64 %v6885 to ptr
  store i32 0, ptr %p6886, align 4, !alias.scope !3, !noalias !4
  %v6887 = load i64, ptr %slot26, align 8
  store i64 %v6887, ptr %slot1246, align 8
  %v6888 = load i64, ptr %slot18, align 8
  %p6889 = inttoptr i64 %v6888 to ptr
  %ld6890 = load i32, ptr %p6889, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6890, ptr %slot1247, align 8
  %v6891 = load i32, ptr %slot1247, align 8
  %op6892 = and i32 %v6891, 28
  store i32 %op6892, ptr %slot1248, align 8
  %v6893 = load i32, ptr %slot1248, align 8
  %cv6894 = zext i32 %v6893 to i64
  %cond6895 = icmp ne i64 %cv6894, 0
  br i1 %cond6895, label %bb_rcslotrole1740, label %bb_rcslotowner1740
bb_rcslotrole1740:
  %v6896 = load i64, ptr %slot66, align 8
  store i64 %v6896, ptr %slot1249, align 8
  %v6897 = load i64, ptr %slot1249, align 8
  %v6898 = load i64, ptr %slot1246, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v6897, i64 %v6898) nomerge, !dbg !184
  br label %bb_rcslotdone1740
bb_rcslotowner1740:
  %v6899 = load i64, ptr %slot66, align 8
  store i64 %v6899, ptr %slot1250, align 8
  %v6900 = load i64, ptr %slot1250, align 8
  %v6901 = load i64, ptr %slot1246, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v6900, i64 %v6901) nomerge, !dbg !184
  br label %bb_rcslotdone1740
bb_rcslotdone1740:
  %v6902 = load i64, ptr %slot54, align 8
  %p6903 = inttoptr i64 %v6902 to ptr
  %ld6904 = load i64, ptr %p6903, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6904, ptr %slot1251, align 8
  %v6905 = load i64, ptr %slot1251, align 8
  %v6906 = load i64, ptr %slot53, align 8
  %p6907 = inttoptr i64 %v6906 to ptr
  store i64 %v6905, ptr %p6907, align 8, !alias.scope !3, !noalias !4
  %v6908 = load i64, ptr %slot53, align 8
  %p6909 = inttoptr i64 %v6908 to ptr
  %ld6910 = load i64, ptr %p6909, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6910, ptr %slot1252, align 8
  %v6911 = load i64, ptr %slot1252, align 8
  %v6912 = load i64, ptr %slot54, align 8
  %p6913 = inttoptr i64 %v6912 to ptr
  store i64 %v6911, ptr %p6913, align 8, !alias.scope !3, !noalias !4
  %v6914 = load i64, ptr %slot55, align 8
  %p6915 = inttoptr i64 %v6914 to ptr
  store i64 0, ptr %p6915, align 8, !alias.scope !3, !noalias !4
  %v6916 = load i64, ptr %slot55, align 8
  %p6917 = inttoptr i64 %v6916 to ptr
  %ld6918 = load i64, ptr %p6917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6918, ptr %slot1253, align 8
  %v6919 = load i64, ptr %slot54, align 8
  %p6920 = inttoptr i64 %v6919 to ptr
  %ld6921 = load i64, ptr %p6920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6921, ptr %slot1254, align 8
  %v6922 = load i64, ptr %slot1254, align 8
  %v6923 = load i64, ptr %slot1253, align 8
  %cmp6924 = icmp slt i64 %v6922, %v6923
  %cv6925 = zext i1 %cmp6924 to i64
  store i64 %cv6925, ptr %slot1255, align 8
  %v6926 = load i64, ptr %slot1255, align 8
  %v6927 = load i64, ptr %slot54, align 8
  %p6928 = inttoptr i64 %v6927 to ptr
  store i64 %v6926, ptr %p6928, align 8, !alias.scope !3, !noalias !4
  %v6929 = load i64, ptr %slot54, align 8
  %p6930 = inttoptr i64 %v6929 to ptr
  %ld6931 = load i64, ptr %p6930, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6931, ptr %slot1256, align 8
  %v6932 = load i64, ptr %slot1256, align 8
  %cond6933 = icmp ne i64 %v6932, 0
  br i1 %cond6933, label %bb_next1753, label %bb_i92
bb_next1753:
  %v6934 = load i64, ptr %slot51, align 8
  %p6935 = inttoptr i64 %v6934 to ptr
  %ld6936 = load i64, ptr %p6935, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6936, ptr %slot1257, align 8
  %v6937 = load i64, ptr %slot1257, align 8
  %op6938 = add i64 %v6937, 0
  store i64 %op6938, ptr %slot1258, align 8
  %v6939 = load i64, ptr %slot1258, align 8
  %p6940 = inttoptr i64 %v6939 to ptr
  %ld6941 = load i64, ptr %p6940, align 8, !alias.scope !6, !noalias !7
  store i64 %ld6941, ptr %slot1259, align 8
  %v6942 = load i64, ptr %slot1259, align 8
  %v6943 = load i64, ptr %slot54, align 8
  %p6944 = inttoptr i64 %v6943 to ptr
  store i64 %v6942, ptr %p6944, align 8, !alias.scope !3, !noalias !4
  %v6945 = load i64, ptr %slot54, align 8
  %p6946 = inttoptr i64 %v6945 to ptr
  %ld6947 = load i64, ptr %p6946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6947, ptr %slot1260, align 8
  %v6948 = load i64, ptr %slot1260, align 8
  %cmp6949 = icmp ugt i64 %v6948, 9223372036854775807
  %cv6950 = zext i1 %cmp6949 to i64
  store i64 %cv6950, ptr %slot1261, align 8
  %v6951 = load i64, ptr %slot1261, align 8
  %cond6952 = icmp ne i64 %v6951, 0
  br i1 %cond6952, label %bb_cast_overflow1758, label %bb_cast_ok1758
bb_cast_overflow1758:
  %v6953 = load i64, ptr %slot1, align 8
  %p6954 = inttoptr i64 %v6953 to ptr
  %v6955 = load i64, ptr %slot1260, align 8
  call void @myl_qbe_fail_cast(ptr %p6954, i64 %v6955, i64 320) nomerge, !dbg !186
  unreachable
bb_cast_ok1758:
  %v6956 = load i64, ptr %slot1260, align 8
  %v6957 = load i64, ptr %slot54, align 8
  %p6958 = inttoptr i64 %v6957 to ptr
  store i64 %v6956, ptr %p6958, align 8, !alias.scope !3, !noalias !4
  %v6959 = load i64, ptr %slot53, align 8
  %p6960 = inttoptr i64 %v6959 to ptr
  %ld6961 = load i64, ptr %p6960, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6961, ptr %slot1262, align 8
  %v6962 = load i64, ptr %slot1262, align 8
  %v6963 = load i64, ptr %slot55, align 8
  %p6964 = inttoptr i64 %v6963 to ptr
  store i64 %v6962, ptr %p6964, align 8, !alias.scope !3, !noalias !4
  %v6965 = load i64, ptr %slot55, align 8
  %p6966 = inttoptr i64 %v6965 to ptr
  %ld6967 = load i64, ptr %p6966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6967, ptr %slot1263, align 8
  %v6968 = load i64, ptr %slot54, align 8
  %p6969 = inttoptr i64 %v6968 to ptr
  %ld6970 = load i64, ptr %p6969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6970, ptr %slot1264, align 8
  %v6971 = load i64, ptr %slot1264, align 8
  %v6972 = load i64, ptr %slot1263, align 8
  %ovpair6974 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v6971, i64 %v6972)
  %op6973 = extractvalue { i64, i1 } %ovpair6974, 0
  %ov6975 = extractvalue { i64, i1 } %ovpair6974, 1
  store i64 %op6973, ptr %slot1265, align 8
  %v6976 = load i64, ptr %slot1264, align 8
  %v6977 = load i64, ptr %slot1265, align 8
  %op6978 = xor i64 %v6976, %v6977
  store i64 %op6978, ptr %slot1266, align 8
  %v6979 = load i64, ptr %slot1263, align 8
  %v6980 = load i64, ptr %slot1265, align 8
  %op6981 = xor i64 %v6979, %v6980
  store i64 %op6981, ptr %slot1267, align 8
  %v6982 = load i64, ptr %slot1266, align 8
  %v6983 = load i64, ptr %slot1267, align 8
  %op6984 = and i64 %v6982, %v6983
  store i64 %op6984, ptr %slot1268, align 8
  %cv6985 = zext i1 %ov6975 to i64
  store i64 %cv6985, ptr %slot1269, align 8
  %v6986 = load i64, ptr %slot1269, align 8
  %cond6987 = icmp ne i64 %v6986, 0
  br i1 %cond6987, label %bb_overflow1762, label %bb_checked1762
bb_overflow1762:
  %v6988 = load i64, ptr %slot1, align 8
  %p6989 = inttoptr i64 %v6988 to ptr
  %v6990 = load i64, ptr %slot1264, align 8
  %v6991 = load i64, ptr %slot1263, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p6989, i64 0, i64 %v6990, i64 %v6991, i64 64) nomerge, !dbg !188
  unreachable
bb_checked1762:
  %v6992 = load i64, ptr %slot1265, align 8
  %v6993 = load i64, ptr %slot54, align 8
  %p6994 = inttoptr i64 %v6993 to ptr
  store i64 %v6992, ptr %p6994, align 8, !alias.scope !3, !noalias !4
  %v6995 = load i64, ptr %slot54, align 8
  %p6996 = inttoptr i64 %v6995 to ptr
  %ld6997 = load i64, ptr %p6996, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6997, ptr %slot1270, align 8
  %v6998 = load i64, ptr %slot1270, align 8
  %v6999 = load i64, ptr %slot53, align 8
  %p7000 = inttoptr i64 %v6999 to ptr
  store i64 %v6998, ptr %p7000, align 8, !alias.scope !3, !noalias !4
  br label %bb_i92
bb_i92:
  %v7001 = load i64, ptr %slot53, align 8
  %p7002 = inttoptr i64 %v7001 to ptr
  %ld7003 = load i64, ptr %p7002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7003, ptr %slot1271, align 8
  %v7004 = load i64, ptr %slot1271, align 8
  %v7005 = load i64, ptr %slot54, align 8
  %p7006 = inttoptr i64 %v7005 to ptr
  store i64 %v7004, ptr %p7006, align 8, !alias.scope !3, !noalias !4
  %v7007 = load i64, ptr %slot52, align 8
  %v7008 = load i64, ptr %slot60, align 8
  %p7009 = inttoptr i64 %v7007 to ptr
  %p7010 = inttoptr i64 %v7008 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7010, ptr %p7009, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v7011 = load i64, ptr %slot60, align 8
  %v7012 = load i64, ptr %slot55, align 8
  %p7013 = inttoptr i64 %v7012 to ptr
  store i64 %v7011, ptr %p7013, align 8, !alias.scope !3, !noalias !4
  %v7014 = load i64, ptr %slot51, align 8
  %p7015 = inttoptr i64 %v7014 to ptr
  %ld7016 = load i64, ptr %p7015, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7016, ptr %slot1272, align 8
  %v7017 = load i64, ptr %slot55, align 8
  %p7018 = inttoptr i64 %v7017 to ptr
  %ld7019 = load i64, ptr %p7018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7019, ptr %slot1273, align 8
  %v7020 = load i64, ptr %slot54, align 8
  %p7021 = inttoptr i64 %v7020 to ptr
  %ld7022 = load i64, ptr %p7021, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7022, ptr %slot1274, align 8
  %v7023 = load i64, ptr %slot1272, align 8
  %p7024 = inttoptr i64 %v7023 to ptr
  %ld7025 = load i64, ptr %p7024, align 8, !alias.scope !6, !noalias !7
  store i64 %ld7025, ptr %slot1275, align 8
  %v7026 = load i64, ptr %slot1274, align 8
  %v7027 = load i64, ptr %slot1275, align 8
  %cmp7028 = icmp ult i64 %v7026, %v7027
  %cv7029 = zext i1 %cmp7028 to i64
  store i64 %cv7029, ptr %slot1276, align 8
  %v7030 = load i64, ptr %slot1276, align 8
  %cond7031 = icmp ne i64 %v7030, 0
  br i1 %cond7031, label %bb_success1775, label %bb_failed1775
bb_failed1775:
  %v7032 = load i64, ptr %slot1, align 8
  %p7033 = inttoptr i64 %v7032 to ptr
  %v7034 = load i64, ptr %slot1274, align 8
  %v7035 = load i64, ptr %slot1275, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p7033, i64 %v7034, i64 %v7035) nomerge, !dbg !190
  unreachable
bb_success1775:
  %v7036 = load i64, ptr %slot55, align 8
  %p7037 = inttoptr i64 %v7036 to ptr
  %ld7038 = load i64, ptr %p7037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7038, ptr %slot1277, align 8
  %v7039 = load i64, ptr %slot66, align 8
  %v7040 = load i64, ptr %slot1272, align 8
  %v7041 = load i64, ptr %slot1274, align 8
  %v7042 = load i64, ptr %slot1277, align 8
  %call7043 = call i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64 %v7039, i64 %v7040, i64 %v7041, i64 %v7042) nomerge, !dbg !190
  store i32 %call7043, ptr %slot1278, align 8
  %v7044 = load i32, ptr %slot1278, align 8
  %cv7045 = zext i32 %v7044 to i64
  %cond7046 = icmp ne i64 %cv7045, 0
  br i1 %cond7046, label %bb_success1778, label %bb_failed1778
bb_failed1778:
  %v7047 = load i64, ptr %slot1, align 8
  %p7048 = inttoptr i64 %v7047 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7048) nomerge, !dbg !190
  unreachable
bb_success1778:
  %v7049 = load i64, ptr %slot54, align 8
  %p7050 = inttoptr i64 %v7049 to ptr
  store i64 0, ptr %p7050, align 8, !alias.scope !3, !noalias !4
  %v7051 = load i64, ptr %slot19, align 8
  %p7052 = inttoptr i64 %v7051 to ptr
  %ld7053 = load i32, ptr %p7052, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7053, ptr %slot1279, align 8
  %v7054 = load i32, ptr %slot1279, align 8
  %cv7055 = zext i32 %v7054 to i64
  %cond7056 = icmp ne i64 %cv7055, 0
  br i1 %cond7056, label %bb_rcslotdrop1781, label %bb_rcslotdone1781
bb_rcslotdrop1781:
  %v7057 = load i64, ptr %slot19, align 8
  %p7058 = inttoptr i64 %v7057 to ptr
  store i32 0, ptr %p7058, align 4, !alias.scope !3, !noalias !4
  %v7059 = load i64, ptr %slot27, align 8
  store i64 %v7059, ptr %slot1280, align 8
  %v7060 = load i64, ptr %slot20, align 8
  %p7061 = inttoptr i64 %v7060 to ptr
  %ld7062 = load i32, ptr %p7061, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7062, ptr %slot1281, align 8
  %v7063 = load i32, ptr %slot1281, align 8
  %op7064 = and i32 %v7063, 28
  store i32 %op7064, ptr %slot1282, align 8
  %v7065 = load i32, ptr %slot1282, align 8
  %cv7066 = zext i32 %v7065 to i64
  %cond7067 = icmp ne i64 %cv7066, 0
  br i1 %cond7067, label %bb_rcslotrole1781, label %bb_rcslotowner1781
bb_rcslotrole1781:
  %v7068 = load i64, ptr %slot66, align 8
  store i64 %v7068, ptr %slot1283, align 8
  %v7069 = load i64, ptr %slot1283, align 8
  %v7070 = load i64, ptr %slot1280, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7069, i64 %v7070) nomerge, !dbg !190
  br label %bb_rcslotdone1781
bb_rcslotowner1781:
  %v7071 = load i64, ptr %slot66, align 8
  store i64 %v7071, ptr %slot1284, align 8
  %v7072 = load i64, ptr %slot1284, align 8
  %v7073 = load i64, ptr %slot1280, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7072, i64 %v7073) nomerge, !dbg !190
  br label %bb_rcslotdone1781
bb_rcslotdone1781:
  %v7074 = load i64, ptr %slot34, align 8
  store i64 %v7074, ptr %slot1285, align 8
  %v7075 = load i64, ptr %slot1285, align 8
  %p7077 = inttoptr i64 %v7075 to ptr
  %gep7078 = getelementptr i8, ptr %p7077, i64 24
  %op7076 = ptrtoint ptr %gep7078 to i64
  store i64 %op7076, ptr %slot1286, align 8
  %v7079 = load i64, ptr %slot1286, align 8
  %p7080 = inttoptr i64 %v7079 to ptr
  %ld7081 = load i32, ptr %p7080, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7081, ptr %slot1287, align 8
  %v7082 = load i32, ptr %slot1287, align 8
  %cv7083 = zext i32 %v7082 to i64
  %cond7084 = icmp ne i64 %cv7083, 0
  br i1 %cond7084, label %bb_rcsendactive1789, label %bb_rcsenddone1789
bb_rcsendactive1789:
  %v7085 = load i64, ptr %slot66, align 8
  %p7087 = inttoptr i64 %v7085 to ptr
  %gep7088 = getelementptr i8, ptr %p7087, i64 5640
  %op7086 = ptrtoint ptr %gep7088 to i64
  store i64 %op7086, ptr %slot1288, align 8
  %v7089 = load i64, ptr %slot1288, align 8
  %p7090 = inttoptr i64 %v7089 to ptr
  %ld7091 = load i64, ptr %p7090, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7091, ptr %slot1289, align 8
  %v7092 = load i64, ptr %slot1289, align 8
  %op7093 = add i64 %v7092, 248
  store i64 %op7093, ptr %slot1290, align 8
  %v7094 = load i64, ptr %slot1290, align 8
  %p7095 = inttoptr i64 %v7094 to ptr
  %ld7096 = load i64, ptr %p7095, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7096, ptr %slot1291, align 8
  %v7097 = load i64, ptr %slot1291, align 8
  %v7098 = load i64, ptr %slot1285, align 8
  %cmp7099 = icmp eq i64 %v7097, %v7098
  %cv7100 = zext i1 %cmp7099 to i32
  store i32 %cv7100, ptr %slot1292, align 8
  %v7101 = load i32, ptr %slot1292, align 8
  %cv7102 = zext i32 %v7101 to i64
  %cond7103 = icmp ne i64 %cv7102, 0
  br i1 %cond7103, label %bb_rcs1797, label %bb_rcsendslow1789
bb_rcs1797:
  %v7104 = load i64, ptr %slot1289, align 8
  %op7105 = add i64 %v7104, 200
  store i64 %op7105, ptr %slot1293, align 8
  %v7106 = load i64, ptr %slot1293, align 8
  %p7107 = inttoptr i64 %v7106 to ptr
  %ld7108 = load i64, ptr %p7107, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7108, ptr %slot1294, align 8
  %v7109 = load i64, ptr %slot1294, align 8
  %cmp7110 = icmp eq i64 %v7109, 0
  %cv7111 = zext i1 %cmp7110 to i32
  store i32 %cv7111, ptr %slot1295, align 8
  %v7112 = load i32, ptr %slot1295, align 8
  %cv7113 = zext i32 %v7112 to i64
  %cond7114 = icmp ne i64 %cv7113, 0
  br i1 %cond7114, label %bb_rcs1801, label %bb_rcsendslow1789
bb_rcs1801:
  %v7115 = load i64, ptr %slot1285, align 8
  %p7117 = inttoptr i64 %v7115 to ptr
  %gep7118 = getelementptr i8, ptr %p7117, i64 16
  %op7116 = ptrtoint ptr %gep7118 to i64
  store i64 %op7116, ptr %slot1296, align 8
  %v7119 = load i64, ptr %slot1296, align 8
  %p7120 = inttoptr i64 %v7119 to ptr
  %ld7121 = load i64, ptr %p7120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7121, ptr %slot1297, align 8
  %v7122 = load i64, ptr %slot1297, align 8
  %cmp7123 = icmp ne i64 %v7122, 0
  %cv7124 = zext i1 %cmp7123 to i32
  store i32 %cv7124, ptr %slot1298, align 8
  %v7125 = load i32, ptr %slot1298, align 8
  %cv7126 = zext i32 %v7125 to i64
  %cond7127 = icmp ne i64 %cv7126, 0
  br i1 %cond7127, label %bb_rcsendnode1789, label %bb_rcsendunlink1789
bb_rcsendnode1789:
  %v7128 = load i64, ptr %slot1297, align 8
  %op7129 = add i64 %v7128, 0
  store i64 %op7129, ptr %slot1299, align 8
  %v7130 = load i64, ptr %slot1299, align 8
  %p7131 = inttoptr i64 %v7130 to ptr
  %ld7132 = load i64, ptr %p7131, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7132, ptr %slot1300, align 8
  %v7133 = load i64, ptr %slot1300, align 8
  %cmp7134 = icmp eq i64 %v7133, 0
  %cv7135 = zext i1 %cmp7134 to i32
  store i32 %cv7135, ptr %slot1301, align 8
  %v7136 = load i32, ptr %slot1301, align 8
  %cv7137 = zext i32 %v7136 to i64
  %cond7138 = icmp ne i64 %cv7137, 0
  br i1 %cond7138, label %bb_rcs1808, label %bb_rcsendslow1789
bb_rcs1808:
  %v7139 = load i64, ptr %slot1289, align 8
  %op7140 = add i64 %v7139, 264
  store i64 %op7140, ptr %slot1302, align 8
  %v7141 = load i64, ptr %slot1302, align 8
  %p7142 = inttoptr i64 %v7141 to ptr
  %ld7143 = load i64, ptr %p7142, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7143, ptr %slot1303, align 8
  %v7144 = load i64, ptr %slot1303, align 8
  %cmp7145 = icmp ult i64 %v7144, 32
  %cv7146 = zext i1 %cmp7145 to i32
  store i32 %cv7146, ptr %slot1304, align 8
  %v7147 = load i32, ptr %slot1304, align 8
  %cv7148 = zext i32 %v7147 to i64
  %cond7149 = icmp ne i64 %cv7148, 0
  br i1 %cond7149, label %bb_rcs1812, label %bb_rcsendslow1789
bb_rcs1812:
  %v7150 = load i64, ptr %slot1297, align 8
  %op7151 = add i64 %v7150, 8
  store i64 %op7151, ptr %slot1305, align 8
  %v7152 = load i64, ptr %slot1305, align 8
  %p7153 = inttoptr i64 %v7152 to ptr
  %ld7154 = load i64, ptr %p7153, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7154, ptr %slot1306, align 8
  %v7155 = load i64, ptr %slot1306, align 8
  %cmp7156 = icmp ne i64 %v7155, 0
  %cv7157 = zext i1 %cmp7156 to i32
  store i32 %cv7157, ptr %slot1307, align 8
  %v7158 = load i32, ptr %slot1307, align 8
  %cv7159 = zext i32 %v7158 to i64
  %cond7160 = icmp ne i64 %cv7159, 0
  br i1 %cond7160, label %bb_rcs1816, label %bb_rcsendslow1789
bb_rcs1816:
  %v7161 = load i64, ptr %slot1306, align 8
  %op7162 = sub i64 %v7161, 16
  store i64 %op7162, ptr %slot1308, align 8
  %v7163 = load i64, ptr %slot1306, align 8
  %p7164 = inttoptr i64 %v7163 to ptr
  %rgep7165 = getelementptr i8, ptr %p7164, i64 -16
  %ld7166 = load i64, ptr %rgep7165, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7166, ptr %slot1309, align 8
  %v7167 = load i64, ptr %slot1309, align 8
  %op7168 = and i64 %v7167, 4611686018427387907
  store i64 %op7168, ptr %slot1310, align 8
  %v7169 = load i64, ptr %slot1310, align 8
  %cmp7170 = icmp eq i64 %v7169, 0
  %cv7171 = zext i1 %cmp7170 to i32
  store i32 %cv7171, ptr %slot1311, align 8
  %v7172 = load i32, ptr %slot1311, align 8
  %cv7173 = zext i32 %v7172 to i64
  %cond7174 = icmp ne i64 %cv7173, 0
  br i1 %cond7174, label %bb_rcs1821, label %bb_rcsendslow1789
bb_rcs1821:
  %v7175 = load i64, ptr %slot1306, align 8
  %op7176 = sub i64 %v7175, 24
  store i64 %op7176, ptr %slot1312, align 8
  %v7177 = load i64, ptr %slot1306, align 8
  %p7178 = inttoptr i64 %v7177 to ptr
  %rgep7179 = getelementptr i8, ptr %p7178, i64 -24
  %ld7180 = load i64, ptr %rgep7179, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7180, ptr %slot1313, align 8
  %v7181 = load i64, ptr %slot1313, align 8
  %cmp7182 = icmp ne i64 %v7181, 0
  %cv7183 = zext i1 %cmp7182 to i32
  store i32 %cv7183, ptr %slot1314, align 8
  %v7184 = load i32, ptr %slot1314, align 8
  %cv7185 = zext i32 %v7184 to i64
  %cond7186 = icmp ne i64 %cv7185, 0
  br i1 %cond7186, label %bb_rcs1825, label %bb_rcsendslow1789
bb_rcs1825:
  %v7187 = load i64, ptr %slot1306, align 8
  %op7188 = sub i64 %v7187, 32
  store i64 %op7188, ptr %slot1315, align 8
  %v7189 = load i64, ptr %slot1306, align 8
  %p7190 = inttoptr i64 %v7189 to ptr
  %rgep7191 = getelementptr i8, ptr %p7190, i64 -32
  %ld7192 = load i64, ptr %rgep7191, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7192, ptr %slot1316, align 8
  %v7193 = load i64, ptr %slot1313, align 8
  %cmp7194 = icmp ugt i64 %v7193, 1
  %cv7195 = zext i1 %cmp7194 to i32
  store i32 %cv7195, ptr %slot1317, align 8
  %v7196 = load i64, ptr %slot1316, align 8
  %cmp7197 = icmp ne i64 %v7196, 0
  %cv7198 = zext i1 %cmp7197 to i32
  store i32 %cv7198, ptr %slot1318, align 8
  %v7199 = load i32, ptr %slot1317, align 8
  %v7200 = load i32, ptr %slot1318, align 8
  %op7201 = or i32 %v7199, %v7200
  store i32 %op7201, ptr %slot1319, align 8
  %v7202 = load i32, ptr %slot1319, align 8
  %cv7203 = zext i32 %v7202 to i64
  %cond7204 = icmp ne i64 %cv7203, 0
  br i1 %cond7204, label %bb_rcs1831, label %bb_rcsendslow1789
bb_rcs1831:
  %v7205 = load i64, ptr %slot1297, align 8
  %op7206 = add i64 %v7205, 32
  store i64 %op7206, ptr %slot1320, align 8
  %v7207 = load i64, ptr %slot1320, align 8
  %p7208 = inttoptr i64 %v7207 to ptr
  %ld7209 = load i64, ptr %p7208, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7209, ptr %slot1321, align 8
  %v7210 = load i64, ptr %slot1321, align 8
  %cmp7211 = icmp ne i64 %v7210, 0
  %cv7212 = zext i1 %cmp7211 to i32
  store i32 %cv7212, ptr %slot1322, align 8
  %v7213 = load i32, ptr %slot1322, align 8
  %cv7214 = zext i32 %v7213 to i64
  %cond7215 = icmp ne i64 %cv7214, 0
  br i1 %cond7215, label %bb_rcsendbacking1789, label %bb_rcsendcommit1789
bb_rcsendbacking1789:
  %v7216 = load i64, ptr %slot1321, align 8
  %op7217 = sub i64 %v7216, 16
  store i64 %op7217, ptr %slot1323, align 8
  %v7218 = load i64, ptr %slot1321, align 8
  %p7219 = inttoptr i64 %v7218 to ptr
  %rgep7220 = getelementptr i8, ptr %p7219, i64 -16
  %ld7221 = load i64, ptr %rgep7220, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7221, ptr %slot1324, align 8
  %v7222 = load i64, ptr %slot1324, align 8
  %op7223 = and i64 %v7222, 4611686018427387907
  store i64 %op7223, ptr %slot1325, align 8
  %v7224 = load i64, ptr %slot1325, align 8
  %cmp7225 = icmp eq i64 %v7224, 0
  %cv7226 = zext i1 %cmp7225 to i32
  store i32 %cv7226, ptr %slot1326, align 8
  %v7227 = load i32, ptr %slot1326, align 8
  %cv7228 = zext i32 %v7227 to i64
  %cond7229 = icmp ne i64 %cv7228, 0
  br i1 %cond7229, label %bb_rcs1839, label %bb_rcsendslow1789
bb_rcs1839:
  %v7230 = load i64, ptr %slot1321, align 8
  %op7231 = sub i64 %v7230, 24
  store i64 %op7231, ptr %slot1327, align 8
  %v7232 = load i64, ptr %slot1321, align 8
  %p7233 = inttoptr i64 %v7232 to ptr
  %rgep7234 = getelementptr i8, ptr %p7233, i64 -24
  %ld7235 = load i64, ptr %rgep7234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7235, ptr %slot1328, align 8
  %v7236 = load i64, ptr %slot1328, align 8
  %cmp7237 = icmp ne i64 %v7236, 0
  %cv7238 = zext i1 %cmp7237 to i32
  store i32 %cv7238, ptr %slot1329, align 8
  %v7239 = load i32, ptr %slot1329, align 8
  %cv7240 = zext i32 %v7239 to i64
  %cond7241 = icmp ne i64 %cv7240, 0
  br i1 %cond7241, label %bb_rcs1843, label %bb_rcsendslow1789
bb_rcs1843:
  %v7242 = load i64, ptr %slot1321, align 8
  %op7243 = sub i64 %v7242, 32
  store i64 %op7243, ptr %slot1330, align 8
  %v7244 = load i64, ptr %slot1321, align 8
  %p7245 = inttoptr i64 %v7244 to ptr
  %rgep7246 = getelementptr i8, ptr %p7245, i64 -32
  %ld7247 = load i64, ptr %rgep7246, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7247, ptr %slot1331, align 8
  %v7248 = load i64, ptr %slot1328, align 8
  %cmp7249 = icmp ugt i64 %v7248, 1
  %cv7250 = zext i1 %cmp7249 to i32
  store i32 %cv7250, ptr %slot1332, align 8
  %v7251 = load i64, ptr %slot1331, align 8
  %cmp7252 = icmp ne i64 %v7251, 0
  %cv7253 = zext i1 %cmp7252 to i32
  store i32 %cv7253, ptr %slot1333, align 8
  %v7254 = load i32, ptr %slot1332, align 8
  %v7255 = load i32, ptr %slot1333, align 8
  %op7256 = or i32 %v7254, %v7255
  store i32 %op7256, ptr %slot1334, align 8
  %v7257 = load i32, ptr %slot1334, align 8
  %cv7258 = zext i32 %v7257 to i64
  %cond7259 = icmp ne i64 %cv7258, 0
  br i1 %cond7259, label %bb_rcs1849, label %bb_rcsendslow1789
bb_rcs1849:
  br label %bb_rcsendcommit1789
bb_rcsendcommit1789:
  %v7260 = load i64, ptr %slot1297, align 8
  %op7261 = add i64 %v7260, 24
  store i64 %op7261, ptr %slot1335, align 8
  %v7262 = load i64, ptr %slot1335, align 8
  %p7263 = inttoptr i64 %v7262 to ptr
  %ld7264 = load i32, ptr %p7263, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld7264, ptr %slot1336, align 8
  %v7265 = load i32, ptr %slot1336, align 8
  %cv7266 = zext i32 %v7265 to i64
  %cond7267 = icmp ne i64 %cv7266, 0
  br i1 %cond7267, label %bb_rcsendrestore1789, label %bb_rcsendreturned1789
bb_rcsendrestore1789:
  %v7268 = load i64, ptr %slot1297, align 8
  %op7269 = add i64 %v7268, 16
  store i64 %op7269, ptr %slot1337, align 8
  %v7270 = load i64, ptr %slot1337, align 8
  %p7271 = inttoptr i64 %v7270 to ptr
  %ld7272 = load i64, ptr %p7271, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7272, ptr %slot1338, align 8
  %v7273 = load i64, ptr %slot1309, align 8
  %op7274 = and i64 %v7273, 17293822569102704639
  store i64 %op7274, ptr %slot1339, align 8
  %v7275 = load i64, ptr %slot1339, align 8
  %v7276 = load i64, ptr %slot1338, align 8
  %op7277 = or i64 %v7275, %v7276
  store i64 %op7277, ptr %slot1340, align 8
  %v7278 = load i64, ptr %slot1306, align 8
  %op7279 = sub i64 %v7278, 16
  store i64 %op7279, ptr %slot1341, align 8
  %v7280 = load i64, ptr %slot1340, align 8
  %v7281 = load i64, ptr %slot1306, align 8
  %p7282 = inttoptr i64 %v7281 to ptr
  %rgep7283 = getelementptr i8, ptr %p7282, i64 -16
  store i64 %v7280, ptr %rgep7283, align 8, !alias.scope !9, !noalias !10
  %v7284 = load i64, ptr %slot1285, align 8
  %p7286 = inttoptr i64 %v7284 to ptr
  %gep7287 = getelementptr i8, ptr %p7286, i64 16
  %op7285 = ptrtoint ptr %gep7287 to i64
  store i64 %op7285, ptr %slot1342, align 8
  br label %bb_rcsendreturned1789
bb_rcsendreturned1789:
  %v7288 = load i64, ptr %slot1342, align 8
  %p7289 = inttoptr i64 %v7288 to ptr
  store i64 0, ptr %p7289, align 8, !alias.scope !3, !noalias !4
  %v7290 = load i64, ptr %slot1289, align 8
  %op7291 = add i64 %v7290, 256
  store i64 %op7291, ptr %slot1343, align 8
  %v7292 = load i64, ptr %slot1343, align 8
  %p7293 = inttoptr i64 %v7292 to ptr
  %ld7294 = load i64, ptr %p7293, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7294, ptr %slot1344, align 8
  %v7295 = load i64, ptr %slot1297, align 8
  %op7296 = add i64 %v7295, 0
  store i64 %op7296, ptr %slot1345, align 8
  %v7297 = load i64, ptr %slot1344, align 8
  %v7298 = load i64, ptr %slot1345, align 8
  %p7299 = inttoptr i64 %v7298 to ptr
  store i64 %v7297, ptr %p7299, align 8, !alias.scope !9999998, !noalias !9999999
  %v7300 = load i64, ptr %slot1289, align 8
  %op7301 = add i64 %v7300, 256
  store i64 %op7301, ptr %slot1346, align 8
  %v7302 = load i64, ptr %slot1297, align 8
  %v7303 = load i64, ptr %slot1346, align 8
  %p7304 = inttoptr i64 %v7303 to ptr
  store i64 %v7302, ptr %p7304, align 8, !alias.scope !9999998, !noalias !9999999
  %v7305 = load i64, ptr %slot1289, align 8
  %op7306 = add i64 %v7305, 264
  store i64 %op7306, ptr %slot1347, align 8
  %v7307 = load i64, ptr %slot1347, align 8
  %p7308 = inttoptr i64 %v7307 to ptr
  %ld7309 = load i64, ptr %p7308, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7309, ptr %slot1348, align 8
  %v7310 = load i64, ptr %slot1348, align 8
  %op7311 = add i64 %v7310, 1
  store i64 %op7311, ptr %slot1349, align 8
  %v7312 = load i64, ptr %slot1349, align 8
  %v7313 = load i64, ptr %slot1347, align 8
  %p7314 = inttoptr i64 %v7313 to ptr
  store i64 %v7312, ptr %p7314, align 8, !alias.scope !9999998, !noalias !9999999
  %v7315 = load i64, ptr %slot66, align 8
  %p7317 = inttoptr i64 %v7315 to ptr
  %gep7318 = getelementptr i8, ptr %p7317, i64 24
  %op7316 = ptrtoint ptr %gep7318 to i64
  store i64 %op7316, ptr %slot1350, align 8
  %v7319 = load i64, ptr %slot1350, align 8
  %p7320 = inttoptr i64 %v7319 to ptr
  %ld7321 = load i64, ptr %p7320, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7321, ptr %slot1351, align 8
  %v7322 = load i64, ptr %slot1351, align 8
  %op7323 = add i64 %v7322, 18446744073709551576
  store i64 %op7323, ptr %slot1352, align 8
  %v7324 = load i64, ptr %slot1352, align 8
  %v7325 = load i64, ptr %slot1350, align 8
  %p7326 = inttoptr i64 %v7325 to ptr
  store i64 %v7324, ptr %p7326, align 8, !alias.scope !9999998, !noalias !9999999
  %v7327 = load i64, ptr %slot1289, align 8
  %op7328 = add i64 %v7327, 48
  store i64 %op7328, ptr %slot1353, align 8
  %v7329 = load i64, ptr %slot1353, align 8
  %p7330 = inttoptr i64 %v7329 to ptr
  %ld7331 = load i64, ptr %p7330, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld7331, ptr %slot1354, align 8
  %v7332 = load i64, ptr %slot1354, align 8
  %op7333 = add i64 %v7332, 18446744073709551576
  store i64 %op7333, ptr %slot1355, align 8
  %v7334 = load i64, ptr %slot1355, align 8
  %v7335 = load i64, ptr %slot1353, align 8
  %p7336 = inttoptr i64 %v7335 to ptr
  store i64 %v7334, ptr %p7336, align 8, !alias.scope !9999998, !noalias !9999999
  %v7337 = load i64, ptr %slot1321, align 8
  %cmp7338 = icmp ne i64 %v7337, 0
  %cv7339 = zext i1 %cmp7338 to i32
  store i32 %cv7339, ptr %slot1356, align 8
  %v7340 = load i32, ptr %slot1356, align 8
  %cv7341 = zext i32 %v7340 to i64
  %cond7342 = icmp ne i64 %cv7341, 0
  br i1 %cond7342, label %bb_rcsenddropbacking1789, label %bb_rcsenddroppayload1789
bb_rcsenddropbacking1789:
  %v7343 = load i64, ptr %slot1321, align 8
  %op7344 = sub i64 %v7343, 24
  store i64 %op7344, ptr %slot1357, align 8
  %v7345 = load i64, ptr %slot1321, align 8
  %p7346 = inttoptr i64 %v7345 to ptr
  %rgep7347 = getelementptr i8, ptr %p7346, i64 -24
  %ld7348 = load i64, ptr %rgep7347, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7348, ptr %slot1358, align 8
  %v7349 = load i64, ptr %slot1358, align 8
  %op7350 = add i64 %v7349, 18446744073709551615
  store i64 %op7350, ptr %slot1359, align 8
  %v7351 = load i64, ptr %slot1359, align 8
  %v7352 = load i64, ptr %slot1321, align 8
  %p7353 = inttoptr i64 %v7352 to ptr
  %rgep7354 = getelementptr i8, ptr %p7353, i64 -24
  store i64 %v7351, ptr %rgep7354, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload1789
bb_rcsenddroppayload1789:
  %v7355 = load i64, ptr %slot1306, align 8
  %op7356 = sub i64 %v7355, 24
  store i64 %op7356, ptr %slot1360, align 8
  %v7357 = load i64, ptr %slot1306, align 8
  %p7358 = inttoptr i64 %v7357 to ptr
  %rgep7359 = getelementptr i8, ptr %p7358, i64 -24
  %ld7360 = load i64, ptr %rgep7359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7360, ptr %slot1361, align 8
  %v7361 = load i64, ptr %slot1361, align 8
  %op7362 = add i64 %v7361, 18446744073709551615
  store i64 %op7362, ptr %slot1362, align 8
  %v7363 = load i64, ptr %slot1362, align 8
  %v7364 = load i64, ptr %slot1306, align 8
  %p7365 = inttoptr i64 %v7364 to ptr
  %rgep7366 = getelementptr i8, ptr %p7365, i64 -24
  store i64 %v7363, ptr %rgep7366, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink1789
bb_rcsendunlink1789:
  %v7367 = load i64, ptr %slot1285, align 8
  %p7369 = inttoptr i64 %v7367 to ptr
  %gep7370 = getelementptr i8, ptr %p7369, i64 8
  %op7368 = ptrtoint ptr %gep7370 to i64
  store i64 %op7368, ptr %slot1363, align 8
  %v7371 = load i64, ptr %slot1363, align 8
  %p7372 = inttoptr i64 %v7371 to ptr
  %ld7373 = load i64, ptr %p7372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7373, ptr %slot1364, align 8
  %v7374 = load i64, ptr %slot1289, align 8
  %op7375 = add i64 %v7374, 248
  store i64 %op7375, ptr %slot1365, align 8
  %v7376 = load i64, ptr %slot1364, align 8
  %v7377 = load i64, ptr %slot1365, align 8
  %p7378 = inttoptr i64 %v7377 to ptr
  store i64 %v7376, ptr %p7378, align 8, !alias.scope !9999998, !noalias !9999999
  %v7379 = load i64, ptr %slot1285, align 8
  %p7381 = inttoptr i64 %v7379 to ptr
  %gep7382 = getelementptr i8, ptr %p7381, i64 24
  %op7380 = ptrtoint ptr %gep7382 to i64
  store i64 %op7380, ptr %slot1366, align 8
  %v7383 = load i64, ptr %slot1285, align 8
  %p7385 = inttoptr i64 %v7383 to ptr
  %gep7386 = getelementptr i8, ptr %p7385, i64 8
  %op7384 = ptrtoint ptr %gep7386 to i64
  store i64 %op7384, ptr %slot1367, align 8
  %v7387 = load i64, ptr %slot1366, align 8
  %p7388 = inttoptr i64 %v7387 to ptr
  store i32 0, ptr %p7388, align 4, !alias.scope !3, !noalias !4
  %v7389 = load i64, ptr %slot1367, align 8
  %p7390 = inttoptr i64 %v7389 to ptr
  store i64 0, ptr %p7390, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone1789
bb_rcsendslow1789:
  %v7391 = load i64, ptr %slot1, align 8
  %p7392 = inttoptr i64 %v7391 to ptr
  %v7393 = load i64, ptr %slot1285, align 8
  %p7394 = inttoptr i64 %v7393 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p7392, ptr %p7394) nomerge, !dbg !190
  br label %bb_rcsenddone1789
bb_rcsenddone1789:
  %v7395 = load i64, ptr %slot40, align 8
  %p7396 = inttoptr i64 %v7395 to ptr
  %ld7397 = load i64, ptr %p7396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7397, ptr %slot1368, align 8
  %v7398 = load i64, ptr %slot1368, align 8
  %v7399 = load i64, ptr %slot54, align 8
  %p7400 = inttoptr i64 %v7399 to ptr
  store i64 %v7398, ptr %p7400, align 8, !alias.scope !3, !noalias !4
  %v7401 = load i64, ptr %slot55, align 8
  %p7402 = inttoptr i64 %v7401 to ptr
  store i64 256, ptr %p7402, align 8, !alias.scope !3, !noalias !4
  %v7403 = load i64, ptr %slot55, align 8
  %p7404 = inttoptr i64 %v7403 to ptr
  %ld7405 = load i64, ptr %p7404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7405, ptr %slot1369, align 8
  %v7406 = load i64, ptr %slot54, align 8
  %p7407 = inttoptr i64 %v7406 to ptr
  %ld7408 = load i64, ptr %p7407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7408, ptr %slot1370, align 8
  %v7409 = load i64, ptr %slot1370, align 8
  %v7410 = load i64, ptr %slot1369, align 8
  %cmp7411 = icmp sge i64 %v7409, %v7410
  %cv7412 = zext i1 %cmp7411 to i64
  store i64 %cv7412, ptr %slot1371, align 8
  %v7413 = load i64, ptr %slot1371, align 8
  %v7414 = load i64, ptr %slot54, align 8
  %p7415 = inttoptr i64 %v7414 to ptr
  store i64 %v7413, ptr %p7415, align 8, !alias.scope !3, !noalias !4
  %v7416 = load i64, ptr %slot54, align 8
  %p7417 = inttoptr i64 %v7416 to ptr
  %ld7418 = load i64, ptr %p7417, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7418, ptr %slot1372, align 8
  %v7419 = load i64, ptr %slot1372, align 8
  %cond7420 = icmp ne i64 %v7419, 0
  br i1 %cond7420, label %bb_next1888, label %bb_i107
bb_next1888:
  %v7421 = load i64, ptr %slot37, align 8
  %p7422 = inttoptr i64 %v7421 to ptr
  %ld7423 = load i64, ptr %p7422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7423, ptr %slot1373, align 8
  %v7424 = load i64, ptr %slot1373, align 8
  %v7425 = load i64, ptr %slot54, align 8
  %p7426 = inttoptr i64 %v7425 to ptr
  store i64 %v7424, ptr %p7426, align 8, !alias.scope !3, !noalias !4
  %p7427 = inttoptr i64 ptrtoint (ptr @myl_lit_7240c91ead2f85c7eb63a02228e06d80f417083f74f470faac795d8bd3f4708d to i64) to ptr
  %ld7428 = load i64, ptr %p7427, align 8, !alias.scope !4, !noalias !3
  store i64 %ld7428, ptr %slot1374, align 8
  %v7429 = load i64, ptr %slot1374, align 8
  %v7430 = load i64, ptr %slot55, align 8
  %p7431 = inttoptr i64 %v7430 to ptr
  store i64 %v7429, ptr %p7431, align 8, !alias.scope !3, !noalias !4
  %v7432 = load i64, ptr %slot55, align 8
  %p7433 = inttoptr i64 %v7432 to ptr
  %ld7434 = load i64, ptr %p7433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7434, ptr %slot1375, align 8
  %v7435 = load i64, ptr %slot1375, align 8
  %v7436 = load i64, ptr %slot30, align 8
  %p7437 = inttoptr i64 %v7436 to ptr
  store i64 %v7435, ptr %p7437, align 8, !alias.scope !3, !noalias !4
  %v7438 = load i64, ptr %slot30, align 8
  store i64 %v7438, ptr %slot1376, align 8
  %v7439 = load i64, ptr %slot31, align 8
  store i64 %v7439, ptr %slot1377, align 8
  %v7440 = load i64, ptr %slot1376, align 8
  %v7441 = load i64, ptr %slot1377, align 8
  %p7442 = inttoptr i64 %v7440 to ptr
  %p7443 = inttoptr i64 %v7441 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7443, ptr %p7442, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7444 = load i64, ptr %slot24, align 8
  %p7445 = inttoptr i64 %v7444 to ptr
  store i32 2, ptr %p7445, align 4, !alias.scope !3, !noalias !4
  %v7446 = load i64, ptr %slot23, align 8
  %p7447 = inttoptr i64 %v7446 to ptr
  store i32 1, ptr %p7447, align 4, !alias.scope !3, !noalias !4
  %v7448 = load i64, ptr %slot27, align 8
  store i64 %v7448, ptr %slot1378, align 8
  %v7449 = load i64, ptr %slot31, align 8
  store i64 %v7449, ptr %slot1379, align 8
  %v7450 = load i64, ptr %slot1379, align 8
  %v7451 = load i64, ptr %slot1378, align 8
  %p7452 = inttoptr i64 %v7450 to ptr
  %p7453 = inttoptr i64 %v7451 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7453, ptr %p7452, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7454 = load i64, ptr %slot20, align 8
  %p7455 = inttoptr i64 %v7454 to ptr
  store i32 2, ptr %p7455, align 4, !alias.scope !3, !noalias !4
  %v7456 = load i64, ptr %slot24, align 8
  %p7457 = inttoptr i64 %v7456 to ptr
  %ld7458 = load i32, ptr %p7457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7458, ptr %slot1380, align 8
  %v7459 = load i32, ptr %slot1380, align 8
  %v7460 = load i64, ptr %slot20, align 8
  %p7461 = inttoptr i64 %v7460 to ptr
  store i32 %v7459, ptr %p7461, align 4, !alias.scope !3, !noalias !4
  %v7462 = load i64, ptr %slot23, align 8
  %p7463 = inttoptr i64 %v7462 to ptr
  store i32 0, ptr %p7463, align 4, !alias.scope !3, !noalias !4
  %v7464 = load i64, ptr %slot19, align 8
  %p7465 = inttoptr i64 %v7464 to ptr
  store i32 1, ptr %p7465, align 4, !alias.scope !3, !noalias !4
  %v7466 = load i64, ptr %slot1378, align 8
  %p7467 = inttoptr i64 %v7466 to ptr
  %ld7468 = load i64, ptr %p7467, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7468, ptr %slot1381, align 8
  %v7469 = load i64, ptr %slot1381, align 8
  %v7470 = load i64, ptr %slot55, align 8
  %p7471 = inttoptr i64 %v7470 to ptr
  store i64 %v7469, ptr %p7471, align 8, !alias.scope !3, !noalias !4
  %v7472 = load i64, ptr %slot54, align 8
  %p7473 = inttoptr i64 %v7472 to ptr
  %ld7474 = load i64, ptr %p7473, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7474, ptr %slot1382, align 8
  %v7475 = load i64, ptr %slot55, align 8
  %p7476 = inttoptr i64 %v7475 to ptr
  %ld7477 = load i64, ptr %p7476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7477, ptr %slot1383, align 8
  %v7478 = load i64, ptr %slot1, align 8
  %v7479 = load i64, ptr %slot1382, align 8
  %v7480 = load i64, ptr %slot1383, align 8
  %call7481 = call i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64 %v7478, i64 %v7479, i64 %v7480) nomerge, !dbg !192
  store i64 %call7481, ptr %slot1384, align 8
  %v7482 = load i64, ptr %slot1384, align 8
  %v7483 = load i64, ptr %slot54, align 8
  %p7484 = inttoptr i64 %v7483 to ptr
  store i64 %v7482, ptr %p7484, align 8, !alias.scope !3, !noalias !4
  %v7485 = load i64, ptr %slot17, align 8
  %p7486 = inttoptr i64 %v7485 to ptr
  %ld7487 = load i32, ptr %p7486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7487, ptr %slot1385, align 8
  %v7488 = load i32, ptr %slot1385, align 8
  %cv7489 = zext i32 %v7488 to i64
  %cond7490 = icmp ne i64 %cv7489, 0
  br i1 %cond7490, label %bb_rcslotdrop1910, label %bb_rcslotdone1910
bb_rcslotdrop1910:
  %v7491 = load i64, ptr %slot17, align 8
  %p7492 = inttoptr i64 %v7491 to ptr
  store i32 0, ptr %p7492, align 4, !alias.scope !3, !noalias !4
  %v7493 = load i64, ptr %slot26, align 8
  store i64 %v7493, ptr %slot1386, align 8
  %v7494 = load i64, ptr %slot18, align 8
  %p7495 = inttoptr i64 %v7494 to ptr
  %ld7496 = load i32, ptr %p7495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7496, ptr %slot1387, align 8
  %v7497 = load i32, ptr %slot1387, align 8
  %op7498 = and i32 %v7497, 28
  store i32 %op7498, ptr %slot1388, align 8
  %v7499 = load i32, ptr %slot1388, align 8
  %cv7500 = zext i32 %v7499 to i64
  %cond7501 = icmp ne i64 %cv7500, 0
  br i1 %cond7501, label %bb_rcslotrole1910, label %bb_rcslotowner1910
bb_rcslotrole1910:
  %v7502 = load i64, ptr %slot66, align 8
  store i64 %v7502, ptr %slot1389, align 8
  %v7503 = load i64, ptr %slot1389, align 8
  %v7504 = load i64, ptr %slot1386, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v7503, i64 %v7504) nomerge, !dbg !192
  br label %bb_rcslotdone1910
bb_rcslotowner1910:
  %v7505 = load i64, ptr %slot66, align 8
  store i64 %v7505, ptr %slot1390, align 8
  %v7506 = load i64, ptr %slot1390, align 8
  %v7507 = load i64, ptr %slot1386, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v7506, i64 %v7507) nomerge, !dbg !192
  br label %bb_rcslotdone1910
bb_rcslotdone1910:
  %v7508 = load i64, ptr %slot19, align 8
  %p7509 = inttoptr i64 %v7508 to ptr
  %ld7510 = load i32, ptr %p7509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7510, ptr %slot1391, align 8
  %v7511 = load i32, ptr %slot1391, align 8
  %cv7512 = zext i32 %v7511 to i64
  %cond7513 = icmp ne i64 %cv7512, 0
  br i1 %cond7513, label %bb_rcslotdrop1919, label %bb_rcslotdone1919
bb_rcslotdrop1919:
  %v7514 = load i64, ptr %slot19, align 8
  %p7515 = inttoptr i64 %v7514 to ptr
  store i32 0, ptr %p7515, align 4, !alias.scope !3, !noalias !4
  %v7516 = load i64, ptr %slot27, align 8
  store i64 %v7516, ptr %slot1392, align 8
  %v7517 = load i64, ptr %slot20, align 8
  %p7518 = inttoptr i64 %v7517 to ptr
  %ld7519 = load i32, ptr %p7518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7519, ptr %slot1393, align 8
  %v7520 = load i32, ptr %slot1393, align 8
  %op7521 = and i32 %v7520, 28
  store i32 %op7521, ptr %slot1394, align 8
  %v7522 = load i32, ptr %slot1394, align 8
  %cv7523 = zext i32 %v7522 to i64
  %cond7524 = icmp ne i64 %cv7523, 0
  br i1 %cond7524, label %bb_rcslotrole1919, label %bb_rcslotowner1919
bb_rcslotrole1919:
  %v7525 = load i64, ptr %slot66, align 8
  store i64 %v7525, ptr %slot1395, align 8
  %v7526 = load i64, ptr %slot1392, align 8
  %p7527 = inttoptr i64 %v7526 to ptr
  %ld7528 = load i64, ptr %p7527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7528, ptr %slot1396, align 8
  %v7529 = load i64, ptr %slot1396, align 8
  %cmp7530 = icmp ne i64 %v7529, 0
  %cv7531 = zext i1 %cmp7530 to i32
  store i32 %cv7531, ptr %slot1397, align 8
  %v7532 = load i32, ptr %slot1397, align 8
  %cv7533 = zext i32 %v7532 to i64
  %cond7534 = icmp ne i64 %cv7533, 0
  br i1 %cond7534, label %bb_rcgnn1935, label %bb_rcgdone1935
bb_rcgnn1935:
  %v7535 = load i64, ptr %slot1396, align 8
  %op7536 = sub i64 %v7535, 16
  store i64 %op7536, ptr %slot1398, align 8
  %v7537 = load i64, ptr %slot1396, align 8
  %p7538 = inttoptr i64 %v7537 to ptr
  %rgep7539 = getelementptr i8, ptr %p7538, i64 -16
  %ld7540 = load i64, ptr %rgep7539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7540, ptr %slot1399, align 8
  %v7541 = load i64, ptr %slot1399, align 8
  %op7542 = and i64 %v7541, 4611686018427387906
  store i64 %op7542, ptr %slot1400, align 8
  %v7543 = load i64, ptr %slot1400, align 8
  %cmp7544 = icmp ne i64 %v7543, 0
  %cv7545 = zext i1 %cmp7544 to i32
  store i32 %cv7545, ptr %slot1401, align 8
  %v7546 = load i32, ptr %slot1401, align 8
  %cv7547 = zext i32 %v7546 to i64
  %cond7548 = icmp ne i64 %cv7547, 0
  br i1 %cond7548, label %bb_rcgclear1935, label %bb_rcgcounted1935
bb_rcgcounted1935:
  %v7549 = load i64, ptr %slot1396, align 8
  %op7550 = sub i64 %v7549, 24
  store i64 %op7550, ptr %slot1402, align 8
  %v7551 = load i64, ptr %slot1396, align 8
  %p7552 = inttoptr i64 %v7551 to ptr
  %rgep7553 = getelementptr i8, ptr %p7552, i64 -24
  %ld7554 = load i64, ptr %rgep7553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7554, ptr %slot1403, align 8
  %v7555 = load i64, ptr %slot1403, align 8
  %op7556 = sub i64 %v7555, 1
  store i64 %op7556, ptr %slot1404, align 8
  %v7557 = load i64, ptr %slot1404, align 8
  %cmp7558 = icmp eq i64 %v7557, 0
  %cv7559 = zext i1 %cmp7558 to i32
  store i32 %cv7559, ptr %slot1405, align 8
  %v7560 = load i32, ptr %slot1405, align 8
  %cv7561 = zext i32 %v7560 to i64
  %cond7562 = icmp ne i64 %cv7561, 0
  br i1 %cond7562, label %bb_rcglast1935, label %bb_rcgdec1935
bb_rcglast1935:
  %v7563 = load i64, ptr %slot1396, align 8
  %op7564 = sub i64 %v7563, 32
  store i64 %op7564, ptr %slot1406, align 8
  %v7565 = load i64, ptr %slot1396, align 8
  %p7566 = inttoptr i64 %v7565 to ptr
  %rgep7567 = getelementptr i8, ptr %p7566, i64 -32
  %ld7568 = load i64, ptr %rgep7567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7568, ptr %slot1407, align 8
  %v7569 = load i64, ptr %slot1407, align 8
  %cmp7570 = icmp ne i64 %v7569, 0
  %cv7571 = zext i1 %cmp7570 to i32
  store i32 %cv7571, ptr %slot1408, align 8
  %v7572 = load i32, ptr %slot1408, align 8
  %cv7573 = zext i32 %v7572 to i64
  %cond7574 = icmp ne i64 %cv7573, 0
  br i1 %cond7574, label %bb_rcgdec1935, label %bb_rcgslow1935
bb_rcgslow1935:
  %v7575 = load i64, ptr %slot1395, align 8
  %v7576 = load i64, ptr %slot1392, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7575, i64 %v7576) nomerge, !dbg !192
  br label %bb_rcgdone1935
bb_rcgdec1935:
  %v7577 = load i64, ptr %slot1404, align 8
  %v7578 = load i64, ptr %slot1396, align 8
  %p7579 = inttoptr i64 %v7578 to ptr
  %rgep7580 = getelementptr i8, ptr %p7579, i64 -24
  store i64 %v7577, ptr %rgep7580, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1935
bb_rcgclear1935:
  %v7581 = load i64, ptr %slot1392, align 8
  %p7582 = inttoptr i64 %v7581 to ptr
  store i64 0, ptr %p7582, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1935
bb_rcgdone1935:
  br label %bb_rcslotdone1919
bb_rcslotowner1919:
  %v7583 = load i64, ptr %slot66, align 8
  store i64 %v7583, ptr %slot1409, align 8
  %v7584 = load i64, ptr %slot1392, align 8
  %p7585 = inttoptr i64 %v7584 to ptr
  %ld7586 = load i64, ptr %p7585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7586, ptr %slot1410, align 8
  %v7587 = load i64, ptr %slot1410, align 8
  %cmp7588 = icmp ne i64 %v7587, 0
  %cv7589 = zext i1 %cmp7588 to i32
  store i32 %cv7589, ptr %slot1411, align 8
  %v7590 = load i32, ptr %slot1411, align 8
  %cv7591 = zext i32 %v7590 to i64
  %cond7592 = icmp ne i64 %cv7591, 0
  br i1 %cond7592, label %bb_rcgnn1950, label %bb_rcgdone1950
bb_rcgnn1950:
  %v7593 = load i64, ptr %slot1410, align 8
  %op7594 = sub i64 %v7593, 16
  store i64 %op7594, ptr %slot1412, align 8
  %v7595 = load i64, ptr %slot1410, align 8
  %p7596 = inttoptr i64 %v7595 to ptr
  %rgep7597 = getelementptr i8, ptr %p7596, i64 -16
  %ld7598 = load i64, ptr %rgep7597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7598, ptr %slot1413, align 8
  %v7599 = load i64, ptr %slot1413, align 8
  %op7600 = and i64 %v7599, 4611686018427387906
  store i64 %op7600, ptr %slot1414, align 8
  %v7601 = load i64, ptr %slot1414, align 8
  %cmp7602 = icmp ne i64 %v7601, 0
  %cv7603 = zext i1 %cmp7602 to i32
  store i32 %cv7603, ptr %slot1415, align 8
  %v7604 = load i32, ptr %slot1415, align 8
  %cv7605 = zext i32 %v7604 to i64
  %cond7606 = icmp ne i64 %cv7605, 0
  br i1 %cond7606, label %bb_rcgclear1950, label %bb_rcgcounted1950
bb_rcgcounted1950:
  %v7607 = load i64, ptr %slot1410, align 8
  %op7608 = sub i64 %v7607, 32
  store i64 %op7608, ptr %slot1416, align 8
  %v7609 = load i64, ptr %slot1410, align 8
  %p7610 = inttoptr i64 %v7609 to ptr
  %rgep7611 = getelementptr i8, ptr %p7610, i64 -32
  %ld7612 = load i64, ptr %rgep7611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7612, ptr %slot1417, align 8
  %v7613 = load i64, ptr %slot1417, align 8
  %op7614 = sub i64 %v7613, 1
  store i64 %op7614, ptr %slot1418, align 8
  %v7615 = load i64, ptr %slot1418, align 8
  %cmp7616 = icmp eq i64 %v7615, 0
  %cv7617 = zext i1 %cmp7616 to i32
  store i32 %cv7617, ptr %slot1419, align 8
  %v7618 = load i32, ptr %slot1419, align 8
  %cv7619 = zext i32 %v7618 to i64
  %cond7620 = icmp ne i64 %cv7619, 0
  br i1 %cond7620, label %bb_rcglast1950, label %bb_rcgdec1950
bb_rcglast1950:
  %v7621 = load i64, ptr %slot1410, align 8
  %op7622 = sub i64 %v7621, 24
  store i64 %op7622, ptr %slot1420, align 8
  %v7623 = load i64, ptr %slot1410, align 8
  %p7624 = inttoptr i64 %v7623 to ptr
  %rgep7625 = getelementptr i8, ptr %p7624, i64 -24
  %ld7626 = load i64, ptr %rgep7625, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7626, ptr %slot1421, align 8
  %v7627 = load i64, ptr %slot1421, align 8
  %cmp7628 = icmp ne i64 %v7627, 0
  %cv7629 = zext i1 %cmp7628 to i32
  store i32 %cv7629, ptr %slot1422, align 8
  %v7630 = load i32, ptr %slot1422, align 8
  %cv7631 = zext i32 %v7630 to i64
  %cond7632 = icmp ne i64 %cv7631, 0
  br i1 %cond7632, label %bb_rcgdec1950, label %bb_rcgslow1950
bb_rcgslow1950:
  %v7633 = load i64, ptr %slot1409, align 8
  %v7634 = load i64, ptr %slot1392, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7633, i64 %v7634) nomerge, !dbg !192
  br label %bb_rcgdone1950
bb_rcgdec1950:
  %v7635 = load i64, ptr %slot1418, align 8
  %v7636 = load i64, ptr %slot1410, align 8
  %p7637 = inttoptr i64 %v7636 to ptr
  %rgep7638 = getelementptr i8, ptr %p7637, i64 -32
  store i64 %v7635, ptr %rgep7638, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1950
bb_rcgclear1950:
  %v7639 = load i64, ptr %slot1392, align 8
  %p7640 = inttoptr i64 %v7639 to ptr
  store i64 0, ptr %p7640, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1950
bb_rcgdone1950:
  br label %bb_rcslotdone1919
bb_rcslotdone1919:
  %v7641 = load i64, ptr %slot54, align 8
  %p7642 = inttoptr i64 %v7641 to ptr
  store i64 0, ptr %p7642, align 8, !alias.scope !3, !noalias !4
  %v7643 = load i64, ptr %slot54, align 8
  %p7644 = inttoptr i64 %v7643 to ptr
  %ld7645 = load i64, ptr %p7644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7645, ptr %slot1423, align 8
  %v7646 = load i64, ptr %slot32, align 8
  %p7648 = inttoptr i64 %v7646 to ptr
  %gep7649 = getelementptr i8, ptr %p7648, i64 24
  %op7647 = ptrtoint ptr %gep7649 to i64
  store i64 %op7647, ptr %slot1424, align 8
  %v7650 = load i64, ptr %slot1424, align 8
  %p7651 = inttoptr i64 %v7650 to ptr
  %ld7652 = load i32, ptr %p7651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7652, ptr %slot1425, align 8
  %v7653 = load i64, ptr %slot34, align 8
  %p7655 = inttoptr i64 %v7653 to ptr
  %gep7656 = getelementptr i8, ptr %p7655, i64 24
  %op7654 = ptrtoint ptr %gep7656 to i64
  store i64 %op7654, ptr %slot1426, align 8
  %v7657 = load i64, ptr %slot1426, align 8
  %p7658 = inttoptr i64 %v7657 to ptr
  %ld7659 = load i32, ptr %p7658, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7659, ptr %slot1427, align 8
  %v7660 = load i32, ptr %slot1425, align 8
  %v7661 = load i32, ptr %slot1427, align 8
  %op7662 = or i32 %v7660, %v7661
  store i32 %op7662, ptr %slot1428, align 8
  %v7663 = load i32, ptr %slot1428, align 8
  %cv7664 = zext i32 %v7663 to i64
  %cond7665 = icmp ne i64 %cv7664, 0
  br i1 %cond7665, label %bb_rcscopesopen1960, label %bb_rcscopesclosed1960
bb_rcscopesopen1960:
  %v7666 = load i64, ptr %slot36, align 8
  %p7668 = inttoptr i64 %v7666 to ptr
  %gep7669 = getelementptr i8, ptr %p7668, i64 0
  %op7667 = ptrtoint ptr %gep7669 to i64
  store i64 %op7667, ptr %slot1429, align 8
  %v7670 = load i64, ptr %slot32, align 8
  %v7671 = load i64, ptr %slot1429, align 8
  %p7672 = inttoptr i64 %v7671 to ptr
  store i64 %v7670, ptr %p7672, align 8, !alias.scope !3, !noalias !4
  %v7673 = load i64, ptr %slot36, align 8
  %p7675 = inttoptr i64 %v7673 to ptr
  %gep7676 = getelementptr i8, ptr %p7675, i64 8
  %op7674 = ptrtoint ptr %gep7676 to i64
  store i64 %op7674, ptr %slot1430, align 8
  %v7677 = load i64, ptr %slot34, align 8
  %v7678 = load i64, ptr %slot1430, align 8
  %p7679 = inttoptr i64 %v7678 to ptr
  store i64 %v7677, ptr %p7679, align 8, !alias.scope !3, !noalias !4
  %v7680 = load i64, ptr %slot1, align 8
  %p7681 = inttoptr i64 %v7680 to ptr
  %v7682 = load i64, ptr %slot36, align 8
  %p7683 = inttoptr i64 %v7682 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p7681, ptr %p7683, i64 2) nomerge, !dbg !194
  br label %bb_rcscopesclosed1960
bb_rcscopesclosed1960:
  %v7684 = load i64, ptr %slot17, align 8
  %p7685 = inttoptr i64 %v7684 to ptr
  %ld7686 = load i32, ptr %p7685, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7686, ptr %slot1431, align 8
  %v7687 = load i32, ptr %slot1431, align 8
  %cv7688 = zext i32 %v7687 to i64
  %cond7689 = icmp ne i64 %cv7688, 0
  br i1 %cond7689, label %bb_rcslotdrop1965, label %bb_rcslotdone1965
bb_rcslotdrop1965:
  %v7690 = load i64, ptr %slot17, align 8
  %p7691 = inttoptr i64 %v7690 to ptr
  store i32 0, ptr %p7691, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1965
bb_rcslotdone1965:
  %v7692 = load i64, ptr %slot15, align 8
  %p7693 = inttoptr i64 %v7692 to ptr
  %ld7694 = load i32, ptr %p7693, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7694, ptr %slot1432, align 8
  %v7695 = load i32, ptr %slot1432, align 8
  %cv7696 = zext i32 %v7695 to i64
  %cond7697 = icmp ne i64 %cv7696, 0
  br i1 %cond7697, label %bb_rcslotdrop1968, label %bb_rcslotdone1968
bb_rcslotdrop1968:
  %v7698 = load i64, ptr %slot15, align 8
  %p7699 = inttoptr i64 %v7698 to ptr
  store i32 0, ptr %p7699, align 4, !alias.scope !3, !noalias !4
  %v7700 = load i64, ptr %slot52, align 8
  store i64 %v7700, ptr %slot1433, align 8
  %v7701 = load i64, ptr %slot16, align 8
  %p7702 = inttoptr i64 %v7701 to ptr
  %ld7703 = load i32, ptr %p7702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7703, ptr %slot1434, align 8
  %v7704 = load i32, ptr %slot1434, align 8
  %op7705 = and i32 %v7704, 28
  store i32 %op7705, ptr %slot1435, align 8
  %v7706 = load i32, ptr %slot1435, align 8
  %cv7707 = zext i32 %v7706 to i64
  %cond7708 = icmp ne i64 %cv7707, 0
  br i1 %cond7708, label %bb_rcslotrole1968, label %bb_rcslotowner1968
bb_rcslotrole1968:
  %v7709 = load i64, ptr %slot66, align 8
  store i64 %v7709, ptr %slot1436, align 8
  %v7710 = load i64, ptr %slot1436, align 8
  %v7711 = load i64, ptr %slot1433, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7710, i64 %v7711) nomerge, !dbg !194
  br label %bb_rcslotdone1968
bb_rcslotowner1968:
  %v7712 = load i64, ptr %slot66, align 8
  store i64 %v7712, ptr %slot1437, align 8
  %v7713 = load i64, ptr %slot1437, align 8
  %v7714 = load i64, ptr %slot1433, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7713, i64 %v7714) nomerge, !dbg !194
  br label %bb_rcslotdone1968
bb_rcslotdone1968:
  %v7715 = load i64, ptr %slot13, align 8
  %p7716 = inttoptr i64 %v7715 to ptr
  %ld7717 = load i32, ptr %p7716, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7717, ptr %slot1438, align 8
  %v7718 = load i32, ptr %slot1438, align 8
  %cv7719 = zext i32 %v7718 to i64
  %cond7720 = icmp ne i64 %cv7719, 0
  br i1 %cond7720, label %bb_rcslotdrop2014, label %bb_rcslotdone2014
bb_rcslotdrop2014:
  %v7721 = load i64, ptr %slot13, align 8
  %p7722 = inttoptr i64 %v7721 to ptr
  store i32 0, ptr %p7722, align 4, !alias.scope !3, !noalias !4
  %v7723 = load i64, ptr %slot49, align 8
  store i64 %v7723, ptr %slot1439, align 8
  %v7724 = load i64, ptr %slot14, align 8
  %p7725 = inttoptr i64 %v7724 to ptr
  %ld7726 = load i32, ptr %p7725, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7726, ptr %slot1440, align 8
  %v7727 = load i32, ptr %slot1440, align 8
  %op7728 = and i32 %v7727, 28
  store i32 %op7728, ptr %slot1441, align 8
  %v7729 = load i32, ptr %slot1441, align 8
  %cv7730 = zext i32 %v7729 to i64
  %cond7731 = icmp ne i64 %cv7730, 0
  br i1 %cond7731, label %bb_rcslotrole2014, label %bb_rcslotowner2014
bb_rcslotrole2014:
  %v7732 = load i64, ptr %slot66, align 8
  store i64 %v7732, ptr %slot1442, align 8
  %v7733 = load i64, ptr %slot1442, align 8
  %v7734 = load i64, ptr %slot1439, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7733, i64 %v7734) nomerge, !dbg !194
  br label %bb_rcslotdone2014
bb_rcslotowner2014:
  %v7735 = load i64, ptr %slot66, align 8
  store i64 %v7735, ptr %slot1443, align 8
  %v7736 = load i64, ptr %slot1443, align 8
  %v7737 = load i64, ptr %slot1439, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7736, i64 %v7737) nomerge, !dbg !194
  br label %bb_rcslotdone2014
bb_rcslotdone2014:
  %v7738 = load i64, ptr %slot11, align 8
  %p7739 = inttoptr i64 %v7738 to ptr
  %ld7740 = load i32, ptr %p7739, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7740, ptr %slot1444, align 8
  %v7741 = load i32, ptr %slot1444, align 8
  %cv7742 = zext i32 %v7741 to i64
  %cond7743 = icmp ne i64 %cv7742, 0
  br i1 %cond7743, label %bb_rcslotdrop2060, label %bb_rcslotdone2060
bb_rcslotdrop2060:
  %v7744 = load i64, ptr %slot11, align 8
  %p7745 = inttoptr i64 %v7744 to ptr
  store i32 0, ptr %p7745, align 4, !alias.scope !3, !noalias !4
  %v7746 = load i64, ptr %slot47, align 8
  store i64 %v7746, ptr %slot1445, align 8
  %v7747 = load i64, ptr %slot12, align 8
  %p7748 = inttoptr i64 %v7747 to ptr
  %ld7749 = load i32, ptr %p7748, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7749, ptr %slot1446, align 8
  %v7750 = load i32, ptr %slot1446, align 8
  %op7751 = and i32 %v7750, 28
  store i32 %op7751, ptr %slot1447, align 8
  %v7752 = load i32, ptr %slot1447, align 8
  %cv7753 = zext i32 %v7752 to i64
  %cond7754 = icmp ne i64 %cv7753, 0
  br i1 %cond7754, label %bb_rcslotrole2060, label %bb_rcslotowner2060
bb_rcslotrole2060:
  %v7755 = load i64, ptr %slot66, align 8
  store i64 %v7755, ptr %slot1448, align 8
  %v7756 = load i64, ptr %slot1448, align 8
  %v7757 = load i64, ptr %slot1445, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v7756, i64 %v7757) nomerge, !dbg !194
  br label %bb_rcslotdone2060
bb_rcslotowner2060:
  %v7758 = load i64, ptr %slot66, align 8
  store i64 %v7758, ptr %slot1449, align 8
  %v7759 = load i64, ptr %slot1449, align 8
  %v7760 = load i64, ptr %slot1445, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v7759, i64 %v7760) nomerge, !dbg !194
  br label %bb_rcslotdone2060
bb_rcslotdone2060:
  %v7761 = load i64, ptr %slot9, align 8
  %p7762 = inttoptr i64 %v7761 to ptr
  %ld7763 = load i32, ptr %p7762, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7763, ptr %slot1450, align 8
  %v7764 = load i32, ptr %slot1450, align 8
  %cv7765 = zext i32 %v7764 to i64
  %cond7766 = icmp ne i64 %cv7765, 0
  br i1 %cond7766, label %bb_rcslotdrop2069, label %bb_rcslotdone2069
bb_rcslotdrop2069:
  %v7767 = load i64, ptr %slot9, align 8
  %p7768 = inttoptr i64 %v7767 to ptr
  store i32 0, ptr %p7768, align 4, !alias.scope !3, !noalias !4
  %v7769 = load i64, ptr %slot46, align 8
  store i64 %v7769, ptr %slot1451, align 8
  %v7770 = load i64, ptr %slot10, align 8
  %p7771 = inttoptr i64 %v7770 to ptr
  %ld7772 = load i32, ptr %p7771, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7772, ptr %slot1452, align 8
  %v7773 = load i32, ptr %slot1452, align 8
  %op7774 = and i32 %v7773, 28
  store i32 %op7774, ptr %slot1453, align 8
  %v7775 = load i32, ptr %slot1453, align 8
  %cv7776 = zext i32 %v7775 to i64
  %cond7777 = icmp ne i64 %cv7776, 0
  br i1 %cond7777, label %bb_rcslotrole2069, label %bb_rcslotowner2069
bb_rcslotrole2069:
  %v7778 = load i64, ptr %slot66, align 8
  store i64 %v7778, ptr %slot1454, align 8
  %v7779 = load i64, ptr %slot1454, align 8
  %v7780 = load i64, ptr %slot1451, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7779, i64 %v7780) nomerge, !dbg !194
  br label %bb_rcslotdone2069
bb_rcslotowner2069:
  %v7781 = load i64, ptr %slot66, align 8
  store i64 %v7781, ptr %slot1455, align 8
  %v7782 = load i64, ptr %slot1455, align 8
  %v7783 = load i64, ptr %slot1451, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7782, i64 %v7783) nomerge, !dbg !194
  br label %bb_rcslotdone2069
bb_rcslotdone2069:
  %v7784 = load i64, ptr %slot7, align 8
  %p7785 = inttoptr i64 %v7784 to ptr
  %ld7786 = load i32, ptr %p7785, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7786, ptr %slot1456, align 8
  %v7787 = load i32, ptr %slot1456, align 8
  %cv7788 = zext i32 %v7787 to i64
  %cond7789 = icmp ne i64 %cv7788, 0
  br i1 %cond7789, label %bb_rcslotdrop2078, label %bb_rcslotdone2078
bb_rcslotdrop2078:
  %v7790 = load i64, ptr %slot7, align 8
  %p7791 = inttoptr i64 %v7790 to ptr
  store i32 0, ptr %p7791, align 4, !alias.scope !3, !noalias !4
  %v7792 = load i64, ptr %slot45, align 8
  store i64 %v7792, ptr %slot1457, align 8
  %v7793 = load i64, ptr %slot8, align 8
  %p7794 = inttoptr i64 %v7793 to ptr
  %ld7795 = load i32, ptr %p7794, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7795, ptr %slot1458, align 8
  %v7796 = load i32, ptr %slot1458, align 8
  %op7797 = and i32 %v7796, 28
  store i32 %op7797, ptr %slot1459, align 8
  %v7798 = load i32, ptr %slot1459, align 8
  %cv7799 = zext i32 %v7798 to i64
  %cond7800 = icmp ne i64 %cv7799, 0
  br i1 %cond7800, label %bb_rcslotrole2078, label %bb_rcslotowner2078
bb_rcslotrole2078:
  %v7801 = load i64, ptr %slot66, align 8
  store i64 %v7801, ptr %slot1460, align 8
  %v7802 = load i64, ptr %slot1460, align 8
  %v7803 = load i64, ptr %slot1457, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7802, i64 %v7803) nomerge, !dbg !194
  br label %bb_rcslotdone2078
bb_rcslotowner2078:
  %v7804 = load i64, ptr %slot66, align 8
  store i64 %v7804, ptr %slot1461, align 8
  %v7805 = load i64, ptr %slot1461, align 8
  %v7806 = load i64, ptr %slot1457, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7805, i64 %v7806) nomerge, !dbg !194
  br label %bb_rcslotdone2078
bb_rcslotdone2078:
  %v7807 = load i64, ptr %slot5, align 8
  %p7808 = inttoptr i64 %v7807 to ptr
  %ld7809 = load i32, ptr %p7808, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7809, ptr %slot1462, align 8
  %v7810 = load i32, ptr %slot1462, align 8
  %cv7811 = zext i32 %v7810 to i64
  %cond7812 = icmp ne i64 %cv7811, 0
  br i1 %cond7812, label %bb_rcslotdrop2161, label %bb_rcslotdone2161
bb_rcslotdrop2161:
  %v7813 = load i64, ptr %slot5, align 8
  %p7814 = inttoptr i64 %v7813 to ptr
  store i32 0, ptr %p7814, align 4, !alias.scope !3, !noalias !4
  %v7815 = load i64, ptr %slot39, align 8
  store i64 %v7815, ptr %slot1463, align 8
  %v7816 = load i64, ptr %slot6, align 8
  %p7817 = inttoptr i64 %v7816 to ptr
  %ld7818 = load i32, ptr %p7817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7818, ptr %slot1464, align 8
  %v7819 = load i32, ptr %slot1464, align 8
  %op7820 = and i32 %v7819, 28
  store i32 %op7820, ptr %slot1465, align 8
  %v7821 = load i32, ptr %slot1465, align 8
  %cv7822 = zext i32 %v7821 to i64
  %cond7823 = icmp ne i64 %cv7822, 0
  br i1 %cond7823, label %bb_rcslotrole2161, label %bb_rcslotowner2161
bb_rcslotrole2161:
  %v7824 = load i64, ptr %slot66, align 8
  store i64 %v7824, ptr %slot1466, align 8
  %v7825 = load i64, ptr %slot1466, align 8
  %v7826 = load i64, ptr %slot1463, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v7825, i64 %v7826) nomerge, !dbg !194
  br label %bb_rcslotdone2161
bb_rcslotowner2161:
  %v7827 = load i64, ptr %slot66, align 8
  store i64 %v7827, ptr %slot1467, align 8
  %v7828 = load i64, ptr %slot1467, align 8
  %v7829 = load i64, ptr %slot1463, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v7828, i64 %v7829) nomerge, !dbg !194
  br label %bb_rcslotdone2161
bb_rcslotdone2161:
  %v7830 = load i64, ptr %slot1423, align 8
  ret i64 %v7830
bb_i107:
  %v7831 = load i64, ptr %slot40, align 8
  %p7832 = inttoptr i64 %v7831 to ptr
  %ld7833 = load i64, ptr %p7832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7833, ptr %slot1468, align 8
  %v7834 = load i64, ptr %slot1468, align 8
  %v7835 = load i64, ptr %slot54, align 8
  %p7836 = inttoptr i64 %v7835 to ptr
  store i64 %v7834, ptr %p7836, align 8, !alias.scope !3, !noalias !4
  %v7837 = load i64, ptr %slot54, align 8
  %p7838 = inttoptr i64 %v7837 to ptr
  %ld7839 = load i64, ptr %p7838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7839, ptr %slot1469, align 8
  %v7840 = load i64, ptr %slot32, align 8
  %p7842 = inttoptr i64 %v7840 to ptr
  %gep7843 = getelementptr i8, ptr %p7842, i64 24
  %op7841 = ptrtoint ptr %gep7843 to i64
  store i64 %op7841, ptr %slot1470, align 8
  %v7844 = load i64, ptr %slot1470, align 8
  %p7845 = inttoptr i64 %v7844 to ptr
  %ld7846 = load i32, ptr %p7845, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7846, ptr %slot1471, align 8
  %v7847 = load i64, ptr %slot34, align 8
  %p7849 = inttoptr i64 %v7847 to ptr
  %gep7850 = getelementptr i8, ptr %p7849, i64 24
  %op7848 = ptrtoint ptr %gep7850 to i64
  store i64 %op7848, ptr %slot1472, align 8
  %v7851 = load i64, ptr %slot1472, align 8
  %p7852 = inttoptr i64 %v7851 to ptr
  %ld7853 = load i32, ptr %p7852, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7853, ptr %slot1473, align 8
  %v7854 = load i32, ptr %slot1471, align 8
  %v7855 = load i32, ptr %slot1473, align 8
  %op7856 = or i32 %v7854, %v7855
  store i32 %op7856, ptr %slot1474, align 8
  %v7857 = load i32, ptr %slot1474, align 8
  %cv7858 = zext i32 %v7857 to i64
  %cond7859 = icmp ne i64 %cv7858, 0
  br i1 %cond7859, label %bb_rcscopesopen2184, label %bb_rcscopesclosed2184
bb_rcscopesopen2184:
  %v7860 = load i64, ptr %slot36, align 8
  %p7862 = inttoptr i64 %v7860 to ptr
  %gep7863 = getelementptr i8, ptr %p7862, i64 0
  %op7861 = ptrtoint ptr %gep7863 to i64
  store i64 %op7861, ptr %slot1475, align 8
  %v7864 = load i64, ptr %slot32, align 8
  %v7865 = load i64, ptr %slot1475, align 8
  %p7866 = inttoptr i64 %v7865 to ptr
  store i64 %v7864, ptr %p7866, align 8, !alias.scope !3, !noalias !4
  %v7867 = load i64, ptr %slot36, align 8
  %p7869 = inttoptr i64 %v7867 to ptr
  %gep7870 = getelementptr i8, ptr %p7869, i64 8
  %op7868 = ptrtoint ptr %gep7870 to i64
  store i64 %op7868, ptr %slot1476, align 8
  %v7871 = load i64, ptr %slot34, align 8
  %v7872 = load i64, ptr %slot1476, align 8
  %p7873 = inttoptr i64 %v7872 to ptr
  store i64 %v7871, ptr %p7873, align 8, !alias.scope !3, !noalias !4
  %v7874 = load i64, ptr %slot1, align 8
  %p7875 = inttoptr i64 %v7874 to ptr
  %v7876 = load i64, ptr %slot36, align 8
  %p7877 = inttoptr i64 %v7876 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p7875, ptr %p7877, i64 2) nomerge, !dbg !196
  br label %bb_rcscopesclosed2184
bb_rcscopesclosed2184:
  %v7878 = load i64, ptr %slot17, align 8
  %p7879 = inttoptr i64 %v7878 to ptr
  %ld7880 = load i32, ptr %p7879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7880, ptr %slot1477, align 8
  %v7881 = load i32, ptr %slot1477, align 8
  %cv7882 = zext i32 %v7881 to i64
  %cond7883 = icmp ne i64 %cv7882, 0
  br i1 %cond7883, label %bb_rcslotdrop2189, label %bb_rcslotdone2189
bb_rcslotdrop2189:
  %v7884 = load i64, ptr %slot17, align 8
  %p7885 = inttoptr i64 %v7884 to ptr
  store i32 0, ptr %p7885, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2189
bb_rcslotdone2189:
  %v7886 = load i64, ptr %slot15, align 8
  %p7887 = inttoptr i64 %v7886 to ptr
  %ld7888 = load i32, ptr %p7887, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7888, ptr %slot1478, align 8
  %v7889 = load i32, ptr %slot1478, align 8
  %cv7890 = zext i32 %v7889 to i64
  %cond7891 = icmp ne i64 %cv7890, 0
  br i1 %cond7891, label %bb_rcslotdrop2192, label %bb_rcslotdone2192
bb_rcslotdrop2192:
  %v7892 = load i64, ptr %slot15, align 8
  %p7893 = inttoptr i64 %v7892 to ptr
  store i32 0, ptr %p7893, align 4, !alias.scope !3, !noalias !4
  %v7894 = load i64, ptr %slot52, align 8
  store i64 %v7894, ptr %slot1479, align 8
  %v7895 = load i64, ptr %slot16, align 8
  %p7896 = inttoptr i64 %v7895 to ptr
  %ld7897 = load i32, ptr %p7896, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7897, ptr %slot1480, align 8
  %v7898 = load i32, ptr %slot1480, align 8
  %op7899 = and i32 %v7898, 28
  store i32 %op7899, ptr %slot1481, align 8
  %v7900 = load i32, ptr %slot1481, align 8
  %cv7901 = zext i32 %v7900 to i64
  %cond7902 = icmp ne i64 %cv7901, 0
  br i1 %cond7902, label %bb_rcslotrole2192, label %bb_rcslotowner2192
bb_rcslotrole2192:
  %v7903 = load i64, ptr %slot66, align 8
  store i64 %v7903, ptr %slot1482, align 8
  %v7904 = load i64, ptr %slot1482, align 8
  %v7905 = load i64, ptr %slot1479, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v7904, i64 %v7905) nomerge, !dbg !196
  br label %bb_rcslotdone2192
bb_rcslotowner2192:
  %v7906 = load i64, ptr %slot66, align 8
  store i64 %v7906, ptr %slot1483, align 8
  %v7907 = load i64, ptr %slot1483, align 8
  %v7908 = load i64, ptr %slot1479, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v7907, i64 %v7908) nomerge, !dbg !196
  br label %bb_rcslotdone2192
bb_rcslotdone2192:
  %v7909 = load i64, ptr %slot13, align 8
  %p7910 = inttoptr i64 %v7909 to ptr
  %ld7911 = load i32, ptr %p7910, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7911, ptr %slot1484, align 8
  %v7912 = load i32, ptr %slot1484, align 8
  %cv7913 = zext i32 %v7912 to i64
  %cond7914 = icmp ne i64 %cv7913, 0
  br i1 %cond7914, label %bb_rcslotdrop2238, label %bb_rcslotdone2238
bb_rcslotdrop2238:
  %v7915 = load i64, ptr %slot13, align 8
  %p7916 = inttoptr i64 %v7915 to ptr
  store i32 0, ptr %p7916, align 4, !alias.scope !3, !noalias !4
  %v7917 = load i64, ptr %slot49, align 8
  store i64 %v7917, ptr %slot1485, align 8
  %v7918 = load i64, ptr %slot14, align 8
  %p7919 = inttoptr i64 %v7918 to ptr
  %ld7920 = load i32, ptr %p7919, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7920, ptr %slot1486, align 8
  %v7921 = load i32, ptr %slot1486, align 8
  %op7922 = and i32 %v7921, 28
  store i32 %op7922, ptr %slot1487, align 8
  %v7923 = load i32, ptr %slot1487, align 8
  %cv7924 = zext i32 %v7923 to i64
  %cond7925 = icmp ne i64 %cv7924, 0
  br i1 %cond7925, label %bb_rcslotrole2238, label %bb_rcslotowner2238
bb_rcslotrole2238:
  %v7926 = load i64, ptr %slot66, align 8
  store i64 %v7926, ptr %slot1488, align 8
  %v7927 = load i64, ptr %slot1488, align 8
  %v7928 = load i64, ptr %slot1485, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7927, i64 %v7928) nomerge, !dbg !196
  br label %bb_rcslotdone2238
bb_rcslotowner2238:
  %v7929 = load i64, ptr %slot66, align 8
  store i64 %v7929, ptr %slot1489, align 8
  %v7930 = load i64, ptr %slot1489, align 8
  %v7931 = load i64, ptr %slot1485, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7930, i64 %v7931) nomerge, !dbg !196
  br label %bb_rcslotdone2238
bb_rcslotdone2238:
  %v7932 = load i64, ptr %slot11, align 8
  %p7933 = inttoptr i64 %v7932 to ptr
  %ld7934 = load i32, ptr %p7933, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7934, ptr %slot1490, align 8
  %v7935 = load i32, ptr %slot1490, align 8
  %cv7936 = zext i32 %v7935 to i64
  %cond7937 = icmp ne i64 %cv7936, 0
  br i1 %cond7937, label %bb_rcslotdrop2284, label %bb_rcslotdone2284
bb_rcslotdrop2284:
  %v7938 = load i64, ptr %slot11, align 8
  %p7939 = inttoptr i64 %v7938 to ptr
  store i32 0, ptr %p7939, align 4, !alias.scope !3, !noalias !4
  %v7940 = load i64, ptr %slot47, align 8
  store i64 %v7940, ptr %slot1491, align 8
  %v7941 = load i64, ptr %slot12, align 8
  %p7942 = inttoptr i64 %v7941 to ptr
  %ld7943 = load i32, ptr %p7942, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7943, ptr %slot1492, align 8
  %v7944 = load i32, ptr %slot1492, align 8
  %op7945 = and i32 %v7944, 28
  store i32 %op7945, ptr %slot1493, align 8
  %v7946 = load i32, ptr %slot1493, align 8
  %cv7947 = zext i32 %v7946 to i64
  %cond7948 = icmp ne i64 %cv7947, 0
  br i1 %cond7948, label %bb_rcslotrole2284, label %bb_rcslotowner2284
bb_rcslotrole2284:
  %v7949 = load i64, ptr %slot66, align 8
  store i64 %v7949, ptr %slot1494, align 8
  %v7950 = load i64, ptr %slot1494, align 8
  %v7951 = load i64, ptr %slot1491, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v7950, i64 %v7951) nomerge, !dbg !196
  br label %bb_rcslotdone2284
bb_rcslotowner2284:
  %v7952 = load i64, ptr %slot66, align 8
  store i64 %v7952, ptr %slot1495, align 8
  %v7953 = load i64, ptr %slot1495, align 8
  %v7954 = load i64, ptr %slot1491, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v7953, i64 %v7954) nomerge, !dbg !196
  br label %bb_rcslotdone2284
bb_rcslotdone2284:
  %v7955 = load i64, ptr %slot9, align 8
  %p7956 = inttoptr i64 %v7955 to ptr
  %ld7957 = load i32, ptr %p7956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7957, ptr %slot1496, align 8
  %v7958 = load i32, ptr %slot1496, align 8
  %cv7959 = zext i32 %v7958 to i64
  %cond7960 = icmp ne i64 %cv7959, 0
  br i1 %cond7960, label %bb_rcslotdrop2293, label %bb_rcslotdone2293
bb_rcslotdrop2293:
  %v7961 = load i64, ptr %slot9, align 8
  %p7962 = inttoptr i64 %v7961 to ptr
  store i32 0, ptr %p7962, align 4, !alias.scope !3, !noalias !4
  %v7963 = load i64, ptr %slot46, align 8
  store i64 %v7963, ptr %slot1497, align 8
  %v7964 = load i64, ptr %slot10, align 8
  %p7965 = inttoptr i64 %v7964 to ptr
  %ld7966 = load i32, ptr %p7965, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7966, ptr %slot1498, align 8
  %v7967 = load i32, ptr %slot1498, align 8
  %op7968 = and i32 %v7967, 28
  store i32 %op7968, ptr %slot1499, align 8
  %v7969 = load i32, ptr %slot1499, align 8
  %cv7970 = zext i32 %v7969 to i64
  %cond7971 = icmp ne i64 %cv7970, 0
  br i1 %cond7971, label %bb_rcslotrole2293, label %bb_rcslotowner2293
bb_rcslotrole2293:
  %v7972 = load i64, ptr %slot66, align 8
  store i64 %v7972, ptr %slot1500, align 8
  %v7973 = load i64, ptr %slot1500, align 8
  %v7974 = load i64, ptr %slot1497, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7973, i64 %v7974) nomerge, !dbg !196
  br label %bb_rcslotdone2293
bb_rcslotowner2293:
  %v7975 = load i64, ptr %slot66, align 8
  store i64 %v7975, ptr %slot1501, align 8
  %v7976 = load i64, ptr %slot1501, align 8
  %v7977 = load i64, ptr %slot1497, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7976, i64 %v7977) nomerge, !dbg !196
  br label %bb_rcslotdone2293
bb_rcslotdone2293:
  %v7978 = load i64, ptr %slot7, align 8
  %p7979 = inttoptr i64 %v7978 to ptr
  %ld7980 = load i32, ptr %p7979, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7980, ptr %slot1502, align 8
  %v7981 = load i32, ptr %slot1502, align 8
  %cv7982 = zext i32 %v7981 to i64
  %cond7983 = icmp ne i64 %cv7982, 0
  br i1 %cond7983, label %bb_rcslotdrop2302, label %bb_rcslotdone2302
bb_rcslotdrop2302:
  %v7984 = load i64, ptr %slot7, align 8
  %p7985 = inttoptr i64 %v7984 to ptr
  store i32 0, ptr %p7985, align 4, !alias.scope !3, !noalias !4
  %v7986 = load i64, ptr %slot45, align 8
  store i64 %v7986, ptr %slot1503, align 8
  %v7987 = load i64, ptr %slot8, align 8
  %p7988 = inttoptr i64 %v7987 to ptr
  %ld7989 = load i32, ptr %p7988, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7989, ptr %slot1504, align 8
  %v7990 = load i32, ptr %slot1504, align 8
  %op7991 = and i32 %v7990, 28
  store i32 %op7991, ptr %slot1505, align 8
  %v7992 = load i32, ptr %slot1505, align 8
  %cv7993 = zext i32 %v7992 to i64
  %cond7994 = icmp ne i64 %cv7993, 0
  br i1 %cond7994, label %bb_rcslotrole2302, label %bb_rcslotowner2302
bb_rcslotrole2302:
  %v7995 = load i64, ptr %slot66, align 8
  store i64 %v7995, ptr %slot1506, align 8
  %v7996 = load i64, ptr %slot1506, align 8
  %v7997 = load i64, ptr %slot1503, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v7996, i64 %v7997) nomerge, !dbg !196
  br label %bb_rcslotdone2302
bb_rcslotowner2302:
  %v7998 = load i64, ptr %slot66, align 8
  store i64 %v7998, ptr %slot1507, align 8
  %v7999 = load i64, ptr %slot1507, align 8
  %v8000 = load i64, ptr %slot1503, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v7999, i64 %v8000) nomerge, !dbg !196
  br label %bb_rcslotdone2302
bb_rcslotdone2302:
  %v8001 = load i64, ptr %slot5, align 8
  %p8002 = inttoptr i64 %v8001 to ptr
  %ld8003 = load i32, ptr %p8002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8003, ptr %slot1508, align 8
  %v8004 = load i32, ptr %slot1508, align 8
  %cv8005 = zext i32 %v8004 to i64
  %cond8006 = icmp ne i64 %cv8005, 0
  br i1 %cond8006, label %bb_rcslotdrop2385, label %bb_rcslotdone2385
bb_rcslotdrop2385:
  %v8007 = load i64, ptr %slot5, align 8
  %p8008 = inttoptr i64 %v8007 to ptr
  store i32 0, ptr %p8008, align 4, !alias.scope !3, !noalias !4
  %v8009 = load i64, ptr %slot39, align 8
  store i64 %v8009, ptr %slot1509, align 8
  %v8010 = load i64, ptr %slot6, align 8
  %p8011 = inttoptr i64 %v8010 to ptr
  %ld8012 = load i32, ptr %p8011, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8012, ptr %slot1510, align 8
  %v8013 = load i32, ptr %slot1510, align 8
  %op8014 = and i32 %v8013, 28
  store i32 %op8014, ptr %slot1511, align 8
  %v8015 = load i32, ptr %slot1511, align 8
  %cv8016 = zext i32 %v8015 to i64
  %cond8017 = icmp ne i64 %cv8016, 0
  br i1 %cond8017, label %bb_rcslotrole2385, label %bb_rcslotowner2385
bb_rcslotrole2385:
  %v8018 = load i64, ptr %slot66, align 8
  store i64 %v8018, ptr %slot1512, align 8
  %v8019 = load i64, ptr %slot1512, align 8
  %v8020 = load i64, ptr %slot1509, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v8019, i64 %v8020) nomerge, !dbg !196
  br label %bb_rcslotdone2385
bb_rcslotowner2385:
  %v8021 = load i64, ptr %slot66, align 8
  store i64 %v8021, ptr %slot1513, align 8
  %v8022 = load i64, ptr %slot1513, align 8
  %v8023 = load i64, ptr %slot1509, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v8022, i64 %v8023) nomerge, !dbg !196
  br label %bb_rcslotdone2385
bb_rcslotdone2385:
  %v8024 = load i64, ptr %slot1469, align 8
  ret i64 %v8024
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_7240c91ead2f85c7eb63a02228e06d80f417083f74f470faac795d8bd3f4708d = external global i8, align 8
@myl_native_list_header_type = external global i8, align 8
@myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2 = external global i8, align 8
@myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_05fc0e6538ca8f4b665e96a95caffae09d28186d2951c07629014719c7522651(i64, i64, i64)
declare void @myl_f_22a8b04580f16a66c0e3f26be74bb0c68889fdbf3c631d6ce7353ae8747293c0(ptr sret([24 x i8]) align 8, i64, i64)
declare i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64, i64, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_drop(i64, i64)
declare void @myl_t_10ba51025942802e98cbdad911475b594471021f660d3c2b48989b42d51368d2_rcg_unloan(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_loan(i64, i64, i64)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_drop(i64, i64)
declare void @myl_t_55d899cc13d2b2529fe8d57434403898471922197fb6b0ac279fb982f51ebdda_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_loan(i64, i64, i64)
declare i32 @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_list_set(i64, i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_loan(i64, i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11}
!11 = distinct !{!11, !0, !"element 88v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f", linkageName: "myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 13825451060386814108, i64 0, !"myl_f_0d4564642f743d8f76f6c8cc057ea8c996ea21350aea649a2de73058dbe4a77f"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!122 = !DILocation(line: 12, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!124 = !DILocation(line: 14, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!126 = !DILocation(line: 17, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!128 = !DILocation(line: 26, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!130 = !DILocation(line: 28, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!132 = !DILocation(line: 31, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!134 = !DILocation(line: 32, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!136 = !DILocation(line: 33, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!138 = !DILocation(line: 35, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!140 = !DILocation(line: 37, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!142 = !DILocation(line: 39, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!144 = !DILocation(line: 42, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!146 = !DILocation(line: 44, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!148 = !DILocation(line: 45, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!150 = !DILocation(line: 46, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!152 = !DILocation(line: 47, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!154 = !DILocation(line: 48, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!156 = !DILocation(line: 52, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!158 = !DILocation(line: 54, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646975)
!160 = !DILocation(line: 55, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!162 = !DILocation(line: 63, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647055)
!164 = !DILocation(line: 65, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647087)
!166 = !DILocation(line: 69, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!168 = !DILocation(line: 70, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!170 = !DILocation(line: 73, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!172 = !DILocation(line: 74, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!174 = !DILocation(line: 75, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!176 = !DILocation(line: 76, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!178 = !DILocation(line: 78, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!180 = !DILocation(line: 79, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647175)
!182 = !DILocation(line: 80, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!184 = !DILocation(line: 82, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647247)
!186 = !DILocation(line: 89, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647263)
!188 = !DILocation(line: 91, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!190 = !DILocation(line: 96, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647367)
!192 = !DILocation(line: 104, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!194 = !DILocation(line: 107, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647407)
!196 = !DILocation(line: 109, column: 0, scope: !197)
