target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_bf0431d3d9e553eacefcb10ebb00251bb8b43354cc87fd12c99ceb5644f705d6(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i32, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i32, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i32, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i32, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i32, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i32, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i32, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i32, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i32, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i32, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i32, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i32, align 8
  %slot483 = alloca i32, align 8
  %slot484 = alloca i64, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i32, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i32, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i32, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i32, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i64, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i32, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i32, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i32, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i32, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i32, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i32, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i32, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i32, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i32, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i32, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i32, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i32, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i32, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i32, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i32, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i32, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i32, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i32, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i32, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i32, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i32, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i32, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i32, align 8
  %slot986 = alloca i32, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i32, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i32, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i32, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i32, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i32, align 8
  %slot1084 = alloca i32, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i32, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i32, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i32, align 8
  %slot1119 = alloca i32, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i32, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i32, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i32, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i32, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i32, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i32, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i64, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i64, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i32, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i64, align 8
  %slot1175 = alloca i32, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i32, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i32, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i32, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i32, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i32, align 8
  %slot1200 = alloca i32, align 8
  %slot1201 = alloca i32, align 8
  %slot1202 = alloca i32, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i32, align 8
  %slot1208 = alloca i32, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i32, align 8
  %slot1217 = alloca i32, align 8
  %slot1218 = alloca i32, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i32, align 8
  %slot1221 = alloca i32, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i32, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i32, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i64, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i32, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i64, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i32, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i32, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i64, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i32, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i32, align 8
  %slot1265 = alloca i64, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i32, align 8
  %slot1268 = alloca i32, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i32, align 8
  %slot1271 = alloca i32, align 8
  %slot1272 = alloca i64, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i32, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i64, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i32, align 8
  %slot1279 = alloca i64, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i32, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i32, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i32, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i64, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i32, align 8
  %slot1297 = alloca i64, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i64, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i32, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i32, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i32, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i32, align 8
  %slot1332 = alloca i32, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i64, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i32, align 8
  %slot1341 = alloca i32, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i32, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i32, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i32, align 8
  %slot1359 = alloca i32, align 8
  %slot1360 = alloca i32, align 8
  %slot1361 = alloca i32, align 8
  %slot1362 = alloca i32, align 8
  %slot1363 = alloca i64, align 8
  %slot1364 = alloca i32, align 8
  %slot1365 = alloca i32, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i32, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i64, align 8
  %slot1372 = alloca i32, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i32, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i32, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i32, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i32, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i32, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i64, align 8
  %slot1393 = alloca i32, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i64, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i32, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i32, align 8
  %slot1403 = alloca i32, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i64, align 8
  %slot1408 = alloca i32, align 8
  %slot1409 = alloca i32, align 8
  %slot1410 = alloca i32, align 8
  %slot1411 = alloca i64, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i32, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i32, align 8
  %slot1418 = alloca i32, align 8
  %slot1419 = alloca i32, align 8
  %slot1420 = alloca i32, align 8
  %slot1421 = alloca i64, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i32, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i32, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i32, align 8
  %slot1433 = alloca i32, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i32, align 8
  %slot1436 = alloca i32, align 8
  %slot1437 = alloca i32, align 8
  %slot1438 = alloca i32, align 8
  %slot1439 = alloca i32, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i32, align 8
  %slot1442 = alloca i32, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i64, align 8
  %slot1445 = alloca i32, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i64, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i32, align 8
  %slot1450 = alloca i64, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i32, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i32, align 8
  %slot1457 = alloca i64, align 8
  %slot1458 = alloca i64, align 8
  %slot1459 = alloca i32, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i64, align 8
  %slot1463 = alloca i32, align 8
  %slot1464 = alloca i64, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i64, align 8
  %slot1467 = alloca i32, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i32, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i64, align 8
  %slot1474 = alloca i64, align 8
  %slot1475 = alloca i64, align 8
  %slot1476 = alloca i64, align 8
  %slot1477 = alloca i32, align 8
  %slot1478 = alloca i32, align 8
  %slot1479 = alloca i32, align 8
  %slot1480 = alloca i32, align 8
  %slot1481 = alloca i64, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i64, align 8
  %slot1485 = alloca i32, align 8
  %slot1486 = alloca i32, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i32, align 8
  %slot1491 = alloca i64, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i32, align 8
  %slot1495 = alloca i32, align 8
  %slot1496 = alloca i32, align 8
  %slot1497 = alloca i32, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i64, align 8
  %slot1501 = alloca i32, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i64, align 8
  %slot1505 = alloca i32, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i32, align 8
  %slot1510 = alloca i32, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i32, align 8
  %slot1513 = alloca i32, align 8
  %slot1514 = alloca i32, align 8
  %slot1515 = alloca i32, align 8
  %slot1516 = alloca i32, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i32, align 8
  %slot1519 = alloca i32, align 8
  %slot1520 = alloca i64, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i32, align 8
  %slot1523 = alloca i64, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i32, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i64, align 8
  %slot1529 = alloca i64, align 8
  %slot1530 = alloca i32, align 8
  %slot1531 = alloca i64, align 8
  %slot1532 = alloca i64, align 8
  %slot1533 = alloca i32, align 8
  %slot1534 = alloca i64, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i32, align 8
  %slot1537 = alloca i64, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i64, align 8
  %slot1540 = alloca i32, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i64, align 8
  %slot1544 = alloca i32, align 8
  %slot1545 = alloca i64, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i32, align 8
  %slot1548 = alloca i64, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i64, align 8
  %slot1551 = alloca i64, align 8
  %slot1552 = alloca i64, align 8
  %slot1553 = alloca i64, align 8
  %slot1554 = alloca i64, align 8
  %slot1555 = alloca i64, align 8
  %slot1556 = alloca i64, align 8
  %slot1557 = alloca i64, align 8
  %slot1558 = alloca i64, align 8
  %slot1559 = alloca i64, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i64, align 8
  %slot1562 = alloca i64, align 8
  %slot1563 = alloca i32, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i64, align 8
  %slot1566 = alloca i64, align 8
  %slot1567 = alloca i32, align 8
  %slot1568 = alloca i64, align 8
  %slot1569 = alloca i64, align 8
  %slot1570 = alloca i32, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i64, align 8
  %slot1573 = alloca i64, align 8
  %slot1574 = alloca i32, align 8
  %slot1575 = alloca i64, align 8
  %slot1576 = alloca i64, align 8
  %slot1577 = alloca i32, align 8
  %slot1578 = alloca i64, align 8
  %slot1579 = alloca i64, align 8
  %slot1580 = alloca i64, align 8
  %slot1581 = alloca i32, align 8
  %slot1582 = alloca i64, align 8
  %slot1583 = alloca i64, align 8
  %slot1584 = alloca i64, align 8
  %slot1585 = alloca i64, align 8
  %slot1586 = alloca i32, align 8
  %slot1587 = alloca i32, align 8
  %slot1588 = alloca i32, align 8
  %slot1589 = alloca i64, align 8
  %slot1590 = alloca i32, align 8
  %slot1591 = alloca i64, align 8
  %slot1592 = alloca i32, align 8
  %slot1593 = alloca i32, align 8
  %slot1594 = alloca i64, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i32, align 8
  %slot1597 = alloca i64, align 8
  %slot1598 = alloca i32, align 8
  %slot1599 = alloca i32, align 8
  %slot1600 = alloca i64, align 8
  %slot1601 = alloca i64, align 8
  %slot1602 = alloca i32, align 8
  %slot1603 = alloca i64, align 8
  %slot1604 = alloca i64, align 8
  %slot1605 = alloca i64, align 8
  %slot1606 = alloca i32, align 8
  %slot1607 = alloca i64, align 8
  %slot1608 = alloca i64, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i32, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i64, align 8
  %slot1613 = alloca i32, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i64, align 8
  %slot1616 = alloca i32, align 8
  %slot1617 = alloca i64, align 8
  %slot1618 = alloca i64, align 8
  %slot1619 = alloca i64, align 8
  %slot1620 = alloca i32, align 8
  %slot1621 = alloca i64, align 8
  %slot1622 = alloca i64, align 8
  %slot1623 = alloca i64, align 8
  %slot1624 = alloca i32, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i64, align 8
  %slot1627 = alloca i32, align 8
  %slot1628 = alloca i32, align 8
  %slot1629 = alloca i64, align 8
  %slot1630 = alloca i32, align 8
  %slot1631 = alloca i32, align 8
  %slot1632 = alloca i64, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i32, align 8
  %slot1635 = alloca i64, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i64, align 8
  %slot1638 = alloca i32, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i64, align 8
  %slot1641 = alloca i64, align 8
  %slot1642 = alloca i32, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i64, align 8
  %slot1645 = alloca i32, align 8
  %slot1646 = alloca i64, align 8
  %slot1647 = alloca i64, align 8
  %slot1648 = alloca i32, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i64, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i32, align 8
  %slot1653 = alloca i64, align 8
  %slot1654 = alloca i64, align 8
  %slot1655 = alloca i64, align 8
  %slot1656 = alloca i32, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i64, align 8
  %slot1659 = alloca i32, align 8
  %slot1660 = alloca i32, align 8
  %slot1661 = alloca i64, align 8
  %slot1662 = alloca i32, align 8
  %slot1663 = alloca i32, align 8
  %slot1664 = alloca i64, align 8
  %slot1665 = alloca i64, align 8
  %slot1666 = alloca i32, align 8
  %slot1667 = alloca i64, align 8
  %slot1668 = alloca i64, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i32, align 8
  %slot1671 = alloca i64, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i64, align 8
  %slot1674 = alloca i32, align 8
  %slot1675 = alloca i64, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i32, align 8
  %slot1678 = alloca i64, align 8
  %slot1679 = alloca i64, align 8
  %slot1680 = alloca i32, align 8
  %slot1681 = alloca i64, align 8
  %slot1682 = alloca i64, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i32, align 8
  %slot1685 = alloca i64, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i64, align 8
  %slot1688 = alloca i32, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1692 = load i64, ptr %slot1, align 8
  %op1693 = add i64 %v1692, 32
  store i64 %op1693, ptr %slot4, align 8
  %mem1694 = alloca i8, i64 40, align 8
  %ptr1695 = ptrtoint ptr %mem1694 to i64
  store i64 %ptr1695, ptr %slot5, align 8
  %mem1696 = alloca i8, i64 8, align 8
  %ptr1697 = ptrtoint ptr %mem1696 to i64
  store i64 %ptr1697, ptr %slot6, align 8
  %mem1698 = alloca i8, i64 8, align 8
  %ptr1699 = ptrtoint ptr %mem1698 to i64
  store i64 %ptr1699, ptr %slot7, align 8
  %mem1700 = alloca i8, i64 8, align 8
  %ptr1701 = ptrtoint ptr %mem1700 to i64
  store i64 %ptr1701, ptr %slot8, align 8
  %mem1702 = alloca i8, i64 8, align 8
  %ptr1703 = ptrtoint ptr %mem1702 to i64
  store i64 %ptr1703, ptr %slot9, align 8
  %mem1704 = alloca i8, i64 8, align 8
  %ptr1705 = ptrtoint ptr %mem1704 to i64
  store i64 %ptr1705, ptr %slot10, align 8
  %mem1706 = alloca i8, i64 8, align 8
  %ptr1707 = ptrtoint ptr %mem1706 to i64
  store i64 %ptr1707, ptr %slot11, align 8
  %mem1708 = alloca i8, i64 8, align 8
  %ptr1709 = ptrtoint ptr %mem1708 to i64
  store i64 %ptr1709, ptr %slot12, align 8
  %mem1710 = alloca i8, i64 8, align 8
  %ptr1711 = ptrtoint ptr %mem1710 to i64
  store i64 %ptr1711, ptr %slot13, align 8
  %mem1712 = alloca i8, i64 8, align 8
  %ptr1713 = ptrtoint ptr %mem1712 to i64
  store i64 %ptr1713, ptr %slot14, align 8
  %mem1714 = alloca i8, i64 8, align 8
  %ptr1715 = ptrtoint ptr %mem1714 to i64
  store i64 %ptr1715, ptr %slot15, align 8
  %mem1716 = alloca i8, i64 8, align 8
  %ptr1717 = ptrtoint ptr %mem1716 to i64
  store i64 %ptr1717, ptr %slot16, align 8
  %mem1718 = alloca i8, i64 8, align 8
  %ptr1719 = ptrtoint ptr %mem1718 to i64
  store i64 %ptr1719, ptr %slot17, align 8
  %mem1720 = alloca i8, i64 8, align 8
  %ptr1721 = ptrtoint ptr %mem1720 to i64
  store i64 %ptr1721, ptr %slot18, align 8
  %mem1722 = alloca i8, i64 8, align 8
  %ptr1723 = ptrtoint ptr %mem1722 to i64
  store i64 %ptr1723, ptr %slot19, align 8
  %mem1724 = alloca i8, i64 8, align 8
  %ptr1725 = ptrtoint ptr %mem1724 to i64
  store i64 %ptr1725, ptr %slot20, align 8
  %mem1726 = alloca i8, i64 208, align 8
  %ptr1727 = ptrtoint ptr %mem1726 to i64
  store i64 %ptr1727, ptr %slot21, align 8
  %mem1728 = alloca i8, i64 48, align 8
  %ptr1729 = ptrtoint ptr %mem1728 to i64
  store i64 %ptr1729, ptr %slot22, align 8
  %mem1730 = alloca i8, i64 16, align 8
  %ptr1731 = ptrtoint ptr %mem1730 to i64
  store i64 %ptr1731, ptr %slot23, align 8
  %mem1732 = alloca i8, i64 8, align 8
  %ptr1733 = ptrtoint ptr %mem1732 to i64
  store i64 %ptr1733, ptr %slot24, align 8
  %mem1734 = alloca i8, i64 8, align 8
  %ptr1735 = ptrtoint ptr %mem1734 to i64
  store i64 %ptr1735, ptr %slot25, align 8
  %mem1736 = alloca i8, i64 8, align 8
  %ptr1737 = ptrtoint ptr %mem1736 to i64
  store i64 %ptr1737, ptr %slot26, align 8
  %mem1738 = alloca i8, i64 208, align 8
  %ptr1739 = ptrtoint ptr %mem1738 to i64
  store i64 %ptr1739, ptr %slot27, align 8
  %mem1740 = alloca i8, i64 8, align 8
  %ptr1741 = ptrtoint ptr %mem1740 to i64
  store i64 %ptr1741, ptr %slot28, align 8
  %mem1742 = alloca i8, i64 8, align 8
  %ptr1743 = ptrtoint ptr %mem1742 to i64
  store i64 %ptr1743, ptr %slot29, align 8
  %mem1744 = alloca i8, i64 8, align 8
  %ptr1745 = ptrtoint ptr %mem1744 to i64
  store i64 %ptr1745, ptr %slot30, align 8
  %mem1746 = alloca i8, i64 8, align 8
  %ptr1747 = ptrtoint ptr %mem1746 to i64
  store i64 %ptr1747, ptr %slot31, align 8
  %mem1748 = alloca i8, i64 16, align 8
  %ptr1749 = ptrtoint ptr %mem1748 to i64
  store i64 %ptr1749, ptr %slot32, align 8
  %mem1750 = alloca i8, i64 8, align 8
  %ptr1751 = ptrtoint ptr %mem1750 to i64
  store i64 %ptr1751, ptr %slot33, align 8
  %mem1752 = alloca i8, i64 8, align 8
  %ptr1753 = ptrtoint ptr %mem1752 to i64
  store i64 %ptr1753, ptr %slot34, align 8
  %mem1754 = alloca i8, i64 48, align 8
  %ptr1755 = ptrtoint ptr %mem1754 to i64
  store i64 %ptr1755, ptr %slot35, align 8
  %mem1756 = alloca i8, i64 8, align 8
  %ptr1757 = ptrtoint ptr %mem1756 to i64
  store i64 %ptr1757, ptr %slot36, align 8
  %mem1758 = alloca i8, i64 8, align 8
  %ptr1759 = ptrtoint ptr %mem1758 to i64
  store i64 %ptr1759, ptr %slot37, align 8
  %mem1760 = alloca i8, i64 8, align 8
  %ptr1761 = ptrtoint ptr %mem1760 to i64
  store i64 %ptr1761, ptr %slot38, align 8
  %mem1762 = alloca i8, i64 8, align 8
  %ptr1763 = ptrtoint ptr %mem1762 to i64
  store i64 %ptr1763, ptr %slot39, align 8
  %mem1764 = alloca i8, i64 8, align 8
  %ptr1765 = ptrtoint ptr %mem1764 to i64
  store i64 %ptr1765, ptr %slot40, align 8
  %mem1766 = alloca i8, i64 8, align 8
  %ptr1767 = ptrtoint ptr %mem1766 to i64
  store i64 %ptr1767, ptr %slot41, align 8
  %mem1768 = alloca i8, i64 8, align 8
  %ptr1769 = ptrtoint ptr %mem1768 to i64
  store i64 %ptr1769, ptr %slot42, align 8
  %mem1770 = alloca i8, i64 8, align 8
  %ptr1771 = ptrtoint ptr %mem1770 to i64
  store i64 %ptr1771, ptr %slot43, align 8
  %mem1772 = alloca i8, i64 40, align 8
  %ptr1773 = ptrtoint ptr %mem1772 to i64
  store i64 %ptr1773, ptr %slot44, align 8
  %mem1774 = alloca i8, i64 40, align 8
  %ptr1775 = ptrtoint ptr %mem1774 to i64
  store i64 %ptr1775, ptr %slot45, align 8
  %v1776 = load i64, ptr %slot30, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  store i64 0, ptr %p1777, align 8, !alias.scope !3, !noalias !4
  %v1778 = load i64, ptr %slot33, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i64 0, ptr %p1779, align 8, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot36, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  store i64 0, ptr %p1781, align 8, !alias.scope !3, !noalias !4
  %v1782 = load i64, ptr %slot37, align 8
  %p1783 = inttoptr i64 %v1782 to ptr
  store i64 0, ptr %p1783, align 8, !alias.scope !3, !noalias !4
  %v1784 = load i64, ptr %slot38, align 8
  %p1785 = inttoptr i64 %v1784 to ptr
  store i64 0, ptr %p1785, align 8, !alias.scope !3, !noalias !4
  %v1786 = load i64, ptr %slot2, align 8
  %v1787 = load i64, ptr %slot28, align 8
  %p1788 = inttoptr i64 %v1787 to ptr
  store i64 %v1786, ptr %p1788, align 8, !alias.scope !3, !noalias !4
  %v1789 = load i64, ptr %slot3, align 8
  %v1790 = load i64, ptr %slot29, align 8
  %p1791 = inttoptr i64 %v1790 to ptr
  store i64 %v1789, ptr %p1791, align 8, !alias.scope !3, !noalias !4
  %v1792 = load i64, ptr %slot1, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %call1794 = call ptr @myl_qbe_heap(ptr %p1793) nomerge, !dbg !110
  %calladdr1795 = ptrtoint ptr %call1794 to i64
  store i64 %calladdr1795, ptr %slot46, align 8
  %v1796 = load i64, ptr %slot1, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  %call1798 = call i64 @myl_qbe_region_mark(ptr %p1797) nomerge, !dbg !110
  store i64 %call1798, ptr %slot47, align 8
  %v1799 = load i64, ptr %slot6, align 8
  %p1800 = inttoptr i64 %v1799 to ptr
  store i32 0, ptr %p1800, align 4, !alias.scope !3, !noalias !4
  %v1801 = load i64, ptr %slot7, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  store i32 0, ptr %p1802, align 4, !alias.scope !3, !noalias !4
  %v1803 = load i64, ptr %slot8, align 8
  %p1804 = inttoptr i64 %v1803 to ptr
  store i32 0, ptr %p1804, align 4, !alias.scope !3, !noalias !4
  %v1805 = load i64, ptr %slot9, align 8
  %p1806 = inttoptr i64 %v1805 to ptr
  store i32 0, ptr %p1806, align 4, !alias.scope !3, !noalias !4
  %v1807 = load i64, ptr %slot10, align 8
  %p1808 = inttoptr i64 %v1807 to ptr
  store i32 0, ptr %p1808, align 4, !alias.scope !3, !noalias !4
  %v1809 = load i64, ptr %slot11, align 8
  %p1810 = inttoptr i64 %v1809 to ptr
  store i32 0, ptr %p1810, align 4, !alias.scope !3, !noalias !4
  %v1811 = load i64, ptr %slot12, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  store i32 0, ptr %p1812, align 4, !alias.scope !3, !noalias !4
  %v1813 = load i64, ptr %slot13, align 8
  %p1814 = inttoptr i64 %v1813 to ptr
  store i32 0, ptr %p1814, align 4, !alias.scope !3, !noalias !4
  %v1815 = load i64, ptr %slot14, align 8
  %p1816 = inttoptr i64 %v1815 to ptr
  store i32 0, ptr %p1816, align 4, !alias.scope !3, !noalias !4
  %v1817 = load i64, ptr %slot15, align 8
  %p1818 = inttoptr i64 %v1817 to ptr
  store i32 0, ptr %p1818, align 4, !alias.scope !3, !noalias !4
  %v1819 = load i64, ptr %slot16, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  store i32 0, ptr %p1820, align 4, !alias.scope !3, !noalias !4
  %v1821 = load i64, ptr %slot17, align 8
  %p1822 = inttoptr i64 %v1821 to ptr
  store i32 0, ptr %p1822, align 4, !alias.scope !3, !noalias !4
  %v1823 = load i64, ptr %slot18, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  store i32 0, ptr %p1824, align 4, !alias.scope !3, !noalias !4
  %v1825 = load i64, ptr %slot19, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  store i32 0, ptr %p1826, align 4, !alias.scope !3, !noalias !4
  %v1827 = load i64, ptr %slot20, align 8
  %p1828 = inttoptr i64 %v1827 to ptr
  store i32 0, ptr %p1828, align 4, !alias.scope !3, !noalias !4
  %v1829 = load i64, ptr %slot7, align 8
  %p1830 = inttoptr i64 %v1829 to ptr
  store i32 2, ptr %p1830, align 4, !alias.scope !3, !noalias !4
  %v1831 = load i64, ptr %slot9, align 8
  %p1832 = inttoptr i64 %v1831 to ptr
  store i32 2, ptr %p1832, align 4, !alias.scope !3, !noalias !4
  %v1833 = load i64, ptr %slot11, align 8
  %p1834 = inttoptr i64 %v1833 to ptr
  store i32 2, ptr %p1834, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1835 = load i64, ptr %slot28, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  %ld1837 = load i64, ptr %p1836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1837, ptr %slot48, align 8
  %v1838 = load i64, ptr %slot48, align 8
  %v1839 = load i64, ptr %slot39, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  store i64 %v1838, ptr %p1840, align 8, !alias.scope !3, !noalias !4
  %v1841 = load i64, ptr %slot39, align 8
  %p1842 = inttoptr i64 %v1841 to ptr
  %ld1843 = load i64, ptr %p1842, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1843, ptr %slot49, align 8
  %v1844 = load i64, ptr %slot49, align 8
  %op1845 = add i64 %v1844, 0
  store i64 %op1845, ptr %slot50, align 8
  %v1846 = load i64, ptr %slot50, align 8
  %p1847 = inttoptr i64 %v1846 to ptr
  %ld1848 = load i64, ptr %p1847, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1848, ptr %slot51, align 8
  %v1849 = load i64, ptr %slot51, align 8
  %v1850 = load i64, ptr %slot39, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  store i64 %v1849, ptr %p1851, align 8, !alias.scope !3, !noalias !4
  %v1852 = load i64, ptr %slot12, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  %ld1854 = load i32, ptr %p1853, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1854, ptr %slot52, align 8
  %v1855 = load i32, ptr %slot52, align 8
  %cv1856 = zext i32 %v1855 to i64
  %cond1857 = icmp ne i64 %cv1856, 0
  br i1 %cond1857, label %bb_rcslotdrop14, label %bb_rcslotdone14
bb_rcslotdrop14:
  %v1858 = load i64, ptr %slot12, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  store i32 0, ptr %p1859, align 4, !alias.scope !3, !noalias !4
  %v1860 = load i64, ptr %slot21, align 8
  store i64 %v1860, ptr %slot53, align 8
  %v1861 = load i64, ptr %slot13, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  %ld1863 = load i32, ptr %p1862, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1863, ptr %slot54, align 8
  %v1864 = load i32, ptr %slot54, align 8
  %op1865 = and i32 %v1864, 28
  store i32 %op1865, ptr %slot55, align 8
  %v1866 = load i32, ptr %slot55, align 8
  %cv1867 = zext i32 %v1866 to i64
  %cond1868 = icmp ne i64 %cv1867, 0
  br i1 %cond1868, label %bb_rcslotrole14, label %bb_rcslotowner14
bb_rcslotrole14:
  %v1869 = load i64, ptr %slot46, align 8
  store i64 %v1869, ptr %slot56, align 8
  %v1870 = load i64, ptr %slot56, align 8
  %v1871 = load i64, ptr %slot53, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1870, i64 %v1871) nomerge, !dbg !112
  br label %bb_rcslotdone14
bb_rcslotowner14:
  %v1872 = load i64, ptr %slot46, align 8
  store i64 %v1872, ptr %slot57, align 8
  %v1873 = load i64, ptr %slot57, align 8
  %v1874 = load i64, ptr %slot53, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1873, i64 %v1874) nomerge, !dbg !112
  br label %bb_rcslotdone14
bb_rcslotdone14:
  %v1875 = load i64, ptr %slot39, align 8
  %p1876 = inttoptr i64 %v1875 to ptr
  %ld1877 = load i64, ptr %p1876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1877, ptr %slot58, align 8
  %v1878 = load i64, ptr %slot58, align 8
  %v1879 = load i64, ptr %slot30, align 8
  %p1880 = inttoptr i64 %v1879 to ptr
  store i64 %v1878, ptr %p1880, align 8, !alias.scope !3, !noalias !4
  %v1881 = load i64, ptr %slot29, align 8
  %p1882 = inttoptr i64 %v1881 to ptr
  %ld1883 = load i64, ptr %p1882, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1883, ptr %slot59, align 8
  %v1884 = load i64, ptr %slot59, align 8
  %v1885 = load i64, ptr %slot39, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  store i64 %v1884, ptr %p1886, align 8, !alias.scope !3, !noalias !4
  %v1887 = load i64, ptr %slot39, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  %ld1889 = load i64, ptr %p1888, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1889, ptr %slot60, align 8
  %v1890 = load i64, ptr %slot60, align 8
  %op1891 = add i64 %v1890, 0
  store i64 %op1891, ptr %slot61, align 8
  %v1892 = load i64, ptr %slot61, align 8
  %p1893 = inttoptr i64 %v1892 to ptr
  %ld1894 = load i64, ptr %p1893, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1894, ptr %slot62, align 8
  %v1895 = load i64, ptr %slot62, align 8
  %v1896 = load i64, ptr %slot39, align 8
  %p1897 = inttoptr i64 %v1896 to ptr
  store i64 %v1895, ptr %p1897, align 8, !alias.scope !3, !noalias !4
  %v1898 = load i64, ptr %slot39, align 8
  %p1899 = inttoptr i64 %v1898 to ptr
  %ld1900 = load i64, ptr %p1899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1900, ptr %slot63, align 8
  %v1901 = load i64, ptr %slot63, align 8
  %v1902 = load i64, ptr %slot31, align 8
  %p1903 = inttoptr i64 %v1902 to ptr
  store i64 %v1901, ptr %p1903, align 8, !alias.scope !3, !noalias !4
  %v1904 = load i64, ptr %slot31, align 8
  %p1905 = inttoptr i64 %v1904 to ptr
  %ld1906 = load i64, ptr %p1905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1906, ptr %slot64, align 8
  %v1907 = load i64, ptr %slot64, align 8
  %v1908 = load i64, ptr %slot39, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  store i64 %v1907, ptr %p1909, align 8, !alias.scope !3, !noalias !4
  %v1910 = load i64, ptr %slot40, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i64 0, ptr %p1911, align 8, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot40, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  %ld1914 = load i64, ptr %p1913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1914, ptr %slot65, align 8
  %v1915 = load i64, ptr %slot39, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  %ld1917 = load i64, ptr %p1916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1917, ptr %slot66, align 8
  %v1918 = load i64, ptr %slot66, align 8
  %v1919 = load i64, ptr %slot65, align 8
  %cmp1920 = icmp slt i64 %v1918, %v1919
  %cv1921 = zext i1 %cmp1920 to i64
  store i64 %cv1921, ptr %slot67, align 8
  %v1922 = load i64, ptr %slot67, align 8
  %v1923 = load i64, ptr %slot39, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  store i64 %v1922, ptr %p1924, align 8, !alias.scope !3, !noalias !4
  %v1925 = load i64, ptr %slot39, align 8
  %p1926 = inttoptr i64 %v1925 to ptr
  %ld1927 = load i64, ptr %p1926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1927, ptr %slot68, align 8
  %v1928 = load i64, ptr %slot68, align 8
  %cond1929 = icmp ne i64 %v1928, 0
  br i1 %cond1929, label %bb_next32, label %bb_i15
bb_next32:
  %v1930 = load i64, ptr %slot30, align 8
  %p1931 = inttoptr i64 %v1930 to ptr
  %ld1932 = load i64, ptr %p1931, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1932, ptr %slot69, align 8
  %v1933 = load i64, ptr %slot69, align 8
  %op1934 = add i64 %v1933, 0
  store i64 %op1934, ptr %slot70, align 8
  %v1935 = load i64, ptr %slot70, align 8
  %p1936 = inttoptr i64 %v1935 to ptr
  %ld1937 = load i64, ptr %p1936, align 8, !alias.scope !6, !noalias !7
  store i64 %ld1937, ptr %slot71, align 8
  %v1938 = load i64, ptr %slot71, align 8
  %v1939 = load i64, ptr %slot39, align 8
  %p1940 = inttoptr i64 %v1939 to ptr
  store i64 %v1938, ptr %p1940, align 8, !alias.scope !3, !noalias !4
  %v1941 = load i64, ptr %slot39, align 8
  %p1942 = inttoptr i64 %v1941 to ptr
  %ld1943 = load i64, ptr %p1942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1943, ptr %slot72, align 8
  %v1944 = load i64, ptr %slot72, align 8
  %cmp1945 = icmp ugt i64 %v1944, 9223372036854775807
  %cv1946 = zext i1 %cmp1945 to i64
  store i64 %cv1946, ptr %slot73, align 8
  %v1947 = load i64, ptr %slot73, align 8
  %cond1948 = icmp ne i64 %v1947, 0
  br i1 %cond1948, label %bb_cast_overflow37, label %bb_cast_ok37
bb_cast_overflow37:
  %v1949 = load i64, ptr %slot1, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  %v1951 = load i64, ptr %slot72, align 8
  call void @myl_qbe_fail_cast(ptr %p1950, i64 %v1951, i64 320) nomerge, !dbg !114
  unreachable
bb_cast_ok37:
  %v1952 = load i64, ptr %slot72, align 8
  %v1953 = load i64, ptr %slot39, align 8
  %p1954 = inttoptr i64 %v1953 to ptr
  store i64 %v1952, ptr %p1954, align 8, !alias.scope !3, !noalias !4
  %v1955 = load i64, ptr %slot31, align 8
  %p1956 = inttoptr i64 %v1955 to ptr
  %ld1957 = load i64, ptr %p1956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1957, ptr %slot74, align 8
  %v1958 = load i64, ptr %slot74, align 8
  %v1959 = load i64, ptr %slot40, align 8
  %p1960 = inttoptr i64 %v1959 to ptr
  store i64 %v1958, ptr %p1960, align 8, !alias.scope !3, !noalias !4
  %v1961 = load i64, ptr %slot40, align 8
  %p1962 = inttoptr i64 %v1961 to ptr
  %ld1963 = load i64, ptr %p1962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1963, ptr %slot75, align 8
  %v1964 = load i64, ptr %slot39, align 8
  %p1965 = inttoptr i64 %v1964 to ptr
  %ld1966 = load i64, ptr %p1965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1966, ptr %slot76, align 8
  %v1967 = load i64, ptr %slot76, align 8
  %v1968 = load i64, ptr %slot75, align 8
  %ovpair1970 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v1967, i64 %v1968)
  %op1969 = extractvalue { i64, i1 } %ovpair1970, 0
  %ov1971 = extractvalue { i64, i1 } %ovpair1970, 1
  store i64 %op1969, ptr %slot77, align 8
  %v1972 = load i64, ptr %slot76, align 8
  %v1973 = load i64, ptr %slot77, align 8
  %op1974 = xor i64 %v1972, %v1973
  store i64 %op1974, ptr %slot78, align 8
  %v1975 = load i64, ptr %slot75, align 8
  %v1976 = load i64, ptr %slot77, align 8
  %op1977 = xor i64 %v1975, %v1976
  store i64 %op1977, ptr %slot79, align 8
  %v1978 = load i64, ptr %slot78, align 8
  %v1979 = load i64, ptr %slot79, align 8
  %op1980 = and i64 %v1978, %v1979
  store i64 %op1980, ptr %slot80, align 8
  %cv1981 = zext i1 %ov1971 to i64
  store i64 %cv1981, ptr %slot81, align 8
  %v1982 = load i64, ptr %slot81, align 8
  %cond1983 = icmp ne i64 %v1982, 0
  br i1 %cond1983, label %bb_overflow41, label %bb_checked41
bb_overflow41:
  %v1984 = load i64, ptr %slot1, align 8
  %p1985 = inttoptr i64 %v1984 to ptr
  %v1986 = load i64, ptr %slot76, align 8
  %v1987 = load i64, ptr %slot75, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p1985, i64 0, i64 %v1986, i64 %v1987, i64 64) nomerge, !dbg !116
  unreachable
bb_checked41:
  %v1988 = load i64, ptr %slot77, align 8
  %v1989 = load i64, ptr %slot39, align 8
  %p1990 = inttoptr i64 %v1989 to ptr
  store i64 %v1988, ptr %p1990, align 8, !alias.scope !3, !noalias !4
  %v1991 = load i64, ptr %slot39, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  %ld1993 = load i64, ptr %p1992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1993, ptr %slot82, align 8
  %v1994 = load i64, ptr %slot82, align 8
  %v1995 = load i64, ptr %slot31, align 8
  %p1996 = inttoptr i64 %v1995 to ptr
  store i64 %v1994, ptr %p1996, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_i15:
  %v1997 = load i64, ptr %slot31, align 8
  %p1998 = inttoptr i64 %v1997 to ptr
  %ld1999 = load i64, ptr %p1998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1999, ptr %slot83, align 8
  %v2000 = load i64, ptr %slot83, align 8
  %v2001 = load i64, ptr %slot39, align 8
  %p2002 = inttoptr i64 %v2001 to ptr
  store i64 %v2000, ptr %p2002, align 8, !alias.scope !3, !noalias !4
  %v2003 = load i64, ptr %slot30, align 8
  %p2004 = inttoptr i64 %v2003 to ptr
  %ld2005 = load i64, ptr %p2004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2005, ptr %slot84, align 8
  %v2006 = load i64, ptr %slot39, align 8
  %p2007 = inttoptr i64 %v2006 to ptr
  %ld2008 = load i64, ptr %p2007, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2008, ptr %slot85, align 8
  %v2009 = load i64, ptr %slot84, align 8
  %p2010 = inttoptr i64 %v2009 to ptr
  %ld2011 = load i64, ptr %p2010, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2011, ptr %slot86, align 8
  %v2012 = load i64, ptr %slot85, align 8
  %v2013 = load i64, ptr %slot86, align 8
  %cmp2014 = icmp ult i64 %v2012, %v2013
  %cv2015 = zext i1 %cmp2014 to i64
  store i64 %cv2015, ptr %slot87, align 8
  %v2016 = load i64, ptr %slot87, align 8
  %cond2017 = icmp ne i64 %v2016, 0
  br i1 %cond2017, label %bb_success53, label %bb_failed53
bb_failed53:
  %v2018 = load i64, ptr %slot1, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  %v2020 = load i64, ptr %slot85, align 8
  %v2021 = load i64, ptr %slot86, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2019, i64 %v2020, i64 %v2021) nomerge, !dbg !118
  unreachable
bb_success53:
  %v2022 = load i64, ptr %slot84, align 8
  %op2023 = add i64 %v2022, 32
  store i64 %op2023, ptr %slot88, align 8
  %v2024 = load i64, ptr %slot88, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  %ld2026 = load i64, ptr %p2025, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2026, ptr %slot89, align 8
  %v2027 = load i64, ptr %slot85, align 8
  %op2028 = mul i64 %v2027, 56
  store i64 %op2028, ptr %slot90, align 8
  %v2029 = load i64, ptr %slot89, align 8
  %v2030 = load i64, ptr %slot90, align 8
  %op2031 = add i64 %v2029, %v2030
  store i64 %op2031, ptr %slot91, align 8
  %v2032 = load i64, ptr %slot91, align 8
  %v2033 = load i64, ptr %slot39, align 8
  %p2034 = inttoptr i64 %v2033 to ptr
  store i64 %v2032, ptr %p2034, align 8, !alias.scope !3, !noalias !4
  %v2035 = load i64, ptr %slot39, align 8
  %p2036 = inttoptr i64 %v2035 to ptr
  %ld2037 = load i64, ptr %p2036, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2037, ptr %slot92, align 8
  %v2038 = load i64, ptr %slot92, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  %ld2040 = load i32, ptr %p2039, align 4, !alias.scope !12, !noalias !13
  %ext2041 = zext i32 %ld2040 to i64
  store i64 %ext2041, ptr %slot93, align 8
  %v2042 = load i64, ptr %slot93, align 8
  %cmp2043 = icmp eq i64 %v2042, 0
  %cv2044 = zext i1 %cmp2043 to i64
  store i64 %cv2044, ptr %slot94, align 8
  %v2045 = load i64, ptr %slot94, align 8
  %cond2046 = icmp ne i64 %v2045, 0
  br i1 %cond2046, label %bb_rcarm60, label %bb_rcarmnext60
bb_rcarm60:
  %v2047 = load i64, ptr %slot12, align 8
  %p2048 = inttoptr i64 %v2047 to ptr
  %ld2049 = load i32, ptr %p2048, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2049, ptr %slot95, align 8
  %v2050 = load i32, ptr %slot95, align 8
  %cv2051 = zext i32 %v2050 to i64
  %cond2052 = icmp ne i64 %cv2051, 0
  br i1 %cond2052, label %bb_rcslotdrop63, label %bb_rcslotdone63
bb_rcslotdrop63:
  %v2053 = load i64, ptr %slot12, align 8
  %p2054 = inttoptr i64 %v2053 to ptr
  store i32 0, ptr %p2054, align 4, !alias.scope !3, !noalias !4
  %v2055 = load i64, ptr %slot21, align 8
  store i64 %v2055, ptr %slot96, align 8
  %v2056 = load i64, ptr %slot13, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  %ld2058 = load i32, ptr %p2057, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2058, ptr %slot97, align 8
  %v2059 = load i32, ptr %slot97, align 8
  %op2060 = and i32 %v2059, 28
  store i32 %op2060, ptr %slot98, align 8
  %v2061 = load i32, ptr %slot98, align 8
  %cv2062 = zext i32 %v2061 to i64
  %cond2063 = icmp ne i64 %cv2062, 0
  br i1 %cond2063, label %bb_rcslotrole63, label %bb_rcslotowner63
bb_rcslotrole63:
  %v2064 = load i64, ptr %slot46, align 8
  store i64 %v2064, ptr %slot99, align 8
  %v2065 = load i64, ptr %slot99, align 8
  %v2066 = load i64, ptr %slot96, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2065, i64 %v2066) nomerge, !dbg !120
  br label %bb_rcslotdone63
bb_rcslotowner63:
  %v2067 = load i64, ptr %slot46, align 8
  store i64 %v2067, ptr %slot100, align 8
  %v2068 = load i64, ptr %slot100, align 8
  %v2069 = load i64, ptr %slot96, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2068, i64 %v2069) nomerge, !dbg !120
  br label %bb_rcslotdone63
bb_rcslotdone63:
  br label %bb_i91
bb_rcarmnext60:
  %v2070 = load i64, ptr %slot93, align 8
  %cmp2071 = icmp eq i64 %v2070, 1
  %cv2072 = zext i1 %cmp2071 to i64
  store i64 %cv2072, ptr %slot101, align 8
  %v2073 = load i64, ptr %slot101, align 8
  %cond2074 = icmp ne i64 %v2073, 0
  br i1 %cond2074, label %bb_rcarm70, label %bb_rcarmnext70
bb_rcarm70:
  %v2075 = load i64, ptr %slot12, align 8
  %p2076 = inttoptr i64 %v2075 to ptr
  %ld2077 = load i32, ptr %p2076, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2077, ptr %slot102, align 8
  %v2078 = load i32, ptr %slot102, align 8
  %cv2079 = zext i32 %v2078 to i64
  %cond2080 = icmp ne i64 %cv2079, 0
  br i1 %cond2080, label %bb_rcslotdrop73, label %bb_rcslotdone73
bb_rcslotdrop73:
  %v2081 = load i64, ptr %slot12, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  store i32 0, ptr %p2082, align 4, !alias.scope !3, !noalias !4
  %v2083 = load i64, ptr %slot21, align 8
  store i64 %v2083, ptr %slot103, align 8
  %v2084 = load i64, ptr %slot13, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  %ld2086 = load i32, ptr %p2085, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2086, ptr %slot104, align 8
  %v2087 = load i32, ptr %slot104, align 8
  %op2088 = and i32 %v2087, 28
  store i32 %op2088, ptr %slot105, align 8
  %v2089 = load i32, ptr %slot105, align 8
  %cv2090 = zext i32 %v2089 to i64
  %cond2091 = icmp ne i64 %cv2090, 0
  br i1 %cond2091, label %bb_rcslotrole73, label %bb_rcslotowner73
bb_rcslotrole73:
  %v2092 = load i64, ptr %slot46, align 8
  store i64 %v2092, ptr %slot106, align 8
  %v2093 = load i64, ptr %slot106, align 8
  %v2094 = load i64, ptr %slot103, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2093, i64 %v2094) nomerge, !dbg !120
  br label %bb_rcslotdone73
bb_rcslotowner73:
  %v2095 = load i64, ptr %slot46, align 8
  store i64 %v2095, ptr %slot107, align 8
  %v2096 = load i64, ptr %slot107, align 8
  %v2097 = load i64, ptr %slot103, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2096, i64 %v2097) nomerge, !dbg !120
  br label %bb_rcslotdone73
bb_rcslotdone73:
  br label %bb_i94
bb_rcarmnext70:
  %v2098 = load i64, ptr %slot93, align 8
  %cmp2099 = icmp eq i64 %v2098, 2
  %cv2100 = zext i1 %cmp2099 to i64
  store i64 %cv2100, ptr %slot108, align 8
  %v2101 = load i64, ptr %slot108, align 8
  %cond2102 = icmp ne i64 %v2101, 0
  br i1 %cond2102, label %bb_rcarm80, label %bb_rcarmnext80
bb_rcarm80:
  %v2103 = load i64, ptr %slot12, align 8
  %p2104 = inttoptr i64 %v2103 to ptr
  %ld2105 = load i32, ptr %p2104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2105, ptr %slot109, align 8
  %v2106 = load i32, ptr %slot109, align 8
  %cv2107 = zext i32 %v2106 to i64
  %cond2108 = icmp ne i64 %cv2107, 0
  br i1 %cond2108, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v2109 = load i64, ptr %slot12, align 8
  %p2110 = inttoptr i64 %v2109 to ptr
  store i32 0, ptr %p2110, align 4, !alias.scope !3, !noalias !4
  %v2111 = load i64, ptr %slot21, align 8
  store i64 %v2111, ptr %slot110, align 8
  %v2112 = load i64, ptr %slot13, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  %ld2114 = load i32, ptr %p2113, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2114, ptr %slot111, align 8
  %v2115 = load i32, ptr %slot111, align 8
  %op2116 = and i32 %v2115, 28
  store i32 %op2116, ptr %slot112, align 8
  %v2117 = load i32, ptr %slot112, align 8
  %cv2118 = zext i32 %v2117 to i64
  %cond2119 = icmp ne i64 %cv2118, 0
  br i1 %cond2119, label %bb_rcslotrole83, label %bb_rcslotowner83
bb_rcslotrole83:
  %v2120 = load i64, ptr %slot46, align 8
  store i64 %v2120, ptr %slot113, align 8
  %v2121 = load i64, ptr %slot113, align 8
  %v2122 = load i64, ptr %slot110, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2121, i64 %v2122) nomerge, !dbg !120
  br label %bb_rcslotdone83
bb_rcslotowner83:
  %v2123 = load i64, ptr %slot46, align 8
  store i64 %v2123, ptr %slot114, align 8
  %v2124 = load i64, ptr %slot114, align 8
  %v2125 = load i64, ptr %slot110, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2124, i64 %v2125) nomerge, !dbg !120
  br label %bb_rcslotdone83
bb_rcslotdone83:
  br label %bb_i97
bb_rcarmnext80:
  %v2126 = load i64, ptr %slot93, align 8
  %cmp2127 = icmp eq i64 %v2126, 3
  %cv2128 = zext i1 %cmp2127 to i64
  store i64 %cv2128, ptr %slot115, align 8
  %v2129 = load i64, ptr %slot115, align 8
  %cond2130 = icmp ne i64 %v2129, 0
  br i1 %cond2130, label %bb_rcarm90, label %bb_rcarmnext90
bb_rcarm90:
  %v2131 = load i64, ptr %slot12, align 8
  %p2132 = inttoptr i64 %v2131 to ptr
  %ld2133 = load i32, ptr %p2132, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2133, ptr %slot116, align 8
  %v2134 = load i32, ptr %slot116, align 8
  %cv2135 = zext i32 %v2134 to i64
  %cond2136 = icmp ne i64 %cv2135, 0
  br i1 %cond2136, label %bb_rcslotdrop93, label %bb_rcslotdone93
bb_rcslotdrop93:
  %v2137 = load i64, ptr %slot12, align 8
  %p2138 = inttoptr i64 %v2137 to ptr
  store i32 0, ptr %p2138, align 4, !alias.scope !3, !noalias !4
  %v2139 = load i64, ptr %slot21, align 8
  store i64 %v2139, ptr %slot117, align 8
  %v2140 = load i64, ptr %slot13, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %ld2142 = load i32, ptr %p2141, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2142, ptr %slot118, align 8
  %v2143 = load i32, ptr %slot118, align 8
  %op2144 = and i32 %v2143, 28
  store i32 %op2144, ptr %slot119, align 8
  %v2145 = load i32, ptr %slot119, align 8
  %cv2146 = zext i32 %v2145 to i64
  %cond2147 = icmp ne i64 %cv2146, 0
  br i1 %cond2147, label %bb_rcslotrole93, label %bb_rcslotowner93
bb_rcslotrole93:
  %v2148 = load i64, ptr %slot46, align 8
  store i64 %v2148, ptr %slot120, align 8
  %v2149 = load i64, ptr %slot120, align 8
  %v2150 = load i64, ptr %slot117, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2149, i64 %v2150) nomerge, !dbg !120
  br label %bb_rcslotdone93
bb_rcslotowner93:
  %v2151 = load i64, ptr %slot46, align 8
  store i64 %v2151, ptr %slot121, align 8
  %v2152 = load i64, ptr %slot121, align 8
  %v2153 = load i64, ptr %slot117, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2152, i64 %v2153) nomerge, !dbg !120
  br label %bb_rcslotdone93
bb_rcslotdone93:
  br label %bb_i100
bb_rcarmnext90:
  %v2154 = load i64, ptr %slot93, align 8
  %cmp2155 = icmp eq i64 %v2154, 4
  %cv2156 = zext i1 %cmp2155 to i64
  store i64 %cv2156, ptr %slot122, align 8
  %v2157 = load i64, ptr %slot122, align 8
  %cond2158 = icmp ne i64 %v2157, 0
  br i1 %cond2158, label %bb_rcarm100, label %bb_rcarmnext100
bb_rcarm100:
  %v2159 = load i64, ptr %slot92, align 8
  %op2160 = add i64 %v2159, 8
  store i64 %op2160, ptr %slot123, align 8
  %v2161 = load i64, ptr %slot123, align 8
  %v2162 = load i64, ptr %slot32, align 8
  %p2163 = inttoptr i64 %v2161 to ptr
  %p2164 = inttoptr i64 %v2162 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2164, ptr %p2163, i64 16, i1 false), !alias.scope !10000000
  %v2165 = load i64, ptr %slot12, align 8
  %p2166 = inttoptr i64 %v2165 to ptr
  %ld2167 = load i32, ptr %p2166, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2167, ptr %slot124, align 8
  %v2168 = load i32, ptr %slot124, align 8
  %cv2169 = zext i32 %v2168 to i64
  %cond2170 = icmp ne i64 %cv2169, 0
  br i1 %cond2170, label %bb_rcslotdrop114, label %bb_rcslotdone114
bb_rcslotdrop114:
  %v2171 = load i64, ptr %slot12, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  store i32 0, ptr %p2172, align 4, !alias.scope !3, !noalias !4
  %v2173 = load i64, ptr %slot21, align 8
  store i64 %v2173, ptr %slot125, align 8
  %v2174 = load i64, ptr %slot13, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  %ld2176 = load i32, ptr %p2175, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2176, ptr %slot126, align 8
  %v2177 = load i32, ptr %slot126, align 8
  %op2178 = and i32 %v2177, 28
  store i32 %op2178, ptr %slot127, align 8
  %v2179 = load i32, ptr %slot127, align 8
  %cv2180 = zext i32 %v2179 to i64
  %cond2181 = icmp ne i64 %cv2180, 0
  br i1 %cond2181, label %bb_rcslotrole114, label %bb_rcslotowner114
bb_rcslotrole114:
  %v2182 = load i64, ptr %slot46, align 8
  store i64 %v2182, ptr %slot128, align 8
  %v2183 = load i64, ptr %slot128, align 8
  %v2184 = load i64, ptr %slot125, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2183, i64 %v2184) nomerge, !dbg !120
  br label %bb_rcslotdone114
bb_rcslotowner114:
  %v2185 = load i64, ptr %slot46, align 8
  store i64 %v2185, ptr %slot129, align 8
  %v2186 = load i64, ptr %slot129, align 8
  %v2187 = load i64, ptr %slot125, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2186, i64 %v2187) nomerge, !dbg !120
  br label %bb_rcslotdone114
bb_rcslotdone114:
  br label %bb_i18
bb_rcarmnext100:
  %v2188 = load i64, ptr %slot93, align 8
  %cmp2189 = icmp eq i64 %v2188, 5
  %cv2190 = zext i1 %cmp2189 to i64
  store i64 %cv2190, ptr %slot130, align 8
  %v2191 = load i64, ptr %slot130, align 8
  %cond2192 = icmp ne i64 %v2191, 0
  br i1 %cond2192, label %bb_rcarm121, label %bb_rcarmnext121
bb_rcarm121:
  %v2193 = load i64, ptr %slot12, align 8
  %p2194 = inttoptr i64 %v2193 to ptr
  %ld2195 = load i32, ptr %p2194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2195, ptr %slot131, align 8
  %v2196 = load i32, ptr %slot131, align 8
  %cv2197 = zext i32 %v2196 to i64
  %cond2198 = icmp ne i64 %cv2197, 0
  br i1 %cond2198, label %bb_rcslotdrop124, label %bb_rcslotdone124
bb_rcslotdrop124:
  %v2199 = load i64, ptr %slot12, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  store i32 0, ptr %p2200, align 4, !alias.scope !3, !noalias !4
  %v2201 = load i64, ptr %slot21, align 8
  store i64 %v2201, ptr %slot132, align 8
  %v2202 = load i64, ptr %slot13, align 8
  %p2203 = inttoptr i64 %v2202 to ptr
  %ld2204 = load i32, ptr %p2203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2204, ptr %slot133, align 8
  %v2205 = load i32, ptr %slot133, align 8
  %op2206 = and i32 %v2205, 28
  store i32 %op2206, ptr %slot134, align 8
  %v2207 = load i32, ptr %slot134, align 8
  %cv2208 = zext i32 %v2207 to i64
  %cond2209 = icmp ne i64 %cv2208, 0
  br i1 %cond2209, label %bb_rcslotrole124, label %bb_rcslotowner124
bb_rcslotrole124:
  %v2210 = load i64, ptr %slot46, align 8
  store i64 %v2210, ptr %slot135, align 8
  %v2211 = load i64, ptr %slot135, align 8
  %v2212 = load i64, ptr %slot132, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2211, i64 %v2212) nomerge, !dbg !120
  br label %bb_rcslotdone124
bb_rcslotowner124:
  %v2213 = load i64, ptr %slot46, align 8
  store i64 %v2213, ptr %slot136, align 8
  %v2214 = load i64, ptr %slot136, align 8
  %v2215 = load i64, ptr %slot132, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2214, i64 %v2215) nomerge, !dbg !120
  br label %bb_rcslotdone124
bb_rcslotdone124:
  br label %bb_i103
bb_rcarmnext121:
  %v2216 = load i64, ptr %slot93, align 8
  %cmp2217 = icmp eq i64 %v2216, 6
  %cv2218 = zext i1 %cmp2217 to i64
  store i64 %cv2218, ptr %slot137, align 8
  %v2219 = load i64, ptr %slot137, align 8
  %cond2220 = icmp ne i64 %v2219, 0
  br i1 %cond2220, label %bb_rcarm131, label %bb_rcarmnext131
bb_rcarm131:
  %v2221 = load i64, ptr %slot12, align 8
  %p2222 = inttoptr i64 %v2221 to ptr
  %ld2223 = load i32, ptr %p2222, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2223, ptr %slot138, align 8
  %v2224 = load i32, ptr %slot138, align 8
  %cv2225 = zext i32 %v2224 to i64
  %cond2226 = icmp ne i64 %cv2225, 0
  br i1 %cond2226, label %bb_rcslotdrop134, label %bb_rcslotdone134
bb_rcslotdrop134:
  %v2227 = load i64, ptr %slot12, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  store i32 0, ptr %p2228, align 4, !alias.scope !3, !noalias !4
  %v2229 = load i64, ptr %slot21, align 8
  store i64 %v2229, ptr %slot139, align 8
  %v2230 = load i64, ptr %slot13, align 8
  %p2231 = inttoptr i64 %v2230 to ptr
  %ld2232 = load i32, ptr %p2231, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2232, ptr %slot140, align 8
  %v2233 = load i32, ptr %slot140, align 8
  %op2234 = and i32 %v2233, 28
  store i32 %op2234, ptr %slot141, align 8
  %v2235 = load i32, ptr %slot141, align 8
  %cv2236 = zext i32 %v2235 to i64
  %cond2237 = icmp ne i64 %cv2236, 0
  br i1 %cond2237, label %bb_rcslotrole134, label %bb_rcslotowner134
bb_rcslotrole134:
  %v2238 = load i64, ptr %slot46, align 8
  store i64 %v2238, ptr %slot142, align 8
  %v2239 = load i64, ptr %slot142, align 8
  %v2240 = load i64, ptr %slot139, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2239, i64 %v2240) nomerge, !dbg !120
  br label %bb_rcslotdone134
bb_rcslotowner134:
  %v2241 = load i64, ptr %slot46, align 8
  store i64 %v2241, ptr %slot143, align 8
  %v2242 = load i64, ptr %slot143, align 8
  %v2243 = load i64, ptr %slot139, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2242, i64 %v2243) nomerge, !dbg !120
  br label %bb_rcslotdone134
bb_rcslotdone134:
  br label %bb_i106
bb_rcarmnext131:
  %v2244 = load i64, ptr %slot93, align 8
  %cmp2245 = icmp eq i64 %v2244, 7
  %cv2246 = zext i1 %cmp2245 to i64
  store i64 %cv2246, ptr %slot144, align 8
  %v2247 = load i64, ptr %slot144, align 8
  %cond2248 = icmp ne i64 %v2247, 0
  br i1 %cond2248, label %bb_rcarm141, label %bb_rcarmnext141
bb_rcarm141:
  %v2249 = load i64, ptr %slot12, align 8
  %p2250 = inttoptr i64 %v2249 to ptr
  %ld2251 = load i32, ptr %p2250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2251, ptr %slot145, align 8
  %v2252 = load i32, ptr %slot145, align 8
  %cv2253 = zext i32 %v2252 to i64
  %cond2254 = icmp ne i64 %cv2253, 0
  br i1 %cond2254, label %bb_rcslotdrop144, label %bb_rcslotdone144
bb_rcslotdrop144:
  %v2255 = load i64, ptr %slot12, align 8
  %p2256 = inttoptr i64 %v2255 to ptr
  store i32 0, ptr %p2256, align 4, !alias.scope !3, !noalias !4
  %v2257 = load i64, ptr %slot21, align 8
  store i64 %v2257, ptr %slot146, align 8
  %v2258 = load i64, ptr %slot13, align 8
  %p2259 = inttoptr i64 %v2258 to ptr
  %ld2260 = load i32, ptr %p2259, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2260, ptr %slot147, align 8
  %v2261 = load i32, ptr %slot147, align 8
  %op2262 = and i32 %v2261, 28
  store i32 %op2262, ptr %slot148, align 8
  %v2263 = load i32, ptr %slot148, align 8
  %cv2264 = zext i32 %v2263 to i64
  %cond2265 = icmp ne i64 %cv2264, 0
  br i1 %cond2265, label %bb_rcslotrole144, label %bb_rcslotowner144
bb_rcslotrole144:
  %v2266 = load i64, ptr %slot46, align 8
  store i64 %v2266, ptr %slot149, align 8
  %v2267 = load i64, ptr %slot149, align 8
  %v2268 = load i64, ptr %slot146, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2267, i64 %v2268) nomerge, !dbg !120
  br label %bb_rcslotdone144
bb_rcslotowner144:
  %v2269 = load i64, ptr %slot46, align 8
  store i64 %v2269, ptr %slot150, align 8
  %v2270 = load i64, ptr %slot150, align 8
  %v2271 = load i64, ptr %slot146, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2270, i64 %v2271) nomerge, !dbg !120
  br label %bb_rcslotdone144
bb_rcslotdone144:
  br label %bb_i109
bb_rcarmnext141:
  %v2272 = load i64, ptr %slot93, align 8
  %cmp2273 = icmp eq i64 %v2272, 8
  %cv2274 = zext i1 %cmp2273 to i64
  store i64 %cv2274, ptr %slot151, align 8
  %v2275 = load i64, ptr %slot151, align 8
  %cond2276 = icmp ne i64 %v2275, 0
  br i1 %cond2276, label %bb_rcarm151, label %bb_rcarmnext151
bb_rcarm151:
  %v2277 = load i64, ptr %slot12, align 8
  %p2278 = inttoptr i64 %v2277 to ptr
  %ld2279 = load i32, ptr %p2278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2279, ptr %slot152, align 8
  %v2280 = load i32, ptr %slot152, align 8
  %cv2281 = zext i32 %v2280 to i64
  %cond2282 = icmp ne i64 %cv2281, 0
  br i1 %cond2282, label %bb_rcslotdrop154, label %bb_rcslotdone154
bb_rcslotdrop154:
  %v2283 = load i64, ptr %slot12, align 8
  %p2284 = inttoptr i64 %v2283 to ptr
  store i32 0, ptr %p2284, align 4, !alias.scope !3, !noalias !4
  %v2285 = load i64, ptr %slot21, align 8
  store i64 %v2285, ptr %slot153, align 8
  %v2286 = load i64, ptr %slot13, align 8
  %p2287 = inttoptr i64 %v2286 to ptr
  %ld2288 = load i32, ptr %p2287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2288, ptr %slot154, align 8
  %v2289 = load i32, ptr %slot154, align 8
  %op2290 = and i32 %v2289, 28
  store i32 %op2290, ptr %slot155, align 8
  %v2291 = load i32, ptr %slot155, align 8
  %cv2292 = zext i32 %v2291 to i64
  %cond2293 = icmp ne i64 %cv2292, 0
  br i1 %cond2293, label %bb_rcslotrole154, label %bb_rcslotowner154
bb_rcslotrole154:
  %v2294 = load i64, ptr %slot46, align 8
  store i64 %v2294, ptr %slot156, align 8
  %v2295 = load i64, ptr %slot156, align 8
  %v2296 = load i64, ptr %slot153, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2295, i64 %v2296) nomerge, !dbg !120
  br label %bb_rcslotdone154
bb_rcslotowner154:
  %v2297 = load i64, ptr %slot46, align 8
  store i64 %v2297, ptr %slot157, align 8
  %v2298 = load i64, ptr %slot157, align 8
  %v2299 = load i64, ptr %slot153, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2298, i64 %v2299) nomerge, !dbg !120
  br label %bb_rcslotdone154
bb_rcslotdone154:
  br label %bb_i112
bb_rcarmnext151:
  %v2300 = load i64, ptr %slot93, align 8
  %cmp2301 = icmp eq i64 %v2300, 9
  %cv2302 = zext i1 %cmp2301 to i64
  store i64 %cv2302, ptr %slot158, align 8
  %v2303 = load i64, ptr %slot158, align 8
  %cond2304 = icmp ne i64 %v2303, 0
  br i1 %cond2304, label %bb_rcarm161, label %bb_rcarmnext161
bb_rcarm161:
  %v2305 = load i64, ptr %slot12, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  %ld2307 = load i32, ptr %p2306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2307, ptr %slot159, align 8
  %v2308 = load i32, ptr %slot159, align 8
  %cv2309 = zext i32 %v2308 to i64
  %cond2310 = icmp ne i64 %cv2309, 0
  br i1 %cond2310, label %bb_rcslotdrop164, label %bb_rcslotdone164
bb_rcslotdrop164:
  %v2311 = load i64, ptr %slot12, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  store i32 0, ptr %p2312, align 4, !alias.scope !3, !noalias !4
  %v2313 = load i64, ptr %slot21, align 8
  store i64 %v2313, ptr %slot160, align 8
  %v2314 = load i64, ptr %slot13, align 8
  %p2315 = inttoptr i64 %v2314 to ptr
  %ld2316 = load i32, ptr %p2315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2316, ptr %slot161, align 8
  %v2317 = load i32, ptr %slot161, align 8
  %op2318 = and i32 %v2317, 28
  store i32 %op2318, ptr %slot162, align 8
  %v2319 = load i32, ptr %slot162, align 8
  %cv2320 = zext i32 %v2319 to i64
  %cond2321 = icmp ne i64 %cv2320, 0
  br i1 %cond2321, label %bb_rcslotrole164, label %bb_rcslotowner164
bb_rcslotrole164:
  %v2322 = load i64, ptr %slot46, align 8
  store i64 %v2322, ptr %slot163, align 8
  %v2323 = load i64, ptr %slot163, align 8
  %v2324 = load i64, ptr %slot160, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2323, i64 %v2324) nomerge, !dbg !120
  br label %bb_rcslotdone164
bb_rcslotowner164:
  %v2325 = load i64, ptr %slot46, align 8
  store i64 %v2325, ptr %slot164, align 8
  %v2326 = load i64, ptr %slot164, align 8
  %v2327 = load i64, ptr %slot160, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2326, i64 %v2327) nomerge, !dbg !120
  br label %bb_rcslotdone164
bb_rcslotdone164:
  br label %bb_i115
bb_rcarmnext161:
  %v2328 = load i64, ptr %slot93, align 8
  %cmp2329 = icmp eq i64 %v2328, 10
  %cv2330 = zext i1 %cmp2329 to i64
  store i64 %cv2330, ptr %slot165, align 8
  %v2331 = load i64, ptr %slot165, align 8
  %cond2332 = icmp ne i64 %v2331, 0
  br i1 %cond2332, label %bb_rcarm171, label %bb_rcarmnext171
bb_rcarm171:
  %v2333 = load i64, ptr %slot12, align 8
  %p2334 = inttoptr i64 %v2333 to ptr
  %ld2335 = load i32, ptr %p2334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2335, ptr %slot166, align 8
  %v2336 = load i32, ptr %slot166, align 8
  %cv2337 = zext i32 %v2336 to i64
  %cond2338 = icmp ne i64 %cv2337, 0
  br i1 %cond2338, label %bb_rcslotdrop174, label %bb_rcslotdone174
bb_rcslotdrop174:
  %v2339 = load i64, ptr %slot12, align 8
  %p2340 = inttoptr i64 %v2339 to ptr
  store i32 0, ptr %p2340, align 4, !alias.scope !3, !noalias !4
  %v2341 = load i64, ptr %slot21, align 8
  store i64 %v2341, ptr %slot167, align 8
  %v2342 = load i64, ptr %slot13, align 8
  %p2343 = inttoptr i64 %v2342 to ptr
  %ld2344 = load i32, ptr %p2343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2344, ptr %slot168, align 8
  %v2345 = load i32, ptr %slot168, align 8
  %op2346 = and i32 %v2345, 28
  store i32 %op2346, ptr %slot169, align 8
  %v2347 = load i32, ptr %slot169, align 8
  %cv2348 = zext i32 %v2347 to i64
  %cond2349 = icmp ne i64 %cv2348, 0
  br i1 %cond2349, label %bb_rcslotrole174, label %bb_rcslotowner174
bb_rcslotrole174:
  %v2350 = load i64, ptr %slot46, align 8
  store i64 %v2350, ptr %slot170, align 8
  %v2351 = load i64, ptr %slot170, align 8
  %v2352 = load i64, ptr %slot167, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2351, i64 %v2352) nomerge, !dbg !120
  br label %bb_rcslotdone174
bb_rcslotowner174:
  %v2353 = load i64, ptr %slot46, align 8
  store i64 %v2353, ptr %slot171, align 8
  %v2354 = load i64, ptr %slot171, align 8
  %v2355 = load i64, ptr %slot167, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2354, i64 %v2355) nomerge, !dbg !120
  br label %bb_rcslotdone174
bb_rcslotdone174:
  br label %bb_i118
bb_rcarmnext171:
  br label %bb_failure
bb_i18:
  %v2356 = load i64, ptr %slot32, align 8
  %v2357 = load i64, ptr %slot39, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i64 %v2356, ptr %p2358, align 8, !alias.scope !3, !noalias !4
  %v2359 = load i64, ptr %slot28, align 8
  %p2360 = inttoptr i64 %v2359 to ptr
  %ld2361 = load i64, ptr %p2360, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2361, ptr %slot172, align 8
  %v2362 = load i64, ptr %slot172, align 8
  %v2363 = load i64, ptr %slot39, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  store i64 %v2362, ptr %p2364, align 8, !alias.scope !3, !noalias !4
  %v2365 = load i64, ptr %slot39, align 8
  %p2366 = inttoptr i64 %v2365 to ptr
  %ld2367 = load i64, ptr %p2366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2367, ptr %slot173, align 8
  %v2368 = load i64, ptr %slot173, align 8
  %op2369 = add i64 %v2368, 0
  store i64 %op2369, ptr %slot174, align 8
  %v2370 = load i64, ptr %slot174, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  %ld2372 = load i64, ptr %p2371, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2372, ptr %slot175, align 8
  %v2373 = load i64, ptr %slot175, align 8
  %v2374 = load i64, ptr %slot39, align 8
  %p2375 = inttoptr i64 %v2374 to ptr
  store i64 %v2373, ptr %p2375, align 8, !alias.scope !3, !noalias !4
  %v2376 = load i64, ptr %slot12, align 8
  %p2377 = inttoptr i64 %v2376 to ptr
  %ld2378 = load i32, ptr %p2377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2378, ptr %slot176, align 8
  %v2379 = load i32, ptr %slot176, align 8
  %cv2380 = zext i32 %v2379 to i64
  %cond2381 = icmp ne i64 %cv2380, 0
  br i1 %cond2381, label %bb_rcslotdrop187, label %bb_rcslotdone187
bb_rcslotdrop187:
  %v2382 = load i64, ptr %slot12, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  store i32 0, ptr %p2383, align 4, !alias.scope !3, !noalias !4
  %v2384 = load i64, ptr %slot21, align 8
  store i64 %v2384, ptr %slot177, align 8
  %v2385 = load i64, ptr %slot13, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  %ld2387 = load i32, ptr %p2386, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2387, ptr %slot178, align 8
  %v2388 = load i32, ptr %slot178, align 8
  %op2389 = and i32 %v2388, 28
  store i32 %op2389, ptr %slot179, align 8
  %v2390 = load i32, ptr %slot179, align 8
  %cv2391 = zext i32 %v2390 to i64
  %cond2392 = icmp ne i64 %cv2391, 0
  br i1 %cond2392, label %bb_rcslotrole187, label %bb_rcslotowner187
bb_rcslotrole187:
  %v2393 = load i64, ptr %slot46, align 8
  store i64 %v2393, ptr %slot180, align 8
  %v2394 = load i64, ptr %slot180, align 8
  %v2395 = load i64, ptr %slot177, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2394, i64 %v2395) nomerge, !dbg !122
  br label %bb_rcslotdone187
bb_rcslotowner187:
  %v2396 = load i64, ptr %slot46, align 8
  store i64 %v2396, ptr %slot181, align 8
  %v2397 = load i64, ptr %slot181, align 8
  %v2398 = load i64, ptr %slot177, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2397, i64 %v2398) nomerge, !dbg !122
  br label %bb_rcslotdone187
bb_rcslotdone187:
  %v2399 = load i64, ptr %slot39, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %ld2401 = load i64, ptr %p2400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2401, ptr %slot182, align 8
  %v2402 = load i64, ptr %slot182, align 8
  %v2403 = load i64, ptr %slot33, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  store i64 %v2402, ptr %p2404, align 8, !alias.scope !3, !noalias !4
  %v2405 = load i64, ptr %slot32, align 8
  %v2406 = load i64, ptr %slot39, align 8
  %p2407 = inttoptr i64 %v2406 to ptr
  store i64 %v2405, ptr %p2407, align 8, !alias.scope !3, !noalias !4
  %v2408 = load i64, ptr %slot39, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  %ld2410 = load i64, ptr %p2409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2410, ptr %slot183, align 8
  %v2411 = load i64, ptr %slot183, align 8
  %op2412 = add i64 %v2411, 0
  store i64 %op2412, ptr %slot184, align 8
  %v2413 = load i64, ptr %slot184, align 8
  %p2414 = inttoptr i64 %v2413 to ptr
  %ld2415 = load i64, ptr %p2414, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2415, ptr %slot185, align 8
  %v2416 = load i64, ptr %slot185, align 8
  %v2417 = load i64, ptr %slot39, align 8
  %p2418 = inttoptr i64 %v2417 to ptr
  store i64 %v2416, ptr %p2418, align 8, !alias.scope !3, !noalias !4
  %v2419 = load i64, ptr %slot12, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  %ld2421 = load i32, ptr %p2420, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2421, ptr %slot186, align 8
  %v2422 = load i32, ptr %slot186, align 8
  %cv2423 = zext i32 %v2422 to i64
  %cond2424 = icmp ne i64 %cv2423, 0
  br i1 %cond2424, label %bb_rcslotdrop200, label %bb_rcslotdone200
bb_rcslotdrop200:
  %v2425 = load i64, ptr %slot12, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  store i32 0, ptr %p2426, align 4, !alias.scope !3, !noalias !4
  %v2427 = load i64, ptr %slot21, align 8
  store i64 %v2427, ptr %slot187, align 8
  %v2428 = load i64, ptr %slot13, align 8
  %p2429 = inttoptr i64 %v2428 to ptr
  %ld2430 = load i32, ptr %p2429, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2430, ptr %slot188, align 8
  %v2431 = load i32, ptr %slot188, align 8
  %op2432 = and i32 %v2431, 28
  store i32 %op2432, ptr %slot189, align 8
  %v2433 = load i32, ptr %slot189, align 8
  %cv2434 = zext i32 %v2433 to i64
  %cond2435 = icmp ne i64 %cv2434, 0
  br i1 %cond2435, label %bb_rcslotrole200, label %bb_rcslotowner200
bb_rcslotrole200:
  %v2436 = load i64, ptr %slot46, align 8
  store i64 %v2436, ptr %slot190, align 8
  %v2437 = load i64, ptr %slot190, align 8
  %v2438 = load i64, ptr %slot187, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v2437, i64 %v2438) nomerge, !dbg !124
  br label %bb_rcslotdone200
bb_rcslotowner200:
  %v2439 = load i64, ptr %slot46, align 8
  store i64 %v2439, ptr %slot191, align 8
  %v2440 = load i64, ptr %slot191, align 8
  %v2441 = load i64, ptr %slot187, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64 %v2440, i64 %v2441) nomerge, !dbg !124
  br label %bb_rcslotdone200
bb_rcslotdone200:
  %v2442 = load i64, ptr %slot39, align 8
  %p2443 = inttoptr i64 %v2442 to ptr
  %ld2444 = load i64, ptr %p2443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2444, ptr %slot192, align 8
  %v2445 = load i64, ptr %slot192, align 8
  %v2446 = load i64, ptr %slot34, align 8
  %p2447 = inttoptr i64 %v2446 to ptr
  store i64 %v2445, ptr %p2447, align 8, !alias.scope !3, !noalias !4
  %v2448 = load i64, ptr %slot34, align 8
  %p2449 = inttoptr i64 %v2448 to ptr
  %ld2450 = load i64, ptr %p2449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2450, ptr %slot193, align 8
  %v2451 = load i64, ptr %slot193, align 8
  %v2452 = load i64, ptr %slot39, align 8
  %p2453 = inttoptr i64 %v2452 to ptr
  store i64 %v2451, ptr %p2453, align 8, !alias.scope !3, !noalias !4
  %v2454 = load i64, ptr %slot40, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  store i64 0, ptr %p2455, align 8, !alias.scope !3, !noalias !4
  %v2456 = load i64, ptr %slot40, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  %ld2458 = load i64, ptr %p2457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2458, ptr %slot194, align 8
  %v2459 = load i64, ptr %slot39, align 8
  %p2460 = inttoptr i64 %v2459 to ptr
  %ld2461 = load i64, ptr %p2460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2461, ptr %slot195, align 8
  %v2462 = load i64, ptr %slot195, align 8
  %v2463 = load i64, ptr %slot194, align 8
  %cmp2464 = icmp slt i64 %v2462, %v2463
  %cv2465 = zext i1 %cmp2464 to i64
  store i64 %cv2465, ptr %slot196, align 8
  %v2466 = load i64, ptr %slot196, align 8
  %v2467 = load i64, ptr %slot39, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  store i64 %v2466, ptr %p2468, align 8, !alias.scope !3, !noalias !4
  %v2469 = load i64, ptr %slot39, align 8
  %p2470 = inttoptr i64 %v2469 to ptr
  %ld2471 = load i64, ptr %p2470, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2471, ptr %slot197, align 8
  %v2472 = load i64, ptr %slot197, align 8
  %cond2473 = icmp ne i64 %v2472, 0
  br i1 %cond2473, label %bb_next213, label %bb_i36
bb_next213:
  %v2474 = load i64, ptr %slot33, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  %ld2476 = load i64, ptr %p2475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2476, ptr %slot198, align 8
  %v2477 = load i64, ptr %slot198, align 8
  %op2478 = add i64 %v2477, 0
  store i64 %op2478, ptr %slot199, align 8
  %v2479 = load i64, ptr %slot199, align 8
  %p2480 = inttoptr i64 %v2479 to ptr
  %ld2481 = load i64, ptr %p2480, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2481, ptr %slot200, align 8
  %v2482 = load i64, ptr %slot200, align 8
  %v2483 = load i64, ptr %slot39, align 8
  %p2484 = inttoptr i64 %v2483 to ptr
  store i64 %v2482, ptr %p2484, align 8, !alias.scope !3, !noalias !4
  %v2485 = load i64, ptr %slot39, align 8
  %p2486 = inttoptr i64 %v2485 to ptr
  %ld2487 = load i64, ptr %p2486, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2487, ptr %slot201, align 8
  %v2488 = load i64, ptr %slot201, align 8
  %cmp2489 = icmp ugt i64 %v2488, 9223372036854775807
  %cv2490 = zext i1 %cmp2489 to i64
  store i64 %cv2490, ptr %slot202, align 8
  %v2491 = load i64, ptr %slot202, align 8
  %cond2492 = icmp ne i64 %v2491, 0
  br i1 %cond2492, label %bb_cast_overflow218, label %bb_cast_ok218
bb_cast_overflow218:
  %v2493 = load i64, ptr %slot1, align 8
  %p2494 = inttoptr i64 %v2493 to ptr
  %v2495 = load i64, ptr %slot201, align 8
  call void @myl_qbe_fail_cast(ptr %p2494, i64 %v2495, i64 320) nomerge, !dbg !126
  unreachable
bb_cast_ok218:
  %v2496 = load i64, ptr %slot201, align 8
  %v2497 = load i64, ptr %slot39, align 8
  %p2498 = inttoptr i64 %v2497 to ptr
  store i64 %v2496, ptr %p2498, align 8, !alias.scope !3, !noalias !4
  %v2499 = load i64, ptr %slot34, align 8
  %p2500 = inttoptr i64 %v2499 to ptr
  %ld2501 = load i64, ptr %p2500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2501, ptr %slot203, align 8
  %v2502 = load i64, ptr %slot203, align 8
  %v2503 = load i64, ptr %slot40, align 8
  %p2504 = inttoptr i64 %v2503 to ptr
  store i64 %v2502, ptr %p2504, align 8, !alias.scope !3, !noalias !4
  %v2505 = load i64, ptr %slot40, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %ld2507 = load i64, ptr %p2506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2507, ptr %slot204, align 8
  %v2508 = load i64, ptr %slot39, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  %ld2510 = load i64, ptr %p2509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2510, ptr %slot205, align 8
  %v2511 = load i64, ptr %slot205, align 8
  %v2512 = load i64, ptr %slot204, align 8
  %ovpair2514 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v2511, i64 %v2512)
  %op2513 = extractvalue { i64, i1 } %ovpair2514, 0
  %ov2515 = extractvalue { i64, i1 } %ovpair2514, 1
  store i64 %op2513, ptr %slot206, align 8
  %v2516 = load i64, ptr %slot205, align 8
  %v2517 = load i64, ptr %slot206, align 8
  %op2518 = xor i64 %v2516, %v2517
  store i64 %op2518, ptr %slot207, align 8
  %v2519 = load i64, ptr %slot204, align 8
  %v2520 = load i64, ptr %slot206, align 8
  %op2521 = xor i64 %v2519, %v2520
  store i64 %op2521, ptr %slot208, align 8
  %v2522 = load i64, ptr %slot207, align 8
  %v2523 = load i64, ptr %slot208, align 8
  %op2524 = and i64 %v2522, %v2523
  store i64 %op2524, ptr %slot209, align 8
  %cv2525 = zext i1 %ov2515 to i64
  store i64 %cv2525, ptr %slot210, align 8
  %v2526 = load i64, ptr %slot210, align 8
  %cond2527 = icmp ne i64 %v2526, 0
  br i1 %cond2527, label %bb_overflow222, label %bb_checked222
bb_overflow222:
  %v2528 = load i64, ptr %slot1, align 8
  %p2529 = inttoptr i64 %v2528 to ptr
  %v2530 = load i64, ptr %slot205, align 8
  %v2531 = load i64, ptr %slot204, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2529, i64 0, i64 %v2530, i64 %v2531, i64 64) nomerge, !dbg !128
  unreachable
bb_checked222:
  %v2532 = load i64, ptr %slot206, align 8
  %v2533 = load i64, ptr %slot39, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  store i64 %v2532, ptr %p2534, align 8, !alias.scope !3, !noalias !4
  %v2535 = load i64, ptr %slot39, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  %ld2537 = load i64, ptr %p2536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2537, ptr %slot211, align 8
  %v2538 = load i64, ptr %slot211, align 8
  %v2539 = load i64, ptr %slot34, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  store i64 %v2538, ptr %p2540, align 8, !alias.scope !3, !noalias !4
  br label %bb_i36
bb_i36:
  %v2541 = load i64, ptr %slot34, align 8
  %p2542 = inttoptr i64 %v2541 to ptr
  %ld2543 = load i64, ptr %p2542, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2543, ptr %slot212, align 8
  %v2544 = load i64, ptr %slot212, align 8
  %v2545 = load i64, ptr %slot39, align 8
  %p2546 = inttoptr i64 %v2545 to ptr
  store i64 %v2544, ptr %p2546, align 8, !alias.scope !3, !noalias !4
  %v2547 = load i64, ptr %slot33, align 8
  %p2548 = inttoptr i64 %v2547 to ptr
  %ld2549 = load i64, ptr %p2548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2549, ptr %slot213, align 8
  %v2550 = load i64, ptr %slot39, align 8
  %p2551 = inttoptr i64 %v2550 to ptr
  %ld2552 = load i64, ptr %p2551, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2552, ptr %slot214, align 8
  %v2553 = load i64, ptr %slot213, align 8
  %p2554 = inttoptr i64 %v2553 to ptr
  %ld2555 = load i64, ptr %p2554, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2555, ptr %slot215, align 8
  %v2556 = load i64, ptr %slot214, align 8
  %v2557 = load i64, ptr %slot215, align 8
  %cmp2558 = icmp ult i64 %v2556, %v2557
  %cv2559 = zext i1 %cmp2558 to i64
  store i64 %cv2559, ptr %slot216, align 8
  %v2560 = load i64, ptr %slot216, align 8
  %cond2561 = icmp ne i64 %v2560, 0
  br i1 %cond2561, label %bb_success234, label %bb_failed234
bb_failed234:
  %v2562 = load i64, ptr %slot1, align 8
  %p2563 = inttoptr i64 %v2562 to ptr
  %v2564 = load i64, ptr %slot214, align 8
  %v2565 = load i64, ptr %slot215, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p2563, i64 %v2564, i64 %v2565) nomerge, !dbg !130
  unreachable
bb_success234:
  %v2566 = load i64, ptr %slot213, align 8
  %op2567 = add i64 %v2566, 32
  store i64 %op2567, ptr %slot217, align 8
  %v2568 = load i64, ptr %slot217, align 8
  %p2569 = inttoptr i64 %v2568 to ptr
  %ld2570 = load i64, ptr %p2569, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2570, ptr %slot218, align 8
  %v2571 = load i64, ptr %slot214, align 8
  %op2572 = mul i64 %v2571, 56
  store i64 %op2572, ptr %slot219, align 8
  %v2573 = load i64, ptr %slot218, align 8
  %v2574 = load i64, ptr %slot219, align 8
  %op2575 = add i64 %v2573, %v2574
  store i64 %op2575, ptr %slot220, align 8
  %v2576 = load i64, ptr %slot220, align 8
  %v2577 = load i64, ptr %slot39, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  store i64 %v2576, ptr %p2578, align 8, !alias.scope !3, !noalias !4
  %v2579 = load i64, ptr %slot39, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  %ld2581 = load i64, ptr %p2580, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2581, ptr %slot221, align 8
  %v2582 = load i64, ptr %slot221, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  %ld2584 = load i32, ptr %p2583, align 4, !alias.scope !12, !noalias !13
  %ext2585 = zext i32 %ld2584 to i64
  store i64 %ext2585, ptr %slot222, align 8
  %v2586 = load i64, ptr %slot222, align 8
  %cmp2587 = icmp eq i64 %v2586, 0
  %cv2588 = zext i1 %cmp2587 to i64
  store i64 %cv2588, ptr %slot223, align 8
  %v2589 = load i64, ptr %slot223, align 8
  %cond2590 = icmp ne i64 %v2589, 0
  br i1 %cond2590, label %bb_rcarm241, label %bb_rcarmnext241
bb_rcarm241:
  %v2591 = load i64, ptr %slot12, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  %ld2593 = load i32, ptr %p2592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2593, ptr %slot224, align 8
  %v2594 = load i32, ptr %slot224, align 8
  %cv2595 = zext i32 %v2594 to i64
  %cond2596 = icmp ne i64 %cv2595, 0
  br i1 %cond2596, label %bb_rcslotdrop244, label %bb_rcslotdone244
bb_rcslotdrop244:
  %v2597 = load i64, ptr %slot12, align 8
  %p2598 = inttoptr i64 %v2597 to ptr
  store i32 0, ptr %p2598, align 4, !alias.scope !3, !noalias !4
  %v2599 = load i64, ptr %slot21, align 8
  store i64 %v2599, ptr %slot225, align 8
  %v2600 = load i64, ptr %slot13, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  %ld2602 = load i32, ptr %p2601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2602, ptr %slot226, align 8
  %v2603 = load i32, ptr %slot226, align 8
  %op2604 = and i32 %v2603, 28
  store i32 %op2604, ptr %slot227, align 8
  %v2605 = load i32, ptr %slot227, align 8
  %cv2606 = zext i32 %v2605 to i64
  %cond2607 = icmp ne i64 %cv2606, 0
  br i1 %cond2607, label %bb_rcslotrole244, label %bb_rcslotowner244
bb_rcslotrole244:
  %v2608 = load i64, ptr %slot46, align 8
  store i64 %v2608, ptr %slot228, align 8
  %v2609 = load i64, ptr %slot228, align 8
  %v2610 = load i64, ptr %slot225, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2609, i64 %v2610) nomerge, !dbg !132
  br label %bb_rcslotdone244
bb_rcslotowner244:
  %v2611 = load i64, ptr %slot46, align 8
  store i64 %v2611, ptr %slot229, align 8
  %v2612 = load i64, ptr %slot229, align 8
  %v2613 = load i64, ptr %slot225, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2612, i64 %v2613) nomerge, !dbg !132
  br label %bb_rcslotdone244
bb_rcslotdone244:
  br label %bb_i59
bb_rcarmnext241:
  %v2614 = load i64, ptr %slot222, align 8
  %cmp2615 = icmp eq i64 %v2614, 1
  %cv2616 = zext i1 %cmp2615 to i64
  store i64 %cv2616, ptr %slot230, align 8
  %v2617 = load i64, ptr %slot230, align 8
  %cond2618 = icmp ne i64 %v2617, 0
  br i1 %cond2618, label %bb_rcarm251, label %bb_rcarmnext251
bb_rcarm251:
  %v2619 = load i64, ptr %slot12, align 8
  %p2620 = inttoptr i64 %v2619 to ptr
  %ld2621 = load i32, ptr %p2620, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2621, ptr %slot231, align 8
  %v2622 = load i32, ptr %slot231, align 8
  %cv2623 = zext i32 %v2622 to i64
  %cond2624 = icmp ne i64 %cv2623, 0
  br i1 %cond2624, label %bb_rcslotdrop254, label %bb_rcslotdone254
bb_rcslotdrop254:
  %v2625 = load i64, ptr %slot12, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  store i32 0, ptr %p2626, align 4, !alias.scope !3, !noalias !4
  %v2627 = load i64, ptr %slot21, align 8
  store i64 %v2627, ptr %slot232, align 8
  %v2628 = load i64, ptr %slot13, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  %ld2630 = load i32, ptr %p2629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2630, ptr %slot233, align 8
  %v2631 = load i32, ptr %slot233, align 8
  %op2632 = and i32 %v2631, 28
  store i32 %op2632, ptr %slot234, align 8
  %v2633 = load i32, ptr %slot234, align 8
  %cv2634 = zext i32 %v2633 to i64
  %cond2635 = icmp ne i64 %cv2634, 0
  br i1 %cond2635, label %bb_rcslotrole254, label %bb_rcslotowner254
bb_rcslotrole254:
  %v2636 = load i64, ptr %slot46, align 8
  store i64 %v2636, ptr %slot235, align 8
  %v2637 = load i64, ptr %slot235, align 8
  %v2638 = load i64, ptr %slot232, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2637, i64 %v2638) nomerge, !dbg !132
  br label %bb_rcslotdone254
bb_rcslotowner254:
  %v2639 = load i64, ptr %slot46, align 8
  store i64 %v2639, ptr %slot236, align 8
  %v2640 = load i64, ptr %slot236, align 8
  %v2641 = load i64, ptr %slot232, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2640, i64 %v2641) nomerge, !dbg !132
  br label %bb_rcslotdone254
bb_rcslotdone254:
  br label %bb_i62
bb_rcarmnext251:
  %v2642 = load i64, ptr %slot222, align 8
  %cmp2643 = icmp eq i64 %v2642, 2
  %cv2644 = zext i1 %cmp2643 to i64
  store i64 %cv2644, ptr %slot237, align 8
  %v2645 = load i64, ptr %slot237, align 8
  %cond2646 = icmp ne i64 %v2645, 0
  br i1 %cond2646, label %bb_rcarm261, label %bb_rcarmnext261
bb_rcarm261:
  %v2647 = load i64, ptr %slot221, align 8
  %op2648 = add i64 %v2647, 8
  store i64 %op2648, ptr %slot238, align 8
  %v2649 = load i64, ptr %slot238, align 8
  %v2650 = load i64, ptr %slot35, align 8
  %p2651 = inttoptr i64 %v2649 to ptr
  %p2652 = inttoptr i64 %v2650 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2652, ptr %p2651, i64 48, i1 false), !alias.scope !10000000
  %v2653 = load i64, ptr %slot12, align 8
  %p2654 = inttoptr i64 %v2653 to ptr
  %ld2655 = load i32, ptr %p2654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2655, ptr %slot239, align 8
  %v2656 = load i32, ptr %slot239, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcslotdrop275, label %bb_rcslotdone275
bb_rcslotdrop275:
  %v2659 = load i64, ptr %slot12, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  store i32 0, ptr %p2660, align 4, !alias.scope !3, !noalias !4
  %v2661 = load i64, ptr %slot21, align 8
  store i64 %v2661, ptr %slot240, align 8
  %v2662 = load i64, ptr %slot13, align 8
  %p2663 = inttoptr i64 %v2662 to ptr
  %ld2664 = load i32, ptr %p2663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2664, ptr %slot241, align 8
  %v2665 = load i32, ptr %slot241, align 8
  %op2666 = and i32 %v2665, 28
  store i32 %op2666, ptr %slot242, align 8
  %v2667 = load i32, ptr %slot242, align 8
  %cv2668 = zext i32 %v2667 to i64
  %cond2669 = icmp ne i64 %cv2668, 0
  br i1 %cond2669, label %bb_rcslotrole275, label %bb_rcslotowner275
bb_rcslotrole275:
  %v2670 = load i64, ptr %slot46, align 8
  store i64 %v2670, ptr %slot243, align 8
  %v2671 = load i64, ptr %slot243, align 8
  %v2672 = load i64, ptr %slot240, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2671, i64 %v2672) nomerge, !dbg !132
  br label %bb_rcslotdone275
bb_rcslotowner275:
  %v2673 = load i64, ptr %slot46, align 8
  store i64 %v2673, ptr %slot244, align 8
  %v2674 = load i64, ptr %slot244, align 8
  %v2675 = load i64, ptr %slot240, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2674, i64 %v2675) nomerge, !dbg !132
  br label %bb_rcslotdone275
bb_rcslotdone275:
  br label %bb_i39
bb_rcarmnext261:
  %v2676 = load i64, ptr %slot222, align 8
  %cmp2677 = icmp eq i64 %v2676, 3
  %cv2678 = zext i1 %cmp2677 to i64
  store i64 %cv2678, ptr %slot245, align 8
  %v2679 = load i64, ptr %slot245, align 8
  %cond2680 = icmp ne i64 %v2679, 0
  br i1 %cond2680, label %bb_rcarm282, label %bb_rcarmnext282
bb_rcarm282:
  %v2681 = load i64, ptr %slot12, align 8
  %p2682 = inttoptr i64 %v2681 to ptr
  %ld2683 = load i32, ptr %p2682, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2683, ptr %slot246, align 8
  %v2684 = load i32, ptr %slot246, align 8
  %cv2685 = zext i32 %v2684 to i64
  %cond2686 = icmp ne i64 %cv2685, 0
  br i1 %cond2686, label %bb_rcslotdrop285, label %bb_rcslotdone285
bb_rcslotdrop285:
  %v2687 = load i64, ptr %slot12, align 8
  %p2688 = inttoptr i64 %v2687 to ptr
  store i32 0, ptr %p2688, align 4, !alias.scope !3, !noalias !4
  %v2689 = load i64, ptr %slot21, align 8
  store i64 %v2689, ptr %slot247, align 8
  %v2690 = load i64, ptr %slot13, align 8
  %p2691 = inttoptr i64 %v2690 to ptr
  %ld2692 = load i32, ptr %p2691, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2692, ptr %slot248, align 8
  %v2693 = load i32, ptr %slot248, align 8
  %op2694 = and i32 %v2693, 28
  store i32 %op2694, ptr %slot249, align 8
  %v2695 = load i32, ptr %slot249, align 8
  %cv2696 = zext i32 %v2695 to i64
  %cond2697 = icmp ne i64 %cv2696, 0
  br i1 %cond2697, label %bb_rcslotrole285, label %bb_rcslotowner285
bb_rcslotrole285:
  %v2698 = load i64, ptr %slot46, align 8
  store i64 %v2698, ptr %slot250, align 8
  %v2699 = load i64, ptr %slot250, align 8
  %v2700 = load i64, ptr %slot247, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2699, i64 %v2700) nomerge, !dbg !132
  br label %bb_rcslotdone285
bb_rcslotowner285:
  %v2701 = load i64, ptr %slot46, align 8
  store i64 %v2701, ptr %slot251, align 8
  %v2702 = load i64, ptr %slot251, align 8
  %v2703 = load i64, ptr %slot247, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2702, i64 %v2703) nomerge, !dbg !132
  br label %bb_rcslotdone285
bb_rcslotdone285:
  br label %bb_i65
bb_rcarmnext282:
  %v2704 = load i64, ptr %slot222, align 8
  %cmp2705 = icmp eq i64 %v2704, 4
  %cv2706 = zext i1 %cmp2705 to i64
  store i64 %cv2706, ptr %slot252, align 8
  %v2707 = load i64, ptr %slot252, align 8
  %cond2708 = icmp ne i64 %v2707, 0
  br i1 %cond2708, label %bb_rcarm292, label %bb_rcarmnext292
bb_rcarm292:
  %v2709 = load i64, ptr %slot12, align 8
  %p2710 = inttoptr i64 %v2709 to ptr
  %ld2711 = load i32, ptr %p2710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2711, ptr %slot253, align 8
  %v2712 = load i32, ptr %slot253, align 8
  %cv2713 = zext i32 %v2712 to i64
  %cond2714 = icmp ne i64 %cv2713, 0
  br i1 %cond2714, label %bb_rcslotdrop295, label %bb_rcslotdone295
bb_rcslotdrop295:
  %v2715 = load i64, ptr %slot12, align 8
  %p2716 = inttoptr i64 %v2715 to ptr
  store i32 0, ptr %p2716, align 4, !alias.scope !3, !noalias !4
  %v2717 = load i64, ptr %slot21, align 8
  store i64 %v2717, ptr %slot254, align 8
  %v2718 = load i64, ptr %slot13, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  %ld2720 = load i32, ptr %p2719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2720, ptr %slot255, align 8
  %v2721 = load i32, ptr %slot255, align 8
  %op2722 = and i32 %v2721, 28
  store i32 %op2722, ptr %slot256, align 8
  %v2723 = load i32, ptr %slot256, align 8
  %cv2724 = zext i32 %v2723 to i64
  %cond2725 = icmp ne i64 %cv2724, 0
  br i1 %cond2725, label %bb_rcslotrole295, label %bb_rcslotowner295
bb_rcslotrole295:
  %v2726 = load i64, ptr %slot46, align 8
  store i64 %v2726, ptr %slot257, align 8
  %v2727 = load i64, ptr %slot257, align 8
  %v2728 = load i64, ptr %slot254, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2727, i64 %v2728) nomerge, !dbg !132
  br label %bb_rcslotdone295
bb_rcslotowner295:
  %v2729 = load i64, ptr %slot46, align 8
  store i64 %v2729, ptr %slot258, align 8
  %v2730 = load i64, ptr %slot258, align 8
  %v2731 = load i64, ptr %slot254, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2730, i64 %v2731) nomerge, !dbg !132
  br label %bb_rcslotdone295
bb_rcslotdone295:
  br label %bb_i68
bb_rcarmnext292:
  %v2732 = load i64, ptr %slot222, align 8
  %cmp2733 = icmp eq i64 %v2732, 5
  %cv2734 = zext i1 %cmp2733 to i64
  store i64 %cv2734, ptr %slot259, align 8
  %v2735 = load i64, ptr %slot259, align 8
  %cond2736 = icmp ne i64 %v2735, 0
  br i1 %cond2736, label %bb_rcarm302, label %bb_rcarmnext302
bb_rcarm302:
  %v2737 = load i64, ptr %slot12, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  %ld2739 = load i32, ptr %p2738, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2739, ptr %slot260, align 8
  %v2740 = load i32, ptr %slot260, align 8
  %cv2741 = zext i32 %v2740 to i64
  %cond2742 = icmp ne i64 %cv2741, 0
  br i1 %cond2742, label %bb_rcslotdrop305, label %bb_rcslotdone305
bb_rcslotdrop305:
  %v2743 = load i64, ptr %slot12, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  store i32 0, ptr %p2744, align 4, !alias.scope !3, !noalias !4
  %v2745 = load i64, ptr %slot21, align 8
  store i64 %v2745, ptr %slot261, align 8
  %v2746 = load i64, ptr %slot13, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  %ld2748 = load i32, ptr %p2747, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2748, ptr %slot262, align 8
  %v2749 = load i32, ptr %slot262, align 8
  %op2750 = and i32 %v2749, 28
  store i32 %op2750, ptr %slot263, align 8
  %v2751 = load i32, ptr %slot263, align 8
  %cv2752 = zext i32 %v2751 to i64
  %cond2753 = icmp ne i64 %cv2752, 0
  br i1 %cond2753, label %bb_rcslotrole305, label %bb_rcslotowner305
bb_rcslotrole305:
  %v2754 = load i64, ptr %slot46, align 8
  store i64 %v2754, ptr %slot264, align 8
  %v2755 = load i64, ptr %slot264, align 8
  %v2756 = load i64, ptr %slot261, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2755, i64 %v2756) nomerge, !dbg !132
  br label %bb_rcslotdone305
bb_rcslotowner305:
  %v2757 = load i64, ptr %slot46, align 8
  store i64 %v2757, ptr %slot265, align 8
  %v2758 = load i64, ptr %slot265, align 8
  %v2759 = load i64, ptr %slot261, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2758, i64 %v2759) nomerge, !dbg !132
  br label %bb_rcslotdone305
bb_rcslotdone305:
  br label %bb_i71
bb_rcarmnext302:
  %v2760 = load i64, ptr %slot222, align 8
  %cmp2761 = icmp eq i64 %v2760, 6
  %cv2762 = zext i1 %cmp2761 to i64
  store i64 %cv2762, ptr %slot266, align 8
  %v2763 = load i64, ptr %slot266, align 8
  %cond2764 = icmp ne i64 %v2763, 0
  br i1 %cond2764, label %bb_rcarm312, label %bb_rcarmnext312
bb_rcarm312:
  %v2765 = load i64, ptr %slot12, align 8
  %p2766 = inttoptr i64 %v2765 to ptr
  %ld2767 = load i32, ptr %p2766, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2767, ptr %slot267, align 8
  %v2768 = load i32, ptr %slot267, align 8
  %cv2769 = zext i32 %v2768 to i64
  %cond2770 = icmp ne i64 %cv2769, 0
  br i1 %cond2770, label %bb_rcslotdrop315, label %bb_rcslotdone315
bb_rcslotdrop315:
  %v2771 = load i64, ptr %slot12, align 8
  %p2772 = inttoptr i64 %v2771 to ptr
  store i32 0, ptr %p2772, align 4, !alias.scope !3, !noalias !4
  %v2773 = load i64, ptr %slot21, align 8
  store i64 %v2773, ptr %slot268, align 8
  %v2774 = load i64, ptr %slot13, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  %ld2776 = load i32, ptr %p2775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2776, ptr %slot269, align 8
  %v2777 = load i32, ptr %slot269, align 8
  %op2778 = and i32 %v2777, 28
  store i32 %op2778, ptr %slot270, align 8
  %v2779 = load i32, ptr %slot270, align 8
  %cv2780 = zext i32 %v2779 to i64
  %cond2781 = icmp ne i64 %cv2780, 0
  br i1 %cond2781, label %bb_rcslotrole315, label %bb_rcslotowner315
bb_rcslotrole315:
  %v2782 = load i64, ptr %slot46, align 8
  store i64 %v2782, ptr %slot271, align 8
  %v2783 = load i64, ptr %slot271, align 8
  %v2784 = load i64, ptr %slot268, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2783, i64 %v2784) nomerge, !dbg !132
  br label %bb_rcslotdone315
bb_rcslotowner315:
  %v2785 = load i64, ptr %slot46, align 8
  store i64 %v2785, ptr %slot272, align 8
  %v2786 = load i64, ptr %slot272, align 8
  %v2787 = load i64, ptr %slot268, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2786, i64 %v2787) nomerge, !dbg !132
  br label %bb_rcslotdone315
bb_rcslotdone315:
  br label %bb_i74
bb_rcarmnext312:
  %v2788 = load i64, ptr %slot222, align 8
  %cmp2789 = icmp eq i64 %v2788, 7
  %cv2790 = zext i1 %cmp2789 to i64
  store i64 %cv2790, ptr %slot273, align 8
  %v2791 = load i64, ptr %slot273, align 8
  %cond2792 = icmp ne i64 %v2791, 0
  br i1 %cond2792, label %bb_rcarm322, label %bb_rcarmnext322
bb_rcarm322:
  %v2793 = load i64, ptr %slot12, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  %ld2795 = load i32, ptr %p2794, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2795, ptr %slot274, align 8
  %v2796 = load i32, ptr %slot274, align 8
  %cv2797 = zext i32 %v2796 to i64
  %cond2798 = icmp ne i64 %cv2797, 0
  br i1 %cond2798, label %bb_rcslotdrop325, label %bb_rcslotdone325
bb_rcslotdrop325:
  %v2799 = load i64, ptr %slot12, align 8
  %p2800 = inttoptr i64 %v2799 to ptr
  store i32 0, ptr %p2800, align 4, !alias.scope !3, !noalias !4
  %v2801 = load i64, ptr %slot21, align 8
  store i64 %v2801, ptr %slot275, align 8
  %v2802 = load i64, ptr %slot13, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  %ld2804 = load i32, ptr %p2803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2804, ptr %slot276, align 8
  %v2805 = load i32, ptr %slot276, align 8
  %op2806 = and i32 %v2805, 28
  store i32 %op2806, ptr %slot277, align 8
  %v2807 = load i32, ptr %slot277, align 8
  %cv2808 = zext i32 %v2807 to i64
  %cond2809 = icmp ne i64 %cv2808, 0
  br i1 %cond2809, label %bb_rcslotrole325, label %bb_rcslotowner325
bb_rcslotrole325:
  %v2810 = load i64, ptr %slot46, align 8
  store i64 %v2810, ptr %slot278, align 8
  %v2811 = load i64, ptr %slot278, align 8
  %v2812 = load i64, ptr %slot275, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2811, i64 %v2812) nomerge, !dbg !132
  br label %bb_rcslotdone325
bb_rcslotowner325:
  %v2813 = load i64, ptr %slot46, align 8
  store i64 %v2813, ptr %slot279, align 8
  %v2814 = load i64, ptr %slot279, align 8
  %v2815 = load i64, ptr %slot275, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2814, i64 %v2815) nomerge, !dbg !132
  br label %bb_rcslotdone325
bb_rcslotdone325:
  br label %bb_i77
bb_rcarmnext322:
  %v2816 = load i64, ptr %slot222, align 8
  %cmp2817 = icmp eq i64 %v2816, 8
  %cv2818 = zext i1 %cmp2817 to i64
  store i64 %cv2818, ptr %slot280, align 8
  %v2819 = load i64, ptr %slot280, align 8
  %cond2820 = icmp ne i64 %v2819, 0
  br i1 %cond2820, label %bb_rcarm332, label %bb_rcarmnext332
bb_rcarm332:
  %v2821 = load i64, ptr %slot12, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  %ld2823 = load i32, ptr %p2822, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2823, ptr %slot281, align 8
  %v2824 = load i32, ptr %slot281, align 8
  %cv2825 = zext i32 %v2824 to i64
  %cond2826 = icmp ne i64 %cv2825, 0
  br i1 %cond2826, label %bb_rcslotdrop335, label %bb_rcslotdone335
bb_rcslotdrop335:
  %v2827 = load i64, ptr %slot12, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  store i32 0, ptr %p2828, align 4, !alias.scope !3, !noalias !4
  %v2829 = load i64, ptr %slot21, align 8
  store i64 %v2829, ptr %slot282, align 8
  %v2830 = load i64, ptr %slot13, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  %ld2832 = load i32, ptr %p2831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2832, ptr %slot283, align 8
  %v2833 = load i32, ptr %slot283, align 8
  %op2834 = and i32 %v2833, 28
  store i32 %op2834, ptr %slot284, align 8
  %v2835 = load i32, ptr %slot284, align 8
  %cv2836 = zext i32 %v2835 to i64
  %cond2837 = icmp ne i64 %cv2836, 0
  br i1 %cond2837, label %bb_rcslotrole335, label %bb_rcslotowner335
bb_rcslotrole335:
  %v2838 = load i64, ptr %slot46, align 8
  store i64 %v2838, ptr %slot285, align 8
  %v2839 = load i64, ptr %slot285, align 8
  %v2840 = load i64, ptr %slot282, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2839, i64 %v2840) nomerge, !dbg !132
  br label %bb_rcslotdone335
bb_rcslotowner335:
  %v2841 = load i64, ptr %slot46, align 8
  store i64 %v2841, ptr %slot286, align 8
  %v2842 = load i64, ptr %slot286, align 8
  %v2843 = load i64, ptr %slot282, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2842, i64 %v2843) nomerge, !dbg !132
  br label %bb_rcslotdone335
bb_rcslotdone335:
  br label %bb_i80
bb_rcarmnext332:
  %v2844 = load i64, ptr %slot222, align 8
  %cmp2845 = icmp eq i64 %v2844, 9
  %cv2846 = zext i1 %cmp2845 to i64
  store i64 %cv2846, ptr %slot287, align 8
  %v2847 = load i64, ptr %slot287, align 8
  %cond2848 = icmp ne i64 %v2847, 0
  br i1 %cond2848, label %bb_rcarm342, label %bb_rcarmnext342
bb_rcarm342:
  %v2849 = load i64, ptr %slot12, align 8
  %p2850 = inttoptr i64 %v2849 to ptr
  %ld2851 = load i32, ptr %p2850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2851, ptr %slot288, align 8
  %v2852 = load i32, ptr %slot288, align 8
  %cv2853 = zext i32 %v2852 to i64
  %cond2854 = icmp ne i64 %cv2853, 0
  br i1 %cond2854, label %bb_rcslotdrop345, label %bb_rcslotdone345
bb_rcslotdrop345:
  %v2855 = load i64, ptr %slot12, align 8
  %p2856 = inttoptr i64 %v2855 to ptr
  store i32 0, ptr %p2856, align 4, !alias.scope !3, !noalias !4
  %v2857 = load i64, ptr %slot21, align 8
  store i64 %v2857, ptr %slot289, align 8
  %v2858 = load i64, ptr %slot13, align 8
  %p2859 = inttoptr i64 %v2858 to ptr
  %ld2860 = load i32, ptr %p2859, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2860, ptr %slot290, align 8
  %v2861 = load i32, ptr %slot290, align 8
  %op2862 = and i32 %v2861, 28
  store i32 %op2862, ptr %slot291, align 8
  %v2863 = load i32, ptr %slot291, align 8
  %cv2864 = zext i32 %v2863 to i64
  %cond2865 = icmp ne i64 %cv2864, 0
  br i1 %cond2865, label %bb_rcslotrole345, label %bb_rcslotowner345
bb_rcslotrole345:
  %v2866 = load i64, ptr %slot46, align 8
  store i64 %v2866, ptr %slot292, align 8
  %v2867 = load i64, ptr %slot292, align 8
  %v2868 = load i64, ptr %slot289, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2867, i64 %v2868) nomerge, !dbg !132
  br label %bb_rcslotdone345
bb_rcslotowner345:
  %v2869 = load i64, ptr %slot46, align 8
  store i64 %v2869, ptr %slot293, align 8
  %v2870 = load i64, ptr %slot293, align 8
  %v2871 = load i64, ptr %slot289, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2870, i64 %v2871) nomerge, !dbg !132
  br label %bb_rcslotdone345
bb_rcslotdone345:
  br label %bb_i83
bb_rcarmnext342:
  %v2872 = load i64, ptr %slot222, align 8
  %cmp2873 = icmp eq i64 %v2872, 10
  %cv2874 = zext i1 %cmp2873 to i64
  store i64 %cv2874, ptr %slot294, align 8
  %v2875 = load i64, ptr %slot294, align 8
  %cond2876 = icmp ne i64 %v2875, 0
  br i1 %cond2876, label %bb_rcarm352, label %bb_rcarmnext352
bb_rcarm352:
  %v2877 = load i64, ptr %slot12, align 8
  %p2878 = inttoptr i64 %v2877 to ptr
  %ld2879 = load i32, ptr %p2878, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2879, ptr %slot295, align 8
  %v2880 = load i32, ptr %slot295, align 8
  %cv2881 = zext i32 %v2880 to i64
  %cond2882 = icmp ne i64 %cv2881, 0
  br i1 %cond2882, label %bb_rcslotdrop355, label %bb_rcslotdone355
bb_rcslotdrop355:
  %v2883 = load i64, ptr %slot12, align 8
  %p2884 = inttoptr i64 %v2883 to ptr
  store i32 0, ptr %p2884, align 4, !alias.scope !3, !noalias !4
  %v2885 = load i64, ptr %slot21, align 8
  store i64 %v2885, ptr %slot296, align 8
  %v2886 = load i64, ptr %slot13, align 8
  %p2887 = inttoptr i64 %v2886 to ptr
  %ld2888 = load i32, ptr %p2887, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2888, ptr %slot297, align 8
  %v2889 = load i32, ptr %slot297, align 8
  %op2890 = and i32 %v2889, 28
  store i32 %op2890, ptr %slot298, align 8
  %v2891 = load i32, ptr %slot298, align 8
  %cv2892 = zext i32 %v2891 to i64
  %cond2893 = icmp ne i64 %cv2892, 0
  br i1 %cond2893, label %bb_rcslotrole355, label %bb_rcslotowner355
bb_rcslotrole355:
  %v2894 = load i64, ptr %slot46, align 8
  store i64 %v2894, ptr %slot299, align 8
  %v2895 = load i64, ptr %slot299, align 8
  %v2896 = load i64, ptr %slot296, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v2895, i64 %v2896) nomerge, !dbg !132
  br label %bb_rcslotdone355
bb_rcslotowner355:
  %v2897 = load i64, ptr %slot46, align 8
  store i64 %v2897, ptr %slot300, align 8
  %v2898 = load i64, ptr %slot300, align 8
  %v2899 = load i64, ptr %slot296, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v2898, i64 %v2899) nomerge, !dbg !132
  br label %bb_rcslotdone355
bb_rcslotdone355:
  br label %bb_i86
bb_rcarmnext352:
  br label %bb_failure
bb_i39:
  %v2900 = load i64, ptr %slot35, align 8
  %v2901 = load i64, ptr %slot39, align 8
  %p2902 = inttoptr i64 %v2901 to ptr
  store i64 %v2900, ptr %p2902, align 8, !alias.scope !3, !noalias !4
  %v2903 = load i64, ptr %slot35, align 8
  %v2904 = load i64, ptr %slot39, align 8
  %p2905 = inttoptr i64 %v2904 to ptr
  store i64 %v2903, ptr %p2905, align 8, !alias.scope !3, !noalias !4
  %v2906 = load i64, ptr %slot39, align 8
  %p2907 = inttoptr i64 %v2906 to ptr
  %ld2908 = load i64, ptr %p2907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2908, ptr %slot301, align 8
  %v2909 = load i64, ptr %slot301, align 8
  %op2910 = add i64 %v2909, 16
  store i64 %op2910, ptr %slot302, align 8
  %v2911 = load i64, ptr %slot302, align 8
  %v2912 = load i64, ptr %slot39, align 8
  %p2913 = inttoptr i64 %v2912 to ptr
  store i64 %v2911, ptr %p2913, align 8, !alias.scope !3, !noalias !4
  %v2914 = load i64, ptr %slot12, align 8
  %p2915 = inttoptr i64 %v2914 to ptr
  %ld2916 = load i32, ptr %p2915, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2916, ptr %slot303, align 8
  %v2917 = load i32, ptr %slot303, align 8
  %cv2918 = zext i32 %v2917 to i64
  %cond2919 = icmp ne i64 %cv2918, 0
  br i1 %cond2919, label %bb_rcslotdrop366, label %bb_rcslotdone366
bb_rcslotdrop366:
  %v2920 = load i64, ptr %slot12, align 8
  %p2921 = inttoptr i64 %v2920 to ptr
  store i32 0, ptr %p2921, align 4, !alias.scope !3, !noalias !4
  %v2922 = load i64, ptr %slot21, align 8
  store i64 %v2922, ptr %slot304, align 8
  %v2923 = load i64, ptr %slot13, align 8
  %p2924 = inttoptr i64 %v2923 to ptr
  %ld2925 = load i32, ptr %p2924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2925, ptr %slot305, align 8
  %v2926 = load i32, ptr %slot305, align 8
  %op2927 = and i32 %v2926, 28
  store i32 %op2927, ptr %slot306, align 8
  %v2928 = load i32, ptr %slot306, align 8
  %cv2929 = zext i32 %v2928 to i64
  %cond2930 = icmp ne i64 %cv2929, 0
  br i1 %cond2930, label %bb_rcslotrole366, label %bb_rcslotowner366
bb_rcslotrole366:
  %v2931 = load i64, ptr %slot46, align 8
  store i64 %v2931, ptr %slot307, align 8
  %v2932 = load i64, ptr %slot307, align 8
  %v2933 = load i64, ptr %slot304, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v2932, i64 %v2933) nomerge, !dbg !134
  br label %bb_rcslotdone366
bb_rcslotowner366:
  %v2934 = load i64, ptr %slot46, align 8
  store i64 %v2934, ptr %slot308, align 8
  %v2935 = load i64, ptr %slot308, align 8
  %v2936 = load i64, ptr %slot304, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v2935, i64 %v2936) nomerge, !dbg !134
  br label %bb_rcslotdone366
bb_rcslotdone366:
  %v2937 = load i64, ptr %slot39, align 8
  %p2938 = inttoptr i64 %v2937 to ptr
  %ld2939 = load i64, ptr %p2938, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2939, ptr %slot309, align 8
  %v2940 = load i64, ptr %slot309, align 8
  %op2941 = add i64 %v2940, 16
  store i64 %op2941, ptr %slot310, align 8
  %v2942 = load i64, ptr %slot310, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  %ld2944 = load i64, ptr %p2943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2944, ptr %slot311, align 8
  %v2945 = load i64, ptr %slot311, align 8
  %v2946 = load i64, ptr %slot39, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  store i64 %v2945, ptr %p2947, align 8, !alias.scope !3, !noalias !4
  %v2948 = load i64, ptr %slot12, align 8
  %p2949 = inttoptr i64 %v2948 to ptr
  %ld2950 = load i32, ptr %p2949, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2950, ptr %slot312, align 8
  %v2951 = load i32, ptr %slot312, align 8
  %cv2952 = zext i32 %v2951 to i64
  %cond2953 = icmp ne i64 %cv2952, 0
  br i1 %cond2953, label %bb_rcslotdrop378, label %bb_rcslotdone378
bb_rcslotdrop378:
  %v2954 = load i64, ptr %slot12, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  store i32 0, ptr %p2955, align 4, !alias.scope !3, !noalias !4
  %v2956 = load i64, ptr %slot21, align 8
  store i64 %v2956, ptr %slot313, align 8
  %v2957 = load i64, ptr %slot13, align 8
  %p2958 = inttoptr i64 %v2957 to ptr
  %ld2959 = load i32, ptr %p2958, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2959, ptr %slot314, align 8
  %v2960 = load i32, ptr %slot314, align 8
  %op2961 = and i32 %v2960, 28
  store i32 %op2961, ptr %slot315, align 8
  %v2962 = load i32, ptr %slot315, align 8
  %cv2963 = zext i32 %v2962 to i64
  %cond2964 = icmp ne i64 %cv2963, 0
  br i1 %cond2964, label %bb_rcslotrole378, label %bb_rcslotowner378
bb_rcslotrole378:
  %v2965 = load i64, ptr %slot46, align 8
  store i64 %v2965, ptr %slot316, align 8
  %v2966 = load i64, ptr %slot316, align 8
  %v2967 = load i64, ptr %slot313, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v2966, i64 %v2967) nomerge, !dbg !136
  br label %bb_rcslotdone378
bb_rcslotowner378:
  %v2968 = load i64, ptr %slot46, align 8
  store i64 %v2968, ptr %slot317, align 8
  %v2969 = load i64, ptr %slot317, align 8
  %v2970 = load i64, ptr %slot313, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v2969, i64 %v2970) nomerge, !dbg !136
  br label %bb_rcslotdone378
bb_rcslotdone378:
  %v2971 = load i64, ptr %slot39, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  %ld2973 = load i64, ptr %p2972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2973, ptr %slot318, align 8
  %v2974 = load i64, ptr %slot318, align 8
  %v2975 = load i64, ptr %slot24, align 8
  %p2976 = inttoptr i64 %v2975 to ptr
  store i64 %v2974, ptr %p2976, align 8, !alias.scope !3, !noalias !4
  %v2977 = load i64, ptr %slot24, align 8
  store i64 %v2977, ptr %slot319, align 8
  %v2978 = load i64, ptr %slot12, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  %ld2980 = load i32, ptr %p2979, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2980, ptr %slot320, align 8
  %v2981 = load i64, ptr %slot13, align 8
  %p2982 = inttoptr i64 %v2981 to ptr
  %ld2983 = load i32, ptr %p2982, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2983, ptr %slot321, align 8
  %v2984 = load i32, ptr %slot321, align 8
  %op2985 = and i32 %v2984, 24
  store i32 %op2985, ptr %slot321, align 8
  %v2986 = load i32, ptr %slot321, align 8
  %cmp2987 = icmp eq i32 %v2986, 0
  %cv2988 = zext i1 %cmp2987 to i32
  store i32 %cv2988, ptr %slot322, align 8
  %v2989 = load i32, ptr %slot320, align 8
  %v2990 = load i32, ptr %slot322, align 8
  %op2991 = and i32 %v2989, %v2990
  store i32 %op2991, ptr %slot323, align 8
  %v2992 = load i64, ptr %slot47, align 8
  store i64 %v2992, ptr %slot324, align 8
  %v2993 = load i32, ptr %slot323, align 8
  %op2994 = mul i32 %v2993, 4
  store i32 %op2994, ptr %slot325, align 8
  %v2995 = load i32, ptr %slot325, align 8
  %op2996 = or i32 %v2995, 0
  store i32 %op2996, ptr %slot326, align 8
  %v2997 = load i64, ptr %slot27, align 8
  store i64 %v2997, ptr %slot327, align 8
  %v2998 = load i32, ptr %slot326, align 8
  %op2999 = and i32 %v2998, 3
  store i32 %op2999, ptr %slot328, align 8
  %v3000 = load i32, ptr %slot328, align 8
  %cv3001 = zext i32 %v3000 to i64
  %cond3002 = icmp ne i64 %cv3001, 0
  br i1 %cond3002, label %bb_rcgpublishslow398, label %bb_rcgpublishmode398
bb_rcgpublishmode398:
  %v3003 = load i64, ptr %slot319, align 8
  %p3004 = inttoptr i64 %v3003 to ptr
  %ld3005 = load i64, ptr %p3004, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3005, ptr %slot329, align 8
  %v3006 = load i64, ptr %slot329, align 8
  %cmp3007 = icmp ne i64 %v3006, 0
  %cv3008 = zext i1 %cmp3007 to i32
  store i32 %cv3008, ptr %slot330, align 8
  %v3009 = load i32, ptr %slot330, align 8
  %cv3010 = zext i32 %v3009 to i64
  %cond3011 = icmp ne i64 %cv3010, 0
  br i1 %cond3011, label %bb_rcgpublishnn398, label %bb_rcgpublishstore398
bb_rcgpublishnn398:
  %v3012 = load i64, ptr %slot329, align 8
  %op3013 = sub i64 %v3012, 16
  store i64 %op3013, ptr %slot331, align 8
  %v3014 = load i64, ptr %slot329, align 8
  %p3015 = inttoptr i64 %v3014 to ptr
  %rgep3016 = getelementptr i8, ptr %p3015, i64 -16
  %ld3017 = load i64, ptr %rgep3016, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3017, ptr %slot332, align 8
  %v3018 = load i64, ptr %slot332, align 8
  %op3019 = and i64 %v3018, 5764607523034234880
  store i64 %op3019, ptr %slot333, align 8
  %v3020 = load i64, ptr %slot333, align 8
  %cmp3021 = icmp ne i64 %v3020, 0
  %cv3022 = zext i1 %cmp3021 to i32
  store i32 %cv3022, ptr %slot334, align 8
  %v3023 = load i32, ptr %slot334, align 8
  %cv3024 = zext i32 %v3023 to i64
  %cond3025 = icmp ne i64 %cv3024, 0
  br i1 %cond3025, label %bb_rcgpublishslow398, label %bb_rcgpublishshare398
bb_rcgpublishshare398:
  %v3026 = load i32, ptr %slot326, align 8
  %op3027 = and i32 %v3026, 4
  store i32 %op3027, ptr %slot335, align 8
  %v3028 = load i64, ptr %slot332, align 8
  %op3029 = and i64 %v3028, 2
  store i64 %op3029, ptr %slot336, align 8
  %v3030 = load i32, ptr %slot335, align 8
  %cv3031 = zext i32 %v3030 to i64
  %cond3032 = icmp ne i64 %cv3031, 0
  br i1 %cond3032, label %bb_rcgpublishmarkcheck398, label %bb_rcgpublishordinary398
bb_rcgpublishordinary398:
  %v3033 = load i64, ptr %slot336, align 8
  %cmp3034 = icmp ne i64 %v3033, 0
  %cv3035 = zext i1 %cmp3034 to i32
  store i32 %cv3035, ptr %slot337, align 8
  %v3036 = load i32, ptr %slot337, align 8
  %cv3037 = zext i32 %v3036 to i64
  %cond3038 = icmp ne i64 %cv3037, 0
  br i1 %cond3038, label %bb_rcgpublishmarkcheck398, label %bb_rcgpublishcapacity398
bb_rcgpublishcapacity398:
  %v3039 = load i64, ptr %slot329, align 8
  %op3040 = sub i64 %v3039, 32
  store i64 %op3040, ptr %slot338, align 8
  %v3041 = load i64, ptr %slot329, align 8
  %p3042 = inttoptr i64 %v3041 to ptr
  %rgep3043 = getelementptr i8, ptr %p3042, i64 -32
  %ld3044 = load i64, ptr %rgep3043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3044, ptr %slot339, align 8
  %v3045 = load i64, ptr %slot339, align 8
  %op3046 = add i64 %v3045, 1
  store i64 %op3046, ptr %slot340, align 8
  %v3047 = load i64, ptr %slot340, align 8
  %cmp3048 = icmp eq i64 %v3047, 0
  %cv3049 = zext i1 %cmp3048 to i32
  store i32 %cv3049, ptr %slot341, align 8
  %v3050 = load i32, ptr %slot341, align 8
  %cv3051 = zext i32 %v3050 to i64
  %cond3052 = icmp ne i64 %cv3051, 0
  br i1 %cond3052, label %bb_rcgpublishslow398, label %bb_rcgpublishacquire398
bb_rcgpublishacquire398:
  %v3053 = load i64, ptr %slot340, align 8
  %v3054 = load i64, ptr %slot329, align 8
  %p3055 = inttoptr i64 %v3054 to ptr
  %rgep3056 = getelementptr i8, ptr %p3055, i64 -32
  store i64 %v3053, ptr %rgep3056, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgpublishmarkcheck398
bb_rcgpublishmarkcheck398:
  %v3057 = load i64, ptr %slot332, align 8
  %op3058 = and i64 %v3057, 2305843009213693954
  store i64 %op3058, ptr %slot342, align 8
  %v3059 = load i64, ptr %slot342, align 8
  %cmp3060 = icmp ne i64 %v3059, 0
  %cv3061 = zext i1 %cmp3060 to i32
  store i32 %cv3061, ptr %slot343, align 8
  %v3062 = load i32, ptr %slot343, align 8
  %cv3063 = zext i32 %v3062 to i64
  %cond3064 = icmp ne i64 %cv3063, 0
  br i1 %cond3064, label %bb_rcgpublishstore398, label %bb_rcgpublishmark398
bb_rcgpublishmark398:
  %v3065 = load i64, ptr %slot332, align 8
  %op3066 = or i64 %v3065, 2305843009213693952
  store i64 %op3066, ptr %slot344, align 8
  %v3067 = load i64, ptr %slot344, align 8
  %v3068 = load i64, ptr %slot329, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %rgep3070 = getelementptr i8, ptr %p3069, i64 -16
  store i64 %v3067, ptr %rgep3070, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgpublishstore398
bb_rcgpublishstore398:
  %v3071 = load i64, ptr %slot329, align 8
  %v3072 = load i64, ptr %slot327, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  store i64 %v3071, ptr %p3073, align 8, !alias.scope !3, !noalias !4
  %v3074 = load i32, ptr %slot326, align 8
  %op3075 = and i32 %v3074, 4
  store i32 %op3075, ptr %slot345, align 8
  %v3076 = load i32, ptr %slot345, align 8
  %cv3077 = zext i32 %v3076 to i64
  %cond3078 = icmp ne i64 %cv3077, 0
  br i1 %cond3078, label %bb_rcgpublishtake398, label %bb_rcgpublished398
bb_rcgpublishtake398:
  %v3079 = load i64, ptr %slot319, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  store i64 0, ptr %p3080, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgpublished398
bb_rcgpublishslow398:
  %v3081 = load i64, ptr %slot46, align 8
  %v3082 = load i64, ptr %slot327, align 8
  %v3083 = load i64, ptr %slot319, align 8
  %v3084 = load i64, ptr %slot324, align 8
  %cv3085 = trunc i64 %v3084 to i32
  %v3086 = load i32, ptr %slot326, align 8
  %call3087 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_publish(i64 %v3081, i64 %v3082, i64 %v3083, i32 %cv3085, i32 %v3086) nomerge, !dbg !138
  store i32 %call3087, ptr %slot346, align 8
  %v3088 = load i32, ptr %slot346, align 8
  %cv3089 = zext i32 %v3088 to i64
  %cond3090 = icmp ne i64 %cv3089, 0
  br i1 %cond3090, label %bb_rcsuccess418, label %bb_rcfailure418
bb_rcfailure418:
  %v3091 = load i64, ptr %slot46, align 8
  %p3092 = inttoptr i64 %v3091 to ptr
  %call3093 = call i32 @myl_rc_take_failure(ptr %p3092) nomerge, !dbg !138
  store i32 %call3093, ptr %slot347, align 8
  %v3094 = load i64, ptr %slot1, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  %v3096 = load i32, ptr %slot347, align 8
  %call3097 = call i32 @myl_qbe_rc_status(ptr %p3095, i32 %v3096) nomerge, !dbg !138
  store i32 %call3097, ptr %slot348, align 8
  br label %bb_failure
bb_rcsuccess418:
  br label %bb_rcgpublished398
bb_rcgpublished398:
  %v3098 = load i32, ptr %slot323, align 8
  %cv3099 = zext i32 %v3098 to i64
  %cond3100 = icmp ne i64 %cv3099, 0
  br i1 %cond3100, label %bb_rchtaken421, label %bb_rchcopied421
bb_rchcopied421:
  %v3101 = load i64, ptr %slot12, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  %ld3103 = load i32, ptr %p3102, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3103, ptr %slot349, align 8
  %v3104 = load i32, ptr %slot349, align 8
  %cv3105 = zext i32 %v3104 to i64
  %cond3106 = icmp ne i64 %cv3105, 0
  br i1 %cond3106, label %bb_rcslotdrop424, label %bb_rcslotdone424
bb_rcslotdrop424:
  %v3107 = load i64, ptr %slot12, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  store i32 0, ptr %p3108, align 4, !alias.scope !3, !noalias !4
  %v3109 = load i64, ptr %slot21, align 8
  store i64 %v3109, ptr %slot350, align 8
  %v3110 = load i64, ptr %slot13, align 8
  %p3111 = inttoptr i64 %v3110 to ptr
  %ld3112 = load i32, ptr %p3111, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3112, ptr %slot351, align 8
  %v3113 = load i32, ptr %slot351, align 8
  %op3114 = and i32 %v3113, 28
  store i32 %op3114, ptr %slot352, align 8
  %v3115 = load i32, ptr %slot352, align 8
  %cv3116 = zext i32 %v3115 to i64
  %cond3117 = icmp ne i64 %cv3116, 0
  br i1 %cond3117, label %bb_rcslotrole424, label %bb_rcslotowner424
bb_rcslotrole424:
  %v3118 = load i64, ptr %slot46, align 8
  store i64 %v3118, ptr %slot353, align 8
  %v3119 = load i64, ptr %slot350, align 8
  %p3120 = inttoptr i64 %v3119 to ptr
  %ld3121 = load i64, ptr %p3120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3121, ptr %slot354, align 8
  %v3122 = load i64, ptr %slot354, align 8
  %cmp3123 = icmp ne i64 %v3122, 0
  %cv3124 = zext i1 %cmp3123 to i32
  store i32 %cv3124, ptr %slot355, align 8
  %v3125 = load i32, ptr %slot355, align 8
  %cv3126 = zext i32 %v3125 to i64
  %cond3127 = icmp ne i64 %cv3126, 0
  br i1 %cond3127, label %bb_rcgnn440, label %bb_rcgdone440
bb_rcgnn440:
  %v3128 = load i64, ptr %slot354, align 8
  %op3129 = sub i64 %v3128, 16
  store i64 %op3129, ptr %slot356, align 8
  %v3130 = load i64, ptr %slot354, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  %rgep3132 = getelementptr i8, ptr %p3131, i64 -16
  %ld3133 = load i64, ptr %rgep3132, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3133, ptr %slot357, align 8
  %v3134 = load i64, ptr %slot357, align 8
  %op3135 = and i64 %v3134, 4611686018427387906
  store i64 %op3135, ptr %slot358, align 8
  %v3136 = load i64, ptr %slot358, align 8
  %cmp3137 = icmp ne i64 %v3136, 0
  %cv3138 = zext i1 %cmp3137 to i32
  store i32 %cv3138, ptr %slot359, align 8
  %v3139 = load i32, ptr %slot359, align 8
  %cv3140 = zext i32 %v3139 to i64
  %cond3141 = icmp ne i64 %cv3140, 0
  br i1 %cond3141, label %bb_rcgclear440, label %bb_rcgcounted440
bb_rcgcounted440:
  %v3142 = load i64, ptr %slot354, align 8
  %op3143 = sub i64 %v3142, 24
  store i64 %op3143, ptr %slot360, align 8
  %v3144 = load i64, ptr %slot354, align 8
  %p3145 = inttoptr i64 %v3144 to ptr
  %rgep3146 = getelementptr i8, ptr %p3145, i64 -24
  %ld3147 = load i64, ptr %rgep3146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3147, ptr %slot361, align 8
  %v3148 = load i64, ptr %slot361, align 8
  %op3149 = sub i64 %v3148, 1
  store i64 %op3149, ptr %slot362, align 8
  %v3150 = load i64, ptr %slot362, align 8
  %cmp3151 = icmp eq i64 %v3150, 0
  %cv3152 = zext i1 %cmp3151 to i32
  store i32 %cv3152, ptr %slot363, align 8
  %v3153 = load i32, ptr %slot363, align 8
  %cv3154 = zext i32 %v3153 to i64
  %cond3155 = icmp ne i64 %cv3154, 0
  br i1 %cond3155, label %bb_rcglast440, label %bb_rcgdec440
bb_rcglast440:
  %v3156 = load i64, ptr %slot354, align 8
  %op3157 = sub i64 %v3156, 32
  store i64 %op3157, ptr %slot364, align 8
  %v3158 = load i64, ptr %slot354, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  %rgep3160 = getelementptr i8, ptr %p3159, i64 -32
  %ld3161 = load i64, ptr %rgep3160, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3161, ptr %slot365, align 8
  %v3162 = load i64, ptr %slot365, align 8
  %cmp3163 = icmp ne i64 %v3162, 0
  %cv3164 = zext i1 %cmp3163 to i32
  store i32 %cv3164, ptr %slot366, align 8
  %v3165 = load i32, ptr %slot366, align 8
  %cv3166 = zext i32 %v3165 to i64
  %cond3167 = icmp ne i64 %cv3166, 0
  br i1 %cond3167, label %bb_rcgdec440, label %bb_rcgslow440
bb_rcgslow440:
  %v3168 = load i64, ptr %slot353, align 8
  %v3169 = load i64, ptr %slot350, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3168, i64 %v3169) nomerge, !dbg !138
  br label %bb_rcgdone440
bb_rcgdec440:
  %v3170 = load i64, ptr %slot362, align 8
  %v3171 = load i64, ptr %slot354, align 8
  %p3172 = inttoptr i64 %v3171 to ptr
  %rgep3173 = getelementptr i8, ptr %p3172, i64 -24
  store i64 %v3170, ptr %rgep3173, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear440
bb_rcgclear440:
  %v3174 = load i64, ptr %slot350, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  store i64 0, ptr %p3175, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone440
bb_rcgdone440:
  br label %bb_rcslotdone424
bb_rcslotowner424:
  %v3176 = load i64, ptr %slot46, align 8
  store i64 %v3176, ptr %slot367, align 8
  %v3177 = load i64, ptr %slot350, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  %ld3179 = load i64, ptr %p3178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3179, ptr %slot368, align 8
  %v3180 = load i64, ptr %slot368, align 8
  %cmp3181 = icmp ne i64 %v3180, 0
  %cv3182 = zext i1 %cmp3181 to i32
  store i32 %cv3182, ptr %slot369, align 8
  %v3183 = load i32, ptr %slot369, align 8
  %cv3184 = zext i32 %v3183 to i64
  %cond3185 = icmp ne i64 %cv3184, 0
  br i1 %cond3185, label %bb_rcgnn455, label %bb_rcgdone455
bb_rcgnn455:
  %v3186 = load i64, ptr %slot368, align 8
  %op3187 = sub i64 %v3186, 16
  store i64 %op3187, ptr %slot370, align 8
  %v3188 = load i64, ptr %slot368, align 8
  %p3189 = inttoptr i64 %v3188 to ptr
  %rgep3190 = getelementptr i8, ptr %p3189, i64 -16
  %ld3191 = load i64, ptr %rgep3190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3191, ptr %slot371, align 8
  %v3192 = load i64, ptr %slot371, align 8
  %op3193 = and i64 %v3192, 4611686018427387906
  store i64 %op3193, ptr %slot372, align 8
  %v3194 = load i64, ptr %slot372, align 8
  %cmp3195 = icmp ne i64 %v3194, 0
  %cv3196 = zext i1 %cmp3195 to i32
  store i32 %cv3196, ptr %slot373, align 8
  %v3197 = load i32, ptr %slot373, align 8
  %cv3198 = zext i32 %v3197 to i64
  %cond3199 = icmp ne i64 %cv3198, 0
  br i1 %cond3199, label %bb_rcgclear455, label %bb_rcgcounted455
bb_rcgcounted455:
  %v3200 = load i64, ptr %slot368, align 8
  %op3201 = sub i64 %v3200, 32
  store i64 %op3201, ptr %slot374, align 8
  %v3202 = load i64, ptr %slot368, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  %rgep3204 = getelementptr i8, ptr %p3203, i64 -32
  %ld3205 = load i64, ptr %rgep3204, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3205, ptr %slot375, align 8
  %v3206 = load i64, ptr %slot375, align 8
  %op3207 = sub i64 %v3206, 1
  store i64 %op3207, ptr %slot376, align 8
  %v3208 = load i64, ptr %slot376, align 8
  %cmp3209 = icmp eq i64 %v3208, 0
  %cv3210 = zext i1 %cmp3209 to i32
  store i32 %cv3210, ptr %slot377, align 8
  %v3211 = load i32, ptr %slot377, align 8
  %cv3212 = zext i32 %v3211 to i64
  %cond3213 = icmp ne i64 %cv3212, 0
  br i1 %cond3213, label %bb_rcglast455, label %bb_rcgdec455
bb_rcglast455:
  %v3214 = load i64, ptr %slot368, align 8
  %op3215 = sub i64 %v3214, 24
  store i64 %op3215, ptr %slot378, align 8
  %v3216 = load i64, ptr %slot368, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  %rgep3218 = getelementptr i8, ptr %p3217, i64 -24
  %ld3219 = load i64, ptr %rgep3218, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3219, ptr %slot379, align 8
  %v3220 = load i64, ptr %slot379, align 8
  %cmp3221 = icmp ne i64 %v3220, 0
  %cv3222 = zext i1 %cmp3221 to i32
  store i32 %cv3222, ptr %slot380, align 8
  %v3223 = load i32, ptr %slot380, align 8
  %cv3224 = zext i32 %v3223 to i64
  %cond3225 = icmp ne i64 %cv3224, 0
  br i1 %cond3225, label %bb_rcgdec455, label %bb_rcgslow455
bb_rcgslow455:
  %v3226 = load i64, ptr %slot367, align 8
  %v3227 = load i64, ptr %slot350, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3226, i64 %v3227) nomerge, !dbg !138
  br label %bb_rcgdone455
bb_rcgdec455:
  %v3228 = load i64, ptr %slot376, align 8
  %v3229 = load i64, ptr %slot368, align 8
  %p3230 = inttoptr i64 %v3229 to ptr
  %rgep3231 = getelementptr i8, ptr %p3230, i64 -32
  store i64 %v3228, ptr %rgep3231, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear455
bb_rcgclear455:
  %v3232 = load i64, ptr %slot350, align 8
  %p3233 = inttoptr i64 %v3232 to ptr
  store i64 0, ptr %p3233, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone455
bb_rcgdone455:
  br label %bb_rcslotdone424
bb_rcslotdone424:
  br label %bb_rchprepared421
bb_rchtaken421:
  %v3234 = load i64, ptr %slot12, align 8
  %p3235 = inttoptr i64 %v3234 to ptr
  store i32 0, ptr %p3235, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared421
bb_rchprepared421:
  %v3236 = load i64, ptr %slot19, align 8
  %p3237 = inttoptr i64 %v3236 to ptr
  store i32 2, ptr %p3237, align 4, !alias.scope !3, !noalias !4
  %v3238 = load i64, ptr %slot18, align 8
  %p3239 = inttoptr i64 %v3238 to ptr
  store i32 1, ptr %p3239, align 4, !alias.scope !3, !noalias !4
  %v3240 = load i64, ptr %slot21, align 8
  store i64 %v3240, ptr %slot381, align 8
  %v3241 = load i64, ptr %slot27, align 8
  store i64 %v3241, ptr %slot382, align 8
  %v3242 = load i64, ptr %slot382, align 8
  %v3243 = load i64, ptr %slot381, align 8
  %p3244 = inttoptr i64 %v3242 to ptr
  %p3245 = inttoptr i64 %v3243 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3245, ptr %p3244, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3246 = load i64, ptr %slot13, align 8
  %p3247 = inttoptr i64 %v3246 to ptr
  store i32 2, ptr %p3247, align 4, !alias.scope !3, !noalias !4
  %v3248 = load i64, ptr %slot19, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %ld3250 = load i32, ptr %p3249, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3250, ptr %slot383, align 8
  %v3251 = load i32, ptr %slot383, align 8
  %v3252 = load i64, ptr %slot13, align 8
  %p3253 = inttoptr i64 %v3252 to ptr
  store i32 %v3251, ptr %p3253, align 4, !alias.scope !3, !noalias !4
  %v3254 = load i64, ptr %slot18, align 8
  %p3255 = inttoptr i64 %v3254 to ptr
  store i32 0, ptr %p3255, align 4, !alias.scope !3, !noalias !4
  %v3256 = load i64, ptr %slot12, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  store i32 1, ptr %p3257, align 4, !alias.scope !3, !noalias !4
  %v3258 = load i64, ptr %slot381, align 8
  %p3259 = inttoptr i64 %v3258 to ptr
  %ld3260 = load i64, ptr %p3259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3260, ptr %slot384, align 8
  %v3261 = load i64, ptr %slot384, align 8
  %v3262 = load i64, ptr %slot39, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  store i64 %v3261, ptr %p3263, align 8, !alias.scope !3, !noalias !4
  %v3264 = load i64, ptr %slot35, align 8
  %v3265 = load i64, ptr %slot40, align 8
  %p3266 = inttoptr i64 %v3265 to ptr
  store i64 %v3264, ptr %p3266, align 8, !alias.scope !3, !noalias !4
  %v3267 = load i64, ptr %slot40, align 8
  %p3268 = inttoptr i64 %v3267 to ptr
  %ld3269 = load i64, ptr %p3268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3269, ptr %slot385, align 8
  %v3270 = load i64, ptr %slot385, align 8
  %op3271 = add i64 %v3270, 16
  store i64 %op3271, ptr %slot386, align 8
  %v3272 = load i64, ptr %slot386, align 8
  %v3273 = load i64, ptr %slot40, align 8
  %p3274 = inttoptr i64 %v3273 to ptr
  store i64 %v3272, ptr %p3274, align 8, !alias.scope !3, !noalias !4
  %v3275 = load i64, ptr %slot14, align 8
  %p3276 = inttoptr i64 %v3275 to ptr
  %ld3277 = load i32, ptr %p3276, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3277, ptr %slot387, align 8
  %v3278 = load i32, ptr %slot387, align 8
  %cv3279 = zext i32 %v3278 to i64
  %cond3280 = icmp ne i64 %cv3279, 0
  br i1 %cond3280, label %bb_rcslotdrop475, label %bb_rcslotdone475
bb_rcslotdrop475:
  %v3281 = load i64, ptr %slot14, align 8
  %p3282 = inttoptr i64 %v3281 to ptr
  store i32 0, ptr %p3282, align 4, !alias.scope !3, !noalias !4
  %v3283 = load i64, ptr %slot22, align 8
  store i64 %v3283, ptr %slot388, align 8
  %v3284 = load i64, ptr %slot15, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  %ld3286 = load i32, ptr %p3285, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3286, ptr %slot389, align 8
  %v3287 = load i32, ptr %slot389, align 8
  %op3288 = and i32 %v3287, 28
  store i32 %op3288, ptr %slot390, align 8
  %v3289 = load i32, ptr %slot390, align 8
  %cv3290 = zext i32 %v3289 to i64
  %cond3291 = icmp ne i64 %cv3290, 0
  br i1 %cond3291, label %bb_rcslotrole475, label %bb_rcslotowner475
bb_rcslotrole475:
  %v3292 = load i64, ptr %slot46, align 8
  store i64 %v3292, ptr %slot391, align 8
  %v3293 = load i64, ptr %slot391, align 8
  %v3294 = load i64, ptr %slot388, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64 %v3293, i64 %v3294) nomerge, !dbg !140
  br label %bb_rcslotdone475
bb_rcslotowner475:
  %v3295 = load i64, ptr %slot46, align 8
  store i64 %v3295, ptr %slot392, align 8
  %v3296 = load i64, ptr %slot392, align 8
  %v3297 = load i64, ptr %slot388, align 8
  call void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64 %v3296, i64 %v3297) nomerge, !dbg !140
  br label %bb_rcslotdone475
bb_rcslotdone475:
  %v3298 = load i64, ptr %slot40, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  %ld3300 = load i64, ptr %p3299, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3300, ptr %slot393, align 8
  %v3301 = load i64, ptr %slot393, align 8
  %op3302 = add i64 %v3301, 0
  store i64 %op3302, ptr %slot394, align 8
  %v3303 = load i64, ptr %slot394, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  %ld3305 = load i64, ptr %p3304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3305, ptr %slot395, align 8
  %v3306 = load i64, ptr %slot395, align 8
  %v3307 = load i64, ptr %slot40, align 8
  %p3308 = inttoptr i64 %v3307 to ptr
  store i64 %v3306, ptr %p3308, align 8, !alias.scope !3, !noalias !4
  %v3309 = load i64, ptr %slot14, align 8
  %p3310 = inttoptr i64 %v3309 to ptr
  %ld3311 = load i32, ptr %p3310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3311, ptr %slot396, align 8
  %v3312 = load i32, ptr %slot396, align 8
  %cv3313 = zext i32 %v3312 to i64
  %cond3314 = icmp ne i64 %cv3313, 0
  br i1 %cond3314, label %bb_rcslotdrop487, label %bb_rcslotdone487
bb_rcslotdrop487:
  %v3315 = load i64, ptr %slot14, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  store i32 0, ptr %p3316, align 4, !alias.scope !3, !noalias !4
  %v3317 = load i64, ptr %slot22, align 8
  store i64 %v3317, ptr %slot397, align 8
  %v3318 = load i64, ptr %slot15, align 8
  %p3319 = inttoptr i64 %v3318 to ptr
  %ld3320 = load i32, ptr %p3319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3320, ptr %slot398, align 8
  %v3321 = load i32, ptr %slot398, align 8
  %op3322 = and i32 %v3321, 28
  store i32 %op3322, ptr %slot399, align 8
  %v3323 = load i32, ptr %slot399, align 8
  %cv3324 = zext i32 %v3323 to i64
  %cond3325 = icmp ne i64 %cv3324, 0
  br i1 %cond3325, label %bb_rcslotrole487, label %bb_rcslotowner487
bb_rcslotrole487:
  %v3326 = load i64, ptr %slot46, align 8
  store i64 %v3326, ptr %slot400, align 8
  %v3327 = load i64, ptr %slot400, align 8
  %v3328 = load i64, ptr %slot397, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64 %v3327, i64 %v3328) nomerge, !dbg !142
  br label %bb_rcslotdone487
bb_rcslotowner487:
  %v3329 = load i64, ptr %slot46, align 8
  store i64 %v3329, ptr %slot401, align 8
  %v3330 = load i64, ptr %slot401, align 8
  %v3331 = load i64, ptr %slot397, align 8
  call void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64 %v3330, i64 %v3331) nomerge, !dbg !142
  br label %bb_rcslotdone487
bb_rcslotdone487:
  %v3332 = load i64, ptr %slot40, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i64, ptr %p3333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3334, ptr %slot402, align 8
  %v3335 = load i64, ptr %slot402, align 8
  %v3336 = load i64, ptr %slot25, align 8
  %p3337 = inttoptr i64 %v3336 to ptr
  store i64 %v3335, ptr %p3337, align 8, !alias.scope !3, !noalias !4
  %v3338 = load i64, ptr %slot25, align 8
  store i64 %v3338, ptr %slot403, align 8
  %v3339 = load i64, ptr %slot14, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  %ld3341 = load i32, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3341, ptr %slot404, align 8
  %v3342 = load i64, ptr %slot15, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  %ld3344 = load i32, ptr %p3343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3344, ptr %slot405, align 8
  %v3345 = load i32, ptr %slot405, align 8
  %op3346 = and i32 %v3345, 24
  store i32 %op3346, ptr %slot405, align 8
  %v3347 = load i32, ptr %slot405, align 8
  %cmp3348 = icmp eq i32 %v3347, 0
  %cv3349 = zext i1 %cmp3348 to i32
  store i32 %cv3349, ptr %slot406, align 8
  %v3350 = load i32, ptr %slot404, align 8
  %v3351 = load i32, ptr %slot406, align 8
  %op3352 = and i32 %v3350, %v3351
  store i32 %op3352, ptr %slot407, align 8
  %v3353 = load i64, ptr %slot47, align 8
  store i64 %v3353, ptr %slot408, align 8
  %v3354 = load i32, ptr %slot407, align 8
  %op3355 = mul i32 %v3354, 4
  store i32 %op3355, ptr %slot409, align 8
  %v3356 = load i32, ptr %slot409, align 8
  %op3357 = or i32 %v3356, 0
  store i32 %op3357, ptr %slot410, align 8
  %v3358 = load i64, ptr %slot27, align 8
  store i64 %v3358, ptr %slot411, align 8
  %v3359 = load i32, ptr %slot410, align 8
  %op3360 = and i32 %v3359, 3
  store i32 %op3360, ptr %slot412, align 8
  %v3361 = load i32, ptr %slot412, align 8
  %cv3362 = zext i32 %v3361 to i64
  %cond3363 = icmp ne i64 %cv3362, 0
  br i1 %cond3363, label %bb_rcgpublishslow507, label %bb_rcgpublishmode507
bb_rcgpublishmode507:
  %v3364 = load i64, ptr %slot403, align 8
  %p3365 = inttoptr i64 %v3364 to ptr
  %ld3366 = load i64, ptr %p3365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3366, ptr %slot413, align 8
  %v3367 = load i64, ptr %slot413, align 8
  %cmp3368 = icmp ne i64 %v3367, 0
  %cv3369 = zext i1 %cmp3368 to i32
  store i32 %cv3369, ptr %slot414, align 8
  %v3370 = load i32, ptr %slot414, align 8
  %cv3371 = zext i32 %v3370 to i64
  %cond3372 = icmp ne i64 %cv3371, 0
  br i1 %cond3372, label %bb_rcgpublishnn507, label %bb_rcgpublishstore507
bb_rcgpublishnn507:
  %v3373 = load i64, ptr %slot413, align 8
  %op3374 = sub i64 %v3373, 16
  store i64 %op3374, ptr %slot415, align 8
  %v3375 = load i64, ptr %slot413, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  %rgep3377 = getelementptr i8, ptr %p3376, i64 -16
  %ld3378 = load i64, ptr %rgep3377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3378, ptr %slot416, align 8
  %v3379 = load i64, ptr %slot416, align 8
  %op3380 = and i64 %v3379, 5764607523034234880
  store i64 %op3380, ptr %slot417, align 8
  %v3381 = load i64, ptr %slot417, align 8
  %cmp3382 = icmp ne i64 %v3381, 0
  %cv3383 = zext i1 %cmp3382 to i32
  store i32 %cv3383, ptr %slot418, align 8
  %v3384 = load i32, ptr %slot418, align 8
  %cv3385 = zext i32 %v3384 to i64
  %cond3386 = icmp ne i64 %cv3385, 0
  br i1 %cond3386, label %bb_rcgpublishslow507, label %bb_rcgpublishshare507
bb_rcgpublishshare507:
  %v3387 = load i32, ptr %slot410, align 8
  %op3388 = and i32 %v3387, 4
  store i32 %op3388, ptr %slot419, align 8
  %v3389 = load i64, ptr %slot416, align 8
  %op3390 = and i64 %v3389, 2
  store i64 %op3390, ptr %slot420, align 8
  %v3391 = load i32, ptr %slot419, align 8
  %cv3392 = zext i32 %v3391 to i64
  %cond3393 = icmp ne i64 %cv3392, 0
  br i1 %cond3393, label %bb_rcgpublishmarkcheck507, label %bb_rcgpublishordinary507
bb_rcgpublishordinary507:
  %v3394 = load i64, ptr %slot420, align 8
  %cmp3395 = icmp ne i64 %v3394, 0
  %cv3396 = zext i1 %cmp3395 to i32
  store i32 %cv3396, ptr %slot421, align 8
  %v3397 = load i32, ptr %slot421, align 8
  %cv3398 = zext i32 %v3397 to i64
  %cond3399 = icmp ne i64 %cv3398, 0
  br i1 %cond3399, label %bb_rcgpublishmarkcheck507, label %bb_rcgpublishcapacity507
bb_rcgpublishcapacity507:
  %v3400 = load i64, ptr %slot413, align 8
  %op3401 = sub i64 %v3400, 32
  store i64 %op3401, ptr %slot422, align 8
  %v3402 = load i64, ptr %slot413, align 8
  %p3403 = inttoptr i64 %v3402 to ptr
  %rgep3404 = getelementptr i8, ptr %p3403, i64 -32
  %ld3405 = load i64, ptr %rgep3404, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3405, ptr %slot423, align 8
  %v3406 = load i64, ptr %slot423, align 8
  %op3407 = add i64 %v3406, 1
  store i64 %op3407, ptr %slot424, align 8
  %v3408 = load i64, ptr %slot424, align 8
  %cmp3409 = icmp eq i64 %v3408, 0
  %cv3410 = zext i1 %cmp3409 to i32
  store i32 %cv3410, ptr %slot425, align 8
  %v3411 = load i32, ptr %slot425, align 8
  %cv3412 = zext i32 %v3411 to i64
  %cond3413 = icmp ne i64 %cv3412, 0
  br i1 %cond3413, label %bb_rcgpublishslow507, label %bb_rcgpublishacquire507
bb_rcgpublishacquire507:
  %v3414 = load i64, ptr %slot424, align 8
  %v3415 = load i64, ptr %slot413, align 8
  %p3416 = inttoptr i64 %v3415 to ptr
  %rgep3417 = getelementptr i8, ptr %p3416, i64 -32
  store i64 %v3414, ptr %rgep3417, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgpublishmarkcheck507
bb_rcgpublishmarkcheck507:
  %v3418 = load i64, ptr %slot416, align 8
  %op3419 = and i64 %v3418, 2305843009213693954
  store i64 %op3419, ptr %slot426, align 8
  %v3420 = load i64, ptr %slot426, align 8
  %cmp3421 = icmp ne i64 %v3420, 0
  %cv3422 = zext i1 %cmp3421 to i32
  store i32 %cv3422, ptr %slot427, align 8
  %v3423 = load i32, ptr %slot427, align 8
  %cv3424 = zext i32 %v3423 to i64
  %cond3425 = icmp ne i64 %cv3424, 0
  br i1 %cond3425, label %bb_rcgpublishstore507, label %bb_rcgpublishmark507
bb_rcgpublishmark507:
  %v3426 = load i64, ptr %slot416, align 8
  %op3427 = or i64 %v3426, 2305843009213693952
  store i64 %op3427, ptr %slot428, align 8
  %v3428 = load i64, ptr %slot428, align 8
  %v3429 = load i64, ptr %slot413, align 8
  %p3430 = inttoptr i64 %v3429 to ptr
  %rgep3431 = getelementptr i8, ptr %p3430, i64 -16
  store i64 %v3428, ptr %rgep3431, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgpublishstore507
bb_rcgpublishstore507:
  %v3432 = load i64, ptr %slot413, align 8
  %v3433 = load i64, ptr %slot411, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  store i64 %v3432, ptr %p3434, align 8, !alias.scope !3, !noalias !4
  %v3435 = load i32, ptr %slot410, align 8
  %op3436 = and i32 %v3435, 4
  store i32 %op3436, ptr %slot429, align 8
  %v3437 = load i32, ptr %slot429, align 8
  %cv3438 = zext i32 %v3437 to i64
  %cond3439 = icmp ne i64 %cv3438, 0
  br i1 %cond3439, label %bb_rcgpublishtake507, label %bb_rcgpublished507
bb_rcgpublishtake507:
  %v3440 = load i64, ptr %slot403, align 8
  %p3441 = inttoptr i64 %v3440 to ptr
  store i64 0, ptr %p3441, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgpublished507
bb_rcgpublishslow507:
  %v3442 = load i64, ptr %slot46, align 8
  %v3443 = load i64, ptr %slot411, align 8
  %v3444 = load i64, ptr %slot403, align 8
  %v3445 = load i64, ptr %slot408, align 8
  %cv3446 = trunc i64 %v3445 to i32
  %v3447 = load i32, ptr %slot410, align 8
  %call3448 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish(i64 %v3442, i64 %v3443, i64 %v3444, i32 %cv3446, i32 %v3447) nomerge, !dbg !144
  store i32 %call3448, ptr %slot430, align 8
  %v3449 = load i32, ptr %slot430, align 8
  %cv3450 = zext i32 %v3449 to i64
  %cond3451 = icmp ne i64 %cv3450, 0
  br i1 %cond3451, label %bb_rcsuccess527, label %bb_rcfailure527
bb_rcfailure527:
  %v3452 = load i64, ptr %slot46, align 8
  %p3453 = inttoptr i64 %v3452 to ptr
  %call3454 = call i32 @myl_rc_take_failure(ptr %p3453) nomerge, !dbg !144
  store i32 %call3454, ptr %slot431, align 8
  %v3455 = load i64, ptr %slot1, align 8
  %p3456 = inttoptr i64 %v3455 to ptr
  %v3457 = load i32, ptr %slot431, align 8
  %call3458 = call i32 @myl_qbe_rc_status(ptr %p3456, i32 %v3457) nomerge, !dbg !144
  store i32 %call3458, ptr %slot432, align 8
  br label %bb_failure
bb_rcsuccess527:
  br label %bb_rcgpublished507
bb_rcgpublished507:
  %v3459 = load i32, ptr %slot407, align 8
  %cv3460 = zext i32 %v3459 to i64
  %cond3461 = icmp ne i64 %cv3460, 0
  br i1 %cond3461, label %bb_rchtaken530, label %bb_rchcopied530
bb_rchcopied530:
  %v3462 = load i64, ptr %slot14, align 8
  %p3463 = inttoptr i64 %v3462 to ptr
  %ld3464 = load i32, ptr %p3463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3464, ptr %slot433, align 8
  %v3465 = load i32, ptr %slot433, align 8
  %cv3466 = zext i32 %v3465 to i64
  %cond3467 = icmp ne i64 %cv3466, 0
  br i1 %cond3467, label %bb_rcslotdrop533, label %bb_rcslotdone533
bb_rcslotdrop533:
  %v3468 = load i64, ptr %slot14, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  store i32 0, ptr %p3469, align 4, !alias.scope !3, !noalias !4
  %v3470 = load i64, ptr %slot22, align 8
  store i64 %v3470, ptr %slot434, align 8
  %v3471 = load i64, ptr %slot15, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  %ld3473 = load i32, ptr %p3472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3473, ptr %slot435, align 8
  %v3474 = load i32, ptr %slot435, align 8
  %op3475 = and i32 %v3474, 28
  store i32 %op3475, ptr %slot436, align 8
  %v3476 = load i32, ptr %slot436, align 8
  %cv3477 = zext i32 %v3476 to i64
  %cond3478 = icmp ne i64 %cv3477, 0
  br i1 %cond3478, label %bb_rcslotrole533, label %bb_rcslotowner533
bb_rcslotrole533:
  %v3479 = load i64, ptr %slot46, align 8
  store i64 %v3479, ptr %slot437, align 8
  %v3480 = load i64, ptr %slot434, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  %ld3482 = load i64, ptr %p3481, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3482, ptr %slot438, align 8
  %v3483 = load i64, ptr %slot438, align 8
  %cmp3484 = icmp ne i64 %v3483, 0
  %cv3485 = zext i1 %cmp3484 to i32
  store i32 %cv3485, ptr %slot439, align 8
  %v3486 = load i32, ptr %slot439, align 8
  %cv3487 = zext i32 %v3486 to i64
  %cond3488 = icmp ne i64 %cv3487, 0
  br i1 %cond3488, label %bb_rcgnn549, label %bb_rcgdone549
bb_rcgnn549:
  %v3489 = load i64, ptr %slot438, align 8
  %op3490 = sub i64 %v3489, 16
  store i64 %op3490, ptr %slot440, align 8
  %v3491 = load i64, ptr %slot438, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %rgep3493 = getelementptr i8, ptr %p3492, i64 -16
  %ld3494 = load i64, ptr %rgep3493, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3494, ptr %slot441, align 8
  %v3495 = load i64, ptr %slot441, align 8
  %op3496 = and i64 %v3495, 4611686018427387906
  store i64 %op3496, ptr %slot442, align 8
  %v3497 = load i64, ptr %slot442, align 8
  %cmp3498 = icmp ne i64 %v3497, 0
  %cv3499 = zext i1 %cmp3498 to i32
  store i32 %cv3499, ptr %slot443, align 8
  %v3500 = load i32, ptr %slot443, align 8
  %cv3501 = zext i32 %v3500 to i64
  %cond3502 = icmp ne i64 %cv3501, 0
  br i1 %cond3502, label %bb_rcgclear549, label %bb_rcgcounted549
bb_rcgcounted549:
  %v3503 = load i64, ptr %slot438, align 8
  %op3504 = sub i64 %v3503, 24
  store i64 %op3504, ptr %slot444, align 8
  %v3505 = load i64, ptr %slot438, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  %rgep3507 = getelementptr i8, ptr %p3506, i64 -24
  %ld3508 = load i64, ptr %rgep3507, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3508, ptr %slot445, align 8
  %v3509 = load i64, ptr %slot445, align 8
  %op3510 = sub i64 %v3509, 1
  store i64 %op3510, ptr %slot446, align 8
  %v3511 = load i64, ptr %slot446, align 8
  %cmp3512 = icmp eq i64 %v3511, 0
  %cv3513 = zext i1 %cmp3512 to i32
  store i32 %cv3513, ptr %slot447, align 8
  %v3514 = load i32, ptr %slot447, align 8
  %cv3515 = zext i32 %v3514 to i64
  %cond3516 = icmp ne i64 %cv3515, 0
  br i1 %cond3516, label %bb_rcglast549, label %bb_rcgdec549
bb_rcglast549:
  %v3517 = load i64, ptr %slot438, align 8
  %op3518 = sub i64 %v3517, 32
  store i64 %op3518, ptr %slot448, align 8
  %v3519 = load i64, ptr %slot438, align 8
  %p3520 = inttoptr i64 %v3519 to ptr
  %rgep3521 = getelementptr i8, ptr %p3520, i64 -32
  %ld3522 = load i64, ptr %rgep3521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3522, ptr %slot449, align 8
  %v3523 = load i64, ptr %slot449, align 8
  %cmp3524 = icmp ne i64 %v3523, 0
  %cv3525 = zext i1 %cmp3524 to i32
  store i32 %cv3525, ptr %slot450, align 8
  %v3526 = load i32, ptr %slot450, align 8
  %cv3527 = zext i32 %v3526 to i64
  %cond3528 = icmp ne i64 %cv3527, 0
  br i1 %cond3528, label %bb_rcgdec549, label %bb_rcgslow549
bb_rcgslow549:
  %v3529 = load i64, ptr %slot437, align 8
  %v3530 = load i64, ptr %slot434, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3529, i64 %v3530) nomerge, !dbg !144
  br label %bb_rcgdone549
bb_rcgdec549:
  %v3531 = load i64, ptr %slot446, align 8
  %v3532 = load i64, ptr %slot438, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  %rgep3534 = getelementptr i8, ptr %p3533, i64 -24
  store i64 %v3531, ptr %rgep3534, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear549
bb_rcgclear549:
  %v3535 = load i64, ptr %slot434, align 8
  %p3536 = inttoptr i64 %v3535 to ptr
  store i64 0, ptr %p3536, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone549
bb_rcgdone549:
  br label %bb_rcslotdone533
bb_rcslotowner533:
  %v3537 = load i64, ptr %slot46, align 8
  store i64 %v3537, ptr %slot451, align 8
  %v3538 = load i64, ptr %slot434, align 8
  %p3539 = inttoptr i64 %v3538 to ptr
  %ld3540 = load i64, ptr %p3539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3540, ptr %slot452, align 8
  %v3541 = load i64, ptr %slot452, align 8
  %cmp3542 = icmp ne i64 %v3541, 0
  %cv3543 = zext i1 %cmp3542 to i32
  store i32 %cv3543, ptr %slot453, align 8
  %v3544 = load i32, ptr %slot453, align 8
  %cv3545 = zext i32 %v3544 to i64
  %cond3546 = icmp ne i64 %cv3545, 0
  br i1 %cond3546, label %bb_rcgnn564, label %bb_rcgdone564
bb_rcgnn564:
  %v3547 = load i64, ptr %slot452, align 8
  %op3548 = sub i64 %v3547, 16
  store i64 %op3548, ptr %slot454, align 8
  %v3549 = load i64, ptr %slot452, align 8
  %p3550 = inttoptr i64 %v3549 to ptr
  %rgep3551 = getelementptr i8, ptr %p3550, i64 -16
  %ld3552 = load i64, ptr %rgep3551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3552, ptr %slot455, align 8
  %v3553 = load i64, ptr %slot455, align 8
  %op3554 = and i64 %v3553, 4611686018427387906
  store i64 %op3554, ptr %slot456, align 8
  %v3555 = load i64, ptr %slot456, align 8
  %cmp3556 = icmp ne i64 %v3555, 0
  %cv3557 = zext i1 %cmp3556 to i32
  store i32 %cv3557, ptr %slot457, align 8
  %v3558 = load i32, ptr %slot457, align 8
  %cv3559 = zext i32 %v3558 to i64
  %cond3560 = icmp ne i64 %cv3559, 0
  br i1 %cond3560, label %bb_rcgclear564, label %bb_rcgcounted564
bb_rcgcounted564:
  %v3561 = load i64, ptr %slot452, align 8
  %op3562 = sub i64 %v3561, 32
  store i64 %op3562, ptr %slot458, align 8
  %v3563 = load i64, ptr %slot452, align 8
  %p3564 = inttoptr i64 %v3563 to ptr
  %rgep3565 = getelementptr i8, ptr %p3564, i64 -32
  %ld3566 = load i64, ptr %rgep3565, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3566, ptr %slot459, align 8
  %v3567 = load i64, ptr %slot459, align 8
  %op3568 = sub i64 %v3567, 1
  store i64 %op3568, ptr %slot460, align 8
  %v3569 = load i64, ptr %slot460, align 8
  %cmp3570 = icmp eq i64 %v3569, 0
  %cv3571 = zext i1 %cmp3570 to i32
  store i32 %cv3571, ptr %slot461, align 8
  %v3572 = load i32, ptr %slot461, align 8
  %cv3573 = zext i32 %v3572 to i64
  %cond3574 = icmp ne i64 %cv3573, 0
  br i1 %cond3574, label %bb_rcglast564, label %bb_rcgdec564
bb_rcglast564:
  %v3575 = load i64, ptr %slot452, align 8
  %op3576 = sub i64 %v3575, 24
  store i64 %op3576, ptr %slot462, align 8
  %v3577 = load i64, ptr %slot452, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  %rgep3579 = getelementptr i8, ptr %p3578, i64 -24
  %ld3580 = load i64, ptr %rgep3579, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3580, ptr %slot463, align 8
  %v3581 = load i64, ptr %slot463, align 8
  %cmp3582 = icmp ne i64 %v3581, 0
  %cv3583 = zext i1 %cmp3582 to i32
  store i32 %cv3583, ptr %slot464, align 8
  %v3584 = load i32, ptr %slot464, align 8
  %cv3585 = zext i32 %v3584 to i64
  %cond3586 = icmp ne i64 %cv3585, 0
  br i1 %cond3586, label %bb_rcgdec564, label %bb_rcgslow564
bb_rcgslow564:
  %v3587 = load i64, ptr %slot451, align 8
  %v3588 = load i64, ptr %slot434, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3587, i64 %v3588) nomerge, !dbg !144
  br label %bb_rcgdone564
bb_rcgdec564:
  %v3589 = load i64, ptr %slot460, align 8
  %v3590 = load i64, ptr %slot452, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  %rgep3592 = getelementptr i8, ptr %p3591, i64 -32
  store i64 %v3589, ptr %rgep3592, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear564
bb_rcgclear564:
  %v3593 = load i64, ptr %slot434, align 8
  %p3594 = inttoptr i64 %v3593 to ptr
  store i64 0, ptr %p3594, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone564
bb_rcgdone564:
  br label %bb_rcslotdone533
bb_rcslotdone533:
  br label %bb_rchprepared530
bb_rchtaken530:
  %v3595 = load i64, ptr %slot14, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  store i32 0, ptr %p3596, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared530
bb_rchprepared530:
  %v3597 = load i64, ptr %slot19, align 8
  %p3598 = inttoptr i64 %v3597 to ptr
  store i32 2, ptr %p3598, align 4, !alias.scope !3, !noalias !4
  %v3599 = load i64, ptr %slot18, align 8
  %p3600 = inttoptr i64 %v3599 to ptr
  store i32 1, ptr %p3600, align 4, !alias.scope !3, !noalias !4
  %v3601 = load i64, ptr %slot22, align 8
  store i64 %v3601, ptr %slot465, align 8
  %v3602 = load i64, ptr %slot27, align 8
  store i64 %v3602, ptr %slot466, align 8
  %v3603 = load i64, ptr %slot466, align 8
  %v3604 = load i64, ptr %slot465, align 8
  %p3605 = inttoptr i64 %v3603 to ptr
  %p3606 = inttoptr i64 %v3604 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3606, ptr %p3605, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3607 = load i64, ptr %slot15, align 8
  %p3608 = inttoptr i64 %v3607 to ptr
  store i32 2, ptr %p3608, align 4, !alias.scope !3, !noalias !4
  %v3609 = load i64, ptr %slot19, align 8
  %p3610 = inttoptr i64 %v3609 to ptr
  %ld3611 = load i32, ptr %p3610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3611, ptr %slot467, align 8
  %v3612 = load i32, ptr %slot467, align 8
  %v3613 = load i64, ptr %slot15, align 8
  %p3614 = inttoptr i64 %v3613 to ptr
  store i32 %v3612, ptr %p3614, align 4, !alias.scope !3, !noalias !4
  %v3615 = load i64, ptr %slot18, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  store i32 0, ptr %p3616, align 4, !alias.scope !3, !noalias !4
  %v3617 = load i64, ptr %slot14, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  store i32 1, ptr %p3618, align 4, !alias.scope !3, !noalias !4
  %v3619 = load i64, ptr %slot465, align 8
  %p3620 = inttoptr i64 %v3619 to ptr
  %ld3621 = load i64, ptr %p3620, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3621, ptr %slot468, align 8
  %v3622 = load i64, ptr %slot468, align 8
  %v3623 = load i64, ptr %slot40, align 8
  %p3624 = inttoptr i64 %v3623 to ptr
  store i64 %v3622, ptr %p3624, align 8, !alias.scope !3, !noalias !4
  %v3625 = load i64, ptr %slot32, align 8
  %v3626 = load i64, ptr %slot41, align 8
  %p3627 = inttoptr i64 %v3626 to ptr
  store i64 %v3625, ptr %p3627, align 8, !alias.scope !3, !noalias !4
  %v3628 = load i64, ptr %slot41, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  %ld3630 = load i64, ptr %p3629, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3630, ptr %slot469, align 8
  %v3631 = load i64, ptr %slot469, align 8
  %op3632 = add i64 %v3631, 8
  store i64 %op3632, ptr %slot470, align 8
  %v3633 = load i64, ptr %slot470, align 8
  %p3634 = inttoptr i64 %v3633 to ptr
  %ld3635 = load i64, ptr %p3634, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3635, ptr %slot471, align 8
  %v3636 = load i64, ptr %slot471, align 8
  %v3637 = load i64, ptr %slot41, align 8
  %p3638 = inttoptr i64 %v3637 to ptr
  store i64 %v3636, ptr %p3638, align 8, !alias.scope !3, !noalias !4
  %v3639 = load i64, ptr %slot16, align 8
  %p3640 = inttoptr i64 %v3639 to ptr
  %ld3641 = load i32, ptr %p3640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3641, ptr %slot472, align 8
  %v3642 = load i32, ptr %slot472, align 8
  %cv3643 = zext i32 %v3642 to i64
  %cond3644 = icmp ne i64 %cv3643, 0
  br i1 %cond3644, label %bb_rcslotdrop585, label %bb_rcslotdone585
bb_rcslotdrop585:
  %v3645 = load i64, ptr %slot16, align 8
  %p3646 = inttoptr i64 %v3645 to ptr
  store i32 0, ptr %p3646, align 4, !alias.scope !3, !noalias !4
  %v3647 = load i64, ptr %slot23, align 8
  store i64 %v3647, ptr %slot473, align 8
  %v3648 = load i64, ptr %slot17, align 8
  %p3649 = inttoptr i64 %v3648 to ptr
  %ld3650 = load i32, ptr %p3649, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3650, ptr %slot474, align 8
  %v3651 = load i32, ptr %slot474, align 8
  %op3652 = and i32 %v3651, 28
  store i32 %op3652, ptr %slot475, align 8
  %v3653 = load i32, ptr %slot475, align 8
  %cv3654 = zext i32 %v3653 to i64
  %cond3655 = icmp ne i64 %cv3654, 0
  br i1 %cond3655, label %bb_rcslotrole585, label %bb_rcslotowner585
bb_rcslotrole585:
  %v3656 = load i64, ptr %slot46, align 8
  store i64 %v3656, ptr %slot476, align 8
  %v3657 = load i64, ptr %slot476, align 8
  %v3658 = load i64, ptr %slot473, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64 %v3657, i64 %v3658) nomerge, !dbg !146
  br label %bb_rcslotdone585
bb_rcslotowner585:
  %v3659 = load i64, ptr %slot46, align 8
  store i64 %v3659, ptr %slot477, align 8
  %v3660 = load i64, ptr %slot477, align 8
  %v3661 = load i64, ptr %slot473, align 8
  call void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64 %v3660, i64 %v3661) nomerge, !dbg !146
  br label %bb_rcslotdone585
bb_rcslotdone585:
  %v3662 = load i64, ptr %slot41, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  %ld3664 = load i64, ptr %p3663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3664, ptr %slot478, align 8
  %v3665 = load i64, ptr %slot478, align 8
  %v3666 = load i64, ptr %slot26, align 8
  %p3667 = inttoptr i64 %v3666 to ptr
  store i64 %v3665, ptr %p3667, align 8, !alias.scope !3, !noalias !4
  %v3668 = load i64, ptr %slot26, align 8
  store i64 %v3668, ptr %slot479, align 8
  %v3669 = load i64, ptr %slot16, align 8
  %p3670 = inttoptr i64 %v3669 to ptr
  %ld3671 = load i32, ptr %p3670, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3671, ptr %slot480, align 8
  %v3672 = load i64, ptr %slot17, align 8
  %p3673 = inttoptr i64 %v3672 to ptr
  %ld3674 = load i32, ptr %p3673, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3674, ptr %slot481, align 8
  %v3675 = load i32, ptr %slot481, align 8
  %op3676 = and i32 %v3675, 24
  store i32 %op3676, ptr %slot481, align 8
  %v3677 = load i32, ptr %slot481, align 8
  %cmp3678 = icmp eq i32 %v3677, 0
  %cv3679 = zext i1 %cmp3678 to i32
  store i32 %cv3679, ptr %slot482, align 8
  %v3680 = load i32, ptr %slot480, align 8
  %v3681 = load i32, ptr %slot482, align 8
  %op3682 = and i32 %v3680, %v3681
  store i32 %op3682, ptr %slot483, align 8
  %v3683 = load i64, ptr %slot47, align 8
  store i64 %v3683, ptr %slot484, align 8
  %v3684 = load i32, ptr %slot483, align 8
  %op3685 = mul i32 %v3684, 4
  store i32 %op3685, ptr %slot485, align 8
  %v3686 = load i32, ptr %slot485, align 8
  %op3687 = or i32 %v3686, 0
  store i32 %op3687, ptr %slot486, align 8
  %v3688 = load i64, ptr %slot27, align 8
  store i64 %v3688, ptr %slot487, align 8
  %v3689 = load i32, ptr %slot486, align 8
  %op3690 = and i32 %v3689, 3
  store i32 %op3690, ptr %slot488, align 8
  %v3691 = load i32, ptr %slot488, align 8
  %cv3692 = zext i32 %v3691 to i64
  %cond3693 = icmp ne i64 %cv3692, 0
  br i1 %cond3693, label %bb_rcgpublishslow605, label %bb_rcgpublishmode605
bb_rcgpublishmode605:
  %v3694 = load i64, ptr %slot479, align 8
  %p3695 = inttoptr i64 %v3694 to ptr
  %ld3696 = load i64, ptr %p3695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3696, ptr %slot489, align 8
  %v3697 = load i64, ptr %slot489, align 8
  %cmp3698 = icmp ne i64 %v3697, 0
  %cv3699 = zext i1 %cmp3698 to i32
  store i32 %cv3699, ptr %slot490, align 8
  %v3700 = load i32, ptr %slot490, align 8
  %cv3701 = zext i32 %v3700 to i64
  %cond3702 = icmp ne i64 %cv3701, 0
  br i1 %cond3702, label %bb_rcgpublishnn605, label %bb_rcgpublishstore605
bb_rcgpublishnn605:
  %v3703 = load i64, ptr %slot489, align 8
  %op3704 = sub i64 %v3703, 16
  store i64 %op3704, ptr %slot491, align 8
  %v3705 = load i64, ptr %slot489, align 8
  %p3706 = inttoptr i64 %v3705 to ptr
  %rgep3707 = getelementptr i8, ptr %p3706, i64 -16
  %ld3708 = load i64, ptr %rgep3707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3708, ptr %slot492, align 8
  %v3709 = load i64, ptr %slot492, align 8
  %op3710 = and i64 %v3709, 5764607523034234880
  store i64 %op3710, ptr %slot493, align 8
  %v3711 = load i64, ptr %slot493, align 8
  %cmp3712 = icmp ne i64 %v3711, 0
  %cv3713 = zext i1 %cmp3712 to i32
  store i32 %cv3713, ptr %slot494, align 8
  %v3714 = load i32, ptr %slot494, align 8
  %cv3715 = zext i32 %v3714 to i64
  %cond3716 = icmp ne i64 %cv3715, 0
  br i1 %cond3716, label %bb_rcgpublishslow605, label %bb_rcgpublishshare605
bb_rcgpublishshare605:
  %v3717 = load i32, ptr %slot486, align 8
  %op3718 = and i32 %v3717, 4
  store i32 %op3718, ptr %slot495, align 8
  %v3719 = load i64, ptr %slot492, align 8
  %op3720 = and i64 %v3719, 2
  store i64 %op3720, ptr %slot496, align 8
  %v3721 = load i32, ptr %slot495, align 8
  %cv3722 = zext i32 %v3721 to i64
  %cond3723 = icmp ne i64 %cv3722, 0
  br i1 %cond3723, label %bb_rcgpublishmarkcheck605, label %bb_rcgpublishordinary605
bb_rcgpublishordinary605:
  %v3724 = load i64, ptr %slot496, align 8
  %cmp3725 = icmp ne i64 %v3724, 0
  %cv3726 = zext i1 %cmp3725 to i32
  store i32 %cv3726, ptr %slot497, align 8
  %v3727 = load i32, ptr %slot497, align 8
  %cv3728 = zext i32 %v3727 to i64
  %cond3729 = icmp ne i64 %cv3728, 0
  br i1 %cond3729, label %bb_rcgpublishmarkcheck605, label %bb_rcgpublishcapacity605
bb_rcgpublishcapacity605:
  %v3730 = load i64, ptr %slot489, align 8
  %op3731 = sub i64 %v3730, 32
  store i64 %op3731, ptr %slot498, align 8
  %v3732 = load i64, ptr %slot489, align 8
  %p3733 = inttoptr i64 %v3732 to ptr
  %rgep3734 = getelementptr i8, ptr %p3733, i64 -32
  %ld3735 = load i64, ptr %rgep3734, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3735, ptr %slot499, align 8
  %v3736 = load i64, ptr %slot499, align 8
  %op3737 = add i64 %v3736, 1
  store i64 %op3737, ptr %slot500, align 8
  %v3738 = load i64, ptr %slot500, align 8
  %cmp3739 = icmp eq i64 %v3738, 0
  %cv3740 = zext i1 %cmp3739 to i32
  store i32 %cv3740, ptr %slot501, align 8
  %v3741 = load i32, ptr %slot501, align 8
  %cv3742 = zext i32 %v3741 to i64
  %cond3743 = icmp ne i64 %cv3742, 0
  br i1 %cond3743, label %bb_rcgpublishslow605, label %bb_rcgpublishacquire605
bb_rcgpublishacquire605:
  %v3744 = load i64, ptr %slot500, align 8
  %v3745 = load i64, ptr %slot489, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  %rgep3747 = getelementptr i8, ptr %p3746, i64 -32
  store i64 %v3744, ptr %rgep3747, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgpublishmarkcheck605
bb_rcgpublishmarkcheck605:
  %v3748 = load i64, ptr %slot492, align 8
  %op3749 = and i64 %v3748, 2305843009213693954
  store i64 %op3749, ptr %slot502, align 8
  %v3750 = load i64, ptr %slot502, align 8
  %cmp3751 = icmp ne i64 %v3750, 0
  %cv3752 = zext i1 %cmp3751 to i32
  store i32 %cv3752, ptr %slot503, align 8
  %v3753 = load i32, ptr %slot503, align 8
  %cv3754 = zext i32 %v3753 to i64
  %cond3755 = icmp ne i64 %cv3754, 0
  br i1 %cond3755, label %bb_rcgpublishstore605, label %bb_rcgpublishmark605
bb_rcgpublishmark605:
  %v3756 = load i64, ptr %slot492, align 8
  %op3757 = or i64 %v3756, 2305843009213693952
  store i64 %op3757, ptr %slot504, align 8
  %v3758 = load i64, ptr %slot504, align 8
  %v3759 = load i64, ptr %slot489, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  %rgep3761 = getelementptr i8, ptr %p3760, i64 -16
  store i64 %v3758, ptr %rgep3761, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgpublishstore605
bb_rcgpublishstore605:
  %v3762 = load i64, ptr %slot489, align 8
  %v3763 = load i64, ptr %slot487, align 8
  %p3764 = inttoptr i64 %v3763 to ptr
  store i64 %v3762, ptr %p3764, align 8, !alias.scope !3, !noalias !4
  %v3765 = load i32, ptr %slot486, align 8
  %op3766 = and i32 %v3765, 4
  store i32 %op3766, ptr %slot505, align 8
  %v3767 = load i32, ptr %slot505, align 8
  %cv3768 = zext i32 %v3767 to i64
  %cond3769 = icmp ne i64 %cv3768, 0
  br i1 %cond3769, label %bb_rcgpublishtake605, label %bb_rcgpublished605
bb_rcgpublishtake605:
  %v3770 = load i64, ptr %slot479, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  store i64 0, ptr %p3771, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgpublished605
bb_rcgpublishslow605:
  %v3772 = load i64, ptr %slot46, align 8
  %v3773 = load i64, ptr %slot487, align 8
  %v3774 = load i64, ptr %slot479, align 8
  %v3775 = load i64, ptr %slot484, align 8
  %cv3776 = trunc i64 %v3775 to i32
  %v3777 = load i32, ptr %slot486, align 8
  %call3778 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish(i64 %v3772, i64 %v3773, i64 %v3774, i32 %cv3776, i32 %v3777) nomerge, !dbg !148
  store i32 %call3778, ptr %slot506, align 8
  %v3779 = load i32, ptr %slot506, align 8
  %cv3780 = zext i32 %v3779 to i64
  %cond3781 = icmp ne i64 %cv3780, 0
  br i1 %cond3781, label %bb_rcsuccess625, label %bb_rcfailure625
bb_rcfailure625:
  %v3782 = load i64, ptr %slot46, align 8
  %p3783 = inttoptr i64 %v3782 to ptr
  %call3784 = call i32 @myl_rc_take_failure(ptr %p3783) nomerge, !dbg !148
  store i32 %call3784, ptr %slot507, align 8
  %v3785 = load i64, ptr %slot1, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %v3787 = load i32, ptr %slot507, align 8
  %call3788 = call i32 @myl_qbe_rc_status(ptr %p3786, i32 %v3787) nomerge, !dbg !148
  store i32 %call3788, ptr %slot508, align 8
  br label %bb_failure
bb_rcsuccess625:
  br label %bb_rcgpublished605
bb_rcgpublished605:
  %v3789 = load i32, ptr %slot483, align 8
  %cv3790 = zext i32 %v3789 to i64
  %cond3791 = icmp ne i64 %cv3790, 0
  br i1 %cond3791, label %bb_rchtaken628, label %bb_rchcopied628
bb_rchcopied628:
  %v3792 = load i64, ptr %slot16, align 8
  %p3793 = inttoptr i64 %v3792 to ptr
  %ld3794 = load i32, ptr %p3793, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3794, ptr %slot509, align 8
  %v3795 = load i32, ptr %slot509, align 8
  %cv3796 = zext i32 %v3795 to i64
  %cond3797 = icmp ne i64 %cv3796, 0
  br i1 %cond3797, label %bb_rcslotdrop631, label %bb_rcslotdone631
bb_rcslotdrop631:
  %v3798 = load i64, ptr %slot16, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  store i32 0, ptr %p3799, align 4, !alias.scope !3, !noalias !4
  %v3800 = load i64, ptr %slot23, align 8
  store i64 %v3800, ptr %slot510, align 8
  %v3801 = load i64, ptr %slot17, align 8
  %p3802 = inttoptr i64 %v3801 to ptr
  %ld3803 = load i32, ptr %p3802, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3803, ptr %slot511, align 8
  %v3804 = load i32, ptr %slot511, align 8
  %op3805 = and i32 %v3804, 28
  store i32 %op3805, ptr %slot512, align 8
  %v3806 = load i32, ptr %slot512, align 8
  %cv3807 = zext i32 %v3806 to i64
  %cond3808 = icmp ne i64 %cv3807, 0
  br i1 %cond3808, label %bb_rcslotrole631, label %bb_rcslotowner631
bb_rcslotrole631:
  %v3809 = load i64, ptr %slot46, align 8
  store i64 %v3809, ptr %slot513, align 8
  %v3810 = load i64, ptr %slot510, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  %ld3812 = load i64, ptr %p3811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3812, ptr %slot514, align 8
  %v3813 = load i64, ptr %slot514, align 8
  %cmp3814 = icmp ne i64 %v3813, 0
  %cv3815 = zext i1 %cmp3814 to i32
  store i32 %cv3815, ptr %slot515, align 8
  %v3816 = load i32, ptr %slot515, align 8
  %cv3817 = zext i32 %v3816 to i64
  %cond3818 = icmp ne i64 %cv3817, 0
  br i1 %cond3818, label %bb_rcgnn647, label %bb_rcgdone647
bb_rcgnn647:
  %v3819 = load i64, ptr %slot514, align 8
  %op3820 = sub i64 %v3819, 16
  store i64 %op3820, ptr %slot516, align 8
  %v3821 = load i64, ptr %slot514, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  %rgep3823 = getelementptr i8, ptr %p3822, i64 -16
  %ld3824 = load i64, ptr %rgep3823, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3824, ptr %slot517, align 8
  %v3825 = load i64, ptr %slot517, align 8
  %op3826 = and i64 %v3825, 4611686018427387906
  store i64 %op3826, ptr %slot518, align 8
  %v3827 = load i64, ptr %slot518, align 8
  %cmp3828 = icmp ne i64 %v3827, 0
  %cv3829 = zext i1 %cmp3828 to i32
  store i32 %cv3829, ptr %slot519, align 8
  %v3830 = load i32, ptr %slot519, align 8
  %cv3831 = zext i32 %v3830 to i64
  %cond3832 = icmp ne i64 %cv3831, 0
  br i1 %cond3832, label %bb_rcgclear647, label %bb_rcgcounted647
bb_rcgcounted647:
  %v3833 = load i64, ptr %slot514, align 8
  %op3834 = sub i64 %v3833, 24
  store i64 %op3834, ptr %slot520, align 8
  %v3835 = load i64, ptr %slot514, align 8
  %p3836 = inttoptr i64 %v3835 to ptr
  %rgep3837 = getelementptr i8, ptr %p3836, i64 -24
  %ld3838 = load i64, ptr %rgep3837, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3838, ptr %slot521, align 8
  %v3839 = load i64, ptr %slot521, align 8
  %op3840 = sub i64 %v3839, 1
  store i64 %op3840, ptr %slot522, align 8
  %v3841 = load i64, ptr %slot522, align 8
  %cmp3842 = icmp eq i64 %v3841, 0
  %cv3843 = zext i1 %cmp3842 to i32
  store i32 %cv3843, ptr %slot523, align 8
  %v3844 = load i32, ptr %slot523, align 8
  %cv3845 = zext i32 %v3844 to i64
  %cond3846 = icmp ne i64 %cv3845, 0
  br i1 %cond3846, label %bb_rcglast647, label %bb_rcgdec647
bb_rcglast647:
  %v3847 = load i64, ptr %slot514, align 8
  %op3848 = sub i64 %v3847, 32
  store i64 %op3848, ptr %slot524, align 8
  %v3849 = load i64, ptr %slot514, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  %rgep3851 = getelementptr i8, ptr %p3850, i64 -32
  %ld3852 = load i64, ptr %rgep3851, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3852, ptr %slot525, align 8
  %v3853 = load i64, ptr %slot525, align 8
  %cmp3854 = icmp ne i64 %v3853, 0
  %cv3855 = zext i1 %cmp3854 to i32
  store i32 %cv3855, ptr %slot526, align 8
  %v3856 = load i32, ptr %slot526, align 8
  %cv3857 = zext i32 %v3856 to i64
  %cond3858 = icmp ne i64 %cv3857, 0
  br i1 %cond3858, label %bb_rcgdec647, label %bb_rcgslow647
bb_rcgslow647:
  %v3859 = load i64, ptr %slot513, align 8
  %v3860 = load i64, ptr %slot510, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3859, i64 %v3860) nomerge, !dbg !148
  br label %bb_rcgdone647
bb_rcgdec647:
  %v3861 = load i64, ptr %slot522, align 8
  %v3862 = load i64, ptr %slot514, align 8
  %p3863 = inttoptr i64 %v3862 to ptr
  %rgep3864 = getelementptr i8, ptr %p3863, i64 -24
  store i64 %v3861, ptr %rgep3864, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear647
bb_rcgclear647:
  %v3865 = load i64, ptr %slot510, align 8
  %p3866 = inttoptr i64 %v3865 to ptr
  store i64 0, ptr %p3866, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone647
bb_rcgdone647:
  br label %bb_rcslotdone631
bb_rcslotowner631:
  %v3867 = load i64, ptr %slot46, align 8
  store i64 %v3867, ptr %slot527, align 8
  %v3868 = load i64, ptr %slot510, align 8
  %p3869 = inttoptr i64 %v3868 to ptr
  %ld3870 = load i64, ptr %p3869, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3870, ptr %slot528, align 8
  %v3871 = load i64, ptr %slot528, align 8
  %cmp3872 = icmp ne i64 %v3871, 0
  %cv3873 = zext i1 %cmp3872 to i32
  store i32 %cv3873, ptr %slot529, align 8
  %v3874 = load i32, ptr %slot529, align 8
  %cv3875 = zext i32 %v3874 to i64
  %cond3876 = icmp ne i64 %cv3875, 0
  br i1 %cond3876, label %bb_rcgnn662, label %bb_rcgdone662
bb_rcgnn662:
  %v3877 = load i64, ptr %slot528, align 8
  %op3878 = sub i64 %v3877, 16
  store i64 %op3878, ptr %slot530, align 8
  %v3879 = load i64, ptr %slot528, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %rgep3881 = getelementptr i8, ptr %p3880, i64 -16
  %ld3882 = load i64, ptr %rgep3881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3882, ptr %slot531, align 8
  %v3883 = load i64, ptr %slot531, align 8
  %op3884 = and i64 %v3883, 4611686018427387906
  store i64 %op3884, ptr %slot532, align 8
  %v3885 = load i64, ptr %slot532, align 8
  %cmp3886 = icmp ne i64 %v3885, 0
  %cv3887 = zext i1 %cmp3886 to i32
  store i32 %cv3887, ptr %slot533, align 8
  %v3888 = load i32, ptr %slot533, align 8
  %cv3889 = zext i32 %v3888 to i64
  %cond3890 = icmp ne i64 %cv3889, 0
  br i1 %cond3890, label %bb_rcgclear662, label %bb_rcgcounted662
bb_rcgcounted662:
  %v3891 = load i64, ptr %slot528, align 8
  %op3892 = sub i64 %v3891, 32
  store i64 %op3892, ptr %slot534, align 8
  %v3893 = load i64, ptr %slot528, align 8
  %p3894 = inttoptr i64 %v3893 to ptr
  %rgep3895 = getelementptr i8, ptr %p3894, i64 -32
  %ld3896 = load i64, ptr %rgep3895, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3896, ptr %slot535, align 8
  %v3897 = load i64, ptr %slot535, align 8
  %op3898 = sub i64 %v3897, 1
  store i64 %op3898, ptr %slot536, align 8
  %v3899 = load i64, ptr %slot536, align 8
  %cmp3900 = icmp eq i64 %v3899, 0
  %cv3901 = zext i1 %cmp3900 to i32
  store i32 %cv3901, ptr %slot537, align 8
  %v3902 = load i32, ptr %slot537, align 8
  %cv3903 = zext i32 %v3902 to i64
  %cond3904 = icmp ne i64 %cv3903, 0
  br i1 %cond3904, label %bb_rcglast662, label %bb_rcgdec662
bb_rcglast662:
  %v3905 = load i64, ptr %slot528, align 8
  %op3906 = sub i64 %v3905, 24
  store i64 %op3906, ptr %slot538, align 8
  %v3907 = load i64, ptr %slot528, align 8
  %p3908 = inttoptr i64 %v3907 to ptr
  %rgep3909 = getelementptr i8, ptr %p3908, i64 -24
  %ld3910 = load i64, ptr %rgep3909, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3910, ptr %slot539, align 8
  %v3911 = load i64, ptr %slot539, align 8
  %cmp3912 = icmp ne i64 %v3911, 0
  %cv3913 = zext i1 %cmp3912 to i32
  store i32 %cv3913, ptr %slot540, align 8
  %v3914 = load i32, ptr %slot540, align 8
  %cv3915 = zext i32 %v3914 to i64
  %cond3916 = icmp ne i64 %cv3915, 0
  br i1 %cond3916, label %bb_rcgdec662, label %bb_rcgslow662
bb_rcgslow662:
  %v3917 = load i64, ptr %slot527, align 8
  %v3918 = load i64, ptr %slot510, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3917, i64 %v3918) nomerge, !dbg !148
  br label %bb_rcgdone662
bb_rcgdec662:
  %v3919 = load i64, ptr %slot536, align 8
  %v3920 = load i64, ptr %slot528, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  %rgep3922 = getelementptr i8, ptr %p3921, i64 -32
  store i64 %v3919, ptr %rgep3922, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear662
bb_rcgclear662:
  %v3923 = load i64, ptr %slot510, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  store i64 0, ptr %p3924, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone662
bb_rcgdone662:
  br label %bb_rcslotdone631
bb_rcslotdone631:
  br label %bb_rchprepared628
bb_rchtaken628:
  %v3925 = load i64, ptr %slot16, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  store i32 0, ptr %p3926, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared628
bb_rchprepared628:
  %v3927 = load i64, ptr %slot19, align 8
  %p3928 = inttoptr i64 %v3927 to ptr
  store i32 2, ptr %p3928, align 4, !alias.scope !3, !noalias !4
  %v3929 = load i64, ptr %slot18, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  store i32 1, ptr %p3930, align 4, !alias.scope !3, !noalias !4
  %v3931 = load i64, ptr %slot23, align 8
  store i64 %v3931, ptr %slot541, align 8
  %v3932 = load i64, ptr %slot27, align 8
  store i64 %v3932, ptr %slot542, align 8
  %v3933 = load i64, ptr %slot542, align 8
  %v3934 = load i64, ptr %slot541, align 8
  %p3935 = inttoptr i64 %v3933 to ptr
  %p3936 = inttoptr i64 %v3934 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3936, ptr %p3935, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3937 = load i64, ptr %slot17, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  store i32 2, ptr %p3938, align 4, !alias.scope !3, !noalias !4
  %v3939 = load i64, ptr %slot19, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  %ld3941 = load i32, ptr %p3940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3941, ptr %slot543, align 8
  %v3942 = load i32, ptr %slot543, align 8
  %v3943 = load i64, ptr %slot17, align 8
  %p3944 = inttoptr i64 %v3943 to ptr
  store i32 %v3942, ptr %p3944, align 4, !alias.scope !3, !noalias !4
  %v3945 = load i64, ptr %slot18, align 8
  %p3946 = inttoptr i64 %v3945 to ptr
  store i32 0, ptr %p3946, align 4, !alias.scope !3, !noalias !4
  %v3947 = load i64, ptr %slot16, align 8
  %p3948 = inttoptr i64 %v3947 to ptr
  store i32 1, ptr %p3948, align 4, !alias.scope !3, !noalias !4
  %v3949 = load i64, ptr %slot541, align 8
  %p3950 = inttoptr i64 %v3949 to ptr
  %ld3951 = load i64, ptr %p3950, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3951, ptr %slot544, align 8
  %v3952 = load i64, ptr %slot544, align 8
  %v3953 = load i64, ptr %slot41, align 8
  %p3954 = inttoptr i64 %v3953 to ptr
  store i64 %v3952, ptr %p3954, align 8, !alias.scope !3, !noalias !4
  %v3955 = load i64, ptr %slot29, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %ld3957 = load i64, ptr %p3956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3957, ptr %slot545, align 8
  %v3958 = load i64, ptr %slot545, align 8
  %v3959 = load i64, ptr %slot42, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  store i64 %v3958, ptr %p3960, align 8, !alias.scope !3, !noalias !4
  %v3961 = load i64, ptr %slot42, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  %ld3963 = load i64, ptr %p3962, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3963, ptr %slot546, align 8
  %v3964 = load i64, ptr %slot546, align 8
  %op3965 = add i64 %v3964, 8
  store i64 %op3965, ptr %slot547, align 8
  %v3966 = load i64, ptr %slot547, align 8
  %p3967 = inttoptr i64 %v3966 to ptr
  %ld3968 = load i64, ptr %p3967, align 8
  store i64 %ld3968, ptr %slot548, align 8
  %v3969 = load i64, ptr %slot548, align 8
  %v3970 = load i64, ptr %slot42, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  store i64 %v3969, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  %v3972 = load i64, ptr %slot29, align 8
  %p3973 = inttoptr i64 %v3972 to ptr
  %ld3974 = load i64, ptr %p3973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3974, ptr %slot549, align 8
  %v3975 = load i64, ptr %slot549, align 8
  %v3976 = load i64, ptr %slot43, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  store i64 %v3975, ptr %p3977, align 8, !alias.scope !3, !noalias !4
  %v3978 = load i64, ptr %slot43, align 8
  %p3979 = inttoptr i64 %v3978 to ptr
  %ld3980 = load i64, ptr %p3979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3980, ptr %slot550, align 8
  %v3981 = load i64, ptr %slot550, align 8
  %op3982 = add i64 %v3981, 16
  store i64 %op3982, ptr %slot551, align 8
  %v3983 = load i64, ptr %slot551, align 8
  %p3984 = inttoptr i64 %v3983 to ptr
  %ld3985 = load i64, ptr %p3984, align 8
  store i64 %ld3985, ptr %slot552, align 8
  %v3986 = load i64, ptr %slot552, align 8
  %v3987 = load i64, ptr %slot43, align 8
  %p3988 = inttoptr i64 %v3987 to ptr
  store i64 %v3986, ptr %p3988, align 8, !alias.scope !3, !noalias !4
  %v3989 = load i64, ptr %slot44, align 8
  store i64 %v3989, ptr %slot553, align 8
  %v3990 = load i64, ptr %slot553, align 8
  %p3991 = inttoptr i64 %v3990 to ptr
  store i64 0, ptr %p3991, align 8, !alias.scope !3, !noalias !4
  %v3992 = load i64, ptr %slot553, align 8
  %p3994 = inttoptr i64 %v3992 to ptr
  %gep3995 = getelementptr i8, ptr %p3994, i64 8
  %op3993 = ptrtoint ptr %gep3995 to i64
  store i64 %op3993, ptr %slot554, align 8
  %v3996 = load i64, ptr %slot554, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  store i64 0, ptr %p3997, align 8, !alias.scope !3, !noalias !4
  %v3998 = load i64, ptr %slot553, align 8
  %p4000 = inttoptr i64 %v3998 to ptr
  %gep4001 = getelementptr i8, ptr %p4000, i64 16
  %op3999 = ptrtoint ptr %gep4001 to i64
  store i64 %op3999, ptr %slot555, align 8
  %v4002 = load i64, ptr %slot555, align 8
  %p4003 = inttoptr i64 %v4002 to ptr
  store i64 0, ptr %p4003, align 8, !alias.scope !3, !noalias !4
  %v4004 = load i64, ptr %slot553, align 8
  %p4006 = inttoptr i64 %v4004 to ptr
  %gep4007 = getelementptr i8, ptr %p4006, i64 24
  %op4005 = ptrtoint ptr %gep4007 to i64
  store i64 %op4005, ptr %slot556, align 8
  %v4008 = load i64, ptr %slot556, align 8
  %p4009 = inttoptr i64 %v4008 to ptr
  store i64 0, ptr %p4009, align 8, !alias.scope !3, !noalias !4
  %v4010 = load i64, ptr %slot553, align 8
  %p4012 = inttoptr i64 %v4010 to ptr
  %gep4013 = getelementptr i8, ptr %p4012, i64 32
  %op4011 = ptrtoint ptr %gep4013 to i64
  store i64 %op4011, ptr %slot557, align 8
  %v4014 = load i64, ptr %slot557, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  store i64 0, ptr %p4015, align 8, !alias.scope !3, !noalias !4
  %v4016 = load i64, ptr %slot20, align 8
  %p4017 = inttoptr i64 %v4016 to ptr
  store i32 1, ptr %p4017, align 4, !alias.scope !3, !noalias !4
  %v4018 = load i64, ptr %slot47, align 8
  store i64 %v4018, ptr %slot558, align 8
  %v4019 = load i64, ptr %slot39, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  %ld4021 = load i64, ptr %p4020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4021, ptr %slot559, align 8
  %v4022 = load i64, ptr %slot559, align 8
  %v4023 = load i64, ptr %slot24, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  store i64 %v4022, ptr %p4024, align 8, !alias.scope !3, !noalias !4
  %v4025 = load i64, ptr %slot24, align 8
  store i64 %v4025, ptr %slot560, align 8
  %v4026 = load i64, ptr %slot553, align 8
  %p4028 = inttoptr i64 %v4026 to ptr
  %gep4029 = getelementptr i8, ptr %p4028, i64 0
  %op4027 = ptrtoint ptr %gep4029 to i64
  store i64 %op4027, ptr %slot561, align 8
  %v4030 = load i64, ptr %slot39, align 8
  %p4031 = inttoptr i64 %v4030 to ptr
  %ld4032 = load i64, ptr %p4031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4032, ptr %slot562, align 8
  %v4033 = load i64, ptr %slot562, align 8
  %v4034 = load i64, ptr %slot24, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  store i64 %v4033, ptr %p4035, align 8, !alias.scope !3, !noalias !4
  %v4036 = load i64, ptr %slot24, align 8
  store i64 %v4036, ptr %slot563, align 8
  %v4037 = load i64, ptr %slot12, align 8
  %p4038 = inttoptr i64 %v4037 to ptr
  %ld4039 = load i32, ptr %p4038, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4039, ptr %slot564, align 8
  %v4040 = load i64, ptr %slot13, align 8
  %p4041 = inttoptr i64 %v4040 to ptr
  %ld4042 = load i32, ptr %p4041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4042, ptr %slot565, align 8
  %v4043 = load i32, ptr %slot565, align 8
  %op4044 = and i32 %v4043, 24
  store i32 %op4044, ptr %slot565, align 8
  %v4045 = load i32, ptr %slot565, align 8
  %cmp4046 = icmp eq i32 %v4045, 0
  %cv4047 = zext i1 %cmp4046 to i32
  store i32 %cv4047, ptr %slot566, align 8
  %v4048 = load i32, ptr %slot564, align 8
  %v4049 = load i32, ptr %slot566, align 8
  %op4050 = and i32 %v4048, %v4049
  store i32 %op4050, ptr %slot567, align 8
  %v4051 = load i32, ptr %slot567, align 8
  %cv4052 = zext i32 %v4051 to i64
  %cond4053 = icmp ne i64 %cv4052, 0
  br i1 %cond4053, label %bb_rctake699, label %bb_rccopy699
bb_rctake699:
  %v4054 = load i64, ptr %slot27, align 8
  store i64 %v4054, ptr %slot568, align 8
  %v4055 = load i64, ptr %slot47, align 8
  store i64 %v4055, ptr %slot569, align 8
  %v4056 = load i64, ptr %slot563, align 8
  %v4057 = load i64, ptr %slot568, align 8
  %op4058 = sub i64 %v4056, %v4057
  store i64 %op4058, ptr %slot570, align 8
  %v4059 = load i64, ptr %slot568, align 8
  %v4060 = load i64, ptr %slot563, align 8
  %op4061 = sub i64 %v4059, %v4060
  store i64 %op4061, ptr %slot571, align 8
  %v4062 = load i64, ptr %slot570, align 8
  %cmp4063 = icmp ult i64 %v4062, 8
  %cv4064 = zext i1 %cmp4063 to i32
  store i32 %cv4064, ptr %slot572, align 8
  %v4065 = load i64, ptr %slot571, align 8
  %cmp4066 = icmp ult i64 %v4065, 8
  %cv4067 = zext i1 %cmp4066 to i32
  store i32 %cv4067, ptr %slot573, align 8
  %v4068 = load i32, ptr %slot572, align 8
  %v4069 = load i32, ptr %slot573, align 8
  %op4070 = or i32 %v4068, %v4069
  store i32 %op4070, ptr %slot574, align 8
  %v4071 = load i32, ptr %slot574, align 8
  %cv4072 = zext i32 %v4071 to i64
  %cond4073 = icmp ne i64 %cv4072, 0
  br i1 %cond4073, label %bb_rcmoveslow708, label %bb_rcmovecheck708
bb_rcmovecheck708:
  %v4074 = load i64, ptr %slot563, align 8
  %p4076 = inttoptr i64 %v4074 to ptr
  %gep4077 = getelementptr i8, ptr %p4076, i64 0
  %op4075 = ptrtoint ptr %gep4077 to i64
  store i64 %op4075, ptr %slot575, align 8
  %v4078 = load i64, ptr %slot575, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  %ld4080 = load i64, ptr %p4079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4080, ptr %slot576, align 8
  %v4081 = load i64, ptr %slot576, align 8
  %cmp4082 = icmp ne i64 %v4081, 0
  %cv4083 = zext i1 %cmp4082 to i32
  store i32 %cv4083, ptr %slot577, align 8
  %v4084 = load i32, ptr %slot577, align 8
  %cv4085 = zext i32 %v4084 to i64
  %cond4086 = icmp ne i64 %cv4085, 0
  br i1 %cond4086, label %bb_rcmoveheader716, label %bb_rcmovenext716
bb_rcmoveheader716:
  %v4087 = load i64, ptr %slot576, align 8
  %op4088 = sub i64 %v4087, 16
  store i64 %op4088, ptr %slot578, align 8
  %v4089 = load i64, ptr %slot576, align 8
  %p4090 = inttoptr i64 %v4089 to ptr
  %rgep4091 = getelementptr i8, ptr %p4090, i64 -16
  %ld4092 = load i64, ptr %rgep4091, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4092, ptr %slot579, align 8
  %v4093 = load i64, ptr %slot579, align 8
  %op4094 = and i64 %v4093, 5764607523034234881
  store i64 %op4094, ptr %slot580, align 8
  %v4095 = load i64, ptr %slot580, align 8
  %cmp4096 = icmp ne i64 %v4095, 0
  %cv4097 = zext i1 %cmp4096 to i32
  store i32 %cv4097, ptr %slot581, align 8
  %v4098 = load i32, ptr %slot581, align 8
  %cv4099 = zext i32 %v4098 to i64
  %cond4100 = icmp ne i64 %cv4099, 0
  br i1 %cond4100, label %bb_rcmoveslow708, label %bb_rcmovenext716
bb_rcmovenext716:
  %v4101 = load i64, ptr %slot563, align 8
  %v4102 = load i64, ptr %slot568, align 8
  %p4103 = inttoptr i64 %v4101 to ptr
  %p4104 = inttoptr i64 %v4102 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4104, ptr %p4103, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4105 = load i64, ptr %slot563, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  store i64 0, ptr %p4106, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved708
bb_rcmoveslow708:
  %v4107 = load i64, ptr %slot46, align 8
  %v4108 = load i64, ptr %slot568, align 8
  %v4109 = load i64, ptr %slot563, align 8
  %v4110 = load i64, ptr %slot569, align 8
  %cv4111 = trunc i64 %v4110 to i32
  %call4112 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64 %v4107, i64 %v4108, i64 %v4109, i32 %cv4111) nomerge, !dbg !150
  store i32 %call4112, ptr %slot582, align 8
  %v4113 = load i32, ptr %slot582, align 8
  %cv4114 = zext i32 %v4113 to i64
  %cond4115 = icmp ne i64 %cv4114, 0
  br i1 %cond4115, label %bb_rcsuccess723, label %bb_rcfailure723
bb_rcfailure723:
  %v4116 = load i64, ptr %slot46, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  %call4118 = call i32 @myl_rc_take_failure(ptr %p4117) nomerge, !dbg !150
  store i32 %call4118, ptr %slot583, align 8
  %v4119 = load i64, ptr %slot1, align 8
  %p4120 = inttoptr i64 %v4119 to ptr
  %v4121 = load i32, ptr %slot583, align 8
  %call4122 = call i32 @myl_qbe_rc_status(ptr %p4120, i32 %v4121) nomerge, !dbg !150
  store i32 %call4122, ptr %slot584, align 8
  br label %bb_failure
bb_rcsuccess723:
  br label %bb_rcmoved708
bb_rcmoved708:
  %v4123 = load i64, ptr %slot12, align 8
  %p4124 = inttoptr i64 %v4123 to ptr
  store i32 0, ptr %p4124, align 4, !alias.scope !3, !noalias !4
  %v4125 = load i64, ptr %slot19, align 8
  %p4126 = inttoptr i64 %v4125 to ptr
  store i32 2, ptr %p4126, align 4, !alias.scope !3, !noalias !4
  %v4127 = load i64, ptr %slot18, align 8
  %p4128 = inttoptr i64 %v4127 to ptr
  store i32 1, ptr %p4128, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared699
bb_rccopy699:
  %v4129 = load i64, ptr %slot27, align 8
  store i64 %v4129, ptr %slot585, align 8
  %v4130 = load i64, ptr %slot47, align 8
  store i64 %v4130, ptr %slot586, align 8
  %v4131 = load i64, ptr %slot563, align 8
  %p4132 = inttoptr i64 %v4131 to ptr
  %ld4133 = load i64, ptr %p4132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4133, ptr %slot587, align 8
  %v4134 = load i64, ptr %slot587, align 8
  %cmp4135 = icmp ne i64 %v4134, 0
  %cv4136 = zext i1 %cmp4135 to i32
  store i32 %cv4136, ptr %slot588, align 8
  %v4137 = load i32, ptr %slot588, align 8
  %cv4138 = zext i32 %v4137 to i64
  %cond4139 = icmp ne i64 %cv4138, 0
  br i1 %cond4139, label %bb_rcgnn732, label %bb_rcgplain732
bb_rcgnn732:
  %v4140 = load i64, ptr %slot587, align 8
  %op4141 = sub i64 %v4140, 16
  store i64 %op4141, ptr %slot589, align 8
  %v4142 = load i64, ptr %slot587, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  %rgep4144 = getelementptr i8, ptr %p4143, i64 -16
  %ld4145 = load i64, ptr %rgep4144, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4145, ptr %slot590, align 8
  %v4146 = load i64, ptr %slot590, align 8
  %op4147 = and i64 %v4146, 4611686018427387906
  store i64 %op4147, ptr %slot591, align 8
  %v4148 = load i64, ptr %slot591, align 8
  %cmp4149 = icmp ne i64 %v4148, 0
  %cv4150 = zext i1 %cmp4149 to i32
  store i32 %cv4150, ptr %slot592, align 8
  %v4151 = load i32, ptr %slot592, align 8
  %cv4152 = zext i32 %v4151 to i64
  %cond4153 = icmp ne i64 %cv4152, 0
  br i1 %cond4153, label %bb_rcgspecial732, label %bb_rcginc732
bb_rcginc732:
  %v4154 = load i64, ptr %slot587, align 8
  %op4155 = sub i64 %v4154, 32
  store i64 %op4155, ptr %slot593, align 8
  %v4156 = load i64, ptr %slot587, align 8
  %p4157 = inttoptr i64 %v4156 to ptr
  %rgep4158 = getelementptr i8, ptr %p4157, i64 -32
  %ld4159 = load i64, ptr %rgep4158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4159, ptr %slot594, align 8
  %v4160 = load i64, ptr %slot594, align 8
  %op4161 = add i64 %v4160, 1
  store i64 %op4161, ptr %slot595, align 8
  %v4162 = load i64, ptr %slot595, align 8
  %cmp4163 = icmp eq i64 %v4162, 0
  %cv4164 = zext i1 %cmp4163 to i32
  store i32 %cv4164, ptr %slot596, align 8
  %v4165 = load i32, ptr %slot596, align 8
  %cv4166 = zext i32 %v4165 to i64
  %cond4167 = icmp ne i64 %cv4166, 0
  br i1 %cond4167, label %bb_rcglimit732, label %bb_rcgcapacity732
bb_rcglimit732:
  %v4168 = load i64, ptr %slot1, align 8
  %p4169 = inttoptr i64 %v4168 to ptr
  %call4170 = call i32 @myl_qbe_rc_status(ptr %p4169, i32 2) nomerge, !dbg !150
  store i32 %call4170, ptr %slot597, align 8
  br label %bb_failure
bb_rcgcapacity732:
  %v4171 = load i64, ptr %slot595, align 8
  %v4172 = load i64, ptr %slot587, align 8
  %p4173 = inttoptr i64 %v4172 to ptr
  %rgep4174 = getelementptr i8, ptr %p4173, i64 -32
  store i64 %v4171, ptr %rgep4174, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain732
bb_rcgspecial732:
  %v4175 = load i64, ptr %slot590, align 8
  %op4176 = and i64 %v4175, 4611686018427387904
  store i64 %op4176, ptr %slot598, align 8
  %v4177 = load i64, ptr %slot598, align 8
  %cmp4178 = icmp ne i64 %v4177, 0
  %cv4179 = zext i1 %cmp4178 to i32
  store i32 %cv4179, ptr %slot599, align 8
  %v4180 = load i32, ptr %slot599, align 8
  %cv4181 = zext i32 %v4180 to i64
  %cond4182 = icmp ne i64 %cv4181, 0
  br i1 %cond4182, label %bb_rcgslow732, label %bb_rcgplain732
bb_rcgslow732:
  %v4183 = load i64, ptr %slot46, align 8
  %v4184 = load i64, ptr %slot585, align 8
  %v4185 = load i64, ptr %slot563, align 8
  %v4186 = load i64, ptr %slot586, align 8
  %cv4187 = trunc i64 %v4186 to i32
  %call4188 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_retain(i64 %v4183, i64 %v4184, i64 %v4185, i32 %cv4187) nomerge, !dbg !150
  store i32 %call4188, ptr %slot600, align 8
  %v4189 = load i32, ptr %slot600, align 8
  %cv4190 = zext i32 %v4189 to i64
  %cond4191 = icmp ne i64 %cv4190, 0
  br i1 %cond4191, label %bb_rcsuccess746, label %bb_rcfailure746
bb_rcfailure746:
  %v4192 = load i64, ptr %slot46, align 8
  %p4193 = inttoptr i64 %v4192 to ptr
  %call4194 = call i32 @myl_rc_take_failure(ptr %p4193) nomerge, !dbg !150
  store i32 %call4194, ptr %slot601, align 8
  %v4195 = load i64, ptr %slot1, align 8
  %p4196 = inttoptr i64 %v4195 to ptr
  %v4197 = load i32, ptr %slot601, align 8
  %call4198 = call i32 @myl_qbe_rc_status(ptr %p4196, i32 %v4197) nomerge, !dbg !150
  store i32 %call4198, ptr %slot602, align 8
  br label %bb_failure
bb_rcsuccess746:
  br label %bb_rcgdone732
bb_rcgplain732:
  %v4199 = load i64, ptr %slot587, align 8
  %v4200 = load i64, ptr %slot585, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  store i64 %v4199, ptr %p4201, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone732
bb_rcgdone732:
  %v4202 = load i64, ptr %slot19, align 8
  %p4203 = inttoptr i64 %v4202 to ptr
  store i32 2, ptr %p4203, align 4, !alias.scope !3, !noalias !4
  %v4204 = load i64, ptr %slot18, align 8
  %p4205 = inttoptr i64 %v4204 to ptr
  store i32 1, ptr %p4205, align 4, !alias.scope !3, !noalias !4
  %v4206 = load i64, ptr %slot12, align 8
  %p4207 = inttoptr i64 %v4206 to ptr
  %ld4208 = load i32, ptr %p4207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4208, ptr %slot603, align 8
  %v4209 = load i32, ptr %slot603, align 8
  %cv4210 = zext i32 %v4209 to i64
  %cond4211 = icmp ne i64 %cv4210, 0
  br i1 %cond4211, label %bb_rcslotdrop753, label %bb_rcslotdone753
bb_rcslotdrop753:
  %v4212 = load i64, ptr %slot12, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  store i32 0, ptr %p4213, align 4, !alias.scope !3, !noalias !4
  %v4214 = load i64, ptr %slot21, align 8
  store i64 %v4214, ptr %slot604, align 8
  %v4215 = load i64, ptr %slot13, align 8
  %p4216 = inttoptr i64 %v4215 to ptr
  %ld4217 = load i32, ptr %p4216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4217, ptr %slot605, align 8
  %v4218 = load i32, ptr %slot605, align 8
  %op4219 = and i32 %v4218, 28
  store i32 %op4219, ptr %slot606, align 8
  %v4220 = load i32, ptr %slot606, align 8
  %cv4221 = zext i32 %v4220 to i64
  %cond4222 = icmp ne i64 %cv4221, 0
  br i1 %cond4222, label %bb_rcslotrole753, label %bb_rcslotowner753
bb_rcslotrole753:
  %v4223 = load i64, ptr %slot46, align 8
  store i64 %v4223, ptr %slot607, align 8
  %v4224 = load i64, ptr %slot604, align 8
  %p4225 = inttoptr i64 %v4224 to ptr
  %ld4226 = load i64, ptr %p4225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4226, ptr %slot608, align 8
  %v4227 = load i64, ptr %slot608, align 8
  %cmp4228 = icmp ne i64 %v4227, 0
  %cv4229 = zext i1 %cmp4228 to i32
  store i32 %cv4229, ptr %slot609, align 8
  %v4230 = load i32, ptr %slot609, align 8
  %cv4231 = zext i32 %v4230 to i64
  %cond4232 = icmp ne i64 %cv4231, 0
  br i1 %cond4232, label %bb_rcgnn769, label %bb_rcgdone769
bb_rcgnn769:
  %v4233 = load i64, ptr %slot608, align 8
  %op4234 = sub i64 %v4233, 16
  store i64 %op4234, ptr %slot610, align 8
  %v4235 = load i64, ptr %slot608, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  %rgep4237 = getelementptr i8, ptr %p4236, i64 -16
  %ld4238 = load i64, ptr %rgep4237, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4238, ptr %slot611, align 8
  %v4239 = load i64, ptr %slot611, align 8
  %op4240 = and i64 %v4239, 4611686018427387906
  store i64 %op4240, ptr %slot612, align 8
  %v4241 = load i64, ptr %slot612, align 8
  %cmp4242 = icmp ne i64 %v4241, 0
  %cv4243 = zext i1 %cmp4242 to i32
  store i32 %cv4243, ptr %slot613, align 8
  %v4244 = load i32, ptr %slot613, align 8
  %cv4245 = zext i32 %v4244 to i64
  %cond4246 = icmp ne i64 %cv4245, 0
  br i1 %cond4246, label %bb_rcgclear769, label %bb_rcgcounted769
bb_rcgcounted769:
  %v4247 = load i64, ptr %slot608, align 8
  %op4248 = sub i64 %v4247, 24
  store i64 %op4248, ptr %slot614, align 8
  %v4249 = load i64, ptr %slot608, align 8
  %p4250 = inttoptr i64 %v4249 to ptr
  %rgep4251 = getelementptr i8, ptr %p4250, i64 -24
  %ld4252 = load i64, ptr %rgep4251, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4252, ptr %slot615, align 8
  %v4253 = load i64, ptr %slot615, align 8
  %op4254 = sub i64 %v4253, 1
  store i64 %op4254, ptr %slot616, align 8
  %v4255 = load i64, ptr %slot616, align 8
  %cmp4256 = icmp eq i64 %v4255, 0
  %cv4257 = zext i1 %cmp4256 to i32
  store i32 %cv4257, ptr %slot617, align 8
  %v4258 = load i32, ptr %slot617, align 8
  %cv4259 = zext i32 %v4258 to i64
  %cond4260 = icmp ne i64 %cv4259, 0
  br i1 %cond4260, label %bb_rcglast769, label %bb_rcgdec769
bb_rcglast769:
  %v4261 = load i64, ptr %slot608, align 8
  %op4262 = sub i64 %v4261, 32
  store i64 %op4262, ptr %slot618, align 8
  %v4263 = load i64, ptr %slot608, align 8
  %p4264 = inttoptr i64 %v4263 to ptr
  %rgep4265 = getelementptr i8, ptr %p4264, i64 -32
  %ld4266 = load i64, ptr %rgep4265, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4266, ptr %slot619, align 8
  %v4267 = load i64, ptr %slot619, align 8
  %cmp4268 = icmp ne i64 %v4267, 0
  %cv4269 = zext i1 %cmp4268 to i32
  store i32 %cv4269, ptr %slot620, align 8
  %v4270 = load i32, ptr %slot620, align 8
  %cv4271 = zext i32 %v4270 to i64
  %cond4272 = icmp ne i64 %cv4271, 0
  br i1 %cond4272, label %bb_rcgdec769, label %bb_rcgslow769
bb_rcgslow769:
  %v4273 = load i64, ptr %slot607, align 8
  %v4274 = load i64, ptr %slot604, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v4273, i64 %v4274) nomerge, !dbg !150
  br label %bb_rcgdone769
bb_rcgdec769:
  %v4275 = load i64, ptr %slot616, align 8
  %v4276 = load i64, ptr %slot608, align 8
  %p4277 = inttoptr i64 %v4276 to ptr
  %rgep4278 = getelementptr i8, ptr %p4277, i64 -24
  store i64 %v4275, ptr %rgep4278, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear769
bb_rcgclear769:
  %v4279 = load i64, ptr %slot604, align 8
  %p4280 = inttoptr i64 %v4279 to ptr
  store i64 0, ptr %p4280, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone769
bb_rcgdone769:
  br label %bb_rcslotdone753
bb_rcslotowner753:
  %v4281 = load i64, ptr %slot46, align 8
  store i64 %v4281, ptr %slot621, align 8
  %v4282 = load i64, ptr %slot604, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  %ld4284 = load i64, ptr %p4283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4284, ptr %slot622, align 8
  %v4285 = load i64, ptr %slot622, align 8
  %cmp4286 = icmp ne i64 %v4285, 0
  %cv4287 = zext i1 %cmp4286 to i32
  store i32 %cv4287, ptr %slot623, align 8
  %v4288 = load i32, ptr %slot623, align 8
  %cv4289 = zext i32 %v4288 to i64
  %cond4290 = icmp ne i64 %cv4289, 0
  br i1 %cond4290, label %bb_rcgnn784, label %bb_rcgdone784
bb_rcgnn784:
  %v4291 = load i64, ptr %slot622, align 8
  %op4292 = sub i64 %v4291, 16
  store i64 %op4292, ptr %slot624, align 8
  %v4293 = load i64, ptr %slot622, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  %rgep4295 = getelementptr i8, ptr %p4294, i64 -16
  %ld4296 = load i64, ptr %rgep4295, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4296, ptr %slot625, align 8
  %v4297 = load i64, ptr %slot625, align 8
  %op4298 = and i64 %v4297, 4611686018427387906
  store i64 %op4298, ptr %slot626, align 8
  %v4299 = load i64, ptr %slot626, align 8
  %cmp4300 = icmp ne i64 %v4299, 0
  %cv4301 = zext i1 %cmp4300 to i32
  store i32 %cv4301, ptr %slot627, align 8
  %v4302 = load i32, ptr %slot627, align 8
  %cv4303 = zext i32 %v4302 to i64
  %cond4304 = icmp ne i64 %cv4303, 0
  br i1 %cond4304, label %bb_rcgclear784, label %bb_rcgcounted784
bb_rcgcounted784:
  %v4305 = load i64, ptr %slot622, align 8
  %op4306 = sub i64 %v4305, 32
  store i64 %op4306, ptr %slot628, align 8
  %v4307 = load i64, ptr %slot622, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  %rgep4309 = getelementptr i8, ptr %p4308, i64 -32
  %ld4310 = load i64, ptr %rgep4309, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4310, ptr %slot629, align 8
  %v4311 = load i64, ptr %slot629, align 8
  %op4312 = sub i64 %v4311, 1
  store i64 %op4312, ptr %slot630, align 8
  %v4313 = load i64, ptr %slot630, align 8
  %cmp4314 = icmp eq i64 %v4313, 0
  %cv4315 = zext i1 %cmp4314 to i32
  store i32 %cv4315, ptr %slot631, align 8
  %v4316 = load i32, ptr %slot631, align 8
  %cv4317 = zext i32 %v4316 to i64
  %cond4318 = icmp ne i64 %cv4317, 0
  br i1 %cond4318, label %bb_rcglast784, label %bb_rcgdec784
bb_rcglast784:
  %v4319 = load i64, ptr %slot622, align 8
  %op4320 = sub i64 %v4319, 24
  store i64 %op4320, ptr %slot632, align 8
  %v4321 = load i64, ptr %slot622, align 8
  %p4322 = inttoptr i64 %v4321 to ptr
  %rgep4323 = getelementptr i8, ptr %p4322, i64 -24
  %ld4324 = load i64, ptr %rgep4323, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4324, ptr %slot633, align 8
  %v4325 = load i64, ptr %slot633, align 8
  %cmp4326 = icmp ne i64 %v4325, 0
  %cv4327 = zext i1 %cmp4326 to i32
  store i32 %cv4327, ptr %slot634, align 8
  %v4328 = load i32, ptr %slot634, align 8
  %cv4329 = zext i32 %v4328 to i64
  %cond4330 = icmp ne i64 %cv4329, 0
  br i1 %cond4330, label %bb_rcgdec784, label %bb_rcgslow784
bb_rcgslow784:
  %v4331 = load i64, ptr %slot621, align 8
  %v4332 = load i64, ptr %slot604, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v4331, i64 %v4332) nomerge, !dbg !150
  br label %bb_rcgdone784
bb_rcgdec784:
  %v4333 = load i64, ptr %slot630, align 8
  %v4334 = load i64, ptr %slot622, align 8
  %p4335 = inttoptr i64 %v4334 to ptr
  %rgep4336 = getelementptr i8, ptr %p4335, i64 -32
  store i64 %v4333, ptr %rgep4336, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear784
bb_rcgclear784:
  %v4337 = load i64, ptr %slot604, align 8
  %p4338 = inttoptr i64 %v4337 to ptr
  store i64 0, ptr %p4338, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone784
bb_rcgdone784:
  br label %bb_rcslotdone753
bb_rcslotdone753:
  br label %bb_rcprepared699
bb_rcprepared699:
  %v4339 = load i64, ptr %slot27, align 8
  store i64 %v4339, ptr %slot635, align 8
  %v4340 = load i64, ptr %slot635, align 8
  %v4341 = load i64, ptr %slot561, align 8
  %p4342 = inttoptr i64 %v4340 to ptr
  %p4343 = inttoptr i64 %v4341 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4343, ptr %p4342, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4344 = load i64, ptr %slot18, align 8
  %p4345 = inttoptr i64 %v4344 to ptr
  store i32 0, ptr %p4345, align 4, !alias.scope !3, !noalias !4
  %v4346 = load i64, ptr %slot40, align 8
  %p4347 = inttoptr i64 %v4346 to ptr
  %ld4348 = load i64, ptr %p4347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4348, ptr %slot636, align 8
  %v4349 = load i64, ptr %slot636, align 8
  %v4350 = load i64, ptr %slot25, align 8
  %p4351 = inttoptr i64 %v4350 to ptr
  store i64 %v4349, ptr %p4351, align 8, !alias.scope !3, !noalias !4
  %v4352 = load i64, ptr %slot25, align 8
  store i64 %v4352, ptr %slot637, align 8
  %v4353 = load i64, ptr %slot553, align 8
  %p4355 = inttoptr i64 %v4353 to ptr
  %gep4356 = getelementptr i8, ptr %p4355, i64 8
  %op4354 = ptrtoint ptr %gep4356 to i64
  store i64 %op4354, ptr %slot638, align 8
  %v4357 = load i64, ptr %slot40, align 8
  %p4358 = inttoptr i64 %v4357 to ptr
  %ld4359 = load i64, ptr %p4358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4359, ptr %slot639, align 8
  %v4360 = load i64, ptr %slot639, align 8
  %v4361 = load i64, ptr %slot25, align 8
  %p4362 = inttoptr i64 %v4361 to ptr
  store i64 %v4360, ptr %p4362, align 8, !alias.scope !3, !noalias !4
  %v4363 = load i64, ptr %slot25, align 8
  store i64 %v4363, ptr %slot640, align 8
  %v4364 = load i64, ptr %slot14, align 8
  %p4365 = inttoptr i64 %v4364 to ptr
  %ld4366 = load i32, ptr %p4365, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4366, ptr %slot641, align 8
  %v4367 = load i64, ptr %slot15, align 8
  %p4368 = inttoptr i64 %v4367 to ptr
  %ld4369 = load i32, ptr %p4368, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4369, ptr %slot642, align 8
  %v4370 = load i32, ptr %slot642, align 8
  %op4371 = and i32 %v4370, 24
  store i32 %op4371, ptr %slot642, align 8
  %v4372 = load i32, ptr %slot642, align 8
  %cmp4373 = icmp eq i32 %v4372, 0
  %cv4374 = zext i1 %cmp4373 to i32
  store i32 %cv4374, ptr %slot643, align 8
  %v4375 = load i32, ptr %slot641, align 8
  %v4376 = load i32, ptr %slot643, align 8
  %op4377 = and i32 %v4375, %v4376
  store i32 %op4377, ptr %slot644, align 8
  %v4378 = load i32, ptr %slot644, align 8
  %cv4379 = zext i32 %v4378 to i64
  %cond4380 = icmp ne i64 %cv4379, 0
  br i1 %cond4380, label %bb_rctake795, label %bb_rccopy795
bb_rctake795:
  %v4381 = load i64, ptr %slot27, align 8
  store i64 %v4381, ptr %slot645, align 8
  %v4382 = load i64, ptr %slot47, align 8
  store i64 %v4382, ptr %slot646, align 8
  %v4383 = load i64, ptr %slot640, align 8
  %v4384 = load i64, ptr %slot645, align 8
  %op4385 = sub i64 %v4383, %v4384
  store i64 %op4385, ptr %slot647, align 8
  %v4386 = load i64, ptr %slot645, align 8
  %v4387 = load i64, ptr %slot640, align 8
  %op4388 = sub i64 %v4386, %v4387
  store i64 %op4388, ptr %slot648, align 8
  %v4389 = load i64, ptr %slot647, align 8
  %cmp4390 = icmp ult i64 %v4389, 8
  %cv4391 = zext i1 %cmp4390 to i32
  store i32 %cv4391, ptr %slot649, align 8
  %v4392 = load i64, ptr %slot648, align 8
  %cmp4393 = icmp ult i64 %v4392, 8
  %cv4394 = zext i1 %cmp4393 to i32
  store i32 %cv4394, ptr %slot650, align 8
  %v4395 = load i32, ptr %slot649, align 8
  %v4396 = load i32, ptr %slot650, align 8
  %op4397 = or i32 %v4395, %v4396
  store i32 %op4397, ptr %slot651, align 8
  %v4398 = load i32, ptr %slot651, align 8
  %cv4399 = zext i32 %v4398 to i64
  %cond4400 = icmp ne i64 %cv4399, 0
  br i1 %cond4400, label %bb_rcmoveslow804, label %bb_rcmovecheck804
bb_rcmovecheck804:
  %v4401 = load i64, ptr %slot640, align 8
  %p4403 = inttoptr i64 %v4401 to ptr
  %gep4404 = getelementptr i8, ptr %p4403, i64 0
  %op4402 = ptrtoint ptr %gep4404 to i64
  store i64 %op4402, ptr %slot652, align 8
  %v4405 = load i64, ptr %slot652, align 8
  %p4406 = inttoptr i64 %v4405 to ptr
  %ld4407 = load i64, ptr %p4406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4407, ptr %slot653, align 8
  %v4408 = load i64, ptr %slot653, align 8
  %cmp4409 = icmp ne i64 %v4408, 0
  %cv4410 = zext i1 %cmp4409 to i32
  store i32 %cv4410, ptr %slot654, align 8
  %v4411 = load i32, ptr %slot654, align 8
  %cv4412 = zext i32 %v4411 to i64
  %cond4413 = icmp ne i64 %cv4412, 0
  br i1 %cond4413, label %bb_rcmoveheader812, label %bb_rcmovenext812
bb_rcmoveheader812:
  %v4414 = load i64, ptr %slot653, align 8
  %op4415 = sub i64 %v4414, 16
  store i64 %op4415, ptr %slot655, align 8
  %v4416 = load i64, ptr %slot653, align 8
  %p4417 = inttoptr i64 %v4416 to ptr
  %rgep4418 = getelementptr i8, ptr %p4417, i64 -16
  %ld4419 = load i64, ptr %rgep4418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4419, ptr %slot656, align 8
  %v4420 = load i64, ptr %slot656, align 8
  %op4421 = and i64 %v4420, 5764607523034234881
  store i64 %op4421, ptr %slot657, align 8
  %v4422 = load i64, ptr %slot657, align 8
  %cmp4423 = icmp ne i64 %v4422, 0
  %cv4424 = zext i1 %cmp4423 to i32
  store i32 %cv4424, ptr %slot658, align 8
  %v4425 = load i32, ptr %slot658, align 8
  %cv4426 = zext i32 %v4425 to i64
  %cond4427 = icmp ne i64 %cv4426, 0
  br i1 %cond4427, label %bb_rcmoveslow804, label %bb_rcmovenext812
bb_rcmovenext812:
  %v4428 = load i64, ptr %slot640, align 8
  %v4429 = load i64, ptr %slot645, align 8
  %p4430 = inttoptr i64 %v4428 to ptr
  %p4431 = inttoptr i64 %v4429 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4431, ptr %p4430, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4432 = load i64, ptr %slot640, align 8
  %p4433 = inttoptr i64 %v4432 to ptr
  store i64 0, ptr %p4433, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved804
bb_rcmoveslow804:
  %v4434 = load i64, ptr %slot46, align 8
  %v4435 = load i64, ptr %slot645, align 8
  %v4436 = load i64, ptr %slot640, align 8
  %v4437 = load i64, ptr %slot646, align 8
  %cv4438 = trunc i64 %v4437 to i32
  %call4439 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v4434, i64 %v4435, i64 %v4436, i32 %cv4438) nomerge, !dbg !150
  store i32 %call4439, ptr %slot659, align 8
  %v4440 = load i32, ptr %slot659, align 8
  %cv4441 = zext i32 %v4440 to i64
  %cond4442 = icmp ne i64 %cv4441, 0
  br i1 %cond4442, label %bb_rcsuccess819, label %bb_rcfailure819
bb_rcfailure819:
  %v4443 = load i64, ptr %slot46, align 8
  %p4444 = inttoptr i64 %v4443 to ptr
  %call4445 = call i32 @myl_rc_take_failure(ptr %p4444) nomerge, !dbg !150
  store i32 %call4445, ptr %slot660, align 8
  %v4446 = load i64, ptr %slot1, align 8
  %p4447 = inttoptr i64 %v4446 to ptr
  %v4448 = load i32, ptr %slot660, align 8
  %call4449 = call i32 @myl_qbe_rc_status(ptr %p4447, i32 %v4448) nomerge, !dbg !150
  store i32 %call4449, ptr %slot661, align 8
  br label %bb_failure
bb_rcsuccess819:
  br label %bb_rcmoved804
bb_rcmoved804:
  %v4450 = load i64, ptr %slot14, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  store i32 0, ptr %p4451, align 4, !alias.scope !3, !noalias !4
  %v4452 = load i64, ptr %slot19, align 8
  %p4453 = inttoptr i64 %v4452 to ptr
  store i32 2, ptr %p4453, align 4, !alias.scope !3, !noalias !4
  %v4454 = load i64, ptr %slot18, align 8
  %p4455 = inttoptr i64 %v4454 to ptr
  store i32 1, ptr %p4455, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared795
bb_rccopy795:
  %v4456 = load i64, ptr %slot27, align 8
  store i64 %v4456, ptr %slot662, align 8
  %v4457 = load i64, ptr %slot47, align 8
  store i64 %v4457, ptr %slot663, align 8
  %v4458 = load i64, ptr %slot640, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  %ld4460 = load i64, ptr %p4459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4460, ptr %slot664, align 8
  %v4461 = load i64, ptr %slot664, align 8
  %cmp4462 = icmp ne i64 %v4461, 0
  %cv4463 = zext i1 %cmp4462 to i32
  store i32 %cv4463, ptr %slot665, align 8
  %v4464 = load i32, ptr %slot665, align 8
  %cv4465 = zext i32 %v4464 to i64
  %cond4466 = icmp ne i64 %cv4465, 0
  br i1 %cond4466, label %bb_rcgnn828, label %bb_rcgplain828
bb_rcgnn828:
  %v4467 = load i64, ptr %slot664, align 8
  %op4468 = sub i64 %v4467, 16
  store i64 %op4468, ptr %slot666, align 8
  %v4469 = load i64, ptr %slot664, align 8
  %p4470 = inttoptr i64 %v4469 to ptr
  %rgep4471 = getelementptr i8, ptr %p4470, i64 -16
  %ld4472 = load i64, ptr %rgep4471, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4472, ptr %slot667, align 8
  %v4473 = load i64, ptr %slot667, align 8
  %op4474 = and i64 %v4473, 4611686018427387906
  store i64 %op4474, ptr %slot668, align 8
  %v4475 = load i64, ptr %slot668, align 8
  %cmp4476 = icmp ne i64 %v4475, 0
  %cv4477 = zext i1 %cmp4476 to i32
  store i32 %cv4477, ptr %slot669, align 8
  %v4478 = load i32, ptr %slot669, align 8
  %cv4479 = zext i32 %v4478 to i64
  %cond4480 = icmp ne i64 %cv4479, 0
  br i1 %cond4480, label %bb_rcgspecial828, label %bb_rcginc828
bb_rcginc828:
  %v4481 = load i64, ptr %slot664, align 8
  %op4482 = sub i64 %v4481, 32
  store i64 %op4482, ptr %slot670, align 8
  %v4483 = load i64, ptr %slot664, align 8
  %p4484 = inttoptr i64 %v4483 to ptr
  %rgep4485 = getelementptr i8, ptr %p4484, i64 -32
  %ld4486 = load i64, ptr %rgep4485, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4486, ptr %slot671, align 8
  %v4487 = load i64, ptr %slot671, align 8
  %op4488 = add i64 %v4487, 1
  store i64 %op4488, ptr %slot672, align 8
  %v4489 = load i64, ptr %slot672, align 8
  %cmp4490 = icmp eq i64 %v4489, 0
  %cv4491 = zext i1 %cmp4490 to i32
  store i32 %cv4491, ptr %slot673, align 8
  %v4492 = load i32, ptr %slot673, align 8
  %cv4493 = zext i32 %v4492 to i64
  %cond4494 = icmp ne i64 %cv4493, 0
  br i1 %cond4494, label %bb_rcglimit828, label %bb_rcgcapacity828
bb_rcglimit828:
  %v4495 = load i64, ptr %slot1, align 8
  %p4496 = inttoptr i64 %v4495 to ptr
  %call4497 = call i32 @myl_qbe_rc_status(ptr %p4496, i32 2) nomerge, !dbg !150
  store i32 %call4497, ptr %slot674, align 8
  br label %bb_failure
bb_rcgcapacity828:
  %v4498 = load i64, ptr %slot672, align 8
  %v4499 = load i64, ptr %slot664, align 8
  %p4500 = inttoptr i64 %v4499 to ptr
  %rgep4501 = getelementptr i8, ptr %p4500, i64 -32
  store i64 %v4498, ptr %rgep4501, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain828
bb_rcgspecial828:
  %v4502 = load i64, ptr %slot667, align 8
  %op4503 = and i64 %v4502, 4611686018427387904
  store i64 %op4503, ptr %slot675, align 8
  %v4504 = load i64, ptr %slot675, align 8
  %cmp4505 = icmp ne i64 %v4504, 0
  %cv4506 = zext i1 %cmp4505 to i32
  store i32 %cv4506, ptr %slot676, align 8
  %v4507 = load i32, ptr %slot676, align 8
  %cv4508 = zext i32 %v4507 to i64
  %cond4509 = icmp ne i64 %cv4508, 0
  br i1 %cond4509, label %bb_rcgslow828, label %bb_rcgplain828
bb_rcgslow828:
  %v4510 = load i64, ptr %slot46, align 8
  %v4511 = load i64, ptr %slot662, align 8
  %v4512 = load i64, ptr %slot640, align 8
  %v4513 = load i64, ptr %slot663, align 8
  %cv4514 = trunc i64 %v4513 to i32
  %call4515 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v4510, i64 %v4511, i64 %v4512, i32 %cv4514) nomerge, !dbg !150
  store i32 %call4515, ptr %slot677, align 8
  %v4516 = load i32, ptr %slot677, align 8
  %cv4517 = zext i32 %v4516 to i64
  %cond4518 = icmp ne i64 %cv4517, 0
  br i1 %cond4518, label %bb_rcsuccess842, label %bb_rcfailure842
bb_rcfailure842:
  %v4519 = load i64, ptr %slot46, align 8
  %p4520 = inttoptr i64 %v4519 to ptr
  %call4521 = call i32 @myl_rc_take_failure(ptr %p4520) nomerge, !dbg !150
  store i32 %call4521, ptr %slot678, align 8
  %v4522 = load i64, ptr %slot1, align 8
  %p4523 = inttoptr i64 %v4522 to ptr
  %v4524 = load i32, ptr %slot678, align 8
  %call4525 = call i32 @myl_qbe_rc_status(ptr %p4523, i32 %v4524) nomerge, !dbg !150
  store i32 %call4525, ptr %slot679, align 8
  br label %bb_failure
bb_rcsuccess842:
  br label %bb_rcgdone828
bb_rcgplain828:
  %v4526 = load i64, ptr %slot664, align 8
  %v4527 = load i64, ptr %slot662, align 8
  %p4528 = inttoptr i64 %v4527 to ptr
  store i64 %v4526, ptr %p4528, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone828
bb_rcgdone828:
  %v4529 = load i64, ptr %slot19, align 8
  %p4530 = inttoptr i64 %v4529 to ptr
  store i32 2, ptr %p4530, align 4, !alias.scope !3, !noalias !4
  %v4531 = load i64, ptr %slot18, align 8
  %p4532 = inttoptr i64 %v4531 to ptr
  store i32 1, ptr %p4532, align 4, !alias.scope !3, !noalias !4
  %v4533 = load i64, ptr %slot14, align 8
  %p4534 = inttoptr i64 %v4533 to ptr
  %ld4535 = load i32, ptr %p4534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4535, ptr %slot680, align 8
  %v4536 = load i32, ptr %slot680, align 8
  %cv4537 = zext i32 %v4536 to i64
  %cond4538 = icmp ne i64 %cv4537, 0
  br i1 %cond4538, label %bb_rcslotdrop849, label %bb_rcslotdone849
bb_rcslotdrop849:
  %v4539 = load i64, ptr %slot14, align 8
  %p4540 = inttoptr i64 %v4539 to ptr
  store i32 0, ptr %p4540, align 4, !alias.scope !3, !noalias !4
  %v4541 = load i64, ptr %slot22, align 8
  store i64 %v4541, ptr %slot681, align 8
  %v4542 = load i64, ptr %slot15, align 8
  %p4543 = inttoptr i64 %v4542 to ptr
  %ld4544 = load i32, ptr %p4543, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4544, ptr %slot682, align 8
  %v4545 = load i32, ptr %slot682, align 8
  %op4546 = and i32 %v4545, 28
  store i32 %op4546, ptr %slot683, align 8
  %v4547 = load i32, ptr %slot683, align 8
  %cv4548 = zext i32 %v4547 to i64
  %cond4549 = icmp ne i64 %cv4548, 0
  br i1 %cond4549, label %bb_rcslotrole849, label %bb_rcslotowner849
bb_rcslotrole849:
  %v4550 = load i64, ptr %slot46, align 8
  store i64 %v4550, ptr %slot684, align 8
  %v4551 = load i64, ptr %slot681, align 8
  %p4552 = inttoptr i64 %v4551 to ptr
  %ld4553 = load i64, ptr %p4552, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4553, ptr %slot685, align 8
  %v4554 = load i64, ptr %slot685, align 8
  %cmp4555 = icmp ne i64 %v4554, 0
  %cv4556 = zext i1 %cmp4555 to i32
  store i32 %cv4556, ptr %slot686, align 8
  %v4557 = load i32, ptr %slot686, align 8
  %cv4558 = zext i32 %v4557 to i64
  %cond4559 = icmp ne i64 %cv4558, 0
  br i1 %cond4559, label %bb_rcgnn865, label %bb_rcgdone865
bb_rcgnn865:
  %v4560 = load i64, ptr %slot685, align 8
  %op4561 = sub i64 %v4560, 16
  store i64 %op4561, ptr %slot687, align 8
  %v4562 = load i64, ptr %slot685, align 8
  %p4563 = inttoptr i64 %v4562 to ptr
  %rgep4564 = getelementptr i8, ptr %p4563, i64 -16
  %ld4565 = load i64, ptr %rgep4564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4565, ptr %slot688, align 8
  %v4566 = load i64, ptr %slot688, align 8
  %op4567 = and i64 %v4566, 4611686018427387906
  store i64 %op4567, ptr %slot689, align 8
  %v4568 = load i64, ptr %slot689, align 8
  %cmp4569 = icmp ne i64 %v4568, 0
  %cv4570 = zext i1 %cmp4569 to i32
  store i32 %cv4570, ptr %slot690, align 8
  %v4571 = load i32, ptr %slot690, align 8
  %cv4572 = zext i32 %v4571 to i64
  %cond4573 = icmp ne i64 %cv4572, 0
  br i1 %cond4573, label %bb_rcgclear865, label %bb_rcgcounted865
bb_rcgcounted865:
  %v4574 = load i64, ptr %slot685, align 8
  %op4575 = sub i64 %v4574, 24
  store i64 %op4575, ptr %slot691, align 8
  %v4576 = load i64, ptr %slot685, align 8
  %p4577 = inttoptr i64 %v4576 to ptr
  %rgep4578 = getelementptr i8, ptr %p4577, i64 -24
  %ld4579 = load i64, ptr %rgep4578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4579, ptr %slot692, align 8
  %v4580 = load i64, ptr %slot692, align 8
  %op4581 = sub i64 %v4580, 1
  store i64 %op4581, ptr %slot693, align 8
  %v4582 = load i64, ptr %slot693, align 8
  %cmp4583 = icmp eq i64 %v4582, 0
  %cv4584 = zext i1 %cmp4583 to i32
  store i32 %cv4584, ptr %slot694, align 8
  %v4585 = load i32, ptr %slot694, align 8
  %cv4586 = zext i32 %v4585 to i64
  %cond4587 = icmp ne i64 %cv4586, 0
  br i1 %cond4587, label %bb_rcglast865, label %bb_rcgdec865
bb_rcglast865:
  %v4588 = load i64, ptr %slot685, align 8
  %op4589 = sub i64 %v4588, 32
  store i64 %op4589, ptr %slot695, align 8
  %v4590 = load i64, ptr %slot685, align 8
  %p4591 = inttoptr i64 %v4590 to ptr
  %rgep4592 = getelementptr i8, ptr %p4591, i64 -32
  %ld4593 = load i64, ptr %rgep4592, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4593, ptr %slot696, align 8
  %v4594 = load i64, ptr %slot696, align 8
  %cmp4595 = icmp ne i64 %v4594, 0
  %cv4596 = zext i1 %cmp4595 to i32
  store i32 %cv4596, ptr %slot697, align 8
  %v4597 = load i32, ptr %slot697, align 8
  %cv4598 = zext i32 %v4597 to i64
  %cond4599 = icmp ne i64 %cv4598, 0
  br i1 %cond4599, label %bb_rcgdec865, label %bb_rcgslow865
bb_rcgslow865:
  %v4600 = load i64, ptr %slot684, align 8
  %v4601 = load i64, ptr %slot681, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4600, i64 %v4601) nomerge, !dbg !150
  br label %bb_rcgdone865
bb_rcgdec865:
  %v4602 = load i64, ptr %slot693, align 8
  %v4603 = load i64, ptr %slot685, align 8
  %p4604 = inttoptr i64 %v4603 to ptr
  %rgep4605 = getelementptr i8, ptr %p4604, i64 -24
  store i64 %v4602, ptr %rgep4605, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear865
bb_rcgclear865:
  %v4606 = load i64, ptr %slot681, align 8
  %p4607 = inttoptr i64 %v4606 to ptr
  store i64 0, ptr %p4607, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone865
bb_rcgdone865:
  br label %bb_rcslotdone849
bb_rcslotowner849:
  %v4608 = load i64, ptr %slot46, align 8
  store i64 %v4608, ptr %slot698, align 8
  %v4609 = load i64, ptr %slot681, align 8
  %p4610 = inttoptr i64 %v4609 to ptr
  %ld4611 = load i64, ptr %p4610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4611, ptr %slot699, align 8
  %v4612 = load i64, ptr %slot699, align 8
  %cmp4613 = icmp ne i64 %v4612, 0
  %cv4614 = zext i1 %cmp4613 to i32
  store i32 %cv4614, ptr %slot700, align 8
  %v4615 = load i32, ptr %slot700, align 8
  %cv4616 = zext i32 %v4615 to i64
  %cond4617 = icmp ne i64 %cv4616, 0
  br i1 %cond4617, label %bb_rcgnn880, label %bb_rcgdone880
bb_rcgnn880:
  %v4618 = load i64, ptr %slot699, align 8
  %op4619 = sub i64 %v4618, 16
  store i64 %op4619, ptr %slot701, align 8
  %v4620 = load i64, ptr %slot699, align 8
  %p4621 = inttoptr i64 %v4620 to ptr
  %rgep4622 = getelementptr i8, ptr %p4621, i64 -16
  %ld4623 = load i64, ptr %rgep4622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4623, ptr %slot702, align 8
  %v4624 = load i64, ptr %slot702, align 8
  %op4625 = and i64 %v4624, 4611686018427387906
  store i64 %op4625, ptr %slot703, align 8
  %v4626 = load i64, ptr %slot703, align 8
  %cmp4627 = icmp ne i64 %v4626, 0
  %cv4628 = zext i1 %cmp4627 to i32
  store i32 %cv4628, ptr %slot704, align 8
  %v4629 = load i32, ptr %slot704, align 8
  %cv4630 = zext i32 %v4629 to i64
  %cond4631 = icmp ne i64 %cv4630, 0
  br i1 %cond4631, label %bb_rcgclear880, label %bb_rcgcounted880
bb_rcgcounted880:
  %v4632 = load i64, ptr %slot699, align 8
  %op4633 = sub i64 %v4632, 32
  store i64 %op4633, ptr %slot705, align 8
  %v4634 = load i64, ptr %slot699, align 8
  %p4635 = inttoptr i64 %v4634 to ptr
  %rgep4636 = getelementptr i8, ptr %p4635, i64 -32
  %ld4637 = load i64, ptr %rgep4636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4637, ptr %slot706, align 8
  %v4638 = load i64, ptr %slot706, align 8
  %op4639 = sub i64 %v4638, 1
  store i64 %op4639, ptr %slot707, align 8
  %v4640 = load i64, ptr %slot707, align 8
  %cmp4641 = icmp eq i64 %v4640, 0
  %cv4642 = zext i1 %cmp4641 to i32
  store i32 %cv4642, ptr %slot708, align 8
  %v4643 = load i32, ptr %slot708, align 8
  %cv4644 = zext i32 %v4643 to i64
  %cond4645 = icmp ne i64 %cv4644, 0
  br i1 %cond4645, label %bb_rcglast880, label %bb_rcgdec880
bb_rcglast880:
  %v4646 = load i64, ptr %slot699, align 8
  %op4647 = sub i64 %v4646, 24
  store i64 %op4647, ptr %slot709, align 8
  %v4648 = load i64, ptr %slot699, align 8
  %p4649 = inttoptr i64 %v4648 to ptr
  %rgep4650 = getelementptr i8, ptr %p4649, i64 -24
  %ld4651 = load i64, ptr %rgep4650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4651, ptr %slot710, align 8
  %v4652 = load i64, ptr %slot710, align 8
  %cmp4653 = icmp ne i64 %v4652, 0
  %cv4654 = zext i1 %cmp4653 to i32
  store i32 %cv4654, ptr %slot711, align 8
  %v4655 = load i32, ptr %slot711, align 8
  %cv4656 = zext i32 %v4655 to i64
  %cond4657 = icmp ne i64 %cv4656, 0
  br i1 %cond4657, label %bb_rcgdec880, label %bb_rcgslow880
bb_rcgslow880:
  %v4658 = load i64, ptr %slot698, align 8
  %v4659 = load i64, ptr %slot681, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4658, i64 %v4659) nomerge, !dbg !150
  br label %bb_rcgdone880
bb_rcgdec880:
  %v4660 = load i64, ptr %slot707, align 8
  %v4661 = load i64, ptr %slot699, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %rgep4663 = getelementptr i8, ptr %p4662, i64 -32
  store i64 %v4660, ptr %rgep4663, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear880
bb_rcgclear880:
  %v4664 = load i64, ptr %slot681, align 8
  %p4665 = inttoptr i64 %v4664 to ptr
  store i64 0, ptr %p4665, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone880
bb_rcgdone880:
  br label %bb_rcslotdone849
bb_rcslotdone849:
  br label %bb_rcprepared795
bb_rcprepared795:
  %v4666 = load i64, ptr %slot27, align 8
  store i64 %v4666, ptr %slot712, align 8
  %v4667 = load i64, ptr %slot712, align 8
  %v4668 = load i64, ptr %slot638, align 8
  %p4669 = inttoptr i64 %v4667 to ptr
  %p4670 = inttoptr i64 %v4668 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4670, ptr %p4669, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4671 = load i64, ptr %slot18, align 8
  %p4672 = inttoptr i64 %v4671 to ptr
  store i32 0, ptr %p4672, align 4, !alias.scope !3, !noalias !4
  %v4673 = load i64, ptr %slot41, align 8
  %p4674 = inttoptr i64 %v4673 to ptr
  %ld4675 = load i64, ptr %p4674, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4675, ptr %slot713, align 8
  %v4676 = load i64, ptr %slot713, align 8
  %v4677 = load i64, ptr %slot26, align 8
  %p4678 = inttoptr i64 %v4677 to ptr
  store i64 %v4676, ptr %p4678, align 8, !alias.scope !3, !noalias !4
  %v4679 = load i64, ptr %slot26, align 8
  store i64 %v4679, ptr %slot714, align 8
  %v4680 = load i64, ptr %slot553, align 8
  %p4682 = inttoptr i64 %v4680 to ptr
  %gep4683 = getelementptr i8, ptr %p4682, i64 16
  %op4681 = ptrtoint ptr %gep4683 to i64
  store i64 %op4681, ptr %slot715, align 8
  %v4684 = load i64, ptr %slot41, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  %ld4686 = load i64, ptr %p4685, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4686, ptr %slot716, align 8
  %v4687 = load i64, ptr %slot716, align 8
  %v4688 = load i64, ptr %slot26, align 8
  %p4689 = inttoptr i64 %v4688 to ptr
  store i64 %v4687, ptr %p4689, align 8, !alias.scope !3, !noalias !4
  %v4690 = load i64, ptr %slot26, align 8
  store i64 %v4690, ptr %slot717, align 8
  %v4691 = load i64, ptr %slot16, align 8
  %p4692 = inttoptr i64 %v4691 to ptr
  %ld4693 = load i32, ptr %p4692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4693, ptr %slot718, align 8
  %v4694 = load i64, ptr %slot17, align 8
  %p4695 = inttoptr i64 %v4694 to ptr
  %ld4696 = load i32, ptr %p4695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4696, ptr %slot719, align 8
  %v4697 = load i32, ptr %slot719, align 8
  %op4698 = and i32 %v4697, 24
  store i32 %op4698, ptr %slot719, align 8
  %v4699 = load i32, ptr %slot719, align 8
  %cmp4700 = icmp eq i32 %v4699, 0
  %cv4701 = zext i1 %cmp4700 to i32
  store i32 %cv4701, ptr %slot720, align 8
  %v4702 = load i32, ptr %slot718, align 8
  %v4703 = load i32, ptr %slot720, align 8
  %op4704 = and i32 %v4702, %v4703
  store i32 %op4704, ptr %slot721, align 8
  %v4705 = load i32, ptr %slot721, align 8
  %cv4706 = zext i32 %v4705 to i64
  %cond4707 = icmp ne i64 %cv4706, 0
  br i1 %cond4707, label %bb_rctake891, label %bb_rccopy891
bb_rctake891:
  %v4708 = load i64, ptr %slot27, align 8
  store i64 %v4708, ptr %slot722, align 8
  %v4709 = load i64, ptr %slot47, align 8
  store i64 %v4709, ptr %slot723, align 8
  %v4710 = load i64, ptr %slot717, align 8
  %v4711 = load i64, ptr %slot722, align 8
  %op4712 = sub i64 %v4710, %v4711
  store i64 %op4712, ptr %slot724, align 8
  %v4713 = load i64, ptr %slot722, align 8
  %v4714 = load i64, ptr %slot717, align 8
  %op4715 = sub i64 %v4713, %v4714
  store i64 %op4715, ptr %slot725, align 8
  %v4716 = load i64, ptr %slot724, align 8
  %cmp4717 = icmp ult i64 %v4716, 8
  %cv4718 = zext i1 %cmp4717 to i32
  store i32 %cv4718, ptr %slot726, align 8
  %v4719 = load i64, ptr %slot725, align 8
  %cmp4720 = icmp ult i64 %v4719, 8
  %cv4721 = zext i1 %cmp4720 to i32
  store i32 %cv4721, ptr %slot727, align 8
  %v4722 = load i32, ptr %slot726, align 8
  %v4723 = load i32, ptr %slot727, align 8
  %op4724 = or i32 %v4722, %v4723
  store i32 %op4724, ptr %slot728, align 8
  %v4725 = load i32, ptr %slot728, align 8
  %cv4726 = zext i32 %v4725 to i64
  %cond4727 = icmp ne i64 %cv4726, 0
  br i1 %cond4727, label %bb_rcmoveslow900, label %bb_rcmovecheck900
bb_rcmovecheck900:
  %v4728 = load i64, ptr %slot717, align 8
  %p4730 = inttoptr i64 %v4728 to ptr
  %gep4731 = getelementptr i8, ptr %p4730, i64 0
  %op4729 = ptrtoint ptr %gep4731 to i64
  store i64 %op4729, ptr %slot729, align 8
  %v4732 = load i64, ptr %slot729, align 8
  %p4733 = inttoptr i64 %v4732 to ptr
  %ld4734 = load i64, ptr %p4733, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4734, ptr %slot730, align 8
  %v4735 = load i64, ptr %slot730, align 8
  %cmp4736 = icmp ne i64 %v4735, 0
  %cv4737 = zext i1 %cmp4736 to i32
  store i32 %cv4737, ptr %slot731, align 8
  %v4738 = load i32, ptr %slot731, align 8
  %cv4739 = zext i32 %v4738 to i64
  %cond4740 = icmp ne i64 %cv4739, 0
  br i1 %cond4740, label %bb_rcmoveheader908, label %bb_rcmovenext908
bb_rcmoveheader908:
  %v4741 = load i64, ptr %slot730, align 8
  %op4742 = sub i64 %v4741, 16
  store i64 %op4742, ptr %slot732, align 8
  %v4743 = load i64, ptr %slot730, align 8
  %p4744 = inttoptr i64 %v4743 to ptr
  %rgep4745 = getelementptr i8, ptr %p4744, i64 -16
  %ld4746 = load i64, ptr %rgep4745, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4746, ptr %slot733, align 8
  %v4747 = load i64, ptr %slot733, align 8
  %op4748 = and i64 %v4747, 5764607523034234881
  store i64 %op4748, ptr %slot734, align 8
  %v4749 = load i64, ptr %slot734, align 8
  %cmp4750 = icmp ne i64 %v4749, 0
  %cv4751 = zext i1 %cmp4750 to i32
  store i32 %cv4751, ptr %slot735, align 8
  %v4752 = load i32, ptr %slot735, align 8
  %cv4753 = zext i32 %v4752 to i64
  %cond4754 = icmp ne i64 %cv4753, 0
  br i1 %cond4754, label %bb_rcmoveslow900, label %bb_rcmovenext908
bb_rcmovenext908:
  %v4755 = load i64, ptr %slot717, align 8
  %v4756 = load i64, ptr %slot722, align 8
  %p4757 = inttoptr i64 %v4755 to ptr
  %p4758 = inttoptr i64 %v4756 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4758, ptr %p4757, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4759 = load i64, ptr %slot717, align 8
  %p4760 = inttoptr i64 %v4759 to ptr
  store i64 0, ptr %p4760, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved900
bb_rcmoveslow900:
  %v4761 = load i64, ptr %slot46, align 8
  %v4762 = load i64, ptr %slot722, align 8
  %v4763 = load i64, ptr %slot717, align 8
  %v4764 = load i64, ptr %slot723, align 8
  %cv4765 = trunc i64 %v4764 to i32
  %call4766 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v4761, i64 %v4762, i64 %v4763, i32 %cv4765) nomerge, !dbg !150
  store i32 %call4766, ptr %slot736, align 8
  %v4767 = load i32, ptr %slot736, align 8
  %cv4768 = zext i32 %v4767 to i64
  %cond4769 = icmp ne i64 %cv4768, 0
  br i1 %cond4769, label %bb_rcsuccess915, label %bb_rcfailure915
bb_rcfailure915:
  %v4770 = load i64, ptr %slot46, align 8
  %p4771 = inttoptr i64 %v4770 to ptr
  %call4772 = call i32 @myl_rc_take_failure(ptr %p4771) nomerge, !dbg !150
  store i32 %call4772, ptr %slot737, align 8
  %v4773 = load i64, ptr %slot1, align 8
  %p4774 = inttoptr i64 %v4773 to ptr
  %v4775 = load i32, ptr %slot737, align 8
  %call4776 = call i32 @myl_qbe_rc_status(ptr %p4774, i32 %v4775) nomerge, !dbg !150
  store i32 %call4776, ptr %slot738, align 8
  br label %bb_failure
bb_rcsuccess915:
  br label %bb_rcmoved900
bb_rcmoved900:
  %v4777 = load i64, ptr %slot16, align 8
  %p4778 = inttoptr i64 %v4777 to ptr
  store i32 0, ptr %p4778, align 4, !alias.scope !3, !noalias !4
  %v4779 = load i64, ptr %slot19, align 8
  %p4780 = inttoptr i64 %v4779 to ptr
  store i32 2, ptr %p4780, align 4, !alias.scope !3, !noalias !4
  %v4781 = load i64, ptr %slot18, align 8
  %p4782 = inttoptr i64 %v4781 to ptr
  store i32 1, ptr %p4782, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared891
bb_rccopy891:
  %v4783 = load i64, ptr %slot27, align 8
  store i64 %v4783, ptr %slot739, align 8
  %v4784 = load i64, ptr %slot47, align 8
  store i64 %v4784, ptr %slot740, align 8
  %v4785 = load i64, ptr %slot717, align 8
  %p4786 = inttoptr i64 %v4785 to ptr
  %ld4787 = load i64, ptr %p4786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4787, ptr %slot741, align 8
  %v4788 = load i64, ptr %slot741, align 8
  %cmp4789 = icmp ne i64 %v4788, 0
  %cv4790 = zext i1 %cmp4789 to i32
  store i32 %cv4790, ptr %slot742, align 8
  %v4791 = load i32, ptr %slot742, align 8
  %cv4792 = zext i32 %v4791 to i64
  %cond4793 = icmp ne i64 %cv4792, 0
  br i1 %cond4793, label %bb_rcgnn924, label %bb_rcgplain924
bb_rcgnn924:
  %v4794 = load i64, ptr %slot741, align 8
  %op4795 = sub i64 %v4794, 16
  store i64 %op4795, ptr %slot743, align 8
  %v4796 = load i64, ptr %slot741, align 8
  %p4797 = inttoptr i64 %v4796 to ptr
  %rgep4798 = getelementptr i8, ptr %p4797, i64 -16
  %ld4799 = load i64, ptr %rgep4798, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4799, ptr %slot744, align 8
  %v4800 = load i64, ptr %slot744, align 8
  %op4801 = and i64 %v4800, 4611686018427387906
  store i64 %op4801, ptr %slot745, align 8
  %v4802 = load i64, ptr %slot745, align 8
  %cmp4803 = icmp ne i64 %v4802, 0
  %cv4804 = zext i1 %cmp4803 to i32
  store i32 %cv4804, ptr %slot746, align 8
  %v4805 = load i32, ptr %slot746, align 8
  %cv4806 = zext i32 %v4805 to i64
  %cond4807 = icmp ne i64 %cv4806, 0
  br i1 %cond4807, label %bb_rcgspecial924, label %bb_rcginc924
bb_rcginc924:
  %v4808 = load i64, ptr %slot741, align 8
  %op4809 = sub i64 %v4808, 32
  store i64 %op4809, ptr %slot747, align 8
  %v4810 = load i64, ptr %slot741, align 8
  %p4811 = inttoptr i64 %v4810 to ptr
  %rgep4812 = getelementptr i8, ptr %p4811, i64 -32
  %ld4813 = load i64, ptr %rgep4812, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4813, ptr %slot748, align 8
  %v4814 = load i64, ptr %slot748, align 8
  %op4815 = add i64 %v4814, 1
  store i64 %op4815, ptr %slot749, align 8
  %v4816 = load i64, ptr %slot749, align 8
  %cmp4817 = icmp eq i64 %v4816, 0
  %cv4818 = zext i1 %cmp4817 to i32
  store i32 %cv4818, ptr %slot750, align 8
  %v4819 = load i32, ptr %slot750, align 8
  %cv4820 = zext i32 %v4819 to i64
  %cond4821 = icmp ne i64 %cv4820, 0
  br i1 %cond4821, label %bb_rcglimit924, label %bb_rcgcapacity924
bb_rcglimit924:
  %v4822 = load i64, ptr %slot1, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  %call4824 = call i32 @myl_qbe_rc_status(ptr %p4823, i32 2) nomerge, !dbg !150
  store i32 %call4824, ptr %slot751, align 8
  br label %bb_failure
bb_rcgcapacity924:
  %v4825 = load i64, ptr %slot749, align 8
  %v4826 = load i64, ptr %slot741, align 8
  %p4827 = inttoptr i64 %v4826 to ptr
  %rgep4828 = getelementptr i8, ptr %p4827, i64 -32
  store i64 %v4825, ptr %rgep4828, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain924
bb_rcgspecial924:
  %v4829 = load i64, ptr %slot744, align 8
  %op4830 = and i64 %v4829, 4611686018427387904
  store i64 %op4830, ptr %slot752, align 8
  %v4831 = load i64, ptr %slot752, align 8
  %cmp4832 = icmp ne i64 %v4831, 0
  %cv4833 = zext i1 %cmp4832 to i32
  store i32 %cv4833, ptr %slot753, align 8
  %v4834 = load i32, ptr %slot753, align 8
  %cv4835 = zext i32 %v4834 to i64
  %cond4836 = icmp ne i64 %cv4835, 0
  br i1 %cond4836, label %bb_rcgslow924, label %bb_rcgplain924
bb_rcgslow924:
  %v4837 = load i64, ptr %slot46, align 8
  %v4838 = load i64, ptr %slot739, align 8
  %v4839 = load i64, ptr %slot717, align 8
  %v4840 = load i64, ptr %slot740, align 8
  %cv4841 = trunc i64 %v4840 to i32
  %call4842 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v4837, i64 %v4838, i64 %v4839, i32 %cv4841) nomerge, !dbg !150
  store i32 %call4842, ptr %slot754, align 8
  %v4843 = load i32, ptr %slot754, align 8
  %cv4844 = zext i32 %v4843 to i64
  %cond4845 = icmp ne i64 %cv4844, 0
  br i1 %cond4845, label %bb_rcsuccess938, label %bb_rcfailure938
bb_rcfailure938:
  %v4846 = load i64, ptr %slot46, align 8
  %p4847 = inttoptr i64 %v4846 to ptr
  %call4848 = call i32 @myl_rc_take_failure(ptr %p4847) nomerge, !dbg !150
  store i32 %call4848, ptr %slot755, align 8
  %v4849 = load i64, ptr %slot1, align 8
  %p4850 = inttoptr i64 %v4849 to ptr
  %v4851 = load i32, ptr %slot755, align 8
  %call4852 = call i32 @myl_qbe_rc_status(ptr %p4850, i32 %v4851) nomerge, !dbg !150
  store i32 %call4852, ptr %slot756, align 8
  br label %bb_failure
bb_rcsuccess938:
  br label %bb_rcgdone924
bb_rcgplain924:
  %v4853 = load i64, ptr %slot741, align 8
  %v4854 = load i64, ptr %slot739, align 8
  %p4855 = inttoptr i64 %v4854 to ptr
  store i64 %v4853, ptr %p4855, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone924
bb_rcgdone924:
  %v4856 = load i64, ptr %slot19, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  store i32 2, ptr %p4857, align 4, !alias.scope !3, !noalias !4
  %v4858 = load i64, ptr %slot18, align 8
  %p4859 = inttoptr i64 %v4858 to ptr
  store i32 1, ptr %p4859, align 4, !alias.scope !3, !noalias !4
  %v4860 = load i64, ptr %slot16, align 8
  %p4861 = inttoptr i64 %v4860 to ptr
  %ld4862 = load i32, ptr %p4861, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4862, ptr %slot757, align 8
  %v4863 = load i32, ptr %slot757, align 8
  %cv4864 = zext i32 %v4863 to i64
  %cond4865 = icmp ne i64 %cv4864, 0
  br i1 %cond4865, label %bb_rcslotdrop945, label %bb_rcslotdone945
bb_rcslotdrop945:
  %v4866 = load i64, ptr %slot16, align 8
  %p4867 = inttoptr i64 %v4866 to ptr
  store i32 0, ptr %p4867, align 4, !alias.scope !3, !noalias !4
  %v4868 = load i64, ptr %slot23, align 8
  store i64 %v4868, ptr %slot758, align 8
  %v4869 = load i64, ptr %slot17, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  %ld4871 = load i32, ptr %p4870, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4871, ptr %slot759, align 8
  %v4872 = load i32, ptr %slot759, align 8
  %op4873 = and i32 %v4872, 28
  store i32 %op4873, ptr %slot760, align 8
  %v4874 = load i32, ptr %slot760, align 8
  %cv4875 = zext i32 %v4874 to i64
  %cond4876 = icmp ne i64 %cv4875, 0
  br i1 %cond4876, label %bb_rcslotrole945, label %bb_rcslotowner945
bb_rcslotrole945:
  %v4877 = load i64, ptr %slot46, align 8
  store i64 %v4877, ptr %slot761, align 8
  %v4878 = load i64, ptr %slot758, align 8
  %p4879 = inttoptr i64 %v4878 to ptr
  %ld4880 = load i64, ptr %p4879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4880, ptr %slot762, align 8
  %v4881 = load i64, ptr %slot762, align 8
  %cmp4882 = icmp ne i64 %v4881, 0
  %cv4883 = zext i1 %cmp4882 to i32
  store i32 %cv4883, ptr %slot763, align 8
  %v4884 = load i32, ptr %slot763, align 8
  %cv4885 = zext i32 %v4884 to i64
  %cond4886 = icmp ne i64 %cv4885, 0
  br i1 %cond4886, label %bb_rcgnn961, label %bb_rcgdone961
bb_rcgnn961:
  %v4887 = load i64, ptr %slot762, align 8
  %op4888 = sub i64 %v4887, 16
  store i64 %op4888, ptr %slot764, align 8
  %v4889 = load i64, ptr %slot762, align 8
  %p4890 = inttoptr i64 %v4889 to ptr
  %rgep4891 = getelementptr i8, ptr %p4890, i64 -16
  %ld4892 = load i64, ptr %rgep4891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4892, ptr %slot765, align 8
  %v4893 = load i64, ptr %slot765, align 8
  %op4894 = and i64 %v4893, 4611686018427387906
  store i64 %op4894, ptr %slot766, align 8
  %v4895 = load i64, ptr %slot766, align 8
  %cmp4896 = icmp ne i64 %v4895, 0
  %cv4897 = zext i1 %cmp4896 to i32
  store i32 %cv4897, ptr %slot767, align 8
  %v4898 = load i32, ptr %slot767, align 8
  %cv4899 = zext i32 %v4898 to i64
  %cond4900 = icmp ne i64 %cv4899, 0
  br i1 %cond4900, label %bb_rcgclear961, label %bb_rcgcounted961
bb_rcgcounted961:
  %v4901 = load i64, ptr %slot762, align 8
  %op4902 = sub i64 %v4901, 24
  store i64 %op4902, ptr %slot768, align 8
  %v4903 = load i64, ptr %slot762, align 8
  %p4904 = inttoptr i64 %v4903 to ptr
  %rgep4905 = getelementptr i8, ptr %p4904, i64 -24
  %ld4906 = load i64, ptr %rgep4905, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4906, ptr %slot769, align 8
  %v4907 = load i64, ptr %slot769, align 8
  %op4908 = sub i64 %v4907, 1
  store i64 %op4908, ptr %slot770, align 8
  %v4909 = load i64, ptr %slot770, align 8
  %cmp4910 = icmp eq i64 %v4909, 0
  %cv4911 = zext i1 %cmp4910 to i32
  store i32 %cv4911, ptr %slot771, align 8
  %v4912 = load i32, ptr %slot771, align 8
  %cv4913 = zext i32 %v4912 to i64
  %cond4914 = icmp ne i64 %cv4913, 0
  br i1 %cond4914, label %bb_rcglast961, label %bb_rcgdec961
bb_rcglast961:
  %v4915 = load i64, ptr %slot762, align 8
  %op4916 = sub i64 %v4915, 32
  store i64 %op4916, ptr %slot772, align 8
  %v4917 = load i64, ptr %slot762, align 8
  %p4918 = inttoptr i64 %v4917 to ptr
  %rgep4919 = getelementptr i8, ptr %p4918, i64 -32
  %ld4920 = load i64, ptr %rgep4919, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4920, ptr %slot773, align 8
  %v4921 = load i64, ptr %slot773, align 8
  %cmp4922 = icmp ne i64 %v4921, 0
  %cv4923 = zext i1 %cmp4922 to i32
  store i32 %cv4923, ptr %slot774, align 8
  %v4924 = load i32, ptr %slot774, align 8
  %cv4925 = zext i32 %v4924 to i64
  %cond4926 = icmp ne i64 %cv4925, 0
  br i1 %cond4926, label %bb_rcgdec961, label %bb_rcgslow961
bb_rcgslow961:
  %v4927 = load i64, ptr %slot761, align 8
  %v4928 = load i64, ptr %slot758, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4927, i64 %v4928) nomerge, !dbg !150
  br label %bb_rcgdone961
bb_rcgdec961:
  %v4929 = load i64, ptr %slot770, align 8
  %v4930 = load i64, ptr %slot762, align 8
  %p4931 = inttoptr i64 %v4930 to ptr
  %rgep4932 = getelementptr i8, ptr %p4931, i64 -24
  store i64 %v4929, ptr %rgep4932, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear961
bb_rcgclear961:
  %v4933 = load i64, ptr %slot758, align 8
  %p4934 = inttoptr i64 %v4933 to ptr
  store i64 0, ptr %p4934, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone961
bb_rcgdone961:
  br label %bb_rcslotdone945
bb_rcslotowner945:
  %v4935 = load i64, ptr %slot46, align 8
  store i64 %v4935, ptr %slot775, align 8
  %v4936 = load i64, ptr %slot758, align 8
  %p4937 = inttoptr i64 %v4936 to ptr
  %ld4938 = load i64, ptr %p4937, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4938, ptr %slot776, align 8
  %v4939 = load i64, ptr %slot776, align 8
  %cmp4940 = icmp ne i64 %v4939, 0
  %cv4941 = zext i1 %cmp4940 to i32
  store i32 %cv4941, ptr %slot777, align 8
  %v4942 = load i32, ptr %slot777, align 8
  %cv4943 = zext i32 %v4942 to i64
  %cond4944 = icmp ne i64 %cv4943, 0
  br i1 %cond4944, label %bb_rcgnn976, label %bb_rcgdone976
bb_rcgnn976:
  %v4945 = load i64, ptr %slot776, align 8
  %op4946 = sub i64 %v4945, 16
  store i64 %op4946, ptr %slot778, align 8
  %v4947 = load i64, ptr %slot776, align 8
  %p4948 = inttoptr i64 %v4947 to ptr
  %rgep4949 = getelementptr i8, ptr %p4948, i64 -16
  %ld4950 = load i64, ptr %rgep4949, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4950, ptr %slot779, align 8
  %v4951 = load i64, ptr %slot779, align 8
  %op4952 = and i64 %v4951, 4611686018427387906
  store i64 %op4952, ptr %slot780, align 8
  %v4953 = load i64, ptr %slot780, align 8
  %cmp4954 = icmp ne i64 %v4953, 0
  %cv4955 = zext i1 %cmp4954 to i32
  store i32 %cv4955, ptr %slot781, align 8
  %v4956 = load i32, ptr %slot781, align 8
  %cv4957 = zext i32 %v4956 to i64
  %cond4958 = icmp ne i64 %cv4957, 0
  br i1 %cond4958, label %bb_rcgclear976, label %bb_rcgcounted976
bb_rcgcounted976:
  %v4959 = load i64, ptr %slot776, align 8
  %op4960 = sub i64 %v4959, 32
  store i64 %op4960, ptr %slot782, align 8
  %v4961 = load i64, ptr %slot776, align 8
  %p4962 = inttoptr i64 %v4961 to ptr
  %rgep4963 = getelementptr i8, ptr %p4962, i64 -32
  %ld4964 = load i64, ptr %rgep4963, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4964, ptr %slot783, align 8
  %v4965 = load i64, ptr %slot783, align 8
  %op4966 = sub i64 %v4965, 1
  store i64 %op4966, ptr %slot784, align 8
  %v4967 = load i64, ptr %slot784, align 8
  %cmp4968 = icmp eq i64 %v4967, 0
  %cv4969 = zext i1 %cmp4968 to i32
  store i32 %cv4969, ptr %slot785, align 8
  %v4970 = load i32, ptr %slot785, align 8
  %cv4971 = zext i32 %v4970 to i64
  %cond4972 = icmp ne i64 %cv4971, 0
  br i1 %cond4972, label %bb_rcglast976, label %bb_rcgdec976
bb_rcglast976:
  %v4973 = load i64, ptr %slot776, align 8
  %op4974 = sub i64 %v4973, 24
  store i64 %op4974, ptr %slot786, align 8
  %v4975 = load i64, ptr %slot776, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  %rgep4977 = getelementptr i8, ptr %p4976, i64 -24
  %ld4978 = load i64, ptr %rgep4977, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4978, ptr %slot787, align 8
  %v4979 = load i64, ptr %slot787, align 8
  %cmp4980 = icmp ne i64 %v4979, 0
  %cv4981 = zext i1 %cmp4980 to i32
  store i32 %cv4981, ptr %slot788, align 8
  %v4982 = load i32, ptr %slot788, align 8
  %cv4983 = zext i32 %v4982 to i64
  %cond4984 = icmp ne i64 %cv4983, 0
  br i1 %cond4984, label %bb_rcgdec976, label %bb_rcgslow976
bb_rcgslow976:
  %v4985 = load i64, ptr %slot775, align 8
  %v4986 = load i64, ptr %slot758, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4985, i64 %v4986) nomerge, !dbg !150
  br label %bb_rcgdone976
bb_rcgdec976:
  %v4987 = load i64, ptr %slot784, align 8
  %v4988 = load i64, ptr %slot776, align 8
  %p4989 = inttoptr i64 %v4988 to ptr
  %rgep4990 = getelementptr i8, ptr %p4989, i64 -32
  store i64 %v4987, ptr %rgep4990, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear976
bb_rcgclear976:
  %v4991 = load i64, ptr %slot758, align 8
  %p4992 = inttoptr i64 %v4991 to ptr
  store i64 0, ptr %p4992, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone976
bb_rcgdone976:
  br label %bb_rcslotdone945
bb_rcslotdone945:
  br label %bb_rcprepared891
bb_rcprepared891:
  %v4993 = load i64, ptr %slot27, align 8
  store i64 %v4993, ptr %slot789, align 8
  %v4994 = load i64, ptr %slot789, align 8
  %v4995 = load i64, ptr %slot715, align 8
  %p4996 = inttoptr i64 %v4994 to ptr
  %p4997 = inttoptr i64 %v4995 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4997, ptr %p4996, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4998 = load i64, ptr %slot18, align 8
  %p4999 = inttoptr i64 %v4998 to ptr
  store i32 0, ptr %p4999, align 4, !alias.scope !3, !noalias !4
  %v5000 = load i64, ptr %slot42, align 8
  store i64 %v5000, ptr %slot790, align 8
  %v5001 = load i64, ptr %slot553, align 8
  %p5003 = inttoptr i64 %v5001 to ptr
  %gep5004 = getelementptr i8, ptr %p5003, i64 24
  %op5002 = ptrtoint ptr %gep5004 to i64
  store i64 %op5002, ptr %slot791, align 8
  %v5005 = load i64, ptr %slot790, align 8
  %p5006 = inttoptr i64 %v5005 to ptr
  %ld5007 = load i64, ptr %p5006, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5007, ptr %slot792, align 8
  %v5008 = load i64, ptr %slot792, align 8
  %v5009 = load i64, ptr %slot791, align 8
  %p5010 = inttoptr i64 %v5009 to ptr
  store i64 %v5008, ptr %p5010, align 8, !alias.scope !3, !noalias !4
  %v5011 = load i64, ptr %slot43, align 8
  store i64 %v5011, ptr %slot793, align 8
  %v5012 = load i64, ptr %slot553, align 8
  %p5014 = inttoptr i64 %v5012 to ptr
  %gep5015 = getelementptr i8, ptr %p5014, i64 32
  %op5013 = ptrtoint ptr %gep5015 to i64
  store i64 %op5013, ptr %slot794, align 8
  %v5016 = load i64, ptr %slot793, align 8
  %p5017 = inttoptr i64 %v5016 to ptr
  %ld5018 = load i64, ptr %p5017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5018, ptr %slot795, align 8
  %v5019 = load i64, ptr %slot795, align 8
  %v5020 = load i64, ptr %slot794, align 8
  %p5021 = inttoptr i64 %v5020 to ptr
  store i64 %v5019, ptr %p5021, align 8, !alias.scope !3, !noalias !4
  %v5022 = load i64, ptr %slot553, align 8
  %v5023 = load i64, ptr %slot39, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  store i64 %v5022, ptr %p5024, align 8, !alias.scope !3, !noalias !4
  %v5025 = load i64, ptr %slot39, align 8
  %p5026 = inttoptr i64 %v5025 to ptr
  %ld5027 = load i64, ptr %p5026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5027, ptr %slot796, align 8
  %v5028 = load i64, ptr %slot21, align 8
  store i64 %v5028, ptr %slot797, align 8
  %v5029 = load i64, ptr %slot796, align 8
  %v5030 = load i64, ptr %slot797, align 8
  %p5031 = inttoptr i64 %v5029 to ptr
  %p5032 = inttoptr i64 %v5030 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5032, ptr %p5031, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5033 = load i64, ptr %slot13, align 8
  %p5034 = inttoptr i64 %v5033 to ptr
  store i32 2, ptr %p5034, align 4, !alias.scope !3, !noalias !4
  %v5035 = load i64, ptr %slot12, align 8
  %p5036 = inttoptr i64 %v5035 to ptr
  store i32 1, ptr %p5036, align 4, !alias.scope !3, !noalias !4
  %v5037 = load i64, ptr %slot797, align 8
  %v5038 = load i64, ptr %slot39, align 8
  %p5039 = inttoptr i64 %v5038 to ptr
  store i64 %v5037, ptr %p5039, align 8, !alias.scope !3, !noalias !4
  %v5040 = load i64, ptr %slot39, align 8
  %p5041 = inttoptr i64 %v5040 to ptr
  %ld5042 = load i64, ptr %p5041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5042, ptr %slot798, align 8
  %v5043 = load i64, ptr %slot39, align 8
  %p5044 = inttoptr i64 %v5043 to ptr
  %ld5045 = load i64, ptr %p5044, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5045, ptr %slot799, align 8
  %v5046 = load i64, ptr %slot27, align 8
  store i64 %v5046, ptr %slot800, align 8
  %v5047 = load i64, ptr %slot47, align 8
  store i64 %v5047, ptr %slot801, align 8
  %v5048 = load i64, ptr %slot799, align 8
  %op5049 = add i64 %v5048, 0
  store i64 %op5049, ptr %slot802, align 8
  %v5050 = load i64, ptr %slot802, align 8
  %p5051 = inttoptr i64 %v5050 to ptr
  %ld5052 = load i64, ptr %p5051, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5052, ptr %slot803, align 8
  %v5053 = load i64, ptr %slot803, align 8
  %cmp5054 = icmp ne i64 %v5053, 0
  %cv5055 = zext i1 %cmp5054 to i32
  store i32 %cv5055, ptr %slot804, align 8
  %v5056 = load i32, ptr %slot804, align 8
  %cv5057 = zext i32 %v5056 to i64
  %cond5058 = icmp ne i64 %cv5057, 0
  br i1 %cond5058, label %bb_rcmoveheader999, label %bb_rcmovenext999
bb_rcmoveheader999:
  %v5059 = load i64, ptr %slot803, align 8
  %op5060 = sub i64 %v5059, 16
  store i64 %op5060, ptr %slot805, align 8
  %v5061 = load i64, ptr %slot803, align 8
  %p5062 = inttoptr i64 %v5061 to ptr
  %rgep5063 = getelementptr i8, ptr %p5062, i64 -16
  %ld5064 = load i64, ptr %rgep5063, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5064, ptr %slot806, align 8
  %v5065 = load i64, ptr %slot806, align 8
  %op5066 = and i64 %v5065, 5764607523034234881
  store i64 %op5066, ptr %slot807, align 8
  %v5067 = load i64, ptr %slot807, align 8
  %cmp5068 = icmp ne i64 %v5067, 0
  %cv5069 = zext i1 %cmp5068 to i32
  store i32 %cv5069, ptr %slot808, align 8
  %v5070 = load i32, ptr %slot808, align 8
  %cv5071 = zext i32 %v5070 to i64
  %cond5072 = icmp ne i64 %cv5071, 0
  br i1 %cond5072, label %bb_rcmoveslow996, label %bb_rcmovenext999
bb_rcmovenext999:
  %v5073 = load i64, ptr %slot799, align 8
  %op5074 = add i64 %v5073, 8
  store i64 %op5074, ptr %slot809, align 8
  %v5075 = load i64, ptr %slot809, align 8
  %p5076 = inttoptr i64 %v5075 to ptr
  %ld5077 = load i64, ptr %p5076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5077, ptr %slot810, align 8
  %v5078 = load i64, ptr %slot810, align 8
  %cmp5079 = icmp ne i64 %v5078, 0
  %cv5080 = zext i1 %cmp5079 to i32
  store i32 %cv5080, ptr %slot811, align 8
  %v5081 = load i32, ptr %slot811, align 8
  %cv5082 = zext i32 %v5081 to i64
  %cond5083 = icmp ne i64 %cv5082, 0
  br i1 %cond5083, label %bb_rcmoveheader1007, label %bb_rcmovenext1007
bb_rcmoveheader1007:
  %v5084 = load i64, ptr %slot810, align 8
  %op5085 = sub i64 %v5084, 16
  store i64 %op5085, ptr %slot812, align 8
  %v5086 = load i64, ptr %slot810, align 8
  %p5087 = inttoptr i64 %v5086 to ptr
  %rgep5088 = getelementptr i8, ptr %p5087, i64 -16
  %ld5089 = load i64, ptr %rgep5088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5089, ptr %slot813, align 8
  %v5090 = load i64, ptr %slot813, align 8
  %op5091 = and i64 %v5090, 5764607523034234881
  store i64 %op5091, ptr %slot814, align 8
  %v5092 = load i64, ptr %slot814, align 8
  %cmp5093 = icmp ne i64 %v5092, 0
  %cv5094 = zext i1 %cmp5093 to i32
  store i32 %cv5094, ptr %slot815, align 8
  %v5095 = load i32, ptr %slot815, align 8
  %cv5096 = zext i32 %v5095 to i64
  %cond5097 = icmp ne i64 %cv5096, 0
  br i1 %cond5097, label %bb_rcmoveslow996, label %bb_rcmovenext1007
bb_rcmovenext1007:
  %v5098 = load i64, ptr %slot799, align 8
  %op5099 = add i64 %v5098, 16
  store i64 %op5099, ptr %slot816, align 8
  %v5100 = load i64, ptr %slot816, align 8
  %p5101 = inttoptr i64 %v5100 to ptr
  %ld5102 = load i64, ptr %p5101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5102, ptr %slot817, align 8
  %v5103 = load i64, ptr %slot817, align 8
  %cmp5104 = icmp ne i64 %v5103, 0
  %cv5105 = zext i1 %cmp5104 to i32
  store i32 %cv5105, ptr %slot818, align 8
  %v5106 = load i32, ptr %slot818, align 8
  %cv5107 = zext i32 %v5106 to i64
  %cond5108 = icmp ne i64 %cv5107, 0
  br i1 %cond5108, label %bb_rcmoveheader1015, label %bb_rcmovenext1015
bb_rcmoveheader1015:
  %v5109 = load i64, ptr %slot817, align 8
  %op5110 = sub i64 %v5109, 16
  store i64 %op5110, ptr %slot819, align 8
  %v5111 = load i64, ptr %slot817, align 8
  %p5112 = inttoptr i64 %v5111 to ptr
  %rgep5113 = getelementptr i8, ptr %p5112, i64 -16
  %ld5114 = load i64, ptr %rgep5113, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5114, ptr %slot820, align 8
  %v5115 = load i64, ptr %slot820, align 8
  %op5116 = and i64 %v5115, 5764607523034234881
  store i64 %op5116, ptr %slot821, align 8
  %v5117 = load i64, ptr %slot821, align 8
  %cmp5118 = icmp ne i64 %v5117, 0
  %cv5119 = zext i1 %cmp5118 to i32
  store i32 %cv5119, ptr %slot822, align 8
  %v5120 = load i32, ptr %slot822, align 8
  %cv5121 = zext i32 %v5120 to i64
  %cond5122 = icmp ne i64 %cv5121, 0
  br i1 %cond5122, label %bb_rcmoveslow996, label %bb_rcmovenext1015
bb_rcmovenext1015:
  %v5123 = load i64, ptr %slot799, align 8
  %v5124 = load i64, ptr %slot800, align 8
  %p5125 = inttoptr i64 %v5123 to ptr
  %p5126 = inttoptr i64 %v5124 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5126, ptr %p5125, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5127 = load i64, ptr %slot799, align 8
  %p5128 = inttoptr i64 %v5127 to ptr
  store i64 0, ptr %p5128, align 8, !alias.scope !3, !noalias !4
  %v5129 = load i64, ptr %slot799, align 8
  %op5130 = add i64 %v5129, 8
  store i64 %op5130, ptr %slot823, align 8
  %v5131 = load i64, ptr %slot823, align 8
  %p5132 = inttoptr i64 %v5131 to ptr
  store i64 0, ptr %p5132, align 8, !alias.scope !3, !noalias !4
  %v5133 = load i64, ptr %slot799, align 8
  %op5134 = add i64 %v5133, 16
  store i64 %op5134, ptr %slot824, align 8
  %v5135 = load i64, ptr %slot824, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  store i64 0, ptr %p5136, align 8, !alias.scope !3, !noalias !4
  %v5137 = load i64, ptr %slot799, align 8
  %op5138 = add i64 %v5137, 24
  store i64 %op5138, ptr %slot825, align 8
  %v5139 = load i64, ptr %slot825, align 8
  %p5140 = inttoptr i64 %v5139 to ptr
  store i64 0, ptr %p5140, align 8, !alias.scope !3, !noalias !4
  %v5141 = load i64, ptr %slot799, align 8
  %op5142 = add i64 %v5141, 32
  store i64 %op5142, ptr %slot826, align 8
  %v5143 = load i64, ptr %slot826, align 8
  %p5144 = inttoptr i64 %v5143 to ptr
  store i64 0, ptr %p5144, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved996
bb_rcmoveslow996:
  %v5145 = load i64, ptr %slot46, align 8
  %v5146 = load i64, ptr %slot800, align 8
  %v5147 = load i64, ptr %slot799, align 8
  %v5148 = load i64, ptr %slot801, align 8
  %cv5149 = trunc i64 %v5148 to i32
  %call5150 = call i32 @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_take(i64 %v5145, i64 %v5146, i64 %v5147, i32 %cv5149) nomerge, !dbg !152
  store i32 %call5150, ptr %slot827, align 8
  %v5151 = load i32, ptr %slot827, align 8
  %cv5152 = zext i32 %v5151 to i64
  %cond5153 = icmp ne i64 %cv5152, 0
  br i1 %cond5153, label %bb_rcsuccess1026, label %bb_rcfailure1026
bb_rcfailure1026:
  %v5154 = load i64, ptr %slot46, align 8
  %p5155 = inttoptr i64 %v5154 to ptr
  %call5156 = call i32 @myl_rc_take_failure(ptr %p5155) nomerge, !dbg !152
  store i32 %call5156, ptr %slot828, align 8
  %v5157 = load i64, ptr %slot1, align 8
  %p5158 = inttoptr i64 %v5157 to ptr
  %v5159 = load i32, ptr %slot828, align 8
  %call5160 = call i32 @myl_qbe_rc_status(ptr %p5158, i32 %v5159) nomerge, !dbg !152
  store i32 %call5160, ptr %slot829, align 8
  br label %bb_failure
bb_rcsuccess1026:
  br label %bb_rcmoved996
bb_rcmoved996:
  %v5161 = load i64, ptr %slot12, align 8
  %p5162 = inttoptr i64 %v5161 to ptr
  store i32 0, ptr %p5162, align 4, !alias.scope !3, !noalias !4
  %v5163 = load i64, ptr %slot19, align 8
  %p5164 = inttoptr i64 %v5163 to ptr
  store i32 2, ptr %p5164, align 4, !alias.scope !3, !noalias !4
  %v5165 = load i64, ptr %slot18, align 8
  %p5166 = inttoptr i64 %v5165 to ptr
  store i32 1, ptr %p5166, align 4, !alias.scope !3, !noalias !4
  %v5167 = load i64, ptr %slot27, align 8
  store i64 %v5167, ptr %slot830, align 8
  %v5168 = load i64, ptr %slot18, align 8
  %p5169 = inttoptr i64 %v5168 to ptr
  store i32 0, ptr %p5169, align 4, !alias.scope !3, !noalias !4
  %v5170 = load i64, ptr %slot12, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  %ld5172 = load i32, ptr %p5171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5172, ptr %slot831, align 8
  %v5173 = load i32, ptr %slot831, align 8
  %cv5174 = zext i32 %v5173 to i64
  %cond5175 = icmp ne i64 %cv5174, 0
  br i1 %cond5175, label %bb_rcslotdrop1036, label %bb_rcslotdone1036
bb_rcslotdrop1036:
  %v5176 = load i64, ptr %slot12, align 8
  %p5177 = inttoptr i64 %v5176 to ptr
  store i32 0, ptr %p5177, align 4, !alias.scope !3, !noalias !4
  %v5178 = load i64, ptr %slot21, align 8
  store i64 %v5178, ptr %slot832, align 8
  %v5179 = load i64, ptr %slot13, align 8
  %p5180 = inttoptr i64 %v5179 to ptr
  %ld5181 = load i32, ptr %p5180, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5181, ptr %slot833, align 8
  %v5182 = load i32, ptr %slot833, align 8
  %op5183 = and i32 %v5182, 28
  store i32 %op5183, ptr %slot834, align 8
  %v5184 = load i32, ptr %slot834, align 8
  %cv5185 = zext i32 %v5184 to i64
  %cond5186 = icmp ne i64 %cv5185, 0
  br i1 %cond5186, label %bb_rcslotrole1036, label %bb_rcslotowner1036
bb_rcslotrole1036:
  %v5187 = load i64, ptr %slot46, align 8
  store i64 %v5187, ptr %slot835, align 8
  %v5188 = load i64, ptr %slot835, align 8
  %v5189 = load i64, ptr %slot832, align 8
  call void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_unloan(i64 %v5188, i64 %v5189) nomerge, !dbg !152
  br label %bb_rcslotdone1036
bb_rcslotowner1036:
  %v5190 = load i64, ptr %slot46, align 8
  store i64 %v5190, ptr %slot836, align 8
  %v5191 = load i64, ptr %slot836, align 8
  %v5192 = load i64, ptr %slot832, align 8
  call void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_drop(i64 %v5191, i64 %v5192) nomerge, !dbg !152
  br label %bb_rcslotdone1036
bb_rcslotdone1036:
  %v5193 = load i64, ptr %slot10, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  %ld5195 = load i32, ptr %p5194, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5195, ptr %slot837, align 8
  %v5196 = load i32, ptr %slot837, align 8
  %cv5197 = zext i32 %v5196 to i64
  %cond5198 = icmp ne i64 %cv5197, 0
  br i1 %cond5198, label %bb_rcslotdrop1045, label %bb_rcslotdone1045
bb_rcslotdrop1045:
  %v5199 = load i64, ptr %slot10, align 8
  %p5200 = inttoptr i64 %v5199 to ptr
  store i32 0, ptr %p5200, align 4, !alias.scope !3, !noalias !4
  %v5201 = load i64, ptr %slot38, align 8
  store i64 %v5201, ptr %slot838, align 8
  %v5202 = load i64, ptr %slot11, align 8
  %p5203 = inttoptr i64 %v5202 to ptr
  %ld5204 = load i32, ptr %p5203, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5204, ptr %slot839, align 8
  %v5205 = load i32, ptr %slot839, align 8
  %op5206 = and i32 %v5205, 28
  store i32 %op5206, ptr %slot840, align 8
  %v5207 = load i32, ptr %slot840, align 8
  %cv5208 = zext i32 %v5207 to i64
  %cond5209 = icmp ne i64 %cv5208, 0
  br i1 %cond5209, label %bb_rcslotrole1045, label %bb_rcslotowner1045
bb_rcslotrole1045:
  %v5210 = load i64, ptr %slot46, align 8
  store i64 %v5210, ptr %slot841, align 8
  %v5211 = load i64, ptr %slot838, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  %ld5213 = load i64, ptr %p5212, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5213, ptr %slot842, align 8
  %v5214 = load i64, ptr %slot842, align 8
  %cmp5215 = icmp ne i64 %v5214, 0
  %cv5216 = zext i1 %cmp5215 to i32
  store i32 %cv5216, ptr %slot843, align 8
  %v5217 = load i32, ptr %slot843, align 8
  %cv5218 = zext i32 %v5217 to i64
  %cond5219 = icmp ne i64 %cv5218, 0
  br i1 %cond5219, label %bb_rcgnn1061, label %bb_rcgdone1061
bb_rcgnn1061:
  %v5220 = load i64, ptr %slot842, align 8
  %op5221 = sub i64 %v5220, 16
  store i64 %op5221, ptr %slot844, align 8
  %v5222 = load i64, ptr %slot842, align 8
  %p5223 = inttoptr i64 %v5222 to ptr
  %rgep5224 = getelementptr i8, ptr %p5223, i64 -16
  %ld5225 = load i64, ptr %rgep5224, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5225, ptr %slot845, align 8
  %v5226 = load i64, ptr %slot845, align 8
  %op5227 = and i64 %v5226, 4611686018427387906
  store i64 %op5227, ptr %slot846, align 8
  %v5228 = load i64, ptr %slot846, align 8
  %cmp5229 = icmp ne i64 %v5228, 0
  %cv5230 = zext i1 %cmp5229 to i32
  store i32 %cv5230, ptr %slot847, align 8
  %v5231 = load i32, ptr %slot847, align 8
  %cv5232 = zext i32 %v5231 to i64
  %cond5233 = icmp ne i64 %cv5232, 0
  br i1 %cond5233, label %bb_rcgclear1061, label %bb_rcgcounted1061
bb_rcgcounted1061:
  %v5234 = load i64, ptr %slot842, align 8
  %op5235 = sub i64 %v5234, 24
  store i64 %op5235, ptr %slot848, align 8
  %v5236 = load i64, ptr %slot842, align 8
  %p5237 = inttoptr i64 %v5236 to ptr
  %rgep5238 = getelementptr i8, ptr %p5237, i64 -24
  %ld5239 = load i64, ptr %rgep5238, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5239, ptr %slot849, align 8
  %v5240 = load i64, ptr %slot849, align 8
  %op5241 = sub i64 %v5240, 1
  store i64 %op5241, ptr %slot850, align 8
  %v5242 = load i64, ptr %slot850, align 8
  %cmp5243 = icmp eq i64 %v5242, 0
  %cv5244 = zext i1 %cmp5243 to i32
  store i32 %cv5244, ptr %slot851, align 8
  %v5245 = load i32, ptr %slot851, align 8
  %cv5246 = zext i32 %v5245 to i64
  %cond5247 = icmp ne i64 %cv5246, 0
  br i1 %cond5247, label %bb_rcglast1061, label %bb_rcgdec1061
bb_rcglast1061:
  %v5248 = load i64, ptr %slot842, align 8
  %op5249 = sub i64 %v5248, 32
  store i64 %op5249, ptr %slot852, align 8
  %v5250 = load i64, ptr %slot842, align 8
  %p5251 = inttoptr i64 %v5250 to ptr
  %rgep5252 = getelementptr i8, ptr %p5251, i64 -32
  %ld5253 = load i64, ptr %rgep5252, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5253, ptr %slot853, align 8
  %v5254 = load i64, ptr %slot853, align 8
  %cmp5255 = icmp ne i64 %v5254, 0
  %cv5256 = zext i1 %cmp5255 to i32
  store i32 %cv5256, ptr %slot854, align 8
  %v5257 = load i32, ptr %slot854, align 8
  %cv5258 = zext i32 %v5257 to i64
  %cond5259 = icmp ne i64 %cv5258, 0
  br i1 %cond5259, label %bb_rcgdec1061, label %bb_rcgslow1061
bb_rcgslow1061:
  %v5260 = load i64, ptr %slot841, align 8
  %v5261 = load i64, ptr %slot838, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5260, i64 %v5261) nomerge, !dbg !152
  br label %bb_rcgdone1061
bb_rcgdec1061:
  %v5262 = load i64, ptr %slot850, align 8
  %v5263 = load i64, ptr %slot842, align 8
  %p5264 = inttoptr i64 %v5263 to ptr
  %rgep5265 = getelementptr i8, ptr %p5264, i64 -24
  store i64 %v5262, ptr %rgep5265, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1061
bb_rcgclear1061:
  %v5266 = load i64, ptr %slot838, align 8
  %p5267 = inttoptr i64 %v5266 to ptr
  store i64 0, ptr %p5267, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1061
bb_rcgdone1061:
  br label %bb_rcslotdone1045
bb_rcslotowner1045:
  %v5268 = load i64, ptr %slot46, align 8
  store i64 %v5268, ptr %slot855, align 8
  %v5269 = load i64, ptr %slot838, align 8
  %p5270 = inttoptr i64 %v5269 to ptr
  %ld5271 = load i64, ptr %p5270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5271, ptr %slot856, align 8
  %v5272 = load i64, ptr %slot856, align 8
  %cmp5273 = icmp ne i64 %v5272, 0
  %cv5274 = zext i1 %cmp5273 to i32
  store i32 %cv5274, ptr %slot857, align 8
  %v5275 = load i32, ptr %slot857, align 8
  %cv5276 = zext i32 %v5275 to i64
  %cond5277 = icmp ne i64 %cv5276, 0
  br i1 %cond5277, label %bb_rcgnn1076, label %bb_rcgdone1076
bb_rcgnn1076:
  %v5278 = load i64, ptr %slot856, align 8
  %op5279 = sub i64 %v5278, 16
  store i64 %op5279, ptr %slot858, align 8
  %v5280 = load i64, ptr %slot856, align 8
  %p5281 = inttoptr i64 %v5280 to ptr
  %rgep5282 = getelementptr i8, ptr %p5281, i64 -16
  %ld5283 = load i64, ptr %rgep5282, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5283, ptr %slot859, align 8
  %v5284 = load i64, ptr %slot859, align 8
  %op5285 = and i64 %v5284, 4611686018427387906
  store i64 %op5285, ptr %slot860, align 8
  %v5286 = load i64, ptr %slot860, align 8
  %cmp5287 = icmp ne i64 %v5286, 0
  %cv5288 = zext i1 %cmp5287 to i32
  store i32 %cv5288, ptr %slot861, align 8
  %v5289 = load i32, ptr %slot861, align 8
  %cv5290 = zext i32 %v5289 to i64
  %cond5291 = icmp ne i64 %cv5290, 0
  br i1 %cond5291, label %bb_rcgclear1076, label %bb_rcgcounted1076
bb_rcgcounted1076:
  %v5292 = load i64, ptr %slot856, align 8
  %op5293 = sub i64 %v5292, 32
  store i64 %op5293, ptr %slot862, align 8
  %v5294 = load i64, ptr %slot856, align 8
  %p5295 = inttoptr i64 %v5294 to ptr
  %rgep5296 = getelementptr i8, ptr %p5295, i64 -32
  %ld5297 = load i64, ptr %rgep5296, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5297, ptr %slot863, align 8
  %v5298 = load i64, ptr %slot863, align 8
  %op5299 = sub i64 %v5298, 1
  store i64 %op5299, ptr %slot864, align 8
  %v5300 = load i64, ptr %slot864, align 8
  %cmp5301 = icmp eq i64 %v5300, 0
  %cv5302 = zext i1 %cmp5301 to i32
  store i32 %cv5302, ptr %slot865, align 8
  %v5303 = load i32, ptr %slot865, align 8
  %cv5304 = zext i32 %v5303 to i64
  %cond5305 = icmp ne i64 %cv5304, 0
  br i1 %cond5305, label %bb_rcglast1076, label %bb_rcgdec1076
bb_rcglast1076:
  %v5306 = load i64, ptr %slot856, align 8
  %op5307 = sub i64 %v5306, 24
  store i64 %op5307, ptr %slot866, align 8
  %v5308 = load i64, ptr %slot856, align 8
  %p5309 = inttoptr i64 %v5308 to ptr
  %rgep5310 = getelementptr i8, ptr %p5309, i64 -24
  %ld5311 = load i64, ptr %rgep5310, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5311, ptr %slot867, align 8
  %v5312 = load i64, ptr %slot867, align 8
  %cmp5313 = icmp ne i64 %v5312, 0
  %cv5314 = zext i1 %cmp5313 to i32
  store i32 %cv5314, ptr %slot868, align 8
  %v5315 = load i32, ptr %slot868, align 8
  %cv5316 = zext i32 %v5315 to i64
  %cond5317 = icmp ne i64 %cv5316, 0
  br i1 %cond5317, label %bb_rcgdec1076, label %bb_rcgslow1076
bb_rcgslow1076:
  %v5318 = load i64, ptr %slot855, align 8
  %v5319 = load i64, ptr %slot838, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5318, i64 %v5319) nomerge, !dbg !152
  br label %bb_rcgdone1076
bb_rcgdec1076:
  %v5320 = load i64, ptr %slot864, align 8
  %v5321 = load i64, ptr %slot856, align 8
  %p5322 = inttoptr i64 %v5321 to ptr
  %rgep5323 = getelementptr i8, ptr %p5322, i64 -32
  store i64 %v5320, ptr %rgep5323, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1076
bb_rcgclear1076:
  %v5324 = load i64, ptr %slot838, align 8
  %p5325 = inttoptr i64 %v5324 to ptr
  store i64 0, ptr %p5325, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1076
bb_rcgdone1076:
  br label %bb_rcslotdone1045
bb_rcslotdone1045:
  %v5326 = load i64, ptr %slot8, align 8
  %p5327 = inttoptr i64 %v5326 to ptr
  %ld5328 = load i32, ptr %p5327, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5328, ptr %slot869, align 8
  %v5329 = load i32, ptr %slot869, align 8
  %cv5330 = zext i32 %v5329 to i64
  %cond5331 = icmp ne i64 %cv5330, 0
  br i1 %cond5331, label %bb_rcslotdrop1082, label %bb_rcslotdone1082
bb_rcslotdrop1082:
  %v5332 = load i64, ptr %slot8, align 8
  %p5333 = inttoptr i64 %v5332 to ptr
  store i32 0, ptr %p5333, align 4, !alias.scope !3, !noalias !4
  %v5334 = load i64, ptr %slot37, align 8
  store i64 %v5334, ptr %slot870, align 8
  %v5335 = load i64, ptr %slot9, align 8
  %p5336 = inttoptr i64 %v5335 to ptr
  %ld5337 = load i32, ptr %p5336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5337, ptr %slot871, align 8
  %v5338 = load i32, ptr %slot871, align 8
  %op5339 = and i32 %v5338, 28
  store i32 %op5339, ptr %slot872, align 8
  %v5340 = load i32, ptr %slot872, align 8
  %cv5341 = zext i32 %v5340 to i64
  %cond5342 = icmp ne i64 %cv5341, 0
  br i1 %cond5342, label %bb_rcslotrole1082, label %bb_rcslotowner1082
bb_rcslotrole1082:
  %v5343 = load i64, ptr %slot46, align 8
  store i64 %v5343, ptr %slot873, align 8
  %v5344 = load i64, ptr %slot870, align 8
  %p5345 = inttoptr i64 %v5344 to ptr
  %ld5346 = load i64, ptr %p5345, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5346, ptr %slot874, align 8
  %v5347 = load i64, ptr %slot874, align 8
  %cmp5348 = icmp ne i64 %v5347, 0
  %cv5349 = zext i1 %cmp5348 to i32
  store i32 %cv5349, ptr %slot875, align 8
  %v5350 = load i32, ptr %slot875, align 8
  %cv5351 = zext i32 %v5350 to i64
  %cond5352 = icmp ne i64 %cv5351, 0
  br i1 %cond5352, label %bb_rcgnn1098, label %bb_rcgdone1098
bb_rcgnn1098:
  %v5353 = load i64, ptr %slot874, align 8
  %op5354 = sub i64 %v5353, 16
  store i64 %op5354, ptr %slot876, align 8
  %v5355 = load i64, ptr %slot874, align 8
  %p5356 = inttoptr i64 %v5355 to ptr
  %rgep5357 = getelementptr i8, ptr %p5356, i64 -16
  %ld5358 = load i64, ptr %rgep5357, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5358, ptr %slot877, align 8
  %v5359 = load i64, ptr %slot877, align 8
  %op5360 = and i64 %v5359, 4611686018427387906
  store i64 %op5360, ptr %slot878, align 8
  %v5361 = load i64, ptr %slot878, align 8
  %cmp5362 = icmp ne i64 %v5361, 0
  %cv5363 = zext i1 %cmp5362 to i32
  store i32 %cv5363, ptr %slot879, align 8
  %v5364 = load i32, ptr %slot879, align 8
  %cv5365 = zext i32 %v5364 to i64
  %cond5366 = icmp ne i64 %cv5365, 0
  br i1 %cond5366, label %bb_rcgclear1098, label %bb_rcgcounted1098
bb_rcgcounted1098:
  %v5367 = load i64, ptr %slot874, align 8
  %op5368 = sub i64 %v5367, 24
  store i64 %op5368, ptr %slot880, align 8
  %v5369 = load i64, ptr %slot874, align 8
  %p5370 = inttoptr i64 %v5369 to ptr
  %rgep5371 = getelementptr i8, ptr %p5370, i64 -24
  %ld5372 = load i64, ptr %rgep5371, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5372, ptr %slot881, align 8
  %v5373 = load i64, ptr %slot881, align 8
  %op5374 = sub i64 %v5373, 1
  store i64 %op5374, ptr %slot882, align 8
  %v5375 = load i64, ptr %slot882, align 8
  %cmp5376 = icmp eq i64 %v5375, 0
  %cv5377 = zext i1 %cmp5376 to i32
  store i32 %cv5377, ptr %slot883, align 8
  %v5378 = load i32, ptr %slot883, align 8
  %cv5379 = zext i32 %v5378 to i64
  %cond5380 = icmp ne i64 %cv5379, 0
  br i1 %cond5380, label %bb_rcglast1098, label %bb_rcgdec1098
bb_rcglast1098:
  %v5381 = load i64, ptr %slot874, align 8
  %op5382 = sub i64 %v5381, 32
  store i64 %op5382, ptr %slot884, align 8
  %v5383 = load i64, ptr %slot874, align 8
  %p5384 = inttoptr i64 %v5383 to ptr
  %rgep5385 = getelementptr i8, ptr %p5384, i64 -32
  %ld5386 = load i64, ptr %rgep5385, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5386, ptr %slot885, align 8
  %v5387 = load i64, ptr %slot885, align 8
  %cmp5388 = icmp ne i64 %v5387, 0
  %cv5389 = zext i1 %cmp5388 to i32
  store i32 %cv5389, ptr %slot886, align 8
  %v5390 = load i32, ptr %slot886, align 8
  %cv5391 = zext i32 %v5390 to i64
  %cond5392 = icmp ne i64 %cv5391, 0
  br i1 %cond5392, label %bb_rcgdec1098, label %bb_rcgslow1098
bb_rcgslow1098:
  %v5393 = load i64, ptr %slot873, align 8
  %v5394 = load i64, ptr %slot870, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5393, i64 %v5394) nomerge, !dbg !152
  br label %bb_rcgdone1098
bb_rcgdec1098:
  %v5395 = load i64, ptr %slot882, align 8
  %v5396 = load i64, ptr %slot874, align 8
  %p5397 = inttoptr i64 %v5396 to ptr
  %rgep5398 = getelementptr i8, ptr %p5397, i64 -24
  store i64 %v5395, ptr %rgep5398, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1098
bb_rcgclear1098:
  %v5399 = load i64, ptr %slot870, align 8
  %p5400 = inttoptr i64 %v5399 to ptr
  store i64 0, ptr %p5400, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1098
bb_rcgdone1098:
  br label %bb_rcslotdone1082
bb_rcslotowner1082:
  %v5401 = load i64, ptr %slot46, align 8
  store i64 %v5401, ptr %slot887, align 8
  %v5402 = load i64, ptr %slot870, align 8
  %p5403 = inttoptr i64 %v5402 to ptr
  %ld5404 = load i64, ptr %p5403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5404, ptr %slot888, align 8
  %v5405 = load i64, ptr %slot888, align 8
  %cmp5406 = icmp ne i64 %v5405, 0
  %cv5407 = zext i1 %cmp5406 to i32
  store i32 %cv5407, ptr %slot889, align 8
  %v5408 = load i32, ptr %slot889, align 8
  %cv5409 = zext i32 %v5408 to i64
  %cond5410 = icmp ne i64 %cv5409, 0
  br i1 %cond5410, label %bb_rcgnn1113, label %bb_rcgdone1113
bb_rcgnn1113:
  %v5411 = load i64, ptr %slot888, align 8
  %op5412 = sub i64 %v5411, 16
  store i64 %op5412, ptr %slot890, align 8
  %v5413 = load i64, ptr %slot888, align 8
  %p5414 = inttoptr i64 %v5413 to ptr
  %rgep5415 = getelementptr i8, ptr %p5414, i64 -16
  %ld5416 = load i64, ptr %rgep5415, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5416, ptr %slot891, align 8
  %v5417 = load i64, ptr %slot891, align 8
  %op5418 = and i64 %v5417, 4611686018427387906
  store i64 %op5418, ptr %slot892, align 8
  %v5419 = load i64, ptr %slot892, align 8
  %cmp5420 = icmp ne i64 %v5419, 0
  %cv5421 = zext i1 %cmp5420 to i32
  store i32 %cv5421, ptr %slot893, align 8
  %v5422 = load i32, ptr %slot893, align 8
  %cv5423 = zext i32 %v5422 to i64
  %cond5424 = icmp ne i64 %cv5423, 0
  br i1 %cond5424, label %bb_rcgclear1113, label %bb_rcgcounted1113
bb_rcgcounted1113:
  %v5425 = load i64, ptr %slot888, align 8
  %op5426 = sub i64 %v5425, 32
  store i64 %op5426, ptr %slot894, align 8
  %v5427 = load i64, ptr %slot888, align 8
  %p5428 = inttoptr i64 %v5427 to ptr
  %rgep5429 = getelementptr i8, ptr %p5428, i64 -32
  %ld5430 = load i64, ptr %rgep5429, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5430, ptr %slot895, align 8
  %v5431 = load i64, ptr %slot895, align 8
  %op5432 = sub i64 %v5431, 1
  store i64 %op5432, ptr %slot896, align 8
  %v5433 = load i64, ptr %slot896, align 8
  %cmp5434 = icmp eq i64 %v5433, 0
  %cv5435 = zext i1 %cmp5434 to i32
  store i32 %cv5435, ptr %slot897, align 8
  %v5436 = load i32, ptr %slot897, align 8
  %cv5437 = zext i32 %v5436 to i64
  %cond5438 = icmp ne i64 %cv5437, 0
  br i1 %cond5438, label %bb_rcglast1113, label %bb_rcgdec1113
bb_rcglast1113:
  %v5439 = load i64, ptr %slot888, align 8
  %op5440 = sub i64 %v5439, 24
  store i64 %op5440, ptr %slot898, align 8
  %v5441 = load i64, ptr %slot888, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  %rgep5443 = getelementptr i8, ptr %p5442, i64 -24
  %ld5444 = load i64, ptr %rgep5443, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5444, ptr %slot899, align 8
  %v5445 = load i64, ptr %slot899, align 8
  %cmp5446 = icmp ne i64 %v5445, 0
  %cv5447 = zext i1 %cmp5446 to i32
  store i32 %cv5447, ptr %slot900, align 8
  %v5448 = load i32, ptr %slot900, align 8
  %cv5449 = zext i32 %v5448 to i64
  %cond5450 = icmp ne i64 %cv5449, 0
  br i1 %cond5450, label %bb_rcgdec1113, label %bb_rcgslow1113
bb_rcgslow1113:
  %v5451 = load i64, ptr %slot887, align 8
  %v5452 = load i64, ptr %slot870, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5451, i64 %v5452) nomerge, !dbg !152
  br label %bb_rcgdone1113
bb_rcgdec1113:
  %v5453 = load i64, ptr %slot896, align 8
  %v5454 = load i64, ptr %slot888, align 8
  %p5455 = inttoptr i64 %v5454 to ptr
  %rgep5456 = getelementptr i8, ptr %p5455, i64 -32
  store i64 %v5453, ptr %rgep5456, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1113
bb_rcgclear1113:
  %v5457 = load i64, ptr %slot870, align 8
  %p5458 = inttoptr i64 %v5457 to ptr
  store i64 0, ptr %p5458, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1113
bb_rcgdone1113:
  br label %bb_rcslotdone1082
bb_rcslotdone1082:
  %v5459 = load i64, ptr %slot6, align 8
  %p5460 = inttoptr i64 %v5459 to ptr
  %ld5461 = load i32, ptr %p5460, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5461, ptr %slot901, align 8
  %v5462 = load i32, ptr %slot901, align 8
  %cv5463 = zext i32 %v5462 to i64
  %cond5464 = icmp ne i64 %cv5463, 0
  br i1 %cond5464, label %bb_rcslotdrop1119, label %bb_rcslotdone1119
bb_rcslotdrop1119:
  %v5465 = load i64, ptr %slot6, align 8
  %p5466 = inttoptr i64 %v5465 to ptr
  store i32 0, ptr %p5466, align 4, !alias.scope !3, !noalias !4
  %v5467 = load i64, ptr %slot36, align 8
  store i64 %v5467, ptr %slot902, align 8
  %v5468 = load i64, ptr %slot7, align 8
  %p5469 = inttoptr i64 %v5468 to ptr
  %ld5470 = load i32, ptr %p5469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5470, ptr %slot903, align 8
  %v5471 = load i32, ptr %slot903, align 8
  %op5472 = and i32 %v5471, 28
  store i32 %op5472, ptr %slot904, align 8
  %v5473 = load i32, ptr %slot904, align 8
  %cv5474 = zext i32 %v5473 to i64
  %cond5475 = icmp ne i64 %cv5474, 0
  br i1 %cond5475, label %bb_rcslotrole1119, label %bb_rcslotowner1119
bb_rcslotrole1119:
  %v5476 = load i64, ptr %slot46, align 8
  store i64 %v5476, ptr %slot905, align 8
  %v5477 = load i64, ptr %slot902, align 8
  %p5478 = inttoptr i64 %v5477 to ptr
  %ld5479 = load i64, ptr %p5478, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5479, ptr %slot906, align 8
  %v5480 = load i64, ptr %slot906, align 8
  %cmp5481 = icmp ne i64 %v5480, 0
  %cv5482 = zext i1 %cmp5481 to i32
  store i32 %cv5482, ptr %slot907, align 8
  %v5483 = load i32, ptr %slot907, align 8
  %cv5484 = zext i32 %v5483 to i64
  %cond5485 = icmp ne i64 %cv5484, 0
  br i1 %cond5485, label %bb_rcgnn1135, label %bb_rcgdone1135
bb_rcgnn1135:
  %v5486 = load i64, ptr %slot906, align 8
  %op5487 = sub i64 %v5486, 16
  store i64 %op5487, ptr %slot908, align 8
  %v5488 = load i64, ptr %slot906, align 8
  %p5489 = inttoptr i64 %v5488 to ptr
  %rgep5490 = getelementptr i8, ptr %p5489, i64 -16
  %ld5491 = load i64, ptr %rgep5490, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5491, ptr %slot909, align 8
  %v5492 = load i64, ptr %slot909, align 8
  %op5493 = and i64 %v5492, 4611686018427387906
  store i64 %op5493, ptr %slot910, align 8
  %v5494 = load i64, ptr %slot910, align 8
  %cmp5495 = icmp ne i64 %v5494, 0
  %cv5496 = zext i1 %cmp5495 to i32
  store i32 %cv5496, ptr %slot911, align 8
  %v5497 = load i32, ptr %slot911, align 8
  %cv5498 = zext i32 %v5497 to i64
  %cond5499 = icmp ne i64 %cv5498, 0
  br i1 %cond5499, label %bb_rcgclear1135, label %bb_rcgcounted1135
bb_rcgcounted1135:
  %v5500 = load i64, ptr %slot906, align 8
  %op5501 = sub i64 %v5500, 24
  store i64 %op5501, ptr %slot912, align 8
  %v5502 = load i64, ptr %slot906, align 8
  %p5503 = inttoptr i64 %v5502 to ptr
  %rgep5504 = getelementptr i8, ptr %p5503, i64 -24
  %ld5505 = load i64, ptr %rgep5504, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5505, ptr %slot913, align 8
  %v5506 = load i64, ptr %slot913, align 8
  %op5507 = sub i64 %v5506, 1
  store i64 %op5507, ptr %slot914, align 8
  %v5508 = load i64, ptr %slot914, align 8
  %cmp5509 = icmp eq i64 %v5508, 0
  %cv5510 = zext i1 %cmp5509 to i32
  store i32 %cv5510, ptr %slot915, align 8
  %v5511 = load i32, ptr %slot915, align 8
  %cv5512 = zext i32 %v5511 to i64
  %cond5513 = icmp ne i64 %cv5512, 0
  br i1 %cond5513, label %bb_rcglast1135, label %bb_rcgdec1135
bb_rcglast1135:
  %v5514 = load i64, ptr %slot906, align 8
  %op5515 = sub i64 %v5514, 32
  store i64 %op5515, ptr %slot916, align 8
  %v5516 = load i64, ptr %slot906, align 8
  %p5517 = inttoptr i64 %v5516 to ptr
  %rgep5518 = getelementptr i8, ptr %p5517, i64 -32
  %ld5519 = load i64, ptr %rgep5518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5519, ptr %slot917, align 8
  %v5520 = load i64, ptr %slot917, align 8
  %cmp5521 = icmp ne i64 %v5520, 0
  %cv5522 = zext i1 %cmp5521 to i32
  store i32 %cv5522, ptr %slot918, align 8
  %v5523 = load i32, ptr %slot918, align 8
  %cv5524 = zext i32 %v5523 to i64
  %cond5525 = icmp ne i64 %cv5524, 0
  br i1 %cond5525, label %bb_rcgdec1135, label %bb_rcgslow1135
bb_rcgslow1135:
  %v5526 = load i64, ptr %slot905, align 8
  %v5527 = load i64, ptr %slot902, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v5526, i64 %v5527) nomerge, !dbg !152
  br label %bb_rcgdone1135
bb_rcgdec1135:
  %v5528 = load i64, ptr %slot914, align 8
  %v5529 = load i64, ptr %slot906, align 8
  %p5530 = inttoptr i64 %v5529 to ptr
  %rgep5531 = getelementptr i8, ptr %p5530, i64 -24
  store i64 %v5528, ptr %rgep5531, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1135
bb_rcgclear1135:
  %v5532 = load i64, ptr %slot902, align 8
  %p5533 = inttoptr i64 %v5532 to ptr
  store i64 0, ptr %p5533, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1135
bb_rcgdone1135:
  br label %bb_rcslotdone1119
bb_rcslotowner1119:
  %v5534 = load i64, ptr %slot46, align 8
  store i64 %v5534, ptr %slot919, align 8
  %v5535 = load i64, ptr %slot902, align 8
  %p5536 = inttoptr i64 %v5535 to ptr
  %ld5537 = load i64, ptr %p5536, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5537, ptr %slot920, align 8
  %v5538 = load i64, ptr %slot920, align 8
  %cmp5539 = icmp ne i64 %v5538, 0
  %cv5540 = zext i1 %cmp5539 to i32
  store i32 %cv5540, ptr %slot921, align 8
  %v5541 = load i32, ptr %slot921, align 8
  %cv5542 = zext i32 %v5541 to i64
  %cond5543 = icmp ne i64 %cv5542, 0
  br i1 %cond5543, label %bb_rcgnn1150, label %bb_rcgdone1150
bb_rcgnn1150:
  %v5544 = load i64, ptr %slot920, align 8
  %op5545 = sub i64 %v5544, 16
  store i64 %op5545, ptr %slot922, align 8
  %v5546 = load i64, ptr %slot920, align 8
  %p5547 = inttoptr i64 %v5546 to ptr
  %rgep5548 = getelementptr i8, ptr %p5547, i64 -16
  %ld5549 = load i64, ptr %rgep5548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5549, ptr %slot923, align 8
  %v5550 = load i64, ptr %slot923, align 8
  %op5551 = and i64 %v5550, 4611686018427387906
  store i64 %op5551, ptr %slot924, align 8
  %v5552 = load i64, ptr %slot924, align 8
  %cmp5553 = icmp ne i64 %v5552, 0
  %cv5554 = zext i1 %cmp5553 to i32
  store i32 %cv5554, ptr %slot925, align 8
  %v5555 = load i32, ptr %slot925, align 8
  %cv5556 = zext i32 %v5555 to i64
  %cond5557 = icmp ne i64 %cv5556, 0
  br i1 %cond5557, label %bb_rcgclear1150, label %bb_rcgcounted1150
bb_rcgcounted1150:
  %v5558 = load i64, ptr %slot920, align 8
  %op5559 = sub i64 %v5558, 32
  store i64 %op5559, ptr %slot926, align 8
  %v5560 = load i64, ptr %slot920, align 8
  %p5561 = inttoptr i64 %v5560 to ptr
  %rgep5562 = getelementptr i8, ptr %p5561, i64 -32
  %ld5563 = load i64, ptr %rgep5562, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5563, ptr %slot927, align 8
  %v5564 = load i64, ptr %slot927, align 8
  %op5565 = sub i64 %v5564, 1
  store i64 %op5565, ptr %slot928, align 8
  %v5566 = load i64, ptr %slot928, align 8
  %cmp5567 = icmp eq i64 %v5566, 0
  %cv5568 = zext i1 %cmp5567 to i32
  store i32 %cv5568, ptr %slot929, align 8
  %v5569 = load i32, ptr %slot929, align 8
  %cv5570 = zext i32 %v5569 to i64
  %cond5571 = icmp ne i64 %cv5570, 0
  br i1 %cond5571, label %bb_rcglast1150, label %bb_rcgdec1150
bb_rcglast1150:
  %v5572 = load i64, ptr %slot920, align 8
  %op5573 = sub i64 %v5572, 24
  store i64 %op5573, ptr %slot930, align 8
  %v5574 = load i64, ptr %slot920, align 8
  %p5575 = inttoptr i64 %v5574 to ptr
  %rgep5576 = getelementptr i8, ptr %p5575, i64 -24
  %ld5577 = load i64, ptr %rgep5576, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5577, ptr %slot931, align 8
  %v5578 = load i64, ptr %slot931, align 8
  %cmp5579 = icmp ne i64 %v5578, 0
  %cv5580 = zext i1 %cmp5579 to i32
  store i32 %cv5580, ptr %slot932, align 8
  %v5581 = load i32, ptr %slot932, align 8
  %cv5582 = zext i32 %v5581 to i64
  %cond5583 = icmp ne i64 %cv5582, 0
  br i1 %cond5583, label %bb_rcgdec1150, label %bb_rcgslow1150
bb_rcgslow1150:
  %v5584 = load i64, ptr %slot919, align 8
  %v5585 = load i64, ptr %slot902, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v5584, i64 %v5585) nomerge, !dbg !152
  br label %bb_rcgdone1150
bb_rcgdec1150:
  %v5586 = load i64, ptr %slot928, align 8
  %v5587 = load i64, ptr %slot920, align 8
  %p5588 = inttoptr i64 %v5587 to ptr
  %rgep5589 = getelementptr i8, ptr %p5588, i64 -32
  store i64 %v5586, ptr %rgep5589, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1150
bb_rcgclear1150:
  %v5590 = load i64, ptr %slot902, align 8
  %p5591 = inttoptr i64 %v5590 to ptr
  store i64 0, ptr %p5591, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1150
bb_rcgdone1150:
  br label %bb_rcslotdone1119
bb_rcslotdone1119:
  %v5592 = load i64, ptr %slot830, align 8
  %p5593 = inttoptr i64 %v5592 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5593, i64 40, i1 false)
  ret void
bb_i59:
  %v5594 = load i64, ptr %slot39, align 8
  %p5595 = inttoptr i64 %v5594 to ptr
  store i64 0, ptr %p5595, align 8, !alias.scope !3, !noalias !4
  %v5596 = load i64, ptr %slot39, align 8
  %p5597 = inttoptr i64 %v5596 to ptr
  %ld5598 = load i64, ptr %p5597, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5598, ptr %slot933, align 8
  %v5599 = load i64, ptr %slot933, align 8
  %cond5600 = icmp ne i64 %v5599, 0
  br i1 %cond5600, label %bb_success1256, label %bb_failed1256
bb_failed1256:
  %v5601 = load i64, ptr %slot1, align 8
  %p5602 = inttoptr i64 %v5601 to ptr
  call void @myl_qbe_fail_assert(ptr %p5602) nomerge, !dbg !154
  unreachable
bb_success1256:
  br label %bb_i89
bb_i62:
  %v5603 = load i64, ptr %slot39, align 8
  %p5604 = inttoptr i64 %v5603 to ptr
  store i64 0, ptr %p5604, align 8, !alias.scope !3, !noalias !4
  %v5605 = load i64, ptr %slot39, align 8
  %p5606 = inttoptr i64 %v5605 to ptr
  %ld5607 = load i64, ptr %p5606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5607, ptr %slot934, align 8
  %v5608 = load i64, ptr %slot934, align 8
  %cond5609 = icmp ne i64 %v5608, 0
  br i1 %cond5609, label %bb_success1258, label %bb_failed1258
bb_failed1258:
  %v5610 = load i64, ptr %slot1, align 8
  %p5611 = inttoptr i64 %v5610 to ptr
  call void @myl_qbe_fail_assert(ptr %p5611) nomerge, !dbg !156
  unreachable
bb_success1258:
  br label %bb_i89
bb_i65:
  %v5612 = load i64, ptr %slot39, align 8
  %p5613 = inttoptr i64 %v5612 to ptr
  store i64 0, ptr %p5613, align 8, !alias.scope !3, !noalias !4
  %v5614 = load i64, ptr %slot39, align 8
  %p5615 = inttoptr i64 %v5614 to ptr
  %ld5616 = load i64, ptr %p5615, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5616, ptr %slot935, align 8
  %v5617 = load i64, ptr %slot935, align 8
  %cond5618 = icmp ne i64 %v5617, 0
  br i1 %cond5618, label %bb_success1260, label %bb_failed1260
bb_failed1260:
  %v5619 = load i64, ptr %slot1, align 8
  %p5620 = inttoptr i64 %v5619 to ptr
  call void @myl_qbe_fail_assert(ptr %p5620) nomerge, !dbg !158
  unreachable
bb_success1260:
  br label %bb_i89
bb_i68:
  %v5621 = load i64, ptr %slot39, align 8
  %p5622 = inttoptr i64 %v5621 to ptr
  store i64 0, ptr %p5622, align 8, !alias.scope !3, !noalias !4
  %v5623 = load i64, ptr %slot39, align 8
  %p5624 = inttoptr i64 %v5623 to ptr
  %ld5625 = load i64, ptr %p5624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5625, ptr %slot936, align 8
  %v5626 = load i64, ptr %slot936, align 8
  %cond5627 = icmp ne i64 %v5626, 0
  br i1 %cond5627, label %bb_success1262, label %bb_failed1262
bb_failed1262:
  %v5628 = load i64, ptr %slot1, align 8
  %p5629 = inttoptr i64 %v5628 to ptr
  call void @myl_qbe_fail_assert(ptr %p5629) nomerge, !dbg !160
  unreachable
bb_success1262:
  br label %bb_i89
bb_i71:
  %v5630 = load i64, ptr %slot39, align 8
  %p5631 = inttoptr i64 %v5630 to ptr
  store i64 0, ptr %p5631, align 8, !alias.scope !3, !noalias !4
  %v5632 = load i64, ptr %slot39, align 8
  %p5633 = inttoptr i64 %v5632 to ptr
  %ld5634 = load i64, ptr %p5633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5634, ptr %slot937, align 8
  %v5635 = load i64, ptr %slot937, align 8
  %cond5636 = icmp ne i64 %v5635, 0
  br i1 %cond5636, label %bb_success1264, label %bb_failed1264
bb_failed1264:
  %v5637 = load i64, ptr %slot1, align 8
  %p5638 = inttoptr i64 %v5637 to ptr
  call void @myl_qbe_fail_assert(ptr %p5638) nomerge, !dbg !162
  unreachable
bb_success1264:
  br label %bb_i89
bb_i74:
  %v5639 = load i64, ptr %slot39, align 8
  %p5640 = inttoptr i64 %v5639 to ptr
  store i64 0, ptr %p5640, align 8, !alias.scope !3, !noalias !4
  %v5641 = load i64, ptr %slot39, align 8
  %p5642 = inttoptr i64 %v5641 to ptr
  %ld5643 = load i64, ptr %p5642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5643, ptr %slot938, align 8
  %v5644 = load i64, ptr %slot938, align 8
  %cond5645 = icmp ne i64 %v5644, 0
  br i1 %cond5645, label %bb_success1266, label %bb_failed1266
bb_failed1266:
  %v5646 = load i64, ptr %slot1, align 8
  %p5647 = inttoptr i64 %v5646 to ptr
  call void @myl_qbe_fail_assert(ptr %p5647) nomerge, !dbg !164
  unreachable
bb_success1266:
  br label %bb_i89
bb_i77:
  %v5648 = load i64, ptr %slot39, align 8
  %p5649 = inttoptr i64 %v5648 to ptr
  store i64 0, ptr %p5649, align 8, !alias.scope !3, !noalias !4
  %v5650 = load i64, ptr %slot39, align 8
  %p5651 = inttoptr i64 %v5650 to ptr
  %ld5652 = load i64, ptr %p5651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5652, ptr %slot939, align 8
  %v5653 = load i64, ptr %slot939, align 8
  %cond5654 = icmp ne i64 %v5653, 0
  br i1 %cond5654, label %bb_success1268, label %bb_failed1268
bb_failed1268:
  %v5655 = load i64, ptr %slot1, align 8
  %p5656 = inttoptr i64 %v5655 to ptr
  call void @myl_qbe_fail_assert(ptr %p5656) nomerge, !dbg !166
  unreachable
bb_success1268:
  br label %bb_i89
bb_i80:
  %v5657 = load i64, ptr %slot39, align 8
  %p5658 = inttoptr i64 %v5657 to ptr
  store i64 0, ptr %p5658, align 8, !alias.scope !3, !noalias !4
  %v5659 = load i64, ptr %slot39, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  %ld5661 = load i64, ptr %p5660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5661, ptr %slot940, align 8
  %v5662 = load i64, ptr %slot940, align 8
  %cond5663 = icmp ne i64 %v5662, 0
  br i1 %cond5663, label %bb_success1270, label %bb_failed1270
bb_failed1270:
  %v5664 = load i64, ptr %slot1, align 8
  %p5665 = inttoptr i64 %v5664 to ptr
  call void @myl_qbe_fail_assert(ptr %p5665) nomerge, !dbg !168
  unreachable
bb_success1270:
  br label %bb_i89
bb_i83:
  %v5666 = load i64, ptr %slot39, align 8
  %p5667 = inttoptr i64 %v5666 to ptr
  store i64 0, ptr %p5667, align 8, !alias.scope !3, !noalias !4
  %v5668 = load i64, ptr %slot39, align 8
  %p5669 = inttoptr i64 %v5668 to ptr
  %ld5670 = load i64, ptr %p5669, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5670, ptr %slot941, align 8
  %v5671 = load i64, ptr %slot941, align 8
  %cond5672 = icmp ne i64 %v5671, 0
  br i1 %cond5672, label %bb_success1272, label %bb_failed1272
bb_failed1272:
  %v5673 = load i64, ptr %slot1, align 8
  %p5674 = inttoptr i64 %v5673 to ptr
  call void @myl_qbe_fail_assert(ptr %p5674) nomerge, !dbg !170
  unreachable
bb_success1272:
  br label %bb_i89
bb_i86:
  %v5675 = load i64, ptr %slot39, align 8
  %p5676 = inttoptr i64 %v5675 to ptr
  store i64 0, ptr %p5676, align 8, !alias.scope !3, !noalias !4
  %v5677 = load i64, ptr %slot39, align 8
  %p5678 = inttoptr i64 %v5677 to ptr
  %ld5679 = load i64, ptr %p5678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5679, ptr %slot942, align 8
  %v5680 = load i64, ptr %slot942, align 8
  %cond5681 = icmp ne i64 %v5680, 0
  br i1 %cond5681, label %bb_success1274, label %bb_failed1274
bb_failed1274:
  %v5682 = load i64, ptr %slot1, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  call void @myl_qbe_fail_assert(ptr %p5683) nomerge, !dbg !172
  unreachable
bb_success1274:
  br label %bb_i89
bb_i89:
  br label %bb_i121
bb_i91:
  %v5684 = load i64, ptr %slot39, align 8
  %p5685 = inttoptr i64 %v5684 to ptr
  store i64 0, ptr %p5685, align 8, !alias.scope !3, !noalias !4
  %v5686 = load i64, ptr %slot39, align 8
  %p5687 = inttoptr i64 %v5686 to ptr
  %ld5688 = load i64, ptr %p5687, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5688, ptr %slot943, align 8
  %v5689 = load i64, ptr %slot943, align 8
  %cond5690 = icmp ne i64 %v5689, 0
  br i1 %cond5690, label %bb_success1301, label %bb_failed1301
bb_failed1301:
  %v5691 = load i64, ptr %slot1, align 8
  %p5692 = inttoptr i64 %v5691 to ptr
  call void @myl_qbe_fail_assert(ptr %p5692) nomerge, !dbg !174
  unreachable
bb_success1301:
  br label %bb_i121
bb_i94:
  %v5693 = load i64, ptr %slot39, align 8
  %p5694 = inttoptr i64 %v5693 to ptr
  store i64 0, ptr %p5694, align 8, !alias.scope !3, !noalias !4
  %v5695 = load i64, ptr %slot39, align 8
  %p5696 = inttoptr i64 %v5695 to ptr
  %ld5697 = load i64, ptr %p5696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5697, ptr %slot944, align 8
  %v5698 = load i64, ptr %slot944, align 8
  %cond5699 = icmp ne i64 %v5698, 0
  br i1 %cond5699, label %bb_success1303, label %bb_failed1303
bb_failed1303:
  %v5700 = load i64, ptr %slot1, align 8
  %p5701 = inttoptr i64 %v5700 to ptr
  call void @myl_qbe_fail_assert(ptr %p5701) nomerge, !dbg !176
  unreachable
bb_success1303:
  br label %bb_i121
bb_i97:
  %v5702 = load i64, ptr %slot39, align 8
  %p5703 = inttoptr i64 %v5702 to ptr
  store i64 0, ptr %p5703, align 8, !alias.scope !3, !noalias !4
  %v5704 = load i64, ptr %slot39, align 8
  %p5705 = inttoptr i64 %v5704 to ptr
  %ld5706 = load i64, ptr %p5705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5706, ptr %slot945, align 8
  %v5707 = load i64, ptr %slot945, align 8
  %cond5708 = icmp ne i64 %v5707, 0
  br i1 %cond5708, label %bb_success1305, label %bb_failed1305
bb_failed1305:
  %v5709 = load i64, ptr %slot1, align 8
  %p5710 = inttoptr i64 %v5709 to ptr
  call void @myl_qbe_fail_assert(ptr %p5710) nomerge, !dbg !178
  unreachable
bb_success1305:
  br label %bb_i121
bb_i100:
  %v5711 = load i64, ptr %slot39, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  store i64 0, ptr %p5712, align 8, !alias.scope !3, !noalias !4
  %v5713 = load i64, ptr %slot39, align 8
  %p5714 = inttoptr i64 %v5713 to ptr
  %ld5715 = load i64, ptr %p5714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5715, ptr %slot946, align 8
  %v5716 = load i64, ptr %slot946, align 8
  %cond5717 = icmp ne i64 %v5716, 0
  br i1 %cond5717, label %bb_success1307, label %bb_failed1307
bb_failed1307:
  %v5718 = load i64, ptr %slot1, align 8
  %p5719 = inttoptr i64 %v5718 to ptr
  call void @myl_qbe_fail_assert(ptr %p5719) nomerge, !dbg !180
  unreachable
bb_success1307:
  br label %bb_i121
bb_i103:
  %v5720 = load i64, ptr %slot39, align 8
  %p5721 = inttoptr i64 %v5720 to ptr
  store i64 0, ptr %p5721, align 8, !alias.scope !3, !noalias !4
  %v5722 = load i64, ptr %slot39, align 8
  %p5723 = inttoptr i64 %v5722 to ptr
  %ld5724 = load i64, ptr %p5723, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5724, ptr %slot947, align 8
  %v5725 = load i64, ptr %slot947, align 8
  %cond5726 = icmp ne i64 %v5725, 0
  br i1 %cond5726, label %bb_success1309, label %bb_failed1309
bb_failed1309:
  %v5727 = load i64, ptr %slot1, align 8
  %p5728 = inttoptr i64 %v5727 to ptr
  call void @myl_qbe_fail_assert(ptr %p5728) nomerge, !dbg !182
  unreachable
bb_success1309:
  br label %bb_i121
bb_i106:
  %v5729 = load i64, ptr %slot39, align 8
  %p5730 = inttoptr i64 %v5729 to ptr
  store i64 0, ptr %p5730, align 8, !alias.scope !3, !noalias !4
  %v5731 = load i64, ptr %slot39, align 8
  %p5732 = inttoptr i64 %v5731 to ptr
  %ld5733 = load i64, ptr %p5732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5733, ptr %slot948, align 8
  %v5734 = load i64, ptr %slot948, align 8
  %cond5735 = icmp ne i64 %v5734, 0
  br i1 %cond5735, label %bb_success1311, label %bb_failed1311
bb_failed1311:
  %v5736 = load i64, ptr %slot1, align 8
  %p5737 = inttoptr i64 %v5736 to ptr
  call void @myl_qbe_fail_assert(ptr %p5737) nomerge, !dbg !184
  unreachable
bb_success1311:
  br label %bb_i121
bb_i109:
  %v5738 = load i64, ptr %slot39, align 8
  %p5739 = inttoptr i64 %v5738 to ptr
  store i64 0, ptr %p5739, align 8, !alias.scope !3, !noalias !4
  %v5740 = load i64, ptr %slot39, align 8
  %p5741 = inttoptr i64 %v5740 to ptr
  %ld5742 = load i64, ptr %p5741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5742, ptr %slot949, align 8
  %v5743 = load i64, ptr %slot949, align 8
  %cond5744 = icmp ne i64 %v5743, 0
  br i1 %cond5744, label %bb_success1313, label %bb_failed1313
bb_failed1313:
  %v5745 = load i64, ptr %slot1, align 8
  %p5746 = inttoptr i64 %v5745 to ptr
  call void @myl_qbe_fail_assert(ptr %p5746) nomerge, !dbg !186
  unreachable
bb_success1313:
  br label %bb_i121
bb_i112:
  %v5747 = load i64, ptr %slot39, align 8
  %p5748 = inttoptr i64 %v5747 to ptr
  store i64 0, ptr %p5748, align 8, !alias.scope !3, !noalias !4
  %v5749 = load i64, ptr %slot39, align 8
  %p5750 = inttoptr i64 %v5749 to ptr
  %ld5751 = load i64, ptr %p5750, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5751, ptr %slot950, align 8
  %v5752 = load i64, ptr %slot950, align 8
  %cond5753 = icmp ne i64 %v5752, 0
  br i1 %cond5753, label %bb_success1315, label %bb_failed1315
bb_failed1315:
  %v5754 = load i64, ptr %slot1, align 8
  %p5755 = inttoptr i64 %v5754 to ptr
  call void @myl_qbe_fail_assert(ptr %p5755) nomerge, !dbg !188
  unreachable
bb_success1315:
  br label %bb_i121
bb_i115:
  %v5756 = load i64, ptr %slot39, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  store i64 0, ptr %p5757, align 8, !alias.scope !3, !noalias !4
  %v5758 = load i64, ptr %slot39, align 8
  %p5759 = inttoptr i64 %v5758 to ptr
  %ld5760 = load i64, ptr %p5759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5760, ptr %slot951, align 8
  %v5761 = load i64, ptr %slot951, align 8
  %cond5762 = icmp ne i64 %v5761, 0
  br i1 %cond5762, label %bb_success1317, label %bb_failed1317
bb_failed1317:
  %v5763 = load i64, ptr %slot1, align 8
  %p5764 = inttoptr i64 %v5763 to ptr
  call void @myl_qbe_fail_assert(ptr %p5764) nomerge, !dbg !190
  unreachable
bb_success1317:
  br label %bb_i121
bb_i118:
  %v5765 = load i64, ptr %slot39, align 8
  %p5766 = inttoptr i64 %v5765 to ptr
  store i64 0, ptr %p5766, align 8, !alias.scope !3, !noalias !4
  %v5767 = load i64, ptr %slot39, align 8
  %p5768 = inttoptr i64 %v5767 to ptr
  %ld5769 = load i64, ptr %p5768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5769, ptr %slot952, align 8
  %v5770 = load i64, ptr %slot952, align 8
  %cond5771 = icmp ne i64 %v5770, 0
  br i1 %cond5771, label %bb_success1319, label %bb_failed1319
bb_failed1319:
  %v5772 = load i64, ptr %slot1, align 8
  %p5773 = inttoptr i64 %v5772 to ptr
  call void @myl_qbe_fail_assert(ptr %p5773) nomerge, !dbg !192
  unreachable
bb_success1319:
  br label %bb_i121
bb_i121:
  %v5774 = load i64, ptr %slot39, align 8
  %p5775 = inttoptr i64 %v5774 to ptr
  store i64 0, ptr %p5775, align 8, !alias.scope !3, !noalias !4
  %v5776 = load i64, ptr %slot39, align 8
  %p5777 = inttoptr i64 %v5776 to ptr
  %ld5778 = load i64, ptr %p5777, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5778, ptr %slot953, align 8
  %v5779 = load i64, ptr %slot953, align 8
  %cmp5780 = icmp sge i64 %v5779, 0
  %cv5781 = zext i1 %cmp5780 to i64
  store i64 %cv5781, ptr %slot954, align 8
  %v5782 = load i64, ptr %slot954, align 8
  %cond5783 = icmp ne i64 %v5782, 0
  br i1 %cond5783, label %bb_success1322, label %bb_failed1322
bb_failed1322:
  %v5784 = load i64, ptr %slot1, align 8
  %p5785 = inttoptr i64 %v5784 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p5785) nomerge, !dbg !194
  unreachable
bb_success1322:
  %v5786 = load i64, ptr %slot46, align 8
  %p5787 = inttoptr i64 %v5786 to ptr
  %p5788 = inttoptr i64 ptrtoint (ptr @myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47 to i64) to ptr
  %v5789 = load i64, ptr %slot953, align 8
  %call5790 = call ptr @myl_native_list_new(ptr %p5787, ptr %p5788, i64 %v5789) nomerge, !dbg !194
  %calladdr5791 = ptrtoint ptr %call5790 to i64
  store i64 %calladdr5791, ptr %slot955, align 8
  %v5792 = load i64, ptr %slot955, align 8
  %cond5793 = icmp ne i64 %v5792, 0
  br i1 %cond5793, label %bb_success1324, label %bb_failed1324
bb_failed1324:
  %v5794 = load i64, ptr %slot1, align 8
  %p5795 = inttoptr i64 %v5794 to ptr
  call void @myl_qbe_fail_allocation(ptr %p5795) nomerge, !dbg !194
  unreachable
bb_success1324:
  %v5796 = load i64, ptr %slot955, align 8
  %v5797 = load i64, ptr %slot39, align 8
  %p5798 = inttoptr i64 %v5797 to ptr
  store i64 %v5796, ptr %p5798, align 8, !alias.scope !3, !noalias !4
  %v5799 = load i64, ptr %slot39, align 8
  %p5800 = inttoptr i64 %v5799 to ptr
  %ld5801 = load i64, ptr %p5800, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5801, ptr %slot956, align 8
  %v5802 = load i64, ptr %slot956, align 8
  %v5803 = load i64, ptr %slot24, align 8
  %p5804 = inttoptr i64 %v5803 to ptr
  store i64 %v5802, ptr %p5804, align 8, !alias.scope !3, !noalias !4
  %v5805 = load i64, ptr %slot24, align 8
  store i64 %v5805, ptr %slot957, align 8
  %v5806 = load i64, ptr %slot27, align 8
  store i64 %v5806, ptr %slot958, align 8
  %v5807 = load i64, ptr %slot957, align 8
  %v5808 = load i64, ptr %slot958, align 8
  %p5809 = inttoptr i64 %v5807 to ptr
  %p5810 = inttoptr i64 %v5808 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5810, ptr %p5809, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5811 = load i64, ptr %slot19, align 8
  %p5812 = inttoptr i64 %v5811 to ptr
  store i32 2, ptr %p5812, align 4, !alias.scope !3, !noalias !4
  %v5813 = load i64, ptr %slot18, align 8
  %p5814 = inttoptr i64 %v5813 to ptr
  store i32 1, ptr %p5814, align 4, !alias.scope !3, !noalias !4
  %v5815 = load i64, ptr %slot21, align 8
  store i64 %v5815, ptr %slot959, align 8
  %v5816 = load i64, ptr %slot27, align 8
  store i64 %v5816, ptr %slot960, align 8
  %v5817 = load i64, ptr %slot960, align 8
  %v5818 = load i64, ptr %slot959, align 8
  %p5819 = inttoptr i64 %v5817 to ptr
  %p5820 = inttoptr i64 %v5818 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5820, ptr %p5819, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5821 = load i64, ptr %slot13, align 8
  %p5822 = inttoptr i64 %v5821 to ptr
  store i32 2, ptr %p5822, align 4, !alias.scope !3, !noalias !4
  %v5823 = load i64, ptr %slot19, align 8
  %p5824 = inttoptr i64 %v5823 to ptr
  %ld5825 = load i32, ptr %p5824, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5825, ptr %slot961, align 8
  %v5826 = load i32, ptr %slot961, align 8
  %v5827 = load i64, ptr %slot13, align 8
  %p5828 = inttoptr i64 %v5827 to ptr
  store i32 %v5826, ptr %p5828, align 4, !alias.scope !3, !noalias !4
  %v5829 = load i64, ptr %slot18, align 8
  %p5830 = inttoptr i64 %v5829 to ptr
  store i32 0, ptr %p5830, align 4, !alias.scope !3, !noalias !4
  %v5831 = load i64, ptr %slot12, align 8
  %p5832 = inttoptr i64 %v5831 to ptr
  store i32 1, ptr %p5832, align 4, !alias.scope !3, !noalias !4
  %v5833 = load i64, ptr %slot959, align 8
  %p5834 = inttoptr i64 %v5833 to ptr
  %ld5835 = load i64, ptr %p5834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5835, ptr %slot962, align 8
  %v5836 = load i64, ptr %slot962, align 8
  %v5837 = load i64, ptr %slot39, align 8
  %p5838 = inttoptr i64 %v5837 to ptr
  store i64 %v5836, ptr %p5838, align 8, !alias.scope !3, !noalias !4
  %v5839 = load i64, ptr %slot39, align 8
  %p5840 = inttoptr i64 %v5839 to ptr
  %ld5841 = load i64, ptr %p5840, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5841, ptr %slot963, align 8
  %v5842 = load i64, ptr %slot963, align 8
  %v5843 = load i64, ptr %slot24, align 8
  %p5844 = inttoptr i64 %v5843 to ptr
  store i64 %v5842, ptr %p5844, align 8, !alias.scope !3, !noalias !4
  %v5845 = load i64, ptr %slot24, align 8
  store i64 %v5845, ptr %slot964, align 8
  %v5846 = load i64, ptr %slot12, align 8
  %p5847 = inttoptr i64 %v5846 to ptr
  %ld5848 = load i32, ptr %p5847, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5848, ptr %slot965, align 8
  %v5849 = load i64, ptr %slot13, align 8
  %p5850 = inttoptr i64 %v5849 to ptr
  %ld5851 = load i32, ptr %p5850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5851, ptr %slot966, align 8
  %v5852 = load i32, ptr %slot966, align 8
  %op5853 = and i32 %v5852, 24
  store i32 %op5853, ptr %slot966, align 8
  %v5854 = load i32, ptr %slot966, align 8
  %cmp5855 = icmp eq i32 %v5854, 0
  %cv5856 = zext i1 %cmp5855 to i32
  store i32 %cv5856, ptr %slot967, align 8
  %v5857 = load i32, ptr %slot965, align 8
  %v5858 = load i32, ptr %slot967, align 8
  %op5859 = and i32 %v5857, %v5858
  store i32 %op5859, ptr %slot968, align 8
  %v5860 = load i32, ptr %slot968, align 8
  %cv5861 = zext i32 %v5860 to i64
  %cond5862 = icmp ne i64 %cv5861, 0
  br i1 %cond5862, label %bb_rcprivateown1347, label %bb_rcprivateloan1347
bb_rcprivateown1347:
  %v5863 = load i64, ptr %slot27, align 8
  store i64 %v5863, ptr %slot969, align 8
  %v5864 = load i64, ptr %slot47, align 8
  store i64 %v5864, ptr %slot970, align 8
  %v5865 = load i64, ptr %slot964, align 8
  %v5866 = load i64, ptr %slot969, align 8
  %op5867 = sub i64 %v5865, %v5866
  store i64 %op5867, ptr %slot971, align 8
  %v5868 = load i64, ptr %slot969, align 8
  %v5869 = load i64, ptr %slot964, align 8
  %op5870 = sub i64 %v5868, %v5869
  store i64 %op5870, ptr %slot972, align 8
  %v5871 = load i64, ptr %slot971, align 8
  %cmp5872 = icmp ult i64 %v5871, 8
  %cv5873 = zext i1 %cmp5872 to i32
  store i32 %cv5873, ptr %slot973, align 8
  %v5874 = load i64, ptr %slot972, align 8
  %cmp5875 = icmp ult i64 %v5874, 8
  %cv5876 = zext i1 %cmp5875 to i32
  store i32 %cv5876, ptr %slot974, align 8
  %v5877 = load i32, ptr %slot973, align 8
  %v5878 = load i32, ptr %slot974, align 8
  %op5879 = or i32 %v5877, %v5878
  store i32 %op5879, ptr %slot975, align 8
  %v5880 = load i32, ptr %slot975, align 8
  %cv5881 = zext i32 %v5880 to i64
  %cond5882 = icmp ne i64 %cv5881, 0
  br i1 %cond5882, label %bb_rcmoveslow1350, label %bb_rcmovecheck1350
bb_rcmovecheck1350:
  %v5883 = load i64, ptr %slot964, align 8
  %p5885 = inttoptr i64 %v5883 to ptr
  %gep5886 = getelementptr i8, ptr %p5885, i64 0
  %op5884 = ptrtoint ptr %gep5886 to i64
  store i64 %op5884, ptr %slot976, align 8
  %v5887 = load i64, ptr %slot976, align 8
  %p5888 = inttoptr i64 %v5887 to ptr
  %ld5889 = load i64, ptr %p5888, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5889, ptr %slot977, align 8
  %v5890 = load i64, ptr %slot977, align 8
  %cmp5891 = icmp ne i64 %v5890, 0
  %cv5892 = zext i1 %cmp5891 to i32
  store i32 %cv5892, ptr %slot978, align 8
  %v5893 = load i32, ptr %slot978, align 8
  %cv5894 = zext i32 %v5893 to i64
  %cond5895 = icmp ne i64 %cv5894, 0
  br i1 %cond5895, label %bb_rcmoveheader1358, label %bb_rcmovenext1358
bb_rcmoveheader1358:
  %v5896 = load i64, ptr %slot977, align 8
  %op5897 = sub i64 %v5896, 16
  store i64 %op5897, ptr %slot979, align 8
  %v5898 = load i64, ptr %slot977, align 8
  %p5899 = inttoptr i64 %v5898 to ptr
  %rgep5900 = getelementptr i8, ptr %p5899, i64 -16
  %ld5901 = load i64, ptr %rgep5900, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5901, ptr %slot980, align 8
  %v5902 = load i64, ptr %slot980, align 8
  %op5903 = and i64 %v5902, 5764607523034234881
  store i64 %op5903, ptr %slot981, align 8
  %v5904 = load i64, ptr %slot981, align 8
  %cmp5905 = icmp ne i64 %v5904, 0
  %cv5906 = zext i1 %cmp5905 to i32
  store i32 %cv5906, ptr %slot982, align 8
  %v5907 = load i32, ptr %slot982, align 8
  %cv5908 = zext i32 %v5907 to i64
  %cond5909 = icmp ne i64 %cv5908, 0
  br i1 %cond5909, label %bb_rcmoveslow1350, label %bb_rcmovenext1358
bb_rcmovenext1358:
  %v5910 = load i64, ptr %slot964, align 8
  %v5911 = load i64, ptr %slot969, align 8
  %p5912 = inttoptr i64 %v5910 to ptr
  %p5913 = inttoptr i64 %v5911 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5913, ptr %p5912, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5914 = load i64, ptr %slot964, align 8
  %p5915 = inttoptr i64 %v5914 to ptr
  store i64 0, ptr %p5915, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1350
bb_rcmoveslow1350:
  %v5916 = load i64, ptr %slot46, align 8
  %v5917 = load i64, ptr %slot969, align 8
  %v5918 = load i64, ptr %slot964, align 8
  %v5919 = load i64, ptr %slot970, align 8
  %cv5920 = trunc i64 %v5919 to i32
  %call5921 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64 %v5916, i64 %v5917, i64 %v5918, i32 %cv5920) nomerge, !dbg !196
  store i32 %call5921, ptr %slot983, align 8
  %v5922 = load i32, ptr %slot983, align 8
  %cv5923 = zext i32 %v5922 to i64
  %cond5924 = icmp ne i64 %cv5923, 0
  br i1 %cond5924, label %bb_rcsuccess1365, label %bb_rcfailure1365
bb_rcfailure1365:
  %v5925 = load i64, ptr %slot46, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  %call5927 = call i32 @myl_rc_take_failure(ptr %p5926) nomerge, !dbg !196
  store i32 %call5927, ptr %slot984, align 8
  %v5928 = load i64, ptr %slot1, align 8
  %p5929 = inttoptr i64 %v5928 to ptr
  %v5930 = load i32, ptr %slot984, align 8
  %call5931 = call i32 @myl_qbe_rc_status(ptr %p5929, i32 %v5930) nomerge, !dbg !196
  store i32 %call5931, ptr %slot985, align 8
  br label %bb_failure
bb_rcsuccess1365:
  br label %bb_rcmoved1350
bb_rcmoved1350:
  %v5932 = load i64, ptr %slot12, align 8
  %p5933 = inttoptr i64 %v5932 to ptr
  store i32 0, ptr %p5933, align 4, !alias.scope !3, !noalias !4
  %v5934 = load i64, ptr %slot19, align 8
  %p5935 = inttoptr i64 %v5934 to ptr
  store i32 2, ptr %p5935, align 4, !alias.scope !3, !noalias !4
  %v5936 = load i64, ptr %slot18, align 8
  %p5937 = inttoptr i64 %v5936 to ptr
  store i32 1, ptr %p5937, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1347
bb_rcprivateloan1347:
  %v5938 = load i64, ptr %slot12, align 8
  %p5939 = inttoptr i64 %v5938 to ptr
  %ld5940 = load i32, ptr %p5939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5940, ptr %slot986, align 8
  %v5941 = load i64, ptr %slot13, align 8
  %p5942 = inttoptr i64 %v5941 to ptr
  %ld5943 = load i32, ptr %p5942, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5943, ptr %slot987, align 8
  %v5944 = load i32, ptr %slot987, align 8
  %cmp5945 = icmp eq i32 %v5944, 16
  %cv5946 = zext i1 %cmp5945 to i32
  store i32 %cv5946, ptr %slot988, align 8
  %v5947 = load i32, ptr %slot988, align 8
  %v5948 = load i32, ptr %slot986, align 8
  %op5949 = and i32 %v5947, %v5948
  store i32 %op5949, ptr %slot988, align 8
  %v5950 = load i32, ptr %slot988, align 8
  %cv5951 = zext i32 %v5950 to i64
  %cond5952 = icmp ne i64 %cv5951, 0
  br i1 %cond5952, label %bb_rcprivatemove1347, label %bb_rcprivatenew1347
bb_rcprivatemove1347:
  %v5953 = load i64, ptr %slot27, align 8
  store i64 %v5953, ptr %slot989, align 8
  %v5954 = load i64, ptr %slot964, align 8
  %v5955 = load i64, ptr %slot989, align 8
  %p5956 = inttoptr i64 %v5954 to ptr
  %p5957 = inttoptr i64 %v5955 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5957, ptr %p5956, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5958 = load i64, ptr %slot964, align 8
  %p5959 = inttoptr i64 %v5958 to ptr
  store i64 0, ptr %p5959, align 8, !alias.scope !3, !noalias !4
  %v5960 = load i64, ptr %slot19, align 8
  %p5961 = inttoptr i64 %v5960 to ptr
  store i32 2, ptr %p5961, align 4, !alias.scope !3, !noalias !4
  %v5962 = load i64, ptr %slot19, align 8
  %p5963 = inttoptr i64 %v5962 to ptr
  store i32 16, ptr %p5963, align 4, !alias.scope !3, !noalias !4
  %v5964 = load i64, ptr %slot18, align 8
  %p5965 = inttoptr i64 %v5964 to ptr
  store i32 1, ptr %p5965, align 4, !alias.scope !3, !noalias !4
  %v5966 = load i64, ptr %slot12, align 8
  %p5967 = inttoptr i64 %v5966 to ptr
  store i32 0, ptr %p5967, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1347
bb_rcprivatenew1347:
  %v5968 = load i64, ptr %slot27, align 8
  store i64 %v5968, ptr %slot990, align 8
  %v5969 = load i64, ptr %slot964, align 8
  %p5970 = inttoptr i64 %v5969 to ptr
  %ld5971 = load i64, ptr %p5970, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5971, ptr %slot991, align 8
  %v5972 = load i64, ptr %slot991, align 8
  %cmp5973 = icmp ne i64 %v5972, 0
  %cv5974 = zext i1 %cmp5973 to i32
  store i32 %cv5974, ptr %slot992, align 8
  %v5975 = load i32, ptr %slot992, align 8
  %cv5976 = zext i32 %v5975 to i64
  %cond5977 = icmp ne i64 %cv5976, 0
  br i1 %cond5977, label %bb_rcgnn1383, label %bb_rcgstore1383
bb_rcgnn1383:
  %v5978 = load i64, ptr %slot991, align 8
  %op5979 = sub i64 %v5978, 16
  store i64 %op5979, ptr %slot993, align 8
  %v5980 = load i64, ptr %slot991, align 8
  %p5981 = inttoptr i64 %v5980 to ptr
  %rgep5982 = getelementptr i8, ptr %p5981, i64 -16
  %ld5983 = load i64, ptr %rgep5982, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5983, ptr %slot994, align 8
  %v5984 = load i64, ptr %slot994, align 8
  %op5985 = and i64 %v5984, 4611686018427387906
  store i64 %op5985, ptr %slot995, align 8
  %v5986 = load i64, ptr %slot995, align 8
  %cmp5987 = icmp ne i64 %v5986, 0
  %cv5988 = zext i1 %cmp5987 to i32
  store i32 %cv5988, ptr %slot996, align 8
  %v5989 = load i32, ptr %slot996, align 8
  %cv5990 = zext i32 %v5989 to i64
  %cond5991 = icmp ne i64 %cv5990, 0
  br i1 %cond5991, label %bb_rcgstore1383, label %bb_rcginc1383
bb_rcginc1383:
  %v5992 = load i64, ptr %slot991, align 8
  %op5993 = sub i64 %v5992, 24
  store i64 %op5993, ptr %slot997, align 8
  %v5994 = load i64, ptr %slot991, align 8
  %p5995 = inttoptr i64 %v5994 to ptr
  %rgep5996 = getelementptr i8, ptr %p5995, i64 -24
  %ld5997 = load i64, ptr %rgep5996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5997, ptr %slot998, align 8
  %v5998 = load i64, ptr %slot998, align 8
  %op5999 = add i64 %v5998, 1
  store i64 %op5999, ptr %slot999, align 8
  %v6000 = load i64, ptr %slot999, align 8
  %cmp6001 = icmp eq i64 %v6000, 0
  %cv6002 = zext i1 %cmp6001 to i32
  store i32 %cv6002, ptr %slot1000, align 8
  %v6003 = load i32, ptr %slot1000, align 8
  %cv6004 = zext i32 %v6003 to i64
  %cond6005 = icmp ne i64 %cv6004, 0
  br i1 %cond6005, label %bb_rcglimit1383, label %bb_rcgcapacity1383
bb_rcglimit1383:
  %v6006 = load i64, ptr %slot1, align 8
  %p6007 = inttoptr i64 %v6006 to ptr
  %call6008 = call i32 @myl_qbe_rc_status(ptr %p6007, i32 2) nomerge, !dbg !196
  store i32 %call6008, ptr %slot1001, align 8
  br label %bb_failure
bb_rcgcapacity1383:
  %v6009 = load i64, ptr %slot999, align 8
  %v6010 = load i64, ptr %slot991, align 8
  %p6011 = inttoptr i64 %v6010 to ptr
  %rgep6012 = getelementptr i8, ptr %p6011, i64 -24
  store i64 %v6009, ptr %rgep6012, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1383
bb_rcgstore1383:
  %v6013 = load i64, ptr %slot991, align 8
  %v6014 = load i64, ptr %slot990, align 8
  %p6015 = inttoptr i64 %v6014 to ptr
  store i64 %v6013, ptr %p6015, align 8, !alias.scope !3, !noalias !4
  %v6016 = load i64, ptr %slot19, align 8
  %p6017 = inttoptr i64 %v6016 to ptr
  store i32 2, ptr %p6017, align 4, !alias.scope !3, !noalias !4
  %v6018 = load i64, ptr %slot19, align 8
  %p6019 = inttoptr i64 %v6018 to ptr
  store i32 16, ptr %p6019, align 4, !alias.scope !3, !noalias !4
  %v6020 = load i64, ptr %slot18, align 8
  %p6021 = inttoptr i64 %v6020 to ptr
  store i32 1, ptr %p6021, align 4, !alias.scope !3, !noalias !4
  %v6022 = load i64, ptr %slot12, align 8
  %p6023 = inttoptr i64 %v6022 to ptr
  %ld6024 = load i32, ptr %p6023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6024, ptr %slot1002, align 8
  %v6025 = load i32, ptr %slot1002, align 8
  %cv6026 = zext i32 %v6025 to i64
  %cond6027 = icmp ne i64 %cv6026, 0
  br i1 %cond6027, label %bb_rcslotdrop1399, label %bb_rcslotdone1399
bb_rcslotdrop1399:
  %v6028 = load i64, ptr %slot12, align 8
  %p6029 = inttoptr i64 %v6028 to ptr
  store i32 0, ptr %p6029, align 4, !alias.scope !3, !noalias !4
  %v6030 = load i64, ptr %slot21, align 8
  store i64 %v6030, ptr %slot1003, align 8
  %v6031 = load i64, ptr %slot13, align 8
  %p6032 = inttoptr i64 %v6031 to ptr
  %ld6033 = load i32, ptr %p6032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6033, ptr %slot1004, align 8
  %v6034 = load i32, ptr %slot1004, align 8
  %op6035 = and i32 %v6034, 28
  store i32 %op6035, ptr %slot1005, align 8
  %v6036 = load i32, ptr %slot1005, align 8
  %cv6037 = zext i32 %v6036 to i64
  %cond6038 = icmp ne i64 %cv6037, 0
  br i1 %cond6038, label %bb_rcslotrole1399, label %bb_rcslotowner1399
bb_rcslotrole1399:
  %v6039 = load i64, ptr %slot46, align 8
  store i64 %v6039, ptr %slot1006, align 8
  %v6040 = load i64, ptr %slot1003, align 8
  %p6041 = inttoptr i64 %v6040 to ptr
  %ld6042 = load i64, ptr %p6041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6042, ptr %slot1007, align 8
  %v6043 = load i64, ptr %slot1007, align 8
  %cmp6044 = icmp ne i64 %v6043, 0
  %cv6045 = zext i1 %cmp6044 to i32
  store i32 %cv6045, ptr %slot1008, align 8
  %v6046 = load i32, ptr %slot1008, align 8
  %cv6047 = zext i32 %v6046 to i64
  %cond6048 = icmp ne i64 %cv6047, 0
  br i1 %cond6048, label %bb_rcgnn1415, label %bb_rcgdone1415
bb_rcgnn1415:
  %v6049 = load i64, ptr %slot1007, align 8
  %op6050 = sub i64 %v6049, 16
  store i64 %op6050, ptr %slot1009, align 8
  %v6051 = load i64, ptr %slot1007, align 8
  %p6052 = inttoptr i64 %v6051 to ptr
  %rgep6053 = getelementptr i8, ptr %p6052, i64 -16
  %ld6054 = load i64, ptr %rgep6053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6054, ptr %slot1010, align 8
  %v6055 = load i64, ptr %slot1010, align 8
  %op6056 = and i64 %v6055, 4611686018427387906
  store i64 %op6056, ptr %slot1011, align 8
  %v6057 = load i64, ptr %slot1011, align 8
  %cmp6058 = icmp ne i64 %v6057, 0
  %cv6059 = zext i1 %cmp6058 to i32
  store i32 %cv6059, ptr %slot1012, align 8
  %v6060 = load i32, ptr %slot1012, align 8
  %cv6061 = zext i32 %v6060 to i64
  %cond6062 = icmp ne i64 %cv6061, 0
  br i1 %cond6062, label %bb_rcgclear1415, label %bb_rcgcounted1415
bb_rcgcounted1415:
  %v6063 = load i64, ptr %slot1007, align 8
  %op6064 = sub i64 %v6063, 24
  store i64 %op6064, ptr %slot1013, align 8
  %v6065 = load i64, ptr %slot1007, align 8
  %p6066 = inttoptr i64 %v6065 to ptr
  %rgep6067 = getelementptr i8, ptr %p6066, i64 -24
  %ld6068 = load i64, ptr %rgep6067, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6068, ptr %slot1014, align 8
  %v6069 = load i64, ptr %slot1014, align 8
  %op6070 = sub i64 %v6069, 1
  store i64 %op6070, ptr %slot1015, align 8
  %v6071 = load i64, ptr %slot1015, align 8
  %cmp6072 = icmp eq i64 %v6071, 0
  %cv6073 = zext i1 %cmp6072 to i32
  store i32 %cv6073, ptr %slot1016, align 8
  %v6074 = load i32, ptr %slot1016, align 8
  %cv6075 = zext i32 %v6074 to i64
  %cond6076 = icmp ne i64 %cv6075, 0
  br i1 %cond6076, label %bb_rcglast1415, label %bb_rcgdec1415
bb_rcglast1415:
  %v6077 = load i64, ptr %slot1007, align 8
  %op6078 = sub i64 %v6077, 32
  store i64 %op6078, ptr %slot1017, align 8
  %v6079 = load i64, ptr %slot1007, align 8
  %p6080 = inttoptr i64 %v6079 to ptr
  %rgep6081 = getelementptr i8, ptr %p6080, i64 -32
  %ld6082 = load i64, ptr %rgep6081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6082, ptr %slot1018, align 8
  %v6083 = load i64, ptr %slot1018, align 8
  %cmp6084 = icmp ne i64 %v6083, 0
  %cv6085 = zext i1 %cmp6084 to i32
  store i32 %cv6085, ptr %slot1019, align 8
  %v6086 = load i32, ptr %slot1019, align 8
  %cv6087 = zext i32 %v6086 to i64
  %cond6088 = icmp ne i64 %cv6087, 0
  br i1 %cond6088, label %bb_rcgdec1415, label %bb_rcgslow1415
bb_rcgslow1415:
  %v6089 = load i64, ptr %slot1006, align 8
  %v6090 = load i64, ptr %slot1003, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v6089, i64 %v6090) nomerge, !dbg !196
  br label %bb_rcgdone1415
bb_rcgdec1415:
  %v6091 = load i64, ptr %slot1015, align 8
  %v6092 = load i64, ptr %slot1007, align 8
  %p6093 = inttoptr i64 %v6092 to ptr
  %rgep6094 = getelementptr i8, ptr %p6093, i64 -24
  store i64 %v6091, ptr %rgep6094, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1415
bb_rcgclear1415:
  %v6095 = load i64, ptr %slot1003, align 8
  %p6096 = inttoptr i64 %v6095 to ptr
  store i64 0, ptr %p6096, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1415
bb_rcgdone1415:
  br label %bb_rcslotdone1399
bb_rcslotowner1399:
  %v6097 = load i64, ptr %slot46, align 8
  store i64 %v6097, ptr %slot1020, align 8
  %v6098 = load i64, ptr %slot1003, align 8
  %p6099 = inttoptr i64 %v6098 to ptr
  %ld6100 = load i64, ptr %p6099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6100, ptr %slot1021, align 8
  %v6101 = load i64, ptr %slot1021, align 8
  %cmp6102 = icmp ne i64 %v6101, 0
  %cv6103 = zext i1 %cmp6102 to i32
  store i32 %cv6103, ptr %slot1022, align 8
  %v6104 = load i32, ptr %slot1022, align 8
  %cv6105 = zext i32 %v6104 to i64
  %cond6106 = icmp ne i64 %cv6105, 0
  br i1 %cond6106, label %bb_rcgnn1430, label %bb_rcgdone1430
bb_rcgnn1430:
  %v6107 = load i64, ptr %slot1021, align 8
  %op6108 = sub i64 %v6107, 16
  store i64 %op6108, ptr %slot1023, align 8
  %v6109 = load i64, ptr %slot1021, align 8
  %p6110 = inttoptr i64 %v6109 to ptr
  %rgep6111 = getelementptr i8, ptr %p6110, i64 -16
  %ld6112 = load i64, ptr %rgep6111, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6112, ptr %slot1024, align 8
  %v6113 = load i64, ptr %slot1024, align 8
  %op6114 = and i64 %v6113, 4611686018427387906
  store i64 %op6114, ptr %slot1025, align 8
  %v6115 = load i64, ptr %slot1025, align 8
  %cmp6116 = icmp ne i64 %v6115, 0
  %cv6117 = zext i1 %cmp6116 to i32
  store i32 %cv6117, ptr %slot1026, align 8
  %v6118 = load i32, ptr %slot1026, align 8
  %cv6119 = zext i32 %v6118 to i64
  %cond6120 = icmp ne i64 %cv6119, 0
  br i1 %cond6120, label %bb_rcgclear1430, label %bb_rcgcounted1430
bb_rcgcounted1430:
  %v6121 = load i64, ptr %slot1021, align 8
  %op6122 = sub i64 %v6121, 32
  store i64 %op6122, ptr %slot1027, align 8
  %v6123 = load i64, ptr %slot1021, align 8
  %p6124 = inttoptr i64 %v6123 to ptr
  %rgep6125 = getelementptr i8, ptr %p6124, i64 -32
  %ld6126 = load i64, ptr %rgep6125, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6126, ptr %slot1028, align 8
  %v6127 = load i64, ptr %slot1028, align 8
  %op6128 = sub i64 %v6127, 1
  store i64 %op6128, ptr %slot1029, align 8
  %v6129 = load i64, ptr %slot1029, align 8
  %cmp6130 = icmp eq i64 %v6129, 0
  %cv6131 = zext i1 %cmp6130 to i32
  store i32 %cv6131, ptr %slot1030, align 8
  %v6132 = load i32, ptr %slot1030, align 8
  %cv6133 = zext i32 %v6132 to i64
  %cond6134 = icmp ne i64 %cv6133, 0
  br i1 %cond6134, label %bb_rcglast1430, label %bb_rcgdec1430
bb_rcglast1430:
  %v6135 = load i64, ptr %slot1021, align 8
  %op6136 = sub i64 %v6135, 24
  store i64 %op6136, ptr %slot1031, align 8
  %v6137 = load i64, ptr %slot1021, align 8
  %p6138 = inttoptr i64 %v6137 to ptr
  %rgep6139 = getelementptr i8, ptr %p6138, i64 -24
  %ld6140 = load i64, ptr %rgep6139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6140, ptr %slot1032, align 8
  %v6141 = load i64, ptr %slot1032, align 8
  %cmp6142 = icmp ne i64 %v6141, 0
  %cv6143 = zext i1 %cmp6142 to i32
  store i32 %cv6143, ptr %slot1033, align 8
  %v6144 = load i32, ptr %slot1033, align 8
  %cv6145 = zext i32 %v6144 to i64
  %cond6146 = icmp ne i64 %cv6145, 0
  br i1 %cond6146, label %bb_rcgdec1430, label %bb_rcgslow1430
bb_rcgslow1430:
  %v6147 = load i64, ptr %slot1020, align 8
  %v6148 = load i64, ptr %slot1003, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v6147, i64 %v6148) nomerge, !dbg !196
  br label %bb_rcgdone1430
bb_rcgdec1430:
  %v6149 = load i64, ptr %slot1029, align 8
  %v6150 = load i64, ptr %slot1021, align 8
  %p6151 = inttoptr i64 %v6150 to ptr
  %rgep6152 = getelementptr i8, ptr %p6151, i64 -32
  store i64 %v6149, ptr %rgep6152, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1430
bb_rcgclear1430:
  %v6153 = load i64, ptr %slot1003, align 8
  %p6154 = inttoptr i64 %v6153 to ptr
  store i64 0, ptr %p6154, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1430
bb_rcgdone1430:
  br label %bb_rcslotdone1399
bb_rcslotdone1399:
  br label %bb_rcprivateprepared1347
bb_rcprivateprepared1347:
  %v6155 = load i64, ptr %slot6, align 8
  %p6156 = inttoptr i64 %v6155 to ptr
  %ld6157 = load i32, ptr %p6156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6157, ptr %slot1034, align 8
  %v6158 = load i32, ptr %slot1034, align 8
  %cv6159 = zext i32 %v6158 to i64
  %cond6160 = icmp ne i64 %cv6159, 0
  br i1 %cond6160, label %bb_rcslotdrop1437, label %bb_rcslotdone1437
bb_rcslotdrop1437:
  %v6161 = load i64, ptr %slot6, align 8
  %p6162 = inttoptr i64 %v6161 to ptr
  store i32 0, ptr %p6162, align 4, !alias.scope !3, !noalias !4
  %v6163 = load i64, ptr %slot36, align 8
  store i64 %v6163, ptr %slot1035, align 8
  %v6164 = load i64, ptr %slot7, align 8
  %p6165 = inttoptr i64 %v6164 to ptr
  %ld6166 = load i32, ptr %p6165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6166, ptr %slot1036, align 8
  %v6167 = load i32, ptr %slot1036, align 8
  %op6168 = and i32 %v6167, 28
  store i32 %op6168, ptr %slot1037, align 8
  %v6169 = load i32, ptr %slot1037, align 8
  %cv6170 = zext i32 %v6169 to i64
  %cond6171 = icmp ne i64 %cv6170, 0
  br i1 %cond6171, label %bb_rcslotrole1437, label %bb_rcslotowner1437
bb_rcslotrole1437:
  %v6172 = load i64, ptr %slot46, align 8
  store i64 %v6172, ptr %slot1038, align 8
  %v6173 = load i64, ptr %slot1035, align 8
  %p6174 = inttoptr i64 %v6173 to ptr
  %ld6175 = load i64, ptr %p6174, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6175, ptr %slot1039, align 8
  %v6176 = load i64, ptr %slot1039, align 8
  %cmp6177 = icmp ne i64 %v6176, 0
  %cv6178 = zext i1 %cmp6177 to i32
  store i32 %cv6178, ptr %slot1040, align 8
  %v6179 = load i32, ptr %slot1040, align 8
  %cv6180 = zext i32 %v6179 to i64
  %cond6181 = icmp ne i64 %cv6180, 0
  br i1 %cond6181, label %bb_rcgnn1453, label %bb_rcgdone1453
bb_rcgnn1453:
  %v6182 = load i64, ptr %slot1039, align 8
  %op6183 = sub i64 %v6182, 16
  store i64 %op6183, ptr %slot1041, align 8
  %v6184 = load i64, ptr %slot1039, align 8
  %p6185 = inttoptr i64 %v6184 to ptr
  %rgep6186 = getelementptr i8, ptr %p6185, i64 -16
  %ld6187 = load i64, ptr %rgep6186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6187, ptr %slot1042, align 8
  %v6188 = load i64, ptr %slot1042, align 8
  %op6189 = and i64 %v6188, 4611686018427387906
  store i64 %op6189, ptr %slot1043, align 8
  %v6190 = load i64, ptr %slot1043, align 8
  %cmp6191 = icmp ne i64 %v6190, 0
  %cv6192 = zext i1 %cmp6191 to i32
  store i32 %cv6192, ptr %slot1044, align 8
  %v6193 = load i32, ptr %slot1044, align 8
  %cv6194 = zext i32 %v6193 to i64
  %cond6195 = icmp ne i64 %cv6194, 0
  br i1 %cond6195, label %bb_rcgclear1453, label %bb_rcgcounted1453
bb_rcgcounted1453:
  %v6196 = load i64, ptr %slot1039, align 8
  %op6197 = sub i64 %v6196, 24
  store i64 %op6197, ptr %slot1045, align 8
  %v6198 = load i64, ptr %slot1039, align 8
  %p6199 = inttoptr i64 %v6198 to ptr
  %rgep6200 = getelementptr i8, ptr %p6199, i64 -24
  %ld6201 = load i64, ptr %rgep6200, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6201, ptr %slot1046, align 8
  %v6202 = load i64, ptr %slot1046, align 8
  %op6203 = sub i64 %v6202, 1
  store i64 %op6203, ptr %slot1047, align 8
  %v6204 = load i64, ptr %slot1047, align 8
  %cmp6205 = icmp eq i64 %v6204, 0
  %cv6206 = zext i1 %cmp6205 to i32
  store i32 %cv6206, ptr %slot1048, align 8
  %v6207 = load i32, ptr %slot1048, align 8
  %cv6208 = zext i32 %v6207 to i64
  %cond6209 = icmp ne i64 %cv6208, 0
  br i1 %cond6209, label %bb_rcglast1453, label %bb_rcgdec1453
bb_rcglast1453:
  %v6210 = load i64, ptr %slot1039, align 8
  %op6211 = sub i64 %v6210, 32
  store i64 %op6211, ptr %slot1049, align 8
  %v6212 = load i64, ptr %slot1039, align 8
  %p6213 = inttoptr i64 %v6212 to ptr
  %rgep6214 = getelementptr i8, ptr %p6213, i64 -32
  %ld6215 = load i64, ptr %rgep6214, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6215, ptr %slot1050, align 8
  %v6216 = load i64, ptr %slot1050, align 8
  %cmp6217 = icmp ne i64 %v6216, 0
  %cv6218 = zext i1 %cmp6217 to i32
  store i32 %cv6218, ptr %slot1051, align 8
  %v6219 = load i32, ptr %slot1051, align 8
  %cv6220 = zext i32 %v6219 to i64
  %cond6221 = icmp ne i64 %cv6220, 0
  br i1 %cond6221, label %bb_rcgdec1453, label %bb_rcgslow1453
bb_rcgslow1453:
  %v6222 = load i64, ptr %slot1038, align 8
  %v6223 = load i64, ptr %slot1035, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v6222, i64 %v6223) nomerge, !dbg !196
  br label %bb_rcgdone1453
bb_rcgdec1453:
  %v6224 = load i64, ptr %slot1047, align 8
  %v6225 = load i64, ptr %slot1039, align 8
  %p6226 = inttoptr i64 %v6225 to ptr
  %rgep6227 = getelementptr i8, ptr %p6226, i64 -24
  store i64 %v6224, ptr %rgep6227, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1453
bb_rcgclear1453:
  %v6228 = load i64, ptr %slot1035, align 8
  %p6229 = inttoptr i64 %v6228 to ptr
  store i64 0, ptr %p6229, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1453
bb_rcgdone1453:
  br label %bb_rcslotdone1437
bb_rcslotowner1437:
  %v6230 = load i64, ptr %slot46, align 8
  store i64 %v6230, ptr %slot1052, align 8
  %v6231 = load i64, ptr %slot1035, align 8
  %p6232 = inttoptr i64 %v6231 to ptr
  %ld6233 = load i64, ptr %p6232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6233, ptr %slot1053, align 8
  %v6234 = load i64, ptr %slot1053, align 8
  %cmp6235 = icmp ne i64 %v6234, 0
  %cv6236 = zext i1 %cmp6235 to i32
  store i32 %cv6236, ptr %slot1054, align 8
  %v6237 = load i32, ptr %slot1054, align 8
  %cv6238 = zext i32 %v6237 to i64
  %cond6239 = icmp ne i64 %cv6238, 0
  br i1 %cond6239, label %bb_rcgnn1468, label %bb_rcgdone1468
bb_rcgnn1468:
  %v6240 = load i64, ptr %slot1053, align 8
  %op6241 = sub i64 %v6240, 16
  store i64 %op6241, ptr %slot1055, align 8
  %v6242 = load i64, ptr %slot1053, align 8
  %p6243 = inttoptr i64 %v6242 to ptr
  %rgep6244 = getelementptr i8, ptr %p6243, i64 -16
  %ld6245 = load i64, ptr %rgep6244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6245, ptr %slot1056, align 8
  %v6246 = load i64, ptr %slot1056, align 8
  %op6247 = and i64 %v6246, 4611686018427387906
  store i64 %op6247, ptr %slot1057, align 8
  %v6248 = load i64, ptr %slot1057, align 8
  %cmp6249 = icmp ne i64 %v6248, 0
  %cv6250 = zext i1 %cmp6249 to i32
  store i32 %cv6250, ptr %slot1058, align 8
  %v6251 = load i32, ptr %slot1058, align 8
  %cv6252 = zext i32 %v6251 to i64
  %cond6253 = icmp ne i64 %cv6252, 0
  br i1 %cond6253, label %bb_rcgclear1468, label %bb_rcgcounted1468
bb_rcgcounted1468:
  %v6254 = load i64, ptr %slot1053, align 8
  %op6255 = sub i64 %v6254, 32
  store i64 %op6255, ptr %slot1059, align 8
  %v6256 = load i64, ptr %slot1053, align 8
  %p6257 = inttoptr i64 %v6256 to ptr
  %rgep6258 = getelementptr i8, ptr %p6257, i64 -32
  %ld6259 = load i64, ptr %rgep6258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6259, ptr %slot1060, align 8
  %v6260 = load i64, ptr %slot1060, align 8
  %op6261 = sub i64 %v6260, 1
  store i64 %op6261, ptr %slot1061, align 8
  %v6262 = load i64, ptr %slot1061, align 8
  %cmp6263 = icmp eq i64 %v6262, 0
  %cv6264 = zext i1 %cmp6263 to i32
  store i32 %cv6264, ptr %slot1062, align 8
  %v6265 = load i32, ptr %slot1062, align 8
  %cv6266 = zext i32 %v6265 to i64
  %cond6267 = icmp ne i64 %cv6266, 0
  br i1 %cond6267, label %bb_rcglast1468, label %bb_rcgdec1468
bb_rcglast1468:
  %v6268 = load i64, ptr %slot1053, align 8
  %op6269 = sub i64 %v6268, 24
  store i64 %op6269, ptr %slot1063, align 8
  %v6270 = load i64, ptr %slot1053, align 8
  %p6271 = inttoptr i64 %v6270 to ptr
  %rgep6272 = getelementptr i8, ptr %p6271, i64 -24
  %ld6273 = load i64, ptr %rgep6272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6273, ptr %slot1064, align 8
  %v6274 = load i64, ptr %slot1064, align 8
  %cmp6275 = icmp ne i64 %v6274, 0
  %cv6276 = zext i1 %cmp6275 to i32
  store i32 %cv6276, ptr %slot1065, align 8
  %v6277 = load i32, ptr %slot1065, align 8
  %cv6278 = zext i32 %v6277 to i64
  %cond6279 = icmp ne i64 %cv6278, 0
  br i1 %cond6279, label %bb_rcgdec1468, label %bb_rcgslow1468
bb_rcgslow1468:
  %v6280 = load i64, ptr %slot1052, align 8
  %v6281 = load i64, ptr %slot1035, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v6280, i64 %v6281) nomerge, !dbg !196
  br label %bb_rcgdone1468
bb_rcgdec1468:
  %v6282 = load i64, ptr %slot1061, align 8
  %v6283 = load i64, ptr %slot1053, align 8
  %p6284 = inttoptr i64 %v6283 to ptr
  %rgep6285 = getelementptr i8, ptr %p6284, i64 -32
  store i64 %v6282, ptr %rgep6285, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1468
bb_rcgclear1468:
  %v6286 = load i64, ptr %slot1035, align 8
  %p6287 = inttoptr i64 %v6286 to ptr
  store i64 0, ptr %p6287, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1468
bb_rcgdone1468:
  br label %bb_rcslotdone1437
bb_rcslotdone1437:
  %v6288 = load i64, ptr %slot36, align 8
  store i64 %v6288, ptr %slot1066, align 8
  %v6289 = load i64, ptr %slot27, align 8
  store i64 %v6289, ptr %slot1067, align 8
  %v6290 = load i64, ptr %slot1067, align 8
  %v6291 = load i64, ptr %slot1066, align 8
  %p6292 = inttoptr i64 %v6290 to ptr
  %p6293 = inttoptr i64 %v6291 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6293, ptr %p6292, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6294 = load i64, ptr %slot18, align 8
  %p6295 = inttoptr i64 %v6294 to ptr
  store i32 0, ptr %p6295, align 4, !alias.scope !3, !noalias !4
  %v6296 = load i64, ptr %slot7, align 8
  %p6297 = inttoptr i64 %v6296 to ptr
  store i32 2, ptr %p6297, align 4, !alias.scope !3, !noalias !4
  %v6298 = load i64, ptr %slot19, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  %ld6300 = load i32, ptr %p6299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6300, ptr %slot1068, align 8
  %v6301 = load i32, ptr %slot1068, align 8
  %v6302 = load i64, ptr %slot7, align 8
  %p6303 = inttoptr i64 %v6302 to ptr
  store i32 %v6301, ptr %p6303, align 4, !alias.scope !3, !noalias !4
  %v6304 = load i64, ptr %slot6, align 8
  %p6305 = inttoptr i64 %v6304 to ptr
  store i32 1, ptr %p6305, align 4, !alias.scope !3, !noalias !4
  %v6306 = load i64, ptr %slot36, align 8
  %p6307 = inttoptr i64 %v6306 to ptr
  %ld6308 = load i64, ptr %p6307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6308, ptr %slot1069, align 8
  %v6309 = load i64, ptr %slot1069, align 8
  %v6310 = load i64, ptr %slot39, align 8
  %p6311 = inttoptr i64 %v6310 to ptr
  store i64 %v6309, ptr %p6311, align 8, !alias.scope !3, !noalias !4
  %v6312 = load i64, ptr %slot40, align 8
  %p6313 = inttoptr i64 %v6312 to ptr
  store i64 0, ptr %p6313, align 8, !alias.scope !3, !noalias !4
  %v6314 = load i64, ptr %slot40, align 8
  %p6315 = inttoptr i64 %v6314 to ptr
  %ld6316 = load i64, ptr %p6315, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6316, ptr %slot1070, align 8
  %v6317 = load i64, ptr %slot1070, align 8
  %cmp6318 = icmp sge i64 %v6317, 0
  %cv6319 = zext i1 %cmp6318 to i64
  store i64 %cv6319, ptr %slot1071, align 8
  %v6320 = load i64, ptr %slot1071, align 8
  %cond6321 = icmp ne i64 %v6320, 0
  br i1 %cond6321, label %bb_success1482, label %bb_failed1482
bb_failed1482:
  %v6322 = load i64, ptr %slot1, align 8
  %p6323 = inttoptr i64 %v6322 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p6323) nomerge, !dbg !198
  unreachable
bb_success1482:
  %v6324 = load i64, ptr %slot46, align 8
  %p6325 = inttoptr i64 %v6324 to ptr
  %p6326 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v6327 = load i64, ptr %slot1070, align 8
  %call6328 = call ptr @myl_native_list_new(ptr %p6325, ptr %p6326, i64 %v6327) nomerge, !dbg !198
  %calladdr6329 = ptrtoint ptr %call6328 to i64
  store i64 %calladdr6329, ptr %slot1072, align 8
  %v6330 = load i64, ptr %slot1072, align 8
  %cond6331 = icmp ne i64 %v6330, 0
  br i1 %cond6331, label %bb_success1484, label %bb_failed1484
bb_failed1484:
  %v6332 = load i64, ptr %slot1, align 8
  %p6333 = inttoptr i64 %v6332 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6333) nomerge, !dbg !198
  unreachable
bb_success1484:
  %v6334 = load i64, ptr %slot1072, align 8
  %v6335 = load i64, ptr %slot40, align 8
  %p6336 = inttoptr i64 %v6335 to ptr
  store i64 %v6334, ptr %p6336, align 8, !alias.scope !3, !noalias !4
  %v6337 = load i64, ptr %slot40, align 8
  %p6338 = inttoptr i64 %v6337 to ptr
  %ld6339 = load i64, ptr %p6338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6339, ptr %slot1073, align 8
  %v6340 = load i64, ptr %slot1073, align 8
  %v6341 = load i64, ptr %slot25, align 8
  %p6342 = inttoptr i64 %v6341 to ptr
  store i64 %v6340, ptr %p6342, align 8, !alias.scope !3, !noalias !4
  %v6343 = load i64, ptr %slot25, align 8
  store i64 %v6343, ptr %slot1074, align 8
  %v6344 = load i64, ptr %slot27, align 8
  store i64 %v6344, ptr %slot1075, align 8
  %v6345 = load i64, ptr %slot1074, align 8
  %v6346 = load i64, ptr %slot1075, align 8
  %p6347 = inttoptr i64 %v6345 to ptr
  %p6348 = inttoptr i64 %v6346 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6348, ptr %p6347, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6349 = load i64, ptr %slot19, align 8
  %p6350 = inttoptr i64 %v6349 to ptr
  store i32 2, ptr %p6350, align 4, !alias.scope !3, !noalias !4
  %v6351 = load i64, ptr %slot18, align 8
  %p6352 = inttoptr i64 %v6351 to ptr
  store i32 1, ptr %p6352, align 4, !alias.scope !3, !noalias !4
  %v6353 = load i64, ptr %slot22, align 8
  store i64 %v6353, ptr %slot1076, align 8
  %v6354 = load i64, ptr %slot27, align 8
  store i64 %v6354, ptr %slot1077, align 8
  %v6355 = load i64, ptr %slot1077, align 8
  %v6356 = load i64, ptr %slot1076, align 8
  %p6357 = inttoptr i64 %v6355 to ptr
  %p6358 = inttoptr i64 %v6356 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6358, ptr %p6357, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6359 = load i64, ptr %slot15, align 8
  %p6360 = inttoptr i64 %v6359 to ptr
  store i32 2, ptr %p6360, align 4, !alias.scope !3, !noalias !4
  %v6361 = load i64, ptr %slot19, align 8
  %p6362 = inttoptr i64 %v6361 to ptr
  %ld6363 = load i32, ptr %p6362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6363, ptr %slot1078, align 8
  %v6364 = load i32, ptr %slot1078, align 8
  %v6365 = load i64, ptr %slot15, align 8
  %p6366 = inttoptr i64 %v6365 to ptr
  store i32 %v6364, ptr %p6366, align 4, !alias.scope !3, !noalias !4
  %v6367 = load i64, ptr %slot18, align 8
  %p6368 = inttoptr i64 %v6367 to ptr
  store i32 0, ptr %p6368, align 4, !alias.scope !3, !noalias !4
  %v6369 = load i64, ptr %slot14, align 8
  %p6370 = inttoptr i64 %v6369 to ptr
  store i32 1, ptr %p6370, align 4, !alias.scope !3, !noalias !4
  %v6371 = load i64, ptr %slot1076, align 8
  %p6372 = inttoptr i64 %v6371 to ptr
  %ld6373 = load i64, ptr %p6372, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6373, ptr %slot1079, align 8
  %v6374 = load i64, ptr %slot1079, align 8
  %v6375 = load i64, ptr %slot40, align 8
  %p6376 = inttoptr i64 %v6375 to ptr
  store i64 %v6374, ptr %p6376, align 8, !alias.scope !3, !noalias !4
  %v6377 = load i64, ptr %slot40, align 8
  %p6378 = inttoptr i64 %v6377 to ptr
  %ld6379 = load i64, ptr %p6378, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6379, ptr %slot1080, align 8
  %v6380 = load i64, ptr %slot1080, align 8
  %v6381 = load i64, ptr %slot25, align 8
  %p6382 = inttoptr i64 %v6381 to ptr
  store i64 %v6380, ptr %p6382, align 8, !alias.scope !3, !noalias !4
  %v6383 = load i64, ptr %slot25, align 8
  store i64 %v6383, ptr %slot1081, align 8
  %v6384 = load i64, ptr %slot14, align 8
  %p6385 = inttoptr i64 %v6384 to ptr
  %ld6386 = load i32, ptr %p6385, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6386, ptr %slot1082, align 8
  %v6387 = load i64, ptr %slot15, align 8
  %p6388 = inttoptr i64 %v6387 to ptr
  %ld6389 = load i32, ptr %p6388, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6389, ptr %slot1083, align 8
  %v6390 = load i32, ptr %slot1083, align 8
  %op6391 = and i32 %v6390, 24
  store i32 %op6391, ptr %slot1083, align 8
  %v6392 = load i32, ptr %slot1083, align 8
  %cmp6393 = icmp eq i32 %v6392, 0
  %cv6394 = zext i1 %cmp6393 to i32
  store i32 %cv6394, ptr %slot1084, align 8
  %v6395 = load i32, ptr %slot1082, align 8
  %v6396 = load i32, ptr %slot1084, align 8
  %op6397 = and i32 %v6395, %v6396
  store i32 %op6397, ptr %slot1085, align 8
  %v6398 = load i32, ptr %slot1085, align 8
  %cv6399 = zext i32 %v6398 to i64
  %cond6400 = icmp ne i64 %cv6399, 0
  br i1 %cond6400, label %bb_rcprivateown1507, label %bb_rcprivateloan1507
bb_rcprivateown1507:
  %v6401 = load i64, ptr %slot27, align 8
  store i64 %v6401, ptr %slot1086, align 8
  %v6402 = load i64, ptr %slot47, align 8
  store i64 %v6402, ptr %slot1087, align 8
  %v6403 = load i64, ptr %slot1081, align 8
  %v6404 = load i64, ptr %slot1086, align 8
  %op6405 = sub i64 %v6403, %v6404
  store i64 %op6405, ptr %slot1088, align 8
  %v6406 = load i64, ptr %slot1086, align 8
  %v6407 = load i64, ptr %slot1081, align 8
  %op6408 = sub i64 %v6406, %v6407
  store i64 %op6408, ptr %slot1089, align 8
  %v6409 = load i64, ptr %slot1088, align 8
  %cmp6410 = icmp ult i64 %v6409, 8
  %cv6411 = zext i1 %cmp6410 to i32
  store i32 %cv6411, ptr %slot1090, align 8
  %v6412 = load i64, ptr %slot1089, align 8
  %cmp6413 = icmp ult i64 %v6412, 8
  %cv6414 = zext i1 %cmp6413 to i32
  store i32 %cv6414, ptr %slot1091, align 8
  %v6415 = load i32, ptr %slot1090, align 8
  %v6416 = load i32, ptr %slot1091, align 8
  %op6417 = or i32 %v6415, %v6416
  store i32 %op6417, ptr %slot1092, align 8
  %v6418 = load i32, ptr %slot1092, align 8
  %cv6419 = zext i32 %v6418 to i64
  %cond6420 = icmp ne i64 %cv6419, 0
  br i1 %cond6420, label %bb_rcmoveslow1510, label %bb_rcmovecheck1510
bb_rcmovecheck1510:
  %v6421 = load i64, ptr %slot1081, align 8
  %p6423 = inttoptr i64 %v6421 to ptr
  %gep6424 = getelementptr i8, ptr %p6423, i64 0
  %op6422 = ptrtoint ptr %gep6424 to i64
  store i64 %op6422, ptr %slot1093, align 8
  %v6425 = load i64, ptr %slot1093, align 8
  %p6426 = inttoptr i64 %v6425 to ptr
  %ld6427 = load i64, ptr %p6426, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6427, ptr %slot1094, align 8
  %v6428 = load i64, ptr %slot1094, align 8
  %cmp6429 = icmp ne i64 %v6428, 0
  %cv6430 = zext i1 %cmp6429 to i32
  store i32 %cv6430, ptr %slot1095, align 8
  %v6431 = load i32, ptr %slot1095, align 8
  %cv6432 = zext i32 %v6431 to i64
  %cond6433 = icmp ne i64 %cv6432, 0
  br i1 %cond6433, label %bb_rcmoveheader1518, label %bb_rcmovenext1518
bb_rcmoveheader1518:
  %v6434 = load i64, ptr %slot1094, align 8
  %op6435 = sub i64 %v6434, 16
  store i64 %op6435, ptr %slot1096, align 8
  %v6436 = load i64, ptr %slot1094, align 8
  %p6437 = inttoptr i64 %v6436 to ptr
  %rgep6438 = getelementptr i8, ptr %p6437, i64 -16
  %ld6439 = load i64, ptr %rgep6438, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6439, ptr %slot1097, align 8
  %v6440 = load i64, ptr %slot1097, align 8
  %op6441 = and i64 %v6440, 5764607523034234881
  store i64 %op6441, ptr %slot1098, align 8
  %v6442 = load i64, ptr %slot1098, align 8
  %cmp6443 = icmp ne i64 %v6442, 0
  %cv6444 = zext i1 %cmp6443 to i32
  store i32 %cv6444, ptr %slot1099, align 8
  %v6445 = load i32, ptr %slot1099, align 8
  %cv6446 = zext i32 %v6445 to i64
  %cond6447 = icmp ne i64 %cv6446, 0
  br i1 %cond6447, label %bb_rcmoveslow1510, label %bb_rcmovenext1518
bb_rcmovenext1518:
  %v6448 = load i64, ptr %slot1081, align 8
  %v6449 = load i64, ptr %slot1086, align 8
  %p6450 = inttoptr i64 %v6448 to ptr
  %p6451 = inttoptr i64 %v6449 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6451, ptr %p6450, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6452 = load i64, ptr %slot1081, align 8
  %p6453 = inttoptr i64 %v6452 to ptr
  store i64 0, ptr %p6453, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1510
bb_rcmoveslow1510:
  %v6454 = load i64, ptr %slot46, align 8
  %v6455 = load i64, ptr %slot1086, align 8
  %v6456 = load i64, ptr %slot1081, align 8
  %v6457 = load i64, ptr %slot1087, align 8
  %cv6458 = trunc i64 %v6457 to i32
  %call6459 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v6454, i64 %v6455, i64 %v6456, i32 %cv6458) nomerge, !dbg !200
  store i32 %call6459, ptr %slot1100, align 8
  %v6460 = load i32, ptr %slot1100, align 8
  %cv6461 = zext i32 %v6460 to i64
  %cond6462 = icmp ne i64 %cv6461, 0
  br i1 %cond6462, label %bb_rcsuccess1525, label %bb_rcfailure1525
bb_rcfailure1525:
  %v6463 = load i64, ptr %slot46, align 8
  %p6464 = inttoptr i64 %v6463 to ptr
  %call6465 = call i32 @myl_rc_take_failure(ptr %p6464) nomerge, !dbg !200
  store i32 %call6465, ptr %slot1101, align 8
  %v6466 = load i64, ptr %slot1, align 8
  %p6467 = inttoptr i64 %v6466 to ptr
  %v6468 = load i32, ptr %slot1101, align 8
  %call6469 = call i32 @myl_qbe_rc_status(ptr %p6467, i32 %v6468) nomerge, !dbg !200
  store i32 %call6469, ptr %slot1102, align 8
  br label %bb_failure
bb_rcsuccess1525:
  br label %bb_rcmoved1510
bb_rcmoved1510:
  %v6470 = load i64, ptr %slot14, align 8
  %p6471 = inttoptr i64 %v6470 to ptr
  store i32 0, ptr %p6471, align 4, !alias.scope !3, !noalias !4
  %v6472 = load i64, ptr %slot19, align 8
  %p6473 = inttoptr i64 %v6472 to ptr
  store i32 2, ptr %p6473, align 4, !alias.scope !3, !noalias !4
  %v6474 = load i64, ptr %slot18, align 8
  %p6475 = inttoptr i64 %v6474 to ptr
  store i32 1, ptr %p6475, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1507
bb_rcprivateloan1507:
  %v6476 = load i64, ptr %slot14, align 8
  %p6477 = inttoptr i64 %v6476 to ptr
  %ld6478 = load i32, ptr %p6477, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6478, ptr %slot1103, align 8
  %v6479 = load i64, ptr %slot15, align 8
  %p6480 = inttoptr i64 %v6479 to ptr
  %ld6481 = load i32, ptr %p6480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6481, ptr %slot1104, align 8
  %v6482 = load i32, ptr %slot1104, align 8
  %cmp6483 = icmp eq i32 %v6482, 16
  %cv6484 = zext i1 %cmp6483 to i32
  store i32 %cv6484, ptr %slot1105, align 8
  %v6485 = load i32, ptr %slot1105, align 8
  %v6486 = load i32, ptr %slot1103, align 8
  %op6487 = and i32 %v6485, %v6486
  store i32 %op6487, ptr %slot1105, align 8
  %v6488 = load i32, ptr %slot1105, align 8
  %cv6489 = zext i32 %v6488 to i64
  %cond6490 = icmp ne i64 %cv6489, 0
  br i1 %cond6490, label %bb_rcprivatemove1507, label %bb_rcprivatenew1507
bb_rcprivatemove1507:
  %v6491 = load i64, ptr %slot27, align 8
  store i64 %v6491, ptr %slot1106, align 8
  %v6492 = load i64, ptr %slot1081, align 8
  %v6493 = load i64, ptr %slot1106, align 8
  %p6494 = inttoptr i64 %v6492 to ptr
  %p6495 = inttoptr i64 %v6493 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6495, ptr %p6494, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6496 = load i64, ptr %slot1081, align 8
  %p6497 = inttoptr i64 %v6496 to ptr
  store i64 0, ptr %p6497, align 8, !alias.scope !3, !noalias !4
  %v6498 = load i64, ptr %slot19, align 8
  %p6499 = inttoptr i64 %v6498 to ptr
  store i32 2, ptr %p6499, align 4, !alias.scope !3, !noalias !4
  %v6500 = load i64, ptr %slot19, align 8
  %p6501 = inttoptr i64 %v6500 to ptr
  store i32 16, ptr %p6501, align 4, !alias.scope !3, !noalias !4
  %v6502 = load i64, ptr %slot18, align 8
  %p6503 = inttoptr i64 %v6502 to ptr
  store i32 1, ptr %p6503, align 4, !alias.scope !3, !noalias !4
  %v6504 = load i64, ptr %slot14, align 8
  %p6505 = inttoptr i64 %v6504 to ptr
  store i32 0, ptr %p6505, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1507
bb_rcprivatenew1507:
  %v6506 = load i64, ptr %slot27, align 8
  store i64 %v6506, ptr %slot1107, align 8
  %v6507 = load i64, ptr %slot1081, align 8
  %p6508 = inttoptr i64 %v6507 to ptr
  %ld6509 = load i64, ptr %p6508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6509, ptr %slot1108, align 8
  %v6510 = load i64, ptr %slot1108, align 8
  %cmp6511 = icmp ne i64 %v6510, 0
  %cv6512 = zext i1 %cmp6511 to i32
  store i32 %cv6512, ptr %slot1109, align 8
  %v6513 = load i32, ptr %slot1109, align 8
  %cv6514 = zext i32 %v6513 to i64
  %cond6515 = icmp ne i64 %cv6514, 0
  br i1 %cond6515, label %bb_rcgnn1543, label %bb_rcgstore1543
bb_rcgnn1543:
  %v6516 = load i64, ptr %slot1108, align 8
  %op6517 = sub i64 %v6516, 16
  store i64 %op6517, ptr %slot1110, align 8
  %v6518 = load i64, ptr %slot1108, align 8
  %p6519 = inttoptr i64 %v6518 to ptr
  %rgep6520 = getelementptr i8, ptr %p6519, i64 -16
  %ld6521 = load i64, ptr %rgep6520, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6521, ptr %slot1111, align 8
  %v6522 = load i64, ptr %slot1111, align 8
  %op6523 = and i64 %v6522, 4611686018427387906
  store i64 %op6523, ptr %slot1112, align 8
  %v6524 = load i64, ptr %slot1112, align 8
  %cmp6525 = icmp ne i64 %v6524, 0
  %cv6526 = zext i1 %cmp6525 to i32
  store i32 %cv6526, ptr %slot1113, align 8
  %v6527 = load i32, ptr %slot1113, align 8
  %cv6528 = zext i32 %v6527 to i64
  %cond6529 = icmp ne i64 %cv6528, 0
  br i1 %cond6529, label %bb_rcgstore1543, label %bb_rcginc1543
bb_rcginc1543:
  %v6530 = load i64, ptr %slot1108, align 8
  %op6531 = sub i64 %v6530, 24
  store i64 %op6531, ptr %slot1114, align 8
  %v6532 = load i64, ptr %slot1108, align 8
  %p6533 = inttoptr i64 %v6532 to ptr
  %rgep6534 = getelementptr i8, ptr %p6533, i64 -24
  %ld6535 = load i64, ptr %rgep6534, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6535, ptr %slot1115, align 8
  %v6536 = load i64, ptr %slot1115, align 8
  %op6537 = add i64 %v6536, 1
  store i64 %op6537, ptr %slot1116, align 8
  %v6538 = load i64, ptr %slot1116, align 8
  %cmp6539 = icmp eq i64 %v6538, 0
  %cv6540 = zext i1 %cmp6539 to i32
  store i32 %cv6540, ptr %slot1117, align 8
  %v6541 = load i32, ptr %slot1117, align 8
  %cv6542 = zext i32 %v6541 to i64
  %cond6543 = icmp ne i64 %cv6542, 0
  br i1 %cond6543, label %bb_rcglimit1543, label %bb_rcgcapacity1543
bb_rcglimit1543:
  %v6544 = load i64, ptr %slot1, align 8
  %p6545 = inttoptr i64 %v6544 to ptr
  %call6546 = call i32 @myl_qbe_rc_status(ptr %p6545, i32 2) nomerge, !dbg !200
  store i32 %call6546, ptr %slot1118, align 8
  br label %bb_failure
bb_rcgcapacity1543:
  %v6547 = load i64, ptr %slot1116, align 8
  %v6548 = load i64, ptr %slot1108, align 8
  %p6549 = inttoptr i64 %v6548 to ptr
  %rgep6550 = getelementptr i8, ptr %p6549, i64 -24
  store i64 %v6547, ptr %rgep6550, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1543
bb_rcgstore1543:
  %v6551 = load i64, ptr %slot1108, align 8
  %v6552 = load i64, ptr %slot1107, align 8
  %p6553 = inttoptr i64 %v6552 to ptr
  store i64 %v6551, ptr %p6553, align 8, !alias.scope !3, !noalias !4
  %v6554 = load i64, ptr %slot19, align 8
  %p6555 = inttoptr i64 %v6554 to ptr
  store i32 2, ptr %p6555, align 4, !alias.scope !3, !noalias !4
  %v6556 = load i64, ptr %slot19, align 8
  %p6557 = inttoptr i64 %v6556 to ptr
  store i32 16, ptr %p6557, align 4, !alias.scope !3, !noalias !4
  %v6558 = load i64, ptr %slot18, align 8
  %p6559 = inttoptr i64 %v6558 to ptr
  store i32 1, ptr %p6559, align 4, !alias.scope !3, !noalias !4
  %v6560 = load i64, ptr %slot14, align 8
  %p6561 = inttoptr i64 %v6560 to ptr
  %ld6562 = load i32, ptr %p6561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6562, ptr %slot1119, align 8
  %v6563 = load i32, ptr %slot1119, align 8
  %cv6564 = zext i32 %v6563 to i64
  %cond6565 = icmp ne i64 %cv6564, 0
  br i1 %cond6565, label %bb_rcslotdrop1559, label %bb_rcslotdone1559
bb_rcslotdrop1559:
  %v6566 = load i64, ptr %slot14, align 8
  %p6567 = inttoptr i64 %v6566 to ptr
  store i32 0, ptr %p6567, align 4, !alias.scope !3, !noalias !4
  %v6568 = load i64, ptr %slot22, align 8
  store i64 %v6568, ptr %slot1120, align 8
  %v6569 = load i64, ptr %slot15, align 8
  %p6570 = inttoptr i64 %v6569 to ptr
  %ld6571 = load i32, ptr %p6570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6571, ptr %slot1121, align 8
  %v6572 = load i32, ptr %slot1121, align 8
  %op6573 = and i32 %v6572, 28
  store i32 %op6573, ptr %slot1122, align 8
  %v6574 = load i32, ptr %slot1122, align 8
  %cv6575 = zext i32 %v6574 to i64
  %cond6576 = icmp ne i64 %cv6575, 0
  br i1 %cond6576, label %bb_rcslotrole1559, label %bb_rcslotowner1559
bb_rcslotrole1559:
  %v6577 = load i64, ptr %slot46, align 8
  store i64 %v6577, ptr %slot1123, align 8
  %v6578 = load i64, ptr %slot1120, align 8
  %p6579 = inttoptr i64 %v6578 to ptr
  %ld6580 = load i64, ptr %p6579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6580, ptr %slot1124, align 8
  %v6581 = load i64, ptr %slot1124, align 8
  %cmp6582 = icmp ne i64 %v6581, 0
  %cv6583 = zext i1 %cmp6582 to i32
  store i32 %cv6583, ptr %slot1125, align 8
  %v6584 = load i32, ptr %slot1125, align 8
  %cv6585 = zext i32 %v6584 to i64
  %cond6586 = icmp ne i64 %cv6585, 0
  br i1 %cond6586, label %bb_rcgnn1575, label %bb_rcgdone1575
bb_rcgnn1575:
  %v6587 = load i64, ptr %slot1124, align 8
  %op6588 = sub i64 %v6587, 16
  store i64 %op6588, ptr %slot1126, align 8
  %v6589 = load i64, ptr %slot1124, align 8
  %p6590 = inttoptr i64 %v6589 to ptr
  %rgep6591 = getelementptr i8, ptr %p6590, i64 -16
  %ld6592 = load i64, ptr %rgep6591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6592, ptr %slot1127, align 8
  %v6593 = load i64, ptr %slot1127, align 8
  %op6594 = and i64 %v6593, 4611686018427387906
  store i64 %op6594, ptr %slot1128, align 8
  %v6595 = load i64, ptr %slot1128, align 8
  %cmp6596 = icmp ne i64 %v6595, 0
  %cv6597 = zext i1 %cmp6596 to i32
  store i32 %cv6597, ptr %slot1129, align 8
  %v6598 = load i32, ptr %slot1129, align 8
  %cv6599 = zext i32 %v6598 to i64
  %cond6600 = icmp ne i64 %cv6599, 0
  br i1 %cond6600, label %bb_rcgclear1575, label %bb_rcgcounted1575
bb_rcgcounted1575:
  %v6601 = load i64, ptr %slot1124, align 8
  %op6602 = sub i64 %v6601, 24
  store i64 %op6602, ptr %slot1130, align 8
  %v6603 = load i64, ptr %slot1124, align 8
  %p6604 = inttoptr i64 %v6603 to ptr
  %rgep6605 = getelementptr i8, ptr %p6604, i64 -24
  %ld6606 = load i64, ptr %rgep6605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6606, ptr %slot1131, align 8
  %v6607 = load i64, ptr %slot1131, align 8
  %op6608 = sub i64 %v6607, 1
  store i64 %op6608, ptr %slot1132, align 8
  %v6609 = load i64, ptr %slot1132, align 8
  %cmp6610 = icmp eq i64 %v6609, 0
  %cv6611 = zext i1 %cmp6610 to i32
  store i32 %cv6611, ptr %slot1133, align 8
  %v6612 = load i32, ptr %slot1133, align 8
  %cv6613 = zext i32 %v6612 to i64
  %cond6614 = icmp ne i64 %cv6613, 0
  br i1 %cond6614, label %bb_rcglast1575, label %bb_rcgdec1575
bb_rcglast1575:
  %v6615 = load i64, ptr %slot1124, align 8
  %op6616 = sub i64 %v6615, 32
  store i64 %op6616, ptr %slot1134, align 8
  %v6617 = load i64, ptr %slot1124, align 8
  %p6618 = inttoptr i64 %v6617 to ptr
  %rgep6619 = getelementptr i8, ptr %p6618, i64 -32
  %ld6620 = load i64, ptr %rgep6619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6620, ptr %slot1135, align 8
  %v6621 = load i64, ptr %slot1135, align 8
  %cmp6622 = icmp ne i64 %v6621, 0
  %cv6623 = zext i1 %cmp6622 to i32
  store i32 %cv6623, ptr %slot1136, align 8
  %v6624 = load i32, ptr %slot1136, align 8
  %cv6625 = zext i32 %v6624 to i64
  %cond6626 = icmp ne i64 %cv6625, 0
  br i1 %cond6626, label %bb_rcgdec1575, label %bb_rcgslow1575
bb_rcgslow1575:
  %v6627 = load i64, ptr %slot1123, align 8
  %v6628 = load i64, ptr %slot1120, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v6627, i64 %v6628) nomerge, !dbg !200
  br label %bb_rcgdone1575
bb_rcgdec1575:
  %v6629 = load i64, ptr %slot1132, align 8
  %v6630 = load i64, ptr %slot1124, align 8
  %p6631 = inttoptr i64 %v6630 to ptr
  %rgep6632 = getelementptr i8, ptr %p6631, i64 -24
  store i64 %v6629, ptr %rgep6632, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1575
bb_rcgclear1575:
  %v6633 = load i64, ptr %slot1120, align 8
  %p6634 = inttoptr i64 %v6633 to ptr
  store i64 0, ptr %p6634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1575
bb_rcgdone1575:
  br label %bb_rcslotdone1559
bb_rcslotowner1559:
  %v6635 = load i64, ptr %slot46, align 8
  store i64 %v6635, ptr %slot1137, align 8
  %v6636 = load i64, ptr %slot1120, align 8
  %p6637 = inttoptr i64 %v6636 to ptr
  %ld6638 = load i64, ptr %p6637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6638, ptr %slot1138, align 8
  %v6639 = load i64, ptr %slot1138, align 8
  %cmp6640 = icmp ne i64 %v6639, 0
  %cv6641 = zext i1 %cmp6640 to i32
  store i32 %cv6641, ptr %slot1139, align 8
  %v6642 = load i32, ptr %slot1139, align 8
  %cv6643 = zext i32 %v6642 to i64
  %cond6644 = icmp ne i64 %cv6643, 0
  br i1 %cond6644, label %bb_rcgnn1590, label %bb_rcgdone1590
bb_rcgnn1590:
  %v6645 = load i64, ptr %slot1138, align 8
  %op6646 = sub i64 %v6645, 16
  store i64 %op6646, ptr %slot1140, align 8
  %v6647 = load i64, ptr %slot1138, align 8
  %p6648 = inttoptr i64 %v6647 to ptr
  %rgep6649 = getelementptr i8, ptr %p6648, i64 -16
  %ld6650 = load i64, ptr %rgep6649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6650, ptr %slot1141, align 8
  %v6651 = load i64, ptr %slot1141, align 8
  %op6652 = and i64 %v6651, 4611686018427387906
  store i64 %op6652, ptr %slot1142, align 8
  %v6653 = load i64, ptr %slot1142, align 8
  %cmp6654 = icmp ne i64 %v6653, 0
  %cv6655 = zext i1 %cmp6654 to i32
  store i32 %cv6655, ptr %slot1143, align 8
  %v6656 = load i32, ptr %slot1143, align 8
  %cv6657 = zext i32 %v6656 to i64
  %cond6658 = icmp ne i64 %cv6657, 0
  br i1 %cond6658, label %bb_rcgclear1590, label %bb_rcgcounted1590
bb_rcgcounted1590:
  %v6659 = load i64, ptr %slot1138, align 8
  %op6660 = sub i64 %v6659, 32
  store i64 %op6660, ptr %slot1144, align 8
  %v6661 = load i64, ptr %slot1138, align 8
  %p6662 = inttoptr i64 %v6661 to ptr
  %rgep6663 = getelementptr i8, ptr %p6662, i64 -32
  %ld6664 = load i64, ptr %rgep6663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6664, ptr %slot1145, align 8
  %v6665 = load i64, ptr %slot1145, align 8
  %op6666 = sub i64 %v6665, 1
  store i64 %op6666, ptr %slot1146, align 8
  %v6667 = load i64, ptr %slot1146, align 8
  %cmp6668 = icmp eq i64 %v6667, 0
  %cv6669 = zext i1 %cmp6668 to i32
  store i32 %cv6669, ptr %slot1147, align 8
  %v6670 = load i32, ptr %slot1147, align 8
  %cv6671 = zext i32 %v6670 to i64
  %cond6672 = icmp ne i64 %cv6671, 0
  br i1 %cond6672, label %bb_rcglast1590, label %bb_rcgdec1590
bb_rcglast1590:
  %v6673 = load i64, ptr %slot1138, align 8
  %op6674 = sub i64 %v6673, 24
  store i64 %op6674, ptr %slot1148, align 8
  %v6675 = load i64, ptr %slot1138, align 8
  %p6676 = inttoptr i64 %v6675 to ptr
  %rgep6677 = getelementptr i8, ptr %p6676, i64 -24
  %ld6678 = load i64, ptr %rgep6677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6678, ptr %slot1149, align 8
  %v6679 = load i64, ptr %slot1149, align 8
  %cmp6680 = icmp ne i64 %v6679, 0
  %cv6681 = zext i1 %cmp6680 to i32
  store i32 %cv6681, ptr %slot1150, align 8
  %v6682 = load i32, ptr %slot1150, align 8
  %cv6683 = zext i32 %v6682 to i64
  %cond6684 = icmp ne i64 %cv6683, 0
  br i1 %cond6684, label %bb_rcgdec1590, label %bb_rcgslow1590
bb_rcgslow1590:
  %v6685 = load i64, ptr %slot1137, align 8
  %v6686 = load i64, ptr %slot1120, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v6685, i64 %v6686) nomerge, !dbg !200
  br label %bb_rcgdone1590
bb_rcgdec1590:
  %v6687 = load i64, ptr %slot1146, align 8
  %v6688 = load i64, ptr %slot1138, align 8
  %p6689 = inttoptr i64 %v6688 to ptr
  %rgep6690 = getelementptr i8, ptr %p6689, i64 -32
  store i64 %v6687, ptr %rgep6690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1590
bb_rcgclear1590:
  %v6691 = load i64, ptr %slot1120, align 8
  %p6692 = inttoptr i64 %v6691 to ptr
  store i64 0, ptr %p6692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1590
bb_rcgdone1590:
  br label %bb_rcslotdone1559
bb_rcslotdone1559:
  br label %bb_rcprivateprepared1507
bb_rcprivateprepared1507:
  %v6693 = load i64, ptr %slot8, align 8
  %p6694 = inttoptr i64 %v6693 to ptr
  %ld6695 = load i32, ptr %p6694, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6695, ptr %slot1151, align 8
  %v6696 = load i32, ptr %slot1151, align 8
  %cv6697 = zext i32 %v6696 to i64
  %cond6698 = icmp ne i64 %cv6697, 0
  br i1 %cond6698, label %bb_rcslotdrop1597, label %bb_rcslotdone1597
bb_rcslotdrop1597:
  %v6699 = load i64, ptr %slot8, align 8
  %p6700 = inttoptr i64 %v6699 to ptr
  store i32 0, ptr %p6700, align 4, !alias.scope !3, !noalias !4
  %v6701 = load i64, ptr %slot37, align 8
  store i64 %v6701, ptr %slot1152, align 8
  %v6702 = load i64, ptr %slot9, align 8
  %p6703 = inttoptr i64 %v6702 to ptr
  %ld6704 = load i32, ptr %p6703, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6704, ptr %slot1153, align 8
  %v6705 = load i32, ptr %slot1153, align 8
  %op6706 = and i32 %v6705, 28
  store i32 %op6706, ptr %slot1154, align 8
  %v6707 = load i32, ptr %slot1154, align 8
  %cv6708 = zext i32 %v6707 to i64
  %cond6709 = icmp ne i64 %cv6708, 0
  br i1 %cond6709, label %bb_rcslotrole1597, label %bb_rcslotowner1597
bb_rcslotrole1597:
  %v6710 = load i64, ptr %slot46, align 8
  store i64 %v6710, ptr %slot1155, align 8
  %v6711 = load i64, ptr %slot1152, align 8
  %p6712 = inttoptr i64 %v6711 to ptr
  %ld6713 = load i64, ptr %p6712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6713, ptr %slot1156, align 8
  %v6714 = load i64, ptr %slot1156, align 8
  %cmp6715 = icmp ne i64 %v6714, 0
  %cv6716 = zext i1 %cmp6715 to i32
  store i32 %cv6716, ptr %slot1157, align 8
  %v6717 = load i32, ptr %slot1157, align 8
  %cv6718 = zext i32 %v6717 to i64
  %cond6719 = icmp ne i64 %cv6718, 0
  br i1 %cond6719, label %bb_rcgnn1613, label %bb_rcgdone1613
bb_rcgnn1613:
  %v6720 = load i64, ptr %slot1156, align 8
  %op6721 = sub i64 %v6720, 16
  store i64 %op6721, ptr %slot1158, align 8
  %v6722 = load i64, ptr %slot1156, align 8
  %p6723 = inttoptr i64 %v6722 to ptr
  %rgep6724 = getelementptr i8, ptr %p6723, i64 -16
  %ld6725 = load i64, ptr %rgep6724, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6725, ptr %slot1159, align 8
  %v6726 = load i64, ptr %slot1159, align 8
  %op6727 = and i64 %v6726, 4611686018427387906
  store i64 %op6727, ptr %slot1160, align 8
  %v6728 = load i64, ptr %slot1160, align 8
  %cmp6729 = icmp ne i64 %v6728, 0
  %cv6730 = zext i1 %cmp6729 to i32
  store i32 %cv6730, ptr %slot1161, align 8
  %v6731 = load i32, ptr %slot1161, align 8
  %cv6732 = zext i32 %v6731 to i64
  %cond6733 = icmp ne i64 %cv6732, 0
  br i1 %cond6733, label %bb_rcgclear1613, label %bb_rcgcounted1613
bb_rcgcounted1613:
  %v6734 = load i64, ptr %slot1156, align 8
  %op6735 = sub i64 %v6734, 24
  store i64 %op6735, ptr %slot1162, align 8
  %v6736 = load i64, ptr %slot1156, align 8
  %p6737 = inttoptr i64 %v6736 to ptr
  %rgep6738 = getelementptr i8, ptr %p6737, i64 -24
  %ld6739 = load i64, ptr %rgep6738, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6739, ptr %slot1163, align 8
  %v6740 = load i64, ptr %slot1163, align 8
  %op6741 = sub i64 %v6740, 1
  store i64 %op6741, ptr %slot1164, align 8
  %v6742 = load i64, ptr %slot1164, align 8
  %cmp6743 = icmp eq i64 %v6742, 0
  %cv6744 = zext i1 %cmp6743 to i32
  store i32 %cv6744, ptr %slot1165, align 8
  %v6745 = load i32, ptr %slot1165, align 8
  %cv6746 = zext i32 %v6745 to i64
  %cond6747 = icmp ne i64 %cv6746, 0
  br i1 %cond6747, label %bb_rcglast1613, label %bb_rcgdec1613
bb_rcglast1613:
  %v6748 = load i64, ptr %slot1156, align 8
  %op6749 = sub i64 %v6748, 32
  store i64 %op6749, ptr %slot1166, align 8
  %v6750 = load i64, ptr %slot1156, align 8
  %p6751 = inttoptr i64 %v6750 to ptr
  %rgep6752 = getelementptr i8, ptr %p6751, i64 -32
  %ld6753 = load i64, ptr %rgep6752, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6753, ptr %slot1167, align 8
  %v6754 = load i64, ptr %slot1167, align 8
  %cmp6755 = icmp ne i64 %v6754, 0
  %cv6756 = zext i1 %cmp6755 to i32
  store i32 %cv6756, ptr %slot1168, align 8
  %v6757 = load i32, ptr %slot1168, align 8
  %cv6758 = zext i32 %v6757 to i64
  %cond6759 = icmp ne i64 %cv6758, 0
  br i1 %cond6759, label %bb_rcgdec1613, label %bb_rcgslow1613
bb_rcgslow1613:
  %v6760 = load i64, ptr %slot1155, align 8
  %v6761 = load i64, ptr %slot1152, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v6760, i64 %v6761) nomerge, !dbg !200
  br label %bb_rcgdone1613
bb_rcgdec1613:
  %v6762 = load i64, ptr %slot1164, align 8
  %v6763 = load i64, ptr %slot1156, align 8
  %p6764 = inttoptr i64 %v6763 to ptr
  %rgep6765 = getelementptr i8, ptr %p6764, i64 -24
  store i64 %v6762, ptr %rgep6765, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1613
bb_rcgclear1613:
  %v6766 = load i64, ptr %slot1152, align 8
  %p6767 = inttoptr i64 %v6766 to ptr
  store i64 0, ptr %p6767, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1613
bb_rcgdone1613:
  br label %bb_rcslotdone1597
bb_rcslotowner1597:
  %v6768 = load i64, ptr %slot46, align 8
  store i64 %v6768, ptr %slot1169, align 8
  %v6769 = load i64, ptr %slot1152, align 8
  %p6770 = inttoptr i64 %v6769 to ptr
  %ld6771 = load i64, ptr %p6770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6771, ptr %slot1170, align 8
  %v6772 = load i64, ptr %slot1170, align 8
  %cmp6773 = icmp ne i64 %v6772, 0
  %cv6774 = zext i1 %cmp6773 to i32
  store i32 %cv6774, ptr %slot1171, align 8
  %v6775 = load i32, ptr %slot1171, align 8
  %cv6776 = zext i32 %v6775 to i64
  %cond6777 = icmp ne i64 %cv6776, 0
  br i1 %cond6777, label %bb_rcgnn1628, label %bb_rcgdone1628
bb_rcgnn1628:
  %v6778 = load i64, ptr %slot1170, align 8
  %op6779 = sub i64 %v6778, 16
  store i64 %op6779, ptr %slot1172, align 8
  %v6780 = load i64, ptr %slot1170, align 8
  %p6781 = inttoptr i64 %v6780 to ptr
  %rgep6782 = getelementptr i8, ptr %p6781, i64 -16
  %ld6783 = load i64, ptr %rgep6782, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6783, ptr %slot1173, align 8
  %v6784 = load i64, ptr %slot1173, align 8
  %op6785 = and i64 %v6784, 4611686018427387906
  store i64 %op6785, ptr %slot1174, align 8
  %v6786 = load i64, ptr %slot1174, align 8
  %cmp6787 = icmp ne i64 %v6786, 0
  %cv6788 = zext i1 %cmp6787 to i32
  store i32 %cv6788, ptr %slot1175, align 8
  %v6789 = load i32, ptr %slot1175, align 8
  %cv6790 = zext i32 %v6789 to i64
  %cond6791 = icmp ne i64 %cv6790, 0
  br i1 %cond6791, label %bb_rcgclear1628, label %bb_rcgcounted1628
bb_rcgcounted1628:
  %v6792 = load i64, ptr %slot1170, align 8
  %op6793 = sub i64 %v6792, 32
  store i64 %op6793, ptr %slot1176, align 8
  %v6794 = load i64, ptr %slot1170, align 8
  %p6795 = inttoptr i64 %v6794 to ptr
  %rgep6796 = getelementptr i8, ptr %p6795, i64 -32
  %ld6797 = load i64, ptr %rgep6796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6797, ptr %slot1177, align 8
  %v6798 = load i64, ptr %slot1177, align 8
  %op6799 = sub i64 %v6798, 1
  store i64 %op6799, ptr %slot1178, align 8
  %v6800 = load i64, ptr %slot1178, align 8
  %cmp6801 = icmp eq i64 %v6800, 0
  %cv6802 = zext i1 %cmp6801 to i32
  store i32 %cv6802, ptr %slot1179, align 8
  %v6803 = load i32, ptr %slot1179, align 8
  %cv6804 = zext i32 %v6803 to i64
  %cond6805 = icmp ne i64 %cv6804, 0
  br i1 %cond6805, label %bb_rcglast1628, label %bb_rcgdec1628
bb_rcglast1628:
  %v6806 = load i64, ptr %slot1170, align 8
  %op6807 = sub i64 %v6806, 24
  store i64 %op6807, ptr %slot1180, align 8
  %v6808 = load i64, ptr %slot1170, align 8
  %p6809 = inttoptr i64 %v6808 to ptr
  %rgep6810 = getelementptr i8, ptr %p6809, i64 -24
  %ld6811 = load i64, ptr %rgep6810, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6811, ptr %slot1181, align 8
  %v6812 = load i64, ptr %slot1181, align 8
  %cmp6813 = icmp ne i64 %v6812, 0
  %cv6814 = zext i1 %cmp6813 to i32
  store i32 %cv6814, ptr %slot1182, align 8
  %v6815 = load i32, ptr %slot1182, align 8
  %cv6816 = zext i32 %v6815 to i64
  %cond6817 = icmp ne i64 %cv6816, 0
  br i1 %cond6817, label %bb_rcgdec1628, label %bb_rcgslow1628
bb_rcgslow1628:
  %v6818 = load i64, ptr %slot1169, align 8
  %v6819 = load i64, ptr %slot1152, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v6818, i64 %v6819) nomerge, !dbg !200
  br label %bb_rcgdone1628
bb_rcgdec1628:
  %v6820 = load i64, ptr %slot1178, align 8
  %v6821 = load i64, ptr %slot1170, align 8
  %p6822 = inttoptr i64 %v6821 to ptr
  %rgep6823 = getelementptr i8, ptr %p6822, i64 -32
  store i64 %v6820, ptr %rgep6823, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1628
bb_rcgclear1628:
  %v6824 = load i64, ptr %slot1152, align 8
  %p6825 = inttoptr i64 %v6824 to ptr
  store i64 0, ptr %p6825, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1628
bb_rcgdone1628:
  br label %bb_rcslotdone1597
bb_rcslotdone1597:
  %v6826 = load i64, ptr %slot37, align 8
  store i64 %v6826, ptr %slot1183, align 8
  %v6827 = load i64, ptr %slot27, align 8
  store i64 %v6827, ptr %slot1184, align 8
  %v6828 = load i64, ptr %slot1184, align 8
  %v6829 = load i64, ptr %slot1183, align 8
  %p6830 = inttoptr i64 %v6828 to ptr
  %p6831 = inttoptr i64 %v6829 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6831, ptr %p6830, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6832 = load i64, ptr %slot18, align 8
  %p6833 = inttoptr i64 %v6832 to ptr
  store i32 0, ptr %p6833, align 4, !alias.scope !3, !noalias !4
  %v6834 = load i64, ptr %slot9, align 8
  %p6835 = inttoptr i64 %v6834 to ptr
  store i32 2, ptr %p6835, align 4, !alias.scope !3, !noalias !4
  %v6836 = load i64, ptr %slot19, align 8
  %p6837 = inttoptr i64 %v6836 to ptr
  %ld6838 = load i32, ptr %p6837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6838, ptr %slot1185, align 8
  %v6839 = load i32, ptr %slot1185, align 8
  %v6840 = load i64, ptr %slot9, align 8
  %p6841 = inttoptr i64 %v6840 to ptr
  store i32 %v6839, ptr %p6841, align 4, !alias.scope !3, !noalias !4
  %v6842 = load i64, ptr %slot8, align 8
  %p6843 = inttoptr i64 %v6842 to ptr
  store i32 1, ptr %p6843, align 4, !alias.scope !3, !noalias !4
  %v6844 = load i64, ptr %slot37, align 8
  %p6845 = inttoptr i64 %v6844 to ptr
  %ld6846 = load i64, ptr %p6845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6846, ptr %slot1186, align 8
  %v6847 = load i64, ptr %slot1186, align 8
  %v6848 = load i64, ptr %slot40, align 8
  %p6849 = inttoptr i64 %v6848 to ptr
  store i64 %v6847, ptr %p6849, align 8, !alias.scope !3, !noalias !4
  %v6850 = load i64, ptr %slot41, align 8
  %p6851 = inttoptr i64 %v6850 to ptr
  store i64 0, ptr %p6851, align 8, !alias.scope !3, !noalias !4
  %v6852 = load i64, ptr %slot41, align 8
  %p6853 = inttoptr i64 %v6852 to ptr
  %ld6854 = load i64, ptr %p6853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6854, ptr %slot1187, align 8
  %v6855 = load i64, ptr %slot1187, align 8
  %cmp6856 = icmp sge i64 %v6855, 0
  %cv6857 = zext i1 %cmp6856 to i64
  store i64 %cv6857, ptr %slot1188, align 8
  %v6858 = load i64, ptr %slot1188, align 8
  %cond6859 = icmp ne i64 %v6858, 0
  br i1 %cond6859, label %bb_success1642, label %bb_failed1642
bb_failed1642:
  %v6860 = load i64, ptr %slot1, align 8
  %p6861 = inttoptr i64 %v6860 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p6861) nomerge, !dbg !202
  unreachable
bb_success1642:
  %v6862 = load i64, ptr %slot46, align 8
  %p6863 = inttoptr i64 %v6862 to ptr
  %p6864 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v6865 = load i64, ptr %slot1187, align 8
  %call6866 = call ptr @myl_native_list_new(ptr %p6863, ptr %p6864, i64 %v6865) nomerge, !dbg !202
  %calladdr6867 = ptrtoint ptr %call6866 to i64
  store i64 %calladdr6867, ptr %slot1189, align 8
  %v6868 = load i64, ptr %slot1189, align 8
  %cond6869 = icmp ne i64 %v6868, 0
  br i1 %cond6869, label %bb_success1644, label %bb_failed1644
bb_failed1644:
  %v6870 = load i64, ptr %slot1, align 8
  %p6871 = inttoptr i64 %v6870 to ptr
  call void @myl_qbe_fail_allocation(ptr %p6871) nomerge, !dbg !202
  unreachable
bb_success1644:
  %v6872 = load i64, ptr %slot1189, align 8
  %v6873 = load i64, ptr %slot41, align 8
  %p6874 = inttoptr i64 %v6873 to ptr
  store i64 %v6872, ptr %p6874, align 8, !alias.scope !3, !noalias !4
  %v6875 = load i64, ptr %slot41, align 8
  %p6876 = inttoptr i64 %v6875 to ptr
  %ld6877 = load i64, ptr %p6876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6877, ptr %slot1190, align 8
  %v6878 = load i64, ptr %slot1190, align 8
  %v6879 = load i64, ptr %slot26, align 8
  %p6880 = inttoptr i64 %v6879 to ptr
  store i64 %v6878, ptr %p6880, align 8, !alias.scope !3, !noalias !4
  %v6881 = load i64, ptr %slot26, align 8
  store i64 %v6881, ptr %slot1191, align 8
  %v6882 = load i64, ptr %slot27, align 8
  store i64 %v6882, ptr %slot1192, align 8
  %v6883 = load i64, ptr %slot1191, align 8
  %v6884 = load i64, ptr %slot1192, align 8
  %p6885 = inttoptr i64 %v6883 to ptr
  %p6886 = inttoptr i64 %v6884 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6886, ptr %p6885, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6887 = load i64, ptr %slot19, align 8
  %p6888 = inttoptr i64 %v6887 to ptr
  store i32 2, ptr %p6888, align 4, !alias.scope !3, !noalias !4
  %v6889 = load i64, ptr %slot18, align 8
  %p6890 = inttoptr i64 %v6889 to ptr
  store i32 1, ptr %p6890, align 4, !alias.scope !3, !noalias !4
  %v6891 = load i64, ptr %slot23, align 8
  store i64 %v6891, ptr %slot1193, align 8
  %v6892 = load i64, ptr %slot27, align 8
  store i64 %v6892, ptr %slot1194, align 8
  %v6893 = load i64, ptr %slot1194, align 8
  %v6894 = load i64, ptr %slot1193, align 8
  %p6895 = inttoptr i64 %v6893 to ptr
  %p6896 = inttoptr i64 %v6894 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6896, ptr %p6895, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6897 = load i64, ptr %slot17, align 8
  %p6898 = inttoptr i64 %v6897 to ptr
  store i32 2, ptr %p6898, align 4, !alias.scope !3, !noalias !4
  %v6899 = load i64, ptr %slot19, align 8
  %p6900 = inttoptr i64 %v6899 to ptr
  %ld6901 = load i32, ptr %p6900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6901, ptr %slot1195, align 8
  %v6902 = load i32, ptr %slot1195, align 8
  %v6903 = load i64, ptr %slot17, align 8
  %p6904 = inttoptr i64 %v6903 to ptr
  store i32 %v6902, ptr %p6904, align 4, !alias.scope !3, !noalias !4
  %v6905 = load i64, ptr %slot18, align 8
  %p6906 = inttoptr i64 %v6905 to ptr
  store i32 0, ptr %p6906, align 4, !alias.scope !3, !noalias !4
  %v6907 = load i64, ptr %slot16, align 8
  %p6908 = inttoptr i64 %v6907 to ptr
  store i32 1, ptr %p6908, align 4, !alias.scope !3, !noalias !4
  %v6909 = load i64, ptr %slot1193, align 8
  %p6910 = inttoptr i64 %v6909 to ptr
  %ld6911 = load i64, ptr %p6910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6911, ptr %slot1196, align 8
  %v6912 = load i64, ptr %slot1196, align 8
  %v6913 = load i64, ptr %slot41, align 8
  %p6914 = inttoptr i64 %v6913 to ptr
  store i64 %v6912, ptr %p6914, align 8, !alias.scope !3, !noalias !4
  %v6915 = load i64, ptr %slot41, align 8
  %p6916 = inttoptr i64 %v6915 to ptr
  %ld6917 = load i64, ptr %p6916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6917, ptr %slot1197, align 8
  %v6918 = load i64, ptr %slot1197, align 8
  %v6919 = load i64, ptr %slot26, align 8
  %p6920 = inttoptr i64 %v6919 to ptr
  store i64 %v6918, ptr %p6920, align 8, !alias.scope !3, !noalias !4
  %v6921 = load i64, ptr %slot26, align 8
  store i64 %v6921, ptr %slot1198, align 8
  %v6922 = load i64, ptr %slot16, align 8
  %p6923 = inttoptr i64 %v6922 to ptr
  %ld6924 = load i32, ptr %p6923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6924, ptr %slot1199, align 8
  %v6925 = load i64, ptr %slot17, align 8
  %p6926 = inttoptr i64 %v6925 to ptr
  %ld6927 = load i32, ptr %p6926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6927, ptr %slot1200, align 8
  %v6928 = load i32, ptr %slot1200, align 8
  %op6929 = and i32 %v6928, 24
  store i32 %op6929, ptr %slot1200, align 8
  %v6930 = load i32, ptr %slot1200, align 8
  %cmp6931 = icmp eq i32 %v6930, 0
  %cv6932 = zext i1 %cmp6931 to i32
  store i32 %cv6932, ptr %slot1201, align 8
  %v6933 = load i32, ptr %slot1199, align 8
  %v6934 = load i32, ptr %slot1201, align 8
  %op6935 = and i32 %v6933, %v6934
  store i32 %op6935, ptr %slot1202, align 8
  %v6936 = load i32, ptr %slot1202, align 8
  %cv6937 = zext i32 %v6936 to i64
  %cond6938 = icmp ne i64 %cv6937, 0
  br i1 %cond6938, label %bb_rcprivateown1667, label %bb_rcprivateloan1667
bb_rcprivateown1667:
  %v6939 = load i64, ptr %slot27, align 8
  store i64 %v6939, ptr %slot1203, align 8
  %v6940 = load i64, ptr %slot47, align 8
  store i64 %v6940, ptr %slot1204, align 8
  %v6941 = load i64, ptr %slot1198, align 8
  %v6942 = load i64, ptr %slot1203, align 8
  %op6943 = sub i64 %v6941, %v6942
  store i64 %op6943, ptr %slot1205, align 8
  %v6944 = load i64, ptr %slot1203, align 8
  %v6945 = load i64, ptr %slot1198, align 8
  %op6946 = sub i64 %v6944, %v6945
  store i64 %op6946, ptr %slot1206, align 8
  %v6947 = load i64, ptr %slot1205, align 8
  %cmp6948 = icmp ult i64 %v6947, 8
  %cv6949 = zext i1 %cmp6948 to i32
  store i32 %cv6949, ptr %slot1207, align 8
  %v6950 = load i64, ptr %slot1206, align 8
  %cmp6951 = icmp ult i64 %v6950, 8
  %cv6952 = zext i1 %cmp6951 to i32
  store i32 %cv6952, ptr %slot1208, align 8
  %v6953 = load i32, ptr %slot1207, align 8
  %v6954 = load i32, ptr %slot1208, align 8
  %op6955 = or i32 %v6953, %v6954
  store i32 %op6955, ptr %slot1209, align 8
  %v6956 = load i32, ptr %slot1209, align 8
  %cv6957 = zext i32 %v6956 to i64
  %cond6958 = icmp ne i64 %cv6957, 0
  br i1 %cond6958, label %bb_rcmoveslow1670, label %bb_rcmovecheck1670
bb_rcmovecheck1670:
  %v6959 = load i64, ptr %slot1198, align 8
  %p6961 = inttoptr i64 %v6959 to ptr
  %gep6962 = getelementptr i8, ptr %p6961, i64 0
  %op6960 = ptrtoint ptr %gep6962 to i64
  store i64 %op6960, ptr %slot1210, align 8
  %v6963 = load i64, ptr %slot1210, align 8
  %p6964 = inttoptr i64 %v6963 to ptr
  %ld6965 = load i64, ptr %p6964, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6965, ptr %slot1211, align 8
  %v6966 = load i64, ptr %slot1211, align 8
  %cmp6967 = icmp ne i64 %v6966, 0
  %cv6968 = zext i1 %cmp6967 to i32
  store i32 %cv6968, ptr %slot1212, align 8
  %v6969 = load i32, ptr %slot1212, align 8
  %cv6970 = zext i32 %v6969 to i64
  %cond6971 = icmp ne i64 %cv6970, 0
  br i1 %cond6971, label %bb_rcmoveheader1678, label %bb_rcmovenext1678
bb_rcmoveheader1678:
  %v6972 = load i64, ptr %slot1211, align 8
  %op6973 = sub i64 %v6972, 16
  store i64 %op6973, ptr %slot1213, align 8
  %v6974 = load i64, ptr %slot1211, align 8
  %p6975 = inttoptr i64 %v6974 to ptr
  %rgep6976 = getelementptr i8, ptr %p6975, i64 -16
  %ld6977 = load i64, ptr %rgep6976, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6977, ptr %slot1214, align 8
  %v6978 = load i64, ptr %slot1214, align 8
  %op6979 = and i64 %v6978, 5764607523034234881
  store i64 %op6979, ptr %slot1215, align 8
  %v6980 = load i64, ptr %slot1215, align 8
  %cmp6981 = icmp ne i64 %v6980, 0
  %cv6982 = zext i1 %cmp6981 to i32
  store i32 %cv6982, ptr %slot1216, align 8
  %v6983 = load i32, ptr %slot1216, align 8
  %cv6984 = zext i32 %v6983 to i64
  %cond6985 = icmp ne i64 %cv6984, 0
  br i1 %cond6985, label %bb_rcmoveslow1670, label %bb_rcmovenext1678
bb_rcmovenext1678:
  %v6986 = load i64, ptr %slot1198, align 8
  %v6987 = load i64, ptr %slot1203, align 8
  %p6988 = inttoptr i64 %v6986 to ptr
  %p6989 = inttoptr i64 %v6987 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6989, ptr %p6988, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v6990 = load i64, ptr %slot1198, align 8
  %p6991 = inttoptr i64 %v6990 to ptr
  store i64 0, ptr %p6991, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1670
bb_rcmoveslow1670:
  %v6992 = load i64, ptr %slot46, align 8
  %v6993 = load i64, ptr %slot1203, align 8
  %v6994 = load i64, ptr %slot1198, align 8
  %v6995 = load i64, ptr %slot1204, align 8
  %cv6996 = trunc i64 %v6995 to i32
  %call6997 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v6992, i64 %v6993, i64 %v6994, i32 %cv6996) nomerge, !dbg !204
  store i32 %call6997, ptr %slot1217, align 8
  %v6998 = load i32, ptr %slot1217, align 8
  %cv6999 = zext i32 %v6998 to i64
  %cond7000 = icmp ne i64 %cv6999, 0
  br i1 %cond7000, label %bb_rcsuccess1685, label %bb_rcfailure1685
bb_rcfailure1685:
  %v7001 = load i64, ptr %slot46, align 8
  %p7002 = inttoptr i64 %v7001 to ptr
  %call7003 = call i32 @myl_rc_take_failure(ptr %p7002) nomerge, !dbg !204
  store i32 %call7003, ptr %slot1218, align 8
  %v7004 = load i64, ptr %slot1, align 8
  %p7005 = inttoptr i64 %v7004 to ptr
  %v7006 = load i32, ptr %slot1218, align 8
  %call7007 = call i32 @myl_qbe_rc_status(ptr %p7005, i32 %v7006) nomerge, !dbg !204
  store i32 %call7007, ptr %slot1219, align 8
  br label %bb_failure
bb_rcsuccess1685:
  br label %bb_rcmoved1670
bb_rcmoved1670:
  %v7008 = load i64, ptr %slot16, align 8
  %p7009 = inttoptr i64 %v7008 to ptr
  store i32 0, ptr %p7009, align 4, !alias.scope !3, !noalias !4
  %v7010 = load i64, ptr %slot19, align 8
  %p7011 = inttoptr i64 %v7010 to ptr
  store i32 2, ptr %p7011, align 4, !alias.scope !3, !noalias !4
  %v7012 = load i64, ptr %slot18, align 8
  %p7013 = inttoptr i64 %v7012 to ptr
  store i32 1, ptr %p7013, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1667
bb_rcprivateloan1667:
  %v7014 = load i64, ptr %slot16, align 8
  %p7015 = inttoptr i64 %v7014 to ptr
  %ld7016 = load i32, ptr %p7015, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7016, ptr %slot1220, align 8
  %v7017 = load i64, ptr %slot17, align 8
  %p7018 = inttoptr i64 %v7017 to ptr
  %ld7019 = load i32, ptr %p7018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7019, ptr %slot1221, align 8
  %v7020 = load i32, ptr %slot1221, align 8
  %cmp7021 = icmp eq i32 %v7020, 16
  %cv7022 = zext i1 %cmp7021 to i32
  store i32 %cv7022, ptr %slot1222, align 8
  %v7023 = load i32, ptr %slot1222, align 8
  %v7024 = load i32, ptr %slot1220, align 8
  %op7025 = and i32 %v7023, %v7024
  store i32 %op7025, ptr %slot1222, align 8
  %v7026 = load i32, ptr %slot1222, align 8
  %cv7027 = zext i32 %v7026 to i64
  %cond7028 = icmp ne i64 %cv7027, 0
  br i1 %cond7028, label %bb_rcprivatemove1667, label %bb_rcprivatenew1667
bb_rcprivatemove1667:
  %v7029 = load i64, ptr %slot27, align 8
  store i64 %v7029, ptr %slot1223, align 8
  %v7030 = load i64, ptr %slot1198, align 8
  %v7031 = load i64, ptr %slot1223, align 8
  %p7032 = inttoptr i64 %v7030 to ptr
  %p7033 = inttoptr i64 %v7031 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7033, ptr %p7032, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7034 = load i64, ptr %slot1198, align 8
  %p7035 = inttoptr i64 %v7034 to ptr
  store i64 0, ptr %p7035, align 8, !alias.scope !3, !noalias !4
  %v7036 = load i64, ptr %slot19, align 8
  %p7037 = inttoptr i64 %v7036 to ptr
  store i32 2, ptr %p7037, align 4, !alias.scope !3, !noalias !4
  %v7038 = load i64, ptr %slot19, align 8
  %p7039 = inttoptr i64 %v7038 to ptr
  store i32 16, ptr %p7039, align 4, !alias.scope !3, !noalias !4
  %v7040 = load i64, ptr %slot18, align 8
  %p7041 = inttoptr i64 %v7040 to ptr
  store i32 1, ptr %p7041, align 4, !alias.scope !3, !noalias !4
  %v7042 = load i64, ptr %slot16, align 8
  %p7043 = inttoptr i64 %v7042 to ptr
  store i32 0, ptr %p7043, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1667
bb_rcprivatenew1667:
  %v7044 = load i64, ptr %slot27, align 8
  store i64 %v7044, ptr %slot1224, align 8
  %v7045 = load i64, ptr %slot1198, align 8
  %p7046 = inttoptr i64 %v7045 to ptr
  %ld7047 = load i64, ptr %p7046, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7047, ptr %slot1225, align 8
  %v7048 = load i64, ptr %slot1225, align 8
  %cmp7049 = icmp ne i64 %v7048, 0
  %cv7050 = zext i1 %cmp7049 to i32
  store i32 %cv7050, ptr %slot1226, align 8
  %v7051 = load i32, ptr %slot1226, align 8
  %cv7052 = zext i32 %v7051 to i64
  %cond7053 = icmp ne i64 %cv7052, 0
  br i1 %cond7053, label %bb_rcgnn1703, label %bb_rcgstore1703
bb_rcgnn1703:
  %v7054 = load i64, ptr %slot1225, align 8
  %op7055 = sub i64 %v7054, 16
  store i64 %op7055, ptr %slot1227, align 8
  %v7056 = load i64, ptr %slot1225, align 8
  %p7057 = inttoptr i64 %v7056 to ptr
  %rgep7058 = getelementptr i8, ptr %p7057, i64 -16
  %ld7059 = load i64, ptr %rgep7058, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7059, ptr %slot1228, align 8
  %v7060 = load i64, ptr %slot1228, align 8
  %op7061 = and i64 %v7060, 4611686018427387906
  store i64 %op7061, ptr %slot1229, align 8
  %v7062 = load i64, ptr %slot1229, align 8
  %cmp7063 = icmp ne i64 %v7062, 0
  %cv7064 = zext i1 %cmp7063 to i32
  store i32 %cv7064, ptr %slot1230, align 8
  %v7065 = load i32, ptr %slot1230, align 8
  %cv7066 = zext i32 %v7065 to i64
  %cond7067 = icmp ne i64 %cv7066, 0
  br i1 %cond7067, label %bb_rcgstore1703, label %bb_rcginc1703
bb_rcginc1703:
  %v7068 = load i64, ptr %slot1225, align 8
  %op7069 = sub i64 %v7068, 24
  store i64 %op7069, ptr %slot1231, align 8
  %v7070 = load i64, ptr %slot1225, align 8
  %p7071 = inttoptr i64 %v7070 to ptr
  %rgep7072 = getelementptr i8, ptr %p7071, i64 -24
  %ld7073 = load i64, ptr %rgep7072, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7073, ptr %slot1232, align 8
  %v7074 = load i64, ptr %slot1232, align 8
  %op7075 = add i64 %v7074, 1
  store i64 %op7075, ptr %slot1233, align 8
  %v7076 = load i64, ptr %slot1233, align 8
  %cmp7077 = icmp eq i64 %v7076, 0
  %cv7078 = zext i1 %cmp7077 to i32
  store i32 %cv7078, ptr %slot1234, align 8
  %v7079 = load i32, ptr %slot1234, align 8
  %cv7080 = zext i32 %v7079 to i64
  %cond7081 = icmp ne i64 %cv7080, 0
  br i1 %cond7081, label %bb_rcglimit1703, label %bb_rcgcapacity1703
bb_rcglimit1703:
  %v7082 = load i64, ptr %slot1, align 8
  %p7083 = inttoptr i64 %v7082 to ptr
  %call7084 = call i32 @myl_qbe_rc_status(ptr %p7083, i32 2) nomerge, !dbg !204
  store i32 %call7084, ptr %slot1235, align 8
  br label %bb_failure
bb_rcgcapacity1703:
  %v7085 = load i64, ptr %slot1233, align 8
  %v7086 = load i64, ptr %slot1225, align 8
  %p7087 = inttoptr i64 %v7086 to ptr
  %rgep7088 = getelementptr i8, ptr %p7087, i64 -24
  store i64 %v7085, ptr %rgep7088, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1703
bb_rcgstore1703:
  %v7089 = load i64, ptr %slot1225, align 8
  %v7090 = load i64, ptr %slot1224, align 8
  %p7091 = inttoptr i64 %v7090 to ptr
  store i64 %v7089, ptr %p7091, align 8, !alias.scope !3, !noalias !4
  %v7092 = load i64, ptr %slot19, align 8
  %p7093 = inttoptr i64 %v7092 to ptr
  store i32 2, ptr %p7093, align 4, !alias.scope !3, !noalias !4
  %v7094 = load i64, ptr %slot19, align 8
  %p7095 = inttoptr i64 %v7094 to ptr
  store i32 16, ptr %p7095, align 4, !alias.scope !3, !noalias !4
  %v7096 = load i64, ptr %slot18, align 8
  %p7097 = inttoptr i64 %v7096 to ptr
  store i32 1, ptr %p7097, align 4, !alias.scope !3, !noalias !4
  %v7098 = load i64, ptr %slot16, align 8
  %p7099 = inttoptr i64 %v7098 to ptr
  %ld7100 = load i32, ptr %p7099, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7100, ptr %slot1236, align 8
  %v7101 = load i32, ptr %slot1236, align 8
  %cv7102 = zext i32 %v7101 to i64
  %cond7103 = icmp ne i64 %cv7102, 0
  br i1 %cond7103, label %bb_rcslotdrop1719, label %bb_rcslotdone1719
bb_rcslotdrop1719:
  %v7104 = load i64, ptr %slot16, align 8
  %p7105 = inttoptr i64 %v7104 to ptr
  store i32 0, ptr %p7105, align 4, !alias.scope !3, !noalias !4
  %v7106 = load i64, ptr %slot23, align 8
  store i64 %v7106, ptr %slot1237, align 8
  %v7107 = load i64, ptr %slot17, align 8
  %p7108 = inttoptr i64 %v7107 to ptr
  %ld7109 = load i32, ptr %p7108, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7109, ptr %slot1238, align 8
  %v7110 = load i32, ptr %slot1238, align 8
  %op7111 = and i32 %v7110, 28
  store i32 %op7111, ptr %slot1239, align 8
  %v7112 = load i32, ptr %slot1239, align 8
  %cv7113 = zext i32 %v7112 to i64
  %cond7114 = icmp ne i64 %cv7113, 0
  br i1 %cond7114, label %bb_rcslotrole1719, label %bb_rcslotowner1719
bb_rcslotrole1719:
  %v7115 = load i64, ptr %slot46, align 8
  store i64 %v7115, ptr %slot1240, align 8
  %v7116 = load i64, ptr %slot1237, align 8
  %p7117 = inttoptr i64 %v7116 to ptr
  %ld7118 = load i64, ptr %p7117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7118, ptr %slot1241, align 8
  %v7119 = load i64, ptr %slot1241, align 8
  %cmp7120 = icmp ne i64 %v7119, 0
  %cv7121 = zext i1 %cmp7120 to i32
  store i32 %cv7121, ptr %slot1242, align 8
  %v7122 = load i32, ptr %slot1242, align 8
  %cv7123 = zext i32 %v7122 to i64
  %cond7124 = icmp ne i64 %cv7123, 0
  br i1 %cond7124, label %bb_rcgnn1735, label %bb_rcgdone1735
bb_rcgnn1735:
  %v7125 = load i64, ptr %slot1241, align 8
  %op7126 = sub i64 %v7125, 16
  store i64 %op7126, ptr %slot1243, align 8
  %v7127 = load i64, ptr %slot1241, align 8
  %p7128 = inttoptr i64 %v7127 to ptr
  %rgep7129 = getelementptr i8, ptr %p7128, i64 -16
  %ld7130 = load i64, ptr %rgep7129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7130, ptr %slot1244, align 8
  %v7131 = load i64, ptr %slot1244, align 8
  %op7132 = and i64 %v7131, 4611686018427387906
  store i64 %op7132, ptr %slot1245, align 8
  %v7133 = load i64, ptr %slot1245, align 8
  %cmp7134 = icmp ne i64 %v7133, 0
  %cv7135 = zext i1 %cmp7134 to i32
  store i32 %cv7135, ptr %slot1246, align 8
  %v7136 = load i32, ptr %slot1246, align 8
  %cv7137 = zext i32 %v7136 to i64
  %cond7138 = icmp ne i64 %cv7137, 0
  br i1 %cond7138, label %bb_rcgclear1735, label %bb_rcgcounted1735
bb_rcgcounted1735:
  %v7139 = load i64, ptr %slot1241, align 8
  %op7140 = sub i64 %v7139, 24
  store i64 %op7140, ptr %slot1247, align 8
  %v7141 = load i64, ptr %slot1241, align 8
  %p7142 = inttoptr i64 %v7141 to ptr
  %rgep7143 = getelementptr i8, ptr %p7142, i64 -24
  %ld7144 = load i64, ptr %rgep7143, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7144, ptr %slot1248, align 8
  %v7145 = load i64, ptr %slot1248, align 8
  %op7146 = sub i64 %v7145, 1
  store i64 %op7146, ptr %slot1249, align 8
  %v7147 = load i64, ptr %slot1249, align 8
  %cmp7148 = icmp eq i64 %v7147, 0
  %cv7149 = zext i1 %cmp7148 to i32
  store i32 %cv7149, ptr %slot1250, align 8
  %v7150 = load i32, ptr %slot1250, align 8
  %cv7151 = zext i32 %v7150 to i64
  %cond7152 = icmp ne i64 %cv7151, 0
  br i1 %cond7152, label %bb_rcglast1735, label %bb_rcgdec1735
bb_rcglast1735:
  %v7153 = load i64, ptr %slot1241, align 8
  %op7154 = sub i64 %v7153, 32
  store i64 %op7154, ptr %slot1251, align 8
  %v7155 = load i64, ptr %slot1241, align 8
  %p7156 = inttoptr i64 %v7155 to ptr
  %rgep7157 = getelementptr i8, ptr %p7156, i64 -32
  %ld7158 = load i64, ptr %rgep7157, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7158, ptr %slot1252, align 8
  %v7159 = load i64, ptr %slot1252, align 8
  %cmp7160 = icmp ne i64 %v7159, 0
  %cv7161 = zext i1 %cmp7160 to i32
  store i32 %cv7161, ptr %slot1253, align 8
  %v7162 = load i32, ptr %slot1253, align 8
  %cv7163 = zext i32 %v7162 to i64
  %cond7164 = icmp ne i64 %cv7163, 0
  br i1 %cond7164, label %bb_rcgdec1735, label %bb_rcgslow1735
bb_rcgslow1735:
  %v7165 = load i64, ptr %slot1240, align 8
  %v7166 = load i64, ptr %slot1237, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v7165, i64 %v7166) nomerge, !dbg !204
  br label %bb_rcgdone1735
bb_rcgdec1735:
  %v7167 = load i64, ptr %slot1249, align 8
  %v7168 = load i64, ptr %slot1241, align 8
  %p7169 = inttoptr i64 %v7168 to ptr
  %rgep7170 = getelementptr i8, ptr %p7169, i64 -24
  store i64 %v7167, ptr %rgep7170, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1735
bb_rcgclear1735:
  %v7171 = load i64, ptr %slot1237, align 8
  %p7172 = inttoptr i64 %v7171 to ptr
  store i64 0, ptr %p7172, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1735
bb_rcgdone1735:
  br label %bb_rcslotdone1719
bb_rcslotowner1719:
  %v7173 = load i64, ptr %slot46, align 8
  store i64 %v7173, ptr %slot1254, align 8
  %v7174 = load i64, ptr %slot1237, align 8
  %p7175 = inttoptr i64 %v7174 to ptr
  %ld7176 = load i64, ptr %p7175, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7176, ptr %slot1255, align 8
  %v7177 = load i64, ptr %slot1255, align 8
  %cmp7178 = icmp ne i64 %v7177, 0
  %cv7179 = zext i1 %cmp7178 to i32
  store i32 %cv7179, ptr %slot1256, align 8
  %v7180 = load i32, ptr %slot1256, align 8
  %cv7181 = zext i32 %v7180 to i64
  %cond7182 = icmp ne i64 %cv7181, 0
  br i1 %cond7182, label %bb_rcgnn1750, label %bb_rcgdone1750
bb_rcgnn1750:
  %v7183 = load i64, ptr %slot1255, align 8
  %op7184 = sub i64 %v7183, 16
  store i64 %op7184, ptr %slot1257, align 8
  %v7185 = load i64, ptr %slot1255, align 8
  %p7186 = inttoptr i64 %v7185 to ptr
  %rgep7187 = getelementptr i8, ptr %p7186, i64 -16
  %ld7188 = load i64, ptr %rgep7187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7188, ptr %slot1258, align 8
  %v7189 = load i64, ptr %slot1258, align 8
  %op7190 = and i64 %v7189, 4611686018427387906
  store i64 %op7190, ptr %slot1259, align 8
  %v7191 = load i64, ptr %slot1259, align 8
  %cmp7192 = icmp ne i64 %v7191, 0
  %cv7193 = zext i1 %cmp7192 to i32
  store i32 %cv7193, ptr %slot1260, align 8
  %v7194 = load i32, ptr %slot1260, align 8
  %cv7195 = zext i32 %v7194 to i64
  %cond7196 = icmp ne i64 %cv7195, 0
  br i1 %cond7196, label %bb_rcgclear1750, label %bb_rcgcounted1750
bb_rcgcounted1750:
  %v7197 = load i64, ptr %slot1255, align 8
  %op7198 = sub i64 %v7197, 32
  store i64 %op7198, ptr %slot1261, align 8
  %v7199 = load i64, ptr %slot1255, align 8
  %p7200 = inttoptr i64 %v7199 to ptr
  %rgep7201 = getelementptr i8, ptr %p7200, i64 -32
  %ld7202 = load i64, ptr %rgep7201, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7202, ptr %slot1262, align 8
  %v7203 = load i64, ptr %slot1262, align 8
  %op7204 = sub i64 %v7203, 1
  store i64 %op7204, ptr %slot1263, align 8
  %v7205 = load i64, ptr %slot1263, align 8
  %cmp7206 = icmp eq i64 %v7205, 0
  %cv7207 = zext i1 %cmp7206 to i32
  store i32 %cv7207, ptr %slot1264, align 8
  %v7208 = load i32, ptr %slot1264, align 8
  %cv7209 = zext i32 %v7208 to i64
  %cond7210 = icmp ne i64 %cv7209, 0
  br i1 %cond7210, label %bb_rcglast1750, label %bb_rcgdec1750
bb_rcglast1750:
  %v7211 = load i64, ptr %slot1255, align 8
  %op7212 = sub i64 %v7211, 24
  store i64 %op7212, ptr %slot1265, align 8
  %v7213 = load i64, ptr %slot1255, align 8
  %p7214 = inttoptr i64 %v7213 to ptr
  %rgep7215 = getelementptr i8, ptr %p7214, i64 -24
  %ld7216 = load i64, ptr %rgep7215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7216, ptr %slot1266, align 8
  %v7217 = load i64, ptr %slot1266, align 8
  %cmp7218 = icmp ne i64 %v7217, 0
  %cv7219 = zext i1 %cmp7218 to i32
  store i32 %cv7219, ptr %slot1267, align 8
  %v7220 = load i32, ptr %slot1267, align 8
  %cv7221 = zext i32 %v7220 to i64
  %cond7222 = icmp ne i64 %cv7221, 0
  br i1 %cond7222, label %bb_rcgdec1750, label %bb_rcgslow1750
bb_rcgslow1750:
  %v7223 = load i64, ptr %slot1254, align 8
  %v7224 = load i64, ptr %slot1237, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v7223, i64 %v7224) nomerge, !dbg !204
  br label %bb_rcgdone1750
bb_rcgdec1750:
  %v7225 = load i64, ptr %slot1263, align 8
  %v7226 = load i64, ptr %slot1255, align 8
  %p7227 = inttoptr i64 %v7226 to ptr
  %rgep7228 = getelementptr i8, ptr %p7227, i64 -32
  store i64 %v7225, ptr %rgep7228, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1750
bb_rcgclear1750:
  %v7229 = load i64, ptr %slot1237, align 8
  %p7230 = inttoptr i64 %v7229 to ptr
  store i64 0, ptr %p7230, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1750
bb_rcgdone1750:
  br label %bb_rcslotdone1719
bb_rcslotdone1719:
  br label %bb_rcprivateprepared1667
bb_rcprivateprepared1667:
  %v7231 = load i64, ptr %slot10, align 8
  %p7232 = inttoptr i64 %v7231 to ptr
  %ld7233 = load i32, ptr %p7232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7233, ptr %slot1268, align 8
  %v7234 = load i32, ptr %slot1268, align 8
  %cv7235 = zext i32 %v7234 to i64
  %cond7236 = icmp ne i64 %cv7235, 0
  br i1 %cond7236, label %bb_rcslotdrop1757, label %bb_rcslotdone1757
bb_rcslotdrop1757:
  %v7237 = load i64, ptr %slot10, align 8
  %p7238 = inttoptr i64 %v7237 to ptr
  store i32 0, ptr %p7238, align 4, !alias.scope !3, !noalias !4
  %v7239 = load i64, ptr %slot38, align 8
  store i64 %v7239, ptr %slot1269, align 8
  %v7240 = load i64, ptr %slot11, align 8
  %p7241 = inttoptr i64 %v7240 to ptr
  %ld7242 = load i32, ptr %p7241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7242, ptr %slot1270, align 8
  %v7243 = load i32, ptr %slot1270, align 8
  %op7244 = and i32 %v7243, 28
  store i32 %op7244, ptr %slot1271, align 8
  %v7245 = load i32, ptr %slot1271, align 8
  %cv7246 = zext i32 %v7245 to i64
  %cond7247 = icmp ne i64 %cv7246, 0
  br i1 %cond7247, label %bb_rcslotrole1757, label %bb_rcslotowner1757
bb_rcslotrole1757:
  %v7248 = load i64, ptr %slot46, align 8
  store i64 %v7248, ptr %slot1272, align 8
  %v7249 = load i64, ptr %slot1269, align 8
  %p7250 = inttoptr i64 %v7249 to ptr
  %ld7251 = load i64, ptr %p7250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7251, ptr %slot1273, align 8
  %v7252 = load i64, ptr %slot1273, align 8
  %cmp7253 = icmp ne i64 %v7252, 0
  %cv7254 = zext i1 %cmp7253 to i32
  store i32 %cv7254, ptr %slot1274, align 8
  %v7255 = load i32, ptr %slot1274, align 8
  %cv7256 = zext i32 %v7255 to i64
  %cond7257 = icmp ne i64 %cv7256, 0
  br i1 %cond7257, label %bb_rcgnn1773, label %bb_rcgdone1773
bb_rcgnn1773:
  %v7258 = load i64, ptr %slot1273, align 8
  %op7259 = sub i64 %v7258, 16
  store i64 %op7259, ptr %slot1275, align 8
  %v7260 = load i64, ptr %slot1273, align 8
  %p7261 = inttoptr i64 %v7260 to ptr
  %rgep7262 = getelementptr i8, ptr %p7261, i64 -16
  %ld7263 = load i64, ptr %rgep7262, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7263, ptr %slot1276, align 8
  %v7264 = load i64, ptr %slot1276, align 8
  %op7265 = and i64 %v7264, 4611686018427387906
  store i64 %op7265, ptr %slot1277, align 8
  %v7266 = load i64, ptr %slot1277, align 8
  %cmp7267 = icmp ne i64 %v7266, 0
  %cv7268 = zext i1 %cmp7267 to i32
  store i32 %cv7268, ptr %slot1278, align 8
  %v7269 = load i32, ptr %slot1278, align 8
  %cv7270 = zext i32 %v7269 to i64
  %cond7271 = icmp ne i64 %cv7270, 0
  br i1 %cond7271, label %bb_rcgclear1773, label %bb_rcgcounted1773
bb_rcgcounted1773:
  %v7272 = load i64, ptr %slot1273, align 8
  %op7273 = sub i64 %v7272, 24
  store i64 %op7273, ptr %slot1279, align 8
  %v7274 = load i64, ptr %slot1273, align 8
  %p7275 = inttoptr i64 %v7274 to ptr
  %rgep7276 = getelementptr i8, ptr %p7275, i64 -24
  %ld7277 = load i64, ptr %rgep7276, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7277, ptr %slot1280, align 8
  %v7278 = load i64, ptr %slot1280, align 8
  %op7279 = sub i64 %v7278, 1
  store i64 %op7279, ptr %slot1281, align 8
  %v7280 = load i64, ptr %slot1281, align 8
  %cmp7281 = icmp eq i64 %v7280, 0
  %cv7282 = zext i1 %cmp7281 to i32
  store i32 %cv7282, ptr %slot1282, align 8
  %v7283 = load i32, ptr %slot1282, align 8
  %cv7284 = zext i32 %v7283 to i64
  %cond7285 = icmp ne i64 %cv7284, 0
  br i1 %cond7285, label %bb_rcglast1773, label %bb_rcgdec1773
bb_rcglast1773:
  %v7286 = load i64, ptr %slot1273, align 8
  %op7287 = sub i64 %v7286, 32
  store i64 %op7287, ptr %slot1283, align 8
  %v7288 = load i64, ptr %slot1273, align 8
  %p7289 = inttoptr i64 %v7288 to ptr
  %rgep7290 = getelementptr i8, ptr %p7289, i64 -32
  %ld7291 = load i64, ptr %rgep7290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7291, ptr %slot1284, align 8
  %v7292 = load i64, ptr %slot1284, align 8
  %cmp7293 = icmp ne i64 %v7292, 0
  %cv7294 = zext i1 %cmp7293 to i32
  store i32 %cv7294, ptr %slot1285, align 8
  %v7295 = load i32, ptr %slot1285, align 8
  %cv7296 = zext i32 %v7295 to i64
  %cond7297 = icmp ne i64 %cv7296, 0
  br i1 %cond7297, label %bb_rcgdec1773, label %bb_rcgslow1773
bb_rcgslow1773:
  %v7298 = load i64, ptr %slot1272, align 8
  %v7299 = load i64, ptr %slot1269, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v7298, i64 %v7299) nomerge, !dbg !204
  br label %bb_rcgdone1773
bb_rcgdec1773:
  %v7300 = load i64, ptr %slot1281, align 8
  %v7301 = load i64, ptr %slot1273, align 8
  %p7302 = inttoptr i64 %v7301 to ptr
  %rgep7303 = getelementptr i8, ptr %p7302, i64 -24
  store i64 %v7300, ptr %rgep7303, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1773
bb_rcgclear1773:
  %v7304 = load i64, ptr %slot1269, align 8
  %p7305 = inttoptr i64 %v7304 to ptr
  store i64 0, ptr %p7305, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1773
bb_rcgdone1773:
  br label %bb_rcslotdone1757
bb_rcslotowner1757:
  %v7306 = load i64, ptr %slot46, align 8
  store i64 %v7306, ptr %slot1286, align 8
  %v7307 = load i64, ptr %slot1269, align 8
  %p7308 = inttoptr i64 %v7307 to ptr
  %ld7309 = load i64, ptr %p7308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7309, ptr %slot1287, align 8
  %v7310 = load i64, ptr %slot1287, align 8
  %cmp7311 = icmp ne i64 %v7310, 0
  %cv7312 = zext i1 %cmp7311 to i32
  store i32 %cv7312, ptr %slot1288, align 8
  %v7313 = load i32, ptr %slot1288, align 8
  %cv7314 = zext i32 %v7313 to i64
  %cond7315 = icmp ne i64 %cv7314, 0
  br i1 %cond7315, label %bb_rcgnn1788, label %bb_rcgdone1788
bb_rcgnn1788:
  %v7316 = load i64, ptr %slot1287, align 8
  %op7317 = sub i64 %v7316, 16
  store i64 %op7317, ptr %slot1289, align 8
  %v7318 = load i64, ptr %slot1287, align 8
  %p7319 = inttoptr i64 %v7318 to ptr
  %rgep7320 = getelementptr i8, ptr %p7319, i64 -16
  %ld7321 = load i64, ptr %rgep7320, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7321, ptr %slot1290, align 8
  %v7322 = load i64, ptr %slot1290, align 8
  %op7323 = and i64 %v7322, 4611686018427387906
  store i64 %op7323, ptr %slot1291, align 8
  %v7324 = load i64, ptr %slot1291, align 8
  %cmp7325 = icmp ne i64 %v7324, 0
  %cv7326 = zext i1 %cmp7325 to i32
  store i32 %cv7326, ptr %slot1292, align 8
  %v7327 = load i32, ptr %slot1292, align 8
  %cv7328 = zext i32 %v7327 to i64
  %cond7329 = icmp ne i64 %cv7328, 0
  br i1 %cond7329, label %bb_rcgclear1788, label %bb_rcgcounted1788
bb_rcgcounted1788:
  %v7330 = load i64, ptr %slot1287, align 8
  %op7331 = sub i64 %v7330, 32
  store i64 %op7331, ptr %slot1293, align 8
  %v7332 = load i64, ptr %slot1287, align 8
  %p7333 = inttoptr i64 %v7332 to ptr
  %rgep7334 = getelementptr i8, ptr %p7333, i64 -32
  %ld7335 = load i64, ptr %rgep7334, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7335, ptr %slot1294, align 8
  %v7336 = load i64, ptr %slot1294, align 8
  %op7337 = sub i64 %v7336, 1
  store i64 %op7337, ptr %slot1295, align 8
  %v7338 = load i64, ptr %slot1295, align 8
  %cmp7339 = icmp eq i64 %v7338, 0
  %cv7340 = zext i1 %cmp7339 to i32
  store i32 %cv7340, ptr %slot1296, align 8
  %v7341 = load i32, ptr %slot1296, align 8
  %cv7342 = zext i32 %v7341 to i64
  %cond7343 = icmp ne i64 %cv7342, 0
  br i1 %cond7343, label %bb_rcglast1788, label %bb_rcgdec1788
bb_rcglast1788:
  %v7344 = load i64, ptr %slot1287, align 8
  %op7345 = sub i64 %v7344, 24
  store i64 %op7345, ptr %slot1297, align 8
  %v7346 = load i64, ptr %slot1287, align 8
  %p7347 = inttoptr i64 %v7346 to ptr
  %rgep7348 = getelementptr i8, ptr %p7347, i64 -24
  %ld7349 = load i64, ptr %rgep7348, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7349, ptr %slot1298, align 8
  %v7350 = load i64, ptr %slot1298, align 8
  %cmp7351 = icmp ne i64 %v7350, 0
  %cv7352 = zext i1 %cmp7351 to i32
  store i32 %cv7352, ptr %slot1299, align 8
  %v7353 = load i32, ptr %slot1299, align 8
  %cv7354 = zext i32 %v7353 to i64
  %cond7355 = icmp ne i64 %cv7354, 0
  br i1 %cond7355, label %bb_rcgdec1788, label %bb_rcgslow1788
bb_rcgslow1788:
  %v7356 = load i64, ptr %slot1286, align 8
  %v7357 = load i64, ptr %slot1269, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v7356, i64 %v7357) nomerge, !dbg !204
  br label %bb_rcgdone1788
bb_rcgdec1788:
  %v7358 = load i64, ptr %slot1295, align 8
  %v7359 = load i64, ptr %slot1287, align 8
  %p7360 = inttoptr i64 %v7359 to ptr
  %rgep7361 = getelementptr i8, ptr %p7360, i64 -32
  store i64 %v7358, ptr %rgep7361, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1788
bb_rcgclear1788:
  %v7362 = load i64, ptr %slot1269, align 8
  %p7363 = inttoptr i64 %v7362 to ptr
  store i64 0, ptr %p7363, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1788
bb_rcgdone1788:
  br label %bb_rcslotdone1757
bb_rcslotdone1757:
  %v7364 = load i64, ptr %slot38, align 8
  store i64 %v7364, ptr %slot1300, align 8
  %v7365 = load i64, ptr %slot27, align 8
  store i64 %v7365, ptr %slot1301, align 8
  %v7366 = load i64, ptr %slot1301, align 8
  %v7367 = load i64, ptr %slot1300, align 8
  %p7368 = inttoptr i64 %v7366 to ptr
  %p7369 = inttoptr i64 %v7367 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7369, ptr %p7368, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7370 = load i64, ptr %slot18, align 8
  %p7371 = inttoptr i64 %v7370 to ptr
  store i32 0, ptr %p7371, align 4, !alias.scope !3, !noalias !4
  %v7372 = load i64, ptr %slot11, align 8
  %p7373 = inttoptr i64 %v7372 to ptr
  store i32 2, ptr %p7373, align 4, !alias.scope !3, !noalias !4
  %v7374 = load i64, ptr %slot19, align 8
  %p7375 = inttoptr i64 %v7374 to ptr
  %ld7376 = load i32, ptr %p7375, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7376, ptr %slot1302, align 8
  %v7377 = load i32, ptr %slot1302, align 8
  %v7378 = load i64, ptr %slot11, align 8
  %p7379 = inttoptr i64 %v7378 to ptr
  store i32 %v7377, ptr %p7379, align 4, !alias.scope !3, !noalias !4
  %v7380 = load i64, ptr %slot10, align 8
  %p7381 = inttoptr i64 %v7380 to ptr
  store i32 1, ptr %p7381, align 4, !alias.scope !3, !noalias !4
  %v7382 = load i64, ptr %slot38, align 8
  %p7383 = inttoptr i64 %v7382 to ptr
  %ld7384 = load i64, ptr %p7383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7384, ptr %slot1303, align 8
  %v7385 = load i64, ptr %slot1303, align 8
  %v7386 = load i64, ptr %slot41, align 8
  %p7387 = inttoptr i64 %v7386 to ptr
  store i64 %v7385, ptr %p7387, align 8, !alias.scope !3, !noalias !4
  %v7388 = load i64, ptr %slot29, align 8
  %p7389 = inttoptr i64 %v7388 to ptr
  %ld7390 = load i64, ptr %p7389, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7390, ptr %slot1304, align 8
  %v7391 = load i64, ptr %slot1304, align 8
  %v7392 = load i64, ptr %slot42, align 8
  %p7393 = inttoptr i64 %v7392 to ptr
  store i64 %v7391, ptr %p7393, align 8, !alias.scope !3, !noalias !4
  %v7394 = load i64, ptr %slot42, align 8
  %p7395 = inttoptr i64 %v7394 to ptr
  %ld7396 = load i64, ptr %p7395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7396, ptr %slot1305, align 8
  %v7397 = load i64, ptr %slot1305, align 8
  %op7398 = add i64 %v7397, 8
  store i64 %op7398, ptr %slot1306, align 8
  %v7399 = load i64, ptr %slot1306, align 8
  %p7400 = inttoptr i64 %v7399 to ptr
  %ld7401 = load i64, ptr %p7400, align 8
  store i64 %ld7401, ptr %slot1307, align 8
  %v7402 = load i64, ptr %slot1307, align 8
  %v7403 = load i64, ptr %slot42, align 8
  %p7404 = inttoptr i64 %v7403 to ptr
  store i64 %v7402, ptr %p7404, align 8, !alias.scope !3, !noalias !4
  %v7405 = load i64, ptr %slot29, align 8
  %p7406 = inttoptr i64 %v7405 to ptr
  %ld7407 = load i64, ptr %p7406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7407, ptr %slot1308, align 8
  %v7408 = load i64, ptr %slot1308, align 8
  %v7409 = load i64, ptr %slot43, align 8
  %p7410 = inttoptr i64 %v7409 to ptr
  store i64 %v7408, ptr %p7410, align 8, !alias.scope !3, !noalias !4
  %v7411 = load i64, ptr %slot43, align 8
  %p7412 = inttoptr i64 %v7411 to ptr
  %ld7413 = load i64, ptr %p7412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7413, ptr %slot1309, align 8
  %v7414 = load i64, ptr %slot1309, align 8
  %op7415 = add i64 %v7414, 16
  store i64 %op7415, ptr %slot1310, align 8
  %v7416 = load i64, ptr %slot1310, align 8
  %p7417 = inttoptr i64 %v7416 to ptr
  %ld7418 = load i64, ptr %p7417, align 8
  store i64 %ld7418, ptr %slot1311, align 8
  %v7419 = load i64, ptr %slot1311, align 8
  %v7420 = load i64, ptr %slot43, align 8
  %p7421 = inttoptr i64 %v7420 to ptr
  store i64 %v7419, ptr %p7421, align 8, !alias.scope !3, !noalias !4
  %v7422 = load i64, ptr %slot45, align 8
  store i64 %v7422, ptr %slot1312, align 8
  %v7423 = load i64, ptr %slot1312, align 8
  %p7424 = inttoptr i64 %v7423 to ptr
  store i64 0, ptr %p7424, align 8, !alias.scope !3, !noalias !4
  %v7425 = load i64, ptr %slot1312, align 8
  %p7427 = inttoptr i64 %v7425 to ptr
  %gep7428 = getelementptr i8, ptr %p7427, i64 8
  %op7426 = ptrtoint ptr %gep7428 to i64
  store i64 %op7426, ptr %slot1313, align 8
  %v7429 = load i64, ptr %slot1313, align 8
  %p7430 = inttoptr i64 %v7429 to ptr
  store i64 0, ptr %p7430, align 8, !alias.scope !3, !noalias !4
  %v7431 = load i64, ptr %slot1312, align 8
  %p7433 = inttoptr i64 %v7431 to ptr
  %gep7434 = getelementptr i8, ptr %p7433, i64 16
  %op7432 = ptrtoint ptr %gep7434 to i64
  store i64 %op7432, ptr %slot1314, align 8
  %v7435 = load i64, ptr %slot1314, align 8
  %p7436 = inttoptr i64 %v7435 to ptr
  store i64 0, ptr %p7436, align 8, !alias.scope !3, !noalias !4
  %v7437 = load i64, ptr %slot1312, align 8
  %p7439 = inttoptr i64 %v7437 to ptr
  %gep7440 = getelementptr i8, ptr %p7439, i64 24
  %op7438 = ptrtoint ptr %gep7440 to i64
  store i64 %op7438, ptr %slot1315, align 8
  %v7441 = load i64, ptr %slot1315, align 8
  %p7442 = inttoptr i64 %v7441 to ptr
  store i64 0, ptr %p7442, align 8, !alias.scope !3, !noalias !4
  %v7443 = load i64, ptr %slot1312, align 8
  %p7445 = inttoptr i64 %v7443 to ptr
  %gep7446 = getelementptr i8, ptr %p7445, i64 32
  %op7444 = ptrtoint ptr %gep7446 to i64
  store i64 %op7444, ptr %slot1316, align 8
  %v7447 = load i64, ptr %slot1316, align 8
  %p7448 = inttoptr i64 %v7447 to ptr
  store i64 0, ptr %p7448, align 8, !alias.scope !3, !noalias !4
  %v7449 = load i64, ptr %slot20, align 8
  %p7450 = inttoptr i64 %v7449 to ptr
  store i32 1, ptr %p7450, align 4, !alias.scope !3, !noalias !4
  %v7451 = load i64, ptr %slot47, align 8
  store i64 %v7451, ptr %slot1317, align 8
  %v7452 = load i64, ptr %slot39, align 8
  %p7453 = inttoptr i64 %v7452 to ptr
  %ld7454 = load i64, ptr %p7453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7454, ptr %slot1318, align 8
  %v7455 = load i64, ptr %slot1318, align 8
  %v7456 = load i64, ptr %slot24, align 8
  %p7457 = inttoptr i64 %v7456 to ptr
  store i64 %v7455, ptr %p7457, align 8, !alias.scope !3, !noalias !4
  %v7458 = load i64, ptr %slot24, align 8
  store i64 %v7458, ptr %slot1319, align 8
  %v7459 = load i64, ptr %slot1312, align 8
  %p7461 = inttoptr i64 %v7459 to ptr
  %gep7462 = getelementptr i8, ptr %p7461, i64 0
  %op7460 = ptrtoint ptr %gep7462 to i64
  store i64 %op7460, ptr %slot1320, align 8
  %v7463 = load i64, ptr %slot39, align 8
  %p7464 = inttoptr i64 %v7463 to ptr
  %ld7465 = load i64, ptr %p7464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7465, ptr %slot1321, align 8
  %v7466 = load i64, ptr %slot1321, align 8
  %v7467 = load i64, ptr %slot24, align 8
  %p7468 = inttoptr i64 %v7467 to ptr
  store i64 %v7466, ptr %p7468, align 8, !alias.scope !3, !noalias !4
  %v7469 = load i64, ptr %slot24, align 8
  store i64 %v7469, ptr %slot1322, align 8
  %v7470 = load i64, ptr %slot12, align 8
  %p7471 = inttoptr i64 %v7470 to ptr
  %ld7472 = load i32, ptr %p7471, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7472, ptr %slot1323, align 8
  %v7473 = load i64, ptr %slot13, align 8
  %p7474 = inttoptr i64 %v7473 to ptr
  %ld7475 = load i32, ptr %p7474, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7475, ptr %slot1324, align 8
  %v7476 = load i32, ptr %slot1324, align 8
  %op7477 = and i32 %v7476, 24
  store i32 %op7477, ptr %slot1324, align 8
  %v7478 = load i32, ptr %slot1324, align 8
  %cmp7479 = icmp eq i32 %v7478, 0
  %cv7480 = zext i1 %cmp7479 to i32
  store i32 %cv7480, ptr %slot1325, align 8
  %v7481 = load i32, ptr %slot1323, align 8
  %v7482 = load i32, ptr %slot1325, align 8
  %op7483 = and i32 %v7481, %v7482
  store i32 %op7483, ptr %slot1326, align 8
  %v7484 = load i32, ptr %slot1326, align 8
  %cv7485 = zext i32 %v7484 to i64
  %cond7486 = icmp ne i64 %cv7485, 0
  br i1 %cond7486, label %bb_rctake1821, label %bb_rccopy1821
bb_rctake1821:
  %v7487 = load i64, ptr %slot27, align 8
  store i64 %v7487, ptr %slot1327, align 8
  %v7488 = load i64, ptr %slot47, align 8
  store i64 %v7488, ptr %slot1328, align 8
  %v7489 = load i64, ptr %slot1322, align 8
  %v7490 = load i64, ptr %slot1327, align 8
  %op7491 = sub i64 %v7489, %v7490
  store i64 %op7491, ptr %slot1329, align 8
  %v7492 = load i64, ptr %slot1327, align 8
  %v7493 = load i64, ptr %slot1322, align 8
  %op7494 = sub i64 %v7492, %v7493
  store i64 %op7494, ptr %slot1330, align 8
  %v7495 = load i64, ptr %slot1329, align 8
  %cmp7496 = icmp ult i64 %v7495, 8
  %cv7497 = zext i1 %cmp7496 to i32
  store i32 %cv7497, ptr %slot1331, align 8
  %v7498 = load i64, ptr %slot1330, align 8
  %cmp7499 = icmp ult i64 %v7498, 8
  %cv7500 = zext i1 %cmp7499 to i32
  store i32 %cv7500, ptr %slot1332, align 8
  %v7501 = load i32, ptr %slot1331, align 8
  %v7502 = load i32, ptr %slot1332, align 8
  %op7503 = or i32 %v7501, %v7502
  store i32 %op7503, ptr %slot1333, align 8
  %v7504 = load i32, ptr %slot1333, align 8
  %cv7505 = zext i32 %v7504 to i64
  %cond7506 = icmp ne i64 %cv7505, 0
  br i1 %cond7506, label %bb_rcmoveslow1830, label %bb_rcmovecheck1830
bb_rcmovecheck1830:
  %v7507 = load i64, ptr %slot1322, align 8
  %p7509 = inttoptr i64 %v7507 to ptr
  %gep7510 = getelementptr i8, ptr %p7509, i64 0
  %op7508 = ptrtoint ptr %gep7510 to i64
  store i64 %op7508, ptr %slot1334, align 8
  %v7511 = load i64, ptr %slot1334, align 8
  %p7512 = inttoptr i64 %v7511 to ptr
  %ld7513 = load i64, ptr %p7512, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7513, ptr %slot1335, align 8
  %v7514 = load i64, ptr %slot1335, align 8
  %cmp7515 = icmp ne i64 %v7514, 0
  %cv7516 = zext i1 %cmp7515 to i32
  store i32 %cv7516, ptr %slot1336, align 8
  %v7517 = load i32, ptr %slot1336, align 8
  %cv7518 = zext i32 %v7517 to i64
  %cond7519 = icmp ne i64 %cv7518, 0
  br i1 %cond7519, label %bb_rcmoveheader1838, label %bb_rcmovenext1838
bb_rcmoveheader1838:
  %v7520 = load i64, ptr %slot1335, align 8
  %op7521 = sub i64 %v7520, 16
  store i64 %op7521, ptr %slot1337, align 8
  %v7522 = load i64, ptr %slot1335, align 8
  %p7523 = inttoptr i64 %v7522 to ptr
  %rgep7524 = getelementptr i8, ptr %p7523, i64 -16
  %ld7525 = load i64, ptr %rgep7524, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7525, ptr %slot1338, align 8
  %v7526 = load i64, ptr %slot1338, align 8
  %op7527 = and i64 %v7526, 5764607523034234881
  store i64 %op7527, ptr %slot1339, align 8
  %v7528 = load i64, ptr %slot1339, align 8
  %cmp7529 = icmp ne i64 %v7528, 0
  %cv7530 = zext i1 %cmp7529 to i32
  store i32 %cv7530, ptr %slot1340, align 8
  %v7531 = load i32, ptr %slot1340, align 8
  %cv7532 = zext i32 %v7531 to i64
  %cond7533 = icmp ne i64 %cv7532, 0
  br i1 %cond7533, label %bb_rcmoveslow1830, label %bb_rcmovenext1838
bb_rcmovenext1838:
  %v7534 = load i64, ptr %slot1322, align 8
  %v7535 = load i64, ptr %slot1327, align 8
  %p7536 = inttoptr i64 %v7534 to ptr
  %p7537 = inttoptr i64 %v7535 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7537, ptr %p7536, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7538 = load i64, ptr %slot1322, align 8
  %p7539 = inttoptr i64 %v7538 to ptr
  store i64 0, ptr %p7539, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1830
bb_rcmoveslow1830:
  %v7540 = load i64, ptr %slot46, align 8
  %v7541 = load i64, ptr %slot1327, align 8
  %v7542 = load i64, ptr %slot1322, align 8
  %v7543 = load i64, ptr %slot1328, align 8
  %cv7544 = trunc i64 %v7543 to i32
  %call7545 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64 %v7540, i64 %v7541, i64 %v7542, i32 %cv7544) nomerge, !dbg !206
  store i32 %call7545, ptr %slot1341, align 8
  %v7546 = load i32, ptr %slot1341, align 8
  %cv7547 = zext i32 %v7546 to i64
  %cond7548 = icmp ne i64 %cv7547, 0
  br i1 %cond7548, label %bb_rcsuccess1845, label %bb_rcfailure1845
bb_rcfailure1845:
  %v7549 = load i64, ptr %slot46, align 8
  %p7550 = inttoptr i64 %v7549 to ptr
  %call7551 = call i32 @myl_rc_take_failure(ptr %p7550) nomerge, !dbg !206
  store i32 %call7551, ptr %slot1342, align 8
  %v7552 = load i64, ptr %slot1, align 8
  %p7553 = inttoptr i64 %v7552 to ptr
  %v7554 = load i32, ptr %slot1342, align 8
  %call7555 = call i32 @myl_qbe_rc_status(ptr %p7553, i32 %v7554) nomerge, !dbg !206
  store i32 %call7555, ptr %slot1343, align 8
  br label %bb_failure
bb_rcsuccess1845:
  br label %bb_rcmoved1830
bb_rcmoved1830:
  %v7556 = load i64, ptr %slot12, align 8
  %p7557 = inttoptr i64 %v7556 to ptr
  store i32 0, ptr %p7557, align 4, !alias.scope !3, !noalias !4
  %v7558 = load i64, ptr %slot19, align 8
  %p7559 = inttoptr i64 %v7558 to ptr
  store i32 2, ptr %p7559, align 4, !alias.scope !3, !noalias !4
  %v7560 = load i64, ptr %slot18, align 8
  %p7561 = inttoptr i64 %v7560 to ptr
  store i32 1, ptr %p7561, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1821
bb_rccopy1821:
  %v7562 = load i64, ptr %slot27, align 8
  store i64 %v7562, ptr %slot1344, align 8
  %v7563 = load i64, ptr %slot47, align 8
  store i64 %v7563, ptr %slot1345, align 8
  %v7564 = load i64, ptr %slot1322, align 8
  %p7565 = inttoptr i64 %v7564 to ptr
  %ld7566 = load i64, ptr %p7565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7566, ptr %slot1346, align 8
  %v7567 = load i64, ptr %slot1346, align 8
  %cmp7568 = icmp ne i64 %v7567, 0
  %cv7569 = zext i1 %cmp7568 to i32
  store i32 %cv7569, ptr %slot1347, align 8
  %v7570 = load i32, ptr %slot1347, align 8
  %cv7571 = zext i32 %v7570 to i64
  %cond7572 = icmp ne i64 %cv7571, 0
  br i1 %cond7572, label %bb_rcgnn1854, label %bb_rcgplain1854
bb_rcgnn1854:
  %v7573 = load i64, ptr %slot1346, align 8
  %op7574 = sub i64 %v7573, 16
  store i64 %op7574, ptr %slot1348, align 8
  %v7575 = load i64, ptr %slot1346, align 8
  %p7576 = inttoptr i64 %v7575 to ptr
  %rgep7577 = getelementptr i8, ptr %p7576, i64 -16
  %ld7578 = load i64, ptr %rgep7577, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7578, ptr %slot1349, align 8
  %v7579 = load i64, ptr %slot1349, align 8
  %op7580 = and i64 %v7579, 4611686018427387906
  store i64 %op7580, ptr %slot1350, align 8
  %v7581 = load i64, ptr %slot1350, align 8
  %cmp7582 = icmp ne i64 %v7581, 0
  %cv7583 = zext i1 %cmp7582 to i32
  store i32 %cv7583, ptr %slot1351, align 8
  %v7584 = load i32, ptr %slot1351, align 8
  %cv7585 = zext i32 %v7584 to i64
  %cond7586 = icmp ne i64 %cv7585, 0
  br i1 %cond7586, label %bb_rcgspecial1854, label %bb_rcginc1854
bb_rcginc1854:
  %v7587 = load i64, ptr %slot1346, align 8
  %op7588 = sub i64 %v7587, 32
  store i64 %op7588, ptr %slot1352, align 8
  %v7589 = load i64, ptr %slot1346, align 8
  %p7590 = inttoptr i64 %v7589 to ptr
  %rgep7591 = getelementptr i8, ptr %p7590, i64 -32
  %ld7592 = load i64, ptr %rgep7591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7592, ptr %slot1353, align 8
  %v7593 = load i64, ptr %slot1353, align 8
  %op7594 = add i64 %v7593, 1
  store i64 %op7594, ptr %slot1354, align 8
  %v7595 = load i64, ptr %slot1354, align 8
  %cmp7596 = icmp eq i64 %v7595, 0
  %cv7597 = zext i1 %cmp7596 to i32
  store i32 %cv7597, ptr %slot1355, align 8
  %v7598 = load i32, ptr %slot1355, align 8
  %cv7599 = zext i32 %v7598 to i64
  %cond7600 = icmp ne i64 %cv7599, 0
  br i1 %cond7600, label %bb_rcglimit1854, label %bb_rcgcapacity1854
bb_rcglimit1854:
  %v7601 = load i64, ptr %slot1, align 8
  %p7602 = inttoptr i64 %v7601 to ptr
  %call7603 = call i32 @myl_qbe_rc_status(ptr %p7602, i32 2) nomerge, !dbg !206
  store i32 %call7603, ptr %slot1356, align 8
  br label %bb_failure
bb_rcgcapacity1854:
  %v7604 = load i64, ptr %slot1354, align 8
  %v7605 = load i64, ptr %slot1346, align 8
  %p7606 = inttoptr i64 %v7605 to ptr
  %rgep7607 = getelementptr i8, ptr %p7606, i64 -32
  store i64 %v7604, ptr %rgep7607, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1854
bb_rcgspecial1854:
  %v7608 = load i64, ptr %slot1349, align 8
  %op7609 = and i64 %v7608, 4611686018427387904
  store i64 %op7609, ptr %slot1357, align 8
  %v7610 = load i64, ptr %slot1357, align 8
  %cmp7611 = icmp ne i64 %v7610, 0
  %cv7612 = zext i1 %cmp7611 to i32
  store i32 %cv7612, ptr %slot1358, align 8
  %v7613 = load i32, ptr %slot1358, align 8
  %cv7614 = zext i32 %v7613 to i64
  %cond7615 = icmp ne i64 %cv7614, 0
  br i1 %cond7615, label %bb_rcgslow1854, label %bb_rcgplain1854
bb_rcgslow1854:
  %v7616 = load i64, ptr %slot46, align 8
  %v7617 = load i64, ptr %slot1344, align 8
  %v7618 = load i64, ptr %slot1322, align 8
  %v7619 = load i64, ptr %slot1345, align 8
  %cv7620 = trunc i64 %v7619 to i32
  %call7621 = call i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_retain(i64 %v7616, i64 %v7617, i64 %v7618, i32 %cv7620) nomerge, !dbg !206
  store i32 %call7621, ptr %slot1359, align 8
  %v7622 = load i32, ptr %slot1359, align 8
  %cv7623 = zext i32 %v7622 to i64
  %cond7624 = icmp ne i64 %cv7623, 0
  br i1 %cond7624, label %bb_rcsuccess1868, label %bb_rcfailure1868
bb_rcfailure1868:
  %v7625 = load i64, ptr %slot46, align 8
  %p7626 = inttoptr i64 %v7625 to ptr
  %call7627 = call i32 @myl_rc_take_failure(ptr %p7626) nomerge, !dbg !206
  store i32 %call7627, ptr %slot1360, align 8
  %v7628 = load i64, ptr %slot1, align 8
  %p7629 = inttoptr i64 %v7628 to ptr
  %v7630 = load i32, ptr %slot1360, align 8
  %call7631 = call i32 @myl_qbe_rc_status(ptr %p7629, i32 %v7630) nomerge, !dbg !206
  store i32 %call7631, ptr %slot1361, align 8
  br label %bb_failure
bb_rcsuccess1868:
  br label %bb_rcgdone1854
bb_rcgplain1854:
  %v7632 = load i64, ptr %slot1346, align 8
  %v7633 = load i64, ptr %slot1344, align 8
  %p7634 = inttoptr i64 %v7633 to ptr
  store i64 %v7632, ptr %p7634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1854
bb_rcgdone1854:
  %v7635 = load i64, ptr %slot19, align 8
  %p7636 = inttoptr i64 %v7635 to ptr
  store i32 2, ptr %p7636, align 4, !alias.scope !3, !noalias !4
  %v7637 = load i64, ptr %slot18, align 8
  %p7638 = inttoptr i64 %v7637 to ptr
  store i32 1, ptr %p7638, align 4, !alias.scope !3, !noalias !4
  %v7639 = load i64, ptr %slot12, align 8
  %p7640 = inttoptr i64 %v7639 to ptr
  %ld7641 = load i32, ptr %p7640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7641, ptr %slot1362, align 8
  %v7642 = load i32, ptr %slot1362, align 8
  %cv7643 = zext i32 %v7642 to i64
  %cond7644 = icmp ne i64 %cv7643, 0
  br i1 %cond7644, label %bb_rcslotdrop1875, label %bb_rcslotdone1875
bb_rcslotdrop1875:
  %v7645 = load i64, ptr %slot12, align 8
  %p7646 = inttoptr i64 %v7645 to ptr
  store i32 0, ptr %p7646, align 4, !alias.scope !3, !noalias !4
  %v7647 = load i64, ptr %slot21, align 8
  store i64 %v7647, ptr %slot1363, align 8
  %v7648 = load i64, ptr %slot13, align 8
  %p7649 = inttoptr i64 %v7648 to ptr
  %ld7650 = load i32, ptr %p7649, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7650, ptr %slot1364, align 8
  %v7651 = load i32, ptr %slot1364, align 8
  %op7652 = and i32 %v7651, 28
  store i32 %op7652, ptr %slot1365, align 8
  %v7653 = load i32, ptr %slot1365, align 8
  %cv7654 = zext i32 %v7653 to i64
  %cond7655 = icmp ne i64 %cv7654, 0
  br i1 %cond7655, label %bb_rcslotrole1875, label %bb_rcslotowner1875
bb_rcslotrole1875:
  %v7656 = load i64, ptr %slot46, align 8
  store i64 %v7656, ptr %slot1366, align 8
  %v7657 = load i64, ptr %slot1363, align 8
  %p7658 = inttoptr i64 %v7657 to ptr
  %ld7659 = load i64, ptr %p7658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7659, ptr %slot1367, align 8
  %v7660 = load i64, ptr %slot1367, align 8
  %cmp7661 = icmp ne i64 %v7660, 0
  %cv7662 = zext i1 %cmp7661 to i32
  store i32 %cv7662, ptr %slot1368, align 8
  %v7663 = load i32, ptr %slot1368, align 8
  %cv7664 = zext i32 %v7663 to i64
  %cond7665 = icmp ne i64 %cv7664, 0
  br i1 %cond7665, label %bb_rcgnn1891, label %bb_rcgdone1891
bb_rcgnn1891:
  %v7666 = load i64, ptr %slot1367, align 8
  %op7667 = sub i64 %v7666, 16
  store i64 %op7667, ptr %slot1369, align 8
  %v7668 = load i64, ptr %slot1367, align 8
  %p7669 = inttoptr i64 %v7668 to ptr
  %rgep7670 = getelementptr i8, ptr %p7669, i64 -16
  %ld7671 = load i64, ptr %rgep7670, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7671, ptr %slot1370, align 8
  %v7672 = load i64, ptr %slot1370, align 8
  %op7673 = and i64 %v7672, 4611686018427387906
  store i64 %op7673, ptr %slot1371, align 8
  %v7674 = load i64, ptr %slot1371, align 8
  %cmp7675 = icmp ne i64 %v7674, 0
  %cv7676 = zext i1 %cmp7675 to i32
  store i32 %cv7676, ptr %slot1372, align 8
  %v7677 = load i32, ptr %slot1372, align 8
  %cv7678 = zext i32 %v7677 to i64
  %cond7679 = icmp ne i64 %cv7678, 0
  br i1 %cond7679, label %bb_rcgclear1891, label %bb_rcgcounted1891
bb_rcgcounted1891:
  %v7680 = load i64, ptr %slot1367, align 8
  %op7681 = sub i64 %v7680, 24
  store i64 %op7681, ptr %slot1373, align 8
  %v7682 = load i64, ptr %slot1367, align 8
  %p7683 = inttoptr i64 %v7682 to ptr
  %rgep7684 = getelementptr i8, ptr %p7683, i64 -24
  %ld7685 = load i64, ptr %rgep7684, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7685, ptr %slot1374, align 8
  %v7686 = load i64, ptr %slot1374, align 8
  %op7687 = sub i64 %v7686, 1
  store i64 %op7687, ptr %slot1375, align 8
  %v7688 = load i64, ptr %slot1375, align 8
  %cmp7689 = icmp eq i64 %v7688, 0
  %cv7690 = zext i1 %cmp7689 to i32
  store i32 %cv7690, ptr %slot1376, align 8
  %v7691 = load i32, ptr %slot1376, align 8
  %cv7692 = zext i32 %v7691 to i64
  %cond7693 = icmp ne i64 %cv7692, 0
  br i1 %cond7693, label %bb_rcglast1891, label %bb_rcgdec1891
bb_rcglast1891:
  %v7694 = load i64, ptr %slot1367, align 8
  %op7695 = sub i64 %v7694, 32
  store i64 %op7695, ptr %slot1377, align 8
  %v7696 = load i64, ptr %slot1367, align 8
  %p7697 = inttoptr i64 %v7696 to ptr
  %rgep7698 = getelementptr i8, ptr %p7697, i64 -32
  %ld7699 = load i64, ptr %rgep7698, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7699, ptr %slot1378, align 8
  %v7700 = load i64, ptr %slot1378, align 8
  %cmp7701 = icmp ne i64 %v7700, 0
  %cv7702 = zext i1 %cmp7701 to i32
  store i32 %cv7702, ptr %slot1379, align 8
  %v7703 = load i32, ptr %slot1379, align 8
  %cv7704 = zext i32 %v7703 to i64
  %cond7705 = icmp ne i64 %cv7704, 0
  br i1 %cond7705, label %bb_rcgdec1891, label %bb_rcgslow1891
bb_rcgslow1891:
  %v7706 = load i64, ptr %slot1366, align 8
  %v7707 = load i64, ptr %slot1363, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v7706, i64 %v7707) nomerge, !dbg !206
  br label %bb_rcgdone1891
bb_rcgdec1891:
  %v7708 = load i64, ptr %slot1375, align 8
  %v7709 = load i64, ptr %slot1367, align 8
  %p7710 = inttoptr i64 %v7709 to ptr
  %rgep7711 = getelementptr i8, ptr %p7710, i64 -24
  store i64 %v7708, ptr %rgep7711, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1891
bb_rcgclear1891:
  %v7712 = load i64, ptr %slot1363, align 8
  %p7713 = inttoptr i64 %v7712 to ptr
  store i64 0, ptr %p7713, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1891
bb_rcgdone1891:
  br label %bb_rcslotdone1875
bb_rcslotowner1875:
  %v7714 = load i64, ptr %slot46, align 8
  store i64 %v7714, ptr %slot1380, align 8
  %v7715 = load i64, ptr %slot1363, align 8
  %p7716 = inttoptr i64 %v7715 to ptr
  %ld7717 = load i64, ptr %p7716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7717, ptr %slot1381, align 8
  %v7718 = load i64, ptr %slot1381, align 8
  %cmp7719 = icmp ne i64 %v7718, 0
  %cv7720 = zext i1 %cmp7719 to i32
  store i32 %cv7720, ptr %slot1382, align 8
  %v7721 = load i32, ptr %slot1382, align 8
  %cv7722 = zext i32 %v7721 to i64
  %cond7723 = icmp ne i64 %cv7722, 0
  br i1 %cond7723, label %bb_rcgnn1906, label %bb_rcgdone1906
bb_rcgnn1906:
  %v7724 = load i64, ptr %slot1381, align 8
  %op7725 = sub i64 %v7724, 16
  store i64 %op7725, ptr %slot1383, align 8
  %v7726 = load i64, ptr %slot1381, align 8
  %p7727 = inttoptr i64 %v7726 to ptr
  %rgep7728 = getelementptr i8, ptr %p7727, i64 -16
  %ld7729 = load i64, ptr %rgep7728, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7729, ptr %slot1384, align 8
  %v7730 = load i64, ptr %slot1384, align 8
  %op7731 = and i64 %v7730, 4611686018427387906
  store i64 %op7731, ptr %slot1385, align 8
  %v7732 = load i64, ptr %slot1385, align 8
  %cmp7733 = icmp ne i64 %v7732, 0
  %cv7734 = zext i1 %cmp7733 to i32
  store i32 %cv7734, ptr %slot1386, align 8
  %v7735 = load i32, ptr %slot1386, align 8
  %cv7736 = zext i32 %v7735 to i64
  %cond7737 = icmp ne i64 %cv7736, 0
  br i1 %cond7737, label %bb_rcgclear1906, label %bb_rcgcounted1906
bb_rcgcounted1906:
  %v7738 = load i64, ptr %slot1381, align 8
  %op7739 = sub i64 %v7738, 32
  store i64 %op7739, ptr %slot1387, align 8
  %v7740 = load i64, ptr %slot1381, align 8
  %p7741 = inttoptr i64 %v7740 to ptr
  %rgep7742 = getelementptr i8, ptr %p7741, i64 -32
  %ld7743 = load i64, ptr %rgep7742, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7743, ptr %slot1388, align 8
  %v7744 = load i64, ptr %slot1388, align 8
  %op7745 = sub i64 %v7744, 1
  store i64 %op7745, ptr %slot1389, align 8
  %v7746 = load i64, ptr %slot1389, align 8
  %cmp7747 = icmp eq i64 %v7746, 0
  %cv7748 = zext i1 %cmp7747 to i32
  store i32 %cv7748, ptr %slot1390, align 8
  %v7749 = load i32, ptr %slot1390, align 8
  %cv7750 = zext i32 %v7749 to i64
  %cond7751 = icmp ne i64 %cv7750, 0
  br i1 %cond7751, label %bb_rcglast1906, label %bb_rcgdec1906
bb_rcglast1906:
  %v7752 = load i64, ptr %slot1381, align 8
  %op7753 = sub i64 %v7752, 24
  store i64 %op7753, ptr %slot1391, align 8
  %v7754 = load i64, ptr %slot1381, align 8
  %p7755 = inttoptr i64 %v7754 to ptr
  %rgep7756 = getelementptr i8, ptr %p7755, i64 -24
  %ld7757 = load i64, ptr %rgep7756, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7757, ptr %slot1392, align 8
  %v7758 = load i64, ptr %slot1392, align 8
  %cmp7759 = icmp ne i64 %v7758, 0
  %cv7760 = zext i1 %cmp7759 to i32
  store i32 %cv7760, ptr %slot1393, align 8
  %v7761 = load i32, ptr %slot1393, align 8
  %cv7762 = zext i32 %v7761 to i64
  %cond7763 = icmp ne i64 %cv7762, 0
  br i1 %cond7763, label %bb_rcgdec1906, label %bb_rcgslow1906
bb_rcgslow1906:
  %v7764 = load i64, ptr %slot1380, align 8
  %v7765 = load i64, ptr %slot1363, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v7764, i64 %v7765) nomerge, !dbg !206
  br label %bb_rcgdone1906
bb_rcgdec1906:
  %v7766 = load i64, ptr %slot1389, align 8
  %v7767 = load i64, ptr %slot1381, align 8
  %p7768 = inttoptr i64 %v7767 to ptr
  %rgep7769 = getelementptr i8, ptr %p7768, i64 -32
  store i64 %v7766, ptr %rgep7769, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1906
bb_rcgclear1906:
  %v7770 = load i64, ptr %slot1363, align 8
  %p7771 = inttoptr i64 %v7770 to ptr
  store i64 0, ptr %p7771, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1906
bb_rcgdone1906:
  br label %bb_rcslotdone1875
bb_rcslotdone1875:
  br label %bb_rcprepared1821
bb_rcprepared1821:
  %v7772 = load i64, ptr %slot27, align 8
  store i64 %v7772, ptr %slot1394, align 8
  %v7773 = load i64, ptr %slot1394, align 8
  %v7774 = load i64, ptr %slot1320, align 8
  %p7775 = inttoptr i64 %v7773 to ptr
  %p7776 = inttoptr i64 %v7774 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7776, ptr %p7775, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7777 = load i64, ptr %slot18, align 8
  %p7778 = inttoptr i64 %v7777 to ptr
  store i32 0, ptr %p7778, align 4, !alias.scope !3, !noalias !4
  %v7779 = load i64, ptr %slot40, align 8
  %p7780 = inttoptr i64 %v7779 to ptr
  %ld7781 = load i64, ptr %p7780, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7781, ptr %slot1395, align 8
  %v7782 = load i64, ptr %slot1395, align 8
  %v7783 = load i64, ptr %slot25, align 8
  %p7784 = inttoptr i64 %v7783 to ptr
  store i64 %v7782, ptr %p7784, align 8, !alias.scope !3, !noalias !4
  %v7785 = load i64, ptr %slot25, align 8
  store i64 %v7785, ptr %slot1396, align 8
  %v7786 = load i64, ptr %slot1312, align 8
  %p7788 = inttoptr i64 %v7786 to ptr
  %gep7789 = getelementptr i8, ptr %p7788, i64 8
  %op7787 = ptrtoint ptr %gep7789 to i64
  store i64 %op7787, ptr %slot1397, align 8
  %v7790 = load i64, ptr %slot40, align 8
  %p7791 = inttoptr i64 %v7790 to ptr
  %ld7792 = load i64, ptr %p7791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7792, ptr %slot1398, align 8
  %v7793 = load i64, ptr %slot1398, align 8
  %v7794 = load i64, ptr %slot25, align 8
  %p7795 = inttoptr i64 %v7794 to ptr
  store i64 %v7793, ptr %p7795, align 8, !alias.scope !3, !noalias !4
  %v7796 = load i64, ptr %slot25, align 8
  store i64 %v7796, ptr %slot1399, align 8
  %v7797 = load i64, ptr %slot14, align 8
  %p7798 = inttoptr i64 %v7797 to ptr
  %ld7799 = load i32, ptr %p7798, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7799, ptr %slot1400, align 8
  %v7800 = load i64, ptr %slot15, align 8
  %p7801 = inttoptr i64 %v7800 to ptr
  %ld7802 = load i32, ptr %p7801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7802, ptr %slot1401, align 8
  %v7803 = load i32, ptr %slot1401, align 8
  %op7804 = and i32 %v7803, 24
  store i32 %op7804, ptr %slot1401, align 8
  %v7805 = load i32, ptr %slot1401, align 8
  %cmp7806 = icmp eq i32 %v7805, 0
  %cv7807 = zext i1 %cmp7806 to i32
  store i32 %cv7807, ptr %slot1402, align 8
  %v7808 = load i32, ptr %slot1400, align 8
  %v7809 = load i32, ptr %slot1402, align 8
  %op7810 = and i32 %v7808, %v7809
  store i32 %op7810, ptr %slot1403, align 8
  %v7811 = load i32, ptr %slot1403, align 8
  %cv7812 = zext i32 %v7811 to i64
  %cond7813 = icmp ne i64 %cv7812, 0
  br i1 %cond7813, label %bb_rctake1917, label %bb_rccopy1917
bb_rctake1917:
  %v7814 = load i64, ptr %slot27, align 8
  store i64 %v7814, ptr %slot1404, align 8
  %v7815 = load i64, ptr %slot47, align 8
  store i64 %v7815, ptr %slot1405, align 8
  %v7816 = load i64, ptr %slot1399, align 8
  %v7817 = load i64, ptr %slot1404, align 8
  %op7818 = sub i64 %v7816, %v7817
  store i64 %op7818, ptr %slot1406, align 8
  %v7819 = load i64, ptr %slot1404, align 8
  %v7820 = load i64, ptr %slot1399, align 8
  %op7821 = sub i64 %v7819, %v7820
  store i64 %op7821, ptr %slot1407, align 8
  %v7822 = load i64, ptr %slot1406, align 8
  %cmp7823 = icmp ult i64 %v7822, 8
  %cv7824 = zext i1 %cmp7823 to i32
  store i32 %cv7824, ptr %slot1408, align 8
  %v7825 = load i64, ptr %slot1407, align 8
  %cmp7826 = icmp ult i64 %v7825, 8
  %cv7827 = zext i1 %cmp7826 to i32
  store i32 %cv7827, ptr %slot1409, align 8
  %v7828 = load i32, ptr %slot1408, align 8
  %v7829 = load i32, ptr %slot1409, align 8
  %op7830 = or i32 %v7828, %v7829
  store i32 %op7830, ptr %slot1410, align 8
  %v7831 = load i32, ptr %slot1410, align 8
  %cv7832 = zext i32 %v7831 to i64
  %cond7833 = icmp ne i64 %cv7832, 0
  br i1 %cond7833, label %bb_rcmoveslow1926, label %bb_rcmovecheck1926
bb_rcmovecheck1926:
  %v7834 = load i64, ptr %slot1399, align 8
  %p7836 = inttoptr i64 %v7834 to ptr
  %gep7837 = getelementptr i8, ptr %p7836, i64 0
  %op7835 = ptrtoint ptr %gep7837 to i64
  store i64 %op7835, ptr %slot1411, align 8
  %v7838 = load i64, ptr %slot1411, align 8
  %p7839 = inttoptr i64 %v7838 to ptr
  %ld7840 = load i64, ptr %p7839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7840, ptr %slot1412, align 8
  %v7841 = load i64, ptr %slot1412, align 8
  %cmp7842 = icmp ne i64 %v7841, 0
  %cv7843 = zext i1 %cmp7842 to i32
  store i32 %cv7843, ptr %slot1413, align 8
  %v7844 = load i32, ptr %slot1413, align 8
  %cv7845 = zext i32 %v7844 to i64
  %cond7846 = icmp ne i64 %cv7845, 0
  br i1 %cond7846, label %bb_rcmoveheader1934, label %bb_rcmovenext1934
bb_rcmoveheader1934:
  %v7847 = load i64, ptr %slot1412, align 8
  %op7848 = sub i64 %v7847, 16
  store i64 %op7848, ptr %slot1414, align 8
  %v7849 = load i64, ptr %slot1412, align 8
  %p7850 = inttoptr i64 %v7849 to ptr
  %rgep7851 = getelementptr i8, ptr %p7850, i64 -16
  %ld7852 = load i64, ptr %rgep7851, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7852, ptr %slot1415, align 8
  %v7853 = load i64, ptr %slot1415, align 8
  %op7854 = and i64 %v7853, 5764607523034234881
  store i64 %op7854, ptr %slot1416, align 8
  %v7855 = load i64, ptr %slot1416, align 8
  %cmp7856 = icmp ne i64 %v7855, 0
  %cv7857 = zext i1 %cmp7856 to i32
  store i32 %cv7857, ptr %slot1417, align 8
  %v7858 = load i32, ptr %slot1417, align 8
  %cv7859 = zext i32 %v7858 to i64
  %cond7860 = icmp ne i64 %cv7859, 0
  br i1 %cond7860, label %bb_rcmoveslow1926, label %bb_rcmovenext1934
bb_rcmovenext1934:
  %v7861 = load i64, ptr %slot1399, align 8
  %v7862 = load i64, ptr %slot1404, align 8
  %p7863 = inttoptr i64 %v7861 to ptr
  %p7864 = inttoptr i64 %v7862 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7864, ptr %p7863, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7865 = load i64, ptr %slot1399, align 8
  %p7866 = inttoptr i64 %v7865 to ptr
  store i64 0, ptr %p7866, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1926
bb_rcmoveslow1926:
  %v7867 = load i64, ptr %slot46, align 8
  %v7868 = load i64, ptr %slot1404, align 8
  %v7869 = load i64, ptr %slot1399, align 8
  %v7870 = load i64, ptr %slot1405, align 8
  %cv7871 = trunc i64 %v7870 to i32
  %call7872 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v7867, i64 %v7868, i64 %v7869, i32 %cv7871) nomerge, !dbg !206
  store i32 %call7872, ptr %slot1418, align 8
  %v7873 = load i32, ptr %slot1418, align 8
  %cv7874 = zext i32 %v7873 to i64
  %cond7875 = icmp ne i64 %cv7874, 0
  br i1 %cond7875, label %bb_rcsuccess1941, label %bb_rcfailure1941
bb_rcfailure1941:
  %v7876 = load i64, ptr %slot46, align 8
  %p7877 = inttoptr i64 %v7876 to ptr
  %call7878 = call i32 @myl_rc_take_failure(ptr %p7877) nomerge, !dbg !206
  store i32 %call7878, ptr %slot1419, align 8
  %v7879 = load i64, ptr %slot1, align 8
  %p7880 = inttoptr i64 %v7879 to ptr
  %v7881 = load i32, ptr %slot1419, align 8
  %call7882 = call i32 @myl_qbe_rc_status(ptr %p7880, i32 %v7881) nomerge, !dbg !206
  store i32 %call7882, ptr %slot1420, align 8
  br label %bb_failure
bb_rcsuccess1941:
  br label %bb_rcmoved1926
bb_rcmoved1926:
  %v7883 = load i64, ptr %slot14, align 8
  %p7884 = inttoptr i64 %v7883 to ptr
  store i32 0, ptr %p7884, align 4, !alias.scope !3, !noalias !4
  %v7885 = load i64, ptr %slot19, align 8
  %p7886 = inttoptr i64 %v7885 to ptr
  store i32 2, ptr %p7886, align 4, !alias.scope !3, !noalias !4
  %v7887 = load i64, ptr %slot18, align 8
  %p7888 = inttoptr i64 %v7887 to ptr
  store i32 1, ptr %p7888, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1917
bb_rccopy1917:
  %v7889 = load i64, ptr %slot27, align 8
  store i64 %v7889, ptr %slot1421, align 8
  %v7890 = load i64, ptr %slot47, align 8
  store i64 %v7890, ptr %slot1422, align 8
  %v7891 = load i64, ptr %slot1399, align 8
  %p7892 = inttoptr i64 %v7891 to ptr
  %ld7893 = load i64, ptr %p7892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7893, ptr %slot1423, align 8
  %v7894 = load i64, ptr %slot1423, align 8
  %cmp7895 = icmp ne i64 %v7894, 0
  %cv7896 = zext i1 %cmp7895 to i32
  store i32 %cv7896, ptr %slot1424, align 8
  %v7897 = load i32, ptr %slot1424, align 8
  %cv7898 = zext i32 %v7897 to i64
  %cond7899 = icmp ne i64 %cv7898, 0
  br i1 %cond7899, label %bb_rcgnn1950, label %bb_rcgplain1950
bb_rcgnn1950:
  %v7900 = load i64, ptr %slot1423, align 8
  %op7901 = sub i64 %v7900, 16
  store i64 %op7901, ptr %slot1425, align 8
  %v7902 = load i64, ptr %slot1423, align 8
  %p7903 = inttoptr i64 %v7902 to ptr
  %rgep7904 = getelementptr i8, ptr %p7903, i64 -16
  %ld7905 = load i64, ptr %rgep7904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7905, ptr %slot1426, align 8
  %v7906 = load i64, ptr %slot1426, align 8
  %op7907 = and i64 %v7906, 4611686018427387906
  store i64 %op7907, ptr %slot1427, align 8
  %v7908 = load i64, ptr %slot1427, align 8
  %cmp7909 = icmp ne i64 %v7908, 0
  %cv7910 = zext i1 %cmp7909 to i32
  store i32 %cv7910, ptr %slot1428, align 8
  %v7911 = load i32, ptr %slot1428, align 8
  %cv7912 = zext i32 %v7911 to i64
  %cond7913 = icmp ne i64 %cv7912, 0
  br i1 %cond7913, label %bb_rcgspecial1950, label %bb_rcginc1950
bb_rcginc1950:
  %v7914 = load i64, ptr %slot1423, align 8
  %op7915 = sub i64 %v7914, 32
  store i64 %op7915, ptr %slot1429, align 8
  %v7916 = load i64, ptr %slot1423, align 8
  %p7917 = inttoptr i64 %v7916 to ptr
  %rgep7918 = getelementptr i8, ptr %p7917, i64 -32
  %ld7919 = load i64, ptr %rgep7918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7919, ptr %slot1430, align 8
  %v7920 = load i64, ptr %slot1430, align 8
  %op7921 = add i64 %v7920, 1
  store i64 %op7921, ptr %slot1431, align 8
  %v7922 = load i64, ptr %slot1431, align 8
  %cmp7923 = icmp eq i64 %v7922, 0
  %cv7924 = zext i1 %cmp7923 to i32
  store i32 %cv7924, ptr %slot1432, align 8
  %v7925 = load i32, ptr %slot1432, align 8
  %cv7926 = zext i32 %v7925 to i64
  %cond7927 = icmp ne i64 %cv7926, 0
  br i1 %cond7927, label %bb_rcglimit1950, label %bb_rcgcapacity1950
bb_rcglimit1950:
  %v7928 = load i64, ptr %slot1, align 8
  %p7929 = inttoptr i64 %v7928 to ptr
  %call7930 = call i32 @myl_qbe_rc_status(ptr %p7929, i32 2) nomerge, !dbg !206
  store i32 %call7930, ptr %slot1433, align 8
  br label %bb_failure
bb_rcgcapacity1950:
  %v7931 = load i64, ptr %slot1431, align 8
  %v7932 = load i64, ptr %slot1423, align 8
  %p7933 = inttoptr i64 %v7932 to ptr
  %rgep7934 = getelementptr i8, ptr %p7933, i64 -32
  store i64 %v7931, ptr %rgep7934, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1950
bb_rcgspecial1950:
  %v7935 = load i64, ptr %slot1426, align 8
  %op7936 = and i64 %v7935, 4611686018427387904
  store i64 %op7936, ptr %slot1434, align 8
  %v7937 = load i64, ptr %slot1434, align 8
  %cmp7938 = icmp ne i64 %v7937, 0
  %cv7939 = zext i1 %cmp7938 to i32
  store i32 %cv7939, ptr %slot1435, align 8
  %v7940 = load i32, ptr %slot1435, align 8
  %cv7941 = zext i32 %v7940 to i64
  %cond7942 = icmp ne i64 %cv7941, 0
  br i1 %cond7942, label %bb_rcgslow1950, label %bb_rcgplain1950
bb_rcgslow1950:
  %v7943 = load i64, ptr %slot46, align 8
  %v7944 = load i64, ptr %slot1421, align 8
  %v7945 = load i64, ptr %slot1399, align 8
  %v7946 = load i64, ptr %slot1422, align 8
  %cv7947 = trunc i64 %v7946 to i32
  %call7948 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v7943, i64 %v7944, i64 %v7945, i32 %cv7947) nomerge, !dbg !206
  store i32 %call7948, ptr %slot1436, align 8
  %v7949 = load i32, ptr %slot1436, align 8
  %cv7950 = zext i32 %v7949 to i64
  %cond7951 = icmp ne i64 %cv7950, 0
  br i1 %cond7951, label %bb_rcsuccess1964, label %bb_rcfailure1964
bb_rcfailure1964:
  %v7952 = load i64, ptr %slot46, align 8
  %p7953 = inttoptr i64 %v7952 to ptr
  %call7954 = call i32 @myl_rc_take_failure(ptr %p7953) nomerge, !dbg !206
  store i32 %call7954, ptr %slot1437, align 8
  %v7955 = load i64, ptr %slot1, align 8
  %p7956 = inttoptr i64 %v7955 to ptr
  %v7957 = load i32, ptr %slot1437, align 8
  %call7958 = call i32 @myl_qbe_rc_status(ptr %p7956, i32 %v7957) nomerge, !dbg !206
  store i32 %call7958, ptr %slot1438, align 8
  br label %bb_failure
bb_rcsuccess1964:
  br label %bb_rcgdone1950
bb_rcgplain1950:
  %v7959 = load i64, ptr %slot1423, align 8
  %v7960 = load i64, ptr %slot1421, align 8
  %p7961 = inttoptr i64 %v7960 to ptr
  store i64 %v7959, ptr %p7961, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1950
bb_rcgdone1950:
  %v7962 = load i64, ptr %slot19, align 8
  %p7963 = inttoptr i64 %v7962 to ptr
  store i32 2, ptr %p7963, align 4, !alias.scope !3, !noalias !4
  %v7964 = load i64, ptr %slot18, align 8
  %p7965 = inttoptr i64 %v7964 to ptr
  store i32 1, ptr %p7965, align 4, !alias.scope !3, !noalias !4
  %v7966 = load i64, ptr %slot14, align 8
  %p7967 = inttoptr i64 %v7966 to ptr
  %ld7968 = load i32, ptr %p7967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7968, ptr %slot1439, align 8
  %v7969 = load i32, ptr %slot1439, align 8
  %cv7970 = zext i32 %v7969 to i64
  %cond7971 = icmp ne i64 %cv7970, 0
  br i1 %cond7971, label %bb_rcslotdrop1971, label %bb_rcslotdone1971
bb_rcslotdrop1971:
  %v7972 = load i64, ptr %slot14, align 8
  %p7973 = inttoptr i64 %v7972 to ptr
  store i32 0, ptr %p7973, align 4, !alias.scope !3, !noalias !4
  %v7974 = load i64, ptr %slot22, align 8
  store i64 %v7974, ptr %slot1440, align 8
  %v7975 = load i64, ptr %slot15, align 8
  %p7976 = inttoptr i64 %v7975 to ptr
  %ld7977 = load i32, ptr %p7976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7977, ptr %slot1441, align 8
  %v7978 = load i32, ptr %slot1441, align 8
  %op7979 = and i32 %v7978, 28
  store i32 %op7979, ptr %slot1442, align 8
  %v7980 = load i32, ptr %slot1442, align 8
  %cv7981 = zext i32 %v7980 to i64
  %cond7982 = icmp ne i64 %cv7981, 0
  br i1 %cond7982, label %bb_rcslotrole1971, label %bb_rcslotowner1971
bb_rcslotrole1971:
  %v7983 = load i64, ptr %slot46, align 8
  store i64 %v7983, ptr %slot1443, align 8
  %v7984 = load i64, ptr %slot1440, align 8
  %p7985 = inttoptr i64 %v7984 to ptr
  %ld7986 = load i64, ptr %p7985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7986, ptr %slot1444, align 8
  %v7987 = load i64, ptr %slot1444, align 8
  %cmp7988 = icmp ne i64 %v7987, 0
  %cv7989 = zext i1 %cmp7988 to i32
  store i32 %cv7989, ptr %slot1445, align 8
  %v7990 = load i32, ptr %slot1445, align 8
  %cv7991 = zext i32 %v7990 to i64
  %cond7992 = icmp ne i64 %cv7991, 0
  br i1 %cond7992, label %bb_rcgnn1987, label %bb_rcgdone1987
bb_rcgnn1987:
  %v7993 = load i64, ptr %slot1444, align 8
  %op7994 = sub i64 %v7993, 16
  store i64 %op7994, ptr %slot1446, align 8
  %v7995 = load i64, ptr %slot1444, align 8
  %p7996 = inttoptr i64 %v7995 to ptr
  %rgep7997 = getelementptr i8, ptr %p7996, i64 -16
  %ld7998 = load i64, ptr %rgep7997, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7998, ptr %slot1447, align 8
  %v7999 = load i64, ptr %slot1447, align 8
  %op8000 = and i64 %v7999, 4611686018427387906
  store i64 %op8000, ptr %slot1448, align 8
  %v8001 = load i64, ptr %slot1448, align 8
  %cmp8002 = icmp ne i64 %v8001, 0
  %cv8003 = zext i1 %cmp8002 to i32
  store i32 %cv8003, ptr %slot1449, align 8
  %v8004 = load i32, ptr %slot1449, align 8
  %cv8005 = zext i32 %v8004 to i64
  %cond8006 = icmp ne i64 %cv8005, 0
  br i1 %cond8006, label %bb_rcgclear1987, label %bb_rcgcounted1987
bb_rcgcounted1987:
  %v8007 = load i64, ptr %slot1444, align 8
  %op8008 = sub i64 %v8007, 24
  store i64 %op8008, ptr %slot1450, align 8
  %v8009 = load i64, ptr %slot1444, align 8
  %p8010 = inttoptr i64 %v8009 to ptr
  %rgep8011 = getelementptr i8, ptr %p8010, i64 -24
  %ld8012 = load i64, ptr %rgep8011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8012, ptr %slot1451, align 8
  %v8013 = load i64, ptr %slot1451, align 8
  %op8014 = sub i64 %v8013, 1
  store i64 %op8014, ptr %slot1452, align 8
  %v8015 = load i64, ptr %slot1452, align 8
  %cmp8016 = icmp eq i64 %v8015, 0
  %cv8017 = zext i1 %cmp8016 to i32
  store i32 %cv8017, ptr %slot1453, align 8
  %v8018 = load i32, ptr %slot1453, align 8
  %cv8019 = zext i32 %v8018 to i64
  %cond8020 = icmp ne i64 %cv8019, 0
  br i1 %cond8020, label %bb_rcglast1987, label %bb_rcgdec1987
bb_rcglast1987:
  %v8021 = load i64, ptr %slot1444, align 8
  %op8022 = sub i64 %v8021, 32
  store i64 %op8022, ptr %slot1454, align 8
  %v8023 = load i64, ptr %slot1444, align 8
  %p8024 = inttoptr i64 %v8023 to ptr
  %rgep8025 = getelementptr i8, ptr %p8024, i64 -32
  %ld8026 = load i64, ptr %rgep8025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8026, ptr %slot1455, align 8
  %v8027 = load i64, ptr %slot1455, align 8
  %cmp8028 = icmp ne i64 %v8027, 0
  %cv8029 = zext i1 %cmp8028 to i32
  store i32 %cv8029, ptr %slot1456, align 8
  %v8030 = load i32, ptr %slot1456, align 8
  %cv8031 = zext i32 %v8030 to i64
  %cond8032 = icmp ne i64 %cv8031, 0
  br i1 %cond8032, label %bb_rcgdec1987, label %bb_rcgslow1987
bb_rcgslow1987:
  %v8033 = load i64, ptr %slot1443, align 8
  %v8034 = load i64, ptr %slot1440, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v8033, i64 %v8034) nomerge, !dbg !206
  br label %bb_rcgdone1987
bb_rcgdec1987:
  %v8035 = load i64, ptr %slot1452, align 8
  %v8036 = load i64, ptr %slot1444, align 8
  %p8037 = inttoptr i64 %v8036 to ptr
  %rgep8038 = getelementptr i8, ptr %p8037, i64 -24
  store i64 %v8035, ptr %rgep8038, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1987
bb_rcgclear1987:
  %v8039 = load i64, ptr %slot1440, align 8
  %p8040 = inttoptr i64 %v8039 to ptr
  store i64 0, ptr %p8040, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1987
bb_rcgdone1987:
  br label %bb_rcslotdone1971
bb_rcslotowner1971:
  %v8041 = load i64, ptr %slot46, align 8
  store i64 %v8041, ptr %slot1457, align 8
  %v8042 = load i64, ptr %slot1440, align 8
  %p8043 = inttoptr i64 %v8042 to ptr
  %ld8044 = load i64, ptr %p8043, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8044, ptr %slot1458, align 8
  %v8045 = load i64, ptr %slot1458, align 8
  %cmp8046 = icmp ne i64 %v8045, 0
  %cv8047 = zext i1 %cmp8046 to i32
  store i32 %cv8047, ptr %slot1459, align 8
  %v8048 = load i32, ptr %slot1459, align 8
  %cv8049 = zext i32 %v8048 to i64
  %cond8050 = icmp ne i64 %cv8049, 0
  br i1 %cond8050, label %bb_rcgnn2002, label %bb_rcgdone2002
bb_rcgnn2002:
  %v8051 = load i64, ptr %slot1458, align 8
  %op8052 = sub i64 %v8051, 16
  store i64 %op8052, ptr %slot1460, align 8
  %v8053 = load i64, ptr %slot1458, align 8
  %p8054 = inttoptr i64 %v8053 to ptr
  %rgep8055 = getelementptr i8, ptr %p8054, i64 -16
  %ld8056 = load i64, ptr %rgep8055, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8056, ptr %slot1461, align 8
  %v8057 = load i64, ptr %slot1461, align 8
  %op8058 = and i64 %v8057, 4611686018427387906
  store i64 %op8058, ptr %slot1462, align 8
  %v8059 = load i64, ptr %slot1462, align 8
  %cmp8060 = icmp ne i64 %v8059, 0
  %cv8061 = zext i1 %cmp8060 to i32
  store i32 %cv8061, ptr %slot1463, align 8
  %v8062 = load i32, ptr %slot1463, align 8
  %cv8063 = zext i32 %v8062 to i64
  %cond8064 = icmp ne i64 %cv8063, 0
  br i1 %cond8064, label %bb_rcgclear2002, label %bb_rcgcounted2002
bb_rcgcounted2002:
  %v8065 = load i64, ptr %slot1458, align 8
  %op8066 = sub i64 %v8065, 32
  store i64 %op8066, ptr %slot1464, align 8
  %v8067 = load i64, ptr %slot1458, align 8
  %p8068 = inttoptr i64 %v8067 to ptr
  %rgep8069 = getelementptr i8, ptr %p8068, i64 -32
  %ld8070 = load i64, ptr %rgep8069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8070, ptr %slot1465, align 8
  %v8071 = load i64, ptr %slot1465, align 8
  %op8072 = sub i64 %v8071, 1
  store i64 %op8072, ptr %slot1466, align 8
  %v8073 = load i64, ptr %slot1466, align 8
  %cmp8074 = icmp eq i64 %v8073, 0
  %cv8075 = zext i1 %cmp8074 to i32
  store i32 %cv8075, ptr %slot1467, align 8
  %v8076 = load i32, ptr %slot1467, align 8
  %cv8077 = zext i32 %v8076 to i64
  %cond8078 = icmp ne i64 %cv8077, 0
  br i1 %cond8078, label %bb_rcglast2002, label %bb_rcgdec2002
bb_rcglast2002:
  %v8079 = load i64, ptr %slot1458, align 8
  %op8080 = sub i64 %v8079, 24
  store i64 %op8080, ptr %slot1468, align 8
  %v8081 = load i64, ptr %slot1458, align 8
  %p8082 = inttoptr i64 %v8081 to ptr
  %rgep8083 = getelementptr i8, ptr %p8082, i64 -24
  %ld8084 = load i64, ptr %rgep8083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8084, ptr %slot1469, align 8
  %v8085 = load i64, ptr %slot1469, align 8
  %cmp8086 = icmp ne i64 %v8085, 0
  %cv8087 = zext i1 %cmp8086 to i32
  store i32 %cv8087, ptr %slot1470, align 8
  %v8088 = load i32, ptr %slot1470, align 8
  %cv8089 = zext i32 %v8088 to i64
  %cond8090 = icmp ne i64 %cv8089, 0
  br i1 %cond8090, label %bb_rcgdec2002, label %bb_rcgslow2002
bb_rcgslow2002:
  %v8091 = load i64, ptr %slot1457, align 8
  %v8092 = load i64, ptr %slot1440, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v8091, i64 %v8092) nomerge, !dbg !206
  br label %bb_rcgdone2002
bb_rcgdec2002:
  %v8093 = load i64, ptr %slot1466, align 8
  %v8094 = load i64, ptr %slot1458, align 8
  %p8095 = inttoptr i64 %v8094 to ptr
  %rgep8096 = getelementptr i8, ptr %p8095, i64 -32
  store i64 %v8093, ptr %rgep8096, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2002
bb_rcgclear2002:
  %v8097 = load i64, ptr %slot1440, align 8
  %p8098 = inttoptr i64 %v8097 to ptr
  store i64 0, ptr %p8098, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2002
bb_rcgdone2002:
  br label %bb_rcslotdone1971
bb_rcslotdone1971:
  br label %bb_rcprepared1917
bb_rcprepared1917:
  %v8099 = load i64, ptr %slot27, align 8
  store i64 %v8099, ptr %slot1471, align 8
  %v8100 = load i64, ptr %slot1471, align 8
  %v8101 = load i64, ptr %slot1397, align 8
  %p8102 = inttoptr i64 %v8100 to ptr
  %p8103 = inttoptr i64 %v8101 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8103, ptr %p8102, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8104 = load i64, ptr %slot18, align 8
  %p8105 = inttoptr i64 %v8104 to ptr
  store i32 0, ptr %p8105, align 4, !alias.scope !3, !noalias !4
  %v8106 = load i64, ptr %slot41, align 8
  %p8107 = inttoptr i64 %v8106 to ptr
  %ld8108 = load i64, ptr %p8107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8108, ptr %slot1472, align 8
  %v8109 = load i64, ptr %slot1472, align 8
  %v8110 = load i64, ptr %slot26, align 8
  %p8111 = inttoptr i64 %v8110 to ptr
  store i64 %v8109, ptr %p8111, align 8, !alias.scope !3, !noalias !4
  %v8112 = load i64, ptr %slot26, align 8
  store i64 %v8112, ptr %slot1473, align 8
  %v8113 = load i64, ptr %slot1312, align 8
  %p8115 = inttoptr i64 %v8113 to ptr
  %gep8116 = getelementptr i8, ptr %p8115, i64 16
  %op8114 = ptrtoint ptr %gep8116 to i64
  store i64 %op8114, ptr %slot1474, align 8
  %v8117 = load i64, ptr %slot41, align 8
  %p8118 = inttoptr i64 %v8117 to ptr
  %ld8119 = load i64, ptr %p8118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8119, ptr %slot1475, align 8
  %v8120 = load i64, ptr %slot1475, align 8
  %v8121 = load i64, ptr %slot26, align 8
  %p8122 = inttoptr i64 %v8121 to ptr
  store i64 %v8120, ptr %p8122, align 8, !alias.scope !3, !noalias !4
  %v8123 = load i64, ptr %slot26, align 8
  store i64 %v8123, ptr %slot1476, align 8
  %v8124 = load i64, ptr %slot16, align 8
  %p8125 = inttoptr i64 %v8124 to ptr
  %ld8126 = load i32, ptr %p8125, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8126, ptr %slot1477, align 8
  %v8127 = load i64, ptr %slot17, align 8
  %p8128 = inttoptr i64 %v8127 to ptr
  %ld8129 = load i32, ptr %p8128, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8129, ptr %slot1478, align 8
  %v8130 = load i32, ptr %slot1478, align 8
  %op8131 = and i32 %v8130, 24
  store i32 %op8131, ptr %slot1478, align 8
  %v8132 = load i32, ptr %slot1478, align 8
  %cmp8133 = icmp eq i32 %v8132, 0
  %cv8134 = zext i1 %cmp8133 to i32
  store i32 %cv8134, ptr %slot1479, align 8
  %v8135 = load i32, ptr %slot1477, align 8
  %v8136 = load i32, ptr %slot1479, align 8
  %op8137 = and i32 %v8135, %v8136
  store i32 %op8137, ptr %slot1480, align 8
  %v8138 = load i32, ptr %slot1480, align 8
  %cv8139 = zext i32 %v8138 to i64
  %cond8140 = icmp ne i64 %cv8139, 0
  br i1 %cond8140, label %bb_rctake2013, label %bb_rccopy2013
bb_rctake2013:
  %v8141 = load i64, ptr %slot27, align 8
  store i64 %v8141, ptr %slot1481, align 8
  %v8142 = load i64, ptr %slot47, align 8
  store i64 %v8142, ptr %slot1482, align 8
  %v8143 = load i64, ptr %slot1476, align 8
  %v8144 = load i64, ptr %slot1481, align 8
  %op8145 = sub i64 %v8143, %v8144
  store i64 %op8145, ptr %slot1483, align 8
  %v8146 = load i64, ptr %slot1481, align 8
  %v8147 = load i64, ptr %slot1476, align 8
  %op8148 = sub i64 %v8146, %v8147
  store i64 %op8148, ptr %slot1484, align 8
  %v8149 = load i64, ptr %slot1483, align 8
  %cmp8150 = icmp ult i64 %v8149, 8
  %cv8151 = zext i1 %cmp8150 to i32
  store i32 %cv8151, ptr %slot1485, align 8
  %v8152 = load i64, ptr %slot1484, align 8
  %cmp8153 = icmp ult i64 %v8152, 8
  %cv8154 = zext i1 %cmp8153 to i32
  store i32 %cv8154, ptr %slot1486, align 8
  %v8155 = load i32, ptr %slot1485, align 8
  %v8156 = load i32, ptr %slot1486, align 8
  %op8157 = or i32 %v8155, %v8156
  store i32 %op8157, ptr %slot1487, align 8
  %v8158 = load i32, ptr %slot1487, align 8
  %cv8159 = zext i32 %v8158 to i64
  %cond8160 = icmp ne i64 %cv8159, 0
  br i1 %cond8160, label %bb_rcmoveslow2022, label %bb_rcmovecheck2022
bb_rcmovecheck2022:
  %v8161 = load i64, ptr %slot1476, align 8
  %p8163 = inttoptr i64 %v8161 to ptr
  %gep8164 = getelementptr i8, ptr %p8163, i64 0
  %op8162 = ptrtoint ptr %gep8164 to i64
  store i64 %op8162, ptr %slot1488, align 8
  %v8165 = load i64, ptr %slot1488, align 8
  %p8166 = inttoptr i64 %v8165 to ptr
  %ld8167 = load i64, ptr %p8166, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8167, ptr %slot1489, align 8
  %v8168 = load i64, ptr %slot1489, align 8
  %cmp8169 = icmp ne i64 %v8168, 0
  %cv8170 = zext i1 %cmp8169 to i32
  store i32 %cv8170, ptr %slot1490, align 8
  %v8171 = load i32, ptr %slot1490, align 8
  %cv8172 = zext i32 %v8171 to i64
  %cond8173 = icmp ne i64 %cv8172, 0
  br i1 %cond8173, label %bb_rcmoveheader2030, label %bb_rcmovenext2030
bb_rcmoveheader2030:
  %v8174 = load i64, ptr %slot1489, align 8
  %op8175 = sub i64 %v8174, 16
  store i64 %op8175, ptr %slot1491, align 8
  %v8176 = load i64, ptr %slot1489, align 8
  %p8177 = inttoptr i64 %v8176 to ptr
  %rgep8178 = getelementptr i8, ptr %p8177, i64 -16
  %ld8179 = load i64, ptr %rgep8178, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8179, ptr %slot1492, align 8
  %v8180 = load i64, ptr %slot1492, align 8
  %op8181 = and i64 %v8180, 5764607523034234881
  store i64 %op8181, ptr %slot1493, align 8
  %v8182 = load i64, ptr %slot1493, align 8
  %cmp8183 = icmp ne i64 %v8182, 0
  %cv8184 = zext i1 %cmp8183 to i32
  store i32 %cv8184, ptr %slot1494, align 8
  %v8185 = load i32, ptr %slot1494, align 8
  %cv8186 = zext i32 %v8185 to i64
  %cond8187 = icmp ne i64 %cv8186, 0
  br i1 %cond8187, label %bb_rcmoveslow2022, label %bb_rcmovenext2030
bb_rcmovenext2030:
  %v8188 = load i64, ptr %slot1476, align 8
  %v8189 = load i64, ptr %slot1481, align 8
  %p8190 = inttoptr i64 %v8188 to ptr
  %p8191 = inttoptr i64 %v8189 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8191, ptr %p8190, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8192 = load i64, ptr %slot1476, align 8
  %p8193 = inttoptr i64 %v8192 to ptr
  store i64 0, ptr %p8193, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2022
bb_rcmoveslow2022:
  %v8194 = load i64, ptr %slot46, align 8
  %v8195 = load i64, ptr %slot1481, align 8
  %v8196 = load i64, ptr %slot1476, align 8
  %v8197 = load i64, ptr %slot1482, align 8
  %cv8198 = trunc i64 %v8197 to i32
  %call8199 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v8194, i64 %v8195, i64 %v8196, i32 %cv8198) nomerge, !dbg !206
  store i32 %call8199, ptr %slot1495, align 8
  %v8200 = load i32, ptr %slot1495, align 8
  %cv8201 = zext i32 %v8200 to i64
  %cond8202 = icmp ne i64 %cv8201, 0
  br i1 %cond8202, label %bb_rcsuccess2037, label %bb_rcfailure2037
bb_rcfailure2037:
  %v8203 = load i64, ptr %slot46, align 8
  %p8204 = inttoptr i64 %v8203 to ptr
  %call8205 = call i32 @myl_rc_take_failure(ptr %p8204) nomerge, !dbg !206
  store i32 %call8205, ptr %slot1496, align 8
  %v8206 = load i64, ptr %slot1, align 8
  %p8207 = inttoptr i64 %v8206 to ptr
  %v8208 = load i32, ptr %slot1496, align 8
  %call8209 = call i32 @myl_qbe_rc_status(ptr %p8207, i32 %v8208) nomerge, !dbg !206
  store i32 %call8209, ptr %slot1497, align 8
  br label %bb_failure
bb_rcsuccess2037:
  br label %bb_rcmoved2022
bb_rcmoved2022:
  %v8210 = load i64, ptr %slot16, align 8
  %p8211 = inttoptr i64 %v8210 to ptr
  store i32 0, ptr %p8211, align 4, !alias.scope !3, !noalias !4
  %v8212 = load i64, ptr %slot19, align 8
  %p8213 = inttoptr i64 %v8212 to ptr
  store i32 2, ptr %p8213, align 4, !alias.scope !3, !noalias !4
  %v8214 = load i64, ptr %slot18, align 8
  %p8215 = inttoptr i64 %v8214 to ptr
  store i32 1, ptr %p8215, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2013
bb_rccopy2013:
  %v8216 = load i64, ptr %slot27, align 8
  store i64 %v8216, ptr %slot1498, align 8
  %v8217 = load i64, ptr %slot47, align 8
  store i64 %v8217, ptr %slot1499, align 8
  %v8218 = load i64, ptr %slot1476, align 8
  %p8219 = inttoptr i64 %v8218 to ptr
  %ld8220 = load i64, ptr %p8219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8220, ptr %slot1500, align 8
  %v8221 = load i64, ptr %slot1500, align 8
  %cmp8222 = icmp ne i64 %v8221, 0
  %cv8223 = zext i1 %cmp8222 to i32
  store i32 %cv8223, ptr %slot1501, align 8
  %v8224 = load i32, ptr %slot1501, align 8
  %cv8225 = zext i32 %v8224 to i64
  %cond8226 = icmp ne i64 %cv8225, 0
  br i1 %cond8226, label %bb_rcgnn2046, label %bb_rcgplain2046
bb_rcgnn2046:
  %v8227 = load i64, ptr %slot1500, align 8
  %op8228 = sub i64 %v8227, 16
  store i64 %op8228, ptr %slot1502, align 8
  %v8229 = load i64, ptr %slot1500, align 8
  %p8230 = inttoptr i64 %v8229 to ptr
  %rgep8231 = getelementptr i8, ptr %p8230, i64 -16
  %ld8232 = load i64, ptr %rgep8231, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8232, ptr %slot1503, align 8
  %v8233 = load i64, ptr %slot1503, align 8
  %op8234 = and i64 %v8233, 4611686018427387906
  store i64 %op8234, ptr %slot1504, align 8
  %v8235 = load i64, ptr %slot1504, align 8
  %cmp8236 = icmp ne i64 %v8235, 0
  %cv8237 = zext i1 %cmp8236 to i32
  store i32 %cv8237, ptr %slot1505, align 8
  %v8238 = load i32, ptr %slot1505, align 8
  %cv8239 = zext i32 %v8238 to i64
  %cond8240 = icmp ne i64 %cv8239, 0
  br i1 %cond8240, label %bb_rcgspecial2046, label %bb_rcginc2046
bb_rcginc2046:
  %v8241 = load i64, ptr %slot1500, align 8
  %op8242 = sub i64 %v8241, 32
  store i64 %op8242, ptr %slot1506, align 8
  %v8243 = load i64, ptr %slot1500, align 8
  %p8244 = inttoptr i64 %v8243 to ptr
  %rgep8245 = getelementptr i8, ptr %p8244, i64 -32
  %ld8246 = load i64, ptr %rgep8245, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8246, ptr %slot1507, align 8
  %v8247 = load i64, ptr %slot1507, align 8
  %op8248 = add i64 %v8247, 1
  store i64 %op8248, ptr %slot1508, align 8
  %v8249 = load i64, ptr %slot1508, align 8
  %cmp8250 = icmp eq i64 %v8249, 0
  %cv8251 = zext i1 %cmp8250 to i32
  store i32 %cv8251, ptr %slot1509, align 8
  %v8252 = load i32, ptr %slot1509, align 8
  %cv8253 = zext i32 %v8252 to i64
  %cond8254 = icmp ne i64 %cv8253, 0
  br i1 %cond8254, label %bb_rcglimit2046, label %bb_rcgcapacity2046
bb_rcglimit2046:
  %v8255 = load i64, ptr %slot1, align 8
  %p8256 = inttoptr i64 %v8255 to ptr
  %call8257 = call i32 @myl_qbe_rc_status(ptr %p8256, i32 2) nomerge, !dbg !206
  store i32 %call8257, ptr %slot1510, align 8
  br label %bb_failure
bb_rcgcapacity2046:
  %v8258 = load i64, ptr %slot1508, align 8
  %v8259 = load i64, ptr %slot1500, align 8
  %p8260 = inttoptr i64 %v8259 to ptr
  %rgep8261 = getelementptr i8, ptr %p8260, i64 -32
  store i64 %v8258, ptr %rgep8261, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2046
bb_rcgspecial2046:
  %v8262 = load i64, ptr %slot1503, align 8
  %op8263 = and i64 %v8262, 4611686018427387904
  store i64 %op8263, ptr %slot1511, align 8
  %v8264 = load i64, ptr %slot1511, align 8
  %cmp8265 = icmp ne i64 %v8264, 0
  %cv8266 = zext i1 %cmp8265 to i32
  store i32 %cv8266, ptr %slot1512, align 8
  %v8267 = load i32, ptr %slot1512, align 8
  %cv8268 = zext i32 %v8267 to i64
  %cond8269 = icmp ne i64 %cv8268, 0
  br i1 %cond8269, label %bb_rcgslow2046, label %bb_rcgplain2046
bb_rcgslow2046:
  %v8270 = load i64, ptr %slot46, align 8
  %v8271 = load i64, ptr %slot1498, align 8
  %v8272 = load i64, ptr %slot1476, align 8
  %v8273 = load i64, ptr %slot1499, align 8
  %cv8274 = trunc i64 %v8273 to i32
  %call8275 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v8270, i64 %v8271, i64 %v8272, i32 %cv8274) nomerge, !dbg !206
  store i32 %call8275, ptr %slot1513, align 8
  %v8276 = load i32, ptr %slot1513, align 8
  %cv8277 = zext i32 %v8276 to i64
  %cond8278 = icmp ne i64 %cv8277, 0
  br i1 %cond8278, label %bb_rcsuccess2060, label %bb_rcfailure2060
bb_rcfailure2060:
  %v8279 = load i64, ptr %slot46, align 8
  %p8280 = inttoptr i64 %v8279 to ptr
  %call8281 = call i32 @myl_rc_take_failure(ptr %p8280) nomerge, !dbg !206
  store i32 %call8281, ptr %slot1514, align 8
  %v8282 = load i64, ptr %slot1, align 8
  %p8283 = inttoptr i64 %v8282 to ptr
  %v8284 = load i32, ptr %slot1514, align 8
  %call8285 = call i32 @myl_qbe_rc_status(ptr %p8283, i32 %v8284) nomerge, !dbg !206
  store i32 %call8285, ptr %slot1515, align 8
  br label %bb_failure
bb_rcsuccess2060:
  br label %bb_rcgdone2046
bb_rcgplain2046:
  %v8286 = load i64, ptr %slot1500, align 8
  %v8287 = load i64, ptr %slot1498, align 8
  %p8288 = inttoptr i64 %v8287 to ptr
  store i64 %v8286, ptr %p8288, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2046
bb_rcgdone2046:
  %v8289 = load i64, ptr %slot19, align 8
  %p8290 = inttoptr i64 %v8289 to ptr
  store i32 2, ptr %p8290, align 4, !alias.scope !3, !noalias !4
  %v8291 = load i64, ptr %slot18, align 8
  %p8292 = inttoptr i64 %v8291 to ptr
  store i32 1, ptr %p8292, align 4, !alias.scope !3, !noalias !4
  %v8293 = load i64, ptr %slot16, align 8
  %p8294 = inttoptr i64 %v8293 to ptr
  %ld8295 = load i32, ptr %p8294, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8295, ptr %slot1516, align 8
  %v8296 = load i32, ptr %slot1516, align 8
  %cv8297 = zext i32 %v8296 to i64
  %cond8298 = icmp ne i64 %cv8297, 0
  br i1 %cond8298, label %bb_rcslotdrop2067, label %bb_rcslotdone2067
bb_rcslotdrop2067:
  %v8299 = load i64, ptr %slot16, align 8
  %p8300 = inttoptr i64 %v8299 to ptr
  store i32 0, ptr %p8300, align 4, !alias.scope !3, !noalias !4
  %v8301 = load i64, ptr %slot23, align 8
  store i64 %v8301, ptr %slot1517, align 8
  %v8302 = load i64, ptr %slot17, align 8
  %p8303 = inttoptr i64 %v8302 to ptr
  %ld8304 = load i32, ptr %p8303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8304, ptr %slot1518, align 8
  %v8305 = load i32, ptr %slot1518, align 8
  %op8306 = and i32 %v8305, 28
  store i32 %op8306, ptr %slot1519, align 8
  %v8307 = load i32, ptr %slot1519, align 8
  %cv8308 = zext i32 %v8307 to i64
  %cond8309 = icmp ne i64 %cv8308, 0
  br i1 %cond8309, label %bb_rcslotrole2067, label %bb_rcslotowner2067
bb_rcslotrole2067:
  %v8310 = load i64, ptr %slot46, align 8
  store i64 %v8310, ptr %slot1520, align 8
  %v8311 = load i64, ptr %slot1517, align 8
  %p8312 = inttoptr i64 %v8311 to ptr
  %ld8313 = load i64, ptr %p8312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8313, ptr %slot1521, align 8
  %v8314 = load i64, ptr %slot1521, align 8
  %cmp8315 = icmp ne i64 %v8314, 0
  %cv8316 = zext i1 %cmp8315 to i32
  store i32 %cv8316, ptr %slot1522, align 8
  %v8317 = load i32, ptr %slot1522, align 8
  %cv8318 = zext i32 %v8317 to i64
  %cond8319 = icmp ne i64 %cv8318, 0
  br i1 %cond8319, label %bb_rcgnn2083, label %bb_rcgdone2083
bb_rcgnn2083:
  %v8320 = load i64, ptr %slot1521, align 8
  %op8321 = sub i64 %v8320, 16
  store i64 %op8321, ptr %slot1523, align 8
  %v8322 = load i64, ptr %slot1521, align 8
  %p8323 = inttoptr i64 %v8322 to ptr
  %rgep8324 = getelementptr i8, ptr %p8323, i64 -16
  %ld8325 = load i64, ptr %rgep8324, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8325, ptr %slot1524, align 8
  %v8326 = load i64, ptr %slot1524, align 8
  %op8327 = and i64 %v8326, 4611686018427387906
  store i64 %op8327, ptr %slot1525, align 8
  %v8328 = load i64, ptr %slot1525, align 8
  %cmp8329 = icmp ne i64 %v8328, 0
  %cv8330 = zext i1 %cmp8329 to i32
  store i32 %cv8330, ptr %slot1526, align 8
  %v8331 = load i32, ptr %slot1526, align 8
  %cv8332 = zext i32 %v8331 to i64
  %cond8333 = icmp ne i64 %cv8332, 0
  br i1 %cond8333, label %bb_rcgclear2083, label %bb_rcgcounted2083
bb_rcgcounted2083:
  %v8334 = load i64, ptr %slot1521, align 8
  %op8335 = sub i64 %v8334, 24
  store i64 %op8335, ptr %slot1527, align 8
  %v8336 = load i64, ptr %slot1521, align 8
  %p8337 = inttoptr i64 %v8336 to ptr
  %rgep8338 = getelementptr i8, ptr %p8337, i64 -24
  %ld8339 = load i64, ptr %rgep8338, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8339, ptr %slot1528, align 8
  %v8340 = load i64, ptr %slot1528, align 8
  %op8341 = sub i64 %v8340, 1
  store i64 %op8341, ptr %slot1529, align 8
  %v8342 = load i64, ptr %slot1529, align 8
  %cmp8343 = icmp eq i64 %v8342, 0
  %cv8344 = zext i1 %cmp8343 to i32
  store i32 %cv8344, ptr %slot1530, align 8
  %v8345 = load i32, ptr %slot1530, align 8
  %cv8346 = zext i32 %v8345 to i64
  %cond8347 = icmp ne i64 %cv8346, 0
  br i1 %cond8347, label %bb_rcglast2083, label %bb_rcgdec2083
bb_rcglast2083:
  %v8348 = load i64, ptr %slot1521, align 8
  %op8349 = sub i64 %v8348, 32
  store i64 %op8349, ptr %slot1531, align 8
  %v8350 = load i64, ptr %slot1521, align 8
  %p8351 = inttoptr i64 %v8350 to ptr
  %rgep8352 = getelementptr i8, ptr %p8351, i64 -32
  %ld8353 = load i64, ptr %rgep8352, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8353, ptr %slot1532, align 8
  %v8354 = load i64, ptr %slot1532, align 8
  %cmp8355 = icmp ne i64 %v8354, 0
  %cv8356 = zext i1 %cmp8355 to i32
  store i32 %cv8356, ptr %slot1533, align 8
  %v8357 = load i32, ptr %slot1533, align 8
  %cv8358 = zext i32 %v8357 to i64
  %cond8359 = icmp ne i64 %cv8358, 0
  br i1 %cond8359, label %bb_rcgdec2083, label %bb_rcgslow2083
bb_rcgslow2083:
  %v8360 = load i64, ptr %slot1520, align 8
  %v8361 = load i64, ptr %slot1517, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v8360, i64 %v8361) nomerge, !dbg !206
  br label %bb_rcgdone2083
bb_rcgdec2083:
  %v8362 = load i64, ptr %slot1529, align 8
  %v8363 = load i64, ptr %slot1521, align 8
  %p8364 = inttoptr i64 %v8363 to ptr
  %rgep8365 = getelementptr i8, ptr %p8364, i64 -24
  store i64 %v8362, ptr %rgep8365, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2083
bb_rcgclear2083:
  %v8366 = load i64, ptr %slot1517, align 8
  %p8367 = inttoptr i64 %v8366 to ptr
  store i64 0, ptr %p8367, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2083
bb_rcgdone2083:
  br label %bb_rcslotdone2067
bb_rcslotowner2067:
  %v8368 = load i64, ptr %slot46, align 8
  store i64 %v8368, ptr %slot1534, align 8
  %v8369 = load i64, ptr %slot1517, align 8
  %p8370 = inttoptr i64 %v8369 to ptr
  %ld8371 = load i64, ptr %p8370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8371, ptr %slot1535, align 8
  %v8372 = load i64, ptr %slot1535, align 8
  %cmp8373 = icmp ne i64 %v8372, 0
  %cv8374 = zext i1 %cmp8373 to i32
  store i32 %cv8374, ptr %slot1536, align 8
  %v8375 = load i32, ptr %slot1536, align 8
  %cv8376 = zext i32 %v8375 to i64
  %cond8377 = icmp ne i64 %cv8376, 0
  br i1 %cond8377, label %bb_rcgnn2098, label %bb_rcgdone2098
bb_rcgnn2098:
  %v8378 = load i64, ptr %slot1535, align 8
  %op8379 = sub i64 %v8378, 16
  store i64 %op8379, ptr %slot1537, align 8
  %v8380 = load i64, ptr %slot1535, align 8
  %p8381 = inttoptr i64 %v8380 to ptr
  %rgep8382 = getelementptr i8, ptr %p8381, i64 -16
  %ld8383 = load i64, ptr %rgep8382, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8383, ptr %slot1538, align 8
  %v8384 = load i64, ptr %slot1538, align 8
  %op8385 = and i64 %v8384, 4611686018427387906
  store i64 %op8385, ptr %slot1539, align 8
  %v8386 = load i64, ptr %slot1539, align 8
  %cmp8387 = icmp ne i64 %v8386, 0
  %cv8388 = zext i1 %cmp8387 to i32
  store i32 %cv8388, ptr %slot1540, align 8
  %v8389 = load i32, ptr %slot1540, align 8
  %cv8390 = zext i32 %v8389 to i64
  %cond8391 = icmp ne i64 %cv8390, 0
  br i1 %cond8391, label %bb_rcgclear2098, label %bb_rcgcounted2098
bb_rcgcounted2098:
  %v8392 = load i64, ptr %slot1535, align 8
  %op8393 = sub i64 %v8392, 32
  store i64 %op8393, ptr %slot1541, align 8
  %v8394 = load i64, ptr %slot1535, align 8
  %p8395 = inttoptr i64 %v8394 to ptr
  %rgep8396 = getelementptr i8, ptr %p8395, i64 -32
  %ld8397 = load i64, ptr %rgep8396, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8397, ptr %slot1542, align 8
  %v8398 = load i64, ptr %slot1542, align 8
  %op8399 = sub i64 %v8398, 1
  store i64 %op8399, ptr %slot1543, align 8
  %v8400 = load i64, ptr %slot1543, align 8
  %cmp8401 = icmp eq i64 %v8400, 0
  %cv8402 = zext i1 %cmp8401 to i32
  store i32 %cv8402, ptr %slot1544, align 8
  %v8403 = load i32, ptr %slot1544, align 8
  %cv8404 = zext i32 %v8403 to i64
  %cond8405 = icmp ne i64 %cv8404, 0
  br i1 %cond8405, label %bb_rcglast2098, label %bb_rcgdec2098
bb_rcglast2098:
  %v8406 = load i64, ptr %slot1535, align 8
  %op8407 = sub i64 %v8406, 24
  store i64 %op8407, ptr %slot1545, align 8
  %v8408 = load i64, ptr %slot1535, align 8
  %p8409 = inttoptr i64 %v8408 to ptr
  %rgep8410 = getelementptr i8, ptr %p8409, i64 -24
  %ld8411 = load i64, ptr %rgep8410, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8411, ptr %slot1546, align 8
  %v8412 = load i64, ptr %slot1546, align 8
  %cmp8413 = icmp ne i64 %v8412, 0
  %cv8414 = zext i1 %cmp8413 to i32
  store i32 %cv8414, ptr %slot1547, align 8
  %v8415 = load i32, ptr %slot1547, align 8
  %cv8416 = zext i32 %v8415 to i64
  %cond8417 = icmp ne i64 %cv8416, 0
  br i1 %cond8417, label %bb_rcgdec2098, label %bb_rcgslow2098
bb_rcgslow2098:
  %v8418 = load i64, ptr %slot1534, align 8
  %v8419 = load i64, ptr %slot1517, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v8418, i64 %v8419) nomerge, !dbg !206
  br label %bb_rcgdone2098
bb_rcgdec2098:
  %v8420 = load i64, ptr %slot1543, align 8
  %v8421 = load i64, ptr %slot1535, align 8
  %p8422 = inttoptr i64 %v8421 to ptr
  %rgep8423 = getelementptr i8, ptr %p8422, i64 -32
  store i64 %v8420, ptr %rgep8423, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2098
bb_rcgclear2098:
  %v8424 = load i64, ptr %slot1517, align 8
  %p8425 = inttoptr i64 %v8424 to ptr
  store i64 0, ptr %p8425, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2098
bb_rcgdone2098:
  br label %bb_rcslotdone2067
bb_rcslotdone2067:
  br label %bb_rcprepared2013
bb_rcprepared2013:
  %v8426 = load i64, ptr %slot27, align 8
  store i64 %v8426, ptr %slot1548, align 8
  %v8427 = load i64, ptr %slot1548, align 8
  %v8428 = load i64, ptr %slot1474, align 8
  %p8429 = inttoptr i64 %v8427 to ptr
  %p8430 = inttoptr i64 %v8428 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8430, ptr %p8429, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8431 = load i64, ptr %slot18, align 8
  %p8432 = inttoptr i64 %v8431 to ptr
  store i32 0, ptr %p8432, align 4, !alias.scope !3, !noalias !4
  %v8433 = load i64, ptr %slot42, align 8
  store i64 %v8433, ptr %slot1549, align 8
  %v8434 = load i64, ptr %slot1312, align 8
  %p8436 = inttoptr i64 %v8434 to ptr
  %gep8437 = getelementptr i8, ptr %p8436, i64 24
  %op8435 = ptrtoint ptr %gep8437 to i64
  store i64 %op8435, ptr %slot1550, align 8
  %v8438 = load i64, ptr %slot1549, align 8
  %p8439 = inttoptr i64 %v8438 to ptr
  %ld8440 = load i64, ptr %p8439, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8440, ptr %slot1551, align 8
  %v8441 = load i64, ptr %slot1551, align 8
  %v8442 = load i64, ptr %slot1550, align 8
  %p8443 = inttoptr i64 %v8442 to ptr
  store i64 %v8441, ptr %p8443, align 8, !alias.scope !3, !noalias !4
  %v8444 = load i64, ptr %slot43, align 8
  store i64 %v8444, ptr %slot1552, align 8
  %v8445 = load i64, ptr %slot1312, align 8
  %p8447 = inttoptr i64 %v8445 to ptr
  %gep8448 = getelementptr i8, ptr %p8447, i64 32
  %op8446 = ptrtoint ptr %gep8448 to i64
  store i64 %op8446, ptr %slot1553, align 8
  %v8449 = load i64, ptr %slot1552, align 8
  %p8450 = inttoptr i64 %v8449 to ptr
  %ld8451 = load i64, ptr %p8450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8451, ptr %slot1554, align 8
  %v8452 = load i64, ptr %slot1554, align 8
  %v8453 = load i64, ptr %slot1553, align 8
  %p8454 = inttoptr i64 %v8453 to ptr
  store i64 %v8452, ptr %p8454, align 8, !alias.scope !3, !noalias !4
  %v8455 = load i64, ptr %slot1312, align 8
  %v8456 = load i64, ptr %slot39, align 8
  %p8457 = inttoptr i64 %v8456 to ptr
  store i64 %v8455, ptr %p8457, align 8, !alias.scope !3, !noalias !4
  %v8458 = load i64, ptr %slot39, align 8
  %p8459 = inttoptr i64 %v8458 to ptr
  %ld8460 = load i64, ptr %p8459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8460, ptr %slot1555, align 8
  %v8461 = load i64, ptr %slot21, align 8
  store i64 %v8461, ptr %slot1556, align 8
  %v8462 = load i64, ptr %slot1555, align 8
  %v8463 = load i64, ptr %slot1556, align 8
  %p8464 = inttoptr i64 %v8462 to ptr
  %p8465 = inttoptr i64 %v8463 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8465, ptr %p8464, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v8466 = load i64, ptr %slot13, align 8
  %p8467 = inttoptr i64 %v8466 to ptr
  store i32 2, ptr %p8467, align 4, !alias.scope !3, !noalias !4
  %v8468 = load i64, ptr %slot12, align 8
  %p8469 = inttoptr i64 %v8468 to ptr
  store i32 1, ptr %p8469, align 4, !alias.scope !3, !noalias !4
  %v8470 = load i64, ptr %slot1556, align 8
  %v8471 = load i64, ptr %slot39, align 8
  %p8472 = inttoptr i64 %v8471 to ptr
  store i64 %v8470, ptr %p8472, align 8, !alias.scope !3, !noalias !4
  %v8473 = load i64, ptr %slot39, align 8
  %p8474 = inttoptr i64 %v8473 to ptr
  %ld8475 = load i64, ptr %p8474, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8475, ptr %slot1557, align 8
  %v8476 = load i64, ptr %slot39, align 8
  %p8477 = inttoptr i64 %v8476 to ptr
  %ld8478 = load i64, ptr %p8477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8478, ptr %slot1558, align 8
  %v8479 = load i64, ptr %slot27, align 8
  store i64 %v8479, ptr %slot1559, align 8
  %v8480 = load i64, ptr %slot47, align 8
  store i64 %v8480, ptr %slot1560, align 8
  %v8481 = load i64, ptr %slot1558, align 8
  %op8482 = add i64 %v8481, 0
  store i64 %op8482, ptr %slot1561, align 8
  %v8483 = load i64, ptr %slot1561, align 8
  %p8484 = inttoptr i64 %v8483 to ptr
  %ld8485 = load i64, ptr %p8484, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8485, ptr %slot1562, align 8
  %v8486 = load i64, ptr %slot1562, align 8
  %cmp8487 = icmp ne i64 %v8486, 0
  %cv8488 = zext i1 %cmp8487 to i32
  store i32 %cv8488, ptr %slot1563, align 8
  %v8489 = load i32, ptr %slot1563, align 8
  %cv8490 = zext i32 %v8489 to i64
  %cond8491 = icmp ne i64 %cv8490, 0
  br i1 %cond8491, label %bb_rcmoveheader2121, label %bb_rcmovenext2121
bb_rcmoveheader2121:
  %v8492 = load i64, ptr %slot1562, align 8
  %op8493 = sub i64 %v8492, 16
  store i64 %op8493, ptr %slot1564, align 8
  %v8494 = load i64, ptr %slot1562, align 8
  %p8495 = inttoptr i64 %v8494 to ptr
  %rgep8496 = getelementptr i8, ptr %p8495, i64 -16
  %ld8497 = load i64, ptr %rgep8496, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8497, ptr %slot1565, align 8
  %v8498 = load i64, ptr %slot1565, align 8
  %op8499 = and i64 %v8498, 5764607523034234881
  store i64 %op8499, ptr %slot1566, align 8
  %v8500 = load i64, ptr %slot1566, align 8
  %cmp8501 = icmp ne i64 %v8500, 0
  %cv8502 = zext i1 %cmp8501 to i32
  store i32 %cv8502, ptr %slot1567, align 8
  %v8503 = load i32, ptr %slot1567, align 8
  %cv8504 = zext i32 %v8503 to i64
  %cond8505 = icmp ne i64 %cv8504, 0
  br i1 %cond8505, label %bb_rcmoveslow2118, label %bb_rcmovenext2121
bb_rcmovenext2121:
  %v8506 = load i64, ptr %slot1558, align 8
  %op8507 = add i64 %v8506, 8
  store i64 %op8507, ptr %slot1568, align 8
  %v8508 = load i64, ptr %slot1568, align 8
  %p8509 = inttoptr i64 %v8508 to ptr
  %ld8510 = load i64, ptr %p8509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8510, ptr %slot1569, align 8
  %v8511 = load i64, ptr %slot1569, align 8
  %cmp8512 = icmp ne i64 %v8511, 0
  %cv8513 = zext i1 %cmp8512 to i32
  store i32 %cv8513, ptr %slot1570, align 8
  %v8514 = load i32, ptr %slot1570, align 8
  %cv8515 = zext i32 %v8514 to i64
  %cond8516 = icmp ne i64 %cv8515, 0
  br i1 %cond8516, label %bb_rcmoveheader2129, label %bb_rcmovenext2129
bb_rcmoveheader2129:
  %v8517 = load i64, ptr %slot1569, align 8
  %op8518 = sub i64 %v8517, 16
  store i64 %op8518, ptr %slot1571, align 8
  %v8519 = load i64, ptr %slot1569, align 8
  %p8520 = inttoptr i64 %v8519 to ptr
  %rgep8521 = getelementptr i8, ptr %p8520, i64 -16
  %ld8522 = load i64, ptr %rgep8521, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8522, ptr %slot1572, align 8
  %v8523 = load i64, ptr %slot1572, align 8
  %op8524 = and i64 %v8523, 5764607523034234881
  store i64 %op8524, ptr %slot1573, align 8
  %v8525 = load i64, ptr %slot1573, align 8
  %cmp8526 = icmp ne i64 %v8525, 0
  %cv8527 = zext i1 %cmp8526 to i32
  store i32 %cv8527, ptr %slot1574, align 8
  %v8528 = load i32, ptr %slot1574, align 8
  %cv8529 = zext i32 %v8528 to i64
  %cond8530 = icmp ne i64 %cv8529, 0
  br i1 %cond8530, label %bb_rcmoveslow2118, label %bb_rcmovenext2129
bb_rcmovenext2129:
  %v8531 = load i64, ptr %slot1558, align 8
  %op8532 = add i64 %v8531, 16
  store i64 %op8532, ptr %slot1575, align 8
  %v8533 = load i64, ptr %slot1575, align 8
  %p8534 = inttoptr i64 %v8533 to ptr
  %ld8535 = load i64, ptr %p8534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8535, ptr %slot1576, align 8
  %v8536 = load i64, ptr %slot1576, align 8
  %cmp8537 = icmp ne i64 %v8536, 0
  %cv8538 = zext i1 %cmp8537 to i32
  store i32 %cv8538, ptr %slot1577, align 8
  %v8539 = load i32, ptr %slot1577, align 8
  %cv8540 = zext i32 %v8539 to i64
  %cond8541 = icmp ne i64 %cv8540, 0
  br i1 %cond8541, label %bb_rcmoveheader2137, label %bb_rcmovenext2137
bb_rcmoveheader2137:
  %v8542 = load i64, ptr %slot1576, align 8
  %op8543 = sub i64 %v8542, 16
  store i64 %op8543, ptr %slot1578, align 8
  %v8544 = load i64, ptr %slot1576, align 8
  %p8545 = inttoptr i64 %v8544 to ptr
  %rgep8546 = getelementptr i8, ptr %p8545, i64 -16
  %ld8547 = load i64, ptr %rgep8546, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8547, ptr %slot1579, align 8
  %v8548 = load i64, ptr %slot1579, align 8
  %op8549 = and i64 %v8548, 5764607523034234881
  store i64 %op8549, ptr %slot1580, align 8
  %v8550 = load i64, ptr %slot1580, align 8
  %cmp8551 = icmp ne i64 %v8550, 0
  %cv8552 = zext i1 %cmp8551 to i32
  store i32 %cv8552, ptr %slot1581, align 8
  %v8553 = load i32, ptr %slot1581, align 8
  %cv8554 = zext i32 %v8553 to i64
  %cond8555 = icmp ne i64 %cv8554, 0
  br i1 %cond8555, label %bb_rcmoveslow2118, label %bb_rcmovenext2137
bb_rcmovenext2137:
  %v8556 = load i64, ptr %slot1558, align 8
  %v8557 = load i64, ptr %slot1559, align 8
  %p8558 = inttoptr i64 %v8556 to ptr
  %p8559 = inttoptr i64 %v8557 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8559, ptr %p8558, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v8560 = load i64, ptr %slot1558, align 8
  %p8561 = inttoptr i64 %v8560 to ptr
  store i64 0, ptr %p8561, align 8, !alias.scope !3, !noalias !4
  %v8562 = load i64, ptr %slot1558, align 8
  %op8563 = add i64 %v8562, 8
  store i64 %op8563, ptr %slot1582, align 8
  %v8564 = load i64, ptr %slot1582, align 8
  %p8565 = inttoptr i64 %v8564 to ptr
  store i64 0, ptr %p8565, align 8, !alias.scope !3, !noalias !4
  %v8566 = load i64, ptr %slot1558, align 8
  %op8567 = add i64 %v8566, 16
  store i64 %op8567, ptr %slot1583, align 8
  %v8568 = load i64, ptr %slot1583, align 8
  %p8569 = inttoptr i64 %v8568 to ptr
  store i64 0, ptr %p8569, align 8, !alias.scope !3, !noalias !4
  %v8570 = load i64, ptr %slot1558, align 8
  %op8571 = add i64 %v8570, 24
  store i64 %op8571, ptr %slot1584, align 8
  %v8572 = load i64, ptr %slot1584, align 8
  %p8573 = inttoptr i64 %v8572 to ptr
  store i64 0, ptr %p8573, align 8, !alias.scope !3, !noalias !4
  %v8574 = load i64, ptr %slot1558, align 8
  %op8575 = add i64 %v8574, 32
  store i64 %op8575, ptr %slot1585, align 8
  %v8576 = load i64, ptr %slot1585, align 8
  %p8577 = inttoptr i64 %v8576 to ptr
  store i64 0, ptr %p8577, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2118
bb_rcmoveslow2118:
  %v8578 = load i64, ptr %slot46, align 8
  %v8579 = load i64, ptr %slot1559, align 8
  %v8580 = load i64, ptr %slot1558, align 8
  %v8581 = load i64, ptr %slot1560, align 8
  %cv8582 = trunc i64 %v8581 to i32
  %call8583 = call i32 @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_take(i64 %v8578, i64 %v8579, i64 %v8580, i32 %cv8582) nomerge, !dbg !208
  store i32 %call8583, ptr %slot1586, align 8
  %v8584 = load i32, ptr %slot1586, align 8
  %cv8585 = zext i32 %v8584 to i64
  %cond8586 = icmp ne i64 %cv8585, 0
  br i1 %cond8586, label %bb_rcsuccess2148, label %bb_rcfailure2148
bb_rcfailure2148:
  %v8587 = load i64, ptr %slot46, align 8
  %p8588 = inttoptr i64 %v8587 to ptr
  %call8589 = call i32 @myl_rc_take_failure(ptr %p8588) nomerge, !dbg !208
  store i32 %call8589, ptr %slot1587, align 8
  %v8590 = load i64, ptr %slot1, align 8
  %p8591 = inttoptr i64 %v8590 to ptr
  %v8592 = load i32, ptr %slot1587, align 8
  %call8593 = call i32 @myl_qbe_rc_status(ptr %p8591, i32 %v8592) nomerge, !dbg !208
  store i32 %call8593, ptr %slot1588, align 8
  br label %bb_failure
bb_rcsuccess2148:
  br label %bb_rcmoved2118
bb_rcmoved2118:
  %v8594 = load i64, ptr %slot12, align 8
  %p8595 = inttoptr i64 %v8594 to ptr
  store i32 0, ptr %p8595, align 4, !alias.scope !3, !noalias !4
  %v8596 = load i64, ptr %slot19, align 8
  %p8597 = inttoptr i64 %v8596 to ptr
  store i32 2, ptr %p8597, align 4, !alias.scope !3, !noalias !4
  %v8598 = load i64, ptr %slot18, align 8
  %p8599 = inttoptr i64 %v8598 to ptr
  store i32 1, ptr %p8599, align 4, !alias.scope !3, !noalias !4
  %v8600 = load i64, ptr %slot27, align 8
  store i64 %v8600, ptr %slot1589, align 8
  %v8601 = load i64, ptr %slot18, align 8
  %p8602 = inttoptr i64 %v8601 to ptr
  store i32 0, ptr %p8602, align 4, !alias.scope !3, !noalias !4
  %v8603 = load i64, ptr %slot12, align 8
  %p8604 = inttoptr i64 %v8603 to ptr
  %ld8605 = load i32, ptr %p8604, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8605, ptr %slot1590, align 8
  %v8606 = load i32, ptr %slot1590, align 8
  %cv8607 = zext i32 %v8606 to i64
  %cond8608 = icmp ne i64 %cv8607, 0
  br i1 %cond8608, label %bb_rcslotdrop2158, label %bb_rcslotdone2158
bb_rcslotdrop2158:
  %v8609 = load i64, ptr %slot12, align 8
  %p8610 = inttoptr i64 %v8609 to ptr
  store i32 0, ptr %p8610, align 4, !alias.scope !3, !noalias !4
  %v8611 = load i64, ptr %slot21, align 8
  store i64 %v8611, ptr %slot1591, align 8
  %v8612 = load i64, ptr %slot13, align 8
  %p8613 = inttoptr i64 %v8612 to ptr
  %ld8614 = load i32, ptr %p8613, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8614, ptr %slot1592, align 8
  %v8615 = load i32, ptr %slot1592, align 8
  %op8616 = and i32 %v8615, 28
  store i32 %op8616, ptr %slot1593, align 8
  %v8617 = load i32, ptr %slot1593, align 8
  %cv8618 = zext i32 %v8617 to i64
  %cond8619 = icmp ne i64 %cv8618, 0
  br i1 %cond8619, label %bb_rcslotrole2158, label %bb_rcslotowner2158
bb_rcslotrole2158:
  %v8620 = load i64, ptr %slot46, align 8
  store i64 %v8620, ptr %slot1594, align 8
  %v8621 = load i64, ptr %slot1594, align 8
  %v8622 = load i64, ptr %slot1591, align 8
  call void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_unloan(i64 %v8621, i64 %v8622) nomerge, !dbg !208
  br label %bb_rcslotdone2158
bb_rcslotowner2158:
  %v8623 = load i64, ptr %slot46, align 8
  store i64 %v8623, ptr %slot1595, align 8
  %v8624 = load i64, ptr %slot1595, align 8
  %v8625 = load i64, ptr %slot1591, align 8
  call void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_drop(i64 %v8624, i64 %v8625) nomerge, !dbg !208
  br label %bb_rcslotdone2158
bb_rcslotdone2158:
  %v8626 = load i64, ptr %slot10, align 8
  %p8627 = inttoptr i64 %v8626 to ptr
  %ld8628 = load i32, ptr %p8627, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8628, ptr %slot1596, align 8
  %v8629 = load i32, ptr %slot1596, align 8
  %cv8630 = zext i32 %v8629 to i64
  %cond8631 = icmp ne i64 %cv8630, 0
  br i1 %cond8631, label %bb_rcslotdrop2167, label %bb_rcslotdone2167
bb_rcslotdrop2167:
  %v8632 = load i64, ptr %slot10, align 8
  %p8633 = inttoptr i64 %v8632 to ptr
  store i32 0, ptr %p8633, align 4, !alias.scope !3, !noalias !4
  %v8634 = load i64, ptr %slot38, align 8
  store i64 %v8634, ptr %slot1597, align 8
  %v8635 = load i64, ptr %slot11, align 8
  %p8636 = inttoptr i64 %v8635 to ptr
  %ld8637 = load i32, ptr %p8636, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8637, ptr %slot1598, align 8
  %v8638 = load i32, ptr %slot1598, align 8
  %op8639 = and i32 %v8638, 28
  store i32 %op8639, ptr %slot1599, align 8
  %v8640 = load i32, ptr %slot1599, align 8
  %cv8641 = zext i32 %v8640 to i64
  %cond8642 = icmp ne i64 %cv8641, 0
  br i1 %cond8642, label %bb_rcslotrole2167, label %bb_rcslotowner2167
bb_rcslotrole2167:
  %v8643 = load i64, ptr %slot46, align 8
  store i64 %v8643, ptr %slot1600, align 8
  %v8644 = load i64, ptr %slot1597, align 8
  %p8645 = inttoptr i64 %v8644 to ptr
  %ld8646 = load i64, ptr %p8645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8646, ptr %slot1601, align 8
  %v8647 = load i64, ptr %slot1601, align 8
  %cmp8648 = icmp ne i64 %v8647, 0
  %cv8649 = zext i1 %cmp8648 to i32
  store i32 %cv8649, ptr %slot1602, align 8
  %v8650 = load i32, ptr %slot1602, align 8
  %cv8651 = zext i32 %v8650 to i64
  %cond8652 = icmp ne i64 %cv8651, 0
  br i1 %cond8652, label %bb_rcgnn2183, label %bb_rcgdone2183
bb_rcgnn2183:
  %v8653 = load i64, ptr %slot1601, align 8
  %op8654 = sub i64 %v8653, 16
  store i64 %op8654, ptr %slot1603, align 8
  %v8655 = load i64, ptr %slot1601, align 8
  %p8656 = inttoptr i64 %v8655 to ptr
  %rgep8657 = getelementptr i8, ptr %p8656, i64 -16
  %ld8658 = load i64, ptr %rgep8657, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8658, ptr %slot1604, align 8
  %v8659 = load i64, ptr %slot1604, align 8
  %op8660 = and i64 %v8659, 4611686018427387906
  store i64 %op8660, ptr %slot1605, align 8
  %v8661 = load i64, ptr %slot1605, align 8
  %cmp8662 = icmp ne i64 %v8661, 0
  %cv8663 = zext i1 %cmp8662 to i32
  store i32 %cv8663, ptr %slot1606, align 8
  %v8664 = load i32, ptr %slot1606, align 8
  %cv8665 = zext i32 %v8664 to i64
  %cond8666 = icmp ne i64 %cv8665, 0
  br i1 %cond8666, label %bb_rcgclear2183, label %bb_rcgcounted2183
bb_rcgcounted2183:
  %v8667 = load i64, ptr %slot1601, align 8
  %op8668 = sub i64 %v8667, 24
  store i64 %op8668, ptr %slot1607, align 8
  %v8669 = load i64, ptr %slot1601, align 8
  %p8670 = inttoptr i64 %v8669 to ptr
  %rgep8671 = getelementptr i8, ptr %p8670, i64 -24
  %ld8672 = load i64, ptr %rgep8671, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8672, ptr %slot1608, align 8
  %v8673 = load i64, ptr %slot1608, align 8
  %op8674 = sub i64 %v8673, 1
  store i64 %op8674, ptr %slot1609, align 8
  %v8675 = load i64, ptr %slot1609, align 8
  %cmp8676 = icmp eq i64 %v8675, 0
  %cv8677 = zext i1 %cmp8676 to i32
  store i32 %cv8677, ptr %slot1610, align 8
  %v8678 = load i32, ptr %slot1610, align 8
  %cv8679 = zext i32 %v8678 to i64
  %cond8680 = icmp ne i64 %cv8679, 0
  br i1 %cond8680, label %bb_rcglast2183, label %bb_rcgdec2183
bb_rcglast2183:
  %v8681 = load i64, ptr %slot1601, align 8
  %op8682 = sub i64 %v8681, 32
  store i64 %op8682, ptr %slot1611, align 8
  %v8683 = load i64, ptr %slot1601, align 8
  %p8684 = inttoptr i64 %v8683 to ptr
  %rgep8685 = getelementptr i8, ptr %p8684, i64 -32
  %ld8686 = load i64, ptr %rgep8685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8686, ptr %slot1612, align 8
  %v8687 = load i64, ptr %slot1612, align 8
  %cmp8688 = icmp ne i64 %v8687, 0
  %cv8689 = zext i1 %cmp8688 to i32
  store i32 %cv8689, ptr %slot1613, align 8
  %v8690 = load i32, ptr %slot1613, align 8
  %cv8691 = zext i32 %v8690 to i64
  %cond8692 = icmp ne i64 %cv8691, 0
  br i1 %cond8692, label %bb_rcgdec2183, label %bb_rcgslow2183
bb_rcgslow2183:
  %v8693 = load i64, ptr %slot1600, align 8
  %v8694 = load i64, ptr %slot1597, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v8693, i64 %v8694) nomerge, !dbg !208
  br label %bb_rcgdone2183
bb_rcgdec2183:
  %v8695 = load i64, ptr %slot1609, align 8
  %v8696 = load i64, ptr %slot1601, align 8
  %p8697 = inttoptr i64 %v8696 to ptr
  %rgep8698 = getelementptr i8, ptr %p8697, i64 -24
  store i64 %v8695, ptr %rgep8698, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2183
bb_rcgclear2183:
  %v8699 = load i64, ptr %slot1597, align 8
  %p8700 = inttoptr i64 %v8699 to ptr
  store i64 0, ptr %p8700, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2183
bb_rcgdone2183:
  br label %bb_rcslotdone2167
bb_rcslotowner2167:
  %v8701 = load i64, ptr %slot46, align 8
  store i64 %v8701, ptr %slot1614, align 8
  %v8702 = load i64, ptr %slot1597, align 8
  %p8703 = inttoptr i64 %v8702 to ptr
  %ld8704 = load i64, ptr %p8703, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8704, ptr %slot1615, align 8
  %v8705 = load i64, ptr %slot1615, align 8
  %cmp8706 = icmp ne i64 %v8705, 0
  %cv8707 = zext i1 %cmp8706 to i32
  store i32 %cv8707, ptr %slot1616, align 8
  %v8708 = load i32, ptr %slot1616, align 8
  %cv8709 = zext i32 %v8708 to i64
  %cond8710 = icmp ne i64 %cv8709, 0
  br i1 %cond8710, label %bb_rcgnn2198, label %bb_rcgdone2198
bb_rcgnn2198:
  %v8711 = load i64, ptr %slot1615, align 8
  %op8712 = sub i64 %v8711, 16
  store i64 %op8712, ptr %slot1617, align 8
  %v8713 = load i64, ptr %slot1615, align 8
  %p8714 = inttoptr i64 %v8713 to ptr
  %rgep8715 = getelementptr i8, ptr %p8714, i64 -16
  %ld8716 = load i64, ptr %rgep8715, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8716, ptr %slot1618, align 8
  %v8717 = load i64, ptr %slot1618, align 8
  %op8718 = and i64 %v8717, 4611686018427387906
  store i64 %op8718, ptr %slot1619, align 8
  %v8719 = load i64, ptr %slot1619, align 8
  %cmp8720 = icmp ne i64 %v8719, 0
  %cv8721 = zext i1 %cmp8720 to i32
  store i32 %cv8721, ptr %slot1620, align 8
  %v8722 = load i32, ptr %slot1620, align 8
  %cv8723 = zext i32 %v8722 to i64
  %cond8724 = icmp ne i64 %cv8723, 0
  br i1 %cond8724, label %bb_rcgclear2198, label %bb_rcgcounted2198
bb_rcgcounted2198:
  %v8725 = load i64, ptr %slot1615, align 8
  %op8726 = sub i64 %v8725, 32
  store i64 %op8726, ptr %slot1621, align 8
  %v8727 = load i64, ptr %slot1615, align 8
  %p8728 = inttoptr i64 %v8727 to ptr
  %rgep8729 = getelementptr i8, ptr %p8728, i64 -32
  %ld8730 = load i64, ptr %rgep8729, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8730, ptr %slot1622, align 8
  %v8731 = load i64, ptr %slot1622, align 8
  %op8732 = sub i64 %v8731, 1
  store i64 %op8732, ptr %slot1623, align 8
  %v8733 = load i64, ptr %slot1623, align 8
  %cmp8734 = icmp eq i64 %v8733, 0
  %cv8735 = zext i1 %cmp8734 to i32
  store i32 %cv8735, ptr %slot1624, align 8
  %v8736 = load i32, ptr %slot1624, align 8
  %cv8737 = zext i32 %v8736 to i64
  %cond8738 = icmp ne i64 %cv8737, 0
  br i1 %cond8738, label %bb_rcglast2198, label %bb_rcgdec2198
bb_rcglast2198:
  %v8739 = load i64, ptr %slot1615, align 8
  %op8740 = sub i64 %v8739, 24
  store i64 %op8740, ptr %slot1625, align 8
  %v8741 = load i64, ptr %slot1615, align 8
  %p8742 = inttoptr i64 %v8741 to ptr
  %rgep8743 = getelementptr i8, ptr %p8742, i64 -24
  %ld8744 = load i64, ptr %rgep8743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8744, ptr %slot1626, align 8
  %v8745 = load i64, ptr %slot1626, align 8
  %cmp8746 = icmp ne i64 %v8745, 0
  %cv8747 = zext i1 %cmp8746 to i32
  store i32 %cv8747, ptr %slot1627, align 8
  %v8748 = load i32, ptr %slot1627, align 8
  %cv8749 = zext i32 %v8748 to i64
  %cond8750 = icmp ne i64 %cv8749, 0
  br i1 %cond8750, label %bb_rcgdec2198, label %bb_rcgslow2198
bb_rcgslow2198:
  %v8751 = load i64, ptr %slot1614, align 8
  %v8752 = load i64, ptr %slot1597, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v8751, i64 %v8752) nomerge, !dbg !208
  br label %bb_rcgdone2198
bb_rcgdec2198:
  %v8753 = load i64, ptr %slot1623, align 8
  %v8754 = load i64, ptr %slot1615, align 8
  %p8755 = inttoptr i64 %v8754 to ptr
  %rgep8756 = getelementptr i8, ptr %p8755, i64 -32
  store i64 %v8753, ptr %rgep8756, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2198
bb_rcgclear2198:
  %v8757 = load i64, ptr %slot1597, align 8
  %p8758 = inttoptr i64 %v8757 to ptr
  store i64 0, ptr %p8758, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2198
bb_rcgdone2198:
  br label %bb_rcslotdone2167
bb_rcslotdone2167:
  %v8759 = load i64, ptr %slot8, align 8
  %p8760 = inttoptr i64 %v8759 to ptr
  %ld8761 = load i32, ptr %p8760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8761, ptr %slot1628, align 8
  %v8762 = load i32, ptr %slot1628, align 8
  %cv8763 = zext i32 %v8762 to i64
  %cond8764 = icmp ne i64 %cv8763, 0
  br i1 %cond8764, label %bb_rcslotdrop2204, label %bb_rcslotdone2204
bb_rcslotdrop2204:
  %v8765 = load i64, ptr %slot8, align 8
  %p8766 = inttoptr i64 %v8765 to ptr
  store i32 0, ptr %p8766, align 4, !alias.scope !3, !noalias !4
  %v8767 = load i64, ptr %slot37, align 8
  store i64 %v8767, ptr %slot1629, align 8
  %v8768 = load i64, ptr %slot9, align 8
  %p8769 = inttoptr i64 %v8768 to ptr
  %ld8770 = load i32, ptr %p8769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8770, ptr %slot1630, align 8
  %v8771 = load i32, ptr %slot1630, align 8
  %op8772 = and i32 %v8771, 28
  store i32 %op8772, ptr %slot1631, align 8
  %v8773 = load i32, ptr %slot1631, align 8
  %cv8774 = zext i32 %v8773 to i64
  %cond8775 = icmp ne i64 %cv8774, 0
  br i1 %cond8775, label %bb_rcslotrole2204, label %bb_rcslotowner2204
bb_rcslotrole2204:
  %v8776 = load i64, ptr %slot46, align 8
  store i64 %v8776, ptr %slot1632, align 8
  %v8777 = load i64, ptr %slot1629, align 8
  %p8778 = inttoptr i64 %v8777 to ptr
  %ld8779 = load i64, ptr %p8778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8779, ptr %slot1633, align 8
  %v8780 = load i64, ptr %slot1633, align 8
  %cmp8781 = icmp ne i64 %v8780, 0
  %cv8782 = zext i1 %cmp8781 to i32
  store i32 %cv8782, ptr %slot1634, align 8
  %v8783 = load i32, ptr %slot1634, align 8
  %cv8784 = zext i32 %v8783 to i64
  %cond8785 = icmp ne i64 %cv8784, 0
  br i1 %cond8785, label %bb_rcgnn2220, label %bb_rcgdone2220
bb_rcgnn2220:
  %v8786 = load i64, ptr %slot1633, align 8
  %op8787 = sub i64 %v8786, 16
  store i64 %op8787, ptr %slot1635, align 8
  %v8788 = load i64, ptr %slot1633, align 8
  %p8789 = inttoptr i64 %v8788 to ptr
  %rgep8790 = getelementptr i8, ptr %p8789, i64 -16
  %ld8791 = load i64, ptr %rgep8790, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8791, ptr %slot1636, align 8
  %v8792 = load i64, ptr %slot1636, align 8
  %op8793 = and i64 %v8792, 4611686018427387906
  store i64 %op8793, ptr %slot1637, align 8
  %v8794 = load i64, ptr %slot1637, align 8
  %cmp8795 = icmp ne i64 %v8794, 0
  %cv8796 = zext i1 %cmp8795 to i32
  store i32 %cv8796, ptr %slot1638, align 8
  %v8797 = load i32, ptr %slot1638, align 8
  %cv8798 = zext i32 %v8797 to i64
  %cond8799 = icmp ne i64 %cv8798, 0
  br i1 %cond8799, label %bb_rcgclear2220, label %bb_rcgcounted2220
bb_rcgcounted2220:
  %v8800 = load i64, ptr %slot1633, align 8
  %op8801 = sub i64 %v8800, 24
  store i64 %op8801, ptr %slot1639, align 8
  %v8802 = load i64, ptr %slot1633, align 8
  %p8803 = inttoptr i64 %v8802 to ptr
  %rgep8804 = getelementptr i8, ptr %p8803, i64 -24
  %ld8805 = load i64, ptr %rgep8804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8805, ptr %slot1640, align 8
  %v8806 = load i64, ptr %slot1640, align 8
  %op8807 = sub i64 %v8806, 1
  store i64 %op8807, ptr %slot1641, align 8
  %v8808 = load i64, ptr %slot1641, align 8
  %cmp8809 = icmp eq i64 %v8808, 0
  %cv8810 = zext i1 %cmp8809 to i32
  store i32 %cv8810, ptr %slot1642, align 8
  %v8811 = load i32, ptr %slot1642, align 8
  %cv8812 = zext i32 %v8811 to i64
  %cond8813 = icmp ne i64 %cv8812, 0
  br i1 %cond8813, label %bb_rcglast2220, label %bb_rcgdec2220
bb_rcglast2220:
  %v8814 = load i64, ptr %slot1633, align 8
  %op8815 = sub i64 %v8814, 32
  store i64 %op8815, ptr %slot1643, align 8
  %v8816 = load i64, ptr %slot1633, align 8
  %p8817 = inttoptr i64 %v8816 to ptr
  %rgep8818 = getelementptr i8, ptr %p8817, i64 -32
  %ld8819 = load i64, ptr %rgep8818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8819, ptr %slot1644, align 8
  %v8820 = load i64, ptr %slot1644, align 8
  %cmp8821 = icmp ne i64 %v8820, 0
  %cv8822 = zext i1 %cmp8821 to i32
  store i32 %cv8822, ptr %slot1645, align 8
  %v8823 = load i32, ptr %slot1645, align 8
  %cv8824 = zext i32 %v8823 to i64
  %cond8825 = icmp ne i64 %cv8824, 0
  br i1 %cond8825, label %bb_rcgdec2220, label %bb_rcgslow2220
bb_rcgslow2220:
  %v8826 = load i64, ptr %slot1632, align 8
  %v8827 = load i64, ptr %slot1629, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v8826, i64 %v8827) nomerge, !dbg !208
  br label %bb_rcgdone2220
bb_rcgdec2220:
  %v8828 = load i64, ptr %slot1641, align 8
  %v8829 = load i64, ptr %slot1633, align 8
  %p8830 = inttoptr i64 %v8829 to ptr
  %rgep8831 = getelementptr i8, ptr %p8830, i64 -24
  store i64 %v8828, ptr %rgep8831, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2220
bb_rcgclear2220:
  %v8832 = load i64, ptr %slot1629, align 8
  %p8833 = inttoptr i64 %v8832 to ptr
  store i64 0, ptr %p8833, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2220
bb_rcgdone2220:
  br label %bb_rcslotdone2204
bb_rcslotowner2204:
  %v8834 = load i64, ptr %slot46, align 8
  store i64 %v8834, ptr %slot1646, align 8
  %v8835 = load i64, ptr %slot1629, align 8
  %p8836 = inttoptr i64 %v8835 to ptr
  %ld8837 = load i64, ptr %p8836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8837, ptr %slot1647, align 8
  %v8838 = load i64, ptr %slot1647, align 8
  %cmp8839 = icmp ne i64 %v8838, 0
  %cv8840 = zext i1 %cmp8839 to i32
  store i32 %cv8840, ptr %slot1648, align 8
  %v8841 = load i32, ptr %slot1648, align 8
  %cv8842 = zext i32 %v8841 to i64
  %cond8843 = icmp ne i64 %cv8842, 0
  br i1 %cond8843, label %bb_rcgnn2235, label %bb_rcgdone2235
bb_rcgnn2235:
  %v8844 = load i64, ptr %slot1647, align 8
  %op8845 = sub i64 %v8844, 16
  store i64 %op8845, ptr %slot1649, align 8
  %v8846 = load i64, ptr %slot1647, align 8
  %p8847 = inttoptr i64 %v8846 to ptr
  %rgep8848 = getelementptr i8, ptr %p8847, i64 -16
  %ld8849 = load i64, ptr %rgep8848, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8849, ptr %slot1650, align 8
  %v8850 = load i64, ptr %slot1650, align 8
  %op8851 = and i64 %v8850, 4611686018427387906
  store i64 %op8851, ptr %slot1651, align 8
  %v8852 = load i64, ptr %slot1651, align 8
  %cmp8853 = icmp ne i64 %v8852, 0
  %cv8854 = zext i1 %cmp8853 to i32
  store i32 %cv8854, ptr %slot1652, align 8
  %v8855 = load i32, ptr %slot1652, align 8
  %cv8856 = zext i32 %v8855 to i64
  %cond8857 = icmp ne i64 %cv8856, 0
  br i1 %cond8857, label %bb_rcgclear2235, label %bb_rcgcounted2235
bb_rcgcounted2235:
  %v8858 = load i64, ptr %slot1647, align 8
  %op8859 = sub i64 %v8858, 32
  store i64 %op8859, ptr %slot1653, align 8
  %v8860 = load i64, ptr %slot1647, align 8
  %p8861 = inttoptr i64 %v8860 to ptr
  %rgep8862 = getelementptr i8, ptr %p8861, i64 -32
  %ld8863 = load i64, ptr %rgep8862, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8863, ptr %slot1654, align 8
  %v8864 = load i64, ptr %slot1654, align 8
  %op8865 = sub i64 %v8864, 1
  store i64 %op8865, ptr %slot1655, align 8
  %v8866 = load i64, ptr %slot1655, align 8
  %cmp8867 = icmp eq i64 %v8866, 0
  %cv8868 = zext i1 %cmp8867 to i32
  store i32 %cv8868, ptr %slot1656, align 8
  %v8869 = load i32, ptr %slot1656, align 8
  %cv8870 = zext i32 %v8869 to i64
  %cond8871 = icmp ne i64 %cv8870, 0
  br i1 %cond8871, label %bb_rcglast2235, label %bb_rcgdec2235
bb_rcglast2235:
  %v8872 = load i64, ptr %slot1647, align 8
  %op8873 = sub i64 %v8872, 24
  store i64 %op8873, ptr %slot1657, align 8
  %v8874 = load i64, ptr %slot1647, align 8
  %p8875 = inttoptr i64 %v8874 to ptr
  %rgep8876 = getelementptr i8, ptr %p8875, i64 -24
  %ld8877 = load i64, ptr %rgep8876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8877, ptr %slot1658, align 8
  %v8878 = load i64, ptr %slot1658, align 8
  %cmp8879 = icmp ne i64 %v8878, 0
  %cv8880 = zext i1 %cmp8879 to i32
  store i32 %cv8880, ptr %slot1659, align 8
  %v8881 = load i32, ptr %slot1659, align 8
  %cv8882 = zext i32 %v8881 to i64
  %cond8883 = icmp ne i64 %cv8882, 0
  br i1 %cond8883, label %bb_rcgdec2235, label %bb_rcgslow2235
bb_rcgslow2235:
  %v8884 = load i64, ptr %slot1646, align 8
  %v8885 = load i64, ptr %slot1629, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v8884, i64 %v8885) nomerge, !dbg !208
  br label %bb_rcgdone2235
bb_rcgdec2235:
  %v8886 = load i64, ptr %slot1655, align 8
  %v8887 = load i64, ptr %slot1647, align 8
  %p8888 = inttoptr i64 %v8887 to ptr
  %rgep8889 = getelementptr i8, ptr %p8888, i64 -32
  store i64 %v8886, ptr %rgep8889, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2235
bb_rcgclear2235:
  %v8890 = load i64, ptr %slot1629, align 8
  %p8891 = inttoptr i64 %v8890 to ptr
  store i64 0, ptr %p8891, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2235
bb_rcgdone2235:
  br label %bb_rcslotdone2204
bb_rcslotdone2204:
  %v8892 = load i64, ptr %slot6, align 8
  %p8893 = inttoptr i64 %v8892 to ptr
  %ld8894 = load i32, ptr %p8893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8894, ptr %slot1660, align 8
  %v8895 = load i32, ptr %slot1660, align 8
  %cv8896 = zext i32 %v8895 to i64
  %cond8897 = icmp ne i64 %cv8896, 0
  br i1 %cond8897, label %bb_rcslotdrop2241, label %bb_rcslotdone2241
bb_rcslotdrop2241:
  %v8898 = load i64, ptr %slot6, align 8
  %p8899 = inttoptr i64 %v8898 to ptr
  store i32 0, ptr %p8899, align 4, !alias.scope !3, !noalias !4
  %v8900 = load i64, ptr %slot36, align 8
  store i64 %v8900, ptr %slot1661, align 8
  %v8901 = load i64, ptr %slot7, align 8
  %p8902 = inttoptr i64 %v8901 to ptr
  %ld8903 = load i32, ptr %p8902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8903, ptr %slot1662, align 8
  %v8904 = load i32, ptr %slot1662, align 8
  %op8905 = and i32 %v8904, 28
  store i32 %op8905, ptr %slot1663, align 8
  %v8906 = load i32, ptr %slot1663, align 8
  %cv8907 = zext i32 %v8906 to i64
  %cond8908 = icmp ne i64 %cv8907, 0
  br i1 %cond8908, label %bb_rcslotrole2241, label %bb_rcslotowner2241
bb_rcslotrole2241:
  %v8909 = load i64, ptr %slot46, align 8
  store i64 %v8909, ptr %slot1664, align 8
  %v8910 = load i64, ptr %slot1661, align 8
  %p8911 = inttoptr i64 %v8910 to ptr
  %ld8912 = load i64, ptr %p8911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8912, ptr %slot1665, align 8
  %v8913 = load i64, ptr %slot1665, align 8
  %cmp8914 = icmp ne i64 %v8913, 0
  %cv8915 = zext i1 %cmp8914 to i32
  store i32 %cv8915, ptr %slot1666, align 8
  %v8916 = load i32, ptr %slot1666, align 8
  %cv8917 = zext i32 %v8916 to i64
  %cond8918 = icmp ne i64 %cv8917, 0
  br i1 %cond8918, label %bb_rcgnn2257, label %bb_rcgdone2257
bb_rcgnn2257:
  %v8919 = load i64, ptr %slot1665, align 8
  %op8920 = sub i64 %v8919, 16
  store i64 %op8920, ptr %slot1667, align 8
  %v8921 = load i64, ptr %slot1665, align 8
  %p8922 = inttoptr i64 %v8921 to ptr
  %rgep8923 = getelementptr i8, ptr %p8922, i64 -16
  %ld8924 = load i64, ptr %rgep8923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8924, ptr %slot1668, align 8
  %v8925 = load i64, ptr %slot1668, align 8
  %op8926 = and i64 %v8925, 4611686018427387906
  store i64 %op8926, ptr %slot1669, align 8
  %v8927 = load i64, ptr %slot1669, align 8
  %cmp8928 = icmp ne i64 %v8927, 0
  %cv8929 = zext i1 %cmp8928 to i32
  store i32 %cv8929, ptr %slot1670, align 8
  %v8930 = load i32, ptr %slot1670, align 8
  %cv8931 = zext i32 %v8930 to i64
  %cond8932 = icmp ne i64 %cv8931, 0
  br i1 %cond8932, label %bb_rcgclear2257, label %bb_rcgcounted2257
bb_rcgcounted2257:
  %v8933 = load i64, ptr %slot1665, align 8
  %op8934 = sub i64 %v8933, 24
  store i64 %op8934, ptr %slot1671, align 8
  %v8935 = load i64, ptr %slot1665, align 8
  %p8936 = inttoptr i64 %v8935 to ptr
  %rgep8937 = getelementptr i8, ptr %p8936, i64 -24
  %ld8938 = load i64, ptr %rgep8937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8938, ptr %slot1672, align 8
  %v8939 = load i64, ptr %slot1672, align 8
  %op8940 = sub i64 %v8939, 1
  store i64 %op8940, ptr %slot1673, align 8
  %v8941 = load i64, ptr %slot1673, align 8
  %cmp8942 = icmp eq i64 %v8941, 0
  %cv8943 = zext i1 %cmp8942 to i32
  store i32 %cv8943, ptr %slot1674, align 8
  %v8944 = load i32, ptr %slot1674, align 8
  %cv8945 = zext i32 %v8944 to i64
  %cond8946 = icmp ne i64 %cv8945, 0
  br i1 %cond8946, label %bb_rcglast2257, label %bb_rcgdec2257
bb_rcglast2257:
  %v8947 = load i64, ptr %slot1665, align 8
  %op8948 = sub i64 %v8947, 32
  store i64 %op8948, ptr %slot1675, align 8
  %v8949 = load i64, ptr %slot1665, align 8
  %p8950 = inttoptr i64 %v8949 to ptr
  %rgep8951 = getelementptr i8, ptr %p8950, i64 -32
  %ld8952 = load i64, ptr %rgep8951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8952, ptr %slot1676, align 8
  %v8953 = load i64, ptr %slot1676, align 8
  %cmp8954 = icmp ne i64 %v8953, 0
  %cv8955 = zext i1 %cmp8954 to i32
  store i32 %cv8955, ptr %slot1677, align 8
  %v8956 = load i32, ptr %slot1677, align 8
  %cv8957 = zext i32 %v8956 to i64
  %cond8958 = icmp ne i64 %cv8957, 0
  br i1 %cond8958, label %bb_rcgdec2257, label %bb_rcgslow2257
bb_rcgslow2257:
  %v8959 = load i64, ptr %slot1664, align 8
  %v8960 = load i64, ptr %slot1661, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v8959, i64 %v8960) nomerge, !dbg !208
  br label %bb_rcgdone2257
bb_rcgdec2257:
  %v8961 = load i64, ptr %slot1673, align 8
  %v8962 = load i64, ptr %slot1665, align 8
  %p8963 = inttoptr i64 %v8962 to ptr
  %rgep8964 = getelementptr i8, ptr %p8963, i64 -24
  store i64 %v8961, ptr %rgep8964, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2257
bb_rcgclear2257:
  %v8965 = load i64, ptr %slot1661, align 8
  %p8966 = inttoptr i64 %v8965 to ptr
  store i64 0, ptr %p8966, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2257
bb_rcgdone2257:
  br label %bb_rcslotdone2241
bb_rcslotowner2241:
  %v8967 = load i64, ptr %slot46, align 8
  store i64 %v8967, ptr %slot1678, align 8
  %v8968 = load i64, ptr %slot1661, align 8
  %p8969 = inttoptr i64 %v8968 to ptr
  %ld8970 = load i64, ptr %p8969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8970, ptr %slot1679, align 8
  %v8971 = load i64, ptr %slot1679, align 8
  %cmp8972 = icmp ne i64 %v8971, 0
  %cv8973 = zext i1 %cmp8972 to i32
  store i32 %cv8973, ptr %slot1680, align 8
  %v8974 = load i32, ptr %slot1680, align 8
  %cv8975 = zext i32 %v8974 to i64
  %cond8976 = icmp ne i64 %cv8975, 0
  br i1 %cond8976, label %bb_rcgnn2272, label %bb_rcgdone2272
bb_rcgnn2272:
  %v8977 = load i64, ptr %slot1679, align 8
  %op8978 = sub i64 %v8977, 16
  store i64 %op8978, ptr %slot1681, align 8
  %v8979 = load i64, ptr %slot1679, align 8
  %p8980 = inttoptr i64 %v8979 to ptr
  %rgep8981 = getelementptr i8, ptr %p8980, i64 -16
  %ld8982 = load i64, ptr %rgep8981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8982, ptr %slot1682, align 8
  %v8983 = load i64, ptr %slot1682, align 8
  %op8984 = and i64 %v8983, 4611686018427387906
  store i64 %op8984, ptr %slot1683, align 8
  %v8985 = load i64, ptr %slot1683, align 8
  %cmp8986 = icmp ne i64 %v8985, 0
  %cv8987 = zext i1 %cmp8986 to i32
  store i32 %cv8987, ptr %slot1684, align 8
  %v8988 = load i32, ptr %slot1684, align 8
  %cv8989 = zext i32 %v8988 to i64
  %cond8990 = icmp ne i64 %cv8989, 0
  br i1 %cond8990, label %bb_rcgclear2272, label %bb_rcgcounted2272
bb_rcgcounted2272:
  %v8991 = load i64, ptr %slot1679, align 8
  %op8992 = sub i64 %v8991, 32
  store i64 %op8992, ptr %slot1685, align 8
  %v8993 = load i64, ptr %slot1679, align 8
  %p8994 = inttoptr i64 %v8993 to ptr
  %rgep8995 = getelementptr i8, ptr %p8994, i64 -32
  %ld8996 = load i64, ptr %rgep8995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8996, ptr %slot1686, align 8
  %v8997 = load i64, ptr %slot1686, align 8
  %op8998 = sub i64 %v8997, 1
  store i64 %op8998, ptr %slot1687, align 8
  %v8999 = load i64, ptr %slot1687, align 8
  %cmp9000 = icmp eq i64 %v8999, 0
  %cv9001 = zext i1 %cmp9000 to i32
  store i32 %cv9001, ptr %slot1688, align 8
  %v9002 = load i32, ptr %slot1688, align 8
  %cv9003 = zext i32 %v9002 to i64
  %cond9004 = icmp ne i64 %cv9003, 0
  br i1 %cond9004, label %bb_rcglast2272, label %bb_rcgdec2272
bb_rcglast2272:
  %v9005 = load i64, ptr %slot1679, align 8
  %op9006 = sub i64 %v9005, 24
  store i64 %op9006, ptr %slot1689, align 8
  %v9007 = load i64, ptr %slot1679, align 8
  %p9008 = inttoptr i64 %v9007 to ptr
  %rgep9009 = getelementptr i8, ptr %p9008, i64 -24
  %ld9010 = load i64, ptr %rgep9009, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9010, ptr %slot1690, align 8
  %v9011 = load i64, ptr %slot1690, align 8
  %cmp9012 = icmp ne i64 %v9011, 0
  %cv9013 = zext i1 %cmp9012 to i32
  store i32 %cv9013, ptr %slot1691, align 8
  %v9014 = load i32, ptr %slot1691, align 8
  %cv9015 = zext i32 %v9014 to i64
  %cond9016 = icmp ne i64 %cv9015, 0
  br i1 %cond9016, label %bb_rcgdec2272, label %bb_rcgslow2272
bb_rcgslow2272:
  %v9017 = load i64, ptr %slot1678, align 8
  %v9018 = load i64, ptr %slot1661, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v9017, i64 %v9018) nomerge, !dbg !208
  br label %bb_rcgdone2272
bb_rcgdec2272:
  %v9019 = load i64, ptr %slot1687, align 8
  %v9020 = load i64, ptr %slot1679, align 8
  %p9021 = inttoptr i64 %v9020 to ptr
  %rgep9022 = getelementptr i8, ptr %p9021, i64 -32
  store i64 %v9019, ptr %rgep9022, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2272
bb_rcgclear2272:
  %v9023 = load i64, ptr %slot1661, align 8
  %p9024 = inttoptr i64 %v9023 to ptr
  store i64 0, ptr %p9024, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2272
bb_rcgdone2272:
  br label %bb_rcslotdone2241
bb_rcslotdone2241:
  %v9025 = load i64, ptr %slot1589, align 8
  %p9026 = inttoptr i64 %v9025 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p9026, i64 40, i1 false)
  ret void
bb_failure:
  %v9027 = load i64, ptr %slot5, align 8
  %p9028 = inttoptr i64 %v9027 to ptr
  call void @llvm.memset.p0.i64(ptr %p9028, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !208
  %v9029 = load i64, ptr %slot5, align 8
  %p9030 = inttoptr i64 %v9029 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p9030, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v9031 = load i64, ptr %slot5, align 8
  %p9032 = inttoptr i64 %v9031 to ptr
  call void @llvm.memset.p0.i64(ptr %p9032, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !208
  %v9033 = load i64, ptr %slot5, align 8
  %p9034 = inttoptr i64 %v9033 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p9034, i64 40, i1 false)
  ret void
}

@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8
@myl_t_db15a47f73854f7ebc4f4ae65ec67e894512211a55599ebe8bbfe5cf82a0ab47 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_assert(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_drop(i64, i64)
declare void @myl_t_3fbe4cc99fb5a57da17772281c921da4f54b29903abc47c1c41ab16feea423ac_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_drop(i64, i64)
declare void @myl_t_944d650aef3e197f2951c2994f5a48b69ce184c5770e2df53366d0eeb51eeaf4_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_drop(i64, i64)
declare i32 @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_c000f22f7ee44dea31e81b0a933c1dec3a560f42212434ae24333c6a58c466f9_rcg_unloan(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_drop(i64, i64)
declare void @myl_t_d0874b46aa914472a0c31ec6a69c7d5999c1d36bc3d75aa56e5d28c3c2eda5b8_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 56v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !11}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_bf0431d3d9e553eacefcb10ebb00251bb8b43354cc87fd12c99ceb5644f705d6", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_bf0431d3d9e553eacefcb10ebb00251bb8b43354cc87fd12c99ceb5644f705d6", linkageName: "myl_f_bf0431d3d9e553eacefcb10ebb00251bb8b43354cc87fd12c99ceb5644f705d6", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 18093635364448888292, i64 0, !"myl_f_bf0431d3d9e553eacefcb10ebb00251bb8b43354cc87fd12c99ceb5644f705d6"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!112 = !DILocation(line: 2, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!114 = !DILocation(line: 12, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!116 = !DILocation(line: 14, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!118 = !DILocation(line: 17, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!120 = !DILocation(line: 18, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!122 = !DILocation(line: 23, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!124 = !DILocation(line: 26, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!126 = !DILocation(line: 33, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!128 = !DILocation(line: 35, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!130 = !DILocation(line: 38, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!132 = !DILocation(line: 39, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!134 = !DILocation(line: 44, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!136 = !DILocation(line: 45, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646903)
!138 = !DILocation(line: 46, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!140 = !DILocation(line: 48, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!142 = !DILocation(line: 49, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!144 = !DILocation(line: 50, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!146 = !DILocation(line: 52, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!148 = !DILocation(line: 53, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!150 = !DILocation(line: 58, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!152 = !DILocation(line: 59, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!154 = !DILocation(line: 61, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647047)
!156 = !DILocation(line: 64, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!158 = !DILocation(line: 67, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!160 = !DILocation(line: 70, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647119)
!162 = !DILocation(line: 73, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!164 = !DILocation(line: 76, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!166 = !DILocation(line: 79, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!168 = !DILocation(line: 82, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647215)
!170 = !DILocation(line: 85, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647239)
!172 = !DILocation(line: 88, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647279)
!174 = !DILocation(line: 93, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!176 = !DILocation(line: 96, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!178 = !DILocation(line: 99, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647351)
!180 = !DILocation(line: 102, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647375)
!182 = !DILocation(line: 105, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647399)
!184 = !DILocation(line: 108, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647423)
!186 = !DILocation(line: 111, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647447)
!188 = !DILocation(line: 114, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647471)
!190 = !DILocation(line: 117, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647495)
!192 = !DILocation(line: 120, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647519)
!194 = !DILocation(line: 123, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647527)
!196 = !DILocation(line: 124, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647559)
!198 = !DILocation(line: 128, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647567)
!200 = !DILocation(line: 129, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647599)
!202 = !DILocation(line: 133, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647607)
!204 = !DILocation(line: 134, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647663)
!206 = !DILocation(line: 141, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647671)
!208 = !DILocation(line: 142, column: 0, scope: !209)
