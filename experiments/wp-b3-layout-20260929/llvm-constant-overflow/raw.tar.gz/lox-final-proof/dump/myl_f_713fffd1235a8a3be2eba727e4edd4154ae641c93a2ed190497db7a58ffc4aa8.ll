target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v35 = load i64, ptr %slot1, align 8
  %op36 = add i64 %v35, 32
  store i64 %op36, ptr %slot4, align 8
  %mem37 = alloca i8, i64 8, align 8
  %ptr38 = ptrtoint ptr %mem37 to i64
  store i64 %ptr38, ptr %slot5, align 8
  %mem39 = alloca i8, i64 16, align 8
  %ptr40 = ptrtoint ptr %mem39 to i64
  store i64 %ptr40, ptr %slot6, align 8
  %mem41 = alloca i8, i64 8, align 8
  %ptr42 = ptrtoint ptr %mem41 to i64
  store i64 %ptr42, ptr %slot7, align 8
  %mem43 = alloca i8, i64 8, align 8
  %ptr44 = ptrtoint ptr %mem43 to i64
  store i64 %ptr44, ptr %slot8, align 8
  %mem45 = alloca i8, i64 8, align 8
  %ptr46 = ptrtoint ptr %mem45 to i64
  store i64 %ptr46, ptr %slot9, align 8
  %mem47 = alloca i8, i64 8, align 8
  %ptr48 = ptrtoint ptr %mem47 to i64
  store i64 %ptr48, ptr %slot10, align 8
  %mem49 = alloca i8, i64 8, align 8
  %ptr50 = ptrtoint ptr %mem49 to i64
  store i64 %ptr50, ptr %slot11, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem51 = alloca i8, i64 8, align 8
  %ptr52 = ptrtoint ptr %mem51 to i64
  store i64 %ptr52, ptr %slot12, align 8
  %v53 = load i64, ptr %slot1, align 8
  %op54 = add i64 %v53, 64
  store i64 %op54, ptr %slot13, align 8
  %v55 = load i64, ptr %slot13, align 8
  %p56 = inttoptr i64 %v55 to ptr
  %ld57 = load i64, ptr %p56, align 8, !alias.scope !4, !noalias !3
  store i64 %ld57, ptr %slot14, align 8
  %stack58 = call ptr @llvm.stacksave()
  %stackaddr59 = ptrtoint ptr %stack58 to i64
  %v60 = load i64, ptr %slot14, align 8
  %cmp61 = icmp ult i64 %stackaddr59, %v60
  %cv62 = zext i1 %cmp61 to i64
  store i64 %cv62, ptr %slot15, align 8
  %v63 = load i64, ptr %slot15, align 8
  %cond64 = icmp ne i64 %v63, 0
  br i1 %cond64, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v65 = load i64, ptr %slot1, align 8
  %p66 = inttoptr i64 %v65 to ptr
  call void @myl_qbe_fail_frame(ptr %p66) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v67 = load i64, ptr %slot2, align 8
  %v68 = load i64, ptr %slot7, align 8
  %p69 = inttoptr i64 %v68 to ptr
  store i64 %v67, ptr %p69, align 8, !alias.scope !3, !noalias !4
  %v70 = load i64, ptr %slot3, align 8
  %v71 = load i64, ptr %slot8, align 8
  %p72 = inttoptr i64 %v71 to ptr
  store i64 %v70, ptr %p72, align 8, !alias.scope !3, !noalias !4
  %v73 = load i64, ptr %slot1, align 8
  %p74 = inttoptr i64 %v73 to ptr
  %call75 = call i64 @myl_qbe_region_mark(ptr %p74) nomerge, !dbg !112
  store i64 %call75, ptr %slot16, align 8
  %v76 = load i64, ptr %slot5, align 8
  %p77 = inttoptr i64 %v76 to ptr
  store i32 0, ptr %p77, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v78 = load i64, ptr %slot8, align 8
  %p79 = inttoptr i64 %v78 to ptr
  %ld80 = load i64, ptr %p79, align 8, !alias.scope !3, !noalias !4
  store i64 %ld80, ptr %slot17, align 8
  %v81 = load i64, ptr %slot17, align 8
  %v82 = load i64, ptr %slot10, align 8
  %p83 = inttoptr i64 %v82 to ptr
  store i64 %v81, ptr %p83, align 8, !alias.scope !3, !noalias !4
  %v84 = load i64, ptr %slot10, align 8
  %p85 = inttoptr i64 %v84 to ptr
  %ld86 = load i64, ptr %p85, align 8, !alias.scope !3, !noalias !4
  store i64 %ld86, ptr %slot18, align 8
  %v87 = load i64, ptr %slot18, align 8
  %p88 = inttoptr i64 %v87 to ptr
  %ld89 = load i32, ptr %p88, align 4, !alias.scope !4, !noalias !3
  %ext90 = zext i32 %ld89 to i64
  store i64 %ext90, ptr %slot19, align 8
  %v91 = load i64, ptr %slot19, align 8
  %cmp92 = icmp eq i64 %v91, 0
  %cv93 = zext i1 %cmp92 to i64
  store i64 %cv93, ptr %slot20, align 8
  %v94 = load i64, ptr %slot20, align 8
  %cond95 = icmp ne i64 %v94, 0
  br i1 %cond95, label %bb_rcarm11, label %bb_rcarmnext11
bb_rcarm11:
  br label %bb_i7
bb_rcarmnext11:
  %v96 = load i64, ptr %slot19, align 8
  %cmp97 = icmp eq i64 %v96, 1
  %cv98 = zext i1 %cmp97 to i64
  store i64 %cv98, ptr %slot21, align 8
  %v99 = load i64, ptr %slot21, align 8
  %cond100 = icmp ne i64 %v99, 0
  br i1 %cond100, label %bb_rcarm12, label %bb_rcarmnext12
bb_rcarm12:
  br label %bb_i8
bb_rcarmnext12:
  %v101 = load i64, ptr %slot19, align 8
  %cmp102 = icmp eq i64 %v101, 2
  %cv103 = zext i1 %cmp102 to i64
  store i64 %cv103, ptr %slot22, align 8
  %v104 = load i64, ptr %slot22, align 8
  %cond105 = icmp ne i64 %v104, 0
  br i1 %cond105, label %bb_rcarm13, label %bb_rcarmnext13
bb_rcarm13:
  br label %bb_i9
bb_rcarmnext13:
  %v106 = load i64, ptr %slot19, align 8
  %cmp107 = icmp eq i64 %v106, 3
  %cv108 = zext i1 %cmp107 to i64
  store i64 %cv108, ptr %slot23, align 8
  %v109 = load i64, ptr %slot23, align 8
  %cond110 = icmp ne i64 %v109, 0
  br i1 %cond110, label %bb_rcarm14, label %bb_rcarmnext14
bb_rcarm14:
  %v111 = load i64, ptr %slot6, align 8
  store i64 %v111, ptr %slot24, align 8
  %v112 = load i64, ptr %slot18, align 8
  %op113 = add i64 %v112, 8
  store i64 %op113, ptr %slot25, align 8
  %v114 = load i64, ptr %slot16, align 8
  store i64 %v114, ptr %slot26, align 8
  %v115 = load i64, ptr %slot25, align 8
  %p116 = inttoptr i64 %v115 to ptr
  %ld117 = load i64, ptr %p116, align 8, !alias.scope !4, !noalias !3
  store i64 %ld117, ptr %slot27, align 8
  %v118 = load i64, ptr %slot27, align 8
  %v119 = load i64, ptr %slot24, align 8
  %p120 = inttoptr i64 %v119 to ptr
  store i64 %v118, ptr %p120, align 8, !alias.scope !3, !noalias !4
  %v121 = load i64, ptr %slot5, align 8
  %p122 = inttoptr i64 %v121 to ptr
  store i32 1, ptr %p122, align 4, !alias.scope !3, !noalias !4
  %v123 = load i64, ptr %slot24, align 8
  %p124 = inttoptr i64 %v123 to ptr
  %ld125 = load i64, ptr %p124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld125, ptr %slot28, align 8
  %v126 = load i64, ptr %slot28, align 8
  %v127 = load i64, ptr %slot9, align 8
  %p128 = inttoptr i64 %v127 to ptr
  store i64 %v126, ptr %p128, align 8, !alias.scope !3, !noalias !4
  %v129 = load i64, ptr %slot5, align 8
  %p130 = inttoptr i64 %v129 to ptr
  store i32 0, ptr %p130, align 4, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_rcarmnext14:
  br label %bb_failure
bb_i2:
  %v131 = load i64, ptr %slot7, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %ld133 = load i64, ptr %p132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld133, ptr %slot29, align 8
  %v134 = load i64, ptr %slot29, align 8
  %v135 = load i64, ptr %slot10, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i64 %v134, ptr %p136, align 8, !alias.scope !3, !noalias !4
  %v137 = load i64, ptr %slot9, align 8
  %p138 = inttoptr i64 %v137 to ptr
  %ld139 = load i64, ptr %p138, align 8, !alias.scope !3, !noalias !4
  store i64 %ld139, ptr %slot30, align 8
  %v140 = load i64, ptr %slot30, align 8
  %v141 = load i64, ptr %slot11, align 8
  %p142 = inttoptr i64 %v141 to ptr
  store i64 %v140, ptr %p142, align 8, !alias.scope !3, !noalias !4
  %v143 = load i64, ptr %slot10, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %ld145 = load i64, ptr %p144, align 8, !alias.scope !3, !noalias !4
  store i64 %ld145, ptr %slot31, align 8
  %v146 = load i64, ptr %slot11, align 8
  %p147 = inttoptr i64 %v146 to ptr
  %ld148 = load i64, ptr %p147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld148, ptr %slot32, align 8
  %v149 = load i64, ptr %slot1, align 8
  %v150 = load i64, ptr %slot31, align 8
  %v151 = load i64, ptr %slot32, align 8
  %call152 = call i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64 %v149, i64 %v150, i64 %v151) nomerge, !dbg !114
  store i64 %call152, ptr %slot33, align 8
  %v153 = load i64, ptr %slot33, align 8
  %v154 = load i64, ptr %slot10, align 8
  %p155 = inttoptr i64 %v154 to ptr
  store i64 %v153, ptr %p155, align 8, !alias.scope !3, !noalias !4
  br label %bb_i10
bb_i7:
  br label %bb_i10
bb_i8:
  br label %bb_i10
bb_i9:
  br label %bb_i10
bb_i10:
  %v156 = load i64, ptr %slot10, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i64 0, ptr %p157, align 8, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot10, align 8
  %p159 = inttoptr i64 %v158 to ptr
  %ld160 = load i64, ptr %p159, align 8, !alias.scope !3, !noalias !4
  store i64 %ld160, ptr %slot34, align 8
  %v161 = load i64, ptr %slot34, align 8
  ret i64 %v161
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare ptr @llvm.stacksave()
declare i64 @myl_f_c4c5a4c6a4cdae13084bc2cde9519648aa8aacd3f71e4fb8057ea0563c67d8c6(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare i64 @myl_qbe_region_mark(ptr)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8", linkageName: "myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10674351217424887998, i64 0, !"myl_f_713fffd1235a8a3be2eba727e4edd4154ae641c93a2ed190497db7a58ffc4aa8"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!114 = !DILocation(line: 5, column: 0, scope: !115)
