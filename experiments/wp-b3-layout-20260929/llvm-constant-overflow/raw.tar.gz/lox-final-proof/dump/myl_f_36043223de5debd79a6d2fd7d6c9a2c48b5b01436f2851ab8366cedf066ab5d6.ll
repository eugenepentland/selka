target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_36043223de5debd79a6d2fd7d6c9a2c48b5b01436f2851ab8366cedf066ab5d6(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i32, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i32, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v75 = load i64, ptr %slot1, align 8
  %op76 = add i64 %v75, 32
  store i64 %op76, ptr %slot3, align 8
  %mem77 = alloca i8, i64 8, align 8
  %ptr78 = ptrtoint ptr %mem77 to i64
  store i64 %ptr78, ptr %slot4, align 8
  %mem79 = alloca i8, i64 8, align 8
  %ptr80 = ptrtoint ptr %mem79 to i64
  store i64 %ptr80, ptr %slot5, align 8
  %mem81 = alloca i8, i64 8, align 8
  %ptr82 = ptrtoint ptr %mem81 to i64
  store i64 %ptr82, ptr %slot6, align 8
  %mem83 = alloca i8, i64 8, align 8
  %ptr84 = ptrtoint ptr %mem83 to i64
  store i64 %ptr84, ptr %slot7, align 8
  %mem85 = alloca i8, i64 8, align 8
  %ptr86 = ptrtoint ptr %mem85 to i64
  store i64 %ptr86, ptr %slot8, align 8
  %mem87 = alloca i8, i64 8, align 8
  %ptr88 = ptrtoint ptr %mem87 to i64
  store i64 %ptr88, ptr %slot9, align 8
  %mem89 = alloca i8, i64 392, align 8
  %ptr90 = ptrtoint ptr %mem89 to i64
  store i64 %ptr90, ptr %slot10, align 8
  %mem91 = alloca i8, i64 8, align 8
  %ptr92 = ptrtoint ptr %mem91 to i64
  store i64 %ptr92, ptr %slot11, align 8
  %mem93 = alloca i8, i64 8, align 8
  %ptr94 = ptrtoint ptr %mem93 to i64
  store i64 %ptr94, ptr %slot12, align 8
  %mem95 = alloca i8, i64 8, align 8
  %ptr96 = ptrtoint ptr %mem95 to i64
  store i64 %ptr96, ptr %slot13, align 8
  %mem97 = alloca i8, i64 8, align 8
  %ptr98 = ptrtoint ptr %mem97 to i64
  store i64 %ptr98, ptr %slot14, align 8
  %mem99 = alloca i8, i64 392, align 8
  %ptr100 = ptrtoint ptr %mem99 to i64
  store i64 %ptr100, ptr %slot15, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem101 = alloca i8, i64 8, align 8
  %ptr102 = ptrtoint ptr %mem101 to i64
  store i64 %ptr102, ptr %slot16, align 8
  %v103 = load i64, ptr %slot1, align 8
  %op104 = add i64 %v103, 64
  store i64 %op104, ptr %slot17, align 8
  %v105 = load i64, ptr %slot17, align 8
  %p106 = inttoptr i64 %v105 to ptr
  %ld107 = load i64, ptr %p106, align 8, !alias.scope !4, !noalias !3
  store i64 %ld107, ptr %slot18, align 8
  %stack108 = call ptr @llvm.stacksave()
  %stackaddr109 = ptrtoint ptr %stack108 to i64
  %v110 = load i64, ptr %slot18, align 8
  %cmp111 = icmp ult i64 %stackaddr109, %v110
  %cv112 = zext i1 %cmp111 to i64
  store i64 %cv112, ptr %slot19, align 8
  %v113 = load i64, ptr %slot19, align 8
  %cond114 = icmp ne i64 %v113, 0
  br i1 %cond114, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v115 = load i64, ptr %slot1, align 8
  %p116 = inttoptr i64 %v115 to ptr
  call void @myl_qbe_fail_frame(ptr %p116) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v117 = load i64, ptr %slot2, align 8
  %v118 = load i64, ptr %slot11, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot1, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %call122 = call ptr @myl_qbe_heap(ptr %p121) nomerge, !dbg !112
  %calladdr123 = ptrtoint ptr %call122 to i64
  store i64 %calladdr123, ptr %slot20, align 8
  %v124 = load i64, ptr %slot4, align 8
  %p125 = inttoptr i64 %v124 to ptr
  store i32 0, ptr %p125, align 4, !alias.scope !3, !noalias !4
  %v126 = load i64, ptr %slot5, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i32 0, ptr %p127, align 4, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot6, align 8
  %p129 = inttoptr i64 %v128 to ptr
  store i32 0, ptr %p129, align 4, !alias.scope !3, !noalias !4
  %v130 = load i64, ptr %slot7, align 8
  %p131 = inttoptr i64 %v130 to ptr
  store i32 0, ptr %p131, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v132 = load i64, ptr %slot11, align 8
  %p133 = inttoptr i64 %v132 to ptr
  %ld134 = load i64, ptr %p133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld134, ptr %slot21, align 8
  %v135 = load i64, ptr %slot21, align 8
  %v136 = load i64, ptr %slot12, align 8
  %p137 = inttoptr i64 %v136 to ptr
  store i64 %v135, ptr %p137, align 8, !alias.scope !3, !noalias !4
  %v138 = load i64, ptr %slot12, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i64, ptr %p139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot22, align 8
  %v141 = load i64, ptr %slot1, align 8
  %v142 = load i64, ptr %slot22, align 8
  %call143 = call i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64 %v141, i64 %v142) nomerge, !dbg !114
  store i64 %call143, ptr %slot23, align 8
  %v144 = load i64, ptr %slot23, align 8
  %v145 = load i64, ptr %slot12, align 8
  %p146 = inttoptr i64 %v145 to ptr
  store i64 %v144, ptr %p146, align 8, !alias.scope !3, !noalias !4
  %v147 = load i64, ptr %slot11, align 8
  %p148 = inttoptr i64 %v147 to ptr
  %ld149 = load i64, ptr %p148, align 8, !alias.scope !3, !noalias !4
  store i64 %ld149, ptr %slot24, align 8
  %v150 = load i64, ptr %slot24, align 8
  %v151 = load i64, ptr %slot12, align 8
  %p152 = inttoptr i64 %v151 to ptr
  store i64 %v150, ptr %p152, align 8, !alias.scope !3, !noalias !4
  %v153 = load i64, ptr %slot15, align 8
  store i64 %v153, ptr %slot25, align 8
  %v154 = load i64, ptr %slot25, align 8
  %p155 = inttoptr i64 %v154 to ptr
  store i32 0, ptr %p155, align 4, !alias.scope !3, !noalias !4
  %v156 = load i64, ptr %slot25, align 8
  %p157 = inttoptr i64 %v156 to ptr
  store i32 8, ptr %p157, align 4, !alias.scope !3, !noalias !4
  %v158 = load i64, ptr %slot25, align 8
  %v159 = load i64, ptr %slot13, align 8
  %p160 = inttoptr i64 %v159 to ptr
  store i64 %v158, ptr %p160, align 8, !alias.scope !3, !noalias !4
  %p161 = inttoptr i64 ptrtoint (ptr @myl_lit_1d7b28d542275a21ffb926802019519fec7fb59c7843e7a7cdd715c413b30ef4 to i64) to ptr
  %ld162 = load i64, ptr %p161, align 8, !alias.scope !4, !noalias !3
  store i64 %ld162, ptr %slot26, align 8
  %v163 = load i64, ptr %slot26, align 8
  %v164 = load i64, ptr %slot14, align 8
  %p165 = inttoptr i64 %v164 to ptr
  store i64 %v163, ptr %p165, align 8, !alias.scope !3, !noalias !4
  %v166 = load i64, ptr %slot14, align 8
  %p167 = inttoptr i64 %v166 to ptr
  %ld168 = load i64, ptr %p167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld168, ptr %slot27, align 8
  %v169 = load i64, ptr %slot27, align 8
  %v170 = load i64, ptr %slot9, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i64 %v169, ptr %p171, align 8, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot9, align 8
  store i64 %v172, ptr %slot28, align 8
  %v173 = load i64, ptr %slot10, align 8
  store i64 %v173, ptr %slot29, align 8
  %v174 = load i64, ptr %slot28, align 8
  %v175 = load i64, ptr %slot29, align 8
  %p176 = inttoptr i64 %v174 to ptr
  %p177 = inttoptr i64 %v175 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p177, ptr %p176, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v178 = load i64, ptr %slot7, align 8
  %p179 = inttoptr i64 %v178 to ptr
  store i32 2, ptr %p179, align 4, !alias.scope !3, !noalias !4
  %v180 = load i64, ptr %slot6, align 8
  %p181 = inttoptr i64 %v180 to ptr
  store i32 1, ptr %p181, align 4, !alias.scope !3, !noalias !4
  %v182 = load i64, ptr %slot8, align 8
  store i64 %v182, ptr %slot30, align 8
  %v183 = load i64, ptr %slot10, align 8
  store i64 %v183, ptr %slot31, align 8
  %v184 = load i64, ptr %slot31, align 8
  %v185 = load i64, ptr %slot30, align 8
  %p186 = inttoptr i64 %v184 to ptr
  %p187 = inttoptr i64 %v185 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p187, ptr %p186, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v188 = load i64, ptr %slot5, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i32 2, ptr %p189, align 4, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot7, align 8
  %p191 = inttoptr i64 %v190 to ptr
  %ld192 = load i32, ptr %p191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld192, ptr %slot32, align 8
  %v193 = load i32, ptr %slot32, align 8
  %v194 = load i64, ptr %slot5, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i32 %v193, ptr %p195, align 4, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot6, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i32 0, ptr %p197, align 4, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot4, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i32 1, ptr %p199, align 4, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot30, align 8
  %p201 = inttoptr i64 %v200 to ptr
  %ld202 = load i64, ptr %p201, align 8, !alias.scope !3, !noalias !4
  store i64 %ld202, ptr %slot33, align 8
  %v203 = load i64, ptr %slot33, align 8
  %v204 = load i64, ptr %slot14, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i64 %v203, ptr %p205, align 8, !alias.scope !3, !noalias !4
  %v206 = load i64, ptr %slot12, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %ld208 = load i64, ptr %p207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld208, ptr %slot34, align 8
  %v209 = load i64, ptr %slot13, align 8
  %p210 = inttoptr i64 %v209 to ptr
  %ld211 = load i64, ptr %p210, align 8, !alias.scope !3, !noalias !4
  store i64 %ld211, ptr %slot35, align 8
  %v212 = load i64, ptr %slot14, align 8
  %p213 = inttoptr i64 %v212 to ptr
  %ld214 = load i64, ptr %p213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld214, ptr %slot36, align 8
  %v215 = load i64, ptr %slot1, align 8
  %v216 = load i64, ptr %slot34, align 8
  %v217 = load i64, ptr %slot35, align 8
  %v218 = load i64, ptr %slot36, align 8
  %call219 = call i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64 %v215, i64 %v216, i64 %v217, i64 %v218) nomerge, !dbg !116
  store i64 %call219, ptr %slot37, align 8
  %v220 = load i64, ptr %slot37, align 8
  %v221 = load i64, ptr %slot12, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i64 %v220, ptr %p222, align 8, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot4, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ld225 = load i32, ptr %p224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld225, ptr %slot38, align 8
  %v226 = load i32, ptr %slot38, align 8
  %cv227 = zext i32 %v226 to i64
  %cond228 = icmp ne i64 %cv227, 0
  br i1 %cond228, label %bb_rcslotdrop53, label %bb_rcslotdone53
bb_rcslotdrop53:
  %v229 = load i64, ptr %slot4, align 8
  %p230 = inttoptr i64 %v229 to ptr
  store i32 0, ptr %p230, align 4, !alias.scope !3, !noalias !4
  %v231 = load i64, ptr %slot8, align 8
  store i64 %v231, ptr %slot39, align 8
  %v232 = load i64, ptr %slot5, align 8
  %p233 = inttoptr i64 %v232 to ptr
  %ld234 = load i32, ptr %p233, align 4, !alias.scope !3, !noalias !4
  store i32 %ld234, ptr %slot40, align 8
  %v235 = load i32, ptr %slot40, align 8
  %op236 = and i32 %v235, 28
  store i32 %op236, ptr %slot41, align 8
  %v237 = load i32, ptr %slot41, align 8
  %cv238 = zext i32 %v237 to i64
  %cond239 = icmp ne i64 %cv238, 0
  br i1 %cond239, label %bb_rcslotrole53, label %bb_rcslotowner53
bb_rcslotrole53:
  %v240 = load i64, ptr %slot20, align 8
  store i64 %v240, ptr %slot42, align 8
  %v241 = load i64, ptr %slot39, align 8
  %p242 = inttoptr i64 %v241 to ptr
  %ld243 = load i64, ptr %p242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld243, ptr %slot43, align 8
  %v244 = load i64, ptr %slot43, align 8
  %cmp245 = icmp ne i64 %v244, 0
  %cv246 = zext i1 %cmp245 to i32
  store i32 %cv246, ptr %slot44, align 8
  %v247 = load i32, ptr %slot44, align 8
  %cv248 = zext i32 %v247 to i64
  %cond249 = icmp ne i64 %cv248, 0
  br i1 %cond249, label %bb_rcgnn69, label %bb_rcgdone69
bb_rcgnn69:
  %v250 = load i64, ptr %slot43, align 8
  %op251 = sub i64 %v250, 16
  store i64 %op251, ptr %slot45, align 8
  %v252 = load i64, ptr %slot43, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %rgep254 = getelementptr i8, ptr %p253, i64 -16
  %ld255 = load i64, ptr %rgep254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld255, ptr %slot46, align 8
  %v256 = load i64, ptr %slot46, align 8
  %op257 = and i64 %v256, 4611686018427387906
  store i64 %op257, ptr %slot47, align 8
  %v258 = load i64, ptr %slot47, align 8
  %cmp259 = icmp ne i64 %v258, 0
  %cv260 = zext i1 %cmp259 to i32
  store i32 %cv260, ptr %slot48, align 8
  %v261 = load i32, ptr %slot48, align 8
  %cv262 = zext i32 %v261 to i64
  %cond263 = icmp ne i64 %cv262, 0
  br i1 %cond263, label %bb_rcgclear69, label %bb_rcgcounted69
bb_rcgcounted69:
  %v264 = load i64, ptr %slot43, align 8
  %op265 = sub i64 %v264, 24
  store i64 %op265, ptr %slot49, align 8
  %v266 = load i64, ptr %slot43, align 8
  %p267 = inttoptr i64 %v266 to ptr
  %rgep268 = getelementptr i8, ptr %p267, i64 -24
  %ld269 = load i64, ptr %rgep268, align 8, !alias.scope !9, !noalias !10
  store i64 %ld269, ptr %slot50, align 8
  %v270 = load i64, ptr %slot50, align 8
  %op271 = sub i64 %v270, 1
  store i64 %op271, ptr %slot51, align 8
  %v272 = load i64, ptr %slot51, align 8
  %cmp273 = icmp eq i64 %v272, 0
  %cv274 = zext i1 %cmp273 to i32
  store i32 %cv274, ptr %slot52, align 8
  %v275 = load i32, ptr %slot52, align 8
  %cv276 = zext i32 %v275 to i64
  %cond277 = icmp ne i64 %cv276, 0
  br i1 %cond277, label %bb_rcglast69, label %bb_rcgdec69
bb_rcglast69:
  %v278 = load i64, ptr %slot43, align 8
  %op279 = sub i64 %v278, 32
  store i64 %op279, ptr %slot53, align 8
  %v280 = load i64, ptr %slot43, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %rgep282 = getelementptr i8, ptr %p281, i64 -32
  %ld283 = load i64, ptr %rgep282, align 8, !alias.scope !9, !noalias !10
  store i64 %ld283, ptr %slot54, align 8
  %v284 = load i64, ptr %slot54, align 8
  %cmp285 = icmp ne i64 %v284, 0
  %cv286 = zext i1 %cmp285 to i32
  store i32 %cv286, ptr %slot55, align 8
  %v287 = load i32, ptr %slot55, align 8
  %cv288 = zext i32 %v287 to i64
  %cond289 = icmp ne i64 %cv288, 0
  br i1 %cond289, label %bb_rcgdec69, label %bb_rcgslow69
bb_rcgslow69:
  %v290 = load i64, ptr %slot42, align 8
  %v291 = load i64, ptr %slot39, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v290, i64 %v291) nomerge, !dbg !116
  br label %bb_rcgdone69
bb_rcgdec69:
  %v292 = load i64, ptr %slot51, align 8
  %v293 = load i64, ptr %slot43, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %rgep295 = getelementptr i8, ptr %p294, i64 -24
  store i64 %v292, ptr %rgep295, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear69
bb_rcgclear69:
  %v296 = load i64, ptr %slot39, align 8
  %p297 = inttoptr i64 %v296 to ptr
  store i64 0, ptr %p297, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone69
bb_rcgdone69:
  br label %bb_rcslotdone53
bb_rcslotowner53:
  %v298 = load i64, ptr %slot20, align 8
  store i64 %v298, ptr %slot56, align 8
  %v299 = load i64, ptr %slot39, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %ld301 = load i64, ptr %p300, align 8, !alias.scope !3, !noalias !4
  store i64 %ld301, ptr %slot57, align 8
  %v302 = load i64, ptr %slot57, align 8
  %cmp303 = icmp ne i64 %v302, 0
  %cv304 = zext i1 %cmp303 to i32
  store i32 %cv304, ptr %slot58, align 8
  %v305 = load i32, ptr %slot58, align 8
  %cv306 = zext i32 %v305 to i64
  %cond307 = icmp ne i64 %cv306, 0
  br i1 %cond307, label %bb_rcgnn84, label %bb_rcgdone84
bb_rcgnn84:
  %v308 = load i64, ptr %slot57, align 8
  %op309 = sub i64 %v308, 16
  store i64 %op309, ptr %slot59, align 8
  %v310 = load i64, ptr %slot57, align 8
  %p311 = inttoptr i64 %v310 to ptr
  %rgep312 = getelementptr i8, ptr %p311, i64 -16
  %ld313 = load i64, ptr %rgep312, align 8, !alias.scope !9, !noalias !10
  store i64 %ld313, ptr %slot60, align 8
  %v314 = load i64, ptr %slot60, align 8
  %op315 = and i64 %v314, 4611686018427387906
  store i64 %op315, ptr %slot61, align 8
  %v316 = load i64, ptr %slot61, align 8
  %cmp317 = icmp ne i64 %v316, 0
  %cv318 = zext i1 %cmp317 to i32
  store i32 %cv318, ptr %slot62, align 8
  %v319 = load i32, ptr %slot62, align 8
  %cv320 = zext i32 %v319 to i64
  %cond321 = icmp ne i64 %cv320, 0
  br i1 %cond321, label %bb_rcgclear84, label %bb_rcgcounted84
bb_rcgcounted84:
  %v322 = load i64, ptr %slot57, align 8
  %op323 = sub i64 %v322, 32
  store i64 %op323, ptr %slot63, align 8
  %v324 = load i64, ptr %slot57, align 8
  %p325 = inttoptr i64 %v324 to ptr
  %rgep326 = getelementptr i8, ptr %p325, i64 -32
  %ld327 = load i64, ptr %rgep326, align 8, !alias.scope !9, !noalias !10
  store i64 %ld327, ptr %slot64, align 8
  %v328 = load i64, ptr %slot64, align 8
  %op329 = sub i64 %v328, 1
  store i64 %op329, ptr %slot65, align 8
  %v330 = load i64, ptr %slot65, align 8
  %cmp331 = icmp eq i64 %v330, 0
  %cv332 = zext i1 %cmp331 to i32
  store i32 %cv332, ptr %slot66, align 8
  %v333 = load i32, ptr %slot66, align 8
  %cv334 = zext i32 %v333 to i64
  %cond335 = icmp ne i64 %cv334, 0
  br i1 %cond335, label %bb_rcglast84, label %bb_rcgdec84
bb_rcglast84:
  %v336 = load i64, ptr %slot57, align 8
  %op337 = sub i64 %v336, 24
  store i64 %op337, ptr %slot67, align 8
  %v338 = load i64, ptr %slot57, align 8
  %p339 = inttoptr i64 %v338 to ptr
  %rgep340 = getelementptr i8, ptr %p339, i64 -24
  %ld341 = load i64, ptr %rgep340, align 8, !alias.scope !9, !noalias !10
  store i64 %ld341, ptr %slot68, align 8
  %v342 = load i64, ptr %slot68, align 8
  %cmp343 = icmp ne i64 %v342, 0
  %cv344 = zext i1 %cmp343 to i32
  store i32 %cv344, ptr %slot69, align 8
  %v345 = load i32, ptr %slot69, align 8
  %cv346 = zext i32 %v345 to i64
  %cond347 = icmp ne i64 %cv346, 0
  br i1 %cond347, label %bb_rcgdec84, label %bb_rcgslow84
bb_rcgslow84:
  %v348 = load i64, ptr %slot56, align 8
  %v349 = load i64, ptr %slot39, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v348, i64 %v349) nomerge, !dbg !116
  br label %bb_rcgdone84
bb_rcgdec84:
  %v350 = load i64, ptr %slot65, align 8
  %v351 = load i64, ptr %slot57, align 8
  %p352 = inttoptr i64 %v351 to ptr
  %rgep353 = getelementptr i8, ptr %p352, i64 -32
  store i64 %v350, ptr %rgep353, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear84
bb_rcgclear84:
  %v354 = load i64, ptr %slot39, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i64 0, ptr %p355, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone84
bb_rcgdone84:
  br label %bb_rcslotdone53
bb_rcslotdone53:
  %v356 = load i64, ptr %slot11, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i64, ptr %p357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld358, ptr %slot70, align 8
  %v359 = load i64, ptr %slot70, align 8
  %v360 = load i64, ptr %slot12, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i64 %v359, ptr %p361, align 8, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot13, align 8
  %p363 = inttoptr i64 %v362 to ptr
  store i64 4, ptr %p363, align 8, !alias.scope !3, !noalias !4
  %v364 = load i64, ptr %slot12, align 8
  %p365 = inttoptr i64 %v364 to ptr
  %ld366 = load i64, ptr %p365, align 8, !alias.scope !3, !noalias !4
  store i64 %ld366, ptr %slot71, align 8
  %v367 = load i64, ptr %slot13, align 8
  %p368 = inttoptr i64 %v367 to ptr
  %ld369 = load i64, ptr %p368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld369, ptr %slot72, align 8
  %v370 = load i64, ptr %slot1, align 8
  %v371 = load i64, ptr %slot71, align 8
  %v372 = load i64, ptr %slot72, align 8
  %call373 = call i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64 %v370, i64 %v371, i64 %v372) nomerge, !dbg !118
  store i64 %call373, ptr %slot73, align 8
  %v374 = load i64, ptr %slot73, align 8
  %v375 = load i64, ptr %slot12, align 8
  %p376 = inttoptr i64 %v375 to ptr
  store i64 %v374, ptr %p376, align 8, !alias.scope !3, !noalias !4
  %v377 = load i64, ptr %slot12, align 8
  %p378 = inttoptr i64 %v377 to ptr
  store i64 0, ptr %p378, align 8, !alias.scope !3, !noalias !4
  %v379 = load i64, ptr %slot12, align 8
  %p380 = inttoptr i64 %v379 to ptr
  %ld381 = load i64, ptr %p380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld381, ptr %slot74, align 8
  %v382 = load i64, ptr %slot74, align 8
  ret i64 %v382
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_1d7b28d542275a21ffb926802019519fec7fb59c7843e7a7cdd715c413b30ef4 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_071e3970666c5aaa2a9990ecd707a0eb6965ebbf98d954de0bd11cbb3f8fad61(i64, i64, i64, i64)
declare i64 @myl_f_54abe9aa6a7187afc14a47955508430e71c2919d7ba36a98c73994e172057f65(i64, i64)
declare i64 @myl_f_a32f7514f82f02a38a26c31ef30886fb7eb9200c6a749b4c3dcccb91dc9d03d1(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_36043223de5debd79a6d2fd7d6c9a2c48b5b01436f2851ab8366cedf066ab5d6", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_36043223de5debd79a6d2fd7d6c9a2c48b5b01436f2851ab8366cedf066ab5d6", linkageName: "myl_f_36043223de5debd79a6d2fd7d6c9a2c48b5b01436f2851ab8366cedf066ab5d6", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 5302272249899847596, i64 0, !"myl_f_36043223de5debd79a6d2fd7d6c9a2c48b5b01436f2851ab8366cedf066ab5d6"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!116 = !DILocation(line: 7, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!118 = !DILocation(line: 11, column: 0, scope: !119)
