target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i32, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i32, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i32, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i32, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i32, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i32, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i32, align 8
  %slot193 = alloca i32, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i32, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i64, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i32, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i32, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i32, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i32, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i64, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i32, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %callresult330 = alloca [16 x i8], align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i32, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i32, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i32, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i32, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i32, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i32, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %callresult484 = alloca [40 x i8], align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i32, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i32, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %callresult511 = alloca [1 x i8], align 1
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i32, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i32, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i32, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i32, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i32, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i32, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i64, align 8
  %callresult559 = alloca [16 x i8], align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i64, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i32, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i64, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i32, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i32, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i32, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %callresult700 = alloca [48 x i8], align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i32, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i32, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i32, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i32, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i32, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i32, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i32, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i32, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i32, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i32, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i32, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i32, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i32, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i32, align 8
  %slot855 = alloca i32, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i32, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i32, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i32, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i32, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i32, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i32, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i32, align 8
  %slot962 = alloca i32, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i32, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i32, align 8
  %slot985 = alloca i32, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i32, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i32, align 8
  %slot1043 = alloca i32, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i32, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v1072 = load i64, ptr %slot1, align 8
  %op1073 = add i64 %v1072, 32
  store i64 %op1073, ptr %slot4, align 8
  %mem1074 = alloca i8, i64 16, align 8
  %ptr1075 = ptrtoint ptr %mem1074 to i64
  store i64 %ptr1075, ptr %slot5, align 8
  %mem1076 = alloca i8, i64 8, align 8
  %ptr1077 = ptrtoint ptr %mem1076 to i64
  store i64 %ptr1077, ptr %slot6, align 8
  %mem1078 = alloca i8, i64 8, align 8
  %ptr1079 = ptrtoint ptr %mem1078 to i64
  store i64 %ptr1079, ptr %slot7, align 8
  %mem1080 = alloca i8, i64 8, align 8
  %ptr1081 = ptrtoint ptr %mem1080 to i64
  store i64 %ptr1081, ptr %slot8, align 8
  %mem1082 = alloca i8, i64 8, align 8
  %ptr1083 = ptrtoint ptr %mem1082 to i64
  store i64 %ptr1083, ptr %slot9, align 8
  %mem1084 = alloca i8, i64 8, align 8
  %ptr1085 = ptrtoint ptr %mem1084 to i64
  store i64 %ptr1085, ptr %slot10, align 8
  %mem1086 = alloca i8, i64 8, align 8
  %ptr1087 = ptrtoint ptr %mem1086 to i64
  store i64 %ptr1087, ptr %slot11, align 8
  %mem1088 = alloca i8, i64 8, align 8
  %ptr1089 = ptrtoint ptr %mem1088 to i64
  store i64 %ptr1089, ptr %slot12, align 8
  %mem1090 = alloca i8, i64 8, align 8
  %ptr1091 = ptrtoint ptr %mem1090 to i64
  store i64 %ptr1091, ptr %slot13, align 8
  %mem1092 = alloca i8, i64 8, align 8
  %ptr1093 = ptrtoint ptr %mem1092 to i64
  store i64 %ptr1093, ptr %slot14, align 8
  %mem1094 = alloca i8, i64 8, align 8
  %ptr1095 = ptrtoint ptr %mem1094 to i64
  store i64 %ptr1095, ptr %slot15, align 8
  %mem1096 = alloca i8, i64 8, align 8
  %ptr1097 = ptrtoint ptr %mem1096 to i64
  store i64 %ptr1097, ptr %slot16, align 8
  %mem1098 = alloca i8, i64 8, align 8
  %ptr1099 = ptrtoint ptr %mem1098 to i64
  store i64 %ptr1099, ptr %slot17, align 8
  %mem1100 = alloca i8, i64 8, align 8
  %ptr1101 = ptrtoint ptr %mem1100 to i64
  store i64 %ptr1101, ptr %slot18, align 8
  %mem1102 = alloca i8, i64 8, align 8
  %ptr1103 = ptrtoint ptr %mem1102 to i64
  store i64 %ptr1103, ptr %slot19, align 8
  %mem1104 = alloca i8, i64 8, align 8
  %ptr1105 = ptrtoint ptr %mem1104 to i64
  store i64 %ptr1105, ptr %slot20, align 8
  %mem1106 = alloca i8, i64 8, align 8
  %ptr1107 = ptrtoint ptr %mem1106 to i64
  store i64 %ptr1107, ptr %slot21, align 8
  %mem1108 = alloca i8, i64 312, align 8
  %ptr1109 = ptrtoint ptr %mem1108 to i64
  store i64 %ptr1109, ptr %slot22, align 8
  %mem1110 = alloca i8, i64 312, align 8
  %ptr1111 = ptrtoint ptr %mem1110 to i64
  store i64 %ptr1111, ptr %slot23, align 8
  %mem1112 = alloca i8, i64 40, align 8
  %ptr1113 = ptrtoint ptr %mem1112 to i64
  store i64 %ptr1113, ptr %slot24, align 8
  %mem1114 = alloca i8, i64 8, align 8
  %ptr1115 = ptrtoint ptr %mem1114 to i64
  store i64 %ptr1115, ptr %slot25, align 8
  %mem1116 = alloca i8, i64 8, align 8
  %ptr1117 = ptrtoint ptr %mem1116 to i64
  store i64 %ptr1117, ptr %slot26, align 8
  %mem1118 = alloca i8, i64 8, align 8
  %ptr1119 = ptrtoint ptr %mem1118 to i64
  store i64 %ptr1119, ptr %slot27, align 8
  %mem1120 = alloca i8, i64 312, align 8
  %ptr1121 = ptrtoint ptr %mem1120 to i64
  store i64 %ptr1121, ptr %slot28, align 8
  %mem1122 = alloca i8, i64 8, align 8
  %ptr1123 = ptrtoint ptr %mem1122 to i64
  store i64 %ptr1123, ptr %slot29, align 8
  %mem1124 = alloca i8, i64 8, align 8
  %ptr1125 = ptrtoint ptr %mem1124 to i64
  store i64 %ptr1125, ptr %slot30, align 8
  %mem1126 = alloca i8, i64 8, align 8
  %ptr1127 = ptrtoint ptr %mem1126 to i64
  store i64 %ptr1127, ptr %slot31, align 8
  %mem1128 = alloca i8, i64 8, align 8
  %ptr1129 = ptrtoint ptr %mem1128 to i64
  store i64 %ptr1129, ptr %slot32, align 8
  %mem1130 = alloca i8, i64 8, align 8
  %ptr1131 = ptrtoint ptr %mem1130 to i64
  store i64 %ptr1131, ptr %slot33, align 8
  %mem1132 = alloca i8, i64 8, align 8
  %ptr1133 = ptrtoint ptr %mem1132 to i64
  store i64 %ptr1133, ptr %slot34, align 8
  %mem1134 = alloca i8, i64 40, align 8
  %ptr1135 = ptrtoint ptr %mem1134 to i64
  store i64 %ptr1135, ptr %slot35, align 8
  %mem1136 = alloca i8, i64 8, align 8
  %ptr1137 = ptrtoint ptr %mem1136 to i64
  store i64 %ptr1137, ptr %slot36, align 8
  %mem1138 = alloca i8, i64 8, align 8
  %ptr1139 = ptrtoint ptr %mem1138 to i64
  store i64 %ptr1139, ptr %slot37, align 8
  %mem1140 = alloca i8, i64 8, align 8
  %ptr1141 = ptrtoint ptr %mem1140 to i64
  store i64 %ptr1141, ptr %slot38, align 8
  %mem1142 = alloca i8, i64 8, align 8
  %ptr1143 = ptrtoint ptr %mem1142 to i64
  store i64 %ptr1143, ptr %slot39, align 8
  %mem1144 = alloca i8, i64 312, align 8
  %ptr1145 = ptrtoint ptr %mem1144 to i64
  store i64 %ptr1145, ptr %slot40, align 8
  %mem1146 = alloca i8, i64 16, align 8
  %ptr1147 = ptrtoint ptr %mem1146 to i64
  store i64 %ptr1147, ptr %slot41, align 8
  %mem1148 = alloca i8, i64 312, align 8
  %ptr1149 = ptrtoint ptr %mem1148 to i64
  store i64 %ptr1149, ptr %slot42, align 8
  %mem1150 = alloca i8, i64 312, align 8
  %ptr1151 = ptrtoint ptr %mem1150 to i64
  store i64 %ptr1151, ptr %slot43, align 8
  %mem1152 = alloca i8, i64 16, align 8
  %ptr1153 = ptrtoint ptr %mem1152 to i64
  store i64 %ptr1153, ptr %slot44, align 8
  %mem1154 = alloca i8, i64 312, align 8
  %ptr1155 = ptrtoint ptr %mem1154 to i64
  store i64 %ptr1155, ptr %slot45, align 8
  %mem1156 = alloca i8, i64 48, align 8
  %ptr1157 = ptrtoint ptr %mem1156 to i64
  store i64 %ptr1157, ptr %slot46, align 8
  %mem1158 = alloca i8, i64 312, align 8
  %ptr1159 = ptrtoint ptr %mem1158 to i64
  store i64 %ptr1159, ptr %slot47, align 8
  %mem1160 = alloca i8, i64 312, align 8
  %ptr1161 = ptrtoint ptr %mem1160 to i64
  store i64 %ptr1161, ptr %slot48, align 8
  %mem1162 = alloca i8, i64 16, align 8
  %ptr1163 = ptrtoint ptr %mem1162 to i64
  store i64 %ptr1163, ptr %slot49, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1164 = alloca i8, i64 8, align 8
  %ptr1165 = ptrtoint ptr %mem1164 to i64
  store i64 %ptr1165, ptr %slot50, align 8
  %v1166 = load i64, ptr %slot1, align 8
  %op1167 = add i64 %v1166, 64
  store i64 %op1167, ptr %slot51, align 8
  %v1168 = load i64, ptr %slot51, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %ld1170 = load i64, ptr %p1169, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1170, ptr %slot52, align 8
  %stack1171 = call ptr @llvm.stacksave()
  %stackaddr1172 = ptrtoint ptr %stack1171 to i64
  %v1173 = load i64, ptr %slot52, align 8
  %cmp1174 = icmp ult i64 %stackaddr1172, %v1173
  %cv1175 = zext i1 %cmp1174 to i64
  store i64 %cv1175, ptr %slot53, align 8
  %v1176 = load i64, ptr %slot53, align 8
  %cond1177 = icmp ne i64 %v1176, 0
  br i1 %cond1177, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1178 = load i64, ptr %slot1, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  call void @myl_qbe_fail_frame(ptr %p1179) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1180 = load i64, ptr %slot32, align 8
  %p1181 = inttoptr i64 %v1180 to ptr
  store i64 0, ptr %p1181, align 8, !alias.scope !3, !noalias !4
  %v1182 = load i64, ptr %slot33, align 8
  %p1183 = inttoptr i64 %v1182 to ptr
  store i64 0, ptr %p1183, align 8, !alias.scope !3, !noalias !4
  %v1184 = load i64, ptr %slot34, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  store i64 0, ptr %p1185, align 8, !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot2, align 8
  %v1187 = load i64, ptr %slot30, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  store i64 %v1186, ptr %p1188, align 8, !alias.scope !3, !noalias !4
  %v1189 = load i64, ptr %slot3, align 8
  %v1190 = load i64, ptr %slot31, align 8
  %p1191 = inttoptr i64 %v1190 to ptr
  store i64 %v1189, ptr %p1191, align 8, !alias.scope !3, !noalias !4
  %v1192 = load i64, ptr %slot1, align 8
  %p1193 = inttoptr i64 %v1192 to ptr
  %call1194 = call ptr @myl_qbe_heap(ptr %p1193) nomerge, !dbg !112
  %calladdr1195 = ptrtoint ptr %call1194 to i64
  store i64 %calladdr1195, ptr %slot54, align 8
  %v1196 = load i64, ptr %slot1, align 8
  %p1197 = inttoptr i64 %v1196 to ptr
  %call1198 = call i64 @myl_qbe_region_mark(ptr %p1197) nomerge, !dbg !112
  store i64 %call1198, ptr %slot55, align 8
  %v1199 = load i64, ptr %slot6, align 8
  %p1200 = inttoptr i64 %v1199 to ptr
  store i32 0, ptr %p1200, align 4, !alias.scope !3, !noalias !4
  %v1201 = load i64, ptr %slot7, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  store i32 0, ptr %p1202, align 4, !alias.scope !3, !noalias !4
  %v1203 = load i64, ptr %slot8, align 8
  %p1204 = inttoptr i64 %v1203 to ptr
  store i32 0, ptr %p1204, align 4, !alias.scope !3, !noalias !4
  %v1205 = load i64, ptr %slot9, align 8
  %p1206 = inttoptr i64 %v1205 to ptr
  store i32 0, ptr %p1206, align 4, !alias.scope !3, !noalias !4
  %v1207 = load i64, ptr %slot10, align 8
  %p1208 = inttoptr i64 %v1207 to ptr
  store i32 0, ptr %p1208, align 4, !alias.scope !3, !noalias !4
  %v1209 = load i64, ptr %slot11, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i32 0, ptr %p1210, align 4, !alias.scope !3, !noalias !4
  %v1211 = load i64, ptr %slot12, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i32 0, ptr %p1212, align 4, !alias.scope !3, !noalias !4
  %v1213 = load i64, ptr %slot13, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  store i32 0, ptr %p1214, align 4, !alias.scope !3, !noalias !4
  %v1215 = load i64, ptr %slot14, align 8
  %p1216 = inttoptr i64 %v1215 to ptr
  store i32 0, ptr %p1216, align 4, !alias.scope !3, !noalias !4
  %v1217 = load i64, ptr %slot15, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  store i32 0, ptr %p1218, align 4, !alias.scope !3, !noalias !4
  %v1219 = load i64, ptr %slot16, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  store i32 0, ptr %p1220, align 4, !alias.scope !3, !noalias !4
  %v1221 = load i64, ptr %slot17, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  store i32 0, ptr %p1222, align 4, !alias.scope !3, !noalias !4
  %v1223 = load i64, ptr %slot18, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  store i32 0, ptr %p1224, align 4, !alias.scope !3, !noalias !4
  %v1225 = load i64, ptr %slot19, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  store i32 0, ptr %p1226, align 4, !alias.scope !3, !noalias !4
  %v1227 = load i64, ptr %slot20, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  store i32 0, ptr %p1228, align 4, !alias.scope !3, !noalias !4
  %v1229 = load i64, ptr %slot21, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  store i32 0, ptr %p1230, align 4, !alias.scope !3, !noalias !4
  %v1231 = load i64, ptr %slot7, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  store i32 2, ptr %p1232, align 4, !alias.scope !3, !noalias !4
  %v1233 = load i64, ptr %slot9, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  store i32 2, ptr %p1234, align 4, !alias.scope !3, !noalias !4
  %v1235 = load i64, ptr %slot11, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  store i32 2, ptr %p1236, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1237 = load i64, ptr %slot36, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  store i64 0, ptr %p1238, align 8, !alias.scope !3, !noalias !4
  %v1239 = load i64, ptr %slot36, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  %ld1241 = load i64, ptr %p1240, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1241, ptr %slot56, align 8
  %v1242 = load i64, ptr %slot56, align 8
  %cmp1243 = icmp sge i64 %v1242, 0
  %cv1244 = zext i1 %cmp1243 to i64
  store i64 %cv1244, ptr %slot57, align 8
  %v1245 = load i64, ptr %slot57, align 8
  %cond1246 = icmp ne i64 %v1245, 0
  br i1 %cond1246, label %bb_success13, label %bb_failed13
bb_failed13:
  %v1247 = load i64, ptr %slot1, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1248) nomerge, !dbg !114
  unreachable
bb_success13:
  %v1249 = load i64, ptr %slot54, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  %p1251 = inttoptr i64 ptrtoint (ptr @myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda to i64) to ptr
  %v1252 = load i64, ptr %slot56, align 8
  %call1253 = call ptr @myl_native_list_new(ptr %p1250, ptr %p1251, i64 %v1252) nomerge, !dbg !114
  %calladdr1254 = ptrtoint ptr %call1253 to i64
  store i64 %calladdr1254, ptr %slot58, align 8
  %v1255 = load i64, ptr %slot58, align 8
  %cond1256 = icmp ne i64 %v1255, 0
  br i1 %cond1256, label %bb_success15, label %bb_failed15
bb_failed15:
  %v1257 = load i64, ptr %slot1, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1258) nomerge, !dbg !114
  unreachable
bb_success15:
  %v1259 = load i64, ptr %slot58, align 8
  %v1260 = load i64, ptr %slot36, align 8
  %p1261 = inttoptr i64 %v1260 to ptr
  store i64 %v1259, ptr %p1261, align 8, !alias.scope !3, !noalias !4
  %v1262 = load i64, ptr %slot36, align 8
  %p1263 = inttoptr i64 %v1262 to ptr
  %ld1264 = load i64, ptr %p1263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1264, ptr %slot59, align 8
  %v1265 = load i64, ptr %slot59, align 8
  %v1266 = load i64, ptr %slot25, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  store i64 %v1265, ptr %p1267, align 8, !alias.scope !3, !noalias !4
  %v1268 = load i64, ptr %slot25, align 8
  store i64 %v1268, ptr %slot60, align 8
  %v1269 = load i64, ptr %slot28, align 8
  store i64 %v1269, ptr %slot61, align 8
  %v1270 = load i64, ptr %slot60, align 8
  %v1271 = load i64, ptr %slot61, align 8
  %p1272 = inttoptr i64 %v1270 to ptr
  %p1273 = inttoptr i64 %v1271 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1273, ptr %p1272, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1274 = load i64, ptr %slot20, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i32 2, ptr %p1275, align 4, !alias.scope !3, !noalias !4
  %v1276 = load i64, ptr %slot19, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  store i32 1, ptr %p1277, align 4, !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot22, align 8
  store i64 %v1278, ptr %slot62, align 8
  %v1279 = load i64, ptr %slot28, align 8
  store i64 %v1279, ptr %slot63, align 8
  %v1280 = load i64, ptr %slot63, align 8
  %v1281 = load i64, ptr %slot62, align 8
  %p1282 = inttoptr i64 %v1280 to ptr
  %p1283 = inttoptr i64 %v1281 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1283, ptr %p1282, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1284 = load i64, ptr %slot13, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  store i32 2, ptr %p1285, align 4, !alias.scope !3, !noalias !4
  %v1286 = load i64, ptr %slot20, align 8
  %p1287 = inttoptr i64 %v1286 to ptr
  %ld1288 = load i32, ptr %p1287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1288, ptr %slot64, align 8
  %v1289 = load i32, ptr %slot64, align 8
  %v1290 = load i64, ptr %slot13, align 8
  %p1291 = inttoptr i64 %v1290 to ptr
  store i32 %v1289, ptr %p1291, align 4, !alias.scope !3, !noalias !4
  %v1292 = load i64, ptr %slot19, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  store i32 0, ptr %p1293, align 4, !alias.scope !3, !noalias !4
  %v1294 = load i64, ptr %slot12, align 8
  %p1295 = inttoptr i64 %v1294 to ptr
  store i32 1, ptr %p1295, align 4, !alias.scope !3, !noalias !4
  %v1296 = load i64, ptr %slot62, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  %ld1298 = load i64, ptr %p1297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1298, ptr %slot65, align 8
  %v1299 = load i64, ptr %slot65, align 8
  %v1300 = load i64, ptr %slot36, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i64 %v1299, ptr %p1301, align 8, !alias.scope !3, !noalias !4
  %v1302 = load i64, ptr %slot36, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  %ld1304 = load i64, ptr %p1303, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1304, ptr %slot66, align 8
  %v1305 = load i64, ptr %slot66, align 8
  %v1306 = load i64, ptr %slot25, align 8
  %p1307 = inttoptr i64 %v1306 to ptr
  store i64 %v1305, ptr %p1307, align 8, !alias.scope !3, !noalias !4
  %v1308 = load i64, ptr %slot25, align 8
  store i64 %v1308, ptr %slot67, align 8
  %v1309 = load i64, ptr %slot12, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  %ld1311 = load i32, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1311, ptr %slot68, align 8
  %v1312 = load i64, ptr %slot13, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  %ld1314 = load i32, ptr %p1313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1314, ptr %slot69, align 8
  %v1315 = load i32, ptr %slot69, align 8
  %op1316 = and i32 %v1315, 24
  store i32 %op1316, ptr %slot69, align 8
  %v1317 = load i32, ptr %slot69, align 8
  %cmp1318 = icmp eq i32 %v1317, 0
  %cv1319 = zext i1 %cmp1318 to i32
  store i32 %cv1319, ptr %slot70, align 8
  %v1320 = load i32, ptr %slot68, align 8
  %v1321 = load i32, ptr %slot70, align 8
  %op1322 = and i32 %v1320, %v1321
  store i32 %op1322, ptr %slot71, align 8
  %v1323 = load i32, ptr %slot71, align 8
  %cv1324 = zext i32 %v1323 to i64
  %cond1325 = icmp ne i64 %cv1324, 0
  br i1 %cond1325, label %bb_rcprivateown38, label %bb_rcprivateloan38
bb_rcprivateown38:
  %v1326 = load i64, ptr %slot28, align 8
  store i64 %v1326, ptr %slot72, align 8
  %v1327 = load i64, ptr %slot55, align 8
  store i64 %v1327, ptr %slot73, align 8
  %v1328 = load i64, ptr %slot67, align 8
  %v1329 = load i64, ptr %slot72, align 8
  %op1330 = sub i64 %v1328, %v1329
  store i64 %op1330, ptr %slot74, align 8
  %v1331 = load i64, ptr %slot72, align 8
  %v1332 = load i64, ptr %slot67, align 8
  %op1333 = sub i64 %v1331, %v1332
  store i64 %op1333, ptr %slot75, align 8
  %v1334 = load i64, ptr %slot74, align 8
  %cmp1335 = icmp ult i64 %v1334, 8
  %cv1336 = zext i1 %cmp1335 to i32
  store i32 %cv1336, ptr %slot76, align 8
  %v1337 = load i64, ptr %slot75, align 8
  %cmp1338 = icmp ult i64 %v1337, 8
  %cv1339 = zext i1 %cmp1338 to i32
  store i32 %cv1339, ptr %slot77, align 8
  %v1340 = load i32, ptr %slot76, align 8
  %v1341 = load i32, ptr %slot77, align 8
  %op1342 = or i32 %v1340, %v1341
  store i32 %op1342, ptr %slot78, align 8
  %v1343 = load i32, ptr %slot78, align 8
  %cv1344 = zext i32 %v1343 to i64
  %cond1345 = icmp ne i64 %cv1344, 0
  br i1 %cond1345, label %bb_rcmoveslow41, label %bb_rcmovecheck41
bb_rcmovecheck41:
  %v1346 = load i64, ptr %slot67, align 8
  %p1348 = inttoptr i64 %v1346 to ptr
  %gep1349 = getelementptr i8, ptr %p1348, i64 0
  %op1347 = ptrtoint ptr %gep1349 to i64
  store i64 %op1347, ptr %slot79, align 8
  %v1350 = load i64, ptr %slot79, align 8
  %p1351 = inttoptr i64 %v1350 to ptr
  %ld1352 = load i64, ptr %p1351, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1352, ptr %slot80, align 8
  %v1353 = load i64, ptr %slot80, align 8
  %cmp1354 = icmp ne i64 %v1353, 0
  %cv1355 = zext i1 %cmp1354 to i32
  store i32 %cv1355, ptr %slot81, align 8
  %v1356 = load i32, ptr %slot81, align 8
  %cv1357 = zext i32 %v1356 to i64
  %cond1358 = icmp ne i64 %cv1357, 0
  br i1 %cond1358, label %bb_rcmoveheader49, label %bb_rcmovenext49
bb_rcmoveheader49:
  %v1359 = load i64, ptr %slot80, align 8
  %op1360 = sub i64 %v1359, 16
  store i64 %op1360, ptr %slot82, align 8
  %v1361 = load i64, ptr %slot80, align 8
  %p1362 = inttoptr i64 %v1361 to ptr
  %rgep1363 = getelementptr i8, ptr %p1362, i64 -16
  %ld1364 = load i64, ptr %rgep1363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1364, ptr %slot83, align 8
  %v1365 = load i64, ptr %slot83, align 8
  %op1366 = and i64 %v1365, 5764607523034234881
  store i64 %op1366, ptr %slot84, align 8
  %v1367 = load i64, ptr %slot84, align 8
  %cmp1368 = icmp ne i64 %v1367, 0
  %cv1369 = zext i1 %cmp1368 to i32
  store i32 %cv1369, ptr %slot85, align 8
  %v1370 = load i32, ptr %slot85, align 8
  %cv1371 = zext i32 %v1370 to i64
  %cond1372 = icmp ne i64 %cv1371, 0
  br i1 %cond1372, label %bb_rcmoveslow41, label %bb_rcmovenext49
bb_rcmovenext49:
  %v1373 = load i64, ptr %slot67, align 8
  %v1374 = load i64, ptr %slot72, align 8
  %p1375 = inttoptr i64 %v1373 to ptr
  %p1376 = inttoptr i64 %v1374 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1376, ptr %p1375, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1377 = load i64, ptr %slot67, align 8
  %p1378 = inttoptr i64 %v1377 to ptr
  store i64 0, ptr %p1378, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved41
bb_rcmoveslow41:
  %v1379 = load i64, ptr %slot54, align 8
  %v1380 = load i64, ptr %slot72, align 8
  %v1381 = load i64, ptr %slot67, align 8
  %v1382 = load i64, ptr %slot73, align 8
  %cv1383 = trunc i64 %v1382 to i32
  %call1384 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1379, i64 %v1380, i64 %v1381, i32 %cv1383) nomerge, !dbg !116
  store i32 %call1384, ptr %slot86, align 8
  %v1385 = load i32, ptr %slot86, align 8
  %cv1386 = zext i32 %v1385 to i64
  %cond1387 = icmp ne i64 %cv1386, 0
  br i1 %cond1387, label %bb_rcsuccess56, label %bb_rcfailure56
bb_rcfailure56:
  %v1388 = load i64, ptr %slot54, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %call1390 = call i32 @myl_rc_take_failure(ptr %p1389) nomerge, !dbg !116
  store i32 %call1390, ptr %slot87, align 8
  %v1391 = load i64, ptr %slot1, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  %v1393 = load i32, ptr %slot87, align 8
  %call1394 = call i32 @myl_qbe_rc_status(ptr %p1392, i32 %v1393) nomerge, !dbg !116
  store i32 %call1394, ptr %slot88, align 8
  br label %bb_failure
bb_rcsuccess56:
  br label %bb_rcmoved41
bb_rcmoved41:
  %v1395 = load i64, ptr %slot12, align 8
  %p1396 = inttoptr i64 %v1395 to ptr
  store i32 0, ptr %p1396, align 4, !alias.scope !3, !noalias !4
  %v1397 = load i64, ptr %slot20, align 8
  %p1398 = inttoptr i64 %v1397 to ptr
  store i32 2, ptr %p1398, align 4, !alias.scope !3, !noalias !4
  %v1399 = load i64, ptr %slot19, align 8
  %p1400 = inttoptr i64 %v1399 to ptr
  store i32 1, ptr %p1400, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared38
bb_rcprivateloan38:
  %v1401 = load i64, ptr %slot12, align 8
  %p1402 = inttoptr i64 %v1401 to ptr
  %ld1403 = load i32, ptr %p1402, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1403, ptr %slot89, align 8
  %v1404 = load i64, ptr %slot13, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  %ld1406 = load i32, ptr %p1405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1406, ptr %slot90, align 8
  %v1407 = load i32, ptr %slot90, align 8
  %cmp1408 = icmp eq i32 %v1407, 16
  %cv1409 = zext i1 %cmp1408 to i32
  store i32 %cv1409, ptr %slot91, align 8
  %v1410 = load i32, ptr %slot91, align 8
  %v1411 = load i32, ptr %slot89, align 8
  %op1412 = and i32 %v1410, %v1411
  store i32 %op1412, ptr %slot91, align 8
  %v1413 = load i32, ptr %slot91, align 8
  %cv1414 = zext i32 %v1413 to i64
  %cond1415 = icmp ne i64 %cv1414, 0
  br i1 %cond1415, label %bb_rcprivatemove38, label %bb_rcprivatenew38
bb_rcprivatemove38:
  %v1416 = load i64, ptr %slot28, align 8
  store i64 %v1416, ptr %slot92, align 8
  %v1417 = load i64, ptr %slot67, align 8
  %v1418 = load i64, ptr %slot92, align 8
  %p1419 = inttoptr i64 %v1417 to ptr
  %p1420 = inttoptr i64 %v1418 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1420, ptr %p1419, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1421 = load i64, ptr %slot67, align 8
  %p1422 = inttoptr i64 %v1421 to ptr
  store i64 0, ptr %p1422, align 8, !alias.scope !3, !noalias !4
  %v1423 = load i64, ptr %slot20, align 8
  %p1424 = inttoptr i64 %v1423 to ptr
  store i32 2, ptr %p1424, align 4, !alias.scope !3, !noalias !4
  %v1425 = load i64, ptr %slot20, align 8
  %p1426 = inttoptr i64 %v1425 to ptr
  store i32 16, ptr %p1426, align 4, !alias.scope !3, !noalias !4
  %v1427 = load i64, ptr %slot19, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i32 1, ptr %p1428, align 4, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot12, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  store i32 0, ptr %p1430, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared38
bb_rcprivatenew38:
  %v1431 = load i64, ptr %slot28, align 8
  store i64 %v1431, ptr %slot93, align 8
  %v1432 = load i64, ptr %slot67, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  %ld1434 = load i64, ptr %p1433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1434, ptr %slot94, align 8
  %v1435 = load i64, ptr %slot94, align 8
  %cmp1436 = icmp ne i64 %v1435, 0
  %cv1437 = zext i1 %cmp1436 to i32
  store i32 %cv1437, ptr %slot95, align 8
  %v1438 = load i32, ptr %slot95, align 8
  %cv1439 = zext i32 %v1438 to i64
  %cond1440 = icmp ne i64 %cv1439, 0
  br i1 %cond1440, label %bb_rcgnn74, label %bb_rcgstore74
bb_rcgnn74:
  %v1441 = load i64, ptr %slot94, align 8
  %op1442 = sub i64 %v1441, 16
  store i64 %op1442, ptr %slot96, align 8
  %v1443 = load i64, ptr %slot94, align 8
  %p1444 = inttoptr i64 %v1443 to ptr
  %rgep1445 = getelementptr i8, ptr %p1444, i64 -16
  %ld1446 = load i64, ptr %rgep1445, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1446, ptr %slot97, align 8
  %v1447 = load i64, ptr %slot97, align 8
  %op1448 = and i64 %v1447, 4611686018427387906
  store i64 %op1448, ptr %slot98, align 8
  %v1449 = load i64, ptr %slot98, align 8
  %cmp1450 = icmp ne i64 %v1449, 0
  %cv1451 = zext i1 %cmp1450 to i32
  store i32 %cv1451, ptr %slot99, align 8
  %v1452 = load i32, ptr %slot99, align 8
  %cv1453 = zext i32 %v1452 to i64
  %cond1454 = icmp ne i64 %cv1453, 0
  br i1 %cond1454, label %bb_rcgstore74, label %bb_rcginc74
bb_rcginc74:
  %v1455 = load i64, ptr %slot94, align 8
  %op1456 = sub i64 %v1455, 24
  store i64 %op1456, ptr %slot100, align 8
  %v1457 = load i64, ptr %slot94, align 8
  %p1458 = inttoptr i64 %v1457 to ptr
  %rgep1459 = getelementptr i8, ptr %p1458, i64 -24
  %ld1460 = load i64, ptr %rgep1459, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1460, ptr %slot101, align 8
  %v1461 = load i64, ptr %slot101, align 8
  %op1462 = add i64 %v1461, 1
  store i64 %op1462, ptr %slot102, align 8
  %v1463 = load i64, ptr %slot102, align 8
  %cmp1464 = icmp eq i64 %v1463, 0
  %cv1465 = zext i1 %cmp1464 to i32
  store i32 %cv1465, ptr %slot103, align 8
  %v1466 = load i32, ptr %slot103, align 8
  %cv1467 = zext i32 %v1466 to i64
  %cond1468 = icmp ne i64 %cv1467, 0
  br i1 %cond1468, label %bb_rcglimit74, label %bb_rcgcapacity74
bb_rcglimit74:
  %v1469 = load i64, ptr %slot1, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %call1471 = call i32 @myl_qbe_rc_status(ptr %p1470, i32 2) nomerge, !dbg !116
  store i32 %call1471, ptr %slot104, align 8
  br label %bb_failure
bb_rcgcapacity74:
  %v1472 = load i64, ptr %slot102, align 8
  %v1473 = load i64, ptr %slot94, align 8
  %p1474 = inttoptr i64 %v1473 to ptr
  %rgep1475 = getelementptr i8, ptr %p1474, i64 -24
  store i64 %v1472, ptr %rgep1475, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore74
bb_rcgstore74:
  %v1476 = load i64, ptr %slot94, align 8
  %v1477 = load i64, ptr %slot93, align 8
  %p1478 = inttoptr i64 %v1477 to ptr
  store i64 %v1476, ptr %p1478, align 8, !alias.scope !3, !noalias !4
  %v1479 = load i64, ptr %slot20, align 8
  %p1480 = inttoptr i64 %v1479 to ptr
  store i32 2, ptr %p1480, align 4, !alias.scope !3, !noalias !4
  %v1481 = load i64, ptr %slot20, align 8
  %p1482 = inttoptr i64 %v1481 to ptr
  store i32 16, ptr %p1482, align 4, !alias.scope !3, !noalias !4
  %v1483 = load i64, ptr %slot19, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  store i32 1, ptr %p1484, align 4, !alias.scope !3, !noalias !4
  %v1485 = load i64, ptr %slot12, align 8
  %p1486 = inttoptr i64 %v1485 to ptr
  %ld1487 = load i32, ptr %p1486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1487, ptr %slot105, align 8
  %v1488 = load i32, ptr %slot105, align 8
  %cv1489 = zext i32 %v1488 to i64
  %cond1490 = icmp ne i64 %cv1489, 0
  br i1 %cond1490, label %bb_rcslotdrop90, label %bb_rcslotdone90
bb_rcslotdrop90:
  %v1491 = load i64, ptr %slot12, align 8
  %p1492 = inttoptr i64 %v1491 to ptr
  store i32 0, ptr %p1492, align 4, !alias.scope !3, !noalias !4
  %v1493 = load i64, ptr %slot22, align 8
  store i64 %v1493, ptr %slot106, align 8
  %v1494 = load i64, ptr %slot13, align 8
  %p1495 = inttoptr i64 %v1494 to ptr
  %ld1496 = load i32, ptr %p1495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1496, ptr %slot107, align 8
  %v1497 = load i32, ptr %slot107, align 8
  %op1498 = and i32 %v1497, 28
  store i32 %op1498, ptr %slot108, align 8
  %v1499 = load i32, ptr %slot108, align 8
  %cv1500 = zext i32 %v1499 to i64
  %cond1501 = icmp ne i64 %cv1500, 0
  br i1 %cond1501, label %bb_rcslotrole90, label %bb_rcslotowner90
bb_rcslotrole90:
  %v1502 = load i64, ptr %slot54, align 8
  store i64 %v1502, ptr %slot109, align 8
  %v1503 = load i64, ptr %slot106, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  %ld1505 = load i64, ptr %p1504, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1505, ptr %slot110, align 8
  %v1506 = load i64, ptr %slot110, align 8
  %cmp1507 = icmp ne i64 %v1506, 0
  %cv1508 = zext i1 %cmp1507 to i32
  store i32 %cv1508, ptr %slot111, align 8
  %v1509 = load i32, ptr %slot111, align 8
  %cv1510 = zext i32 %v1509 to i64
  %cond1511 = icmp ne i64 %cv1510, 0
  br i1 %cond1511, label %bb_rcgnn106, label %bb_rcgdone106
bb_rcgnn106:
  %v1512 = load i64, ptr %slot110, align 8
  %op1513 = sub i64 %v1512, 16
  store i64 %op1513, ptr %slot112, align 8
  %v1514 = load i64, ptr %slot110, align 8
  %p1515 = inttoptr i64 %v1514 to ptr
  %rgep1516 = getelementptr i8, ptr %p1515, i64 -16
  %ld1517 = load i64, ptr %rgep1516, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1517, ptr %slot113, align 8
  %v1518 = load i64, ptr %slot113, align 8
  %op1519 = and i64 %v1518, 4611686018427387906
  store i64 %op1519, ptr %slot114, align 8
  %v1520 = load i64, ptr %slot114, align 8
  %cmp1521 = icmp ne i64 %v1520, 0
  %cv1522 = zext i1 %cmp1521 to i32
  store i32 %cv1522, ptr %slot115, align 8
  %v1523 = load i32, ptr %slot115, align 8
  %cv1524 = zext i32 %v1523 to i64
  %cond1525 = icmp ne i64 %cv1524, 0
  br i1 %cond1525, label %bb_rcgclear106, label %bb_rcgcounted106
bb_rcgcounted106:
  %v1526 = load i64, ptr %slot110, align 8
  %op1527 = sub i64 %v1526, 24
  store i64 %op1527, ptr %slot116, align 8
  %v1528 = load i64, ptr %slot110, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  %rgep1530 = getelementptr i8, ptr %p1529, i64 -24
  %ld1531 = load i64, ptr %rgep1530, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1531, ptr %slot117, align 8
  %v1532 = load i64, ptr %slot117, align 8
  %op1533 = sub i64 %v1532, 1
  store i64 %op1533, ptr %slot118, align 8
  %v1534 = load i64, ptr %slot118, align 8
  %cmp1535 = icmp eq i64 %v1534, 0
  %cv1536 = zext i1 %cmp1535 to i32
  store i32 %cv1536, ptr %slot119, align 8
  %v1537 = load i32, ptr %slot119, align 8
  %cv1538 = zext i32 %v1537 to i64
  %cond1539 = icmp ne i64 %cv1538, 0
  br i1 %cond1539, label %bb_rcglast106, label %bb_rcgdec106
bb_rcglast106:
  %v1540 = load i64, ptr %slot110, align 8
  %op1541 = sub i64 %v1540, 32
  store i64 %op1541, ptr %slot120, align 8
  %v1542 = load i64, ptr %slot110, align 8
  %p1543 = inttoptr i64 %v1542 to ptr
  %rgep1544 = getelementptr i8, ptr %p1543, i64 -32
  %ld1545 = load i64, ptr %rgep1544, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1545, ptr %slot121, align 8
  %v1546 = load i64, ptr %slot121, align 8
  %cmp1547 = icmp ne i64 %v1546, 0
  %cv1548 = zext i1 %cmp1547 to i32
  store i32 %cv1548, ptr %slot122, align 8
  %v1549 = load i32, ptr %slot122, align 8
  %cv1550 = zext i32 %v1549 to i64
  %cond1551 = icmp ne i64 %cv1550, 0
  br i1 %cond1551, label %bb_rcgdec106, label %bb_rcgslow106
bb_rcgslow106:
  %v1552 = load i64, ptr %slot109, align 8
  %v1553 = load i64, ptr %slot106, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1552, i64 %v1553) nomerge, !dbg !116
  br label %bb_rcgdone106
bb_rcgdec106:
  %v1554 = load i64, ptr %slot118, align 8
  %v1555 = load i64, ptr %slot110, align 8
  %p1556 = inttoptr i64 %v1555 to ptr
  %rgep1557 = getelementptr i8, ptr %p1556, i64 -24
  store i64 %v1554, ptr %rgep1557, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear106
bb_rcgclear106:
  %v1558 = load i64, ptr %slot106, align 8
  %p1559 = inttoptr i64 %v1558 to ptr
  store i64 0, ptr %p1559, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone106
bb_rcgdone106:
  br label %bb_rcslotdone90
bb_rcslotowner90:
  %v1560 = load i64, ptr %slot54, align 8
  store i64 %v1560, ptr %slot123, align 8
  %v1561 = load i64, ptr %slot106, align 8
  %p1562 = inttoptr i64 %v1561 to ptr
  %ld1563 = load i64, ptr %p1562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1563, ptr %slot124, align 8
  %v1564 = load i64, ptr %slot124, align 8
  %cmp1565 = icmp ne i64 %v1564, 0
  %cv1566 = zext i1 %cmp1565 to i32
  store i32 %cv1566, ptr %slot125, align 8
  %v1567 = load i32, ptr %slot125, align 8
  %cv1568 = zext i32 %v1567 to i64
  %cond1569 = icmp ne i64 %cv1568, 0
  br i1 %cond1569, label %bb_rcgnn121, label %bb_rcgdone121
bb_rcgnn121:
  %v1570 = load i64, ptr %slot124, align 8
  %op1571 = sub i64 %v1570, 16
  store i64 %op1571, ptr %slot126, align 8
  %v1572 = load i64, ptr %slot124, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  %rgep1574 = getelementptr i8, ptr %p1573, i64 -16
  %ld1575 = load i64, ptr %rgep1574, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1575, ptr %slot127, align 8
  %v1576 = load i64, ptr %slot127, align 8
  %op1577 = and i64 %v1576, 4611686018427387906
  store i64 %op1577, ptr %slot128, align 8
  %v1578 = load i64, ptr %slot128, align 8
  %cmp1579 = icmp ne i64 %v1578, 0
  %cv1580 = zext i1 %cmp1579 to i32
  store i32 %cv1580, ptr %slot129, align 8
  %v1581 = load i32, ptr %slot129, align 8
  %cv1582 = zext i32 %v1581 to i64
  %cond1583 = icmp ne i64 %cv1582, 0
  br i1 %cond1583, label %bb_rcgclear121, label %bb_rcgcounted121
bb_rcgcounted121:
  %v1584 = load i64, ptr %slot124, align 8
  %op1585 = sub i64 %v1584, 32
  store i64 %op1585, ptr %slot130, align 8
  %v1586 = load i64, ptr %slot124, align 8
  %p1587 = inttoptr i64 %v1586 to ptr
  %rgep1588 = getelementptr i8, ptr %p1587, i64 -32
  %ld1589 = load i64, ptr %rgep1588, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1589, ptr %slot131, align 8
  %v1590 = load i64, ptr %slot131, align 8
  %op1591 = sub i64 %v1590, 1
  store i64 %op1591, ptr %slot132, align 8
  %v1592 = load i64, ptr %slot132, align 8
  %cmp1593 = icmp eq i64 %v1592, 0
  %cv1594 = zext i1 %cmp1593 to i32
  store i32 %cv1594, ptr %slot133, align 8
  %v1595 = load i32, ptr %slot133, align 8
  %cv1596 = zext i32 %v1595 to i64
  %cond1597 = icmp ne i64 %cv1596, 0
  br i1 %cond1597, label %bb_rcglast121, label %bb_rcgdec121
bb_rcglast121:
  %v1598 = load i64, ptr %slot124, align 8
  %op1599 = sub i64 %v1598, 24
  store i64 %op1599, ptr %slot134, align 8
  %v1600 = load i64, ptr %slot124, align 8
  %p1601 = inttoptr i64 %v1600 to ptr
  %rgep1602 = getelementptr i8, ptr %p1601, i64 -24
  %ld1603 = load i64, ptr %rgep1602, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1603, ptr %slot135, align 8
  %v1604 = load i64, ptr %slot135, align 8
  %cmp1605 = icmp ne i64 %v1604, 0
  %cv1606 = zext i1 %cmp1605 to i32
  store i32 %cv1606, ptr %slot136, align 8
  %v1607 = load i32, ptr %slot136, align 8
  %cv1608 = zext i32 %v1607 to i64
  %cond1609 = icmp ne i64 %cv1608, 0
  br i1 %cond1609, label %bb_rcgdec121, label %bb_rcgslow121
bb_rcgslow121:
  %v1610 = load i64, ptr %slot123, align 8
  %v1611 = load i64, ptr %slot106, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1610, i64 %v1611) nomerge, !dbg !116
  br label %bb_rcgdone121
bb_rcgdec121:
  %v1612 = load i64, ptr %slot132, align 8
  %v1613 = load i64, ptr %slot124, align 8
  %p1614 = inttoptr i64 %v1613 to ptr
  %rgep1615 = getelementptr i8, ptr %p1614, i64 -32
  store i64 %v1612, ptr %rgep1615, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear121
bb_rcgclear121:
  %v1616 = load i64, ptr %slot106, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  store i64 0, ptr %p1617, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone121
bb_rcgdone121:
  br label %bb_rcslotdone90
bb_rcslotdone90:
  br label %bb_rcprivateprepared38
bb_rcprivateprepared38:
  %v1618 = load i64, ptr %slot6, align 8
  %p1619 = inttoptr i64 %v1618 to ptr
  %ld1620 = load i32, ptr %p1619, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1620, ptr %slot137, align 8
  %v1621 = load i32, ptr %slot137, align 8
  %cv1622 = zext i32 %v1621 to i64
  %cond1623 = icmp ne i64 %cv1622, 0
  br i1 %cond1623, label %bb_rcslotdrop128, label %bb_rcslotdone128
bb_rcslotdrop128:
  %v1624 = load i64, ptr %slot6, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i32 0, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot32, align 8
  store i64 %v1626, ptr %slot138, align 8
  %v1627 = load i64, ptr %slot7, align 8
  %p1628 = inttoptr i64 %v1627 to ptr
  %ld1629 = load i32, ptr %p1628, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1629, ptr %slot139, align 8
  %v1630 = load i32, ptr %slot139, align 8
  %op1631 = and i32 %v1630, 28
  store i32 %op1631, ptr %slot140, align 8
  %v1632 = load i32, ptr %slot140, align 8
  %cv1633 = zext i32 %v1632 to i64
  %cond1634 = icmp ne i64 %cv1633, 0
  br i1 %cond1634, label %bb_rcslotrole128, label %bb_rcslotowner128
bb_rcslotrole128:
  %v1635 = load i64, ptr %slot54, align 8
  store i64 %v1635, ptr %slot141, align 8
  %v1636 = load i64, ptr %slot138, align 8
  %p1637 = inttoptr i64 %v1636 to ptr
  %ld1638 = load i64, ptr %p1637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1638, ptr %slot142, align 8
  %v1639 = load i64, ptr %slot142, align 8
  %cmp1640 = icmp ne i64 %v1639, 0
  %cv1641 = zext i1 %cmp1640 to i32
  store i32 %cv1641, ptr %slot143, align 8
  %v1642 = load i32, ptr %slot143, align 8
  %cv1643 = zext i32 %v1642 to i64
  %cond1644 = icmp ne i64 %cv1643, 0
  br i1 %cond1644, label %bb_rcgnn144, label %bb_rcgdone144
bb_rcgnn144:
  %v1645 = load i64, ptr %slot142, align 8
  %op1646 = sub i64 %v1645, 16
  store i64 %op1646, ptr %slot144, align 8
  %v1647 = load i64, ptr %slot142, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %rgep1649 = getelementptr i8, ptr %p1648, i64 -16
  %ld1650 = load i64, ptr %rgep1649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1650, ptr %slot145, align 8
  %v1651 = load i64, ptr %slot145, align 8
  %op1652 = and i64 %v1651, 4611686018427387906
  store i64 %op1652, ptr %slot146, align 8
  %v1653 = load i64, ptr %slot146, align 8
  %cmp1654 = icmp ne i64 %v1653, 0
  %cv1655 = zext i1 %cmp1654 to i32
  store i32 %cv1655, ptr %slot147, align 8
  %v1656 = load i32, ptr %slot147, align 8
  %cv1657 = zext i32 %v1656 to i64
  %cond1658 = icmp ne i64 %cv1657, 0
  br i1 %cond1658, label %bb_rcgclear144, label %bb_rcgcounted144
bb_rcgcounted144:
  %v1659 = load i64, ptr %slot142, align 8
  %op1660 = sub i64 %v1659, 24
  store i64 %op1660, ptr %slot148, align 8
  %v1661 = load i64, ptr %slot142, align 8
  %p1662 = inttoptr i64 %v1661 to ptr
  %rgep1663 = getelementptr i8, ptr %p1662, i64 -24
  %ld1664 = load i64, ptr %rgep1663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1664, ptr %slot149, align 8
  %v1665 = load i64, ptr %slot149, align 8
  %op1666 = sub i64 %v1665, 1
  store i64 %op1666, ptr %slot150, align 8
  %v1667 = load i64, ptr %slot150, align 8
  %cmp1668 = icmp eq i64 %v1667, 0
  %cv1669 = zext i1 %cmp1668 to i32
  store i32 %cv1669, ptr %slot151, align 8
  %v1670 = load i32, ptr %slot151, align 8
  %cv1671 = zext i32 %v1670 to i64
  %cond1672 = icmp ne i64 %cv1671, 0
  br i1 %cond1672, label %bb_rcglast144, label %bb_rcgdec144
bb_rcglast144:
  %v1673 = load i64, ptr %slot142, align 8
  %op1674 = sub i64 %v1673, 32
  store i64 %op1674, ptr %slot152, align 8
  %v1675 = load i64, ptr %slot142, align 8
  %p1676 = inttoptr i64 %v1675 to ptr
  %rgep1677 = getelementptr i8, ptr %p1676, i64 -32
  %ld1678 = load i64, ptr %rgep1677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1678, ptr %slot153, align 8
  %v1679 = load i64, ptr %slot153, align 8
  %cmp1680 = icmp ne i64 %v1679, 0
  %cv1681 = zext i1 %cmp1680 to i32
  store i32 %cv1681, ptr %slot154, align 8
  %v1682 = load i32, ptr %slot154, align 8
  %cv1683 = zext i32 %v1682 to i64
  %cond1684 = icmp ne i64 %cv1683, 0
  br i1 %cond1684, label %bb_rcgdec144, label %bb_rcgslow144
bb_rcgslow144:
  %v1685 = load i64, ptr %slot141, align 8
  %v1686 = load i64, ptr %slot138, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v1685, i64 %v1686) nomerge, !dbg !116
  br label %bb_rcgdone144
bb_rcgdec144:
  %v1687 = load i64, ptr %slot150, align 8
  %v1688 = load i64, ptr %slot142, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  %rgep1690 = getelementptr i8, ptr %p1689, i64 -24
  store i64 %v1687, ptr %rgep1690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear144
bb_rcgclear144:
  %v1691 = load i64, ptr %slot138, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  store i64 0, ptr %p1692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone144
bb_rcgdone144:
  br label %bb_rcslotdone128
bb_rcslotowner128:
  %v1693 = load i64, ptr %slot54, align 8
  store i64 %v1693, ptr %slot155, align 8
  %v1694 = load i64, ptr %slot138, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  %ld1696 = load i64, ptr %p1695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1696, ptr %slot156, align 8
  %v1697 = load i64, ptr %slot156, align 8
  %cmp1698 = icmp ne i64 %v1697, 0
  %cv1699 = zext i1 %cmp1698 to i32
  store i32 %cv1699, ptr %slot157, align 8
  %v1700 = load i32, ptr %slot157, align 8
  %cv1701 = zext i32 %v1700 to i64
  %cond1702 = icmp ne i64 %cv1701, 0
  br i1 %cond1702, label %bb_rcgnn159, label %bb_rcgdone159
bb_rcgnn159:
  %v1703 = load i64, ptr %slot156, align 8
  %op1704 = sub i64 %v1703, 16
  store i64 %op1704, ptr %slot158, align 8
  %v1705 = load i64, ptr %slot156, align 8
  %p1706 = inttoptr i64 %v1705 to ptr
  %rgep1707 = getelementptr i8, ptr %p1706, i64 -16
  %ld1708 = load i64, ptr %rgep1707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1708, ptr %slot159, align 8
  %v1709 = load i64, ptr %slot159, align 8
  %op1710 = and i64 %v1709, 4611686018427387906
  store i64 %op1710, ptr %slot160, align 8
  %v1711 = load i64, ptr %slot160, align 8
  %cmp1712 = icmp ne i64 %v1711, 0
  %cv1713 = zext i1 %cmp1712 to i32
  store i32 %cv1713, ptr %slot161, align 8
  %v1714 = load i32, ptr %slot161, align 8
  %cv1715 = zext i32 %v1714 to i64
  %cond1716 = icmp ne i64 %cv1715, 0
  br i1 %cond1716, label %bb_rcgclear159, label %bb_rcgcounted159
bb_rcgcounted159:
  %v1717 = load i64, ptr %slot156, align 8
  %op1718 = sub i64 %v1717, 32
  store i64 %op1718, ptr %slot162, align 8
  %v1719 = load i64, ptr %slot156, align 8
  %p1720 = inttoptr i64 %v1719 to ptr
  %rgep1721 = getelementptr i8, ptr %p1720, i64 -32
  %ld1722 = load i64, ptr %rgep1721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1722, ptr %slot163, align 8
  %v1723 = load i64, ptr %slot163, align 8
  %op1724 = sub i64 %v1723, 1
  store i64 %op1724, ptr %slot164, align 8
  %v1725 = load i64, ptr %slot164, align 8
  %cmp1726 = icmp eq i64 %v1725, 0
  %cv1727 = zext i1 %cmp1726 to i32
  store i32 %cv1727, ptr %slot165, align 8
  %v1728 = load i32, ptr %slot165, align 8
  %cv1729 = zext i32 %v1728 to i64
  %cond1730 = icmp ne i64 %cv1729, 0
  br i1 %cond1730, label %bb_rcglast159, label %bb_rcgdec159
bb_rcglast159:
  %v1731 = load i64, ptr %slot156, align 8
  %op1732 = sub i64 %v1731, 24
  store i64 %op1732, ptr %slot166, align 8
  %v1733 = load i64, ptr %slot156, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  %rgep1735 = getelementptr i8, ptr %p1734, i64 -24
  %ld1736 = load i64, ptr %rgep1735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1736, ptr %slot167, align 8
  %v1737 = load i64, ptr %slot167, align 8
  %cmp1738 = icmp ne i64 %v1737, 0
  %cv1739 = zext i1 %cmp1738 to i32
  store i32 %cv1739, ptr %slot168, align 8
  %v1740 = load i32, ptr %slot168, align 8
  %cv1741 = zext i32 %v1740 to i64
  %cond1742 = icmp ne i64 %cv1741, 0
  br i1 %cond1742, label %bb_rcgdec159, label %bb_rcgslow159
bb_rcgslow159:
  %v1743 = load i64, ptr %slot155, align 8
  %v1744 = load i64, ptr %slot138, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v1743, i64 %v1744) nomerge, !dbg !116
  br label %bb_rcgdone159
bb_rcgdec159:
  %v1745 = load i64, ptr %slot164, align 8
  %v1746 = load i64, ptr %slot156, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %rgep1748 = getelementptr i8, ptr %p1747, i64 -32
  store i64 %v1745, ptr %rgep1748, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear159
bb_rcgclear159:
  %v1749 = load i64, ptr %slot138, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  store i64 0, ptr %p1750, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone159
bb_rcgdone159:
  br label %bb_rcslotdone128
bb_rcslotdone128:
  %v1751 = load i64, ptr %slot32, align 8
  store i64 %v1751, ptr %slot169, align 8
  %v1752 = load i64, ptr %slot28, align 8
  store i64 %v1752, ptr %slot170, align 8
  %v1753 = load i64, ptr %slot170, align 8
  %v1754 = load i64, ptr %slot169, align 8
  %p1755 = inttoptr i64 %v1753 to ptr
  %p1756 = inttoptr i64 %v1754 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1756, ptr %p1755, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1757 = load i64, ptr %slot19, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  store i32 0, ptr %p1758, align 4, !alias.scope !3, !noalias !4
  %v1759 = load i64, ptr %slot7, align 8
  %p1760 = inttoptr i64 %v1759 to ptr
  store i32 2, ptr %p1760, align 4, !alias.scope !3, !noalias !4
  %v1761 = load i64, ptr %slot20, align 8
  %p1762 = inttoptr i64 %v1761 to ptr
  %ld1763 = load i32, ptr %p1762, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1763, ptr %slot171, align 8
  %v1764 = load i32, ptr %slot171, align 8
  %v1765 = load i64, ptr %slot7, align 8
  %p1766 = inttoptr i64 %v1765 to ptr
  store i32 %v1764, ptr %p1766, align 4, !alias.scope !3, !noalias !4
  %v1767 = load i64, ptr %slot6, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  store i32 1, ptr %p1768, align 4, !alias.scope !3, !noalias !4
  %v1769 = load i64, ptr %slot32, align 8
  %p1770 = inttoptr i64 %v1769 to ptr
  %ld1771 = load i64, ptr %p1770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1771, ptr %slot172, align 8
  %v1772 = load i64, ptr %slot172, align 8
  %v1773 = load i64, ptr %slot36, align 8
  %p1774 = inttoptr i64 %v1773 to ptr
  store i64 %v1772, ptr %p1774, align 8, !alias.scope !3, !noalias !4
  %v1775 = load i64, ptr %slot36, align 8
  %p1776 = inttoptr i64 %v1775 to ptr
  %ld1777 = load i64, ptr %p1776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1777, ptr %slot173, align 8
  %v1778 = load i64, ptr %slot173, align 8
  %v1779 = load i64, ptr %slot25, align 8
  %p1780 = inttoptr i64 %v1779 to ptr
  store i64 %v1778, ptr %p1780, align 8, !alias.scope !3, !noalias !4
  %v1781 = load i64, ptr %slot25, align 8
  store i64 %v1781, ptr %slot174, align 8
  %v1782 = load i64, ptr %slot12, align 8
  %p1783 = inttoptr i64 %v1782 to ptr
  %ld1784 = load i32, ptr %p1783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1784, ptr %slot175, align 8
  %v1785 = load i64, ptr %slot13, align 8
  %p1786 = inttoptr i64 %v1785 to ptr
  %ld1787 = load i32, ptr %p1786, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1787, ptr %slot176, align 8
  %v1788 = load i32, ptr %slot176, align 8
  %op1789 = and i32 %v1788, 24
  store i32 %op1789, ptr %slot176, align 8
  %v1790 = load i32, ptr %slot176, align 8
  %cmp1791 = icmp eq i32 %v1790, 0
  %cv1792 = zext i1 %cmp1791 to i32
  store i32 %cv1792, ptr %slot177, align 8
  %v1793 = load i32, ptr %slot175, align 8
  %v1794 = load i32, ptr %slot177, align 8
  %op1795 = and i32 %v1793, %v1794
  store i32 %op1795, ptr %slot178, align 8
  %v1796 = load i32, ptr %slot178, align 8
  %cv1797 = zext i32 %v1796 to i64
  %cond1798 = icmp ne i64 %cv1797, 0
  br i1 %cond1798, label %bb_rctake173, label %bb_rccopy173
bb_rctake173:
  %v1799 = load i64, ptr %slot28, align 8
  store i64 %v1799, ptr %slot179, align 8
  %v1800 = load i64, ptr %slot55, align 8
  store i64 %v1800, ptr %slot180, align 8
  %v1801 = load i64, ptr %slot174, align 8
  %v1802 = load i64, ptr %slot179, align 8
  %op1803 = sub i64 %v1801, %v1802
  store i64 %op1803, ptr %slot181, align 8
  %v1804 = load i64, ptr %slot179, align 8
  %v1805 = load i64, ptr %slot174, align 8
  %op1806 = sub i64 %v1804, %v1805
  store i64 %op1806, ptr %slot182, align 8
  %v1807 = load i64, ptr %slot181, align 8
  %cmp1808 = icmp ult i64 %v1807, 8
  %cv1809 = zext i1 %cmp1808 to i32
  store i32 %cv1809, ptr %slot183, align 8
  %v1810 = load i64, ptr %slot182, align 8
  %cmp1811 = icmp ult i64 %v1810, 8
  %cv1812 = zext i1 %cmp1811 to i32
  store i32 %cv1812, ptr %slot184, align 8
  %v1813 = load i32, ptr %slot183, align 8
  %v1814 = load i32, ptr %slot184, align 8
  %op1815 = or i32 %v1813, %v1814
  store i32 %op1815, ptr %slot185, align 8
  %v1816 = load i32, ptr %slot185, align 8
  %cv1817 = zext i32 %v1816 to i64
  %cond1818 = icmp ne i64 %cv1817, 0
  br i1 %cond1818, label %bb_rcmoveslow182, label %bb_rcmovecheck182
bb_rcmovecheck182:
  %v1819 = load i64, ptr %slot174, align 8
  %p1821 = inttoptr i64 %v1819 to ptr
  %gep1822 = getelementptr i8, ptr %p1821, i64 0
  %op1820 = ptrtoint ptr %gep1822 to i64
  store i64 %op1820, ptr %slot186, align 8
  %v1823 = load i64, ptr %slot186, align 8
  %p1824 = inttoptr i64 %v1823 to ptr
  %ld1825 = load i64, ptr %p1824, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1825, ptr %slot187, align 8
  %v1826 = load i64, ptr %slot187, align 8
  %cmp1827 = icmp ne i64 %v1826, 0
  %cv1828 = zext i1 %cmp1827 to i32
  store i32 %cv1828, ptr %slot188, align 8
  %v1829 = load i32, ptr %slot188, align 8
  %cv1830 = zext i32 %v1829 to i64
  %cond1831 = icmp ne i64 %cv1830, 0
  br i1 %cond1831, label %bb_rcmoveheader190, label %bb_rcmovenext190
bb_rcmoveheader190:
  %v1832 = load i64, ptr %slot187, align 8
  %op1833 = sub i64 %v1832, 16
  store i64 %op1833, ptr %slot189, align 8
  %v1834 = load i64, ptr %slot187, align 8
  %p1835 = inttoptr i64 %v1834 to ptr
  %rgep1836 = getelementptr i8, ptr %p1835, i64 -16
  %ld1837 = load i64, ptr %rgep1836, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1837, ptr %slot190, align 8
  %v1838 = load i64, ptr %slot190, align 8
  %op1839 = and i64 %v1838, 5764607523034234881
  store i64 %op1839, ptr %slot191, align 8
  %v1840 = load i64, ptr %slot191, align 8
  %cmp1841 = icmp ne i64 %v1840, 0
  %cv1842 = zext i1 %cmp1841 to i32
  store i32 %cv1842, ptr %slot192, align 8
  %v1843 = load i32, ptr %slot192, align 8
  %cv1844 = zext i32 %v1843 to i64
  %cond1845 = icmp ne i64 %cv1844, 0
  br i1 %cond1845, label %bb_rcmoveslow182, label %bb_rcmovenext190
bb_rcmovenext190:
  %v1846 = load i64, ptr %slot174, align 8
  %v1847 = load i64, ptr %slot179, align 8
  %p1848 = inttoptr i64 %v1846 to ptr
  %p1849 = inttoptr i64 %v1847 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1849, ptr %p1848, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1850 = load i64, ptr %slot174, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  store i64 0, ptr %p1851, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved182
bb_rcmoveslow182:
  %v1852 = load i64, ptr %slot54, align 8
  %v1853 = load i64, ptr %slot179, align 8
  %v1854 = load i64, ptr %slot174, align 8
  %v1855 = load i64, ptr %slot180, align 8
  %cv1856 = trunc i64 %v1855 to i32
  %call1857 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v1852, i64 %v1853, i64 %v1854, i32 %cv1856) nomerge, !dbg !118
  store i32 %call1857, ptr %slot193, align 8
  %v1858 = load i32, ptr %slot193, align 8
  %cv1859 = zext i32 %v1858 to i64
  %cond1860 = icmp ne i64 %cv1859, 0
  br i1 %cond1860, label %bb_rcsuccess197, label %bb_rcfailure197
bb_rcfailure197:
  %v1861 = load i64, ptr %slot54, align 8
  %p1862 = inttoptr i64 %v1861 to ptr
  %call1863 = call i32 @myl_rc_take_failure(ptr %p1862) nomerge, !dbg !118
  store i32 %call1863, ptr %slot194, align 8
  %v1864 = load i64, ptr %slot1, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  %v1866 = load i32, ptr %slot194, align 8
  %call1867 = call i32 @myl_qbe_rc_status(ptr %p1865, i32 %v1866) nomerge, !dbg !118
  store i32 %call1867, ptr %slot195, align 8
  br label %bb_failure
bb_rcsuccess197:
  br label %bb_rcmoved182
bb_rcmoved182:
  %v1868 = load i64, ptr %slot12, align 8
  %p1869 = inttoptr i64 %v1868 to ptr
  store i32 0, ptr %p1869, align 4, !alias.scope !3, !noalias !4
  %v1870 = load i64, ptr %slot20, align 8
  %p1871 = inttoptr i64 %v1870 to ptr
  store i32 2, ptr %p1871, align 4, !alias.scope !3, !noalias !4
  %v1872 = load i64, ptr %slot19, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  store i32 1, ptr %p1873, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared173
bb_rccopy173:
  %v1874 = load i64, ptr %slot28, align 8
  store i64 %v1874, ptr %slot196, align 8
  %v1875 = load i64, ptr %slot55, align 8
  store i64 %v1875, ptr %slot197, align 8
  %v1876 = load i64, ptr %slot174, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  %ld1878 = load i64, ptr %p1877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1878, ptr %slot198, align 8
  %v1879 = load i64, ptr %slot198, align 8
  %cmp1880 = icmp ne i64 %v1879, 0
  %cv1881 = zext i1 %cmp1880 to i32
  store i32 %cv1881, ptr %slot199, align 8
  %v1882 = load i32, ptr %slot199, align 8
  %cv1883 = zext i32 %v1882 to i64
  %cond1884 = icmp ne i64 %cv1883, 0
  br i1 %cond1884, label %bb_rcgnn206, label %bb_rcgplain206
bb_rcgnn206:
  %v1885 = load i64, ptr %slot198, align 8
  %op1886 = sub i64 %v1885, 16
  store i64 %op1886, ptr %slot200, align 8
  %v1887 = load i64, ptr %slot198, align 8
  %p1888 = inttoptr i64 %v1887 to ptr
  %rgep1889 = getelementptr i8, ptr %p1888, i64 -16
  %ld1890 = load i64, ptr %rgep1889, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1890, ptr %slot201, align 8
  %v1891 = load i64, ptr %slot201, align 8
  %op1892 = and i64 %v1891, 4611686018427387906
  store i64 %op1892, ptr %slot202, align 8
  %v1893 = load i64, ptr %slot202, align 8
  %cmp1894 = icmp ne i64 %v1893, 0
  %cv1895 = zext i1 %cmp1894 to i32
  store i32 %cv1895, ptr %slot203, align 8
  %v1896 = load i32, ptr %slot203, align 8
  %cv1897 = zext i32 %v1896 to i64
  %cond1898 = icmp ne i64 %cv1897, 0
  br i1 %cond1898, label %bb_rcgspecial206, label %bb_rcginc206
bb_rcginc206:
  %v1899 = load i64, ptr %slot198, align 8
  %op1900 = sub i64 %v1899, 32
  store i64 %op1900, ptr %slot204, align 8
  %v1901 = load i64, ptr %slot198, align 8
  %p1902 = inttoptr i64 %v1901 to ptr
  %rgep1903 = getelementptr i8, ptr %p1902, i64 -32
  %ld1904 = load i64, ptr %rgep1903, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1904, ptr %slot205, align 8
  %v1905 = load i64, ptr %slot205, align 8
  %op1906 = add i64 %v1905, 1
  store i64 %op1906, ptr %slot206, align 8
  %v1907 = load i64, ptr %slot206, align 8
  %cmp1908 = icmp eq i64 %v1907, 0
  %cv1909 = zext i1 %cmp1908 to i32
  store i32 %cv1909, ptr %slot207, align 8
  %v1910 = load i32, ptr %slot207, align 8
  %cv1911 = zext i32 %v1910 to i64
  %cond1912 = icmp ne i64 %cv1911, 0
  br i1 %cond1912, label %bb_rcglimit206, label %bb_rcgcapacity206
bb_rcglimit206:
  %v1913 = load i64, ptr %slot1, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  %call1915 = call i32 @myl_qbe_rc_status(ptr %p1914, i32 2) nomerge, !dbg !118
  store i32 %call1915, ptr %slot208, align 8
  br label %bb_failure
bb_rcgcapacity206:
  %v1916 = load i64, ptr %slot206, align 8
  %v1917 = load i64, ptr %slot198, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %rgep1919 = getelementptr i8, ptr %p1918, i64 -32
  store i64 %v1916, ptr %rgep1919, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain206
bb_rcgspecial206:
  %v1920 = load i64, ptr %slot201, align 8
  %op1921 = and i64 %v1920, 4611686018427387904
  store i64 %op1921, ptr %slot209, align 8
  %v1922 = load i64, ptr %slot209, align 8
  %cmp1923 = icmp ne i64 %v1922, 0
  %cv1924 = zext i1 %cmp1923 to i32
  store i32 %cv1924, ptr %slot210, align 8
  %v1925 = load i32, ptr %slot210, align 8
  %cv1926 = zext i32 %v1925 to i64
  %cond1927 = icmp ne i64 %cv1926, 0
  br i1 %cond1927, label %bb_rcgslow206, label %bb_rcgplain206
bb_rcgslow206:
  %v1928 = load i64, ptr %slot54, align 8
  %v1929 = load i64, ptr %slot196, align 8
  %v1930 = load i64, ptr %slot174, align 8
  %v1931 = load i64, ptr %slot197, align 8
  %cv1932 = trunc i64 %v1931 to i32
  %call1933 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v1928, i64 %v1929, i64 %v1930, i32 %cv1932) nomerge, !dbg !118
  store i32 %call1933, ptr %slot211, align 8
  %v1934 = load i32, ptr %slot211, align 8
  %cv1935 = zext i32 %v1934 to i64
  %cond1936 = icmp ne i64 %cv1935, 0
  br i1 %cond1936, label %bb_rcsuccess220, label %bb_rcfailure220
bb_rcfailure220:
  %v1937 = load i64, ptr %slot54, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  %call1939 = call i32 @myl_rc_take_failure(ptr %p1938) nomerge, !dbg !118
  store i32 %call1939, ptr %slot212, align 8
  %v1940 = load i64, ptr %slot1, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  %v1942 = load i32, ptr %slot212, align 8
  %call1943 = call i32 @myl_qbe_rc_status(ptr %p1941, i32 %v1942) nomerge, !dbg !118
  store i32 %call1943, ptr %slot213, align 8
  br label %bb_failure
bb_rcsuccess220:
  br label %bb_rcgdone206
bb_rcgplain206:
  %v1944 = load i64, ptr %slot198, align 8
  %v1945 = load i64, ptr %slot196, align 8
  %p1946 = inttoptr i64 %v1945 to ptr
  store i64 %v1944, ptr %p1946, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone206
bb_rcgdone206:
  %v1947 = load i64, ptr %slot20, align 8
  %p1948 = inttoptr i64 %v1947 to ptr
  store i32 2, ptr %p1948, align 4, !alias.scope !3, !noalias !4
  %v1949 = load i64, ptr %slot19, align 8
  %p1950 = inttoptr i64 %v1949 to ptr
  store i32 1, ptr %p1950, align 4, !alias.scope !3, !noalias !4
  %v1951 = load i64, ptr %slot12, align 8
  %p1952 = inttoptr i64 %v1951 to ptr
  %ld1953 = load i32, ptr %p1952, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1953, ptr %slot214, align 8
  %v1954 = load i32, ptr %slot214, align 8
  %cv1955 = zext i32 %v1954 to i64
  %cond1956 = icmp ne i64 %cv1955, 0
  br i1 %cond1956, label %bb_rcslotdrop227, label %bb_rcslotdone227
bb_rcslotdrop227:
  %v1957 = load i64, ptr %slot12, align 8
  %p1958 = inttoptr i64 %v1957 to ptr
  store i32 0, ptr %p1958, align 4, !alias.scope !3, !noalias !4
  %v1959 = load i64, ptr %slot22, align 8
  store i64 %v1959, ptr %slot215, align 8
  %v1960 = load i64, ptr %slot13, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  %ld1962 = load i32, ptr %p1961, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1962, ptr %slot216, align 8
  %v1963 = load i32, ptr %slot216, align 8
  %op1964 = and i32 %v1963, 28
  store i32 %op1964, ptr %slot217, align 8
  %v1965 = load i32, ptr %slot217, align 8
  %cv1966 = zext i32 %v1965 to i64
  %cond1967 = icmp ne i64 %cv1966, 0
  br i1 %cond1967, label %bb_rcslotrole227, label %bb_rcslotowner227
bb_rcslotrole227:
  %v1968 = load i64, ptr %slot54, align 8
  store i64 %v1968, ptr %slot218, align 8
  %v1969 = load i64, ptr %slot215, align 8
  %p1970 = inttoptr i64 %v1969 to ptr
  %ld1971 = load i64, ptr %p1970, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1971, ptr %slot219, align 8
  %v1972 = load i64, ptr %slot219, align 8
  %cmp1973 = icmp ne i64 %v1972, 0
  %cv1974 = zext i1 %cmp1973 to i32
  store i32 %cv1974, ptr %slot220, align 8
  %v1975 = load i32, ptr %slot220, align 8
  %cv1976 = zext i32 %v1975 to i64
  %cond1977 = icmp ne i64 %cv1976, 0
  br i1 %cond1977, label %bb_rcgnn243, label %bb_rcgdone243
bb_rcgnn243:
  %v1978 = load i64, ptr %slot219, align 8
  %op1979 = sub i64 %v1978, 16
  store i64 %op1979, ptr %slot221, align 8
  %v1980 = load i64, ptr %slot219, align 8
  %p1981 = inttoptr i64 %v1980 to ptr
  %rgep1982 = getelementptr i8, ptr %p1981, i64 -16
  %ld1983 = load i64, ptr %rgep1982, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1983, ptr %slot222, align 8
  %v1984 = load i64, ptr %slot222, align 8
  %op1985 = and i64 %v1984, 4611686018427387906
  store i64 %op1985, ptr %slot223, align 8
  %v1986 = load i64, ptr %slot223, align 8
  %cmp1987 = icmp ne i64 %v1986, 0
  %cv1988 = zext i1 %cmp1987 to i32
  store i32 %cv1988, ptr %slot224, align 8
  %v1989 = load i32, ptr %slot224, align 8
  %cv1990 = zext i32 %v1989 to i64
  %cond1991 = icmp ne i64 %cv1990, 0
  br i1 %cond1991, label %bb_rcgclear243, label %bb_rcgcounted243
bb_rcgcounted243:
  %v1992 = load i64, ptr %slot219, align 8
  %op1993 = sub i64 %v1992, 24
  store i64 %op1993, ptr %slot225, align 8
  %v1994 = load i64, ptr %slot219, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  %rgep1996 = getelementptr i8, ptr %p1995, i64 -24
  %ld1997 = load i64, ptr %rgep1996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1997, ptr %slot226, align 8
  %v1998 = load i64, ptr %slot226, align 8
  %op1999 = sub i64 %v1998, 1
  store i64 %op1999, ptr %slot227, align 8
  %v2000 = load i64, ptr %slot227, align 8
  %cmp2001 = icmp eq i64 %v2000, 0
  %cv2002 = zext i1 %cmp2001 to i32
  store i32 %cv2002, ptr %slot228, align 8
  %v2003 = load i32, ptr %slot228, align 8
  %cv2004 = zext i32 %v2003 to i64
  %cond2005 = icmp ne i64 %cv2004, 0
  br i1 %cond2005, label %bb_rcglast243, label %bb_rcgdec243
bb_rcglast243:
  %v2006 = load i64, ptr %slot219, align 8
  %op2007 = sub i64 %v2006, 32
  store i64 %op2007, ptr %slot229, align 8
  %v2008 = load i64, ptr %slot219, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  %rgep2010 = getelementptr i8, ptr %p2009, i64 -32
  %ld2011 = load i64, ptr %rgep2010, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2011, ptr %slot230, align 8
  %v2012 = load i64, ptr %slot230, align 8
  %cmp2013 = icmp ne i64 %v2012, 0
  %cv2014 = zext i1 %cmp2013 to i32
  store i32 %cv2014, ptr %slot231, align 8
  %v2015 = load i32, ptr %slot231, align 8
  %cv2016 = zext i32 %v2015 to i64
  %cond2017 = icmp ne i64 %cv2016, 0
  br i1 %cond2017, label %bb_rcgdec243, label %bb_rcgslow243
bb_rcgslow243:
  %v2018 = load i64, ptr %slot218, align 8
  %v2019 = load i64, ptr %slot215, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2018, i64 %v2019) nomerge, !dbg !118
  br label %bb_rcgdone243
bb_rcgdec243:
  %v2020 = load i64, ptr %slot227, align 8
  %v2021 = load i64, ptr %slot219, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  %rgep2023 = getelementptr i8, ptr %p2022, i64 -24
  store i64 %v2020, ptr %rgep2023, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear243
bb_rcgclear243:
  %v2024 = load i64, ptr %slot215, align 8
  %p2025 = inttoptr i64 %v2024 to ptr
  store i64 0, ptr %p2025, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone243
bb_rcgdone243:
  br label %bb_rcslotdone227
bb_rcslotowner227:
  %v2026 = load i64, ptr %slot54, align 8
  store i64 %v2026, ptr %slot232, align 8
  %v2027 = load i64, ptr %slot215, align 8
  %p2028 = inttoptr i64 %v2027 to ptr
  %ld2029 = load i64, ptr %p2028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2029, ptr %slot233, align 8
  %v2030 = load i64, ptr %slot233, align 8
  %cmp2031 = icmp ne i64 %v2030, 0
  %cv2032 = zext i1 %cmp2031 to i32
  store i32 %cv2032, ptr %slot234, align 8
  %v2033 = load i32, ptr %slot234, align 8
  %cv2034 = zext i32 %v2033 to i64
  %cond2035 = icmp ne i64 %cv2034, 0
  br i1 %cond2035, label %bb_rcgnn258, label %bb_rcgdone258
bb_rcgnn258:
  %v2036 = load i64, ptr %slot233, align 8
  %op2037 = sub i64 %v2036, 16
  store i64 %op2037, ptr %slot235, align 8
  %v2038 = load i64, ptr %slot233, align 8
  %p2039 = inttoptr i64 %v2038 to ptr
  %rgep2040 = getelementptr i8, ptr %p2039, i64 -16
  %ld2041 = load i64, ptr %rgep2040, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2041, ptr %slot236, align 8
  %v2042 = load i64, ptr %slot236, align 8
  %op2043 = and i64 %v2042, 4611686018427387906
  store i64 %op2043, ptr %slot237, align 8
  %v2044 = load i64, ptr %slot237, align 8
  %cmp2045 = icmp ne i64 %v2044, 0
  %cv2046 = zext i1 %cmp2045 to i32
  store i32 %cv2046, ptr %slot238, align 8
  %v2047 = load i32, ptr %slot238, align 8
  %cv2048 = zext i32 %v2047 to i64
  %cond2049 = icmp ne i64 %cv2048, 0
  br i1 %cond2049, label %bb_rcgclear258, label %bb_rcgcounted258
bb_rcgcounted258:
  %v2050 = load i64, ptr %slot233, align 8
  %op2051 = sub i64 %v2050, 32
  store i64 %op2051, ptr %slot239, align 8
  %v2052 = load i64, ptr %slot233, align 8
  %p2053 = inttoptr i64 %v2052 to ptr
  %rgep2054 = getelementptr i8, ptr %p2053, i64 -32
  %ld2055 = load i64, ptr %rgep2054, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2055, ptr %slot240, align 8
  %v2056 = load i64, ptr %slot240, align 8
  %op2057 = sub i64 %v2056, 1
  store i64 %op2057, ptr %slot241, align 8
  %v2058 = load i64, ptr %slot241, align 8
  %cmp2059 = icmp eq i64 %v2058, 0
  %cv2060 = zext i1 %cmp2059 to i32
  store i32 %cv2060, ptr %slot242, align 8
  %v2061 = load i32, ptr %slot242, align 8
  %cv2062 = zext i32 %v2061 to i64
  %cond2063 = icmp ne i64 %cv2062, 0
  br i1 %cond2063, label %bb_rcglast258, label %bb_rcgdec258
bb_rcglast258:
  %v2064 = load i64, ptr %slot233, align 8
  %op2065 = sub i64 %v2064, 24
  store i64 %op2065, ptr %slot243, align 8
  %v2066 = load i64, ptr %slot233, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  %rgep2068 = getelementptr i8, ptr %p2067, i64 -24
  %ld2069 = load i64, ptr %rgep2068, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2069, ptr %slot244, align 8
  %v2070 = load i64, ptr %slot244, align 8
  %cmp2071 = icmp ne i64 %v2070, 0
  %cv2072 = zext i1 %cmp2071 to i32
  store i32 %cv2072, ptr %slot245, align 8
  %v2073 = load i32, ptr %slot245, align 8
  %cv2074 = zext i32 %v2073 to i64
  %cond2075 = icmp ne i64 %cv2074, 0
  br i1 %cond2075, label %bb_rcgdec258, label %bb_rcgslow258
bb_rcgslow258:
  %v2076 = load i64, ptr %slot232, align 8
  %v2077 = load i64, ptr %slot215, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2076, i64 %v2077) nomerge, !dbg !118
  br label %bb_rcgdone258
bb_rcgdec258:
  %v2078 = load i64, ptr %slot241, align 8
  %v2079 = load i64, ptr %slot233, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  %rgep2081 = getelementptr i8, ptr %p2080, i64 -32
  store i64 %v2078, ptr %rgep2081, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear258
bb_rcgclear258:
  %v2082 = load i64, ptr %slot215, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  store i64 0, ptr %p2083, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone258
bb_rcgdone258:
  br label %bb_rcslotdone227
bb_rcslotdone227:
  br label %bb_rcprepared173
bb_rcprepared173:
  %v2084 = load i64, ptr %slot8, align 8
  %p2085 = inttoptr i64 %v2084 to ptr
  %ld2086 = load i32, ptr %p2085, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2086, ptr %slot246, align 8
  %v2087 = load i32, ptr %slot246, align 8
  %cv2088 = zext i32 %v2087 to i64
  %cond2089 = icmp ne i64 %cv2088, 0
  br i1 %cond2089, label %bb_rcslotdrop265, label %bb_rcslotdone265
bb_rcslotdrop265:
  %v2090 = load i64, ptr %slot8, align 8
  %p2091 = inttoptr i64 %v2090 to ptr
  store i32 0, ptr %p2091, align 4, !alias.scope !3, !noalias !4
  %v2092 = load i64, ptr %slot33, align 8
  store i64 %v2092, ptr %slot247, align 8
  %v2093 = load i64, ptr %slot9, align 8
  %p2094 = inttoptr i64 %v2093 to ptr
  %ld2095 = load i32, ptr %p2094, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2095, ptr %slot248, align 8
  %v2096 = load i32, ptr %slot248, align 8
  %op2097 = and i32 %v2096, 28
  store i32 %op2097, ptr %slot249, align 8
  %v2098 = load i32, ptr %slot249, align 8
  %cv2099 = zext i32 %v2098 to i64
  %cond2100 = icmp ne i64 %cv2099, 0
  br i1 %cond2100, label %bb_rcslotrole265, label %bb_rcslotowner265
bb_rcslotrole265:
  %v2101 = load i64, ptr %slot54, align 8
  store i64 %v2101, ptr %slot250, align 8
  %v2102 = load i64, ptr %slot247, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  %ld2104 = load i64, ptr %p2103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2104, ptr %slot251, align 8
  %v2105 = load i64, ptr %slot251, align 8
  %cmp2106 = icmp ne i64 %v2105, 0
  %cv2107 = zext i1 %cmp2106 to i32
  store i32 %cv2107, ptr %slot252, align 8
  %v2108 = load i32, ptr %slot252, align 8
  %cv2109 = zext i32 %v2108 to i64
  %cond2110 = icmp ne i64 %cv2109, 0
  br i1 %cond2110, label %bb_rcgnn281, label %bb_rcgdone281
bb_rcgnn281:
  %v2111 = load i64, ptr %slot251, align 8
  %op2112 = sub i64 %v2111, 16
  store i64 %op2112, ptr %slot253, align 8
  %v2113 = load i64, ptr %slot251, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %rgep2115 = getelementptr i8, ptr %p2114, i64 -16
  %ld2116 = load i64, ptr %rgep2115, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2116, ptr %slot254, align 8
  %v2117 = load i64, ptr %slot254, align 8
  %op2118 = and i64 %v2117, 4611686018427387906
  store i64 %op2118, ptr %slot255, align 8
  %v2119 = load i64, ptr %slot255, align 8
  %cmp2120 = icmp ne i64 %v2119, 0
  %cv2121 = zext i1 %cmp2120 to i32
  store i32 %cv2121, ptr %slot256, align 8
  %v2122 = load i32, ptr %slot256, align 8
  %cv2123 = zext i32 %v2122 to i64
  %cond2124 = icmp ne i64 %cv2123, 0
  br i1 %cond2124, label %bb_rcgclear281, label %bb_rcgcounted281
bb_rcgcounted281:
  %v2125 = load i64, ptr %slot251, align 8
  %op2126 = sub i64 %v2125, 24
  store i64 %op2126, ptr %slot257, align 8
  %v2127 = load i64, ptr %slot251, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  %rgep2129 = getelementptr i8, ptr %p2128, i64 -24
  %ld2130 = load i64, ptr %rgep2129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2130, ptr %slot258, align 8
  %v2131 = load i64, ptr %slot258, align 8
  %op2132 = sub i64 %v2131, 1
  store i64 %op2132, ptr %slot259, align 8
  %v2133 = load i64, ptr %slot259, align 8
  %cmp2134 = icmp eq i64 %v2133, 0
  %cv2135 = zext i1 %cmp2134 to i32
  store i32 %cv2135, ptr %slot260, align 8
  %v2136 = load i32, ptr %slot260, align 8
  %cv2137 = zext i32 %v2136 to i64
  %cond2138 = icmp ne i64 %cv2137, 0
  br i1 %cond2138, label %bb_rcglast281, label %bb_rcgdec281
bb_rcglast281:
  %v2139 = load i64, ptr %slot251, align 8
  %op2140 = sub i64 %v2139, 32
  store i64 %op2140, ptr %slot261, align 8
  %v2141 = load i64, ptr %slot251, align 8
  %p2142 = inttoptr i64 %v2141 to ptr
  %rgep2143 = getelementptr i8, ptr %p2142, i64 -32
  %ld2144 = load i64, ptr %rgep2143, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2144, ptr %slot262, align 8
  %v2145 = load i64, ptr %slot262, align 8
  %cmp2146 = icmp ne i64 %v2145, 0
  %cv2147 = zext i1 %cmp2146 to i32
  store i32 %cv2147, ptr %slot263, align 8
  %v2148 = load i32, ptr %slot263, align 8
  %cv2149 = zext i32 %v2148 to i64
  %cond2150 = icmp ne i64 %cv2149, 0
  br i1 %cond2150, label %bb_rcgdec281, label %bb_rcgslow281
bb_rcgslow281:
  %v2151 = load i64, ptr %slot250, align 8
  %v2152 = load i64, ptr %slot247, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2151, i64 %v2152) nomerge, !dbg !118
  br label %bb_rcgdone281
bb_rcgdec281:
  %v2153 = load i64, ptr %slot259, align 8
  %v2154 = load i64, ptr %slot251, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  %rgep2156 = getelementptr i8, ptr %p2155, i64 -24
  store i64 %v2153, ptr %rgep2156, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear281
bb_rcgclear281:
  %v2157 = load i64, ptr %slot247, align 8
  %p2158 = inttoptr i64 %v2157 to ptr
  store i64 0, ptr %p2158, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone281
bb_rcgdone281:
  br label %bb_rcslotdone265
bb_rcslotowner265:
  %v2159 = load i64, ptr %slot54, align 8
  store i64 %v2159, ptr %slot264, align 8
  %v2160 = load i64, ptr %slot247, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  %ld2162 = load i64, ptr %p2161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2162, ptr %slot265, align 8
  %v2163 = load i64, ptr %slot265, align 8
  %cmp2164 = icmp ne i64 %v2163, 0
  %cv2165 = zext i1 %cmp2164 to i32
  store i32 %cv2165, ptr %slot266, align 8
  %v2166 = load i32, ptr %slot266, align 8
  %cv2167 = zext i32 %v2166 to i64
  %cond2168 = icmp ne i64 %cv2167, 0
  br i1 %cond2168, label %bb_rcgnn296, label %bb_rcgdone296
bb_rcgnn296:
  %v2169 = load i64, ptr %slot265, align 8
  %op2170 = sub i64 %v2169, 16
  store i64 %op2170, ptr %slot267, align 8
  %v2171 = load i64, ptr %slot265, align 8
  %p2172 = inttoptr i64 %v2171 to ptr
  %rgep2173 = getelementptr i8, ptr %p2172, i64 -16
  %ld2174 = load i64, ptr %rgep2173, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2174, ptr %slot268, align 8
  %v2175 = load i64, ptr %slot268, align 8
  %op2176 = and i64 %v2175, 4611686018427387906
  store i64 %op2176, ptr %slot269, align 8
  %v2177 = load i64, ptr %slot269, align 8
  %cmp2178 = icmp ne i64 %v2177, 0
  %cv2179 = zext i1 %cmp2178 to i32
  store i32 %cv2179, ptr %slot270, align 8
  %v2180 = load i32, ptr %slot270, align 8
  %cv2181 = zext i32 %v2180 to i64
  %cond2182 = icmp ne i64 %cv2181, 0
  br i1 %cond2182, label %bb_rcgclear296, label %bb_rcgcounted296
bb_rcgcounted296:
  %v2183 = load i64, ptr %slot265, align 8
  %op2184 = sub i64 %v2183, 32
  store i64 %op2184, ptr %slot271, align 8
  %v2185 = load i64, ptr %slot265, align 8
  %p2186 = inttoptr i64 %v2185 to ptr
  %rgep2187 = getelementptr i8, ptr %p2186, i64 -32
  %ld2188 = load i64, ptr %rgep2187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2188, ptr %slot272, align 8
  %v2189 = load i64, ptr %slot272, align 8
  %op2190 = sub i64 %v2189, 1
  store i64 %op2190, ptr %slot273, align 8
  %v2191 = load i64, ptr %slot273, align 8
  %cmp2192 = icmp eq i64 %v2191, 0
  %cv2193 = zext i1 %cmp2192 to i32
  store i32 %cv2193, ptr %slot274, align 8
  %v2194 = load i32, ptr %slot274, align 8
  %cv2195 = zext i32 %v2194 to i64
  %cond2196 = icmp ne i64 %cv2195, 0
  br i1 %cond2196, label %bb_rcglast296, label %bb_rcgdec296
bb_rcglast296:
  %v2197 = load i64, ptr %slot265, align 8
  %op2198 = sub i64 %v2197, 24
  store i64 %op2198, ptr %slot275, align 8
  %v2199 = load i64, ptr %slot265, align 8
  %p2200 = inttoptr i64 %v2199 to ptr
  %rgep2201 = getelementptr i8, ptr %p2200, i64 -24
  %ld2202 = load i64, ptr %rgep2201, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2202, ptr %slot276, align 8
  %v2203 = load i64, ptr %slot276, align 8
  %cmp2204 = icmp ne i64 %v2203, 0
  %cv2205 = zext i1 %cmp2204 to i32
  store i32 %cv2205, ptr %slot277, align 8
  %v2206 = load i32, ptr %slot277, align 8
  %cv2207 = zext i32 %v2206 to i64
  %cond2208 = icmp ne i64 %cv2207, 0
  br i1 %cond2208, label %bb_rcgdec296, label %bb_rcgslow296
bb_rcgslow296:
  %v2209 = load i64, ptr %slot264, align 8
  %v2210 = load i64, ptr %slot247, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2209, i64 %v2210) nomerge, !dbg !118
  br label %bb_rcgdone296
bb_rcgdec296:
  %v2211 = load i64, ptr %slot273, align 8
  %v2212 = load i64, ptr %slot265, align 8
  %p2213 = inttoptr i64 %v2212 to ptr
  %rgep2214 = getelementptr i8, ptr %p2213, i64 -32
  store i64 %v2211, ptr %rgep2214, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear296
bb_rcgclear296:
  %v2215 = load i64, ptr %slot247, align 8
  %p2216 = inttoptr i64 %v2215 to ptr
  store i64 0, ptr %p2216, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone296
bb_rcgdone296:
  br label %bb_rcslotdone265
bb_rcslotdone265:
  %v2217 = load i64, ptr %slot33, align 8
  store i64 %v2217, ptr %slot278, align 8
  %v2218 = load i64, ptr %slot28, align 8
  store i64 %v2218, ptr %slot279, align 8
  %v2219 = load i64, ptr %slot279, align 8
  %v2220 = load i64, ptr %slot278, align 8
  %p2221 = inttoptr i64 %v2219 to ptr
  %p2222 = inttoptr i64 %v2220 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2222, ptr %p2221, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2223 = load i64, ptr %slot19, align 8
  %p2224 = inttoptr i64 %v2223 to ptr
  store i32 0, ptr %p2224, align 4, !alias.scope !3, !noalias !4
  %v2225 = load i64, ptr %slot9, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  store i32 2, ptr %p2226, align 4, !alias.scope !3, !noalias !4
  %v2227 = load i64, ptr %slot20, align 8
  %p2228 = inttoptr i64 %v2227 to ptr
  %ld2229 = load i32, ptr %p2228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2229, ptr %slot280, align 8
  %v2230 = load i32, ptr %slot280, align 8
  %v2231 = load i64, ptr %slot9, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  store i32 %v2230, ptr %p2232, align 4, !alias.scope !3, !noalias !4
  %v2233 = load i64, ptr %slot8, align 8
  %p2234 = inttoptr i64 %v2233 to ptr
  store i32 1, ptr %p2234, align 4, !alias.scope !3, !noalias !4
  %v2235 = load i64, ptr %slot6, align 8
  %p2236 = inttoptr i64 %v2235 to ptr
  %ld2237 = load i32, ptr %p2236, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2237, ptr %slot281, align 8
  %v2238 = load i32, ptr %slot281, align 8
  %cv2239 = zext i32 %v2238 to i64
  %cond2240 = icmp ne i64 %cv2239, 0
  br i1 %cond2240, label %bb_rcslotdrop309, label %bb_rcslotdone309
bb_rcslotdrop309:
  %v2241 = load i64, ptr %slot6, align 8
  %p2242 = inttoptr i64 %v2241 to ptr
  store i32 0, ptr %p2242, align 4, !alias.scope !3, !noalias !4
  %v2243 = load i64, ptr %slot32, align 8
  store i64 %v2243, ptr %slot282, align 8
  %v2244 = load i64, ptr %slot7, align 8
  %p2245 = inttoptr i64 %v2244 to ptr
  %ld2246 = load i32, ptr %p2245, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2246, ptr %slot283, align 8
  %v2247 = load i32, ptr %slot283, align 8
  %op2248 = and i32 %v2247, 28
  store i32 %op2248, ptr %slot284, align 8
  %v2249 = load i32, ptr %slot284, align 8
  %cv2250 = zext i32 %v2249 to i64
  %cond2251 = icmp ne i64 %cv2250, 0
  br i1 %cond2251, label %bb_rcslotrole309, label %bb_rcslotowner309
bb_rcslotrole309:
  %v2252 = load i64, ptr %slot54, align 8
  store i64 %v2252, ptr %slot285, align 8
  %v2253 = load i64, ptr %slot282, align 8
  %p2254 = inttoptr i64 %v2253 to ptr
  %ld2255 = load i64, ptr %p2254, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2255, ptr %slot286, align 8
  %v2256 = load i64, ptr %slot286, align 8
  %cmp2257 = icmp ne i64 %v2256, 0
  %cv2258 = zext i1 %cmp2257 to i32
  store i32 %cv2258, ptr %slot287, align 8
  %v2259 = load i32, ptr %slot287, align 8
  %cv2260 = zext i32 %v2259 to i64
  %cond2261 = icmp ne i64 %cv2260, 0
  br i1 %cond2261, label %bb_rcgnn325, label %bb_rcgdone325
bb_rcgnn325:
  %v2262 = load i64, ptr %slot286, align 8
  %op2263 = sub i64 %v2262, 16
  store i64 %op2263, ptr %slot288, align 8
  %v2264 = load i64, ptr %slot286, align 8
  %p2265 = inttoptr i64 %v2264 to ptr
  %rgep2266 = getelementptr i8, ptr %p2265, i64 -16
  %ld2267 = load i64, ptr %rgep2266, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2267, ptr %slot289, align 8
  %v2268 = load i64, ptr %slot289, align 8
  %op2269 = and i64 %v2268, 4611686018427387906
  store i64 %op2269, ptr %slot290, align 8
  %v2270 = load i64, ptr %slot290, align 8
  %cmp2271 = icmp ne i64 %v2270, 0
  %cv2272 = zext i1 %cmp2271 to i32
  store i32 %cv2272, ptr %slot291, align 8
  %v2273 = load i32, ptr %slot291, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcgclear325, label %bb_rcgcounted325
bb_rcgcounted325:
  %v2276 = load i64, ptr %slot286, align 8
  %op2277 = sub i64 %v2276, 24
  store i64 %op2277, ptr %slot292, align 8
  %v2278 = load i64, ptr %slot286, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  %rgep2280 = getelementptr i8, ptr %p2279, i64 -24
  %ld2281 = load i64, ptr %rgep2280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2281, ptr %slot293, align 8
  %v2282 = load i64, ptr %slot293, align 8
  %op2283 = sub i64 %v2282, 1
  store i64 %op2283, ptr %slot294, align 8
  %v2284 = load i64, ptr %slot294, align 8
  %cmp2285 = icmp eq i64 %v2284, 0
  %cv2286 = zext i1 %cmp2285 to i32
  store i32 %cv2286, ptr %slot295, align 8
  %v2287 = load i32, ptr %slot295, align 8
  %cv2288 = zext i32 %v2287 to i64
  %cond2289 = icmp ne i64 %cv2288, 0
  br i1 %cond2289, label %bb_rcglast325, label %bb_rcgdec325
bb_rcglast325:
  %v2290 = load i64, ptr %slot286, align 8
  %op2291 = sub i64 %v2290, 32
  store i64 %op2291, ptr %slot296, align 8
  %v2292 = load i64, ptr %slot286, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  %rgep2294 = getelementptr i8, ptr %p2293, i64 -32
  %ld2295 = load i64, ptr %rgep2294, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2295, ptr %slot297, align 8
  %v2296 = load i64, ptr %slot297, align 8
  %cmp2297 = icmp ne i64 %v2296, 0
  %cv2298 = zext i1 %cmp2297 to i32
  store i32 %cv2298, ptr %slot298, align 8
  %v2299 = load i32, ptr %slot298, align 8
  %cv2300 = zext i32 %v2299 to i64
  %cond2301 = icmp ne i64 %cv2300, 0
  br i1 %cond2301, label %bb_rcgdec325, label %bb_rcgslow325
bb_rcgslow325:
  %v2302 = load i64, ptr %slot285, align 8
  %v2303 = load i64, ptr %slot282, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2302, i64 %v2303) nomerge, !dbg !118
  br label %bb_rcgdone325
bb_rcgdec325:
  %v2304 = load i64, ptr %slot294, align 8
  %v2305 = load i64, ptr %slot286, align 8
  %p2306 = inttoptr i64 %v2305 to ptr
  %rgep2307 = getelementptr i8, ptr %p2306, i64 -24
  store i64 %v2304, ptr %rgep2307, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear325
bb_rcgclear325:
  %v2308 = load i64, ptr %slot282, align 8
  %p2309 = inttoptr i64 %v2308 to ptr
  store i64 0, ptr %p2309, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone325
bb_rcgdone325:
  br label %bb_rcslotdone309
bb_rcslotowner309:
  %v2310 = load i64, ptr %slot54, align 8
  store i64 %v2310, ptr %slot299, align 8
  %v2311 = load i64, ptr %slot282, align 8
  %p2312 = inttoptr i64 %v2311 to ptr
  %ld2313 = load i64, ptr %p2312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2313, ptr %slot300, align 8
  %v2314 = load i64, ptr %slot300, align 8
  %cmp2315 = icmp ne i64 %v2314, 0
  %cv2316 = zext i1 %cmp2315 to i32
  store i32 %cv2316, ptr %slot301, align 8
  %v2317 = load i32, ptr %slot301, align 8
  %cv2318 = zext i32 %v2317 to i64
  %cond2319 = icmp ne i64 %cv2318, 0
  br i1 %cond2319, label %bb_rcgnn340, label %bb_rcgdone340
bb_rcgnn340:
  %v2320 = load i64, ptr %slot300, align 8
  %op2321 = sub i64 %v2320, 16
  store i64 %op2321, ptr %slot302, align 8
  %v2322 = load i64, ptr %slot300, align 8
  %p2323 = inttoptr i64 %v2322 to ptr
  %rgep2324 = getelementptr i8, ptr %p2323, i64 -16
  %ld2325 = load i64, ptr %rgep2324, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2325, ptr %slot303, align 8
  %v2326 = load i64, ptr %slot303, align 8
  %op2327 = and i64 %v2326, 4611686018427387906
  store i64 %op2327, ptr %slot304, align 8
  %v2328 = load i64, ptr %slot304, align 8
  %cmp2329 = icmp ne i64 %v2328, 0
  %cv2330 = zext i1 %cmp2329 to i32
  store i32 %cv2330, ptr %slot305, align 8
  %v2331 = load i32, ptr %slot305, align 8
  %cv2332 = zext i32 %v2331 to i64
  %cond2333 = icmp ne i64 %cv2332, 0
  br i1 %cond2333, label %bb_rcgclear340, label %bb_rcgcounted340
bb_rcgcounted340:
  %v2334 = load i64, ptr %slot300, align 8
  %op2335 = sub i64 %v2334, 32
  store i64 %op2335, ptr %slot306, align 8
  %v2336 = load i64, ptr %slot300, align 8
  %p2337 = inttoptr i64 %v2336 to ptr
  %rgep2338 = getelementptr i8, ptr %p2337, i64 -32
  %ld2339 = load i64, ptr %rgep2338, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2339, ptr %slot307, align 8
  %v2340 = load i64, ptr %slot307, align 8
  %op2341 = sub i64 %v2340, 1
  store i64 %op2341, ptr %slot308, align 8
  %v2342 = load i64, ptr %slot308, align 8
  %cmp2343 = icmp eq i64 %v2342, 0
  %cv2344 = zext i1 %cmp2343 to i32
  store i32 %cv2344, ptr %slot309, align 8
  %v2345 = load i32, ptr %slot309, align 8
  %cv2346 = zext i32 %v2345 to i64
  %cond2347 = icmp ne i64 %cv2346, 0
  br i1 %cond2347, label %bb_rcglast340, label %bb_rcgdec340
bb_rcglast340:
  %v2348 = load i64, ptr %slot300, align 8
  %op2349 = sub i64 %v2348, 24
  store i64 %op2349, ptr %slot310, align 8
  %v2350 = load i64, ptr %slot300, align 8
  %p2351 = inttoptr i64 %v2350 to ptr
  %rgep2352 = getelementptr i8, ptr %p2351, i64 -24
  %ld2353 = load i64, ptr %rgep2352, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2353, ptr %slot311, align 8
  %v2354 = load i64, ptr %slot311, align 8
  %cmp2355 = icmp ne i64 %v2354, 0
  %cv2356 = zext i1 %cmp2355 to i32
  store i32 %cv2356, ptr %slot312, align 8
  %v2357 = load i32, ptr %slot312, align 8
  %cv2358 = zext i32 %v2357 to i64
  %cond2359 = icmp ne i64 %cv2358, 0
  br i1 %cond2359, label %bb_rcgdec340, label %bb_rcgslow340
bb_rcgslow340:
  %v2360 = load i64, ptr %slot299, align 8
  %v2361 = load i64, ptr %slot282, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2360, i64 %v2361) nomerge, !dbg !118
  br label %bb_rcgdone340
bb_rcgdec340:
  %v2362 = load i64, ptr %slot308, align 8
  %v2363 = load i64, ptr %slot300, align 8
  %p2364 = inttoptr i64 %v2363 to ptr
  %rgep2365 = getelementptr i8, ptr %p2364, i64 -32
  store i64 %v2362, ptr %rgep2365, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear340
bb_rcgclear340:
  %v2366 = load i64, ptr %slot282, align 8
  %p2367 = inttoptr i64 %v2366 to ptr
  store i64 0, ptr %p2367, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone340
bb_rcgdone340:
  br label %bb_rcslotdone309
bb_rcslotdone309:
  %v2368 = load i64, ptr %slot30, align 8
  %p2369 = inttoptr i64 %v2368 to ptr
  %ld2370 = load i64, ptr %p2369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2370, ptr %slot313, align 8
  %v2371 = load i64, ptr %slot313, align 8
  %v2372 = load i64, ptr %slot36, align 8
  %p2373 = inttoptr i64 %v2372 to ptr
  store i64 %v2371, ptr %p2373, align 8, !alias.scope !3, !noalias !4
  %v2374 = load i64, ptr %slot40, align 8
  store i64 %v2374, ptr %slot314, align 8
  %v2375 = load i64, ptr %slot314, align 8
  %p2376 = inttoptr i64 %v2375 to ptr
  store i32 0, ptr %p2376, align 4, !alias.scope !3, !noalias !4
  %v2377 = load i64, ptr %slot314, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  store i32 1, ptr %p2378, align 4, !alias.scope !3, !noalias !4
  %v2379 = load i64, ptr %slot314, align 8
  %v2380 = load i64, ptr %slot37, align 8
  %p2381 = inttoptr i64 %v2380 to ptr
  store i64 %v2379, ptr %p2381, align 8, !alias.scope !3, !noalias !4
  %v2382 = load i64, ptr %slot36, align 8
  %p2383 = inttoptr i64 %v2382 to ptr
  %ld2384 = load i64, ptr %p2383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2384, ptr %slot315, align 8
  %v2385 = load i64, ptr %slot37, align 8
  %p2386 = inttoptr i64 %v2385 to ptr
  %ld2387 = load i64, ptr %p2386, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2387, ptr %slot316, align 8
  %v2388 = load i64, ptr %slot1, align 8
  %v2389 = load i64, ptr %slot315, align 8
  %v2390 = load i64, ptr %slot316, align 8
  %call2391 = call i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64 %v2388, i64 %v2389, i64 %v2390) nomerge, !dbg !120
  store i64 %call2391, ptr %slot317, align 8
  %v2392 = load i64, ptr %slot317, align 8
  %v2393 = load i64, ptr %slot36, align 8
  %p2394 = inttoptr i64 %v2393 to ptr
  store i64 %v2392, ptr %p2394, align 8, !alias.scope !3, !noalias !4
  %v2395 = load i64, ptr %slot12, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  %ld2397 = load i32, ptr %p2396, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2397, ptr %slot318, align 8
  %v2398 = load i32, ptr %slot318, align 8
  %cv2399 = zext i32 %v2398 to i64
  %cond2400 = icmp ne i64 %cv2399, 0
  br i1 %cond2400, label %bb_rcslotdrop351, label %bb_rcslotdone351
bb_rcslotdrop351:
  %v2401 = load i64, ptr %slot12, align 8
  %p2402 = inttoptr i64 %v2401 to ptr
  store i32 0, ptr %p2402, align 4, !alias.scope !3, !noalias !4
  %v2403 = load i64, ptr %slot22, align 8
  store i64 %v2403, ptr %slot319, align 8
  %v2404 = load i64, ptr %slot13, align 8
  %p2405 = inttoptr i64 %v2404 to ptr
  %ld2406 = load i32, ptr %p2405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2406, ptr %slot320, align 8
  %v2407 = load i32, ptr %slot320, align 8
  %op2408 = and i32 %v2407, 28
  store i32 %op2408, ptr %slot321, align 8
  %v2409 = load i32, ptr %slot321, align 8
  %cv2410 = zext i32 %v2409 to i64
  %cond2411 = icmp ne i64 %cv2410, 0
  br i1 %cond2411, label %bb_rcslotrole351, label %bb_rcslotowner351
bb_rcslotrole351:
  %v2412 = load i64, ptr %slot54, align 8
  store i64 %v2412, ptr %slot322, align 8
  %v2413 = load i64, ptr %slot322, align 8
  %v2414 = load i64, ptr %slot319, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2413, i64 %v2414) nomerge, !dbg !120
  br label %bb_rcslotdone351
bb_rcslotowner351:
  %v2415 = load i64, ptr %slot54, align 8
  store i64 %v2415, ptr %slot323, align 8
  %v2416 = load i64, ptr %slot323, align 8
  %v2417 = load i64, ptr %slot319, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2416, i64 %v2417) nomerge, !dbg !120
  br label %bb_rcslotdone351
bb_rcslotdone351:
  %v2418 = load i64, ptr %slot36, align 8
  %p2419 = inttoptr i64 %v2418 to ptr
  %ld2420 = load i64, ptr %p2419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2420, ptr %slot324, align 8
  %v2421 = load i64, ptr %slot324, align 8
  %op2422 = xor i64 %v2421, 1
  store i64 %op2422, ptr %slot325, align 8
  %v2423 = load i64, ptr %slot325, align 8
  %v2424 = load i64, ptr %slot36, align 8
  %p2425 = inttoptr i64 %v2424 to ptr
  store i64 %v2423, ptr %p2425, align 8, !alias.scope !3, !noalias !4
  %v2426 = load i64, ptr %slot36, align 8
  %p2427 = inttoptr i64 %v2426 to ptr
  %ld2428 = load i64, ptr %p2427, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2428, ptr %slot326, align 8
  %v2429 = load i64, ptr %slot326, align 8
  %cond2430 = icmp ne i64 %v2429, 0
  br i1 %cond2430, label %bb_next361, label %bb_i43
bb_next361:
  %v2431 = load i64, ptr %slot30, align 8
  %p2432 = inttoptr i64 %v2431 to ptr
  %ld2433 = load i64, ptr %p2432, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2433, ptr %slot327, align 8
  %v2434 = load i64, ptr %slot327, align 8
  %v2435 = load i64, ptr %slot36, align 8
  %p2436 = inttoptr i64 %v2435 to ptr
  store i64 %v2434, ptr %p2436, align 8, !alias.scope !3, !noalias !4
  %v2437 = load i64, ptr %slot36, align 8
  %p2438 = inttoptr i64 %v2437 to ptr
  %ld2439 = load i64, ptr %p2438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2439, ptr %slot328, align 8
  %v2440 = load i64, ptr %slot1, align 8
  %v2441 = load i64, ptr %slot328, align 8
  %call2442 = call { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64 %v2440, i64 %v2441) nomerge, !dbg !122
  store { i64, i64 } %call2442, ptr %callresult330, align 8
  %addr2443 = ptrtoint ptr %callresult330 to i64
  store i64 %addr2443, ptr %slot329, align 8
  %v2444 = load i64, ptr %slot329, align 8
  %v2445 = load i64, ptr %slot36, align 8
  %p2446 = inttoptr i64 %v2445 to ptr
  store i64 %v2444, ptr %p2446, align 8, !alias.scope !3, !noalias !4
  %v2447 = load i64, ptr %slot12, align 8
  %p2448 = inttoptr i64 %v2447 to ptr
  %ld2449 = load i32, ptr %p2448, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2449, ptr %slot331, align 8
  %v2450 = load i32, ptr %slot331, align 8
  %cv2451 = zext i32 %v2450 to i64
  %cond2452 = icmp ne i64 %cv2451, 0
  br i1 %cond2452, label %bb_rcslotdrop366, label %bb_rcslotdone366
bb_rcslotdrop366:
  %v2453 = load i64, ptr %slot12, align 8
  %p2454 = inttoptr i64 %v2453 to ptr
  store i32 0, ptr %p2454, align 4, !alias.scope !3, !noalias !4
  %v2455 = load i64, ptr %slot22, align 8
  store i64 %v2455, ptr %slot332, align 8
  %v2456 = load i64, ptr %slot13, align 8
  %p2457 = inttoptr i64 %v2456 to ptr
  %ld2458 = load i32, ptr %p2457, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2458, ptr %slot333, align 8
  %v2459 = load i32, ptr %slot333, align 8
  %op2460 = and i32 %v2459, 28
  store i32 %op2460, ptr %slot334, align 8
  %v2461 = load i32, ptr %slot334, align 8
  %cv2462 = zext i32 %v2461 to i64
  %cond2463 = icmp ne i64 %cv2462, 0
  br i1 %cond2463, label %bb_rcslotrole366, label %bb_rcslotowner366
bb_rcslotrole366:
  %v2464 = load i64, ptr %slot54, align 8
  store i64 %v2464, ptr %slot335, align 8
  %v2465 = load i64, ptr %slot335, align 8
  %v2466 = load i64, ptr %slot332, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v2465, i64 %v2466) nomerge, !dbg !122
  br label %bb_rcslotdone366
bb_rcslotowner366:
  %v2467 = load i64, ptr %slot54, align 8
  store i64 %v2467, ptr %slot336, align 8
  %v2468 = load i64, ptr %slot336, align 8
  %v2469 = load i64, ptr %slot332, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v2468, i64 %v2469) nomerge, !dbg !122
  br label %bb_rcslotdone366
bb_rcslotdone366:
  %v2470 = load i64, ptr %slot36, align 8
  %p2471 = inttoptr i64 %v2470 to ptr
  %ld2472 = load i64, ptr %p2471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2472, ptr %slot337, align 8
  %v2473 = load i64, ptr %slot337, align 8
  %p2474 = inttoptr i64 %v2473 to ptr
  %ld2475 = load i32, ptr %p2474, align 4
  %ext2476 = zext i32 %ld2475 to i64
  store i64 %ext2476, ptr %slot338, align 8
  %v2477 = load i64, ptr %slot338, align 8
  %cmp2478 = icmp eq i64 %v2477, 0
  %cv2479 = zext i1 %cmp2478 to i64
  store i64 %cv2479, ptr %slot339, align 8
  %v2480 = load i64, ptr %slot339, align 8
  %cond2481 = icmp ne i64 %v2480, 0
  br i1 %cond2481, label %bb_rctryok374, label %bb_rctryerror374
bb_rctryerror374:
  %p2482 = inttoptr i64 ptrtoint (ptr @myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p2482, i64 12884901901) "call-inline-cost"="0", !dbg !124
  %v2483 = load i64, ptr %slot337, align 8
  %op2484 = add i64 %v2483, 8
  store i64 %op2484, ptr %slot340, align 8
  %v2485 = load i64, ptr %slot41, align 8
  store i64 %v2485, ptr %slot341, align 8
  %v2486 = load i64, ptr %slot341, align 8
  %p2487 = inttoptr i64 %v2486 to ptr
  store i64 0, ptr %p2487, align 8, !alias.scope !3, !noalias !4
  %v2488 = load i64, ptr %slot341, align 8
  %p2490 = inttoptr i64 %v2488 to ptr
  %gep2491 = getelementptr i8, ptr %p2490, i64 8
  %op2489 = ptrtoint ptr %gep2491 to i64
  store i64 %op2489, ptr %slot342, align 8
  %v2492 = load i64, ptr %slot342, align 8
  %p2493 = inttoptr i64 %v2492 to ptr
  store i64 0, ptr %p2493, align 8, !alias.scope !3, !noalias !4
  %v2494 = load i64, ptr %slot341, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  store i32 1, ptr %p2495, align 4, !alias.scope !3, !noalias !4
  %v2496 = load i64, ptr %slot341, align 8
  %p2498 = inttoptr i64 %v2496 to ptr
  %gep2499 = getelementptr i8, ptr %p2498, i64 8
  %op2497 = ptrtoint ptr %gep2499 to i64
  store i64 %op2497, ptr %slot343, align 8
  %v2500 = load i64, ptr %slot21, align 8
  %p2501 = inttoptr i64 %v2500 to ptr
  store i32 1, ptr %p2501, align 4, !alias.scope !3, !noalias !4
  %v2502 = load i64, ptr %slot55, align 8
  store i64 %v2502, ptr %slot344, align 8
  %v2503 = load i64, ptr %slot341, align 8
  %v2504 = load i64, ptr %slot36, align 8
  %p2505 = inttoptr i64 %v2504 to ptr
  store i64 %v2503, ptr %p2505, align 8, !alias.scope !3, !noalias !4
  br label %bb_i15
bb_rctryok374:
  %v2506 = load i64, ptr %slot41, align 8
  store i64 %v2506, ptr %slot345, align 8
  %v2507 = load i64, ptr %slot345, align 8
  %p2508 = inttoptr i64 %v2507 to ptr
  store i64 0, ptr %p2508, align 8, !alias.scope !3, !noalias !4
  %v2509 = load i64, ptr %slot21, align 8
  %p2510 = inttoptr i64 %v2509 to ptr
  store i32 1, ptr %p2510, align 4, !alias.scope !3, !noalias !4
  %v2511 = load i64, ptr %slot337, align 8
  %op2512 = add i64 %v2511, 8
  store i64 %op2512, ptr %slot346, align 8
  %v2513 = load i64, ptr %slot55, align 8
  store i64 %v2513, ptr %slot347, align 8
  %v2514 = load i64, ptr %slot346, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  %ld2516 = load i64, ptr %p2515, align 8
  store i64 %ld2516, ptr %slot348, align 8
  %v2517 = load i64, ptr %slot348, align 8
  %v2518 = load i64, ptr %slot345, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  store i64 %v2517, ptr %p2519, align 8, !alias.scope !3, !noalias !4
  %v2520 = load i64, ptr %slot345, align 8
  %p2521 = inttoptr i64 %v2520 to ptr
  %ld2522 = load i64, ptr %p2521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2522, ptr %slot349, align 8
  %v2523 = load i64, ptr %slot349, align 8
  %v2524 = load i64, ptr %slot36, align 8
  %p2525 = inttoptr i64 %v2524 to ptr
  store i64 %v2523, ptr %p2525, align 8, !alias.scope !3, !noalias !4
  br label %bb_i16
bb_i15:
  %v2526 = load i64, ptr %slot36, align 8
  %p2527 = inttoptr i64 %v2526 to ptr
  %ld2528 = load i64, ptr %p2527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2528, ptr %slot350, align 8
  %v2529 = load i64, ptr %slot12, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %ld2531 = load i32, ptr %p2530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2531, ptr %slot351, align 8
  %v2532 = load i32, ptr %slot351, align 8
  %cv2533 = zext i32 %v2532 to i64
  %cond2534 = icmp ne i64 %cv2533, 0
  br i1 %cond2534, label %bb_rcslotdrop393, label %bb_rcslotdone393
bb_rcslotdrop393:
  %v2535 = load i64, ptr %slot12, align 8
  %p2536 = inttoptr i64 %v2535 to ptr
  store i32 0, ptr %p2536, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone393
bb_rcslotdone393:
  %v2537 = load i64, ptr %slot10, align 8
  %p2538 = inttoptr i64 %v2537 to ptr
  %ld2539 = load i32, ptr %p2538, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2539, ptr %slot352, align 8
  %v2540 = load i32, ptr %slot352, align 8
  %cv2541 = zext i32 %v2540 to i64
  %cond2542 = icmp ne i64 %cv2541, 0
  br i1 %cond2542, label %bb_rcslotdrop396, label %bb_rcslotdone396
bb_rcslotdrop396:
  %v2543 = load i64, ptr %slot10, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  store i32 0, ptr %p2544, align 4, !alias.scope !3, !noalias !4
  %v2545 = load i64, ptr %slot35, align 8
  store i64 %v2545, ptr %slot353, align 8
  %v2546 = load i64, ptr %slot11, align 8
  %p2547 = inttoptr i64 %v2546 to ptr
  %ld2548 = load i32, ptr %p2547, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2548, ptr %slot354, align 8
  %v2549 = load i32, ptr %slot354, align 8
  %op2550 = and i32 %v2549, 28
  store i32 %op2550, ptr %slot355, align 8
  %v2551 = load i32, ptr %slot355, align 8
  %cv2552 = zext i32 %v2551 to i64
  %cond2553 = icmp ne i64 %cv2552, 0
  br i1 %cond2553, label %bb_rcslotrole396, label %bb_rcslotowner396
bb_rcslotrole396:
  %v2554 = load i64, ptr %slot54, align 8
  store i64 %v2554, ptr %slot356, align 8
  %v2555 = load i64, ptr %slot356, align 8
  %v2556 = load i64, ptr %slot353, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2555, i64 %v2556) nomerge, !dbg !126
  br label %bb_rcslotdone396
bb_rcslotowner396:
  %v2557 = load i64, ptr %slot54, align 8
  store i64 %v2557, ptr %slot357, align 8
  %v2558 = load i64, ptr %slot357, align 8
  %v2559 = load i64, ptr %slot353, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2558, i64 %v2559) nomerge, !dbg !126
  br label %bb_rcslotdone396
bb_rcslotdone396:
  %v2560 = load i64, ptr %slot8, align 8
  %p2561 = inttoptr i64 %v2560 to ptr
  %ld2562 = load i32, ptr %p2561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2562, ptr %slot358, align 8
  %v2563 = load i32, ptr %slot358, align 8
  %cv2564 = zext i32 %v2563 to i64
  %cond2565 = icmp ne i64 %cv2564, 0
  br i1 %cond2565, label %bb_rcslotdrop405, label %bb_rcslotdone405
bb_rcslotdrop405:
  %v2566 = load i64, ptr %slot8, align 8
  %p2567 = inttoptr i64 %v2566 to ptr
  store i32 0, ptr %p2567, align 4, !alias.scope !3, !noalias !4
  %v2568 = load i64, ptr %slot33, align 8
  store i64 %v2568, ptr %slot359, align 8
  %v2569 = load i64, ptr %slot9, align 8
  %p2570 = inttoptr i64 %v2569 to ptr
  %ld2571 = load i32, ptr %p2570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2571, ptr %slot360, align 8
  %v2572 = load i32, ptr %slot360, align 8
  %op2573 = and i32 %v2572, 28
  store i32 %op2573, ptr %slot361, align 8
  %v2574 = load i32, ptr %slot361, align 8
  %cv2575 = zext i32 %v2574 to i64
  %cond2576 = icmp ne i64 %cv2575, 0
  br i1 %cond2576, label %bb_rcslotrole405, label %bb_rcslotowner405
bb_rcslotrole405:
  %v2577 = load i64, ptr %slot54, align 8
  store i64 %v2577, ptr %slot362, align 8
  %v2578 = load i64, ptr %slot359, align 8
  %p2579 = inttoptr i64 %v2578 to ptr
  %ld2580 = load i64, ptr %p2579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2580, ptr %slot363, align 8
  %v2581 = load i64, ptr %slot363, align 8
  %cmp2582 = icmp ne i64 %v2581, 0
  %cv2583 = zext i1 %cmp2582 to i32
  store i32 %cv2583, ptr %slot364, align 8
  %v2584 = load i32, ptr %slot364, align 8
  %cv2585 = zext i32 %v2584 to i64
  %cond2586 = icmp ne i64 %cv2585, 0
  br i1 %cond2586, label %bb_rcgnn421, label %bb_rcgdone421
bb_rcgnn421:
  %v2587 = load i64, ptr %slot363, align 8
  %op2588 = sub i64 %v2587, 16
  store i64 %op2588, ptr %slot365, align 8
  %v2589 = load i64, ptr %slot363, align 8
  %p2590 = inttoptr i64 %v2589 to ptr
  %rgep2591 = getelementptr i8, ptr %p2590, i64 -16
  %ld2592 = load i64, ptr %rgep2591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2592, ptr %slot366, align 8
  %v2593 = load i64, ptr %slot366, align 8
  %op2594 = and i64 %v2593, 4611686018427387906
  store i64 %op2594, ptr %slot367, align 8
  %v2595 = load i64, ptr %slot367, align 8
  %cmp2596 = icmp ne i64 %v2595, 0
  %cv2597 = zext i1 %cmp2596 to i32
  store i32 %cv2597, ptr %slot368, align 8
  %v2598 = load i32, ptr %slot368, align 8
  %cv2599 = zext i32 %v2598 to i64
  %cond2600 = icmp ne i64 %cv2599, 0
  br i1 %cond2600, label %bb_rcgclear421, label %bb_rcgcounted421
bb_rcgcounted421:
  %v2601 = load i64, ptr %slot363, align 8
  %op2602 = sub i64 %v2601, 24
  store i64 %op2602, ptr %slot369, align 8
  %v2603 = load i64, ptr %slot363, align 8
  %p2604 = inttoptr i64 %v2603 to ptr
  %rgep2605 = getelementptr i8, ptr %p2604, i64 -24
  %ld2606 = load i64, ptr %rgep2605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2606, ptr %slot370, align 8
  %v2607 = load i64, ptr %slot370, align 8
  %op2608 = sub i64 %v2607, 1
  store i64 %op2608, ptr %slot371, align 8
  %v2609 = load i64, ptr %slot371, align 8
  %cmp2610 = icmp eq i64 %v2609, 0
  %cv2611 = zext i1 %cmp2610 to i32
  store i32 %cv2611, ptr %slot372, align 8
  %v2612 = load i32, ptr %slot372, align 8
  %cv2613 = zext i32 %v2612 to i64
  %cond2614 = icmp ne i64 %cv2613, 0
  br i1 %cond2614, label %bb_rcglast421, label %bb_rcgdec421
bb_rcglast421:
  %v2615 = load i64, ptr %slot363, align 8
  %op2616 = sub i64 %v2615, 32
  store i64 %op2616, ptr %slot373, align 8
  %v2617 = load i64, ptr %slot363, align 8
  %p2618 = inttoptr i64 %v2617 to ptr
  %rgep2619 = getelementptr i8, ptr %p2618, i64 -32
  %ld2620 = load i64, ptr %rgep2619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2620, ptr %slot374, align 8
  %v2621 = load i64, ptr %slot374, align 8
  %cmp2622 = icmp ne i64 %v2621, 0
  %cv2623 = zext i1 %cmp2622 to i32
  store i32 %cv2623, ptr %slot375, align 8
  %v2624 = load i32, ptr %slot375, align 8
  %cv2625 = zext i32 %v2624 to i64
  %cond2626 = icmp ne i64 %cv2625, 0
  br i1 %cond2626, label %bb_rcgdec421, label %bb_rcgslow421
bb_rcgslow421:
  %v2627 = load i64, ptr %slot362, align 8
  %v2628 = load i64, ptr %slot359, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2627, i64 %v2628) nomerge, !dbg !126
  br label %bb_rcgdone421
bb_rcgdec421:
  %v2629 = load i64, ptr %slot371, align 8
  %v2630 = load i64, ptr %slot363, align 8
  %p2631 = inttoptr i64 %v2630 to ptr
  %rgep2632 = getelementptr i8, ptr %p2631, i64 -24
  store i64 %v2629, ptr %rgep2632, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear421
bb_rcgclear421:
  %v2633 = load i64, ptr %slot359, align 8
  %p2634 = inttoptr i64 %v2633 to ptr
  store i64 0, ptr %p2634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone421
bb_rcgdone421:
  br label %bb_rcslotdone405
bb_rcslotowner405:
  %v2635 = load i64, ptr %slot54, align 8
  store i64 %v2635, ptr %slot376, align 8
  %v2636 = load i64, ptr %slot359, align 8
  %p2637 = inttoptr i64 %v2636 to ptr
  %ld2638 = load i64, ptr %p2637, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2638, ptr %slot377, align 8
  %v2639 = load i64, ptr %slot377, align 8
  %cmp2640 = icmp ne i64 %v2639, 0
  %cv2641 = zext i1 %cmp2640 to i32
  store i32 %cv2641, ptr %slot378, align 8
  %v2642 = load i32, ptr %slot378, align 8
  %cv2643 = zext i32 %v2642 to i64
  %cond2644 = icmp ne i64 %cv2643, 0
  br i1 %cond2644, label %bb_rcgnn436, label %bb_rcgdone436
bb_rcgnn436:
  %v2645 = load i64, ptr %slot377, align 8
  %op2646 = sub i64 %v2645, 16
  store i64 %op2646, ptr %slot379, align 8
  %v2647 = load i64, ptr %slot377, align 8
  %p2648 = inttoptr i64 %v2647 to ptr
  %rgep2649 = getelementptr i8, ptr %p2648, i64 -16
  %ld2650 = load i64, ptr %rgep2649, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2650, ptr %slot380, align 8
  %v2651 = load i64, ptr %slot380, align 8
  %op2652 = and i64 %v2651, 4611686018427387906
  store i64 %op2652, ptr %slot381, align 8
  %v2653 = load i64, ptr %slot381, align 8
  %cmp2654 = icmp ne i64 %v2653, 0
  %cv2655 = zext i1 %cmp2654 to i32
  store i32 %cv2655, ptr %slot382, align 8
  %v2656 = load i32, ptr %slot382, align 8
  %cv2657 = zext i32 %v2656 to i64
  %cond2658 = icmp ne i64 %cv2657, 0
  br i1 %cond2658, label %bb_rcgclear436, label %bb_rcgcounted436
bb_rcgcounted436:
  %v2659 = load i64, ptr %slot377, align 8
  %op2660 = sub i64 %v2659, 32
  store i64 %op2660, ptr %slot383, align 8
  %v2661 = load i64, ptr %slot377, align 8
  %p2662 = inttoptr i64 %v2661 to ptr
  %rgep2663 = getelementptr i8, ptr %p2662, i64 -32
  %ld2664 = load i64, ptr %rgep2663, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2664, ptr %slot384, align 8
  %v2665 = load i64, ptr %slot384, align 8
  %op2666 = sub i64 %v2665, 1
  store i64 %op2666, ptr %slot385, align 8
  %v2667 = load i64, ptr %slot385, align 8
  %cmp2668 = icmp eq i64 %v2667, 0
  %cv2669 = zext i1 %cmp2668 to i32
  store i32 %cv2669, ptr %slot386, align 8
  %v2670 = load i32, ptr %slot386, align 8
  %cv2671 = zext i32 %v2670 to i64
  %cond2672 = icmp ne i64 %cv2671, 0
  br i1 %cond2672, label %bb_rcglast436, label %bb_rcgdec436
bb_rcglast436:
  %v2673 = load i64, ptr %slot377, align 8
  %op2674 = sub i64 %v2673, 24
  store i64 %op2674, ptr %slot387, align 8
  %v2675 = load i64, ptr %slot377, align 8
  %p2676 = inttoptr i64 %v2675 to ptr
  %rgep2677 = getelementptr i8, ptr %p2676, i64 -24
  %ld2678 = load i64, ptr %rgep2677, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2678, ptr %slot388, align 8
  %v2679 = load i64, ptr %slot388, align 8
  %cmp2680 = icmp ne i64 %v2679, 0
  %cv2681 = zext i1 %cmp2680 to i32
  store i32 %cv2681, ptr %slot389, align 8
  %v2682 = load i32, ptr %slot389, align 8
  %cv2683 = zext i32 %v2682 to i64
  %cond2684 = icmp ne i64 %cv2683, 0
  br i1 %cond2684, label %bb_rcgdec436, label %bb_rcgslow436
bb_rcgslow436:
  %v2685 = load i64, ptr %slot376, align 8
  %v2686 = load i64, ptr %slot359, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2685, i64 %v2686) nomerge, !dbg !126
  br label %bb_rcgdone436
bb_rcgdec436:
  %v2687 = load i64, ptr %slot385, align 8
  %v2688 = load i64, ptr %slot377, align 8
  %p2689 = inttoptr i64 %v2688 to ptr
  %rgep2690 = getelementptr i8, ptr %p2689, i64 -32
  store i64 %v2687, ptr %rgep2690, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear436
bb_rcgclear436:
  %v2691 = load i64, ptr %slot359, align 8
  %p2692 = inttoptr i64 %v2691 to ptr
  store i64 0, ptr %p2692, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone436
bb_rcgdone436:
  br label %bb_rcslotdone405
bb_rcslotdone405:
  %v2693 = load i64, ptr %slot6, align 8
  %p2694 = inttoptr i64 %v2693 to ptr
  %ld2695 = load i32, ptr %p2694, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2695, ptr %slot390, align 8
  %v2696 = load i32, ptr %slot390, align 8
  %cv2697 = zext i32 %v2696 to i64
  %cond2698 = icmp ne i64 %cv2697, 0
  br i1 %cond2698, label %bb_rcslotdrop442, label %bb_rcslotdone442
bb_rcslotdrop442:
  %v2699 = load i64, ptr %slot6, align 8
  %p2700 = inttoptr i64 %v2699 to ptr
  store i32 0, ptr %p2700, align 4, !alias.scope !3, !noalias !4
  %v2701 = load i64, ptr %slot32, align 8
  store i64 %v2701, ptr %slot391, align 8
  %v2702 = load i64, ptr %slot7, align 8
  %p2703 = inttoptr i64 %v2702 to ptr
  %ld2704 = load i32, ptr %p2703, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2704, ptr %slot392, align 8
  %v2705 = load i32, ptr %slot392, align 8
  %op2706 = and i32 %v2705, 28
  store i32 %op2706, ptr %slot393, align 8
  %v2707 = load i32, ptr %slot393, align 8
  %cv2708 = zext i32 %v2707 to i64
  %cond2709 = icmp ne i64 %cv2708, 0
  br i1 %cond2709, label %bb_rcslotrole442, label %bb_rcslotowner442
bb_rcslotrole442:
  %v2710 = load i64, ptr %slot54, align 8
  store i64 %v2710, ptr %slot394, align 8
  %v2711 = load i64, ptr %slot391, align 8
  %p2712 = inttoptr i64 %v2711 to ptr
  %ld2713 = load i64, ptr %p2712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2713, ptr %slot395, align 8
  %v2714 = load i64, ptr %slot395, align 8
  %cmp2715 = icmp ne i64 %v2714, 0
  %cv2716 = zext i1 %cmp2715 to i32
  store i32 %cv2716, ptr %slot396, align 8
  %v2717 = load i32, ptr %slot396, align 8
  %cv2718 = zext i32 %v2717 to i64
  %cond2719 = icmp ne i64 %cv2718, 0
  br i1 %cond2719, label %bb_rcgnn458, label %bb_rcgdone458
bb_rcgnn458:
  %v2720 = load i64, ptr %slot395, align 8
  %op2721 = sub i64 %v2720, 16
  store i64 %op2721, ptr %slot397, align 8
  %v2722 = load i64, ptr %slot395, align 8
  %p2723 = inttoptr i64 %v2722 to ptr
  %rgep2724 = getelementptr i8, ptr %p2723, i64 -16
  %ld2725 = load i64, ptr %rgep2724, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2725, ptr %slot398, align 8
  %v2726 = load i64, ptr %slot398, align 8
  %op2727 = and i64 %v2726, 4611686018427387906
  store i64 %op2727, ptr %slot399, align 8
  %v2728 = load i64, ptr %slot399, align 8
  %cmp2729 = icmp ne i64 %v2728, 0
  %cv2730 = zext i1 %cmp2729 to i32
  store i32 %cv2730, ptr %slot400, align 8
  %v2731 = load i32, ptr %slot400, align 8
  %cv2732 = zext i32 %v2731 to i64
  %cond2733 = icmp ne i64 %cv2732, 0
  br i1 %cond2733, label %bb_rcgclear458, label %bb_rcgcounted458
bb_rcgcounted458:
  %v2734 = load i64, ptr %slot395, align 8
  %op2735 = sub i64 %v2734, 24
  store i64 %op2735, ptr %slot401, align 8
  %v2736 = load i64, ptr %slot395, align 8
  %p2737 = inttoptr i64 %v2736 to ptr
  %rgep2738 = getelementptr i8, ptr %p2737, i64 -24
  %ld2739 = load i64, ptr %rgep2738, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2739, ptr %slot402, align 8
  %v2740 = load i64, ptr %slot402, align 8
  %op2741 = sub i64 %v2740, 1
  store i64 %op2741, ptr %slot403, align 8
  %v2742 = load i64, ptr %slot403, align 8
  %cmp2743 = icmp eq i64 %v2742, 0
  %cv2744 = zext i1 %cmp2743 to i32
  store i32 %cv2744, ptr %slot404, align 8
  %v2745 = load i32, ptr %slot404, align 8
  %cv2746 = zext i32 %v2745 to i64
  %cond2747 = icmp ne i64 %cv2746, 0
  br i1 %cond2747, label %bb_rcglast458, label %bb_rcgdec458
bb_rcglast458:
  %v2748 = load i64, ptr %slot395, align 8
  %op2749 = sub i64 %v2748, 32
  store i64 %op2749, ptr %slot405, align 8
  %v2750 = load i64, ptr %slot395, align 8
  %p2751 = inttoptr i64 %v2750 to ptr
  %rgep2752 = getelementptr i8, ptr %p2751, i64 -32
  %ld2753 = load i64, ptr %rgep2752, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2753, ptr %slot406, align 8
  %v2754 = load i64, ptr %slot406, align 8
  %cmp2755 = icmp ne i64 %v2754, 0
  %cv2756 = zext i1 %cmp2755 to i32
  store i32 %cv2756, ptr %slot407, align 8
  %v2757 = load i32, ptr %slot407, align 8
  %cv2758 = zext i32 %v2757 to i64
  %cond2759 = icmp ne i64 %cv2758, 0
  br i1 %cond2759, label %bb_rcgdec458, label %bb_rcgslow458
bb_rcgslow458:
  %v2760 = load i64, ptr %slot394, align 8
  %v2761 = load i64, ptr %slot391, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v2760, i64 %v2761) nomerge, !dbg !126
  br label %bb_rcgdone458
bb_rcgdec458:
  %v2762 = load i64, ptr %slot403, align 8
  %v2763 = load i64, ptr %slot395, align 8
  %p2764 = inttoptr i64 %v2763 to ptr
  %rgep2765 = getelementptr i8, ptr %p2764, i64 -24
  store i64 %v2762, ptr %rgep2765, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear458
bb_rcgclear458:
  %v2766 = load i64, ptr %slot391, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  store i64 0, ptr %p2767, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone458
bb_rcgdone458:
  br label %bb_rcslotdone442
bb_rcslotowner442:
  %v2768 = load i64, ptr %slot54, align 8
  store i64 %v2768, ptr %slot408, align 8
  %v2769 = load i64, ptr %slot391, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  %ld2771 = load i64, ptr %p2770, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2771, ptr %slot409, align 8
  %v2772 = load i64, ptr %slot409, align 8
  %cmp2773 = icmp ne i64 %v2772, 0
  %cv2774 = zext i1 %cmp2773 to i32
  store i32 %cv2774, ptr %slot410, align 8
  %v2775 = load i32, ptr %slot410, align 8
  %cv2776 = zext i32 %v2775 to i64
  %cond2777 = icmp ne i64 %cv2776, 0
  br i1 %cond2777, label %bb_rcgnn473, label %bb_rcgdone473
bb_rcgnn473:
  %v2778 = load i64, ptr %slot409, align 8
  %op2779 = sub i64 %v2778, 16
  store i64 %op2779, ptr %slot411, align 8
  %v2780 = load i64, ptr %slot409, align 8
  %p2781 = inttoptr i64 %v2780 to ptr
  %rgep2782 = getelementptr i8, ptr %p2781, i64 -16
  %ld2783 = load i64, ptr %rgep2782, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2783, ptr %slot412, align 8
  %v2784 = load i64, ptr %slot412, align 8
  %op2785 = and i64 %v2784, 4611686018427387906
  store i64 %op2785, ptr %slot413, align 8
  %v2786 = load i64, ptr %slot413, align 8
  %cmp2787 = icmp ne i64 %v2786, 0
  %cv2788 = zext i1 %cmp2787 to i32
  store i32 %cv2788, ptr %slot414, align 8
  %v2789 = load i32, ptr %slot414, align 8
  %cv2790 = zext i32 %v2789 to i64
  %cond2791 = icmp ne i64 %cv2790, 0
  br i1 %cond2791, label %bb_rcgclear473, label %bb_rcgcounted473
bb_rcgcounted473:
  %v2792 = load i64, ptr %slot409, align 8
  %op2793 = sub i64 %v2792, 32
  store i64 %op2793, ptr %slot415, align 8
  %v2794 = load i64, ptr %slot409, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  %rgep2796 = getelementptr i8, ptr %p2795, i64 -32
  %ld2797 = load i64, ptr %rgep2796, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2797, ptr %slot416, align 8
  %v2798 = load i64, ptr %slot416, align 8
  %op2799 = sub i64 %v2798, 1
  store i64 %op2799, ptr %slot417, align 8
  %v2800 = load i64, ptr %slot417, align 8
  %cmp2801 = icmp eq i64 %v2800, 0
  %cv2802 = zext i1 %cmp2801 to i32
  store i32 %cv2802, ptr %slot418, align 8
  %v2803 = load i32, ptr %slot418, align 8
  %cv2804 = zext i32 %v2803 to i64
  %cond2805 = icmp ne i64 %cv2804, 0
  br i1 %cond2805, label %bb_rcglast473, label %bb_rcgdec473
bb_rcglast473:
  %v2806 = load i64, ptr %slot409, align 8
  %op2807 = sub i64 %v2806, 24
  store i64 %op2807, ptr %slot419, align 8
  %v2808 = load i64, ptr %slot409, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  %rgep2810 = getelementptr i8, ptr %p2809, i64 -24
  %ld2811 = load i64, ptr %rgep2810, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2811, ptr %slot420, align 8
  %v2812 = load i64, ptr %slot420, align 8
  %cmp2813 = icmp ne i64 %v2812, 0
  %cv2814 = zext i1 %cmp2813 to i32
  store i32 %cv2814, ptr %slot421, align 8
  %v2815 = load i32, ptr %slot421, align 8
  %cv2816 = zext i32 %v2815 to i64
  %cond2817 = icmp ne i64 %cv2816, 0
  br i1 %cond2817, label %bb_rcgdec473, label %bb_rcgslow473
bb_rcgslow473:
  %v2818 = load i64, ptr %slot408, align 8
  %v2819 = load i64, ptr %slot391, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v2818, i64 %v2819) nomerge, !dbg !126
  br label %bb_rcgdone473
bb_rcgdec473:
  %v2820 = load i64, ptr %slot417, align 8
  %v2821 = load i64, ptr %slot409, align 8
  %p2822 = inttoptr i64 %v2821 to ptr
  %rgep2823 = getelementptr i8, ptr %p2822, i64 -32
  store i64 %v2820, ptr %rgep2823, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear473
bb_rcgclear473:
  %v2824 = load i64, ptr %slot391, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  store i64 0, ptr %p2825, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone473
bb_rcgdone473:
  br label %bb_rcslotdone442
bb_rcslotdone442:
  %v2826 = load i64, ptr %slot350, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  %ret2828 = load { i64, i64 }, ptr %p2827, align 8
  ret { i64, i64 } %ret2828
bb_i16:
  %v2829 = load i64, ptr %slot33, align 8
  store i64 %v2829, ptr %slot422, align 8
  %v2830 = load i64, ptr %slot9, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  store i32 2, ptr %p2831, align 4, !alias.scope !3, !noalias !4
  %v2832 = load i64, ptr %slot422, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  %ld2834 = load i64, ptr %p2833, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2834, ptr %slot423, align 8
  %v2835 = load i64, ptr %slot423, align 8
  %cmp2836 = icmp ne i64 %v2835, 0
  %cv2837 = zext i1 %cmp2836 to i32
  store i32 %cv2837, ptr %slot424, align 8
  %v2838 = load i32, ptr %slot424, align 8
  %cv2839 = zext i32 %v2838 to i64
  %cond2840 = icmp ne i64 %cv2839, 0
  br i1 %cond2840, label %bb_rcguniquenn489, label %bb_rcgunique489
bb_rcguniquenn489:
  %v2841 = load i64, ptr %slot423, align 8
  %op2842 = sub i64 %v2841, 16
  store i64 %op2842, ptr %slot425, align 8
  %v2843 = load i64, ptr %slot423, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  %rgep2845 = getelementptr i8, ptr %p2844, i64 -16
  %ld2846 = load i64, ptr %rgep2845, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2846, ptr %slot426, align 8
  %v2847 = load i64, ptr %slot426, align 8
  %op2848 = and i64 %v2847, 6917529027641081858
  store i64 %op2848, ptr %slot427, align 8
  %v2849 = load i64, ptr %slot427, align 8
  %cmp2850 = icmp ne i64 %v2849, 0
  %cv2851 = zext i1 %cmp2850 to i32
  store i32 %cv2851, ptr %slot428, align 8
  %v2852 = load i32, ptr %slot428, align 8
  %cv2853 = zext i32 %v2852 to i64
  %cond2854 = icmp ne i64 %cv2853, 0
  br i1 %cond2854, label %bb_rcguniqueslow489, label %bb_rcguniquecount489
bb_rcguniquecount489:
  %v2855 = load i64, ptr %slot423, align 8
  %op2856 = sub i64 %v2855, 32
  store i64 %op2856, ptr %slot429, align 8
  %v2857 = load i64, ptr %slot423, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  %rgep2859 = getelementptr i8, ptr %p2858, i64 -32
  %ld2860 = load i64, ptr %rgep2859, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2860, ptr %slot430, align 8
  %v2861 = load i64, ptr %slot430, align 8
  %cmp2862 = icmp ult i64 %v2861, 2
  %cv2863 = zext i1 %cmp2862 to i32
  store i32 %cv2863, ptr %slot431, align 8
  %v2864 = load i32, ptr %slot431, align 8
  %cv2865 = zext i32 %v2864 to i64
  %cond2866 = icmp ne i64 %cv2865, 0
  br i1 %cond2866, label %bb_rcgunique489, label %bb_rcguniqueslow489
bb_rcguniqueslow489:
  %v2867 = load i64, ptr %slot1, align 8
  %p2868 = inttoptr i64 %v2867 to ptr
  %p2869 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v2870 = load i64, ptr %slot422, align 8
  %p2871 = inttoptr i64 %v2870 to ptr
  %v2872 = load i64, ptr %slot8, align 8
  %p2873 = inttoptr i64 %v2872 to ptr
  %call2874 = call i32 @myl_qbe_rc_unique_local(ptr %p2868, ptr %p2869, ptr %p2871, ptr %p2873) nomerge, !dbg !128
  store i32 %call2874, ptr %slot432, align 8
  %v2875 = load i32, ptr %slot432, align 8
  %cv2876 = zext i32 %v2875 to i64
  %cond2877 = icmp ne i64 %cv2876, 0
  br i1 %cond2877, label %bb_rcunique500, label %bb_failure
bb_rcunique500:
  br label %bb_rcgunique489
bb_rcgunique489:
  %v2878 = load i64, ptr %slot33, align 8
  %p2879 = inttoptr i64 %v2878 to ptr
  %ld2880 = load i64, ptr %p2879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2880, ptr %slot433, align 8
  %v2881 = load i64, ptr %slot36, align 8
  store i64 %v2881, ptr %slot434, align 8
  %v2882 = load i64, ptr %slot434, align 8
  %p2883 = inttoptr i64 %v2882 to ptr
  %ld2884 = load i64, ptr %p2883, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2884, ptr %slot435, align 8
  %v2885 = load i64, ptr %slot433, align 8
  %op2886 = add i64 %v2885, 0
  store i64 %op2886, ptr %slot436, align 8
  %v2887 = load i64, ptr %slot436, align 8
  %p2888 = inttoptr i64 %v2887 to ptr
  %ld2889 = load i64, ptr %p2888, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2889, ptr %slot437, align 8
  %v2890 = load i64, ptr %slot433, align 8
  %op2891 = add i64 %v2890, 8
  store i64 %op2891, ptr %slot438, align 8
  %v2892 = load i64, ptr %slot438, align 8
  %p2893 = inttoptr i64 %v2892 to ptr
  %ld2894 = load i64, ptr %p2893, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2894, ptr %slot439, align 8
  %v2895 = load i64, ptr %slot433, align 8
  %op2896 = add i64 %v2895, 16
  store i64 %op2896, ptr %slot440, align 8
  %v2897 = load i64, ptr %slot440, align 8
  %p2898 = inttoptr i64 %v2897 to ptr
  %ld2899 = load i64, ptr %p2898, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2899, ptr %slot441, align 8
  %v2900 = load i64, ptr %slot437, align 8
  %v2901 = load i64, ptr %slot439, align 8
  %cmp2902 = icmp ult i64 %v2900, %v2901
  %cv2903 = zext i1 %cmp2902 to i32
  store i32 %cv2903, ptr %slot442, align 8
  %v2904 = load i64, ptr %slot441, align 8
  %cmp2905 = icmp ne i64 %v2904, 18446744073709551615
  %cv2906 = zext i1 %cmp2905 to i32
  store i32 %cv2906, ptr %slot443, align 8
  %v2907 = load i32, ptr %slot442, align 8
  %v2908 = load i32, ptr %slot443, align 8
  %op2909 = and i32 %v2907, %v2908
  store i32 %op2909, ptr %slot444, align 8
  %v2910 = load i32, ptr %slot444, align 8
  %cv2911 = zext i32 %v2910 to i64
  %cond2912 = icmp ne i64 %cv2911, 0
  br i1 %cond2912, label %bb_rcappend_check505, label %bb_rcappend_slow505
bb_rcappend_check505:
  %v2913 = load i64, ptr %slot54, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  %v2915 = load i64, ptr %slot433, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %call2917 = call i32 @myl_rc_list_plain_ready(ptr %p2914, ptr %p2916) nomerge, !dbg !128
  store i32 %call2917, ptr %slot445, align 8
  %v2918 = load i32, ptr %slot445, align 8
  %cv2919 = zext i32 %v2918 to i64
  %cond2920 = icmp ne i64 %cv2919, 0
  br i1 %cond2920, label %bb_rcappend_fast505, label %bb_rcappend_slow505
bb_rcappend_slow505:
  %v2921 = load i64, ptr %slot434, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  %ld2923 = load i64, ptr %p2922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2923, ptr %slot446, align 8
  %v2924 = load i64, ptr %slot446, align 8
  %v2925 = load i64, ptr %slot29, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  store i64 %v2924, ptr %p2926, align 8, !alias.scope !3, !noalias !4
  %v2927 = load i64, ptr %slot29, align 8
  store i64 %v2927, ptr %slot447, align 8
  %v2928 = load i64, ptr %slot54, align 8
  %p2929 = inttoptr i64 %v2928 to ptr
  %v2930 = load i64, ptr %slot433, align 8
  %p2931 = inttoptr i64 %v2930 to ptr
  %v2932 = load i64, ptr %slot447, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  %call2934 = call i32 @myl_rc_list_append(ptr %p2929, ptr %p2931, ptr %p2933) nomerge, !dbg !128
  store i32 %call2934, ptr %slot448, align 8
  %v2935 = load i32, ptr %slot448, align 8
  %cv2936 = zext i32 %v2935 to i64
  %cond2937 = icmp ne i64 %cv2936, 0
  br i1 %cond2937, label %bb_success518, label %bb_failed518
bb_failed518:
  %v2938 = load i64, ptr %slot1, align 8
  %p2939 = inttoptr i64 %v2938 to ptr
  call void @myl_qbe_fail_allocation(ptr %p2939) nomerge, !dbg !128
  unreachable
bb_success518:
  br label %bb_rcappend_done505
bb_rcappend_fast505:
  %v2940 = load i64, ptr %slot433, align 8
  %op2941 = add i64 %v2940, 32
  store i64 %op2941, ptr %slot449, align 8
  %v2942 = load i64, ptr %slot449, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  %ld2944 = load i64, ptr %p2943, align 8, !alias.scope !6, !noalias !7
  store i64 %ld2944, ptr %slot450, align 8
  %v2945 = load i64, ptr %slot437, align 8
  %op2946 = mul i64 %v2945, 8
  store i64 %op2946, ptr %slot451, align 8
  %v2947 = load i64, ptr %slot450, align 8
  %v2948 = load i64, ptr %slot451, align 8
  %op2949 = add i64 %v2947, %v2948
  store i64 %op2949, ptr %slot452, align 8
  %v2950 = load i64, ptr %slot435, align 8
  %v2951 = load i64, ptr %slot450, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %v2953 = load i64, ptr %slot451, align 8
  %egep2954 = getelementptr i8, ptr %p2952, i64 %v2953
  store i64 %v2950, ptr %egep2954, align 8, !alias.scope !12, !noalias !13
  %v2955 = load i64, ptr %slot433, align 8
  %op2956 = add i64 %v2955, 0
  store i64 %op2956, ptr %slot453, align 8
  %v2957 = load i64, ptr %slot437, align 8
  %op2958 = add i64 %v2957, 1
  store i64 %op2958, ptr %slot454, align 8
  %v2959 = load i64, ptr %slot454, align 8
  %v2960 = load i64, ptr %slot453, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  store i64 %v2959, ptr %p2961, align 8, !alias.scope !6, !noalias !7
  %v2962 = load i64, ptr %slot433, align 8
  %op2963 = add i64 %v2962, 16
  store i64 %op2963, ptr %slot455, align 8
  %v2964 = load i64, ptr %slot441, align 8
  %op2965 = add i64 %v2964, 1
  store i64 %op2965, ptr %slot456, align 8
  %v2966 = load i64, ptr %slot456, align 8
  %v2967 = load i64, ptr %slot455, align 8
  %p2968 = inttoptr i64 %v2967 to ptr
  store i64 %v2966, ptr %p2968, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done505
bb_rcappend_done505:
  %v2969 = load i64, ptr %slot36, align 8
  %p2970 = inttoptr i64 %v2969 to ptr
  store i64 0, ptr %p2970, align 8, !alias.scope !3, !noalias !4
  br label %bb_i18
bb_i18:
  %v2971 = load i64, ptr %slot30, align 8
  %p2972 = inttoptr i64 %v2971 to ptr
  %ld2973 = load i64, ptr %p2972, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2973, ptr %slot457, align 8
  %v2974 = load i64, ptr %slot457, align 8
  %v2975 = load i64, ptr %slot36, align 8
  %p2976 = inttoptr i64 %v2975 to ptr
  store i64 %v2974, ptr %p2976, align 8, !alias.scope !3, !noalias !4
  %v2977 = load i64, ptr %slot42, align 8
  store i64 %v2977, ptr %slot458, align 8
  %v2978 = load i64, ptr %slot458, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  store i32 0, ptr %p2979, align 4, !alias.scope !3, !noalias !4
  %v2980 = load i64, ptr %slot458, align 8
  %p2981 = inttoptr i64 %v2980 to ptr
  store i32 4, ptr %p2981, align 4, !alias.scope !3, !noalias !4
  %v2982 = load i64, ptr %slot458, align 8
  %v2983 = load i64, ptr %slot37, align 8
  %p2984 = inttoptr i64 %v2983 to ptr
  store i64 %v2982, ptr %p2984, align 8, !alias.scope !3, !noalias !4
  %v2985 = load i64, ptr %slot36, align 8
  %p2986 = inttoptr i64 %v2985 to ptr
  %ld2987 = load i64, ptr %p2986, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2987, ptr %slot459, align 8
  %v2988 = load i64, ptr %slot37, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  %ld2990 = load i64, ptr %p2989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2990, ptr %slot460, align 8
  %v2991 = load i64, ptr %slot1, align 8
  %v2992 = load i64, ptr %slot459, align 8
  %v2993 = load i64, ptr %slot460, align 8
  %call2994 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v2991, i64 %v2992, i64 %v2993) nomerge, !dbg !130
  store i64 %call2994, ptr %slot461, align 8
  %v2995 = load i64, ptr %slot461, align 8
  %v2996 = load i64, ptr %slot36, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  store i64 %v2995, ptr %p2997, align 8, !alias.scope !3, !noalias !4
  %v2998 = load i64, ptr %slot12, align 8
  %p2999 = inttoptr i64 %v2998 to ptr
  %ld3000 = load i32, ptr %p2999, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3000, ptr %slot462, align 8
  %v3001 = load i32, ptr %slot462, align 8
  %cv3002 = zext i32 %v3001 to i64
  %cond3003 = icmp ne i64 %cv3002, 0
  br i1 %cond3003, label %bb_rcslotdrop534, label %bb_rcslotdone534
bb_rcslotdrop534:
  %v3004 = load i64, ptr %slot12, align 8
  %p3005 = inttoptr i64 %v3004 to ptr
  store i32 0, ptr %p3005, align 4, !alias.scope !3, !noalias !4
  %v3006 = load i64, ptr %slot22, align 8
  store i64 %v3006, ptr %slot463, align 8
  %v3007 = load i64, ptr %slot13, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  %ld3009 = load i32, ptr %p3008, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3009, ptr %slot464, align 8
  %v3010 = load i32, ptr %slot464, align 8
  %op3011 = and i32 %v3010, 28
  store i32 %op3011, ptr %slot465, align 8
  %v3012 = load i32, ptr %slot465, align 8
  %cv3013 = zext i32 %v3012 to i64
  %cond3014 = icmp ne i64 %cv3013, 0
  br i1 %cond3014, label %bb_rcslotrole534, label %bb_rcslotowner534
bb_rcslotrole534:
  %v3015 = load i64, ptr %slot54, align 8
  store i64 %v3015, ptr %slot466, align 8
  %v3016 = load i64, ptr %slot466, align 8
  %v3017 = load i64, ptr %slot463, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3016, i64 %v3017) nomerge, !dbg !130
  br label %bb_rcslotdone534
bb_rcslotowner534:
  %v3018 = load i64, ptr %slot54, align 8
  store i64 %v3018, ptr %slot467, align 8
  %v3019 = load i64, ptr %slot467, align 8
  %v3020 = load i64, ptr %slot463, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3019, i64 %v3020) nomerge, !dbg !130
  br label %bb_rcslotdone534
bb_rcslotdone534:
  %v3021 = load i64, ptr %slot36, align 8
  %p3022 = inttoptr i64 %v3021 to ptr
  %ld3023 = load i64, ptr %p3022, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3023, ptr %slot468, align 8
  %v3024 = load i64, ptr %slot468, align 8
  %cond3025 = icmp ne i64 %v3024, 0
  br i1 %cond3025, label %bb_next542, label %bb_i43
bb_next542:
  %v3026 = load i64, ptr %slot33, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %ld3028 = load i64, ptr %p3027, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3028, ptr %slot469, align 8
  %v3029 = load i64, ptr %slot469, align 8
  %v3030 = load i64, ptr %slot36, align 8
  %p3031 = inttoptr i64 %v3030 to ptr
  store i64 %v3029, ptr %p3031, align 8, !alias.scope !3, !noalias !4
  %v3032 = load i64, ptr %slot36, align 8
  %p3033 = inttoptr i64 %v3032 to ptr
  %ld3034 = load i64, ptr %p3033, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3034, ptr %slot470, align 8
  %v3035 = load i64, ptr %slot470, align 8
  %v3036 = load i64, ptr %slot34, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  store i64 %v3035, ptr %p3037, align 8, !alias.scope !3, !noalias !4
  %v3038 = load i64, ptr %slot34, align 8
  %p3039 = inttoptr i64 %v3038 to ptr
  %ld3040 = load i64, ptr %p3039, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3040, ptr %slot471, align 8
  %v3041 = load i64, ptr %slot471, align 8
  %op3042 = add i64 %v3041, 0
  store i64 %op3042, ptr %slot472, align 8
  %v3043 = load i64, ptr %slot472, align 8
  %p3044 = inttoptr i64 %v3043 to ptr
  %ld3045 = load i64, ptr %p3044, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3045, ptr %slot473, align 8
  %v3046 = load i64, ptr %slot473, align 8
  %v3047 = load i64, ptr %slot36, align 8
  %p3048 = inttoptr i64 %v3047 to ptr
  store i64 %v3046, ptr %p3048, align 8, !alias.scope !3, !noalias !4
  %v3049 = load i64, ptr %slot36, align 8
  %p3050 = inttoptr i64 %v3049 to ptr
  %ld3051 = load i64, ptr %p3050, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3051, ptr %slot474, align 8
  %v3052 = load i64, ptr %slot474, align 8
  %cmp3053 = icmp ugt i64 %v3052, 9223372036854775807
  %cv3054 = zext i1 %cmp3053 to i64
  store i64 %cv3054, ptr %slot475, align 8
  %v3055 = load i64, ptr %slot475, align 8
  %cond3056 = icmp ne i64 %v3055, 0
  br i1 %cond3056, label %bb_cast_overflow549, label %bb_cast_ok549
bb_cast_overflow549:
  %v3057 = load i64, ptr %slot1, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  %v3059 = load i64, ptr %slot474, align 8
  call void @myl_qbe_fail_cast(ptr %p3058, i64 %v3059, i64 320) nomerge, !dbg !132
  unreachable
bb_cast_ok549:
  %v3060 = load i64, ptr %slot474, align 8
  %v3061 = load i64, ptr %slot36, align 8
  %p3062 = inttoptr i64 %v3061 to ptr
  store i64 %v3060, ptr %p3062, align 8, !alias.scope !3, !noalias !4
  %v3063 = load i64, ptr %slot37, align 8
  %p3064 = inttoptr i64 %v3063 to ptr
  store i64 255, ptr %p3064, align 8, !alias.scope !3, !noalias !4
  %v3065 = load i64, ptr %slot37, align 8
  %p3066 = inttoptr i64 %v3065 to ptr
  %ld3067 = load i64, ptr %p3066, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3067, ptr %slot476, align 8
  %v3068 = load i64, ptr %slot36, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %ld3070 = load i64, ptr %p3069, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3070, ptr %slot477, align 8
  %v3071 = load i64, ptr %slot477, align 8
  %v3072 = load i64, ptr %slot476, align 8
  %cmp3073 = icmp sge i64 %v3071, %v3072
  %cv3074 = zext i1 %cmp3073 to i64
  store i64 %cv3074, ptr %slot478, align 8
  %v3075 = load i64, ptr %slot478, align 8
  %v3076 = load i64, ptr %slot36, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  store i64 %v3075, ptr %p3077, align 8, !alias.scope !3, !noalias !4
  %v3078 = load i64, ptr %slot36, align 8
  %p3079 = inttoptr i64 %v3078 to ptr
  %ld3080 = load i64, ptr %p3079, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3080, ptr %slot479, align 8
  %v3081 = load i64, ptr %slot479, align 8
  %cond3082 = icmp ne i64 %v3081, 0
  br i1 %cond3082, label %bb_next554, label %bb_i35
bb_next554:
  %v3083 = load i64, ptr %slot30, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  %ld3085 = load i64, ptr %p3084, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3085, ptr %slot480, align 8
  %v3086 = load i64, ptr %slot480, align 8
  %v3087 = load i64, ptr %slot36, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  store i64 %v3086, ptr %p3088, align 8, !alias.scope !3, !noalias !4
  %v3089 = load i64, ptr %slot30, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  %ld3091 = load i64, ptr %p3090, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3091, ptr %slot481, align 8
  %v3092 = load i64, ptr %slot481, align 8
  %v3093 = load i64, ptr %slot43, align 8
  %p3094 = inttoptr i64 %v3092 to ptr
  %p3095 = inttoptr i64 %v3093 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3095, ptr %p3094, i64 312, i1 false), !alias.scope !10000000
  %v3096 = load i64, ptr %slot43, align 8
  %v3097 = load i64, ptr %slot37, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  store i64 %v3096, ptr %p3098, align 8, !alias.scope !3, !noalias !4
  %v3099 = load i64, ptr %slot37, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  %ld3101 = load i64, ptr %p3100, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3101, ptr %slot482, align 8
  %v3102 = load i64, ptr %slot1, align 8
  %v3103 = load i64, ptr %slot482, align 8
  call void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8 %callresult484, i64 %v3102, i64 %v3103) nomerge, !dbg !134
  %addr3104 = ptrtoint ptr %callresult484 to i64
  store i64 %addr3104, ptr %slot483, align 8
  %v3105 = load i64, ptr %slot483, align 8
  %v3106 = load i64, ptr %slot37, align 8
  %p3107 = inttoptr i64 %v3106 to ptr
  store i64 %v3105, ptr %p3107, align 8, !alias.scope !3, !noalias !4
  %v3108 = load i64, ptr %slot37, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  %ld3110 = load i64, ptr %p3109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3110, ptr %slot485, align 8
  %v3111 = load i64, ptr %slot28, align 8
  store i64 %v3111, ptr %slot486, align 8
  %v3112 = load i64, ptr %slot54, align 8
  %v3113 = load i64, ptr %slot486, align 8
  %v3114 = load i64, ptr %slot485, align 8
  %call3115 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v3112, i64 %v3113, i64 %v3114) nomerge, !dbg !134
  store i32 %call3115, ptr %slot487, align 8
  %v3116 = load i32, ptr %slot487, align 8
  %cv3117 = zext i32 %v3116 to i64
  %cond3118 = icmp ne i64 %cv3117, 0
  br i1 %cond3118, label %bb_rcsuccess561, label %bb_rcfailure561
bb_rcfailure561:
  %v3119 = load i64, ptr %slot54, align 8
  %p3120 = inttoptr i64 %v3119 to ptr
  %call3121 = call i32 @myl_rc_take_failure(ptr %p3120) nomerge, !dbg !134
  store i32 %call3121, ptr %slot488, align 8
  %v3122 = load i64, ptr %slot1, align 8
  %p3123 = inttoptr i64 %v3122 to ptr
  %v3124 = load i32, ptr %slot488, align 8
  %call3125 = call i32 @myl_qbe_rc_status(ptr %p3123, i32 %v3124) nomerge, !dbg !134
  store i32 %call3125, ptr %slot489, align 8
  br label %bb_failure
bb_rcsuccess561:
  %v3126 = load i64, ptr %slot20, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  store i32 2, ptr %p3127, align 4, !alias.scope !3, !noalias !4
  %v3128 = load i64, ptr %slot20, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  store i32 16, ptr %p3129, align 4, !alias.scope !3, !noalias !4
  %v3130 = load i64, ptr %slot19, align 8
  %p3131 = inttoptr i64 %v3130 to ptr
  store i32 1, ptr %p3131, align 4, !alias.scope !3, !noalias !4
  %v3132 = load i64, ptr %slot14, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  %ld3134 = load i32, ptr %p3133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3134, ptr %slot490, align 8
  %v3135 = load i32, ptr %slot490, align 8
  %cv3136 = zext i32 %v3135 to i64
  %cond3137 = icmp ne i64 %cv3136, 0
  br i1 %cond3137, label %bb_rcslotdrop569, label %bb_rcslotdone569
bb_rcslotdrop569:
  %v3138 = load i64, ptr %slot14, align 8
  %p3139 = inttoptr i64 %v3138 to ptr
  store i32 0, ptr %p3139, align 4, !alias.scope !3, !noalias !4
  %v3140 = load i64, ptr %slot23, align 8
  store i64 %v3140, ptr %slot491, align 8
  %v3141 = load i64, ptr %slot15, align 8
  %p3142 = inttoptr i64 %v3141 to ptr
  %ld3143 = load i32, ptr %p3142, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3143, ptr %slot492, align 8
  %v3144 = load i32, ptr %slot492, align 8
  %op3145 = and i32 %v3144, 28
  store i32 %op3145, ptr %slot493, align 8
  %v3146 = load i32, ptr %slot493, align 8
  %cv3147 = zext i32 %v3146 to i64
  %cond3148 = icmp ne i64 %cv3147, 0
  br i1 %cond3148, label %bb_rcslotrole569, label %bb_rcslotowner569
bb_rcslotrole569:
  %v3149 = load i64, ptr %slot54, align 8
  store i64 %v3149, ptr %slot494, align 8
  %v3150 = load i64, ptr %slot494, align 8
  %v3151 = load i64, ptr %slot491, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3150, i64 %v3151) nomerge, !dbg !134
  br label %bb_rcslotdone569
bb_rcslotowner569:
  %v3152 = load i64, ptr %slot54, align 8
  store i64 %v3152, ptr %slot495, align 8
  %v3153 = load i64, ptr %slot495, align 8
  %v3154 = load i64, ptr %slot491, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3153, i64 %v3154) nomerge, !dbg !134
  br label %bb_rcslotdone569
bb_rcslotdone569:
  %v3155 = load i64, ptr %slot23, align 8
  store i64 %v3155, ptr %slot496, align 8
  %v3156 = load i64, ptr %slot28, align 8
  store i64 %v3156, ptr %slot497, align 8
  %v3157 = load i64, ptr %slot497, align 8
  %v3158 = load i64, ptr %slot496, align 8
  %p3159 = inttoptr i64 %v3157 to ptr
  %p3160 = inttoptr i64 %v3158 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3160, ptr %p3159, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3161 = load i64, ptr %slot15, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  store i32 2, ptr %p3162, align 4, !alias.scope !3, !noalias !4
  %v3163 = load i64, ptr %slot20, align 8
  %p3164 = inttoptr i64 %v3163 to ptr
  %ld3165 = load i32, ptr %p3164, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3165, ptr %slot498, align 8
  %v3166 = load i32, ptr %slot498, align 8
  %v3167 = load i64, ptr %slot15, align 8
  %p3168 = inttoptr i64 %v3167 to ptr
  store i32 %v3166, ptr %p3168, align 4, !alias.scope !3, !noalias !4
  %v3169 = load i64, ptr %slot19, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  store i32 0, ptr %p3170, align 4, !alias.scope !3, !noalias !4
  %v3171 = load i64, ptr %slot14, align 8
  %p3172 = inttoptr i64 %v3171 to ptr
  store i32 1, ptr %p3172, align 4, !alias.scope !3, !noalias !4
  %v3173 = load i64, ptr %slot496, align 8
  %v3174 = load i64, ptr %slot37, align 8
  %p3175 = inttoptr i64 %v3174 to ptr
  store i64 %v3173, ptr %p3175, align 8, !alias.scope !3, !noalias !4
  %p3176 = inttoptr i64 ptrtoint (ptr @myl_lit_a2fef6855234220d4efe69d6d206ee3c11f5b0c2ac2ff07411d432d186d8f508 to i64) to ptr
  %ld3177 = load i64, ptr %p3176, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3177, ptr %slot499, align 8
  %v3178 = load i64, ptr %slot499, align 8
  %v3179 = load i64, ptr %slot38, align 8
  %p3180 = inttoptr i64 %v3179 to ptr
  store i64 %v3178, ptr %p3180, align 8, !alias.scope !3, !noalias !4
  %v3181 = load i64, ptr %slot38, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  %ld3183 = load i64, ptr %p3182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3183, ptr %slot500, align 8
  %v3184 = load i64, ptr %slot500, align 8
  %v3185 = load i64, ptr %slot26, align 8
  %p3186 = inttoptr i64 %v3185 to ptr
  store i64 %v3184, ptr %p3186, align 8, !alias.scope !3, !noalias !4
  %v3187 = load i64, ptr %slot26, align 8
  store i64 %v3187, ptr %slot501, align 8
  %v3188 = load i64, ptr %slot28, align 8
  store i64 %v3188, ptr %slot502, align 8
  %v3189 = load i64, ptr %slot501, align 8
  %v3190 = load i64, ptr %slot502, align 8
  %p3191 = inttoptr i64 %v3189 to ptr
  %p3192 = inttoptr i64 %v3190 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3192, ptr %p3191, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3193 = load i64, ptr %slot20, align 8
  %p3194 = inttoptr i64 %v3193 to ptr
  store i32 2, ptr %p3194, align 4, !alias.scope !3, !noalias !4
  %v3195 = load i64, ptr %slot19, align 8
  %p3196 = inttoptr i64 %v3195 to ptr
  store i32 1, ptr %p3196, align 4, !alias.scope !3, !noalias !4
  %v3197 = load i64, ptr %slot24, align 8
  store i64 %v3197, ptr %slot503, align 8
  %v3198 = load i64, ptr %slot28, align 8
  store i64 %v3198, ptr %slot504, align 8
  %v3199 = load i64, ptr %slot504, align 8
  %v3200 = load i64, ptr %slot503, align 8
  %p3201 = inttoptr i64 %v3199 to ptr
  %p3202 = inttoptr i64 %v3200 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3202, ptr %p3201, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3203 = load i64, ptr %slot17, align 8
  %p3204 = inttoptr i64 %v3203 to ptr
  store i32 2, ptr %p3204, align 4, !alias.scope !3, !noalias !4
  %v3205 = load i64, ptr %slot20, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  %ld3207 = load i32, ptr %p3206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3207, ptr %slot505, align 8
  %v3208 = load i32, ptr %slot505, align 8
  %v3209 = load i64, ptr %slot17, align 8
  %p3210 = inttoptr i64 %v3209 to ptr
  store i32 %v3208, ptr %p3210, align 4, !alias.scope !3, !noalias !4
  %v3211 = load i64, ptr %slot19, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  store i32 0, ptr %p3212, align 4, !alias.scope !3, !noalias !4
  %v3213 = load i64, ptr %slot16, align 8
  %p3214 = inttoptr i64 %v3213 to ptr
  store i32 1, ptr %p3214, align 4, !alias.scope !3, !noalias !4
  %v3215 = load i64, ptr %slot503, align 8
  %p3216 = inttoptr i64 %v3215 to ptr
  %ld3217 = load i64, ptr %p3216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3217, ptr %slot506, align 8
  %v3218 = load i64, ptr %slot506, align 8
  %v3219 = load i64, ptr %slot38, align 8
  %p3220 = inttoptr i64 %v3219 to ptr
  store i64 %v3218, ptr %p3220, align 8, !alias.scope !3, !noalias !4
  %v3221 = load i64, ptr %slot36, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  %ld3223 = load i64, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3223, ptr %slot507, align 8
  %v3224 = load i64, ptr %slot37, align 8
  %p3225 = inttoptr i64 %v3224 to ptr
  %ld3226 = load i64, ptr %p3225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3226, ptr %slot508, align 8
  %v3227 = load i64, ptr %slot38, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  %ld3229 = load i64, ptr %p3228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3229, ptr %slot509, align 8
  %v3230 = load i64, ptr %slot1, align 8
  %v3231 = load i64, ptr %slot507, align 8
  %v3232 = load i64, ptr %slot508, align 8
  %v3233 = load i64, ptr %slot509, align 8
  %call3234 = call i8 @myl_f_7a515a62bcf2d52dbd1a003508cbad18b835f8a05891010b6b797b5f49fa312f(i64 %v3230, i64 %v3231, i64 %v3232, i64 %v3233) nomerge, !dbg !136
  store i8 %call3234, ptr %callresult511, align 1
  %addr3235 = ptrtoint ptr %callresult511 to i64
  store i64 %addr3235, ptr %slot510, align 8
  %v3236 = load i64, ptr %slot510, align 8
  %v3237 = load i64, ptr %slot36, align 8
  %p3238 = inttoptr i64 %v3237 to ptr
  store i64 %v3236, ptr %p3238, align 8, !alias.scope !3, !noalias !4
  %v3239 = load i64, ptr %slot12, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  %ld3241 = load i32, ptr %p3240, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3241, ptr %slot512, align 8
  %v3242 = load i32, ptr %slot512, align 8
  %cv3243 = zext i32 %v3242 to i64
  %cond3244 = icmp ne i64 %cv3243, 0
  br i1 %cond3244, label %bb_rcslotdrop606, label %bb_rcslotdone606
bb_rcslotdrop606:
  %v3245 = load i64, ptr %slot12, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  store i32 0, ptr %p3246, align 4, !alias.scope !3, !noalias !4
  %v3247 = load i64, ptr %slot22, align 8
  store i64 %v3247, ptr %slot513, align 8
  %v3248 = load i64, ptr %slot13, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %ld3250 = load i32, ptr %p3249, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3250, ptr %slot514, align 8
  %v3251 = load i32, ptr %slot514, align 8
  %op3252 = and i32 %v3251, 28
  store i32 %op3252, ptr %slot515, align 8
  %v3253 = load i32, ptr %slot515, align 8
  %cv3254 = zext i32 %v3253 to i64
  %cond3255 = icmp ne i64 %cv3254, 0
  br i1 %cond3255, label %bb_rcslotrole606, label %bb_rcslotowner606
bb_rcslotrole606:
  %v3256 = load i64, ptr %slot54, align 8
  store i64 %v3256, ptr %slot516, align 8
  %v3257 = load i64, ptr %slot516, align 8
  %v3258 = load i64, ptr %slot513, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3257, i64 %v3258) nomerge, !dbg !136
  br label %bb_rcslotdone606
bb_rcslotowner606:
  %v3259 = load i64, ptr %slot54, align 8
  store i64 %v3259, ptr %slot517, align 8
  %v3260 = load i64, ptr %slot517, align 8
  %v3261 = load i64, ptr %slot513, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3260, i64 %v3261) nomerge, !dbg !136
  br label %bb_rcslotdone606
bb_rcslotdone606:
  %v3262 = load i64, ptr %slot14, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  %ld3264 = load i32, ptr %p3263, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3264, ptr %slot518, align 8
  %v3265 = load i32, ptr %slot518, align 8
  %cv3266 = zext i32 %v3265 to i64
  %cond3267 = icmp ne i64 %cv3266, 0
  br i1 %cond3267, label %bb_rcslotdrop615, label %bb_rcslotdone615
bb_rcslotdrop615:
  %v3268 = load i64, ptr %slot14, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  store i32 0, ptr %p3269, align 4, !alias.scope !3, !noalias !4
  %v3270 = load i64, ptr %slot23, align 8
  store i64 %v3270, ptr %slot519, align 8
  %v3271 = load i64, ptr %slot15, align 8
  %p3272 = inttoptr i64 %v3271 to ptr
  %ld3273 = load i32, ptr %p3272, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3273, ptr %slot520, align 8
  %v3274 = load i32, ptr %slot520, align 8
  %op3275 = and i32 %v3274, 28
  store i32 %op3275, ptr %slot521, align 8
  %v3276 = load i32, ptr %slot521, align 8
  %cv3277 = zext i32 %v3276 to i64
  %cond3278 = icmp ne i64 %cv3277, 0
  br i1 %cond3278, label %bb_rcslotrole615, label %bb_rcslotowner615
bb_rcslotrole615:
  %v3279 = load i64, ptr %slot54, align 8
  store i64 %v3279, ptr %slot522, align 8
  %v3280 = load i64, ptr %slot522, align 8
  %v3281 = load i64, ptr %slot519, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3280, i64 %v3281) nomerge, !dbg !136
  br label %bb_rcslotdone615
bb_rcslotowner615:
  %v3282 = load i64, ptr %slot54, align 8
  store i64 %v3282, ptr %slot523, align 8
  %v3283 = load i64, ptr %slot523, align 8
  %v3284 = load i64, ptr %slot519, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3283, i64 %v3284) nomerge, !dbg !136
  br label %bb_rcslotdone615
bb_rcslotdone615:
  %v3285 = load i64, ptr %slot16, align 8
  %p3286 = inttoptr i64 %v3285 to ptr
  %ld3287 = load i32, ptr %p3286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3287, ptr %slot524, align 8
  %v3288 = load i32, ptr %slot524, align 8
  %cv3289 = zext i32 %v3288 to i64
  %cond3290 = icmp ne i64 %cv3289, 0
  br i1 %cond3290, label %bb_rcslotdrop624, label %bb_rcslotdone624
bb_rcslotdrop624:
  %v3291 = load i64, ptr %slot16, align 8
  %p3292 = inttoptr i64 %v3291 to ptr
  store i32 0, ptr %p3292, align 4, !alias.scope !3, !noalias !4
  %v3293 = load i64, ptr %slot24, align 8
  store i64 %v3293, ptr %slot525, align 8
  %v3294 = load i64, ptr %slot17, align 8
  %p3295 = inttoptr i64 %v3294 to ptr
  %ld3296 = load i32, ptr %p3295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3296, ptr %slot526, align 8
  %v3297 = load i32, ptr %slot526, align 8
  %op3298 = and i32 %v3297, 28
  store i32 %op3298, ptr %slot527, align 8
  %v3299 = load i32, ptr %slot527, align 8
  %cv3300 = zext i32 %v3299 to i64
  %cond3301 = icmp ne i64 %cv3300, 0
  br i1 %cond3301, label %bb_rcslotrole624, label %bb_rcslotowner624
bb_rcslotrole624:
  %v3302 = load i64, ptr %slot54, align 8
  store i64 %v3302, ptr %slot528, align 8
  %v3303 = load i64, ptr %slot525, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  %ld3305 = load i64, ptr %p3304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3305, ptr %slot529, align 8
  %v3306 = load i64, ptr %slot529, align 8
  %cmp3307 = icmp ne i64 %v3306, 0
  %cv3308 = zext i1 %cmp3307 to i32
  store i32 %cv3308, ptr %slot530, align 8
  %v3309 = load i32, ptr %slot530, align 8
  %cv3310 = zext i32 %v3309 to i64
  %cond3311 = icmp ne i64 %cv3310, 0
  br i1 %cond3311, label %bb_rcgnn640, label %bb_rcgdone640
bb_rcgnn640:
  %v3312 = load i64, ptr %slot529, align 8
  %op3313 = sub i64 %v3312, 16
  store i64 %op3313, ptr %slot531, align 8
  %v3314 = load i64, ptr %slot529, align 8
  %p3315 = inttoptr i64 %v3314 to ptr
  %rgep3316 = getelementptr i8, ptr %p3315, i64 -16
  %ld3317 = load i64, ptr %rgep3316, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3317, ptr %slot532, align 8
  %v3318 = load i64, ptr %slot532, align 8
  %op3319 = and i64 %v3318, 4611686018427387906
  store i64 %op3319, ptr %slot533, align 8
  %v3320 = load i64, ptr %slot533, align 8
  %cmp3321 = icmp ne i64 %v3320, 0
  %cv3322 = zext i1 %cmp3321 to i32
  store i32 %cv3322, ptr %slot534, align 8
  %v3323 = load i32, ptr %slot534, align 8
  %cv3324 = zext i32 %v3323 to i64
  %cond3325 = icmp ne i64 %cv3324, 0
  br i1 %cond3325, label %bb_rcgclear640, label %bb_rcgcounted640
bb_rcgcounted640:
  %v3326 = load i64, ptr %slot529, align 8
  %op3327 = sub i64 %v3326, 24
  store i64 %op3327, ptr %slot535, align 8
  %v3328 = load i64, ptr %slot529, align 8
  %p3329 = inttoptr i64 %v3328 to ptr
  %rgep3330 = getelementptr i8, ptr %p3329, i64 -24
  %ld3331 = load i64, ptr %rgep3330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3331, ptr %slot536, align 8
  %v3332 = load i64, ptr %slot536, align 8
  %op3333 = sub i64 %v3332, 1
  store i64 %op3333, ptr %slot537, align 8
  %v3334 = load i64, ptr %slot537, align 8
  %cmp3335 = icmp eq i64 %v3334, 0
  %cv3336 = zext i1 %cmp3335 to i32
  store i32 %cv3336, ptr %slot538, align 8
  %v3337 = load i32, ptr %slot538, align 8
  %cv3338 = zext i32 %v3337 to i64
  %cond3339 = icmp ne i64 %cv3338, 0
  br i1 %cond3339, label %bb_rcglast640, label %bb_rcgdec640
bb_rcglast640:
  %v3340 = load i64, ptr %slot529, align 8
  %op3341 = sub i64 %v3340, 32
  store i64 %op3341, ptr %slot539, align 8
  %v3342 = load i64, ptr %slot529, align 8
  %p3343 = inttoptr i64 %v3342 to ptr
  %rgep3344 = getelementptr i8, ptr %p3343, i64 -32
  %ld3345 = load i64, ptr %rgep3344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3345, ptr %slot540, align 8
  %v3346 = load i64, ptr %slot540, align 8
  %cmp3347 = icmp ne i64 %v3346, 0
  %cv3348 = zext i1 %cmp3347 to i32
  store i32 %cv3348, ptr %slot541, align 8
  %v3349 = load i32, ptr %slot541, align 8
  %cv3350 = zext i32 %v3349 to i64
  %cond3351 = icmp ne i64 %cv3350, 0
  br i1 %cond3351, label %bb_rcgdec640, label %bb_rcgslow640
bb_rcgslow640:
  %v3352 = load i64, ptr %slot528, align 8
  %v3353 = load i64, ptr %slot525, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3352, i64 %v3353) nomerge, !dbg !136
  br label %bb_rcgdone640
bb_rcgdec640:
  %v3354 = load i64, ptr %slot537, align 8
  %v3355 = load i64, ptr %slot529, align 8
  %p3356 = inttoptr i64 %v3355 to ptr
  %rgep3357 = getelementptr i8, ptr %p3356, i64 -24
  store i64 %v3354, ptr %rgep3357, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear640
bb_rcgclear640:
  %v3358 = load i64, ptr %slot525, align 8
  %p3359 = inttoptr i64 %v3358 to ptr
  store i64 0, ptr %p3359, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone640
bb_rcgdone640:
  br label %bb_rcslotdone624
bb_rcslotowner624:
  %v3360 = load i64, ptr %slot54, align 8
  store i64 %v3360, ptr %slot542, align 8
  %v3361 = load i64, ptr %slot525, align 8
  %p3362 = inttoptr i64 %v3361 to ptr
  %ld3363 = load i64, ptr %p3362, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3363, ptr %slot543, align 8
  %v3364 = load i64, ptr %slot543, align 8
  %cmp3365 = icmp ne i64 %v3364, 0
  %cv3366 = zext i1 %cmp3365 to i32
  store i32 %cv3366, ptr %slot544, align 8
  %v3367 = load i32, ptr %slot544, align 8
  %cv3368 = zext i32 %v3367 to i64
  %cond3369 = icmp ne i64 %cv3368, 0
  br i1 %cond3369, label %bb_rcgnn655, label %bb_rcgdone655
bb_rcgnn655:
  %v3370 = load i64, ptr %slot543, align 8
  %op3371 = sub i64 %v3370, 16
  store i64 %op3371, ptr %slot545, align 8
  %v3372 = load i64, ptr %slot543, align 8
  %p3373 = inttoptr i64 %v3372 to ptr
  %rgep3374 = getelementptr i8, ptr %p3373, i64 -16
  %ld3375 = load i64, ptr %rgep3374, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3375, ptr %slot546, align 8
  %v3376 = load i64, ptr %slot546, align 8
  %op3377 = and i64 %v3376, 4611686018427387906
  store i64 %op3377, ptr %slot547, align 8
  %v3378 = load i64, ptr %slot547, align 8
  %cmp3379 = icmp ne i64 %v3378, 0
  %cv3380 = zext i1 %cmp3379 to i32
  store i32 %cv3380, ptr %slot548, align 8
  %v3381 = load i32, ptr %slot548, align 8
  %cv3382 = zext i32 %v3381 to i64
  %cond3383 = icmp ne i64 %cv3382, 0
  br i1 %cond3383, label %bb_rcgclear655, label %bb_rcgcounted655
bb_rcgcounted655:
  %v3384 = load i64, ptr %slot543, align 8
  %op3385 = sub i64 %v3384, 32
  store i64 %op3385, ptr %slot549, align 8
  %v3386 = load i64, ptr %slot543, align 8
  %p3387 = inttoptr i64 %v3386 to ptr
  %rgep3388 = getelementptr i8, ptr %p3387, i64 -32
  %ld3389 = load i64, ptr %rgep3388, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3389, ptr %slot550, align 8
  %v3390 = load i64, ptr %slot550, align 8
  %op3391 = sub i64 %v3390, 1
  store i64 %op3391, ptr %slot551, align 8
  %v3392 = load i64, ptr %slot551, align 8
  %cmp3393 = icmp eq i64 %v3392, 0
  %cv3394 = zext i1 %cmp3393 to i32
  store i32 %cv3394, ptr %slot552, align 8
  %v3395 = load i32, ptr %slot552, align 8
  %cv3396 = zext i32 %v3395 to i64
  %cond3397 = icmp ne i64 %cv3396, 0
  br i1 %cond3397, label %bb_rcglast655, label %bb_rcgdec655
bb_rcglast655:
  %v3398 = load i64, ptr %slot543, align 8
  %op3399 = sub i64 %v3398, 24
  store i64 %op3399, ptr %slot553, align 8
  %v3400 = load i64, ptr %slot543, align 8
  %p3401 = inttoptr i64 %v3400 to ptr
  %rgep3402 = getelementptr i8, ptr %p3401, i64 -24
  %ld3403 = load i64, ptr %rgep3402, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3403, ptr %slot554, align 8
  %v3404 = load i64, ptr %slot554, align 8
  %cmp3405 = icmp ne i64 %v3404, 0
  %cv3406 = zext i1 %cmp3405 to i32
  store i32 %cv3406, ptr %slot555, align 8
  %v3407 = load i32, ptr %slot555, align 8
  %cv3408 = zext i32 %v3407 to i64
  %cond3409 = icmp ne i64 %cv3408, 0
  br i1 %cond3409, label %bb_rcgdec655, label %bb_rcgslow655
bb_rcgslow655:
  %v3410 = load i64, ptr %slot542, align 8
  %v3411 = load i64, ptr %slot525, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3410, i64 %v3411) nomerge, !dbg !136
  br label %bb_rcgdone655
bb_rcgdec655:
  %v3412 = load i64, ptr %slot551, align 8
  %v3413 = load i64, ptr %slot543, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  %rgep3415 = getelementptr i8, ptr %p3414, i64 -32
  store i64 %v3412, ptr %rgep3415, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear655
bb_rcgclear655:
  %v3416 = load i64, ptr %slot525, align 8
  %p3417 = inttoptr i64 %v3416 to ptr
  store i64 0, ptr %p3417, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone655
bb_rcgdone655:
  br label %bb_rcslotdone624
bb_rcslotdone624:
  br label %bb_i35
bb_i35:
  %v3418 = load i64, ptr %slot30, align 8
  %p3419 = inttoptr i64 %v3418 to ptr
  %ld3420 = load i64, ptr %p3419, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3420, ptr %slot556, align 8
  %v3421 = load i64, ptr %slot556, align 8
  %v3422 = load i64, ptr %slot36, align 8
  %p3423 = inttoptr i64 %v3422 to ptr
  store i64 %v3421, ptr %p3423, align 8, !alias.scope !3, !noalias !4
  %v3424 = load i64, ptr %slot36, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  %ld3426 = load i64, ptr %p3425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3426, ptr %slot557, align 8
  %v3427 = load i64, ptr %slot1, align 8
  %v3428 = load i64, ptr %slot557, align 8
  %call3429 = call { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64 %v3427, i64 %v3428) nomerge, !dbg !138
  store { i64, i64 } %call3429, ptr %callresult559, align 8
  %addr3430 = ptrtoint ptr %callresult559 to i64
  store i64 %addr3430, ptr %slot558, align 8
  %v3431 = load i64, ptr %slot558, align 8
  %v3432 = load i64, ptr %slot36, align 8
  %p3433 = inttoptr i64 %v3432 to ptr
  store i64 %v3431, ptr %p3433, align 8, !alias.scope !3, !noalias !4
  %v3434 = load i64, ptr %slot12, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  %ld3436 = load i32, ptr %p3435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3436, ptr %slot560, align 8
  %v3437 = load i32, ptr %slot560, align 8
  %cv3438 = zext i32 %v3437 to i64
  %cond3439 = icmp ne i64 %cv3438, 0
  br i1 %cond3439, label %bb_rcslotdrop664, label %bb_rcslotdone664
bb_rcslotdrop664:
  %v3440 = load i64, ptr %slot12, align 8
  %p3441 = inttoptr i64 %v3440 to ptr
  store i32 0, ptr %p3441, align 4, !alias.scope !3, !noalias !4
  %v3442 = load i64, ptr %slot22, align 8
  store i64 %v3442, ptr %slot561, align 8
  %v3443 = load i64, ptr %slot13, align 8
  %p3444 = inttoptr i64 %v3443 to ptr
  %ld3445 = load i32, ptr %p3444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3445, ptr %slot562, align 8
  %v3446 = load i32, ptr %slot562, align 8
  %op3447 = and i32 %v3446, 28
  store i32 %op3447, ptr %slot563, align 8
  %v3448 = load i32, ptr %slot563, align 8
  %cv3449 = zext i32 %v3448 to i64
  %cond3450 = icmp ne i64 %cv3449, 0
  br i1 %cond3450, label %bb_rcslotrole664, label %bb_rcslotowner664
bb_rcslotrole664:
  %v3451 = load i64, ptr %slot54, align 8
  store i64 %v3451, ptr %slot564, align 8
  %v3452 = load i64, ptr %slot564, align 8
  %v3453 = load i64, ptr %slot561, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3452, i64 %v3453) nomerge, !dbg !138
  br label %bb_rcslotdone664
bb_rcslotowner664:
  %v3454 = load i64, ptr %slot54, align 8
  store i64 %v3454, ptr %slot565, align 8
  %v3455 = load i64, ptr %slot565, align 8
  %v3456 = load i64, ptr %slot561, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3455, i64 %v3456) nomerge, !dbg !138
  br label %bb_rcslotdone664
bb_rcslotdone664:
  %v3457 = load i64, ptr %slot36, align 8
  %p3458 = inttoptr i64 %v3457 to ptr
  %ld3459 = load i64, ptr %p3458, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3459, ptr %slot566, align 8
  %v3460 = load i64, ptr %slot566, align 8
  %p3461 = inttoptr i64 %v3460 to ptr
  %ld3462 = load i32, ptr %p3461, align 4
  %ext3463 = zext i32 %ld3462 to i64
  store i64 %ext3463, ptr %slot567, align 8
  %v3464 = load i64, ptr %slot567, align 8
  %cmp3465 = icmp eq i64 %v3464, 0
  %cv3466 = zext i1 %cmp3465 to i64
  store i64 %cv3466, ptr %slot568, align 8
  %v3467 = load i64, ptr %slot568, align 8
  %cond3468 = icmp ne i64 %v3467, 0
  br i1 %cond3468, label %bb_rctryok672, label %bb_rctryerror672
bb_rctryerror672:
  %p3469 = inttoptr i64 ptrtoint (ptr @myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p3469, i64 12884901925) "call-inline-cost"="0", !dbg !140
  %v3470 = load i64, ptr %slot566, align 8
  %op3471 = add i64 %v3470, 8
  store i64 %op3471, ptr %slot569, align 8
  %v3472 = load i64, ptr %slot44, align 8
  store i64 %v3472, ptr %slot570, align 8
  %v3473 = load i64, ptr %slot570, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  store i64 0, ptr %p3474, align 8, !alias.scope !3, !noalias !4
  %v3475 = load i64, ptr %slot570, align 8
  %p3477 = inttoptr i64 %v3475 to ptr
  %gep3478 = getelementptr i8, ptr %p3477, i64 8
  %op3476 = ptrtoint ptr %gep3478 to i64
  store i64 %op3476, ptr %slot571, align 8
  %v3479 = load i64, ptr %slot571, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  store i64 0, ptr %p3480, align 8, !alias.scope !3, !noalias !4
  %v3481 = load i64, ptr %slot570, align 8
  %p3482 = inttoptr i64 %v3481 to ptr
  store i32 1, ptr %p3482, align 4, !alias.scope !3, !noalias !4
  %v3483 = load i64, ptr %slot570, align 8
  %p3485 = inttoptr i64 %v3483 to ptr
  %gep3486 = getelementptr i8, ptr %p3485, i64 8
  %op3484 = ptrtoint ptr %gep3486 to i64
  store i64 %op3484, ptr %slot572, align 8
  %v3487 = load i64, ptr %slot21, align 8
  %p3488 = inttoptr i64 %v3487 to ptr
  store i32 1, ptr %p3488, align 4, !alias.scope !3, !noalias !4
  %v3489 = load i64, ptr %slot55, align 8
  store i64 %v3489, ptr %slot573, align 8
  %v3490 = load i64, ptr %slot570, align 8
  %v3491 = load i64, ptr %slot36, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  store i64 %v3490, ptr %p3492, align 8, !alias.scope !3, !noalias !4
  br label %bb_i39
bb_rctryok672:
  %v3493 = load i64, ptr %slot44, align 8
  store i64 %v3493, ptr %slot574, align 8
  %v3494 = load i64, ptr %slot574, align 8
  %p3495 = inttoptr i64 %v3494 to ptr
  store i64 0, ptr %p3495, align 8, !alias.scope !3, !noalias !4
  %v3496 = load i64, ptr %slot21, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  store i32 1, ptr %p3497, align 4, !alias.scope !3, !noalias !4
  %v3498 = load i64, ptr %slot566, align 8
  %op3499 = add i64 %v3498, 8
  store i64 %op3499, ptr %slot575, align 8
  %v3500 = load i64, ptr %slot55, align 8
  store i64 %v3500, ptr %slot576, align 8
  %v3501 = load i64, ptr %slot575, align 8
  %p3502 = inttoptr i64 %v3501 to ptr
  %ld3503 = load i64, ptr %p3502, align 8
  store i64 %ld3503, ptr %slot577, align 8
  %v3504 = load i64, ptr %slot577, align 8
  %v3505 = load i64, ptr %slot574, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  store i64 %v3504, ptr %p3506, align 8, !alias.scope !3, !noalias !4
  %v3507 = load i64, ptr %slot574, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %ld3509 = load i64, ptr %p3508, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3509, ptr %slot578, align 8
  %v3510 = load i64, ptr %slot578, align 8
  %v3511 = load i64, ptr %slot36, align 8
  %p3512 = inttoptr i64 %v3511 to ptr
  store i64 %v3510, ptr %p3512, align 8, !alias.scope !3, !noalias !4
  br label %bb_i40
bb_i39:
  %v3513 = load i64, ptr %slot36, align 8
  %p3514 = inttoptr i64 %v3513 to ptr
  %ld3515 = load i64, ptr %p3514, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3515, ptr %slot579, align 8
  %v3516 = load i64, ptr %slot12, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  %ld3518 = load i32, ptr %p3517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3518, ptr %slot580, align 8
  %v3519 = load i32, ptr %slot580, align 8
  %cv3520 = zext i32 %v3519 to i64
  %cond3521 = icmp ne i64 %cv3520, 0
  br i1 %cond3521, label %bb_rcslotdrop691, label %bb_rcslotdone691
bb_rcslotdrop691:
  %v3522 = load i64, ptr %slot12, align 8
  %p3523 = inttoptr i64 %v3522 to ptr
  store i32 0, ptr %p3523, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone691
bb_rcslotdone691:
  %v3524 = load i64, ptr %slot10, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  %ld3526 = load i32, ptr %p3525, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3526, ptr %slot581, align 8
  %v3527 = load i32, ptr %slot581, align 8
  %cv3528 = zext i32 %v3527 to i64
  %cond3529 = icmp ne i64 %cv3528, 0
  br i1 %cond3529, label %bb_rcslotdrop694, label %bb_rcslotdone694
bb_rcslotdrop694:
  %v3530 = load i64, ptr %slot10, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  store i32 0, ptr %p3531, align 4, !alias.scope !3, !noalias !4
  %v3532 = load i64, ptr %slot35, align 8
  store i64 %v3532, ptr %slot582, align 8
  %v3533 = load i64, ptr %slot11, align 8
  %p3534 = inttoptr i64 %v3533 to ptr
  %ld3535 = load i32, ptr %p3534, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3535, ptr %slot583, align 8
  %v3536 = load i32, ptr %slot583, align 8
  %op3537 = and i32 %v3536, 28
  store i32 %op3537, ptr %slot584, align 8
  %v3538 = load i32, ptr %slot584, align 8
  %cv3539 = zext i32 %v3538 to i64
  %cond3540 = icmp ne i64 %cv3539, 0
  br i1 %cond3540, label %bb_rcslotrole694, label %bb_rcslotowner694
bb_rcslotrole694:
  %v3541 = load i64, ptr %slot54, align 8
  store i64 %v3541, ptr %slot585, align 8
  %v3542 = load i64, ptr %slot585, align 8
  %v3543 = load i64, ptr %slot582, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3542, i64 %v3543) nomerge, !dbg !142
  br label %bb_rcslotdone694
bb_rcslotowner694:
  %v3544 = load i64, ptr %slot54, align 8
  store i64 %v3544, ptr %slot586, align 8
  %v3545 = load i64, ptr %slot586, align 8
  %v3546 = load i64, ptr %slot582, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3545, i64 %v3546) nomerge, !dbg !142
  br label %bb_rcslotdone694
bb_rcslotdone694:
  %v3547 = load i64, ptr %slot8, align 8
  %p3548 = inttoptr i64 %v3547 to ptr
  %ld3549 = load i32, ptr %p3548, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3549, ptr %slot587, align 8
  %v3550 = load i32, ptr %slot587, align 8
  %cv3551 = zext i32 %v3550 to i64
  %cond3552 = icmp ne i64 %cv3551, 0
  br i1 %cond3552, label %bb_rcslotdrop703, label %bb_rcslotdone703
bb_rcslotdrop703:
  %v3553 = load i64, ptr %slot8, align 8
  %p3554 = inttoptr i64 %v3553 to ptr
  store i32 0, ptr %p3554, align 4, !alias.scope !3, !noalias !4
  %v3555 = load i64, ptr %slot33, align 8
  store i64 %v3555, ptr %slot588, align 8
  %v3556 = load i64, ptr %slot9, align 8
  %p3557 = inttoptr i64 %v3556 to ptr
  %ld3558 = load i32, ptr %p3557, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3558, ptr %slot589, align 8
  %v3559 = load i32, ptr %slot589, align 8
  %op3560 = and i32 %v3559, 28
  store i32 %op3560, ptr %slot590, align 8
  %v3561 = load i32, ptr %slot590, align 8
  %cv3562 = zext i32 %v3561 to i64
  %cond3563 = icmp ne i64 %cv3562, 0
  br i1 %cond3563, label %bb_rcslotrole703, label %bb_rcslotowner703
bb_rcslotrole703:
  %v3564 = load i64, ptr %slot54, align 8
  store i64 %v3564, ptr %slot591, align 8
  %v3565 = load i64, ptr %slot588, align 8
  %p3566 = inttoptr i64 %v3565 to ptr
  %ld3567 = load i64, ptr %p3566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3567, ptr %slot592, align 8
  %v3568 = load i64, ptr %slot592, align 8
  %cmp3569 = icmp ne i64 %v3568, 0
  %cv3570 = zext i1 %cmp3569 to i32
  store i32 %cv3570, ptr %slot593, align 8
  %v3571 = load i32, ptr %slot593, align 8
  %cv3572 = zext i32 %v3571 to i64
  %cond3573 = icmp ne i64 %cv3572, 0
  br i1 %cond3573, label %bb_rcgnn719, label %bb_rcgdone719
bb_rcgnn719:
  %v3574 = load i64, ptr %slot592, align 8
  %op3575 = sub i64 %v3574, 16
  store i64 %op3575, ptr %slot594, align 8
  %v3576 = load i64, ptr %slot592, align 8
  %p3577 = inttoptr i64 %v3576 to ptr
  %rgep3578 = getelementptr i8, ptr %p3577, i64 -16
  %ld3579 = load i64, ptr %rgep3578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3579, ptr %slot595, align 8
  %v3580 = load i64, ptr %slot595, align 8
  %op3581 = and i64 %v3580, 4611686018427387906
  store i64 %op3581, ptr %slot596, align 8
  %v3582 = load i64, ptr %slot596, align 8
  %cmp3583 = icmp ne i64 %v3582, 0
  %cv3584 = zext i1 %cmp3583 to i32
  store i32 %cv3584, ptr %slot597, align 8
  %v3585 = load i32, ptr %slot597, align 8
  %cv3586 = zext i32 %v3585 to i64
  %cond3587 = icmp ne i64 %cv3586, 0
  br i1 %cond3587, label %bb_rcgclear719, label %bb_rcgcounted719
bb_rcgcounted719:
  %v3588 = load i64, ptr %slot592, align 8
  %op3589 = sub i64 %v3588, 24
  store i64 %op3589, ptr %slot598, align 8
  %v3590 = load i64, ptr %slot592, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  %rgep3592 = getelementptr i8, ptr %p3591, i64 -24
  %ld3593 = load i64, ptr %rgep3592, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3593, ptr %slot599, align 8
  %v3594 = load i64, ptr %slot599, align 8
  %op3595 = sub i64 %v3594, 1
  store i64 %op3595, ptr %slot600, align 8
  %v3596 = load i64, ptr %slot600, align 8
  %cmp3597 = icmp eq i64 %v3596, 0
  %cv3598 = zext i1 %cmp3597 to i32
  store i32 %cv3598, ptr %slot601, align 8
  %v3599 = load i32, ptr %slot601, align 8
  %cv3600 = zext i32 %v3599 to i64
  %cond3601 = icmp ne i64 %cv3600, 0
  br i1 %cond3601, label %bb_rcglast719, label %bb_rcgdec719
bb_rcglast719:
  %v3602 = load i64, ptr %slot592, align 8
  %op3603 = sub i64 %v3602, 32
  store i64 %op3603, ptr %slot602, align 8
  %v3604 = load i64, ptr %slot592, align 8
  %p3605 = inttoptr i64 %v3604 to ptr
  %rgep3606 = getelementptr i8, ptr %p3605, i64 -32
  %ld3607 = load i64, ptr %rgep3606, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3607, ptr %slot603, align 8
  %v3608 = load i64, ptr %slot603, align 8
  %cmp3609 = icmp ne i64 %v3608, 0
  %cv3610 = zext i1 %cmp3609 to i32
  store i32 %cv3610, ptr %slot604, align 8
  %v3611 = load i32, ptr %slot604, align 8
  %cv3612 = zext i32 %v3611 to i64
  %cond3613 = icmp ne i64 %cv3612, 0
  br i1 %cond3613, label %bb_rcgdec719, label %bb_rcgslow719
bb_rcgslow719:
  %v3614 = load i64, ptr %slot591, align 8
  %v3615 = load i64, ptr %slot588, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3614, i64 %v3615) nomerge, !dbg !142
  br label %bb_rcgdone719
bb_rcgdec719:
  %v3616 = load i64, ptr %slot600, align 8
  %v3617 = load i64, ptr %slot592, align 8
  %p3618 = inttoptr i64 %v3617 to ptr
  %rgep3619 = getelementptr i8, ptr %p3618, i64 -24
  store i64 %v3616, ptr %rgep3619, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear719
bb_rcgclear719:
  %v3620 = load i64, ptr %slot588, align 8
  %p3621 = inttoptr i64 %v3620 to ptr
  store i64 0, ptr %p3621, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone719
bb_rcgdone719:
  br label %bb_rcslotdone703
bb_rcslotowner703:
  %v3622 = load i64, ptr %slot54, align 8
  store i64 %v3622, ptr %slot605, align 8
  %v3623 = load i64, ptr %slot588, align 8
  %p3624 = inttoptr i64 %v3623 to ptr
  %ld3625 = load i64, ptr %p3624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3625, ptr %slot606, align 8
  %v3626 = load i64, ptr %slot606, align 8
  %cmp3627 = icmp ne i64 %v3626, 0
  %cv3628 = zext i1 %cmp3627 to i32
  store i32 %cv3628, ptr %slot607, align 8
  %v3629 = load i32, ptr %slot607, align 8
  %cv3630 = zext i32 %v3629 to i64
  %cond3631 = icmp ne i64 %cv3630, 0
  br i1 %cond3631, label %bb_rcgnn734, label %bb_rcgdone734
bb_rcgnn734:
  %v3632 = load i64, ptr %slot606, align 8
  %op3633 = sub i64 %v3632, 16
  store i64 %op3633, ptr %slot608, align 8
  %v3634 = load i64, ptr %slot606, align 8
  %p3635 = inttoptr i64 %v3634 to ptr
  %rgep3636 = getelementptr i8, ptr %p3635, i64 -16
  %ld3637 = load i64, ptr %rgep3636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3637, ptr %slot609, align 8
  %v3638 = load i64, ptr %slot609, align 8
  %op3639 = and i64 %v3638, 4611686018427387906
  store i64 %op3639, ptr %slot610, align 8
  %v3640 = load i64, ptr %slot610, align 8
  %cmp3641 = icmp ne i64 %v3640, 0
  %cv3642 = zext i1 %cmp3641 to i32
  store i32 %cv3642, ptr %slot611, align 8
  %v3643 = load i32, ptr %slot611, align 8
  %cv3644 = zext i32 %v3643 to i64
  %cond3645 = icmp ne i64 %cv3644, 0
  br i1 %cond3645, label %bb_rcgclear734, label %bb_rcgcounted734
bb_rcgcounted734:
  %v3646 = load i64, ptr %slot606, align 8
  %op3647 = sub i64 %v3646, 32
  store i64 %op3647, ptr %slot612, align 8
  %v3648 = load i64, ptr %slot606, align 8
  %p3649 = inttoptr i64 %v3648 to ptr
  %rgep3650 = getelementptr i8, ptr %p3649, i64 -32
  %ld3651 = load i64, ptr %rgep3650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3651, ptr %slot613, align 8
  %v3652 = load i64, ptr %slot613, align 8
  %op3653 = sub i64 %v3652, 1
  store i64 %op3653, ptr %slot614, align 8
  %v3654 = load i64, ptr %slot614, align 8
  %cmp3655 = icmp eq i64 %v3654, 0
  %cv3656 = zext i1 %cmp3655 to i32
  store i32 %cv3656, ptr %slot615, align 8
  %v3657 = load i32, ptr %slot615, align 8
  %cv3658 = zext i32 %v3657 to i64
  %cond3659 = icmp ne i64 %cv3658, 0
  br i1 %cond3659, label %bb_rcglast734, label %bb_rcgdec734
bb_rcglast734:
  %v3660 = load i64, ptr %slot606, align 8
  %op3661 = sub i64 %v3660, 24
  store i64 %op3661, ptr %slot616, align 8
  %v3662 = load i64, ptr %slot606, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  %rgep3664 = getelementptr i8, ptr %p3663, i64 -24
  %ld3665 = load i64, ptr %rgep3664, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3665, ptr %slot617, align 8
  %v3666 = load i64, ptr %slot617, align 8
  %cmp3667 = icmp ne i64 %v3666, 0
  %cv3668 = zext i1 %cmp3667 to i32
  store i32 %cv3668, ptr %slot618, align 8
  %v3669 = load i32, ptr %slot618, align 8
  %cv3670 = zext i32 %v3669 to i64
  %cond3671 = icmp ne i64 %cv3670, 0
  br i1 %cond3671, label %bb_rcgdec734, label %bb_rcgslow734
bb_rcgslow734:
  %v3672 = load i64, ptr %slot605, align 8
  %v3673 = load i64, ptr %slot588, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3672, i64 %v3673) nomerge, !dbg !142
  br label %bb_rcgdone734
bb_rcgdec734:
  %v3674 = load i64, ptr %slot614, align 8
  %v3675 = load i64, ptr %slot606, align 8
  %p3676 = inttoptr i64 %v3675 to ptr
  %rgep3677 = getelementptr i8, ptr %p3676, i64 -32
  store i64 %v3674, ptr %rgep3677, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear734
bb_rcgclear734:
  %v3678 = load i64, ptr %slot588, align 8
  %p3679 = inttoptr i64 %v3678 to ptr
  store i64 0, ptr %p3679, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone734
bb_rcgdone734:
  br label %bb_rcslotdone703
bb_rcslotdone703:
  %v3680 = load i64, ptr %slot6, align 8
  %p3681 = inttoptr i64 %v3680 to ptr
  %ld3682 = load i32, ptr %p3681, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3682, ptr %slot619, align 8
  %v3683 = load i32, ptr %slot619, align 8
  %cv3684 = zext i32 %v3683 to i64
  %cond3685 = icmp ne i64 %cv3684, 0
  br i1 %cond3685, label %bb_rcslotdrop740, label %bb_rcslotdone740
bb_rcslotdrop740:
  %v3686 = load i64, ptr %slot6, align 8
  %p3687 = inttoptr i64 %v3686 to ptr
  store i32 0, ptr %p3687, align 4, !alias.scope !3, !noalias !4
  %v3688 = load i64, ptr %slot32, align 8
  store i64 %v3688, ptr %slot620, align 8
  %v3689 = load i64, ptr %slot7, align 8
  %p3690 = inttoptr i64 %v3689 to ptr
  %ld3691 = load i32, ptr %p3690, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3691, ptr %slot621, align 8
  %v3692 = load i32, ptr %slot621, align 8
  %op3693 = and i32 %v3692, 28
  store i32 %op3693, ptr %slot622, align 8
  %v3694 = load i32, ptr %slot622, align 8
  %cv3695 = zext i32 %v3694 to i64
  %cond3696 = icmp ne i64 %cv3695, 0
  br i1 %cond3696, label %bb_rcslotrole740, label %bb_rcslotowner740
bb_rcslotrole740:
  %v3697 = load i64, ptr %slot54, align 8
  store i64 %v3697, ptr %slot623, align 8
  %v3698 = load i64, ptr %slot620, align 8
  %p3699 = inttoptr i64 %v3698 to ptr
  %ld3700 = load i64, ptr %p3699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3700, ptr %slot624, align 8
  %v3701 = load i64, ptr %slot624, align 8
  %cmp3702 = icmp ne i64 %v3701, 0
  %cv3703 = zext i1 %cmp3702 to i32
  store i32 %cv3703, ptr %slot625, align 8
  %v3704 = load i32, ptr %slot625, align 8
  %cv3705 = zext i32 %v3704 to i64
  %cond3706 = icmp ne i64 %cv3705, 0
  br i1 %cond3706, label %bb_rcgnn756, label %bb_rcgdone756
bb_rcgnn756:
  %v3707 = load i64, ptr %slot624, align 8
  %op3708 = sub i64 %v3707, 16
  store i64 %op3708, ptr %slot626, align 8
  %v3709 = load i64, ptr %slot624, align 8
  %p3710 = inttoptr i64 %v3709 to ptr
  %rgep3711 = getelementptr i8, ptr %p3710, i64 -16
  %ld3712 = load i64, ptr %rgep3711, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3712, ptr %slot627, align 8
  %v3713 = load i64, ptr %slot627, align 8
  %op3714 = and i64 %v3713, 4611686018427387906
  store i64 %op3714, ptr %slot628, align 8
  %v3715 = load i64, ptr %slot628, align 8
  %cmp3716 = icmp ne i64 %v3715, 0
  %cv3717 = zext i1 %cmp3716 to i32
  store i32 %cv3717, ptr %slot629, align 8
  %v3718 = load i32, ptr %slot629, align 8
  %cv3719 = zext i32 %v3718 to i64
  %cond3720 = icmp ne i64 %cv3719, 0
  br i1 %cond3720, label %bb_rcgclear756, label %bb_rcgcounted756
bb_rcgcounted756:
  %v3721 = load i64, ptr %slot624, align 8
  %op3722 = sub i64 %v3721, 24
  store i64 %op3722, ptr %slot630, align 8
  %v3723 = load i64, ptr %slot624, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %rgep3725 = getelementptr i8, ptr %p3724, i64 -24
  %ld3726 = load i64, ptr %rgep3725, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3726, ptr %slot631, align 8
  %v3727 = load i64, ptr %slot631, align 8
  %op3728 = sub i64 %v3727, 1
  store i64 %op3728, ptr %slot632, align 8
  %v3729 = load i64, ptr %slot632, align 8
  %cmp3730 = icmp eq i64 %v3729, 0
  %cv3731 = zext i1 %cmp3730 to i32
  store i32 %cv3731, ptr %slot633, align 8
  %v3732 = load i32, ptr %slot633, align 8
  %cv3733 = zext i32 %v3732 to i64
  %cond3734 = icmp ne i64 %cv3733, 0
  br i1 %cond3734, label %bb_rcglast756, label %bb_rcgdec756
bb_rcglast756:
  %v3735 = load i64, ptr %slot624, align 8
  %op3736 = sub i64 %v3735, 32
  store i64 %op3736, ptr %slot634, align 8
  %v3737 = load i64, ptr %slot624, align 8
  %p3738 = inttoptr i64 %v3737 to ptr
  %rgep3739 = getelementptr i8, ptr %p3738, i64 -32
  %ld3740 = load i64, ptr %rgep3739, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3740, ptr %slot635, align 8
  %v3741 = load i64, ptr %slot635, align 8
  %cmp3742 = icmp ne i64 %v3741, 0
  %cv3743 = zext i1 %cmp3742 to i32
  store i32 %cv3743, ptr %slot636, align 8
  %v3744 = load i32, ptr %slot636, align 8
  %cv3745 = zext i32 %v3744 to i64
  %cond3746 = icmp ne i64 %cv3745, 0
  br i1 %cond3746, label %bb_rcgdec756, label %bb_rcgslow756
bb_rcgslow756:
  %v3747 = load i64, ptr %slot623, align 8
  %v3748 = load i64, ptr %slot620, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3747, i64 %v3748) nomerge, !dbg !142
  br label %bb_rcgdone756
bb_rcgdec756:
  %v3749 = load i64, ptr %slot632, align 8
  %v3750 = load i64, ptr %slot624, align 8
  %p3751 = inttoptr i64 %v3750 to ptr
  %rgep3752 = getelementptr i8, ptr %p3751, i64 -24
  store i64 %v3749, ptr %rgep3752, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear756
bb_rcgclear756:
  %v3753 = load i64, ptr %slot620, align 8
  %p3754 = inttoptr i64 %v3753 to ptr
  store i64 0, ptr %p3754, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone756
bb_rcgdone756:
  br label %bb_rcslotdone740
bb_rcslotowner740:
  %v3755 = load i64, ptr %slot54, align 8
  store i64 %v3755, ptr %slot637, align 8
  %v3756 = load i64, ptr %slot620, align 8
  %p3757 = inttoptr i64 %v3756 to ptr
  %ld3758 = load i64, ptr %p3757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3758, ptr %slot638, align 8
  %v3759 = load i64, ptr %slot638, align 8
  %cmp3760 = icmp ne i64 %v3759, 0
  %cv3761 = zext i1 %cmp3760 to i32
  store i32 %cv3761, ptr %slot639, align 8
  %v3762 = load i32, ptr %slot639, align 8
  %cv3763 = zext i32 %v3762 to i64
  %cond3764 = icmp ne i64 %cv3763, 0
  br i1 %cond3764, label %bb_rcgnn771, label %bb_rcgdone771
bb_rcgnn771:
  %v3765 = load i64, ptr %slot638, align 8
  %op3766 = sub i64 %v3765, 16
  store i64 %op3766, ptr %slot640, align 8
  %v3767 = load i64, ptr %slot638, align 8
  %p3768 = inttoptr i64 %v3767 to ptr
  %rgep3769 = getelementptr i8, ptr %p3768, i64 -16
  %ld3770 = load i64, ptr %rgep3769, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3770, ptr %slot641, align 8
  %v3771 = load i64, ptr %slot641, align 8
  %op3772 = and i64 %v3771, 4611686018427387906
  store i64 %op3772, ptr %slot642, align 8
  %v3773 = load i64, ptr %slot642, align 8
  %cmp3774 = icmp ne i64 %v3773, 0
  %cv3775 = zext i1 %cmp3774 to i32
  store i32 %cv3775, ptr %slot643, align 8
  %v3776 = load i32, ptr %slot643, align 8
  %cv3777 = zext i32 %v3776 to i64
  %cond3778 = icmp ne i64 %cv3777, 0
  br i1 %cond3778, label %bb_rcgclear771, label %bb_rcgcounted771
bb_rcgcounted771:
  %v3779 = load i64, ptr %slot638, align 8
  %op3780 = sub i64 %v3779, 32
  store i64 %op3780, ptr %slot644, align 8
  %v3781 = load i64, ptr %slot638, align 8
  %p3782 = inttoptr i64 %v3781 to ptr
  %rgep3783 = getelementptr i8, ptr %p3782, i64 -32
  %ld3784 = load i64, ptr %rgep3783, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3784, ptr %slot645, align 8
  %v3785 = load i64, ptr %slot645, align 8
  %op3786 = sub i64 %v3785, 1
  store i64 %op3786, ptr %slot646, align 8
  %v3787 = load i64, ptr %slot646, align 8
  %cmp3788 = icmp eq i64 %v3787, 0
  %cv3789 = zext i1 %cmp3788 to i32
  store i32 %cv3789, ptr %slot647, align 8
  %v3790 = load i32, ptr %slot647, align 8
  %cv3791 = zext i32 %v3790 to i64
  %cond3792 = icmp ne i64 %cv3791, 0
  br i1 %cond3792, label %bb_rcglast771, label %bb_rcgdec771
bb_rcglast771:
  %v3793 = load i64, ptr %slot638, align 8
  %op3794 = sub i64 %v3793, 24
  store i64 %op3794, ptr %slot648, align 8
  %v3795 = load i64, ptr %slot638, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  %rgep3797 = getelementptr i8, ptr %p3796, i64 -24
  %ld3798 = load i64, ptr %rgep3797, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3798, ptr %slot649, align 8
  %v3799 = load i64, ptr %slot649, align 8
  %cmp3800 = icmp ne i64 %v3799, 0
  %cv3801 = zext i1 %cmp3800 to i32
  store i32 %cv3801, ptr %slot650, align 8
  %v3802 = load i32, ptr %slot650, align 8
  %cv3803 = zext i32 %v3802 to i64
  %cond3804 = icmp ne i64 %cv3803, 0
  br i1 %cond3804, label %bb_rcgdec771, label %bb_rcgslow771
bb_rcgslow771:
  %v3805 = load i64, ptr %slot637, align 8
  %v3806 = load i64, ptr %slot620, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3805, i64 %v3806) nomerge, !dbg !142
  br label %bb_rcgdone771
bb_rcgdec771:
  %v3807 = load i64, ptr %slot646, align 8
  %v3808 = load i64, ptr %slot638, align 8
  %p3809 = inttoptr i64 %v3808 to ptr
  %rgep3810 = getelementptr i8, ptr %p3809, i64 -32
  store i64 %v3807, ptr %rgep3810, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear771
bb_rcgclear771:
  %v3811 = load i64, ptr %slot620, align 8
  %p3812 = inttoptr i64 %v3811 to ptr
  store i64 0, ptr %p3812, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone771
bb_rcgdone771:
  br label %bb_rcslotdone740
bb_rcslotdone740:
  %v3813 = load i64, ptr %slot579, align 8
  %p3814 = inttoptr i64 %v3813 to ptr
  %ret3815 = load { i64, i64 }, ptr %p3814, align 8
  ret { i64, i64 } %ret3815
bb_i40:
  %v3816 = load i64, ptr %slot33, align 8
  store i64 %v3816, ptr %slot651, align 8
  %v3817 = load i64, ptr %slot9, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  store i32 2, ptr %p3818, align 4, !alias.scope !3, !noalias !4
  %v3819 = load i64, ptr %slot651, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %ld3821 = load i64, ptr %p3820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3821, ptr %slot652, align 8
  %v3822 = load i64, ptr %slot652, align 8
  %cmp3823 = icmp ne i64 %v3822, 0
  %cv3824 = zext i1 %cmp3823 to i32
  store i32 %cv3824, ptr %slot653, align 8
  %v3825 = load i32, ptr %slot653, align 8
  %cv3826 = zext i32 %v3825 to i64
  %cond3827 = icmp ne i64 %cv3826, 0
  br i1 %cond3827, label %bb_rcguniquenn787, label %bb_rcgunique787
bb_rcguniquenn787:
  %v3828 = load i64, ptr %slot652, align 8
  %op3829 = sub i64 %v3828, 16
  store i64 %op3829, ptr %slot654, align 8
  %v3830 = load i64, ptr %slot652, align 8
  %p3831 = inttoptr i64 %v3830 to ptr
  %rgep3832 = getelementptr i8, ptr %p3831, i64 -16
  %ld3833 = load i64, ptr %rgep3832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3833, ptr %slot655, align 8
  %v3834 = load i64, ptr %slot655, align 8
  %op3835 = and i64 %v3834, 6917529027641081858
  store i64 %op3835, ptr %slot656, align 8
  %v3836 = load i64, ptr %slot656, align 8
  %cmp3837 = icmp ne i64 %v3836, 0
  %cv3838 = zext i1 %cmp3837 to i32
  store i32 %cv3838, ptr %slot657, align 8
  %v3839 = load i32, ptr %slot657, align 8
  %cv3840 = zext i32 %v3839 to i64
  %cond3841 = icmp ne i64 %cv3840, 0
  br i1 %cond3841, label %bb_rcguniqueslow787, label %bb_rcguniquecount787
bb_rcguniquecount787:
  %v3842 = load i64, ptr %slot652, align 8
  %op3843 = sub i64 %v3842, 32
  store i64 %op3843, ptr %slot658, align 8
  %v3844 = load i64, ptr %slot652, align 8
  %p3845 = inttoptr i64 %v3844 to ptr
  %rgep3846 = getelementptr i8, ptr %p3845, i64 -32
  %ld3847 = load i64, ptr %rgep3846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3847, ptr %slot659, align 8
  %v3848 = load i64, ptr %slot659, align 8
  %cmp3849 = icmp ult i64 %v3848, 2
  %cv3850 = zext i1 %cmp3849 to i32
  store i32 %cv3850, ptr %slot660, align 8
  %v3851 = load i32, ptr %slot660, align 8
  %cv3852 = zext i32 %v3851 to i64
  %cond3853 = icmp ne i64 %cv3852, 0
  br i1 %cond3853, label %bb_rcgunique787, label %bb_rcguniqueslow787
bb_rcguniqueslow787:
  %v3854 = load i64, ptr %slot1, align 8
  %p3855 = inttoptr i64 %v3854 to ptr
  %p3856 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v3857 = load i64, ptr %slot651, align 8
  %p3858 = inttoptr i64 %v3857 to ptr
  %v3859 = load i64, ptr %slot8, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  %call3861 = call i32 @myl_qbe_rc_unique_local(ptr %p3855, ptr %p3856, ptr %p3858, ptr %p3860) nomerge, !dbg !144
  store i32 %call3861, ptr %slot661, align 8
  %v3862 = load i32, ptr %slot661, align 8
  %cv3863 = zext i32 %v3862 to i64
  %cond3864 = icmp ne i64 %cv3863, 0
  br i1 %cond3864, label %bb_rcunique798, label %bb_failure
bb_rcunique798:
  br label %bb_rcgunique787
bb_rcgunique787:
  %v3865 = load i64, ptr %slot33, align 8
  %p3866 = inttoptr i64 %v3865 to ptr
  %ld3867 = load i64, ptr %p3866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3867, ptr %slot662, align 8
  %v3868 = load i64, ptr %slot36, align 8
  store i64 %v3868, ptr %slot663, align 8
  %v3869 = load i64, ptr %slot663, align 8
  %p3870 = inttoptr i64 %v3869 to ptr
  %ld3871 = load i64, ptr %p3870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3871, ptr %slot664, align 8
  %v3872 = load i64, ptr %slot662, align 8
  %op3873 = add i64 %v3872, 0
  store i64 %op3873, ptr %slot665, align 8
  %v3874 = load i64, ptr %slot665, align 8
  %p3875 = inttoptr i64 %v3874 to ptr
  %ld3876 = load i64, ptr %p3875, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3876, ptr %slot666, align 8
  %v3877 = load i64, ptr %slot662, align 8
  %op3878 = add i64 %v3877, 8
  store i64 %op3878, ptr %slot667, align 8
  %v3879 = load i64, ptr %slot667, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %ld3881 = load i64, ptr %p3880, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3881, ptr %slot668, align 8
  %v3882 = load i64, ptr %slot662, align 8
  %op3883 = add i64 %v3882, 16
  store i64 %op3883, ptr %slot669, align 8
  %v3884 = load i64, ptr %slot669, align 8
  %p3885 = inttoptr i64 %v3884 to ptr
  %ld3886 = load i64, ptr %p3885, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3886, ptr %slot670, align 8
  %v3887 = load i64, ptr %slot666, align 8
  %v3888 = load i64, ptr %slot668, align 8
  %cmp3889 = icmp ult i64 %v3887, %v3888
  %cv3890 = zext i1 %cmp3889 to i32
  store i32 %cv3890, ptr %slot671, align 8
  %v3891 = load i64, ptr %slot670, align 8
  %cmp3892 = icmp ne i64 %v3891, 18446744073709551615
  %cv3893 = zext i1 %cmp3892 to i32
  store i32 %cv3893, ptr %slot672, align 8
  %v3894 = load i32, ptr %slot671, align 8
  %v3895 = load i32, ptr %slot672, align 8
  %op3896 = and i32 %v3894, %v3895
  store i32 %op3896, ptr %slot673, align 8
  %v3897 = load i32, ptr %slot673, align 8
  %cv3898 = zext i32 %v3897 to i64
  %cond3899 = icmp ne i64 %cv3898, 0
  br i1 %cond3899, label %bb_rcappend_check803, label %bb_rcappend_slow803
bb_rcappend_check803:
  %v3900 = load i64, ptr %slot54, align 8
  %p3901 = inttoptr i64 %v3900 to ptr
  %v3902 = load i64, ptr %slot662, align 8
  %p3903 = inttoptr i64 %v3902 to ptr
  %call3904 = call i32 @myl_rc_list_plain_ready(ptr %p3901, ptr %p3903) nomerge, !dbg !144
  store i32 %call3904, ptr %slot674, align 8
  %v3905 = load i32, ptr %slot674, align 8
  %cv3906 = zext i32 %v3905 to i64
  %cond3907 = icmp ne i64 %cv3906, 0
  br i1 %cond3907, label %bb_rcappend_fast803, label %bb_rcappend_slow803
bb_rcappend_slow803:
  %v3908 = load i64, ptr %slot663, align 8
  %p3909 = inttoptr i64 %v3908 to ptr
  %ld3910 = load i64, ptr %p3909, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3910, ptr %slot675, align 8
  %v3911 = load i64, ptr %slot675, align 8
  %v3912 = load i64, ptr %slot29, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  store i64 %v3911, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  %v3914 = load i64, ptr %slot29, align 8
  store i64 %v3914, ptr %slot676, align 8
  %v3915 = load i64, ptr %slot54, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  %v3917 = load i64, ptr %slot662, align 8
  %p3918 = inttoptr i64 %v3917 to ptr
  %v3919 = load i64, ptr %slot676, align 8
  %p3920 = inttoptr i64 %v3919 to ptr
  %call3921 = call i32 @myl_rc_list_append(ptr %p3916, ptr %p3918, ptr %p3920) nomerge, !dbg !144
  store i32 %call3921, ptr %slot677, align 8
  %v3922 = load i32, ptr %slot677, align 8
  %cv3923 = zext i32 %v3922 to i64
  %cond3924 = icmp ne i64 %cv3923, 0
  br i1 %cond3924, label %bb_success816, label %bb_failed816
bb_failed816:
  %v3925 = load i64, ptr %slot1, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  call void @myl_qbe_fail_allocation(ptr %p3926) nomerge, !dbg !144
  unreachable
bb_success816:
  br label %bb_rcappend_done803
bb_rcappend_fast803:
  %v3927 = load i64, ptr %slot662, align 8
  %op3928 = add i64 %v3927, 32
  store i64 %op3928, ptr %slot678, align 8
  %v3929 = load i64, ptr %slot678, align 8
  %p3930 = inttoptr i64 %v3929 to ptr
  %ld3931 = load i64, ptr %p3930, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3931, ptr %slot679, align 8
  %v3932 = load i64, ptr %slot666, align 8
  %op3933 = mul i64 %v3932, 8
  store i64 %op3933, ptr %slot680, align 8
  %v3934 = load i64, ptr %slot679, align 8
  %v3935 = load i64, ptr %slot680, align 8
  %op3936 = add i64 %v3934, %v3935
  store i64 %op3936, ptr %slot681, align 8
  %v3937 = load i64, ptr %slot664, align 8
  %v3938 = load i64, ptr %slot679, align 8
  %p3939 = inttoptr i64 %v3938 to ptr
  %v3940 = load i64, ptr %slot680, align 8
  %egep3941 = getelementptr i8, ptr %p3939, i64 %v3940
  store i64 %v3937, ptr %egep3941, align 8, !alias.scope !12, !noalias !13
  %v3942 = load i64, ptr %slot662, align 8
  %op3943 = add i64 %v3942, 0
  store i64 %op3943, ptr %slot682, align 8
  %v3944 = load i64, ptr %slot666, align 8
  %op3945 = add i64 %v3944, 1
  store i64 %op3945, ptr %slot683, align 8
  %v3946 = load i64, ptr %slot683, align 8
  %v3947 = load i64, ptr %slot682, align 8
  %p3948 = inttoptr i64 %v3947 to ptr
  store i64 %v3946, ptr %p3948, align 8, !alias.scope !6, !noalias !7
  %v3949 = load i64, ptr %slot662, align 8
  %op3950 = add i64 %v3949, 16
  store i64 %op3950, ptr %slot684, align 8
  %v3951 = load i64, ptr %slot670, align 8
  %op3952 = add i64 %v3951, 1
  store i64 %op3952, ptr %slot685, align 8
  %v3953 = load i64, ptr %slot685, align 8
  %v3954 = load i64, ptr %slot684, align 8
  %p3955 = inttoptr i64 %v3954 to ptr
  store i64 %v3953, ptr %p3955, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done803
bb_rcappend_done803:
  %v3956 = load i64, ptr %slot36, align 8
  %p3957 = inttoptr i64 %v3956 to ptr
  store i64 0, ptr %p3957, align 8, !alias.scope !3, !noalias !4
  br label %bb_i18
bb_i43:
  %v3958 = load i64, ptr %slot30, align 8
  %p3959 = inttoptr i64 %v3958 to ptr
  %ld3960 = load i64, ptr %p3959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3960, ptr %slot686, align 8
  %v3961 = load i64, ptr %slot686, align 8
  %v3962 = load i64, ptr %slot36, align 8
  %p3963 = inttoptr i64 %v3962 to ptr
  store i64 %v3961, ptr %p3963, align 8, !alias.scope !3, !noalias !4
  %v3964 = load i64, ptr %slot45, align 8
  store i64 %v3964, ptr %slot687, align 8
  %v3965 = load i64, ptr %slot687, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  store i32 0, ptr %p3966, align 4, !alias.scope !3, !noalias !4
  %v3967 = load i64, ptr %slot687, align 8
  %p3968 = inttoptr i64 %v3967 to ptr
  store i32 1, ptr %p3968, align 4, !alias.scope !3, !noalias !4
  %v3969 = load i64, ptr %slot687, align 8
  %v3970 = load i64, ptr %slot37, align 8
  %p3971 = inttoptr i64 %v3970 to ptr
  store i64 %v3969, ptr %p3971, align 8, !alias.scope !3, !noalias !4
  %p3972 = inttoptr i64 ptrtoint (ptr @myl_lit_35d41e0b6aa3a58cd0db1d8c7a982e8b15477d856cb7b6bc9404d8afd095ed9e to i64) to ptr
  %ld3973 = load i64, ptr %p3972, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3973, ptr %slot688, align 8
  %v3974 = load i64, ptr %slot688, align 8
  %v3975 = load i64, ptr %slot38, align 8
  %p3976 = inttoptr i64 %v3975 to ptr
  store i64 %v3974, ptr %p3976, align 8, !alias.scope !3, !noalias !4
  %v3977 = load i64, ptr %slot38, align 8
  %p3978 = inttoptr i64 %v3977 to ptr
  %ld3979 = load i64, ptr %p3978, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3979, ptr %slot689, align 8
  %v3980 = load i64, ptr %slot689, align 8
  %v3981 = load i64, ptr %slot26, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  store i64 %v3980, ptr %p3982, align 8, !alias.scope !3, !noalias !4
  %v3983 = load i64, ptr %slot26, align 8
  store i64 %v3983, ptr %slot690, align 8
  %v3984 = load i64, ptr %slot28, align 8
  store i64 %v3984, ptr %slot691, align 8
  %v3985 = load i64, ptr %slot690, align 8
  %v3986 = load i64, ptr %slot691, align 8
  %p3987 = inttoptr i64 %v3985 to ptr
  %p3988 = inttoptr i64 %v3986 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3988, ptr %p3987, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3989 = load i64, ptr %slot20, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  store i32 2, ptr %p3990, align 4, !alias.scope !3, !noalias !4
  %v3991 = load i64, ptr %slot19, align 8
  %p3992 = inttoptr i64 %v3991 to ptr
  store i32 1, ptr %p3992, align 4, !alias.scope !3, !noalias !4
  %v3993 = load i64, ptr %slot24, align 8
  store i64 %v3993, ptr %slot692, align 8
  %v3994 = load i64, ptr %slot28, align 8
  store i64 %v3994, ptr %slot693, align 8
  %v3995 = load i64, ptr %slot693, align 8
  %v3996 = load i64, ptr %slot692, align 8
  %p3997 = inttoptr i64 %v3995 to ptr
  %p3998 = inttoptr i64 %v3996 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3998, ptr %p3997, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3999 = load i64, ptr %slot17, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  store i32 2, ptr %p4000, align 4, !alias.scope !3, !noalias !4
  %v4001 = load i64, ptr %slot20, align 8
  %p4002 = inttoptr i64 %v4001 to ptr
  %ld4003 = load i32, ptr %p4002, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4003, ptr %slot694, align 8
  %v4004 = load i32, ptr %slot694, align 8
  %v4005 = load i64, ptr %slot17, align 8
  %p4006 = inttoptr i64 %v4005 to ptr
  store i32 %v4004, ptr %p4006, align 4, !alias.scope !3, !noalias !4
  %v4007 = load i64, ptr %slot19, align 8
  %p4008 = inttoptr i64 %v4007 to ptr
  store i32 0, ptr %p4008, align 4, !alias.scope !3, !noalias !4
  %v4009 = load i64, ptr %slot16, align 8
  %p4010 = inttoptr i64 %v4009 to ptr
  store i32 1, ptr %p4010, align 4, !alias.scope !3, !noalias !4
  %v4011 = load i64, ptr %slot692, align 8
  %p4012 = inttoptr i64 %v4011 to ptr
  %ld4013 = load i64, ptr %p4012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4013, ptr %slot695, align 8
  %v4014 = load i64, ptr %slot695, align 8
  %v4015 = load i64, ptr %slot38, align 8
  %p4016 = inttoptr i64 %v4015 to ptr
  store i64 %v4014, ptr %p4016, align 8, !alias.scope !3, !noalias !4
  %v4017 = load i64, ptr %slot36, align 8
  %p4018 = inttoptr i64 %v4017 to ptr
  %ld4019 = load i64, ptr %p4018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4019, ptr %slot696, align 8
  %v4020 = load i64, ptr %slot37, align 8
  %p4021 = inttoptr i64 %v4020 to ptr
  %ld4022 = load i64, ptr %p4021, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4022, ptr %slot697, align 8
  %v4023 = load i64, ptr %slot38, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  %ld4025 = load i64, ptr %p4024, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4025, ptr %slot698, align 8
  %v4026 = load i64, ptr %slot1, align 8
  %v4027 = load i64, ptr %slot696, align 8
  %v4028 = load i64, ptr %slot697, align 8
  %v4029 = load i64, ptr %slot698, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult700, i64 %v4026, i64 %v4027, i64 %v4028, i64 %v4029) nomerge, !dbg !146
  %addr4030 = ptrtoint ptr %callresult700 to i64
  store i64 %addr4030, ptr %slot699, align 8
  %v4031 = load i64, ptr %slot699, align 8
  %v4032 = load i64, ptr %slot36, align 8
  %p4033 = inttoptr i64 %v4032 to ptr
  store i64 %v4031, ptr %p4033, align 8, !alias.scope !3, !noalias !4
  %v4034 = load i64, ptr %slot36, align 8
  %p4035 = inttoptr i64 %v4034 to ptr
  %ld4036 = load i64, ptr %p4035, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4036, ptr %slot701, align 8
  %v4037 = load i64, ptr %slot28, align 8
  store i64 %v4037, ptr %slot702, align 8
  %v4038 = load i64, ptr %slot701, align 8
  %v4039 = load i64, ptr %slot702, align 8
  %p4040 = inttoptr i64 %v4038 to ptr
  %p4041 = inttoptr i64 %v4039 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4041, ptr %p4040, i64 48, i1 false)
  %v4042 = load i64, ptr %slot20, align 8
  %p4043 = inttoptr i64 %v4042 to ptr
  store i32 2, ptr %p4043, align 4, !alias.scope !3, !noalias !4
  %v4044 = load i64, ptr %slot19, align 8
  %p4045 = inttoptr i64 %v4044 to ptr
  store i32 1, ptr %p4045, align 4, !alias.scope !3, !noalias !4
  %v4046 = load i64, ptr %slot12, align 8
  %p4047 = inttoptr i64 %v4046 to ptr
  %ld4048 = load i32, ptr %p4047, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4048, ptr %slot703, align 8
  %v4049 = load i32, ptr %slot703, align 8
  %cv4050 = zext i32 %v4049 to i64
  %cond4051 = icmp ne i64 %cv4050, 0
  br i1 %cond4051, label %bb_rcslotdrop853, label %bb_rcslotdone853
bb_rcslotdrop853:
  %v4052 = load i64, ptr %slot12, align 8
  %p4053 = inttoptr i64 %v4052 to ptr
  store i32 0, ptr %p4053, align 4, !alias.scope !3, !noalias !4
  %v4054 = load i64, ptr %slot22, align 8
  store i64 %v4054, ptr %slot704, align 8
  %v4055 = load i64, ptr %slot13, align 8
  %p4056 = inttoptr i64 %v4055 to ptr
  %ld4057 = load i32, ptr %p4056, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4057, ptr %slot705, align 8
  %v4058 = load i32, ptr %slot705, align 8
  %op4059 = and i32 %v4058, 28
  store i32 %op4059, ptr %slot706, align 8
  %v4060 = load i32, ptr %slot706, align 8
  %cv4061 = zext i32 %v4060 to i64
  %cond4062 = icmp ne i64 %cv4061, 0
  br i1 %cond4062, label %bb_rcslotrole853, label %bb_rcslotowner853
bb_rcslotrole853:
  %v4063 = load i64, ptr %slot54, align 8
  store i64 %v4063, ptr %slot707, align 8
  %v4064 = load i64, ptr %slot707, align 8
  %v4065 = load i64, ptr %slot704, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v4064, i64 %v4065) nomerge, !dbg !146
  br label %bb_rcslotdone853
bb_rcslotowner853:
  %v4066 = load i64, ptr %slot54, align 8
  store i64 %v4066, ptr %slot708, align 8
  %v4067 = load i64, ptr %slot708, align 8
  %v4068 = load i64, ptr %slot704, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v4067, i64 %v4068) nomerge, !dbg !146
  br label %bb_rcslotdone853
bb_rcslotdone853:
  %v4069 = load i64, ptr %slot16, align 8
  %p4070 = inttoptr i64 %v4069 to ptr
  %ld4071 = load i32, ptr %p4070, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4071, ptr %slot709, align 8
  %v4072 = load i32, ptr %slot709, align 8
  %cv4073 = zext i32 %v4072 to i64
  %cond4074 = icmp ne i64 %cv4073, 0
  br i1 %cond4074, label %bb_rcslotdrop862, label %bb_rcslotdone862
bb_rcslotdrop862:
  %v4075 = load i64, ptr %slot16, align 8
  %p4076 = inttoptr i64 %v4075 to ptr
  store i32 0, ptr %p4076, align 4, !alias.scope !3, !noalias !4
  %v4077 = load i64, ptr %slot24, align 8
  store i64 %v4077, ptr %slot710, align 8
  %v4078 = load i64, ptr %slot17, align 8
  %p4079 = inttoptr i64 %v4078 to ptr
  %ld4080 = load i32, ptr %p4079, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4080, ptr %slot711, align 8
  %v4081 = load i32, ptr %slot711, align 8
  %op4082 = and i32 %v4081, 28
  store i32 %op4082, ptr %slot712, align 8
  %v4083 = load i32, ptr %slot712, align 8
  %cv4084 = zext i32 %v4083 to i64
  %cond4085 = icmp ne i64 %cv4084, 0
  br i1 %cond4085, label %bb_rcslotrole862, label %bb_rcslotowner862
bb_rcslotrole862:
  %v4086 = load i64, ptr %slot54, align 8
  store i64 %v4086, ptr %slot713, align 8
  %v4087 = load i64, ptr %slot710, align 8
  %p4088 = inttoptr i64 %v4087 to ptr
  %ld4089 = load i64, ptr %p4088, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4089, ptr %slot714, align 8
  %v4090 = load i64, ptr %slot714, align 8
  %cmp4091 = icmp ne i64 %v4090, 0
  %cv4092 = zext i1 %cmp4091 to i32
  store i32 %cv4092, ptr %slot715, align 8
  %v4093 = load i32, ptr %slot715, align 8
  %cv4094 = zext i32 %v4093 to i64
  %cond4095 = icmp ne i64 %cv4094, 0
  br i1 %cond4095, label %bb_rcgnn878, label %bb_rcgdone878
bb_rcgnn878:
  %v4096 = load i64, ptr %slot714, align 8
  %op4097 = sub i64 %v4096, 16
  store i64 %op4097, ptr %slot716, align 8
  %v4098 = load i64, ptr %slot714, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  %rgep4100 = getelementptr i8, ptr %p4099, i64 -16
  %ld4101 = load i64, ptr %rgep4100, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4101, ptr %slot717, align 8
  %v4102 = load i64, ptr %slot717, align 8
  %op4103 = and i64 %v4102, 4611686018427387906
  store i64 %op4103, ptr %slot718, align 8
  %v4104 = load i64, ptr %slot718, align 8
  %cmp4105 = icmp ne i64 %v4104, 0
  %cv4106 = zext i1 %cmp4105 to i32
  store i32 %cv4106, ptr %slot719, align 8
  %v4107 = load i32, ptr %slot719, align 8
  %cv4108 = zext i32 %v4107 to i64
  %cond4109 = icmp ne i64 %cv4108, 0
  br i1 %cond4109, label %bb_rcgclear878, label %bb_rcgcounted878
bb_rcgcounted878:
  %v4110 = load i64, ptr %slot714, align 8
  %op4111 = sub i64 %v4110, 24
  store i64 %op4111, ptr %slot720, align 8
  %v4112 = load i64, ptr %slot714, align 8
  %p4113 = inttoptr i64 %v4112 to ptr
  %rgep4114 = getelementptr i8, ptr %p4113, i64 -24
  %ld4115 = load i64, ptr %rgep4114, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4115, ptr %slot721, align 8
  %v4116 = load i64, ptr %slot721, align 8
  %op4117 = sub i64 %v4116, 1
  store i64 %op4117, ptr %slot722, align 8
  %v4118 = load i64, ptr %slot722, align 8
  %cmp4119 = icmp eq i64 %v4118, 0
  %cv4120 = zext i1 %cmp4119 to i32
  store i32 %cv4120, ptr %slot723, align 8
  %v4121 = load i32, ptr %slot723, align 8
  %cv4122 = zext i32 %v4121 to i64
  %cond4123 = icmp ne i64 %cv4122, 0
  br i1 %cond4123, label %bb_rcglast878, label %bb_rcgdec878
bb_rcglast878:
  %v4124 = load i64, ptr %slot714, align 8
  %op4125 = sub i64 %v4124, 32
  store i64 %op4125, ptr %slot724, align 8
  %v4126 = load i64, ptr %slot714, align 8
  %p4127 = inttoptr i64 %v4126 to ptr
  %rgep4128 = getelementptr i8, ptr %p4127, i64 -32
  %ld4129 = load i64, ptr %rgep4128, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4129, ptr %slot725, align 8
  %v4130 = load i64, ptr %slot725, align 8
  %cmp4131 = icmp ne i64 %v4130, 0
  %cv4132 = zext i1 %cmp4131 to i32
  store i32 %cv4132, ptr %slot726, align 8
  %v4133 = load i32, ptr %slot726, align 8
  %cv4134 = zext i32 %v4133 to i64
  %cond4135 = icmp ne i64 %cv4134, 0
  br i1 %cond4135, label %bb_rcgdec878, label %bb_rcgslow878
bb_rcgslow878:
  %v4136 = load i64, ptr %slot713, align 8
  %v4137 = load i64, ptr %slot710, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4136, i64 %v4137) nomerge, !dbg !146
  br label %bb_rcgdone878
bb_rcgdec878:
  %v4138 = load i64, ptr %slot722, align 8
  %v4139 = load i64, ptr %slot714, align 8
  %p4140 = inttoptr i64 %v4139 to ptr
  %rgep4141 = getelementptr i8, ptr %p4140, i64 -24
  store i64 %v4138, ptr %rgep4141, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear878
bb_rcgclear878:
  %v4142 = load i64, ptr %slot710, align 8
  %p4143 = inttoptr i64 %v4142 to ptr
  store i64 0, ptr %p4143, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone878
bb_rcgdone878:
  br label %bb_rcslotdone862
bb_rcslotowner862:
  %v4144 = load i64, ptr %slot54, align 8
  store i64 %v4144, ptr %slot727, align 8
  %v4145 = load i64, ptr %slot710, align 8
  %p4146 = inttoptr i64 %v4145 to ptr
  %ld4147 = load i64, ptr %p4146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4147, ptr %slot728, align 8
  %v4148 = load i64, ptr %slot728, align 8
  %cmp4149 = icmp ne i64 %v4148, 0
  %cv4150 = zext i1 %cmp4149 to i32
  store i32 %cv4150, ptr %slot729, align 8
  %v4151 = load i32, ptr %slot729, align 8
  %cv4152 = zext i32 %v4151 to i64
  %cond4153 = icmp ne i64 %cv4152, 0
  br i1 %cond4153, label %bb_rcgnn893, label %bb_rcgdone893
bb_rcgnn893:
  %v4154 = load i64, ptr %slot728, align 8
  %op4155 = sub i64 %v4154, 16
  store i64 %op4155, ptr %slot730, align 8
  %v4156 = load i64, ptr %slot728, align 8
  %p4157 = inttoptr i64 %v4156 to ptr
  %rgep4158 = getelementptr i8, ptr %p4157, i64 -16
  %ld4159 = load i64, ptr %rgep4158, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4159, ptr %slot731, align 8
  %v4160 = load i64, ptr %slot731, align 8
  %op4161 = and i64 %v4160, 4611686018427387906
  store i64 %op4161, ptr %slot732, align 8
  %v4162 = load i64, ptr %slot732, align 8
  %cmp4163 = icmp ne i64 %v4162, 0
  %cv4164 = zext i1 %cmp4163 to i32
  store i32 %cv4164, ptr %slot733, align 8
  %v4165 = load i32, ptr %slot733, align 8
  %cv4166 = zext i32 %v4165 to i64
  %cond4167 = icmp ne i64 %cv4166, 0
  br i1 %cond4167, label %bb_rcgclear893, label %bb_rcgcounted893
bb_rcgcounted893:
  %v4168 = load i64, ptr %slot728, align 8
  %op4169 = sub i64 %v4168, 32
  store i64 %op4169, ptr %slot734, align 8
  %v4170 = load i64, ptr %slot728, align 8
  %p4171 = inttoptr i64 %v4170 to ptr
  %rgep4172 = getelementptr i8, ptr %p4171, i64 -32
  %ld4173 = load i64, ptr %rgep4172, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4173, ptr %slot735, align 8
  %v4174 = load i64, ptr %slot735, align 8
  %op4175 = sub i64 %v4174, 1
  store i64 %op4175, ptr %slot736, align 8
  %v4176 = load i64, ptr %slot736, align 8
  %cmp4177 = icmp eq i64 %v4176, 0
  %cv4178 = zext i1 %cmp4177 to i32
  store i32 %cv4178, ptr %slot737, align 8
  %v4179 = load i32, ptr %slot737, align 8
  %cv4180 = zext i32 %v4179 to i64
  %cond4181 = icmp ne i64 %cv4180, 0
  br i1 %cond4181, label %bb_rcglast893, label %bb_rcgdec893
bb_rcglast893:
  %v4182 = load i64, ptr %slot728, align 8
  %op4183 = sub i64 %v4182, 24
  store i64 %op4183, ptr %slot738, align 8
  %v4184 = load i64, ptr %slot728, align 8
  %p4185 = inttoptr i64 %v4184 to ptr
  %rgep4186 = getelementptr i8, ptr %p4185, i64 -24
  %ld4187 = load i64, ptr %rgep4186, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4187, ptr %slot739, align 8
  %v4188 = load i64, ptr %slot739, align 8
  %cmp4189 = icmp ne i64 %v4188, 0
  %cv4190 = zext i1 %cmp4189 to i32
  store i32 %cv4190, ptr %slot740, align 8
  %v4191 = load i32, ptr %slot740, align 8
  %cv4192 = zext i32 %v4191 to i64
  %cond4193 = icmp ne i64 %cv4192, 0
  br i1 %cond4193, label %bb_rcgdec893, label %bb_rcgslow893
bb_rcgslow893:
  %v4194 = load i64, ptr %slot727, align 8
  %v4195 = load i64, ptr %slot710, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4194, i64 %v4195) nomerge, !dbg !146
  br label %bb_rcgdone893
bb_rcgdec893:
  %v4196 = load i64, ptr %slot736, align 8
  %v4197 = load i64, ptr %slot728, align 8
  %p4198 = inttoptr i64 %v4197 to ptr
  %rgep4199 = getelementptr i8, ptr %p4198, i64 -32
  store i64 %v4196, ptr %rgep4199, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear893
bb_rcgclear893:
  %v4200 = load i64, ptr %slot710, align 8
  %p4201 = inttoptr i64 %v4200 to ptr
  store i64 0, ptr %p4201, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone893
bb_rcgdone893:
  br label %bb_rcslotdone862
bb_rcslotdone862:
  %v4202 = load i64, ptr %slot22, align 8
  store i64 %v4202, ptr %slot741, align 8
  %v4203 = load i64, ptr %slot28, align 8
  store i64 %v4203, ptr %slot742, align 8
  %v4204 = load i64, ptr %slot742, align 8
  %v4205 = load i64, ptr %slot741, align 8
  %p4206 = inttoptr i64 %v4204 to ptr
  %p4207 = inttoptr i64 %v4205 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4207, ptr %p4206, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v4208 = load i64, ptr %slot13, align 8
  %p4209 = inttoptr i64 %v4208 to ptr
  store i32 2, ptr %p4209, align 4, !alias.scope !3, !noalias !4
  %v4210 = load i64, ptr %slot20, align 8
  %p4211 = inttoptr i64 %v4210 to ptr
  %ld4212 = load i32, ptr %p4211, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4212, ptr %slot743, align 8
  %v4213 = load i32, ptr %slot743, align 8
  %v4214 = load i64, ptr %slot13, align 8
  %p4215 = inttoptr i64 %v4214 to ptr
  store i32 %v4213, ptr %p4215, align 4, !alias.scope !3, !noalias !4
  %v4216 = load i64, ptr %slot19, align 8
  %p4217 = inttoptr i64 %v4216 to ptr
  store i32 0, ptr %p4217, align 4, !alias.scope !3, !noalias !4
  %v4218 = load i64, ptr %slot12, align 8
  %p4219 = inttoptr i64 %v4218 to ptr
  store i32 1, ptr %p4219, align 4, !alias.scope !3, !noalias !4
  %v4220 = load i64, ptr %slot741, align 8
  %v4221 = load i64, ptr %slot36, align 8
  %p4222 = inttoptr i64 %v4221 to ptr
  store i64 %v4220, ptr %p4222, align 8, !alias.scope !3, !noalias !4
  %v4223 = load i64, ptr %slot36, align 8
  %p4224 = inttoptr i64 %v4223 to ptr
  %ld4225 = load i64, ptr %p4224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4225, ptr %slot744, align 8
  %v4226 = load i64, ptr %slot744, align 8
  %p4227 = inttoptr i64 %v4226 to ptr
  %ld4228 = load i32, ptr %p4227, align 4
  %ext4229 = zext i32 %ld4228 to i64
  store i64 %ext4229, ptr %slot745, align 8
  %v4230 = load i64, ptr %slot745, align 8
  %cmp4231 = icmp eq i64 %v4230, 0
  %cv4232 = zext i1 %cmp4231 to i64
  store i64 %cv4232, ptr %slot746, align 8
  %v4233 = load i64, ptr %slot746, align 8
  %cond4234 = icmp ne i64 %v4233, 0
  br i1 %cond4234, label %bb_rctryok906, label %bb_rctryerror906
bb_rctryerror906:
  %p4235 = inttoptr i64 ptrtoint (ptr @myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p4235, i64 12884901935) "call-inline-cost"="0", !dbg !148
  %v4236 = load i64, ptr %slot744, align 8
  %op4237 = add i64 %v4236, 8
  store i64 %op4237, ptr %slot747, align 8
  %v4238 = load i64, ptr %slot46, align 8
  store i64 %v4238, ptr %slot748, align 8
  %v4239 = load i64, ptr %slot748, align 8
  %p4240 = inttoptr i64 %v4239 to ptr
  store i64 0, ptr %p4240, align 8, !alias.scope !3, !noalias !4
  %v4241 = load i64, ptr %slot748, align 8
  %p4243 = inttoptr i64 %v4241 to ptr
  %gep4244 = getelementptr i8, ptr %p4243, i64 8
  %op4242 = ptrtoint ptr %gep4244 to i64
  store i64 %op4242, ptr %slot749, align 8
  %v4245 = load i64, ptr %slot749, align 8
  %p4246 = inttoptr i64 %v4245 to ptr
  store i64 0, ptr %p4246, align 8, !alias.scope !3, !noalias !4
  %v4247 = load i64, ptr %slot748, align 8
  %p4248 = inttoptr i64 %v4247 to ptr
  store i32 1, ptr %p4248, align 4, !alias.scope !3, !noalias !4
  %v4249 = load i64, ptr %slot748, align 8
  %p4251 = inttoptr i64 %v4249 to ptr
  %gep4252 = getelementptr i8, ptr %p4251, i64 8
  %op4250 = ptrtoint ptr %gep4252 to i64
  store i64 %op4250, ptr %slot750, align 8
  %v4253 = load i64, ptr %slot21, align 8
  %p4254 = inttoptr i64 %v4253 to ptr
  store i32 1, ptr %p4254, align 4, !alias.scope !3, !noalias !4
  %v4255 = load i64, ptr %slot55, align 8
  store i64 %v4255, ptr %slot751, align 8
  %v4256 = load i64, ptr %slot748, align 8
  %v4257 = load i64, ptr %slot36, align 8
  %p4258 = inttoptr i64 %v4257 to ptr
  store i64 %v4256, ptr %p4258, align 8, !alias.scope !3, !noalias !4
  %v4259 = load i64, ptr %slot12, align 8
  %p4260 = inttoptr i64 %v4259 to ptr
  %ld4261 = load i32, ptr %p4260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4261, ptr %slot752, align 8
  %v4262 = load i32, ptr %slot752, align 8
  %cv4263 = zext i32 %v4262 to i64
  %cond4264 = icmp ne i64 %cv4263, 0
  br i1 %cond4264, label %bb_rcslotdrop917, label %bb_rcslotdone917
bb_rcslotdrop917:
  %v4265 = load i64, ptr %slot12, align 8
  %p4266 = inttoptr i64 %v4265 to ptr
  store i32 0, ptr %p4266, align 4, !alias.scope !3, !noalias !4
  %v4267 = load i64, ptr %slot22, align 8
  store i64 %v4267, ptr %slot753, align 8
  %v4268 = load i64, ptr %slot13, align 8
  %p4269 = inttoptr i64 %v4268 to ptr
  %ld4270 = load i32, ptr %p4269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4270, ptr %slot754, align 8
  %v4271 = load i32, ptr %slot754, align 8
  %op4272 = and i32 %v4271, 28
  store i32 %op4272, ptr %slot755, align 8
  %v4273 = load i32, ptr %slot755, align 8
  %cv4274 = zext i32 %v4273 to i64
  %cond4275 = icmp ne i64 %cv4274, 0
  br i1 %cond4275, label %bb_rcslotrole917, label %bb_rcslotowner917
bb_rcslotrole917:
  %v4276 = load i64, ptr %slot54, align 8
  store i64 %v4276, ptr %slot756, align 8
  %v4277 = load i64, ptr %slot756, align 8
  %v4278 = load i64, ptr %slot753, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v4277, i64 %v4278) nomerge, !dbg !148
  br label %bb_rcslotdone917
bb_rcslotowner917:
  %v4279 = load i64, ptr %slot54, align 8
  store i64 %v4279, ptr %slot757, align 8
  %v4280 = load i64, ptr %slot757, align 8
  %v4281 = load i64, ptr %slot753, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v4280, i64 %v4281) nomerge, !dbg !148
  br label %bb_rcslotdone917
bb_rcslotdone917:
  br label %bb_i49
bb_rctryok906:
  %v4282 = load i64, ptr %slot46, align 8
  store i64 %v4282, ptr %slot758, align 8
  %v4283 = load i64, ptr %slot758, align 8
  %p4284 = inttoptr i64 %v4283 to ptr
  store i64 0, ptr %p4284, align 8, !alias.scope !3, !noalias !4
  %v4285 = load i64, ptr %slot758, align 8
  %p4287 = inttoptr i64 %v4285 to ptr
  %gep4288 = getelementptr i8, ptr %p4287, i64 8
  %op4286 = ptrtoint ptr %gep4288 to i64
  store i64 %op4286, ptr %slot759, align 8
  %v4289 = load i64, ptr %slot759, align 8
  %p4290 = inttoptr i64 %v4289 to ptr
  store i64 0, ptr %p4290, align 8, !alias.scope !3, !noalias !4
  %v4291 = load i64, ptr %slot758, align 8
  %p4293 = inttoptr i64 %v4291 to ptr
  %gep4294 = getelementptr i8, ptr %p4293, i64 16
  %op4292 = ptrtoint ptr %gep4294 to i64
  store i64 %op4292, ptr %slot760, align 8
  %v4295 = load i64, ptr %slot760, align 8
  %p4296 = inttoptr i64 %v4295 to ptr
  store i64 0, ptr %p4296, align 8, !alias.scope !3, !noalias !4
  %v4297 = load i64, ptr %slot758, align 8
  %p4299 = inttoptr i64 %v4297 to ptr
  %gep4300 = getelementptr i8, ptr %p4299, i64 24
  %op4298 = ptrtoint ptr %gep4300 to i64
  store i64 %op4298, ptr %slot761, align 8
  %v4301 = load i64, ptr %slot761, align 8
  %p4302 = inttoptr i64 %v4301 to ptr
  store i64 0, ptr %p4302, align 8, !alias.scope !3, !noalias !4
  %v4303 = load i64, ptr %slot758, align 8
  %p4305 = inttoptr i64 %v4303 to ptr
  %gep4306 = getelementptr i8, ptr %p4305, i64 32
  %op4304 = ptrtoint ptr %gep4306 to i64
  store i64 %op4304, ptr %slot762, align 8
  %v4307 = load i64, ptr %slot762, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  store i64 0, ptr %p4308, align 8, !alias.scope !3, !noalias !4
  %v4309 = load i64, ptr %slot21, align 8
  %p4310 = inttoptr i64 %v4309 to ptr
  store i32 1, ptr %p4310, align 4, !alias.scope !3, !noalias !4
  %v4311 = load i64, ptr %slot744, align 8
  %op4312 = add i64 %v4311, 8
  store i64 %op4312, ptr %slot763, align 8
  %v4313 = load i64, ptr %slot55, align 8
  store i64 %v4313, ptr %slot764, align 8
  %v4314 = load i64, ptr %slot54, align 8
  %v4315 = load i64, ptr %slot758, align 8
  %v4316 = load i64, ptr %slot763, align 8
  %v4317 = load i64, ptr %slot764, align 8
  %cv4318 = trunc i64 %v4317 to i32
  %call4319 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v4314, i64 %v4315, i64 %v4316, i32 %cv4318) nomerge, !dbg !148
  store i32 %call4319, ptr %slot765, align 8
  %v4320 = load i32, ptr %slot765, align 8
  %cv4321 = zext i32 %v4320 to i64
  %cond4322 = icmp ne i64 %cv4321, 0
  br i1 %cond4322, label %bb_rcsuccess934, label %bb_rcfailure934
bb_rcfailure934:
  %v4323 = load i64, ptr %slot54, align 8
  %p4324 = inttoptr i64 %v4323 to ptr
  %call4325 = call i32 @myl_rc_take_failure(ptr %p4324) nomerge, !dbg !148
  store i32 %call4325, ptr %slot766, align 8
  %v4326 = load i64, ptr %slot1, align 8
  %p4327 = inttoptr i64 %v4326 to ptr
  %v4328 = load i32, ptr %slot766, align 8
  %call4329 = call i32 @myl_qbe_rc_status(ptr %p4327, i32 %v4328) nomerge, !dbg !148
  store i32 %call4329, ptr %slot767, align 8
  br label %bb_failure
bb_rcsuccess934:
  %v4330 = load i64, ptr %slot758, align 8
  %v4331 = load i64, ptr %slot36, align 8
  %p4332 = inttoptr i64 %v4331 to ptr
  store i64 %v4330, ptr %p4332, align 8, !alias.scope !3, !noalias !4
  %v4333 = load i64, ptr %slot36, align 8
  %p4334 = inttoptr i64 %v4333 to ptr
  %ld4335 = load i64, ptr %p4334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4335, ptr %slot768, align 8
  %v4336 = load i64, ptr %slot28, align 8
  store i64 %v4336, ptr %slot769, align 8
  %v4337 = load i64, ptr %slot768, align 8
  %v4338 = load i64, ptr %slot769, align 8
  %p4339 = inttoptr i64 %v4337 to ptr
  %p4340 = inttoptr i64 %v4338 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4340, ptr %p4339, i64 40, i1 false)
  %v4341 = load i64, ptr %slot20, align 8
  %p4342 = inttoptr i64 %v4341 to ptr
  store i32 2, ptr %p4342, align 4, !alias.scope !3, !noalias !4
  %v4343 = load i64, ptr %slot19, align 8
  %p4344 = inttoptr i64 %v4343 to ptr
  store i32 1, ptr %p4344, align 4, !alias.scope !3, !noalias !4
  %v4345 = load i64, ptr %slot12, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  %ld4347 = load i32, ptr %p4346, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4347, ptr %slot770, align 8
  %v4348 = load i32, ptr %slot770, align 8
  %cv4349 = zext i32 %v4348 to i64
  %cond4350 = icmp ne i64 %cv4349, 0
  br i1 %cond4350, label %bb_rcslotdrop943, label %bb_rcslotdone943
bb_rcslotdrop943:
  %v4351 = load i64, ptr %slot12, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  store i32 0, ptr %p4352, align 4, !alias.scope !3, !noalias !4
  %v4353 = load i64, ptr %slot22, align 8
  store i64 %v4353, ptr %slot771, align 8
  %v4354 = load i64, ptr %slot13, align 8
  %p4355 = inttoptr i64 %v4354 to ptr
  %ld4356 = load i32, ptr %p4355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4356, ptr %slot772, align 8
  %v4357 = load i32, ptr %slot772, align 8
  %op4358 = and i32 %v4357, 28
  store i32 %op4358, ptr %slot773, align 8
  %v4359 = load i32, ptr %slot773, align 8
  %cv4360 = zext i32 %v4359 to i64
  %cond4361 = icmp ne i64 %cv4360, 0
  br i1 %cond4361, label %bb_rcslotrole943, label %bb_rcslotowner943
bb_rcslotrole943:
  %v4362 = load i64, ptr %slot54, align 8
  store i64 %v4362, ptr %slot774, align 8
  %v4363 = load i64, ptr %slot774, align 8
  %v4364 = load i64, ptr %slot771, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v4363, i64 %v4364) nomerge, !dbg !148
  br label %bb_rcslotdone943
bb_rcslotowner943:
  %v4365 = load i64, ptr %slot54, align 8
  store i64 %v4365, ptr %slot775, align 8
  %v4366 = load i64, ptr %slot775, align 8
  %v4367 = load i64, ptr %slot771, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v4366, i64 %v4367) nomerge, !dbg !148
  br label %bb_rcslotdone943
bb_rcslotdone943:
  %v4368 = load i64, ptr %slot22, align 8
  store i64 %v4368, ptr %slot776, align 8
  %v4369 = load i64, ptr %slot28, align 8
  store i64 %v4369, ptr %slot777, align 8
  %v4370 = load i64, ptr %slot777, align 8
  %v4371 = load i64, ptr %slot776, align 8
  %p4372 = inttoptr i64 %v4370 to ptr
  %p4373 = inttoptr i64 %v4371 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4373, ptr %p4372, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v4374 = load i64, ptr %slot13, align 8
  %p4375 = inttoptr i64 %v4374 to ptr
  store i32 2, ptr %p4375, align 4, !alias.scope !3, !noalias !4
  %v4376 = load i64, ptr %slot20, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %ld4378 = load i32, ptr %p4377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4378, ptr %slot778, align 8
  %v4379 = load i32, ptr %slot778, align 8
  %v4380 = load i64, ptr %slot13, align 8
  %p4381 = inttoptr i64 %v4380 to ptr
  store i32 %v4379, ptr %p4381, align 4, !alias.scope !3, !noalias !4
  %v4382 = load i64, ptr %slot19, align 8
  %p4383 = inttoptr i64 %v4382 to ptr
  store i32 0, ptr %p4383, align 4, !alias.scope !3, !noalias !4
  %v4384 = load i64, ptr %slot12, align 8
  %p4385 = inttoptr i64 %v4384 to ptr
  store i32 1, ptr %p4385, align 4, !alias.scope !3, !noalias !4
  %v4386 = load i64, ptr %slot776, align 8
  %v4387 = load i64, ptr %slot36, align 8
  %p4388 = inttoptr i64 %v4387 to ptr
  store i64 %v4386, ptr %p4388, align 8, !alias.scope !3, !noalias !4
  br label %bb_i50
bb_i49:
  %v4389 = load i64, ptr %slot36, align 8
  %p4390 = inttoptr i64 %v4389 to ptr
  %ld4391 = load i64, ptr %p4390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4391, ptr %slot779, align 8
  %v4392 = load i64, ptr %slot12, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  %ld4394 = load i32, ptr %p4393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4394, ptr %slot780, align 8
  %v4395 = load i32, ptr %slot780, align 8
  %cv4396 = zext i32 %v4395 to i64
  %cond4397 = icmp ne i64 %cv4396, 0
  br i1 %cond4397, label %bb_rcslotdrop961, label %bb_rcslotdone961
bb_rcslotdrop961:
  %v4398 = load i64, ptr %slot12, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  store i32 0, ptr %p4399, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone961
bb_rcslotdone961:
  %v4400 = load i64, ptr %slot10, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  %ld4402 = load i32, ptr %p4401, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4402, ptr %slot781, align 8
  %v4403 = load i32, ptr %slot781, align 8
  %cv4404 = zext i32 %v4403 to i64
  %cond4405 = icmp ne i64 %cv4404, 0
  br i1 %cond4405, label %bb_rcslotdrop964, label %bb_rcslotdone964
bb_rcslotdrop964:
  %v4406 = load i64, ptr %slot10, align 8
  %p4407 = inttoptr i64 %v4406 to ptr
  store i32 0, ptr %p4407, align 4, !alias.scope !3, !noalias !4
  %v4408 = load i64, ptr %slot35, align 8
  store i64 %v4408, ptr %slot782, align 8
  %v4409 = load i64, ptr %slot11, align 8
  %p4410 = inttoptr i64 %v4409 to ptr
  %ld4411 = load i32, ptr %p4410, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4411, ptr %slot783, align 8
  %v4412 = load i32, ptr %slot783, align 8
  %op4413 = and i32 %v4412, 28
  store i32 %op4413, ptr %slot784, align 8
  %v4414 = load i32, ptr %slot784, align 8
  %cv4415 = zext i32 %v4414 to i64
  %cond4416 = icmp ne i64 %cv4415, 0
  br i1 %cond4416, label %bb_rcslotrole964, label %bb_rcslotowner964
bb_rcslotrole964:
  %v4417 = load i64, ptr %slot54, align 8
  store i64 %v4417, ptr %slot785, align 8
  %v4418 = load i64, ptr %slot785, align 8
  %v4419 = load i64, ptr %slot782, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4418, i64 %v4419) nomerge, !dbg !150
  br label %bb_rcslotdone964
bb_rcslotowner964:
  %v4420 = load i64, ptr %slot54, align 8
  store i64 %v4420, ptr %slot786, align 8
  %v4421 = load i64, ptr %slot786, align 8
  %v4422 = load i64, ptr %slot782, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4421, i64 %v4422) nomerge, !dbg !150
  br label %bb_rcslotdone964
bb_rcslotdone964:
  %v4423 = load i64, ptr %slot8, align 8
  %p4424 = inttoptr i64 %v4423 to ptr
  %ld4425 = load i32, ptr %p4424, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4425, ptr %slot787, align 8
  %v4426 = load i32, ptr %slot787, align 8
  %cv4427 = zext i32 %v4426 to i64
  %cond4428 = icmp ne i64 %cv4427, 0
  br i1 %cond4428, label %bb_rcslotdrop973, label %bb_rcslotdone973
bb_rcslotdrop973:
  %v4429 = load i64, ptr %slot8, align 8
  %p4430 = inttoptr i64 %v4429 to ptr
  store i32 0, ptr %p4430, align 4, !alias.scope !3, !noalias !4
  %v4431 = load i64, ptr %slot33, align 8
  store i64 %v4431, ptr %slot788, align 8
  %v4432 = load i64, ptr %slot9, align 8
  %p4433 = inttoptr i64 %v4432 to ptr
  %ld4434 = load i32, ptr %p4433, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4434, ptr %slot789, align 8
  %v4435 = load i32, ptr %slot789, align 8
  %op4436 = and i32 %v4435, 28
  store i32 %op4436, ptr %slot790, align 8
  %v4437 = load i32, ptr %slot790, align 8
  %cv4438 = zext i32 %v4437 to i64
  %cond4439 = icmp ne i64 %cv4438, 0
  br i1 %cond4439, label %bb_rcslotrole973, label %bb_rcslotowner973
bb_rcslotrole973:
  %v4440 = load i64, ptr %slot54, align 8
  store i64 %v4440, ptr %slot791, align 8
  %v4441 = load i64, ptr %slot788, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  %ld4443 = load i64, ptr %p4442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4443, ptr %slot792, align 8
  %v4444 = load i64, ptr %slot792, align 8
  %cmp4445 = icmp ne i64 %v4444, 0
  %cv4446 = zext i1 %cmp4445 to i32
  store i32 %cv4446, ptr %slot793, align 8
  %v4447 = load i32, ptr %slot793, align 8
  %cv4448 = zext i32 %v4447 to i64
  %cond4449 = icmp ne i64 %cv4448, 0
  br i1 %cond4449, label %bb_rcgnn989, label %bb_rcgdone989
bb_rcgnn989:
  %v4450 = load i64, ptr %slot792, align 8
  %op4451 = sub i64 %v4450, 16
  store i64 %op4451, ptr %slot794, align 8
  %v4452 = load i64, ptr %slot792, align 8
  %p4453 = inttoptr i64 %v4452 to ptr
  %rgep4454 = getelementptr i8, ptr %p4453, i64 -16
  %ld4455 = load i64, ptr %rgep4454, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4455, ptr %slot795, align 8
  %v4456 = load i64, ptr %slot795, align 8
  %op4457 = and i64 %v4456, 4611686018427387906
  store i64 %op4457, ptr %slot796, align 8
  %v4458 = load i64, ptr %slot796, align 8
  %cmp4459 = icmp ne i64 %v4458, 0
  %cv4460 = zext i1 %cmp4459 to i32
  store i32 %cv4460, ptr %slot797, align 8
  %v4461 = load i32, ptr %slot797, align 8
  %cv4462 = zext i32 %v4461 to i64
  %cond4463 = icmp ne i64 %cv4462, 0
  br i1 %cond4463, label %bb_rcgclear989, label %bb_rcgcounted989
bb_rcgcounted989:
  %v4464 = load i64, ptr %slot792, align 8
  %op4465 = sub i64 %v4464, 24
  store i64 %op4465, ptr %slot798, align 8
  %v4466 = load i64, ptr %slot792, align 8
  %p4467 = inttoptr i64 %v4466 to ptr
  %rgep4468 = getelementptr i8, ptr %p4467, i64 -24
  %ld4469 = load i64, ptr %rgep4468, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4469, ptr %slot799, align 8
  %v4470 = load i64, ptr %slot799, align 8
  %op4471 = sub i64 %v4470, 1
  store i64 %op4471, ptr %slot800, align 8
  %v4472 = load i64, ptr %slot800, align 8
  %cmp4473 = icmp eq i64 %v4472, 0
  %cv4474 = zext i1 %cmp4473 to i32
  store i32 %cv4474, ptr %slot801, align 8
  %v4475 = load i32, ptr %slot801, align 8
  %cv4476 = zext i32 %v4475 to i64
  %cond4477 = icmp ne i64 %cv4476, 0
  br i1 %cond4477, label %bb_rcglast989, label %bb_rcgdec989
bb_rcglast989:
  %v4478 = load i64, ptr %slot792, align 8
  %op4479 = sub i64 %v4478, 32
  store i64 %op4479, ptr %slot802, align 8
  %v4480 = load i64, ptr %slot792, align 8
  %p4481 = inttoptr i64 %v4480 to ptr
  %rgep4482 = getelementptr i8, ptr %p4481, i64 -32
  %ld4483 = load i64, ptr %rgep4482, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4483, ptr %slot803, align 8
  %v4484 = load i64, ptr %slot803, align 8
  %cmp4485 = icmp ne i64 %v4484, 0
  %cv4486 = zext i1 %cmp4485 to i32
  store i32 %cv4486, ptr %slot804, align 8
  %v4487 = load i32, ptr %slot804, align 8
  %cv4488 = zext i32 %v4487 to i64
  %cond4489 = icmp ne i64 %cv4488, 0
  br i1 %cond4489, label %bb_rcgdec989, label %bb_rcgslow989
bb_rcgslow989:
  %v4490 = load i64, ptr %slot791, align 8
  %v4491 = load i64, ptr %slot788, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4490, i64 %v4491) nomerge, !dbg !150
  br label %bb_rcgdone989
bb_rcgdec989:
  %v4492 = load i64, ptr %slot800, align 8
  %v4493 = load i64, ptr %slot792, align 8
  %p4494 = inttoptr i64 %v4493 to ptr
  %rgep4495 = getelementptr i8, ptr %p4494, i64 -24
  store i64 %v4492, ptr %rgep4495, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear989
bb_rcgclear989:
  %v4496 = load i64, ptr %slot788, align 8
  %p4497 = inttoptr i64 %v4496 to ptr
  store i64 0, ptr %p4497, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone989
bb_rcgdone989:
  br label %bb_rcslotdone973
bb_rcslotowner973:
  %v4498 = load i64, ptr %slot54, align 8
  store i64 %v4498, ptr %slot805, align 8
  %v4499 = load i64, ptr %slot788, align 8
  %p4500 = inttoptr i64 %v4499 to ptr
  %ld4501 = load i64, ptr %p4500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4501, ptr %slot806, align 8
  %v4502 = load i64, ptr %slot806, align 8
  %cmp4503 = icmp ne i64 %v4502, 0
  %cv4504 = zext i1 %cmp4503 to i32
  store i32 %cv4504, ptr %slot807, align 8
  %v4505 = load i32, ptr %slot807, align 8
  %cv4506 = zext i32 %v4505 to i64
  %cond4507 = icmp ne i64 %cv4506, 0
  br i1 %cond4507, label %bb_rcgnn1004, label %bb_rcgdone1004
bb_rcgnn1004:
  %v4508 = load i64, ptr %slot806, align 8
  %op4509 = sub i64 %v4508, 16
  store i64 %op4509, ptr %slot808, align 8
  %v4510 = load i64, ptr %slot806, align 8
  %p4511 = inttoptr i64 %v4510 to ptr
  %rgep4512 = getelementptr i8, ptr %p4511, i64 -16
  %ld4513 = load i64, ptr %rgep4512, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4513, ptr %slot809, align 8
  %v4514 = load i64, ptr %slot809, align 8
  %op4515 = and i64 %v4514, 4611686018427387906
  store i64 %op4515, ptr %slot810, align 8
  %v4516 = load i64, ptr %slot810, align 8
  %cmp4517 = icmp ne i64 %v4516, 0
  %cv4518 = zext i1 %cmp4517 to i32
  store i32 %cv4518, ptr %slot811, align 8
  %v4519 = load i32, ptr %slot811, align 8
  %cv4520 = zext i32 %v4519 to i64
  %cond4521 = icmp ne i64 %cv4520, 0
  br i1 %cond4521, label %bb_rcgclear1004, label %bb_rcgcounted1004
bb_rcgcounted1004:
  %v4522 = load i64, ptr %slot806, align 8
  %op4523 = sub i64 %v4522, 32
  store i64 %op4523, ptr %slot812, align 8
  %v4524 = load i64, ptr %slot806, align 8
  %p4525 = inttoptr i64 %v4524 to ptr
  %rgep4526 = getelementptr i8, ptr %p4525, i64 -32
  %ld4527 = load i64, ptr %rgep4526, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4527, ptr %slot813, align 8
  %v4528 = load i64, ptr %slot813, align 8
  %op4529 = sub i64 %v4528, 1
  store i64 %op4529, ptr %slot814, align 8
  %v4530 = load i64, ptr %slot814, align 8
  %cmp4531 = icmp eq i64 %v4530, 0
  %cv4532 = zext i1 %cmp4531 to i32
  store i32 %cv4532, ptr %slot815, align 8
  %v4533 = load i32, ptr %slot815, align 8
  %cv4534 = zext i32 %v4533 to i64
  %cond4535 = icmp ne i64 %cv4534, 0
  br i1 %cond4535, label %bb_rcglast1004, label %bb_rcgdec1004
bb_rcglast1004:
  %v4536 = load i64, ptr %slot806, align 8
  %op4537 = sub i64 %v4536, 24
  store i64 %op4537, ptr %slot816, align 8
  %v4538 = load i64, ptr %slot806, align 8
  %p4539 = inttoptr i64 %v4538 to ptr
  %rgep4540 = getelementptr i8, ptr %p4539, i64 -24
  %ld4541 = load i64, ptr %rgep4540, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4541, ptr %slot817, align 8
  %v4542 = load i64, ptr %slot817, align 8
  %cmp4543 = icmp ne i64 %v4542, 0
  %cv4544 = zext i1 %cmp4543 to i32
  store i32 %cv4544, ptr %slot818, align 8
  %v4545 = load i32, ptr %slot818, align 8
  %cv4546 = zext i32 %v4545 to i64
  %cond4547 = icmp ne i64 %cv4546, 0
  br i1 %cond4547, label %bb_rcgdec1004, label %bb_rcgslow1004
bb_rcgslow1004:
  %v4548 = load i64, ptr %slot805, align 8
  %v4549 = load i64, ptr %slot788, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4548, i64 %v4549) nomerge, !dbg !150
  br label %bb_rcgdone1004
bb_rcgdec1004:
  %v4550 = load i64, ptr %slot814, align 8
  %v4551 = load i64, ptr %slot806, align 8
  %p4552 = inttoptr i64 %v4551 to ptr
  %rgep4553 = getelementptr i8, ptr %p4552, i64 -32
  store i64 %v4550, ptr %rgep4553, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1004
bb_rcgclear1004:
  %v4554 = load i64, ptr %slot788, align 8
  %p4555 = inttoptr i64 %v4554 to ptr
  store i64 0, ptr %p4555, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1004
bb_rcgdone1004:
  br label %bb_rcslotdone973
bb_rcslotdone973:
  %v4556 = load i64, ptr %slot6, align 8
  %p4557 = inttoptr i64 %v4556 to ptr
  %ld4558 = load i32, ptr %p4557, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4558, ptr %slot819, align 8
  %v4559 = load i32, ptr %slot819, align 8
  %cv4560 = zext i32 %v4559 to i64
  %cond4561 = icmp ne i64 %cv4560, 0
  br i1 %cond4561, label %bb_rcslotdrop1010, label %bb_rcslotdone1010
bb_rcslotdrop1010:
  %v4562 = load i64, ptr %slot6, align 8
  %p4563 = inttoptr i64 %v4562 to ptr
  store i32 0, ptr %p4563, align 4, !alias.scope !3, !noalias !4
  %v4564 = load i64, ptr %slot32, align 8
  store i64 %v4564, ptr %slot820, align 8
  %v4565 = load i64, ptr %slot7, align 8
  %p4566 = inttoptr i64 %v4565 to ptr
  %ld4567 = load i32, ptr %p4566, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4567, ptr %slot821, align 8
  %v4568 = load i32, ptr %slot821, align 8
  %op4569 = and i32 %v4568, 28
  store i32 %op4569, ptr %slot822, align 8
  %v4570 = load i32, ptr %slot822, align 8
  %cv4571 = zext i32 %v4570 to i64
  %cond4572 = icmp ne i64 %cv4571, 0
  br i1 %cond4572, label %bb_rcslotrole1010, label %bb_rcslotowner1010
bb_rcslotrole1010:
  %v4573 = load i64, ptr %slot54, align 8
  store i64 %v4573, ptr %slot823, align 8
  %v4574 = load i64, ptr %slot820, align 8
  %p4575 = inttoptr i64 %v4574 to ptr
  %ld4576 = load i64, ptr %p4575, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4576, ptr %slot824, align 8
  %v4577 = load i64, ptr %slot824, align 8
  %cmp4578 = icmp ne i64 %v4577, 0
  %cv4579 = zext i1 %cmp4578 to i32
  store i32 %cv4579, ptr %slot825, align 8
  %v4580 = load i32, ptr %slot825, align 8
  %cv4581 = zext i32 %v4580 to i64
  %cond4582 = icmp ne i64 %cv4581, 0
  br i1 %cond4582, label %bb_rcgnn1026, label %bb_rcgdone1026
bb_rcgnn1026:
  %v4583 = load i64, ptr %slot824, align 8
  %op4584 = sub i64 %v4583, 16
  store i64 %op4584, ptr %slot826, align 8
  %v4585 = load i64, ptr %slot824, align 8
  %p4586 = inttoptr i64 %v4585 to ptr
  %rgep4587 = getelementptr i8, ptr %p4586, i64 -16
  %ld4588 = load i64, ptr %rgep4587, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4588, ptr %slot827, align 8
  %v4589 = load i64, ptr %slot827, align 8
  %op4590 = and i64 %v4589, 4611686018427387906
  store i64 %op4590, ptr %slot828, align 8
  %v4591 = load i64, ptr %slot828, align 8
  %cmp4592 = icmp ne i64 %v4591, 0
  %cv4593 = zext i1 %cmp4592 to i32
  store i32 %cv4593, ptr %slot829, align 8
  %v4594 = load i32, ptr %slot829, align 8
  %cv4595 = zext i32 %v4594 to i64
  %cond4596 = icmp ne i64 %cv4595, 0
  br i1 %cond4596, label %bb_rcgclear1026, label %bb_rcgcounted1026
bb_rcgcounted1026:
  %v4597 = load i64, ptr %slot824, align 8
  %op4598 = sub i64 %v4597, 24
  store i64 %op4598, ptr %slot830, align 8
  %v4599 = load i64, ptr %slot824, align 8
  %p4600 = inttoptr i64 %v4599 to ptr
  %rgep4601 = getelementptr i8, ptr %p4600, i64 -24
  %ld4602 = load i64, ptr %rgep4601, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4602, ptr %slot831, align 8
  %v4603 = load i64, ptr %slot831, align 8
  %op4604 = sub i64 %v4603, 1
  store i64 %op4604, ptr %slot832, align 8
  %v4605 = load i64, ptr %slot832, align 8
  %cmp4606 = icmp eq i64 %v4605, 0
  %cv4607 = zext i1 %cmp4606 to i32
  store i32 %cv4607, ptr %slot833, align 8
  %v4608 = load i32, ptr %slot833, align 8
  %cv4609 = zext i32 %v4608 to i64
  %cond4610 = icmp ne i64 %cv4609, 0
  br i1 %cond4610, label %bb_rcglast1026, label %bb_rcgdec1026
bb_rcglast1026:
  %v4611 = load i64, ptr %slot824, align 8
  %op4612 = sub i64 %v4611, 32
  store i64 %op4612, ptr %slot834, align 8
  %v4613 = load i64, ptr %slot824, align 8
  %p4614 = inttoptr i64 %v4613 to ptr
  %rgep4615 = getelementptr i8, ptr %p4614, i64 -32
  %ld4616 = load i64, ptr %rgep4615, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4616, ptr %slot835, align 8
  %v4617 = load i64, ptr %slot835, align 8
  %cmp4618 = icmp ne i64 %v4617, 0
  %cv4619 = zext i1 %cmp4618 to i32
  store i32 %cv4619, ptr %slot836, align 8
  %v4620 = load i32, ptr %slot836, align 8
  %cv4621 = zext i32 %v4620 to i64
  %cond4622 = icmp ne i64 %cv4621, 0
  br i1 %cond4622, label %bb_rcgdec1026, label %bb_rcgslow1026
bb_rcgslow1026:
  %v4623 = load i64, ptr %slot823, align 8
  %v4624 = load i64, ptr %slot820, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v4623, i64 %v4624) nomerge, !dbg !150
  br label %bb_rcgdone1026
bb_rcgdec1026:
  %v4625 = load i64, ptr %slot832, align 8
  %v4626 = load i64, ptr %slot824, align 8
  %p4627 = inttoptr i64 %v4626 to ptr
  %rgep4628 = getelementptr i8, ptr %p4627, i64 -24
  store i64 %v4625, ptr %rgep4628, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1026
bb_rcgclear1026:
  %v4629 = load i64, ptr %slot820, align 8
  %p4630 = inttoptr i64 %v4629 to ptr
  store i64 0, ptr %p4630, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1026
bb_rcgdone1026:
  br label %bb_rcslotdone1010
bb_rcslotowner1010:
  %v4631 = load i64, ptr %slot54, align 8
  store i64 %v4631, ptr %slot837, align 8
  %v4632 = load i64, ptr %slot820, align 8
  %p4633 = inttoptr i64 %v4632 to ptr
  %ld4634 = load i64, ptr %p4633, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4634, ptr %slot838, align 8
  %v4635 = load i64, ptr %slot838, align 8
  %cmp4636 = icmp ne i64 %v4635, 0
  %cv4637 = zext i1 %cmp4636 to i32
  store i32 %cv4637, ptr %slot839, align 8
  %v4638 = load i32, ptr %slot839, align 8
  %cv4639 = zext i32 %v4638 to i64
  %cond4640 = icmp ne i64 %cv4639, 0
  br i1 %cond4640, label %bb_rcgnn1041, label %bb_rcgdone1041
bb_rcgnn1041:
  %v4641 = load i64, ptr %slot838, align 8
  %op4642 = sub i64 %v4641, 16
  store i64 %op4642, ptr %slot840, align 8
  %v4643 = load i64, ptr %slot838, align 8
  %p4644 = inttoptr i64 %v4643 to ptr
  %rgep4645 = getelementptr i8, ptr %p4644, i64 -16
  %ld4646 = load i64, ptr %rgep4645, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4646, ptr %slot841, align 8
  %v4647 = load i64, ptr %slot841, align 8
  %op4648 = and i64 %v4647, 4611686018427387906
  store i64 %op4648, ptr %slot842, align 8
  %v4649 = load i64, ptr %slot842, align 8
  %cmp4650 = icmp ne i64 %v4649, 0
  %cv4651 = zext i1 %cmp4650 to i32
  store i32 %cv4651, ptr %slot843, align 8
  %v4652 = load i32, ptr %slot843, align 8
  %cv4653 = zext i32 %v4652 to i64
  %cond4654 = icmp ne i64 %cv4653, 0
  br i1 %cond4654, label %bb_rcgclear1041, label %bb_rcgcounted1041
bb_rcgcounted1041:
  %v4655 = load i64, ptr %slot838, align 8
  %op4656 = sub i64 %v4655, 32
  store i64 %op4656, ptr %slot844, align 8
  %v4657 = load i64, ptr %slot838, align 8
  %p4658 = inttoptr i64 %v4657 to ptr
  %rgep4659 = getelementptr i8, ptr %p4658, i64 -32
  %ld4660 = load i64, ptr %rgep4659, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4660, ptr %slot845, align 8
  %v4661 = load i64, ptr %slot845, align 8
  %op4662 = sub i64 %v4661, 1
  store i64 %op4662, ptr %slot846, align 8
  %v4663 = load i64, ptr %slot846, align 8
  %cmp4664 = icmp eq i64 %v4663, 0
  %cv4665 = zext i1 %cmp4664 to i32
  store i32 %cv4665, ptr %slot847, align 8
  %v4666 = load i32, ptr %slot847, align 8
  %cv4667 = zext i32 %v4666 to i64
  %cond4668 = icmp ne i64 %cv4667, 0
  br i1 %cond4668, label %bb_rcglast1041, label %bb_rcgdec1041
bb_rcglast1041:
  %v4669 = load i64, ptr %slot838, align 8
  %op4670 = sub i64 %v4669, 24
  store i64 %op4670, ptr %slot848, align 8
  %v4671 = load i64, ptr %slot838, align 8
  %p4672 = inttoptr i64 %v4671 to ptr
  %rgep4673 = getelementptr i8, ptr %p4672, i64 -24
  %ld4674 = load i64, ptr %rgep4673, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4674, ptr %slot849, align 8
  %v4675 = load i64, ptr %slot849, align 8
  %cmp4676 = icmp ne i64 %v4675, 0
  %cv4677 = zext i1 %cmp4676 to i32
  store i32 %cv4677, ptr %slot850, align 8
  %v4678 = load i32, ptr %slot850, align 8
  %cv4679 = zext i32 %v4678 to i64
  %cond4680 = icmp ne i64 %cv4679, 0
  br i1 %cond4680, label %bb_rcgdec1041, label %bb_rcgslow1041
bb_rcgslow1041:
  %v4681 = load i64, ptr %slot837, align 8
  %v4682 = load i64, ptr %slot820, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v4681, i64 %v4682) nomerge, !dbg !150
  br label %bb_rcgdone1041
bb_rcgdec1041:
  %v4683 = load i64, ptr %slot846, align 8
  %v4684 = load i64, ptr %slot838, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  %rgep4686 = getelementptr i8, ptr %p4685, i64 -32
  store i64 %v4683, ptr %rgep4686, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1041
bb_rcgclear1041:
  %v4687 = load i64, ptr %slot820, align 8
  %p4688 = inttoptr i64 %v4687 to ptr
  store i64 0, ptr %p4688, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1041
bb_rcgdone1041:
  br label %bb_rcslotdone1010
bb_rcslotdone1010:
  %v4689 = load i64, ptr %slot779, align 8
  %p4690 = inttoptr i64 %v4689 to ptr
  %ret4691 = load { i64, i64 }, ptr %p4690, align 8
  ret { i64, i64 } %ret4691
bb_i50:
  %v4692 = load i64, ptr %slot36, align 8
  %p4693 = inttoptr i64 %v4692 to ptr
  %ld4694 = load i64, ptr %p4693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4694, ptr %slot851, align 8
  %v4695 = load i64, ptr %slot12, align 8
  %p4696 = inttoptr i64 %v4695 to ptr
  %ld4697 = load i32, ptr %p4696, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4697, ptr %slot852, align 8
  %v4698 = load i64, ptr %slot13, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  %ld4700 = load i32, ptr %p4699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4700, ptr %slot853, align 8
  %v4701 = load i32, ptr %slot853, align 8
  %op4702 = and i32 %v4701, 24
  store i32 %op4702, ptr %slot853, align 8
  %v4703 = load i32, ptr %slot853, align 8
  %cmp4704 = icmp eq i32 %v4703, 0
  %cv4705 = zext i1 %cmp4704 to i32
  store i32 %cv4705, ptr %slot854, align 8
  %v4706 = load i32, ptr %slot852, align 8
  %v4707 = load i32, ptr %slot854, align 8
  %op4708 = and i32 %v4706, %v4707
  store i32 %op4708, ptr %slot855, align 8
  %v4709 = load i32, ptr %slot855, align 8
  %cv4710 = zext i32 %v4709 to i64
  %cond4711 = icmp ne i64 %cv4710, 0
  br i1 %cond4711, label %bb_rctake1055, label %bb_rccopy1055
bb_rctake1055:
  %v4712 = load i64, ptr %slot28, align 8
  store i64 %v4712, ptr %slot856, align 8
  %v4713 = load i64, ptr %slot55, align 8
  store i64 %v4713, ptr %slot857, align 8
  %v4714 = load i64, ptr %slot54, align 8
  %v4715 = load i64, ptr %slot856, align 8
  %v4716 = load i64, ptr %slot851, align 8
  %v4717 = load i64, ptr %slot857, align 8
  %cv4718 = trunc i64 %v4717 to i32
  %call4719 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v4714, i64 %v4715, i64 %v4716, i32 %cv4718) nomerge, !dbg !152
  store i32 %call4719, ptr %slot858, align 8
  %v4720 = load i32, ptr %slot858, align 8
  %cv4721 = zext i32 %v4720 to i64
  %cond4722 = icmp ne i64 %cv4721, 0
  br i1 %cond4722, label %bb_rcsuccess1065, label %bb_rcfailure1065
bb_rcfailure1065:
  %v4723 = load i64, ptr %slot54, align 8
  %p4724 = inttoptr i64 %v4723 to ptr
  %call4725 = call i32 @myl_rc_take_failure(ptr %p4724) nomerge, !dbg !152
  store i32 %call4725, ptr %slot859, align 8
  %v4726 = load i64, ptr %slot1, align 8
  %p4727 = inttoptr i64 %v4726 to ptr
  %v4728 = load i32, ptr %slot859, align 8
  %call4729 = call i32 @myl_qbe_rc_status(ptr %p4727, i32 %v4728) nomerge, !dbg !152
  store i32 %call4729, ptr %slot860, align 8
  br label %bb_failure
bb_rcsuccess1065:
  %v4730 = load i64, ptr %slot12, align 8
  %p4731 = inttoptr i64 %v4730 to ptr
  store i32 0, ptr %p4731, align 4, !alias.scope !3, !noalias !4
  %v4732 = load i64, ptr %slot20, align 8
  %p4733 = inttoptr i64 %v4732 to ptr
  store i32 2, ptr %p4733, align 4, !alias.scope !3, !noalias !4
  %v4734 = load i64, ptr %slot19, align 8
  %p4735 = inttoptr i64 %v4734 to ptr
  store i32 1, ptr %p4735, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1055
bb_rccopy1055:
  %v4736 = load i64, ptr %slot28, align 8
  store i64 %v4736, ptr %slot861, align 8
  %v4737 = load i64, ptr %slot55, align 8
  store i64 %v4737, ptr %slot862, align 8
  %v4738 = load i64, ptr %slot54, align 8
  %v4739 = load i64, ptr %slot861, align 8
  %v4740 = load i64, ptr %slot851, align 8
  %v4741 = load i64, ptr %slot862, align 8
  %cv4742 = trunc i64 %v4741 to i32
  %call4743 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v4738, i64 %v4739, i64 %v4740, i32 %cv4742) nomerge, !dbg !152
  store i32 %call4743, ptr %slot863, align 8
  %v4744 = load i32, ptr %slot863, align 8
  %cv4745 = zext i32 %v4744 to i64
  %cond4746 = icmp ne i64 %cv4745, 0
  br i1 %cond4746, label %bb_rcsuccess1074, label %bb_rcfailure1074
bb_rcfailure1074:
  %v4747 = load i64, ptr %slot54, align 8
  %p4748 = inttoptr i64 %v4747 to ptr
  %call4749 = call i32 @myl_rc_take_failure(ptr %p4748) nomerge, !dbg !152
  store i32 %call4749, ptr %slot864, align 8
  %v4750 = load i64, ptr %slot1, align 8
  %p4751 = inttoptr i64 %v4750 to ptr
  %v4752 = load i32, ptr %slot864, align 8
  %call4753 = call i32 @myl_qbe_rc_status(ptr %p4751, i32 %v4752) nomerge, !dbg !152
  store i32 %call4753, ptr %slot865, align 8
  br label %bb_failure
bb_rcsuccess1074:
  %v4754 = load i64, ptr %slot20, align 8
  %p4755 = inttoptr i64 %v4754 to ptr
  store i32 2, ptr %p4755, align 4, !alias.scope !3, !noalias !4
  %v4756 = load i64, ptr %slot19, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  store i32 1, ptr %p4757, align 4, !alias.scope !3, !noalias !4
  %v4758 = load i64, ptr %slot12, align 8
  %p4759 = inttoptr i64 %v4758 to ptr
  %ld4760 = load i32, ptr %p4759, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4760, ptr %slot866, align 8
  %v4761 = load i32, ptr %slot866, align 8
  %cv4762 = zext i32 %v4761 to i64
  %cond4763 = icmp ne i64 %cv4762, 0
  br i1 %cond4763, label %bb_rcslotdrop1081, label %bb_rcslotdone1081
bb_rcslotdrop1081:
  %v4764 = load i64, ptr %slot12, align 8
  %p4765 = inttoptr i64 %v4764 to ptr
  store i32 0, ptr %p4765, align 4, !alias.scope !3, !noalias !4
  %v4766 = load i64, ptr %slot22, align 8
  store i64 %v4766, ptr %slot867, align 8
  %v4767 = load i64, ptr %slot13, align 8
  %p4768 = inttoptr i64 %v4767 to ptr
  %ld4769 = load i32, ptr %p4768, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4769, ptr %slot868, align 8
  %v4770 = load i32, ptr %slot868, align 8
  %op4771 = and i32 %v4770, 28
  store i32 %op4771, ptr %slot869, align 8
  %v4772 = load i32, ptr %slot869, align 8
  %cv4773 = zext i32 %v4772 to i64
  %cond4774 = icmp ne i64 %cv4773, 0
  br i1 %cond4774, label %bb_rcslotrole1081, label %bb_rcslotowner1081
bb_rcslotrole1081:
  %v4775 = load i64, ptr %slot54, align 8
  store i64 %v4775, ptr %slot870, align 8
  %v4776 = load i64, ptr %slot870, align 8
  %v4777 = load i64, ptr %slot867, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4776, i64 %v4777) nomerge, !dbg !152
  br label %bb_rcslotdone1081
bb_rcslotowner1081:
  %v4778 = load i64, ptr %slot54, align 8
  store i64 %v4778, ptr %slot871, align 8
  %v4779 = load i64, ptr %slot871, align 8
  %v4780 = load i64, ptr %slot867, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4779, i64 %v4780) nomerge, !dbg !152
  br label %bb_rcslotdone1081
bb_rcslotdone1081:
  br label %bb_rcprepared1055
bb_rcprepared1055:
  %v4781 = load i64, ptr %slot10, align 8
  %p4782 = inttoptr i64 %v4781 to ptr
  %ld4783 = load i32, ptr %p4782, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4783, ptr %slot872, align 8
  %v4784 = load i32, ptr %slot872, align 8
  %cv4785 = zext i32 %v4784 to i64
  %cond4786 = icmp ne i64 %cv4785, 0
  br i1 %cond4786, label %bb_rcslotdrop1091, label %bb_rcslotdone1091
bb_rcslotdrop1091:
  %v4787 = load i64, ptr %slot10, align 8
  %p4788 = inttoptr i64 %v4787 to ptr
  store i32 0, ptr %p4788, align 4, !alias.scope !3, !noalias !4
  %v4789 = load i64, ptr %slot35, align 8
  store i64 %v4789, ptr %slot873, align 8
  %v4790 = load i64, ptr %slot11, align 8
  %p4791 = inttoptr i64 %v4790 to ptr
  %ld4792 = load i32, ptr %p4791, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4792, ptr %slot874, align 8
  %v4793 = load i32, ptr %slot874, align 8
  %op4794 = and i32 %v4793, 28
  store i32 %op4794, ptr %slot875, align 8
  %v4795 = load i32, ptr %slot875, align 8
  %cv4796 = zext i32 %v4795 to i64
  %cond4797 = icmp ne i64 %cv4796, 0
  br i1 %cond4797, label %bb_rcslotrole1091, label %bb_rcslotowner1091
bb_rcslotrole1091:
  %v4798 = load i64, ptr %slot54, align 8
  store i64 %v4798, ptr %slot876, align 8
  %v4799 = load i64, ptr %slot876, align 8
  %v4800 = load i64, ptr %slot873, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4799, i64 %v4800) nomerge, !dbg !152
  br label %bb_rcslotdone1091
bb_rcslotowner1091:
  %v4801 = load i64, ptr %slot54, align 8
  store i64 %v4801, ptr %slot877, align 8
  %v4802 = load i64, ptr %slot877, align 8
  %v4803 = load i64, ptr %slot873, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4802, i64 %v4803) nomerge, !dbg !152
  br label %bb_rcslotdone1091
bb_rcslotdone1091:
  %v4804 = load i64, ptr %slot35, align 8
  store i64 %v4804, ptr %slot878, align 8
  %v4805 = load i64, ptr %slot28, align 8
  store i64 %v4805, ptr %slot879, align 8
  %v4806 = load i64, ptr %slot879, align 8
  %v4807 = load i64, ptr %slot878, align 8
  %p4808 = inttoptr i64 %v4806 to ptr
  %p4809 = inttoptr i64 %v4807 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4809, ptr %p4808, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v4810 = load i64, ptr %slot19, align 8
  %p4811 = inttoptr i64 %v4810 to ptr
  store i32 0, ptr %p4811, align 4, !alias.scope !3, !noalias !4
  %v4812 = load i64, ptr %slot11, align 8
  %p4813 = inttoptr i64 %v4812 to ptr
  store i32 2, ptr %p4813, align 4, !alias.scope !3, !noalias !4
  %v4814 = load i64, ptr %slot20, align 8
  %p4815 = inttoptr i64 %v4814 to ptr
  %ld4816 = load i32, ptr %p4815, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4816, ptr %slot880, align 8
  %v4817 = load i32, ptr %slot880, align 8
  %v4818 = load i64, ptr %slot11, align 8
  %p4819 = inttoptr i64 %v4818 to ptr
  store i32 %v4817, ptr %p4819, align 4, !alias.scope !3, !noalias !4
  %v4820 = load i64, ptr %slot10, align 8
  %p4821 = inttoptr i64 %v4820 to ptr
  store i32 1, ptr %p4821, align 4, !alias.scope !3, !noalias !4
  %v4822 = load i64, ptr %slot30, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  %ld4824 = load i64, ptr %p4823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4824, ptr %slot881, align 8
  %v4825 = load i64, ptr %slot881, align 8
  %v4826 = load i64, ptr %slot36, align 8
  %p4827 = inttoptr i64 %v4826 to ptr
  store i64 %v4825, ptr %p4827, align 8, !alias.scope !3, !noalias !4
  %v4828 = load i64, ptr %slot31, align 8
  %p4829 = inttoptr i64 %v4828 to ptr
  %ld4830 = load i64, ptr %p4829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4830, ptr %slot882, align 8
  %v4831 = load i64, ptr %slot882, align 8
  %v4832 = load i64, ptr %slot37, align 8
  %p4833 = inttoptr i64 %v4832 to ptr
  store i64 %v4831, ptr %p4833, align 8, !alias.scope !3, !noalias !4
  %v4834 = load i64, ptr %slot35, align 8
  %v4835 = load i64, ptr %slot38, align 8
  %p4836 = inttoptr i64 %v4835 to ptr
  store i64 %v4834, ptr %p4836, align 8, !alias.scope !3, !noalias !4
  %v4837 = load i64, ptr %slot33, align 8
  %p4838 = inttoptr i64 %v4837 to ptr
  %ld4839 = load i64, ptr %p4838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4839, ptr %slot883, align 8
  %v4840 = load i64, ptr %slot883, align 8
  %v4841 = load i64, ptr %slot39, align 8
  %p4842 = inttoptr i64 %v4841 to ptr
  store i64 %v4840, ptr %p4842, align 8, !alias.scope !3, !noalias !4
  %v4843 = load i64, ptr %slot47, align 8
  store i64 %v4843, ptr %slot884, align 8
  %v4844 = load i64, ptr %slot884, align 8
  %p4845 = inttoptr i64 %v4844 to ptr
  store i64 0, ptr %p4845, align 8, !alias.scope !3, !noalias !4
  %v4846 = load i64, ptr %slot884, align 8
  %p4848 = inttoptr i64 %v4846 to ptr
  %gep4849 = getelementptr i8, ptr %p4848, i64 8
  %op4847 = ptrtoint ptr %gep4849 to i64
  store i64 %op4847, ptr %slot885, align 8
  %v4850 = load i64, ptr %slot885, align 8
  %p4851 = inttoptr i64 %v4850 to ptr
  store i64 0, ptr %p4851, align 8, !alias.scope !3, !noalias !4
  %v4852 = load i64, ptr %slot884, align 8
  %p4854 = inttoptr i64 %v4852 to ptr
  %gep4855 = getelementptr i8, ptr %p4854, i64 16
  %op4853 = ptrtoint ptr %gep4855 to i64
  store i64 %op4853, ptr %slot886, align 8
  %v4856 = load i64, ptr %slot886, align 8
  %p4857 = inttoptr i64 %v4856 to ptr
  store i64 0, ptr %p4857, align 8, !alias.scope !3, !noalias !4
  %v4858 = load i64, ptr %slot884, align 8
  %p4860 = inttoptr i64 %v4858 to ptr
  %gep4861 = getelementptr i8, ptr %p4860, i64 24
  %op4859 = ptrtoint ptr %gep4861 to i64
  store i64 %op4859, ptr %slot887, align 8
  %v4862 = load i64, ptr %slot887, align 8
  %p4863 = inttoptr i64 %v4862 to ptr
  store i64 0, ptr %p4863, align 8, !alias.scope !3, !noalias !4
  %v4864 = load i64, ptr %slot884, align 8
  %p4866 = inttoptr i64 %v4864 to ptr
  %gep4867 = getelementptr i8, ptr %p4866, i64 32
  %op4865 = ptrtoint ptr %gep4867 to i64
  store i64 %op4865, ptr %slot888, align 8
  %v4868 = load i64, ptr %slot888, align 8
  %p4869 = inttoptr i64 %v4868 to ptr
  store i64 0, ptr %p4869, align 8, !alias.scope !3, !noalias !4
  %v4870 = load i64, ptr %slot884, align 8
  %p4872 = inttoptr i64 %v4870 to ptr
  %gep4873 = getelementptr i8, ptr %p4872, i64 40
  %op4871 = ptrtoint ptr %gep4873 to i64
  store i64 %op4871, ptr %slot889, align 8
  %v4874 = load i64, ptr %slot889, align 8
  %p4875 = inttoptr i64 %v4874 to ptr
  store i64 0, ptr %p4875, align 8, !alias.scope !3, !noalias !4
  %v4876 = load i64, ptr %slot884, align 8
  %p4878 = inttoptr i64 %v4876 to ptr
  %gep4879 = getelementptr i8, ptr %p4878, i64 48
  %op4877 = ptrtoint ptr %gep4879 to i64
  store i64 %op4877, ptr %slot890, align 8
  %v4880 = load i64, ptr %slot890, align 8
  %p4881 = inttoptr i64 %v4880 to ptr
  store i64 0, ptr %p4881, align 8, !alias.scope !3, !noalias !4
  %v4882 = load i64, ptr %slot21, align 8
  %p4883 = inttoptr i64 %v4882 to ptr
  store i32 1, ptr %p4883, align 4, !alias.scope !3, !noalias !4
  %v4884 = load i64, ptr %slot55, align 8
  store i64 %v4884, ptr %slot891, align 8
  %v4885 = load i64, ptr %slot37, align 8
  store i64 %v4885, ptr %slot892, align 8
  %v4886 = load i64, ptr %slot884, align 8
  %p4888 = inttoptr i64 %v4886 to ptr
  %gep4889 = getelementptr i8, ptr %p4888, i64 0
  %op4887 = ptrtoint ptr %gep4889 to i64
  store i64 %op4887, ptr %slot893, align 8
  %v4890 = load i64, ptr %slot892, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  %ld4892 = load i64, ptr %p4891, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4892, ptr %slot894, align 8
  %v4893 = load i64, ptr %slot894, align 8
  %v4894 = load i64, ptr %slot893, align 8
  %p4895 = inttoptr i64 %v4894 to ptr
  store i64 %v4893, ptr %p4895, align 8, !alias.scope !3, !noalias !4
  %v4896 = load i64, ptr %slot38, align 8
  %p4897 = inttoptr i64 %v4896 to ptr
  %ld4898 = load i64, ptr %p4897, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4898, ptr %slot895, align 8
  %v4899 = load i64, ptr %slot884, align 8
  %p4901 = inttoptr i64 %v4899 to ptr
  %gep4902 = getelementptr i8, ptr %p4901, i64 8
  %op4900 = ptrtoint ptr %gep4902 to i64
  store i64 %op4900, ptr %slot896, align 8
  %v4903 = load i64, ptr %slot38, align 8
  %p4904 = inttoptr i64 %v4903 to ptr
  %ld4905 = load i64, ptr %p4904, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4905, ptr %slot897, align 8
  %v4906 = load i64, ptr %slot16, align 8
  %p4907 = inttoptr i64 %v4906 to ptr
  %ld4908 = load i32, ptr %p4907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4908, ptr %slot898, align 8
  %v4909 = load i64, ptr %slot17, align 8
  %p4910 = inttoptr i64 %v4909 to ptr
  %ld4911 = load i32, ptr %p4910, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4911, ptr %slot899, align 8
  %v4912 = load i32, ptr %slot899, align 8
  %op4913 = and i32 %v4912, 24
  store i32 %op4913, ptr %slot899, align 8
  %v4914 = load i32, ptr %slot899, align 8
  %cmp4915 = icmp eq i32 %v4914, 0
  %cv4916 = zext i1 %cmp4915 to i32
  store i32 %cv4916, ptr %slot900, align 8
  %v4917 = load i32, ptr %slot898, align 8
  %v4918 = load i32, ptr %slot900, align 8
  %op4919 = and i32 %v4917, %v4918
  store i32 %op4919, ptr %slot901, align 8
  %v4920 = load i32, ptr %slot901, align 8
  %cv4921 = zext i32 %v4920 to i64
  %cond4922 = icmp ne i64 %cv4921, 0
  br i1 %cond4922, label %bb_rctake1124, label %bb_rccopy1124
bb_rctake1124:
  %v4923 = load i64, ptr %slot28, align 8
  store i64 %v4923, ptr %slot902, align 8
  %v4924 = load i64, ptr %slot55, align 8
  store i64 %v4924, ptr %slot903, align 8
  %v4925 = load i64, ptr %slot54, align 8
  %v4926 = load i64, ptr %slot902, align 8
  %v4927 = load i64, ptr %slot897, align 8
  %v4928 = load i64, ptr %slot903, align 8
  %cv4929 = trunc i64 %v4928 to i32
  %call4930 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v4925, i64 %v4926, i64 %v4927, i32 %cv4929) nomerge, !dbg !154
  store i32 %call4930, ptr %slot904, align 8
  %v4931 = load i32, ptr %slot904, align 8
  %cv4932 = zext i32 %v4931 to i64
  %cond4933 = icmp ne i64 %cv4932, 0
  br i1 %cond4933, label %bb_rcsuccess1134, label %bb_rcfailure1134
bb_rcfailure1134:
  %v4934 = load i64, ptr %slot54, align 8
  %p4935 = inttoptr i64 %v4934 to ptr
  %call4936 = call i32 @myl_rc_take_failure(ptr %p4935) nomerge, !dbg !154
  store i32 %call4936, ptr %slot905, align 8
  %v4937 = load i64, ptr %slot1, align 8
  %p4938 = inttoptr i64 %v4937 to ptr
  %v4939 = load i32, ptr %slot905, align 8
  %call4940 = call i32 @myl_qbe_rc_status(ptr %p4938, i32 %v4939) nomerge, !dbg !154
  store i32 %call4940, ptr %slot906, align 8
  br label %bb_failure
bb_rcsuccess1134:
  %v4941 = load i64, ptr %slot16, align 8
  %p4942 = inttoptr i64 %v4941 to ptr
  store i32 0, ptr %p4942, align 4, !alias.scope !3, !noalias !4
  %v4943 = load i64, ptr %slot20, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  store i32 2, ptr %p4944, align 4, !alias.scope !3, !noalias !4
  %v4945 = load i64, ptr %slot19, align 8
  %p4946 = inttoptr i64 %v4945 to ptr
  store i32 1, ptr %p4946, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1124
bb_rccopy1124:
  %v4947 = load i64, ptr %slot28, align 8
  store i64 %v4947, ptr %slot907, align 8
  %v4948 = load i64, ptr %slot55, align 8
  store i64 %v4948, ptr %slot908, align 8
  %v4949 = load i64, ptr %slot54, align 8
  %v4950 = load i64, ptr %slot907, align 8
  %v4951 = load i64, ptr %slot897, align 8
  %v4952 = load i64, ptr %slot908, align 8
  %cv4953 = trunc i64 %v4952 to i32
  %call4954 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v4949, i64 %v4950, i64 %v4951, i32 %cv4953) nomerge, !dbg !154
  store i32 %call4954, ptr %slot909, align 8
  %v4955 = load i32, ptr %slot909, align 8
  %cv4956 = zext i32 %v4955 to i64
  %cond4957 = icmp ne i64 %cv4956, 0
  br i1 %cond4957, label %bb_rcsuccess1143, label %bb_rcfailure1143
bb_rcfailure1143:
  %v4958 = load i64, ptr %slot54, align 8
  %p4959 = inttoptr i64 %v4958 to ptr
  %call4960 = call i32 @myl_rc_take_failure(ptr %p4959) nomerge, !dbg !154
  store i32 %call4960, ptr %slot910, align 8
  %v4961 = load i64, ptr %slot1, align 8
  %p4962 = inttoptr i64 %v4961 to ptr
  %v4963 = load i32, ptr %slot910, align 8
  %call4964 = call i32 @myl_qbe_rc_status(ptr %p4962, i32 %v4963) nomerge, !dbg !154
  store i32 %call4964, ptr %slot911, align 8
  br label %bb_failure
bb_rcsuccess1143:
  %v4965 = load i64, ptr %slot20, align 8
  %p4966 = inttoptr i64 %v4965 to ptr
  store i32 2, ptr %p4966, align 4, !alias.scope !3, !noalias !4
  %v4967 = load i64, ptr %slot19, align 8
  %p4968 = inttoptr i64 %v4967 to ptr
  store i32 1, ptr %p4968, align 4, !alias.scope !3, !noalias !4
  %v4969 = load i64, ptr %slot16, align 8
  %p4970 = inttoptr i64 %v4969 to ptr
  %ld4971 = load i32, ptr %p4970, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4971, ptr %slot912, align 8
  %v4972 = load i32, ptr %slot912, align 8
  %cv4973 = zext i32 %v4972 to i64
  %cond4974 = icmp ne i64 %cv4973, 0
  br i1 %cond4974, label %bb_rcslotdrop1150, label %bb_rcslotdone1150
bb_rcslotdrop1150:
  %v4975 = load i64, ptr %slot16, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  store i32 0, ptr %p4976, align 4, !alias.scope !3, !noalias !4
  %v4977 = load i64, ptr %slot24, align 8
  store i64 %v4977, ptr %slot913, align 8
  %v4978 = load i64, ptr %slot17, align 8
  %p4979 = inttoptr i64 %v4978 to ptr
  %ld4980 = load i32, ptr %p4979, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4980, ptr %slot914, align 8
  %v4981 = load i32, ptr %slot914, align 8
  %op4982 = and i32 %v4981, 28
  store i32 %op4982, ptr %slot915, align 8
  %v4983 = load i32, ptr %slot915, align 8
  %cv4984 = zext i32 %v4983 to i64
  %cond4985 = icmp ne i64 %cv4984, 0
  br i1 %cond4985, label %bb_rcslotrole1150, label %bb_rcslotowner1150
bb_rcslotrole1150:
  %v4986 = load i64, ptr %slot54, align 8
  store i64 %v4986, ptr %slot916, align 8
  %v4987 = load i64, ptr %slot916, align 8
  %v4988 = load i64, ptr %slot913, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4987, i64 %v4988) nomerge, !dbg !154
  br label %bb_rcslotdone1150
bb_rcslotowner1150:
  %v4989 = load i64, ptr %slot54, align 8
  store i64 %v4989, ptr %slot917, align 8
  %v4990 = load i64, ptr %slot917, align 8
  %v4991 = load i64, ptr %slot913, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4990, i64 %v4991) nomerge, !dbg !154
  br label %bb_rcslotdone1150
bb_rcslotdone1150:
  br label %bb_rcprepared1124
bb_rcprepared1124:
  %v4992 = load i64, ptr %slot28, align 8
  store i64 %v4992, ptr %slot918, align 8
  %v4993 = load i64, ptr %slot918, align 8
  %v4994 = load i64, ptr %slot896, align 8
  %p4995 = inttoptr i64 %v4993 to ptr
  %p4996 = inttoptr i64 %v4994 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4996, ptr %p4995, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v4997 = load i64, ptr %slot19, align 8
  %p4998 = inttoptr i64 %v4997 to ptr
  store i32 0, ptr %p4998, align 4, !alias.scope !3, !noalias !4
  %v4999 = load i64, ptr %slot39, align 8
  %p5000 = inttoptr i64 %v4999 to ptr
  %ld5001 = load i64, ptr %p5000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5001, ptr %slot919, align 8
  %v5002 = load i64, ptr %slot919, align 8
  %v5003 = load i64, ptr %slot27, align 8
  %p5004 = inttoptr i64 %v5003 to ptr
  store i64 %v5002, ptr %p5004, align 8, !alias.scope !3, !noalias !4
  %v5005 = load i64, ptr %slot27, align 8
  store i64 %v5005, ptr %slot920, align 8
  %v5006 = load i64, ptr %slot884, align 8
  %p5008 = inttoptr i64 %v5006 to ptr
  %gep5009 = getelementptr i8, ptr %p5008, i64 48
  %op5007 = ptrtoint ptr %gep5009 to i64
  store i64 %op5007, ptr %slot921, align 8
  %v5010 = load i64, ptr %slot39, align 8
  %p5011 = inttoptr i64 %v5010 to ptr
  %ld5012 = load i64, ptr %p5011, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5012, ptr %slot922, align 8
  %v5013 = load i64, ptr %slot922, align 8
  %v5014 = load i64, ptr %slot27, align 8
  %p5015 = inttoptr i64 %v5014 to ptr
  store i64 %v5013, ptr %p5015, align 8, !alias.scope !3, !noalias !4
  %v5016 = load i64, ptr %slot27, align 8
  store i64 %v5016, ptr %slot923, align 8
  store i32 0, ptr %slot924, align 8
  %v5017 = load i64, ptr %slot18, align 8
  %p5018 = inttoptr i64 %v5017 to ptr
  %ld5019 = load i32, ptr %p5018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5019, ptr %slot925, align 8
  %v5020 = load i32, ptr %slot925, align 8
  %op5021 = and i32 %v5020, 24
  store i32 %op5021, ptr %slot925, align 8
  %v5022 = load i32, ptr %slot925, align 8
  %cmp5023 = icmp eq i32 %v5022, 0
  %cv5024 = zext i1 %cmp5023 to i32
  store i32 %cv5024, ptr %slot926, align 8
  %v5025 = load i32, ptr %slot924, align 8
  %v5026 = load i32, ptr %slot926, align 8
  %op5027 = and i32 %v5025, %v5026
  store i32 %op5027, ptr %slot927, align 8
  %v5028 = load i32, ptr %slot927, align 8
  %cv5029 = zext i32 %v5028 to i64
  %cond5030 = icmp ne i64 %cv5029, 0
  br i1 %cond5030, label %bb_rctake1164, label %bb_rccopy1164
bb_rctake1164:
  %v5031 = load i64, ptr %slot28, align 8
  store i64 %v5031, ptr %slot928, align 8
  %v5032 = load i64, ptr %slot55, align 8
  store i64 %v5032, ptr %slot929, align 8
  %v5033 = load i64, ptr %slot923, align 8
  %v5034 = load i64, ptr %slot928, align 8
  %op5035 = sub i64 %v5033, %v5034
  store i64 %op5035, ptr %slot930, align 8
  %v5036 = load i64, ptr %slot928, align 8
  %v5037 = load i64, ptr %slot923, align 8
  %op5038 = sub i64 %v5036, %v5037
  store i64 %op5038, ptr %slot931, align 8
  %v5039 = load i64, ptr %slot930, align 8
  %cmp5040 = icmp ult i64 %v5039, 8
  %cv5041 = zext i1 %cmp5040 to i32
  store i32 %cv5041, ptr %slot932, align 8
  %v5042 = load i64, ptr %slot931, align 8
  %cmp5043 = icmp ult i64 %v5042, 8
  %cv5044 = zext i1 %cmp5043 to i32
  store i32 %cv5044, ptr %slot933, align 8
  %v5045 = load i32, ptr %slot932, align 8
  %v5046 = load i32, ptr %slot933, align 8
  %op5047 = or i32 %v5045, %v5046
  store i32 %op5047, ptr %slot934, align 8
  %v5048 = load i32, ptr %slot934, align 8
  %cv5049 = zext i32 %v5048 to i64
  %cond5050 = icmp ne i64 %cv5049, 0
  br i1 %cond5050, label %bb_rcmoveslow1173, label %bb_rcmovecheck1173
bb_rcmovecheck1173:
  %v5051 = load i64, ptr %slot923, align 8
  %p5053 = inttoptr i64 %v5051 to ptr
  %gep5054 = getelementptr i8, ptr %p5053, i64 0
  %op5052 = ptrtoint ptr %gep5054 to i64
  store i64 %op5052, ptr %slot935, align 8
  %v5055 = load i64, ptr %slot935, align 8
  %p5056 = inttoptr i64 %v5055 to ptr
  %ld5057 = load i64, ptr %p5056, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5057, ptr %slot936, align 8
  %v5058 = load i64, ptr %slot936, align 8
  %cmp5059 = icmp ne i64 %v5058, 0
  %cv5060 = zext i1 %cmp5059 to i32
  store i32 %cv5060, ptr %slot937, align 8
  %v5061 = load i32, ptr %slot937, align 8
  %cv5062 = zext i32 %v5061 to i64
  %cond5063 = icmp ne i64 %cv5062, 0
  br i1 %cond5063, label %bb_rcmoveheader1181, label %bb_rcmovenext1181
bb_rcmoveheader1181:
  %v5064 = load i64, ptr %slot936, align 8
  %op5065 = sub i64 %v5064, 16
  store i64 %op5065, ptr %slot938, align 8
  %v5066 = load i64, ptr %slot936, align 8
  %p5067 = inttoptr i64 %v5066 to ptr
  %rgep5068 = getelementptr i8, ptr %p5067, i64 -16
  %ld5069 = load i64, ptr %rgep5068, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5069, ptr %slot939, align 8
  %v5070 = load i64, ptr %slot939, align 8
  %op5071 = and i64 %v5070, 5764607523034234881
  store i64 %op5071, ptr %slot940, align 8
  %v5072 = load i64, ptr %slot940, align 8
  %cmp5073 = icmp ne i64 %v5072, 0
  %cv5074 = zext i1 %cmp5073 to i32
  store i32 %cv5074, ptr %slot941, align 8
  %v5075 = load i32, ptr %slot941, align 8
  %cv5076 = zext i32 %v5075 to i64
  %cond5077 = icmp ne i64 %cv5076, 0
  br i1 %cond5077, label %bb_rcmoveslow1173, label %bb_rcmovenext1181
bb_rcmovenext1181:
  %v5078 = load i64, ptr %slot923, align 8
  %v5079 = load i64, ptr %slot928, align 8
  %p5080 = inttoptr i64 %v5078 to ptr
  %p5081 = inttoptr i64 %v5079 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5081, ptr %p5080, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5082 = load i64, ptr %slot923, align 8
  %p5083 = inttoptr i64 %v5082 to ptr
  store i64 0, ptr %p5083, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1173
bb_rcmoveslow1173:
  %v5084 = load i64, ptr %slot54, align 8
  %v5085 = load i64, ptr %slot928, align 8
  %v5086 = load i64, ptr %slot923, align 8
  %v5087 = load i64, ptr %slot929, align 8
  %cv5088 = trunc i64 %v5087 to i32
  %call5089 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64 %v5084, i64 %v5085, i64 %v5086, i32 %cv5088) nomerge, !dbg !154
  store i32 %call5089, ptr %slot942, align 8
  %v5090 = load i32, ptr %slot942, align 8
  %cv5091 = zext i32 %v5090 to i64
  %cond5092 = icmp ne i64 %cv5091, 0
  br i1 %cond5092, label %bb_rcsuccess1188, label %bb_rcfailure1188
bb_rcfailure1188:
  %v5093 = load i64, ptr %slot54, align 8
  %p5094 = inttoptr i64 %v5093 to ptr
  %call5095 = call i32 @myl_rc_take_failure(ptr %p5094) nomerge, !dbg !154
  store i32 %call5095, ptr %slot943, align 8
  %v5096 = load i64, ptr %slot1, align 8
  %p5097 = inttoptr i64 %v5096 to ptr
  %v5098 = load i32, ptr %slot943, align 8
  %call5099 = call i32 @myl_qbe_rc_status(ptr %p5097, i32 %v5098) nomerge, !dbg !154
  store i32 %call5099, ptr %slot944, align 8
  br label %bb_failure
bb_rcsuccess1188:
  br label %bb_rcmoved1173
bb_rcmoved1173:
  %v5100 = load i64, ptr %slot20, align 8
  %p5101 = inttoptr i64 %v5100 to ptr
  store i32 2, ptr %p5101, align 4, !alias.scope !3, !noalias !4
  %v5102 = load i64, ptr %slot19, align 8
  %p5103 = inttoptr i64 %v5102 to ptr
  store i32 1, ptr %p5103, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1164
bb_rccopy1164:
  %v5104 = load i64, ptr %slot28, align 8
  store i64 %v5104, ptr %slot945, align 8
  %v5105 = load i64, ptr %slot55, align 8
  store i64 %v5105, ptr %slot946, align 8
  %v5106 = load i64, ptr %slot923, align 8
  %p5107 = inttoptr i64 %v5106 to ptr
  %ld5108 = load i64, ptr %p5107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5108, ptr %slot947, align 8
  %v5109 = load i64, ptr %slot947, align 8
  %cmp5110 = icmp ne i64 %v5109, 0
  %cv5111 = zext i1 %cmp5110 to i32
  store i32 %cv5111, ptr %slot948, align 8
  %v5112 = load i32, ptr %slot948, align 8
  %cv5113 = zext i32 %v5112 to i64
  %cond5114 = icmp ne i64 %cv5113, 0
  br i1 %cond5114, label %bb_rcgnn1197, label %bb_rcgplain1197
bb_rcgnn1197:
  %v5115 = load i64, ptr %slot947, align 8
  %op5116 = sub i64 %v5115, 16
  store i64 %op5116, ptr %slot949, align 8
  %v5117 = load i64, ptr %slot947, align 8
  %p5118 = inttoptr i64 %v5117 to ptr
  %rgep5119 = getelementptr i8, ptr %p5118, i64 -16
  %ld5120 = load i64, ptr %rgep5119, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5120, ptr %slot950, align 8
  %v5121 = load i64, ptr %slot950, align 8
  %op5122 = and i64 %v5121, 4611686018427387906
  store i64 %op5122, ptr %slot951, align 8
  %v5123 = load i64, ptr %slot951, align 8
  %cmp5124 = icmp ne i64 %v5123, 0
  %cv5125 = zext i1 %cmp5124 to i32
  store i32 %cv5125, ptr %slot952, align 8
  %v5126 = load i32, ptr %slot952, align 8
  %cv5127 = zext i32 %v5126 to i64
  %cond5128 = icmp ne i64 %cv5127, 0
  br i1 %cond5128, label %bb_rcgspecial1197, label %bb_rcginc1197
bb_rcginc1197:
  %v5129 = load i64, ptr %slot947, align 8
  %op5130 = sub i64 %v5129, 32
  store i64 %op5130, ptr %slot953, align 8
  %v5131 = load i64, ptr %slot947, align 8
  %p5132 = inttoptr i64 %v5131 to ptr
  %rgep5133 = getelementptr i8, ptr %p5132, i64 -32
  %ld5134 = load i64, ptr %rgep5133, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5134, ptr %slot954, align 8
  %v5135 = load i64, ptr %slot954, align 8
  %op5136 = add i64 %v5135, 1
  store i64 %op5136, ptr %slot955, align 8
  %v5137 = load i64, ptr %slot955, align 8
  %cmp5138 = icmp eq i64 %v5137, 0
  %cv5139 = zext i1 %cmp5138 to i32
  store i32 %cv5139, ptr %slot956, align 8
  %v5140 = load i32, ptr %slot956, align 8
  %cv5141 = zext i32 %v5140 to i64
  %cond5142 = icmp ne i64 %cv5141, 0
  br i1 %cond5142, label %bb_rcglimit1197, label %bb_rcgcapacity1197
bb_rcglimit1197:
  %v5143 = load i64, ptr %slot1, align 8
  %p5144 = inttoptr i64 %v5143 to ptr
  %call5145 = call i32 @myl_qbe_rc_status(ptr %p5144, i32 2) nomerge, !dbg !154
  store i32 %call5145, ptr %slot957, align 8
  br label %bb_failure
bb_rcgcapacity1197:
  %v5146 = load i64, ptr %slot955, align 8
  %v5147 = load i64, ptr %slot947, align 8
  %p5148 = inttoptr i64 %v5147 to ptr
  %rgep5149 = getelementptr i8, ptr %p5148, i64 -32
  store i64 %v5146, ptr %rgep5149, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain1197
bb_rcgspecial1197:
  %v5150 = load i64, ptr %slot950, align 8
  %op5151 = and i64 %v5150, 4611686018427387904
  store i64 %op5151, ptr %slot958, align 8
  %v5152 = load i64, ptr %slot958, align 8
  %cmp5153 = icmp ne i64 %v5152, 0
  %cv5154 = zext i1 %cmp5153 to i32
  store i32 %cv5154, ptr %slot959, align 8
  %v5155 = load i32, ptr %slot959, align 8
  %cv5156 = zext i32 %v5155 to i64
  %cond5157 = icmp ne i64 %cv5156, 0
  br i1 %cond5157, label %bb_rcgslow1197, label %bb_rcgplain1197
bb_rcgslow1197:
  %v5158 = load i64, ptr %slot54, align 8
  %v5159 = load i64, ptr %slot945, align 8
  %v5160 = load i64, ptr %slot923, align 8
  %v5161 = load i64, ptr %slot946, align 8
  %cv5162 = trunc i64 %v5161 to i32
  %call5163 = call i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64 %v5158, i64 %v5159, i64 %v5160, i32 %cv5162) nomerge, !dbg !154
  store i32 %call5163, ptr %slot960, align 8
  %v5164 = load i32, ptr %slot960, align 8
  %cv5165 = zext i32 %v5164 to i64
  %cond5166 = icmp ne i64 %cv5165, 0
  br i1 %cond5166, label %bb_rcsuccess1211, label %bb_rcfailure1211
bb_rcfailure1211:
  %v5167 = load i64, ptr %slot54, align 8
  %p5168 = inttoptr i64 %v5167 to ptr
  %call5169 = call i32 @myl_rc_take_failure(ptr %p5168) nomerge, !dbg !154
  store i32 %call5169, ptr %slot961, align 8
  %v5170 = load i64, ptr %slot1, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  %v5172 = load i32, ptr %slot961, align 8
  %call5173 = call i32 @myl_qbe_rc_status(ptr %p5171, i32 %v5172) nomerge, !dbg !154
  store i32 %call5173, ptr %slot962, align 8
  br label %bb_failure
bb_rcsuccess1211:
  br label %bb_rcgdone1197
bb_rcgplain1197:
  %v5174 = load i64, ptr %slot947, align 8
  %v5175 = load i64, ptr %slot945, align 8
  %p5176 = inttoptr i64 %v5175 to ptr
  store i64 %v5174, ptr %p5176, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1197
bb_rcgdone1197:
  %v5177 = load i64, ptr %slot20, align 8
  %p5178 = inttoptr i64 %v5177 to ptr
  store i32 2, ptr %p5178, align 4, !alias.scope !3, !noalias !4
  %v5179 = load i64, ptr %slot19, align 8
  %p5180 = inttoptr i64 %v5179 to ptr
  store i32 1, ptr %p5180, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1164
bb_rcprepared1164:
  %v5181 = load i64, ptr %slot28, align 8
  store i64 %v5181, ptr %slot963, align 8
  %v5182 = load i64, ptr %slot963, align 8
  %v5183 = load i64, ptr %slot921, align 8
  %p5184 = inttoptr i64 %v5182 to ptr
  %p5185 = inttoptr i64 %v5183 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5185, ptr %p5184, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5186 = load i64, ptr %slot19, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  store i32 0, ptr %p5187, align 4, !alias.scope !3, !noalias !4
  %v5188 = load i64, ptr %slot884, align 8
  %v5189 = load i64, ptr %slot37, align 8
  %p5190 = inttoptr i64 %v5189 to ptr
  store i64 %v5188, ptr %p5190, align 8, !alias.scope !3, !noalias !4
  %v5191 = load i64, ptr %slot37, align 8
  %p5192 = inttoptr i64 %v5191 to ptr
  %ld5193 = load i64, ptr %p5192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5193, ptr %slot964, align 8
  %v5194 = load i64, ptr %slot23, align 8
  store i64 %v5194, ptr %slot965, align 8
  %v5195 = load i64, ptr %slot964, align 8
  %v5196 = load i64, ptr %slot965, align 8
  %p5197 = inttoptr i64 %v5195 to ptr
  %p5198 = inttoptr i64 %v5196 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5198, ptr %p5197, i64 56, i1 false)
  %v5199 = load i64, ptr %slot15, align 8
  %p5200 = inttoptr i64 %v5199 to ptr
  store i32 2, ptr %p5200, align 4, !alias.scope !3, !noalias !4
  %v5201 = load i64, ptr %slot14, align 8
  %p5202 = inttoptr i64 %v5201 to ptr
  store i32 1, ptr %p5202, align 4, !alias.scope !3, !noalias !4
  %v5203 = load i64, ptr %slot965, align 8
  %v5204 = load i64, ptr %slot37, align 8
  %p5205 = inttoptr i64 %v5204 to ptr
  store i64 %v5203, ptr %p5205, align 8, !alias.scope !3, !noalias !4
  %v5206 = load i64, ptr %slot48, align 8
  store i64 %v5206, ptr %slot966, align 8
  %v5207 = load i64, ptr %slot966, align 8
  %p5208 = inttoptr i64 %v5207 to ptr
  call void @llvm.memset.p0.i64(ptr %p5208, i8 0, i64 112, i1 false), !alias.scope !3, !noalias !4, !dbg !156
  %v5209 = load i64, ptr %slot966, align 8
  %p5210 = inttoptr i64 %v5209 to ptr
  store i32 2, ptr %p5210, align 4, !alias.scope !3, !noalias !4
  %v5211 = load i64, ptr %slot21, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  store i32 1, ptr %p5212, align 4, !alias.scope !3, !noalias !4
  %v5213 = load i64, ptr %slot37, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  %ld5215 = load i64, ptr %p5214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5215, ptr %slot967, align 8
  %v5216 = load i64, ptr %slot966, align 8
  %p5218 = inttoptr i64 %v5216 to ptr
  %gep5219 = getelementptr i8, ptr %p5218, i64 8
  %op5217 = ptrtoint ptr %gep5219 to i64
  store i64 %op5217, ptr %slot968, align 8
  %v5220 = load i64, ptr %slot55, align 8
  store i64 %v5220, ptr %slot969, align 8
  %v5221 = load i64, ptr %slot37, align 8
  %p5222 = inttoptr i64 %v5221 to ptr
  %ld5223 = load i64, ptr %p5222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5223, ptr %slot970, align 8
  %v5224 = load i64, ptr %slot28, align 8
  store i64 %v5224, ptr %slot971, align 8
  %v5225 = load i64, ptr %slot55, align 8
  store i64 %v5225, ptr %slot972, align 8
  %v5226 = load i64, ptr %slot54, align 8
  %v5227 = load i64, ptr %slot971, align 8
  %v5228 = load i64, ptr %slot970, align 8
  %v5229 = load i64, ptr %slot972, align 8
  %cv5230 = trunc i64 %v5229 to i32
  %call5231 = call i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64 %v5226, i64 %v5227, i64 %v5228, i32 %cv5230) nomerge, !dbg !156
  store i32 %call5231, ptr %slot973, align 8
  %v5232 = load i32, ptr %slot973, align 8
  %cv5233 = zext i32 %v5232 to i64
  %cond5234 = icmp ne i64 %cv5233, 0
  br i1 %cond5234, label %bb_rcsuccess1269, label %bb_rcfailure1269
bb_rcfailure1269:
  %v5235 = load i64, ptr %slot54, align 8
  %p5236 = inttoptr i64 %v5235 to ptr
  %call5237 = call i32 @myl_rc_take_failure(ptr %p5236) nomerge, !dbg !156
  store i32 %call5237, ptr %slot974, align 8
  %v5238 = load i64, ptr %slot1, align 8
  %p5239 = inttoptr i64 %v5238 to ptr
  %v5240 = load i32, ptr %slot974, align 8
  %call5241 = call i32 @myl_qbe_rc_status(ptr %p5239, i32 %v5240) nomerge, !dbg !156
  store i32 %call5241, ptr %slot975, align 8
  br label %bb_failure
bb_rcsuccess1269:
  %v5242 = load i64, ptr %slot14, align 8
  %p5243 = inttoptr i64 %v5242 to ptr
  store i32 0, ptr %p5243, align 4, !alias.scope !3, !noalias !4
  %v5244 = load i64, ptr %slot20, align 8
  %p5245 = inttoptr i64 %v5244 to ptr
  store i32 2, ptr %p5245, align 4, !alias.scope !3, !noalias !4
  %v5246 = load i64, ptr %slot19, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  store i32 1, ptr %p5247, align 4, !alias.scope !3, !noalias !4
  %v5248 = load i64, ptr %slot28, align 8
  store i64 %v5248, ptr %slot976, align 8
  %v5249 = load i64, ptr %slot976, align 8
  %v5250 = load i64, ptr %slot968, align 8
  %p5251 = inttoptr i64 %v5249 to ptr
  %p5252 = inttoptr i64 %v5250 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5252, ptr %p5251, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v5253 = load i64, ptr %slot19, align 8
  %p5254 = inttoptr i64 %v5253 to ptr
  store i32 0, ptr %p5254, align 4, !alias.scope !3, !noalias !4
  %v5255 = load i64, ptr %slot966, align 8
  %v5256 = load i64, ptr %slot37, align 8
  %p5257 = inttoptr i64 %v5256 to ptr
  store i64 %v5255, ptr %p5257, align 8, !alias.scope !3, !noalias !4
  %v5258 = load i64, ptr %slot37, align 8
  %p5259 = inttoptr i64 %v5258 to ptr
  %ld5260 = load i64, ptr %p5259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5260, ptr %slot977, align 8
  %v5261 = load i64, ptr %slot23, align 8
  store i64 %v5261, ptr %slot978, align 8
  %v5262 = load i64, ptr %slot977, align 8
  %v5263 = load i64, ptr %slot978, align 8
  %p5264 = inttoptr i64 %v5262 to ptr
  %p5265 = inttoptr i64 %v5263 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5265, ptr %p5264, i64 112, i1 false)
  %v5266 = load i64, ptr %slot15, align 8
  %p5267 = inttoptr i64 %v5266 to ptr
  store i32 2, ptr %p5267, align 4, !alias.scope !3, !noalias !4
  %v5268 = load i64, ptr %slot14, align 8
  %p5269 = inttoptr i64 %v5268 to ptr
  store i32 1, ptr %p5269, align 4, !alias.scope !3, !noalias !4
  %v5270 = load i64, ptr %slot978, align 8
  %v5271 = load i64, ptr %slot37, align 8
  %p5272 = inttoptr i64 %v5271 to ptr
  store i64 %v5270, ptr %p5272, align 8, !alias.scope !3, !noalias !4
  %v5273 = load i64, ptr %slot36, align 8
  %p5274 = inttoptr i64 %v5273 to ptr
  %ld5275 = load i64, ptr %p5274, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5275, ptr %slot979, align 8
  %v5276 = load i64, ptr %slot37, align 8
  %p5277 = inttoptr i64 %v5276 to ptr
  %ld5278 = load i64, ptr %p5277, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5278, ptr %slot980, align 8
  %v5279 = load i64, ptr %slot1, align 8
  %v5280 = load i64, ptr %slot979, align 8
  %v5281 = load i64, ptr %slot980, align 8
  %call5282 = call i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64 %v5279, i64 %v5280, i64 %v5281) nomerge, !dbg !158
  store i64 %call5282, ptr %slot981, align 8
  %v5283 = load i64, ptr %slot981, align 8
  %v5284 = load i64, ptr %slot36, align 8
  %p5285 = inttoptr i64 %v5284 to ptr
  store i64 %v5283, ptr %p5285, align 8, !alias.scope !3, !noalias !4
  %v5286 = load i64, ptr %slot12, align 8
  %p5287 = inttoptr i64 %v5286 to ptr
  %ld5288 = load i32, ptr %p5287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5288, ptr %slot982, align 8
  %v5289 = load i32, ptr %slot982, align 8
  %cv5290 = zext i32 %v5289 to i64
  %cond5291 = icmp ne i64 %cv5290, 0
  br i1 %cond5291, label %bb_rcslotdrop1286, label %bb_rcslotdone1286
bb_rcslotdrop1286:
  %v5292 = load i64, ptr %slot12, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  store i32 0, ptr %p5293, align 4, !alias.scope !3, !noalias !4
  %v5294 = load i64, ptr %slot22, align 8
  store i64 %v5294, ptr %slot983, align 8
  %v5295 = load i64, ptr %slot13, align 8
  %p5296 = inttoptr i64 %v5295 to ptr
  %ld5297 = load i32, ptr %p5296, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5297, ptr %slot984, align 8
  %v5298 = load i32, ptr %slot984, align 8
  %op5299 = and i32 %v5298, 28
  store i32 %op5299, ptr %slot985, align 8
  %v5300 = load i32, ptr %slot985, align 8
  %cv5301 = zext i32 %v5300 to i64
  %cond5302 = icmp ne i64 %cv5301, 0
  br i1 %cond5302, label %bb_rcslotrole1286, label %bb_rcslotowner1286
bb_rcslotrole1286:
  %v5303 = load i64, ptr %slot54, align 8
  store i64 %v5303, ptr %slot986, align 8
  %v5304 = load i64, ptr %slot986, align 8
  %v5305 = load i64, ptr %slot983, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v5304, i64 %v5305) nomerge, !dbg !158
  br label %bb_rcslotdone1286
bb_rcslotowner1286:
  %v5306 = load i64, ptr %slot54, align 8
  store i64 %v5306, ptr %slot987, align 8
  %v5307 = load i64, ptr %slot987, align 8
  %v5308 = load i64, ptr %slot983, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v5307, i64 %v5308) nomerge, !dbg !158
  br label %bb_rcslotdone1286
bb_rcslotdone1286:
  %v5309 = load i64, ptr %slot14, align 8
  %p5310 = inttoptr i64 %v5309 to ptr
  %ld5311 = load i32, ptr %p5310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5311, ptr %slot988, align 8
  %v5312 = load i32, ptr %slot988, align 8
  %cv5313 = zext i32 %v5312 to i64
  %cond5314 = icmp ne i64 %cv5313, 0
  br i1 %cond5314, label %bb_rcslotdrop1295, label %bb_rcslotdone1295
bb_rcslotdrop1295:
  %v5315 = load i64, ptr %slot14, align 8
  %p5316 = inttoptr i64 %v5315 to ptr
  store i32 0, ptr %p5316, align 4, !alias.scope !3, !noalias !4
  %v5317 = load i64, ptr %slot23, align 8
  store i64 %v5317, ptr %slot989, align 8
  %v5318 = load i64, ptr %slot15, align 8
  %p5319 = inttoptr i64 %v5318 to ptr
  %ld5320 = load i32, ptr %p5319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5320, ptr %slot990, align 8
  %v5321 = load i32, ptr %slot990, align 8
  %op5322 = and i32 %v5321, 28
  store i32 %op5322, ptr %slot991, align 8
  %v5323 = load i32, ptr %slot991, align 8
  %cv5324 = zext i32 %v5323 to i64
  %cond5325 = icmp ne i64 %cv5324, 0
  br i1 %cond5325, label %bb_rcslotrole1295, label %bb_rcslotowner1295
bb_rcslotrole1295:
  %v5326 = load i64, ptr %slot54, align 8
  store i64 %v5326, ptr %slot992, align 8
  %v5327 = load i64, ptr %slot992, align 8
  %v5328 = load i64, ptr %slot989, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v5327, i64 %v5328) nomerge, !dbg !158
  br label %bb_rcslotdone1295
bb_rcslotowner1295:
  %v5329 = load i64, ptr %slot54, align 8
  store i64 %v5329, ptr %slot993, align 8
  %v5330 = load i64, ptr %slot993, align 8
  %v5331 = load i64, ptr %slot989, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v5330, i64 %v5331) nomerge, !dbg !158
  br label %bb_rcslotdone1295
bb_rcslotdone1295:
  %v5332 = load i64, ptr %slot49, align 8
  store i64 %v5332, ptr %slot994, align 8
  %v5333 = load i64, ptr %slot994, align 8
  %p5334 = inttoptr i64 %v5333 to ptr
  store i64 0, ptr %p5334, align 8, !alias.scope !3, !noalias !4
  %v5335 = load i64, ptr %slot994, align 8
  %p5337 = inttoptr i64 %v5335 to ptr
  %gep5338 = getelementptr i8, ptr %p5337, i64 8
  %op5336 = ptrtoint ptr %gep5338 to i64
  store i64 %op5336, ptr %slot995, align 8
  %v5339 = load i64, ptr %slot995, align 8
  %p5340 = inttoptr i64 %v5339 to ptr
  store i64 0, ptr %p5340, align 8, !alias.scope !3, !noalias !4
  %v5341 = load i64, ptr %slot994, align 8
  %p5342 = inttoptr i64 %v5341 to ptr
  store i32 0, ptr %p5342, align 4, !alias.scope !3, !noalias !4
  %v5343 = load i64, ptr %slot21, align 8
  %p5344 = inttoptr i64 %v5343 to ptr
  store i32 1, ptr %p5344, align 4, !alias.scope !3, !noalias !4
  %v5345 = load i64, ptr %slot36, align 8
  store i64 %v5345, ptr %slot996, align 8
  %v5346 = load i64, ptr %slot994, align 8
  %p5348 = inttoptr i64 %v5346 to ptr
  %gep5349 = getelementptr i8, ptr %p5348, i64 8
  %op5347 = ptrtoint ptr %gep5349 to i64
  store i64 %op5347, ptr %slot997, align 8
  %v5350 = load i64, ptr %slot55, align 8
  store i64 %v5350, ptr %slot998, align 8
  %v5351 = load i64, ptr %slot996, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  %ld5353 = load i64, ptr %p5352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5353, ptr %slot999, align 8
  %v5354 = load i64, ptr %slot999, align 8
  %v5355 = load i64, ptr %slot997, align 8
  %p5356 = inttoptr i64 %v5355 to ptr
  store i64 %v5354, ptr %p5356, align 8, !alias.scope !3, !noalias !4
  %v5357 = load i64, ptr %slot994, align 8
  %v5358 = load i64, ptr %slot36, align 8
  %p5359 = inttoptr i64 %v5358 to ptr
  store i64 %v5357, ptr %p5359, align 8, !alias.scope !3, !noalias !4
  %v5360 = load i64, ptr %slot36, align 8
  %p5361 = inttoptr i64 %v5360 to ptr
  %ld5362 = load i64, ptr %p5361, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5362, ptr %slot1000, align 8
  %v5363 = load i64, ptr %slot12, align 8
  %p5364 = inttoptr i64 %v5363 to ptr
  %ld5365 = load i32, ptr %p5364, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5365, ptr %slot1001, align 8
  %v5366 = load i32, ptr %slot1001, align 8
  %cv5367 = zext i32 %v5366 to i64
  %cond5368 = icmp ne i64 %cv5367, 0
  br i1 %cond5368, label %bb_rcslotdrop1313, label %bb_rcslotdone1313
bb_rcslotdrop1313:
  %v5369 = load i64, ptr %slot12, align 8
  %p5370 = inttoptr i64 %v5369 to ptr
  store i32 0, ptr %p5370, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1313
bb_rcslotdone1313:
  %v5371 = load i64, ptr %slot10, align 8
  %p5372 = inttoptr i64 %v5371 to ptr
  %ld5373 = load i32, ptr %p5372, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5373, ptr %slot1002, align 8
  %v5374 = load i32, ptr %slot1002, align 8
  %cv5375 = zext i32 %v5374 to i64
  %cond5376 = icmp ne i64 %cv5375, 0
  br i1 %cond5376, label %bb_rcslotdrop1316, label %bb_rcslotdone1316
bb_rcslotdrop1316:
  %v5377 = load i64, ptr %slot10, align 8
  %p5378 = inttoptr i64 %v5377 to ptr
  store i32 0, ptr %p5378, align 4, !alias.scope !3, !noalias !4
  %v5379 = load i64, ptr %slot35, align 8
  store i64 %v5379, ptr %slot1003, align 8
  %v5380 = load i64, ptr %slot11, align 8
  %p5381 = inttoptr i64 %v5380 to ptr
  %ld5382 = load i32, ptr %p5381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5382, ptr %slot1004, align 8
  %v5383 = load i32, ptr %slot1004, align 8
  %op5384 = and i32 %v5383, 28
  store i32 %op5384, ptr %slot1005, align 8
  %v5385 = load i32, ptr %slot1005, align 8
  %cv5386 = zext i32 %v5385 to i64
  %cond5387 = icmp ne i64 %cv5386, 0
  br i1 %cond5387, label %bb_rcslotrole1316, label %bb_rcslotowner1316
bb_rcslotrole1316:
  %v5388 = load i64, ptr %slot54, align 8
  store i64 %v5388, ptr %slot1006, align 8
  %v5389 = load i64, ptr %slot1006, align 8
  %v5390 = load i64, ptr %slot1003, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v5389, i64 %v5390) nomerge, !dbg !160
  br label %bb_rcslotdone1316
bb_rcslotowner1316:
  %v5391 = load i64, ptr %slot54, align 8
  store i64 %v5391, ptr %slot1007, align 8
  %v5392 = load i64, ptr %slot1007, align 8
  %v5393 = load i64, ptr %slot1003, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v5392, i64 %v5393) nomerge, !dbg !160
  br label %bb_rcslotdone1316
bb_rcslotdone1316:
  %v5394 = load i64, ptr %slot8, align 8
  %p5395 = inttoptr i64 %v5394 to ptr
  %ld5396 = load i32, ptr %p5395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5396, ptr %slot1008, align 8
  %v5397 = load i32, ptr %slot1008, align 8
  %cv5398 = zext i32 %v5397 to i64
  %cond5399 = icmp ne i64 %cv5398, 0
  br i1 %cond5399, label %bb_rcslotdrop1325, label %bb_rcslotdone1325
bb_rcslotdrop1325:
  %v5400 = load i64, ptr %slot8, align 8
  %p5401 = inttoptr i64 %v5400 to ptr
  store i32 0, ptr %p5401, align 4, !alias.scope !3, !noalias !4
  %v5402 = load i64, ptr %slot33, align 8
  store i64 %v5402, ptr %slot1009, align 8
  %v5403 = load i64, ptr %slot9, align 8
  %p5404 = inttoptr i64 %v5403 to ptr
  %ld5405 = load i32, ptr %p5404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5405, ptr %slot1010, align 8
  %v5406 = load i32, ptr %slot1010, align 8
  %op5407 = and i32 %v5406, 28
  store i32 %op5407, ptr %slot1011, align 8
  %v5408 = load i32, ptr %slot1011, align 8
  %cv5409 = zext i32 %v5408 to i64
  %cond5410 = icmp ne i64 %cv5409, 0
  br i1 %cond5410, label %bb_rcslotrole1325, label %bb_rcslotowner1325
bb_rcslotrole1325:
  %v5411 = load i64, ptr %slot54, align 8
  store i64 %v5411, ptr %slot1012, align 8
  %v5412 = load i64, ptr %slot1009, align 8
  %p5413 = inttoptr i64 %v5412 to ptr
  %ld5414 = load i64, ptr %p5413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5414, ptr %slot1013, align 8
  %v5415 = load i64, ptr %slot1013, align 8
  %cmp5416 = icmp ne i64 %v5415, 0
  %cv5417 = zext i1 %cmp5416 to i32
  store i32 %cv5417, ptr %slot1014, align 8
  %v5418 = load i32, ptr %slot1014, align 8
  %cv5419 = zext i32 %v5418 to i64
  %cond5420 = icmp ne i64 %cv5419, 0
  br i1 %cond5420, label %bb_rcgnn1341, label %bb_rcgdone1341
bb_rcgnn1341:
  %v5421 = load i64, ptr %slot1013, align 8
  %op5422 = sub i64 %v5421, 16
  store i64 %op5422, ptr %slot1015, align 8
  %v5423 = load i64, ptr %slot1013, align 8
  %p5424 = inttoptr i64 %v5423 to ptr
  %rgep5425 = getelementptr i8, ptr %p5424, i64 -16
  %ld5426 = load i64, ptr %rgep5425, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5426, ptr %slot1016, align 8
  %v5427 = load i64, ptr %slot1016, align 8
  %op5428 = and i64 %v5427, 4611686018427387906
  store i64 %op5428, ptr %slot1017, align 8
  %v5429 = load i64, ptr %slot1017, align 8
  %cmp5430 = icmp ne i64 %v5429, 0
  %cv5431 = zext i1 %cmp5430 to i32
  store i32 %cv5431, ptr %slot1018, align 8
  %v5432 = load i32, ptr %slot1018, align 8
  %cv5433 = zext i32 %v5432 to i64
  %cond5434 = icmp ne i64 %cv5433, 0
  br i1 %cond5434, label %bb_rcgclear1341, label %bb_rcgcounted1341
bb_rcgcounted1341:
  %v5435 = load i64, ptr %slot1013, align 8
  %op5436 = sub i64 %v5435, 24
  store i64 %op5436, ptr %slot1019, align 8
  %v5437 = load i64, ptr %slot1013, align 8
  %p5438 = inttoptr i64 %v5437 to ptr
  %rgep5439 = getelementptr i8, ptr %p5438, i64 -24
  %ld5440 = load i64, ptr %rgep5439, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5440, ptr %slot1020, align 8
  %v5441 = load i64, ptr %slot1020, align 8
  %op5442 = sub i64 %v5441, 1
  store i64 %op5442, ptr %slot1021, align 8
  %v5443 = load i64, ptr %slot1021, align 8
  %cmp5444 = icmp eq i64 %v5443, 0
  %cv5445 = zext i1 %cmp5444 to i32
  store i32 %cv5445, ptr %slot1022, align 8
  %v5446 = load i32, ptr %slot1022, align 8
  %cv5447 = zext i32 %v5446 to i64
  %cond5448 = icmp ne i64 %cv5447, 0
  br i1 %cond5448, label %bb_rcglast1341, label %bb_rcgdec1341
bb_rcglast1341:
  %v5449 = load i64, ptr %slot1013, align 8
  %op5450 = sub i64 %v5449, 32
  store i64 %op5450, ptr %slot1023, align 8
  %v5451 = load i64, ptr %slot1013, align 8
  %p5452 = inttoptr i64 %v5451 to ptr
  %rgep5453 = getelementptr i8, ptr %p5452, i64 -32
  %ld5454 = load i64, ptr %rgep5453, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5454, ptr %slot1024, align 8
  %v5455 = load i64, ptr %slot1024, align 8
  %cmp5456 = icmp ne i64 %v5455, 0
  %cv5457 = zext i1 %cmp5456 to i32
  store i32 %cv5457, ptr %slot1025, align 8
  %v5458 = load i32, ptr %slot1025, align 8
  %cv5459 = zext i32 %v5458 to i64
  %cond5460 = icmp ne i64 %cv5459, 0
  br i1 %cond5460, label %bb_rcgdec1341, label %bb_rcgslow1341
bb_rcgslow1341:
  %v5461 = load i64, ptr %slot1012, align 8
  %v5462 = load i64, ptr %slot1009, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5461, i64 %v5462) nomerge, !dbg !160
  br label %bb_rcgdone1341
bb_rcgdec1341:
  %v5463 = load i64, ptr %slot1021, align 8
  %v5464 = load i64, ptr %slot1013, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  %rgep5466 = getelementptr i8, ptr %p5465, i64 -24
  store i64 %v5463, ptr %rgep5466, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1341
bb_rcgclear1341:
  %v5467 = load i64, ptr %slot1009, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  store i64 0, ptr %p5468, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1341
bb_rcgdone1341:
  br label %bb_rcslotdone1325
bb_rcslotowner1325:
  %v5469 = load i64, ptr %slot54, align 8
  store i64 %v5469, ptr %slot1026, align 8
  %v5470 = load i64, ptr %slot1009, align 8
  %p5471 = inttoptr i64 %v5470 to ptr
  %ld5472 = load i64, ptr %p5471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5472, ptr %slot1027, align 8
  %v5473 = load i64, ptr %slot1027, align 8
  %cmp5474 = icmp ne i64 %v5473, 0
  %cv5475 = zext i1 %cmp5474 to i32
  store i32 %cv5475, ptr %slot1028, align 8
  %v5476 = load i32, ptr %slot1028, align 8
  %cv5477 = zext i32 %v5476 to i64
  %cond5478 = icmp ne i64 %cv5477, 0
  br i1 %cond5478, label %bb_rcgnn1356, label %bb_rcgdone1356
bb_rcgnn1356:
  %v5479 = load i64, ptr %slot1027, align 8
  %op5480 = sub i64 %v5479, 16
  store i64 %op5480, ptr %slot1029, align 8
  %v5481 = load i64, ptr %slot1027, align 8
  %p5482 = inttoptr i64 %v5481 to ptr
  %rgep5483 = getelementptr i8, ptr %p5482, i64 -16
  %ld5484 = load i64, ptr %rgep5483, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5484, ptr %slot1030, align 8
  %v5485 = load i64, ptr %slot1030, align 8
  %op5486 = and i64 %v5485, 4611686018427387906
  store i64 %op5486, ptr %slot1031, align 8
  %v5487 = load i64, ptr %slot1031, align 8
  %cmp5488 = icmp ne i64 %v5487, 0
  %cv5489 = zext i1 %cmp5488 to i32
  store i32 %cv5489, ptr %slot1032, align 8
  %v5490 = load i32, ptr %slot1032, align 8
  %cv5491 = zext i32 %v5490 to i64
  %cond5492 = icmp ne i64 %cv5491, 0
  br i1 %cond5492, label %bb_rcgclear1356, label %bb_rcgcounted1356
bb_rcgcounted1356:
  %v5493 = load i64, ptr %slot1027, align 8
  %op5494 = sub i64 %v5493, 32
  store i64 %op5494, ptr %slot1033, align 8
  %v5495 = load i64, ptr %slot1027, align 8
  %p5496 = inttoptr i64 %v5495 to ptr
  %rgep5497 = getelementptr i8, ptr %p5496, i64 -32
  %ld5498 = load i64, ptr %rgep5497, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5498, ptr %slot1034, align 8
  %v5499 = load i64, ptr %slot1034, align 8
  %op5500 = sub i64 %v5499, 1
  store i64 %op5500, ptr %slot1035, align 8
  %v5501 = load i64, ptr %slot1035, align 8
  %cmp5502 = icmp eq i64 %v5501, 0
  %cv5503 = zext i1 %cmp5502 to i32
  store i32 %cv5503, ptr %slot1036, align 8
  %v5504 = load i32, ptr %slot1036, align 8
  %cv5505 = zext i32 %v5504 to i64
  %cond5506 = icmp ne i64 %cv5505, 0
  br i1 %cond5506, label %bb_rcglast1356, label %bb_rcgdec1356
bb_rcglast1356:
  %v5507 = load i64, ptr %slot1027, align 8
  %op5508 = sub i64 %v5507, 24
  store i64 %op5508, ptr %slot1037, align 8
  %v5509 = load i64, ptr %slot1027, align 8
  %p5510 = inttoptr i64 %v5509 to ptr
  %rgep5511 = getelementptr i8, ptr %p5510, i64 -24
  %ld5512 = load i64, ptr %rgep5511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5512, ptr %slot1038, align 8
  %v5513 = load i64, ptr %slot1038, align 8
  %cmp5514 = icmp ne i64 %v5513, 0
  %cv5515 = zext i1 %cmp5514 to i32
  store i32 %cv5515, ptr %slot1039, align 8
  %v5516 = load i32, ptr %slot1039, align 8
  %cv5517 = zext i32 %v5516 to i64
  %cond5518 = icmp ne i64 %cv5517, 0
  br i1 %cond5518, label %bb_rcgdec1356, label %bb_rcgslow1356
bb_rcgslow1356:
  %v5519 = load i64, ptr %slot1026, align 8
  %v5520 = load i64, ptr %slot1009, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5519, i64 %v5520) nomerge, !dbg !160
  br label %bb_rcgdone1356
bb_rcgdec1356:
  %v5521 = load i64, ptr %slot1035, align 8
  %v5522 = load i64, ptr %slot1027, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  %rgep5524 = getelementptr i8, ptr %p5523, i64 -32
  store i64 %v5521, ptr %rgep5524, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1356
bb_rcgclear1356:
  %v5525 = load i64, ptr %slot1009, align 8
  %p5526 = inttoptr i64 %v5525 to ptr
  store i64 0, ptr %p5526, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1356
bb_rcgdone1356:
  br label %bb_rcslotdone1325
bb_rcslotdone1325:
  %v5527 = load i64, ptr %slot6, align 8
  %p5528 = inttoptr i64 %v5527 to ptr
  %ld5529 = load i32, ptr %p5528, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5529, ptr %slot1040, align 8
  %v5530 = load i32, ptr %slot1040, align 8
  %cv5531 = zext i32 %v5530 to i64
  %cond5532 = icmp ne i64 %cv5531, 0
  br i1 %cond5532, label %bb_rcslotdrop1362, label %bb_rcslotdone1362
bb_rcslotdrop1362:
  %v5533 = load i64, ptr %slot6, align 8
  %p5534 = inttoptr i64 %v5533 to ptr
  store i32 0, ptr %p5534, align 4, !alias.scope !3, !noalias !4
  %v5535 = load i64, ptr %slot32, align 8
  store i64 %v5535, ptr %slot1041, align 8
  %v5536 = load i64, ptr %slot7, align 8
  %p5537 = inttoptr i64 %v5536 to ptr
  %ld5538 = load i32, ptr %p5537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5538, ptr %slot1042, align 8
  %v5539 = load i32, ptr %slot1042, align 8
  %op5540 = and i32 %v5539, 28
  store i32 %op5540, ptr %slot1043, align 8
  %v5541 = load i32, ptr %slot1043, align 8
  %cv5542 = zext i32 %v5541 to i64
  %cond5543 = icmp ne i64 %cv5542, 0
  br i1 %cond5543, label %bb_rcslotrole1362, label %bb_rcslotowner1362
bb_rcslotrole1362:
  %v5544 = load i64, ptr %slot54, align 8
  store i64 %v5544, ptr %slot1044, align 8
  %v5545 = load i64, ptr %slot1041, align 8
  %p5546 = inttoptr i64 %v5545 to ptr
  %ld5547 = load i64, ptr %p5546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5547, ptr %slot1045, align 8
  %v5548 = load i64, ptr %slot1045, align 8
  %cmp5549 = icmp ne i64 %v5548, 0
  %cv5550 = zext i1 %cmp5549 to i32
  store i32 %cv5550, ptr %slot1046, align 8
  %v5551 = load i32, ptr %slot1046, align 8
  %cv5552 = zext i32 %v5551 to i64
  %cond5553 = icmp ne i64 %cv5552, 0
  br i1 %cond5553, label %bb_rcgnn1378, label %bb_rcgdone1378
bb_rcgnn1378:
  %v5554 = load i64, ptr %slot1045, align 8
  %op5555 = sub i64 %v5554, 16
  store i64 %op5555, ptr %slot1047, align 8
  %v5556 = load i64, ptr %slot1045, align 8
  %p5557 = inttoptr i64 %v5556 to ptr
  %rgep5558 = getelementptr i8, ptr %p5557, i64 -16
  %ld5559 = load i64, ptr %rgep5558, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5559, ptr %slot1048, align 8
  %v5560 = load i64, ptr %slot1048, align 8
  %op5561 = and i64 %v5560, 4611686018427387906
  store i64 %op5561, ptr %slot1049, align 8
  %v5562 = load i64, ptr %slot1049, align 8
  %cmp5563 = icmp ne i64 %v5562, 0
  %cv5564 = zext i1 %cmp5563 to i32
  store i32 %cv5564, ptr %slot1050, align 8
  %v5565 = load i32, ptr %slot1050, align 8
  %cv5566 = zext i32 %v5565 to i64
  %cond5567 = icmp ne i64 %cv5566, 0
  br i1 %cond5567, label %bb_rcgclear1378, label %bb_rcgcounted1378
bb_rcgcounted1378:
  %v5568 = load i64, ptr %slot1045, align 8
  %op5569 = sub i64 %v5568, 24
  store i64 %op5569, ptr %slot1051, align 8
  %v5570 = load i64, ptr %slot1045, align 8
  %p5571 = inttoptr i64 %v5570 to ptr
  %rgep5572 = getelementptr i8, ptr %p5571, i64 -24
  %ld5573 = load i64, ptr %rgep5572, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5573, ptr %slot1052, align 8
  %v5574 = load i64, ptr %slot1052, align 8
  %op5575 = sub i64 %v5574, 1
  store i64 %op5575, ptr %slot1053, align 8
  %v5576 = load i64, ptr %slot1053, align 8
  %cmp5577 = icmp eq i64 %v5576, 0
  %cv5578 = zext i1 %cmp5577 to i32
  store i32 %cv5578, ptr %slot1054, align 8
  %v5579 = load i32, ptr %slot1054, align 8
  %cv5580 = zext i32 %v5579 to i64
  %cond5581 = icmp ne i64 %cv5580, 0
  br i1 %cond5581, label %bb_rcglast1378, label %bb_rcgdec1378
bb_rcglast1378:
  %v5582 = load i64, ptr %slot1045, align 8
  %op5583 = sub i64 %v5582, 32
  store i64 %op5583, ptr %slot1055, align 8
  %v5584 = load i64, ptr %slot1045, align 8
  %p5585 = inttoptr i64 %v5584 to ptr
  %rgep5586 = getelementptr i8, ptr %p5585, i64 -32
  %ld5587 = load i64, ptr %rgep5586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5587, ptr %slot1056, align 8
  %v5588 = load i64, ptr %slot1056, align 8
  %cmp5589 = icmp ne i64 %v5588, 0
  %cv5590 = zext i1 %cmp5589 to i32
  store i32 %cv5590, ptr %slot1057, align 8
  %v5591 = load i32, ptr %slot1057, align 8
  %cv5592 = zext i32 %v5591 to i64
  %cond5593 = icmp ne i64 %cv5592, 0
  br i1 %cond5593, label %bb_rcgdec1378, label %bb_rcgslow1378
bb_rcgslow1378:
  %v5594 = load i64, ptr %slot1044, align 8
  %v5595 = load i64, ptr %slot1041, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v5594, i64 %v5595) nomerge, !dbg !160
  br label %bb_rcgdone1378
bb_rcgdec1378:
  %v5596 = load i64, ptr %slot1053, align 8
  %v5597 = load i64, ptr %slot1045, align 8
  %p5598 = inttoptr i64 %v5597 to ptr
  %rgep5599 = getelementptr i8, ptr %p5598, i64 -24
  store i64 %v5596, ptr %rgep5599, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1378
bb_rcgclear1378:
  %v5600 = load i64, ptr %slot1041, align 8
  %p5601 = inttoptr i64 %v5600 to ptr
  store i64 0, ptr %p5601, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1378
bb_rcgdone1378:
  br label %bb_rcslotdone1362
bb_rcslotowner1362:
  %v5602 = load i64, ptr %slot54, align 8
  store i64 %v5602, ptr %slot1058, align 8
  %v5603 = load i64, ptr %slot1041, align 8
  %p5604 = inttoptr i64 %v5603 to ptr
  %ld5605 = load i64, ptr %p5604, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5605, ptr %slot1059, align 8
  %v5606 = load i64, ptr %slot1059, align 8
  %cmp5607 = icmp ne i64 %v5606, 0
  %cv5608 = zext i1 %cmp5607 to i32
  store i32 %cv5608, ptr %slot1060, align 8
  %v5609 = load i32, ptr %slot1060, align 8
  %cv5610 = zext i32 %v5609 to i64
  %cond5611 = icmp ne i64 %cv5610, 0
  br i1 %cond5611, label %bb_rcgnn1393, label %bb_rcgdone1393
bb_rcgnn1393:
  %v5612 = load i64, ptr %slot1059, align 8
  %op5613 = sub i64 %v5612, 16
  store i64 %op5613, ptr %slot1061, align 8
  %v5614 = load i64, ptr %slot1059, align 8
  %p5615 = inttoptr i64 %v5614 to ptr
  %rgep5616 = getelementptr i8, ptr %p5615, i64 -16
  %ld5617 = load i64, ptr %rgep5616, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5617, ptr %slot1062, align 8
  %v5618 = load i64, ptr %slot1062, align 8
  %op5619 = and i64 %v5618, 4611686018427387906
  store i64 %op5619, ptr %slot1063, align 8
  %v5620 = load i64, ptr %slot1063, align 8
  %cmp5621 = icmp ne i64 %v5620, 0
  %cv5622 = zext i1 %cmp5621 to i32
  store i32 %cv5622, ptr %slot1064, align 8
  %v5623 = load i32, ptr %slot1064, align 8
  %cv5624 = zext i32 %v5623 to i64
  %cond5625 = icmp ne i64 %cv5624, 0
  br i1 %cond5625, label %bb_rcgclear1393, label %bb_rcgcounted1393
bb_rcgcounted1393:
  %v5626 = load i64, ptr %slot1059, align 8
  %op5627 = sub i64 %v5626, 32
  store i64 %op5627, ptr %slot1065, align 8
  %v5628 = load i64, ptr %slot1059, align 8
  %p5629 = inttoptr i64 %v5628 to ptr
  %rgep5630 = getelementptr i8, ptr %p5629, i64 -32
  %ld5631 = load i64, ptr %rgep5630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5631, ptr %slot1066, align 8
  %v5632 = load i64, ptr %slot1066, align 8
  %op5633 = sub i64 %v5632, 1
  store i64 %op5633, ptr %slot1067, align 8
  %v5634 = load i64, ptr %slot1067, align 8
  %cmp5635 = icmp eq i64 %v5634, 0
  %cv5636 = zext i1 %cmp5635 to i32
  store i32 %cv5636, ptr %slot1068, align 8
  %v5637 = load i32, ptr %slot1068, align 8
  %cv5638 = zext i32 %v5637 to i64
  %cond5639 = icmp ne i64 %cv5638, 0
  br i1 %cond5639, label %bb_rcglast1393, label %bb_rcgdec1393
bb_rcglast1393:
  %v5640 = load i64, ptr %slot1059, align 8
  %op5641 = sub i64 %v5640, 24
  store i64 %op5641, ptr %slot1069, align 8
  %v5642 = load i64, ptr %slot1059, align 8
  %p5643 = inttoptr i64 %v5642 to ptr
  %rgep5644 = getelementptr i8, ptr %p5643, i64 -24
  %ld5645 = load i64, ptr %rgep5644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5645, ptr %slot1070, align 8
  %v5646 = load i64, ptr %slot1070, align 8
  %cmp5647 = icmp ne i64 %v5646, 0
  %cv5648 = zext i1 %cmp5647 to i32
  store i32 %cv5648, ptr %slot1071, align 8
  %v5649 = load i32, ptr %slot1071, align 8
  %cv5650 = zext i32 %v5649 to i64
  %cond5651 = icmp ne i64 %cv5650, 0
  br i1 %cond5651, label %bb_rcgdec1393, label %bb_rcgslow1393
bb_rcgslow1393:
  %v5652 = load i64, ptr %slot1058, align 8
  %v5653 = load i64, ptr %slot1041, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v5652, i64 %v5653) nomerge, !dbg !160
  br label %bb_rcgdone1393
bb_rcgdec1393:
  %v5654 = load i64, ptr %slot1067, align 8
  %v5655 = load i64, ptr %slot1059, align 8
  %p5656 = inttoptr i64 %v5655 to ptr
  %rgep5657 = getelementptr i8, ptr %p5656, i64 -32
  store i64 %v5654, ptr %rgep5657, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1393
bb_rcgclear1393:
  %v5658 = load i64, ptr %slot1041, align 8
  %p5659 = inttoptr i64 %v5658 to ptr
  store i64 0, ptr %p5659, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1393
bb_rcgdone1393:
  br label %bb_rcslotdone1362
bb_rcslotdone1362:
  %v5660 = load i64, ptr %slot1000, align 8
  %p5661 = inttoptr i64 %v5660 to ptr
  %ret5662 = load { i64, i64 }, ptr %p5661, align 8
  ret { i64, i64 } %ret5662
bb_failure:
  %v5663 = load i64, ptr %slot5, align 8
  %p5664 = inttoptr i64 %v5663 to ptr
  call void @llvm.memset.p0.i64(ptr %p5664, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !160
  %v5665 = load i64, ptr %slot5, align 8
  %p5666 = inttoptr i64 %v5665 to ptr
  %ret5667 = load { i64, i64 }, ptr %p5666, align 8
  ret { i64, i64 } %ret5667
bb_entry_failure:
  %v5668 = load i64, ptr %slot5, align 8
  %p5669 = inttoptr i64 %v5668 to ptr
  call void @llvm.memset.p0.i64(ptr %p5669, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !160
  %v5670 = load i64, ptr %slot5, align 8
  %p5671 = inttoptr i64 %v5670 to ptr
  %ret5672 = load { i64, i64 }, ptr %p5671, align 8
  ret { i64, i64 } %ret5672
}

@myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04_meta = external global i8, align 8
@myl_lit_35d41e0b6aa3a58cd0db1d8c7a982e8b15477d856cb7b6bc9404d8afd095ed9e = external global i8, align 8
@myl_lit_a2fef6855234220d4efe69d6d206ee3c11f5b0c2ac2ff07411d432d186d8f508 = external global i8, align 8
@myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = external global i8, align 8
@myl_t_1a91deb3742283487d66c3b500f6effd7ef1170e6d4b4368fe9ec3c3f0354fda = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64, i64, i64)
declare { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64, i64)
declare void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare i8 @myl_f_7a515a62bcf2d52dbd1a003508cbad18b835f8a05891010b6b797b5f49fa312f(i64, i64, i64, i64)
declare i64 @myl_f_99a76686ca586e845633883aa58736c220bb792a0d32a46cfd0ef285b8c49255(i64, i64, i64)
declare i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64, i64, i64)
declare void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8, i64, i64, i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_list_append(ptr, ptr, ptr)
declare i32 @myl_rc_list_plain_ready(ptr, ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare i32 @myl_t_2cedd6eeca93c3ea92d86b2593a2be12b6045916b4fe03348350f9d6124d48cc_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04", linkageName: "myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 644224429190654413, i64 0, !"myl_f_8b3ed21fbff2cac3f9fe5d302cab81640a288554cdb97e83aede5b6dfd01ee04"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!118 = !DILocation(line: 6, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!124 = !DILocation(line: 14, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!126 = !DILocation(line: 16, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!130 = !DILocation(line: 21, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!132 = !DILocation(line: 26, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!134 = !DILocation(line: 32, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646807)
!136 = !DILocation(line: 34, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!138 = !DILocation(line: 37, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!140 = !DILocation(line: 38, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646855)
!142 = !DILocation(line: 40, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!144 = !DILocation(line: 41, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!146 = !DILocation(line: 47, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!148 = !DILocation(line: 48, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!150 = !DILocation(line: 50, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!152 = !DILocation(line: 51, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!154 = !DILocation(line: 57, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!156 = !DILocation(line: 58, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!158 = !DILocation(line: 59, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!160 = !DILocation(line: 61, column: 0, scope: !161)
