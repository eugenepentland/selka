target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v25 = load i64, ptr %slot1, align 8
  %op26 = add i64 %v25, 32
  store i64 %op26, ptr %slot4, align 8
  %mem27 = alloca i8, i64 8, align 8
  %ptr28 = ptrtoint ptr %mem27 to i64
  store i64 %ptr28, ptr %slot5, align 8
  %mem29 = alloca i8, i64 8, align 8
  %ptr30 = ptrtoint ptr %mem29 to i64
  store i64 %ptr30, ptr %slot6, align 8
  %mem31 = alloca i8, i64 8, align 8
  %ptr32 = ptrtoint ptr %mem31 to i64
  store i64 %ptr32, ptr %slot7, align 8
  %mem33 = alloca i8, i64 8, align 8
  %ptr34 = ptrtoint ptr %mem33 to i64
  store i64 %ptr34, ptr %slot8, align 8
  %mem35 = alloca i8, i64 8, align 8
  %ptr36 = ptrtoint ptr %mem35 to i64
  store i64 %ptr36, ptr %slot9, align 8
  %mem37 = alloca i8, i64 392, align 8
  %ptr38 = ptrtoint ptr %mem37 to i64
  store i64 %ptr38, ptr %slot10, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem39 = alloca i8, i64 8, align 8
  %ptr40 = ptrtoint ptr %mem39 to i64
  store i64 %ptr40, ptr %slot11, align 8
  %v41 = load i64, ptr %slot1, align 8
  %op42 = add i64 %v41, 64
  store i64 %op42, ptr %slot12, align 8
  %v43 = load i64, ptr %slot12, align 8
  %p44 = inttoptr i64 %v43 to ptr
  %ld45 = load i64, ptr %p44, align 8, !alias.scope !4, !noalias !3
  store i64 %ld45, ptr %slot13, align 8
  %stack46 = call ptr @llvm.stacksave()
  %stackaddr47 = ptrtoint ptr %stack46 to i64
  %v48 = load i64, ptr %slot13, align 8
  %cmp49 = icmp ult i64 %stackaddr47, %v48
  %cv50 = zext i1 %cmp49 to i64
  store i64 %cv50, ptr %slot14, align 8
  %v51 = load i64, ptr %slot14, align 8
  %cond52 = icmp ne i64 %v51, 0
  br i1 %cond52, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v53 = load i64, ptr %slot1, align 8
  %p54 = inttoptr i64 %v53 to ptr
  call void @myl_qbe_fail_frame(ptr %p54) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v55 = load i64, ptr %slot2, align 8
  %v56 = load i64, ptr %slot5, align 8
  %p57 = inttoptr i64 %v56 to ptr
  store i64 %v55, ptr %p57, align 8, !alias.scope !3, !noalias !4
  %v58 = load i64, ptr %slot3, align 8
  %v59 = load i64, ptr %slot6, align 8
  %p60 = inttoptr i64 %v59 to ptr
  store i64 %v58, ptr %p60, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v61 = load i64, ptr %slot5, align 8
  %p62 = inttoptr i64 %v61 to ptr
  %ld63 = load i64, ptr %p62, align 8, !alias.scope !3, !noalias !4
  store i64 %ld63, ptr %slot15, align 8
  %v64 = load i64, ptr %slot15, align 8
  %v65 = load i64, ptr %slot7, align 8
  %p66 = inttoptr i64 %v65 to ptr
  store i64 %v64, ptr %p66, align 8, !alias.scope !3, !noalias !4
  %v67 = load i64, ptr %slot5, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %ld69 = load i64, ptr %p68, align 8, !alias.scope !3, !noalias !4
  store i64 %ld69, ptr %slot16, align 8
  %v70 = load i64, ptr %slot16, align 8
  %v71 = load i64, ptr %slot10, align 8
  %p72 = inttoptr i64 %v70 to ptr
  %p73 = inttoptr i64 %v71 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p73, ptr %p72, i64 392, i1 false), !alias.scope !10000000
  %v74 = load i64, ptr %slot10, align 8
  %v75 = load i64, ptr %slot8, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 %v74, ptr %p76, align 8, !alias.scope !3, !noalias !4
  %v77 = load i64, ptr %slot8, align 8
  %p78 = inttoptr i64 %v77 to ptr
  %ld79 = load i64, ptr %p78, align 8, !alias.scope !3, !noalias !4
  store i64 %ld79, ptr %slot17, align 8
  %v80 = load i64, ptr %slot17, align 8
  %op81 = add i64 %v80, 288
  store i64 %op81, ptr %slot18, align 8
  %v82 = load i64, ptr %slot18, align 8
  %v83 = load i64, ptr %slot8, align 8
  %p84 = inttoptr i64 %v83 to ptr
  store i64 %v82, ptr %p84, align 8, !alias.scope !3, !noalias !4
  %v85 = load i64, ptr %slot6, align 8
  %p86 = inttoptr i64 %v85 to ptr
  %ld87 = load i64, ptr %p86, align 8, !alias.scope !3, !noalias !4
  store i64 %ld87, ptr %slot19, align 8
  %v88 = load i64, ptr %slot19, align 8
  %v89 = load i64, ptr %slot9, align 8
  %p90 = inttoptr i64 %v89 to ptr
  store i64 %v88, ptr %p90, align 8, !alias.scope !3, !noalias !4
  %v91 = load i64, ptr %slot7, align 8
  %p92 = inttoptr i64 %v91 to ptr
  %ld93 = load i64, ptr %p92, align 8, !alias.scope !3, !noalias !4
  store i64 %ld93, ptr %slot20, align 8
  %v94 = load i64, ptr %slot8, align 8
  %p95 = inttoptr i64 %v94 to ptr
  %ld96 = load i64, ptr %p95, align 8, !alias.scope !3, !noalias !4
  store i64 %ld96, ptr %slot21, align 8
  %v97 = load i64, ptr %slot9, align 8
  %p98 = inttoptr i64 %v97 to ptr
  %ld99 = load i64, ptr %p98, align 8, !alias.scope !3, !noalias !4
  store i64 %ld99, ptr %slot22, align 8
  %v100 = load i64, ptr %slot1, align 8
  %v101 = load i64, ptr %slot20, align 8
  %v102 = load i64, ptr %slot21, align 8
  %v103 = load i64, ptr %slot22, align 8
  %call104 = call i64 @myl_f_2e04afb4dad24fcad4ace06a2b2111913dbe8bb22edd83132db5fc4644fffa02(i64 %v100, i64 %v101, i64 %v102, i64 %v103) nomerge, !dbg !112
  store i64 %call104, ptr %slot23, align 8
  %v105 = load i64, ptr %slot23, align 8
  %v106 = load i64, ptr %slot7, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i64 %v105, ptr %p107, align 8, !alias.scope !3, !noalias !4
  %v108 = load i64, ptr %slot7, align 8
  %p109 = inttoptr i64 %v108 to ptr
  store i64 0, ptr %p109, align 8, !alias.scope !3, !noalias !4
  %v110 = load i64, ptr %slot7, align 8
  %p111 = inttoptr i64 %v110 to ptr
  %ld112 = load i64, ptr %p111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld112, ptr %slot24, align 8
  %v113 = load i64, ptr %slot24, align 8
  ret i64 %v113
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_2e04afb4dad24fcad4ace06a2b2111913dbe8bb22edd83132db5fc4644fffa02(i64, i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58", linkageName: "myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 10073568570672338029, i64 0, !"myl_f_72873b1c7a3a32c4728e2c017b5f2cadbeafa8e995e7b8f3d82ebb5e8e042f58"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!112 = !DILocation(line: 5, column: 0, scope: !113)
