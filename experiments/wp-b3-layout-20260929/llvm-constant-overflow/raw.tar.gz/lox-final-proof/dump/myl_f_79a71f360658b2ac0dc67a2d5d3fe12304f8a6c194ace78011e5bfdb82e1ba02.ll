target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %callresult123 = alloca [40 x i8], align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i32, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i32, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i32, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i32, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i32, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i64, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i32, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i32, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i32, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i64, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i32, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i32, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %callresult266 = alloca [40 x i8], align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i32, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i32, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i64, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i32, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i32, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i64, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i64, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i32, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i32, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %callresult405 = alloca [40 x i8], align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i32, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i32, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i32, align 8
  %slot427 = alloca i32, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i32, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i32, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i32, align 8
  %slot444 = alloca i32, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i32, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i32, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i32, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i32, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i32, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i32, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i32, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i32, align 8
  %slot509 = alloca i64, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i32, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i32, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i64, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i32, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i32, align 8
  %slot534 = alloca i32, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %callresult541 = alloca [40 x i8], align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i32, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i32, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i32, align 8
  %slot564 = alloca i32, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i32, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i32, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i64, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i32, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i32, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i32, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i32, align 8
  %slot621 = alloca i32, align 8
  %slot622 = alloca i64, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i32, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i32, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i32, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i32, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i32, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i32, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i32, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i32, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i32, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i32, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i32, align 8
  %slot717 = alloca i32, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i32, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i32, align 8
  %slot726 = alloca i32, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i32, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i32, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i32, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i32, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i32, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i32, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i32, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i32, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i32, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i32, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i32, align 8
  %slot813 = alloca i32, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i32, align 8
  %slot827 = alloca i32, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i32, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i32, align 8
  %slot833 = alloca i32, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i32, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i32, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i32, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i32, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i32, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i32, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i32, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %callresult921 = alloca [40 x i8], align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i32, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i32, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i32, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i32, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i32, align 8
  %slot944 = alloca i32, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i32, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i32, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i32, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i64, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i32, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i64, align 8
  %slot992 = alloca i32, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i32, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i32, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i64, align 8
  %slot1006 = alloca i32, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i32, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i32, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i32, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i32, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i32, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i64, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i32, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i32, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i32, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i32, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i32, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i64, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i64, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i32, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i64, align 8
  %slot1145 = alloca i32, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i64, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i64, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i32, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i64, align 8
  %slot1159 = alloca i32, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i64, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i64, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i32, align 8
  %slot1171 = alloca i64, align 8
  %slot1172 = alloca i32, align 8
  %slot1173 = alloca i64, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i32, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i64, align 8
  %slot1178 = alloca i32, align 8
  %slot1179 = alloca i64, align 8
  %slot1180 = alloca i64, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i32, align 8
  %slot1183 = alloca i64, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i32, align 8
  %slot1187 = alloca i64, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i32, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i64, align 8
  %slot1192 = alloca i32, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i64, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i32, align 8
  %slot1197 = alloca i64, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i32, align 8
  %slot1201 = alloca i64, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i32, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i64, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i64, align 8
  %slot1209 = alloca i64, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i64, align 8
  %slot1212 = alloca i64, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i64, align 8
  %slot1216 = alloca i32, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i32, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i32, align 8
  %slot1223 = alloca i64, align 8
  %slot1224 = alloca i32, align 8
  %slot1225 = alloca i32, align 8
  %slot1226 = alloca i64, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i64, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i64, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i32, align 8
  %slot1236 = alloca i32, align 8
  %slot1237 = alloca i64, align 8
  %slot1238 = alloca i32, align 8
  %slot1239 = alloca i32, align 8
  %slot1240 = alloca i64, align 8
  %slot1241 = alloca i64, align 8
  %slot1242 = alloca i32, align 8
  %slot1243 = alloca i64, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i32, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i64, align 8
  %slot1248 = alloca i32, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i32, align 8
  %slot1251 = alloca i32, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i32, align 8
  %slot1255 = alloca i64, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i32, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i64, align 8
  %slot1262 = alloca i32, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i32, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i32, align 8
  %slot1269 = alloca i64, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i64, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i64, align 8
  %slot1276 = alloca i32, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i32, align 8
  %slot1280 = alloca i32, align 8
  %slot1281 = alloca i64, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i32, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i64, align 8
  %slot1286 = alloca i32, align 8
  %slot1287 = alloca i64, align 8
  %slot1288 = alloca i64, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i32, align 8
  %slot1291 = alloca i64, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i64, align 8
  %slot1294 = alloca i32, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i32, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i64, align 8
  %slot1300 = alloca i32, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i64, align 8
  %slot1304 = alloca i32, align 8
  %slot1305 = alloca i64, align 8
  %slot1306 = alloca i64, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i32, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i32, align 8
  %slot1312 = alloca i32, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i32, align 8
  %slot1315 = alloca i32, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i64, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i32, align 8
  %slot1324 = alloca i64, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i32, align 8
  %slot1327 = alloca i64, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i64, align 8
  %callresult1333 = alloca [40 x i8], align 8
  %slot1334 = alloca i64, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i32, align 8
  %slot1337 = alloca i32, align 8
  %slot1338 = alloca i32, align 8
  %slot1339 = alloca i32, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i32, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i64, align 8
  %slot1344 = alloca i64, align 8
  %slot1345 = alloca i64, align 8
  %slot1346 = alloca i64, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i32, align 8
  %slot1350 = alloca i32, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i32, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i32, align 8
  %slot1356 = alloca i32, align 8
  %slot1357 = alloca i32, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i64, align 8
  %slot1360 = alloca i32, align 8
  %slot1361 = alloca i32, align 8
  %slot1362 = alloca i32, align 8
  %slot1363 = alloca i32, align 8
  %slot1364 = alloca i64, align 8
  %slot1365 = alloca i32, align 8
  %slot1366 = alloca i32, align 8
  %slot1367 = alloca i64, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i32, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i32, align 8
  %slot1372 = alloca i32, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i64, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i32, align 8
  %slot1378 = alloca i64, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i64, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i64, align 8
  %slot1386 = alloca i32, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i64, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i64, align 8
  %callresult1392 = alloca [48 x i8], align 8
  %slot1393 = alloca i64, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i32, align 8
  %slot1396 = alloca i64, align 8
  %slot1397 = alloca i32, align 8
  %slot1398 = alloca i32, align 8
  %slot1399 = alloca i64, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i32, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i32, align 8
  %slot1404 = alloca i32, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i32, align 8
  %slot1408 = alloca i64, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i64, align 8
  %slot1411 = alloca i32, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i64, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i32, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i64, align 8
  %slot1418 = alloca i32, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i32, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i64, align 8
  %slot1425 = alloca i32, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i64, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i32, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i32, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i32, align 8
  %slot1436 = alloca i64, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i64, align 8
  %slot1441 = alloca i64, align 8
  %slot1442 = alloca i64, align 8
  %slot1443 = alloca i64, align 8
  %slot1444 = alloca i32, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i32, align 8
  %slot1447 = alloca i32, align 8
  %slot1448 = alloca i64, align 8
  %slot1449 = alloca i64, align 8
  %slot1450 = alloca i64, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i64, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i32, align 8
  %slot1458 = alloca i32, align 8
  %slot1459 = alloca i32, align 8
  %slot1460 = alloca i64, align 8
  %slot1461 = alloca i64, align 8
  %slot1462 = alloca i32, align 8
  %slot1463 = alloca i64, align 8
  %slot1464 = alloca i32, align 8
  %slot1465 = alloca i32, align 8
  %slot1466 = alloca i64, align 8
  %slot1467 = alloca i64, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i32, align 8
  %slot1471 = alloca i64, align 8
  %slot1472 = alloca i32, align 8
  %slot1473 = alloca i32, align 8
  %slot1474 = alloca i64, align 8
  %slot1475 = alloca i32, align 8
  %slot1476 = alloca i32, align 8
  %slot1477 = alloca i64, align 8
  %slot1478 = alloca i64, align 8
  %slot1479 = alloca i32, align 8
  %slot1480 = alloca i64, align 8
  %slot1481 = alloca i32, align 8
  %slot1482 = alloca i32, align 8
  %slot1483 = alloca i64, align 8
  %slot1484 = alloca i64, align 8
  %slot1485 = alloca i32, align 8
  %slot1486 = alloca i64, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i32, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i64, align 8
  %slot1491 = alloca i32, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i64, align 8
  %slot1495 = alloca i32, align 8
  %slot1496 = alloca i64, align 8
  %slot1497 = alloca i64, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i32, align 8
  %slot1500 = alloca i64, align 8
  %slot1501 = alloca i64, align 8
  %slot1502 = alloca i32, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i64, align 8
  %slot1505 = alloca i32, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i64, align 8
  %slot1509 = alloca i32, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i64, align 8
  %slot1512 = alloca i64, align 8
  %slot1513 = alloca i32, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i64, align 8
  %slot1516 = alloca i32, align 8
  %slot1517 = alloca i32, align 8
  %slot1518 = alloca i64, align 8
  %slot1519 = alloca i32, align 8
  %slot1520 = alloca i32, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i64, align 8
  %slot1523 = alloca i32, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i64, align 8
  %slot1527 = alloca i32, align 8
  %slot1528 = alloca i64, align 8
  %slot1529 = alloca i64, align 8
  %slot1530 = alloca i64, align 8
  %slot1531 = alloca i32, align 8
  %slot1532 = alloca i64, align 8
  %slot1533 = alloca i64, align 8
  %slot1534 = alloca i32, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i64, align 8
  %slot1537 = alloca i32, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i64, align 8
  %slot1540 = alloca i64, align 8
  %slot1541 = alloca i32, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i64, align 8
  %slot1544 = alloca i64, align 8
  %slot1545 = alloca i32, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i64, align 8
  %slot1548 = alloca i32, align 8
  %slot1549 = alloca i32, align 8
  %slot1550 = alloca i64, align 8
  %slot1551 = alloca i32, align 8
  %slot1552 = alloca i32, align 8
  %slot1553 = alloca i64, align 8
  %slot1554 = alloca i64, align 8
  %slot1555 = alloca i32, align 8
  %slot1556 = alloca i64, align 8
  %slot1557 = alloca i32, align 8
  %slot1558 = alloca i32, align 8
  %slot1559 = alloca i64, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i64, align 8
  %slot1562 = alloca i64, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i64, align 8
  %slot1566 = alloca i64, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i64, align 8
  %slot1569 = alloca i32, align 8
  %slot1570 = alloca i64, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i64, align 8
  %slot1573 = alloca i64, align 8
  %slot1574 = alloca i64, align 8
  %callresult1575 = alloca [48 x i8], align 8
  %slot1576 = alloca i64, align 8
  %slot1577 = alloca i64, align 8
  %slot1578 = alloca i32, align 8
  %slot1579 = alloca i64, align 8
  %slot1580 = alloca i32, align 8
  %slot1581 = alloca i32, align 8
  %slot1582 = alloca i64, align 8
  %slot1583 = alloca i64, align 8
  %slot1584 = alloca i32, align 8
  %slot1585 = alloca i64, align 8
  %slot1586 = alloca i32, align 8
  %slot1587 = alloca i32, align 8
  %slot1588 = alloca i64, align 8
  %slot1589 = alloca i64, align 8
  %slot1590 = alloca i32, align 8
  %slot1591 = alloca i64, align 8
  %slot1592 = alloca i64, align 8
  %slot1593 = alloca i64, align 8
  %slot1594 = alloca i32, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i64, align 8
  %slot1597 = alloca i64, align 8
  %slot1598 = alloca i32, align 8
  %slot1599 = alloca i64, align 8
  %slot1600 = alloca i64, align 8
  %slot1601 = alloca i32, align 8
  %slot1602 = alloca i64, align 8
  %slot1603 = alloca i64, align 8
  %slot1604 = alloca i32, align 8
  %slot1605 = alloca i64, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i64, align 8
  %slot1608 = alloca i32, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i64, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i32, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i64, align 8
  %slot1615 = alloca i32, align 8
  %slot1616 = alloca i64, align 8
  %slot1617 = alloca i64, align 8
  %slot1618 = alloca i32, align 8
  %slot1619 = alloca i64, align 8
  %slot1620 = alloca i64, align 8
  %slot1621 = alloca i64, align 8
  %slot1622 = alloca i64, align 8
  %slot1623 = alloca i64, align 8
  %slot1624 = alloca i64, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i64, align 8
  %slot1627 = alloca i32, align 8
  %slot1628 = alloca i64, align 8
  %slot1629 = alloca i32, align 8
  %slot1630 = alloca i32, align 8
  %slot1631 = alloca i64, align 8
  %slot1632 = alloca i64, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i64, align 8
  %slot1635 = alloca i64, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i64, align 8
  %slot1638 = alloca i64, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i32, align 8
  %slot1641 = alloca i32, align 8
  %slot1642 = alloca i32, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i64, align 8
  %slot1645 = alloca i32, align 8
  %slot1646 = alloca i64, align 8
  %slot1647 = alloca i32, align 8
  %slot1648 = alloca i32, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i64, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i64, align 8
  %slot1653 = alloca i32, align 8
  %slot1654 = alloca i64, align 8
  %slot1655 = alloca i32, align 8
  %slot1656 = alloca i32, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i32, align 8
  %slot1659 = alloca i32, align 8
  %slot1660 = alloca i64, align 8
  %slot1661 = alloca i64, align 8
  %slot1662 = alloca i32, align 8
  %slot1663 = alloca i64, align 8
  %slot1664 = alloca i32, align 8
  %slot1665 = alloca i32, align 8
  %slot1666 = alloca i64, align 8
  %slot1667 = alloca i64, align 8
  %slot1668 = alloca i32, align 8
  %slot1669 = alloca i64, align 8
  %slot1670 = alloca i32, align 8
  %slot1671 = alloca i32, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i64, align 8
  %slot1674 = alloca i32, align 8
  %slot1675 = alloca i64, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i64, align 8
  %slot1678 = alloca i32, align 8
  %slot1679 = alloca i64, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i64, align 8
  %slot1682 = alloca i32, align 8
  %slot1683 = alloca i64, align 8
  %slot1684 = alloca i64, align 8
  %slot1685 = alloca i32, align 8
  %slot1686 = alloca i64, align 8
  %slot1687 = alloca i64, align 8
  %slot1688 = alloca i32, align 8
  %slot1689 = alloca i64, align 8
  %slot1690 = alloca i64, align 8
  %slot1691 = alloca i64, align 8
  %slot1692 = alloca i32, align 8
  %slot1693 = alloca i64, align 8
  %slot1694 = alloca i64, align 8
  %slot1695 = alloca i64, align 8
  %slot1696 = alloca i32, align 8
  %slot1697 = alloca i64, align 8
  %slot1698 = alloca i64, align 8
  %slot1699 = alloca i32, align 8
  %slot1700 = alloca i32, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i32, align 8
  %slot1703 = alloca i32, align 8
  %slot1704 = alloca i64, align 8
  %slot1705 = alloca i64, align 8
  %slot1706 = alloca i32, align 8
  %slot1707 = alloca i64, align 8
  %slot1708 = alloca i64, align 8
  %slot1709 = alloca i64, align 8
  %slot1710 = alloca i32, align 8
  %slot1711 = alloca i64, align 8
  %slot1712 = alloca i64, align 8
  %slot1713 = alloca i64, align 8
  %slot1714 = alloca i32, align 8
  %slot1715 = alloca i64, align 8
  %slot1716 = alloca i64, align 8
  %slot1717 = alloca i32, align 8
  %slot1718 = alloca i64, align 8
  %slot1719 = alloca i64, align 8
  %slot1720 = alloca i32, align 8
  %slot1721 = alloca i64, align 8
  %slot1722 = alloca i64, align 8
  %slot1723 = alloca i64, align 8
  %slot1724 = alloca i32, align 8
  %slot1725 = alloca i64, align 8
  %slot1726 = alloca i64, align 8
  %slot1727 = alloca i64, align 8
  %slot1728 = alloca i32, align 8
  %slot1729 = alloca i64, align 8
  %slot1730 = alloca i64, align 8
  %slot1731 = alloca i32, align 8
  %slot1732 = alloca i32, align 8
  %slot1733 = alloca i64, align 8
  %slot1734 = alloca i32, align 8
  %slot1735 = alloca i32, align 8
  %slot1736 = alloca i64, align 8
  %slot1737 = alloca i64, align 8
  %slot1738 = alloca i64, align 8
  %slot1739 = alloca i32, align 8
  %slot1740 = alloca i32, align 8
  %slot1741 = alloca i32, align 8
  %slot1742 = alloca i32, align 8
  %slot1743 = alloca i64, align 8
  %slot1744 = alloca i64, align 8
  %slot1745 = alloca i32, align 8
  %slot1746 = alloca i32, align 8
  %slot1747 = alloca i32, align 8
  %slot1748 = alloca i64, align 8
  %slot1749 = alloca i64, align 8
  %slot1750 = alloca i32, align 8
  %slot1751 = alloca i32, align 8
  %slot1752 = alloca i32, align 8
  %slot1753 = alloca i32, align 8
  %slot1754 = alloca i64, align 8
  %slot1755 = alloca i32, align 8
  %slot1756 = alloca i32, align 8
  %slot1757 = alloca i64, align 8
  %slot1758 = alloca i64, align 8
  %slot1759 = alloca i32, align 8
  %slot1760 = alloca i64, align 8
  %slot1761 = alloca i32, align 8
  %slot1762 = alloca i32, align 8
  %slot1763 = alloca i64, align 8
  %slot1764 = alloca i64, align 8
  %slot1765 = alloca i64, align 8
  %slot1766 = alloca i64, align 8
  %slot1767 = alloca i32, align 8
  %slot1768 = alloca i64, align 8
  %slot1769 = alloca i64, align 8
  %slot1770 = alloca i64, align 8
  %slot1771 = alloca i64, align 8
  %slot1772 = alloca i64, align 8
  %slot1773 = alloca i64, align 8
  %slot1774 = alloca i64, align 8
  %slot1775 = alloca i64, align 8
  %slot1776 = alloca i64, align 8
  %slot1777 = alloca i64, align 8
  %slot1778 = alloca i32, align 8
  %slot1779 = alloca i32, align 8
  %slot1780 = alloca i32, align 8
  %slot1781 = alloca i32, align 8
  %slot1782 = alloca i64, align 8
  %slot1783 = alloca i64, align 8
  %slot1784 = alloca i32, align 8
  %slot1785 = alloca i32, align 8
  %slot1786 = alloca i32, align 8
  %slot1787 = alloca i64, align 8
  %slot1788 = alloca i64, align 8
  %slot1789 = alloca i32, align 8
  %slot1790 = alloca i32, align 8
  %slot1791 = alloca i32, align 8
  %slot1792 = alloca i32, align 8
  %slot1793 = alloca i64, align 8
  %slot1794 = alloca i32, align 8
  %slot1795 = alloca i32, align 8
  %slot1796 = alloca i64, align 8
  %slot1797 = alloca i64, align 8
  %slot1798 = alloca i64, align 8
  %slot1799 = alloca i64, align 8
  %slot1800 = alloca i64, align 8
  %slot1801 = alloca i64, align 8
  %slot1802 = alloca i32, align 8
  %slot1803 = alloca i32, align 8
  %slot1804 = alloca i32, align 8
  %slot1805 = alloca i32, align 8
  %slot1806 = alloca i64, align 8
  %slot1807 = alloca i64, align 8
  %slot1808 = alloca i32, align 8
  %slot1809 = alloca i32, align 8
  %slot1810 = alloca i32, align 8
  %slot1811 = alloca i64, align 8
  %slot1812 = alloca i64, align 8
  %slot1813 = alloca i32, align 8
  %slot1814 = alloca i32, align 8
  %slot1815 = alloca i32, align 8
  %slot1816 = alloca i32, align 8
  %slot1817 = alloca i64, align 8
  %slot1818 = alloca i32, align 8
  %slot1819 = alloca i32, align 8
  %slot1820 = alloca i64, align 8
  %slot1821 = alloca i64, align 8
  %slot1822 = alloca i64, align 8
  %slot1823 = alloca i64, align 8
  %slot1824 = alloca i64, align 8
  %slot1825 = alloca i64, align 8
  %slot1826 = alloca i64, align 8
  %slot1827 = alloca i64, align 8
  %slot1828 = alloca i64, align 8
  %slot1829 = alloca i64, align 8
  %slot1830 = alloca i64, align 8
  %slot1831 = alloca i64, align 8
  %slot1832 = alloca i64, align 8
  %slot1833 = alloca i64, align 8
  %slot1834 = alloca i64, align 8
  %slot1835 = alloca i64, align 8
  %slot1836 = alloca i64, align 8
  %slot1837 = alloca i64, align 8
  %slot1838 = alloca i64, align 8
  %slot1839 = alloca i64, align 8
  %slot1840 = alloca i64, align 8
  %slot1841 = alloca i32, align 8
  %slot1842 = alloca i32, align 8
  %slot1843 = alloca i32, align 8
  %slot1844 = alloca i64, align 8
  %slot1845 = alloca i64, align 8
  %slot1846 = alloca i64, align 8
  %slot1847 = alloca i64, align 8
  %slot1848 = alloca i64, align 8
  %slot1849 = alloca i64, align 8
  %slot1850 = alloca i32, align 8
  %slot1851 = alloca i64, align 8
  %slot1852 = alloca i32, align 8
  %slot1853 = alloca i32, align 8
  %slot1854 = alloca i64, align 8
  %slot1855 = alloca i64, align 8
  %slot1856 = alloca i32, align 8
  %slot1857 = alloca i64, align 8
  %slot1858 = alloca i32, align 8
  %slot1859 = alloca i32, align 8
  %slot1860 = alloca i64, align 8
  %slot1861 = alloca i64, align 8
  %slot1862 = alloca i64, align 8
  %slot1863 = alloca i64, align 8
  %slot1864 = alloca i64, align 8
  %slot1865 = alloca i64, align 8
  %slot1866 = alloca i64, align 8
  %slot1867 = alloca i64, align 8
  %slot1868 = alloca i64, align 8
  %slot1869 = alloca i32, align 8
  %slot1870 = alloca i32, align 8
  %slot1871 = alloca i64, align 8
  %slot1872 = alloca i32, align 8
  %slot1873 = alloca i32, align 8
  %slot1874 = alloca i64, align 8
  %slot1875 = alloca i64, align 8
  %slot1876 = alloca i32, align 8
  %slot1877 = alloca i64, align 8
  %slot1878 = alloca i32, align 8
  %slot1879 = alloca i32, align 8
  %slot1880 = alloca i64, align 8
  %slot1881 = alloca i64, align 8
  %slot1882 = alloca i32, align 8
  %slot1883 = alloca i64, align 8
  %slot1884 = alloca i32, align 8
  %slot1885 = alloca i32, align 8
  %slot1886 = alloca i64, align 8
  %slot1887 = alloca i64, align 8
  %slot1888 = alloca i32, align 8
  %slot1889 = alloca i64, align 8
  %slot1890 = alloca i64, align 8
  %slot1891 = alloca i64, align 8
  %slot1892 = alloca i32, align 8
  %slot1893 = alloca i64, align 8
  %slot1894 = alloca i64, align 8
  %slot1895 = alloca i64, align 8
  %slot1896 = alloca i32, align 8
  %slot1897 = alloca i64, align 8
  %slot1898 = alloca i64, align 8
  %slot1899 = alloca i32, align 8
  %slot1900 = alloca i64, align 8
  %slot1901 = alloca i64, align 8
  %slot1902 = alloca i32, align 8
  %slot1903 = alloca i64, align 8
  %slot1904 = alloca i64, align 8
  %slot1905 = alloca i64, align 8
  %slot1906 = alloca i32, align 8
  %slot1907 = alloca i64, align 8
  %slot1908 = alloca i64, align 8
  %slot1909 = alloca i64, align 8
  %slot1910 = alloca i32, align 8
  %slot1911 = alloca i64, align 8
  %slot1912 = alloca i64, align 8
  %slot1913 = alloca i32, align 8
  %slot1914 = alloca i32, align 8
  %slot1915 = alloca i64, align 8
  %slot1916 = alloca i32, align 8
  %slot1917 = alloca i32, align 8
  %slot1918 = alloca i64, align 8
  %slot1919 = alloca i64, align 8
  %slot1920 = alloca i32, align 8
  %slot1921 = alloca i64, align 8
  %slot1922 = alloca i64, align 8
  %slot1923 = alloca i64, align 8
  %slot1924 = alloca i32, align 8
  %slot1925 = alloca i64, align 8
  %slot1926 = alloca i64, align 8
  %slot1927 = alloca i64, align 8
  %slot1928 = alloca i32, align 8
  %slot1929 = alloca i64, align 8
  %slot1930 = alloca i64, align 8
  %slot1931 = alloca i32, align 8
  %slot1932 = alloca i64, align 8
  %slot1933 = alloca i64, align 8
  %slot1934 = alloca i32, align 8
  %slot1935 = alloca i64, align 8
  %slot1936 = alloca i64, align 8
  %slot1937 = alloca i64, align 8
  %slot1938 = alloca i32, align 8
  %slot1939 = alloca i64, align 8
  %slot1940 = alloca i64, align 8
  %slot1941 = alloca i64, align 8
  %slot1942 = alloca i32, align 8
  %slot1943 = alloca i64, align 8
  %slot1944 = alloca i64, align 8
  %slot1945 = alloca i32, align 8
  %slot1946 = alloca i32, align 8
  %slot1947 = alloca i64, align 8
  %slot1948 = alloca i32, align 8
  %slot1949 = alloca i32, align 8
  %slot1950 = alloca i64, align 8
  %slot1951 = alloca i64, align 8
  %slot1952 = alloca i64, align 8
  %slot1953 = alloca i64, align 8
  %slot1954 = alloca i64, align 8
  %slot1955 = alloca i64, align 8
  %slot1956 = alloca i64, align 8
  %slot1957 = alloca i32, align 8
  %slot1958 = alloca i64, align 8
  %slot1959 = alloca i32, align 8
  %slot1960 = alloca i32, align 8
  %slot1961 = alloca i64, align 8
  %slot1962 = alloca i64, align 8
  %slot1963 = alloca i64, align 8
  %slot1964 = alloca i64, align 8
  %slot1965 = alloca i64, align 8
  %slot1966 = alloca i64, align 8
  %slot1967 = alloca i64, align 8
  %callresult1968 = alloca [40 x i8], align 8
  %slot1969 = alloca i64, align 8
  %slot1970 = alloca i64, align 8
  %slot1971 = alloca i32, align 8
  %slot1972 = alloca i32, align 8
  %slot1973 = alloca i32, align 8
  %slot1974 = alloca i32, align 8
  %slot1975 = alloca i64, align 8
  %slot1976 = alloca i32, align 8
  %slot1977 = alloca i32, align 8
  %slot1978 = alloca i64, align 8
  %slot1979 = alloca i64, align 8
  %slot1980 = alloca i64, align 8
  %slot1981 = alloca i64, align 8
  %slot1982 = alloca i32, align 8
  %slot1983 = alloca i64, align 8
  %slot1984 = alloca i64, align 8
  %slot1985 = alloca i64, align 8
  %slot1986 = alloca i64, align 8
  %slot1987 = alloca i64, align 8
  %slot1988 = alloca i64, align 8
  %slot1989 = alloca i64, align 8
  %slot1990 = alloca i64, align 8
  %slot1991 = alloca i64, align 8
  %slot1992 = alloca i64, align 8
  %slot1993 = alloca i64, align 8
  %slot1994 = alloca i32, align 8
  %slot1995 = alloca i32, align 8
  %slot1996 = alloca i32, align 8
  %slot1997 = alloca i32, align 8
  %slot1998 = alloca i64, align 8
  %slot1999 = alloca i64, align 8
  %slot2000 = alloca i32, align 8
  %slot2001 = alloca i32, align 8
  %slot2002 = alloca i32, align 8
  %slot2003 = alloca i64, align 8
  %slot2004 = alloca i64, align 8
  %slot2005 = alloca i32, align 8
  %slot2006 = alloca i32, align 8
  %slot2007 = alloca i32, align 8
  %slot2008 = alloca i32, align 8
  %slot2009 = alloca i64, align 8
  %slot2010 = alloca i32, align 8
  %slot2011 = alloca i32, align 8
  %slot2012 = alloca i64, align 8
  %slot2013 = alloca i64, align 8
  %slot2014 = alloca i64, align 8
  %slot2015 = alloca i64, align 8
  %slot2016 = alloca i64, align 8
  %slot2017 = alloca i64, align 8
  %slot2018 = alloca i64, align 8
  %slot2019 = alloca i64, align 8
  %slot2020 = alloca i64, align 8
  %slot2021 = alloca i64, align 8
  %slot2022 = alloca i64, align 8
  %slot2023 = alloca i64, align 8
  %slot2024 = alloca i64, align 8
  %slot2025 = alloca i64, align 8
  %slot2026 = alloca i64, align 8
  %slot2027 = alloca i64, align 8
  %slot2028 = alloca i64, align 8
  %slot2029 = alloca i64, align 8
  %slot2030 = alloca i32, align 8
  %slot2031 = alloca i32, align 8
  %slot2032 = alloca i32, align 8
  %slot2033 = alloca i64, align 8
  %slot2034 = alloca i64, align 8
  %slot2035 = alloca i64, align 8
  %slot2036 = alloca i64, align 8
  %slot2037 = alloca i64, align 8
  %slot2038 = alloca i64, align 8
  %slot2039 = alloca i32, align 8
  %slot2040 = alloca i64, align 8
  %slot2041 = alloca i32, align 8
  %slot2042 = alloca i32, align 8
  %slot2043 = alloca i64, align 8
  %slot2044 = alloca i64, align 8
  %slot2045 = alloca i32, align 8
  %slot2046 = alloca i64, align 8
  %slot2047 = alloca i32, align 8
  %slot2048 = alloca i32, align 8
  %slot2049 = alloca i64, align 8
  %slot2050 = alloca i64, align 8
  %slot2051 = alloca i64, align 8
  %slot2052 = alloca i64, align 8
  %slot2053 = alloca i64, align 8
  %slot2054 = alloca i64, align 8
  %slot2055 = alloca i64, align 8
  %slot2056 = alloca i64, align 8
  %slot2057 = alloca i64, align 8
  %slot2058 = alloca i32, align 8
  %slot2059 = alloca i32, align 8
  %slot2060 = alloca i64, align 8
  %slot2061 = alloca i32, align 8
  %slot2062 = alloca i32, align 8
  %slot2063 = alloca i64, align 8
  %slot2064 = alloca i64, align 8
  %slot2065 = alloca i32, align 8
  %slot2066 = alloca i64, align 8
  %slot2067 = alloca i32, align 8
  %slot2068 = alloca i32, align 8
  %slot2069 = alloca i64, align 8
  %slot2070 = alloca i64, align 8
  %slot2071 = alloca i32, align 8
  %slot2072 = alloca i64, align 8
  %slot2073 = alloca i32, align 8
  %slot2074 = alloca i32, align 8
  %slot2075 = alloca i64, align 8
  %slot2076 = alloca i64, align 8
  %slot2077 = alloca i32, align 8
  %slot2078 = alloca i64, align 8
  %slot2079 = alloca i64, align 8
  %slot2080 = alloca i64, align 8
  %slot2081 = alloca i32, align 8
  %slot2082 = alloca i64, align 8
  %slot2083 = alloca i64, align 8
  %slot2084 = alloca i64, align 8
  %slot2085 = alloca i32, align 8
  %slot2086 = alloca i64, align 8
  %slot2087 = alloca i64, align 8
  %slot2088 = alloca i32, align 8
  %slot2089 = alloca i64, align 8
  %slot2090 = alloca i64, align 8
  %slot2091 = alloca i32, align 8
  %slot2092 = alloca i64, align 8
  %slot2093 = alloca i64, align 8
  %slot2094 = alloca i64, align 8
  %slot2095 = alloca i32, align 8
  %slot2096 = alloca i64, align 8
  %slot2097 = alloca i64, align 8
  %slot2098 = alloca i64, align 8
  %slot2099 = alloca i32, align 8
  %slot2100 = alloca i64, align 8
  %slot2101 = alloca i64, align 8
  %slot2102 = alloca i32, align 8
  %slot2103 = alloca i32, align 8
  %slot2104 = alloca i64, align 8
  %slot2105 = alloca i32, align 8
  %slot2106 = alloca i32, align 8
  %slot2107 = alloca i64, align 8
  %slot2108 = alloca i64, align 8
  %slot2109 = alloca i32, align 8
  %slot2110 = alloca i64, align 8
  %slot2111 = alloca i64, align 8
  %slot2112 = alloca i64, align 8
  %slot2113 = alloca i32, align 8
  %slot2114 = alloca i64, align 8
  %slot2115 = alloca i64, align 8
  %slot2116 = alloca i64, align 8
  %slot2117 = alloca i32, align 8
  %slot2118 = alloca i64, align 8
  %slot2119 = alloca i64, align 8
  %slot2120 = alloca i32, align 8
  %slot2121 = alloca i64, align 8
  %slot2122 = alloca i64, align 8
  %slot2123 = alloca i32, align 8
  %slot2124 = alloca i64, align 8
  %slot2125 = alloca i64, align 8
  %slot2126 = alloca i64, align 8
  %slot2127 = alloca i32, align 8
  %slot2128 = alloca i64, align 8
  %slot2129 = alloca i64, align 8
  %slot2130 = alloca i64, align 8
  %slot2131 = alloca i32, align 8
  %slot2132 = alloca i64, align 8
  %slot2133 = alloca i64, align 8
  %slot2134 = alloca i32, align 8
  %slot2135 = alloca i32, align 8
  %slot2136 = alloca i64, align 8
  %slot2137 = alloca i32, align 8
  %slot2138 = alloca i32, align 8
  %slot2139 = alloca i64, align 8
  %slot2140 = alloca i64, align 8
  %slot2141 = alloca i64, align 8
  %slot2142 = alloca i64, align 8
  %slot2143 = alloca i64, align 8
  %slot2144 = alloca i64, align 8
  %slot2145 = alloca i64, align 8
  %slot2146 = alloca i32, align 8
  %slot2147 = alloca i64, align 8
  %slot2148 = alloca i32, align 8
  %slot2149 = alloca i32, align 8
  %slot2150 = alloca i64, align 8
  %slot2151 = alloca i64, align 8
  %slot2152 = alloca i64, align 8
  %slot2153 = alloca i64, align 8
  %slot2154 = alloca i64, align 8
  %slot2155 = alloca i64, align 8
  %slot2156 = alloca i64, align 8
  %callresult2157 = alloca [40 x i8], align 8
  %slot2158 = alloca i64, align 8
  %slot2159 = alloca i64, align 8
  %slot2160 = alloca i32, align 8
  %slot2161 = alloca i32, align 8
  %slot2162 = alloca i32, align 8
  %slot2163 = alloca i32, align 8
  %slot2164 = alloca i64, align 8
  %slot2165 = alloca i32, align 8
  %slot2166 = alloca i32, align 8
  %slot2167 = alloca i64, align 8
  %slot2168 = alloca i64, align 8
  %slot2169 = alloca i64, align 8
  %slot2170 = alloca i64, align 8
  %slot2171 = alloca i32, align 8
  %slot2172 = alloca i64, align 8
  %slot2173 = alloca i64, align 8
  %slot2174 = alloca i64, align 8
  %slot2175 = alloca i32, align 8
  %slot2176 = alloca i64, align 8
  %slot2177 = alloca i32, align 8
  %slot2178 = alloca i32, align 8
  %slot2179 = alloca i64, align 8
  %slot2180 = alloca i64, align 8
  %slot2181 = alloca i32, align 8
  %slot2182 = alloca i64, align 8
  %slot2183 = alloca i32, align 8
  %slot2184 = alloca i32, align 8
  %slot2185 = alloca i64, align 8
  %slot2186 = alloca i64, align 8
  %slot2187 = alloca i64, align 8
  %slot2188 = alloca i64, align 8
  %slot2189 = alloca i64, align 8
  %slot2190 = alloca i64, align 8
  %slot2191 = alloca i64, align 8
  %slot2192 = alloca i64, align 8
  %slot2193 = alloca i64, align 8
  %slot2194 = alloca i32, align 8
  %slot2195 = alloca i32, align 8
  %slot2196 = alloca i64, align 8
  %slot2197 = alloca i32, align 8
  %slot2198 = alloca i32, align 8
  %slot2199 = alloca i64, align 8
  %slot2200 = alloca i64, align 8
  %slot2201 = alloca i32, align 8
  %slot2202 = alloca i64, align 8
  %slot2203 = alloca i32, align 8
  %slot2204 = alloca i32, align 8
  %slot2205 = alloca i64, align 8
  %slot2206 = alloca i64, align 8
  %slot2207 = alloca i32, align 8
  %slot2208 = alloca i64, align 8
  %slot2209 = alloca i32, align 8
  %slot2210 = alloca i32, align 8
  %slot2211 = alloca i64, align 8
  %slot2212 = alloca i64, align 8
  %slot2213 = alloca i32, align 8
  %slot2214 = alloca i64, align 8
  %slot2215 = alloca i64, align 8
  %slot2216 = alloca i64, align 8
  %slot2217 = alloca i32, align 8
  %slot2218 = alloca i64, align 8
  %slot2219 = alloca i64, align 8
  %slot2220 = alloca i64, align 8
  %slot2221 = alloca i32, align 8
  %slot2222 = alloca i64, align 8
  %slot2223 = alloca i64, align 8
  %slot2224 = alloca i32, align 8
  %slot2225 = alloca i64, align 8
  %slot2226 = alloca i64, align 8
  %slot2227 = alloca i32, align 8
  %slot2228 = alloca i64, align 8
  %slot2229 = alloca i64, align 8
  %slot2230 = alloca i64, align 8
  %slot2231 = alloca i32, align 8
  %slot2232 = alloca i64, align 8
  %slot2233 = alloca i64, align 8
  %slot2234 = alloca i64, align 8
  %slot2235 = alloca i32, align 8
  %slot2236 = alloca i64, align 8
  %slot2237 = alloca i64, align 8
  %slot2238 = alloca i32, align 8
  %slot2239 = alloca i32, align 8
  %slot2240 = alloca i64, align 8
  %slot2241 = alloca i32, align 8
  %slot2242 = alloca i32, align 8
  %slot2243 = alloca i64, align 8
  %slot2244 = alloca i64, align 8
  %slot2245 = alloca i32, align 8
  %slot2246 = alloca i64, align 8
  %slot2247 = alloca i64, align 8
  %slot2248 = alloca i64, align 8
  %slot2249 = alloca i32, align 8
  %slot2250 = alloca i64, align 8
  %slot2251 = alloca i64, align 8
  %slot2252 = alloca i64, align 8
  %slot2253 = alloca i32, align 8
  %slot2254 = alloca i64, align 8
  %slot2255 = alloca i64, align 8
  %slot2256 = alloca i32, align 8
  %slot2257 = alloca i64, align 8
  %slot2258 = alloca i64, align 8
  %slot2259 = alloca i32, align 8
  %slot2260 = alloca i64, align 8
  %slot2261 = alloca i64, align 8
  %slot2262 = alloca i64, align 8
  %slot2263 = alloca i32, align 8
  %slot2264 = alloca i64, align 8
  %slot2265 = alloca i64, align 8
  %slot2266 = alloca i64, align 8
  %slot2267 = alloca i32, align 8
  %slot2268 = alloca i64, align 8
  %slot2269 = alloca i64, align 8
  %slot2270 = alloca i32, align 8
  %slot2271 = alloca i32, align 8
  %slot2272 = alloca i64, align 8
  %slot2273 = alloca i32, align 8
  %slot2274 = alloca i32, align 8
  %slot2275 = alloca i64, align 8
  %slot2276 = alloca i64, align 8
  %slot2277 = alloca i64, align 8
  %slot2278 = alloca i64, align 8
  %slot2279 = alloca i64, align 8
  %slot2280 = alloca i64, align 8
  %slot2281 = alloca i64, align 8
  %slot2282 = alloca i32, align 8
  %slot2283 = alloca i64, align 8
  %slot2284 = alloca i32, align 8
  %slot2285 = alloca i32, align 8
  %slot2286 = alloca i64, align 8
  %slot2287 = alloca i64, align 8
  %slot2288 = alloca i64, align 8
  %slot2289 = alloca i64, align 8
  %slot2290 = alloca i64, align 8
  %slot2291 = alloca i64, align 8
  %callresult2292 = alloca [16 x i8], align 8
  %slot2293 = alloca i32, align 8
  %slot2294 = alloca i64, align 8
  %slot2295 = alloca i32, align 8
  %slot2296 = alloca i32, align 8
  %slot2297 = alloca i64, align 8
  %slot2298 = alloca i64, align 8
  %slot2299 = alloca i64, align 8
  %slot2300 = alloca i64, align 8
  %slot2301 = alloca i64, align 8
  %slot2302 = alloca i64, align 8
  %slot2303 = alloca i64, align 8
  %slot2304 = alloca i64, align 8
  %slot2305 = alloca i64, align 8
  %slot2306 = alloca i64, align 8
  %slot2307 = alloca i64, align 8
  %slot2308 = alloca i64, align 8
  %slot2309 = alloca i64, align 8
  %slot2310 = alloca i64, align 8
  %slot2311 = alloca i64, align 8
  %slot2312 = alloca i64, align 8
  %slot2313 = alloca i32, align 8
  %slot2314 = alloca i32, align 8
  %slot2315 = alloca i64, align 8
  %slot2316 = alloca i32, align 8
  %slot2317 = alloca i32, align 8
  %slot2318 = alloca i64, align 8
  %slot2319 = alloca i64, align 8
  %slot2320 = alloca i32, align 8
  %slot2321 = alloca i64, align 8
  %slot2322 = alloca i32, align 8
  %slot2323 = alloca i32, align 8
  %slot2324 = alloca i64, align 8
  %slot2325 = alloca i64, align 8
  %slot2326 = alloca i32, align 8
  %slot2327 = alloca i64, align 8
  %slot2328 = alloca i32, align 8
  %slot2329 = alloca i32, align 8
  %slot2330 = alloca i64, align 8
  %slot2331 = alloca i64, align 8
  %slot2332 = alloca i32, align 8
  %slot2333 = alloca i64, align 8
  %slot2334 = alloca i64, align 8
  %slot2335 = alloca i64, align 8
  %slot2336 = alloca i32, align 8
  %slot2337 = alloca i64, align 8
  %slot2338 = alloca i64, align 8
  %slot2339 = alloca i64, align 8
  %slot2340 = alloca i32, align 8
  %slot2341 = alloca i64, align 8
  %slot2342 = alloca i64, align 8
  %slot2343 = alloca i32, align 8
  %slot2344 = alloca i64, align 8
  %slot2345 = alloca i64, align 8
  %slot2346 = alloca i32, align 8
  %slot2347 = alloca i64, align 8
  %slot2348 = alloca i64, align 8
  %slot2349 = alloca i64, align 8
  %slot2350 = alloca i32, align 8
  %slot2351 = alloca i64, align 8
  %slot2352 = alloca i64, align 8
  %slot2353 = alloca i64, align 8
  %slot2354 = alloca i32, align 8
  %slot2355 = alloca i64, align 8
  %slot2356 = alloca i64, align 8
  %slot2357 = alloca i32, align 8
  %slot2358 = alloca i32, align 8
  %slot2359 = alloca i64, align 8
  %slot2360 = alloca i32, align 8
  %slot2361 = alloca i32, align 8
  %slot2362 = alloca i64, align 8
  %slot2363 = alloca i64, align 8
  %slot2364 = alloca i32, align 8
  %slot2365 = alloca i64, align 8
  %slot2366 = alloca i64, align 8
  %slot2367 = alloca i64, align 8
  %slot2368 = alloca i32, align 8
  %slot2369 = alloca i64, align 8
  %slot2370 = alloca i64, align 8
  %slot2371 = alloca i64, align 8
  %slot2372 = alloca i32, align 8
  %slot2373 = alloca i64, align 8
  %slot2374 = alloca i64, align 8
  %slot2375 = alloca i32, align 8
  %slot2376 = alloca i64, align 8
  %slot2377 = alloca i64, align 8
  %slot2378 = alloca i32, align 8
  %slot2379 = alloca i64, align 8
  %slot2380 = alloca i64, align 8
  %slot2381 = alloca i64, align 8
  %slot2382 = alloca i32, align 8
  %slot2383 = alloca i64, align 8
  %slot2384 = alloca i64, align 8
  %slot2385 = alloca i64, align 8
  %slot2386 = alloca i32, align 8
  %slot2387 = alloca i64, align 8
  %slot2388 = alloca i64, align 8
  %slot2389 = alloca i32, align 8
  %slot2390 = alloca i32, align 8
  %slot2391 = alloca i64, align 8
  %slot2392 = alloca i32, align 8
  %slot2393 = alloca i32, align 8
  %slot2394 = alloca i64, align 8
  %slot2395 = alloca i64, align 8
  %slot2396 = alloca i64, align 8
  %slot2397 = alloca i64, align 8
  %slot2398 = alloca i64, align 8
  %slot2399 = alloca i64, align 8
  %slot2400 = alloca i64, align 8
  %slot2401 = alloca i64, align 8
  %slot2402 = alloca i64, align 8
  %slot2403 = alloca i64, align 8
  %slot2404 = alloca i64, align 8
  %slot2405 = alloca i32, align 8
  %slot2406 = alloca i64, align 8
  %slot2407 = alloca i64, align 8
  %slot2408 = alloca i64, align 8
  %slot2409 = alloca i64, align 8
  %slot2410 = alloca i64, align 8
  %callresult2411 = alloca [48 x i8], align 8
  %slot2412 = alloca i64, align 8
  %slot2413 = alloca i64, align 8
  %slot2414 = alloca i32, align 8
  %slot2415 = alloca i64, align 8
  %slot2416 = alloca i32, align 8
  %slot2417 = alloca i32, align 8
  %slot2418 = alloca i64, align 8
  %slot2419 = alloca i64, align 8
  %slot2420 = alloca i32, align 8
  %slot2421 = alloca i64, align 8
  %slot2422 = alloca i32, align 8
  %slot2423 = alloca i32, align 8
  %slot2424 = alloca i64, align 8
  %slot2425 = alloca i64, align 8
  %slot2426 = alloca i32, align 8
  %slot2427 = alloca i64, align 8
  %slot2428 = alloca i64, align 8
  %slot2429 = alloca i64, align 8
  %slot2430 = alloca i32, align 8
  %slot2431 = alloca i64, align 8
  %slot2432 = alloca i64, align 8
  %slot2433 = alloca i64, align 8
  %slot2434 = alloca i32, align 8
  %slot2435 = alloca i64, align 8
  %slot2436 = alloca i64, align 8
  %slot2437 = alloca i32, align 8
  %slot2438 = alloca i64, align 8
  %slot2439 = alloca i64, align 8
  %slot2440 = alloca i32, align 8
  %slot2441 = alloca i64, align 8
  %slot2442 = alloca i64, align 8
  %slot2443 = alloca i64, align 8
  %slot2444 = alloca i32, align 8
  %slot2445 = alloca i64, align 8
  %slot2446 = alloca i64, align 8
  %slot2447 = alloca i64, align 8
  %slot2448 = alloca i32, align 8
  %slot2449 = alloca i64, align 8
  %slot2450 = alloca i64, align 8
  %slot2451 = alloca i32, align 8
  %slot2452 = alloca i64, align 8
  %slot2453 = alloca i64, align 8
  %slot2454 = alloca i32, align 8
  %slot2455 = alloca i64, align 8
  %slot2456 = alloca i64, align 8
  %slot2457 = alloca i64, align 8
  %slot2458 = alloca i64, align 8
  %slot2459 = alloca i64, align 8
  %slot2460 = alloca i64, align 8
  %slot2461 = alloca i64, align 8
  %slot2462 = alloca i64, align 8
  %slot2463 = alloca i32, align 8
  %slot2464 = alloca i64, align 8
  %slot2465 = alloca i32, align 8
  %slot2466 = alloca i32, align 8
  %slot2467 = alloca i64, align 8
  %slot2468 = alloca i64, align 8
  %slot2469 = alloca i64, align 8
  %slot2470 = alloca i64, align 8
  %slot2471 = alloca i64, align 8
  %slot2472 = alloca i64, align 8
  %slot2473 = alloca i64, align 8
  %slot2474 = alloca i64, align 8
  %slot2475 = alloca i64, align 8
  %slot2476 = alloca i32, align 8
  %slot2477 = alloca i32, align 8
  %slot2478 = alloca i32, align 8
  %slot2479 = alloca i64, align 8
  %slot2480 = alloca i64, align 8
  %slot2481 = alloca i32, align 8
  %slot2482 = alloca i64, align 8
  %slot2483 = alloca i32, align 8
  %slot2484 = alloca i32, align 8
  %slot2485 = alloca i64, align 8
  %slot2486 = alloca i64, align 8
  %slot2487 = alloca i64, align 8
  %slot2488 = alloca i64, align 8
  %slot2489 = alloca i32, align 8
  %slot2490 = alloca i64, align 8
  %slot2491 = alloca i32, align 8
  %slot2492 = alloca i32, align 8
  %slot2493 = alloca i64, align 8
  %slot2494 = alloca i32, align 8
  %slot2495 = alloca i32, align 8
  %slot2496 = alloca i64, align 8
  %slot2497 = alloca i64, align 8
  %slot2498 = alloca i32, align 8
  %slot2499 = alloca i64, align 8
  %slot2500 = alloca i32, align 8
  %slot2501 = alloca i32, align 8
  %slot2502 = alloca i64, align 8
  %slot2503 = alloca i64, align 8
  %slot2504 = alloca i32, align 8
  %slot2505 = alloca i64, align 8
  %slot2506 = alloca i32, align 8
  %slot2507 = alloca i32, align 8
  %slot2508 = alloca i64, align 8
  %slot2509 = alloca i64, align 8
  %slot2510 = alloca i32, align 8
  %slot2511 = alloca i64, align 8
  %slot2512 = alloca i64, align 8
  %slot2513 = alloca i64, align 8
  %slot2514 = alloca i32, align 8
  %slot2515 = alloca i64, align 8
  %slot2516 = alloca i64, align 8
  %slot2517 = alloca i64, align 8
  %slot2518 = alloca i32, align 8
  %slot2519 = alloca i64, align 8
  %slot2520 = alloca i64, align 8
  %slot2521 = alloca i32, align 8
  %slot2522 = alloca i64, align 8
  %slot2523 = alloca i64, align 8
  %slot2524 = alloca i32, align 8
  %slot2525 = alloca i64, align 8
  %slot2526 = alloca i64, align 8
  %slot2527 = alloca i64, align 8
  %slot2528 = alloca i32, align 8
  %slot2529 = alloca i64, align 8
  %slot2530 = alloca i64, align 8
  %slot2531 = alloca i64, align 8
  %slot2532 = alloca i32, align 8
  %slot2533 = alloca i64, align 8
  %slot2534 = alloca i64, align 8
  %slot2535 = alloca i32, align 8
  %slot2536 = alloca i32, align 8
  %slot2537 = alloca i64, align 8
  %slot2538 = alloca i32, align 8
  %slot2539 = alloca i32, align 8
  %slot2540 = alloca i64, align 8
  %slot2541 = alloca i64, align 8
  %slot2542 = alloca i32, align 8
  %slot2543 = alloca i64, align 8
  %slot2544 = alloca i64, align 8
  %slot2545 = alloca i64, align 8
  %slot2546 = alloca i32, align 8
  %slot2547 = alloca i64, align 8
  %slot2548 = alloca i64, align 8
  %slot2549 = alloca i64, align 8
  %slot2550 = alloca i32, align 8
  %slot2551 = alloca i64, align 8
  %slot2552 = alloca i64, align 8
  %slot2553 = alloca i32, align 8
  %slot2554 = alloca i64, align 8
  %slot2555 = alloca i64, align 8
  %slot2556 = alloca i32, align 8
  %slot2557 = alloca i64, align 8
  %slot2558 = alloca i64, align 8
  %slot2559 = alloca i64, align 8
  %slot2560 = alloca i32, align 8
  %slot2561 = alloca i64, align 8
  %slot2562 = alloca i64, align 8
  %slot2563 = alloca i64, align 8
  %slot2564 = alloca i32, align 8
  %slot2565 = alloca i64, align 8
  %slot2566 = alloca i64, align 8
  %slot2567 = alloca i32, align 8
  %slot2568 = alloca i32, align 8
  %slot2569 = alloca i64, align 8
  %slot2570 = alloca i32, align 8
  %slot2571 = alloca i32, align 8
  %slot2572 = alloca i64, align 8
  %slot2573 = alloca i64, align 8
  %slot2574 = alloca i32, align 8
  %slot2575 = alloca i64, align 8
  %slot2576 = alloca i32, align 8
  %slot2577 = alloca i32, align 8
  %slot2578 = alloca i64, align 8
  %slot2579 = alloca i64, align 8
  %slot2580 = alloca i64, align 8
  %slot2581 = alloca i64, align 8
  %slot2582 = alloca i64, align 8
  %slot2583 = alloca i64, align 8
  %slot2584 = alloca i64, align 8
  %slot2585 = alloca i64, align 8
  %slot2586 = alloca i64, align 8
  %slot2587 = alloca i64, align 8
  %slot2588 = alloca i64, align 8
  %slot2589 = alloca i64, align 8
  %slot2590 = alloca i64, align 8
  %slot2591 = alloca i64, align 8
  %slot2592 = alloca i64, align 8
  %slot2593 = alloca i64, align 8
  %slot2594 = alloca i64, align 8
  %slot2595 = alloca i64, align 8
  %slot2596 = alloca i32, align 8
  %slot2597 = alloca i64, align 8
  %slot2598 = alloca i32, align 8
  %slot2599 = alloca i32, align 8
  %slot2600 = alloca i64, align 8
  %slot2601 = alloca i64, align 8
  %slot2602 = alloca i32, align 8
  %slot2603 = alloca i64, align 8
  %slot2604 = alloca i32, align 8
  %slot2605 = alloca i32, align 8
  %slot2606 = alloca i64, align 8
  %slot2607 = alloca i64, align 8
  %slot2608 = alloca i64, align 8
  %slot2609 = alloca i64, align 8
  %slot2610 = alloca i64, align 8
  %slot2611 = alloca i64, align 8
  %slot2612 = alloca i64, align 8
  %slot2613 = alloca i64, align 8
  %slot2614 = alloca i64, align 8
  %slot2615 = alloca i32, align 8
  %slot2616 = alloca i32, align 8
  %slot2617 = alloca i64, align 8
  %slot2618 = alloca i32, align 8
  %slot2619 = alloca i32, align 8
  %slot2620 = alloca i64, align 8
  %slot2621 = alloca i64, align 8
  %slot2622 = alloca i32, align 8
  %slot2623 = alloca i64, align 8
  %slot2624 = alloca i32, align 8
  %slot2625 = alloca i32, align 8
  %slot2626 = alloca i64, align 8
  %slot2627 = alloca i64, align 8
  %slot2628 = alloca i32, align 8
  %slot2629 = alloca i64, align 8
  %slot2630 = alloca i32, align 8
  %slot2631 = alloca i32, align 8
  %slot2632 = alloca i64, align 8
  %slot2633 = alloca i64, align 8
  %slot2634 = alloca i32, align 8
  %slot2635 = alloca i64, align 8
  %slot2636 = alloca i64, align 8
  %slot2637 = alloca i64, align 8
  %slot2638 = alloca i32, align 8
  %slot2639 = alloca i64, align 8
  %slot2640 = alloca i64, align 8
  %slot2641 = alloca i64, align 8
  %slot2642 = alloca i32, align 8
  %slot2643 = alloca i64, align 8
  %slot2644 = alloca i64, align 8
  %slot2645 = alloca i32, align 8
  %slot2646 = alloca i64, align 8
  %slot2647 = alloca i64, align 8
  %slot2648 = alloca i32, align 8
  %slot2649 = alloca i64, align 8
  %slot2650 = alloca i64, align 8
  %slot2651 = alloca i64, align 8
  %slot2652 = alloca i32, align 8
  %slot2653 = alloca i64, align 8
  %slot2654 = alloca i64, align 8
  %slot2655 = alloca i64, align 8
  %slot2656 = alloca i32, align 8
  %slot2657 = alloca i64, align 8
  %slot2658 = alloca i64, align 8
  %slot2659 = alloca i32, align 8
  %slot2660 = alloca i32, align 8
  %slot2661 = alloca i64, align 8
  %slot2662 = alloca i32, align 8
  %slot2663 = alloca i32, align 8
  %slot2664 = alloca i64, align 8
  %slot2665 = alloca i64, align 8
  %slot2666 = alloca i32, align 8
  %slot2667 = alloca i64, align 8
  %slot2668 = alloca i64, align 8
  %slot2669 = alloca i64, align 8
  %slot2670 = alloca i32, align 8
  %slot2671 = alloca i64, align 8
  %slot2672 = alloca i64, align 8
  %slot2673 = alloca i64, align 8
  %slot2674 = alloca i32, align 8
  %slot2675 = alloca i64, align 8
  %slot2676 = alloca i64, align 8
  %slot2677 = alloca i32, align 8
  %slot2678 = alloca i64, align 8
  %slot2679 = alloca i64, align 8
  %slot2680 = alloca i32, align 8
  %slot2681 = alloca i64, align 8
  %slot2682 = alloca i64, align 8
  %slot2683 = alloca i64, align 8
  %slot2684 = alloca i32, align 8
  %slot2685 = alloca i64, align 8
  %slot2686 = alloca i64, align 8
  %slot2687 = alloca i64, align 8
  %slot2688 = alloca i32, align 8
  %slot2689 = alloca i64, align 8
  %slot2690 = alloca i64, align 8
  %slot2691 = alloca i32, align 8
  %slot2692 = alloca i32, align 8
  %slot2693 = alloca i64, align 8
  %slot2694 = alloca i32, align 8
  %slot2695 = alloca i32, align 8
  %slot2696 = alloca i64, align 8
  %slot2697 = alloca i64, align 8
  %slot2698 = alloca i64, align 8
  %slot2699 = alloca i64, align 8
  %slot2700 = alloca i64, align 8
  %slot2701 = alloca i64, align 8
  %callresult2702 = alloca [40 x i8], align 8
  %slot2703 = alloca i64, align 8
  %slot2704 = alloca i64, align 8
  %slot2705 = alloca i32, align 8
  %slot2706 = alloca i32, align 8
  %slot2707 = alloca i32, align 8
  %slot2708 = alloca i32, align 8
  %slot2709 = alloca i64, align 8
  %slot2710 = alloca i32, align 8
  %slot2711 = alloca i32, align 8
  %slot2712 = alloca i64, align 8
  %slot2713 = alloca i64, align 8
  %slot2714 = alloca i64, align 8
  %slot2715 = alloca i64, align 8
  %slot2716 = alloca i32, align 8
  %slot2717 = alloca i64, align 8
  %slot2718 = alloca i64, align 8
  %slot2719 = alloca i64, align 8
  %slot2720 = alloca i64, align 8
  %slot2721 = alloca i64, align 8
  %slot2722 = alloca i64, align 8
  %slot2723 = alloca i32, align 8
  %slot2724 = alloca i64, align 8
  %slot2725 = alloca i64, align 8
  %slot2726 = alloca i64, align 8
  %slot2727 = alloca i64, align 8
  %slot2728 = alloca i64, align 8
  %callresult2729 = alloca [1 x i8], align 1
  %slot2730 = alloca i32, align 8
  %slot2731 = alloca i64, align 8
  %slot2732 = alloca i32, align 8
  %slot2733 = alloca i32, align 8
  %slot2734 = alloca i64, align 8
  %slot2735 = alloca i64, align 8
  %slot2736 = alloca i32, align 8
  %slot2737 = alloca i64, align 8
  %slot2738 = alloca i32, align 8
  %slot2739 = alloca i32, align 8
  %slot2740 = alloca i64, align 8
  %slot2741 = alloca i64, align 8
  %slot2742 = alloca i32, align 8
  %slot2743 = alloca i64, align 8
  %slot2744 = alloca i32, align 8
  %slot2745 = alloca i32, align 8
  %slot2746 = alloca i64, align 8
  %slot2747 = alloca i64, align 8
  %slot2748 = alloca i32, align 8
  %slot2749 = alloca i64, align 8
  %slot2750 = alloca i64, align 8
  %slot2751 = alloca i64, align 8
  %slot2752 = alloca i32, align 8
  %slot2753 = alloca i64, align 8
  %slot2754 = alloca i64, align 8
  %slot2755 = alloca i64, align 8
  %slot2756 = alloca i32, align 8
  %slot2757 = alloca i64, align 8
  %slot2758 = alloca i64, align 8
  %slot2759 = alloca i32, align 8
  %slot2760 = alloca i64, align 8
  %slot2761 = alloca i64, align 8
  %slot2762 = alloca i32, align 8
  %slot2763 = alloca i64, align 8
  %slot2764 = alloca i64, align 8
  %slot2765 = alloca i64, align 8
  %slot2766 = alloca i32, align 8
  %slot2767 = alloca i64, align 8
  %slot2768 = alloca i64, align 8
  %slot2769 = alloca i64, align 8
  %slot2770 = alloca i32, align 8
  %slot2771 = alloca i64, align 8
  %slot2772 = alloca i64, align 8
  %slot2773 = alloca i32, align 8
  %slot2774 = alloca i64, align 8
  %slot2775 = alloca i64, align 8
  %slot2776 = alloca i64, align 8
  %slot2777 = alloca i64, align 8
  %slot2778 = alloca i64, align 8
  %slot2779 = alloca i64, align 8
  %slot2780 = alloca i32, align 8
  %slot2781 = alloca i32, align 8
  %slot2782 = alloca i64, align 8
  %slot2783 = alloca i32, align 8
  %slot2784 = alloca i32, align 8
  %slot2785 = alloca i64, align 8
  %slot2786 = alloca i64, align 8
  %slot2787 = alloca i32, align 8
  %slot2788 = alloca i64, align 8
  %slot2789 = alloca i32, align 8
  %slot2790 = alloca i32, align 8
  %slot2791 = alloca i64, align 8
  %slot2792 = alloca i64, align 8
  %slot2793 = alloca i32, align 8
  %slot2794 = alloca i64, align 8
  %slot2795 = alloca i32, align 8
  %slot2796 = alloca i32, align 8
  %slot2797 = alloca i64, align 8
  %slot2798 = alloca i64, align 8
  %slot2799 = alloca i32, align 8
  %slot2800 = alloca i64, align 8
  %slot2801 = alloca i64, align 8
  %slot2802 = alloca i64, align 8
  %slot2803 = alloca i32, align 8
  %slot2804 = alloca i64, align 8
  %slot2805 = alloca i64, align 8
  %slot2806 = alloca i64, align 8
  %slot2807 = alloca i32, align 8
  %slot2808 = alloca i64, align 8
  %slot2809 = alloca i64, align 8
  %slot2810 = alloca i32, align 8
  %slot2811 = alloca i64, align 8
  %slot2812 = alloca i64, align 8
  %slot2813 = alloca i32, align 8
  %slot2814 = alloca i64, align 8
  %slot2815 = alloca i64, align 8
  %slot2816 = alloca i64, align 8
  %slot2817 = alloca i32, align 8
  %slot2818 = alloca i64, align 8
  %slot2819 = alloca i64, align 8
  %slot2820 = alloca i64, align 8
  %slot2821 = alloca i32, align 8
  %slot2822 = alloca i64, align 8
  %slot2823 = alloca i64, align 8
  %slot2824 = alloca i32, align 8
  %slot2825 = alloca i32, align 8
  %slot2826 = alloca i64, align 8
  %slot2827 = alloca i32, align 8
  %slot2828 = alloca i32, align 8
  %slot2829 = alloca i64, align 8
  %slot2830 = alloca i64, align 8
  %slot2831 = alloca i32, align 8
  %slot2832 = alloca i64, align 8
  %slot2833 = alloca i64, align 8
  %slot2834 = alloca i64, align 8
  %slot2835 = alloca i32, align 8
  %slot2836 = alloca i64, align 8
  %slot2837 = alloca i64, align 8
  %slot2838 = alloca i64, align 8
  %slot2839 = alloca i32, align 8
  %slot2840 = alloca i64, align 8
  %slot2841 = alloca i64, align 8
  %slot2842 = alloca i32, align 8
  %slot2843 = alloca i64, align 8
  %slot2844 = alloca i64, align 8
  %slot2845 = alloca i32, align 8
  %slot2846 = alloca i64, align 8
  %slot2847 = alloca i64, align 8
  %slot2848 = alloca i64, align 8
  %slot2849 = alloca i32, align 8
  %slot2850 = alloca i64, align 8
  %slot2851 = alloca i64, align 8
  %slot2852 = alloca i64, align 8
  %slot2853 = alloca i32, align 8
  %slot2854 = alloca i64, align 8
  %slot2855 = alloca i64, align 8
  %slot2856 = alloca i32, align 8
  %slot2857 = alloca i32, align 8
  %slot2858 = alloca i64, align 8
  %slot2859 = alloca i32, align 8
  %slot2860 = alloca i32, align 8
  %slot2861 = alloca i64, align 8
  %slot2862 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v2863 = load i64, ptr %slot1, align 8
  %op2864 = add i64 %v2863, 32
  store i64 %op2864, ptr %slot3, align 8
  %mem2865 = alloca i8, i64 16, align 8
  %ptr2866 = ptrtoint ptr %mem2865 to i64
  store i64 %ptr2866, ptr %slot4, align 8
  %mem2867 = alloca i8, i64 8, align 8
  %ptr2868 = ptrtoint ptr %mem2867 to i64
  store i64 %ptr2868, ptr %slot5, align 8
  %mem2869 = alloca i8, i64 8, align 8
  %ptr2870 = ptrtoint ptr %mem2869 to i64
  store i64 %ptr2870, ptr %slot6, align 8
  %mem2871 = alloca i8, i64 8, align 8
  %ptr2872 = ptrtoint ptr %mem2871 to i64
  store i64 %ptr2872, ptr %slot7, align 8
  %mem2873 = alloca i8, i64 8, align 8
  %ptr2874 = ptrtoint ptr %mem2873 to i64
  store i64 %ptr2874, ptr %slot8, align 8
  %mem2875 = alloca i8, i64 8, align 8
  %ptr2876 = ptrtoint ptr %mem2875 to i64
  store i64 %ptr2876, ptr %slot9, align 8
  %mem2877 = alloca i8, i64 8, align 8
  %ptr2878 = ptrtoint ptr %mem2877 to i64
  store i64 %ptr2878, ptr %slot10, align 8
  %mem2879 = alloca i8, i64 8, align 8
  %ptr2880 = ptrtoint ptr %mem2879 to i64
  store i64 %ptr2880, ptr %slot11, align 8
  %mem2881 = alloca i8, i64 8, align 8
  %ptr2882 = ptrtoint ptr %mem2881 to i64
  store i64 %ptr2882, ptr %slot12, align 8
  %mem2883 = alloca i8, i64 8, align 8
  %ptr2884 = ptrtoint ptr %mem2883 to i64
  store i64 %ptr2884, ptr %slot13, align 8
  %mem2885 = alloca i8, i64 8, align 8
  %ptr2886 = ptrtoint ptr %mem2885 to i64
  store i64 %ptr2886, ptr %slot14, align 8
  %mem2887 = alloca i8, i64 8, align 8
  %ptr2888 = ptrtoint ptr %mem2887 to i64
  store i64 %ptr2888, ptr %slot15, align 8
  %mem2889 = alloca i8, i64 8, align 8
  %ptr2890 = ptrtoint ptr %mem2889 to i64
  store i64 %ptr2890, ptr %slot16, align 8
  %mem2891 = alloca i8, i64 8, align 8
  %ptr2892 = ptrtoint ptr %mem2891 to i64
  store i64 %ptr2892, ptr %slot17, align 8
  %mem2893 = alloca i8, i64 8, align 8
  %ptr2894 = ptrtoint ptr %mem2893 to i64
  store i64 %ptr2894, ptr %slot18, align 8
  %mem2895 = alloca i8, i64 8, align 8
  %ptr2896 = ptrtoint ptr %mem2895 to i64
  store i64 %ptr2896, ptr %slot19, align 8
  %mem2897 = alloca i8, i64 8, align 8
  %ptr2898 = ptrtoint ptr %mem2897 to i64
  store i64 %ptr2898, ptr %slot20, align 8
  %mem2899 = alloca i8, i64 8, align 8
  %ptr2900 = ptrtoint ptr %mem2899 to i64
  store i64 %ptr2900, ptr %slot21, align 8
  %mem2901 = alloca i8, i64 8, align 8
  %ptr2902 = ptrtoint ptr %mem2901 to i64
  store i64 %ptr2902, ptr %slot22, align 8
  %mem2903 = alloca i8, i64 8, align 8
  %ptr2904 = ptrtoint ptr %mem2903 to i64
  store i64 %ptr2904, ptr %slot23, align 8
  %mem2905 = alloca i8, i64 312, align 8
  %ptr2906 = ptrtoint ptr %mem2905 to i64
  store i64 %ptr2906, ptr %slot24, align 8
  %mem2907 = alloca i8, i64 312, align 8
  %ptr2908 = ptrtoint ptr %mem2907 to i64
  store i64 %ptr2908, ptr %slot25, align 8
  %mem2909 = alloca i8, i64 312, align 8
  %ptr2910 = ptrtoint ptr %mem2909 to i64
  store i64 %ptr2910, ptr %slot26, align 8
  %mem2911 = alloca i8, i64 8, align 8
  %ptr2912 = ptrtoint ptr %mem2911 to i64
  store i64 %ptr2912, ptr %slot27, align 8
  %mem2913 = alloca i8, i64 8, align 8
  %ptr2914 = ptrtoint ptr %mem2913 to i64
  store i64 %ptr2914, ptr %slot28, align 8
  %mem2915 = alloca i8, i64 8, align 8
  %ptr2916 = ptrtoint ptr %mem2915 to i64
  store i64 %ptr2916, ptr %slot29, align 8
  %mem2917 = alloca i8, i64 312, align 8
  %ptr2918 = ptrtoint ptr %mem2917 to i64
  store i64 %ptr2918, ptr %slot30, align 8
  %mem2919 = alloca i8, i64 16, align 8
  %ptr2920 = ptrtoint ptr %mem2919 to i64
  store i64 %ptr2920, ptr %slot31, align 8
  %mem2921 = alloca i8, i64 8, align 8
  %ptr2922 = ptrtoint ptr %mem2921 to i64
  store i64 %ptr2922, ptr %slot32, align 8
  %mem2923 = alloca i8, i64 40, align 8
  %ptr2924 = ptrtoint ptr %mem2923 to i64
  store i64 %ptr2924, ptr %slot33, align 8
  %mem2925 = alloca i8, i64 8, align 8
  %ptr2926 = ptrtoint ptr %mem2925 to i64
  store i64 %ptr2926, ptr %slot34, align 8
  %mem2927 = alloca i8, i64 16, align 8
  %ptr2928 = ptrtoint ptr %mem2927 to i64
  store i64 %ptr2928, ptr %slot35, align 8
  %mem2929 = alloca i8, i64 8, align 8
  %ptr2930 = ptrtoint ptr %mem2929 to i64
  store i64 %ptr2930, ptr %slot36, align 8
  %mem2931 = alloca i8, i64 8, align 8
  %ptr2932 = ptrtoint ptr %mem2931 to i64
  store i64 %ptr2932, ptr %slot37, align 8
  %mem2933 = alloca i8, i64 8, align 8
  %ptr2934 = ptrtoint ptr %mem2933 to i64
  store i64 %ptr2934, ptr %slot38, align 8
  %mem2935 = alloca i8, i64 8, align 8
  %ptr2936 = ptrtoint ptr %mem2935 to i64
  store i64 %ptr2936, ptr %slot39, align 8
  %mem2937 = alloca i8, i64 8, align 8
  %ptr2938 = ptrtoint ptr %mem2937 to i64
  store i64 %ptr2938, ptr %slot40, align 8
  %mem2939 = alloca i8, i64 40, align 8
  %ptr2940 = ptrtoint ptr %mem2939 to i64
  store i64 %ptr2940, ptr %slot41, align 8
  %mem2941 = alloca i8, i64 40, align 8
  %ptr2942 = ptrtoint ptr %mem2941 to i64
  store i64 %ptr2942, ptr %slot42, align 8
  %mem2943 = alloca i8, i64 8, align 8
  %ptr2944 = ptrtoint ptr %mem2943 to i64
  store i64 %ptr2944, ptr %slot43, align 8
  %mem2945 = alloca i8, i64 8, align 8
  %ptr2946 = ptrtoint ptr %mem2945 to i64
  store i64 %ptr2946, ptr %slot44, align 8
  %mem2947 = alloca i8, i64 8, align 8
  %ptr2948 = ptrtoint ptr %mem2947 to i64
  store i64 %ptr2948, ptr %slot45, align 8
  %mem2949 = alloca i8, i64 8, align 8
  %ptr2950 = ptrtoint ptr %mem2949 to i64
  store i64 %ptr2950, ptr %slot46, align 8
  %mem2951 = alloca i8, i64 8, align 8
  %ptr2952 = ptrtoint ptr %mem2951 to i64
  store i64 %ptr2952, ptr %slot47, align 8
  %mem2953 = alloca i8, i64 8, align 8
  %ptr2954 = ptrtoint ptr %mem2953 to i64
  store i64 %ptr2954, ptr %slot48, align 8
  %mem2955 = alloca i8, i64 8, align 8
  %ptr2956 = ptrtoint ptr %mem2955 to i64
  store i64 %ptr2956, ptr %slot49, align 8
  %mem2957 = alloca i8, i64 312, align 8
  %ptr2958 = ptrtoint ptr %mem2957 to i64
  store i64 %ptr2958, ptr %slot50, align 8
  %mem2959 = alloca i8, i64 312, align 8
  %ptr2960 = ptrtoint ptr %mem2959 to i64
  store i64 %ptr2960, ptr %slot51, align 8
  %mem2961 = alloca i8, i64 312, align 8
  %ptr2962 = ptrtoint ptr %mem2961 to i64
  store i64 %ptr2962, ptr %slot52, align 8
  %mem2963 = alloca i8, i64 16, align 8
  %ptr2964 = ptrtoint ptr %mem2963 to i64
  store i64 %ptr2964, ptr %slot53, align 8
  %mem2965 = alloca i8, i64 312, align 8
  %ptr2966 = ptrtoint ptr %mem2965 to i64
  store i64 %ptr2966, ptr %slot54, align 8
  %mem2967 = alloca i8, i64 312, align 8
  %ptr2968 = ptrtoint ptr %mem2967 to i64
  store i64 %ptr2968, ptr %slot55, align 8
  %mem2969 = alloca i8, i64 312, align 8
  %ptr2970 = ptrtoint ptr %mem2969 to i64
  store i64 %ptr2970, ptr %slot56, align 8
  %mem2971 = alloca i8, i64 16, align 8
  %ptr2972 = ptrtoint ptr %mem2971 to i64
  store i64 %ptr2972, ptr %slot57, align 8
  %mem2973 = alloca i8, i64 312, align 8
  %ptr2974 = ptrtoint ptr %mem2973 to i64
  store i64 %ptr2974, ptr %slot58, align 8
  %mem2975 = alloca i8, i64 312, align 8
  %ptr2976 = ptrtoint ptr %mem2975 to i64
  store i64 %ptr2976, ptr %slot59, align 8
  %mem2977 = alloca i8, i64 312, align 8
  %ptr2978 = ptrtoint ptr %mem2977 to i64
  store i64 %ptr2978, ptr %slot60, align 8
  %mem2979 = alloca i8, i64 16, align 8
  %ptr2980 = ptrtoint ptr %mem2979 to i64
  store i64 %ptr2980, ptr %slot61, align 8
  %mem2981 = alloca i8, i64 312, align 8
  %ptr2982 = ptrtoint ptr %mem2981 to i64
  store i64 %ptr2982, ptr %slot62, align 8
  %mem2983 = alloca i8, i64 312, align 8
  %ptr2984 = ptrtoint ptr %mem2983 to i64
  store i64 %ptr2984, ptr %slot63, align 8
  %mem2985 = alloca i8, i64 16, align 8
  %ptr2986 = ptrtoint ptr %mem2985 to i64
  store i64 %ptr2986, ptr %slot64, align 8
  %mem2987 = alloca i8, i64 312, align 8
  %ptr2988 = ptrtoint ptr %mem2987 to i64
  store i64 %ptr2988, ptr %slot65, align 8
  %mem2989 = alloca i8, i64 312, align 8
  %ptr2990 = ptrtoint ptr %mem2989 to i64
  store i64 %ptr2990, ptr %slot66, align 8
  %mem2991 = alloca i8, i64 312, align 8
  %ptr2992 = ptrtoint ptr %mem2991 to i64
  store i64 %ptr2992, ptr %slot67, align 8
  %mem2993 = alloca i8, i64 16, align 8
  %ptr2994 = ptrtoint ptr %mem2993 to i64
  store i64 %ptr2994, ptr %slot68, align 8
  %mem2995 = alloca i8, i64 312, align 8
  %ptr2996 = ptrtoint ptr %mem2995 to i64
  store i64 %ptr2996, ptr %slot69, align 8
  %mem2997 = alloca i8, i64 312, align 8
  %ptr2998 = ptrtoint ptr %mem2997 to i64
  store i64 %ptr2998, ptr %slot70, align 8
  %mem2999 = alloca i8, i64 48, align 8
  %ptr3000 = ptrtoint ptr %mem2999 to i64
  store i64 %ptr3000, ptr %slot71, align 8
  %mem3001 = alloca i8, i64 312, align 8
  %ptr3002 = ptrtoint ptr %mem3001 to i64
  store i64 %ptr3002, ptr %slot72, align 8
  %mem3003 = alloca i8, i64 48, align 8
  %ptr3004 = ptrtoint ptr %mem3003 to i64
  store i64 %ptr3004, ptr %slot73, align 8
  %mem3005 = alloca i8, i64 312, align 8
  %ptr3006 = ptrtoint ptr %mem3005 to i64
  store i64 %ptr3006, ptr %slot74, align 8
  %mem3007 = alloca i8, i64 312, align 8
  %ptr3008 = ptrtoint ptr %mem3007 to i64
  store i64 %ptr3008, ptr %slot75, align 8
  %mem3009 = alloca i8, i64 16, align 8
  %ptr3010 = ptrtoint ptr %mem3009 to i64
  store i64 %ptr3010, ptr %slot76, align 8
  %mem3011 = alloca i8, i64 312, align 8
  %ptr3012 = ptrtoint ptr %mem3011 to i64
  store i64 %ptr3012, ptr %slot77, align 8
  %mem3013 = alloca i8, i64 312, align 8
  %ptr3014 = ptrtoint ptr %mem3013 to i64
  store i64 %ptr3014, ptr %slot78, align 8
  %mem3015 = alloca i8, i64 312, align 8
  %ptr3016 = ptrtoint ptr %mem3015 to i64
  store i64 %ptr3016, ptr %slot79, align 8
  %mem3017 = alloca i8, i64 312, align 8
  %ptr3018 = ptrtoint ptr %mem3017 to i64
  store i64 %ptr3018, ptr %slot80, align 8
  %mem3019 = alloca i8, i64 16, align 8
  %ptr3020 = ptrtoint ptr %mem3019 to i64
  store i64 %ptr3020, ptr %slot81, align 8
  %mem3021 = alloca i8, i64 312, align 8
  %ptr3022 = ptrtoint ptr %mem3021 to i64
  store i64 %ptr3022, ptr %slot82, align 8
  %mem3023 = alloca i8, i64 312, align 8
  %ptr3024 = ptrtoint ptr %mem3023 to i64
  store i64 %ptr3024, ptr %slot83, align 8
  %mem3025 = alloca i8, i64 16, align 8
  %ptr3026 = ptrtoint ptr %mem3025 to i64
  store i64 %ptr3026, ptr %slot84, align 8
  %mem3027 = alloca i8, i64 312, align 8
  %ptr3028 = ptrtoint ptr %mem3027 to i64
  store i64 %ptr3028, ptr %slot85, align 8
  %mem3029 = alloca i8, i64 16, align 8
  %ptr3030 = ptrtoint ptr %mem3029 to i64
  store i64 %ptr3030, ptr %slot86, align 8
  %mem3031 = alloca i8, i64 312, align 8
  %ptr3032 = ptrtoint ptr %mem3031 to i64
  store i64 %ptr3032, ptr %slot87, align 8
  %mem3033 = alloca i8, i64 48, align 8
  %ptr3034 = ptrtoint ptr %mem3033 to i64
  store i64 %ptr3034, ptr %slot88, align 8
  %mem3035 = alloca i8, i64 312, align 8
  %ptr3036 = ptrtoint ptr %mem3035 to i64
  store i64 %ptr3036, ptr %slot89, align 8
  %mem3037 = alloca i8, i64 312, align 8
  %ptr3038 = ptrtoint ptr %mem3037 to i64
  store i64 %ptr3038, ptr %slot90, align 8
  %mem3039 = alloca i8, i64 16, align 8
  %ptr3040 = ptrtoint ptr %mem3039 to i64
  store i64 %ptr3040, ptr %slot91, align 8
  %mem3041 = alloca i8, i64 312, align 8
  %ptr3042 = ptrtoint ptr %mem3041 to i64
  store i64 %ptr3042, ptr %slot92, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem3043 = alloca i8, i64 8, align 8
  %ptr3044 = ptrtoint ptr %mem3043 to i64
  store i64 %ptr3044, ptr %slot93, align 8
  %v3045 = load i64, ptr %slot1, align 8
  %op3046 = add i64 %v3045, 64
  store i64 %op3046, ptr %slot94, align 8
  %v3047 = load i64, ptr %slot94, align 8
  %p3048 = inttoptr i64 %v3047 to ptr
  %ld3049 = load i64, ptr %p3048, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3049, ptr %slot95, align 8
  %stack3050 = call ptr @llvm.stacksave()
  %stackaddr3051 = ptrtoint ptr %stack3050 to i64
  %v3052 = load i64, ptr %slot95, align 8
  %cmp3053 = icmp ult i64 %stackaddr3051, %v3052
  %cv3054 = zext i1 %cmp3053 to i64
  store i64 %cv3054, ptr %slot96, align 8
  %v3055 = load i64, ptr %slot96, align 8
  %cond3056 = icmp ne i64 %v3055, 0
  br i1 %cond3056, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v3057 = load i64, ptr %slot1, align 8
  %p3058 = inttoptr i64 %v3057 to ptr
  call void @myl_qbe_fail_frame(ptr %p3058) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %mem3059 = alloca i8, i64 16, align 8
  %ptr3060 = ptrtoint ptr %mem3059 to i64
  store i64 %ptr3060, ptr %slot97, align 8
  %mem3061 = alloca i8, i64 16, align 8
  %ptr3062 = ptrtoint ptr %mem3061 to i64
  store i64 %ptr3062, ptr %slot98, align 8
  %v3063 = load i64, ptr %slot34, align 8
  %p3064 = inttoptr i64 %v3063 to ptr
  store i64 0, ptr %p3064, align 8, !alias.scope !3, !noalias !4
  %v3065 = load i64, ptr %slot39, align 8
  %p3066 = inttoptr i64 %v3065 to ptr
  store i64 0, ptr %p3066, align 8, !alias.scope !3, !noalias !4
  %v3067 = load i64, ptr %slot2, align 8
  %v3068 = load i64, ptr %slot32, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  store i64 %v3067, ptr %p3069, align 8, !alias.scope !3, !noalias !4
  %v3070 = load i64, ptr %slot1, align 8
  %p3071 = inttoptr i64 %v3070 to ptr
  %call3072 = call ptr @myl_qbe_heap(ptr %p3071) nomerge, !dbg !112
  %calladdr3073 = ptrtoint ptr %call3072 to i64
  store i64 %calladdr3073, ptr %slot99, align 8
  %v3074 = load i64, ptr %slot1, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  %call3076 = call i64 @myl_qbe_region_mark(ptr %p3075) nomerge, !dbg !112
  store i64 %call3076, ptr %slot100, align 8
  %v3077 = load i64, ptr %slot5, align 8
  %p3078 = inttoptr i64 %v3077 to ptr
  store i32 0, ptr %p3078, align 4, !alias.scope !3, !noalias !4
  %v3079 = load i64, ptr %slot6, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  store i32 0, ptr %p3080, align 4, !alias.scope !3, !noalias !4
  %v3081 = load i64, ptr %slot7, align 8
  %p3082 = inttoptr i64 %v3081 to ptr
  store i32 0, ptr %p3082, align 4, !alias.scope !3, !noalias !4
  %v3083 = load i64, ptr %slot8, align 8
  %p3084 = inttoptr i64 %v3083 to ptr
  store i32 0, ptr %p3084, align 4, !alias.scope !3, !noalias !4
  %v3085 = load i64, ptr %slot9, align 8
  %p3086 = inttoptr i64 %v3085 to ptr
  store i32 0, ptr %p3086, align 4, !alias.scope !3, !noalias !4
  %v3087 = load i64, ptr %slot10, align 8
  %p3088 = inttoptr i64 %v3087 to ptr
  store i32 0, ptr %p3088, align 4, !alias.scope !3, !noalias !4
  %v3089 = load i64, ptr %slot11, align 8
  %p3090 = inttoptr i64 %v3089 to ptr
  store i32 0, ptr %p3090, align 4, !alias.scope !3, !noalias !4
  %v3091 = load i64, ptr %slot12, align 8
  %p3092 = inttoptr i64 %v3091 to ptr
  store i32 0, ptr %p3092, align 4, !alias.scope !3, !noalias !4
  %v3093 = load i64, ptr %slot13, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  store i32 0, ptr %p3094, align 4, !alias.scope !3, !noalias !4
  %v3095 = load i64, ptr %slot14, align 8
  %p3096 = inttoptr i64 %v3095 to ptr
  store i32 0, ptr %p3096, align 4, !alias.scope !3, !noalias !4
  %v3097 = load i64, ptr %slot15, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  store i32 0, ptr %p3098, align 4, !alias.scope !3, !noalias !4
  %v3099 = load i64, ptr %slot16, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  store i32 0, ptr %p3100, align 4, !alias.scope !3, !noalias !4
  %v3101 = load i64, ptr %slot17, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  store i32 0, ptr %p3102, align 4, !alias.scope !3, !noalias !4
  %v3103 = load i64, ptr %slot18, align 8
  %p3104 = inttoptr i64 %v3103 to ptr
  store i32 0, ptr %p3104, align 4, !alias.scope !3, !noalias !4
  %v3105 = load i64, ptr %slot19, align 8
  %p3106 = inttoptr i64 %v3105 to ptr
  store i32 0, ptr %p3106, align 4, !alias.scope !3, !noalias !4
  %v3107 = load i64, ptr %slot20, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  store i32 0, ptr %p3108, align 4, !alias.scope !3, !noalias !4
  %v3109 = load i64, ptr %slot21, align 8
  %p3110 = inttoptr i64 %v3109 to ptr
  store i32 0, ptr %p3110, align 4, !alias.scope !3, !noalias !4
  %v3111 = load i64, ptr %slot22, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  store i32 0, ptr %p3112, align 4, !alias.scope !3, !noalias !4
  %v3113 = load i64, ptr %slot23, align 8
  %p3114 = inttoptr i64 %v3113 to ptr
  store i32 0, ptr %p3114, align 4, !alias.scope !3, !noalias !4
  %v3115 = load i64, ptr %slot6, align 8
  %p3116 = inttoptr i64 %v3115 to ptr
  store i32 2, ptr %p3116, align 4, !alias.scope !3, !noalias !4
  %v3117 = load i64, ptr %slot8, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  store i32 2, ptr %p3118, align 4, !alias.scope !3, !noalias !4
  %v3119 = load i64, ptr %slot10, align 8
  %p3120 = inttoptr i64 %v3119 to ptr
  store i32 2, ptr %p3120, align 4, !alias.scope !3, !noalias !4
  %v3121 = load i64, ptr %slot12, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  store i32 2, ptr %p3122, align 4, !alias.scope !3, !noalias !4
  %v3123 = load i64, ptr %slot14, align 8
  %p3124 = inttoptr i64 %v3123 to ptr
  store i32 2, ptr %p3124, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v3125 = load i64, ptr %slot32, align 8
  %p3126 = inttoptr i64 %v3125 to ptr
  %ld3127 = load i64, ptr %p3126, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3127, ptr %slot101, align 8
  %v3128 = load i64, ptr %slot101, align 8
  %v3129 = load i64, ptr %slot44, align 8
  %p3130 = inttoptr i64 %v3129 to ptr
  store i64 %v3128, ptr %p3130, align 8, !alias.scope !3, !noalias !4
  %v3131 = load i64, ptr %slot50, align 8
  store i64 %v3131, ptr %slot102, align 8
  %v3132 = load i64, ptr %slot102, align 8
  %p3133 = inttoptr i64 %v3132 to ptr
  store i32 0, ptr %p3133, align 4, !alias.scope !3, !noalias !4
  %v3134 = load i64, ptr %slot102, align 8
  %p3135 = inttoptr i64 %v3134 to ptr
  store i32 25, ptr %p3135, align 4, !alias.scope !3, !noalias !4
  %v3136 = load i64, ptr %slot102, align 8
  %v3137 = load i64, ptr %slot45, align 8
  %p3138 = inttoptr i64 %v3137 to ptr
  store i64 %v3136, ptr %p3138, align 8, !alias.scope !3, !noalias !4
  %v3139 = load i64, ptr %slot44, align 8
  %p3140 = inttoptr i64 %v3139 to ptr
  %ld3141 = load i64, ptr %p3140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3141, ptr %slot103, align 8
  %v3142 = load i64, ptr %slot45, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %ld3144 = load i64, ptr %p3143, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3144, ptr %slot104, align 8
  %v3145 = load i64, ptr %slot1, align 8
  %v3146 = load i64, ptr %slot103, align 8
  %v3147 = load i64, ptr %slot104, align 8
  %call3148 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v3145, i64 %v3146, i64 %v3147) nomerge, !dbg !114
  store i64 %call3148, ptr %slot105, align 8
  %v3149 = load i64, ptr %slot105, align 8
  %v3150 = load i64, ptr %slot44, align 8
  %p3151 = inttoptr i64 %v3150 to ptr
  store i64 %v3149, ptr %p3151, align 8, !alias.scope !3, !noalias !4
  %v3152 = load i64, ptr %slot15, align 8
  %p3153 = inttoptr i64 %v3152 to ptr
  %ld3154 = load i32, ptr %p3153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3154, ptr %slot106, align 8
  %v3155 = load i32, ptr %slot106, align 8
  %cv3156 = zext i32 %v3155 to i64
  %cond3157 = icmp ne i64 %cv3156, 0
  br i1 %cond3157, label %bb_rcslotdrop20, label %bb_rcslotdone20
bb_rcslotdrop20:
  %v3158 = load i64, ptr %slot15, align 8
  %p3159 = inttoptr i64 %v3158 to ptr
  store i32 0, ptr %p3159, align 4, !alias.scope !3, !noalias !4
  %v3160 = load i64, ptr %slot24, align 8
  store i64 %v3160, ptr %slot107, align 8
  %v3161 = load i64, ptr %slot16, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  %ld3163 = load i32, ptr %p3162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3163, ptr %slot108, align 8
  %v3164 = load i32, ptr %slot108, align 8
  %op3165 = and i32 %v3164, 28
  store i32 %op3165, ptr %slot109, align 8
  %v3166 = load i32, ptr %slot109, align 8
  %cv3167 = zext i32 %v3166 to i64
  %cond3168 = icmp ne i64 %cv3167, 0
  br i1 %cond3168, label %bb_rcslotrole20, label %bb_rcslotowner20
bb_rcslotrole20:
  %v3169 = load i64, ptr %slot99, align 8
  store i64 %v3169, ptr %slot110, align 8
  %v3170 = load i64, ptr %slot110, align 8
  %v3171 = load i64, ptr %slot107, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3170, i64 %v3171) nomerge, !dbg !114
  br label %bb_rcslotdone20
bb_rcslotowner20:
  %v3172 = load i64, ptr %slot99, align 8
  store i64 %v3172, ptr %slot111, align 8
  %v3173 = load i64, ptr %slot111, align 8
  %v3174 = load i64, ptr %slot107, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3173, i64 %v3174) nomerge, !dbg !114
  br label %bb_rcslotdone20
bb_rcslotdone20:
  %v3175 = load i64, ptr %slot44, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  %ld3177 = load i64, ptr %p3176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3177, ptr %slot112, align 8
  %v3178 = load i64, ptr %slot112, align 8
  %cond3179 = icmp ne i64 %v3178, 0
  br i1 %cond3179, label %bb_next28, label %bb_i12
bb_next28:
  %v3180 = load i64, ptr %slot32, align 8
  %p3181 = inttoptr i64 %v3180 to ptr
  %ld3182 = load i64, ptr %p3181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3182, ptr %slot113, align 8
  %v3183 = load i64, ptr %slot113, align 8
  %v3184 = load i64, ptr %slot44, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  store i64 %v3183, ptr %p3185, align 8, !alias.scope !3, !noalias !4
  %v3186 = load i64, ptr %slot45, align 8
  %p3187 = inttoptr i64 %v3186 to ptr
  store i64 0, ptr %p3187, align 8, !alias.scope !3, !noalias !4
  %v3188 = load i64, ptr %slot51, align 8
  store i64 %v3188, ptr %slot114, align 8
  %v3189 = load i64, ptr %slot114, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  store i64 0, ptr %p3190, align 8, !alias.scope !3, !noalias !4
  %v3191 = load i64, ptr %slot114, align 8
  %p3193 = inttoptr i64 %v3191 to ptr
  %gep3194 = getelementptr i8, ptr %p3193, i64 8
  %op3192 = ptrtoint ptr %gep3194 to i64
  store i64 %op3192, ptr %slot115, align 8
  %v3195 = load i64, ptr %slot115, align 8
  %p3196 = inttoptr i64 %v3195 to ptr
  store i64 0, ptr %p3196, align 8, !alias.scope !3, !noalias !4
  %v3197 = load i64, ptr %slot114, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  store i32 1, ptr %p3198, align 4, !alias.scope !3, !noalias !4
  %v3199 = load i64, ptr %slot23, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  store i32 1, ptr %p3200, align 4, !alias.scope !3, !noalias !4
  %v3201 = load i64, ptr %slot45, align 8
  store i64 %v3201, ptr %slot116, align 8
  %v3202 = load i64, ptr %slot114, align 8
  %p3204 = inttoptr i64 %v3202 to ptr
  %gep3205 = getelementptr i8, ptr %p3204, i64 8
  %op3203 = ptrtoint ptr %gep3205 to i64
  store i64 %op3203, ptr %slot117, align 8
  %v3206 = load i64, ptr %slot100, align 8
  store i64 %v3206, ptr %slot118, align 8
  %v3207 = load i64, ptr %slot116, align 8
  %p3208 = inttoptr i64 %v3207 to ptr
  %ld3209 = load i8, ptr %p3208, align 1, !alias.scope !3, !noalias !4
  %ext3210 = zext i8 %ld3209 to i64
  store i64 %ext3210, ptr %slot119, align 8
  %v3211 = load i64, ptr %slot119, align 8
  %cv3212 = trunc i64 %v3211 to i8
  %v3213 = load i64, ptr %slot117, align 8
  %p3214 = inttoptr i64 %v3213 to ptr
  store i8 %cv3212, ptr %p3214, align 1, !alias.scope !3, !noalias !4
  %v3215 = load i64, ptr %slot114, align 8
  %v3216 = load i64, ptr %slot45, align 8
  %p3217 = inttoptr i64 %v3216 to ptr
  store i64 %v3215, ptr %p3217, align 8, !alias.scope !3, !noalias !4
  %v3218 = load i64, ptr %slot32, align 8
  %p3219 = inttoptr i64 %v3218 to ptr
  %ld3220 = load i64, ptr %p3219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3220, ptr %slot120, align 8
  %v3221 = load i64, ptr %slot120, align 8
  %v3222 = load i64, ptr %slot52, align 8
  %p3223 = inttoptr i64 %v3221 to ptr
  %p3224 = inttoptr i64 %v3222 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3224, ptr %p3223, i64 312, i1 false), !alias.scope !10000000
  %v3225 = load i64, ptr %slot52, align 8
  %v3226 = load i64, ptr %slot46, align 8
  %p3227 = inttoptr i64 %v3226 to ptr
  store i64 %v3225, ptr %p3227, align 8, !alias.scope !3, !noalias !4
  %v3228 = load i64, ptr %slot46, align 8
  %p3229 = inttoptr i64 %v3228 to ptr
  %ld3230 = load i64, ptr %p3229, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3230, ptr %slot121, align 8
  %v3231 = load i64, ptr %slot1, align 8
  %v3232 = load i64, ptr %slot121, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult123, i64 %v3231, i64 %v3232) nomerge, !dbg !116
  %addr3233 = ptrtoint ptr %callresult123 to i64
  store i64 %addr3233, ptr %slot122, align 8
  %v3234 = load i64, ptr %slot122, align 8
  %v3235 = load i64, ptr %slot46, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  store i64 %v3234, ptr %p3236, align 8, !alias.scope !3, !noalias !4
  %v3237 = load i64, ptr %slot46, align 8
  %p3238 = inttoptr i64 %v3237 to ptr
  %ld3239 = load i64, ptr %p3238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3239, ptr %slot124, align 8
  %v3240 = load i64, ptr %slot30, align 8
  store i64 %v3240, ptr %slot125, align 8
  %v3241 = load i64, ptr %slot99, align 8
  %v3242 = load i64, ptr %slot125, align 8
  %v3243 = load i64, ptr %slot124, align 8
  %call3244 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v3241, i64 %v3242, i64 %v3243) nomerge, !dbg !116
  store i32 %call3244, ptr %slot126, align 8
  %v3245 = load i32, ptr %slot126, align 8
  %cv3246 = zext i32 %v3245 to i64
  %cond3247 = icmp ne i64 %cv3246, 0
  br i1 %cond3247, label %bb_rcsuccess43, label %bb_rcfailure43
bb_rcfailure43:
  %v3248 = load i64, ptr %slot99, align 8
  %p3249 = inttoptr i64 %v3248 to ptr
  %call3250 = call i32 @myl_rc_take_failure(ptr %p3249) nomerge, !dbg !116
  store i32 %call3250, ptr %slot127, align 8
  %v3251 = load i64, ptr %slot1, align 8
  %p3252 = inttoptr i64 %v3251 to ptr
  %v3253 = load i32, ptr %slot127, align 8
  %call3254 = call i32 @myl_qbe_rc_status(ptr %p3252, i32 %v3253) nomerge, !dbg !116
  store i32 %call3254, ptr %slot128, align 8
  br label %bb_failure
bb_rcsuccess43:
  %v3255 = load i64, ptr %slot22, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  store i32 2, ptr %p3256, align 4, !alias.scope !3, !noalias !4
  %v3257 = load i64, ptr %slot22, align 8
  %p3258 = inttoptr i64 %v3257 to ptr
  store i32 16, ptr %p3258, align 4, !alias.scope !3, !noalias !4
  %v3259 = load i64, ptr %slot21, align 8
  %p3260 = inttoptr i64 %v3259 to ptr
  store i32 1, ptr %p3260, align 4, !alias.scope !3, !noalias !4
  %v3261 = load i64, ptr %slot19, align 8
  %p3262 = inttoptr i64 %v3261 to ptr
  %ld3263 = load i32, ptr %p3262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3263, ptr %slot129, align 8
  %v3264 = load i32, ptr %slot129, align 8
  %cv3265 = zext i32 %v3264 to i64
  %cond3266 = icmp ne i64 %cv3265, 0
  br i1 %cond3266, label %bb_rcslotdrop51, label %bb_rcslotdone51
bb_rcslotdrop51:
  %v3267 = load i64, ptr %slot19, align 8
  %p3268 = inttoptr i64 %v3267 to ptr
  store i32 0, ptr %p3268, align 4, !alias.scope !3, !noalias !4
  %v3269 = load i64, ptr %slot26, align 8
  store i64 %v3269, ptr %slot130, align 8
  %v3270 = load i64, ptr %slot20, align 8
  %p3271 = inttoptr i64 %v3270 to ptr
  %ld3272 = load i32, ptr %p3271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3272, ptr %slot131, align 8
  %v3273 = load i32, ptr %slot131, align 8
  %op3274 = and i32 %v3273, 28
  store i32 %op3274, ptr %slot132, align 8
  %v3275 = load i32, ptr %slot132, align 8
  %cv3276 = zext i32 %v3275 to i64
  %cond3277 = icmp ne i64 %cv3276, 0
  br i1 %cond3277, label %bb_rcslotrole51, label %bb_rcslotowner51
bb_rcslotrole51:
  %v3278 = load i64, ptr %slot99, align 8
  store i64 %v3278, ptr %slot133, align 8
  %v3279 = load i64, ptr %slot133, align 8
  %v3280 = load i64, ptr %slot130, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3279, i64 %v3280) nomerge, !dbg !116
  br label %bb_rcslotdone51
bb_rcslotowner51:
  %v3281 = load i64, ptr %slot99, align 8
  store i64 %v3281, ptr %slot134, align 8
  %v3282 = load i64, ptr %slot134, align 8
  %v3283 = load i64, ptr %slot130, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3282, i64 %v3283) nomerge, !dbg !116
  br label %bb_rcslotdone51
bb_rcslotdone51:
  %v3284 = load i64, ptr %slot26, align 8
  store i64 %v3284, ptr %slot135, align 8
  %v3285 = load i64, ptr %slot30, align 8
  store i64 %v3285, ptr %slot136, align 8
  %v3286 = load i64, ptr %slot136, align 8
  %v3287 = load i64, ptr %slot135, align 8
  %p3288 = inttoptr i64 %v3286 to ptr
  %p3289 = inttoptr i64 %v3287 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3289, ptr %p3288, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3290 = load i64, ptr %slot20, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  store i32 2, ptr %p3291, align 4, !alias.scope !3, !noalias !4
  %v3292 = load i64, ptr %slot22, align 8
  %p3293 = inttoptr i64 %v3292 to ptr
  %ld3294 = load i32, ptr %p3293, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3294, ptr %slot137, align 8
  %v3295 = load i32, ptr %slot137, align 8
  %v3296 = load i64, ptr %slot20, align 8
  %p3297 = inttoptr i64 %v3296 to ptr
  store i32 %v3295, ptr %p3297, align 4, !alias.scope !3, !noalias !4
  %v3298 = load i64, ptr %slot21, align 8
  %p3299 = inttoptr i64 %v3298 to ptr
  store i32 0, ptr %p3299, align 4, !alias.scope !3, !noalias !4
  %v3300 = load i64, ptr %slot19, align 8
  %p3301 = inttoptr i64 %v3300 to ptr
  store i32 1, ptr %p3301, align 4, !alias.scope !3, !noalias !4
  %v3302 = load i64, ptr %slot135, align 8
  %v3303 = load i64, ptr %slot46, align 8
  %p3304 = inttoptr i64 %v3303 to ptr
  store i64 %v3302, ptr %p3304, align 8, !alias.scope !3, !noalias !4
  %v3305 = load i64, ptr %slot44, align 8
  %p3306 = inttoptr i64 %v3305 to ptr
  %ld3307 = load i64, ptr %p3306, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3307, ptr %slot138, align 8
  %v3308 = load i64, ptr %slot45, align 8
  %p3309 = inttoptr i64 %v3308 to ptr
  %ld3310 = load i64, ptr %p3309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3310, ptr %slot139, align 8
  %v3311 = load i64, ptr %slot46, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  %ld3313 = load i64, ptr %p3312, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3313, ptr %slot140, align 8
  %v3314 = load i64, ptr %slot1, align 8
  %v3315 = load i64, ptr %slot138, align 8
  %v3316 = load i64, ptr %slot139, align 8
  %v3317 = load i64, ptr %slot140, align 8
  %call3318 = call i64 @myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623(i64 %v3314, i64 %v3315, i64 %v3316, i64 %v3317) nomerge, !dbg !118
  store i64 %call3318, ptr %slot141, align 8
  %v3319 = load i64, ptr %slot141, align 8
  %v3320 = load i64, ptr %slot44, align 8
  %p3321 = inttoptr i64 %v3320 to ptr
  store i64 %v3319, ptr %p3321, align 8, !alias.scope !3, !noalias !4
  %v3322 = load i64, ptr %slot15, align 8
  %p3323 = inttoptr i64 %v3322 to ptr
  %ld3324 = load i32, ptr %p3323, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3324, ptr %slot142, align 8
  %v3325 = load i32, ptr %slot142, align 8
  %cv3326 = zext i32 %v3325 to i64
  %cond3327 = icmp ne i64 %cv3326, 0
  br i1 %cond3327, label %bb_rcslotdrop72, label %bb_rcslotdone72
bb_rcslotdrop72:
  %v3328 = load i64, ptr %slot15, align 8
  %p3329 = inttoptr i64 %v3328 to ptr
  store i32 0, ptr %p3329, align 4, !alias.scope !3, !noalias !4
  %v3330 = load i64, ptr %slot24, align 8
  store i64 %v3330, ptr %slot143, align 8
  %v3331 = load i64, ptr %slot16, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  %ld3333 = load i32, ptr %p3332, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3333, ptr %slot144, align 8
  %v3334 = load i32, ptr %slot144, align 8
  %op3335 = and i32 %v3334, 28
  store i32 %op3335, ptr %slot145, align 8
  %v3336 = load i32, ptr %slot145, align 8
  %cv3337 = zext i32 %v3336 to i64
  %cond3338 = icmp ne i64 %cv3337, 0
  br i1 %cond3338, label %bb_rcslotrole72, label %bb_rcslotowner72
bb_rcslotrole72:
  %v3339 = load i64, ptr %slot99, align 8
  store i64 %v3339, ptr %slot146, align 8
  %v3340 = load i64, ptr %slot146, align 8
  %v3341 = load i64, ptr %slot143, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3340, i64 %v3341) nomerge, !dbg !118
  br label %bb_rcslotdone72
bb_rcslotowner72:
  %v3342 = load i64, ptr %slot99, align 8
  store i64 %v3342, ptr %slot147, align 8
  %v3343 = load i64, ptr %slot147, align 8
  %v3344 = load i64, ptr %slot143, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3343, i64 %v3344) nomerge, !dbg !118
  br label %bb_rcslotdone72
bb_rcslotdone72:
  %v3345 = load i64, ptr %slot19, align 8
  %p3346 = inttoptr i64 %v3345 to ptr
  %ld3347 = load i32, ptr %p3346, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3347, ptr %slot148, align 8
  %v3348 = load i32, ptr %slot148, align 8
  %cv3349 = zext i32 %v3348 to i64
  %cond3350 = icmp ne i64 %cv3349, 0
  br i1 %cond3350, label %bb_rcslotdrop81, label %bb_rcslotdone81
bb_rcslotdrop81:
  %v3351 = load i64, ptr %slot19, align 8
  %p3352 = inttoptr i64 %v3351 to ptr
  store i32 0, ptr %p3352, align 4, !alias.scope !3, !noalias !4
  %v3353 = load i64, ptr %slot26, align 8
  store i64 %v3353, ptr %slot149, align 8
  %v3354 = load i64, ptr %slot20, align 8
  %p3355 = inttoptr i64 %v3354 to ptr
  %ld3356 = load i32, ptr %p3355, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3356, ptr %slot150, align 8
  %v3357 = load i32, ptr %slot150, align 8
  %op3358 = and i32 %v3357, 28
  store i32 %op3358, ptr %slot151, align 8
  %v3359 = load i32, ptr %slot151, align 8
  %cv3360 = zext i32 %v3359 to i64
  %cond3361 = icmp ne i64 %cv3360, 0
  br i1 %cond3361, label %bb_rcslotrole81, label %bb_rcslotowner81
bb_rcslotrole81:
  %v3362 = load i64, ptr %slot99, align 8
  store i64 %v3362, ptr %slot152, align 8
  %v3363 = load i64, ptr %slot152, align 8
  %v3364 = load i64, ptr %slot149, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3363, i64 %v3364) nomerge, !dbg !118
  br label %bb_rcslotdone81
bb_rcslotowner81:
  %v3365 = load i64, ptr %slot99, align 8
  store i64 %v3365, ptr %slot153, align 8
  %v3366 = load i64, ptr %slot153, align 8
  %v3367 = load i64, ptr %slot149, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3366, i64 %v3367) nomerge, !dbg !118
  br label %bb_rcslotdone81
bb_rcslotdone81:
  %v3368 = load i64, ptr %slot53, align 8
  store i64 %v3368, ptr %slot154, align 8
  %v3369 = load i64, ptr %slot154, align 8
  %p3370 = inttoptr i64 %v3369 to ptr
  store i64 0, ptr %p3370, align 8, !alias.scope !3, !noalias !4
  %v3371 = load i64, ptr %slot154, align 8
  %p3373 = inttoptr i64 %v3371 to ptr
  %gep3374 = getelementptr i8, ptr %p3373, i64 8
  %op3372 = ptrtoint ptr %gep3374 to i64
  store i64 %op3372, ptr %slot155, align 8
  %v3375 = load i64, ptr %slot155, align 8
  %p3376 = inttoptr i64 %v3375 to ptr
  store i64 0, ptr %p3376, align 8, !alias.scope !3, !noalias !4
  %v3377 = load i64, ptr %slot154, align 8
  %p3378 = inttoptr i64 %v3377 to ptr
  store i32 0, ptr %p3378, align 4, !alias.scope !3, !noalias !4
  %v3379 = load i64, ptr %slot23, align 8
  %p3380 = inttoptr i64 %v3379 to ptr
  store i32 1, ptr %p3380, align 4, !alias.scope !3, !noalias !4
  %v3381 = load i64, ptr %slot44, align 8
  store i64 %v3381, ptr %slot156, align 8
  %v3382 = load i64, ptr %slot154, align 8
  %p3384 = inttoptr i64 %v3382 to ptr
  %gep3385 = getelementptr i8, ptr %p3384, i64 8
  %op3383 = ptrtoint ptr %gep3385 to i64
  store i64 %op3383, ptr %slot157, align 8
  %v3386 = load i64, ptr %slot100, align 8
  store i64 %v3386, ptr %slot158, align 8
  %v3387 = load i64, ptr %slot156, align 8
  %p3388 = inttoptr i64 %v3387 to ptr
  %ld3389 = load i64, ptr %p3388, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3389, ptr %slot159, align 8
  %v3390 = load i64, ptr %slot159, align 8
  %v3391 = load i64, ptr %slot157, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  store i64 %v3390, ptr %p3392, align 8, !alias.scope !3, !noalias !4
  %v3393 = load i64, ptr %slot154, align 8
  %v3394 = load i64, ptr %slot44, align 8
  %p3395 = inttoptr i64 %v3394 to ptr
  store i64 %v3393, ptr %p3395, align 8, !alias.scope !3, !noalias !4
  %v3396 = load i64, ptr %slot44, align 8
  %p3397 = inttoptr i64 %v3396 to ptr
  %ld3398 = load i64, ptr %p3397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3398, ptr %slot160, align 8
  %v3399 = load i64, ptr %slot15, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  %ld3401 = load i32, ptr %p3400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3401, ptr %slot161, align 8
  %v3402 = load i32, ptr %slot161, align 8
  %cv3403 = zext i32 %v3402 to i64
  %cond3404 = icmp ne i64 %cv3403, 0
  br i1 %cond3404, label %bb_rcslotdrop99, label %bb_rcslotdone99
bb_rcslotdrop99:
  %v3405 = load i64, ptr %slot15, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  store i32 0, ptr %p3406, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone99
bb_rcslotdone99:
  %v3407 = load i64, ptr %slot13, align 8
  %p3408 = inttoptr i64 %v3407 to ptr
  %ld3409 = load i32, ptr %p3408, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3409, ptr %slot162, align 8
  %v3410 = load i32, ptr %slot162, align 8
  %cv3411 = zext i32 %v3410 to i64
  %cond3412 = icmp ne i64 %cv3411, 0
  br i1 %cond3412, label %bb_rcslotdrop102, label %bb_rcslotdone102
bb_rcslotdrop102:
  %v3413 = load i64, ptr %slot13, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  store i32 0, ptr %p3414, align 4, !alias.scope !3, !noalias !4
  %v3415 = load i64, ptr %slot42, align 8
  store i64 %v3415, ptr %slot163, align 8
  %v3416 = load i64, ptr %slot14, align 8
  %p3417 = inttoptr i64 %v3416 to ptr
  %ld3418 = load i32, ptr %p3417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3418, ptr %slot164, align 8
  %v3419 = load i32, ptr %slot164, align 8
  %op3420 = and i32 %v3419, 28
  store i32 %op3420, ptr %slot165, align 8
  %v3421 = load i32, ptr %slot165, align 8
  %cv3422 = zext i32 %v3421 to i64
  %cond3423 = icmp ne i64 %cv3422, 0
  br i1 %cond3423, label %bb_rcslotrole102, label %bb_rcslotowner102
bb_rcslotrole102:
  %v3424 = load i64, ptr %slot99, align 8
  store i64 %v3424, ptr %slot166, align 8
  %v3425 = load i64, ptr %slot166, align 8
  %v3426 = load i64, ptr %slot163, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3425, i64 %v3426) nomerge, !dbg !120
  br label %bb_rcslotdone102
bb_rcslotowner102:
  %v3427 = load i64, ptr %slot99, align 8
  store i64 %v3427, ptr %slot167, align 8
  %v3428 = load i64, ptr %slot167, align 8
  %v3429 = load i64, ptr %slot163, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3428, i64 %v3429) nomerge, !dbg !120
  br label %bb_rcslotdone102
bb_rcslotdone102:
  %v3430 = load i64, ptr %slot11, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %ld3432 = load i32, ptr %p3431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3432, ptr %slot168, align 8
  %v3433 = load i32, ptr %slot168, align 8
  %cv3434 = zext i32 %v3433 to i64
  %cond3435 = icmp ne i64 %cv3434, 0
  br i1 %cond3435, label %bb_rcslotdrop111, label %bb_rcslotdone111
bb_rcslotdrop111:
  %v3436 = load i64, ptr %slot11, align 8
  %p3437 = inttoptr i64 %v3436 to ptr
  store i32 0, ptr %p3437, align 4, !alias.scope !3, !noalias !4
  %v3438 = load i64, ptr %slot41, align 8
  store i64 %v3438, ptr %slot169, align 8
  %v3439 = load i64, ptr %slot12, align 8
  %p3440 = inttoptr i64 %v3439 to ptr
  %ld3441 = load i32, ptr %p3440, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3441, ptr %slot170, align 8
  %v3442 = load i32, ptr %slot170, align 8
  %op3443 = and i32 %v3442, 28
  store i32 %op3443, ptr %slot171, align 8
  %v3444 = load i32, ptr %slot171, align 8
  %cv3445 = zext i32 %v3444 to i64
  %cond3446 = icmp ne i64 %cv3445, 0
  br i1 %cond3446, label %bb_rcslotrole111, label %bb_rcslotowner111
bb_rcslotrole111:
  %v3447 = load i64, ptr %slot99, align 8
  store i64 %v3447, ptr %slot172, align 8
  %v3448 = load i64, ptr %slot172, align 8
  %v3449 = load i64, ptr %slot169, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3448, i64 %v3449) nomerge, !dbg !120
  br label %bb_rcslotdone111
bb_rcslotowner111:
  %v3450 = load i64, ptr %slot99, align 8
  store i64 %v3450, ptr %slot173, align 8
  %v3451 = load i64, ptr %slot173, align 8
  %v3452 = load i64, ptr %slot169, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3451, i64 %v3452) nomerge, !dbg !120
  br label %bb_rcslotdone111
bb_rcslotdone111:
  %v3453 = load i64, ptr %slot9, align 8
  %p3454 = inttoptr i64 %v3453 to ptr
  %ld3455 = load i32, ptr %p3454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3455, ptr %slot174, align 8
  %v3456 = load i32, ptr %slot174, align 8
  %cv3457 = zext i32 %v3456 to i64
  %cond3458 = icmp ne i64 %cv3457, 0
  br i1 %cond3458, label %bb_rcslotdrop120, label %bb_rcslotdone120
bb_rcslotdrop120:
  %v3459 = load i64, ptr %slot9, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  store i32 0, ptr %p3460, align 4, !alias.scope !3, !noalias !4
  %v3461 = load i64, ptr %slot39, align 8
  store i64 %v3461, ptr %slot175, align 8
  %v3462 = load i64, ptr %slot10, align 8
  %p3463 = inttoptr i64 %v3462 to ptr
  %ld3464 = load i32, ptr %p3463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3464, ptr %slot176, align 8
  %v3465 = load i32, ptr %slot176, align 8
  %op3466 = and i32 %v3465, 28
  store i32 %op3466, ptr %slot177, align 8
  %v3467 = load i32, ptr %slot177, align 8
  %cv3468 = zext i32 %v3467 to i64
  %cond3469 = icmp ne i64 %cv3468, 0
  br i1 %cond3469, label %bb_rcslotrole120, label %bb_rcslotowner120
bb_rcslotrole120:
  %v3470 = load i64, ptr %slot99, align 8
  store i64 %v3470, ptr %slot178, align 8
  %v3471 = load i64, ptr %slot175, align 8
  %p3472 = inttoptr i64 %v3471 to ptr
  %ld3473 = load i64, ptr %p3472, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3473, ptr %slot179, align 8
  %v3474 = load i64, ptr %slot179, align 8
  %cmp3475 = icmp ne i64 %v3474, 0
  %cv3476 = zext i1 %cmp3475 to i32
  store i32 %cv3476, ptr %slot180, align 8
  %v3477 = load i32, ptr %slot180, align 8
  %cv3478 = zext i32 %v3477 to i64
  %cond3479 = icmp ne i64 %cv3478, 0
  br i1 %cond3479, label %bb_rcgnn136, label %bb_rcgdone136
bb_rcgnn136:
  %v3480 = load i64, ptr %slot179, align 8
  %op3481 = sub i64 %v3480, 16
  store i64 %op3481, ptr %slot181, align 8
  %v3482 = load i64, ptr %slot179, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  %rgep3484 = getelementptr i8, ptr %p3483, i64 -16
  %ld3485 = load i64, ptr %rgep3484, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3485, ptr %slot182, align 8
  %v3486 = load i64, ptr %slot182, align 8
  %op3487 = and i64 %v3486, 4611686018427387906
  store i64 %op3487, ptr %slot183, align 8
  %v3488 = load i64, ptr %slot183, align 8
  %cmp3489 = icmp ne i64 %v3488, 0
  %cv3490 = zext i1 %cmp3489 to i32
  store i32 %cv3490, ptr %slot184, align 8
  %v3491 = load i32, ptr %slot184, align 8
  %cv3492 = zext i32 %v3491 to i64
  %cond3493 = icmp ne i64 %cv3492, 0
  br i1 %cond3493, label %bb_rcgclear136, label %bb_rcgcounted136
bb_rcgcounted136:
  %v3494 = load i64, ptr %slot179, align 8
  %op3495 = sub i64 %v3494, 24
  store i64 %op3495, ptr %slot185, align 8
  %v3496 = load i64, ptr %slot179, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  %rgep3498 = getelementptr i8, ptr %p3497, i64 -24
  %ld3499 = load i64, ptr %rgep3498, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3499, ptr %slot186, align 8
  %v3500 = load i64, ptr %slot186, align 8
  %op3501 = sub i64 %v3500, 1
  store i64 %op3501, ptr %slot187, align 8
  %v3502 = load i64, ptr %slot187, align 8
  %cmp3503 = icmp eq i64 %v3502, 0
  %cv3504 = zext i1 %cmp3503 to i32
  store i32 %cv3504, ptr %slot188, align 8
  %v3505 = load i32, ptr %slot188, align 8
  %cv3506 = zext i32 %v3505 to i64
  %cond3507 = icmp ne i64 %cv3506, 0
  br i1 %cond3507, label %bb_rcglast136, label %bb_rcgdec136
bb_rcglast136:
  %v3508 = load i64, ptr %slot179, align 8
  %op3509 = sub i64 %v3508, 32
  store i64 %op3509, ptr %slot189, align 8
  %v3510 = load i64, ptr %slot179, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  %rgep3512 = getelementptr i8, ptr %p3511, i64 -32
  %ld3513 = load i64, ptr %rgep3512, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3513, ptr %slot190, align 8
  %v3514 = load i64, ptr %slot190, align 8
  %cmp3515 = icmp ne i64 %v3514, 0
  %cv3516 = zext i1 %cmp3515 to i32
  store i32 %cv3516, ptr %slot191, align 8
  %v3517 = load i32, ptr %slot191, align 8
  %cv3518 = zext i32 %v3517 to i64
  %cond3519 = icmp ne i64 %cv3518, 0
  br i1 %cond3519, label %bb_rcgdec136, label %bb_rcgslow136
bb_rcgslow136:
  %v3520 = load i64, ptr %slot178, align 8
  %v3521 = load i64, ptr %slot175, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3520, i64 %v3521) nomerge, !dbg !120
  br label %bb_rcgdone136
bb_rcgdec136:
  %v3522 = load i64, ptr %slot187, align 8
  %v3523 = load i64, ptr %slot179, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  %rgep3525 = getelementptr i8, ptr %p3524, i64 -24
  store i64 %v3522, ptr %rgep3525, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear136
bb_rcgclear136:
  %v3526 = load i64, ptr %slot175, align 8
  %p3527 = inttoptr i64 %v3526 to ptr
  store i64 0, ptr %p3527, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone136
bb_rcgdone136:
  br label %bb_rcslotdone120
bb_rcslotowner120:
  %v3528 = load i64, ptr %slot99, align 8
  store i64 %v3528, ptr %slot192, align 8
  %v3529 = load i64, ptr %slot175, align 8
  %p3530 = inttoptr i64 %v3529 to ptr
  %ld3531 = load i64, ptr %p3530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3531, ptr %slot193, align 8
  %v3532 = load i64, ptr %slot193, align 8
  %cmp3533 = icmp ne i64 %v3532, 0
  %cv3534 = zext i1 %cmp3533 to i32
  store i32 %cv3534, ptr %slot194, align 8
  %v3535 = load i32, ptr %slot194, align 8
  %cv3536 = zext i32 %v3535 to i64
  %cond3537 = icmp ne i64 %cv3536, 0
  br i1 %cond3537, label %bb_rcgnn151, label %bb_rcgdone151
bb_rcgnn151:
  %v3538 = load i64, ptr %slot193, align 8
  %op3539 = sub i64 %v3538, 16
  store i64 %op3539, ptr %slot195, align 8
  %v3540 = load i64, ptr %slot193, align 8
  %p3541 = inttoptr i64 %v3540 to ptr
  %rgep3542 = getelementptr i8, ptr %p3541, i64 -16
  %ld3543 = load i64, ptr %rgep3542, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3543, ptr %slot196, align 8
  %v3544 = load i64, ptr %slot196, align 8
  %op3545 = and i64 %v3544, 4611686018427387906
  store i64 %op3545, ptr %slot197, align 8
  %v3546 = load i64, ptr %slot197, align 8
  %cmp3547 = icmp ne i64 %v3546, 0
  %cv3548 = zext i1 %cmp3547 to i32
  store i32 %cv3548, ptr %slot198, align 8
  %v3549 = load i32, ptr %slot198, align 8
  %cv3550 = zext i32 %v3549 to i64
  %cond3551 = icmp ne i64 %cv3550, 0
  br i1 %cond3551, label %bb_rcgclear151, label %bb_rcgcounted151
bb_rcgcounted151:
  %v3552 = load i64, ptr %slot193, align 8
  %op3553 = sub i64 %v3552, 32
  store i64 %op3553, ptr %slot199, align 8
  %v3554 = load i64, ptr %slot193, align 8
  %p3555 = inttoptr i64 %v3554 to ptr
  %rgep3556 = getelementptr i8, ptr %p3555, i64 -32
  %ld3557 = load i64, ptr %rgep3556, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3557, ptr %slot200, align 8
  %v3558 = load i64, ptr %slot200, align 8
  %op3559 = sub i64 %v3558, 1
  store i64 %op3559, ptr %slot201, align 8
  %v3560 = load i64, ptr %slot201, align 8
  %cmp3561 = icmp eq i64 %v3560, 0
  %cv3562 = zext i1 %cmp3561 to i32
  store i32 %cv3562, ptr %slot202, align 8
  %v3563 = load i32, ptr %slot202, align 8
  %cv3564 = zext i32 %v3563 to i64
  %cond3565 = icmp ne i64 %cv3564, 0
  br i1 %cond3565, label %bb_rcglast151, label %bb_rcgdec151
bb_rcglast151:
  %v3566 = load i64, ptr %slot193, align 8
  %op3567 = sub i64 %v3566, 24
  store i64 %op3567, ptr %slot203, align 8
  %v3568 = load i64, ptr %slot193, align 8
  %p3569 = inttoptr i64 %v3568 to ptr
  %rgep3570 = getelementptr i8, ptr %p3569, i64 -24
  %ld3571 = load i64, ptr %rgep3570, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3571, ptr %slot204, align 8
  %v3572 = load i64, ptr %slot204, align 8
  %cmp3573 = icmp ne i64 %v3572, 0
  %cv3574 = zext i1 %cmp3573 to i32
  store i32 %cv3574, ptr %slot205, align 8
  %v3575 = load i32, ptr %slot205, align 8
  %cv3576 = zext i32 %v3575 to i64
  %cond3577 = icmp ne i64 %cv3576, 0
  br i1 %cond3577, label %bb_rcgdec151, label %bb_rcgslow151
bb_rcgslow151:
  %v3578 = load i64, ptr %slot192, align 8
  %v3579 = load i64, ptr %slot175, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3578, i64 %v3579) nomerge, !dbg !120
  br label %bb_rcgdone151
bb_rcgdec151:
  %v3580 = load i64, ptr %slot201, align 8
  %v3581 = load i64, ptr %slot193, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  %rgep3583 = getelementptr i8, ptr %p3582, i64 -32
  store i64 %v3580, ptr %rgep3583, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear151
bb_rcgclear151:
  %v3584 = load i64, ptr %slot175, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  store i64 0, ptr %p3585, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone151
bb_rcgdone151:
  br label %bb_rcslotdone120
bb_rcslotdone120:
  %v3586 = load i64, ptr %slot7, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  %ld3588 = load i32, ptr %p3587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3588, ptr %slot206, align 8
  %v3589 = load i32, ptr %slot206, align 8
  %cv3590 = zext i32 %v3589 to i64
  %cond3591 = icmp ne i64 %cv3590, 0
  br i1 %cond3591, label %bb_rcslotdrop157, label %bb_rcslotdone157
bb_rcslotdrop157:
  %v3592 = load i64, ptr %slot7, align 8
  %p3593 = inttoptr i64 %v3592 to ptr
  store i32 0, ptr %p3593, align 4, !alias.scope !3, !noalias !4
  %v3594 = load i64, ptr %slot34, align 8
  store i64 %v3594, ptr %slot207, align 8
  %v3595 = load i64, ptr %slot8, align 8
  %p3596 = inttoptr i64 %v3595 to ptr
  %ld3597 = load i32, ptr %p3596, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3597, ptr %slot208, align 8
  %v3598 = load i32, ptr %slot208, align 8
  %op3599 = and i32 %v3598, 28
  store i32 %op3599, ptr %slot209, align 8
  %v3600 = load i32, ptr %slot209, align 8
  %cv3601 = zext i32 %v3600 to i64
  %cond3602 = icmp ne i64 %cv3601, 0
  br i1 %cond3602, label %bb_rcslotrole157, label %bb_rcslotowner157
bb_rcslotrole157:
  %v3603 = load i64, ptr %slot99, align 8
  store i64 %v3603, ptr %slot210, align 8
  %v3604 = load i64, ptr %slot207, align 8
  %p3605 = inttoptr i64 %v3604 to ptr
  %ld3606 = load i64, ptr %p3605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3606, ptr %slot211, align 8
  %v3607 = load i64, ptr %slot211, align 8
  %cmp3608 = icmp ne i64 %v3607, 0
  %cv3609 = zext i1 %cmp3608 to i32
  store i32 %cv3609, ptr %slot212, align 8
  %v3610 = load i32, ptr %slot212, align 8
  %cv3611 = zext i32 %v3610 to i64
  %cond3612 = icmp ne i64 %cv3611, 0
  br i1 %cond3612, label %bb_rcgnn173, label %bb_rcgdone173
bb_rcgnn173:
  %v3613 = load i64, ptr %slot211, align 8
  %op3614 = sub i64 %v3613, 16
  store i64 %op3614, ptr %slot213, align 8
  %v3615 = load i64, ptr %slot211, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  %rgep3617 = getelementptr i8, ptr %p3616, i64 -16
  %ld3618 = load i64, ptr %rgep3617, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3618, ptr %slot214, align 8
  %v3619 = load i64, ptr %slot214, align 8
  %op3620 = and i64 %v3619, 4611686018427387906
  store i64 %op3620, ptr %slot215, align 8
  %v3621 = load i64, ptr %slot215, align 8
  %cmp3622 = icmp ne i64 %v3621, 0
  %cv3623 = zext i1 %cmp3622 to i32
  store i32 %cv3623, ptr %slot216, align 8
  %v3624 = load i32, ptr %slot216, align 8
  %cv3625 = zext i32 %v3624 to i64
  %cond3626 = icmp ne i64 %cv3625, 0
  br i1 %cond3626, label %bb_rcgclear173, label %bb_rcgcounted173
bb_rcgcounted173:
  %v3627 = load i64, ptr %slot211, align 8
  %op3628 = sub i64 %v3627, 24
  store i64 %op3628, ptr %slot217, align 8
  %v3629 = load i64, ptr %slot211, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  %rgep3631 = getelementptr i8, ptr %p3630, i64 -24
  %ld3632 = load i64, ptr %rgep3631, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3632, ptr %slot218, align 8
  %v3633 = load i64, ptr %slot218, align 8
  %op3634 = sub i64 %v3633, 1
  store i64 %op3634, ptr %slot219, align 8
  %v3635 = load i64, ptr %slot219, align 8
  %cmp3636 = icmp eq i64 %v3635, 0
  %cv3637 = zext i1 %cmp3636 to i32
  store i32 %cv3637, ptr %slot220, align 8
  %v3638 = load i32, ptr %slot220, align 8
  %cv3639 = zext i32 %v3638 to i64
  %cond3640 = icmp ne i64 %cv3639, 0
  br i1 %cond3640, label %bb_rcglast173, label %bb_rcgdec173
bb_rcglast173:
  %v3641 = load i64, ptr %slot211, align 8
  %op3642 = sub i64 %v3641, 32
  store i64 %op3642, ptr %slot221, align 8
  %v3643 = load i64, ptr %slot211, align 8
  %p3644 = inttoptr i64 %v3643 to ptr
  %rgep3645 = getelementptr i8, ptr %p3644, i64 -32
  %ld3646 = load i64, ptr %rgep3645, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3646, ptr %slot222, align 8
  %v3647 = load i64, ptr %slot222, align 8
  %cmp3648 = icmp ne i64 %v3647, 0
  %cv3649 = zext i1 %cmp3648 to i32
  store i32 %cv3649, ptr %slot223, align 8
  %v3650 = load i32, ptr %slot223, align 8
  %cv3651 = zext i32 %v3650 to i64
  %cond3652 = icmp ne i64 %cv3651, 0
  br i1 %cond3652, label %bb_rcgdec173, label %bb_rcgslow173
bb_rcgslow173:
  %v3653 = load i64, ptr %slot210, align 8
  %v3654 = load i64, ptr %slot207, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v3653, i64 %v3654) nomerge, !dbg !120
  br label %bb_rcgdone173
bb_rcgdec173:
  %v3655 = load i64, ptr %slot219, align 8
  %v3656 = load i64, ptr %slot211, align 8
  %p3657 = inttoptr i64 %v3656 to ptr
  %rgep3658 = getelementptr i8, ptr %p3657, i64 -24
  store i64 %v3655, ptr %rgep3658, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear173
bb_rcgclear173:
  %v3659 = load i64, ptr %slot207, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  store i64 0, ptr %p3660, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone173
bb_rcgdone173:
  br label %bb_rcslotdone157
bb_rcslotowner157:
  %v3661 = load i64, ptr %slot99, align 8
  store i64 %v3661, ptr %slot224, align 8
  %v3662 = load i64, ptr %slot207, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  %ld3664 = load i64, ptr %p3663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3664, ptr %slot225, align 8
  %v3665 = load i64, ptr %slot225, align 8
  %cmp3666 = icmp ne i64 %v3665, 0
  %cv3667 = zext i1 %cmp3666 to i32
  store i32 %cv3667, ptr %slot226, align 8
  %v3668 = load i32, ptr %slot226, align 8
  %cv3669 = zext i32 %v3668 to i64
  %cond3670 = icmp ne i64 %cv3669, 0
  br i1 %cond3670, label %bb_rcgnn188, label %bb_rcgdone188
bb_rcgnn188:
  %v3671 = load i64, ptr %slot225, align 8
  %op3672 = sub i64 %v3671, 16
  store i64 %op3672, ptr %slot227, align 8
  %v3673 = load i64, ptr %slot225, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %rgep3675 = getelementptr i8, ptr %p3674, i64 -16
  %ld3676 = load i64, ptr %rgep3675, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3676, ptr %slot228, align 8
  %v3677 = load i64, ptr %slot228, align 8
  %op3678 = and i64 %v3677, 4611686018427387906
  store i64 %op3678, ptr %slot229, align 8
  %v3679 = load i64, ptr %slot229, align 8
  %cmp3680 = icmp ne i64 %v3679, 0
  %cv3681 = zext i1 %cmp3680 to i32
  store i32 %cv3681, ptr %slot230, align 8
  %v3682 = load i32, ptr %slot230, align 8
  %cv3683 = zext i32 %v3682 to i64
  %cond3684 = icmp ne i64 %cv3683, 0
  br i1 %cond3684, label %bb_rcgclear188, label %bb_rcgcounted188
bb_rcgcounted188:
  %v3685 = load i64, ptr %slot225, align 8
  %op3686 = sub i64 %v3685, 32
  store i64 %op3686, ptr %slot231, align 8
  %v3687 = load i64, ptr %slot225, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %rgep3689 = getelementptr i8, ptr %p3688, i64 -32
  %ld3690 = load i64, ptr %rgep3689, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3690, ptr %slot232, align 8
  %v3691 = load i64, ptr %slot232, align 8
  %op3692 = sub i64 %v3691, 1
  store i64 %op3692, ptr %slot233, align 8
  %v3693 = load i64, ptr %slot233, align 8
  %cmp3694 = icmp eq i64 %v3693, 0
  %cv3695 = zext i1 %cmp3694 to i32
  store i32 %cv3695, ptr %slot234, align 8
  %v3696 = load i32, ptr %slot234, align 8
  %cv3697 = zext i32 %v3696 to i64
  %cond3698 = icmp ne i64 %cv3697, 0
  br i1 %cond3698, label %bb_rcglast188, label %bb_rcgdec188
bb_rcglast188:
  %v3699 = load i64, ptr %slot225, align 8
  %op3700 = sub i64 %v3699, 24
  store i64 %op3700, ptr %slot235, align 8
  %v3701 = load i64, ptr %slot225, align 8
  %p3702 = inttoptr i64 %v3701 to ptr
  %rgep3703 = getelementptr i8, ptr %p3702, i64 -24
  %ld3704 = load i64, ptr %rgep3703, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3704, ptr %slot236, align 8
  %v3705 = load i64, ptr %slot236, align 8
  %cmp3706 = icmp ne i64 %v3705, 0
  %cv3707 = zext i1 %cmp3706 to i32
  store i32 %cv3707, ptr %slot237, align 8
  %v3708 = load i32, ptr %slot237, align 8
  %cv3709 = zext i32 %v3708 to i64
  %cond3710 = icmp ne i64 %cv3709, 0
  br i1 %cond3710, label %bb_rcgdec188, label %bb_rcgslow188
bb_rcgslow188:
  %v3711 = load i64, ptr %slot224, align 8
  %v3712 = load i64, ptr %slot207, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v3711, i64 %v3712) nomerge, !dbg !120
  br label %bb_rcgdone188
bb_rcgdec188:
  %v3713 = load i64, ptr %slot233, align 8
  %v3714 = load i64, ptr %slot225, align 8
  %p3715 = inttoptr i64 %v3714 to ptr
  %rgep3716 = getelementptr i8, ptr %p3715, i64 -32
  store i64 %v3713, ptr %rgep3716, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear188
bb_rcgclear188:
  %v3717 = load i64, ptr %slot207, align 8
  %p3718 = inttoptr i64 %v3717 to ptr
  store i64 0, ptr %p3718, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone188
bb_rcgdone188:
  br label %bb_rcslotdone157
bb_rcslotdone157:
  %v3719 = load i64, ptr %slot5, align 8
  %p3720 = inttoptr i64 %v3719 to ptr
  %ld3721 = load i32, ptr %p3720, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3721, ptr %slot238, align 8
  %v3722 = load i32, ptr %slot238, align 8
  %cv3723 = zext i32 %v3722 to i64
  %cond3724 = icmp ne i64 %cv3723, 0
  br i1 %cond3724, label %bb_rcslotdrop194, label %bb_rcslotdone194
bb_rcslotdrop194:
  %v3725 = load i64, ptr %slot5, align 8
  %p3726 = inttoptr i64 %v3725 to ptr
  store i32 0, ptr %p3726, align 4, !alias.scope !3, !noalias !4
  %v3727 = load i64, ptr %slot33, align 8
  store i64 %v3727, ptr %slot239, align 8
  %v3728 = load i64, ptr %slot6, align 8
  %p3729 = inttoptr i64 %v3728 to ptr
  %ld3730 = load i32, ptr %p3729, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3730, ptr %slot240, align 8
  %v3731 = load i32, ptr %slot240, align 8
  %op3732 = and i32 %v3731, 28
  store i32 %op3732, ptr %slot241, align 8
  %v3733 = load i32, ptr %slot241, align 8
  %cv3734 = zext i32 %v3733 to i64
  %cond3735 = icmp ne i64 %cv3734, 0
  br i1 %cond3735, label %bb_rcslotrole194, label %bb_rcslotowner194
bb_rcslotrole194:
  %v3736 = load i64, ptr %slot99, align 8
  store i64 %v3736, ptr %slot242, align 8
  %v3737 = load i64, ptr %slot242, align 8
  %v3738 = load i64, ptr %slot239, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3737, i64 %v3738) nomerge, !dbg !120
  br label %bb_rcslotdone194
bb_rcslotowner194:
  %v3739 = load i64, ptr %slot99, align 8
  store i64 %v3739, ptr %slot243, align 8
  %v3740 = load i64, ptr %slot243, align 8
  %v3741 = load i64, ptr %slot239, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3740, i64 %v3741) nomerge, !dbg !120
  br label %bb_rcslotdone194
bb_rcslotdone194:
  %v3742 = load i64, ptr %slot160, align 8
  %p3743 = inttoptr i64 %v3742 to ptr
  %ret3744 = load { i64, i64 }, ptr %p3743, align 8
  ret { i64, i64 } %ret3744
bb_i12:
  %v3745 = load i64, ptr %slot32, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  %ld3747 = load i64, ptr %p3746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3747, ptr %slot244, align 8
  %v3748 = load i64, ptr %slot244, align 8
  %v3749 = load i64, ptr %slot44, align 8
  %p3750 = inttoptr i64 %v3749 to ptr
  store i64 %v3748, ptr %p3750, align 8, !alias.scope !3, !noalias !4
  %v3751 = load i64, ptr %slot54, align 8
  store i64 %v3751, ptr %slot245, align 8
  %v3752 = load i64, ptr %slot245, align 8
  %p3753 = inttoptr i64 %v3752 to ptr
  store i32 0, ptr %p3753, align 4, !alias.scope !3, !noalias !4
  %v3754 = load i64, ptr %slot245, align 8
  %p3755 = inttoptr i64 %v3754 to ptr
  store i32 35, ptr %p3755, align 4, !alias.scope !3, !noalias !4
  %v3756 = load i64, ptr %slot245, align 8
  %v3757 = load i64, ptr %slot45, align 8
  %p3758 = inttoptr i64 %v3757 to ptr
  store i64 %v3756, ptr %p3758, align 8, !alias.scope !3, !noalias !4
  %v3759 = load i64, ptr %slot44, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  %ld3761 = load i64, ptr %p3760, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3761, ptr %slot246, align 8
  %v3762 = load i64, ptr %slot45, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %ld3764 = load i64, ptr %p3763, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3764, ptr %slot247, align 8
  %v3765 = load i64, ptr %slot1, align 8
  %v3766 = load i64, ptr %slot246, align 8
  %v3767 = load i64, ptr %slot247, align 8
  %call3768 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v3765, i64 %v3766, i64 %v3767) nomerge, !dbg !122
  store i64 %call3768, ptr %slot248, align 8
  %v3769 = load i64, ptr %slot248, align 8
  %v3770 = load i64, ptr %slot44, align 8
  %p3771 = inttoptr i64 %v3770 to ptr
  store i64 %v3769, ptr %p3771, align 8, !alias.scope !3, !noalias !4
  %v3772 = load i64, ptr %slot15, align 8
  %p3773 = inttoptr i64 %v3772 to ptr
  %ld3774 = load i32, ptr %p3773, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3774, ptr %slot249, align 8
  %v3775 = load i32, ptr %slot249, align 8
  %cv3776 = zext i32 %v3775 to i64
  %cond3777 = icmp ne i64 %cv3776, 0
  br i1 %cond3777, label %bb_rcslotdrop217, label %bb_rcslotdone217
bb_rcslotdrop217:
  %v3778 = load i64, ptr %slot15, align 8
  %p3779 = inttoptr i64 %v3778 to ptr
  store i32 0, ptr %p3779, align 4, !alias.scope !3, !noalias !4
  %v3780 = load i64, ptr %slot24, align 8
  store i64 %v3780, ptr %slot250, align 8
  %v3781 = load i64, ptr %slot16, align 8
  %p3782 = inttoptr i64 %v3781 to ptr
  %ld3783 = load i32, ptr %p3782, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3783, ptr %slot251, align 8
  %v3784 = load i32, ptr %slot251, align 8
  %op3785 = and i32 %v3784, 28
  store i32 %op3785, ptr %slot252, align 8
  %v3786 = load i32, ptr %slot252, align 8
  %cv3787 = zext i32 %v3786 to i64
  %cond3788 = icmp ne i64 %cv3787, 0
  br i1 %cond3788, label %bb_rcslotrole217, label %bb_rcslotowner217
bb_rcslotrole217:
  %v3789 = load i64, ptr %slot99, align 8
  store i64 %v3789, ptr %slot253, align 8
  %v3790 = load i64, ptr %slot253, align 8
  %v3791 = load i64, ptr %slot250, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3790, i64 %v3791) nomerge, !dbg !122
  br label %bb_rcslotdone217
bb_rcslotowner217:
  %v3792 = load i64, ptr %slot99, align 8
  store i64 %v3792, ptr %slot254, align 8
  %v3793 = load i64, ptr %slot254, align 8
  %v3794 = load i64, ptr %slot250, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3793, i64 %v3794) nomerge, !dbg !122
  br label %bb_rcslotdone217
bb_rcslotdone217:
  %v3795 = load i64, ptr %slot44, align 8
  %p3796 = inttoptr i64 %v3795 to ptr
  %ld3797 = load i64, ptr %p3796, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3797, ptr %slot255, align 8
  %v3798 = load i64, ptr %slot255, align 8
  %cond3799 = icmp ne i64 %v3798, 0
  br i1 %cond3799, label %bb_next225, label %bb_i24
bb_next225:
  %v3800 = load i64, ptr %slot32, align 8
  %p3801 = inttoptr i64 %v3800 to ptr
  %ld3802 = load i64, ptr %p3801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3802, ptr %slot256, align 8
  %v3803 = load i64, ptr %slot256, align 8
  %v3804 = load i64, ptr %slot44, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  store i64 %v3803, ptr %p3805, align 8, !alias.scope !3, !noalias !4
  %v3806 = load i64, ptr %slot45, align 8
  %p3807 = inttoptr i64 %v3806 to ptr
  store i64 1, ptr %p3807, align 8, !alias.scope !3, !noalias !4
  %v3808 = load i64, ptr %slot55, align 8
  store i64 %v3808, ptr %slot257, align 8
  %v3809 = load i64, ptr %slot257, align 8
  %p3810 = inttoptr i64 %v3809 to ptr
  store i64 0, ptr %p3810, align 8, !alias.scope !3, !noalias !4
  %v3811 = load i64, ptr %slot257, align 8
  %p3813 = inttoptr i64 %v3811 to ptr
  %gep3814 = getelementptr i8, ptr %p3813, i64 8
  %op3812 = ptrtoint ptr %gep3814 to i64
  store i64 %op3812, ptr %slot258, align 8
  %v3815 = load i64, ptr %slot258, align 8
  %p3816 = inttoptr i64 %v3815 to ptr
  store i64 0, ptr %p3816, align 8, !alias.scope !3, !noalias !4
  %v3817 = load i64, ptr %slot257, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  store i32 1, ptr %p3818, align 4, !alias.scope !3, !noalias !4
  %v3819 = load i64, ptr %slot23, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  store i32 1, ptr %p3820, align 4, !alias.scope !3, !noalias !4
  %v3821 = load i64, ptr %slot45, align 8
  store i64 %v3821, ptr %slot259, align 8
  %v3822 = load i64, ptr %slot257, align 8
  %p3824 = inttoptr i64 %v3822 to ptr
  %gep3825 = getelementptr i8, ptr %p3824, i64 8
  %op3823 = ptrtoint ptr %gep3825 to i64
  store i64 %op3823, ptr %slot260, align 8
  %v3826 = load i64, ptr %slot100, align 8
  store i64 %v3826, ptr %slot261, align 8
  %v3827 = load i64, ptr %slot259, align 8
  %p3828 = inttoptr i64 %v3827 to ptr
  %ld3829 = load i8, ptr %p3828, align 1, !alias.scope !3, !noalias !4
  %ext3830 = zext i8 %ld3829 to i64
  store i64 %ext3830, ptr %slot262, align 8
  %v3831 = load i64, ptr %slot262, align 8
  %cv3832 = trunc i64 %v3831 to i8
  %v3833 = load i64, ptr %slot260, align 8
  %p3834 = inttoptr i64 %v3833 to ptr
  store i8 %cv3832, ptr %p3834, align 1, !alias.scope !3, !noalias !4
  %v3835 = load i64, ptr %slot257, align 8
  %v3836 = load i64, ptr %slot45, align 8
  %p3837 = inttoptr i64 %v3836 to ptr
  store i64 %v3835, ptr %p3837, align 8, !alias.scope !3, !noalias !4
  %v3838 = load i64, ptr %slot32, align 8
  %p3839 = inttoptr i64 %v3838 to ptr
  %ld3840 = load i64, ptr %p3839, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3840, ptr %slot263, align 8
  %v3841 = load i64, ptr %slot263, align 8
  %v3842 = load i64, ptr %slot56, align 8
  %p3843 = inttoptr i64 %v3841 to ptr
  %p3844 = inttoptr i64 %v3842 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3844, ptr %p3843, i64 312, i1 false), !alias.scope !10000000
  %v3845 = load i64, ptr %slot56, align 8
  %v3846 = load i64, ptr %slot46, align 8
  %p3847 = inttoptr i64 %v3846 to ptr
  store i64 %v3845, ptr %p3847, align 8, !alias.scope !3, !noalias !4
  %v3848 = load i64, ptr %slot46, align 8
  %p3849 = inttoptr i64 %v3848 to ptr
  %ld3850 = load i64, ptr %p3849, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3850, ptr %slot264, align 8
  %v3851 = load i64, ptr %slot1, align 8
  %v3852 = load i64, ptr %slot264, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult266, i64 %v3851, i64 %v3852) nomerge, !dbg !124
  %addr3853 = ptrtoint ptr %callresult266 to i64
  store i64 %addr3853, ptr %slot265, align 8
  %v3854 = load i64, ptr %slot265, align 8
  %v3855 = load i64, ptr %slot46, align 8
  %p3856 = inttoptr i64 %v3855 to ptr
  store i64 %v3854, ptr %p3856, align 8, !alias.scope !3, !noalias !4
  %v3857 = load i64, ptr %slot46, align 8
  %p3858 = inttoptr i64 %v3857 to ptr
  %ld3859 = load i64, ptr %p3858, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3859, ptr %slot267, align 8
  %v3860 = load i64, ptr %slot30, align 8
  store i64 %v3860, ptr %slot268, align 8
  %v3861 = load i64, ptr %slot99, align 8
  %v3862 = load i64, ptr %slot268, align 8
  %v3863 = load i64, ptr %slot267, align 8
  %call3864 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v3861, i64 %v3862, i64 %v3863) nomerge, !dbg !124
  store i32 %call3864, ptr %slot269, align 8
  %v3865 = load i32, ptr %slot269, align 8
  %cv3866 = zext i32 %v3865 to i64
  %cond3867 = icmp ne i64 %cv3866, 0
  br i1 %cond3867, label %bb_rcsuccess240, label %bb_rcfailure240
bb_rcfailure240:
  %v3868 = load i64, ptr %slot99, align 8
  %p3869 = inttoptr i64 %v3868 to ptr
  %call3870 = call i32 @myl_rc_take_failure(ptr %p3869) nomerge, !dbg !124
  store i32 %call3870, ptr %slot270, align 8
  %v3871 = load i64, ptr %slot1, align 8
  %p3872 = inttoptr i64 %v3871 to ptr
  %v3873 = load i32, ptr %slot270, align 8
  %call3874 = call i32 @myl_qbe_rc_status(ptr %p3872, i32 %v3873) nomerge, !dbg !124
  store i32 %call3874, ptr %slot271, align 8
  br label %bb_failure
bb_rcsuccess240:
  %v3875 = load i64, ptr %slot22, align 8
  %p3876 = inttoptr i64 %v3875 to ptr
  store i32 2, ptr %p3876, align 4, !alias.scope !3, !noalias !4
  %v3877 = load i64, ptr %slot22, align 8
  %p3878 = inttoptr i64 %v3877 to ptr
  store i32 16, ptr %p3878, align 4, !alias.scope !3, !noalias !4
  %v3879 = load i64, ptr %slot21, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  store i32 1, ptr %p3880, align 4, !alias.scope !3, !noalias !4
  %v3881 = load i64, ptr %slot19, align 8
  %p3882 = inttoptr i64 %v3881 to ptr
  %ld3883 = load i32, ptr %p3882, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3883, ptr %slot272, align 8
  %v3884 = load i32, ptr %slot272, align 8
  %cv3885 = zext i32 %v3884 to i64
  %cond3886 = icmp ne i64 %cv3885, 0
  br i1 %cond3886, label %bb_rcslotdrop248, label %bb_rcslotdone248
bb_rcslotdrop248:
  %v3887 = load i64, ptr %slot19, align 8
  %p3888 = inttoptr i64 %v3887 to ptr
  store i32 0, ptr %p3888, align 4, !alias.scope !3, !noalias !4
  %v3889 = load i64, ptr %slot26, align 8
  store i64 %v3889, ptr %slot273, align 8
  %v3890 = load i64, ptr %slot20, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  %ld3892 = load i32, ptr %p3891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3892, ptr %slot274, align 8
  %v3893 = load i32, ptr %slot274, align 8
  %op3894 = and i32 %v3893, 28
  store i32 %op3894, ptr %slot275, align 8
  %v3895 = load i32, ptr %slot275, align 8
  %cv3896 = zext i32 %v3895 to i64
  %cond3897 = icmp ne i64 %cv3896, 0
  br i1 %cond3897, label %bb_rcslotrole248, label %bb_rcslotowner248
bb_rcslotrole248:
  %v3898 = load i64, ptr %slot99, align 8
  store i64 %v3898, ptr %slot276, align 8
  %v3899 = load i64, ptr %slot276, align 8
  %v3900 = load i64, ptr %slot273, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3899, i64 %v3900) nomerge, !dbg !124
  br label %bb_rcslotdone248
bb_rcslotowner248:
  %v3901 = load i64, ptr %slot99, align 8
  store i64 %v3901, ptr %slot277, align 8
  %v3902 = load i64, ptr %slot277, align 8
  %v3903 = load i64, ptr %slot273, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3902, i64 %v3903) nomerge, !dbg !124
  br label %bb_rcslotdone248
bb_rcslotdone248:
  %v3904 = load i64, ptr %slot26, align 8
  store i64 %v3904, ptr %slot278, align 8
  %v3905 = load i64, ptr %slot30, align 8
  store i64 %v3905, ptr %slot279, align 8
  %v3906 = load i64, ptr %slot279, align 8
  %v3907 = load i64, ptr %slot278, align 8
  %p3908 = inttoptr i64 %v3906 to ptr
  %p3909 = inttoptr i64 %v3907 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3909, ptr %p3908, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v3910 = load i64, ptr %slot20, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  store i32 2, ptr %p3911, align 4, !alias.scope !3, !noalias !4
  %v3912 = load i64, ptr %slot22, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  %ld3914 = load i32, ptr %p3913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3914, ptr %slot280, align 8
  %v3915 = load i32, ptr %slot280, align 8
  %v3916 = load i64, ptr %slot20, align 8
  %p3917 = inttoptr i64 %v3916 to ptr
  store i32 %v3915, ptr %p3917, align 4, !alias.scope !3, !noalias !4
  %v3918 = load i64, ptr %slot21, align 8
  %p3919 = inttoptr i64 %v3918 to ptr
  store i32 0, ptr %p3919, align 4, !alias.scope !3, !noalias !4
  %v3920 = load i64, ptr %slot19, align 8
  %p3921 = inttoptr i64 %v3920 to ptr
  store i32 1, ptr %p3921, align 4, !alias.scope !3, !noalias !4
  %v3922 = load i64, ptr %slot278, align 8
  %v3923 = load i64, ptr %slot46, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  store i64 %v3922, ptr %p3924, align 8, !alias.scope !3, !noalias !4
  %v3925 = load i64, ptr %slot44, align 8
  %p3926 = inttoptr i64 %v3925 to ptr
  %ld3927 = load i64, ptr %p3926, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3927, ptr %slot281, align 8
  %v3928 = load i64, ptr %slot45, align 8
  %p3929 = inttoptr i64 %v3928 to ptr
  %ld3930 = load i64, ptr %p3929, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3930, ptr %slot282, align 8
  %v3931 = load i64, ptr %slot46, align 8
  %p3932 = inttoptr i64 %v3931 to ptr
  %ld3933 = load i64, ptr %p3932, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3933, ptr %slot283, align 8
  %v3934 = load i64, ptr %slot1, align 8
  %v3935 = load i64, ptr %slot281, align 8
  %v3936 = load i64, ptr %slot282, align 8
  %v3937 = load i64, ptr %slot283, align 8
  %call3938 = call i64 @myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623(i64 %v3934, i64 %v3935, i64 %v3936, i64 %v3937) nomerge, !dbg !126
  store i64 %call3938, ptr %slot284, align 8
  %v3939 = load i64, ptr %slot284, align 8
  %v3940 = load i64, ptr %slot44, align 8
  %p3941 = inttoptr i64 %v3940 to ptr
  store i64 %v3939, ptr %p3941, align 8, !alias.scope !3, !noalias !4
  %v3942 = load i64, ptr %slot15, align 8
  %p3943 = inttoptr i64 %v3942 to ptr
  %ld3944 = load i32, ptr %p3943, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3944, ptr %slot285, align 8
  %v3945 = load i32, ptr %slot285, align 8
  %cv3946 = zext i32 %v3945 to i64
  %cond3947 = icmp ne i64 %cv3946, 0
  br i1 %cond3947, label %bb_rcslotdrop269, label %bb_rcslotdone269
bb_rcslotdrop269:
  %v3948 = load i64, ptr %slot15, align 8
  %p3949 = inttoptr i64 %v3948 to ptr
  store i32 0, ptr %p3949, align 4, !alias.scope !3, !noalias !4
  %v3950 = load i64, ptr %slot24, align 8
  store i64 %v3950, ptr %slot286, align 8
  %v3951 = load i64, ptr %slot16, align 8
  %p3952 = inttoptr i64 %v3951 to ptr
  %ld3953 = load i32, ptr %p3952, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3953, ptr %slot287, align 8
  %v3954 = load i32, ptr %slot287, align 8
  %op3955 = and i32 %v3954, 28
  store i32 %op3955, ptr %slot288, align 8
  %v3956 = load i32, ptr %slot288, align 8
  %cv3957 = zext i32 %v3956 to i64
  %cond3958 = icmp ne i64 %cv3957, 0
  br i1 %cond3958, label %bb_rcslotrole269, label %bb_rcslotowner269
bb_rcslotrole269:
  %v3959 = load i64, ptr %slot99, align 8
  store i64 %v3959, ptr %slot289, align 8
  %v3960 = load i64, ptr %slot289, align 8
  %v3961 = load i64, ptr %slot286, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3960, i64 %v3961) nomerge, !dbg !126
  br label %bb_rcslotdone269
bb_rcslotowner269:
  %v3962 = load i64, ptr %slot99, align 8
  store i64 %v3962, ptr %slot290, align 8
  %v3963 = load i64, ptr %slot290, align 8
  %v3964 = load i64, ptr %slot286, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3963, i64 %v3964) nomerge, !dbg !126
  br label %bb_rcslotdone269
bb_rcslotdone269:
  %v3965 = load i64, ptr %slot19, align 8
  %p3966 = inttoptr i64 %v3965 to ptr
  %ld3967 = load i32, ptr %p3966, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3967, ptr %slot291, align 8
  %v3968 = load i32, ptr %slot291, align 8
  %cv3969 = zext i32 %v3968 to i64
  %cond3970 = icmp ne i64 %cv3969, 0
  br i1 %cond3970, label %bb_rcslotdrop278, label %bb_rcslotdone278
bb_rcslotdrop278:
  %v3971 = load i64, ptr %slot19, align 8
  %p3972 = inttoptr i64 %v3971 to ptr
  store i32 0, ptr %p3972, align 4, !alias.scope !3, !noalias !4
  %v3973 = load i64, ptr %slot26, align 8
  store i64 %v3973, ptr %slot292, align 8
  %v3974 = load i64, ptr %slot20, align 8
  %p3975 = inttoptr i64 %v3974 to ptr
  %ld3976 = load i32, ptr %p3975, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3976, ptr %slot293, align 8
  %v3977 = load i32, ptr %slot293, align 8
  %op3978 = and i32 %v3977, 28
  store i32 %op3978, ptr %slot294, align 8
  %v3979 = load i32, ptr %slot294, align 8
  %cv3980 = zext i32 %v3979 to i64
  %cond3981 = icmp ne i64 %cv3980, 0
  br i1 %cond3981, label %bb_rcslotrole278, label %bb_rcslotowner278
bb_rcslotrole278:
  %v3982 = load i64, ptr %slot99, align 8
  store i64 %v3982, ptr %slot295, align 8
  %v3983 = load i64, ptr %slot295, align 8
  %v3984 = load i64, ptr %slot292, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v3983, i64 %v3984) nomerge, !dbg !126
  br label %bb_rcslotdone278
bb_rcslotowner278:
  %v3985 = load i64, ptr %slot99, align 8
  store i64 %v3985, ptr %slot296, align 8
  %v3986 = load i64, ptr %slot296, align 8
  %v3987 = load i64, ptr %slot292, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v3986, i64 %v3987) nomerge, !dbg !126
  br label %bb_rcslotdone278
bb_rcslotdone278:
  %v3988 = load i64, ptr %slot57, align 8
  store i64 %v3988, ptr %slot297, align 8
  %v3989 = load i64, ptr %slot297, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  store i64 0, ptr %p3990, align 8, !alias.scope !3, !noalias !4
  %v3991 = load i64, ptr %slot297, align 8
  %p3993 = inttoptr i64 %v3991 to ptr
  %gep3994 = getelementptr i8, ptr %p3993, i64 8
  %op3992 = ptrtoint ptr %gep3994 to i64
  store i64 %op3992, ptr %slot298, align 8
  %v3995 = load i64, ptr %slot298, align 8
  %p3996 = inttoptr i64 %v3995 to ptr
  store i64 0, ptr %p3996, align 8, !alias.scope !3, !noalias !4
  %v3997 = load i64, ptr %slot297, align 8
  %p3998 = inttoptr i64 %v3997 to ptr
  store i32 0, ptr %p3998, align 4, !alias.scope !3, !noalias !4
  %v3999 = load i64, ptr %slot23, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  store i32 1, ptr %p4000, align 4, !alias.scope !3, !noalias !4
  %v4001 = load i64, ptr %slot44, align 8
  store i64 %v4001, ptr %slot299, align 8
  %v4002 = load i64, ptr %slot297, align 8
  %p4004 = inttoptr i64 %v4002 to ptr
  %gep4005 = getelementptr i8, ptr %p4004, i64 8
  %op4003 = ptrtoint ptr %gep4005 to i64
  store i64 %op4003, ptr %slot300, align 8
  %v4006 = load i64, ptr %slot100, align 8
  store i64 %v4006, ptr %slot301, align 8
  %v4007 = load i64, ptr %slot299, align 8
  %p4008 = inttoptr i64 %v4007 to ptr
  %ld4009 = load i64, ptr %p4008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4009, ptr %slot302, align 8
  %v4010 = load i64, ptr %slot302, align 8
  %v4011 = load i64, ptr %slot300, align 8
  %p4012 = inttoptr i64 %v4011 to ptr
  store i64 %v4010, ptr %p4012, align 8, !alias.scope !3, !noalias !4
  %v4013 = load i64, ptr %slot297, align 8
  %v4014 = load i64, ptr %slot44, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  store i64 %v4013, ptr %p4015, align 8, !alias.scope !3, !noalias !4
  %v4016 = load i64, ptr %slot44, align 8
  %p4017 = inttoptr i64 %v4016 to ptr
  %ld4018 = load i64, ptr %p4017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4018, ptr %slot303, align 8
  %v4019 = load i64, ptr %slot15, align 8
  %p4020 = inttoptr i64 %v4019 to ptr
  %ld4021 = load i32, ptr %p4020, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4021, ptr %slot304, align 8
  %v4022 = load i32, ptr %slot304, align 8
  %cv4023 = zext i32 %v4022 to i64
  %cond4024 = icmp ne i64 %cv4023, 0
  br i1 %cond4024, label %bb_rcslotdrop296, label %bb_rcslotdone296
bb_rcslotdrop296:
  %v4025 = load i64, ptr %slot15, align 8
  %p4026 = inttoptr i64 %v4025 to ptr
  store i32 0, ptr %p4026, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone296
bb_rcslotdone296:
  %v4027 = load i64, ptr %slot13, align 8
  %p4028 = inttoptr i64 %v4027 to ptr
  %ld4029 = load i32, ptr %p4028, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4029, ptr %slot305, align 8
  %v4030 = load i32, ptr %slot305, align 8
  %cv4031 = zext i32 %v4030 to i64
  %cond4032 = icmp ne i64 %cv4031, 0
  br i1 %cond4032, label %bb_rcslotdrop299, label %bb_rcslotdone299
bb_rcslotdrop299:
  %v4033 = load i64, ptr %slot13, align 8
  %p4034 = inttoptr i64 %v4033 to ptr
  store i32 0, ptr %p4034, align 4, !alias.scope !3, !noalias !4
  %v4035 = load i64, ptr %slot42, align 8
  store i64 %v4035, ptr %slot306, align 8
  %v4036 = load i64, ptr %slot14, align 8
  %p4037 = inttoptr i64 %v4036 to ptr
  %ld4038 = load i32, ptr %p4037, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4038, ptr %slot307, align 8
  %v4039 = load i32, ptr %slot307, align 8
  %op4040 = and i32 %v4039, 28
  store i32 %op4040, ptr %slot308, align 8
  %v4041 = load i32, ptr %slot308, align 8
  %cv4042 = zext i32 %v4041 to i64
  %cond4043 = icmp ne i64 %cv4042, 0
  br i1 %cond4043, label %bb_rcslotrole299, label %bb_rcslotowner299
bb_rcslotrole299:
  %v4044 = load i64, ptr %slot99, align 8
  store i64 %v4044, ptr %slot309, align 8
  %v4045 = load i64, ptr %slot309, align 8
  %v4046 = load i64, ptr %slot306, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4045, i64 %v4046) nomerge, !dbg !128
  br label %bb_rcslotdone299
bb_rcslotowner299:
  %v4047 = load i64, ptr %slot99, align 8
  store i64 %v4047, ptr %slot310, align 8
  %v4048 = load i64, ptr %slot310, align 8
  %v4049 = load i64, ptr %slot306, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4048, i64 %v4049) nomerge, !dbg !128
  br label %bb_rcslotdone299
bb_rcslotdone299:
  %v4050 = load i64, ptr %slot11, align 8
  %p4051 = inttoptr i64 %v4050 to ptr
  %ld4052 = load i32, ptr %p4051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4052, ptr %slot311, align 8
  %v4053 = load i32, ptr %slot311, align 8
  %cv4054 = zext i32 %v4053 to i64
  %cond4055 = icmp ne i64 %cv4054, 0
  br i1 %cond4055, label %bb_rcslotdrop308, label %bb_rcslotdone308
bb_rcslotdrop308:
  %v4056 = load i64, ptr %slot11, align 8
  %p4057 = inttoptr i64 %v4056 to ptr
  store i32 0, ptr %p4057, align 4, !alias.scope !3, !noalias !4
  %v4058 = load i64, ptr %slot41, align 8
  store i64 %v4058, ptr %slot312, align 8
  %v4059 = load i64, ptr %slot12, align 8
  %p4060 = inttoptr i64 %v4059 to ptr
  %ld4061 = load i32, ptr %p4060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4061, ptr %slot313, align 8
  %v4062 = load i32, ptr %slot313, align 8
  %op4063 = and i32 %v4062, 28
  store i32 %op4063, ptr %slot314, align 8
  %v4064 = load i32, ptr %slot314, align 8
  %cv4065 = zext i32 %v4064 to i64
  %cond4066 = icmp ne i64 %cv4065, 0
  br i1 %cond4066, label %bb_rcslotrole308, label %bb_rcslotowner308
bb_rcslotrole308:
  %v4067 = load i64, ptr %slot99, align 8
  store i64 %v4067, ptr %slot315, align 8
  %v4068 = load i64, ptr %slot315, align 8
  %v4069 = load i64, ptr %slot312, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4068, i64 %v4069) nomerge, !dbg !128
  br label %bb_rcslotdone308
bb_rcslotowner308:
  %v4070 = load i64, ptr %slot99, align 8
  store i64 %v4070, ptr %slot316, align 8
  %v4071 = load i64, ptr %slot316, align 8
  %v4072 = load i64, ptr %slot312, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4071, i64 %v4072) nomerge, !dbg !128
  br label %bb_rcslotdone308
bb_rcslotdone308:
  %v4073 = load i64, ptr %slot9, align 8
  %p4074 = inttoptr i64 %v4073 to ptr
  %ld4075 = load i32, ptr %p4074, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4075, ptr %slot317, align 8
  %v4076 = load i32, ptr %slot317, align 8
  %cv4077 = zext i32 %v4076 to i64
  %cond4078 = icmp ne i64 %cv4077, 0
  br i1 %cond4078, label %bb_rcslotdrop317, label %bb_rcslotdone317
bb_rcslotdrop317:
  %v4079 = load i64, ptr %slot9, align 8
  %p4080 = inttoptr i64 %v4079 to ptr
  store i32 0, ptr %p4080, align 4, !alias.scope !3, !noalias !4
  %v4081 = load i64, ptr %slot39, align 8
  store i64 %v4081, ptr %slot318, align 8
  %v4082 = load i64, ptr %slot10, align 8
  %p4083 = inttoptr i64 %v4082 to ptr
  %ld4084 = load i32, ptr %p4083, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4084, ptr %slot319, align 8
  %v4085 = load i32, ptr %slot319, align 8
  %op4086 = and i32 %v4085, 28
  store i32 %op4086, ptr %slot320, align 8
  %v4087 = load i32, ptr %slot320, align 8
  %cv4088 = zext i32 %v4087 to i64
  %cond4089 = icmp ne i64 %cv4088, 0
  br i1 %cond4089, label %bb_rcslotrole317, label %bb_rcslotowner317
bb_rcslotrole317:
  %v4090 = load i64, ptr %slot99, align 8
  store i64 %v4090, ptr %slot321, align 8
  %v4091 = load i64, ptr %slot318, align 8
  %p4092 = inttoptr i64 %v4091 to ptr
  %ld4093 = load i64, ptr %p4092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4093, ptr %slot322, align 8
  %v4094 = load i64, ptr %slot322, align 8
  %cmp4095 = icmp ne i64 %v4094, 0
  %cv4096 = zext i1 %cmp4095 to i32
  store i32 %cv4096, ptr %slot323, align 8
  %v4097 = load i32, ptr %slot323, align 8
  %cv4098 = zext i32 %v4097 to i64
  %cond4099 = icmp ne i64 %cv4098, 0
  br i1 %cond4099, label %bb_rcgnn333, label %bb_rcgdone333
bb_rcgnn333:
  %v4100 = load i64, ptr %slot322, align 8
  %op4101 = sub i64 %v4100, 16
  store i64 %op4101, ptr %slot324, align 8
  %v4102 = load i64, ptr %slot322, align 8
  %p4103 = inttoptr i64 %v4102 to ptr
  %rgep4104 = getelementptr i8, ptr %p4103, i64 -16
  %ld4105 = load i64, ptr %rgep4104, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4105, ptr %slot325, align 8
  %v4106 = load i64, ptr %slot325, align 8
  %op4107 = and i64 %v4106, 4611686018427387906
  store i64 %op4107, ptr %slot326, align 8
  %v4108 = load i64, ptr %slot326, align 8
  %cmp4109 = icmp ne i64 %v4108, 0
  %cv4110 = zext i1 %cmp4109 to i32
  store i32 %cv4110, ptr %slot327, align 8
  %v4111 = load i32, ptr %slot327, align 8
  %cv4112 = zext i32 %v4111 to i64
  %cond4113 = icmp ne i64 %cv4112, 0
  br i1 %cond4113, label %bb_rcgclear333, label %bb_rcgcounted333
bb_rcgcounted333:
  %v4114 = load i64, ptr %slot322, align 8
  %op4115 = sub i64 %v4114, 24
  store i64 %op4115, ptr %slot328, align 8
  %v4116 = load i64, ptr %slot322, align 8
  %p4117 = inttoptr i64 %v4116 to ptr
  %rgep4118 = getelementptr i8, ptr %p4117, i64 -24
  %ld4119 = load i64, ptr %rgep4118, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4119, ptr %slot329, align 8
  %v4120 = load i64, ptr %slot329, align 8
  %op4121 = sub i64 %v4120, 1
  store i64 %op4121, ptr %slot330, align 8
  %v4122 = load i64, ptr %slot330, align 8
  %cmp4123 = icmp eq i64 %v4122, 0
  %cv4124 = zext i1 %cmp4123 to i32
  store i32 %cv4124, ptr %slot331, align 8
  %v4125 = load i32, ptr %slot331, align 8
  %cv4126 = zext i32 %v4125 to i64
  %cond4127 = icmp ne i64 %cv4126, 0
  br i1 %cond4127, label %bb_rcglast333, label %bb_rcgdec333
bb_rcglast333:
  %v4128 = load i64, ptr %slot322, align 8
  %op4129 = sub i64 %v4128, 32
  store i64 %op4129, ptr %slot332, align 8
  %v4130 = load i64, ptr %slot322, align 8
  %p4131 = inttoptr i64 %v4130 to ptr
  %rgep4132 = getelementptr i8, ptr %p4131, i64 -32
  %ld4133 = load i64, ptr %rgep4132, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4133, ptr %slot333, align 8
  %v4134 = load i64, ptr %slot333, align 8
  %cmp4135 = icmp ne i64 %v4134, 0
  %cv4136 = zext i1 %cmp4135 to i32
  store i32 %cv4136, ptr %slot334, align 8
  %v4137 = load i32, ptr %slot334, align 8
  %cv4138 = zext i32 %v4137 to i64
  %cond4139 = icmp ne i64 %cv4138, 0
  br i1 %cond4139, label %bb_rcgdec333, label %bb_rcgslow333
bb_rcgslow333:
  %v4140 = load i64, ptr %slot321, align 8
  %v4141 = load i64, ptr %slot318, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4140, i64 %v4141) nomerge, !dbg !128
  br label %bb_rcgdone333
bb_rcgdec333:
  %v4142 = load i64, ptr %slot330, align 8
  %v4143 = load i64, ptr %slot322, align 8
  %p4144 = inttoptr i64 %v4143 to ptr
  %rgep4145 = getelementptr i8, ptr %p4144, i64 -24
  store i64 %v4142, ptr %rgep4145, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear333
bb_rcgclear333:
  %v4146 = load i64, ptr %slot318, align 8
  %p4147 = inttoptr i64 %v4146 to ptr
  store i64 0, ptr %p4147, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone333
bb_rcgdone333:
  br label %bb_rcslotdone317
bb_rcslotowner317:
  %v4148 = load i64, ptr %slot99, align 8
  store i64 %v4148, ptr %slot335, align 8
  %v4149 = load i64, ptr %slot318, align 8
  %p4150 = inttoptr i64 %v4149 to ptr
  %ld4151 = load i64, ptr %p4150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4151, ptr %slot336, align 8
  %v4152 = load i64, ptr %slot336, align 8
  %cmp4153 = icmp ne i64 %v4152, 0
  %cv4154 = zext i1 %cmp4153 to i32
  store i32 %cv4154, ptr %slot337, align 8
  %v4155 = load i32, ptr %slot337, align 8
  %cv4156 = zext i32 %v4155 to i64
  %cond4157 = icmp ne i64 %cv4156, 0
  br i1 %cond4157, label %bb_rcgnn348, label %bb_rcgdone348
bb_rcgnn348:
  %v4158 = load i64, ptr %slot336, align 8
  %op4159 = sub i64 %v4158, 16
  store i64 %op4159, ptr %slot338, align 8
  %v4160 = load i64, ptr %slot336, align 8
  %p4161 = inttoptr i64 %v4160 to ptr
  %rgep4162 = getelementptr i8, ptr %p4161, i64 -16
  %ld4163 = load i64, ptr %rgep4162, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4163, ptr %slot339, align 8
  %v4164 = load i64, ptr %slot339, align 8
  %op4165 = and i64 %v4164, 4611686018427387906
  store i64 %op4165, ptr %slot340, align 8
  %v4166 = load i64, ptr %slot340, align 8
  %cmp4167 = icmp ne i64 %v4166, 0
  %cv4168 = zext i1 %cmp4167 to i32
  store i32 %cv4168, ptr %slot341, align 8
  %v4169 = load i32, ptr %slot341, align 8
  %cv4170 = zext i32 %v4169 to i64
  %cond4171 = icmp ne i64 %cv4170, 0
  br i1 %cond4171, label %bb_rcgclear348, label %bb_rcgcounted348
bb_rcgcounted348:
  %v4172 = load i64, ptr %slot336, align 8
  %op4173 = sub i64 %v4172, 32
  store i64 %op4173, ptr %slot342, align 8
  %v4174 = load i64, ptr %slot336, align 8
  %p4175 = inttoptr i64 %v4174 to ptr
  %rgep4176 = getelementptr i8, ptr %p4175, i64 -32
  %ld4177 = load i64, ptr %rgep4176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4177, ptr %slot343, align 8
  %v4178 = load i64, ptr %slot343, align 8
  %op4179 = sub i64 %v4178, 1
  store i64 %op4179, ptr %slot344, align 8
  %v4180 = load i64, ptr %slot344, align 8
  %cmp4181 = icmp eq i64 %v4180, 0
  %cv4182 = zext i1 %cmp4181 to i32
  store i32 %cv4182, ptr %slot345, align 8
  %v4183 = load i32, ptr %slot345, align 8
  %cv4184 = zext i32 %v4183 to i64
  %cond4185 = icmp ne i64 %cv4184, 0
  br i1 %cond4185, label %bb_rcglast348, label %bb_rcgdec348
bb_rcglast348:
  %v4186 = load i64, ptr %slot336, align 8
  %op4187 = sub i64 %v4186, 24
  store i64 %op4187, ptr %slot346, align 8
  %v4188 = load i64, ptr %slot336, align 8
  %p4189 = inttoptr i64 %v4188 to ptr
  %rgep4190 = getelementptr i8, ptr %p4189, i64 -24
  %ld4191 = load i64, ptr %rgep4190, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4191, ptr %slot347, align 8
  %v4192 = load i64, ptr %slot347, align 8
  %cmp4193 = icmp ne i64 %v4192, 0
  %cv4194 = zext i1 %cmp4193 to i32
  store i32 %cv4194, ptr %slot348, align 8
  %v4195 = load i32, ptr %slot348, align 8
  %cv4196 = zext i32 %v4195 to i64
  %cond4197 = icmp ne i64 %cv4196, 0
  br i1 %cond4197, label %bb_rcgdec348, label %bb_rcgslow348
bb_rcgslow348:
  %v4198 = load i64, ptr %slot335, align 8
  %v4199 = load i64, ptr %slot318, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4198, i64 %v4199) nomerge, !dbg !128
  br label %bb_rcgdone348
bb_rcgdec348:
  %v4200 = load i64, ptr %slot344, align 8
  %v4201 = load i64, ptr %slot336, align 8
  %p4202 = inttoptr i64 %v4201 to ptr
  %rgep4203 = getelementptr i8, ptr %p4202, i64 -32
  store i64 %v4200, ptr %rgep4203, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear348
bb_rcgclear348:
  %v4204 = load i64, ptr %slot318, align 8
  %p4205 = inttoptr i64 %v4204 to ptr
  store i64 0, ptr %p4205, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone348
bb_rcgdone348:
  br label %bb_rcslotdone317
bb_rcslotdone317:
  %v4206 = load i64, ptr %slot7, align 8
  %p4207 = inttoptr i64 %v4206 to ptr
  %ld4208 = load i32, ptr %p4207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4208, ptr %slot349, align 8
  %v4209 = load i32, ptr %slot349, align 8
  %cv4210 = zext i32 %v4209 to i64
  %cond4211 = icmp ne i64 %cv4210, 0
  br i1 %cond4211, label %bb_rcslotdrop354, label %bb_rcslotdone354
bb_rcslotdrop354:
  %v4212 = load i64, ptr %slot7, align 8
  %p4213 = inttoptr i64 %v4212 to ptr
  store i32 0, ptr %p4213, align 4, !alias.scope !3, !noalias !4
  %v4214 = load i64, ptr %slot34, align 8
  store i64 %v4214, ptr %slot350, align 8
  %v4215 = load i64, ptr %slot8, align 8
  %p4216 = inttoptr i64 %v4215 to ptr
  %ld4217 = load i32, ptr %p4216, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4217, ptr %slot351, align 8
  %v4218 = load i32, ptr %slot351, align 8
  %op4219 = and i32 %v4218, 28
  store i32 %op4219, ptr %slot352, align 8
  %v4220 = load i32, ptr %slot352, align 8
  %cv4221 = zext i32 %v4220 to i64
  %cond4222 = icmp ne i64 %cv4221, 0
  br i1 %cond4222, label %bb_rcslotrole354, label %bb_rcslotowner354
bb_rcslotrole354:
  %v4223 = load i64, ptr %slot99, align 8
  store i64 %v4223, ptr %slot353, align 8
  %v4224 = load i64, ptr %slot350, align 8
  %p4225 = inttoptr i64 %v4224 to ptr
  %ld4226 = load i64, ptr %p4225, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4226, ptr %slot354, align 8
  %v4227 = load i64, ptr %slot354, align 8
  %cmp4228 = icmp ne i64 %v4227, 0
  %cv4229 = zext i1 %cmp4228 to i32
  store i32 %cv4229, ptr %slot355, align 8
  %v4230 = load i32, ptr %slot355, align 8
  %cv4231 = zext i32 %v4230 to i64
  %cond4232 = icmp ne i64 %cv4231, 0
  br i1 %cond4232, label %bb_rcgnn370, label %bb_rcgdone370
bb_rcgnn370:
  %v4233 = load i64, ptr %slot354, align 8
  %op4234 = sub i64 %v4233, 16
  store i64 %op4234, ptr %slot356, align 8
  %v4235 = load i64, ptr %slot354, align 8
  %p4236 = inttoptr i64 %v4235 to ptr
  %rgep4237 = getelementptr i8, ptr %p4236, i64 -16
  %ld4238 = load i64, ptr %rgep4237, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4238, ptr %slot357, align 8
  %v4239 = load i64, ptr %slot357, align 8
  %op4240 = and i64 %v4239, 4611686018427387906
  store i64 %op4240, ptr %slot358, align 8
  %v4241 = load i64, ptr %slot358, align 8
  %cmp4242 = icmp ne i64 %v4241, 0
  %cv4243 = zext i1 %cmp4242 to i32
  store i32 %cv4243, ptr %slot359, align 8
  %v4244 = load i32, ptr %slot359, align 8
  %cv4245 = zext i32 %v4244 to i64
  %cond4246 = icmp ne i64 %cv4245, 0
  br i1 %cond4246, label %bb_rcgclear370, label %bb_rcgcounted370
bb_rcgcounted370:
  %v4247 = load i64, ptr %slot354, align 8
  %op4248 = sub i64 %v4247, 24
  store i64 %op4248, ptr %slot360, align 8
  %v4249 = load i64, ptr %slot354, align 8
  %p4250 = inttoptr i64 %v4249 to ptr
  %rgep4251 = getelementptr i8, ptr %p4250, i64 -24
  %ld4252 = load i64, ptr %rgep4251, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4252, ptr %slot361, align 8
  %v4253 = load i64, ptr %slot361, align 8
  %op4254 = sub i64 %v4253, 1
  store i64 %op4254, ptr %slot362, align 8
  %v4255 = load i64, ptr %slot362, align 8
  %cmp4256 = icmp eq i64 %v4255, 0
  %cv4257 = zext i1 %cmp4256 to i32
  store i32 %cv4257, ptr %slot363, align 8
  %v4258 = load i32, ptr %slot363, align 8
  %cv4259 = zext i32 %v4258 to i64
  %cond4260 = icmp ne i64 %cv4259, 0
  br i1 %cond4260, label %bb_rcglast370, label %bb_rcgdec370
bb_rcglast370:
  %v4261 = load i64, ptr %slot354, align 8
  %op4262 = sub i64 %v4261, 32
  store i64 %op4262, ptr %slot364, align 8
  %v4263 = load i64, ptr %slot354, align 8
  %p4264 = inttoptr i64 %v4263 to ptr
  %rgep4265 = getelementptr i8, ptr %p4264, i64 -32
  %ld4266 = load i64, ptr %rgep4265, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4266, ptr %slot365, align 8
  %v4267 = load i64, ptr %slot365, align 8
  %cmp4268 = icmp ne i64 %v4267, 0
  %cv4269 = zext i1 %cmp4268 to i32
  store i32 %cv4269, ptr %slot366, align 8
  %v4270 = load i32, ptr %slot366, align 8
  %cv4271 = zext i32 %v4270 to i64
  %cond4272 = icmp ne i64 %cv4271, 0
  br i1 %cond4272, label %bb_rcgdec370, label %bb_rcgslow370
bb_rcgslow370:
  %v4273 = load i64, ptr %slot353, align 8
  %v4274 = load i64, ptr %slot350, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4273, i64 %v4274) nomerge, !dbg !128
  br label %bb_rcgdone370
bb_rcgdec370:
  %v4275 = load i64, ptr %slot362, align 8
  %v4276 = load i64, ptr %slot354, align 8
  %p4277 = inttoptr i64 %v4276 to ptr
  %rgep4278 = getelementptr i8, ptr %p4277, i64 -24
  store i64 %v4275, ptr %rgep4278, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear370
bb_rcgclear370:
  %v4279 = load i64, ptr %slot350, align 8
  %p4280 = inttoptr i64 %v4279 to ptr
  store i64 0, ptr %p4280, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone370
bb_rcgdone370:
  br label %bb_rcslotdone354
bb_rcslotowner354:
  %v4281 = load i64, ptr %slot99, align 8
  store i64 %v4281, ptr %slot367, align 8
  %v4282 = load i64, ptr %slot350, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  %ld4284 = load i64, ptr %p4283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4284, ptr %slot368, align 8
  %v4285 = load i64, ptr %slot368, align 8
  %cmp4286 = icmp ne i64 %v4285, 0
  %cv4287 = zext i1 %cmp4286 to i32
  store i32 %cv4287, ptr %slot369, align 8
  %v4288 = load i32, ptr %slot369, align 8
  %cv4289 = zext i32 %v4288 to i64
  %cond4290 = icmp ne i64 %cv4289, 0
  br i1 %cond4290, label %bb_rcgnn385, label %bb_rcgdone385
bb_rcgnn385:
  %v4291 = load i64, ptr %slot368, align 8
  %op4292 = sub i64 %v4291, 16
  store i64 %op4292, ptr %slot370, align 8
  %v4293 = load i64, ptr %slot368, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  %rgep4295 = getelementptr i8, ptr %p4294, i64 -16
  %ld4296 = load i64, ptr %rgep4295, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4296, ptr %slot371, align 8
  %v4297 = load i64, ptr %slot371, align 8
  %op4298 = and i64 %v4297, 4611686018427387906
  store i64 %op4298, ptr %slot372, align 8
  %v4299 = load i64, ptr %slot372, align 8
  %cmp4300 = icmp ne i64 %v4299, 0
  %cv4301 = zext i1 %cmp4300 to i32
  store i32 %cv4301, ptr %slot373, align 8
  %v4302 = load i32, ptr %slot373, align 8
  %cv4303 = zext i32 %v4302 to i64
  %cond4304 = icmp ne i64 %cv4303, 0
  br i1 %cond4304, label %bb_rcgclear385, label %bb_rcgcounted385
bb_rcgcounted385:
  %v4305 = load i64, ptr %slot368, align 8
  %op4306 = sub i64 %v4305, 32
  store i64 %op4306, ptr %slot374, align 8
  %v4307 = load i64, ptr %slot368, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  %rgep4309 = getelementptr i8, ptr %p4308, i64 -32
  %ld4310 = load i64, ptr %rgep4309, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4310, ptr %slot375, align 8
  %v4311 = load i64, ptr %slot375, align 8
  %op4312 = sub i64 %v4311, 1
  store i64 %op4312, ptr %slot376, align 8
  %v4313 = load i64, ptr %slot376, align 8
  %cmp4314 = icmp eq i64 %v4313, 0
  %cv4315 = zext i1 %cmp4314 to i32
  store i32 %cv4315, ptr %slot377, align 8
  %v4316 = load i32, ptr %slot377, align 8
  %cv4317 = zext i32 %v4316 to i64
  %cond4318 = icmp ne i64 %cv4317, 0
  br i1 %cond4318, label %bb_rcglast385, label %bb_rcgdec385
bb_rcglast385:
  %v4319 = load i64, ptr %slot368, align 8
  %op4320 = sub i64 %v4319, 24
  store i64 %op4320, ptr %slot378, align 8
  %v4321 = load i64, ptr %slot368, align 8
  %p4322 = inttoptr i64 %v4321 to ptr
  %rgep4323 = getelementptr i8, ptr %p4322, i64 -24
  %ld4324 = load i64, ptr %rgep4323, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4324, ptr %slot379, align 8
  %v4325 = load i64, ptr %slot379, align 8
  %cmp4326 = icmp ne i64 %v4325, 0
  %cv4327 = zext i1 %cmp4326 to i32
  store i32 %cv4327, ptr %slot380, align 8
  %v4328 = load i32, ptr %slot380, align 8
  %cv4329 = zext i32 %v4328 to i64
  %cond4330 = icmp ne i64 %cv4329, 0
  br i1 %cond4330, label %bb_rcgdec385, label %bb_rcgslow385
bb_rcgslow385:
  %v4331 = load i64, ptr %slot367, align 8
  %v4332 = load i64, ptr %slot350, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4331, i64 %v4332) nomerge, !dbg !128
  br label %bb_rcgdone385
bb_rcgdec385:
  %v4333 = load i64, ptr %slot376, align 8
  %v4334 = load i64, ptr %slot368, align 8
  %p4335 = inttoptr i64 %v4334 to ptr
  %rgep4336 = getelementptr i8, ptr %p4335, i64 -32
  store i64 %v4333, ptr %rgep4336, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear385
bb_rcgclear385:
  %v4337 = load i64, ptr %slot350, align 8
  %p4338 = inttoptr i64 %v4337 to ptr
  store i64 0, ptr %p4338, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone385
bb_rcgdone385:
  br label %bb_rcslotdone354
bb_rcslotdone354:
  %v4339 = load i64, ptr %slot5, align 8
  %p4340 = inttoptr i64 %v4339 to ptr
  %ld4341 = load i32, ptr %p4340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4341, ptr %slot381, align 8
  %v4342 = load i32, ptr %slot381, align 8
  %cv4343 = zext i32 %v4342 to i64
  %cond4344 = icmp ne i64 %cv4343, 0
  br i1 %cond4344, label %bb_rcslotdrop391, label %bb_rcslotdone391
bb_rcslotdrop391:
  %v4345 = load i64, ptr %slot5, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  store i32 0, ptr %p4346, align 4, !alias.scope !3, !noalias !4
  %v4347 = load i64, ptr %slot33, align 8
  store i64 %v4347, ptr %slot382, align 8
  %v4348 = load i64, ptr %slot6, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  %ld4350 = load i32, ptr %p4349, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4350, ptr %slot383, align 8
  %v4351 = load i32, ptr %slot383, align 8
  %op4352 = and i32 %v4351, 28
  store i32 %op4352, ptr %slot384, align 8
  %v4353 = load i32, ptr %slot384, align 8
  %cv4354 = zext i32 %v4353 to i64
  %cond4355 = icmp ne i64 %cv4354, 0
  br i1 %cond4355, label %bb_rcslotrole391, label %bb_rcslotowner391
bb_rcslotrole391:
  %v4356 = load i64, ptr %slot99, align 8
  store i64 %v4356, ptr %slot385, align 8
  %v4357 = load i64, ptr %slot385, align 8
  %v4358 = load i64, ptr %slot382, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4357, i64 %v4358) nomerge, !dbg !128
  br label %bb_rcslotdone391
bb_rcslotowner391:
  %v4359 = load i64, ptr %slot99, align 8
  store i64 %v4359, ptr %slot386, align 8
  %v4360 = load i64, ptr %slot386, align 8
  %v4361 = load i64, ptr %slot382, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4360, i64 %v4361) nomerge, !dbg !128
  br label %bb_rcslotdone391
bb_rcslotdone391:
  %v4362 = load i64, ptr %slot303, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  %ret4364 = load { i64, i64 }, ptr %p4363, align 8
  ret { i64, i64 } %ret4364
bb_i24:
  %v4365 = load i64, ptr %slot32, align 8
  %p4366 = inttoptr i64 %v4365 to ptr
  %ld4367 = load i64, ptr %p4366, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4367, ptr %slot387, align 8
  %v4368 = load i64, ptr %slot387, align 8
  %v4369 = load i64, ptr %slot44, align 8
  %p4370 = inttoptr i64 %v4369 to ptr
  store i64 %v4368, ptr %p4370, align 8, !alias.scope !3, !noalias !4
  %v4371 = load i64, ptr %slot58, align 8
  store i64 %v4371, ptr %slot388, align 8
  %v4372 = load i64, ptr %slot388, align 8
  %p4373 = inttoptr i64 %v4372 to ptr
  store i32 0, ptr %p4373, align 4, !alias.scope !3, !noalias !4
  %v4374 = load i64, ptr %slot388, align 8
  %p4375 = inttoptr i64 %v4374 to ptr
  store i32 29, ptr %p4375, align 4, !alias.scope !3, !noalias !4
  %v4376 = load i64, ptr %slot388, align 8
  %v4377 = load i64, ptr %slot45, align 8
  %p4378 = inttoptr i64 %v4377 to ptr
  store i64 %v4376, ptr %p4378, align 8, !alias.scope !3, !noalias !4
  %v4379 = load i64, ptr %slot44, align 8
  %p4380 = inttoptr i64 %v4379 to ptr
  %ld4381 = load i64, ptr %p4380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4381, ptr %slot389, align 8
  %v4382 = load i64, ptr %slot45, align 8
  %p4383 = inttoptr i64 %v4382 to ptr
  %ld4384 = load i64, ptr %p4383, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4384, ptr %slot390, align 8
  %v4385 = load i64, ptr %slot1, align 8
  %v4386 = load i64, ptr %slot389, align 8
  %v4387 = load i64, ptr %slot390, align 8
  %call4388 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v4385, i64 %v4386, i64 %v4387) nomerge, !dbg !130
  store i64 %call4388, ptr %slot391, align 8
  %v4389 = load i64, ptr %slot391, align 8
  %v4390 = load i64, ptr %slot44, align 8
  %p4391 = inttoptr i64 %v4390 to ptr
  store i64 %v4389, ptr %p4391, align 8, !alias.scope !3, !noalias !4
  %v4392 = load i64, ptr %slot15, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  %ld4394 = load i32, ptr %p4393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4394, ptr %slot392, align 8
  %v4395 = load i32, ptr %slot392, align 8
  %cv4396 = zext i32 %v4395 to i64
  %cond4397 = icmp ne i64 %cv4396, 0
  br i1 %cond4397, label %bb_rcslotdrop414, label %bb_rcslotdone414
bb_rcslotdrop414:
  %v4398 = load i64, ptr %slot15, align 8
  %p4399 = inttoptr i64 %v4398 to ptr
  store i32 0, ptr %p4399, align 4, !alias.scope !3, !noalias !4
  %v4400 = load i64, ptr %slot24, align 8
  store i64 %v4400, ptr %slot393, align 8
  %v4401 = load i64, ptr %slot16, align 8
  %p4402 = inttoptr i64 %v4401 to ptr
  %ld4403 = load i32, ptr %p4402, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4403, ptr %slot394, align 8
  %v4404 = load i32, ptr %slot394, align 8
  %op4405 = and i32 %v4404, 28
  store i32 %op4405, ptr %slot395, align 8
  %v4406 = load i32, ptr %slot395, align 8
  %cv4407 = zext i32 %v4406 to i64
  %cond4408 = icmp ne i64 %cv4407, 0
  br i1 %cond4408, label %bb_rcslotrole414, label %bb_rcslotowner414
bb_rcslotrole414:
  %v4409 = load i64, ptr %slot99, align 8
  store i64 %v4409, ptr %slot396, align 8
  %v4410 = load i64, ptr %slot396, align 8
  %v4411 = load i64, ptr %slot393, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v4410, i64 %v4411) nomerge, !dbg !130
  br label %bb_rcslotdone414
bb_rcslotowner414:
  %v4412 = load i64, ptr %slot99, align 8
  store i64 %v4412, ptr %slot397, align 8
  %v4413 = load i64, ptr %slot397, align 8
  %v4414 = load i64, ptr %slot393, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v4413, i64 %v4414) nomerge, !dbg !130
  br label %bb_rcslotdone414
bb_rcslotdone414:
  %v4415 = load i64, ptr %slot44, align 8
  %p4416 = inttoptr i64 %v4415 to ptr
  %ld4417 = load i64, ptr %p4416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4417, ptr %slot398, align 8
  %v4418 = load i64, ptr %slot398, align 8
  %cond4419 = icmp ne i64 %v4418, 0
  br i1 %cond4419, label %bb_next422, label %bb_i35
bb_next422:
  %v4420 = load i64, ptr %slot32, align 8
  %p4421 = inttoptr i64 %v4420 to ptr
  %ld4422 = load i64, ptr %p4421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4422, ptr %slot399, align 8
  %v4423 = load i64, ptr %slot399, align 8
  %v4424 = load i64, ptr %slot44, align 8
  %p4425 = inttoptr i64 %v4424 to ptr
  store i64 %v4423, ptr %p4425, align 8, !alias.scope !3, !noalias !4
  %v4426 = load i64, ptr %slot59, align 8
  store i64 %v4426, ptr %slot400, align 8
  %v4427 = load i64, ptr %slot400, align 8
  %p4428 = inttoptr i64 %v4427 to ptr
  store i64 0, ptr %p4428, align 8, !alias.scope !3, !noalias !4
  %v4429 = load i64, ptr %slot400, align 8
  %p4431 = inttoptr i64 %v4429 to ptr
  %gep4432 = getelementptr i8, ptr %p4431, i64 8
  %op4430 = ptrtoint ptr %gep4432 to i64
  store i64 %op4430, ptr %slot401, align 8
  %v4433 = load i64, ptr %slot401, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  store i64 0, ptr %p4434, align 8, !alias.scope !3, !noalias !4
  %v4435 = load i64, ptr %slot400, align 8
  %p4436 = inttoptr i64 %v4435 to ptr
  store i32 0, ptr %p4436, align 4, !alias.scope !3, !noalias !4
  %v4437 = load i64, ptr %slot400, align 8
  %v4438 = load i64, ptr %slot45, align 8
  %p4439 = inttoptr i64 %v4438 to ptr
  store i64 %v4437, ptr %p4439, align 8, !alias.scope !3, !noalias !4
  %v4440 = load i64, ptr %slot32, align 8
  %p4441 = inttoptr i64 %v4440 to ptr
  %ld4442 = load i64, ptr %p4441, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4442, ptr %slot402, align 8
  %v4443 = load i64, ptr %slot402, align 8
  %v4444 = load i64, ptr %slot60, align 8
  %p4445 = inttoptr i64 %v4443 to ptr
  %p4446 = inttoptr i64 %v4444 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4446, ptr %p4445, i64 312, i1 false), !alias.scope !10000000
  %v4447 = load i64, ptr %slot60, align 8
  %v4448 = load i64, ptr %slot46, align 8
  %p4449 = inttoptr i64 %v4448 to ptr
  store i64 %v4447, ptr %p4449, align 8, !alias.scope !3, !noalias !4
  %v4450 = load i64, ptr %slot46, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  %ld4452 = load i64, ptr %p4451, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4452, ptr %slot403, align 8
  %v4453 = load i64, ptr %slot1, align 8
  %v4454 = load i64, ptr %slot403, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult405, i64 %v4453, i64 %v4454) nomerge, !dbg !132
  %addr4455 = ptrtoint ptr %callresult405 to i64
  store i64 %addr4455, ptr %slot404, align 8
  %v4456 = load i64, ptr %slot404, align 8
  %v4457 = load i64, ptr %slot46, align 8
  %p4458 = inttoptr i64 %v4457 to ptr
  store i64 %v4456, ptr %p4458, align 8, !alias.scope !3, !noalias !4
  %v4459 = load i64, ptr %slot46, align 8
  %p4460 = inttoptr i64 %v4459 to ptr
  %ld4461 = load i64, ptr %p4460, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4461, ptr %slot406, align 8
  %v4462 = load i64, ptr %slot30, align 8
  store i64 %v4462, ptr %slot407, align 8
  %v4463 = load i64, ptr %slot99, align 8
  %v4464 = load i64, ptr %slot407, align 8
  %v4465 = load i64, ptr %slot406, align 8
  %call4466 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v4463, i64 %v4464, i64 %v4465) nomerge, !dbg !132
  store i32 %call4466, ptr %slot408, align 8
  %v4467 = load i32, ptr %slot408, align 8
  %cv4468 = zext i32 %v4467 to i64
  %cond4469 = icmp ne i64 %cv4468, 0
  br i1 %cond4469, label %bb_rcsuccess431, label %bb_rcfailure431
bb_rcfailure431:
  %v4470 = load i64, ptr %slot99, align 8
  %p4471 = inttoptr i64 %v4470 to ptr
  %call4472 = call i32 @myl_rc_take_failure(ptr %p4471) nomerge, !dbg !132
  store i32 %call4472, ptr %slot409, align 8
  %v4473 = load i64, ptr %slot1, align 8
  %p4474 = inttoptr i64 %v4473 to ptr
  %v4475 = load i32, ptr %slot409, align 8
  %call4476 = call i32 @myl_qbe_rc_status(ptr %p4474, i32 %v4475) nomerge, !dbg !132
  store i32 %call4476, ptr %slot410, align 8
  br label %bb_failure
bb_rcsuccess431:
  %v4477 = load i64, ptr %slot22, align 8
  %p4478 = inttoptr i64 %v4477 to ptr
  store i32 2, ptr %p4478, align 4, !alias.scope !3, !noalias !4
  %v4479 = load i64, ptr %slot22, align 8
  %p4480 = inttoptr i64 %v4479 to ptr
  store i32 16, ptr %p4480, align 4, !alias.scope !3, !noalias !4
  %v4481 = load i64, ptr %slot21, align 8
  %p4482 = inttoptr i64 %v4481 to ptr
  store i32 1, ptr %p4482, align 4, !alias.scope !3, !noalias !4
  %v4483 = load i64, ptr %slot19, align 8
  %p4484 = inttoptr i64 %v4483 to ptr
  %ld4485 = load i32, ptr %p4484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4485, ptr %slot411, align 8
  %v4486 = load i32, ptr %slot411, align 8
  %cv4487 = zext i32 %v4486 to i64
  %cond4488 = icmp ne i64 %cv4487, 0
  br i1 %cond4488, label %bb_rcslotdrop439, label %bb_rcslotdone439
bb_rcslotdrop439:
  %v4489 = load i64, ptr %slot19, align 8
  %p4490 = inttoptr i64 %v4489 to ptr
  store i32 0, ptr %p4490, align 4, !alias.scope !3, !noalias !4
  %v4491 = load i64, ptr %slot26, align 8
  store i64 %v4491, ptr %slot412, align 8
  %v4492 = load i64, ptr %slot20, align 8
  %p4493 = inttoptr i64 %v4492 to ptr
  %ld4494 = load i32, ptr %p4493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4494, ptr %slot413, align 8
  %v4495 = load i32, ptr %slot413, align 8
  %op4496 = and i32 %v4495, 28
  store i32 %op4496, ptr %slot414, align 8
  %v4497 = load i32, ptr %slot414, align 8
  %cv4498 = zext i32 %v4497 to i64
  %cond4499 = icmp ne i64 %cv4498, 0
  br i1 %cond4499, label %bb_rcslotrole439, label %bb_rcslotowner439
bb_rcslotrole439:
  %v4500 = load i64, ptr %slot99, align 8
  store i64 %v4500, ptr %slot415, align 8
  %v4501 = load i64, ptr %slot415, align 8
  %v4502 = load i64, ptr %slot412, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v4501, i64 %v4502) nomerge, !dbg !132
  br label %bb_rcslotdone439
bb_rcslotowner439:
  %v4503 = load i64, ptr %slot99, align 8
  store i64 %v4503, ptr %slot416, align 8
  %v4504 = load i64, ptr %slot416, align 8
  %v4505 = load i64, ptr %slot412, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v4504, i64 %v4505) nomerge, !dbg !132
  br label %bb_rcslotdone439
bb_rcslotdone439:
  %v4506 = load i64, ptr %slot26, align 8
  store i64 %v4506, ptr %slot417, align 8
  %v4507 = load i64, ptr %slot30, align 8
  store i64 %v4507, ptr %slot418, align 8
  %v4508 = load i64, ptr %slot418, align 8
  %v4509 = load i64, ptr %slot417, align 8
  %p4510 = inttoptr i64 %v4508 to ptr
  %p4511 = inttoptr i64 %v4509 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4511, ptr %p4510, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v4512 = load i64, ptr %slot20, align 8
  %p4513 = inttoptr i64 %v4512 to ptr
  store i32 2, ptr %p4513, align 4, !alias.scope !3, !noalias !4
  %v4514 = load i64, ptr %slot22, align 8
  %p4515 = inttoptr i64 %v4514 to ptr
  %ld4516 = load i32, ptr %p4515, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4516, ptr %slot419, align 8
  %v4517 = load i32, ptr %slot419, align 8
  %v4518 = load i64, ptr %slot20, align 8
  %p4519 = inttoptr i64 %v4518 to ptr
  store i32 %v4517, ptr %p4519, align 4, !alias.scope !3, !noalias !4
  %v4520 = load i64, ptr %slot21, align 8
  %p4521 = inttoptr i64 %v4520 to ptr
  store i32 0, ptr %p4521, align 4, !alias.scope !3, !noalias !4
  %v4522 = load i64, ptr %slot19, align 8
  %p4523 = inttoptr i64 %v4522 to ptr
  store i32 1, ptr %p4523, align 4, !alias.scope !3, !noalias !4
  %v4524 = load i64, ptr %slot417, align 8
  %v4525 = load i64, ptr %slot46, align 8
  %p4526 = inttoptr i64 %v4525 to ptr
  store i64 %v4524, ptr %p4526, align 8, !alias.scope !3, !noalias !4
  %v4527 = load i64, ptr %slot44, align 8
  %p4528 = inttoptr i64 %v4527 to ptr
  %ld4529 = load i64, ptr %p4528, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4529, ptr %slot420, align 8
  %v4530 = load i64, ptr %slot45, align 8
  %p4531 = inttoptr i64 %v4530 to ptr
  %ld4532 = load i64, ptr %p4531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4532, ptr %slot421, align 8
  %v4533 = load i64, ptr %slot46, align 8
  %p4534 = inttoptr i64 %v4533 to ptr
  %ld4535 = load i64, ptr %p4534, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4535, ptr %slot422, align 8
  %v4536 = load i64, ptr %slot1, align 8
  %v4537 = load i64, ptr %slot420, align 8
  %v4538 = load i64, ptr %slot421, align 8
  %v4539 = load i64, ptr %slot422, align 8
  %call4540 = call i64 @myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623(i64 %v4536, i64 %v4537, i64 %v4538, i64 %v4539) nomerge, !dbg !134
  store i64 %call4540, ptr %slot423, align 8
  %v4541 = load i64, ptr %slot423, align 8
  %v4542 = load i64, ptr %slot44, align 8
  %p4543 = inttoptr i64 %v4542 to ptr
  store i64 %v4541, ptr %p4543, align 8, !alias.scope !3, !noalias !4
  %v4544 = load i64, ptr %slot15, align 8
  %p4545 = inttoptr i64 %v4544 to ptr
  %ld4546 = load i32, ptr %p4545, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4546, ptr %slot424, align 8
  %v4547 = load i32, ptr %slot424, align 8
  %cv4548 = zext i32 %v4547 to i64
  %cond4549 = icmp ne i64 %cv4548, 0
  br i1 %cond4549, label %bb_rcslotdrop460, label %bb_rcslotdone460
bb_rcslotdrop460:
  %v4550 = load i64, ptr %slot15, align 8
  %p4551 = inttoptr i64 %v4550 to ptr
  store i32 0, ptr %p4551, align 4, !alias.scope !3, !noalias !4
  %v4552 = load i64, ptr %slot24, align 8
  store i64 %v4552, ptr %slot425, align 8
  %v4553 = load i64, ptr %slot16, align 8
  %p4554 = inttoptr i64 %v4553 to ptr
  %ld4555 = load i32, ptr %p4554, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4555, ptr %slot426, align 8
  %v4556 = load i32, ptr %slot426, align 8
  %op4557 = and i32 %v4556, 28
  store i32 %op4557, ptr %slot427, align 8
  %v4558 = load i32, ptr %slot427, align 8
  %cv4559 = zext i32 %v4558 to i64
  %cond4560 = icmp ne i64 %cv4559, 0
  br i1 %cond4560, label %bb_rcslotrole460, label %bb_rcslotowner460
bb_rcslotrole460:
  %v4561 = load i64, ptr %slot99, align 8
  store i64 %v4561, ptr %slot428, align 8
  %v4562 = load i64, ptr %slot428, align 8
  %v4563 = load i64, ptr %slot425, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v4562, i64 %v4563) nomerge, !dbg !134
  br label %bb_rcslotdone460
bb_rcslotowner460:
  %v4564 = load i64, ptr %slot99, align 8
  store i64 %v4564, ptr %slot429, align 8
  %v4565 = load i64, ptr %slot429, align 8
  %v4566 = load i64, ptr %slot425, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v4565, i64 %v4566) nomerge, !dbg !134
  br label %bb_rcslotdone460
bb_rcslotdone460:
  %v4567 = load i64, ptr %slot19, align 8
  %p4568 = inttoptr i64 %v4567 to ptr
  %ld4569 = load i32, ptr %p4568, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4569, ptr %slot430, align 8
  %v4570 = load i32, ptr %slot430, align 8
  %cv4571 = zext i32 %v4570 to i64
  %cond4572 = icmp ne i64 %cv4571, 0
  br i1 %cond4572, label %bb_rcslotdrop469, label %bb_rcslotdone469
bb_rcslotdrop469:
  %v4573 = load i64, ptr %slot19, align 8
  %p4574 = inttoptr i64 %v4573 to ptr
  store i32 0, ptr %p4574, align 4, !alias.scope !3, !noalias !4
  %v4575 = load i64, ptr %slot26, align 8
  store i64 %v4575, ptr %slot431, align 8
  %v4576 = load i64, ptr %slot20, align 8
  %p4577 = inttoptr i64 %v4576 to ptr
  %ld4578 = load i32, ptr %p4577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4578, ptr %slot432, align 8
  %v4579 = load i32, ptr %slot432, align 8
  %op4580 = and i32 %v4579, 28
  store i32 %op4580, ptr %slot433, align 8
  %v4581 = load i32, ptr %slot433, align 8
  %cv4582 = zext i32 %v4581 to i64
  %cond4583 = icmp ne i64 %cv4582, 0
  br i1 %cond4583, label %bb_rcslotrole469, label %bb_rcslotowner469
bb_rcslotrole469:
  %v4584 = load i64, ptr %slot99, align 8
  store i64 %v4584, ptr %slot434, align 8
  %v4585 = load i64, ptr %slot434, align 8
  %v4586 = load i64, ptr %slot431, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4585, i64 %v4586) nomerge, !dbg !134
  br label %bb_rcslotdone469
bb_rcslotowner469:
  %v4587 = load i64, ptr %slot99, align 8
  store i64 %v4587, ptr %slot435, align 8
  %v4588 = load i64, ptr %slot435, align 8
  %v4589 = load i64, ptr %slot431, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4588, i64 %v4589) nomerge, !dbg !134
  br label %bb_rcslotdone469
bb_rcslotdone469:
  %v4590 = load i64, ptr %slot61, align 8
  store i64 %v4590, ptr %slot436, align 8
  %v4591 = load i64, ptr %slot436, align 8
  %p4592 = inttoptr i64 %v4591 to ptr
  store i64 0, ptr %p4592, align 8, !alias.scope !3, !noalias !4
  %v4593 = load i64, ptr %slot436, align 8
  %p4595 = inttoptr i64 %v4593 to ptr
  %gep4596 = getelementptr i8, ptr %p4595, i64 8
  %op4594 = ptrtoint ptr %gep4596 to i64
  store i64 %op4594, ptr %slot437, align 8
  %v4597 = load i64, ptr %slot437, align 8
  %p4598 = inttoptr i64 %v4597 to ptr
  store i64 0, ptr %p4598, align 8, !alias.scope !3, !noalias !4
  %v4599 = load i64, ptr %slot436, align 8
  %p4600 = inttoptr i64 %v4599 to ptr
  store i32 0, ptr %p4600, align 4, !alias.scope !3, !noalias !4
  %v4601 = load i64, ptr %slot23, align 8
  %p4602 = inttoptr i64 %v4601 to ptr
  store i32 1, ptr %p4602, align 4, !alias.scope !3, !noalias !4
  %v4603 = load i64, ptr %slot44, align 8
  store i64 %v4603, ptr %slot438, align 8
  %v4604 = load i64, ptr %slot436, align 8
  %p4606 = inttoptr i64 %v4604 to ptr
  %gep4607 = getelementptr i8, ptr %p4606, i64 8
  %op4605 = ptrtoint ptr %gep4607 to i64
  store i64 %op4605, ptr %slot439, align 8
  %v4608 = load i64, ptr %slot100, align 8
  store i64 %v4608, ptr %slot440, align 8
  %v4609 = load i64, ptr %slot438, align 8
  %p4610 = inttoptr i64 %v4609 to ptr
  %ld4611 = load i64, ptr %p4610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4611, ptr %slot441, align 8
  %v4612 = load i64, ptr %slot441, align 8
  %v4613 = load i64, ptr %slot439, align 8
  %p4614 = inttoptr i64 %v4613 to ptr
  store i64 %v4612, ptr %p4614, align 8, !alias.scope !3, !noalias !4
  %v4615 = load i64, ptr %slot436, align 8
  %v4616 = load i64, ptr %slot44, align 8
  %p4617 = inttoptr i64 %v4616 to ptr
  store i64 %v4615, ptr %p4617, align 8, !alias.scope !3, !noalias !4
  %v4618 = load i64, ptr %slot44, align 8
  %p4619 = inttoptr i64 %v4618 to ptr
  %ld4620 = load i64, ptr %p4619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4620, ptr %slot442, align 8
  %v4621 = load i64, ptr %slot15, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  %ld4623 = load i32, ptr %p4622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4623, ptr %slot443, align 8
  %v4624 = load i32, ptr %slot443, align 8
  %cv4625 = zext i32 %v4624 to i64
  %cond4626 = icmp ne i64 %cv4625, 0
  br i1 %cond4626, label %bb_rcslotdrop487, label %bb_rcslotdone487
bb_rcslotdrop487:
  %v4627 = load i64, ptr %slot15, align 8
  %p4628 = inttoptr i64 %v4627 to ptr
  store i32 0, ptr %p4628, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone487
bb_rcslotdone487:
  %v4629 = load i64, ptr %slot13, align 8
  %p4630 = inttoptr i64 %v4629 to ptr
  %ld4631 = load i32, ptr %p4630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4631, ptr %slot444, align 8
  %v4632 = load i32, ptr %slot444, align 8
  %cv4633 = zext i32 %v4632 to i64
  %cond4634 = icmp ne i64 %cv4633, 0
  br i1 %cond4634, label %bb_rcslotdrop490, label %bb_rcslotdone490
bb_rcslotdrop490:
  %v4635 = load i64, ptr %slot13, align 8
  %p4636 = inttoptr i64 %v4635 to ptr
  store i32 0, ptr %p4636, align 4, !alias.scope !3, !noalias !4
  %v4637 = load i64, ptr %slot42, align 8
  store i64 %v4637, ptr %slot445, align 8
  %v4638 = load i64, ptr %slot14, align 8
  %p4639 = inttoptr i64 %v4638 to ptr
  %ld4640 = load i32, ptr %p4639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4640, ptr %slot446, align 8
  %v4641 = load i32, ptr %slot446, align 8
  %op4642 = and i32 %v4641, 28
  store i32 %op4642, ptr %slot447, align 8
  %v4643 = load i32, ptr %slot447, align 8
  %cv4644 = zext i32 %v4643 to i64
  %cond4645 = icmp ne i64 %cv4644, 0
  br i1 %cond4645, label %bb_rcslotrole490, label %bb_rcslotowner490
bb_rcslotrole490:
  %v4646 = load i64, ptr %slot99, align 8
  store i64 %v4646, ptr %slot448, align 8
  %v4647 = load i64, ptr %slot448, align 8
  %v4648 = load i64, ptr %slot445, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4647, i64 %v4648) nomerge, !dbg !136
  br label %bb_rcslotdone490
bb_rcslotowner490:
  %v4649 = load i64, ptr %slot99, align 8
  store i64 %v4649, ptr %slot449, align 8
  %v4650 = load i64, ptr %slot449, align 8
  %v4651 = load i64, ptr %slot445, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4650, i64 %v4651) nomerge, !dbg !136
  br label %bb_rcslotdone490
bb_rcslotdone490:
  %v4652 = load i64, ptr %slot11, align 8
  %p4653 = inttoptr i64 %v4652 to ptr
  %ld4654 = load i32, ptr %p4653, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4654, ptr %slot450, align 8
  %v4655 = load i32, ptr %slot450, align 8
  %cv4656 = zext i32 %v4655 to i64
  %cond4657 = icmp ne i64 %cv4656, 0
  br i1 %cond4657, label %bb_rcslotdrop499, label %bb_rcslotdone499
bb_rcslotdrop499:
  %v4658 = load i64, ptr %slot11, align 8
  %p4659 = inttoptr i64 %v4658 to ptr
  store i32 0, ptr %p4659, align 4, !alias.scope !3, !noalias !4
  %v4660 = load i64, ptr %slot41, align 8
  store i64 %v4660, ptr %slot451, align 8
  %v4661 = load i64, ptr %slot12, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %ld4663 = load i32, ptr %p4662, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4663, ptr %slot452, align 8
  %v4664 = load i32, ptr %slot452, align 8
  %op4665 = and i32 %v4664, 28
  store i32 %op4665, ptr %slot453, align 8
  %v4666 = load i32, ptr %slot453, align 8
  %cv4667 = zext i32 %v4666 to i64
  %cond4668 = icmp ne i64 %cv4667, 0
  br i1 %cond4668, label %bb_rcslotrole499, label %bb_rcslotowner499
bb_rcslotrole499:
  %v4669 = load i64, ptr %slot99, align 8
  store i64 %v4669, ptr %slot454, align 8
  %v4670 = load i64, ptr %slot454, align 8
  %v4671 = load i64, ptr %slot451, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4670, i64 %v4671) nomerge, !dbg !136
  br label %bb_rcslotdone499
bb_rcslotowner499:
  %v4672 = load i64, ptr %slot99, align 8
  store i64 %v4672, ptr %slot455, align 8
  %v4673 = load i64, ptr %slot455, align 8
  %v4674 = load i64, ptr %slot451, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4673, i64 %v4674) nomerge, !dbg !136
  br label %bb_rcslotdone499
bb_rcslotdone499:
  %v4675 = load i64, ptr %slot9, align 8
  %p4676 = inttoptr i64 %v4675 to ptr
  %ld4677 = load i32, ptr %p4676, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4677, ptr %slot456, align 8
  %v4678 = load i32, ptr %slot456, align 8
  %cv4679 = zext i32 %v4678 to i64
  %cond4680 = icmp ne i64 %cv4679, 0
  br i1 %cond4680, label %bb_rcslotdrop508, label %bb_rcslotdone508
bb_rcslotdrop508:
  %v4681 = load i64, ptr %slot9, align 8
  %p4682 = inttoptr i64 %v4681 to ptr
  store i32 0, ptr %p4682, align 4, !alias.scope !3, !noalias !4
  %v4683 = load i64, ptr %slot39, align 8
  store i64 %v4683, ptr %slot457, align 8
  %v4684 = load i64, ptr %slot10, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  %ld4686 = load i32, ptr %p4685, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4686, ptr %slot458, align 8
  %v4687 = load i32, ptr %slot458, align 8
  %op4688 = and i32 %v4687, 28
  store i32 %op4688, ptr %slot459, align 8
  %v4689 = load i32, ptr %slot459, align 8
  %cv4690 = zext i32 %v4689 to i64
  %cond4691 = icmp ne i64 %cv4690, 0
  br i1 %cond4691, label %bb_rcslotrole508, label %bb_rcslotowner508
bb_rcslotrole508:
  %v4692 = load i64, ptr %slot99, align 8
  store i64 %v4692, ptr %slot460, align 8
  %v4693 = load i64, ptr %slot457, align 8
  %p4694 = inttoptr i64 %v4693 to ptr
  %ld4695 = load i64, ptr %p4694, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4695, ptr %slot461, align 8
  %v4696 = load i64, ptr %slot461, align 8
  %cmp4697 = icmp ne i64 %v4696, 0
  %cv4698 = zext i1 %cmp4697 to i32
  store i32 %cv4698, ptr %slot462, align 8
  %v4699 = load i32, ptr %slot462, align 8
  %cv4700 = zext i32 %v4699 to i64
  %cond4701 = icmp ne i64 %cv4700, 0
  br i1 %cond4701, label %bb_rcgnn524, label %bb_rcgdone524
bb_rcgnn524:
  %v4702 = load i64, ptr %slot461, align 8
  %op4703 = sub i64 %v4702, 16
  store i64 %op4703, ptr %slot463, align 8
  %v4704 = load i64, ptr %slot461, align 8
  %p4705 = inttoptr i64 %v4704 to ptr
  %rgep4706 = getelementptr i8, ptr %p4705, i64 -16
  %ld4707 = load i64, ptr %rgep4706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4707, ptr %slot464, align 8
  %v4708 = load i64, ptr %slot464, align 8
  %op4709 = and i64 %v4708, 4611686018427387906
  store i64 %op4709, ptr %slot465, align 8
  %v4710 = load i64, ptr %slot465, align 8
  %cmp4711 = icmp ne i64 %v4710, 0
  %cv4712 = zext i1 %cmp4711 to i32
  store i32 %cv4712, ptr %slot466, align 8
  %v4713 = load i32, ptr %slot466, align 8
  %cv4714 = zext i32 %v4713 to i64
  %cond4715 = icmp ne i64 %cv4714, 0
  br i1 %cond4715, label %bb_rcgclear524, label %bb_rcgcounted524
bb_rcgcounted524:
  %v4716 = load i64, ptr %slot461, align 8
  %op4717 = sub i64 %v4716, 24
  store i64 %op4717, ptr %slot467, align 8
  %v4718 = load i64, ptr %slot461, align 8
  %p4719 = inttoptr i64 %v4718 to ptr
  %rgep4720 = getelementptr i8, ptr %p4719, i64 -24
  %ld4721 = load i64, ptr %rgep4720, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4721, ptr %slot468, align 8
  %v4722 = load i64, ptr %slot468, align 8
  %op4723 = sub i64 %v4722, 1
  store i64 %op4723, ptr %slot469, align 8
  %v4724 = load i64, ptr %slot469, align 8
  %cmp4725 = icmp eq i64 %v4724, 0
  %cv4726 = zext i1 %cmp4725 to i32
  store i32 %cv4726, ptr %slot470, align 8
  %v4727 = load i32, ptr %slot470, align 8
  %cv4728 = zext i32 %v4727 to i64
  %cond4729 = icmp ne i64 %cv4728, 0
  br i1 %cond4729, label %bb_rcglast524, label %bb_rcgdec524
bb_rcglast524:
  %v4730 = load i64, ptr %slot461, align 8
  %op4731 = sub i64 %v4730, 32
  store i64 %op4731, ptr %slot471, align 8
  %v4732 = load i64, ptr %slot461, align 8
  %p4733 = inttoptr i64 %v4732 to ptr
  %rgep4734 = getelementptr i8, ptr %p4733, i64 -32
  %ld4735 = load i64, ptr %rgep4734, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4735, ptr %slot472, align 8
  %v4736 = load i64, ptr %slot472, align 8
  %cmp4737 = icmp ne i64 %v4736, 0
  %cv4738 = zext i1 %cmp4737 to i32
  store i32 %cv4738, ptr %slot473, align 8
  %v4739 = load i32, ptr %slot473, align 8
  %cv4740 = zext i32 %v4739 to i64
  %cond4741 = icmp ne i64 %cv4740, 0
  br i1 %cond4741, label %bb_rcgdec524, label %bb_rcgslow524
bb_rcgslow524:
  %v4742 = load i64, ptr %slot460, align 8
  %v4743 = load i64, ptr %slot457, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4742, i64 %v4743) nomerge, !dbg !136
  br label %bb_rcgdone524
bb_rcgdec524:
  %v4744 = load i64, ptr %slot469, align 8
  %v4745 = load i64, ptr %slot461, align 8
  %p4746 = inttoptr i64 %v4745 to ptr
  %rgep4747 = getelementptr i8, ptr %p4746, i64 -24
  store i64 %v4744, ptr %rgep4747, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear524
bb_rcgclear524:
  %v4748 = load i64, ptr %slot457, align 8
  %p4749 = inttoptr i64 %v4748 to ptr
  store i64 0, ptr %p4749, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone524
bb_rcgdone524:
  br label %bb_rcslotdone508
bb_rcslotowner508:
  %v4750 = load i64, ptr %slot99, align 8
  store i64 %v4750, ptr %slot474, align 8
  %v4751 = load i64, ptr %slot457, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  %ld4753 = load i64, ptr %p4752, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4753, ptr %slot475, align 8
  %v4754 = load i64, ptr %slot475, align 8
  %cmp4755 = icmp ne i64 %v4754, 0
  %cv4756 = zext i1 %cmp4755 to i32
  store i32 %cv4756, ptr %slot476, align 8
  %v4757 = load i32, ptr %slot476, align 8
  %cv4758 = zext i32 %v4757 to i64
  %cond4759 = icmp ne i64 %cv4758, 0
  br i1 %cond4759, label %bb_rcgnn539, label %bb_rcgdone539
bb_rcgnn539:
  %v4760 = load i64, ptr %slot475, align 8
  %op4761 = sub i64 %v4760, 16
  store i64 %op4761, ptr %slot477, align 8
  %v4762 = load i64, ptr %slot475, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  %rgep4764 = getelementptr i8, ptr %p4763, i64 -16
  %ld4765 = load i64, ptr %rgep4764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4765, ptr %slot478, align 8
  %v4766 = load i64, ptr %slot478, align 8
  %op4767 = and i64 %v4766, 4611686018427387906
  store i64 %op4767, ptr %slot479, align 8
  %v4768 = load i64, ptr %slot479, align 8
  %cmp4769 = icmp ne i64 %v4768, 0
  %cv4770 = zext i1 %cmp4769 to i32
  store i32 %cv4770, ptr %slot480, align 8
  %v4771 = load i32, ptr %slot480, align 8
  %cv4772 = zext i32 %v4771 to i64
  %cond4773 = icmp ne i64 %cv4772, 0
  br i1 %cond4773, label %bb_rcgclear539, label %bb_rcgcounted539
bb_rcgcounted539:
  %v4774 = load i64, ptr %slot475, align 8
  %op4775 = sub i64 %v4774, 32
  store i64 %op4775, ptr %slot481, align 8
  %v4776 = load i64, ptr %slot475, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  %rgep4778 = getelementptr i8, ptr %p4777, i64 -32
  %ld4779 = load i64, ptr %rgep4778, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4779, ptr %slot482, align 8
  %v4780 = load i64, ptr %slot482, align 8
  %op4781 = sub i64 %v4780, 1
  store i64 %op4781, ptr %slot483, align 8
  %v4782 = load i64, ptr %slot483, align 8
  %cmp4783 = icmp eq i64 %v4782, 0
  %cv4784 = zext i1 %cmp4783 to i32
  store i32 %cv4784, ptr %slot484, align 8
  %v4785 = load i32, ptr %slot484, align 8
  %cv4786 = zext i32 %v4785 to i64
  %cond4787 = icmp ne i64 %cv4786, 0
  br i1 %cond4787, label %bb_rcglast539, label %bb_rcgdec539
bb_rcglast539:
  %v4788 = load i64, ptr %slot475, align 8
  %op4789 = sub i64 %v4788, 24
  store i64 %op4789, ptr %slot485, align 8
  %v4790 = load i64, ptr %slot475, align 8
  %p4791 = inttoptr i64 %v4790 to ptr
  %rgep4792 = getelementptr i8, ptr %p4791, i64 -24
  %ld4793 = load i64, ptr %rgep4792, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4793, ptr %slot486, align 8
  %v4794 = load i64, ptr %slot486, align 8
  %cmp4795 = icmp ne i64 %v4794, 0
  %cv4796 = zext i1 %cmp4795 to i32
  store i32 %cv4796, ptr %slot487, align 8
  %v4797 = load i32, ptr %slot487, align 8
  %cv4798 = zext i32 %v4797 to i64
  %cond4799 = icmp ne i64 %cv4798, 0
  br i1 %cond4799, label %bb_rcgdec539, label %bb_rcgslow539
bb_rcgslow539:
  %v4800 = load i64, ptr %slot474, align 8
  %v4801 = load i64, ptr %slot457, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4800, i64 %v4801) nomerge, !dbg !136
  br label %bb_rcgdone539
bb_rcgdec539:
  %v4802 = load i64, ptr %slot483, align 8
  %v4803 = load i64, ptr %slot475, align 8
  %p4804 = inttoptr i64 %v4803 to ptr
  %rgep4805 = getelementptr i8, ptr %p4804, i64 -32
  store i64 %v4802, ptr %rgep4805, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear539
bb_rcgclear539:
  %v4806 = load i64, ptr %slot457, align 8
  %p4807 = inttoptr i64 %v4806 to ptr
  store i64 0, ptr %p4807, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone539
bb_rcgdone539:
  br label %bb_rcslotdone508
bb_rcslotdone508:
  %v4808 = load i64, ptr %slot7, align 8
  %p4809 = inttoptr i64 %v4808 to ptr
  %ld4810 = load i32, ptr %p4809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4810, ptr %slot488, align 8
  %v4811 = load i32, ptr %slot488, align 8
  %cv4812 = zext i32 %v4811 to i64
  %cond4813 = icmp ne i64 %cv4812, 0
  br i1 %cond4813, label %bb_rcslotdrop545, label %bb_rcslotdone545
bb_rcslotdrop545:
  %v4814 = load i64, ptr %slot7, align 8
  %p4815 = inttoptr i64 %v4814 to ptr
  store i32 0, ptr %p4815, align 4, !alias.scope !3, !noalias !4
  %v4816 = load i64, ptr %slot34, align 8
  store i64 %v4816, ptr %slot489, align 8
  %v4817 = load i64, ptr %slot8, align 8
  %p4818 = inttoptr i64 %v4817 to ptr
  %ld4819 = load i32, ptr %p4818, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4819, ptr %slot490, align 8
  %v4820 = load i32, ptr %slot490, align 8
  %op4821 = and i32 %v4820, 28
  store i32 %op4821, ptr %slot491, align 8
  %v4822 = load i32, ptr %slot491, align 8
  %cv4823 = zext i32 %v4822 to i64
  %cond4824 = icmp ne i64 %cv4823, 0
  br i1 %cond4824, label %bb_rcslotrole545, label %bb_rcslotowner545
bb_rcslotrole545:
  %v4825 = load i64, ptr %slot99, align 8
  store i64 %v4825, ptr %slot492, align 8
  %v4826 = load i64, ptr %slot489, align 8
  %p4827 = inttoptr i64 %v4826 to ptr
  %ld4828 = load i64, ptr %p4827, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4828, ptr %slot493, align 8
  %v4829 = load i64, ptr %slot493, align 8
  %cmp4830 = icmp ne i64 %v4829, 0
  %cv4831 = zext i1 %cmp4830 to i32
  store i32 %cv4831, ptr %slot494, align 8
  %v4832 = load i32, ptr %slot494, align 8
  %cv4833 = zext i32 %v4832 to i64
  %cond4834 = icmp ne i64 %cv4833, 0
  br i1 %cond4834, label %bb_rcgnn561, label %bb_rcgdone561
bb_rcgnn561:
  %v4835 = load i64, ptr %slot493, align 8
  %op4836 = sub i64 %v4835, 16
  store i64 %op4836, ptr %slot495, align 8
  %v4837 = load i64, ptr %slot493, align 8
  %p4838 = inttoptr i64 %v4837 to ptr
  %rgep4839 = getelementptr i8, ptr %p4838, i64 -16
  %ld4840 = load i64, ptr %rgep4839, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4840, ptr %slot496, align 8
  %v4841 = load i64, ptr %slot496, align 8
  %op4842 = and i64 %v4841, 4611686018427387906
  store i64 %op4842, ptr %slot497, align 8
  %v4843 = load i64, ptr %slot497, align 8
  %cmp4844 = icmp ne i64 %v4843, 0
  %cv4845 = zext i1 %cmp4844 to i32
  store i32 %cv4845, ptr %slot498, align 8
  %v4846 = load i32, ptr %slot498, align 8
  %cv4847 = zext i32 %v4846 to i64
  %cond4848 = icmp ne i64 %cv4847, 0
  br i1 %cond4848, label %bb_rcgclear561, label %bb_rcgcounted561
bb_rcgcounted561:
  %v4849 = load i64, ptr %slot493, align 8
  %op4850 = sub i64 %v4849, 24
  store i64 %op4850, ptr %slot499, align 8
  %v4851 = load i64, ptr %slot493, align 8
  %p4852 = inttoptr i64 %v4851 to ptr
  %rgep4853 = getelementptr i8, ptr %p4852, i64 -24
  %ld4854 = load i64, ptr %rgep4853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4854, ptr %slot500, align 8
  %v4855 = load i64, ptr %slot500, align 8
  %op4856 = sub i64 %v4855, 1
  store i64 %op4856, ptr %slot501, align 8
  %v4857 = load i64, ptr %slot501, align 8
  %cmp4858 = icmp eq i64 %v4857, 0
  %cv4859 = zext i1 %cmp4858 to i32
  store i32 %cv4859, ptr %slot502, align 8
  %v4860 = load i32, ptr %slot502, align 8
  %cv4861 = zext i32 %v4860 to i64
  %cond4862 = icmp ne i64 %cv4861, 0
  br i1 %cond4862, label %bb_rcglast561, label %bb_rcgdec561
bb_rcglast561:
  %v4863 = load i64, ptr %slot493, align 8
  %op4864 = sub i64 %v4863, 32
  store i64 %op4864, ptr %slot503, align 8
  %v4865 = load i64, ptr %slot493, align 8
  %p4866 = inttoptr i64 %v4865 to ptr
  %rgep4867 = getelementptr i8, ptr %p4866, i64 -32
  %ld4868 = load i64, ptr %rgep4867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4868, ptr %slot504, align 8
  %v4869 = load i64, ptr %slot504, align 8
  %cmp4870 = icmp ne i64 %v4869, 0
  %cv4871 = zext i1 %cmp4870 to i32
  store i32 %cv4871, ptr %slot505, align 8
  %v4872 = load i32, ptr %slot505, align 8
  %cv4873 = zext i32 %v4872 to i64
  %cond4874 = icmp ne i64 %cv4873, 0
  br i1 %cond4874, label %bb_rcgdec561, label %bb_rcgslow561
bb_rcgslow561:
  %v4875 = load i64, ptr %slot492, align 8
  %v4876 = load i64, ptr %slot489, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4875, i64 %v4876) nomerge, !dbg !136
  br label %bb_rcgdone561
bb_rcgdec561:
  %v4877 = load i64, ptr %slot501, align 8
  %v4878 = load i64, ptr %slot493, align 8
  %p4879 = inttoptr i64 %v4878 to ptr
  %rgep4880 = getelementptr i8, ptr %p4879, i64 -24
  store i64 %v4877, ptr %rgep4880, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear561
bb_rcgclear561:
  %v4881 = load i64, ptr %slot489, align 8
  %p4882 = inttoptr i64 %v4881 to ptr
  store i64 0, ptr %p4882, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone561
bb_rcgdone561:
  br label %bb_rcslotdone545
bb_rcslotowner545:
  %v4883 = load i64, ptr %slot99, align 8
  store i64 %v4883, ptr %slot506, align 8
  %v4884 = load i64, ptr %slot489, align 8
  %p4885 = inttoptr i64 %v4884 to ptr
  %ld4886 = load i64, ptr %p4885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4886, ptr %slot507, align 8
  %v4887 = load i64, ptr %slot507, align 8
  %cmp4888 = icmp ne i64 %v4887, 0
  %cv4889 = zext i1 %cmp4888 to i32
  store i32 %cv4889, ptr %slot508, align 8
  %v4890 = load i32, ptr %slot508, align 8
  %cv4891 = zext i32 %v4890 to i64
  %cond4892 = icmp ne i64 %cv4891, 0
  br i1 %cond4892, label %bb_rcgnn576, label %bb_rcgdone576
bb_rcgnn576:
  %v4893 = load i64, ptr %slot507, align 8
  %op4894 = sub i64 %v4893, 16
  store i64 %op4894, ptr %slot509, align 8
  %v4895 = load i64, ptr %slot507, align 8
  %p4896 = inttoptr i64 %v4895 to ptr
  %rgep4897 = getelementptr i8, ptr %p4896, i64 -16
  %ld4898 = load i64, ptr %rgep4897, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4898, ptr %slot510, align 8
  %v4899 = load i64, ptr %slot510, align 8
  %op4900 = and i64 %v4899, 4611686018427387906
  store i64 %op4900, ptr %slot511, align 8
  %v4901 = load i64, ptr %slot511, align 8
  %cmp4902 = icmp ne i64 %v4901, 0
  %cv4903 = zext i1 %cmp4902 to i32
  store i32 %cv4903, ptr %slot512, align 8
  %v4904 = load i32, ptr %slot512, align 8
  %cv4905 = zext i32 %v4904 to i64
  %cond4906 = icmp ne i64 %cv4905, 0
  br i1 %cond4906, label %bb_rcgclear576, label %bb_rcgcounted576
bb_rcgcounted576:
  %v4907 = load i64, ptr %slot507, align 8
  %op4908 = sub i64 %v4907, 32
  store i64 %op4908, ptr %slot513, align 8
  %v4909 = load i64, ptr %slot507, align 8
  %p4910 = inttoptr i64 %v4909 to ptr
  %rgep4911 = getelementptr i8, ptr %p4910, i64 -32
  %ld4912 = load i64, ptr %rgep4911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4912, ptr %slot514, align 8
  %v4913 = load i64, ptr %slot514, align 8
  %op4914 = sub i64 %v4913, 1
  store i64 %op4914, ptr %slot515, align 8
  %v4915 = load i64, ptr %slot515, align 8
  %cmp4916 = icmp eq i64 %v4915, 0
  %cv4917 = zext i1 %cmp4916 to i32
  store i32 %cv4917, ptr %slot516, align 8
  %v4918 = load i32, ptr %slot516, align 8
  %cv4919 = zext i32 %v4918 to i64
  %cond4920 = icmp ne i64 %cv4919, 0
  br i1 %cond4920, label %bb_rcglast576, label %bb_rcgdec576
bb_rcglast576:
  %v4921 = load i64, ptr %slot507, align 8
  %op4922 = sub i64 %v4921, 24
  store i64 %op4922, ptr %slot517, align 8
  %v4923 = load i64, ptr %slot507, align 8
  %p4924 = inttoptr i64 %v4923 to ptr
  %rgep4925 = getelementptr i8, ptr %p4924, i64 -24
  %ld4926 = load i64, ptr %rgep4925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4926, ptr %slot518, align 8
  %v4927 = load i64, ptr %slot518, align 8
  %cmp4928 = icmp ne i64 %v4927, 0
  %cv4929 = zext i1 %cmp4928 to i32
  store i32 %cv4929, ptr %slot519, align 8
  %v4930 = load i32, ptr %slot519, align 8
  %cv4931 = zext i32 %v4930 to i64
  %cond4932 = icmp ne i64 %cv4931, 0
  br i1 %cond4932, label %bb_rcgdec576, label %bb_rcgslow576
bb_rcgslow576:
  %v4933 = load i64, ptr %slot506, align 8
  %v4934 = load i64, ptr %slot489, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4933, i64 %v4934) nomerge, !dbg !136
  br label %bb_rcgdone576
bb_rcgdec576:
  %v4935 = load i64, ptr %slot515, align 8
  %v4936 = load i64, ptr %slot507, align 8
  %p4937 = inttoptr i64 %v4936 to ptr
  %rgep4938 = getelementptr i8, ptr %p4937, i64 -32
  store i64 %v4935, ptr %rgep4938, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear576
bb_rcgclear576:
  %v4939 = load i64, ptr %slot489, align 8
  %p4940 = inttoptr i64 %v4939 to ptr
  store i64 0, ptr %p4940, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone576
bb_rcgdone576:
  br label %bb_rcslotdone545
bb_rcslotdone545:
  %v4941 = load i64, ptr %slot5, align 8
  %p4942 = inttoptr i64 %v4941 to ptr
  %ld4943 = load i32, ptr %p4942, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4943, ptr %slot520, align 8
  %v4944 = load i32, ptr %slot520, align 8
  %cv4945 = zext i32 %v4944 to i64
  %cond4946 = icmp ne i64 %cv4945, 0
  br i1 %cond4946, label %bb_rcslotdrop582, label %bb_rcslotdone582
bb_rcslotdrop582:
  %v4947 = load i64, ptr %slot5, align 8
  %p4948 = inttoptr i64 %v4947 to ptr
  store i32 0, ptr %p4948, align 4, !alias.scope !3, !noalias !4
  %v4949 = load i64, ptr %slot33, align 8
  store i64 %v4949, ptr %slot521, align 8
  %v4950 = load i64, ptr %slot6, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  %ld4952 = load i32, ptr %p4951, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4952, ptr %slot522, align 8
  %v4953 = load i32, ptr %slot522, align 8
  %op4954 = and i32 %v4953, 28
  store i32 %op4954, ptr %slot523, align 8
  %v4955 = load i32, ptr %slot523, align 8
  %cv4956 = zext i32 %v4955 to i64
  %cond4957 = icmp ne i64 %cv4956, 0
  br i1 %cond4957, label %bb_rcslotrole582, label %bb_rcslotowner582
bb_rcslotrole582:
  %v4958 = load i64, ptr %slot99, align 8
  store i64 %v4958, ptr %slot524, align 8
  %v4959 = load i64, ptr %slot524, align 8
  %v4960 = load i64, ptr %slot521, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v4959, i64 %v4960) nomerge, !dbg !136
  br label %bb_rcslotdone582
bb_rcslotowner582:
  %v4961 = load i64, ptr %slot99, align 8
  store i64 %v4961, ptr %slot525, align 8
  %v4962 = load i64, ptr %slot525, align 8
  %v4963 = load i64, ptr %slot521, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v4962, i64 %v4963) nomerge, !dbg !136
  br label %bb_rcslotdone582
bb_rcslotdone582:
  %v4964 = load i64, ptr %slot442, align 8
  %p4965 = inttoptr i64 %v4964 to ptr
  %ret4966 = load { i64, i64 }, ptr %p4965, align 8
  ret { i64, i64 } %ret4966
bb_i35:
  %v4967 = load i64, ptr %slot32, align 8
  %p4968 = inttoptr i64 %v4967 to ptr
  %ld4969 = load i64, ptr %p4968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4969, ptr %slot526, align 8
  %v4970 = load i64, ptr %slot526, align 8
  %v4971 = load i64, ptr %slot44, align 8
  %p4972 = inttoptr i64 %v4971 to ptr
  store i64 %v4970, ptr %p4972, align 8, !alias.scope !3, !noalias !4
  %v4973 = load i64, ptr %slot62, align 8
  store i64 %v4973, ptr %slot527, align 8
  %v4974 = load i64, ptr %slot527, align 8
  %p4975 = inttoptr i64 %v4974 to ptr
  store i32 0, ptr %p4975, align 4, !alias.scope !3, !noalias !4
  %v4976 = load i64, ptr %slot527, align 8
  %p4977 = inttoptr i64 %v4976 to ptr
  store i32 21, ptr %p4977, align 4, !alias.scope !3, !noalias !4
  %v4978 = load i64, ptr %slot527, align 8
  %v4979 = load i64, ptr %slot45, align 8
  %p4980 = inttoptr i64 %v4979 to ptr
  store i64 %v4978, ptr %p4980, align 8, !alias.scope !3, !noalias !4
  %v4981 = load i64, ptr %slot44, align 8
  %p4982 = inttoptr i64 %v4981 to ptr
  %ld4983 = load i64, ptr %p4982, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4983, ptr %slot528, align 8
  %v4984 = load i64, ptr %slot45, align 8
  %p4985 = inttoptr i64 %v4984 to ptr
  %ld4986 = load i64, ptr %p4985, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4986, ptr %slot529, align 8
  %v4987 = load i64, ptr %slot1, align 8
  %v4988 = load i64, ptr %slot528, align 8
  %v4989 = load i64, ptr %slot529, align 8
  %call4990 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v4987, i64 %v4988, i64 %v4989) nomerge, !dbg !138
  store i64 %call4990, ptr %slot530, align 8
  %v4991 = load i64, ptr %slot530, align 8
  %v4992 = load i64, ptr %slot44, align 8
  %p4993 = inttoptr i64 %v4992 to ptr
  store i64 %v4991, ptr %p4993, align 8, !alias.scope !3, !noalias !4
  %v4994 = load i64, ptr %slot15, align 8
  %p4995 = inttoptr i64 %v4994 to ptr
  %ld4996 = load i32, ptr %p4995, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4996, ptr %slot531, align 8
  %v4997 = load i32, ptr %slot531, align 8
  %cv4998 = zext i32 %v4997 to i64
  %cond4999 = icmp ne i64 %cv4998, 0
  br i1 %cond4999, label %bb_rcslotdrop605, label %bb_rcslotdone605
bb_rcslotdrop605:
  %v5000 = load i64, ptr %slot15, align 8
  %p5001 = inttoptr i64 %v5000 to ptr
  store i32 0, ptr %p5001, align 4, !alias.scope !3, !noalias !4
  %v5002 = load i64, ptr %slot24, align 8
  store i64 %v5002, ptr %slot532, align 8
  %v5003 = load i64, ptr %slot16, align 8
  %p5004 = inttoptr i64 %v5003 to ptr
  %ld5005 = load i32, ptr %p5004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5005, ptr %slot533, align 8
  %v5006 = load i32, ptr %slot533, align 8
  %op5007 = and i32 %v5006, 28
  store i32 %op5007, ptr %slot534, align 8
  %v5008 = load i32, ptr %slot534, align 8
  %cv5009 = zext i32 %v5008 to i64
  %cond5010 = icmp ne i64 %cv5009, 0
  br i1 %cond5010, label %bb_rcslotrole605, label %bb_rcslotowner605
bb_rcslotrole605:
  %v5011 = load i64, ptr %slot99, align 8
  store i64 %v5011, ptr %slot535, align 8
  %v5012 = load i64, ptr %slot535, align 8
  %v5013 = load i64, ptr %slot532, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v5012, i64 %v5013) nomerge, !dbg !138
  br label %bb_rcslotdone605
bb_rcslotowner605:
  %v5014 = load i64, ptr %slot99, align 8
  store i64 %v5014, ptr %slot536, align 8
  %v5015 = load i64, ptr %slot536, align 8
  %v5016 = load i64, ptr %slot532, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v5015, i64 %v5016) nomerge, !dbg !138
  br label %bb_rcslotdone605
bb_rcslotdone605:
  %v5017 = load i64, ptr %slot44, align 8
  %p5018 = inttoptr i64 %v5017 to ptr
  %ld5019 = load i64, ptr %p5018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5019, ptr %slot537, align 8
  %v5020 = load i64, ptr %slot537, align 8
  %cond5021 = icmp ne i64 %v5020, 0
  br i1 %cond5021, label %bb_next613, label %bb_i72
bb_next613:
  %v5022 = load i64, ptr %slot32, align 8
  %p5023 = inttoptr i64 %v5022 to ptr
  %ld5024 = load i64, ptr %p5023, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5024, ptr %slot538, align 8
  %v5025 = load i64, ptr %slot538, align 8
  %v5026 = load i64, ptr %slot44, align 8
  %p5027 = inttoptr i64 %v5026 to ptr
  store i64 %v5025, ptr %p5027, align 8, !alias.scope !3, !noalias !4
  %v5028 = load i64, ptr %slot44, align 8
  %p5029 = inttoptr i64 %v5028 to ptr
  %ld5030 = load i64, ptr %p5029, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5030, ptr %slot539, align 8
  %v5031 = load i64, ptr %slot1, align 8
  %v5032 = load i64, ptr %slot539, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult541, i64 %v5031, i64 %v5032) nomerge, !dbg !140
  %addr5033 = ptrtoint ptr %callresult541 to i64
  store i64 %addr5033, ptr %slot540, align 8
  %v5034 = load i64, ptr %slot540, align 8
  %v5035 = load i64, ptr %slot44, align 8
  %p5036 = inttoptr i64 %v5035 to ptr
  store i64 %v5034, ptr %p5036, align 8, !alias.scope !3, !noalias !4
  %v5037 = load i64, ptr %slot44, align 8
  %p5038 = inttoptr i64 %v5037 to ptr
  %ld5039 = load i64, ptr %p5038, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5039, ptr %slot542, align 8
  %v5040 = load i64, ptr %slot30, align 8
  store i64 %v5040, ptr %slot543, align 8
  %v5041 = load i64, ptr %slot99, align 8
  %v5042 = load i64, ptr %slot543, align 8
  %v5043 = load i64, ptr %slot542, align 8
  %call5044 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v5041, i64 %v5042, i64 %v5043) nomerge, !dbg !140
  store i32 %call5044, ptr %slot544, align 8
  %v5045 = load i32, ptr %slot544, align 8
  %cv5046 = zext i32 %v5045 to i64
  %cond5047 = icmp ne i64 %cv5046, 0
  br i1 %cond5047, label %bb_rcsuccess619, label %bb_rcfailure619
bb_rcfailure619:
  %v5048 = load i64, ptr %slot99, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  %call5050 = call i32 @myl_rc_take_failure(ptr %p5049) nomerge, !dbg !140
  store i32 %call5050, ptr %slot545, align 8
  %v5051 = load i64, ptr %slot1, align 8
  %p5052 = inttoptr i64 %v5051 to ptr
  %v5053 = load i32, ptr %slot545, align 8
  %call5054 = call i32 @myl_qbe_rc_status(ptr %p5052, i32 %v5053) nomerge, !dbg !140
  store i32 %call5054, ptr %slot546, align 8
  br label %bb_failure
bb_rcsuccess619:
  %v5055 = load i64, ptr %slot22, align 8
  %p5056 = inttoptr i64 %v5055 to ptr
  store i32 2, ptr %p5056, align 4, !alias.scope !3, !noalias !4
  %v5057 = load i64, ptr %slot22, align 8
  %p5058 = inttoptr i64 %v5057 to ptr
  store i32 16, ptr %p5058, align 4, !alias.scope !3, !noalias !4
  %v5059 = load i64, ptr %slot21, align 8
  %p5060 = inttoptr i64 %v5059 to ptr
  store i32 1, ptr %p5060, align 4, !alias.scope !3, !noalias !4
  %v5061 = load i64, ptr %slot15, align 8
  %p5062 = inttoptr i64 %v5061 to ptr
  %ld5063 = load i32, ptr %p5062, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5063, ptr %slot547, align 8
  %v5064 = load i32, ptr %slot547, align 8
  %cv5065 = zext i32 %v5064 to i64
  %cond5066 = icmp ne i64 %cv5065, 0
  br i1 %cond5066, label %bb_rcslotdrop627, label %bb_rcslotdone627
bb_rcslotdrop627:
  %v5067 = load i64, ptr %slot15, align 8
  %p5068 = inttoptr i64 %v5067 to ptr
  store i32 0, ptr %p5068, align 4, !alias.scope !3, !noalias !4
  %v5069 = load i64, ptr %slot24, align 8
  store i64 %v5069, ptr %slot548, align 8
  %v5070 = load i64, ptr %slot16, align 8
  %p5071 = inttoptr i64 %v5070 to ptr
  %ld5072 = load i32, ptr %p5071, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5072, ptr %slot549, align 8
  %v5073 = load i32, ptr %slot549, align 8
  %op5074 = and i32 %v5073, 28
  store i32 %op5074, ptr %slot550, align 8
  %v5075 = load i32, ptr %slot550, align 8
  %cv5076 = zext i32 %v5075 to i64
  %cond5077 = icmp ne i64 %cv5076, 0
  br i1 %cond5077, label %bb_rcslotrole627, label %bb_rcslotowner627
bb_rcslotrole627:
  %v5078 = load i64, ptr %slot99, align 8
  store i64 %v5078, ptr %slot551, align 8
  %v5079 = load i64, ptr %slot551, align 8
  %v5080 = load i64, ptr %slot548, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v5079, i64 %v5080) nomerge, !dbg !140
  br label %bb_rcslotdone627
bb_rcslotowner627:
  %v5081 = load i64, ptr %slot99, align 8
  store i64 %v5081, ptr %slot552, align 8
  %v5082 = load i64, ptr %slot552, align 8
  %v5083 = load i64, ptr %slot548, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v5082, i64 %v5083) nomerge, !dbg !140
  br label %bb_rcslotdone627
bb_rcslotdone627:
  %v5084 = load i64, ptr %slot24, align 8
  store i64 %v5084, ptr %slot553, align 8
  %v5085 = load i64, ptr %slot30, align 8
  store i64 %v5085, ptr %slot554, align 8
  %v5086 = load i64, ptr %slot554, align 8
  %v5087 = load i64, ptr %slot553, align 8
  %p5088 = inttoptr i64 %v5086 to ptr
  %p5089 = inttoptr i64 %v5087 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5089, ptr %p5088, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5090 = load i64, ptr %slot16, align 8
  %p5091 = inttoptr i64 %v5090 to ptr
  store i32 2, ptr %p5091, align 4, !alias.scope !3, !noalias !4
  %v5092 = load i64, ptr %slot22, align 8
  %p5093 = inttoptr i64 %v5092 to ptr
  %ld5094 = load i32, ptr %p5093, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5094, ptr %slot555, align 8
  %v5095 = load i32, ptr %slot555, align 8
  %v5096 = load i64, ptr %slot16, align 8
  %p5097 = inttoptr i64 %v5096 to ptr
  store i32 %v5095, ptr %p5097, align 4, !alias.scope !3, !noalias !4
  %v5098 = load i64, ptr %slot21, align 8
  %p5099 = inttoptr i64 %v5098 to ptr
  store i32 0, ptr %p5099, align 4, !alias.scope !3, !noalias !4
  %v5100 = load i64, ptr %slot15, align 8
  %p5101 = inttoptr i64 %v5100 to ptr
  store i32 1, ptr %p5101, align 4, !alias.scope !3, !noalias !4
  %v5102 = load i64, ptr %slot553, align 8
  %v5103 = load i64, ptr %slot44, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  store i64 %v5102, ptr %p5104, align 8, !alias.scope !3, !noalias !4
  %v5105 = load i64, ptr %slot44, align 8
  %p5106 = inttoptr i64 %v5105 to ptr
  %ld5107 = load i64, ptr %p5106, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5107, ptr %slot556, align 8
  %v5108 = load i64, ptr %slot15, align 8
  %p5109 = inttoptr i64 %v5108 to ptr
  %ld5110 = load i32, ptr %p5109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5110, ptr %slot557, align 8
  %v5111 = load i64, ptr %slot16, align 8
  %p5112 = inttoptr i64 %v5111 to ptr
  %ld5113 = load i32, ptr %p5112, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5113, ptr %slot558, align 8
  %v5114 = load i32, ptr %slot558, align 8
  %op5115 = and i32 %v5114, 24
  store i32 %op5115, ptr %slot558, align 8
  %v5116 = load i32, ptr %slot558, align 8
  %cmp5117 = icmp eq i32 %v5116, 0
  %cv5118 = zext i1 %cmp5117 to i32
  store i32 %cv5118, ptr %slot559, align 8
  %v5119 = load i32, ptr %slot557, align 8
  %v5120 = load i32, ptr %slot559, align 8
  %op5121 = and i32 %v5119, %v5120
  store i32 %op5121, ptr %slot560, align 8
  %v5122 = load i32, ptr %slot560, align 8
  %cv5123 = zext i32 %v5122 to i64
  %cond5124 = icmp ne i64 %cv5123, 0
  br i1 %cond5124, label %bb_rctake643, label %bb_rccopy643
bb_rctake643:
  %v5125 = load i64, ptr %slot30, align 8
  store i64 %v5125, ptr %slot561, align 8
  %v5126 = load i64, ptr %slot100, align 8
  store i64 %v5126, ptr %slot562, align 8
  %v5127 = load i64, ptr %slot99, align 8
  %v5128 = load i64, ptr %slot561, align 8
  %v5129 = load i64, ptr %slot556, align 8
  %v5130 = load i64, ptr %slot562, align 8
  %cv5131 = trunc i64 %v5130 to i32
  %call5132 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v5127, i64 %v5128, i64 %v5129, i32 %cv5131) nomerge, !dbg !142
  store i32 %call5132, ptr %slot563, align 8
  %v5133 = load i32, ptr %slot563, align 8
  %cv5134 = zext i32 %v5133 to i64
  %cond5135 = icmp ne i64 %cv5134, 0
  br i1 %cond5135, label %bb_rcsuccess653, label %bb_rcfailure653
bb_rcfailure653:
  %v5136 = load i64, ptr %slot99, align 8
  %p5137 = inttoptr i64 %v5136 to ptr
  %call5138 = call i32 @myl_rc_take_failure(ptr %p5137) nomerge, !dbg !142
  store i32 %call5138, ptr %slot564, align 8
  %v5139 = load i64, ptr %slot1, align 8
  %p5140 = inttoptr i64 %v5139 to ptr
  %v5141 = load i32, ptr %slot564, align 8
  %call5142 = call i32 @myl_qbe_rc_status(ptr %p5140, i32 %v5141) nomerge, !dbg !142
  store i32 %call5142, ptr %slot565, align 8
  br label %bb_failure
bb_rcsuccess653:
  %v5143 = load i64, ptr %slot15, align 8
  %p5144 = inttoptr i64 %v5143 to ptr
  store i32 0, ptr %p5144, align 4, !alias.scope !3, !noalias !4
  %v5145 = load i64, ptr %slot22, align 8
  %p5146 = inttoptr i64 %v5145 to ptr
  store i32 2, ptr %p5146, align 4, !alias.scope !3, !noalias !4
  %v5147 = load i64, ptr %slot21, align 8
  %p5148 = inttoptr i64 %v5147 to ptr
  store i32 1, ptr %p5148, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared643
bb_rccopy643:
  %v5149 = load i64, ptr %slot30, align 8
  store i64 %v5149, ptr %slot566, align 8
  %v5150 = load i64, ptr %slot100, align 8
  store i64 %v5150, ptr %slot567, align 8
  %v5151 = load i64, ptr %slot99, align 8
  %v5152 = load i64, ptr %slot566, align 8
  %v5153 = load i64, ptr %slot556, align 8
  %v5154 = load i64, ptr %slot567, align 8
  %cv5155 = trunc i64 %v5154 to i32
  %call5156 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v5151, i64 %v5152, i64 %v5153, i32 %cv5155) nomerge, !dbg !142
  store i32 %call5156, ptr %slot568, align 8
  %v5157 = load i32, ptr %slot568, align 8
  %cv5158 = zext i32 %v5157 to i64
  %cond5159 = icmp ne i64 %cv5158, 0
  br i1 %cond5159, label %bb_rcsuccess662, label %bb_rcfailure662
bb_rcfailure662:
  %v5160 = load i64, ptr %slot99, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  %call5162 = call i32 @myl_rc_take_failure(ptr %p5161) nomerge, !dbg !142
  store i32 %call5162, ptr %slot569, align 8
  %v5163 = load i64, ptr %slot1, align 8
  %p5164 = inttoptr i64 %v5163 to ptr
  %v5165 = load i32, ptr %slot569, align 8
  %call5166 = call i32 @myl_qbe_rc_status(ptr %p5164, i32 %v5165) nomerge, !dbg !142
  store i32 %call5166, ptr %slot570, align 8
  br label %bb_failure
bb_rcsuccess662:
  %v5167 = load i64, ptr %slot22, align 8
  %p5168 = inttoptr i64 %v5167 to ptr
  store i32 2, ptr %p5168, align 4, !alias.scope !3, !noalias !4
  %v5169 = load i64, ptr %slot21, align 8
  %p5170 = inttoptr i64 %v5169 to ptr
  store i32 1, ptr %p5170, align 4, !alias.scope !3, !noalias !4
  %v5171 = load i64, ptr %slot15, align 8
  %p5172 = inttoptr i64 %v5171 to ptr
  %ld5173 = load i32, ptr %p5172, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5173, ptr %slot571, align 8
  %v5174 = load i32, ptr %slot571, align 8
  %cv5175 = zext i32 %v5174 to i64
  %cond5176 = icmp ne i64 %cv5175, 0
  br i1 %cond5176, label %bb_rcslotdrop669, label %bb_rcslotdone669
bb_rcslotdrop669:
  %v5177 = load i64, ptr %slot15, align 8
  %p5178 = inttoptr i64 %v5177 to ptr
  store i32 0, ptr %p5178, align 4, !alias.scope !3, !noalias !4
  %v5179 = load i64, ptr %slot24, align 8
  store i64 %v5179, ptr %slot572, align 8
  %v5180 = load i64, ptr %slot16, align 8
  %p5181 = inttoptr i64 %v5180 to ptr
  %ld5182 = load i32, ptr %p5181, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5182, ptr %slot573, align 8
  %v5183 = load i32, ptr %slot573, align 8
  %op5184 = and i32 %v5183, 28
  store i32 %op5184, ptr %slot574, align 8
  %v5185 = load i32, ptr %slot574, align 8
  %cv5186 = zext i32 %v5185 to i64
  %cond5187 = icmp ne i64 %cv5186, 0
  br i1 %cond5187, label %bb_rcslotrole669, label %bb_rcslotowner669
bb_rcslotrole669:
  %v5188 = load i64, ptr %slot99, align 8
  store i64 %v5188, ptr %slot575, align 8
  %v5189 = load i64, ptr %slot575, align 8
  %v5190 = load i64, ptr %slot572, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v5189, i64 %v5190) nomerge, !dbg !142
  br label %bb_rcslotdone669
bb_rcslotowner669:
  %v5191 = load i64, ptr %slot99, align 8
  store i64 %v5191, ptr %slot576, align 8
  %v5192 = load i64, ptr %slot576, align 8
  %v5193 = load i64, ptr %slot572, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v5192, i64 %v5193) nomerge, !dbg !142
  br label %bb_rcslotdone669
bb_rcslotdone669:
  br label %bb_rcprepared643
bb_rcprepared643:
  %v5194 = load i64, ptr %slot5, align 8
  %p5195 = inttoptr i64 %v5194 to ptr
  %ld5196 = load i32, ptr %p5195, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5196, ptr %slot577, align 8
  %v5197 = load i32, ptr %slot577, align 8
  %cv5198 = zext i32 %v5197 to i64
  %cond5199 = icmp ne i64 %cv5198, 0
  br i1 %cond5199, label %bb_rcslotdrop679, label %bb_rcslotdone679
bb_rcslotdrop679:
  %v5200 = load i64, ptr %slot5, align 8
  %p5201 = inttoptr i64 %v5200 to ptr
  store i32 0, ptr %p5201, align 4, !alias.scope !3, !noalias !4
  %v5202 = load i64, ptr %slot33, align 8
  store i64 %v5202, ptr %slot578, align 8
  %v5203 = load i64, ptr %slot6, align 8
  %p5204 = inttoptr i64 %v5203 to ptr
  %ld5205 = load i32, ptr %p5204, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5205, ptr %slot579, align 8
  %v5206 = load i32, ptr %slot579, align 8
  %op5207 = and i32 %v5206, 28
  store i32 %op5207, ptr %slot580, align 8
  %v5208 = load i32, ptr %slot580, align 8
  %cv5209 = zext i32 %v5208 to i64
  %cond5210 = icmp ne i64 %cv5209, 0
  br i1 %cond5210, label %bb_rcslotrole679, label %bb_rcslotowner679
bb_rcslotrole679:
  %v5211 = load i64, ptr %slot99, align 8
  store i64 %v5211, ptr %slot581, align 8
  %v5212 = load i64, ptr %slot581, align 8
  %v5213 = load i64, ptr %slot578, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v5212, i64 %v5213) nomerge, !dbg !142
  br label %bb_rcslotdone679
bb_rcslotowner679:
  %v5214 = load i64, ptr %slot99, align 8
  store i64 %v5214, ptr %slot582, align 8
  %v5215 = load i64, ptr %slot582, align 8
  %v5216 = load i64, ptr %slot578, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v5215, i64 %v5216) nomerge, !dbg !142
  br label %bb_rcslotdone679
bb_rcslotdone679:
  %v5217 = load i64, ptr %slot33, align 8
  store i64 %v5217, ptr %slot583, align 8
  %v5218 = load i64, ptr %slot30, align 8
  store i64 %v5218, ptr %slot584, align 8
  %v5219 = load i64, ptr %slot584, align 8
  %v5220 = load i64, ptr %slot583, align 8
  %p5221 = inttoptr i64 %v5219 to ptr
  %p5222 = inttoptr i64 %v5220 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5222, ptr %p5221, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5223 = load i64, ptr %slot21, align 8
  %p5224 = inttoptr i64 %v5223 to ptr
  store i32 0, ptr %p5224, align 4, !alias.scope !3, !noalias !4
  %v5225 = load i64, ptr %slot6, align 8
  %p5226 = inttoptr i64 %v5225 to ptr
  store i32 2, ptr %p5226, align 4, !alias.scope !3, !noalias !4
  %v5227 = load i64, ptr %slot22, align 8
  %p5228 = inttoptr i64 %v5227 to ptr
  %ld5229 = load i32, ptr %p5228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5229, ptr %slot585, align 8
  %v5230 = load i32, ptr %slot585, align 8
  %v5231 = load i64, ptr %slot6, align 8
  %p5232 = inttoptr i64 %v5231 to ptr
  store i32 %v5230, ptr %p5232, align 4, !alias.scope !3, !noalias !4
  %v5233 = load i64, ptr %slot5, align 8
  %p5234 = inttoptr i64 %v5233 to ptr
  store i32 1, ptr %p5234, align 4, !alias.scope !3, !noalias !4
  %v5235 = load i64, ptr %slot32, align 8
  %p5236 = inttoptr i64 %v5235 to ptr
  %ld5237 = load i64, ptr %p5236, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5237, ptr %slot586, align 8
  %v5238 = load i64, ptr %slot586, align 8
  %v5239 = load i64, ptr %slot44, align 8
  %p5240 = inttoptr i64 %v5239 to ptr
  store i64 %v5238, ptr %p5240, align 8, !alias.scope !3, !noalias !4
  %v5241 = load i64, ptr %slot44, align 8
  %p5242 = inttoptr i64 %v5241 to ptr
  %ld5243 = load i64, ptr %p5242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5243, ptr %slot587, align 8
  %v5244 = load i64, ptr %slot587, align 8
  %op5245 = add i64 %v5244, 248
  store i64 %op5245, ptr %slot588, align 8
  %v5246 = load i64, ptr %slot588, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  %ld5248 = load i64, ptr %p5247, align 8
  store i64 %ld5248, ptr %slot589, align 8
  %v5249 = load i64, ptr %slot589, align 8
  %v5250 = load i64, ptr %slot44, align 8
  %p5251 = inttoptr i64 %v5250 to ptr
  store i64 %v5249, ptr %p5251, align 8, !alias.scope !3, !noalias !4
  %v5252 = load i64, ptr %slot15, align 8
  %p5253 = inttoptr i64 %v5252 to ptr
  %ld5254 = load i32, ptr %p5253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5254, ptr %slot590, align 8
  %v5255 = load i32, ptr %slot590, align 8
  %cv5256 = zext i32 %v5255 to i64
  %cond5257 = icmp ne i64 %cv5256, 0
  br i1 %cond5257, label %bb_rcslotdrop699, label %bb_rcslotdone699
bb_rcslotdrop699:
  %v5258 = load i64, ptr %slot15, align 8
  %p5259 = inttoptr i64 %v5258 to ptr
  store i32 0, ptr %p5259, align 4, !alias.scope !3, !noalias !4
  %v5260 = load i64, ptr %slot24, align 8
  store i64 %v5260, ptr %slot591, align 8
  %v5261 = load i64, ptr %slot16, align 8
  %p5262 = inttoptr i64 %v5261 to ptr
  %ld5263 = load i32, ptr %p5262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5263, ptr %slot592, align 8
  %v5264 = load i32, ptr %slot592, align 8
  %op5265 = and i32 %v5264, 28
  store i32 %op5265, ptr %slot593, align 8
  %v5266 = load i32, ptr %slot593, align 8
  %cv5267 = zext i32 %v5266 to i64
  %cond5268 = icmp ne i64 %cv5267, 0
  br i1 %cond5268, label %bb_rcslotrole699, label %bb_rcslotowner699
bb_rcslotrole699:
  %v5269 = load i64, ptr %slot99, align 8
  store i64 %v5269, ptr %slot594, align 8
  %v5270 = load i64, ptr %slot594, align 8
  %v5271 = load i64, ptr %slot591, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v5270, i64 %v5271) nomerge, !dbg !144
  br label %bb_rcslotdone699
bb_rcslotowner699:
  %v5272 = load i64, ptr %slot99, align 8
  store i64 %v5272, ptr %slot595, align 8
  %v5273 = load i64, ptr %slot595, align 8
  %v5274 = load i64, ptr %slot591, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v5273, i64 %v5274) nomerge, !dbg !144
  br label %bb_rcslotdone699
bb_rcslotdone699:
  %v5275 = load i64, ptr %slot44, align 8
  %p5276 = inttoptr i64 %v5275 to ptr
  %ld5277 = load i64, ptr %p5276, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5277, ptr %slot596, align 8
  %v5278 = load i64, ptr %slot596, align 8
  %v5279 = load i64, ptr %slot27, align 8
  %p5280 = inttoptr i64 %v5279 to ptr
  store i64 %v5278, ptr %p5280, align 8, !alias.scope !3, !noalias !4
  %v5281 = load i64, ptr %slot27, align 8
  store i64 %v5281, ptr %slot597, align 8
  %v5282 = load i64, ptr %slot15, align 8
  %p5283 = inttoptr i64 %v5282 to ptr
  %ld5284 = load i32, ptr %p5283, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5284, ptr %slot598, align 8
  %v5285 = load i64, ptr %slot16, align 8
  %p5286 = inttoptr i64 %v5285 to ptr
  %ld5287 = load i32, ptr %p5286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5287, ptr %slot599, align 8
  %v5288 = load i32, ptr %slot599, align 8
  %op5289 = and i32 %v5288, 24
  store i32 %op5289, ptr %slot599, align 8
  %v5290 = load i32, ptr %slot599, align 8
  %cmp5291 = icmp eq i32 %v5290, 0
  %cv5292 = zext i1 %cmp5291 to i32
  store i32 %cv5292, ptr %slot600, align 8
  %v5293 = load i32, ptr %slot598, align 8
  %v5294 = load i32, ptr %slot600, align 8
  %op5295 = and i32 %v5293, %v5294
  store i32 %op5295, ptr %slot601, align 8
  %v5296 = load i32, ptr %slot601, align 8
  %cv5297 = zext i32 %v5296 to i64
  %cond5298 = icmp ne i64 %cv5297, 0
  br i1 %cond5298, label %bb_rcprivateown714, label %bb_rcprivateloan714
bb_rcprivateown714:
  %v5299 = load i64, ptr %slot30, align 8
  store i64 %v5299, ptr %slot602, align 8
  %v5300 = load i64, ptr %slot100, align 8
  store i64 %v5300, ptr %slot603, align 8
  %v5301 = load i64, ptr %slot597, align 8
  %v5302 = load i64, ptr %slot602, align 8
  %op5303 = sub i64 %v5301, %v5302
  store i64 %op5303, ptr %slot604, align 8
  %v5304 = load i64, ptr %slot602, align 8
  %v5305 = load i64, ptr %slot597, align 8
  %op5306 = sub i64 %v5304, %v5305
  store i64 %op5306, ptr %slot605, align 8
  %v5307 = load i64, ptr %slot604, align 8
  %cmp5308 = icmp ult i64 %v5307, 8
  %cv5309 = zext i1 %cmp5308 to i32
  store i32 %cv5309, ptr %slot606, align 8
  %v5310 = load i64, ptr %slot605, align 8
  %cmp5311 = icmp ult i64 %v5310, 8
  %cv5312 = zext i1 %cmp5311 to i32
  store i32 %cv5312, ptr %slot607, align 8
  %v5313 = load i32, ptr %slot606, align 8
  %v5314 = load i32, ptr %slot607, align 8
  %op5315 = or i32 %v5313, %v5314
  store i32 %op5315, ptr %slot608, align 8
  %v5316 = load i32, ptr %slot608, align 8
  %cv5317 = zext i32 %v5316 to i64
  %cond5318 = icmp ne i64 %cv5317, 0
  br i1 %cond5318, label %bb_rcmoveslow717, label %bb_rcmovecheck717
bb_rcmovecheck717:
  %v5319 = load i64, ptr %slot597, align 8
  %p5321 = inttoptr i64 %v5319 to ptr
  %gep5322 = getelementptr i8, ptr %p5321, i64 0
  %op5320 = ptrtoint ptr %gep5322 to i64
  store i64 %op5320, ptr %slot609, align 8
  %v5323 = load i64, ptr %slot609, align 8
  %p5324 = inttoptr i64 %v5323 to ptr
  %ld5325 = load i64, ptr %p5324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5325, ptr %slot610, align 8
  %v5326 = load i64, ptr %slot610, align 8
  %cmp5327 = icmp ne i64 %v5326, 0
  %cv5328 = zext i1 %cmp5327 to i32
  store i32 %cv5328, ptr %slot611, align 8
  %v5329 = load i32, ptr %slot611, align 8
  %cv5330 = zext i32 %v5329 to i64
  %cond5331 = icmp ne i64 %cv5330, 0
  br i1 %cond5331, label %bb_rcmoveheader725, label %bb_rcmovenext725
bb_rcmoveheader725:
  %v5332 = load i64, ptr %slot610, align 8
  %op5333 = sub i64 %v5332, 16
  store i64 %op5333, ptr %slot612, align 8
  %v5334 = load i64, ptr %slot610, align 8
  %p5335 = inttoptr i64 %v5334 to ptr
  %rgep5336 = getelementptr i8, ptr %p5335, i64 -16
  %ld5337 = load i64, ptr %rgep5336, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5337, ptr %slot613, align 8
  %v5338 = load i64, ptr %slot613, align 8
  %op5339 = and i64 %v5338, 5764607523034234881
  store i64 %op5339, ptr %slot614, align 8
  %v5340 = load i64, ptr %slot614, align 8
  %cmp5341 = icmp ne i64 %v5340, 0
  %cv5342 = zext i1 %cmp5341 to i32
  store i32 %cv5342, ptr %slot615, align 8
  %v5343 = load i32, ptr %slot615, align 8
  %cv5344 = zext i32 %v5343 to i64
  %cond5345 = icmp ne i64 %cv5344, 0
  br i1 %cond5345, label %bb_rcmoveslow717, label %bb_rcmovenext725
bb_rcmovenext725:
  %v5346 = load i64, ptr %slot597, align 8
  %v5347 = load i64, ptr %slot602, align 8
  %p5348 = inttoptr i64 %v5346 to ptr
  %p5349 = inttoptr i64 %v5347 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5349, ptr %p5348, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5350 = load i64, ptr %slot597, align 8
  %p5351 = inttoptr i64 %v5350 to ptr
  store i64 0, ptr %p5351, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved717
bb_rcmoveslow717:
  %v5352 = load i64, ptr %slot99, align 8
  %v5353 = load i64, ptr %slot602, align 8
  %v5354 = load i64, ptr %slot597, align 8
  %v5355 = load i64, ptr %slot603, align 8
  %cv5356 = trunc i64 %v5355 to i32
  %call5357 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v5352, i64 %v5353, i64 %v5354, i32 %cv5356) nomerge, !dbg !146
  store i32 %call5357, ptr %slot616, align 8
  %v5358 = load i32, ptr %slot616, align 8
  %cv5359 = zext i32 %v5358 to i64
  %cond5360 = icmp ne i64 %cv5359, 0
  br i1 %cond5360, label %bb_rcsuccess732, label %bb_rcfailure732
bb_rcfailure732:
  %v5361 = load i64, ptr %slot99, align 8
  %p5362 = inttoptr i64 %v5361 to ptr
  %call5363 = call i32 @myl_rc_take_failure(ptr %p5362) nomerge, !dbg !146
  store i32 %call5363, ptr %slot617, align 8
  %v5364 = load i64, ptr %slot1, align 8
  %p5365 = inttoptr i64 %v5364 to ptr
  %v5366 = load i32, ptr %slot617, align 8
  %call5367 = call i32 @myl_qbe_rc_status(ptr %p5365, i32 %v5366) nomerge, !dbg !146
  store i32 %call5367, ptr %slot618, align 8
  br label %bb_failure
bb_rcsuccess732:
  br label %bb_rcmoved717
bb_rcmoved717:
  %v5368 = load i64, ptr %slot15, align 8
  %p5369 = inttoptr i64 %v5368 to ptr
  store i32 0, ptr %p5369, align 4, !alias.scope !3, !noalias !4
  %v5370 = load i64, ptr %slot22, align 8
  %p5371 = inttoptr i64 %v5370 to ptr
  store i32 2, ptr %p5371, align 4, !alias.scope !3, !noalias !4
  %v5372 = load i64, ptr %slot21, align 8
  %p5373 = inttoptr i64 %v5372 to ptr
  store i32 1, ptr %p5373, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared714
bb_rcprivateloan714:
  %v5374 = load i64, ptr %slot15, align 8
  %p5375 = inttoptr i64 %v5374 to ptr
  %ld5376 = load i32, ptr %p5375, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5376, ptr %slot619, align 8
  %v5377 = load i64, ptr %slot16, align 8
  %p5378 = inttoptr i64 %v5377 to ptr
  %ld5379 = load i32, ptr %p5378, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5379, ptr %slot620, align 8
  %v5380 = load i32, ptr %slot620, align 8
  %cmp5381 = icmp eq i32 %v5380, 16
  %cv5382 = zext i1 %cmp5381 to i32
  store i32 %cv5382, ptr %slot621, align 8
  %v5383 = load i32, ptr %slot621, align 8
  %v5384 = load i32, ptr %slot619, align 8
  %op5385 = and i32 %v5383, %v5384
  store i32 %op5385, ptr %slot621, align 8
  %v5386 = load i32, ptr %slot621, align 8
  %cv5387 = zext i32 %v5386 to i64
  %cond5388 = icmp ne i64 %cv5387, 0
  br i1 %cond5388, label %bb_rcprivatemove714, label %bb_rcprivatenew714
bb_rcprivatemove714:
  %v5389 = load i64, ptr %slot30, align 8
  store i64 %v5389, ptr %slot622, align 8
  %v5390 = load i64, ptr %slot597, align 8
  %v5391 = load i64, ptr %slot622, align 8
  %p5392 = inttoptr i64 %v5390 to ptr
  %p5393 = inttoptr i64 %v5391 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5393, ptr %p5392, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5394 = load i64, ptr %slot597, align 8
  %p5395 = inttoptr i64 %v5394 to ptr
  store i64 0, ptr %p5395, align 8, !alias.scope !3, !noalias !4
  %v5396 = load i64, ptr %slot22, align 8
  %p5397 = inttoptr i64 %v5396 to ptr
  store i32 2, ptr %p5397, align 4, !alias.scope !3, !noalias !4
  %v5398 = load i64, ptr %slot22, align 8
  %p5399 = inttoptr i64 %v5398 to ptr
  store i32 16, ptr %p5399, align 4, !alias.scope !3, !noalias !4
  %v5400 = load i64, ptr %slot21, align 8
  %p5401 = inttoptr i64 %v5400 to ptr
  store i32 1, ptr %p5401, align 4, !alias.scope !3, !noalias !4
  %v5402 = load i64, ptr %slot15, align 8
  %p5403 = inttoptr i64 %v5402 to ptr
  store i32 0, ptr %p5403, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared714
bb_rcprivatenew714:
  %v5404 = load i64, ptr %slot30, align 8
  store i64 %v5404, ptr %slot623, align 8
  %v5405 = load i64, ptr %slot597, align 8
  %p5406 = inttoptr i64 %v5405 to ptr
  %ld5407 = load i64, ptr %p5406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5407, ptr %slot624, align 8
  %v5408 = load i64, ptr %slot624, align 8
  %cmp5409 = icmp ne i64 %v5408, 0
  %cv5410 = zext i1 %cmp5409 to i32
  store i32 %cv5410, ptr %slot625, align 8
  %v5411 = load i32, ptr %slot625, align 8
  %cv5412 = zext i32 %v5411 to i64
  %cond5413 = icmp ne i64 %cv5412, 0
  br i1 %cond5413, label %bb_rcgnn750, label %bb_rcgstore750
bb_rcgnn750:
  %v5414 = load i64, ptr %slot624, align 8
  %op5415 = sub i64 %v5414, 16
  store i64 %op5415, ptr %slot626, align 8
  %v5416 = load i64, ptr %slot624, align 8
  %p5417 = inttoptr i64 %v5416 to ptr
  %rgep5418 = getelementptr i8, ptr %p5417, i64 -16
  %ld5419 = load i64, ptr %rgep5418, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5419, ptr %slot627, align 8
  %v5420 = load i64, ptr %slot627, align 8
  %op5421 = and i64 %v5420, 4611686018427387906
  store i64 %op5421, ptr %slot628, align 8
  %v5422 = load i64, ptr %slot628, align 8
  %cmp5423 = icmp ne i64 %v5422, 0
  %cv5424 = zext i1 %cmp5423 to i32
  store i32 %cv5424, ptr %slot629, align 8
  %v5425 = load i32, ptr %slot629, align 8
  %cv5426 = zext i32 %v5425 to i64
  %cond5427 = icmp ne i64 %cv5426, 0
  br i1 %cond5427, label %bb_rcgstore750, label %bb_rcginc750
bb_rcginc750:
  %v5428 = load i64, ptr %slot624, align 8
  %op5429 = sub i64 %v5428, 24
  store i64 %op5429, ptr %slot630, align 8
  %v5430 = load i64, ptr %slot624, align 8
  %p5431 = inttoptr i64 %v5430 to ptr
  %rgep5432 = getelementptr i8, ptr %p5431, i64 -24
  %ld5433 = load i64, ptr %rgep5432, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5433, ptr %slot631, align 8
  %v5434 = load i64, ptr %slot631, align 8
  %op5435 = add i64 %v5434, 1
  store i64 %op5435, ptr %slot632, align 8
  %v5436 = load i64, ptr %slot632, align 8
  %cmp5437 = icmp eq i64 %v5436, 0
  %cv5438 = zext i1 %cmp5437 to i32
  store i32 %cv5438, ptr %slot633, align 8
  %v5439 = load i32, ptr %slot633, align 8
  %cv5440 = zext i32 %v5439 to i64
  %cond5441 = icmp ne i64 %cv5440, 0
  br i1 %cond5441, label %bb_rcglimit750, label %bb_rcgcapacity750
bb_rcglimit750:
  %v5442 = load i64, ptr %slot1, align 8
  %p5443 = inttoptr i64 %v5442 to ptr
  %call5444 = call i32 @myl_qbe_rc_status(ptr %p5443, i32 2) nomerge, !dbg !146
  store i32 %call5444, ptr %slot634, align 8
  br label %bb_failure
bb_rcgcapacity750:
  %v5445 = load i64, ptr %slot632, align 8
  %v5446 = load i64, ptr %slot624, align 8
  %p5447 = inttoptr i64 %v5446 to ptr
  %rgep5448 = getelementptr i8, ptr %p5447, i64 -24
  store i64 %v5445, ptr %rgep5448, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore750
bb_rcgstore750:
  %v5449 = load i64, ptr %slot624, align 8
  %v5450 = load i64, ptr %slot623, align 8
  %p5451 = inttoptr i64 %v5450 to ptr
  store i64 %v5449, ptr %p5451, align 8, !alias.scope !3, !noalias !4
  %v5452 = load i64, ptr %slot22, align 8
  %p5453 = inttoptr i64 %v5452 to ptr
  store i32 2, ptr %p5453, align 4, !alias.scope !3, !noalias !4
  %v5454 = load i64, ptr %slot22, align 8
  %p5455 = inttoptr i64 %v5454 to ptr
  store i32 16, ptr %p5455, align 4, !alias.scope !3, !noalias !4
  %v5456 = load i64, ptr %slot21, align 8
  %p5457 = inttoptr i64 %v5456 to ptr
  store i32 1, ptr %p5457, align 4, !alias.scope !3, !noalias !4
  %v5458 = load i64, ptr %slot15, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  %ld5460 = load i32, ptr %p5459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5460, ptr %slot635, align 8
  %v5461 = load i32, ptr %slot635, align 8
  %cv5462 = zext i32 %v5461 to i64
  %cond5463 = icmp ne i64 %cv5462, 0
  br i1 %cond5463, label %bb_rcslotdrop766, label %bb_rcslotdone766
bb_rcslotdrop766:
  %v5464 = load i64, ptr %slot15, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i32 0, ptr %p5465, align 4, !alias.scope !3, !noalias !4
  %v5466 = load i64, ptr %slot24, align 8
  store i64 %v5466, ptr %slot636, align 8
  %v5467 = load i64, ptr %slot16, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  %ld5469 = load i32, ptr %p5468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5469, ptr %slot637, align 8
  %v5470 = load i32, ptr %slot637, align 8
  %op5471 = and i32 %v5470, 28
  store i32 %op5471, ptr %slot638, align 8
  %v5472 = load i32, ptr %slot638, align 8
  %cv5473 = zext i32 %v5472 to i64
  %cond5474 = icmp ne i64 %cv5473, 0
  br i1 %cond5474, label %bb_rcslotrole766, label %bb_rcslotowner766
bb_rcslotrole766:
  %v5475 = load i64, ptr %slot99, align 8
  store i64 %v5475, ptr %slot639, align 8
  %v5476 = load i64, ptr %slot636, align 8
  %p5477 = inttoptr i64 %v5476 to ptr
  %ld5478 = load i64, ptr %p5477, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5478, ptr %slot640, align 8
  %v5479 = load i64, ptr %slot640, align 8
  %cmp5480 = icmp ne i64 %v5479, 0
  %cv5481 = zext i1 %cmp5480 to i32
  store i32 %cv5481, ptr %slot641, align 8
  %v5482 = load i32, ptr %slot641, align 8
  %cv5483 = zext i32 %v5482 to i64
  %cond5484 = icmp ne i64 %cv5483, 0
  br i1 %cond5484, label %bb_rcgnn782, label %bb_rcgdone782
bb_rcgnn782:
  %v5485 = load i64, ptr %slot640, align 8
  %op5486 = sub i64 %v5485, 16
  store i64 %op5486, ptr %slot642, align 8
  %v5487 = load i64, ptr %slot640, align 8
  %p5488 = inttoptr i64 %v5487 to ptr
  %rgep5489 = getelementptr i8, ptr %p5488, i64 -16
  %ld5490 = load i64, ptr %rgep5489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5490, ptr %slot643, align 8
  %v5491 = load i64, ptr %slot643, align 8
  %op5492 = and i64 %v5491, 4611686018427387906
  store i64 %op5492, ptr %slot644, align 8
  %v5493 = load i64, ptr %slot644, align 8
  %cmp5494 = icmp ne i64 %v5493, 0
  %cv5495 = zext i1 %cmp5494 to i32
  store i32 %cv5495, ptr %slot645, align 8
  %v5496 = load i32, ptr %slot645, align 8
  %cv5497 = zext i32 %v5496 to i64
  %cond5498 = icmp ne i64 %cv5497, 0
  br i1 %cond5498, label %bb_rcgclear782, label %bb_rcgcounted782
bb_rcgcounted782:
  %v5499 = load i64, ptr %slot640, align 8
  %op5500 = sub i64 %v5499, 24
  store i64 %op5500, ptr %slot646, align 8
  %v5501 = load i64, ptr %slot640, align 8
  %p5502 = inttoptr i64 %v5501 to ptr
  %rgep5503 = getelementptr i8, ptr %p5502, i64 -24
  %ld5504 = load i64, ptr %rgep5503, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5504, ptr %slot647, align 8
  %v5505 = load i64, ptr %slot647, align 8
  %op5506 = sub i64 %v5505, 1
  store i64 %op5506, ptr %slot648, align 8
  %v5507 = load i64, ptr %slot648, align 8
  %cmp5508 = icmp eq i64 %v5507, 0
  %cv5509 = zext i1 %cmp5508 to i32
  store i32 %cv5509, ptr %slot649, align 8
  %v5510 = load i32, ptr %slot649, align 8
  %cv5511 = zext i32 %v5510 to i64
  %cond5512 = icmp ne i64 %cv5511, 0
  br i1 %cond5512, label %bb_rcglast782, label %bb_rcgdec782
bb_rcglast782:
  %v5513 = load i64, ptr %slot640, align 8
  %op5514 = sub i64 %v5513, 32
  store i64 %op5514, ptr %slot650, align 8
  %v5515 = load i64, ptr %slot640, align 8
  %p5516 = inttoptr i64 %v5515 to ptr
  %rgep5517 = getelementptr i8, ptr %p5516, i64 -32
  %ld5518 = load i64, ptr %rgep5517, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5518, ptr %slot651, align 8
  %v5519 = load i64, ptr %slot651, align 8
  %cmp5520 = icmp ne i64 %v5519, 0
  %cv5521 = zext i1 %cmp5520 to i32
  store i32 %cv5521, ptr %slot652, align 8
  %v5522 = load i32, ptr %slot652, align 8
  %cv5523 = zext i32 %v5522 to i64
  %cond5524 = icmp ne i64 %cv5523, 0
  br i1 %cond5524, label %bb_rcgdec782, label %bb_rcgslow782
bb_rcgslow782:
  %v5525 = load i64, ptr %slot639, align 8
  %v5526 = load i64, ptr %slot636, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5525, i64 %v5526) nomerge, !dbg !146
  br label %bb_rcgdone782
bb_rcgdec782:
  %v5527 = load i64, ptr %slot648, align 8
  %v5528 = load i64, ptr %slot640, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  %rgep5530 = getelementptr i8, ptr %p5529, i64 -24
  store i64 %v5527, ptr %rgep5530, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear782
bb_rcgclear782:
  %v5531 = load i64, ptr %slot636, align 8
  %p5532 = inttoptr i64 %v5531 to ptr
  store i64 0, ptr %p5532, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone782
bb_rcgdone782:
  br label %bb_rcslotdone766
bb_rcslotowner766:
  %v5533 = load i64, ptr %slot99, align 8
  store i64 %v5533, ptr %slot653, align 8
  %v5534 = load i64, ptr %slot636, align 8
  %p5535 = inttoptr i64 %v5534 to ptr
  %ld5536 = load i64, ptr %p5535, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5536, ptr %slot654, align 8
  %v5537 = load i64, ptr %slot654, align 8
  %cmp5538 = icmp ne i64 %v5537, 0
  %cv5539 = zext i1 %cmp5538 to i32
  store i32 %cv5539, ptr %slot655, align 8
  %v5540 = load i32, ptr %slot655, align 8
  %cv5541 = zext i32 %v5540 to i64
  %cond5542 = icmp ne i64 %cv5541, 0
  br i1 %cond5542, label %bb_rcgnn797, label %bb_rcgdone797
bb_rcgnn797:
  %v5543 = load i64, ptr %slot654, align 8
  %op5544 = sub i64 %v5543, 16
  store i64 %op5544, ptr %slot656, align 8
  %v5545 = load i64, ptr %slot654, align 8
  %p5546 = inttoptr i64 %v5545 to ptr
  %rgep5547 = getelementptr i8, ptr %p5546, i64 -16
  %ld5548 = load i64, ptr %rgep5547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5548, ptr %slot657, align 8
  %v5549 = load i64, ptr %slot657, align 8
  %op5550 = and i64 %v5549, 4611686018427387906
  store i64 %op5550, ptr %slot658, align 8
  %v5551 = load i64, ptr %slot658, align 8
  %cmp5552 = icmp ne i64 %v5551, 0
  %cv5553 = zext i1 %cmp5552 to i32
  store i32 %cv5553, ptr %slot659, align 8
  %v5554 = load i32, ptr %slot659, align 8
  %cv5555 = zext i32 %v5554 to i64
  %cond5556 = icmp ne i64 %cv5555, 0
  br i1 %cond5556, label %bb_rcgclear797, label %bb_rcgcounted797
bb_rcgcounted797:
  %v5557 = load i64, ptr %slot654, align 8
  %op5558 = sub i64 %v5557, 32
  store i64 %op5558, ptr %slot660, align 8
  %v5559 = load i64, ptr %slot654, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  %rgep5561 = getelementptr i8, ptr %p5560, i64 -32
  %ld5562 = load i64, ptr %rgep5561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5562, ptr %slot661, align 8
  %v5563 = load i64, ptr %slot661, align 8
  %op5564 = sub i64 %v5563, 1
  store i64 %op5564, ptr %slot662, align 8
  %v5565 = load i64, ptr %slot662, align 8
  %cmp5566 = icmp eq i64 %v5565, 0
  %cv5567 = zext i1 %cmp5566 to i32
  store i32 %cv5567, ptr %slot663, align 8
  %v5568 = load i32, ptr %slot663, align 8
  %cv5569 = zext i32 %v5568 to i64
  %cond5570 = icmp ne i64 %cv5569, 0
  br i1 %cond5570, label %bb_rcglast797, label %bb_rcgdec797
bb_rcglast797:
  %v5571 = load i64, ptr %slot654, align 8
  %op5572 = sub i64 %v5571, 24
  store i64 %op5572, ptr %slot664, align 8
  %v5573 = load i64, ptr %slot654, align 8
  %p5574 = inttoptr i64 %v5573 to ptr
  %rgep5575 = getelementptr i8, ptr %p5574, i64 -24
  %ld5576 = load i64, ptr %rgep5575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5576, ptr %slot665, align 8
  %v5577 = load i64, ptr %slot665, align 8
  %cmp5578 = icmp ne i64 %v5577, 0
  %cv5579 = zext i1 %cmp5578 to i32
  store i32 %cv5579, ptr %slot666, align 8
  %v5580 = load i32, ptr %slot666, align 8
  %cv5581 = zext i32 %v5580 to i64
  %cond5582 = icmp ne i64 %cv5581, 0
  br i1 %cond5582, label %bb_rcgdec797, label %bb_rcgslow797
bb_rcgslow797:
  %v5583 = load i64, ptr %slot653, align 8
  %v5584 = load i64, ptr %slot636, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5583, i64 %v5584) nomerge, !dbg !146
  br label %bb_rcgdone797
bb_rcgdec797:
  %v5585 = load i64, ptr %slot662, align 8
  %v5586 = load i64, ptr %slot654, align 8
  %p5587 = inttoptr i64 %v5586 to ptr
  %rgep5588 = getelementptr i8, ptr %p5587, i64 -32
  store i64 %v5585, ptr %rgep5588, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear797
bb_rcgclear797:
  %v5589 = load i64, ptr %slot636, align 8
  %p5590 = inttoptr i64 %v5589 to ptr
  store i64 0, ptr %p5590, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone797
bb_rcgdone797:
  br label %bb_rcslotdone766
bb_rcslotdone766:
  br label %bb_rcprivateprepared714
bb_rcprivateprepared714:
  %v5591 = load i64, ptr %slot7, align 8
  %p5592 = inttoptr i64 %v5591 to ptr
  %ld5593 = load i32, ptr %p5592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5593, ptr %slot667, align 8
  %v5594 = load i32, ptr %slot667, align 8
  %cv5595 = zext i32 %v5594 to i64
  %cond5596 = icmp ne i64 %cv5595, 0
  br i1 %cond5596, label %bb_rcslotdrop804, label %bb_rcslotdone804
bb_rcslotdrop804:
  %v5597 = load i64, ptr %slot7, align 8
  %p5598 = inttoptr i64 %v5597 to ptr
  store i32 0, ptr %p5598, align 4, !alias.scope !3, !noalias !4
  %v5599 = load i64, ptr %slot34, align 8
  store i64 %v5599, ptr %slot668, align 8
  %v5600 = load i64, ptr %slot8, align 8
  %p5601 = inttoptr i64 %v5600 to ptr
  %ld5602 = load i32, ptr %p5601, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5602, ptr %slot669, align 8
  %v5603 = load i32, ptr %slot669, align 8
  %op5604 = and i32 %v5603, 28
  store i32 %op5604, ptr %slot670, align 8
  %v5605 = load i32, ptr %slot670, align 8
  %cv5606 = zext i32 %v5605 to i64
  %cond5607 = icmp ne i64 %cv5606, 0
  br i1 %cond5607, label %bb_rcslotrole804, label %bb_rcslotowner804
bb_rcslotrole804:
  %v5608 = load i64, ptr %slot99, align 8
  store i64 %v5608, ptr %slot671, align 8
  %v5609 = load i64, ptr %slot668, align 8
  %p5610 = inttoptr i64 %v5609 to ptr
  %ld5611 = load i64, ptr %p5610, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5611, ptr %slot672, align 8
  %v5612 = load i64, ptr %slot672, align 8
  %cmp5613 = icmp ne i64 %v5612, 0
  %cv5614 = zext i1 %cmp5613 to i32
  store i32 %cv5614, ptr %slot673, align 8
  %v5615 = load i32, ptr %slot673, align 8
  %cv5616 = zext i32 %v5615 to i64
  %cond5617 = icmp ne i64 %cv5616, 0
  br i1 %cond5617, label %bb_rcgnn820, label %bb_rcgdone820
bb_rcgnn820:
  %v5618 = load i64, ptr %slot672, align 8
  %op5619 = sub i64 %v5618, 16
  store i64 %op5619, ptr %slot674, align 8
  %v5620 = load i64, ptr %slot672, align 8
  %p5621 = inttoptr i64 %v5620 to ptr
  %rgep5622 = getelementptr i8, ptr %p5621, i64 -16
  %ld5623 = load i64, ptr %rgep5622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5623, ptr %slot675, align 8
  %v5624 = load i64, ptr %slot675, align 8
  %op5625 = and i64 %v5624, 4611686018427387906
  store i64 %op5625, ptr %slot676, align 8
  %v5626 = load i64, ptr %slot676, align 8
  %cmp5627 = icmp ne i64 %v5626, 0
  %cv5628 = zext i1 %cmp5627 to i32
  store i32 %cv5628, ptr %slot677, align 8
  %v5629 = load i32, ptr %slot677, align 8
  %cv5630 = zext i32 %v5629 to i64
  %cond5631 = icmp ne i64 %cv5630, 0
  br i1 %cond5631, label %bb_rcgclear820, label %bb_rcgcounted820
bb_rcgcounted820:
  %v5632 = load i64, ptr %slot672, align 8
  %op5633 = sub i64 %v5632, 24
  store i64 %op5633, ptr %slot678, align 8
  %v5634 = load i64, ptr %slot672, align 8
  %p5635 = inttoptr i64 %v5634 to ptr
  %rgep5636 = getelementptr i8, ptr %p5635, i64 -24
  %ld5637 = load i64, ptr %rgep5636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5637, ptr %slot679, align 8
  %v5638 = load i64, ptr %slot679, align 8
  %op5639 = sub i64 %v5638, 1
  store i64 %op5639, ptr %slot680, align 8
  %v5640 = load i64, ptr %slot680, align 8
  %cmp5641 = icmp eq i64 %v5640, 0
  %cv5642 = zext i1 %cmp5641 to i32
  store i32 %cv5642, ptr %slot681, align 8
  %v5643 = load i32, ptr %slot681, align 8
  %cv5644 = zext i32 %v5643 to i64
  %cond5645 = icmp ne i64 %cv5644, 0
  br i1 %cond5645, label %bb_rcglast820, label %bb_rcgdec820
bb_rcglast820:
  %v5646 = load i64, ptr %slot672, align 8
  %op5647 = sub i64 %v5646, 32
  store i64 %op5647, ptr %slot682, align 8
  %v5648 = load i64, ptr %slot672, align 8
  %p5649 = inttoptr i64 %v5648 to ptr
  %rgep5650 = getelementptr i8, ptr %p5649, i64 -32
  %ld5651 = load i64, ptr %rgep5650, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5651, ptr %slot683, align 8
  %v5652 = load i64, ptr %slot683, align 8
  %cmp5653 = icmp ne i64 %v5652, 0
  %cv5654 = zext i1 %cmp5653 to i32
  store i32 %cv5654, ptr %slot684, align 8
  %v5655 = load i32, ptr %slot684, align 8
  %cv5656 = zext i32 %v5655 to i64
  %cond5657 = icmp ne i64 %cv5656, 0
  br i1 %cond5657, label %bb_rcgdec820, label %bb_rcgslow820
bb_rcgslow820:
  %v5658 = load i64, ptr %slot671, align 8
  %v5659 = load i64, ptr %slot668, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5658, i64 %v5659) nomerge, !dbg !146
  br label %bb_rcgdone820
bb_rcgdec820:
  %v5660 = load i64, ptr %slot680, align 8
  %v5661 = load i64, ptr %slot672, align 8
  %p5662 = inttoptr i64 %v5661 to ptr
  %rgep5663 = getelementptr i8, ptr %p5662, i64 -24
  store i64 %v5660, ptr %rgep5663, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear820
bb_rcgclear820:
  %v5664 = load i64, ptr %slot668, align 8
  %p5665 = inttoptr i64 %v5664 to ptr
  store i64 0, ptr %p5665, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone820
bb_rcgdone820:
  br label %bb_rcslotdone804
bb_rcslotowner804:
  %v5666 = load i64, ptr %slot99, align 8
  store i64 %v5666, ptr %slot685, align 8
  %v5667 = load i64, ptr %slot668, align 8
  %p5668 = inttoptr i64 %v5667 to ptr
  %ld5669 = load i64, ptr %p5668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5669, ptr %slot686, align 8
  %v5670 = load i64, ptr %slot686, align 8
  %cmp5671 = icmp ne i64 %v5670, 0
  %cv5672 = zext i1 %cmp5671 to i32
  store i32 %cv5672, ptr %slot687, align 8
  %v5673 = load i32, ptr %slot687, align 8
  %cv5674 = zext i32 %v5673 to i64
  %cond5675 = icmp ne i64 %cv5674, 0
  br i1 %cond5675, label %bb_rcgnn835, label %bb_rcgdone835
bb_rcgnn835:
  %v5676 = load i64, ptr %slot686, align 8
  %op5677 = sub i64 %v5676, 16
  store i64 %op5677, ptr %slot688, align 8
  %v5678 = load i64, ptr %slot686, align 8
  %p5679 = inttoptr i64 %v5678 to ptr
  %rgep5680 = getelementptr i8, ptr %p5679, i64 -16
  %ld5681 = load i64, ptr %rgep5680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5681, ptr %slot689, align 8
  %v5682 = load i64, ptr %slot689, align 8
  %op5683 = and i64 %v5682, 4611686018427387906
  store i64 %op5683, ptr %slot690, align 8
  %v5684 = load i64, ptr %slot690, align 8
  %cmp5685 = icmp ne i64 %v5684, 0
  %cv5686 = zext i1 %cmp5685 to i32
  store i32 %cv5686, ptr %slot691, align 8
  %v5687 = load i32, ptr %slot691, align 8
  %cv5688 = zext i32 %v5687 to i64
  %cond5689 = icmp ne i64 %cv5688, 0
  br i1 %cond5689, label %bb_rcgclear835, label %bb_rcgcounted835
bb_rcgcounted835:
  %v5690 = load i64, ptr %slot686, align 8
  %op5691 = sub i64 %v5690, 32
  store i64 %op5691, ptr %slot692, align 8
  %v5692 = load i64, ptr %slot686, align 8
  %p5693 = inttoptr i64 %v5692 to ptr
  %rgep5694 = getelementptr i8, ptr %p5693, i64 -32
  %ld5695 = load i64, ptr %rgep5694, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5695, ptr %slot693, align 8
  %v5696 = load i64, ptr %slot693, align 8
  %op5697 = sub i64 %v5696, 1
  store i64 %op5697, ptr %slot694, align 8
  %v5698 = load i64, ptr %slot694, align 8
  %cmp5699 = icmp eq i64 %v5698, 0
  %cv5700 = zext i1 %cmp5699 to i32
  store i32 %cv5700, ptr %slot695, align 8
  %v5701 = load i32, ptr %slot695, align 8
  %cv5702 = zext i32 %v5701 to i64
  %cond5703 = icmp ne i64 %cv5702, 0
  br i1 %cond5703, label %bb_rcglast835, label %bb_rcgdec835
bb_rcglast835:
  %v5704 = load i64, ptr %slot686, align 8
  %op5705 = sub i64 %v5704, 24
  store i64 %op5705, ptr %slot696, align 8
  %v5706 = load i64, ptr %slot686, align 8
  %p5707 = inttoptr i64 %v5706 to ptr
  %rgep5708 = getelementptr i8, ptr %p5707, i64 -24
  %ld5709 = load i64, ptr %rgep5708, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5709, ptr %slot697, align 8
  %v5710 = load i64, ptr %slot697, align 8
  %cmp5711 = icmp ne i64 %v5710, 0
  %cv5712 = zext i1 %cmp5711 to i32
  store i32 %cv5712, ptr %slot698, align 8
  %v5713 = load i32, ptr %slot698, align 8
  %cv5714 = zext i32 %v5713 to i64
  %cond5715 = icmp ne i64 %cv5714, 0
  br i1 %cond5715, label %bb_rcgdec835, label %bb_rcgslow835
bb_rcgslow835:
  %v5716 = load i64, ptr %slot685, align 8
  %v5717 = load i64, ptr %slot668, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5716, i64 %v5717) nomerge, !dbg !146
  br label %bb_rcgdone835
bb_rcgdec835:
  %v5718 = load i64, ptr %slot694, align 8
  %v5719 = load i64, ptr %slot686, align 8
  %p5720 = inttoptr i64 %v5719 to ptr
  %rgep5721 = getelementptr i8, ptr %p5720, i64 -32
  store i64 %v5718, ptr %rgep5721, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear835
bb_rcgclear835:
  %v5722 = load i64, ptr %slot668, align 8
  %p5723 = inttoptr i64 %v5722 to ptr
  store i64 0, ptr %p5723, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone835
bb_rcgdone835:
  br label %bb_rcslotdone804
bb_rcslotdone804:
  %v5724 = load i64, ptr %slot34, align 8
  store i64 %v5724, ptr %slot699, align 8
  %v5725 = load i64, ptr %slot30, align 8
  store i64 %v5725, ptr %slot700, align 8
  %v5726 = load i64, ptr %slot700, align 8
  %v5727 = load i64, ptr %slot699, align 8
  %p5728 = inttoptr i64 %v5726 to ptr
  %p5729 = inttoptr i64 %v5727 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5729, ptr %p5728, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5730 = load i64, ptr %slot21, align 8
  %p5731 = inttoptr i64 %v5730 to ptr
  store i32 0, ptr %p5731, align 4, !alias.scope !3, !noalias !4
  %v5732 = load i64, ptr %slot8, align 8
  %p5733 = inttoptr i64 %v5732 to ptr
  store i32 2, ptr %p5733, align 4, !alias.scope !3, !noalias !4
  %v5734 = load i64, ptr %slot22, align 8
  %p5735 = inttoptr i64 %v5734 to ptr
  %ld5736 = load i32, ptr %p5735, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5736, ptr %slot701, align 8
  %v5737 = load i32, ptr %slot701, align 8
  %v5738 = load i64, ptr %slot8, align 8
  %p5739 = inttoptr i64 %v5738 to ptr
  store i32 %v5737, ptr %p5739, align 4, !alias.scope !3, !noalias !4
  %v5740 = load i64, ptr %slot7, align 8
  %p5741 = inttoptr i64 %v5740 to ptr
  store i32 1, ptr %p5741, align 4, !alias.scope !3, !noalias !4
  %v5742 = load i64, ptr %slot33, align 8
  %v5743 = load i64, ptr %slot44, align 8
  %p5744 = inttoptr i64 %v5743 to ptr
  store i64 %v5742, ptr %p5744, align 8, !alias.scope !3, !noalias !4
  %v5745 = load i64, ptr %slot44, align 8
  %p5746 = inttoptr i64 %v5745 to ptr
  %ld5747 = load i64, ptr %p5746, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5747, ptr %slot702, align 8
  %v5748 = load i64, ptr %slot702, align 8
  %op5749 = add i64 %v5748, 8
  store i64 %op5749, ptr %slot703, align 8
  %v5750 = load i64, ptr %slot703, align 8
  %p5751 = inttoptr i64 %v5750 to ptr
  %ld5752 = load i64, ptr %p5751, align 8
  store i64 %ld5752, ptr %slot704, align 8
  %v5753 = load i64, ptr %slot704, align 8
  %v5754 = load i64, ptr %slot44, align 8
  %p5755 = inttoptr i64 %v5754 to ptr
  store i64 %v5753, ptr %p5755, align 8, !alias.scope !3, !noalias !4
  %v5756 = load i64, ptr %slot15, align 8
  %p5757 = inttoptr i64 %v5756 to ptr
  %ld5758 = load i32, ptr %p5757, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5758, ptr %slot705, align 8
  %v5759 = load i32, ptr %slot705, align 8
  %cv5760 = zext i32 %v5759 to i64
  %cond5761 = icmp ne i64 %cv5760, 0
  br i1 %cond5761, label %bb_rcslotdrop851, label %bb_rcslotdone851
bb_rcslotdrop851:
  %v5762 = load i64, ptr %slot15, align 8
  %p5763 = inttoptr i64 %v5762 to ptr
  store i32 0, ptr %p5763, align 4, !alias.scope !3, !noalias !4
  %v5764 = load i64, ptr %slot24, align 8
  store i64 %v5764, ptr %slot706, align 8
  %v5765 = load i64, ptr %slot16, align 8
  %p5766 = inttoptr i64 %v5765 to ptr
  %ld5767 = load i32, ptr %p5766, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5767, ptr %slot707, align 8
  %v5768 = load i32, ptr %slot707, align 8
  %op5769 = and i32 %v5768, 28
  store i32 %op5769, ptr %slot708, align 8
  %v5770 = load i32, ptr %slot708, align 8
  %cv5771 = zext i32 %v5770 to i64
  %cond5772 = icmp ne i64 %cv5771, 0
  br i1 %cond5772, label %bb_rcslotrole851, label %bb_rcslotowner851
bb_rcslotrole851:
  %v5773 = load i64, ptr %slot99, align 8
  store i64 %v5773, ptr %slot709, align 8
  %v5774 = load i64, ptr %slot709, align 8
  %v5775 = load i64, ptr %slot706, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v5774, i64 %v5775) nomerge, !dbg !148
  br label %bb_rcslotdone851
bb_rcslotowner851:
  %v5776 = load i64, ptr %slot99, align 8
  store i64 %v5776, ptr %slot710, align 8
  %v5777 = load i64, ptr %slot710, align 8
  %v5778 = load i64, ptr %slot706, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v5777, i64 %v5778) nomerge, !dbg !148
  br label %bb_rcslotdone851
bb_rcslotdone851:
  %v5779 = load i64, ptr %slot33, align 8
  %v5780 = load i64, ptr %slot45, align 8
  %p5781 = inttoptr i64 %v5780 to ptr
  store i64 %v5779, ptr %p5781, align 8, !alias.scope !3, !noalias !4
  %v5782 = load i64, ptr %slot45, align 8
  %p5783 = inttoptr i64 %v5782 to ptr
  %ld5784 = load i64, ptr %p5783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5784, ptr %slot711, align 8
  %v5785 = load i64, ptr %slot711, align 8
  %op5786 = add i64 %v5785, 8
  store i64 %op5786, ptr %slot712, align 8
  %v5787 = load i64, ptr %slot712, align 8
  %p5788 = inttoptr i64 %v5787 to ptr
  %ld5789 = load i64, ptr %p5788, align 8
  store i64 %ld5789, ptr %slot713, align 8
  %v5790 = load i64, ptr %slot713, align 8
  %v5791 = load i64, ptr %slot45, align 8
  %p5792 = inttoptr i64 %v5791 to ptr
  store i64 %v5790, ptr %p5792, align 8, !alias.scope !3, !noalias !4
  %v5793 = load i64, ptr %slot17, align 8
  %p5794 = inttoptr i64 %v5793 to ptr
  %ld5795 = load i32, ptr %p5794, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5795, ptr %slot714, align 8
  %v5796 = load i32, ptr %slot714, align 8
  %cv5797 = zext i32 %v5796 to i64
  %cond5798 = icmp ne i64 %cv5797, 0
  br i1 %cond5798, label %bb_rcslotdrop863, label %bb_rcslotdone863
bb_rcslotdrop863:
  %v5799 = load i64, ptr %slot17, align 8
  %p5800 = inttoptr i64 %v5799 to ptr
  store i32 0, ptr %p5800, align 4, !alias.scope !3, !noalias !4
  %v5801 = load i64, ptr %slot25, align 8
  store i64 %v5801, ptr %slot715, align 8
  %v5802 = load i64, ptr %slot18, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  %ld5804 = load i32, ptr %p5803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5804, ptr %slot716, align 8
  %v5805 = load i32, ptr %slot716, align 8
  %op5806 = and i32 %v5805, 28
  store i32 %op5806, ptr %slot717, align 8
  %v5807 = load i32, ptr %slot717, align 8
  %cv5808 = zext i32 %v5807 to i64
  %cond5809 = icmp ne i64 %cv5808, 0
  br i1 %cond5809, label %bb_rcslotrole863, label %bb_rcslotowner863
bb_rcslotrole863:
  %v5810 = load i64, ptr %slot99, align 8
  store i64 %v5810, ptr %slot718, align 8
  %v5811 = load i64, ptr %slot718, align 8
  %v5812 = load i64, ptr %slot715, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v5811, i64 %v5812) nomerge, !dbg !150
  br label %bb_rcslotdone863
bb_rcslotowner863:
  %v5813 = load i64, ptr %slot99, align 8
  store i64 %v5813, ptr %slot719, align 8
  %v5814 = load i64, ptr %slot719, align 8
  %v5815 = load i64, ptr %slot715, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v5814, i64 %v5815) nomerge, !dbg !150
  br label %bb_rcslotdone863
bb_rcslotdone863:
  %v5816 = load i64, ptr %slot33, align 8
  %v5817 = load i64, ptr %slot46, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  store i64 %v5816, ptr %p5818, align 8, !alias.scope !3, !noalias !4
  %v5819 = load i64, ptr %slot46, align 8
  %p5820 = inttoptr i64 %v5819 to ptr
  %ld5821 = load i64, ptr %p5820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5821, ptr %slot720, align 8
  %v5822 = load i64, ptr %slot720, align 8
  %op5823 = add i64 %v5822, 16
  store i64 %op5823, ptr %slot721, align 8
  %v5824 = load i64, ptr %slot721, align 8
  %p5825 = inttoptr i64 %v5824 to ptr
  %ld5826 = load i64, ptr %p5825, align 8
  store i64 %ld5826, ptr %slot722, align 8
  %v5827 = load i64, ptr %slot722, align 8
  %v5828 = load i64, ptr %slot46, align 8
  %p5829 = inttoptr i64 %v5828 to ptr
  store i64 %v5827, ptr %p5829, align 8, !alias.scope !3, !noalias !4
  %v5830 = load i64, ptr %slot19, align 8
  %p5831 = inttoptr i64 %v5830 to ptr
  %ld5832 = load i32, ptr %p5831, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5832, ptr %slot723, align 8
  %v5833 = load i32, ptr %slot723, align 8
  %cv5834 = zext i32 %v5833 to i64
  %cond5835 = icmp ne i64 %cv5834, 0
  br i1 %cond5835, label %bb_rcslotdrop875, label %bb_rcslotdone875
bb_rcslotdrop875:
  %v5836 = load i64, ptr %slot19, align 8
  %p5837 = inttoptr i64 %v5836 to ptr
  store i32 0, ptr %p5837, align 4, !alias.scope !3, !noalias !4
  %v5838 = load i64, ptr %slot26, align 8
  store i64 %v5838, ptr %slot724, align 8
  %v5839 = load i64, ptr %slot20, align 8
  %p5840 = inttoptr i64 %v5839 to ptr
  %ld5841 = load i32, ptr %p5840, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5841, ptr %slot725, align 8
  %v5842 = load i32, ptr %slot725, align 8
  %op5843 = and i32 %v5842, 28
  store i32 %op5843, ptr %slot726, align 8
  %v5844 = load i32, ptr %slot726, align 8
  %cv5845 = zext i32 %v5844 to i64
  %cond5846 = icmp ne i64 %cv5845, 0
  br i1 %cond5846, label %bb_rcslotrole875, label %bb_rcslotowner875
bb_rcslotrole875:
  %v5847 = load i64, ptr %slot99, align 8
  store i64 %v5847, ptr %slot727, align 8
  %v5848 = load i64, ptr %slot727, align 8
  %v5849 = load i64, ptr %slot724, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v5848, i64 %v5849) nomerge, !dbg !152
  br label %bb_rcslotdone875
bb_rcslotowner875:
  %v5850 = load i64, ptr %slot99, align 8
  store i64 %v5850, ptr %slot728, align 8
  %v5851 = load i64, ptr %slot728, align 8
  %v5852 = load i64, ptr %slot724, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v5851, i64 %v5852) nomerge, !dbg !152
  br label %bb_rcslotdone875
bb_rcslotdone875:
  %v5853 = load i64, ptr %slot46, align 8
  %p5854 = inttoptr i64 %v5853 to ptr
  %ld5855 = load i64, ptr %p5854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5855, ptr %slot729, align 8
  %v5856 = load i64, ptr %slot45, align 8
  %p5857 = inttoptr i64 %v5856 to ptr
  %ld5858 = load i64, ptr %p5857, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5858, ptr %slot730, align 8
  %v5859 = load i64, ptr %slot730, align 8
  %v5860 = load i64, ptr %slot729, align 8
  %ovpair5862 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v5859, i64 %v5860)
  %op5861 = extractvalue { i64, i1 } %ovpair5862, 0
  %ov5863 = extractvalue { i64, i1 } %ovpair5862, 1
  store i64 %op5861, ptr %slot731, align 8
  %v5864 = load i64, ptr %slot730, align 8
  %v5865 = load i64, ptr %slot731, align 8
  %op5866 = xor i64 %v5864, %v5865
  store i64 %op5866, ptr %slot732, align 8
  %v5867 = load i64, ptr %slot729, align 8
  %v5868 = load i64, ptr %slot731, align 8
  %op5869 = xor i64 %v5867, %v5868
  store i64 %op5869, ptr %slot733, align 8
  %v5870 = load i64, ptr %slot732, align 8
  %v5871 = load i64, ptr %slot733, align 8
  %op5872 = and i64 %v5870, %v5871
  store i64 %op5872, ptr %slot734, align 8
  %cv5873 = zext i1 %ov5863 to i64
  store i64 %cv5873, ptr %slot735, align 8
  %v5874 = load i64, ptr %slot735, align 8
  %cond5875 = icmp ne i64 %v5874, 0
  br i1 %cond5875, label %bb_overflow884, label %bb_checked884
bb_overflow884:
  %v5876 = load i64, ptr %slot1, align 8
  %p5877 = inttoptr i64 %v5876 to ptr
  %v5878 = load i64, ptr %slot730, align 8
  %v5879 = load i64, ptr %slot729, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5877, i64 0, i64 %v5878, i64 %v5879, i64 64) nomerge, !dbg !154
  unreachable
bb_checked884:
  %v5880 = load i64, ptr %slot731, align 8
  %v5881 = load i64, ptr %slot45, align 8
  %p5882 = inttoptr i64 %v5881 to ptr
  store i64 %v5880, ptr %p5882, align 8, !alias.scope !3, !noalias !4
  %v5883 = load i64, ptr %slot34, align 8
  %p5884 = inttoptr i64 %v5883 to ptr
  %ld5885 = load i64, ptr %p5884, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5885, ptr %slot736, align 8
  %v5886 = load i64, ptr %slot44, align 8
  %p5887 = inttoptr i64 %v5886 to ptr
  %ld5888 = load i64, ptr %p5887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5888, ptr %slot737, align 8
  %v5889 = load i64, ptr %slot45, align 8
  %p5890 = inttoptr i64 %v5889 to ptr
  %ld5891 = load i64, ptr %p5890, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5891, ptr %slot738, align 8
  %v5892 = load i64, ptr %slot736, align 8
  %p5893 = inttoptr i64 %v5892 to ptr
  %v5894 = load i64, ptr %slot737, align 8
  %v5895 = load i64, ptr %slot738, align 8
  %v5896 = load i64, ptr %slot31, align 8
  %p5897 = inttoptr i64 %v5896 to ptr
  %call5898 = call ptr @myl_native_bytes_range(ptr %p5893, i64 %v5894, i64 %v5895, ptr %p5897) nomerge, !dbg !156
  %calladdr5899 = ptrtoint ptr %call5898 to i64
  store i64 %calladdr5899, ptr %slot739, align 8
  %v5900 = load i64, ptr %slot31, align 8
  %p5901 = inttoptr i64 %v5900 to ptr
  %ld5902 = load i64, ptr %p5901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5902, ptr %slot740, align 8
  %v5903 = load i64, ptr %slot739, align 8
  %p5904 = inttoptr i64 %v5903 to ptr
  %v5905 = load i64, ptr %slot740, align 8
  %v5906 = load i64, ptr %slot31, align 8
  %p5907 = inttoptr i64 %v5906 to ptr
  %call5908 = call i32 @myl_native_bytes_number_parse(ptr %p5904, i64 %v5905, i32 1, ptr %p5907) nomerge, !dbg !156
  store i32 %call5908, ptr %slot741, align 8
  %v5909 = load i64, ptr %slot31, align 8
  %p5910 = inttoptr i64 %v5909 to ptr
  %ld5911 = load i64, ptr %p5910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5911, ptr %slot742, align 8
  %v5912 = load i64, ptr %slot97, align 8
  store i64 %v5912, ptr %slot743, align 8
  %v5913 = load i64, ptr %slot743, align 8
  %p5915 = inttoptr i64 %v5913 to ptr
  %gep5916 = getelementptr i8, ptr %p5915, i64 8
  %op5914 = ptrtoint ptr %gep5916 to i64
  store i64 %op5914, ptr %slot744, align 8
  %v5917 = load i32, ptr %slot741, align 8
  %cv5918 = zext i32 %v5917 to i64
  %cond5919 = icmp ne i64 %cv5918, 0
  br i1 %cond5919, label %bb_some899, label %bb_none899
bb_some899:
  %v5920 = load i64, ptr %slot743, align 8
  %p5921 = inttoptr i64 %v5920 to ptr
  store i32 1, ptr %p5921, align 4, !alias.scope !3, !noalias !4
  %v5922 = load i64, ptr %slot742, align 8
  %v5923 = load i64, ptr %slot744, align 8
  %p5924 = inttoptr i64 %v5923 to ptr
  store i64 %v5922, ptr %p5924, align 8, !alias.scope !3, !noalias !4
  br label %bb_parsed899
bb_none899:
  %v5925 = load i64, ptr %slot743, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  store i32 0, ptr %p5926, align 4, !alias.scope !3, !noalias !4
  br label %bb_parsed899
bb_parsed899:
  %v5927 = load i64, ptr %slot743, align 8
  %v5928 = load i64, ptr %slot44, align 8
  %p5929 = inttoptr i64 %v5928 to ptr
  store i64 %v5927, ptr %p5929, align 8, !alias.scope !3, !noalias !4
  %v5930 = load i64, ptr %slot44, align 8
  %p5931 = inttoptr i64 %v5930 to ptr
  %ld5932 = load i64, ptr %p5931, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5932, ptr %slot745, align 8
  %v5933 = load i64, ptr %slot745, align 8
  %v5934 = load i64, ptr %slot35, align 8
  %p5935 = inttoptr i64 %v5933 to ptr
  %p5936 = inttoptr i64 %v5934 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5936, ptr %p5935, i64 16, i1 false)
  %v5937 = load i64, ptr %slot7, align 8
  %p5938 = inttoptr i64 %v5937 to ptr
  %ld5939 = load i32, ptr %p5938, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5939, ptr %slot746, align 8
  %v5940 = load i32, ptr %slot746, align 8
  %cv5941 = zext i32 %v5940 to i64
  %cond5942 = icmp ne i64 %cv5941, 0
  br i1 %cond5942, label %bb_rcslotdrop903, label %bb_rcslotdone903
bb_rcslotdrop903:
  %v5943 = load i64, ptr %slot7, align 8
  %p5944 = inttoptr i64 %v5943 to ptr
  store i32 0, ptr %p5944, align 4, !alias.scope !3, !noalias !4
  %v5945 = load i64, ptr %slot34, align 8
  store i64 %v5945, ptr %slot747, align 8
  %v5946 = load i64, ptr %slot8, align 8
  %p5947 = inttoptr i64 %v5946 to ptr
  %ld5948 = load i32, ptr %p5947, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5948, ptr %slot748, align 8
  %v5949 = load i32, ptr %slot748, align 8
  %op5950 = and i32 %v5949, 28
  store i32 %op5950, ptr %slot749, align 8
  %v5951 = load i32, ptr %slot749, align 8
  %cv5952 = zext i32 %v5951 to i64
  %cond5953 = icmp ne i64 %cv5952, 0
  br i1 %cond5953, label %bb_rcslotrole903, label %bb_rcslotowner903
bb_rcslotrole903:
  %v5954 = load i64, ptr %slot99, align 8
  store i64 %v5954, ptr %slot750, align 8
  %v5955 = load i64, ptr %slot747, align 8
  %p5956 = inttoptr i64 %v5955 to ptr
  %ld5957 = load i64, ptr %p5956, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5957, ptr %slot751, align 8
  %v5958 = load i64, ptr %slot751, align 8
  %cmp5959 = icmp ne i64 %v5958, 0
  %cv5960 = zext i1 %cmp5959 to i32
  store i32 %cv5960, ptr %slot752, align 8
  %v5961 = load i32, ptr %slot752, align 8
  %cv5962 = zext i32 %v5961 to i64
  %cond5963 = icmp ne i64 %cv5962, 0
  br i1 %cond5963, label %bb_rcgnn919, label %bb_rcgdone919
bb_rcgnn919:
  %v5964 = load i64, ptr %slot751, align 8
  %op5965 = sub i64 %v5964, 16
  store i64 %op5965, ptr %slot753, align 8
  %v5966 = load i64, ptr %slot751, align 8
  %p5967 = inttoptr i64 %v5966 to ptr
  %rgep5968 = getelementptr i8, ptr %p5967, i64 -16
  %ld5969 = load i64, ptr %rgep5968, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5969, ptr %slot754, align 8
  %v5970 = load i64, ptr %slot754, align 8
  %op5971 = and i64 %v5970, 4611686018427387906
  store i64 %op5971, ptr %slot755, align 8
  %v5972 = load i64, ptr %slot755, align 8
  %cmp5973 = icmp ne i64 %v5972, 0
  %cv5974 = zext i1 %cmp5973 to i32
  store i32 %cv5974, ptr %slot756, align 8
  %v5975 = load i32, ptr %slot756, align 8
  %cv5976 = zext i32 %v5975 to i64
  %cond5977 = icmp ne i64 %cv5976, 0
  br i1 %cond5977, label %bb_rcgclear919, label %bb_rcgcounted919
bb_rcgcounted919:
  %v5978 = load i64, ptr %slot751, align 8
  %op5979 = sub i64 %v5978, 24
  store i64 %op5979, ptr %slot757, align 8
  %v5980 = load i64, ptr %slot751, align 8
  %p5981 = inttoptr i64 %v5980 to ptr
  %rgep5982 = getelementptr i8, ptr %p5981, i64 -24
  %ld5983 = load i64, ptr %rgep5982, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5983, ptr %slot758, align 8
  %v5984 = load i64, ptr %slot758, align 8
  %op5985 = sub i64 %v5984, 1
  store i64 %op5985, ptr %slot759, align 8
  %v5986 = load i64, ptr %slot759, align 8
  %cmp5987 = icmp eq i64 %v5986, 0
  %cv5988 = zext i1 %cmp5987 to i32
  store i32 %cv5988, ptr %slot760, align 8
  %v5989 = load i32, ptr %slot760, align 8
  %cv5990 = zext i32 %v5989 to i64
  %cond5991 = icmp ne i64 %cv5990, 0
  br i1 %cond5991, label %bb_rcglast919, label %bb_rcgdec919
bb_rcglast919:
  %v5992 = load i64, ptr %slot751, align 8
  %op5993 = sub i64 %v5992, 32
  store i64 %op5993, ptr %slot761, align 8
  %v5994 = load i64, ptr %slot751, align 8
  %p5995 = inttoptr i64 %v5994 to ptr
  %rgep5996 = getelementptr i8, ptr %p5995, i64 -32
  %ld5997 = load i64, ptr %rgep5996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5997, ptr %slot762, align 8
  %v5998 = load i64, ptr %slot762, align 8
  %cmp5999 = icmp ne i64 %v5998, 0
  %cv6000 = zext i1 %cmp5999 to i32
  store i32 %cv6000, ptr %slot763, align 8
  %v6001 = load i32, ptr %slot763, align 8
  %cv6002 = zext i32 %v6001 to i64
  %cond6003 = icmp ne i64 %cv6002, 0
  br i1 %cond6003, label %bb_rcgdec919, label %bb_rcgslow919
bb_rcgslow919:
  %v6004 = load i64, ptr %slot750, align 8
  %v6005 = load i64, ptr %slot747, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6004, i64 %v6005) nomerge, !dbg !158
  br label %bb_rcgdone919
bb_rcgdec919:
  %v6006 = load i64, ptr %slot759, align 8
  %v6007 = load i64, ptr %slot751, align 8
  %p6008 = inttoptr i64 %v6007 to ptr
  %rgep6009 = getelementptr i8, ptr %p6008, i64 -24
  store i64 %v6006, ptr %rgep6009, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear919
bb_rcgclear919:
  %v6010 = load i64, ptr %slot747, align 8
  %p6011 = inttoptr i64 %v6010 to ptr
  store i64 0, ptr %p6011, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone919
bb_rcgdone919:
  br label %bb_rcslotdone903
bb_rcslotowner903:
  %v6012 = load i64, ptr %slot99, align 8
  store i64 %v6012, ptr %slot764, align 8
  %v6013 = load i64, ptr %slot747, align 8
  %p6014 = inttoptr i64 %v6013 to ptr
  %ld6015 = load i64, ptr %p6014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6015, ptr %slot765, align 8
  %v6016 = load i64, ptr %slot765, align 8
  %cmp6017 = icmp ne i64 %v6016, 0
  %cv6018 = zext i1 %cmp6017 to i32
  store i32 %cv6018, ptr %slot766, align 8
  %v6019 = load i32, ptr %slot766, align 8
  %cv6020 = zext i32 %v6019 to i64
  %cond6021 = icmp ne i64 %cv6020, 0
  br i1 %cond6021, label %bb_rcgnn934, label %bb_rcgdone934
bb_rcgnn934:
  %v6022 = load i64, ptr %slot765, align 8
  %op6023 = sub i64 %v6022, 16
  store i64 %op6023, ptr %slot767, align 8
  %v6024 = load i64, ptr %slot765, align 8
  %p6025 = inttoptr i64 %v6024 to ptr
  %rgep6026 = getelementptr i8, ptr %p6025, i64 -16
  %ld6027 = load i64, ptr %rgep6026, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6027, ptr %slot768, align 8
  %v6028 = load i64, ptr %slot768, align 8
  %op6029 = and i64 %v6028, 4611686018427387906
  store i64 %op6029, ptr %slot769, align 8
  %v6030 = load i64, ptr %slot769, align 8
  %cmp6031 = icmp ne i64 %v6030, 0
  %cv6032 = zext i1 %cmp6031 to i32
  store i32 %cv6032, ptr %slot770, align 8
  %v6033 = load i32, ptr %slot770, align 8
  %cv6034 = zext i32 %v6033 to i64
  %cond6035 = icmp ne i64 %cv6034, 0
  br i1 %cond6035, label %bb_rcgclear934, label %bb_rcgcounted934
bb_rcgcounted934:
  %v6036 = load i64, ptr %slot765, align 8
  %op6037 = sub i64 %v6036, 32
  store i64 %op6037, ptr %slot771, align 8
  %v6038 = load i64, ptr %slot765, align 8
  %p6039 = inttoptr i64 %v6038 to ptr
  %rgep6040 = getelementptr i8, ptr %p6039, i64 -32
  %ld6041 = load i64, ptr %rgep6040, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6041, ptr %slot772, align 8
  %v6042 = load i64, ptr %slot772, align 8
  %op6043 = sub i64 %v6042, 1
  store i64 %op6043, ptr %slot773, align 8
  %v6044 = load i64, ptr %slot773, align 8
  %cmp6045 = icmp eq i64 %v6044, 0
  %cv6046 = zext i1 %cmp6045 to i32
  store i32 %cv6046, ptr %slot774, align 8
  %v6047 = load i32, ptr %slot774, align 8
  %cv6048 = zext i32 %v6047 to i64
  %cond6049 = icmp ne i64 %cv6048, 0
  br i1 %cond6049, label %bb_rcglast934, label %bb_rcgdec934
bb_rcglast934:
  %v6050 = load i64, ptr %slot765, align 8
  %op6051 = sub i64 %v6050, 24
  store i64 %op6051, ptr %slot775, align 8
  %v6052 = load i64, ptr %slot765, align 8
  %p6053 = inttoptr i64 %v6052 to ptr
  %rgep6054 = getelementptr i8, ptr %p6053, i64 -24
  %ld6055 = load i64, ptr %rgep6054, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6055, ptr %slot776, align 8
  %v6056 = load i64, ptr %slot776, align 8
  %cmp6057 = icmp ne i64 %v6056, 0
  %cv6058 = zext i1 %cmp6057 to i32
  store i32 %cv6058, ptr %slot777, align 8
  %v6059 = load i32, ptr %slot777, align 8
  %cv6060 = zext i32 %v6059 to i64
  %cond6061 = icmp ne i64 %cv6060, 0
  br i1 %cond6061, label %bb_rcgdec934, label %bb_rcgslow934
bb_rcgslow934:
  %v6062 = load i64, ptr %slot764, align 8
  %v6063 = load i64, ptr %slot747, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6062, i64 %v6063) nomerge, !dbg !158
  br label %bb_rcgdone934
bb_rcgdec934:
  %v6064 = load i64, ptr %slot773, align 8
  %v6065 = load i64, ptr %slot765, align 8
  %p6066 = inttoptr i64 %v6065 to ptr
  %rgep6067 = getelementptr i8, ptr %p6066, i64 -32
  store i64 %v6064, ptr %rgep6067, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear934
bb_rcgclear934:
  %v6068 = load i64, ptr %slot747, align 8
  %p6069 = inttoptr i64 %v6068 to ptr
  store i64 0, ptr %p6069, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone934
bb_rcgdone934:
  br label %bb_rcslotdone903
bb_rcslotdone903:
  %v6070 = load i64, ptr %slot44, align 8
  %p6071 = inttoptr i64 %v6070 to ptr
  store i64 0, ptr %p6071, align 8, !alias.scope !3, !noalias !4
  %v6072 = load i64, ptr %slot44, align 8
  %p6073 = inttoptr i64 %v6072 to ptr
  %ld6074 = load i64, ptr %p6073, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6074, ptr %slot778, align 8
  %v6075 = load i64, ptr %slot778, align 8
  %v6076 = load i64, ptr %slot36, align 8
  %p6077 = inttoptr i64 %v6076 to ptr
  store i64 %v6075, ptr %p6077, align 8, !alias.scope !3, !noalias !4
  %v6078 = load i64, ptr %slot35, align 8
  %v6079 = load i64, ptr %slot44, align 8
  %p6080 = inttoptr i64 %v6079 to ptr
  store i64 %v6078, ptr %p6080, align 8, !alias.scope !3, !noalias !4
  %v6081 = load i64, ptr %slot44, align 8
  %p6082 = inttoptr i64 %v6081 to ptr
  %ld6083 = load i64, ptr %p6082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6083, ptr %slot779, align 8
  %v6084 = load i64, ptr %slot779, align 8
  %p6085 = inttoptr i64 %v6084 to ptr
  %ld6086 = load i32, ptr %p6085, align 4
  %ext6087 = zext i32 %ld6086 to i64
  store i64 %ext6087, ptr %slot780, align 8
  %v6088 = load i64, ptr %slot780, align 8
  %cmp6089 = icmp eq i64 %v6088, 0
  %cv6090 = zext i1 %cmp6089 to i64
  store i64 %cv6090, ptr %slot781, align 8
  %v6091 = load i64, ptr %slot781, align 8
  %cond6092 = icmp ne i64 %v6091, 0
  br i1 %cond6092, label %bb_rcarm941, label %bb_rcarmnext941
bb_rcarm941:
  br label %bb_i60
bb_rcarmnext941:
  %v6093 = load i64, ptr %slot780, align 8
  %cmp6094 = icmp eq i64 %v6093, 1
  %cv6095 = zext i1 %cmp6094 to i64
  store i64 %cv6095, ptr %slot782, align 8
  %v6096 = load i64, ptr %slot782, align 8
  %cond6097 = icmp ne i64 %v6096, 0
  br i1 %cond6097, label %bb_rcarm942, label %bb_rcarmnext942
bb_rcarm942:
  %v6098 = load i64, ptr %slot30, align 8
  store i64 %v6098, ptr %slot783, align 8
  %v6099 = load i64, ptr %slot779, align 8
  %op6100 = add i64 %v6099, 8
  store i64 %op6100, ptr %slot784, align 8
  %v6101 = load i64, ptr %slot100, align 8
  store i64 %v6101, ptr %slot785, align 8
  %v6102 = load i64, ptr %slot784, align 8
  %p6103 = inttoptr i64 %v6102 to ptr
  %ld6104 = load i64, ptr %p6103, align 8
  store i64 %ld6104, ptr %slot786, align 8
  %v6105 = load i64, ptr %slot786, align 8
  %v6106 = load i64, ptr %slot783, align 8
  %p6107 = inttoptr i64 %v6106 to ptr
  store i64 %v6105, ptr %p6107, align 8, !alias.scope !3, !noalias !4
  %v6108 = load i64, ptr %slot22, align 8
  %p6109 = inttoptr i64 %v6108 to ptr
  store i32 0, ptr %p6109, align 4, !alias.scope !3, !noalias !4
  %v6110 = load i64, ptr %slot21, align 8
  %p6111 = inttoptr i64 %v6110 to ptr
  store i32 1, ptr %p6111, align 4, !alias.scope !3, !noalias !4
  %v6112 = load i64, ptr %slot783, align 8
  %p6113 = inttoptr i64 %v6112 to ptr
  %ld6114 = load i64, ptr %p6113, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6114, ptr %slot787, align 8
  %v6115 = load i64, ptr %slot787, align 8
  %v6116 = load i64, ptr %slot37, align 8
  %p6117 = inttoptr i64 %v6116 to ptr
  store i64 %v6115, ptr %p6117, align 8, !alias.scope !3, !noalias !4
  %v6118 = load i64, ptr %slot21, align 8
  %p6119 = inttoptr i64 %v6118 to ptr
  store i32 0, ptr %p6119, align 4, !alias.scope !3, !noalias !4
  br label %bb_i59
bb_rcarmnext942:
  br label %bb_failure
bb_i59:
  br label %bb_i63
bb_i60:
  %v6120 = load i64, ptr %slot36, align 8
  %p6121 = inttoptr i64 %v6120 to ptr
  %ld6122 = load i64, ptr %p6121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6122, ptr %slot788, align 8
  %v6123 = load i64, ptr %slot788, align 8
  %v6124 = load i64, ptr %slot44, align 8
  %p6125 = inttoptr i64 %v6124 to ptr
  store i64 %v6123, ptr %p6125, align 8, !alias.scope !3, !noalias !4
  %v6126 = load i64, ptr %slot44, align 8
  %p6127 = inttoptr i64 %v6126 to ptr
  %ld6128 = load i64, ptr %p6127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6128, ptr %slot789, align 8
  %v6129 = load i64, ptr %slot789, align 8
  %v6130 = load i64, ptr %slot37, align 8
  %p6131 = inttoptr i64 %v6130 to ptr
  store i64 %v6129, ptr %p6131, align 8, !alias.scope !3, !noalias !4
  br label %bb_i63
bb_i63:
  %v6132 = load i64, ptr %slot37, align 8
  %p6133 = inttoptr i64 %v6132 to ptr
  %ld6134 = load i64, ptr %p6133, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6134, ptr %slot790, align 8
  %v6135 = load i64, ptr %slot790, align 8
  %v6136 = load i64, ptr %slot44, align 8
  %p6137 = inttoptr i64 %v6136 to ptr
  store i64 %v6135, ptr %p6137, align 8, !alias.scope !3, !noalias !4
  %v6138 = load i64, ptr %slot44, align 8
  %p6139 = inttoptr i64 %v6138 to ptr
  %ld6140 = load i64, ptr %p6139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6140, ptr %slot791, align 8
  %v6141 = load i64, ptr %slot791, align 8
  %v6142 = load i64, ptr %slot38, align 8
  %p6143 = inttoptr i64 %v6142 to ptr
  store i64 %v6141, ptr %p6143, align 8, !alias.scope !3, !noalias !4
  %v6144 = load i64, ptr %slot32, align 8
  %p6145 = inttoptr i64 %v6144 to ptr
  %ld6146 = load i64, ptr %p6145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6146, ptr %slot792, align 8
  %v6147 = load i64, ptr %slot792, align 8
  %v6148 = load i64, ptr %slot44, align 8
  %p6149 = inttoptr i64 %v6148 to ptr
  store i64 %v6147, ptr %p6149, align 8, !alias.scope !3, !noalias !4
  %v6150 = load i64, ptr %slot38, align 8
  %p6151 = inttoptr i64 %v6150 to ptr
  %ld6152 = load i64, ptr %p6151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6152, ptr %slot793, align 8
  %v6153 = load i64, ptr %slot793, align 8
  %v6154 = load i64, ptr %slot45, align 8
  %p6155 = inttoptr i64 %v6154 to ptr
  store i64 %v6153, ptr %p6155, align 8, !alias.scope !3, !noalias !4
  %v6156 = load i64, ptr %slot63, align 8
  store i64 %v6156, ptr %slot794, align 8
  %v6157 = load i64, ptr %slot794, align 8
  %p6158 = inttoptr i64 %v6157 to ptr
  store i64 0, ptr %p6158, align 8, !alias.scope !3, !noalias !4
  %v6159 = load i64, ptr %slot794, align 8
  %p6161 = inttoptr i64 %v6159 to ptr
  %gep6162 = getelementptr i8, ptr %p6161, i64 8
  %op6160 = ptrtoint ptr %gep6162 to i64
  store i64 %op6160, ptr %slot795, align 8
  %v6163 = load i64, ptr %slot795, align 8
  %p6164 = inttoptr i64 %v6163 to ptr
  store i64 0, ptr %p6164, align 8, !alias.scope !3, !noalias !4
  %v6165 = load i64, ptr %slot794, align 8
  %p6166 = inttoptr i64 %v6165 to ptr
  store i32 2, ptr %p6166, align 4, !alias.scope !3, !noalias !4
  %v6167 = load i64, ptr %slot23, align 8
  %p6168 = inttoptr i64 %v6167 to ptr
  store i32 1, ptr %p6168, align 4, !alias.scope !3, !noalias !4
  %v6169 = load i64, ptr %slot45, align 8
  store i64 %v6169, ptr %slot796, align 8
  %v6170 = load i64, ptr %slot794, align 8
  %p6172 = inttoptr i64 %v6170 to ptr
  %gep6173 = getelementptr i8, ptr %p6172, i64 8
  %op6171 = ptrtoint ptr %gep6173 to i64
  store i64 %op6171, ptr %slot797, align 8
  %v6174 = load i64, ptr %slot100, align 8
  store i64 %v6174, ptr %slot798, align 8
  %v6175 = load i64, ptr %slot796, align 8
  %p6176 = inttoptr i64 %v6175 to ptr
  %ld6177 = load i64, ptr %p6176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6177, ptr %slot799, align 8
  %v6178 = load i64, ptr %slot799, align 8
  %v6179 = load i64, ptr %slot797, align 8
  %p6180 = inttoptr i64 %v6179 to ptr
  store i64 %v6178, ptr %p6180, align 8, !alias.scope !3, !noalias !4
  %v6181 = load i64, ptr %slot794, align 8
  %v6182 = load i64, ptr %slot45, align 8
  %p6183 = inttoptr i64 %v6182 to ptr
  store i64 %v6181, ptr %p6183, align 8, !alias.scope !3, !noalias !4
  %v6184 = load i64, ptr %slot33, align 8
  %v6185 = load i64, ptr %slot46, align 8
  %p6186 = inttoptr i64 %v6185 to ptr
  store i64 %v6184, ptr %p6186, align 8, !alias.scope !3, !noalias !4
  %v6187 = load i64, ptr %slot44, align 8
  %p6188 = inttoptr i64 %v6187 to ptr
  %ld6189 = load i64, ptr %p6188, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6189, ptr %slot800, align 8
  %v6190 = load i64, ptr %slot45, align 8
  %p6191 = inttoptr i64 %v6190 to ptr
  %ld6192 = load i64, ptr %p6191, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6192, ptr %slot801, align 8
  %v6193 = load i64, ptr %slot46, align 8
  %p6194 = inttoptr i64 %v6193 to ptr
  %ld6195 = load i64, ptr %p6194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6195, ptr %slot802, align 8
  %v6196 = load i64, ptr %slot1, align 8
  %v6197 = load i64, ptr %slot800, align 8
  %v6198 = load i64, ptr %slot801, align 8
  %v6199 = load i64, ptr %slot802, align 8
  %call6200 = call i64 @myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623(i64 %v6196, i64 %v6197, i64 %v6198, i64 %v6199) nomerge, !dbg !160
  store i64 %call6200, ptr %slot803, align 8
  %v6201 = load i64, ptr %slot803, align 8
  %v6202 = load i64, ptr %slot44, align 8
  %p6203 = inttoptr i64 %v6202 to ptr
  store i64 %v6201, ptr %p6203, align 8, !alias.scope !3, !noalias !4
  %v6204 = load i64, ptr %slot15, align 8
  %p6205 = inttoptr i64 %v6204 to ptr
  %ld6206 = load i32, ptr %p6205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6206, ptr %slot804, align 8
  %v6207 = load i32, ptr %slot804, align 8
  %cv6208 = zext i32 %v6207 to i64
  %cond6209 = icmp ne i64 %cv6208, 0
  br i1 %cond6209, label %bb_rcslotdrop971, label %bb_rcslotdone971
bb_rcslotdrop971:
  %v6210 = load i64, ptr %slot15, align 8
  %p6211 = inttoptr i64 %v6210 to ptr
  store i32 0, ptr %p6211, align 4, !alias.scope !3, !noalias !4
  %v6212 = load i64, ptr %slot24, align 8
  store i64 %v6212, ptr %slot805, align 8
  %v6213 = load i64, ptr %slot16, align 8
  %p6214 = inttoptr i64 %v6213 to ptr
  %ld6215 = load i32, ptr %p6214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6215, ptr %slot806, align 8
  %v6216 = load i32, ptr %slot806, align 8
  %op6217 = and i32 %v6216, 28
  store i32 %op6217, ptr %slot807, align 8
  %v6218 = load i32, ptr %slot807, align 8
  %cv6219 = zext i32 %v6218 to i64
  %cond6220 = icmp ne i64 %cv6219, 0
  br i1 %cond6220, label %bb_rcslotrole971, label %bb_rcslotowner971
bb_rcslotrole971:
  %v6221 = load i64, ptr %slot99, align 8
  store i64 %v6221, ptr %slot808, align 8
  %v6222 = load i64, ptr %slot808, align 8
  %v6223 = load i64, ptr %slot805, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v6222, i64 %v6223) nomerge, !dbg !160
  br label %bb_rcslotdone971
bb_rcslotowner971:
  %v6224 = load i64, ptr %slot99, align 8
  store i64 %v6224, ptr %slot809, align 8
  %v6225 = load i64, ptr %slot809, align 8
  %v6226 = load i64, ptr %slot805, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v6225, i64 %v6226) nomerge, !dbg !160
  br label %bb_rcslotdone971
bb_rcslotdone971:
  %v6227 = load i64, ptr %slot19, align 8
  %p6228 = inttoptr i64 %v6227 to ptr
  %ld6229 = load i32, ptr %p6228, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6229, ptr %slot810, align 8
  %v6230 = load i32, ptr %slot810, align 8
  %cv6231 = zext i32 %v6230 to i64
  %cond6232 = icmp ne i64 %cv6231, 0
  br i1 %cond6232, label %bb_rcslotdrop980, label %bb_rcslotdone980
bb_rcslotdrop980:
  %v6233 = load i64, ptr %slot19, align 8
  %p6234 = inttoptr i64 %v6233 to ptr
  store i32 0, ptr %p6234, align 4, !alias.scope !3, !noalias !4
  %v6235 = load i64, ptr %slot26, align 8
  store i64 %v6235, ptr %slot811, align 8
  %v6236 = load i64, ptr %slot20, align 8
  %p6237 = inttoptr i64 %v6236 to ptr
  %ld6238 = load i32, ptr %p6237, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6238, ptr %slot812, align 8
  %v6239 = load i32, ptr %slot812, align 8
  %op6240 = and i32 %v6239, 28
  store i32 %op6240, ptr %slot813, align 8
  %v6241 = load i32, ptr %slot813, align 8
  %cv6242 = zext i32 %v6241 to i64
  %cond6243 = icmp ne i64 %cv6242, 0
  br i1 %cond6243, label %bb_rcslotrole980, label %bb_rcslotowner980
bb_rcslotrole980:
  %v6244 = load i64, ptr %slot99, align 8
  store i64 %v6244, ptr %slot814, align 8
  %v6245 = load i64, ptr %slot814, align 8
  %v6246 = load i64, ptr %slot811, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6245, i64 %v6246) nomerge, !dbg !160
  br label %bb_rcslotdone980
bb_rcslotowner980:
  %v6247 = load i64, ptr %slot99, align 8
  store i64 %v6247, ptr %slot815, align 8
  %v6248 = load i64, ptr %slot815, align 8
  %v6249 = load i64, ptr %slot811, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6248, i64 %v6249) nomerge, !dbg !160
  br label %bb_rcslotdone980
bb_rcslotdone980:
  %v6250 = load i64, ptr %slot64, align 8
  store i64 %v6250, ptr %slot816, align 8
  %v6251 = load i64, ptr %slot816, align 8
  %p6252 = inttoptr i64 %v6251 to ptr
  store i64 0, ptr %p6252, align 8, !alias.scope !3, !noalias !4
  %v6253 = load i64, ptr %slot816, align 8
  %p6255 = inttoptr i64 %v6253 to ptr
  %gep6256 = getelementptr i8, ptr %p6255, i64 8
  %op6254 = ptrtoint ptr %gep6256 to i64
  store i64 %op6254, ptr %slot817, align 8
  %v6257 = load i64, ptr %slot817, align 8
  %p6258 = inttoptr i64 %v6257 to ptr
  store i64 0, ptr %p6258, align 8, !alias.scope !3, !noalias !4
  %v6259 = load i64, ptr %slot816, align 8
  %p6260 = inttoptr i64 %v6259 to ptr
  store i32 0, ptr %p6260, align 4, !alias.scope !3, !noalias !4
  %v6261 = load i64, ptr %slot23, align 8
  %p6262 = inttoptr i64 %v6261 to ptr
  store i32 1, ptr %p6262, align 4, !alias.scope !3, !noalias !4
  %v6263 = load i64, ptr %slot44, align 8
  store i64 %v6263, ptr %slot818, align 8
  %v6264 = load i64, ptr %slot816, align 8
  %p6266 = inttoptr i64 %v6264 to ptr
  %gep6267 = getelementptr i8, ptr %p6266, i64 8
  %op6265 = ptrtoint ptr %gep6267 to i64
  store i64 %op6265, ptr %slot819, align 8
  %v6268 = load i64, ptr %slot100, align 8
  store i64 %v6268, ptr %slot820, align 8
  %v6269 = load i64, ptr %slot818, align 8
  %p6270 = inttoptr i64 %v6269 to ptr
  %ld6271 = load i64, ptr %p6270, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6271, ptr %slot821, align 8
  %v6272 = load i64, ptr %slot821, align 8
  %v6273 = load i64, ptr %slot819, align 8
  %p6274 = inttoptr i64 %v6273 to ptr
  store i64 %v6272, ptr %p6274, align 8, !alias.scope !3, !noalias !4
  %v6275 = load i64, ptr %slot816, align 8
  %v6276 = load i64, ptr %slot44, align 8
  %p6277 = inttoptr i64 %v6276 to ptr
  store i64 %v6275, ptr %p6277, align 8, !alias.scope !3, !noalias !4
  %v6278 = load i64, ptr %slot44, align 8
  %p6279 = inttoptr i64 %v6278 to ptr
  %ld6280 = load i64, ptr %p6279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6280, ptr %slot822, align 8
  %v6281 = load i64, ptr %slot15, align 8
  %p6282 = inttoptr i64 %v6281 to ptr
  %ld6283 = load i32, ptr %p6282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6283, ptr %slot823, align 8
  %v6284 = load i32, ptr %slot823, align 8
  %cv6285 = zext i32 %v6284 to i64
  %cond6286 = icmp ne i64 %cv6285, 0
  br i1 %cond6286, label %bb_rcslotdrop998, label %bb_rcslotdone998
bb_rcslotdrop998:
  %v6287 = load i64, ptr %slot15, align 8
  %p6288 = inttoptr i64 %v6287 to ptr
  store i32 0, ptr %p6288, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone998
bb_rcslotdone998:
  %v6289 = load i64, ptr %slot13, align 8
  %p6290 = inttoptr i64 %v6289 to ptr
  %ld6291 = load i32, ptr %p6290, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6291, ptr %slot824, align 8
  %v6292 = load i32, ptr %slot824, align 8
  %cv6293 = zext i32 %v6292 to i64
  %cond6294 = icmp ne i64 %cv6293, 0
  br i1 %cond6294, label %bb_rcslotdrop1001, label %bb_rcslotdone1001
bb_rcslotdrop1001:
  %v6295 = load i64, ptr %slot13, align 8
  %p6296 = inttoptr i64 %v6295 to ptr
  store i32 0, ptr %p6296, align 4, !alias.scope !3, !noalias !4
  %v6297 = load i64, ptr %slot42, align 8
  store i64 %v6297, ptr %slot825, align 8
  %v6298 = load i64, ptr %slot14, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  %ld6300 = load i32, ptr %p6299, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6300, ptr %slot826, align 8
  %v6301 = load i32, ptr %slot826, align 8
  %op6302 = and i32 %v6301, 28
  store i32 %op6302, ptr %slot827, align 8
  %v6303 = load i32, ptr %slot827, align 8
  %cv6304 = zext i32 %v6303 to i64
  %cond6305 = icmp ne i64 %cv6304, 0
  br i1 %cond6305, label %bb_rcslotrole1001, label %bb_rcslotowner1001
bb_rcslotrole1001:
  %v6306 = load i64, ptr %slot99, align 8
  store i64 %v6306, ptr %slot828, align 8
  %v6307 = load i64, ptr %slot828, align 8
  %v6308 = load i64, ptr %slot825, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6307, i64 %v6308) nomerge, !dbg !162
  br label %bb_rcslotdone1001
bb_rcslotowner1001:
  %v6309 = load i64, ptr %slot99, align 8
  store i64 %v6309, ptr %slot829, align 8
  %v6310 = load i64, ptr %slot829, align 8
  %v6311 = load i64, ptr %slot825, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6310, i64 %v6311) nomerge, !dbg !162
  br label %bb_rcslotdone1001
bb_rcslotdone1001:
  %v6312 = load i64, ptr %slot11, align 8
  %p6313 = inttoptr i64 %v6312 to ptr
  %ld6314 = load i32, ptr %p6313, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6314, ptr %slot830, align 8
  %v6315 = load i32, ptr %slot830, align 8
  %cv6316 = zext i32 %v6315 to i64
  %cond6317 = icmp ne i64 %cv6316, 0
  br i1 %cond6317, label %bb_rcslotdrop1010, label %bb_rcslotdone1010
bb_rcslotdrop1010:
  %v6318 = load i64, ptr %slot11, align 8
  %p6319 = inttoptr i64 %v6318 to ptr
  store i32 0, ptr %p6319, align 4, !alias.scope !3, !noalias !4
  %v6320 = load i64, ptr %slot41, align 8
  store i64 %v6320, ptr %slot831, align 8
  %v6321 = load i64, ptr %slot12, align 8
  %p6322 = inttoptr i64 %v6321 to ptr
  %ld6323 = load i32, ptr %p6322, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6323, ptr %slot832, align 8
  %v6324 = load i32, ptr %slot832, align 8
  %op6325 = and i32 %v6324, 28
  store i32 %op6325, ptr %slot833, align 8
  %v6326 = load i32, ptr %slot833, align 8
  %cv6327 = zext i32 %v6326 to i64
  %cond6328 = icmp ne i64 %cv6327, 0
  br i1 %cond6328, label %bb_rcslotrole1010, label %bb_rcslotowner1010
bb_rcslotrole1010:
  %v6329 = load i64, ptr %slot99, align 8
  store i64 %v6329, ptr %slot834, align 8
  %v6330 = load i64, ptr %slot834, align 8
  %v6331 = load i64, ptr %slot831, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6330, i64 %v6331) nomerge, !dbg !162
  br label %bb_rcslotdone1010
bb_rcslotowner1010:
  %v6332 = load i64, ptr %slot99, align 8
  store i64 %v6332, ptr %slot835, align 8
  %v6333 = load i64, ptr %slot835, align 8
  %v6334 = load i64, ptr %slot831, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6333, i64 %v6334) nomerge, !dbg !162
  br label %bb_rcslotdone1010
bb_rcslotdone1010:
  %v6335 = load i64, ptr %slot9, align 8
  %p6336 = inttoptr i64 %v6335 to ptr
  %ld6337 = load i32, ptr %p6336, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6337, ptr %slot836, align 8
  %v6338 = load i32, ptr %slot836, align 8
  %cv6339 = zext i32 %v6338 to i64
  %cond6340 = icmp ne i64 %cv6339, 0
  br i1 %cond6340, label %bb_rcslotdrop1019, label %bb_rcslotdone1019
bb_rcslotdrop1019:
  %v6341 = load i64, ptr %slot9, align 8
  %p6342 = inttoptr i64 %v6341 to ptr
  store i32 0, ptr %p6342, align 4, !alias.scope !3, !noalias !4
  %v6343 = load i64, ptr %slot39, align 8
  store i64 %v6343, ptr %slot837, align 8
  %v6344 = load i64, ptr %slot10, align 8
  %p6345 = inttoptr i64 %v6344 to ptr
  %ld6346 = load i32, ptr %p6345, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6346, ptr %slot838, align 8
  %v6347 = load i32, ptr %slot838, align 8
  %op6348 = and i32 %v6347, 28
  store i32 %op6348, ptr %slot839, align 8
  %v6349 = load i32, ptr %slot839, align 8
  %cv6350 = zext i32 %v6349 to i64
  %cond6351 = icmp ne i64 %cv6350, 0
  br i1 %cond6351, label %bb_rcslotrole1019, label %bb_rcslotowner1019
bb_rcslotrole1019:
  %v6352 = load i64, ptr %slot99, align 8
  store i64 %v6352, ptr %slot840, align 8
  %v6353 = load i64, ptr %slot837, align 8
  %p6354 = inttoptr i64 %v6353 to ptr
  %ld6355 = load i64, ptr %p6354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6355, ptr %slot841, align 8
  %v6356 = load i64, ptr %slot841, align 8
  %cmp6357 = icmp ne i64 %v6356, 0
  %cv6358 = zext i1 %cmp6357 to i32
  store i32 %cv6358, ptr %slot842, align 8
  %v6359 = load i32, ptr %slot842, align 8
  %cv6360 = zext i32 %v6359 to i64
  %cond6361 = icmp ne i64 %cv6360, 0
  br i1 %cond6361, label %bb_rcgnn1035, label %bb_rcgdone1035
bb_rcgnn1035:
  %v6362 = load i64, ptr %slot841, align 8
  %op6363 = sub i64 %v6362, 16
  store i64 %op6363, ptr %slot843, align 8
  %v6364 = load i64, ptr %slot841, align 8
  %p6365 = inttoptr i64 %v6364 to ptr
  %rgep6366 = getelementptr i8, ptr %p6365, i64 -16
  %ld6367 = load i64, ptr %rgep6366, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6367, ptr %slot844, align 8
  %v6368 = load i64, ptr %slot844, align 8
  %op6369 = and i64 %v6368, 4611686018427387906
  store i64 %op6369, ptr %slot845, align 8
  %v6370 = load i64, ptr %slot845, align 8
  %cmp6371 = icmp ne i64 %v6370, 0
  %cv6372 = zext i1 %cmp6371 to i32
  store i32 %cv6372, ptr %slot846, align 8
  %v6373 = load i32, ptr %slot846, align 8
  %cv6374 = zext i32 %v6373 to i64
  %cond6375 = icmp ne i64 %cv6374, 0
  br i1 %cond6375, label %bb_rcgclear1035, label %bb_rcgcounted1035
bb_rcgcounted1035:
  %v6376 = load i64, ptr %slot841, align 8
  %op6377 = sub i64 %v6376, 24
  store i64 %op6377, ptr %slot847, align 8
  %v6378 = load i64, ptr %slot841, align 8
  %p6379 = inttoptr i64 %v6378 to ptr
  %rgep6380 = getelementptr i8, ptr %p6379, i64 -24
  %ld6381 = load i64, ptr %rgep6380, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6381, ptr %slot848, align 8
  %v6382 = load i64, ptr %slot848, align 8
  %op6383 = sub i64 %v6382, 1
  store i64 %op6383, ptr %slot849, align 8
  %v6384 = load i64, ptr %slot849, align 8
  %cmp6385 = icmp eq i64 %v6384, 0
  %cv6386 = zext i1 %cmp6385 to i32
  store i32 %cv6386, ptr %slot850, align 8
  %v6387 = load i32, ptr %slot850, align 8
  %cv6388 = zext i32 %v6387 to i64
  %cond6389 = icmp ne i64 %cv6388, 0
  br i1 %cond6389, label %bb_rcglast1035, label %bb_rcgdec1035
bb_rcglast1035:
  %v6390 = load i64, ptr %slot841, align 8
  %op6391 = sub i64 %v6390, 32
  store i64 %op6391, ptr %slot851, align 8
  %v6392 = load i64, ptr %slot841, align 8
  %p6393 = inttoptr i64 %v6392 to ptr
  %rgep6394 = getelementptr i8, ptr %p6393, i64 -32
  %ld6395 = load i64, ptr %rgep6394, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6395, ptr %slot852, align 8
  %v6396 = load i64, ptr %slot852, align 8
  %cmp6397 = icmp ne i64 %v6396, 0
  %cv6398 = zext i1 %cmp6397 to i32
  store i32 %cv6398, ptr %slot853, align 8
  %v6399 = load i32, ptr %slot853, align 8
  %cv6400 = zext i32 %v6399 to i64
  %cond6401 = icmp ne i64 %cv6400, 0
  br i1 %cond6401, label %bb_rcgdec1035, label %bb_rcgslow1035
bb_rcgslow1035:
  %v6402 = load i64, ptr %slot840, align 8
  %v6403 = load i64, ptr %slot837, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6402, i64 %v6403) nomerge, !dbg !162
  br label %bb_rcgdone1035
bb_rcgdec1035:
  %v6404 = load i64, ptr %slot849, align 8
  %v6405 = load i64, ptr %slot841, align 8
  %p6406 = inttoptr i64 %v6405 to ptr
  %rgep6407 = getelementptr i8, ptr %p6406, i64 -24
  store i64 %v6404, ptr %rgep6407, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1035
bb_rcgclear1035:
  %v6408 = load i64, ptr %slot837, align 8
  %p6409 = inttoptr i64 %v6408 to ptr
  store i64 0, ptr %p6409, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1035
bb_rcgdone1035:
  br label %bb_rcslotdone1019
bb_rcslotowner1019:
  %v6410 = load i64, ptr %slot99, align 8
  store i64 %v6410, ptr %slot854, align 8
  %v6411 = load i64, ptr %slot837, align 8
  %p6412 = inttoptr i64 %v6411 to ptr
  %ld6413 = load i64, ptr %p6412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6413, ptr %slot855, align 8
  %v6414 = load i64, ptr %slot855, align 8
  %cmp6415 = icmp ne i64 %v6414, 0
  %cv6416 = zext i1 %cmp6415 to i32
  store i32 %cv6416, ptr %slot856, align 8
  %v6417 = load i32, ptr %slot856, align 8
  %cv6418 = zext i32 %v6417 to i64
  %cond6419 = icmp ne i64 %cv6418, 0
  br i1 %cond6419, label %bb_rcgnn1050, label %bb_rcgdone1050
bb_rcgnn1050:
  %v6420 = load i64, ptr %slot855, align 8
  %op6421 = sub i64 %v6420, 16
  store i64 %op6421, ptr %slot857, align 8
  %v6422 = load i64, ptr %slot855, align 8
  %p6423 = inttoptr i64 %v6422 to ptr
  %rgep6424 = getelementptr i8, ptr %p6423, i64 -16
  %ld6425 = load i64, ptr %rgep6424, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6425, ptr %slot858, align 8
  %v6426 = load i64, ptr %slot858, align 8
  %op6427 = and i64 %v6426, 4611686018427387906
  store i64 %op6427, ptr %slot859, align 8
  %v6428 = load i64, ptr %slot859, align 8
  %cmp6429 = icmp ne i64 %v6428, 0
  %cv6430 = zext i1 %cmp6429 to i32
  store i32 %cv6430, ptr %slot860, align 8
  %v6431 = load i32, ptr %slot860, align 8
  %cv6432 = zext i32 %v6431 to i64
  %cond6433 = icmp ne i64 %cv6432, 0
  br i1 %cond6433, label %bb_rcgclear1050, label %bb_rcgcounted1050
bb_rcgcounted1050:
  %v6434 = load i64, ptr %slot855, align 8
  %op6435 = sub i64 %v6434, 32
  store i64 %op6435, ptr %slot861, align 8
  %v6436 = load i64, ptr %slot855, align 8
  %p6437 = inttoptr i64 %v6436 to ptr
  %rgep6438 = getelementptr i8, ptr %p6437, i64 -32
  %ld6439 = load i64, ptr %rgep6438, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6439, ptr %slot862, align 8
  %v6440 = load i64, ptr %slot862, align 8
  %op6441 = sub i64 %v6440, 1
  store i64 %op6441, ptr %slot863, align 8
  %v6442 = load i64, ptr %slot863, align 8
  %cmp6443 = icmp eq i64 %v6442, 0
  %cv6444 = zext i1 %cmp6443 to i32
  store i32 %cv6444, ptr %slot864, align 8
  %v6445 = load i32, ptr %slot864, align 8
  %cv6446 = zext i32 %v6445 to i64
  %cond6447 = icmp ne i64 %cv6446, 0
  br i1 %cond6447, label %bb_rcglast1050, label %bb_rcgdec1050
bb_rcglast1050:
  %v6448 = load i64, ptr %slot855, align 8
  %op6449 = sub i64 %v6448, 24
  store i64 %op6449, ptr %slot865, align 8
  %v6450 = load i64, ptr %slot855, align 8
  %p6451 = inttoptr i64 %v6450 to ptr
  %rgep6452 = getelementptr i8, ptr %p6451, i64 -24
  %ld6453 = load i64, ptr %rgep6452, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6453, ptr %slot866, align 8
  %v6454 = load i64, ptr %slot866, align 8
  %cmp6455 = icmp ne i64 %v6454, 0
  %cv6456 = zext i1 %cmp6455 to i32
  store i32 %cv6456, ptr %slot867, align 8
  %v6457 = load i32, ptr %slot867, align 8
  %cv6458 = zext i32 %v6457 to i64
  %cond6459 = icmp ne i64 %cv6458, 0
  br i1 %cond6459, label %bb_rcgdec1050, label %bb_rcgslow1050
bb_rcgslow1050:
  %v6460 = load i64, ptr %slot854, align 8
  %v6461 = load i64, ptr %slot837, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6460, i64 %v6461) nomerge, !dbg !162
  br label %bb_rcgdone1050
bb_rcgdec1050:
  %v6462 = load i64, ptr %slot863, align 8
  %v6463 = load i64, ptr %slot855, align 8
  %p6464 = inttoptr i64 %v6463 to ptr
  %rgep6465 = getelementptr i8, ptr %p6464, i64 -32
  store i64 %v6462, ptr %rgep6465, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1050
bb_rcgclear1050:
  %v6466 = load i64, ptr %slot837, align 8
  %p6467 = inttoptr i64 %v6466 to ptr
  store i64 0, ptr %p6467, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1050
bb_rcgdone1050:
  br label %bb_rcslotdone1019
bb_rcslotdone1019:
  %v6468 = load i64, ptr %slot7, align 8
  %p6469 = inttoptr i64 %v6468 to ptr
  %ld6470 = load i32, ptr %p6469, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6470, ptr %slot868, align 8
  %v6471 = load i32, ptr %slot868, align 8
  %cv6472 = zext i32 %v6471 to i64
  %cond6473 = icmp ne i64 %cv6472, 0
  br i1 %cond6473, label %bb_rcslotdrop1056, label %bb_rcslotdone1056
bb_rcslotdrop1056:
  %v6474 = load i64, ptr %slot7, align 8
  %p6475 = inttoptr i64 %v6474 to ptr
  store i32 0, ptr %p6475, align 4, !alias.scope !3, !noalias !4
  %v6476 = load i64, ptr %slot34, align 8
  store i64 %v6476, ptr %slot869, align 8
  %v6477 = load i64, ptr %slot8, align 8
  %p6478 = inttoptr i64 %v6477 to ptr
  %ld6479 = load i32, ptr %p6478, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6479, ptr %slot870, align 8
  %v6480 = load i32, ptr %slot870, align 8
  %op6481 = and i32 %v6480, 28
  store i32 %op6481, ptr %slot871, align 8
  %v6482 = load i32, ptr %slot871, align 8
  %cv6483 = zext i32 %v6482 to i64
  %cond6484 = icmp ne i64 %cv6483, 0
  br i1 %cond6484, label %bb_rcslotrole1056, label %bb_rcslotowner1056
bb_rcslotrole1056:
  %v6485 = load i64, ptr %slot99, align 8
  store i64 %v6485, ptr %slot872, align 8
  %v6486 = load i64, ptr %slot869, align 8
  %p6487 = inttoptr i64 %v6486 to ptr
  %ld6488 = load i64, ptr %p6487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6488, ptr %slot873, align 8
  %v6489 = load i64, ptr %slot873, align 8
  %cmp6490 = icmp ne i64 %v6489, 0
  %cv6491 = zext i1 %cmp6490 to i32
  store i32 %cv6491, ptr %slot874, align 8
  %v6492 = load i32, ptr %slot874, align 8
  %cv6493 = zext i32 %v6492 to i64
  %cond6494 = icmp ne i64 %cv6493, 0
  br i1 %cond6494, label %bb_rcgnn1072, label %bb_rcgdone1072
bb_rcgnn1072:
  %v6495 = load i64, ptr %slot873, align 8
  %op6496 = sub i64 %v6495, 16
  store i64 %op6496, ptr %slot875, align 8
  %v6497 = load i64, ptr %slot873, align 8
  %p6498 = inttoptr i64 %v6497 to ptr
  %rgep6499 = getelementptr i8, ptr %p6498, i64 -16
  %ld6500 = load i64, ptr %rgep6499, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6500, ptr %slot876, align 8
  %v6501 = load i64, ptr %slot876, align 8
  %op6502 = and i64 %v6501, 4611686018427387906
  store i64 %op6502, ptr %slot877, align 8
  %v6503 = load i64, ptr %slot877, align 8
  %cmp6504 = icmp ne i64 %v6503, 0
  %cv6505 = zext i1 %cmp6504 to i32
  store i32 %cv6505, ptr %slot878, align 8
  %v6506 = load i32, ptr %slot878, align 8
  %cv6507 = zext i32 %v6506 to i64
  %cond6508 = icmp ne i64 %cv6507, 0
  br i1 %cond6508, label %bb_rcgclear1072, label %bb_rcgcounted1072
bb_rcgcounted1072:
  %v6509 = load i64, ptr %slot873, align 8
  %op6510 = sub i64 %v6509, 24
  store i64 %op6510, ptr %slot879, align 8
  %v6511 = load i64, ptr %slot873, align 8
  %p6512 = inttoptr i64 %v6511 to ptr
  %rgep6513 = getelementptr i8, ptr %p6512, i64 -24
  %ld6514 = load i64, ptr %rgep6513, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6514, ptr %slot880, align 8
  %v6515 = load i64, ptr %slot880, align 8
  %op6516 = sub i64 %v6515, 1
  store i64 %op6516, ptr %slot881, align 8
  %v6517 = load i64, ptr %slot881, align 8
  %cmp6518 = icmp eq i64 %v6517, 0
  %cv6519 = zext i1 %cmp6518 to i32
  store i32 %cv6519, ptr %slot882, align 8
  %v6520 = load i32, ptr %slot882, align 8
  %cv6521 = zext i32 %v6520 to i64
  %cond6522 = icmp ne i64 %cv6521, 0
  br i1 %cond6522, label %bb_rcglast1072, label %bb_rcgdec1072
bb_rcglast1072:
  %v6523 = load i64, ptr %slot873, align 8
  %op6524 = sub i64 %v6523, 32
  store i64 %op6524, ptr %slot883, align 8
  %v6525 = load i64, ptr %slot873, align 8
  %p6526 = inttoptr i64 %v6525 to ptr
  %rgep6527 = getelementptr i8, ptr %p6526, i64 -32
  %ld6528 = load i64, ptr %rgep6527, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6528, ptr %slot884, align 8
  %v6529 = load i64, ptr %slot884, align 8
  %cmp6530 = icmp ne i64 %v6529, 0
  %cv6531 = zext i1 %cmp6530 to i32
  store i32 %cv6531, ptr %slot885, align 8
  %v6532 = load i32, ptr %slot885, align 8
  %cv6533 = zext i32 %v6532 to i64
  %cond6534 = icmp ne i64 %cv6533, 0
  br i1 %cond6534, label %bb_rcgdec1072, label %bb_rcgslow1072
bb_rcgslow1072:
  %v6535 = load i64, ptr %slot872, align 8
  %v6536 = load i64, ptr %slot869, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v6535, i64 %v6536) nomerge, !dbg !162
  br label %bb_rcgdone1072
bb_rcgdec1072:
  %v6537 = load i64, ptr %slot881, align 8
  %v6538 = load i64, ptr %slot873, align 8
  %p6539 = inttoptr i64 %v6538 to ptr
  %rgep6540 = getelementptr i8, ptr %p6539, i64 -24
  store i64 %v6537, ptr %rgep6540, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1072
bb_rcgclear1072:
  %v6541 = load i64, ptr %slot869, align 8
  %p6542 = inttoptr i64 %v6541 to ptr
  store i64 0, ptr %p6542, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1072
bb_rcgdone1072:
  br label %bb_rcslotdone1056
bb_rcslotowner1056:
  %v6543 = load i64, ptr %slot99, align 8
  store i64 %v6543, ptr %slot886, align 8
  %v6544 = load i64, ptr %slot869, align 8
  %p6545 = inttoptr i64 %v6544 to ptr
  %ld6546 = load i64, ptr %p6545, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6546, ptr %slot887, align 8
  %v6547 = load i64, ptr %slot887, align 8
  %cmp6548 = icmp ne i64 %v6547, 0
  %cv6549 = zext i1 %cmp6548 to i32
  store i32 %cv6549, ptr %slot888, align 8
  %v6550 = load i32, ptr %slot888, align 8
  %cv6551 = zext i32 %v6550 to i64
  %cond6552 = icmp ne i64 %cv6551, 0
  br i1 %cond6552, label %bb_rcgnn1087, label %bb_rcgdone1087
bb_rcgnn1087:
  %v6553 = load i64, ptr %slot887, align 8
  %op6554 = sub i64 %v6553, 16
  store i64 %op6554, ptr %slot889, align 8
  %v6555 = load i64, ptr %slot887, align 8
  %p6556 = inttoptr i64 %v6555 to ptr
  %rgep6557 = getelementptr i8, ptr %p6556, i64 -16
  %ld6558 = load i64, ptr %rgep6557, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6558, ptr %slot890, align 8
  %v6559 = load i64, ptr %slot890, align 8
  %op6560 = and i64 %v6559, 4611686018427387906
  store i64 %op6560, ptr %slot891, align 8
  %v6561 = load i64, ptr %slot891, align 8
  %cmp6562 = icmp ne i64 %v6561, 0
  %cv6563 = zext i1 %cmp6562 to i32
  store i32 %cv6563, ptr %slot892, align 8
  %v6564 = load i32, ptr %slot892, align 8
  %cv6565 = zext i32 %v6564 to i64
  %cond6566 = icmp ne i64 %cv6565, 0
  br i1 %cond6566, label %bb_rcgclear1087, label %bb_rcgcounted1087
bb_rcgcounted1087:
  %v6567 = load i64, ptr %slot887, align 8
  %op6568 = sub i64 %v6567, 32
  store i64 %op6568, ptr %slot893, align 8
  %v6569 = load i64, ptr %slot887, align 8
  %p6570 = inttoptr i64 %v6569 to ptr
  %rgep6571 = getelementptr i8, ptr %p6570, i64 -32
  %ld6572 = load i64, ptr %rgep6571, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6572, ptr %slot894, align 8
  %v6573 = load i64, ptr %slot894, align 8
  %op6574 = sub i64 %v6573, 1
  store i64 %op6574, ptr %slot895, align 8
  %v6575 = load i64, ptr %slot895, align 8
  %cmp6576 = icmp eq i64 %v6575, 0
  %cv6577 = zext i1 %cmp6576 to i32
  store i32 %cv6577, ptr %slot896, align 8
  %v6578 = load i32, ptr %slot896, align 8
  %cv6579 = zext i32 %v6578 to i64
  %cond6580 = icmp ne i64 %cv6579, 0
  br i1 %cond6580, label %bb_rcglast1087, label %bb_rcgdec1087
bb_rcglast1087:
  %v6581 = load i64, ptr %slot887, align 8
  %op6582 = sub i64 %v6581, 24
  store i64 %op6582, ptr %slot897, align 8
  %v6583 = load i64, ptr %slot887, align 8
  %p6584 = inttoptr i64 %v6583 to ptr
  %rgep6585 = getelementptr i8, ptr %p6584, i64 -24
  %ld6586 = load i64, ptr %rgep6585, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6586, ptr %slot898, align 8
  %v6587 = load i64, ptr %slot898, align 8
  %cmp6588 = icmp ne i64 %v6587, 0
  %cv6589 = zext i1 %cmp6588 to i32
  store i32 %cv6589, ptr %slot899, align 8
  %v6590 = load i32, ptr %slot899, align 8
  %cv6591 = zext i32 %v6590 to i64
  %cond6592 = icmp ne i64 %cv6591, 0
  br i1 %cond6592, label %bb_rcgdec1087, label %bb_rcgslow1087
bb_rcgslow1087:
  %v6593 = load i64, ptr %slot886, align 8
  %v6594 = load i64, ptr %slot869, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v6593, i64 %v6594) nomerge, !dbg !162
  br label %bb_rcgdone1087
bb_rcgdec1087:
  %v6595 = load i64, ptr %slot895, align 8
  %v6596 = load i64, ptr %slot887, align 8
  %p6597 = inttoptr i64 %v6596 to ptr
  %rgep6598 = getelementptr i8, ptr %p6597, i64 -32
  store i64 %v6595, ptr %rgep6598, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1087
bb_rcgclear1087:
  %v6599 = load i64, ptr %slot869, align 8
  %p6600 = inttoptr i64 %v6599 to ptr
  store i64 0, ptr %p6600, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1087
bb_rcgdone1087:
  br label %bb_rcslotdone1056
bb_rcslotdone1056:
  %v6601 = load i64, ptr %slot5, align 8
  %p6602 = inttoptr i64 %v6601 to ptr
  %ld6603 = load i32, ptr %p6602, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6603, ptr %slot900, align 8
  %v6604 = load i32, ptr %slot900, align 8
  %cv6605 = zext i32 %v6604 to i64
  %cond6606 = icmp ne i64 %cv6605, 0
  br i1 %cond6606, label %bb_rcslotdrop1093, label %bb_rcslotdone1093
bb_rcslotdrop1093:
  %v6607 = load i64, ptr %slot5, align 8
  %p6608 = inttoptr i64 %v6607 to ptr
  store i32 0, ptr %p6608, align 4, !alias.scope !3, !noalias !4
  %v6609 = load i64, ptr %slot33, align 8
  store i64 %v6609, ptr %slot901, align 8
  %v6610 = load i64, ptr %slot6, align 8
  %p6611 = inttoptr i64 %v6610 to ptr
  %ld6612 = load i32, ptr %p6611, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6612, ptr %slot902, align 8
  %v6613 = load i32, ptr %slot902, align 8
  %op6614 = and i32 %v6613, 28
  store i32 %op6614, ptr %slot903, align 8
  %v6615 = load i32, ptr %slot903, align 8
  %cv6616 = zext i32 %v6615 to i64
  %cond6617 = icmp ne i64 %cv6616, 0
  br i1 %cond6617, label %bb_rcslotrole1093, label %bb_rcslotowner1093
bb_rcslotrole1093:
  %v6618 = load i64, ptr %slot99, align 8
  store i64 %v6618, ptr %slot904, align 8
  %v6619 = load i64, ptr %slot904, align 8
  %v6620 = load i64, ptr %slot901, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6619, i64 %v6620) nomerge, !dbg !162
  br label %bb_rcslotdone1093
bb_rcslotowner1093:
  %v6621 = load i64, ptr %slot99, align 8
  store i64 %v6621, ptr %slot905, align 8
  %v6622 = load i64, ptr %slot905, align 8
  %v6623 = load i64, ptr %slot901, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6622, i64 %v6623) nomerge, !dbg !162
  br label %bb_rcslotdone1093
bb_rcslotdone1093:
  %v6624 = load i64, ptr %slot822, align 8
  %p6625 = inttoptr i64 %v6624 to ptr
  %ret6626 = load { i64, i64 }, ptr %p6625, align 8
  ret { i64, i64 } %ret6626
bb_i72:
  %v6627 = load i64, ptr %slot32, align 8
  %p6628 = inttoptr i64 %v6627 to ptr
  %ld6629 = load i64, ptr %p6628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6629, ptr %slot906, align 8
  %v6630 = load i64, ptr %slot906, align 8
  %v6631 = load i64, ptr %slot44, align 8
  %p6632 = inttoptr i64 %v6631 to ptr
  store i64 %v6630, ptr %p6632, align 8, !alias.scope !3, !noalias !4
  %v6633 = load i64, ptr %slot65, align 8
  store i64 %v6633, ptr %slot907, align 8
  %v6634 = load i64, ptr %slot907, align 8
  %p6635 = inttoptr i64 %v6634 to ptr
  store i32 0, ptr %p6635, align 4, !alias.scope !3, !noalias !4
  %v6636 = load i64, ptr %slot907, align 8
  %p6637 = inttoptr i64 %v6636 to ptr
  store i32 20, ptr %p6637, align 4, !alias.scope !3, !noalias !4
  %v6638 = load i64, ptr %slot907, align 8
  %v6639 = load i64, ptr %slot45, align 8
  %p6640 = inttoptr i64 %v6639 to ptr
  store i64 %v6638, ptr %p6640, align 8, !alias.scope !3, !noalias !4
  %v6641 = load i64, ptr %slot44, align 8
  %p6642 = inttoptr i64 %v6641 to ptr
  %ld6643 = load i64, ptr %p6642, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6643, ptr %slot908, align 8
  %v6644 = load i64, ptr %slot45, align 8
  %p6645 = inttoptr i64 %v6644 to ptr
  %ld6646 = load i64, ptr %p6645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6646, ptr %slot909, align 8
  %v6647 = load i64, ptr %slot1, align 8
  %v6648 = load i64, ptr %slot908, align 8
  %v6649 = load i64, ptr %slot909, align 8
  %call6650 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v6647, i64 %v6648, i64 %v6649) nomerge, !dbg !164
  store i64 %call6650, ptr %slot910, align 8
  %v6651 = load i64, ptr %slot910, align 8
  %v6652 = load i64, ptr %slot44, align 8
  %p6653 = inttoptr i64 %v6652 to ptr
  store i64 %v6651, ptr %p6653, align 8, !alias.scope !3, !noalias !4
  %v6654 = load i64, ptr %slot15, align 8
  %p6655 = inttoptr i64 %v6654 to ptr
  %ld6656 = load i32, ptr %p6655, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6656, ptr %slot911, align 8
  %v6657 = load i32, ptr %slot911, align 8
  %cv6658 = zext i32 %v6657 to i64
  %cond6659 = icmp ne i64 %cv6658, 0
  br i1 %cond6659, label %bb_rcslotdrop1116, label %bb_rcslotdone1116
bb_rcslotdrop1116:
  %v6660 = load i64, ptr %slot15, align 8
  %p6661 = inttoptr i64 %v6660 to ptr
  store i32 0, ptr %p6661, align 4, !alias.scope !3, !noalias !4
  %v6662 = load i64, ptr %slot24, align 8
  store i64 %v6662, ptr %slot912, align 8
  %v6663 = load i64, ptr %slot16, align 8
  %p6664 = inttoptr i64 %v6663 to ptr
  %ld6665 = load i32, ptr %p6664, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6665, ptr %slot913, align 8
  %v6666 = load i32, ptr %slot913, align 8
  %op6667 = and i32 %v6666, 28
  store i32 %op6667, ptr %slot914, align 8
  %v6668 = load i32, ptr %slot914, align 8
  %cv6669 = zext i32 %v6668 to i64
  %cond6670 = icmp ne i64 %cv6669, 0
  br i1 %cond6670, label %bb_rcslotrole1116, label %bb_rcslotowner1116
bb_rcslotrole1116:
  %v6671 = load i64, ptr %slot99, align 8
  store i64 %v6671, ptr %slot915, align 8
  %v6672 = load i64, ptr %slot915, align 8
  %v6673 = load i64, ptr %slot912, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v6672, i64 %v6673) nomerge, !dbg !164
  br label %bb_rcslotdone1116
bb_rcslotowner1116:
  %v6674 = load i64, ptr %slot99, align 8
  store i64 %v6674, ptr %slot916, align 8
  %v6675 = load i64, ptr %slot916, align 8
  %v6676 = load i64, ptr %slot912, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v6675, i64 %v6676) nomerge, !dbg !164
  br label %bb_rcslotdone1116
bb_rcslotdone1116:
  %v6677 = load i64, ptr %slot44, align 8
  %p6678 = inttoptr i64 %v6677 to ptr
  %ld6679 = load i64, ptr %p6678, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6679, ptr %slot917, align 8
  %v6680 = load i64, ptr %slot917, align 8
  %cond6681 = icmp ne i64 %v6680, 0
  br i1 %cond6681, label %bb_next1124, label %bb_i104
bb_next1124:
  %v6682 = load i64, ptr %slot32, align 8
  %p6683 = inttoptr i64 %v6682 to ptr
  %ld6684 = load i64, ptr %p6683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6684, ptr %slot918, align 8
  %v6685 = load i64, ptr %slot918, align 8
  %v6686 = load i64, ptr %slot44, align 8
  %p6687 = inttoptr i64 %v6686 to ptr
  store i64 %v6685, ptr %p6687, align 8, !alias.scope !3, !noalias !4
  %v6688 = load i64, ptr %slot44, align 8
  %p6689 = inttoptr i64 %v6688 to ptr
  %ld6690 = load i64, ptr %p6689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6690, ptr %slot919, align 8
  %v6691 = load i64, ptr %slot1, align 8
  %v6692 = load i64, ptr %slot919, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult921, i64 %v6691, i64 %v6692) nomerge, !dbg !166
  %addr6693 = ptrtoint ptr %callresult921 to i64
  store i64 %addr6693, ptr %slot920, align 8
  %v6694 = load i64, ptr %slot920, align 8
  %v6695 = load i64, ptr %slot44, align 8
  %p6696 = inttoptr i64 %v6695 to ptr
  store i64 %v6694, ptr %p6696, align 8, !alias.scope !3, !noalias !4
  %v6697 = load i64, ptr %slot44, align 8
  %p6698 = inttoptr i64 %v6697 to ptr
  %ld6699 = load i64, ptr %p6698, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6699, ptr %slot922, align 8
  %v6700 = load i64, ptr %slot30, align 8
  store i64 %v6700, ptr %slot923, align 8
  %v6701 = load i64, ptr %slot99, align 8
  %v6702 = load i64, ptr %slot923, align 8
  %v6703 = load i64, ptr %slot922, align 8
  %call6704 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v6701, i64 %v6702, i64 %v6703) nomerge, !dbg !166
  store i32 %call6704, ptr %slot924, align 8
  %v6705 = load i32, ptr %slot924, align 8
  %cv6706 = zext i32 %v6705 to i64
  %cond6707 = icmp ne i64 %cv6706, 0
  br i1 %cond6707, label %bb_rcsuccess1130, label %bb_rcfailure1130
bb_rcfailure1130:
  %v6708 = load i64, ptr %slot99, align 8
  %p6709 = inttoptr i64 %v6708 to ptr
  %call6710 = call i32 @myl_rc_take_failure(ptr %p6709) nomerge, !dbg !166
  store i32 %call6710, ptr %slot925, align 8
  %v6711 = load i64, ptr %slot1, align 8
  %p6712 = inttoptr i64 %v6711 to ptr
  %v6713 = load i32, ptr %slot925, align 8
  %call6714 = call i32 @myl_qbe_rc_status(ptr %p6712, i32 %v6713) nomerge, !dbg !166
  store i32 %call6714, ptr %slot926, align 8
  br label %bb_failure
bb_rcsuccess1130:
  %v6715 = load i64, ptr %slot22, align 8
  %p6716 = inttoptr i64 %v6715 to ptr
  store i32 2, ptr %p6716, align 4, !alias.scope !3, !noalias !4
  %v6717 = load i64, ptr %slot22, align 8
  %p6718 = inttoptr i64 %v6717 to ptr
  store i32 16, ptr %p6718, align 4, !alias.scope !3, !noalias !4
  %v6719 = load i64, ptr %slot21, align 8
  %p6720 = inttoptr i64 %v6719 to ptr
  store i32 1, ptr %p6720, align 4, !alias.scope !3, !noalias !4
  %v6721 = load i64, ptr %slot15, align 8
  %p6722 = inttoptr i64 %v6721 to ptr
  %ld6723 = load i32, ptr %p6722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6723, ptr %slot927, align 8
  %v6724 = load i32, ptr %slot927, align 8
  %cv6725 = zext i32 %v6724 to i64
  %cond6726 = icmp ne i64 %cv6725, 0
  br i1 %cond6726, label %bb_rcslotdrop1138, label %bb_rcslotdone1138
bb_rcslotdrop1138:
  %v6727 = load i64, ptr %slot15, align 8
  %p6728 = inttoptr i64 %v6727 to ptr
  store i32 0, ptr %p6728, align 4, !alias.scope !3, !noalias !4
  %v6729 = load i64, ptr %slot24, align 8
  store i64 %v6729, ptr %slot928, align 8
  %v6730 = load i64, ptr %slot16, align 8
  %p6731 = inttoptr i64 %v6730 to ptr
  %ld6732 = load i32, ptr %p6731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6732, ptr %slot929, align 8
  %v6733 = load i32, ptr %slot929, align 8
  %op6734 = and i32 %v6733, 28
  store i32 %op6734, ptr %slot930, align 8
  %v6735 = load i32, ptr %slot930, align 8
  %cv6736 = zext i32 %v6735 to i64
  %cond6737 = icmp ne i64 %cv6736, 0
  br i1 %cond6737, label %bb_rcslotrole1138, label %bb_rcslotowner1138
bb_rcslotrole1138:
  %v6738 = load i64, ptr %slot99, align 8
  store i64 %v6738, ptr %slot931, align 8
  %v6739 = load i64, ptr %slot931, align 8
  %v6740 = load i64, ptr %slot928, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v6739, i64 %v6740) nomerge, !dbg !166
  br label %bb_rcslotdone1138
bb_rcslotowner1138:
  %v6741 = load i64, ptr %slot99, align 8
  store i64 %v6741, ptr %slot932, align 8
  %v6742 = load i64, ptr %slot932, align 8
  %v6743 = load i64, ptr %slot928, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v6742, i64 %v6743) nomerge, !dbg !166
  br label %bb_rcslotdone1138
bb_rcslotdone1138:
  %v6744 = load i64, ptr %slot24, align 8
  store i64 %v6744, ptr %slot933, align 8
  %v6745 = load i64, ptr %slot30, align 8
  store i64 %v6745, ptr %slot934, align 8
  %v6746 = load i64, ptr %slot934, align 8
  %v6747 = load i64, ptr %slot933, align 8
  %p6748 = inttoptr i64 %v6746 to ptr
  %p6749 = inttoptr i64 %v6747 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6749, ptr %p6748, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v6750 = load i64, ptr %slot16, align 8
  %p6751 = inttoptr i64 %v6750 to ptr
  store i32 2, ptr %p6751, align 4, !alias.scope !3, !noalias !4
  %v6752 = load i64, ptr %slot22, align 8
  %p6753 = inttoptr i64 %v6752 to ptr
  %ld6754 = load i32, ptr %p6753, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6754, ptr %slot935, align 8
  %v6755 = load i32, ptr %slot935, align 8
  %v6756 = load i64, ptr %slot16, align 8
  %p6757 = inttoptr i64 %v6756 to ptr
  store i32 %v6755, ptr %p6757, align 4, !alias.scope !3, !noalias !4
  %v6758 = load i64, ptr %slot21, align 8
  %p6759 = inttoptr i64 %v6758 to ptr
  store i32 0, ptr %p6759, align 4, !alias.scope !3, !noalias !4
  %v6760 = load i64, ptr %slot15, align 8
  %p6761 = inttoptr i64 %v6760 to ptr
  store i32 1, ptr %p6761, align 4, !alias.scope !3, !noalias !4
  %v6762 = load i64, ptr %slot933, align 8
  %v6763 = load i64, ptr %slot44, align 8
  %p6764 = inttoptr i64 %v6763 to ptr
  store i64 %v6762, ptr %p6764, align 8, !alias.scope !3, !noalias !4
  %v6765 = load i64, ptr %slot44, align 8
  %p6766 = inttoptr i64 %v6765 to ptr
  %ld6767 = load i64, ptr %p6766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6767, ptr %slot936, align 8
  %v6768 = load i64, ptr %slot15, align 8
  %p6769 = inttoptr i64 %v6768 to ptr
  %ld6770 = load i32, ptr %p6769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6770, ptr %slot937, align 8
  %v6771 = load i64, ptr %slot16, align 8
  %p6772 = inttoptr i64 %v6771 to ptr
  %ld6773 = load i32, ptr %p6772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6773, ptr %slot938, align 8
  %v6774 = load i32, ptr %slot938, align 8
  %op6775 = and i32 %v6774, 24
  store i32 %op6775, ptr %slot938, align 8
  %v6776 = load i32, ptr %slot938, align 8
  %cmp6777 = icmp eq i32 %v6776, 0
  %cv6778 = zext i1 %cmp6777 to i32
  store i32 %cv6778, ptr %slot939, align 8
  %v6779 = load i32, ptr %slot937, align 8
  %v6780 = load i32, ptr %slot939, align 8
  %op6781 = and i32 %v6779, %v6780
  store i32 %op6781, ptr %slot940, align 8
  %v6782 = load i32, ptr %slot940, align 8
  %cv6783 = zext i32 %v6782 to i64
  %cond6784 = icmp ne i64 %cv6783, 0
  br i1 %cond6784, label %bb_rctake1154, label %bb_rccopy1154
bb_rctake1154:
  %v6785 = load i64, ptr %slot30, align 8
  store i64 %v6785, ptr %slot941, align 8
  %v6786 = load i64, ptr %slot100, align 8
  store i64 %v6786, ptr %slot942, align 8
  %v6787 = load i64, ptr %slot99, align 8
  %v6788 = load i64, ptr %slot941, align 8
  %v6789 = load i64, ptr %slot936, align 8
  %v6790 = load i64, ptr %slot942, align 8
  %cv6791 = trunc i64 %v6790 to i32
  %call6792 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v6787, i64 %v6788, i64 %v6789, i32 %cv6791) nomerge, !dbg !168
  store i32 %call6792, ptr %slot943, align 8
  %v6793 = load i32, ptr %slot943, align 8
  %cv6794 = zext i32 %v6793 to i64
  %cond6795 = icmp ne i64 %cv6794, 0
  br i1 %cond6795, label %bb_rcsuccess1164, label %bb_rcfailure1164
bb_rcfailure1164:
  %v6796 = load i64, ptr %slot99, align 8
  %p6797 = inttoptr i64 %v6796 to ptr
  %call6798 = call i32 @myl_rc_take_failure(ptr %p6797) nomerge, !dbg !168
  store i32 %call6798, ptr %slot944, align 8
  %v6799 = load i64, ptr %slot1, align 8
  %p6800 = inttoptr i64 %v6799 to ptr
  %v6801 = load i32, ptr %slot944, align 8
  %call6802 = call i32 @myl_qbe_rc_status(ptr %p6800, i32 %v6801) nomerge, !dbg !168
  store i32 %call6802, ptr %slot945, align 8
  br label %bb_failure
bb_rcsuccess1164:
  %v6803 = load i64, ptr %slot15, align 8
  %p6804 = inttoptr i64 %v6803 to ptr
  store i32 0, ptr %p6804, align 4, !alias.scope !3, !noalias !4
  %v6805 = load i64, ptr %slot22, align 8
  %p6806 = inttoptr i64 %v6805 to ptr
  store i32 2, ptr %p6806, align 4, !alias.scope !3, !noalias !4
  %v6807 = load i64, ptr %slot21, align 8
  %p6808 = inttoptr i64 %v6807 to ptr
  store i32 1, ptr %p6808, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1154
bb_rccopy1154:
  %v6809 = load i64, ptr %slot30, align 8
  store i64 %v6809, ptr %slot946, align 8
  %v6810 = load i64, ptr %slot100, align 8
  store i64 %v6810, ptr %slot947, align 8
  %v6811 = load i64, ptr %slot99, align 8
  %v6812 = load i64, ptr %slot946, align 8
  %v6813 = load i64, ptr %slot936, align 8
  %v6814 = load i64, ptr %slot947, align 8
  %cv6815 = trunc i64 %v6814 to i32
  %call6816 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v6811, i64 %v6812, i64 %v6813, i32 %cv6815) nomerge, !dbg !168
  store i32 %call6816, ptr %slot948, align 8
  %v6817 = load i32, ptr %slot948, align 8
  %cv6818 = zext i32 %v6817 to i64
  %cond6819 = icmp ne i64 %cv6818, 0
  br i1 %cond6819, label %bb_rcsuccess1173, label %bb_rcfailure1173
bb_rcfailure1173:
  %v6820 = load i64, ptr %slot99, align 8
  %p6821 = inttoptr i64 %v6820 to ptr
  %call6822 = call i32 @myl_rc_take_failure(ptr %p6821) nomerge, !dbg !168
  store i32 %call6822, ptr %slot949, align 8
  %v6823 = load i64, ptr %slot1, align 8
  %p6824 = inttoptr i64 %v6823 to ptr
  %v6825 = load i32, ptr %slot949, align 8
  %call6826 = call i32 @myl_qbe_rc_status(ptr %p6824, i32 %v6825) nomerge, !dbg !168
  store i32 %call6826, ptr %slot950, align 8
  br label %bb_failure
bb_rcsuccess1173:
  %v6827 = load i64, ptr %slot22, align 8
  %p6828 = inttoptr i64 %v6827 to ptr
  store i32 2, ptr %p6828, align 4, !alias.scope !3, !noalias !4
  %v6829 = load i64, ptr %slot21, align 8
  %p6830 = inttoptr i64 %v6829 to ptr
  store i32 1, ptr %p6830, align 4, !alias.scope !3, !noalias !4
  %v6831 = load i64, ptr %slot15, align 8
  %p6832 = inttoptr i64 %v6831 to ptr
  %ld6833 = load i32, ptr %p6832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6833, ptr %slot951, align 8
  %v6834 = load i32, ptr %slot951, align 8
  %cv6835 = zext i32 %v6834 to i64
  %cond6836 = icmp ne i64 %cv6835, 0
  br i1 %cond6836, label %bb_rcslotdrop1180, label %bb_rcslotdone1180
bb_rcslotdrop1180:
  %v6837 = load i64, ptr %slot15, align 8
  %p6838 = inttoptr i64 %v6837 to ptr
  store i32 0, ptr %p6838, align 4, !alias.scope !3, !noalias !4
  %v6839 = load i64, ptr %slot24, align 8
  store i64 %v6839, ptr %slot952, align 8
  %v6840 = load i64, ptr %slot16, align 8
  %p6841 = inttoptr i64 %v6840 to ptr
  %ld6842 = load i32, ptr %p6841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6842, ptr %slot953, align 8
  %v6843 = load i32, ptr %slot953, align 8
  %op6844 = and i32 %v6843, 28
  store i32 %op6844, ptr %slot954, align 8
  %v6845 = load i32, ptr %slot954, align 8
  %cv6846 = zext i32 %v6845 to i64
  %cond6847 = icmp ne i64 %cv6846, 0
  br i1 %cond6847, label %bb_rcslotrole1180, label %bb_rcslotowner1180
bb_rcslotrole1180:
  %v6848 = load i64, ptr %slot99, align 8
  store i64 %v6848, ptr %slot955, align 8
  %v6849 = load i64, ptr %slot955, align 8
  %v6850 = load i64, ptr %slot952, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6849, i64 %v6850) nomerge, !dbg !168
  br label %bb_rcslotdone1180
bb_rcslotowner1180:
  %v6851 = load i64, ptr %slot99, align 8
  store i64 %v6851, ptr %slot956, align 8
  %v6852 = load i64, ptr %slot956, align 8
  %v6853 = load i64, ptr %slot952, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6852, i64 %v6853) nomerge, !dbg !168
  br label %bb_rcslotdone1180
bb_rcslotdone1180:
  br label %bb_rcprepared1154
bb_rcprepared1154:
  %v6854 = load i64, ptr %slot5, align 8
  %p6855 = inttoptr i64 %v6854 to ptr
  %ld6856 = load i32, ptr %p6855, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6856, ptr %slot957, align 8
  %v6857 = load i32, ptr %slot957, align 8
  %cv6858 = zext i32 %v6857 to i64
  %cond6859 = icmp ne i64 %cv6858, 0
  br i1 %cond6859, label %bb_rcslotdrop1190, label %bb_rcslotdone1190
bb_rcslotdrop1190:
  %v6860 = load i64, ptr %slot5, align 8
  %p6861 = inttoptr i64 %v6860 to ptr
  store i32 0, ptr %p6861, align 4, !alias.scope !3, !noalias !4
  %v6862 = load i64, ptr %slot33, align 8
  store i64 %v6862, ptr %slot958, align 8
  %v6863 = load i64, ptr %slot6, align 8
  %p6864 = inttoptr i64 %v6863 to ptr
  %ld6865 = load i32, ptr %p6864, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6865, ptr %slot959, align 8
  %v6866 = load i32, ptr %slot959, align 8
  %op6867 = and i32 %v6866, 28
  store i32 %op6867, ptr %slot960, align 8
  %v6868 = load i32, ptr %slot960, align 8
  %cv6869 = zext i32 %v6868 to i64
  %cond6870 = icmp ne i64 %cv6869, 0
  br i1 %cond6870, label %bb_rcslotrole1190, label %bb_rcslotowner1190
bb_rcslotrole1190:
  %v6871 = load i64, ptr %slot99, align 8
  store i64 %v6871, ptr %slot961, align 8
  %v6872 = load i64, ptr %slot961, align 8
  %v6873 = load i64, ptr %slot958, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v6872, i64 %v6873) nomerge, !dbg !168
  br label %bb_rcslotdone1190
bb_rcslotowner1190:
  %v6874 = load i64, ptr %slot99, align 8
  store i64 %v6874, ptr %slot962, align 8
  %v6875 = load i64, ptr %slot962, align 8
  %v6876 = load i64, ptr %slot958, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v6875, i64 %v6876) nomerge, !dbg !168
  br label %bb_rcslotdone1190
bb_rcslotdone1190:
  %v6877 = load i64, ptr %slot33, align 8
  store i64 %v6877, ptr %slot963, align 8
  %v6878 = load i64, ptr %slot30, align 8
  store i64 %v6878, ptr %slot964, align 8
  %v6879 = load i64, ptr %slot964, align 8
  %v6880 = load i64, ptr %slot963, align 8
  %p6881 = inttoptr i64 %v6879 to ptr
  %p6882 = inttoptr i64 %v6880 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6882, ptr %p6881, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v6883 = load i64, ptr %slot21, align 8
  %p6884 = inttoptr i64 %v6883 to ptr
  store i32 0, ptr %p6884, align 4, !alias.scope !3, !noalias !4
  %v6885 = load i64, ptr %slot6, align 8
  %p6886 = inttoptr i64 %v6885 to ptr
  store i32 2, ptr %p6886, align 4, !alias.scope !3, !noalias !4
  %v6887 = load i64, ptr %slot22, align 8
  %p6888 = inttoptr i64 %v6887 to ptr
  %ld6889 = load i32, ptr %p6888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6889, ptr %slot965, align 8
  %v6890 = load i32, ptr %slot965, align 8
  %v6891 = load i64, ptr %slot6, align 8
  %p6892 = inttoptr i64 %v6891 to ptr
  store i32 %v6890, ptr %p6892, align 4, !alias.scope !3, !noalias !4
  %v6893 = load i64, ptr %slot5, align 8
  %p6894 = inttoptr i64 %v6893 to ptr
  store i32 1, ptr %p6894, align 4, !alias.scope !3, !noalias !4
  %v6895 = load i64, ptr %slot32, align 8
  %p6896 = inttoptr i64 %v6895 to ptr
  %ld6897 = load i64, ptr %p6896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6897, ptr %slot966, align 8
  %v6898 = load i64, ptr %slot966, align 8
  %v6899 = load i64, ptr %slot44, align 8
  %p6900 = inttoptr i64 %v6899 to ptr
  store i64 %v6898, ptr %p6900, align 8, !alias.scope !3, !noalias !4
  %v6901 = load i64, ptr %slot32, align 8
  %p6902 = inttoptr i64 %v6901 to ptr
  %ld6903 = load i64, ptr %p6902, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6903, ptr %slot967, align 8
  %v6904 = load i64, ptr %slot967, align 8
  %v6905 = load i64, ptr %slot66, align 8
  %p6906 = inttoptr i64 %v6904 to ptr
  %p6907 = inttoptr i64 %v6905 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6907, ptr %p6906, i64 312, i1 false), !alias.scope !10000000
  %v6908 = load i64, ptr %slot66, align 8
  %v6909 = load i64, ptr %slot45, align 8
  %p6910 = inttoptr i64 %v6909 to ptr
  store i64 %v6908, ptr %p6910, align 8, !alias.scope !3, !noalias !4
  %v6911 = load i64, ptr %slot45, align 8
  %p6912 = inttoptr i64 %v6911 to ptr
  %ld6913 = load i64, ptr %p6912, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6913, ptr %slot968, align 8
  %v6914 = load i64, ptr %slot968, align 8
  %op6915 = add i64 %v6914, 248
  store i64 %op6915, ptr %slot969, align 8
  %v6916 = load i64, ptr %slot969, align 8
  %p6917 = inttoptr i64 %v6916 to ptr
  %ld6918 = load i64, ptr %p6917, align 8
  store i64 %ld6918, ptr %slot970, align 8
  %v6919 = load i64, ptr %slot970, align 8
  %v6920 = load i64, ptr %slot45, align 8
  %p6921 = inttoptr i64 %v6920 to ptr
  store i64 %v6919, ptr %p6921, align 8, !alias.scope !3, !noalias !4
  %v6922 = load i64, ptr %slot17, align 8
  %p6923 = inttoptr i64 %v6922 to ptr
  %ld6924 = load i32, ptr %p6923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6924, ptr %slot971, align 8
  %v6925 = load i32, ptr %slot971, align 8
  %cv6926 = zext i32 %v6925 to i64
  %cond6927 = icmp ne i64 %cv6926, 0
  br i1 %cond6927, label %bb_rcslotdrop1211, label %bb_rcslotdone1211
bb_rcslotdrop1211:
  %v6928 = load i64, ptr %slot17, align 8
  %p6929 = inttoptr i64 %v6928 to ptr
  store i32 0, ptr %p6929, align 4, !alias.scope !3, !noalias !4
  %v6930 = load i64, ptr %slot25, align 8
  store i64 %v6930, ptr %slot972, align 8
  %v6931 = load i64, ptr %slot18, align 8
  %p6932 = inttoptr i64 %v6931 to ptr
  %ld6933 = load i32, ptr %p6932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6933, ptr %slot973, align 8
  %v6934 = load i32, ptr %slot973, align 8
  %op6935 = and i32 %v6934, 28
  store i32 %op6935, ptr %slot974, align 8
  %v6936 = load i32, ptr %slot974, align 8
  %cv6937 = zext i32 %v6936 to i64
  %cond6938 = icmp ne i64 %cv6937, 0
  br i1 %cond6938, label %bb_rcslotrole1211, label %bb_rcslotowner1211
bb_rcslotrole1211:
  %v6939 = load i64, ptr %slot99, align 8
  store i64 %v6939, ptr %slot975, align 8
  %v6940 = load i64, ptr %slot975, align 8
  %v6941 = load i64, ptr %slot972, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v6940, i64 %v6941) nomerge, !dbg !170
  br label %bb_rcslotdone1211
bb_rcslotowner1211:
  %v6942 = load i64, ptr %slot99, align 8
  store i64 %v6942, ptr %slot976, align 8
  %v6943 = load i64, ptr %slot976, align 8
  %v6944 = load i64, ptr %slot972, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v6943, i64 %v6944) nomerge, !dbg !170
  br label %bb_rcslotdone1211
bb_rcslotdone1211:
  %v6945 = load i64, ptr %slot45, align 8
  %p6946 = inttoptr i64 %v6945 to ptr
  %ld6947 = load i64, ptr %p6946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6947, ptr %slot977, align 8
  %v6948 = load i64, ptr %slot977, align 8
  %v6949 = load i64, ptr %slot28, align 8
  %p6950 = inttoptr i64 %v6949 to ptr
  store i64 %v6948, ptr %p6950, align 8, !alias.scope !3, !noalias !4
  %v6951 = load i64, ptr %slot28, align 8
  store i64 %v6951, ptr %slot978, align 8
  %v6952 = load i64, ptr %slot17, align 8
  %p6953 = inttoptr i64 %v6952 to ptr
  %ld6954 = load i32, ptr %p6953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6954, ptr %slot979, align 8
  %v6955 = load i64, ptr %slot18, align 8
  %p6956 = inttoptr i64 %v6955 to ptr
  %ld6957 = load i32, ptr %p6956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6957, ptr %slot980, align 8
  %v6958 = load i32, ptr %slot980, align 8
  %op6959 = and i32 %v6958, 24
  store i32 %op6959, ptr %slot980, align 8
  %v6960 = load i32, ptr %slot980, align 8
  %cmp6961 = icmp eq i32 %v6960, 0
  %cv6962 = zext i1 %cmp6961 to i32
  store i32 %cv6962, ptr %slot981, align 8
  %v6963 = load i32, ptr %slot979, align 8
  %v6964 = load i32, ptr %slot981, align 8
  %op6965 = and i32 %v6963, %v6964
  store i32 %op6965, ptr %slot982, align 8
  %v6966 = load i32, ptr %slot982, align 8
  %cv6967 = zext i32 %v6966 to i64
  %cond6968 = icmp ne i64 %cv6967, 0
  br i1 %cond6968, label %bb_rcprivateown1226, label %bb_rcprivateloan1226
bb_rcprivateown1226:
  %v6969 = load i64, ptr %slot30, align 8
  store i64 %v6969, ptr %slot983, align 8
  %v6970 = load i64, ptr %slot100, align 8
  store i64 %v6970, ptr %slot984, align 8
  %v6971 = load i64, ptr %slot978, align 8
  %v6972 = load i64, ptr %slot983, align 8
  %op6973 = sub i64 %v6971, %v6972
  store i64 %op6973, ptr %slot985, align 8
  %v6974 = load i64, ptr %slot983, align 8
  %v6975 = load i64, ptr %slot978, align 8
  %op6976 = sub i64 %v6974, %v6975
  store i64 %op6976, ptr %slot986, align 8
  %v6977 = load i64, ptr %slot985, align 8
  %cmp6978 = icmp ult i64 %v6977, 8
  %cv6979 = zext i1 %cmp6978 to i32
  store i32 %cv6979, ptr %slot987, align 8
  %v6980 = load i64, ptr %slot986, align 8
  %cmp6981 = icmp ult i64 %v6980, 8
  %cv6982 = zext i1 %cmp6981 to i32
  store i32 %cv6982, ptr %slot988, align 8
  %v6983 = load i32, ptr %slot987, align 8
  %v6984 = load i32, ptr %slot988, align 8
  %op6985 = or i32 %v6983, %v6984
  store i32 %op6985, ptr %slot989, align 8
  %v6986 = load i32, ptr %slot989, align 8
  %cv6987 = zext i32 %v6986 to i64
  %cond6988 = icmp ne i64 %cv6987, 0
  br i1 %cond6988, label %bb_rcmoveslow1229, label %bb_rcmovecheck1229
bb_rcmovecheck1229:
  %v6989 = load i64, ptr %slot978, align 8
  %p6991 = inttoptr i64 %v6989 to ptr
  %gep6992 = getelementptr i8, ptr %p6991, i64 0
  %op6990 = ptrtoint ptr %gep6992 to i64
  store i64 %op6990, ptr %slot990, align 8
  %v6993 = load i64, ptr %slot990, align 8
  %p6994 = inttoptr i64 %v6993 to ptr
  %ld6995 = load i64, ptr %p6994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6995, ptr %slot991, align 8
  %v6996 = load i64, ptr %slot991, align 8
  %cmp6997 = icmp ne i64 %v6996, 0
  %cv6998 = zext i1 %cmp6997 to i32
  store i32 %cv6998, ptr %slot992, align 8
  %v6999 = load i32, ptr %slot992, align 8
  %cv7000 = zext i32 %v6999 to i64
  %cond7001 = icmp ne i64 %cv7000, 0
  br i1 %cond7001, label %bb_rcmoveheader1237, label %bb_rcmovenext1237
bb_rcmoveheader1237:
  %v7002 = load i64, ptr %slot991, align 8
  %op7003 = sub i64 %v7002, 16
  store i64 %op7003, ptr %slot993, align 8
  %v7004 = load i64, ptr %slot991, align 8
  %p7005 = inttoptr i64 %v7004 to ptr
  %rgep7006 = getelementptr i8, ptr %p7005, i64 -16
  %ld7007 = load i64, ptr %rgep7006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7007, ptr %slot994, align 8
  %v7008 = load i64, ptr %slot994, align 8
  %op7009 = and i64 %v7008, 5764607523034234881
  store i64 %op7009, ptr %slot995, align 8
  %v7010 = load i64, ptr %slot995, align 8
  %cmp7011 = icmp ne i64 %v7010, 0
  %cv7012 = zext i1 %cmp7011 to i32
  store i32 %cv7012, ptr %slot996, align 8
  %v7013 = load i32, ptr %slot996, align 8
  %cv7014 = zext i32 %v7013 to i64
  %cond7015 = icmp ne i64 %cv7014, 0
  br i1 %cond7015, label %bb_rcmoveslow1229, label %bb_rcmovenext1237
bb_rcmovenext1237:
  %v7016 = load i64, ptr %slot978, align 8
  %v7017 = load i64, ptr %slot983, align 8
  %p7018 = inttoptr i64 %v7016 to ptr
  %p7019 = inttoptr i64 %v7017 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7019, ptr %p7018, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7020 = load i64, ptr %slot978, align 8
  %p7021 = inttoptr i64 %v7020 to ptr
  store i64 0, ptr %p7021, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved1229
bb_rcmoveslow1229:
  %v7022 = load i64, ptr %slot99, align 8
  %v7023 = load i64, ptr %slot983, align 8
  %v7024 = load i64, ptr %slot978, align 8
  %v7025 = load i64, ptr %slot984, align 8
  %cv7026 = trunc i64 %v7025 to i32
  %call7027 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v7022, i64 %v7023, i64 %v7024, i32 %cv7026) nomerge, !dbg !172
  store i32 %call7027, ptr %slot997, align 8
  %v7028 = load i32, ptr %slot997, align 8
  %cv7029 = zext i32 %v7028 to i64
  %cond7030 = icmp ne i64 %cv7029, 0
  br i1 %cond7030, label %bb_rcsuccess1244, label %bb_rcfailure1244
bb_rcfailure1244:
  %v7031 = load i64, ptr %slot99, align 8
  %p7032 = inttoptr i64 %v7031 to ptr
  %call7033 = call i32 @myl_rc_take_failure(ptr %p7032) nomerge, !dbg !172
  store i32 %call7033, ptr %slot998, align 8
  %v7034 = load i64, ptr %slot1, align 8
  %p7035 = inttoptr i64 %v7034 to ptr
  %v7036 = load i32, ptr %slot998, align 8
  %call7037 = call i32 @myl_qbe_rc_status(ptr %p7035, i32 %v7036) nomerge, !dbg !172
  store i32 %call7037, ptr %slot999, align 8
  br label %bb_failure
bb_rcsuccess1244:
  br label %bb_rcmoved1229
bb_rcmoved1229:
  %v7038 = load i64, ptr %slot17, align 8
  %p7039 = inttoptr i64 %v7038 to ptr
  store i32 0, ptr %p7039, align 4, !alias.scope !3, !noalias !4
  %v7040 = load i64, ptr %slot22, align 8
  %p7041 = inttoptr i64 %v7040 to ptr
  store i32 2, ptr %p7041, align 4, !alias.scope !3, !noalias !4
  %v7042 = load i64, ptr %slot21, align 8
  %p7043 = inttoptr i64 %v7042 to ptr
  store i32 1, ptr %p7043, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1226
bb_rcprivateloan1226:
  %v7044 = load i64, ptr %slot17, align 8
  %p7045 = inttoptr i64 %v7044 to ptr
  %ld7046 = load i32, ptr %p7045, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7046, ptr %slot1000, align 8
  %v7047 = load i64, ptr %slot18, align 8
  %p7048 = inttoptr i64 %v7047 to ptr
  %ld7049 = load i32, ptr %p7048, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7049, ptr %slot1001, align 8
  %v7050 = load i32, ptr %slot1001, align 8
  %cmp7051 = icmp eq i32 %v7050, 16
  %cv7052 = zext i1 %cmp7051 to i32
  store i32 %cv7052, ptr %slot1002, align 8
  %v7053 = load i32, ptr %slot1002, align 8
  %v7054 = load i32, ptr %slot1000, align 8
  %op7055 = and i32 %v7053, %v7054
  store i32 %op7055, ptr %slot1002, align 8
  %v7056 = load i32, ptr %slot1002, align 8
  %cv7057 = zext i32 %v7056 to i64
  %cond7058 = icmp ne i64 %cv7057, 0
  br i1 %cond7058, label %bb_rcprivatemove1226, label %bb_rcprivatenew1226
bb_rcprivatemove1226:
  %v7059 = load i64, ptr %slot30, align 8
  store i64 %v7059, ptr %slot1003, align 8
  %v7060 = load i64, ptr %slot978, align 8
  %v7061 = load i64, ptr %slot1003, align 8
  %p7062 = inttoptr i64 %v7060 to ptr
  %p7063 = inttoptr i64 %v7061 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7063, ptr %p7062, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7064 = load i64, ptr %slot978, align 8
  %p7065 = inttoptr i64 %v7064 to ptr
  store i64 0, ptr %p7065, align 8, !alias.scope !3, !noalias !4
  %v7066 = load i64, ptr %slot22, align 8
  %p7067 = inttoptr i64 %v7066 to ptr
  store i32 2, ptr %p7067, align 4, !alias.scope !3, !noalias !4
  %v7068 = load i64, ptr %slot22, align 8
  %p7069 = inttoptr i64 %v7068 to ptr
  store i32 16, ptr %p7069, align 4, !alias.scope !3, !noalias !4
  %v7070 = load i64, ptr %slot21, align 8
  %p7071 = inttoptr i64 %v7070 to ptr
  store i32 1, ptr %p7071, align 4, !alias.scope !3, !noalias !4
  %v7072 = load i64, ptr %slot17, align 8
  %p7073 = inttoptr i64 %v7072 to ptr
  store i32 0, ptr %p7073, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared1226
bb_rcprivatenew1226:
  %v7074 = load i64, ptr %slot30, align 8
  store i64 %v7074, ptr %slot1004, align 8
  %v7075 = load i64, ptr %slot978, align 8
  %p7076 = inttoptr i64 %v7075 to ptr
  %ld7077 = load i64, ptr %p7076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7077, ptr %slot1005, align 8
  %v7078 = load i64, ptr %slot1005, align 8
  %cmp7079 = icmp ne i64 %v7078, 0
  %cv7080 = zext i1 %cmp7079 to i32
  store i32 %cv7080, ptr %slot1006, align 8
  %v7081 = load i32, ptr %slot1006, align 8
  %cv7082 = zext i32 %v7081 to i64
  %cond7083 = icmp ne i64 %cv7082, 0
  br i1 %cond7083, label %bb_rcgnn1262, label %bb_rcgstore1262
bb_rcgnn1262:
  %v7084 = load i64, ptr %slot1005, align 8
  %op7085 = sub i64 %v7084, 16
  store i64 %op7085, ptr %slot1007, align 8
  %v7086 = load i64, ptr %slot1005, align 8
  %p7087 = inttoptr i64 %v7086 to ptr
  %rgep7088 = getelementptr i8, ptr %p7087, i64 -16
  %ld7089 = load i64, ptr %rgep7088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7089, ptr %slot1008, align 8
  %v7090 = load i64, ptr %slot1008, align 8
  %op7091 = and i64 %v7090, 4611686018427387906
  store i64 %op7091, ptr %slot1009, align 8
  %v7092 = load i64, ptr %slot1009, align 8
  %cmp7093 = icmp ne i64 %v7092, 0
  %cv7094 = zext i1 %cmp7093 to i32
  store i32 %cv7094, ptr %slot1010, align 8
  %v7095 = load i32, ptr %slot1010, align 8
  %cv7096 = zext i32 %v7095 to i64
  %cond7097 = icmp ne i64 %cv7096, 0
  br i1 %cond7097, label %bb_rcgstore1262, label %bb_rcginc1262
bb_rcginc1262:
  %v7098 = load i64, ptr %slot1005, align 8
  %op7099 = sub i64 %v7098, 24
  store i64 %op7099, ptr %slot1011, align 8
  %v7100 = load i64, ptr %slot1005, align 8
  %p7101 = inttoptr i64 %v7100 to ptr
  %rgep7102 = getelementptr i8, ptr %p7101, i64 -24
  %ld7103 = load i64, ptr %rgep7102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7103, ptr %slot1012, align 8
  %v7104 = load i64, ptr %slot1012, align 8
  %op7105 = add i64 %v7104, 1
  store i64 %op7105, ptr %slot1013, align 8
  %v7106 = load i64, ptr %slot1013, align 8
  %cmp7107 = icmp eq i64 %v7106, 0
  %cv7108 = zext i1 %cmp7107 to i32
  store i32 %cv7108, ptr %slot1014, align 8
  %v7109 = load i32, ptr %slot1014, align 8
  %cv7110 = zext i32 %v7109 to i64
  %cond7111 = icmp ne i64 %cv7110, 0
  br i1 %cond7111, label %bb_rcglimit1262, label %bb_rcgcapacity1262
bb_rcglimit1262:
  %v7112 = load i64, ptr %slot1, align 8
  %p7113 = inttoptr i64 %v7112 to ptr
  %call7114 = call i32 @myl_qbe_rc_status(ptr %p7113, i32 2) nomerge, !dbg !172
  store i32 %call7114, ptr %slot1015, align 8
  br label %bb_failure
bb_rcgcapacity1262:
  %v7115 = load i64, ptr %slot1013, align 8
  %v7116 = load i64, ptr %slot1005, align 8
  %p7117 = inttoptr i64 %v7116 to ptr
  %rgep7118 = getelementptr i8, ptr %p7117, i64 -24
  store i64 %v7115, ptr %rgep7118, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1262
bb_rcgstore1262:
  %v7119 = load i64, ptr %slot1005, align 8
  %v7120 = load i64, ptr %slot1004, align 8
  %p7121 = inttoptr i64 %v7120 to ptr
  store i64 %v7119, ptr %p7121, align 8, !alias.scope !3, !noalias !4
  %v7122 = load i64, ptr %slot22, align 8
  %p7123 = inttoptr i64 %v7122 to ptr
  store i32 2, ptr %p7123, align 4, !alias.scope !3, !noalias !4
  %v7124 = load i64, ptr %slot22, align 8
  %p7125 = inttoptr i64 %v7124 to ptr
  store i32 16, ptr %p7125, align 4, !alias.scope !3, !noalias !4
  %v7126 = load i64, ptr %slot21, align 8
  %p7127 = inttoptr i64 %v7126 to ptr
  store i32 1, ptr %p7127, align 4, !alias.scope !3, !noalias !4
  %v7128 = load i64, ptr %slot17, align 8
  %p7129 = inttoptr i64 %v7128 to ptr
  %ld7130 = load i32, ptr %p7129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7130, ptr %slot1016, align 8
  %v7131 = load i32, ptr %slot1016, align 8
  %cv7132 = zext i32 %v7131 to i64
  %cond7133 = icmp ne i64 %cv7132, 0
  br i1 %cond7133, label %bb_rcslotdrop1278, label %bb_rcslotdone1278
bb_rcslotdrop1278:
  %v7134 = load i64, ptr %slot17, align 8
  %p7135 = inttoptr i64 %v7134 to ptr
  store i32 0, ptr %p7135, align 4, !alias.scope !3, !noalias !4
  %v7136 = load i64, ptr %slot25, align 8
  store i64 %v7136, ptr %slot1017, align 8
  %v7137 = load i64, ptr %slot18, align 8
  %p7138 = inttoptr i64 %v7137 to ptr
  %ld7139 = load i32, ptr %p7138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7139, ptr %slot1018, align 8
  %v7140 = load i32, ptr %slot1018, align 8
  %op7141 = and i32 %v7140, 28
  store i32 %op7141, ptr %slot1019, align 8
  %v7142 = load i32, ptr %slot1019, align 8
  %cv7143 = zext i32 %v7142 to i64
  %cond7144 = icmp ne i64 %cv7143, 0
  br i1 %cond7144, label %bb_rcslotrole1278, label %bb_rcslotowner1278
bb_rcslotrole1278:
  %v7145 = load i64, ptr %slot99, align 8
  store i64 %v7145, ptr %slot1020, align 8
  %v7146 = load i64, ptr %slot1017, align 8
  %p7147 = inttoptr i64 %v7146 to ptr
  %ld7148 = load i64, ptr %p7147, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7148, ptr %slot1021, align 8
  %v7149 = load i64, ptr %slot1021, align 8
  %cmp7150 = icmp ne i64 %v7149, 0
  %cv7151 = zext i1 %cmp7150 to i32
  store i32 %cv7151, ptr %slot1022, align 8
  %v7152 = load i32, ptr %slot1022, align 8
  %cv7153 = zext i32 %v7152 to i64
  %cond7154 = icmp ne i64 %cv7153, 0
  br i1 %cond7154, label %bb_rcgnn1294, label %bb_rcgdone1294
bb_rcgnn1294:
  %v7155 = load i64, ptr %slot1021, align 8
  %op7156 = sub i64 %v7155, 16
  store i64 %op7156, ptr %slot1023, align 8
  %v7157 = load i64, ptr %slot1021, align 8
  %p7158 = inttoptr i64 %v7157 to ptr
  %rgep7159 = getelementptr i8, ptr %p7158, i64 -16
  %ld7160 = load i64, ptr %rgep7159, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7160, ptr %slot1024, align 8
  %v7161 = load i64, ptr %slot1024, align 8
  %op7162 = and i64 %v7161, 4611686018427387906
  store i64 %op7162, ptr %slot1025, align 8
  %v7163 = load i64, ptr %slot1025, align 8
  %cmp7164 = icmp ne i64 %v7163, 0
  %cv7165 = zext i1 %cmp7164 to i32
  store i32 %cv7165, ptr %slot1026, align 8
  %v7166 = load i32, ptr %slot1026, align 8
  %cv7167 = zext i32 %v7166 to i64
  %cond7168 = icmp ne i64 %cv7167, 0
  br i1 %cond7168, label %bb_rcgclear1294, label %bb_rcgcounted1294
bb_rcgcounted1294:
  %v7169 = load i64, ptr %slot1021, align 8
  %op7170 = sub i64 %v7169, 24
  store i64 %op7170, ptr %slot1027, align 8
  %v7171 = load i64, ptr %slot1021, align 8
  %p7172 = inttoptr i64 %v7171 to ptr
  %rgep7173 = getelementptr i8, ptr %p7172, i64 -24
  %ld7174 = load i64, ptr %rgep7173, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7174, ptr %slot1028, align 8
  %v7175 = load i64, ptr %slot1028, align 8
  %op7176 = sub i64 %v7175, 1
  store i64 %op7176, ptr %slot1029, align 8
  %v7177 = load i64, ptr %slot1029, align 8
  %cmp7178 = icmp eq i64 %v7177, 0
  %cv7179 = zext i1 %cmp7178 to i32
  store i32 %cv7179, ptr %slot1030, align 8
  %v7180 = load i32, ptr %slot1030, align 8
  %cv7181 = zext i32 %v7180 to i64
  %cond7182 = icmp ne i64 %cv7181, 0
  br i1 %cond7182, label %bb_rcglast1294, label %bb_rcgdec1294
bb_rcglast1294:
  %v7183 = load i64, ptr %slot1021, align 8
  %op7184 = sub i64 %v7183, 32
  store i64 %op7184, ptr %slot1031, align 8
  %v7185 = load i64, ptr %slot1021, align 8
  %p7186 = inttoptr i64 %v7185 to ptr
  %rgep7187 = getelementptr i8, ptr %p7186, i64 -32
  %ld7188 = load i64, ptr %rgep7187, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7188, ptr %slot1032, align 8
  %v7189 = load i64, ptr %slot1032, align 8
  %cmp7190 = icmp ne i64 %v7189, 0
  %cv7191 = zext i1 %cmp7190 to i32
  store i32 %cv7191, ptr %slot1033, align 8
  %v7192 = load i32, ptr %slot1033, align 8
  %cv7193 = zext i32 %v7192 to i64
  %cond7194 = icmp ne i64 %cv7193, 0
  br i1 %cond7194, label %bb_rcgdec1294, label %bb_rcgslow1294
bb_rcgslow1294:
  %v7195 = load i64, ptr %slot1020, align 8
  %v7196 = load i64, ptr %slot1017, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7195, i64 %v7196) nomerge, !dbg !172
  br label %bb_rcgdone1294
bb_rcgdec1294:
  %v7197 = load i64, ptr %slot1029, align 8
  %v7198 = load i64, ptr %slot1021, align 8
  %p7199 = inttoptr i64 %v7198 to ptr
  %rgep7200 = getelementptr i8, ptr %p7199, i64 -24
  store i64 %v7197, ptr %rgep7200, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1294
bb_rcgclear1294:
  %v7201 = load i64, ptr %slot1017, align 8
  %p7202 = inttoptr i64 %v7201 to ptr
  store i64 0, ptr %p7202, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1294
bb_rcgdone1294:
  br label %bb_rcslotdone1278
bb_rcslotowner1278:
  %v7203 = load i64, ptr %slot99, align 8
  store i64 %v7203, ptr %slot1034, align 8
  %v7204 = load i64, ptr %slot1017, align 8
  %p7205 = inttoptr i64 %v7204 to ptr
  %ld7206 = load i64, ptr %p7205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7206, ptr %slot1035, align 8
  %v7207 = load i64, ptr %slot1035, align 8
  %cmp7208 = icmp ne i64 %v7207, 0
  %cv7209 = zext i1 %cmp7208 to i32
  store i32 %cv7209, ptr %slot1036, align 8
  %v7210 = load i32, ptr %slot1036, align 8
  %cv7211 = zext i32 %v7210 to i64
  %cond7212 = icmp ne i64 %cv7211, 0
  br i1 %cond7212, label %bb_rcgnn1309, label %bb_rcgdone1309
bb_rcgnn1309:
  %v7213 = load i64, ptr %slot1035, align 8
  %op7214 = sub i64 %v7213, 16
  store i64 %op7214, ptr %slot1037, align 8
  %v7215 = load i64, ptr %slot1035, align 8
  %p7216 = inttoptr i64 %v7215 to ptr
  %rgep7217 = getelementptr i8, ptr %p7216, i64 -16
  %ld7218 = load i64, ptr %rgep7217, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7218, ptr %slot1038, align 8
  %v7219 = load i64, ptr %slot1038, align 8
  %op7220 = and i64 %v7219, 4611686018427387906
  store i64 %op7220, ptr %slot1039, align 8
  %v7221 = load i64, ptr %slot1039, align 8
  %cmp7222 = icmp ne i64 %v7221, 0
  %cv7223 = zext i1 %cmp7222 to i32
  store i32 %cv7223, ptr %slot1040, align 8
  %v7224 = load i32, ptr %slot1040, align 8
  %cv7225 = zext i32 %v7224 to i64
  %cond7226 = icmp ne i64 %cv7225, 0
  br i1 %cond7226, label %bb_rcgclear1309, label %bb_rcgcounted1309
bb_rcgcounted1309:
  %v7227 = load i64, ptr %slot1035, align 8
  %op7228 = sub i64 %v7227, 32
  store i64 %op7228, ptr %slot1041, align 8
  %v7229 = load i64, ptr %slot1035, align 8
  %p7230 = inttoptr i64 %v7229 to ptr
  %rgep7231 = getelementptr i8, ptr %p7230, i64 -32
  %ld7232 = load i64, ptr %rgep7231, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7232, ptr %slot1042, align 8
  %v7233 = load i64, ptr %slot1042, align 8
  %op7234 = sub i64 %v7233, 1
  store i64 %op7234, ptr %slot1043, align 8
  %v7235 = load i64, ptr %slot1043, align 8
  %cmp7236 = icmp eq i64 %v7235, 0
  %cv7237 = zext i1 %cmp7236 to i32
  store i32 %cv7237, ptr %slot1044, align 8
  %v7238 = load i32, ptr %slot1044, align 8
  %cv7239 = zext i32 %v7238 to i64
  %cond7240 = icmp ne i64 %cv7239, 0
  br i1 %cond7240, label %bb_rcglast1309, label %bb_rcgdec1309
bb_rcglast1309:
  %v7241 = load i64, ptr %slot1035, align 8
  %op7242 = sub i64 %v7241, 24
  store i64 %op7242, ptr %slot1045, align 8
  %v7243 = load i64, ptr %slot1035, align 8
  %p7244 = inttoptr i64 %v7243 to ptr
  %rgep7245 = getelementptr i8, ptr %p7244, i64 -24
  %ld7246 = load i64, ptr %rgep7245, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7246, ptr %slot1046, align 8
  %v7247 = load i64, ptr %slot1046, align 8
  %cmp7248 = icmp ne i64 %v7247, 0
  %cv7249 = zext i1 %cmp7248 to i32
  store i32 %cv7249, ptr %slot1047, align 8
  %v7250 = load i32, ptr %slot1047, align 8
  %cv7251 = zext i32 %v7250 to i64
  %cond7252 = icmp ne i64 %cv7251, 0
  br i1 %cond7252, label %bb_rcgdec1309, label %bb_rcgslow1309
bb_rcgslow1309:
  %v7253 = load i64, ptr %slot1034, align 8
  %v7254 = load i64, ptr %slot1017, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7253, i64 %v7254) nomerge, !dbg !172
  br label %bb_rcgdone1309
bb_rcgdec1309:
  %v7255 = load i64, ptr %slot1043, align 8
  %v7256 = load i64, ptr %slot1035, align 8
  %p7257 = inttoptr i64 %v7256 to ptr
  %rgep7258 = getelementptr i8, ptr %p7257, i64 -32
  store i64 %v7255, ptr %rgep7258, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1309
bb_rcgclear1309:
  %v7259 = load i64, ptr %slot1017, align 8
  %p7260 = inttoptr i64 %v7259 to ptr
  store i64 0, ptr %p7260, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1309
bb_rcgdone1309:
  br label %bb_rcslotdone1278
bb_rcslotdone1278:
  br label %bb_rcprivateprepared1226
bb_rcprivateprepared1226:
  %v7261 = load i64, ptr %slot9, align 8
  %p7262 = inttoptr i64 %v7261 to ptr
  %ld7263 = load i32, ptr %p7262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7263, ptr %slot1048, align 8
  %v7264 = load i32, ptr %slot1048, align 8
  %cv7265 = zext i32 %v7264 to i64
  %cond7266 = icmp ne i64 %cv7265, 0
  br i1 %cond7266, label %bb_rcslotdrop1316, label %bb_rcslotdone1316
bb_rcslotdrop1316:
  %v7267 = load i64, ptr %slot9, align 8
  %p7268 = inttoptr i64 %v7267 to ptr
  store i32 0, ptr %p7268, align 4, !alias.scope !3, !noalias !4
  %v7269 = load i64, ptr %slot39, align 8
  store i64 %v7269, ptr %slot1049, align 8
  %v7270 = load i64, ptr %slot10, align 8
  %p7271 = inttoptr i64 %v7270 to ptr
  %ld7272 = load i32, ptr %p7271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7272, ptr %slot1050, align 8
  %v7273 = load i32, ptr %slot1050, align 8
  %op7274 = and i32 %v7273, 28
  store i32 %op7274, ptr %slot1051, align 8
  %v7275 = load i32, ptr %slot1051, align 8
  %cv7276 = zext i32 %v7275 to i64
  %cond7277 = icmp ne i64 %cv7276, 0
  br i1 %cond7277, label %bb_rcslotrole1316, label %bb_rcslotowner1316
bb_rcslotrole1316:
  %v7278 = load i64, ptr %slot99, align 8
  store i64 %v7278, ptr %slot1052, align 8
  %v7279 = load i64, ptr %slot1049, align 8
  %p7280 = inttoptr i64 %v7279 to ptr
  %ld7281 = load i64, ptr %p7280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7281, ptr %slot1053, align 8
  %v7282 = load i64, ptr %slot1053, align 8
  %cmp7283 = icmp ne i64 %v7282, 0
  %cv7284 = zext i1 %cmp7283 to i32
  store i32 %cv7284, ptr %slot1054, align 8
  %v7285 = load i32, ptr %slot1054, align 8
  %cv7286 = zext i32 %v7285 to i64
  %cond7287 = icmp ne i64 %cv7286, 0
  br i1 %cond7287, label %bb_rcgnn1332, label %bb_rcgdone1332
bb_rcgnn1332:
  %v7288 = load i64, ptr %slot1053, align 8
  %op7289 = sub i64 %v7288, 16
  store i64 %op7289, ptr %slot1055, align 8
  %v7290 = load i64, ptr %slot1053, align 8
  %p7291 = inttoptr i64 %v7290 to ptr
  %rgep7292 = getelementptr i8, ptr %p7291, i64 -16
  %ld7293 = load i64, ptr %rgep7292, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7293, ptr %slot1056, align 8
  %v7294 = load i64, ptr %slot1056, align 8
  %op7295 = and i64 %v7294, 4611686018427387906
  store i64 %op7295, ptr %slot1057, align 8
  %v7296 = load i64, ptr %slot1057, align 8
  %cmp7297 = icmp ne i64 %v7296, 0
  %cv7298 = zext i1 %cmp7297 to i32
  store i32 %cv7298, ptr %slot1058, align 8
  %v7299 = load i32, ptr %slot1058, align 8
  %cv7300 = zext i32 %v7299 to i64
  %cond7301 = icmp ne i64 %cv7300, 0
  br i1 %cond7301, label %bb_rcgclear1332, label %bb_rcgcounted1332
bb_rcgcounted1332:
  %v7302 = load i64, ptr %slot1053, align 8
  %op7303 = sub i64 %v7302, 24
  store i64 %op7303, ptr %slot1059, align 8
  %v7304 = load i64, ptr %slot1053, align 8
  %p7305 = inttoptr i64 %v7304 to ptr
  %rgep7306 = getelementptr i8, ptr %p7305, i64 -24
  %ld7307 = load i64, ptr %rgep7306, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7307, ptr %slot1060, align 8
  %v7308 = load i64, ptr %slot1060, align 8
  %op7309 = sub i64 %v7308, 1
  store i64 %op7309, ptr %slot1061, align 8
  %v7310 = load i64, ptr %slot1061, align 8
  %cmp7311 = icmp eq i64 %v7310, 0
  %cv7312 = zext i1 %cmp7311 to i32
  store i32 %cv7312, ptr %slot1062, align 8
  %v7313 = load i32, ptr %slot1062, align 8
  %cv7314 = zext i32 %v7313 to i64
  %cond7315 = icmp ne i64 %cv7314, 0
  br i1 %cond7315, label %bb_rcglast1332, label %bb_rcgdec1332
bb_rcglast1332:
  %v7316 = load i64, ptr %slot1053, align 8
  %op7317 = sub i64 %v7316, 32
  store i64 %op7317, ptr %slot1063, align 8
  %v7318 = load i64, ptr %slot1053, align 8
  %p7319 = inttoptr i64 %v7318 to ptr
  %rgep7320 = getelementptr i8, ptr %p7319, i64 -32
  %ld7321 = load i64, ptr %rgep7320, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7321, ptr %slot1064, align 8
  %v7322 = load i64, ptr %slot1064, align 8
  %cmp7323 = icmp ne i64 %v7322, 0
  %cv7324 = zext i1 %cmp7323 to i32
  store i32 %cv7324, ptr %slot1065, align 8
  %v7325 = load i32, ptr %slot1065, align 8
  %cv7326 = zext i32 %v7325 to i64
  %cond7327 = icmp ne i64 %cv7326, 0
  br i1 %cond7327, label %bb_rcgdec1332, label %bb_rcgslow1332
bb_rcgslow1332:
  %v7328 = load i64, ptr %slot1052, align 8
  %v7329 = load i64, ptr %slot1049, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7328, i64 %v7329) nomerge, !dbg !172
  br label %bb_rcgdone1332
bb_rcgdec1332:
  %v7330 = load i64, ptr %slot1061, align 8
  %v7331 = load i64, ptr %slot1053, align 8
  %p7332 = inttoptr i64 %v7331 to ptr
  %rgep7333 = getelementptr i8, ptr %p7332, i64 -24
  store i64 %v7330, ptr %rgep7333, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1332
bb_rcgclear1332:
  %v7334 = load i64, ptr %slot1049, align 8
  %p7335 = inttoptr i64 %v7334 to ptr
  store i64 0, ptr %p7335, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1332
bb_rcgdone1332:
  br label %bb_rcslotdone1316
bb_rcslotowner1316:
  %v7336 = load i64, ptr %slot99, align 8
  store i64 %v7336, ptr %slot1066, align 8
  %v7337 = load i64, ptr %slot1049, align 8
  %p7338 = inttoptr i64 %v7337 to ptr
  %ld7339 = load i64, ptr %p7338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7339, ptr %slot1067, align 8
  %v7340 = load i64, ptr %slot1067, align 8
  %cmp7341 = icmp ne i64 %v7340, 0
  %cv7342 = zext i1 %cmp7341 to i32
  store i32 %cv7342, ptr %slot1068, align 8
  %v7343 = load i32, ptr %slot1068, align 8
  %cv7344 = zext i32 %v7343 to i64
  %cond7345 = icmp ne i64 %cv7344, 0
  br i1 %cond7345, label %bb_rcgnn1347, label %bb_rcgdone1347
bb_rcgnn1347:
  %v7346 = load i64, ptr %slot1067, align 8
  %op7347 = sub i64 %v7346, 16
  store i64 %op7347, ptr %slot1069, align 8
  %v7348 = load i64, ptr %slot1067, align 8
  %p7349 = inttoptr i64 %v7348 to ptr
  %rgep7350 = getelementptr i8, ptr %p7349, i64 -16
  %ld7351 = load i64, ptr %rgep7350, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7351, ptr %slot1070, align 8
  %v7352 = load i64, ptr %slot1070, align 8
  %op7353 = and i64 %v7352, 4611686018427387906
  store i64 %op7353, ptr %slot1071, align 8
  %v7354 = load i64, ptr %slot1071, align 8
  %cmp7355 = icmp ne i64 %v7354, 0
  %cv7356 = zext i1 %cmp7355 to i32
  store i32 %cv7356, ptr %slot1072, align 8
  %v7357 = load i32, ptr %slot1072, align 8
  %cv7358 = zext i32 %v7357 to i64
  %cond7359 = icmp ne i64 %cv7358, 0
  br i1 %cond7359, label %bb_rcgclear1347, label %bb_rcgcounted1347
bb_rcgcounted1347:
  %v7360 = load i64, ptr %slot1067, align 8
  %op7361 = sub i64 %v7360, 32
  store i64 %op7361, ptr %slot1073, align 8
  %v7362 = load i64, ptr %slot1067, align 8
  %p7363 = inttoptr i64 %v7362 to ptr
  %rgep7364 = getelementptr i8, ptr %p7363, i64 -32
  %ld7365 = load i64, ptr %rgep7364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7365, ptr %slot1074, align 8
  %v7366 = load i64, ptr %slot1074, align 8
  %op7367 = sub i64 %v7366, 1
  store i64 %op7367, ptr %slot1075, align 8
  %v7368 = load i64, ptr %slot1075, align 8
  %cmp7369 = icmp eq i64 %v7368, 0
  %cv7370 = zext i1 %cmp7369 to i32
  store i32 %cv7370, ptr %slot1076, align 8
  %v7371 = load i32, ptr %slot1076, align 8
  %cv7372 = zext i32 %v7371 to i64
  %cond7373 = icmp ne i64 %cv7372, 0
  br i1 %cond7373, label %bb_rcglast1347, label %bb_rcgdec1347
bb_rcglast1347:
  %v7374 = load i64, ptr %slot1067, align 8
  %op7375 = sub i64 %v7374, 24
  store i64 %op7375, ptr %slot1077, align 8
  %v7376 = load i64, ptr %slot1067, align 8
  %p7377 = inttoptr i64 %v7376 to ptr
  %rgep7378 = getelementptr i8, ptr %p7377, i64 -24
  %ld7379 = load i64, ptr %rgep7378, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7379, ptr %slot1078, align 8
  %v7380 = load i64, ptr %slot1078, align 8
  %cmp7381 = icmp ne i64 %v7380, 0
  %cv7382 = zext i1 %cmp7381 to i32
  store i32 %cv7382, ptr %slot1079, align 8
  %v7383 = load i32, ptr %slot1079, align 8
  %cv7384 = zext i32 %v7383 to i64
  %cond7385 = icmp ne i64 %cv7384, 0
  br i1 %cond7385, label %bb_rcgdec1347, label %bb_rcgslow1347
bb_rcgslow1347:
  %v7386 = load i64, ptr %slot1066, align 8
  %v7387 = load i64, ptr %slot1049, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7386, i64 %v7387) nomerge, !dbg !172
  br label %bb_rcgdone1347
bb_rcgdec1347:
  %v7388 = load i64, ptr %slot1075, align 8
  %v7389 = load i64, ptr %slot1067, align 8
  %p7390 = inttoptr i64 %v7389 to ptr
  %rgep7391 = getelementptr i8, ptr %p7390, i64 -32
  store i64 %v7388, ptr %rgep7391, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1347
bb_rcgclear1347:
  %v7392 = load i64, ptr %slot1049, align 8
  %p7393 = inttoptr i64 %v7392 to ptr
  store i64 0, ptr %p7393, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1347
bb_rcgdone1347:
  br label %bb_rcslotdone1316
bb_rcslotdone1316:
  %v7394 = load i64, ptr %slot39, align 8
  store i64 %v7394, ptr %slot1080, align 8
  %v7395 = load i64, ptr %slot30, align 8
  store i64 %v7395, ptr %slot1081, align 8
  %v7396 = load i64, ptr %slot1081, align 8
  %v7397 = load i64, ptr %slot1080, align 8
  %p7398 = inttoptr i64 %v7396 to ptr
  %p7399 = inttoptr i64 %v7397 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7399, ptr %p7398, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7400 = load i64, ptr %slot21, align 8
  %p7401 = inttoptr i64 %v7400 to ptr
  store i32 0, ptr %p7401, align 4, !alias.scope !3, !noalias !4
  %v7402 = load i64, ptr %slot10, align 8
  %p7403 = inttoptr i64 %v7402 to ptr
  store i32 2, ptr %p7403, align 4, !alias.scope !3, !noalias !4
  %v7404 = load i64, ptr %slot22, align 8
  %p7405 = inttoptr i64 %v7404 to ptr
  %ld7406 = load i32, ptr %p7405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7406, ptr %slot1082, align 8
  %v7407 = load i32, ptr %slot1082, align 8
  %v7408 = load i64, ptr %slot10, align 8
  %p7409 = inttoptr i64 %v7408 to ptr
  store i32 %v7407, ptr %p7409, align 4, !alias.scope !3, !noalias !4
  %v7410 = load i64, ptr %slot9, align 8
  %p7411 = inttoptr i64 %v7410 to ptr
  store i32 1, ptr %p7411, align 4, !alias.scope !3, !noalias !4
  %v7412 = load i64, ptr %slot33, align 8
  %v7413 = load i64, ptr %slot45, align 8
  %p7414 = inttoptr i64 %v7413 to ptr
  store i64 %v7412, ptr %p7414, align 8, !alias.scope !3, !noalias !4
  %v7415 = load i64, ptr %slot45, align 8
  %p7416 = inttoptr i64 %v7415 to ptr
  %ld7417 = load i64, ptr %p7416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7417, ptr %slot1083, align 8
  %v7418 = load i64, ptr %slot1083, align 8
  %op7419 = add i64 %v7418, 8
  store i64 %op7419, ptr %slot1084, align 8
  %v7420 = load i64, ptr %slot1084, align 8
  %p7421 = inttoptr i64 %v7420 to ptr
  %ld7422 = load i64, ptr %p7421, align 8
  store i64 %ld7422, ptr %slot1085, align 8
  %v7423 = load i64, ptr %slot1085, align 8
  %v7424 = load i64, ptr %slot45, align 8
  %p7425 = inttoptr i64 %v7424 to ptr
  store i64 %v7423, ptr %p7425, align 8, !alias.scope !3, !noalias !4
  %v7426 = load i64, ptr %slot17, align 8
  %p7427 = inttoptr i64 %v7426 to ptr
  %ld7428 = load i32, ptr %p7427, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7428, ptr %slot1086, align 8
  %v7429 = load i32, ptr %slot1086, align 8
  %cv7430 = zext i32 %v7429 to i64
  %cond7431 = icmp ne i64 %cv7430, 0
  br i1 %cond7431, label %bb_rcslotdrop1363, label %bb_rcslotdone1363
bb_rcslotdrop1363:
  %v7432 = load i64, ptr %slot17, align 8
  %p7433 = inttoptr i64 %v7432 to ptr
  store i32 0, ptr %p7433, align 4, !alias.scope !3, !noalias !4
  %v7434 = load i64, ptr %slot25, align 8
  store i64 %v7434, ptr %slot1087, align 8
  %v7435 = load i64, ptr %slot18, align 8
  %p7436 = inttoptr i64 %v7435 to ptr
  %ld7437 = load i32, ptr %p7436, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7437, ptr %slot1088, align 8
  %v7438 = load i32, ptr %slot1088, align 8
  %op7439 = and i32 %v7438, 28
  store i32 %op7439, ptr %slot1089, align 8
  %v7440 = load i32, ptr %slot1089, align 8
  %cv7441 = zext i32 %v7440 to i64
  %cond7442 = icmp ne i64 %cv7441, 0
  br i1 %cond7442, label %bb_rcslotrole1363, label %bb_rcslotowner1363
bb_rcslotrole1363:
  %v7443 = load i64, ptr %slot99, align 8
  store i64 %v7443, ptr %slot1090, align 8
  %v7444 = load i64, ptr %slot1090, align 8
  %v7445 = load i64, ptr %slot1087, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v7444, i64 %v7445) nomerge, !dbg !174
  br label %bb_rcslotdone1363
bb_rcslotowner1363:
  %v7446 = load i64, ptr %slot99, align 8
  store i64 %v7446, ptr %slot1091, align 8
  %v7447 = load i64, ptr %slot1091, align 8
  %v7448 = load i64, ptr %slot1087, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v7447, i64 %v7448) nomerge, !dbg !174
  br label %bb_rcslotdone1363
bb_rcslotdone1363:
  %v7449 = load i64, ptr %slot46, align 8
  %p7450 = inttoptr i64 %v7449 to ptr
  store i64 1, ptr %p7450, align 8, !alias.scope !3, !noalias !4
  %v7451 = load i64, ptr %slot46, align 8
  %p7452 = inttoptr i64 %v7451 to ptr
  %ld7453 = load i64, ptr %p7452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7453, ptr %slot1092, align 8
  %v7454 = load i64, ptr %slot45, align 8
  %p7455 = inttoptr i64 %v7454 to ptr
  %ld7456 = load i64, ptr %p7455, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7456, ptr %slot1093, align 8
  %v7457 = load i64, ptr %slot1093, align 8
  %v7458 = load i64, ptr %slot1092, align 8
  %ovpair7460 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v7457, i64 %v7458)
  %op7459 = extractvalue { i64, i1 } %ovpair7460, 0
  %ov7461 = extractvalue { i64, i1 } %ovpair7460, 1
  store i64 %op7459, ptr %slot1094, align 8
  %cv7462 = zext i1 %ov7461 to i64
  store i64 %cv7462, ptr %slot1095, align 8
  %v7463 = load i64, ptr %slot1095, align 8
  %cond7464 = icmp ne i64 %v7463, 0
  br i1 %cond7464, label %bb_overflow1372, label %bb_checked1372
bb_overflow1372:
  %v7465 = load i64, ptr %slot1, align 8
  %p7466 = inttoptr i64 %v7465 to ptr
  %v7467 = load i64, ptr %slot1093, align 8
  %v7468 = load i64, ptr %slot1092, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p7466, i64 0, i64 %v7467, i64 %v7468, i64 64) nomerge, !dbg !176
  unreachable
bb_checked1372:
  %v7469 = load i64, ptr %slot1094, align 8
  %v7470 = load i64, ptr %slot45, align 8
  %p7471 = inttoptr i64 %v7470 to ptr
  store i64 %v7469, ptr %p7471, align 8, !alias.scope !3, !noalias !4
  %v7472 = load i64, ptr %slot33, align 8
  %v7473 = load i64, ptr %slot46, align 8
  %p7474 = inttoptr i64 %v7473 to ptr
  store i64 %v7472, ptr %p7474, align 8, !alias.scope !3, !noalias !4
  %v7475 = load i64, ptr %slot46, align 8
  %p7476 = inttoptr i64 %v7475 to ptr
  %ld7477 = load i64, ptr %p7476, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7477, ptr %slot1096, align 8
  %v7478 = load i64, ptr %slot1096, align 8
  %op7479 = add i64 %v7478, 8
  store i64 %op7479, ptr %slot1097, align 8
  %v7480 = load i64, ptr %slot1097, align 8
  %p7481 = inttoptr i64 %v7480 to ptr
  %ld7482 = load i64, ptr %p7481, align 8
  store i64 %ld7482, ptr %slot1098, align 8
  %v7483 = load i64, ptr %slot1098, align 8
  %v7484 = load i64, ptr %slot46, align 8
  %p7485 = inttoptr i64 %v7484 to ptr
  store i64 %v7483, ptr %p7485, align 8, !alias.scope !3, !noalias !4
  %v7486 = load i64, ptr %slot19, align 8
  %p7487 = inttoptr i64 %v7486 to ptr
  %ld7488 = load i32, ptr %p7487, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7488, ptr %slot1099, align 8
  %v7489 = load i32, ptr %slot1099, align 8
  %cv7490 = zext i32 %v7489 to i64
  %cond7491 = icmp ne i64 %cv7490, 0
  br i1 %cond7491, label %bb_rcslotdrop1379, label %bb_rcslotdone1379
bb_rcslotdrop1379:
  %v7492 = load i64, ptr %slot19, align 8
  %p7493 = inttoptr i64 %v7492 to ptr
  store i32 0, ptr %p7493, align 4, !alias.scope !3, !noalias !4
  %v7494 = load i64, ptr %slot26, align 8
  store i64 %v7494, ptr %slot1100, align 8
  %v7495 = load i64, ptr %slot20, align 8
  %p7496 = inttoptr i64 %v7495 to ptr
  %ld7497 = load i32, ptr %p7496, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7497, ptr %slot1101, align 8
  %v7498 = load i32, ptr %slot1101, align 8
  %op7499 = and i32 %v7498, 28
  store i32 %op7499, ptr %slot1102, align 8
  %v7500 = load i32, ptr %slot1102, align 8
  %cv7501 = zext i32 %v7500 to i64
  %cond7502 = icmp ne i64 %cv7501, 0
  br i1 %cond7502, label %bb_rcslotrole1379, label %bb_rcslotowner1379
bb_rcslotrole1379:
  %v7503 = load i64, ptr %slot99, align 8
  store i64 %v7503, ptr %slot1103, align 8
  %v7504 = load i64, ptr %slot1103, align 8
  %v7505 = load i64, ptr %slot1100, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v7504, i64 %v7505) nomerge, !dbg !178
  br label %bb_rcslotdone1379
bb_rcslotowner1379:
  %v7506 = load i64, ptr %slot99, align 8
  store i64 %v7506, ptr %slot1104, align 8
  %v7507 = load i64, ptr %slot1104, align 8
  %v7508 = load i64, ptr %slot1100, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v7507, i64 %v7508) nomerge, !dbg !178
  br label %bb_rcslotdone1379
bb_rcslotdone1379:
  %v7509 = load i64, ptr %slot33, align 8
  %v7510 = load i64, ptr %slot47, align 8
  %p7511 = inttoptr i64 %v7510 to ptr
  store i64 %v7509, ptr %p7511, align 8, !alias.scope !3, !noalias !4
  %v7512 = load i64, ptr %slot47, align 8
  %p7513 = inttoptr i64 %v7512 to ptr
  %ld7514 = load i64, ptr %p7513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7514, ptr %slot1105, align 8
  %v7515 = load i64, ptr %slot1105, align 8
  %op7516 = add i64 %v7515, 16
  store i64 %op7516, ptr %slot1106, align 8
  %v7517 = load i64, ptr %slot1106, align 8
  %p7518 = inttoptr i64 %v7517 to ptr
  %ld7519 = load i64, ptr %p7518, align 8
  store i64 %ld7519, ptr %slot1107, align 8
  %v7520 = load i64, ptr %slot1107, align 8
  %v7521 = load i64, ptr %slot47, align 8
  %p7522 = inttoptr i64 %v7521 to ptr
  store i64 %v7520, ptr %p7522, align 8, !alias.scope !3, !noalias !4
  %v7523 = load i64, ptr %slot47, align 8
  %p7524 = inttoptr i64 %v7523 to ptr
  %ld7525 = load i64, ptr %p7524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7525, ptr %slot1108, align 8
  %v7526 = load i64, ptr %slot46, align 8
  %p7527 = inttoptr i64 %v7526 to ptr
  %ld7528 = load i64, ptr %p7527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7528, ptr %slot1109, align 8
  %v7529 = load i64, ptr %slot1109, align 8
  %v7530 = load i64, ptr %slot1108, align 8
  %ovpair7532 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v7529, i64 %v7530)
  %op7531 = extractvalue { i64, i1 } %ovpair7532, 0
  %ov7533 = extractvalue { i64, i1 } %ovpair7532, 1
  store i64 %op7531, ptr %slot1110, align 8
  %v7534 = load i64, ptr %slot1109, align 8
  %v7535 = load i64, ptr %slot1110, align 8
  %op7536 = xor i64 %v7534, %v7535
  store i64 %op7536, ptr %slot1111, align 8
  %v7537 = load i64, ptr %slot1108, align 8
  %v7538 = load i64, ptr %slot1110, align 8
  %op7539 = xor i64 %v7537, %v7538
  store i64 %op7539, ptr %slot1112, align 8
  %v7540 = load i64, ptr %slot1111, align 8
  %v7541 = load i64, ptr %slot1112, align 8
  %op7542 = and i64 %v7540, %v7541
  store i64 %op7542, ptr %slot1113, align 8
  %cv7543 = zext i1 %ov7533 to i64
  store i64 %cv7543, ptr %slot1114, align 8
  %v7544 = load i64, ptr %slot1114, align 8
  %cond7545 = icmp ne i64 %v7544, 0
  br i1 %cond7545, label %bb_overflow1400, label %bb_checked1400
bb_overflow1400:
  %v7546 = load i64, ptr %slot1, align 8
  %p7547 = inttoptr i64 %v7546 to ptr
  %v7548 = load i64, ptr %slot1109, align 8
  %v7549 = load i64, ptr %slot1108, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p7547, i64 0, i64 %v7548, i64 %v7549, i64 64) nomerge, !dbg !180
  unreachable
bb_checked1400:
  %v7550 = load i64, ptr %slot1110, align 8
  %v7551 = load i64, ptr %slot46, align 8
  %p7552 = inttoptr i64 %v7551 to ptr
  store i64 %v7550, ptr %p7552, align 8, !alias.scope !3, !noalias !4
  %v7553 = load i64, ptr %slot47, align 8
  %p7554 = inttoptr i64 %v7553 to ptr
  store i64 1, ptr %p7554, align 8, !alias.scope !3, !noalias !4
  %v7555 = load i64, ptr %slot47, align 8
  %p7556 = inttoptr i64 %v7555 to ptr
  %ld7557 = load i64, ptr %p7556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7557, ptr %slot1115, align 8
  %v7558 = load i64, ptr %slot46, align 8
  %p7559 = inttoptr i64 %v7558 to ptr
  %ld7560 = load i64, ptr %p7559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7560, ptr %slot1116, align 8
  %v7561 = load i64, ptr %slot1116, align 8
  %v7562 = load i64, ptr %slot1115, align 8
  %ovpair7564 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v7561, i64 %v7562)
  %op7563 = extractvalue { i64, i1 } %ovpair7564, 0
  %ov7565 = extractvalue { i64, i1 } %ovpair7564, 1
  store i64 %op7563, ptr %slot1117, align 8
  %cv7566 = zext i1 %ov7565 to i64
  store i64 %cv7566, ptr %slot1118, align 8
  %v7567 = load i64, ptr %slot1118, align 8
  %cond7568 = icmp ne i64 %v7567, 0
  br i1 %cond7568, label %bb_overflow1407, label %bb_checked1407
bb_overflow1407:
  %v7569 = load i64, ptr %slot1, align 8
  %p7570 = inttoptr i64 %v7569 to ptr
  %v7571 = load i64, ptr %slot1116, align 8
  %v7572 = load i64, ptr %slot1115, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p7570, i64 1, i64 %v7571, i64 %v7572, i64 64) nomerge, !dbg !182
  unreachable
bb_checked1407:
  %v7573 = load i64, ptr %slot1117, align 8
  %v7574 = load i64, ptr %slot46, align 8
  %p7575 = inttoptr i64 %v7574 to ptr
  store i64 %v7573, ptr %p7575, align 8, !alias.scope !3, !noalias !4
  %v7576 = load i64, ptr %slot39, align 8
  %p7577 = inttoptr i64 %v7576 to ptr
  %ld7578 = load i64, ptr %p7577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7578, ptr %slot1119, align 8
  %v7579 = load i64, ptr %slot45, align 8
  %p7580 = inttoptr i64 %v7579 to ptr
  %ld7581 = load i64, ptr %p7580, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7581, ptr %slot1120, align 8
  %v7582 = load i64, ptr %slot46, align 8
  %p7583 = inttoptr i64 %v7582 to ptr
  %ld7584 = load i64, ptr %p7583, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7584, ptr %slot1121, align 8
  %v7585 = load i64, ptr %slot99, align 8
  %p7586 = inttoptr i64 %v7585 to ptr
  %v7587 = load i64, ptr %slot1119, align 8
  %p7588 = inttoptr i64 %v7587 to ptr
  %v7589 = load i64, ptr %slot1120, align 8
  %v7590 = load i64, ptr %slot1121, align 8
  %call7591 = call ptr @myl_native_bytes_view(ptr %p7586, ptr %p7588, i64 %v7589, i64 %v7590) nomerge, !dbg !184
  %calladdr7592 = ptrtoint ptr %call7591 to i64
  store i64 %calladdr7592, ptr %slot1122, align 8
  %v7593 = load i64, ptr %slot1122, align 8
  %cond7594 = icmp ne i64 %v7593, 0
  br i1 %cond7594, label %bb_success1413, label %bb_failed1413
bb_failed1413:
  %v7595 = load i64, ptr %slot1, align 8
  %p7596 = inttoptr i64 %v7595 to ptr
  call void @myl_qbe_fail_allocation(ptr %p7596) nomerge, !dbg !184
  unreachable
bb_success1413:
  %v7597 = load i64, ptr %slot1122, align 8
  %v7598 = load i64, ptr %slot45, align 8
  %p7599 = inttoptr i64 %v7598 to ptr
  store i64 %v7597, ptr %p7599, align 8, !alias.scope !3, !noalias !4
  %v7600 = load i64, ptr %slot45, align 8
  %p7601 = inttoptr i64 %v7600 to ptr
  %ld7602 = load i64, ptr %p7601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7602, ptr %slot1123, align 8
  %v7603 = load i64, ptr %slot1123, align 8
  %v7604 = load i64, ptr %slot28, align 8
  %p7605 = inttoptr i64 %v7604 to ptr
  store i64 %v7603, ptr %p7605, align 8, !alias.scope !3, !noalias !4
  %v7606 = load i64, ptr %slot28, align 8
  store i64 %v7606, ptr %slot1124, align 8
  %v7607 = load i64, ptr %slot30, align 8
  store i64 %v7607, ptr %slot1125, align 8
  %v7608 = load i64, ptr %slot1124, align 8
  %v7609 = load i64, ptr %slot1125, align 8
  %p7610 = inttoptr i64 %v7608 to ptr
  %p7611 = inttoptr i64 %v7609 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7611, ptr %p7610, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7612 = load i64, ptr %slot22, align 8
  %p7613 = inttoptr i64 %v7612 to ptr
  store i32 2, ptr %p7613, align 4, !alias.scope !3, !noalias !4
  %v7614 = load i64, ptr %slot21, align 8
  %p7615 = inttoptr i64 %v7614 to ptr
  store i32 1, ptr %p7615, align 4, !alias.scope !3, !noalias !4
  %v7616 = load i64, ptr %slot25, align 8
  store i64 %v7616, ptr %slot1126, align 8
  %v7617 = load i64, ptr %slot30, align 8
  store i64 %v7617, ptr %slot1127, align 8
  %v7618 = load i64, ptr %slot1127, align 8
  %v7619 = load i64, ptr %slot1126, align 8
  %p7620 = inttoptr i64 %v7618 to ptr
  %p7621 = inttoptr i64 %v7619 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7621, ptr %p7620, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v7622 = load i64, ptr %slot18, align 8
  %p7623 = inttoptr i64 %v7622 to ptr
  store i32 2, ptr %p7623, align 4, !alias.scope !3, !noalias !4
  %v7624 = load i64, ptr %slot22, align 8
  %p7625 = inttoptr i64 %v7624 to ptr
  %ld7626 = load i32, ptr %p7625, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7626, ptr %slot1128, align 8
  %v7627 = load i32, ptr %slot1128, align 8
  %v7628 = load i64, ptr %slot18, align 8
  %p7629 = inttoptr i64 %v7628 to ptr
  store i32 %v7627, ptr %p7629, align 4, !alias.scope !3, !noalias !4
  %v7630 = load i64, ptr %slot21, align 8
  %p7631 = inttoptr i64 %v7630 to ptr
  store i32 0, ptr %p7631, align 4, !alias.scope !3, !noalias !4
  %v7632 = load i64, ptr %slot17, align 8
  %p7633 = inttoptr i64 %v7632 to ptr
  store i32 1, ptr %p7633, align 4, !alias.scope !3, !noalias !4
  %v7634 = load i64, ptr %slot1126, align 8
  %p7635 = inttoptr i64 %v7634 to ptr
  %ld7636 = load i64, ptr %p7635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7636, ptr %slot1129, align 8
  %v7637 = load i64, ptr %slot1129, align 8
  %v7638 = load i64, ptr %slot45, align 8
  %p7639 = inttoptr i64 %v7638 to ptr
  store i64 %v7637, ptr %p7639, align 8, !alias.scope !3, !noalias !4
  %v7640 = load i64, ptr %slot44, align 8
  %p7641 = inttoptr i64 %v7640 to ptr
  %ld7642 = load i64, ptr %p7641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7642, ptr %slot1130, align 8
  %v7643 = load i64, ptr %slot45, align 8
  %p7644 = inttoptr i64 %v7643 to ptr
  %ld7645 = load i64, ptr %p7644, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7645, ptr %slot1131, align 8
  %v7646 = load i64, ptr %slot1, align 8
  %v7647 = load i64, ptr %slot1130, align 8
  %v7648 = load i64, ptr %slot1131, align 8
  %call7649 = call i64 @myl_f_be55845d0d1b5c3c8f232826f6eebbc3f154bbc843ca36782c227966ffc2f923(i64 %v7646, i64 %v7647, i64 %v7648) nomerge, !dbg !186
  store i64 %call7649, ptr %slot1132, align 8
  %v7650 = load i64, ptr %slot1132, align 8
  %v7651 = load i64, ptr %slot44, align 8
  %p7652 = inttoptr i64 %v7651 to ptr
  store i64 %v7650, ptr %p7652, align 8, !alias.scope !3, !noalias !4
  %v7653 = load i64, ptr %slot15, align 8
  %p7654 = inttoptr i64 %v7653 to ptr
  %ld7655 = load i32, ptr %p7654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7655, ptr %slot1133, align 8
  %v7656 = load i32, ptr %slot1133, align 8
  %cv7657 = zext i32 %v7656 to i64
  %cond7658 = icmp ne i64 %cv7657, 0
  br i1 %cond7658, label %bb_rcslotdrop1433, label %bb_rcslotdone1433
bb_rcslotdrop1433:
  %v7659 = load i64, ptr %slot15, align 8
  %p7660 = inttoptr i64 %v7659 to ptr
  store i32 0, ptr %p7660, align 4, !alias.scope !3, !noalias !4
  %v7661 = load i64, ptr %slot24, align 8
  store i64 %v7661, ptr %slot1134, align 8
  %v7662 = load i64, ptr %slot16, align 8
  %p7663 = inttoptr i64 %v7662 to ptr
  %ld7664 = load i32, ptr %p7663, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7664, ptr %slot1135, align 8
  %v7665 = load i32, ptr %slot1135, align 8
  %op7666 = and i32 %v7665, 28
  store i32 %op7666, ptr %slot1136, align 8
  %v7667 = load i32, ptr %slot1136, align 8
  %cv7668 = zext i32 %v7667 to i64
  %cond7669 = icmp ne i64 %cv7668, 0
  br i1 %cond7669, label %bb_rcslotrole1433, label %bb_rcslotowner1433
bb_rcslotrole1433:
  %v7670 = load i64, ptr %slot99, align 8
  store i64 %v7670, ptr %slot1137, align 8
  %v7671 = load i64, ptr %slot1137, align 8
  %v7672 = load i64, ptr %slot1134, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v7671, i64 %v7672) nomerge, !dbg !186
  br label %bb_rcslotdone1433
bb_rcslotowner1433:
  %v7673 = load i64, ptr %slot99, align 8
  store i64 %v7673, ptr %slot1138, align 8
  %v7674 = load i64, ptr %slot1138, align 8
  %v7675 = load i64, ptr %slot1134, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v7674, i64 %v7675) nomerge, !dbg !186
  br label %bb_rcslotdone1433
bb_rcslotdone1433:
  %v7676 = load i64, ptr %slot17, align 8
  %p7677 = inttoptr i64 %v7676 to ptr
  %ld7678 = load i32, ptr %p7677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7678, ptr %slot1139, align 8
  %v7679 = load i32, ptr %slot1139, align 8
  %cv7680 = zext i32 %v7679 to i64
  %cond7681 = icmp ne i64 %cv7680, 0
  br i1 %cond7681, label %bb_rcslotdrop1442, label %bb_rcslotdone1442
bb_rcslotdrop1442:
  %v7682 = load i64, ptr %slot17, align 8
  %p7683 = inttoptr i64 %v7682 to ptr
  store i32 0, ptr %p7683, align 4, !alias.scope !3, !noalias !4
  %v7684 = load i64, ptr %slot25, align 8
  store i64 %v7684, ptr %slot1140, align 8
  %v7685 = load i64, ptr %slot18, align 8
  %p7686 = inttoptr i64 %v7685 to ptr
  %ld7687 = load i32, ptr %p7686, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7687, ptr %slot1141, align 8
  %v7688 = load i32, ptr %slot1141, align 8
  %op7689 = and i32 %v7688, 28
  store i32 %op7689, ptr %slot1142, align 8
  %v7690 = load i32, ptr %slot1142, align 8
  %cv7691 = zext i32 %v7690 to i64
  %cond7692 = icmp ne i64 %cv7691, 0
  br i1 %cond7692, label %bb_rcslotrole1442, label %bb_rcslotowner1442
bb_rcslotrole1442:
  %v7693 = load i64, ptr %slot99, align 8
  store i64 %v7693, ptr %slot1143, align 8
  %v7694 = load i64, ptr %slot1140, align 8
  %p7695 = inttoptr i64 %v7694 to ptr
  %ld7696 = load i64, ptr %p7695, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7696, ptr %slot1144, align 8
  %v7697 = load i64, ptr %slot1144, align 8
  %cmp7698 = icmp ne i64 %v7697, 0
  %cv7699 = zext i1 %cmp7698 to i32
  store i32 %cv7699, ptr %slot1145, align 8
  %v7700 = load i32, ptr %slot1145, align 8
  %cv7701 = zext i32 %v7700 to i64
  %cond7702 = icmp ne i64 %cv7701, 0
  br i1 %cond7702, label %bb_rcgnn1458, label %bb_rcgdone1458
bb_rcgnn1458:
  %v7703 = load i64, ptr %slot1144, align 8
  %op7704 = sub i64 %v7703, 16
  store i64 %op7704, ptr %slot1146, align 8
  %v7705 = load i64, ptr %slot1144, align 8
  %p7706 = inttoptr i64 %v7705 to ptr
  %rgep7707 = getelementptr i8, ptr %p7706, i64 -16
  %ld7708 = load i64, ptr %rgep7707, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7708, ptr %slot1147, align 8
  %v7709 = load i64, ptr %slot1147, align 8
  %op7710 = and i64 %v7709, 4611686018427387906
  store i64 %op7710, ptr %slot1148, align 8
  %v7711 = load i64, ptr %slot1148, align 8
  %cmp7712 = icmp ne i64 %v7711, 0
  %cv7713 = zext i1 %cmp7712 to i32
  store i32 %cv7713, ptr %slot1149, align 8
  %v7714 = load i32, ptr %slot1149, align 8
  %cv7715 = zext i32 %v7714 to i64
  %cond7716 = icmp ne i64 %cv7715, 0
  br i1 %cond7716, label %bb_rcgclear1458, label %bb_rcgcounted1458
bb_rcgcounted1458:
  %v7717 = load i64, ptr %slot1144, align 8
  %op7718 = sub i64 %v7717, 24
  store i64 %op7718, ptr %slot1150, align 8
  %v7719 = load i64, ptr %slot1144, align 8
  %p7720 = inttoptr i64 %v7719 to ptr
  %rgep7721 = getelementptr i8, ptr %p7720, i64 -24
  %ld7722 = load i64, ptr %rgep7721, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7722, ptr %slot1151, align 8
  %v7723 = load i64, ptr %slot1151, align 8
  %op7724 = sub i64 %v7723, 1
  store i64 %op7724, ptr %slot1152, align 8
  %v7725 = load i64, ptr %slot1152, align 8
  %cmp7726 = icmp eq i64 %v7725, 0
  %cv7727 = zext i1 %cmp7726 to i32
  store i32 %cv7727, ptr %slot1153, align 8
  %v7728 = load i32, ptr %slot1153, align 8
  %cv7729 = zext i32 %v7728 to i64
  %cond7730 = icmp ne i64 %cv7729, 0
  br i1 %cond7730, label %bb_rcglast1458, label %bb_rcgdec1458
bb_rcglast1458:
  %v7731 = load i64, ptr %slot1144, align 8
  %op7732 = sub i64 %v7731, 32
  store i64 %op7732, ptr %slot1154, align 8
  %v7733 = load i64, ptr %slot1144, align 8
  %p7734 = inttoptr i64 %v7733 to ptr
  %rgep7735 = getelementptr i8, ptr %p7734, i64 -32
  %ld7736 = load i64, ptr %rgep7735, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7736, ptr %slot1155, align 8
  %v7737 = load i64, ptr %slot1155, align 8
  %cmp7738 = icmp ne i64 %v7737, 0
  %cv7739 = zext i1 %cmp7738 to i32
  store i32 %cv7739, ptr %slot1156, align 8
  %v7740 = load i32, ptr %slot1156, align 8
  %cv7741 = zext i32 %v7740 to i64
  %cond7742 = icmp ne i64 %cv7741, 0
  br i1 %cond7742, label %bb_rcgdec1458, label %bb_rcgslow1458
bb_rcgslow1458:
  %v7743 = load i64, ptr %slot1143, align 8
  %v7744 = load i64, ptr %slot1140, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7743, i64 %v7744) nomerge, !dbg !186
  br label %bb_rcgdone1458
bb_rcgdec1458:
  %v7745 = load i64, ptr %slot1152, align 8
  %v7746 = load i64, ptr %slot1144, align 8
  %p7747 = inttoptr i64 %v7746 to ptr
  %rgep7748 = getelementptr i8, ptr %p7747, i64 -24
  store i64 %v7745, ptr %rgep7748, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1458
bb_rcgclear1458:
  %v7749 = load i64, ptr %slot1140, align 8
  %p7750 = inttoptr i64 %v7749 to ptr
  store i64 0, ptr %p7750, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1458
bb_rcgdone1458:
  br label %bb_rcslotdone1442
bb_rcslotowner1442:
  %v7751 = load i64, ptr %slot99, align 8
  store i64 %v7751, ptr %slot1157, align 8
  %v7752 = load i64, ptr %slot1140, align 8
  %p7753 = inttoptr i64 %v7752 to ptr
  %ld7754 = load i64, ptr %p7753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7754, ptr %slot1158, align 8
  %v7755 = load i64, ptr %slot1158, align 8
  %cmp7756 = icmp ne i64 %v7755, 0
  %cv7757 = zext i1 %cmp7756 to i32
  store i32 %cv7757, ptr %slot1159, align 8
  %v7758 = load i32, ptr %slot1159, align 8
  %cv7759 = zext i32 %v7758 to i64
  %cond7760 = icmp ne i64 %cv7759, 0
  br i1 %cond7760, label %bb_rcgnn1473, label %bb_rcgdone1473
bb_rcgnn1473:
  %v7761 = load i64, ptr %slot1158, align 8
  %op7762 = sub i64 %v7761, 16
  store i64 %op7762, ptr %slot1160, align 8
  %v7763 = load i64, ptr %slot1158, align 8
  %p7764 = inttoptr i64 %v7763 to ptr
  %rgep7765 = getelementptr i8, ptr %p7764, i64 -16
  %ld7766 = load i64, ptr %rgep7765, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7766, ptr %slot1161, align 8
  %v7767 = load i64, ptr %slot1161, align 8
  %op7768 = and i64 %v7767, 4611686018427387906
  store i64 %op7768, ptr %slot1162, align 8
  %v7769 = load i64, ptr %slot1162, align 8
  %cmp7770 = icmp ne i64 %v7769, 0
  %cv7771 = zext i1 %cmp7770 to i32
  store i32 %cv7771, ptr %slot1163, align 8
  %v7772 = load i32, ptr %slot1163, align 8
  %cv7773 = zext i32 %v7772 to i64
  %cond7774 = icmp ne i64 %cv7773, 0
  br i1 %cond7774, label %bb_rcgclear1473, label %bb_rcgcounted1473
bb_rcgcounted1473:
  %v7775 = load i64, ptr %slot1158, align 8
  %op7776 = sub i64 %v7775, 32
  store i64 %op7776, ptr %slot1164, align 8
  %v7777 = load i64, ptr %slot1158, align 8
  %p7778 = inttoptr i64 %v7777 to ptr
  %rgep7779 = getelementptr i8, ptr %p7778, i64 -32
  %ld7780 = load i64, ptr %rgep7779, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7780, ptr %slot1165, align 8
  %v7781 = load i64, ptr %slot1165, align 8
  %op7782 = sub i64 %v7781, 1
  store i64 %op7782, ptr %slot1166, align 8
  %v7783 = load i64, ptr %slot1166, align 8
  %cmp7784 = icmp eq i64 %v7783, 0
  %cv7785 = zext i1 %cmp7784 to i32
  store i32 %cv7785, ptr %slot1167, align 8
  %v7786 = load i32, ptr %slot1167, align 8
  %cv7787 = zext i32 %v7786 to i64
  %cond7788 = icmp ne i64 %cv7787, 0
  br i1 %cond7788, label %bb_rcglast1473, label %bb_rcgdec1473
bb_rcglast1473:
  %v7789 = load i64, ptr %slot1158, align 8
  %op7790 = sub i64 %v7789, 24
  store i64 %op7790, ptr %slot1168, align 8
  %v7791 = load i64, ptr %slot1158, align 8
  %p7792 = inttoptr i64 %v7791 to ptr
  %rgep7793 = getelementptr i8, ptr %p7792, i64 -24
  %ld7794 = load i64, ptr %rgep7793, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7794, ptr %slot1169, align 8
  %v7795 = load i64, ptr %slot1169, align 8
  %cmp7796 = icmp ne i64 %v7795, 0
  %cv7797 = zext i1 %cmp7796 to i32
  store i32 %cv7797, ptr %slot1170, align 8
  %v7798 = load i32, ptr %slot1170, align 8
  %cv7799 = zext i32 %v7798 to i64
  %cond7800 = icmp ne i64 %cv7799, 0
  br i1 %cond7800, label %bb_rcgdec1473, label %bb_rcgslow1473
bb_rcgslow1473:
  %v7801 = load i64, ptr %slot1157, align 8
  %v7802 = load i64, ptr %slot1140, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7801, i64 %v7802) nomerge, !dbg !186
  br label %bb_rcgdone1473
bb_rcgdec1473:
  %v7803 = load i64, ptr %slot1166, align 8
  %v7804 = load i64, ptr %slot1158, align 8
  %p7805 = inttoptr i64 %v7804 to ptr
  %rgep7806 = getelementptr i8, ptr %p7805, i64 -32
  store i64 %v7803, ptr %rgep7806, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1473
bb_rcgclear1473:
  %v7807 = load i64, ptr %slot1140, align 8
  %p7808 = inttoptr i64 %v7807 to ptr
  store i64 0, ptr %p7808, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1473
bb_rcgdone1473:
  br label %bb_rcslotdone1442
bb_rcslotdone1442:
  %v7809 = load i64, ptr %slot44, align 8
  %p7810 = inttoptr i64 %v7809 to ptr
  %ld7811 = load i64, ptr %p7810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7811, ptr %slot1171, align 8
  %v7812 = load i64, ptr %slot1171, align 8
  %v7813 = load i64, ptr %slot40, align 8
  %p7814 = inttoptr i64 %v7813 to ptr
  store i64 %v7812, ptr %p7814, align 8, !alias.scope !3, !noalias !4
  %v7815 = load i64, ptr %slot9, align 8
  %p7816 = inttoptr i64 %v7815 to ptr
  %ld7817 = load i32, ptr %p7816, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7817, ptr %slot1172, align 8
  %v7818 = load i32, ptr %slot1172, align 8
  %cv7819 = zext i32 %v7818 to i64
  %cond7820 = icmp ne i64 %cv7819, 0
  br i1 %cond7820, label %bb_rcslotdrop1480, label %bb_rcslotdone1480
bb_rcslotdrop1480:
  %v7821 = load i64, ptr %slot9, align 8
  %p7822 = inttoptr i64 %v7821 to ptr
  store i32 0, ptr %p7822, align 4, !alias.scope !3, !noalias !4
  %v7823 = load i64, ptr %slot39, align 8
  store i64 %v7823, ptr %slot1173, align 8
  %v7824 = load i64, ptr %slot10, align 8
  %p7825 = inttoptr i64 %v7824 to ptr
  %ld7826 = load i32, ptr %p7825, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7826, ptr %slot1174, align 8
  %v7827 = load i32, ptr %slot1174, align 8
  %op7828 = and i32 %v7827, 28
  store i32 %op7828, ptr %slot1175, align 8
  %v7829 = load i32, ptr %slot1175, align 8
  %cv7830 = zext i32 %v7829 to i64
  %cond7831 = icmp ne i64 %cv7830, 0
  br i1 %cond7831, label %bb_rcslotrole1480, label %bb_rcslotowner1480
bb_rcslotrole1480:
  %v7832 = load i64, ptr %slot99, align 8
  store i64 %v7832, ptr %slot1176, align 8
  %v7833 = load i64, ptr %slot1173, align 8
  %p7834 = inttoptr i64 %v7833 to ptr
  %ld7835 = load i64, ptr %p7834, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7835, ptr %slot1177, align 8
  %v7836 = load i64, ptr %slot1177, align 8
  %cmp7837 = icmp ne i64 %v7836, 0
  %cv7838 = zext i1 %cmp7837 to i32
  store i32 %cv7838, ptr %slot1178, align 8
  %v7839 = load i32, ptr %slot1178, align 8
  %cv7840 = zext i32 %v7839 to i64
  %cond7841 = icmp ne i64 %cv7840, 0
  br i1 %cond7841, label %bb_rcgnn1496, label %bb_rcgdone1496
bb_rcgnn1496:
  %v7842 = load i64, ptr %slot1177, align 8
  %op7843 = sub i64 %v7842, 16
  store i64 %op7843, ptr %slot1179, align 8
  %v7844 = load i64, ptr %slot1177, align 8
  %p7845 = inttoptr i64 %v7844 to ptr
  %rgep7846 = getelementptr i8, ptr %p7845, i64 -16
  %ld7847 = load i64, ptr %rgep7846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7847, ptr %slot1180, align 8
  %v7848 = load i64, ptr %slot1180, align 8
  %op7849 = and i64 %v7848, 4611686018427387906
  store i64 %op7849, ptr %slot1181, align 8
  %v7850 = load i64, ptr %slot1181, align 8
  %cmp7851 = icmp ne i64 %v7850, 0
  %cv7852 = zext i1 %cmp7851 to i32
  store i32 %cv7852, ptr %slot1182, align 8
  %v7853 = load i32, ptr %slot1182, align 8
  %cv7854 = zext i32 %v7853 to i64
  %cond7855 = icmp ne i64 %cv7854, 0
  br i1 %cond7855, label %bb_rcgclear1496, label %bb_rcgcounted1496
bb_rcgcounted1496:
  %v7856 = load i64, ptr %slot1177, align 8
  %op7857 = sub i64 %v7856, 24
  store i64 %op7857, ptr %slot1183, align 8
  %v7858 = load i64, ptr %slot1177, align 8
  %p7859 = inttoptr i64 %v7858 to ptr
  %rgep7860 = getelementptr i8, ptr %p7859, i64 -24
  %ld7861 = load i64, ptr %rgep7860, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7861, ptr %slot1184, align 8
  %v7862 = load i64, ptr %slot1184, align 8
  %op7863 = sub i64 %v7862, 1
  store i64 %op7863, ptr %slot1185, align 8
  %v7864 = load i64, ptr %slot1185, align 8
  %cmp7865 = icmp eq i64 %v7864, 0
  %cv7866 = zext i1 %cmp7865 to i32
  store i32 %cv7866, ptr %slot1186, align 8
  %v7867 = load i32, ptr %slot1186, align 8
  %cv7868 = zext i32 %v7867 to i64
  %cond7869 = icmp ne i64 %cv7868, 0
  br i1 %cond7869, label %bb_rcglast1496, label %bb_rcgdec1496
bb_rcglast1496:
  %v7870 = load i64, ptr %slot1177, align 8
  %op7871 = sub i64 %v7870, 32
  store i64 %op7871, ptr %slot1187, align 8
  %v7872 = load i64, ptr %slot1177, align 8
  %p7873 = inttoptr i64 %v7872 to ptr
  %rgep7874 = getelementptr i8, ptr %p7873, i64 -32
  %ld7875 = load i64, ptr %rgep7874, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7875, ptr %slot1188, align 8
  %v7876 = load i64, ptr %slot1188, align 8
  %cmp7877 = icmp ne i64 %v7876, 0
  %cv7878 = zext i1 %cmp7877 to i32
  store i32 %cv7878, ptr %slot1189, align 8
  %v7879 = load i32, ptr %slot1189, align 8
  %cv7880 = zext i32 %v7879 to i64
  %cond7881 = icmp ne i64 %cv7880, 0
  br i1 %cond7881, label %bb_rcgdec1496, label %bb_rcgslow1496
bb_rcgslow1496:
  %v7882 = load i64, ptr %slot1176, align 8
  %v7883 = load i64, ptr %slot1173, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v7882, i64 %v7883) nomerge, !dbg !188
  br label %bb_rcgdone1496
bb_rcgdec1496:
  %v7884 = load i64, ptr %slot1185, align 8
  %v7885 = load i64, ptr %slot1177, align 8
  %p7886 = inttoptr i64 %v7885 to ptr
  %rgep7887 = getelementptr i8, ptr %p7886, i64 -24
  store i64 %v7884, ptr %rgep7887, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1496
bb_rcgclear1496:
  %v7888 = load i64, ptr %slot1173, align 8
  %p7889 = inttoptr i64 %v7888 to ptr
  store i64 0, ptr %p7889, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1496
bb_rcgdone1496:
  br label %bb_rcslotdone1480
bb_rcslotowner1480:
  %v7890 = load i64, ptr %slot99, align 8
  store i64 %v7890, ptr %slot1190, align 8
  %v7891 = load i64, ptr %slot1173, align 8
  %p7892 = inttoptr i64 %v7891 to ptr
  %ld7893 = load i64, ptr %p7892, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7893, ptr %slot1191, align 8
  %v7894 = load i64, ptr %slot1191, align 8
  %cmp7895 = icmp ne i64 %v7894, 0
  %cv7896 = zext i1 %cmp7895 to i32
  store i32 %cv7896, ptr %slot1192, align 8
  %v7897 = load i32, ptr %slot1192, align 8
  %cv7898 = zext i32 %v7897 to i64
  %cond7899 = icmp ne i64 %cv7898, 0
  br i1 %cond7899, label %bb_rcgnn1511, label %bb_rcgdone1511
bb_rcgnn1511:
  %v7900 = load i64, ptr %slot1191, align 8
  %op7901 = sub i64 %v7900, 16
  store i64 %op7901, ptr %slot1193, align 8
  %v7902 = load i64, ptr %slot1191, align 8
  %p7903 = inttoptr i64 %v7902 to ptr
  %rgep7904 = getelementptr i8, ptr %p7903, i64 -16
  %ld7905 = load i64, ptr %rgep7904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7905, ptr %slot1194, align 8
  %v7906 = load i64, ptr %slot1194, align 8
  %op7907 = and i64 %v7906, 4611686018427387906
  store i64 %op7907, ptr %slot1195, align 8
  %v7908 = load i64, ptr %slot1195, align 8
  %cmp7909 = icmp ne i64 %v7908, 0
  %cv7910 = zext i1 %cmp7909 to i32
  store i32 %cv7910, ptr %slot1196, align 8
  %v7911 = load i32, ptr %slot1196, align 8
  %cv7912 = zext i32 %v7911 to i64
  %cond7913 = icmp ne i64 %cv7912, 0
  br i1 %cond7913, label %bb_rcgclear1511, label %bb_rcgcounted1511
bb_rcgcounted1511:
  %v7914 = load i64, ptr %slot1191, align 8
  %op7915 = sub i64 %v7914, 32
  store i64 %op7915, ptr %slot1197, align 8
  %v7916 = load i64, ptr %slot1191, align 8
  %p7917 = inttoptr i64 %v7916 to ptr
  %rgep7918 = getelementptr i8, ptr %p7917, i64 -32
  %ld7919 = load i64, ptr %rgep7918, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7919, ptr %slot1198, align 8
  %v7920 = load i64, ptr %slot1198, align 8
  %op7921 = sub i64 %v7920, 1
  store i64 %op7921, ptr %slot1199, align 8
  %v7922 = load i64, ptr %slot1199, align 8
  %cmp7923 = icmp eq i64 %v7922, 0
  %cv7924 = zext i1 %cmp7923 to i32
  store i32 %cv7924, ptr %slot1200, align 8
  %v7925 = load i32, ptr %slot1200, align 8
  %cv7926 = zext i32 %v7925 to i64
  %cond7927 = icmp ne i64 %cv7926, 0
  br i1 %cond7927, label %bb_rcglast1511, label %bb_rcgdec1511
bb_rcglast1511:
  %v7928 = load i64, ptr %slot1191, align 8
  %op7929 = sub i64 %v7928, 24
  store i64 %op7929, ptr %slot1201, align 8
  %v7930 = load i64, ptr %slot1191, align 8
  %p7931 = inttoptr i64 %v7930 to ptr
  %rgep7932 = getelementptr i8, ptr %p7931, i64 -24
  %ld7933 = load i64, ptr %rgep7932, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7933, ptr %slot1202, align 8
  %v7934 = load i64, ptr %slot1202, align 8
  %cmp7935 = icmp ne i64 %v7934, 0
  %cv7936 = zext i1 %cmp7935 to i32
  store i32 %cv7936, ptr %slot1203, align 8
  %v7937 = load i32, ptr %slot1203, align 8
  %cv7938 = zext i32 %v7937 to i64
  %cond7939 = icmp ne i64 %cv7938, 0
  br i1 %cond7939, label %bb_rcgdec1511, label %bb_rcgslow1511
bb_rcgslow1511:
  %v7940 = load i64, ptr %slot1190, align 8
  %v7941 = load i64, ptr %slot1173, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v7940, i64 %v7941) nomerge, !dbg !188
  br label %bb_rcgdone1511
bb_rcgdec1511:
  %v7942 = load i64, ptr %slot1199, align 8
  %v7943 = load i64, ptr %slot1191, align 8
  %p7944 = inttoptr i64 %v7943 to ptr
  %rgep7945 = getelementptr i8, ptr %p7944, i64 -32
  store i64 %v7942, ptr %rgep7945, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1511
bb_rcgclear1511:
  %v7946 = load i64, ptr %slot1173, align 8
  %p7947 = inttoptr i64 %v7946 to ptr
  store i64 0, ptr %p7947, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1511
bb_rcgdone1511:
  br label %bb_rcslotdone1480
bb_rcslotdone1480:
  %v7948 = load i64, ptr %slot32, align 8
  %p7949 = inttoptr i64 %v7948 to ptr
  %ld7950 = load i64, ptr %p7949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7950, ptr %slot1204, align 8
  %v7951 = load i64, ptr %slot1204, align 8
  %v7952 = load i64, ptr %slot44, align 8
  %p7953 = inttoptr i64 %v7952 to ptr
  store i64 %v7951, ptr %p7953, align 8, !alias.scope !3, !noalias !4
  %v7954 = load i64, ptr %slot40, align 8
  %p7955 = inttoptr i64 %v7954 to ptr
  %ld7956 = load i64, ptr %p7955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7956, ptr %slot1205, align 8
  %v7957 = load i64, ptr %slot1205, align 8
  %v7958 = load i64, ptr %slot45, align 8
  %p7959 = inttoptr i64 %v7958 to ptr
  store i64 %v7957, ptr %p7959, align 8, !alias.scope !3, !noalias !4
  %v7960 = load i64, ptr %slot67, align 8
  store i64 %v7960, ptr %slot1206, align 8
  %v7961 = load i64, ptr %slot1206, align 8
  %p7962 = inttoptr i64 %v7961 to ptr
  store i64 0, ptr %p7962, align 8, !alias.scope !3, !noalias !4
  %v7963 = load i64, ptr %slot1206, align 8
  %p7965 = inttoptr i64 %v7963 to ptr
  %gep7966 = getelementptr i8, ptr %p7965, i64 8
  %op7964 = ptrtoint ptr %gep7966 to i64
  store i64 %op7964, ptr %slot1207, align 8
  %v7967 = load i64, ptr %slot1207, align 8
  %p7968 = inttoptr i64 %v7967 to ptr
  store i64 0, ptr %p7968, align 8, !alias.scope !3, !noalias !4
  %v7969 = load i64, ptr %slot1206, align 8
  %p7970 = inttoptr i64 %v7969 to ptr
  store i32 3, ptr %p7970, align 4, !alias.scope !3, !noalias !4
  %v7971 = load i64, ptr %slot23, align 8
  %p7972 = inttoptr i64 %v7971 to ptr
  store i32 1, ptr %p7972, align 4, !alias.scope !3, !noalias !4
  %v7973 = load i64, ptr %slot45, align 8
  store i64 %v7973, ptr %slot1208, align 8
  %v7974 = load i64, ptr %slot1206, align 8
  %p7976 = inttoptr i64 %v7974 to ptr
  %gep7977 = getelementptr i8, ptr %p7976, i64 8
  %op7975 = ptrtoint ptr %gep7977 to i64
  store i64 %op7975, ptr %slot1209, align 8
  %v7978 = load i64, ptr %slot100, align 8
  store i64 %v7978, ptr %slot1210, align 8
  %v7979 = load i64, ptr %slot1208, align 8
  %p7980 = inttoptr i64 %v7979 to ptr
  %ld7981 = load i64, ptr %p7980, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7981, ptr %slot1211, align 8
  %v7982 = load i64, ptr %slot1211, align 8
  %v7983 = load i64, ptr %slot1209, align 8
  %p7984 = inttoptr i64 %v7983 to ptr
  store i64 %v7982, ptr %p7984, align 8, !alias.scope !3, !noalias !4
  %v7985 = load i64, ptr %slot1206, align 8
  %v7986 = load i64, ptr %slot45, align 8
  %p7987 = inttoptr i64 %v7986 to ptr
  store i64 %v7985, ptr %p7987, align 8, !alias.scope !3, !noalias !4
  %v7988 = load i64, ptr %slot33, align 8
  %v7989 = load i64, ptr %slot46, align 8
  %p7990 = inttoptr i64 %v7989 to ptr
  store i64 %v7988, ptr %p7990, align 8, !alias.scope !3, !noalias !4
  %v7991 = load i64, ptr %slot44, align 8
  %p7992 = inttoptr i64 %v7991 to ptr
  %ld7993 = load i64, ptr %p7992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7993, ptr %slot1212, align 8
  %v7994 = load i64, ptr %slot45, align 8
  %p7995 = inttoptr i64 %v7994 to ptr
  %ld7996 = load i64, ptr %p7995, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7996, ptr %slot1213, align 8
  %v7997 = load i64, ptr %slot46, align 8
  %p7998 = inttoptr i64 %v7997 to ptr
  %ld7999 = load i64, ptr %p7998, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7999, ptr %slot1214, align 8
  %v8000 = load i64, ptr %slot1, align 8
  %v8001 = load i64, ptr %slot1212, align 8
  %v8002 = load i64, ptr %slot1213, align 8
  %v8003 = load i64, ptr %slot1214, align 8
  %call8004 = call i64 @myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623(i64 %v8000, i64 %v8001, i64 %v8002, i64 %v8003) nomerge, !dbg !190
  store i64 %call8004, ptr %slot1215, align 8
  %v8005 = load i64, ptr %slot1215, align 8
  %v8006 = load i64, ptr %slot44, align 8
  %p8007 = inttoptr i64 %v8006 to ptr
  store i64 %v8005, ptr %p8007, align 8, !alias.scope !3, !noalias !4
  %v8008 = load i64, ptr %slot15, align 8
  %p8009 = inttoptr i64 %v8008 to ptr
  %ld8010 = load i32, ptr %p8009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8010, ptr %slot1216, align 8
  %v8011 = load i32, ptr %slot1216, align 8
  %cv8012 = zext i32 %v8011 to i64
  %cond8013 = icmp ne i64 %cv8012, 0
  br i1 %cond8013, label %bb_rcslotdrop1531, label %bb_rcslotdone1531
bb_rcslotdrop1531:
  %v8014 = load i64, ptr %slot15, align 8
  %p8015 = inttoptr i64 %v8014 to ptr
  store i32 0, ptr %p8015, align 4, !alias.scope !3, !noalias !4
  %v8016 = load i64, ptr %slot24, align 8
  store i64 %v8016, ptr %slot1217, align 8
  %v8017 = load i64, ptr %slot16, align 8
  %p8018 = inttoptr i64 %v8017 to ptr
  %ld8019 = load i32, ptr %p8018, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8019, ptr %slot1218, align 8
  %v8020 = load i32, ptr %slot1218, align 8
  %op8021 = and i32 %v8020, 28
  store i32 %op8021, ptr %slot1219, align 8
  %v8022 = load i32, ptr %slot1219, align 8
  %cv8023 = zext i32 %v8022 to i64
  %cond8024 = icmp ne i64 %cv8023, 0
  br i1 %cond8024, label %bb_rcslotrole1531, label %bb_rcslotowner1531
bb_rcslotrole1531:
  %v8025 = load i64, ptr %slot99, align 8
  store i64 %v8025, ptr %slot1220, align 8
  %v8026 = load i64, ptr %slot1220, align 8
  %v8027 = load i64, ptr %slot1217, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v8026, i64 %v8027) nomerge, !dbg !190
  br label %bb_rcslotdone1531
bb_rcslotowner1531:
  %v8028 = load i64, ptr %slot99, align 8
  store i64 %v8028, ptr %slot1221, align 8
  %v8029 = load i64, ptr %slot1221, align 8
  %v8030 = load i64, ptr %slot1217, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v8029, i64 %v8030) nomerge, !dbg !190
  br label %bb_rcslotdone1531
bb_rcslotdone1531:
  %v8031 = load i64, ptr %slot19, align 8
  %p8032 = inttoptr i64 %v8031 to ptr
  %ld8033 = load i32, ptr %p8032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8033, ptr %slot1222, align 8
  %v8034 = load i32, ptr %slot1222, align 8
  %cv8035 = zext i32 %v8034 to i64
  %cond8036 = icmp ne i64 %cv8035, 0
  br i1 %cond8036, label %bb_rcslotdrop1540, label %bb_rcslotdone1540
bb_rcslotdrop1540:
  %v8037 = load i64, ptr %slot19, align 8
  %p8038 = inttoptr i64 %v8037 to ptr
  store i32 0, ptr %p8038, align 4, !alias.scope !3, !noalias !4
  %v8039 = load i64, ptr %slot26, align 8
  store i64 %v8039, ptr %slot1223, align 8
  %v8040 = load i64, ptr %slot20, align 8
  %p8041 = inttoptr i64 %v8040 to ptr
  %ld8042 = load i32, ptr %p8041, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8042, ptr %slot1224, align 8
  %v8043 = load i32, ptr %slot1224, align 8
  %op8044 = and i32 %v8043, 28
  store i32 %op8044, ptr %slot1225, align 8
  %v8045 = load i32, ptr %slot1225, align 8
  %cv8046 = zext i32 %v8045 to i64
  %cond8047 = icmp ne i64 %cv8046, 0
  br i1 %cond8047, label %bb_rcslotrole1540, label %bb_rcslotowner1540
bb_rcslotrole1540:
  %v8048 = load i64, ptr %slot99, align 8
  store i64 %v8048, ptr %slot1226, align 8
  %v8049 = load i64, ptr %slot1226, align 8
  %v8050 = load i64, ptr %slot1223, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v8049, i64 %v8050) nomerge, !dbg !190
  br label %bb_rcslotdone1540
bb_rcslotowner1540:
  %v8051 = load i64, ptr %slot99, align 8
  store i64 %v8051, ptr %slot1227, align 8
  %v8052 = load i64, ptr %slot1227, align 8
  %v8053 = load i64, ptr %slot1223, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v8052, i64 %v8053) nomerge, !dbg !190
  br label %bb_rcslotdone1540
bb_rcslotdone1540:
  %v8054 = load i64, ptr %slot68, align 8
  store i64 %v8054, ptr %slot1228, align 8
  %v8055 = load i64, ptr %slot1228, align 8
  %p8056 = inttoptr i64 %v8055 to ptr
  store i64 0, ptr %p8056, align 8, !alias.scope !3, !noalias !4
  %v8057 = load i64, ptr %slot1228, align 8
  %p8059 = inttoptr i64 %v8057 to ptr
  %gep8060 = getelementptr i8, ptr %p8059, i64 8
  %op8058 = ptrtoint ptr %gep8060 to i64
  store i64 %op8058, ptr %slot1229, align 8
  %v8061 = load i64, ptr %slot1229, align 8
  %p8062 = inttoptr i64 %v8061 to ptr
  store i64 0, ptr %p8062, align 8, !alias.scope !3, !noalias !4
  %v8063 = load i64, ptr %slot1228, align 8
  %p8064 = inttoptr i64 %v8063 to ptr
  store i32 0, ptr %p8064, align 4, !alias.scope !3, !noalias !4
  %v8065 = load i64, ptr %slot23, align 8
  %p8066 = inttoptr i64 %v8065 to ptr
  store i32 1, ptr %p8066, align 4, !alias.scope !3, !noalias !4
  %v8067 = load i64, ptr %slot44, align 8
  store i64 %v8067, ptr %slot1230, align 8
  %v8068 = load i64, ptr %slot1228, align 8
  %p8070 = inttoptr i64 %v8068 to ptr
  %gep8071 = getelementptr i8, ptr %p8070, i64 8
  %op8069 = ptrtoint ptr %gep8071 to i64
  store i64 %op8069, ptr %slot1231, align 8
  %v8072 = load i64, ptr %slot100, align 8
  store i64 %v8072, ptr %slot1232, align 8
  %v8073 = load i64, ptr %slot1230, align 8
  %p8074 = inttoptr i64 %v8073 to ptr
  %ld8075 = load i64, ptr %p8074, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8075, ptr %slot1233, align 8
  %v8076 = load i64, ptr %slot1233, align 8
  %v8077 = load i64, ptr %slot1231, align 8
  %p8078 = inttoptr i64 %v8077 to ptr
  store i64 %v8076, ptr %p8078, align 8, !alias.scope !3, !noalias !4
  %v8079 = load i64, ptr %slot1228, align 8
  %v8080 = load i64, ptr %slot44, align 8
  %p8081 = inttoptr i64 %v8080 to ptr
  store i64 %v8079, ptr %p8081, align 8, !alias.scope !3, !noalias !4
  %v8082 = load i64, ptr %slot44, align 8
  %p8083 = inttoptr i64 %v8082 to ptr
  %ld8084 = load i64, ptr %p8083, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8084, ptr %slot1234, align 8
  %v8085 = load i64, ptr %slot15, align 8
  %p8086 = inttoptr i64 %v8085 to ptr
  %ld8087 = load i32, ptr %p8086, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8087, ptr %slot1235, align 8
  %v8088 = load i32, ptr %slot1235, align 8
  %cv8089 = zext i32 %v8088 to i64
  %cond8090 = icmp ne i64 %cv8089, 0
  br i1 %cond8090, label %bb_rcslotdrop1558, label %bb_rcslotdone1558
bb_rcslotdrop1558:
  %v8091 = load i64, ptr %slot15, align 8
  %p8092 = inttoptr i64 %v8091 to ptr
  store i32 0, ptr %p8092, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1558
bb_rcslotdone1558:
  %v8093 = load i64, ptr %slot13, align 8
  %p8094 = inttoptr i64 %v8093 to ptr
  %ld8095 = load i32, ptr %p8094, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8095, ptr %slot1236, align 8
  %v8096 = load i32, ptr %slot1236, align 8
  %cv8097 = zext i32 %v8096 to i64
  %cond8098 = icmp ne i64 %cv8097, 0
  br i1 %cond8098, label %bb_rcslotdrop1561, label %bb_rcslotdone1561
bb_rcslotdrop1561:
  %v8099 = load i64, ptr %slot13, align 8
  %p8100 = inttoptr i64 %v8099 to ptr
  store i32 0, ptr %p8100, align 4, !alias.scope !3, !noalias !4
  %v8101 = load i64, ptr %slot42, align 8
  store i64 %v8101, ptr %slot1237, align 8
  %v8102 = load i64, ptr %slot14, align 8
  %p8103 = inttoptr i64 %v8102 to ptr
  %ld8104 = load i32, ptr %p8103, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8104, ptr %slot1238, align 8
  %v8105 = load i32, ptr %slot1238, align 8
  %op8106 = and i32 %v8105, 28
  store i32 %op8106, ptr %slot1239, align 8
  %v8107 = load i32, ptr %slot1239, align 8
  %cv8108 = zext i32 %v8107 to i64
  %cond8109 = icmp ne i64 %cv8108, 0
  br i1 %cond8109, label %bb_rcslotrole1561, label %bb_rcslotowner1561
bb_rcslotrole1561:
  %v8110 = load i64, ptr %slot99, align 8
  store i64 %v8110, ptr %slot1240, align 8
  %v8111 = load i64, ptr %slot1240, align 8
  %v8112 = load i64, ptr %slot1237, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v8111, i64 %v8112) nomerge, !dbg !192
  br label %bb_rcslotdone1561
bb_rcslotowner1561:
  %v8113 = load i64, ptr %slot99, align 8
  store i64 %v8113, ptr %slot1241, align 8
  %v8114 = load i64, ptr %slot1241, align 8
  %v8115 = load i64, ptr %slot1237, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v8114, i64 %v8115) nomerge, !dbg !192
  br label %bb_rcslotdone1561
bb_rcslotdone1561:
  %v8116 = load i64, ptr %slot11, align 8
  %p8117 = inttoptr i64 %v8116 to ptr
  %ld8118 = load i32, ptr %p8117, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8118, ptr %slot1242, align 8
  %v8119 = load i32, ptr %slot1242, align 8
  %cv8120 = zext i32 %v8119 to i64
  %cond8121 = icmp ne i64 %cv8120, 0
  br i1 %cond8121, label %bb_rcslotdrop1570, label %bb_rcslotdone1570
bb_rcslotdrop1570:
  %v8122 = load i64, ptr %slot11, align 8
  %p8123 = inttoptr i64 %v8122 to ptr
  store i32 0, ptr %p8123, align 4, !alias.scope !3, !noalias !4
  %v8124 = load i64, ptr %slot41, align 8
  store i64 %v8124, ptr %slot1243, align 8
  %v8125 = load i64, ptr %slot12, align 8
  %p8126 = inttoptr i64 %v8125 to ptr
  %ld8127 = load i32, ptr %p8126, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8127, ptr %slot1244, align 8
  %v8128 = load i32, ptr %slot1244, align 8
  %op8129 = and i32 %v8128, 28
  store i32 %op8129, ptr %slot1245, align 8
  %v8130 = load i32, ptr %slot1245, align 8
  %cv8131 = zext i32 %v8130 to i64
  %cond8132 = icmp ne i64 %cv8131, 0
  br i1 %cond8132, label %bb_rcslotrole1570, label %bb_rcslotowner1570
bb_rcslotrole1570:
  %v8133 = load i64, ptr %slot99, align 8
  store i64 %v8133, ptr %slot1246, align 8
  %v8134 = load i64, ptr %slot1246, align 8
  %v8135 = load i64, ptr %slot1243, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v8134, i64 %v8135) nomerge, !dbg !192
  br label %bb_rcslotdone1570
bb_rcslotowner1570:
  %v8136 = load i64, ptr %slot99, align 8
  store i64 %v8136, ptr %slot1247, align 8
  %v8137 = load i64, ptr %slot1247, align 8
  %v8138 = load i64, ptr %slot1243, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v8137, i64 %v8138) nomerge, !dbg !192
  br label %bb_rcslotdone1570
bb_rcslotdone1570:
  %v8139 = load i64, ptr %slot9, align 8
  %p8140 = inttoptr i64 %v8139 to ptr
  %ld8141 = load i32, ptr %p8140, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8141, ptr %slot1248, align 8
  %v8142 = load i32, ptr %slot1248, align 8
  %cv8143 = zext i32 %v8142 to i64
  %cond8144 = icmp ne i64 %cv8143, 0
  br i1 %cond8144, label %bb_rcslotdrop1579, label %bb_rcslotdone1579
bb_rcslotdrop1579:
  %v8145 = load i64, ptr %slot9, align 8
  %p8146 = inttoptr i64 %v8145 to ptr
  store i32 0, ptr %p8146, align 4, !alias.scope !3, !noalias !4
  %v8147 = load i64, ptr %slot39, align 8
  store i64 %v8147, ptr %slot1249, align 8
  %v8148 = load i64, ptr %slot10, align 8
  %p8149 = inttoptr i64 %v8148 to ptr
  %ld8150 = load i32, ptr %p8149, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8150, ptr %slot1250, align 8
  %v8151 = load i32, ptr %slot1250, align 8
  %op8152 = and i32 %v8151, 28
  store i32 %op8152, ptr %slot1251, align 8
  %v8153 = load i32, ptr %slot1251, align 8
  %cv8154 = zext i32 %v8153 to i64
  %cond8155 = icmp ne i64 %cv8154, 0
  br i1 %cond8155, label %bb_rcslotrole1579, label %bb_rcslotowner1579
bb_rcslotrole1579:
  %v8156 = load i64, ptr %slot99, align 8
  store i64 %v8156, ptr %slot1252, align 8
  %v8157 = load i64, ptr %slot1249, align 8
  %p8158 = inttoptr i64 %v8157 to ptr
  %ld8159 = load i64, ptr %p8158, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8159, ptr %slot1253, align 8
  %v8160 = load i64, ptr %slot1253, align 8
  %cmp8161 = icmp ne i64 %v8160, 0
  %cv8162 = zext i1 %cmp8161 to i32
  store i32 %cv8162, ptr %slot1254, align 8
  %v8163 = load i32, ptr %slot1254, align 8
  %cv8164 = zext i32 %v8163 to i64
  %cond8165 = icmp ne i64 %cv8164, 0
  br i1 %cond8165, label %bb_rcgnn1595, label %bb_rcgdone1595
bb_rcgnn1595:
  %v8166 = load i64, ptr %slot1253, align 8
  %op8167 = sub i64 %v8166, 16
  store i64 %op8167, ptr %slot1255, align 8
  %v8168 = load i64, ptr %slot1253, align 8
  %p8169 = inttoptr i64 %v8168 to ptr
  %rgep8170 = getelementptr i8, ptr %p8169, i64 -16
  %ld8171 = load i64, ptr %rgep8170, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8171, ptr %slot1256, align 8
  %v8172 = load i64, ptr %slot1256, align 8
  %op8173 = and i64 %v8172, 4611686018427387906
  store i64 %op8173, ptr %slot1257, align 8
  %v8174 = load i64, ptr %slot1257, align 8
  %cmp8175 = icmp ne i64 %v8174, 0
  %cv8176 = zext i1 %cmp8175 to i32
  store i32 %cv8176, ptr %slot1258, align 8
  %v8177 = load i32, ptr %slot1258, align 8
  %cv8178 = zext i32 %v8177 to i64
  %cond8179 = icmp ne i64 %cv8178, 0
  br i1 %cond8179, label %bb_rcgclear1595, label %bb_rcgcounted1595
bb_rcgcounted1595:
  %v8180 = load i64, ptr %slot1253, align 8
  %op8181 = sub i64 %v8180, 24
  store i64 %op8181, ptr %slot1259, align 8
  %v8182 = load i64, ptr %slot1253, align 8
  %p8183 = inttoptr i64 %v8182 to ptr
  %rgep8184 = getelementptr i8, ptr %p8183, i64 -24
  %ld8185 = load i64, ptr %rgep8184, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8185, ptr %slot1260, align 8
  %v8186 = load i64, ptr %slot1260, align 8
  %op8187 = sub i64 %v8186, 1
  store i64 %op8187, ptr %slot1261, align 8
  %v8188 = load i64, ptr %slot1261, align 8
  %cmp8189 = icmp eq i64 %v8188, 0
  %cv8190 = zext i1 %cmp8189 to i32
  store i32 %cv8190, ptr %slot1262, align 8
  %v8191 = load i32, ptr %slot1262, align 8
  %cv8192 = zext i32 %v8191 to i64
  %cond8193 = icmp ne i64 %cv8192, 0
  br i1 %cond8193, label %bb_rcglast1595, label %bb_rcgdec1595
bb_rcglast1595:
  %v8194 = load i64, ptr %slot1253, align 8
  %op8195 = sub i64 %v8194, 32
  store i64 %op8195, ptr %slot1263, align 8
  %v8196 = load i64, ptr %slot1253, align 8
  %p8197 = inttoptr i64 %v8196 to ptr
  %rgep8198 = getelementptr i8, ptr %p8197, i64 -32
  %ld8199 = load i64, ptr %rgep8198, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8199, ptr %slot1264, align 8
  %v8200 = load i64, ptr %slot1264, align 8
  %cmp8201 = icmp ne i64 %v8200, 0
  %cv8202 = zext i1 %cmp8201 to i32
  store i32 %cv8202, ptr %slot1265, align 8
  %v8203 = load i32, ptr %slot1265, align 8
  %cv8204 = zext i32 %v8203 to i64
  %cond8205 = icmp ne i64 %cv8204, 0
  br i1 %cond8205, label %bb_rcgdec1595, label %bb_rcgslow1595
bb_rcgslow1595:
  %v8206 = load i64, ptr %slot1252, align 8
  %v8207 = load i64, ptr %slot1249, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v8206, i64 %v8207) nomerge, !dbg !192
  br label %bb_rcgdone1595
bb_rcgdec1595:
  %v8208 = load i64, ptr %slot1261, align 8
  %v8209 = load i64, ptr %slot1253, align 8
  %p8210 = inttoptr i64 %v8209 to ptr
  %rgep8211 = getelementptr i8, ptr %p8210, i64 -24
  store i64 %v8208, ptr %rgep8211, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1595
bb_rcgclear1595:
  %v8212 = load i64, ptr %slot1249, align 8
  %p8213 = inttoptr i64 %v8212 to ptr
  store i64 0, ptr %p8213, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1595
bb_rcgdone1595:
  br label %bb_rcslotdone1579
bb_rcslotowner1579:
  %v8214 = load i64, ptr %slot99, align 8
  store i64 %v8214, ptr %slot1266, align 8
  %v8215 = load i64, ptr %slot1249, align 8
  %p8216 = inttoptr i64 %v8215 to ptr
  %ld8217 = load i64, ptr %p8216, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8217, ptr %slot1267, align 8
  %v8218 = load i64, ptr %slot1267, align 8
  %cmp8219 = icmp ne i64 %v8218, 0
  %cv8220 = zext i1 %cmp8219 to i32
  store i32 %cv8220, ptr %slot1268, align 8
  %v8221 = load i32, ptr %slot1268, align 8
  %cv8222 = zext i32 %v8221 to i64
  %cond8223 = icmp ne i64 %cv8222, 0
  br i1 %cond8223, label %bb_rcgnn1610, label %bb_rcgdone1610
bb_rcgnn1610:
  %v8224 = load i64, ptr %slot1267, align 8
  %op8225 = sub i64 %v8224, 16
  store i64 %op8225, ptr %slot1269, align 8
  %v8226 = load i64, ptr %slot1267, align 8
  %p8227 = inttoptr i64 %v8226 to ptr
  %rgep8228 = getelementptr i8, ptr %p8227, i64 -16
  %ld8229 = load i64, ptr %rgep8228, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8229, ptr %slot1270, align 8
  %v8230 = load i64, ptr %slot1270, align 8
  %op8231 = and i64 %v8230, 4611686018427387906
  store i64 %op8231, ptr %slot1271, align 8
  %v8232 = load i64, ptr %slot1271, align 8
  %cmp8233 = icmp ne i64 %v8232, 0
  %cv8234 = zext i1 %cmp8233 to i32
  store i32 %cv8234, ptr %slot1272, align 8
  %v8235 = load i32, ptr %slot1272, align 8
  %cv8236 = zext i32 %v8235 to i64
  %cond8237 = icmp ne i64 %cv8236, 0
  br i1 %cond8237, label %bb_rcgclear1610, label %bb_rcgcounted1610
bb_rcgcounted1610:
  %v8238 = load i64, ptr %slot1267, align 8
  %op8239 = sub i64 %v8238, 32
  store i64 %op8239, ptr %slot1273, align 8
  %v8240 = load i64, ptr %slot1267, align 8
  %p8241 = inttoptr i64 %v8240 to ptr
  %rgep8242 = getelementptr i8, ptr %p8241, i64 -32
  %ld8243 = load i64, ptr %rgep8242, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8243, ptr %slot1274, align 8
  %v8244 = load i64, ptr %slot1274, align 8
  %op8245 = sub i64 %v8244, 1
  store i64 %op8245, ptr %slot1275, align 8
  %v8246 = load i64, ptr %slot1275, align 8
  %cmp8247 = icmp eq i64 %v8246, 0
  %cv8248 = zext i1 %cmp8247 to i32
  store i32 %cv8248, ptr %slot1276, align 8
  %v8249 = load i32, ptr %slot1276, align 8
  %cv8250 = zext i32 %v8249 to i64
  %cond8251 = icmp ne i64 %cv8250, 0
  br i1 %cond8251, label %bb_rcglast1610, label %bb_rcgdec1610
bb_rcglast1610:
  %v8252 = load i64, ptr %slot1267, align 8
  %op8253 = sub i64 %v8252, 24
  store i64 %op8253, ptr %slot1277, align 8
  %v8254 = load i64, ptr %slot1267, align 8
  %p8255 = inttoptr i64 %v8254 to ptr
  %rgep8256 = getelementptr i8, ptr %p8255, i64 -24
  %ld8257 = load i64, ptr %rgep8256, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8257, ptr %slot1278, align 8
  %v8258 = load i64, ptr %slot1278, align 8
  %cmp8259 = icmp ne i64 %v8258, 0
  %cv8260 = zext i1 %cmp8259 to i32
  store i32 %cv8260, ptr %slot1279, align 8
  %v8261 = load i32, ptr %slot1279, align 8
  %cv8262 = zext i32 %v8261 to i64
  %cond8263 = icmp ne i64 %cv8262, 0
  br i1 %cond8263, label %bb_rcgdec1610, label %bb_rcgslow1610
bb_rcgslow1610:
  %v8264 = load i64, ptr %slot1266, align 8
  %v8265 = load i64, ptr %slot1249, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v8264, i64 %v8265) nomerge, !dbg !192
  br label %bb_rcgdone1610
bb_rcgdec1610:
  %v8266 = load i64, ptr %slot1275, align 8
  %v8267 = load i64, ptr %slot1267, align 8
  %p8268 = inttoptr i64 %v8267 to ptr
  %rgep8269 = getelementptr i8, ptr %p8268, i64 -32
  store i64 %v8266, ptr %rgep8269, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1610
bb_rcgclear1610:
  %v8270 = load i64, ptr %slot1249, align 8
  %p8271 = inttoptr i64 %v8270 to ptr
  store i64 0, ptr %p8271, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1610
bb_rcgdone1610:
  br label %bb_rcslotdone1579
bb_rcslotdone1579:
  %v8272 = load i64, ptr %slot7, align 8
  %p8273 = inttoptr i64 %v8272 to ptr
  %ld8274 = load i32, ptr %p8273, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8274, ptr %slot1280, align 8
  %v8275 = load i32, ptr %slot1280, align 8
  %cv8276 = zext i32 %v8275 to i64
  %cond8277 = icmp ne i64 %cv8276, 0
  br i1 %cond8277, label %bb_rcslotdrop1616, label %bb_rcslotdone1616
bb_rcslotdrop1616:
  %v8278 = load i64, ptr %slot7, align 8
  %p8279 = inttoptr i64 %v8278 to ptr
  store i32 0, ptr %p8279, align 4, !alias.scope !3, !noalias !4
  %v8280 = load i64, ptr %slot34, align 8
  store i64 %v8280, ptr %slot1281, align 8
  %v8281 = load i64, ptr %slot8, align 8
  %p8282 = inttoptr i64 %v8281 to ptr
  %ld8283 = load i32, ptr %p8282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8283, ptr %slot1282, align 8
  %v8284 = load i32, ptr %slot1282, align 8
  %op8285 = and i32 %v8284, 28
  store i32 %op8285, ptr %slot1283, align 8
  %v8286 = load i32, ptr %slot1283, align 8
  %cv8287 = zext i32 %v8286 to i64
  %cond8288 = icmp ne i64 %cv8287, 0
  br i1 %cond8288, label %bb_rcslotrole1616, label %bb_rcslotowner1616
bb_rcslotrole1616:
  %v8289 = load i64, ptr %slot99, align 8
  store i64 %v8289, ptr %slot1284, align 8
  %v8290 = load i64, ptr %slot1281, align 8
  %p8291 = inttoptr i64 %v8290 to ptr
  %ld8292 = load i64, ptr %p8291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8292, ptr %slot1285, align 8
  %v8293 = load i64, ptr %slot1285, align 8
  %cmp8294 = icmp ne i64 %v8293, 0
  %cv8295 = zext i1 %cmp8294 to i32
  store i32 %cv8295, ptr %slot1286, align 8
  %v8296 = load i32, ptr %slot1286, align 8
  %cv8297 = zext i32 %v8296 to i64
  %cond8298 = icmp ne i64 %cv8297, 0
  br i1 %cond8298, label %bb_rcgnn1632, label %bb_rcgdone1632
bb_rcgnn1632:
  %v8299 = load i64, ptr %slot1285, align 8
  %op8300 = sub i64 %v8299, 16
  store i64 %op8300, ptr %slot1287, align 8
  %v8301 = load i64, ptr %slot1285, align 8
  %p8302 = inttoptr i64 %v8301 to ptr
  %rgep8303 = getelementptr i8, ptr %p8302, i64 -16
  %ld8304 = load i64, ptr %rgep8303, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8304, ptr %slot1288, align 8
  %v8305 = load i64, ptr %slot1288, align 8
  %op8306 = and i64 %v8305, 4611686018427387906
  store i64 %op8306, ptr %slot1289, align 8
  %v8307 = load i64, ptr %slot1289, align 8
  %cmp8308 = icmp ne i64 %v8307, 0
  %cv8309 = zext i1 %cmp8308 to i32
  store i32 %cv8309, ptr %slot1290, align 8
  %v8310 = load i32, ptr %slot1290, align 8
  %cv8311 = zext i32 %v8310 to i64
  %cond8312 = icmp ne i64 %cv8311, 0
  br i1 %cond8312, label %bb_rcgclear1632, label %bb_rcgcounted1632
bb_rcgcounted1632:
  %v8313 = load i64, ptr %slot1285, align 8
  %op8314 = sub i64 %v8313, 24
  store i64 %op8314, ptr %slot1291, align 8
  %v8315 = load i64, ptr %slot1285, align 8
  %p8316 = inttoptr i64 %v8315 to ptr
  %rgep8317 = getelementptr i8, ptr %p8316, i64 -24
  %ld8318 = load i64, ptr %rgep8317, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8318, ptr %slot1292, align 8
  %v8319 = load i64, ptr %slot1292, align 8
  %op8320 = sub i64 %v8319, 1
  store i64 %op8320, ptr %slot1293, align 8
  %v8321 = load i64, ptr %slot1293, align 8
  %cmp8322 = icmp eq i64 %v8321, 0
  %cv8323 = zext i1 %cmp8322 to i32
  store i32 %cv8323, ptr %slot1294, align 8
  %v8324 = load i32, ptr %slot1294, align 8
  %cv8325 = zext i32 %v8324 to i64
  %cond8326 = icmp ne i64 %cv8325, 0
  br i1 %cond8326, label %bb_rcglast1632, label %bb_rcgdec1632
bb_rcglast1632:
  %v8327 = load i64, ptr %slot1285, align 8
  %op8328 = sub i64 %v8327, 32
  store i64 %op8328, ptr %slot1295, align 8
  %v8329 = load i64, ptr %slot1285, align 8
  %p8330 = inttoptr i64 %v8329 to ptr
  %rgep8331 = getelementptr i8, ptr %p8330, i64 -32
  %ld8332 = load i64, ptr %rgep8331, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8332, ptr %slot1296, align 8
  %v8333 = load i64, ptr %slot1296, align 8
  %cmp8334 = icmp ne i64 %v8333, 0
  %cv8335 = zext i1 %cmp8334 to i32
  store i32 %cv8335, ptr %slot1297, align 8
  %v8336 = load i32, ptr %slot1297, align 8
  %cv8337 = zext i32 %v8336 to i64
  %cond8338 = icmp ne i64 %cv8337, 0
  br i1 %cond8338, label %bb_rcgdec1632, label %bb_rcgslow1632
bb_rcgslow1632:
  %v8339 = load i64, ptr %slot1284, align 8
  %v8340 = load i64, ptr %slot1281, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v8339, i64 %v8340) nomerge, !dbg !192
  br label %bb_rcgdone1632
bb_rcgdec1632:
  %v8341 = load i64, ptr %slot1293, align 8
  %v8342 = load i64, ptr %slot1285, align 8
  %p8343 = inttoptr i64 %v8342 to ptr
  %rgep8344 = getelementptr i8, ptr %p8343, i64 -24
  store i64 %v8341, ptr %rgep8344, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1632
bb_rcgclear1632:
  %v8345 = load i64, ptr %slot1281, align 8
  %p8346 = inttoptr i64 %v8345 to ptr
  store i64 0, ptr %p8346, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1632
bb_rcgdone1632:
  br label %bb_rcslotdone1616
bb_rcslotowner1616:
  %v8347 = load i64, ptr %slot99, align 8
  store i64 %v8347, ptr %slot1298, align 8
  %v8348 = load i64, ptr %slot1281, align 8
  %p8349 = inttoptr i64 %v8348 to ptr
  %ld8350 = load i64, ptr %p8349, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8350, ptr %slot1299, align 8
  %v8351 = load i64, ptr %slot1299, align 8
  %cmp8352 = icmp ne i64 %v8351, 0
  %cv8353 = zext i1 %cmp8352 to i32
  store i32 %cv8353, ptr %slot1300, align 8
  %v8354 = load i32, ptr %slot1300, align 8
  %cv8355 = zext i32 %v8354 to i64
  %cond8356 = icmp ne i64 %cv8355, 0
  br i1 %cond8356, label %bb_rcgnn1647, label %bb_rcgdone1647
bb_rcgnn1647:
  %v8357 = load i64, ptr %slot1299, align 8
  %op8358 = sub i64 %v8357, 16
  store i64 %op8358, ptr %slot1301, align 8
  %v8359 = load i64, ptr %slot1299, align 8
  %p8360 = inttoptr i64 %v8359 to ptr
  %rgep8361 = getelementptr i8, ptr %p8360, i64 -16
  %ld8362 = load i64, ptr %rgep8361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8362, ptr %slot1302, align 8
  %v8363 = load i64, ptr %slot1302, align 8
  %op8364 = and i64 %v8363, 4611686018427387906
  store i64 %op8364, ptr %slot1303, align 8
  %v8365 = load i64, ptr %slot1303, align 8
  %cmp8366 = icmp ne i64 %v8365, 0
  %cv8367 = zext i1 %cmp8366 to i32
  store i32 %cv8367, ptr %slot1304, align 8
  %v8368 = load i32, ptr %slot1304, align 8
  %cv8369 = zext i32 %v8368 to i64
  %cond8370 = icmp ne i64 %cv8369, 0
  br i1 %cond8370, label %bb_rcgclear1647, label %bb_rcgcounted1647
bb_rcgcounted1647:
  %v8371 = load i64, ptr %slot1299, align 8
  %op8372 = sub i64 %v8371, 32
  store i64 %op8372, ptr %slot1305, align 8
  %v8373 = load i64, ptr %slot1299, align 8
  %p8374 = inttoptr i64 %v8373 to ptr
  %rgep8375 = getelementptr i8, ptr %p8374, i64 -32
  %ld8376 = load i64, ptr %rgep8375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8376, ptr %slot1306, align 8
  %v8377 = load i64, ptr %slot1306, align 8
  %op8378 = sub i64 %v8377, 1
  store i64 %op8378, ptr %slot1307, align 8
  %v8379 = load i64, ptr %slot1307, align 8
  %cmp8380 = icmp eq i64 %v8379, 0
  %cv8381 = zext i1 %cmp8380 to i32
  store i32 %cv8381, ptr %slot1308, align 8
  %v8382 = load i32, ptr %slot1308, align 8
  %cv8383 = zext i32 %v8382 to i64
  %cond8384 = icmp ne i64 %cv8383, 0
  br i1 %cond8384, label %bb_rcglast1647, label %bb_rcgdec1647
bb_rcglast1647:
  %v8385 = load i64, ptr %slot1299, align 8
  %op8386 = sub i64 %v8385, 24
  store i64 %op8386, ptr %slot1309, align 8
  %v8387 = load i64, ptr %slot1299, align 8
  %p8388 = inttoptr i64 %v8387 to ptr
  %rgep8389 = getelementptr i8, ptr %p8388, i64 -24
  %ld8390 = load i64, ptr %rgep8389, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8390, ptr %slot1310, align 8
  %v8391 = load i64, ptr %slot1310, align 8
  %cmp8392 = icmp ne i64 %v8391, 0
  %cv8393 = zext i1 %cmp8392 to i32
  store i32 %cv8393, ptr %slot1311, align 8
  %v8394 = load i32, ptr %slot1311, align 8
  %cv8395 = zext i32 %v8394 to i64
  %cond8396 = icmp ne i64 %cv8395, 0
  br i1 %cond8396, label %bb_rcgdec1647, label %bb_rcgslow1647
bb_rcgslow1647:
  %v8397 = load i64, ptr %slot1298, align 8
  %v8398 = load i64, ptr %slot1281, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v8397, i64 %v8398) nomerge, !dbg !192
  br label %bb_rcgdone1647
bb_rcgdec1647:
  %v8399 = load i64, ptr %slot1307, align 8
  %v8400 = load i64, ptr %slot1299, align 8
  %p8401 = inttoptr i64 %v8400 to ptr
  %rgep8402 = getelementptr i8, ptr %p8401, i64 -32
  store i64 %v8399, ptr %rgep8402, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1647
bb_rcgclear1647:
  %v8403 = load i64, ptr %slot1281, align 8
  %p8404 = inttoptr i64 %v8403 to ptr
  store i64 0, ptr %p8404, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1647
bb_rcgdone1647:
  br label %bb_rcslotdone1616
bb_rcslotdone1616:
  %v8405 = load i64, ptr %slot5, align 8
  %p8406 = inttoptr i64 %v8405 to ptr
  %ld8407 = load i32, ptr %p8406, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8407, ptr %slot1312, align 8
  %v8408 = load i32, ptr %slot1312, align 8
  %cv8409 = zext i32 %v8408 to i64
  %cond8410 = icmp ne i64 %cv8409, 0
  br i1 %cond8410, label %bb_rcslotdrop1653, label %bb_rcslotdone1653
bb_rcslotdrop1653:
  %v8411 = load i64, ptr %slot5, align 8
  %p8412 = inttoptr i64 %v8411 to ptr
  store i32 0, ptr %p8412, align 4, !alias.scope !3, !noalias !4
  %v8413 = load i64, ptr %slot33, align 8
  store i64 %v8413, ptr %slot1313, align 8
  %v8414 = load i64, ptr %slot6, align 8
  %p8415 = inttoptr i64 %v8414 to ptr
  %ld8416 = load i32, ptr %p8415, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8416, ptr %slot1314, align 8
  %v8417 = load i32, ptr %slot1314, align 8
  %op8418 = and i32 %v8417, 28
  store i32 %op8418, ptr %slot1315, align 8
  %v8419 = load i32, ptr %slot1315, align 8
  %cv8420 = zext i32 %v8419 to i64
  %cond8421 = icmp ne i64 %cv8420, 0
  br i1 %cond8421, label %bb_rcslotrole1653, label %bb_rcslotowner1653
bb_rcslotrole1653:
  %v8422 = load i64, ptr %slot99, align 8
  store i64 %v8422, ptr %slot1316, align 8
  %v8423 = load i64, ptr %slot1316, align 8
  %v8424 = load i64, ptr %slot1313, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v8423, i64 %v8424) nomerge, !dbg !192
  br label %bb_rcslotdone1653
bb_rcslotowner1653:
  %v8425 = load i64, ptr %slot99, align 8
  store i64 %v8425, ptr %slot1317, align 8
  %v8426 = load i64, ptr %slot1317, align 8
  %v8427 = load i64, ptr %slot1313, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v8426, i64 %v8427) nomerge, !dbg !192
  br label %bb_rcslotdone1653
bb_rcslotdone1653:
  %v8428 = load i64, ptr %slot1234, align 8
  %p8429 = inttoptr i64 %v8428 to ptr
  %ret8430 = load { i64, i64 }, ptr %p8429, align 8
  ret { i64, i64 } %ret8430
bb_i104:
  %v8431 = load i64, ptr %slot32, align 8
  %p8432 = inttoptr i64 %v8431 to ptr
  %ld8433 = load i64, ptr %p8432, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8433, ptr %slot1318, align 8
  %v8434 = load i64, ptr %slot1318, align 8
  %v8435 = load i64, ptr %slot44, align 8
  %p8436 = inttoptr i64 %v8435 to ptr
  store i64 %v8434, ptr %p8436, align 8, !alias.scope !3, !noalias !4
  %v8437 = load i64, ptr %slot69, align 8
  store i64 %v8437, ptr %slot1319, align 8
  %v8438 = load i64, ptr %slot1319, align 8
  %p8439 = inttoptr i64 %v8438 to ptr
  store i32 0, ptr %p8439, align 4, !alias.scope !3, !noalias !4
  %v8440 = load i64, ptr %slot1319, align 8
  %p8441 = inttoptr i64 %v8440 to ptr
  store i32 33, ptr %p8441, align 4, !alias.scope !3, !noalias !4
  %v8442 = load i64, ptr %slot1319, align 8
  %v8443 = load i64, ptr %slot45, align 8
  %p8444 = inttoptr i64 %v8443 to ptr
  store i64 %v8442, ptr %p8444, align 8, !alias.scope !3, !noalias !4
  %v8445 = load i64, ptr %slot44, align 8
  %p8446 = inttoptr i64 %v8445 to ptr
  %ld8447 = load i64, ptr %p8446, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8447, ptr %slot1320, align 8
  %v8448 = load i64, ptr %slot45, align 8
  %p8449 = inttoptr i64 %v8448 to ptr
  %ld8450 = load i64, ptr %p8449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8450, ptr %slot1321, align 8
  %v8451 = load i64, ptr %slot1, align 8
  %v8452 = load i64, ptr %slot1320, align 8
  %v8453 = load i64, ptr %slot1321, align 8
  %call8454 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v8451, i64 %v8452, i64 %v8453) nomerge, !dbg !194
  store i64 %call8454, ptr %slot1322, align 8
  %v8455 = load i64, ptr %slot1322, align 8
  %v8456 = load i64, ptr %slot44, align 8
  %p8457 = inttoptr i64 %v8456 to ptr
  store i64 %v8455, ptr %p8457, align 8, !alias.scope !3, !noalias !4
  %v8458 = load i64, ptr %slot15, align 8
  %p8459 = inttoptr i64 %v8458 to ptr
  %ld8460 = load i32, ptr %p8459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8460, ptr %slot1323, align 8
  %v8461 = load i32, ptr %slot1323, align 8
  %cv8462 = zext i32 %v8461 to i64
  %cond8463 = icmp ne i64 %cv8462, 0
  br i1 %cond8463, label %bb_rcslotdrop1676, label %bb_rcslotdone1676
bb_rcslotdrop1676:
  %v8464 = load i64, ptr %slot15, align 8
  %p8465 = inttoptr i64 %v8464 to ptr
  store i32 0, ptr %p8465, align 4, !alias.scope !3, !noalias !4
  %v8466 = load i64, ptr %slot24, align 8
  store i64 %v8466, ptr %slot1324, align 8
  %v8467 = load i64, ptr %slot16, align 8
  %p8468 = inttoptr i64 %v8467 to ptr
  %ld8469 = load i32, ptr %p8468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8469, ptr %slot1325, align 8
  %v8470 = load i32, ptr %slot1325, align 8
  %op8471 = and i32 %v8470, 28
  store i32 %op8471, ptr %slot1326, align 8
  %v8472 = load i32, ptr %slot1326, align 8
  %cv8473 = zext i32 %v8472 to i64
  %cond8474 = icmp ne i64 %cv8473, 0
  br i1 %cond8474, label %bb_rcslotrole1676, label %bb_rcslotowner1676
bb_rcslotrole1676:
  %v8475 = load i64, ptr %slot99, align 8
  store i64 %v8475, ptr %slot1327, align 8
  %v8476 = load i64, ptr %slot1327, align 8
  %v8477 = load i64, ptr %slot1324, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v8476, i64 %v8477) nomerge, !dbg !194
  br label %bb_rcslotdone1676
bb_rcslotowner1676:
  %v8478 = load i64, ptr %slot99, align 8
  store i64 %v8478, ptr %slot1328, align 8
  %v8479 = load i64, ptr %slot1328, align 8
  %v8480 = load i64, ptr %slot1324, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v8479, i64 %v8480) nomerge, !dbg !194
  br label %bb_rcslotdone1676
bb_rcslotdone1676:
  %v8481 = load i64, ptr %slot44, align 8
  %p8482 = inttoptr i64 %v8481 to ptr
  %ld8483 = load i64, ptr %p8482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8483, ptr %slot1329, align 8
  %v8484 = load i64, ptr %slot1329, align 8
  %cond8485 = icmp ne i64 %v8484, 0
  br i1 %cond8485, label %bb_next1684, label %bb_i140
bb_next1684:
  %v8486 = load i64, ptr %slot32, align 8
  %p8487 = inttoptr i64 %v8486 to ptr
  %ld8488 = load i64, ptr %p8487, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8488, ptr %slot1330, align 8
  %v8489 = load i64, ptr %slot1330, align 8
  %v8490 = load i64, ptr %slot44, align 8
  %p8491 = inttoptr i64 %v8490 to ptr
  store i64 %v8489, ptr %p8491, align 8, !alias.scope !3, !noalias !4
  %v8492 = load i64, ptr %slot44, align 8
  %p8493 = inttoptr i64 %v8492 to ptr
  %ld8494 = load i64, ptr %p8493, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8494, ptr %slot1331, align 8
  %v8495 = load i64, ptr %slot1, align 8
  %v8496 = load i64, ptr %slot1331, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult1333, i64 %v8495, i64 %v8496) nomerge, !dbg !196
  %addr8497 = ptrtoint ptr %callresult1333 to i64
  store i64 %addr8497, ptr %slot1332, align 8
  %v8498 = load i64, ptr %slot1332, align 8
  %v8499 = load i64, ptr %slot44, align 8
  %p8500 = inttoptr i64 %v8499 to ptr
  store i64 %v8498, ptr %p8500, align 8, !alias.scope !3, !noalias !4
  %v8501 = load i64, ptr %slot44, align 8
  %p8502 = inttoptr i64 %v8501 to ptr
  %ld8503 = load i64, ptr %p8502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8503, ptr %slot1334, align 8
  %v8504 = load i64, ptr %slot30, align 8
  store i64 %v8504, ptr %slot1335, align 8
  %v8505 = load i64, ptr %slot99, align 8
  %v8506 = load i64, ptr %slot1335, align 8
  %v8507 = load i64, ptr %slot1334, align 8
  %call8508 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v8505, i64 %v8506, i64 %v8507) nomerge, !dbg !196
  store i32 %call8508, ptr %slot1336, align 8
  %v8509 = load i32, ptr %slot1336, align 8
  %cv8510 = zext i32 %v8509 to i64
  %cond8511 = icmp ne i64 %cv8510, 0
  br i1 %cond8511, label %bb_rcsuccess1690, label %bb_rcfailure1690
bb_rcfailure1690:
  %v8512 = load i64, ptr %slot99, align 8
  %p8513 = inttoptr i64 %v8512 to ptr
  %call8514 = call i32 @myl_rc_take_failure(ptr %p8513) nomerge, !dbg !196
  store i32 %call8514, ptr %slot1337, align 8
  %v8515 = load i64, ptr %slot1, align 8
  %p8516 = inttoptr i64 %v8515 to ptr
  %v8517 = load i32, ptr %slot1337, align 8
  %call8518 = call i32 @myl_qbe_rc_status(ptr %p8516, i32 %v8517) nomerge, !dbg !196
  store i32 %call8518, ptr %slot1338, align 8
  br label %bb_failure
bb_rcsuccess1690:
  %v8519 = load i64, ptr %slot22, align 8
  %p8520 = inttoptr i64 %v8519 to ptr
  store i32 2, ptr %p8520, align 4, !alias.scope !3, !noalias !4
  %v8521 = load i64, ptr %slot22, align 8
  %p8522 = inttoptr i64 %v8521 to ptr
  store i32 16, ptr %p8522, align 4, !alias.scope !3, !noalias !4
  %v8523 = load i64, ptr %slot21, align 8
  %p8524 = inttoptr i64 %v8523 to ptr
  store i32 1, ptr %p8524, align 4, !alias.scope !3, !noalias !4
  %v8525 = load i64, ptr %slot15, align 8
  %p8526 = inttoptr i64 %v8525 to ptr
  %ld8527 = load i32, ptr %p8526, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8527, ptr %slot1339, align 8
  %v8528 = load i32, ptr %slot1339, align 8
  %cv8529 = zext i32 %v8528 to i64
  %cond8530 = icmp ne i64 %cv8529, 0
  br i1 %cond8530, label %bb_rcslotdrop1698, label %bb_rcslotdone1698
bb_rcslotdrop1698:
  %v8531 = load i64, ptr %slot15, align 8
  %p8532 = inttoptr i64 %v8531 to ptr
  store i32 0, ptr %p8532, align 4, !alias.scope !3, !noalias !4
  %v8533 = load i64, ptr %slot24, align 8
  store i64 %v8533, ptr %slot1340, align 8
  %v8534 = load i64, ptr %slot16, align 8
  %p8535 = inttoptr i64 %v8534 to ptr
  %ld8536 = load i32, ptr %p8535, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8536, ptr %slot1341, align 8
  %v8537 = load i32, ptr %slot1341, align 8
  %op8538 = and i32 %v8537, 28
  store i32 %op8538, ptr %slot1342, align 8
  %v8539 = load i32, ptr %slot1342, align 8
  %cv8540 = zext i32 %v8539 to i64
  %cond8541 = icmp ne i64 %cv8540, 0
  br i1 %cond8541, label %bb_rcslotrole1698, label %bb_rcslotowner1698
bb_rcslotrole1698:
  %v8542 = load i64, ptr %slot99, align 8
  store i64 %v8542, ptr %slot1343, align 8
  %v8543 = load i64, ptr %slot1343, align 8
  %v8544 = load i64, ptr %slot1340, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v8543, i64 %v8544) nomerge, !dbg !196
  br label %bb_rcslotdone1698
bb_rcslotowner1698:
  %v8545 = load i64, ptr %slot99, align 8
  store i64 %v8545, ptr %slot1344, align 8
  %v8546 = load i64, ptr %slot1344, align 8
  %v8547 = load i64, ptr %slot1340, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v8546, i64 %v8547) nomerge, !dbg !196
  br label %bb_rcslotdone1698
bb_rcslotdone1698:
  %v8548 = load i64, ptr %slot24, align 8
  store i64 %v8548, ptr %slot1345, align 8
  %v8549 = load i64, ptr %slot30, align 8
  store i64 %v8549, ptr %slot1346, align 8
  %v8550 = load i64, ptr %slot1346, align 8
  %v8551 = load i64, ptr %slot1345, align 8
  %p8552 = inttoptr i64 %v8550 to ptr
  %p8553 = inttoptr i64 %v8551 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8553, ptr %p8552, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v8554 = load i64, ptr %slot16, align 8
  %p8555 = inttoptr i64 %v8554 to ptr
  store i32 2, ptr %p8555, align 4, !alias.scope !3, !noalias !4
  %v8556 = load i64, ptr %slot22, align 8
  %p8557 = inttoptr i64 %v8556 to ptr
  %ld8558 = load i32, ptr %p8557, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8558, ptr %slot1347, align 8
  %v8559 = load i32, ptr %slot1347, align 8
  %v8560 = load i64, ptr %slot16, align 8
  %p8561 = inttoptr i64 %v8560 to ptr
  store i32 %v8559, ptr %p8561, align 4, !alias.scope !3, !noalias !4
  %v8562 = load i64, ptr %slot21, align 8
  %p8563 = inttoptr i64 %v8562 to ptr
  store i32 0, ptr %p8563, align 4, !alias.scope !3, !noalias !4
  %v8564 = load i64, ptr %slot15, align 8
  %p8565 = inttoptr i64 %v8564 to ptr
  store i32 1, ptr %p8565, align 4, !alias.scope !3, !noalias !4
  %v8566 = load i64, ptr %slot1345, align 8
  %v8567 = load i64, ptr %slot44, align 8
  %p8568 = inttoptr i64 %v8567 to ptr
  store i64 %v8566, ptr %p8568, align 8, !alias.scope !3, !noalias !4
  %v8569 = load i64, ptr %slot44, align 8
  %p8570 = inttoptr i64 %v8569 to ptr
  %ld8571 = load i64, ptr %p8570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8571, ptr %slot1348, align 8
  %v8572 = load i64, ptr %slot15, align 8
  %p8573 = inttoptr i64 %v8572 to ptr
  %ld8574 = load i32, ptr %p8573, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8574, ptr %slot1349, align 8
  %v8575 = load i64, ptr %slot16, align 8
  %p8576 = inttoptr i64 %v8575 to ptr
  %ld8577 = load i32, ptr %p8576, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8577, ptr %slot1350, align 8
  %v8578 = load i32, ptr %slot1350, align 8
  %op8579 = and i32 %v8578, 24
  store i32 %op8579, ptr %slot1350, align 8
  %v8580 = load i32, ptr %slot1350, align 8
  %cmp8581 = icmp eq i32 %v8580, 0
  %cv8582 = zext i1 %cmp8581 to i32
  store i32 %cv8582, ptr %slot1351, align 8
  %v8583 = load i32, ptr %slot1349, align 8
  %v8584 = load i32, ptr %slot1351, align 8
  %op8585 = and i32 %v8583, %v8584
  store i32 %op8585, ptr %slot1352, align 8
  %v8586 = load i32, ptr %slot1352, align 8
  %cv8587 = zext i32 %v8586 to i64
  %cond8588 = icmp ne i64 %cv8587, 0
  br i1 %cond8588, label %bb_rctake1714, label %bb_rccopy1714
bb_rctake1714:
  %v8589 = load i64, ptr %slot30, align 8
  store i64 %v8589, ptr %slot1353, align 8
  %v8590 = load i64, ptr %slot100, align 8
  store i64 %v8590, ptr %slot1354, align 8
  %v8591 = load i64, ptr %slot99, align 8
  %v8592 = load i64, ptr %slot1353, align 8
  %v8593 = load i64, ptr %slot1348, align 8
  %v8594 = load i64, ptr %slot1354, align 8
  %cv8595 = trunc i64 %v8594 to i32
  %call8596 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v8591, i64 %v8592, i64 %v8593, i32 %cv8595) nomerge, !dbg !198
  store i32 %call8596, ptr %slot1355, align 8
  %v8597 = load i32, ptr %slot1355, align 8
  %cv8598 = zext i32 %v8597 to i64
  %cond8599 = icmp ne i64 %cv8598, 0
  br i1 %cond8599, label %bb_rcsuccess1724, label %bb_rcfailure1724
bb_rcfailure1724:
  %v8600 = load i64, ptr %slot99, align 8
  %p8601 = inttoptr i64 %v8600 to ptr
  %call8602 = call i32 @myl_rc_take_failure(ptr %p8601) nomerge, !dbg !198
  store i32 %call8602, ptr %slot1356, align 8
  %v8603 = load i64, ptr %slot1, align 8
  %p8604 = inttoptr i64 %v8603 to ptr
  %v8605 = load i32, ptr %slot1356, align 8
  %call8606 = call i32 @myl_qbe_rc_status(ptr %p8604, i32 %v8605) nomerge, !dbg !198
  store i32 %call8606, ptr %slot1357, align 8
  br label %bb_failure
bb_rcsuccess1724:
  %v8607 = load i64, ptr %slot15, align 8
  %p8608 = inttoptr i64 %v8607 to ptr
  store i32 0, ptr %p8608, align 4, !alias.scope !3, !noalias !4
  %v8609 = load i64, ptr %slot22, align 8
  %p8610 = inttoptr i64 %v8609 to ptr
  store i32 2, ptr %p8610, align 4, !alias.scope !3, !noalias !4
  %v8611 = load i64, ptr %slot21, align 8
  %p8612 = inttoptr i64 %v8611 to ptr
  store i32 1, ptr %p8612, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1714
bb_rccopy1714:
  %v8613 = load i64, ptr %slot30, align 8
  store i64 %v8613, ptr %slot1358, align 8
  %v8614 = load i64, ptr %slot100, align 8
  store i64 %v8614, ptr %slot1359, align 8
  %v8615 = load i64, ptr %slot99, align 8
  %v8616 = load i64, ptr %slot1358, align 8
  %v8617 = load i64, ptr %slot1348, align 8
  %v8618 = load i64, ptr %slot1359, align 8
  %cv8619 = trunc i64 %v8618 to i32
  %call8620 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v8615, i64 %v8616, i64 %v8617, i32 %cv8619) nomerge, !dbg !198
  store i32 %call8620, ptr %slot1360, align 8
  %v8621 = load i32, ptr %slot1360, align 8
  %cv8622 = zext i32 %v8621 to i64
  %cond8623 = icmp ne i64 %cv8622, 0
  br i1 %cond8623, label %bb_rcsuccess1733, label %bb_rcfailure1733
bb_rcfailure1733:
  %v8624 = load i64, ptr %slot99, align 8
  %p8625 = inttoptr i64 %v8624 to ptr
  %call8626 = call i32 @myl_rc_take_failure(ptr %p8625) nomerge, !dbg !198
  store i32 %call8626, ptr %slot1361, align 8
  %v8627 = load i64, ptr %slot1, align 8
  %p8628 = inttoptr i64 %v8627 to ptr
  %v8629 = load i32, ptr %slot1361, align 8
  %call8630 = call i32 @myl_qbe_rc_status(ptr %p8628, i32 %v8629) nomerge, !dbg !198
  store i32 %call8630, ptr %slot1362, align 8
  br label %bb_failure
bb_rcsuccess1733:
  %v8631 = load i64, ptr %slot22, align 8
  %p8632 = inttoptr i64 %v8631 to ptr
  store i32 2, ptr %p8632, align 4, !alias.scope !3, !noalias !4
  %v8633 = load i64, ptr %slot21, align 8
  %p8634 = inttoptr i64 %v8633 to ptr
  store i32 1, ptr %p8634, align 4, !alias.scope !3, !noalias !4
  %v8635 = load i64, ptr %slot15, align 8
  %p8636 = inttoptr i64 %v8635 to ptr
  %ld8637 = load i32, ptr %p8636, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8637, ptr %slot1363, align 8
  %v8638 = load i32, ptr %slot1363, align 8
  %cv8639 = zext i32 %v8638 to i64
  %cond8640 = icmp ne i64 %cv8639, 0
  br i1 %cond8640, label %bb_rcslotdrop1740, label %bb_rcslotdone1740
bb_rcslotdrop1740:
  %v8641 = load i64, ptr %slot15, align 8
  %p8642 = inttoptr i64 %v8641 to ptr
  store i32 0, ptr %p8642, align 4, !alias.scope !3, !noalias !4
  %v8643 = load i64, ptr %slot24, align 8
  store i64 %v8643, ptr %slot1364, align 8
  %v8644 = load i64, ptr %slot16, align 8
  %p8645 = inttoptr i64 %v8644 to ptr
  %ld8646 = load i32, ptr %p8645, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8646, ptr %slot1365, align 8
  %v8647 = load i32, ptr %slot1365, align 8
  %op8648 = and i32 %v8647, 28
  store i32 %op8648, ptr %slot1366, align 8
  %v8649 = load i32, ptr %slot1366, align 8
  %cv8650 = zext i32 %v8649 to i64
  %cond8651 = icmp ne i64 %cv8650, 0
  br i1 %cond8651, label %bb_rcslotrole1740, label %bb_rcslotowner1740
bb_rcslotrole1740:
  %v8652 = load i64, ptr %slot99, align 8
  store i64 %v8652, ptr %slot1367, align 8
  %v8653 = load i64, ptr %slot1367, align 8
  %v8654 = load i64, ptr %slot1364, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v8653, i64 %v8654) nomerge, !dbg !198
  br label %bb_rcslotdone1740
bb_rcslotowner1740:
  %v8655 = load i64, ptr %slot99, align 8
  store i64 %v8655, ptr %slot1368, align 8
  %v8656 = load i64, ptr %slot1368, align 8
  %v8657 = load i64, ptr %slot1364, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v8656, i64 %v8657) nomerge, !dbg !198
  br label %bb_rcslotdone1740
bb_rcslotdone1740:
  br label %bb_rcprepared1714
bb_rcprepared1714:
  %v8658 = load i64, ptr %slot11, align 8
  %p8659 = inttoptr i64 %v8658 to ptr
  %ld8660 = load i32, ptr %p8659, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8660, ptr %slot1369, align 8
  %v8661 = load i32, ptr %slot1369, align 8
  %cv8662 = zext i32 %v8661 to i64
  %cond8663 = icmp ne i64 %cv8662, 0
  br i1 %cond8663, label %bb_rcslotdrop1750, label %bb_rcslotdone1750
bb_rcslotdrop1750:
  %v8664 = load i64, ptr %slot11, align 8
  %p8665 = inttoptr i64 %v8664 to ptr
  store i32 0, ptr %p8665, align 4, !alias.scope !3, !noalias !4
  %v8666 = load i64, ptr %slot41, align 8
  store i64 %v8666, ptr %slot1370, align 8
  %v8667 = load i64, ptr %slot12, align 8
  %p8668 = inttoptr i64 %v8667 to ptr
  %ld8669 = load i32, ptr %p8668, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8669, ptr %slot1371, align 8
  %v8670 = load i32, ptr %slot1371, align 8
  %op8671 = and i32 %v8670, 28
  store i32 %op8671, ptr %slot1372, align 8
  %v8672 = load i32, ptr %slot1372, align 8
  %cv8673 = zext i32 %v8672 to i64
  %cond8674 = icmp ne i64 %cv8673, 0
  br i1 %cond8674, label %bb_rcslotrole1750, label %bb_rcslotowner1750
bb_rcslotrole1750:
  %v8675 = load i64, ptr %slot99, align 8
  store i64 %v8675, ptr %slot1373, align 8
  %v8676 = load i64, ptr %slot1373, align 8
  %v8677 = load i64, ptr %slot1370, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v8676, i64 %v8677) nomerge, !dbg !198
  br label %bb_rcslotdone1750
bb_rcslotowner1750:
  %v8678 = load i64, ptr %slot99, align 8
  store i64 %v8678, ptr %slot1374, align 8
  %v8679 = load i64, ptr %slot1374, align 8
  %v8680 = load i64, ptr %slot1370, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v8679, i64 %v8680) nomerge, !dbg !198
  br label %bb_rcslotdone1750
bb_rcslotdone1750:
  %v8681 = load i64, ptr %slot41, align 8
  store i64 %v8681, ptr %slot1375, align 8
  %v8682 = load i64, ptr %slot30, align 8
  store i64 %v8682, ptr %slot1376, align 8
  %v8683 = load i64, ptr %slot1376, align 8
  %v8684 = load i64, ptr %slot1375, align 8
  %p8685 = inttoptr i64 %v8683 to ptr
  %p8686 = inttoptr i64 %v8684 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8686, ptr %p8685, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v8687 = load i64, ptr %slot21, align 8
  %p8688 = inttoptr i64 %v8687 to ptr
  store i32 0, ptr %p8688, align 4, !alias.scope !3, !noalias !4
  %v8689 = load i64, ptr %slot12, align 8
  %p8690 = inttoptr i64 %v8689 to ptr
  store i32 2, ptr %p8690, align 4, !alias.scope !3, !noalias !4
  %v8691 = load i64, ptr %slot22, align 8
  %p8692 = inttoptr i64 %v8691 to ptr
  %ld8693 = load i32, ptr %p8692, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8693, ptr %slot1377, align 8
  %v8694 = load i32, ptr %slot1377, align 8
  %v8695 = load i64, ptr %slot12, align 8
  %p8696 = inttoptr i64 %v8695 to ptr
  store i32 %v8694, ptr %p8696, align 4, !alias.scope !3, !noalias !4
  %v8697 = load i64, ptr %slot11, align 8
  %p8698 = inttoptr i64 %v8697 to ptr
  store i32 1, ptr %p8698, align 4, !alias.scope !3, !noalias !4
  %v8699 = load i64, ptr %slot32, align 8
  %p8700 = inttoptr i64 %v8699 to ptr
  %ld8701 = load i64, ptr %p8700, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8701, ptr %slot1378, align 8
  %v8702 = load i64, ptr %slot1378, align 8
  %v8703 = load i64, ptr %slot44, align 8
  %p8704 = inttoptr i64 %v8703 to ptr
  store i64 %v8702, ptr %p8704, align 8, !alias.scope !3, !noalias !4
  %v8705 = load i64, ptr %slot70, align 8
  store i64 %v8705, ptr %slot1379, align 8
  %v8706 = load i64, ptr %slot1379, align 8
  %p8707 = inttoptr i64 %v8706 to ptr
  store i32 0, ptr %p8707, align 4, !alias.scope !3, !noalias !4
  %v8708 = load i64, ptr %slot1379, align 8
  %p8709 = inttoptr i64 %v8708 to ptr
  store i32 5, ptr %p8709, align 4, !alias.scope !3, !noalias !4
  %v8710 = load i64, ptr %slot1379, align 8
  %v8711 = load i64, ptr %slot45, align 8
  %p8712 = inttoptr i64 %v8711 to ptr
  store i64 %v8710, ptr %p8712, align 8, !alias.scope !3, !noalias !4
  %p8713 = inttoptr i64 ptrtoint (ptr @myl_lit_881974f73ada6aff407ebfba62bf871f256bbdf7b656c2f7273e09ae58fa4d70 to i64) to ptr
  %ld8714 = load i64, ptr %p8713, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8714, ptr %slot1380, align 8
  %v8715 = load i64, ptr %slot1380, align 8
  %v8716 = load i64, ptr %slot46, align 8
  %p8717 = inttoptr i64 %v8716 to ptr
  store i64 %v8715, ptr %p8717, align 8, !alias.scope !3, !noalias !4
  %v8718 = load i64, ptr %slot46, align 8
  %p8719 = inttoptr i64 %v8718 to ptr
  %ld8720 = load i64, ptr %p8719, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8720, ptr %slot1381, align 8
  %v8721 = load i64, ptr %slot1381, align 8
  %v8722 = load i64, ptr %slot29, align 8
  %p8723 = inttoptr i64 %v8722 to ptr
  store i64 %v8721, ptr %p8723, align 8, !alias.scope !3, !noalias !4
  %v8724 = load i64, ptr %slot29, align 8
  store i64 %v8724, ptr %slot1382, align 8
  %v8725 = load i64, ptr %slot30, align 8
  store i64 %v8725, ptr %slot1383, align 8
  %v8726 = load i64, ptr %slot1382, align 8
  %v8727 = load i64, ptr %slot1383, align 8
  %p8728 = inttoptr i64 %v8726 to ptr
  %p8729 = inttoptr i64 %v8727 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8729, ptr %p8728, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8730 = load i64, ptr %slot22, align 8
  %p8731 = inttoptr i64 %v8730 to ptr
  store i32 2, ptr %p8731, align 4, !alias.scope !3, !noalias !4
  %v8732 = load i64, ptr %slot21, align 8
  %p8733 = inttoptr i64 %v8732 to ptr
  store i32 1, ptr %p8733, align 4, !alias.scope !3, !noalias !4
  %v8734 = load i64, ptr %slot26, align 8
  store i64 %v8734, ptr %slot1384, align 8
  %v8735 = load i64, ptr %slot30, align 8
  store i64 %v8735, ptr %slot1385, align 8
  %v8736 = load i64, ptr %slot1385, align 8
  %v8737 = load i64, ptr %slot1384, align 8
  %p8738 = inttoptr i64 %v8736 to ptr
  %p8739 = inttoptr i64 %v8737 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8739, ptr %p8738, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8740 = load i64, ptr %slot20, align 8
  %p8741 = inttoptr i64 %v8740 to ptr
  store i32 2, ptr %p8741, align 4, !alias.scope !3, !noalias !4
  %v8742 = load i64, ptr %slot22, align 8
  %p8743 = inttoptr i64 %v8742 to ptr
  %ld8744 = load i32, ptr %p8743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8744, ptr %slot1386, align 8
  %v8745 = load i32, ptr %slot1386, align 8
  %v8746 = load i64, ptr %slot20, align 8
  %p8747 = inttoptr i64 %v8746 to ptr
  store i32 %v8745, ptr %p8747, align 4, !alias.scope !3, !noalias !4
  %v8748 = load i64, ptr %slot21, align 8
  %p8749 = inttoptr i64 %v8748 to ptr
  store i32 0, ptr %p8749, align 4, !alias.scope !3, !noalias !4
  %v8750 = load i64, ptr %slot19, align 8
  %p8751 = inttoptr i64 %v8750 to ptr
  store i32 1, ptr %p8751, align 4, !alias.scope !3, !noalias !4
  %v8752 = load i64, ptr %slot1384, align 8
  %p8753 = inttoptr i64 %v8752 to ptr
  %ld8754 = load i64, ptr %p8753, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8754, ptr %slot1387, align 8
  %v8755 = load i64, ptr %slot1387, align 8
  %v8756 = load i64, ptr %slot46, align 8
  %p8757 = inttoptr i64 %v8756 to ptr
  store i64 %v8755, ptr %p8757, align 8, !alias.scope !3, !noalias !4
  %v8758 = load i64, ptr %slot44, align 8
  %p8759 = inttoptr i64 %v8758 to ptr
  %ld8760 = load i64, ptr %p8759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8760, ptr %slot1388, align 8
  %v8761 = load i64, ptr %slot45, align 8
  %p8762 = inttoptr i64 %v8761 to ptr
  %ld8763 = load i64, ptr %p8762, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8763, ptr %slot1389, align 8
  %v8764 = load i64, ptr %slot46, align 8
  %p8765 = inttoptr i64 %v8764 to ptr
  %ld8766 = load i64, ptr %p8765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8766, ptr %slot1390, align 8
  %v8767 = load i64, ptr %slot1, align 8
  %v8768 = load i64, ptr %slot1388, align 8
  %v8769 = load i64, ptr %slot1389, align 8
  %v8770 = load i64, ptr %slot1390, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult1392, i64 %v8767, i64 %v8768, i64 %v8769, i64 %v8770) nomerge, !dbg !200
  %addr8771 = ptrtoint ptr %callresult1392 to i64
  store i64 %addr8771, ptr %slot1391, align 8
  %v8772 = load i64, ptr %slot1391, align 8
  %v8773 = load i64, ptr %slot44, align 8
  %p8774 = inttoptr i64 %v8773 to ptr
  store i64 %v8772, ptr %p8774, align 8, !alias.scope !3, !noalias !4
  %v8775 = load i64, ptr %slot44, align 8
  %p8776 = inttoptr i64 %v8775 to ptr
  %ld8777 = load i64, ptr %p8776, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8777, ptr %slot1393, align 8
  %v8778 = load i64, ptr %slot30, align 8
  store i64 %v8778, ptr %slot1394, align 8
  %v8779 = load i64, ptr %slot1393, align 8
  %v8780 = load i64, ptr %slot1394, align 8
  %p8781 = inttoptr i64 %v8779 to ptr
  %p8782 = inttoptr i64 %v8780 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8782, ptr %p8781, i64 48, i1 false)
  %v8783 = load i64, ptr %slot22, align 8
  %p8784 = inttoptr i64 %v8783 to ptr
  store i32 2, ptr %p8784, align 4, !alias.scope !3, !noalias !4
  %v8785 = load i64, ptr %slot21, align 8
  %p8786 = inttoptr i64 %v8785 to ptr
  store i32 1, ptr %p8786, align 4, !alias.scope !3, !noalias !4
  %v8787 = load i64, ptr %slot15, align 8
  %p8788 = inttoptr i64 %v8787 to ptr
  %ld8789 = load i32, ptr %p8788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8789, ptr %slot1395, align 8
  %v8790 = load i32, ptr %slot1395, align 8
  %cv8791 = zext i32 %v8790 to i64
  %cond8792 = icmp ne i64 %cv8791, 0
  br i1 %cond8792, label %bb_rcslotdrop1792, label %bb_rcslotdone1792
bb_rcslotdrop1792:
  %v8793 = load i64, ptr %slot15, align 8
  %p8794 = inttoptr i64 %v8793 to ptr
  store i32 0, ptr %p8794, align 4, !alias.scope !3, !noalias !4
  %v8795 = load i64, ptr %slot24, align 8
  store i64 %v8795, ptr %slot1396, align 8
  %v8796 = load i64, ptr %slot16, align 8
  %p8797 = inttoptr i64 %v8796 to ptr
  %ld8798 = load i32, ptr %p8797, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8798, ptr %slot1397, align 8
  %v8799 = load i32, ptr %slot1397, align 8
  %op8800 = and i32 %v8799, 28
  store i32 %op8800, ptr %slot1398, align 8
  %v8801 = load i32, ptr %slot1398, align 8
  %cv8802 = zext i32 %v8801 to i64
  %cond8803 = icmp ne i64 %cv8802, 0
  br i1 %cond8803, label %bb_rcslotrole1792, label %bb_rcslotowner1792
bb_rcslotrole1792:
  %v8804 = load i64, ptr %slot99, align 8
  store i64 %v8804, ptr %slot1399, align 8
  %v8805 = load i64, ptr %slot1399, align 8
  %v8806 = load i64, ptr %slot1396, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v8805, i64 %v8806) nomerge, !dbg !200
  br label %bb_rcslotdone1792
bb_rcslotowner1792:
  %v8807 = load i64, ptr %slot99, align 8
  store i64 %v8807, ptr %slot1400, align 8
  %v8808 = load i64, ptr %slot1400, align 8
  %v8809 = load i64, ptr %slot1396, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v8808, i64 %v8809) nomerge, !dbg !200
  br label %bb_rcslotdone1792
bb_rcslotdone1792:
  %v8810 = load i64, ptr %slot19, align 8
  %p8811 = inttoptr i64 %v8810 to ptr
  %ld8812 = load i32, ptr %p8811, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8812, ptr %slot1401, align 8
  %v8813 = load i32, ptr %slot1401, align 8
  %cv8814 = zext i32 %v8813 to i64
  %cond8815 = icmp ne i64 %cv8814, 0
  br i1 %cond8815, label %bb_rcslotdrop1801, label %bb_rcslotdone1801
bb_rcslotdrop1801:
  %v8816 = load i64, ptr %slot19, align 8
  %p8817 = inttoptr i64 %v8816 to ptr
  store i32 0, ptr %p8817, align 4, !alias.scope !3, !noalias !4
  %v8818 = load i64, ptr %slot26, align 8
  store i64 %v8818, ptr %slot1402, align 8
  %v8819 = load i64, ptr %slot20, align 8
  %p8820 = inttoptr i64 %v8819 to ptr
  %ld8821 = load i32, ptr %p8820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8821, ptr %slot1403, align 8
  %v8822 = load i32, ptr %slot1403, align 8
  %op8823 = and i32 %v8822, 28
  store i32 %op8823, ptr %slot1404, align 8
  %v8824 = load i32, ptr %slot1404, align 8
  %cv8825 = zext i32 %v8824 to i64
  %cond8826 = icmp ne i64 %cv8825, 0
  br i1 %cond8826, label %bb_rcslotrole1801, label %bb_rcslotowner1801
bb_rcslotrole1801:
  %v8827 = load i64, ptr %slot99, align 8
  store i64 %v8827, ptr %slot1405, align 8
  %v8828 = load i64, ptr %slot1402, align 8
  %p8829 = inttoptr i64 %v8828 to ptr
  %ld8830 = load i64, ptr %p8829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8830, ptr %slot1406, align 8
  %v8831 = load i64, ptr %slot1406, align 8
  %cmp8832 = icmp ne i64 %v8831, 0
  %cv8833 = zext i1 %cmp8832 to i32
  store i32 %cv8833, ptr %slot1407, align 8
  %v8834 = load i32, ptr %slot1407, align 8
  %cv8835 = zext i32 %v8834 to i64
  %cond8836 = icmp ne i64 %cv8835, 0
  br i1 %cond8836, label %bb_rcgnn1817, label %bb_rcgdone1817
bb_rcgnn1817:
  %v8837 = load i64, ptr %slot1406, align 8
  %op8838 = sub i64 %v8837, 16
  store i64 %op8838, ptr %slot1408, align 8
  %v8839 = load i64, ptr %slot1406, align 8
  %p8840 = inttoptr i64 %v8839 to ptr
  %rgep8841 = getelementptr i8, ptr %p8840, i64 -16
  %ld8842 = load i64, ptr %rgep8841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8842, ptr %slot1409, align 8
  %v8843 = load i64, ptr %slot1409, align 8
  %op8844 = and i64 %v8843, 4611686018427387906
  store i64 %op8844, ptr %slot1410, align 8
  %v8845 = load i64, ptr %slot1410, align 8
  %cmp8846 = icmp ne i64 %v8845, 0
  %cv8847 = zext i1 %cmp8846 to i32
  store i32 %cv8847, ptr %slot1411, align 8
  %v8848 = load i32, ptr %slot1411, align 8
  %cv8849 = zext i32 %v8848 to i64
  %cond8850 = icmp ne i64 %cv8849, 0
  br i1 %cond8850, label %bb_rcgclear1817, label %bb_rcgcounted1817
bb_rcgcounted1817:
  %v8851 = load i64, ptr %slot1406, align 8
  %op8852 = sub i64 %v8851, 24
  store i64 %op8852, ptr %slot1412, align 8
  %v8853 = load i64, ptr %slot1406, align 8
  %p8854 = inttoptr i64 %v8853 to ptr
  %rgep8855 = getelementptr i8, ptr %p8854, i64 -24
  %ld8856 = load i64, ptr %rgep8855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8856, ptr %slot1413, align 8
  %v8857 = load i64, ptr %slot1413, align 8
  %op8858 = sub i64 %v8857, 1
  store i64 %op8858, ptr %slot1414, align 8
  %v8859 = load i64, ptr %slot1414, align 8
  %cmp8860 = icmp eq i64 %v8859, 0
  %cv8861 = zext i1 %cmp8860 to i32
  store i32 %cv8861, ptr %slot1415, align 8
  %v8862 = load i32, ptr %slot1415, align 8
  %cv8863 = zext i32 %v8862 to i64
  %cond8864 = icmp ne i64 %cv8863, 0
  br i1 %cond8864, label %bb_rcglast1817, label %bb_rcgdec1817
bb_rcglast1817:
  %v8865 = load i64, ptr %slot1406, align 8
  %op8866 = sub i64 %v8865, 32
  store i64 %op8866, ptr %slot1416, align 8
  %v8867 = load i64, ptr %slot1406, align 8
  %p8868 = inttoptr i64 %v8867 to ptr
  %rgep8869 = getelementptr i8, ptr %p8868, i64 -32
  %ld8870 = load i64, ptr %rgep8869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8870, ptr %slot1417, align 8
  %v8871 = load i64, ptr %slot1417, align 8
  %cmp8872 = icmp ne i64 %v8871, 0
  %cv8873 = zext i1 %cmp8872 to i32
  store i32 %cv8873, ptr %slot1418, align 8
  %v8874 = load i32, ptr %slot1418, align 8
  %cv8875 = zext i32 %v8874 to i64
  %cond8876 = icmp ne i64 %cv8875, 0
  br i1 %cond8876, label %bb_rcgdec1817, label %bb_rcgslow1817
bb_rcgslow1817:
  %v8877 = load i64, ptr %slot1405, align 8
  %v8878 = load i64, ptr %slot1402, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v8877, i64 %v8878) nomerge, !dbg !200
  br label %bb_rcgdone1817
bb_rcgdec1817:
  %v8879 = load i64, ptr %slot1414, align 8
  %v8880 = load i64, ptr %slot1406, align 8
  %p8881 = inttoptr i64 %v8880 to ptr
  %rgep8882 = getelementptr i8, ptr %p8881, i64 -24
  store i64 %v8879, ptr %rgep8882, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1817
bb_rcgclear1817:
  %v8883 = load i64, ptr %slot1402, align 8
  %p8884 = inttoptr i64 %v8883 to ptr
  store i64 0, ptr %p8884, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1817
bb_rcgdone1817:
  br label %bb_rcslotdone1801
bb_rcslotowner1801:
  %v8885 = load i64, ptr %slot99, align 8
  store i64 %v8885, ptr %slot1419, align 8
  %v8886 = load i64, ptr %slot1402, align 8
  %p8887 = inttoptr i64 %v8886 to ptr
  %ld8888 = load i64, ptr %p8887, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8888, ptr %slot1420, align 8
  %v8889 = load i64, ptr %slot1420, align 8
  %cmp8890 = icmp ne i64 %v8889, 0
  %cv8891 = zext i1 %cmp8890 to i32
  store i32 %cv8891, ptr %slot1421, align 8
  %v8892 = load i32, ptr %slot1421, align 8
  %cv8893 = zext i32 %v8892 to i64
  %cond8894 = icmp ne i64 %cv8893, 0
  br i1 %cond8894, label %bb_rcgnn1832, label %bb_rcgdone1832
bb_rcgnn1832:
  %v8895 = load i64, ptr %slot1420, align 8
  %op8896 = sub i64 %v8895, 16
  store i64 %op8896, ptr %slot1422, align 8
  %v8897 = load i64, ptr %slot1420, align 8
  %p8898 = inttoptr i64 %v8897 to ptr
  %rgep8899 = getelementptr i8, ptr %p8898, i64 -16
  %ld8900 = load i64, ptr %rgep8899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8900, ptr %slot1423, align 8
  %v8901 = load i64, ptr %slot1423, align 8
  %op8902 = and i64 %v8901, 4611686018427387906
  store i64 %op8902, ptr %slot1424, align 8
  %v8903 = load i64, ptr %slot1424, align 8
  %cmp8904 = icmp ne i64 %v8903, 0
  %cv8905 = zext i1 %cmp8904 to i32
  store i32 %cv8905, ptr %slot1425, align 8
  %v8906 = load i32, ptr %slot1425, align 8
  %cv8907 = zext i32 %v8906 to i64
  %cond8908 = icmp ne i64 %cv8907, 0
  br i1 %cond8908, label %bb_rcgclear1832, label %bb_rcgcounted1832
bb_rcgcounted1832:
  %v8909 = load i64, ptr %slot1420, align 8
  %op8910 = sub i64 %v8909, 32
  store i64 %op8910, ptr %slot1426, align 8
  %v8911 = load i64, ptr %slot1420, align 8
  %p8912 = inttoptr i64 %v8911 to ptr
  %rgep8913 = getelementptr i8, ptr %p8912, i64 -32
  %ld8914 = load i64, ptr %rgep8913, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8914, ptr %slot1427, align 8
  %v8915 = load i64, ptr %slot1427, align 8
  %op8916 = sub i64 %v8915, 1
  store i64 %op8916, ptr %slot1428, align 8
  %v8917 = load i64, ptr %slot1428, align 8
  %cmp8918 = icmp eq i64 %v8917, 0
  %cv8919 = zext i1 %cmp8918 to i32
  store i32 %cv8919, ptr %slot1429, align 8
  %v8920 = load i32, ptr %slot1429, align 8
  %cv8921 = zext i32 %v8920 to i64
  %cond8922 = icmp ne i64 %cv8921, 0
  br i1 %cond8922, label %bb_rcglast1832, label %bb_rcgdec1832
bb_rcglast1832:
  %v8923 = load i64, ptr %slot1420, align 8
  %op8924 = sub i64 %v8923, 24
  store i64 %op8924, ptr %slot1430, align 8
  %v8925 = load i64, ptr %slot1420, align 8
  %p8926 = inttoptr i64 %v8925 to ptr
  %rgep8927 = getelementptr i8, ptr %p8926, i64 -24
  %ld8928 = load i64, ptr %rgep8927, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8928, ptr %slot1431, align 8
  %v8929 = load i64, ptr %slot1431, align 8
  %cmp8930 = icmp ne i64 %v8929, 0
  %cv8931 = zext i1 %cmp8930 to i32
  store i32 %cv8931, ptr %slot1432, align 8
  %v8932 = load i32, ptr %slot1432, align 8
  %cv8933 = zext i32 %v8932 to i64
  %cond8934 = icmp ne i64 %cv8933, 0
  br i1 %cond8934, label %bb_rcgdec1832, label %bb_rcgslow1832
bb_rcgslow1832:
  %v8935 = load i64, ptr %slot1419, align 8
  %v8936 = load i64, ptr %slot1402, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v8935, i64 %v8936) nomerge, !dbg !200
  br label %bb_rcgdone1832
bb_rcgdec1832:
  %v8937 = load i64, ptr %slot1428, align 8
  %v8938 = load i64, ptr %slot1420, align 8
  %p8939 = inttoptr i64 %v8938 to ptr
  %rgep8940 = getelementptr i8, ptr %p8939, i64 -32
  store i64 %v8937, ptr %rgep8940, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1832
bb_rcgclear1832:
  %v8941 = load i64, ptr %slot1402, align 8
  %p8942 = inttoptr i64 %v8941 to ptr
  store i64 0, ptr %p8942, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1832
bb_rcgdone1832:
  br label %bb_rcslotdone1801
bb_rcslotdone1801:
  %v8943 = load i64, ptr %slot24, align 8
  store i64 %v8943, ptr %slot1433, align 8
  %v8944 = load i64, ptr %slot30, align 8
  store i64 %v8944, ptr %slot1434, align 8
  %v8945 = load i64, ptr %slot1434, align 8
  %v8946 = load i64, ptr %slot1433, align 8
  %p8947 = inttoptr i64 %v8945 to ptr
  %p8948 = inttoptr i64 %v8946 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8948, ptr %p8947, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v8949 = load i64, ptr %slot16, align 8
  %p8950 = inttoptr i64 %v8949 to ptr
  store i32 2, ptr %p8950, align 4, !alias.scope !3, !noalias !4
  %v8951 = load i64, ptr %slot22, align 8
  %p8952 = inttoptr i64 %v8951 to ptr
  %ld8953 = load i32, ptr %p8952, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8953, ptr %slot1435, align 8
  %v8954 = load i32, ptr %slot1435, align 8
  %v8955 = load i64, ptr %slot16, align 8
  %p8956 = inttoptr i64 %v8955 to ptr
  store i32 %v8954, ptr %p8956, align 4, !alias.scope !3, !noalias !4
  %v8957 = load i64, ptr %slot21, align 8
  %p8958 = inttoptr i64 %v8957 to ptr
  store i32 0, ptr %p8958, align 4, !alias.scope !3, !noalias !4
  %v8959 = load i64, ptr %slot15, align 8
  %p8960 = inttoptr i64 %v8959 to ptr
  store i32 1, ptr %p8960, align 4, !alias.scope !3, !noalias !4
  %v8961 = load i64, ptr %slot1433, align 8
  %v8962 = load i64, ptr %slot44, align 8
  %p8963 = inttoptr i64 %v8962 to ptr
  store i64 %v8961, ptr %p8963, align 8, !alias.scope !3, !noalias !4
  %v8964 = load i64, ptr %slot44, align 8
  %p8965 = inttoptr i64 %v8964 to ptr
  %ld8966 = load i64, ptr %p8965, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8966, ptr %slot1436, align 8
  %v8967 = load i64, ptr %slot1436, align 8
  %p8968 = inttoptr i64 %v8967 to ptr
  %ld8969 = load i32, ptr %p8968, align 4
  %ext8970 = zext i32 %ld8969 to i64
  store i64 %ext8970, ptr %slot1437, align 8
  %v8971 = load i64, ptr %slot1437, align 8
  %cmp8972 = icmp eq i64 %v8971, 0
  %cv8973 = zext i1 %cmp8972 to i64
  store i64 %cv8973, ptr %slot1438, align 8
  %v8974 = load i64, ptr %slot1438, align 8
  %cond8975 = icmp ne i64 %v8974, 0
  br i1 %cond8975, label %bb_rctryok1845, label %bb_rctryerror1845
bb_rctryerror1845:
  %p8976 = inttoptr i64 ptrtoint (ptr @myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p8976, i64 12884902003) "call-inline-cost"="0", !dbg !202
  %v8977 = load i64, ptr %slot1436, align 8
  %op8978 = add i64 %v8977, 8
  store i64 %op8978, ptr %slot1439, align 8
  %v8979 = load i64, ptr %slot71, align 8
  store i64 %v8979, ptr %slot1440, align 8
  %v8980 = load i64, ptr %slot1440, align 8
  %p8981 = inttoptr i64 %v8980 to ptr
  store i64 0, ptr %p8981, align 8, !alias.scope !3, !noalias !4
  %v8982 = load i64, ptr %slot1440, align 8
  %p8984 = inttoptr i64 %v8982 to ptr
  %gep8985 = getelementptr i8, ptr %p8984, i64 8
  %op8983 = ptrtoint ptr %gep8985 to i64
  store i64 %op8983, ptr %slot1441, align 8
  %v8986 = load i64, ptr %slot1441, align 8
  %p8987 = inttoptr i64 %v8986 to ptr
  store i64 0, ptr %p8987, align 8, !alias.scope !3, !noalias !4
  %v8988 = load i64, ptr %slot1440, align 8
  %p8989 = inttoptr i64 %v8988 to ptr
  store i32 1, ptr %p8989, align 4, !alias.scope !3, !noalias !4
  %v8990 = load i64, ptr %slot1440, align 8
  %p8992 = inttoptr i64 %v8990 to ptr
  %gep8993 = getelementptr i8, ptr %p8992, i64 8
  %op8991 = ptrtoint ptr %gep8993 to i64
  store i64 %op8991, ptr %slot1442, align 8
  %v8994 = load i64, ptr %slot23, align 8
  %p8995 = inttoptr i64 %v8994 to ptr
  store i32 1, ptr %p8995, align 4, !alias.scope !3, !noalias !4
  %v8996 = load i64, ptr %slot100, align 8
  store i64 %v8996, ptr %slot1443, align 8
  %v8997 = load i64, ptr %slot1440, align 8
  %v8998 = load i64, ptr %slot44, align 8
  %p8999 = inttoptr i64 %v8998 to ptr
  store i64 %v8997, ptr %p8999, align 8, !alias.scope !3, !noalias !4
  %v9000 = load i64, ptr %slot15, align 8
  %p9001 = inttoptr i64 %v9000 to ptr
  %ld9002 = load i32, ptr %p9001, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9002, ptr %slot1444, align 8
  %v9003 = load i32, ptr %slot1444, align 8
  %cv9004 = zext i32 %v9003 to i64
  %cond9005 = icmp ne i64 %cv9004, 0
  br i1 %cond9005, label %bb_rcslotdrop1856, label %bb_rcslotdone1856
bb_rcslotdrop1856:
  %v9006 = load i64, ptr %slot15, align 8
  %p9007 = inttoptr i64 %v9006 to ptr
  store i32 0, ptr %p9007, align 4, !alias.scope !3, !noalias !4
  %v9008 = load i64, ptr %slot24, align 8
  store i64 %v9008, ptr %slot1445, align 8
  %v9009 = load i64, ptr %slot16, align 8
  %p9010 = inttoptr i64 %v9009 to ptr
  %ld9011 = load i32, ptr %p9010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9011, ptr %slot1446, align 8
  %v9012 = load i32, ptr %slot1446, align 8
  %op9013 = and i32 %v9012, 28
  store i32 %op9013, ptr %slot1447, align 8
  %v9014 = load i32, ptr %slot1447, align 8
  %cv9015 = zext i32 %v9014 to i64
  %cond9016 = icmp ne i64 %cv9015, 0
  br i1 %cond9016, label %bb_rcslotrole1856, label %bb_rcslotowner1856
bb_rcslotrole1856:
  %v9017 = load i64, ptr %slot99, align 8
  store i64 %v9017, ptr %slot1448, align 8
  %v9018 = load i64, ptr %slot1448, align 8
  %v9019 = load i64, ptr %slot1445, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v9018, i64 %v9019) nomerge, !dbg !202
  br label %bb_rcslotdone1856
bb_rcslotowner1856:
  %v9020 = load i64, ptr %slot99, align 8
  store i64 %v9020, ptr %slot1449, align 8
  %v9021 = load i64, ptr %slot1449, align 8
  %v9022 = load i64, ptr %slot1445, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v9021, i64 %v9022) nomerge, !dbg !202
  br label %bb_rcslotdone1856
bb_rcslotdone1856:
  br label %bb_i117
bb_rctryok1845:
  %v9023 = load i64, ptr %slot71, align 8
  store i64 %v9023, ptr %slot1450, align 8
  %v9024 = load i64, ptr %slot1450, align 8
  %p9025 = inttoptr i64 %v9024 to ptr
  store i64 0, ptr %p9025, align 8, !alias.scope !3, !noalias !4
  %v9026 = load i64, ptr %slot1450, align 8
  %p9028 = inttoptr i64 %v9026 to ptr
  %gep9029 = getelementptr i8, ptr %p9028, i64 8
  %op9027 = ptrtoint ptr %gep9029 to i64
  store i64 %op9027, ptr %slot1451, align 8
  %v9030 = load i64, ptr %slot1451, align 8
  %p9031 = inttoptr i64 %v9030 to ptr
  store i64 0, ptr %p9031, align 8, !alias.scope !3, !noalias !4
  %v9032 = load i64, ptr %slot1450, align 8
  %p9034 = inttoptr i64 %v9032 to ptr
  %gep9035 = getelementptr i8, ptr %p9034, i64 16
  %op9033 = ptrtoint ptr %gep9035 to i64
  store i64 %op9033, ptr %slot1452, align 8
  %v9036 = load i64, ptr %slot1452, align 8
  %p9037 = inttoptr i64 %v9036 to ptr
  store i64 0, ptr %p9037, align 8, !alias.scope !3, !noalias !4
  %v9038 = load i64, ptr %slot1450, align 8
  %p9040 = inttoptr i64 %v9038 to ptr
  %gep9041 = getelementptr i8, ptr %p9040, i64 24
  %op9039 = ptrtoint ptr %gep9041 to i64
  store i64 %op9039, ptr %slot1453, align 8
  %v9042 = load i64, ptr %slot1453, align 8
  %p9043 = inttoptr i64 %v9042 to ptr
  store i64 0, ptr %p9043, align 8, !alias.scope !3, !noalias !4
  %v9044 = load i64, ptr %slot1450, align 8
  %p9046 = inttoptr i64 %v9044 to ptr
  %gep9047 = getelementptr i8, ptr %p9046, i64 32
  %op9045 = ptrtoint ptr %gep9047 to i64
  store i64 %op9045, ptr %slot1454, align 8
  %v9048 = load i64, ptr %slot1454, align 8
  %p9049 = inttoptr i64 %v9048 to ptr
  store i64 0, ptr %p9049, align 8, !alias.scope !3, !noalias !4
  %v9050 = load i64, ptr %slot23, align 8
  %p9051 = inttoptr i64 %v9050 to ptr
  store i32 1, ptr %p9051, align 4, !alias.scope !3, !noalias !4
  %v9052 = load i64, ptr %slot1436, align 8
  %op9053 = add i64 %v9052, 8
  store i64 %op9053, ptr %slot1455, align 8
  %v9054 = load i64, ptr %slot100, align 8
  store i64 %v9054, ptr %slot1456, align 8
  %v9055 = load i64, ptr %slot99, align 8
  %v9056 = load i64, ptr %slot1450, align 8
  %v9057 = load i64, ptr %slot1455, align 8
  %v9058 = load i64, ptr %slot1456, align 8
  %cv9059 = trunc i64 %v9058 to i32
  %call9060 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v9055, i64 %v9056, i64 %v9057, i32 %cv9059) nomerge, !dbg !202
  store i32 %call9060, ptr %slot1457, align 8
  %v9061 = load i32, ptr %slot1457, align 8
  %cv9062 = zext i32 %v9061 to i64
  %cond9063 = icmp ne i64 %cv9062, 0
  br i1 %cond9063, label %bb_rcsuccess1873, label %bb_rcfailure1873
bb_rcfailure1873:
  %v9064 = load i64, ptr %slot99, align 8
  %p9065 = inttoptr i64 %v9064 to ptr
  %call9066 = call i32 @myl_rc_take_failure(ptr %p9065) nomerge, !dbg !202
  store i32 %call9066, ptr %slot1458, align 8
  %v9067 = load i64, ptr %slot1, align 8
  %p9068 = inttoptr i64 %v9067 to ptr
  %v9069 = load i32, ptr %slot1458, align 8
  %call9070 = call i32 @myl_qbe_rc_status(ptr %p9068, i32 %v9069) nomerge, !dbg !202
  store i32 %call9070, ptr %slot1459, align 8
  br label %bb_failure
bb_rcsuccess1873:
  %v9071 = load i64, ptr %slot1450, align 8
  %v9072 = load i64, ptr %slot44, align 8
  %p9073 = inttoptr i64 %v9072 to ptr
  store i64 %v9071, ptr %p9073, align 8, !alias.scope !3, !noalias !4
  %v9074 = load i64, ptr %slot44, align 8
  %p9075 = inttoptr i64 %v9074 to ptr
  %ld9076 = load i64, ptr %p9075, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9076, ptr %slot1460, align 8
  %v9077 = load i64, ptr %slot30, align 8
  store i64 %v9077, ptr %slot1461, align 8
  %v9078 = load i64, ptr %slot1460, align 8
  %v9079 = load i64, ptr %slot1461, align 8
  %p9080 = inttoptr i64 %v9078 to ptr
  %p9081 = inttoptr i64 %v9079 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9081, ptr %p9080, i64 40, i1 false)
  %v9082 = load i64, ptr %slot22, align 8
  %p9083 = inttoptr i64 %v9082 to ptr
  store i32 2, ptr %p9083, align 4, !alias.scope !3, !noalias !4
  %v9084 = load i64, ptr %slot21, align 8
  %p9085 = inttoptr i64 %v9084 to ptr
  store i32 1, ptr %p9085, align 4, !alias.scope !3, !noalias !4
  %v9086 = load i64, ptr %slot15, align 8
  %p9087 = inttoptr i64 %v9086 to ptr
  %ld9088 = load i32, ptr %p9087, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9088, ptr %slot1462, align 8
  %v9089 = load i32, ptr %slot1462, align 8
  %cv9090 = zext i32 %v9089 to i64
  %cond9091 = icmp ne i64 %cv9090, 0
  br i1 %cond9091, label %bb_rcslotdrop1882, label %bb_rcslotdone1882
bb_rcslotdrop1882:
  %v9092 = load i64, ptr %slot15, align 8
  %p9093 = inttoptr i64 %v9092 to ptr
  store i32 0, ptr %p9093, align 4, !alias.scope !3, !noalias !4
  %v9094 = load i64, ptr %slot24, align 8
  store i64 %v9094, ptr %slot1463, align 8
  %v9095 = load i64, ptr %slot16, align 8
  %p9096 = inttoptr i64 %v9095 to ptr
  %ld9097 = load i32, ptr %p9096, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9097, ptr %slot1464, align 8
  %v9098 = load i32, ptr %slot1464, align 8
  %op9099 = and i32 %v9098, 28
  store i32 %op9099, ptr %slot1465, align 8
  %v9100 = load i32, ptr %slot1465, align 8
  %cv9101 = zext i32 %v9100 to i64
  %cond9102 = icmp ne i64 %cv9101, 0
  br i1 %cond9102, label %bb_rcslotrole1882, label %bb_rcslotowner1882
bb_rcslotrole1882:
  %v9103 = load i64, ptr %slot99, align 8
  store i64 %v9103, ptr %slot1466, align 8
  %v9104 = load i64, ptr %slot1466, align 8
  %v9105 = load i64, ptr %slot1463, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v9104, i64 %v9105) nomerge, !dbg !202
  br label %bb_rcslotdone1882
bb_rcslotowner1882:
  %v9106 = load i64, ptr %slot99, align 8
  store i64 %v9106, ptr %slot1467, align 8
  %v9107 = load i64, ptr %slot1467, align 8
  %v9108 = load i64, ptr %slot1463, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v9107, i64 %v9108) nomerge, !dbg !202
  br label %bb_rcslotdone1882
bb_rcslotdone1882:
  %v9109 = load i64, ptr %slot24, align 8
  store i64 %v9109, ptr %slot1468, align 8
  %v9110 = load i64, ptr %slot30, align 8
  store i64 %v9110, ptr %slot1469, align 8
  %v9111 = load i64, ptr %slot1469, align 8
  %v9112 = load i64, ptr %slot1468, align 8
  %p9113 = inttoptr i64 %v9111 to ptr
  %p9114 = inttoptr i64 %v9112 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9114, ptr %p9113, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v9115 = load i64, ptr %slot16, align 8
  %p9116 = inttoptr i64 %v9115 to ptr
  store i32 2, ptr %p9116, align 4, !alias.scope !3, !noalias !4
  %v9117 = load i64, ptr %slot22, align 8
  %p9118 = inttoptr i64 %v9117 to ptr
  %ld9119 = load i32, ptr %p9118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9119, ptr %slot1470, align 8
  %v9120 = load i32, ptr %slot1470, align 8
  %v9121 = load i64, ptr %slot16, align 8
  %p9122 = inttoptr i64 %v9121 to ptr
  store i32 %v9120, ptr %p9122, align 4, !alias.scope !3, !noalias !4
  %v9123 = load i64, ptr %slot21, align 8
  %p9124 = inttoptr i64 %v9123 to ptr
  store i32 0, ptr %p9124, align 4, !alias.scope !3, !noalias !4
  %v9125 = load i64, ptr %slot15, align 8
  %p9126 = inttoptr i64 %v9125 to ptr
  store i32 1, ptr %p9126, align 4, !alias.scope !3, !noalias !4
  %v9127 = load i64, ptr %slot1468, align 8
  %v9128 = load i64, ptr %slot44, align 8
  %p9129 = inttoptr i64 %v9128 to ptr
  store i64 %v9127, ptr %p9129, align 8, !alias.scope !3, !noalias !4
  br label %bb_i118
bb_i117:
  %v9130 = load i64, ptr %slot44, align 8
  %p9131 = inttoptr i64 %v9130 to ptr
  %ld9132 = load i64, ptr %p9131, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9132, ptr %slot1471, align 8
  %v9133 = load i64, ptr %slot15, align 8
  %p9134 = inttoptr i64 %v9133 to ptr
  %ld9135 = load i32, ptr %p9134, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9135, ptr %slot1472, align 8
  %v9136 = load i32, ptr %slot1472, align 8
  %cv9137 = zext i32 %v9136 to i64
  %cond9138 = icmp ne i64 %cv9137, 0
  br i1 %cond9138, label %bb_rcslotdrop1900, label %bb_rcslotdone1900
bb_rcslotdrop1900:
  %v9139 = load i64, ptr %slot15, align 8
  %p9140 = inttoptr i64 %v9139 to ptr
  store i32 0, ptr %p9140, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1900
bb_rcslotdone1900:
  %v9141 = load i64, ptr %slot13, align 8
  %p9142 = inttoptr i64 %v9141 to ptr
  %ld9143 = load i32, ptr %p9142, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9143, ptr %slot1473, align 8
  %v9144 = load i32, ptr %slot1473, align 8
  %cv9145 = zext i32 %v9144 to i64
  %cond9146 = icmp ne i64 %cv9145, 0
  br i1 %cond9146, label %bb_rcslotdrop1903, label %bb_rcslotdone1903
bb_rcslotdrop1903:
  %v9147 = load i64, ptr %slot13, align 8
  %p9148 = inttoptr i64 %v9147 to ptr
  store i32 0, ptr %p9148, align 4, !alias.scope !3, !noalias !4
  %v9149 = load i64, ptr %slot42, align 8
  store i64 %v9149, ptr %slot1474, align 8
  %v9150 = load i64, ptr %slot14, align 8
  %p9151 = inttoptr i64 %v9150 to ptr
  %ld9152 = load i32, ptr %p9151, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9152, ptr %slot1475, align 8
  %v9153 = load i32, ptr %slot1475, align 8
  %op9154 = and i32 %v9153, 28
  store i32 %op9154, ptr %slot1476, align 8
  %v9155 = load i32, ptr %slot1476, align 8
  %cv9156 = zext i32 %v9155 to i64
  %cond9157 = icmp ne i64 %cv9156, 0
  br i1 %cond9157, label %bb_rcslotrole1903, label %bb_rcslotowner1903
bb_rcslotrole1903:
  %v9158 = load i64, ptr %slot99, align 8
  store i64 %v9158, ptr %slot1477, align 8
  %v9159 = load i64, ptr %slot1477, align 8
  %v9160 = load i64, ptr %slot1474, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v9159, i64 %v9160) nomerge, !dbg !204
  br label %bb_rcslotdone1903
bb_rcslotowner1903:
  %v9161 = load i64, ptr %slot99, align 8
  store i64 %v9161, ptr %slot1478, align 8
  %v9162 = load i64, ptr %slot1478, align 8
  %v9163 = load i64, ptr %slot1474, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v9162, i64 %v9163) nomerge, !dbg !204
  br label %bb_rcslotdone1903
bb_rcslotdone1903:
  %v9164 = load i64, ptr %slot11, align 8
  %p9165 = inttoptr i64 %v9164 to ptr
  %ld9166 = load i32, ptr %p9165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9166, ptr %slot1479, align 8
  %v9167 = load i32, ptr %slot1479, align 8
  %cv9168 = zext i32 %v9167 to i64
  %cond9169 = icmp ne i64 %cv9168, 0
  br i1 %cond9169, label %bb_rcslotdrop1912, label %bb_rcslotdone1912
bb_rcslotdrop1912:
  %v9170 = load i64, ptr %slot11, align 8
  %p9171 = inttoptr i64 %v9170 to ptr
  store i32 0, ptr %p9171, align 4, !alias.scope !3, !noalias !4
  %v9172 = load i64, ptr %slot41, align 8
  store i64 %v9172, ptr %slot1480, align 8
  %v9173 = load i64, ptr %slot12, align 8
  %p9174 = inttoptr i64 %v9173 to ptr
  %ld9175 = load i32, ptr %p9174, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9175, ptr %slot1481, align 8
  %v9176 = load i32, ptr %slot1481, align 8
  %op9177 = and i32 %v9176, 28
  store i32 %op9177, ptr %slot1482, align 8
  %v9178 = load i32, ptr %slot1482, align 8
  %cv9179 = zext i32 %v9178 to i64
  %cond9180 = icmp ne i64 %cv9179, 0
  br i1 %cond9180, label %bb_rcslotrole1912, label %bb_rcslotowner1912
bb_rcslotrole1912:
  %v9181 = load i64, ptr %slot99, align 8
  store i64 %v9181, ptr %slot1483, align 8
  %v9182 = load i64, ptr %slot1483, align 8
  %v9183 = load i64, ptr %slot1480, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v9182, i64 %v9183) nomerge, !dbg !204
  br label %bb_rcslotdone1912
bb_rcslotowner1912:
  %v9184 = load i64, ptr %slot99, align 8
  store i64 %v9184, ptr %slot1484, align 8
  %v9185 = load i64, ptr %slot1484, align 8
  %v9186 = load i64, ptr %slot1480, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v9185, i64 %v9186) nomerge, !dbg !204
  br label %bb_rcslotdone1912
bb_rcslotdone1912:
  %v9187 = load i64, ptr %slot9, align 8
  %p9188 = inttoptr i64 %v9187 to ptr
  %ld9189 = load i32, ptr %p9188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9189, ptr %slot1485, align 8
  %v9190 = load i32, ptr %slot1485, align 8
  %cv9191 = zext i32 %v9190 to i64
  %cond9192 = icmp ne i64 %cv9191, 0
  br i1 %cond9192, label %bb_rcslotdrop1921, label %bb_rcslotdone1921
bb_rcslotdrop1921:
  %v9193 = load i64, ptr %slot9, align 8
  %p9194 = inttoptr i64 %v9193 to ptr
  store i32 0, ptr %p9194, align 4, !alias.scope !3, !noalias !4
  %v9195 = load i64, ptr %slot39, align 8
  store i64 %v9195, ptr %slot1486, align 8
  %v9196 = load i64, ptr %slot10, align 8
  %p9197 = inttoptr i64 %v9196 to ptr
  %ld9198 = load i32, ptr %p9197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9198, ptr %slot1487, align 8
  %v9199 = load i32, ptr %slot1487, align 8
  %op9200 = and i32 %v9199, 28
  store i32 %op9200, ptr %slot1488, align 8
  %v9201 = load i32, ptr %slot1488, align 8
  %cv9202 = zext i32 %v9201 to i64
  %cond9203 = icmp ne i64 %cv9202, 0
  br i1 %cond9203, label %bb_rcslotrole1921, label %bb_rcslotowner1921
bb_rcslotrole1921:
  %v9204 = load i64, ptr %slot99, align 8
  store i64 %v9204, ptr %slot1489, align 8
  %v9205 = load i64, ptr %slot1486, align 8
  %p9206 = inttoptr i64 %v9205 to ptr
  %ld9207 = load i64, ptr %p9206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9207, ptr %slot1490, align 8
  %v9208 = load i64, ptr %slot1490, align 8
  %cmp9209 = icmp ne i64 %v9208, 0
  %cv9210 = zext i1 %cmp9209 to i32
  store i32 %cv9210, ptr %slot1491, align 8
  %v9211 = load i32, ptr %slot1491, align 8
  %cv9212 = zext i32 %v9211 to i64
  %cond9213 = icmp ne i64 %cv9212, 0
  br i1 %cond9213, label %bb_rcgnn1937, label %bb_rcgdone1937
bb_rcgnn1937:
  %v9214 = load i64, ptr %slot1490, align 8
  %op9215 = sub i64 %v9214, 16
  store i64 %op9215, ptr %slot1492, align 8
  %v9216 = load i64, ptr %slot1490, align 8
  %p9217 = inttoptr i64 %v9216 to ptr
  %rgep9218 = getelementptr i8, ptr %p9217, i64 -16
  %ld9219 = load i64, ptr %rgep9218, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9219, ptr %slot1493, align 8
  %v9220 = load i64, ptr %slot1493, align 8
  %op9221 = and i64 %v9220, 4611686018427387906
  store i64 %op9221, ptr %slot1494, align 8
  %v9222 = load i64, ptr %slot1494, align 8
  %cmp9223 = icmp ne i64 %v9222, 0
  %cv9224 = zext i1 %cmp9223 to i32
  store i32 %cv9224, ptr %slot1495, align 8
  %v9225 = load i32, ptr %slot1495, align 8
  %cv9226 = zext i32 %v9225 to i64
  %cond9227 = icmp ne i64 %cv9226, 0
  br i1 %cond9227, label %bb_rcgclear1937, label %bb_rcgcounted1937
bb_rcgcounted1937:
  %v9228 = load i64, ptr %slot1490, align 8
  %op9229 = sub i64 %v9228, 24
  store i64 %op9229, ptr %slot1496, align 8
  %v9230 = load i64, ptr %slot1490, align 8
  %p9231 = inttoptr i64 %v9230 to ptr
  %rgep9232 = getelementptr i8, ptr %p9231, i64 -24
  %ld9233 = load i64, ptr %rgep9232, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9233, ptr %slot1497, align 8
  %v9234 = load i64, ptr %slot1497, align 8
  %op9235 = sub i64 %v9234, 1
  store i64 %op9235, ptr %slot1498, align 8
  %v9236 = load i64, ptr %slot1498, align 8
  %cmp9237 = icmp eq i64 %v9236, 0
  %cv9238 = zext i1 %cmp9237 to i32
  store i32 %cv9238, ptr %slot1499, align 8
  %v9239 = load i32, ptr %slot1499, align 8
  %cv9240 = zext i32 %v9239 to i64
  %cond9241 = icmp ne i64 %cv9240, 0
  br i1 %cond9241, label %bb_rcglast1937, label %bb_rcgdec1937
bb_rcglast1937:
  %v9242 = load i64, ptr %slot1490, align 8
  %op9243 = sub i64 %v9242, 32
  store i64 %op9243, ptr %slot1500, align 8
  %v9244 = load i64, ptr %slot1490, align 8
  %p9245 = inttoptr i64 %v9244 to ptr
  %rgep9246 = getelementptr i8, ptr %p9245, i64 -32
  %ld9247 = load i64, ptr %rgep9246, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9247, ptr %slot1501, align 8
  %v9248 = load i64, ptr %slot1501, align 8
  %cmp9249 = icmp ne i64 %v9248, 0
  %cv9250 = zext i1 %cmp9249 to i32
  store i32 %cv9250, ptr %slot1502, align 8
  %v9251 = load i32, ptr %slot1502, align 8
  %cv9252 = zext i32 %v9251 to i64
  %cond9253 = icmp ne i64 %cv9252, 0
  br i1 %cond9253, label %bb_rcgdec1937, label %bb_rcgslow1937
bb_rcgslow1937:
  %v9254 = load i64, ptr %slot1489, align 8
  %v9255 = load i64, ptr %slot1486, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v9254, i64 %v9255) nomerge, !dbg !204
  br label %bb_rcgdone1937
bb_rcgdec1937:
  %v9256 = load i64, ptr %slot1498, align 8
  %v9257 = load i64, ptr %slot1490, align 8
  %p9258 = inttoptr i64 %v9257 to ptr
  %rgep9259 = getelementptr i8, ptr %p9258, i64 -24
  store i64 %v9256, ptr %rgep9259, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1937
bb_rcgclear1937:
  %v9260 = load i64, ptr %slot1486, align 8
  %p9261 = inttoptr i64 %v9260 to ptr
  store i64 0, ptr %p9261, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1937
bb_rcgdone1937:
  br label %bb_rcslotdone1921
bb_rcslotowner1921:
  %v9262 = load i64, ptr %slot99, align 8
  store i64 %v9262, ptr %slot1503, align 8
  %v9263 = load i64, ptr %slot1486, align 8
  %p9264 = inttoptr i64 %v9263 to ptr
  %ld9265 = load i64, ptr %p9264, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9265, ptr %slot1504, align 8
  %v9266 = load i64, ptr %slot1504, align 8
  %cmp9267 = icmp ne i64 %v9266, 0
  %cv9268 = zext i1 %cmp9267 to i32
  store i32 %cv9268, ptr %slot1505, align 8
  %v9269 = load i32, ptr %slot1505, align 8
  %cv9270 = zext i32 %v9269 to i64
  %cond9271 = icmp ne i64 %cv9270, 0
  br i1 %cond9271, label %bb_rcgnn1952, label %bb_rcgdone1952
bb_rcgnn1952:
  %v9272 = load i64, ptr %slot1504, align 8
  %op9273 = sub i64 %v9272, 16
  store i64 %op9273, ptr %slot1506, align 8
  %v9274 = load i64, ptr %slot1504, align 8
  %p9275 = inttoptr i64 %v9274 to ptr
  %rgep9276 = getelementptr i8, ptr %p9275, i64 -16
  %ld9277 = load i64, ptr %rgep9276, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9277, ptr %slot1507, align 8
  %v9278 = load i64, ptr %slot1507, align 8
  %op9279 = and i64 %v9278, 4611686018427387906
  store i64 %op9279, ptr %slot1508, align 8
  %v9280 = load i64, ptr %slot1508, align 8
  %cmp9281 = icmp ne i64 %v9280, 0
  %cv9282 = zext i1 %cmp9281 to i32
  store i32 %cv9282, ptr %slot1509, align 8
  %v9283 = load i32, ptr %slot1509, align 8
  %cv9284 = zext i32 %v9283 to i64
  %cond9285 = icmp ne i64 %cv9284, 0
  br i1 %cond9285, label %bb_rcgclear1952, label %bb_rcgcounted1952
bb_rcgcounted1952:
  %v9286 = load i64, ptr %slot1504, align 8
  %op9287 = sub i64 %v9286, 32
  store i64 %op9287, ptr %slot1510, align 8
  %v9288 = load i64, ptr %slot1504, align 8
  %p9289 = inttoptr i64 %v9288 to ptr
  %rgep9290 = getelementptr i8, ptr %p9289, i64 -32
  %ld9291 = load i64, ptr %rgep9290, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9291, ptr %slot1511, align 8
  %v9292 = load i64, ptr %slot1511, align 8
  %op9293 = sub i64 %v9292, 1
  store i64 %op9293, ptr %slot1512, align 8
  %v9294 = load i64, ptr %slot1512, align 8
  %cmp9295 = icmp eq i64 %v9294, 0
  %cv9296 = zext i1 %cmp9295 to i32
  store i32 %cv9296, ptr %slot1513, align 8
  %v9297 = load i32, ptr %slot1513, align 8
  %cv9298 = zext i32 %v9297 to i64
  %cond9299 = icmp ne i64 %cv9298, 0
  br i1 %cond9299, label %bb_rcglast1952, label %bb_rcgdec1952
bb_rcglast1952:
  %v9300 = load i64, ptr %slot1504, align 8
  %op9301 = sub i64 %v9300, 24
  store i64 %op9301, ptr %slot1514, align 8
  %v9302 = load i64, ptr %slot1504, align 8
  %p9303 = inttoptr i64 %v9302 to ptr
  %rgep9304 = getelementptr i8, ptr %p9303, i64 -24
  %ld9305 = load i64, ptr %rgep9304, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9305, ptr %slot1515, align 8
  %v9306 = load i64, ptr %slot1515, align 8
  %cmp9307 = icmp ne i64 %v9306, 0
  %cv9308 = zext i1 %cmp9307 to i32
  store i32 %cv9308, ptr %slot1516, align 8
  %v9309 = load i32, ptr %slot1516, align 8
  %cv9310 = zext i32 %v9309 to i64
  %cond9311 = icmp ne i64 %cv9310, 0
  br i1 %cond9311, label %bb_rcgdec1952, label %bb_rcgslow1952
bb_rcgslow1952:
  %v9312 = load i64, ptr %slot1503, align 8
  %v9313 = load i64, ptr %slot1486, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v9312, i64 %v9313) nomerge, !dbg !204
  br label %bb_rcgdone1952
bb_rcgdec1952:
  %v9314 = load i64, ptr %slot1512, align 8
  %v9315 = load i64, ptr %slot1504, align 8
  %p9316 = inttoptr i64 %v9315 to ptr
  %rgep9317 = getelementptr i8, ptr %p9316, i64 -32
  store i64 %v9314, ptr %rgep9317, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1952
bb_rcgclear1952:
  %v9318 = load i64, ptr %slot1486, align 8
  %p9319 = inttoptr i64 %v9318 to ptr
  store i64 0, ptr %p9319, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1952
bb_rcgdone1952:
  br label %bb_rcslotdone1921
bb_rcslotdone1921:
  %v9320 = load i64, ptr %slot7, align 8
  %p9321 = inttoptr i64 %v9320 to ptr
  %ld9322 = load i32, ptr %p9321, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9322, ptr %slot1517, align 8
  %v9323 = load i32, ptr %slot1517, align 8
  %cv9324 = zext i32 %v9323 to i64
  %cond9325 = icmp ne i64 %cv9324, 0
  br i1 %cond9325, label %bb_rcslotdrop1958, label %bb_rcslotdone1958
bb_rcslotdrop1958:
  %v9326 = load i64, ptr %slot7, align 8
  %p9327 = inttoptr i64 %v9326 to ptr
  store i32 0, ptr %p9327, align 4, !alias.scope !3, !noalias !4
  %v9328 = load i64, ptr %slot34, align 8
  store i64 %v9328, ptr %slot1518, align 8
  %v9329 = load i64, ptr %slot8, align 8
  %p9330 = inttoptr i64 %v9329 to ptr
  %ld9331 = load i32, ptr %p9330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9331, ptr %slot1519, align 8
  %v9332 = load i32, ptr %slot1519, align 8
  %op9333 = and i32 %v9332, 28
  store i32 %op9333, ptr %slot1520, align 8
  %v9334 = load i32, ptr %slot1520, align 8
  %cv9335 = zext i32 %v9334 to i64
  %cond9336 = icmp ne i64 %cv9335, 0
  br i1 %cond9336, label %bb_rcslotrole1958, label %bb_rcslotowner1958
bb_rcslotrole1958:
  %v9337 = load i64, ptr %slot99, align 8
  store i64 %v9337, ptr %slot1521, align 8
  %v9338 = load i64, ptr %slot1518, align 8
  %p9339 = inttoptr i64 %v9338 to ptr
  %ld9340 = load i64, ptr %p9339, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9340, ptr %slot1522, align 8
  %v9341 = load i64, ptr %slot1522, align 8
  %cmp9342 = icmp ne i64 %v9341, 0
  %cv9343 = zext i1 %cmp9342 to i32
  store i32 %cv9343, ptr %slot1523, align 8
  %v9344 = load i32, ptr %slot1523, align 8
  %cv9345 = zext i32 %v9344 to i64
  %cond9346 = icmp ne i64 %cv9345, 0
  br i1 %cond9346, label %bb_rcgnn1974, label %bb_rcgdone1974
bb_rcgnn1974:
  %v9347 = load i64, ptr %slot1522, align 8
  %op9348 = sub i64 %v9347, 16
  store i64 %op9348, ptr %slot1524, align 8
  %v9349 = load i64, ptr %slot1522, align 8
  %p9350 = inttoptr i64 %v9349 to ptr
  %rgep9351 = getelementptr i8, ptr %p9350, i64 -16
  %ld9352 = load i64, ptr %rgep9351, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9352, ptr %slot1525, align 8
  %v9353 = load i64, ptr %slot1525, align 8
  %op9354 = and i64 %v9353, 4611686018427387906
  store i64 %op9354, ptr %slot1526, align 8
  %v9355 = load i64, ptr %slot1526, align 8
  %cmp9356 = icmp ne i64 %v9355, 0
  %cv9357 = zext i1 %cmp9356 to i32
  store i32 %cv9357, ptr %slot1527, align 8
  %v9358 = load i32, ptr %slot1527, align 8
  %cv9359 = zext i32 %v9358 to i64
  %cond9360 = icmp ne i64 %cv9359, 0
  br i1 %cond9360, label %bb_rcgclear1974, label %bb_rcgcounted1974
bb_rcgcounted1974:
  %v9361 = load i64, ptr %slot1522, align 8
  %op9362 = sub i64 %v9361, 24
  store i64 %op9362, ptr %slot1528, align 8
  %v9363 = load i64, ptr %slot1522, align 8
  %p9364 = inttoptr i64 %v9363 to ptr
  %rgep9365 = getelementptr i8, ptr %p9364, i64 -24
  %ld9366 = load i64, ptr %rgep9365, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9366, ptr %slot1529, align 8
  %v9367 = load i64, ptr %slot1529, align 8
  %op9368 = sub i64 %v9367, 1
  store i64 %op9368, ptr %slot1530, align 8
  %v9369 = load i64, ptr %slot1530, align 8
  %cmp9370 = icmp eq i64 %v9369, 0
  %cv9371 = zext i1 %cmp9370 to i32
  store i32 %cv9371, ptr %slot1531, align 8
  %v9372 = load i32, ptr %slot1531, align 8
  %cv9373 = zext i32 %v9372 to i64
  %cond9374 = icmp ne i64 %cv9373, 0
  br i1 %cond9374, label %bb_rcglast1974, label %bb_rcgdec1974
bb_rcglast1974:
  %v9375 = load i64, ptr %slot1522, align 8
  %op9376 = sub i64 %v9375, 32
  store i64 %op9376, ptr %slot1532, align 8
  %v9377 = load i64, ptr %slot1522, align 8
  %p9378 = inttoptr i64 %v9377 to ptr
  %rgep9379 = getelementptr i8, ptr %p9378, i64 -32
  %ld9380 = load i64, ptr %rgep9379, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9380, ptr %slot1533, align 8
  %v9381 = load i64, ptr %slot1533, align 8
  %cmp9382 = icmp ne i64 %v9381, 0
  %cv9383 = zext i1 %cmp9382 to i32
  store i32 %cv9383, ptr %slot1534, align 8
  %v9384 = load i32, ptr %slot1534, align 8
  %cv9385 = zext i32 %v9384 to i64
  %cond9386 = icmp ne i64 %cv9385, 0
  br i1 %cond9386, label %bb_rcgdec1974, label %bb_rcgslow1974
bb_rcgslow1974:
  %v9387 = load i64, ptr %slot1521, align 8
  %v9388 = load i64, ptr %slot1518, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v9387, i64 %v9388) nomerge, !dbg !204
  br label %bb_rcgdone1974
bb_rcgdec1974:
  %v9389 = load i64, ptr %slot1530, align 8
  %v9390 = load i64, ptr %slot1522, align 8
  %p9391 = inttoptr i64 %v9390 to ptr
  %rgep9392 = getelementptr i8, ptr %p9391, i64 -24
  store i64 %v9389, ptr %rgep9392, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1974
bb_rcgclear1974:
  %v9393 = load i64, ptr %slot1518, align 8
  %p9394 = inttoptr i64 %v9393 to ptr
  store i64 0, ptr %p9394, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1974
bb_rcgdone1974:
  br label %bb_rcslotdone1958
bb_rcslotowner1958:
  %v9395 = load i64, ptr %slot99, align 8
  store i64 %v9395, ptr %slot1535, align 8
  %v9396 = load i64, ptr %slot1518, align 8
  %p9397 = inttoptr i64 %v9396 to ptr
  %ld9398 = load i64, ptr %p9397, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9398, ptr %slot1536, align 8
  %v9399 = load i64, ptr %slot1536, align 8
  %cmp9400 = icmp ne i64 %v9399, 0
  %cv9401 = zext i1 %cmp9400 to i32
  store i32 %cv9401, ptr %slot1537, align 8
  %v9402 = load i32, ptr %slot1537, align 8
  %cv9403 = zext i32 %v9402 to i64
  %cond9404 = icmp ne i64 %cv9403, 0
  br i1 %cond9404, label %bb_rcgnn1989, label %bb_rcgdone1989
bb_rcgnn1989:
  %v9405 = load i64, ptr %slot1536, align 8
  %op9406 = sub i64 %v9405, 16
  store i64 %op9406, ptr %slot1538, align 8
  %v9407 = load i64, ptr %slot1536, align 8
  %p9408 = inttoptr i64 %v9407 to ptr
  %rgep9409 = getelementptr i8, ptr %p9408, i64 -16
  %ld9410 = load i64, ptr %rgep9409, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9410, ptr %slot1539, align 8
  %v9411 = load i64, ptr %slot1539, align 8
  %op9412 = and i64 %v9411, 4611686018427387906
  store i64 %op9412, ptr %slot1540, align 8
  %v9413 = load i64, ptr %slot1540, align 8
  %cmp9414 = icmp ne i64 %v9413, 0
  %cv9415 = zext i1 %cmp9414 to i32
  store i32 %cv9415, ptr %slot1541, align 8
  %v9416 = load i32, ptr %slot1541, align 8
  %cv9417 = zext i32 %v9416 to i64
  %cond9418 = icmp ne i64 %cv9417, 0
  br i1 %cond9418, label %bb_rcgclear1989, label %bb_rcgcounted1989
bb_rcgcounted1989:
  %v9419 = load i64, ptr %slot1536, align 8
  %op9420 = sub i64 %v9419, 32
  store i64 %op9420, ptr %slot1542, align 8
  %v9421 = load i64, ptr %slot1536, align 8
  %p9422 = inttoptr i64 %v9421 to ptr
  %rgep9423 = getelementptr i8, ptr %p9422, i64 -32
  %ld9424 = load i64, ptr %rgep9423, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9424, ptr %slot1543, align 8
  %v9425 = load i64, ptr %slot1543, align 8
  %op9426 = sub i64 %v9425, 1
  store i64 %op9426, ptr %slot1544, align 8
  %v9427 = load i64, ptr %slot1544, align 8
  %cmp9428 = icmp eq i64 %v9427, 0
  %cv9429 = zext i1 %cmp9428 to i32
  store i32 %cv9429, ptr %slot1545, align 8
  %v9430 = load i32, ptr %slot1545, align 8
  %cv9431 = zext i32 %v9430 to i64
  %cond9432 = icmp ne i64 %cv9431, 0
  br i1 %cond9432, label %bb_rcglast1989, label %bb_rcgdec1989
bb_rcglast1989:
  %v9433 = load i64, ptr %slot1536, align 8
  %op9434 = sub i64 %v9433, 24
  store i64 %op9434, ptr %slot1546, align 8
  %v9435 = load i64, ptr %slot1536, align 8
  %p9436 = inttoptr i64 %v9435 to ptr
  %rgep9437 = getelementptr i8, ptr %p9436, i64 -24
  %ld9438 = load i64, ptr %rgep9437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9438, ptr %slot1547, align 8
  %v9439 = load i64, ptr %slot1547, align 8
  %cmp9440 = icmp ne i64 %v9439, 0
  %cv9441 = zext i1 %cmp9440 to i32
  store i32 %cv9441, ptr %slot1548, align 8
  %v9442 = load i32, ptr %slot1548, align 8
  %cv9443 = zext i32 %v9442 to i64
  %cond9444 = icmp ne i64 %cv9443, 0
  br i1 %cond9444, label %bb_rcgdec1989, label %bb_rcgslow1989
bb_rcgslow1989:
  %v9445 = load i64, ptr %slot1535, align 8
  %v9446 = load i64, ptr %slot1518, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v9445, i64 %v9446) nomerge, !dbg !204
  br label %bb_rcgdone1989
bb_rcgdec1989:
  %v9447 = load i64, ptr %slot1544, align 8
  %v9448 = load i64, ptr %slot1536, align 8
  %p9449 = inttoptr i64 %v9448 to ptr
  %rgep9450 = getelementptr i8, ptr %p9449, i64 -32
  store i64 %v9447, ptr %rgep9450, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1989
bb_rcgclear1989:
  %v9451 = load i64, ptr %slot1518, align 8
  %p9452 = inttoptr i64 %v9451 to ptr
  store i64 0, ptr %p9452, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1989
bb_rcgdone1989:
  br label %bb_rcslotdone1958
bb_rcslotdone1958:
  %v9453 = load i64, ptr %slot5, align 8
  %p9454 = inttoptr i64 %v9453 to ptr
  %ld9455 = load i32, ptr %p9454, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9455, ptr %slot1549, align 8
  %v9456 = load i32, ptr %slot1549, align 8
  %cv9457 = zext i32 %v9456 to i64
  %cond9458 = icmp ne i64 %cv9457, 0
  br i1 %cond9458, label %bb_rcslotdrop1995, label %bb_rcslotdone1995
bb_rcslotdrop1995:
  %v9459 = load i64, ptr %slot5, align 8
  %p9460 = inttoptr i64 %v9459 to ptr
  store i32 0, ptr %p9460, align 4, !alias.scope !3, !noalias !4
  %v9461 = load i64, ptr %slot33, align 8
  store i64 %v9461, ptr %slot1550, align 8
  %v9462 = load i64, ptr %slot6, align 8
  %p9463 = inttoptr i64 %v9462 to ptr
  %ld9464 = load i32, ptr %p9463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9464, ptr %slot1551, align 8
  %v9465 = load i32, ptr %slot1551, align 8
  %op9466 = and i32 %v9465, 28
  store i32 %op9466, ptr %slot1552, align 8
  %v9467 = load i32, ptr %slot1552, align 8
  %cv9468 = zext i32 %v9467 to i64
  %cond9469 = icmp ne i64 %cv9468, 0
  br i1 %cond9469, label %bb_rcslotrole1995, label %bb_rcslotowner1995
bb_rcslotrole1995:
  %v9470 = load i64, ptr %slot99, align 8
  store i64 %v9470, ptr %slot1553, align 8
  %v9471 = load i64, ptr %slot1553, align 8
  %v9472 = load i64, ptr %slot1550, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v9471, i64 %v9472) nomerge, !dbg !204
  br label %bb_rcslotdone1995
bb_rcslotowner1995:
  %v9473 = load i64, ptr %slot99, align 8
  store i64 %v9473, ptr %slot1554, align 8
  %v9474 = load i64, ptr %slot1554, align 8
  %v9475 = load i64, ptr %slot1550, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v9474, i64 %v9475) nomerge, !dbg !204
  br label %bb_rcslotdone1995
bb_rcslotdone1995:
  %v9476 = load i64, ptr %slot1471, align 8
  %p9477 = inttoptr i64 %v9476 to ptr
  %ret9478 = load { i64, i64 }, ptr %p9477, align 8
  ret { i64, i64 } %ret9478
bb_i118:
  %v9479 = load i64, ptr %slot15, align 8
  %p9480 = inttoptr i64 %v9479 to ptr
  %ld9481 = load i32, ptr %p9480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9481, ptr %slot1555, align 8
  %v9482 = load i32, ptr %slot1555, align 8
  %cv9483 = zext i32 %v9482 to i64
  %cond9484 = icmp ne i64 %cv9483, 0
  br i1 %cond9484, label %bb_rcslotdrop2013, label %bb_rcslotdone2013
bb_rcslotdrop2013:
  %v9485 = load i64, ptr %slot15, align 8
  %p9486 = inttoptr i64 %v9485 to ptr
  store i32 0, ptr %p9486, align 4, !alias.scope !3, !noalias !4
  %v9487 = load i64, ptr %slot24, align 8
  store i64 %v9487, ptr %slot1556, align 8
  %v9488 = load i64, ptr %slot16, align 8
  %p9489 = inttoptr i64 %v9488 to ptr
  %ld9490 = load i32, ptr %p9489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9490, ptr %slot1557, align 8
  %v9491 = load i32, ptr %slot1557, align 8
  %op9492 = and i32 %v9491, 28
  store i32 %op9492, ptr %slot1558, align 8
  %v9493 = load i32, ptr %slot1558, align 8
  %cv9494 = zext i32 %v9493 to i64
  %cond9495 = icmp ne i64 %cv9494, 0
  br i1 %cond9495, label %bb_rcslotrole2013, label %bb_rcslotowner2013
bb_rcslotrole2013:
  %v9496 = load i64, ptr %slot99, align 8
  store i64 %v9496, ptr %slot1559, align 8
  %v9497 = load i64, ptr %slot1559, align 8
  %v9498 = load i64, ptr %slot1556, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v9497, i64 %v9498) nomerge, !dbg !206
  br label %bb_rcslotdone2013
bb_rcslotowner2013:
  %v9499 = load i64, ptr %slot99, align 8
  store i64 %v9499, ptr %slot1560, align 8
  %v9500 = load i64, ptr %slot1560, align 8
  %v9501 = load i64, ptr %slot1556, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v9500, i64 %v9501) nomerge, !dbg !206
  br label %bb_rcslotdone2013
bb_rcslotdone2013:
  %v9502 = load i64, ptr %slot32, align 8
  %p9503 = inttoptr i64 %v9502 to ptr
  %ld9504 = load i64, ptr %p9503, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9504, ptr %slot1561, align 8
  %v9505 = load i64, ptr %slot1561, align 8
  %v9506 = load i64, ptr %slot44, align 8
  %p9507 = inttoptr i64 %v9506 to ptr
  store i64 %v9505, ptr %p9507, align 8, !alias.scope !3, !noalias !4
  %v9508 = load i64, ptr %slot72, align 8
  store i64 %v9508, ptr %slot1562, align 8
  %v9509 = load i64, ptr %slot1562, align 8
  %p9510 = inttoptr i64 %v9509 to ptr
  store i32 0, ptr %p9510, align 4, !alias.scope !3, !noalias !4
  %v9511 = load i64, ptr %slot1562, align 8
  %p9512 = inttoptr i64 %v9511 to ptr
  store i32 19, ptr %p9512, align 4, !alias.scope !3, !noalias !4
  %v9513 = load i64, ptr %slot1562, align 8
  %v9514 = load i64, ptr %slot45, align 8
  %p9515 = inttoptr i64 %v9514 to ptr
  store i64 %v9513, ptr %p9515, align 8, !alias.scope !3, !noalias !4
  %p9516 = inttoptr i64 ptrtoint (ptr @myl_lit_9c78dec40d01c6c2bedb89cda9ba9fa8c40c54e0b599c5f8b355df196d3b6314 to i64) to ptr
  %ld9517 = load i64, ptr %p9516, align 8, !alias.scope !4, !noalias !3
  store i64 %ld9517, ptr %slot1563, align 8
  %v9518 = load i64, ptr %slot1563, align 8
  %v9519 = load i64, ptr %slot46, align 8
  %p9520 = inttoptr i64 %v9519 to ptr
  store i64 %v9518, ptr %p9520, align 8, !alias.scope !3, !noalias !4
  %v9521 = load i64, ptr %slot46, align 8
  %p9522 = inttoptr i64 %v9521 to ptr
  %ld9523 = load i64, ptr %p9522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9523, ptr %slot1564, align 8
  %v9524 = load i64, ptr %slot1564, align 8
  %v9525 = load i64, ptr %slot29, align 8
  %p9526 = inttoptr i64 %v9525 to ptr
  store i64 %v9524, ptr %p9526, align 8, !alias.scope !3, !noalias !4
  %v9527 = load i64, ptr %slot29, align 8
  store i64 %v9527, ptr %slot1565, align 8
  %v9528 = load i64, ptr %slot30, align 8
  store i64 %v9528, ptr %slot1566, align 8
  %v9529 = load i64, ptr %slot1565, align 8
  %v9530 = load i64, ptr %slot1566, align 8
  %p9531 = inttoptr i64 %v9529 to ptr
  %p9532 = inttoptr i64 %v9530 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9532, ptr %p9531, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9533 = load i64, ptr %slot22, align 8
  %p9534 = inttoptr i64 %v9533 to ptr
  store i32 2, ptr %p9534, align 4, !alias.scope !3, !noalias !4
  %v9535 = load i64, ptr %slot21, align 8
  %p9536 = inttoptr i64 %v9535 to ptr
  store i32 1, ptr %p9536, align 4, !alias.scope !3, !noalias !4
  %v9537 = load i64, ptr %slot26, align 8
  store i64 %v9537, ptr %slot1567, align 8
  %v9538 = load i64, ptr %slot30, align 8
  store i64 %v9538, ptr %slot1568, align 8
  %v9539 = load i64, ptr %slot1568, align 8
  %v9540 = load i64, ptr %slot1567, align 8
  %p9541 = inttoptr i64 %v9539 to ptr
  %p9542 = inttoptr i64 %v9540 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9542, ptr %p9541, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9543 = load i64, ptr %slot20, align 8
  %p9544 = inttoptr i64 %v9543 to ptr
  store i32 2, ptr %p9544, align 4, !alias.scope !3, !noalias !4
  %v9545 = load i64, ptr %slot22, align 8
  %p9546 = inttoptr i64 %v9545 to ptr
  %ld9547 = load i32, ptr %p9546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9547, ptr %slot1569, align 8
  %v9548 = load i32, ptr %slot1569, align 8
  %v9549 = load i64, ptr %slot20, align 8
  %p9550 = inttoptr i64 %v9549 to ptr
  store i32 %v9548, ptr %p9550, align 4, !alias.scope !3, !noalias !4
  %v9551 = load i64, ptr %slot21, align 8
  %p9552 = inttoptr i64 %v9551 to ptr
  store i32 0, ptr %p9552, align 4, !alias.scope !3, !noalias !4
  %v9553 = load i64, ptr %slot19, align 8
  %p9554 = inttoptr i64 %v9553 to ptr
  store i32 1, ptr %p9554, align 4, !alias.scope !3, !noalias !4
  %v9555 = load i64, ptr %slot1567, align 8
  %p9556 = inttoptr i64 %v9555 to ptr
  %ld9557 = load i64, ptr %p9556, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9557, ptr %slot1570, align 8
  %v9558 = load i64, ptr %slot1570, align 8
  %v9559 = load i64, ptr %slot46, align 8
  %p9560 = inttoptr i64 %v9559 to ptr
  store i64 %v9558, ptr %p9560, align 8, !alias.scope !3, !noalias !4
  %v9561 = load i64, ptr %slot44, align 8
  %p9562 = inttoptr i64 %v9561 to ptr
  %ld9563 = load i64, ptr %p9562, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9563, ptr %slot1571, align 8
  %v9564 = load i64, ptr %slot45, align 8
  %p9565 = inttoptr i64 %v9564 to ptr
  %ld9566 = load i64, ptr %p9565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9566, ptr %slot1572, align 8
  %v9567 = load i64, ptr %slot46, align 8
  %p9568 = inttoptr i64 %v9567 to ptr
  %ld9569 = load i64, ptr %p9568, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9569, ptr %slot1573, align 8
  %v9570 = load i64, ptr %slot1, align 8
  %v9571 = load i64, ptr %slot1571, align 8
  %v9572 = load i64, ptr %slot1572, align 8
  %v9573 = load i64, ptr %slot1573, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult1575, i64 %v9570, i64 %v9571, i64 %v9572, i64 %v9573) nomerge, !dbg !208
  %addr9574 = ptrtoint ptr %callresult1575 to i64
  store i64 %addr9574, ptr %slot1574, align 8
  %v9575 = load i64, ptr %slot1574, align 8
  %v9576 = load i64, ptr %slot44, align 8
  %p9577 = inttoptr i64 %v9576 to ptr
  store i64 %v9575, ptr %p9577, align 8, !alias.scope !3, !noalias !4
  %v9578 = load i64, ptr %slot44, align 8
  %p9579 = inttoptr i64 %v9578 to ptr
  %ld9580 = load i64, ptr %p9579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9580, ptr %slot1576, align 8
  %v9581 = load i64, ptr %slot30, align 8
  store i64 %v9581, ptr %slot1577, align 8
  %v9582 = load i64, ptr %slot1576, align 8
  %v9583 = load i64, ptr %slot1577, align 8
  %p9584 = inttoptr i64 %v9582 to ptr
  %p9585 = inttoptr i64 %v9583 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9585, ptr %p9584, i64 48, i1 false)
  %v9586 = load i64, ptr %slot22, align 8
  %p9587 = inttoptr i64 %v9586 to ptr
  store i32 2, ptr %p9587, align 4, !alias.scope !3, !noalias !4
  %v9588 = load i64, ptr %slot21, align 8
  %p9589 = inttoptr i64 %v9588 to ptr
  store i32 1, ptr %p9589, align 4, !alias.scope !3, !noalias !4
  %v9590 = load i64, ptr %slot15, align 8
  %p9591 = inttoptr i64 %v9590 to ptr
  %ld9592 = load i32, ptr %p9591, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9592, ptr %slot1578, align 8
  %v9593 = load i32, ptr %slot1578, align 8
  %cv9594 = zext i32 %v9593 to i64
  %cond9595 = icmp ne i64 %cv9594, 0
  br i1 %cond9595, label %bb_rcslotdrop2048, label %bb_rcslotdone2048
bb_rcslotdrop2048:
  %v9596 = load i64, ptr %slot15, align 8
  %p9597 = inttoptr i64 %v9596 to ptr
  store i32 0, ptr %p9597, align 4, !alias.scope !3, !noalias !4
  %v9598 = load i64, ptr %slot24, align 8
  store i64 %v9598, ptr %slot1579, align 8
  %v9599 = load i64, ptr %slot16, align 8
  %p9600 = inttoptr i64 %v9599 to ptr
  %ld9601 = load i32, ptr %p9600, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9601, ptr %slot1580, align 8
  %v9602 = load i32, ptr %slot1580, align 8
  %op9603 = and i32 %v9602, 28
  store i32 %op9603, ptr %slot1581, align 8
  %v9604 = load i32, ptr %slot1581, align 8
  %cv9605 = zext i32 %v9604 to i64
  %cond9606 = icmp ne i64 %cv9605, 0
  br i1 %cond9606, label %bb_rcslotrole2048, label %bb_rcslotowner2048
bb_rcslotrole2048:
  %v9607 = load i64, ptr %slot99, align 8
  store i64 %v9607, ptr %slot1582, align 8
  %v9608 = load i64, ptr %slot1582, align 8
  %v9609 = load i64, ptr %slot1579, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v9608, i64 %v9609) nomerge, !dbg !208
  br label %bb_rcslotdone2048
bb_rcslotowner2048:
  %v9610 = load i64, ptr %slot99, align 8
  store i64 %v9610, ptr %slot1583, align 8
  %v9611 = load i64, ptr %slot1583, align 8
  %v9612 = load i64, ptr %slot1579, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v9611, i64 %v9612) nomerge, !dbg !208
  br label %bb_rcslotdone2048
bb_rcslotdone2048:
  %v9613 = load i64, ptr %slot19, align 8
  %p9614 = inttoptr i64 %v9613 to ptr
  %ld9615 = load i32, ptr %p9614, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9615, ptr %slot1584, align 8
  %v9616 = load i32, ptr %slot1584, align 8
  %cv9617 = zext i32 %v9616 to i64
  %cond9618 = icmp ne i64 %cv9617, 0
  br i1 %cond9618, label %bb_rcslotdrop2057, label %bb_rcslotdone2057
bb_rcslotdrop2057:
  %v9619 = load i64, ptr %slot19, align 8
  %p9620 = inttoptr i64 %v9619 to ptr
  store i32 0, ptr %p9620, align 4, !alias.scope !3, !noalias !4
  %v9621 = load i64, ptr %slot26, align 8
  store i64 %v9621, ptr %slot1585, align 8
  %v9622 = load i64, ptr %slot20, align 8
  %p9623 = inttoptr i64 %v9622 to ptr
  %ld9624 = load i32, ptr %p9623, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9624, ptr %slot1586, align 8
  %v9625 = load i32, ptr %slot1586, align 8
  %op9626 = and i32 %v9625, 28
  store i32 %op9626, ptr %slot1587, align 8
  %v9627 = load i32, ptr %slot1587, align 8
  %cv9628 = zext i32 %v9627 to i64
  %cond9629 = icmp ne i64 %cv9628, 0
  br i1 %cond9629, label %bb_rcslotrole2057, label %bb_rcslotowner2057
bb_rcslotrole2057:
  %v9630 = load i64, ptr %slot99, align 8
  store i64 %v9630, ptr %slot1588, align 8
  %v9631 = load i64, ptr %slot1585, align 8
  %p9632 = inttoptr i64 %v9631 to ptr
  %ld9633 = load i64, ptr %p9632, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9633, ptr %slot1589, align 8
  %v9634 = load i64, ptr %slot1589, align 8
  %cmp9635 = icmp ne i64 %v9634, 0
  %cv9636 = zext i1 %cmp9635 to i32
  store i32 %cv9636, ptr %slot1590, align 8
  %v9637 = load i32, ptr %slot1590, align 8
  %cv9638 = zext i32 %v9637 to i64
  %cond9639 = icmp ne i64 %cv9638, 0
  br i1 %cond9639, label %bb_rcgnn2073, label %bb_rcgdone2073
bb_rcgnn2073:
  %v9640 = load i64, ptr %slot1589, align 8
  %op9641 = sub i64 %v9640, 16
  store i64 %op9641, ptr %slot1591, align 8
  %v9642 = load i64, ptr %slot1589, align 8
  %p9643 = inttoptr i64 %v9642 to ptr
  %rgep9644 = getelementptr i8, ptr %p9643, i64 -16
  %ld9645 = load i64, ptr %rgep9644, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9645, ptr %slot1592, align 8
  %v9646 = load i64, ptr %slot1592, align 8
  %op9647 = and i64 %v9646, 4611686018427387906
  store i64 %op9647, ptr %slot1593, align 8
  %v9648 = load i64, ptr %slot1593, align 8
  %cmp9649 = icmp ne i64 %v9648, 0
  %cv9650 = zext i1 %cmp9649 to i32
  store i32 %cv9650, ptr %slot1594, align 8
  %v9651 = load i32, ptr %slot1594, align 8
  %cv9652 = zext i32 %v9651 to i64
  %cond9653 = icmp ne i64 %cv9652, 0
  br i1 %cond9653, label %bb_rcgclear2073, label %bb_rcgcounted2073
bb_rcgcounted2073:
  %v9654 = load i64, ptr %slot1589, align 8
  %op9655 = sub i64 %v9654, 24
  store i64 %op9655, ptr %slot1595, align 8
  %v9656 = load i64, ptr %slot1589, align 8
  %p9657 = inttoptr i64 %v9656 to ptr
  %rgep9658 = getelementptr i8, ptr %p9657, i64 -24
  %ld9659 = load i64, ptr %rgep9658, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9659, ptr %slot1596, align 8
  %v9660 = load i64, ptr %slot1596, align 8
  %op9661 = sub i64 %v9660, 1
  store i64 %op9661, ptr %slot1597, align 8
  %v9662 = load i64, ptr %slot1597, align 8
  %cmp9663 = icmp eq i64 %v9662, 0
  %cv9664 = zext i1 %cmp9663 to i32
  store i32 %cv9664, ptr %slot1598, align 8
  %v9665 = load i32, ptr %slot1598, align 8
  %cv9666 = zext i32 %v9665 to i64
  %cond9667 = icmp ne i64 %cv9666, 0
  br i1 %cond9667, label %bb_rcglast2073, label %bb_rcgdec2073
bb_rcglast2073:
  %v9668 = load i64, ptr %slot1589, align 8
  %op9669 = sub i64 %v9668, 32
  store i64 %op9669, ptr %slot1599, align 8
  %v9670 = load i64, ptr %slot1589, align 8
  %p9671 = inttoptr i64 %v9670 to ptr
  %rgep9672 = getelementptr i8, ptr %p9671, i64 -32
  %ld9673 = load i64, ptr %rgep9672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9673, ptr %slot1600, align 8
  %v9674 = load i64, ptr %slot1600, align 8
  %cmp9675 = icmp ne i64 %v9674, 0
  %cv9676 = zext i1 %cmp9675 to i32
  store i32 %cv9676, ptr %slot1601, align 8
  %v9677 = load i32, ptr %slot1601, align 8
  %cv9678 = zext i32 %v9677 to i64
  %cond9679 = icmp ne i64 %cv9678, 0
  br i1 %cond9679, label %bb_rcgdec2073, label %bb_rcgslow2073
bb_rcgslow2073:
  %v9680 = load i64, ptr %slot1588, align 8
  %v9681 = load i64, ptr %slot1585, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v9680, i64 %v9681) nomerge, !dbg !208
  br label %bb_rcgdone2073
bb_rcgdec2073:
  %v9682 = load i64, ptr %slot1597, align 8
  %v9683 = load i64, ptr %slot1589, align 8
  %p9684 = inttoptr i64 %v9683 to ptr
  %rgep9685 = getelementptr i8, ptr %p9684, i64 -24
  store i64 %v9682, ptr %rgep9685, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2073
bb_rcgclear2073:
  %v9686 = load i64, ptr %slot1585, align 8
  %p9687 = inttoptr i64 %v9686 to ptr
  store i64 0, ptr %p9687, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2073
bb_rcgdone2073:
  br label %bb_rcslotdone2057
bb_rcslotowner2057:
  %v9688 = load i64, ptr %slot99, align 8
  store i64 %v9688, ptr %slot1602, align 8
  %v9689 = load i64, ptr %slot1585, align 8
  %p9690 = inttoptr i64 %v9689 to ptr
  %ld9691 = load i64, ptr %p9690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9691, ptr %slot1603, align 8
  %v9692 = load i64, ptr %slot1603, align 8
  %cmp9693 = icmp ne i64 %v9692, 0
  %cv9694 = zext i1 %cmp9693 to i32
  store i32 %cv9694, ptr %slot1604, align 8
  %v9695 = load i32, ptr %slot1604, align 8
  %cv9696 = zext i32 %v9695 to i64
  %cond9697 = icmp ne i64 %cv9696, 0
  br i1 %cond9697, label %bb_rcgnn2088, label %bb_rcgdone2088
bb_rcgnn2088:
  %v9698 = load i64, ptr %slot1603, align 8
  %op9699 = sub i64 %v9698, 16
  store i64 %op9699, ptr %slot1605, align 8
  %v9700 = load i64, ptr %slot1603, align 8
  %p9701 = inttoptr i64 %v9700 to ptr
  %rgep9702 = getelementptr i8, ptr %p9701, i64 -16
  %ld9703 = load i64, ptr %rgep9702, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9703, ptr %slot1606, align 8
  %v9704 = load i64, ptr %slot1606, align 8
  %op9705 = and i64 %v9704, 4611686018427387906
  store i64 %op9705, ptr %slot1607, align 8
  %v9706 = load i64, ptr %slot1607, align 8
  %cmp9707 = icmp ne i64 %v9706, 0
  %cv9708 = zext i1 %cmp9707 to i32
  store i32 %cv9708, ptr %slot1608, align 8
  %v9709 = load i32, ptr %slot1608, align 8
  %cv9710 = zext i32 %v9709 to i64
  %cond9711 = icmp ne i64 %cv9710, 0
  br i1 %cond9711, label %bb_rcgclear2088, label %bb_rcgcounted2088
bb_rcgcounted2088:
  %v9712 = load i64, ptr %slot1603, align 8
  %op9713 = sub i64 %v9712, 32
  store i64 %op9713, ptr %slot1609, align 8
  %v9714 = load i64, ptr %slot1603, align 8
  %p9715 = inttoptr i64 %v9714 to ptr
  %rgep9716 = getelementptr i8, ptr %p9715, i64 -32
  %ld9717 = load i64, ptr %rgep9716, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9717, ptr %slot1610, align 8
  %v9718 = load i64, ptr %slot1610, align 8
  %op9719 = sub i64 %v9718, 1
  store i64 %op9719, ptr %slot1611, align 8
  %v9720 = load i64, ptr %slot1611, align 8
  %cmp9721 = icmp eq i64 %v9720, 0
  %cv9722 = zext i1 %cmp9721 to i32
  store i32 %cv9722, ptr %slot1612, align 8
  %v9723 = load i32, ptr %slot1612, align 8
  %cv9724 = zext i32 %v9723 to i64
  %cond9725 = icmp ne i64 %cv9724, 0
  br i1 %cond9725, label %bb_rcglast2088, label %bb_rcgdec2088
bb_rcglast2088:
  %v9726 = load i64, ptr %slot1603, align 8
  %op9727 = sub i64 %v9726, 24
  store i64 %op9727, ptr %slot1613, align 8
  %v9728 = load i64, ptr %slot1603, align 8
  %p9729 = inttoptr i64 %v9728 to ptr
  %rgep9730 = getelementptr i8, ptr %p9729, i64 -24
  %ld9731 = load i64, ptr %rgep9730, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9731, ptr %slot1614, align 8
  %v9732 = load i64, ptr %slot1614, align 8
  %cmp9733 = icmp ne i64 %v9732, 0
  %cv9734 = zext i1 %cmp9733 to i32
  store i32 %cv9734, ptr %slot1615, align 8
  %v9735 = load i32, ptr %slot1615, align 8
  %cv9736 = zext i32 %v9735 to i64
  %cond9737 = icmp ne i64 %cv9736, 0
  br i1 %cond9737, label %bb_rcgdec2088, label %bb_rcgslow2088
bb_rcgslow2088:
  %v9738 = load i64, ptr %slot1602, align 8
  %v9739 = load i64, ptr %slot1585, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v9738, i64 %v9739) nomerge, !dbg !208
  br label %bb_rcgdone2088
bb_rcgdec2088:
  %v9740 = load i64, ptr %slot1611, align 8
  %v9741 = load i64, ptr %slot1603, align 8
  %p9742 = inttoptr i64 %v9741 to ptr
  %rgep9743 = getelementptr i8, ptr %p9742, i64 -32
  store i64 %v9740, ptr %rgep9743, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2088
bb_rcgclear2088:
  %v9744 = load i64, ptr %slot1585, align 8
  %p9745 = inttoptr i64 %v9744 to ptr
  store i64 0, ptr %p9745, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2088
bb_rcgdone2088:
  br label %bb_rcslotdone2057
bb_rcslotdone2057:
  %v9746 = load i64, ptr %slot24, align 8
  store i64 %v9746, ptr %slot1616, align 8
  %v9747 = load i64, ptr %slot30, align 8
  store i64 %v9747, ptr %slot1617, align 8
  %v9748 = load i64, ptr %slot1617, align 8
  %v9749 = load i64, ptr %slot1616, align 8
  %p9750 = inttoptr i64 %v9748 to ptr
  %p9751 = inttoptr i64 %v9749 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9751, ptr %p9750, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v9752 = load i64, ptr %slot16, align 8
  %p9753 = inttoptr i64 %v9752 to ptr
  store i32 2, ptr %p9753, align 4, !alias.scope !3, !noalias !4
  %v9754 = load i64, ptr %slot22, align 8
  %p9755 = inttoptr i64 %v9754 to ptr
  %ld9756 = load i32, ptr %p9755, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9756, ptr %slot1618, align 8
  %v9757 = load i32, ptr %slot1618, align 8
  %v9758 = load i64, ptr %slot16, align 8
  %p9759 = inttoptr i64 %v9758 to ptr
  store i32 %v9757, ptr %p9759, align 4, !alias.scope !3, !noalias !4
  %v9760 = load i64, ptr %slot21, align 8
  %p9761 = inttoptr i64 %v9760 to ptr
  store i32 0, ptr %p9761, align 4, !alias.scope !3, !noalias !4
  %v9762 = load i64, ptr %slot15, align 8
  %p9763 = inttoptr i64 %v9762 to ptr
  store i32 1, ptr %p9763, align 4, !alias.scope !3, !noalias !4
  %v9764 = load i64, ptr %slot1616, align 8
  %v9765 = load i64, ptr %slot44, align 8
  %p9766 = inttoptr i64 %v9765 to ptr
  store i64 %v9764, ptr %p9766, align 8, !alias.scope !3, !noalias !4
  %v9767 = load i64, ptr %slot44, align 8
  %p9768 = inttoptr i64 %v9767 to ptr
  %ld9769 = load i64, ptr %p9768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9769, ptr %slot1619, align 8
  %v9770 = load i64, ptr %slot1619, align 8
  %p9771 = inttoptr i64 %v9770 to ptr
  %ld9772 = load i32, ptr %p9771, align 4
  %ext9773 = zext i32 %ld9772 to i64
  store i64 %ext9773, ptr %slot1620, align 8
  %v9774 = load i64, ptr %slot1620, align 8
  %cmp9775 = icmp eq i64 %v9774, 0
  %cv9776 = zext i1 %cmp9775 to i64
  store i64 %cv9776, ptr %slot1621, align 8
  %v9777 = load i64, ptr %slot1621, align 8
  %cond9778 = icmp ne i64 %v9777, 0
  br i1 %cond9778, label %bb_rctryok2101, label %bb_rctryerror2101
bb_rctryerror2101:
  %p9779 = inttoptr i64 ptrtoint (ptr @myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p9779, i64 12884902011) "call-inline-cost"="0", !dbg !210
  %v9780 = load i64, ptr %slot1619, align 8
  %op9781 = add i64 %v9780, 8
  store i64 %op9781, ptr %slot1622, align 8
  %v9782 = load i64, ptr %slot73, align 8
  store i64 %v9782, ptr %slot1623, align 8
  %v9783 = load i64, ptr %slot1623, align 8
  %p9784 = inttoptr i64 %v9783 to ptr
  store i64 0, ptr %p9784, align 8, !alias.scope !3, !noalias !4
  %v9785 = load i64, ptr %slot1623, align 8
  %p9787 = inttoptr i64 %v9785 to ptr
  %gep9788 = getelementptr i8, ptr %p9787, i64 8
  %op9786 = ptrtoint ptr %gep9788 to i64
  store i64 %op9786, ptr %slot1624, align 8
  %v9789 = load i64, ptr %slot1624, align 8
  %p9790 = inttoptr i64 %v9789 to ptr
  store i64 0, ptr %p9790, align 8, !alias.scope !3, !noalias !4
  %v9791 = load i64, ptr %slot1623, align 8
  %p9792 = inttoptr i64 %v9791 to ptr
  store i32 1, ptr %p9792, align 4, !alias.scope !3, !noalias !4
  %v9793 = load i64, ptr %slot1623, align 8
  %p9795 = inttoptr i64 %v9793 to ptr
  %gep9796 = getelementptr i8, ptr %p9795, i64 8
  %op9794 = ptrtoint ptr %gep9796 to i64
  store i64 %op9794, ptr %slot1625, align 8
  %v9797 = load i64, ptr %slot23, align 8
  %p9798 = inttoptr i64 %v9797 to ptr
  store i32 1, ptr %p9798, align 4, !alias.scope !3, !noalias !4
  %v9799 = load i64, ptr %slot100, align 8
  store i64 %v9799, ptr %slot1626, align 8
  %v9800 = load i64, ptr %slot1623, align 8
  %v9801 = load i64, ptr %slot44, align 8
  %p9802 = inttoptr i64 %v9801 to ptr
  store i64 %v9800, ptr %p9802, align 8, !alias.scope !3, !noalias !4
  %v9803 = load i64, ptr %slot15, align 8
  %p9804 = inttoptr i64 %v9803 to ptr
  %ld9805 = load i32, ptr %p9804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9805, ptr %slot1627, align 8
  %v9806 = load i32, ptr %slot1627, align 8
  %cv9807 = zext i32 %v9806 to i64
  %cond9808 = icmp ne i64 %cv9807, 0
  br i1 %cond9808, label %bb_rcslotdrop2112, label %bb_rcslotdone2112
bb_rcslotdrop2112:
  %v9809 = load i64, ptr %slot15, align 8
  %p9810 = inttoptr i64 %v9809 to ptr
  store i32 0, ptr %p9810, align 4, !alias.scope !3, !noalias !4
  %v9811 = load i64, ptr %slot24, align 8
  store i64 %v9811, ptr %slot1628, align 8
  %v9812 = load i64, ptr %slot16, align 8
  %p9813 = inttoptr i64 %v9812 to ptr
  %ld9814 = load i32, ptr %p9813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9814, ptr %slot1629, align 8
  %v9815 = load i32, ptr %slot1629, align 8
  %op9816 = and i32 %v9815, 28
  store i32 %op9816, ptr %slot1630, align 8
  %v9817 = load i32, ptr %slot1630, align 8
  %cv9818 = zext i32 %v9817 to i64
  %cond9819 = icmp ne i64 %cv9818, 0
  br i1 %cond9819, label %bb_rcslotrole2112, label %bb_rcslotowner2112
bb_rcslotrole2112:
  %v9820 = load i64, ptr %slot99, align 8
  store i64 %v9820, ptr %slot1631, align 8
  %v9821 = load i64, ptr %slot1631, align 8
  %v9822 = load i64, ptr %slot1628, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v9821, i64 %v9822) nomerge, !dbg !210
  br label %bb_rcslotdone2112
bb_rcslotowner2112:
  %v9823 = load i64, ptr %slot99, align 8
  store i64 %v9823, ptr %slot1632, align 8
  %v9824 = load i64, ptr %slot1632, align 8
  %v9825 = load i64, ptr %slot1628, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v9824, i64 %v9825) nomerge, !dbg !210
  br label %bb_rcslotdone2112
bb_rcslotdone2112:
  br label %bb_i125
bb_rctryok2101:
  %v9826 = load i64, ptr %slot73, align 8
  store i64 %v9826, ptr %slot1633, align 8
  %v9827 = load i64, ptr %slot1633, align 8
  %p9828 = inttoptr i64 %v9827 to ptr
  store i64 0, ptr %p9828, align 8, !alias.scope !3, !noalias !4
  %v9829 = load i64, ptr %slot1633, align 8
  %p9831 = inttoptr i64 %v9829 to ptr
  %gep9832 = getelementptr i8, ptr %p9831, i64 8
  %op9830 = ptrtoint ptr %gep9832 to i64
  store i64 %op9830, ptr %slot1634, align 8
  %v9833 = load i64, ptr %slot1634, align 8
  %p9834 = inttoptr i64 %v9833 to ptr
  store i64 0, ptr %p9834, align 8, !alias.scope !3, !noalias !4
  %v9835 = load i64, ptr %slot1633, align 8
  %p9837 = inttoptr i64 %v9835 to ptr
  %gep9838 = getelementptr i8, ptr %p9837, i64 16
  %op9836 = ptrtoint ptr %gep9838 to i64
  store i64 %op9836, ptr %slot1635, align 8
  %v9839 = load i64, ptr %slot1635, align 8
  %p9840 = inttoptr i64 %v9839 to ptr
  store i64 0, ptr %p9840, align 8, !alias.scope !3, !noalias !4
  %v9841 = load i64, ptr %slot1633, align 8
  %p9843 = inttoptr i64 %v9841 to ptr
  %gep9844 = getelementptr i8, ptr %p9843, i64 24
  %op9842 = ptrtoint ptr %gep9844 to i64
  store i64 %op9842, ptr %slot1636, align 8
  %v9845 = load i64, ptr %slot1636, align 8
  %p9846 = inttoptr i64 %v9845 to ptr
  store i64 0, ptr %p9846, align 8, !alias.scope !3, !noalias !4
  %v9847 = load i64, ptr %slot1633, align 8
  %p9849 = inttoptr i64 %v9847 to ptr
  %gep9850 = getelementptr i8, ptr %p9849, i64 32
  %op9848 = ptrtoint ptr %gep9850 to i64
  store i64 %op9848, ptr %slot1637, align 8
  %v9851 = load i64, ptr %slot1637, align 8
  %p9852 = inttoptr i64 %v9851 to ptr
  store i64 0, ptr %p9852, align 8, !alias.scope !3, !noalias !4
  %v9853 = load i64, ptr %slot23, align 8
  %p9854 = inttoptr i64 %v9853 to ptr
  store i32 1, ptr %p9854, align 4, !alias.scope !3, !noalias !4
  %v9855 = load i64, ptr %slot1619, align 8
  %op9856 = add i64 %v9855, 8
  store i64 %op9856, ptr %slot1638, align 8
  %v9857 = load i64, ptr %slot100, align 8
  store i64 %v9857, ptr %slot1639, align 8
  %v9858 = load i64, ptr %slot99, align 8
  %v9859 = load i64, ptr %slot1633, align 8
  %v9860 = load i64, ptr %slot1638, align 8
  %v9861 = load i64, ptr %slot1639, align 8
  %cv9862 = trunc i64 %v9861 to i32
  %call9863 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v9858, i64 %v9859, i64 %v9860, i32 %cv9862) nomerge, !dbg !210
  store i32 %call9863, ptr %slot1640, align 8
  %v9864 = load i32, ptr %slot1640, align 8
  %cv9865 = zext i32 %v9864 to i64
  %cond9866 = icmp ne i64 %cv9865, 0
  br i1 %cond9866, label %bb_rcsuccess2129, label %bb_rcfailure2129
bb_rcfailure2129:
  %v9867 = load i64, ptr %slot99, align 8
  %p9868 = inttoptr i64 %v9867 to ptr
  %call9869 = call i32 @myl_rc_take_failure(ptr %p9868) nomerge, !dbg !210
  store i32 %call9869, ptr %slot1641, align 8
  %v9870 = load i64, ptr %slot1, align 8
  %p9871 = inttoptr i64 %v9870 to ptr
  %v9872 = load i32, ptr %slot1641, align 8
  %call9873 = call i32 @myl_qbe_rc_status(ptr %p9871, i32 %v9872) nomerge, !dbg !210
  store i32 %call9873, ptr %slot1642, align 8
  br label %bb_failure
bb_rcsuccess2129:
  %v9874 = load i64, ptr %slot1633, align 8
  %v9875 = load i64, ptr %slot44, align 8
  %p9876 = inttoptr i64 %v9875 to ptr
  store i64 %v9874, ptr %p9876, align 8, !alias.scope !3, !noalias !4
  %v9877 = load i64, ptr %slot44, align 8
  %p9878 = inttoptr i64 %v9877 to ptr
  %ld9879 = load i64, ptr %p9878, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9879, ptr %slot1643, align 8
  %v9880 = load i64, ptr %slot30, align 8
  store i64 %v9880, ptr %slot1644, align 8
  %v9881 = load i64, ptr %slot1643, align 8
  %v9882 = load i64, ptr %slot1644, align 8
  %p9883 = inttoptr i64 %v9881 to ptr
  %p9884 = inttoptr i64 %v9882 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9884, ptr %p9883, i64 40, i1 false)
  %v9885 = load i64, ptr %slot22, align 8
  %p9886 = inttoptr i64 %v9885 to ptr
  store i32 2, ptr %p9886, align 4, !alias.scope !3, !noalias !4
  %v9887 = load i64, ptr %slot21, align 8
  %p9888 = inttoptr i64 %v9887 to ptr
  store i32 1, ptr %p9888, align 4, !alias.scope !3, !noalias !4
  %v9889 = load i64, ptr %slot15, align 8
  %p9890 = inttoptr i64 %v9889 to ptr
  %ld9891 = load i32, ptr %p9890, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9891, ptr %slot1645, align 8
  %v9892 = load i32, ptr %slot1645, align 8
  %cv9893 = zext i32 %v9892 to i64
  %cond9894 = icmp ne i64 %cv9893, 0
  br i1 %cond9894, label %bb_rcslotdrop2138, label %bb_rcslotdone2138
bb_rcslotdrop2138:
  %v9895 = load i64, ptr %slot15, align 8
  %p9896 = inttoptr i64 %v9895 to ptr
  store i32 0, ptr %p9896, align 4, !alias.scope !3, !noalias !4
  %v9897 = load i64, ptr %slot24, align 8
  store i64 %v9897, ptr %slot1646, align 8
  %v9898 = load i64, ptr %slot16, align 8
  %p9899 = inttoptr i64 %v9898 to ptr
  %ld9900 = load i32, ptr %p9899, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9900, ptr %slot1647, align 8
  %v9901 = load i32, ptr %slot1647, align 8
  %op9902 = and i32 %v9901, 28
  store i32 %op9902, ptr %slot1648, align 8
  %v9903 = load i32, ptr %slot1648, align 8
  %cv9904 = zext i32 %v9903 to i64
  %cond9905 = icmp ne i64 %cv9904, 0
  br i1 %cond9905, label %bb_rcslotrole2138, label %bb_rcslotowner2138
bb_rcslotrole2138:
  %v9906 = load i64, ptr %slot99, align 8
  store i64 %v9906, ptr %slot1649, align 8
  %v9907 = load i64, ptr %slot1649, align 8
  %v9908 = load i64, ptr %slot1646, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v9907, i64 %v9908) nomerge, !dbg !210
  br label %bb_rcslotdone2138
bb_rcslotowner2138:
  %v9909 = load i64, ptr %slot99, align 8
  store i64 %v9909, ptr %slot1650, align 8
  %v9910 = load i64, ptr %slot1650, align 8
  %v9911 = load i64, ptr %slot1646, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v9910, i64 %v9911) nomerge, !dbg !210
  br label %bb_rcslotdone2138
bb_rcslotdone2138:
  %v9912 = load i64, ptr %slot24, align 8
  store i64 %v9912, ptr %slot1651, align 8
  %v9913 = load i64, ptr %slot30, align 8
  store i64 %v9913, ptr %slot1652, align 8
  %v9914 = load i64, ptr %slot1652, align 8
  %v9915 = load i64, ptr %slot1651, align 8
  %p9916 = inttoptr i64 %v9914 to ptr
  %p9917 = inttoptr i64 %v9915 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9917, ptr %p9916, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v9918 = load i64, ptr %slot16, align 8
  %p9919 = inttoptr i64 %v9918 to ptr
  store i32 2, ptr %p9919, align 4, !alias.scope !3, !noalias !4
  %v9920 = load i64, ptr %slot22, align 8
  %p9921 = inttoptr i64 %v9920 to ptr
  %ld9922 = load i32, ptr %p9921, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9922, ptr %slot1653, align 8
  %v9923 = load i32, ptr %slot1653, align 8
  %v9924 = load i64, ptr %slot16, align 8
  %p9925 = inttoptr i64 %v9924 to ptr
  store i32 %v9923, ptr %p9925, align 4, !alias.scope !3, !noalias !4
  %v9926 = load i64, ptr %slot21, align 8
  %p9927 = inttoptr i64 %v9926 to ptr
  store i32 0, ptr %p9927, align 4, !alias.scope !3, !noalias !4
  %v9928 = load i64, ptr %slot15, align 8
  %p9929 = inttoptr i64 %v9928 to ptr
  store i32 1, ptr %p9929, align 4, !alias.scope !3, !noalias !4
  %v9930 = load i64, ptr %slot1651, align 8
  %v9931 = load i64, ptr %slot44, align 8
  %p9932 = inttoptr i64 %v9931 to ptr
  store i64 %v9930, ptr %p9932, align 8, !alias.scope !3, !noalias !4
  br label %bb_i126
bb_i125:
  %v9933 = load i64, ptr %slot44, align 8
  %p9934 = inttoptr i64 %v9933 to ptr
  %ld9935 = load i64, ptr %p9934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9935, ptr %slot1654, align 8
  %v9936 = load i64, ptr %slot15, align 8
  %p9937 = inttoptr i64 %v9936 to ptr
  %ld9938 = load i32, ptr %p9937, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9938, ptr %slot1655, align 8
  %v9939 = load i32, ptr %slot1655, align 8
  %cv9940 = zext i32 %v9939 to i64
  %cond9941 = icmp ne i64 %cv9940, 0
  br i1 %cond9941, label %bb_rcslotdrop2156, label %bb_rcslotdone2156
bb_rcslotdrop2156:
  %v9942 = load i64, ptr %slot15, align 8
  %p9943 = inttoptr i64 %v9942 to ptr
  store i32 0, ptr %p9943, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2156
bb_rcslotdone2156:
  %v9944 = load i64, ptr %slot13, align 8
  %p9945 = inttoptr i64 %v9944 to ptr
  %ld9946 = load i32, ptr %p9945, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9946, ptr %slot1656, align 8
  %v9947 = load i32, ptr %slot1656, align 8
  %cv9948 = zext i32 %v9947 to i64
  %cond9949 = icmp ne i64 %cv9948, 0
  br i1 %cond9949, label %bb_rcslotdrop2159, label %bb_rcslotdone2159
bb_rcslotdrop2159:
  %v9950 = load i64, ptr %slot13, align 8
  %p9951 = inttoptr i64 %v9950 to ptr
  store i32 0, ptr %p9951, align 4, !alias.scope !3, !noalias !4
  %v9952 = load i64, ptr %slot42, align 8
  store i64 %v9952, ptr %slot1657, align 8
  %v9953 = load i64, ptr %slot14, align 8
  %p9954 = inttoptr i64 %v9953 to ptr
  %ld9955 = load i32, ptr %p9954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9955, ptr %slot1658, align 8
  %v9956 = load i32, ptr %slot1658, align 8
  %op9957 = and i32 %v9956, 28
  store i32 %op9957, ptr %slot1659, align 8
  %v9958 = load i32, ptr %slot1659, align 8
  %cv9959 = zext i32 %v9958 to i64
  %cond9960 = icmp ne i64 %cv9959, 0
  br i1 %cond9960, label %bb_rcslotrole2159, label %bb_rcslotowner2159
bb_rcslotrole2159:
  %v9961 = load i64, ptr %slot99, align 8
  store i64 %v9961, ptr %slot1660, align 8
  %v9962 = load i64, ptr %slot1660, align 8
  %v9963 = load i64, ptr %slot1657, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v9962, i64 %v9963) nomerge, !dbg !212
  br label %bb_rcslotdone2159
bb_rcslotowner2159:
  %v9964 = load i64, ptr %slot99, align 8
  store i64 %v9964, ptr %slot1661, align 8
  %v9965 = load i64, ptr %slot1661, align 8
  %v9966 = load i64, ptr %slot1657, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v9965, i64 %v9966) nomerge, !dbg !212
  br label %bb_rcslotdone2159
bb_rcslotdone2159:
  %v9967 = load i64, ptr %slot11, align 8
  %p9968 = inttoptr i64 %v9967 to ptr
  %ld9969 = load i32, ptr %p9968, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9969, ptr %slot1662, align 8
  %v9970 = load i32, ptr %slot1662, align 8
  %cv9971 = zext i32 %v9970 to i64
  %cond9972 = icmp ne i64 %cv9971, 0
  br i1 %cond9972, label %bb_rcslotdrop2168, label %bb_rcslotdone2168
bb_rcslotdrop2168:
  %v9973 = load i64, ptr %slot11, align 8
  %p9974 = inttoptr i64 %v9973 to ptr
  store i32 0, ptr %p9974, align 4, !alias.scope !3, !noalias !4
  %v9975 = load i64, ptr %slot41, align 8
  store i64 %v9975, ptr %slot1663, align 8
  %v9976 = load i64, ptr %slot12, align 8
  %p9977 = inttoptr i64 %v9976 to ptr
  %ld9978 = load i32, ptr %p9977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9978, ptr %slot1664, align 8
  %v9979 = load i32, ptr %slot1664, align 8
  %op9980 = and i32 %v9979, 28
  store i32 %op9980, ptr %slot1665, align 8
  %v9981 = load i32, ptr %slot1665, align 8
  %cv9982 = zext i32 %v9981 to i64
  %cond9983 = icmp ne i64 %cv9982, 0
  br i1 %cond9983, label %bb_rcslotrole2168, label %bb_rcslotowner2168
bb_rcslotrole2168:
  %v9984 = load i64, ptr %slot99, align 8
  store i64 %v9984, ptr %slot1666, align 8
  %v9985 = load i64, ptr %slot1666, align 8
  %v9986 = load i64, ptr %slot1663, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v9985, i64 %v9986) nomerge, !dbg !212
  br label %bb_rcslotdone2168
bb_rcslotowner2168:
  %v9987 = load i64, ptr %slot99, align 8
  store i64 %v9987, ptr %slot1667, align 8
  %v9988 = load i64, ptr %slot1667, align 8
  %v9989 = load i64, ptr %slot1663, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v9988, i64 %v9989) nomerge, !dbg !212
  br label %bb_rcslotdone2168
bb_rcslotdone2168:
  %v9990 = load i64, ptr %slot9, align 8
  %p9991 = inttoptr i64 %v9990 to ptr
  %ld9992 = load i32, ptr %p9991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9992, ptr %slot1668, align 8
  %v9993 = load i32, ptr %slot1668, align 8
  %cv9994 = zext i32 %v9993 to i64
  %cond9995 = icmp ne i64 %cv9994, 0
  br i1 %cond9995, label %bb_rcslotdrop2177, label %bb_rcslotdone2177
bb_rcslotdrop2177:
  %v9996 = load i64, ptr %slot9, align 8
  %p9997 = inttoptr i64 %v9996 to ptr
  store i32 0, ptr %p9997, align 4, !alias.scope !3, !noalias !4
  %v9998 = load i64, ptr %slot39, align 8
  store i64 %v9998, ptr %slot1669, align 8
  %v9999 = load i64, ptr %slot10, align 8
  %p10000 = inttoptr i64 %v9999 to ptr
  %ld10001 = load i32, ptr %p10000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10001, ptr %slot1670, align 8
  %v10002 = load i32, ptr %slot1670, align 8
  %op10003 = and i32 %v10002, 28
  store i32 %op10003, ptr %slot1671, align 8
  %v10004 = load i32, ptr %slot1671, align 8
  %cv10005 = zext i32 %v10004 to i64
  %cond10006 = icmp ne i64 %cv10005, 0
  br i1 %cond10006, label %bb_rcslotrole2177, label %bb_rcslotowner2177
bb_rcslotrole2177:
  %v10007 = load i64, ptr %slot99, align 8
  store i64 %v10007, ptr %slot1672, align 8
  %v10008 = load i64, ptr %slot1669, align 8
  %p10009 = inttoptr i64 %v10008 to ptr
  %ld10010 = load i64, ptr %p10009, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10010, ptr %slot1673, align 8
  %v10011 = load i64, ptr %slot1673, align 8
  %cmp10012 = icmp ne i64 %v10011, 0
  %cv10013 = zext i1 %cmp10012 to i32
  store i32 %cv10013, ptr %slot1674, align 8
  %v10014 = load i32, ptr %slot1674, align 8
  %cv10015 = zext i32 %v10014 to i64
  %cond10016 = icmp ne i64 %cv10015, 0
  br i1 %cond10016, label %bb_rcgnn2193, label %bb_rcgdone2193
bb_rcgnn2193:
  %v10017 = load i64, ptr %slot1673, align 8
  %op10018 = sub i64 %v10017, 16
  store i64 %op10018, ptr %slot1675, align 8
  %v10019 = load i64, ptr %slot1673, align 8
  %p10020 = inttoptr i64 %v10019 to ptr
  %rgep10021 = getelementptr i8, ptr %p10020, i64 -16
  %ld10022 = load i64, ptr %rgep10021, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10022, ptr %slot1676, align 8
  %v10023 = load i64, ptr %slot1676, align 8
  %op10024 = and i64 %v10023, 4611686018427387906
  store i64 %op10024, ptr %slot1677, align 8
  %v10025 = load i64, ptr %slot1677, align 8
  %cmp10026 = icmp ne i64 %v10025, 0
  %cv10027 = zext i1 %cmp10026 to i32
  store i32 %cv10027, ptr %slot1678, align 8
  %v10028 = load i32, ptr %slot1678, align 8
  %cv10029 = zext i32 %v10028 to i64
  %cond10030 = icmp ne i64 %cv10029, 0
  br i1 %cond10030, label %bb_rcgclear2193, label %bb_rcgcounted2193
bb_rcgcounted2193:
  %v10031 = load i64, ptr %slot1673, align 8
  %op10032 = sub i64 %v10031, 24
  store i64 %op10032, ptr %slot1679, align 8
  %v10033 = load i64, ptr %slot1673, align 8
  %p10034 = inttoptr i64 %v10033 to ptr
  %rgep10035 = getelementptr i8, ptr %p10034, i64 -24
  %ld10036 = load i64, ptr %rgep10035, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10036, ptr %slot1680, align 8
  %v10037 = load i64, ptr %slot1680, align 8
  %op10038 = sub i64 %v10037, 1
  store i64 %op10038, ptr %slot1681, align 8
  %v10039 = load i64, ptr %slot1681, align 8
  %cmp10040 = icmp eq i64 %v10039, 0
  %cv10041 = zext i1 %cmp10040 to i32
  store i32 %cv10041, ptr %slot1682, align 8
  %v10042 = load i32, ptr %slot1682, align 8
  %cv10043 = zext i32 %v10042 to i64
  %cond10044 = icmp ne i64 %cv10043, 0
  br i1 %cond10044, label %bb_rcglast2193, label %bb_rcgdec2193
bb_rcglast2193:
  %v10045 = load i64, ptr %slot1673, align 8
  %op10046 = sub i64 %v10045, 32
  store i64 %op10046, ptr %slot1683, align 8
  %v10047 = load i64, ptr %slot1673, align 8
  %p10048 = inttoptr i64 %v10047 to ptr
  %rgep10049 = getelementptr i8, ptr %p10048, i64 -32
  %ld10050 = load i64, ptr %rgep10049, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10050, ptr %slot1684, align 8
  %v10051 = load i64, ptr %slot1684, align 8
  %cmp10052 = icmp ne i64 %v10051, 0
  %cv10053 = zext i1 %cmp10052 to i32
  store i32 %cv10053, ptr %slot1685, align 8
  %v10054 = load i32, ptr %slot1685, align 8
  %cv10055 = zext i32 %v10054 to i64
  %cond10056 = icmp ne i64 %cv10055, 0
  br i1 %cond10056, label %bb_rcgdec2193, label %bb_rcgslow2193
bb_rcgslow2193:
  %v10057 = load i64, ptr %slot1672, align 8
  %v10058 = load i64, ptr %slot1669, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v10057, i64 %v10058) nomerge, !dbg !212
  br label %bb_rcgdone2193
bb_rcgdec2193:
  %v10059 = load i64, ptr %slot1681, align 8
  %v10060 = load i64, ptr %slot1673, align 8
  %p10061 = inttoptr i64 %v10060 to ptr
  %rgep10062 = getelementptr i8, ptr %p10061, i64 -24
  store i64 %v10059, ptr %rgep10062, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2193
bb_rcgclear2193:
  %v10063 = load i64, ptr %slot1669, align 8
  %p10064 = inttoptr i64 %v10063 to ptr
  store i64 0, ptr %p10064, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2193
bb_rcgdone2193:
  br label %bb_rcslotdone2177
bb_rcslotowner2177:
  %v10065 = load i64, ptr %slot99, align 8
  store i64 %v10065, ptr %slot1686, align 8
  %v10066 = load i64, ptr %slot1669, align 8
  %p10067 = inttoptr i64 %v10066 to ptr
  %ld10068 = load i64, ptr %p10067, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10068, ptr %slot1687, align 8
  %v10069 = load i64, ptr %slot1687, align 8
  %cmp10070 = icmp ne i64 %v10069, 0
  %cv10071 = zext i1 %cmp10070 to i32
  store i32 %cv10071, ptr %slot1688, align 8
  %v10072 = load i32, ptr %slot1688, align 8
  %cv10073 = zext i32 %v10072 to i64
  %cond10074 = icmp ne i64 %cv10073, 0
  br i1 %cond10074, label %bb_rcgnn2208, label %bb_rcgdone2208
bb_rcgnn2208:
  %v10075 = load i64, ptr %slot1687, align 8
  %op10076 = sub i64 %v10075, 16
  store i64 %op10076, ptr %slot1689, align 8
  %v10077 = load i64, ptr %slot1687, align 8
  %p10078 = inttoptr i64 %v10077 to ptr
  %rgep10079 = getelementptr i8, ptr %p10078, i64 -16
  %ld10080 = load i64, ptr %rgep10079, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10080, ptr %slot1690, align 8
  %v10081 = load i64, ptr %slot1690, align 8
  %op10082 = and i64 %v10081, 4611686018427387906
  store i64 %op10082, ptr %slot1691, align 8
  %v10083 = load i64, ptr %slot1691, align 8
  %cmp10084 = icmp ne i64 %v10083, 0
  %cv10085 = zext i1 %cmp10084 to i32
  store i32 %cv10085, ptr %slot1692, align 8
  %v10086 = load i32, ptr %slot1692, align 8
  %cv10087 = zext i32 %v10086 to i64
  %cond10088 = icmp ne i64 %cv10087, 0
  br i1 %cond10088, label %bb_rcgclear2208, label %bb_rcgcounted2208
bb_rcgcounted2208:
  %v10089 = load i64, ptr %slot1687, align 8
  %op10090 = sub i64 %v10089, 32
  store i64 %op10090, ptr %slot1693, align 8
  %v10091 = load i64, ptr %slot1687, align 8
  %p10092 = inttoptr i64 %v10091 to ptr
  %rgep10093 = getelementptr i8, ptr %p10092, i64 -32
  %ld10094 = load i64, ptr %rgep10093, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10094, ptr %slot1694, align 8
  %v10095 = load i64, ptr %slot1694, align 8
  %op10096 = sub i64 %v10095, 1
  store i64 %op10096, ptr %slot1695, align 8
  %v10097 = load i64, ptr %slot1695, align 8
  %cmp10098 = icmp eq i64 %v10097, 0
  %cv10099 = zext i1 %cmp10098 to i32
  store i32 %cv10099, ptr %slot1696, align 8
  %v10100 = load i32, ptr %slot1696, align 8
  %cv10101 = zext i32 %v10100 to i64
  %cond10102 = icmp ne i64 %cv10101, 0
  br i1 %cond10102, label %bb_rcglast2208, label %bb_rcgdec2208
bb_rcglast2208:
  %v10103 = load i64, ptr %slot1687, align 8
  %op10104 = sub i64 %v10103, 24
  store i64 %op10104, ptr %slot1697, align 8
  %v10105 = load i64, ptr %slot1687, align 8
  %p10106 = inttoptr i64 %v10105 to ptr
  %rgep10107 = getelementptr i8, ptr %p10106, i64 -24
  %ld10108 = load i64, ptr %rgep10107, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10108, ptr %slot1698, align 8
  %v10109 = load i64, ptr %slot1698, align 8
  %cmp10110 = icmp ne i64 %v10109, 0
  %cv10111 = zext i1 %cmp10110 to i32
  store i32 %cv10111, ptr %slot1699, align 8
  %v10112 = load i32, ptr %slot1699, align 8
  %cv10113 = zext i32 %v10112 to i64
  %cond10114 = icmp ne i64 %cv10113, 0
  br i1 %cond10114, label %bb_rcgdec2208, label %bb_rcgslow2208
bb_rcgslow2208:
  %v10115 = load i64, ptr %slot1686, align 8
  %v10116 = load i64, ptr %slot1669, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v10115, i64 %v10116) nomerge, !dbg !212
  br label %bb_rcgdone2208
bb_rcgdec2208:
  %v10117 = load i64, ptr %slot1695, align 8
  %v10118 = load i64, ptr %slot1687, align 8
  %p10119 = inttoptr i64 %v10118 to ptr
  %rgep10120 = getelementptr i8, ptr %p10119, i64 -32
  store i64 %v10117, ptr %rgep10120, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2208
bb_rcgclear2208:
  %v10121 = load i64, ptr %slot1669, align 8
  %p10122 = inttoptr i64 %v10121 to ptr
  store i64 0, ptr %p10122, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2208
bb_rcgdone2208:
  br label %bb_rcslotdone2177
bb_rcslotdone2177:
  %v10123 = load i64, ptr %slot7, align 8
  %p10124 = inttoptr i64 %v10123 to ptr
  %ld10125 = load i32, ptr %p10124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10125, ptr %slot1700, align 8
  %v10126 = load i32, ptr %slot1700, align 8
  %cv10127 = zext i32 %v10126 to i64
  %cond10128 = icmp ne i64 %cv10127, 0
  br i1 %cond10128, label %bb_rcslotdrop2214, label %bb_rcslotdone2214
bb_rcslotdrop2214:
  %v10129 = load i64, ptr %slot7, align 8
  %p10130 = inttoptr i64 %v10129 to ptr
  store i32 0, ptr %p10130, align 4, !alias.scope !3, !noalias !4
  %v10131 = load i64, ptr %slot34, align 8
  store i64 %v10131, ptr %slot1701, align 8
  %v10132 = load i64, ptr %slot8, align 8
  %p10133 = inttoptr i64 %v10132 to ptr
  %ld10134 = load i32, ptr %p10133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10134, ptr %slot1702, align 8
  %v10135 = load i32, ptr %slot1702, align 8
  %op10136 = and i32 %v10135, 28
  store i32 %op10136, ptr %slot1703, align 8
  %v10137 = load i32, ptr %slot1703, align 8
  %cv10138 = zext i32 %v10137 to i64
  %cond10139 = icmp ne i64 %cv10138, 0
  br i1 %cond10139, label %bb_rcslotrole2214, label %bb_rcslotowner2214
bb_rcslotrole2214:
  %v10140 = load i64, ptr %slot99, align 8
  store i64 %v10140, ptr %slot1704, align 8
  %v10141 = load i64, ptr %slot1701, align 8
  %p10142 = inttoptr i64 %v10141 to ptr
  %ld10143 = load i64, ptr %p10142, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10143, ptr %slot1705, align 8
  %v10144 = load i64, ptr %slot1705, align 8
  %cmp10145 = icmp ne i64 %v10144, 0
  %cv10146 = zext i1 %cmp10145 to i32
  store i32 %cv10146, ptr %slot1706, align 8
  %v10147 = load i32, ptr %slot1706, align 8
  %cv10148 = zext i32 %v10147 to i64
  %cond10149 = icmp ne i64 %cv10148, 0
  br i1 %cond10149, label %bb_rcgnn2230, label %bb_rcgdone2230
bb_rcgnn2230:
  %v10150 = load i64, ptr %slot1705, align 8
  %op10151 = sub i64 %v10150, 16
  store i64 %op10151, ptr %slot1707, align 8
  %v10152 = load i64, ptr %slot1705, align 8
  %p10153 = inttoptr i64 %v10152 to ptr
  %rgep10154 = getelementptr i8, ptr %p10153, i64 -16
  %ld10155 = load i64, ptr %rgep10154, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10155, ptr %slot1708, align 8
  %v10156 = load i64, ptr %slot1708, align 8
  %op10157 = and i64 %v10156, 4611686018427387906
  store i64 %op10157, ptr %slot1709, align 8
  %v10158 = load i64, ptr %slot1709, align 8
  %cmp10159 = icmp ne i64 %v10158, 0
  %cv10160 = zext i1 %cmp10159 to i32
  store i32 %cv10160, ptr %slot1710, align 8
  %v10161 = load i32, ptr %slot1710, align 8
  %cv10162 = zext i32 %v10161 to i64
  %cond10163 = icmp ne i64 %cv10162, 0
  br i1 %cond10163, label %bb_rcgclear2230, label %bb_rcgcounted2230
bb_rcgcounted2230:
  %v10164 = load i64, ptr %slot1705, align 8
  %op10165 = sub i64 %v10164, 24
  store i64 %op10165, ptr %slot1711, align 8
  %v10166 = load i64, ptr %slot1705, align 8
  %p10167 = inttoptr i64 %v10166 to ptr
  %rgep10168 = getelementptr i8, ptr %p10167, i64 -24
  %ld10169 = load i64, ptr %rgep10168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10169, ptr %slot1712, align 8
  %v10170 = load i64, ptr %slot1712, align 8
  %op10171 = sub i64 %v10170, 1
  store i64 %op10171, ptr %slot1713, align 8
  %v10172 = load i64, ptr %slot1713, align 8
  %cmp10173 = icmp eq i64 %v10172, 0
  %cv10174 = zext i1 %cmp10173 to i32
  store i32 %cv10174, ptr %slot1714, align 8
  %v10175 = load i32, ptr %slot1714, align 8
  %cv10176 = zext i32 %v10175 to i64
  %cond10177 = icmp ne i64 %cv10176, 0
  br i1 %cond10177, label %bb_rcglast2230, label %bb_rcgdec2230
bb_rcglast2230:
  %v10178 = load i64, ptr %slot1705, align 8
  %op10179 = sub i64 %v10178, 32
  store i64 %op10179, ptr %slot1715, align 8
  %v10180 = load i64, ptr %slot1705, align 8
  %p10181 = inttoptr i64 %v10180 to ptr
  %rgep10182 = getelementptr i8, ptr %p10181, i64 -32
  %ld10183 = load i64, ptr %rgep10182, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10183, ptr %slot1716, align 8
  %v10184 = load i64, ptr %slot1716, align 8
  %cmp10185 = icmp ne i64 %v10184, 0
  %cv10186 = zext i1 %cmp10185 to i32
  store i32 %cv10186, ptr %slot1717, align 8
  %v10187 = load i32, ptr %slot1717, align 8
  %cv10188 = zext i32 %v10187 to i64
  %cond10189 = icmp ne i64 %cv10188, 0
  br i1 %cond10189, label %bb_rcgdec2230, label %bb_rcgslow2230
bb_rcgslow2230:
  %v10190 = load i64, ptr %slot1704, align 8
  %v10191 = load i64, ptr %slot1701, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v10190, i64 %v10191) nomerge, !dbg !212
  br label %bb_rcgdone2230
bb_rcgdec2230:
  %v10192 = load i64, ptr %slot1713, align 8
  %v10193 = load i64, ptr %slot1705, align 8
  %p10194 = inttoptr i64 %v10193 to ptr
  %rgep10195 = getelementptr i8, ptr %p10194, i64 -24
  store i64 %v10192, ptr %rgep10195, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2230
bb_rcgclear2230:
  %v10196 = load i64, ptr %slot1701, align 8
  %p10197 = inttoptr i64 %v10196 to ptr
  store i64 0, ptr %p10197, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2230
bb_rcgdone2230:
  br label %bb_rcslotdone2214
bb_rcslotowner2214:
  %v10198 = load i64, ptr %slot99, align 8
  store i64 %v10198, ptr %slot1718, align 8
  %v10199 = load i64, ptr %slot1701, align 8
  %p10200 = inttoptr i64 %v10199 to ptr
  %ld10201 = load i64, ptr %p10200, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10201, ptr %slot1719, align 8
  %v10202 = load i64, ptr %slot1719, align 8
  %cmp10203 = icmp ne i64 %v10202, 0
  %cv10204 = zext i1 %cmp10203 to i32
  store i32 %cv10204, ptr %slot1720, align 8
  %v10205 = load i32, ptr %slot1720, align 8
  %cv10206 = zext i32 %v10205 to i64
  %cond10207 = icmp ne i64 %cv10206, 0
  br i1 %cond10207, label %bb_rcgnn2245, label %bb_rcgdone2245
bb_rcgnn2245:
  %v10208 = load i64, ptr %slot1719, align 8
  %op10209 = sub i64 %v10208, 16
  store i64 %op10209, ptr %slot1721, align 8
  %v10210 = load i64, ptr %slot1719, align 8
  %p10211 = inttoptr i64 %v10210 to ptr
  %rgep10212 = getelementptr i8, ptr %p10211, i64 -16
  %ld10213 = load i64, ptr %rgep10212, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10213, ptr %slot1722, align 8
  %v10214 = load i64, ptr %slot1722, align 8
  %op10215 = and i64 %v10214, 4611686018427387906
  store i64 %op10215, ptr %slot1723, align 8
  %v10216 = load i64, ptr %slot1723, align 8
  %cmp10217 = icmp ne i64 %v10216, 0
  %cv10218 = zext i1 %cmp10217 to i32
  store i32 %cv10218, ptr %slot1724, align 8
  %v10219 = load i32, ptr %slot1724, align 8
  %cv10220 = zext i32 %v10219 to i64
  %cond10221 = icmp ne i64 %cv10220, 0
  br i1 %cond10221, label %bb_rcgclear2245, label %bb_rcgcounted2245
bb_rcgcounted2245:
  %v10222 = load i64, ptr %slot1719, align 8
  %op10223 = sub i64 %v10222, 32
  store i64 %op10223, ptr %slot1725, align 8
  %v10224 = load i64, ptr %slot1719, align 8
  %p10225 = inttoptr i64 %v10224 to ptr
  %rgep10226 = getelementptr i8, ptr %p10225, i64 -32
  %ld10227 = load i64, ptr %rgep10226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10227, ptr %slot1726, align 8
  %v10228 = load i64, ptr %slot1726, align 8
  %op10229 = sub i64 %v10228, 1
  store i64 %op10229, ptr %slot1727, align 8
  %v10230 = load i64, ptr %slot1727, align 8
  %cmp10231 = icmp eq i64 %v10230, 0
  %cv10232 = zext i1 %cmp10231 to i32
  store i32 %cv10232, ptr %slot1728, align 8
  %v10233 = load i32, ptr %slot1728, align 8
  %cv10234 = zext i32 %v10233 to i64
  %cond10235 = icmp ne i64 %cv10234, 0
  br i1 %cond10235, label %bb_rcglast2245, label %bb_rcgdec2245
bb_rcglast2245:
  %v10236 = load i64, ptr %slot1719, align 8
  %op10237 = sub i64 %v10236, 24
  store i64 %op10237, ptr %slot1729, align 8
  %v10238 = load i64, ptr %slot1719, align 8
  %p10239 = inttoptr i64 %v10238 to ptr
  %rgep10240 = getelementptr i8, ptr %p10239, i64 -24
  %ld10241 = load i64, ptr %rgep10240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10241, ptr %slot1730, align 8
  %v10242 = load i64, ptr %slot1730, align 8
  %cmp10243 = icmp ne i64 %v10242, 0
  %cv10244 = zext i1 %cmp10243 to i32
  store i32 %cv10244, ptr %slot1731, align 8
  %v10245 = load i32, ptr %slot1731, align 8
  %cv10246 = zext i32 %v10245 to i64
  %cond10247 = icmp ne i64 %cv10246, 0
  br i1 %cond10247, label %bb_rcgdec2245, label %bb_rcgslow2245
bb_rcgslow2245:
  %v10248 = load i64, ptr %slot1718, align 8
  %v10249 = load i64, ptr %slot1701, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v10248, i64 %v10249) nomerge, !dbg !212
  br label %bb_rcgdone2245
bb_rcgdec2245:
  %v10250 = load i64, ptr %slot1727, align 8
  %v10251 = load i64, ptr %slot1719, align 8
  %p10252 = inttoptr i64 %v10251 to ptr
  %rgep10253 = getelementptr i8, ptr %p10252, i64 -32
  store i64 %v10250, ptr %rgep10253, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2245
bb_rcgclear2245:
  %v10254 = load i64, ptr %slot1701, align 8
  %p10255 = inttoptr i64 %v10254 to ptr
  store i64 0, ptr %p10255, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2245
bb_rcgdone2245:
  br label %bb_rcslotdone2214
bb_rcslotdone2214:
  %v10256 = load i64, ptr %slot5, align 8
  %p10257 = inttoptr i64 %v10256 to ptr
  %ld10258 = load i32, ptr %p10257, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10258, ptr %slot1732, align 8
  %v10259 = load i32, ptr %slot1732, align 8
  %cv10260 = zext i32 %v10259 to i64
  %cond10261 = icmp ne i64 %cv10260, 0
  br i1 %cond10261, label %bb_rcslotdrop2251, label %bb_rcslotdone2251
bb_rcslotdrop2251:
  %v10262 = load i64, ptr %slot5, align 8
  %p10263 = inttoptr i64 %v10262 to ptr
  store i32 0, ptr %p10263, align 4, !alias.scope !3, !noalias !4
  %v10264 = load i64, ptr %slot33, align 8
  store i64 %v10264, ptr %slot1733, align 8
  %v10265 = load i64, ptr %slot6, align 8
  %p10266 = inttoptr i64 %v10265 to ptr
  %ld10267 = load i32, ptr %p10266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10267, ptr %slot1734, align 8
  %v10268 = load i32, ptr %slot1734, align 8
  %op10269 = and i32 %v10268, 28
  store i32 %op10269, ptr %slot1735, align 8
  %v10270 = load i32, ptr %slot1735, align 8
  %cv10271 = zext i32 %v10270 to i64
  %cond10272 = icmp ne i64 %cv10271, 0
  br i1 %cond10272, label %bb_rcslotrole2251, label %bb_rcslotowner2251
bb_rcslotrole2251:
  %v10273 = load i64, ptr %slot99, align 8
  store i64 %v10273, ptr %slot1736, align 8
  %v10274 = load i64, ptr %slot1736, align 8
  %v10275 = load i64, ptr %slot1733, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v10274, i64 %v10275) nomerge, !dbg !212
  br label %bb_rcslotdone2251
bb_rcslotowner2251:
  %v10276 = load i64, ptr %slot99, align 8
  store i64 %v10276, ptr %slot1737, align 8
  %v10277 = load i64, ptr %slot1737, align 8
  %v10278 = load i64, ptr %slot1733, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v10277, i64 %v10278) nomerge, !dbg !212
  br label %bb_rcslotdone2251
bb_rcslotdone2251:
  %v10279 = load i64, ptr %slot1654, align 8
  %p10280 = inttoptr i64 %v10279 to ptr
  %ret10281 = load { i64, i64 }, ptr %p10280, align 8
  ret { i64, i64 } %ret10281
bb_i126:
  %v10282 = load i64, ptr %slot44, align 8
  %p10283 = inttoptr i64 %v10282 to ptr
  %ld10284 = load i64, ptr %p10283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10284, ptr %slot1738, align 8
  %v10285 = load i64, ptr %slot15, align 8
  %p10286 = inttoptr i64 %v10285 to ptr
  %ld10287 = load i32, ptr %p10286, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10287, ptr %slot1739, align 8
  %v10288 = load i64, ptr %slot16, align 8
  %p10289 = inttoptr i64 %v10288 to ptr
  %ld10290 = load i32, ptr %p10289, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10290, ptr %slot1740, align 8
  %v10291 = load i32, ptr %slot1740, align 8
  %op10292 = and i32 %v10291, 24
  store i32 %op10292, ptr %slot1740, align 8
  %v10293 = load i32, ptr %slot1740, align 8
  %cmp10294 = icmp eq i32 %v10293, 0
  %cv10295 = zext i1 %cmp10294 to i32
  store i32 %cv10295, ptr %slot1741, align 8
  %v10296 = load i32, ptr %slot1739, align 8
  %v10297 = load i32, ptr %slot1741, align 8
  %op10298 = and i32 %v10296, %v10297
  store i32 %op10298, ptr %slot1742, align 8
  %v10299 = load i32, ptr %slot1742, align 8
  %cv10300 = zext i32 %v10299 to i64
  %cond10301 = icmp ne i64 %cv10300, 0
  br i1 %cond10301, label %bb_rctake2268, label %bb_rccopy2268
bb_rctake2268:
  %v10302 = load i64, ptr %slot30, align 8
  store i64 %v10302, ptr %slot1743, align 8
  %v10303 = load i64, ptr %slot100, align 8
  store i64 %v10303, ptr %slot1744, align 8
  %v10304 = load i64, ptr %slot99, align 8
  %v10305 = load i64, ptr %slot1743, align 8
  %v10306 = load i64, ptr %slot1738, align 8
  %v10307 = load i64, ptr %slot1744, align 8
  %cv10308 = trunc i64 %v10307 to i32
  %call10309 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v10304, i64 %v10305, i64 %v10306, i32 %cv10308) nomerge, !dbg !214
  store i32 %call10309, ptr %slot1745, align 8
  %v10310 = load i32, ptr %slot1745, align 8
  %cv10311 = zext i32 %v10310 to i64
  %cond10312 = icmp ne i64 %cv10311, 0
  br i1 %cond10312, label %bb_rcsuccess2278, label %bb_rcfailure2278
bb_rcfailure2278:
  %v10313 = load i64, ptr %slot99, align 8
  %p10314 = inttoptr i64 %v10313 to ptr
  %call10315 = call i32 @myl_rc_take_failure(ptr %p10314) nomerge, !dbg !214
  store i32 %call10315, ptr %slot1746, align 8
  %v10316 = load i64, ptr %slot1, align 8
  %p10317 = inttoptr i64 %v10316 to ptr
  %v10318 = load i32, ptr %slot1746, align 8
  %call10319 = call i32 @myl_qbe_rc_status(ptr %p10317, i32 %v10318) nomerge, !dbg !214
  store i32 %call10319, ptr %slot1747, align 8
  br label %bb_failure
bb_rcsuccess2278:
  %v10320 = load i64, ptr %slot15, align 8
  %p10321 = inttoptr i64 %v10320 to ptr
  store i32 0, ptr %p10321, align 4, !alias.scope !3, !noalias !4
  %v10322 = load i64, ptr %slot22, align 8
  %p10323 = inttoptr i64 %v10322 to ptr
  store i32 2, ptr %p10323, align 4, !alias.scope !3, !noalias !4
  %v10324 = load i64, ptr %slot21, align 8
  %p10325 = inttoptr i64 %v10324 to ptr
  store i32 1, ptr %p10325, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2268
bb_rccopy2268:
  %v10326 = load i64, ptr %slot30, align 8
  store i64 %v10326, ptr %slot1748, align 8
  %v10327 = load i64, ptr %slot100, align 8
  store i64 %v10327, ptr %slot1749, align 8
  %v10328 = load i64, ptr %slot99, align 8
  %v10329 = load i64, ptr %slot1748, align 8
  %v10330 = load i64, ptr %slot1738, align 8
  %v10331 = load i64, ptr %slot1749, align 8
  %cv10332 = trunc i64 %v10331 to i32
  %call10333 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v10328, i64 %v10329, i64 %v10330, i32 %cv10332) nomerge, !dbg !214
  store i32 %call10333, ptr %slot1750, align 8
  %v10334 = load i32, ptr %slot1750, align 8
  %cv10335 = zext i32 %v10334 to i64
  %cond10336 = icmp ne i64 %cv10335, 0
  br i1 %cond10336, label %bb_rcsuccess2287, label %bb_rcfailure2287
bb_rcfailure2287:
  %v10337 = load i64, ptr %slot99, align 8
  %p10338 = inttoptr i64 %v10337 to ptr
  %call10339 = call i32 @myl_rc_take_failure(ptr %p10338) nomerge, !dbg !214
  store i32 %call10339, ptr %slot1751, align 8
  %v10340 = load i64, ptr %slot1, align 8
  %p10341 = inttoptr i64 %v10340 to ptr
  %v10342 = load i32, ptr %slot1751, align 8
  %call10343 = call i32 @myl_qbe_rc_status(ptr %p10341, i32 %v10342) nomerge, !dbg !214
  store i32 %call10343, ptr %slot1752, align 8
  br label %bb_failure
bb_rcsuccess2287:
  %v10344 = load i64, ptr %slot22, align 8
  %p10345 = inttoptr i64 %v10344 to ptr
  store i32 2, ptr %p10345, align 4, !alias.scope !3, !noalias !4
  %v10346 = load i64, ptr %slot21, align 8
  %p10347 = inttoptr i64 %v10346 to ptr
  store i32 1, ptr %p10347, align 4, !alias.scope !3, !noalias !4
  %v10348 = load i64, ptr %slot15, align 8
  %p10349 = inttoptr i64 %v10348 to ptr
  %ld10350 = load i32, ptr %p10349, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10350, ptr %slot1753, align 8
  %v10351 = load i32, ptr %slot1753, align 8
  %cv10352 = zext i32 %v10351 to i64
  %cond10353 = icmp ne i64 %cv10352, 0
  br i1 %cond10353, label %bb_rcslotdrop2294, label %bb_rcslotdone2294
bb_rcslotdrop2294:
  %v10354 = load i64, ptr %slot15, align 8
  %p10355 = inttoptr i64 %v10354 to ptr
  store i32 0, ptr %p10355, align 4, !alias.scope !3, !noalias !4
  %v10356 = load i64, ptr %slot24, align 8
  store i64 %v10356, ptr %slot1754, align 8
  %v10357 = load i64, ptr %slot16, align 8
  %p10358 = inttoptr i64 %v10357 to ptr
  %ld10359 = load i32, ptr %p10358, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10359, ptr %slot1755, align 8
  %v10360 = load i32, ptr %slot1755, align 8
  %op10361 = and i32 %v10360, 28
  store i32 %op10361, ptr %slot1756, align 8
  %v10362 = load i32, ptr %slot1756, align 8
  %cv10363 = zext i32 %v10362 to i64
  %cond10364 = icmp ne i64 %cv10363, 0
  br i1 %cond10364, label %bb_rcslotrole2294, label %bb_rcslotowner2294
bb_rcslotrole2294:
  %v10365 = load i64, ptr %slot99, align 8
  store i64 %v10365, ptr %slot1757, align 8
  %v10366 = load i64, ptr %slot1757, align 8
  %v10367 = load i64, ptr %slot1754, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v10366, i64 %v10367) nomerge, !dbg !214
  br label %bb_rcslotdone2294
bb_rcslotowner2294:
  %v10368 = load i64, ptr %slot99, align 8
  store i64 %v10368, ptr %slot1758, align 8
  %v10369 = load i64, ptr %slot1758, align 8
  %v10370 = load i64, ptr %slot1754, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v10369, i64 %v10370) nomerge, !dbg !214
  br label %bb_rcslotdone2294
bb_rcslotdone2294:
  br label %bb_rcprepared2268
bb_rcprepared2268:
  %v10371 = load i64, ptr %slot13, align 8
  %p10372 = inttoptr i64 %v10371 to ptr
  %ld10373 = load i32, ptr %p10372, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10373, ptr %slot1759, align 8
  %v10374 = load i32, ptr %slot1759, align 8
  %cv10375 = zext i32 %v10374 to i64
  %cond10376 = icmp ne i64 %cv10375, 0
  br i1 %cond10376, label %bb_rcslotdrop2304, label %bb_rcslotdone2304
bb_rcslotdrop2304:
  %v10377 = load i64, ptr %slot13, align 8
  %p10378 = inttoptr i64 %v10377 to ptr
  store i32 0, ptr %p10378, align 4, !alias.scope !3, !noalias !4
  %v10379 = load i64, ptr %slot42, align 8
  store i64 %v10379, ptr %slot1760, align 8
  %v10380 = load i64, ptr %slot14, align 8
  %p10381 = inttoptr i64 %v10380 to ptr
  %ld10382 = load i32, ptr %p10381, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10382, ptr %slot1761, align 8
  %v10383 = load i32, ptr %slot1761, align 8
  %op10384 = and i32 %v10383, 28
  store i32 %op10384, ptr %slot1762, align 8
  %v10385 = load i32, ptr %slot1762, align 8
  %cv10386 = zext i32 %v10385 to i64
  %cond10387 = icmp ne i64 %cv10386, 0
  br i1 %cond10387, label %bb_rcslotrole2304, label %bb_rcslotowner2304
bb_rcslotrole2304:
  %v10388 = load i64, ptr %slot99, align 8
  store i64 %v10388, ptr %slot1763, align 8
  %v10389 = load i64, ptr %slot1763, align 8
  %v10390 = load i64, ptr %slot1760, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v10389, i64 %v10390) nomerge, !dbg !214
  br label %bb_rcslotdone2304
bb_rcslotowner2304:
  %v10391 = load i64, ptr %slot99, align 8
  store i64 %v10391, ptr %slot1764, align 8
  %v10392 = load i64, ptr %slot1764, align 8
  %v10393 = load i64, ptr %slot1760, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v10392, i64 %v10393) nomerge, !dbg !214
  br label %bb_rcslotdone2304
bb_rcslotdone2304:
  %v10394 = load i64, ptr %slot42, align 8
  store i64 %v10394, ptr %slot1765, align 8
  %v10395 = load i64, ptr %slot30, align 8
  store i64 %v10395, ptr %slot1766, align 8
  %v10396 = load i64, ptr %slot1766, align 8
  %v10397 = load i64, ptr %slot1765, align 8
  %p10398 = inttoptr i64 %v10396 to ptr
  %p10399 = inttoptr i64 %v10397 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10399, ptr %p10398, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v10400 = load i64, ptr %slot21, align 8
  %p10401 = inttoptr i64 %v10400 to ptr
  store i32 0, ptr %p10401, align 4, !alias.scope !3, !noalias !4
  %v10402 = load i64, ptr %slot14, align 8
  %p10403 = inttoptr i64 %v10402 to ptr
  store i32 2, ptr %p10403, align 4, !alias.scope !3, !noalias !4
  %v10404 = load i64, ptr %slot22, align 8
  %p10405 = inttoptr i64 %v10404 to ptr
  %ld10406 = load i32, ptr %p10405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10406, ptr %slot1767, align 8
  %v10407 = load i32, ptr %slot1767, align 8
  %v10408 = load i64, ptr %slot14, align 8
  %p10409 = inttoptr i64 %v10408 to ptr
  store i32 %v10407, ptr %p10409, align 4, !alias.scope !3, !noalias !4
  %v10410 = load i64, ptr %slot13, align 8
  %p10411 = inttoptr i64 %v10410 to ptr
  store i32 1, ptr %p10411, align 4, !alias.scope !3, !noalias !4
  %v10412 = load i64, ptr %slot32, align 8
  %p10413 = inttoptr i64 %v10412 to ptr
  %ld10414 = load i64, ptr %p10413, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10414, ptr %slot1768, align 8
  %v10415 = load i64, ptr %slot1768, align 8
  %v10416 = load i64, ptr %slot44, align 8
  %p10417 = inttoptr i64 %v10416 to ptr
  store i64 %v10415, ptr %p10417, align 8, !alias.scope !3, !noalias !4
  %v10418 = load i64, ptr %slot41, align 8
  %v10419 = load i64, ptr %slot45, align 8
  %p10420 = inttoptr i64 %v10419 to ptr
  store i64 %v10418, ptr %p10420, align 8, !alias.scope !3, !noalias !4
  %v10421 = load i64, ptr %slot42, align 8
  %v10422 = load i64, ptr %slot46, align 8
  %p10423 = inttoptr i64 %v10422 to ptr
  store i64 %v10421, ptr %p10423, align 8, !alias.scope !3, !noalias !4
  %v10424 = load i64, ptr %slot32, align 8
  %p10425 = inttoptr i64 %v10424 to ptr
  %ld10426 = load i64, ptr %p10425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10426, ptr %slot1769, align 8
  %v10427 = load i64, ptr %slot1769, align 8
  %v10428 = load i64, ptr %slot47, align 8
  %p10429 = inttoptr i64 %v10428 to ptr
  store i64 %v10427, ptr %p10429, align 8, !alias.scope !3, !noalias !4
  %v10430 = load i64, ptr %slot42, align 8
  %v10431 = load i64, ptr %slot48, align 8
  %p10432 = inttoptr i64 %v10431 to ptr
  store i64 %v10430, ptr %p10432, align 8, !alias.scope !3, !noalias !4
  %v10433 = load i64, ptr %slot47, align 8
  %p10434 = inttoptr i64 %v10433 to ptr
  %ld10435 = load i64, ptr %p10434, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10435, ptr %slot1770, align 8
  %v10436 = load i64, ptr %slot48, align 8
  %p10437 = inttoptr i64 %v10436 to ptr
  %ld10438 = load i64, ptr %p10437, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10438, ptr %slot1771, align 8
  %v10439 = load i64, ptr %slot1, align 8
  %v10440 = load i64, ptr %slot1770, align 8
  %v10441 = load i64, ptr %slot1771, align 8
  %call10442 = call i64 @myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4(i64 %v10439, i64 %v10440, i64 %v10441) nomerge, !dbg !216
  store i64 %call10442, ptr %slot1772, align 8
  %v10443 = load i64, ptr %slot1772, align 8
  %v10444 = load i64, ptr %slot47, align 8
  %p10445 = inttoptr i64 %v10444 to ptr
  store i64 %v10443, ptr %p10445, align 8, !alias.scope !3, !noalias !4
  %v10446 = load i64, ptr %slot48, align 8
  %p10447 = inttoptr i64 %v10446 to ptr
  store i64 18446744073709551615, ptr %p10447, align 8, !alias.scope !3, !noalias !4
  %v10448 = load i64, ptr %slot49, align 8
  %p10449 = inttoptr i64 %v10448 to ptr
  store i64 0, ptr %p10449, align 8, !alias.scope !3, !noalias !4
  %v10450 = load i64, ptr %slot74, align 8
  store i64 %v10450, ptr %slot1773, align 8
  %v10451 = load i64, ptr %slot1773, align 8
  %p10452 = inttoptr i64 %v10451 to ptr
  call void @llvm.memset.p0.i64(ptr %p10452, i8 0, i64 104, i1 false), !alias.scope !3, !noalias !4, !dbg !218
  %v10453 = load i64, ptr %slot23, align 8
  %p10454 = inttoptr i64 %v10453 to ptr
  store i32 1, ptr %p10454, align 4, !alias.scope !3, !noalias !4
  %v10455 = load i64, ptr %slot100, align 8
  store i64 %v10455, ptr %slot1774, align 8
  %v10456 = load i64, ptr %slot45, align 8
  %p10457 = inttoptr i64 %v10456 to ptr
  %ld10458 = load i64, ptr %p10457, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10458, ptr %slot1775, align 8
  %v10459 = load i64, ptr %slot1773, align 8
  %p10461 = inttoptr i64 %v10459 to ptr
  %gep10462 = getelementptr i8, ptr %p10461, i64 0
  %op10460 = ptrtoint ptr %gep10462 to i64
  store i64 %op10460, ptr %slot1776, align 8
  %v10463 = load i64, ptr %slot45, align 8
  %p10464 = inttoptr i64 %v10463 to ptr
  %ld10465 = load i64, ptr %p10464, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10465, ptr %slot1777, align 8
  %v10466 = load i64, ptr %slot17, align 8
  %p10467 = inttoptr i64 %v10466 to ptr
  %ld10468 = load i32, ptr %p10467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10468, ptr %slot1778, align 8
  %v10469 = load i64, ptr %slot18, align 8
  %p10470 = inttoptr i64 %v10469 to ptr
  %ld10471 = load i32, ptr %p10470, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10471, ptr %slot1779, align 8
  %v10472 = load i32, ptr %slot1779, align 8
  %op10473 = and i32 %v10472, 24
  store i32 %op10473, ptr %slot1779, align 8
  %v10474 = load i32, ptr %slot1779, align 8
  %cmp10475 = icmp eq i32 %v10474, 0
  %cv10476 = zext i1 %cmp10475 to i32
  store i32 %cv10476, ptr %slot1780, align 8
  %v10477 = load i32, ptr %slot1778, align 8
  %v10478 = load i32, ptr %slot1780, align 8
  %op10479 = and i32 %v10477, %v10478
  store i32 %op10479, ptr %slot1781, align 8
  %v10480 = load i32, ptr %slot1781, align 8
  %cv10481 = zext i32 %v10480 to i64
  %cond10482 = icmp ne i64 %cv10481, 0
  br i1 %cond10482, label %bb_rctake2348, label %bb_rccopy2348
bb_rctake2348:
  %v10483 = load i64, ptr %slot30, align 8
  store i64 %v10483, ptr %slot1782, align 8
  %v10484 = load i64, ptr %slot100, align 8
  store i64 %v10484, ptr %slot1783, align 8
  %v10485 = load i64, ptr %slot99, align 8
  %v10486 = load i64, ptr %slot1782, align 8
  %v10487 = load i64, ptr %slot1777, align 8
  %v10488 = load i64, ptr %slot1783, align 8
  %cv10489 = trunc i64 %v10488 to i32
  %call10490 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v10485, i64 %v10486, i64 %v10487, i32 %cv10489) nomerge, !dbg !218
  store i32 %call10490, ptr %slot1784, align 8
  %v10491 = load i32, ptr %slot1784, align 8
  %cv10492 = zext i32 %v10491 to i64
  %cond10493 = icmp ne i64 %cv10492, 0
  br i1 %cond10493, label %bb_rcsuccess2358, label %bb_rcfailure2358
bb_rcfailure2358:
  %v10494 = load i64, ptr %slot99, align 8
  %p10495 = inttoptr i64 %v10494 to ptr
  %call10496 = call i32 @myl_rc_take_failure(ptr %p10495) nomerge, !dbg !218
  store i32 %call10496, ptr %slot1785, align 8
  %v10497 = load i64, ptr %slot1, align 8
  %p10498 = inttoptr i64 %v10497 to ptr
  %v10499 = load i32, ptr %slot1785, align 8
  %call10500 = call i32 @myl_qbe_rc_status(ptr %p10498, i32 %v10499) nomerge, !dbg !218
  store i32 %call10500, ptr %slot1786, align 8
  br label %bb_failure
bb_rcsuccess2358:
  %v10501 = load i64, ptr %slot17, align 8
  %p10502 = inttoptr i64 %v10501 to ptr
  store i32 0, ptr %p10502, align 4, !alias.scope !3, !noalias !4
  %v10503 = load i64, ptr %slot22, align 8
  %p10504 = inttoptr i64 %v10503 to ptr
  store i32 2, ptr %p10504, align 4, !alias.scope !3, !noalias !4
  %v10505 = load i64, ptr %slot21, align 8
  %p10506 = inttoptr i64 %v10505 to ptr
  store i32 1, ptr %p10506, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2348
bb_rccopy2348:
  %v10507 = load i64, ptr %slot30, align 8
  store i64 %v10507, ptr %slot1787, align 8
  %v10508 = load i64, ptr %slot100, align 8
  store i64 %v10508, ptr %slot1788, align 8
  %v10509 = load i64, ptr %slot99, align 8
  %v10510 = load i64, ptr %slot1787, align 8
  %v10511 = load i64, ptr %slot1777, align 8
  %v10512 = load i64, ptr %slot1788, align 8
  %cv10513 = trunc i64 %v10512 to i32
  %call10514 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v10509, i64 %v10510, i64 %v10511, i32 %cv10513) nomerge, !dbg !218
  store i32 %call10514, ptr %slot1789, align 8
  %v10515 = load i32, ptr %slot1789, align 8
  %cv10516 = zext i32 %v10515 to i64
  %cond10517 = icmp ne i64 %cv10516, 0
  br i1 %cond10517, label %bb_rcsuccess2367, label %bb_rcfailure2367
bb_rcfailure2367:
  %v10518 = load i64, ptr %slot99, align 8
  %p10519 = inttoptr i64 %v10518 to ptr
  %call10520 = call i32 @myl_rc_take_failure(ptr %p10519) nomerge, !dbg !218
  store i32 %call10520, ptr %slot1790, align 8
  %v10521 = load i64, ptr %slot1, align 8
  %p10522 = inttoptr i64 %v10521 to ptr
  %v10523 = load i32, ptr %slot1790, align 8
  %call10524 = call i32 @myl_qbe_rc_status(ptr %p10522, i32 %v10523) nomerge, !dbg !218
  store i32 %call10524, ptr %slot1791, align 8
  br label %bb_failure
bb_rcsuccess2367:
  %v10525 = load i64, ptr %slot22, align 8
  %p10526 = inttoptr i64 %v10525 to ptr
  store i32 2, ptr %p10526, align 4, !alias.scope !3, !noalias !4
  %v10527 = load i64, ptr %slot21, align 8
  %p10528 = inttoptr i64 %v10527 to ptr
  store i32 1, ptr %p10528, align 4, !alias.scope !3, !noalias !4
  %v10529 = load i64, ptr %slot17, align 8
  %p10530 = inttoptr i64 %v10529 to ptr
  %ld10531 = load i32, ptr %p10530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10531, ptr %slot1792, align 8
  %v10532 = load i32, ptr %slot1792, align 8
  %cv10533 = zext i32 %v10532 to i64
  %cond10534 = icmp ne i64 %cv10533, 0
  br i1 %cond10534, label %bb_rcslotdrop2374, label %bb_rcslotdone2374
bb_rcslotdrop2374:
  %v10535 = load i64, ptr %slot17, align 8
  %p10536 = inttoptr i64 %v10535 to ptr
  store i32 0, ptr %p10536, align 4, !alias.scope !3, !noalias !4
  %v10537 = load i64, ptr %slot25, align 8
  store i64 %v10537, ptr %slot1793, align 8
  %v10538 = load i64, ptr %slot18, align 8
  %p10539 = inttoptr i64 %v10538 to ptr
  %ld10540 = load i32, ptr %p10539, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10540, ptr %slot1794, align 8
  %v10541 = load i32, ptr %slot1794, align 8
  %op10542 = and i32 %v10541, 28
  store i32 %op10542, ptr %slot1795, align 8
  %v10543 = load i32, ptr %slot1795, align 8
  %cv10544 = zext i32 %v10543 to i64
  %cond10545 = icmp ne i64 %cv10544, 0
  br i1 %cond10545, label %bb_rcslotrole2374, label %bb_rcslotowner2374
bb_rcslotrole2374:
  %v10546 = load i64, ptr %slot99, align 8
  store i64 %v10546, ptr %slot1796, align 8
  %v10547 = load i64, ptr %slot1796, align 8
  %v10548 = load i64, ptr %slot1793, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v10547, i64 %v10548) nomerge, !dbg !218
  br label %bb_rcslotdone2374
bb_rcslotowner2374:
  %v10549 = load i64, ptr %slot99, align 8
  store i64 %v10549, ptr %slot1797, align 8
  %v10550 = load i64, ptr %slot1797, align 8
  %v10551 = load i64, ptr %slot1793, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v10550, i64 %v10551) nomerge, !dbg !218
  br label %bb_rcslotdone2374
bb_rcslotdone2374:
  br label %bb_rcprepared2348
bb_rcprepared2348:
  %v10552 = load i64, ptr %slot30, align 8
  store i64 %v10552, ptr %slot1798, align 8
  %v10553 = load i64, ptr %slot1798, align 8
  %v10554 = load i64, ptr %slot1776, align 8
  %p10555 = inttoptr i64 %v10553 to ptr
  %p10556 = inttoptr i64 %v10554 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10556, ptr %p10555, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v10557 = load i64, ptr %slot21, align 8
  %p10558 = inttoptr i64 %v10557 to ptr
  store i32 0, ptr %p10558, align 4, !alias.scope !3, !noalias !4
  %v10559 = load i64, ptr %slot46, align 8
  %p10560 = inttoptr i64 %v10559 to ptr
  %ld10561 = load i64, ptr %p10560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10561, ptr %slot1799, align 8
  %v10562 = load i64, ptr %slot1773, align 8
  %p10564 = inttoptr i64 %v10562 to ptr
  %gep10565 = getelementptr i8, ptr %p10564, i64 40
  %op10563 = ptrtoint ptr %gep10565 to i64
  store i64 %op10563, ptr %slot1800, align 8
  %v10566 = load i64, ptr %slot46, align 8
  %p10567 = inttoptr i64 %v10566 to ptr
  %ld10568 = load i64, ptr %p10567, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10568, ptr %slot1801, align 8
  %v10569 = load i64, ptr %slot19, align 8
  %p10570 = inttoptr i64 %v10569 to ptr
  %ld10571 = load i32, ptr %p10570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10571, ptr %slot1802, align 8
  %v10572 = load i64, ptr %slot20, align 8
  %p10573 = inttoptr i64 %v10572 to ptr
  %ld10574 = load i32, ptr %p10573, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10574, ptr %slot1803, align 8
  %v10575 = load i32, ptr %slot1803, align 8
  %op10576 = and i32 %v10575, 24
  store i32 %op10576, ptr %slot1803, align 8
  %v10577 = load i32, ptr %slot1803, align 8
  %cmp10578 = icmp eq i32 %v10577, 0
  %cv10579 = zext i1 %cmp10578 to i32
  store i32 %cv10579, ptr %slot1804, align 8
  %v10580 = load i32, ptr %slot1802, align 8
  %v10581 = load i32, ptr %slot1804, align 8
  %op10582 = and i32 %v10580, %v10581
  store i32 %op10582, ptr %slot1805, align 8
  %v10583 = load i32, ptr %slot1805, align 8
  %cv10584 = zext i32 %v10583 to i64
  %cond10585 = icmp ne i64 %cv10584, 0
  br i1 %cond10585, label %bb_rctake2386, label %bb_rccopy2386
bb_rctake2386:
  %v10586 = load i64, ptr %slot30, align 8
  store i64 %v10586, ptr %slot1806, align 8
  %v10587 = load i64, ptr %slot100, align 8
  store i64 %v10587, ptr %slot1807, align 8
  %v10588 = load i64, ptr %slot99, align 8
  %v10589 = load i64, ptr %slot1806, align 8
  %v10590 = load i64, ptr %slot1801, align 8
  %v10591 = load i64, ptr %slot1807, align 8
  %cv10592 = trunc i64 %v10591 to i32
  %call10593 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v10588, i64 %v10589, i64 %v10590, i32 %cv10592) nomerge, !dbg !218
  store i32 %call10593, ptr %slot1808, align 8
  %v10594 = load i32, ptr %slot1808, align 8
  %cv10595 = zext i32 %v10594 to i64
  %cond10596 = icmp ne i64 %cv10595, 0
  br i1 %cond10596, label %bb_rcsuccess2396, label %bb_rcfailure2396
bb_rcfailure2396:
  %v10597 = load i64, ptr %slot99, align 8
  %p10598 = inttoptr i64 %v10597 to ptr
  %call10599 = call i32 @myl_rc_take_failure(ptr %p10598) nomerge, !dbg !218
  store i32 %call10599, ptr %slot1809, align 8
  %v10600 = load i64, ptr %slot1, align 8
  %p10601 = inttoptr i64 %v10600 to ptr
  %v10602 = load i32, ptr %slot1809, align 8
  %call10603 = call i32 @myl_qbe_rc_status(ptr %p10601, i32 %v10602) nomerge, !dbg !218
  store i32 %call10603, ptr %slot1810, align 8
  br label %bb_failure
bb_rcsuccess2396:
  %v10604 = load i64, ptr %slot19, align 8
  %p10605 = inttoptr i64 %v10604 to ptr
  store i32 0, ptr %p10605, align 4, !alias.scope !3, !noalias !4
  %v10606 = load i64, ptr %slot22, align 8
  %p10607 = inttoptr i64 %v10606 to ptr
  store i32 2, ptr %p10607, align 4, !alias.scope !3, !noalias !4
  %v10608 = load i64, ptr %slot21, align 8
  %p10609 = inttoptr i64 %v10608 to ptr
  store i32 1, ptr %p10609, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2386
bb_rccopy2386:
  %v10610 = load i64, ptr %slot30, align 8
  store i64 %v10610, ptr %slot1811, align 8
  %v10611 = load i64, ptr %slot100, align 8
  store i64 %v10611, ptr %slot1812, align 8
  %v10612 = load i64, ptr %slot99, align 8
  %v10613 = load i64, ptr %slot1811, align 8
  %v10614 = load i64, ptr %slot1801, align 8
  %v10615 = load i64, ptr %slot1812, align 8
  %cv10616 = trunc i64 %v10615 to i32
  %call10617 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v10612, i64 %v10613, i64 %v10614, i32 %cv10616) nomerge, !dbg !218
  store i32 %call10617, ptr %slot1813, align 8
  %v10618 = load i32, ptr %slot1813, align 8
  %cv10619 = zext i32 %v10618 to i64
  %cond10620 = icmp ne i64 %cv10619, 0
  br i1 %cond10620, label %bb_rcsuccess2405, label %bb_rcfailure2405
bb_rcfailure2405:
  %v10621 = load i64, ptr %slot99, align 8
  %p10622 = inttoptr i64 %v10621 to ptr
  %call10623 = call i32 @myl_rc_take_failure(ptr %p10622) nomerge, !dbg !218
  store i32 %call10623, ptr %slot1814, align 8
  %v10624 = load i64, ptr %slot1, align 8
  %p10625 = inttoptr i64 %v10624 to ptr
  %v10626 = load i32, ptr %slot1814, align 8
  %call10627 = call i32 @myl_qbe_rc_status(ptr %p10625, i32 %v10626) nomerge, !dbg !218
  store i32 %call10627, ptr %slot1815, align 8
  br label %bb_failure
bb_rcsuccess2405:
  %v10628 = load i64, ptr %slot22, align 8
  %p10629 = inttoptr i64 %v10628 to ptr
  store i32 2, ptr %p10629, align 4, !alias.scope !3, !noalias !4
  %v10630 = load i64, ptr %slot21, align 8
  %p10631 = inttoptr i64 %v10630 to ptr
  store i32 1, ptr %p10631, align 4, !alias.scope !3, !noalias !4
  %v10632 = load i64, ptr %slot19, align 8
  %p10633 = inttoptr i64 %v10632 to ptr
  %ld10634 = load i32, ptr %p10633, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10634, ptr %slot1816, align 8
  %v10635 = load i32, ptr %slot1816, align 8
  %cv10636 = zext i32 %v10635 to i64
  %cond10637 = icmp ne i64 %cv10636, 0
  br i1 %cond10637, label %bb_rcslotdrop2412, label %bb_rcslotdone2412
bb_rcslotdrop2412:
  %v10638 = load i64, ptr %slot19, align 8
  %p10639 = inttoptr i64 %v10638 to ptr
  store i32 0, ptr %p10639, align 4, !alias.scope !3, !noalias !4
  %v10640 = load i64, ptr %slot26, align 8
  store i64 %v10640, ptr %slot1817, align 8
  %v10641 = load i64, ptr %slot20, align 8
  %p10642 = inttoptr i64 %v10641 to ptr
  %ld10643 = load i32, ptr %p10642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10643, ptr %slot1818, align 8
  %v10644 = load i32, ptr %slot1818, align 8
  %op10645 = and i32 %v10644, 28
  store i32 %op10645, ptr %slot1819, align 8
  %v10646 = load i32, ptr %slot1819, align 8
  %cv10647 = zext i32 %v10646 to i64
  %cond10648 = icmp ne i64 %cv10647, 0
  br i1 %cond10648, label %bb_rcslotrole2412, label %bb_rcslotowner2412
bb_rcslotrole2412:
  %v10649 = load i64, ptr %slot99, align 8
  store i64 %v10649, ptr %slot1820, align 8
  %v10650 = load i64, ptr %slot1820, align 8
  %v10651 = load i64, ptr %slot1817, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v10650, i64 %v10651) nomerge, !dbg !218
  br label %bb_rcslotdone2412
bb_rcslotowner2412:
  %v10652 = load i64, ptr %slot99, align 8
  store i64 %v10652, ptr %slot1821, align 8
  %v10653 = load i64, ptr %slot1821, align 8
  %v10654 = load i64, ptr %slot1817, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v10653, i64 %v10654) nomerge, !dbg !218
  br label %bb_rcslotdone2412
bb_rcslotdone2412:
  br label %bb_rcprepared2386
bb_rcprepared2386:
  %v10655 = load i64, ptr %slot30, align 8
  store i64 %v10655, ptr %slot1822, align 8
  %v10656 = load i64, ptr %slot1822, align 8
  %v10657 = load i64, ptr %slot1800, align 8
  %p10658 = inttoptr i64 %v10656 to ptr
  %p10659 = inttoptr i64 %v10657 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10659, ptr %p10658, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v10660 = load i64, ptr %slot21, align 8
  %p10661 = inttoptr i64 %v10660 to ptr
  store i32 0, ptr %p10661, align 4, !alias.scope !3, !noalias !4
  %v10662 = load i64, ptr %slot47, align 8
  store i64 %v10662, ptr %slot1823, align 8
  %v10663 = load i64, ptr %slot1773, align 8
  %p10665 = inttoptr i64 %v10663 to ptr
  %gep10666 = getelementptr i8, ptr %p10665, i64 80
  %op10664 = ptrtoint ptr %gep10666 to i64
  store i64 %op10664, ptr %slot1824, align 8
  %v10667 = load i64, ptr %slot1823, align 8
  %p10668 = inttoptr i64 %v10667 to ptr
  %ld10669 = load i64, ptr %p10668, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10669, ptr %slot1825, align 8
  %v10670 = load i64, ptr %slot1825, align 8
  %v10671 = load i64, ptr %slot1824, align 8
  %p10672 = inttoptr i64 %v10671 to ptr
  store i64 %v10670, ptr %p10672, align 8, !alias.scope !3, !noalias !4
  %v10673 = load i64, ptr %slot48, align 8
  store i64 %v10673, ptr %slot1826, align 8
  %v10674 = load i64, ptr %slot1773, align 8
  %p10676 = inttoptr i64 %v10674 to ptr
  %gep10677 = getelementptr i8, ptr %p10676, i64 88
  %op10675 = ptrtoint ptr %gep10677 to i64
  store i64 %op10675, ptr %slot1827, align 8
  %v10678 = load i64, ptr %slot1826, align 8
  %p10679 = inttoptr i64 %v10678 to ptr
  %ld10680 = load i64, ptr %p10679, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10680, ptr %slot1828, align 8
  %v10681 = load i64, ptr %slot1828, align 8
  %v10682 = load i64, ptr %slot1827, align 8
  %p10683 = inttoptr i64 %v10682 to ptr
  store i64 %v10681, ptr %p10683, align 8, !alias.scope !3, !noalias !4
  %v10684 = load i64, ptr %slot49, align 8
  store i64 %v10684, ptr %slot1829, align 8
  %v10685 = load i64, ptr %slot1773, align 8
  %p10687 = inttoptr i64 %v10685 to ptr
  %gep10688 = getelementptr i8, ptr %p10687, i64 96
  %op10686 = ptrtoint ptr %gep10688 to i64
  store i64 %op10686, ptr %slot1830, align 8
  %v10689 = load i64, ptr %slot1829, align 8
  %p10690 = inttoptr i64 %v10689 to ptr
  %ld10691 = load i64, ptr %p10690, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10691, ptr %slot1831, align 8
  %v10692 = load i64, ptr %slot1831, align 8
  %v10693 = load i64, ptr %slot1830, align 8
  %p10694 = inttoptr i64 %v10693 to ptr
  store i64 %v10692, ptr %p10694, align 8, !alias.scope !3, !noalias !4
  %v10695 = load i64, ptr %slot1773, align 8
  %v10696 = load i64, ptr %slot45, align 8
  %p10697 = inttoptr i64 %v10696 to ptr
  store i64 %v10695, ptr %p10697, align 8, !alias.scope !3, !noalias !4
  %v10698 = load i64, ptr %slot45, align 8
  %p10699 = inttoptr i64 %v10698 to ptr
  %ld10700 = load i64, ptr %p10699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10700, ptr %slot1832, align 8
  %v10701 = load i64, ptr %slot25, align 8
  store i64 %v10701, ptr %slot1833, align 8
  %v10702 = load i64, ptr %slot1832, align 8
  %v10703 = load i64, ptr %slot1833, align 8
  %p10704 = inttoptr i64 %v10702 to ptr
  %p10705 = inttoptr i64 %v10703 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10705, ptr %p10704, i64 104, i1 false)
  %v10706 = load i64, ptr %slot18, align 8
  %p10707 = inttoptr i64 %v10706 to ptr
  store i32 2, ptr %p10707, align 4, !alias.scope !3, !noalias !4
  %v10708 = load i64, ptr %slot17, align 8
  %p10709 = inttoptr i64 %v10708 to ptr
  store i32 1, ptr %p10709, align 4, !alias.scope !3, !noalias !4
  %v10710 = load i64, ptr %slot1833, align 8
  %v10711 = load i64, ptr %slot45, align 8
  %p10712 = inttoptr i64 %v10711 to ptr
  store i64 %v10710, ptr %p10712, align 8, !alias.scope !3, !noalias !4
  %v10713 = load i64, ptr %slot75, align 8
  store i64 %v10713, ptr %slot1834, align 8
  %v10714 = load i64, ptr %slot1834, align 8
  %p10715 = inttoptr i64 %v10714 to ptr
  call void @llvm.memset.p0.i64(ptr %p10715, i8 0, i64 112, i1 false), !alias.scope !3, !noalias !4, !dbg !220
  %v10716 = load i64, ptr %slot1834, align 8
  %p10717 = inttoptr i64 %v10716 to ptr
  store i32 8, ptr %p10717, align 4, !alias.scope !3, !noalias !4
  %v10718 = load i64, ptr %slot23, align 8
  %p10719 = inttoptr i64 %v10718 to ptr
  store i32 1, ptr %p10719, align 4, !alias.scope !3, !noalias !4
  %v10720 = load i64, ptr %slot45, align 8
  %p10721 = inttoptr i64 %v10720 to ptr
  %ld10722 = load i64, ptr %p10721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10722, ptr %slot1835, align 8
  %v10723 = load i64, ptr %slot1834, align 8
  %p10725 = inttoptr i64 %v10723 to ptr
  %gep10726 = getelementptr i8, ptr %p10725, i64 8
  %op10724 = ptrtoint ptr %gep10726 to i64
  store i64 %op10724, ptr %slot1836, align 8
  %v10727 = load i64, ptr %slot100, align 8
  store i64 %v10727, ptr %slot1837, align 8
  %v10728 = load i64, ptr %slot45, align 8
  %p10729 = inttoptr i64 %v10728 to ptr
  %ld10730 = load i64, ptr %p10729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10730, ptr %slot1838, align 8
  %v10731 = load i64, ptr %slot30, align 8
  store i64 %v10731, ptr %slot1839, align 8
  %v10732 = load i64, ptr %slot100, align 8
  store i64 %v10732, ptr %slot1840, align 8
  %v10733 = load i64, ptr %slot99, align 8
  %v10734 = load i64, ptr %slot1839, align 8
  %v10735 = load i64, ptr %slot1838, align 8
  %v10736 = load i64, ptr %slot1840, align 8
  %cv10737 = trunc i64 %v10736 to i32
  %call10738 = call i32 @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_take(i64 %v10733, i64 %v10734, i64 %v10735, i32 %cv10737) nomerge, !dbg !220
  store i32 %call10738, ptr %slot1841, align 8
  %v10739 = load i32, ptr %slot1841, align 8
  %cv10740 = zext i32 %v10739 to i64
  %cond10741 = icmp ne i64 %cv10740, 0
  br i1 %cond10741, label %bb_rcsuccess2444, label %bb_rcfailure2444
bb_rcfailure2444:
  %v10742 = load i64, ptr %slot99, align 8
  %p10743 = inttoptr i64 %v10742 to ptr
  %call10744 = call i32 @myl_rc_take_failure(ptr %p10743) nomerge, !dbg !220
  store i32 %call10744, ptr %slot1842, align 8
  %v10745 = load i64, ptr %slot1, align 8
  %p10746 = inttoptr i64 %v10745 to ptr
  %v10747 = load i32, ptr %slot1842, align 8
  %call10748 = call i32 @myl_qbe_rc_status(ptr %p10746, i32 %v10747) nomerge, !dbg !220
  store i32 %call10748, ptr %slot1843, align 8
  br label %bb_failure
bb_rcsuccess2444:
  %v10749 = load i64, ptr %slot17, align 8
  %p10750 = inttoptr i64 %v10749 to ptr
  store i32 0, ptr %p10750, align 4, !alias.scope !3, !noalias !4
  %v10751 = load i64, ptr %slot22, align 8
  %p10752 = inttoptr i64 %v10751 to ptr
  store i32 2, ptr %p10752, align 4, !alias.scope !3, !noalias !4
  %v10753 = load i64, ptr %slot21, align 8
  %p10754 = inttoptr i64 %v10753 to ptr
  store i32 1, ptr %p10754, align 4, !alias.scope !3, !noalias !4
  %v10755 = load i64, ptr %slot30, align 8
  store i64 %v10755, ptr %slot1844, align 8
  %v10756 = load i64, ptr %slot1844, align 8
  %v10757 = load i64, ptr %slot1836, align 8
  %p10758 = inttoptr i64 %v10756 to ptr
  %p10759 = inttoptr i64 %v10757 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10759, ptr %p10758, i64 104, i1 false), !alias.scope !3, !noalias !4
  %v10760 = load i64, ptr %slot21, align 8
  %p10761 = inttoptr i64 %v10760 to ptr
  store i32 0, ptr %p10761, align 4, !alias.scope !3, !noalias !4
  %v10762 = load i64, ptr %slot1834, align 8
  %v10763 = load i64, ptr %slot45, align 8
  %p10764 = inttoptr i64 %v10763 to ptr
  store i64 %v10762, ptr %p10764, align 8, !alias.scope !3, !noalias !4
  %v10765 = load i64, ptr %slot45, align 8
  %p10766 = inttoptr i64 %v10765 to ptr
  %ld10767 = load i64, ptr %p10766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10767, ptr %slot1845, align 8
  %v10768 = load i64, ptr %slot25, align 8
  store i64 %v10768, ptr %slot1846, align 8
  %v10769 = load i64, ptr %slot1845, align 8
  %v10770 = load i64, ptr %slot1846, align 8
  %p10771 = inttoptr i64 %v10769 to ptr
  %p10772 = inttoptr i64 %v10770 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10772, ptr %p10771, i64 112, i1 false)
  %v10773 = load i64, ptr %slot18, align 8
  %p10774 = inttoptr i64 %v10773 to ptr
  store i32 2, ptr %p10774, align 4, !alias.scope !3, !noalias !4
  %v10775 = load i64, ptr %slot17, align 8
  %p10776 = inttoptr i64 %v10775 to ptr
  store i32 1, ptr %p10776, align 4, !alias.scope !3, !noalias !4
  %v10777 = load i64, ptr %slot1846, align 8
  %v10778 = load i64, ptr %slot45, align 8
  %p10779 = inttoptr i64 %v10778 to ptr
  store i64 %v10777, ptr %p10779, align 8, !alias.scope !3, !noalias !4
  %v10780 = load i64, ptr %slot44, align 8
  %p10781 = inttoptr i64 %v10780 to ptr
  %ld10782 = load i64, ptr %p10781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10782, ptr %slot1847, align 8
  %v10783 = load i64, ptr %slot45, align 8
  %p10784 = inttoptr i64 %v10783 to ptr
  %ld10785 = load i64, ptr %p10784, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10785, ptr %slot1848, align 8
  %v10786 = load i64, ptr %slot1, align 8
  %v10787 = load i64, ptr %slot1847, align 8
  %v10788 = load i64, ptr %slot1848, align 8
  %call10789 = call i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64 %v10786, i64 %v10787, i64 %v10788) nomerge, !dbg !222
  store i64 %call10789, ptr %slot1849, align 8
  %v10790 = load i64, ptr %slot1849, align 8
  %v10791 = load i64, ptr %slot44, align 8
  %p10792 = inttoptr i64 %v10791 to ptr
  store i64 %v10790, ptr %p10792, align 8, !alias.scope !3, !noalias !4
  %v10793 = load i64, ptr %slot15, align 8
  %p10794 = inttoptr i64 %v10793 to ptr
  %ld10795 = load i32, ptr %p10794, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10795, ptr %slot1850, align 8
  %v10796 = load i32, ptr %slot1850, align 8
  %cv10797 = zext i32 %v10796 to i64
  %cond10798 = icmp ne i64 %cv10797, 0
  br i1 %cond10798, label %bb_rcslotdrop2461, label %bb_rcslotdone2461
bb_rcslotdrop2461:
  %v10799 = load i64, ptr %slot15, align 8
  %p10800 = inttoptr i64 %v10799 to ptr
  store i32 0, ptr %p10800, align 4, !alias.scope !3, !noalias !4
  %v10801 = load i64, ptr %slot24, align 8
  store i64 %v10801, ptr %slot1851, align 8
  %v10802 = load i64, ptr %slot16, align 8
  %p10803 = inttoptr i64 %v10802 to ptr
  %ld10804 = load i32, ptr %p10803, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10804, ptr %slot1852, align 8
  %v10805 = load i32, ptr %slot1852, align 8
  %op10806 = and i32 %v10805, 28
  store i32 %op10806, ptr %slot1853, align 8
  %v10807 = load i32, ptr %slot1853, align 8
  %cv10808 = zext i32 %v10807 to i64
  %cond10809 = icmp ne i64 %cv10808, 0
  br i1 %cond10809, label %bb_rcslotrole2461, label %bb_rcslotowner2461
bb_rcslotrole2461:
  %v10810 = load i64, ptr %slot99, align 8
  store i64 %v10810, ptr %slot1854, align 8
  %v10811 = load i64, ptr %slot1854, align 8
  %v10812 = load i64, ptr %slot1851, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v10811, i64 %v10812) nomerge, !dbg !222
  br label %bb_rcslotdone2461
bb_rcslotowner2461:
  %v10813 = load i64, ptr %slot99, align 8
  store i64 %v10813, ptr %slot1855, align 8
  %v10814 = load i64, ptr %slot1855, align 8
  %v10815 = load i64, ptr %slot1851, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v10814, i64 %v10815) nomerge, !dbg !222
  br label %bb_rcslotdone2461
bb_rcslotdone2461:
  %v10816 = load i64, ptr %slot17, align 8
  %p10817 = inttoptr i64 %v10816 to ptr
  %ld10818 = load i32, ptr %p10817, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10818, ptr %slot1856, align 8
  %v10819 = load i32, ptr %slot1856, align 8
  %cv10820 = zext i32 %v10819 to i64
  %cond10821 = icmp ne i64 %cv10820, 0
  br i1 %cond10821, label %bb_rcslotdrop2470, label %bb_rcslotdone2470
bb_rcslotdrop2470:
  %v10822 = load i64, ptr %slot17, align 8
  %p10823 = inttoptr i64 %v10822 to ptr
  store i32 0, ptr %p10823, align 4, !alias.scope !3, !noalias !4
  %v10824 = load i64, ptr %slot25, align 8
  store i64 %v10824, ptr %slot1857, align 8
  %v10825 = load i64, ptr %slot18, align 8
  %p10826 = inttoptr i64 %v10825 to ptr
  %ld10827 = load i32, ptr %p10826, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10827, ptr %slot1858, align 8
  %v10828 = load i32, ptr %slot1858, align 8
  %op10829 = and i32 %v10828, 28
  store i32 %op10829, ptr %slot1859, align 8
  %v10830 = load i32, ptr %slot1859, align 8
  %cv10831 = zext i32 %v10830 to i64
  %cond10832 = icmp ne i64 %cv10831, 0
  br i1 %cond10832, label %bb_rcslotrole2470, label %bb_rcslotowner2470
bb_rcslotrole2470:
  %v10833 = load i64, ptr %slot99, align 8
  store i64 %v10833, ptr %slot1860, align 8
  %v10834 = load i64, ptr %slot1860, align 8
  %v10835 = load i64, ptr %slot1857, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v10834, i64 %v10835) nomerge, !dbg !222
  br label %bb_rcslotdone2470
bb_rcslotowner2470:
  %v10836 = load i64, ptr %slot99, align 8
  store i64 %v10836, ptr %slot1861, align 8
  %v10837 = load i64, ptr %slot1861, align 8
  %v10838 = load i64, ptr %slot1857, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v10837, i64 %v10838) nomerge, !dbg !222
  br label %bb_rcslotdone2470
bb_rcslotdone2470:
  %v10839 = load i64, ptr %slot76, align 8
  store i64 %v10839, ptr %slot1862, align 8
  %v10840 = load i64, ptr %slot1862, align 8
  %p10841 = inttoptr i64 %v10840 to ptr
  store i64 0, ptr %p10841, align 8, !alias.scope !3, !noalias !4
  %v10842 = load i64, ptr %slot1862, align 8
  %p10844 = inttoptr i64 %v10842 to ptr
  %gep10845 = getelementptr i8, ptr %p10844, i64 8
  %op10843 = ptrtoint ptr %gep10845 to i64
  store i64 %op10843, ptr %slot1863, align 8
  %v10846 = load i64, ptr %slot1863, align 8
  %p10847 = inttoptr i64 %v10846 to ptr
  store i64 0, ptr %p10847, align 8, !alias.scope !3, !noalias !4
  %v10848 = load i64, ptr %slot1862, align 8
  %p10849 = inttoptr i64 %v10848 to ptr
  store i32 0, ptr %p10849, align 4, !alias.scope !3, !noalias !4
  %v10850 = load i64, ptr %slot23, align 8
  %p10851 = inttoptr i64 %v10850 to ptr
  store i32 1, ptr %p10851, align 4, !alias.scope !3, !noalias !4
  %v10852 = load i64, ptr %slot44, align 8
  store i64 %v10852, ptr %slot1864, align 8
  %v10853 = load i64, ptr %slot1862, align 8
  %p10855 = inttoptr i64 %v10853 to ptr
  %gep10856 = getelementptr i8, ptr %p10855, i64 8
  %op10854 = ptrtoint ptr %gep10856 to i64
  store i64 %op10854, ptr %slot1865, align 8
  %v10857 = load i64, ptr %slot100, align 8
  store i64 %v10857, ptr %slot1866, align 8
  %v10858 = load i64, ptr %slot1864, align 8
  %p10859 = inttoptr i64 %v10858 to ptr
  %ld10860 = load i64, ptr %p10859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10860, ptr %slot1867, align 8
  %v10861 = load i64, ptr %slot1867, align 8
  %v10862 = load i64, ptr %slot1865, align 8
  %p10863 = inttoptr i64 %v10862 to ptr
  store i64 %v10861, ptr %p10863, align 8, !alias.scope !3, !noalias !4
  %v10864 = load i64, ptr %slot1862, align 8
  %v10865 = load i64, ptr %slot44, align 8
  %p10866 = inttoptr i64 %v10865 to ptr
  store i64 %v10864, ptr %p10866, align 8, !alias.scope !3, !noalias !4
  %v10867 = load i64, ptr %slot44, align 8
  %p10868 = inttoptr i64 %v10867 to ptr
  %ld10869 = load i64, ptr %p10868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10869, ptr %slot1868, align 8
  %v10870 = load i64, ptr %slot15, align 8
  %p10871 = inttoptr i64 %v10870 to ptr
  %ld10872 = load i32, ptr %p10871, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10872, ptr %slot1869, align 8
  %v10873 = load i32, ptr %slot1869, align 8
  %cv10874 = zext i32 %v10873 to i64
  %cond10875 = icmp ne i64 %cv10874, 0
  br i1 %cond10875, label %bb_rcslotdrop2488, label %bb_rcslotdone2488
bb_rcslotdrop2488:
  %v10876 = load i64, ptr %slot15, align 8
  %p10877 = inttoptr i64 %v10876 to ptr
  store i32 0, ptr %p10877, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2488
bb_rcslotdone2488:
  %v10878 = load i64, ptr %slot13, align 8
  %p10879 = inttoptr i64 %v10878 to ptr
  %ld10880 = load i32, ptr %p10879, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10880, ptr %slot1870, align 8
  %v10881 = load i32, ptr %slot1870, align 8
  %cv10882 = zext i32 %v10881 to i64
  %cond10883 = icmp ne i64 %cv10882, 0
  br i1 %cond10883, label %bb_rcslotdrop2491, label %bb_rcslotdone2491
bb_rcslotdrop2491:
  %v10884 = load i64, ptr %slot13, align 8
  %p10885 = inttoptr i64 %v10884 to ptr
  store i32 0, ptr %p10885, align 4, !alias.scope !3, !noalias !4
  %v10886 = load i64, ptr %slot42, align 8
  store i64 %v10886, ptr %slot1871, align 8
  %v10887 = load i64, ptr %slot14, align 8
  %p10888 = inttoptr i64 %v10887 to ptr
  %ld10889 = load i32, ptr %p10888, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10889, ptr %slot1872, align 8
  %v10890 = load i32, ptr %slot1872, align 8
  %op10891 = and i32 %v10890, 28
  store i32 %op10891, ptr %slot1873, align 8
  %v10892 = load i32, ptr %slot1873, align 8
  %cv10893 = zext i32 %v10892 to i64
  %cond10894 = icmp ne i64 %cv10893, 0
  br i1 %cond10894, label %bb_rcslotrole2491, label %bb_rcslotowner2491
bb_rcslotrole2491:
  %v10895 = load i64, ptr %slot99, align 8
  store i64 %v10895, ptr %slot1874, align 8
  %v10896 = load i64, ptr %slot1874, align 8
  %v10897 = load i64, ptr %slot1871, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v10896, i64 %v10897) nomerge, !dbg !224
  br label %bb_rcslotdone2491
bb_rcslotowner2491:
  %v10898 = load i64, ptr %slot99, align 8
  store i64 %v10898, ptr %slot1875, align 8
  %v10899 = load i64, ptr %slot1875, align 8
  %v10900 = load i64, ptr %slot1871, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v10899, i64 %v10900) nomerge, !dbg !224
  br label %bb_rcslotdone2491
bb_rcslotdone2491:
  %v10901 = load i64, ptr %slot11, align 8
  %p10902 = inttoptr i64 %v10901 to ptr
  %ld10903 = load i32, ptr %p10902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10903, ptr %slot1876, align 8
  %v10904 = load i32, ptr %slot1876, align 8
  %cv10905 = zext i32 %v10904 to i64
  %cond10906 = icmp ne i64 %cv10905, 0
  br i1 %cond10906, label %bb_rcslotdrop2500, label %bb_rcslotdone2500
bb_rcslotdrop2500:
  %v10907 = load i64, ptr %slot11, align 8
  %p10908 = inttoptr i64 %v10907 to ptr
  store i32 0, ptr %p10908, align 4, !alias.scope !3, !noalias !4
  %v10909 = load i64, ptr %slot41, align 8
  store i64 %v10909, ptr %slot1877, align 8
  %v10910 = load i64, ptr %slot12, align 8
  %p10911 = inttoptr i64 %v10910 to ptr
  %ld10912 = load i32, ptr %p10911, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10912, ptr %slot1878, align 8
  %v10913 = load i32, ptr %slot1878, align 8
  %op10914 = and i32 %v10913, 28
  store i32 %op10914, ptr %slot1879, align 8
  %v10915 = load i32, ptr %slot1879, align 8
  %cv10916 = zext i32 %v10915 to i64
  %cond10917 = icmp ne i64 %cv10916, 0
  br i1 %cond10917, label %bb_rcslotrole2500, label %bb_rcslotowner2500
bb_rcslotrole2500:
  %v10918 = load i64, ptr %slot99, align 8
  store i64 %v10918, ptr %slot1880, align 8
  %v10919 = load i64, ptr %slot1880, align 8
  %v10920 = load i64, ptr %slot1877, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v10919, i64 %v10920) nomerge, !dbg !224
  br label %bb_rcslotdone2500
bb_rcslotowner2500:
  %v10921 = load i64, ptr %slot99, align 8
  store i64 %v10921, ptr %slot1881, align 8
  %v10922 = load i64, ptr %slot1881, align 8
  %v10923 = load i64, ptr %slot1877, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v10922, i64 %v10923) nomerge, !dbg !224
  br label %bb_rcslotdone2500
bb_rcslotdone2500:
  %v10924 = load i64, ptr %slot9, align 8
  %p10925 = inttoptr i64 %v10924 to ptr
  %ld10926 = load i32, ptr %p10925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10926, ptr %slot1882, align 8
  %v10927 = load i32, ptr %slot1882, align 8
  %cv10928 = zext i32 %v10927 to i64
  %cond10929 = icmp ne i64 %cv10928, 0
  br i1 %cond10929, label %bb_rcslotdrop2509, label %bb_rcslotdone2509
bb_rcslotdrop2509:
  %v10930 = load i64, ptr %slot9, align 8
  %p10931 = inttoptr i64 %v10930 to ptr
  store i32 0, ptr %p10931, align 4, !alias.scope !3, !noalias !4
  %v10932 = load i64, ptr %slot39, align 8
  store i64 %v10932, ptr %slot1883, align 8
  %v10933 = load i64, ptr %slot10, align 8
  %p10934 = inttoptr i64 %v10933 to ptr
  %ld10935 = load i32, ptr %p10934, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10935, ptr %slot1884, align 8
  %v10936 = load i32, ptr %slot1884, align 8
  %op10937 = and i32 %v10936, 28
  store i32 %op10937, ptr %slot1885, align 8
  %v10938 = load i32, ptr %slot1885, align 8
  %cv10939 = zext i32 %v10938 to i64
  %cond10940 = icmp ne i64 %cv10939, 0
  br i1 %cond10940, label %bb_rcslotrole2509, label %bb_rcslotowner2509
bb_rcslotrole2509:
  %v10941 = load i64, ptr %slot99, align 8
  store i64 %v10941, ptr %slot1886, align 8
  %v10942 = load i64, ptr %slot1883, align 8
  %p10943 = inttoptr i64 %v10942 to ptr
  %ld10944 = load i64, ptr %p10943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10944, ptr %slot1887, align 8
  %v10945 = load i64, ptr %slot1887, align 8
  %cmp10946 = icmp ne i64 %v10945, 0
  %cv10947 = zext i1 %cmp10946 to i32
  store i32 %cv10947, ptr %slot1888, align 8
  %v10948 = load i32, ptr %slot1888, align 8
  %cv10949 = zext i32 %v10948 to i64
  %cond10950 = icmp ne i64 %cv10949, 0
  br i1 %cond10950, label %bb_rcgnn2525, label %bb_rcgdone2525
bb_rcgnn2525:
  %v10951 = load i64, ptr %slot1887, align 8
  %op10952 = sub i64 %v10951, 16
  store i64 %op10952, ptr %slot1889, align 8
  %v10953 = load i64, ptr %slot1887, align 8
  %p10954 = inttoptr i64 %v10953 to ptr
  %rgep10955 = getelementptr i8, ptr %p10954, i64 -16
  %ld10956 = load i64, ptr %rgep10955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10956, ptr %slot1890, align 8
  %v10957 = load i64, ptr %slot1890, align 8
  %op10958 = and i64 %v10957, 4611686018427387906
  store i64 %op10958, ptr %slot1891, align 8
  %v10959 = load i64, ptr %slot1891, align 8
  %cmp10960 = icmp ne i64 %v10959, 0
  %cv10961 = zext i1 %cmp10960 to i32
  store i32 %cv10961, ptr %slot1892, align 8
  %v10962 = load i32, ptr %slot1892, align 8
  %cv10963 = zext i32 %v10962 to i64
  %cond10964 = icmp ne i64 %cv10963, 0
  br i1 %cond10964, label %bb_rcgclear2525, label %bb_rcgcounted2525
bb_rcgcounted2525:
  %v10965 = load i64, ptr %slot1887, align 8
  %op10966 = sub i64 %v10965, 24
  store i64 %op10966, ptr %slot1893, align 8
  %v10967 = load i64, ptr %slot1887, align 8
  %p10968 = inttoptr i64 %v10967 to ptr
  %rgep10969 = getelementptr i8, ptr %p10968, i64 -24
  %ld10970 = load i64, ptr %rgep10969, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10970, ptr %slot1894, align 8
  %v10971 = load i64, ptr %slot1894, align 8
  %op10972 = sub i64 %v10971, 1
  store i64 %op10972, ptr %slot1895, align 8
  %v10973 = load i64, ptr %slot1895, align 8
  %cmp10974 = icmp eq i64 %v10973, 0
  %cv10975 = zext i1 %cmp10974 to i32
  store i32 %cv10975, ptr %slot1896, align 8
  %v10976 = load i32, ptr %slot1896, align 8
  %cv10977 = zext i32 %v10976 to i64
  %cond10978 = icmp ne i64 %cv10977, 0
  br i1 %cond10978, label %bb_rcglast2525, label %bb_rcgdec2525
bb_rcglast2525:
  %v10979 = load i64, ptr %slot1887, align 8
  %op10980 = sub i64 %v10979, 32
  store i64 %op10980, ptr %slot1897, align 8
  %v10981 = load i64, ptr %slot1887, align 8
  %p10982 = inttoptr i64 %v10981 to ptr
  %rgep10983 = getelementptr i8, ptr %p10982, i64 -32
  %ld10984 = load i64, ptr %rgep10983, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10984, ptr %slot1898, align 8
  %v10985 = load i64, ptr %slot1898, align 8
  %cmp10986 = icmp ne i64 %v10985, 0
  %cv10987 = zext i1 %cmp10986 to i32
  store i32 %cv10987, ptr %slot1899, align 8
  %v10988 = load i32, ptr %slot1899, align 8
  %cv10989 = zext i32 %v10988 to i64
  %cond10990 = icmp ne i64 %cv10989, 0
  br i1 %cond10990, label %bb_rcgdec2525, label %bb_rcgslow2525
bb_rcgslow2525:
  %v10991 = load i64, ptr %slot1886, align 8
  %v10992 = load i64, ptr %slot1883, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v10991, i64 %v10992) nomerge, !dbg !224
  br label %bb_rcgdone2525
bb_rcgdec2525:
  %v10993 = load i64, ptr %slot1895, align 8
  %v10994 = load i64, ptr %slot1887, align 8
  %p10995 = inttoptr i64 %v10994 to ptr
  %rgep10996 = getelementptr i8, ptr %p10995, i64 -24
  store i64 %v10993, ptr %rgep10996, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2525
bb_rcgclear2525:
  %v10997 = load i64, ptr %slot1883, align 8
  %p10998 = inttoptr i64 %v10997 to ptr
  store i64 0, ptr %p10998, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2525
bb_rcgdone2525:
  br label %bb_rcslotdone2509
bb_rcslotowner2509:
  %v10999 = load i64, ptr %slot99, align 8
  store i64 %v10999, ptr %slot1900, align 8
  %v11000 = load i64, ptr %slot1883, align 8
  %p11001 = inttoptr i64 %v11000 to ptr
  %ld11002 = load i64, ptr %p11001, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11002, ptr %slot1901, align 8
  %v11003 = load i64, ptr %slot1901, align 8
  %cmp11004 = icmp ne i64 %v11003, 0
  %cv11005 = zext i1 %cmp11004 to i32
  store i32 %cv11005, ptr %slot1902, align 8
  %v11006 = load i32, ptr %slot1902, align 8
  %cv11007 = zext i32 %v11006 to i64
  %cond11008 = icmp ne i64 %cv11007, 0
  br i1 %cond11008, label %bb_rcgnn2540, label %bb_rcgdone2540
bb_rcgnn2540:
  %v11009 = load i64, ptr %slot1901, align 8
  %op11010 = sub i64 %v11009, 16
  store i64 %op11010, ptr %slot1903, align 8
  %v11011 = load i64, ptr %slot1901, align 8
  %p11012 = inttoptr i64 %v11011 to ptr
  %rgep11013 = getelementptr i8, ptr %p11012, i64 -16
  %ld11014 = load i64, ptr %rgep11013, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11014, ptr %slot1904, align 8
  %v11015 = load i64, ptr %slot1904, align 8
  %op11016 = and i64 %v11015, 4611686018427387906
  store i64 %op11016, ptr %slot1905, align 8
  %v11017 = load i64, ptr %slot1905, align 8
  %cmp11018 = icmp ne i64 %v11017, 0
  %cv11019 = zext i1 %cmp11018 to i32
  store i32 %cv11019, ptr %slot1906, align 8
  %v11020 = load i32, ptr %slot1906, align 8
  %cv11021 = zext i32 %v11020 to i64
  %cond11022 = icmp ne i64 %cv11021, 0
  br i1 %cond11022, label %bb_rcgclear2540, label %bb_rcgcounted2540
bb_rcgcounted2540:
  %v11023 = load i64, ptr %slot1901, align 8
  %op11024 = sub i64 %v11023, 32
  store i64 %op11024, ptr %slot1907, align 8
  %v11025 = load i64, ptr %slot1901, align 8
  %p11026 = inttoptr i64 %v11025 to ptr
  %rgep11027 = getelementptr i8, ptr %p11026, i64 -32
  %ld11028 = load i64, ptr %rgep11027, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11028, ptr %slot1908, align 8
  %v11029 = load i64, ptr %slot1908, align 8
  %op11030 = sub i64 %v11029, 1
  store i64 %op11030, ptr %slot1909, align 8
  %v11031 = load i64, ptr %slot1909, align 8
  %cmp11032 = icmp eq i64 %v11031, 0
  %cv11033 = zext i1 %cmp11032 to i32
  store i32 %cv11033, ptr %slot1910, align 8
  %v11034 = load i32, ptr %slot1910, align 8
  %cv11035 = zext i32 %v11034 to i64
  %cond11036 = icmp ne i64 %cv11035, 0
  br i1 %cond11036, label %bb_rcglast2540, label %bb_rcgdec2540
bb_rcglast2540:
  %v11037 = load i64, ptr %slot1901, align 8
  %op11038 = sub i64 %v11037, 24
  store i64 %op11038, ptr %slot1911, align 8
  %v11039 = load i64, ptr %slot1901, align 8
  %p11040 = inttoptr i64 %v11039 to ptr
  %rgep11041 = getelementptr i8, ptr %p11040, i64 -24
  %ld11042 = load i64, ptr %rgep11041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11042, ptr %slot1912, align 8
  %v11043 = load i64, ptr %slot1912, align 8
  %cmp11044 = icmp ne i64 %v11043, 0
  %cv11045 = zext i1 %cmp11044 to i32
  store i32 %cv11045, ptr %slot1913, align 8
  %v11046 = load i32, ptr %slot1913, align 8
  %cv11047 = zext i32 %v11046 to i64
  %cond11048 = icmp ne i64 %cv11047, 0
  br i1 %cond11048, label %bb_rcgdec2540, label %bb_rcgslow2540
bb_rcgslow2540:
  %v11049 = load i64, ptr %slot1900, align 8
  %v11050 = load i64, ptr %slot1883, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v11049, i64 %v11050) nomerge, !dbg !224
  br label %bb_rcgdone2540
bb_rcgdec2540:
  %v11051 = load i64, ptr %slot1909, align 8
  %v11052 = load i64, ptr %slot1901, align 8
  %p11053 = inttoptr i64 %v11052 to ptr
  %rgep11054 = getelementptr i8, ptr %p11053, i64 -32
  store i64 %v11051, ptr %rgep11054, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2540
bb_rcgclear2540:
  %v11055 = load i64, ptr %slot1883, align 8
  %p11056 = inttoptr i64 %v11055 to ptr
  store i64 0, ptr %p11056, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2540
bb_rcgdone2540:
  br label %bb_rcslotdone2509
bb_rcslotdone2509:
  %v11057 = load i64, ptr %slot7, align 8
  %p11058 = inttoptr i64 %v11057 to ptr
  %ld11059 = load i32, ptr %p11058, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11059, ptr %slot1914, align 8
  %v11060 = load i32, ptr %slot1914, align 8
  %cv11061 = zext i32 %v11060 to i64
  %cond11062 = icmp ne i64 %cv11061, 0
  br i1 %cond11062, label %bb_rcslotdrop2546, label %bb_rcslotdone2546
bb_rcslotdrop2546:
  %v11063 = load i64, ptr %slot7, align 8
  %p11064 = inttoptr i64 %v11063 to ptr
  store i32 0, ptr %p11064, align 4, !alias.scope !3, !noalias !4
  %v11065 = load i64, ptr %slot34, align 8
  store i64 %v11065, ptr %slot1915, align 8
  %v11066 = load i64, ptr %slot8, align 8
  %p11067 = inttoptr i64 %v11066 to ptr
  %ld11068 = load i32, ptr %p11067, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11068, ptr %slot1916, align 8
  %v11069 = load i32, ptr %slot1916, align 8
  %op11070 = and i32 %v11069, 28
  store i32 %op11070, ptr %slot1917, align 8
  %v11071 = load i32, ptr %slot1917, align 8
  %cv11072 = zext i32 %v11071 to i64
  %cond11073 = icmp ne i64 %cv11072, 0
  br i1 %cond11073, label %bb_rcslotrole2546, label %bb_rcslotowner2546
bb_rcslotrole2546:
  %v11074 = load i64, ptr %slot99, align 8
  store i64 %v11074, ptr %slot1918, align 8
  %v11075 = load i64, ptr %slot1915, align 8
  %p11076 = inttoptr i64 %v11075 to ptr
  %ld11077 = load i64, ptr %p11076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11077, ptr %slot1919, align 8
  %v11078 = load i64, ptr %slot1919, align 8
  %cmp11079 = icmp ne i64 %v11078, 0
  %cv11080 = zext i1 %cmp11079 to i32
  store i32 %cv11080, ptr %slot1920, align 8
  %v11081 = load i32, ptr %slot1920, align 8
  %cv11082 = zext i32 %v11081 to i64
  %cond11083 = icmp ne i64 %cv11082, 0
  br i1 %cond11083, label %bb_rcgnn2562, label %bb_rcgdone2562
bb_rcgnn2562:
  %v11084 = load i64, ptr %slot1919, align 8
  %op11085 = sub i64 %v11084, 16
  store i64 %op11085, ptr %slot1921, align 8
  %v11086 = load i64, ptr %slot1919, align 8
  %p11087 = inttoptr i64 %v11086 to ptr
  %rgep11088 = getelementptr i8, ptr %p11087, i64 -16
  %ld11089 = load i64, ptr %rgep11088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11089, ptr %slot1922, align 8
  %v11090 = load i64, ptr %slot1922, align 8
  %op11091 = and i64 %v11090, 4611686018427387906
  store i64 %op11091, ptr %slot1923, align 8
  %v11092 = load i64, ptr %slot1923, align 8
  %cmp11093 = icmp ne i64 %v11092, 0
  %cv11094 = zext i1 %cmp11093 to i32
  store i32 %cv11094, ptr %slot1924, align 8
  %v11095 = load i32, ptr %slot1924, align 8
  %cv11096 = zext i32 %v11095 to i64
  %cond11097 = icmp ne i64 %cv11096, 0
  br i1 %cond11097, label %bb_rcgclear2562, label %bb_rcgcounted2562
bb_rcgcounted2562:
  %v11098 = load i64, ptr %slot1919, align 8
  %op11099 = sub i64 %v11098, 24
  store i64 %op11099, ptr %slot1925, align 8
  %v11100 = load i64, ptr %slot1919, align 8
  %p11101 = inttoptr i64 %v11100 to ptr
  %rgep11102 = getelementptr i8, ptr %p11101, i64 -24
  %ld11103 = load i64, ptr %rgep11102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11103, ptr %slot1926, align 8
  %v11104 = load i64, ptr %slot1926, align 8
  %op11105 = sub i64 %v11104, 1
  store i64 %op11105, ptr %slot1927, align 8
  %v11106 = load i64, ptr %slot1927, align 8
  %cmp11107 = icmp eq i64 %v11106, 0
  %cv11108 = zext i1 %cmp11107 to i32
  store i32 %cv11108, ptr %slot1928, align 8
  %v11109 = load i32, ptr %slot1928, align 8
  %cv11110 = zext i32 %v11109 to i64
  %cond11111 = icmp ne i64 %cv11110, 0
  br i1 %cond11111, label %bb_rcglast2562, label %bb_rcgdec2562
bb_rcglast2562:
  %v11112 = load i64, ptr %slot1919, align 8
  %op11113 = sub i64 %v11112, 32
  store i64 %op11113, ptr %slot1929, align 8
  %v11114 = load i64, ptr %slot1919, align 8
  %p11115 = inttoptr i64 %v11114 to ptr
  %rgep11116 = getelementptr i8, ptr %p11115, i64 -32
  %ld11117 = load i64, ptr %rgep11116, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11117, ptr %slot1930, align 8
  %v11118 = load i64, ptr %slot1930, align 8
  %cmp11119 = icmp ne i64 %v11118, 0
  %cv11120 = zext i1 %cmp11119 to i32
  store i32 %cv11120, ptr %slot1931, align 8
  %v11121 = load i32, ptr %slot1931, align 8
  %cv11122 = zext i32 %v11121 to i64
  %cond11123 = icmp ne i64 %cv11122, 0
  br i1 %cond11123, label %bb_rcgdec2562, label %bb_rcgslow2562
bb_rcgslow2562:
  %v11124 = load i64, ptr %slot1918, align 8
  %v11125 = load i64, ptr %slot1915, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v11124, i64 %v11125) nomerge, !dbg !224
  br label %bb_rcgdone2562
bb_rcgdec2562:
  %v11126 = load i64, ptr %slot1927, align 8
  %v11127 = load i64, ptr %slot1919, align 8
  %p11128 = inttoptr i64 %v11127 to ptr
  %rgep11129 = getelementptr i8, ptr %p11128, i64 -24
  store i64 %v11126, ptr %rgep11129, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2562
bb_rcgclear2562:
  %v11130 = load i64, ptr %slot1915, align 8
  %p11131 = inttoptr i64 %v11130 to ptr
  store i64 0, ptr %p11131, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2562
bb_rcgdone2562:
  br label %bb_rcslotdone2546
bb_rcslotowner2546:
  %v11132 = load i64, ptr %slot99, align 8
  store i64 %v11132, ptr %slot1932, align 8
  %v11133 = load i64, ptr %slot1915, align 8
  %p11134 = inttoptr i64 %v11133 to ptr
  %ld11135 = load i64, ptr %p11134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11135, ptr %slot1933, align 8
  %v11136 = load i64, ptr %slot1933, align 8
  %cmp11137 = icmp ne i64 %v11136, 0
  %cv11138 = zext i1 %cmp11137 to i32
  store i32 %cv11138, ptr %slot1934, align 8
  %v11139 = load i32, ptr %slot1934, align 8
  %cv11140 = zext i32 %v11139 to i64
  %cond11141 = icmp ne i64 %cv11140, 0
  br i1 %cond11141, label %bb_rcgnn2577, label %bb_rcgdone2577
bb_rcgnn2577:
  %v11142 = load i64, ptr %slot1933, align 8
  %op11143 = sub i64 %v11142, 16
  store i64 %op11143, ptr %slot1935, align 8
  %v11144 = load i64, ptr %slot1933, align 8
  %p11145 = inttoptr i64 %v11144 to ptr
  %rgep11146 = getelementptr i8, ptr %p11145, i64 -16
  %ld11147 = load i64, ptr %rgep11146, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11147, ptr %slot1936, align 8
  %v11148 = load i64, ptr %slot1936, align 8
  %op11149 = and i64 %v11148, 4611686018427387906
  store i64 %op11149, ptr %slot1937, align 8
  %v11150 = load i64, ptr %slot1937, align 8
  %cmp11151 = icmp ne i64 %v11150, 0
  %cv11152 = zext i1 %cmp11151 to i32
  store i32 %cv11152, ptr %slot1938, align 8
  %v11153 = load i32, ptr %slot1938, align 8
  %cv11154 = zext i32 %v11153 to i64
  %cond11155 = icmp ne i64 %cv11154, 0
  br i1 %cond11155, label %bb_rcgclear2577, label %bb_rcgcounted2577
bb_rcgcounted2577:
  %v11156 = load i64, ptr %slot1933, align 8
  %op11157 = sub i64 %v11156, 32
  store i64 %op11157, ptr %slot1939, align 8
  %v11158 = load i64, ptr %slot1933, align 8
  %p11159 = inttoptr i64 %v11158 to ptr
  %rgep11160 = getelementptr i8, ptr %p11159, i64 -32
  %ld11161 = load i64, ptr %rgep11160, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11161, ptr %slot1940, align 8
  %v11162 = load i64, ptr %slot1940, align 8
  %op11163 = sub i64 %v11162, 1
  store i64 %op11163, ptr %slot1941, align 8
  %v11164 = load i64, ptr %slot1941, align 8
  %cmp11165 = icmp eq i64 %v11164, 0
  %cv11166 = zext i1 %cmp11165 to i32
  store i32 %cv11166, ptr %slot1942, align 8
  %v11167 = load i32, ptr %slot1942, align 8
  %cv11168 = zext i32 %v11167 to i64
  %cond11169 = icmp ne i64 %cv11168, 0
  br i1 %cond11169, label %bb_rcglast2577, label %bb_rcgdec2577
bb_rcglast2577:
  %v11170 = load i64, ptr %slot1933, align 8
  %op11171 = sub i64 %v11170, 24
  store i64 %op11171, ptr %slot1943, align 8
  %v11172 = load i64, ptr %slot1933, align 8
  %p11173 = inttoptr i64 %v11172 to ptr
  %rgep11174 = getelementptr i8, ptr %p11173, i64 -24
  %ld11175 = load i64, ptr %rgep11174, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11175, ptr %slot1944, align 8
  %v11176 = load i64, ptr %slot1944, align 8
  %cmp11177 = icmp ne i64 %v11176, 0
  %cv11178 = zext i1 %cmp11177 to i32
  store i32 %cv11178, ptr %slot1945, align 8
  %v11179 = load i32, ptr %slot1945, align 8
  %cv11180 = zext i32 %v11179 to i64
  %cond11181 = icmp ne i64 %cv11180, 0
  br i1 %cond11181, label %bb_rcgdec2577, label %bb_rcgslow2577
bb_rcgslow2577:
  %v11182 = load i64, ptr %slot1932, align 8
  %v11183 = load i64, ptr %slot1915, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v11182, i64 %v11183) nomerge, !dbg !224
  br label %bb_rcgdone2577
bb_rcgdec2577:
  %v11184 = load i64, ptr %slot1941, align 8
  %v11185 = load i64, ptr %slot1933, align 8
  %p11186 = inttoptr i64 %v11185 to ptr
  %rgep11187 = getelementptr i8, ptr %p11186, i64 -32
  store i64 %v11184, ptr %rgep11187, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2577
bb_rcgclear2577:
  %v11188 = load i64, ptr %slot1915, align 8
  %p11189 = inttoptr i64 %v11188 to ptr
  store i64 0, ptr %p11189, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2577
bb_rcgdone2577:
  br label %bb_rcslotdone2546
bb_rcslotdone2546:
  %v11190 = load i64, ptr %slot5, align 8
  %p11191 = inttoptr i64 %v11190 to ptr
  %ld11192 = load i32, ptr %p11191, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11192, ptr %slot1946, align 8
  %v11193 = load i32, ptr %slot1946, align 8
  %cv11194 = zext i32 %v11193 to i64
  %cond11195 = icmp ne i64 %cv11194, 0
  br i1 %cond11195, label %bb_rcslotdrop2583, label %bb_rcslotdone2583
bb_rcslotdrop2583:
  %v11196 = load i64, ptr %slot5, align 8
  %p11197 = inttoptr i64 %v11196 to ptr
  store i32 0, ptr %p11197, align 4, !alias.scope !3, !noalias !4
  %v11198 = load i64, ptr %slot33, align 8
  store i64 %v11198, ptr %slot1947, align 8
  %v11199 = load i64, ptr %slot6, align 8
  %p11200 = inttoptr i64 %v11199 to ptr
  %ld11201 = load i32, ptr %p11200, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11201, ptr %slot1948, align 8
  %v11202 = load i32, ptr %slot1948, align 8
  %op11203 = and i32 %v11202, 28
  store i32 %op11203, ptr %slot1949, align 8
  %v11204 = load i32, ptr %slot1949, align 8
  %cv11205 = zext i32 %v11204 to i64
  %cond11206 = icmp ne i64 %cv11205, 0
  br i1 %cond11206, label %bb_rcslotrole2583, label %bb_rcslotowner2583
bb_rcslotrole2583:
  %v11207 = load i64, ptr %slot99, align 8
  store i64 %v11207, ptr %slot1950, align 8
  %v11208 = load i64, ptr %slot1950, align 8
  %v11209 = load i64, ptr %slot1947, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v11208, i64 %v11209) nomerge, !dbg !224
  br label %bb_rcslotdone2583
bb_rcslotowner2583:
  %v11210 = load i64, ptr %slot99, align 8
  store i64 %v11210, ptr %slot1951, align 8
  %v11211 = load i64, ptr %slot1951, align 8
  %v11212 = load i64, ptr %slot1947, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v11211, i64 %v11212) nomerge, !dbg !224
  br label %bb_rcslotdone2583
bb_rcslotdone2583:
  %v11213 = load i64, ptr %slot1868, align 8
  %p11214 = inttoptr i64 %v11213 to ptr
  %ret11215 = load { i64, i64 }, ptr %p11214, align 8
  ret { i64, i64 } %ret11215
bb_i140:
  %v11216 = load i64, ptr %slot32, align 8
  %p11217 = inttoptr i64 %v11216 to ptr
  %ld11218 = load i64, ptr %p11217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11218, ptr %slot1952, align 8
  %v11219 = load i64, ptr %slot1952, align 8
  %v11220 = load i64, ptr %slot44, align 8
  %p11221 = inttoptr i64 %v11220 to ptr
  store i64 %v11219, ptr %p11221, align 8, !alias.scope !3, !noalias !4
  %v11222 = load i64, ptr %slot77, align 8
  store i64 %v11222, ptr %slot1953, align 8
  %v11223 = load i64, ptr %slot1953, align 8
  %p11224 = inttoptr i64 %v11223 to ptr
  store i32 0, ptr %p11224, align 4, !alias.scope !3, !noalias !4
  %v11225 = load i64, ptr %slot1953, align 8
  %p11226 = inttoptr i64 %v11225 to ptr
  store i32 34, ptr %p11226, align 4, !alias.scope !3, !noalias !4
  %v11227 = load i64, ptr %slot1953, align 8
  %v11228 = load i64, ptr %slot45, align 8
  %p11229 = inttoptr i64 %v11228 to ptr
  store i64 %v11227, ptr %p11229, align 8, !alias.scope !3, !noalias !4
  %v11230 = load i64, ptr %slot44, align 8
  %p11231 = inttoptr i64 %v11230 to ptr
  %ld11232 = load i64, ptr %p11231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11232, ptr %slot1954, align 8
  %v11233 = load i64, ptr %slot45, align 8
  %p11234 = inttoptr i64 %v11233 to ptr
  %ld11235 = load i64, ptr %p11234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11235, ptr %slot1955, align 8
  %v11236 = load i64, ptr %slot1, align 8
  %v11237 = load i64, ptr %slot1954, align 8
  %v11238 = load i64, ptr %slot1955, align 8
  %call11239 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v11236, i64 %v11237, i64 %v11238) nomerge, !dbg !226
  store i64 %call11239, ptr %slot1956, align 8
  %v11240 = load i64, ptr %slot1956, align 8
  %v11241 = load i64, ptr %slot44, align 8
  %p11242 = inttoptr i64 %v11241 to ptr
  store i64 %v11240, ptr %p11242, align 8, !alias.scope !3, !noalias !4
  %v11243 = load i64, ptr %slot15, align 8
  %p11244 = inttoptr i64 %v11243 to ptr
  %ld11245 = load i32, ptr %p11244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11245, ptr %slot1957, align 8
  %v11246 = load i32, ptr %slot1957, align 8
  %cv11247 = zext i32 %v11246 to i64
  %cond11248 = icmp ne i64 %cv11247, 0
  br i1 %cond11248, label %bb_rcslotdrop2606, label %bb_rcslotdone2606
bb_rcslotdrop2606:
  %v11249 = load i64, ptr %slot15, align 8
  %p11250 = inttoptr i64 %v11249 to ptr
  store i32 0, ptr %p11250, align 4, !alias.scope !3, !noalias !4
  %v11251 = load i64, ptr %slot24, align 8
  store i64 %v11251, ptr %slot1958, align 8
  %v11252 = load i64, ptr %slot16, align 8
  %p11253 = inttoptr i64 %v11252 to ptr
  %ld11254 = load i32, ptr %p11253, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11254, ptr %slot1959, align 8
  %v11255 = load i32, ptr %slot1959, align 8
  %op11256 = and i32 %v11255, 28
  store i32 %op11256, ptr %slot1960, align 8
  %v11257 = load i32, ptr %slot1960, align 8
  %cv11258 = zext i32 %v11257 to i64
  %cond11259 = icmp ne i64 %cv11258, 0
  br i1 %cond11259, label %bb_rcslotrole2606, label %bb_rcslotowner2606
bb_rcslotrole2606:
  %v11260 = load i64, ptr %slot99, align 8
  store i64 %v11260, ptr %slot1961, align 8
  %v11261 = load i64, ptr %slot1961, align 8
  %v11262 = load i64, ptr %slot1958, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v11261, i64 %v11262) nomerge, !dbg !226
  br label %bb_rcslotdone2606
bb_rcslotowner2606:
  %v11263 = load i64, ptr %slot99, align 8
  store i64 %v11263, ptr %slot1962, align 8
  %v11264 = load i64, ptr %slot1962, align 8
  %v11265 = load i64, ptr %slot1958, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v11264, i64 %v11265) nomerge, !dbg !226
  br label %bb_rcslotdone2606
bb_rcslotdone2606:
  %v11266 = load i64, ptr %slot44, align 8
  %p11267 = inttoptr i64 %v11266 to ptr
  %ld11268 = load i64, ptr %p11267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11268, ptr %slot1963, align 8
  %v11269 = load i64, ptr %slot1963, align 8
  %cond11270 = icmp ne i64 %v11269, 0
  br i1 %cond11270, label %bb_next2614, label %bb_i154
bb_next2614:
  %v11271 = load i64, ptr %slot32, align 8
  %p11272 = inttoptr i64 %v11271 to ptr
  %ld11273 = load i64, ptr %p11272, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11273, ptr %slot1964, align 8
  %v11274 = load i64, ptr %slot1964, align 8
  %v11275 = load i64, ptr %slot44, align 8
  %p11276 = inttoptr i64 %v11275 to ptr
  store i64 %v11274, ptr %p11276, align 8, !alias.scope !3, !noalias !4
  %v11277 = load i64, ptr %slot32, align 8
  %p11278 = inttoptr i64 %v11277 to ptr
  %ld11279 = load i64, ptr %p11278, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11279, ptr %slot1965, align 8
  %v11280 = load i64, ptr %slot1965, align 8
  %v11281 = load i64, ptr %slot78, align 8
  %p11282 = inttoptr i64 %v11280 to ptr
  %p11283 = inttoptr i64 %v11281 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11283, ptr %p11282, i64 312, i1 false), !alias.scope !10000000
  %v11284 = load i64, ptr %slot78, align 8
  %v11285 = load i64, ptr %slot45, align 8
  %p11286 = inttoptr i64 %v11285 to ptr
  store i64 %v11284, ptr %p11286, align 8, !alias.scope !3, !noalias !4
  %v11287 = load i64, ptr %slot45, align 8
  %p11288 = inttoptr i64 %v11287 to ptr
  %ld11289 = load i64, ptr %p11288, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11289, ptr %slot1966, align 8
  %v11290 = load i64, ptr %slot1, align 8
  %v11291 = load i64, ptr %slot1966, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult1968, i64 %v11290, i64 %v11291) nomerge, !dbg !228
  %addr11292 = ptrtoint ptr %callresult1968 to i64
  store i64 %addr11292, ptr %slot1967, align 8
  %v11293 = load i64, ptr %slot1967, align 8
  %v11294 = load i64, ptr %slot45, align 8
  %p11295 = inttoptr i64 %v11294 to ptr
  store i64 %v11293, ptr %p11295, align 8, !alias.scope !3, !noalias !4
  %v11296 = load i64, ptr %slot45, align 8
  %p11297 = inttoptr i64 %v11296 to ptr
  %ld11298 = load i64, ptr %p11297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11298, ptr %slot1969, align 8
  %v11299 = load i64, ptr %slot30, align 8
  store i64 %v11299, ptr %slot1970, align 8
  %v11300 = load i64, ptr %slot99, align 8
  %v11301 = load i64, ptr %slot1970, align 8
  %v11302 = load i64, ptr %slot1969, align 8
  %call11303 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v11300, i64 %v11301, i64 %v11302) nomerge, !dbg !228
  store i32 %call11303, ptr %slot1971, align 8
  %v11304 = load i32, ptr %slot1971, align 8
  %cv11305 = zext i32 %v11304 to i64
  %cond11306 = icmp ne i64 %cv11305, 0
  br i1 %cond11306, label %bb_rcsuccess2621, label %bb_rcfailure2621
bb_rcfailure2621:
  %v11307 = load i64, ptr %slot99, align 8
  %p11308 = inttoptr i64 %v11307 to ptr
  %call11309 = call i32 @myl_rc_take_failure(ptr %p11308) nomerge, !dbg !228
  store i32 %call11309, ptr %slot1972, align 8
  %v11310 = load i64, ptr %slot1, align 8
  %p11311 = inttoptr i64 %v11310 to ptr
  %v11312 = load i32, ptr %slot1972, align 8
  %call11313 = call i32 @myl_qbe_rc_status(ptr %p11311, i32 %v11312) nomerge, !dbg !228
  store i32 %call11313, ptr %slot1973, align 8
  br label %bb_failure
bb_rcsuccess2621:
  %v11314 = load i64, ptr %slot22, align 8
  %p11315 = inttoptr i64 %v11314 to ptr
  store i32 2, ptr %p11315, align 4, !alias.scope !3, !noalias !4
  %v11316 = load i64, ptr %slot22, align 8
  %p11317 = inttoptr i64 %v11316 to ptr
  store i32 16, ptr %p11317, align 4, !alias.scope !3, !noalias !4
  %v11318 = load i64, ptr %slot21, align 8
  %p11319 = inttoptr i64 %v11318 to ptr
  store i32 1, ptr %p11319, align 4, !alias.scope !3, !noalias !4
  %v11320 = load i64, ptr %slot17, align 8
  %p11321 = inttoptr i64 %v11320 to ptr
  %ld11322 = load i32, ptr %p11321, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11322, ptr %slot1974, align 8
  %v11323 = load i32, ptr %slot1974, align 8
  %cv11324 = zext i32 %v11323 to i64
  %cond11325 = icmp ne i64 %cv11324, 0
  br i1 %cond11325, label %bb_rcslotdrop2629, label %bb_rcslotdone2629
bb_rcslotdrop2629:
  %v11326 = load i64, ptr %slot17, align 8
  %p11327 = inttoptr i64 %v11326 to ptr
  store i32 0, ptr %p11327, align 4, !alias.scope !3, !noalias !4
  %v11328 = load i64, ptr %slot25, align 8
  store i64 %v11328, ptr %slot1975, align 8
  %v11329 = load i64, ptr %slot18, align 8
  %p11330 = inttoptr i64 %v11329 to ptr
  %ld11331 = load i32, ptr %p11330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11331, ptr %slot1976, align 8
  %v11332 = load i32, ptr %slot1976, align 8
  %op11333 = and i32 %v11332, 28
  store i32 %op11333, ptr %slot1977, align 8
  %v11334 = load i32, ptr %slot1977, align 8
  %cv11335 = zext i32 %v11334 to i64
  %cond11336 = icmp ne i64 %cv11335, 0
  br i1 %cond11336, label %bb_rcslotrole2629, label %bb_rcslotowner2629
bb_rcslotrole2629:
  %v11337 = load i64, ptr %slot99, align 8
  store i64 %v11337, ptr %slot1978, align 8
  %v11338 = load i64, ptr %slot1978, align 8
  %v11339 = load i64, ptr %slot1975, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v11338, i64 %v11339) nomerge, !dbg !228
  br label %bb_rcslotdone2629
bb_rcslotowner2629:
  %v11340 = load i64, ptr %slot99, align 8
  store i64 %v11340, ptr %slot1979, align 8
  %v11341 = load i64, ptr %slot1979, align 8
  %v11342 = load i64, ptr %slot1975, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v11341, i64 %v11342) nomerge, !dbg !228
  br label %bb_rcslotdone2629
bb_rcslotdone2629:
  %v11343 = load i64, ptr %slot25, align 8
  store i64 %v11343, ptr %slot1980, align 8
  %v11344 = load i64, ptr %slot30, align 8
  store i64 %v11344, ptr %slot1981, align 8
  %v11345 = load i64, ptr %slot1981, align 8
  %v11346 = load i64, ptr %slot1980, align 8
  %p11347 = inttoptr i64 %v11345 to ptr
  %p11348 = inttoptr i64 %v11346 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11348, ptr %p11347, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v11349 = load i64, ptr %slot18, align 8
  %p11350 = inttoptr i64 %v11349 to ptr
  store i32 2, ptr %p11350, align 4, !alias.scope !3, !noalias !4
  %v11351 = load i64, ptr %slot22, align 8
  %p11352 = inttoptr i64 %v11351 to ptr
  %ld11353 = load i32, ptr %p11352, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11353, ptr %slot1982, align 8
  %v11354 = load i32, ptr %slot1982, align 8
  %v11355 = load i64, ptr %slot18, align 8
  %p11356 = inttoptr i64 %v11355 to ptr
  store i32 %v11354, ptr %p11356, align 4, !alias.scope !3, !noalias !4
  %v11357 = load i64, ptr %slot21, align 8
  %p11358 = inttoptr i64 %v11357 to ptr
  store i32 0, ptr %p11358, align 4, !alias.scope !3, !noalias !4
  %v11359 = load i64, ptr %slot17, align 8
  %p11360 = inttoptr i64 %v11359 to ptr
  store i32 1, ptr %p11360, align 4, !alias.scope !3, !noalias !4
  %v11361 = load i64, ptr %slot1980, align 8
  %v11362 = load i64, ptr %slot45, align 8
  %p11363 = inttoptr i64 %v11362 to ptr
  store i64 %v11361, ptr %p11363, align 8, !alias.scope !3, !noalias !4
  %v11364 = load i64, ptr %slot46, align 8
  %p11365 = inttoptr i64 %v11364 to ptr
  store i64 18446744073709551615, ptr %p11365, align 8, !alias.scope !3, !noalias !4
  %v11366 = load i64, ptr %slot47, align 8
  %p11367 = inttoptr i64 %v11366 to ptr
  store i64 0, ptr %p11367, align 8, !alias.scope !3, !noalias !4
  %v11368 = load i64, ptr %slot79, align 8
  store i64 %v11368, ptr %slot1983, align 8
  %v11369 = load i64, ptr %slot1983, align 8
  %p11370 = inttoptr i64 %v11369 to ptr
  store i64 0, ptr %p11370, align 8, !alias.scope !3, !noalias !4
  %v11371 = load i64, ptr %slot1983, align 8
  %p11373 = inttoptr i64 %v11371 to ptr
  %gep11374 = getelementptr i8, ptr %p11373, i64 8
  %op11372 = ptrtoint ptr %gep11374 to i64
  store i64 %op11372, ptr %slot1984, align 8
  %v11375 = load i64, ptr %slot1984, align 8
  %p11376 = inttoptr i64 %v11375 to ptr
  store i64 0, ptr %p11376, align 8, !alias.scope !3, !noalias !4
  %v11377 = load i64, ptr %slot1983, align 8
  %p11379 = inttoptr i64 %v11377 to ptr
  %gep11380 = getelementptr i8, ptr %p11379, i64 16
  %op11378 = ptrtoint ptr %gep11380 to i64
  store i64 %op11378, ptr %slot1985, align 8
  %v11381 = load i64, ptr %slot1985, align 8
  %p11382 = inttoptr i64 %v11381 to ptr
  store i64 0, ptr %p11382, align 8, !alias.scope !3, !noalias !4
  %v11383 = load i64, ptr %slot1983, align 8
  %p11385 = inttoptr i64 %v11383 to ptr
  %gep11386 = getelementptr i8, ptr %p11385, i64 24
  %op11384 = ptrtoint ptr %gep11386 to i64
  store i64 %op11384, ptr %slot1986, align 8
  %v11387 = load i64, ptr %slot1986, align 8
  %p11388 = inttoptr i64 %v11387 to ptr
  store i64 0, ptr %p11388, align 8, !alias.scope !3, !noalias !4
  %v11389 = load i64, ptr %slot1983, align 8
  %p11391 = inttoptr i64 %v11389 to ptr
  %gep11392 = getelementptr i8, ptr %p11391, i64 32
  %op11390 = ptrtoint ptr %gep11392 to i64
  store i64 %op11390, ptr %slot1987, align 8
  %v11393 = load i64, ptr %slot1987, align 8
  %p11394 = inttoptr i64 %v11393 to ptr
  store i64 0, ptr %p11394, align 8, !alias.scope !3, !noalias !4
  %v11395 = load i64, ptr %slot1983, align 8
  %p11397 = inttoptr i64 %v11395 to ptr
  %gep11398 = getelementptr i8, ptr %p11397, i64 40
  %op11396 = ptrtoint ptr %gep11398 to i64
  store i64 %op11396, ptr %slot1988, align 8
  %v11399 = load i64, ptr %slot1988, align 8
  %p11400 = inttoptr i64 %v11399 to ptr
  store i64 0, ptr %p11400, align 8, !alias.scope !3, !noalias !4
  %v11401 = load i64, ptr %slot1983, align 8
  %p11403 = inttoptr i64 %v11401 to ptr
  %gep11404 = getelementptr i8, ptr %p11403, i64 48
  %op11402 = ptrtoint ptr %gep11404 to i64
  store i64 %op11402, ptr %slot1989, align 8
  %v11405 = load i64, ptr %slot1989, align 8
  %p11406 = inttoptr i64 %v11405 to ptr
  store i64 0, ptr %p11406, align 8, !alias.scope !3, !noalias !4
  %v11407 = load i64, ptr %slot23, align 8
  %p11408 = inttoptr i64 %v11407 to ptr
  store i32 1, ptr %p11408, align 4, !alias.scope !3, !noalias !4
  %v11409 = load i64, ptr %slot100, align 8
  store i64 %v11409, ptr %slot1990, align 8
  %v11410 = load i64, ptr %slot45, align 8
  %p11411 = inttoptr i64 %v11410 to ptr
  %ld11412 = load i64, ptr %p11411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11412, ptr %slot1991, align 8
  %v11413 = load i64, ptr %slot1983, align 8
  %p11415 = inttoptr i64 %v11413 to ptr
  %gep11416 = getelementptr i8, ptr %p11415, i64 0
  %op11414 = ptrtoint ptr %gep11416 to i64
  store i64 %op11414, ptr %slot1992, align 8
  %v11417 = load i64, ptr %slot45, align 8
  %p11418 = inttoptr i64 %v11417 to ptr
  %ld11419 = load i64, ptr %p11418, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11419, ptr %slot1993, align 8
  %v11420 = load i64, ptr %slot17, align 8
  %p11421 = inttoptr i64 %v11420 to ptr
  %ld11422 = load i32, ptr %p11421, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11422, ptr %slot1994, align 8
  %v11423 = load i64, ptr %slot18, align 8
  %p11424 = inttoptr i64 %v11423 to ptr
  %ld11425 = load i32, ptr %p11424, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11425, ptr %slot1995, align 8
  %v11426 = load i32, ptr %slot1995, align 8
  %op11427 = and i32 %v11426, 24
  store i32 %op11427, ptr %slot1995, align 8
  %v11428 = load i32, ptr %slot1995, align 8
  %cmp11429 = icmp eq i32 %v11428, 0
  %cv11430 = zext i1 %cmp11429 to i32
  store i32 %cv11430, ptr %slot1996, align 8
  %v11431 = load i32, ptr %slot1994, align 8
  %v11432 = load i32, ptr %slot1996, align 8
  %op11433 = and i32 %v11431, %v11432
  store i32 %op11433, ptr %slot1997, align 8
  %v11434 = load i32, ptr %slot1997, align 8
  %cv11435 = zext i32 %v11434 to i64
  %cond11436 = icmp ne i64 %cv11435, 0
  br i1 %cond11436, label %bb_rctake2657, label %bb_rccopy2657
bb_rctake2657:
  %v11437 = load i64, ptr %slot30, align 8
  store i64 %v11437, ptr %slot1998, align 8
  %v11438 = load i64, ptr %slot100, align 8
  store i64 %v11438, ptr %slot1999, align 8
  %v11439 = load i64, ptr %slot99, align 8
  %v11440 = load i64, ptr %slot1998, align 8
  %v11441 = load i64, ptr %slot1993, align 8
  %v11442 = load i64, ptr %slot1999, align 8
  %cv11443 = trunc i64 %v11442 to i32
  %call11444 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64 %v11439, i64 %v11440, i64 %v11441, i32 %cv11443) nomerge, !dbg !230
  store i32 %call11444, ptr %slot2000, align 8
  %v11445 = load i32, ptr %slot2000, align 8
  %cv11446 = zext i32 %v11445 to i64
  %cond11447 = icmp ne i64 %cv11446, 0
  br i1 %cond11447, label %bb_rcsuccess2667, label %bb_rcfailure2667
bb_rcfailure2667:
  %v11448 = load i64, ptr %slot99, align 8
  %p11449 = inttoptr i64 %v11448 to ptr
  %call11450 = call i32 @myl_rc_take_failure(ptr %p11449) nomerge, !dbg !230
  store i32 %call11450, ptr %slot2001, align 8
  %v11451 = load i64, ptr %slot1, align 8
  %p11452 = inttoptr i64 %v11451 to ptr
  %v11453 = load i32, ptr %slot2001, align 8
  %call11454 = call i32 @myl_qbe_rc_status(ptr %p11452, i32 %v11453) nomerge, !dbg !230
  store i32 %call11454, ptr %slot2002, align 8
  br label %bb_failure
bb_rcsuccess2667:
  %v11455 = load i64, ptr %slot17, align 8
  %p11456 = inttoptr i64 %v11455 to ptr
  store i32 0, ptr %p11456, align 4, !alias.scope !3, !noalias !4
  %v11457 = load i64, ptr %slot22, align 8
  %p11458 = inttoptr i64 %v11457 to ptr
  store i32 2, ptr %p11458, align 4, !alias.scope !3, !noalias !4
  %v11459 = load i64, ptr %slot21, align 8
  %p11460 = inttoptr i64 %v11459 to ptr
  store i32 1, ptr %p11460, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared2657
bb_rccopy2657:
  %v11461 = load i64, ptr %slot30, align 8
  store i64 %v11461, ptr %slot2003, align 8
  %v11462 = load i64, ptr %slot100, align 8
  store i64 %v11462, ptr %slot2004, align 8
  %v11463 = load i64, ptr %slot99, align 8
  %v11464 = load i64, ptr %slot2003, align 8
  %v11465 = load i64, ptr %slot1993, align 8
  %v11466 = load i64, ptr %slot2004, align 8
  %cv11467 = trunc i64 %v11466 to i32
  %call11468 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v11463, i64 %v11464, i64 %v11465, i32 %cv11467) nomerge, !dbg !230
  store i32 %call11468, ptr %slot2005, align 8
  %v11469 = load i32, ptr %slot2005, align 8
  %cv11470 = zext i32 %v11469 to i64
  %cond11471 = icmp ne i64 %cv11470, 0
  br i1 %cond11471, label %bb_rcsuccess2676, label %bb_rcfailure2676
bb_rcfailure2676:
  %v11472 = load i64, ptr %slot99, align 8
  %p11473 = inttoptr i64 %v11472 to ptr
  %call11474 = call i32 @myl_rc_take_failure(ptr %p11473) nomerge, !dbg !230
  store i32 %call11474, ptr %slot2006, align 8
  %v11475 = load i64, ptr %slot1, align 8
  %p11476 = inttoptr i64 %v11475 to ptr
  %v11477 = load i32, ptr %slot2006, align 8
  %call11478 = call i32 @myl_qbe_rc_status(ptr %p11476, i32 %v11477) nomerge, !dbg !230
  store i32 %call11478, ptr %slot2007, align 8
  br label %bb_failure
bb_rcsuccess2676:
  %v11479 = load i64, ptr %slot22, align 8
  %p11480 = inttoptr i64 %v11479 to ptr
  store i32 2, ptr %p11480, align 4, !alias.scope !3, !noalias !4
  %v11481 = load i64, ptr %slot21, align 8
  %p11482 = inttoptr i64 %v11481 to ptr
  store i32 1, ptr %p11482, align 4, !alias.scope !3, !noalias !4
  %v11483 = load i64, ptr %slot17, align 8
  %p11484 = inttoptr i64 %v11483 to ptr
  %ld11485 = load i32, ptr %p11484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11485, ptr %slot2008, align 8
  %v11486 = load i32, ptr %slot2008, align 8
  %cv11487 = zext i32 %v11486 to i64
  %cond11488 = icmp ne i64 %cv11487, 0
  br i1 %cond11488, label %bb_rcslotdrop2683, label %bb_rcslotdone2683
bb_rcslotdrop2683:
  %v11489 = load i64, ptr %slot17, align 8
  %p11490 = inttoptr i64 %v11489 to ptr
  store i32 0, ptr %p11490, align 4, !alias.scope !3, !noalias !4
  %v11491 = load i64, ptr %slot25, align 8
  store i64 %v11491, ptr %slot2009, align 8
  %v11492 = load i64, ptr %slot18, align 8
  %p11493 = inttoptr i64 %v11492 to ptr
  %ld11494 = load i32, ptr %p11493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11494, ptr %slot2010, align 8
  %v11495 = load i32, ptr %slot2010, align 8
  %op11496 = and i32 %v11495, 28
  store i32 %op11496, ptr %slot2011, align 8
  %v11497 = load i32, ptr %slot2011, align 8
  %cv11498 = zext i32 %v11497 to i64
  %cond11499 = icmp ne i64 %cv11498, 0
  br i1 %cond11499, label %bb_rcslotrole2683, label %bb_rcslotowner2683
bb_rcslotrole2683:
  %v11500 = load i64, ptr %slot99, align 8
  store i64 %v11500, ptr %slot2012, align 8
  %v11501 = load i64, ptr %slot2012, align 8
  %v11502 = load i64, ptr %slot2009, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v11501, i64 %v11502) nomerge, !dbg !230
  br label %bb_rcslotdone2683
bb_rcslotowner2683:
  %v11503 = load i64, ptr %slot99, align 8
  store i64 %v11503, ptr %slot2013, align 8
  %v11504 = load i64, ptr %slot2013, align 8
  %v11505 = load i64, ptr %slot2009, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v11504, i64 %v11505) nomerge, !dbg !230
  br label %bb_rcslotdone2683
bb_rcslotdone2683:
  br label %bb_rcprepared2657
bb_rcprepared2657:
  %v11506 = load i64, ptr %slot30, align 8
  store i64 %v11506, ptr %slot2014, align 8
  %v11507 = load i64, ptr %slot2014, align 8
  %v11508 = load i64, ptr %slot1992, align 8
  %p11509 = inttoptr i64 %v11507 to ptr
  %p11510 = inttoptr i64 %v11508 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11510, ptr %p11509, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v11511 = load i64, ptr %slot21, align 8
  %p11512 = inttoptr i64 %v11511 to ptr
  store i32 0, ptr %p11512, align 4, !alias.scope !3, !noalias !4
  %v11513 = load i64, ptr %slot46, align 8
  store i64 %v11513, ptr %slot2015, align 8
  %v11514 = load i64, ptr %slot1983, align 8
  %p11516 = inttoptr i64 %v11514 to ptr
  %gep11517 = getelementptr i8, ptr %p11516, i64 40
  %op11515 = ptrtoint ptr %gep11517 to i64
  store i64 %op11515, ptr %slot2016, align 8
  %v11518 = load i64, ptr %slot2015, align 8
  %p11519 = inttoptr i64 %v11518 to ptr
  %ld11520 = load i64, ptr %p11519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11520, ptr %slot2017, align 8
  %v11521 = load i64, ptr %slot2017, align 8
  %v11522 = load i64, ptr %slot2016, align 8
  %p11523 = inttoptr i64 %v11522 to ptr
  store i64 %v11521, ptr %p11523, align 8, !alias.scope !3, !noalias !4
  %v11524 = load i64, ptr %slot47, align 8
  store i64 %v11524, ptr %slot2018, align 8
  %v11525 = load i64, ptr %slot1983, align 8
  %p11527 = inttoptr i64 %v11525 to ptr
  %gep11528 = getelementptr i8, ptr %p11527, i64 48
  %op11526 = ptrtoint ptr %gep11528 to i64
  store i64 %op11526, ptr %slot2019, align 8
  %v11529 = load i64, ptr %slot2018, align 8
  %p11530 = inttoptr i64 %v11529 to ptr
  %ld11531 = load i64, ptr %p11530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11531, ptr %slot2020, align 8
  %v11532 = load i64, ptr %slot2020, align 8
  %v11533 = load i64, ptr %slot2019, align 8
  %p11534 = inttoptr i64 %v11533 to ptr
  store i64 %v11532, ptr %p11534, align 8, !alias.scope !3, !noalias !4
  %v11535 = load i64, ptr %slot1983, align 8
  %v11536 = load i64, ptr %slot45, align 8
  %p11537 = inttoptr i64 %v11536 to ptr
  store i64 %v11535, ptr %p11537, align 8, !alias.scope !3, !noalias !4
  %v11538 = load i64, ptr %slot45, align 8
  %p11539 = inttoptr i64 %v11538 to ptr
  %ld11540 = load i64, ptr %p11539, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11540, ptr %slot2021, align 8
  %v11541 = load i64, ptr %slot25, align 8
  store i64 %v11541, ptr %slot2022, align 8
  %v11542 = load i64, ptr %slot2021, align 8
  %v11543 = load i64, ptr %slot2022, align 8
  %p11544 = inttoptr i64 %v11542 to ptr
  %p11545 = inttoptr i64 %v11543 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11545, ptr %p11544, i64 56, i1 false)
  %v11546 = load i64, ptr %slot18, align 8
  %p11547 = inttoptr i64 %v11546 to ptr
  store i32 2, ptr %p11547, align 4, !alias.scope !3, !noalias !4
  %v11548 = load i64, ptr %slot17, align 8
  %p11549 = inttoptr i64 %v11548 to ptr
  store i32 1, ptr %p11549, align 4, !alias.scope !3, !noalias !4
  %v11550 = load i64, ptr %slot2022, align 8
  %v11551 = load i64, ptr %slot45, align 8
  %p11552 = inttoptr i64 %v11551 to ptr
  store i64 %v11550, ptr %p11552, align 8, !alias.scope !3, !noalias !4
  %v11553 = load i64, ptr %slot80, align 8
  store i64 %v11553, ptr %slot2023, align 8
  %v11554 = load i64, ptr %slot2023, align 8
  %p11555 = inttoptr i64 %v11554 to ptr
  call void @llvm.memset.p0.i64(ptr %p11555, i8 0, i64 112, i1 false), !alias.scope !3, !noalias !4, !dbg !232
  %v11556 = load i64, ptr %slot2023, align 8
  %p11557 = inttoptr i64 %v11556 to ptr
  store i32 9, ptr %p11557, align 4, !alias.scope !3, !noalias !4
  %v11558 = load i64, ptr %slot23, align 8
  %p11559 = inttoptr i64 %v11558 to ptr
  store i32 1, ptr %p11559, align 4, !alias.scope !3, !noalias !4
  %v11560 = load i64, ptr %slot45, align 8
  %p11561 = inttoptr i64 %v11560 to ptr
  %ld11562 = load i64, ptr %p11561, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11562, ptr %slot2024, align 8
  %v11563 = load i64, ptr %slot2023, align 8
  %p11565 = inttoptr i64 %v11563 to ptr
  %gep11566 = getelementptr i8, ptr %p11565, i64 8
  %op11564 = ptrtoint ptr %gep11566 to i64
  store i64 %op11564, ptr %slot2025, align 8
  %v11567 = load i64, ptr %slot100, align 8
  store i64 %v11567, ptr %slot2026, align 8
  %v11568 = load i64, ptr %slot45, align 8
  %p11569 = inttoptr i64 %v11568 to ptr
  %ld11570 = load i64, ptr %p11569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11570, ptr %slot2027, align 8
  %v11571 = load i64, ptr %slot30, align 8
  store i64 %v11571, ptr %slot2028, align 8
  %v11572 = load i64, ptr %slot100, align 8
  store i64 %v11572, ptr %slot2029, align 8
  %v11573 = load i64, ptr %slot99, align 8
  %v11574 = load i64, ptr %slot2028, align 8
  %v11575 = load i64, ptr %slot2027, align 8
  %v11576 = load i64, ptr %slot2029, align 8
  %cv11577 = trunc i64 %v11576 to i32
  %call11578 = call i32 @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_take(i64 %v11573, i64 %v11574, i64 %v11575, i32 %cv11577) nomerge, !dbg !232
  store i32 %call11578, ptr %slot2030, align 8
  %v11579 = load i32, ptr %slot2030, align 8
  %cv11580 = zext i32 %v11579 to i64
  %cond11581 = icmp ne i64 %cv11580, 0
  br i1 %cond11581, label %bb_rcsuccess2712, label %bb_rcfailure2712
bb_rcfailure2712:
  %v11582 = load i64, ptr %slot99, align 8
  %p11583 = inttoptr i64 %v11582 to ptr
  %call11584 = call i32 @myl_rc_take_failure(ptr %p11583) nomerge, !dbg !232
  store i32 %call11584, ptr %slot2031, align 8
  %v11585 = load i64, ptr %slot1, align 8
  %p11586 = inttoptr i64 %v11585 to ptr
  %v11587 = load i32, ptr %slot2031, align 8
  %call11588 = call i32 @myl_qbe_rc_status(ptr %p11586, i32 %v11587) nomerge, !dbg !232
  store i32 %call11588, ptr %slot2032, align 8
  br label %bb_failure
bb_rcsuccess2712:
  %v11589 = load i64, ptr %slot17, align 8
  %p11590 = inttoptr i64 %v11589 to ptr
  store i32 0, ptr %p11590, align 4, !alias.scope !3, !noalias !4
  %v11591 = load i64, ptr %slot22, align 8
  %p11592 = inttoptr i64 %v11591 to ptr
  store i32 2, ptr %p11592, align 4, !alias.scope !3, !noalias !4
  %v11593 = load i64, ptr %slot21, align 8
  %p11594 = inttoptr i64 %v11593 to ptr
  store i32 1, ptr %p11594, align 4, !alias.scope !3, !noalias !4
  %v11595 = load i64, ptr %slot30, align 8
  store i64 %v11595, ptr %slot2033, align 8
  %v11596 = load i64, ptr %slot2033, align 8
  %v11597 = load i64, ptr %slot2025, align 8
  %p11598 = inttoptr i64 %v11596 to ptr
  %p11599 = inttoptr i64 %v11597 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11599, ptr %p11598, i64 56, i1 false), !alias.scope !3, !noalias !4
  %v11600 = load i64, ptr %slot21, align 8
  %p11601 = inttoptr i64 %v11600 to ptr
  store i32 0, ptr %p11601, align 4, !alias.scope !3, !noalias !4
  %v11602 = load i64, ptr %slot2023, align 8
  %v11603 = load i64, ptr %slot45, align 8
  %p11604 = inttoptr i64 %v11603 to ptr
  store i64 %v11602, ptr %p11604, align 8, !alias.scope !3, !noalias !4
  %v11605 = load i64, ptr %slot45, align 8
  %p11606 = inttoptr i64 %v11605 to ptr
  %ld11607 = load i64, ptr %p11606, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11607, ptr %slot2034, align 8
  %v11608 = load i64, ptr %slot25, align 8
  store i64 %v11608, ptr %slot2035, align 8
  %v11609 = load i64, ptr %slot2034, align 8
  %v11610 = load i64, ptr %slot2035, align 8
  %p11611 = inttoptr i64 %v11609 to ptr
  %p11612 = inttoptr i64 %v11610 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11612, ptr %p11611, i64 112, i1 false)
  %v11613 = load i64, ptr %slot18, align 8
  %p11614 = inttoptr i64 %v11613 to ptr
  store i32 2, ptr %p11614, align 4, !alias.scope !3, !noalias !4
  %v11615 = load i64, ptr %slot17, align 8
  %p11616 = inttoptr i64 %v11615 to ptr
  store i32 1, ptr %p11616, align 4, !alias.scope !3, !noalias !4
  %v11617 = load i64, ptr %slot2035, align 8
  %v11618 = load i64, ptr %slot45, align 8
  %p11619 = inttoptr i64 %v11618 to ptr
  store i64 %v11617, ptr %p11619, align 8, !alias.scope !3, !noalias !4
  %v11620 = load i64, ptr %slot44, align 8
  %p11621 = inttoptr i64 %v11620 to ptr
  %ld11622 = load i64, ptr %p11621, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11622, ptr %slot2036, align 8
  %v11623 = load i64, ptr %slot45, align 8
  %p11624 = inttoptr i64 %v11623 to ptr
  %ld11625 = load i64, ptr %p11624, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11625, ptr %slot2037, align 8
  %v11626 = load i64, ptr %slot1, align 8
  %v11627 = load i64, ptr %slot2036, align 8
  %v11628 = load i64, ptr %slot2037, align 8
  %call11629 = call i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64 %v11626, i64 %v11627, i64 %v11628) nomerge, !dbg !234
  store i64 %call11629, ptr %slot2038, align 8
  %v11630 = load i64, ptr %slot2038, align 8
  %v11631 = load i64, ptr %slot44, align 8
  %p11632 = inttoptr i64 %v11631 to ptr
  store i64 %v11630, ptr %p11632, align 8, !alias.scope !3, !noalias !4
  %v11633 = load i64, ptr %slot15, align 8
  %p11634 = inttoptr i64 %v11633 to ptr
  %ld11635 = load i32, ptr %p11634, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11635, ptr %slot2039, align 8
  %v11636 = load i32, ptr %slot2039, align 8
  %cv11637 = zext i32 %v11636 to i64
  %cond11638 = icmp ne i64 %cv11637, 0
  br i1 %cond11638, label %bb_rcslotdrop2729, label %bb_rcslotdone2729
bb_rcslotdrop2729:
  %v11639 = load i64, ptr %slot15, align 8
  %p11640 = inttoptr i64 %v11639 to ptr
  store i32 0, ptr %p11640, align 4, !alias.scope !3, !noalias !4
  %v11641 = load i64, ptr %slot24, align 8
  store i64 %v11641, ptr %slot2040, align 8
  %v11642 = load i64, ptr %slot16, align 8
  %p11643 = inttoptr i64 %v11642 to ptr
  %ld11644 = load i32, ptr %p11643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11644, ptr %slot2041, align 8
  %v11645 = load i32, ptr %slot2041, align 8
  %op11646 = and i32 %v11645, 28
  store i32 %op11646, ptr %slot2042, align 8
  %v11647 = load i32, ptr %slot2042, align 8
  %cv11648 = zext i32 %v11647 to i64
  %cond11649 = icmp ne i64 %cv11648, 0
  br i1 %cond11649, label %bb_rcslotrole2729, label %bb_rcslotowner2729
bb_rcslotrole2729:
  %v11650 = load i64, ptr %slot99, align 8
  store i64 %v11650, ptr %slot2043, align 8
  %v11651 = load i64, ptr %slot2043, align 8
  %v11652 = load i64, ptr %slot2040, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v11651, i64 %v11652) nomerge, !dbg !234
  br label %bb_rcslotdone2729
bb_rcslotowner2729:
  %v11653 = load i64, ptr %slot99, align 8
  store i64 %v11653, ptr %slot2044, align 8
  %v11654 = load i64, ptr %slot2044, align 8
  %v11655 = load i64, ptr %slot2040, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v11654, i64 %v11655) nomerge, !dbg !234
  br label %bb_rcslotdone2729
bb_rcslotdone2729:
  %v11656 = load i64, ptr %slot17, align 8
  %p11657 = inttoptr i64 %v11656 to ptr
  %ld11658 = load i32, ptr %p11657, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11658, ptr %slot2045, align 8
  %v11659 = load i32, ptr %slot2045, align 8
  %cv11660 = zext i32 %v11659 to i64
  %cond11661 = icmp ne i64 %cv11660, 0
  br i1 %cond11661, label %bb_rcslotdrop2738, label %bb_rcslotdone2738
bb_rcslotdrop2738:
  %v11662 = load i64, ptr %slot17, align 8
  %p11663 = inttoptr i64 %v11662 to ptr
  store i32 0, ptr %p11663, align 4, !alias.scope !3, !noalias !4
  %v11664 = load i64, ptr %slot25, align 8
  store i64 %v11664, ptr %slot2046, align 8
  %v11665 = load i64, ptr %slot18, align 8
  %p11666 = inttoptr i64 %v11665 to ptr
  %ld11667 = load i32, ptr %p11666, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11667, ptr %slot2047, align 8
  %v11668 = load i32, ptr %slot2047, align 8
  %op11669 = and i32 %v11668, 28
  store i32 %op11669, ptr %slot2048, align 8
  %v11670 = load i32, ptr %slot2048, align 8
  %cv11671 = zext i32 %v11670 to i64
  %cond11672 = icmp ne i64 %cv11671, 0
  br i1 %cond11672, label %bb_rcslotrole2738, label %bb_rcslotowner2738
bb_rcslotrole2738:
  %v11673 = load i64, ptr %slot99, align 8
  store i64 %v11673, ptr %slot2049, align 8
  %v11674 = load i64, ptr %slot2049, align 8
  %v11675 = load i64, ptr %slot2046, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v11674, i64 %v11675) nomerge, !dbg !234
  br label %bb_rcslotdone2738
bb_rcslotowner2738:
  %v11676 = load i64, ptr %slot99, align 8
  store i64 %v11676, ptr %slot2050, align 8
  %v11677 = load i64, ptr %slot2050, align 8
  %v11678 = load i64, ptr %slot2046, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v11677, i64 %v11678) nomerge, !dbg !234
  br label %bb_rcslotdone2738
bb_rcslotdone2738:
  %v11679 = load i64, ptr %slot81, align 8
  store i64 %v11679, ptr %slot2051, align 8
  %v11680 = load i64, ptr %slot2051, align 8
  %p11681 = inttoptr i64 %v11680 to ptr
  store i64 0, ptr %p11681, align 8, !alias.scope !3, !noalias !4
  %v11682 = load i64, ptr %slot2051, align 8
  %p11684 = inttoptr i64 %v11682 to ptr
  %gep11685 = getelementptr i8, ptr %p11684, i64 8
  %op11683 = ptrtoint ptr %gep11685 to i64
  store i64 %op11683, ptr %slot2052, align 8
  %v11686 = load i64, ptr %slot2052, align 8
  %p11687 = inttoptr i64 %v11686 to ptr
  store i64 0, ptr %p11687, align 8, !alias.scope !3, !noalias !4
  %v11688 = load i64, ptr %slot2051, align 8
  %p11689 = inttoptr i64 %v11688 to ptr
  store i32 0, ptr %p11689, align 4, !alias.scope !3, !noalias !4
  %v11690 = load i64, ptr %slot23, align 8
  %p11691 = inttoptr i64 %v11690 to ptr
  store i32 1, ptr %p11691, align 4, !alias.scope !3, !noalias !4
  %v11692 = load i64, ptr %slot44, align 8
  store i64 %v11692, ptr %slot2053, align 8
  %v11693 = load i64, ptr %slot2051, align 8
  %p11695 = inttoptr i64 %v11693 to ptr
  %gep11696 = getelementptr i8, ptr %p11695, i64 8
  %op11694 = ptrtoint ptr %gep11696 to i64
  store i64 %op11694, ptr %slot2054, align 8
  %v11697 = load i64, ptr %slot100, align 8
  store i64 %v11697, ptr %slot2055, align 8
  %v11698 = load i64, ptr %slot2053, align 8
  %p11699 = inttoptr i64 %v11698 to ptr
  %ld11700 = load i64, ptr %p11699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11700, ptr %slot2056, align 8
  %v11701 = load i64, ptr %slot2056, align 8
  %v11702 = load i64, ptr %slot2054, align 8
  %p11703 = inttoptr i64 %v11702 to ptr
  store i64 %v11701, ptr %p11703, align 8, !alias.scope !3, !noalias !4
  %v11704 = load i64, ptr %slot2051, align 8
  %v11705 = load i64, ptr %slot44, align 8
  %p11706 = inttoptr i64 %v11705 to ptr
  store i64 %v11704, ptr %p11706, align 8, !alias.scope !3, !noalias !4
  %v11707 = load i64, ptr %slot44, align 8
  %p11708 = inttoptr i64 %v11707 to ptr
  %ld11709 = load i64, ptr %p11708, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11709, ptr %slot2057, align 8
  %v11710 = load i64, ptr %slot15, align 8
  %p11711 = inttoptr i64 %v11710 to ptr
  %ld11712 = load i32, ptr %p11711, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11712, ptr %slot2058, align 8
  %v11713 = load i32, ptr %slot2058, align 8
  %cv11714 = zext i32 %v11713 to i64
  %cond11715 = icmp ne i64 %cv11714, 0
  br i1 %cond11715, label %bb_rcslotdrop2756, label %bb_rcslotdone2756
bb_rcslotdrop2756:
  %v11716 = load i64, ptr %slot15, align 8
  %p11717 = inttoptr i64 %v11716 to ptr
  store i32 0, ptr %p11717, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2756
bb_rcslotdone2756:
  %v11718 = load i64, ptr %slot13, align 8
  %p11719 = inttoptr i64 %v11718 to ptr
  %ld11720 = load i32, ptr %p11719, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11720, ptr %slot2059, align 8
  %v11721 = load i32, ptr %slot2059, align 8
  %cv11722 = zext i32 %v11721 to i64
  %cond11723 = icmp ne i64 %cv11722, 0
  br i1 %cond11723, label %bb_rcslotdrop2759, label %bb_rcslotdone2759
bb_rcslotdrop2759:
  %v11724 = load i64, ptr %slot13, align 8
  %p11725 = inttoptr i64 %v11724 to ptr
  store i32 0, ptr %p11725, align 4, !alias.scope !3, !noalias !4
  %v11726 = load i64, ptr %slot42, align 8
  store i64 %v11726, ptr %slot2060, align 8
  %v11727 = load i64, ptr %slot14, align 8
  %p11728 = inttoptr i64 %v11727 to ptr
  %ld11729 = load i32, ptr %p11728, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11729, ptr %slot2061, align 8
  %v11730 = load i32, ptr %slot2061, align 8
  %op11731 = and i32 %v11730, 28
  store i32 %op11731, ptr %slot2062, align 8
  %v11732 = load i32, ptr %slot2062, align 8
  %cv11733 = zext i32 %v11732 to i64
  %cond11734 = icmp ne i64 %cv11733, 0
  br i1 %cond11734, label %bb_rcslotrole2759, label %bb_rcslotowner2759
bb_rcslotrole2759:
  %v11735 = load i64, ptr %slot99, align 8
  store i64 %v11735, ptr %slot2063, align 8
  %v11736 = load i64, ptr %slot2063, align 8
  %v11737 = load i64, ptr %slot2060, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v11736, i64 %v11737) nomerge, !dbg !236
  br label %bb_rcslotdone2759
bb_rcslotowner2759:
  %v11738 = load i64, ptr %slot99, align 8
  store i64 %v11738, ptr %slot2064, align 8
  %v11739 = load i64, ptr %slot2064, align 8
  %v11740 = load i64, ptr %slot2060, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v11739, i64 %v11740) nomerge, !dbg !236
  br label %bb_rcslotdone2759
bb_rcslotdone2759:
  %v11741 = load i64, ptr %slot11, align 8
  %p11742 = inttoptr i64 %v11741 to ptr
  %ld11743 = load i32, ptr %p11742, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11743, ptr %slot2065, align 8
  %v11744 = load i32, ptr %slot2065, align 8
  %cv11745 = zext i32 %v11744 to i64
  %cond11746 = icmp ne i64 %cv11745, 0
  br i1 %cond11746, label %bb_rcslotdrop2768, label %bb_rcslotdone2768
bb_rcslotdrop2768:
  %v11747 = load i64, ptr %slot11, align 8
  %p11748 = inttoptr i64 %v11747 to ptr
  store i32 0, ptr %p11748, align 4, !alias.scope !3, !noalias !4
  %v11749 = load i64, ptr %slot41, align 8
  store i64 %v11749, ptr %slot2066, align 8
  %v11750 = load i64, ptr %slot12, align 8
  %p11751 = inttoptr i64 %v11750 to ptr
  %ld11752 = load i32, ptr %p11751, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11752, ptr %slot2067, align 8
  %v11753 = load i32, ptr %slot2067, align 8
  %op11754 = and i32 %v11753, 28
  store i32 %op11754, ptr %slot2068, align 8
  %v11755 = load i32, ptr %slot2068, align 8
  %cv11756 = zext i32 %v11755 to i64
  %cond11757 = icmp ne i64 %cv11756, 0
  br i1 %cond11757, label %bb_rcslotrole2768, label %bb_rcslotowner2768
bb_rcslotrole2768:
  %v11758 = load i64, ptr %slot99, align 8
  store i64 %v11758, ptr %slot2069, align 8
  %v11759 = load i64, ptr %slot2069, align 8
  %v11760 = load i64, ptr %slot2066, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v11759, i64 %v11760) nomerge, !dbg !236
  br label %bb_rcslotdone2768
bb_rcslotowner2768:
  %v11761 = load i64, ptr %slot99, align 8
  store i64 %v11761, ptr %slot2070, align 8
  %v11762 = load i64, ptr %slot2070, align 8
  %v11763 = load i64, ptr %slot2066, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v11762, i64 %v11763) nomerge, !dbg !236
  br label %bb_rcslotdone2768
bb_rcslotdone2768:
  %v11764 = load i64, ptr %slot9, align 8
  %p11765 = inttoptr i64 %v11764 to ptr
  %ld11766 = load i32, ptr %p11765, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11766, ptr %slot2071, align 8
  %v11767 = load i32, ptr %slot2071, align 8
  %cv11768 = zext i32 %v11767 to i64
  %cond11769 = icmp ne i64 %cv11768, 0
  br i1 %cond11769, label %bb_rcslotdrop2777, label %bb_rcslotdone2777
bb_rcslotdrop2777:
  %v11770 = load i64, ptr %slot9, align 8
  %p11771 = inttoptr i64 %v11770 to ptr
  store i32 0, ptr %p11771, align 4, !alias.scope !3, !noalias !4
  %v11772 = load i64, ptr %slot39, align 8
  store i64 %v11772, ptr %slot2072, align 8
  %v11773 = load i64, ptr %slot10, align 8
  %p11774 = inttoptr i64 %v11773 to ptr
  %ld11775 = load i32, ptr %p11774, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11775, ptr %slot2073, align 8
  %v11776 = load i32, ptr %slot2073, align 8
  %op11777 = and i32 %v11776, 28
  store i32 %op11777, ptr %slot2074, align 8
  %v11778 = load i32, ptr %slot2074, align 8
  %cv11779 = zext i32 %v11778 to i64
  %cond11780 = icmp ne i64 %cv11779, 0
  br i1 %cond11780, label %bb_rcslotrole2777, label %bb_rcslotowner2777
bb_rcslotrole2777:
  %v11781 = load i64, ptr %slot99, align 8
  store i64 %v11781, ptr %slot2075, align 8
  %v11782 = load i64, ptr %slot2072, align 8
  %p11783 = inttoptr i64 %v11782 to ptr
  %ld11784 = load i64, ptr %p11783, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11784, ptr %slot2076, align 8
  %v11785 = load i64, ptr %slot2076, align 8
  %cmp11786 = icmp ne i64 %v11785, 0
  %cv11787 = zext i1 %cmp11786 to i32
  store i32 %cv11787, ptr %slot2077, align 8
  %v11788 = load i32, ptr %slot2077, align 8
  %cv11789 = zext i32 %v11788 to i64
  %cond11790 = icmp ne i64 %cv11789, 0
  br i1 %cond11790, label %bb_rcgnn2793, label %bb_rcgdone2793
bb_rcgnn2793:
  %v11791 = load i64, ptr %slot2076, align 8
  %op11792 = sub i64 %v11791, 16
  store i64 %op11792, ptr %slot2078, align 8
  %v11793 = load i64, ptr %slot2076, align 8
  %p11794 = inttoptr i64 %v11793 to ptr
  %rgep11795 = getelementptr i8, ptr %p11794, i64 -16
  %ld11796 = load i64, ptr %rgep11795, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11796, ptr %slot2079, align 8
  %v11797 = load i64, ptr %slot2079, align 8
  %op11798 = and i64 %v11797, 4611686018427387906
  store i64 %op11798, ptr %slot2080, align 8
  %v11799 = load i64, ptr %slot2080, align 8
  %cmp11800 = icmp ne i64 %v11799, 0
  %cv11801 = zext i1 %cmp11800 to i32
  store i32 %cv11801, ptr %slot2081, align 8
  %v11802 = load i32, ptr %slot2081, align 8
  %cv11803 = zext i32 %v11802 to i64
  %cond11804 = icmp ne i64 %cv11803, 0
  br i1 %cond11804, label %bb_rcgclear2793, label %bb_rcgcounted2793
bb_rcgcounted2793:
  %v11805 = load i64, ptr %slot2076, align 8
  %op11806 = sub i64 %v11805, 24
  store i64 %op11806, ptr %slot2082, align 8
  %v11807 = load i64, ptr %slot2076, align 8
  %p11808 = inttoptr i64 %v11807 to ptr
  %rgep11809 = getelementptr i8, ptr %p11808, i64 -24
  %ld11810 = load i64, ptr %rgep11809, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11810, ptr %slot2083, align 8
  %v11811 = load i64, ptr %slot2083, align 8
  %op11812 = sub i64 %v11811, 1
  store i64 %op11812, ptr %slot2084, align 8
  %v11813 = load i64, ptr %slot2084, align 8
  %cmp11814 = icmp eq i64 %v11813, 0
  %cv11815 = zext i1 %cmp11814 to i32
  store i32 %cv11815, ptr %slot2085, align 8
  %v11816 = load i32, ptr %slot2085, align 8
  %cv11817 = zext i32 %v11816 to i64
  %cond11818 = icmp ne i64 %cv11817, 0
  br i1 %cond11818, label %bb_rcglast2793, label %bb_rcgdec2793
bb_rcglast2793:
  %v11819 = load i64, ptr %slot2076, align 8
  %op11820 = sub i64 %v11819, 32
  store i64 %op11820, ptr %slot2086, align 8
  %v11821 = load i64, ptr %slot2076, align 8
  %p11822 = inttoptr i64 %v11821 to ptr
  %rgep11823 = getelementptr i8, ptr %p11822, i64 -32
  %ld11824 = load i64, ptr %rgep11823, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11824, ptr %slot2087, align 8
  %v11825 = load i64, ptr %slot2087, align 8
  %cmp11826 = icmp ne i64 %v11825, 0
  %cv11827 = zext i1 %cmp11826 to i32
  store i32 %cv11827, ptr %slot2088, align 8
  %v11828 = load i32, ptr %slot2088, align 8
  %cv11829 = zext i32 %v11828 to i64
  %cond11830 = icmp ne i64 %cv11829, 0
  br i1 %cond11830, label %bb_rcgdec2793, label %bb_rcgslow2793
bb_rcgslow2793:
  %v11831 = load i64, ptr %slot2075, align 8
  %v11832 = load i64, ptr %slot2072, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v11831, i64 %v11832) nomerge, !dbg !236
  br label %bb_rcgdone2793
bb_rcgdec2793:
  %v11833 = load i64, ptr %slot2084, align 8
  %v11834 = load i64, ptr %slot2076, align 8
  %p11835 = inttoptr i64 %v11834 to ptr
  %rgep11836 = getelementptr i8, ptr %p11835, i64 -24
  store i64 %v11833, ptr %rgep11836, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2793
bb_rcgclear2793:
  %v11837 = load i64, ptr %slot2072, align 8
  %p11838 = inttoptr i64 %v11837 to ptr
  store i64 0, ptr %p11838, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2793
bb_rcgdone2793:
  br label %bb_rcslotdone2777
bb_rcslotowner2777:
  %v11839 = load i64, ptr %slot99, align 8
  store i64 %v11839, ptr %slot2089, align 8
  %v11840 = load i64, ptr %slot2072, align 8
  %p11841 = inttoptr i64 %v11840 to ptr
  %ld11842 = load i64, ptr %p11841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11842, ptr %slot2090, align 8
  %v11843 = load i64, ptr %slot2090, align 8
  %cmp11844 = icmp ne i64 %v11843, 0
  %cv11845 = zext i1 %cmp11844 to i32
  store i32 %cv11845, ptr %slot2091, align 8
  %v11846 = load i32, ptr %slot2091, align 8
  %cv11847 = zext i32 %v11846 to i64
  %cond11848 = icmp ne i64 %cv11847, 0
  br i1 %cond11848, label %bb_rcgnn2808, label %bb_rcgdone2808
bb_rcgnn2808:
  %v11849 = load i64, ptr %slot2090, align 8
  %op11850 = sub i64 %v11849, 16
  store i64 %op11850, ptr %slot2092, align 8
  %v11851 = load i64, ptr %slot2090, align 8
  %p11852 = inttoptr i64 %v11851 to ptr
  %rgep11853 = getelementptr i8, ptr %p11852, i64 -16
  %ld11854 = load i64, ptr %rgep11853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11854, ptr %slot2093, align 8
  %v11855 = load i64, ptr %slot2093, align 8
  %op11856 = and i64 %v11855, 4611686018427387906
  store i64 %op11856, ptr %slot2094, align 8
  %v11857 = load i64, ptr %slot2094, align 8
  %cmp11858 = icmp ne i64 %v11857, 0
  %cv11859 = zext i1 %cmp11858 to i32
  store i32 %cv11859, ptr %slot2095, align 8
  %v11860 = load i32, ptr %slot2095, align 8
  %cv11861 = zext i32 %v11860 to i64
  %cond11862 = icmp ne i64 %cv11861, 0
  br i1 %cond11862, label %bb_rcgclear2808, label %bb_rcgcounted2808
bb_rcgcounted2808:
  %v11863 = load i64, ptr %slot2090, align 8
  %op11864 = sub i64 %v11863, 32
  store i64 %op11864, ptr %slot2096, align 8
  %v11865 = load i64, ptr %slot2090, align 8
  %p11866 = inttoptr i64 %v11865 to ptr
  %rgep11867 = getelementptr i8, ptr %p11866, i64 -32
  %ld11868 = load i64, ptr %rgep11867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11868, ptr %slot2097, align 8
  %v11869 = load i64, ptr %slot2097, align 8
  %op11870 = sub i64 %v11869, 1
  store i64 %op11870, ptr %slot2098, align 8
  %v11871 = load i64, ptr %slot2098, align 8
  %cmp11872 = icmp eq i64 %v11871, 0
  %cv11873 = zext i1 %cmp11872 to i32
  store i32 %cv11873, ptr %slot2099, align 8
  %v11874 = load i32, ptr %slot2099, align 8
  %cv11875 = zext i32 %v11874 to i64
  %cond11876 = icmp ne i64 %cv11875, 0
  br i1 %cond11876, label %bb_rcglast2808, label %bb_rcgdec2808
bb_rcglast2808:
  %v11877 = load i64, ptr %slot2090, align 8
  %op11878 = sub i64 %v11877, 24
  store i64 %op11878, ptr %slot2100, align 8
  %v11879 = load i64, ptr %slot2090, align 8
  %p11880 = inttoptr i64 %v11879 to ptr
  %rgep11881 = getelementptr i8, ptr %p11880, i64 -24
  %ld11882 = load i64, ptr %rgep11881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11882, ptr %slot2101, align 8
  %v11883 = load i64, ptr %slot2101, align 8
  %cmp11884 = icmp ne i64 %v11883, 0
  %cv11885 = zext i1 %cmp11884 to i32
  store i32 %cv11885, ptr %slot2102, align 8
  %v11886 = load i32, ptr %slot2102, align 8
  %cv11887 = zext i32 %v11886 to i64
  %cond11888 = icmp ne i64 %cv11887, 0
  br i1 %cond11888, label %bb_rcgdec2808, label %bb_rcgslow2808
bb_rcgslow2808:
  %v11889 = load i64, ptr %slot2089, align 8
  %v11890 = load i64, ptr %slot2072, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v11889, i64 %v11890) nomerge, !dbg !236
  br label %bb_rcgdone2808
bb_rcgdec2808:
  %v11891 = load i64, ptr %slot2098, align 8
  %v11892 = load i64, ptr %slot2090, align 8
  %p11893 = inttoptr i64 %v11892 to ptr
  %rgep11894 = getelementptr i8, ptr %p11893, i64 -32
  store i64 %v11891, ptr %rgep11894, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2808
bb_rcgclear2808:
  %v11895 = load i64, ptr %slot2072, align 8
  %p11896 = inttoptr i64 %v11895 to ptr
  store i64 0, ptr %p11896, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2808
bb_rcgdone2808:
  br label %bb_rcslotdone2777
bb_rcslotdone2777:
  %v11897 = load i64, ptr %slot7, align 8
  %p11898 = inttoptr i64 %v11897 to ptr
  %ld11899 = load i32, ptr %p11898, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11899, ptr %slot2103, align 8
  %v11900 = load i32, ptr %slot2103, align 8
  %cv11901 = zext i32 %v11900 to i64
  %cond11902 = icmp ne i64 %cv11901, 0
  br i1 %cond11902, label %bb_rcslotdrop2814, label %bb_rcslotdone2814
bb_rcslotdrop2814:
  %v11903 = load i64, ptr %slot7, align 8
  %p11904 = inttoptr i64 %v11903 to ptr
  store i32 0, ptr %p11904, align 4, !alias.scope !3, !noalias !4
  %v11905 = load i64, ptr %slot34, align 8
  store i64 %v11905, ptr %slot2104, align 8
  %v11906 = load i64, ptr %slot8, align 8
  %p11907 = inttoptr i64 %v11906 to ptr
  %ld11908 = load i32, ptr %p11907, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11908, ptr %slot2105, align 8
  %v11909 = load i32, ptr %slot2105, align 8
  %op11910 = and i32 %v11909, 28
  store i32 %op11910, ptr %slot2106, align 8
  %v11911 = load i32, ptr %slot2106, align 8
  %cv11912 = zext i32 %v11911 to i64
  %cond11913 = icmp ne i64 %cv11912, 0
  br i1 %cond11913, label %bb_rcslotrole2814, label %bb_rcslotowner2814
bb_rcslotrole2814:
  %v11914 = load i64, ptr %slot99, align 8
  store i64 %v11914, ptr %slot2107, align 8
  %v11915 = load i64, ptr %slot2104, align 8
  %p11916 = inttoptr i64 %v11915 to ptr
  %ld11917 = load i64, ptr %p11916, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11917, ptr %slot2108, align 8
  %v11918 = load i64, ptr %slot2108, align 8
  %cmp11919 = icmp ne i64 %v11918, 0
  %cv11920 = zext i1 %cmp11919 to i32
  store i32 %cv11920, ptr %slot2109, align 8
  %v11921 = load i32, ptr %slot2109, align 8
  %cv11922 = zext i32 %v11921 to i64
  %cond11923 = icmp ne i64 %cv11922, 0
  br i1 %cond11923, label %bb_rcgnn2830, label %bb_rcgdone2830
bb_rcgnn2830:
  %v11924 = load i64, ptr %slot2108, align 8
  %op11925 = sub i64 %v11924, 16
  store i64 %op11925, ptr %slot2110, align 8
  %v11926 = load i64, ptr %slot2108, align 8
  %p11927 = inttoptr i64 %v11926 to ptr
  %rgep11928 = getelementptr i8, ptr %p11927, i64 -16
  %ld11929 = load i64, ptr %rgep11928, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11929, ptr %slot2111, align 8
  %v11930 = load i64, ptr %slot2111, align 8
  %op11931 = and i64 %v11930, 4611686018427387906
  store i64 %op11931, ptr %slot2112, align 8
  %v11932 = load i64, ptr %slot2112, align 8
  %cmp11933 = icmp ne i64 %v11932, 0
  %cv11934 = zext i1 %cmp11933 to i32
  store i32 %cv11934, ptr %slot2113, align 8
  %v11935 = load i32, ptr %slot2113, align 8
  %cv11936 = zext i32 %v11935 to i64
  %cond11937 = icmp ne i64 %cv11936, 0
  br i1 %cond11937, label %bb_rcgclear2830, label %bb_rcgcounted2830
bb_rcgcounted2830:
  %v11938 = load i64, ptr %slot2108, align 8
  %op11939 = sub i64 %v11938, 24
  store i64 %op11939, ptr %slot2114, align 8
  %v11940 = load i64, ptr %slot2108, align 8
  %p11941 = inttoptr i64 %v11940 to ptr
  %rgep11942 = getelementptr i8, ptr %p11941, i64 -24
  %ld11943 = load i64, ptr %rgep11942, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11943, ptr %slot2115, align 8
  %v11944 = load i64, ptr %slot2115, align 8
  %op11945 = sub i64 %v11944, 1
  store i64 %op11945, ptr %slot2116, align 8
  %v11946 = load i64, ptr %slot2116, align 8
  %cmp11947 = icmp eq i64 %v11946, 0
  %cv11948 = zext i1 %cmp11947 to i32
  store i32 %cv11948, ptr %slot2117, align 8
  %v11949 = load i32, ptr %slot2117, align 8
  %cv11950 = zext i32 %v11949 to i64
  %cond11951 = icmp ne i64 %cv11950, 0
  br i1 %cond11951, label %bb_rcglast2830, label %bb_rcgdec2830
bb_rcglast2830:
  %v11952 = load i64, ptr %slot2108, align 8
  %op11953 = sub i64 %v11952, 32
  store i64 %op11953, ptr %slot2118, align 8
  %v11954 = load i64, ptr %slot2108, align 8
  %p11955 = inttoptr i64 %v11954 to ptr
  %rgep11956 = getelementptr i8, ptr %p11955, i64 -32
  %ld11957 = load i64, ptr %rgep11956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11957, ptr %slot2119, align 8
  %v11958 = load i64, ptr %slot2119, align 8
  %cmp11959 = icmp ne i64 %v11958, 0
  %cv11960 = zext i1 %cmp11959 to i32
  store i32 %cv11960, ptr %slot2120, align 8
  %v11961 = load i32, ptr %slot2120, align 8
  %cv11962 = zext i32 %v11961 to i64
  %cond11963 = icmp ne i64 %cv11962, 0
  br i1 %cond11963, label %bb_rcgdec2830, label %bb_rcgslow2830
bb_rcgslow2830:
  %v11964 = load i64, ptr %slot2107, align 8
  %v11965 = load i64, ptr %slot2104, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v11964, i64 %v11965) nomerge, !dbg !236
  br label %bb_rcgdone2830
bb_rcgdec2830:
  %v11966 = load i64, ptr %slot2116, align 8
  %v11967 = load i64, ptr %slot2108, align 8
  %p11968 = inttoptr i64 %v11967 to ptr
  %rgep11969 = getelementptr i8, ptr %p11968, i64 -24
  store i64 %v11966, ptr %rgep11969, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2830
bb_rcgclear2830:
  %v11970 = load i64, ptr %slot2104, align 8
  %p11971 = inttoptr i64 %v11970 to ptr
  store i64 0, ptr %p11971, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2830
bb_rcgdone2830:
  br label %bb_rcslotdone2814
bb_rcslotowner2814:
  %v11972 = load i64, ptr %slot99, align 8
  store i64 %v11972, ptr %slot2121, align 8
  %v11973 = load i64, ptr %slot2104, align 8
  %p11974 = inttoptr i64 %v11973 to ptr
  %ld11975 = load i64, ptr %p11974, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11975, ptr %slot2122, align 8
  %v11976 = load i64, ptr %slot2122, align 8
  %cmp11977 = icmp ne i64 %v11976, 0
  %cv11978 = zext i1 %cmp11977 to i32
  store i32 %cv11978, ptr %slot2123, align 8
  %v11979 = load i32, ptr %slot2123, align 8
  %cv11980 = zext i32 %v11979 to i64
  %cond11981 = icmp ne i64 %cv11980, 0
  br i1 %cond11981, label %bb_rcgnn2845, label %bb_rcgdone2845
bb_rcgnn2845:
  %v11982 = load i64, ptr %slot2122, align 8
  %op11983 = sub i64 %v11982, 16
  store i64 %op11983, ptr %slot2124, align 8
  %v11984 = load i64, ptr %slot2122, align 8
  %p11985 = inttoptr i64 %v11984 to ptr
  %rgep11986 = getelementptr i8, ptr %p11985, i64 -16
  %ld11987 = load i64, ptr %rgep11986, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11987, ptr %slot2125, align 8
  %v11988 = load i64, ptr %slot2125, align 8
  %op11989 = and i64 %v11988, 4611686018427387906
  store i64 %op11989, ptr %slot2126, align 8
  %v11990 = load i64, ptr %slot2126, align 8
  %cmp11991 = icmp ne i64 %v11990, 0
  %cv11992 = zext i1 %cmp11991 to i32
  store i32 %cv11992, ptr %slot2127, align 8
  %v11993 = load i32, ptr %slot2127, align 8
  %cv11994 = zext i32 %v11993 to i64
  %cond11995 = icmp ne i64 %cv11994, 0
  br i1 %cond11995, label %bb_rcgclear2845, label %bb_rcgcounted2845
bb_rcgcounted2845:
  %v11996 = load i64, ptr %slot2122, align 8
  %op11997 = sub i64 %v11996, 32
  store i64 %op11997, ptr %slot2128, align 8
  %v11998 = load i64, ptr %slot2122, align 8
  %p11999 = inttoptr i64 %v11998 to ptr
  %rgep12000 = getelementptr i8, ptr %p11999, i64 -32
  %ld12001 = load i64, ptr %rgep12000, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12001, ptr %slot2129, align 8
  %v12002 = load i64, ptr %slot2129, align 8
  %op12003 = sub i64 %v12002, 1
  store i64 %op12003, ptr %slot2130, align 8
  %v12004 = load i64, ptr %slot2130, align 8
  %cmp12005 = icmp eq i64 %v12004, 0
  %cv12006 = zext i1 %cmp12005 to i32
  store i32 %cv12006, ptr %slot2131, align 8
  %v12007 = load i32, ptr %slot2131, align 8
  %cv12008 = zext i32 %v12007 to i64
  %cond12009 = icmp ne i64 %cv12008, 0
  br i1 %cond12009, label %bb_rcglast2845, label %bb_rcgdec2845
bb_rcglast2845:
  %v12010 = load i64, ptr %slot2122, align 8
  %op12011 = sub i64 %v12010, 24
  store i64 %op12011, ptr %slot2132, align 8
  %v12012 = load i64, ptr %slot2122, align 8
  %p12013 = inttoptr i64 %v12012 to ptr
  %rgep12014 = getelementptr i8, ptr %p12013, i64 -24
  %ld12015 = load i64, ptr %rgep12014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12015, ptr %slot2133, align 8
  %v12016 = load i64, ptr %slot2133, align 8
  %cmp12017 = icmp ne i64 %v12016, 0
  %cv12018 = zext i1 %cmp12017 to i32
  store i32 %cv12018, ptr %slot2134, align 8
  %v12019 = load i32, ptr %slot2134, align 8
  %cv12020 = zext i32 %v12019 to i64
  %cond12021 = icmp ne i64 %cv12020, 0
  br i1 %cond12021, label %bb_rcgdec2845, label %bb_rcgslow2845
bb_rcgslow2845:
  %v12022 = load i64, ptr %slot2121, align 8
  %v12023 = load i64, ptr %slot2104, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v12022, i64 %v12023) nomerge, !dbg !236
  br label %bb_rcgdone2845
bb_rcgdec2845:
  %v12024 = load i64, ptr %slot2130, align 8
  %v12025 = load i64, ptr %slot2122, align 8
  %p12026 = inttoptr i64 %v12025 to ptr
  %rgep12027 = getelementptr i8, ptr %p12026, i64 -32
  store i64 %v12024, ptr %rgep12027, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2845
bb_rcgclear2845:
  %v12028 = load i64, ptr %slot2104, align 8
  %p12029 = inttoptr i64 %v12028 to ptr
  store i64 0, ptr %p12029, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2845
bb_rcgdone2845:
  br label %bb_rcslotdone2814
bb_rcslotdone2814:
  %v12030 = load i64, ptr %slot5, align 8
  %p12031 = inttoptr i64 %v12030 to ptr
  %ld12032 = load i32, ptr %p12031, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12032, ptr %slot2135, align 8
  %v12033 = load i32, ptr %slot2135, align 8
  %cv12034 = zext i32 %v12033 to i64
  %cond12035 = icmp ne i64 %cv12034, 0
  br i1 %cond12035, label %bb_rcslotdrop2851, label %bb_rcslotdone2851
bb_rcslotdrop2851:
  %v12036 = load i64, ptr %slot5, align 8
  %p12037 = inttoptr i64 %v12036 to ptr
  store i32 0, ptr %p12037, align 4, !alias.scope !3, !noalias !4
  %v12038 = load i64, ptr %slot33, align 8
  store i64 %v12038, ptr %slot2136, align 8
  %v12039 = load i64, ptr %slot6, align 8
  %p12040 = inttoptr i64 %v12039 to ptr
  %ld12041 = load i32, ptr %p12040, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12041, ptr %slot2137, align 8
  %v12042 = load i32, ptr %slot2137, align 8
  %op12043 = and i32 %v12042, 28
  store i32 %op12043, ptr %slot2138, align 8
  %v12044 = load i32, ptr %slot2138, align 8
  %cv12045 = zext i32 %v12044 to i64
  %cond12046 = icmp ne i64 %cv12045, 0
  br i1 %cond12046, label %bb_rcslotrole2851, label %bb_rcslotowner2851
bb_rcslotrole2851:
  %v12047 = load i64, ptr %slot99, align 8
  store i64 %v12047, ptr %slot2139, align 8
  %v12048 = load i64, ptr %slot2139, align 8
  %v12049 = load i64, ptr %slot2136, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v12048, i64 %v12049) nomerge, !dbg !236
  br label %bb_rcslotdone2851
bb_rcslotowner2851:
  %v12050 = load i64, ptr %slot99, align 8
  store i64 %v12050, ptr %slot2140, align 8
  %v12051 = load i64, ptr %slot2140, align 8
  %v12052 = load i64, ptr %slot2136, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v12051, i64 %v12052) nomerge, !dbg !236
  br label %bb_rcslotdone2851
bb_rcslotdone2851:
  %v12053 = load i64, ptr %slot2057, align 8
  %p12054 = inttoptr i64 %v12053 to ptr
  %ret12055 = load { i64, i64 }, ptr %p12054, align 8
  ret { i64, i64 } %ret12055
bb_i154:
  %v12056 = load i64, ptr %slot32, align 8
  %p12057 = inttoptr i64 %v12056 to ptr
  %ld12058 = load i64, ptr %p12057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12058, ptr %slot2141, align 8
  %v12059 = load i64, ptr %slot2141, align 8
  %v12060 = load i64, ptr %slot44, align 8
  %p12061 = inttoptr i64 %v12060 to ptr
  store i64 %v12059, ptr %p12061, align 8, !alias.scope !3, !noalias !4
  %v12062 = load i64, ptr %slot82, align 8
  store i64 %v12062, ptr %slot2142, align 8
  %v12063 = load i64, ptr %slot2142, align 8
  %p12064 = inttoptr i64 %v12063 to ptr
  store i32 0, ptr %p12064, align 4, !alias.scope !3, !noalias !4
  %v12065 = load i64, ptr %slot2142, align 8
  %p12066 = inttoptr i64 %v12065 to ptr
  store i32 19, ptr %p12066, align 4, !alias.scope !3, !noalias !4
  %v12067 = load i64, ptr %slot2142, align 8
  %v12068 = load i64, ptr %slot45, align 8
  %p12069 = inttoptr i64 %v12068 to ptr
  store i64 %v12067, ptr %p12069, align 8, !alias.scope !3, !noalias !4
  %v12070 = load i64, ptr %slot44, align 8
  %p12071 = inttoptr i64 %v12070 to ptr
  %ld12072 = load i64, ptr %p12071, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12072, ptr %slot2143, align 8
  %v12073 = load i64, ptr %slot45, align 8
  %p12074 = inttoptr i64 %v12073 to ptr
  %ld12075 = load i64, ptr %p12074, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12075, ptr %slot2144, align 8
  %v12076 = load i64, ptr %slot1, align 8
  %v12077 = load i64, ptr %slot2143, align 8
  %v12078 = load i64, ptr %slot2144, align 8
  %call12079 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v12076, i64 %v12077, i64 %v12078) nomerge, !dbg !238
  store i64 %call12079, ptr %slot2145, align 8
  %v12080 = load i64, ptr %slot2145, align 8
  %v12081 = load i64, ptr %slot44, align 8
  %p12082 = inttoptr i64 %v12081 to ptr
  store i64 %v12080, ptr %p12082, align 8, !alias.scope !3, !noalias !4
  %v12083 = load i64, ptr %slot15, align 8
  %p12084 = inttoptr i64 %v12083 to ptr
  %ld12085 = load i32, ptr %p12084, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12085, ptr %slot2146, align 8
  %v12086 = load i32, ptr %slot2146, align 8
  %cv12087 = zext i32 %v12086 to i64
  %cond12088 = icmp ne i64 %cv12087, 0
  br i1 %cond12088, label %bb_rcslotdrop2874, label %bb_rcslotdone2874
bb_rcslotdrop2874:
  %v12089 = load i64, ptr %slot15, align 8
  %p12090 = inttoptr i64 %v12089 to ptr
  store i32 0, ptr %p12090, align 4, !alias.scope !3, !noalias !4
  %v12091 = load i64, ptr %slot24, align 8
  store i64 %v12091, ptr %slot2147, align 8
  %v12092 = load i64, ptr %slot16, align 8
  %p12093 = inttoptr i64 %v12092 to ptr
  %ld12094 = load i32, ptr %p12093, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12094, ptr %slot2148, align 8
  %v12095 = load i32, ptr %slot2148, align 8
  %op12096 = and i32 %v12095, 28
  store i32 %op12096, ptr %slot2149, align 8
  %v12097 = load i32, ptr %slot2149, align 8
  %cv12098 = zext i32 %v12097 to i64
  %cond12099 = icmp ne i64 %cv12098, 0
  br i1 %cond12099, label %bb_rcslotrole2874, label %bb_rcslotowner2874
bb_rcslotrole2874:
  %v12100 = load i64, ptr %slot99, align 8
  store i64 %v12100, ptr %slot2150, align 8
  %v12101 = load i64, ptr %slot2150, align 8
  %v12102 = load i64, ptr %slot2147, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v12101, i64 %v12102) nomerge, !dbg !238
  br label %bb_rcslotdone2874
bb_rcslotowner2874:
  %v12103 = load i64, ptr %slot99, align 8
  store i64 %v12103, ptr %slot2151, align 8
  %v12104 = load i64, ptr %slot2151, align 8
  %v12105 = load i64, ptr %slot2147, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v12104, i64 %v12105) nomerge, !dbg !238
  br label %bb_rcslotdone2874
bb_rcslotdone2874:
  %v12106 = load i64, ptr %slot44, align 8
  %p12107 = inttoptr i64 %v12106 to ptr
  %ld12108 = load i64, ptr %p12107, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12108, ptr %slot2152, align 8
  %v12109 = load i64, ptr %slot2152, align 8
  %cond12110 = icmp ne i64 %v12109, 0
  br i1 %cond12110, label %bb_next2882, label %bb_i164
bb_next2882:
  %v12111 = load i64, ptr %slot32, align 8
  %p12112 = inttoptr i64 %v12111 to ptr
  %ld12113 = load i64, ptr %p12112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12113, ptr %slot2153, align 8
  %v12114 = load i64, ptr %slot2153, align 8
  %v12115 = load i64, ptr %slot44, align 8
  %p12116 = inttoptr i64 %v12115 to ptr
  store i64 %v12114, ptr %p12116, align 8, !alias.scope !3, !noalias !4
  %v12117 = load i64, ptr %slot32, align 8
  %p12118 = inttoptr i64 %v12117 to ptr
  %ld12119 = load i64, ptr %p12118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12119, ptr %slot2154, align 8
  %v12120 = load i64, ptr %slot2154, align 8
  %v12121 = load i64, ptr %slot83, align 8
  %p12122 = inttoptr i64 %v12120 to ptr
  %p12123 = inttoptr i64 %v12121 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12123, ptr %p12122, i64 312, i1 false), !alias.scope !10000000
  %v12124 = load i64, ptr %slot83, align 8
  %v12125 = load i64, ptr %slot45, align 8
  %p12126 = inttoptr i64 %v12125 to ptr
  store i64 %v12124, ptr %p12126, align 8, !alias.scope !3, !noalias !4
  %v12127 = load i64, ptr %slot45, align 8
  %p12128 = inttoptr i64 %v12127 to ptr
  %ld12129 = load i64, ptr %p12128, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12129, ptr %slot2155, align 8
  %v12130 = load i64, ptr %slot1, align 8
  %v12131 = load i64, ptr %slot2155, align 8
  call void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8 %callresult2157, i64 %v12130, i64 %v12131) nomerge, !dbg !240
  %addr12132 = ptrtoint ptr %callresult2157 to i64
  store i64 %addr12132, ptr %slot2156, align 8
  %v12133 = load i64, ptr %slot2156, align 8
  %v12134 = load i64, ptr %slot45, align 8
  %p12135 = inttoptr i64 %v12134 to ptr
  store i64 %v12133, ptr %p12135, align 8, !alias.scope !3, !noalias !4
  %v12136 = load i64, ptr %slot45, align 8
  %p12137 = inttoptr i64 %v12136 to ptr
  %ld12138 = load i64, ptr %p12137, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12138, ptr %slot2158, align 8
  %v12139 = load i64, ptr %slot30, align 8
  store i64 %v12139, ptr %slot2159, align 8
  %v12140 = load i64, ptr %slot99, align 8
  %v12141 = load i64, ptr %slot2159, align 8
  %v12142 = load i64, ptr %slot2158, align 8
  %call12143 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v12140, i64 %v12141, i64 %v12142) nomerge, !dbg !240
  store i32 %call12143, ptr %slot2160, align 8
  %v12144 = load i32, ptr %slot2160, align 8
  %cv12145 = zext i32 %v12144 to i64
  %cond12146 = icmp ne i64 %cv12145, 0
  br i1 %cond12146, label %bb_rcsuccess2889, label %bb_rcfailure2889
bb_rcfailure2889:
  %v12147 = load i64, ptr %slot99, align 8
  %p12148 = inttoptr i64 %v12147 to ptr
  %call12149 = call i32 @myl_rc_take_failure(ptr %p12148) nomerge, !dbg !240
  store i32 %call12149, ptr %slot2161, align 8
  %v12150 = load i64, ptr %slot1, align 8
  %p12151 = inttoptr i64 %v12150 to ptr
  %v12152 = load i32, ptr %slot2161, align 8
  %call12153 = call i32 @myl_qbe_rc_status(ptr %p12151, i32 %v12152) nomerge, !dbg !240
  store i32 %call12153, ptr %slot2162, align 8
  br label %bb_failure
bb_rcsuccess2889:
  %v12154 = load i64, ptr %slot22, align 8
  %p12155 = inttoptr i64 %v12154 to ptr
  store i32 2, ptr %p12155, align 4, !alias.scope !3, !noalias !4
  %v12156 = load i64, ptr %slot22, align 8
  %p12157 = inttoptr i64 %v12156 to ptr
  store i32 16, ptr %p12157, align 4, !alias.scope !3, !noalias !4
  %v12158 = load i64, ptr %slot21, align 8
  %p12159 = inttoptr i64 %v12158 to ptr
  store i32 1, ptr %p12159, align 4, !alias.scope !3, !noalias !4
  %v12160 = load i64, ptr %slot17, align 8
  %p12161 = inttoptr i64 %v12160 to ptr
  %ld12162 = load i32, ptr %p12161, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12162, ptr %slot2163, align 8
  %v12163 = load i32, ptr %slot2163, align 8
  %cv12164 = zext i32 %v12163 to i64
  %cond12165 = icmp ne i64 %cv12164, 0
  br i1 %cond12165, label %bb_rcslotdrop2897, label %bb_rcslotdone2897
bb_rcslotdrop2897:
  %v12166 = load i64, ptr %slot17, align 8
  %p12167 = inttoptr i64 %v12166 to ptr
  store i32 0, ptr %p12167, align 4, !alias.scope !3, !noalias !4
  %v12168 = load i64, ptr %slot25, align 8
  store i64 %v12168, ptr %slot2164, align 8
  %v12169 = load i64, ptr %slot18, align 8
  %p12170 = inttoptr i64 %v12169 to ptr
  %ld12171 = load i32, ptr %p12170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12171, ptr %slot2165, align 8
  %v12172 = load i32, ptr %slot2165, align 8
  %op12173 = and i32 %v12172, 28
  store i32 %op12173, ptr %slot2166, align 8
  %v12174 = load i32, ptr %slot2166, align 8
  %cv12175 = zext i32 %v12174 to i64
  %cond12176 = icmp ne i64 %cv12175, 0
  br i1 %cond12176, label %bb_rcslotrole2897, label %bb_rcslotowner2897
bb_rcslotrole2897:
  %v12177 = load i64, ptr %slot99, align 8
  store i64 %v12177, ptr %slot2167, align 8
  %v12178 = load i64, ptr %slot2167, align 8
  %v12179 = load i64, ptr %slot2164, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v12178, i64 %v12179) nomerge, !dbg !240
  br label %bb_rcslotdone2897
bb_rcslotowner2897:
  %v12180 = load i64, ptr %slot99, align 8
  store i64 %v12180, ptr %slot2168, align 8
  %v12181 = load i64, ptr %slot2168, align 8
  %v12182 = load i64, ptr %slot2164, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v12181, i64 %v12182) nomerge, !dbg !240
  br label %bb_rcslotdone2897
bb_rcslotdone2897:
  %v12183 = load i64, ptr %slot25, align 8
  store i64 %v12183, ptr %slot2169, align 8
  %v12184 = load i64, ptr %slot30, align 8
  store i64 %v12184, ptr %slot2170, align 8
  %v12185 = load i64, ptr %slot2170, align 8
  %v12186 = load i64, ptr %slot2169, align 8
  %p12187 = inttoptr i64 %v12185 to ptr
  %p12188 = inttoptr i64 %v12186 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12188, ptr %p12187, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v12189 = load i64, ptr %slot18, align 8
  %p12190 = inttoptr i64 %v12189 to ptr
  store i32 2, ptr %p12190, align 4, !alias.scope !3, !noalias !4
  %v12191 = load i64, ptr %slot22, align 8
  %p12192 = inttoptr i64 %v12191 to ptr
  %ld12193 = load i32, ptr %p12192, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12193, ptr %slot2171, align 8
  %v12194 = load i32, ptr %slot2171, align 8
  %v12195 = load i64, ptr %slot18, align 8
  %p12196 = inttoptr i64 %v12195 to ptr
  store i32 %v12194, ptr %p12196, align 4, !alias.scope !3, !noalias !4
  %v12197 = load i64, ptr %slot21, align 8
  %p12198 = inttoptr i64 %v12197 to ptr
  store i32 0, ptr %p12198, align 4, !alias.scope !3, !noalias !4
  %v12199 = load i64, ptr %slot17, align 8
  %p12200 = inttoptr i64 %v12199 to ptr
  store i32 1, ptr %p12200, align 4, !alias.scope !3, !noalias !4
  %v12201 = load i64, ptr %slot2169, align 8
  %v12202 = load i64, ptr %slot45, align 8
  %p12203 = inttoptr i64 %v12202 to ptr
  store i64 %v12201, ptr %p12203, align 8, !alias.scope !3, !noalias !4
  %v12204 = load i64, ptr %slot44, align 8
  %p12205 = inttoptr i64 %v12204 to ptr
  %ld12206 = load i64, ptr %p12205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12206, ptr %slot2172, align 8
  %v12207 = load i64, ptr %slot45, align 8
  %p12208 = inttoptr i64 %v12207 to ptr
  %ld12209 = load i64, ptr %p12208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12209, ptr %slot2173, align 8
  %v12210 = load i64, ptr %slot1, align 8
  %v12211 = load i64, ptr %slot2172, align 8
  %v12212 = load i64, ptr %slot2173, align 8
  %call12213 = call i64 @myl_f_95ed024ac5550fa33e3709a22f37afe61493456c867352f03a4d43811a49c125(i64 %v12210, i64 %v12211, i64 %v12212) nomerge, !dbg !242
  store i64 %call12213, ptr %slot2174, align 8
  %v12214 = load i64, ptr %slot2174, align 8
  %v12215 = load i64, ptr %slot44, align 8
  %p12216 = inttoptr i64 %v12215 to ptr
  store i64 %v12214, ptr %p12216, align 8, !alias.scope !3, !noalias !4
  %v12217 = load i64, ptr %slot15, align 8
  %p12218 = inttoptr i64 %v12217 to ptr
  %ld12219 = load i32, ptr %p12218, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12219, ptr %slot2175, align 8
  %v12220 = load i32, ptr %slot2175, align 8
  %cv12221 = zext i32 %v12220 to i64
  %cond12222 = icmp ne i64 %cv12221, 0
  br i1 %cond12222, label %bb_rcslotdrop2917, label %bb_rcslotdone2917
bb_rcslotdrop2917:
  %v12223 = load i64, ptr %slot15, align 8
  %p12224 = inttoptr i64 %v12223 to ptr
  store i32 0, ptr %p12224, align 4, !alias.scope !3, !noalias !4
  %v12225 = load i64, ptr %slot24, align 8
  store i64 %v12225, ptr %slot2176, align 8
  %v12226 = load i64, ptr %slot16, align 8
  %p12227 = inttoptr i64 %v12226 to ptr
  %ld12228 = load i32, ptr %p12227, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12228, ptr %slot2177, align 8
  %v12229 = load i32, ptr %slot2177, align 8
  %op12230 = and i32 %v12229, 28
  store i32 %op12230, ptr %slot2178, align 8
  %v12231 = load i32, ptr %slot2178, align 8
  %cv12232 = zext i32 %v12231 to i64
  %cond12233 = icmp ne i64 %cv12232, 0
  br i1 %cond12233, label %bb_rcslotrole2917, label %bb_rcslotowner2917
bb_rcslotrole2917:
  %v12234 = load i64, ptr %slot99, align 8
  store i64 %v12234, ptr %slot2179, align 8
  %v12235 = load i64, ptr %slot2179, align 8
  %v12236 = load i64, ptr %slot2176, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v12235, i64 %v12236) nomerge, !dbg !242
  br label %bb_rcslotdone2917
bb_rcslotowner2917:
  %v12237 = load i64, ptr %slot99, align 8
  store i64 %v12237, ptr %slot2180, align 8
  %v12238 = load i64, ptr %slot2180, align 8
  %v12239 = load i64, ptr %slot2176, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v12238, i64 %v12239) nomerge, !dbg !242
  br label %bb_rcslotdone2917
bb_rcslotdone2917:
  %v12240 = load i64, ptr %slot17, align 8
  %p12241 = inttoptr i64 %v12240 to ptr
  %ld12242 = load i32, ptr %p12241, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12242, ptr %slot2181, align 8
  %v12243 = load i32, ptr %slot2181, align 8
  %cv12244 = zext i32 %v12243 to i64
  %cond12245 = icmp ne i64 %cv12244, 0
  br i1 %cond12245, label %bb_rcslotdrop2926, label %bb_rcslotdone2926
bb_rcslotdrop2926:
  %v12246 = load i64, ptr %slot17, align 8
  %p12247 = inttoptr i64 %v12246 to ptr
  store i32 0, ptr %p12247, align 4, !alias.scope !3, !noalias !4
  %v12248 = load i64, ptr %slot25, align 8
  store i64 %v12248, ptr %slot2182, align 8
  %v12249 = load i64, ptr %slot18, align 8
  %p12250 = inttoptr i64 %v12249 to ptr
  %ld12251 = load i32, ptr %p12250, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12251, ptr %slot2183, align 8
  %v12252 = load i32, ptr %slot2183, align 8
  %op12253 = and i32 %v12252, 28
  store i32 %op12253, ptr %slot2184, align 8
  %v12254 = load i32, ptr %slot2184, align 8
  %cv12255 = zext i32 %v12254 to i64
  %cond12256 = icmp ne i64 %cv12255, 0
  br i1 %cond12256, label %bb_rcslotrole2926, label %bb_rcslotowner2926
bb_rcslotrole2926:
  %v12257 = load i64, ptr %slot99, align 8
  store i64 %v12257, ptr %slot2185, align 8
  %v12258 = load i64, ptr %slot2185, align 8
  %v12259 = load i64, ptr %slot2182, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v12258, i64 %v12259) nomerge, !dbg !242
  br label %bb_rcslotdone2926
bb_rcslotowner2926:
  %v12260 = load i64, ptr %slot99, align 8
  store i64 %v12260, ptr %slot2186, align 8
  %v12261 = load i64, ptr %slot2186, align 8
  %v12262 = load i64, ptr %slot2182, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v12261, i64 %v12262) nomerge, !dbg !242
  br label %bb_rcslotdone2926
bb_rcslotdone2926:
  %v12263 = load i64, ptr %slot84, align 8
  store i64 %v12263, ptr %slot2187, align 8
  %v12264 = load i64, ptr %slot2187, align 8
  %p12265 = inttoptr i64 %v12264 to ptr
  store i64 0, ptr %p12265, align 8, !alias.scope !3, !noalias !4
  %v12266 = load i64, ptr %slot2187, align 8
  %p12268 = inttoptr i64 %v12266 to ptr
  %gep12269 = getelementptr i8, ptr %p12268, i64 8
  %op12267 = ptrtoint ptr %gep12269 to i64
  store i64 %op12267, ptr %slot2188, align 8
  %v12270 = load i64, ptr %slot2188, align 8
  %p12271 = inttoptr i64 %v12270 to ptr
  store i64 0, ptr %p12271, align 8, !alias.scope !3, !noalias !4
  %v12272 = load i64, ptr %slot2187, align 8
  %p12273 = inttoptr i64 %v12272 to ptr
  store i32 0, ptr %p12273, align 4, !alias.scope !3, !noalias !4
  %v12274 = load i64, ptr %slot23, align 8
  %p12275 = inttoptr i64 %v12274 to ptr
  store i32 1, ptr %p12275, align 4, !alias.scope !3, !noalias !4
  %v12276 = load i64, ptr %slot44, align 8
  store i64 %v12276, ptr %slot2189, align 8
  %v12277 = load i64, ptr %slot2187, align 8
  %p12279 = inttoptr i64 %v12277 to ptr
  %gep12280 = getelementptr i8, ptr %p12279, i64 8
  %op12278 = ptrtoint ptr %gep12280 to i64
  store i64 %op12278, ptr %slot2190, align 8
  %v12281 = load i64, ptr %slot100, align 8
  store i64 %v12281, ptr %slot2191, align 8
  %v12282 = load i64, ptr %slot2189, align 8
  %p12283 = inttoptr i64 %v12282 to ptr
  %ld12284 = load i64, ptr %p12283, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12284, ptr %slot2192, align 8
  %v12285 = load i64, ptr %slot2192, align 8
  %v12286 = load i64, ptr %slot2190, align 8
  %p12287 = inttoptr i64 %v12286 to ptr
  store i64 %v12285, ptr %p12287, align 8, !alias.scope !3, !noalias !4
  %v12288 = load i64, ptr %slot2187, align 8
  %v12289 = load i64, ptr %slot44, align 8
  %p12290 = inttoptr i64 %v12289 to ptr
  store i64 %v12288, ptr %p12290, align 8, !alias.scope !3, !noalias !4
  %v12291 = load i64, ptr %slot44, align 8
  %p12292 = inttoptr i64 %v12291 to ptr
  %ld12293 = load i64, ptr %p12292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12293, ptr %slot2193, align 8
  %v12294 = load i64, ptr %slot15, align 8
  %p12295 = inttoptr i64 %v12294 to ptr
  %ld12296 = load i32, ptr %p12295, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12296, ptr %slot2194, align 8
  %v12297 = load i32, ptr %slot2194, align 8
  %cv12298 = zext i32 %v12297 to i64
  %cond12299 = icmp ne i64 %cv12298, 0
  br i1 %cond12299, label %bb_rcslotdrop2944, label %bb_rcslotdone2944
bb_rcslotdrop2944:
  %v12300 = load i64, ptr %slot15, align 8
  %p12301 = inttoptr i64 %v12300 to ptr
  store i32 0, ptr %p12301, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone2944
bb_rcslotdone2944:
  %v12302 = load i64, ptr %slot13, align 8
  %p12303 = inttoptr i64 %v12302 to ptr
  %ld12304 = load i32, ptr %p12303, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12304, ptr %slot2195, align 8
  %v12305 = load i32, ptr %slot2195, align 8
  %cv12306 = zext i32 %v12305 to i64
  %cond12307 = icmp ne i64 %cv12306, 0
  br i1 %cond12307, label %bb_rcslotdrop2947, label %bb_rcslotdone2947
bb_rcslotdrop2947:
  %v12308 = load i64, ptr %slot13, align 8
  %p12309 = inttoptr i64 %v12308 to ptr
  store i32 0, ptr %p12309, align 4, !alias.scope !3, !noalias !4
  %v12310 = load i64, ptr %slot42, align 8
  store i64 %v12310, ptr %slot2196, align 8
  %v12311 = load i64, ptr %slot14, align 8
  %p12312 = inttoptr i64 %v12311 to ptr
  %ld12313 = load i32, ptr %p12312, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12313, ptr %slot2197, align 8
  %v12314 = load i32, ptr %slot2197, align 8
  %op12315 = and i32 %v12314, 28
  store i32 %op12315, ptr %slot2198, align 8
  %v12316 = load i32, ptr %slot2198, align 8
  %cv12317 = zext i32 %v12316 to i64
  %cond12318 = icmp ne i64 %cv12317, 0
  br i1 %cond12318, label %bb_rcslotrole2947, label %bb_rcslotowner2947
bb_rcslotrole2947:
  %v12319 = load i64, ptr %slot99, align 8
  store i64 %v12319, ptr %slot2199, align 8
  %v12320 = load i64, ptr %slot2199, align 8
  %v12321 = load i64, ptr %slot2196, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v12320, i64 %v12321) nomerge, !dbg !244
  br label %bb_rcslotdone2947
bb_rcslotowner2947:
  %v12322 = load i64, ptr %slot99, align 8
  store i64 %v12322, ptr %slot2200, align 8
  %v12323 = load i64, ptr %slot2200, align 8
  %v12324 = load i64, ptr %slot2196, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v12323, i64 %v12324) nomerge, !dbg !244
  br label %bb_rcslotdone2947
bb_rcslotdone2947:
  %v12325 = load i64, ptr %slot11, align 8
  %p12326 = inttoptr i64 %v12325 to ptr
  %ld12327 = load i32, ptr %p12326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12327, ptr %slot2201, align 8
  %v12328 = load i32, ptr %slot2201, align 8
  %cv12329 = zext i32 %v12328 to i64
  %cond12330 = icmp ne i64 %cv12329, 0
  br i1 %cond12330, label %bb_rcslotdrop2956, label %bb_rcslotdone2956
bb_rcslotdrop2956:
  %v12331 = load i64, ptr %slot11, align 8
  %p12332 = inttoptr i64 %v12331 to ptr
  store i32 0, ptr %p12332, align 4, !alias.scope !3, !noalias !4
  %v12333 = load i64, ptr %slot41, align 8
  store i64 %v12333, ptr %slot2202, align 8
  %v12334 = load i64, ptr %slot12, align 8
  %p12335 = inttoptr i64 %v12334 to ptr
  %ld12336 = load i32, ptr %p12335, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12336, ptr %slot2203, align 8
  %v12337 = load i32, ptr %slot2203, align 8
  %op12338 = and i32 %v12337, 28
  store i32 %op12338, ptr %slot2204, align 8
  %v12339 = load i32, ptr %slot2204, align 8
  %cv12340 = zext i32 %v12339 to i64
  %cond12341 = icmp ne i64 %cv12340, 0
  br i1 %cond12341, label %bb_rcslotrole2956, label %bb_rcslotowner2956
bb_rcslotrole2956:
  %v12342 = load i64, ptr %slot99, align 8
  store i64 %v12342, ptr %slot2205, align 8
  %v12343 = load i64, ptr %slot2205, align 8
  %v12344 = load i64, ptr %slot2202, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v12343, i64 %v12344) nomerge, !dbg !244
  br label %bb_rcslotdone2956
bb_rcslotowner2956:
  %v12345 = load i64, ptr %slot99, align 8
  store i64 %v12345, ptr %slot2206, align 8
  %v12346 = load i64, ptr %slot2206, align 8
  %v12347 = load i64, ptr %slot2202, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v12346, i64 %v12347) nomerge, !dbg !244
  br label %bb_rcslotdone2956
bb_rcslotdone2956:
  %v12348 = load i64, ptr %slot9, align 8
  %p12349 = inttoptr i64 %v12348 to ptr
  %ld12350 = load i32, ptr %p12349, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12350, ptr %slot2207, align 8
  %v12351 = load i32, ptr %slot2207, align 8
  %cv12352 = zext i32 %v12351 to i64
  %cond12353 = icmp ne i64 %cv12352, 0
  br i1 %cond12353, label %bb_rcslotdrop2965, label %bb_rcslotdone2965
bb_rcslotdrop2965:
  %v12354 = load i64, ptr %slot9, align 8
  %p12355 = inttoptr i64 %v12354 to ptr
  store i32 0, ptr %p12355, align 4, !alias.scope !3, !noalias !4
  %v12356 = load i64, ptr %slot39, align 8
  store i64 %v12356, ptr %slot2208, align 8
  %v12357 = load i64, ptr %slot10, align 8
  %p12358 = inttoptr i64 %v12357 to ptr
  %ld12359 = load i32, ptr %p12358, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12359, ptr %slot2209, align 8
  %v12360 = load i32, ptr %slot2209, align 8
  %op12361 = and i32 %v12360, 28
  store i32 %op12361, ptr %slot2210, align 8
  %v12362 = load i32, ptr %slot2210, align 8
  %cv12363 = zext i32 %v12362 to i64
  %cond12364 = icmp ne i64 %cv12363, 0
  br i1 %cond12364, label %bb_rcslotrole2965, label %bb_rcslotowner2965
bb_rcslotrole2965:
  %v12365 = load i64, ptr %slot99, align 8
  store i64 %v12365, ptr %slot2211, align 8
  %v12366 = load i64, ptr %slot2208, align 8
  %p12367 = inttoptr i64 %v12366 to ptr
  %ld12368 = load i64, ptr %p12367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12368, ptr %slot2212, align 8
  %v12369 = load i64, ptr %slot2212, align 8
  %cmp12370 = icmp ne i64 %v12369, 0
  %cv12371 = zext i1 %cmp12370 to i32
  store i32 %cv12371, ptr %slot2213, align 8
  %v12372 = load i32, ptr %slot2213, align 8
  %cv12373 = zext i32 %v12372 to i64
  %cond12374 = icmp ne i64 %cv12373, 0
  br i1 %cond12374, label %bb_rcgnn2981, label %bb_rcgdone2981
bb_rcgnn2981:
  %v12375 = load i64, ptr %slot2212, align 8
  %op12376 = sub i64 %v12375, 16
  store i64 %op12376, ptr %slot2214, align 8
  %v12377 = load i64, ptr %slot2212, align 8
  %p12378 = inttoptr i64 %v12377 to ptr
  %rgep12379 = getelementptr i8, ptr %p12378, i64 -16
  %ld12380 = load i64, ptr %rgep12379, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12380, ptr %slot2215, align 8
  %v12381 = load i64, ptr %slot2215, align 8
  %op12382 = and i64 %v12381, 4611686018427387906
  store i64 %op12382, ptr %slot2216, align 8
  %v12383 = load i64, ptr %slot2216, align 8
  %cmp12384 = icmp ne i64 %v12383, 0
  %cv12385 = zext i1 %cmp12384 to i32
  store i32 %cv12385, ptr %slot2217, align 8
  %v12386 = load i32, ptr %slot2217, align 8
  %cv12387 = zext i32 %v12386 to i64
  %cond12388 = icmp ne i64 %cv12387, 0
  br i1 %cond12388, label %bb_rcgclear2981, label %bb_rcgcounted2981
bb_rcgcounted2981:
  %v12389 = load i64, ptr %slot2212, align 8
  %op12390 = sub i64 %v12389, 24
  store i64 %op12390, ptr %slot2218, align 8
  %v12391 = load i64, ptr %slot2212, align 8
  %p12392 = inttoptr i64 %v12391 to ptr
  %rgep12393 = getelementptr i8, ptr %p12392, i64 -24
  %ld12394 = load i64, ptr %rgep12393, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12394, ptr %slot2219, align 8
  %v12395 = load i64, ptr %slot2219, align 8
  %op12396 = sub i64 %v12395, 1
  store i64 %op12396, ptr %slot2220, align 8
  %v12397 = load i64, ptr %slot2220, align 8
  %cmp12398 = icmp eq i64 %v12397, 0
  %cv12399 = zext i1 %cmp12398 to i32
  store i32 %cv12399, ptr %slot2221, align 8
  %v12400 = load i32, ptr %slot2221, align 8
  %cv12401 = zext i32 %v12400 to i64
  %cond12402 = icmp ne i64 %cv12401, 0
  br i1 %cond12402, label %bb_rcglast2981, label %bb_rcgdec2981
bb_rcglast2981:
  %v12403 = load i64, ptr %slot2212, align 8
  %op12404 = sub i64 %v12403, 32
  store i64 %op12404, ptr %slot2222, align 8
  %v12405 = load i64, ptr %slot2212, align 8
  %p12406 = inttoptr i64 %v12405 to ptr
  %rgep12407 = getelementptr i8, ptr %p12406, i64 -32
  %ld12408 = load i64, ptr %rgep12407, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12408, ptr %slot2223, align 8
  %v12409 = load i64, ptr %slot2223, align 8
  %cmp12410 = icmp ne i64 %v12409, 0
  %cv12411 = zext i1 %cmp12410 to i32
  store i32 %cv12411, ptr %slot2224, align 8
  %v12412 = load i32, ptr %slot2224, align 8
  %cv12413 = zext i32 %v12412 to i64
  %cond12414 = icmp ne i64 %cv12413, 0
  br i1 %cond12414, label %bb_rcgdec2981, label %bb_rcgslow2981
bb_rcgslow2981:
  %v12415 = load i64, ptr %slot2211, align 8
  %v12416 = load i64, ptr %slot2208, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v12415, i64 %v12416) nomerge, !dbg !244
  br label %bb_rcgdone2981
bb_rcgdec2981:
  %v12417 = load i64, ptr %slot2220, align 8
  %v12418 = load i64, ptr %slot2212, align 8
  %p12419 = inttoptr i64 %v12418 to ptr
  %rgep12420 = getelementptr i8, ptr %p12419, i64 -24
  store i64 %v12417, ptr %rgep12420, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2981
bb_rcgclear2981:
  %v12421 = load i64, ptr %slot2208, align 8
  %p12422 = inttoptr i64 %v12421 to ptr
  store i64 0, ptr %p12422, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2981
bb_rcgdone2981:
  br label %bb_rcslotdone2965
bb_rcslotowner2965:
  %v12423 = load i64, ptr %slot99, align 8
  store i64 %v12423, ptr %slot2225, align 8
  %v12424 = load i64, ptr %slot2208, align 8
  %p12425 = inttoptr i64 %v12424 to ptr
  %ld12426 = load i64, ptr %p12425, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12426, ptr %slot2226, align 8
  %v12427 = load i64, ptr %slot2226, align 8
  %cmp12428 = icmp ne i64 %v12427, 0
  %cv12429 = zext i1 %cmp12428 to i32
  store i32 %cv12429, ptr %slot2227, align 8
  %v12430 = load i32, ptr %slot2227, align 8
  %cv12431 = zext i32 %v12430 to i64
  %cond12432 = icmp ne i64 %cv12431, 0
  br i1 %cond12432, label %bb_rcgnn2996, label %bb_rcgdone2996
bb_rcgnn2996:
  %v12433 = load i64, ptr %slot2226, align 8
  %op12434 = sub i64 %v12433, 16
  store i64 %op12434, ptr %slot2228, align 8
  %v12435 = load i64, ptr %slot2226, align 8
  %p12436 = inttoptr i64 %v12435 to ptr
  %rgep12437 = getelementptr i8, ptr %p12436, i64 -16
  %ld12438 = load i64, ptr %rgep12437, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12438, ptr %slot2229, align 8
  %v12439 = load i64, ptr %slot2229, align 8
  %op12440 = and i64 %v12439, 4611686018427387906
  store i64 %op12440, ptr %slot2230, align 8
  %v12441 = load i64, ptr %slot2230, align 8
  %cmp12442 = icmp ne i64 %v12441, 0
  %cv12443 = zext i1 %cmp12442 to i32
  store i32 %cv12443, ptr %slot2231, align 8
  %v12444 = load i32, ptr %slot2231, align 8
  %cv12445 = zext i32 %v12444 to i64
  %cond12446 = icmp ne i64 %cv12445, 0
  br i1 %cond12446, label %bb_rcgclear2996, label %bb_rcgcounted2996
bb_rcgcounted2996:
  %v12447 = load i64, ptr %slot2226, align 8
  %op12448 = sub i64 %v12447, 32
  store i64 %op12448, ptr %slot2232, align 8
  %v12449 = load i64, ptr %slot2226, align 8
  %p12450 = inttoptr i64 %v12449 to ptr
  %rgep12451 = getelementptr i8, ptr %p12450, i64 -32
  %ld12452 = load i64, ptr %rgep12451, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12452, ptr %slot2233, align 8
  %v12453 = load i64, ptr %slot2233, align 8
  %op12454 = sub i64 %v12453, 1
  store i64 %op12454, ptr %slot2234, align 8
  %v12455 = load i64, ptr %slot2234, align 8
  %cmp12456 = icmp eq i64 %v12455, 0
  %cv12457 = zext i1 %cmp12456 to i32
  store i32 %cv12457, ptr %slot2235, align 8
  %v12458 = load i32, ptr %slot2235, align 8
  %cv12459 = zext i32 %v12458 to i64
  %cond12460 = icmp ne i64 %cv12459, 0
  br i1 %cond12460, label %bb_rcglast2996, label %bb_rcgdec2996
bb_rcglast2996:
  %v12461 = load i64, ptr %slot2226, align 8
  %op12462 = sub i64 %v12461, 24
  store i64 %op12462, ptr %slot2236, align 8
  %v12463 = load i64, ptr %slot2226, align 8
  %p12464 = inttoptr i64 %v12463 to ptr
  %rgep12465 = getelementptr i8, ptr %p12464, i64 -24
  %ld12466 = load i64, ptr %rgep12465, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12466, ptr %slot2237, align 8
  %v12467 = load i64, ptr %slot2237, align 8
  %cmp12468 = icmp ne i64 %v12467, 0
  %cv12469 = zext i1 %cmp12468 to i32
  store i32 %cv12469, ptr %slot2238, align 8
  %v12470 = load i32, ptr %slot2238, align 8
  %cv12471 = zext i32 %v12470 to i64
  %cond12472 = icmp ne i64 %cv12471, 0
  br i1 %cond12472, label %bb_rcgdec2996, label %bb_rcgslow2996
bb_rcgslow2996:
  %v12473 = load i64, ptr %slot2225, align 8
  %v12474 = load i64, ptr %slot2208, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v12473, i64 %v12474) nomerge, !dbg !244
  br label %bb_rcgdone2996
bb_rcgdec2996:
  %v12475 = load i64, ptr %slot2234, align 8
  %v12476 = load i64, ptr %slot2226, align 8
  %p12477 = inttoptr i64 %v12476 to ptr
  %rgep12478 = getelementptr i8, ptr %p12477, i64 -32
  store i64 %v12475, ptr %rgep12478, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2996
bb_rcgclear2996:
  %v12479 = load i64, ptr %slot2208, align 8
  %p12480 = inttoptr i64 %v12479 to ptr
  store i64 0, ptr %p12480, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2996
bb_rcgdone2996:
  br label %bb_rcslotdone2965
bb_rcslotdone2965:
  %v12481 = load i64, ptr %slot7, align 8
  %p12482 = inttoptr i64 %v12481 to ptr
  %ld12483 = load i32, ptr %p12482, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12483, ptr %slot2239, align 8
  %v12484 = load i32, ptr %slot2239, align 8
  %cv12485 = zext i32 %v12484 to i64
  %cond12486 = icmp ne i64 %cv12485, 0
  br i1 %cond12486, label %bb_rcslotdrop3002, label %bb_rcslotdone3002
bb_rcslotdrop3002:
  %v12487 = load i64, ptr %slot7, align 8
  %p12488 = inttoptr i64 %v12487 to ptr
  store i32 0, ptr %p12488, align 4, !alias.scope !3, !noalias !4
  %v12489 = load i64, ptr %slot34, align 8
  store i64 %v12489, ptr %slot2240, align 8
  %v12490 = load i64, ptr %slot8, align 8
  %p12491 = inttoptr i64 %v12490 to ptr
  %ld12492 = load i32, ptr %p12491, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12492, ptr %slot2241, align 8
  %v12493 = load i32, ptr %slot2241, align 8
  %op12494 = and i32 %v12493, 28
  store i32 %op12494, ptr %slot2242, align 8
  %v12495 = load i32, ptr %slot2242, align 8
  %cv12496 = zext i32 %v12495 to i64
  %cond12497 = icmp ne i64 %cv12496, 0
  br i1 %cond12497, label %bb_rcslotrole3002, label %bb_rcslotowner3002
bb_rcslotrole3002:
  %v12498 = load i64, ptr %slot99, align 8
  store i64 %v12498, ptr %slot2243, align 8
  %v12499 = load i64, ptr %slot2240, align 8
  %p12500 = inttoptr i64 %v12499 to ptr
  %ld12501 = load i64, ptr %p12500, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12501, ptr %slot2244, align 8
  %v12502 = load i64, ptr %slot2244, align 8
  %cmp12503 = icmp ne i64 %v12502, 0
  %cv12504 = zext i1 %cmp12503 to i32
  store i32 %cv12504, ptr %slot2245, align 8
  %v12505 = load i32, ptr %slot2245, align 8
  %cv12506 = zext i32 %v12505 to i64
  %cond12507 = icmp ne i64 %cv12506, 0
  br i1 %cond12507, label %bb_rcgnn3018, label %bb_rcgdone3018
bb_rcgnn3018:
  %v12508 = load i64, ptr %slot2244, align 8
  %op12509 = sub i64 %v12508, 16
  store i64 %op12509, ptr %slot2246, align 8
  %v12510 = load i64, ptr %slot2244, align 8
  %p12511 = inttoptr i64 %v12510 to ptr
  %rgep12512 = getelementptr i8, ptr %p12511, i64 -16
  %ld12513 = load i64, ptr %rgep12512, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12513, ptr %slot2247, align 8
  %v12514 = load i64, ptr %slot2247, align 8
  %op12515 = and i64 %v12514, 4611686018427387906
  store i64 %op12515, ptr %slot2248, align 8
  %v12516 = load i64, ptr %slot2248, align 8
  %cmp12517 = icmp ne i64 %v12516, 0
  %cv12518 = zext i1 %cmp12517 to i32
  store i32 %cv12518, ptr %slot2249, align 8
  %v12519 = load i32, ptr %slot2249, align 8
  %cv12520 = zext i32 %v12519 to i64
  %cond12521 = icmp ne i64 %cv12520, 0
  br i1 %cond12521, label %bb_rcgclear3018, label %bb_rcgcounted3018
bb_rcgcounted3018:
  %v12522 = load i64, ptr %slot2244, align 8
  %op12523 = sub i64 %v12522, 24
  store i64 %op12523, ptr %slot2250, align 8
  %v12524 = load i64, ptr %slot2244, align 8
  %p12525 = inttoptr i64 %v12524 to ptr
  %rgep12526 = getelementptr i8, ptr %p12525, i64 -24
  %ld12527 = load i64, ptr %rgep12526, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12527, ptr %slot2251, align 8
  %v12528 = load i64, ptr %slot2251, align 8
  %op12529 = sub i64 %v12528, 1
  store i64 %op12529, ptr %slot2252, align 8
  %v12530 = load i64, ptr %slot2252, align 8
  %cmp12531 = icmp eq i64 %v12530, 0
  %cv12532 = zext i1 %cmp12531 to i32
  store i32 %cv12532, ptr %slot2253, align 8
  %v12533 = load i32, ptr %slot2253, align 8
  %cv12534 = zext i32 %v12533 to i64
  %cond12535 = icmp ne i64 %cv12534, 0
  br i1 %cond12535, label %bb_rcglast3018, label %bb_rcgdec3018
bb_rcglast3018:
  %v12536 = load i64, ptr %slot2244, align 8
  %op12537 = sub i64 %v12536, 32
  store i64 %op12537, ptr %slot2254, align 8
  %v12538 = load i64, ptr %slot2244, align 8
  %p12539 = inttoptr i64 %v12538 to ptr
  %rgep12540 = getelementptr i8, ptr %p12539, i64 -32
  %ld12541 = load i64, ptr %rgep12540, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12541, ptr %slot2255, align 8
  %v12542 = load i64, ptr %slot2255, align 8
  %cmp12543 = icmp ne i64 %v12542, 0
  %cv12544 = zext i1 %cmp12543 to i32
  store i32 %cv12544, ptr %slot2256, align 8
  %v12545 = load i32, ptr %slot2256, align 8
  %cv12546 = zext i32 %v12545 to i64
  %cond12547 = icmp ne i64 %cv12546, 0
  br i1 %cond12547, label %bb_rcgdec3018, label %bb_rcgslow3018
bb_rcgslow3018:
  %v12548 = load i64, ptr %slot2243, align 8
  %v12549 = load i64, ptr %slot2240, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v12548, i64 %v12549) nomerge, !dbg !244
  br label %bb_rcgdone3018
bb_rcgdec3018:
  %v12550 = load i64, ptr %slot2252, align 8
  %v12551 = load i64, ptr %slot2244, align 8
  %p12552 = inttoptr i64 %v12551 to ptr
  %rgep12553 = getelementptr i8, ptr %p12552, i64 -24
  store i64 %v12550, ptr %rgep12553, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3018
bb_rcgclear3018:
  %v12554 = load i64, ptr %slot2240, align 8
  %p12555 = inttoptr i64 %v12554 to ptr
  store i64 0, ptr %p12555, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3018
bb_rcgdone3018:
  br label %bb_rcslotdone3002
bb_rcslotowner3002:
  %v12556 = load i64, ptr %slot99, align 8
  store i64 %v12556, ptr %slot2257, align 8
  %v12557 = load i64, ptr %slot2240, align 8
  %p12558 = inttoptr i64 %v12557 to ptr
  %ld12559 = load i64, ptr %p12558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12559, ptr %slot2258, align 8
  %v12560 = load i64, ptr %slot2258, align 8
  %cmp12561 = icmp ne i64 %v12560, 0
  %cv12562 = zext i1 %cmp12561 to i32
  store i32 %cv12562, ptr %slot2259, align 8
  %v12563 = load i32, ptr %slot2259, align 8
  %cv12564 = zext i32 %v12563 to i64
  %cond12565 = icmp ne i64 %cv12564, 0
  br i1 %cond12565, label %bb_rcgnn3033, label %bb_rcgdone3033
bb_rcgnn3033:
  %v12566 = load i64, ptr %slot2258, align 8
  %op12567 = sub i64 %v12566, 16
  store i64 %op12567, ptr %slot2260, align 8
  %v12568 = load i64, ptr %slot2258, align 8
  %p12569 = inttoptr i64 %v12568 to ptr
  %rgep12570 = getelementptr i8, ptr %p12569, i64 -16
  %ld12571 = load i64, ptr %rgep12570, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12571, ptr %slot2261, align 8
  %v12572 = load i64, ptr %slot2261, align 8
  %op12573 = and i64 %v12572, 4611686018427387906
  store i64 %op12573, ptr %slot2262, align 8
  %v12574 = load i64, ptr %slot2262, align 8
  %cmp12575 = icmp ne i64 %v12574, 0
  %cv12576 = zext i1 %cmp12575 to i32
  store i32 %cv12576, ptr %slot2263, align 8
  %v12577 = load i32, ptr %slot2263, align 8
  %cv12578 = zext i32 %v12577 to i64
  %cond12579 = icmp ne i64 %cv12578, 0
  br i1 %cond12579, label %bb_rcgclear3033, label %bb_rcgcounted3033
bb_rcgcounted3033:
  %v12580 = load i64, ptr %slot2258, align 8
  %op12581 = sub i64 %v12580, 32
  store i64 %op12581, ptr %slot2264, align 8
  %v12582 = load i64, ptr %slot2258, align 8
  %p12583 = inttoptr i64 %v12582 to ptr
  %rgep12584 = getelementptr i8, ptr %p12583, i64 -32
  %ld12585 = load i64, ptr %rgep12584, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12585, ptr %slot2265, align 8
  %v12586 = load i64, ptr %slot2265, align 8
  %op12587 = sub i64 %v12586, 1
  store i64 %op12587, ptr %slot2266, align 8
  %v12588 = load i64, ptr %slot2266, align 8
  %cmp12589 = icmp eq i64 %v12588, 0
  %cv12590 = zext i1 %cmp12589 to i32
  store i32 %cv12590, ptr %slot2267, align 8
  %v12591 = load i32, ptr %slot2267, align 8
  %cv12592 = zext i32 %v12591 to i64
  %cond12593 = icmp ne i64 %cv12592, 0
  br i1 %cond12593, label %bb_rcglast3033, label %bb_rcgdec3033
bb_rcglast3033:
  %v12594 = load i64, ptr %slot2258, align 8
  %op12595 = sub i64 %v12594, 24
  store i64 %op12595, ptr %slot2268, align 8
  %v12596 = load i64, ptr %slot2258, align 8
  %p12597 = inttoptr i64 %v12596 to ptr
  %rgep12598 = getelementptr i8, ptr %p12597, i64 -24
  %ld12599 = load i64, ptr %rgep12598, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12599, ptr %slot2269, align 8
  %v12600 = load i64, ptr %slot2269, align 8
  %cmp12601 = icmp ne i64 %v12600, 0
  %cv12602 = zext i1 %cmp12601 to i32
  store i32 %cv12602, ptr %slot2270, align 8
  %v12603 = load i32, ptr %slot2270, align 8
  %cv12604 = zext i32 %v12603 to i64
  %cond12605 = icmp ne i64 %cv12604, 0
  br i1 %cond12605, label %bb_rcgdec3033, label %bb_rcgslow3033
bb_rcgslow3033:
  %v12606 = load i64, ptr %slot2257, align 8
  %v12607 = load i64, ptr %slot2240, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v12606, i64 %v12607) nomerge, !dbg !244
  br label %bb_rcgdone3033
bb_rcgdec3033:
  %v12608 = load i64, ptr %slot2266, align 8
  %v12609 = load i64, ptr %slot2258, align 8
  %p12610 = inttoptr i64 %v12609 to ptr
  %rgep12611 = getelementptr i8, ptr %p12610, i64 -32
  store i64 %v12608, ptr %rgep12611, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3033
bb_rcgclear3033:
  %v12612 = load i64, ptr %slot2240, align 8
  %p12613 = inttoptr i64 %v12612 to ptr
  store i64 0, ptr %p12613, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3033
bb_rcgdone3033:
  br label %bb_rcslotdone3002
bb_rcslotdone3002:
  %v12614 = load i64, ptr %slot5, align 8
  %p12615 = inttoptr i64 %v12614 to ptr
  %ld12616 = load i32, ptr %p12615, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12616, ptr %slot2271, align 8
  %v12617 = load i32, ptr %slot2271, align 8
  %cv12618 = zext i32 %v12617 to i64
  %cond12619 = icmp ne i64 %cv12618, 0
  br i1 %cond12619, label %bb_rcslotdrop3039, label %bb_rcslotdone3039
bb_rcslotdrop3039:
  %v12620 = load i64, ptr %slot5, align 8
  %p12621 = inttoptr i64 %v12620 to ptr
  store i32 0, ptr %p12621, align 4, !alias.scope !3, !noalias !4
  %v12622 = load i64, ptr %slot33, align 8
  store i64 %v12622, ptr %slot2272, align 8
  %v12623 = load i64, ptr %slot6, align 8
  %p12624 = inttoptr i64 %v12623 to ptr
  %ld12625 = load i32, ptr %p12624, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12625, ptr %slot2273, align 8
  %v12626 = load i32, ptr %slot2273, align 8
  %op12627 = and i32 %v12626, 28
  store i32 %op12627, ptr %slot2274, align 8
  %v12628 = load i32, ptr %slot2274, align 8
  %cv12629 = zext i32 %v12628 to i64
  %cond12630 = icmp ne i64 %cv12629, 0
  br i1 %cond12630, label %bb_rcslotrole3039, label %bb_rcslotowner3039
bb_rcslotrole3039:
  %v12631 = load i64, ptr %slot99, align 8
  store i64 %v12631, ptr %slot2275, align 8
  %v12632 = load i64, ptr %slot2275, align 8
  %v12633 = load i64, ptr %slot2272, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v12632, i64 %v12633) nomerge, !dbg !244
  br label %bb_rcslotdone3039
bb_rcslotowner3039:
  %v12634 = load i64, ptr %slot99, align 8
  store i64 %v12634, ptr %slot2276, align 8
  %v12635 = load i64, ptr %slot2276, align 8
  %v12636 = load i64, ptr %slot2272, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v12635, i64 %v12636) nomerge, !dbg !244
  br label %bb_rcslotdone3039
bb_rcslotdone3039:
  %v12637 = load i64, ptr %slot2193, align 8
  %p12638 = inttoptr i64 %v12637 to ptr
  %ret12639 = load { i64, i64 }, ptr %p12638, align 8
  ret { i64, i64 } %ret12639
bb_i164:
  %v12640 = load i64, ptr %slot32, align 8
  %p12641 = inttoptr i64 %v12640 to ptr
  %ld12642 = load i64, ptr %p12641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12642, ptr %slot2277, align 8
  %v12643 = load i64, ptr %slot2277, align 8
  %v12644 = load i64, ptr %slot44, align 8
  %p12645 = inttoptr i64 %v12644 to ptr
  store i64 %v12643, ptr %p12645, align 8, !alias.scope !3, !noalias !4
  %v12646 = load i64, ptr %slot85, align 8
  store i64 %v12646, ptr %slot2278, align 8
  %v12647 = load i64, ptr %slot2278, align 8
  %p12648 = inttoptr i64 %v12647 to ptr
  store i32 0, ptr %p12648, align 4, !alias.scope !3, !noalias !4
  %v12649 = load i64, ptr %slot2278, align 8
  %p12650 = inttoptr i64 %v12649 to ptr
  store i32 0, ptr %p12650, align 4, !alias.scope !3, !noalias !4
  %v12651 = load i64, ptr %slot2278, align 8
  %v12652 = load i64, ptr %slot45, align 8
  %p12653 = inttoptr i64 %v12652 to ptr
  store i64 %v12651, ptr %p12653, align 8, !alias.scope !3, !noalias !4
  %v12654 = load i64, ptr %slot44, align 8
  %p12655 = inttoptr i64 %v12654 to ptr
  %ld12656 = load i64, ptr %p12655, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12656, ptr %slot2279, align 8
  %v12657 = load i64, ptr %slot45, align 8
  %p12658 = inttoptr i64 %v12657 to ptr
  %ld12659 = load i64, ptr %p12658, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12659, ptr %slot2280, align 8
  %v12660 = load i64, ptr %slot1, align 8
  %v12661 = load i64, ptr %slot2279, align 8
  %v12662 = load i64, ptr %slot2280, align 8
  %call12663 = call i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64 %v12660, i64 %v12661, i64 %v12662) nomerge, !dbg !246
  store i64 %call12663, ptr %slot2281, align 8
  %v12664 = load i64, ptr %slot2281, align 8
  %v12665 = load i64, ptr %slot44, align 8
  %p12666 = inttoptr i64 %v12665 to ptr
  store i64 %v12664, ptr %p12666, align 8, !alias.scope !3, !noalias !4
  %v12667 = load i64, ptr %slot15, align 8
  %p12668 = inttoptr i64 %v12667 to ptr
  %ld12669 = load i32, ptr %p12668, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12669, ptr %slot2282, align 8
  %v12670 = load i32, ptr %slot2282, align 8
  %cv12671 = zext i32 %v12670 to i64
  %cond12672 = icmp ne i64 %cv12671, 0
  br i1 %cond12672, label %bb_rcslotdrop3062, label %bb_rcslotdone3062
bb_rcslotdrop3062:
  %v12673 = load i64, ptr %slot15, align 8
  %p12674 = inttoptr i64 %v12673 to ptr
  store i32 0, ptr %p12674, align 4, !alias.scope !3, !noalias !4
  %v12675 = load i64, ptr %slot24, align 8
  store i64 %v12675, ptr %slot2283, align 8
  %v12676 = load i64, ptr %slot16, align 8
  %p12677 = inttoptr i64 %v12676 to ptr
  %ld12678 = load i32, ptr %p12677, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12678, ptr %slot2284, align 8
  %v12679 = load i32, ptr %slot2284, align 8
  %op12680 = and i32 %v12679, 28
  store i32 %op12680, ptr %slot2285, align 8
  %v12681 = load i32, ptr %slot2285, align 8
  %cv12682 = zext i32 %v12681 to i64
  %cond12683 = icmp ne i64 %cv12682, 0
  br i1 %cond12683, label %bb_rcslotrole3062, label %bb_rcslotowner3062
bb_rcslotrole3062:
  %v12684 = load i64, ptr %slot99, align 8
  store i64 %v12684, ptr %slot2286, align 8
  %v12685 = load i64, ptr %slot2286, align 8
  %v12686 = load i64, ptr %slot2283, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v12685, i64 %v12686) nomerge, !dbg !246
  br label %bb_rcslotdone3062
bb_rcslotowner3062:
  %v12687 = load i64, ptr %slot99, align 8
  store i64 %v12687, ptr %slot2287, align 8
  %v12688 = load i64, ptr %slot2287, align 8
  %v12689 = load i64, ptr %slot2283, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v12688, i64 %v12689) nomerge, !dbg !246
  br label %bb_rcslotdone3062
bb_rcslotdone3062:
  %v12690 = load i64, ptr %slot44, align 8
  %p12691 = inttoptr i64 %v12690 to ptr
  %ld12692 = load i64, ptr %p12691, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12692, ptr %slot2288, align 8
  %v12693 = load i64, ptr %slot2288, align 8
  %cond12694 = icmp ne i64 %v12693, 0
  br i1 %cond12694, label %bb_next3070, label %bb_i189
bb_next3070:
  %v12695 = load i64, ptr %slot32, align 8
  %p12696 = inttoptr i64 %v12695 to ptr
  %ld12697 = load i64, ptr %p12696, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12697, ptr %slot2289, align 8
  %v12698 = load i64, ptr %slot2289, align 8
  %v12699 = load i64, ptr %slot44, align 8
  %p12700 = inttoptr i64 %v12699 to ptr
  store i64 %v12698, ptr %p12700, align 8, !alias.scope !3, !noalias !4
  %v12701 = load i64, ptr %slot44, align 8
  %p12702 = inttoptr i64 %v12701 to ptr
  %ld12703 = load i64, ptr %p12702, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12703, ptr %slot2290, align 8
  %v12704 = load i64, ptr %slot1, align 8
  %v12705 = load i64, ptr %slot2290, align 8
  %call12706 = call { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64 %v12704, i64 %v12705) nomerge, !dbg !248
  store { i64, i64 } %call12706, ptr %callresult2292, align 8
  %addr12707 = ptrtoint ptr %callresult2292 to i64
  store i64 %addr12707, ptr %slot2291, align 8
  %v12708 = load i64, ptr %slot2291, align 8
  %v12709 = load i64, ptr %slot44, align 8
  %p12710 = inttoptr i64 %v12709 to ptr
  store i64 %v12708, ptr %p12710, align 8, !alias.scope !3, !noalias !4
  %v12711 = load i64, ptr %slot15, align 8
  %p12712 = inttoptr i64 %v12711 to ptr
  %ld12713 = load i32, ptr %p12712, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12713, ptr %slot2293, align 8
  %v12714 = load i32, ptr %slot2293, align 8
  %cv12715 = zext i32 %v12714 to i64
  %cond12716 = icmp ne i64 %cv12715, 0
  br i1 %cond12716, label %bb_rcslotdrop3075, label %bb_rcslotdone3075
bb_rcslotdrop3075:
  %v12717 = load i64, ptr %slot15, align 8
  %p12718 = inttoptr i64 %v12717 to ptr
  store i32 0, ptr %p12718, align 4, !alias.scope !3, !noalias !4
  %v12719 = load i64, ptr %slot24, align 8
  store i64 %v12719, ptr %slot2294, align 8
  %v12720 = load i64, ptr %slot16, align 8
  %p12721 = inttoptr i64 %v12720 to ptr
  %ld12722 = load i32, ptr %p12721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12722, ptr %slot2295, align 8
  %v12723 = load i32, ptr %slot2295, align 8
  %op12724 = and i32 %v12723, 28
  store i32 %op12724, ptr %slot2296, align 8
  %v12725 = load i32, ptr %slot2296, align 8
  %cv12726 = zext i32 %v12725 to i64
  %cond12727 = icmp ne i64 %cv12726, 0
  br i1 %cond12727, label %bb_rcslotrole3075, label %bb_rcslotowner3075
bb_rcslotrole3075:
  %v12728 = load i64, ptr %slot99, align 8
  store i64 %v12728, ptr %slot2297, align 8
  %v12729 = load i64, ptr %slot2297, align 8
  %v12730 = load i64, ptr %slot2294, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v12729, i64 %v12730) nomerge, !dbg !248
  br label %bb_rcslotdone3075
bb_rcslotowner3075:
  %v12731 = load i64, ptr %slot99, align 8
  store i64 %v12731, ptr %slot2298, align 8
  %v12732 = load i64, ptr %slot2298, align 8
  %v12733 = load i64, ptr %slot2294, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v12732, i64 %v12733) nomerge, !dbg !248
  br label %bb_rcslotdone3075
bb_rcslotdone3075:
  %v12734 = load i64, ptr %slot44, align 8
  %p12735 = inttoptr i64 %v12734 to ptr
  %ld12736 = load i64, ptr %p12735, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12736, ptr %slot2299, align 8
  %v12737 = load i64, ptr %slot2299, align 8
  %p12738 = inttoptr i64 %v12737 to ptr
  %ld12739 = load i32, ptr %p12738, align 4
  %ext12740 = zext i32 %ld12739 to i64
  store i64 %ext12740, ptr %slot2300, align 8
  %v12741 = load i64, ptr %slot2300, align 8
  %cmp12742 = icmp eq i64 %v12741, 0
  %cv12743 = zext i1 %cmp12742 to i64
  store i64 %cv12743, ptr %slot2301, align 8
  %v12744 = load i64, ptr %slot2301, align 8
  %cond12745 = icmp ne i64 %v12744, 0
  br i1 %cond12745, label %bb_rctryok3083, label %bb_rctryerror3083
bb_rctryerror3083:
  %p12746 = inttoptr i64 ptrtoint (ptr @myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p12746, i64 12884902058) "call-inline-cost"="0", !dbg !250
  %v12747 = load i64, ptr %slot2299, align 8
  %op12748 = add i64 %v12747, 8
  store i64 %op12748, ptr %slot2302, align 8
  %v12749 = load i64, ptr %slot86, align 8
  store i64 %v12749, ptr %slot2303, align 8
  %v12750 = load i64, ptr %slot2303, align 8
  %p12751 = inttoptr i64 %v12750 to ptr
  store i64 0, ptr %p12751, align 8, !alias.scope !3, !noalias !4
  %v12752 = load i64, ptr %slot2303, align 8
  %p12754 = inttoptr i64 %v12752 to ptr
  %gep12755 = getelementptr i8, ptr %p12754, i64 8
  %op12753 = ptrtoint ptr %gep12755 to i64
  store i64 %op12753, ptr %slot2304, align 8
  %v12756 = load i64, ptr %slot2304, align 8
  %p12757 = inttoptr i64 %v12756 to ptr
  store i64 0, ptr %p12757, align 8, !alias.scope !3, !noalias !4
  %v12758 = load i64, ptr %slot2303, align 8
  %p12759 = inttoptr i64 %v12758 to ptr
  store i32 1, ptr %p12759, align 4, !alias.scope !3, !noalias !4
  %v12760 = load i64, ptr %slot2303, align 8
  %p12762 = inttoptr i64 %v12760 to ptr
  %gep12763 = getelementptr i8, ptr %p12762, i64 8
  %op12761 = ptrtoint ptr %gep12763 to i64
  store i64 %op12761, ptr %slot2305, align 8
  %v12764 = load i64, ptr %slot23, align 8
  %p12765 = inttoptr i64 %v12764 to ptr
  store i32 1, ptr %p12765, align 4, !alias.scope !3, !noalias !4
  %v12766 = load i64, ptr %slot100, align 8
  store i64 %v12766, ptr %slot2306, align 8
  %v12767 = load i64, ptr %slot2303, align 8
  %v12768 = load i64, ptr %slot44, align 8
  %p12769 = inttoptr i64 %v12768 to ptr
  store i64 %v12767, ptr %p12769, align 8, !alias.scope !3, !noalias !4
  br label %bb_i172
bb_rctryok3083:
  %v12770 = load i64, ptr %slot86, align 8
  store i64 %v12770, ptr %slot2307, align 8
  %v12771 = load i64, ptr %slot2307, align 8
  %p12772 = inttoptr i64 %v12771 to ptr
  store i64 0, ptr %p12772, align 8, !alias.scope !3, !noalias !4
  %v12773 = load i64, ptr %slot23, align 8
  %p12774 = inttoptr i64 %v12773 to ptr
  store i32 1, ptr %p12774, align 4, !alias.scope !3, !noalias !4
  %v12775 = load i64, ptr %slot2299, align 8
  %op12776 = add i64 %v12775, 8
  store i64 %op12776, ptr %slot2308, align 8
  %v12777 = load i64, ptr %slot100, align 8
  store i64 %v12777, ptr %slot2309, align 8
  %v12778 = load i64, ptr %slot2308, align 8
  %p12779 = inttoptr i64 %v12778 to ptr
  %ld12780 = load i64, ptr %p12779, align 8
  store i64 %ld12780, ptr %slot2310, align 8
  %v12781 = load i64, ptr %slot2310, align 8
  %v12782 = load i64, ptr %slot2307, align 8
  %p12783 = inttoptr i64 %v12782 to ptr
  store i64 %v12781, ptr %p12783, align 8, !alias.scope !3, !noalias !4
  %v12784 = load i64, ptr %slot2307, align 8
  %p12785 = inttoptr i64 %v12784 to ptr
  %ld12786 = load i64, ptr %p12785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12786, ptr %slot2311, align 8
  %v12787 = load i64, ptr %slot2311, align 8
  %v12788 = load i64, ptr %slot44, align 8
  %p12789 = inttoptr i64 %v12788 to ptr
  store i64 %v12787, ptr %p12789, align 8, !alias.scope !3, !noalias !4
  br label %bb_i173
bb_i172:
  %v12790 = load i64, ptr %slot44, align 8
  %p12791 = inttoptr i64 %v12790 to ptr
  %ld12792 = load i64, ptr %p12791, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12792, ptr %slot2312, align 8
  %v12793 = load i64, ptr %slot15, align 8
  %p12794 = inttoptr i64 %v12793 to ptr
  %ld12795 = load i32, ptr %p12794, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12795, ptr %slot2313, align 8
  %v12796 = load i32, ptr %slot2313, align 8
  %cv12797 = zext i32 %v12796 to i64
  %cond12798 = icmp ne i64 %cv12797, 0
  br i1 %cond12798, label %bb_rcslotdrop3102, label %bb_rcslotdone3102
bb_rcslotdrop3102:
  %v12799 = load i64, ptr %slot15, align 8
  %p12800 = inttoptr i64 %v12799 to ptr
  store i32 0, ptr %p12800, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone3102
bb_rcslotdone3102:
  %v12801 = load i64, ptr %slot13, align 8
  %p12802 = inttoptr i64 %v12801 to ptr
  %ld12803 = load i32, ptr %p12802, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12803, ptr %slot2314, align 8
  %v12804 = load i32, ptr %slot2314, align 8
  %cv12805 = zext i32 %v12804 to i64
  %cond12806 = icmp ne i64 %cv12805, 0
  br i1 %cond12806, label %bb_rcslotdrop3105, label %bb_rcslotdone3105
bb_rcslotdrop3105:
  %v12807 = load i64, ptr %slot13, align 8
  %p12808 = inttoptr i64 %v12807 to ptr
  store i32 0, ptr %p12808, align 4, !alias.scope !3, !noalias !4
  %v12809 = load i64, ptr %slot42, align 8
  store i64 %v12809, ptr %slot2315, align 8
  %v12810 = load i64, ptr %slot14, align 8
  %p12811 = inttoptr i64 %v12810 to ptr
  %ld12812 = load i32, ptr %p12811, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12812, ptr %slot2316, align 8
  %v12813 = load i32, ptr %slot2316, align 8
  %op12814 = and i32 %v12813, 28
  store i32 %op12814, ptr %slot2317, align 8
  %v12815 = load i32, ptr %slot2317, align 8
  %cv12816 = zext i32 %v12815 to i64
  %cond12817 = icmp ne i64 %cv12816, 0
  br i1 %cond12817, label %bb_rcslotrole3105, label %bb_rcslotowner3105
bb_rcslotrole3105:
  %v12818 = load i64, ptr %slot99, align 8
  store i64 %v12818, ptr %slot2318, align 8
  %v12819 = load i64, ptr %slot2318, align 8
  %v12820 = load i64, ptr %slot2315, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v12819, i64 %v12820) nomerge, !dbg !252
  br label %bb_rcslotdone3105
bb_rcslotowner3105:
  %v12821 = load i64, ptr %slot99, align 8
  store i64 %v12821, ptr %slot2319, align 8
  %v12822 = load i64, ptr %slot2319, align 8
  %v12823 = load i64, ptr %slot2315, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v12822, i64 %v12823) nomerge, !dbg !252
  br label %bb_rcslotdone3105
bb_rcslotdone3105:
  %v12824 = load i64, ptr %slot11, align 8
  %p12825 = inttoptr i64 %v12824 to ptr
  %ld12826 = load i32, ptr %p12825, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12826, ptr %slot2320, align 8
  %v12827 = load i32, ptr %slot2320, align 8
  %cv12828 = zext i32 %v12827 to i64
  %cond12829 = icmp ne i64 %cv12828, 0
  br i1 %cond12829, label %bb_rcslotdrop3114, label %bb_rcslotdone3114
bb_rcslotdrop3114:
  %v12830 = load i64, ptr %slot11, align 8
  %p12831 = inttoptr i64 %v12830 to ptr
  store i32 0, ptr %p12831, align 4, !alias.scope !3, !noalias !4
  %v12832 = load i64, ptr %slot41, align 8
  store i64 %v12832, ptr %slot2321, align 8
  %v12833 = load i64, ptr %slot12, align 8
  %p12834 = inttoptr i64 %v12833 to ptr
  %ld12835 = load i32, ptr %p12834, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12835, ptr %slot2322, align 8
  %v12836 = load i32, ptr %slot2322, align 8
  %op12837 = and i32 %v12836, 28
  store i32 %op12837, ptr %slot2323, align 8
  %v12838 = load i32, ptr %slot2323, align 8
  %cv12839 = zext i32 %v12838 to i64
  %cond12840 = icmp ne i64 %cv12839, 0
  br i1 %cond12840, label %bb_rcslotrole3114, label %bb_rcslotowner3114
bb_rcslotrole3114:
  %v12841 = load i64, ptr %slot99, align 8
  store i64 %v12841, ptr %slot2324, align 8
  %v12842 = load i64, ptr %slot2324, align 8
  %v12843 = load i64, ptr %slot2321, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v12842, i64 %v12843) nomerge, !dbg !252
  br label %bb_rcslotdone3114
bb_rcslotowner3114:
  %v12844 = load i64, ptr %slot99, align 8
  store i64 %v12844, ptr %slot2325, align 8
  %v12845 = load i64, ptr %slot2325, align 8
  %v12846 = load i64, ptr %slot2321, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v12845, i64 %v12846) nomerge, !dbg !252
  br label %bb_rcslotdone3114
bb_rcslotdone3114:
  %v12847 = load i64, ptr %slot9, align 8
  %p12848 = inttoptr i64 %v12847 to ptr
  %ld12849 = load i32, ptr %p12848, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12849, ptr %slot2326, align 8
  %v12850 = load i32, ptr %slot2326, align 8
  %cv12851 = zext i32 %v12850 to i64
  %cond12852 = icmp ne i64 %cv12851, 0
  br i1 %cond12852, label %bb_rcslotdrop3123, label %bb_rcslotdone3123
bb_rcslotdrop3123:
  %v12853 = load i64, ptr %slot9, align 8
  %p12854 = inttoptr i64 %v12853 to ptr
  store i32 0, ptr %p12854, align 4, !alias.scope !3, !noalias !4
  %v12855 = load i64, ptr %slot39, align 8
  store i64 %v12855, ptr %slot2327, align 8
  %v12856 = load i64, ptr %slot10, align 8
  %p12857 = inttoptr i64 %v12856 to ptr
  %ld12858 = load i32, ptr %p12857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12858, ptr %slot2328, align 8
  %v12859 = load i32, ptr %slot2328, align 8
  %op12860 = and i32 %v12859, 28
  store i32 %op12860, ptr %slot2329, align 8
  %v12861 = load i32, ptr %slot2329, align 8
  %cv12862 = zext i32 %v12861 to i64
  %cond12863 = icmp ne i64 %cv12862, 0
  br i1 %cond12863, label %bb_rcslotrole3123, label %bb_rcslotowner3123
bb_rcslotrole3123:
  %v12864 = load i64, ptr %slot99, align 8
  store i64 %v12864, ptr %slot2330, align 8
  %v12865 = load i64, ptr %slot2327, align 8
  %p12866 = inttoptr i64 %v12865 to ptr
  %ld12867 = load i64, ptr %p12866, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12867, ptr %slot2331, align 8
  %v12868 = load i64, ptr %slot2331, align 8
  %cmp12869 = icmp ne i64 %v12868, 0
  %cv12870 = zext i1 %cmp12869 to i32
  store i32 %cv12870, ptr %slot2332, align 8
  %v12871 = load i32, ptr %slot2332, align 8
  %cv12872 = zext i32 %v12871 to i64
  %cond12873 = icmp ne i64 %cv12872, 0
  br i1 %cond12873, label %bb_rcgnn3139, label %bb_rcgdone3139
bb_rcgnn3139:
  %v12874 = load i64, ptr %slot2331, align 8
  %op12875 = sub i64 %v12874, 16
  store i64 %op12875, ptr %slot2333, align 8
  %v12876 = load i64, ptr %slot2331, align 8
  %p12877 = inttoptr i64 %v12876 to ptr
  %rgep12878 = getelementptr i8, ptr %p12877, i64 -16
  %ld12879 = load i64, ptr %rgep12878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12879, ptr %slot2334, align 8
  %v12880 = load i64, ptr %slot2334, align 8
  %op12881 = and i64 %v12880, 4611686018427387906
  store i64 %op12881, ptr %slot2335, align 8
  %v12882 = load i64, ptr %slot2335, align 8
  %cmp12883 = icmp ne i64 %v12882, 0
  %cv12884 = zext i1 %cmp12883 to i32
  store i32 %cv12884, ptr %slot2336, align 8
  %v12885 = load i32, ptr %slot2336, align 8
  %cv12886 = zext i32 %v12885 to i64
  %cond12887 = icmp ne i64 %cv12886, 0
  br i1 %cond12887, label %bb_rcgclear3139, label %bb_rcgcounted3139
bb_rcgcounted3139:
  %v12888 = load i64, ptr %slot2331, align 8
  %op12889 = sub i64 %v12888, 24
  store i64 %op12889, ptr %slot2337, align 8
  %v12890 = load i64, ptr %slot2331, align 8
  %p12891 = inttoptr i64 %v12890 to ptr
  %rgep12892 = getelementptr i8, ptr %p12891, i64 -24
  %ld12893 = load i64, ptr %rgep12892, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12893, ptr %slot2338, align 8
  %v12894 = load i64, ptr %slot2338, align 8
  %op12895 = sub i64 %v12894, 1
  store i64 %op12895, ptr %slot2339, align 8
  %v12896 = load i64, ptr %slot2339, align 8
  %cmp12897 = icmp eq i64 %v12896, 0
  %cv12898 = zext i1 %cmp12897 to i32
  store i32 %cv12898, ptr %slot2340, align 8
  %v12899 = load i32, ptr %slot2340, align 8
  %cv12900 = zext i32 %v12899 to i64
  %cond12901 = icmp ne i64 %cv12900, 0
  br i1 %cond12901, label %bb_rcglast3139, label %bb_rcgdec3139
bb_rcglast3139:
  %v12902 = load i64, ptr %slot2331, align 8
  %op12903 = sub i64 %v12902, 32
  store i64 %op12903, ptr %slot2341, align 8
  %v12904 = load i64, ptr %slot2331, align 8
  %p12905 = inttoptr i64 %v12904 to ptr
  %rgep12906 = getelementptr i8, ptr %p12905, i64 -32
  %ld12907 = load i64, ptr %rgep12906, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12907, ptr %slot2342, align 8
  %v12908 = load i64, ptr %slot2342, align 8
  %cmp12909 = icmp ne i64 %v12908, 0
  %cv12910 = zext i1 %cmp12909 to i32
  store i32 %cv12910, ptr %slot2343, align 8
  %v12911 = load i32, ptr %slot2343, align 8
  %cv12912 = zext i32 %v12911 to i64
  %cond12913 = icmp ne i64 %cv12912, 0
  br i1 %cond12913, label %bb_rcgdec3139, label %bb_rcgslow3139
bb_rcgslow3139:
  %v12914 = load i64, ptr %slot2330, align 8
  %v12915 = load i64, ptr %slot2327, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v12914, i64 %v12915) nomerge, !dbg !252
  br label %bb_rcgdone3139
bb_rcgdec3139:
  %v12916 = load i64, ptr %slot2339, align 8
  %v12917 = load i64, ptr %slot2331, align 8
  %p12918 = inttoptr i64 %v12917 to ptr
  %rgep12919 = getelementptr i8, ptr %p12918, i64 -24
  store i64 %v12916, ptr %rgep12919, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3139
bb_rcgclear3139:
  %v12920 = load i64, ptr %slot2327, align 8
  %p12921 = inttoptr i64 %v12920 to ptr
  store i64 0, ptr %p12921, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3139
bb_rcgdone3139:
  br label %bb_rcslotdone3123
bb_rcslotowner3123:
  %v12922 = load i64, ptr %slot99, align 8
  store i64 %v12922, ptr %slot2344, align 8
  %v12923 = load i64, ptr %slot2327, align 8
  %p12924 = inttoptr i64 %v12923 to ptr
  %ld12925 = load i64, ptr %p12924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12925, ptr %slot2345, align 8
  %v12926 = load i64, ptr %slot2345, align 8
  %cmp12927 = icmp ne i64 %v12926, 0
  %cv12928 = zext i1 %cmp12927 to i32
  store i32 %cv12928, ptr %slot2346, align 8
  %v12929 = load i32, ptr %slot2346, align 8
  %cv12930 = zext i32 %v12929 to i64
  %cond12931 = icmp ne i64 %cv12930, 0
  br i1 %cond12931, label %bb_rcgnn3154, label %bb_rcgdone3154
bb_rcgnn3154:
  %v12932 = load i64, ptr %slot2345, align 8
  %op12933 = sub i64 %v12932, 16
  store i64 %op12933, ptr %slot2347, align 8
  %v12934 = load i64, ptr %slot2345, align 8
  %p12935 = inttoptr i64 %v12934 to ptr
  %rgep12936 = getelementptr i8, ptr %p12935, i64 -16
  %ld12937 = load i64, ptr %rgep12936, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12937, ptr %slot2348, align 8
  %v12938 = load i64, ptr %slot2348, align 8
  %op12939 = and i64 %v12938, 4611686018427387906
  store i64 %op12939, ptr %slot2349, align 8
  %v12940 = load i64, ptr %slot2349, align 8
  %cmp12941 = icmp ne i64 %v12940, 0
  %cv12942 = zext i1 %cmp12941 to i32
  store i32 %cv12942, ptr %slot2350, align 8
  %v12943 = load i32, ptr %slot2350, align 8
  %cv12944 = zext i32 %v12943 to i64
  %cond12945 = icmp ne i64 %cv12944, 0
  br i1 %cond12945, label %bb_rcgclear3154, label %bb_rcgcounted3154
bb_rcgcounted3154:
  %v12946 = load i64, ptr %slot2345, align 8
  %op12947 = sub i64 %v12946, 32
  store i64 %op12947, ptr %slot2351, align 8
  %v12948 = load i64, ptr %slot2345, align 8
  %p12949 = inttoptr i64 %v12948 to ptr
  %rgep12950 = getelementptr i8, ptr %p12949, i64 -32
  %ld12951 = load i64, ptr %rgep12950, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12951, ptr %slot2352, align 8
  %v12952 = load i64, ptr %slot2352, align 8
  %op12953 = sub i64 %v12952, 1
  store i64 %op12953, ptr %slot2353, align 8
  %v12954 = load i64, ptr %slot2353, align 8
  %cmp12955 = icmp eq i64 %v12954, 0
  %cv12956 = zext i1 %cmp12955 to i32
  store i32 %cv12956, ptr %slot2354, align 8
  %v12957 = load i32, ptr %slot2354, align 8
  %cv12958 = zext i32 %v12957 to i64
  %cond12959 = icmp ne i64 %cv12958, 0
  br i1 %cond12959, label %bb_rcglast3154, label %bb_rcgdec3154
bb_rcglast3154:
  %v12960 = load i64, ptr %slot2345, align 8
  %op12961 = sub i64 %v12960, 24
  store i64 %op12961, ptr %slot2355, align 8
  %v12962 = load i64, ptr %slot2345, align 8
  %p12963 = inttoptr i64 %v12962 to ptr
  %rgep12964 = getelementptr i8, ptr %p12963, i64 -24
  %ld12965 = load i64, ptr %rgep12964, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12965, ptr %slot2356, align 8
  %v12966 = load i64, ptr %slot2356, align 8
  %cmp12967 = icmp ne i64 %v12966, 0
  %cv12968 = zext i1 %cmp12967 to i32
  store i32 %cv12968, ptr %slot2357, align 8
  %v12969 = load i32, ptr %slot2357, align 8
  %cv12970 = zext i32 %v12969 to i64
  %cond12971 = icmp ne i64 %cv12970, 0
  br i1 %cond12971, label %bb_rcgdec3154, label %bb_rcgslow3154
bb_rcgslow3154:
  %v12972 = load i64, ptr %slot2344, align 8
  %v12973 = load i64, ptr %slot2327, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v12972, i64 %v12973) nomerge, !dbg !252
  br label %bb_rcgdone3154
bb_rcgdec3154:
  %v12974 = load i64, ptr %slot2353, align 8
  %v12975 = load i64, ptr %slot2345, align 8
  %p12976 = inttoptr i64 %v12975 to ptr
  %rgep12977 = getelementptr i8, ptr %p12976, i64 -32
  store i64 %v12974, ptr %rgep12977, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3154
bb_rcgclear3154:
  %v12978 = load i64, ptr %slot2327, align 8
  %p12979 = inttoptr i64 %v12978 to ptr
  store i64 0, ptr %p12979, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3154
bb_rcgdone3154:
  br label %bb_rcslotdone3123
bb_rcslotdone3123:
  %v12980 = load i64, ptr %slot7, align 8
  %p12981 = inttoptr i64 %v12980 to ptr
  %ld12982 = load i32, ptr %p12981, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12982, ptr %slot2358, align 8
  %v12983 = load i32, ptr %slot2358, align 8
  %cv12984 = zext i32 %v12983 to i64
  %cond12985 = icmp ne i64 %cv12984, 0
  br i1 %cond12985, label %bb_rcslotdrop3160, label %bb_rcslotdone3160
bb_rcslotdrop3160:
  %v12986 = load i64, ptr %slot7, align 8
  %p12987 = inttoptr i64 %v12986 to ptr
  store i32 0, ptr %p12987, align 4, !alias.scope !3, !noalias !4
  %v12988 = load i64, ptr %slot34, align 8
  store i64 %v12988, ptr %slot2359, align 8
  %v12989 = load i64, ptr %slot8, align 8
  %p12990 = inttoptr i64 %v12989 to ptr
  %ld12991 = load i32, ptr %p12990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12991, ptr %slot2360, align 8
  %v12992 = load i32, ptr %slot2360, align 8
  %op12993 = and i32 %v12992, 28
  store i32 %op12993, ptr %slot2361, align 8
  %v12994 = load i32, ptr %slot2361, align 8
  %cv12995 = zext i32 %v12994 to i64
  %cond12996 = icmp ne i64 %cv12995, 0
  br i1 %cond12996, label %bb_rcslotrole3160, label %bb_rcslotowner3160
bb_rcslotrole3160:
  %v12997 = load i64, ptr %slot99, align 8
  store i64 %v12997, ptr %slot2362, align 8
  %v12998 = load i64, ptr %slot2359, align 8
  %p12999 = inttoptr i64 %v12998 to ptr
  %ld13000 = load i64, ptr %p12999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13000, ptr %slot2363, align 8
  %v13001 = load i64, ptr %slot2363, align 8
  %cmp13002 = icmp ne i64 %v13001, 0
  %cv13003 = zext i1 %cmp13002 to i32
  store i32 %cv13003, ptr %slot2364, align 8
  %v13004 = load i32, ptr %slot2364, align 8
  %cv13005 = zext i32 %v13004 to i64
  %cond13006 = icmp ne i64 %cv13005, 0
  br i1 %cond13006, label %bb_rcgnn3176, label %bb_rcgdone3176
bb_rcgnn3176:
  %v13007 = load i64, ptr %slot2363, align 8
  %op13008 = sub i64 %v13007, 16
  store i64 %op13008, ptr %slot2365, align 8
  %v13009 = load i64, ptr %slot2363, align 8
  %p13010 = inttoptr i64 %v13009 to ptr
  %rgep13011 = getelementptr i8, ptr %p13010, i64 -16
  %ld13012 = load i64, ptr %rgep13011, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13012, ptr %slot2366, align 8
  %v13013 = load i64, ptr %slot2366, align 8
  %op13014 = and i64 %v13013, 4611686018427387906
  store i64 %op13014, ptr %slot2367, align 8
  %v13015 = load i64, ptr %slot2367, align 8
  %cmp13016 = icmp ne i64 %v13015, 0
  %cv13017 = zext i1 %cmp13016 to i32
  store i32 %cv13017, ptr %slot2368, align 8
  %v13018 = load i32, ptr %slot2368, align 8
  %cv13019 = zext i32 %v13018 to i64
  %cond13020 = icmp ne i64 %cv13019, 0
  br i1 %cond13020, label %bb_rcgclear3176, label %bb_rcgcounted3176
bb_rcgcounted3176:
  %v13021 = load i64, ptr %slot2363, align 8
  %op13022 = sub i64 %v13021, 24
  store i64 %op13022, ptr %slot2369, align 8
  %v13023 = load i64, ptr %slot2363, align 8
  %p13024 = inttoptr i64 %v13023 to ptr
  %rgep13025 = getelementptr i8, ptr %p13024, i64 -24
  %ld13026 = load i64, ptr %rgep13025, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13026, ptr %slot2370, align 8
  %v13027 = load i64, ptr %slot2370, align 8
  %op13028 = sub i64 %v13027, 1
  store i64 %op13028, ptr %slot2371, align 8
  %v13029 = load i64, ptr %slot2371, align 8
  %cmp13030 = icmp eq i64 %v13029, 0
  %cv13031 = zext i1 %cmp13030 to i32
  store i32 %cv13031, ptr %slot2372, align 8
  %v13032 = load i32, ptr %slot2372, align 8
  %cv13033 = zext i32 %v13032 to i64
  %cond13034 = icmp ne i64 %cv13033, 0
  br i1 %cond13034, label %bb_rcglast3176, label %bb_rcgdec3176
bb_rcglast3176:
  %v13035 = load i64, ptr %slot2363, align 8
  %op13036 = sub i64 %v13035, 32
  store i64 %op13036, ptr %slot2373, align 8
  %v13037 = load i64, ptr %slot2363, align 8
  %p13038 = inttoptr i64 %v13037 to ptr
  %rgep13039 = getelementptr i8, ptr %p13038, i64 -32
  %ld13040 = load i64, ptr %rgep13039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13040, ptr %slot2374, align 8
  %v13041 = load i64, ptr %slot2374, align 8
  %cmp13042 = icmp ne i64 %v13041, 0
  %cv13043 = zext i1 %cmp13042 to i32
  store i32 %cv13043, ptr %slot2375, align 8
  %v13044 = load i32, ptr %slot2375, align 8
  %cv13045 = zext i32 %v13044 to i64
  %cond13046 = icmp ne i64 %cv13045, 0
  br i1 %cond13046, label %bb_rcgdec3176, label %bb_rcgslow3176
bb_rcgslow3176:
  %v13047 = load i64, ptr %slot2362, align 8
  %v13048 = load i64, ptr %slot2359, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v13047, i64 %v13048) nomerge, !dbg !252
  br label %bb_rcgdone3176
bb_rcgdec3176:
  %v13049 = load i64, ptr %slot2371, align 8
  %v13050 = load i64, ptr %slot2363, align 8
  %p13051 = inttoptr i64 %v13050 to ptr
  %rgep13052 = getelementptr i8, ptr %p13051, i64 -24
  store i64 %v13049, ptr %rgep13052, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3176
bb_rcgclear3176:
  %v13053 = load i64, ptr %slot2359, align 8
  %p13054 = inttoptr i64 %v13053 to ptr
  store i64 0, ptr %p13054, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3176
bb_rcgdone3176:
  br label %bb_rcslotdone3160
bb_rcslotowner3160:
  %v13055 = load i64, ptr %slot99, align 8
  store i64 %v13055, ptr %slot2376, align 8
  %v13056 = load i64, ptr %slot2359, align 8
  %p13057 = inttoptr i64 %v13056 to ptr
  %ld13058 = load i64, ptr %p13057, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13058, ptr %slot2377, align 8
  %v13059 = load i64, ptr %slot2377, align 8
  %cmp13060 = icmp ne i64 %v13059, 0
  %cv13061 = zext i1 %cmp13060 to i32
  store i32 %cv13061, ptr %slot2378, align 8
  %v13062 = load i32, ptr %slot2378, align 8
  %cv13063 = zext i32 %v13062 to i64
  %cond13064 = icmp ne i64 %cv13063, 0
  br i1 %cond13064, label %bb_rcgnn3191, label %bb_rcgdone3191
bb_rcgnn3191:
  %v13065 = load i64, ptr %slot2377, align 8
  %op13066 = sub i64 %v13065, 16
  store i64 %op13066, ptr %slot2379, align 8
  %v13067 = load i64, ptr %slot2377, align 8
  %p13068 = inttoptr i64 %v13067 to ptr
  %rgep13069 = getelementptr i8, ptr %p13068, i64 -16
  %ld13070 = load i64, ptr %rgep13069, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13070, ptr %slot2380, align 8
  %v13071 = load i64, ptr %slot2380, align 8
  %op13072 = and i64 %v13071, 4611686018427387906
  store i64 %op13072, ptr %slot2381, align 8
  %v13073 = load i64, ptr %slot2381, align 8
  %cmp13074 = icmp ne i64 %v13073, 0
  %cv13075 = zext i1 %cmp13074 to i32
  store i32 %cv13075, ptr %slot2382, align 8
  %v13076 = load i32, ptr %slot2382, align 8
  %cv13077 = zext i32 %v13076 to i64
  %cond13078 = icmp ne i64 %cv13077, 0
  br i1 %cond13078, label %bb_rcgclear3191, label %bb_rcgcounted3191
bb_rcgcounted3191:
  %v13079 = load i64, ptr %slot2377, align 8
  %op13080 = sub i64 %v13079, 32
  store i64 %op13080, ptr %slot2383, align 8
  %v13081 = load i64, ptr %slot2377, align 8
  %p13082 = inttoptr i64 %v13081 to ptr
  %rgep13083 = getelementptr i8, ptr %p13082, i64 -32
  %ld13084 = load i64, ptr %rgep13083, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13084, ptr %slot2384, align 8
  %v13085 = load i64, ptr %slot2384, align 8
  %op13086 = sub i64 %v13085, 1
  store i64 %op13086, ptr %slot2385, align 8
  %v13087 = load i64, ptr %slot2385, align 8
  %cmp13088 = icmp eq i64 %v13087, 0
  %cv13089 = zext i1 %cmp13088 to i32
  store i32 %cv13089, ptr %slot2386, align 8
  %v13090 = load i32, ptr %slot2386, align 8
  %cv13091 = zext i32 %v13090 to i64
  %cond13092 = icmp ne i64 %cv13091, 0
  br i1 %cond13092, label %bb_rcglast3191, label %bb_rcgdec3191
bb_rcglast3191:
  %v13093 = load i64, ptr %slot2377, align 8
  %op13094 = sub i64 %v13093, 24
  store i64 %op13094, ptr %slot2387, align 8
  %v13095 = load i64, ptr %slot2377, align 8
  %p13096 = inttoptr i64 %v13095 to ptr
  %rgep13097 = getelementptr i8, ptr %p13096, i64 -24
  %ld13098 = load i64, ptr %rgep13097, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13098, ptr %slot2388, align 8
  %v13099 = load i64, ptr %slot2388, align 8
  %cmp13100 = icmp ne i64 %v13099, 0
  %cv13101 = zext i1 %cmp13100 to i32
  store i32 %cv13101, ptr %slot2389, align 8
  %v13102 = load i32, ptr %slot2389, align 8
  %cv13103 = zext i32 %v13102 to i64
  %cond13104 = icmp ne i64 %cv13103, 0
  br i1 %cond13104, label %bb_rcgdec3191, label %bb_rcgslow3191
bb_rcgslow3191:
  %v13105 = load i64, ptr %slot2376, align 8
  %v13106 = load i64, ptr %slot2359, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v13105, i64 %v13106) nomerge, !dbg !252
  br label %bb_rcgdone3191
bb_rcgdec3191:
  %v13107 = load i64, ptr %slot2385, align 8
  %v13108 = load i64, ptr %slot2377, align 8
  %p13109 = inttoptr i64 %v13108 to ptr
  %rgep13110 = getelementptr i8, ptr %p13109, i64 -32
  store i64 %v13107, ptr %rgep13110, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3191
bb_rcgclear3191:
  %v13111 = load i64, ptr %slot2359, align 8
  %p13112 = inttoptr i64 %v13111 to ptr
  store i64 0, ptr %p13112, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3191
bb_rcgdone3191:
  br label %bb_rcslotdone3160
bb_rcslotdone3160:
  %v13113 = load i64, ptr %slot5, align 8
  %p13114 = inttoptr i64 %v13113 to ptr
  %ld13115 = load i32, ptr %p13114, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13115, ptr %slot2390, align 8
  %v13116 = load i32, ptr %slot2390, align 8
  %cv13117 = zext i32 %v13116 to i64
  %cond13118 = icmp ne i64 %cv13117, 0
  br i1 %cond13118, label %bb_rcslotdrop3197, label %bb_rcslotdone3197
bb_rcslotdrop3197:
  %v13119 = load i64, ptr %slot5, align 8
  %p13120 = inttoptr i64 %v13119 to ptr
  store i32 0, ptr %p13120, align 4, !alias.scope !3, !noalias !4
  %v13121 = load i64, ptr %slot33, align 8
  store i64 %v13121, ptr %slot2391, align 8
  %v13122 = load i64, ptr %slot6, align 8
  %p13123 = inttoptr i64 %v13122 to ptr
  %ld13124 = load i32, ptr %p13123, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13124, ptr %slot2392, align 8
  %v13125 = load i32, ptr %slot2392, align 8
  %op13126 = and i32 %v13125, 28
  store i32 %op13126, ptr %slot2393, align 8
  %v13127 = load i32, ptr %slot2393, align 8
  %cv13128 = zext i32 %v13127 to i64
  %cond13129 = icmp ne i64 %cv13128, 0
  br i1 %cond13129, label %bb_rcslotrole3197, label %bb_rcslotowner3197
bb_rcslotrole3197:
  %v13130 = load i64, ptr %slot99, align 8
  store i64 %v13130, ptr %slot2394, align 8
  %v13131 = load i64, ptr %slot2394, align 8
  %v13132 = load i64, ptr %slot2391, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v13131, i64 %v13132) nomerge, !dbg !252
  br label %bb_rcslotdone3197
bb_rcslotowner3197:
  %v13133 = load i64, ptr %slot99, align 8
  store i64 %v13133, ptr %slot2395, align 8
  %v13134 = load i64, ptr %slot2395, align 8
  %v13135 = load i64, ptr %slot2391, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v13134, i64 %v13135) nomerge, !dbg !252
  br label %bb_rcslotdone3197
bb_rcslotdone3197:
  %v13136 = load i64, ptr %slot2312, align 8
  %p13137 = inttoptr i64 %v13136 to ptr
  %ret13138 = load { i64, i64 }, ptr %p13137, align 8
  ret { i64, i64 } %ret13138
bb_i173:
  %v13139 = load i64, ptr %slot44, align 8
  %p13140 = inttoptr i64 %v13139 to ptr
  %ld13141 = load i64, ptr %p13140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13141, ptr %slot2396, align 8
  %v13142 = load i64, ptr %slot2396, align 8
  %v13143 = load i64, ptr %slot43, align 8
  %p13144 = inttoptr i64 %v13143 to ptr
  store i64 %v13142, ptr %p13144, align 8, !alias.scope !3, !noalias !4
  %v13145 = load i64, ptr %slot32, align 8
  %p13146 = inttoptr i64 %v13145 to ptr
  %ld13147 = load i64, ptr %p13146, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13147, ptr %slot2397, align 8
  %v13148 = load i64, ptr %slot2397, align 8
  %v13149 = load i64, ptr %slot44, align 8
  %p13150 = inttoptr i64 %v13149 to ptr
  store i64 %v13148, ptr %p13150, align 8, !alias.scope !3, !noalias !4
  %v13151 = load i64, ptr %slot87, align 8
  store i64 %v13151, ptr %slot2398, align 8
  %v13152 = load i64, ptr %slot2398, align 8
  %p13153 = inttoptr i64 %v13152 to ptr
  store i32 0, ptr %p13153, align 4, !alias.scope !3, !noalias !4
  %v13154 = load i64, ptr %slot2398, align 8
  %p13155 = inttoptr i64 %v13154 to ptr
  store i32 1, ptr %p13155, align 4, !alias.scope !3, !noalias !4
  %v13156 = load i64, ptr %slot2398, align 8
  %v13157 = load i64, ptr %slot45, align 8
  %p13158 = inttoptr i64 %v13157 to ptr
  store i64 %v13156, ptr %p13158, align 8, !alias.scope !3, !noalias !4
  %p13159 = inttoptr i64 ptrtoint (ptr @myl_lit_4a567dbed804c7cf92d6eb2154c9ccfecc754c82ed316a70b59da8384d2cb99f to i64) to ptr
  %ld13160 = load i64, ptr %p13159, align 8, !alias.scope !4, !noalias !3
  store i64 %ld13160, ptr %slot2399, align 8
  %v13161 = load i64, ptr %slot2399, align 8
  %v13162 = load i64, ptr %slot46, align 8
  %p13163 = inttoptr i64 %v13162 to ptr
  store i64 %v13161, ptr %p13163, align 8, !alias.scope !3, !noalias !4
  %v13164 = load i64, ptr %slot46, align 8
  %p13165 = inttoptr i64 %v13164 to ptr
  %ld13166 = load i64, ptr %p13165, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13166, ptr %slot2400, align 8
  %v13167 = load i64, ptr %slot2400, align 8
  %v13168 = load i64, ptr %slot29, align 8
  %p13169 = inttoptr i64 %v13168 to ptr
  store i64 %v13167, ptr %p13169, align 8, !alias.scope !3, !noalias !4
  %v13170 = load i64, ptr %slot29, align 8
  store i64 %v13170, ptr %slot2401, align 8
  %v13171 = load i64, ptr %slot30, align 8
  store i64 %v13171, ptr %slot2402, align 8
  %v13172 = load i64, ptr %slot2401, align 8
  %v13173 = load i64, ptr %slot2402, align 8
  %p13174 = inttoptr i64 %v13172 to ptr
  %p13175 = inttoptr i64 %v13173 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13175, ptr %p13174, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v13176 = load i64, ptr %slot22, align 8
  %p13177 = inttoptr i64 %v13176 to ptr
  store i32 2, ptr %p13177, align 4, !alias.scope !3, !noalias !4
  %v13178 = load i64, ptr %slot21, align 8
  %p13179 = inttoptr i64 %v13178 to ptr
  store i32 1, ptr %p13179, align 4, !alias.scope !3, !noalias !4
  %v13180 = load i64, ptr %slot26, align 8
  store i64 %v13180, ptr %slot2403, align 8
  %v13181 = load i64, ptr %slot30, align 8
  store i64 %v13181, ptr %slot2404, align 8
  %v13182 = load i64, ptr %slot2404, align 8
  %v13183 = load i64, ptr %slot2403, align 8
  %p13184 = inttoptr i64 %v13182 to ptr
  %p13185 = inttoptr i64 %v13183 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13185, ptr %p13184, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v13186 = load i64, ptr %slot20, align 8
  %p13187 = inttoptr i64 %v13186 to ptr
  store i32 2, ptr %p13187, align 4, !alias.scope !3, !noalias !4
  %v13188 = load i64, ptr %slot22, align 8
  %p13189 = inttoptr i64 %v13188 to ptr
  %ld13190 = load i32, ptr %p13189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13190, ptr %slot2405, align 8
  %v13191 = load i32, ptr %slot2405, align 8
  %v13192 = load i64, ptr %slot20, align 8
  %p13193 = inttoptr i64 %v13192 to ptr
  store i32 %v13191, ptr %p13193, align 4, !alias.scope !3, !noalias !4
  %v13194 = load i64, ptr %slot21, align 8
  %p13195 = inttoptr i64 %v13194 to ptr
  store i32 0, ptr %p13195, align 4, !alias.scope !3, !noalias !4
  %v13196 = load i64, ptr %slot19, align 8
  %p13197 = inttoptr i64 %v13196 to ptr
  store i32 1, ptr %p13197, align 4, !alias.scope !3, !noalias !4
  %v13198 = load i64, ptr %slot2403, align 8
  %p13199 = inttoptr i64 %v13198 to ptr
  %ld13200 = load i64, ptr %p13199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13200, ptr %slot2406, align 8
  %v13201 = load i64, ptr %slot2406, align 8
  %v13202 = load i64, ptr %slot46, align 8
  %p13203 = inttoptr i64 %v13202 to ptr
  store i64 %v13201, ptr %p13203, align 8, !alias.scope !3, !noalias !4
  %v13204 = load i64, ptr %slot44, align 8
  %p13205 = inttoptr i64 %v13204 to ptr
  %ld13206 = load i64, ptr %p13205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13206, ptr %slot2407, align 8
  %v13207 = load i64, ptr %slot45, align 8
  %p13208 = inttoptr i64 %v13207 to ptr
  %ld13209 = load i64, ptr %p13208, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13209, ptr %slot2408, align 8
  %v13210 = load i64, ptr %slot46, align 8
  %p13211 = inttoptr i64 %v13210 to ptr
  %ld13212 = load i64, ptr %p13211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13212, ptr %slot2409, align 8
  %v13213 = load i64, ptr %slot1, align 8
  %v13214 = load i64, ptr %slot2407, align 8
  %v13215 = load i64, ptr %slot2408, align 8
  %v13216 = load i64, ptr %slot2409, align 8
  call void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8 %callresult2411, i64 %v13213, i64 %v13214, i64 %v13215, i64 %v13216) nomerge, !dbg !254
  %addr13217 = ptrtoint ptr %callresult2411 to i64
  store i64 %addr13217, ptr %slot2410, align 8
  %v13218 = load i64, ptr %slot2410, align 8
  %v13219 = load i64, ptr %slot44, align 8
  %p13220 = inttoptr i64 %v13219 to ptr
  store i64 %v13218, ptr %p13220, align 8, !alias.scope !3, !noalias !4
  %v13221 = load i64, ptr %slot44, align 8
  %p13222 = inttoptr i64 %v13221 to ptr
  %ld13223 = load i64, ptr %p13222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13223, ptr %slot2412, align 8
  %v13224 = load i64, ptr %slot30, align 8
  store i64 %v13224, ptr %slot2413, align 8
  %v13225 = load i64, ptr %slot2412, align 8
  %v13226 = load i64, ptr %slot2413, align 8
  %p13227 = inttoptr i64 %v13225 to ptr
  %p13228 = inttoptr i64 %v13226 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13228, ptr %p13227, i64 48, i1 false)
  %v13229 = load i64, ptr %slot22, align 8
  %p13230 = inttoptr i64 %v13229 to ptr
  store i32 2, ptr %p13230, align 4, !alias.scope !3, !noalias !4
  %v13231 = load i64, ptr %slot21, align 8
  %p13232 = inttoptr i64 %v13231 to ptr
  store i32 1, ptr %p13232, align 4, !alias.scope !3, !noalias !4
  %v13233 = load i64, ptr %slot15, align 8
  %p13234 = inttoptr i64 %v13233 to ptr
  %ld13235 = load i32, ptr %p13234, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13235, ptr %slot2414, align 8
  %v13236 = load i32, ptr %slot2414, align 8
  %cv13237 = zext i32 %v13236 to i64
  %cond13238 = icmp ne i64 %cv13237, 0
  br i1 %cond13238, label %bb_rcslotdrop3242, label %bb_rcslotdone3242
bb_rcslotdrop3242:
  %v13239 = load i64, ptr %slot15, align 8
  %p13240 = inttoptr i64 %v13239 to ptr
  store i32 0, ptr %p13240, align 4, !alias.scope !3, !noalias !4
  %v13241 = load i64, ptr %slot24, align 8
  store i64 %v13241, ptr %slot2415, align 8
  %v13242 = load i64, ptr %slot16, align 8
  %p13243 = inttoptr i64 %v13242 to ptr
  %ld13244 = load i32, ptr %p13243, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13244, ptr %slot2416, align 8
  %v13245 = load i32, ptr %slot2416, align 8
  %op13246 = and i32 %v13245, 28
  store i32 %op13246, ptr %slot2417, align 8
  %v13247 = load i32, ptr %slot2417, align 8
  %cv13248 = zext i32 %v13247 to i64
  %cond13249 = icmp ne i64 %cv13248, 0
  br i1 %cond13249, label %bb_rcslotrole3242, label %bb_rcslotowner3242
bb_rcslotrole3242:
  %v13250 = load i64, ptr %slot99, align 8
  store i64 %v13250, ptr %slot2418, align 8
  %v13251 = load i64, ptr %slot2418, align 8
  %v13252 = load i64, ptr %slot2415, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v13251, i64 %v13252) nomerge, !dbg !254
  br label %bb_rcslotdone3242
bb_rcslotowner3242:
  %v13253 = load i64, ptr %slot99, align 8
  store i64 %v13253, ptr %slot2419, align 8
  %v13254 = load i64, ptr %slot2419, align 8
  %v13255 = load i64, ptr %slot2415, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v13254, i64 %v13255) nomerge, !dbg !254
  br label %bb_rcslotdone3242
bb_rcslotdone3242:
  %v13256 = load i64, ptr %slot19, align 8
  %p13257 = inttoptr i64 %v13256 to ptr
  %ld13258 = load i32, ptr %p13257, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13258, ptr %slot2420, align 8
  %v13259 = load i32, ptr %slot2420, align 8
  %cv13260 = zext i32 %v13259 to i64
  %cond13261 = icmp ne i64 %cv13260, 0
  br i1 %cond13261, label %bb_rcslotdrop3251, label %bb_rcslotdone3251
bb_rcslotdrop3251:
  %v13262 = load i64, ptr %slot19, align 8
  %p13263 = inttoptr i64 %v13262 to ptr
  store i32 0, ptr %p13263, align 4, !alias.scope !3, !noalias !4
  %v13264 = load i64, ptr %slot26, align 8
  store i64 %v13264, ptr %slot2421, align 8
  %v13265 = load i64, ptr %slot20, align 8
  %p13266 = inttoptr i64 %v13265 to ptr
  %ld13267 = load i32, ptr %p13266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13267, ptr %slot2422, align 8
  %v13268 = load i32, ptr %slot2422, align 8
  %op13269 = and i32 %v13268, 28
  store i32 %op13269, ptr %slot2423, align 8
  %v13270 = load i32, ptr %slot2423, align 8
  %cv13271 = zext i32 %v13270 to i64
  %cond13272 = icmp ne i64 %cv13271, 0
  br i1 %cond13272, label %bb_rcslotrole3251, label %bb_rcslotowner3251
bb_rcslotrole3251:
  %v13273 = load i64, ptr %slot99, align 8
  store i64 %v13273, ptr %slot2424, align 8
  %v13274 = load i64, ptr %slot2421, align 8
  %p13275 = inttoptr i64 %v13274 to ptr
  %ld13276 = load i64, ptr %p13275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13276, ptr %slot2425, align 8
  %v13277 = load i64, ptr %slot2425, align 8
  %cmp13278 = icmp ne i64 %v13277, 0
  %cv13279 = zext i1 %cmp13278 to i32
  store i32 %cv13279, ptr %slot2426, align 8
  %v13280 = load i32, ptr %slot2426, align 8
  %cv13281 = zext i32 %v13280 to i64
  %cond13282 = icmp ne i64 %cv13281, 0
  br i1 %cond13282, label %bb_rcgnn3267, label %bb_rcgdone3267
bb_rcgnn3267:
  %v13283 = load i64, ptr %slot2425, align 8
  %op13284 = sub i64 %v13283, 16
  store i64 %op13284, ptr %slot2427, align 8
  %v13285 = load i64, ptr %slot2425, align 8
  %p13286 = inttoptr i64 %v13285 to ptr
  %rgep13287 = getelementptr i8, ptr %p13286, i64 -16
  %ld13288 = load i64, ptr %rgep13287, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13288, ptr %slot2428, align 8
  %v13289 = load i64, ptr %slot2428, align 8
  %op13290 = and i64 %v13289, 4611686018427387906
  store i64 %op13290, ptr %slot2429, align 8
  %v13291 = load i64, ptr %slot2429, align 8
  %cmp13292 = icmp ne i64 %v13291, 0
  %cv13293 = zext i1 %cmp13292 to i32
  store i32 %cv13293, ptr %slot2430, align 8
  %v13294 = load i32, ptr %slot2430, align 8
  %cv13295 = zext i32 %v13294 to i64
  %cond13296 = icmp ne i64 %cv13295, 0
  br i1 %cond13296, label %bb_rcgclear3267, label %bb_rcgcounted3267
bb_rcgcounted3267:
  %v13297 = load i64, ptr %slot2425, align 8
  %op13298 = sub i64 %v13297, 24
  store i64 %op13298, ptr %slot2431, align 8
  %v13299 = load i64, ptr %slot2425, align 8
  %p13300 = inttoptr i64 %v13299 to ptr
  %rgep13301 = getelementptr i8, ptr %p13300, i64 -24
  %ld13302 = load i64, ptr %rgep13301, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13302, ptr %slot2432, align 8
  %v13303 = load i64, ptr %slot2432, align 8
  %op13304 = sub i64 %v13303, 1
  store i64 %op13304, ptr %slot2433, align 8
  %v13305 = load i64, ptr %slot2433, align 8
  %cmp13306 = icmp eq i64 %v13305, 0
  %cv13307 = zext i1 %cmp13306 to i32
  store i32 %cv13307, ptr %slot2434, align 8
  %v13308 = load i32, ptr %slot2434, align 8
  %cv13309 = zext i32 %v13308 to i64
  %cond13310 = icmp ne i64 %cv13309, 0
  br i1 %cond13310, label %bb_rcglast3267, label %bb_rcgdec3267
bb_rcglast3267:
  %v13311 = load i64, ptr %slot2425, align 8
  %op13312 = sub i64 %v13311, 32
  store i64 %op13312, ptr %slot2435, align 8
  %v13313 = load i64, ptr %slot2425, align 8
  %p13314 = inttoptr i64 %v13313 to ptr
  %rgep13315 = getelementptr i8, ptr %p13314, i64 -32
  %ld13316 = load i64, ptr %rgep13315, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13316, ptr %slot2436, align 8
  %v13317 = load i64, ptr %slot2436, align 8
  %cmp13318 = icmp ne i64 %v13317, 0
  %cv13319 = zext i1 %cmp13318 to i32
  store i32 %cv13319, ptr %slot2437, align 8
  %v13320 = load i32, ptr %slot2437, align 8
  %cv13321 = zext i32 %v13320 to i64
  %cond13322 = icmp ne i64 %cv13321, 0
  br i1 %cond13322, label %bb_rcgdec3267, label %bb_rcgslow3267
bb_rcgslow3267:
  %v13323 = load i64, ptr %slot2424, align 8
  %v13324 = load i64, ptr %slot2421, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v13323, i64 %v13324) nomerge, !dbg !254
  br label %bb_rcgdone3267
bb_rcgdec3267:
  %v13325 = load i64, ptr %slot2433, align 8
  %v13326 = load i64, ptr %slot2425, align 8
  %p13327 = inttoptr i64 %v13326 to ptr
  %rgep13328 = getelementptr i8, ptr %p13327, i64 -24
  store i64 %v13325, ptr %rgep13328, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3267
bb_rcgclear3267:
  %v13329 = load i64, ptr %slot2421, align 8
  %p13330 = inttoptr i64 %v13329 to ptr
  store i64 0, ptr %p13330, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3267
bb_rcgdone3267:
  br label %bb_rcslotdone3251
bb_rcslotowner3251:
  %v13331 = load i64, ptr %slot99, align 8
  store i64 %v13331, ptr %slot2438, align 8
  %v13332 = load i64, ptr %slot2421, align 8
  %p13333 = inttoptr i64 %v13332 to ptr
  %ld13334 = load i64, ptr %p13333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13334, ptr %slot2439, align 8
  %v13335 = load i64, ptr %slot2439, align 8
  %cmp13336 = icmp ne i64 %v13335, 0
  %cv13337 = zext i1 %cmp13336 to i32
  store i32 %cv13337, ptr %slot2440, align 8
  %v13338 = load i32, ptr %slot2440, align 8
  %cv13339 = zext i32 %v13338 to i64
  %cond13340 = icmp ne i64 %cv13339, 0
  br i1 %cond13340, label %bb_rcgnn3282, label %bb_rcgdone3282
bb_rcgnn3282:
  %v13341 = load i64, ptr %slot2439, align 8
  %op13342 = sub i64 %v13341, 16
  store i64 %op13342, ptr %slot2441, align 8
  %v13343 = load i64, ptr %slot2439, align 8
  %p13344 = inttoptr i64 %v13343 to ptr
  %rgep13345 = getelementptr i8, ptr %p13344, i64 -16
  %ld13346 = load i64, ptr %rgep13345, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13346, ptr %slot2442, align 8
  %v13347 = load i64, ptr %slot2442, align 8
  %op13348 = and i64 %v13347, 4611686018427387906
  store i64 %op13348, ptr %slot2443, align 8
  %v13349 = load i64, ptr %slot2443, align 8
  %cmp13350 = icmp ne i64 %v13349, 0
  %cv13351 = zext i1 %cmp13350 to i32
  store i32 %cv13351, ptr %slot2444, align 8
  %v13352 = load i32, ptr %slot2444, align 8
  %cv13353 = zext i32 %v13352 to i64
  %cond13354 = icmp ne i64 %cv13353, 0
  br i1 %cond13354, label %bb_rcgclear3282, label %bb_rcgcounted3282
bb_rcgcounted3282:
  %v13355 = load i64, ptr %slot2439, align 8
  %op13356 = sub i64 %v13355, 32
  store i64 %op13356, ptr %slot2445, align 8
  %v13357 = load i64, ptr %slot2439, align 8
  %p13358 = inttoptr i64 %v13357 to ptr
  %rgep13359 = getelementptr i8, ptr %p13358, i64 -32
  %ld13360 = load i64, ptr %rgep13359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13360, ptr %slot2446, align 8
  %v13361 = load i64, ptr %slot2446, align 8
  %op13362 = sub i64 %v13361, 1
  store i64 %op13362, ptr %slot2447, align 8
  %v13363 = load i64, ptr %slot2447, align 8
  %cmp13364 = icmp eq i64 %v13363, 0
  %cv13365 = zext i1 %cmp13364 to i32
  store i32 %cv13365, ptr %slot2448, align 8
  %v13366 = load i32, ptr %slot2448, align 8
  %cv13367 = zext i32 %v13366 to i64
  %cond13368 = icmp ne i64 %cv13367, 0
  br i1 %cond13368, label %bb_rcglast3282, label %bb_rcgdec3282
bb_rcglast3282:
  %v13369 = load i64, ptr %slot2439, align 8
  %op13370 = sub i64 %v13369, 24
  store i64 %op13370, ptr %slot2449, align 8
  %v13371 = load i64, ptr %slot2439, align 8
  %p13372 = inttoptr i64 %v13371 to ptr
  %rgep13373 = getelementptr i8, ptr %p13372, i64 -24
  %ld13374 = load i64, ptr %rgep13373, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13374, ptr %slot2450, align 8
  %v13375 = load i64, ptr %slot2450, align 8
  %cmp13376 = icmp ne i64 %v13375, 0
  %cv13377 = zext i1 %cmp13376 to i32
  store i32 %cv13377, ptr %slot2451, align 8
  %v13378 = load i32, ptr %slot2451, align 8
  %cv13379 = zext i32 %v13378 to i64
  %cond13380 = icmp ne i64 %cv13379, 0
  br i1 %cond13380, label %bb_rcgdec3282, label %bb_rcgslow3282
bb_rcgslow3282:
  %v13381 = load i64, ptr %slot2438, align 8
  %v13382 = load i64, ptr %slot2421, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v13381, i64 %v13382) nomerge, !dbg !254
  br label %bb_rcgdone3282
bb_rcgdec3282:
  %v13383 = load i64, ptr %slot2447, align 8
  %v13384 = load i64, ptr %slot2439, align 8
  %p13385 = inttoptr i64 %v13384 to ptr
  %rgep13386 = getelementptr i8, ptr %p13385, i64 -32
  store i64 %v13383, ptr %rgep13386, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3282
bb_rcgclear3282:
  %v13387 = load i64, ptr %slot2421, align 8
  %p13388 = inttoptr i64 %v13387 to ptr
  store i64 0, ptr %p13388, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3282
bb_rcgdone3282:
  br label %bb_rcslotdone3251
bb_rcslotdone3251:
  %v13389 = load i64, ptr %slot24, align 8
  store i64 %v13389, ptr %slot2452, align 8
  %v13390 = load i64, ptr %slot30, align 8
  store i64 %v13390, ptr %slot2453, align 8
  %v13391 = load i64, ptr %slot2453, align 8
  %v13392 = load i64, ptr %slot2452, align 8
  %p13393 = inttoptr i64 %v13391 to ptr
  %p13394 = inttoptr i64 %v13392 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13394, ptr %p13393, i64 48, i1 false), !alias.scope !3, !noalias !4
  %v13395 = load i64, ptr %slot16, align 8
  %p13396 = inttoptr i64 %v13395 to ptr
  store i32 2, ptr %p13396, align 4, !alias.scope !3, !noalias !4
  %v13397 = load i64, ptr %slot22, align 8
  %p13398 = inttoptr i64 %v13397 to ptr
  %ld13399 = load i32, ptr %p13398, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13399, ptr %slot2454, align 8
  %v13400 = load i32, ptr %slot2454, align 8
  %v13401 = load i64, ptr %slot16, align 8
  %p13402 = inttoptr i64 %v13401 to ptr
  store i32 %v13400, ptr %p13402, align 4, !alias.scope !3, !noalias !4
  %v13403 = load i64, ptr %slot21, align 8
  %p13404 = inttoptr i64 %v13403 to ptr
  store i32 0, ptr %p13404, align 4, !alias.scope !3, !noalias !4
  %v13405 = load i64, ptr %slot15, align 8
  %p13406 = inttoptr i64 %v13405 to ptr
  store i32 1, ptr %p13406, align 4, !alias.scope !3, !noalias !4
  %v13407 = load i64, ptr %slot2452, align 8
  %v13408 = load i64, ptr %slot44, align 8
  %p13409 = inttoptr i64 %v13408 to ptr
  store i64 %v13407, ptr %p13409, align 8, !alias.scope !3, !noalias !4
  %v13410 = load i64, ptr %slot44, align 8
  %p13411 = inttoptr i64 %v13410 to ptr
  %ld13412 = load i64, ptr %p13411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13412, ptr %slot2455, align 8
  %v13413 = load i64, ptr %slot2455, align 8
  %p13414 = inttoptr i64 %v13413 to ptr
  %ld13415 = load i32, ptr %p13414, align 4
  %ext13416 = zext i32 %ld13415 to i64
  store i64 %ext13416, ptr %slot2456, align 8
  %v13417 = load i64, ptr %slot2456, align 8
  %cmp13418 = icmp eq i64 %v13417, 0
  %cv13419 = zext i1 %cmp13418 to i64
  store i64 %cv13419, ptr %slot2457, align 8
  %v13420 = load i64, ptr %slot2457, align 8
  %cond13421 = icmp ne i64 %v13420, 0
  br i1 %cond13421, label %bb_rctryok3295, label %bb_rctryerror3295
bb_rctryerror3295:
  %p13422 = inttoptr i64 ptrtoint (ptr @myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p13422, i64 12884902066) "call-inline-cost"="0", !dbg !256
  %v13423 = load i64, ptr %slot2455, align 8
  %op13424 = add i64 %v13423, 8
  store i64 %op13424, ptr %slot2458, align 8
  %v13425 = load i64, ptr %slot88, align 8
  store i64 %v13425, ptr %slot2459, align 8
  %v13426 = load i64, ptr %slot2459, align 8
  %p13427 = inttoptr i64 %v13426 to ptr
  store i64 0, ptr %p13427, align 8, !alias.scope !3, !noalias !4
  %v13428 = load i64, ptr %slot2459, align 8
  %p13430 = inttoptr i64 %v13428 to ptr
  %gep13431 = getelementptr i8, ptr %p13430, i64 8
  %op13429 = ptrtoint ptr %gep13431 to i64
  store i64 %op13429, ptr %slot2460, align 8
  %v13432 = load i64, ptr %slot2460, align 8
  %p13433 = inttoptr i64 %v13432 to ptr
  store i64 0, ptr %p13433, align 8, !alias.scope !3, !noalias !4
  %v13434 = load i64, ptr %slot2459, align 8
  %p13435 = inttoptr i64 %v13434 to ptr
  store i32 1, ptr %p13435, align 4, !alias.scope !3, !noalias !4
  %v13436 = load i64, ptr %slot2459, align 8
  %p13438 = inttoptr i64 %v13436 to ptr
  %gep13439 = getelementptr i8, ptr %p13438, i64 8
  %op13437 = ptrtoint ptr %gep13439 to i64
  store i64 %op13437, ptr %slot2461, align 8
  %v13440 = load i64, ptr %slot23, align 8
  %p13441 = inttoptr i64 %v13440 to ptr
  store i32 1, ptr %p13441, align 4, !alias.scope !3, !noalias !4
  %v13442 = load i64, ptr %slot100, align 8
  store i64 %v13442, ptr %slot2462, align 8
  %v13443 = load i64, ptr %slot2459, align 8
  %v13444 = load i64, ptr %slot44, align 8
  %p13445 = inttoptr i64 %v13444 to ptr
  store i64 %v13443, ptr %p13445, align 8, !alias.scope !3, !noalias !4
  %v13446 = load i64, ptr %slot15, align 8
  %p13447 = inttoptr i64 %v13446 to ptr
  %ld13448 = load i32, ptr %p13447, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13448, ptr %slot2463, align 8
  %v13449 = load i32, ptr %slot2463, align 8
  %cv13450 = zext i32 %v13449 to i64
  %cond13451 = icmp ne i64 %cv13450, 0
  br i1 %cond13451, label %bb_rcslotdrop3306, label %bb_rcslotdone3306
bb_rcslotdrop3306:
  %v13452 = load i64, ptr %slot15, align 8
  %p13453 = inttoptr i64 %v13452 to ptr
  store i32 0, ptr %p13453, align 4, !alias.scope !3, !noalias !4
  %v13454 = load i64, ptr %slot24, align 8
  store i64 %v13454, ptr %slot2464, align 8
  %v13455 = load i64, ptr %slot16, align 8
  %p13456 = inttoptr i64 %v13455 to ptr
  %ld13457 = load i32, ptr %p13456, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13457, ptr %slot2465, align 8
  %v13458 = load i32, ptr %slot2465, align 8
  %op13459 = and i32 %v13458, 28
  store i32 %op13459, ptr %slot2466, align 8
  %v13460 = load i32, ptr %slot2466, align 8
  %cv13461 = zext i32 %v13460 to i64
  %cond13462 = icmp ne i64 %cv13461, 0
  br i1 %cond13462, label %bb_rcslotrole3306, label %bb_rcslotowner3306
bb_rcslotrole3306:
  %v13463 = load i64, ptr %slot99, align 8
  store i64 %v13463, ptr %slot2467, align 8
  %v13464 = load i64, ptr %slot2467, align 8
  %v13465 = load i64, ptr %slot2464, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v13464, i64 %v13465) nomerge, !dbg !256
  br label %bb_rcslotdone3306
bb_rcslotowner3306:
  %v13466 = load i64, ptr %slot99, align 8
  store i64 %v13466, ptr %slot2468, align 8
  %v13467 = load i64, ptr %slot2468, align 8
  %v13468 = load i64, ptr %slot2464, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v13467, i64 %v13468) nomerge, !dbg !256
  br label %bb_rcslotdone3306
bb_rcslotdone3306:
  br label %bb_i180
bb_rctryok3295:
  %v13469 = load i64, ptr %slot88, align 8
  store i64 %v13469, ptr %slot2469, align 8
  %v13470 = load i64, ptr %slot2469, align 8
  %p13471 = inttoptr i64 %v13470 to ptr
  store i64 0, ptr %p13471, align 8, !alias.scope !3, !noalias !4
  %v13472 = load i64, ptr %slot2469, align 8
  %p13474 = inttoptr i64 %v13472 to ptr
  %gep13475 = getelementptr i8, ptr %p13474, i64 8
  %op13473 = ptrtoint ptr %gep13475 to i64
  store i64 %op13473, ptr %slot2470, align 8
  %v13476 = load i64, ptr %slot2470, align 8
  %p13477 = inttoptr i64 %v13476 to ptr
  store i64 0, ptr %p13477, align 8, !alias.scope !3, !noalias !4
  %v13478 = load i64, ptr %slot2469, align 8
  %p13480 = inttoptr i64 %v13478 to ptr
  %gep13481 = getelementptr i8, ptr %p13480, i64 16
  %op13479 = ptrtoint ptr %gep13481 to i64
  store i64 %op13479, ptr %slot2471, align 8
  %v13482 = load i64, ptr %slot2471, align 8
  %p13483 = inttoptr i64 %v13482 to ptr
  store i64 0, ptr %p13483, align 8, !alias.scope !3, !noalias !4
  %v13484 = load i64, ptr %slot2469, align 8
  %p13486 = inttoptr i64 %v13484 to ptr
  %gep13487 = getelementptr i8, ptr %p13486, i64 24
  %op13485 = ptrtoint ptr %gep13487 to i64
  store i64 %op13485, ptr %slot2472, align 8
  %v13488 = load i64, ptr %slot2472, align 8
  %p13489 = inttoptr i64 %v13488 to ptr
  store i64 0, ptr %p13489, align 8, !alias.scope !3, !noalias !4
  %v13490 = load i64, ptr %slot2469, align 8
  %p13492 = inttoptr i64 %v13490 to ptr
  %gep13493 = getelementptr i8, ptr %p13492, i64 32
  %op13491 = ptrtoint ptr %gep13493 to i64
  store i64 %op13491, ptr %slot2473, align 8
  %v13494 = load i64, ptr %slot2473, align 8
  %p13495 = inttoptr i64 %v13494 to ptr
  store i64 0, ptr %p13495, align 8, !alias.scope !3, !noalias !4
  %v13496 = load i64, ptr %slot23, align 8
  %p13497 = inttoptr i64 %v13496 to ptr
  store i32 1, ptr %p13497, align 4, !alias.scope !3, !noalias !4
  %v13498 = load i64, ptr %slot2455, align 8
  %op13499 = add i64 %v13498, 8
  store i64 %op13499, ptr %slot2474, align 8
  %v13500 = load i64, ptr %slot100, align 8
  store i64 %v13500, ptr %slot2475, align 8
  %v13501 = load i64, ptr %slot99, align 8
  %v13502 = load i64, ptr %slot2469, align 8
  %v13503 = load i64, ptr %slot2474, align 8
  %v13504 = load i64, ptr %slot2475, align 8
  %cv13505 = trunc i64 %v13504 to i32
  %call13506 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64 %v13501, i64 %v13502, i64 %v13503, i32 %cv13505) nomerge, !dbg !256
  store i32 %call13506, ptr %slot2476, align 8
  %v13507 = load i32, ptr %slot2476, align 8
  %cv13508 = zext i32 %v13507 to i64
  %cond13509 = icmp ne i64 %cv13508, 0
  br i1 %cond13509, label %bb_rcsuccess3323, label %bb_rcfailure3323
bb_rcfailure3323:
  %v13510 = load i64, ptr %slot99, align 8
  %p13511 = inttoptr i64 %v13510 to ptr
  %call13512 = call i32 @myl_rc_take_failure(ptr %p13511) nomerge, !dbg !256
  store i32 %call13512, ptr %slot2477, align 8
  %v13513 = load i64, ptr %slot1, align 8
  %p13514 = inttoptr i64 %v13513 to ptr
  %v13515 = load i32, ptr %slot2477, align 8
  %call13516 = call i32 @myl_qbe_rc_status(ptr %p13514, i32 %v13515) nomerge, !dbg !256
  store i32 %call13516, ptr %slot2478, align 8
  br label %bb_failure
bb_rcsuccess3323:
  %v13517 = load i64, ptr %slot2469, align 8
  %v13518 = load i64, ptr %slot44, align 8
  %p13519 = inttoptr i64 %v13518 to ptr
  store i64 %v13517, ptr %p13519, align 8, !alias.scope !3, !noalias !4
  %v13520 = load i64, ptr %slot44, align 8
  %p13521 = inttoptr i64 %v13520 to ptr
  %ld13522 = load i64, ptr %p13521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13522, ptr %slot2479, align 8
  %v13523 = load i64, ptr %slot30, align 8
  store i64 %v13523, ptr %slot2480, align 8
  %v13524 = load i64, ptr %slot2479, align 8
  %v13525 = load i64, ptr %slot2480, align 8
  %p13526 = inttoptr i64 %v13524 to ptr
  %p13527 = inttoptr i64 %v13525 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13527, ptr %p13526, i64 40, i1 false)
  %v13528 = load i64, ptr %slot22, align 8
  %p13529 = inttoptr i64 %v13528 to ptr
  store i32 2, ptr %p13529, align 4, !alias.scope !3, !noalias !4
  %v13530 = load i64, ptr %slot21, align 8
  %p13531 = inttoptr i64 %v13530 to ptr
  store i32 1, ptr %p13531, align 4, !alias.scope !3, !noalias !4
  %v13532 = load i64, ptr %slot15, align 8
  %p13533 = inttoptr i64 %v13532 to ptr
  %ld13534 = load i32, ptr %p13533, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13534, ptr %slot2481, align 8
  %v13535 = load i32, ptr %slot2481, align 8
  %cv13536 = zext i32 %v13535 to i64
  %cond13537 = icmp ne i64 %cv13536, 0
  br i1 %cond13537, label %bb_rcslotdrop3332, label %bb_rcslotdone3332
bb_rcslotdrop3332:
  %v13538 = load i64, ptr %slot15, align 8
  %p13539 = inttoptr i64 %v13538 to ptr
  store i32 0, ptr %p13539, align 4, !alias.scope !3, !noalias !4
  %v13540 = load i64, ptr %slot24, align 8
  store i64 %v13540, ptr %slot2482, align 8
  %v13541 = load i64, ptr %slot16, align 8
  %p13542 = inttoptr i64 %v13541 to ptr
  %ld13543 = load i32, ptr %p13542, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13543, ptr %slot2483, align 8
  %v13544 = load i32, ptr %slot2483, align 8
  %op13545 = and i32 %v13544, 28
  store i32 %op13545, ptr %slot2484, align 8
  %v13546 = load i32, ptr %slot2484, align 8
  %cv13547 = zext i32 %v13546 to i64
  %cond13548 = icmp ne i64 %cv13547, 0
  br i1 %cond13548, label %bb_rcslotrole3332, label %bb_rcslotowner3332
bb_rcslotrole3332:
  %v13549 = load i64, ptr %slot99, align 8
  store i64 %v13549, ptr %slot2485, align 8
  %v13550 = load i64, ptr %slot2485, align 8
  %v13551 = load i64, ptr %slot2482, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64 %v13550, i64 %v13551) nomerge, !dbg !256
  br label %bb_rcslotdone3332
bb_rcslotowner3332:
  %v13552 = load i64, ptr %slot99, align 8
  store i64 %v13552, ptr %slot2486, align 8
  %v13553 = load i64, ptr %slot2486, align 8
  %v13554 = load i64, ptr %slot2482, align 8
  call void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64 %v13553, i64 %v13554) nomerge, !dbg !256
  br label %bb_rcslotdone3332
bb_rcslotdone3332:
  %v13555 = load i64, ptr %slot24, align 8
  store i64 %v13555, ptr %slot2487, align 8
  %v13556 = load i64, ptr %slot30, align 8
  store i64 %v13556, ptr %slot2488, align 8
  %v13557 = load i64, ptr %slot2488, align 8
  %v13558 = load i64, ptr %slot2487, align 8
  %p13559 = inttoptr i64 %v13557 to ptr
  %p13560 = inttoptr i64 %v13558 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13560, ptr %p13559, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v13561 = load i64, ptr %slot16, align 8
  %p13562 = inttoptr i64 %v13561 to ptr
  store i32 2, ptr %p13562, align 4, !alias.scope !3, !noalias !4
  %v13563 = load i64, ptr %slot22, align 8
  %p13564 = inttoptr i64 %v13563 to ptr
  %ld13565 = load i32, ptr %p13564, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13565, ptr %slot2489, align 8
  %v13566 = load i32, ptr %slot2489, align 8
  %v13567 = load i64, ptr %slot16, align 8
  %p13568 = inttoptr i64 %v13567 to ptr
  store i32 %v13566, ptr %p13568, align 4, !alias.scope !3, !noalias !4
  %v13569 = load i64, ptr %slot21, align 8
  %p13570 = inttoptr i64 %v13569 to ptr
  store i32 0, ptr %p13570, align 4, !alias.scope !3, !noalias !4
  %v13571 = load i64, ptr %slot15, align 8
  %p13572 = inttoptr i64 %v13571 to ptr
  store i32 1, ptr %p13572, align 4, !alias.scope !3, !noalias !4
  %v13573 = load i64, ptr %slot2487, align 8
  %v13574 = load i64, ptr %slot44, align 8
  %p13575 = inttoptr i64 %v13574 to ptr
  store i64 %v13573, ptr %p13575, align 8, !alias.scope !3, !noalias !4
  br label %bb_i181
bb_i180:
  %v13576 = load i64, ptr %slot44, align 8
  %p13577 = inttoptr i64 %v13576 to ptr
  %ld13578 = load i64, ptr %p13577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13578, ptr %slot2490, align 8
  %v13579 = load i64, ptr %slot15, align 8
  %p13580 = inttoptr i64 %v13579 to ptr
  %ld13581 = load i32, ptr %p13580, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13581, ptr %slot2491, align 8
  %v13582 = load i32, ptr %slot2491, align 8
  %cv13583 = zext i32 %v13582 to i64
  %cond13584 = icmp ne i64 %cv13583, 0
  br i1 %cond13584, label %bb_rcslotdrop3350, label %bb_rcslotdone3350
bb_rcslotdrop3350:
  %v13585 = load i64, ptr %slot15, align 8
  %p13586 = inttoptr i64 %v13585 to ptr
  store i32 0, ptr %p13586, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone3350
bb_rcslotdone3350:
  %v13587 = load i64, ptr %slot13, align 8
  %p13588 = inttoptr i64 %v13587 to ptr
  %ld13589 = load i32, ptr %p13588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13589, ptr %slot2492, align 8
  %v13590 = load i32, ptr %slot2492, align 8
  %cv13591 = zext i32 %v13590 to i64
  %cond13592 = icmp ne i64 %cv13591, 0
  br i1 %cond13592, label %bb_rcslotdrop3353, label %bb_rcslotdone3353
bb_rcslotdrop3353:
  %v13593 = load i64, ptr %slot13, align 8
  %p13594 = inttoptr i64 %v13593 to ptr
  store i32 0, ptr %p13594, align 4, !alias.scope !3, !noalias !4
  %v13595 = load i64, ptr %slot42, align 8
  store i64 %v13595, ptr %slot2493, align 8
  %v13596 = load i64, ptr %slot14, align 8
  %p13597 = inttoptr i64 %v13596 to ptr
  %ld13598 = load i32, ptr %p13597, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13598, ptr %slot2494, align 8
  %v13599 = load i32, ptr %slot2494, align 8
  %op13600 = and i32 %v13599, 28
  store i32 %op13600, ptr %slot2495, align 8
  %v13601 = load i32, ptr %slot2495, align 8
  %cv13602 = zext i32 %v13601 to i64
  %cond13603 = icmp ne i64 %cv13602, 0
  br i1 %cond13603, label %bb_rcslotrole3353, label %bb_rcslotowner3353
bb_rcslotrole3353:
  %v13604 = load i64, ptr %slot99, align 8
  store i64 %v13604, ptr %slot2496, align 8
  %v13605 = load i64, ptr %slot2496, align 8
  %v13606 = load i64, ptr %slot2493, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v13605, i64 %v13606) nomerge, !dbg !258
  br label %bb_rcslotdone3353
bb_rcslotowner3353:
  %v13607 = load i64, ptr %slot99, align 8
  store i64 %v13607, ptr %slot2497, align 8
  %v13608 = load i64, ptr %slot2497, align 8
  %v13609 = load i64, ptr %slot2493, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v13608, i64 %v13609) nomerge, !dbg !258
  br label %bb_rcslotdone3353
bb_rcslotdone3353:
  %v13610 = load i64, ptr %slot11, align 8
  %p13611 = inttoptr i64 %v13610 to ptr
  %ld13612 = load i32, ptr %p13611, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13612, ptr %slot2498, align 8
  %v13613 = load i32, ptr %slot2498, align 8
  %cv13614 = zext i32 %v13613 to i64
  %cond13615 = icmp ne i64 %cv13614, 0
  br i1 %cond13615, label %bb_rcslotdrop3362, label %bb_rcslotdone3362
bb_rcslotdrop3362:
  %v13616 = load i64, ptr %slot11, align 8
  %p13617 = inttoptr i64 %v13616 to ptr
  store i32 0, ptr %p13617, align 4, !alias.scope !3, !noalias !4
  %v13618 = load i64, ptr %slot41, align 8
  store i64 %v13618, ptr %slot2499, align 8
  %v13619 = load i64, ptr %slot12, align 8
  %p13620 = inttoptr i64 %v13619 to ptr
  %ld13621 = load i32, ptr %p13620, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13621, ptr %slot2500, align 8
  %v13622 = load i32, ptr %slot2500, align 8
  %op13623 = and i32 %v13622, 28
  store i32 %op13623, ptr %slot2501, align 8
  %v13624 = load i32, ptr %slot2501, align 8
  %cv13625 = zext i32 %v13624 to i64
  %cond13626 = icmp ne i64 %cv13625, 0
  br i1 %cond13626, label %bb_rcslotrole3362, label %bb_rcslotowner3362
bb_rcslotrole3362:
  %v13627 = load i64, ptr %slot99, align 8
  store i64 %v13627, ptr %slot2502, align 8
  %v13628 = load i64, ptr %slot2502, align 8
  %v13629 = load i64, ptr %slot2499, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v13628, i64 %v13629) nomerge, !dbg !258
  br label %bb_rcslotdone3362
bb_rcslotowner3362:
  %v13630 = load i64, ptr %slot99, align 8
  store i64 %v13630, ptr %slot2503, align 8
  %v13631 = load i64, ptr %slot2503, align 8
  %v13632 = load i64, ptr %slot2499, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v13631, i64 %v13632) nomerge, !dbg !258
  br label %bb_rcslotdone3362
bb_rcslotdone3362:
  %v13633 = load i64, ptr %slot9, align 8
  %p13634 = inttoptr i64 %v13633 to ptr
  %ld13635 = load i32, ptr %p13634, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13635, ptr %slot2504, align 8
  %v13636 = load i32, ptr %slot2504, align 8
  %cv13637 = zext i32 %v13636 to i64
  %cond13638 = icmp ne i64 %cv13637, 0
  br i1 %cond13638, label %bb_rcslotdrop3371, label %bb_rcslotdone3371
bb_rcslotdrop3371:
  %v13639 = load i64, ptr %slot9, align 8
  %p13640 = inttoptr i64 %v13639 to ptr
  store i32 0, ptr %p13640, align 4, !alias.scope !3, !noalias !4
  %v13641 = load i64, ptr %slot39, align 8
  store i64 %v13641, ptr %slot2505, align 8
  %v13642 = load i64, ptr %slot10, align 8
  %p13643 = inttoptr i64 %v13642 to ptr
  %ld13644 = load i32, ptr %p13643, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13644, ptr %slot2506, align 8
  %v13645 = load i32, ptr %slot2506, align 8
  %op13646 = and i32 %v13645, 28
  store i32 %op13646, ptr %slot2507, align 8
  %v13647 = load i32, ptr %slot2507, align 8
  %cv13648 = zext i32 %v13647 to i64
  %cond13649 = icmp ne i64 %cv13648, 0
  br i1 %cond13649, label %bb_rcslotrole3371, label %bb_rcslotowner3371
bb_rcslotrole3371:
  %v13650 = load i64, ptr %slot99, align 8
  store i64 %v13650, ptr %slot2508, align 8
  %v13651 = load i64, ptr %slot2505, align 8
  %p13652 = inttoptr i64 %v13651 to ptr
  %ld13653 = load i64, ptr %p13652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13653, ptr %slot2509, align 8
  %v13654 = load i64, ptr %slot2509, align 8
  %cmp13655 = icmp ne i64 %v13654, 0
  %cv13656 = zext i1 %cmp13655 to i32
  store i32 %cv13656, ptr %slot2510, align 8
  %v13657 = load i32, ptr %slot2510, align 8
  %cv13658 = zext i32 %v13657 to i64
  %cond13659 = icmp ne i64 %cv13658, 0
  br i1 %cond13659, label %bb_rcgnn3387, label %bb_rcgdone3387
bb_rcgnn3387:
  %v13660 = load i64, ptr %slot2509, align 8
  %op13661 = sub i64 %v13660, 16
  store i64 %op13661, ptr %slot2511, align 8
  %v13662 = load i64, ptr %slot2509, align 8
  %p13663 = inttoptr i64 %v13662 to ptr
  %rgep13664 = getelementptr i8, ptr %p13663, i64 -16
  %ld13665 = load i64, ptr %rgep13664, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13665, ptr %slot2512, align 8
  %v13666 = load i64, ptr %slot2512, align 8
  %op13667 = and i64 %v13666, 4611686018427387906
  store i64 %op13667, ptr %slot2513, align 8
  %v13668 = load i64, ptr %slot2513, align 8
  %cmp13669 = icmp ne i64 %v13668, 0
  %cv13670 = zext i1 %cmp13669 to i32
  store i32 %cv13670, ptr %slot2514, align 8
  %v13671 = load i32, ptr %slot2514, align 8
  %cv13672 = zext i32 %v13671 to i64
  %cond13673 = icmp ne i64 %cv13672, 0
  br i1 %cond13673, label %bb_rcgclear3387, label %bb_rcgcounted3387
bb_rcgcounted3387:
  %v13674 = load i64, ptr %slot2509, align 8
  %op13675 = sub i64 %v13674, 24
  store i64 %op13675, ptr %slot2515, align 8
  %v13676 = load i64, ptr %slot2509, align 8
  %p13677 = inttoptr i64 %v13676 to ptr
  %rgep13678 = getelementptr i8, ptr %p13677, i64 -24
  %ld13679 = load i64, ptr %rgep13678, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13679, ptr %slot2516, align 8
  %v13680 = load i64, ptr %slot2516, align 8
  %op13681 = sub i64 %v13680, 1
  store i64 %op13681, ptr %slot2517, align 8
  %v13682 = load i64, ptr %slot2517, align 8
  %cmp13683 = icmp eq i64 %v13682, 0
  %cv13684 = zext i1 %cmp13683 to i32
  store i32 %cv13684, ptr %slot2518, align 8
  %v13685 = load i32, ptr %slot2518, align 8
  %cv13686 = zext i32 %v13685 to i64
  %cond13687 = icmp ne i64 %cv13686, 0
  br i1 %cond13687, label %bb_rcglast3387, label %bb_rcgdec3387
bb_rcglast3387:
  %v13688 = load i64, ptr %slot2509, align 8
  %op13689 = sub i64 %v13688, 32
  store i64 %op13689, ptr %slot2519, align 8
  %v13690 = load i64, ptr %slot2509, align 8
  %p13691 = inttoptr i64 %v13690 to ptr
  %rgep13692 = getelementptr i8, ptr %p13691, i64 -32
  %ld13693 = load i64, ptr %rgep13692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13693, ptr %slot2520, align 8
  %v13694 = load i64, ptr %slot2520, align 8
  %cmp13695 = icmp ne i64 %v13694, 0
  %cv13696 = zext i1 %cmp13695 to i32
  store i32 %cv13696, ptr %slot2521, align 8
  %v13697 = load i32, ptr %slot2521, align 8
  %cv13698 = zext i32 %v13697 to i64
  %cond13699 = icmp ne i64 %cv13698, 0
  br i1 %cond13699, label %bb_rcgdec3387, label %bb_rcgslow3387
bb_rcgslow3387:
  %v13700 = load i64, ptr %slot2508, align 8
  %v13701 = load i64, ptr %slot2505, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v13700, i64 %v13701) nomerge, !dbg !258
  br label %bb_rcgdone3387
bb_rcgdec3387:
  %v13702 = load i64, ptr %slot2517, align 8
  %v13703 = load i64, ptr %slot2509, align 8
  %p13704 = inttoptr i64 %v13703 to ptr
  %rgep13705 = getelementptr i8, ptr %p13704, i64 -24
  store i64 %v13702, ptr %rgep13705, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3387
bb_rcgclear3387:
  %v13706 = load i64, ptr %slot2505, align 8
  %p13707 = inttoptr i64 %v13706 to ptr
  store i64 0, ptr %p13707, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3387
bb_rcgdone3387:
  br label %bb_rcslotdone3371
bb_rcslotowner3371:
  %v13708 = load i64, ptr %slot99, align 8
  store i64 %v13708, ptr %slot2522, align 8
  %v13709 = load i64, ptr %slot2505, align 8
  %p13710 = inttoptr i64 %v13709 to ptr
  %ld13711 = load i64, ptr %p13710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13711, ptr %slot2523, align 8
  %v13712 = load i64, ptr %slot2523, align 8
  %cmp13713 = icmp ne i64 %v13712, 0
  %cv13714 = zext i1 %cmp13713 to i32
  store i32 %cv13714, ptr %slot2524, align 8
  %v13715 = load i32, ptr %slot2524, align 8
  %cv13716 = zext i32 %v13715 to i64
  %cond13717 = icmp ne i64 %cv13716, 0
  br i1 %cond13717, label %bb_rcgnn3402, label %bb_rcgdone3402
bb_rcgnn3402:
  %v13718 = load i64, ptr %slot2523, align 8
  %op13719 = sub i64 %v13718, 16
  store i64 %op13719, ptr %slot2525, align 8
  %v13720 = load i64, ptr %slot2523, align 8
  %p13721 = inttoptr i64 %v13720 to ptr
  %rgep13722 = getelementptr i8, ptr %p13721, i64 -16
  %ld13723 = load i64, ptr %rgep13722, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13723, ptr %slot2526, align 8
  %v13724 = load i64, ptr %slot2526, align 8
  %op13725 = and i64 %v13724, 4611686018427387906
  store i64 %op13725, ptr %slot2527, align 8
  %v13726 = load i64, ptr %slot2527, align 8
  %cmp13727 = icmp ne i64 %v13726, 0
  %cv13728 = zext i1 %cmp13727 to i32
  store i32 %cv13728, ptr %slot2528, align 8
  %v13729 = load i32, ptr %slot2528, align 8
  %cv13730 = zext i32 %v13729 to i64
  %cond13731 = icmp ne i64 %cv13730, 0
  br i1 %cond13731, label %bb_rcgclear3402, label %bb_rcgcounted3402
bb_rcgcounted3402:
  %v13732 = load i64, ptr %slot2523, align 8
  %op13733 = sub i64 %v13732, 32
  store i64 %op13733, ptr %slot2529, align 8
  %v13734 = load i64, ptr %slot2523, align 8
  %p13735 = inttoptr i64 %v13734 to ptr
  %rgep13736 = getelementptr i8, ptr %p13735, i64 -32
  %ld13737 = load i64, ptr %rgep13736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13737, ptr %slot2530, align 8
  %v13738 = load i64, ptr %slot2530, align 8
  %op13739 = sub i64 %v13738, 1
  store i64 %op13739, ptr %slot2531, align 8
  %v13740 = load i64, ptr %slot2531, align 8
  %cmp13741 = icmp eq i64 %v13740, 0
  %cv13742 = zext i1 %cmp13741 to i32
  store i32 %cv13742, ptr %slot2532, align 8
  %v13743 = load i32, ptr %slot2532, align 8
  %cv13744 = zext i32 %v13743 to i64
  %cond13745 = icmp ne i64 %cv13744, 0
  br i1 %cond13745, label %bb_rcglast3402, label %bb_rcgdec3402
bb_rcglast3402:
  %v13746 = load i64, ptr %slot2523, align 8
  %op13747 = sub i64 %v13746, 24
  store i64 %op13747, ptr %slot2533, align 8
  %v13748 = load i64, ptr %slot2523, align 8
  %p13749 = inttoptr i64 %v13748 to ptr
  %rgep13750 = getelementptr i8, ptr %p13749, i64 -24
  %ld13751 = load i64, ptr %rgep13750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13751, ptr %slot2534, align 8
  %v13752 = load i64, ptr %slot2534, align 8
  %cmp13753 = icmp ne i64 %v13752, 0
  %cv13754 = zext i1 %cmp13753 to i32
  store i32 %cv13754, ptr %slot2535, align 8
  %v13755 = load i32, ptr %slot2535, align 8
  %cv13756 = zext i32 %v13755 to i64
  %cond13757 = icmp ne i64 %cv13756, 0
  br i1 %cond13757, label %bb_rcgdec3402, label %bb_rcgslow3402
bb_rcgslow3402:
  %v13758 = load i64, ptr %slot2522, align 8
  %v13759 = load i64, ptr %slot2505, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v13758, i64 %v13759) nomerge, !dbg !258
  br label %bb_rcgdone3402
bb_rcgdec3402:
  %v13760 = load i64, ptr %slot2531, align 8
  %v13761 = load i64, ptr %slot2523, align 8
  %p13762 = inttoptr i64 %v13761 to ptr
  %rgep13763 = getelementptr i8, ptr %p13762, i64 -32
  store i64 %v13760, ptr %rgep13763, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3402
bb_rcgclear3402:
  %v13764 = load i64, ptr %slot2505, align 8
  %p13765 = inttoptr i64 %v13764 to ptr
  store i64 0, ptr %p13765, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3402
bb_rcgdone3402:
  br label %bb_rcslotdone3371
bb_rcslotdone3371:
  %v13766 = load i64, ptr %slot7, align 8
  %p13767 = inttoptr i64 %v13766 to ptr
  %ld13768 = load i32, ptr %p13767, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13768, ptr %slot2536, align 8
  %v13769 = load i32, ptr %slot2536, align 8
  %cv13770 = zext i32 %v13769 to i64
  %cond13771 = icmp ne i64 %cv13770, 0
  br i1 %cond13771, label %bb_rcslotdrop3408, label %bb_rcslotdone3408
bb_rcslotdrop3408:
  %v13772 = load i64, ptr %slot7, align 8
  %p13773 = inttoptr i64 %v13772 to ptr
  store i32 0, ptr %p13773, align 4, !alias.scope !3, !noalias !4
  %v13774 = load i64, ptr %slot34, align 8
  store i64 %v13774, ptr %slot2537, align 8
  %v13775 = load i64, ptr %slot8, align 8
  %p13776 = inttoptr i64 %v13775 to ptr
  %ld13777 = load i32, ptr %p13776, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13777, ptr %slot2538, align 8
  %v13778 = load i32, ptr %slot2538, align 8
  %op13779 = and i32 %v13778, 28
  store i32 %op13779, ptr %slot2539, align 8
  %v13780 = load i32, ptr %slot2539, align 8
  %cv13781 = zext i32 %v13780 to i64
  %cond13782 = icmp ne i64 %cv13781, 0
  br i1 %cond13782, label %bb_rcslotrole3408, label %bb_rcslotowner3408
bb_rcslotrole3408:
  %v13783 = load i64, ptr %slot99, align 8
  store i64 %v13783, ptr %slot2540, align 8
  %v13784 = load i64, ptr %slot2537, align 8
  %p13785 = inttoptr i64 %v13784 to ptr
  %ld13786 = load i64, ptr %p13785, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13786, ptr %slot2541, align 8
  %v13787 = load i64, ptr %slot2541, align 8
  %cmp13788 = icmp ne i64 %v13787, 0
  %cv13789 = zext i1 %cmp13788 to i32
  store i32 %cv13789, ptr %slot2542, align 8
  %v13790 = load i32, ptr %slot2542, align 8
  %cv13791 = zext i32 %v13790 to i64
  %cond13792 = icmp ne i64 %cv13791, 0
  br i1 %cond13792, label %bb_rcgnn3424, label %bb_rcgdone3424
bb_rcgnn3424:
  %v13793 = load i64, ptr %slot2541, align 8
  %op13794 = sub i64 %v13793, 16
  store i64 %op13794, ptr %slot2543, align 8
  %v13795 = load i64, ptr %slot2541, align 8
  %p13796 = inttoptr i64 %v13795 to ptr
  %rgep13797 = getelementptr i8, ptr %p13796, i64 -16
  %ld13798 = load i64, ptr %rgep13797, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13798, ptr %slot2544, align 8
  %v13799 = load i64, ptr %slot2544, align 8
  %op13800 = and i64 %v13799, 4611686018427387906
  store i64 %op13800, ptr %slot2545, align 8
  %v13801 = load i64, ptr %slot2545, align 8
  %cmp13802 = icmp ne i64 %v13801, 0
  %cv13803 = zext i1 %cmp13802 to i32
  store i32 %cv13803, ptr %slot2546, align 8
  %v13804 = load i32, ptr %slot2546, align 8
  %cv13805 = zext i32 %v13804 to i64
  %cond13806 = icmp ne i64 %cv13805, 0
  br i1 %cond13806, label %bb_rcgclear3424, label %bb_rcgcounted3424
bb_rcgcounted3424:
  %v13807 = load i64, ptr %slot2541, align 8
  %op13808 = sub i64 %v13807, 24
  store i64 %op13808, ptr %slot2547, align 8
  %v13809 = load i64, ptr %slot2541, align 8
  %p13810 = inttoptr i64 %v13809 to ptr
  %rgep13811 = getelementptr i8, ptr %p13810, i64 -24
  %ld13812 = load i64, ptr %rgep13811, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13812, ptr %slot2548, align 8
  %v13813 = load i64, ptr %slot2548, align 8
  %op13814 = sub i64 %v13813, 1
  store i64 %op13814, ptr %slot2549, align 8
  %v13815 = load i64, ptr %slot2549, align 8
  %cmp13816 = icmp eq i64 %v13815, 0
  %cv13817 = zext i1 %cmp13816 to i32
  store i32 %cv13817, ptr %slot2550, align 8
  %v13818 = load i32, ptr %slot2550, align 8
  %cv13819 = zext i32 %v13818 to i64
  %cond13820 = icmp ne i64 %cv13819, 0
  br i1 %cond13820, label %bb_rcglast3424, label %bb_rcgdec3424
bb_rcglast3424:
  %v13821 = load i64, ptr %slot2541, align 8
  %op13822 = sub i64 %v13821, 32
  store i64 %op13822, ptr %slot2551, align 8
  %v13823 = load i64, ptr %slot2541, align 8
  %p13824 = inttoptr i64 %v13823 to ptr
  %rgep13825 = getelementptr i8, ptr %p13824, i64 -32
  %ld13826 = load i64, ptr %rgep13825, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13826, ptr %slot2552, align 8
  %v13827 = load i64, ptr %slot2552, align 8
  %cmp13828 = icmp ne i64 %v13827, 0
  %cv13829 = zext i1 %cmp13828 to i32
  store i32 %cv13829, ptr %slot2553, align 8
  %v13830 = load i32, ptr %slot2553, align 8
  %cv13831 = zext i32 %v13830 to i64
  %cond13832 = icmp ne i64 %cv13831, 0
  br i1 %cond13832, label %bb_rcgdec3424, label %bb_rcgslow3424
bb_rcgslow3424:
  %v13833 = load i64, ptr %slot2540, align 8
  %v13834 = load i64, ptr %slot2537, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v13833, i64 %v13834) nomerge, !dbg !258
  br label %bb_rcgdone3424
bb_rcgdec3424:
  %v13835 = load i64, ptr %slot2549, align 8
  %v13836 = load i64, ptr %slot2541, align 8
  %p13837 = inttoptr i64 %v13836 to ptr
  %rgep13838 = getelementptr i8, ptr %p13837, i64 -24
  store i64 %v13835, ptr %rgep13838, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3424
bb_rcgclear3424:
  %v13839 = load i64, ptr %slot2537, align 8
  %p13840 = inttoptr i64 %v13839 to ptr
  store i64 0, ptr %p13840, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3424
bb_rcgdone3424:
  br label %bb_rcslotdone3408
bb_rcslotowner3408:
  %v13841 = load i64, ptr %slot99, align 8
  store i64 %v13841, ptr %slot2554, align 8
  %v13842 = load i64, ptr %slot2537, align 8
  %p13843 = inttoptr i64 %v13842 to ptr
  %ld13844 = load i64, ptr %p13843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13844, ptr %slot2555, align 8
  %v13845 = load i64, ptr %slot2555, align 8
  %cmp13846 = icmp ne i64 %v13845, 0
  %cv13847 = zext i1 %cmp13846 to i32
  store i32 %cv13847, ptr %slot2556, align 8
  %v13848 = load i32, ptr %slot2556, align 8
  %cv13849 = zext i32 %v13848 to i64
  %cond13850 = icmp ne i64 %cv13849, 0
  br i1 %cond13850, label %bb_rcgnn3439, label %bb_rcgdone3439
bb_rcgnn3439:
  %v13851 = load i64, ptr %slot2555, align 8
  %op13852 = sub i64 %v13851, 16
  store i64 %op13852, ptr %slot2557, align 8
  %v13853 = load i64, ptr %slot2555, align 8
  %p13854 = inttoptr i64 %v13853 to ptr
  %rgep13855 = getelementptr i8, ptr %p13854, i64 -16
  %ld13856 = load i64, ptr %rgep13855, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13856, ptr %slot2558, align 8
  %v13857 = load i64, ptr %slot2558, align 8
  %op13858 = and i64 %v13857, 4611686018427387906
  store i64 %op13858, ptr %slot2559, align 8
  %v13859 = load i64, ptr %slot2559, align 8
  %cmp13860 = icmp ne i64 %v13859, 0
  %cv13861 = zext i1 %cmp13860 to i32
  store i32 %cv13861, ptr %slot2560, align 8
  %v13862 = load i32, ptr %slot2560, align 8
  %cv13863 = zext i32 %v13862 to i64
  %cond13864 = icmp ne i64 %cv13863, 0
  br i1 %cond13864, label %bb_rcgclear3439, label %bb_rcgcounted3439
bb_rcgcounted3439:
  %v13865 = load i64, ptr %slot2555, align 8
  %op13866 = sub i64 %v13865, 32
  store i64 %op13866, ptr %slot2561, align 8
  %v13867 = load i64, ptr %slot2555, align 8
  %p13868 = inttoptr i64 %v13867 to ptr
  %rgep13869 = getelementptr i8, ptr %p13868, i64 -32
  %ld13870 = load i64, ptr %rgep13869, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13870, ptr %slot2562, align 8
  %v13871 = load i64, ptr %slot2562, align 8
  %op13872 = sub i64 %v13871, 1
  store i64 %op13872, ptr %slot2563, align 8
  %v13873 = load i64, ptr %slot2563, align 8
  %cmp13874 = icmp eq i64 %v13873, 0
  %cv13875 = zext i1 %cmp13874 to i32
  store i32 %cv13875, ptr %slot2564, align 8
  %v13876 = load i32, ptr %slot2564, align 8
  %cv13877 = zext i32 %v13876 to i64
  %cond13878 = icmp ne i64 %cv13877, 0
  br i1 %cond13878, label %bb_rcglast3439, label %bb_rcgdec3439
bb_rcglast3439:
  %v13879 = load i64, ptr %slot2555, align 8
  %op13880 = sub i64 %v13879, 24
  store i64 %op13880, ptr %slot2565, align 8
  %v13881 = load i64, ptr %slot2555, align 8
  %p13882 = inttoptr i64 %v13881 to ptr
  %rgep13883 = getelementptr i8, ptr %p13882, i64 -24
  %ld13884 = load i64, ptr %rgep13883, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13884, ptr %slot2566, align 8
  %v13885 = load i64, ptr %slot2566, align 8
  %cmp13886 = icmp ne i64 %v13885, 0
  %cv13887 = zext i1 %cmp13886 to i32
  store i32 %cv13887, ptr %slot2567, align 8
  %v13888 = load i32, ptr %slot2567, align 8
  %cv13889 = zext i32 %v13888 to i64
  %cond13890 = icmp ne i64 %cv13889, 0
  br i1 %cond13890, label %bb_rcgdec3439, label %bb_rcgslow3439
bb_rcgslow3439:
  %v13891 = load i64, ptr %slot2554, align 8
  %v13892 = load i64, ptr %slot2537, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v13891, i64 %v13892) nomerge, !dbg !258
  br label %bb_rcgdone3439
bb_rcgdec3439:
  %v13893 = load i64, ptr %slot2563, align 8
  %v13894 = load i64, ptr %slot2555, align 8
  %p13895 = inttoptr i64 %v13894 to ptr
  %rgep13896 = getelementptr i8, ptr %p13895, i64 -32
  store i64 %v13893, ptr %rgep13896, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3439
bb_rcgclear3439:
  %v13897 = load i64, ptr %slot2537, align 8
  %p13898 = inttoptr i64 %v13897 to ptr
  store i64 0, ptr %p13898, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3439
bb_rcgdone3439:
  br label %bb_rcslotdone3408
bb_rcslotdone3408:
  %v13899 = load i64, ptr %slot5, align 8
  %p13900 = inttoptr i64 %v13899 to ptr
  %ld13901 = load i32, ptr %p13900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13901, ptr %slot2568, align 8
  %v13902 = load i32, ptr %slot2568, align 8
  %cv13903 = zext i32 %v13902 to i64
  %cond13904 = icmp ne i64 %cv13903, 0
  br i1 %cond13904, label %bb_rcslotdrop3445, label %bb_rcslotdone3445
bb_rcslotdrop3445:
  %v13905 = load i64, ptr %slot5, align 8
  %p13906 = inttoptr i64 %v13905 to ptr
  store i32 0, ptr %p13906, align 4, !alias.scope !3, !noalias !4
  %v13907 = load i64, ptr %slot33, align 8
  store i64 %v13907, ptr %slot2569, align 8
  %v13908 = load i64, ptr %slot6, align 8
  %p13909 = inttoptr i64 %v13908 to ptr
  %ld13910 = load i32, ptr %p13909, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13910, ptr %slot2570, align 8
  %v13911 = load i32, ptr %slot2570, align 8
  %op13912 = and i32 %v13911, 28
  store i32 %op13912, ptr %slot2571, align 8
  %v13913 = load i32, ptr %slot2571, align 8
  %cv13914 = zext i32 %v13913 to i64
  %cond13915 = icmp ne i64 %cv13914, 0
  br i1 %cond13915, label %bb_rcslotrole3445, label %bb_rcslotowner3445
bb_rcslotrole3445:
  %v13916 = load i64, ptr %slot99, align 8
  store i64 %v13916, ptr %slot2572, align 8
  %v13917 = load i64, ptr %slot2572, align 8
  %v13918 = load i64, ptr %slot2569, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v13917, i64 %v13918) nomerge, !dbg !258
  br label %bb_rcslotdone3445
bb_rcslotowner3445:
  %v13919 = load i64, ptr %slot99, align 8
  store i64 %v13919, ptr %slot2573, align 8
  %v13920 = load i64, ptr %slot2573, align 8
  %v13921 = load i64, ptr %slot2569, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v13920, i64 %v13921) nomerge, !dbg !258
  br label %bb_rcslotdone3445
bb_rcslotdone3445:
  %v13922 = load i64, ptr %slot2490, align 8
  %p13923 = inttoptr i64 %v13922 to ptr
  %ret13924 = load { i64, i64 }, ptr %p13923, align 8
  ret { i64, i64 } %ret13924
bb_i181:
  %v13925 = load i64, ptr %slot15, align 8
  %p13926 = inttoptr i64 %v13925 to ptr
  %ld13927 = load i32, ptr %p13926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13927, ptr %slot2574, align 8
  %v13928 = load i32, ptr %slot2574, align 8
  %cv13929 = zext i32 %v13928 to i64
  %cond13930 = icmp ne i64 %cv13929, 0
  br i1 %cond13930, label %bb_rcslotdrop3463, label %bb_rcslotdone3463
bb_rcslotdrop3463:
  %v13931 = load i64, ptr %slot15, align 8
  %p13932 = inttoptr i64 %v13931 to ptr
  store i32 0, ptr %p13932, align 4, !alias.scope !3, !noalias !4
  %v13933 = load i64, ptr %slot24, align 8
  store i64 %v13933, ptr %slot2575, align 8
  %v13934 = load i64, ptr %slot16, align 8
  %p13935 = inttoptr i64 %v13934 to ptr
  %ld13936 = load i32, ptr %p13935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13936, ptr %slot2576, align 8
  %v13937 = load i32, ptr %slot2576, align 8
  %op13938 = and i32 %v13937, 28
  store i32 %op13938, ptr %slot2577, align 8
  %v13939 = load i32, ptr %slot2577, align 8
  %cv13940 = zext i32 %v13939 to i64
  %cond13941 = icmp ne i64 %cv13940, 0
  br i1 %cond13941, label %bb_rcslotrole3463, label %bb_rcslotowner3463
bb_rcslotrole3463:
  %v13942 = load i64, ptr %slot99, align 8
  store i64 %v13942, ptr %slot2578, align 8
  %v13943 = load i64, ptr %slot2578, align 8
  %v13944 = load i64, ptr %slot2575, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v13943, i64 %v13944) nomerge, !dbg !260
  br label %bb_rcslotdone3463
bb_rcslotowner3463:
  %v13945 = load i64, ptr %slot99, align 8
  store i64 %v13945, ptr %slot2579, align 8
  %v13946 = load i64, ptr %slot2579, align 8
  %v13947 = load i64, ptr %slot2575, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v13946, i64 %v13947) nomerge, !dbg !260
  br label %bb_rcslotdone3463
bb_rcslotdone3463:
  %v13948 = load i64, ptr %slot32, align 8
  %p13949 = inttoptr i64 %v13948 to ptr
  %ld13950 = load i64, ptr %p13949, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13950, ptr %slot2580, align 8
  %v13951 = load i64, ptr %slot2580, align 8
  %v13952 = load i64, ptr %slot44, align 8
  %p13953 = inttoptr i64 %v13952 to ptr
  store i64 %v13951, ptr %p13953, align 8, !alias.scope !3, !noalias !4
  %v13954 = load i64, ptr %slot43, align 8
  %p13955 = inttoptr i64 %v13954 to ptr
  %ld13956 = load i64, ptr %p13955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13956, ptr %slot2581, align 8
  %v13957 = load i64, ptr %slot2581, align 8
  %v13958 = load i64, ptr %slot45, align 8
  %p13959 = inttoptr i64 %v13958 to ptr
  store i64 %v13957, ptr %p13959, align 8, !alias.scope !3, !noalias !4
  %v13960 = load i64, ptr %slot89, align 8
  store i64 %v13960, ptr %slot2582, align 8
  %v13961 = load i64, ptr %slot100, align 8
  store i64 %v13961, ptr %slot2583, align 8
  %v13962 = load i64, ptr %slot45, align 8
  store i64 %v13962, ptr %slot2584, align 8
  %v13963 = load i64, ptr %slot2582, align 8
  %p13965 = inttoptr i64 %v13963 to ptr
  %gep13966 = getelementptr i8, ptr %p13965, i64 0
  %op13964 = ptrtoint ptr %gep13966 to i64
  store i64 %op13964, ptr %slot2585, align 8
  %v13967 = load i64, ptr %slot2584, align 8
  %p13968 = inttoptr i64 %v13967 to ptr
  %ld13969 = load i64, ptr %p13968, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13969, ptr %slot2586, align 8
  %v13970 = load i64, ptr %slot2586, align 8
  %v13971 = load i64, ptr %slot2585, align 8
  %p13972 = inttoptr i64 %v13971 to ptr
  store i64 %v13970, ptr %p13972, align 8, !alias.scope !3, !noalias !4
  %v13973 = load i64, ptr %slot2582, align 8
  %v13974 = load i64, ptr %slot45, align 8
  %p13975 = inttoptr i64 %v13974 to ptr
  store i64 %v13973, ptr %p13975, align 8, !alias.scope !3, !noalias !4
  %v13976 = load i64, ptr %slot90, align 8
  store i64 %v13976, ptr %slot2587, align 8
  %v13977 = load i64, ptr %slot2587, align 8
  %p13978 = inttoptr i64 %v13977 to ptr
  call void @llvm.memset.p0.i64(ptr %p13978, i8 0, i64 112, i1 false), !alias.scope !3, !noalias !4, !dbg !262
  %v13979 = load i64, ptr %slot2587, align 8
  %p13980 = inttoptr i64 %v13979 to ptr
  store i32 4, ptr %p13980, align 4, !alias.scope !3, !noalias !4
  %v13981 = load i64, ptr %slot23, align 8
  %p13982 = inttoptr i64 %v13981 to ptr
  store i32 1, ptr %p13982, align 4, !alias.scope !3, !noalias !4
  %v13983 = load i64, ptr %slot45, align 8
  %p13984 = inttoptr i64 %v13983 to ptr
  %ld13985 = load i64, ptr %p13984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13985, ptr %slot2588, align 8
  %v13986 = load i64, ptr %slot2587, align 8
  %p13988 = inttoptr i64 %v13986 to ptr
  %gep13989 = getelementptr i8, ptr %p13988, i64 8
  %op13987 = ptrtoint ptr %gep13989 to i64
  store i64 %op13987, ptr %slot2589, align 8
  %v13990 = load i64, ptr %slot100, align 8
  store i64 %v13990, ptr %slot2590, align 8
  %v13991 = load i64, ptr %slot2588, align 8
  %v13992 = load i64, ptr %slot2589, align 8
  %p13993 = inttoptr i64 %v13991 to ptr
  %p13994 = inttoptr i64 %v13992 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p13994, ptr %p13993, i64 8, i1 false)
  %v13995 = load i64, ptr %slot2587, align 8
  %v13996 = load i64, ptr %slot45, align 8
  %p13997 = inttoptr i64 %v13996 to ptr
  store i64 %v13995, ptr %p13997, align 8, !alias.scope !3, !noalias !4
  %v13998 = load i64, ptr %slot45, align 8
  %p13999 = inttoptr i64 %v13998 to ptr
  %ld14000 = load i64, ptr %p13999, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14000, ptr %slot2591, align 8
  %v14001 = load i64, ptr %slot25, align 8
  store i64 %v14001, ptr %slot2592, align 8
  %v14002 = load i64, ptr %slot2591, align 8
  %v14003 = load i64, ptr %slot2592, align 8
  %p14004 = inttoptr i64 %v14002 to ptr
  %p14005 = inttoptr i64 %v14003 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p14005, ptr %p14004, i64 112, i1 false)
  %v14006 = load i64, ptr %slot18, align 8
  %p14007 = inttoptr i64 %v14006 to ptr
  store i32 2, ptr %p14007, align 4, !alias.scope !3, !noalias !4
  %v14008 = load i64, ptr %slot17, align 8
  %p14009 = inttoptr i64 %v14008 to ptr
  store i32 1, ptr %p14009, align 4, !alias.scope !3, !noalias !4
  %v14010 = load i64, ptr %slot2592, align 8
  %v14011 = load i64, ptr %slot45, align 8
  %p14012 = inttoptr i64 %v14011 to ptr
  store i64 %v14010, ptr %p14012, align 8, !alias.scope !3, !noalias !4
  %v14013 = load i64, ptr %slot44, align 8
  %p14014 = inttoptr i64 %v14013 to ptr
  %ld14015 = load i64, ptr %p14014, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14015, ptr %slot2593, align 8
  %v14016 = load i64, ptr %slot45, align 8
  %p14017 = inttoptr i64 %v14016 to ptr
  %ld14018 = load i64, ptr %p14017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14018, ptr %slot2594, align 8
  %v14019 = load i64, ptr %slot1, align 8
  %v14020 = load i64, ptr %slot2593, align 8
  %v14021 = load i64, ptr %slot2594, align 8
  %call14022 = call i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64 %v14019, i64 %v14020, i64 %v14021) nomerge, !dbg !264
  store i64 %call14022, ptr %slot2595, align 8
  %v14023 = load i64, ptr %slot2595, align 8
  %v14024 = load i64, ptr %slot44, align 8
  %p14025 = inttoptr i64 %v14024 to ptr
  store i64 %v14023, ptr %p14025, align 8, !alias.scope !3, !noalias !4
  %v14026 = load i64, ptr %slot15, align 8
  %p14027 = inttoptr i64 %v14026 to ptr
  %ld14028 = load i32, ptr %p14027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14028, ptr %slot2596, align 8
  %v14029 = load i32, ptr %slot2596, align 8
  %cv14030 = zext i32 %v14029 to i64
  %cond14031 = icmp ne i64 %cv14030, 0
  br i1 %cond14031, label %bb_rcslotdrop3492, label %bb_rcslotdone3492
bb_rcslotdrop3492:
  %v14032 = load i64, ptr %slot15, align 8
  %p14033 = inttoptr i64 %v14032 to ptr
  store i32 0, ptr %p14033, align 4, !alias.scope !3, !noalias !4
  %v14034 = load i64, ptr %slot24, align 8
  store i64 %v14034, ptr %slot2597, align 8
  %v14035 = load i64, ptr %slot16, align 8
  %p14036 = inttoptr i64 %v14035 to ptr
  %ld14037 = load i32, ptr %p14036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14037, ptr %slot2598, align 8
  %v14038 = load i32, ptr %slot2598, align 8
  %op14039 = and i32 %v14038, 28
  store i32 %op14039, ptr %slot2599, align 8
  %v14040 = load i32, ptr %slot2599, align 8
  %cv14041 = zext i32 %v14040 to i64
  %cond14042 = icmp ne i64 %cv14041, 0
  br i1 %cond14042, label %bb_rcslotrole3492, label %bb_rcslotowner3492
bb_rcslotrole3492:
  %v14043 = load i64, ptr %slot99, align 8
  store i64 %v14043, ptr %slot2600, align 8
  %v14044 = load i64, ptr %slot2600, align 8
  %v14045 = load i64, ptr %slot2597, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v14044, i64 %v14045) nomerge, !dbg !264
  br label %bb_rcslotdone3492
bb_rcslotowner3492:
  %v14046 = load i64, ptr %slot99, align 8
  store i64 %v14046, ptr %slot2601, align 8
  %v14047 = load i64, ptr %slot2601, align 8
  %v14048 = load i64, ptr %slot2597, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v14047, i64 %v14048) nomerge, !dbg !264
  br label %bb_rcslotdone3492
bb_rcslotdone3492:
  %v14049 = load i64, ptr %slot17, align 8
  %p14050 = inttoptr i64 %v14049 to ptr
  %ld14051 = load i32, ptr %p14050, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14051, ptr %slot2602, align 8
  %v14052 = load i32, ptr %slot2602, align 8
  %cv14053 = zext i32 %v14052 to i64
  %cond14054 = icmp ne i64 %cv14053, 0
  br i1 %cond14054, label %bb_rcslotdrop3501, label %bb_rcslotdone3501
bb_rcslotdrop3501:
  %v14055 = load i64, ptr %slot17, align 8
  %p14056 = inttoptr i64 %v14055 to ptr
  store i32 0, ptr %p14056, align 4, !alias.scope !3, !noalias !4
  %v14057 = load i64, ptr %slot25, align 8
  store i64 %v14057, ptr %slot2603, align 8
  %v14058 = load i64, ptr %slot18, align 8
  %p14059 = inttoptr i64 %v14058 to ptr
  %ld14060 = load i32, ptr %p14059, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14060, ptr %slot2604, align 8
  %v14061 = load i32, ptr %slot2604, align 8
  %op14062 = and i32 %v14061, 28
  store i32 %op14062, ptr %slot2605, align 8
  %v14063 = load i32, ptr %slot2605, align 8
  %cv14064 = zext i32 %v14063 to i64
  %cond14065 = icmp ne i64 %cv14064, 0
  br i1 %cond14065, label %bb_rcslotrole3501, label %bb_rcslotowner3501
bb_rcslotrole3501:
  %v14066 = load i64, ptr %slot99, align 8
  store i64 %v14066, ptr %slot2606, align 8
  %v14067 = load i64, ptr %slot2606, align 8
  %v14068 = load i64, ptr %slot2603, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64 %v14067, i64 %v14068) nomerge, !dbg !264
  br label %bb_rcslotdone3501
bb_rcslotowner3501:
  %v14069 = load i64, ptr %slot99, align 8
  store i64 %v14069, ptr %slot2607, align 8
  %v14070 = load i64, ptr %slot2607, align 8
  %v14071 = load i64, ptr %slot2603, align 8
  call void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64 %v14070, i64 %v14071) nomerge, !dbg !264
  br label %bb_rcslotdone3501
bb_rcslotdone3501:
  %v14072 = load i64, ptr %slot91, align 8
  store i64 %v14072, ptr %slot2608, align 8
  %v14073 = load i64, ptr %slot2608, align 8
  %p14074 = inttoptr i64 %v14073 to ptr
  store i64 0, ptr %p14074, align 8, !alias.scope !3, !noalias !4
  %v14075 = load i64, ptr %slot2608, align 8
  %p14077 = inttoptr i64 %v14075 to ptr
  %gep14078 = getelementptr i8, ptr %p14077, i64 8
  %op14076 = ptrtoint ptr %gep14078 to i64
  store i64 %op14076, ptr %slot2609, align 8
  %v14079 = load i64, ptr %slot2609, align 8
  %p14080 = inttoptr i64 %v14079 to ptr
  store i64 0, ptr %p14080, align 8, !alias.scope !3, !noalias !4
  %v14081 = load i64, ptr %slot2608, align 8
  %p14082 = inttoptr i64 %v14081 to ptr
  store i32 0, ptr %p14082, align 4, !alias.scope !3, !noalias !4
  %v14083 = load i64, ptr %slot23, align 8
  %p14084 = inttoptr i64 %v14083 to ptr
  store i32 1, ptr %p14084, align 4, !alias.scope !3, !noalias !4
  %v14085 = load i64, ptr %slot44, align 8
  store i64 %v14085, ptr %slot2610, align 8
  %v14086 = load i64, ptr %slot2608, align 8
  %p14088 = inttoptr i64 %v14086 to ptr
  %gep14089 = getelementptr i8, ptr %p14088, i64 8
  %op14087 = ptrtoint ptr %gep14089 to i64
  store i64 %op14087, ptr %slot2611, align 8
  %v14090 = load i64, ptr %slot100, align 8
  store i64 %v14090, ptr %slot2612, align 8
  %v14091 = load i64, ptr %slot2610, align 8
  %p14092 = inttoptr i64 %v14091 to ptr
  %ld14093 = load i64, ptr %p14092, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14093, ptr %slot2613, align 8
  %v14094 = load i64, ptr %slot2613, align 8
  %v14095 = load i64, ptr %slot2611, align 8
  %p14096 = inttoptr i64 %v14095 to ptr
  store i64 %v14094, ptr %p14096, align 8, !alias.scope !3, !noalias !4
  %v14097 = load i64, ptr %slot2608, align 8
  %v14098 = load i64, ptr %slot44, align 8
  %p14099 = inttoptr i64 %v14098 to ptr
  store i64 %v14097, ptr %p14099, align 8, !alias.scope !3, !noalias !4
  %v14100 = load i64, ptr %slot44, align 8
  %p14101 = inttoptr i64 %v14100 to ptr
  %ld14102 = load i64, ptr %p14101, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14102, ptr %slot2614, align 8
  %v14103 = load i64, ptr %slot15, align 8
  %p14104 = inttoptr i64 %v14103 to ptr
  %ld14105 = load i32, ptr %p14104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14105, ptr %slot2615, align 8
  %v14106 = load i32, ptr %slot2615, align 8
  %cv14107 = zext i32 %v14106 to i64
  %cond14108 = icmp ne i64 %cv14107, 0
  br i1 %cond14108, label %bb_rcslotdrop3519, label %bb_rcslotdone3519
bb_rcslotdrop3519:
  %v14109 = load i64, ptr %slot15, align 8
  %p14110 = inttoptr i64 %v14109 to ptr
  store i32 0, ptr %p14110, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone3519
bb_rcslotdone3519:
  %v14111 = load i64, ptr %slot13, align 8
  %p14112 = inttoptr i64 %v14111 to ptr
  %ld14113 = load i32, ptr %p14112, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14113, ptr %slot2616, align 8
  %v14114 = load i32, ptr %slot2616, align 8
  %cv14115 = zext i32 %v14114 to i64
  %cond14116 = icmp ne i64 %cv14115, 0
  br i1 %cond14116, label %bb_rcslotdrop3522, label %bb_rcslotdone3522
bb_rcslotdrop3522:
  %v14117 = load i64, ptr %slot13, align 8
  %p14118 = inttoptr i64 %v14117 to ptr
  store i32 0, ptr %p14118, align 4, !alias.scope !3, !noalias !4
  %v14119 = load i64, ptr %slot42, align 8
  store i64 %v14119, ptr %slot2617, align 8
  %v14120 = load i64, ptr %slot14, align 8
  %p14121 = inttoptr i64 %v14120 to ptr
  %ld14122 = load i32, ptr %p14121, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14122, ptr %slot2618, align 8
  %v14123 = load i32, ptr %slot2618, align 8
  %op14124 = and i32 %v14123, 28
  store i32 %op14124, ptr %slot2619, align 8
  %v14125 = load i32, ptr %slot2619, align 8
  %cv14126 = zext i32 %v14125 to i64
  %cond14127 = icmp ne i64 %cv14126, 0
  br i1 %cond14127, label %bb_rcslotrole3522, label %bb_rcslotowner3522
bb_rcslotrole3522:
  %v14128 = load i64, ptr %slot99, align 8
  store i64 %v14128, ptr %slot2620, align 8
  %v14129 = load i64, ptr %slot2620, align 8
  %v14130 = load i64, ptr %slot2617, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v14129, i64 %v14130) nomerge, !dbg !266
  br label %bb_rcslotdone3522
bb_rcslotowner3522:
  %v14131 = load i64, ptr %slot99, align 8
  store i64 %v14131, ptr %slot2621, align 8
  %v14132 = load i64, ptr %slot2621, align 8
  %v14133 = load i64, ptr %slot2617, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v14132, i64 %v14133) nomerge, !dbg !266
  br label %bb_rcslotdone3522
bb_rcslotdone3522:
  %v14134 = load i64, ptr %slot11, align 8
  %p14135 = inttoptr i64 %v14134 to ptr
  %ld14136 = load i32, ptr %p14135, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14136, ptr %slot2622, align 8
  %v14137 = load i32, ptr %slot2622, align 8
  %cv14138 = zext i32 %v14137 to i64
  %cond14139 = icmp ne i64 %cv14138, 0
  br i1 %cond14139, label %bb_rcslotdrop3531, label %bb_rcslotdone3531
bb_rcslotdrop3531:
  %v14140 = load i64, ptr %slot11, align 8
  %p14141 = inttoptr i64 %v14140 to ptr
  store i32 0, ptr %p14141, align 4, !alias.scope !3, !noalias !4
  %v14142 = load i64, ptr %slot41, align 8
  store i64 %v14142, ptr %slot2623, align 8
  %v14143 = load i64, ptr %slot12, align 8
  %p14144 = inttoptr i64 %v14143 to ptr
  %ld14145 = load i32, ptr %p14144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14145, ptr %slot2624, align 8
  %v14146 = load i32, ptr %slot2624, align 8
  %op14147 = and i32 %v14146, 28
  store i32 %op14147, ptr %slot2625, align 8
  %v14148 = load i32, ptr %slot2625, align 8
  %cv14149 = zext i32 %v14148 to i64
  %cond14150 = icmp ne i64 %cv14149, 0
  br i1 %cond14150, label %bb_rcslotrole3531, label %bb_rcslotowner3531
bb_rcslotrole3531:
  %v14151 = load i64, ptr %slot99, align 8
  store i64 %v14151, ptr %slot2626, align 8
  %v14152 = load i64, ptr %slot2626, align 8
  %v14153 = load i64, ptr %slot2623, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v14152, i64 %v14153) nomerge, !dbg !266
  br label %bb_rcslotdone3531
bb_rcslotowner3531:
  %v14154 = load i64, ptr %slot99, align 8
  store i64 %v14154, ptr %slot2627, align 8
  %v14155 = load i64, ptr %slot2627, align 8
  %v14156 = load i64, ptr %slot2623, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v14155, i64 %v14156) nomerge, !dbg !266
  br label %bb_rcslotdone3531
bb_rcslotdone3531:
  %v14157 = load i64, ptr %slot9, align 8
  %p14158 = inttoptr i64 %v14157 to ptr
  %ld14159 = load i32, ptr %p14158, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14159, ptr %slot2628, align 8
  %v14160 = load i32, ptr %slot2628, align 8
  %cv14161 = zext i32 %v14160 to i64
  %cond14162 = icmp ne i64 %cv14161, 0
  br i1 %cond14162, label %bb_rcslotdrop3540, label %bb_rcslotdone3540
bb_rcslotdrop3540:
  %v14163 = load i64, ptr %slot9, align 8
  %p14164 = inttoptr i64 %v14163 to ptr
  store i32 0, ptr %p14164, align 4, !alias.scope !3, !noalias !4
  %v14165 = load i64, ptr %slot39, align 8
  store i64 %v14165, ptr %slot2629, align 8
  %v14166 = load i64, ptr %slot10, align 8
  %p14167 = inttoptr i64 %v14166 to ptr
  %ld14168 = load i32, ptr %p14167, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14168, ptr %slot2630, align 8
  %v14169 = load i32, ptr %slot2630, align 8
  %op14170 = and i32 %v14169, 28
  store i32 %op14170, ptr %slot2631, align 8
  %v14171 = load i32, ptr %slot2631, align 8
  %cv14172 = zext i32 %v14171 to i64
  %cond14173 = icmp ne i64 %cv14172, 0
  br i1 %cond14173, label %bb_rcslotrole3540, label %bb_rcslotowner3540
bb_rcslotrole3540:
  %v14174 = load i64, ptr %slot99, align 8
  store i64 %v14174, ptr %slot2632, align 8
  %v14175 = load i64, ptr %slot2629, align 8
  %p14176 = inttoptr i64 %v14175 to ptr
  %ld14177 = load i64, ptr %p14176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14177, ptr %slot2633, align 8
  %v14178 = load i64, ptr %slot2633, align 8
  %cmp14179 = icmp ne i64 %v14178, 0
  %cv14180 = zext i1 %cmp14179 to i32
  store i32 %cv14180, ptr %slot2634, align 8
  %v14181 = load i32, ptr %slot2634, align 8
  %cv14182 = zext i32 %v14181 to i64
  %cond14183 = icmp ne i64 %cv14182, 0
  br i1 %cond14183, label %bb_rcgnn3556, label %bb_rcgdone3556
bb_rcgnn3556:
  %v14184 = load i64, ptr %slot2633, align 8
  %op14185 = sub i64 %v14184, 16
  store i64 %op14185, ptr %slot2635, align 8
  %v14186 = load i64, ptr %slot2633, align 8
  %p14187 = inttoptr i64 %v14186 to ptr
  %rgep14188 = getelementptr i8, ptr %p14187, i64 -16
  %ld14189 = load i64, ptr %rgep14188, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14189, ptr %slot2636, align 8
  %v14190 = load i64, ptr %slot2636, align 8
  %op14191 = and i64 %v14190, 4611686018427387906
  store i64 %op14191, ptr %slot2637, align 8
  %v14192 = load i64, ptr %slot2637, align 8
  %cmp14193 = icmp ne i64 %v14192, 0
  %cv14194 = zext i1 %cmp14193 to i32
  store i32 %cv14194, ptr %slot2638, align 8
  %v14195 = load i32, ptr %slot2638, align 8
  %cv14196 = zext i32 %v14195 to i64
  %cond14197 = icmp ne i64 %cv14196, 0
  br i1 %cond14197, label %bb_rcgclear3556, label %bb_rcgcounted3556
bb_rcgcounted3556:
  %v14198 = load i64, ptr %slot2633, align 8
  %op14199 = sub i64 %v14198, 24
  store i64 %op14199, ptr %slot2639, align 8
  %v14200 = load i64, ptr %slot2633, align 8
  %p14201 = inttoptr i64 %v14200 to ptr
  %rgep14202 = getelementptr i8, ptr %p14201, i64 -24
  %ld14203 = load i64, ptr %rgep14202, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14203, ptr %slot2640, align 8
  %v14204 = load i64, ptr %slot2640, align 8
  %op14205 = sub i64 %v14204, 1
  store i64 %op14205, ptr %slot2641, align 8
  %v14206 = load i64, ptr %slot2641, align 8
  %cmp14207 = icmp eq i64 %v14206, 0
  %cv14208 = zext i1 %cmp14207 to i32
  store i32 %cv14208, ptr %slot2642, align 8
  %v14209 = load i32, ptr %slot2642, align 8
  %cv14210 = zext i32 %v14209 to i64
  %cond14211 = icmp ne i64 %cv14210, 0
  br i1 %cond14211, label %bb_rcglast3556, label %bb_rcgdec3556
bb_rcglast3556:
  %v14212 = load i64, ptr %slot2633, align 8
  %op14213 = sub i64 %v14212, 32
  store i64 %op14213, ptr %slot2643, align 8
  %v14214 = load i64, ptr %slot2633, align 8
  %p14215 = inttoptr i64 %v14214 to ptr
  %rgep14216 = getelementptr i8, ptr %p14215, i64 -32
  %ld14217 = load i64, ptr %rgep14216, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14217, ptr %slot2644, align 8
  %v14218 = load i64, ptr %slot2644, align 8
  %cmp14219 = icmp ne i64 %v14218, 0
  %cv14220 = zext i1 %cmp14219 to i32
  store i32 %cv14220, ptr %slot2645, align 8
  %v14221 = load i32, ptr %slot2645, align 8
  %cv14222 = zext i32 %v14221 to i64
  %cond14223 = icmp ne i64 %cv14222, 0
  br i1 %cond14223, label %bb_rcgdec3556, label %bb_rcgslow3556
bb_rcgslow3556:
  %v14224 = load i64, ptr %slot2632, align 8
  %v14225 = load i64, ptr %slot2629, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v14224, i64 %v14225) nomerge, !dbg !266
  br label %bb_rcgdone3556
bb_rcgdec3556:
  %v14226 = load i64, ptr %slot2641, align 8
  %v14227 = load i64, ptr %slot2633, align 8
  %p14228 = inttoptr i64 %v14227 to ptr
  %rgep14229 = getelementptr i8, ptr %p14228, i64 -24
  store i64 %v14226, ptr %rgep14229, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3556
bb_rcgclear3556:
  %v14230 = load i64, ptr %slot2629, align 8
  %p14231 = inttoptr i64 %v14230 to ptr
  store i64 0, ptr %p14231, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3556
bb_rcgdone3556:
  br label %bb_rcslotdone3540
bb_rcslotowner3540:
  %v14232 = load i64, ptr %slot99, align 8
  store i64 %v14232, ptr %slot2646, align 8
  %v14233 = load i64, ptr %slot2629, align 8
  %p14234 = inttoptr i64 %v14233 to ptr
  %ld14235 = load i64, ptr %p14234, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14235, ptr %slot2647, align 8
  %v14236 = load i64, ptr %slot2647, align 8
  %cmp14237 = icmp ne i64 %v14236, 0
  %cv14238 = zext i1 %cmp14237 to i32
  store i32 %cv14238, ptr %slot2648, align 8
  %v14239 = load i32, ptr %slot2648, align 8
  %cv14240 = zext i32 %v14239 to i64
  %cond14241 = icmp ne i64 %cv14240, 0
  br i1 %cond14241, label %bb_rcgnn3571, label %bb_rcgdone3571
bb_rcgnn3571:
  %v14242 = load i64, ptr %slot2647, align 8
  %op14243 = sub i64 %v14242, 16
  store i64 %op14243, ptr %slot2649, align 8
  %v14244 = load i64, ptr %slot2647, align 8
  %p14245 = inttoptr i64 %v14244 to ptr
  %rgep14246 = getelementptr i8, ptr %p14245, i64 -16
  %ld14247 = load i64, ptr %rgep14246, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14247, ptr %slot2650, align 8
  %v14248 = load i64, ptr %slot2650, align 8
  %op14249 = and i64 %v14248, 4611686018427387906
  store i64 %op14249, ptr %slot2651, align 8
  %v14250 = load i64, ptr %slot2651, align 8
  %cmp14251 = icmp ne i64 %v14250, 0
  %cv14252 = zext i1 %cmp14251 to i32
  store i32 %cv14252, ptr %slot2652, align 8
  %v14253 = load i32, ptr %slot2652, align 8
  %cv14254 = zext i32 %v14253 to i64
  %cond14255 = icmp ne i64 %cv14254, 0
  br i1 %cond14255, label %bb_rcgclear3571, label %bb_rcgcounted3571
bb_rcgcounted3571:
  %v14256 = load i64, ptr %slot2647, align 8
  %op14257 = sub i64 %v14256, 32
  store i64 %op14257, ptr %slot2653, align 8
  %v14258 = load i64, ptr %slot2647, align 8
  %p14259 = inttoptr i64 %v14258 to ptr
  %rgep14260 = getelementptr i8, ptr %p14259, i64 -32
  %ld14261 = load i64, ptr %rgep14260, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14261, ptr %slot2654, align 8
  %v14262 = load i64, ptr %slot2654, align 8
  %op14263 = sub i64 %v14262, 1
  store i64 %op14263, ptr %slot2655, align 8
  %v14264 = load i64, ptr %slot2655, align 8
  %cmp14265 = icmp eq i64 %v14264, 0
  %cv14266 = zext i1 %cmp14265 to i32
  store i32 %cv14266, ptr %slot2656, align 8
  %v14267 = load i32, ptr %slot2656, align 8
  %cv14268 = zext i32 %v14267 to i64
  %cond14269 = icmp ne i64 %cv14268, 0
  br i1 %cond14269, label %bb_rcglast3571, label %bb_rcgdec3571
bb_rcglast3571:
  %v14270 = load i64, ptr %slot2647, align 8
  %op14271 = sub i64 %v14270, 24
  store i64 %op14271, ptr %slot2657, align 8
  %v14272 = load i64, ptr %slot2647, align 8
  %p14273 = inttoptr i64 %v14272 to ptr
  %rgep14274 = getelementptr i8, ptr %p14273, i64 -24
  %ld14275 = load i64, ptr %rgep14274, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14275, ptr %slot2658, align 8
  %v14276 = load i64, ptr %slot2658, align 8
  %cmp14277 = icmp ne i64 %v14276, 0
  %cv14278 = zext i1 %cmp14277 to i32
  store i32 %cv14278, ptr %slot2659, align 8
  %v14279 = load i32, ptr %slot2659, align 8
  %cv14280 = zext i32 %v14279 to i64
  %cond14281 = icmp ne i64 %cv14280, 0
  br i1 %cond14281, label %bb_rcgdec3571, label %bb_rcgslow3571
bb_rcgslow3571:
  %v14282 = load i64, ptr %slot2646, align 8
  %v14283 = load i64, ptr %slot2629, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v14282, i64 %v14283) nomerge, !dbg !266
  br label %bb_rcgdone3571
bb_rcgdec3571:
  %v14284 = load i64, ptr %slot2655, align 8
  %v14285 = load i64, ptr %slot2647, align 8
  %p14286 = inttoptr i64 %v14285 to ptr
  %rgep14287 = getelementptr i8, ptr %p14286, i64 -32
  store i64 %v14284, ptr %rgep14287, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3571
bb_rcgclear3571:
  %v14288 = load i64, ptr %slot2629, align 8
  %p14289 = inttoptr i64 %v14288 to ptr
  store i64 0, ptr %p14289, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3571
bb_rcgdone3571:
  br label %bb_rcslotdone3540
bb_rcslotdone3540:
  %v14290 = load i64, ptr %slot7, align 8
  %p14291 = inttoptr i64 %v14290 to ptr
  %ld14292 = load i32, ptr %p14291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14292, ptr %slot2660, align 8
  %v14293 = load i32, ptr %slot2660, align 8
  %cv14294 = zext i32 %v14293 to i64
  %cond14295 = icmp ne i64 %cv14294, 0
  br i1 %cond14295, label %bb_rcslotdrop3577, label %bb_rcslotdone3577
bb_rcslotdrop3577:
  %v14296 = load i64, ptr %slot7, align 8
  %p14297 = inttoptr i64 %v14296 to ptr
  store i32 0, ptr %p14297, align 4, !alias.scope !3, !noalias !4
  %v14298 = load i64, ptr %slot34, align 8
  store i64 %v14298, ptr %slot2661, align 8
  %v14299 = load i64, ptr %slot8, align 8
  %p14300 = inttoptr i64 %v14299 to ptr
  %ld14301 = load i32, ptr %p14300, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14301, ptr %slot2662, align 8
  %v14302 = load i32, ptr %slot2662, align 8
  %op14303 = and i32 %v14302, 28
  store i32 %op14303, ptr %slot2663, align 8
  %v14304 = load i32, ptr %slot2663, align 8
  %cv14305 = zext i32 %v14304 to i64
  %cond14306 = icmp ne i64 %cv14305, 0
  br i1 %cond14306, label %bb_rcslotrole3577, label %bb_rcslotowner3577
bb_rcslotrole3577:
  %v14307 = load i64, ptr %slot99, align 8
  store i64 %v14307, ptr %slot2664, align 8
  %v14308 = load i64, ptr %slot2661, align 8
  %p14309 = inttoptr i64 %v14308 to ptr
  %ld14310 = load i64, ptr %p14309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14310, ptr %slot2665, align 8
  %v14311 = load i64, ptr %slot2665, align 8
  %cmp14312 = icmp ne i64 %v14311, 0
  %cv14313 = zext i1 %cmp14312 to i32
  store i32 %cv14313, ptr %slot2666, align 8
  %v14314 = load i32, ptr %slot2666, align 8
  %cv14315 = zext i32 %v14314 to i64
  %cond14316 = icmp ne i64 %cv14315, 0
  br i1 %cond14316, label %bb_rcgnn3593, label %bb_rcgdone3593
bb_rcgnn3593:
  %v14317 = load i64, ptr %slot2665, align 8
  %op14318 = sub i64 %v14317, 16
  store i64 %op14318, ptr %slot2667, align 8
  %v14319 = load i64, ptr %slot2665, align 8
  %p14320 = inttoptr i64 %v14319 to ptr
  %rgep14321 = getelementptr i8, ptr %p14320, i64 -16
  %ld14322 = load i64, ptr %rgep14321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14322, ptr %slot2668, align 8
  %v14323 = load i64, ptr %slot2668, align 8
  %op14324 = and i64 %v14323, 4611686018427387906
  store i64 %op14324, ptr %slot2669, align 8
  %v14325 = load i64, ptr %slot2669, align 8
  %cmp14326 = icmp ne i64 %v14325, 0
  %cv14327 = zext i1 %cmp14326 to i32
  store i32 %cv14327, ptr %slot2670, align 8
  %v14328 = load i32, ptr %slot2670, align 8
  %cv14329 = zext i32 %v14328 to i64
  %cond14330 = icmp ne i64 %cv14329, 0
  br i1 %cond14330, label %bb_rcgclear3593, label %bb_rcgcounted3593
bb_rcgcounted3593:
  %v14331 = load i64, ptr %slot2665, align 8
  %op14332 = sub i64 %v14331, 24
  store i64 %op14332, ptr %slot2671, align 8
  %v14333 = load i64, ptr %slot2665, align 8
  %p14334 = inttoptr i64 %v14333 to ptr
  %rgep14335 = getelementptr i8, ptr %p14334, i64 -24
  %ld14336 = load i64, ptr %rgep14335, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14336, ptr %slot2672, align 8
  %v14337 = load i64, ptr %slot2672, align 8
  %op14338 = sub i64 %v14337, 1
  store i64 %op14338, ptr %slot2673, align 8
  %v14339 = load i64, ptr %slot2673, align 8
  %cmp14340 = icmp eq i64 %v14339, 0
  %cv14341 = zext i1 %cmp14340 to i32
  store i32 %cv14341, ptr %slot2674, align 8
  %v14342 = load i32, ptr %slot2674, align 8
  %cv14343 = zext i32 %v14342 to i64
  %cond14344 = icmp ne i64 %cv14343, 0
  br i1 %cond14344, label %bb_rcglast3593, label %bb_rcgdec3593
bb_rcglast3593:
  %v14345 = load i64, ptr %slot2665, align 8
  %op14346 = sub i64 %v14345, 32
  store i64 %op14346, ptr %slot2675, align 8
  %v14347 = load i64, ptr %slot2665, align 8
  %p14348 = inttoptr i64 %v14347 to ptr
  %rgep14349 = getelementptr i8, ptr %p14348, i64 -32
  %ld14350 = load i64, ptr %rgep14349, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14350, ptr %slot2676, align 8
  %v14351 = load i64, ptr %slot2676, align 8
  %cmp14352 = icmp ne i64 %v14351, 0
  %cv14353 = zext i1 %cmp14352 to i32
  store i32 %cv14353, ptr %slot2677, align 8
  %v14354 = load i32, ptr %slot2677, align 8
  %cv14355 = zext i32 %v14354 to i64
  %cond14356 = icmp ne i64 %cv14355, 0
  br i1 %cond14356, label %bb_rcgdec3593, label %bb_rcgslow3593
bb_rcgslow3593:
  %v14357 = load i64, ptr %slot2664, align 8
  %v14358 = load i64, ptr %slot2661, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v14357, i64 %v14358) nomerge, !dbg !266
  br label %bb_rcgdone3593
bb_rcgdec3593:
  %v14359 = load i64, ptr %slot2673, align 8
  %v14360 = load i64, ptr %slot2665, align 8
  %p14361 = inttoptr i64 %v14360 to ptr
  %rgep14362 = getelementptr i8, ptr %p14361, i64 -24
  store i64 %v14359, ptr %rgep14362, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3593
bb_rcgclear3593:
  %v14363 = load i64, ptr %slot2661, align 8
  %p14364 = inttoptr i64 %v14363 to ptr
  store i64 0, ptr %p14364, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3593
bb_rcgdone3593:
  br label %bb_rcslotdone3577
bb_rcslotowner3577:
  %v14365 = load i64, ptr %slot99, align 8
  store i64 %v14365, ptr %slot2678, align 8
  %v14366 = load i64, ptr %slot2661, align 8
  %p14367 = inttoptr i64 %v14366 to ptr
  %ld14368 = load i64, ptr %p14367, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14368, ptr %slot2679, align 8
  %v14369 = load i64, ptr %slot2679, align 8
  %cmp14370 = icmp ne i64 %v14369, 0
  %cv14371 = zext i1 %cmp14370 to i32
  store i32 %cv14371, ptr %slot2680, align 8
  %v14372 = load i32, ptr %slot2680, align 8
  %cv14373 = zext i32 %v14372 to i64
  %cond14374 = icmp ne i64 %cv14373, 0
  br i1 %cond14374, label %bb_rcgnn3608, label %bb_rcgdone3608
bb_rcgnn3608:
  %v14375 = load i64, ptr %slot2679, align 8
  %op14376 = sub i64 %v14375, 16
  store i64 %op14376, ptr %slot2681, align 8
  %v14377 = load i64, ptr %slot2679, align 8
  %p14378 = inttoptr i64 %v14377 to ptr
  %rgep14379 = getelementptr i8, ptr %p14378, i64 -16
  %ld14380 = load i64, ptr %rgep14379, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14380, ptr %slot2682, align 8
  %v14381 = load i64, ptr %slot2682, align 8
  %op14382 = and i64 %v14381, 4611686018427387906
  store i64 %op14382, ptr %slot2683, align 8
  %v14383 = load i64, ptr %slot2683, align 8
  %cmp14384 = icmp ne i64 %v14383, 0
  %cv14385 = zext i1 %cmp14384 to i32
  store i32 %cv14385, ptr %slot2684, align 8
  %v14386 = load i32, ptr %slot2684, align 8
  %cv14387 = zext i32 %v14386 to i64
  %cond14388 = icmp ne i64 %cv14387, 0
  br i1 %cond14388, label %bb_rcgclear3608, label %bb_rcgcounted3608
bb_rcgcounted3608:
  %v14389 = load i64, ptr %slot2679, align 8
  %op14390 = sub i64 %v14389, 32
  store i64 %op14390, ptr %slot2685, align 8
  %v14391 = load i64, ptr %slot2679, align 8
  %p14392 = inttoptr i64 %v14391 to ptr
  %rgep14393 = getelementptr i8, ptr %p14392, i64 -32
  %ld14394 = load i64, ptr %rgep14393, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14394, ptr %slot2686, align 8
  %v14395 = load i64, ptr %slot2686, align 8
  %op14396 = sub i64 %v14395, 1
  store i64 %op14396, ptr %slot2687, align 8
  %v14397 = load i64, ptr %slot2687, align 8
  %cmp14398 = icmp eq i64 %v14397, 0
  %cv14399 = zext i1 %cmp14398 to i32
  store i32 %cv14399, ptr %slot2688, align 8
  %v14400 = load i32, ptr %slot2688, align 8
  %cv14401 = zext i32 %v14400 to i64
  %cond14402 = icmp ne i64 %cv14401, 0
  br i1 %cond14402, label %bb_rcglast3608, label %bb_rcgdec3608
bb_rcglast3608:
  %v14403 = load i64, ptr %slot2679, align 8
  %op14404 = sub i64 %v14403, 24
  store i64 %op14404, ptr %slot2689, align 8
  %v14405 = load i64, ptr %slot2679, align 8
  %p14406 = inttoptr i64 %v14405 to ptr
  %rgep14407 = getelementptr i8, ptr %p14406, i64 -24
  %ld14408 = load i64, ptr %rgep14407, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14408, ptr %slot2690, align 8
  %v14409 = load i64, ptr %slot2690, align 8
  %cmp14410 = icmp ne i64 %v14409, 0
  %cv14411 = zext i1 %cmp14410 to i32
  store i32 %cv14411, ptr %slot2691, align 8
  %v14412 = load i32, ptr %slot2691, align 8
  %cv14413 = zext i32 %v14412 to i64
  %cond14414 = icmp ne i64 %cv14413, 0
  br i1 %cond14414, label %bb_rcgdec3608, label %bb_rcgslow3608
bb_rcgslow3608:
  %v14415 = load i64, ptr %slot2678, align 8
  %v14416 = load i64, ptr %slot2661, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v14415, i64 %v14416) nomerge, !dbg !266
  br label %bb_rcgdone3608
bb_rcgdec3608:
  %v14417 = load i64, ptr %slot2687, align 8
  %v14418 = load i64, ptr %slot2679, align 8
  %p14419 = inttoptr i64 %v14418 to ptr
  %rgep14420 = getelementptr i8, ptr %p14419, i64 -32
  store i64 %v14417, ptr %rgep14420, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3608
bb_rcgclear3608:
  %v14421 = load i64, ptr %slot2661, align 8
  %p14422 = inttoptr i64 %v14421 to ptr
  store i64 0, ptr %p14422, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3608
bb_rcgdone3608:
  br label %bb_rcslotdone3577
bb_rcslotdone3577:
  %v14423 = load i64, ptr %slot5, align 8
  %p14424 = inttoptr i64 %v14423 to ptr
  %ld14425 = load i32, ptr %p14424, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14425, ptr %slot2692, align 8
  %v14426 = load i32, ptr %slot2692, align 8
  %cv14427 = zext i32 %v14426 to i64
  %cond14428 = icmp ne i64 %cv14427, 0
  br i1 %cond14428, label %bb_rcslotdrop3614, label %bb_rcslotdone3614
bb_rcslotdrop3614:
  %v14429 = load i64, ptr %slot5, align 8
  %p14430 = inttoptr i64 %v14429 to ptr
  store i32 0, ptr %p14430, align 4, !alias.scope !3, !noalias !4
  %v14431 = load i64, ptr %slot33, align 8
  store i64 %v14431, ptr %slot2693, align 8
  %v14432 = load i64, ptr %slot6, align 8
  %p14433 = inttoptr i64 %v14432 to ptr
  %ld14434 = load i32, ptr %p14433, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14434, ptr %slot2694, align 8
  %v14435 = load i32, ptr %slot2694, align 8
  %op14436 = and i32 %v14435, 28
  store i32 %op14436, ptr %slot2695, align 8
  %v14437 = load i32, ptr %slot2695, align 8
  %cv14438 = zext i32 %v14437 to i64
  %cond14439 = icmp ne i64 %cv14438, 0
  br i1 %cond14439, label %bb_rcslotrole3614, label %bb_rcslotowner3614
bb_rcslotrole3614:
  %v14440 = load i64, ptr %slot99, align 8
  store i64 %v14440, ptr %slot2696, align 8
  %v14441 = load i64, ptr %slot2696, align 8
  %v14442 = load i64, ptr %slot2693, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v14441, i64 %v14442) nomerge, !dbg !266
  br label %bb_rcslotdone3614
bb_rcslotowner3614:
  %v14443 = load i64, ptr %slot99, align 8
  store i64 %v14443, ptr %slot2697, align 8
  %v14444 = load i64, ptr %slot2697, align 8
  %v14445 = load i64, ptr %slot2693, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v14444, i64 %v14445) nomerge, !dbg !266
  br label %bb_rcslotdone3614
bb_rcslotdone3614:
  %v14446 = load i64, ptr %slot2614, align 8
  %p14447 = inttoptr i64 %v14446 to ptr
  %ret14448 = load { i64, i64 }, ptr %p14447, align 8
  ret { i64, i64 } %ret14448
bb_i189:
  %v14449 = load i64, ptr %slot32, align 8
  %p14450 = inttoptr i64 %v14449 to ptr
  %ld14451 = load i64, ptr %p14450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14451, ptr %slot2698, align 8
  %v14452 = load i64, ptr %slot2698, align 8
  %v14453 = load i64, ptr %slot44, align 8
  %p14454 = inttoptr i64 %v14453 to ptr
  store i64 %v14452, ptr %p14454, align 8, !alias.scope !3, !noalias !4
  %v14455 = load i64, ptr %slot32, align 8
  %p14456 = inttoptr i64 %v14455 to ptr
  %ld14457 = load i64, ptr %p14456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14457, ptr %slot2699, align 8
  %v14458 = load i64, ptr %slot2699, align 8
  %v14459 = load i64, ptr %slot92, align 8
  %p14460 = inttoptr i64 %v14458 to ptr
  %p14461 = inttoptr i64 %v14459 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p14461, ptr %p14460, i64 312, i1 false), !alias.scope !10000000
  %v14462 = load i64, ptr %slot92, align 8
  %v14463 = load i64, ptr %slot45, align 8
  %p14464 = inttoptr i64 %v14463 to ptr
  store i64 %v14462, ptr %p14464, align 8, !alias.scope !3, !noalias !4
  %v14465 = load i64, ptr %slot45, align 8
  %p14466 = inttoptr i64 %v14465 to ptr
  %ld14467 = load i64, ptr %p14466, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14467, ptr %slot2700, align 8
  %v14468 = load i64, ptr %slot1, align 8
  %v14469 = load i64, ptr %slot2700, align 8
  call void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8 %callresult2702, i64 %v14468, i64 %v14469) nomerge, !dbg !268
  %addr14470 = ptrtoint ptr %callresult2702 to i64
  store i64 %addr14470, ptr %slot2701, align 8
  %v14471 = load i64, ptr %slot2701, align 8
  %v14472 = load i64, ptr %slot45, align 8
  %p14473 = inttoptr i64 %v14472 to ptr
  store i64 %v14471, ptr %p14473, align 8, !alias.scope !3, !noalias !4
  %v14474 = load i64, ptr %slot45, align 8
  %p14475 = inttoptr i64 %v14474 to ptr
  %ld14476 = load i64, ptr %p14475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14476, ptr %slot2703, align 8
  %v14477 = load i64, ptr %slot30, align 8
  store i64 %v14477, ptr %slot2704, align 8
  %v14478 = load i64, ptr %slot99, align 8
  %v14479 = load i64, ptr %slot2704, align 8
  %v14480 = load i64, ptr %slot2703, align 8
  %call14481 = call i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64 %v14478, i64 %v14479, i64 %v14480) nomerge, !dbg !268
  store i32 %call14481, ptr %slot2705, align 8
  %v14482 = load i32, ptr %slot2705, align 8
  %cv14483 = zext i32 %v14482 to i64
  %cond14484 = icmp ne i64 %cv14483, 0
  br i1 %cond14484, label %bb_rcsuccess3637, label %bb_rcfailure3637
bb_rcfailure3637:
  %v14485 = load i64, ptr %slot99, align 8
  %p14486 = inttoptr i64 %v14485 to ptr
  %call14487 = call i32 @myl_rc_take_failure(ptr %p14486) nomerge, !dbg !268
  store i32 %call14487, ptr %slot2706, align 8
  %v14488 = load i64, ptr %slot1, align 8
  %p14489 = inttoptr i64 %v14488 to ptr
  %v14490 = load i32, ptr %slot2706, align 8
  %call14491 = call i32 @myl_qbe_rc_status(ptr %p14489, i32 %v14490) nomerge, !dbg !268
  store i32 %call14491, ptr %slot2707, align 8
  br label %bb_failure
bb_rcsuccess3637:
  %v14492 = load i64, ptr %slot22, align 8
  %p14493 = inttoptr i64 %v14492 to ptr
  store i32 2, ptr %p14493, align 4, !alias.scope !3, !noalias !4
  %v14494 = load i64, ptr %slot22, align 8
  %p14495 = inttoptr i64 %v14494 to ptr
  store i32 16, ptr %p14495, align 4, !alias.scope !3, !noalias !4
  %v14496 = load i64, ptr %slot21, align 8
  %p14497 = inttoptr i64 %v14496 to ptr
  store i32 1, ptr %p14497, align 4, !alias.scope !3, !noalias !4
  %v14498 = load i64, ptr %slot17, align 8
  %p14499 = inttoptr i64 %v14498 to ptr
  %ld14500 = load i32, ptr %p14499, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14500, ptr %slot2708, align 8
  %v14501 = load i32, ptr %slot2708, align 8
  %cv14502 = zext i32 %v14501 to i64
  %cond14503 = icmp ne i64 %cv14502, 0
  br i1 %cond14503, label %bb_rcslotdrop3645, label %bb_rcslotdone3645
bb_rcslotdrop3645:
  %v14504 = load i64, ptr %slot17, align 8
  %p14505 = inttoptr i64 %v14504 to ptr
  store i32 0, ptr %p14505, align 4, !alias.scope !3, !noalias !4
  %v14506 = load i64, ptr %slot25, align 8
  store i64 %v14506, ptr %slot2709, align 8
  %v14507 = load i64, ptr %slot18, align 8
  %p14508 = inttoptr i64 %v14507 to ptr
  %ld14509 = load i32, ptr %p14508, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14509, ptr %slot2710, align 8
  %v14510 = load i32, ptr %slot2710, align 8
  %op14511 = and i32 %v14510, 28
  store i32 %op14511, ptr %slot2711, align 8
  %v14512 = load i32, ptr %slot2711, align 8
  %cv14513 = zext i32 %v14512 to i64
  %cond14514 = icmp ne i64 %cv14513, 0
  br i1 %cond14514, label %bb_rcslotrole3645, label %bb_rcslotowner3645
bb_rcslotrole3645:
  %v14515 = load i64, ptr %slot99, align 8
  store i64 %v14515, ptr %slot2712, align 8
  %v14516 = load i64, ptr %slot2712, align 8
  %v14517 = load i64, ptr %slot2709, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v14516, i64 %v14517) nomerge, !dbg !268
  br label %bb_rcslotdone3645
bb_rcslotowner3645:
  %v14518 = load i64, ptr %slot99, align 8
  store i64 %v14518, ptr %slot2713, align 8
  %v14519 = load i64, ptr %slot2713, align 8
  %v14520 = load i64, ptr %slot2709, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v14519, i64 %v14520) nomerge, !dbg !268
  br label %bb_rcslotdone3645
bb_rcslotdone3645:
  %v14521 = load i64, ptr %slot25, align 8
  store i64 %v14521, ptr %slot2714, align 8
  %v14522 = load i64, ptr %slot30, align 8
  store i64 %v14522, ptr %slot2715, align 8
  %v14523 = load i64, ptr %slot2715, align 8
  %v14524 = load i64, ptr %slot2714, align 8
  %p14525 = inttoptr i64 %v14523 to ptr
  %p14526 = inttoptr i64 %v14524 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p14526, ptr %p14525, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v14527 = load i64, ptr %slot18, align 8
  %p14528 = inttoptr i64 %v14527 to ptr
  store i32 2, ptr %p14528, align 4, !alias.scope !3, !noalias !4
  %v14529 = load i64, ptr %slot22, align 8
  %p14530 = inttoptr i64 %v14529 to ptr
  %ld14531 = load i32, ptr %p14530, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14531, ptr %slot2716, align 8
  %v14532 = load i32, ptr %slot2716, align 8
  %v14533 = load i64, ptr %slot18, align 8
  %p14534 = inttoptr i64 %v14533 to ptr
  store i32 %v14532, ptr %p14534, align 4, !alias.scope !3, !noalias !4
  %v14535 = load i64, ptr %slot21, align 8
  %p14536 = inttoptr i64 %v14535 to ptr
  store i32 0, ptr %p14536, align 4, !alias.scope !3, !noalias !4
  %v14537 = load i64, ptr %slot17, align 8
  %p14538 = inttoptr i64 %v14537 to ptr
  store i32 1, ptr %p14538, align 4, !alias.scope !3, !noalias !4
  %v14539 = load i64, ptr %slot2714, align 8
  %v14540 = load i64, ptr %slot45, align 8
  %p14541 = inttoptr i64 %v14540 to ptr
  store i64 %v14539, ptr %p14541, align 8, !alias.scope !3, !noalias !4
  %p14542 = inttoptr i64 ptrtoint (ptr @myl_lit_d768da1261b328d49d84dd2a5d0143673c4885882d455d18227005ca42aecda4 to i64) to ptr
  %ld14543 = load i64, ptr %p14542, align 8, !alias.scope !4, !noalias !3
  store i64 %ld14543, ptr %slot2717, align 8
  %v14544 = load i64, ptr %slot2717, align 8
  %v14545 = load i64, ptr %slot46, align 8
  %p14546 = inttoptr i64 %v14545 to ptr
  store i64 %v14544, ptr %p14546, align 8, !alias.scope !3, !noalias !4
  %v14547 = load i64, ptr %slot46, align 8
  %p14548 = inttoptr i64 %v14547 to ptr
  %ld14549 = load i64, ptr %p14548, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14549, ptr %slot2718, align 8
  %v14550 = load i64, ptr %slot2718, align 8
  %v14551 = load i64, ptr %slot29, align 8
  %p14552 = inttoptr i64 %v14551 to ptr
  store i64 %v14550, ptr %p14552, align 8, !alias.scope !3, !noalias !4
  %v14553 = load i64, ptr %slot29, align 8
  store i64 %v14553, ptr %slot2719, align 8
  %v14554 = load i64, ptr %slot30, align 8
  store i64 %v14554, ptr %slot2720, align 8
  %v14555 = load i64, ptr %slot2719, align 8
  %v14556 = load i64, ptr %slot2720, align 8
  %p14557 = inttoptr i64 %v14555 to ptr
  %p14558 = inttoptr i64 %v14556 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p14558, ptr %p14557, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v14559 = load i64, ptr %slot22, align 8
  %p14560 = inttoptr i64 %v14559 to ptr
  store i32 2, ptr %p14560, align 4, !alias.scope !3, !noalias !4
  %v14561 = load i64, ptr %slot21, align 8
  %p14562 = inttoptr i64 %v14561 to ptr
  store i32 1, ptr %p14562, align 4, !alias.scope !3, !noalias !4
  %v14563 = load i64, ptr %slot26, align 8
  store i64 %v14563, ptr %slot2721, align 8
  %v14564 = load i64, ptr %slot30, align 8
  store i64 %v14564, ptr %slot2722, align 8
  %v14565 = load i64, ptr %slot2722, align 8
  %v14566 = load i64, ptr %slot2721, align 8
  %p14567 = inttoptr i64 %v14565 to ptr
  %p14568 = inttoptr i64 %v14566 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p14568, ptr %p14567, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v14569 = load i64, ptr %slot20, align 8
  %p14570 = inttoptr i64 %v14569 to ptr
  store i32 2, ptr %p14570, align 4, !alias.scope !3, !noalias !4
  %v14571 = load i64, ptr %slot22, align 8
  %p14572 = inttoptr i64 %v14571 to ptr
  %ld14573 = load i32, ptr %p14572, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14573, ptr %slot2723, align 8
  %v14574 = load i32, ptr %slot2723, align 8
  %v14575 = load i64, ptr %slot20, align 8
  %p14576 = inttoptr i64 %v14575 to ptr
  store i32 %v14574, ptr %p14576, align 4, !alias.scope !3, !noalias !4
  %v14577 = load i64, ptr %slot21, align 8
  %p14578 = inttoptr i64 %v14577 to ptr
  store i32 0, ptr %p14578, align 4, !alias.scope !3, !noalias !4
  %v14579 = load i64, ptr %slot19, align 8
  %p14580 = inttoptr i64 %v14579 to ptr
  store i32 1, ptr %p14580, align 4, !alias.scope !3, !noalias !4
  %v14581 = load i64, ptr %slot2721, align 8
  %p14582 = inttoptr i64 %v14581 to ptr
  %ld14583 = load i64, ptr %p14582, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14583, ptr %slot2724, align 8
  %v14584 = load i64, ptr %slot2724, align 8
  %v14585 = load i64, ptr %slot46, align 8
  %p14586 = inttoptr i64 %v14585 to ptr
  store i64 %v14584, ptr %p14586, align 8, !alias.scope !3, !noalias !4
  %v14587 = load i64, ptr %slot44, align 8
  %p14588 = inttoptr i64 %v14587 to ptr
  %ld14589 = load i64, ptr %p14588, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14589, ptr %slot2725, align 8
  %v14590 = load i64, ptr %slot45, align 8
  %p14591 = inttoptr i64 %v14590 to ptr
  %ld14592 = load i64, ptr %p14591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14592, ptr %slot2726, align 8
  %v14593 = load i64, ptr %slot46, align 8
  %p14594 = inttoptr i64 %v14593 to ptr
  %ld14595 = load i64, ptr %p14594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14595, ptr %slot2727, align 8
  %v14596 = load i64, ptr %slot1, align 8
  %v14597 = load i64, ptr %slot2725, align 8
  %v14598 = load i64, ptr %slot2726, align 8
  %v14599 = load i64, ptr %slot2727, align 8
  %call14600 = call i8 @myl_f_7a515a62bcf2d52dbd1a003508cbad18b835f8a05891010b6b797b5f49fa312f(i64 %v14596, i64 %v14597, i64 %v14598, i64 %v14599) nomerge, !dbg !270
  store i8 %call14600, ptr %callresult2729, align 1
  %addr14601 = ptrtoint ptr %callresult2729 to i64
  store i64 %addr14601, ptr %slot2728, align 8
  %v14602 = load i64, ptr %slot2728, align 8
  %v14603 = load i64, ptr %slot44, align 8
  %p14604 = inttoptr i64 %v14603 to ptr
  store i64 %v14602, ptr %p14604, align 8, !alias.scope !3, !noalias !4
  %v14605 = load i64, ptr %slot15, align 8
  %p14606 = inttoptr i64 %v14605 to ptr
  %ld14607 = load i32, ptr %p14606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14607, ptr %slot2730, align 8
  %v14608 = load i32, ptr %slot2730, align 8
  %cv14609 = zext i32 %v14608 to i64
  %cond14610 = icmp ne i64 %cv14609, 0
  br i1 %cond14610, label %bb_rcslotdrop3682, label %bb_rcslotdone3682
bb_rcslotdrop3682:
  %v14611 = load i64, ptr %slot15, align 8
  %p14612 = inttoptr i64 %v14611 to ptr
  store i32 0, ptr %p14612, align 4, !alias.scope !3, !noalias !4
  %v14613 = load i64, ptr %slot24, align 8
  store i64 %v14613, ptr %slot2731, align 8
  %v14614 = load i64, ptr %slot16, align 8
  %p14615 = inttoptr i64 %v14614 to ptr
  %ld14616 = load i32, ptr %p14615, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14616, ptr %slot2732, align 8
  %v14617 = load i32, ptr %slot2732, align 8
  %op14618 = and i32 %v14617, 28
  store i32 %op14618, ptr %slot2733, align 8
  %v14619 = load i32, ptr %slot2733, align 8
  %cv14620 = zext i32 %v14619 to i64
  %cond14621 = icmp ne i64 %cv14620, 0
  br i1 %cond14621, label %bb_rcslotrole3682, label %bb_rcslotowner3682
bb_rcslotrole3682:
  %v14622 = load i64, ptr %slot99, align 8
  store i64 %v14622, ptr %slot2734, align 8
  %v14623 = load i64, ptr %slot2734, align 8
  %v14624 = load i64, ptr %slot2731, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v14623, i64 %v14624) nomerge, !dbg !270
  br label %bb_rcslotdone3682
bb_rcslotowner3682:
  %v14625 = load i64, ptr %slot99, align 8
  store i64 %v14625, ptr %slot2735, align 8
  %v14626 = load i64, ptr %slot2735, align 8
  %v14627 = load i64, ptr %slot2731, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v14626, i64 %v14627) nomerge, !dbg !270
  br label %bb_rcslotdone3682
bb_rcslotdone3682:
  %v14628 = load i64, ptr %slot17, align 8
  %p14629 = inttoptr i64 %v14628 to ptr
  %ld14630 = load i32, ptr %p14629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14630, ptr %slot2736, align 8
  %v14631 = load i32, ptr %slot2736, align 8
  %cv14632 = zext i32 %v14631 to i64
  %cond14633 = icmp ne i64 %cv14632, 0
  br i1 %cond14633, label %bb_rcslotdrop3691, label %bb_rcslotdone3691
bb_rcslotdrop3691:
  %v14634 = load i64, ptr %slot17, align 8
  %p14635 = inttoptr i64 %v14634 to ptr
  store i32 0, ptr %p14635, align 4, !alias.scope !3, !noalias !4
  %v14636 = load i64, ptr %slot25, align 8
  store i64 %v14636, ptr %slot2737, align 8
  %v14637 = load i64, ptr %slot18, align 8
  %p14638 = inttoptr i64 %v14637 to ptr
  %ld14639 = load i32, ptr %p14638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14639, ptr %slot2738, align 8
  %v14640 = load i32, ptr %slot2738, align 8
  %op14641 = and i32 %v14640, 28
  store i32 %op14641, ptr %slot2739, align 8
  %v14642 = load i32, ptr %slot2739, align 8
  %cv14643 = zext i32 %v14642 to i64
  %cond14644 = icmp ne i64 %cv14643, 0
  br i1 %cond14644, label %bb_rcslotrole3691, label %bb_rcslotowner3691
bb_rcslotrole3691:
  %v14645 = load i64, ptr %slot99, align 8
  store i64 %v14645, ptr %slot2740, align 8
  %v14646 = load i64, ptr %slot2740, align 8
  %v14647 = load i64, ptr %slot2737, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v14646, i64 %v14647) nomerge, !dbg !270
  br label %bb_rcslotdone3691
bb_rcslotowner3691:
  %v14648 = load i64, ptr %slot99, align 8
  store i64 %v14648, ptr %slot2741, align 8
  %v14649 = load i64, ptr %slot2741, align 8
  %v14650 = load i64, ptr %slot2737, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v14649, i64 %v14650) nomerge, !dbg !270
  br label %bb_rcslotdone3691
bb_rcslotdone3691:
  %v14651 = load i64, ptr %slot19, align 8
  %p14652 = inttoptr i64 %v14651 to ptr
  %ld14653 = load i32, ptr %p14652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14653, ptr %slot2742, align 8
  %v14654 = load i32, ptr %slot2742, align 8
  %cv14655 = zext i32 %v14654 to i64
  %cond14656 = icmp ne i64 %cv14655, 0
  br i1 %cond14656, label %bb_rcslotdrop3700, label %bb_rcslotdone3700
bb_rcslotdrop3700:
  %v14657 = load i64, ptr %slot19, align 8
  %p14658 = inttoptr i64 %v14657 to ptr
  store i32 0, ptr %p14658, align 4, !alias.scope !3, !noalias !4
  %v14659 = load i64, ptr %slot26, align 8
  store i64 %v14659, ptr %slot2743, align 8
  %v14660 = load i64, ptr %slot20, align 8
  %p14661 = inttoptr i64 %v14660 to ptr
  %ld14662 = load i32, ptr %p14661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14662, ptr %slot2744, align 8
  %v14663 = load i32, ptr %slot2744, align 8
  %op14664 = and i32 %v14663, 28
  store i32 %op14664, ptr %slot2745, align 8
  %v14665 = load i32, ptr %slot2745, align 8
  %cv14666 = zext i32 %v14665 to i64
  %cond14667 = icmp ne i64 %cv14666, 0
  br i1 %cond14667, label %bb_rcslotrole3700, label %bb_rcslotowner3700
bb_rcslotrole3700:
  %v14668 = load i64, ptr %slot99, align 8
  store i64 %v14668, ptr %slot2746, align 8
  %v14669 = load i64, ptr %slot2743, align 8
  %p14670 = inttoptr i64 %v14669 to ptr
  %ld14671 = load i64, ptr %p14670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14671, ptr %slot2747, align 8
  %v14672 = load i64, ptr %slot2747, align 8
  %cmp14673 = icmp ne i64 %v14672, 0
  %cv14674 = zext i1 %cmp14673 to i32
  store i32 %cv14674, ptr %slot2748, align 8
  %v14675 = load i32, ptr %slot2748, align 8
  %cv14676 = zext i32 %v14675 to i64
  %cond14677 = icmp ne i64 %cv14676, 0
  br i1 %cond14677, label %bb_rcgnn3716, label %bb_rcgdone3716
bb_rcgnn3716:
  %v14678 = load i64, ptr %slot2747, align 8
  %op14679 = sub i64 %v14678, 16
  store i64 %op14679, ptr %slot2749, align 8
  %v14680 = load i64, ptr %slot2747, align 8
  %p14681 = inttoptr i64 %v14680 to ptr
  %rgep14682 = getelementptr i8, ptr %p14681, i64 -16
  %ld14683 = load i64, ptr %rgep14682, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14683, ptr %slot2750, align 8
  %v14684 = load i64, ptr %slot2750, align 8
  %op14685 = and i64 %v14684, 4611686018427387906
  store i64 %op14685, ptr %slot2751, align 8
  %v14686 = load i64, ptr %slot2751, align 8
  %cmp14687 = icmp ne i64 %v14686, 0
  %cv14688 = zext i1 %cmp14687 to i32
  store i32 %cv14688, ptr %slot2752, align 8
  %v14689 = load i32, ptr %slot2752, align 8
  %cv14690 = zext i32 %v14689 to i64
  %cond14691 = icmp ne i64 %cv14690, 0
  br i1 %cond14691, label %bb_rcgclear3716, label %bb_rcgcounted3716
bb_rcgcounted3716:
  %v14692 = load i64, ptr %slot2747, align 8
  %op14693 = sub i64 %v14692, 24
  store i64 %op14693, ptr %slot2753, align 8
  %v14694 = load i64, ptr %slot2747, align 8
  %p14695 = inttoptr i64 %v14694 to ptr
  %rgep14696 = getelementptr i8, ptr %p14695, i64 -24
  %ld14697 = load i64, ptr %rgep14696, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14697, ptr %slot2754, align 8
  %v14698 = load i64, ptr %slot2754, align 8
  %op14699 = sub i64 %v14698, 1
  store i64 %op14699, ptr %slot2755, align 8
  %v14700 = load i64, ptr %slot2755, align 8
  %cmp14701 = icmp eq i64 %v14700, 0
  %cv14702 = zext i1 %cmp14701 to i32
  store i32 %cv14702, ptr %slot2756, align 8
  %v14703 = load i32, ptr %slot2756, align 8
  %cv14704 = zext i32 %v14703 to i64
  %cond14705 = icmp ne i64 %cv14704, 0
  br i1 %cond14705, label %bb_rcglast3716, label %bb_rcgdec3716
bb_rcglast3716:
  %v14706 = load i64, ptr %slot2747, align 8
  %op14707 = sub i64 %v14706, 32
  store i64 %op14707, ptr %slot2757, align 8
  %v14708 = load i64, ptr %slot2747, align 8
  %p14709 = inttoptr i64 %v14708 to ptr
  %rgep14710 = getelementptr i8, ptr %p14709, i64 -32
  %ld14711 = load i64, ptr %rgep14710, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14711, ptr %slot2758, align 8
  %v14712 = load i64, ptr %slot2758, align 8
  %cmp14713 = icmp ne i64 %v14712, 0
  %cv14714 = zext i1 %cmp14713 to i32
  store i32 %cv14714, ptr %slot2759, align 8
  %v14715 = load i32, ptr %slot2759, align 8
  %cv14716 = zext i32 %v14715 to i64
  %cond14717 = icmp ne i64 %cv14716, 0
  br i1 %cond14717, label %bb_rcgdec3716, label %bb_rcgslow3716
bb_rcgslow3716:
  %v14718 = load i64, ptr %slot2746, align 8
  %v14719 = load i64, ptr %slot2743, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v14718, i64 %v14719) nomerge, !dbg !270
  br label %bb_rcgdone3716
bb_rcgdec3716:
  %v14720 = load i64, ptr %slot2755, align 8
  %v14721 = load i64, ptr %slot2747, align 8
  %p14722 = inttoptr i64 %v14721 to ptr
  %rgep14723 = getelementptr i8, ptr %p14722, i64 -24
  store i64 %v14720, ptr %rgep14723, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3716
bb_rcgclear3716:
  %v14724 = load i64, ptr %slot2743, align 8
  %p14725 = inttoptr i64 %v14724 to ptr
  store i64 0, ptr %p14725, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3716
bb_rcgdone3716:
  br label %bb_rcslotdone3700
bb_rcslotowner3700:
  %v14726 = load i64, ptr %slot99, align 8
  store i64 %v14726, ptr %slot2760, align 8
  %v14727 = load i64, ptr %slot2743, align 8
  %p14728 = inttoptr i64 %v14727 to ptr
  %ld14729 = load i64, ptr %p14728, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14729, ptr %slot2761, align 8
  %v14730 = load i64, ptr %slot2761, align 8
  %cmp14731 = icmp ne i64 %v14730, 0
  %cv14732 = zext i1 %cmp14731 to i32
  store i32 %cv14732, ptr %slot2762, align 8
  %v14733 = load i32, ptr %slot2762, align 8
  %cv14734 = zext i32 %v14733 to i64
  %cond14735 = icmp ne i64 %cv14734, 0
  br i1 %cond14735, label %bb_rcgnn3731, label %bb_rcgdone3731
bb_rcgnn3731:
  %v14736 = load i64, ptr %slot2761, align 8
  %op14737 = sub i64 %v14736, 16
  store i64 %op14737, ptr %slot2763, align 8
  %v14738 = load i64, ptr %slot2761, align 8
  %p14739 = inttoptr i64 %v14738 to ptr
  %rgep14740 = getelementptr i8, ptr %p14739, i64 -16
  %ld14741 = load i64, ptr %rgep14740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14741, ptr %slot2764, align 8
  %v14742 = load i64, ptr %slot2764, align 8
  %op14743 = and i64 %v14742, 4611686018427387906
  store i64 %op14743, ptr %slot2765, align 8
  %v14744 = load i64, ptr %slot2765, align 8
  %cmp14745 = icmp ne i64 %v14744, 0
  %cv14746 = zext i1 %cmp14745 to i32
  store i32 %cv14746, ptr %slot2766, align 8
  %v14747 = load i32, ptr %slot2766, align 8
  %cv14748 = zext i32 %v14747 to i64
  %cond14749 = icmp ne i64 %cv14748, 0
  br i1 %cond14749, label %bb_rcgclear3731, label %bb_rcgcounted3731
bb_rcgcounted3731:
  %v14750 = load i64, ptr %slot2761, align 8
  %op14751 = sub i64 %v14750, 32
  store i64 %op14751, ptr %slot2767, align 8
  %v14752 = load i64, ptr %slot2761, align 8
  %p14753 = inttoptr i64 %v14752 to ptr
  %rgep14754 = getelementptr i8, ptr %p14753, i64 -32
  %ld14755 = load i64, ptr %rgep14754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14755, ptr %slot2768, align 8
  %v14756 = load i64, ptr %slot2768, align 8
  %op14757 = sub i64 %v14756, 1
  store i64 %op14757, ptr %slot2769, align 8
  %v14758 = load i64, ptr %slot2769, align 8
  %cmp14759 = icmp eq i64 %v14758, 0
  %cv14760 = zext i1 %cmp14759 to i32
  store i32 %cv14760, ptr %slot2770, align 8
  %v14761 = load i32, ptr %slot2770, align 8
  %cv14762 = zext i32 %v14761 to i64
  %cond14763 = icmp ne i64 %cv14762, 0
  br i1 %cond14763, label %bb_rcglast3731, label %bb_rcgdec3731
bb_rcglast3731:
  %v14764 = load i64, ptr %slot2761, align 8
  %op14765 = sub i64 %v14764, 24
  store i64 %op14765, ptr %slot2771, align 8
  %v14766 = load i64, ptr %slot2761, align 8
  %p14767 = inttoptr i64 %v14766 to ptr
  %rgep14768 = getelementptr i8, ptr %p14767, i64 -24
  %ld14769 = load i64, ptr %rgep14768, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14769, ptr %slot2772, align 8
  %v14770 = load i64, ptr %slot2772, align 8
  %cmp14771 = icmp ne i64 %v14770, 0
  %cv14772 = zext i1 %cmp14771 to i32
  store i32 %cv14772, ptr %slot2773, align 8
  %v14773 = load i32, ptr %slot2773, align 8
  %cv14774 = zext i32 %v14773 to i64
  %cond14775 = icmp ne i64 %cv14774, 0
  br i1 %cond14775, label %bb_rcgdec3731, label %bb_rcgslow3731
bb_rcgslow3731:
  %v14776 = load i64, ptr %slot2760, align 8
  %v14777 = load i64, ptr %slot2743, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v14776, i64 %v14777) nomerge, !dbg !270
  br label %bb_rcgdone3731
bb_rcgdec3731:
  %v14778 = load i64, ptr %slot2769, align 8
  %v14779 = load i64, ptr %slot2761, align 8
  %p14780 = inttoptr i64 %v14779 to ptr
  %rgep14781 = getelementptr i8, ptr %p14780, i64 -32
  store i64 %v14778, ptr %rgep14781, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3731
bb_rcgclear3731:
  %v14782 = load i64, ptr %slot2743, align 8
  %p14783 = inttoptr i64 %v14782 to ptr
  store i64 0, ptr %p14783, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3731
bb_rcgdone3731:
  br label %bb_rcslotdone3700
bb_rcslotdone3700:
  %v14784 = load i64, ptr %slot98, align 8
  store i64 %v14784, ptr %slot2774, align 8
  %v14785 = load i64, ptr %slot2774, align 8
  %p14786 = inttoptr i64 %v14785 to ptr
  store i64 0, ptr %p14786, align 8, !alias.scope !3, !noalias !4
  %v14787 = load i64, ptr %slot2774, align 8
  %p14789 = inttoptr i64 %v14787 to ptr
  %gep14790 = getelementptr i8, ptr %p14789, i64 8
  %op14788 = ptrtoint ptr %gep14790 to i64
  store i64 %op14788, ptr %slot2775, align 8
  %v14791 = load i64, ptr %slot2775, align 8
  %p14792 = inttoptr i64 %v14791 to ptr
  store i64 0, ptr %p14792, align 8, !alias.scope !3, !noalias !4
  %v14793 = load i64, ptr %slot2774, align 8
  %p14794 = inttoptr i64 %v14793 to ptr
  store i32 1, ptr %p14794, align 4, !alias.scope !3, !noalias !4
  %v14795 = load i64, ptr %slot23, align 8
  %p14796 = inttoptr i64 %v14795 to ptr
  store i32 1, ptr %p14796, align 4, !alias.scope !3, !noalias !4
  %v14797 = load i64, ptr %slot44, align 8
  %p14798 = inttoptr i64 %v14797 to ptr
  %ld14799 = load i64, ptr %p14798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14799, ptr %slot2776, align 8
  %v14800 = load i64, ptr %slot2774, align 8
  %p14802 = inttoptr i64 %v14800 to ptr
  %gep14803 = getelementptr i8, ptr %p14802, i64 8
  %op14801 = ptrtoint ptr %gep14803 to i64
  store i64 %op14801, ptr %slot2777, align 8
  %v14804 = load i64, ptr %slot100, align 8
  store i64 %v14804, ptr %slot2778, align 8
  %v14805 = load i64, ptr %slot2774, align 8
  %v14806 = load i64, ptr %slot44, align 8
  %p14807 = inttoptr i64 %v14806 to ptr
  store i64 %v14805, ptr %p14807, align 8, !alias.scope !3, !noalias !4
  %p14808 = inttoptr i64 ptrtoint (ptr @myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p14808, i64 194) "call-inline-cost"="0", !dbg !272
  %v14809 = load i64, ptr %slot44, align 8
  %p14810 = inttoptr i64 %v14809 to ptr
  %ld14811 = load i64, ptr %p14810, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14811, ptr %slot2779, align 8
  %v14812 = load i64, ptr %slot15, align 8
  %p14813 = inttoptr i64 %v14812 to ptr
  %ld14814 = load i32, ptr %p14813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14814, ptr %slot2780, align 8
  %v14815 = load i32, ptr %slot2780, align 8
  %cv14816 = zext i32 %v14815 to i64
  %cond14817 = icmp ne i64 %cv14816, 0
  br i1 %cond14817, label %bb_rcslotdrop3745, label %bb_rcslotdone3745
bb_rcslotdrop3745:
  %v14818 = load i64, ptr %slot15, align 8
  %p14819 = inttoptr i64 %v14818 to ptr
  store i32 0, ptr %p14819, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone3745
bb_rcslotdone3745:
  %v14820 = load i64, ptr %slot13, align 8
  %p14821 = inttoptr i64 %v14820 to ptr
  %ld14822 = load i32, ptr %p14821, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14822, ptr %slot2781, align 8
  %v14823 = load i32, ptr %slot2781, align 8
  %cv14824 = zext i32 %v14823 to i64
  %cond14825 = icmp ne i64 %cv14824, 0
  br i1 %cond14825, label %bb_rcslotdrop3748, label %bb_rcslotdone3748
bb_rcslotdrop3748:
  %v14826 = load i64, ptr %slot13, align 8
  %p14827 = inttoptr i64 %v14826 to ptr
  store i32 0, ptr %p14827, align 4, !alias.scope !3, !noalias !4
  %v14828 = load i64, ptr %slot42, align 8
  store i64 %v14828, ptr %slot2782, align 8
  %v14829 = load i64, ptr %slot14, align 8
  %p14830 = inttoptr i64 %v14829 to ptr
  %ld14831 = load i32, ptr %p14830, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14831, ptr %slot2783, align 8
  %v14832 = load i32, ptr %slot2783, align 8
  %op14833 = and i32 %v14832, 28
  store i32 %op14833, ptr %slot2784, align 8
  %v14834 = load i32, ptr %slot2784, align 8
  %cv14835 = zext i32 %v14834 to i64
  %cond14836 = icmp ne i64 %cv14835, 0
  br i1 %cond14836, label %bb_rcslotrole3748, label %bb_rcslotowner3748
bb_rcslotrole3748:
  %v14837 = load i64, ptr %slot99, align 8
  store i64 %v14837, ptr %slot2785, align 8
  %v14838 = load i64, ptr %slot2785, align 8
  %v14839 = load i64, ptr %slot2782, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v14838, i64 %v14839) nomerge, !dbg !274
  br label %bb_rcslotdone3748
bb_rcslotowner3748:
  %v14840 = load i64, ptr %slot99, align 8
  store i64 %v14840, ptr %slot2786, align 8
  %v14841 = load i64, ptr %slot2786, align 8
  %v14842 = load i64, ptr %slot2782, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v14841, i64 %v14842) nomerge, !dbg !274
  br label %bb_rcslotdone3748
bb_rcslotdone3748:
  %v14843 = load i64, ptr %slot11, align 8
  %p14844 = inttoptr i64 %v14843 to ptr
  %ld14845 = load i32, ptr %p14844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14845, ptr %slot2787, align 8
  %v14846 = load i32, ptr %slot2787, align 8
  %cv14847 = zext i32 %v14846 to i64
  %cond14848 = icmp ne i64 %cv14847, 0
  br i1 %cond14848, label %bb_rcslotdrop3757, label %bb_rcslotdone3757
bb_rcslotdrop3757:
  %v14849 = load i64, ptr %slot11, align 8
  %p14850 = inttoptr i64 %v14849 to ptr
  store i32 0, ptr %p14850, align 4, !alias.scope !3, !noalias !4
  %v14851 = load i64, ptr %slot41, align 8
  store i64 %v14851, ptr %slot2788, align 8
  %v14852 = load i64, ptr %slot12, align 8
  %p14853 = inttoptr i64 %v14852 to ptr
  %ld14854 = load i32, ptr %p14853, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14854, ptr %slot2789, align 8
  %v14855 = load i32, ptr %slot2789, align 8
  %op14856 = and i32 %v14855, 28
  store i32 %op14856, ptr %slot2790, align 8
  %v14857 = load i32, ptr %slot2790, align 8
  %cv14858 = zext i32 %v14857 to i64
  %cond14859 = icmp ne i64 %cv14858, 0
  br i1 %cond14859, label %bb_rcslotrole3757, label %bb_rcslotowner3757
bb_rcslotrole3757:
  %v14860 = load i64, ptr %slot99, align 8
  store i64 %v14860, ptr %slot2791, align 8
  %v14861 = load i64, ptr %slot2791, align 8
  %v14862 = load i64, ptr %slot2788, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v14861, i64 %v14862) nomerge, !dbg !274
  br label %bb_rcslotdone3757
bb_rcslotowner3757:
  %v14863 = load i64, ptr %slot99, align 8
  store i64 %v14863, ptr %slot2792, align 8
  %v14864 = load i64, ptr %slot2792, align 8
  %v14865 = load i64, ptr %slot2788, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v14864, i64 %v14865) nomerge, !dbg !274
  br label %bb_rcslotdone3757
bb_rcslotdone3757:
  %v14866 = load i64, ptr %slot9, align 8
  %p14867 = inttoptr i64 %v14866 to ptr
  %ld14868 = load i32, ptr %p14867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14868, ptr %slot2793, align 8
  %v14869 = load i32, ptr %slot2793, align 8
  %cv14870 = zext i32 %v14869 to i64
  %cond14871 = icmp ne i64 %cv14870, 0
  br i1 %cond14871, label %bb_rcslotdrop3766, label %bb_rcslotdone3766
bb_rcslotdrop3766:
  %v14872 = load i64, ptr %slot9, align 8
  %p14873 = inttoptr i64 %v14872 to ptr
  store i32 0, ptr %p14873, align 4, !alias.scope !3, !noalias !4
  %v14874 = load i64, ptr %slot39, align 8
  store i64 %v14874, ptr %slot2794, align 8
  %v14875 = load i64, ptr %slot10, align 8
  %p14876 = inttoptr i64 %v14875 to ptr
  %ld14877 = load i32, ptr %p14876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld14877, ptr %slot2795, align 8
  %v14878 = load i32, ptr %slot2795, align 8
  %op14879 = and i32 %v14878, 28
  store i32 %op14879, ptr %slot2796, align 8
  %v14880 = load i32, ptr %slot2796, align 8
  %cv14881 = zext i32 %v14880 to i64
  %cond14882 = icmp ne i64 %cv14881, 0
  br i1 %cond14882, label %bb_rcslotrole3766, label %bb_rcslotowner3766
bb_rcslotrole3766:
  %v14883 = load i64, ptr %slot99, align 8
  store i64 %v14883, ptr %slot2797, align 8
  %v14884 = load i64, ptr %slot2794, align 8
  %p14885 = inttoptr i64 %v14884 to ptr
  %ld14886 = load i64, ptr %p14885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14886, ptr %slot2798, align 8
  %v14887 = load i64, ptr %slot2798, align 8
  %cmp14888 = icmp ne i64 %v14887, 0
  %cv14889 = zext i1 %cmp14888 to i32
  store i32 %cv14889, ptr %slot2799, align 8
  %v14890 = load i32, ptr %slot2799, align 8
  %cv14891 = zext i32 %v14890 to i64
  %cond14892 = icmp ne i64 %cv14891, 0
  br i1 %cond14892, label %bb_rcgnn3782, label %bb_rcgdone3782
bb_rcgnn3782:
  %v14893 = load i64, ptr %slot2798, align 8
  %op14894 = sub i64 %v14893, 16
  store i64 %op14894, ptr %slot2800, align 8
  %v14895 = load i64, ptr %slot2798, align 8
  %p14896 = inttoptr i64 %v14895 to ptr
  %rgep14897 = getelementptr i8, ptr %p14896, i64 -16
  %ld14898 = load i64, ptr %rgep14897, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14898, ptr %slot2801, align 8
  %v14899 = load i64, ptr %slot2801, align 8
  %op14900 = and i64 %v14899, 4611686018427387906
  store i64 %op14900, ptr %slot2802, align 8
  %v14901 = load i64, ptr %slot2802, align 8
  %cmp14902 = icmp ne i64 %v14901, 0
  %cv14903 = zext i1 %cmp14902 to i32
  store i32 %cv14903, ptr %slot2803, align 8
  %v14904 = load i32, ptr %slot2803, align 8
  %cv14905 = zext i32 %v14904 to i64
  %cond14906 = icmp ne i64 %cv14905, 0
  br i1 %cond14906, label %bb_rcgclear3782, label %bb_rcgcounted3782
bb_rcgcounted3782:
  %v14907 = load i64, ptr %slot2798, align 8
  %op14908 = sub i64 %v14907, 24
  store i64 %op14908, ptr %slot2804, align 8
  %v14909 = load i64, ptr %slot2798, align 8
  %p14910 = inttoptr i64 %v14909 to ptr
  %rgep14911 = getelementptr i8, ptr %p14910, i64 -24
  %ld14912 = load i64, ptr %rgep14911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14912, ptr %slot2805, align 8
  %v14913 = load i64, ptr %slot2805, align 8
  %op14914 = sub i64 %v14913, 1
  store i64 %op14914, ptr %slot2806, align 8
  %v14915 = load i64, ptr %slot2806, align 8
  %cmp14916 = icmp eq i64 %v14915, 0
  %cv14917 = zext i1 %cmp14916 to i32
  store i32 %cv14917, ptr %slot2807, align 8
  %v14918 = load i32, ptr %slot2807, align 8
  %cv14919 = zext i32 %v14918 to i64
  %cond14920 = icmp ne i64 %cv14919, 0
  br i1 %cond14920, label %bb_rcglast3782, label %bb_rcgdec3782
bb_rcglast3782:
  %v14921 = load i64, ptr %slot2798, align 8
  %op14922 = sub i64 %v14921, 32
  store i64 %op14922, ptr %slot2808, align 8
  %v14923 = load i64, ptr %slot2798, align 8
  %p14924 = inttoptr i64 %v14923 to ptr
  %rgep14925 = getelementptr i8, ptr %p14924, i64 -32
  %ld14926 = load i64, ptr %rgep14925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14926, ptr %slot2809, align 8
  %v14927 = load i64, ptr %slot2809, align 8
  %cmp14928 = icmp ne i64 %v14927, 0
  %cv14929 = zext i1 %cmp14928 to i32
  store i32 %cv14929, ptr %slot2810, align 8
  %v14930 = load i32, ptr %slot2810, align 8
  %cv14931 = zext i32 %v14930 to i64
  %cond14932 = icmp ne i64 %cv14931, 0
  br i1 %cond14932, label %bb_rcgdec3782, label %bb_rcgslow3782
bb_rcgslow3782:
  %v14933 = load i64, ptr %slot2797, align 8
  %v14934 = load i64, ptr %slot2794, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v14933, i64 %v14934) nomerge, !dbg !274
  br label %bb_rcgdone3782
bb_rcgdec3782:
  %v14935 = load i64, ptr %slot2806, align 8
  %v14936 = load i64, ptr %slot2798, align 8
  %p14937 = inttoptr i64 %v14936 to ptr
  %rgep14938 = getelementptr i8, ptr %p14937, i64 -24
  store i64 %v14935, ptr %rgep14938, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3782
bb_rcgclear3782:
  %v14939 = load i64, ptr %slot2794, align 8
  %p14940 = inttoptr i64 %v14939 to ptr
  store i64 0, ptr %p14940, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3782
bb_rcgdone3782:
  br label %bb_rcslotdone3766
bb_rcslotowner3766:
  %v14941 = load i64, ptr %slot99, align 8
  store i64 %v14941, ptr %slot2811, align 8
  %v14942 = load i64, ptr %slot2794, align 8
  %p14943 = inttoptr i64 %v14942 to ptr
  %ld14944 = load i64, ptr %p14943, align 8, !alias.scope !3, !noalias !4
  store i64 %ld14944, ptr %slot2812, align 8
  %v14945 = load i64, ptr %slot2812, align 8
  %cmp14946 = icmp ne i64 %v14945, 0
  %cv14947 = zext i1 %cmp14946 to i32
  store i32 %cv14947, ptr %slot2813, align 8
  %v14948 = load i32, ptr %slot2813, align 8
  %cv14949 = zext i32 %v14948 to i64
  %cond14950 = icmp ne i64 %cv14949, 0
  br i1 %cond14950, label %bb_rcgnn3797, label %bb_rcgdone3797
bb_rcgnn3797:
  %v14951 = load i64, ptr %slot2812, align 8
  %op14952 = sub i64 %v14951, 16
  store i64 %op14952, ptr %slot2814, align 8
  %v14953 = load i64, ptr %slot2812, align 8
  %p14954 = inttoptr i64 %v14953 to ptr
  %rgep14955 = getelementptr i8, ptr %p14954, i64 -16
  %ld14956 = load i64, ptr %rgep14955, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14956, ptr %slot2815, align 8
  %v14957 = load i64, ptr %slot2815, align 8
  %op14958 = and i64 %v14957, 4611686018427387906
  store i64 %op14958, ptr %slot2816, align 8
  %v14959 = load i64, ptr %slot2816, align 8
  %cmp14960 = icmp ne i64 %v14959, 0
  %cv14961 = zext i1 %cmp14960 to i32
  store i32 %cv14961, ptr %slot2817, align 8
  %v14962 = load i32, ptr %slot2817, align 8
  %cv14963 = zext i32 %v14962 to i64
  %cond14964 = icmp ne i64 %cv14963, 0
  br i1 %cond14964, label %bb_rcgclear3797, label %bb_rcgcounted3797
bb_rcgcounted3797:
  %v14965 = load i64, ptr %slot2812, align 8
  %op14966 = sub i64 %v14965, 32
  store i64 %op14966, ptr %slot2818, align 8
  %v14967 = load i64, ptr %slot2812, align 8
  %p14968 = inttoptr i64 %v14967 to ptr
  %rgep14969 = getelementptr i8, ptr %p14968, i64 -32
  %ld14970 = load i64, ptr %rgep14969, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14970, ptr %slot2819, align 8
  %v14971 = load i64, ptr %slot2819, align 8
  %op14972 = sub i64 %v14971, 1
  store i64 %op14972, ptr %slot2820, align 8
  %v14973 = load i64, ptr %slot2820, align 8
  %cmp14974 = icmp eq i64 %v14973, 0
  %cv14975 = zext i1 %cmp14974 to i32
  store i32 %cv14975, ptr %slot2821, align 8
  %v14976 = load i32, ptr %slot2821, align 8
  %cv14977 = zext i32 %v14976 to i64
  %cond14978 = icmp ne i64 %cv14977, 0
  br i1 %cond14978, label %bb_rcglast3797, label %bb_rcgdec3797
bb_rcglast3797:
  %v14979 = load i64, ptr %slot2812, align 8
  %op14980 = sub i64 %v14979, 24
  store i64 %op14980, ptr %slot2822, align 8
  %v14981 = load i64, ptr %slot2812, align 8
  %p14982 = inttoptr i64 %v14981 to ptr
  %rgep14983 = getelementptr i8, ptr %p14982, i64 -24
  %ld14984 = load i64, ptr %rgep14983, align 8, !alias.scope !9, !noalias !10
  store i64 %ld14984, ptr %slot2823, align 8
  %v14985 = load i64, ptr %slot2823, align 8
  %cmp14986 = icmp ne i64 %v14985, 0
  %cv14987 = zext i1 %cmp14986 to i32
  store i32 %cv14987, ptr %slot2824, align 8
  %v14988 = load i32, ptr %slot2824, align 8
  %cv14989 = zext i32 %v14988 to i64
  %cond14990 = icmp ne i64 %cv14989, 0
  br i1 %cond14990, label %bb_rcgdec3797, label %bb_rcgslow3797
bb_rcgslow3797:
  %v14991 = load i64, ptr %slot2811, align 8
  %v14992 = load i64, ptr %slot2794, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v14991, i64 %v14992) nomerge, !dbg !274
  br label %bb_rcgdone3797
bb_rcgdec3797:
  %v14993 = load i64, ptr %slot2820, align 8
  %v14994 = load i64, ptr %slot2812, align 8
  %p14995 = inttoptr i64 %v14994 to ptr
  %rgep14996 = getelementptr i8, ptr %p14995, i64 -32
  store i64 %v14993, ptr %rgep14996, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3797
bb_rcgclear3797:
  %v14997 = load i64, ptr %slot2794, align 8
  %p14998 = inttoptr i64 %v14997 to ptr
  store i64 0, ptr %p14998, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3797
bb_rcgdone3797:
  br label %bb_rcslotdone3766
bb_rcslotdone3766:
  %v14999 = load i64, ptr %slot7, align 8
  %p15000 = inttoptr i64 %v14999 to ptr
  %ld15001 = load i32, ptr %p15000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld15001, ptr %slot2825, align 8
  %v15002 = load i32, ptr %slot2825, align 8
  %cv15003 = zext i32 %v15002 to i64
  %cond15004 = icmp ne i64 %cv15003, 0
  br i1 %cond15004, label %bb_rcslotdrop3803, label %bb_rcslotdone3803
bb_rcslotdrop3803:
  %v15005 = load i64, ptr %slot7, align 8
  %p15006 = inttoptr i64 %v15005 to ptr
  store i32 0, ptr %p15006, align 4, !alias.scope !3, !noalias !4
  %v15007 = load i64, ptr %slot34, align 8
  store i64 %v15007, ptr %slot2826, align 8
  %v15008 = load i64, ptr %slot8, align 8
  %p15009 = inttoptr i64 %v15008 to ptr
  %ld15010 = load i32, ptr %p15009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld15010, ptr %slot2827, align 8
  %v15011 = load i32, ptr %slot2827, align 8
  %op15012 = and i32 %v15011, 28
  store i32 %op15012, ptr %slot2828, align 8
  %v15013 = load i32, ptr %slot2828, align 8
  %cv15014 = zext i32 %v15013 to i64
  %cond15015 = icmp ne i64 %cv15014, 0
  br i1 %cond15015, label %bb_rcslotrole3803, label %bb_rcslotowner3803
bb_rcslotrole3803:
  %v15016 = load i64, ptr %slot99, align 8
  store i64 %v15016, ptr %slot2829, align 8
  %v15017 = load i64, ptr %slot2826, align 8
  %p15018 = inttoptr i64 %v15017 to ptr
  %ld15019 = load i64, ptr %p15018, align 8, !alias.scope !3, !noalias !4
  store i64 %ld15019, ptr %slot2830, align 8
  %v15020 = load i64, ptr %slot2830, align 8
  %cmp15021 = icmp ne i64 %v15020, 0
  %cv15022 = zext i1 %cmp15021 to i32
  store i32 %cv15022, ptr %slot2831, align 8
  %v15023 = load i32, ptr %slot2831, align 8
  %cv15024 = zext i32 %v15023 to i64
  %cond15025 = icmp ne i64 %cv15024, 0
  br i1 %cond15025, label %bb_rcgnn3819, label %bb_rcgdone3819
bb_rcgnn3819:
  %v15026 = load i64, ptr %slot2830, align 8
  %op15027 = sub i64 %v15026, 16
  store i64 %op15027, ptr %slot2832, align 8
  %v15028 = load i64, ptr %slot2830, align 8
  %p15029 = inttoptr i64 %v15028 to ptr
  %rgep15030 = getelementptr i8, ptr %p15029, i64 -16
  %ld15031 = load i64, ptr %rgep15030, align 8, !alias.scope !9, !noalias !10
  store i64 %ld15031, ptr %slot2833, align 8
  %v15032 = load i64, ptr %slot2833, align 8
  %op15033 = and i64 %v15032, 4611686018427387906
  store i64 %op15033, ptr %slot2834, align 8
  %v15034 = load i64, ptr %slot2834, align 8
  %cmp15035 = icmp ne i64 %v15034, 0
  %cv15036 = zext i1 %cmp15035 to i32
  store i32 %cv15036, ptr %slot2835, align 8
  %v15037 = load i32, ptr %slot2835, align 8
  %cv15038 = zext i32 %v15037 to i64
  %cond15039 = icmp ne i64 %cv15038, 0
  br i1 %cond15039, label %bb_rcgclear3819, label %bb_rcgcounted3819
bb_rcgcounted3819:
  %v15040 = load i64, ptr %slot2830, align 8
  %op15041 = sub i64 %v15040, 24
  store i64 %op15041, ptr %slot2836, align 8
  %v15042 = load i64, ptr %slot2830, align 8
  %p15043 = inttoptr i64 %v15042 to ptr
  %rgep15044 = getelementptr i8, ptr %p15043, i64 -24
  %ld15045 = load i64, ptr %rgep15044, align 8, !alias.scope !9, !noalias !10
  store i64 %ld15045, ptr %slot2837, align 8
  %v15046 = load i64, ptr %slot2837, align 8
  %op15047 = sub i64 %v15046, 1
  store i64 %op15047, ptr %slot2838, align 8
  %v15048 = load i64, ptr %slot2838, align 8
  %cmp15049 = icmp eq i64 %v15048, 0
  %cv15050 = zext i1 %cmp15049 to i32
  store i32 %cv15050, ptr %slot2839, align 8
  %v15051 = load i32, ptr %slot2839, align 8
  %cv15052 = zext i32 %v15051 to i64
  %cond15053 = icmp ne i64 %cv15052, 0
  br i1 %cond15053, label %bb_rcglast3819, label %bb_rcgdec3819
bb_rcglast3819:
  %v15054 = load i64, ptr %slot2830, align 8
  %op15055 = sub i64 %v15054, 32
  store i64 %op15055, ptr %slot2840, align 8
  %v15056 = load i64, ptr %slot2830, align 8
  %p15057 = inttoptr i64 %v15056 to ptr
  %rgep15058 = getelementptr i8, ptr %p15057, i64 -32
  %ld15059 = load i64, ptr %rgep15058, align 8, !alias.scope !9, !noalias !10
  store i64 %ld15059, ptr %slot2841, align 8
  %v15060 = load i64, ptr %slot2841, align 8
  %cmp15061 = icmp ne i64 %v15060, 0
  %cv15062 = zext i1 %cmp15061 to i32
  store i32 %cv15062, ptr %slot2842, align 8
  %v15063 = load i32, ptr %slot2842, align 8
  %cv15064 = zext i32 %v15063 to i64
  %cond15065 = icmp ne i64 %cv15064, 0
  br i1 %cond15065, label %bb_rcgdec3819, label %bb_rcgslow3819
bb_rcgslow3819:
  %v15066 = load i64, ptr %slot2829, align 8
  %v15067 = load i64, ptr %slot2826, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v15066, i64 %v15067) nomerge, !dbg !274
  br label %bb_rcgdone3819
bb_rcgdec3819:
  %v15068 = load i64, ptr %slot2838, align 8
  %v15069 = load i64, ptr %slot2830, align 8
  %p15070 = inttoptr i64 %v15069 to ptr
  %rgep15071 = getelementptr i8, ptr %p15070, i64 -24
  store i64 %v15068, ptr %rgep15071, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3819
bb_rcgclear3819:
  %v15072 = load i64, ptr %slot2826, align 8
  %p15073 = inttoptr i64 %v15072 to ptr
  store i64 0, ptr %p15073, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3819
bb_rcgdone3819:
  br label %bb_rcslotdone3803
bb_rcslotowner3803:
  %v15074 = load i64, ptr %slot99, align 8
  store i64 %v15074, ptr %slot2843, align 8
  %v15075 = load i64, ptr %slot2826, align 8
  %p15076 = inttoptr i64 %v15075 to ptr
  %ld15077 = load i64, ptr %p15076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld15077, ptr %slot2844, align 8
  %v15078 = load i64, ptr %slot2844, align 8
  %cmp15079 = icmp ne i64 %v15078, 0
  %cv15080 = zext i1 %cmp15079 to i32
  store i32 %cv15080, ptr %slot2845, align 8
  %v15081 = load i32, ptr %slot2845, align 8
  %cv15082 = zext i32 %v15081 to i64
  %cond15083 = icmp ne i64 %cv15082, 0
  br i1 %cond15083, label %bb_rcgnn3834, label %bb_rcgdone3834
bb_rcgnn3834:
  %v15084 = load i64, ptr %slot2844, align 8
  %op15085 = sub i64 %v15084, 16
  store i64 %op15085, ptr %slot2846, align 8
  %v15086 = load i64, ptr %slot2844, align 8
  %p15087 = inttoptr i64 %v15086 to ptr
  %rgep15088 = getelementptr i8, ptr %p15087, i64 -16
  %ld15089 = load i64, ptr %rgep15088, align 8, !alias.scope !9, !noalias !10
  store i64 %ld15089, ptr %slot2847, align 8
  %v15090 = load i64, ptr %slot2847, align 8
  %op15091 = and i64 %v15090, 4611686018427387906
  store i64 %op15091, ptr %slot2848, align 8
  %v15092 = load i64, ptr %slot2848, align 8
  %cmp15093 = icmp ne i64 %v15092, 0
  %cv15094 = zext i1 %cmp15093 to i32
  store i32 %cv15094, ptr %slot2849, align 8
  %v15095 = load i32, ptr %slot2849, align 8
  %cv15096 = zext i32 %v15095 to i64
  %cond15097 = icmp ne i64 %cv15096, 0
  br i1 %cond15097, label %bb_rcgclear3834, label %bb_rcgcounted3834
bb_rcgcounted3834:
  %v15098 = load i64, ptr %slot2844, align 8
  %op15099 = sub i64 %v15098, 32
  store i64 %op15099, ptr %slot2850, align 8
  %v15100 = load i64, ptr %slot2844, align 8
  %p15101 = inttoptr i64 %v15100 to ptr
  %rgep15102 = getelementptr i8, ptr %p15101, i64 -32
  %ld15103 = load i64, ptr %rgep15102, align 8, !alias.scope !9, !noalias !10
  store i64 %ld15103, ptr %slot2851, align 8
  %v15104 = load i64, ptr %slot2851, align 8
  %op15105 = sub i64 %v15104, 1
  store i64 %op15105, ptr %slot2852, align 8
  %v15106 = load i64, ptr %slot2852, align 8
  %cmp15107 = icmp eq i64 %v15106, 0
  %cv15108 = zext i1 %cmp15107 to i32
  store i32 %cv15108, ptr %slot2853, align 8
  %v15109 = load i32, ptr %slot2853, align 8
  %cv15110 = zext i32 %v15109 to i64
  %cond15111 = icmp ne i64 %cv15110, 0
  br i1 %cond15111, label %bb_rcglast3834, label %bb_rcgdec3834
bb_rcglast3834:
  %v15112 = load i64, ptr %slot2844, align 8
  %op15113 = sub i64 %v15112, 24
  store i64 %op15113, ptr %slot2854, align 8
  %v15114 = load i64, ptr %slot2844, align 8
  %p15115 = inttoptr i64 %v15114 to ptr
  %rgep15116 = getelementptr i8, ptr %p15115, i64 -24
  %ld15117 = load i64, ptr %rgep15116, align 8, !alias.scope !9, !noalias !10
  store i64 %ld15117, ptr %slot2855, align 8
  %v15118 = load i64, ptr %slot2855, align 8
  %cmp15119 = icmp ne i64 %v15118, 0
  %cv15120 = zext i1 %cmp15119 to i32
  store i32 %cv15120, ptr %slot2856, align 8
  %v15121 = load i32, ptr %slot2856, align 8
  %cv15122 = zext i32 %v15121 to i64
  %cond15123 = icmp ne i64 %cv15122, 0
  br i1 %cond15123, label %bb_rcgdec3834, label %bb_rcgslow3834
bb_rcgslow3834:
  %v15124 = load i64, ptr %slot2843, align 8
  %v15125 = load i64, ptr %slot2826, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v15124, i64 %v15125) nomerge, !dbg !274
  br label %bb_rcgdone3834
bb_rcgdec3834:
  %v15126 = load i64, ptr %slot2852, align 8
  %v15127 = load i64, ptr %slot2844, align 8
  %p15128 = inttoptr i64 %v15127 to ptr
  %rgep15129 = getelementptr i8, ptr %p15128, i64 -32
  store i64 %v15126, ptr %rgep15129, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3834
bb_rcgclear3834:
  %v15130 = load i64, ptr %slot2826, align 8
  %p15131 = inttoptr i64 %v15130 to ptr
  store i64 0, ptr %p15131, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3834
bb_rcgdone3834:
  br label %bb_rcslotdone3803
bb_rcslotdone3803:
  %v15132 = load i64, ptr %slot5, align 8
  %p15133 = inttoptr i64 %v15132 to ptr
  %ld15134 = load i32, ptr %p15133, align 4, !alias.scope !3, !noalias !4
  store i32 %ld15134, ptr %slot2857, align 8
  %v15135 = load i32, ptr %slot2857, align 8
  %cv15136 = zext i32 %v15135 to i64
  %cond15137 = icmp ne i64 %cv15136, 0
  br i1 %cond15137, label %bb_rcslotdrop3840, label %bb_rcslotdone3840
bb_rcslotdrop3840:
  %v15138 = load i64, ptr %slot5, align 8
  %p15139 = inttoptr i64 %v15138 to ptr
  store i32 0, ptr %p15139, align 4, !alias.scope !3, !noalias !4
  %v15140 = load i64, ptr %slot33, align 8
  store i64 %v15140, ptr %slot2858, align 8
  %v15141 = load i64, ptr %slot6, align 8
  %p15142 = inttoptr i64 %v15141 to ptr
  %ld15143 = load i32, ptr %p15142, align 4, !alias.scope !3, !noalias !4
  store i32 %ld15143, ptr %slot2859, align 8
  %v15144 = load i32, ptr %slot2859, align 8
  %op15145 = and i32 %v15144, 28
  store i32 %op15145, ptr %slot2860, align 8
  %v15146 = load i32, ptr %slot2860, align 8
  %cv15147 = zext i32 %v15146 to i64
  %cond15148 = icmp ne i64 %cv15147, 0
  br i1 %cond15148, label %bb_rcslotrole3840, label %bb_rcslotowner3840
bb_rcslotrole3840:
  %v15149 = load i64, ptr %slot99, align 8
  store i64 %v15149, ptr %slot2861, align 8
  %v15150 = load i64, ptr %slot2861, align 8
  %v15151 = load i64, ptr %slot2858, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v15150, i64 %v15151) nomerge, !dbg !274
  br label %bb_rcslotdone3840
bb_rcslotowner3840:
  %v15152 = load i64, ptr %slot99, align 8
  store i64 %v15152, ptr %slot2862, align 8
  %v15153 = load i64, ptr %slot2862, align 8
  %v15154 = load i64, ptr %slot2858, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v15153, i64 %v15154) nomerge, !dbg !274
  br label %bb_rcslotdone3840
bb_rcslotdone3840:
  %v15155 = load i64, ptr %slot2779, align 8
  %p15156 = inttoptr i64 %v15155 to ptr
  %ret15157 = load { i64, i64 }, ptr %p15156, align 8
  ret { i64, i64 } %ret15157
bb_failure:
  %v15158 = load i64, ptr %slot4, align 8
  %p15159 = inttoptr i64 %v15158 to ptr
  call void @llvm.memset.p0.i64(ptr %p15159, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !274
  %v15160 = load i64, ptr %slot4, align 8
  %p15161 = inttoptr i64 %v15160 to ptr
  %ret15162 = load { i64, i64 }, ptr %p15161, align 8
  ret { i64, i64 } %ret15162
bb_entry_failure:
  %v15163 = load i64, ptr %slot4, align 8
  %p15164 = inttoptr i64 %v15163 to ptr
  call void @llvm.memset.p0.i64(ptr %p15164, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !274
  %v15165 = load i64, ptr %slot4, align 8
  %p15166 = inttoptr i64 %v15165 to ptr
  %ret15167 = load { i64, i64 }, ptr %p15166, align 8
  ret { i64, i64 } %ret15167
}

@myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02_meta = external global i8, align 8
@myl_lit_4a567dbed804c7cf92d6eb2154c9ccfecc754c82ed316a70b59da8384d2cb99f = external global i8, align 8
@myl_lit_881974f73ada6aff407ebfba62bf871f256bbdf7b656c2f7273e09ae58fa4d70 = external global i8, align 8
@myl_lit_9c78dec40d01c6c2bedb89cda9ba9fa8c40c54e0b599c5f8b355df196d3b6314 = external global i8, align 8
@myl_lit_d768da1261b328d49d84dd2a5d0143673c4885882d455d18227005ca42aecda4 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_0852eba96c77f7afcc3f7f7ba264fa932e026fa8ae3581862cf7b1d9d82914d4_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare i64 @myl_f_09ac5f1ec5d527b8e47dfe7d31e0ded962e03563ba62f0f2a27aed6073695bb4(i64, i64, i64)
declare i64 @myl_f_44a5ec7f496860cf0b71be8102746ea8e7c1b55d19ea6f2031f48b2fd6233055(i64, i64, i64)
declare i64 @myl_f_4521d175f012ce8c8470c22d2931ed754baea9bee997654d4708f8fc203d4623(i64, i64, i64, i64)
declare { i64, i64 } @myl_f_47954c6af8efda32016a72b4e903396e86f238e834ff3f811dcdd43255b2ad2e(i64, i64)
declare void @myl_f_48fc85b8d899bffdab8561c792857826ecb0e00dc6ba262ad50eb05ce72b6ace_rc_borrow(ptr sret([40 x i8]) align 8, i64, i64)
declare i8 @myl_f_7a515a62bcf2d52dbd1a003508cbad18b835f8a05891010b6b797b5f49fa312f(i64, i64, i64, i64)
declare i64 @myl_f_95ed024ac5550fa33e3709a22f37afe61493456c867352f03a4d43811a49c125(i64, i64, i64)
declare i64 @myl_f_b7a12bdbd9547ccabb9d876662e9976c6fd3dd8b6892255b2031bd242de13116(i64, i64, i64)
declare i64 @myl_f_be55845d0d1b5c3c8f232826f6eebbc3f154bbc843ca36782c227966ffc2f923(i64, i64, i64)
declare void @myl_f_e2c0eba886f57ca59b45b2ece391ba75757906c13f3a1bc9ed1d460cdba5fe42(ptr sret([48 x i8]) align 8, i64, i64, i64, i64)
declare i32 @myl_native_bytes_number_parse(ptr, i64, i32, ptr)
declare ptr @myl_native_bytes_range(ptr, i64, i64, ptr)
declare ptr @myl_native_bytes_view(ptr, ptr, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare i32 @myl_t_00d3d0a6d183667b0b8b1b9b81e4544027060320c0d477576f0046bde98e5d2f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_drop(i64, i64)
declare void @myl_t_2411665088eb19109b6087627d8343f1cf3540c5146d3862535fde926cb87252_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_loan(i64, i64, i64)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_take(i64, i64, i64, i32)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_drop(i64, i64)
declare void @myl_t_6f2a1ab4afa929be6e127c21d505b724ea90718cabbadb2726d605f7956261ec_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)
declare i32 @myl_t_a819ef2d72d340126fc5682fa118621e1368f8d54ae79cf8810ff758598e6ec8_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02", linkageName: "myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 6283035235364625409, i64 0, !"myl_f_79a71f360658b2ac0dc67a2d5d3fe12304f8a6c194ace78011e5bfdb82e1ba02"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!114 = !DILocation(line: 3, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!116 = !DILocation(line: 9, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!118 = !DILocation(line: 10, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!120 = !DILocation(line: 12, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!122 = !DILocation(line: 15, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!124 = !DILocation(line: 21, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!126 = !DILocation(line: 22, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!128 = !DILocation(line: 24, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!130 = !DILocation(line: 27, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646791)
!132 = !DILocation(line: 32, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646799)
!134 = !DILocation(line: 33, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!136 = !DILocation(line: 35, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!138 = !DILocation(line: 38, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!140 = !DILocation(line: 41, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!142 = !DILocation(line: 42, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!144 = !DILocation(line: 44, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!146 = !DILocation(line: 45, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!148 = !DILocation(line: 47, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!150 = !DILocation(line: 49, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!152 = !DILocation(line: 51, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!154 = !DILocation(line: 52, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!156 = !DILocation(line: 53, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!158 = !DILocation(line: 54, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!160 = !DILocation(line: 70, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647111)
!162 = !DILocation(line: 72, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647135)
!164 = !DILocation(line: 75, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647159)
!166 = !DILocation(line: 78, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!168 = !DILocation(line: 79, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647191)
!170 = !DILocation(line: 82, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647199)
!172 = !DILocation(line: 83, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647215)
!174 = !DILocation(line: 85, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!176 = !DILocation(line: 87, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647247)
!178 = !DILocation(line: 89, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647271)
!180 = !DILocation(line: 92, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647287)
!182 = !DILocation(line: 94, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647295)
!184 = !DILocation(line: 95, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647303)
!186 = !DILocation(line: 96, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647311)
!188 = !DILocation(line: 97, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647351)
!190 = !DILocation(line: 102, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647367)
!192 = !DILocation(line: 104, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647391)
!194 = !DILocation(line: 107, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647415)
!196 = !DILocation(line: 110, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647423)
!198 = !DILocation(line: 111, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647455)
!200 = !DILocation(line: 115, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647463)
!202 = !DILocation(line: 116, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647479)
!204 = !DILocation(line: 118, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647487)
!206 = !DILocation(line: 119, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647519)
!208 = !DILocation(line: 123, column: 0, scope: !209)
!211 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647527)
!210 = !DILocation(line: 124, column: 0, scope: !211)
!213 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647543)
!212 = !DILocation(line: 126, column: 0, scope: !213)
!215 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647551)
!214 = !DILocation(line: 127, column: 0, scope: !215)
!217 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647599)
!216 = !DILocation(line: 133, column: 0, scope: !217)
!219 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647623)
!218 = !DILocation(line: 136, column: 0, scope: !219)
!221 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647631)
!220 = !DILocation(line: 137, column: 0, scope: !221)
!223 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647639)
!222 = !DILocation(line: 138, column: 0, scope: !223)
!225 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647655)
!224 = !DILocation(line: 140, column: 0, scope: !225)
!227 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647679)
!226 = !DILocation(line: 143, column: 0, scope: !227)
!229 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647711)
!228 = !DILocation(line: 147, column: 0, scope: !229)
!231 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647735)
!230 = !DILocation(line: 150, column: 0, scope: !231)
!233 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647743)
!232 = !DILocation(line: 151, column: 0, scope: !233)
!235 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647751)
!234 = !DILocation(line: 152, column: 0, scope: !235)
!237 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647767)
!236 = !DILocation(line: 154, column: 0, scope: !237)
!239 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647791)
!238 = !DILocation(line: 157, column: 0, scope: !239)
!241 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647823)
!240 = !DILocation(line: 161, column: 0, scope: !241)
!243 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647831)
!242 = !DILocation(line: 162, column: 0, scope: !243)
!245 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647847)
!244 = !DILocation(line: 164, column: 0, scope: !245)
!247 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647871)
!246 = !DILocation(line: 167, column: 0, scope: !247)
!249 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647895)
!248 = !DILocation(line: 170, column: 0, scope: !249)
!251 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647903)
!250 = !DILocation(line: 171, column: 0, scope: !251)
!253 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647919)
!252 = !DILocation(line: 173, column: 0, scope: !253)
!255 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647959)
!254 = !DILocation(line: 178, column: 0, scope: !255)
!257 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647967)
!256 = !DILocation(line: 179, column: 0, scope: !257)
!259 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647983)
!258 = !DILocation(line: 181, column: 0, scope: !259)
!261 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647991)
!260 = !DILocation(line: 182, column: 0, scope: !261)
!263 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648023)
!262 = !DILocation(line: 186, column: 0, scope: !263)
!265 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648031)
!264 = !DILocation(line: 187, column: 0, scope: !265)
!267 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648047)
!266 = !DILocation(line: 189, column: 0, scope: !267)
!269 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648071)
!268 = !DILocation(line: 192, column: 0, scope: !269)
!271 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648087)
!270 = !DILocation(line: 194, column: 0, scope: !271)
!273 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648095)
!272 = !DILocation(line: 195, column: 0, scope: !273)
!275 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648103)
!274 = !DILocation(line: 196, column: 0, scope: !275)
