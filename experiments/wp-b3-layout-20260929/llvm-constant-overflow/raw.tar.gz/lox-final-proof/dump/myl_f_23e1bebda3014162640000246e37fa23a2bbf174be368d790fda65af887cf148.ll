target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_23e1bebda3014162640000246e37fa23a2bbf174be368d790fda65af887cf148(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %callresult44 = alloca [88 x i8], align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i32, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i32, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i32, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i32, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i32, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i32, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i32, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i32, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i32, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i32, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i32, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i32, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i32, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i32, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i32, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i32, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i32, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i64, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i64, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i32, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i32, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i32, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i32, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i64, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i64, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i32, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i32, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i32, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i32, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i32, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i64, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i32, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i32, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i32, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i32, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i32, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i32, align 8
  %slot376 = alloca i32, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i32, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i64, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i64, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i32, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i64, align 8
  %slot393 = alloca i32, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i64, align 8
  %slot396 = alloca i32, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i32, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i32, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i32, align 8
  %slot408 = alloca i32, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i32, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i32, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i32, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i32, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i32, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i32, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i32, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i32, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i32, align 8
  %slot460 = alloca i64, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i32, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i64, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i32, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i32, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i64, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i32, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i64, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i64, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i64, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i32, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i64, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i32, align 8
  %slot502 = alloca i64, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i32, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i32, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i32, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i32, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i32, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i32, align 8
  %slot537 = alloca i32, align 8
  %slot538 = alloca i32, align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i32, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i32, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i32, align 8
  %slot555 = alloca i32, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i32, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i32, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i32, align 8
  %slot581 = alloca i64, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i32, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i32, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i64, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i32, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i32, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i64, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i64, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i32, align 8
  %slot657 = alloca i32, align 8
  %slot658 = alloca i64, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i32, align 8
  %slot664 = alloca i32, align 8
  %slot665 = alloca i32, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i64, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i32, align 8
  %slot672 = alloca i32, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i32, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i32, align 8
  %slot683 = alloca i32, align 8
  %slot684 = alloca i32, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i32, align 8
  %slot689 = alloca i32, align 8
  %slot690 = alloca i32, align 8
  %slot691 = alloca i64, align 8
  %slot692 = alloca i32, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i32, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i64, align 8
  %slot705 = alloca i64, align 8
  %slot706 = alloca i32, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i32, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i32, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i32, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i64, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i32, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i32, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i32, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i64, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i32, align 8
  %slot737 = alloca i32, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i32, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i32, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i32, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i32, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i32, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i64, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i32, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i32, align 8
  %slot775 = alloca i32, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i32, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i32, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i64, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i32, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i64, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i64, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i32, align 8
  %slot820 = alloca i32, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i64, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i64, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i32, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i32, align 8
  %slot837 = alloca i32, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i32, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i32, align 8
  %slot842 = alloca i32, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i32, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i32, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i32, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i32, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i64, align 8
  %slot869 = alloca i64, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i64, align 8
  %slot876 = alloca i64, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i32, align 8
  %slot889 = alloca i64, align 8
  %slot890 = alloca i64, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i64, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i64, align 8
  %slot907 = alloca i64, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i64, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i64, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i32, align 8
  %slot917 = alloca i64, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i32, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i32, align 8
  %slot933 = alloca i64, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i32, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i32, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i64, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i32, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i32, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i32, align 8
  %slot968 = alloca i32, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i32, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i32, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i64, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i64, align 8
  %slot995 = alloca i32, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i64, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i32, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i64, align 8
  %slot1002 = alloca i32, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i32, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i32, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i32, align 8
  %slot1014 = alloca i32, align 8
  %slot1015 = alloca i64, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i32, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i64, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i32, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i32, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i64, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i64, align 8
  %slot1030 = alloca i64, align 8
  %slot1031 = alloca i32, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i64, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i32, align 8
  %slot1043 = alloca i32, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i32, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i64, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i64, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i32, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i32, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i32, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i32, align 8
  %slot1078 = alloca i32, align 8
  %slot1079 = alloca i64, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i64, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i32, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i32, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i64, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i64, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i32, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i32, align 8
  %slot1107 = alloca i32, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i32, align 8
  %slot1110 = alloca i32, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v1113 = load i64, ptr %slot1, align 8
  %op1114 = add i64 %v1113, 32
  store i64 %op1114, ptr %slot3, align 8
  %mem1115 = alloca i8, i64 8, align 8
  %ptr1116 = ptrtoint ptr %mem1115 to i64
  store i64 %ptr1116, ptr %slot4, align 8
  %mem1117 = alloca i8, i64 8, align 8
  %ptr1118 = ptrtoint ptr %mem1117 to i64
  store i64 %ptr1118, ptr %slot5, align 8
  %mem1119 = alloca i8, i64 8, align 8
  %ptr1120 = ptrtoint ptr %mem1119 to i64
  store i64 %ptr1120, ptr %slot6, align 8
  %mem1121 = alloca i8, i64 8, align 8
  %ptr1122 = ptrtoint ptr %mem1121 to i64
  store i64 %ptr1122, ptr %slot7, align 8
  %mem1123 = alloca i8, i64 8, align 8
  %ptr1124 = ptrtoint ptr %mem1123 to i64
  store i64 %ptr1124, ptr %slot8, align 8
  %mem1125 = alloca i8, i64 8, align 8
  %ptr1126 = ptrtoint ptr %mem1125 to i64
  store i64 %ptr1126, ptr %slot9, align 8
  %mem1127 = alloca i8, i64 8, align 8
  %ptr1128 = ptrtoint ptr %mem1127 to i64
  store i64 %ptr1128, ptr %slot10, align 8
  %mem1129 = alloca i8, i64 8, align 8
  %ptr1130 = ptrtoint ptr %mem1129 to i64
  store i64 %ptr1130, ptr %slot11, align 8
  %mem1131 = alloca i8, i64 8, align 8
  %ptr1132 = ptrtoint ptr %mem1131 to i64
  store i64 %ptr1132, ptr %slot12, align 8
  %mem1133 = alloca i8, i64 8, align 8
  %ptr1134 = ptrtoint ptr %mem1133 to i64
  store i64 %ptr1134, ptr %slot13, align 8
  %mem1135 = alloca i8, i64 8, align 8
  %ptr1136 = ptrtoint ptr %mem1135 to i64
  store i64 %ptr1136, ptr %slot14, align 8
  %mem1137 = alloca i8, i64 8, align 8
  %ptr1138 = ptrtoint ptr %mem1137 to i64
  store i64 %ptr1138, ptr %slot15, align 8
  %mem1139 = alloca i8, i64 8, align 8
  %ptr1140 = ptrtoint ptr %mem1139 to i64
  store i64 %ptr1140, ptr %slot16, align 8
  %mem1141 = alloca i8, i64 8, align 8
  %ptr1142 = ptrtoint ptr %mem1141 to i64
  store i64 %ptr1142, ptr %slot17, align 8
  %mem1143 = alloca i8, i64 8, align 8
  %ptr1144 = ptrtoint ptr %mem1143 to i64
  store i64 %ptr1144, ptr %slot18, align 8
  %mem1145 = alloca i8, i64 8, align 8
  %ptr1146 = ptrtoint ptr %mem1145 to i64
  store i64 %ptr1146, ptr %slot19, align 8
  %mem1147 = alloca i8, i64 392, align 8
  %ptr1148 = ptrtoint ptr %mem1147 to i64
  store i64 %ptr1148, ptr %slot20, align 8
  %mem1149 = alloca i8, i64 392, align 8
  %ptr1150 = ptrtoint ptr %mem1149 to i64
  store i64 %ptr1150, ptr %slot21, align 8
  %mem1151 = alloca i8, i64 8, align 8
  %ptr1152 = ptrtoint ptr %mem1151 to i64
  store i64 %ptr1152, ptr %slot22, align 8
  %mem1153 = alloca i8, i64 8, align 8
  %ptr1154 = ptrtoint ptr %mem1153 to i64
  store i64 %ptr1154, ptr %slot23, align 8
  %mem1155 = alloca i8, i64 392, align 8
  %ptr1156 = ptrtoint ptr %mem1155 to i64
  store i64 %ptr1156, ptr %slot24, align 8
  %mem1157 = alloca i8, i64 8, align 8
  %ptr1158 = ptrtoint ptr %mem1157 to i64
  store i64 %ptr1158, ptr %slot25, align 8
  %mem1159 = alloca i8, i64 88, align 8
  %ptr1160 = ptrtoint ptr %mem1159 to i64
  store i64 %ptr1160, ptr %slot26, align 8
  %mem1161 = alloca i8, i64 8, align 8
  %ptr1162 = ptrtoint ptr %mem1161 to i64
  store i64 %ptr1162, ptr %slot27, align 8
  %mem1163 = alloca i8, i64 8, align 8
  %ptr1164 = ptrtoint ptr %mem1163 to i64
  store i64 %ptr1164, ptr %slot28, align 8
  %mem1165 = alloca i8, i64 8, align 8
  %ptr1166 = ptrtoint ptr %mem1165 to i64
  store i64 %ptr1166, ptr %slot29, align 8
  %mem1167 = alloca i8, i64 8, align 8
  %ptr1168 = ptrtoint ptr %mem1167 to i64
  store i64 %ptr1168, ptr %slot30, align 8
  %mem1169 = alloca i8, i64 8, align 8
  %ptr1170 = ptrtoint ptr %mem1169 to i64
  store i64 %ptr1170, ptr %slot31, align 8
  %mem1171 = alloca i8, i64 24, align 8
  %ptr1172 = ptrtoint ptr %mem1171 to i64
  store i64 %ptr1172, ptr %slot32, align 8
  %mem1173 = alloca i8, i64 8, align 8
  %ptr1174 = ptrtoint ptr %mem1173 to i64
  store i64 %ptr1174, ptr %slot33, align 8
  %mem1175 = alloca i8, i64 8, align 8
  %ptr1176 = ptrtoint ptr %mem1175 to i64
  store i64 %ptr1176, ptr %slot34, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem1177 = alloca i8, i64 8, align 8
  %ptr1178 = ptrtoint ptr %mem1177 to i64
  store i64 %ptr1178, ptr %slot35, align 8
  %v1179 = load i64, ptr %slot1, align 8
  %op1180 = add i64 %v1179, 64
  store i64 %op1180, ptr %slot36, align 8
  %v1181 = load i64, ptr %slot36, align 8
  %p1182 = inttoptr i64 %v1181 to ptr
  %ld1183 = load i64, ptr %p1182, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1183, ptr %slot37, align 8
  %stack1184 = call ptr @llvm.stacksave()
  %stackaddr1185 = ptrtoint ptr %stack1184 to i64
  %v1186 = load i64, ptr %slot37, align 8
  %cmp1187 = icmp ult i64 %stackaddr1185, %v1186
  %cv1188 = zext i1 %cmp1187 to i64
  store i64 %cv1188, ptr %slot38, align 8
  %v1189 = load i64, ptr %slot38, align 8
  %cond1190 = icmp ne i64 %v1189, 0
  br i1 %cond1190, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v1191 = load i64, ptr %slot1, align 8
  %p1192 = inttoptr i64 %v1191 to ptr
  call void @myl_qbe_fail_frame(ptr %p1192) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v1193 = load i64, ptr %slot27, align 8
  %p1194 = inttoptr i64 %v1193 to ptr
  store i64 0, ptr %p1194, align 8, !alias.scope !3, !noalias !4
  %v1195 = load i64, ptr %slot28, align 8
  %p1196 = inttoptr i64 %v1195 to ptr
  store i64 0, ptr %p1196, align 8, !alias.scope !3, !noalias !4
  %v1197 = load i64, ptr %slot30, align 8
  %p1198 = inttoptr i64 %v1197 to ptr
  store i64 0, ptr %p1198, align 8, !alias.scope !3, !noalias !4
  %v1199 = load i64, ptr %slot2, align 8
  %v1200 = load i64, ptr %slot25, align 8
  %p1201 = inttoptr i64 %v1200 to ptr
  store i64 %v1199, ptr %p1201, align 8, !alias.scope !3, !noalias !4
  %v1202 = load i64, ptr %slot1, align 8
  %p1203 = inttoptr i64 %v1202 to ptr
  %call1204 = call ptr @myl_qbe_heap(ptr %p1203) nomerge, !dbg !112
  %calladdr1205 = ptrtoint ptr %call1204 to i64
  store i64 %calladdr1205, ptr %slot39, align 8
  %v1206 = load i64, ptr %slot1, align 8
  %p1207 = inttoptr i64 %v1206 to ptr
  %call1208 = call i64 @myl_qbe_region_mark(ptr %p1207) nomerge, !dbg !112
  store i64 %call1208, ptr %slot40, align 8
  %v1209 = load i64, ptr %slot4, align 8
  %p1210 = inttoptr i64 %v1209 to ptr
  store i32 0, ptr %p1210, align 4, !alias.scope !3, !noalias !4
  %v1211 = load i64, ptr %slot5, align 8
  %p1212 = inttoptr i64 %v1211 to ptr
  store i32 0, ptr %p1212, align 4, !alias.scope !3, !noalias !4
  %v1213 = load i64, ptr %slot6, align 8
  %p1214 = inttoptr i64 %v1213 to ptr
  store i32 0, ptr %p1214, align 4, !alias.scope !3, !noalias !4
  %v1215 = load i64, ptr %slot7, align 8
  %p1216 = inttoptr i64 %v1215 to ptr
  store i32 0, ptr %p1216, align 4, !alias.scope !3, !noalias !4
  %v1217 = load i64, ptr %slot8, align 8
  %p1218 = inttoptr i64 %v1217 to ptr
  store i32 0, ptr %p1218, align 4, !alias.scope !3, !noalias !4
  %v1219 = load i64, ptr %slot9, align 8
  %p1220 = inttoptr i64 %v1219 to ptr
  store i32 0, ptr %p1220, align 4, !alias.scope !3, !noalias !4
  %v1221 = load i64, ptr %slot10, align 8
  %p1222 = inttoptr i64 %v1221 to ptr
  store i32 0, ptr %p1222, align 4, !alias.scope !3, !noalias !4
  %v1223 = load i64, ptr %slot11, align 8
  %p1224 = inttoptr i64 %v1223 to ptr
  store i32 0, ptr %p1224, align 4, !alias.scope !3, !noalias !4
  %v1225 = load i64, ptr %slot12, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  store i32 0, ptr %p1226, align 4, !alias.scope !3, !noalias !4
  %v1227 = load i64, ptr %slot13, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  store i32 0, ptr %p1228, align 4, !alias.scope !3, !noalias !4
  %v1229 = load i64, ptr %slot14, align 8
  %p1230 = inttoptr i64 %v1229 to ptr
  store i32 0, ptr %p1230, align 4, !alias.scope !3, !noalias !4
  %v1231 = load i64, ptr %slot15, align 8
  %p1232 = inttoptr i64 %v1231 to ptr
  store i32 0, ptr %p1232, align 4, !alias.scope !3, !noalias !4
  %v1233 = load i64, ptr %slot16, align 8
  %p1234 = inttoptr i64 %v1233 to ptr
  store i32 0, ptr %p1234, align 4, !alias.scope !3, !noalias !4
  %v1235 = load i64, ptr %slot17, align 8
  %p1236 = inttoptr i64 %v1235 to ptr
  store i32 0, ptr %p1236, align 4, !alias.scope !3, !noalias !4
  %v1237 = load i64, ptr %slot18, align 8
  %p1238 = inttoptr i64 %v1237 to ptr
  store i32 0, ptr %p1238, align 4, !alias.scope !3, !noalias !4
  %v1239 = load i64, ptr %slot19, align 8
  %p1240 = inttoptr i64 %v1239 to ptr
  store i32 0, ptr %p1240, align 4, !alias.scope !3, !noalias !4
  %v1241 = load i64, ptr %slot5, align 8
  %p1242 = inttoptr i64 %v1241 to ptr
  store i32 2, ptr %p1242, align 4, !alias.scope !3, !noalias !4
  %v1243 = load i64, ptr %slot7, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  store i32 2, ptr %p1244, align 4, !alias.scope !3, !noalias !4
  %v1245 = load i64, ptr %slot9, align 8
  %p1246 = inttoptr i64 %v1245 to ptr
  store i32 2, ptr %p1246, align 4, !alias.scope !3, !noalias !4
  %v1247 = load i64, ptr %slot11, align 8
  %p1248 = inttoptr i64 %v1247 to ptr
  store i32 2, ptr %p1248, align 4, !alias.scope !3, !noalias !4
  %v1249 = load i64, ptr %slot13, align 8
  %p1250 = inttoptr i64 %v1249 to ptr
  store i32 2, ptr %p1250, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1251 = load i64, ptr %slot25, align 8
  %p1252 = inttoptr i64 %v1251 to ptr
  %ld1253 = load i64, ptr %p1252, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1253, ptr %slot41, align 8
  %v1254 = load i64, ptr %slot41, align 8
  %v1255 = load i64, ptr %slot33, align 8
  %p1256 = inttoptr i64 %v1255 to ptr
  store i64 %v1254, ptr %p1256, align 8, !alias.scope !3, !noalias !4
  %v1257 = load i64, ptr %slot33, align 8
  %p1258 = inttoptr i64 %v1257 to ptr
  %ld1259 = load i64, ptr %p1258, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1259, ptr %slot42, align 8
  %v1260 = load i64, ptr %slot1, align 8
  %v1261 = load i64, ptr %slot42, align 8
  call void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8 %callresult44, i64 %v1260, i64 %v1261) nomerge, !dbg !114
  %addr1262 = ptrtoint ptr %callresult44 to i64
  store i64 %addr1262, ptr %slot43, align 8
  %v1263 = load i64, ptr %slot43, align 8
  %v1264 = load i64, ptr %slot33, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  store i64 %v1263, ptr %p1265, align 8, !alias.scope !3, !noalias !4
  %v1266 = load i64, ptr %slot33, align 8
  %p1267 = inttoptr i64 %v1266 to ptr
  %ld1268 = load i64, ptr %p1267, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1268, ptr %slot45, align 8
  %v1269 = load i64, ptr %slot24, align 8
  store i64 %v1269, ptr %slot46, align 8
  %v1270 = load i64, ptr %slot45, align 8
  %v1271 = load i64, ptr %slot46, align 8
  %p1272 = inttoptr i64 %v1270 to ptr
  %p1273 = inttoptr i64 %v1271 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1273, ptr %p1272, i64 88, i1 false)
  %v1274 = load i64, ptr %slot19, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  store i32 2, ptr %p1275, align 4, !alias.scope !3, !noalias !4
  %v1276 = load i64, ptr %slot18, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  store i32 1, ptr %p1277, align 4, !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot14, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  %ld1280 = load i32, ptr %p1279, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1280, ptr %slot47, align 8
  %v1281 = load i32, ptr %slot47, align 8
  %cv1282 = zext i32 %v1281 to i64
  %cond1283 = icmp ne i64 %cv1282, 0
  br i1 %cond1283, label %bb_rcslotdrop22, label %bb_rcslotdone22
bb_rcslotdrop22:
  %v1284 = load i64, ptr %slot14, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  store i32 0, ptr %p1285, align 4, !alias.scope !3, !noalias !4
  %v1286 = load i64, ptr %slot20, align 8
  store i64 %v1286, ptr %slot48, align 8
  %v1287 = load i64, ptr %slot15, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  %ld1289 = load i32, ptr %p1288, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1289, ptr %slot49, align 8
  %v1290 = load i32, ptr %slot49, align 8
  %op1291 = and i32 %v1290, 28
  store i32 %op1291, ptr %slot50, align 8
  %v1292 = load i32, ptr %slot50, align 8
  %cv1293 = zext i32 %v1292 to i64
  %cond1294 = icmp ne i64 %cv1293, 0
  br i1 %cond1294, label %bb_rcslotrole22, label %bb_rcslotowner22
bb_rcslotrole22:
  %v1295 = load i64, ptr %slot39, align 8
  store i64 %v1295, ptr %slot51, align 8
  %v1296 = load i64, ptr %slot51, align 8
  %v1297 = load i64, ptr %slot48, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1296, i64 %v1297) nomerge, !dbg !114
  br label %bb_rcslotdone22
bb_rcslotowner22:
  %v1298 = load i64, ptr %slot39, align 8
  store i64 %v1298, ptr %slot52, align 8
  %v1299 = load i64, ptr %slot52, align 8
  %v1300 = load i64, ptr %slot48, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1299, i64 %v1300) nomerge, !dbg !114
  br label %bb_rcslotdone22
bb_rcslotdone22:
  %v1301 = load i64, ptr %slot20, align 8
  store i64 %v1301, ptr %slot53, align 8
  %v1302 = load i64, ptr %slot24, align 8
  store i64 %v1302, ptr %slot54, align 8
  %v1303 = load i64, ptr %slot54, align 8
  %v1304 = load i64, ptr %slot53, align 8
  %p1305 = inttoptr i64 %v1303 to ptr
  %p1306 = inttoptr i64 %v1304 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1306, ptr %p1305, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1307 = load i64, ptr %slot15, align 8
  %p1308 = inttoptr i64 %v1307 to ptr
  store i32 2, ptr %p1308, align 4, !alias.scope !3, !noalias !4
  %v1309 = load i64, ptr %slot19, align 8
  %p1310 = inttoptr i64 %v1309 to ptr
  %ld1311 = load i32, ptr %p1310, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1311, ptr %slot55, align 8
  %v1312 = load i32, ptr %slot55, align 8
  %v1313 = load i64, ptr %slot15, align 8
  %p1314 = inttoptr i64 %v1313 to ptr
  store i32 %v1312, ptr %p1314, align 4, !alias.scope !3, !noalias !4
  %v1315 = load i64, ptr %slot18, align 8
  %p1316 = inttoptr i64 %v1315 to ptr
  store i32 0, ptr %p1316, align 4, !alias.scope !3, !noalias !4
  %v1317 = load i64, ptr %slot14, align 8
  %p1318 = inttoptr i64 %v1317 to ptr
  store i32 1, ptr %p1318, align 4, !alias.scope !3, !noalias !4
  %v1319 = load i64, ptr %slot53, align 8
  %v1320 = load i64, ptr %slot33, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i64 %v1319, ptr %p1321, align 8, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot33, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  %ld1324 = load i64, ptr %p1323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1324, ptr %slot56, align 8
  %v1325 = load i64, ptr %slot24, align 8
  store i64 %v1325, ptr %slot57, align 8
  %v1326 = load i64, ptr %slot40, align 8
  store i64 %v1326, ptr %slot58, align 8
  %v1327 = load i64, ptr %slot39, align 8
  %v1328 = load i64, ptr %slot57, align 8
  %v1329 = load i64, ptr %slot56, align 8
  %v1330 = load i64, ptr %slot58, align 8
  %cv1331 = trunc i64 %v1330 to i32
  %call1332 = call i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64 %v1327, i64 %v1328, i64 %v1329, i32 %cv1331) nomerge, !dbg !116
  store i32 %call1332, ptr %slot59, align 8
  %v1333 = load i32, ptr %slot59, align 8
  %cv1334 = zext i32 %v1333 to i64
  %cond1335 = icmp ne i64 %cv1334, 0
  br i1 %cond1335, label %bb_rcsuccess41, label %bb_rcfailure41
bb_rcfailure41:
  %v1336 = load i64, ptr %slot39, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  %call1338 = call i32 @myl_rc_take_failure(ptr %p1337) nomerge, !dbg !116
  store i32 %call1338, ptr %slot60, align 8
  %v1339 = load i64, ptr %slot1, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  %v1341 = load i32, ptr %slot60, align 8
  %call1342 = call i32 @myl_qbe_rc_status(ptr %p1340, i32 %v1341) nomerge, !dbg !116
  store i32 %call1342, ptr %slot61, align 8
  br label %bb_failure
bb_rcsuccess41:
  %v1343 = load i64, ptr %slot14, align 8
  %p1344 = inttoptr i64 %v1343 to ptr
  store i32 0, ptr %p1344, align 4, !alias.scope !3, !noalias !4
  %v1345 = load i64, ptr %slot19, align 8
  %p1346 = inttoptr i64 %v1345 to ptr
  store i32 2, ptr %p1346, align 4, !alias.scope !3, !noalias !4
  %v1347 = load i64, ptr %slot18, align 8
  %p1348 = inttoptr i64 %v1347 to ptr
  store i32 1, ptr %p1348, align 4, !alias.scope !3, !noalias !4
  %v1349 = load i64, ptr %slot4, align 8
  %p1350 = inttoptr i64 %v1349 to ptr
  %ld1351 = load i32, ptr %p1350, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1351, ptr %slot62, align 8
  %v1352 = load i32, ptr %slot62, align 8
  %cv1353 = zext i32 %v1352 to i64
  %cond1354 = icmp ne i64 %cv1353, 0
  br i1 %cond1354, label %bb_rcslotdrop50, label %bb_rcslotdone50
bb_rcslotdrop50:
  %v1355 = load i64, ptr %slot4, align 8
  %p1356 = inttoptr i64 %v1355 to ptr
  store i32 0, ptr %p1356, align 4, !alias.scope !3, !noalias !4
  %v1357 = load i64, ptr %slot26, align 8
  store i64 %v1357, ptr %slot63, align 8
  %v1358 = load i64, ptr %slot5, align 8
  %p1359 = inttoptr i64 %v1358 to ptr
  %ld1360 = load i32, ptr %p1359, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1360, ptr %slot64, align 8
  %v1361 = load i32, ptr %slot64, align 8
  %op1362 = and i32 %v1361, 28
  store i32 %op1362, ptr %slot65, align 8
  %v1363 = load i32, ptr %slot65, align 8
  %cv1364 = zext i32 %v1363 to i64
  %cond1365 = icmp ne i64 %cv1364, 0
  br i1 %cond1365, label %bb_rcslotrole50, label %bb_rcslotowner50
bb_rcslotrole50:
  %v1366 = load i64, ptr %slot39, align 8
  store i64 %v1366, ptr %slot66, align 8
  %v1367 = load i64, ptr %slot66, align 8
  %v1368 = load i64, ptr %slot63, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1367, i64 %v1368) nomerge, !dbg !116
  br label %bb_rcslotdone50
bb_rcslotowner50:
  %v1369 = load i64, ptr %slot39, align 8
  store i64 %v1369, ptr %slot67, align 8
  %v1370 = load i64, ptr %slot67, align 8
  %v1371 = load i64, ptr %slot63, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1370, i64 %v1371) nomerge, !dbg !116
  br label %bb_rcslotdone50
bb_rcslotdone50:
  %v1372 = load i64, ptr %slot26, align 8
  store i64 %v1372, ptr %slot68, align 8
  %v1373 = load i64, ptr %slot24, align 8
  store i64 %v1373, ptr %slot69, align 8
  %v1374 = load i64, ptr %slot69, align 8
  %v1375 = load i64, ptr %slot68, align 8
  %p1376 = inttoptr i64 %v1374 to ptr
  %p1377 = inttoptr i64 %v1375 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1377, ptr %p1376, i64 88, i1 false), !alias.scope !3, !noalias !4
  %v1378 = load i64, ptr %slot18, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  store i32 0, ptr %p1379, align 4, !alias.scope !3, !noalias !4
  %v1380 = load i64, ptr %slot5, align 8
  %p1381 = inttoptr i64 %v1380 to ptr
  store i32 2, ptr %p1381, align 4, !alias.scope !3, !noalias !4
  %v1382 = load i64, ptr %slot19, align 8
  %p1383 = inttoptr i64 %v1382 to ptr
  %ld1384 = load i32, ptr %p1383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1384, ptr %slot70, align 8
  %v1385 = load i32, ptr %slot70, align 8
  %v1386 = load i64, ptr %slot5, align 8
  %p1387 = inttoptr i64 %v1386 to ptr
  store i32 %v1385, ptr %p1387, align 4, !alias.scope !3, !noalias !4
  %v1388 = load i64, ptr %slot4, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  store i32 1, ptr %p1389, align 4, !alias.scope !3, !noalias !4
  %v1390 = load i64, ptr %slot26, align 8
  %v1391 = load i64, ptr %slot33, align 8
  %p1392 = inttoptr i64 %v1391 to ptr
  store i64 %v1390, ptr %p1392, align 8, !alias.scope !3, !noalias !4
  %v1393 = load i64, ptr %slot33, align 8
  %p1394 = inttoptr i64 %v1393 to ptr
  %ld1395 = load i64, ptr %p1394, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1395, ptr %slot71, align 8
  %v1396 = load i64, ptr %slot71, align 8
  %op1397 = add i64 %v1396, 80
  store i64 %op1397, ptr %slot72, align 8
  %v1398 = load i64, ptr %slot72, align 8
  %p1399 = inttoptr i64 %v1398 to ptr
  %ld1400 = load i64, ptr %p1399, align 8
  store i64 %ld1400, ptr %slot73, align 8
  %v1401 = load i64, ptr %slot73, align 8
  %v1402 = load i64, ptr %slot33, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  store i64 %v1401, ptr %p1403, align 8, !alias.scope !3, !noalias !4
  %v1404 = load i64, ptr %slot14, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  %ld1406 = load i32, ptr %p1405, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1406, ptr %slot74, align 8
  %v1407 = load i32, ptr %slot74, align 8
  %cv1408 = zext i32 %v1407 to i64
  %cond1409 = icmp ne i64 %cv1408, 0
  br i1 %cond1409, label %bb_rcslotdrop69, label %bb_rcslotdone69
bb_rcslotdrop69:
  %v1410 = load i64, ptr %slot14, align 8
  %p1411 = inttoptr i64 %v1410 to ptr
  store i32 0, ptr %p1411, align 4, !alias.scope !3, !noalias !4
  %v1412 = load i64, ptr %slot20, align 8
  store i64 %v1412, ptr %slot75, align 8
  %v1413 = load i64, ptr %slot15, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  %ld1415 = load i32, ptr %p1414, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1415, ptr %slot76, align 8
  %v1416 = load i32, ptr %slot76, align 8
  %op1417 = and i32 %v1416, 28
  store i32 %op1417, ptr %slot77, align 8
  %v1418 = load i32, ptr %slot77, align 8
  %cv1419 = zext i32 %v1418 to i64
  %cond1420 = icmp ne i64 %cv1419, 0
  br i1 %cond1420, label %bb_rcslotrole69, label %bb_rcslotowner69
bb_rcslotrole69:
  %v1421 = load i64, ptr %slot39, align 8
  store i64 %v1421, ptr %slot78, align 8
  %v1422 = load i64, ptr %slot78, align 8
  %v1423 = load i64, ptr %slot75, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1422, i64 %v1423) nomerge, !dbg !118
  br label %bb_rcslotdone69
bb_rcslotowner69:
  %v1424 = load i64, ptr %slot39, align 8
  store i64 %v1424, ptr %slot79, align 8
  %v1425 = load i64, ptr %slot79, align 8
  %v1426 = load i64, ptr %slot75, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1425, i64 %v1426) nomerge, !dbg !118
  br label %bb_rcslotdone69
bb_rcslotdone69:
  %v1427 = load i64, ptr %slot34, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i64 0, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot34, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot80, align 8
  %v1432 = load i64, ptr %slot33, align 8
  %p1433 = inttoptr i64 %v1432 to ptr
  %ld1434 = load i64, ptr %p1433, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1434, ptr %slot81, align 8
  %v1435 = load i64, ptr %slot81, align 8
  %v1436 = load i64, ptr %slot80, align 8
  %cmp1437 = icmp eq i64 %v1435, %v1436
  %cv1438 = zext i1 %cmp1437 to i64
  store i64 %cv1438, ptr %slot82, align 8
  %v1439 = load i64, ptr %slot82, align 8
  %v1440 = load i64, ptr %slot33, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  store i64 %v1439, ptr %p1441, align 8, !alias.scope !3, !noalias !4
  %v1442 = load i64, ptr %slot33, align 8
  %p1443 = inttoptr i64 %v1442 to ptr
  %ld1444 = load i64, ptr %p1443, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1444, ptr %slot83, align 8
  %v1445 = load i64, ptr %slot83, align 8
  %cond1446 = icmp ne i64 %v1445, 0
  br i1 %cond1446, label %bb_next80, label %bb_i10
bb_next80:
  %v1447 = load i64, ptr %slot33, align 8
  %p1448 = inttoptr i64 %v1447 to ptr
  store i64 0, ptr %p1448, align 8, !alias.scope !3, !noalias !4
  %v1449 = load i64, ptr %slot33, align 8
  %p1450 = inttoptr i64 %v1449 to ptr
  %ld1451 = load i64, ptr %p1450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1451, ptr %slot84, align 8
  %v1452 = load i64, ptr %slot14, align 8
  %p1453 = inttoptr i64 %v1452 to ptr
  %ld1454 = load i32, ptr %p1453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1454, ptr %slot85, align 8
  %v1455 = load i32, ptr %slot85, align 8
  %cv1456 = zext i32 %v1455 to i64
  %cond1457 = icmp ne i64 %cv1456, 0
  br i1 %cond1457, label %bb_rcslotdrop83, label %bb_rcslotdone83
bb_rcslotdrop83:
  %v1458 = load i64, ptr %slot14, align 8
  %p1459 = inttoptr i64 %v1458 to ptr
  store i32 0, ptr %p1459, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone83
bb_rcslotdone83:
  %v1460 = load i64, ptr %slot12, align 8
  %p1461 = inttoptr i64 %v1460 to ptr
  %ld1462 = load i32, ptr %p1461, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1462, ptr %slot86, align 8
  %v1463 = load i32, ptr %slot86, align 8
  %cv1464 = zext i32 %v1463 to i64
  %cond1465 = icmp ne i64 %cv1464, 0
  br i1 %cond1465, label %bb_rcslotdrop86, label %bb_rcslotdone86
bb_rcslotdrop86:
  %v1466 = load i64, ptr %slot12, align 8
  %p1467 = inttoptr i64 %v1466 to ptr
  store i32 0, ptr %p1467, align 4, !alias.scope !3, !noalias !4
  %v1468 = load i64, ptr %slot32, align 8
  store i64 %v1468, ptr %slot87, align 8
  %v1469 = load i64, ptr %slot13, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  %ld1471 = load i32, ptr %p1470, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1471, ptr %slot88, align 8
  %v1472 = load i32, ptr %slot88, align 8
  %op1473 = and i32 %v1472, 28
  store i32 %op1473, ptr %slot89, align 8
  %v1474 = load i32, ptr %slot89, align 8
  %cv1475 = zext i32 %v1474 to i64
  %cond1476 = icmp ne i64 %cv1475, 0
  br i1 %cond1476, label %bb_rcslotrole86, label %bb_rcslotowner86
bb_rcslotrole86:
  %v1477 = load i64, ptr %slot39, align 8
  store i64 %v1477, ptr %slot90, align 8
  %v1478 = load i64, ptr %slot90, align 8
  %v1479 = load i64, ptr %slot87, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v1478, i64 %v1479) nomerge, !dbg !120
  br label %bb_rcslotdone86
bb_rcslotowner86:
  %v1480 = load i64, ptr %slot39, align 8
  store i64 %v1480, ptr %slot91, align 8
  %v1481 = load i64, ptr %slot91, align 8
  %v1482 = load i64, ptr %slot87, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v1481, i64 %v1482) nomerge, !dbg !120
  br label %bb_rcslotdone86
bb_rcslotdone86:
  %v1483 = load i64, ptr %slot10, align 8
  %p1484 = inttoptr i64 %v1483 to ptr
  %ld1485 = load i32, ptr %p1484, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1485, ptr %slot92, align 8
  %v1486 = load i32, ptr %slot92, align 8
  %cv1487 = zext i32 %v1486 to i64
  %cond1488 = icmp ne i64 %cv1487, 0
  br i1 %cond1488, label %bb_rcslotdrop95, label %bb_rcslotdone95
bb_rcslotdrop95:
  %v1489 = load i64, ptr %slot10, align 8
  %p1490 = inttoptr i64 %v1489 to ptr
  store i32 0, ptr %p1490, align 4, !alias.scope !3, !noalias !4
  %v1491 = load i64, ptr %slot30, align 8
  store i64 %v1491, ptr %slot93, align 8
  %v1492 = load i64, ptr %slot11, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  %ld1494 = load i32, ptr %p1493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1494, ptr %slot94, align 8
  %v1495 = load i32, ptr %slot94, align 8
  %op1496 = and i32 %v1495, 28
  store i32 %op1496, ptr %slot95, align 8
  %v1497 = load i32, ptr %slot95, align 8
  %cv1498 = zext i32 %v1497 to i64
  %cond1499 = icmp ne i64 %cv1498, 0
  br i1 %cond1499, label %bb_rcslotrole95, label %bb_rcslotowner95
bb_rcslotrole95:
  %v1500 = load i64, ptr %slot39, align 8
  store i64 %v1500, ptr %slot96, align 8
  %v1501 = load i64, ptr %slot93, align 8
  %p1502 = inttoptr i64 %v1501 to ptr
  %ld1503 = load i64, ptr %p1502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1503, ptr %slot97, align 8
  %v1504 = load i64, ptr %slot97, align 8
  %cmp1505 = icmp ne i64 %v1504, 0
  %cv1506 = zext i1 %cmp1505 to i32
  store i32 %cv1506, ptr %slot98, align 8
  %v1507 = load i32, ptr %slot98, align 8
  %cv1508 = zext i32 %v1507 to i64
  %cond1509 = icmp ne i64 %cv1508, 0
  br i1 %cond1509, label %bb_rcgnn111, label %bb_rcgdone111
bb_rcgnn111:
  %v1510 = load i64, ptr %slot97, align 8
  %op1511 = sub i64 %v1510, 16
  store i64 %op1511, ptr %slot99, align 8
  %v1512 = load i64, ptr %slot97, align 8
  %p1513 = inttoptr i64 %v1512 to ptr
  %rgep1514 = getelementptr i8, ptr %p1513, i64 -16
  %ld1515 = load i64, ptr %rgep1514, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1515, ptr %slot100, align 8
  %v1516 = load i64, ptr %slot100, align 8
  %op1517 = and i64 %v1516, 4611686018427387906
  store i64 %op1517, ptr %slot101, align 8
  %v1518 = load i64, ptr %slot101, align 8
  %cmp1519 = icmp ne i64 %v1518, 0
  %cv1520 = zext i1 %cmp1519 to i32
  store i32 %cv1520, ptr %slot102, align 8
  %v1521 = load i32, ptr %slot102, align 8
  %cv1522 = zext i32 %v1521 to i64
  %cond1523 = icmp ne i64 %cv1522, 0
  br i1 %cond1523, label %bb_rcgclear111, label %bb_rcgcounted111
bb_rcgcounted111:
  %v1524 = load i64, ptr %slot97, align 8
  %op1525 = sub i64 %v1524, 24
  store i64 %op1525, ptr %slot103, align 8
  %v1526 = load i64, ptr %slot97, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  %rgep1528 = getelementptr i8, ptr %p1527, i64 -24
  %ld1529 = load i64, ptr %rgep1528, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1529, ptr %slot104, align 8
  %v1530 = load i64, ptr %slot104, align 8
  %op1531 = sub i64 %v1530, 1
  store i64 %op1531, ptr %slot105, align 8
  %v1532 = load i64, ptr %slot105, align 8
  %cmp1533 = icmp eq i64 %v1532, 0
  %cv1534 = zext i1 %cmp1533 to i32
  store i32 %cv1534, ptr %slot106, align 8
  %v1535 = load i32, ptr %slot106, align 8
  %cv1536 = zext i32 %v1535 to i64
  %cond1537 = icmp ne i64 %cv1536, 0
  br i1 %cond1537, label %bb_rcglast111, label %bb_rcgdec111
bb_rcglast111:
  %v1538 = load i64, ptr %slot97, align 8
  %op1539 = sub i64 %v1538, 32
  store i64 %op1539, ptr %slot107, align 8
  %v1540 = load i64, ptr %slot97, align 8
  %p1541 = inttoptr i64 %v1540 to ptr
  %rgep1542 = getelementptr i8, ptr %p1541, i64 -32
  %ld1543 = load i64, ptr %rgep1542, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1543, ptr %slot108, align 8
  %v1544 = load i64, ptr %slot108, align 8
  %cmp1545 = icmp ne i64 %v1544, 0
  %cv1546 = zext i1 %cmp1545 to i32
  store i32 %cv1546, ptr %slot109, align 8
  %v1547 = load i32, ptr %slot109, align 8
  %cv1548 = zext i32 %v1547 to i64
  %cond1549 = icmp ne i64 %cv1548, 0
  br i1 %cond1549, label %bb_rcgdec111, label %bb_rcgslow111
bb_rcgslow111:
  %v1550 = load i64, ptr %slot96, align 8
  %v1551 = load i64, ptr %slot93, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v1550, i64 %v1551) nomerge, !dbg !120
  br label %bb_rcgdone111
bb_rcgdec111:
  %v1552 = load i64, ptr %slot105, align 8
  %v1553 = load i64, ptr %slot97, align 8
  %p1554 = inttoptr i64 %v1553 to ptr
  %rgep1555 = getelementptr i8, ptr %p1554, i64 -24
  store i64 %v1552, ptr %rgep1555, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear111
bb_rcgclear111:
  %v1556 = load i64, ptr %slot93, align 8
  %p1557 = inttoptr i64 %v1556 to ptr
  store i64 0, ptr %p1557, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone111
bb_rcgdone111:
  br label %bb_rcslotdone95
bb_rcslotowner95:
  %v1558 = load i64, ptr %slot39, align 8
  store i64 %v1558, ptr %slot110, align 8
  %v1559 = load i64, ptr %slot93, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %ld1561 = load i64, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1561, ptr %slot111, align 8
  %v1562 = load i64, ptr %slot111, align 8
  %cmp1563 = icmp ne i64 %v1562, 0
  %cv1564 = zext i1 %cmp1563 to i32
  store i32 %cv1564, ptr %slot112, align 8
  %v1565 = load i32, ptr %slot112, align 8
  %cv1566 = zext i32 %v1565 to i64
  %cond1567 = icmp ne i64 %cv1566, 0
  br i1 %cond1567, label %bb_rcgnn126, label %bb_rcgdone126
bb_rcgnn126:
  %v1568 = load i64, ptr %slot111, align 8
  %op1569 = sub i64 %v1568, 16
  store i64 %op1569, ptr %slot113, align 8
  %v1570 = load i64, ptr %slot111, align 8
  %p1571 = inttoptr i64 %v1570 to ptr
  %rgep1572 = getelementptr i8, ptr %p1571, i64 -16
  %ld1573 = load i64, ptr %rgep1572, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1573, ptr %slot114, align 8
  %v1574 = load i64, ptr %slot114, align 8
  %op1575 = and i64 %v1574, 4611686018427387906
  store i64 %op1575, ptr %slot115, align 8
  %v1576 = load i64, ptr %slot115, align 8
  %cmp1577 = icmp ne i64 %v1576, 0
  %cv1578 = zext i1 %cmp1577 to i32
  store i32 %cv1578, ptr %slot116, align 8
  %v1579 = load i32, ptr %slot116, align 8
  %cv1580 = zext i32 %v1579 to i64
  %cond1581 = icmp ne i64 %cv1580, 0
  br i1 %cond1581, label %bb_rcgclear126, label %bb_rcgcounted126
bb_rcgcounted126:
  %v1582 = load i64, ptr %slot111, align 8
  %op1583 = sub i64 %v1582, 32
  store i64 %op1583, ptr %slot117, align 8
  %v1584 = load i64, ptr %slot111, align 8
  %p1585 = inttoptr i64 %v1584 to ptr
  %rgep1586 = getelementptr i8, ptr %p1585, i64 -32
  %ld1587 = load i64, ptr %rgep1586, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1587, ptr %slot118, align 8
  %v1588 = load i64, ptr %slot118, align 8
  %op1589 = sub i64 %v1588, 1
  store i64 %op1589, ptr %slot119, align 8
  %v1590 = load i64, ptr %slot119, align 8
  %cmp1591 = icmp eq i64 %v1590, 0
  %cv1592 = zext i1 %cmp1591 to i32
  store i32 %cv1592, ptr %slot120, align 8
  %v1593 = load i32, ptr %slot120, align 8
  %cv1594 = zext i32 %v1593 to i64
  %cond1595 = icmp ne i64 %cv1594, 0
  br i1 %cond1595, label %bb_rcglast126, label %bb_rcgdec126
bb_rcglast126:
  %v1596 = load i64, ptr %slot111, align 8
  %op1597 = sub i64 %v1596, 24
  store i64 %op1597, ptr %slot121, align 8
  %v1598 = load i64, ptr %slot111, align 8
  %p1599 = inttoptr i64 %v1598 to ptr
  %rgep1600 = getelementptr i8, ptr %p1599, i64 -24
  %ld1601 = load i64, ptr %rgep1600, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1601, ptr %slot122, align 8
  %v1602 = load i64, ptr %slot122, align 8
  %cmp1603 = icmp ne i64 %v1602, 0
  %cv1604 = zext i1 %cmp1603 to i32
  store i32 %cv1604, ptr %slot123, align 8
  %v1605 = load i32, ptr %slot123, align 8
  %cv1606 = zext i32 %v1605 to i64
  %cond1607 = icmp ne i64 %cv1606, 0
  br i1 %cond1607, label %bb_rcgdec126, label %bb_rcgslow126
bb_rcgslow126:
  %v1608 = load i64, ptr %slot110, align 8
  %v1609 = load i64, ptr %slot93, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v1608, i64 %v1609) nomerge, !dbg !120
  br label %bb_rcgdone126
bb_rcgdec126:
  %v1610 = load i64, ptr %slot119, align 8
  %v1611 = load i64, ptr %slot111, align 8
  %p1612 = inttoptr i64 %v1611 to ptr
  %rgep1613 = getelementptr i8, ptr %p1612, i64 -32
  store i64 %v1610, ptr %rgep1613, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear126
bb_rcgclear126:
  %v1614 = load i64, ptr %slot93, align 8
  %p1615 = inttoptr i64 %v1614 to ptr
  store i64 0, ptr %p1615, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone126
bb_rcgdone126:
  br label %bb_rcslotdone95
bb_rcslotdone95:
  %v1616 = load i64, ptr %slot8, align 8
  %p1617 = inttoptr i64 %v1616 to ptr
  %ld1618 = load i32, ptr %p1617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1618, ptr %slot124, align 8
  %v1619 = load i32, ptr %slot124, align 8
  %cv1620 = zext i32 %v1619 to i64
  %cond1621 = icmp ne i64 %cv1620, 0
  br i1 %cond1621, label %bb_rcslotdrop132, label %bb_rcslotdone132
bb_rcslotdrop132:
  %v1622 = load i64, ptr %slot8, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 0, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot28, align 8
  store i64 %v1624, ptr %slot125, align 8
  %v1625 = load i64, ptr %slot9, align 8
  %p1626 = inttoptr i64 %v1625 to ptr
  %ld1627 = load i32, ptr %p1626, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1627, ptr %slot126, align 8
  %v1628 = load i32, ptr %slot126, align 8
  %op1629 = and i32 %v1628, 28
  store i32 %op1629, ptr %slot127, align 8
  %v1630 = load i32, ptr %slot127, align 8
  %cv1631 = zext i32 %v1630 to i64
  %cond1632 = icmp ne i64 %cv1631, 0
  br i1 %cond1632, label %bb_rcslotrole132, label %bb_rcslotowner132
bb_rcslotrole132:
  %v1633 = load i64, ptr %slot39, align 8
  store i64 %v1633, ptr %slot128, align 8
  %v1634 = load i64, ptr %slot125, align 8
  %p1635 = inttoptr i64 %v1634 to ptr
  %ld1636 = load i64, ptr %p1635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1636, ptr %slot129, align 8
  %v1637 = load i64, ptr %slot129, align 8
  %cmp1638 = icmp ne i64 %v1637, 0
  %cv1639 = zext i1 %cmp1638 to i32
  store i32 %cv1639, ptr %slot130, align 8
  %v1640 = load i32, ptr %slot130, align 8
  %cv1641 = zext i32 %v1640 to i64
  %cond1642 = icmp ne i64 %cv1641, 0
  br i1 %cond1642, label %bb_rcgnn148, label %bb_rcgdone148
bb_rcgnn148:
  %v1643 = load i64, ptr %slot129, align 8
  %op1644 = sub i64 %v1643, 16
  store i64 %op1644, ptr %slot131, align 8
  %v1645 = load i64, ptr %slot129, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  %rgep1647 = getelementptr i8, ptr %p1646, i64 -16
  %ld1648 = load i64, ptr %rgep1647, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1648, ptr %slot132, align 8
  %v1649 = load i64, ptr %slot132, align 8
  %op1650 = and i64 %v1649, 4611686018427387906
  store i64 %op1650, ptr %slot133, align 8
  %v1651 = load i64, ptr %slot133, align 8
  %cmp1652 = icmp ne i64 %v1651, 0
  %cv1653 = zext i1 %cmp1652 to i32
  store i32 %cv1653, ptr %slot134, align 8
  %v1654 = load i32, ptr %slot134, align 8
  %cv1655 = zext i32 %v1654 to i64
  %cond1656 = icmp ne i64 %cv1655, 0
  br i1 %cond1656, label %bb_rcgclear148, label %bb_rcgcounted148
bb_rcgcounted148:
  %v1657 = load i64, ptr %slot129, align 8
  %op1658 = sub i64 %v1657, 24
  store i64 %op1658, ptr %slot135, align 8
  %v1659 = load i64, ptr %slot129, align 8
  %p1660 = inttoptr i64 %v1659 to ptr
  %rgep1661 = getelementptr i8, ptr %p1660, i64 -24
  %ld1662 = load i64, ptr %rgep1661, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1662, ptr %slot136, align 8
  %v1663 = load i64, ptr %slot136, align 8
  %op1664 = sub i64 %v1663, 1
  store i64 %op1664, ptr %slot137, align 8
  %v1665 = load i64, ptr %slot137, align 8
  %cmp1666 = icmp eq i64 %v1665, 0
  %cv1667 = zext i1 %cmp1666 to i32
  store i32 %cv1667, ptr %slot138, align 8
  %v1668 = load i32, ptr %slot138, align 8
  %cv1669 = zext i32 %v1668 to i64
  %cond1670 = icmp ne i64 %cv1669, 0
  br i1 %cond1670, label %bb_rcglast148, label %bb_rcgdec148
bb_rcglast148:
  %v1671 = load i64, ptr %slot129, align 8
  %op1672 = sub i64 %v1671, 32
  store i64 %op1672, ptr %slot139, align 8
  %v1673 = load i64, ptr %slot129, align 8
  %p1674 = inttoptr i64 %v1673 to ptr
  %rgep1675 = getelementptr i8, ptr %p1674, i64 -32
  %ld1676 = load i64, ptr %rgep1675, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1676, ptr %slot140, align 8
  %v1677 = load i64, ptr %slot140, align 8
  %cmp1678 = icmp ne i64 %v1677, 0
  %cv1679 = zext i1 %cmp1678 to i32
  store i32 %cv1679, ptr %slot141, align 8
  %v1680 = load i32, ptr %slot141, align 8
  %cv1681 = zext i32 %v1680 to i64
  %cond1682 = icmp ne i64 %cv1681, 0
  br i1 %cond1682, label %bb_rcgdec148, label %bb_rcgslow148
bb_rcgslow148:
  %v1683 = load i64, ptr %slot128, align 8
  %v1684 = load i64, ptr %slot125, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v1683, i64 %v1684) nomerge, !dbg !120
  br label %bb_rcgdone148
bb_rcgdec148:
  %v1685 = load i64, ptr %slot137, align 8
  %v1686 = load i64, ptr %slot129, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  %rgep1688 = getelementptr i8, ptr %p1687, i64 -24
  store i64 %v1685, ptr %rgep1688, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear148
bb_rcgclear148:
  %v1689 = load i64, ptr %slot125, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i64 0, ptr %p1690, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone148
bb_rcgdone148:
  br label %bb_rcslotdone132
bb_rcslotowner132:
  %v1691 = load i64, ptr %slot39, align 8
  store i64 %v1691, ptr %slot142, align 8
  %v1692 = load i64, ptr %slot125, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  %ld1694 = load i64, ptr %p1693, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1694, ptr %slot143, align 8
  %v1695 = load i64, ptr %slot143, align 8
  %cmp1696 = icmp ne i64 %v1695, 0
  %cv1697 = zext i1 %cmp1696 to i32
  store i32 %cv1697, ptr %slot144, align 8
  %v1698 = load i32, ptr %slot144, align 8
  %cv1699 = zext i32 %v1698 to i64
  %cond1700 = icmp ne i64 %cv1699, 0
  br i1 %cond1700, label %bb_rcgnn163, label %bb_rcgdone163
bb_rcgnn163:
  %v1701 = load i64, ptr %slot143, align 8
  %op1702 = sub i64 %v1701, 16
  store i64 %op1702, ptr %slot145, align 8
  %v1703 = load i64, ptr %slot143, align 8
  %p1704 = inttoptr i64 %v1703 to ptr
  %rgep1705 = getelementptr i8, ptr %p1704, i64 -16
  %ld1706 = load i64, ptr %rgep1705, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1706, ptr %slot146, align 8
  %v1707 = load i64, ptr %slot146, align 8
  %op1708 = and i64 %v1707, 4611686018427387906
  store i64 %op1708, ptr %slot147, align 8
  %v1709 = load i64, ptr %slot147, align 8
  %cmp1710 = icmp ne i64 %v1709, 0
  %cv1711 = zext i1 %cmp1710 to i32
  store i32 %cv1711, ptr %slot148, align 8
  %v1712 = load i32, ptr %slot148, align 8
  %cv1713 = zext i32 %v1712 to i64
  %cond1714 = icmp ne i64 %cv1713, 0
  br i1 %cond1714, label %bb_rcgclear163, label %bb_rcgcounted163
bb_rcgcounted163:
  %v1715 = load i64, ptr %slot143, align 8
  %op1716 = sub i64 %v1715, 32
  store i64 %op1716, ptr %slot149, align 8
  %v1717 = load i64, ptr %slot143, align 8
  %p1718 = inttoptr i64 %v1717 to ptr
  %rgep1719 = getelementptr i8, ptr %p1718, i64 -32
  %ld1720 = load i64, ptr %rgep1719, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1720, ptr %slot150, align 8
  %v1721 = load i64, ptr %slot150, align 8
  %op1722 = sub i64 %v1721, 1
  store i64 %op1722, ptr %slot151, align 8
  %v1723 = load i64, ptr %slot151, align 8
  %cmp1724 = icmp eq i64 %v1723, 0
  %cv1725 = zext i1 %cmp1724 to i32
  store i32 %cv1725, ptr %slot152, align 8
  %v1726 = load i32, ptr %slot152, align 8
  %cv1727 = zext i32 %v1726 to i64
  %cond1728 = icmp ne i64 %cv1727, 0
  br i1 %cond1728, label %bb_rcglast163, label %bb_rcgdec163
bb_rcglast163:
  %v1729 = load i64, ptr %slot143, align 8
  %op1730 = sub i64 %v1729, 24
  store i64 %op1730, ptr %slot153, align 8
  %v1731 = load i64, ptr %slot143, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  %rgep1733 = getelementptr i8, ptr %p1732, i64 -24
  %ld1734 = load i64, ptr %rgep1733, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1734, ptr %slot154, align 8
  %v1735 = load i64, ptr %slot154, align 8
  %cmp1736 = icmp ne i64 %v1735, 0
  %cv1737 = zext i1 %cmp1736 to i32
  store i32 %cv1737, ptr %slot155, align 8
  %v1738 = load i32, ptr %slot155, align 8
  %cv1739 = zext i32 %v1738 to i64
  %cond1740 = icmp ne i64 %cv1739, 0
  br i1 %cond1740, label %bb_rcgdec163, label %bb_rcgslow163
bb_rcgslow163:
  %v1741 = load i64, ptr %slot142, align 8
  %v1742 = load i64, ptr %slot125, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v1741, i64 %v1742) nomerge, !dbg !120
  br label %bb_rcgdone163
bb_rcgdec163:
  %v1743 = load i64, ptr %slot151, align 8
  %v1744 = load i64, ptr %slot143, align 8
  %p1745 = inttoptr i64 %v1744 to ptr
  %rgep1746 = getelementptr i8, ptr %p1745, i64 -32
  store i64 %v1743, ptr %rgep1746, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear163
bb_rcgclear163:
  %v1747 = load i64, ptr %slot125, align 8
  %p1748 = inttoptr i64 %v1747 to ptr
  store i64 0, ptr %p1748, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone163
bb_rcgdone163:
  br label %bb_rcslotdone132
bb_rcslotdone132:
  %v1749 = load i64, ptr %slot6, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %ld1751 = load i32, ptr %p1750, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1751, ptr %slot156, align 8
  %v1752 = load i32, ptr %slot156, align 8
  %cv1753 = zext i32 %v1752 to i64
  %cond1754 = icmp ne i64 %cv1753, 0
  br i1 %cond1754, label %bb_rcslotdrop169, label %bb_rcslotdone169
bb_rcslotdrop169:
  %v1755 = load i64, ptr %slot6, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  store i32 0, ptr %p1756, align 4, !alias.scope !3, !noalias !4
  %v1757 = load i64, ptr %slot27, align 8
  store i64 %v1757, ptr %slot157, align 8
  %v1758 = load i64, ptr %slot7, align 8
  %p1759 = inttoptr i64 %v1758 to ptr
  %ld1760 = load i32, ptr %p1759, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1760, ptr %slot158, align 8
  %v1761 = load i32, ptr %slot158, align 8
  %op1762 = and i32 %v1761, 28
  store i32 %op1762, ptr %slot159, align 8
  %v1763 = load i32, ptr %slot159, align 8
  %cv1764 = zext i32 %v1763 to i64
  %cond1765 = icmp ne i64 %cv1764, 0
  br i1 %cond1765, label %bb_rcslotrole169, label %bb_rcslotowner169
bb_rcslotrole169:
  %v1766 = load i64, ptr %slot39, align 8
  store i64 %v1766, ptr %slot160, align 8
  %v1767 = load i64, ptr %slot157, align 8
  %p1768 = inttoptr i64 %v1767 to ptr
  %ld1769 = load i64, ptr %p1768, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1769, ptr %slot161, align 8
  %v1770 = load i64, ptr %slot161, align 8
  %cmp1771 = icmp ne i64 %v1770, 0
  %cv1772 = zext i1 %cmp1771 to i32
  store i32 %cv1772, ptr %slot162, align 8
  %v1773 = load i32, ptr %slot162, align 8
  %cv1774 = zext i32 %v1773 to i64
  %cond1775 = icmp ne i64 %cv1774, 0
  br i1 %cond1775, label %bb_rcgnn185, label %bb_rcgdone185
bb_rcgnn185:
  %v1776 = load i64, ptr %slot161, align 8
  %op1777 = sub i64 %v1776, 16
  store i64 %op1777, ptr %slot163, align 8
  %v1778 = load i64, ptr %slot161, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  %rgep1780 = getelementptr i8, ptr %p1779, i64 -16
  %ld1781 = load i64, ptr %rgep1780, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1781, ptr %slot164, align 8
  %v1782 = load i64, ptr %slot164, align 8
  %op1783 = and i64 %v1782, 4611686018427387906
  store i64 %op1783, ptr %slot165, align 8
  %v1784 = load i64, ptr %slot165, align 8
  %cmp1785 = icmp ne i64 %v1784, 0
  %cv1786 = zext i1 %cmp1785 to i32
  store i32 %cv1786, ptr %slot166, align 8
  %v1787 = load i32, ptr %slot166, align 8
  %cv1788 = zext i32 %v1787 to i64
  %cond1789 = icmp ne i64 %cv1788, 0
  br i1 %cond1789, label %bb_rcgclear185, label %bb_rcgcounted185
bb_rcgcounted185:
  %v1790 = load i64, ptr %slot161, align 8
  %op1791 = sub i64 %v1790, 24
  store i64 %op1791, ptr %slot167, align 8
  %v1792 = load i64, ptr %slot161, align 8
  %p1793 = inttoptr i64 %v1792 to ptr
  %rgep1794 = getelementptr i8, ptr %p1793, i64 -24
  %ld1795 = load i64, ptr %rgep1794, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1795, ptr %slot168, align 8
  %v1796 = load i64, ptr %slot168, align 8
  %op1797 = sub i64 %v1796, 1
  store i64 %op1797, ptr %slot169, align 8
  %v1798 = load i64, ptr %slot169, align 8
  %cmp1799 = icmp eq i64 %v1798, 0
  %cv1800 = zext i1 %cmp1799 to i32
  store i32 %cv1800, ptr %slot170, align 8
  %v1801 = load i32, ptr %slot170, align 8
  %cv1802 = zext i32 %v1801 to i64
  %cond1803 = icmp ne i64 %cv1802, 0
  br i1 %cond1803, label %bb_rcglast185, label %bb_rcgdec185
bb_rcglast185:
  %v1804 = load i64, ptr %slot161, align 8
  %op1805 = sub i64 %v1804, 32
  store i64 %op1805, ptr %slot171, align 8
  %v1806 = load i64, ptr %slot161, align 8
  %p1807 = inttoptr i64 %v1806 to ptr
  %rgep1808 = getelementptr i8, ptr %p1807, i64 -32
  %ld1809 = load i64, ptr %rgep1808, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1809, ptr %slot172, align 8
  %v1810 = load i64, ptr %slot172, align 8
  %cmp1811 = icmp ne i64 %v1810, 0
  %cv1812 = zext i1 %cmp1811 to i32
  store i32 %cv1812, ptr %slot173, align 8
  %v1813 = load i32, ptr %slot173, align 8
  %cv1814 = zext i32 %v1813 to i64
  %cond1815 = icmp ne i64 %cv1814, 0
  br i1 %cond1815, label %bb_rcgdec185, label %bb_rcgslow185
bb_rcgslow185:
  %v1816 = load i64, ptr %slot160, align 8
  %v1817 = load i64, ptr %slot157, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v1816, i64 %v1817) nomerge, !dbg !120
  br label %bb_rcgdone185
bb_rcgdec185:
  %v1818 = load i64, ptr %slot169, align 8
  %v1819 = load i64, ptr %slot161, align 8
  %p1820 = inttoptr i64 %v1819 to ptr
  %rgep1821 = getelementptr i8, ptr %p1820, i64 -24
  store i64 %v1818, ptr %rgep1821, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear185
bb_rcgclear185:
  %v1822 = load i64, ptr %slot157, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  store i64 0, ptr %p1823, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone185
bb_rcgdone185:
  br label %bb_rcslotdone169
bb_rcslotowner169:
  %v1824 = load i64, ptr %slot39, align 8
  store i64 %v1824, ptr %slot174, align 8
  %v1825 = load i64, ptr %slot157, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %ld1827 = load i64, ptr %p1826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1827, ptr %slot175, align 8
  %v1828 = load i64, ptr %slot175, align 8
  %cmp1829 = icmp ne i64 %v1828, 0
  %cv1830 = zext i1 %cmp1829 to i32
  store i32 %cv1830, ptr %slot176, align 8
  %v1831 = load i32, ptr %slot176, align 8
  %cv1832 = zext i32 %v1831 to i64
  %cond1833 = icmp ne i64 %cv1832, 0
  br i1 %cond1833, label %bb_rcgnn200, label %bb_rcgdone200
bb_rcgnn200:
  %v1834 = load i64, ptr %slot175, align 8
  %op1835 = sub i64 %v1834, 16
  store i64 %op1835, ptr %slot177, align 8
  %v1836 = load i64, ptr %slot175, align 8
  %p1837 = inttoptr i64 %v1836 to ptr
  %rgep1838 = getelementptr i8, ptr %p1837, i64 -16
  %ld1839 = load i64, ptr %rgep1838, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1839, ptr %slot178, align 8
  %v1840 = load i64, ptr %slot178, align 8
  %op1841 = and i64 %v1840, 4611686018427387906
  store i64 %op1841, ptr %slot179, align 8
  %v1842 = load i64, ptr %slot179, align 8
  %cmp1843 = icmp ne i64 %v1842, 0
  %cv1844 = zext i1 %cmp1843 to i32
  store i32 %cv1844, ptr %slot180, align 8
  %v1845 = load i32, ptr %slot180, align 8
  %cv1846 = zext i32 %v1845 to i64
  %cond1847 = icmp ne i64 %cv1846, 0
  br i1 %cond1847, label %bb_rcgclear200, label %bb_rcgcounted200
bb_rcgcounted200:
  %v1848 = load i64, ptr %slot175, align 8
  %op1849 = sub i64 %v1848, 32
  store i64 %op1849, ptr %slot181, align 8
  %v1850 = load i64, ptr %slot175, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  %rgep1852 = getelementptr i8, ptr %p1851, i64 -32
  %ld1853 = load i64, ptr %rgep1852, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1853, ptr %slot182, align 8
  %v1854 = load i64, ptr %slot182, align 8
  %op1855 = sub i64 %v1854, 1
  store i64 %op1855, ptr %slot183, align 8
  %v1856 = load i64, ptr %slot183, align 8
  %cmp1857 = icmp eq i64 %v1856, 0
  %cv1858 = zext i1 %cmp1857 to i32
  store i32 %cv1858, ptr %slot184, align 8
  %v1859 = load i32, ptr %slot184, align 8
  %cv1860 = zext i32 %v1859 to i64
  %cond1861 = icmp ne i64 %cv1860, 0
  br i1 %cond1861, label %bb_rcglast200, label %bb_rcgdec200
bb_rcglast200:
  %v1862 = load i64, ptr %slot175, align 8
  %op1863 = sub i64 %v1862, 24
  store i64 %op1863, ptr %slot185, align 8
  %v1864 = load i64, ptr %slot175, align 8
  %p1865 = inttoptr i64 %v1864 to ptr
  %rgep1866 = getelementptr i8, ptr %p1865, i64 -24
  %ld1867 = load i64, ptr %rgep1866, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1867, ptr %slot186, align 8
  %v1868 = load i64, ptr %slot186, align 8
  %cmp1869 = icmp ne i64 %v1868, 0
  %cv1870 = zext i1 %cmp1869 to i32
  store i32 %cv1870, ptr %slot187, align 8
  %v1871 = load i32, ptr %slot187, align 8
  %cv1872 = zext i32 %v1871 to i64
  %cond1873 = icmp ne i64 %cv1872, 0
  br i1 %cond1873, label %bb_rcgdec200, label %bb_rcgslow200
bb_rcgslow200:
  %v1874 = load i64, ptr %slot174, align 8
  %v1875 = load i64, ptr %slot157, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v1874, i64 %v1875) nomerge, !dbg !120
  br label %bb_rcgdone200
bb_rcgdec200:
  %v1876 = load i64, ptr %slot183, align 8
  %v1877 = load i64, ptr %slot175, align 8
  %p1878 = inttoptr i64 %v1877 to ptr
  %rgep1879 = getelementptr i8, ptr %p1878, i64 -32
  store i64 %v1876, ptr %rgep1879, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear200
bb_rcgclear200:
  %v1880 = load i64, ptr %slot157, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  store i64 0, ptr %p1881, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone200
bb_rcgdone200:
  br label %bb_rcslotdone169
bb_rcslotdone169:
  %v1882 = load i64, ptr %slot4, align 8
  %p1883 = inttoptr i64 %v1882 to ptr
  %ld1884 = load i32, ptr %p1883, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1884, ptr %slot188, align 8
  %v1885 = load i32, ptr %slot188, align 8
  %cv1886 = zext i32 %v1885 to i64
  %cond1887 = icmp ne i64 %cv1886, 0
  br i1 %cond1887, label %bb_rcslotdrop206, label %bb_rcslotdone206
bb_rcslotdrop206:
  %v1888 = load i64, ptr %slot4, align 8
  %p1889 = inttoptr i64 %v1888 to ptr
  store i32 0, ptr %p1889, align 4, !alias.scope !3, !noalias !4
  %v1890 = load i64, ptr %slot26, align 8
  store i64 %v1890, ptr %slot189, align 8
  %v1891 = load i64, ptr %slot5, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  %ld1893 = load i32, ptr %p1892, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1893, ptr %slot190, align 8
  %v1894 = load i32, ptr %slot190, align 8
  %op1895 = and i32 %v1894, 28
  store i32 %op1895, ptr %slot191, align 8
  %v1896 = load i32, ptr %slot191, align 8
  %cv1897 = zext i32 %v1896 to i64
  %cond1898 = icmp ne i64 %cv1897, 0
  br i1 %cond1898, label %bb_rcslotrole206, label %bb_rcslotowner206
bb_rcslotrole206:
  %v1899 = load i64, ptr %slot39, align 8
  store i64 %v1899, ptr %slot192, align 8
  %v1900 = load i64, ptr %slot192, align 8
  %v1901 = load i64, ptr %slot189, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v1900, i64 %v1901) nomerge, !dbg !120
  br label %bb_rcslotdone206
bb_rcslotowner206:
  %v1902 = load i64, ptr %slot39, align 8
  store i64 %v1902, ptr %slot193, align 8
  %v1903 = load i64, ptr %slot193, align 8
  %v1904 = load i64, ptr %slot189, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v1903, i64 %v1904) nomerge, !dbg !120
  br label %bb_rcslotdone206
bb_rcslotdone206:
  %v1905 = load i64, ptr %slot84, align 8
  ret i64 %v1905
bb_i10:
  %v1906 = load i64, ptr %slot25, align 8
  %p1907 = inttoptr i64 %v1906 to ptr
  %ld1908 = load i64, ptr %p1907, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1908, ptr %slot194, align 8
  %v1909 = load i64, ptr %slot194, align 8
  %v1910 = load i64, ptr %slot33, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  store i64 %v1909, ptr %p1911, align 8, !alias.scope !3, !noalias !4
  %v1912 = load i64, ptr %slot33, align 8
  %p1913 = inttoptr i64 %v1912 to ptr
  %ld1914 = load i64, ptr %p1913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1914, ptr %slot195, align 8
  %v1915 = load i64, ptr %slot195, align 8
  %op1916 = add i64 %v1915, 248
  store i64 %op1916, ptr %slot196, align 8
  %v1917 = load i64, ptr %slot196, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %ld1919 = load i64, ptr %p1918, align 8
  store i64 %ld1919, ptr %slot197, align 8
  %v1920 = load i64, ptr %slot197, align 8
  %v1921 = load i64, ptr %slot33, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  store i64 %v1920, ptr %p1922, align 8, !alias.scope !3, !noalias !4
  %v1923 = load i64, ptr %slot14, align 8
  %p1924 = inttoptr i64 %v1923 to ptr
  %ld1925 = load i32, ptr %p1924, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1925, ptr %slot198, align 8
  %v1926 = load i32, ptr %slot198, align 8
  %cv1927 = zext i32 %v1926 to i64
  %cond1928 = icmp ne i64 %cv1927, 0
  br i1 %cond1928, label %bb_rcslotdrop228, label %bb_rcslotdone228
bb_rcslotdrop228:
  %v1929 = load i64, ptr %slot14, align 8
  %p1930 = inttoptr i64 %v1929 to ptr
  store i32 0, ptr %p1930, align 4, !alias.scope !3, !noalias !4
  %v1931 = load i64, ptr %slot20, align 8
  store i64 %v1931, ptr %slot199, align 8
  %v1932 = load i64, ptr %slot15, align 8
  %p1933 = inttoptr i64 %v1932 to ptr
  %ld1934 = load i32, ptr %p1933, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1934, ptr %slot200, align 8
  %v1935 = load i32, ptr %slot200, align 8
  %op1936 = and i32 %v1935, 28
  store i32 %op1936, ptr %slot201, align 8
  %v1937 = load i32, ptr %slot201, align 8
  %cv1938 = zext i32 %v1937 to i64
  %cond1939 = icmp ne i64 %cv1938, 0
  br i1 %cond1939, label %bb_rcslotrole228, label %bb_rcslotowner228
bb_rcslotrole228:
  %v1940 = load i64, ptr %slot39, align 8
  store i64 %v1940, ptr %slot202, align 8
  %v1941 = load i64, ptr %slot202, align 8
  %v1942 = load i64, ptr %slot199, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1941, i64 %v1942) nomerge, !dbg !122
  br label %bb_rcslotdone228
bb_rcslotowner228:
  %v1943 = load i64, ptr %slot39, align 8
  store i64 %v1943, ptr %slot203, align 8
  %v1944 = load i64, ptr %slot203, align 8
  %v1945 = load i64, ptr %slot199, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1944, i64 %v1945) nomerge, !dbg !122
  br label %bb_rcslotdone228
bb_rcslotdone228:
  %v1946 = load i64, ptr %slot25, align 8
  %p1947 = inttoptr i64 %v1946 to ptr
  %ld1948 = load i64, ptr %p1947, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1948, ptr %slot204, align 8
  %v1949 = load i64, ptr %slot204, align 8
  %v1950 = load i64, ptr %slot34, align 8
  %p1951 = inttoptr i64 %v1950 to ptr
  store i64 %v1949, ptr %p1951, align 8, !alias.scope !3, !noalias !4
  %v1952 = load i64, ptr %slot34, align 8
  %p1953 = inttoptr i64 %v1952 to ptr
  %ld1954 = load i64, ptr %p1953, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1954, ptr %slot205, align 8
  %v1955 = load i64, ptr %slot205, align 8
  %op1956 = add i64 %v1955, 328
  store i64 %op1956, ptr %slot206, align 8
  %v1957 = load i64, ptr %slot206, align 8
  %v1958 = load i64, ptr %slot34, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  store i64 %v1957, ptr %p1959, align 8, !alias.scope !3, !noalias !4
  %v1960 = load i64, ptr %slot16, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  %ld1962 = load i32, ptr %p1961, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1962, ptr %slot207, align 8
  %v1963 = load i32, ptr %slot207, align 8
  %cv1964 = zext i32 %v1963 to i64
  %cond1965 = icmp ne i64 %cv1964, 0
  br i1 %cond1965, label %bb_rcslotdrop240, label %bb_rcslotdone240
bb_rcslotdrop240:
  %v1966 = load i64, ptr %slot16, align 8
  %p1967 = inttoptr i64 %v1966 to ptr
  store i32 0, ptr %p1967, align 4, !alias.scope !3, !noalias !4
  %v1968 = load i64, ptr %slot21, align 8
  store i64 %v1968, ptr %slot208, align 8
  %v1969 = load i64, ptr %slot17, align 8
  %p1970 = inttoptr i64 %v1969 to ptr
  %ld1971 = load i32, ptr %p1970, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1971, ptr %slot209, align 8
  %v1972 = load i32, ptr %slot209, align 8
  %op1973 = and i32 %v1972, 28
  store i32 %op1973, ptr %slot210, align 8
  %v1974 = load i32, ptr %slot210, align 8
  %cv1975 = zext i32 %v1974 to i64
  %cond1976 = icmp ne i64 %cv1975, 0
  br i1 %cond1976, label %bb_rcslotrole240, label %bb_rcslotowner240
bb_rcslotrole240:
  %v1977 = load i64, ptr %slot39, align 8
  store i64 %v1977, ptr %slot211, align 8
  %v1978 = load i64, ptr %slot211, align 8
  %v1979 = load i64, ptr %slot208, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v1978, i64 %v1979) nomerge, !dbg !124
  br label %bb_rcslotdone240
bb_rcslotowner240:
  %v1980 = load i64, ptr %slot39, align 8
  store i64 %v1980, ptr %slot212, align 8
  %v1981 = load i64, ptr %slot212, align 8
  %v1982 = load i64, ptr %slot208, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v1981, i64 %v1982) nomerge, !dbg !124
  br label %bb_rcslotdone240
bb_rcslotdone240:
  %v1983 = load i64, ptr %slot33, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  %ld1985 = load i64, ptr %p1984, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1985, ptr %slot213, align 8
  %v1986 = load i64, ptr %slot34, align 8
  %p1987 = inttoptr i64 %v1986 to ptr
  %ld1988 = load i64, ptr %p1987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1988, ptr %slot214, align 8
  %v1989 = load i64, ptr %slot1, align 8
  %v1990 = load i64, ptr %slot213, align 8
  %v1991 = load i64, ptr %slot214, align 8
  %call1992 = call i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64 %v1989, i64 %v1990, i64 %v1991) nomerge, !dbg !126
  store i64 %call1992, ptr %slot215, align 8
  %v1993 = load i64, ptr %slot215, align 8
  %v1994 = load i64, ptr %slot33, align 8
  %p1995 = inttoptr i64 %v1994 to ptr
  store i64 %v1993, ptr %p1995, align 8, !alias.scope !3, !noalias !4
  %v1996 = load i64, ptr %slot33, align 8
  %p1997 = inttoptr i64 %v1996 to ptr
  %ld1998 = load i64, ptr %p1997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1998, ptr %slot216, align 8
  %v1999 = load i64, ptr %slot216, align 8
  %v2000 = load i64, ptr %slot22, align 8
  %p2001 = inttoptr i64 %v2000 to ptr
  store i64 %v1999, ptr %p2001, align 8, !alias.scope !3, !noalias !4
  %v2002 = load i64, ptr %slot22, align 8
  store i64 %v2002, ptr %slot217, align 8
  %v2003 = load i64, ptr %slot24, align 8
  store i64 %v2003, ptr %slot218, align 8
  %v2004 = load i64, ptr %slot217, align 8
  %v2005 = load i64, ptr %slot218, align 8
  %p2006 = inttoptr i64 %v2004 to ptr
  %p2007 = inttoptr i64 %v2005 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2007, ptr %p2006, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2008 = load i64, ptr %slot19, align 8
  %p2009 = inttoptr i64 %v2008 to ptr
  store i32 2, ptr %p2009, align 4, !alias.scope !3, !noalias !4
  %v2010 = load i64, ptr %slot18, align 8
  %p2011 = inttoptr i64 %v2010 to ptr
  store i32 1, ptr %p2011, align 4, !alias.scope !3, !noalias !4
  %v2012 = load i64, ptr %slot14, align 8
  %p2013 = inttoptr i64 %v2012 to ptr
  %ld2014 = load i32, ptr %p2013, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2014, ptr %slot219, align 8
  %v2015 = load i32, ptr %slot219, align 8
  %cv2016 = zext i32 %v2015 to i64
  %cond2017 = icmp ne i64 %cv2016, 0
  br i1 %cond2017, label %bb_rcslotdrop257, label %bb_rcslotdone257
bb_rcslotdrop257:
  %v2018 = load i64, ptr %slot14, align 8
  %p2019 = inttoptr i64 %v2018 to ptr
  store i32 0, ptr %p2019, align 4, !alias.scope !3, !noalias !4
  %v2020 = load i64, ptr %slot20, align 8
  store i64 %v2020, ptr %slot220, align 8
  %v2021 = load i64, ptr %slot15, align 8
  %p2022 = inttoptr i64 %v2021 to ptr
  %ld2023 = load i32, ptr %p2022, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2023, ptr %slot221, align 8
  %v2024 = load i32, ptr %slot221, align 8
  %op2025 = and i32 %v2024, 28
  store i32 %op2025, ptr %slot222, align 8
  %v2026 = load i32, ptr %slot222, align 8
  %cv2027 = zext i32 %v2026 to i64
  %cond2028 = icmp ne i64 %cv2027, 0
  br i1 %cond2028, label %bb_rcslotrole257, label %bb_rcslotowner257
bb_rcslotrole257:
  %v2029 = load i64, ptr %slot39, align 8
  store i64 %v2029, ptr %slot223, align 8
  %v2030 = load i64, ptr %slot220, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  %ld2032 = load i64, ptr %p2031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2032, ptr %slot224, align 8
  %v2033 = load i64, ptr %slot224, align 8
  %cmp2034 = icmp ne i64 %v2033, 0
  %cv2035 = zext i1 %cmp2034 to i32
  store i32 %cv2035, ptr %slot225, align 8
  %v2036 = load i32, ptr %slot225, align 8
  %cv2037 = zext i32 %v2036 to i64
  %cond2038 = icmp ne i64 %cv2037, 0
  br i1 %cond2038, label %bb_rcgnn273, label %bb_rcgdone273
bb_rcgnn273:
  %v2039 = load i64, ptr %slot224, align 8
  %op2040 = sub i64 %v2039, 16
  store i64 %op2040, ptr %slot226, align 8
  %v2041 = load i64, ptr %slot224, align 8
  %p2042 = inttoptr i64 %v2041 to ptr
  %rgep2043 = getelementptr i8, ptr %p2042, i64 -16
  %ld2044 = load i64, ptr %rgep2043, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2044, ptr %slot227, align 8
  %v2045 = load i64, ptr %slot227, align 8
  %op2046 = and i64 %v2045, 4611686018427387906
  store i64 %op2046, ptr %slot228, align 8
  %v2047 = load i64, ptr %slot228, align 8
  %cmp2048 = icmp ne i64 %v2047, 0
  %cv2049 = zext i1 %cmp2048 to i32
  store i32 %cv2049, ptr %slot229, align 8
  %v2050 = load i32, ptr %slot229, align 8
  %cv2051 = zext i32 %v2050 to i64
  %cond2052 = icmp ne i64 %cv2051, 0
  br i1 %cond2052, label %bb_rcgclear273, label %bb_rcgcounted273
bb_rcgcounted273:
  %v2053 = load i64, ptr %slot224, align 8
  %op2054 = sub i64 %v2053, 24
  store i64 %op2054, ptr %slot230, align 8
  %v2055 = load i64, ptr %slot224, align 8
  %p2056 = inttoptr i64 %v2055 to ptr
  %rgep2057 = getelementptr i8, ptr %p2056, i64 -24
  %ld2058 = load i64, ptr %rgep2057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2058, ptr %slot231, align 8
  %v2059 = load i64, ptr %slot231, align 8
  %op2060 = sub i64 %v2059, 1
  store i64 %op2060, ptr %slot232, align 8
  %v2061 = load i64, ptr %slot232, align 8
  %cmp2062 = icmp eq i64 %v2061, 0
  %cv2063 = zext i1 %cmp2062 to i32
  store i32 %cv2063, ptr %slot233, align 8
  %v2064 = load i32, ptr %slot233, align 8
  %cv2065 = zext i32 %v2064 to i64
  %cond2066 = icmp ne i64 %cv2065, 0
  br i1 %cond2066, label %bb_rcglast273, label %bb_rcgdec273
bb_rcglast273:
  %v2067 = load i64, ptr %slot224, align 8
  %op2068 = sub i64 %v2067, 32
  store i64 %op2068, ptr %slot234, align 8
  %v2069 = load i64, ptr %slot224, align 8
  %p2070 = inttoptr i64 %v2069 to ptr
  %rgep2071 = getelementptr i8, ptr %p2070, i64 -32
  %ld2072 = load i64, ptr %rgep2071, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2072, ptr %slot235, align 8
  %v2073 = load i64, ptr %slot235, align 8
  %cmp2074 = icmp ne i64 %v2073, 0
  %cv2075 = zext i1 %cmp2074 to i32
  store i32 %cv2075, ptr %slot236, align 8
  %v2076 = load i32, ptr %slot236, align 8
  %cv2077 = zext i32 %v2076 to i64
  %cond2078 = icmp ne i64 %cv2077, 0
  br i1 %cond2078, label %bb_rcgdec273, label %bb_rcgslow273
bb_rcgslow273:
  %v2079 = load i64, ptr %slot223, align 8
  %v2080 = load i64, ptr %slot220, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2079, i64 %v2080) nomerge, !dbg !126
  br label %bb_rcgdone273
bb_rcgdec273:
  %v2081 = load i64, ptr %slot232, align 8
  %v2082 = load i64, ptr %slot224, align 8
  %p2083 = inttoptr i64 %v2082 to ptr
  %rgep2084 = getelementptr i8, ptr %p2083, i64 -24
  store i64 %v2081, ptr %rgep2084, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear273
bb_rcgclear273:
  %v2085 = load i64, ptr %slot220, align 8
  %p2086 = inttoptr i64 %v2085 to ptr
  store i64 0, ptr %p2086, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone273
bb_rcgdone273:
  br label %bb_rcslotdone257
bb_rcslotowner257:
  %v2087 = load i64, ptr %slot39, align 8
  store i64 %v2087, ptr %slot237, align 8
  %v2088 = load i64, ptr %slot220, align 8
  %p2089 = inttoptr i64 %v2088 to ptr
  %ld2090 = load i64, ptr %p2089, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2090, ptr %slot238, align 8
  %v2091 = load i64, ptr %slot238, align 8
  %cmp2092 = icmp ne i64 %v2091, 0
  %cv2093 = zext i1 %cmp2092 to i32
  store i32 %cv2093, ptr %slot239, align 8
  %v2094 = load i32, ptr %slot239, align 8
  %cv2095 = zext i32 %v2094 to i64
  %cond2096 = icmp ne i64 %cv2095, 0
  br i1 %cond2096, label %bb_rcgnn288, label %bb_rcgdone288
bb_rcgnn288:
  %v2097 = load i64, ptr %slot238, align 8
  %op2098 = sub i64 %v2097, 16
  store i64 %op2098, ptr %slot240, align 8
  %v2099 = load i64, ptr %slot238, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  %rgep2101 = getelementptr i8, ptr %p2100, i64 -16
  %ld2102 = load i64, ptr %rgep2101, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2102, ptr %slot241, align 8
  %v2103 = load i64, ptr %slot241, align 8
  %op2104 = and i64 %v2103, 4611686018427387906
  store i64 %op2104, ptr %slot242, align 8
  %v2105 = load i64, ptr %slot242, align 8
  %cmp2106 = icmp ne i64 %v2105, 0
  %cv2107 = zext i1 %cmp2106 to i32
  store i32 %cv2107, ptr %slot243, align 8
  %v2108 = load i32, ptr %slot243, align 8
  %cv2109 = zext i32 %v2108 to i64
  %cond2110 = icmp ne i64 %cv2109, 0
  br i1 %cond2110, label %bb_rcgclear288, label %bb_rcgcounted288
bb_rcgcounted288:
  %v2111 = load i64, ptr %slot238, align 8
  %op2112 = sub i64 %v2111, 32
  store i64 %op2112, ptr %slot244, align 8
  %v2113 = load i64, ptr %slot238, align 8
  %p2114 = inttoptr i64 %v2113 to ptr
  %rgep2115 = getelementptr i8, ptr %p2114, i64 -32
  %ld2116 = load i64, ptr %rgep2115, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2116, ptr %slot245, align 8
  %v2117 = load i64, ptr %slot245, align 8
  %op2118 = sub i64 %v2117, 1
  store i64 %op2118, ptr %slot246, align 8
  %v2119 = load i64, ptr %slot246, align 8
  %cmp2120 = icmp eq i64 %v2119, 0
  %cv2121 = zext i1 %cmp2120 to i32
  store i32 %cv2121, ptr %slot247, align 8
  %v2122 = load i32, ptr %slot247, align 8
  %cv2123 = zext i32 %v2122 to i64
  %cond2124 = icmp ne i64 %cv2123, 0
  br i1 %cond2124, label %bb_rcglast288, label %bb_rcgdec288
bb_rcglast288:
  %v2125 = load i64, ptr %slot238, align 8
  %op2126 = sub i64 %v2125, 24
  store i64 %op2126, ptr %slot248, align 8
  %v2127 = load i64, ptr %slot238, align 8
  %p2128 = inttoptr i64 %v2127 to ptr
  %rgep2129 = getelementptr i8, ptr %p2128, i64 -24
  %ld2130 = load i64, ptr %rgep2129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2130, ptr %slot249, align 8
  %v2131 = load i64, ptr %slot249, align 8
  %cmp2132 = icmp ne i64 %v2131, 0
  %cv2133 = zext i1 %cmp2132 to i32
  store i32 %cv2133, ptr %slot250, align 8
  %v2134 = load i32, ptr %slot250, align 8
  %cv2135 = zext i32 %v2134 to i64
  %cond2136 = icmp ne i64 %cv2135, 0
  br i1 %cond2136, label %bb_rcgdec288, label %bb_rcgslow288
bb_rcgslow288:
  %v2137 = load i64, ptr %slot237, align 8
  %v2138 = load i64, ptr %slot220, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2137, i64 %v2138) nomerge, !dbg !126
  br label %bb_rcgdone288
bb_rcgdec288:
  %v2139 = load i64, ptr %slot246, align 8
  %v2140 = load i64, ptr %slot238, align 8
  %p2141 = inttoptr i64 %v2140 to ptr
  %rgep2142 = getelementptr i8, ptr %p2141, i64 -32
  store i64 %v2139, ptr %rgep2142, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear288
bb_rcgclear288:
  %v2143 = load i64, ptr %slot220, align 8
  %p2144 = inttoptr i64 %v2143 to ptr
  store i64 0, ptr %p2144, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone288
bb_rcgdone288:
  br label %bb_rcslotdone257
bb_rcslotdone257:
  %v2145 = load i64, ptr %slot16, align 8
  %p2146 = inttoptr i64 %v2145 to ptr
  %ld2147 = load i32, ptr %p2146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2147, ptr %slot251, align 8
  %v2148 = load i32, ptr %slot251, align 8
  %cv2149 = zext i32 %v2148 to i64
  %cond2150 = icmp ne i64 %cv2149, 0
  br i1 %cond2150, label %bb_rcslotdrop294, label %bb_rcslotdone294
bb_rcslotdrop294:
  %v2151 = load i64, ptr %slot16, align 8
  %p2152 = inttoptr i64 %v2151 to ptr
  store i32 0, ptr %p2152, align 4, !alias.scope !3, !noalias !4
  %v2153 = load i64, ptr %slot21, align 8
  store i64 %v2153, ptr %slot252, align 8
  %v2154 = load i64, ptr %slot17, align 8
  %p2155 = inttoptr i64 %v2154 to ptr
  %ld2156 = load i32, ptr %p2155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2156, ptr %slot253, align 8
  %v2157 = load i32, ptr %slot253, align 8
  %op2158 = and i32 %v2157, 28
  store i32 %op2158, ptr %slot254, align 8
  %v2159 = load i32, ptr %slot254, align 8
  %cv2160 = zext i32 %v2159 to i64
  %cond2161 = icmp ne i64 %cv2160, 0
  br i1 %cond2161, label %bb_rcslotrole294, label %bb_rcslotowner294
bb_rcslotrole294:
  %v2162 = load i64, ptr %slot39, align 8
  store i64 %v2162, ptr %slot255, align 8
  %v2163 = load i64, ptr %slot255, align 8
  %v2164 = load i64, ptr %slot252, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64 %v2163, i64 %v2164) nomerge, !dbg !126
  br label %bb_rcslotdone294
bb_rcslotowner294:
  %v2165 = load i64, ptr %slot39, align 8
  store i64 %v2165, ptr %slot256, align 8
  %v2166 = load i64, ptr %slot256, align 8
  %v2167 = load i64, ptr %slot252, align 8
  call void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64 %v2166, i64 %v2167) nomerge, !dbg !126
  br label %bb_rcslotdone294
bb_rcslotdone294:
  %v2168 = load i64, ptr %slot20, align 8
  store i64 %v2168, ptr %slot257, align 8
  %v2169 = load i64, ptr %slot24, align 8
  store i64 %v2169, ptr %slot258, align 8
  %v2170 = load i64, ptr %slot258, align 8
  %v2171 = load i64, ptr %slot257, align 8
  %p2172 = inttoptr i64 %v2170 to ptr
  %p2173 = inttoptr i64 %v2171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2173, ptr %p2172, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2174 = load i64, ptr %slot15, align 8
  %p2175 = inttoptr i64 %v2174 to ptr
  store i32 2, ptr %p2175, align 4, !alias.scope !3, !noalias !4
  %v2176 = load i64, ptr %slot19, align 8
  %p2177 = inttoptr i64 %v2176 to ptr
  %ld2178 = load i32, ptr %p2177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2178, ptr %slot259, align 8
  %v2179 = load i32, ptr %slot259, align 8
  %v2180 = load i64, ptr %slot15, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  store i32 %v2179, ptr %p2181, align 4, !alias.scope !3, !noalias !4
  %v2182 = load i64, ptr %slot18, align 8
  %p2183 = inttoptr i64 %v2182 to ptr
  store i32 0, ptr %p2183, align 4, !alias.scope !3, !noalias !4
  %v2184 = load i64, ptr %slot14, align 8
  %p2185 = inttoptr i64 %v2184 to ptr
  store i32 1, ptr %p2185, align 4, !alias.scope !3, !noalias !4
  %v2186 = load i64, ptr %slot257, align 8
  %p2187 = inttoptr i64 %v2186 to ptr
  %ld2188 = load i64, ptr %p2187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2188, ptr %slot260, align 8
  %v2189 = load i64, ptr %slot260, align 8
  %v2190 = load i64, ptr %slot33, align 8
  %p2191 = inttoptr i64 %v2190 to ptr
  store i64 %v2189, ptr %p2191, align 8, !alias.scope !3, !noalias !4
  %v2192 = load i64, ptr %slot33, align 8
  %p2193 = inttoptr i64 %v2192 to ptr
  %ld2194 = load i64, ptr %p2193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2194, ptr %slot261, align 8
  %v2195 = load i64, ptr %slot261, align 8
  %v2196 = load i64, ptr %slot22, align 8
  %p2197 = inttoptr i64 %v2196 to ptr
  store i64 %v2195, ptr %p2197, align 8, !alias.scope !3, !noalias !4
  %v2198 = load i64, ptr %slot22, align 8
  store i64 %v2198, ptr %slot262, align 8
  %v2199 = load i64, ptr %slot24, align 8
  store i64 %v2199, ptr %slot263, align 8
  %v2200 = load i64, ptr %slot40, align 8
  store i64 %v2200, ptr %slot264, align 8
  %v2201 = load i64, ptr %slot262, align 8
  %p2203 = inttoptr i64 %v2201 to ptr
  %gep2204 = getelementptr i8, ptr %p2203, i64 0
  %op2202 = ptrtoint ptr %gep2204 to i64
  store i64 %op2202, ptr %slot265, align 8
  %v2205 = load i64, ptr %slot265, align 8
  %p2206 = inttoptr i64 %v2205 to ptr
  %ld2207 = load i64, ptr %p2206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2207, ptr %slot266, align 8
  %v2208 = load i64, ptr %slot266, align 8
  %cmp2209 = icmp ne i64 %v2208, 0
  %cv2210 = zext i1 %cmp2209 to i32
  store i32 %cv2210, ptr %slot267, align 8
  %v2211 = load i32, ptr %slot267, align 8
  %cv2212 = zext i32 %v2211 to i64
  %cond2213 = icmp ne i64 %cv2212, 0
  br i1 %cond2213, label %bb_rcmoveheader317, label %bb_rcmovenext317
bb_rcmoveheader317:
  %v2214 = load i64, ptr %slot266, align 8
  %op2215 = sub i64 %v2214, 16
  store i64 %op2215, ptr %slot268, align 8
  %v2216 = load i64, ptr %slot266, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  %rgep2218 = getelementptr i8, ptr %p2217, i64 -16
  %ld2219 = load i64, ptr %rgep2218, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2219, ptr %slot269, align 8
  %v2220 = load i64, ptr %slot269, align 8
  %op2221 = and i64 %v2220, 5764607523034234881
  store i64 %op2221, ptr %slot270, align 8
  %v2222 = load i64, ptr %slot270, align 8
  %cmp2223 = icmp ne i64 %v2222, 0
  %cv2224 = zext i1 %cmp2223 to i32
  store i32 %cv2224, ptr %slot271, align 8
  %v2225 = load i32, ptr %slot271, align 8
  %cv2226 = zext i32 %v2225 to i64
  %cond2227 = icmp ne i64 %cv2226, 0
  br i1 %cond2227, label %bb_rcmoveslow314, label %bb_rcmovenext317
bb_rcmovenext317:
  %v2228 = load i64, ptr %slot262, align 8
  %v2229 = load i64, ptr %slot263, align 8
  %p2230 = inttoptr i64 %v2228 to ptr
  %p2231 = inttoptr i64 %v2229 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2231, ptr %p2230, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2232 = load i64, ptr %slot262, align 8
  %p2233 = inttoptr i64 %v2232 to ptr
  store i64 0, ptr %p2233, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved314
bb_rcmoveslow314:
  %v2234 = load i64, ptr %slot39, align 8
  %v2235 = load i64, ptr %slot263, align 8
  %v2236 = load i64, ptr %slot262, align 8
  %v2237 = load i64, ptr %slot264, align 8
  %cv2238 = trunc i64 %v2237 to i32
  %call2239 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2234, i64 %v2235, i64 %v2236, i32 %cv2238) nomerge, !dbg !128
  store i32 %call2239, ptr %slot272, align 8
  %v2240 = load i32, ptr %slot272, align 8
  %cv2241 = zext i32 %v2240 to i64
  %cond2242 = icmp ne i64 %cv2241, 0
  br i1 %cond2242, label %bb_rcsuccess324, label %bb_rcfailure324
bb_rcfailure324:
  %v2243 = load i64, ptr %slot39, align 8
  %p2244 = inttoptr i64 %v2243 to ptr
  %call2245 = call i32 @myl_rc_take_failure(ptr %p2244) nomerge, !dbg !128
  store i32 %call2245, ptr %slot273, align 8
  %v2246 = load i64, ptr %slot1, align 8
  %p2247 = inttoptr i64 %v2246 to ptr
  %v2248 = load i32, ptr %slot273, align 8
  %call2249 = call i32 @myl_qbe_rc_status(ptr %p2247, i32 %v2248) nomerge, !dbg !128
  store i32 %call2249, ptr %slot274, align 8
  br label %bb_failure
bb_rcsuccess324:
  br label %bb_rcmoved314
bb_rcmoved314:
  %v2250 = load i64, ptr %slot14, align 8
  %p2251 = inttoptr i64 %v2250 to ptr
  store i32 0, ptr %p2251, align 4, !alias.scope !3, !noalias !4
  %v2252 = load i64, ptr %slot19, align 8
  %p2253 = inttoptr i64 %v2252 to ptr
  store i32 2, ptr %p2253, align 4, !alias.scope !3, !noalias !4
  %v2254 = load i64, ptr %slot18, align 8
  %p2255 = inttoptr i64 %v2254 to ptr
  store i32 1, ptr %p2255, align 4, !alias.scope !3, !noalias !4
  %v2256 = load i64, ptr %slot6, align 8
  %p2257 = inttoptr i64 %v2256 to ptr
  %ld2258 = load i32, ptr %p2257, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2258, ptr %slot275, align 8
  %v2259 = load i32, ptr %slot275, align 8
  %cv2260 = zext i32 %v2259 to i64
  %cond2261 = icmp ne i64 %cv2260, 0
  br i1 %cond2261, label %bb_rcslotdrop333, label %bb_rcslotdone333
bb_rcslotdrop333:
  %v2262 = load i64, ptr %slot6, align 8
  %p2263 = inttoptr i64 %v2262 to ptr
  store i32 0, ptr %p2263, align 4, !alias.scope !3, !noalias !4
  %v2264 = load i64, ptr %slot27, align 8
  store i64 %v2264, ptr %slot276, align 8
  %v2265 = load i64, ptr %slot7, align 8
  %p2266 = inttoptr i64 %v2265 to ptr
  %ld2267 = load i32, ptr %p2266, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2267, ptr %slot277, align 8
  %v2268 = load i32, ptr %slot277, align 8
  %op2269 = and i32 %v2268, 28
  store i32 %op2269, ptr %slot278, align 8
  %v2270 = load i32, ptr %slot278, align 8
  %cv2271 = zext i32 %v2270 to i64
  %cond2272 = icmp ne i64 %cv2271, 0
  br i1 %cond2272, label %bb_rcslotrole333, label %bb_rcslotowner333
bb_rcslotrole333:
  %v2273 = load i64, ptr %slot39, align 8
  store i64 %v2273, ptr %slot279, align 8
  %v2274 = load i64, ptr %slot276, align 8
  %p2275 = inttoptr i64 %v2274 to ptr
  %ld2276 = load i64, ptr %p2275, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2276, ptr %slot280, align 8
  %v2277 = load i64, ptr %slot280, align 8
  %cmp2278 = icmp ne i64 %v2277, 0
  %cv2279 = zext i1 %cmp2278 to i32
  store i32 %cv2279, ptr %slot281, align 8
  %v2280 = load i32, ptr %slot281, align 8
  %cv2281 = zext i32 %v2280 to i64
  %cond2282 = icmp ne i64 %cv2281, 0
  br i1 %cond2282, label %bb_rcgnn349, label %bb_rcgdone349
bb_rcgnn349:
  %v2283 = load i64, ptr %slot280, align 8
  %op2284 = sub i64 %v2283, 16
  store i64 %op2284, ptr %slot282, align 8
  %v2285 = load i64, ptr %slot280, align 8
  %p2286 = inttoptr i64 %v2285 to ptr
  %rgep2287 = getelementptr i8, ptr %p2286, i64 -16
  %ld2288 = load i64, ptr %rgep2287, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2288, ptr %slot283, align 8
  %v2289 = load i64, ptr %slot283, align 8
  %op2290 = and i64 %v2289, 4611686018427387906
  store i64 %op2290, ptr %slot284, align 8
  %v2291 = load i64, ptr %slot284, align 8
  %cmp2292 = icmp ne i64 %v2291, 0
  %cv2293 = zext i1 %cmp2292 to i32
  store i32 %cv2293, ptr %slot285, align 8
  %v2294 = load i32, ptr %slot285, align 8
  %cv2295 = zext i32 %v2294 to i64
  %cond2296 = icmp ne i64 %cv2295, 0
  br i1 %cond2296, label %bb_rcgclear349, label %bb_rcgcounted349
bb_rcgcounted349:
  %v2297 = load i64, ptr %slot280, align 8
  %op2298 = sub i64 %v2297, 24
  store i64 %op2298, ptr %slot286, align 8
  %v2299 = load i64, ptr %slot280, align 8
  %p2300 = inttoptr i64 %v2299 to ptr
  %rgep2301 = getelementptr i8, ptr %p2300, i64 -24
  %ld2302 = load i64, ptr %rgep2301, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2302, ptr %slot287, align 8
  %v2303 = load i64, ptr %slot287, align 8
  %op2304 = sub i64 %v2303, 1
  store i64 %op2304, ptr %slot288, align 8
  %v2305 = load i64, ptr %slot288, align 8
  %cmp2306 = icmp eq i64 %v2305, 0
  %cv2307 = zext i1 %cmp2306 to i32
  store i32 %cv2307, ptr %slot289, align 8
  %v2308 = load i32, ptr %slot289, align 8
  %cv2309 = zext i32 %v2308 to i64
  %cond2310 = icmp ne i64 %cv2309, 0
  br i1 %cond2310, label %bb_rcglast349, label %bb_rcgdec349
bb_rcglast349:
  %v2311 = load i64, ptr %slot280, align 8
  %op2312 = sub i64 %v2311, 32
  store i64 %op2312, ptr %slot290, align 8
  %v2313 = load i64, ptr %slot280, align 8
  %p2314 = inttoptr i64 %v2313 to ptr
  %rgep2315 = getelementptr i8, ptr %p2314, i64 -32
  %ld2316 = load i64, ptr %rgep2315, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2316, ptr %slot291, align 8
  %v2317 = load i64, ptr %slot291, align 8
  %cmp2318 = icmp ne i64 %v2317, 0
  %cv2319 = zext i1 %cmp2318 to i32
  store i32 %cv2319, ptr %slot292, align 8
  %v2320 = load i32, ptr %slot292, align 8
  %cv2321 = zext i32 %v2320 to i64
  %cond2322 = icmp ne i64 %cv2321, 0
  br i1 %cond2322, label %bb_rcgdec349, label %bb_rcgslow349
bb_rcgslow349:
  %v2323 = load i64, ptr %slot279, align 8
  %v2324 = load i64, ptr %slot276, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v2323, i64 %v2324) nomerge, !dbg !128
  br label %bb_rcgdone349
bb_rcgdec349:
  %v2325 = load i64, ptr %slot288, align 8
  %v2326 = load i64, ptr %slot280, align 8
  %p2327 = inttoptr i64 %v2326 to ptr
  %rgep2328 = getelementptr i8, ptr %p2327, i64 -24
  store i64 %v2325, ptr %rgep2328, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear349
bb_rcgclear349:
  %v2329 = load i64, ptr %slot276, align 8
  %p2330 = inttoptr i64 %v2329 to ptr
  store i64 0, ptr %p2330, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone349
bb_rcgdone349:
  br label %bb_rcslotdone333
bb_rcslotowner333:
  %v2331 = load i64, ptr %slot39, align 8
  store i64 %v2331, ptr %slot293, align 8
  %v2332 = load i64, ptr %slot276, align 8
  %p2333 = inttoptr i64 %v2332 to ptr
  %ld2334 = load i64, ptr %p2333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2334, ptr %slot294, align 8
  %v2335 = load i64, ptr %slot294, align 8
  %cmp2336 = icmp ne i64 %v2335, 0
  %cv2337 = zext i1 %cmp2336 to i32
  store i32 %cv2337, ptr %slot295, align 8
  %v2338 = load i32, ptr %slot295, align 8
  %cv2339 = zext i32 %v2338 to i64
  %cond2340 = icmp ne i64 %cv2339, 0
  br i1 %cond2340, label %bb_rcgnn364, label %bb_rcgdone364
bb_rcgnn364:
  %v2341 = load i64, ptr %slot294, align 8
  %op2342 = sub i64 %v2341, 16
  store i64 %op2342, ptr %slot296, align 8
  %v2343 = load i64, ptr %slot294, align 8
  %p2344 = inttoptr i64 %v2343 to ptr
  %rgep2345 = getelementptr i8, ptr %p2344, i64 -16
  %ld2346 = load i64, ptr %rgep2345, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2346, ptr %slot297, align 8
  %v2347 = load i64, ptr %slot297, align 8
  %op2348 = and i64 %v2347, 4611686018427387906
  store i64 %op2348, ptr %slot298, align 8
  %v2349 = load i64, ptr %slot298, align 8
  %cmp2350 = icmp ne i64 %v2349, 0
  %cv2351 = zext i1 %cmp2350 to i32
  store i32 %cv2351, ptr %slot299, align 8
  %v2352 = load i32, ptr %slot299, align 8
  %cv2353 = zext i32 %v2352 to i64
  %cond2354 = icmp ne i64 %cv2353, 0
  br i1 %cond2354, label %bb_rcgclear364, label %bb_rcgcounted364
bb_rcgcounted364:
  %v2355 = load i64, ptr %slot294, align 8
  %op2356 = sub i64 %v2355, 32
  store i64 %op2356, ptr %slot300, align 8
  %v2357 = load i64, ptr %slot294, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  %rgep2359 = getelementptr i8, ptr %p2358, i64 -32
  %ld2360 = load i64, ptr %rgep2359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2360, ptr %slot301, align 8
  %v2361 = load i64, ptr %slot301, align 8
  %op2362 = sub i64 %v2361, 1
  store i64 %op2362, ptr %slot302, align 8
  %v2363 = load i64, ptr %slot302, align 8
  %cmp2364 = icmp eq i64 %v2363, 0
  %cv2365 = zext i1 %cmp2364 to i32
  store i32 %cv2365, ptr %slot303, align 8
  %v2366 = load i32, ptr %slot303, align 8
  %cv2367 = zext i32 %v2366 to i64
  %cond2368 = icmp ne i64 %cv2367, 0
  br i1 %cond2368, label %bb_rcglast364, label %bb_rcgdec364
bb_rcglast364:
  %v2369 = load i64, ptr %slot294, align 8
  %op2370 = sub i64 %v2369, 24
  store i64 %op2370, ptr %slot304, align 8
  %v2371 = load i64, ptr %slot294, align 8
  %p2372 = inttoptr i64 %v2371 to ptr
  %rgep2373 = getelementptr i8, ptr %p2372, i64 -24
  %ld2374 = load i64, ptr %rgep2373, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2374, ptr %slot305, align 8
  %v2375 = load i64, ptr %slot305, align 8
  %cmp2376 = icmp ne i64 %v2375, 0
  %cv2377 = zext i1 %cmp2376 to i32
  store i32 %cv2377, ptr %slot306, align 8
  %v2378 = load i32, ptr %slot306, align 8
  %cv2379 = zext i32 %v2378 to i64
  %cond2380 = icmp ne i64 %cv2379, 0
  br i1 %cond2380, label %bb_rcgdec364, label %bb_rcgslow364
bb_rcgslow364:
  %v2381 = load i64, ptr %slot293, align 8
  %v2382 = load i64, ptr %slot276, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v2381, i64 %v2382) nomerge, !dbg !128
  br label %bb_rcgdone364
bb_rcgdec364:
  %v2383 = load i64, ptr %slot302, align 8
  %v2384 = load i64, ptr %slot294, align 8
  %p2385 = inttoptr i64 %v2384 to ptr
  %rgep2386 = getelementptr i8, ptr %p2385, i64 -32
  store i64 %v2383, ptr %rgep2386, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear364
bb_rcgclear364:
  %v2387 = load i64, ptr %slot276, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  store i64 0, ptr %p2388, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone364
bb_rcgdone364:
  br label %bb_rcslotdone333
bb_rcslotdone333:
  %v2389 = load i64, ptr %slot27, align 8
  store i64 %v2389, ptr %slot307, align 8
  %v2390 = load i64, ptr %slot24, align 8
  store i64 %v2390, ptr %slot308, align 8
  %v2391 = load i64, ptr %slot308, align 8
  %v2392 = load i64, ptr %slot307, align 8
  %p2393 = inttoptr i64 %v2391 to ptr
  %p2394 = inttoptr i64 %v2392 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2394, ptr %p2393, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2395 = load i64, ptr %slot18, align 8
  %p2396 = inttoptr i64 %v2395 to ptr
  store i32 0, ptr %p2396, align 4, !alias.scope !3, !noalias !4
  %v2397 = load i64, ptr %slot7, align 8
  %p2398 = inttoptr i64 %v2397 to ptr
  store i32 2, ptr %p2398, align 4, !alias.scope !3, !noalias !4
  %v2399 = load i64, ptr %slot19, align 8
  %p2400 = inttoptr i64 %v2399 to ptr
  %ld2401 = load i32, ptr %p2400, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2401, ptr %slot309, align 8
  %v2402 = load i32, ptr %slot309, align 8
  %v2403 = load i64, ptr %slot7, align 8
  %p2404 = inttoptr i64 %v2403 to ptr
  store i32 %v2402, ptr %p2404, align 4, !alias.scope !3, !noalias !4
  %v2405 = load i64, ptr %slot6, align 8
  %p2406 = inttoptr i64 %v2405 to ptr
  store i32 1, ptr %p2406, align 4, !alias.scope !3, !noalias !4
  %v2407 = load i64, ptr %slot26, align 8
  %v2408 = load i64, ptr %slot33, align 8
  %p2409 = inttoptr i64 %v2408 to ptr
  store i64 %v2407, ptr %p2409, align 8, !alias.scope !3, !noalias !4
  %v2410 = load i64, ptr %slot33, align 8
  %p2411 = inttoptr i64 %v2410 to ptr
  %ld2412 = load i64, ptr %p2411, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2412, ptr %slot310, align 8
  %v2413 = load i64, ptr %slot310, align 8
  %op2414 = add i64 %v2413, 64
  store i64 %op2414, ptr %slot311, align 8
  %v2415 = load i64, ptr %slot311, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  %ld2417 = load i64, ptr %p2416, align 8
  store i64 %ld2417, ptr %slot312, align 8
  %v2418 = load i64, ptr %slot312, align 8
  %v2419 = load i64, ptr %slot33, align 8
  %p2420 = inttoptr i64 %v2419 to ptr
  store i64 %v2418, ptr %p2420, align 8, !alias.scope !3, !noalias !4
  %v2421 = load i64, ptr %slot33, align 8
  %p2422 = inttoptr i64 %v2421 to ptr
  %ld2423 = load i64, ptr %p2422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2423, ptr %slot313, align 8
  %v2424 = load i64, ptr %slot313, align 8
  %v2425 = load i64, ptr %slot22, align 8
  %p2426 = inttoptr i64 %v2425 to ptr
  store i64 %v2424, ptr %p2426, align 8, !alias.scope !3, !noalias !4
  %v2427 = load i64, ptr %slot22, align 8
  store i64 %v2427, ptr %slot314, align 8
  %v2428 = load i64, ptr %slot24, align 8
  store i64 %v2428, ptr %slot315, align 8
  %v2429 = load i64, ptr %slot314, align 8
  %p2430 = inttoptr i64 %v2429 to ptr
  %ld2431 = load i64, ptr %p2430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2431, ptr %slot316, align 8
  %v2432 = load i64, ptr %slot316, align 8
  %cmp2433 = icmp ne i64 %v2432, 0
  %cv2434 = zext i1 %cmp2433 to i32
  store i32 %cv2434, ptr %slot317, align 8
  %v2435 = load i32, ptr %slot317, align 8
  %cv2436 = zext i32 %v2435 to i64
  %cond2437 = icmp ne i64 %cv2436, 0
  br i1 %cond2437, label %bb_rcgnn382, label %bb_rcgstore382
bb_rcgnn382:
  %v2438 = load i64, ptr %slot316, align 8
  %op2439 = sub i64 %v2438, 16
  store i64 %op2439, ptr %slot318, align 8
  %v2440 = load i64, ptr %slot316, align 8
  %p2441 = inttoptr i64 %v2440 to ptr
  %rgep2442 = getelementptr i8, ptr %p2441, i64 -16
  %ld2443 = load i64, ptr %rgep2442, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2443, ptr %slot319, align 8
  %v2444 = load i64, ptr %slot319, align 8
  %op2445 = and i64 %v2444, 4611686018427387906
  store i64 %op2445, ptr %slot320, align 8
  %v2446 = load i64, ptr %slot320, align 8
  %cmp2447 = icmp ne i64 %v2446, 0
  %cv2448 = zext i1 %cmp2447 to i32
  store i32 %cv2448, ptr %slot321, align 8
  %v2449 = load i32, ptr %slot321, align 8
  %cv2450 = zext i32 %v2449 to i64
  %cond2451 = icmp ne i64 %cv2450, 0
  br i1 %cond2451, label %bb_rcgstore382, label %bb_rcginc382
bb_rcginc382:
  %v2452 = load i64, ptr %slot316, align 8
  %op2453 = sub i64 %v2452, 24
  store i64 %op2453, ptr %slot322, align 8
  %v2454 = load i64, ptr %slot316, align 8
  %p2455 = inttoptr i64 %v2454 to ptr
  %rgep2456 = getelementptr i8, ptr %p2455, i64 -24
  %ld2457 = load i64, ptr %rgep2456, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2457, ptr %slot323, align 8
  %v2458 = load i64, ptr %slot323, align 8
  %op2459 = add i64 %v2458, 1
  store i64 %op2459, ptr %slot324, align 8
  %v2460 = load i64, ptr %slot324, align 8
  %cmp2461 = icmp eq i64 %v2460, 0
  %cv2462 = zext i1 %cmp2461 to i32
  store i32 %cv2462, ptr %slot325, align 8
  %v2463 = load i32, ptr %slot325, align 8
  %cv2464 = zext i32 %v2463 to i64
  %cond2465 = icmp ne i64 %cv2464, 0
  br i1 %cond2465, label %bb_rcglimit382, label %bb_rcgcapacity382
bb_rcglimit382:
  %v2466 = load i64, ptr %slot1, align 8
  %p2467 = inttoptr i64 %v2466 to ptr
  %call2468 = call i32 @myl_qbe_rc_status(ptr %p2467, i32 2) nomerge, !dbg !130
  store i32 %call2468, ptr %slot326, align 8
  br label %bb_failure
bb_rcgcapacity382:
  %v2469 = load i64, ptr %slot324, align 8
  %v2470 = load i64, ptr %slot316, align 8
  %p2471 = inttoptr i64 %v2470 to ptr
  %rgep2472 = getelementptr i8, ptr %p2471, i64 -24
  store i64 %v2469, ptr %rgep2472, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore382
bb_rcgstore382:
  %v2473 = load i64, ptr %slot316, align 8
  %v2474 = load i64, ptr %slot315, align 8
  %p2475 = inttoptr i64 %v2474 to ptr
  store i64 %v2473, ptr %p2475, align 8, !alias.scope !3, !noalias !4
  %v2476 = load i64, ptr %slot19, align 8
  %p2477 = inttoptr i64 %v2476 to ptr
  store i32 2, ptr %p2477, align 4, !alias.scope !3, !noalias !4
  %v2478 = load i64, ptr %slot19, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  store i32 16, ptr %p2479, align 4, !alias.scope !3, !noalias !4
  %v2480 = load i64, ptr %slot18, align 8
  %p2481 = inttoptr i64 %v2480 to ptr
  store i32 1, ptr %p2481, align 4, !alias.scope !3, !noalias !4
  %v2482 = load i64, ptr %slot14, align 8
  %p2483 = inttoptr i64 %v2482 to ptr
  %ld2484 = load i32, ptr %p2483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2484, ptr %slot327, align 8
  %v2485 = load i32, ptr %slot327, align 8
  %cv2486 = zext i32 %v2485 to i64
  %cond2487 = icmp ne i64 %cv2486, 0
  br i1 %cond2487, label %bb_rcslotdrop398, label %bb_rcslotdone398
bb_rcslotdrop398:
  %v2488 = load i64, ptr %slot14, align 8
  %p2489 = inttoptr i64 %v2488 to ptr
  store i32 0, ptr %p2489, align 4, !alias.scope !3, !noalias !4
  %v2490 = load i64, ptr %slot20, align 8
  store i64 %v2490, ptr %slot328, align 8
  %v2491 = load i64, ptr %slot15, align 8
  %p2492 = inttoptr i64 %v2491 to ptr
  %ld2493 = load i32, ptr %p2492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2493, ptr %slot329, align 8
  %v2494 = load i32, ptr %slot329, align 8
  %op2495 = and i32 %v2494, 28
  store i32 %op2495, ptr %slot330, align 8
  %v2496 = load i32, ptr %slot330, align 8
  %cv2497 = zext i32 %v2496 to i64
  %cond2498 = icmp ne i64 %cv2497, 0
  br i1 %cond2498, label %bb_rcslotrole398, label %bb_rcslotowner398
bb_rcslotrole398:
  %v2499 = load i64, ptr %slot39, align 8
  store i64 %v2499, ptr %slot331, align 8
  %v2500 = load i64, ptr %slot331, align 8
  %v2501 = load i64, ptr %slot328, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v2500, i64 %v2501) nomerge, !dbg !130
  br label %bb_rcslotdone398
bb_rcslotowner398:
  %v2502 = load i64, ptr %slot39, align 8
  store i64 %v2502, ptr %slot332, align 8
  %v2503 = load i64, ptr %slot332, align 8
  %v2504 = load i64, ptr %slot328, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v2503, i64 %v2504) nomerge, !dbg !130
  br label %bb_rcslotdone398
bb_rcslotdone398:
  %v2505 = load i64, ptr %slot20, align 8
  store i64 %v2505, ptr %slot333, align 8
  %v2506 = load i64, ptr %slot24, align 8
  store i64 %v2506, ptr %slot334, align 8
  %v2507 = load i64, ptr %slot334, align 8
  %v2508 = load i64, ptr %slot333, align 8
  %p2509 = inttoptr i64 %v2507 to ptr
  %p2510 = inttoptr i64 %v2508 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2510, ptr %p2509, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2511 = load i64, ptr %slot15, align 8
  %p2512 = inttoptr i64 %v2511 to ptr
  store i32 2, ptr %p2512, align 4, !alias.scope !3, !noalias !4
  %v2513 = load i64, ptr %slot19, align 8
  %p2514 = inttoptr i64 %v2513 to ptr
  %ld2515 = load i32, ptr %p2514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2515, ptr %slot335, align 8
  %v2516 = load i32, ptr %slot335, align 8
  %v2517 = load i64, ptr %slot15, align 8
  %p2518 = inttoptr i64 %v2517 to ptr
  store i32 %v2516, ptr %p2518, align 4, !alias.scope !3, !noalias !4
  %v2519 = load i64, ptr %slot18, align 8
  %p2520 = inttoptr i64 %v2519 to ptr
  store i32 0, ptr %p2520, align 4, !alias.scope !3, !noalias !4
  %v2521 = load i64, ptr %slot14, align 8
  %p2522 = inttoptr i64 %v2521 to ptr
  store i32 1, ptr %p2522, align 4, !alias.scope !3, !noalias !4
  %v2523 = load i64, ptr %slot333, align 8
  %p2524 = inttoptr i64 %v2523 to ptr
  %ld2525 = load i64, ptr %p2524, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2525, ptr %slot336, align 8
  %v2526 = load i64, ptr %slot336, align 8
  %v2527 = load i64, ptr %slot33, align 8
  %p2528 = inttoptr i64 %v2527 to ptr
  store i64 %v2526, ptr %p2528, align 8, !alias.scope !3, !noalias !4
  %v2529 = load i64, ptr %slot33, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %ld2531 = load i64, ptr %p2530, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2531, ptr %slot337, align 8
  %v2532 = load i64, ptr %slot337, align 8
  %v2533 = load i64, ptr %slot22, align 8
  %p2534 = inttoptr i64 %v2533 to ptr
  store i64 %v2532, ptr %p2534, align 8, !alias.scope !3, !noalias !4
  %v2535 = load i64, ptr %slot22, align 8
  store i64 %v2535, ptr %slot338, align 8
  %v2536 = load i64, ptr %slot14, align 8
  %p2537 = inttoptr i64 %v2536 to ptr
  %ld2538 = load i32, ptr %p2537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2538, ptr %slot339, align 8
  %v2539 = load i64, ptr %slot15, align 8
  %p2540 = inttoptr i64 %v2539 to ptr
  %ld2541 = load i32, ptr %p2540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2541, ptr %slot340, align 8
  %v2542 = load i32, ptr %slot340, align 8
  %op2543 = and i32 %v2542, 24
  store i32 %op2543, ptr %slot340, align 8
  %v2544 = load i32, ptr %slot340, align 8
  %cmp2545 = icmp eq i32 %v2544, 0
  %cv2546 = zext i1 %cmp2545 to i32
  store i32 %cv2546, ptr %slot341, align 8
  %v2547 = load i32, ptr %slot339, align 8
  %v2548 = load i32, ptr %slot341, align 8
  %op2549 = and i32 %v2547, %v2548
  store i32 %op2549, ptr %slot342, align 8
  %v2550 = load i32, ptr %slot342, align 8
  %cv2551 = zext i32 %v2550 to i64
  %cond2552 = icmp ne i64 %cv2551, 0
  br i1 %cond2552, label %bb_rcprivateown422, label %bb_rcprivateloan422
bb_rcprivateown422:
  %v2553 = load i64, ptr %slot24, align 8
  store i64 %v2553, ptr %slot343, align 8
  %v2554 = load i64, ptr %slot40, align 8
  store i64 %v2554, ptr %slot344, align 8
  %v2555 = load i64, ptr %slot338, align 8
  %v2556 = load i64, ptr %slot343, align 8
  %op2557 = sub i64 %v2555, %v2556
  store i64 %op2557, ptr %slot345, align 8
  %v2558 = load i64, ptr %slot343, align 8
  %v2559 = load i64, ptr %slot338, align 8
  %op2560 = sub i64 %v2558, %v2559
  store i64 %op2560, ptr %slot346, align 8
  %v2561 = load i64, ptr %slot345, align 8
  %cmp2562 = icmp ult i64 %v2561, 8
  %cv2563 = zext i1 %cmp2562 to i32
  store i32 %cv2563, ptr %slot347, align 8
  %v2564 = load i64, ptr %slot346, align 8
  %cmp2565 = icmp ult i64 %v2564, 8
  %cv2566 = zext i1 %cmp2565 to i32
  store i32 %cv2566, ptr %slot348, align 8
  %v2567 = load i32, ptr %slot347, align 8
  %v2568 = load i32, ptr %slot348, align 8
  %op2569 = or i32 %v2567, %v2568
  store i32 %op2569, ptr %slot349, align 8
  %v2570 = load i32, ptr %slot349, align 8
  %cv2571 = zext i32 %v2570 to i64
  %cond2572 = icmp ne i64 %cv2571, 0
  br i1 %cond2572, label %bb_rcmoveslow425, label %bb_rcmovecheck425
bb_rcmovecheck425:
  %v2573 = load i64, ptr %slot338, align 8
  %p2575 = inttoptr i64 %v2573 to ptr
  %gep2576 = getelementptr i8, ptr %p2575, i64 0
  %op2574 = ptrtoint ptr %gep2576 to i64
  store i64 %op2574, ptr %slot350, align 8
  %v2577 = load i64, ptr %slot350, align 8
  %p2578 = inttoptr i64 %v2577 to ptr
  %ld2579 = load i64, ptr %p2578, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2579, ptr %slot351, align 8
  %v2580 = load i64, ptr %slot351, align 8
  %cmp2581 = icmp ne i64 %v2580, 0
  %cv2582 = zext i1 %cmp2581 to i32
  store i32 %cv2582, ptr %slot352, align 8
  %v2583 = load i32, ptr %slot352, align 8
  %cv2584 = zext i32 %v2583 to i64
  %cond2585 = icmp ne i64 %cv2584, 0
  br i1 %cond2585, label %bb_rcmoveheader433, label %bb_rcmovenext433
bb_rcmoveheader433:
  %v2586 = load i64, ptr %slot351, align 8
  %op2587 = sub i64 %v2586, 16
  store i64 %op2587, ptr %slot353, align 8
  %v2588 = load i64, ptr %slot351, align 8
  %p2589 = inttoptr i64 %v2588 to ptr
  %rgep2590 = getelementptr i8, ptr %p2589, i64 -16
  %ld2591 = load i64, ptr %rgep2590, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2591, ptr %slot354, align 8
  %v2592 = load i64, ptr %slot354, align 8
  %op2593 = and i64 %v2592, 5764607523034234881
  store i64 %op2593, ptr %slot355, align 8
  %v2594 = load i64, ptr %slot355, align 8
  %cmp2595 = icmp ne i64 %v2594, 0
  %cv2596 = zext i1 %cmp2595 to i32
  store i32 %cv2596, ptr %slot356, align 8
  %v2597 = load i32, ptr %slot356, align 8
  %cv2598 = zext i32 %v2597 to i64
  %cond2599 = icmp ne i64 %cv2598, 0
  br i1 %cond2599, label %bb_rcmoveslow425, label %bb_rcmovenext433
bb_rcmovenext433:
  %v2600 = load i64, ptr %slot338, align 8
  %v2601 = load i64, ptr %slot343, align 8
  %p2602 = inttoptr i64 %v2600 to ptr
  %p2603 = inttoptr i64 %v2601 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2603, ptr %p2602, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2604 = load i64, ptr %slot338, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  store i64 0, ptr %p2605, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved425
bb_rcmoveslow425:
  %v2606 = load i64, ptr %slot39, align 8
  %v2607 = load i64, ptr %slot343, align 8
  %v2608 = load i64, ptr %slot338, align 8
  %v2609 = load i64, ptr %slot344, align 8
  %cv2610 = trunc i64 %v2609 to i32
  %call2611 = call i32 @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_take(i64 %v2606, i64 %v2607, i64 %v2608, i32 %cv2610) nomerge, !dbg !132
  store i32 %call2611, ptr %slot357, align 8
  %v2612 = load i32, ptr %slot357, align 8
  %cv2613 = zext i32 %v2612 to i64
  %cond2614 = icmp ne i64 %cv2613, 0
  br i1 %cond2614, label %bb_rcsuccess440, label %bb_rcfailure440
bb_rcfailure440:
  %v2615 = load i64, ptr %slot39, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  %call2617 = call i32 @myl_rc_take_failure(ptr %p2616) nomerge, !dbg !132
  store i32 %call2617, ptr %slot358, align 8
  %v2618 = load i64, ptr %slot1, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  %v2620 = load i32, ptr %slot358, align 8
  %call2621 = call i32 @myl_qbe_rc_status(ptr %p2619, i32 %v2620) nomerge, !dbg !132
  store i32 %call2621, ptr %slot359, align 8
  br label %bb_failure
bb_rcsuccess440:
  br label %bb_rcmoved425
bb_rcmoved425:
  %v2622 = load i64, ptr %slot14, align 8
  %p2623 = inttoptr i64 %v2622 to ptr
  store i32 0, ptr %p2623, align 4, !alias.scope !3, !noalias !4
  %v2624 = load i64, ptr %slot19, align 8
  %p2625 = inttoptr i64 %v2624 to ptr
  store i32 2, ptr %p2625, align 4, !alias.scope !3, !noalias !4
  %v2626 = load i64, ptr %slot18, align 8
  %p2627 = inttoptr i64 %v2626 to ptr
  store i32 1, ptr %p2627, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared422
bb_rcprivateloan422:
  %v2628 = load i64, ptr %slot14, align 8
  %p2629 = inttoptr i64 %v2628 to ptr
  %ld2630 = load i32, ptr %p2629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2630, ptr %slot360, align 8
  %v2631 = load i64, ptr %slot15, align 8
  %p2632 = inttoptr i64 %v2631 to ptr
  %ld2633 = load i32, ptr %p2632, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2633, ptr %slot361, align 8
  %v2634 = load i32, ptr %slot361, align 8
  %cmp2635 = icmp eq i32 %v2634, 16
  %cv2636 = zext i1 %cmp2635 to i32
  store i32 %cv2636, ptr %slot362, align 8
  %v2637 = load i32, ptr %slot362, align 8
  %v2638 = load i32, ptr %slot360, align 8
  %op2639 = and i32 %v2637, %v2638
  store i32 %op2639, ptr %slot362, align 8
  %v2640 = load i32, ptr %slot362, align 8
  %cv2641 = zext i32 %v2640 to i64
  %cond2642 = icmp ne i64 %cv2641, 0
  br i1 %cond2642, label %bb_rcprivatemove422, label %bb_rcprivatenew422
bb_rcprivatemove422:
  %v2643 = load i64, ptr %slot24, align 8
  store i64 %v2643, ptr %slot363, align 8
  %v2644 = load i64, ptr %slot338, align 8
  %v2645 = load i64, ptr %slot363, align 8
  %p2646 = inttoptr i64 %v2644 to ptr
  %p2647 = inttoptr i64 %v2645 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2647, ptr %p2646, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2648 = load i64, ptr %slot338, align 8
  %p2649 = inttoptr i64 %v2648 to ptr
  store i64 0, ptr %p2649, align 8, !alias.scope !3, !noalias !4
  %v2650 = load i64, ptr %slot19, align 8
  %p2651 = inttoptr i64 %v2650 to ptr
  store i32 2, ptr %p2651, align 4, !alias.scope !3, !noalias !4
  %v2652 = load i64, ptr %slot19, align 8
  %p2653 = inttoptr i64 %v2652 to ptr
  store i32 16, ptr %p2653, align 4, !alias.scope !3, !noalias !4
  %v2654 = load i64, ptr %slot18, align 8
  %p2655 = inttoptr i64 %v2654 to ptr
  store i32 1, ptr %p2655, align 4, !alias.scope !3, !noalias !4
  %v2656 = load i64, ptr %slot14, align 8
  %p2657 = inttoptr i64 %v2656 to ptr
  store i32 0, ptr %p2657, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared422
bb_rcprivatenew422:
  %v2658 = load i64, ptr %slot24, align 8
  store i64 %v2658, ptr %slot364, align 8
  %v2659 = load i64, ptr %slot338, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  %ld2661 = load i64, ptr %p2660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2661, ptr %slot365, align 8
  %v2662 = load i64, ptr %slot365, align 8
  %cmp2663 = icmp ne i64 %v2662, 0
  %cv2664 = zext i1 %cmp2663 to i32
  store i32 %cv2664, ptr %slot366, align 8
  %v2665 = load i32, ptr %slot366, align 8
  %cv2666 = zext i32 %v2665 to i64
  %cond2667 = icmp ne i64 %cv2666, 0
  br i1 %cond2667, label %bb_rcgnn458, label %bb_rcgstore458
bb_rcgnn458:
  %v2668 = load i64, ptr %slot365, align 8
  %op2669 = sub i64 %v2668, 16
  store i64 %op2669, ptr %slot367, align 8
  %v2670 = load i64, ptr %slot365, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  %rgep2672 = getelementptr i8, ptr %p2671, i64 -16
  %ld2673 = load i64, ptr %rgep2672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2673, ptr %slot368, align 8
  %v2674 = load i64, ptr %slot368, align 8
  %op2675 = and i64 %v2674, 4611686018427387906
  store i64 %op2675, ptr %slot369, align 8
  %v2676 = load i64, ptr %slot369, align 8
  %cmp2677 = icmp ne i64 %v2676, 0
  %cv2678 = zext i1 %cmp2677 to i32
  store i32 %cv2678, ptr %slot370, align 8
  %v2679 = load i32, ptr %slot370, align 8
  %cv2680 = zext i32 %v2679 to i64
  %cond2681 = icmp ne i64 %cv2680, 0
  br i1 %cond2681, label %bb_rcgstore458, label %bb_rcginc458
bb_rcginc458:
  %v2682 = load i64, ptr %slot365, align 8
  %op2683 = sub i64 %v2682, 24
  store i64 %op2683, ptr %slot371, align 8
  %v2684 = load i64, ptr %slot365, align 8
  %p2685 = inttoptr i64 %v2684 to ptr
  %rgep2686 = getelementptr i8, ptr %p2685, i64 -24
  %ld2687 = load i64, ptr %rgep2686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2687, ptr %slot372, align 8
  %v2688 = load i64, ptr %slot372, align 8
  %op2689 = add i64 %v2688, 1
  store i64 %op2689, ptr %slot373, align 8
  %v2690 = load i64, ptr %slot373, align 8
  %cmp2691 = icmp eq i64 %v2690, 0
  %cv2692 = zext i1 %cmp2691 to i32
  store i32 %cv2692, ptr %slot374, align 8
  %v2693 = load i32, ptr %slot374, align 8
  %cv2694 = zext i32 %v2693 to i64
  %cond2695 = icmp ne i64 %cv2694, 0
  br i1 %cond2695, label %bb_rcglimit458, label %bb_rcgcapacity458
bb_rcglimit458:
  %v2696 = load i64, ptr %slot1, align 8
  %p2697 = inttoptr i64 %v2696 to ptr
  %call2698 = call i32 @myl_qbe_rc_status(ptr %p2697, i32 2) nomerge, !dbg !132
  store i32 %call2698, ptr %slot375, align 8
  br label %bb_failure
bb_rcgcapacity458:
  %v2699 = load i64, ptr %slot373, align 8
  %v2700 = load i64, ptr %slot365, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  %rgep2702 = getelementptr i8, ptr %p2701, i64 -24
  store i64 %v2699, ptr %rgep2702, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore458
bb_rcgstore458:
  %v2703 = load i64, ptr %slot365, align 8
  %v2704 = load i64, ptr %slot364, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  store i64 %v2703, ptr %p2705, align 8, !alias.scope !3, !noalias !4
  %v2706 = load i64, ptr %slot19, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  store i32 2, ptr %p2707, align 4, !alias.scope !3, !noalias !4
  %v2708 = load i64, ptr %slot19, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  store i32 16, ptr %p2709, align 4, !alias.scope !3, !noalias !4
  %v2710 = load i64, ptr %slot18, align 8
  %p2711 = inttoptr i64 %v2710 to ptr
  store i32 1, ptr %p2711, align 4, !alias.scope !3, !noalias !4
  %v2712 = load i64, ptr %slot14, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  %ld2714 = load i32, ptr %p2713, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2714, ptr %slot376, align 8
  %v2715 = load i32, ptr %slot376, align 8
  %cv2716 = zext i32 %v2715 to i64
  %cond2717 = icmp ne i64 %cv2716, 0
  br i1 %cond2717, label %bb_rcslotdrop474, label %bb_rcslotdone474
bb_rcslotdrop474:
  %v2718 = load i64, ptr %slot14, align 8
  %p2719 = inttoptr i64 %v2718 to ptr
  store i32 0, ptr %p2719, align 4, !alias.scope !3, !noalias !4
  %v2720 = load i64, ptr %slot20, align 8
  store i64 %v2720, ptr %slot377, align 8
  %v2721 = load i64, ptr %slot15, align 8
  %p2722 = inttoptr i64 %v2721 to ptr
  %ld2723 = load i32, ptr %p2722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2723, ptr %slot378, align 8
  %v2724 = load i32, ptr %slot378, align 8
  %op2725 = and i32 %v2724, 28
  store i32 %op2725, ptr %slot379, align 8
  %v2726 = load i32, ptr %slot379, align 8
  %cv2727 = zext i32 %v2726 to i64
  %cond2728 = icmp ne i64 %cv2727, 0
  br i1 %cond2728, label %bb_rcslotrole474, label %bb_rcslotowner474
bb_rcslotrole474:
  %v2729 = load i64, ptr %slot39, align 8
  store i64 %v2729, ptr %slot380, align 8
  %v2730 = load i64, ptr %slot377, align 8
  %p2731 = inttoptr i64 %v2730 to ptr
  %ld2732 = load i64, ptr %p2731, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2732, ptr %slot381, align 8
  %v2733 = load i64, ptr %slot381, align 8
  %cmp2734 = icmp ne i64 %v2733, 0
  %cv2735 = zext i1 %cmp2734 to i32
  store i32 %cv2735, ptr %slot382, align 8
  %v2736 = load i32, ptr %slot382, align 8
  %cv2737 = zext i32 %v2736 to i64
  %cond2738 = icmp ne i64 %cv2737, 0
  br i1 %cond2738, label %bb_rcgnn490, label %bb_rcgdone490
bb_rcgnn490:
  %v2739 = load i64, ptr %slot381, align 8
  %op2740 = sub i64 %v2739, 16
  store i64 %op2740, ptr %slot383, align 8
  %v2741 = load i64, ptr %slot381, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  %rgep2743 = getelementptr i8, ptr %p2742, i64 -16
  %ld2744 = load i64, ptr %rgep2743, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2744, ptr %slot384, align 8
  %v2745 = load i64, ptr %slot384, align 8
  %op2746 = and i64 %v2745, 4611686018427387906
  store i64 %op2746, ptr %slot385, align 8
  %v2747 = load i64, ptr %slot385, align 8
  %cmp2748 = icmp ne i64 %v2747, 0
  %cv2749 = zext i1 %cmp2748 to i32
  store i32 %cv2749, ptr %slot386, align 8
  %v2750 = load i32, ptr %slot386, align 8
  %cv2751 = zext i32 %v2750 to i64
  %cond2752 = icmp ne i64 %cv2751, 0
  br i1 %cond2752, label %bb_rcgclear490, label %bb_rcgcounted490
bb_rcgcounted490:
  %v2753 = load i64, ptr %slot381, align 8
  %op2754 = sub i64 %v2753, 24
  store i64 %op2754, ptr %slot387, align 8
  %v2755 = load i64, ptr %slot381, align 8
  %p2756 = inttoptr i64 %v2755 to ptr
  %rgep2757 = getelementptr i8, ptr %p2756, i64 -24
  %ld2758 = load i64, ptr %rgep2757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2758, ptr %slot388, align 8
  %v2759 = load i64, ptr %slot388, align 8
  %op2760 = sub i64 %v2759, 1
  store i64 %op2760, ptr %slot389, align 8
  %v2761 = load i64, ptr %slot389, align 8
  %cmp2762 = icmp eq i64 %v2761, 0
  %cv2763 = zext i1 %cmp2762 to i32
  store i32 %cv2763, ptr %slot390, align 8
  %v2764 = load i32, ptr %slot390, align 8
  %cv2765 = zext i32 %v2764 to i64
  %cond2766 = icmp ne i64 %cv2765, 0
  br i1 %cond2766, label %bb_rcglast490, label %bb_rcgdec490
bb_rcglast490:
  %v2767 = load i64, ptr %slot381, align 8
  %op2768 = sub i64 %v2767, 32
  store i64 %op2768, ptr %slot391, align 8
  %v2769 = load i64, ptr %slot381, align 8
  %p2770 = inttoptr i64 %v2769 to ptr
  %rgep2771 = getelementptr i8, ptr %p2770, i64 -32
  %ld2772 = load i64, ptr %rgep2771, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2772, ptr %slot392, align 8
  %v2773 = load i64, ptr %slot392, align 8
  %cmp2774 = icmp ne i64 %v2773, 0
  %cv2775 = zext i1 %cmp2774 to i32
  store i32 %cv2775, ptr %slot393, align 8
  %v2776 = load i32, ptr %slot393, align 8
  %cv2777 = zext i32 %v2776 to i64
  %cond2778 = icmp ne i64 %cv2777, 0
  br i1 %cond2778, label %bb_rcgdec490, label %bb_rcgslow490
bb_rcgslow490:
  %v2779 = load i64, ptr %slot380, align 8
  %v2780 = load i64, ptr %slot377, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v2779, i64 %v2780) nomerge, !dbg !132
  br label %bb_rcgdone490
bb_rcgdec490:
  %v2781 = load i64, ptr %slot389, align 8
  %v2782 = load i64, ptr %slot381, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  %rgep2784 = getelementptr i8, ptr %p2783, i64 -24
  store i64 %v2781, ptr %rgep2784, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear490
bb_rcgclear490:
  %v2785 = load i64, ptr %slot377, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  store i64 0, ptr %p2786, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone490
bb_rcgdone490:
  br label %bb_rcslotdone474
bb_rcslotowner474:
  %v2787 = load i64, ptr %slot39, align 8
  store i64 %v2787, ptr %slot394, align 8
  %v2788 = load i64, ptr %slot377, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  %ld2790 = load i64, ptr %p2789, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2790, ptr %slot395, align 8
  %v2791 = load i64, ptr %slot395, align 8
  %cmp2792 = icmp ne i64 %v2791, 0
  %cv2793 = zext i1 %cmp2792 to i32
  store i32 %cv2793, ptr %slot396, align 8
  %v2794 = load i32, ptr %slot396, align 8
  %cv2795 = zext i32 %v2794 to i64
  %cond2796 = icmp ne i64 %cv2795, 0
  br i1 %cond2796, label %bb_rcgnn505, label %bb_rcgdone505
bb_rcgnn505:
  %v2797 = load i64, ptr %slot395, align 8
  %op2798 = sub i64 %v2797, 16
  store i64 %op2798, ptr %slot397, align 8
  %v2799 = load i64, ptr %slot395, align 8
  %p2800 = inttoptr i64 %v2799 to ptr
  %rgep2801 = getelementptr i8, ptr %p2800, i64 -16
  %ld2802 = load i64, ptr %rgep2801, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2802, ptr %slot398, align 8
  %v2803 = load i64, ptr %slot398, align 8
  %op2804 = and i64 %v2803, 4611686018427387906
  store i64 %op2804, ptr %slot399, align 8
  %v2805 = load i64, ptr %slot399, align 8
  %cmp2806 = icmp ne i64 %v2805, 0
  %cv2807 = zext i1 %cmp2806 to i32
  store i32 %cv2807, ptr %slot400, align 8
  %v2808 = load i32, ptr %slot400, align 8
  %cv2809 = zext i32 %v2808 to i64
  %cond2810 = icmp ne i64 %cv2809, 0
  br i1 %cond2810, label %bb_rcgclear505, label %bb_rcgcounted505
bb_rcgcounted505:
  %v2811 = load i64, ptr %slot395, align 8
  %op2812 = sub i64 %v2811, 32
  store i64 %op2812, ptr %slot401, align 8
  %v2813 = load i64, ptr %slot395, align 8
  %p2814 = inttoptr i64 %v2813 to ptr
  %rgep2815 = getelementptr i8, ptr %p2814, i64 -32
  %ld2816 = load i64, ptr %rgep2815, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2816, ptr %slot402, align 8
  %v2817 = load i64, ptr %slot402, align 8
  %op2818 = sub i64 %v2817, 1
  store i64 %op2818, ptr %slot403, align 8
  %v2819 = load i64, ptr %slot403, align 8
  %cmp2820 = icmp eq i64 %v2819, 0
  %cv2821 = zext i1 %cmp2820 to i32
  store i32 %cv2821, ptr %slot404, align 8
  %v2822 = load i32, ptr %slot404, align 8
  %cv2823 = zext i32 %v2822 to i64
  %cond2824 = icmp ne i64 %cv2823, 0
  br i1 %cond2824, label %bb_rcglast505, label %bb_rcgdec505
bb_rcglast505:
  %v2825 = load i64, ptr %slot395, align 8
  %op2826 = sub i64 %v2825, 24
  store i64 %op2826, ptr %slot405, align 8
  %v2827 = load i64, ptr %slot395, align 8
  %p2828 = inttoptr i64 %v2827 to ptr
  %rgep2829 = getelementptr i8, ptr %p2828, i64 -24
  %ld2830 = load i64, ptr %rgep2829, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2830, ptr %slot406, align 8
  %v2831 = load i64, ptr %slot406, align 8
  %cmp2832 = icmp ne i64 %v2831, 0
  %cv2833 = zext i1 %cmp2832 to i32
  store i32 %cv2833, ptr %slot407, align 8
  %v2834 = load i32, ptr %slot407, align 8
  %cv2835 = zext i32 %v2834 to i64
  %cond2836 = icmp ne i64 %cv2835, 0
  br i1 %cond2836, label %bb_rcgdec505, label %bb_rcgslow505
bb_rcgslow505:
  %v2837 = load i64, ptr %slot394, align 8
  %v2838 = load i64, ptr %slot377, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v2837, i64 %v2838) nomerge, !dbg !132
  br label %bb_rcgdone505
bb_rcgdec505:
  %v2839 = load i64, ptr %slot403, align 8
  %v2840 = load i64, ptr %slot395, align 8
  %p2841 = inttoptr i64 %v2840 to ptr
  %rgep2842 = getelementptr i8, ptr %p2841, i64 -32
  store i64 %v2839, ptr %rgep2842, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear505
bb_rcgclear505:
  %v2843 = load i64, ptr %slot377, align 8
  %p2844 = inttoptr i64 %v2843 to ptr
  store i64 0, ptr %p2844, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone505
bb_rcgdone505:
  br label %bb_rcslotdone474
bb_rcslotdone474:
  br label %bb_rcprivateprepared422
bb_rcprivateprepared422:
  %v2845 = load i64, ptr %slot8, align 8
  %p2846 = inttoptr i64 %v2845 to ptr
  %ld2847 = load i32, ptr %p2846, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2847, ptr %slot408, align 8
  %v2848 = load i32, ptr %slot408, align 8
  %cv2849 = zext i32 %v2848 to i64
  %cond2850 = icmp ne i64 %cv2849, 0
  br i1 %cond2850, label %bb_rcslotdrop512, label %bb_rcslotdone512
bb_rcslotdrop512:
  %v2851 = load i64, ptr %slot8, align 8
  %p2852 = inttoptr i64 %v2851 to ptr
  store i32 0, ptr %p2852, align 4, !alias.scope !3, !noalias !4
  %v2853 = load i64, ptr %slot28, align 8
  store i64 %v2853, ptr %slot409, align 8
  %v2854 = load i64, ptr %slot9, align 8
  %p2855 = inttoptr i64 %v2854 to ptr
  %ld2856 = load i32, ptr %p2855, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2856, ptr %slot410, align 8
  %v2857 = load i32, ptr %slot410, align 8
  %op2858 = and i32 %v2857, 28
  store i32 %op2858, ptr %slot411, align 8
  %v2859 = load i32, ptr %slot411, align 8
  %cv2860 = zext i32 %v2859 to i64
  %cond2861 = icmp ne i64 %cv2860, 0
  br i1 %cond2861, label %bb_rcslotrole512, label %bb_rcslotowner512
bb_rcslotrole512:
  %v2862 = load i64, ptr %slot39, align 8
  store i64 %v2862, ptr %slot412, align 8
  %v2863 = load i64, ptr %slot409, align 8
  %p2864 = inttoptr i64 %v2863 to ptr
  %ld2865 = load i64, ptr %p2864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2865, ptr %slot413, align 8
  %v2866 = load i64, ptr %slot413, align 8
  %cmp2867 = icmp ne i64 %v2866, 0
  %cv2868 = zext i1 %cmp2867 to i32
  store i32 %cv2868, ptr %slot414, align 8
  %v2869 = load i32, ptr %slot414, align 8
  %cv2870 = zext i32 %v2869 to i64
  %cond2871 = icmp ne i64 %cv2870, 0
  br i1 %cond2871, label %bb_rcgnn528, label %bb_rcgdone528
bb_rcgnn528:
  %v2872 = load i64, ptr %slot413, align 8
  %op2873 = sub i64 %v2872, 16
  store i64 %op2873, ptr %slot415, align 8
  %v2874 = load i64, ptr %slot413, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  %rgep2876 = getelementptr i8, ptr %p2875, i64 -16
  %ld2877 = load i64, ptr %rgep2876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2877, ptr %slot416, align 8
  %v2878 = load i64, ptr %slot416, align 8
  %op2879 = and i64 %v2878, 4611686018427387906
  store i64 %op2879, ptr %slot417, align 8
  %v2880 = load i64, ptr %slot417, align 8
  %cmp2881 = icmp ne i64 %v2880, 0
  %cv2882 = zext i1 %cmp2881 to i32
  store i32 %cv2882, ptr %slot418, align 8
  %v2883 = load i32, ptr %slot418, align 8
  %cv2884 = zext i32 %v2883 to i64
  %cond2885 = icmp ne i64 %cv2884, 0
  br i1 %cond2885, label %bb_rcgclear528, label %bb_rcgcounted528
bb_rcgcounted528:
  %v2886 = load i64, ptr %slot413, align 8
  %op2887 = sub i64 %v2886, 24
  store i64 %op2887, ptr %slot419, align 8
  %v2888 = load i64, ptr %slot413, align 8
  %p2889 = inttoptr i64 %v2888 to ptr
  %rgep2890 = getelementptr i8, ptr %p2889, i64 -24
  %ld2891 = load i64, ptr %rgep2890, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2891, ptr %slot420, align 8
  %v2892 = load i64, ptr %slot420, align 8
  %op2893 = sub i64 %v2892, 1
  store i64 %op2893, ptr %slot421, align 8
  %v2894 = load i64, ptr %slot421, align 8
  %cmp2895 = icmp eq i64 %v2894, 0
  %cv2896 = zext i1 %cmp2895 to i32
  store i32 %cv2896, ptr %slot422, align 8
  %v2897 = load i32, ptr %slot422, align 8
  %cv2898 = zext i32 %v2897 to i64
  %cond2899 = icmp ne i64 %cv2898, 0
  br i1 %cond2899, label %bb_rcglast528, label %bb_rcgdec528
bb_rcglast528:
  %v2900 = load i64, ptr %slot413, align 8
  %op2901 = sub i64 %v2900, 32
  store i64 %op2901, ptr %slot423, align 8
  %v2902 = load i64, ptr %slot413, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  %rgep2904 = getelementptr i8, ptr %p2903, i64 -32
  %ld2905 = load i64, ptr %rgep2904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2905, ptr %slot424, align 8
  %v2906 = load i64, ptr %slot424, align 8
  %cmp2907 = icmp ne i64 %v2906, 0
  %cv2908 = zext i1 %cmp2907 to i32
  store i32 %cv2908, ptr %slot425, align 8
  %v2909 = load i32, ptr %slot425, align 8
  %cv2910 = zext i32 %v2909 to i64
  %cond2911 = icmp ne i64 %cv2910, 0
  br i1 %cond2911, label %bb_rcgdec528, label %bb_rcgslow528
bb_rcgslow528:
  %v2912 = load i64, ptr %slot412, align 8
  %v2913 = load i64, ptr %slot409, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v2912, i64 %v2913) nomerge, !dbg !132
  br label %bb_rcgdone528
bb_rcgdec528:
  %v2914 = load i64, ptr %slot421, align 8
  %v2915 = load i64, ptr %slot413, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %rgep2917 = getelementptr i8, ptr %p2916, i64 -24
  store i64 %v2914, ptr %rgep2917, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear528
bb_rcgclear528:
  %v2918 = load i64, ptr %slot409, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  store i64 0, ptr %p2919, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone528
bb_rcgdone528:
  br label %bb_rcslotdone512
bb_rcslotowner512:
  %v2920 = load i64, ptr %slot39, align 8
  store i64 %v2920, ptr %slot426, align 8
  %v2921 = load i64, ptr %slot409, align 8
  %p2922 = inttoptr i64 %v2921 to ptr
  %ld2923 = load i64, ptr %p2922, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2923, ptr %slot427, align 8
  %v2924 = load i64, ptr %slot427, align 8
  %cmp2925 = icmp ne i64 %v2924, 0
  %cv2926 = zext i1 %cmp2925 to i32
  store i32 %cv2926, ptr %slot428, align 8
  %v2927 = load i32, ptr %slot428, align 8
  %cv2928 = zext i32 %v2927 to i64
  %cond2929 = icmp ne i64 %cv2928, 0
  br i1 %cond2929, label %bb_rcgnn543, label %bb_rcgdone543
bb_rcgnn543:
  %v2930 = load i64, ptr %slot427, align 8
  %op2931 = sub i64 %v2930, 16
  store i64 %op2931, ptr %slot429, align 8
  %v2932 = load i64, ptr %slot427, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  %rgep2934 = getelementptr i8, ptr %p2933, i64 -16
  %ld2935 = load i64, ptr %rgep2934, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2935, ptr %slot430, align 8
  %v2936 = load i64, ptr %slot430, align 8
  %op2937 = and i64 %v2936, 4611686018427387906
  store i64 %op2937, ptr %slot431, align 8
  %v2938 = load i64, ptr %slot431, align 8
  %cmp2939 = icmp ne i64 %v2938, 0
  %cv2940 = zext i1 %cmp2939 to i32
  store i32 %cv2940, ptr %slot432, align 8
  %v2941 = load i32, ptr %slot432, align 8
  %cv2942 = zext i32 %v2941 to i64
  %cond2943 = icmp ne i64 %cv2942, 0
  br i1 %cond2943, label %bb_rcgclear543, label %bb_rcgcounted543
bb_rcgcounted543:
  %v2944 = load i64, ptr %slot427, align 8
  %op2945 = sub i64 %v2944, 32
  store i64 %op2945, ptr %slot433, align 8
  %v2946 = load i64, ptr %slot427, align 8
  %p2947 = inttoptr i64 %v2946 to ptr
  %rgep2948 = getelementptr i8, ptr %p2947, i64 -32
  %ld2949 = load i64, ptr %rgep2948, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2949, ptr %slot434, align 8
  %v2950 = load i64, ptr %slot434, align 8
  %op2951 = sub i64 %v2950, 1
  store i64 %op2951, ptr %slot435, align 8
  %v2952 = load i64, ptr %slot435, align 8
  %cmp2953 = icmp eq i64 %v2952, 0
  %cv2954 = zext i1 %cmp2953 to i32
  store i32 %cv2954, ptr %slot436, align 8
  %v2955 = load i32, ptr %slot436, align 8
  %cv2956 = zext i32 %v2955 to i64
  %cond2957 = icmp ne i64 %cv2956, 0
  br i1 %cond2957, label %bb_rcglast543, label %bb_rcgdec543
bb_rcglast543:
  %v2958 = load i64, ptr %slot427, align 8
  %op2959 = sub i64 %v2958, 24
  store i64 %op2959, ptr %slot437, align 8
  %v2960 = load i64, ptr %slot427, align 8
  %p2961 = inttoptr i64 %v2960 to ptr
  %rgep2962 = getelementptr i8, ptr %p2961, i64 -24
  %ld2963 = load i64, ptr %rgep2962, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2963, ptr %slot438, align 8
  %v2964 = load i64, ptr %slot438, align 8
  %cmp2965 = icmp ne i64 %v2964, 0
  %cv2966 = zext i1 %cmp2965 to i32
  store i32 %cv2966, ptr %slot439, align 8
  %v2967 = load i32, ptr %slot439, align 8
  %cv2968 = zext i32 %v2967 to i64
  %cond2969 = icmp ne i64 %cv2968, 0
  br i1 %cond2969, label %bb_rcgdec543, label %bb_rcgslow543
bb_rcgslow543:
  %v2970 = load i64, ptr %slot426, align 8
  %v2971 = load i64, ptr %slot409, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v2970, i64 %v2971) nomerge, !dbg !132
  br label %bb_rcgdone543
bb_rcgdec543:
  %v2972 = load i64, ptr %slot435, align 8
  %v2973 = load i64, ptr %slot427, align 8
  %p2974 = inttoptr i64 %v2973 to ptr
  %rgep2975 = getelementptr i8, ptr %p2974, i64 -32
  store i64 %v2972, ptr %rgep2975, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear543
bb_rcgclear543:
  %v2976 = load i64, ptr %slot409, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  store i64 0, ptr %p2977, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone543
bb_rcgdone543:
  br label %bb_rcslotdone512
bb_rcslotdone512:
  %v2978 = load i64, ptr %slot28, align 8
  store i64 %v2978, ptr %slot440, align 8
  %v2979 = load i64, ptr %slot24, align 8
  store i64 %v2979, ptr %slot441, align 8
  %v2980 = load i64, ptr %slot441, align 8
  %v2981 = load i64, ptr %slot440, align 8
  %p2982 = inttoptr i64 %v2980 to ptr
  %p2983 = inttoptr i64 %v2981 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2983, ptr %p2982, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2984 = load i64, ptr %slot18, align 8
  %p2985 = inttoptr i64 %v2984 to ptr
  store i32 0, ptr %p2985, align 4, !alias.scope !3, !noalias !4
  %v2986 = load i64, ptr %slot9, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  store i32 2, ptr %p2987, align 4, !alias.scope !3, !noalias !4
  %v2988 = load i64, ptr %slot19, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  %ld2990 = load i32, ptr %p2989, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2990, ptr %slot442, align 8
  %v2991 = load i32, ptr %slot442, align 8
  %v2992 = load i64, ptr %slot9, align 8
  %p2993 = inttoptr i64 %v2992 to ptr
  store i32 %v2991, ptr %p2993, align 4, !alias.scope !3, !noalias !4
  %v2994 = load i64, ptr %slot8, align 8
  %p2995 = inttoptr i64 %v2994 to ptr
  store i32 1, ptr %p2995, align 4, !alias.scope !3, !noalias !4
  %v2996 = load i64, ptr %slot28, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  %ld2998 = load i64, ptr %p2997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2998, ptr %slot443, align 8
  %v2999 = load i64, ptr %slot443, align 8
  %op3000 = add i64 %v2999, 0
  store i64 %op3000, ptr %slot444, align 8
  %v3001 = load i64, ptr %slot444, align 8
  %p3002 = inttoptr i64 %v3001 to ptr
  %ld3003 = load i64, ptr %p3002, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3003, ptr %slot445, align 8
  %v3004 = load i64, ptr %slot445, align 8
  %v3005 = load i64, ptr %slot33, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  store i64 %v3004, ptr %p3006, align 8, !alias.scope !3, !noalias !4
  %v3007 = load i64, ptr %slot33, align 8
  %p3008 = inttoptr i64 %v3007 to ptr
  %ld3009 = load i64, ptr %p3008, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3009, ptr %slot446, align 8
  %v3010 = load i64, ptr %slot446, align 8
  %cmp3011 = icmp ugt i64 %v3010, 9223372036854775807
  %cv3012 = zext i1 %cmp3011 to i64
  store i64 %cv3012, ptr %slot447, align 8
  %v3013 = load i64, ptr %slot447, align 8
  %cond3014 = icmp ne i64 %v3013, 0
  br i1 %cond3014, label %bb_cast_overflow559, label %bb_cast_ok559
bb_cast_overflow559:
  %v3015 = load i64, ptr %slot1, align 8
  %p3016 = inttoptr i64 %v3015 to ptr
  %v3017 = load i64, ptr %slot446, align 8
  call void @myl_qbe_fail_cast(ptr %p3016, i64 %v3017, i64 320) nomerge, !dbg !134
  unreachable
bb_cast_ok559:
  %v3018 = load i64, ptr %slot446, align 8
  %v3019 = load i64, ptr %slot33, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  store i64 %v3018, ptr %p3020, align 8, !alias.scope !3, !noalias !4
  %v3021 = load i64, ptr %slot34, align 8
  %p3022 = inttoptr i64 %v3021 to ptr
  store i64 1, ptr %p3022, align 8, !alias.scope !3, !noalias !4
  %v3023 = load i64, ptr %slot34, align 8
  %p3024 = inttoptr i64 %v3023 to ptr
  %ld3025 = load i64, ptr %p3024, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3025, ptr %slot448, align 8
  %v3026 = load i64, ptr %slot33, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %ld3028 = load i64, ptr %p3027, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3028, ptr %slot449, align 8
  %v3029 = load i64, ptr %slot449, align 8
  %v3030 = load i64, ptr %slot448, align 8
  %ovpair3032 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v3029, i64 %v3030)
  %op3031 = extractvalue { i64, i1 } %ovpair3032, 0
  %ov3033 = extractvalue { i64, i1 } %ovpair3032, 1
  store i64 %op3031, ptr %slot450, align 8
  %cv3034 = zext i1 %ov3033 to i64
  store i64 %cv3034, ptr %slot451, align 8
  %v3035 = load i64, ptr %slot451, align 8
  %cond3036 = icmp ne i64 %v3035, 0
  br i1 %cond3036, label %bb_overflow562, label %bb_checked562
bb_overflow562:
  %v3037 = load i64, ptr %slot1, align 8
  %p3038 = inttoptr i64 %v3037 to ptr
  %v3039 = load i64, ptr %slot449, align 8
  %v3040 = load i64, ptr %slot448, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3038, i64 1, i64 %v3039, i64 %v3040, i64 64) nomerge, !dbg !136
  unreachable
bb_checked562:
  %v3041 = load i64, ptr %slot450, align 8
  %v3042 = load i64, ptr %slot33, align 8
  %p3043 = inttoptr i64 %v3042 to ptr
  store i64 %v3041, ptr %p3043, align 8, !alias.scope !3, !noalias !4
  %v3044 = load i64, ptr %slot33, align 8
  %p3045 = inttoptr i64 %v3044 to ptr
  %ld3046 = load i64, ptr %p3045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3046, ptr %slot452, align 8
  %v3047 = load i64, ptr %slot452, align 8
  %v3048 = load i64, ptr %slot29, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  store i64 %v3047, ptr %p3049, align 8, !alias.scope !3, !noalias !4
  %v3050 = load i64, ptr %slot8, align 8
  %p3051 = inttoptr i64 %v3050 to ptr
  %ld3052 = load i32, ptr %p3051, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3052, ptr %slot453, align 8
  %v3053 = load i32, ptr %slot453, align 8
  %cv3054 = zext i32 %v3053 to i64
  %cond3055 = icmp ne i64 %cv3054, 0
  br i1 %cond3055, label %bb_rcslotdrop567, label %bb_rcslotdone567
bb_rcslotdrop567:
  %v3056 = load i64, ptr %slot8, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i32 0, ptr %p3057, align 4, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot28, align 8
  store i64 %v3058, ptr %slot454, align 8
  %v3059 = load i64, ptr %slot9, align 8
  %p3060 = inttoptr i64 %v3059 to ptr
  %ld3061 = load i32, ptr %p3060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3061, ptr %slot455, align 8
  %v3062 = load i32, ptr %slot455, align 8
  %op3063 = and i32 %v3062, 28
  store i32 %op3063, ptr %slot456, align 8
  %v3064 = load i32, ptr %slot456, align 8
  %cv3065 = zext i32 %v3064 to i64
  %cond3066 = icmp ne i64 %cv3065, 0
  br i1 %cond3066, label %bb_rcslotrole567, label %bb_rcslotowner567
bb_rcslotrole567:
  %v3067 = load i64, ptr %slot39, align 8
  store i64 %v3067, ptr %slot457, align 8
  %v3068 = load i64, ptr %slot454, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %ld3070 = load i64, ptr %p3069, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3070, ptr %slot458, align 8
  %v3071 = load i64, ptr %slot458, align 8
  %cmp3072 = icmp ne i64 %v3071, 0
  %cv3073 = zext i1 %cmp3072 to i32
  store i32 %cv3073, ptr %slot459, align 8
  %v3074 = load i32, ptr %slot459, align 8
  %cv3075 = zext i32 %v3074 to i64
  %cond3076 = icmp ne i64 %cv3075, 0
  br i1 %cond3076, label %bb_rcgnn583, label %bb_rcgdone583
bb_rcgnn583:
  %v3077 = load i64, ptr %slot458, align 8
  %op3078 = sub i64 %v3077, 16
  store i64 %op3078, ptr %slot460, align 8
  %v3079 = load i64, ptr %slot458, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  %rgep3081 = getelementptr i8, ptr %p3080, i64 -16
  %ld3082 = load i64, ptr %rgep3081, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3082, ptr %slot461, align 8
  %v3083 = load i64, ptr %slot461, align 8
  %op3084 = and i64 %v3083, 4611686018427387906
  store i64 %op3084, ptr %slot462, align 8
  %v3085 = load i64, ptr %slot462, align 8
  %cmp3086 = icmp ne i64 %v3085, 0
  %cv3087 = zext i1 %cmp3086 to i32
  store i32 %cv3087, ptr %slot463, align 8
  %v3088 = load i32, ptr %slot463, align 8
  %cv3089 = zext i32 %v3088 to i64
  %cond3090 = icmp ne i64 %cv3089, 0
  br i1 %cond3090, label %bb_rcgclear583, label %bb_rcgcounted583
bb_rcgcounted583:
  %v3091 = load i64, ptr %slot458, align 8
  %op3092 = sub i64 %v3091, 24
  store i64 %op3092, ptr %slot464, align 8
  %v3093 = load i64, ptr %slot458, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  %rgep3095 = getelementptr i8, ptr %p3094, i64 -24
  %ld3096 = load i64, ptr %rgep3095, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3096, ptr %slot465, align 8
  %v3097 = load i64, ptr %slot465, align 8
  %op3098 = sub i64 %v3097, 1
  store i64 %op3098, ptr %slot466, align 8
  %v3099 = load i64, ptr %slot466, align 8
  %cmp3100 = icmp eq i64 %v3099, 0
  %cv3101 = zext i1 %cmp3100 to i32
  store i32 %cv3101, ptr %slot467, align 8
  %v3102 = load i32, ptr %slot467, align 8
  %cv3103 = zext i32 %v3102 to i64
  %cond3104 = icmp ne i64 %cv3103, 0
  br i1 %cond3104, label %bb_rcglast583, label %bb_rcgdec583
bb_rcglast583:
  %v3105 = load i64, ptr %slot458, align 8
  %op3106 = sub i64 %v3105, 32
  store i64 %op3106, ptr %slot468, align 8
  %v3107 = load i64, ptr %slot458, align 8
  %p3108 = inttoptr i64 %v3107 to ptr
  %rgep3109 = getelementptr i8, ptr %p3108, i64 -32
  %ld3110 = load i64, ptr %rgep3109, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3110, ptr %slot469, align 8
  %v3111 = load i64, ptr %slot469, align 8
  %cmp3112 = icmp ne i64 %v3111, 0
  %cv3113 = zext i1 %cmp3112 to i32
  store i32 %cv3113, ptr %slot470, align 8
  %v3114 = load i32, ptr %slot470, align 8
  %cv3115 = zext i32 %v3114 to i64
  %cond3116 = icmp ne i64 %cv3115, 0
  br i1 %cond3116, label %bb_rcgdec583, label %bb_rcgslow583
bb_rcgslow583:
  %v3117 = load i64, ptr %slot457, align 8
  %v3118 = load i64, ptr %slot454, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v3117, i64 %v3118) nomerge, !dbg !138
  br label %bb_rcgdone583
bb_rcgdec583:
  %v3119 = load i64, ptr %slot466, align 8
  %v3120 = load i64, ptr %slot458, align 8
  %p3121 = inttoptr i64 %v3120 to ptr
  %rgep3122 = getelementptr i8, ptr %p3121, i64 -24
  store i64 %v3119, ptr %rgep3122, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear583
bb_rcgclear583:
  %v3123 = load i64, ptr %slot454, align 8
  %p3124 = inttoptr i64 %v3123 to ptr
  store i64 0, ptr %p3124, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone583
bb_rcgdone583:
  br label %bb_rcslotdone567
bb_rcslotowner567:
  %v3125 = load i64, ptr %slot39, align 8
  store i64 %v3125, ptr %slot471, align 8
  %v3126 = load i64, ptr %slot454, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  %ld3128 = load i64, ptr %p3127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3128, ptr %slot472, align 8
  %v3129 = load i64, ptr %slot472, align 8
  %cmp3130 = icmp ne i64 %v3129, 0
  %cv3131 = zext i1 %cmp3130 to i32
  store i32 %cv3131, ptr %slot473, align 8
  %v3132 = load i32, ptr %slot473, align 8
  %cv3133 = zext i32 %v3132 to i64
  %cond3134 = icmp ne i64 %cv3133, 0
  br i1 %cond3134, label %bb_rcgnn598, label %bb_rcgdone598
bb_rcgnn598:
  %v3135 = load i64, ptr %slot472, align 8
  %op3136 = sub i64 %v3135, 16
  store i64 %op3136, ptr %slot474, align 8
  %v3137 = load i64, ptr %slot472, align 8
  %p3138 = inttoptr i64 %v3137 to ptr
  %rgep3139 = getelementptr i8, ptr %p3138, i64 -16
  %ld3140 = load i64, ptr %rgep3139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3140, ptr %slot475, align 8
  %v3141 = load i64, ptr %slot475, align 8
  %op3142 = and i64 %v3141, 4611686018427387906
  store i64 %op3142, ptr %slot476, align 8
  %v3143 = load i64, ptr %slot476, align 8
  %cmp3144 = icmp ne i64 %v3143, 0
  %cv3145 = zext i1 %cmp3144 to i32
  store i32 %cv3145, ptr %slot477, align 8
  %v3146 = load i32, ptr %slot477, align 8
  %cv3147 = zext i32 %v3146 to i64
  %cond3148 = icmp ne i64 %cv3147, 0
  br i1 %cond3148, label %bb_rcgclear598, label %bb_rcgcounted598
bb_rcgcounted598:
  %v3149 = load i64, ptr %slot472, align 8
  %op3150 = sub i64 %v3149, 32
  store i64 %op3150, ptr %slot478, align 8
  %v3151 = load i64, ptr %slot472, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  %rgep3153 = getelementptr i8, ptr %p3152, i64 -32
  %ld3154 = load i64, ptr %rgep3153, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3154, ptr %slot479, align 8
  %v3155 = load i64, ptr %slot479, align 8
  %op3156 = sub i64 %v3155, 1
  store i64 %op3156, ptr %slot480, align 8
  %v3157 = load i64, ptr %slot480, align 8
  %cmp3158 = icmp eq i64 %v3157, 0
  %cv3159 = zext i1 %cmp3158 to i32
  store i32 %cv3159, ptr %slot481, align 8
  %v3160 = load i32, ptr %slot481, align 8
  %cv3161 = zext i32 %v3160 to i64
  %cond3162 = icmp ne i64 %cv3161, 0
  br i1 %cond3162, label %bb_rcglast598, label %bb_rcgdec598
bb_rcglast598:
  %v3163 = load i64, ptr %slot472, align 8
  %op3164 = sub i64 %v3163, 24
  store i64 %op3164, ptr %slot482, align 8
  %v3165 = load i64, ptr %slot472, align 8
  %p3166 = inttoptr i64 %v3165 to ptr
  %rgep3167 = getelementptr i8, ptr %p3166, i64 -24
  %ld3168 = load i64, ptr %rgep3167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3168, ptr %slot483, align 8
  %v3169 = load i64, ptr %slot483, align 8
  %cmp3170 = icmp ne i64 %v3169, 0
  %cv3171 = zext i1 %cmp3170 to i32
  store i32 %cv3171, ptr %slot484, align 8
  %v3172 = load i32, ptr %slot484, align 8
  %cv3173 = zext i32 %v3172 to i64
  %cond3174 = icmp ne i64 %cv3173, 0
  br i1 %cond3174, label %bb_rcgdec598, label %bb_rcgslow598
bb_rcgslow598:
  %v3175 = load i64, ptr %slot471, align 8
  %v3176 = load i64, ptr %slot454, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v3175, i64 %v3176) nomerge, !dbg !138
  br label %bb_rcgdone598
bb_rcgdec598:
  %v3177 = load i64, ptr %slot480, align 8
  %v3178 = load i64, ptr %slot472, align 8
  %p3179 = inttoptr i64 %v3178 to ptr
  %rgep3180 = getelementptr i8, ptr %p3179, i64 -32
  store i64 %v3177, ptr %rgep3180, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear598
bb_rcgclear598:
  %v3181 = load i64, ptr %slot454, align 8
  %p3182 = inttoptr i64 %v3181 to ptr
  store i64 0, ptr %p3182, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone598
bb_rcgdone598:
  br label %bb_rcslotdone567
bb_rcslotdone567:
  br label %bb_i24
bb_i24:
  %v3183 = load i64, ptr %slot29, align 8
  %p3184 = inttoptr i64 %v3183 to ptr
  %ld3185 = load i64, ptr %p3184, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3185, ptr %slot485, align 8
  %v3186 = load i64, ptr %slot485, align 8
  %v3187 = load i64, ptr %slot33, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  store i64 %v3186, ptr %p3188, align 8, !alias.scope !3, !noalias !4
  %v3189 = load i64, ptr %slot34, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  store i64 0, ptr %p3190, align 8, !alias.scope !3, !noalias !4
  %v3191 = load i64, ptr %slot34, align 8
  %p3192 = inttoptr i64 %v3191 to ptr
  %ld3193 = load i64, ptr %p3192, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3193, ptr %slot486, align 8
  %v3194 = load i64, ptr %slot33, align 8
  %p3195 = inttoptr i64 %v3194 to ptr
  %ld3196 = load i64, ptr %p3195, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3196, ptr %slot487, align 8
  %v3197 = load i64, ptr %slot487, align 8
  %v3198 = load i64, ptr %slot486, align 8
  %cmp3199 = icmp sge i64 %v3197, %v3198
  %cv3200 = zext i1 %cmp3199 to i64
  store i64 %cv3200, ptr %slot488, align 8
  %v3201 = load i64, ptr %slot488, align 8
  %v3202 = load i64, ptr %slot33, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  store i64 %v3201, ptr %p3203, align 8, !alias.scope !3, !noalias !4
  %v3204 = load i64, ptr %slot33, align 8
  %p3205 = inttoptr i64 %v3204 to ptr
  %ld3206 = load i64, ptr %p3205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3206, ptr %slot489, align 8
  %v3207 = load i64, ptr %slot489, align 8
  %cond3208 = icmp ne i64 %v3207, 0
  br i1 %cond3208, label %bb_next607, label %bb_i73
bb_next607:
  %v3209 = load i64, ptr %slot26, align 8
  %v3210 = load i64, ptr %slot33, align 8
  %p3211 = inttoptr i64 %v3210 to ptr
  store i64 %v3209, ptr %p3211, align 8, !alias.scope !3, !noalias !4
  %v3212 = load i64, ptr %slot33, align 8
  %p3213 = inttoptr i64 %v3212 to ptr
  %ld3214 = load i64, ptr %p3213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3214, ptr %slot490, align 8
  %v3215 = load i64, ptr %slot490, align 8
  %op3216 = add i64 %v3215, 64
  store i64 %op3216, ptr %slot491, align 8
  %v3217 = load i64, ptr %slot491, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  %ld3219 = load i64, ptr %p3218, align 8
  store i64 %ld3219, ptr %slot492, align 8
  %v3220 = load i64, ptr %slot492, align 8
  %v3221 = load i64, ptr %slot33, align 8
  %p3222 = inttoptr i64 %v3221 to ptr
  store i64 %v3220, ptr %p3222, align 8, !alias.scope !3, !noalias !4
  %v3223 = load i64, ptr %slot33, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  %ld3225 = load i64, ptr %p3224, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3225, ptr %slot493, align 8
  %v3226 = load i64, ptr %slot493, align 8
  %v3227 = load i64, ptr %slot22, align 8
  %p3228 = inttoptr i64 %v3227 to ptr
  store i64 %v3226, ptr %p3228, align 8, !alias.scope !3, !noalias !4
  %v3229 = load i64, ptr %slot22, align 8
  store i64 %v3229, ptr %slot494, align 8
  %v3230 = load i64, ptr %slot24, align 8
  store i64 %v3230, ptr %slot495, align 8
  %v3231 = load i64, ptr %slot494, align 8
  %p3232 = inttoptr i64 %v3231 to ptr
  %ld3233 = load i64, ptr %p3232, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3233, ptr %slot496, align 8
  %v3234 = load i64, ptr %slot496, align 8
  %cmp3235 = icmp ne i64 %v3234, 0
  %cv3236 = zext i1 %cmp3235 to i32
  store i32 %cv3236, ptr %slot497, align 8
  %v3237 = load i32, ptr %slot497, align 8
  %cv3238 = zext i32 %v3237 to i64
  %cond3239 = icmp ne i64 %cv3238, 0
  br i1 %cond3239, label %bb_rcgnn614, label %bb_rcgstore614
bb_rcgnn614:
  %v3240 = load i64, ptr %slot496, align 8
  %op3241 = sub i64 %v3240, 16
  store i64 %op3241, ptr %slot498, align 8
  %v3242 = load i64, ptr %slot496, align 8
  %p3243 = inttoptr i64 %v3242 to ptr
  %rgep3244 = getelementptr i8, ptr %p3243, i64 -16
  %ld3245 = load i64, ptr %rgep3244, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3245, ptr %slot499, align 8
  %v3246 = load i64, ptr %slot499, align 8
  %op3247 = and i64 %v3246, 4611686018427387906
  store i64 %op3247, ptr %slot500, align 8
  %v3248 = load i64, ptr %slot500, align 8
  %cmp3249 = icmp ne i64 %v3248, 0
  %cv3250 = zext i1 %cmp3249 to i32
  store i32 %cv3250, ptr %slot501, align 8
  %v3251 = load i32, ptr %slot501, align 8
  %cv3252 = zext i32 %v3251 to i64
  %cond3253 = icmp ne i64 %cv3252, 0
  br i1 %cond3253, label %bb_rcgstore614, label %bb_rcginc614
bb_rcginc614:
  %v3254 = load i64, ptr %slot496, align 8
  %op3255 = sub i64 %v3254, 24
  store i64 %op3255, ptr %slot502, align 8
  %v3256 = load i64, ptr %slot496, align 8
  %p3257 = inttoptr i64 %v3256 to ptr
  %rgep3258 = getelementptr i8, ptr %p3257, i64 -24
  %ld3259 = load i64, ptr %rgep3258, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3259, ptr %slot503, align 8
  %v3260 = load i64, ptr %slot503, align 8
  %op3261 = add i64 %v3260, 1
  store i64 %op3261, ptr %slot504, align 8
  %v3262 = load i64, ptr %slot504, align 8
  %cmp3263 = icmp eq i64 %v3262, 0
  %cv3264 = zext i1 %cmp3263 to i32
  store i32 %cv3264, ptr %slot505, align 8
  %v3265 = load i32, ptr %slot505, align 8
  %cv3266 = zext i32 %v3265 to i64
  %cond3267 = icmp ne i64 %cv3266, 0
  br i1 %cond3267, label %bb_rcglimit614, label %bb_rcgcapacity614
bb_rcglimit614:
  %v3268 = load i64, ptr %slot1, align 8
  %p3269 = inttoptr i64 %v3268 to ptr
  %call3270 = call i32 @myl_qbe_rc_status(ptr %p3269, i32 2) nomerge, !dbg !140
  store i32 %call3270, ptr %slot506, align 8
  br label %bb_failure
bb_rcgcapacity614:
  %v3271 = load i64, ptr %slot504, align 8
  %v3272 = load i64, ptr %slot496, align 8
  %p3273 = inttoptr i64 %v3272 to ptr
  %rgep3274 = getelementptr i8, ptr %p3273, i64 -24
  store i64 %v3271, ptr %rgep3274, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore614
bb_rcgstore614:
  %v3275 = load i64, ptr %slot496, align 8
  %v3276 = load i64, ptr %slot495, align 8
  %p3277 = inttoptr i64 %v3276 to ptr
  store i64 %v3275, ptr %p3277, align 8, !alias.scope !3, !noalias !4
  %v3278 = load i64, ptr %slot19, align 8
  %p3279 = inttoptr i64 %v3278 to ptr
  store i32 2, ptr %p3279, align 4, !alias.scope !3, !noalias !4
  %v3280 = load i64, ptr %slot19, align 8
  %p3281 = inttoptr i64 %v3280 to ptr
  store i32 16, ptr %p3281, align 4, !alias.scope !3, !noalias !4
  %v3282 = load i64, ptr %slot18, align 8
  %p3283 = inttoptr i64 %v3282 to ptr
  store i32 1, ptr %p3283, align 4, !alias.scope !3, !noalias !4
  %v3284 = load i64, ptr %slot14, align 8
  %p3285 = inttoptr i64 %v3284 to ptr
  %ld3286 = load i32, ptr %p3285, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3286, ptr %slot507, align 8
  %v3287 = load i32, ptr %slot507, align 8
  %cv3288 = zext i32 %v3287 to i64
  %cond3289 = icmp ne i64 %cv3288, 0
  br i1 %cond3289, label %bb_rcslotdrop630, label %bb_rcslotdone630
bb_rcslotdrop630:
  %v3290 = load i64, ptr %slot14, align 8
  %p3291 = inttoptr i64 %v3290 to ptr
  store i32 0, ptr %p3291, align 4, !alias.scope !3, !noalias !4
  %v3292 = load i64, ptr %slot20, align 8
  store i64 %v3292, ptr %slot508, align 8
  %v3293 = load i64, ptr %slot15, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  %ld3295 = load i32, ptr %p3294, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3295, ptr %slot509, align 8
  %v3296 = load i32, ptr %slot509, align 8
  %op3297 = and i32 %v3296, 28
  store i32 %op3297, ptr %slot510, align 8
  %v3298 = load i32, ptr %slot510, align 8
  %cv3299 = zext i32 %v3298 to i64
  %cond3300 = icmp ne i64 %cv3299, 0
  br i1 %cond3300, label %bb_rcslotrole630, label %bb_rcslotowner630
bb_rcslotrole630:
  %v3301 = load i64, ptr %slot39, align 8
  store i64 %v3301, ptr %slot511, align 8
  %v3302 = load i64, ptr %slot511, align 8
  %v3303 = load i64, ptr %slot508, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v3302, i64 %v3303) nomerge, !dbg !140
  br label %bb_rcslotdone630
bb_rcslotowner630:
  %v3304 = load i64, ptr %slot39, align 8
  store i64 %v3304, ptr %slot512, align 8
  %v3305 = load i64, ptr %slot512, align 8
  %v3306 = load i64, ptr %slot508, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v3305, i64 %v3306) nomerge, !dbg !140
  br label %bb_rcslotdone630
bb_rcslotdone630:
  %v3307 = load i64, ptr %slot20, align 8
  store i64 %v3307, ptr %slot513, align 8
  %v3308 = load i64, ptr %slot24, align 8
  store i64 %v3308, ptr %slot514, align 8
  %v3309 = load i64, ptr %slot514, align 8
  %v3310 = load i64, ptr %slot513, align 8
  %p3311 = inttoptr i64 %v3309 to ptr
  %p3312 = inttoptr i64 %v3310 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3312, ptr %p3311, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3313 = load i64, ptr %slot15, align 8
  %p3314 = inttoptr i64 %v3313 to ptr
  store i32 2, ptr %p3314, align 4, !alias.scope !3, !noalias !4
  %v3315 = load i64, ptr %slot19, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  %ld3317 = load i32, ptr %p3316, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3317, ptr %slot515, align 8
  %v3318 = load i32, ptr %slot515, align 8
  %v3319 = load i64, ptr %slot15, align 8
  %p3320 = inttoptr i64 %v3319 to ptr
  store i32 %v3318, ptr %p3320, align 4, !alias.scope !3, !noalias !4
  %v3321 = load i64, ptr %slot18, align 8
  %p3322 = inttoptr i64 %v3321 to ptr
  store i32 0, ptr %p3322, align 4, !alias.scope !3, !noalias !4
  %v3323 = load i64, ptr %slot14, align 8
  %p3324 = inttoptr i64 %v3323 to ptr
  store i32 1, ptr %p3324, align 4, !alias.scope !3, !noalias !4
  %v3325 = load i64, ptr %slot513, align 8
  %p3326 = inttoptr i64 %v3325 to ptr
  %ld3327 = load i64, ptr %p3326, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3327, ptr %slot516, align 8
  %v3328 = load i64, ptr %slot516, align 8
  %v3329 = load i64, ptr %slot33, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  store i64 %v3328, ptr %p3330, align 8, !alias.scope !3, !noalias !4
  %v3331 = load i64, ptr %slot33, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  %ld3333 = load i64, ptr %p3332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3333, ptr %slot517, align 8
  %v3334 = load i64, ptr %slot517, align 8
  %v3335 = load i64, ptr %slot22, align 8
  %p3336 = inttoptr i64 %v3335 to ptr
  store i64 %v3334, ptr %p3336, align 8, !alias.scope !3, !noalias !4
  %v3337 = load i64, ptr %slot22, align 8
  store i64 %v3337, ptr %slot518, align 8
  %v3338 = load i64, ptr %slot14, align 8
  %p3339 = inttoptr i64 %v3338 to ptr
  %ld3340 = load i32, ptr %p3339, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3340, ptr %slot519, align 8
  %v3341 = load i64, ptr %slot15, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %ld3343 = load i32, ptr %p3342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3343, ptr %slot520, align 8
  %v3344 = load i32, ptr %slot520, align 8
  %op3345 = and i32 %v3344, 24
  store i32 %op3345, ptr %slot520, align 8
  %v3346 = load i32, ptr %slot520, align 8
  %cmp3347 = icmp eq i32 %v3346, 0
  %cv3348 = zext i1 %cmp3347 to i32
  store i32 %cv3348, ptr %slot521, align 8
  %v3349 = load i32, ptr %slot519, align 8
  %v3350 = load i32, ptr %slot521, align 8
  %op3351 = and i32 %v3349, %v3350
  store i32 %op3351, ptr %slot522, align 8
  %v3352 = load i32, ptr %slot522, align 8
  %cv3353 = zext i32 %v3352 to i64
  %cond3354 = icmp ne i64 %cv3353, 0
  br i1 %cond3354, label %bb_rcprivateown654, label %bb_rcprivateloan654
bb_rcprivateown654:
  %v3355 = load i64, ptr %slot24, align 8
  store i64 %v3355, ptr %slot523, align 8
  %v3356 = load i64, ptr %slot40, align 8
  store i64 %v3356, ptr %slot524, align 8
  %v3357 = load i64, ptr %slot518, align 8
  %v3358 = load i64, ptr %slot523, align 8
  %op3359 = sub i64 %v3357, %v3358
  store i64 %op3359, ptr %slot525, align 8
  %v3360 = load i64, ptr %slot523, align 8
  %v3361 = load i64, ptr %slot518, align 8
  %op3362 = sub i64 %v3360, %v3361
  store i64 %op3362, ptr %slot526, align 8
  %v3363 = load i64, ptr %slot525, align 8
  %cmp3364 = icmp ult i64 %v3363, 8
  %cv3365 = zext i1 %cmp3364 to i32
  store i32 %cv3365, ptr %slot527, align 8
  %v3366 = load i64, ptr %slot526, align 8
  %cmp3367 = icmp ult i64 %v3366, 8
  %cv3368 = zext i1 %cmp3367 to i32
  store i32 %cv3368, ptr %slot528, align 8
  %v3369 = load i32, ptr %slot527, align 8
  %v3370 = load i32, ptr %slot528, align 8
  %op3371 = or i32 %v3369, %v3370
  store i32 %op3371, ptr %slot529, align 8
  %v3372 = load i32, ptr %slot529, align 8
  %cv3373 = zext i32 %v3372 to i64
  %cond3374 = icmp ne i64 %cv3373, 0
  br i1 %cond3374, label %bb_rcmoveslow657, label %bb_rcmovecheck657
bb_rcmovecheck657:
  %v3375 = load i64, ptr %slot518, align 8
  %p3377 = inttoptr i64 %v3375 to ptr
  %gep3378 = getelementptr i8, ptr %p3377, i64 0
  %op3376 = ptrtoint ptr %gep3378 to i64
  store i64 %op3376, ptr %slot530, align 8
  %v3379 = load i64, ptr %slot530, align 8
  %p3380 = inttoptr i64 %v3379 to ptr
  %ld3381 = load i64, ptr %p3380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3381, ptr %slot531, align 8
  %v3382 = load i64, ptr %slot531, align 8
  %cmp3383 = icmp ne i64 %v3382, 0
  %cv3384 = zext i1 %cmp3383 to i32
  store i32 %cv3384, ptr %slot532, align 8
  %v3385 = load i32, ptr %slot532, align 8
  %cv3386 = zext i32 %v3385 to i64
  %cond3387 = icmp ne i64 %cv3386, 0
  br i1 %cond3387, label %bb_rcmoveheader665, label %bb_rcmovenext665
bb_rcmoveheader665:
  %v3388 = load i64, ptr %slot531, align 8
  %op3389 = sub i64 %v3388, 16
  store i64 %op3389, ptr %slot533, align 8
  %v3390 = load i64, ptr %slot531, align 8
  %p3391 = inttoptr i64 %v3390 to ptr
  %rgep3392 = getelementptr i8, ptr %p3391, i64 -16
  %ld3393 = load i64, ptr %rgep3392, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3393, ptr %slot534, align 8
  %v3394 = load i64, ptr %slot534, align 8
  %op3395 = and i64 %v3394, 5764607523034234881
  store i64 %op3395, ptr %slot535, align 8
  %v3396 = load i64, ptr %slot535, align 8
  %cmp3397 = icmp ne i64 %v3396, 0
  %cv3398 = zext i1 %cmp3397 to i32
  store i32 %cv3398, ptr %slot536, align 8
  %v3399 = load i32, ptr %slot536, align 8
  %cv3400 = zext i32 %v3399 to i64
  %cond3401 = icmp ne i64 %cv3400, 0
  br i1 %cond3401, label %bb_rcmoveslow657, label %bb_rcmovenext665
bb_rcmovenext665:
  %v3402 = load i64, ptr %slot518, align 8
  %v3403 = load i64, ptr %slot523, align 8
  %p3404 = inttoptr i64 %v3402 to ptr
  %p3405 = inttoptr i64 %v3403 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3405, ptr %p3404, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3406 = load i64, ptr %slot518, align 8
  %p3407 = inttoptr i64 %v3406 to ptr
  store i64 0, ptr %p3407, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved657
bb_rcmoveslow657:
  %v3408 = load i64, ptr %slot39, align 8
  %v3409 = load i64, ptr %slot523, align 8
  %v3410 = load i64, ptr %slot518, align 8
  %v3411 = load i64, ptr %slot524, align 8
  %cv3412 = trunc i64 %v3411 to i32
  %call3413 = call i32 @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_take(i64 %v3408, i64 %v3409, i64 %v3410, i32 %cv3412) nomerge, !dbg !142
  store i32 %call3413, ptr %slot537, align 8
  %v3414 = load i32, ptr %slot537, align 8
  %cv3415 = zext i32 %v3414 to i64
  %cond3416 = icmp ne i64 %cv3415, 0
  br i1 %cond3416, label %bb_rcsuccess672, label %bb_rcfailure672
bb_rcfailure672:
  %v3417 = load i64, ptr %slot39, align 8
  %p3418 = inttoptr i64 %v3417 to ptr
  %call3419 = call i32 @myl_rc_take_failure(ptr %p3418) nomerge, !dbg !142
  store i32 %call3419, ptr %slot538, align 8
  %v3420 = load i64, ptr %slot1, align 8
  %p3421 = inttoptr i64 %v3420 to ptr
  %v3422 = load i32, ptr %slot538, align 8
  %call3423 = call i32 @myl_qbe_rc_status(ptr %p3421, i32 %v3422) nomerge, !dbg !142
  store i32 %call3423, ptr %slot539, align 8
  br label %bb_failure
bb_rcsuccess672:
  br label %bb_rcmoved657
bb_rcmoved657:
  %v3424 = load i64, ptr %slot14, align 8
  %p3425 = inttoptr i64 %v3424 to ptr
  store i32 0, ptr %p3425, align 4, !alias.scope !3, !noalias !4
  %v3426 = load i64, ptr %slot19, align 8
  %p3427 = inttoptr i64 %v3426 to ptr
  store i32 2, ptr %p3427, align 4, !alias.scope !3, !noalias !4
  %v3428 = load i64, ptr %slot18, align 8
  %p3429 = inttoptr i64 %v3428 to ptr
  store i32 1, ptr %p3429, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared654
bb_rcprivateloan654:
  %v3430 = load i64, ptr %slot14, align 8
  %p3431 = inttoptr i64 %v3430 to ptr
  %ld3432 = load i32, ptr %p3431, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3432, ptr %slot540, align 8
  %v3433 = load i64, ptr %slot15, align 8
  %p3434 = inttoptr i64 %v3433 to ptr
  %ld3435 = load i32, ptr %p3434, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3435, ptr %slot541, align 8
  %v3436 = load i32, ptr %slot541, align 8
  %cmp3437 = icmp eq i32 %v3436, 16
  %cv3438 = zext i1 %cmp3437 to i32
  store i32 %cv3438, ptr %slot542, align 8
  %v3439 = load i32, ptr %slot542, align 8
  %v3440 = load i32, ptr %slot540, align 8
  %op3441 = and i32 %v3439, %v3440
  store i32 %op3441, ptr %slot542, align 8
  %v3442 = load i32, ptr %slot542, align 8
  %cv3443 = zext i32 %v3442 to i64
  %cond3444 = icmp ne i64 %cv3443, 0
  br i1 %cond3444, label %bb_rcprivatemove654, label %bb_rcprivatenew654
bb_rcprivatemove654:
  %v3445 = load i64, ptr %slot24, align 8
  store i64 %v3445, ptr %slot543, align 8
  %v3446 = load i64, ptr %slot518, align 8
  %v3447 = load i64, ptr %slot543, align 8
  %p3448 = inttoptr i64 %v3446 to ptr
  %p3449 = inttoptr i64 %v3447 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3449, ptr %p3448, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3450 = load i64, ptr %slot518, align 8
  %p3451 = inttoptr i64 %v3450 to ptr
  store i64 0, ptr %p3451, align 8, !alias.scope !3, !noalias !4
  %v3452 = load i64, ptr %slot19, align 8
  %p3453 = inttoptr i64 %v3452 to ptr
  store i32 2, ptr %p3453, align 4, !alias.scope !3, !noalias !4
  %v3454 = load i64, ptr %slot19, align 8
  %p3455 = inttoptr i64 %v3454 to ptr
  store i32 16, ptr %p3455, align 4, !alias.scope !3, !noalias !4
  %v3456 = load i64, ptr %slot18, align 8
  %p3457 = inttoptr i64 %v3456 to ptr
  store i32 1, ptr %p3457, align 4, !alias.scope !3, !noalias !4
  %v3458 = load i64, ptr %slot14, align 8
  %p3459 = inttoptr i64 %v3458 to ptr
  store i32 0, ptr %p3459, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared654
bb_rcprivatenew654:
  %v3460 = load i64, ptr %slot24, align 8
  store i64 %v3460, ptr %slot544, align 8
  %v3461 = load i64, ptr %slot518, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  %ld3463 = load i64, ptr %p3462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3463, ptr %slot545, align 8
  %v3464 = load i64, ptr %slot545, align 8
  %cmp3465 = icmp ne i64 %v3464, 0
  %cv3466 = zext i1 %cmp3465 to i32
  store i32 %cv3466, ptr %slot546, align 8
  %v3467 = load i32, ptr %slot546, align 8
  %cv3468 = zext i32 %v3467 to i64
  %cond3469 = icmp ne i64 %cv3468, 0
  br i1 %cond3469, label %bb_rcgnn690, label %bb_rcgstore690
bb_rcgnn690:
  %v3470 = load i64, ptr %slot545, align 8
  %op3471 = sub i64 %v3470, 16
  store i64 %op3471, ptr %slot547, align 8
  %v3472 = load i64, ptr %slot545, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  %rgep3474 = getelementptr i8, ptr %p3473, i64 -16
  %ld3475 = load i64, ptr %rgep3474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3475, ptr %slot548, align 8
  %v3476 = load i64, ptr %slot548, align 8
  %op3477 = and i64 %v3476, 4611686018427387906
  store i64 %op3477, ptr %slot549, align 8
  %v3478 = load i64, ptr %slot549, align 8
  %cmp3479 = icmp ne i64 %v3478, 0
  %cv3480 = zext i1 %cmp3479 to i32
  store i32 %cv3480, ptr %slot550, align 8
  %v3481 = load i32, ptr %slot550, align 8
  %cv3482 = zext i32 %v3481 to i64
  %cond3483 = icmp ne i64 %cv3482, 0
  br i1 %cond3483, label %bb_rcgstore690, label %bb_rcginc690
bb_rcginc690:
  %v3484 = load i64, ptr %slot545, align 8
  %op3485 = sub i64 %v3484, 24
  store i64 %op3485, ptr %slot551, align 8
  %v3486 = load i64, ptr %slot545, align 8
  %p3487 = inttoptr i64 %v3486 to ptr
  %rgep3488 = getelementptr i8, ptr %p3487, i64 -24
  %ld3489 = load i64, ptr %rgep3488, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3489, ptr %slot552, align 8
  %v3490 = load i64, ptr %slot552, align 8
  %op3491 = add i64 %v3490, 1
  store i64 %op3491, ptr %slot553, align 8
  %v3492 = load i64, ptr %slot553, align 8
  %cmp3493 = icmp eq i64 %v3492, 0
  %cv3494 = zext i1 %cmp3493 to i32
  store i32 %cv3494, ptr %slot554, align 8
  %v3495 = load i32, ptr %slot554, align 8
  %cv3496 = zext i32 %v3495 to i64
  %cond3497 = icmp ne i64 %cv3496, 0
  br i1 %cond3497, label %bb_rcglimit690, label %bb_rcgcapacity690
bb_rcglimit690:
  %v3498 = load i64, ptr %slot1, align 8
  %p3499 = inttoptr i64 %v3498 to ptr
  %call3500 = call i32 @myl_qbe_rc_status(ptr %p3499, i32 2) nomerge, !dbg !142
  store i32 %call3500, ptr %slot555, align 8
  br label %bb_failure
bb_rcgcapacity690:
  %v3501 = load i64, ptr %slot553, align 8
  %v3502 = load i64, ptr %slot545, align 8
  %p3503 = inttoptr i64 %v3502 to ptr
  %rgep3504 = getelementptr i8, ptr %p3503, i64 -24
  store i64 %v3501, ptr %rgep3504, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore690
bb_rcgstore690:
  %v3505 = load i64, ptr %slot545, align 8
  %v3506 = load i64, ptr %slot544, align 8
  %p3507 = inttoptr i64 %v3506 to ptr
  store i64 %v3505, ptr %p3507, align 8, !alias.scope !3, !noalias !4
  %v3508 = load i64, ptr %slot19, align 8
  %p3509 = inttoptr i64 %v3508 to ptr
  store i32 2, ptr %p3509, align 4, !alias.scope !3, !noalias !4
  %v3510 = load i64, ptr %slot19, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  store i32 16, ptr %p3511, align 4, !alias.scope !3, !noalias !4
  %v3512 = load i64, ptr %slot18, align 8
  %p3513 = inttoptr i64 %v3512 to ptr
  store i32 1, ptr %p3513, align 4, !alias.scope !3, !noalias !4
  %v3514 = load i64, ptr %slot14, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  %ld3516 = load i32, ptr %p3515, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3516, ptr %slot556, align 8
  %v3517 = load i32, ptr %slot556, align 8
  %cv3518 = zext i32 %v3517 to i64
  %cond3519 = icmp ne i64 %cv3518, 0
  br i1 %cond3519, label %bb_rcslotdrop706, label %bb_rcslotdone706
bb_rcslotdrop706:
  %v3520 = load i64, ptr %slot14, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  store i32 0, ptr %p3521, align 4, !alias.scope !3, !noalias !4
  %v3522 = load i64, ptr %slot20, align 8
  store i64 %v3522, ptr %slot557, align 8
  %v3523 = load i64, ptr %slot15, align 8
  %p3524 = inttoptr i64 %v3523 to ptr
  %ld3525 = load i32, ptr %p3524, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3525, ptr %slot558, align 8
  %v3526 = load i32, ptr %slot558, align 8
  %op3527 = and i32 %v3526, 28
  store i32 %op3527, ptr %slot559, align 8
  %v3528 = load i32, ptr %slot559, align 8
  %cv3529 = zext i32 %v3528 to i64
  %cond3530 = icmp ne i64 %cv3529, 0
  br i1 %cond3530, label %bb_rcslotrole706, label %bb_rcslotowner706
bb_rcslotrole706:
  %v3531 = load i64, ptr %slot39, align 8
  store i64 %v3531, ptr %slot560, align 8
  %v3532 = load i64, ptr %slot557, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  %ld3534 = load i64, ptr %p3533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3534, ptr %slot561, align 8
  %v3535 = load i64, ptr %slot561, align 8
  %cmp3536 = icmp ne i64 %v3535, 0
  %cv3537 = zext i1 %cmp3536 to i32
  store i32 %cv3537, ptr %slot562, align 8
  %v3538 = load i32, ptr %slot562, align 8
  %cv3539 = zext i32 %v3538 to i64
  %cond3540 = icmp ne i64 %cv3539, 0
  br i1 %cond3540, label %bb_rcgnn722, label %bb_rcgdone722
bb_rcgnn722:
  %v3541 = load i64, ptr %slot561, align 8
  %op3542 = sub i64 %v3541, 16
  store i64 %op3542, ptr %slot563, align 8
  %v3543 = load i64, ptr %slot561, align 8
  %p3544 = inttoptr i64 %v3543 to ptr
  %rgep3545 = getelementptr i8, ptr %p3544, i64 -16
  %ld3546 = load i64, ptr %rgep3545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3546, ptr %slot564, align 8
  %v3547 = load i64, ptr %slot564, align 8
  %op3548 = and i64 %v3547, 4611686018427387906
  store i64 %op3548, ptr %slot565, align 8
  %v3549 = load i64, ptr %slot565, align 8
  %cmp3550 = icmp ne i64 %v3549, 0
  %cv3551 = zext i1 %cmp3550 to i32
  store i32 %cv3551, ptr %slot566, align 8
  %v3552 = load i32, ptr %slot566, align 8
  %cv3553 = zext i32 %v3552 to i64
  %cond3554 = icmp ne i64 %cv3553, 0
  br i1 %cond3554, label %bb_rcgclear722, label %bb_rcgcounted722
bb_rcgcounted722:
  %v3555 = load i64, ptr %slot561, align 8
  %op3556 = sub i64 %v3555, 24
  store i64 %op3556, ptr %slot567, align 8
  %v3557 = load i64, ptr %slot561, align 8
  %p3558 = inttoptr i64 %v3557 to ptr
  %rgep3559 = getelementptr i8, ptr %p3558, i64 -24
  %ld3560 = load i64, ptr %rgep3559, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3560, ptr %slot568, align 8
  %v3561 = load i64, ptr %slot568, align 8
  %op3562 = sub i64 %v3561, 1
  store i64 %op3562, ptr %slot569, align 8
  %v3563 = load i64, ptr %slot569, align 8
  %cmp3564 = icmp eq i64 %v3563, 0
  %cv3565 = zext i1 %cmp3564 to i32
  store i32 %cv3565, ptr %slot570, align 8
  %v3566 = load i32, ptr %slot570, align 8
  %cv3567 = zext i32 %v3566 to i64
  %cond3568 = icmp ne i64 %cv3567, 0
  br i1 %cond3568, label %bb_rcglast722, label %bb_rcgdec722
bb_rcglast722:
  %v3569 = load i64, ptr %slot561, align 8
  %op3570 = sub i64 %v3569, 32
  store i64 %op3570, ptr %slot571, align 8
  %v3571 = load i64, ptr %slot561, align 8
  %p3572 = inttoptr i64 %v3571 to ptr
  %rgep3573 = getelementptr i8, ptr %p3572, i64 -32
  %ld3574 = load i64, ptr %rgep3573, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3574, ptr %slot572, align 8
  %v3575 = load i64, ptr %slot572, align 8
  %cmp3576 = icmp ne i64 %v3575, 0
  %cv3577 = zext i1 %cmp3576 to i32
  store i32 %cv3577, ptr %slot573, align 8
  %v3578 = load i32, ptr %slot573, align 8
  %cv3579 = zext i32 %v3578 to i64
  %cond3580 = icmp ne i64 %cv3579, 0
  br i1 %cond3580, label %bb_rcgdec722, label %bb_rcgslow722
bb_rcgslow722:
  %v3581 = load i64, ptr %slot560, align 8
  %v3582 = load i64, ptr %slot557, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v3581, i64 %v3582) nomerge, !dbg !142
  br label %bb_rcgdone722
bb_rcgdec722:
  %v3583 = load i64, ptr %slot569, align 8
  %v3584 = load i64, ptr %slot561, align 8
  %p3585 = inttoptr i64 %v3584 to ptr
  %rgep3586 = getelementptr i8, ptr %p3585, i64 -24
  store i64 %v3583, ptr %rgep3586, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear722
bb_rcgclear722:
  %v3587 = load i64, ptr %slot557, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  store i64 0, ptr %p3588, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone722
bb_rcgdone722:
  br label %bb_rcslotdone706
bb_rcslotowner706:
  %v3589 = load i64, ptr %slot39, align 8
  store i64 %v3589, ptr %slot574, align 8
  %v3590 = load i64, ptr %slot557, align 8
  %p3591 = inttoptr i64 %v3590 to ptr
  %ld3592 = load i64, ptr %p3591, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3592, ptr %slot575, align 8
  %v3593 = load i64, ptr %slot575, align 8
  %cmp3594 = icmp ne i64 %v3593, 0
  %cv3595 = zext i1 %cmp3594 to i32
  store i32 %cv3595, ptr %slot576, align 8
  %v3596 = load i32, ptr %slot576, align 8
  %cv3597 = zext i32 %v3596 to i64
  %cond3598 = icmp ne i64 %cv3597, 0
  br i1 %cond3598, label %bb_rcgnn737, label %bb_rcgdone737
bb_rcgnn737:
  %v3599 = load i64, ptr %slot575, align 8
  %op3600 = sub i64 %v3599, 16
  store i64 %op3600, ptr %slot577, align 8
  %v3601 = load i64, ptr %slot575, align 8
  %p3602 = inttoptr i64 %v3601 to ptr
  %rgep3603 = getelementptr i8, ptr %p3602, i64 -16
  %ld3604 = load i64, ptr %rgep3603, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3604, ptr %slot578, align 8
  %v3605 = load i64, ptr %slot578, align 8
  %op3606 = and i64 %v3605, 4611686018427387906
  store i64 %op3606, ptr %slot579, align 8
  %v3607 = load i64, ptr %slot579, align 8
  %cmp3608 = icmp ne i64 %v3607, 0
  %cv3609 = zext i1 %cmp3608 to i32
  store i32 %cv3609, ptr %slot580, align 8
  %v3610 = load i32, ptr %slot580, align 8
  %cv3611 = zext i32 %v3610 to i64
  %cond3612 = icmp ne i64 %cv3611, 0
  br i1 %cond3612, label %bb_rcgclear737, label %bb_rcgcounted737
bb_rcgcounted737:
  %v3613 = load i64, ptr %slot575, align 8
  %op3614 = sub i64 %v3613, 32
  store i64 %op3614, ptr %slot581, align 8
  %v3615 = load i64, ptr %slot575, align 8
  %p3616 = inttoptr i64 %v3615 to ptr
  %rgep3617 = getelementptr i8, ptr %p3616, i64 -32
  %ld3618 = load i64, ptr %rgep3617, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3618, ptr %slot582, align 8
  %v3619 = load i64, ptr %slot582, align 8
  %op3620 = sub i64 %v3619, 1
  store i64 %op3620, ptr %slot583, align 8
  %v3621 = load i64, ptr %slot583, align 8
  %cmp3622 = icmp eq i64 %v3621, 0
  %cv3623 = zext i1 %cmp3622 to i32
  store i32 %cv3623, ptr %slot584, align 8
  %v3624 = load i32, ptr %slot584, align 8
  %cv3625 = zext i32 %v3624 to i64
  %cond3626 = icmp ne i64 %cv3625, 0
  br i1 %cond3626, label %bb_rcglast737, label %bb_rcgdec737
bb_rcglast737:
  %v3627 = load i64, ptr %slot575, align 8
  %op3628 = sub i64 %v3627, 24
  store i64 %op3628, ptr %slot585, align 8
  %v3629 = load i64, ptr %slot575, align 8
  %p3630 = inttoptr i64 %v3629 to ptr
  %rgep3631 = getelementptr i8, ptr %p3630, i64 -24
  %ld3632 = load i64, ptr %rgep3631, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3632, ptr %slot586, align 8
  %v3633 = load i64, ptr %slot586, align 8
  %cmp3634 = icmp ne i64 %v3633, 0
  %cv3635 = zext i1 %cmp3634 to i32
  store i32 %cv3635, ptr %slot587, align 8
  %v3636 = load i32, ptr %slot587, align 8
  %cv3637 = zext i32 %v3636 to i64
  %cond3638 = icmp ne i64 %cv3637, 0
  br i1 %cond3638, label %bb_rcgdec737, label %bb_rcgslow737
bb_rcgslow737:
  %v3639 = load i64, ptr %slot574, align 8
  %v3640 = load i64, ptr %slot557, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v3639, i64 %v3640) nomerge, !dbg !142
  br label %bb_rcgdone737
bb_rcgdec737:
  %v3641 = load i64, ptr %slot583, align 8
  %v3642 = load i64, ptr %slot575, align 8
  %p3643 = inttoptr i64 %v3642 to ptr
  %rgep3644 = getelementptr i8, ptr %p3643, i64 -32
  store i64 %v3641, ptr %rgep3644, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear737
bb_rcgclear737:
  %v3645 = load i64, ptr %slot557, align 8
  %p3646 = inttoptr i64 %v3645 to ptr
  store i64 0, ptr %p3646, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone737
bb_rcgdone737:
  br label %bb_rcslotdone706
bb_rcslotdone706:
  br label %bb_rcprivateprepared654
bb_rcprivateprepared654:
  %v3647 = load i64, ptr %slot10, align 8
  %p3648 = inttoptr i64 %v3647 to ptr
  %ld3649 = load i32, ptr %p3648, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3649, ptr %slot588, align 8
  %v3650 = load i32, ptr %slot588, align 8
  %cv3651 = zext i32 %v3650 to i64
  %cond3652 = icmp ne i64 %cv3651, 0
  br i1 %cond3652, label %bb_rcslotdrop744, label %bb_rcslotdone744
bb_rcslotdrop744:
  %v3653 = load i64, ptr %slot10, align 8
  %p3654 = inttoptr i64 %v3653 to ptr
  store i32 0, ptr %p3654, align 4, !alias.scope !3, !noalias !4
  %v3655 = load i64, ptr %slot30, align 8
  store i64 %v3655, ptr %slot589, align 8
  %v3656 = load i64, ptr %slot11, align 8
  %p3657 = inttoptr i64 %v3656 to ptr
  %ld3658 = load i32, ptr %p3657, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3658, ptr %slot590, align 8
  %v3659 = load i32, ptr %slot590, align 8
  %op3660 = and i32 %v3659, 28
  store i32 %op3660, ptr %slot591, align 8
  %v3661 = load i32, ptr %slot591, align 8
  %cv3662 = zext i32 %v3661 to i64
  %cond3663 = icmp ne i64 %cv3662, 0
  br i1 %cond3663, label %bb_rcslotrole744, label %bb_rcslotowner744
bb_rcslotrole744:
  %v3664 = load i64, ptr %slot39, align 8
  store i64 %v3664, ptr %slot592, align 8
  %v3665 = load i64, ptr %slot589, align 8
  %p3666 = inttoptr i64 %v3665 to ptr
  %ld3667 = load i64, ptr %p3666, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3667, ptr %slot593, align 8
  %v3668 = load i64, ptr %slot593, align 8
  %cmp3669 = icmp ne i64 %v3668, 0
  %cv3670 = zext i1 %cmp3669 to i32
  store i32 %cv3670, ptr %slot594, align 8
  %v3671 = load i32, ptr %slot594, align 8
  %cv3672 = zext i32 %v3671 to i64
  %cond3673 = icmp ne i64 %cv3672, 0
  br i1 %cond3673, label %bb_rcgnn760, label %bb_rcgdone760
bb_rcgnn760:
  %v3674 = load i64, ptr %slot593, align 8
  %op3675 = sub i64 %v3674, 16
  store i64 %op3675, ptr %slot595, align 8
  %v3676 = load i64, ptr %slot593, align 8
  %p3677 = inttoptr i64 %v3676 to ptr
  %rgep3678 = getelementptr i8, ptr %p3677, i64 -16
  %ld3679 = load i64, ptr %rgep3678, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3679, ptr %slot596, align 8
  %v3680 = load i64, ptr %slot596, align 8
  %op3681 = and i64 %v3680, 4611686018427387906
  store i64 %op3681, ptr %slot597, align 8
  %v3682 = load i64, ptr %slot597, align 8
  %cmp3683 = icmp ne i64 %v3682, 0
  %cv3684 = zext i1 %cmp3683 to i32
  store i32 %cv3684, ptr %slot598, align 8
  %v3685 = load i32, ptr %slot598, align 8
  %cv3686 = zext i32 %v3685 to i64
  %cond3687 = icmp ne i64 %cv3686, 0
  br i1 %cond3687, label %bb_rcgclear760, label %bb_rcgcounted760
bb_rcgcounted760:
  %v3688 = load i64, ptr %slot593, align 8
  %op3689 = sub i64 %v3688, 24
  store i64 %op3689, ptr %slot599, align 8
  %v3690 = load i64, ptr %slot593, align 8
  %p3691 = inttoptr i64 %v3690 to ptr
  %rgep3692 = getelementptr i8, ptr %p3691, i64 -24
  %ld3693 = load i64, ptr %rgep3692, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3693, ptr %slot600, align 8
  %v3694 = load i64, ptr %slot600, align 8
  %op3695 = sub i64 %v3694, 1
  store i64 %op3695, ptr %slot601, align 8
  %v3696 = load i64, ptr %slot601, align 8
  %cmp3697 = icmp eq i64 %v3696, 0
  %cv3698 = zext i1 %cmp3697 to i32
  store i32 %cv3698, ptr %slot602, align 8
  %v3699 = load i32, ptr %slot602, align 8
  %cv3700 = zext i32 %v3699 to i64
  %cond3701 = icmp ne i64 %cv3700, 0
  br i1 %cond3701, label %bb_rcglast760, label %bb_rcgdec760
bb_rcglast760:
  %v3702 = load i64, ptr %slot593, align 8
  %op3703 = sub i64 %v3702, 32
  store i64 %op3703, ptr %slot603, align 8
  %v3704 = load i64, ptr %slot593, align 8
  %p3705 = inttoptr i64 %v3704 to ptr
  %rgep3706 = getelementptr i8, ptr %p3705, i64 -32
  %ld3707 = load i64, ptr %rgep3706, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3707, ptr %slot604, align 8
  %v3708 = load i64, ptr %slot604, align 8
  %cmp3709 = icmp ne i64 %v3708, 0
  %cv3710 = zext i1 %cmp3709 to i32
  store i32 %cv3710, ptr %slot605, align 8
  %v3711 = load i32, ptr %slot605, align 8
  %cv3712 = zext i32 %v3711 to i64
  %cond3713 = icmp ne i64 %cv3712, 0
  br i1 %cond3713, label %bb_rcgdec760, label %bb_rcgslow760
bb_rcgslow760:
  %v3714 = load i64, ptr %slot592, align 8
  %v3715 = load i64, ptr %slot589, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v3714, i64 %v3715) nomerge, !dbg !142
  br label %bb_rcgdone760
bb_rcgdec760:
  %v3716 = load i64, ptr %slot601, align 8
  %v3717 = load i64, ptr %slot593, align 8
  %p3718 = inttoptr i64 %v3717 to ptr
  %rgep3719 = getelementptr i8, ptr %p3718, i64 -24
  store i64 %v3716, ptr %rgep3719, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear760
bb_rcgclear760:
  %v3720 = load i64, ptr %slot589, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  store i64 0, ptr %p3721, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone760
bb_rcgdone760:
  br label %bb_rcslotdone744
bb_rcslotowner744:
  %v3722 = load i64, ptr %slot39, align 8
  store i64 %v3722, ptr %slot606, align 8
  %v3723 = load i64, ptr %slot589, align 8
  %p3724 = inttoptr i64 %v3723 to ptr
  %ld3725 = load i64, ptr %p3724, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3725, ptr %slot607, align 8
  %v3726 = load i64, ptr %slot607, align 8
  %cmp3727 = icmp ne i64 %v3726, 0
  %cv3728 = zext i1 %cmp3727 to i32
  store i32 %cv3728, ptr %slot608, align 8
  %v3729 = load i32, ptr %slot608, align 8
  %cv3730 = zext i32 %v3729 to i64
  %cond3731 = icmp ne i64 %cv3730, 0
  br i1 %cond3731, label %bb_rcgnn775, label %bb_rcgdone775
bb_rcgnn775:
  %v3732 = load i64, ptr %slot607, align 8
  %op3733 = sub i64 %v3732, 16
  store i64 %op3733, ptr %slot609, align 8
  %v3734 = load i64, ptr %slot607, align 8
  %p3735 = inttoptr i64 %v3734 to ptr
  %rgep3736 = getelementptr i8, ptr %p3735, i64 -16
  %ld3737 = load i64, ptr %rgep3736, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3737, ptr %slot610, align 8
  %v3738 = load i64, ptr %slot610, align 8
  %op3739 = and i64 %v3738, 4611686018427387906
  store i64 %op3739, ptr %slot611, align 8
  %v3740 = load i64, ptr %slot611, align 8
  %cmp3741 = icmp ne i64 %v3740, 0
  %cv3742 = zext i1 %cmp3741 to i32
  store i32 %cv3742, ptr %slot612, align 8
  %v3743 = load i32, ptr %slot612, align 8
  %cv3744 = zext i32 %v3743 to i64
  %cond3745 = icmp ne i64 %cv3744, 0
  br i1 %cond3745, label %bb_rcgclear775, label %bb_rcgcounted775
bb_rcgcounted775:
  %v3746 = load i64, ptr %slot607, align 8
  %op3747 = sub i64 %v3746, 32
  store i64 %op3747, ptr %slot613, align 8
  %v3748 = load i64, ptr %slot607, align 8
  %p3749 = inttoptr i64 %v3748 to ptr
  %rgep3750 = getelementptr i8, ptr %p3749, i64 -32
  %ld3751 = load i64, ptr %rgep3750, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3751, ptr %slot614, align 8
  %v3752 = load i64, ptr %slot614, align 8
  %op3753 = sub i64 %v3752, 1
  store i64 %op3753, ptr %slot615, align 8
  %v3754 = load i64, ptr %slot615, align 8
  %cmp3755 = icmp eq i64 %v3754, 0
  %cv3756 = zext i1 %cmp3755 to i32
  store i32 %cv3756, ptr %slot616, align 8
  %v3757 = load i32, ptr %slot616, align 8
  %cv3758 = zext i32 %v3757 to i64
  %cond3759 = icmp ne i64 %cv3758, 0
  br i1 %cond3759, label %bb_rcglast775, label %bb_rcgdec775
bb_rcglast775:
  %v3760 = load i64, ptr %slot607, align 8
  %op3761 = sub i64 %v3760, 24
  store i64 %op3761, ptr %slot617, align 8
  %v3762 = load i64, ptr %slot607, align 8
  %p3763 = inttoptr i64 %v3762 to ptr
  %rgep3764 = getelementptr i8, ptr %p3763, i64 -24
  %ld3765 = load i64, ptr %rgep3764, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3765, ptr %slot618, align 8
  %v3766 = load i64, ptr %slot618, align 8
  %cmp3767 = icmp ne i64 %v3766, 0
  %cv3768 = zext i1 %cmp3767 to i32
  store i32 %cv3768, ptr %slot619, align 8
  %v3769 = load i32, ptr %slot619, align 8
  %cv3770 = zext i32 %v3769 to i64
  %cond3771 = icmp ne i64 %cv3770, 0
  br i1 %cond3771, label %bb_rcgdec775, label %bb_rcgslow775
bb_rcgslow775:
  %v3772 = load i64, ptr %slot606, align 8
  %v3773 = load i64, ptr %slot589, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v3772, i64 %v3773) nomerge, !dbg !142
  br label %bb_rcgdone775
bb_rcgdec775:
  %v3774 = load i64, ptr %slot615, align 8
  %v3775 = load i64, ptr %slot607, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  %rgep3777 = getelementptr i8, ptr %p3776, i64 -32
  store i64 %v3774, ptr %rgep3777, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear775
bb_rcgclear775:
  %v3778 = load i64, ptr %slot589, align 8
  %p3779 = inttoptr i64 %v3778 to ptr
  store i64 0, ptr %p3779, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone775
bb_rcgdone775:
  br label %bb_rcslotdone744
bb_rcslotdone744:
  %v3780 = load i64, ptr %slot30, align 8
  store i64 %v3780, ptr %slot620, align 8
  %v3781 = load i64, ptr %slot24, align 8
  store i64 %v3781, ptr %slot621, align 8
  %v3782 = load i64, ptr %slot621, align 8
  %v3783 = load i64, ptr %slot620, align 8
  %p3784 = inttoptr i64 %v3782 to ptr
  %p3785 = inttoptr i64 %v3783 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3785, ptr %p3784, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3786 = load i64, ptr %slot18, align 8
  %p3787 = inttoptr i64 %v3786 to ptr
  store i32 0, ptr %p3787, align 4, !alias.scope !3, !noalias !4
  %v3788 = load i64, ptr %slot11, align 8
  %p3789 = inttoptr i64 %v3788 to ptr
  store i32 2, ptr %p3789, align 4, !alias.scope !3, !noalias !4
  %v3790 = load i64, ptr %slot19, align 8
  %p3791 = inttoptr i64 %v3790 to ptr
  %ld3792 = load i32, ptr %p3791, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3792, ptr %slot622, align 8
  %v3793 = load i32, ptr %slot622, align 8
  %v3794 = load i64, ptr %slot11, align 8
  %p3795 = inttoptr i64 %v3794 to ptr
  store i32 %v3793, ptr %p3795, align 4, !alias.scope !3, !noalias !4
  %v3796 = load i64, ptr %slot10, align 8
  %p3797 = inttoptr i64 %v3796 to ptr
  store i32 1, ptr %p3797, align 4, !alias.scope !3, !noalias !4
  %v3798 = load i64, ptr %slot29, align 8
  %p3799 = inttoptr i64 %v3798 to ptr
  %ld3800 = load i64, ptr %p3799, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3800, ptr %slot623, align 8
  %v3801 = load i64, ptr %slot623, align 8
  %v3802 = load i64, ptr %slot33, align 8
  %p3803 = inttoptr i64 %v3802 to ptr
  store i64 %v3801, ptr %p3803, align 8, !alias.scope !3, !noalias !4
  %v3804 = load i64, ptr %slot33, align 8
  %p3805 = inttoptr i64 %v3804 to ptr
  %ld3806 = load i64, ptr %p3805, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3806, ptr %slot624, align 8
  %v3807 = load i64, ptr %slot624, align 8
  %v3808 = load i64, ptr %slot31, align 8
  %p3809 = inttoptr i64 %v3808 to ptr
  store i64 %v3807, ptr %p3809, align 8, !alias.scope !3, !noalias !4
  %v3810 = load i64, ptr %slot31, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  %ld3812 = load i64, ptr %p3811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3812, ptr %slot625, align 8
  %v3813 = load i64, ptr %slot625, align 8
  %v3814 = load i64, ptr %slot33, align 8
  %p3815 = inttoptr i64 %v3814 to ptr
  store i64 %v3813, ptr %p3815, align 8, !alias.scope !3, !noalias !4
  %v3816 = load i64, ptr %slot34, align 8
  %p3817 = inttoptr i64 %v3816 to ptr
  store i64 0, ptr %p3817, align 8, !alias.scope !3, !noalias !4
  %v3818 = load i64, ptr %slot34, align 8
  %p3819 = inttoptr i64 %v3818 to ptr
  %ld3820 = load i64, ptr %p3819, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3820, ptr %slot626, align 8
  %v3821 = load i64, ptr %slot33, align 8
  %p3822 = inttoptr i64 %v3821 to ptr
  %ld3823 = load i64, ptr %p3822, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3823, ptr %slot627, align 8
  %v3824 = load i64, ptr %slot627, align 8
  %v3825 = load i64, ptr %slot626, align 8
  %cmp3826 = icmp slt i64 %v3824, %v3825
  %cv3827 = zext i1 %cmp3826 to i64
  store i64 %cv3827, ptr %slot628, align 8
  %v3828 = load i64, ptr %slot628, align 8
  %v3829 = load i64, ptr %slot33, align 8
  %p3830 = inttoptr i64 %v3829 to ptr
  store i64 %v3828, ptr %p3830, align 8, !alias.scope !3, !noalias !4
  %v3831 = load i64, ptr %slot33, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %ld3833 = load i64, ptr %p3832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3833, ptr %slot629, align 8
  %v3834 = load i64, ptr %slot629, align 8
  %cond3835 = icmp ne i64 %v3834, 0
  br i1 %cond3835, label %bb_next793, label %bb_i42
bb_next793:
  %v3836 = load i64, ptr %slot30, align 8
  %p3837 = inttoptr i64 %v3836 to ptr
  %ld3838 = load i64, ptr %p3837, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3838, ptr %slot630, align 8
  %v3839 = load i64, ptr %slot630, align 8
  %op3840 = add i64 %v3839, 0
  store i64 %op3840, ptr %slot631, align 8
  %v3841 = load i64, ptr %slot631, align 8
  %p3842 = inttoptr i64 %v3841 to ptr
  %ld3843 = load i64, ptr %p3842, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3843, ptr %slot632, align 8
  %v3844 = load i64, ptr %slot632, align 8
  %v3845 = load i64, ptr %slot33, align 8
  %p3846 = inttoptr i64 %v3845 to ptr
  store i64 %v3844, ptr %p3846, align 8, !alias.scope !3, !noalias !4
  %v3847 = load i64, ptr %slot33, align 8
  %p3848 = inttoptr i64 %v3847 to ptr
  %ld3849 = load i64, ptr %p3848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3849, ptr %slot633, align 8
  %v3850 = load i64, ptr %slot633, align 8
  %cmp3851 = icmp ugt i64 %v3850, 9223372036854775807
  %cv3852 = zext i1 %cmp3851 to i64
  store i64 %cv3852, ptr %slot634, align 8
  %v3853 = load i64, ptr %slot634, align 8
  %cond3854 = icmp ne i64 %v3853, 0
  br i1 %cond3854, label %bb_cast_overflow798, label %bb_cast_ok798
bb_cast_overflow798:
  %v3855 = load i64, ptr %slot1, align 8
  %p3856 = inttoptr i64 %v3855 to ptr
  %v3857 = load i64, ptr %slot633, align 8
  call void @myl_qbe_fail_cast(ptr %p3856, i64 %v3857, i64 320) nomerge, !dbg !144
  unreachable
bb_cast_ok798:
  %v3858 = load i64, ptr %slot633, align 8
  %v3859 = load i64, ptr %slot33, align 8
  %p3860 = inttoptr i64 %v3859 to ptr
  store i64 %v3858, ptr %p3860, align 8, !alias.scope !3, !noalias !4
  %v3861 = load i64, ptr %slot31, align 8
  %p3862 = inttoptr i64 %v3861 to ptr
  %ld3863 = load i64, ptr %p3862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3863, ptr %slot635, align 8
  %v3864 = load i64, ptr %slot635, align 8
  %v3865 = load i64, ptr %slot34, align 8
  %p3866 = inttoptr i64 %v3865 to ptr
  store i64 %v3864, ptr %p3866, align 8, !alias.scope !3, !noalias !4
  %v3867 = load i64, ptr %slot34, align 8
  %p3868 = inttoptr i64 %v3867 to ptr
  %ld3869 = load i64, ptr %p3868, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3869, ptr %slot636, align 8
  %v3870 = load i64, ptr %slot33, align 8
  %p3871 = inttoptr i64 %v3870 to ptr
  %ld3872 = load i64, ptr %p3871, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3872, ptr %slot637, align 8
  %v3873 = load i64, ptr %slot637, align 8
  %v3874 = load i64, ptr %slot636, align 8
  %ovpair3876 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v3873, i64 %v3874)
  %op3875 = extractvalue { i64, i1 } %ovpair3876, 0
  %ov3877 = extractvalue { i64, i1 } %ovpair3876, 1
  store i64 %op3875, ptr %slot638, align 8
  %v3878 = load i64, ptr %slot637, align 8
  %v3879 = load i64, ptr %slot638, align 8
  %op3880 = xor i64 %v3878, %v3879
  store i64 %op3880, ptr %slot639, align 8
  %v3881 = load i64, ptr %slot636, align 8
  %v3882 = load i64, ptr %slot638, align 8
  %op3883 = xor i64 %v3881, %v3882
  store i64 %op3883, ptr %slot640, align 8
  %v3884 = load i64, ptr %slot639, align 8
  %v3885 = load i64, ptr %slot640, align 8
  %op3886 = and i64 %v3884, %v3885
  store i64 %op3886, ptr %slot641, align 8
  %cv3887 = zext i1 %ov3877 to i64
  store i64 %cv3887, ptr %slot642, align 8
  %v3888 = load i64, ptr %slot642, align 8
  %cond3889 = icmp ne i64 %v3888, 0
  br i1 %cond3889, label %bb_overflow802, label %bb_checked802
bb_overflow802:
  %v3890 = load i64, ptr %slot1, align 8
  %p3891 = inttoptr i64 %v3890 to ptr
  %v3892 = load i64, ptr %slot637, align 8
  %v3893 = load i64, ptr %slot636, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p3891, i64 0, i64 %v3892, i64 %v3893, i64 64) nomerge, !dbg !146
  unreachable
bb_checked802:
  %v3894 = load i64, ptr %slot638, align 8
  %v3895 = load i64, ptr %slot33, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  store i64 %v3894, ptr %p3896, align 8, !alias.scope !3, !noalias !4
  %v3897 = load i64, ptr %slot33, align 8
  %p3898 = inttoptr i64 %v3897 to ptr
  %ld3899 = load i64, ptr %p3898, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3899, ptr %slot643, align 8
  %v3900 = load i64, ptr %slot643, align 8
  %v3901 = load i64, ptr %slot31, align 8
  %p3902 = inttoptr i64 %v3901 to ptr
  store i64 %v3900, ptr %p3902, align 8, !alias.scope !3, !noalias !4
  br label %bb_i42
bb_i42:
  %v3903 = load i64, ptr %slot31, align 8
  %p3904 = inttoptr i64 %v3903 to ptr
  %ld3905 = load i64, ptr %p3904, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3905, ptr %slot644, align 8
  %v3906 = load i64, ptr %slot644, align 8
  %v3907 = load i64, ptr %slot33, align 8
  %p3908 = inttoptr i64 %v3907 to ptr
  store i64 %v3906, ptr %p3908, align 8, !alias.scope !3, !noalias !4
  %v3909 = load i64, ptr %slot30, align 8
  %p3910 = inttoptr i64 %v3909 to ptr
  %ld3911 = load i64, ptr %p3910, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3911, ptr %slot645, align 8
  %v3912 = load i64, ptr %slot33, align 8
  %p3913 = inttoptr i64 %v3912 to ptr
  %ld3914 = load i64, ptr %p3913, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3914, ptr %slot646, align 8
  %v3915 = load i64, ptr %slot645, align 8
  %p3916 = inttoptr i64 %v3915 to ptr
  %ld3917 = load i64, ptr %p3916, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3917, ptr %slot647, align 8
  %v3918 = load i64, ptr %slot646, align 8
  %v3919 = load i64, ptr %slot647, align 8
  %cmp3920 = icmp ult i64 %v3918, %v3919
  %cv3921 = zext i1 %cmp3920 to i64
  store i64 %cv3921, ptr %slot648, align 8
  %v3922 = load i64, ptr %slot648, align 8
  %cond3923 = icmp ne i64 %v3922, 0
  br i1 %cond3923, label %bb_success814, label %bb_failed814
bb_failed814:
  %v3924 = load i64, ptr %slot1, align 8
  %p3925 = inttoptr i64 %v3924 to ptr
  %v3926 = load i64, ptr %slot646, align 8
  %v3927 = load i64, ptr %slot647, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p3925, i64 %v3926, i64 %v3927) nomerge, !dbg !148
  unreachable
bb_success814:
  %v3928 = load i64, ptr %slot645, align 8
  %op3929 = add i64 %v3928, 32
  store i64 %op3929, ptr %slot649, align 8
  %v3930 = load i64, ptr %slot649, align 8
  %p3931 = inttoptr i64 %v3930 to ptr
  %ld3932 = load i64, ptr %p3931, align 8, !alias.scope !6, !noalias !7
  store i64 %ld3932, ptr %slot650, align 8
  %v3933 = load i64, ptr %slot646, align 8
  %op3934 = mul i64 %v3933, 24
  store i64 %op3934, ptr %slot651, align 8
  %v3935 = load i64, ptr %slot650, align 8
  %v3936 = load i64, ptr %slot651, align 8
  %op3937 = add i64 %v3935, %v3936
  store i64 %op3937, ptr %slot652, align 8
  %v3938 = load i64, ptr %slot652, align 8
  %v3939 = load i64, ptr %slot33, align 8
  %p3940 = inttoptr i64 %v3939 to ptr
  store i64 %v3938, ptr %p3940, align 8, !alias.scope !3, !noalias !4
  %v3941 = load i64, ptr %slot33, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  %ld3943 = load i64, ptr %p3942, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3943, ptr %slot653, align 8
  %v3944 = load i64, ptr %slot24, align 8
  store i64 %v3944, ptr %slot654, align 8
  %v3945 = load i64, ptr %slot39, align 8
  %v3946 = load i64, ptr %slot654, align 8
  %v3947 = load i64, ptr %slot653, align 8
  %call3948 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_loan(i64 %v3945, i64 %v3946, i64 %v3947) nomerge, !dbg !148
  store i32 %call3948, ptr %slot655, align 8
  %v3949 = load i32, ptr %slot655, align 8
  %cv3950 = zext i32 %v3949 to i64
  %cond3951 = icmp ne i64 %cv3950, 0
  br i1 %cond3951, label %bb_rcsuccess822, label %bb_rcfailure822
bb_rcfailure822:
  %v3952 = load i64, ptr %slot39, align 8
  %p3953 = inttoptr i64 %v3952 to ptr
  %call3954 = call i32 @myl_rc_take_failure(ptr %p3953) nomerge, !dbg !148
  store i32 %call3954, ptr %slot656, align 8
  %v3955 = load i64, ptr %slot1, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %v3957 = load i32, ptr %slot656, align 8
  %call3958 = call i32 @myl_qbe_rc_status(ptr %p3956, i32 %v3957) nomerge, !dbg !148
  store i32 %call3958, ptr %slot657, align 8
  br label %bb_failure
bb_rcsuccess822:
  %v3959 = load i64, ptr %slot19, align 8
  %p3960 = inttoptr i64 %v3959 to ptr
  store i32 2, ptr %p3960, align 4, !alias.scope !3, !noalias !4
  %v3961 = load i64, ptr %slot19, align 8
  %p3962 = inttoptr i64 %v3961 to ptr
  store i32 16, ptr %p3962, align 4, !alias.scope !3, !noalias !4
  %v3963 = load i64, ptr %slot18, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  store i32 1, ptr %p3964, align 4, !alias.scope !3, !noalias !4
  %v3965 = load i64, ptr %slot20, align 8
  store i64 %v3965, ptr %slot658, align 8
  %v3966 = load i64, ptr %slot24, align 8
  store i64 %v3966, ptr %slot659, align 8
  %v3967 = load i64, ptr %slot659, align 8
  %v3968 = load i64, ptr %slot658, align 8
  %p3969 = inttoptr i64 %v3967 to ptr
  %p3970 = inttoptr i64 %v3968 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3970, ptr %p3969, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3971 = load i64, ptr %slot15, align 8
  %p3972 = inttoptr i64 %v3971 to ptr
  store i32 2, ptr %p3972, align 4, !alias.scope !3, !noalias !4
  %v3973 = load i64, ptr %slot19, align 8
  %p3974 = inttoptr i64 %v3973 to ptr
  %ld3975 = load i32, ptr %p3974, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3975, ptr %slot660, align 8
  %v3976 = load i32, ptr %slot660, align 8
  %v3977 = load i64, ptr %slot15, align 8
  %p3978 = inttoptr i64 %v3977 to ptr
  store i32 %v3976, ptr %p3978, align 4, !alias.scope !3, !noalias !4
  %v3979 = load i64, ptr %slot18, align 8
  %p3980 = inttoptr i64 %v3979 to ptr
  store i32 0, ptr %p3980, align 4, !alias.scope !3, !noalias !4
  %v3981 = load i64, ptr %slot14, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  store i32 1, ptr %p3982, align 4, !alias.scope !3, !noalias !4
  %v3983 = load i64, ptr %slot658, align 8
  %v3984 = load i64, ptr %slot33, align 8
  %p3985 = inttoptr i64 %v3984 to ptr
  store i64 %v3983, ptr %p3985, align 8, !alias.scope !3, !noalias !4
  %v3986 = load i64, ptr %slot33, align 8
  %p3987 = inttoptr i64 %v3986 to ptr
  %ld3988 = load i64, ptr %p3987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3988, ptr %slot661, align 8
  %v3989 = load i64, ptr %slot14, align 8
  %p3990 = inttoptr i64 %v3989 to ptr
  %ld3991 = load i32, ptr %p3990, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3991, ptr %slot662, align 8
  %v3992 = load i64, ptr %slot15, align 8
  %p3993 = inttoptr i64 %v3992 to ptr
  %ld3994 = load i32, ptr %p3993, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3994, ptr %slot663, align 8
  %v3995 = load i32, ptr %slot663, align 8
  %op3996 = and i32 %v3995, 24
  store i32 %op3996, ptr %slot663, align 8
  %v3997 = load i32, ptr %slot663, align 8
  %cmp3998 = icmp eq i32 %v3997, 0
  %cv3999 = zext i1 %cmp3998 to i32
  store i32 %cv3999, ptr %slot664, align 8
  %v4000 = load i32, ptr %slot662, align 8
  %v4001 = load i32, ptr %slot664, align 8
  %op4002 = and i32 %v4000, %v4001
  store i32 %op4002, ptr %slot665, align 8
  %v4003 = load i32, ptr %slot665, align 8
  %cv4004 = zext i32 %v4003 to i64
  %cond4005 = icmp ne i64 %cv4004, 0
  br i1 %cond4005, label %bb_rctake837, label %bb_rccopy837
bb_rctake837:
  %v4006 = load i64, ptr %slot24, align 8
  store i64 %v4006, ptr %slot666, align 8
  %v4007 = load i64, ptr %slot40, align 8
  store i64 %v4007, ptr %slot667, align 8
  %v4008 = load i64, ptr %slot661, align 8
  %v4009 = load i64, ptr %slot666, align 8
  %op4010 = sub i64 %v4008, %v4009
  store i64 %op4010, ptr %slot668, align 8
  %v4011 = load i64, ptr %slot666, align 8
  %v4012 = load i64, ptr %slot661, align 8
  %op4013 = sub i64 %v4011, %v4012
  store i64 %op4013, ptr %slot669, align 8
  %v4014 = load i64, ptr %slot668, align 8
  %cmp4015 = icmp ult i64 %v4014, 24
  %cv4016 = zext i1 %cmp4015 to i32
  store i32 %cv4016, ptr %slot670, align 8
  %v4017 = load i64, ptr %slot669, align 8
  %cmp4018 = icmp ult i64 %v4017, 24
  %cv4019 = zext i1 %cmp4018 to i32
  store i32 %cv4019, ptr %slot671, align 8
  %v4020 = load i32, ptr %slot670, align 8
  %v4021 = load i32, ptr %slot671, align 8
  %op4022 = or i32 %v4020, %v4021
  store i32 %op4022, ptr %slot672, align 8
  %v4023 = load i32, ptr %slot672, align 8
  %cv4024 = zext i32 %v4023 to i64
  %cond4025 = icmp ne i64 %cv4024, 0
  br i1 %cond4025, label %bb_rcmoveslow846, label %bb_rcmovecheck846
bb_rcmovecheck846:
  %v4026 = load i64, ptr %slot661, align 8
  %op4027 = add i64 %v4026, 0
  store i64 %op4027, ptr %slot673, align 8
  %v4028 = load i64, ptr %slot673, align 8
  %p4029 = inttoptr i64 %v4028 to ptr
  %ld4030 = load i64, ptr %p4029, align 8
  store i64 %ld4030, ptr %slot674, align 8
  %v4031 = load i64, ptr %slot674, align 8
  %cmp4032 = icmp ne i64 %v4031, 0
  %cv4033 = zext i1 %cmp4032 to i32
  store i32 %cv4033, ptr %slot675, align 8
  %v4034 = load i32, ptr %slot675, align 8
  %cv4035 = zext i32 %v4034 to i64
  %cond4036 = icmp ne i64 %cv4035, 0
  br i1 %cond4036, label %bb_rcmoveheader854, label %bb_rcmovenext854
bb_rcmoveheader854:
  %v4037 = load i64, ptr %slot674, align 8
  %op4038 = sub i64 %v4037, 16
  store i64 %op4038, ptr %slot676, align 8
  %v4039 = load i64, ptr %slot674, align 8
  %p4040 = inttoptr i64 %v4039 to ptr
  %rgep4041 = getelementptr i8, ptr %p4040, i64 -16
  %ld4042 = load i64, ptr %rgep4041, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4042, ptr %slot677, align 8
  %v4043 = load i64, ptr %slot677, align 8
  %op4044 = and i64 %v4043, 5764607523034234881
  store i64 %op4044, ptr %slot678, align 8
  %v4045 = load i64, ptr %slot678, align 8
  %cmp4046 = icmp ne i64 %v4045, 0
  %cv4047 = zext i1 %cmp4046 to i32
  store i32 %cv4047, ptr %slot679, align 8
  %v4048 = load i32, ptr %slot679, align 8
  %cv4049 = zext i32 %v4048 to i64
  %cond4050 = icmp ne i64 %cv4049, 0
  br i1 %cond4050, label %bb_rcmoveslow846, label %bb_rcmovenext854
bb_rcmovenext854:
  %v4051 = load i64, ptr %slot661, align 8
  %v4052 = load i64, ptr %slot666, align 8
  %p4053 = inttoptr i64 %v4051 to ptr
  %p4054 = inttoptr i64 %v4052 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4054, ptr %p4053, i64 24, i1 false)
  %v4055 = load i64, ptr %slot661, align 8
  %p4056 = inttoptr i64 %v4055 to ptr
  store i64 0, ptr %p4056, align 8
  %v4057 = load i64, ptr %slot661, align 8
  %op4058 = add i64 %v4057, 8
  store i64 %op4058, ptr %slot680, align 8
  %v4059 = load i64, ptr %slot680, align 8
  %p4060 = inttoptr i64 %v4059 to ptr
  store i64 0, ptr %p4060, align 8
  %v4061 = load i64, ptr %slot661, align 8
  %op4062 = add i64 %v4061, 16
  store i64 %op4062, ptr %slot681, align 8
  %v4063 = load i64, ptr %slot681, align 8
  %p4064 = inttoptr i64 %v4063 to ptr
  store i64 0, ptr %p4064, align 8
  br label %bb_rcmoved846
bb_rcmoveslow846:
  %v4065 = load i64, ptr %slot39, align 8
  %v4066 = load i64, ptr %slot666, align 8
  %v4067 = load i64, ptr %slot661, align 8
  %v4068 = load i64, ptr %slot667, align 8
  %cv4069 = trunc i64 %v4068 to i32
  %call4070 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_take(i64 %v4065, i64 %v4066, i64 %v4067, i32 %cv4069) nomerge, !dbg !150
  store i32 %call4070, ptr %slot682, align 8
  %v4071 = load i32, ptr %slot682, align 8
  %cv4072 = zext i32 %v4071 to i64
  %cond4073 = icmp ne i64 %cv4072, 0
  br i1 %cond4073, label %bb_rcsuccess863, label %bb_rcfailure863
bb_rcfailure863:
  %v4074 = load i64, ptr %slot39, align 8
  %p4075 = inttoptr i64 %v4074 to ptr
  %call4076 = call i32 @myl_rc_take_failure(ptr %p4075) nomerge, !dbg !150
  store i32 %call4076, ptr %slot683, align 8
  %v4077 = load i64, ptr %slot1, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  %v4079 = load i32, ptr %slot683, align 8
  %call4080 = call i32 @myl_qbe_rc_status(ptr %p4078, i32 %v4079) nomerge, !dbg !150
  store i32 %call4080, ptr %slot684, align 8
  br label %bb_failure
bb_rcsuccess863:
  br label %bb_rcmoved846
bb_rcmoved846:
  %v4081 = load i64, ptr %slot14, align 8
  %p4082 = inttoptr i64 %v4081 to ptr
  store i32 0, ptr %p4082, align 4, !alias.scope !3, !noalias !4
  %v4083 = load i64, ptr %slot19, align 8
  %p4084 = inttoptr i64 %v4083 to ptr
  store i32 2, ptr %p4084, align 4, !alias.scope !3, !noalias !4
  %v4085 = load i64, ptr %slot18, align 8
  %p4086 = inttoptr i64 %v4085 to ptr
  store i32 1, ptr %p4086, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared837
bb_rccopy837:
  %v4087 = load i64, ptr %slot24, align 8
  store i64 %v4087, ptr %slot685, align 8
  %v4088 = load i64, ptr %slot40, align 8
  store i64 %v4088, ptr %slot686, align 8
  %v4089 = load i64, ptr %slot39, align 8
  %v4090 = load i64, ptr %slot685, align 8
  %v4091 = load i64, ptr %slot661, align 8
  %v4092 = load i64, ptr %slot686, align 8
  %cv4093 = trunc i64 %v4092 to i32
  %call4094 = call i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_retain(i64 %v4089, i64 %v4090, i64 %v4091, i32 %cv4093) nomerge, !dbg !150
  store i32 %call4094, ptr %slot687, align 8
  %v4095 = load i32, ptr %slot687, align 8
  %cv4096 = zext i32 %v4095 to i64
  %cond4097 = icmp ne i64 %cv4096, 0
  br i1 %cond4097, label %bb_rcsuccess872, label %bb_rcfailure872
bb_rcfailure872:
  %v4098 = load i64, ptr %slot39, align 8
  %p4099 = inttoptr i64 %v4098 to ptr
  %call4100 = call i32 @myl_rc_take_failure(ptr %p4099) nomerge, !dbg !150
  store i32 %call4100, ptr %slot688, align 8
  %v4101 = load i64, ptr %slot1, align 8
  %p4102 = inttoptr i64 %v4101 to ptr
  %v4103 = load i32, ptr %slot688, align 8
  %call4104 = call i32 @myl_qbe_rc_status(ptr %p4102, i32 %v4103) nomerge, !dbg !150
  store i32 %call4104, ptr %slot689, align 8
  br label %bb_failure
bb_rcsuccess872:
  %v4105 = load i64, ptr %slot19, align 8
  %p4106 = inttoptr i64 %v4105 to ptr
  store i32 2, ptr %p4106, align 4, !alias.scope !3, !noalias !4
  %v4107 = load i64, ptr %slot18, align 8
  %p4108 = inttoptr i64 %v4107 to ptr
  store i32 1, ptr %p4108, align 4, !alias.scope !3, !noalias !4
  %v4109 = load i64, ptr %slot14, align 8
  %p4110 = inttoptr i64 %v4109 to ptr
  %ld4111 = load i32, ptr %p4110, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4111, ptr %slot690, align 8
  %v4112 = load i32, ptr %slot690, align 8
  %cv4113 = zext i32 %v4112 to i64
  %cond4114 = icmp ne i64 %cv4113, 0
  br i1 %cond4114, label %bb_rcslotdrop879, label %bb_rcslotdone879
bb_rcslotdrop879:
  %v4115 = load i64, ptr %slot14, align 8
  %p4116 = inttoptr i64 %v4115 to ptr
  store i32 0, ptr %p4116, align 4, !alias.scope !3, !noalias !4
  %v4117 = load i64, ptr %slot20, align 8
  store i64 %v4117, ptr %slot691, align 8
  %v4118 = load i64, ptr %slot15, align 8
  %p4119 = inttoptr i64 %v4118 to ptr
  %ld4120 = load i32, ptr %p4119, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4120, ptr %slot692, align 8
  %v4121 = load i32, ptr %slot692, align 8
  %op4122 = and i32 %v4121, 28
  store i32 %op4122, ptr %slot693, align 8
  %v4123 = load i32, ptr %slot693, align 8
  %cv4124 = zext i32 %v4123 to i64
  %cond4125 = icmp ne i64 %cv4124, 0
  br i1 %cond4125, label %bb_rcslotrole879, label %bb_rcslotowner879
bb_rcslotrole879:
  %v4126 = load i64, ptr %slot39, align 8
  store i64 %v4126, ptr %slot694, align 8
  %v4127 = load i64, ptr %slot694, align 8
  %v4128 = load i64, ptr %slot691, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v4127, i64 %v4128) nomerge, !dbg !150
  br label %bb_rcslotdone879
bb_rcslotowner879:
  %v4129 = load i64, ptr %slot691, align 8
  %p4131 = inttoptr i64 %v4129 to ptr
  %gep4132 = getelementptr i8, ptr %p4131, i64 0
  %op4130 = ptrtoint ptr %gep4132 to i64
  store i64 %op4130, ptr %slot695, align 8
  %v4133 = load i64, ptr %slot39, align 8
  store i64 %v4133, ptr %slot696, align 8
  %v4134 = load i64, ptr %slot695, align 8
  %p4135 = inttoptr i64 %v4134 to ptr
  %ld4136 = load i64, ptr %p4135, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4136, ptr %slot697, align 8
  %v4137 = load i64, ptr %slot697, align 8
  %cmp4138 = icmp ne i64 %v4137, 0
  %cv4139 = zext i1 %cmp4138 to i32
  store i32 %cv4139, ptr %slot698, align 8
  %v4140 = load i32, ptr %slot698, align 8
  %cv4141 = zext i32 %v4140 to i64
  %cond4142 = icmp ne i64 %cv4141, 0
  br i1 %cond4142, label %bb_rcgnn897, label %bb_rcgdone897
bb_rcgnn897:
  %v4143 = load i64, ptr %slot697, align 8
  %op4144 = sub i64 %v4143, 16
  store i64 %op4144, ptr %slot699, align 8
  %v4145 = load i64, ptr %slot697, align 8
  %p4146 = inttoptr i64 %v4145 to ptr
  %rgep4147 = getelementptr i8, ptr %p4146, i64 -16
  %ld4148 = load i64, ptr %rgep4147, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4148, ptr %slot700, align 8
  %v4149 = load i64, ptr %slot700, align 8
  %op4150 = and i64 %v4149, 4611686018427387906
  store i64 %op4150, ptr %slot701, align 8
  %v4151 = load i64, ptr %slot701, align 8
  %cmp4152 = icmp ne i64 %v4151, 0
  %cv4153 = zext i1 %cmp4152 to i32
  store i32 %cv4153, ptr %slot702, align 8
  %v4154 = load i32, ptr %slot702, align 8
  %cv4155 = zext i32 %v4154 to i64
  %cond4156 = icmp ne i64 %cv4155, 0
  br i1 %cond4156, label %bb_rcgclear897, label %bb_rcgcounted897
bb_rcgcounted897:
  %v4157 = load i64, ptr %slot697, align 8
  %op4158 = sub i64 %v4157, 32
  store i64 %op4158, ptr %slot703, align 8
  %v4159 = load i64, ptr %slot697, align 8
  %p4160 = inttoptr i64 %v4159 to ptr
  %rgep4161 = getelementptr i8, ptr %p4160, i64 -32
  %ld4162 = load i64, ptr %rgep4161, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4162, ptr %slot704, align 8
  %v4163 = load i64, ptr %slot704, align 8
  %op4164 = sub i64 %v4163, 1
  store i64 %op4164, ptr %slot705, align 8
  %v4165 = load i64, ptr %slot705, align 8
  %cmp4166 = icmp eq i64 %v4165, 0
  %cv4167 = zext i1 %cmp4166 to i32
  store i32 %cv4167, ptr %slot706, align 8
  %v4168 = load i32, ptr %slot706, align 8
  %cv4169 = zext i32 %v4168 to i64
  %cond4170 = icmp ne i64 %cv4169, 0
  br i1 %cond4170, label %bb_rcglast897, label %bb_rcgdec897
bb_rcglast897:
  %v4171 = load i64, ptr %slot697, align 8
  %op4172 = sub i64 %v4171, 24
  store i64 %op4172, ptr %slot707, align 8
  %v4173 = load i64, ptr %slot697, align 8
  %p4174 = inttoptr i64 %v4173 to ptr
  %rgep4175 = getelementptr i8, ptr %p4174, i64 -24
  %ld4176 = load i64, ptr %rgep4175, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4176, ptr %slot708, align 8
  %v4177 = load i64, ptr %slot708, align 8
  %cmp4178 = icmp ne i64 %v4177, 0
  %cv4179 = zext i1 %cmp4178 to i32
  store i32 %cv4179, ptr %slot709, align 8
  %v4180 = load i32, ptr %slot709, align 8
  %cv4181 = zext i32 %v4180 to i64
  %cond4182 = icmp ne i64 %cv4181, 0
  br i1 %cond4182, label %bb_rcgdec897, label %bb_rcgslow897
bb_rcgslow897:
  %v4183 = load i64, ptr %slot696, align 8
  %v4184 = load i64, ptr %slot695, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4183, i64 %v4184) nomerge, !dbg !150
  br label %bb_rcgdone897
bb_rcgdec897:
  %v4185 = load i64, ptr %slot705, align 8
  %v4186 = load i64, ptr %slot697, align 8
  %p4187 = inttoptr i64 %v4186 to ptr
  %rgep4188 = getelementptr i8, ptr %p4187, i64 -32
  store i64 %v4185, ptr %rgep4188, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear897
bb_rcgclear897:
  %v4189 = load i64, ptr %slot695, align 8
  %p4190 = inttoptr i64 %v4189 to ptr
  store i64 0, ptr %p4190, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone897
bb_rcgdone897:
  %v4191 = load i64, ptr %slot691, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  store i64 0, ptr %p4192, align 8, !alias.scope !3, !noalias !4
  %v4193 = load i64, ptr %slot691, align 8
  %p4195 = inttoptr i64 %v4193 to ptr
  %gep4196 = getelementptr i8, ptr %p4195, i64 8
  %op4194 = ptrtoint ptr %gep4196 to i64
  store i64 %op4194, ptr %slot710, align 8
  %v4197 = load i64, ptr %slot710, align 8
  %p4198 = inttoptr i64 %v4197 to ptr
  store i64 0, ptr %p4198, align 8, !alias.scope !3, !noalias !4
  %v4199 = load i64, ptr %slot691, align 8
  %p4201 = inttoptr i64 %v4199 to ptr
  %gep4202 = getelementptr i8, ptr %p4201, i64 16
  %op4200 = ptrtoint ptr %gep4202 to i64
  store i64 %op4200, ptr %slot711, align 8
  %v4203 = load i64, ptr %slot711, align 8
  %p4204 = inttoptr i64 %v4203 to ptr
  store i64 0, ptr %p4204, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone879
bb_rcslotdone879:
  br label %bb_rcprepared837
bb_rcprepared837:
  %v4205 = load i64, ptr %slot12, align 8
  %p4206 = inttoptr i64 %v4205 to ptr
  %ld4207 = load i32, ptr %p4206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4207, ptr %slot712, align 8
  %v4208 = load i32, ptr %slot712, align 8
  %cv4209 = zext i32 %v4208 to i64
  %cond4210 = icmp ne i64 %cv4209, 0
  br i1 %cond4210, label %bb_rcslotdrop906, label %bb_rcslotdone906
bb_rcslotdrop906:
  %v4211 = load i64, ptr %slot12, align 8
  %p4212 = inttoptr i64 %v4211 to ptr
  store i32 0, ptr %p4212, align 4, !alias.scope !3, !noalias !4
  %v4213 = load i64, ptr %slot32, align 8
  store i64 %v4213, ptr %slot713, align 8
  %v4214 = load i64, ptr %slot13, align 8
  %p4215 = inttoptr i64 %v4214 to ptr
  %ld4216 = load i32, ptr %p4215, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4216, ptr %slot714, align 8
  %v4217 = load i32, ptr %slot714, align 8
  %op4218 = and i32 %v4217, 28
  store i32 %op4218, ptr %slot715, align 8
  %v4219 = load i32, ptr %slot715, align 8
  %cv4220 = zext i32 %v4219 to i64
  %cond4221 = icmp ne i64 %cv4220, 0
  br i1 %cond4221, label %bb_rcslotrole906, label %bb_rcslotowner906
bb_rcslotrole906:
  %v4222 = load i64, ptr %slot39, align 8
  store i64 %v4222, ptr %slot716, align 8
  %v4223 = load i64, ptr %slot716, align 8
  %v4224 = load i64, ptr %slot713, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v4223, i64 %v4224) nomerge, !dbg !150
  br label %bb_rcslotdone906
bb_rcslotowner906:
  %v4225 = load i64, ptr %slot713, align 8
  %p4227 = inttoptr i64 %v4225 to ptr
  %gep4228 = getelementptr i8, ptr %p4227, i64 0
  %op4226 = ptrtoint ptr %gep4228 to i64
  store i64 %op4226, ptr %slot717, align 8
  %v4229 = load i64, ptr %slot39, align 8
  store i64 %v4229, ptr %slot718, align 8
  %v4230 = load i64, ptr %slot717, align 8
  %p4231 = inttoptr i64 %v4230 to ptr
  %ld4232 = load i64, ptr %p4231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4232, ptr %slot719, align 8
  %v4233 = load i64, ptr %slot719, align 8
  %cmp4234 = icmp ne i64 %v4233, 0
  %cv4235 = zext i1 %cmp4234 to i32
  store i32 %cv4235, ptr %slot720, align 8
  %v4236 = load i32, ptr %slot720, align 8
  %cv4237 = zext i32 %v4236 to i64
  %cond4238 = icmp ne i64 %cv4237, 0
  br i1 %cond4238, label %bb_rcgnn924, label %bb_rcgdone924
bb_rcgnn924:
  %v4239 = load i64, ptr %slot719, align 8
  %op4240 = sub i64 %v4239, 16
  store i64 %op4240, ptr %slot721, align 8
  %v4241 = load i64, ptr %slot719, align 8
  %p4242 = inttoptr i64 %v4241 to ptr
  %rgep4243 = getelementptr i8, ptr %p4242, i64 -16
  %ld4244 = load i64, ptr %rgep4243, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4244, ptr %slot722, align 8
  %v4245 = load i64, ptr %slot722, align 8
  %op4246 = and i64 %v4245, 4611686018427387906
  store i64 %op4246, ptr %slot723, align 8
  %v4247 = load i64, ptr %slot723, align 8
  %cmp4248 = icmp ne i64 %v4247, 0
  %cv4249 = zext i1 %cmp4248 to i32
  store i32 %cv4249, ptr %slot724, align 8
  %v4250 = load i32, ptr %slot724, align 8
  %cv4251 = zext i32 %v4250 to i64
  %cond4252 = icmp ne i64 %cv4251, 0
  br i1 %cond4252, label %bb_rcgclear924, label %bb_rcgcounted924
bb_rcgcounted924:
  %v4253 = load i64, ptr %slot719, align 8
  %op4254 = sub i64 %v4253, 32
  store i64 %op4254, ptr %slot725, align 8
  %v4255 = load i64, ptr %slot719, align 8
  %p4256 = inttoptr i64 %v4255 to ptr
  %rgep4257 = getelementptr i8, ptr %p4256, i64 -32
  %ld4258 = load i64, ptr %rgep4257, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4258, ptr %slot726, align 8
  %v4259 = load i64, ptr %slot726, align 8
  %op4260 = sub i64 %v4259, 1
  store i64 %op4260, ptr %slot727, align 8
  %v4261 = load i64, ptr %slot727, align 8
  %cmp4262 = icmp eq i64 %v4261, 0
  %cv4263 = zext i1 %cmp4262 to i32
  store i32 %cv4263, ptr %slot728, align 8
  %v4264 = load i32, ptr %slot728, align 8
  %cv4265 = zext i32 %v4264 to i64
  %cond4266 = icmp ne i64 %cv4265, 0
  br i1 %cond4266, label %bb_rcglast924, label %bb_rcgdec924
bb_rcglast924:
  %v4267 = load i64, ptr %slot719, align 8
  %op4268 = sub i64 %v4267, 24
  store i64 %op4268, ptr %slot729, align 8
  %v4269 = load i64, ptr %slot719, align 8
  %p4270 = inttoptr i64 %v4269 to ptr
  %rgep4271 = getelementptr i8, ptr %p4270, i64 -24
  %ld4272 = load i64, ptr %rgep4271, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4272, ptr %slot730, align 8
  %v4273 = load i64, ptr %slot730, align 8
  %cmp4274 = icmp ne i64 %v4273, 0
  %cv4275 = zext i1 %cmp4274 to i32
  store i32 %cv4275, ptr %slot731, align 8
  %v4276 = load i32, ptr %slot731, align 8
  %cv4277 = zext i32 %v4276 to i64
  %cond4278 = icmp ne i64 %cv4277, 0
  br i1 %cond4278, label %bb_rcgdec924, label %bb_rcgslow924
bb_rcgslow924:
  %v4279 = load i64, ptr %slot718, align 8
  %v4280 = load i64, ptr %slot717, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4279, i64 %v4280) nomerge, !dbg !150
  br label %bb_rcgdone924
bb_rcgdec924:
  %v4281 = load i64, ptr %slot727, align 8
  %v4282 = load i64, ptr %slot719, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  %rgep4284 = getelementptr i8, ptr %p4283, i64 -32
  store i64 %v4281, ptr %rgep4284, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear924
bb_rcgclear924:
  %v4285 = load i64, ptr %slot717, align 8
  %p4286 = inttoptr i64 %v4285 to ptr
  store i64 0, ptr %p4286, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone924
bb_rcgdone924:
  %v4287 = load i64, ptr %slot713, align 8
  %p4288 = inttoptr i64 %v4287 to ptr
  store i64 0, ptr %p4288, align 8, !alias.scope !3, !noalias !4
  %v4289 = load i64, ptr %slot713, align 8
  %p4291 = inttoptr i64 %v4289 to ptr
  %gep4292 = getelementptr i8, ptr %p4291, i64 8
  %op4290 = ptrtoint ptr %gep4292 to i64
  store i64 %op4290, ptr %slot732, align 8
  %v4293 = load i64, ptr %slot732, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  store i64 0, ptr %p4294, align 8, !alias.scope !3, !noalias !4
  %v4295 = load i64, ptr %slot713, align 8
  %p4297 = inttoptr i64 %v4295 to ptr
  %gep4298 = getelementptr i8, ptr %p4297, i64 16
  %op4296 = ptrtoint ptr %gep4298 to i64
  store i64 %op4296, ptr %slot733, align 8
  %v4299 = load i64, ptr %slot733, align 8
  %p4300 = inttoptr i64 %v4299 to ptr
  store i64 0, ptr %p4300, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone906
bb_rcslotdone906:
  %v4301 = load i64, ptr %slot32, align 8
  store i64 %v4301, ptr %slot734, align 8
  %v4302 = load i64, ptr %slot24, align 8
  store i64 %v4302, ptr %slot735, align 8
  %v4303 = load i64, ptr %slot735, align 8
  %v4304 = load i64, ptr %slot734, align 8
  %p4305 = inttoptr i64 %v4303 to ptr
  %p4306 = inttoptr i64 %v4304 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4306, ptr %p4305, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4307 = load i64, ptr %slot18, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  store i32 0, ptr %p4308, align 4, !alias.scope !3, !noalias !4
  %v4309 = load i64, ptr %slot13, align 8
  %p4310 = inttoptr i64 %v4309 to ptr
  store i32 2, ptr %p4310, align 4, !alias.scope !3, !noalias !4
  %v4311 = load i64, ptr %slot19, align 8
  %p4312 = inttoptr i64 %v4311 to ptr
  %ld4313 = load i32, ptr %p4312, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4313, ptr %slot736, align 8
  %v4314 = load i32, ptr %slot736, align 8
  %v4315 = load i64, ptr %slot13, align 8
  %p4316 = inttoptr i64 %v4315 to ptr
  store i32 %v4314, ptr %p4316, align 4, !alias.scope !3, !noalias !4
  %v4317 = load i64, ptr %slot12, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  store i32 1, ptr %p4318, align 4, !alias.scope !3, !noalias !4
  %v4319 = load i64, ptr %slot10, align 8
  %p4320 = inttoptr i64 %v4319 to ptr
  %ld4321 = load i32, ptr %p4320, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4321, ptr %slot737, align 8
  %v4322 = load i32, ptr %slot737, align 8
  %cv4323 = zext i32 %v4322 to i64
  %cond4324 = icmp ne i64 %cv4323, 0
  br i1 %cond4324, label %bb_rcslotdrop939, label %bb_rcslotdone939
bb_rcslotdrop939:
  %v4325 = load i64, ptr %slot10, align 8
  %p4326 = inttoptr i64 %v4325 to ptr
  store i32 0, ptr %p4326, align 4, !alias.scope !3, !noalias !4
  %v4327 = load i64, ptr %slot30, align 8
  store i64 %v4327, ptr %slot738, align 8
  %v4328 = load i64, ptr %slot11, align 8
  %p4329 = inttoptr i64 %v4328 to ptr
  %ld4330 = load i32, ptr %p4329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4330, ptr %slot739, align 8
  %v4331 = load i32, ptr %slot739, align 8
  %op4332 = and i32 %v4331, 28
  store i32 %op4332, ptr %slot740, align 8
  %v4333 = load i32, ptr %slot740, align 8
  %cv4334 = zext i32 %v4333 to i64
  %cond4335 = icmp ne i64 %cv4334, 0
  br i1 %cond4335, label %bb_rcslotrole939, label %bb_rcslotowner939
bb_rcslotrole939:
  %v4336 = load i64, ptr %slot39, align 8
  store i64 %v4336, ptr %slot741, align 8
  %v4337 = load i64, ptr %slot738, align 8
  %p4338 = inttoptr i64 %v4337 to ptr
  %ld4339 = load i64, ptr %p4338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4339, ptr %slot742, align 8
  %v4340 = load i64, ptr %slot742, align 8
  %cmp4341 = icmp ne i64 %v4340, 0
  %cv4342 = zext i1 %cmp4341 to i32
  store i32 %cv4342, ptr %slot743, align 8
  %v4343 = load i32, ptr %slot743, align 8
  %cv4344 = zext i32 %v4343 to i64
  %cond4345 = icmp ne i64 %cv4344, 0
  br i1 %cond4345, label %bb_rcgnn955, label %bb_rcgdone955
bb_rcgnn955:
  %v4346 = load i64, ptr %slot742, align 8
  %op4347 = sub i64 %v4346, 16
  store i64 %op4347, ptr %slot744, align 8
  %v4348 = load i64, ptr %slot742, align 8
  %p4349 = inttoptr i64 %v4348 to ptr
  %rgep4350 = getelementptr i8, ptr %p4349, i64 -16
  %ld4351 = load i64, ptr %rgep4350, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4351, ptr %slot745, align 8
  %v4352 = load i64, ptr %slot745, align 8
  %op4353 = and i64 %v4352, 4611686018427387906
  store i64 %op4353, ptr %slot746, align 8
  %v4354 = load i64, ptr %slot746, align 8
  %cmp4355 = icmp ne i64 %v4354, 0
  %cv4356 = zext i1 %cmp4355 to i32
  store i32 %cv4356, ptr %slot747, align 8
  %v4357 = load i32, ptr %slot747, align 8
  %cv4358 = zext i32 %v4357 to i64
  %cond4359 = icmp ne i64 %cv4358, 0
  br i1 %cond4359, label %bb_rcgclear955, label %bb_rcgcounted955
bb_rcgcounted955:
  %v4360 = load i64, ptr %slot742, align 8
  %op4361 = sub i64 %v4360, 24
  store i64 %op4361, ptr %slot748, align 8
  %v4362 = load i64, ptr %slot742, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  %rgep4364 = getelementptr i8, ptr %p4363, i64 -24
  %ld4365 = load i64, ptr %rgep4364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4365, ptr %slot749, align 8
  %v4366 = load i64, ptr %slot749, align 8
  %op4367 = sub i64 %v4366, 1
  store i64 %op4367, ptr %slot750, align 8
  %v4368 = load i64, ptr %slot750, align 8
  %cmp4369 = icmp eq i64 %v4368, 0
  %cv4370 = zext i1 %cmp4369 to i32
  store i32 %cv4370, ptr %slot751, align 8
  %v4371 = load i32, ptr %slot751, align 8
  %cv4372 = zext i32 %v4371 to i64
  %cond4373 = icmp ne i64 %cv4372, 0
  br i1 %cond4373, label %bb_rcglast955, label %bb_rcgdec955
bb_rcglast955:
  %v4374 = load i64, ptr %slot742, align 8
  %op4375 = sub i64 %v4374, 32
  store i64 %op4375, ptr %slot752, align 8
  %v4376 = load i64, ptr %slot742, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %rgep4378 = getelementptr i8, ptr %p4377, i64 -32
  %ld4379 = load i64, ptr %rgep4378, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4379, ptr %slot753, align 8
  %v4380 = load i64, ptr %slot753, align 8
  %cmp4381 = icmp ne i64 %v4380, 0
  %cv4382 = zext i1 %cmp4381 to i32
  store i32 %cv4382, ptr %slot754, align 8
  %v4383 = load i32, ptr %slot754, align 8
  %cv4384 = zext i32 %v4383 to i64
  %cond4385 = icmp ne i64 %cv4384, 0
  br i1 %cond4385, label %bb_rcgdec955, label %bb_rcgslow955
bb_rcgslow955:
  %v4386 = load i64, ptr %slot741, align 8
  %v4387 = load i64, ptr %slot738, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v4386, i64 %v4387) nomerge, !dbg !150
  br label %bb_rcgdone955
bb_rcgdec955:
  %v4388 = load i64, ptr %slot750, align 8
  %v4389 = load i64, ptr %slot742, align 8
  %p4390 = inttoptr i64 %v4389 to ptr
  %rgep4391 = getelementptr i8, ptr %p4390, i64 -24
  store i64 %v4388, ptr %rgep4391, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear955
bb_rcgclear955:
  %v4392 = load i64, ptr %slot738, align 8
  %p4393 = inttoptr i64 %v4392 to ptr
  store i64 0, ptr %p4393, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone955
bb_rcgdone955:
  br label %bb_rcslotdone939
bb_rcslotowner939:
  %v4394 = load i64, ptr %slot39, align 8
  store i64 %v4394, ptr %slot755, align 8
  %v4395 = load i64, ptr %slot738, align 8
  %p4396 = inttoptr i64 %v4395 to ptr
  %ld4397 = load i64, ptr %p4396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4397, ptr %slot756, align 8
  %v4398 = load i64, ptr %slot756, align 8
  %cmp4399 = icmp ne i64 %v4398, 0
  %cv4400 = zext i1 %cmp4399 to i32
  store i32 %cv4400, ptr %slot757, align 8
  %v4401 = load i32, ptr %slot757, align 8
  %cv4402 = zext i32 %v4401 to i64
  %cond4403 = icmp ne i64 %cv4402, 0
  br i1 %cond4403, label %bb_rcgnn970, label %bb_rcgdone970
bb_rcgnn970:
  %v4404 = load i64, ptr %slot756, align 8
  %op4405 = sub i64 %v4404, 16
  store i64 %op4405, ptr %slot758, align 8
  %v4406 = load i64, ptr %slot756, align 8
  %p4407 = inttoptr i64 %v4406 to ptr
  %rgep4408 = getelementptr i8, ptr %p4407, i64 -16
  %ld4409 = load i64, ptr %rgep4408, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4409, ptr %slot759, align 8
  %v4410 = load i64, ptr %slot759, align 8
  %op4411 = and i64 %v4410, 4611686018427387906
  store i64 %op4411, ptr %slot760, align 8
  %v4412 = load i64, ptr %slot760, align 8
  %cmp4413 = icmp ne i64 %v4412, 0
  %cv4414 = zext i1 %cmp4413 to i32
  store i32 %cv4414, ptr %slot761, align 8
  %v4415 = load i32, ptr %slot761, align 8
  %cv4416 = zext i32 %v4415 to i64
  %cond4417 = icmp ne i64 %cv4416, 0
  br i1 %cond4417, label %bb_rcgclear970, label %bb_rcgcounted970
bb_rcgcounted970:
  %v4418 = load i64, ptr %slot756, align 8
  %op4419 = sub i64 %v4418, 32
  store i64 %op4419, ptr %slot762, align 8
  %v4420 = load i64, ptr %slot756, align 8
  %p4421 = inttoptr i64 %v4420 to ptr
  %rgep4422 = getelementptr i8, ptr %p4421, i64 -32
  %ld4423 = load i64, ptr %rgep4422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4423, ptr %slot763, align 8
  %v4424 = load i64, ptr %slot763, align 8
  %op4425 = sub i64 %v4424, 1
  store i64 %op4425, ptr %slot764, align 8
  %v4426 = load i64, ptr %slot764, align 8
  %cmp4427 = icmp eq i64 %v4426, 0
  %cv4428 = zext i1 %cmp4427 to i32
  store i32 %cv4428, ptr %slot765, align 8
  %v4429 = load i32, ptr %slot765, align 8
  %cv4430 = zext i32 %v4429 to i64
  %cond4431 = icmp ne i64 %cv4430, 0
  br i1 %cond4431, label %bb_rcglast970, label %bb_rcgdec970
bb_rcglast970:
  %v4432 = load i64, ptr %slot756, align 8
  %op4433 = sub i64 %v4432, 24
  store i64 %op4433, ptr %slot766, align 8
  %v4434 = load i64, ptr %slot756, align 8
  %p4435 = inttoptr i64 %v4434 to ptr
  %rgep4436 = getelementptr i8, ptr %p4435, i64 -24
  %ld4437 = load i64, ptr %rgep4436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4437, ptr %slot767, align 8
  %v4438 = load i64, ptr %slot767, align 8
  %cmp4439 = icmp ne i64 %v4438, 0
  %cv4440 = zext i1 %cmp4439 to i32
  store i32 %cv4440, ptr %slot768, align 8
  %v4441 = load i32, ptr %slot768, align 8
  %cv4442 = zext i32 %v4441 to i64
  %cond4443 = icmp ne i64 %cv4442, 0
  br i1 %cond4443, label %bb_rcgdec970, label %bb_rcgslow970
bb_rcgslow970:
  %v4444 = load i64, ptr %slot755, align 8
  %v4445 = load i64, ptr %slot738, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v4444, i64 %v4445) nomerge, !dbg !150
  br label %bb_rcgdone970
bb_rcgdec970:
  %v4446 = load i64, ptr %slot764, align 8
  %v4447 = load i64, ptr %slot756, align 8
  %p4448 = inttoptr i64 %v4447 to ptr
  %rgep4449 = getelementptr i8, ptr %p4448, i64 -32
  store i64 %v4446, ptr %rgep4449, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear970
bb_rcgclear970:
  %v4450 = load i64, ptr %slot738, align 8
  %p4451 = inttoptr i64 %v4450 to ptr
  store i64 0, ptr %p4451, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone970
bb_rcgdone970:
  br label %bb_rcslotdone939
bb_rcslotdone939:
  %v4452 = load i64, ptr %slot32, align 8
  %v4453 = load i64, ptr %slot33, align 8
  %p4454 = inttoptr i64 %v4453 to ptr
  store i64 %v4452, ptr %p4454, align 8, !alias.scope !3, !noalias !4
  %v4455 = load i64, ptr %slot33, align 8
  %p4456 = inttoptr i64 %v4455 to ptr
  %ld4457 = load i64, ptr %p4456, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4457, ptr %slot769, align 8
  %v4458 = load i64, ptr %slot769, align 8
  %op4459 = add i64 %v4458, 8
  store i64 %op4459, ptr %slot770, align 8
  %v4460 = load i64, ptr %slot770, align 8
  %p4461 = inttoptr i64 %v4460 to ptr
  %ld4462 = load i64, ptr %p4461, align 8
  store i64 %ld4462, ptr %slot771, align 8
  %v4463 = load i64, ptr %slot771, align 8
  %v4464 = load i64, ptr %slot33, align 8
  %p4465 = inttoptr i64 %v4464 to ptr
  store i64 %v4463, ptr %p4465, align 8, !alias.scope !3, !noalias !4
  %v4466 = load i64, ptr %slot14, align 8
  %p4467 = inttoptr i64 %v4466 to ptr
  %ld4468 = load i32, ptr %p4467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4468, ptr %slot772, align 8
  %v4469 = load i32, ptr %slot772, align 8
  %cv4470 = zext i32 %v4469 to i64
  %cond4471 = icmp ne i64 %cv4470, 0
  br i1 %cond4471, label %bb_rcslotdrop979, label %bb_rcslotdone979
bb_rcslotdrop979:
  %v4472 = load i64, ptr %slot14, align 8
  %p4473 = inttoptr i64 %v4472 to ptr
  store i32 0, ptr %p4473, align 4, !alias.scope !3, !noalias !4
  %v4474 = load i64, ptr %slot20, align 8
  store i64 %v4474, ptr %slot773, align 8
  %v4475 = load i64, ptr %slot15, align 8
  %p4476 = inttoptr i64 %v4475 to ptr
  %ld4477 = load i32, ptr %p4476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4477, ptr %slot774, align 8
  %v4478 = load i32, ptr %slot774, align 8
  %op4479 = and i32 %v4478, 28
  store i32 %op4479, ptr %slot775, align 8
  %v4480 = load i32, ptr %slot775, align 8
  %cv4481 = zext i32 %v4480 to i64
  %cond4482 = icmp ne i64 %cv4481, 0
  br i1 %cond4482, label %bb_rcslotrole979, label %bb_rcslotowner979
bb_rcslotrole979:
  %v4483 = load i64, ptr %slot39, align 8
  store i64 %v4483, ptr %slot776, align 8
  %v4484 = load i64, ptr %slot776, align 8
  %v4485 = load i64, ptr %slot773, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v4484, i64 %v4485) nomerge, !dbg !152
  br label %bb_rcslotdone979
bb_rcslotowner979:
  %v4486 = load i64, ptr %slot39, align 8
  store i64 %v4486, ptr %slot777, align 8
  %v4487 = load i64, ptr %slot777, align 8
  %v4488 = load i64, ptr %slot773, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v4487, i64 %v4488) nomerge, !dbg !152
  br label %bb_rcslotdone979
bb_rcslotdone979:
  %v4489 = load i64, ptr %slot34, align 8
  %p4490 = inttoptr i64 %v4489 to ptr
  store i64 18446744073709551615, ptr %p4490, align 8, !alias.scope !3, !noalias !4
  %v4491 = load i64, ptr %slot34, align 8
  %p4492 = inttoptr i64 %v4491 to ptr
  %ld4493 = load i64, ptr %p4492, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4493, ptr %slot778, align 8
  %v4494 = load i64, ptr %slot33, align 8
  %p4495 = inttoptr i64 %v4494 to ptr
  %ld4496 = load i64, ptr %p4495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4496, ptr %slot779, align 8
  %v4497 = load i64, ptr %slot779, align 8
  %v4498 = load i64, ptr %slot778, align 8
  %cmp4499 = icmp ne i64 %v4497, %v4498
  %cv4500 = zext i1 %cmp4499 to i64
  store i64 %cv4500, ptr %slot780, align 8
  %v4501 = load i64, ptr %slot780, align 8
  %v4502 = load i64, ptr %slot33, align 8
  %p4503 = inttoptr i64 %v4502 to ptr
  store i64 %v4501, ptr %p4503, align 8, !alias.scope !3, !noalias !4
  %v4504 = load i64, ptr %slot33, align 8
  %p4505 = inttoptr i64 %v4504 to ptr
  %ld4506 = load i64, ptr %p4505, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4506, ptr %slot781, align 8
  %v4507 = load i64, ptr %slot781, align 8
  %cond4508 = icmp ne i64 %v4507, 0
  br i1 %cond4508, label %bb_next990, label %bb_i56
bb_next990:
  %v4509 = load i64, ptr %slot32, align 8
  %v4510 = load i64, ptr %slot33, align 8
  %p4511 = inttoptr i64 %v4510 to ptr
  store i64 %v4509, ptr %p4511, align 8, !alias.scope !3, !noalias !4
  %v4512 = load i64, ptr %slot33, align 8
  %p4513 = inttoptr i64 %v4512 to ptr
  %ld4514 = load i64, ptr %p4513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4514, ptr %slot782, align 8
  %v4515 = load i64, ptr %slot782, align 8
  %op4516 = add i64 %v4515, 8
  store i64 %op4516, ptr %slot783, align 8
  %v4517 = load i64, ptr %slot783, align 8
  %p4518 = inttoptr i64 %v4517 to ptr
  %ld4519 = load i64, ptr %p4518, align 8
  store i64 %ld4519, ptr %slot784, align 8
  %v4520 = load i64, ptr %slot784, align 8
  %v4521 = load i64, ptr %slot33, align 8
  %p4522 = inttoptr i64 %v4521 to ptr
  store i64 %v4520, ptr %p4522, align 8, !alias.scope !3, !noalias !4
  %v4523 = load i64, ptr %slot14, align 8
  %p4524 = inttoptr i64 %v4523 to ptr
  %ld4525 = load i32, ptr %p4524, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4525, ptr %slot785, align 8
  %v4526 = load i32, ptr %slot785, align 8
  %cv4527 = zext i32 %v4526 to i64
  %cond4528 = icmp ne i64 %cv4527, 0
  br i1 %cond4528, label %bb_rcslotdrop995, label %bb_rcslotdone995
bb_rcslotdrop995:
  %v4529 = load i64, ptr %slot14, align 8
  %p4530 = inttoptr i64 %v4529 to ptr
  store i32 0, ptr %p4530, align 4, !alias.scope !3, !noalias !4
  %v4531 = load i64, ptr %slot20, align 8
  store i64 %v4531, ptr %slot786, align 8
  %v4532 = load i64, ptr %slot15, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  %ld4534 = load i32, ptr %p4533, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4534, ptr %slot787, align 8
  %v4535 = load i32, ptr %slot787, align 8
  %op4536 = and i32 %v4535, 28
  store i32 %op4536, ptr %slot788, align 8
  %v4537 = load i32, ptr %slot788, align 8
  %cv4538 = zext i32 %v4537 to i64
  %cond4539 = icmp ne i64 %cv4538, 0
  br i1 %cond4539, label %bb_rcslotrole995, label %bb_rcslotowner995
bb_rcslotrole995:
  %v4540 = load i64, ptr %slot39, align 8
  store i64 %v4540, ptr %slot789, align 8
  %v4541 = load i64, ptr %slot789, align 8
  %v4542 = load i64, ptr %slot786, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v4541, i64 %v4542) nomerge, !dbg !154
  br label %bb_rcslotdone995
bb_rcslotowner995:
  %v4543 = load i64, ptr %slot39, align 8
  store i64 %v4543, ptr %slot790, align 8
  %v4544 = load i64, ptr %slot790, align 8
  %v4545 = load i64, ptr %slot786, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v4544, i64 %v4545) nomerge, !dbg !154
  br label %bb_rcslotdone995
bb_rcslotdone995:
  %v4546 = load i64, ptr %slot26, align 8
  %v4547 = load i64, ptr %slot34, align 8
  %p4548 = inttoptr i64 %v4547 to ptr
  store i64 %v4546, ptr %p4548, align 8, !alias.scope !3, !noalias !4
  %v4549 = load i64, ptr %slot34, align 8
  %p4550 = inttoptr i64 %v4549 to ptr
  %ld4551 = load i64, ptr %p4550, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4551, ptr %slot791, align 8
  %v4552 = load i64, ptr %slot791, align 8
  %op4553 = add i64 %v4552, 80
  store i64 %op4553, ptr %slot792, align 8
  %v4554 = load i64, ptr %slot792, align 8
  %p4555 = inttoptr i64 %v4554 to ptr
  %ld4556 = load i64, ptr %p4555, align 8
  store i64 %ld4556, ptr %slot793, align 8
  %v4557 = load i64, ptr %slot793, align 8
  %v4558 = load i64, ptr %slot34, align 8
  %p4559 = inttoptr i64 %v4558 to ptr
  store i64 %v4557, ptr %p4559, align 8, !alias.scope !3, !noalias !4
  %v4560 = load i64, ptr %slot16, align 8
  %p4561 = inttoptr i64 %v4560 to ptr
  %ld4562 = load i32, ptr %p4561, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4562, ptr %slot794, align 8
  %v4563 = load i32, ptr %slot794, align 8
  %cv4564 = zext i32 %v4563 to i64
  %cond4565 = icmp ne i64 %cv4564, 0
  br i1 %cond4565, label %bb_rcslotdrop1007, label %bb_rcslotdone1007
bb_rcslotdrop1007:
  %v4566 = load i64, ptr %slot16, align 8
  %p4567 = inttoptr i64 %v4566 to ptr
  store i32 0, ptr %p4567, align 4, !alias.scope !3, !noalias !4
  %v4568 = load i64, ptr %slot21, align 8
  store i64 %v4568, ptr %slot795, align 8
  %v4569 = load i64, ptr %slot17, align 8
  %p4570 = inttoptr i64 %v4569 to ptr
  %ld4571 = load i32, ptr %p4570, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4571, ptr %slot796, align 8
  %v4572 = load i32, ptr %slot796, align 8
  %op4573 = and i32 %v4572, 28
  store i32 %op4573, ptr %slot797, align 8
  %v4574 = load i32, ptr %slot797, align 8
  %cv4575 = zext i32 %v4574 to i64
  %cond4576 = icmp ne i64 %cv4575, 0
  br i1 %cond4576, label %bb_rcslotrole1007, label %bb_rcslotowner1007
bb_rcslotrole1007:
  %v4577 = load i64, ptr %slot39, align 8
  store i64 %v4577, ptr %slot798, align 8
  %v4578 = load i64, ptr %slot798, align 8
  %v4579 = load i64, ptr %slot795, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v4578, i64 %v4579) nomerge, !dbg !156
  br label %bb_rcslotdone1007
bb_rcslotowner1007:
  %v4580 = load i64, ptr %slot39, align 8
  store i64 %v4580, ptr %slot799, align 8
  %v4581 = load i64, ptr %slot799, align 8
  %v4582 = load i64, ptr %slot795, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v4581, i64 %v4582) nomerge, !dbg !156
  br label %bb_rcslotdone1007
bb_rcslotdone1007:
  %v4583 = load i64, ptr %slot34, align 8
  %p4584 = inttoptr i64 %v4583 to ptr
  %ld4585 = load i64, ptr %p4584, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4585, ptr %slot800, align 8
  %v4586 = load i64, ptr %slot33, align 8
  %p4587 = inttoptr i64 %v4586 to ptr
  %ld4588 = load i64, ptr %p4587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4588, ptr %slot801, align 8
  %v4589 = load i64, ptr %slot801, align 8
  %v4590 = load i64, ptr %slot800, align 8
  %cmp4591 = icmp slt i64 %v4589, %v4590
  %cv4592 = zext i1 %cmp4591 to i64
  store i64 %cv4592, ptr %slot802, align 8
  %v4593 = load i64, ptr %slot802, align 8
  %v4594 = load i64, ptr %slot33, align 8
  %p4595 = inttoptr i64 %v4594 to ptr
  store i64 %v4593, ptr %p4595, align 8, !alias.scope !3, !noalias !4
  br label %bb_i57
bb_i56:
  %v4596 = load i64, ptr %slot33, align 8
  %p4597 = inttoptr i64 %v4596 to ptr
  store i64 0, ptr %p4597, align 8, !alias.scope !3, !noalias !4
  br label %bb_i57
bb_i57:
  %v4598 = load i64, ptr %slot33, align 8
  %p4599 = inttoptr i64 %v4598 to ptr
  %ld4600 = load i64, ptr %p4599, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4600, ptr %slot803, align 8
  %v4601 = load i64, ptr %slot803, align 8
  %cond4602 = icmp ne i64 %v4601, 0
  br i1 %cond4602, label %bb_next1018, label %bb_i59
bb_next1018:
  br label %bb_i73
bb_i59:
  %v4603 = load i64, ptr %slot32, align 8
  %v4604 = load i64, ptr %slot33, align 8
  %p4605 = inttoptr i64 %v4604 to ptr
  store i64 %v4603, ptr %p4605, align 8, !alias.scope !3, !noalias !4
  %v4606 = load i64, ptr %slot33, align 8
  %p4607 = inttoptr i64 %v4606 to ptr
  %ld4608 = load i64, ptr %p4607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4608, ptr %slot804, align 8
  %v4609 = load i64, ptr %slot804, align 8
  %op4610 = add i64 %v4609, 0
  store i64 %op4610, ptr %slot805, align 8
  %v4611 = load i64, ptr %slot805, align 8
  %p4612 = inttoptr i64 %v4611 to ptr
  %ld4613 = load i64, ptr %p4612, align 8
  store i64 %ld4613, ptr %slot806, align 8
  %v4614 = load i64, ptr %slot806, align 8
  %v4615 = load i64, ptr %slot33, align 8
  %p4616 = inttoptr i64 %v4615 to ptr
  store i64 %v4614, ptr %p4616, align 8, !alias.scope !3, !noalias !4
  %v4617 = load i64, ptr %slot33, align 8
  %p4618 = inttoptr i64 %v4617 to ptr
  %ld4619 = load i64, ptr %p4618, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4619, ptr %slot807, align 8
  %v4620 = load i64, ptr %slot807, align 8
  %v4621 = load i64, ptr %slot22, align 8
  %p4622 = inttoptr i64 %v4621 to ptr
  store i64 %v4620, ptr %p4622, align 8, !alias.scope !3, !noalias !4
  %v4623 = load i64, ptr %slot22, align 8
  store i64 %v4623, ptr %slot808, align 8
  %v4624 = load i64, ptr %slot24, align 8
  store i64 %v4624, ptr %slot809, align 8
  %v4625 = load i64, ptr %slot808, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  %ld4627 = load i64, ptr %p4626, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4627, ptr %slot810, align 8
  %v4628 = load i64, ptr %slot810, align 8
  %cmp4629 = icmp ne i64 %v4628, 0
  %cv4630 = zext i1 %cmp4629 to i32
  store i32 %cv4630, ptr %slot811, align 8
  %v4631 = load i32, ptr %slot811, align 8
  %cv4632 = zext i32 %v4631 to i64
  %cond4633 = icmp ne i64 %cv4632, 0
  br i1 %cond4633, label %bb_rcgnn1025, label %bb_rcgstore1025
bb_rcgnn1025:
  %v4634 = load i64, ptr %slot810, align 8
  %op4635 = sub i64 %v4634, 16
  store i64 %op4635, ptr %slot812, align 8
  %v4636 = load i64, ptr %slot810, align 8
  %p4637 = inttoptr i64 %v4636 to ptr
  %rgep4638 = getelementptr i8, ptr %p4637, i64 -16
  %ld4639 = load i64, ptr %rgep4638, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4639, ptr %slot813, align 8
  %v4640 = load i64, ptr %slot813, align 8
  %op4641 = and i64 %v4640, 4611686018427387906
  store i64 %op4641, ptr %slot814, align 8
  %v4642 = load i64, ptr %slot814, align 8
  %cmp4643 = icmp ne i64 %v4642, 0
  %cv4644 = zext i1 %cmp4643 to i32
  store i32 %cv4644, ptr %slot815, align 8
  %v4645 = load i32, ptr %slot815, align 8
  %cv4646 = zext i32 %v4645 to i64
  %cond4647 = icmp ne i64 %cv4646, 0
  br i1 %cond4647, label %bb_rcgstore1025, label %bb_rcginc1025
bb_rcginc1025:
  %v4648 = load i64, ptr %slot810, align 8
  %op4649 = sub i64 %v4648, 24
  store i64 %op4649, ptr %slot816, align 8
  %v4650 = load i64, ptr %slot810, align 8
  %p4651 = inttoptr i64 %v4650 to ptr
  %rgep4652 = getelementptr i8, ptr %p4651, i64 -24
  %ld4653 = load i64, ptr %rgep4652, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4653, ptr %slot817, align 8
  %v4654 = load i64, ptr %slot817, align 8
  %op4655 = add i64 %v4654, 1
  store i64 %op4655, ptr %slot818, align 8
  %v4656 = load i64, ptr %slot818, align 8
  %cmp4657 = icmp eq i64 %v4656, 0
  %cv4658 = zext i1 %cmp4657 to i32
  store i32 %cv4658, ptr %slot819, align 8
  %v4659 = load i32, ptr %slot819, align 8
  %cv4660 = zext i32 %v4659 to i64
  %cond4661 = icmp ne i64 %cv4660, 0
  br i1 %cond4661, label %bb_rcglimit1025, label %bb_rcgcapacity1025
bb_rcglimit1025:
  %v4662 = load i64, ptr %slot1, align 8
  %p4663 = inttoptr i64 %v4662 to ptr
  %call4664 = call i32 @myl_qbe_rc_status(ptr %p4663, i32 2) nomerge, !dbg !158
  store i32 %call4664, ptr %slot820, align 8
  br label %bb_failure
bb_rcgcapacity1025:
  %v4665 = load i64, ptr %slot818, align 8
  %v4666 = load i64, ptr %slot810, align 8
  %p4667 = inttoptr i64 %v4666 to ptr
  %rgep4668 = getelementptr i8, ptr %p4667, i64 -24
  store i64 %v4665, ptr %rgep4668, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore1025
bb_rcgstore1025:
  %v4669 = load i64, ptr %slot810, align 8
  %v4670 = load i64, ptr %slot809, align 8
  %p4671 = inttoptr i64 %v4670 to ptr
  store i64 %v4669, ptr %p4671, align 8, !alias.scope !3, !noalias !4
  %v4672 = load i64, ptr %slot19, align 8
  %p4673 = inttoptr i64 %v4672 to ptr
  store i32 2, ptr %p4673, align 4, !alias.scope !3, !noalias !4
  %v4674 = load i64, ptr %slot19, align 8
  %p4675 = inttoptr i64 %v4674 to ptr
  store i32 16, ptr %p4675, align 4, !alias.scope !3, !noalias !4
  %v4676 = load i64, ptr %slot18, align 8
  %p4677 = inttoptr i64 %v4676 to ptr
  store i32 1, ptr %p4677, align 4, !alias.scope !3, !noalias !4
  %v4678 = load i64, ptr %slot14, align 8
  %p4679 = inttoptr i64 %v4678 to ptr
  %ld4680 = load i32, ptr %p4679, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4680, ptr %slot821, align 8
  %v4681 = load i32, ptr %slot821, align 8
  %cv4682 = zext i32 %v4681 to i64
  %cond4683 = icmp ne i64 %cv4682, 0
  br i1 %cond4683, label %bb_rcslotdrop1041, label %bb_rcslotdone1041
bb_rcslotdrop1041:
  %v4684 = load i64, ptr %slot14, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  store i32 0, ptr %p4685, align 4, !alias.scope !3, !noalias !4
  %v4686 = load i64, ptr %slot20, align 8
  store i64 %v4686, ptr %slot822, align 8
  %v4687 = load i64, ptr %slot15, align 8
  %p4688 = inttoptr i64 %v4687 to ptr
  %ld4689 = load i32, ptr %p4688, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4689, ptr %slot823, align 8
  %v4690 = load i32, ptr %slot823, align 8
  %op4691 = and i32 %v4690, 28
  store i32 %op4691, ptr %slot824, align 8
  %v4692 = load i32, ptr %slot824, align 8
  %cv4693 = zext i32 %v4692 to i64
  %cond4694 = icmp ne i64 %cv4693, 0
  br i1 %cond4694, label %bb_rcslotrole1041, label %bb_rcslotowner1041
bb_rcslotrole1041:
  %v4695 = load i64, ptr %slot39, align 8
  store i64 %v4695, ptr %slot825, align 8
  %v4696 = load i64, ptr %slot825, align 8
  %v4697 = load i64, ptr %slot822, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v4696, i64 %v4697) nomerge, !dbg !158
  br label %bb_rcslotdone1041
bb_rcslotowner1041:
  %v4698 = load i64, ptr %slot39, align 8
  store i64 %v4698, ptr %slot826, align 8
  %v4699 = load i64, ptr %slot826, align 8
  %v4700 = load i64, ptr %slot822, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v4699, i64 %v4700) nomerge, !dbg !158
  br label %bb_rcslotdone1041
bb_rcslotdone1041:
  %v4701 = load i64, ptr %slot20, align 8
  store i64 %v4701, ptr %slot827, align 8
  %v4702 = load i64, ptr %slot24, align 8
  store i64 %v4702, ptr %slot828, align 8
  %v4703 = load i64, ptr %slot828, align 8
  %v4704 = load i64, ptr %slot827, align 8
  %p4705 = inttoptr i64 %v4703 to ptr
  %p4706 = inttoptr i64 %v4704 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4706, ptr %p4705, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v4707 = load i64, ptr %slot15, align 8
  %p4708 = inttoptr i64 %v4707 to ptr
  store i32 2, ptr %p4708, align 4, !alias.scope !3, !noalias !4
  %v4709 = load i64, ptr %slot19, align 8
  %p4710 = inttoptr i64 %v4709 to ptr
  %ld4711 = load i32, ptr %p4710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4711, ptr %slot829, align 8
  %v4712 = load i32, ptr %slot829, align 8
  %v4713 = load i64, ptr %slot15, align 8
  %p4714 = inttoptr i64 %v4713 to ptr
  store i32 %v4712, ptr %p4714, align 4, !alias.scope !3, !noalias !4
  %v4715 = load i64, ptr %slot18, align 8
  %p4716 = inttoptr i64 %v4715 to ptr
  store i32 0, ptr %p4716, align 4, !alias.scope !3, !noalias !4
  %v4717 = load i64, ptr %slot14, align 8
  %p4718 = inttoptr i64 %v4717 to ptr
  store i32 1, ptr %p4718, align 4, !alias.scope !3, !noalias !4
  %v4719 = load i64, ptr %slot827, align 8
  %p4720 = inttoptr i64 %v4719 to ptr
  %ld4721 = load i64, ptr %p4720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4721, ptr %slot830, align 8
  %v4722 = load i64, ptr %slot830, align 8
  %v4723 = load i64, ptr %slot33, align 8
  %p4724 = inttoptr i64 %v4723 to ptr
  store i64 %v4722, ptr %p4724, align 8, !alias.scope !3, !noalias !4
  %v4725 = load i64, ptr %slot27, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  %ld4727 = load i64, ptr %p4726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4727, ptr %slot831, align 8
  %v4728 = load i64, ptr %slot831, align 8
  %v4729 = load i64, ptr %slot34, align 8
  %p4730 = inttoptr i64 %v4729 to ptr
  store i64 %v4728, ptr %p4730, align 8, !alias.scope !3, !noalias !4
  %v4731 = load i64, ptr %slot33, align 8
  %p4732 = inttoptr i64 %v4731 to ptr
  %ld4733 = load i64, ptr %p4732, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4733, ptr %slot832, align 8
  %v4734 = load i64, ptr %slot34, align 8
  %p4735 = inttoptr i64 %v4734 to ptr
  %ld4736 = load i64, ptr %p4735, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4736, ptr %slot833, align 8
  %v4737 = load i64, ptr %slot33, align 8
  store i64 %v4737, ptr %slot834, align 8
  %v4738 = load i64, ptr %slot34, align 8
  store i64 %v4738, ptr %slot835, align 8
  %p4739 = inttoptr i64 ptrtoint (ptr @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9 to i64) to ptr
  %v4740 = load i64, ptr %slot834, align 8
  %p4741 = inttoptr i64 %v4740 to ptr
  %v4742 = load i64, ptr %slot835, align 8
  %p4743 = inttoptr i64 %v4742 to ptr
  %call4744 = call i32 @myl_native_equal(ptr %p4739, ptr %p4741, ptr %p4743) nomerge, !dbg !160
  store i32 %call4744, ptr %slot836, align 8
  %v4745 = load i32, ptr %slot836, align 8
  %cmp4746 = icmp sge i32 %v4745, 0
  %cv4747 = zext i1 %cmp4746 to i32
  store i32 %cv4747, ptr %slot837, align 8
  %v4748 = load i32, ptr %slot837, align 8
  %cv4749 = zext i32 %v4748 to i64
  %cond4750 = icmp ne i64 %cv4749, 0
  br i1 %cond4750, label %bb_equalok1064, label %bb_equalerror1064
bb_equalerror1064:
  %v4751 = load i64, ptr %slot1, align 8
  %p4752 = inttoptr i64 %v4751 to ptr
  %v4753 = load i32, ptr %slot836, align 8
  call void @myl_qbe_fail_equality(ptr %p4752, i32 %v4753) nomerge, !dbg !160
  unreachable
bb_equalok1064:
  %v4754 = load i32, ptr %slot836, align 8
  %ext4755 = zext i32 %v4754 to i64
  store i64 %ext4755, ptr %slot838, align 8
  %v4756 = load i64, ptr %slot838, align 8
  %v4757 = load i64, ptr %slot33, align 8
  %p4758 = inttoptr i64 %v4757 to ptr
  store i64 %v4756, ptr %p4758, align 8, !alias.scope !3, !noalias !4
  %v4759 = load i64, ptr %slot14, align 8
  %p4760 = inttoptr i64 %v4759 to ptr
  %ld4761 = load i32, ptr %p4760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4761, ptr %slot839, align 8
  %v4762 = load i32, ptr %slot839, align 8
  %cv4763 = zext i32 %v4762 to i64
  %cond4764 = icmp ne i64 %cv4763, 0
  br i1 %cond4764, label %bb_rcslotdrop1068, label %bb_rcslotdone1068
bb_rcslotdrop1068:
  %v4765 = load i64, ptr %slot14, align 8
  %p4766 = inttoptr i64 %v4765 to ptr
  store i32 0, ptr %p4766, align 4, !alias.scope !3, !noalias !4
  %v4767 = load i64, ptr %slot20, align 8
  store i64 %v4767, ptr %slot840, align 8
  %v4768 = load i64, ptr %slot15, align 8
  %p4769 = inttoptr i64 %v4768 to ptr
  %ld4770 = load i32, ptr %p4769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4770, ptr %slot841, align 8
  %v4771 = load i32, ptr %slot841, align 8
  %op4772 = and i32 %v4771, 28
  store i32 %op4772, ptr %slot842, align 8
  %v4773 = load i32, ptr %slot842, align 8
  %cv4774 = zext i32 %v4773 to i64
  %cond4775 = icmp ne i64 %cv4774, 0
  br i1 %cond4775, label %bb_rcslotrole1068, label %bb_rcslotowner1068
bb_rcslotrole1068:
  %v4776 = load i64, ptr %slot39, align 8
  store i64 %v4776, ptr %slot843, align 8
  %v4777 = load i64, ptr %slot840, align 8
  %p4778 = inttoptr i64 %v4777 to ptr
  %ld4779 = load i64, ptr %p4778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4779, ptr %slot844, align 8
  %v4780 = load i64, ptr %slot844, align 8
  %cmp4781 = icmp ne i64 %v4780, 0
  %cv4782 = zext i1 %cmp4781 to i32
  store i32 %cv4782, ptr %slot845, align 8
  %v4783 = load i32, ptr %slot845, align 8
  %cv4784 = zext i32 %v4783 to i64
  %cond4785 = icmp ne i64 %cv4784, 0
  br i1 %cond4785, label %bb_rcgnn1084, label %bb_rcgdone1084
bb_rcgnn1084:
  %v4786 = load i64, ptr %slot844, align 8
  %op4787 = sub i64 %v4786, 16
  store i64 %op4787, ptr %slot846, align 8
  %v4788 = load i64, ptr %slot844, align 8
  %p4789 = inttoptr i64 %v4788 to ptr
  %rgep4790 = getelementptr i8, ptr %p4789, i64 -16
  %ld4791 = load i64, ptr %rgep4790, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4791, ptr %slot847, align 8
  %v4792 = load i64, ptr %slot847, align 8
  %op4793 = and i64 %v4792, 4611686018427387906
  store i64 %op4793, ptr %slot848, align 8
  %v4794 = load i64, ptr %slot848, align 8
  %cmp4795 = icmp ne i64 %v4794, 0
  %cv4796 = zext i1 %cmp4795 to i32
  store i32 %cv4796, ptr %slot849, align 8
  %v4797 = load i32, ptr %slot849, align 8
  %cv4798 = zext i32 %v4797 to i64
  %cond4799 = icmp ne i64 %cv4798, 0
  br i1 %cond4799, label %bb_rcgclear1084, label %bb_rcgcounted1084
bb_rcgcounted1084:
  %v4800 = load i64, ptr %slot844, align 8
  %op4801 = sub i64 %v4800, 24
  store i64 %op4801, ptr %slot850, align 8
  %v4802 = load i64, ptr %slot844, align 8
  %p4803 = inttoptr i64 %v4802 to ptr
  %rgep4804 = getelementptr i8, ptr %p4803, i64 -24
  %ld4805 = load i64, ptr %rgep4804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4805, ptr %slot851, align 8
  %v4806 = load i64, ptr %slot851, align 8
  %op4807 = sub i64 %v4806, 1
  store i64 %op4807, ptr %slot852, align 8
  %v4808 = load i64, ptr %slot852, align 8
  %cmp4809 = icmp eq i64 %v4808, 0
  %cv4810 = zext i1 %cmp4809 to i32
  store i32 %cv4810, ptr %slot853, align 8
  %v4811 = load i32, ptr %slot853, align 8
  %cv4812 = zext i32 %v4811 to i64
  %cond4813 = icmp ne i64 %cv4812, 0
  br i1 %cond4813, label %bb_rcglast1084, label %bb_rcgdec1084
bb_rcglast1084:
  %v4814 = load i64, ptr %slot844, align 8
  %op4815 = sub i64 %v4814, 32
  store i64 %op4815, ptr %slot854, align 8
  %v4816 = load i64, ptr %slot844, align 8
  %p4817 = inttoptr i64 %v4816 to ptr
  %rgep4818 = getelementptr i8, ptr %p4817, i64 -32
  %ld4819 = load i64, ptr %rgep4818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4819, ptr %slot855, align 8
  %v4820 = load i64, ptr %slot855, align 8
  %cmp4821 = icmp ne i64 %v4820, 0
  %cv4822 = zext i1 %cmp4821 to i32
  store i32 %cv4822, ptr %slot856, align 8
  %v4823 = load i32, ptr %slot856, align 8
  %cv4824 = zext i32 %v4823 to i64
  %cond4825 = icmp ne i64 %cv4824, 0
  br i1 %cond4825, label %bb_rcgdec1084, label %bb_rcgslow1084
bb_rcgslow1084:
  %v4826 = load i64, ptr %slot843, align 8
  %v4827 = load i64, ptr %slot840, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4826, i64 %v4827) nomerge, !dbg !160
  br label %bb_rcgdone1084
bb_rcgdec1084:
  %v4828 = load i64, ptr %slot852, align 8
  %v4829 = load i64, ptr %slot844, align 8
  %p4830 = inttoptr i64 %v4829 to ptr
  %rgep4831 = getelementptr i8, ptr %p4830, i64 -24
  store i64 %v4828, ptr %rgep4831, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1084
bb_rcgclear1084:
  %v4832 = load i64, ptr %slot840, align 8
  %p4833 = inttoptr i64 %v4832 to ptr
  store i64 0, ptr %p4833, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1084
bb_rcgdone1084:
  br label %bb_rcslotdone1068
bb_rcslotowner1068:
  %v4834 = load i64, ptr %slot39, align 8
  store i64 %v4834, ptr %slot857, align 8
  %v4835 = load i64, ptr %slot840, align 8
  %p4836 = inttoptr i64 %v4835 to ptr
  %ld4837 = load i64, ptr %p4836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4837, ptr %slot858, align 8
  %v4838 = load i64, ptr %slot858, align 8
  %cmp4839 = icmp ne i64 %v4838, 0
  %cv4840 = zext i1 %cmp4839 to i32
  store i32 %cv4840, ptr %slot859, align 8
  %v4841 = load i32, ptr %slot859, align 8
  %cv4842 = zext i32 %v4841 to i64
  %cond4843 = icmp ne i64 %cv4842, 0
  br i1 %cond4843, label %bb_rcgnn1099, label %bb_rcgdone1099
bb_rcgnn1099:
  %v4844 = load i64, ptr %slot858, align 8
  %op4845 = sub i64 %v4844, 16
  store i64 %op4845, ptr %slot860, align 8
  %v4846 = load i64, ptr %slot858, align 8
  %p4847 = inttoptr i64 %v4846 to ptr
  %rgep4848 = getelementptr i8, ptr %p4847, i64 -16
  %ld4849 = load i64, ptr %rgep4848, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4849, ptr %slot861, align 8
  %v4850 = load i64, ptr %slot861, align 8
  %op4851 = and i64 %v4850, 4611686018427387906
  store i64 %op4851, ptr %slot862, align 8
  %v4852 = load i64, ptr %slot862, align 8
  %cmp4853 = icmp ne i64 %v4852, 0
  %cv4854 = zext i1 %cmp4853 to i32
  store i32 %cv4854, ptr %slot863, align 8
  %v4855 = load i32, ptr %slot863, align 8
  %cv4856 = zext i32 %v4855 to i64
  %cond4857 = icmp ne i64 %cv4856, 0
  br i1 %cond4857, label %bb_rcgclear1099, label %bb_rcgcounted1099
bb_rcgcounted1099:
  %v4858 = load i64, ptr %slot858, align 8
  %op4859 = sub i64 %v4858, 32
  store i64 %op4859, ptr %slot864, align 8
  %v4860 = load i64, ptr %slot858, align 8
  %p4861 = inttoptr i64 %v4860 to ptr
  %rgep4862 = getelementptr i8, ptr %p4861, i64 -32
  %ld4863 = load i64, ptr %rgep4862, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4863, ptr %slot865, align 8
  %v4864 = load i64, ptr %slot865, align 8
  %op4865 = sub i64 %v4864, 1
  store i64 %op4865, ptr %slot866, align 8
  %v4866 = load i64, ptr %slot866, align 8
  %cmp4867 = icmp eq i64 %v4866, 0
  %cv4868 = zext i1 %cmp4867 to i32
  store i32 %cv4868, ptr %slot867, align 8
  %v4869 = load i32, ptr %slot867, align 8
  %cv4870 = zext i32 %v4869 to i64
  %cond4871 = icmp ne i64 %cv4870, 0
  br i1 %cond4871, label %bb_rcglast1099, label %bb_rcgdec1099
bb_rcglast1099:
  %v4872 = load i64, ptr %slot858, align 8
  %op4873 = sub i64 %v4872, 24
  store i64 %op4873, ptr %slot868, align 8
  %v4874 = load i64, ptr %slot858, align 8
  %p4875 = inttoptr i64 %v4874 to ptr
  %rgep4876 = getelementptr i8, ptr %p4875, i64 -24
  %ld4877 = load i64, ptr %rgep4876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4877, ptr %slot869, align 8
  %v4878 = load i64, ptr %slot869, align 8
  %cmp4879 = icmp ne i64 %v4878, 0
  %cv4880 = zext i1 %cmp4879 to i32
  store i32 %cv4880, ptr %slot870, align 8
  %v4881 = load i32, ptr %slot870, align 8
  %cv4882 = zext i32 %v4881 to i64
  %cond4883 = icmp ne i64 %cv4882, 0
  br i1 %cond4883, label %bb_rcgdec1099, label %bb_rcgslow1099
bb_rcgslow1099:
  %v4884 = load i64, ptr %slot857, align 8
  %v4885 = load i64, ptr %slot840, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v4884, i64 %v4885) nomerge, !dbg !160
  br label %bb_rcgdone1099
bb_rcgdec1099:
  %v4886 = load i64, ptr %slot866, align 8
  %v4887 = load i64, ptr %slot858, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  %rgep4889 = getelementptr i8, ptr %p4888, i64 -32
  store i64 %v4886, ptr %rgep4889, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1099
bb_rcgclear1099:
  %v4890 = load i64, ptr %slot840, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  store i64 0, ptr %p4891, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1099
bb_rcgdone1099:
  br label %bb_rcslotdone1068
bb_rcslotdone1068:
  %v4892 = load i64, ptr %slot16, align 8
  %p4893 = inttoptr i64 %v4892 to ptr
  %ld4894 = load i32, ptr %p4893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4894, ptr %slot871, align 8
  %v4895 = load i32, ptr %slot871, align 8
  %cv4896 = zext i32 %v4895 to i64
  %cond4897 = icmp ne i64 %cv4896, 0
  br i1 %cond4897, label %bb_rcslotdrop1105, label %bb_rcslotdone1105
bb_rcslotdrop1105:
  %v4898 = load i64, ptr %slot16, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  store i32 0, ptr %p4899, align 4, !alias.scope !3, !noalias !4
  %v4900 = load i64, ptr %slot21, align 8
  store i64 %v4900, ptr %slot872, align 8
  %v4901 = load i64, ptr %slot17, align 8
  %p4902 = inttoptr i64 %v4901 to ptr
  %ld4903 = load i32, ptr %p4902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4903, ptr %slot873, align 8
  %v4904 = load i32, ptr %slot873, align 8
  %op4905 = and i32 %v4904, 28
  store i32 %op4905, ptr %slot874, align 8
  %v4906 = load i32, ptr %slot874, align 8
  %cv4907 = zext i32 %v4906 to i64
  %cond4908 = icmp ne i64 %cv4907, 0
  br i1 %cond4908, label %bb_rcslotrole1105, label %bb_rcslotowner1105
bb_rcslotrole1105:
  %v4909 = load i64, ptr %slot39, align 8
  store i64 %v4909, ptr %slot875, align 8
  %v4910 = load i64, ptr %slot872, align 8
  %p4911 = inttoptr i64 %v4910 to ptr
  %ld4912 = load i64, ptr %p4911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4912, ptr %slot876, align 8
  %v4913 = load i64, ptr %slot876, align 8
  %cmp4914 = icmp ne i64 %v4913, 0
  %cv4915 = zext i1 %cmp4914 to i32
  store i32 %cv4915, ptr %slot877, align 8
  %v4916 = load i32, ptr %slot877, align 8
  %cv4917 = zext i32 %v4916 to i64
  %cond4918 = icmp ne i64 %cv4917, 0
  br i1 %cond4918, label %bb_rcgnn1121, label %bb_rcgdone1121
bb_rcgnn1121:
  %v4919 = load i64, ptr %slot876, align 8
  %op4920 = sub i64 %v4919, 16
  store i64 %op4920, ptr %slot878, align 8
  %v4921 = load i64, ptr %slot876, align 8
  %p4922 = inttoptr i64 %v4921 to ptr
  %rgep4923 = getelementptr i8, ptr %p4922, i64 -16
  %ld4924 = load i64, ptr %rgep4923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4924, ptr %slot879, align 8
  %v4925 = load i64, ptr %slot879, align 8
  %op4926 = and i64 %v4925, 4611686018427387906
  store i64 %op4926, ptr %slot880, align 8
  %v4927 = load i64, ptr %slot880, align 8
  %cmp4928 = icmp ne i64 %v4927, 0
  %cv4929 = zext i1 %cmp4928 to i32
  store i32 %cv4929, ptr %slot881, align 8
  %v4930 = load i32, ptr %slot881, align 8
  %cv4931 = zext i32 %v4930 to i64
  %cond4932 = icmp ne i64 %cv4931, 0
  br i1 %cond4932, label %bb_rcgclear1121, label %bb_rcgcounted1121
bb_rcgcounted1121:
  %v4933 = load i64, ptr %slot876, align 8
  %op4934 = sub i64 %v4933, 24
  store i64 %op4934, ptr %slot882, align 8
  %v4935 = load i64, ptr %slot876, align 8
  %p4936 = inttoptr i64 %v4935 to ptr
  %rgep4937 = getelementptr i8, ptr %p4936, i64 -24
  %ld4938 = load i64, ptr %rgep4937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4938, ptr %slot883, align 8
  %v4939 = load i64, ptr %slot883, align 8
  %op4940 = sub i64 %v4939, 1
  store i64 %op4940, ptr %slot884, align 8
  %v4941 = load i64, ptr %slot884, align 8
  %cmp4942 = icmp eq i64 %v4941, 0
  %cv4943 = zext i1 %cmp4942 to i32
  store i32 %cv4943, ptr %slot885, align 8
  %v4944 = load i32, ptr %slot885, align 8
  %cv4945 = zext i32 %v4944 to i64
  %cond4946 = icmp ne i64 %cv4945, 0
  br i1 %cond4946, label %bb_rcglast1121, label %bb_rcgdec1121
bb_rcglast1121:
  %v4947 = load i64, ptr %slot876, align 8
  %op4948 = sub i64 %v4947, 32
  store i64 %op4948, ptr %slot886, align 8
  %v4949 = load i64, ptr %slot876, align 8
  %p4950 = inttoptr i64 %v4949 to ptr
  %rgep4951 = getelementptr i8, ptr %p4950, i64 -32
  %ld4952 = load i64, ptr %rgep4951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4952, ptr %slot887, align 8
  %v4953 = load i64, ptr %slot887, align 8
  %cmp4954 = icmp ne i64 %v4953, 0
  %cv4955 = zext i1 %cmp4954 to i32
  store i32 %cv4955, ptr %slot888, align 8
  %v4956 = load i32, ptr %slot888, align 8
  %cv4957 = zext i32 %v4956 to i64
  %cond4958 = icmp ne i64 %cv4957, 0
  br i1 %cond4958, label %bb_rcgdec1121, label %bb_rcgslow1121
bb_rcgslow1121:
  %v4959 = load i64, ptr %slot875, align 8
  %v4960 = load i64, ptr %slot872, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v4959, i64 %v4960) nomerge, !dbg !160
  br label %bb_rcgdone1121
bb_rcgdec1121:
  %v4961 = load i64, ptr %slot884, align 8
  %v4962 = load i64, ptr %slot876, align 8
  %p4963 = inttoptr i64 %v4962 to ptr
  %rgep4964 = getelementptr i8, ptr %p4963, i64 -24
  store i64 %v4961, ptr %rgep4964, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1121
bb_rcgclear1121:
  %v4965 = load i64, ptr %slot872, align 8
  %p4966 = inttoptr i64 %v4965 to ptr
  store i64 0, ptr %p4966, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1121
bb_rcgdone1121:
  br label %bb_rcslotdone1105
bb_rcslotowner1105:
  %v4967 = load i64, ptr %slot39, align 8
  store i64 %v4967, ptr %slot889, align 8
  %v4968 = load i64, ptr %slot872, align 8
  %p4969 = inttoptr i64 %v4968 to ptr
  %ld4970 = load i64, ptr %p4969, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4970, ptr %slot890, align 8
  %v4971 = load i64, ptr %slot890, align 8
  %cmp4972 = icmp ne i64 %v4971, 0
  %cv4973 = zext i1 %cmp4972 to i32
  store i32 %cv4973, ptr %slot891, align 8
  %v4974 = load i32, ptr %slot891, align 8
  %cv4975 = zext i32 %v4974 to i64
  %cond4976 = icmp ne i64 %cv4975, 0
  br i1 %cond4976, label %bb_rcgnn1136, label %bb_rcgdone1136
bb_rcgnn1136:
  %v4977 = load i64, ptr %slot890, align 8
  %op4978 = sub i64 %v4977, 16
  store i64 %op4978, ptr %slot892, align 8
  %v4979 = load i64, ptr %slot890, align 8
  %p4980 = inttoptr i64 %v4979 to ptr
  %rgep4981 = getelementptr i8, ptr %p4980, i64 -16
  %ld4982 = load i64, ptr %rgep4981, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4982, ptr %slot893, align 8
  %v4983 = load i64, ptr %slot893, align 8
  %op4984 = and i64 %v4983, 4611686018427387906
  store i64 %op4984, ptr %slot894, align 8
  %v4985 = load i64, ptr %slot894, align 8
  %cmp4986 = icmp ne i64 %v4985, 0
  %cv4987 = zext i1 %cmp4986 to i32
  store i32 %cv4987, ptr %slot895, align 8
  %v4988 = load i32, ptr %slot895, align 8
  %cv4989 = zext i32 %v4988 to i64
  %cond4990 = icmp ne i64 %cv4989, 0
  br i1 %cond4990, label %bb_rcgclear1136, label %bb_rcgcounted1136
bb_rcgcounted1136:
  %v4991 = load i64, ptr %slot890, align 8
  %op4992 = sub i64 %v4991, 32
  store i64 %op4992, ptr %slot896, align 8
  %v4993 = load i64, ptr %slot890, align 8
  %p4994 = inttoptr i64 %v4993 to ptr
  %rgep4995 = getelementptr i8, ptr %p4994, i64 -32
  %ld4996 = load i64, ptr %rgep4995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4996, ptr %slot897, align 8
  %v4997 = load i64, ptr %slot897, align 8
  %op4998 = sub i64 %v4997, 1
  store i64 %op4998, ptr %slot898, align 8
  %v4999 = load i64, ptr %slot898, align 8
  %cmp5000 = icmp eq i64 %v4999, 0
  %cv5001 = zext i1 %cmp5000 to i32
  store i32 %cv5001, ptr %slot899, align 8
  %v5002 = load i32, ptr %slot899, align 8
  %cv5003 = zext i32 %v5002 to i64
  %cond5004 = icmp ne i64 %cv5003, 0
  br i1 %cond5004, label %bb_rcglast1136, label %bb_rcgdec1136
bb_rcglast1136:
  %v5005 = load i64, ptr %slot890, align 8
  %op5006 = sub i64 %v5005, 24
  store i64 %op5006, ptr %slot900, align 8
  %v5007 = load i64, ptr %slot890, align 8
  %p5008 = inttoptr i64 %v5007 to ptr
  %rgep5009 = getelementptr i8, ptr %p5008, i64 -24
  %ld5010 = load i64, ptr %rgep5009, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5010, ptr %slot901, align 8
  %v5011 = load i64, ptr %slot901, align 8
  %cmp5012 = icmp ne i64 %v5011, 0
  %cv5013 = zext i1 %cmp5012 to i32
  store i32 %cv5013, ptr %slot902, align 8
  %v5014 = load i32, ptr %slot902, align 8
  %cv5015 = zext i32 %v5014 to i64
  %cond5016 = icmp ne i64 %cv5015, 0
  br i1 %cond5016, label %bb_rcgdec1136, label %bb_rcgslow1136
bb_rcgslow1136:
  %v5017 = load i64, ptr %slot889, align 8
  %v5018 = load i64, ptr %slot872, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5017, i64 %v5018) nomerge, !dbg !160
  br label %bb_rcgdone1136
bb_rcgdec1136:
  %v5019 = load i64, ptr %slot898, align 8
  %v5020 = load i64, ptr %slot890, align 8
  %p5021 = inttoptr i64 %v5020 to ptr
  %rgep5022 = getelementptr i8, ptr %p5021, i64 -32
  store i64 %v5019, ptr %rgep5022, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1136
bb_rcgclear1136:
  %v5023 = load i64, ptr %slot872, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  store i64 0, ptr %p5024, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1136
bb_rcgdone1136:
  br label %bb_rcslotdone1105
bb_rcslotdone1105:
  %v5025 = load i64, ptr %slot33, align 8
  %p5026 = inttoptr i64 %v5025 to ptr
  %ld5027 = load i64, ptr %p5026, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5027, ptr %slot903, align 8
  %v5028 = load i64, ptr %slot903, align 8
  %cond5029 = icmp ne i64 %v5028, 0
  br i1 %cond5029, label %bb_next1141, label %bb_i68
bb_next1141:
  %v5030 = load i64, ptr %slot25, align 8
  %p5031 = inttoptr i64 %v5030 to ptr
  %ld5032 = load i64, ptr %p5031, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5032, ptr %slot904, align 8
  %v5033 = load i64, ptr %slot904, align 8
  %v5034 = load i64, ptr %slot33, align 8
  %p5035 = inttoptr i64 %v5034 to ptr
  store i64 %v5033, ptr %p5035, align 8, !alias.scope !3, !noalias !4
  %p5036 = inttoptr i64 ptrtoint (ptr @myl_lit_2c737daca1a53c350fb3f42d323cb68d90e97fc7a14c713c8f977d6e08c6cf81 to i64) to ptr
  %ld5037 = load i64, ptr %p5036, align 8, !alias.scope !4, !noalias !3
  store i64 %ld5037, ptr %slot905, align 8
  %v5038 = load i64, ptr %slot905, align 8
  %v5039 = load i64, ptr %slot34, align 8
  %p5040 = inttoptr i64 %v5039 to ptr
  store i64 %v5038, ptr %p5040, align 8, !alias.scope !3, !noalias !4
  %v5041 = load i64, ptr %slot34, align 8
  %p5042 = inttoptr i64 %v5041 to ptr
  %ld5043 = load i64, ptr %p5042, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5043, ptr %slot906, align 8
  %v5044 = load i64, ptr %slot906, align 8
  %v5045 = load i64, ptr %slot23, align 8
  %p5046 = inttoptr i64 %v5045 to ptr
  store i64 %v5044, ptr %p5046, align 8, !alias.scope !3, !noalias !4
  %v5047 = load i64, ptr %slot23, align 8
  store i64 %v5047, ptr %slot907, align 8
  %v5048 = load i64, ptr %slot24, align 8
  store i64 %v5048, ptr %slot908, align 8
  %v5049 = load i64, ptr %slot907, align 8
  %v5050 = load i64, ptr %slot908, align 8
  %p5051 = inttoptr i64 %v5049 to ptr
  %p5052 = inttoptr i64 %v5050 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5052, ptr %p5051, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5053 = load i64, ptr %slot19, align 8
  %p5054 = inttoptr i64 %v5053 to ptr
  store i32 2, ptr %p5054, align 4, !alias.scope !3, !noalias !4
  %v5055 = load i64, ptr %slot18, align 8
  %p5056 = inttoptr i64 %v5055 to ptr
  store i32 1, ptr %p5056, align 4, !alias.scope !3, !noalias !4
  %v5057 = load i64, ptr %slot21, align 8
  store i64 %v5057, ptr %slot909, align 8
  %v5058 = load i64, ptr %slot24, align 8
  store i64 %v5058, ptr %slot910, align 8
  %v5059 = load i64, ptr %slot910, align 8
  %v5060 = load i64, ptr %slot909, align 8
  %p5061 = inttoptr i64 %v5059 to ptr
  %p5062 = inttoptr i64 %v5060 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5062, ptr %p5061, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v5063 = load i64, ptr %slot17, align 8
  %p5064 = inttoptr i64 %v5063 to ptr
  store i32 2, ptr %p5064, align 4, !alias.scope !3, !noalias !4
  %v5065 = load i64, ptr %slot19, align 8
  %p5066 = inttoptr i64 %v5065 to ptr
  %ld5067 = load i32, ptr %p5066, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5067, ptr %slot911, align 8
  %v5068 = load i32, ptr %slot911, align 8
  %v5069 = load i64, ptr %slot17, align 8
  %p5070 = inttoptr i64 %v5069 to ptr
  store i32 %v5068, ptr %p5070, align 4, !alias.scope !3, !noalias !4
  %v5071 = load i64, ptr %slot18, align 8
  %p5072 = inttoptr i64 %v5071 to ptr
  store i32 0, ptr %p5072, align 4, !alias.scope !3, !noalias !4
  %v5073 = load i64, ptr %slot16, align 8
  %p5074 = inttoptr i64 %v5073 to ptr
  store i32 1, ptr %p5074, align 4, !alias.scope !3, !noalias !4
  %v5075 = load i64, ptr %slot909, align 8
  %p5076 = inttoptr i64 %v5075 to ptr
  %ld5077 = load i64, ptr %p5076, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5077, ptr %slot912, align 8
  %v5078 = load i64, ptr %slot912, align 8
  %v5079 = load i64, ptr %slot34, align 8
  %p5080 = inttoptr i64 %v5079 to ptr
  store i64 %v5078, ptr %p5080, align 8, !alias.scope !3, !noalias !4
  %v5081 = load i64, ptr %slot33, align 8
  %p5082 = inttoptr i64 %v5081 to ptr
  %ld5083 = load i64, ptr %p5082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5083, ptr %slot913, align 8
  %v5084 = load i64, ptr %slot34, align 8
  %p5085 = inttoptr i64 %v5084 to ptr
  %ld5086 = load i64, ptr %p5085, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5086, ptr %slot914, align 8
  %v5087 = load i64, ptr %slot1, align 8
  %v5088 = load i64, ptr %slot913, align 8
  %v5089 = load i64, ptr %slot914, align 8
  %call5090 = call i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64 %v5087, i64 %v5088, i64 %v5089) nomerge, !dbg !162
  store i64 %call5090, ptr %slot915, align 8
  %v5091 = load i64, ptr %slot915, align 8
  %v5092 = load i64, ptr %slot33, align 8
  %p5093 = inttoptr i64 %v5092 to ptr
  store i64 %v5091, ptr %p5093, align 8, !alias.scope !3, !noalias !4
  %v5094 = load i64, ptr %slot14, align 8
  %p5095 = inttoptr i64 %v5094 to ptr
  %ld5096 = load i32, ptr %p5095, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5096, ptr %slot916, align 8
  %v5097 = load i32, ptr %slot916, align 8
  %cv5098 = zext i32 %v5097 to i64
  %cond5099 = icmp ne i64 %cv5098, 0
  br i1 %cond5099, label %bb_rcslotdrop1163, label %bb_rcslotdone1163
bb_rcslotdrop1163:
  %v5100 = load i64, ptr %slot14, align 8
  %p5101 = inttoptr i64 %v5100 to ptr
  store i32 0, ptr %p5101, align 4, !alias.scope !3, !noalias !4
  %v5102 = load i64, ptr %slot20, align 8
  store i64 %v5102, ptr %slot917, align 8
  %v5103 = load i64, ptr %slot15, align 8
  %p5104 = inttoptr i64 %v5103 to ptr
  %ld5105 = load i32, ptr %p5104, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5105, ptr %slot918, align 8
  %v5106 = load i32, ptr %slot918, align 8
  %op5107 = and i32 %v5106, 28
  store i32 %op5107, ptr %slot919, align 8
  %v5108 = load i32, ptr %slot919, align 8
  %cv5109 = zext i32 %v5108 to i64
  %cond5110 = icmp ne i64 %cv5109, 0
  br i1 %cond5110, label %bb_rcslotrole1163, label %bb_rcslotowner1163
bb_rcslotrole1163:
  %v5111 = load i64, ptr %slot39, align 8
  store i64 %v5111, ptr %slot920, align 8
  %v5112 = load i64, ptr %slot920, align 8
  %v5113 = load i64, ptr %slot917, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5112, i64 %v5113) nomerge, !dbg !162
  br label %bb_rcslotdone1163
bb_rcslotowner1163:
  %v5114 = load i64, ptr %slot39, align 8
  store i64 %v5114, ptr %slot921, align 8
  %v5115 = load i64, ptr %slot921, align 8
  %v5116 = load i64, ptr %slot917, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5115, i64 %v5116) nomerge, !dbg !162
  br label %bb_rcslotdone1163
bb_rcslotdone1163:
  %v5117 = load i64, ptr %slot16, align 8
  %p5118 = inttoptr i64 %v5117 to ptr
  %ld5119 = load i32, ptr %p5118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5119, ptr %slot922, align 8
  %v5120 = load i32, ptr %slot922, align 8
  %cv5121 = zext i32 %v5120 to i64
  %cond5122 = icmp ne i64 %cv5121, 0
  br i1 %cond5122, label %bb_rcslotdrop1172, label %bb_rcslotdone1172
bb_rcslotdrop1172:
  %v5123 = load i64, ptr %slot16, align 8
  %p5124 = inttoptr i64 %v5123 to ptr
  store i32 0, ptr %p5124, align 4, !alias.scope !3, !noalias !4
  %v5125 = load i64, ptr %slot21, align 8
  store i64 %v5125, ptr %slot923, align 8
  %v5126 = load i64, ptr %slot17, align 8
  %p5127 = inttoptr i64 %v5126 to ptr
  %ld5128 = load i32, ptr %p5127, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5128, ptr %slot924, align 8
  %v5129 = load i32, ptr %slot924, align 8
  %op5130 = and i32 %v5129, 28
  store i32 %op5130, ptr %slot925, align 8
  %v5131 = load i32, ptr %slot925, align 8
  %cv5132 = zext i32 %v5131 to i64
  %cond5133 = icmp ne i64 %cv5132, 0
  br i1 %cond5133, label %bb_rcslotrole1172, label %bb_rcslotowner1172
bb_rcslotrole1172:
  %v5134 = load i64, ptr %slot39, align 8
  store i64 %v5134, ptr %slot926, align 8
  %v5135 = load i64, ptr %slot923, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  %ld5137 = load i64, ptr %p5136, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5137, ptr %slot927, align 8
  %v5138 = load i64, ptr %slot927, align 8
  %cmp5139 = icmp ne i64 %v5138, 0
  %cv5140 = zext i1 %cmp5139 to i32
  store i32 %cv5140, ptr %slot928, align 8
  %v5141 = load i32, ptr %slot928, align 8
  %cv5142 = zext i32 %v5141 to i64
  %cond5143 = icmp ne i64 %cv5142, 0
  br i1 %cond5143, label %bb_rcgnn1188, label %bb_rcgdone1188
bb_rcgnn1188:
  %v5144 = load i64, ptr %slot927, align 8
  %op5145 = sub i64 %v5144, 16
  store i64 %op5145, ptr %slot929, align 8
  %v5146 = load i64, ptr %slot927, align 8
  %p5147 = inttoptr i64 %v5146 to ptr
  %rgep5148 = getelementptr i8, ptr %p5147, i64 -16
  %ld5149 = load i64, ptr %rgep5148, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5149, ptr %slot930, align 8
  %v5150 = load i64, ptr %slot930, align 8
  %op5151 = and i64 %v5150, 4611686018427387906
  store i64 %op5151, ptr %slot931, align 8
  %v5152 = load i64, ptr %slot931, align 8
  %cmp5153 = icmp ne i64 %v5152, 0
  %cv5154 = zext i1 %cmp5153 to i32
  store i32 %cv5154, ptr %slot932, align 8
  %v5155 = load i32, ptr %slot932, align 8
  %cv5156 = zext i32 %v5155 to i64
  %cond5157 = icmp ne i64 %cv5156, 0
  br i1 %cond5157, label %bb_rcgclear1188, label %bb_rcgcounted1188
bb_rcgcounted1188:
  %v5158 = load i64, ptr %slot927, align 8
  %op5159 = sub i64 %v5158, 24
  store i64 %op5159, ptr %slot933, align 8
  %v5160 = load i64, ptr %slot927, align 8
  %p5161 = inttoptr i64 %v5160 to ptr
  %rgep5162 = getelementptr i8, ptr %p5161, i64 -24
  %ld5163 = load i64, ptr %rgep5162, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5163, ptr %slot934, align 8
  %v5164 = load i64, ptr %slot934, align 8
  %op5165 = sub i64 %v5164, 1
  store i64 %op5165, ptr %slot935, align 8
  %v5166 = load i64, ptr %slot935, align 8
  %cmp5167 = icmp eq i64 %v5166, 0
  %cv5168 = zext i1 %cmp5167 to i32
  store i32 %cv5168, ptr %slot936, align 8
  %v5169 = load i32, ptr %slot936, align 8
  %cv5170 = zext i32 %v5169 to i64
  %cond5171 = icmp ne i64 %cv5170, 0
  br i1 %cond5171, label %bb_rcglast1188, label %bb_rcgdec1188
bb_rcglast1188:
  %v5172 = load i64, ptr %slot927, align 8
  %op5173 = sub i64 %v5172, 32
  store i64 %op5173, ptr %slot937, align 8
  %v5174 = load i64, ptr %slot927, align 8
  %p5175 = inttoptr i64 %v5174 to ptr
  %rgep5176 = getelementptr i8, ptr %p5175, i64 -32
  %ld5177 = load i64, ptr %rgep5176, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5177, ptr %slot938, align 8
  %v5178 = load i64, ptr %slot938, align 8
  %cmp5179 = icmp ne i64 %v5178, 0
  %cv5180 = zext i1 %cmp5179 to i32
  store i32 %cv5180, ptr %slot939, align 8
  %v5181 = load i32, ptr %slot939, align 8
  %cv5182 = zext i32 %v5181 to i64
  %cond5183 = icmp ne i64 %cv5182, 0
  br i1 %cond5183, label %bb_rcgdec1188, label %bb_rcgslow1188
bb_rcgslow1188:
  %v5184 = load i64, ptr %slot926, align 8
  %v5185 = load i64, ptr %slot923, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5184, i64 %v5185) nomerge, !dbg !162
  br label %bb_rcgdone1188
bb_rcgdec1188:
  %v5186 = load i64, ptr %slot935, align 8
  %v5187 = load i64, ptr %slot927, align 8
  %p5188 = inttoptr i64 %v5187 to ptr
  %rgep5189 = getelementptr i8, ptr %p5188, i64 -24
  store i64 %v5186, ptr %rgep5189, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1188
bb_rcgclear1188:
  %v5190 = load i64, ptr %slot923, align 8
  %p5191 = inttoptr i64 %v5190 to ptr
  store i64 0, ptr %p5191, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1188
bb_rcgdone1188:
  br label %bb_rcslotdone1172
bb_rcslotowner1172:
  %v5192 = load i64, ptr %slot39, align 8
  store i64 %v5192, ptr %slot940, align 8
  %v5193 = load i64, ptr %slot923, align 8
  %p5194 = inttoptr i64 %v5193 to ptr
  %ld5195 = load i64, ptr %p5194, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5195, ptr %slot941, align 8
  %v5196 = load i64, ptr %slot941, align 8
  %cmp5197 = icmp ne i64 %v5196, 0
  %cv5198 = zext i1 %cmp5197 to i32
  store i32 %cv5198, ptr %slot942, align 8
  %v5199 = load i32, ptr %slot942, align 8
  %cv5200 = zext i32 %v5199 to i64
  %cond5201 = icmp ne i64 %cv5200, 0
  br i1 %cond5201, label %bb_rcgnn1203, label %bb_rcgdone1203
bb_rcgnn1203:
  %v5202 = load i64, ptr %slot941, align 8
  %op5203 = sub i64 %v5202, 16
  store i64 %op5203, ptr %slot943, align 8
  %v5204 = load i64, ptr %slot941, align 8
  %p5205 = inttoptr i64 %v5204 to ptr
  %rgep5206 = getelementptr i8, ptr %p5205, i64 -16
  %ld5207 = load i64, ptr %rgep5206, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5207, ptr %slot944, align 8
  %v5208 = load i64, ptr %slot944, align 8
  %op5209 = and i64 %v5208, 4611686018427387906
  store i64 %op5209, ptr %slot945, align 8
  %v5210 = load i64, ptr %slot945, align 8
  %cmp5211 = icmp ne i64 %v5210, 0
  %cv5212 = zext i1 %cmp5211 to i32
  store i32 %cv5212, ptr %slot946, align 8
  %v5213 = load i32, ptr %slot946, align 8
  %cv5214 = zext i32 %v5213 to i64
  %cond5215 = icmp ne i64 %cv5214, 0
  br i1 %cond5215, label %bb_rcgclear1203, label %bb_rcgcounted1203
bb_rcgcounted1203:
  %v5216 = load i64, ptr %slot941, align 8
  %op5217 = sub i64 %v5216, 32
  store i64 %op5217, ptr %slot947, align 8
  %v5218 = load i64, ptr %slot941, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  %rgep5220 = getelementptr i8, ptr %p5219, i64 -32
  %ld5221 = load i64, ptr %rgep5220, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5221, ptr %slot948, align 8
  %v5222 = load i64, ptr %slot948, align 8
  %op5223 = sub i64 %v5222, 1
  store i64 %op5223, ptr %slot949, align 8
  %v5224 = load i64, ptr %slot949, align 8
  %cmp5225 = icmp eq i64 %v5224, 0
  %cv5226 = zext i1 %cmp5225 to i32
  store i32 %cv5226, ptr %slot950, align 8
  %v5227 = load i32, ptr %slot950, align 8
  %cv5228 = zext i32 %v5227 to i64
  %cond5229 = icmp ne i64 %cv5228, 0
  br i1 %cond5229, label %bb_rcglast1203, label %bb_rcgdec1203
bb_rcglast1203:
  %v5230 = load i64, ptr %slot941, align 8
  %op5231 = sub i64 %v5230, 24
  store i64 %op5231, ptr %slot951, align 8
  %v5232 = load i64, ptr %slot941, align 8
  %p5233 = inttoptr i64 %v5232 to ptr
  %rgep5234 = getelementptr i8, ptr %p5233, i64 -24
  %ld5235 = load i64, ptr %rgep5234, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5235, ptr %slot952, align 8
  %v5236 = load i64, ptr %slot952, align 8
  %cmp5237 = icmp ne i64 %v5236, 0
  %cv5238 = zext i1 %cmp5237 to i32
  store i32 %cv5238, ptr %slot953, align 8
  %v5239 = load i32, ptr %slot953, align 8
  %cv5240 = zext i32 %v5239 to i64
  %cond5241 = icmp ne i64 %cv5240, 0
  br i1 %cond5241, label %bb_rcgdec1203, label %bb_rcgslow1203
bb_rcgslow1203:
  %v5242 = load i64, ptr %slot940, align 8
  %v5243 = load i64, ptr %slot923, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5242, i64 %v5243) nomerge, !dbg !162
  br label %bb_rcgdone1203
bb_rcgdec1203:
  %v5244 = load i64, ptr %slot949, align 8
  %v5245 = load i64, ptr %slot941, align 8
  %p5246 = inttoptr i64 %v5245 to ptr
  %rgep5247 = getelementptr i8, ptr %p5246, i64 -32
  store i64 %v5244, ptr %rgep5247, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1203
bb_rcgclear1203:
  %v5248 = load i64, ptr %slot923, align 8
  %p5249 = inttoptr i64 %v5248 to ptr
  store i64 0, ptr %p5249, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1203
bb_rcgdone1203:
  br label %bb_rcslotdone1172
bb_rcslotdone1172:
  br label %bb_i68
bb_i68:
  %v5250 = load i64, ptr %slot29, align 8
  %p5251 = inttoptr i64 %v5250 to ptr
  %ld5252 = load i64, ptr %p5251, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5252, ptr %slot954, align 8
  %v5253 = load i64, ptr %slot954, align 8
  %v5254 = load i64, ptr %slot33, align 8
  %p5255 = inttoptr i64 %v5254 to ptr
  store i64 %v5253, ptr %p5255, align 8, !alias.scope !3, !noalias !4
  %v5256 = load i64, ptr %slot34, align 8
  %p5257 = inttoptr i64 %v5256 to ptr
  store i64 1, ptr %p5257, align 8, !alias.scope !3, !noalias !4
  %v5258 = load i64, ptr %slot34, align 8
  %p5259 = inttoptr i64 %v5258 to ptr
  %ld5260 = load i64, ptr %p5259, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5260, ptr %slot955, align 8
  %v5261 = load i64, ptr %slot33, align 8
  %p5262 = inttoptr i64 %v5261 to ptr
  %ld5263 = load i64, ptr %p5262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5263, ptr %slot956, align 8
  %v5264 = load i64, ptr %slot956, align 8
  %v5265 = load i64, ptr %slot955, align 8
  %ovpair5267 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v5264, i64 %v5265)
  %op5266 = extractvalue { i64, i1 } %ovpair5267, 0
  %ov5268 = extractvalue { i64, i1 } %ovpair5267, 1
  store i64 %op5266, ptr %slot957, align 8
  %cv5269 = zext i1 %ov5268 to i64
  store i64 %cv5269, ptr %slot958, align 8
  %v5270 = load i64, ptr %slot958, align 8
  %cond5271 = icmp ne i64 %v5270, 0
  br i1 %cond5271, label %bb_overflow1210, label %bb_checked1210
bb_overflow1210:
  %v5272 = load i64, ptr %slot1, align 8
  %p5273 = inttoptr i64 %v5272 to ptr
  %v5274 = load i64, ptr %slot956, align 8
  %v5275 = load i64, ptr %slot955, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p5273, i64 1, i64 %v5274, i64 %v5275, i64 64) nomerge, !dbg !164
  unreachable
bb_checked1210:
  %v5276 = load i64, ptr %slot957, align 8
  %v5277 = load i64, ptr %slot33, align 8
  %p5278 = inttoptr i64 %v5277 to ptr
  store i64 %v5276, ptr %p5278, align 8, !alias.scope !3, !noalias !4
  %v5279 = load i64, ptr %slot33, align 8
  %p5280 = inttoptr i64 %v5279 to ptr
  %ld5281 = load i64, ptr %p5280, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5281, ptr %slot959, align 8
  %v5282 = load i64, ptr %slot959, align 8
  %v5283 = load i64, ptr %slot29, align 8
  %p5284 = inttoptr i64 %v5283 to ptr
  store i64 %v5282, ptr %p5284, align 8, !alias.scope !3, !noalias !4
  br label %bb_i24
bb_i73:
  %v5285 = load i64, ptr %slot25, align 8
  %p5286 = inttoptr i64 %v5285 to ptr
  %ld5287 = load i64, ptr %p5286, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5287, ptr %slot960, align 8
  %v5288 = load i64, ptr %slot960, align 8
  %v5289 = load i64, ptr %slot33, align 8
  %p5290 = inttoptr i64 %v5289 to ptr
  store i64 %v5288, ptr %p5290, align 8, !alias.scope !3, !noalias !4
  %v5291 = load i64, ptr %slot27, align 8
  %p5292 = inttoptr i64 %v5291 to ptr
  %ld5293 = load i64, ptr %p5292, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5293, ptr %slot961, align 8
  %v5294 = load i64, ptr %slot961, align 8
  %v5295 = load i64, ptr %slot34, align 8
  %p5296 = inttoptr i64 %v5295 to ptr
  store i64 %v5294, ptr %p5296, align 8, !alias.scope !3, !noalias !4
  %v5297 = load i64, ptr %slot33, align 8
  %p5298 = inttoptr i64 %v5297 to ptr
  %ld5299 = load i64, ptr %p5298, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5299, ptr %slot962, align 8
  %v5300 = load i64, ptr %slot34, align 8
  %p5301 = inttoptr i64 %v5300 to ptr
  %ld5302 = load i64, ptr %p5301, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5302, ptr %slot963, align 8
  %v5303 = load i64, ptr %slot1, align 8
  %v5304 = load i64, ptr %slot962, align 8
  %v5305 = load i64, ptr %slot963, align 8
  %call5306 = call i64 @myl_f_66c26d82de4091c4939a671e1a95e79206b4c146c1351bf41eb605cd8e32e742(i64 %v5303, i64 %v5304, i64 %v5305) nomerge, !dbg !166
  store i64 %call5306, ptr %slot964, align 8
  %v5307 = load i64, ptr %slot964, align 8
  %v5308 = load i64, ptr %slot33, align 8
  %p5309 = inttoptr i64 %v5308 to ptr
  store i64 %v5307, ptr %p5309, align 8, !alias.scope !3, !noalias !4
  %v5310 = load i64, ptr %slot14, align 8
  %p5311 = inttoptr i64 %v5310 to ptr
  %ld5312 = load i32, ptr %p5311, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5312, ptr %slot965, align 8
  %v5313 = load i32, ptr %slot965, align 8
  %cv5314 = zext i32 %v5313 to i64
  %cond5315 = icmp ne i64 %cv5314, 0
  br i1 %cond5315, label %bb_rcslotdrop1220, label %bb_rcslotdone1220
bb_rcslotdrop1220:
  %v5316 = load i64, ptr %slot14, align 8
  %p5317 = inttoptr i64 %v5316 to ptr
  store i32 0, ptr %p5317, align 4, !alias.scope !3, !noalias !4
  %v5318 = load i64, ptr %slot20, align 8
  store i64 %v5318, ptr %slot966, align 8
  %v5319 = load i64, ptr %slot15, align 8
  %p5320 = inttoptr i64 %v5319 to ptr
  %ld5321 = load i32, ptr %p5320, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5321, ptr %slot967, align 8
  %v5322 = load i32, ptr %slot967, align 8
  %op5323 = and i32 %v5322, 28
  store i32 %op5323, ptr %slot968, align 8
  %v5324 = load i32, ptr %slot968, align 8
  %cv5325 = zext i32 %v5324 to i64
  %cond5326 = icmp ne i64 %cv5325, 0
  br i1 %cond5326, label %bb_rcslotrole1220, label %bb_rcslotowner1220
bb_rcslotrole1220:
  %v5327 = load i64, ptr %slot39, align 8
  store i64 %v5327, ptr %slot969, align 8
  %v5328 = load i64, ptr %slot969, align 8
  %v5329 = load i64, ptr %slot966, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64 %v5328, i64 %v5329) nomerge, !dbg !166
  br label %bb_rcslotdone1220
bb_rcslotowner1220:
  %v5330 = load i64, ptr %slot39, align 8
  store i64 %v5330, ptr %slot970, align 8
  %v5331 = load i64, ptr %slot970, align 8
  %v5332 = load i64, ptr %slot966, align 8
  call void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64 %v5331, i64 %v5332) nomerge, !dbg !166
  br label %bb_rcslotdone1220
bb_rcslotdone1220:
  %v5333 = load i64, ptr %slot16, align 8
  %p5334 = inttoptr i64 %v5333 to ptr
  %ld5335 = load i32, ptr %p5334, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5335, ptr %slot971, align 8
  %v5336 = load i32, ptr %slot971, align 8
  %cv5337 = zext i32 %v5336 to i64
  %cond5338 = icmp ne i64 %cv5337, 0
  br i1 %cond5338, label %bb_rcslotdrop1229, label %bb_rcslotdone1229
bb_rcslotdrop1229:
  %v5339 = load i64, ptr %slot16, align 8
  %p5340 = inttoptr i64 %v5339 to ptr
  store i32 0, ptr %p5340, align 4, !alias.scope !3, !noalias !4
  %v5341 = load i64, ptr %slot21, align 8
  store i64 %v5341, ptr %slot972, align 8
  %v5342 = load i64, ptr %slot17, align 8
  %p5343 = inttoptr i64 %v5342 to ptr
  %ld5344 = load i32, ptr %p5343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5344, ptr %slot973, align 8
  %v5345 = load i32, ptr %slot973, align 8
  %op5346 = and i32 %v5345, 28
  store i32 %op5346, ptr %slot974, align 8
  %v5347 = load i32, ptr %slot974, align 8
  %cv5348 = zext i32 %v5347 to i64
  %cond5349 = icmp ne i64 %cv5348, 0
  br i1 %cond5349, label %bb_rcslotrole1229, label %bb_rcslotowner1229
bb_rcslotrole1229:
  %v5350 = load i64, ptr %slot39, align 8
  store i64 %v5350, ptr %slot975, align 8
  %v5351 = load i64, ptr %slot972, align 8
  %p5352 = inttoptr i64 %v5351 to ptr
  %ld5353 = load i64, ptr %p5352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5353, ptr %slot976, align 8
  %v5354 = load i64, ptr %slot976, align 8
  %cmp5355 = icmp ne i64 %v5354, 0
  %cv5356 = zext i1 %cmp5355 to i32
  store i32 %cv5356, ptr %slot977, align 8
  %v5357 = load i32, ptr %slot977, align 8
  %cv5358 = zext i32 %v5357 to i64
  %cond5359 = icmp ne i64 %cv5358, 0
  br i1 %cond5359, label %bb_rcgnn1245, label %bb_rcgdone1245
bb_rcgnn1245:
  %v5360 = load i64, ptr %slot976, align 8
  %op5361 = sub i64 %v5360, 16
  store i64 %op5361, ptr %slot978, align 8
  %v5362 = load i64, ptr %slot976, align 8
  %p5363 = inttoptr i64 %v5362 to ptr
  %rgep5364 = getelementptr i8, ptr %p5363, i64 -16
  %ld5365 = load i64, ptr %rgep5364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5365, ptr %slot979, align 8
  %v5366 = load i64, ptr %slot979, align 8
  %op5367 = and i64 %v5366, 4611686018427387906
  store i64 %op5367, ptr %slot980, align 8
  %v5368 = load i64, ptr %slot980, align 8
  %cmp5369 = icmp ne i64 %v5368, 0
  %cv5370 = zext i1 %cmp5369 to i32
  store i32 %cv5370, ptr %slot981, align 8
  %v5371 = load i32, ptr %slot981, align 8
  %cv5372 = zext i32 %v5371 to i64
  %cond5373 = icmp ne i64 %cv5372, 0
  br i1 %cond5373, label %bb_rcgclear1245, label %bb_rcgcounted1245
bb_rcgcounted1245:
  %v5374 = load i64, ptr %slot976, align 8
  %op5375 = sub i64 %v5374, 24
  store i64 %op5375, ptr %slot982, align 8
  %v5376 = load i64, ptr %slot976, align 8
  %p5377 = inttoptr i64 %v5376 to ptr
  %rgep5378 = getelementptr i8, ptr %p5377, i64 -24
  %ld5379 = load i64, ptr %rgep5378, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5379, ptr %slot983, align 8
  %v5380 = load i64, ptr %slot983, align 8
  %op5381 = sub i64 %v5380, 1
  store i64 %op5381, ptr %slot984, align 8
  %v5382 = load i64, ptr %slot984, align 8
  %cmp5383 = icmp eq i64 %v5382, 0
  %cv5384 = zext i1 %cmp5383 to i32
  store i32 %cv5384, ptr %slot985, align 8
  %v5385 = load i32, ptr %slot985, align 8
  %cv5386 = zext i32 %v5385 to i64
  %cond5387 = icmp ne i64 %cv5386, 0
  br i1 %cond5387, label %bb_rcglast1245, label %bb_rcgdec1245
bb_rcglast1245:
  %v5388 = load i64, ptr %slot976, align 8
  %op5389 = sub i64 %v5388, 32
  store i64 %op5389, ptr %slot986, align 8
  %v5390 = load i64, ptr %slot976, align 8
  %p5391 = inttoptr i64 %v5390 to ptr
  %rgep5392 = getelementptr i8, ptr %p5391, i64 -32
  %ld5393 = load i64, ptr %rgep5392, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5393, ptr %slot987, align 8
  %v5394 = load i64, ptr %slot987, align 8
  %cmp5395 = icmp ne i64 %v5394, 0
  %cv5396 = zext i1 %cmp5395 to i32
  store i32 %cv5396, ptr %slot988, align 8
  %v5397 = load i32, ptr %slot988, align 8
  %cv5398 = zext i32 %v5397 to i64
  %cond5399 = icmp ne i64 %cv5398, 0
  br i1 %cond5399, label %bb_rcgdec1245, label %bb_rcgslow1245
bb_rcgslow1245:
  %v5400 = load i64, ptr %slot975, align 8
  %v5401 = load i64, ptr %slot972, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5400, i64 %v5401) nomerge, !dbg !166
  br label %bb_rcgdone1245
bb_rcgdec1245:
  %v5402 = load i64, ptr %slot984, align 8
  %v5403 = load i64, ptr %slot976, align 8
  %p5404 = inttoptr i64 %v5403 to ptr
  %rgep5405 = getelementptr i8, ptr %p5404, i64 -24
  store i64 %v5402, ptr %rgep5405, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1245
bb_rcgclear1245:
  %v5406 = load i64, ptr %slot972, align 8
  %p5407 = inttoptr i64 %v5406 to ptr
  store i64 0, ptr %p5407, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1245
bb_rcgdone1245:
  br label %bb_rcslotdone1229
bb_rcslotowner1229:
  %v5408 = load i64, ptr %slot39, align 8
  store i64 %v5408, ptr %slot989, align 8
  %v5409 = load i64, ptr %slot972, align 8
  %p5410 = inttoptr i64 %v5409 to ptr
  %ld5411 = load i64, ptr %p5410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5411, ptr %slot990, align 8
  %v5412 = load i64, ptr %slot990, align 8
  %cmp5413 = icmp ne i64 %v5412, 0
  %cv5414 = zext i1 %cmp5413 to i32
  store i32 %cv5414, ptr %slot991, align 8
  %v5415 = load i32, ptr %slot991, align 8
  %cv5416 = zext i32 %v5415 to i64
  %cond5417 = icmp ne i64 %cv5416, 0
  br i1 %cond5417, label %bb_rcgnn1260, label %bb_rcgdone1260
bb_rcgnn1260:
  %v5418 = load i64, ptr %slot990, align 8
  %op5419 = sub i64 %v5418, 16
  store i64 %op5419, ptr %slot992, align 8
  %v5420 = load i64, ptr %slot990, align 8
  %p5421 = inttoptr i64 %v5420 to ptr
  %rgep5422 = getelementptr i8, ptr %p5421, i64 -16
  %ld5423 = load i64, ptr %rgep5422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5423, ptr %slot993, align 8
  %v5424 = load i64, ptr %slot993, align 8
  %op5425 = and i64 %v5424, 4611686018427387906
  store i64 %op5425, ptr %slot994, align 8
  %v5426 = load i64, ptr %slot994, align 8
  %cmp5427 = icmp ne i64 %v5426, 0
  %cv5428 = zext i1 %cmp5427 to i32
  store i32 %cv5428, ptr %slot995, align 8
  %v5429 = load i32, ptr %slot995, align 8
  %cv5430 = zext i32 %v5429 to i64
  %cond5431 = icmp ne i64 %cv5430, 0
  br i1 %cond5431, label %bb_rcgclear1260, label %bb_rcgcounted1260
bb_rcgcounted1260:
  %v5432 = load i64, ptr %slot990, align 8
  %op5433 = sub i64 %v5432, 32
  store i64 %op5433, ptr %slot996, align 8
  %v5434 = load i64, ptr %slot990, align 8
  %p5435 = inttoptr i64 %v5434 to ptr
  %rgep5436 = getelementptr i8, ptr %p5435, i64 -32
  %ld5437 = load i64, ptr %rgep5436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5437, ptr %slot997, align 8
  %v5438 = load i64, ptr %slot997, align 8
  %op5439 = sub i64 %v5438, 1
  store i64 %op5439, ptr %slot998, align 8
  %v5440 = load i64, ptr %slot998, align 8
  %cmp5441 = icmp eq i64 %v5440, 0
  %cv5442 = zext i1 %cmp5441 to i32
  store i32 %cv5442, ptr %slot999, align 8
  %v5443 = load i32, ptr %slot999, align 8
  %cv5444 = zext i32 %v5443 to i64
  %cond5445 = icmp ne i64 %cv5444, 0
  br i1 %cond5445, label %bb_rcglast1260, label %bb_rcgdec1260
bb_rcglast1260:
  %v5446 = load i64, ptr %slot990, align 8
  %op5447 = sub i64 %v5446, 24
  store i64 %op5447, ptr %slot1000, align 8
  %v5448 = load i64, ptr %slot990, align 8
  %p5449 = inttoptr i64 %v5448 to ptr
  %rgep5450 = getelementptr i8, ptr %p5449, i64 -24
  %ld5451 = load i64, ptr %rgep5450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5451, ptr %slot1001, align 8
  %v5452 = load i64, ptr %slot1001, align 8
  %cmp5453 = icmp ne i64 %v5452, 0
  %cv5454 = zext i1 %cmp5453 to i32
  store i32 %cv5454, ptr %slot1002, align 8
  %v5455 = load i32, ptr %slot1002, align 8
  %cv5456 = zext i32 %v5455 to i64
  %cond5457 = icmp ne i64 %cv5456, 0
  br i1 %cond5457, label %bb_rcgdec1260, label %bb_rcgslow1260
bb_rcgslow1260:
  %v5458 = load i64, ptr %slot989, align 8
  %v5459 = load i64, ptr %slot972, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5458, i64 %v5459) nomerge, !dbg !166
  br label %bb_rcgdone1260
bb_rcgdec1260:
  %v5460 = load i64, ptr %slot998, align 8
  %v5461 = load i64, ptr %slot990, align 8
  %p5462 = inttoptr i64 %v5461 to ptr
  %rgep5463 = getelementptr i8, ptr %p5462, i64 -32
  store i64 %v5460, ptr %rgep5463, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1260
bb_rcgclear1260:
  %v5464 = load i64, ptr %slot972, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i64 0, ptr %p5465, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1260
bb_rcgdone1260:
  br label %bb_rcslotdone1229
bb_rcslotdone1229:
  %v5466 = load i64, ptr %slot33, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  store i64 0, ptr %p5467, align 8, !alias.scope !3, !noalias !4
  %v5468 = load i64, ptr %slot33, align 8
  %p5469 = inttoptr i64 %v5468 to ptr
  %ld5470 = load i64, ptr %p5469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5470, ptr %slot1003, align 8
  %v5471 = load i64, ptr %slot14, align 8
  %p5472 = inttoptr i64 %v5471 to ptr
  %ld5473 = load i32, ptr %p5472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5473, ptr %slot1004, align 8
  %v5474 = load i32, ptr %slot1004, align 8
  %cv5475 = zext i32 %v5474 to i64
  %cond5476 = icmp ne i64 %cv5475, 0
  br i1 %cond5476, label %bb_rcslotdrop1267, label %bb_rcslotdone1267
bb_rcslotdrop1267:
  %v5477 = load i64, ptr %slot14, align 8
  %p5478 = inttoptr i64 %v5477 to ptr
  store i32 0, ptr %p5478, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone1267
bb_rcslotdone1267:
  %v5479 = load i64, ptr %slot12, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  %ld5481 = load i32, ptr %p5480, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5481, ptr %slot1005, align 8
  %v5482 = load i32, ptr %slot1005, align 8
  %cv5483 = zext i32 %v5482 to i64
  %cond5484 = icmp ne i64 %cv5483, 0
  br i1 %cond5484, label %bb_rcslotdrop1270, label %bb_rcslotdone1270
bb_rcslotdrop1270:
  %v5485 = load i64, ptr %slot12, align 8
  %p5486 = inttoptr i64 %v5485 to ptr
  store i32 0, ptr %p5486, align 4, !alias.scope !3, !noalias !4
  %v5487 = load i64, ptr %slot32, align 8
  store i64 %v5487, ptr %slot1006, align 8
  %v5488 = load i64, ptr %slot13, align 8
  %p5489 = inttoptr i64 %v5488 to ptr
  %ld5490 = load i32, ptr %p5489, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5490, ptr %slot1007, align 8
  %v5491 = load i32, ptr %slot1007, align 8
  %op5492 = and i32 %v5491, 28
  store i32 %op5492, ptr %slot1008, align 8
  %v5493 = load i32, ptr %slot1008, align 8
  %cv5494 = zext i32 %v5493 to i64
  %cond5495 = icmp ne i64 %cv5494, 0
  br i1 %cond5495, label %bb_rcslotrole1270, label %bb_rcslotowner1270
bb_rcslotrole1270:
  %v5496 = load i64, ptr %slot39, align 8
  store i64 %v5496, ptr %slot1009, align 8
  %v5497 = load i64, ptr %slot1009, align 8
  %v5498 = load i64, ptr %slot1006, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64 %v5497, i64 %v5498) nomerge, !dbg !168
  br label %bb_rcslotdone1270
bb_rcslotowner1270:
  %v5499 = load i64, ptr %slot39, align 8
  store i64 %v5499, ptr %slot1010, align 8
  %v5500 = load i64, ptr %slot1010, align 8
  %v5501 = load i64, ptr %slot1006, align 8
  call void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64 %v5500, i64 %v5501) nomerge, !dbg !168
  br label %bb_rcslotdone1270
bb_rcslotdone1270:
  %v5502 = load i64, ptr %slot10, align 8
  %p5503 = inttoptr i64 %v5502 to ptr
  %ld5504 = load i32, ptr %p5503, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5504, ptr %slot1011, align 8
  %v5505 = load i32, ptr %slot1011, align 8
  %cv5506 = zext i32 %v5505 to i64
  %cond5507 = icmp ne i64 %cv5506, 0
  br i1 %cond5507, label %bb_rcslotdrop1279, label %bb_rcslotdone1279
bb_rcslotdrop1279:
  %v5508 = load i64, ptr %slot10, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  store i32 0, ptr %p5509, align 4, !alias.scope !3, !noalias !4
  %v5510 = load i64, ptr %slot30, align 8
  store i64 %v5510, ptr %slot1012, align 8
  %v5511 = load i64, ptr %slot11, align 8
  %p5512 = inttoptr i64 %v5511 to ptr
  %ld5513 = load i32, ptr %p5512, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5513, ptr %slot1013, align 8
  %v5514 = load i32, ptr %slot1013, align 8
  %op5515 = and i32 %v5514, 28
  store i32 %op5515, ptr %slot1014, align 8
  %v5516 = load i32, ptr %slot1014, align 8
  %cv5517 = zext i32 %v5516 to i64
  %cond5518 = icmp ne i64 %cv5517, 0
  br i1 %cond5518, label %bb_rcslotrole1279, label %bb_rcslotowner1279
bb_rcslotrole1279:
  %v5519 = load i64, ptr %slot39, align 8
  store i64 %v5519, ptr %slot1015, align 8
  %v5520 = load i64, ptr %slot1012, align 8
  %p5521 = inttoptr i64 %v5520 to ptr
  %ld5522 = load i64, ptr %p5521, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5522, ptr %slot1016, align 8
  %v5523 = load i64, ptr %slot1016, align 8
  %cmp5524 = icmp ne i64 %v5523, 0
  %cv5525 = zext i1 %cmp5524 to i32
  store i32 %cv5525, ptr %slot1017, align 8
  %v5526 = load i32, ptr %slot1017, align 8
  %cv5527 = zext i32 %v5526 to i64
  %cond5528 = icmp ne i64 %cv5527, 0
  br i1 %cond5528, label %bb_rcgnn1295, label %bb_rcgdone1295
bb_rcgnn1295:
  %v5529 = load i64, ptr %slot1016, align 8
  %op5530 = sub i64 %v5529, 16
  store i64 %op5530, ptr %slot1018, align 8
  %v5531 = load i64, ptr %slot1016, align 8
  %p5532 = inttoptr i64 %v5531 to ptr
  %rgep5533 = getelementptr i8, ptr %p5532, i64 -16
  %ld5534 = load i64, ptr %rgep5533, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5534, ptr %slot1019, align 8
  %v5535 = load i64, ptr %slot1019, align 8
  %op5536 = and i64 %v5535, 4611686018427387906
  store i64 %op5536, ptr %slot1020, align 8
  %v5537 = load i64, ptr %slot1020, align 8
  %cmp5538 = icmp ne i64 %v5537, 0
  %cv5539 = zext i1 %cmp5538 to i32
  store i32 %cv5539, ptr %slot1021, align 8
  %v5540 = load i32, ptr %slot1021, align 8
  %cv5541 = zext i32 %v5540 to i64
  %cond5542 = icmp ne i64 %cv5541, 0
  br i1 %cond5542, label %bb_rcgclear1295, label %bb_rcgcounted1295
bb_rcgcounted1295:
  %v5543 = load i64, ptr %slot1016, align 8
  %op5544 = sub i64 %v5543, 24
  store i64 %op5544, ptr %slot1022, align 8
  %v5545 = load i64, ptr %slot1016, align 8
  %p5546 = inttoptr i64 %v5545 to ptr
  %rgep5547 = getelementptr i8, ptr %p5546, i64 -24
  %ld5548 = load i64, ptr %rgep5547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5548, ptr %slot1023, align 8
  %v5549 = load i64, ptr %slot1023, align 8
  %op5550 = sub i64 %v5549, 1
  store i64 %op5550, ptr %slot1024, align 8
  %v5551 = load i64, ptr %slot1024, align 8
  %cmp5552 = icmp eq i64 %v5551, 0
  %cv5553 = zext i1 %cmp5552 to i32
  store i32 %cv5553, ptr %slot1025, align 8
  %v5554 = load i32, ptr %slot1025, align 8
  %cv5555 = zext i32 %v5554 to i64
  %cond5556 = icmp ne i64 %cv5555, 0
  br i1 %cond5556, label %bb_rcglast1295, label %bb_rcgdec1295
bb_rcglast1295:
  %v5557 = load i64, ptr %slot1016, align 8
  %op5558 = sub i64 %v5557, 32
  store i64 %op5558, ptr %slot1026, align 8
  %v5559 = load i64, ptr %slot1016, align 8
  %p5560 = inttoptr i64 %v5559 to ptr
  %rgep5561 = getelementptr i8, ptr %p5560, i64 -32
  %ld5562 = load i64, ptr %rgep5561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5562, ptr %slot1027, align 8
  %v5563 = load i64, ptr %slot1027, align 8
  %cmp5564 = icmp ne i64 %v5563, 0
  %cv5565 = zext i1 %cmp5564 to i32
  store i32 %cv5565, ptr %slot1028, align 8
  %v5566 = load i32, ptr %slot1028, align 8
  %cv5567 = zext i32 %v5566 to i64
  %cond5568 = icmp ne i64 %cv5567, 0
  br i1 %cond5568, label %bb_rcgdec1295, label %bb_rcgslow1295
bb_rcgslow1295:
  %v5569 = load i64, ptr %slot1015, align 8
  %v5570 = load i64, ptr %slot1012, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v5569, i64 %v5570) nomerge, !dbg !168
  br label %bb_rcgdone1295
bb_rcgdec1295:
  %v5571 = load i64, ptr %slot1024, align 8
  %v5572 = load i64, ptr %slot1016, align 8
  %p5573 = inttoptr i64 %v5572 to ptr
  %rgep5574 = getelementptr i8, ptr %p5573, i64 -24
  store i64 %v5571, ptr %rgep5574, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1295
bb_rcgclear1295:
  %v5575 = load i64, ptr %slot1012, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  store i64 0, ptr %p5576, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1295
bb_rcgdone1295:
  br label %bb_rcslotdone1279
bb_rcslotowner1279:
  %v5577 = load i64, ptr %slot39, align 8
  store i64 %v5577, ptr %slot1029, align 8
  %v5578 = load i64, ptr %slot1012, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  %ld5580 = load i64, ptr %p5579, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5580, ptr %slot1030, align 8
  %v5581 = load i64, ptr %slot1030, align 8
  %cmp5582 = icmp ne i64 %v5581, 0
  %cv5583 = zext i1 %cmp5582 to i32
  store i32 %cv5583, ptr %slot1031, align 8
  %v5584 = load i32, ptr %slot1031, align 8
  %cv5585 = zext i32 %v5584 to i64
  %cond5586 = icmp ne i64 %cv5585, 0
  br i1 %cond5586, label %bb_rcgnn1310, label %bb_rcgdone1310
bb_rcgnn1310:
  %v5587 = load i64, ptr %slot1030, align 8
  %op5588 = sub i64 %v5587, 16
  store i64 %op5588, ptr %slot1032, align 8
  %v5589 = load i64, ptr %slot1030, align 8
  %p5590 = inttoptr i64 %v5589 to ptr
  %rgep5591 = getelementptr i8, ptr %p5590, i64 -16
  %ld5592 = load i64, ptr %rgep5591, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5592, ptr %slot1033, align 8
  %v5593 = load i64, ptr %slot1033, align 8
  %op5594 = and i64 %v5593, 4611686018427387906
  store i64 %op5594, ptr %slot1034, align 8
  %v5595 = load i64, ptr %slot1034, align 8
  %cmp5596 = icmp ne i64 %v5595, 0
  %cv5597 = zext i1 %cmp5596 to i32
  store i32 %cv5597, ptr %slot1035, align 8
  %v5598 = load i32, ptr %slot1035, align 8
  %cv5599 = zext i32 %v5598 to i64
  %cond5600 = icmp ne i64 %cv5599, 0
  br i1 %cond5600, label %bb_rcgclear1310, label %bb_rcgcounted1310
bb_rcgcounted1310:
  %v5601 = load i64, ptr %slot1030, align 8
  %op5602 = sub i64 %v5601, 32
  store i64 %op5602, ptr %slot1036, align 8
  %v5603 = load i64, ptr %slot1030, align 8
  %p5604 = inttoptr i64 %v5603 to ptr
  %rgep5605 = getelementptr i8, ptr %p5604, i64 -32
  %ld5606 = load i64, ptr %rgep5605, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5606, ptr %slot1037, align 8
  %v5607 = load i64, ptr %slot1037, align 8
  %op5608 = sub i64 %v5607, 1
  store i64 %op5608, ptr %slot1038, align 8
  %v5609 = load i64, ptr %slot1038, align 8
  %cmp5610 = icmp eq i64 %v5609, 0
  %cv5611 = zext i1 %cmp5610 to i32
  store i32 %cv5611, ptr %slot1039, align 8
  %v5612 = load i32, ptr %slot1039, align 8
  %cv5613 = zext i32 %v5612 to i64
  %cond5614 = icmp ne i64 %cv5613, 0
  br i1 %cond5614, label %bb_rcglast1310, label %bb_rcgdec1310
bb_rcglast1310:
  %v5615 = load i64, ptr %slot1030, align 8
  %op5616 = sub i64 %v5615, 24
  store i64 %op5616, ptr %slot1040, align 8
  %v5617 = load i64, ptr %slot1030, align 8
  %p5618 = inttoptr i64 %v5617 to ptr
  %rgep5619 = getelementptr i8, ptr %p5618, i64 -24
  %ld5620 = load i64, ptr %rgep5619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5620, ptr %slot1041, align 8
  %v5621 = load i64, ptr %slot1041, align 8
  %cmp5622 = icmp ne i64 %v5621, 0
  %cv5623 = zext i1 %cmp5622 to i32
  store i32 %cv5623, ptr %slot1042, align 8
  %v5624 = load i32, ptr %slot1042, align 8
  %cv5625 = zext i32 %v5624 to i64
  %cond5626 = icmp ne i64 %cv5625, 0
  br i1 %cond5626, label %bb_rcgdec1310, label %bb_rcgslow1310
bb_rcgslow1310:
  %v5627 = load i64, ptr %slot1029, align 8
  %v5628 = load i64, ptr %slot1012, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v5627, i64 %v5628) nomerge, !dbg !168
  br label %bb_rcgdone1310
bb_rcgdec1310:
  %v5629 = load i64, ptr %slot1038, align 8
  %v5630 = load i64, ptr %slot1030, align 8
  %p5631 = inttoptr i64 %v5630 to ptr
  %rgep5632 = getelementptr i8, ptr %p5631, i64 -32
  store i64 %v5629, ptr %rgep5632, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1310
bb_rcgclear1310:
  %v5633 = load i64, ptr %slot1012, align 8
  %p5634 = inttoptr i64 %v5633 to ptr
  store i64 0, ptr %p5634, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1310
bb_rcgdone1310:
  br label %bb_rcslotdone1279
bb_rcslotdone1279:
  %v5635 = load i64, ptr %slot8, align 8
  %p5636 = inttoptr i64 %v5635 to ptr
  %ld5637 = load i32, ptr %p5636, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5637, ptr %slot1043, align 8
  %v5638 = load i32, ptr %slot1043, align 8
  %cv5639 = zext i32 %v5638 to i64
  %cond5640 = icmp ne i64 %cv5639, 0
  br i1 %cond5640, label %bb_rcslotdrop1316, label %bb_rcslotdone1316
bb_rcslotdrop1316:
  %v5641 = load i64, ptr %slot8, align 8
  %p5642 = inttoptr i64 %v5641 to ptr
  store i32 0, ptr %p5642, align 4, !alias.scope !3, !noalias !4
  %v5643 = load i64, ptr %slot28, align 8
  store i64 %v5643, ptr %slot1044, align 8
  %v5644 = load i64, ptr %slot9, align 8
  %p5645 = inttoptr i64 %v5644 to ptr
  %ld5646 = load i32, ptr %p5645, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5646, ptr %slot1045, align 8
  %v5647 = load i32, ptr %slot1045, align 8
  %op5648 = and i32 %v5647, 28
  store i32 %op5648, ptr %slot1046, align 8
  %v5649 = load i32, ptr %slot1046, align 8
  %cv5650 = zext i32 %v5649 to i64
  %cond5651 = icmp ne i64 %cv5650, 0
  br i1 %cond5651, label %bb_rcslotrole1316, label %bb_rcslotowner1316
bb_rcslotrole1316:
  %v5652 = load i64, ptr %slot39, align 8
  store i64 %v5652, ptr %slot1047, align 8
  %v5653 = load i64, ptr %slot1044, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  %ld5655 = load i64, ptr %p5654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5655, ptr %slot1048, align 8
  %v5656 = load i64, ptr %slot1048, align 8
  %cmp5657 = icmp ne i64 %v5656, 0
  %cv5658 = zext i1 %cmp5657 to i32
  store i32 %cv5658, ptr %slot1049, align 8
  %v5659 = load i32, ptr %slot1049, align 8
  %cv5660 = zext i32 %v5659 to i64
  %cond5661 = icmp ne i64 %cv5660, 0
  br i1 %cond5661, label %bb_rcgnn1332, label %bb_rcgdone1332
bb_rcgnn1332:
  %v5662 = load i64, ptr %slot1048, align 8
  %op5663 = sub i64 %v5662, 16
  store i64 %op5663, ptr %slot1050, align 8
  %v5664 = load i64, ptr %slot1048, align 8
  %p5665 = inttoptr i64 %v5664 to ptr
  %rgep5666 = getelementptr i8, ptr %p5665, i64 -16
  %ld5667 = load i64, ptr %rgep5666, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5667, ptr %slot1051, align 8
  %v5668 = load i64, ptr %slot1051, align 8
  %op5669 = and i64 %v5668, 4611686018427387906
  store i64 %op5669, ptr %slot1052, align 8
  %v5670 = load i64, ptr %slot1052, align 8
  %cmp5671 = icmp ne i64 %v5670, 0
  %cv5672 = zext i1 %cmp5671 to i32
  store i32 %cv5672, ptr %slot1053, align 8
  %v5673 = load i32, ptr %slot1053, align 8
  %cv5674 = zext i32 %v5673 to i64
  %cond5675 = icmp ne i64 %cv5674, 0
  br i1 %cond5675, label %bb_rcgclear1332, label %bb_rcgcounted1332
bb_rcgcounted1332:
  %v5676 = load i64, ptr %slot1048, align 8
  %op5677 = sub i64 %v5676, 24
  store i64 %op5677, ptr %slot1054, align 8
  %v5678 = load i64, ptr %slot1048, align 8
  %p5679 = inttoptr i64 %v5678 to ptr
  %rgep5680 = getelementptr i8, ptr %p5679, i64 -24
  %ld5681 = load i64, ptr %rgep5680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5681, ptr %slot1055, align 8
  %v5682 = load i64, ptr %slot1055, align 8
  %op5683 = sub i64 %v5682, 1
  store i64 %op5683, ptr %slot1056, align 8
  %v5684 = load i64, ptr %slot1056, align 8
  %cmp5685 = icmp eq i64 %v5684, 0
  %cv5686 = zext i1 %cmp5685 to i32
  store i32 %cv5686, ptr %slot1057, align 8
  %v5687 = load i32, ptr %slot1057, align 8
  %cv5688 = zext i32 %v5687 to i64
  %cond5689 = icmp ne i64 %cv5688, 0
  br i1 %cond5689, label %bb_rcglast1332, label %bb_rcgdec1332
bb_rcglast1332:
  %v5690 = load i64, ptr %slot1048, align 8
  %op5691 = sub i64 %v5690, 32
  store i64 %op5691, ptr %slot1058, align 8
  %v5692 = load i64, ptr %slot1048, align 8
  %p5693 = inttoptr i64 %v5692 to ptr
  %rgep5694 = getelementptr i8, ptr %p5693, i64 -32
  %ld5695 = load i64, ptr %rgep5694, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5695, ptr %slot1059, align 8
  %v5696 = load i64, ptr %slot1059, align 8
  %cmp5697 = icmp ne i64 %v5696, 0
  %cv5698 = zext i1 %cmp5697 to i32
  store i32 %cv5698, ptr %slot1060, align 8
  %v5699 = load i32, ptr %slot1060, align 8
  %cv5700 = zext i32 %v5699 to i64
  %cond5701 = icmp ne i64 %cv5700, 0
  br i1 %cond5701, label %bb_rcgdec1332, label %bb_rcgslow1332
bb_rcgslow1332:
  %v5702 = load i64, ptr %slot1047, align 8
  %v5703 = load i64, ptr %slot1044, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64 %v5702, i64 %v5703) nomerge, !dbg !168
  br label %bb_rcgdone1332
bb_rcgdec1332:
  %v5704 = load i64, ptr %slot1056, align 8
  %v5705 = load i64, ptr %slot1048, align 8
  %p5706 = inttoptr i64 %v5705 to ptr
  %rgep5707 = getelementptr i8, ptr %p5706, i64 -24
  store i64 %v5704, ptr %rgep5707, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1332
bb_rcgclear1332:
  %v5708 = load i64, ptr %slot1044, align 8
  %p5709 = inttoptr i64 %v5708 to ptr
  store i64 0, ptr %p5709, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1332
bb_rcgdone1332:
  br label %bb_rcslotdone1316
bb_rcslotowner1316:
  %v5710 = load i64, ptr %slot39, align 8
  store i64 %v5710, ptr %slot1061, align 8
  %v5711 = load i64, ptr %slot1044, align 8
  %p5712 = inttoptr i64 %v5711 to ptr
  %ld5713 = load i64, ptr %p5712, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5713, ptr %slot1062, align 8
  %v5714 = load i64, ptr %slot1062, align 8
  %cmp5715 = icmp ne i64 %v5714, 0
  %cv5716 = zext i1 %cmp5715 to i32
  store i32 %cv5716, ptr %slot1063, align 8
  %v5717 = load i32, ptr %slot1063, align 8
  %cv5718 = zext i32 %v5717 to i64
  %cond5719 = icmp ne i64 %cv5718, 0
  br i1 %cond5719, label %bb_rcgnn1347, label %bb_rcgdone1347
bb_rcgnn1347:
  %v5720 = load i64, ptr %slot1062, align 8
  %op5721 = sub i64 %v5720, 16
  store i64 %op5721, ptr %slot1064, align 8
  %v5722 = load i64, ptr %slot1062, align 8
  %p5723 = inttoptr i64 %v5722 to ptr
  %rgep5724 = getelementptr i8, ptr %p5723, i64 -16
  %ld5725 = load i64, ptr %rgep5724, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5725, ptr %slot1065, align 8
  %v5726 = load i64, ptr %slot1065, align 8
  %op5727 = and i64 %v5726, 4611686018427387906
  store i64 %op5727, ptr %slot1066, align 8
  %v5728 = load i64, ptr %slot1066, align 8
  %cmp5729 = icmp ne i64 %v5728, 0
  %cv5730 = zext i1 %cmp5729 to i32
  store i32 %cv5730, ptr %slot1067, align 8
  %v5731 = load i32, ptr %slot1067, align 8
  %cv5732 = zext i32 %v5731 to i64
  %cond5733 = icmp ne i64 %cv5732, 0
  br i1 %cond5733, label %bb_rcgclear1347, label %bb_rcgcounted1347
bb_rcgcounted1347:
  %v5734 = load i64, ptr %slot1062, align 8
  %op5735 = sub i64 %v5734, 32
  store i64 %op5735, ptr %slot1068, align 8
  %v5736 = load i64, ptr %slot1062, align 8
  %p5737 = inttoptr i64 %v5736 to ptr
  %rgep5738 = getelementptr i8, ptr %p5737, i64 -32
  %ld5739 = load i64, ptr %rgep5738, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5739, ptr %slot1069, align 8
  %v5740 = load i64, ptr %slot1069, align 8
  %op5741 = sub i64 %v5740, 1
  store i64 %op5741, ptr %slot1070, align 8
  %v5742 = load i64, ptr %slot1070, align 8
  %cmp5743 = icmp eq i64 %v5742, 0
  %cv5744 = zext i1 %cmp5743 to i32
  store i32 %cv5744, ptr %slot1071, align 8
  %v5745 = load i32, ptr %slot1071, align 8
  %cv5746 = zext i32 %v5745 to i64
  %cond5747 = icmp ne i64 %cv5746, 0
  br i1 %cond5747, label %bb_rcglast1347, label %bb_rcgdec1347
bb_rcglast1347:
  %v5748 = load i64, ptr %slot1062, align 8
  %op5749 = sub i64 %v5748, 24
  store i64 %op5749, ptr %slot1072, align 8
  %v5750 = load i64, ptr %slot1062, align 8
  %p5751 = inttoptr i64 %v5750 to ptr
  %rgep5752 = getelementptr i8, ptr %p5751, i64 -24
  %ld5753 = load i64, ptr %rgep5752, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5753, ptr %slot1073, align 8
  %v5754 = load i64, ptr %slot1073, align 8
  %cmp5755 = icmp ne i64 %v5754, 0
  %cv5756 = zext i1 %cmp5755 to i32
  store i32 %cv5756, ptr %slot1074, align 8
  %v5757 = load i32, ptr %slot1074, align 8
  %cv5758 = zext i32 %v5757 to i64
  %cond5759 = icmp ne i64 %cv5758, 0
  br i1 %cond5759, label %bb_rcgdec1347, label %bb_rcgslow1347
bb_rcgslow1347:
  %v5760 = load i64, ptr %slot1061, align 8
  %v5761 = load i64, ptr %slot1044, align 8
  call void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64 %v5760, i64 %v5761) nomerge, !dbg !168
  br label %bb_rcgdone1347
bb_rcgdec1347:
  %v5762 = load i64, ptr %slot1070, align 8
  %v5763 = load i64, ptr %slot1062, align 8
  %p5764 = inttoptr i64 %v5763 to ptr
  %rgep5765 = getelementptr i8, ptr %p5764, i64 -32
  store i64 %v5762, ptr %rgep5765, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1347
bb_rcgclear1347:
  %v5766 = load i64, ptr %slot1044, align 8
  %p5767 = inttoptr i64 %v5766 to ptr
  store i64 0, ptr %p5767, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1347
bb_rcgdone1347:
  br label %bb_rcslotdone1316
bb_rcslotdone1316:
  %v5768 = load i64, ptr %slot6, align 8
  %p5769 = inttoptr i64 %v5768 to ptr
  %ld5770 = load i32, ptr %p5769, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5770, ptr %slot1075, align 8
  %v5771 = load i32, ptr %slot1075, align 8
  %cv5772 = zext i32 %v5771 to i64
  %cond5773 = icmp ne i64 %cv5772, 0
  br i1 %cond5773, label %bb_rcslotdrop1353, label %bb_rcslotdone1353
bb_rcslotdrop1353:
  %v5774 = load i64, ptr %slot6, align 8
  %p5775 = inttoptr i64 %v5774 to ptr
  store i32 0, ptr %p5775, align 4, !alias.scope !3, !noalias !4
  %v5776 = load i64, ptr %slot27, align 8
  store i64 %v5776, ptr %slot1076, align 8
  %v5777 = load i64, ptr %slot7, align 8
  %p5778 = inttoptr i64 %v5777 to ptr
  %ld5779 = load i32, ptr %p5778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5779, ptr %slot1077, align 8
  %v5780 = load i32, ptr %slot1077, align 8
  %op5781 = and i32 %v5780, 28
  store i32 %op5781, ptr %slot1078, align 8
  %v5782 = load i32, ptr %slot1078, align 8
  %cv5783 = zext i32 %v5782 to i64
  %cond5784 = icmp ne i64 %cv5783, 0
  br i1 %cond5784, label %bb_rcslotrole1353, label %bb_rcslotowner1353
bb_rcslotrole1353:
  %v5785 = load i64, ptr %slot39, align 8
  store i64 %v5785, ptr %slot1079, align 8
  %v5786 = load i64, ptr %slot1076, align 8
  %p5787 = inttoptr i64 %v5786 to ptr
  %ld5788 = load i64, ptr %p5787, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5788, ptr %slot1080, align 8
  %v5789 = load i64, ptr %slot1080, align 8
  %cmp5790 = icmp ne i64 %v5789, 0
  %cv5791 = zext i1 %cmp5790 to i32
  store i32 %cv5791, ptr %slot1081, align 8
  %v5792 = load i32, ptr %slot1081, align 8
  %cv5793 = zext i32 %v5792 to i64
  %cond5794 = icmp ne i64 %cv5793, 0
  br i1 %cond5794, label %bb_rcgnn1369, label %bb_rcgdone1369
bb_rcgnn1369:
  %v5795 = load i64, ptr %slot1080, align 8
  %op5796 = sub i64 %v5795, 16
  store i64 %op5796, ptr %slot1082, align 8
  %v5797 = load i64, ptr %slot1080, align 8
  %p5798 = inttoptr i64 %v5797 to ptr
  %rgep5799 = getelementptr i8, ptr %p5798, i64 -16
  %ld5800 = load i64, ptr %rgep5799, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5800, ptr %slot1083, align 8
  %v5801 = load i64, ptr %slot1083, align 8
  %op5802 = and i64 %v5801, 4611686018427387906
  store i64 %op5802, ptr %slot1084, align 8
  %v5803 = load i64, ptr %slot1084, align 8
  %cmp5804 = icmp ne i64 %v5803, 0
  %cv5805 = zext i1 %cmp5804 to i32
  store i32 %cv5805, ptr %slot1085, align 8
  %v5806 = load i32, ptr %slot1085, align 8
  %cv5807 = zext i32 %v5806 to i64
  %cond5808 = icmp ne i64 %cv5807, 0
  br i1 %cond5808, label %bb_rcgclear1369, label %bb_rcgcounted1369
bb_rcgcounted1369:
  %v5809 = load i64, ptr %slot1080, align 8
  %op5810 = sub i64 %v5809, 24
  store i64 %op5810, ptr %slot1086, align 8
  %v5811 = load i64, ptr %slot1080, align 8
  %p5812 = inttoptr i64 %v5811 to ptr
  %rgep5813 = getelementptr i8, ptr %p5812, i64 -24
  %ld5814 = load i64, ptr %rgep5813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5814, ptr %slot1087, align 8
  %v5815 = load i64, ptr %slot1087, align 8
  %op5816 = sub i64 %v5815, 1
  store i64 %op5816, ptr %slot1088, align 8
  %v5817 = load i64, ptr %slot1088, align 8
  %cmp5818 = icmp eq i64 %v5817, 0
  %cv5819 = zext i1 %cmp5818 to i32
  store i32 %cv5819, ptr %slot1089, align 8
  %v5820 = load i32, ptr %slot1089, align 8
  %cv5821 = zext i32 %v5820 to i64
  %cond5822 = icmp ne i64 %cv5821, 0
  br i1 %cond5822, label %bb_rcglast1369, label %bb_rcgdec1369
bb_rcglast1369:
  %v5823 = load i64, ptr %slot1080, align 8
  %op5824 = sub i64 %v5823, 32
  store i64 %op5824, ptr %slot1090, align 8
  %v5825 = load i64, ptr %slot1080, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  %rgep5827 = getelementptr i8, ptr %p5826, i64 -32
  %ld5828 = load i64, ptr %rgep5827, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5828, ptr %slot1091, align 8
  %v5829 = load i64, ptr %slot1091, align 8
  %cmp5830 = icmp ne i64 %v5829, 0
  %cv5831 = zext i1 %cmp5830 to i32
  store i32 %cv5831, ptr %slot1092, align 8
  %v5832 = load i32, ptr %slot1092, align 8
  %cv5833 = zext i32 %v5832 to i64
  %cond5834 = icmp ne i64 %cv5833, 0
  br i1 %cond5834, label %bb_rcgdec1369, label %bb_rcgslow1369
bb_rcgslow1369:
  %v5835 = load i64, ptr %slot1079, align 8
  %v5836 = load i64, ptr %slot1076, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v5835, i64 %v5836) nomerge, !dbg !168
  br label %bb_rcgdone1369
bb_rcgdec1369:
  %v5837 = load i64, ptr %slot1088, align 8
  %v5838 = load i64, ptr %slot1080, align 8
  %p5839 = inttoptr i64 %v5838 to ptr
  %rgep5840 = getelementptr i8, ptr %p5839, i64 -24
  store i64 %v5837, ptr %rgep5840, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1369
bb_rcgclear1369:
  %v5841 = load i64, ptr %slot1076, align 8
  %p5842 = inttoptr i64 %v5841 to ptr
  store i64 0, ptr %p5842, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1369
bb_rcgdone1369:
  br label %bb_rcslotdone1353
bb_rcslotowner1353:
  %v5843 = load i64, ptr %slot39, align 8
  store i64 %v5843, ptr %slot1093, align 8
  %v5844 = load i64, ptr %slot1076, align 8
  %p5845 = inttoptr i64 %v5844 to ptr
  %ld5846 = load i64, ptr %p5845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5846, ptr %slot1094, align 8
  %v5847 = load i64, ptr %slot1094, align 8
  %cmp5848 = icmp ne i64 %v5847, 0
  %cv5849 = zext i1 %cmp5848 to i32
  store i32 %cv5849, ptr %slot1095, align 8
  %v5850 = load i32, ptr %slot1095, align 8
  %cv5851 = zext i32 %v5850 to i64
  %cond5852 = icmp ne i64 %cv5851, 0
  br i1 %cond5852, label %bb_rcgnn1384, label %bb_rcgdone1384
bb_rcgnn1384:
  %v5853 = load i64, ptr %slot1094, align 8
  %op5854 = sub i64 %v5853, 16
  store i64 %op5854, ptr %slot1096, align 8
  %v5855 = load i64, ptr %slot1094, align 8
  %p5856 = inttoptr i64 %v5855 to ptr
  %rgep5857 = getelementptr i8, ptr %p5856, i64 -16
  %ld5858 = load i64, ptr %rgep5857, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5858, ptr %slot1097, align 8
  %v5859 = load i64, ptr %slot1097, align 8
  %op5860 = and i64 %v5859, 4611686018427387906
  store i64 %op5860, ptr %slot1098, align 8
  %v5861 = load i64, ptr %slot1098, align 8
  %cmp5862 = icmp ne i64 %v5861, 0
  %cv5863 = zext i1 %cmp5862 to i32
  store i32 %cv5863, ptr %slot1099, align 8
  %v5864 = load i32, ptr %slot1099, align 8
  %cv5865 = zext i32 %v5864 to i64
  %cond5866 = icmp ne i64 %cv5865, 0
  br i1 %cond5866, label %bb_rcgclear1384, label %bb_rcgcounted1384
bb_rcgcounted1384:
  %v5867 = load i64, ptr %slot1094, align 8
  %op5868 = sub i64 %v5867, 32
  store i64 %op5868, ptr %slot1100, align 8
  %v5869 = load i64, ptr %slot1094, align 8
  %p5870 = inttoptr i64 %v5869 to ptr
  %rgep5871 = getelementptr i8, ptr %p5870, i64 -32
  %ld5872 = load i64, ptr %rgep5871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5872, ptr %slot1101, align 8
  %v5873 = load i64, ptr %slot1101, align 8
  %op5874 = sub i64 %v5873, 1
  store i64 %op5874, ptr %slot1102, align 8
  %v5875 = load i64, ptr %slot1102, align 8
  %cmp5876 = icmp eq i64 %v5875, 0
  %cv5877 = zext i1 %cmp5876 to i32
  store i32 %cv5877, ptr %slot1103, align 8
  %v5878 = load i32, ptr %slot1103, align 8
  %cv5879 = zext i32 %v5878 to i64
  %cond5880 = icmp ne i64 %cv5879, 0
  br i1 %cond5880, label %bb_rcglast1384, label %bb_rcgdec1384
bb_rcglast1384:
  %v5881 = load i64, ptr %slot1094, align 8
  %op5882 = sub i64 %v5881, 24
  store i64 %op5882, ptr %slot1104, align 8
  %v5883 = load i64, ptr %slot1094, align 8
  %p5884 = inttoptr i64 %v5883 to ptr
  %rgep5885 = getelementptr i8, ptr %p5884, i64 -24
  %ld5886 = load i64, ptr %rgep5885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5886, ptr %slot1105, align 8
  %v5887 = load i64, ptr %slot1105, align 8
  %cmp5888 = icmp ne i64 %v5887, 0
  %cv5889 = zext i1 %cmp5888 to i32
  store i32 %cv5889, ptr %slot1106, align 8
  %v5890 = load i32, ptr %slot1106, align 8
  %cv5891 = zext i32 %v5890 to i64
  %cond5892 = icmp ne i64 %cv5891, 0
  br i1 %cond5892, label %bb_rcgdec1384, label %bb_rcgslow1384
bb_rcgslow1384:
  %v5893 = load i64, ptr %slot1093, align 8
  %v5894 = load i64, ptr %slot1076, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v5893, i64 %v5894) nomerge, !dbg !168
  br label %bb_rcgdone1384
bb_rcgdec1384:
  %v5895 = load i64, ptr %slot1102, align 8
  %v5896 = load i64, ptr %slot1094, align 8
  %p5897 = inttoptr i64 %v5896 to ptr
  %rgep5898 = getelementptr i8, ptr %p5897, i64 -32
  store i64 %v5895, ptr %rgep5898, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1384
bb_rcgclear1384:
  %v5899 = load i64, ptr %slot1076, align 8
  %p5900 = inttoptr i64 %v5899 to ptr
  store i64 0, ptr %p5900, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1384
bb_rcgdone1384:
  br label %bb_rcslotdone1353
bb_rcslotdone1353:
  %v5901 = load i64, ptr %slot4, align 8
  %p5902 = inttoptr i64 %v5901 to ptr
  %ld5903 = load i32, ptr %p5902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5903, ptr %slot1107, align 8
  %v5904 = load i32, ptr %slot1107, align 8
  %cv5905 = zext i32 %v5904 to i64
  %cond5906 = icmp ne i64 %cv5905, 0
  br i1 %cond5906, label %bb_rcslotdrop1390, label %bb_rcslotdone1390
bb_rcslotdrop1390:
  %v5907 = load i64, ptr %slot4, align 8
  %p5908 = inttoptr i64 %v5907 to ptr
  store i32 0, ptr %p5908, align 4, !alias.scope !3, !noalias !4
  %v5909 = load i64, ptr %slot26, align 8
  store i64 %v5909, ptr %slot1108, align 8
  %v5910 = load i64, ptr %slot5, align 8
  %p5911 = inttoptr i64 %v5910 to ptr
  %ld5912 = load i32, ptr %p5911, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5912, ptr %slot1109, align 8
  %v5913 = load i32, ptr %slot1109, align 8
  %op5914 = and i32 %v5913, 28
  store i32 %op5914, ptr %slot1110, align 8
  %v5915 = load i32, ptr %slot1110, align 8
  %cv5916 = zext i32 %v5915 to i64
  %cond5917 = icmp ne i64 %cv5916, 0
  br i1 %cond5917, label %bb_rcslotrole1390, label %bb_rcslotowner1390
bb_rcslotrole1390:
  %v5918 = load i64, ptr %slot39, align 8
  store i64 %v5918, ptr %slot1111, align 8
  %v5919 = load i64, ptr %slot1111, align 8
  %v5920 = load i64, ptr %slot1108, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64 %v5919, i64 %v5920) nomerge, !dbg !168
  br label %bb_rcslotdone1390
bb_rcslotowner1390:
  %v5921 = load i64, ptr %slot39, align 8
  store i64 %v5921, ptr %slot1112, align 8
  %v5922 = load i64, ptr %slot1112, align 8
  %v5923 = load i64, ptr %slot1108, align 8
  call void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64 %v5922, i64 %v5923) nomerge, !dbg !168
  br label %bb_rcslotdone1390
bb_rcslotdone1390:
  %v5924 = load i64, ptr %slot1003, align 8
  ret i64 %v5924
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_lit_2c737daca1a53c350fb3f42d323cb68d90e97fc7a14c713c8f977d6e08c6cf81 = external global i8, align 8
@myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_341e4e2e613ad7265ba4a0832af6cbf831b05f9bc4eafcbb0c78502c39545af3(ptr sret([88 x i8]) align 8, i64, i64)
declare i64 @myl_f_528fca326a9501598ef4d78a9bbb50b5c0bfcd3e0d472d45c31c0dd98c10a96e(i64, i64, i64)
declare i64 @myl_f_66c26d82de4091c4939a671e1a95e79206b4c146c1351bf41eb605cd8e32e742(i64, i64, i64)
declare i64 @myl_f_984725bdb8bc09aeb06aa639ec64021e79ec5e9db247c1b72cde7fd9f9c3fe7d(i64, i64, i64)
declare i32 @myl_native_equal(ptr, ptr, ptr)
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_equality(ptr, i32) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_drop(i64, i64)
declare i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_loan(i64, i64, i64)
declare i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_take(i64, i64, i64, i32)
declare void @myl_t_141e4883012c5c07a6642f20a0abedcc836c54acf6d88bc7e688af8558448e88_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_drop(i64, i64)
declare void @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4_rcg_unloan(i64, i64)
declare void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_drop(i64, i64)
declare i32 @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_40ca1bbe4f370588677c61cf869c6989e3a20be2b7172b125043b9b2d28c767f_rcg_unloan(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_drop(i64, i64)
declare void @myl_t_702a6d907b417100aec372fbe640be7c932b6dc514fc7e2a91fc18f6ebf00bd0_rcg_unloan(i64, i64)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_drop(i64, i64)
declare i32 @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_fb4668a64f3668f0326904c089523b9dde529f7f24bfe0373804f946d70b42bd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_23e1bebda3014162640000246e37fa23a2bbf174be368d790fda65af887cf148", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_23e1bebda3014162640000246e37fa23a2bbf174be368d790fda65af887cf148", linkageName: "myl_f_23e1bebda3014162640000246e37fa23a2bbf174be368d790fda65af887cf148", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 3283118118415437498, i64 0, !"myl_f_23e1bebda3014162640000246e37fa23a2bbf174be368d790fda65af887cf148"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!120 = !DILocation(line: 10, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!122 = !DILocation(line: 12, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!124 = !DILocation(line: 14, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!126 = !DILocation(line: 15, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!128 = !DILocation(line: 16, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!130 = !DILocation(line: 18, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646687)
!132 = !DILocation(line: 19, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!134 = !DILocation(line: 21, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646719)
!136 = !DILocation(line: 23, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!138 = !DILocation(line: 24, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!140 = !DILocation(line: 30, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!142 = !DILocation(line: 31, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!144 = !DILocation(line: 39, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!146 = !DILocation(line: 41, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646887)
!148 = !DILocation(line: 44, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!150 = !DILocation(line: 45, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!152 = !DILocation(line: 47, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!154 = !DILocation(line: 52, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646967)
!156 = !DILocation(line: 54, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647023)
!158 = !DILocation(line: 61, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!160 = !DILocation(line: 63, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647071)
!162 = !DILocation(line: 67, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!164 = !DILocation(line: 71, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!166 = !DILocation(line: 76, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647167)
!168 = !DILocation(line: 79, column: 0, scope: !169)
