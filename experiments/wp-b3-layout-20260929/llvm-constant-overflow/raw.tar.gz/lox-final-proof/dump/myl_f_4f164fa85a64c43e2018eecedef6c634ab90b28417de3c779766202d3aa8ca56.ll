target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_4f164fa85a64c43e2018eecedef6c634ab90b28417de3c779766202d3aa8ca56(i64 %p_ctx, i64 %p_a0) #0 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v17 = load i64, ptr %slot1, align 8
  %op18 = add i64 %v17, 32
  store i64 %op18, ptr %slot3, align 8
  %mem19 = alloca i8, i64 8, align 8
  %ptr20 = ptrtoint ptr %mem19 to i64
  store i64 %ptr20, ptr %slot4, align 8
  %mem21 = alloca i8, i64 8, align 8
  %ptr22 = ptrtoint ptr %mem21 to i64
  store i64 %ptr22, ptr %slot5, align 8
  %v23 = load i64, ptr %slot2, align 8
  %v24 = load i64, ptr %slot4, align 8
  %p25 = inttoptr i64 %v24 to ptr
  store i64 %v23, ptr %p25, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v26 = load i64, ptr %slot4, align 8
  %p27 = inttoptr i64 %v26 to ptr
  %ld28 = load i64, ptr %p27, align 8, !alias.scope !3, !noalias !4
  store i64 %ld28, ptr %slot6, align 8
  %v29 = load i64, ptr %slot6, align 8
  %v30 = load i64, ptr %slot5, align 8
  %p31 = inttoptr i64 %v30 to ptr
  store i64 %v29, ptr %p31, align 8, !alias.scope !3, !noalias !4
  %v32 = load i64, ptr %slot5, align 8
  %p33 = inttoptr i64 %v32 to ptr
  %ld34 = load i64, ptr %p33, align 8, !alias.scope !3, !noalias !4
  store i64 %ld34, ptr %slot7, align 8
  %v35 = load i64, ptr %slot7, align 8
  %p36 = inttoptr i64 %v35 to ptr
  %ld37 = load i32, ptr %p36, align 4, !alias.scope !4, !noalias !3
  %ext38 = zext i32 %ld37 to i64
  store i64 %ext38, ptr %slot8, align 8
  %v39 = load i64, ptr %slot8, align 8
  %cmp40 = icmp eq i64 %v39, 0
  %cv41 = zext i1 %cmp40 to i64
  store i64 %cv41, ptr %slot9, align 8
  %v42 = load i64, ptr %slot9, align 8
  %cond43 = icmp ne i64 %v42, 0
  br i1 %cond43, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i4
bb_armnext3:
  %v44 = load i64, ptr %slot8, align 8
  %cmp45 = icmp eq i64 %v44, 1
  %cv46 = zext i1 %cmp45 to i64
  store i64 %cv46, ptr %slot10, align 8
  %v47 = load i64, ptr %slot10, align 8
  %cond48 = icmp ne i64 %v47, 0
  br i1 %cond48, label %bb_arm4, label %bb_armnext4
bb_arm4:
  br label %bb_i6
bb_armnext4:
  %v49 = load i64, ptr %slot8, align 8
  %cmp50 = icmp eq i64 %v49, 2
  %cv51 = zext i1 %cmp50 to i64
  store i64 %cv51, ptr %slot11, align 8
  %v52 = load i64, ptr %slot11, align 8
  %cond53 = icmp ne i64 %v52, 0
  br i1 %cond53, label %bb_arm5, label %bb_armnext5
bb_arm5:
  br label %bb_i2
bb_armnext5:
  %v54 = load i64, ptr %slot8, align 8
  %cmp55 = icmp eq i64 %v54, 3
  %cv56 = zext i1 %cmp55 to i64
  store i64 %cv56, ptr %slot12, align 8
  %v57 = load i64, ptr %slot12, align 8
  %cond58 = icmp ne i64 %v57, 0
  br i1 %cond58, label %bb_arm6, label %bb_armnext6
bb_arm6:
  br label %bb_i8
bb_armnext6:
  br label %bb_failure
bb_i2:
  %v59 = load i64, ptr %slot5, align 8
  %p60 = inttoptr i64 %v59 to ptr
  store i64 1, ptr %p60, align 8, !alias.scope !3, !noalias !4
  %v61 = load i64, ptr %slot5, align 8
  %p62 = inttoptr i64 %v61 to ptr
  %ld63 = load i64, ptr %p62, align 8, !alias.scope !3, !noalias !4
  store i64 %ld63, ptr %slot13, align 8
  %v64 = load i64, ptr %slot13, align 8
  ret i64 %v64
bb_i4:
  %v65 = load i64, ptr %slot5, align 8
  %p66 = inttoptr i64 %v65 to ptr
  store i64 0, ptr %p66, align 8, !alias.scope !3, !noalias !4
  %v67 = load i64, ptr %slot5, align 8
  %p68 = inttoptr i64 %v67 to ptr
  %ld69 = load i64, ptr %p68, align 8, !alias.scope !3, !noalias !4
  store i64 %ld69, ptr %slot14, align 8
  %v70 = load i64, ptr %slot14, align 8
  ret i64 %v70
bb_i6:
  %v71 = load i64, ptr %slot5, align 8
  %p72 = inttoptr i64 %v71 to ptr
  store i64 0, ptr %p72, align 8, !alias.scope !3, !noalias !4
  %v73 = load i64, ptr %slot5, align 8
  %p74 = inttoptr i64 %v73 to ptr
  %ld75 = load i64, ptr %p74, align 8, !alias.scope !3, !noalias !4
  store i64 %ld75, ptr %slot15, align 8
  %v76 = load i64, ptr %slot15, align 8
  ret i64 %v76
bb_i8:
  %v77 = load i64, ptr %slot5, align 8
  %p78 = inttoptr i64 %v77 to ptr
  store i64 0, ptr %p78, align 8, !alias.scope !3, !noalias !4
  %v79 = load i64, ptr %slot5, align 8
  %p80 = inttoptr i64 %v79 to ptr
  %ld81 = load i64, ptr %p80, align 8, !alias.scope !3, !noalias !4
  store i64 %ld81, ptr %slot16, align 8
  %v82 = load i64, ptr %slot16, align 8
  ret i64 %v82
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

attributes #0 = { "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
