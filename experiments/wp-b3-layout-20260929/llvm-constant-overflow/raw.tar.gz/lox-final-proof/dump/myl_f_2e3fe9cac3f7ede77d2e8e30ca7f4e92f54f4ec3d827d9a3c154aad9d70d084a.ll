target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_2e3fe9cac3f7ede77d2e8e30ca7f4e92f54f4ec3d827d9a3c154aad9d70d084a(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i64, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i32, align 8
  %slot142 = alloca i64, align 8
  %slot143 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v144 = load i64, ptr %slot1, align 8
  %op145 = add i64 %v144, 32
  store i64 %op145, ptr %slot4, align 8
  %mem146 = alloca i8, i64 32, align 8
  %ptr147 = ptrtoint ptr %mem146 to i64
  store i64 %ptr147, ptr %slot5, align 8
  %v148 = load i64, ptr %slot5, align 8
  %p150 = inttoptr i64 %v148 to ptr
  %gep151 = getelementptr i8, ptr %p150, i64 24
  %op149 = ptrtoint ptr %gep151 to i64
  store i64 %op149, ptr %slot6, align 8
  %v152 = load i64, ptr %slot6, align 8
  %p153 = inttoptr i64 %v152 to ptr
  store i64 0, ptr %p153, align 8, !alias.scope !3, !noalias !4
  %mem154 = alloca i8, i64 32, align 8
  %ptr155 = ptrtoint ptr %mem154 to i64
  store i64 %ptr155, ptr %slot7, align 8
  %v156 = load i64, ptr %slot7, align 8
  %p158 = inttoptr i64 %v156 to ptr
  %gep159 = getelementptr i8, ptr %p158, i64 24
  %op157 = ptrtoint ptr %gep159 to i64
  store i64 %op157, ptr %slot8, align 8
  %v160 = load i64, ptr %slot8, align 8
  %p161 = inttoptr i64 %v160 to ptr
  store i64 0, ptr %p161, align 8, !alias.scope !3, !noalias !4
  %mem162 = alloca i8, i64 16, align 8
  %ptr163 = ptrtoint ptr %mem162 to i64
  store i64 %ptr163, ptr %slot9, align 8
  %mem164 = alloca i8, i64 8, align 8
  %ptr165 = ptrtoint ptr %mem164 to i64
  store i64 %ptr165, ptr %slot10, align 8
  %mem166 = alloca i8, i64 8, align 8
  %ptr167 = ptrtoint ptr %mem166 to i64
  store i64 %ptr167, ptr %slot11, align 8
  %mem168 = alloca i8, i64 8, align 8
  %ptr169 = ptrtoint ptr %mem168 to i64
  store i64 %ptr169, ptr %slot12, align 8
  %mem170 = alloca i8, i64 8, align 8
  %ptr171 = ptrtoint ptr %mem170 to i64
  store i64 %ptr171, ptr %slot13, align 8
  %mem172 = alloca i8, i64 8, align 8
  %ptr173 = ptrtoint ptr %mem172 to i64
  store i64 %ptr173, ptr %slot14, align 8
  %mem174 = alloca i8, i64 8, align 8
  %ptr175 = ptrtoint ptr %mem174 to i64
  store i64 %ptr175, ptr %slot15, align 8
  %mem176 = alloca i8, i64 8, align 8
  %ptr177 = ptrtoint ptr %mem176 to i64
  store i64 %ptr177, ptr %slot16, align 8
  br label %bb_frameadmit2
bb_frameadmit2:
  %mem178 = alloca i8, i64 8, align 8
  %ptr179 = ptrtoint ptr %mem178 to i64
  store i64 %ptr179, ptr %slot17, align 8
  %v180 = load i64, ptr %slot1, align 8
  %op181 = add i64 %v180, 64
  store i64 %op181, ptr %slot18, align 8
  %v182 = load i64, ptr %slot18, align 8
  %p183 = inttoptr i64 %v182 to ptr
  %ld184 = load i64, ptr %p183, align 8, !alias.scope !4, !noalias !3
  store i64 %ld184, ptr %slot19, align 8
  %stack185 = call ptr @llvm.stacksave()
  %stackaddr186 = ptrtoint ptr %stack185 to i64
  %v187 = load i64, ptr %slot19, align 8
  %cmp188 = icmp ult i64 %stackaddr186, %v187
  %cv189 = zext i1 %cmp188 to i64
  store i64 %cv189, ptr %slot20, align 8
  %v190 = load i64, ptr %slot20, align 8
  %cond191 = icmp ne i64 %v190, 0
  br i1 %cond191, label %bb_floorfail4, label %bb_stackadmit3
bb_floorfail4:
  %v192 = load i64, ptr %slot1, align 8
  %p193 = inttoptr i64 %v192 to ptr
  call void @myl_qbe_fail_frame(ptr %p193) nomerge, !dbg !110
  unreachable
bb_stackadmit3:
  %v194 = load i64, ptr %slot12, align 8
  %p195 = inttoptr i64 %v194 to ptr
  store i64 0, ptr %p195, align 8, !alias.scope !3, !noalias !4
  %v196 = load i64, ptr %slot13, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 0, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot2, align 8
  %v199 = load i64, ptr %slot10, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i64 %v198, ptr %p200, align 8, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot3, align 8
  %v202 = load i64, ptr %slot11, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 %v201, ptr %p203, align 8, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot1, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %call206 = call ptr @myl_qbe_heap(ptr %p205) nomerge, !dbg !112
  %calladdr207 = ptrtoint ptr %call206 to i64
  store i64 %calladdr207, ptr %slot21, align 8
  br label %bb_i0
bb_i0:
  %v208 = load i64, ptr %slot10, align 8
  %p209 = inttoptr i64 %v208 to ptr
  %ld210 = load i64, ptr %p209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld210, ptr %slot22, align 8
  %v211 = load i64, ptr %slot22, align 8
  %v212 = load i64, ptr %slot14, align 8
  %p213 = inttoptr i64 %v212 to ptr
  store i64 %v211, ptr %p213, align 8, !alias.scope !3, !noalias !4
  %v214 = load i64, ptr %slot14, align 8
  %p215 = inttoptr i64 %v214 to ptr
  %ld216 = load i64, ptr %p215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld216, ptr %slot23, align 8
  %v217 = load i64, ptr %slot23, align 8
  %op218 = add i64 %v217, 0
  store i64 %op218, ptr %slot24, align 8
  %v219 = load i64, ptr %slot24, align 8
  %p220 = inttoptr i64 %v219 to ptr
  %ld221 = load i64, ptr %p220, align 8, !alias.scope !4, !noalias !3
  store i64 %ld221, ptr %slot25, align 8
  %v222 = load i64, ptr %slot25, align 8
  %v223 = load i64, ptr %slot14, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i64 %v222, ptr %p224, align 8, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot14, align 8
  %p226 = inttoptr i64 %v225 to ptr
  %ld227 = load i64, ptr %p226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld227, ptr %slot26, align 8
  %v228 = load i64, ptr %slot26, align 8
  %p229 = inttoptr i64 %v228 to ptr
  %ld230 = load i64, ptr %p229, align 8, !alias.scope !6, !noalias !7
  store i64 %ld230, ptr %slot27, align 8
  %v231 = load i64, ptr %slot27, align 8
  %v232 = load i64, ptr %slot14, align 8
  %p233 = inttoptr i64 %v232 to ptr
  store i64 %v231, ptr %p233, align 8, !alias.scope !3, !noalias !4
  %v234 = load i64, ptr %slot11, align 8
  %p235 = inttoptr i64 %v234 to ptr
  %ld236 = load i64, ptr %p235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld236, ptr %slot28, align 8
  %v237 = load i64, ptr %slot28, align 8
  %v238 = load i64, ptr %slot15, align 8
  %p239 = inttoptr i64 %v238 to ptr
  store i64 %v237, ptr %p239, align 8, !alias.scope !3, !noalias !4
  %v240 = load i64, ptr %slot15, align 8
  %p241 = inttoptr i64 %v240 to ptr
  %ld242 = load i64, ptr %p241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld242, ptr %slot29, align 8
  %v243 = load i64, ptr %slot29, align 8
  %p244 = inttoptr i64 %v243 to ptr
  %ld245 = load i64, ptr %p244, align 8, !alias.scope !6, !noalias !7
  store i64 %ld245, ptr %slot30, align 8
  %v246 = load i64, ptr %slot30, align 8
  %v247 = load i64, ptr %slot15, align 8
  %p248 = inttoptr i64 %v247 to ptr
  store i64 %v246, ptr %p248, align 8, !alias.scope !3, !noalias !4
  %v249 = load i64, ptr %slot15, align 8
  %p250 = inttoptr i64 %v249 to ptr
  %ld251 = load i64, ptr %p250, align 8, !alias.scope !3, !noalias !4
  store i64 %ld251, ptr %slot31, align 8
  %v252 = load i64, ptr %slot14, align 8
  %p253 = inttoptr i64 %v252 to ptr
  %ld254 = load i64, ptr %p253, align 8, !alias.scope !3, !noalias !4
  store i64 %ld254, ptr %slot32, align 8
  %v255 = load i64, ptr %slot32, align 8
  %v256 = load i64, ptr %slot31, align 8
  %ovpair258 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v255, i64 %v256)
  %op257 = extractvalue { i64, i1 } %ovpair258, 0
  %ov259 = extractvalue { i64, i1 } %ovpair258, 1
  store i64 %op257, ptr %slot33, align 8
  %v260 = load i64, ptr %slot32, align 8
  %v261 = load i64, ptr %slot33, align 8
  %op262 = xor i64 %v260, %v261
  store i64 %op262, ptr %slot34, align 8
  %v263 = load i64, ptr %slot31, align 8
  %v264 = load i64, ptr %slot33, align 8
  %op265 = xor i64 %v263, %v264
  store i64 %op265, ptr %slot35, align 8
  %v266 = load i64, ptr %slot34, align 8
  %v267 = load i64, ptr %slot35, align 8
  %op268 = and i64 %v266, %v267
  store i64 %op268, ptr %slot36, align 8
  %cv269 = zext i1 %ov259 to i64
  store i64 %cv269, ptr %slot37, align 8
  %v270 = load i64, ptr %slot37, align 8
  %cond271 = icmp ne i64 %v270, 0
  br i1 %cond271, label %bb_overflow107, label %bb_checked107
bb_overflow107:
  %v272 = load i64, ptr %slot1, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %v274 = load i64, ptr %slot32, align 8
  %v275 = load i64, ptr %slot31, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p273, i64 0, i64 %v274, i64 %v275, i64 64) nomerge, !dbg !114
  unreachable
bb_checked107:
  %v276 = load i64, ptr %slot33, align 8
  %v277 = load i64, ptr %slot14, align 8
  %p278 = inttoptr i64 %v277 to ptr
  store i64 %v276, ptr %p278, align 8, !alias.scope !3, !noalias !4
  %v279 = load i64, ptr %slot15, align 8
  %p280 = inttoptr i64 %v279 to ptr
  store i64 1, ptr %p280, align 8, !alias.scope !3, !noalias !4
  %v281 = load i64, ptr %slot15, align 8
  %p282 = inttoptr i64 %v281 to ptr
  %ld283 = load i64, ptr %p282, align 8, !alias.scope !3, !noalias !4
  store i64 %ld283, ptr %slot38, align 8
  %v284 = load i64, ptr %slot14, align 8
  %p285 = inttoptr i64 %v284 to ptr
  %ld286 = load i64, ptr %p285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld286, ptr %slot39, align 8
  %v287 = load i64, ptr %slot39, align 8
  %v288 = load i64, ptr %slot38, align 8
  %ovpair290 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v287, i64 %v288)
  %op289 = extractvalue { i64, i1 } %ovpair290, 0
  %ov291 = extractvalue { i64, i1 } %ovpair290, 1
  store i64 %op289, ptr %slot40, align 8
  %cv292 = zext i1 %ov291 to i64
  store i64 %cv292, ptr %slot41, align 8
  %v293 = load i64, ptr %slot41, align 8
  %cond294 = icmp ne i64 %v293, 0
  br i1 %cond294, label %bb_overflow114, label %bb_checked114
bb_overflow114:
  %v295 = load i64, ptr %slot1, align 8
  %p296 = inttoptr i64 %v295 to ptr
  %v297 = load i64, ptr %slot39, align 8
  %v298 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p296, i64 0, i64 %v297, i64 %v298, i64 64) nomerge, !dbg !116
  unreachable
bb_checked114:
  %v299 = load i64, ptr %slot40, align 8
  %v300 = load i64, ptr %slot14, align 8
  %p301 = inttoptr i64 %v300 to ptr
  store i64 %v299, ptr %p301, align 8, !alias.scope !3, !noalias !4
  %v302 = load i64, ptr %slot15, align 8
  %p303 = inttoptr i64 %v302 to ptr
  store i64 65536, ptr %p303, align 8, !alias.scope !3, !noalias !4
  %v304 = load i64, ptr %slot15, align 8
  %p305 = inttoptr i64 %v304 to ptr
  %ld306 = load i64, ptr %p305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld306, ptr %slot42, align 8
  %v307 = load i64, ptr %slot14, align 8
  %p308 = inttoptr i64 %v307 to ptr
  %ld309 = load i64, ptr %p308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld309, ptr %slot43, align 8
  %v310 = load i64, ptr %slot43, align 8
  %v311 = load i64, ptr %slot42, align 8
  %cmp312 = icmp sgt i64 %v310, %v311
  %cv313 = zext i1 %cmp312 to i64
  store i64 %cv313, ptr %slot44, align 8
  %v314 = load i64, ptr %slot44, align 8
  %v315 = load i64, ptr %slot14, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i64 %v314, ptr %p316, align 8, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot14, align 8
  %p318 = inttoptr i64 %v317 to ptr
  %ld319 = load i64, ptr %p318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld319, ptr %slot45, align 8
  %v320 = load i64, ptr %slot45, align 8
  %cond321 = icmp ne i64 %v320, 0
  br i1 %cond321, label %bb_next120, label %bb_i14
bb_next120:
  %v322 = load i64, ptr %slot10, align 8
  %p323 = inttoptr i64 %v322 to ptr
  %ld324 = load i64, ptr %p323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld324, ptr %slot46, align 8
  %v325 = load i64, ptr %slot46, align 8
  %v326 = load i64, ptr %slot14, align 8
  %p327 = inttoptr i64 %v326 to ptr
  store i64 %v325, ptr %p327, align 8, !alias.scope !3, !noalias !4
  %v328 = load i64, ptr %slot14, align 8
  %p329 = inttoptr i64 %v328 to ptr
  %ld330 = load i64, ptr %p329, align 8, !alias.scope !3, !noalias !4
  store i64 %ld330, ptr %slot47, align 8
  %v331 = load i64, ptr %slot1, align 8
  %v332 = load i64, ptr %slot47, align 8
  %call333 = call i64 @myl_f_4c642894ba529be575349e9e08f91ccf92d5f83245d3db607f459d6043860cdd(i64 %v331, i64 %v332) nomerge, !dbg !118
  store i64 %call333, ptr %slot48, align 8
  %v334 = load i64, ptr %slot48, align 8
  %v335 = load i64, ptr %slot14, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i64 %v334, ptr %p336, align 8, !alias.scope !3, !noalias !4
  br label %bb_i14
bb_i14:
  %v337 = load i64, ptr %slot10, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot49, align 8
  %v340 = load i64, ptr %slot49, align 8
  %v341 = load i64, ptr %slot14, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i64 %v340, ptr %p342, align 8, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot14, align 8
  %p344 = inttoptr i64 %v343 to ptr
  %ld345 = load i64, ptr %p344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld345, ptr %slot50, align 8
  %v346 = load i64, ptr %slot50, align 8
  %op347 = add i64 %v346, 0
  store i64 %op347, ptr %slot51, align 8
  %v348 = load i64, ptr %slot51, align 8
  %p349 = inttoptr i64 %v348 to ptr
  %ld350 = load i64, ptr %p349, align 8, !alias.scope !4, !noalias !3
  store i64 %ld350, ptr %slot52, align 8
  %v351 = load i64, ptr %slot52, align 8
  %v352 = load i64, ptr %slot14, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i64 %v351, ptr %p353, align 8, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot14, align 8
  %p355 = inttoptr i64 %v354 to ptr
  %ld356 = load i64, ptr %p355, align 8, !alias.scope !3, !noalias !4
  store i64 %ld356, ptr %slot53, align 8
  %v357 = load i64, ptr %slot10, align 8
  %p358 = inttoptr i64 %v357 to ptr
  %ld359 = load i64, ptr %p358, align 8, !alias.scope !3, !noalias !4
  store i64 %ld359, ptr %slot54, align 8
  %v360 = load i64, ptr %slot54, align 8
  %op361 = add i64 %v360, 0
  store i64 %op361, ptr %slot55, align 8
  store i64 0, ptr %slot56, align 8
  %v362 = load i64, ptr %slot55, align 8
  %p363 = inttoptr i64 %v362 to ptr
  %ld364 = load i64, ptr %p363, align 8, !alias.scope !4, !noalias !3
  store i64 %ld364, ptr %slot57, align 8
  %v365 = load i64, ptr %slot57, align 8
  %cmp366 = icmp ne i64 %v365, 0
  %cv367 = zext i1 %cmp366 to i32
  store i32 %cv367, ptr %slot58, align 8
  %v368 = load i32, ptr %slot58, align 8
  %cv369 = zext i32 %v368 to i64
  %cond370 = icmp ne i64 %cv369, 0
  br i1 %cond370, label %bb_rcguniquenn187, label %bb_rcgunique187
bb_rcguniquenn187:
  %v371 = load i64, ptr %slot57, align 8
  %op372 = sub i64 %v371, 16
  store i64 %op372, ptr %slot59, align 8
  %v373 = load i64, ptr %slot57, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %rgep375 = getelementptr i8, ptr %p374, i64 -16
  %ld376 = load i64, ptr %rgep375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld376, ptr %slot60, align 8
  %v377 = load i64, ptr %slot60, align 8
  %op378 = and i64 %v377, 6917529027641081858
  store i64 %op378, ptr %slot61, align 8
  %v379 = load i64, ptr %slot61, align 8
  %cmp380 = icmp ne i64 %v379, 0
  %cv381 = zext i1 %cmp380 to i32
  store i32 %cv381, ptr %slot62, align 8
  %v382 = load i32, ptr %slot62, align 8
  %cv383 = zext i32 %v382 to i64
  %cond384 = icmp ne i64 %cv383, 0
  br i1 %cond384, label %bb_rcguniqueslow187, label %bb_rcguniquecount187
bb_rcguniquecount187:
  %v385 = load i64, ptr %slot57, align 8
  %op386 = sub i64 %v385, 32
  store i64 %op386, ptr %slot63, align 8
  %v387 = load i64, ptr %slot57, align 8
  %p388 = inttoptr i64 %v387 to ptr
  %rgep389 = getelementptr i8, ptr %p388, i64 -32
  %ld390 = load i64, ptr %rgep389, align 8, !alias.scope !9, !noalias !10
  store i64 %ld390, ptr %slot64, align 8
  %v391 = load i64, ptr %slot64, align 8
  %cmp392 = icmp ult i64 %v391, 2
  %cv393 = zext i1 %cmp392 to i32
  store i32 %cv393, ptr %slot65, align 8
  %v394 = load i32, ptr %slot65, align 8
  %cv395 = zext i32 %v394 to i64
  %cond396 = icmp ne i64 %cv395, 0
  br i1 %cond396, label %bb_rcgunique187, label %bb_rcguniqueslow187
bb_rcguniqueslow187:
  %v397 = load i64, ptr %slot1, align 8
  %p398 = inttoptr i64 %v397 to ptr
  %p399 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v400 = load i64, ptr %slot55, align 8
  %p401 = inttoptr i64 %v400 to ptr
  %v402 = load i64, ptr %slot56, align 8
  %p403 = inttoptr i64 %v402 to ptr
  %call404 = call i32 @myl_qbe_rc_unique_field(ptr %p398, ptr %p399, ptr %p401, ptr %p403) nomerge, !dbg !120
  store i32 %call404, ptr %slot66, align 8
  %v405 = load i32, ptr %slot66, align 8
  %cv406 = zext i32 %v405 to i64
  %cond407 = icmp ne i64 %cv406, 0
  br i1 %cond407, label %bb_rcunique197, label %bb_failure
bb_rcunique197:
  br label %bb_rcgunique187
bb_rcgunique187:
  %v408 = load i64, ptr %slot55, align 8
  %p409 = inttoptr i64 %v408 to ptr
  %ld410 = load i64, ptr %p409, align 8, !alias.scope !4, !noalias !3
  store i64 %ld410, ptr %slot67, align 8
  %v411 = load i64, ptr %slot67, align 8
  %v412 = load i64, ptr %slot14, align 8
  %p413 = inttoptr i64 %v412 to ptr
  store i64 %v411, ptr %p413, align 8, !alias.scope !3, !noalias !4
  %v414 = load i64, ptr %slot14, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %ld416 = load i64, ptr %p415, align 8, !alias.scope !3, !noalias !4
  store i64 %ld416, ptr %slot68, align 8
  %v417 = load i64, ptr %slot68, align 8
  %v418 = load i64, ptr %slot12, align 8
  %p419 = inttoptr i64 %v418 to ptr
  store i64 %v417, ptr %p419, align 8, !alias.scope !3, !noalias !4
  %v420 = load i64, ptr %slot11, align 8
  %p421 = inttoptr i64 %v420 to ptr
  %ld422 = load i64, ptr %p421, align 8, !alias.scope !3, !noalias !4
  store i64 %ld422, ptr %slot69, align 8
  %v423 = load i64, ptr %slot69, align 8
  %v424 = load i64, ptr %slot14, align 8
  %p425 = inttoptr i64 %v424 to ptr
  store i64 %v423, ptr %p425, align 8, !alias.scope !3, !noalias !4
  %v426 = load i64, ptr %slot15, align 8
  %p427 = inttoptr i64 %v426 to ptr
  store i64 0, ptr %p427, align 8, !alias.scope !3, !noalias !4
  %v428 = load i64, ptr %slot11, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %ld430 = load i64, ptr %p429, align 8, !alias.scope !3, !noalias !4
  store i64 %ld430, ptr %slot70, align 8
  %v431 = load i64, ptr %slot70, align 8
  %v432 = load i64, ptr %slot16, align 8
  %p433 = inttoptr i64 %v432 to ptr
  store i64 %v431, ptr %p433, align 8, !alias.scope !3, !noalias !4
  %v434 = load i64, ptr %slot16, align 8
  %p435 = inttoptr i64 %v434 to ptr
  %ld436 = load i64, ptr %p435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld436, ptr %slot71, align 8
  %v437 = load i64, ptr %slot71, align 8
  %p438 = inttoptr i64 %v437 to ptr
  %ld439 = load i64, ptr %p438, align 8, !alias.scope !6, !noalias !7
  store i64 %ld439, ptr %slot72, align 8
  %v440 = load i64, ptr %slot72, align 8
  %v441 = load i64, ptr %slot16, align 8
  %p442 = inttoptr i64 %v441 to ptr
  store i64 %v440, ptr %p442, align 8, !alias.scope !3, !noalias !4
  %v443 = load i64, ptr %slot12, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i64, ptr %p444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld445, ptr %slot73, align 8
  %v446 = load i64, ptr %slot14, align 8
  %p447 = inttoptr i64 %v446 to ptr
  %ld448 = load i64, ptr %p447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld448, ptr %slot74, align 8
  %v449 = load i64, ptr %slot15, align 8
  %p450 = inttoptr i64 %v449 to ptr
  %ld451 = load i64, ptr %p450, align 8, !alias.scope !3, !noalias !4
  store i64 %ld451, ptr %slot75, align 8
  %v452 = load i64, ptr %slot16, align 8
  %p453 = inttoptr i64 %v452 to ptr
  %ld454 = load i64, ptr %p453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld454, ptr %slot76, align 8
  %v455 = load i64, ptr %slot73, align 8
  %op456 = add i64 %v455, 8
  store i64 %op456, ptr %slot77, align 8
  %v457 = load i64, ptr %slot75, align 8
  %cmp458 = icmp sge i64 %v457, 0
  %cv459 = zext i1 %cmp458 to i64
  store i64 %cv459, ptr %slot78, align 8
  %v460 = load i64, ptr %slot78, align 8
  %cond461 = icmp ne i64 %v460, 0
  br i1 %cond461, label %bb_buf_start320, label %bb_buf_refused320
bb_buf_start320:
  %v462 = load i64, ptr %slot75, align 8
  %v463 = load i64, ptr %slot76, align 8
  %cmp464 = icmp sle i64 %v462, %v463
  %cv465 = zext i1 %cmp464 to i64
  store i64 %cv465, ptr %slot79, align 8
  %v466 = load i64, ptr %slot79, align 8
  %cond467 = icmp ne i64 %v466, 0
  br i1 %cond467, label %bb_buf_order320, label %bb_buf_refused320
bb_buf_order320:
  %v468 = load i64, ptr %slot74, align 8
  %p469 = inttoptr i64 %v468 to ptr
  %ld470 = load i64, ptr %p469, align 8, !alias.scope !6, !noalias !7
  store i64 %ld470, ptr %slot80, align 8
  %v471 = load i64, ptr %slot76, align 8
  %v472 = load i64, ptr %slot80, align 8
  %cmp473 = icmp ule i64 %v471, %v472
  %cv474 = zext i1 %cmp473 to i64
  store i64 %cv474, ptr %slot81, align 8
  %v475 = load i64, ptr %slot81, align 8
  %cond476 = icmp ne i64 %v475, 0
  br i1 %cond476, label %bb_buf_bound320, label %bb_buf_refused320
bb_buf_bound320:
  %v477 = load i64, ptr %slot73, align 8
  %p478 = inttoptr i64 %v477 to ptr
  %ld479 = load i64, ptr %p478, align 8, !alias.scope !6, !noalias !7
  store i64 %ld479, ptr %slot82, align 8
  %v480 = load i64, ptr %slot77, align 8
  %p481 = inttoptr i64 %v480 to ptr
  %ld482 = load i64, ptr %p481, align 8, !alias.scope !6, !noalias !7
  store i64 %ld482, ptr %slot83, align 8
  %v483 = load i64, ptr %slot76, align 8
  %v484 = load i64, ptr %slot75, align 8
  %op485 = sub i64 %v483, %v484
  store i64 %op485, ptr %slot84, align 8
  %v486 = load i64, ptr %slot83, align 8
  %v487 = load i64, ptr %slot82, align 8
  %op488 = sub i64 %v486, %v487
  store i64 %op488, ptr %slot85, align 8
  %v489 = load i64, ptr %slot84, align 8
  %v490 = load i64, ptr %slot85, align 8
  %cmp491 = icmp ult i64 %v489, %v490
  %cv492 = zext i1 %cmp491 to i64
  store i64 %cv492, ptr %slot86, align 8
  %v493 = load i64, ptr %slot86, align 8
  %cond494 = icmp ne i64 %v493, 0
  br i1 %cond494, label %bb_buf_fast320, label %bb_buf_slow320
bb_buf_slow320:
  %v495 = load i64, ptr %slot21, align 8
  %p496 = inttoptr i64 %v495 to ptr
  %v497 = load i64, ptr %slot73, align 8
  %p498 = inttoptr i64 %v497 to ptr
  %v499 = load i64, ptr %slot74, align 8
  %p500 = inttoptr i64 %v499 to ptr
  %v501 = load i64, ptr %slot75, align 8
  %v502 = load i64, ptr %slot76, align 8
  %call503 = call i32 @myl_native_bytes_buffer_append_range(ptr %p496, ptr %p498, ptr %p500, i64 %v501, i64 %v502) nomerge, !dbg !122
  store i32 %call503, ptr %slot87, align 8
  %v504 = load i32, ptr %slot87, align 8
  %ext505 = zext i32 %v504 to i64
  store i64 %ext505, ptr %slot88, align 8
  %v506 = load i64, ptr %slot88, align 8
  %cmp507 = icmp ne i64 %v506, 0
  %cv508 = zext i1 %cmp507 to i64
  store i64 %cv508, ptr %slot89, align 8
  %v509 = load i64, ptr %slot89, align 8
  %cond510 = icmp ne i64 %v509, 0
  br i1 %cond510, label %bb_success334, label %bb_failed334
bb_failed334:
  %v511 = load i64, ptr %slot1, align 8
  %p512 = inttoptr i64 %v511 to ptr
  call void @myl_qbe_fail_allocation(ptr %p512) nomerge, !dbg !122
  unreachable
bb_success334:
  %v513 = load i32, ptr %slot87, align 8
  %cmp514 = icmp eq i32 %v513, 1
  %cv515 = zext i1 %cmp514 to i32
  store i32 %cv515, ptr %slot90, align 8
  %v516 = load i32, ptr %slot90, align 8
  %ext517 = zext i32 %v516 to i64
  store i64 %ext517, ptr %slot91, align 8
  %v518 = load i64, ptr %slot91, align 8
  %v519 = load i64, ptr %slot14, align 8
  %p520 = inttoptr i64 %v519 to ptr
  store i64 %v518, ptr %p520, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done320
bb_buf_fast320:
  %v521 = load i64, ptr %slot73, align 8
  %op522 = add i64 %v521, 32
  store i64 %op522, ptr %slot92, align 8
  %v523 = load i64, ptr %slot74, align 8
  %op524 = add i64 %v523, 32
  store i64 %op524, ptr %slot93, align 8
  %v525 = load i64, ptr %slot92, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i64, ptr %p526, align 8, !alias.scope !6, !noalias !7
  store i64 %ld527, ptr %slot94, align 8
  %v528 = load i64, ptr %slot94, align 8
  %v529 = load i64, ptr %slot82, align 8
  %op530 = add i64 %v528, %v529
  store i64 %op530, ptr %slot95, align 8
  %v531 = load i64, ptr %slot93, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i64, ptr %p532, align 8, !alias.scope !6, !noalias !7
  store i64 %ld533, ptr %slot96, align 8
  %v534 = load i64, ptr %slot96, align 8
  %v535 = load i64, ptr %slot75, align 8
  %op536 = add i64 %v534, %v535
  store i64 %op536, ptr %slot97, align 8
  %v537 = load i64, ptr %slot95, align 8
  %p538 = inttoptr i64 %v537 to ptr
  %v539 = load i64, ptr %slot97, align 8
  %p540 = inttoptr i64 %v539 to ptr
  %v541 = load i64, ptr %slot84, align 8
  call void @myl_native_bytes_copy_octets(ptr %p538, ptr %p540, i64 %v541) nomerge, !dbg !122
  %v542 = load i64, ptr %slot82, align 8
  %v543 = load i64, ptr %slot84, align 8
  %op544 = add i64 %v542, %v543
  store i64 %op544, ptr %slot98, align 8
  %v545 = load i64, ptr %slot98, align 8
  %v546 = load i64, ptr %slot73, align 8
  %p547 = inttoptr i64 %v546 to ptr
  store i64 %v545, ptr %p547, align 8, !alias.scope !6, !noalias !7
  %v548 = load i64, ptr %slot14, align 8
  %p549 = inttoptr i64 %v548 to ptr
  store i64 1, ptr %p549, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done320
bb_buf_refused320:
  %v550 = load i64, ptr %slot14, align 8
  %p551 = inttoptr i64 %v550 to ptr
  store i64 0, ptr %p551, align 8, !alias.scope !3, !noalias !4
  br label %bb_buf_done320
bb_buf_done320:
  %v552 = load i64, ptr %slot10, align 8
  %p553 = inttoptr i64 %v552 to ptr
  %ld554 = load i64, ptr %p553, align 8, !alias.scope !3, !noalias !4
  store i64 %ld554, ptr %slot99, align 8
  %v555 = load i64, ptr %slot99, align 8
  %v556 = load i64, ptr %slot14, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i64 %v555, ptr %p557, align 8, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot14, align 8
  %p559 = inttoptr i64 %v558 to ptr
  %ld560 = load i64, ptr %p559, align 8, !alias.scope !3, !noalias !4
  store i64 %ld560, ptr %slot100, align 8
  %v561 = load i64, ptr %slot100, align 8
  %op562 = add i64 %v561, 0
  store i64 %op562, ptr %slot101, align 8
  %v563 = load i64, ptr %slot101, align 8
  %p564 = inttoptr i64 %v563 to ptr
  %ld565 = load i64, ptr %p564, align 8, !alias.scope !4, !noalias !3
  store i64 %ld565, ptr %slot102, align 8
  %v566 = load i64, ptr %slot102, align 8
  %v567 = load i64, ptr %slot14, align 8
  %p568 = inttoptr i64 %v567 to ptr
  store i64 %v566, ptr %p568, align 8, !alias.scope !3, !noalias !4
  %v569 = load i64, ptr %slot14, align 8
  %p570 = inttoptr i64 %v569 to ptr
  %ld571 = load i64, ptr %p570, align 8, !alias.scope !3, !noalias !4
  store i64 %ld571, ptr %slot103, align 8
  %v572 = load i64, ptr %slot10, align 8
  %p573 = inttoptr i64 %v572 to ptr
  %ld574 = load i64, ptr %p573, align 8, !alias.scope !3, !noalias !4
  store i64 %ld574, ptr %slot104, align 8
  %v575 = load i64, ptr %slot104, align 8
  %op576 = add i64 %v575, 0
  store i64 %op576, ptr %slot105, align 8
  store i64 0, ptr %slot106, align 8
  %v577 = load i64, ptr %slot105, align 8
  %p578 = inttoptr i64 %v577 to ptr
  %ld579 = load i64, ptr %p578, align 8, !alias.scope !4, !noalias !3
  store i64 %ld579, ptr %slot107, align 8
  %v580 = load i64, ptr %slot107, align 8
  %cmp581 = icmp ne i64 %v580, 0
  %cv582 = zext i1 %cmp581 to i32
  store i32 %cv582, ptr %slot108, align 8
  %v583 = load i32, ptr %slot108, align 8
  %cv584 = zext i32 %v583 to i64
  %cond585 = icmp ne i64 %cv584, 0
  br i1 %cond585, label %bb_rcguniquenn436, label %bb_rcgunique436
bb_rcguniquenn436:
  %v586 = load i64, ptr %slot107, align 8
  %op587 = sub i64 %v586, 16
  store i64 %op587, ptr %slot109, align 8
  %v588 = load i64, ptr %slot107, align 8
  %p589 = inttoptr i64 %v588 to ptr
  %rgep590 = getelementptr i8, ptr %p589, i64 -16
  %ld591 = load i64, ptr %rgep590, align 8, !alias.scope !9, !noalias !10
  store i64 %ld591, ptr %slot110, align 8
  %v592 = load i64, ptr %slot110, align 8
  %op593 = and i64 %v592, 6917529027641081858
  store i64 %op593, ptr %slot111, align 8
  %v594 = load i64, ptr %slot111, align 8
  %cmp595 = icmp ne i64 %v594, 0
  %cv596 = zext i1 %cmp595 to i32
  store i32 %cv596, ptr %slot112, align 8
  %v597 = load i32, ptr %slot112, align 8
  %cv598 = zext i32 %v597 to i64
  %cond599 = icmp ne i64 %cv598, 0
  br i1 %cond599, label %bb_rcguniqueslow436, label %bb_rcguniquecount436
bb_rcguniquecount436:
  %v600 = load i64, ptr %slot107, align 8
  %op601 = sub i64 %v600, 32
  store i64 %op601, ptr %slot113, align 8
  %v602 = load i64, ptr %slot107, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %rgep604 = getelementptr i8, ptr %p603, i64 -32
  %ld605 = load i64, ptr %rgep604, align 8, !alias.scope !9, !noalias !10
  store i64 %ld605, ptr %slot114, align 8
  %v606 = load i64, ptr %slot114, align 8
  %cmp607 = icmp ult i64 %v606, 2
  %cv608 = zext i1 %cmp607 to i32
  store i32 %cv608, ptr %slot115, align 8
  %v609 = load i32, ptr %slot115, align 8
  %cv610 = zext i32 %v609 to i64
  %cond611 = icmp ne i64 %cv610, 0
  br i1 %cond611, label %bb_rcgunique436, label %bb_rcguniqueslow436
bb_rcguniqueslow436:
  %v612 = load i64, ptr %slot1, align 8
  %p613 = inttoptr i64 %v612 to ptr
  %p614 = inttoptr i64 ptrtoint (ptr @myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 to i64) to ptr
  %v615 = load i64, ptr %slot105, align 8
  %p616 = inttoptr i64 %v615 to ptr
  %v617 = load i64, ptr %slot106, align 8
  %p618 = inttoptr i64 %v617 to ptr
  %call619 = call i32 @myl_qbe_rc_unique_field(ptr %p613, ptr %p614, ptr %p616, ptr %p618) nomerge, !dbg !124
  store i32 %call619, ptr %slot116, align 8
  %v620 = load i32, ptr %slot116, align 8
  %cv621 = zext i32 %v620 to i64
  %cond622 = icmp ne i64 %cv621, 0
  br i1 %cond622, label %bb_rcunique446, label %bb_failure
bb_rcunique446:
  br label %bb_rcgunique436
bb_rcgunique436:
  %v623 = load i64, ptr %slot105, align 8
  %p624 = inttoptr i64 %v623 to ptr
  %ld625 = load i64, ptr %p624, align 8, !alias.scope !4, !noalias !3
  store i64 %ld625, ptr %slot117, align 8
  %v626 = load i64, ptr %slot117, align 8
  %v627 = load i64, ptr %slot14, align 8
  %p628 = inttoptr i64 %v627 to ptr
  store i64 %v626, ptr %p628, align 8, !alias.scope !3, !noalias !4
  %v629 = load i64, ptr %slot14, align 8
  %p630 = inttoptr i64 %v629 to ptr
  %ld631 = load i64, ptr %p630, align 8, !alias.scope !3, !noalias !4
  store i64 %ld631, ptr %slot118, align 8
  %v632 = load i64, ptr %slot118, align 8
  %v633 = load i64, ptr %slot13, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i64 %v632, ptr %p634, align 8, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot14, align 8
  %p636 = inttoptr i64 %v635 to ptr
  store i64 10, ptr %p636, align 8, !alias.scope !3, !noalias !4
  %v637 = load i64, ptr %slot13, align 8
  %p638 = inttoptr i64 %v637 to ptr
  %ld639 = load i64, ptr %p638, align 8, !alias.scope !3, !noalias !4
  store i64 %ld639, ptr %slot119, align 8
  %v640 = load i64, ptr %slot14, align 8
  %p641 = inttoptr i64 %v640 to ptr
  %ld642 = load i64, ptr %p641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld642, ptr %slot120, align 8
  %v643 = load i64, ptr %slot119, align 8
  %op644 = add i64 %v643, 8
  store i64 %op644, ptr %slot121, align 8
  %v645 = load i64, ptr %slot120, align 8
  %cmp646 = icmp sge i64 %v645, 0
  %cv647 = zext i1 %cmp646 to i64
  store i64 %cv647, ptr %slot122, align 8
  %v648 = load i64, ptr %slot122, align 8
  %cond649 = icmp ne i64 %v648, 0
  br i1 %cond649, label %bb_byte_low526, label %bb_byte_refused526
bb_byte_low526:
  %v650 = load i64, ptr %slot120, align 8
  %cmp651 = icmp sle i64 %v650, 255
  %cv652 = zext i1 %cmp651 to i64
  store i64 %cv652, ptr %slot123, align 8
  %v653 = load i64, ptr %slot123, align 8
  %cond654 = icmp ne i64 %v653, 0
  br i1 %cond654, label %bb_byte_high526, label %bb_byte_refused526
bb_byte_high526:
  %v655 = load i64, ptr %slot119, align 8
  %p656 = inttoptr i64 %v655 to ptr
  %ld657 = load i64, ptr %p656, align 8, !alias.scope !6, !noalias !7
  store i64 %ld657, ptr %slot124, align 8
  %v658 = load i64, ptr %slot121, align 8
  %p659 = inttoptr i64 %v658 to ptr
  %ld660 = load i64, ptr %p659, align 8, !alias.scope !6, !noalias !7
  store i64 %ld660, ptr %slot125, align 8
  %v661 = load i64, ptr %slot124, align 8
  %v662 = load i64, ptr %slot125, align 8
  %cmp663 = icmp ult i64 %v661, %v662
  %cv664 = zext i1 %cmp663 to i64
  store i64 %cv664, ptr %slot126, align 8
  %v665 = load i64, ptr %slot126, align 8
  %cond666 = icmp ne i64 %v665, 0
  br i1 %cond666, label %bb_byte_fast526, label %bb_byte_slow526
bb_byte_slow526:
  %v667 = load i64, ptr %slot21, align 8
  %p668 = inttoptr i64 %v667 to ptr
  %v669 = load i64, ptr %slot119, align 8
  %p670 = inttoptr i64 %v669 to ptr
  %v671 = load i64, ptr %slot120, align 8
  %call672 = call i32 @myl_native_bytes_buffer_append_byte(ptr %p668, ptr %p670, i64 %v671) nomerge, !dbg !126
  store i32 %call672, ptr %slot127, align 8
  %v673 = load i32, ptr %slot127, align 8
  %ext674 = zext i32 %v673 to i64
  store i64 %ext674, ptr %slot128, align 8
  %v675 = load i64, ptr %slot128, align 8
  %cmp676 = icmp ne i64 %v675, 0
  %cv677 = zext i1 %cmp676 to i64
  store i64 %cv677, ptr %slot129, align 8
  %v678 = load i64, ptr %slot129, align 8
  %cond679 = icmp ne i64 %v678, 0
  br i1 %cond679, label %bb_success536, label %bb_failed536
bb_failed536:
  %v680 = load i64, ptr %slot1, align 8
  %p681 = inttoptr i64 %v680 to ptr
  call void @myl_qbe_fail_allocation(ptr %p681) nomerge, !dbg !126
  unreachable
bb_success536:
  %v682 = load i32, ptr %slot127, align 8
  %cmp683 = icmp eq i32 %v682, 1
  %cv684 = zext i1 %cmp683 to i32
  store i32 %cv684, ptr %slot130, align 8
  %v685 = load i32, ptr %slot130, align 8
  %ext686 = zext i32 %v685 to i64
  store i64 %ext686, ptr %slot131, align 8
  %v687 = load i64, ptr %slot131, align 8
  %v688 = load i64, ptr %slot14, align 8
  %p689 = inttoptr i64 %v688 to ptr
  store i64 %v687, ptr %p689, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done526
bb_byte_fast526:
  %v690 = load i64, ptr %slot119, align 8
  %op691 = add i64 %v690, 32
  store i64 %op691, ptr %slot132, align 8
  %v692 = load i64, ptr %slot132, align 8
  %p693 = inttoptr i64 %v692 to ptr
  %ld694 = load i64, ptr %p693, align 8, !alias.scope !6, !noalias !7
  store i64 %ld694, ptr %slot133, align 8
  %v695 = load i64, ptr %slot133, align 8
  %v696 = load i64, ptr %slot124, align 8
  %op697 = add i64 %v695, %v696
  store i64 %op697, ptr %slot134, align 8
  %v698 = load i64, ptr %slot120, align 8
  %cv699 = trunc i64 %v698 to i8
  %v700 = load i64, ptr %slot133, align 8
  %p701 = inttoptr i64 %v700 to ptr
  %v702 = load i64, ptr %slot124, align 8
  %egep703 = getelementptr i8, ptr %p701, i64 %v702
  store i8 %cv699, ptr %egep703, align 1, !alias.scope !12, !noalias !13
  %v704 = load i64, ptr %slot124, align 8
  %op705 = add i64 %v704, 1
  store i64 %op705, ptr %slot135, align 8
  %v706 = load i64, ptr %slot135, align 8
  %v707 = load i64, ptr %slot119, align 8
  %p708 = inttoptr i64 %v707 to ptr
  store i64 %v706, ptr %p708, align 8, !alias.scope !6, !noalias !7
  %v709 = load i64, ptr %slot14, align 8
  %p710 = inttoptr i64 %v709 to ptr
  store i64 1, ptr %p710, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done526
bb_byte_refused526:
  %v711 = load i64, ptr %slot14, align 8
  %p712 = inttoptr i64 %v711 to ptr
  store i64 0, ptr %p712, align 8, !alias.scope !3, !noalias !4
  br label %bb_byte_done526
bb_byte_done526:
  %v713 = load i64, ptr %slot14, align 8
  %p714 = inttoptr i64 %v713 to ptr
  store i64 0, ptr %p714, align 8, !alias.scope !3, !noalias !4
  %v715 = load i64, ptr %slot14, align 8
  %p716 = inttoptr i64 %v715 to ptr
  %ld717 = load i64, ptr %p716, align 8, !alias.scope !3, !noalias !4
  store i64 %ld717, ptr %slot136, align 8
  %v718 = load i64, ptr %slot5, align 8
  %p720 = inttoptr i64 %v718 to ptr
  %gep721 = getelementptr i8, ptr %p720, i64 24
  %op719 = ptrtoint ptr %gep721 to i64
  store i64 %op719, ptr %slot137, align 8
  %v722 = load i64, ptr %slot137, align 8
  %p723 = inttoptr i64 %v722 to ptr
  %ld724 = load i32, ptr %p723, align 4, !alias.scope !3, !noalias !4
  store i32 %ld724, ptr %slot138, align 8
  %v725 = load i64, ptr %slot7, align 8
  %p727 = inttoptr i64 %v725 to ptr
  %gep728 = getelementptr i8, ptr %p727, i64 24
  %op726 = ptrtoint ptr %gep728 to i64
  store i64 %op726, ptr %slot139, align 8
  %v729 = load i64, ptr %slot139, align 8
  %p730 = inttoptr i64 %v729 to ptr
  %ld731 = load i32, ptr %p730, align 4, !alias.scope !3, !noalias !4
  store i32 %ld731, ptr %slot140, align 8
  %v732 = load i32, ptr %slot138, align 8
  %v733 = load i32, ptr %slot140, align 8
  %op734 = or i32 %v732, %v733
  store i32 %op734, ptr %slot141, align 8
  %v735 = load i32, ptr %slot141, align 8
  %cv736 = zext i32 %v735 to i64
  %cond737 = icmp ne i64 %cv736, 0
  br i1 %cond737, label %bb_rcscopesopen549, label %bb_rcscopesclosed549
bb_rcscopesopen549:
  %v738 = load i64, ptr %slot9, align 8
  %p740 = inttoptr i64 %v738 to ptr
  %gep741 = getelementptr i8, ptr %p740, i64 0
  %op739 = ptrtoint ptr %gep741 to i64
  store i64 %op739, ptr %slot142, align 8
  %v742 = load i64, ptr %slot5, align 8
  %v743 = load i64, ptr %slot142, align 8
  %p744 = inttoptr i64 %v743 to ptr
  store i64 %v742, ptr %p744, align 8, !alias.scope !3, !noalias !4
  %v745 = load i64, ptr %slot9, align 8
  %p747 = inttoptr i64 %v745 to ptr
  %gep748 = getelementptr i8, ptr %p747, i64 8
  %op746 = ptrtoint ptr %gep748 to i64
  store i64 %op746, ptr %slot143, align 8
  %v749 = load i64, ptr %slot7, align 8
  %v750 = load i64, ptr %slot143, align 8
  %p751 = inttoptr i64 %v750 to ptr
  store i64 %v749, ptr %p751, align 8, !alias.scope !3, !noalias !4
  %v752 = load i64, ptr %slot1, align 8
  %p753 = inttoptr i64 %v752 to ptr
  %v754 = load i64, ptr %slot9, align 8
  %p755 = inttoptr i64 %v754 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p753, ptr %p755, i64 2) nomerge, !dbg !128
  br label %bb_rcscopesclosed549
bb_rcscopesclosed549:
  %v756 = load i64, ptr %slot136, align 8
  ret i64 %v756
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

@myl_t_116cf4fc7836f7c53a144ff128684d21464d3dd27020a98b52338f495b63cce7 = external global i8, align 8

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_4c642894ba529be575349e9e08f91ccf92d5f83245d3db607f459d6043860cdd(i64, i64)
declare i32 @myl_native_bytes_buffer_append_byte(ptr, ptr, i64)
declare i32 @myl_native_bytes_buffer_append_range(ptr, ptr, ptr, i64, i64)
declare void @myl_native_bytes_copy_octets(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!11 = distinct !{!11, !0, !"element 1v"}
!12 = !{!11}
!13 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_2e3fe9cac3f7ede77d2e8e30ca7f4e92f54f4ec3d827d9a3c154aad9d70d084a", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_2e3fe9cac3f7ede77d2e8e30ca7f4e92f54f4ec3d827d9a3c154aad9d70d084a", linkageName: "myl_f_2e3fe9cac3f7ede77d2e8e30ca7f4e92f54f4ec3d827d9a3c154aad9d70d084a", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9638585953188844230, i64 0, !"myl_f_2e3fe9cac3f7ede77d2e8e30ca7f4e92f54f4ec3d827d9a3c154aad9d70d084a"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!116 = !DILocation(line: 8, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!118 = !DILocation(line: 13, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!120 = !DILocation(line: 17, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646711)
!122 = !DILocation(line: 22, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646743)
!124 = !DILocation(line: 26, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!126 = !DILocation(line: 28, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!128 = !DILocation(line: 31, column: 0, scope: !129)
