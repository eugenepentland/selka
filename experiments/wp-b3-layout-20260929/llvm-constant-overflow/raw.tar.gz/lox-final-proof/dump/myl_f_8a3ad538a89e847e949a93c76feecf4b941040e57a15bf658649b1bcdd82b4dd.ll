target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2, i64 %p_a3) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i64, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i32, align 8
  %slot104 = alloca i32, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i32, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i32, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i64, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i64, align 8
  %slot137 = alloca i64, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i64, align 8
  %callresult143 = alloca [16 x i8], align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i64, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i64, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i64, align 8
  %slot155 = alloca i64, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i32, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i32, align 8
  %slot171 = alloca i32, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i64, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i32, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i64, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i32, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i32, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i64, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i64, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i32, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i64, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i64, align 8
  %slot244 = alloca i64, align 8
  %slot245 = alloca i64, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i64, align 8
  %slot249 = alloca i64, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i64, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i32, align 8
  %slot269 = alloca i64, align 8
  %slot270 = alloca i32, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i64, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i64, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i32, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i64, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i64, align 8
  %slot323 = alloca i64, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i32, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i32, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i32, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i64, align 8
  %slot352 = alloca i64, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i32, align 8
  %slot363 = alloca i64, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i64, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i64, align 8
  %slot370 = alloca i64, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i32, align 8
  %slot374 = alloca i64, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i32, align 8
  %slot378 = alloca i64, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i32, align 8
  %slot381 = alloca i32, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i64, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i64, align 8
  %slot387 = alloca i64, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i64, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i64, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i64, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i64, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i64, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i64, align 8
  %slot410 = alloca i32, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i64, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i64, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i64, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i32, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i64, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i64, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i64, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i64, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i64, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i64, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i64, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i64, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i64, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i32, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i32, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i64, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i64, align 8
  %slot476 = alloca i64, align 8
  %slot477 = alloca i32, align 8
  %slot478 = alloca i64, align 8
  %slot479 = alloca i64, align 8
  %slot480 = alloca i32, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i64, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i64, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i32, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i32, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i32, align 8
  %slot507 = alloca i32, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i64, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i64, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i64, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i64, align 8
  %slot522 = alloca i64, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i64, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i64, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %slot538 = alloca i64, align 8
  %slot539 = alloca i64, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i64, align 8
  %slot542 = alloca i64, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i32, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i32, align 8
  %slot547 = alloca i32, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %callresult554 = alloca [24 x i8], align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i64, align 8
  %slot557 = alloca i32, align 8
  %slot558 = alloca i64, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i32, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i32, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i64, align 8
  %slot570 = alloca i32, align 8
  %slot571 = alloca i32, align 8
  %slot572 = alloca i32, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i32, align 8
  %slot576 = alloca i32, align 8
  %slot577 = alloca i64, align 8
  %slot578 = alloca i64, align 8
  %slot579 = alloca i64, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i64, align 8
  %slot583 = alloca i32, align 8
  %slot584 = alloca i32, align 8
  %slot585 = alloca i32, align 8
  %slot586 = alloca i32, align 8
  %slot587 = alloca i64, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i32, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i64, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i32, align 8
  %slot597 = alloca i64, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i32, align 8
  %slot601 = alloca i64, align 8
  %slot602 = alloca i32, align 8
  %slot603 = alloca i32, align 8
  %slot604 = alloca i32, align 8
  %slot605 = alloca i64, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i32, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i32, align 8
  %slot610 = alloca i32, align 8
  %slot611 = alloca i64, align 8
  %slot612 = alloca i32, align 8
  %slot613 = alloca i32, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i64, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i32, align 8
  %slot619 = alloca i64, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i32, align 8
  %slot627 = alloca i64, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i32, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i32, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i64, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i64, align 8
  %slot639 = alloca i32, align 8
  %slot640 = alloca i64, align 8
  %slot641 = alloca i64, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i32, align 8
  %slot644 = alloca i64, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i32, align 8
  %slot648 = alloca i64, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i32, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i64, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i32, align 8
  %slot655 = alloca i64, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i32, align 8
  %slot661 = alloca i32, align 8
  %slot662 = alloca i64, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i64, align 8
  %slot667 = alloca i32, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i32, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i32, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i32, align 8
  %slot679 = alloca i32, align 8
  %slot680 = alloca i64, align 8
  %slot681 = alloca i64, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i64, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i64, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i32, align 8
  %slot694 = alloca i32, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i64, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i64, align 8
  %callresult701 = alloca [24 x i8], align 8
  %slot702 = alloca i32, align 8
  %slot703 = alloca i64, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i64, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i64, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i64, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i32, align 8
  %slot721 = alloca i32, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %callresult729 = alloca [32 x i8], align 8
  %slot730 = alloca i32, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i32, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i32, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i32, align 8
  %slot743 = alloca i32, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i64, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i32, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i32, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i64, align 8
  %slot761 = alloca i64, align 8
  %slot762 = alloca i64, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i64, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i32, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i32, align 8
  %slot772 = alloca i32, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i64, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i64, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i64, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i64, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i64, align 8
  %slot791 = alloca i32, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i32, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i64, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i64, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i32, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i64, align 8
  %slot808 = alloca i64, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i64, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i64, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i64, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i64, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i64, align 8
  %slot824 = alloca i32, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i64, align 8
  %slot846 = alloca i64, align 8
  %callresult847 = alloca [24 x i8], align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i32, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i32, align 8
  %slot853 = alloca i32, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i32, align 8
  %slot859 = alloca i64, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i64, align 8
  %slot862 = alloca i64, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i64, align 8
  %slot867 = alloca i64, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i32, align 8
  %slot871 = alloca i64, align 8
  %slot872 = alloca i64, align 8
  %slot873 = alloca i32, align 8
  %slot874 = alloca i64, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i32, align 8
  %slot877 = alloca i64, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i64, align 8
  %slot880 = alloca i64, align 8
  %slot881 = alloca i32, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i64, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i32, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i32, align 8
  %slot891 = alloca i64, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i32, align 8
  %slot896 = alloca i32, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i32, align 8
  %slot899 = alloca i64, align 8
  %slot900 = alloca i64, align 8
  %slot901 = alloca i32, align 8
  %slot902 = alloca i32, align 8
  %slot903 = alloca i32, align 8
  %slot904 = alloca i64, align 8
  %slot905 = alloca i64, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i32, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i64, align 8
  %slot911 = alloca i32, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i64, align 8
  %slot914 = alloca i64, align 8
  %slot915 = alloca i64, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i64, align 8
  %slot919 = alloca i32, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i32, align 8
  %slot922 = alloca i32, align 8
  %slot923 = alloca i64, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i32, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i32, align 8
  %slot928 = alloca i32, align 8
  %slot929 = alloca i64, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i32, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i32, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i64, align 8
  %slot937 = alloca i32, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i64, align 8
  %slot941 = alloca i32, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i64, align 8
  %slot947 = alloca i64, align 8
  %slot948 = alloca i32, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i32, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i64, align 8
  %slot955 = alloca i32, align 8
  %slot956 = alloca i64, align 8
  %slot957 = alloca i64, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i32, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i32, align 8
  %slot963 = alloca i32, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i32, align 8
  %slot966 = alloca i32, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i32, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i64, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i64, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i64, align 8
  %slot980 = alloca i32, align 8
  %slot981 = alloca i64, align 8
  %slot982 = alloca i64, align 8
  %slot983 = alloca i32, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i64, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i64, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i64, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i32, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i32, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i64, align 8
  %slot1009 = alloca i32, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i64, align 8
  %slot1012 = alloca i32, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i64, align 8
  %slot1023 = alloca i32, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i32, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i64, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i64, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i32, align 8
  %slot1036 = alloca i32, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i64, align 8
  %slot1039 = alloca i32, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i32, align 8
  %slot1042 = alloca i32, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i32, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i32, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i64, align 8
  %slot1050 = alloca i64, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i32, align 8
  %slot1054 = alloca i32, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i64, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i64, align 8
  %slot1059 = alloca i32, align 8
  %slot1060 = alloca i32, align 8
  %slot1061 = alloca i64, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i64, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i32, align 8
  %slot1068 = alloca i64, align 8
  %slot1069 = alloca i32, align 8
  %slot1070 = alloca i32, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i64, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i64, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %callresult1078 = alloca [16 x i8], align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i32, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i64, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i64, align 8
  %slot1091 = alloca i64, align 8
  %slot1092 = alloca i64, align 8
  %slot1093 = alloca i64, align 8
  %callresult1094 = alloca [24 x i8], align 8
  %slot1095 = alloca i64, align 8
  %slot1096 = alloca i64, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i64, align 8
  %slot1099 = alloca i32, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i64, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i32, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i64, align 8
  %slot1112 = alloca i64, align 8
  %slot1113 = alloca i64, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i32, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i32, align 8
  %slot1118 = alloca i64, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i64, align 8
  %slot1122 = alloca i32, align 8
  %slot1123 = alloca i32, align 8
  %slot1124 = alloca i64, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i64, align 8
  %slot1127 = alloca i64, align 8
  %slot1128 = alloca i32, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i64, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i64, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i32, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i64, align 8
  %slot1141 = alloca i32, align 8
  %slot1142 = alloca i32, align 8
  %slot1143 = alloca i32, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i32, align 8
  %slot1149 = alloca i32, align 8
  %slot1150 = alloca i64, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i32, align 8
  %slot1153 = alloca i32, align 8
  %slot1154 = alloca i32, align 8
  %slot1155 = alloca i32, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i32, align 8
  %slot1158 = alloca i32, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i64, align 8
  %slot1162 = alloca i64, align 8
  %slot1163 = alloca i32, align 8
  %slot1164 = alloca i64, align 8
  %slot1165 = alloca i32, align 8
  %slot1166 = alloca i64, align 8
  %slot1167 = alloca i32, align 8
  %slot1168 = alloca i32, align 8
  %slot1169 = alloca i64, align 8
  %slot1170 = alloca i64, align 8
  %slot1171 = alloca i32, align 8
  %slot1172 = alloca i64, align 8
  %slot1173 = alloca i32, align 8
  %slot1174 = alloca i32, align 8
  %slot1175 = alloca i64, align 8
  %slot1176 = alloca i64, align 8
  %slot1177 = alloca i32, align 8
  %slot1178 = alloca i64, align 8
  %slot1179 = alloca i32, align 8
  %slot1180 = alloca i32, align 8
  %slot1181 = alloca i64, align 8
  %slot1182 = alloca i64, align 8
  %slot1183 = alloca i32, align 8
  %slot1184 = alloca i64, align 8
  %slot1185 = alloca i64, align 8
  %slot1186 = alloca i64, align 8
  %slot1187 = alloca i32, align 8
  %slot1188 = alloca i64, align 8
  %slot1189 = alloca i64, align 8
  %slot1190 = alloca i64, align 8
  %slot1191 = alloca i32, align 8
  %slot1192 = alloca i64, align 8
  %slot1193 = alloca i64, align 8
  %slot1194 = alloca i32, align 8
  %slot1195 = alloca i64, align 8
  %slot1196 = alloca i64, align 8
  %slot1197 = alloca i32, align 8
  %slot1198 = alloca i64, align 8
  %slot1199 = alloca i64, align 8
  %slot1200 = alloca i64, align 8
  %slot1201 = alloca i32, align 8
  %slot1202 = alloca i64, align 8
  %slot1203 = alloca i64, align 8
  %slot1204 = alloca i64, align 8
  %slot1205 = alloca i32, align 8
  %slot1206 = alloca i64, align 8
  %slot1207 = alloca i64, align 8
  %slot1208 = alloca i32, align 8
  %slot1209 = alloca i32, align 8
  %slot1210 = alloca i64, align 8
  %slot1211 = alloca i32, align 8
  %slot1212 = alloca i32, align 8
  %slot1213 = alloca i64, align 8
  %slot1214 = alloca i64, align 8
  %slot1215 = alloca i32, align 8
  %slot1216 = alloca i64, align 8
  %slot1217 = alloca i64, align 8
  %slot1218 = alloca i64, align 8
  %slot1219 = alloca i32, align 8
  %slot1220 = alloca i64, align 8
  %slot1221 = alloca i64, align 8
  %slot1222 = alloca i64, align 8
  %slot1223 = alloca i32, align 8
  %slot1224 = alloca i64, align 8
  %slot1225 = alloca i64, align 8
  %slot1226 = alloca i32, align 8
  %slot1227 = alloca i64, align 8
  %slot1228 = alloca i64, align 8
  %slot1229 = alloca i32, align 8
  %slot1230 = alloca i64, align 8
  %slot1231 = alloca i64, align 8
  %slot1232 = alloca i64, align 8
  %slot1233 = alloca i32, align 8
  %slot1234 = alloca i64, align 8
  %slot1235 = alloca i64, align 8
  %slot1236 = alloca i64, align 8
  %slot1237 = alloca i32, align 8
  %slot1238 = alloca i64, align 8
  %slot1239 = alloca i64, align 8
  %slot1240 = alloca i32, align 8
  %slot1241 = alloca i32, align 8
  %slot1242 = alloca i64, align 8
  %slot1243 = alloca i32, align 8
  %slot1244 = alloca i32, align 8
  %slot1245 = alloca i64, align 8
  %slot1246 = alloca i64, align 8
  %slot1247 = alloca i32, align 8
  %slot1248 = alloca i64, align 8
  %slot1249 = alloca i64, align 8
  %slot1250 = alloca i64, align 8
  %slot1251 = alloca i32, align 8
  %slot1252 = alloca i64, align 8
  %slot1253 = alloca i64, align 8
  %slot1254 = alloca i64, align 8
  %slot1255 = alloca i32, align 8
  %slot1256 = alloca i64, align 8
  %slot1257 = alloca i64, align 8
  %slot1258 = alloca i32, align 8
  %slot1259 = alloca i64, align 8
  %slot1260 = alloca i64, align 8
  %slot1261 = alloca i32, align 8
  %slot1262 = alloca i64, align 8
  %slot1263 = alloca i64, align 8
  %slot1264 = alloca i64, align 8
  %slot1265 = alloca i32, align 8
  %slot1266 = alloca i64, align 8
  %slot1267 = alloca i64, align 8
  %slot1268 = alloca i64, align 8
  %slot1269 = alloca i32, align 8
  %slot1270 = alloca i64, align 8
  %slot1271 = alloca i64, align 8
  %slot1272 = alloca i32, align 8
  %slot1273 = alloca i32, align 8
  %slot1274 = alloca i64, align 8
  %slot1275 = alloca i32, align 8
  %slot1276 = alloca i32, align 8
  %slot1277 = alloca i64, align 8
  %slot1278 = alloca i64, align 8
  %slot1279 = alloca i32, align 8
  %slot1280 = alloca i64, align 8
  %slot1281 = alloca i32, align 8
  %slot1282 = alloca i32, align 8
  %slot1283 = alloca i64, align 8
  %slot1284 = alloca i64, align 8
  %slot1285 = alloca i32, align 8
  %slot1286 = alloca i64, align 8
  %slot1287 = alloca i32, align 8
  %slot1288 = alloca i32, align 8
  %slot1289 = alloca i64, align 8
  %slot1290 = alloca i64, align 8
  %slot1291 = alloca i32, align 8
  %slot1292 = alloca i64, align 8
  %slot1293 = alloca i32, align 8
  %slot1294 = alloca i32, align 8
  %slot1295 = alloca i64, align 8
  %slot1296 = alloca i64, align 8
  %slot1297 = alloca i32, align 8
  %slot1298 = alloca i64, align 8
  %slot1299 = alloca i32, align 8
  %slot1300 = alloca i32, align 8
  %slot1301 = alloca i64, align 8
  %slot1302 = alloca i64, align 8
  %slot1303 = alloca i32, align 8
  %slot1304 = alloca i64, align 8
  %slot1305 = alloca i32, align 8
  %slot1306 = alloca i32, align 8
  %slot1307 = alloca i64, align 8
  %slot1308 = alloca i64, align 8
  %slot1309 = alloca i64, align 8
  %slot1310 = alloca i64, align 8
  %slot1311 = alloca i64, align 8
  %slot1312 = alloca i64, align 8
  %slot1313 = alloca i64, align 8
  %slot1314 = alloca i64, align 8
  %slot1315 = alloca i64, align 8
  %slot1316 = alloca i64, align 8
  %slot1317 = alloca i64, align 8
  %slot1318 = alloca i64, align 8
  %slot1319 = alloca i64, align 8
  %slot1320 = alloca i32, align 8
  %slot1321 = alloca i64, align 8
  %slot1322 = alloca i64, align 8
  %slot1323 = alloca i64, align 8
  %slot1324 = alloca i32, align 8
  %slot1325 = alloca i32, align 8
  %slot1326 = alloca i32, align 8
  %slot1327 = alloca i32, align 8
  %slot1328 = alloca i64, align 8
  %slot1329 = alloca i64, align 8
  %slot1330 = alloca i64, align 8
  %slot1331 = alloca i64, align 8
  %slot1332 = alloca i32, align 8
  %slot1333 = alloca i32, align 8
  %slot1334 = alloca i32, align 8
  %slot1335 = alloca i64, align 8
  %slot1336 = alloca i64, align 8
  %slot1337 = alloca i32, align 8
  %slot1338 = alloca i64, align 8
  %slot1339 = alloca i64, align 8
  %slot1340 = alloca i64, align 8
  %slot1341 = alloca i32, align 8
  %slot1342 = alloca i32, align 8
  %slot1343 = alloca i32, align 8
  %slot1344 = alloca i32, align 8
  %slot1345 = alloca i32, align 8
  %slot1346 = alloca i32, align 8
  %slot1347 = alloca i32, align 8
  %slot1348 = alloca i64, align 8
  %slot1349 = alloca i64, align 8
  %slot1350 = alloca i64, align 8
  %slot1351 = alloca i32, align 8
  %slot1352 = alloca i64, align 8
  %slot1353 = alloca i64, align 8
  %slot1354 = alloca i64, align 8
  %slot1355 = alloca i32, align 8
  %slot1356 = alloca i64, align 8
  %slot1357 = alloca i64, align 8
  %slot1358 = alloca i64, align 8
  %slot1359 = alloca i32, align 8
  %slot1360 = alloca i32, align 8
  %slot1361 = alloca i32, align 8
  %slot1362 = alloca i64, align 8
  %slot1363 = alloca i32, align 8
  %slot1364 = alloca i32, align 8
  %slot1365 = alloca i64, align 8
  %slot1366 = alloca i64, align 8
  %slot1367 = alloca i32, align 8
  %slot1368 = alloca i64, align 8
  %slot1369 = alloca i64, align 8
  %slot1370 = alloca i64, align 8
  %slot1371 = alloca i32, align 8
  %slot1372 = alloca i64, align 8
  %slot1373 = alloca i64, align 8
  %slot1374 = alloca i64, align 8
  %slot1375 = alloca i32, align 8
  %slot1376 = alloca i64, align 8
  %slot1377 = alloca i64, align 8
  %slot1378 = alloca i32, align 8
  %slot1379 = alloca i64, align 8
  %slot1380 = alloca i64, align 8
  %slot1381 = alloca i32, align 8
  %slot1382 = alloca i64, align 8
  %slot1383 = alloca i64, align 8
  %slot1384 = alloca i64, align 8
  %slot1385 = alloca i32, align 8
  %slot1386 = alloca i64, align 8
  %slot1387 = alloca i64, align 8
  %slot1388 = alloca i64, align 8
  %slot1389 = alloca i32, align 8
  %slot1390 = alloca i64, align 8
  %slot1391 = alloca i64, align 8
  %slot1392 = alloca i32, align 8
  %slot1393 = alloca i32, align 8
  %slot1394 = alloca i64, align 8
  %slot1395 = alloca i32, align 8
  %slot1396 = alloca i32, align 8
  %slot1397 = alloca i64, align 8
  %slot1398 = alloca i64, align 8
  %slot1399 = alloca i32, align 8
  %slot1400 = alloca i64, align 8
  %slot1401 = alloca i64, align 8
  %slot1402 = alloca i64, align 8
  %slot1403 = alloca i32, align 8
  %slot1404 = alloca i64, align 8
  %slot1405 = alloca i64, align 8
  %slot1406 = alloca i64, align 8
  %slot1407 = alloca i32, align 8
  %slot1408 = alloca i64, align 8
  %slot1409 = alloca i64, align 8
  %slot1410 = alloca i32, align 8
  %slot1411 = alloca i64, align 8
  %slot1412 = alloca i64, align 8
  %slot1413 = alloca i32, align 8
  %slot1414 = alloca i64, align 8
  %slot1415 = alloca i64, align 8
  %slot1416 = alloca i64, align 8
  %slot1417 = alloca i32, align 8
  %slot1418 = alloca i64, align 8
  %slot1419 = alloca i64, align 8
  %slot1420 = alloca i64, align 8
  %slot1421 = alloca i32, align 8
  %slot1422 = alloca i64, align 8
  %slot1423 = alloca i64, align 8
  %slot1424 = alloca i32, align 8
  %slot1425 = alloca i64, align 8
  %slot1426 = alloca i64, align 8
  %slot1427 = alloca i32, align 8
  %slot1428 = alloca i64, align 8
  %slot1429 = alloca i64, align 8
  %slot1430 = alloca i64, align 8
  %slot1431 = alloca i64, align 8
  %slot1432 = alloca i64, align 8
  %slot1433 = alloca i64, align 8
  %slot1434 = alloca i64, align 8
  %slot1435 = alloca i64, align 8
  %slot1436 = alloca i32, align 8
  %slot1437 = alloca i64, align 8
  %slot1438 = alloca i64, align 8
  %slot1439 = alloca i64, align 8
  %slot1440 = alloca i32, align 8
  %slot1441 = alloca i32, align 8
  %slot1442 = alloca i32, align 8
  %slot1443 = alloca i32, align 8
  %slot1444 = alloca i64, align 8
  %slot1445 = alloca i64, align 8
  %slot1446 = alloca i64, align 8
  %slot1447 = alloca i64, align 8
  %slot1448 = alloca i32, align 8
  %slot1449 = alloca i32, align 8
  %slot1450 = alloca i32, align 8
  %slot1451 = alloca i64, align 8
  %slot1452 = alloca i64, align 8
  %slot1453 = alloca i32, align 8
  %slot1454 = alloca i64, align 8
  %slot1455 = alloca i64, align 8
  %slot1456 = alloca i64, align 8
  %slot1457 = alloca i32, align 8
  %slot1458 = alloca i32, align 8
  %slot1459 = alloca i32, align 8
  %slot1460 = alloca i32, align 8
  %slot1461 = alloca i32, align 8
  %slot1462 = alloca i32, align 8
  %slot1463 = alloca i32, align 8
  %slot1464 = alloca i64, align 8
  %slot1465 = alloca i64, align 8
  %slot1466 = alloca i64, align 8
  %slot1467 = alloca i32, align 8
  %slot1468 = alloca i64, align 8
  %slot1469 = alloca i64, align 8
  %slot1470 = alloca i64, align 8
  %slot1471 = alloca i32, align 8
  %slot1472 = alloca i64, align 8
  %slot1473 = alloca i64, align 8
  %slot1474 = alloca i64, align 8
  %slot1475 = alloca i32, align 8
  %slot1476 = alloca i32, align 8
  %slot1477 = alloca i32, align 8
  %slot1478 = alloca i64, align 8
  %slot1479 = alloca i32, align 8
  %slot1480 = alloca i32, align 8
  %slot1481 = alloca i64, align 8
  %slot1482 = alloca i64, align 8
  %slot1483 = alloca i32, align 8
  %slot1484 = alloca i64, align 8
  %slot1485 = alloca i64, align 8
  %slot1486 = alloca i64, align 8
  %slot1487 = alloca i32, align 8
  %slot1488 = alloca i64, align 8
  %slot1489 = alloca i64, align 8
  %slot1490 = alloca i64, align 8
  %slot1491 = alloca i32, align 8
  %slot1492 = alloca i64, align 8
  %slot1493 = alloca i64, align 8
  %slot1494 = alloca i32, align 8
  %slot1495 = alloca i64, align 8
  %slot1496 = alloca i64, align 8
  %slot1497 = alloca i32, align 8
  %slot1498 = alloca i64, align 8
  %slot1499 = alloca i64, align 8
  %slot1500 = alloca i64, align 8
  %slot1501 = alloca i32, align 8
  %slot1502 = alloca i64, align 8
  %slot1503 = alloca i64, align 8
  %slot1504 = alloca i64, align 8
  %slot1505 = alloca i32, align 8
  %slot1506 = alloca i64, align 8
  %slot1507 = alloca i64, align 8
  %slot1508 = alloca i32, align 8
  %slot1509 = alloca i32, align 8
  %slot1510 = alloca i64, align 8
  %slot1511 = alloca i32, align 8
  %slot1512 = alloca i32, align 8
  %slot1513 = alloca i64, align 8
  %slot1514 = alloca i64, align 8
  %slot1515 = alloca i32, align 8
  %slot1516 = alloca i64, align 8
  %slot1517 = alloca i64, align 8
  %slot1518 = alloca i64, align 8
  %slot1519 = alloca i32, align 8
  %slot1520 = alloca i64, align 8
  %slot1521 = alloca i64, align 8
  %slot1522 = alloca i64, align 8
  %slot1523 = alloca i32, align 8
  %slot1524 = alloca i64, align 8
  %slot1525 = alloca i64, align 8
  %slot1526 = alloca i32, align 8
  %slot1527 = alloca i64, align 8
  %slot1528 = alloca i64, align 8
  %slot1529 = alloca i32, align 8
  %slot1530 = alloca i64, align 8
  %slot1531 = alloca i64, align 8
  %slot1532 = alloca i64, align 8
  %slot1533 = alloca i32, align 8
  %slot1534 = alloca i64, align 8
  %slot1535 = alloca i64, align 8
  %slot1536 = alloca i64, align 8
  %slot1537 = alloca i32, align 8
  %slot1538 = alloca i64, align 8
  %slot1539 = alloca i64, align 8
  %slot1540 = alloca i32, align 8
  %slot1541 = alloca i64, align 8
  %slot1542 = alloca i64, align 8
  %slot1543 = alloca i32, align 8
  %slot1544 = alloca i64, align 8
  %slot1545 = alloca i64, align 8
  %slot1546 = alloca i64, align 8
  %slot1547 = alloca i64, align 8
  %slot1548 = alloca i64, align 8
  %slot1549 = alloca i64, align 8
  %slot1550 = alloca i32, align 8
  %slot1551 = alloca i64, align 8
  %slot1552 = alloca i64, align 8
  %slot1553 = alloca i32, align 8
  %slot1554 = alloca i32, align 8
  %slot1555 = alloca i32, align 8
  %slot1556 = alloca i32, align 8
  %slot1557 = alloca i64, align 8
  %slot1558 = alloca i64, align 8
  %slot1559 = alloca i64, align 8
  %slot1560 = alloca i64, align 8
  %slot1561 = alloca i32, align 8
  %slot1562 = alloca i64, align 8
  %slot1563 = alloca i64, align 8
  %slot1564 = alloca i64, align 8
  %slot1565 = alloca i32, align 8
  %slot1566 = alloca i64, align 8
  %slot1567 = alloca i64, align 8
  %slot1568 = alloca i64, align 8
  %slot1569 = alloca i32, align 8
  %slot1570 = alloca i32, align 8
  %slot1571 = alloca i64, align 8
  %slot1572 = alloca i32, align 8
  %slot1573 = alloca i32, align 8
  %slot1574 = alloca i32, align 8
  %slot1575 = alloca i32, align 8
  %slot1576 = alloca i32, align 8
  %slot1577 = alloca i64, align 8
  %slot1578 = alloca i32, align 8
  %slot1579 = alloca i32, align 8
  %slot1580 = alloca i64, align 8
  %slot1581 = alloca i64, align 8
  %slot1582 = alloca i32, align 8
  %slot1583 = alloca i64, align 8
  %slot1584 = alloca i64, align 8
  %slot1585 = alloca i64, align 8
  %slot1586 = alloca i32, align 8
  %slot1587 = alloca i64, align 8
  %slot1588 = alloca i64, align 8
  %slot1589 = alloca i64, align 8
  %slot1590 = alloca i32, align 8
  %slot1591 = alloca i64, align 8
  %slot1592 = alloca i64, align 8
  %slot1593 = alloca i32, align 8
  %slot1594 = alloca i64, align 8
  %slot1595 = alloca i64, align 8
  %slot1596 = alloca i32, align 8
  %slot1597 = alloca i64, align 8
  %slot1598 = alloca i64, align 8
  %slot1599 = alloca i64, align 8
  %slot1600 = alloca i32, align 8
  %slot1601 = alloca i64, align 8
  %slot1602 = alloca i64, align 8
  %slot1603 = alloca i64, align 8
  %slot1604 = alloca i32, align 8
  %slot1605 = alloca i64, align 8
  %slot1606 = alloca i64, align 8
  %slot1607 = alloca i32, align 8
  %slot1608 = alloca i64, align 8
  %slot1609 = alloca i64, align 8
  %slot1610 = alloca i32, align 8
  %slot1611 = alloca i64, align 8
  %slot1612 = alloca i64, align 8
  %slot1613 = alloca i64, align 8
  %slot1614 = alloca i32, align 8
  %slot1615 = alloca i64, align 8
  %slot1616 = alloca i64, align 8
  %slot1617 = alloca i32, align 8
  %slot1618 = alloca i32, align 8
  %slot1619 = alloca i64, align 8
  %slot1620 = alloca i64, align 8
  %slot1621 = alloca i64, align 8
  %slot1622 = alloca i64, align 8
  %slot1623 = alloca i32, align 8
  %slot1624 = alloca i32, align 8
  %slot1625 = alloca i64, align 8
  %slot1626 = alloca i32, align 8
  %slot1627 = alloca i32, align 8
  %slot1628 = alloca i64, align 8
  %slot1629 = alloca i64, align 8
  %slot1630 = alloca i32, align 8
  %slot1631 = alloca i64, align 8
  %slot1632 = alloca i64, align 8
  %slot1633 = alloca i64, align 8
  %slot1634 = alloca i32, align 8
  %slot1635 = alloca i64, align 8
  %slot1636 = alloca i64, align 8
  %slot1637 = alloca i64, align 8
  %slot1638 = alloca i32, align 8
  %slot1639 = alloca i64, align 8
  %slot1640 = alloca i64, align 8
  %slot1641 = alloca i32, align 8
  %slot1642 = alloca i64, align 8
  %slot1643 = alloca i64, align 8
  %slot1644 = alloca i32, align 8
  %slot1645 = alloca i64, align 8
  %slot1646 = alloca i64, align 8
  %slot1647 = alloca i64, align 8
  %slot1648 = alloca i32, align 8
  %slot1649 = alloca i64, align 8
  %slot1650 = alloca i64, align 8
  %slot1651 = alloca i64, align 8
  %slot1652 = alloca i32, align 8
  %slot1653 = alloca i64, align 8
  %slot1654 = alloca i64, align 8
  %slot1655 = alloca i32, align 8
  %slot1656 = alloca i64, align 8
  %slot1657 = alloca i64, align 8
  %slot1658 = alloca i64, align 8
  %slot1659 = alloca i64, align 8
  %slot1660 = alloca i64, align 8
  %slot1661 = alloca i64, align 8
  %slot1662 = alloca i64, align 8
  %slot1663 = alloca i64, align 8
  %slot1664 = alloca i32, align 8
  %slot1665 = alloca i64, align 8
  %slot1666 = alloca i64, align 8
  %slot1667 = alloca i32, align 8
  %slot1668 = alloca i32, align 8
  %slot1669 = alloca i32, align 8
  %slot1670 = alloca i32, align 8
  %slot1671 = alloca i64, align 8
  %slot1672 = alloca i64, align 8
  %slot1673 = alloca i64, align 8
  %slot1674 = alloca i64, align 8
  %slot1675 = alloca i32, align 8
  %slot1676 = alloca i64, align 8
  %slot1677 = alloca i64, align 8
  %slot1678 = alloca i64, align 8
  %slot1679 = alloca i32, align 8
  %slot1680 = alloca i64, align 8
  %slot1681 = alloca i64, align 8
  %slot1682 = alloca i64, align 8
  %slot1683 = alloca i32, align 8
  %slot1684 = alloca i32, align 8
  %slot1685 = alloca i64, align 8
  %slot1686 = alloca i32, align 8
  %slot1687 = alloca i32, align 8
  %slot1688 = alloca i32, align 8
  %slot1689 = alloca i32, align 8
  %slot1690 = alloca i32, align 8
  %slot1691 = alloca i64, align 8
  %slot1692 = alloca i32, align 8
  %slot1693 = alloca i32, align 8
  %slot1694 = alloca i64, align 8
  %slot1695 = alloca i64, align 8
  %slot1696 = alloca i32, align 8
  %slot1697 = alloca i64, align 8
  %slot1698 = alloca i64, align 8
  %slot1699 = alloca i64, align 8
  %slot1700 = alloca i32, align 8
  %slot1701 = alloca i64, align 8
  %slot1702 = alloca i64, align 8
  %slot1703 = alloca i64, align 8
  %slot1704 = alloca i32, align 8
  %slot1705 = alloca i64, align 8
  %slot1706 = alloca i64, align 8
  %slot1707 = alloca i32, align 8
  %slot1708 = alloca i64, align 8
  %slot1709 = alloca i64, align 8
  %slot1710 = alloca i32, align 8
  %slot1711 = alloca i64, align 8
  %slot1712 = alloca i64, align 8
  %slot1713 = alloca i64, align 8
  %slot1714 = alloca i32, align 8
  %slot1715 = alloca i64, align 8
  %slot1716 = alloca i64, align 8
  %slot1717 = alloca i64, align 8
  %slot1718 = alloca i32, align 8
  %slot1719 = alloca i64, align 8
  %slot1720 = alloca i64, align 8
  %slot1721 = alloca i32, align 8
  %slot1722 = alloca i64, align 8
  %slot1723 = alloca i64, align 8
  %slot1724 = alloca i32, align 8
  %slot1725 = alloca i64, align 8
  %slot1726 = alloca i64, align 8
  %slot1727 = alloca i64, align 8
  %slot1728 = alloca i32, align 8
  %slot1729 = alloca i64, align 8
  %slot1730 = alloca i64, align 8
  %slot1731 = alloca i32, align 8
  %slot1732 = alloca i32, align 8
  %slot1733 = alloca i64, align 8
  %slot1734 = alloca i64, align 8
  %slot1735 = alloca i64, align 8
  %slot1736 = alloca i64, align 8
  %slot1737 = alloca i32, align 8
  %slot1738 = alloca i32, align 8
  %slot1739 = alloca i64, align 8
  %slot1740 = alloca i32, align 8
  %slot1741 = alloca i32, align 8
  %slot1742 = alloca i64, align 8
  %slot1743 = alloca i64, align 8
  %slot1744 = alloca i32, align 8
  %slot1745 = alloca i64, align 8
  %slot1746 = alloca i64, align 8
  %slot1747 = alloca i64, align 8
  %slot1748 = alloca i32, align 8
  %slot1749 = alloca i64, align 8
  %slot1750 = alloca i64, align 8
  %slot1751 = alloca i64, align 8
  %slot1752 = alloca i32, align 8
  %slot1753 = alloca i64, align 8
  %slot1754 = alloca i64, align 8
  %slot1755 = alloca i32, align 8
  %slot1756 = alloca i64, align 8
  %slot1757 = alloca i64, align 8
  %slot1758 = alloca i32, align 8
  %slot1759 = alloca i64, align 8
  %slot1760 = alloca i64, align 8
  %slot1761 = alloca i64, align 8
  %slot1762 = alloca i32, align 8
  %slot1763 = alloca i64, align 8
  %slot1764 = alloca i64, align 8
  %slot1765 = alloca i64, align 8
  %slot1766 = alloca i32, align 8
  %slot1767 = alloca i64, align 8
  %slot1768 = alloca i64, align 8
  %slot1769 = alloca i32, align 8
  %slot1770 = alloca i64, align 8
  %slot1771 = alloca i64, align 8
  %slot1772 = alloca i64, align 8
  %slot1773 = alloca i64, align 8
  %slot1774 = alloca i64, align 8
  %slot1775 = alloca i64, align 8
  %slot1776 = alloca i32, align 8
  %slot1777 = alloca i64, align 8
  %slot1778 = alloca i64, align 8
  %slot1779 = alloca i32, align 8
  %slot1780 = alloca i32, align 8
  %slot1781 = alloca i32, align 8
  %slot1782 = alloca i32, align 8
  %slot1783 = alloca i64, align 8
  %slot1784 = alloca i64, align 8
  %slot1785 = alloca i64, align 8
  %slot1786 = alloca i64, align 8
  %slot1787 = alloca i32, align 8
  %slot1788 = alloca i64, align 8
  %slot1789 = alloca i64, align 8
  %slot1790 = alloca i64, align 8
  %slot1791 = alloca i32, align 8
  %slot1792 = alloca i64, align 8
  %slot1793 = alloca i64, align 8
  %slot1794 = alloca i64, align 8
  %slot1795 = alloca i32, align 8
  %slot1796 = alloca i32, align 8
  %slot1797 = alloca i64, align 8
  %slot1798 = alloca i32, align 8
  %slot1799 = alloca i32, align 8
  %slot1800 = alloca i32, align 8
  %slot1801 = alloca i32, align 8
  %slot1802 = alloca i32, align 8
  %slot1803 = alloca i64, align 8
  %slot1804 = alloca i32, align 8
  %slot1805 = alloca i32, align 8
  %slot1806 = alloca i64, align 8
  %slot1807 = alloca i64, align 8
  %slot1808 = alloca i32, align 8
  %slot1809 = alloca i64, align 8
  %slot1810 = alloca i64, align 8
  %slot1811 = alloca i64, align 8
  %slot1812 = alloca i32, align 8
  %slot1813 = alloca i64, align 8
  %slot1814 = alloca i64, align 8
  %slot1815 = alloca i64, align 8
  %slot1816 = alloca i32, align 8
  %slot1817 = alloca i64, align 8
  %slot1818 = alloca i64, align 8
  %slot1819 = alloca i32, align 8
  %slot1820 = alloca i64, align 8
  %slot1821 = alloca i64, align 8
  %slot1822 = alloca i32, align 8
  %slot1823 = alloca i64, align 8
  %slot1824 = alloca i64, align 8
  %slot1825 = alloca i64, align 8
  %slot1826 = alloca i32, align 8
  %slot1827 = alloca i64, align 8
  %slot1828 = alloca i64, align 8
  %slot1829 = alloca i64, align 8
  %slot1830 = alloca i32, align 8
  %slot1831 = alloca i64, align 8
  %slot1832 = alloca i64, align 8
  %slot1833 = alloca i32, align 8
  %slot1834 = alloca i64, align 8
  %slot1835 = alloca i64, align 8
  %slot1836 = alloca i32, align 8
  %slot1837 = alloca i64, align 8
  %slot1838 = alloca i64, align 8
  %slot1839 = alloca i64, align 8
  %slot1840 = alloca i32, align 8
  %slot1841 = alloca i64, align 8
  %slot1842 = alloca i64, align 8
  %slot1843 = alloca i32, align 8
  %slot1844 = alloca i32, align 8
  %slot1845 = alloca i64, align 8
  %slot1846 = alloca i64, align 8
  %slot1847 = alloca i64, align 8
  %slot1848 = alloca i64, align 8
  %slot1849 = alloca i32, align 8
  %slot1850 = alloca i32, align 8
  %slot1851 = alloca i64, align 8
  %slot1852 = alloca i32, align 8
  %slot1853 = alloca i32, align 8
  %slot1854 = alloca i64, align 8
  %slot1855 = alloca i64, align 8
  %slot1856 = alloca i32, align 8
  %slot1857 = alloca i64, align 8
  %slot1858 = alloca i64, align 8
  %slot1859 = alloca i64, align 8
  %slot1860 = alloca i32, align 8
  %slot1861 = alloca i64, align 8
  %slot1862 = alloca i64, align 8
  %slot1863 = alloca i64, align 8
  %slot1864 = alloca i32, align 8
  %slot1865 = alloca i64, align 8
  %slot1866 = alloca i64, align 8
  %slot1867 = alloca i32, align 8
  %slot1868 = alloca i64, align 8
  %slot1869 = alloca i64, align 8
  %slot1870 = alloca i32, align 8
  %slot1871 = alloca i64, align 8
  %slot1872 = alloca i64, align 8
  %slot1873 = alloca i64, align 8
  %slot1874 = alloca i32, align 8
  %slot1875 = alloca i64, align 8
  %slot1876 = alloca i64, align 8
  %slot1877 = alloca i64, align 8
  %slot1878 = alloca i32, align 8
  %slot1879 = alloca i64, align 8
  %slot1880 = alloca i64, align 8
  %slot1881 = alloca i32, align 8
  %slot1882 = alloca i64, align 8
  %slot1883 = alloca i64, align 8
  %slot1884 = alloca i64, align 8
  %slot1885 = alloca i64, align 8
  %slot1886 = alloca i64, align 8
  %slot1887 = alloca i64, align 8
  %slot1888 = alloca i64, align 8
  %slot1889 = alloca i32, align 8
  %slot1890 = alloca i64, align 8
  %slot1891 = alloca i32, align 8
  %slot1892 = alloca i32, align 8
  %slot1893 = alloca i64, align 8
  %slot1894 = alloca i64, align 8
  %slot1895 = alloca i32, align 8
  %slot1896 = alloca i64, align 8
  %slot1897 = alloca i64, align 8
  %slot1898 = alloca i64, align 8
  %slot1899 = alloca i32, align 8
  %slot1900 = alloca i64, align 8
  %slot1901 = alloca i64, align 8
  %slot1902 = alloca i64, align 8
  %slot1903 = alloca i32, align 8
  %slot1904 = alloca i64, align 8
  %slot1905 = alloca i64, align 8
  %slot1906 = alloca i32, align 8
  %slot1907 = alloca i64, align 8
  %slot1908 = alloca i64, align 8
  %slot1909 = alloca i32, align 8
  %slot1910 = alloca i64, align 8
  %slot1911 = alloca i64, align 8
  %slot1912 = alloca i64, align 8
  %slot1913 = alloca i32, align 8
  %slot1914 = alloca i64, align 8
  %slot1915 = alloca i64, align 8
  %slot1916 = alloca i64, align 8
  %slot1917 = alloca i32, align 8
  %slot1918 = alloca i64, align 8
  %slot1919 = alloca i64, align 8
  %slot1920 = alloca i32, align 8
  %slot1921 = alloca i64, align 8
  %slot1922 = alloca i64, align 8
  %slot1923 = alloca i32, align 8
  %slot1924 = alloca i64, align 8
  %slot1925 = alloca i64, align 8
  %slot1926 = alloca i64, align 8
  %slot1927 = alloca i32, align 8
  %slot1928 = alloca i32, align 8
  %slot1929 = alloca i32, align 8
  %slot1930 = alloca i32, align 8
  %slot1931 = alloca i64, align 8
  %slot1932 = alloca i64, align 8
  %slot1933 = alloca i64, align 8
  %slot1934 = alloca i64, align 8
  %slot1935 = alloca i32, align 8
  %slot1936 = alloca i32, align 8
  %slot1937 = alloca i32, align 8
  %slot1938 = alloca i64, align 8
  %slot1939 = alloca i64, align 8
  %slot1940 = alloca i32, align 8
  %slot1941 = alloca i64, align 8
  %slot1942 = alloca i64, align 8
  %slot1943 = alloca i64, align 8
  %slot1944 = alloca i32, align 8
  %slot1945 = alloca i32, align 8
  %slot1946 = alloca i32, align 8
  %slot1947 = alloca i32, align 8
  %slot1948 = alloca i32, align 8
  %slot1949 = alloca i32, align 8
  %slot1950 = alloca i32, align 8
  %slot1951 = alloca i64, align 8
  %slot1952 = alloca i64, align 8
  %slot1953 = alloca i64, align 8
  %slot1954 = alloca i32, align 8
  %slot1955 = alloca i64, align 8
  %slot1956 = alloca i64, align 8
  %slot1957 = alloca i64, align 8
  %slot1958 = alloca i32, align 8
  %slot1959 = alloca i64, align 8
  %slot1960 = alloca i64, align 8
  %slot1961 = alloca i64, align 8
  %slot1962 = alloca i32, align 8
  %slot1963 = alloca i32, align 8
  %slot1964 = alloca i32, align 8
  %slot1965 = alloca i64, align 8
  %slot1966 = alloca i32, align 8
  %slot1967 = alloca i32, align 8
  %slot1968 = alloca i64, align 8
  %slot1969 = alloca i64, align 8
  %slot1970 = alloca i32, align 8
  %slot1971 = alloca i64, align 8
  %slot1972 = alloca i64, align 8
  %slot1973 = alloca i64, align 8
  %slot1974 = alloca i32, align 8
  %slot1975 = alloca i64, align 8
  %slot1976 = alloca i64, align 8
  %slot1977 = alloca i64, align 8
  %slot1978 = alloca i32, align 8
  %slot1979 = alloca i64, align 8
  %slot1980 = alloca i64, align 8
  %slot1981 = alloca i32, align 8
  %slot1982 = alloca i64, align 8
  %slot1983 = alloca i64, align 8
  %slot1984 = alloca i32, align 8
  %slot1985 = alloca i64, align 8
  %slot1986 = alloca i64, align 8
  %slot1987 = alloca i64, align 8
  %slot1988 = alloca i32, align 8
  %slot1989 = alloca i64, align 8
  %slot1990 = alloca i64, align 8
  %slot1991 = alloca i64, align 8
  %slot1992 = alloca i32, align 8
  %slot1993 = alloca i64, align 8
  %slot1994 = alloca i64, align 8
  %slot1995 = alloca i32, align 8
  %slot1996 = alloca i32, align 8
  %slot1997 = alloca i64, align 8
  %slot1998 = alloca i32, align 8
  %slot1999 = alloca i32, align 8
  %slot2000 = alloca i64, align 8
  %slot2001 = alloca i64, align 8
  %slot2002 = alloca i32, align 8
  %slot2003 = alloca i64, align 8
  %slot2004 = alloca i64, align 8
  %slot2005 = alloca i64, align 8
  %slot2006 = alloca i32, align 8
  %slot2007 = alloca i64, align 8
  %slot2008 = alloca i64, align 8
  %slot2009 = alloca i64, align 8
  %slot2010 = alloca i32, align 8
  %slot2011 = alloca i64, align 8
  %slot2012 = alloca i64, align 8
  %slot2013 = alloca i32, align 8
  %slot2014 = alloca i64, align 8
  %slot2015 = alloca i64, align 8
  %slot2016 = alloca i32, align 8
  %slot2017 = alloca i64, align 8
  %slot2018 = alloca i64, align 8
  %slot2019 = alloca i64, align 8
  %slot2020 = alloca i32, align 8
  %slot2021 = alloca i64, align 8
  %slot2022 = alloca i64, align 8
  %slot2023 = alloca i64, align 8
  %slot2024 = alloca i32, align 8
  %slot2025 = alloca i64, align 8
  %slot2026 = alloca i64, align 8
  %slot2027 = alloca i32, align 8
  %slot2028 = alloca i64, align 8
  %slot2029 = alloca i64, align 8
  %slot2030 = alloca i32, align 8
  %slot2031 = alloca i32, align 8
  %slot2032 = alloca i64, align 8
  %slot2033 = alloca i32, align 8
  %slot2034 = alloca i32, align 8
  %slot2035 = alloca i64, align 8
  %slot2036 = alloca i64, align 8
  %slot2037 = alloca i32, align 8
  %slot2038 = alloca i64, align 8
  %slot2039 = alloca i64, align 8
  %slot2040 = alloca i64, align 8
  %slot2041 = alloca i32, align 8
  %slot2042 = alloca i64, align 8
  %slot2043 = alloca i64, align 8
  %slot2044 = alloca i64, align 8
  %slot2045 = alloca i32, align 8
  %slot2046 = alloca i64, align 8
  %slot2047 = alloca i64, align 8
  %slot2048 = alloca i32, align 8
  %slot2049 = alloca i64, align 8
  %slot2050 = alloca i64, align 8
  %slot2051 = alloca i32, align 8
  %slot2052 = alloca i64, align 8
  %slot2053 = alloca i64, align 8
  %slot2054 = alloca i64, align 8
  %slot2055 = alloca i32, align 8
  %slot2056 = alloca i64, align 8
  %slot2057 = alloca i64, align 8
  %slot2058 = alloca i64, align 8
  %slot2059 = alloca i32, align 8
  %slot2060 = alloca i64, align 8
  %slot2061 = alloca i64, align 8
  %slot2062 = alloca i32, align 8
  %slot2063 = alloca i32, align 8
  %slot2064 = alloca i64, align 8
  %slot2065 = alloca i32, align 8
  %slot2066 = alloca i32, align 8
  %slot2067 = alloca i64, align 8
  %slot2068 = alloca i64, align 8
  %slot2069 = alloca i32, align 8
  %slot2070 = alloca i64, align 8
  %slot2071 = alloca i64, align 8
  %slot2072 = alloca i64, align 8
  %slot2073 = alloca i32, align 8
  %slot2074 = alloca i64, align 8
  %slot2075 = alloca i64, align 8
  %slot2076 = alloca i64, align 8
  %slot2077 = alloca i32, align 8
  %slot2078 = alloca i64, align 8
  %slot2079 = alloca i64, align 8
  %slot2080 = alloca i32, align 8
  %slot2081 = alloca i64, align 8
  %slot2082 = alloca i64, align 8
  %slot2083 = alloca i32, align 8
  %slot2084 = alloca i64, align 8
  %slot2085 = alloca i64, align 8
  %slot2086 = alloca i64, align 8
  %slot2087 = alloca i32, align 8
  %slot2088 = alloca i64, align 8
  %slot2089 = alloca i64, align 8
  %slot2090 = alloca i64, align 8
  %slot2091 = alloca i32, align 8
  %slot2092 = alloca i64, align 8
  %slot2093 = alloca i64, align 8
  %slot2094 = alloca i32, align 8
  %slot2095 = alloca i64, align 8
  %slot2096 = alloca i64, align 8
  %slot2097 = alloca i64, align 8
  %slot2098 = alloca i64, align 8
  %slot2099 = alloca i64, align 8
  %slot2100 = alloca i64, align 8
  %slot2101 = alloca i64, align 8
  %slot2102 = alloca i64, align 8
  %slot2103 = alloca i32, align 8
  %slot2104 = alloca i64, align 8
  %slot2105 = alloca i64, align 8
  %slot2106 = alloca i64, align 8
  %slot2107 = alloca i64, align 8
  %slot2108 = alloca i64, align 8
  %callresult2109 = alloca [16 x i8], align 8
  %slot2110 = alloca i64, align 8
  %slot2111 = alloca i64, align 8
  %slot2112 = alloca i32, align 8
  %slot2113 = alloca i32, align 8
  %slot2114 = alloca i32, align 8
  %slot2115 = alloca i32, align 8
  %slot2116 = alloca i64, align 8
  %slot2117 = alloca i32, align 8
  %slot2118 = alloca i32, align 8
  %slot2119 = alloca i64, align 8
  %slot2120 = alloca i64, align 8
  %slot2121 = alloca i32, align 8
  %slot2122 = alloca i64, align 8
  %slot2123 = alloca i64, align 8
  %slot2124 = alloca i64, align 8
  %slot2125 = alloca i32, align 8
  %slot2126 = alloca i64, align 8
  %slot2127 = alloca i64, align 8
  %slot2128 = alloca i64, align 8
  %slot2129 = alloca i32, align 8
  %slot2130 = alloca i64, align 8
  %slot2131 = alloca i64, align 8
  %slot2132 = alloca i32, align 8
  %slot2133 = alloca i64, align 8
  %slot2134 = alloca i64, align 8
  %slot2135 = alloca i32, align 8
  %slot2136 = alloca i64, align 8
  %slot2137 = alloca i64, align 8
  %slot2138 = alloca i64, align 8
  %slot2139 = alloca i32, align 8
  %slot2140 = alloca i64, align 8
  %slot2141 = alloca i64, align 8
  %slot2142 = alloca i64, align 8
  %slot2143 = alloca i32, align 8
  %slot2144 = alloca i64, align 8
  %slot2145 = alloca i64, align 8
  %slot2146 = alloca i32, align 8
  %slot2147 = alloca i64, align 8
  %slot2148 = alloca i64, align 8
  %slot2149 = alloca i32, align 8
  %slot2150 = alloca i64, align 8
  %slot2151 = alloca i64, align 8
  %slot2152 = alloca i64, align 8
  %slot2153 = alloca i64, align 8
  %slot2154 = alloca i64, align 8
  %slot2155 = alloca i64, align 8
  %slot2156 = alloca i64, align 8
  %slot2157 = alloca i32, align 8
  %slot2158 = alloca i32, align 8
  %slot2159 = alloca i32, align 8
  %slot2160 = alloca i32, align 8
  %slot2161 = alloca i64, align 8
  %slot2162 = alloca i64, align 8
  %slot2163 = alloca i64, align 8
  %slot2164 = alloca i64, align 8
  %slot2165 = alloca i32, align 8
  %slot2166 = alloca i32, align 8
  %slot2167 = alloca i32, align 8
  %slot2168 = alloca i64, align 8
  %slot2169 = alloca i64, align 8
  %slot2170 = alloca i32, align 8
  %slot2171 = alloca i64, align 8
  %slot2172 = alloca i64, align 8
  %slot2173 = alloca i64, align 8
  %slot2174 = alloca i32, align 8
  %slot2175 = alloca i64, align 8
  %slot2176 = alloca i32, align 8
  %slot2177 = alloca i32, align 8
  %slot2178 = alloca i32, align 8
  %slot2179 = alloca i64, align 8
  %slot2180 = alloca i64, align 8
  %slot2181 = alloca i32, align 8
  %slot2182 = alloca i32, align 8
  %slot2183 = alloca i32, align 8
  %slot2184 = alloca i32, align 8
  %slot2185 = alloca i64, align 8
  %slot2186 = alloca i32, align 8
  %slot2187 = alloca i32, align 8
  %slot2188 = alloca i64, align 8
  %slot2189 = alloca i64, align 8
  %slot2190 = alloca i64, align 8
  %slot2191 = alloca i64, align 8
  %slot2192 = alloca i64, align 8
  %slot2193 = alloca i64, align 8
  %slot2194 = alloca i64, align 8
  %slot2195 = alloca i64, align 8
  %slot2196 = alloca i64, align 8
  %slot2197 = alloca i32, align 8
  %slot2198 = alloca i32, align 8
  %slot2199 = alloca i32, align 8
  %slot2200 = alloca i64, align 8
  %slot2201 = alloca i64, align 8
  %slot2202 = alloca i32, align 8
  %slot2203 = alloca i64, align 8
  %slot2204 = alloca i32, align 8
  %slot2205 = alloca i64, align 8
  %slot2206 = alloca i32, align 8
  %slot2207 = alloca i32, align 8
  %slot2208 = alloca i64, align 8
  %slot2209 = alloca i64, align 8
  %slot2210 = alloca i32, align 8
  %slot2211 = alloca i64, align 8
  %slot2212 = alloca i32, align 8
  %slot2213 = alloca i32, align 8
  %slot2214 = alloca i64, align 8
  %slot2215 = alloca i64, align 8
  %slot2216 = alloca i32, align 8
  %slot2217 = alloca i64, align 8
  %slot2218 = alloca i32, align 8
  %slot2219 = alloca i32, align 8
  %slot2220 = alloca i64, align 8
  %slot2221 = alloca i64, align 8
  %slot2222 = alloca i32, align 8
  %slot2223 = alloca i64, align 8
  %slot2224 = alloca i64, align 8
  %slot2225 = alloca i64, align 8
  %slot2226 = alloca i32, align 8
  %slot2227 = alloca i64, align 8
  %slot2228 = alloca i64, align 8
  %slot2229 = alloca i64, align 8
  %slot2230 = alloca i32, align 8
  %slot2231 = alloca i64, align 8
  %slot2232 = alloca i64, align 8
  %slot2233 = alloca i32, align 8
  %slot2234 = alloca i64, align 8
  %slot2235 = alloca i64, align 8
  %slot2236 = alloca i32, align 8
  %slot2237 = alloca i64, align 8
  %slot2238 = alloca i64, align 8
  %slot2239 = alloca i64, align 8
  %slot2240 = alloca i32, align 8
  %slot2241 = alloca i64, align 8
  %slot2242 = alloca i64, align 8
  %slot2243 = alloca i64, align 8
  %slot2244 = alloca i32, align 8
  %slot2245 = alloca i64, align 8
  %slot2246 = alloca i64, align 8
  %slot2247 = alloca i32, align 8
  %slot2248 = alloca i32, align 8
  %slot2249 = alloca i64, align 8
  %slot2250 = alloca i32, align 8
  %slot2251 = alloca i32, align 8
  %slot2252 = alloca i64, align 8
  %slot2253 = alloca i64, align 8
  %slot2254 = alloca i32, align 8
  %slot2255 = alloca i64, align 8
  %slot2256 = alloca i64, align 8
  %slot2257 = alloca i64, align 8
  %slot2258 = alloca i32, align 8
  %slot2259 = alloca i64, align 8
  %slot2260 = alloca i64, align 8
  %slot2261 = alloca i64, align 8
  %slot2262 = alloca i32, align 8
  %slot2263 = alloca i64, align 8
  %slot2264 = alloca i64, align 8
  %slot2265 = alloca i32, align 8
  %slot2266 = alloca i64, align 8
  %slot2267 = alloca i64, align 8
  %slot2268 = alloca i32, align 8
  %slot2269 = alloca i64, align 8
  %slot2270 = alloca i64, align 8
  %slot2271 = alloca i64, align 8
  %slot2272 = alloca i32, align 8
  %slot2273 = alloca i64, align 8
  %slot2274 = alloca i64, align 8
  %slot2275 = alloca i64, align 8
  %slot2276 = alloca i32, align 8
  %slot2277 = alloca i64, align 8
  %slot2278 = alloca i64, align 8
  %slot2279 = alloca i32, align 8
  %slot2280 = alloca i32, align 8
  %slot2281 = alloca i64, align 8
  %slot2282 = alloca i32, align 8
  %slot2283 = alloca i32, align 8
  %slot2284 = alloca i64, align 8
  %slot2285 = alloca i64, align 8
  %slot2286 = alloca i32, align 8
  %slot2287 = alloca i64, align 8
  %slot2288 = alloca i64, align 8
  %slot2289 = alloca i64, align 8
  %slot2290 = alloca i32, align 8
  %slot2291 = alloca i64, align 8
  %slot2292 = alloca i64, align 8
  %slot2293 = alloca i64, align 8
  %slot2294 = alloca i32, align 8
  %slot2295 = alloca i64, align 8
  %slot2296 = alloca i64, align 8
  %slot2297 = alloca i32, align 8
  %slot2298 = alloca i64, align 8
  %slot2299 = alloca i64, align 8
  %slot2300 = alloca i32, align 8
  %slot2301 = alloca i64, align 8
  %slot2302 = alloca i64, align 8
  %slot2303 = alloca i64, align 8
  %slot2304 = alloca i32, align 8
  %slot2305 = alloca i64, align 8
  %slot2306 = alloca i64, align 8
  %slot2307 = alloca i64, align 8
  %slot2308 = alloca i32, align 8
  %slot2309 = alloca i64, align 8
  %slot2310 = alloca i64, align 8
  %slot2311 = alloca i32, align 8
  %slot2312 = alloca i32, align 8
  %slot2313 = alloca i64, align 8
  %slot2314 = alloca i32, align 8
  %slot2315 = alloca i32, align 8
  %slot2316 = alloca i64, align 8
  %slot2317 = alloca i64, align 8
  %slot2318 = alloca i32, align 8
  %slot2319 = alloca i64, align 8
  %slot2320 = alloca i32, align 8
  %slot2321 = alloca i32, align 8
  %slot2322 = alloca i64, align 8
  %slot2323 = alloca i64, align 8
  %slot2324 = alloca i32, align 8
  %slot2325 = alloca i64, align 8
  %slot2326 = alloca i32, align 8
  %slot2327 = alloca i32, align 8
  %slot2328 = alloca i64, align 8
  %slot2329 = alloca i64, align 8
  %slot2330 = alloca i32, align 8
  %slot2331 = alloca i64, align 8
  %slot2332 = alloca i32, align 8
  %slot2333 = alloca i32, align 8
  %slot2334 = alloca i64, align 8
  %slot2335 = alloca i64, align 8
  %slot2336 = alloca i32, align 8
  %slot2337 = alloca i64, align 8
  %slot2338 = alloca i32, align 8
  %slot2339 = alloca i32, align 8
  %slot2340 = alloca i64, align 8
  %slot2341 = alloca i64, align 8
  %slot2342 = alloca i32, align 8
  %slot2343 = alloca i64, align 8
  %slot2344 = alloca i32, align 8
  %slot2345 = alloca i32, align 8
  %slot2346 = alloca i64, align 8
  %slot2347 = alloca i64, align 8
  %slot2348 = alloca i64, align 8
  %slot2349 = alloca i64, align 8
  %slot2350 = alloca i64, align 8
  %slot2351 = alloca i32, align 8
  %slot2352 = alloca i64, align 8
  %slot2353 = alloca i32, align 8
  %slot2354 = alloca i32, align 8
  %slot2355 = alloca i64, align 8
  %slot2356 = alloca i64, align 8
  %slot2357 = alloca i64, align 8
  %slot2358 = alloca i64, align 8
  %slot2359 = alloca i64, align 8
  %slot2360 = alloca i64, align 8
  %slot2361 = alloca i64, align 8
  %slot2362 = alloca i64, align 8
  %slot2363 = alloca i64, align 8
  %slot2364 = alloca i64, align 8
  %slot2365 = alloca i64, align 8
  %slot2366 = alloca i64, align 8
  %slot2367 = alloca i64, align 8
  %slot2368 = alloca i64, align 8
  %slot2369 = alloca i64, align 8
  %slot2370 = alloca i64, align 8
  %slot2371 = alloca i64, align 8
  %slot2372 = alloca i32, align 8
  %slot2373 = alloca i64, align 8
  %slot2374 = alloca i32, align 8
  %slot2375 = alloca i32, align 8
  %slot2376 = alloca i64, align 8
  %slot2377 = alloca i64, align 8
  %slot2378 = alloca i64, align 8
  %slot2379 = alloca i64, align 8
  %slot2380 = alloca i64, align 8
  %slot2381 = alloca i64, align 8
  %slot2382 = alloca i64, align 8
  %slot2383 = alloca i64, align 8
  %slot2384 = alloca i64, align 8
  %slot2385 = alloca i64, align 8
  %slot2386 = alloca i64, align 8
  %slot2387 = alloca i64, align 8
  %slot2388 = alloca i64, align 8
  %slot2389 = alloca i64, align 8
  %slot2390 = alloca i64, align 8
  %slot2391 = alloca i64, align 8
  %slot2392 = alloca i64, align 8
  %slot2393 = alloca i64, align 8
  %slot2394 = alloca i32, align 8
  %slot2395 = alloca i32, align 8
  %slot2396 = alloca i32, align 8
  %slot2397 = alloca i64, align 8
  %slot2398 = alloca i64, align 8
  %slot2399 = alloca i32, align 8
  %slot2400 = alloca i64, align 8
  %slot2401 = alloca i32, align 8
  %slot2402 = alloca i64, align 8
  %slot2403 = alloca i32, align 8
  %slot2404 = alloca i32, align 8
  %slot2405 = alloca i64, align 8
  %slot2406 = alloca i64, align 8
  %slot2407 = alloca i32, align 8
  %slot2408 = alloca i64, align 8
  %slot2409 = alloca i32, align 8
  %slot2410 = alloca i32, align 8
  %slot2411 = alloca i64, align 8
  %slot2412 = alloca i64, align 8
  %slot2413 = alloca i32, align 8
  %slot2414 = alloca i64, align 8
  %slot2415 = alloca i32, align 8
  %slot2416 = alloca i32, align 8
  %slot2417 = alloca i64, align 8
  %slot2418 = alloca i64, align 8
  %slot2419 = alloca i32, align 8
  %slot2420 = alloca i64, align 8
  %slot2421 = alloca i64, align 8
  %slot2422 = alloca i64, align 8
  %slot2423 = alloca i32, align 8
  %slot2424 = alloca i64, align 8
  %slot2425 = alloca i64, align 8
  %slot2426 = alloca i64, align 8
  %slot2427 = alloca i32, align 8
  %slot2428 = alloca i64, align 8
  %slot2429 = alloca i64, align 8
  %slot2430 = alloca i32, align 8
  %slot2431 = alloca i64, align 8
  %slot2432 = alloca i64, align 8
  %slot2433 = alloca i32, align 8
  %slot2434 = alloca i64, align 8
  %slot2435 = alloca i64, align 8
  %slot2436 = alloca i64, align 8
  %slot2437 = alloca i32, align 8
  %slot2438 = alloca i64, align 8
  %slot2439 = alloca i64, align 8
  %slot2440 = alloca i64, align 8
  %slot2441 = alloca i32, align 8
  %slot2442 = alloca i64, align 8
  %slot2443 = alloca i64, align 8
  %slot2444 = alloca i32, align 8
  %slot2445 = alloca i32, align 8
  %slot2446 = alloca i64, align 8
  %slot2447 = alloca i32, align 8
  %slot2448 = alloca i32, align 8
  %slot2449 = alloca i64, align 8
  %slot2450 = alloca i64, align 8
  %slot2451 = alloca i32, align 8
  %slot2452 = alloca i64, align 8
  %slot2453 = alloca i64, align 8
  %slot2454 = alloca i64, align 8
  %slot2455 = alloca i32, align 8
  %slot2456 = alloca i64, align 8
  %slot2457 = alloca i64, align 8
  %slot2458 = alloca i64, align 8
  %slot2459 = alloca i32, align 8
  %slot2460 = alloca i64, align 8
  %slot2461 = alloca i64, align 8
  %slot2462 = alloca i32, align 8
  %slot2463 = alloca i64, align 8
  %slot2464 = alloca i64, align 8
  %slot2465 = alloca i32, align 8
  %slot2466 = alloca i64, align 8
  %slot2467 = alloca i64, align 8
  %slot2468 = alloca i64, align 8
  %slot2469 = alloca i32, align 8
  %slot2470 = alloca i64, align 8
  %slot2471 = alloca i64, align 8
  %slot2472 = alloca i64, align 8
  %slot2473 = alloca i32, align 8
  %slot2474 = alloca i64, align 8
  %slot2475 = alloca i64, align 8
  %slot2476 = alloca i32, align 8
  %slot2477 = alloca i32, align 8
  %slot2478 = alloca i64, align 8
  %slot2479 = alloca i32, align 8
  %slot2480 = alloca i32, align 8
  %slot2481 = alloca i64, align 8
  %slot2482 = alloca i64, align 8
  %slot2483 = alloca i32, align 8
  %slot2484 = alloca i64, align 8
  %slot2485 = alloca i64, align 8
  %slot2486 = alloca i64, align 8
  %slot2487 = alloca i32, align 8
  %slot2488 = alloca i64, align 8
  %slot2489 = alloca i64, align 8
  %slot2490 = alloca i64, align 8
  %slot2491 = alloca i32, align 8
  %slot2492 = alloca i64, align 8
  %slot2493 = alloca i64, align 8
  %slot2494 = alloca i32, align 8
  %slot2495 = alloca i64, align 8
  %slot2496 = alloca i64, align 8
  %slot2497 = alloca i32, align 8
  %slot2498 = alloca i64, align 8
  %slot2499 = alloca i64, align 8
  %slot2500 = alloca i64, align 8
  %slot2501 = alloca i32, align 8
  %slot2502 = alloca i64, align 8
  %slot2503 = alloca i64, align 8
  %slot2504 = alloca i64, align 8
  %slot2505 = alloca i32, align 8
  %slot2506 = alloca i64, align 8
  %slot2507 = alloca i64, align 8
  %slot2508 = alloca i32, align 8
  %slot2509 = alloca i32, align 8
  %slot2510 = alloca i64, align 8
  %slot2511 = alloca i32, align 8
  %slot2512 = alloca i32, align 8
  %slot2513 = alloca i64, align 8
  %slot2514 = alloca i64, align 8
  %slot2515 = alloca i32, align 8
  %slot2516 = alloca i64, align 8
  %slot2517 = alloca i32, align 8
  %slot2518 = alloca i32, align 8
  %slot2519 = alloca i64, align 8
  %slot2520 = alloca i64, align 8
  %slot2521 = alloca i32, align 8
  %slot2522 = alloca i64, align 8
  %slot2523 = alloca i32, align 8
  %slot2524 = alloca i32, align 8
  %slot2525 = alloca i64, align 8
  %slot2526 = alloca i64, align 8
  %slot2527 = alloca i32, align 8
  %slot2528 = alloca i64, align 8
  %slot2529 = alloca i32, align 8
  %slot2530 = alloca i32, align 8
  %slot2531 = alloca i64, align 8
  %slot2532 = alloca i64, align 8
  %slot2533 = alloca i32, align 8
  %slot2534 = alloca i64, align 8
  %slot2535 = alloca i32, align 8
  %slot2536 = alloca i32, align 8
  %slot2537 = alloca i64, align 8
  %slot2538 = alloca i64, align 8
  %slot2539 = alloca i32, align 8
  %slot2540 = alloca i64, align 8
  %slot2541 = alloca i32, align 8
  %slot2542 = alloca i32, align 8
  %slot2543 = alloca i64, align 8
  %slot2544 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  store i64 %p_a3, ptr %slot5, align 8
  %v2545 = load i64, ptr %slot1, align 8
  %op2546 = add i64 %v2545, 32
  store i64 %op2546, ptr %slot6, align 8
  %mem2547 = alloca i8, i64 24, align 8
  %ptr2548 = ptrtoint ptr %mem2547 to i64
  store i64 %ptr2548, ptr %slot7, align 8
  %mem2549 = alloca i8, i64 8, align 8
  %ptr2550 = ptrtoint ptr %mem2549 to i64
  store i64 %ptr2550, ptr %slot8, align 8
  %mem2551 = alloca i8, i64 8, align 8
  %ptr2552 = ptrtoint ptr %mem2551 to i64
  store i64 %ptr2552, ptr %slot9, align 8
  %mem2553 = alloca i8, i64 8, align 8
  %ptr2554 = ptrtoint ptr %mem2553 to i64
  store i64 %ptr2554, ptr %slot10, align 8
  %mem2555 = alloca i8, i64 8, align 8
  %ptr2556 = ptrtoint ptr %mem2555 to i64
  store i64 %ptr2556, ptr %slot11, align 8
  %mem2557 = alloca i8, i64 8, align 8
  %ptr2558 = ptrtoint ptr %mem2557 to i64
  store i64 %ptr2558, ptr %slot12, align 8
  %mem2559 = alloca i8, i64 8, align 8
  %ptr2560 = ptrtoint ptr %mem2559 to i64
  store i64 %ptr2560, ptr %slot13, align 8
  %mem2561 = alloca i8, i64 8, align 8
  %ptr2562 = ptrtoint ptr %mem2561 to i64
  store i64 %ptr2562, ptr %slot14, align 8
  %mem2563 = alloca i8, i64 8, align 8
  %ptr2564 = ptrtoint ptr %mem2563 to i64
  store i64 %ptr2564, ptr %slot15, align 8
  %mem2565 = alloca i8, i64 8, align 8
  %ptr2566 = ptrtoint ptr %mem2565 to i64
  store i64 %ptr2566, ptr %slot16, align 8
  %mem2567 = alloca i8, i64 8, align 8
  %ptr2568 = ptrtoint ptr %mem2567 to i64
  store i64 %ptr2568, ptr %slot17, align 8
  %mem2569 = alloca i8, i64 8, align 8
  %ptr2570 = ptrtoint ptr %mem2569 to i64
  store i64 %ptr2570, ptr %slot18, align 8
  %mem2571 = alloca i8, i64 8, align 8
  %ptr2572 = ptrtoint ptr %mem2571 to i64
  store i64 %ptr2572, ptr %slot19, align 8
  %mem2573 = alloca i8, i64 8, align 8
  %ptr2574 = ptrtoint ptr %mem2573 to i64
  store i64 %ptr2574, ptr %slot20, align 8
  %mem2575 = alloca i8, i64 8, align 8
  %ptr2576 = ptrtoint ptr %mem2575 to i64
  store i64 %ptr2576, ptr %slot21, align 8
  %mem2577 = alloca i8, i64 8, align 8
  %ptr2578 = ptrtoint ptr %mem2577 to i64
  store i64 %ptr2578, ptr %slot22, align 8
  %mem2579 = alloca i8, i64 8, align 8
  %ptr2580 = ptrtoint ptr %mem2579 to i64
  store i64 %ptr2580, ptr %slot23, align 8
  %mem2581 = alloca i8, i64 8, align 8
  %ptr2582 = ptrtoint ptr %mem2581 to i64
  store i64 %ptr2582, ptr %slot24, align 8
  %mem2583 = alloca i8, i64 8, align 8
  %ptr2584 = ptrtoint ptr %mem2583 to i64
  store i64 %ptr2584, ptr %slot25, align 8
  %mem2585 = alloca i8, i64 8, align 8
  %ptr2586 = ptrtoint ptr %mem2585 to i64
  store i64 %ptr2586, ptr %slot26, align 8
  %mem2587 = alloca i8, i64 8, align 8
  %ptr2588 = ptrtoint ptr %mem2587 to i64
  store i64 %ptr2588, ptr %slot27, align 8
  %mem2589 = alloca i8, i64 8, align 8
  %ptr2590 = ptrtoint ptr %mem2589 to i64
  store i64 %ptr2590, ptr %slot28, align 8
  %mem2591 = alloca i8, i64 8, align 8
  %ptr2592 = ptrtoint ptr %mem2591 to i64
  store i64 %ptr2592, ptr %slot29, align 8
  %mem2593 = alloca i8, i64 8, align 8
  %ptr2594 = ptrtoint ptr %mem2593 to i64
  store i64 %ptr2594, ptr %slot30, align 8
  %mem2595 = alloca i8, i64 8, align 8
  %ptr2596 = ptrtoint ptr %mem2595 to i64
  store i64 %ptr2596, ptr %slot31, align 8
  %mem2597 = alloca i8, i64 8, align 8
  %ptr2598 = ptrtoint ptr %mem2597 to i64
  store i64 %ptr2598, ptr %slot32, align 8
  %mem2599 = alloca i8, i64 8, align 8
  %ptr2600 = ptrtoint ptr %mem2599 to i64
  store i64 %ptr2600, ptr %slot33, align 8
  %mem2601 = alloca i8, i64 8, align 8
  %ptr2602 = ptrtoint ptr %mem2601 to i64
  store i64 %ptr2602, ptr %slot34, align 8
  %mem2603 = alloca i8, i64 8, align 8
  %ptr2604 = ptrtoint ptr %mem2603 to i64
  store i64 %ptr2604, ptr %slot35, align 8
  %mem2605 = alloca i8, i64 8, align 8
  %ptr2606 = ptrtoint ptr %mem2605 to i64
  store i64 %ptr2606, ptr %slot36, align 8
  %mem2607 = alloca i8, i64 304, align 8
  %ptr2608 = ptrtoint ptr %mem2607 to i64
  store i64 %ptr2608, ptr %slot37, align 8
  %mem2609 = alloca i8, i64 304, align 8
  %ptr2610 = ptrtoint ptr %mem2609 to i64
  store i64 %ptr2610, ptr %slot38, align 8
  %mem2611 = alloca i8, i64 304, align 8
  %ptr2612 = ptrtoint ptr %mem2611 to i64
  store i64 %ptr2612, ptr %slot39, align 8
  %mem2613 = alloca i8, i64 8, align 8
  %ptr2614 = ptrtoint ptr %mem2613 to i64
  store i64 %ptr2614, ptr %slot40, align 8
  %mem2615 = alloca i8, i64 304, align 8
  %ptr2616 = ptrtoint ptr %mem2615 to i64
  store i64 %ptr2616, ptr %slot41, align 8
  %mem2617 = alloca i8, i64 8, align 8
  %ptr2618 = ptrtoint ptr %mem2617 to i64
  store i64 %ptr2618, ptr %slot42, align 8
  %mem2619 = alloca i8, i64 32, align 8
  %ptr2620 = ptrtoint ptr %mem2619 to i64
  store i64 %ptr2620, ptr %slot43, align 8
  %v2621 = load i64, ptr %slot43, align 8
  %p2623 = inttoptr i64 %v2621 to ptr
  %gep2624 = getelementptr i8, ptr %p2623, i64 24
  %op2622 = ptrtoint ptr %gep2624 to i64
  store i64 %op2622, ptr %slot44, align 8
  %v2625 = load i64, ptr %slot44, align 8
  %p2626 = inttoptr i64 %v2625 to ptr
  store i64 0, ptr %p2626, align 8, !alias.scope !3, !noalias !4
  %mem2627 = alloca i8, i64 8, align 8
  %ptr2628 = ptrtoint ptr %mem2627 to i64
  store i64 %ptr2628, ptr %slot45, align 8
  %mem2629 = alloca i8, i64 8, align 8
  %ptr2630 = ptrtoint ptr %mem2629 to i64
  store i64 %ptr2630, ptr %slot46, align 8
  %mem2631 = alloca i8, i64 8, align 8
  %ptr2632 = ptrtoint ptr %mem2631 to i64
  store i64 %ptr2632, ptr %slot47, align 8
  %mem2633 = alloca i8, i64 8, align 8
  %ptr2634 = ptrtoint ptr %mem2633 to i64
  store i64 %ptr2634, ptr %slot48, align 8
  %mem2635 = alloca i8, i64 8, align 8
  %ptr2636 = ptrtoint ptr %mem2635 to i64
  store i64 %ptr2636, ptr %slot49, align 8
  %mem2637 = alloca i8, i64 8, align 8
  %ptr2638 = ptrtoint ptr %mem2637 to i64
  store i64 %ptr2638, ptr %slot50, align 8
  %mem2639 = alloca i8, i64 208, align 8
  %ptr2640 = ptrtoint ptr %mem2639 to i64
  store i64 %ptr2640, ptr %slot51, align 8
  %mem2641 = alloca i8, i64 8, align 8
  %ptr2642 = ptrtoint ptr %mem2641 to i64
  store i64 %ptr2642, ptr %slot52, align 8
  %mem2643 = alloca i8, i64 8, align 8
  %ptr2644 = ptrtoint ptr %mem2643 to i64
  store i64 %ptr2644, ptr %slot53, align 8
  %mem2645 = alloca i8, i64 16, align 8
  %ptr2646 = ptrtoint ptr %mem2645 to i64
  store i64 %ptr2646, ptr %slot54, align 8
  %mem2647 = alloca i8, i64 8, align 8
  %ptr2648 = ptrtoint ptr %mem2647 to i64
  store i64 %ptr2648, ptr %slot55, align 8
  %mem2649 = alloca i8, i64 16, align 8
  %ptr2650 = ptrtoint ptr %mem2649 to i64
  store i64 %ptr2650, ptr %slot56, align 8
  %mem2651 = alloca i8, i64 16, align 8
  %ptr2652 = ptrtoint ptr %mem2651 to i64
  store i64 %ptr2652, ptr %slot57, align 8
  %mem2653 = alloca i8, i64 32, align 8
  %ptr2654 = ptrtoint ptr %mem2653 to i64
  store i64 %ptr2654, ptr %slot58, align 8
  %mem2655 = alloca i8, i64 208, align 8
  %ptr2656 = ptrtoint ptr %mem2655 to i64
  store i64 %ptr2656, ptr %slot59, align 8
  %mem2657 = alloca i8, i64 8, align 8
  %ptr2658 = ptrtoint ptr %mem2657 to i64
  store i64 %ptr2658, ptr %slot60, align 8
  %mem2659 = alloca i8, i64 208, align 8
  %ptr2660 = ptrtoint ptr %mem2659 to i64
  store i64 %ptr2660, ptr %slot61, align 8
  %mem2661 = alloca i8, i64 208, align 8
  %ptr2662 = ptrtoint ptr %mem2661 to i64
  store i64 %ptr2662, ptr %slot62, align 8
  %mem2663 = alloca i8, i64 8, align 8
  %ptr2664 = ptrtoint ptr %mem2663 to i64
  store i64 %ptr2664, ptr %slot63, align 8
  %mem2665 = alloca i8, i64 208, align 8
  %ptr2666 = ptrtoint ptr %mem2665 to i64
  store i64 %ptr2666, ptr %slot64, align 8
  %mem2667 = alloca i8, i64 8, align 8
  %ptr2668 = ptrtoint ptr %mem2667 to i64
  store i64 %ptr2668, ptr %slot65, align 8
  %mem2669 = alloca i8, i64 8, align 8
  %ptr2670 = ptrtoint ptr %mem2669 to i64
  store i64 %ptr2670, ptr %slot66, align 8
  %mem2671 = alloca i8, i64 8, align 8
  %ptr2672 = ptrtoint ptr %mem2671 to i64
  store i64 %ptr2672, ptr %slot67, align 8
  %mem2673 = alloca i8, i64 208, align 8
  %ptr2674 = ptrtoint ptr %mem2673 to i64
  store i64 %ptr2674, ptr %slot68, align 8
  %mem2675 = alloca i8, i64 8, align 8
  %ptr2676 = ptrtoint ptr %mem2675 to i64
  store i64 %ptr2676, ptr %slot69, align 8
  %mem2677 = alloca i8, i64 8, align 8
  %ptr2678 = ptrtoint ptr %mem2677 to i64
  store i64 %ptr2678, ptr %slot70, align 8
  %mem2679 = alloca i8, i64 8, align 8
  %ptr2680 = ptrtoint ptr %mem2679 to i64
  store i64 %ptr2680, ptr %slot71, align 8
  %mem2681 = alloca i8, i64 8, align 8
  %ptr2682 = ptrtoint ptr %mem2681 to i64
  store i64 %ptr2682, ptr %slot72, align 8
  %mem2683 = alloca i8, i64 8, align 8
  %ptr2684 = ptrtoint ptr %mem2683 to i64
  store i64 %ptr2684, ptr %slot73, align 8
  %mem2685 = alloca i8, i64 8, align 8
  %ptr2686 = ptrtoint ptr %mem2685 to i64
  store i64 %ptr2686, ptr %slot74, align 8
  %mem2687 = alloca i8, i64 304, align 8
  %ptr2688 = ptrtoint ptr %mem2687 to i64
  store i64 %ptr2688, ptr %slot75, align 8
  %mem2689 = alloca i8, i64 208, align 8
  %ptr2690 = ptrtoint ptr %mem2689 to i64
  store i64 %ptr2690, ptr %slot76, align 8
  %mem2691 = alloca i8, i64 208, align 8
  %ptr2692 = ptrtoint ptr %mem2691 to i64
  store i64 %ptr2692, ptr %slot77, align 8
  %mem2693 = alloca i8, i64 16, align 8
  %ptr2694 = ptrtoint ptr %mem2693 to i64
  store i64 %ptr2694, ptr %slot78, align 8
  %mem2695 = alloca i8, i64 16, align 8
  %ptr2696 = ptrtoint ptr %mem2695 to i64
  store i64 %ptr2696, ptr %slot79, align 8
  %mem2697 = alloca i8, i64 304, align 8
  %ptr2698 = ptrtoint ptr %mem2697 to i64
  store i64 %ptr2698, ptr %slot80, align 8
  %mem2699 = alloca i8, i64 304, align 8
  %ptr2700 = ptrtoint ptr %mem2699 to i64
  store i64 %ptr2700, ptr %slot81, align 8
  %mem2701 = alloca i8, i64 208, align 8
  %ptr2702 = ptrtoint ptr %mem2701 to i64
  store i64 %ptr2702, ptr %slot82, align 8
  %mem2703 = alloca i8, i64 304, align 8
  %ptr2704 = ptrtoint ptr %mem2703 to i64
  store i64 %ptr2704, ptr %slot83, align 8
  %mem2705 = alloca i8, i64 208, align 8
  %ptr2706 = ptrtoint ptr %mem2705 to i64
  store i64 %ptr2706, ptr %slot84, align 8
  %mem2707 = alloca i8, i64 24, align 8
  %ptr2708 = ptrtoint ptr %mem2707 to i64
  store i64 %ptr2708, ptr %slot85, align 8
  %mem2709 = alloca i8, i64 304, align 8
  %ptr2710 = ptrtoint ptr %mem2709 to i64
  store i64 %ptr2710, ptr %slot86, align 8
  %mem2711 = alloca i8, i64 24, align 8
  %ptr2712 = ptrtoint ptr %mem2711 to i64
  store i64 %ptr2712, ptr %slot87, align 8
  %mem2713 = alloca i8, i64 24, align 8
  %ptr2714 = ptrtoint ptr %mem2713 to i64
  store i64 %ptr2714, ptr %slot88, align 8
  %mem2715 = alloca i8, i64 304, align 8
  %ptr2716 = ptrtoint ptr %mem2715 to i64
  store i64 %ptr2716, ptr %slot89, align 8
  %mem2717 = alloca i8, i64 208, align 8
  %ptr2718 = ptrtoint ptr %mem2717 to i64
  store i64 %ptr2718, ptr %slot90, align 8
  %mem2719 = alloca i8, i64 24, align 8
  %ptr2720 = ptrtoint ptr %mem2719 to i64
  store i64 %ptr2720, ptr %slot91, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem2721 = alloca i8, i64 8, align 8
  %ptr2722 = ptrtoint ptr %mem2721 to i64
  store i64 %ptr2722, ptr %slot92, align 8
  %v2723 = load i64, ptr %slot1, align 8
  %op2724 = add i64 %v2723, 64
  store i64 %op2724, ptr %slot93, align 8
  %v2725 = load i64, ptr %slot93, align 8
  %p2726 = inttoptr i64 %v2725 to ptr
  %ld2727 = load i64, ptr %p2726, align 8, !alias.scope !4, !noalias !3
  store i64 %ld2727, ptr %slot94, align 8
  %stack2728 = call ptr @llvm.stacksave()
  %stackaddr2729 = ptrtoint ptr %stack2728 to i64
  %v2730 = load i64, ptr %slot94, align 8
  %cmp2731 = icmp ult i64 %stackaddr2729, %v2730
  %cv2732 = zext i1 %cmp2731 to i64
  store i64 %cv2732, ptr %slot95, align 8
  %v2733 = load i64, ptr %slot95, align 8
  %cond2734 = icmp ne i64 %v2733, 0
  br i1 %cond2734, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v2735 = load i64, ptr %slot1, align 8
  %p2736 = inttoptr i64 %v2735 to ptr
  call void @myl_qbe_fail_frame(ptr %p2736) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %v2737 = load i64, ptr %slot53, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  store i64 0, ptr %p2738, align 8, !alias.scope !3, !noalias !4
  %v2739 = load i64, ptr %slot65, align 8
  %p2740 = inttoptr i64 %v2739 to ptr
  store i64 0, ptr %p2740, align 8, !alias.scope !3, !noalias !4
  %v2741 = load i64, ptr %slot66, align 8
  %p2742 = inttoptr i64 %v2741 to ptr
  store i64 0, ptr %p2742, align 8, !alias.scope !3, !noalias !4
  %v2743 = load i64, ptr %slot67, align 8
  %p2744 = inttoptr i64 %v2743 to ptr
  store i64 0, ptr %p2744, align 8, !alias.scope !3, !noalias !4
  %v2745 = load i64, ptr %slot2, align 8
  %v2746 = load i64, ptr %slot46, align 8
  %p2747 = inttoptr i64 %v2746 to ptr
  store i64 %v2745, ptr %p2747, align 8, !alias.scope !3, !noalias !4
  %v2748 = load i64, ptr %slot3, align 8
  %v2749 = load i64, ptr %slot47, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  store i64 %v2748, ptr %p2750, align 8, !alias.scope !3, !noalias !4
  %v2751 = load i64, ptr %slot4, align 8
  %v2752 = load i64, ptr %slot48, align 8
  %p2753 = inttoptr i64 %v2752 to ptr
  store i64 %v2751, ptr %p2753, align 8, !alias.scope !3, !noalias !4
  %v2754 = load i64, ptr %slot5, align 8
  %v2755 = load i64, ptr %slot49, align 8
  %p2756 = inttoptr i64 %v2755 to ptr
  store i64 %v2754, ptr %p2756, align 8, !alias.scope !3, !noalias !4
  %v2757 = load i64, ptr %slot1, align 8
  %p2758 = inttoptr i64 %v2757 to ptr
  %call2759 = call ptr @myl_qbe_heap(ptr %p2758) nomerge, !dbg !112
  %calladdr2760 = ptrtoint ptr %call2759 to i64
  store i64 %calladdr2760, ptr %slot96, align 8
  %v2761 = load i64, ptr %slot1, align 8
  %p2762 = inttoptr i64 %v2761 to ptr
  %call2763 = call i64 @myl_qbe_region_mark(ptr %p2762) nomerge, !dbg !112
  store i64 %call2763, ptr %slot97, align 8
  %v2764 = load i64, ptr %slot8, align 8
  %p2765 = inttoptr i64 %v2764 to ptr
  store i32 0, ptr %p2765, align 4, !alias.scope !3, !noalias !4
  %v2766 = load i64, ptr %slot9, align 8
  %p2767 = inttoptr i64 %v2766 to ptr
  store i32 0, ptr %p2767, align 4, !alias.scope !3, !noalias !4
  %v2768 = load i64, ptr %slot10, align 8
  %p2769 = inttoptr i64 %v2768 to ptr
  store i32 0, ptr %p2769, align 4, !alias.scope !3, !noalias !4
  %v2770 = load i64, ptr %slot11, align 8
  %p2771 = inttoptr i64 %v2770 to ptr
  store i32 0, ptr %p2771, align 4, !alias.scope !3, !noalias !4
  %v2772 = load i64, ptr %slot12, align 8
  %p2773 = inttoptr i64 %v2772 to ptr
  store i32 0, ptr %p2773, align 4, !alias.scope !3, !noalias !4
  %v2774 = load i64, ptr %slot13, align 8
  %p2775 = inttoptr i64 %v2774 to ptr
  store i32 0, ptr %p2775, align 4, !alias.scope !3, !noalias !4
  %v2776 = load i64, ptr %slot14, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  store i32 0, ptr %p2777, align 4, !alias.scope !3, !noalias !4
  %v2778 = load i64, ptr %slot15, align 8
  %p2779 = inttoptr i64 %v2778 to ptr
  store i32 0, ptr %p2779, align 4, !alias.scope !3, !noalias !4
  %v2780 = load i64, ptr %slot16, align 8
  %p2781 = inttoptr i64 %v2780 to ptr
  store i32 0, ptr %p2781, align 4, !alias.scope !3, !noalias !4
  %v2782 = load i64, ptr %slot17, align 8
  %p2783 = inttoptr i64 %v2782 to ptr
  store i32 0, ptr %p2783, align 4, !alias.scope !3, !noalias !4
  %v2784 = load i64, ptr %slot18, align 8
  %p2785 = inttoptr i64 %v2784 to ptr
  store i32 0, ptr %p2785, align 4, !alias.scope !3, !noalias !4
  %v2786 = load i64, ptr %slot19, align 8
  %p2787 = inttoptr i64 %v2786 to ptr
  store i32 0, ptr %p2787, align 4, !alias.scope !3, !noalias !4
  %v2788 = load i64, ptr %slot20, align 8
  %p2789 = inttoptr i64 %v2788 to ptr
  store i32 0, ptr %p2789, align 4, !alias.scope !3, !noalias !4
  %v2790 = load i64, ptr %slot21, align 8
  %p2791 = inttoptr i64 %v2790 to ptr
  store i32 0, ptr %p2791, align 4, !alias.scope !3, !noalias !4
  %v2792 = load i64, ptr %slot22, align 8
  %p2793 = inttoptr i64 %v2792 to ptr
  store i32 0, ptr %p2793, align 4, !alias.scope !3, !noalias !4
  %v2794 = load i64, ptr %slot23, align 8
  %p2795 = inttoptr i64 %v2794 to ptr
  store i32 0, ptr %p2795, align 4, !alias.scope !3, !noalias !4
  %v2796 = load i64, ptr %slot24, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  store i32 0, ptr %p2797, align 4, !alias.scope !3, !noalias !4
  %v2798 = load i64, ptr %slot25, align 8
  %p2799 = inttoptr i64 %v2798 to ptr
  store i32 0, ptr %p2799, align 4, !alias.scope !3, !noalias !4
  %v2800 = load i64, ptr %slot26, align 8
  %p2801 = inttoptr i64 %v2800 to ptr
  store i32 0, ptr %p2801, align 4, !alias.scope !3, !noalias !4
  %v2802 = load i64, ptr %slot27, align 8
  %p2803 = inttoptr i64 %v2802 to ptr
  store i32 0, ptr %p2803, align 4, !alias.scope !3, !noalias !4
  %v2804 = load i64, ptr %slot28, align 8
  %p2805 = inttoptr i64 %v2804 to ptr
  store i32 0, ptr %p2805, align 4, !alias.scope !3, !noalias !4
  %v2806 = load i64, ptr %slot29, align 8
  %p2807 = inttoptr i64 %v2806 to ptr
  store i32 0, ptr %p2807, align 4, !alias.scope !3, !noalias !4
  %v2808 = load i64, ptr %slot30, align 8
  %p2809 = inttoptr i64 %v2808 to ptr
  store i32 0, ptr %p2809, align 4, !alias.scope !3, !noalias !4
  %v2810 = load i64, ptr %slot31, align 8
  %p2811 = inttoptr i64 %v2810 to ptr
  store i32 0, ptr %p2811, align 4, !alias.scope !3, !noalias !4
  %v2812 = load i64, ptr %slot32, align 8
  %p2813 = inttoptr i64 %v2812 to ptr
  store i32 0, ptr %p2813, align 4, !alias.scope !3, !noalias !4
  %v2814 = load i64, ptr %slot33, align 8
  %p2815 = inttoptr i64 %v2814 to ptr
  store i32 0, ptr %p2815, align 4, !alias.scope !3, !noalias !4
  %v2816 = load i64, ptr %slot34, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  store i32 0, ptr %p2817, align 4, !alias.scope !3, !noalias !4
  %v2818 = load i64, ptr %slot35, align 8
  %p2819 = inttoptr i64 %v2818 to ptr
  store i32 0, ptr %p2819, align 4, !alias.scope !3, !noalias !4
  %v2820 = load i64, ptr %slot36, align 8
  %p2821 = inttoptr i64 %v2820 to ptr
  store i32 0, ptr %p2821, align 4, !alias.scope !3, !noalias !4
  %v2822 = load i64, ptr %slot9, align 8
  %p2823 = inttoptr i64 %v2822 to ptr
  store i32 2, ptr %p2823, align 4, !alias.scope !3, !noalias !4
  %v2824 = load i64, ptr %slot11, align 8
  %p2825 = inttoptr i64 %v2824 to ptr
  store i32 2, ptr %p2825, align 4, !alias.scope !3, !noalias !4
  %v2826 = load i64, ptr %slot13, align 8
  %p2827 = inttoptr i64 %v2826 to ptr
  store i32 2, ptr %p2827, align 4, !alias.scope !3, !noalias !4
  %v2828 = load i64, ptr %slot15, align 8
  %p2829 = inttoptr i64 %v2828 to ptr
  store i32 2, ptr %p2829, align 4, !alias.scope !3, !noalias !4
  %v2830 = load i64, ptr %slot17, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  store i32 2, ptr %p2831, align 4, !alias.scope !3, !noalias !4
  %v2832 = load i64, ptr %slot19, align 8
  %p2833 = inttoptr i64 %v2832 to ptr
  store i32 2, ptr %p2833, align 4, !alias.scope !3, !noalias !4
  %v2834 = load i64, ptr %slot21, align 8
  %p2835 = inttoptr i64 %v2834 to ptr
  store i32 2, ptr %p2835, align 4, !alias.scope !3, !noalias !4
  %v2836 = load i64, ptr %slot23, align 8
  %p2837 = inttoptr i64 %v2836 to ptr
  store i32 2, ptr %p2837, align 4, !alias.scope !3, !noalias !4
  %v2838 = load i64, ptr %slot25, align 8
  %p2839 = inttoptr i64 %v2838 to ptr
  store i32 2, ptr %p2839, align 4, !alias.scope !3, !noalias !4
  %v2840 = load i64, ptr %slot27, align 8
  %p2841 = inttoptr i64 %v2840 to ptr
  store i32 2, ptr %p2841, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v2842 = load i64, ptr %slot46, align 8
  %p2843 = inttoptr i64 %v2842 to ptr
  %ld2844 = load i64, ptr %p2843, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2844, ptr %slot98, align 8
  %v2845 = load i64, ptr %slot98, align 8
  %v2846 = load i64, ptr %slot69, align 8
  %p2847 = inttoptr i64 %v2846 to ptr
  store i64 %v2845, ptr %p2847, align 8, !alias.scope !3, !noalias !4
  %v2848 = load i64, ptr %slot69, align 8
  %p2849 = inttoptr i64 %v2848 to ptr
  %ld2850 = load i64, ptr %p2849, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2850, ptr %slot99, align 8
  %v2851 = load i64, ptr %slot99, align 8
  %op2852 = add i64 %v2851, 32
  store i64 %op2852, ptr %slot100, align 8
  %v2853 = load i64, ptr %slot100, align 8
  %v2854 = load i64, ptr %slot69, align 8
  %p2855 = inttoptr i64 %v2854 to ptr
  store i64 %v2853, ptr %p2855, align 8, !alias.scope !3, !noalias !4
  %v2856 = load i64, ptr %slot28, align 8
  %p2857 = inttoptr i64 %v2856 to ptr
  %ld2858 = load i32, ptr %p2857, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2858, ptr %slot101, align 8
  %v2859 = load i32, ptr %slot101, align 8
  %cv2860 = zext i32 %v2859 to i64
  %cond2861 = icmp ne i64 %cv2860, 0
  br i1 %cond2861, label %bb_rcslotdrop37, label %bb_rcslotdone37
bb_rcslotdrop37:
  %v2862 = load i64, ptr %slot28, align 8
  %p2863 = inttoptr i64 %v2862 to ptr
  store i32 0, ptr %p2863, align 4, !alias.scope !3, !noalias !4
  %v2864 = load i64, ptr %slot37, align 8
  store i64 %v2864, ptr %slot102, align 8
  %v2865 = load i64, ptr %slot29, align 8
  %p2866 = inttoptr i64 %v2865 to ptr
  %ld2867 = load i32, ptr %p2866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2867, ptr %slot103, align 8
  %v2868 = load i32, ptr %slot103, align 8
  %op2869 = and i32 %v2868, 28
  store i32 %op2869, ptr %slot104, align 8
  %v2870 = load i32, ptr %slot104, align 8
  %cv2871 = zext i32 %v2870 to i64
  %cond2872 = icmp ne i64 %cv2871, 0
  br i1 %cond2872, label %bb_rcslotrole37, label %bb_rcslotowner37
bb_rcslotrole37:
  %v2873 = load i64, ptr %slot96, align 8
  store i64 %v2873, ptr %slot105, align 8
  %v2874 = load i64, ptr %slot105, align 8
  %v2875 = load i64, ptr %slot102, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v2874, i64 %v2875) nomerge, !dbg !114
  br label %bb_rcslotdone37
bb_rcslotowner37:
  %v2876 = load i64, ptr %slot96, align 8
  store i64 %v2876, ptr %slot106, align 8
  %v2877 = load i64, ptr %slot106, align 8
  %v2878 = load i64, ptr %slot102, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v2877, i64 %v2878) nomerge, !dbg !114
  br label %bb_rcslotdone37
bb_rcslotdone37:
  %v2879 = load i64, ptr %slot69, align 8
  %p2880 = inttoptr i64 %v2879 to ptr
  %ld2881 = load i64, ptr %p2880, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2881, ptr %slot107, align 8
  %v2882 = load i64, ptr %slot107, align 8
  %op2883 = add i64 %v2882, 128
  store i64 %op2883, ptr %slot108, align 8
  %v2884 = load i64, ptr %slot108, align 8
  %p2885 = inttoptr i64 %v2884 to ptr
  %ld2886 = load i64, ptr %p2885, align 8
  store i64 %ld2886, ptr %slot109, align 8
  %v2887 = load i64, ptr %slot109, align 8
  %v2888 = load i64, ptr %slot69, align 8
  %p2889 = inttoptr i64 %v2888 to ptr
  store i64 %v2887, ptr %p2889, align 8, !alias.scope !3, !noalias !4
  %v2890 = load i64, ptr %slot28, align 8
  %p2891 = inttoptr i64 %v2890 to ptr
  %ld2892 = load i32, ptr %p2891, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2892, ptr %slot110, align 8
  %v2893 = load i32, ptr %slot110, align 8
  %cv2894 = zext i32 %v2893 to i64
  %cond2895 = icmp ne i64 %cv2894, 0
  br i1 %cond2895, label %bb_rcslotdrop49, label %bb_rcslotdone49
bb_rcslotdrop49:
  %v2896 = load i64, ptr %slot28, align 8
  %p2897 = inttoptr i64 %v2896 to ptr
  store i32 0, ptr %p2897, align 4, !alias.scope !3, !noalias !4
  %v2898 = load i64, ptr %slot37, align 8
  store i64 %v2898, ptr %slot111, align 8
  %v2899 = load i64, ptr %slot29, align 8
  %p2900 = inttoptr i64 %v2899 to ptr
  %ld2901 = load i32, ptr %p2900, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2901, ptr %slot112, align 8
  %v2902 = load i32, ptr %slot112, align 8
  %op2903 = and i32 %v2902, 28
  store i32 %op2903, ptr %slot113, align 8
  %v2904 = load i32, ptr %slot113, align 8
  %cv2905 = zext i32 %v2904 to i64
  %cond2906 = icmp ne i64 %cv2905, 0
  br i1 %cond2906, label %bb_rcslotrole49, label %bb_rcslotowner49
bb_rcslotrole49:
  %v2907 = load i64, ptr %slot96, align 8
  store i64 %v2907, ptr %slot114, align 8
  %v2908 = load i64, ptr %slot114, align 8
  %v2909 = load i64, ptr %slot111, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2908, i64 %v2909) nomerge, !dbg !116
  br label %bb_rcslotdone49
bb_rcslotowner49:
  %v2910 = load i64, ptr %slot96, align 8
  store i64 %v2910, ptr %slot115, align 8
  %v2911 = load i64, ptr %slot115, align 8
  %v2912 = load i64, ptr %slot111, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2911, i64 %v2912) nomerge, !dbg !116
  br label %bb_rcslotdone49
bb_rcslotdone49:
  %v2913 = load i64, ptr %slot48, align 8
  %p2914 = inttoptr i64 %v2913 to ptr
  %ld2915 = load i64, ptr %p2914, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2915, ptr %slot116, align 8
  %v2916 = load i64, ptr %slot116, align 8
  %v2917 = load i64, ptr %slot70, align 8
  %p2918 = inttoptr i64 %v2917 to ptr
  store i64 %v2916, ptr %p2918, align 8, !alias.scope !3, !noalias !4
  %v2919 = load i64, ptr %slot70, align 8
  %p2920 = inttoptr i64 %v2919 to ptr
  %ld2921 = load i64, ptr %p2920, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2921, ptr %slot117, align 8
  %v2922 = load i64, ptr %slot69, align 8
  %p2923 = inttoptr i64 %v2922 to ptr
  %ld2924 = load i64, ptr %p2923, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2924, ptr %slot118, align 8
  %v2925 = load i64, ptr %slot118, align 8
  %v2926 = load i64, ptr %slot117, align 8
  %ovpair2928 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2925, i64 %v2926)
  %op2927 = extractvalue { i64, i1 } %ovpair2928, 0
  %ov2929 = extractvalue { i64, i1 } %ovpair2928, 1
  store i64 %op2927, ptr %slot119, align 8
  %v2930 = load i64, ptr %slot118, align 8
  %v2931 = load i64, ptr %slot117, align 8
  %op2932 = xor i64 %v2930, %v2931
  store i64 %op2932, ptr %slot120, align 8
  %v2933 = load i64, ptr %slot118, align 8
  %v2934 = load i64, ptr %slot119, align 8
  %op2935 = xor i64 %v2933, %v2934
  store i64 %op2935, ptr %slot121, align 8
  %v2936 = load i64, ptr %slot120, align 8
  %v2937 = load i64, ptr %slot121, align 8
  %op2938 = and i64 %v2936, %v2937
  store i64 %op2938, ptr %slot122, align 8
  %cv2939 = zext i1 %ov2929 to i64
  store i64 %cv2939, ptr %slot123, align 8
  %v2940 = load i64, ptr %slot123, align 8
  %cond2941 = icmp ne i64 %v2940, 0
  br i1 %cond2941, label %bb_overflow59, label %bb_checked59
bb_overflow59:
  %v2942 = load i64, ptr %slot1, align 8
  %p2943 = inttoptr i64 %v2942 to ptr
  %v2944 = load i64, ptr %slot118, align 8
  %v2945 = load i64, ptr %slot117, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2943, i64 1, i64 %v2944, i64 %v2945, i64 64) nomerge, !dbg !118
  unreachable
bb_checked59:
  %v2946 = load i64, ptr %slot119, align 8
  %v2947 = load i64, ptr %slot69, align 8
  %p2948 = inttoptr i64 %v2947 to ptr
  store i64 %v2946, ptr %p2948, align 8, !alias.scope !3, !noalias !4
  %v2949 = load i64, ptr %slot70, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  store i64 1, ptr %p2950, align 8, !alias.scope !3, !noalias !4
  %v2951 = load i64, ptr %slot70, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %ld2953 = load i64, ptr %p2952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2953, ptr %slot124, align 8
  %v2954 = load i64, ptr %slot69, align 8
  %p2955 = inttoptr i64 %v2954 to ptr
  %ld2956 = load i64, ptr %p2955, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2956, ptr %slot125, align 8
  %v2957 = load i64, ptr %slot125, align 8
  %v2958 = load i64, ptr %slot124, align 8
  %ovpair2960 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v2957, i64 %v2958)
  %op2959 = extractvalue { i64, i1 } %ovpair2960, 0
  %ov2961 = extractvalue { i64, i1 } %ovpair2960, 1
  store i64 %op2959, ptr %slot126, align 8
  %cv2962 = zext i1 %ov2961 to i64
  store i64 %cv2962, ptr %slot127, align 8
  %v2963 = load i64, ptr %slot127, align 8
  %cond2964 = icmp ne i64 %v2963, 0
  br i1 %cond2964, label %bb_overflow66, label %bb_checked66
bb_overflow66:
  %v2965 = load i64, ptr %slot1, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  %v2967 = load i64, ptr %slot125, align 8
  %v2968 = load i64, ptr %slot124, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p2966, i64 1, i64 %v2967, i64 %v2968, i64 64) nomerge, !dbg !120
  unreachable
bb_checked66:
  %v2969 = load i64, ptr %slot126, align 8
  %v2970 = load i64, ptr %slot69, align 8
  %p2971 = inttoptr i64 %v2970 to ptr
  store i64 %v2969, ptr %p2971, align 8, !alias.scope !3, !noalias !4
  %v2972 = load i64, ptr %slot69, align 8
  %p2973 = inttoptr i64 %v2972 to ptr
  %ld2974 = load i64, ptr %p2973, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2974, ptr %slot128, align 8
  %v2975 = load i64, ptr %slot128, align 8
  %v2976 = load i64, ptr %slot50, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  store i64 %v2975, ptr %p2977, align 8, !alias.scope !3, !noalias !4
  %v2978 = load i64, ptr %slot46, align 8
  %p2979 = inttoptr i64 %v2978 to ptr
  %ld2980 = load i64, ptr %p2979, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2980, ptr %slot129, align 8
  %v2981 = load i64, ptr %slot129, align 8
  %v2982 = load i64, ptr %slot75, align 8
  %p2983 = inttoptr i64 %v2981 to ptr
  %p2984 = inttoptr i64 %v2982 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2984, ptr %p2983, i64 304, i1 false), !alias.scope !10000000
  %v2985 = load i64, ptr %slot75, align 8
  %v2986 = load i64, ptr %slot69, align 8
  %p2987 = inttoptr i64 %v2986 to ptr
  store i64 %v2985, ptr %p2987, align 8, !alias.scope !3, !noalias !4
  %v2988 = load i64, ptr %slot69, align 8
  %p2989 = inttoptr i64 %v2988 to ptr
  %ld2990 = load i64, ptr %p2989, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2990, ptr %slot130, align 8
  %v2991 = load i64, ptr %slot130, align 8
  %op2992 = add i64 %v2991, 32
  store i64 %op2992, ptr %slot131, align 8
  %v2993 = load i64, ptr %slot131, align 8
  %v2994 = load i64, ptr %slot69, align 8
  %p2995 = inttoptr i64 %v2994 to ptr
  store i64 %v2993, ptr %p2995, align 8, !alias.scope !3, !noalias !4
  %v2996 = load i64, ptr %slot8, align 8
  %p2997 = inttoptr i64 %v2996 to ptr
  %ld2998 = load i32, ptr %p2997, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2998, ptr %slot132, align 8
  %v2999 = load i32, ptr %slot132, align 8
  %cv3000 = zext i32 %v2999 to i64
  %cond3001 = icmp ne i64 %cv3000, 0
  br i1 %cond3001, label %bb_rcslotdrop74, label %bb_rcslotdone74
bb_rcslotdrop74:
  %v3002 = load i64, ptr %slot8, align 8
  %p3003 = inttoptr i64 %v3002 to ptr
  store i32 0, ptr %p3003, align 4, !alias.scope !3, !noalias !4
  %v3004 = load i64, ptr %slot51, align 8
  store i64 %v3004, ptr %slot133, align 8
  %v3005 = load i64, ptr %slot9, align 8
  %p3006 = inttoptr i64 %v3005 to ptr
  %ld3007 = load i32, ptr %p3006, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3007, ptr %slot134, align 8
  %v3008 = load i32, ptr %slot134, align 8
  %op3009 = and i32 %v3008, 28
  store i32 %op3009, ptr %slot135, align 8
  %v3010 = load i32, ptr %slot135, align 8
  %cv3011 = zext i32 %v3010 to i64
  %cond3012 = icmp ne i64 %cv3011, 0
  br i1 %cond3012, label %bb_rcslotrole74, label %bb_rcslotowner74
bb_rcslotrole74:
  %v3013 = load i64, ptr %slot96, align 8
  store i64 %v3013, ptr %slot136, align 8
  %v3014 = load i64, ptr %slot136, align 8
  %v3015 = load i64, ptr %slot133, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3014, i64 %v3015) nomerge, !dbg !122
  br label %bb_rcslotdone74
bb_rcslotowner74:
  %v3016 = load i64, ptr %slot96, align 8
  store i64 %v3016, ptr %slot137, align 8
  %v3017 = load i64, ptr %slot137, align 8
  %v3018 = load i64, ptr %slot133, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3017, i64 %v3018) nomerge, !dbg !122
  br label %bb_rcslotdone74
bb_rcslotdone74:
  %v3019 = load i64, ptr %slot46, align 8
  %p3020 = inttoptr i64 %v3019 to ptr
  %ld3021 = load i64, ptr %p3020, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3021, ptr %slot138, align 8
  %v3022 = load i64, ptr %slot138, align 8
  %op3023 = add i64 %v3022, 32
  store i64 %op3023, ptr %slot139, align 8
  %v3024 = load i64, ptr %slot51, align 8
  store i64 %v3024, ptr %slot140, align 8
  %v3025 = load i64, ptr %slot139, align 8
  %v3026 = load i64, ptr %slot140, align 8
  %p3027 = inttoptr i64 %v3025 to ptr
  %p3028 = inttoptr i64 %v3026 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3028, ptr %p3027, i64 208, i1 false), !alias.scope !10000000
  %v3029 = load i64, ptr %slot139, align 8
  %p3030 = inttoptr i64 %v3029 to ptr
  call void @llvm.memset.p0.i64(ptr %p3030, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !122
  %v3031 = load i64, ptr %slot8, align 8
  %p3032 = inttoptr i64 %v3031 to ptr
  store i32 1, ptr %p3032, align 4, !alias.scope !3, !noalias !4
  %v3033 = load i64, ptr %slot51, align 8
  %v3034 = load i64, ptr %slot69, align 8
  %p3035 = inttoptr i64 %v3034 to ptr
  store i64 %v3033, ptr %p3035, align 8, !alias.scope !3, !noalias !4
  %v3036 = load i64, ptr %slot47, align 8
  %p3037 = inttoptr i64 %v3036 to ptr
  %ld3038 = load i64, ptr %p3037, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3038, ptr %slot141, align 8
  %v3039 = load i64, ptr %slot141, align 8
  %v3040 = load i64, ptr %slot70, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  store i64 %v3039, ptr %p3041, align 8, !alias.scope !3, !noalias !4
  %v3042 = load i64, ptr %slot1, align 8
  %call3043 = call { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64 %v3042) nomerge, !dbg !124
  store { i64, i64 } %call3043, ptr %callresult143, align 8
  %addr3044 = ptrtoint ptr %callresult143 to i64
  store i64 %addr3044, ptr %slot142, align 8
  %v3045 = load i64, ptr %slot142, align 8
  %v3046 = load i64, ptr %slot71, align 8
  %p3047 = inttoptr i64 %v3046 to ptr
  store i64 %v3045, ptr %p3047, align 8, !alias.scope !3, !noalias !4
  %v3048 = load i64, ptr %slot71, align 8
  %p3049 = inttoptr i64 %v3048 to ptr
  %ld3050 = load i64, ptr %p3049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3050, ptr %slot144, align 8
  %v3051 = load i64, ptr %slot41, align 8
  store i64 %v3051, ptr %slot145, align 8
  %v3052 = load i64, ptr %slot144, align 8
  %v3053 = load i64, ptr %slot145, align 8
  %p3054 = inttoptr i64 %v3052 to ptr
  %p3055 = inttoptr i64 %v3053 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3055, ptr %p3054, i64 16, i1 false)
  %v3056 = load i64, ptr %slot35, align 8
  %p3057 = inttoptr i64 %v3056 to ptr
  store i32 2, ptr %p3057, align 4, !alias.scope !3, !noalias !4
  %v3058 = load i64, ptr %slot34, align 8
  %p3059 = inttoptr i64 %v3058 to ptr
  store i32 1, ptr %p3059, align 4, !alias.scope !3, !noalias !4
  %v3060 = load i64, ptr %slot39, align 8
  store i64 %v3060, ptr %slot146, align 8
  %v3061 = load i64, ptr %slot41, align 8
  store i64 %v3061, ptr %slot147, align 8
  %v3062 = load i64, ptr %slot147, align 8
  %v3063 = load i64, ptr %slot146, align 8
  %p3064 = inttoptr i64 %v3062 to ptr
  %p3065 = inttoptr i64 %v3063 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3065, ptr %p3064, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3066 = load i64, ptr %slot33, align 8
  %p3067 = inttoptr i64 %v3066 to ptr
  store i32 2, ptr %p3067, align 4, !alias.scope !3, !noalias !4
  %v3068 = load i64, ptr %slot35, align 8
  %p3069 = inttoptr i64 %v3068 to ptr
  %ld3070 = load i32, ptr %p3069, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3070, ptr %slot148, align 8
  %v3071 = load i32, ptr %slot148, align 8
  %v3072 = load i64, ptr %slot33, align 8
  %p3073 = inttoptr i64 %v3072 to ptr
  store i32 %v3071, ptr %p3073, align 4, !alias.scope !3, !noalias !4
  %v3074 = load i64, ptr %slot34, align 8
  %p3075 = inttoptr i64 %v3074 to ptr
  store i32 0, ptr %p3075, align 4, !alias.scope !3, !noalias !4
  %v3076 = load i64, ptr %slot32, align 8
  %p3077 = inttoptr i64 %v3076 to ptr
  store i32 1, ptr %p3077, align 4, !alias.scope !3, !noalias !4
  %v3078 = load i64, ptr %slot146, align 8
  %v3079 = load i64, ptr %slot71, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  store i64 %v3078, ptr %p3080, align 8, !alias.scope !3, !noalias !4
  %v3081 = load i64, ptr %slot76, align 8
  store i64 %v3081, ptr %slot149, align 8
  %v3082 = load i64, ptr %slot149, align 8
  %p3083 = inttoptr i64 %v3082 to ptr
  store i64 0, ptr %p3083, align 8, !alias.scope !3, !noalias !4
  %v3084 = load i64, ptr %slot149, align 8
  %p3086 = inttoptr i64 %v3084 to ptr
  %gep3087 = getelementptr i8, ptr %p3086, i64 8
  %op3085 = ptrtoint ptr %gep3087 to i64
  store i64 %op3085, ptr %slot150, align 8
  %v3088 = load i64, ptr %slot150, align 8
  %p3089 = inttoptr i64 %v3088 to ptr
  store i64 0, ptr %p3089, align 8, !alias.scope !3, !noalias !4
  %v3090 = load i64, ptr %slot149, align 8
  %p3092 = inttoptr i64 %v3090 to ptr
  %gep3093 = getelementptr i8, ptr %p3092, i64 16
  %op3091 = ptrtoint ptr %gep3093 to i64
  store i64 %op3091, ptr %slot151, align 8
  %v3094 = load i64, ptr %slot151, align 8
  %p3095 = inttoptr i64 %v3094 to ptr
  store i64 0, ptr %p3095, align 8, !alias.scope !3, !noalias !4
  %v3096 = load i64, ptr %slot36, align 8
  %p3097 = inttoptr i64 %v3096 to ptr
  store i32 1, ptr %p3097, align 4, !alias.scope !3, !noalias !4
  %v3098 = load i64, ptr %slot97, align 8
  store i64 %v3098, ptr %slot152, align 8
  %v3099 = load i64, ptr %slot70, align 8
  store i64 %v3099, ptr %slot153, align 8
  %v3100 = load i64, ptr %slot149, align 8
  %p3102 = inttoptr i64 %v3100 to ptr
  %gep3103 = getelementptr i8, ptr %p3102, i64 0
  %op3101 = ptrtoint ptr %gep3103 to i64
  store i64 %op3101, ptr %slot154, align 8
  %v3104 = load i64, ptr %slot153, align 8
  %p3105 = inttoptr i64 %v3104 to ptr
  %ld3106 = load i64, ptr %p3105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3106, ptr %slot155, align 8
  %v3107 = load i64, ptr %slot155, align 8
  %v3108 = load i64, ptr %slot154, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  store i64 %v3107, ptr %p3109, align 8, !alias.scope !3, !noalias !4
  %v3110 = load i64, ptr %slot71, align 8
  %p3111 = inttoptr i64 %v3110 to ptr
  %ld3112 = load i64, ptr %p3111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3112, ptr %slot156, align 8
  %v3113 = load i64, ptr %slot149, align 8
  %p3115 = inttoptr i64 %v3113 to ptr
  %gep3116 = getelementptr i8, ptr %p3115, i64 8
  %op3114 = ptrtoint ptr %gep3116 to i64
  store i64 %op3114, ptr %slot157, align 8
  %v3117 = load i64, ptr %slot71, align 8
  %p3118 = inttoptr i64 %v3117 to ptr
  %ld3119 = load i64, ptr %p3118, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3119, ptr %slot158, align 8
  %v3120 = load i64, ptr %slot41, align 8
  store i64 %v3120, ptr %slot159, align 8
  %v3121 = load i64, ptr %slot97, align 8
  store i64 %v3121, ptr %slot160, align 8
  %v3122 = load i64, ptr %slot158, align 8
  %op3123 = add i64 %v3122, 0
  store i64 %op3123, ptr %slot161, align 8
  %v3124 = load i64, ptr %slot161, align 8
  %p3125 = inttoptr i64 %v3124 to ptr
  %ld3126 = load i64, ptr %p3125, align 8
  store i64 %ld3126, ptr %slot162, align 8
  %v3127 = load i64, ptr %slot162, align 8
  %cmp3128 = icmp ne i64 %v3127, 0
  %cv3129 = zext i1 %cmp3128 to i32
  store i32 %cv3129, ptr %slot163, align 8
  %v3130 = load i32, ptr %slot163, align 8
  %cv3131 = zext i32 %v3130 to i64
  %cond3132 = icmp ne i64 %cv3131, 0
  br i1 %cond3132, label %bb_rcmoveheader116, label %bb_rcmovenext116
bb_rcmoveheader116:
  %v3133 = load i64, ptr %slot162, align 8
  %op3134 = sub i64 %v3133, 16
  store i64 %op3134, ptr %slot164, align 8
  %v3135 = load i64, ptr %slot162, align 8
  %p3136 = inttoptr i64 %v3135 to ptr
  %rgep3137 = getelementptr i8, ptr %p3136, i64 -16
  %ld3138 = load i64, ptr %rgep3137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3138, ptr %slot165, align 8
  %v3139 = load i64, ptr %slot165, align 8
  %op3140 = and i64 %v3139, 5764607523034234881
  store i64 %op3140, ptr %slot166, align 8
  %v3141 = load i64, ptr %slot166, align 8
  %cmp3142 = icmp ne i64 %v3141, 0
  %cv3143 = zext i1 %cmp3142 to i32
  store i32 %cv3143, ptr %slot167, align 8
  %v3144 = load i32, ptr %slot167, align 8
  %cv3145 = zext i32 %v3144 to i64
  %cond3146 = icmp ne i64 %cv3145, 0
  br i1 %cond3146, label %bb_rcmoveslow113, label %bb_rcmovenext116
bb_rcmovenext116:
  %v3147 = load i64, ptr %slot158, align 8
  %v3148 = load i64, ptr %slot159, align 8
  %p3149 = inttoptr i64 %v3147 to ptr
  %p3150 = inttoptr i64 %v3148 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3150, ptr %p3149, i64 16, i1 false)
  %v3151 = load i64, ptr %slot158, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  store i64 0, ptr %p3152, align 8
  %v3153 = load i64, ptr %slot158, align 8
  %op3154 = add i64 %v3153, 8
  store i64 %op3154, ptr %slot168, align 8
  %v3155 = load i64, ptr %slot168, align 8
  %p3156 = inttoptr i64 %v3155 to ptr
  store i64 0, ptr %p3156, align 8
  br label %bb_rcmoved113
bb_rcmoveslow113:
  %v3157 = load i64, ptr %slot96, align 8
  %v3158 = load i64, ptr %slot159, align 8
  %v3159 = load i64, ptr %slot158, align 8
  %v3160 = load i64, ptr %slot160, align 8
  %cv3161 = trunc i64 %v3160 to i32
  %call3162 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v3157, i64 %v3158, i64 %v3159, i32 %cv3161) nomerge, !dbg !126
  store i32 %call3162, ptr %slot169, align 8
  %v3163 = load i32, ptr %slot169, align 8
  %cv3164 = zext i32 %v3163 to i64
  %cond3165 = icmp ne i64 %cv3164, 0
  br i1 %cond3165, label %bb_rcsuccess124, label %bb_rcfailure124
bb_rcfailure124:
  %v3166 = load i64, ptr %slot96, align 8
  %p3167 = inttoptr i64 %v3166 to ptr
  %call3168 = call i32 @myl_rc_take_failure(ptr %p3167) nomerge, !dbg !126
  store i32 %call3168, ptr %slot170, align 8
  %v3169 = load i64, ptr %slot1, align 8
  %p3170 = inttoptr i64 %v3169 to ptr
  %v3171 = load i32, ptr %slot170, align 8
  %call3172 = call i32 @myl_qbe_rc_status(ptr %p3170, i32 %v3171) nomerge, !dbg !126
  store i32 %call3172, ptr %slot171, align 8
  br label %bb_failure
bb_rcsuccess124:
  br label %bb_rcmoved113
bb_rcmoved113:
  %v3173 = load i64, ptr %slot32, align 8
  %p3174 = inttoptr i64 %v3173 to ptr
  store i32 0, ptr %p3174, align 4, !alias.scope !3, !noalias !4
  %v3175 = load i64, ptr %slot35, align 8
  %p3176 = inttoptr i64 %v3175 to ptr
  store i32 2, ptr %p3176, align 4, !alias.scope !3, !noalias !4
  %v3177 = load i64, ptr %slot34, align 8
  %p3178 = inttoptr i64 %v3177 to ptr
  store i32 1, ptr %p3178, align 4, !alias.scope !3, !noalias !4
  %v3179 = load i64, ptr %slot41, align 8
  store i64 %v3179, ptr %slot172, align 8
  %v3180 = load i64, ptr %slot172, align 8
  %v3181 = load i64, ptr %slot157, align 8
  %p3182 = inttoptr i64 %v3180 to ptr
  %p3183 = inttoptr i64 %v3181 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3183, ptr %p3182, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v3184 = load i64, ptr %slot34, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  store i32 0, ptr %p3185, align 4, !alias.scope !3, !noalias !4
  %v3186 = load i64, ptr %slot149, align 8
  %v3187 = load i64, ptr %slot70, align 8
  %p3188 = inttoptr i64 %v3187 to ptr
  store i64 %v3186, ptr %p3188, align 8, !alias.scope !3, !noalias !4
  %v3189 = load i64, ptr %slot70, align 8
  %p3190 = inttoptr i64 %v3189 to ptr
  %ld3191 = load i64, ptr %p3190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3191, ptr %slot173, align 8
  %v3192 = load i64, ptr %slot38, align 8
  store i64 %v3192, ptr %slot174, align 8
  %v3193 = load i64, ptr %slot173, align 8
  %v3194 = load i64, ptr %slot174, align 8
  %p3195 = inttoptr i64 %v3193 to ptr
  %p3196 = inttoptr i64 %v3194 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3196, ptr %p3195, i64 24, i1 false)
  %v3197 = load i64, ptr %slot31, align 8
  %p3198 = inttoptr i64 %v3197 to ptr
  store i32 2, ptr %p3198, align 4, !alias.scope !3, !noalias !4
  %v3199 = load i64, ptr %slot30, align 8
  %p3200 = inttoptr i64 %v3199 to ptr
  store i32 1, ptr %p3200, align 4, !alias.scope !3, !noalias !4
  %v3201 = load i64, ptr %slot174, align 8
  %v3202 = load i64, ptr %slot70, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  store i64 %v3201, ptr %p3203, align 8, !alias.scope !3, !noalias !4
  %v3204 = load i64, ptr %slot77, align 8
  store i64 %v3204, ptr %slot175, align 8
  %v3205 = load i64, ptr %slot175, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  store i64 0, ptr %p3206, align 8, !alias.scope !3, !noalias !4
  %v3207 = load i64, ptr %slot175, align 8
  %p3209 = inttoptr i64 %v3207 to ptr
  %gep3210 = getelementptr i8, ptr %p3209, i64 8
  %op3208 = ptrtoint ptr %gep3210 to i64
  store i64 %op3208, ptr %slot176, align 8
  %v3211 = load i64, ptr %slot176, align 8
  %p3212 = inttoptr i64 %v3211 to ptr
  store i64 0, ptr %p3212, align 8, !alias.scope !3, !noalias !4
  %v3213 = load i64, ptr %slot175, align 8
  %p3215 = inttoptr i64 %v3213 to ptr
  %gep3216 = getelementptr i8, ptr %p3215, i64 16
  %op3214 = ptrtoint ptr %gep3216 to i64
  store i64 %op3214, ptr %slot177, align 8
  %v3217 = load i64, ptr %slot177, align 8
  %p3218 = inttoptr i64 %v3217 to ptr
  store i64 0, ptr %p3218, align 8, !alias.scope !3, !noalias !4
  %v3219 = load i64, ptr %slot175, align 8
  %p3221 = inttoptr i64 %v3219 to ptr
  %gep3222 = getelementptr i8, ptr %p3221, i64 24
  %op3220 = ptrtoint ptr %gep3222 to i64
  store i64 %op3220, ptr %slot178, align 8
  %v3223 = load i64, ptr %slot178, align 8
  %p3224 = inttoptr i64 %v3223 to ptr
  store i64 0, ptr %p3224, align 8, !alias.scope !3, !noalias !4
  %v3225 = load i64, ptr %slot175, align 8
  %p3227 = inttoptr i64 %v3225 to ptr
  %gep3228 = getelementptr i8, ptr %p3227, i64 32
  %op3226 = ptrtoint ptr %gep3228 to i64
  store i64 %op3226, ptr %slot179, align 8
  %v3229 = load i64, ptr %slot179, align 8
  %p3230 = inttoptr i64 %v3229 to ptr
  store i64 0, ptr %p3230, align 8, !alias.scope !3, !noalias !4
  %v3231 = load i64, ptr %slot175, align 8
  %p3233 = inttoptr i64 %v3231 to ptr
  %gep3234 = getelementptr i8, ptr %p3233, i64 40
  %op3232 = ptrtoint ptr %gep3234 to i64
  store i64 %op3232, ptr %slot180, align 8
  %v3235 = load i64, ptr %slot180, align 8
  %p3236 = inttoptr i64 %v3235 to ptr
  store i64 0, ptr %p3236, align 8, !alias.scope !3, !noalias !4
  %v3237 = load i64, ptr %slot175, align 8
  %p3239 = inttoptr i64 %v3237 to ptr
  %gep3240 = getelementptr i8, ptr %p3239, i64 48
  %op3238 = ptrtoint ptr %gep3240 to i64
  store i64 %op3238, ptr %slot181, align 8
  %v3241 = load i64, ptr %slot181, align 8
  %p3242 = inttoptr i64 %v3241 to ptr
  store i64 0, ptr %p3242, align 8, !alias.scope !3, !noalias !4
  %v3243 = load i64, ptr %slot175, align 8
  %p3244 = inttoptr i64 %v3243 to ptr
  store i32 7, ptr %p3244, align 4, !alias.scope !3, !noalias !4
  %v3245 = load i64, ptr %slot36, align 8
  %p3246 = inttoptr i64 %v3245 to ptr
  store i32 1, ptr %p3246, align 4, !alias.scope !3, !noalias !4
  %v3247 = load i64, ptr %slot70, align 8
  %p3248 = inttoptr i64 %v3247 to ptr
  %ld3249 = load i64, ptr %p3248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3249, ptr %slot182, align 8
  %v3250 = load i64, ptr %slot175, align 8
  %p3252 = inttoptr i64 %v3250 to ptr
  %gep3253 = getelementptr i8, ptr %p3252, i64 8
  %op3251 = ptrtoint ptr %gep3253 to i64
  store i64 %op3251, ptr %slot183, align 8
  %v3254 = load i64, ptr %slot97, align 8
  store i64 %v3254, ptr %slot184, align 8
  %v3255 = load i64, ptr %slot70, align 8
  %p3256 = inttoptr i64 %v3255 to ptr
  %ld3257 = load i64, ptr %p3256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3257, ptr %slot185, align 8
  %v3258 = load i64, ptr %slot41, align 8
  store i64 %v3258, ptr %slot186, align 8
  %v3259 = load i64, ptr %slot97, align 8
  store i64 %v3259, ptr %slot187, align 8
  %v3260 = load i64, ptr %slot185, align 8
  %op3261 = add i64 %v3260, 8
  store i64 %op3261, ptr %slot188, align 8
  %v3262 = load i64, ptr %slot188, align 8
  %p3263 = inttoptr i64 %v3262 to ptr
  %ld3264 = load i64, ptr %p3263, align 8
  store i64 %ld3264, ptr %slot189, align 8
  %v3265 = load i64, ptr %slot189, align 8
  %cmp3266 = icmp ne i64 %v3265, 0
  %cv3267 = zext i1 %cmp3266 to i32
  store i32 %cv3267, ptr %slot190, align 8
  %v3268 = load i32, ptr %slot190, align 8
  %cv3269 = zext i32 %v3268 to i64
  %cond3270 = icmp ne i64 %cv3269, 0
  br i1 %cond3270, label %bb_rcmoveheader154, label %bb_rcmovenext154
bb_rcmoveheader154:
  %v3271 = load i64, ptr %slot189, align 8
  %op3272 = sub i64 %v3271, 16
  store i64 %op3272, ptr %slot191, align 8
  %v3273 = load i64, ptr %slot189, align 8
  %p3274 = inttoptr i64 %v3273 to ptr
  %rgep3275 = getelementptr i8, ptr %p3274, i64 -16
  %ld3276 = load i64, ptr %rgep3275, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3276, ptr %slot192, align 8
  %v3277 = load i64, ptr %slot192, align 8
  %op3278 = and i64 %v3277, 5764607523034234881
  store i64 %op3278, ptr %slot193, align 8
  %v3279 = load i64, ptr %slot193, align 8
  %cmp3280 = icmp ne i64 %v3279, 0
  %cv3281 = zext i1 %cmp3280 to i32
  store i32 %cv3281, ptr %slot194, align 8
  %v3282 = load i32, ptr %slot194, align 8
  %cv3283 = zext i32 %v3282 to i64
  %cond3284 = icmp ne i64 %cv3283, 0
  br i1 %cond3284, label %bb_rcmoveslow151, label %bb_rcmovenext154
bb_rcmovenext154:
  %v3285 = load i64, ptr %slot185, align 8
  %v3286 = load i64, ptr %slot186, align 8
  %p3287 = inttoptr i64 %v3285 to ptr
  %p3288 = inttoptr i64 %v3286 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3288, ptr %p3287, i64 24, i1 false)
  %v3289 = load i64, ptr %slot185, align 8
  %p3290 = inttoptr i64 %v3289 to ptr
  store i64 0, ptr %p3290, align 8
  %v3291 = load i64, ptr %slot185, align 8
  %op3292 = add i64 %v3291, 8
  store i64 %op3292, ptr %slot195, align 8
  %v3293 = load i64, ptr %slot195, align 8
  %p3294 = inttoptr i64 %v3293 to ptr
  store i64 0, ptr %p3294, align 8
  %v3295 = load i64, ptr %slot185, align 8
  %op3296 = add i64 %v3295, 16
  store i64 %op3296, ptr %slot196, align 8
  %v3297 = load i64, ptr %slot196, align 8
  %p3298 = inttoptr i64 %v3297 to ptr
  store i64 0, ptr %p3298, align 8
  br label %bb_rcmoved151
bb_rcmoveslow151:
  %v3299 = load i64, ptr %slot96, align 8
  %v3300 = load i64, ptr %slot186, align 8
  %v3301 = load i64, ptr %slot185, align 8
  %v3302 = load i64, ptr %slot187, align 8
  %cv3303 = trunc i64 %v3302 to i32
  %call3304 = call i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64 %v3299, i64 %v3300, i64 %v3301, i32 %cv3303) nomerge, !dbg !128
  store i32 %call3304, ptr %slot197, align 8
  %v3305 = load i32, ptr %slot197, align 8
  %cv3306 = zext i32 %v3305 to i64
  %cond3307 = icmp ne i64 %cv3306, 0
  br i1 %cond3307, label %bb_rcsuccess163, label %bb_rcfailure163
bb_rcfailure163:
  %v3308 = load i64, ptr %slot96, align 8
  %p3309 = inttoptr i64 %v3308 to ptr
  %call3310 = call i32 @myl_rc_take_failure(ptr %p3309) nomerge, !dbg !128
  store i32 %call3310, ptr %slot198, align 8
  %v3311 = load i64, ptr %slot1, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  %v3313 = load i32, ptr %slot198, align 8
  %call3314 = call i32 @myl_qbe_rc_status(ptr %p3312, i32 %v3313) nomerge, !dbg !128
  store i32 %call3314, ptr %slot199, align 8
  br label %bb_failure
bb_rcsuccess163:
  br label %bb_rcmoved151
bb_rcmoved151:
  %v3315 = load i64, ptr %slot30, align 8
  %p3316 = inttoptr i64 %v3315 to ptr
  store i32 0, ptr %p3316, align 4, !alias.scope !3, !noalias !4
  %v3317 = load i64, ptr %slot35, align 8
  %p3318 = inttoptr i64 %v3317 to ptr
  store i32 2, ptr %p3318, align 4, !alias.scope !3, !noalias !4
  %v3319 = load i64, ptr %slot34, align 8
  %p3320 = inttoptr i64 %v3319 to ptr
  store i32 1, ptr %p3320, align 4, !alias.scope !3, !noalias !4
  %v3321 = load i64, ptr %slot41, align 8
  store i64 %v3321, ptr %slot200, align 8
  %v3322 = load i64, ptr %slot200, align 8
  %v3323 = load i64, ptr %slot183, align 8
  %p3324 = inttoptr i64 %v3322 to ptr
  %p3325 = inttoptr i64 %v3323 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3325, ptr %p3324, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v3326 = load i64, ptr %slot34, align 8
  %p3327 = inttoptr i64 %v3326 to ptr
  store i32 0, ptr %p3327, align 4, !alias.scope !3, !noalias !4
  %v3328 = load i64, ptr %slot175, align 8
  %v3329 = load i64, ptr %slot70, align 8
  %p3330 = inttoptr i64 %v3329 to ptr
  store i64 %v3328, ptr %p3330, align 8, !alias.scope !3, !noalias !4
  %v3331 = load i64, ptr %slot70, align 8
  %p3332 = inttoptr i64 %v3331 to ptr
  %ld3333 = load i64, ptr %p3332, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3333, ptr %slot201, align 8
  %v3334 = load i64, ptr %slot38, align 8
  store i64 %v3334, ptr %slot202, align 8
  %v3335 = load i64, ptr %slot201, align 8
  %v3336 = load i64, ptr %slot202, align 8
  %p3337 = inttoptr i64 %v3335 to ptr
  %p3338 = inttoptr i64 %v3336 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3338, ptr %p3337, i64 56, i1 false)
  %v3339 = load i64, ptr %slot31, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i32 2, ptr %p3340, align 4, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot30, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  store i32 1, ptr %p3342, align 4, !alias.scope !3, !noalias !4
  %v3343 = load i64, ptr %slot202, align 8
  %v3344 = load i64, ptr %slot70, align 8
  %p3345 = inttoptr i64 %v3344 to ptr
  store i64 %v3343, ptr %p3345, align 8, !alias.scope !3, !noalias !4
  %v3346 = load i64, ptr %slot69, align 8
  %p3347 = inttoptr i64 %v3346 to ptr
  %ld3348 = load i64, ptr %p3347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3348, ptr %slot203, align 8
  %v3349 = load i64, ptr %slot70, align 8
  %p3350 = inttoptr i64 %v3349 to ptr
  %ld3351 = load i64, ptr %p3350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3351, ptr %slot204, align 8
  %v3352 = load i64, ptr %slot1, align 8
  %v3353 = load i64, ptr %slot203, align 8
  %v3354 = load i64, ptr %slot204, align 8
  %call3355 = call i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64 %v3352, i64 %v3353, i64 %v3354) nomerge, !dbg !130
  store i64 %call3355, ptr %slot205, align 8
  %v3356 = load i64, ptr %slot205, align 8
  %v3357 = load i64, ptr %slot69, align 8
  %p3358 = inttoptr i64 %v3357 to ptr
  store i64 %v3356, ptr %p3358, align 8, !alias.scope !3, !noalias !4
  %v3359 = load i64, ptr %slot28, align 8
  %p3360 = inttoptr i64 %v3359 to ptr
  %ld3361 = load i32, ptr %p3360, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3361, ptr %slot206, align 8
  %v3362 = load i32, ptr %slot206, align 8
  %cv3363 = zext i32 %v3362 to i64
  %cond3364 = icmp ne i64 %cv3363, 0
  br i1 %cond3364, label %bb_rcslotdrop180, label %bb_rcslotdone180
bb_rcslotdrop180:
  %v3365 = load i64, ptr %slot28, align 8
  %p3366 = inttoptr i64 %v3365 to ptr
  store i32 0, ptr %p3366, align 4, !alias.scope !3, !noalias !4
  %v3367 = load i64, ptr %slot37, align 8
  store i64 %v3367, ptr %slot207, align 8
  %v3368 = load i64, ptr %slot29, align 8
  %p3369 = inttoptr i64 %v3368 to ptr
  %ld3370 = load i32, ptr %p3369, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3370, ptr %slot208, align 8
  %v3371 = load i32, ptr %slot208, align 8
  %op3372 = and i32 %v3371, 28
  store i32 %op3372, ptr %slot209, align 8
  %v3373 = load i32, ptr %slot209, align 8
  %cv3374 = zext i32 %v3373 to i64
  %cond3375 = icmp ne i64 %cv3374, 0
  br i1 %cond3375, label %bb_rcslotrole180, label %bb_rcslotowner180
bb_rcslotrole180:
  %v3376 = load i64, ptr %slot96, align 8
  store i64 %v3376, ptr %slot210, align 8
  %v3377 = load i64, ptr %slot210, align 8
  %v3378 = load i64, ptr %slot207, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3377, i64 %v3378) nomerge, !dbg !130
  br label %bb_rcslotdone180
bb_rcslotowner180:
  %v3379 = load i64, ptr %slot96, align 8
  store i64 %v3379, ptr %slot211, align 8
  %v3380 = load i64, ptr %slot211, align 8
  %v3381 = load i64, ptr %slot207, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3380, i64 %v3381) nomerge, !dbg !130
  br label %bb_rcslotdone180
bb_rcslotdone180:
  %v3382 = load i64, ptr %slot30, align 8
  %p3383 = inttoptr i64 %v3382 to ptr
  %ld3384 = load i32, ptr %p3383, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3384, ptr %slot212, align 8
  %v3385 = load i32, ptr %slot212, align 8
  %cv3386 = zext i32 %v3385 to i64
  %cond3387 = icmp ne i64 %cv3386, 0
  br i1 %cond3387, label %bb_rcslotdrop189, label %bb_rcslotdone189
bb_rcslotdrop189:
  %v3388 = load i64, ptr %slot30, align 8
  %p3389 = inttoptr i64 %v3388 to ptr
  store i32 0, ptr %p3389, align 4, !alias.scope !3, !noalias !4
  %v3390 = load i64, ptr %slot38, align 8
  store i64 %v3390, ptr %slot213, align 8
  %v3391 = load i64, ptr %slot31, align 8
  %p3392 = inttoptr i64 %v3391 to ptr
  %ld3393 = load i32, ptr %p3392, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3393, ptr %slot214, align 8
  %v3394 = load i32, ptr %slot214, align 8
  %op3395 = and i32 %v3394, 28
  store i32 %op3395, ptr %slot215, align 8
  %v3396 = load i32, ptr %slot215, align 8
  %cv3397 = zext i32 %v3396 to i64
  %cond3398 = icmp ne i64 %cv3397, 0
  br i1 %cond3398, label %bb_rcslotrole189, label %bb_rcslotowner189
bb_rcslotrole189:
  %v3399 = load i64, ptr %slot96, align 8
  store i64 %v3399, ptr %slot216, align 8
  %v3400 = load i64, ptr %slot216, align 8
  %v3401 = load i64, ptr %slot213, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64 %v3400, i64 %v3401) nomerge, !dbg !130
  br label %bb_rcslotdone189
bb_rcslotowner189:
  %v3402 = load i64, ptr %slot96, align 8
  store i64 %v3402, ptr %slot217, align 8
  %v3403 = load i64, ptr %slot217, align 8
  %v3404 = load i64, ptr %slot213, align 8
  call void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64 %v3403, i64 %v3404) nomerge, !dbg !130
  br label %bb_rcslotdone189
bb_rcslotdone189:
  %v3405 = load i64, ptr %slot69, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  %ld3407 = load i64, ptr %p3406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3407, ptr %slot218, align 8
  %v3408 = load i64, ptr %slot218, align 8
  %v3409 = load i64, ptr %slot52, align 8
  %p3410 = inttoptr i64 %v3409 to ptr
  store i64 %v3408, ptr %p3410, align 8, !alias.scope !3, !noalias !4
  %v3411 = load i64, ptr %slot46, align 8
  %p3412 = inttoptr i64 %v3411 to ptr
  %ld3413 = load i64, ptr %p3412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3413, ptr %slot219, align 8
  %v3414 = load i64, ptr %slot219, align 8
  %op3415 = add i64 %v3414, 32
  store i64 %op3415, ptr %slot220, align 8
  %v3416 = load i64, ptr %slot51, align 8
  store i64 %v3416, ptr %slot221, align 8
  %v3417 = load i64, ptr %slot221, align 8
  %v3418 = load i64, ptr %slot220, align 8
  %p3419 = inttoptr i64 %v3417 to ptr
  %p3420 = inttoptr i64 %v3418 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3420, ptr %p3419, i64 208, i1 false), !alias.scope !10000000
  %v3421 = load i64, ptr %slot221, align 8
  %p3422 = inttoptr i64 %v3421 to ptr
  call void @llvm.memset.p0.i64(ptr %p3422, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v3423 = load i64, ptr %slot8, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  store i32 0, ptr %p3424, align 4, !alias.scope !3, !noalias !4
  %v3425 = load i64, ptr %slot69, align 8
  %p3426 = inttoptr i64 %v3425 to ptr
  store i64 0, ptr %p3426, align 8, !alias.scope !3, !noalias !4
  %v3427 = load i64, ptr %slot52, align 8
  %p3428 = inttoptr i64 %v3427 to ptr
  %ld3429 = load i64, ptr %p3428, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3429, ptr %slot222, align 8
  %v3430 = load i64, ptr %slot222, align 8
  %v3431 = load i64, ptr %slot69, align 8
  %p3432 = inttoptr i64 %v3431 to ptr
  store i64 %v3430, ptr %p3432, align 8, !alias.scope !3, !noalias !4
  %v3433 = load i64, ptr %slot78, align 8
  store i64 %v3433, ptr %slot223, align 8
  %v3434 = load i64, ptr %slot223, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  store i64 0, ptr %p3435, align 8, !alias.scope !3, !noalias !4
  %v3436 = load i64, ptr %slot223, align 8
  %p3438 = inttoptr i64 %v3436 to ptr
  %gep3439 = getelementptr i8, ptr %p3438, i64 8
  %op3437 = ptrtoint ptr %gep3439 to i64
  store i64 %op3437, ptr %slot224, align 8
  %v3440 = load i64, ptr %slot224, align 8
  %p3441 = inttoptr i64 %v3440 to ptr
  store i64 0, ptr %p3441, align 8, !alias.scope !3, !noalias !4
  %v3442 = load i64, ptr %slot223, align 8
  %p3443 = inttoptr i64 %v3442 to ptr
  store i32 3, ptr %p3443, align 4, !alias.scope !3, !noalias !4
  %v3444 = load i64, ptr %slot36, align 8
  %p3445 = inttoptr i64 %v3444 to ptr
  store i32 1, ptr %p3445, align 4, !alias.scope !3, !noalias !4
  %v3446 = load i64, ptr %slot69, align 8
  store i64 %v3446, ptr %slot225, align 8
  %v3447 = load i64, ptr %slot223, align 8
  %p3449 = inttoptr i64 %v3447 to ptr
  %gep3450 = getelementptr i8, ptr %p3449, i64 8
  %op3448 = ptrtoint ptr %gep3450 to i64
  store i64 %op3448, ptr %slot226, align 8
  %v3451 = load i64, ptr %slot97, align 8
  store i64 %v3451, ptr %slot227, align 8
  %v3452 = load i64, ptr %slot225, align 8
  %p3453 = inttoptr i64 %v3452 to ptr
  %ld3454 = load i64, ptr %p3453, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3454, ptr %slot228, align 8
  %v3455 = load i64, ptr %slot228, align 8
  %v3456 = load i64, ptr %slot226, align 8
  %p3457 = inttoptr i64 %v3456 to ptr
  store i64 %v3455, ptr %p3457, align 8, !alias.scope !3, !noalias !4
  %v3458 = load i64, ptr %slot223, align 8
  %v3459 = load i64, ptr %slot69, align 8
  %p3460 = inttoptr i64 %v3459 to ptr
  store i64 %v3458, ptr %p3460, align 8, !alias.scope !3, !noalias !4
  %v3461 = load i64, ptr %slot69, align 8
  %p3462 = inttoptr i64 %v3461 to ptr
  %ld3463 = load i64, ptr %p3462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3463, ptr %slot229, align 8
  %v3464 = load i64, ptr %slot229, align 8
  %v3465 = load i64, ptr %slot54, align 8
  %p3466 = inttoptr i64 %v3464 to ptr
  %p3467 = inttoptr i64 %v3465 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3467, ptr %p3466, i64 16, i1 false)
  %v3468 = load i64, ptr %slot46, align 8
  %p3469 = inttoptr i64 %v3468 to ptr
  %ld3470 = load i64, ptr %p3469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3470, ptr %slot230, align 8
  %v3471 = load i64, ptr %slot230, align 8
  %v3472 = load i64, ptr %slot69, align 8
  %p3473 = inttoptr i64 %v3472 to ptr
  store i64 %v3471, ptr %p3473, align 8, !alias.scope !3, !noalias !4
  %v3474 = load i64, ptr %slot69, align 8
  %p3475 = inttoptr i64 %v3474 to ptr
  %ld3476 = load i64, ptr %p3475, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3476, ptr %slot231, align 8
  %v3477 = load i64, ptr %slot231, align 8
  %op3478 = add i64 %v3477, 32
  store i64 %op3478, ptr %slot232, align 8
  %v3479 = load i64, ptr %slot232, align 8
  %v3480 = load i64, ptr %slot69, align 8
  %p3481 = inttoptr i64 %v3480 to ptr
  store i64 %v3479, ptr %p3481, align 8, !alias.scope !3, !noalias !4
  %v3482 = load i64, ptr %slot28, align 8
  %p3483 = inttoptr i64 %v3482 to ptr
  %ld3484 = load i32, ptr %p3483, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3484, ptr %slot233, align 8
  %v3485 = load i32, ptr %slot233, align 8
  %cv3486 = zext i32 %v3485 to i64
  %cond3487 = icmp ne i64 %cv3486, 0
  br i1 %cond3487, label %bb_rcslotdrop216, label %bb_rcslotdone216
bb_rcslotdrop216:
  %v3488 = load i64, ptr %slot28, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  store i32 0, ptr %p3489, align 4, !alias.scope !3, !noalias !4
  %v3490 = load i64, ptr %slot37, align 8
  store i64 %v3490, ptr %slot234, align 8
  %v3491 = load i64, ptr %slot29, align 8
  %p3492 = inttoptr i64 %v3491 to ptr
  %ld3493 = load i32, ptr %p3492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3493, ptr %slot235, align 8
  %v3494 = load i32, ptr %slot235, align 8
  %op3495 = and i32 %v3494, 28
  store i32 %op3495, ptr %slot236, align 8
  %v3496 = load i32, ptr %slot236, align 8
  %cv3497 = zext i32 %v3496 to i64
  %cond3498 = icmp ne i64 %cv3497, 0
  br i1 %cond3498, label %bb_rcslotrole216, label %bb_rcslotowner216
bb_rcslotrole216:
  %v3499 = load i64, ptr %slot96, align 8
  store i64 %v3499, ptr %slot237, align 8
  %v3500 = load i64, ptr %slot237, align 8
  %v3501 = load i64, ptr %slot234, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v3500, i64 %v3501) nomerge, !dbg !134
  br label %bb_rcslotdone216
bb_rcslotowner216:
  %v3502 = load i64, ptr %slot96, align 8
  store i64 %v3502, ptr %slot238, align 8
  %v3503 = load i64, ptr %slot238, align 8
  %v3504 = load i64, ptr %slot234, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v3503, i64 %v3504) nomerge, !dbg !134
  br label %bb_rcslotdone216
bb_rcslotdone216:
  %v3505 = load i64, ptr %slot69, align 8
  %p3506 = inttoptr i64 %v3505 to ptr
  %ld3507 = load i64, ptr %p3506, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3507, ptr %slot239, align 8
  %v3508 = load i64, ptr %slot239, align 8
  %op3509 = add i64 %v3508, 120
  store i64 %op3509, ptr %slot240, align 8
  %v3510 = load i64, ptr %slot240, align 8
  %p3511 = inttoptr i64 %v3510 to ptr
  %ld3512 = load i64, ptr %p3511, align 8
  store i64 %ld3512, ptr %slot241, align 8
  %v3513 = load i64, ptr %slot241, align 8
  %v3514 = load i64, ptr %slot69, align 8
  %p3515 = inttoptr i64 %v3514 to ptr
  store i64 %v3513, ptr %p3515, align 8, !alias.scope !3, !noalias !4
  %v3516 = load i64, ptr %slot69, align 8
  %p3517 = inttoptr i64 %v3516 to ptr
  %ld3518 = load i64, ptr %p3517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3518, ptr %slot242, align 8
  %v3519 = load i64, ptr %slot242, align 8
  %v3520 = load i64, ptr %slot40, align 8
  %p3521 = inttoptr i64 %v3520 to ptr
  store i64 %v3519, ptr %p3521, align 8, !alias.scope !3, !noalias !4
  %v3522 = load i64, ptr %slot40, align 8
  store i64 %v3522, ptr %slot243, align 8
  %v3523 = load i64, ptr %slot41, align 8
  store i64 %v3523, ptr %slot244, align 8
  %v3524 = load i64, ptr %slot243, align 8
  %p3525 = inttoptr i64 %v3524 to ptr
  %ld3526 = load i64, ptr %p3525, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3526, ptr %slot245, align 8
  %v3527 = load i64, ptr %slot245, align 8
  %cmp3528 = icmp ne i64 %v3527, 0
  %cv3529 = zext i1 %cmp3528 to i32
  store i32 %cv3529, ptr %slot246, align 8
  %v3530 = load i32, ptr %slot246, align 8
  %cv3531 = zext i32 %v3530 to i64
  %cond3532 = icmp ne i64 %cv3531, 0
  br i1 %cond3532, label %bb_rcgnn230, label %bb_rcgstore230
bb_rcgnn230:
  %v3533 = load i64, ptr %slot245, align 8
  %op3534 = sub i64 %v3533, 16
  store i64 %op3534, ptr %slot247, align 8
  %v3535 = load i64, ptr %slot245, align 8
  %p3536 = inttoptr i64 %v3535 to ptr
  %rgep3537 = getelementptr i8, ptr %p3536, i64 -16
  %ld3538 = load i64, ptr %rgep3537, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3538, ptr %slot248, align 8
  %v3539 = load i64, ptr %slot248, align 8
  %op3540 = and i64 %v3539, 4611686018427387906
  store i64 %op3540, ptr %slot249, align 8
  %v3541 = load i64, ptr %slot249, align 8
  %cmp3542 = icmp ne i64 %v3541, 0
  %cv3543 = zext i1 %cmp3542 to i32
  store i32 %cv3543, ptr %slot250, align 8
  %v3544 = load i32, ptr %slot250, align 8
  %cv3545 = zext i32 %v3544 to i64
  %cond3546 = icmp ne i64 %cv3545, 0
  br i1 %cond3546, label %bb_rcgstore230, label %bb_rcginc230
bb_rcginc230:
  %v3547 = load i64, ptr %slot245, align 8
  %op3548 = sub i64 %v3547, 24
  store i64 %op3548, ptr %slot251, align 8
  %v3549 = load i64, ptr %slot245, align 8
  %p3550 = inttoptr i64 %v3549 to ptr
  %rgep3551 = getelementptr i8, ptr %p3550, i64 -24
  %ld3552 = load i64, ptr %rgep3551, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3552, ptr %slot252, align 8
  %v3553 = load i64, ptr %slot252, align 8
  %op3554 = add i64 %v3553, 1
  store i64 %op3554, ptr %slot253, align 8
  %v3555 = load i64, ptr %slot253, align 8
  %cmp3556 = icmp eq i64 %v3555, 0
  %cv3557 = zext i1 %cmp3556 to i32
  store i32 %cv3557, ptr %slot254, align 8
  %v3558 = load i32, ptr %slot254, align 8
  %cv3559 = zext i32 %v3558 to i64
  %cond3560 = icmp ne i64 %cv3559, 0
  br i1 %cond3560, label %bb_rcglimit230, label %bb_rcgcapacity230
bb_rcglimit230:
  %v3561 = load i64, ptr %slot1, align 8
  %p3562 = inttoptr i64 %v3561 to ptr
  %call3563 = call i32 @myl_qbe_rc_status(ptr %p3562, i32 2) nomerge, !dbg !136
  store i32 %call3563, ptr %slot255, align 8
  br label %bb_failure
bb_rcgcapacity230:
  %v3564 = load i64, ptr %slot253, align 8
  %v3565 = load i64, ptr %slot245, align 8
  %p3566 = inttoptr i64 %v3565 to ptr
  %rgep3567 = getelementptr i8, ptr %p3566, i64 -24
  store i64 %v3564, ptr %rgep3567, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore230
bb_rcgstore230:
  %v3568 = load i64, ptr %slot245, align 8
  %v3569 = load i64, ptr %slot244, align 8
  %p3570 = inttoptr i64 %v3569 to ptr
  store i64 %v3568, ptr %p3570, align 8, !alias.scope !3, !noalias !4
  %v3571 = load i64, ptr %slot35, align 8
  %p3572 = inttoptr i64 %v3571 to ptr
  store i32 2, ptr %p3572, align 4, !alias.scope !3, !noalias !4
  %v3573 = load i64, ptr %slot35, align 8
  %p3574 = inttoptr i64 %v3573 to ptr
  store i32 16, ptr %p3574, align 4, !alias.scope !3, !noalias !4
  %v3575 = load i64, ptr %slot34, align 8
  %p3576 = inttoptr i64 %v3575 to ptr
  store i32 1, ptr %p3576, align 4, !alias.scope !3, !noalias !4
  %v3577 = load i64, ptr %slot28, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  %ld3579 = load i32, ptr %p3578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3579, ptr %slot256, align 8
  %v3580 = load i32, ptr %slot256, align 8
  %cv3581 = zext i32 %v3580 to i64
  %cond3582 = icmp ne i64 %cv3581, 0
  br i1 %cond3582, label %bb_rcslotdrop246, label %bb_rcslotdone246
bb_rcslotdrop246:
  %v3583 = load i64, ptr %slot28, align 8
  %p3584 = inttoptr i64 %v3583 to ptr
  store i32 0, ptr %p3584, align 4, !alias.scope !3, !noalias !4
  %v3585 = load i64, ptr %slot37, align 8
  store i64 %v3585, ptr %slot257, align 8
  %v3586 = load i64, ptr %slot29, align 8
  %p3587 = inttoptr i64 %v3586 to ptr
  %ld3588 = load i32, ptr %p3587, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3588, ptr %slot258, align 8
  %v3589 = load i32, ptr %slot258, align 8
  %op3590 = and i32 %v3589, 28
  store i32 %op3590, ptr %slot259, align 8
  %v3591 = load i32, ptr %slot259, align 8
  %cv3592 = zext i32 %v3591 to i64
  %cond3593 = icmp ne i64 %cv3592, 0
  br i1 %cond3593, label %bb_rcslotrole246, label %bb_rcslotowner246
bb_rcslotrole246:
  %v3594 = load i64, ptr %slot96, align 8
  store i64 %v3594, ptr %slot260, align 8
  %v3595 = load i64, ptr %slot260, align 8
  %v3596 = load i64, ptr %slot257, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v3595, i64 %v3596) nomerge, !dbg !136
  br label %bb_rcslotdone246
bb_rcslotowner246:
  %v3597 = load i64, ptr %slot96, align 8
  store i64 %v3597, ptr %slot261, align 8
  %v3598 = load i64, ptr %slot261, align 8
  %v3599 = load i64, ptr %slot257, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v3598, i64 %v3599) nomerge, !dbg !136
  br label %bb_rcslotdone246
bb_rcslotdone246:
  %v3600 = load i64, ptr %slot37, align 8
  store i64 %v3600, ptr %slot262, align 8
  %v3601 = load i64, ptr %slot41, align 8
  store i64 %v3601, ptr %slot263, align 8
  %v3602 = load i64, ptr %slot263, align 8
  %v3603 = load i64, ptr %slot262, align 8
  %p3604 = inttoptr i64 %v3602 to ptr
  %p3605 = inttoptr i64 %v3603 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3605, ptr %p3604, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3606 = load i64, ptr %slot29, align 8
  %p3607 = inttoptr i64 %v3606 to ptr
  store i32 2, ptr %p3607, align 4, !alias.scope !3, !noalias !4
  %v3608 = load i64, ptr %slot35, align 8
  %p3609 = inttoptr i64 %v3608 to ptr
  %ld3610 = load i32, ptr %p3609, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3610, ptr %slot264, align 8
  %v3611 = load i32, ptr %slot264, align 8
  %v3612 = load i64, ptr %slot29, align 8
  %p3613 = inttoptr i64 %v3612 to ptr
  store i32 %v3611, ptr %p3613, align 4, !alias.scope !3, !noalias !4
  %v3614 = load i64, ptr %slot34, align 8
  %p3615 = inttoptr i64 %v3614 to ptr
  store i32 0, ptr %p3615, align 4, !alias.scope !3, !noalias !4
  %v3616 = load i64, ptr %slot28, align 8
  %p3617 = inttoptr i64 %v3616 to ptr
  store i32 1, ptr %p3617, align 4, !alias.scope !3, !noalias !4
  %v3618 = load i64, ptr %slot262, align 8
  %p3619 = inttoptr i64 %v3618 to ptr
  %ld3620 = load i64, ptr %p3619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3620, ptr %slot265, align 8
  %v3621 = load i64, ptr %slot265, align 8
  %v3622 = load i64, ptr %slot69, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  store i64 %v3621, ptr %p3623, align 8, !alias.scope !3, !noalias !4
  %v3624 = load i64, ptr %slot69, align 8
  %p3625 = inttoptr i64 %v3624 to ptr
  %ld3626 = load i64, ptr %p3625, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3626, ptr %slot266, align 8
  %v3627 = load i64, ptr %slot46, align 8
  %p3628 = inttoptr i64 %v3627 to ptr
  %ld3629 = load i64, ptr %p3628, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3629, ptr %slot267, align 8
  %v3630 = load i64, ptr %slot28, align 8
  %p3631 = inttoptr i64 %v3630 to ptr
  %ld3632 = load i32, ptr %p3631, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3632, ptr %slot268, align 8
  %v3633 = load i32, ptr %slot268, align 8
  %cv3634 = zext i32 %v3633 to i64
  %cond3635 = icmp ne i64 %cv3634, 0
  br i1 %cond3635, label %bb_rcslotdrop267, label %bb_rcslotdone267
bb_rcslotdrop267:
  %v3636 = load i64, ptr %slot28, align 8
  %p3637 = inttoptr i64 %v3636 to ptr
  store i32 0, ptr %p3637, align 4, !alias.scope !3, !noalias !4
  %v3638 = load i64, ptr %slot37, align 8
  store i64 %v3638, ptr %slot269, align 8
  %v3639 = load i64, ptr %slot29, align 8
  %p3640 = inttoptr i64 %v3639 to ptr
  %ld3641 = load i32, ptr %p3640, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3641, ptr %slot270, align 8
  %v3642 = load i32, ptr %slot270, align 8
  %op3643 = and i32 %v3642, 28
  store i32 %op3643, ptr %slot271, align 8
  %v3644 = load i32, ptr %slot271, align 8
  %cv3645 = zext i32 %v3644 to i64
  %cond3646 = icmp ne i64 %cv3645, 0
  br i1 %cond3646, label %bb_rcslotrole267, label %bb_rcslotowner267
bb_rcslotrole267:
  %v3647 = load i64, ptr %slot96, align 8
  store i64 %v3647, ptr %slot272, align 8
  %v3648 = load i64, ptr %slot269, align 8
  %p3649 = inttoptr i64 %v3648 to ptr
  %ld3650 = load i64, ptr %p3649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3650, ptr %slot273, align 8
  %v3651 = load i64, ptr %slot273, align 8
  %cmp3652 = icmp ne i64 %v3651, 0
  %cv3653 = zext i1 %cmp3652 to i32
  store i32 %cv3653, ptr %slot274, align 8
  %v3654 = load i32, ptr %slot274, align 8
  %cv3655 = zext i32 %v3654 to i64
  %cond3656 = icmp ne i64 %cv3655, 0
  br i1 %cond3656, label %bb_rcgnn283, label %bb_rcgdone283
bb_rcgnn283:
  %v3657 = load i64, ptr %slot273, align 8
  %op3658 = sub i64 %v3657, 16
  store i64 %op3658, ptr %slot275, align 8
  %v3659 = load i64, ptr %slot273, align 8
  %p3660 = inttoptr i64 %v3659 to ptr
  %rgep3661 = getelementptr i8, ptr %p3660, i64 -16
  %ld3662 = load i64, ptr %rgep3661, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3662, ptr %slot276, align 8
  %v3663 = load i64, ptr %slot276, align 8
  %op3664 = and i64 %v3663, 4611686018427387906
  store i64 %op3664, ptr %slot277, align 8
  %v3665 = load i64, ptr %slot277, align 8
  %cmp3666 = icmp ne i64 %v3665, 0
  %cv3667 = zext i1 %cmp3666 to i32
  store i32 %cv3667, ptr %slot278, align 8
  %v3668 = load i32, ptr %slot278, align 8
  %cv3669 = zext i32 %v3668 to i64
  %cond3670 = icmp ne i64 %cv3669, 0
  br i1 %cond3670, label %bb_rcgclear283, label %bb_rcgcounted283
bb_rcgcounted283:
  %v3671 = load i64, ptr %slot273, align 8
  %op3672 = sub i64 %v3671, 24
  store i64 %op3672, ptr %slot279, align 8
  %v3673 = load i64, ptr %slot273, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %rgep3675 = getelementptr i8, ptr %p3674, i64 -24
  %ld3676 = load i64, ptr %rgep3675, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3676, ptr %slot280, align 8
  %v3677 = load i64, ptr %slot280, align 8
  %op3678 = sub i64 %v3677, 1
  store i64 %op3678, ptr %slot281, align 8
  %v3679 = load i64, ptr %slot281, align 8
  %cmp3680 = icmp eq i64 %v3679, 0
  %cv3681 = zext i1 %cmp3680 to i32
  store i32 %cv3681, ptr %slot282, align 8
  %v3682 = load i32, ptr %slot282, align 8
  %cv3683 = zext i32 %v3682 to i64
  %cond3684 = icmp ne i64 %cv3683, 0
  br i1 %cond3684, label %bb_rcglast283, label %bb_rcgdec283
bb_rcglast283:
  %v3685 = load i64, ptr %slot273, align 8
  %op3686 = sub i64 %v3685, 32
  store i64 %op3686, ptr %slot283, align 8
  %v3687 = load i64, ptr %slot273, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %rgep3689 = getelementptr i8, ptr %p3688, i64 -32
  %ld3690 = load i64, ptr %rgep3689, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3690, ptr %slot284, align 8
  %v3691 = load i64, ptr %slot284, align 8
  %cmp3692 = icmp ne i64 %v3691, 0
  %cv3693 = zext i1 %cmp3692 to i32
  store i32 %cv3693, ptr %slot285, align 8
  %v3694 = load i32, ptr %slot285, align 8
  %cv3695 = zext i32 %v3694 to i64
  %cond3696 = icmp ne i64 %cv3695, 0
  br i1 %cond3696, label %bb_rcgdec283, label %bb_rcgslow283
bb_rcgslow283:
  %v3697 = load i64, ptr %slot272, align 8
  %v3698 = load i64, ptr %slot269, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3697, i64 %v3698) nomerge, !dbg !138
  br label %bb_rcgdone283
bb_rcgdec283:
  %v3699 = load i64, ptr %slot281, align 8
  %v3700 = load i64, ptr %slot273, align 8
  %p3701 = inttoptr i64 %v3700 to ptr
  %rgep3702 = getelementptr i8, ptr %p3701, i64 -24
  store i64 %v3699, ptr %rgep3702, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear283
bb_rcgclear283:
  %v3703 = load i64, ptr %slot269, align 8
  %p3704 = inttoptr i64 %v3703 to ptr
  store i64 0, ptr %p3704, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone283
bb_rcgdone283:
  br label %bb_rcslotdone267
bb_rcslotowner267:
  %v3705 = load i64, ptr %slot96, align 8
  store i64 %v3705, ptr %slot286, align 8
  %v3706 = load i64, ptr %slot269, align 8
  %p3707 = inttoptr i64 %v3706 to ptr
  %ld3708 = load i64, ptr %p3707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3708, ptr %slot287, align 8
  %v3709 = load i64, ptr %slot287, align 8
  %cmp3710 = icmp ne i64 %v3709, 0
  %cv3711 = zext i1 %cmp3710 to i32
  store i32 %cv3711, ptr %slot288, align 8
  %v3712 = load i32, ptr %slot288, align 8
  %cv3713 = zext i32 %v3712 to i64
  %cond3714 = icmp ne i64 %cv3713, 0
  br i1 %cond3714, label %bb_rcgnn298, label %bb_rcgdone298
bb_rcgnn298:
  %v3715 = load i64, ptr %slot287, align 8
  %op3716 = sub i64 %v3715, 16
  store i64 %op3716, ptr %slot289, align 8
  %v3717 = load i64, ptr %slot287, align 8
  %p3718 = inttoptr i64 %v3717 to ptr
  %rgep3719 = getelementptr i8, ptr %p3718, i64 -16
  %ld3720 = load i64, ptr %rgep3719, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3720, ptr %slot290, align 8
  %v3721 = load i64, ptr %slot290, align 8
  %op3722 = and i64 %v3721, 4611686018427387906
  store i64 %op3722, ptr %slot291, align 8
  %v3723 = load i64, ptr %slot291, align 8
  %cmp3724 = icmp ne i64 %v3723, 0
  %cv3725 = zext i1 %cmp3724 to i32
  store i32 %cv3725, ptr %slot292, align 8
  %v3726 = load i32, ptr %slot292, align 8
  %cv3727 = zext i32 %v3726 to i64
  %cond3728 = icmp ne i64 %cv3727, 0
  br i1 %cond3728, label %bb_rcgclear298, label %bb_rcgcounted298
bb_rcgcounted298:
  %v3729 = load i64, ptr %slot287, align 8
  %op3730 = sub i64 %v3729, 32
  store i64 %op3730, ptr %slot293, align 8
  %v3731 = load i64, ptr %slot287, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  %rgep3733 = getelementptr i8, ptr %p3732, i64 -32
  %ld3734 = load i64, ptr %rgep3733, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3734, ptr %slot294, align 8
  %v3735 = load i64, ptr %slot294, align 8
  %op3736 = sub i64 %v3735, 1
  store i64 %op3736, ptr %slot295, align 8
  %v3737 = load i64, ptr %slot295, align 8
  %cmp3738 = icmp eq i64 %v3737, 0
  %cv3739 = zext i1 %cmp3738 to i32
  store i32 %cv3739, ptr %slot296, align 8
  %v3740 = load i32, ptr %slot296, align 8
  %cv3741 = zext i32 %v3740 to i64
  %cond3742 = icmp ne i64 %cv3741, 0
  br i1 %cond3742, label %bb_rcglast298, label %bb_rcgdec298
bb_rcglast298:
  %v3743 = load i64, ptr %slot287, align 8
  %op3744 = sub i64 %v3743, 24
  store i64 %op3744, ptr %slot297, align 8
  %v3745 = load i64, ptr %slot287, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  %rgep3747 = getelementptr i8, ptr %p3746, i64 -24
  %ld3748 = load i64, ptr %rgep3747, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3748, ptr %slot298, align 8
  %v3749 = load i64, ptr %slot298, align 8
  %cmp3750 = icmp ne i64 %v3749, 0
  %cv3751 = zext i1 %cmp3750 to i32
  store i32 %cv3751, ptr %slot299, align 8
  %v3752 = load i32, ptr %slot299, align 8
  %cv3753 = zext i32 %v3752 to i64
  %cond3754 = icmp ne i64 %cv3753, 0
  br i1 %cond3754, label %bb_rcgdec298, label %bb_rcgslow298
bb_rcgslow298:
  %v3755 = load i64, ptr %slot286, align 8
  %v3756 = load i64, ptr %slot269, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3755, i64 %v3756) nomerge, !dbg !138
  br label %bb_rcgdone298
bb_rcgdec298:
  %v3757 = load i64, ptr %slot295, align 8
  %v3758 = load i64, ptr %slot287, align 8
  %p3759 = inttoptr i64 %v3758 to ptr
  %rgep3760 = getelementptr i8, ptr %p3759, i64 -32
  store i64 %v3757, ptr %rgep3760, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear298
bb_rcgclear298:
  %v3761 = load i64, ptr %slot269, align 8
  %p3762 = inttoptr i64 %v3761 to ptr
  store i64 0, ptr %p3762, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone298
bb_rcgdone298:
  br label %bb_rcslotdone267
bb_rcslotdone267:
  %v3763 = load i64, ptr %slot267, align 8
  %op3764 = add i64 %v3763, 32
  store i64 %op3764, ptr %slot300, align 8
  %v3765 = load i64, ptr %slot300, align 8
  %op3766 = add i64 %v3765, 120
  store i64 %op3766, ptr %slot301, align 8
  store i64 0, ptr %slot302, align 8
  %v3767 = load i64, ptr %slot301, align 8
  %p3768 = inttoptr i64 %v3767 to ptr
  %ld3769 = load i64, ptr %p3768, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3769, ptr %slot303, align 8
  %v3770 = load i64, ptr %slot303, align 8
  %cmp3771 = icmp ne i64 %v3770, 0
  %cv3772 = zext i1 %cmp3771 to i32
  store i32 %cv3772, ptr %slot304, align 8
  %v3773 = load i32, ptr %slot304, align 8
  %cv3774 = zext i32 %v3773 to i64
  %cond3775 = icmp ne i64 %cv3774, 0
  br i1 %cond3775, label %bb_rcguniquenn305, label %bb_rcgunique305
bb_rcguniquenn305:
  %v3776 = load i64, ptr %slot303, align 8
  %op3777 = sub i64 %v3776, 16
  store i64 %op3777, ptr %slot305, align 8
  %v3778 = load i64, ptr %slot303, align 8
  %p3779 = inttoptr i64 %v3778 to ptr
  %rgep3780 = getelementptr i8, ptr %p3779, i64 -16
  %ld3781 = load i64, ptr %rgep3780, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3781, ptr %slot306, align 8
  %v3782 = load i64, ptr %slot306, align 8
  %op3783 = and i64 %v3782, 6917529027641081858
  store i64 %op3783, ptr %slot307, align 8
  %v3784 = load i64, ptr %slot307, align 8
  %cmp3785 = icmp ne i64 %v3784, 0
  %cv3786 = zext i1 %cmp3785 to i32
  store i32 %cv3786, ptr %slot308, align 8
  %v3787 = load i32, ptr %slot308, align 8
  %cv3788 = zext i32 %v3787 to i64
  %cond3789 = icmp ne i64 %cv3788, 0
  br i1 %cond3789, label %bb_rcguniqueslow305, label %bb_rcguniquecount305
bb_rcguniquecount305:
  %v3790 = load i64, ptr %slot303, align 8
  %op3791 = sub i64 %v3790, 32
  store i64 %op3791, ptr %slot309, align 8
  %v3792 = load i64, ptr %slot303, align 8
  %p3793 = inttoptr i64 %v3792 to ptr
  %rgep3794 = getelementptr i8, ptr %p3793, i64 -32
  %ld3795 = load i64, ptr %rgep3794, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3795, ptr %slot310, align 8
  %v3796 = load i64, ptr %slot310, align 8
  %cmp3797 = icmp ult i64 %v3796, 2
  %cv3798 = zext i1 %cmp3797 to i32
  store i32 %cv3798, ptr %slot311, align 8
  %v3799 = load i32, ptr %slot311, align 8
  %cv3800 = zext i32 %v3799 to i64
  %cond3801 = icmp ne i64 %cv3800, 0
  br i1 %cond3801, label %bb_rcgunique305, label %bb_rcguniqueslow305
bb_rcguniqueslow305:
  %v3802 = load i64, ptr %slot1, align 8
  %p3803 = inttoptr i64 %v3802 to ptr
  %p3804 = inttoptr i64 ptrtoint (ptr @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a to i64) to ptr
  %v3805 = load i64, ptr %slot301, align 8
  %p3806 = inttoptr i64 %v3805 to ptr
  %v3807 = load i64, ptr %slot302, align 8
  %p3808 = inttoptr i64 %v3807 to ptr
  %call3809 = call i32 @myl_qbe_rc_unique_field(ptr %p3803, ptr %p3804, ptr %p3806, ptr %p3808) nomerge, !dbg !138
  store i32 %call3809, ptr %slot312, align 8
  %v3810 = load i32, ptr %slot312, align 8
  %cv3811 = zext i32 %v3810 to i64
  %cond3812 = icmp ne i64 %cv3811, 0
  br i1 %cond3812, label %bb_rcunique315, label %bb_failure
bb_rcunique315:
  br label %bb_rcgunique305
bb_rcgunique305:
  %v3813 = load i64, ptr %slot301, align 8
  %p3814 = inttoptr i64 %v3813 to ptr
  %ld3815 = load i64, ptr %p3814, align 8, !alias.scope !4, !noalias !3
  store i64 %ld3815, ptr %slot313, align 8
  %v3816 = load i64, ptr %slot313, align 8
  %v3817 = load i64, ptr %slot69, align 8
  %p3818 = inttoptr i64 %v3817 to ptr
  store i64 %v3816, ptr %p3818, align 8, !alias.scope !3, !noalias !4
  %v3819 = load i64, ptr %slot69, align 8
  %p3820 = inttoptr i64 %v3819 to ptr
  %ld3821 = load i64, ptr %p3820, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3821, ptr %slot314, align 8
  %v3822 = load i64, ptr %slot28, align 8
  %p3823 = inttoptr i64 %v3822 to ptr
  %ld3824 = load i32, ptr %p3823, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3824, ptr %slot315, align 8
  %v3825 = load i32, ptr %slot315, align 8
  %cv3826 = zext i32 %v3825 to i64
  %cond3827 = icmp ne i64 %cv3826, 0
  br i1 %cond3827, label %bb_rcslotdrop320, label %bb_rcslotdone320
bb_rcslotdrop320:
  %v3828 = load i64, ptr %slot28, align 8
  %p3829 = inttoptr i64 %v3828 to ptr
  store i32 0, ptr %p3829, align 4, !alias.scope !3, !noalias !4
  %v3830 = load i64, ptr %slot37, align 8
  store i64 %v3830, ptr %slot316, align 8
  %v3831 = load i64, ptr %slot29, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %ld3833 = load i32, ptr %p3832, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3833, ptr %slot317, align 8
  %v3834 = load i32, ptr %slot317, align 8
  %op3835 = and i32 %v3834, 28
  store i32 %op3835, ptr %slot318, align 8
  %v3836 = load i32, ptr %slot318, align 8
  %cv3837 = zext i32 %v3836 to i64
  %cond3838 = icmp ne i64 %cv3837, 0
  br i1 %cond3838, label %bb_rcslotrole320, label %bb_rcslotowner320
bb_rcslotrole320:
  %v3839 = load i64, ptr %slot96, align 8
  store i64 %v3839, ptr %slot319, align 8
  %v3840 = load i64, ptr %slot316, align 8
  %p3841 = inttoptr i64 %v3840 to ptr
  %ld3842 = load i64, ptr %p3841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3842, ptr %slot320, align 8
  %v3843 = load i64, ptr %slot320, align 8
  %cmp3844 = icmp ne i64 %v3843, 0
  %cv3845 = zext i1 %cmp3844 to i32
  store i32 %cv3845, ptr %slot321, align 8
  %v3846 = load i32, ptr %slot321, align 8
  %cv3847 = zext i32 %v3846 to i64
  %cond3848 = icmp ne i64 %cv3847, 0
  br i1 %cond3848, label %bb_rcgnn336, label %bb_rcgdone336
bb_rcgnn336:
  %v3849 = load i64, ptr %slot320, align 8
  %op3850 = sub i64 %v3849, 16
  store i64 %op3850, ptr %slot322, align 8
  %v3851 = load i64, ptr %slot320, align 8
  %p3852 = inttoptr i64 %v3851 to ptr
  %rgep3853 = getelementptr i8, ptr %p3852, i64 -16
  %ld3854 = load i64, ptr %rgep3853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3854, ptr %slot323, align 8
  %v3855 = load i64, ptr %slot323, align 8
  %op3856 = and i64 %v3855, 4611686018427387906
  store i64 %op3856, ptr %slot324, align 8
  %v3857 = load i64, ptr %slot324, align 8
  %cmp3858 = icmp ne i64 %v3857, 0
  %cv3859 = zext i1 %cmp3858 to i32
  store i32 %cv3859, ptr %slot325, align 8
  %v3860 = load i32, ptr %slot325, align 8
  %cv3861 = zext i32 %v3860 to i64
  %cond3862 = icmp ne i64 %cv3861, 0
  br i1 %cond3862, label %bb_rcgclear336, label %bb_rcgcounted336
bb_rcgcounted336:
  %v3863 = load i64, ptr %slot320, align 8
  %op3864 = sub i64 %v3863, 24
  store i64 %op3864, ptr %slot326, align 8
  %v3865 = load i64, ptr %slot320, align 8
  %p3866 = inttoptr i64 %v3865 to ptr
  %rgep3867 = getelementptr i8, ptr %p3866, i64 -24
  %ld3868 = load i64, ptr %rgep3867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3868, ptr %slot327, align 8
  %v3869 = load i64, ptr %slot327, align 8
  %op3870 = sub i64 %v3869, 1
  store i64 %op3870, ptr %slot328, align 8
  %v3871 = load i64, ptr %slot328, align 8
  %cmp3872 = icmp eq i64 %v3871, 0
  %cv3873 = zext i1 %cmp3872 to i32
  store i32 %cv3873, ptr %slot329, align 8
  %v3874 = load i32, ptr %slot329, align 8
  %cv3875 = zext i32 %v3874 to i64
  %cond3876 = icmp ne i64 %cv3875, 0
  br i1 %cond3876, label %bb_rcglast336, label %bb_rcgdec336
bb_rcglast336:
  %v3877 = load i64, ptr %slot320, align 8
  %op3878 = sub i64 %v3877, 32
  store i64 %op3878, ptr %slot330, align 8
  %v3879 = load i64, ptr %slot320, align 8
  %p3880 = inttoptr i64 %v3879 to ptr
  %rgep3881 = getelementptr i8, ptr %p3880, i64 -32
  %ld3882 = load i64, ptr %rgep3881, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3882, ptr %slot331, align 8
  %v3883 = load i64, ptr %slot331, align 8
  %cmp3884 = icmp ne i64 %v3883, 0
  %cv3885 = zext i1 %cmp3884 to i32
  store i32 %cv3885, ptr %slot332, align 8
  %v3886 = load i32, ptr %slot332, align 8
  %cv3887 = zext i32 %v3886 to i64
  %cond3888 = icmp ne i64 %cv3887, 0
  br i1 %cond3888, label %bb_rcgdec336, label %bb_rcgslow336
bb_rcgslow336:
  %v3889 = load i64, ptr %slot319, align 8
  %v3890 = load i64, ptr %slot316, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64 %v3889, i64 %v3890) nomerge, !dbg !138
  br label %bb_rcgdone336
bb_rcgdec336:
  %v3891 = load i64, ptr %slot328, align 8
  %v3892 = load i64, ptr %slot320, align 8
  %p3893 = inttoptr i64 %v3892 to ptr
  %rgep3894 = getelementptr i8, ptr %p3893, i64 -24
  store i64 %v3891, ptr %rgep3894, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear336
bb_rcgclear336:
  %v3895 = load i64, ptr %slot316, align 8
  %p3896 = inttoptr i64 %v3895 to ptr
  store i64 0, ptr %p3896, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone336
bb_rcgdone336:
  br label %bb_rcslotdone320
bb_rcslotowner320:
  %v3897 = load i64, ptr %slot96, align 8
  store i64 %v3897, ptr %slot333, align 8
  %v3898 = load i64, ptr %slot316, align 8
  %p3899 = inttoptr i64 %v3898 to ptr
  %ld3900 = load i64, ptr %p3899, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3900, ptr %slot334, align 8
  %v3901 = load i64, ptr %slot334, align 8
  %cmp3902 = icmp ne i64 %v3901, 0
  %cv3903 = zext i1 %cmp3902 to i32
  store i32 %cv3903, ptr %slot335, align 8
  %v3904 = load i32, ptr %slot335, align 8
  %cv3905 = zext i32 %v3904 to i64
  %cond3906 = icmp ne i64 %cv3905, 0
  br i1 %cond3906, label %bb_rcgnn351, label %bb_rcgdone351
bb_rcgnn351:
  %v3907 = load i64, ptr %slot334, align 8
  %op3908 = sub i64 %v3907, 16
  store i64 %op3908, ptr %slot336, align 8
  %v3909 = load i64, ptr %slot334, align 8
  %p3910 = inttoptr i64 %v3909 to ptr
  %rgep3911 = getelementptr i8, ptr %p3910, i64 -16
  %ld3912 = load i64, ptr %rgep3911, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3912, ptr %slot337, align 8
  %v3913 = load i64, ptr %slot337, align 8
  %op3914 = and i64 %v3913, 4611686018427387906
  store i64 %op3914, ptr %slot338, align 8
  %v3915 = load i64, ptr %slot338, align 8
  %cmp3916 = icmp ne i64 %v3915, 0
  %cv3917 = zext i1 %cmp3916 to i32
  store i32 %cv3917, ptr %slot339, align 8
  %v3918 = load i32, ptr %slot339, align 8
  %cv3919 = zext i32 %v3918 to i64
  %cond3920 = icmp ne i64 %cv3919, 0
  br i1 %cond3920, label %bb_rcgclear351, label %bb_rcgcounted351
bb_rcgcounted351:
  %v3921 = load i64, ptr %slot334, align 8
  %op3922 = sub i64 %v3921, 32
  store i64 %op3922, ptr %slot340, align 8
  %v3923 = load i64, ptr %slot334, align 8
  %p3924 = inttoptr i64 %v3923 to ptr
  %rgep3925 = getelementptr i8, ptr %p3924, i64 -32
  %ld3926 = load i64, ptr %rgep3925, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3926, ptr %slot341, align 8
  %v3927 = load i64, ptr %slot341, align 8
  %op3928 = sub i64 %v3927, 1
  store i64 %op3928, ptr %slot342, align 8
  %v3929 = load i64, ptr %slot342, align 8
  %cmp3930 = icmp eq i64 %v3929, 0
  %cv3931 = zext i1 %cmp3930 to i32
  store i32 %cv3931, ptr %slot343, align 8
  %v3932 = load i32, ptr %slot343, align 8
  %cv3933 = zext i32 %v3932 to i64
  %cond3934 = icmp ne i64 %cv3933, 0
  br i1 %cond3934, label %bb_rcglast351, label %bb_rcgdec351
bb_rcglast351:
  %v3935 = load i64, ptr %slot334, align 8
  %op3936 = sub i64 %v3935, 24
  store i64 %op3936, ptr %slot344, align 8
  %v3937 = load i64, ptr %slot334, align 8
  %p3938 = inttoptr i64 %v3937 to ptr
  %rgep3939 = getelementptr i8, ptr %p3938, i64 -24
  %ld3940 = load i64, ptr %rgep3939, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3940, ptr %slot345, align 8
  %v3941 = load i64, ptr %slot345, align 8
  %cmp3942 = icmp ne i64 %v3941, 0
  %cv3943 = zext i1 %cmp3942 to i32
  store i32 %cv3943, ptr %slot346, align 8
  %v3944 = load i32, ptr %slot346, align 8
  %cv3945 = zext i32 %v3944 to i64
  %cond3946 = icmp ne i64 %cv3945, 0
  br i1 %cond3946, label %bb_rcgdec351, label %bb_rcgslow351
bb_rcgslow351:
  %v3947 = load i64, ptr %slot333, align 8
  %v3948 = load i64, ptr %slot316, align 8
  call void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64 %v3947, i64 %v3948) nomerge, !dbg !138
  br label %bb_rcgdone351
bb_rcgdec351:
  %v3949 = load i64, ptr %slot342, align 8
  %v3950 = load i64, ptr %slot334, align 8
  %p3951 = inttoptr i64 %v3950 to ptr
  %rgep3952 = getelementptr i8, ptr %p3951, i64 -32
  store i64 %v3949, ptr %rgep3952, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear351
bb_rcgclear351:
  %v3953 = load i64, ptr %slot316, align 8
  %p3954 = inttoptr i64 %v3953 to ptr
  store i64 0, ptr %p3954, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone351
bb_rcgdone351:
  br label %bb_rcslotdone320
bb_rcslotdone320:
  %v3955 = load i64, ptr %slot43, align 8
  store i64 %v3955, ptr %slot347, align 8
  %v3956 = load i64, ptr %slot96, align 8
  %v3957 = load i64, ptr %slot347, align 8
  %p3958 = inttoptr i64 %v3957 to ptr
  store i64 %v3956, ptr %p3958, align 8, !alias.scope !3, !noalias !4
  %v3959 = load i64, ptr %slot96, align 8
  %p3961 = inttoptr i64 %v3959 to ptr
  %gep3962 = getelementptr i8, ptr %p3961, i64 5640
  %op3960 = ptrtoint ptr %gep3962 to i64
  store i64 %op3960, ptr %slot348, align 8
  %v3963 = load i64, ptr %slot348, align 8
  %p3964 = inttoptr i64 %v3963 to ptr
  %ld3965 = load i64, ptr %p3964, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3965, ptr %slot349, align 8
  %v3966 = load i64, ptr %slot349, align 8
  %op3967 = add i64 %v3966, 248
  store i64 %op3967, ptr %slot350, align 8
  %v3968 = load i64, ptr %slot350, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  %ld3970 = load i64, ptr %p3969, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3970, ptr %slot351, align 8
  %v3971 = load i64, ptr %slot347, align 8
  %p3973 = inttoptr i64 %v3971 to ptr
  %gep3974 = getelementptr i8, ptr %p3973, i64 8
  %op3972 = ptrtoint ptr %gep3974 to i64
  store i64 %op3972, ptr %slot352, align 8
  %v3975 = load i64, ptr %slot351, align 8
  %v3976 = load i64, ptr %slot352, align 8
  %p3977 = inttoptr i64 %v3976 to ptr
  store i64 %v3975, ptr %p3977, align 8, !alias.scope !3, !noalias !4
  %v3978 = load i64, ptr %slot347, align 8
  %p3980 = inttoptr i64 %v3978 to ptr
  %gep3981 = getelementptr i8, ptr %p3980, i64 16
  %op3979 = ptrtoint ptr %gep3981 to i64
  store i64 %op3979, ptr %slot353, align 8
  %v3982 = load i64, ptr %slot353, align 8
  %p3983 = inttoptr i64 %v3982 to ptr
  store i64 0, ptr %p3983, align 8, !alias.scope !3, !noalias !4
  %v3984 = load i64, ptr %slot96, align 8
  %p3986 = inttoptr i64 %v3984 to ptr
  %gep3987 = getelementptr i8, ptr %p3986, i64 112
  %op3985 = ptrtoint ptr %gep3987 to i64
  store i64 %op3985, ptr %slot354, align 8
  %v3988 = load i64, ptr %slot347, align 8
  %p3990 = inttoptr i64 %v3988 to ptr
  %gep3991 = getelementptr i8, ptr %p3990, i64 24
  %op3989 = ptrtoint ptr %gep3991 to i64
  store i64 %op3989, ptr %slot355, align 8
  %v3992 = load i64, ptr %slot347, align 8
  %p3994 = inttoptr i64 %v3992 to ptr
  %gep3995 = getelementptr i8, ptr %p3994, i64 28
  %op3993 = ptrtoint ptr %gep3995 to i64
  store i64 %op3993, ptr %slot356, align 8
  %v3996 = load i64, ptr %slot354, align 8
  %p3997 = inttoptr i64 %v3996 to ptr
  %ld3998 = load i32, ptr %p3997, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld3998, ptr %slot357, align 8
  %v3999 = load i64, ptr %slot355, align 8
  %p4000 = inttoptr i64 %v3999 to ptr
  store i32 1, ptr %p4000, align 4, !alias.scope !3, !noalias !4
  %v4001 = load i32, ptr %slot357, align 8
  %v4002 = load i64, ptr %slot356, align 8
  %p4003 = inttoptr i64 %v4002 to ptr
  store i32 %v4001, ptr %p4003, align 4, !alias.scope !3, !noalias !4
  %v4004 = load i64, ptr %slot347, align 8
  %v4005 = load i64, ptr %slot350, align 8
  %p4006 = inttoptr i64 %v4005 to ptr
  store i64 %v4004, ptr %p4006, align 8, !alias.scope !9999998, !noalias !9999999
  %v4007 = load i64, ptr %slot314, align 8
  %cmp4008 = icmp ne i64 %v4007, 0
  %cv4009 = zext i1 %cmp4008 to i32
  store i32 %cv4009, ptr %slot358, align 8
  %v4010 = load i32, ptr %slot358, align 8
  %cv4011 = zext i32 %v4010 to i64
  %cond4012 = icmp ne i64 %cv4011, 0
  br i1 %cond4012, label %bb_rcspinmark403, label %bb_rcspindone403
bb_rcspinmark403:
  %v4013 = load i64, ptr %slot314, align 8
  %op4014 = sub i64 %v4013, 16
  store i64 %op4014, ptr %slot359, align 8
  %v4015 = load i64, ptr %slot314, align 8
  %p4016 = inttoptr i64 %v4015 to ptr
  %rgep4017 = getelementptr i8, ptr %p4016, i64 -16
  %ld4018 = load i64, ptr %rgep4017, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4018, ptr %slot360, align 8
  %v4019 = load i64, ptr %slot360, align 8
  %op4020 = and i64 %v4019, 2
  store i64 %op4020, ptr %slot361, align 8
  %v4021 = load i64, ptr %slot361, align 8
  %cmp4022 = icmp ne i64 %v4021, 0
  %cv4023 = zext i1 %cmp4022 to i32
  store i32 %cv4023, ptr %slot362, align 8
  %v4024 = load i32, ptr %slot362, align 8
  %cv4025 = zext i32 %v4024 to i64
  %cond4026 = icmp ne i64 %cv4025, 0
  br i1 %cond4026, label %bb_rcspindone403, label %bb_rcspintype403
bb_rcspintype403:
  %v4027 = load i64, ptr %slot360, align 8
  %op4028 = and i64 %v4027, 4611686018427387907
  store i64 %op4028, ptr %slot363, align 8
  %v4029 = load i64, ptr %slot363, align 8
  %cmp4030 = icmp eq i64 %v4029, 0
  %cv4031 = zext i1 %cmp4030 to i32
  store i32 %cv4031, ptr %slot364, align 8
  %v4032 = load i32, ptr %slot364, align 8
  %cv4033 = zext i32 %v4032 to i64
  %cond4034 = icmp ne i64 %cv4033, 0
  br i1 %cond4034, label %bb_rcs411, label %bb_rcspinslow403
bb_rcs411:
  %v4035 = load i64, ptr %slot314, align 8
  %op4036 = sub i64 %v4035, 8
  store i64 %op4036, ptr %slot365, align 8
  %v4037 = load i64, ptr %slot314, align 8
  %p4038 = inttoptr i64 %v4037 to ptr
  %rgep4039 = getelementptr i8, ptr %p4038, i64 -8
  %ld4040 = load i64, ptr %rgep4039, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4040, ptr %slot366, align 8
  %p4041 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld4042 = load i64, ptr %p4041, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4042, ptr %slot367, align 8
  %v4043 = load i64, ptr %slot366, align 8
  %v4044 = load i64, ptr %slot367, align 8
  %cmp4045 = icmp eq i64 %v4043, %v4044
  %cv4046 = zext i1 %cmp4045 to i32
  store i32 %cv4046, ptr %slot368, align 8
  %v4047 = load i32, ptr %slot368, align 8
  %cv4048 = zext i32 %v4047 to i64
  %cond4049 = icmp ne i64 %cv4048, 0
  br i1 %cond4049, label %bb_rcs416, label %bb_rcspinslow403
bb_rcs416:
  %v4050 = load i64, ptr %slot96, align 8
  %p4052 = inttoptr i64 %v4050 to ptr
  %gep4053 = getelementptr i8, ptr %p4052, i64 5640
  %op4051 = ptrtoint ptr %gep4053 to i64
  store i64 %op4051, ptr %slot369, align 8
  %v4054 = load i64, ptr %slot369, align 8
  %p4055 = inttoptr i64 %v4054 to ptr
  %ld4056 = load i64, ptr %p4055, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4056, ptr %slot370, align 8
  %v4057 = load i64, ptr %slot370, align 8
  %op4058 = add i64 %v4057, 256
  store i64 %op4058, ptr %slot371, align 8
  %v4059 = load i64, ptr %slot371, align 8
  %p4060 = inttoptr i64 %v4059 to ptr
  %ld4061 = load i64, ptr %p4060, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4061, ptr %slot372, align 8
  %v4062 = load i64, ptr %slot372, align 8
  %cmp4063 = icmp ne i64 %v4062, 0
  %cv4064 = zext i1 %cmp4063 to i32
  store i32 %cv4064, ptr %slot373, align 8
  %v4065 = load i32, ptr %slot373, align 8
  %cv4066 = zext i32 %v4065 to i64
  %cond4067 = icmp ne i64 %cv4066, 0
  br i1 %cond4067, label %bb_rcs422, label %bb_rcspinslow403
bb_rcs422:
  %v4068 = load i64, ptr %slot96, align 8
  %p4070 = inttoptr i64 %v4068 to ptr
  %gep4071 = getelementptr i8, ptr %p4070, i64 24
  %op4069 = ptrtoint ptr %gep4071 to i64
  store i64 %op4069, ptr %slot374, align 8
  %v4072 = load i64, ptr %slot374, align 8
  %p4073 = inttoptr i64 %v4072 to ptr
  %ld4074 = load i64, ptr %p4073, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4074, ptr %slot375, align 8
  %v4075 = load i64, ptr %slot375, align 8
  %op4076 = add i64 %v4075, 40
  store i64 %op4076, ptr %slot376, align 8
  %v4077 = load i64, ptr %slot376, align 8
  %v4078 = load i64, ptr %slot375, align 8
  %cmp4079 = icmp uge i64 %v4077, %v4078
  %cv4080 = zext i1 %cmp4079 to i32
  store i32 %cv4080, ptr %slot377, align 8
  %v4081 = load i32, ptr %slot377, align 8
  %cv4082 = zext i32 %v4081 to i64
  %cond4083 = icmp ne i64 %cv4082, 0
  br i1 %cond4083, label %bb_rcs427, label %bb_rcspinslow403
bb_rcs427:
  %v4084 = load i64, ptr %slot96, align 8
  %p4086 = inttoptr i64 %v4084 to ptr
  %gep4087 = getelementptr i8, ptr %p4086, i64 88
  %op4085 = ptrtoint ptr %gep4087 to i64
  store i64 %op4085, ptr %slot378, align 8
  %v4088 = load i64, ptr %slot378, align 8
  %p4089 = inttoptr i64 %v4088 to ptr
  %ld4090 = load i64, ptr %p4089, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4090, ptr %slot379, align 8
  %v4091 = load i64, ptr %slot379, align 8
  %cmp4092 = icmp eq i64 %v4091, 0
  %cv4093 = zext i1 %cmp4092 to i32
  store i32 %cv4093, ptr %slot380, align 8
  %v4094 = load i64, ptr %slot376, align 8
  %v4095 = load i64, ptr %slot379, align 8
  %cmp4096 = icmp ule i64 %v4094, %v4095
  %cv4097 = zext i1 %cmp4096 to i32
  store i32 %cv4097, ptr %slot381, align 8
  %v4098 = load i32, ptr %slot380, align 8
  %v4099 = load i32, ptr %slot381, align 8
  %op4100 = or i32 %v4098, %v4099
  store i32 %op4100, ptr %slot382, align 8
  %v4101 = load i32, ptr %slot382, align 8
  %cv4102 = zext i32 %v4101 to i64
  %cond4103 = icmp ne i64 %cv4102, 0
  br i1 %cond4103, label %bb_rcs433, label %bb_rcspinslow403
bb_rcs433:
  %v4104 = load i64, ptr %slot314, align 8
  %op4105 = sub i64 %v4104, 24
  store i64 %op4105, ptr %slot383, align 8
  %v4106 = load i64, ptr %slot314, align 8
  %p4107 = inttoptr i64 %v4106 to ptr
  %rgep4108 = getelementptr i8, ptr %p4107, i64 -24
  %ld4109 = load i64, ptr %rgep4108, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4109, ptr %slot384, align 8
  %v4110 = load i64, ptr %slot384, align 8
  %cmp4111 = icmp ne i64 %v4110, 18446744073709551615
  %cv4112 = zext i1 %cmp4111 to i32
  store i32 %cv4112, ptr %slot385, align 8
  %v4113 = load i32, ptr %slot385, align 8
  %cv4114 = zext i32 %v4113 to i64
  %cond4115 = icmp ne i64 %cv4114, 0
  br i1 %cond4115, label %bb_rcs437, label %bb_rcspinslow403
bb_rcs437:
  %v4116 = load i64, ptr %slot314, align 8
  %op4117 = add i64 %v4116, 32
  store i64 %op4117, ptr %slot386, align 8
  %v4118 = load i64, ptr %slot386, align 8
  %p4119 = inttoptr i64 %v4118 to ptr
  %ld4120 = load i64, ptr %p4119, align 8
  store i64 %ld4120, ptr %slot387, align 8
  %v4121 = load i64, ptr %slot387, align 8
  %cmp4122 = icmp ne i64 %v4121, 0
  %cv4123 = zext i1 %cmp4122 to i32
  store i32 %cv4123, ptr %slot388, align 8
  %v4124 = load i32, ptr %slot388, align 8
  %cv4125 = zext i32 %v4124 to i64
  %cond4126 = icmp ne i64 %cv4125, 0
  br i1 %cond4126, label %bb_rcspinbacking403, label %bb_rcspincommit403
bb_rcspinbacking403:
  %v4127 = load i64, ptr %slot387, align 8
  %op4128 = sub i64 %v4127, 16
  store i64 %op4128, ptr %slot389, align 8
  %v4129 = load i64, ptr %slot387, align 8
  %p4130 = inttoptr i64 %v4129 to ptr
  %rgep4131 = getelementptr i8, ptr %p4130, i64 -16
  %ld4132 = load i64, ptr %rgep4131, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4132, ptr %slot390, align 8
  %v4133 = load i64, ptr %slot390, align 8
  %op4134 = and i64 %v4133, 4611686018427387907
  store i64 %op4134, ptr %slot391, align 8
  %v4135 = load i64, ptr %slot391, align 8
  %cmp4136 = icmp eq i64 %v4135, 0
  %cv4137 = zext i1 %cmp4136 to i32
  store i32 %cv4137, ptr %slot392, align 8
  %v4138 = load i32, ptr %slot392, align 8
  %cv4139 = zext i32 %v4138 to i64
  %cond4140 = icmp ne i64 %cv4139, 0
  br i1 %cond4140, label %bb_rcs445, label %bb_rcspinslow403
bb_rcs445:
  %v4141 = load i64, ptr %slot387, align 8
  %op4142 = sub i64 %v4141, 24
  store i64 %op4142, ptr %slot393, align 8
  %v4143 = load i64, ptr %slot387, align 8
  %p4144 = inttoptr i64 %v4143 to ptr
  %rgep4145 = getelementptr i8, ptr %p4144, i64 -24
  %ld4146 = load i64, ptr %rgep4145, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4146, ptr %slot394, align 8
  %v4147 = load i64, ptr %slot394, align 8
  %cmp4148 = icmp ne i64 %v4147, 18446744073709551615
  %cv4149 = zext i1 %cmp4148 to i32
  store i32 %cv4149, ptr %slot395, align 8
  %v4150 = load i32, ptr %slot395, align 8
  %cv4151 = zext i32 %v4150 to i64
  %cond4152 = icmp ne i64 %cv4151, 0
  br i1 %cond4152, label %bb_rcs449, label %bb_rcspinslow403
bb_rcs449:
  br label %bb_rcspincommit403
bb_rcspincommit403:
  %v4153 = load i64, ptr %slot372, align 8
  %p4154 = inttoptr i64 %v4153 to ptr
  %ld4155 = load i64, ptr %p4154, align 8
  store i64 %ld4155, ptr %slot396, align 8
  %v4156 = load i64, ptr %slot370, align 8
  %op4157 = add i64 %v4156, 256
  store i64 %op4157, ptr %slot397, align 8
  %v4158 = load i64, ptr %slot396, align 8
  %v4159 = load i64, ptr %slot397, align 8
  %p4160 = inttoptr i64 %v4159 to ptr
  store i64 %v4158, ptr %p4160, align 8, !alias.scope !9999998, !noalias !9999999
  %v4161 = load i64, ptr %slot370, align 8
  %op4162 = add i64 %v4161, 264
  store i64 %op4162, ptr %slot398, align 8
  %v4163 = load i64, ptr %slot398, align 8
  %p4164 = inttoptr i64 %v4163 to ptr
  %ld4165 = load i64, ptr %p4164, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4165, ptr %slot399, align 8
  %v4166 = load i64, ptr %slot399, align 8
  %op4167 = add i64 %v4166, 18446744073709551615
  store i64 %op4167, ptr %slot400, align 8
  %v4168 = load i64, ptr %slot400, align 8
  %v4169 = load i64, ptr %slot398, align 8
  %p4170 = inttoptr i64 %v4169 to ptr
  store i64 %v4168, ptr %p4170, align 8, !alias.scope !9999998, !noalias !9999999
  %v4171 = load i64, ptr %slot96, align 8
  %p4173 = inttoptr i64 %v4171 to ptr
  %gep4174 = getelementptr i8, ptr %p4173, i64 24
  %op4172 = ptrtoint ptr %gep4174 to i64
  store i64 %op4172, ptr %slot401, align 8
  %v4175 = load i64, ptr %slot401, align 8
  %p4176 = inttoptr i64 %v4175 to ptr
  %ld4177 = load i64, ptr %p4176, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4177, ptr %slot402, align 8
  %v4178 = load i64, ptr %slot402, align 8
  %op4179 = add i64 %v4178, 40
  store i64 %op4179, ptr %slot403, align 8
  %v4180 = load i64, ptr %slot403, align 8
  %v4181 = load i64, ptr %slot401, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  store i64 %v4180, ptr %p4182, align 8, !alias.scope !9999998, !noalias !9999999
  %v4183 = load i64, ptr %slot370, align 8
  %op4184 = add i64 %v4183, 48
  store i64 %op4184, ptr %slot404, align 8
  %v4185 = load i64, ptr %slot404, align 8
  %p4186 = inttoptr i64 %v4185 to ptr
  %ld4187 = load i64, ptr %p4186, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4187, ptr %slot405, align 8
  %v4188 = load i64, ptr %slot405, align 8
  %op4189 = add i64 %v4188, 40
  store i64 %op4189, ptr %slot406, align 8
  %v4190 = load i64, ptr %slot406, align 8
  %v4191 = load i64, ptr %slot404, align 8
  %p4192 = inttoptr i64 %v4191 to ptr
  store i64 %v4190, ptr %p4192, align 8, !alias.scope !9999998, !noalias !9999999
  %v4193 = load i64, ptr %slot314, align 8
  %op4194 = sub i64 %v4193, 24
  store i64 %op4194, ptr %slot407, align 8
  %v4195 = load i64, ptr %slot314, align 8
  %p4196 = inttoptr i64 %v4195 to ptr
  %rgep4197 = getelementptr i8, ptr %p4196, i64 -24
  %ld4198 = load i64, ptr %rgep4197, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4198, ptr %slot408, align 8
  %v4199 = load i64, ptr %slot408, align 8
  %op4200 = add i64 %v4199, 1
  store i64 %op4200, ptr %slot409, align 8
  %v4201 = load i64, ptr %slot409, align 8
  %v4202 = load i64, ptr %slot314, align 8
  %p4203 = inttoptr i64 %v4202 to ptr
  %rgep4204 = getelementptr i8, ptr %p4203, i64 -24
  store i64 %v4201, ptr %rgep4204, align 8, !alias.scope !9, !noalias !10
  %v4205 = load i64, ptr %slot387, align 8
  %cmp4206 = icmp ne i64 %v4205, 0
  %cv4207 = zext i1 %cmp4206 to i32
  store i32 %cv4207, ptr %slot410, align 8
  %v4208 = load i32, ptr %slot410, align 8
  %cv4209 = zext i32 %v4208 to i64
  %cond4210 = icmp ne i64 %cv4209, 0
  br i1 %cond4210, label %bb_rcspinhold403, label %bb_rcspinjournal403
bb_rcspinhold403:
  %v4211 = load i64, ptr %slot387, align 8
  %op4212 = sub i64 %v4211, 24
  store i64 %op4212, ptr %slot411, align 8
  %v4213 = load i64, ptr %slot387, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  %rgep4215 = getelementptr i8, ptr %p4214, i64 -24
  %ld4216 = load i64, ptr %rgep4215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4216, ptr %slot412, align 8
  %v4217 = load i64, ptr %slot412, align 8
  %op4218 = add i64 %v4217, 1
  store i64 %op4218, ptr %slot413, align 8
  %v4219 = load i64, ptr %slot413, align 8
  %v4220 = load i64, ptr %slot387, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  %rgep4222 = getelementptr i8, ptr %p4221, i64 -24
  store i64 %v4219, ptr %rgep4222, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal403
bb_rcspinjournal403:
  %v4223 = load i64, ptr %slot360, align 8
  %op4224 = and i64 %v4223, 1152921504606846976
  store i64 %op4224, ptr %slot414, align 8
  %v4225 = load i64, ptr %slot360, align 8
  %op4226 = or i64 %v4225, 1152921504606846976
  store i64 %op4226, ptr %slot415, align 8
  %v4227 = load i64, ptr %slot314, align 8
  %op4228 = sub i64 %v4227, 16
  store i64 %op4228, ptr %slot416, align 8
  %v4229 = load i64, ptr %slot415, align 8
  %v4230 = load i64, ptr %slot314, align 8
  %p4231 = inttoptr i64 %v4230 to ptr
  %rgep4232 = getelementptr i8, ptr %p4231, i64 -16
  store i64 %v4229, ptr %rgep4232, align 8, !alias.scope !9, !noalias !10
  %v4233 = load i64, ptr %slot347, align 8
  %p4235 = inttoptr i64 %v4233 to ptr
  %gep4236 = getelementptr i8, ptr %p4235, i64 16
  %op4234 = ptrtoint ptr %gep4236 to i64
  store i64 %op4234, ptr %slot417, align 8
  %v4237 = load i64, ptr %slot417, align 8
  %p4238 = inttoptr i64 %v4237 to ptr
  %ld4239 = load i64, ptr %p4238, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4239, ptr %slot418, align 8
  %v4240 = load i64, ptr %slot372, align 8
  %op4241 = add i64 %v4240, 0
  store i64 %op4241, ptr %slot419, align 8
  %v4242 = load i64, ptr %slot418, align 8
  %v4243 = load i64, ptr %slot419, align 8
  %p4244 = inttoptr i64 %v4243 to ptr
  store i64 %v4242, ptr %p4244, align 8, !alias.scope !9999998, !noalias !9999999
  %v4245 = load i64, ptr %slot372, align 8
  %op4246 = add i64 %v4245, 8
  store i64 %op4246, ptr %slot420, align 8
  %v4247 = load i64, ptr %slot314, align 8
  %v4248 = load i64, ptr %slot420, align 8
  %p4249 = inttoptr i64 %v4248 to ptr
  store i64 %v4247, ptr %p4249, align 8, !alias.scope !9999998, !noalias !9999999
  %v4250 = load i64, ptr %slot372, align 8
  %op4251 = add i64 %v4250, 16
  store i64 %op4251, ptr %slot421, align 8
  %v4252 = load i64, ptr %slot414, align 8
  %v4253 = load i64, ptr %slot421, align 8
  %p4254 = inttoptr i64 %v4253 to ptr
  store i64 %v4252, ptr %p4254, align 8, !alias.scope !9999998, !noalias !9999999
  %v4255 = load i64, ptr %slot372, align 8
  %op4256 = add i64 %v4255, 24
  store i64 %op4256, ptr %slot422, align 8
  %v4257 = load i64, ptr %slot422, align 8
  %p4258 = inttoptr i64 %v4257 to ptr
  store i32 1, ptr %p4258, align 4, !alias.scope !9999998, !noalias !9999999
  %v4259 = load i64, ptr %slot372, align 8
  %op4260 = add i64 %v4259, 32
  store i64 %op4260, ptr %slot423, align 8
  %v4261 = load i64, ptr %slot387, align 8
  %v4262 = load i64, ptr %slot423, align 8
  %p4263 = inttoptr i64 %v4262 to ptr
  store i64 %v4261, ptr %p4263, align 8, !alias.scope !9999998, !noalias !9999999
  %v4264 = load i64, ptr %slot347, align 8
  %p4266 = inttoptr i64 %v4264 to ptr
  %gep4267 = getelementptr i8, ptr %p4266, i64 16
  %op4265 = ptrtoint ptr %gep4267 to i64
  store i64 %op4265, ptr %slot424, align 8
  %v4268 = load i64, ptr %slot372, align 8
  %v4269 = load i64, ptr %slot424, align 8
  %p4270 = inttoptr i64 %v4269 to ptr
  store i64 %v4268, ptr %p4270, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone403
bb_rcspinslow403:
  %v4271 = load i64, ptr %slot1, align 8
  %p4272 = inttoptr i64 %v4271 to ptr
  %v4273 = load i64, ptr %slot347, align 8
  %p4274 = inttoptr i64 %v4273 to ptr
  %v4275 = load i64, ptr %slot314, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  %call4277 = call i32 @myl_qbe_rc_scope_pin(ptr %p4272, ptr %p4274, ptr %p4276) nomerge, !dbg !138
  store i32 %call4277, ptr %slot425, align 8
  %v4278 = load i32, ptr %slot425, align 8
  %cv4279 = zext i32 %v4278 to i64
  %cond4280 = icmp ne i64 %cv4279, 0
  br i1 %cond4280, label %bb_rcunique480, label %bb_failure
bb_rcunique480:
  br label %bb_rcspindone403
bb_rcspindone403:
  %v4281 = load i64, ptr %slot314, align 8
  %v4282 = load i64, ptr %slot53, align 8
  %p4283 = inttoptr i64 %v4282 to ptr
  store i64 %v4281, ptr %p4283, align 8, !alias.scope !3, !noalias !4
  %v4284 = load i64, ptr %slot50, align 8
  %p4285 = inttoptr i64 %v4284 to ptr
  %ld4286 = load i64, ptr %p4285, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4286, ptr %slot426, align 8
  %v4287 = load i64, ptr %slot426, align 8
  %v4288 = load i64, ptr %slot69, align 8
  %p4289 = inttoptr i64 %v4288 to ptr
  store i64 %v4287, ptr %p4289, align 8, !alias.scope !3, !noalias !4
  %v4290 = load i64, ptr %slot69, align 8
  %p4291 = inttoptr i64 %v4290 to ptr
  %ld4292 = load i64, ptr %p4291, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4292, ptr %slot427, align 8
  %v4293 = load i64, ptr %slot427, align 8
  %v4294 = load i64, ptr %slot55, align 8
  %p4295 = inttoptr i64 %v4294 to ptr
  store i64 %v4293, ptr %p4295, align 8, !alias.scope !3, !noalias !4
  %v4296 = load i64, ptr %slot55, align 8
  %p4297 = inttoptr i64 %v4296 to ptr
  %ld4298 = load i64, ptr %p4297, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4298, ptr %slot428, align 8
  %v4299 = load i64, ptr %slot428, align 8
  %v4300 = load i64, ptr %slot69, align 8
  %p4301 = inttoptr i64 %v4300 to ptr
  store i64 %v4299, ptr %p4301, align 8, !alias.scope !3, !noalias !4
  %v4302 = load i64, ptr %slot70, align 8
  %p4303 = inttoptr i64 %v4302 to ptr
  store i64 0, ptr %p4303, align 8, !alias.scope !3, !noalias !4
  %v4304 = load i64, ptr %slot70, align 8
  %p4305 = inttoptr i64 %v4304 to ptr
  %ld4306 = load i64, ptr %p4305, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4306, ptr %slot429, align 8
  %v4307 = load i64, ptr %slot69, align 8
  %p4308 = inttoptr i64 %v4307 to ptr
  %ld4309 = load i64, ptr %p4308, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4309, ptr %slot430, align 8
  %v4310 = load i64, ptr %slot430, align 8
  %v4311 = load i64, ptr %slot429, align 8
  %cmp4312 = icmp slt i64 %v4310, %v4311
  %cv4313 = zext i1 %cmp4312 to i64
  store i64 %cv4313, ptr %slot431, align 8
  %v4314 = load i64, ptr %slot431, align 8
  %v4315 = load i64, ptr %slot69, align 8
  %p4316 = inttoptr i64 %v4315 to ptr
  store i64 %v4314, ptr %p4316, align 8, !alias.scope !3, !noalias !4
  %v4317 = load i64, ptr %slot69, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  %ld4319 = load i64, ptr %p4318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4319, ptr %slot432, align 8
  %v4320 = load i64, ptr %slot432, align 8
  %cond4321 = icmp ne i64 %v4320, 0
  br i1 %cond4321, label %bb_next488, label %bb_i50
bb_next488:
  %v4322 = load i64, ptr %slot53, align 8
  %p4323 = inttoptr i64 %v4322 to ptr
  %ld4324 = load i64, ptr %p4323, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4324, ptr %slot433, align 8
  %v4325 = load i64, ptr %slot433, align 8
  %op4326 = add i64 %v4325, 0
  store i64 %op4326, ptr %slot434, align 8
  %v4327 = load i64, ptr %slot434, align 8
  %p4328 = inttoptr i64 %v4327 to ptr
  %ld4329 = load i64, ptr %p4328, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4329, ptr %slot435, align 8
  %v4330 = load i64, ptr %slot435, align 8
  %v4331 = load i64, ptr %slot69, align 8
  %p4332 = inttoptr i64 %v4331 to ptr
  store i64 %v4330, ptr %p4332, align 8, !alias.scope !3, !noalias !4
  %v4333 = load i64, ptr %slot69, align 8
  %p4334 = inttoptr i64 %v4333 to ptr
  %ld4335 = load i64, ptr %p4334, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4335, ptr %slot436, align 8
  %v4336 = load i64, ptr %slot436, align 8
  %cmp4337 = icmp ugt i64 %v4336, 9223372036854775807
  %cv4338 = zext i1 %cmp4337 to i64
  store i64 %cv4338, ptr %slot437, align 8
  %v4339 = load i64, ptr %slot437, align 8
  %cond4340 = icmp ne i64 %v4339, 0
  br i1 %cond4340, label %bb_cast_overflow493, label %bb_cast_ok493
bb_cast_overflow493:
  %v4341 = load i64, ptr %slot1, align 8
  %p4342 = inttoptr i64 %v4341 to ptr
  %v4343 = load i64, ptr %slot436, align 8
  call void @myl_qbe_fail_cast(ptr %p4342, i64 %v4343, i64 320) nomerge, !dbg !140
  unreachable
bb_cast_ok493:
  %v4344 = load i64, ptr %slot436, align 8
  %v4345 = load i64, ptr %slot69, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  store i64 %v4344, ptr %p4346, align 8, !alias.scope !3, !noalias !4
  %v4347 = load i64, ptr %slot55, align 8
  %p4348 = inttoptr i64 %v4347 to ptr
  %ld4349 = load i64, ptr %p4348, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4349, ptr %slot438, align 8
  %v4350 = load i64, ptr %slot438, align 8
  %v4351 = load i64, ptr %slot70, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  store i64 %v4350, ptr %p4352, align 8, !alias.scope !3, !noalias !4
  %v4353 = load i64, ptr %slot70, align 8
  %p4354 = inttoptr i64 %v4353 to ptr
  %ld4355 = load i64, ptr %p4354, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4355, ptr %slot439, align 8
  %v4356 = load i64, ptr %slot69, align 8
  %p4357 = inttoptr i64 %v4356 to ptr
  %ld4358 = load i64, ptr %p4357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4358, ptr %slot440, align 8
  %v4359 = load i64, ptr %slot440, align 8
  %v4360 = load i64, ptr %slot439, align 8
  %ovpair4362 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v4359, i64 %v4360)
  %op4361 = extractvalue { i64, i1 } %ovpair4362, 0
  %ov4363 = extractvalue { i64, i1 } %ovpair4362, 1
  store i64 %op4361, ptr %slot441, align 8
  %v4364 = load i64, ptr %slot440, align 8
  %v4365 = load i64, ptr %slot441, align 8
  %op4366 = xor i64 %v4364, %v4365
  store i64 %op4366, ptr %slot442, align 8
  %v4367 = load i64, ptr %slot439, align 8
  %v4368 = load i64, ptr %slot441, align 8
  %op4369 = xor i64 %v4367, %v4368
  store i64 %op4369, ptr %slot443, align 8
  %v4370 = load i64, ptr %slot442, align 8
  %v4371 = load i64, ptr %slot443, align 8
  %op4372 = and i64 %v4370, %v4371
  store i64 %op4372, ptr %slot444, align 8
  %cv4373 = zext i1 %ov4363 to i64
  store i64 %cv4373, ptr %slot445, align 8
  %v4374 = load i64, ptr %slot445, align 8
  %cond4375 = icmp ne i64 %v4374, 0
  br i1 %cond4375, label %bb_overflow497, label %bb_checked497
bb_overflow497:
  %v4376 = load i64, ptr %slot1, align 8
  %p4377 = inttoptr i64 %v4376 to ptr
  %v4378 = load i64, ptr %slot440, align 8
  %v4379 = load i64, ptr %slot439, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p4377, i64 0, i64 %v4378, i64 %v4379, i64 64) nomerge, !dbg !142
  unreachable
bb_checked497:
  %v4380 = load i64, ptr %slot441, align 8
  %v4381 = load i64, ptr %slot69, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  store i64 %v4380, ptr %p4382, align 8, !alias.scope !3, !noalias !4
  %v4383 = load i64, ptr %slot69, align 8
  %p4384 = inttoptr i64 %v4383 to ptr
  %ld4385 = load i64, ptr %p4384, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4385, ptr %slot446, align 8
  %v4386 = load i64, ptr %slot446, align 8
  %v4387 = load i64, ptr %slot55, align 8
  %p4388 = inttoptr i64 %v4387 to ptr
  store i64 %v4386, ptr %p4388, align 8, !alias.scope !3, !noalias !4
  br label %bb_i50
bb_i50:
  %v4389 = load i64, ptr %slot55, align 8
  %p4390 = inttoptr i64 %v4389 to ptr
  %ld4391 = load i64, ptr %p4390, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4391, ptr %slot447, align 8
  %v4392 = load i64, ptr %slot447, align 8
  %v4393 = load i64, ptr %slot69, align 8
  %p4394 = inttoptr i64 %v4393 to ptr
  store i64 %v4392, ptr %p4394, align 8, !alias.scope !3, !noalias !4
  %v4395 = load i64, ptr %slot54, align 8
  %v4396 = load i64, ptr %slot79, align 8
  %p4397 = inttoptr i64 %v4395 to ptr
  %p4398 = inttoptr i64 %v4396 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4398, ptr %p4397, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4399 = load i64, ptr %slot79, align 8
  %v4400 = load i64, ptr %slot70, align 8
  %p4401 = inttoptr i64 %v4400 to ptr
  store i64 %v4399, ptr %p4401, align 8, !alias.scope !3, !noalias !4
  %v4402 = load i64, ptr %slot53, align 8
  %p4403 = inttoptr i64 %v4402 to ptr
  %ld4404 = load i64, ptr %p4403, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4404, ptr %slot448, align 8
  %v4405 = load i64, ptr %slot70, align 8
  %p4406 = inttoptr i64 %v4405 to ptr
  %ld4407 = load i64, ptr %p4406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4407, ptr %slot449, align 8
  %v4408 = load i64, ptr %slot69, align 8
  %p4409 = inttoptr i64 %v4408 to ptr
  %ld4410 = load i64, ptr %p4409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4410, ptr %slot450, align 8
  %v4411 = load i64, ptr %slot448, align 8
  %p4412 = inttoptr i64 %v4411 to ptr
  %ld4413 = load i64, ptr %p4412, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4413, ptr %slot451, align 8
  %v4414 = load i64, ptr %slot450, align 8
  %v4415 = load i64, ptr %slot451, align 8
  %cmp4416 = icmp ult i64 %v4414, %v4415
  %cv4417 = zext i1 %cmp4416 to i64
  store i64 %cv4417, ptr %slot452, align 8
  %v4418 = load i64, ptr %slot452, align 8
  %cond4419 = icmp ne i64 %v4418, 0
  br i1 %cond4419, label %bb_success510, label %bb_failed510
bb_failed510:
  %v4420 = load i64, ptr %slot1, align 8
  %p4421 = inttoptr i64 %v4420 to ptr
  %v4422 = load i64, ptr %slot450, align 8
  %v4423 = load i64, ptr %slot451, align 8
  call void @myl_qbe_fail_normalized_index_bounds(ptr %p4421, i64 %v4422, i64 %v4423) nomerge, !dbg !144
  unreachable
bb_success510:
  %v4424 = load i64, ptr %slot448, align 8
  %op4425 = add i64 %v4424, 32
  store i64 %op4425, ptr %slot453, align 8
  %v4426 = load i64, ptr %slot453, align 8
  %p4427 = inttoptr i64 %v4426 to ptr
  %ld4428 = load i64, ptr %p4427, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4428, ptr %slot454, align 8
  %v4429 = load i64, ptr %slot450, align 8
  %op4430 = mul i64 %v4429, 16
  store i64 %op4430, ptr %slot455, align 8
  %v4431 = load i64, ptr %slot454, align 8
  %v4432 = load i64, ptr %slot455, align 8
  %op4433 = add i64 %v4431, %v4432
  store i64 %op4433, ptr %slot456, align 8
  %v4434 = load i64, ptr %slot70, align 8
  %p4435 = inttoptr i64 %v4434 to ptr
  %ld4436 = load i64, ptr %p4435, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4436, ptr %slot457, align 8
  %v4437 = load i64, ptr %slot457, align 8
  %v4438 = load i64, ptr %slot456, align 8
  %p4439 = inttoptr i64 %v4437 to ptr
  %p4440 = inttoptr i64 %v4438 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4440, ptr %p4439, i64 16, i1 false)
  %v4441 = load i64, ptr %slot69, align 8
  %p4442 = inttoptr i64 %v4441 to ptr
  store i64 0, ptr %p4442, align 8, !alias.scope !3, !noalias !4
  %v4443 = load i64, ptr %slot43, align 8
  store i64 %v4443, ptr %slot458, align 8
  %v4444 = load i64, ptr %slot458, align 8
  %p4446 = inttoptr i64 %v4444 to ptr
  %gep4447 = getelementptr i8, ptr %p4446, i64 24
  %op4445 = ptrtoint ptr %gep4447 to i64
  store i64 %op4445, ptr %slot459, align 8
  %v4448 = load i64, ptr %slot459, align 8
  %p4449 = inttoptr i64 %v4448 to ptr
  %ld4450 = load i32, ptr %p4449, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4450, ptr %slot460, align 8
  %v4451 = load i32, ptr %slot460, align 8
  %cv4452 = zext i32 %v4451 to i64
  %cond4453 = icmp ne i64 %cv4452, 0
  br i1 %cond4453, label %bb_rcsendactive517, label %bb_rcsenddone517
bb_rcsendactive517:
  %v4454 = load i64, ptr %slot96, align 8
  %p4456 = inttoptr i64 %v4454 to ptr
  %gep4457 = getelementptr i8, ptr %p4456, i64 5640
  %op4455 = ptrtoint ptr %gep4457 to i64
  store i64 %op4455, ptr %slot461, align 8
  %v4458 = load i64, ptr %slot461, align 8
  %p4459 = inttoptr i64 %v4458 to ptr
  %ld4460 = load i64, ptr %p4459, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4460, ptr %slot462, align 8
  %v4461 = load i64, ptr %slot462, align 8
  %op4462 = add i64 %v4461, 248
  store i64 %op4462, ptr %slot463, align 8
  %v4463 = load i64, ptr %slot463, align 8
  %p4464 = inttoptr i64 %v4463 to ptr
  %ld4465 = load i64, ptr %p4464, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4465, ptr %slot464, align 8
  %v4466 = load i64, ptr %slot464, align 8
  %v4467 = load i64, ptr %slot458, align 8
  %cmp4468 = icmp eq i64 %v4466, %v4467
  %cv4469 = zext i1 %cmp4468 to i32
  store i32 %cv4469, ptr %slot465, align 8
  %v4470 = load i32, ptr %slot465, align 8
  %cv4471 = zext i32 %v4470 to i64
  %cond4472 = icmp ne i64 %cv4471, 0
  br i1 %cond4472, label %bb_rcs525, label %bb_rcsendslow517
bb_rcs525:
  %v4473 = load i64, ptr %slot462, align 8
  %op4474 = add i64 %v4473, 200
  store i64 %op4474, ptr %slot466, align 8
  %v4475 = load i64, ptr %slot466, align 8
  %p4476 = inttoptr i64 %v4475 to ptr
  %ld4477 = load i64, ptr %p4476, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4477, ptr %slot467, align 8
  %v4478 = load i64, ptr %slot467, align 8
  %cmp4479 = icmp eq i64 %v4478, 0
  %cv4480 = zext i1 %cmp4479 to i32
  store i32 %cv4480, ptr %slot468, align 8
  %v4481 = load i32, ptr %slot468, align 8
  %cv4482 = zext i32 %v4481 to i64
  %cond4483 = icmp ne i64 %cv4482, 0
  br i1 %cond4483, label %bb_rcs529, label %bb_rcsendslow517
bb_rcs529:
  %v4484 = load i64, ptr %slot458, align 8
  %p4486 = inttoptr i64 %v4484 to ptr
  %gep4487 = getelementptr i8, ptr %p4486, i64 16
  %op4485 = ptrtoint ptr %gep4487 to i64
  store i64 %op4485, ptr %slot469, align 8
  %v4488 = load i64, ptr %slot469, align 8
  %p4489 = inttoptr i64 %v4488 to ptr
  %ld4490 = load i64, ptr %p4489, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4490, ptr %slot470, align 8
  %v4491 = load i64, ptr %slot470, align 8
  %cmp4492 = icmp ne i64 %v4491, 0
  %cv4493 = zext i1 %cmp4492 to i32
  store i32 %cv4493, ptr %slot471, align 8
  %v4494 = load i32, ptr %slot471, align 8
  %cv4495 = zext i32 %v4494 to i64
  %cond4496 = icmp ne i64 %cv4495, 0
  br i1 %cond4496, label %bb_rcsendnode517, label %bb_rcsendunlink517
bb_rcsendnode517:
  %v4497 = load i64, ptr %slot470, align 8
  %op4498 = add i64 %v4497, 0
  store i64 %op4498, ptr %slot472, align 8
  %v4499 = load i64, ptr %slot472, align 8
  %p4500 = inttoptr i64 %v4499 to ptr
  %ld4501 = load i64, ptr %p4500, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4501, ptr %slot473, align 8
  %v4502 = load i64, ptr %slot473, align 8
  %cmp4503 = icmp eq i64 %v4502, 0
  %cv4504 = zext i1 %cmp4503 to i32
  store i32 %cv4504, ptr %slot474, align 8
  %v4505 = load i32, ptr %slot474, align 8
  %cv4506 = zext i32 %v4505 to i64
  %cond4507 = icmp ne i64 %cv4506, 0
  br i1 %cond4507, label %bb_rcs536, label %bb_rcsendslow517
bb_rcs536:
  %v4508 = load i64, ptr %slot462, align 8
  %op4509 = add i64 %v4508, 264
  store i64 %op4509, ptr %slot475, align 8
  %v4510 = load i64, ptr %slot475, align 8
  %p4511 = inttoptr i64 %v4510 to ptr
  %ld4512 = load i64, ptr %p4511, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4512, ptr %slot476, align 8
  %v4513 = load i64, ptr %slot476, align 8
  %cmp4514 = icmp ult i64 %v4513, 32
  %cv4515 = zext i1 %cmp4514 to i32
  store i32 %cv4515, ptr %slot477, align 8
  %v4516 = load i32, ptr %slot477, align 8
  %cv4517 = zext i32 %v4516 to i64
  %cond4518 = icmp ne i64 %cv4517, 0
  br i1 %cond4518, label %bb_rcs540, label %bb_rcsendslow517
bb_rcs540:
  %v4519 = load i64, ptr %slot470, align 8
  %op4520 = add i64 %v4519, 8
  store i64 %op4520, ptr %slot478, align 8
  %v4521 = load i64, ptr %slot478, align 8
  %p4522 = inttoptr i64 %v4521 to ptr
  %ld4523 = load i64, ptr %p4522, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4523, ptr %slot479, align 8
  %v4524 = load i64, ptr %slot479, align 8
  %cmp4525 = icmp ne i64 %v4524, 0
  %cv4526 = zext i1 %cmp4525 to i32
  store i32 %cv4526, ptr %slot480, align 8
  %v4527 = load i32, ptr %slot480, align 8
  %cv4528 = zext i32 %v4527 to i64
  %cond4529 = icmp ne i64 %cv4528, 0
  br i1 %cond4529, label %bb_rcs544, label %bb_rcsendslow517
bb_rcs544:
  %v4530 = load i64, ptr %slot479, align 8
  %op4531 = sub i64 %v4530, 16
  store i64 %op4531, ptr %slot481, align 8
  %v4532 = load i64, ptr %slot479, align 8
  %p4533 = inttoptr i64 %v4532 to ptr
  %rgep4534 = getelementptr i8, ptr %p4533, i64 -16
  %ld4535 = load i64, ptr %rgep4534, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4535, ptr %slot482, align 8
  %v4536 = load i64, ptr %slot482, align 8
  %op4537 = and i64 %v4536, 4611686018427387907
  store i64 %op4537, ptr %slot483, align 8
  %v4538 = load i64, ptr %slot483, align 8
  %cmp4539 = icmp eq i64 %v4538, 0
  %cv4540 = zext i1 %cmp4539 to i32
  store i32 %cv4540, ptr %slot484, align 8
  %v4541 = load i32, ptr %slot484, align 8
  %cv4542 = zext i32 %v4541 to i64
  %cond4543 = icmp ne i64 %cv4542, 0
  br i1 %cond4543, label %bb_rcs549, label %bb_rcsendslow517
bb_rcs549:
  %v4544 = load i64, ptr %slot479, align 8
  %op4545 = sub i64 %v4544, 24
  store i64 %op4545, ptr %slot485, align 8
  %v4546 = load i64, ptr %slot479, align 8
  %p4547 = inttoptr i64 %v4546 to ptr
  %rgep4548 = getelementptr i8, ptr %p4547, i64 -24
  %ld4549 = load i64, ptr %rgep4548, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4549, ptr %slot486, align 8
  %v4550 = load i64, ptr %slot486, align 8
  %cmp4551 = icmp ne i64 %v4550, 0
  %cv4552 = zext i1 %cmp4551 to i32
  store i32 %cv4552, ptr %slot487, align 8
  %v4553 = load i32, ptr %slot487, align 8
  %cv4554 = zext i32 %v4553 to i64
  %cond4555 = icmp ne i64 %cv4554, 0
  br i1 %cond4555, label %bb_rcs553, label %bb_rcsendslow517
bb_rcs553:
  %v4556 = load i64, ptr %slot479, align 8
  %op4557 = sub i64 %v4556, 32
  store i64 %op4557, ptr %slot488, align 8
  %v4558 = load i64, ptr %slot479, align 8
  %p4559 = inttoptr i64 %v4558 to ptr
  %rgep4560 = getelementptr i8, ptr %p4559, i64 -32
  %ld4561 = load i64, ptr %rgep4560, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4561, ptr %slot489, align 8
  %v4562 = load i64, ptr %slot486, align 8
  %cmp4563 = icmp ugt i64 %v4562, 1
  %cv4564 = zext i1 %cmp4563 to i32
  store i32 %cv4564, ptr %slot490, align 8
  %v4565 = load i64, ptr %slot489, align 8
  %cmp4566 = icmp ne i64 %v4565, 0
  %cv4567 = zext i1 %cmp4566 to i32
  store i32 %cv4567, ptr %slot491, align 8
  %v4568 = load i32, ptr %slot490, align 8
  %v4569 = load i32, ptr %slot491, align 8
  %op4570 = or i32 %v4568, %v4569
  store i32 %op4570, ptr %slot492, align 8
  %v4571 = load i32, ptr %slot492, align 8
  %cv4572 = zext i32 %v4571 to i64
  %cond4573 = icmp ne i64 %cv4572, 0
  br i1 %cond4573, label %bb_rcs559, label %bb_rcsendslow517
bb_rcs559:
  %v4574 = load i64, ptr %slot470, align 8
  %op4575 = add i64 %v4574, 32
  store i64 %op4575, ptr %slot493, align 8
  %v4576 = load i64, ptr %slot493, align 8
  %p4577 = inttoptr i64 %v4576 to ptr
  %ld4578 = load i64, ptr %p4577, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4578, ptr %slot494, align 8
  %v4579 = load i64, ptr %slot494, align 8
  %cmp4580 = icmp ne i64 %v4579, 0
  %cv4581 = zext i1 %cmp4580 to i32
  store i32 %cv4581, ptr %slot495, align 8
  %v4582 = load i32, ptr %slot495, align 8
  %cv4583 = zext i32 %v4582 to i64
  %cond4584 = icmp ne i64 %cv4583, 0
  br i1 %cond4584, label %bb_rcsendbacking517, label %bb_rcsendcommit517
bb_rcsendbacking517:
  %v4585 = load i64, ptr %slot494, align 8
  %op4586 = sub i64 %v4585, 16
  store i64 %op4586, ptr %slot496, align 8
  %v4587 = load i64, ptr %slot494, align 8
  %p4588 = inttoptr i64 %v4587 to ptr
  %rgep4589 = getelementptr i8, ptr %p4588, i64 -16
  %ld4590 = load i64, ptr %rgep4589, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4590, ptr %slot497, align 8
  %v4591 = load i64, ptr %slot497, align 8
  %op4592 = and i64 %v4591, 4611686018427387907
  store i64 %op4592, ptr %slot498, align 8
  %v4593 = load i64, ptr %slot498, align 8
  %cmp4594 = icmp eq i64 %v4593, 0
  %cv4595 = zext i1 %cmp4594 to i32
  store i32 %cv4595, ptr %slot499, align 8
  %v4596 = load i32, ptr %slot499, align 8
  %cv4597 = zext i32 %v4596 to i64
  %cond4598 = icmp ne i64 %cv4597, 0
  br i1 %cond4598, label %bb_rcs567, label %bb_rcsendslow517
bb_rcs567:
  %v4599 = load i64, ptr %slot494, align 8
  %op4600 = sub i64 %v4599, 24
  store i64 %op4600, ptr %slot500, align 8
  %v4601 = load i64, ptr %slot494, align 8
  %p4602 = inttoptr i64 %v4601 to ptr
  %rgep4603 = getelementptr i8, ptr %p4602, i64 -24
  %ld4604 = load i64, ptr %rgep4603, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4604, ptr %slot501, align 8
  %v4605 = load i64, ptr %slot501, align 8
  %cmp4606 = icmp ne i64 %v4605, 0
  %cv4607 = zext i1 %cmp4606 to i32
  store i32 %cv4607, ptr %slot502, align 8
  %v4608 = load i32, ptr %slot502, align 8
  %cv4609 = zext i32 %v4608 to i64
  %cond4610 = icmp ne i64 %cv4609, 0
  br i1 %cond4610, label %bb_rcs571, label %bb_rcsendslow517
bb_rcs571:
  %v4611 = load i64, ptr %slot494, align 8
  %op4612 = sub i64 %v4611, 32
  store i64 %op4612, ptr %slot503, align 8
  %v4613 = load i64, ptr %slot494, align 8
  %p4614 = inttoptr i64 %v4613 to ptr
  %rgep4615 = getelementptr i8, ptr %p4614, i64 -32
  %ld4616 = load i64, ptr %rgep4615, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4616, ptr %slot504, align 8
  %v4617 = load i64, ptr %slot501, align 8
  %cmp4618 = icmp ugt i64 %v4617, 1
  %cv4619 = zext i1 %cmp4618 to i32
  store i32 %cv4619, ptr %slot505, align 8
  %v4620 = load i64, ptr %slot504, align 8
  %cmp4621 = icmp ne i64 %v4620, 0
  %cv4622 = zext i1 %cmp4621 to i32
  store i32 %cv4622, ptr %slot506, align 8
  %v4623 = load i32, ptr %slot505, align 8
  %v4624 = load i32, ptr %slot506, align 8
  %op4625 = or i32 %v4623, %v4624
  store i32 %op4625, ptr %slot507, align 8
  %v4626 = load i32, ptr %slot507, align 8
  %cv4627 = zext i32 %v4626 to i64
  %cond4628 = icmp ne i64 %cv4627, 0
  br i1 %cond4628, label %bb_rcs577, label %bb_rcsendslow517
bb_rcs577:
  br label %bb_rcsendcommit517
bb_rcsendcommit517:
  %v4629 = load i64, ptr %slot470, align 8
  %op4630 = add i64 %v4629, 24
  store i64 %op4630, ptr %slot508, align 8
  %v4631 = load i64, ptr %slot508, align 8
  %p4632 = inttoptr i64 %v4631 to ptr
  %ld4633 = load i32, ptr %p4632, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld4633, ptr %slot509, align 8
  %v4634 = load i32, ptr %slot509, align 8
  %cv4635 = zext i32 %v4634 to i64
  %cond4636 = icmp ne i64 %cv4635, 0
  br i1 %cond4636, label %bb_rcsendrestore517, label %bb_rcsendreturned517
bb_rcsendrestore517:
  %v4637 = load i64, ptr %slot470, align 8
  %op4638 = add i64 %v4637, 16
  store i64 %op4638, ptr %slot510, align 8
  %v4639 = load i64, ptr %slot510, align 8
  %p4640 = inttoptr i64 %v4639 to ptr
  %ld4641 = load i64, ptr %p4640, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4641, ptr %slot511, align 8
  %v4642 = load i64, ptr %slot482, align 8
  %op4643 = and i64 %v4642, 17293822569102704639
  store i64 %op4643, ptr %slot512, align 8
  %v4644 = load i64, ptr %slot512, align 8
  %v4645 = load i64, ptr %slot511, align 8
  %op4646 = or i64 %v4644, %v4645
  store i64 %op4646, ptr %slot513, align 8
  %v4647 = load i64, ptr %slot479, align 8
  %op4648 = sub i64 %v4647, 16
  store i64 %op4648, ptr %slot514, align 8
  %v4649 = load i64, ptr %slot513, align 8
  %v4650 = load i64, ptr %slot479, align 8
  %p4651 = inttoptr i64 %v4650 to ptr
  %rgep4652 = getelementptr i8, ptr %p4651, i64 -16
  store i64 %v4649, ptr %rgep4652, align 8, !alias.scope !9, !noalias !10
  %v4653 = load i64, ptr %slot458, align 8
  %p4655 = inttoptr i64 %v4653 to ptr
  %gep4656 = getelementptr i8, ptr %p4655, i64 16
  %op4654 = ptrtoint ptr %gep4656 to i64
  store i64 %op4654, ptr %slot515, align 8
  br label %bb_rcsendreturned517
bb_rcsendreturned517:
  %v4657 = load i64, ptr %slot515, align 8
  %p4658 = inttoptr i64 %v4657 to ptr
  store i64 0, ptr %p4658, align 8, !alias.scope !3, !noalias !4
  %v4659 = load i64, ptr %slot462, align 8
  %op4660 = add i64 %v4659, 256
  store i64 %op4660, ptr %slot516, align 8
  %v4661 = load i64, ptr %slot516, align 8
  %p4662 = inttoptr i64 %v4661 to ptr
  %ld4663 = load i64, ptr %p4662, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4663, ptr %slot517, align 8
  %v4664 = load i64, ptr %slot470, align 8
  %op4665 = add i64 %v4664, 0
  store i64 %op4665, ptr %slot518, align 8
  %v4666 = load i64, ptr %slot517, align 8
  %v4667 = load i64, ptr %slot518, align 8
  %p4668 = inttoptr i64 %v4667 to ptr
  store i64 %v4666, ptr %p4668, align 8, !alias.scope !9999998, !noalias !9999999
  %v4669 = load i64, ptr %slot462, align 8
  %op4670 = add i64 %v4669, 256
  store i64 %op4670, ptr %slot519, align 8
  %v4671 = load i64, ptr %slot470, align 8
  %v4672 = load i64, ptr %slot519, align 8
  %p4673 = inttoptr i64 %v4672 to ptr
  store i64 %v4671, ptr %p4673, align 8, !alias.scope !9999998, !noalias !9999999
  %v4674 = load i64, ptr %slot462, align 8
  %op4675 = add i64 %v4674, 264
  store i64 %op4675, ptr %slot520, align 8
  %v4676 = load i64, ptr %slot520, align 8
  %p4677 = inttoptr i64 %v4676 to ptr
  %ld4678 = load i64, ptr %p4677, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4678, ptr %slot521, align 8
  %v4679 = load i64, ptr %slot521, align 8
  %op4680 = add i64 %v4679, 1
  store i64 %op4680, ptr %slot522, align 8
  %v4681 = load i64, ptr %slot522, align 8
  %v4682 = load i64, ptr %slot520, align 8
  %p4683 = inttoptr i64 %v4682 to ptr
  store i64 %v4681, ptr %p4683, align 8, !alias.scope !9999998, !noalias !9999999
  %v4684 = load i64, ptr %slot96, align 8
  %p4686 = inttoptr i64 %v4684 to ptr
  %gep4687 = getelementptr i8, ptr %p4686, i64 24
  %op4685 = ptrtoint ptr %gep4687 to i64
  store i64 %op4685, ptr %slot523, align 8
  %v4688 = load i64, ptr %slot523, align 8
  %p4689 = inttoptr i64 %v4688 to ptr
  %ld4690 = load i64, ptr %p4689, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4690, ptr %slot524, align 8
  %v4691 = load i64, ptr %slot524, align 8
  %op4692 = add i64 %v4691, 18446744073709551576
  store i64 %op4692, ptr %slot525, align 8
  %v4693 = load i64, ptr %slot525, align 8
  %v4694 = load i64, ptr %slot523, align 8
  %p4695 = inttoptr i64 %v4694 to ptr
  store i64 %v4693, ptr %p4695, align 8, !alias.scope !9999998, !noalias !9999999
  %v4696 = load i64, ptr %slot462, align 8
  %op4697 = add i64 %v4696, 48
  store i64 %op4697, ptr %slot526, align 8
  %v4698 = load i64, ptr %slot526, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  %ld4700 = load i64, ptr %p4699, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4700, ptr %slot527, align 8
  %v4701 = load i64, ptr %slot527, align 8
  %op4702 = add i64 %v4701, 18446744073709551576
  store i64 %op4702, ptr %slot528, align 8
  %v4703 = load i64, ptr %slot528, align 8
  %v4704 = load i64, ptr %slot526, align 8
  %p4705 = inttoptr i64 %v4704 to ptr
  store i64 %v4703, ptr %p4705, align 8, !alias.scope !9999998, !noalias !9999999
  %v4706 = load i64, ptr %slot494, align 8
  %cmp4707 = icmp ne i64 %v4706, 0
  %cv4708 = zext i1 %cmp4707 to i32
  store i32 %cv4708, ptr %slot529, align 8
  %v4709 = load i32, ptr %slot529, align 8
  %cv4710 = zext i32 %v4709 to i64
  %cond4711 = icmp ne i64 %cv4710, 0
  br i1 %cond4711, label %bb_rcsenddropbacking517, label %bb_rcsenddroppayload517
bb_rcsenddropbacking517:
  %v4712 = load i64, ptr %slot494, align 8
  %op4713 = sub i64 %v4712, 24
  store i64 %op4713, ptr %slot530, align 8
  %v4714 = load i64, ptr %slot494, align 8
  %p4715 = inttoptr i64 %v4714 to ptr
  %rgep4716 = getelementptr i8, ptr %p4715, i64 -24
  %ld4717 = load i64, ptr %rgep4716, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4717, ptr %slot531, align 8
  %v4718 = load i64, ptr %slot531, align 8
  %op4719 = add i64 %v4718, 18446744073709551615
  store i64 %op4719, ptr %slot532, align 8
  %v4720 = load i64, ptr %slot532, align 8
  %v4721 = load i64, ptr %slot494, align 8
  %p4722 = inttoptr i64 %v4721 to ptr
  %rgep4723 = getelementptr i8, ptr %p4722, i64 -24
  store i64 %v4720, ptr %rgep4723, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload517
bb_rcsenddroppayload517:
  %v4724 = load i64, ptr %slot479, align 8
  %op4725 = sub i64 %v4724, 24
  store i64 %op4725, ptr %slot533, align 8
  %v4726 = load i64, ptr %slot479, align 8
  %p4727 = inttoptr i64 %v4726 to ptr
  %rgep4728 = getelementptr i8, ptr %p4727, i64 -24
  %ld4729 = load i64, ptr %rgep4728, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4729, ptr %slot534, align 8
  %v4730 = load i64, ptr %slot534, align 8
  %op4731 = add i64 %v4730, 18446744073709551615
  store i64 %op4731, ptr %slot535, align 8
  %v4732 = load i64, ptr %slot535, align 8
  %v4733 = load i64, ptr %slot479, align 8
  %p4734 = inttoptr i64 %v4733 to ptr
  %rgep4735 = getelementptr i8, ptr %p4734, i64 -24
  store i64 %v4732, ptr %rgep4735, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink517
bb_rcsendunlink517:
  %v4736 = load i64, ptr %slot458, align 8
  %p4738 = inttoptr i64 %v4736 to ptr
  %gep4739 = getelementptr i8, ptr %p4738, i64 8
  %op4737 = ptrtoint ptr %gep4739 to i64
  store i64 %op4737, ptr %slot536, align 8
  %v4740 = load i64, ptr %slot536, align 8
  %p4741 = inttoptr i64 %v4740 to ptr
  %ld4742 = load i64, ptr %p4741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4742, ptr %slot537, align 8
  %v4743 = load i64, ptr %slot462, align 8
  %op4744 = add i64 %v4743, 248
  store i64 %op4744, ptr %slot538, align 8
  %v4745 = load i64, ptr %slot537, align 8
  %v4746 = load i64, ptr %slot538, align 8
  %p4747 = inttoptr i64 %v4746 to ptr
  store i64 %v4745, ptr %p4747, align 8, !alias.scope !9999998, !noalias !9999999
  %v4748 = load i64, ptr %slot458, align 8
  %p4750 = inttoptr i64 %v4748 to ptr
  %gep4751 = getelementptr i8, ptr %p4750, i64 24
  %op4749 = ptrtoint ptr %gep4751 to i64
  store i64 %op4749, ptr %slot539, align 8
  %v4752 = load i64, ptr %slot458, align 8
  %p4754 = inttoptr i64 %v4752 to ptr
  %gep4755 = getelementptr i8, ptr %p4754, i64 8
  %op4753 = ptrtoint ptr %gep4755 to i64
  store i64 %op4753, ptr %slot540, align 8
  %v4756 = load i64, ptr %slot539, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  store i32 0, ptr %p4757, align 4, !alias.scope !3, !noalias !4
  %v4758 = load i64, ptr %slot540, align 8
  %p4759 = inttoptr i64 %v4758 to ptr
  store i64 0, ptr %p4759, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone517
bb_rcsendslow517:
  %v4760 = load i64, ptr %slot1, align 8
  %p4761 = inttoptr i64 %v4760 to ptr
  %v4762 = load i64, ptr %slot458, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p4761, ptr %p4763) nomerge, !dbg !144
  br label %bb_rcsenddone517
bb_rcsenddone517:
  %v4764 = load i64, ptr %slot46, align 8
  %p4765 = inttoptr i64 %v4764 to ptr
  %ld4766 = load i64, ptr %p4765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4766, ptr %slot541, align 8
  %v4767 = load i64, ptr %slot541, align 8
  %v4768 = load i64, ptr %slot69, align 8
  %p4769 = inttoptr i64 %v4768 to ptr
  store i64 %v4767, ptr %p4769, align 8, !alias.scope !3, !noalias !4
  %v4770 = load i64, ptr %slot69, align 8
  %p4771 = inttoptr i64 %v4770 to ptr
  %ld4772 = load i64, ptr %p4771, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4772, ptr %slot542, align 8
  %v4773 = load i64, ptr %slot542, align 8
  %op4774 = add i64 %v4773, 32
  store i64 %op4774, ptr %slot543, align 8
  %v4775 = load i64, ptr %slot543, align 8
  %v4776 = load i64, ptr %slot69, align 8
  %p4777 = inttoptr i64 %v4776 to ptr
  store i64 %v4775, ptr %p4777, align 8, !alias.scope !3, !noalias !4
  %v4778 = load i64, ptr %slot28, align 8
  %p4779 = inttoptr i64 %v4778 to ptr
  %ld4780 = load i32, ptr %p4779, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4780, ptr %slot544, align 8
  %v4781 = load i32, ptr %slot544, align 8
  %cv4782 = zext i32 %v4781 to i64
  %cond4783 = icmp ne i64 %cv4782, 0
  br i1 %cond4783, label %bb_rcslotdrop616, label %bb_rcslotdone616
bb_rcslotdrop616:
  %v4784 = load i64, ptr %slot28, align 8
  %p4785 = inttoptr i64 %v4784 to ptr
  store i32 0, ptr %p4785, align 4, !alias.scope !3, !noalias !4
  %v4786 = load i64, ptr %slot37, align 8
  store i64 %v4786, ptr %slot545, align 8
  %v4787 = load i64, ptr %slot29, align 8
  %p4788 = inttoptr i64 %v4787 to ptr
  %ld4789 = load i32, ptr %p4788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4789, ptr %slot546, align 8
  %v4790 = load i32, ptr %slot546, align 8
  %op4791 = and i32 %v4790, 28
  store i32 %op4791, ptr %slot547, align 8
  %v4792 = load i32, ptr %slot547, align 8
  %cv4793 = zext i32 %v4792 to i64
  %cond4794 = icmp ne i64 %cv4793, 0
  br i1 %cond4794, label %bb_rcslotrole616, label %bb_rcslotowner616
bb_rcslotrole616:
  %v4795 = load i64, ptr %slot96, align 8
  store i64 %v4795, ptr %slot548, align 8
  %v4796 = load i64, ptr %slot548, align 8
  %v4797 = load i64, ptr %slot545, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v4796, i64 %v4797) nomerge, !dbg !146
  br label %bb_rcslotdone616
bb_rcslotowner616:
  %v4798 = load i64, ptr %slot96, align 8
  store i64 %v4798, ptr %slot549, align 8
  %v4799 = load i64, ptr %slot549, align 8
  %v4800 = load i64, ptr %slot545, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v4799, i64 %v4800) nomerge, !dbg !146
  br label %bb_rcslotdone616
bb_rcslotdone616:
  %v4801 = load i64, ptr %slot47, align 8
  %p4802 = inttoptr i64 %v4801 to ptr
  %ld4803 = load i64, ptr %p4802, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4803, ptr %slot550, align 8
  %v4804 = load i64, ptr %slot550, align 8
  %v4805 = load i64, ptr %slot70, align 8
  %p4806 = inttoptr i64 %v4805 to ptr
  store i64 %v4804, ptr %p4806, align 8, !alias.scope !3, !noalias !4
  %v4807 = load i64, ptr %slot69, align 8
  %p4808 = inttoptr i64 %v4807 to ptr
  %ld4809 = load i64, ptr %p4808, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4809, ptr %slot551, align 8
  %v4810 = load i64, ptr %slot70, align 8
  %p4811 = inttoptr i64 %v4810 to ptr
  %ld4812 = load i64, ptr %p4811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4812, ptr %slot552, align 8
  %v4813 = load i64, ptr %slot1, align 8
  %v4814 = load i64, ptr %slot551, align 8
  %v4815 = load i64, ptr %slot552, align 8
  call void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8 %callresult554, i64 %v4813, i64 %v4814, i64 %v4815) nomerge, !dbg !148
  %addr4816 = ptrtoint ptr %callresult554 to i64
  store i64 %addr4816, ptr %slot553, align 8
  %v4817 = load i64, ptr %slot553, align 8
  %v4818 = load i64, ptr %slot69, align 8
  %p4819 = inttoptr i64 %v4818 to ptr
  store i64 %v4817, ptr %p4819, align 8, !alias.scope !3, !noalias !4
  %v4820 = load i64, ptr %slot69, align 8
  %p4821 = inttoptr i64 %v4820 to ptr
  %ld4822 = load i64, ptr %p4821, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4822, ptr %slot555, align 8
  %v4823 = load i64, ptr %slot41, align 8
  store i64 %v4823, ptr %slot556, align 8
  %v4824 = load i64, ptr %slot555, align 8
  %v4825 = load i64, ptr %slot556, align 8
  %p4826 = inttoptr i64 %v4824 to ptr
  %p4827 = inttoptr i64 %v4825 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4827, ptr %p4826, i64 24, i1 false)
  %v4828 = load i64, ptr %slot35, align 8
  %p4829 = inttoptr i64 %v4828 to ptr
  store i32 2, ptr %p4829, align 4, !alias.scope !3, !noalias !4
  %v4830 = load i64, ptr %slot34, align 8
  %p4831 = inttoptr i64 %v4830 to ptr
  store i32 1, ptr %p4831, align 4, !alias.scope !3, !noalias !4
  %v4832 = load i64, ptr %slot28, align 8
  %p4833 = inttoptr i64 %v4832 to ptr
  %ld4834 = load i32, ptr %p4833, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4834, ptr %slot557, align 8
  %v4835 = load i32, ptr %slot557, align 8
  %cv4836 = zext i32 %v4835 to i64
  %cond4837 = icmp ne i64 %cv4836, 0
  br i1 %cond4837, label %bb_rcslotdrop633, label %bb_rcslotdone633
bb_rcslotdrop633:
  %v4838 = load i64, ptr %slot28, align 8
  %p4839 = inttoptr i64 %v4838 to ptr
  store i32 0, ptr %p4839, align 4, !alias.scope !3, !noalias !4
  %v4840 = load i64, ptr %slot37, align 8
  store i64 %v4840, ptr %slot558, align 8
  %v4841 = load i64, ptr %slot29, align 8
  %p4842 = inttoptr i64 %v4841 to ptr
  %ld4843 = load i32, ptr %p4842, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4843, ptr %slot559, align 8
  %v4844 = load i32, ptr %slot559, align 8
  %op4845 = and i32 %v4844, 28
  store i32 %op4845, ptr %slot560, align 8
  %v4846 = load i32, ptr %slot560, align 8
  %cv4847 = zext i32 %v4846 to i64
  %cond4848 = icmp ne i64 %cv4847, 0
  br i1 %cond4848, label %bb_rcslotrole633, label %bb_rcslotowner633
bb_rcslotrole633:
  %v4849 = load i64, ptr %slot96, align 8
  store i64 %v4849, ptr %slot561, align 8
  %v4850 = load i64, ptr %slot561, align 8
  %v4851 = load i64, ptr %slot558, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4850, i64 %v4851) nomerge, !dbg !148
  br label %bb_rcslotdone633
bb_rcslotowner633:
  %v4852 = load i64, ptr %slot96, align 8
  store i64 %v4852, ptr %slot562, align 8
  %v4853 = load i64, ptr %slot562, align 8
  %v4854 = load i64, ptr %slot558, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4853, i64 %v4854) nomerge, !dbg !148
  br label %bb_rcslotdone633
bb_rcslotdone633:
  %v4855 = load i64, ptr %slot37, align 8
  store i64 %v4855, ptr %slot563, align 8
  %v4856 = load i64, ptr %slot41, align 8
  store i64 %v4856, ptr %slot564, align 8
  %v4857 = load i64, ptr %slot564, align 8
  %v4858 = load i64, ptr %slot563, align 8
  %p4859 = inttoptr i64 %v4857 to ptr
  %p4860 = inttoptr i64 %v4858 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4860, ptr %p4859, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v4861 = load i64, ptr %slot29, align 8
  %p4862 = inttoptr i64 %v4861 to ptr
  store i32 2, ptr %p4862, align 4, !alias.scope !3, !noalias !4
  %v4863 = load i64, ptr %slot35, align 8
  %p4864 = inttoptr i64 %v4863 to ptr
  %ld4865 = load i32, ptr %p4864, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4865, ptr %slot565, align 8
  %v4866 = load i32, ptr %slot565, align 8
  %v4867 = load i64, ptr %slot29, align 8
  %p4868 = inttoptr i64 %v4867 to ptr
  store i32 %v4866, ptr %p4868, align 4, !alias.scope !3, !noalias !4
  %v4869 = load i64, ptr %slot34, align 8
  %p4870 = inttoptr i64 %v4869 to ptr
  store i32 0, ptr %p4870, align 4, !alias.scope !3, !noalias !4
  %v4871 = load i64, ptr %slot28, align 8
  %p4872 = inttoptr i64 %v4871 to ptr
  store i32 1, ptr %p4872, align 4, !alias.scope !3, !noalias !4
  %v4873 = load i64, ptr %slot563, align 8
  %v4874 = load i64, ptr %slot69, align 8
  %p4875 = inttoptr i64 %v4874 to ptr
  store i64 %v4873, ptr %p4875, align 8, !alias.scope !3, !noalias !4
  %v4876 = load i64, ptr %slot69, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %ld4878 = load i64, ptr %p4877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4878, ptr %slot566, align 8
  %v4879 = load i64, ptr %slot566, align 8
  %op4880 = add i64 %v4879, 8
  store i64 %op4880, ptr %slot567, align 8
  %v4881 = load i64, ptr %slot567, align 8
  %v4882 = load i64, ptr %slot69, align 8
  %p4883 = inttoptr i64 %v4882 to ptr
  store i64 %v4881, ptr %p4883, align 8, !alias.scope !3, !noalias !4
  %v4884 = load i64, ptr %slot69, align 8
  %p4885 = inttoptr i64 %v4884 to ptr
  %ld4886 = load i64, ptr %p4885, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4886, ptr %slot568, align 8
  %v4887 = load i64, ptr %slot41, align 8
  store i64 %v4887, ptr %slot569, align 8
  %v4888 = load i64, ptr %slot96, align 8
  %v4889 = load i64, ptr %slot569, align 8
  %v4890 = load i64, ptr %slot568, align 8
  %call4891 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64 %v4888, i64 %v4889, i64 %v4890) nomerge, !dbg !150
  store i32 %call4891, ptr %slot570, align 8
  %v4892 = load i32, ptr %slot570, align 8
  %cv4893 = zext i32 %v4892 to i64
  %cond4894 = icmp ne i64 %cv4893, 0
  br i1 %cond4894, label %bb_rcsuccess653, label %bb_rcfailure653
bb_rcfailure653:
  %v4895 = load i64, ptr %slot96, align 8
  %p4896 = inttoptr i64 %v4895 to ptr
  %call4897 = call i32 @myl_rc_take_failure(ptr %p4896) nomerge, !dbg !150
  store i32 %call4897, ptr %slot571, align 8
  %v4898 = load i64, ptr %slot1, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  %v4900 = load i32, ptr %slot571, align 8
  %call4901 = call i32 @myl_qbe_rc_status(ptr %p4899, i32 %v4900) nomerge, !dbg !150
  store i32 %call4901, ptr %slot572, align 8
  br label %bb_failure
bb_rcsuccess653:
  %v4902 = load i64, ptr %slot35, align 8
  %p4903 = inttoptr i64 %v4902 to ptr
  store i32 2, ptr %p4903, align 4, !alias.scope !3, !noalias !4
  %v4904 = load i64, ptr %slot35, align 8
  %p4905 = inttoptr i64 %v4904 to ptr
  store i32 16, ptr %p4905, align 4, !alias.scope !3, !noalias !4
  %v4906 = load i64, ptr %slot34, align 8
  %p4907 = inttoptr i64 %v4906 to ptr
  store i32 1, ptr %p4907, align 4, !alias.scope !3, !noalias !4
  %v4908 = load i64, ptr %slot28, align 8
  %p4909 = inttoptr i64 %v4908 to ptr
  %ld4910 = load i32, ptr %p4909, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4910, ptr %slot573, align 8
  %v4911 = load i32, ptr %slot573, align 8
  %cv4912 = zext i32 %v4911 to i64
  %cond4913 = icmp ne i64 %cv4912, 0
  br i1 %cond4913, label %bb_rcslotdrop661, label %bb_rcslotdone661
bb_rcslotdrop661:
  %v4914 = load i64, ptr %slot28, align 8
  %p4915 = inttoptr i64 %v4914 to ptr
  store i32 0, ptr %p4915, align 4, !alias.scope !3, !noalias !4
  %v4916 = load i64, ptr %slot37, align 8
  store i64 %v4916, ptr %slot574, align 8
  %v4917 = load i64, ptr %slot29, align 8
  %p4918 = inttoptr i64 %v4917 to ptr
  %ld4919 = load i32, ptr %p4918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4919, ptr %slot575, align 8
  %v4920 = load i32, ptr %slot575, align 8
  %op4921 = and i32 %v4920, 28
  store i32 %op4921, ptr %slot576, align 8
  %v4922 = load i32, ptr %slot576, align 8
  %cv4923 = zext i32 %v4922 to i64
  %cond4924 = icmp ne i64 %cv4923, 0
  br i1 %cond4924, label %bb_rcslotrole661, label %bb_rcslotowner661
bb_rcslotrole661:
  %v4925 = load i64, ptr %slot96, align 8
  store i64 %v4925, ptr %slot577, align 8
  %v4926 = load i64, ptr %slot577, align 8
  %v4927 = load i64, ptr %slot574, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64 %v4926, i64 %v4927) nomerge, !dbg !150
  br label %bb_rcslotdone661
bb_rcslotowner661:
  %v4928 = load i64, ptr %slot96, align 8
  store i64 %v4928, ptr %slot578, align 8
  %v4929 = load i64, ptr %slot578, align 8
  %v4930 = load i64, ptr %slot574, align 8
  call void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64 %v4929, i64 %v4930) nomerge, !dbg !150
  br label %bb_rcslotdone661
bb_rcslotdone661:
  %v4931 = load i64, ptr %slot37, align 8
  store i64 %v4931, ptr %slot579, align 8
  %v4932 = load i64, ptr %slot41, align 8
  store i64 %v4932, ptr %slot580, align 8
  %v4933 = load i64, ptr %slot580, align 8
  %v4934 = load i64, ptr %slot579, align 8
  %p4935 = inttoptr i64 %v4933 to ptr
  %p4936 = inttoptr i64 %v4934 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4936, ptr %p4935, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v4937 = load i64, ptr %slot29, align 8
  %p4938 = inttoptr i64 %v4937 to ptr
  store i32 2, ptr %p4938, align 4, !alias.scope !3, !noalias !4
  %v4939 = load i64, ptr %slot35, align 8
  %p4940 = inttoptr i64 %v4939 to ptr
  %ld4941 = load i32, ptr %p4940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4941, ptr %slot581, align 8
  %v4942 = load i32, ptr %slot581, align 8
  %v4943 = load i64, ptr %slot29, align 8
  %p4944 = inttoptr i64 %v4943 to ptr
  store i32 %v4942, ptr %p4944, align 4, !alias.scope !3, !noalias !4
  %v4945 = load i64, ptr %slot34, align 8
  %p4946 = inttoptr i64 %v4945 to ptr
  store i32 0, ptr %p4946, align 4, !alias.scope !3, !noalias !4
  %v4947 = load i64, ptr %slot28, align 8
  %p4948 = inttoptr i64 %v4947 to ptr
  store i32 1, ptr %p4948, align 4, !alias.scope !3, !noalias !4
  %v4949 = load i64, ptr %slot579, align 8
  %v4950 = load i64, ptr %slot69, align 8
  %p4951 = inttoptr i64 %v4950 to ptr
  store i64 %v4949, ptr %p4951, align 8, !alias.scope !3, !noalias !4
  %v4952 = load i64, ptr %slot69, align 8
  %p4953 = inttoptr i64 %v4952 to ptr
  %ld4954 = load i64, ptr %p4953, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4954, ptr %slot582, align 8
  %v4955 = load i64, ptr %slot28, align 8
  %p4956 = inttoptr i64 %v4955 to ptr
  %ld4957 = load i32, ptr %p4956, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4957, ptr %slot583, align 8
  %v4958 = load i64, ptr %slot29, align 8
  %p4959 = inttoptr i64 %v4958 to ptr
  %ld4960 = load i32, ptr %p4959, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4960, ptr %slot584, align 8
  %v4961 = load i32, ptr %slot584, align 8
  %op4962 = and i32 %v4961, 24
  store i32 %op4962, ptr %slot584, align 8
  %v4963 = load i32, ptr %slot584, align 8
  %cmp4964 = icmp eq i32 %v4963, 0
  %cv4965 = zext i1 %cmp4964 to i32
  store i32 %cv4965, ptr %slot585, align 8
  %v4966 = load i32, ptr %slot583, align 8
  %v4967 = load i32, ptr %slot585, align 8
  %op4968 = and i32 %v4966, %v4967
  store i32 %op4968, ptr %slot586, align 8
  %v4969 = load i32, ptr %slot586, align 8
  %cv4970 = zext i32 %v4969 to i64
  %cond4971 = icmp ne i64 %cv4970, 0
  br i1 %cond4971, label %bb_rctake677, label %bb_rccopy677
bb_rctake677:
  %v4972 = load i64, ptr %slot41, align 8
  store i64 %v4972, ptr %slot587, align 8
  %v4973 = load i64, ptr %slot97, align 8
  store i64 %v4973, ptr %slot588, align 8
  %v4974 = load i64, ptr %slot582, align 8
  %v4975 = load i64, ptr %slot587, align 8
  %op4976 = sub i64 %v4974, %v4975
  store i64 %op4976, ptr %slot589, align 8
  %v4977 = load i64, ptr %slot587, align 8
  %v4978 = load i64, ptr %slot582, align 8
  %op4979 = sub i64 %v4977, %v4978
  store i64 %op4979, ptr %slot590, align 8
  %v4980 = load i64, ptr %slot589, align 8
  %cmp4981 = icmp ult i64 %v4980, 16
  %cv4982 = zext i1 %cmp4981 to i32
  store i32 %cv4982, ptr %slot591, align 8
  %v4983 = load i64, ptr %slot590, align 8
  %cmp4984 = icmp ult i64 %v4983, 16
  %cv4985 = zext i1 %cmp4984 to i32
  store i32 %cv4985, ptr %slot592, align 8
  %v4986 = load i32, ptr %slot591, align 8
  %v4987 = load i32, ptr %slot592, align 8
  %op4988 = or i32 %v4986, %v4987
  store i32 %op4988, ptr %slot593, align 8
  %v4989 = load i32, ptr %slot593, align 8
  %cv4990 = zext i32 %v4989 to i64
  %cond4991 = icmp ne i64 %cv4990, 0
  br i1 %cond4991, label %bb_rcmoveslow686, label %bb_rcmovecheck686
bb_rcmovecheck686:
  %v4992 = load i64, ptr %slot582, align 8
  %op4993 = add i64 %v4992, 0
  store i64 %op4993, ptr %slot594, align 8
  %v4994 = load i64, ptr %slot594, align 8
  %p4995 = inttoptr i64 %v4994 to ptr
  %ld4996 = load i64, ptr %p4995, align 8
  store i64 %ld4996, ptr %slot595, align 8
  %v4997 = load i64, ptr %slot595, align 8
  %cmp4998 = icmp ne i64 %v4997, 0
  %cv4999 = zext i1 %cmp4998 to i32
  store i32 %cv4999, ptr %slot596, align 8
  %v5000 = load i32, ptr %slot596, align 8
  %cv5001 = zext i32 %v5000 to i64
  %cond5002 = icmp ne i64 %cv5001, 0
  br i1 %cond5002, label %bb_rcmoveheader694, label %bb_rcmovenext694
bb_rcmoveheader694:
  %v5003 = load i64, ptr %slot595, align 8
  %op5004 = sub i64 %v5003, 16
  store i64 %op5004, ptr %slot597, align 8
  %v5005 = load i64, ptr %slot595, align 8
  %p5006 = inttoptr i64 %v5005 to ptr
  %rgep5007 = getelementptr i8, ptr %p5006, i64 -16
  %ld5008 = load i64, ptr %rgep5007, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5008, ptr %slot598, align 8
  %v5009 = load i64, ptr %slot598, align 8
  %op5010 = and i64 %v5009, 5764607523034234881
  store i64 %op5010, ptr %slot599, align 8
  %v5011 = load i64, ptr %slot599, align 8
  %cmp5012 = icmp ne i64 %v5011, 0
  %cv5013 = zext i1 %cmp5012 to i32
  store i32 %cv5013, ptr %slot600, align 8
  %v5014 = load i32, ptr %slot600, align 8
  %cv5015 = zext i32 %v5014 to i64
  %cond5016 = icmp ne i64 %cv5015, 0
  br i1 %cond5016, label %bb_rcmoveslow686, label %bb_rcmovenext694
bb_rcmovenext694:
  %v5017 = load i64, ptr %slot582, align 8
  %v5018 = load i64, ptr %slot587, align 8
  %p5019 = inttoptr i64 %v5017 to ptr
  %p5020 = inttoptr i64 %v5018 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5020, ptr %p5019, i64 16, i1 false)
  %v5021 = load i64, ptr %slot582, align 8
  %p5022 = inttoptr i64 %v5021 to ptr
  store i64 0, ptr %p5022, align 8
  %v5023 = load i64, ptr %slot582, align 8
  %op5024 = add i64 %v5023, 8
  store i64 %op5024, ptr %slot601, align 8
  %v5025 = load i64, ptr %slot601, align 8
  %p5026 = inttoptr i64 %v5025 to ptr
  store i64 0, ptr %p5026, align 8
  br label %bb_rcmoved686
bb_rcmoveslow686:
  %v5027 = load i64, ptr %slot96, align 8
  %v5028 = load i64, ptr %slot587, align 8
  %v5029 = load i64, ptr %slot582, align 8
  %v5030 = load i64, ptr %slot588, align 8
  %cv5031 = trunc i64 %v5030 to i32
  %call5032 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64 %v5027, i64 %v5028, i64 %v5029, i32 %cv5031) nomerge, !dbg !152
  store i32 %call5032, ptr %slot602, align 8
  %v5033 = load i32, ptr %slot602, align 8
  %cv5034 = zext i32 %v5033 to i64
  %cond5035 = icmp ne i64 %cv5034, 0
  br i1 %cond5035, label %bb_rcsuccess702, label %bb_rcfailure702
bb_rcfailure702:
  %v5036 = load i64, ptr %slot96, align 8
  %p5037 = inttoptr i64 %v5036 to ptr
  %call5038 = call i32 @myl_rc_take_failure(ptr %p5037) nomerge, !dbg !152
  store i32 %call5038, ptr %slot603, align 8
  %v5039 = load i64, ptr %slot1, align 8
  %p5040 = inttoptr i64 %v5039 to ptr
  %v5041 = load i32, ptr %slot603, align 8
  %call5042 = call i32 @myl_qbe_rc_status(ptr %p5040, i32 %v5041) nomerge, !dbg !152
  store i32 %call5042, ptr %slot604, align 8
  br label %bb_failure
bb_rcsuccess702:
  br label %bb_rcmoved686
bb_rcmoved686:
  %v5043 = load i64, ptr %slot28, align 8
  %p5044 = inttoptr i64 %v5043 to ptr
  store i32 0, ptr %p5044, align 4, !alias.scope !3, !noalias !4
  %v5045 = load i64, ptr %slot35, align 8
  %p5046 = inttoptr i64 %v5045 to ptr
  store i32 2, ptr %p5046, align 4, !alias.scope !3, !noalias !4
  %v5047 = load i64, ptr %slot34, align 8
  %p5048 = inttoptr i64 %v5047 to ptr
  store i32 1, ptr %p5048, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared677
bb_rccopy677:
  %v5049 = load i64, ptr %slot41, align 8
  store i64 %v5049, ptr %slot605, align 8
  %v5050 = load i64, ptr %slot97, align 8
  store i64 %v5050, ptr %slot606, align 8
  %v5051 = load i64, ptr %slot96, align 8
  %v5052 = load i64, ptr %slot605, align 8
  %v5053 = load i64, ptr %slot582, align 8
  %v5054 = load i64, ptr %slot606, align 8
  %cv5055 = trunc i64 %v5054 to i32
  %call5056 = call i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64 %v5051, i64 %v5052, i64 %v5053, i32 %cv5055) nomerge, !dbg !152
  store i32 %call5056, ptr %slot607, align 8
  %v5057 = load i32, ptr %slot607, align 8
  %cv5058 = zext i32 %v5057 to i64
  %cond5059 = icmp ne i64 %cv5058, 0
  br i1 %cond5059, label %bb_rcsuccess711, label %bb_rcfailure711
bb_rcfailure711:
  %v5060 = load i64, ptr %slot96, align 8
  %p5061 = inttoptr i64 %v5060 to ptr
  %call5062 = call i32 @myl_rc_take_failure(ptr %p5061) nomerge, !dbg !152
  store i32 %call5062, ptr %slot608, align 8
  %v5063 = load i64, ptr %slot1, align 8
  %p5064 = inttoptr i64 %v5063 to ptr
  %v5065 = load i32, ptr %slot608, align 8
  %call5066 = call i32 @myl_qbe_rc_status(ptr %p5064, i32 %v5065) nomerge, !dbg !152
  store i32 %call5066, ptr %slot609, align 8
  br label %bb_failure
bb_rcsuccess711:
  %v5067 = load i64, ptr %slot35, align 8
  %p5068 = inttoptr i64 %v5067 to ptr
  store i32 2, ptr %p5068, align 4, !alias.scope !3, !noalias !4
  %v5069 = load i64, ptr %slot34, align 8
  %p5070 = inttoptr i64 %v5069 to ptr
  store i32 1, ptr %p5070, align 4, !alias.scope !3, !noalias !4
  %v5071 = load i64, ptr %slot28, align 8
  %p5072 = inttoptr i64 %v5071 to ptr
  %ld5073 = load i32, ptr %p5072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5073, ptr %slot610, align 8
  %v5074 = load i32, ptr %slot610, align 8
  %cv5075 = zext i32 %v5074 to i64
  %cond5076 = icmp ne i64 %cv5075, 0
  br i1 %cond5076, label %bb_rcslotdrop718, label %bb_rcslotdone718
bb_rcslotdrop718:
  %v5077 = load i64, ptr %slot28, align 8
  %p5078 = inttoptr i64 %v5077 to ptr
  store i32 0, ptr %p5078, align 4, !alias.scope !3, !noalias !4
  %v5079 = load i64, ptr %slot37, align 8
  store i64 %v5079, ptr %slot611, align 8
  %v5080 = load i64, ptr %slot29, align 8
  %p5081 = inttoptr i64 %v5080 to ptr
  %ld5082 = load i32, ptr %p5081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5082, ptr %slot612, align 8
  %v5083 = load i32, ptr %slot612, align 8
  %op5084 = and i32 %v5083, 28
  store i32 %op5084, ptr %slot613, align 8
  %v5085 = load i32, ptr %slot613, align 8
  %cv5086 = zext i32 %v5085 to i64
  %cond5087 = icmp ne i64 %cv5086, 0
  br i1 %cond5087, label %bb_rcslotrole718, label %bb_rcslotowner718
bb_rcslotrole718:
  %v5088 = load i64, ptr %slot96, align 8
  store i64 %v5088, ptr %slot614, align 8
  %v5089 = load i64, ptr %slot614, align 8
  %v5090 = load i64, ptr %slot611, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5089, i64 %v5090) nomerge, !dbg !152
  br label %bb_rcslotdone718
bb_rcslotowner718:
  %v5091 = load i64, ptr %slot611, align 8
  %p5093 = inttoptr i64 %v5091 to ptr
  %gep5094 = getelementptr i8, ptr %p5093, i64 0
  %op5092 = ptrtoint ptr %gep5094 to i64
  store i64 %op5092, ptr %slot615, align 8
  %v5095 = load i64, ptr %slot96, align 8
  store i64 %v5095, ptr %slot616, align 8
  %v5096 = load i64, ptr %slot615, align 8
  %p5097 = inttoptr i64 %v5096 to ptr
  %ld5098 = load i64, ptr %p5097, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5098, ptr %slot617, align 8
  %v5099 = load i64, ptr %slot617, align 8
  %cmp5100 = icmp ne i64 %v5099, 0
  %cv5101 = zext i1 %cmp5100 to i32
  store i32 %cv5101, ptr %slot618, align 8
  %v5102 = load i32, ptr %slot618, align 8
  %cv5103 = zext i32 %v5102 to i64
  %cond5104 = icmp ne i64 %cv5103, 0
  br i1 %cond5104, label %bb_rcgnn736, label %bb_rcgdone736
bb_rcgnn736:
  %v5105 = load i64, ptr %slot617, align 8
  %op5106 = sub i64 %v5105, 16
  store i64 %op5106, ptr %slot619, align 8
  %v5107 = load i64, ptr %slot617, align 8
  %p5108 = inttoptr i64 %v5107 to ptr
  %rgep5109 = getelementptr i8, ptr %p5108, i64 -16
  %ld5110 = load i64, ptr %rgep5109, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5110, ptr %slot620, align 8
  %v5111 = load i64, ptr %slot620, align 8
  %op5112 = and i64 %v5111, 4611686018427387906
  store i64 %op5112, ptr %slot621, align 8
  %v5113 = load i64, ptr %slot621, align 8
  %cmp5114 = icmp ne i64 %v5113, 0
  %cv5115 = zext i1 %cmp5114 to i32
  store i32 %cv5115, ptr %slot622, align 8
  %v5116 = load i32, ptr %slot622, align 8
  %cv5117 = zext i32 %v5116 to i64
  %cond5118 = icmp ne i64 %cv5117, 0
  br i1 %cond5118, label %bb_rcgclear736, label %bb_rcgcounted736
bb_rcgcounted736:
  %v5119 = load i64, ptr %slot617, align 8
  %op5120 = sub i64 %v5119, 32
  store i64 %op5120, ptr %slot623, align 8
  %v5121 = load i64, ptr %slot617, align 8
  %p5122 = inttoptr i64 %v5121 to ptr
  %rgep5123 = getelementptr i8, ptr %p5122, i64 -32
  %ld5124 = load i64, ptr %rgep5123, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5124, ptr %slot624, align 8
  %v5125 = load i64, ptr %slot624, align 8
  %op5126 = sub i64 %v5125, 1
  store i64 %op5126, ptr %slot625, align 8
  %v5127 = load i64, ptr %slot625, align 8
  %cmp5128 = icmp eq i64 %v5127, 0
  %cv5129 = zext i1 %cmp5128 to i32
  store i32 %cv5129, ptr %slot626, align 8
  %v5130 = load i32, ptr %slot626, align 8
  %cv5131 = zext i32 %v5130 to i64
  %cond5132 = icmp ne i64 %cv5131, 0
  br i1 %cond5132, label %bb_rcglast736, label %bb_rcgdec736
bb_rcglast736:
  %v5133 = load i64, ptr %slot617, align 8
  %op5134 = sub i64 %v5133, 24
  store i64 %op5134, ptr %slot627, align 8
  %v5135 = load i64, ptr %slot617, align 8
  %p5136 = inttoptr i64 %v5135 to ptr
  %rgep5137 = getelementptr i8, ptr %p5136, i64 -24
  %ld5138 = load i64, ptr %rgep5137, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5138, ptr %slot628, align 8
  %v5139 = load i64, ptr %slot628, align 8
  %cmp5140 = icmp ne i64 %v5139, 0
  %cv5141 = zext i1 %cmp5140 to i32
  store i32 %cv5141, ptr %slot629, align 8
  %v5142 = load i32, ptr %slot629, align 8
  %cv5143 = zext i32 %v5142 to i64
  %cond5144 = icmp ne i64 %cv5143, 0
  br i1 %cond5144, label %bb_rcgdec736, label %bb_rcgslow736
bb_rcgslow736:
  %v5145 = load i64, ptr %slot616, align 8
  %v5146 = load i64, ptr %slot615, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5145, i64 %v5146) nomerge, !dbg !152
  br label %bb_rcgdone736
bb_rcgdec736:
  %v5147 = load i64, ptr %slot625, align 8
  %v5148 = load i64, ptr %slot617, align 8
  %p5149 = inttoptr i64 %v5148 to ptr
  %rgep5150 = getelementptr i8, ptr %p5149, i64 -32
  store i64 %v5147, ptr %rgep5150, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear736
bb_rcgclear736:
  %v5151 = load i64, ptr %slot615, align 8
  %p5152 = inttoptr i64 %v5151 to ptr
  store i64 0, ptr %p5152, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone736
bb_rcgdone736:
  %v5153 = load i64, ptr %slot611, align 8
  %p5154 = inttoptr i64 %v5153 to ptr
  store i64 0, ptr %p5154, align 8, !alias.scope !3, !noalias !4
  %v5155 = load i64, ptr %slot611, align 8
  %p5157 = inttoptr i64 %v5155 to ptr
  %gep5158 = getelementptr i8, ptr %p5157, i64 8
  %op5156 = ptrtoint ptr %gep5158 to i64
  store i64 %op5156, ptr %slot630, align 8
  %v5159 = load i64, ptr %slot630, align 8
  %p5160 = inttoptr i64 %v5159 to ptr
  store i64 0, ptr %p5160, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone718
bb_rcslotdone718:
  br label %bb_rcprepared677
bb_rcprepared677:
  %v5161 = load i64, ptr %slot10, align 8
  %p5162 = inttoptr i64 %v5161 to ptr
  %ld5163 = load i32, ptr %p5162, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5163, ptr %slot631, align 8
  %v5164 = load i32, ptr %slot631, align 8
  %cv5165 = zext i32 %v5164 to i64
  %cond5166 = icmp ne i64 %cv5165, 0
  br i1 %cond5166, label %bb_rcslotdrop744, label %bb_rcslotdone744
bb_rcslotdrop744:
  %v5167 = load i64, ptr %slot10, align 8
  %p5168 = inttoptr i64 %v5167 to ptr
  store i32 0, ptr %p5168, align 4, !alias.scope !3, !noalias !4
  %v5169 = load i64, ptr %slot56, align 8
  store i64 %v5169, ptr %slot632, align 8
  %v5170 = load i64, ptr %slot11, align 8
  %p5171 = inttoptr i64 %v5170 to ptr
  %ld5172 = load i32, ptr %p5171, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5172, ptr %slot633, align 8
  %v5173 = load i32, ptr %slot633, align 8
  %op5174 = and i32 %v5173, 28
  store i32 %op5174, ptr %slot634, align 8
  %v5175 = load i32, ptr %slot634, align 8
  %cv5176 = zext i32 %v5175 to i64
  %cond5177 = icmp ne i64 %cv5176, 0
  br i1 %cond5177, label %bb_rcslotrole744, label %bb_rcslotowner744
bb_rcslotrole744:
  %v5178 = load i64, ptr %slot96, align 8
  store i64 %v5178, ptr %slot635, align 8
  %v5179 = load i64, ptr %slot635, align 8
  %v5180 = load i64, ptr %slot632, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5179, i64 %v5180) nomerge, !dbg !152
  br label %bb_rcslotdone744
bb_rcslotowner744:
  %v5181 = load i64, ptr %slot632, align 8
  %p5183 = inttoptr i64 %v5181 to ptr
  %gep5184 = getelementptr i8, ptr %p5183, i64 0
  %op5182 = ptrtoint ptr %gep5184 to i64
  store i64 %op5182, ptr %slot636, align 8
  %v5185 = load i64, ptr %slot96, align 8
  store i64 %v5185, ptr %slot637, align 8
  %v5186 = load i64, ptr %slot636, align 8
  %p5187 = inttoptr i64 %v5186 to ptr
  %ld5188 = load i64, ptr %p5187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5188, ptr %slot638, align 8
  %v5189 = load i64, ptr %slot638, align 8
  %cmp5190 = icmp ne i64 %v5189, 0
  %cv5191 = zext i1 %cmp5190 to i32
  store i32 %cv5191, ptr %slot639, align 8
  %v5192 = load i32, ptr %slot639, align 8
  %cv5193 = zext i32 %v5192 to i64
  %cond5194 = icmp ne i64 %cv5193, 0
  br i1 %cond5194, label %bb_rcgnn762, label %bb_rcgdone762
bb_rcgnn762:
  %v5195 = load i64, ptr %slot638, align 8
  %op5196 = sub i64 %v5195, 16
  store i64 %op5196, ptr %slot640, align 8
  %v5197 = load i64, ptr %slot638, align 8
  %p5198 = inttoptr i64 %v5197 to ptr
  %rgep5199 = getelementptr i8, ptr %p5198, i64 -16
  %ld5200 = load i64, ptr %rgep5199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5200, ptr %slot641, align 8
  %v5201 = load i64, ptr %slot641, align 8
  %op5202 = and i64 %v5201, 4611686018427387906
  store i64 %op5202, ptr %slot642, align 8
  %v5203 = load i64, ptr %slot642, align 8
  %cmp5204 = icmp ne i64 %v5203, 0
  %cv5205 = zext i1 %cmp5204 to i32
  store i32 %cv5205, ptr %slot643, align 8
  %v5206 = load i32, ptr %slot643, align 8
  %cv5207 = zext i32 %v5206 to i64
  %cond5208 = icmp ne i64 %cv5207, 0
  br i1 %cond5208, label %bb_rcgclear762, label %bb_rcgcounted762
bb_rcgcounted762:
  %v5209 = load i64, ptr %slot638, align 8
  %op5210 = sub i64 %v5209, 32
  store i64 %op5210, ptr %slot644, align 8
  %v5211 = load i64, ptr %slot638, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  %rgep5213 = getelementptr i8, ptr %p5212, i64 -32
  %ld5214 = load i64, ptr %rgep5213, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5214, ptr %slot645, align 8
  %v5215 = load i64, ptr %slot645, align 8
  %op5216 = sub i64 %v5215, 1
  store i64 %op5216, ptr %slot646, align 8
  %v5217 = load i64, ptr %slot646, align 8
  %cmp5218 = icmp eq i64 %v5217, 0
  %cv5219 = zext i1 %cmp5218 to i32
  store i32 %cv5219, ptr %slot647, align 8
  %v5220 = load i32, ptr %slot647, align 8
  %cv5221 = zext i32 %v5220 to i64
  %cond5222 = icmp ne i64 %cv5221, 0
  br i1 %cond5222, label %bb_rcglast762, label %bb_rcgdec762
bb_rcglast762:
  %v5223 = load i64, ptr %slot638, align 8
  %op5224 = sub i64 %v5223, 24
  store i64 %op5224, ptr %slot648, align 8
  %v5225 = load i64, ptr %slot638, align 8
  %p5226 = inttoptr i64 %v5225 to ptr
  %rgep5227 = getelementptr i8, ptr %p5226, i64 -24
  %ld5228 = load i64, ptr %rgep5227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5228, ptr %slot649, align 8
  %v5229 = load i64, ptr %slot649, align 8
  %cmp5230 = icmp ne i64 %v5229, 0
  %cv5231 = zext i1 %cmp5230 to i32
  store i32 %cv5231, ptr %slot650, align 8
  %v5232 = load i32, ptr %slot650, align 8
  %cv5233 = zext i32 %v5232 to i64
  %cond5234 = icmp ne i64 %cv5233, 0
  br i1 %cond5234, label %bb_rcgdec762, label %bb_rcgslow762
bb_rcgslow762:
  %v5235 = load i64, ptr %slot637, align 8
  %v5236 = load i64, ptr %slot636, align 8
  call void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64 %v5235, i64 %v5236) nomerge, !dbg !152
  br label %bb_rcgdone762
bb_rcgdec762:
  %v5237 = load i64, ptr %slot646, align 8
  %v5238 = load i64, ptr %slot638, align 8
  %p5239 = inttoptr i64 %v5238 to ptr
  %rgep5240 = getelementptr i8, ptr %p5239, i64 -32
  store i64 %v5237, ptr %rgep5240, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear762
bb_rcgclear762:
  %v5241 = load i64, ptr %slot636, align 8
  %p5242 = inttoptr i64 %v5241 to ptr
  store i64 0, ptr %p5242, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone762
bb_rcgdone762:
  %v5243 = load i64, ptr %slot632, align 8
  %p5244 = inttoptr i64 %v5243 to ptr
  store i64 0, ptr %p5244, align 8, !alias.scope !3, !noalias !4
  %v5245 = load i64, ptr %slot632, align 8
  %p5247 = inttoptr i64 %v5245 to ptr
  %gep5248 = getelementptr i8, ptr %p5247, i64 8
  %op5246 = ptrtoint ptr %gep5248 to i64
  store i64 %op5246, ptr %slot651, align 8
  %v5249 = load i64, ptr %slot651, align 8
  %p5250 = inttoptr i64 %v5249 to ptr
  store i64 0, ptr %p5250, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcslotdone744
bb_rcslotdone744:
  %v5251 = load i64, ptr %slot56, align 8
  store i64 %v5251, ptr %slot652, align 8
  %v5252 = load i64, ptr %slot41, align 8
  store i64 %v5252, ptr %slot653, align 8
  %v5253 = load i64, ptr %slot653, align 8
  %v5254 = load i64, ptr %slot652, align 8
  %p5255 = inttoptr i64 %v5253 to ptr
  %p5256 = inttoptr i64 %v5254 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5256, ptr %p5255, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5257 = load i64, ptr %slot34, align 8
  %p5258 = inttoptr i64 %v5257 to ptr
  store i32 0, ptr %p5258, align 4, !alias.scope !3, !noalias !4
  %v5259 = load i64, ptr %slot11, align 8
  %p5260 = inttoptr i64 %v5259 to ptr
  store i32 2, ptr %p5260, align 4, !alias.scope !3, !noalias !4
  %v5261 = load i64, ptr %slot35, align 8
  %p5262 = inttoptr i64 %v5261 to ptr
  %ld5263 = load i32, ptr %p5262, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5263, ptr %slot654, align 8
  %v5264 = load i32, ptr %slot654, align 8
  %v5265 = load i64, ptr %slot11, align 8
  %p5266 = inttoptr i64 %v5265 to ptr
  store i32 %v5264, ptr %p5266, align 4, !alias.scope !3, !noalias !4
  %v5267 = load i64, ptr %slot10, align 8
  %p5268 = inttoptr i64 %v5267 to ptr
  store i32 1, ptr %p5268, align 4, !alias.scope !3, !noalias !4
  %v5269 = load i64, ptr %slot56, align 8
  %v5270 = load i64, ptr %slot69, align 8
  %p5271 = inttoptr i64 %v5270 to ptr
  store i64 %v5269, ptr %p5271, align 8, !alias.scope !3, !noalias !4
  %v5272 = load i64, ptr %slot46, align 8
  %p5273 = inttoptr i64 %v5272 to ptr
  %ld5274 = load i64, ptr %p5273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5274, ptr %slot655, align 8
  %v5275 = load i64, ptr %slot655, align 8
  %v5276 = load i64, ptr %slot70, align 8
  %p5277 = inttoptr i64 %v5276 to ptr
  store i64 %v5275, ptr %p5277, align 8, !alias.scope !3, !noalias !4
  %v5278 = load i64, ptr %slot70, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  %ld5280 = load i64, ptr %p5279, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5280, ptr %slot656, align 8
  %v5281 = load i64, ptr %slot656, align 8
  %op5282 = add i64 %v5281, 32
  store i64 %op5282, ptr %slot657, align 8
  %v5283 = load i64, ptr %slot657, align 8
  %v5284 = load i64, ptr %slot70, align 8
  %p5285 = inttoptr i64 %v5284 to ptr
  store i64 %v5283, ptr %p5285, align 8, !alias.scope !3, !noalias !4
  %v5286 = load i64, ptr %slot30, align 8
  %p5287 = inttoptr i64 %v5286 to ptr
  %ld5288 = load i32, ptr %p5287, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5288, ptr %slot658, align 8
  %v5289 = load i32, ptr %slot658, align 8
  %cv5290 = zext i32 %v5289 to i64
  %cond5291 = icmp ne i64 %cv5290, 0
  br i1 %cond5291, label %bb_rcslotdrop779, label %bb_rcslotdone779
bb_rcslotdrop779:
  %v5292 = load i64, ptr %slot30, align 8
  %p5293 = inttoptr i64 %v5292 to ptr
  store i32 0, ptr %p5293, align 4, !alias.scope !3, !noalias !4
  %v5294 = load i64, ptr %slot38, align 8
  store i64 %v5294, ptr %slot659, align 8
  %v5295 = load i64, ptr %slot31, align 8
  %p5296 = inttoptr i64 %v5295 to ptr
  %ld5297 = load i32, ptr %p5296, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5297, ptr %slot660, align 8
  %v5298 = load i32, ptr %slot660, align 8
  %op5299 = and i32 %v5298, 28
  store i32 %op5299, ptr %slot661, align 8
  %v5300 = load i32, ptr %slot661, align 8
  %cv5301 = zext i32 %v5300 to i64
  %cond5302 = icmp ne i64 %cv5301, 0
  br i1 %cond5302, label %bb_rcslotrole779, label %bb_rcslotowner779
bb_rcslotrole779:
  %v5303 = load i64, ptr %slot96, align 8
  store i64 %v5303, ptr %slot662, align 8
  %v5304 = load i64, ptr %slot662, align 8
  %v5305 = load i64, ptr %slot659, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v5304, i64 %v5305) nomerge, !dbg !154
  br label %bb_rcslotdone779
bb_rcslotowner779:
  %v5306 = load i64, ptr %slot96, align 8
  store i64 %v5306, ptr %slot663, align 8
  %v5307 = load i64, ptr %slot663, align 8
  %v5308 = load i64, ptr %slot659, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v5307, i64 %v5308) nomerge, !dbg !154
  br label %bb_rcslotdone779
bb_rcslotdone779:
  %v5309 = load i64, ptr %slot70, align 8
  %p5310 = inttoptr i64 %v5309 to ptr
  %ld5311 = load i64, ptr %p5310, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5311, ptr %slot664, align 8
  %v5312 = load i64, ptr %slot664, align 8
  %op5313 = add i64 %v5312, 64
  store i64 %op5313, ptr %slot665, align 8
  %v5314 = load i64, ptr %slot665, align 8
  %p5315 = inttoptr i64 %v5314 to ptr
  %ld5316 = load i64, ptr %p5315, align 8
  store i64 %ld5316, ptr %slot666, align 8
  %v5317 = load i64, ptr %slot666, align 8
  %v5318 = load i64, ptr %slot70, align 8
  %p5319 = inttoptr i64 %v5318 to ptr
  store i64 %v5317, ptr %p5319, align 8, !alias.scope !3, !noalias !4
  %v5320 = load i64, ptr %slot30, align 8
  %p5321 = inttoptr i64 %v5320 to ptr
  %ld5322 = load i32, ptr %p5321, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5322, ptr %slot667, align 8
  %v5323 = load i32, ptr %slot667, align 8
  %cv5324 = zext i32 %v5323 to i64
  %cond5325 = icmp ne i64 %cv5324, 0
  br i1 %cond5325, label %bb_rcslotdrop791, label %bb_rcslotdone791
bb_rcslotdrop791:
  %v5326 = load i64, ptr %slot30, align 8
  %p5327 = inttoptr i64 %v5326 to ptr
  store i32 0, ptr %p5327, align 4, !alias.scope !3, !noalias !4
  %v5328 = load i64, ptr %slot38, align 8
  store i64 %v5328, ptr %slot668, align 8
  %v5329 = load i64, ptr %slot31, align 8
  %p5330 = inttoptr i64 %v5329 to ptr
  %ld5331 = load i32, ptr %p5330, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5331, ptr %slot669, align 8
  %v5332 = load i32, ptr %slot669, align 8
  %op5333 = and i32 %v5332, 28
  store i32 %op5333, ptr %slot670, align 8
  %v5334 = load i32, ptr %slot670, align 8
  %cv5335 = zext i32 %v5334 to i64
  %cond5336 = icmp ne i64 %cv5335, 0
  br i1 %cond5336, label %bb_rcslotrole791, label %bb_rcslotowner791
bb_rcslotrole791:
  %v5337 = load i64, ptr %slot96, align 8
  store i64 %v5337, ptr %slot671, align 8
  %v5338 = load i64, ptr %slot671, align 8
  %v5339 = load i64, ptr %slot668, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5338, i64 %v5339) nomerge, !dbg !156
  br label %bb_rcslotdone791
bb_rcslotowner791:
  %v5340 = load i64, ptr %slot96, align 8
  store i64 %v5340, ptr %slot672, align 8
  %v5341 = load i64, ptr %slot672, align 8
  %v5342 = load i64, ptr %slot668, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5341, i64 %v5342) nomerge, !dbg !156
  br label %bb_rcslotdone791
bb_rcslotdone791:
  %v5343 = load i64, ptr %slot46, align 8
  %p5344 = inttoptr i64 %v5343 to ptr
  %ld5345 = load i64, ptr %p5344, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5345, ptr %slot673, align 8
  %v5346 = load i64, ptr %slot673, align 8
  %v5347 = load i64, ptr %slot71, align 8
  %p5348 = inttoptr i64 %v5347 to ptr
  store i64 %v5346, ptr %p5348, align 8, !alias.scope !3, !noalias !4
  %v5349 = load i64, ptr %slot71, align 8
  %p5350 = inttoptr i64 %v5349 to ptr
  %ld5351 = load i64, ptr %p5350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5351, ptr %slot674, align 8
  %v5352 = load i64, ptr %slot674, align 8
  %op5353 = add i64 %v5352, 32
  store i64 %op5353, ptr %slot675, align 8
  %v5354 = load i64, ptr %slot675, align 8
  %v5355 = load i64, ptr %slot71, align 8
  %p5356 = inttoptr i64 %v5355 to ptr
  store i64 %v5354, ptr %p5356, align 8, !alias.scope !3, !noalias !4
  %v5357 = load i64, ptr %slot32, align 8
  %p5358 = inttoptr i64 %v5357 to ptr
  %ld5359 = load i32, ptr %p5358, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5359, ptr %slot676, align 8
  %v5360 = load i32, ptr %slot676, align 8
  %cv5361 = zext i32 %v5360 to i64
  %cond5362 = icmp ne i64 %cv5361, 0
  br i1 %cond5362, label %bb_rcslotdrop803, label %bb_rcslotdone803
bb_rcslotdrop803:
  %v5363 = load i64, ptr %slot32, align 8
  %p5364 = inttoptr i64 %v5363 to ptr
  store i32 0, ptr %p5364, align 4, !alias.scope !3, !noalias !4
  %v5365 = load i64, ptr %slot39, align 8
  store i64 %v5365, ptr %slot677, align 8
  %v5366 = load i64, ptr %slot33, align 8
  %p5367 = inttoptr i64 %v5366 to ptr
  %ld5368 = load i32, ptr %p5367, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5368, ptr %slot678, align 8
  %v5369 = load i32, ptr %slot678, align 8
  %op5370 = and i32 %v5369, 28
  store i32 %op5370, ptr %slot679, align 8
  %v5371 = load i32, ptr %slot679, align 8
  %cv5372 = zext i32 %v5371 to i64
  %cond5373 = icmp ne i64 %cv5372, 0
  br i1 %cond5373, label %bb_rcslotrole803, label %bb_rcslotowner803
bb_rcslotrole803:
  %v5374 = load i64, ptr %slot96, align 8
  store i64 %v5374, ptr %slot680, align 8
  %v5375 = load i64, ptr %slot680, align 8
  %v5376 = load i64, ptr %slot677, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v5375, i64 %v5376) nomerge, !dbg !158
  br label %bb_rcslotdone803
bb_rcslotowner803:
  %v5377 = load i64, ptr %slot96, align 8
  store i64 %v5377, ptr %slot681, align 8
  %v5378 = load i64, ptr %slot681, align 8
  %v5379 = load i64, ptr %slot677, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v5378, i64 %v5379) nomerge, !dbg !158
  br label %bb_rcslotdone803
bb_rcslotdone803:
  %v5380 = load i64, ptr %slot46, align 8
  %p5381 = inttoptr i64 %v5380 to ptr
  %ld5382 = load i64, ptr %p5381, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5382, ptr %slot682, align 8
  %v5383 = load i64, ptr %slot682, align 8
  %v5384 = load i64, ptr %slot72, align 8
  %p5385 = inttoptr i64 %v5384 to ptr
  store i64 %v5383, ptr %p5385, align 8, !alias.scope !3, !noalias !4
  %v5386 = load i64, ptr %slot72, align 8
  %p5387 = inttoptr i64 %v5386 to ptr
  %ld5388 = load i64, ptr %p5387, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5388, ptr %slot683, align 8
  %v5389 = load i64, ptr %slot683, align 8
  %op5390 = add i64 %v5389, 32
  store i64 %op5390, ptr %slot684, align 8
  %v5391 = load i64, ptr %slot684, align 8
  %v5392 = load i64, ptr %slot72, align 8
  %p5393 = inttoptr i64 %v5392 to ptr
  store i64 %v5391, ptr %p5393, align 8, !alias.scope !3, !noalias !4
  %v5394 = load i64, ptr %slot72, align 8
  %p5395 = inttoptr i64 %v5394 to ptr
  %ld5396 = load i64, ptr %p5395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5396, ptr %slot685, align 8
  %v5397 = load i64, ptr %slot685, align 8
  %op5398 = add i64 %v5397, 64
  store i64 %op5398, ptr %slot686, align 8
  %v5399 = load i64, ptr %slot686, align 8
  %p5400 = inttoptr i64 %v5399 to ptr
  %ld5401 = load i64, ptr %p5400, align 8
  store i64 %ld5401, ptr %slot687, align 8
  %v5402 = load i64, ptr %slot687, align 8
  %v5403 = load i64, ptr %slot72, align 8
  %p5404 = inttoptr i64 %v5403 to ptr
  store i64 %v5402, ptr %p5404, align 8, !alias.scope !3, !noalias !4
  %v5405 = load i64, ptr %slot71, align 8
  %p5406 = inttoptr i64 %v5405 to ptr
  %ld5407 = load i64, ptr %p5406, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5407, ptr %slot688, align 8
  %v5408 = load i64, ptr %slot72, align 8
  %p5409 = inttoptr i64 %v5408 to ptr
  %ld5410 = load i64, ptr %p5409, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5410, ptr %slot689, align 8
  %v5411 = load i64, ptr %slot1, align 8
  %v5412 = load i64, ptr %slot688, align 8
  %v5413 = load i64, ptr %slot689, align 8
  %call5414 = call i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64 %v5411, i64 %v5412, i64 %v5413) nomerge, !dbg !160
  store i64 %call5414, ptr %slot690, align 8
  %v5415 = load i64, ptr %slot690, align 8
  %v5416 = load i64, ptr %slot71, align 8
  %p5417 = inttoptr i64 %v5416 to ptr
  store i64 %v5415, ptr %p5417, align 8, !alias.scope !3, !noalias !4
  %v5418 = load i64, ptr %slot32, align 8
  %p5419 = inttoptr i64 %v5418 to ptr
  %ld5420 = load i32, ptr %p5419, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5420, ptr %slot691, align 8
  %v5421 = load i32, ptr %slot691, align 8
  %cv5422 = zext i32 %v5421 to i64
  %cond5423 = icmp ne i64 %cv5422, 0
  br i1 %cond5423, label %bb_rcslotdrop839, label %bb_rcslotdone839
bb_rcslotdrop839:
  %v5424 = load i64, ptr %slot32, align 8
  %p5425 = inttoptr i64 %v5424 to ptr
  store i32 0, ptr %p5425, align 4, !alias.scope !3, !noalias !4
  %v5426 = load i64, ptr %slot39, align 8
  store i64 %v5426, ptr %slot692, align 8
  %v5427 = load i64, ptr %slot33, align 8
  %p5428 = inttoptr i64 %v5427 to ptr
  %ld5429 = load i32, ptr %p5428, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5429, ptr %slot693, align 8
  %v5430 = load i32, ptr %slot693, align 8
  %op5431 = and i32 %v5430, 28
  store i32 %op5431, ptr %slot694, align 8
  %v5432 = load i32, ptr %slot694, align 8
  %cv5433 = zext i32 %v5432 to i64
  %cond5434 = icmp ne i64 %cv5433, 0
  br i1 %cond5434, label %bb_rcslotrole839, label %bb_rcslotowner839
bb_rcslotrole839:
  %v5435 = load i64, ptr %slot96, align 8
  store i64 %v5435, ptr %slot695, align 8
  %v5436 = load i64, ptr %slot695, align 8
  %v5437 = load i64, ptr %slot692, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5436, i64 %v5437) nomerge, !dbg !160
  br label %bb_rcslotdone839
bb_rcslotowner839:
  %v5438 = load i64, ptr %slot96, align 8
  store i64 %v5438, ptr %slot696, align 8
  %v5439 = load i64, ptr %slot696, align 8
  %v5440 = load i64, ptr %slot692, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5439, i64 %v5440) nomerge, !dbg !160
  br label %bb_rcslotdone839
bb_rcslotdone839:
  %v5441 = load i64, ptr %slot69, align 8
  %p5442 = inttoptr i64 %v5441 to ptr
  %ld5443 = load i64, ptr %p5442, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5443, ptr %slot697, align 8
  %v5444 = load i64, ptr %slot70, align 8
  %p5445 = inttoptr i64 %v5444 to ptr
  %ld5446 = load i64, ptr %p5445, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5446, ptr %slot698, align 8
  %v5447 = load i64, ptr %slot71, align 8
  %p5448 = inttoptr i64 %v5447 to ptr
  %ld5449 = load i64, ptr %p5448, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5449, ptr %slot699, align 8
  %v5450 = load i64, ptr %slot1, align 8
  %v5451 = load i64, ptr %slot697, align 8
  %v5452 = load i64, ptr %slot698, align 8
  %v5453 = load i64, ptr %slot699, align 8
  call void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8 %callresult701, i64 %v5450, i64 %v5451, i64 %v5452, i64 %v5453) nomerge, !dbg !162
  %addr5454 = ptrtoint ptr %callresult701 to i64
  store i64 %addr5454, ptr %slot700, align 8
  %v5455 = load i64, ptr %slot700, align 8
  %v5456 = load i64, ptr %slot69, align 8
  %p5457 = inttoptr i64 %v5456 to ptr
  store i64 %v5455, ptr %p5457, align 8, !alias.scope !3, !noalias !4
  %v5458 = load i64, ptr %slot28, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  %ld5460 = load i32, ptr %p5459, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5460, ptr %slot702, align 8
  %v5461 = load i32, ptr %slot702, align 8
  %cv5462 = zext i32 %v5461 to i64
  %cond5463 = icmp ne i64 %cv5462, 0
  br i1 %cond5463, label %bb_rcslotdrop852, label %bb_rcslotdone852
bb_rcslotdrop852:
  %v5464 = load i64, ptr %slot28, align 8
  %p5465 = inttoptr i64 %v5464 to ptr
  store i32 0, ptr %p5465, align 4, !alias.scope !3, !noalias !4
  %v5466 = load i64, ptr %slot37, align 8
  store i64 %v5466, ptr %slot703, align 8
  %v5467 = load i64, ptr %slot29, align 8
  %p5468 = inttoptr i64 %v5467 to ptr
  %ld5469 = load i32, ptr %p5468, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5469, ptr %slot704, align 8
  %v5470 = load i32, ptr %slot704, align 8
  %op5471 = and i32 %v5470, 28
  store i32 %op5471, ptr %slot705, align 8
  %v5472 = load i32, ptr %slot705, align 8
  %cv5473 = zext i32 %v5472 to i64
  %cond5474 = icmp ne i64 %cv5473, 0
  br i1 %cond5474, label %bb_rcslotrole852, label %bb_rcslotowner852
bb_rcslotrole852:
  %v5475 = load i64, ptr %slot96, align 8
  store i64 %v5475, ptr %slot706, align 8
  %v5476 = load i64, ptr %slot706, align 8
  %v5477 = load i64, ptr %slot703, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v5476, i64 %v5477) nomerge, !dbg !162
  br label %bb_rcslotdone852
bb_rcslotowner852:
  %v5478 = load i64, ptr %slot96, align 8
  store i64 %v5478, ptr %slot707, align 8
  %v5479 = load i64, ptr %slot707, align 8
  %v5480 = load i64, ptr %slot703, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v5479, i64 %v5480) nomerge, !dbg !162
  br label %bb_rcslotdone852
bb_rcslotdone852:
  %v5481 = load i64, ptr %slot69, align 8
  %p5482 = inttoptr i64 %v5481 to ptr
  %ld5483 = load i64, ptr %p5482, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5483, ptr %slot708, align 8
  %v5484 = load i64, ptr %slot708, align 8
  %p5485 = inttoptr i64 %v5484 to ptr
  %ld5486 = load i32, ptr %p5485, align 4
  %ext5487 = zext i32 %ld5486 to i64
  store i64 %ext5487, ptr %slot709, align 8
  %v5488 = load i64, ptr %slot709, align 8
  %cmp5489 = icmp eq i64 %v5488, 0
  %cv5490 = zext i1 %cmp5489 to i64
  store i64 %cv5490, ptr %slot710, align 8
  %v5491 = load i64, ptr %slot710, align 8
  %cond5492 = icmp ne i64 %v5491, 0
  br i1 %cond5492, label %bb_rcarm861, label %bb_rcarmnext861
bb_rcarm861:
  br label %bb_i189
bb_rcarmnext861:
  %v5493 = load i64, ptr %slot709, align 8
  %cmp5494 = icmp eq i64 %v5493, 1
  %cv5495 = zext i1 %cmp5494 to i64
  store i64 %cv5495, ptr %slot711, align 8
  %v5496 = load i64, ptr %slot711, align 8
  %cond5497 = icmp ne i64 %v5496, 0
  br i1 %cond5497, label %bb_rcarm862, label %bb_rcarmnext862
bb_rcarm862:
  %v5498 = load i64, ptr %slot41, align 8
  store i64 %v5498, ptr %slot712, align 8
  %v5499 = load i64, ptr %slot708, align 8
  %op5500 = add i64 %v5499, 8
  store i64 %op5500, ptr %slot713, align 8
  %v5501 = load i64, ptr %slot97, align 8
  store i64 %v5501, ptr %slot714, align 8
  %v5502 = load i64, ptr %slot713, align 8
  %v5503 = load i64, ptr %slot712, align 8
  %p5504 = inttoptr i64 %v5502 to ptr
  %p5505 = inttoptr i64 %v5503 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5505, ptr %p5504, i64 16, i1 false)
  %v5506 = load i64, ptr %slot35, align 8
  %p5507 = inttoptr i64 %v5506 to ptr
  store i32 0, ptr %p5507, align 4, !alias.scope !3, !noalias !4
  %v5508 = load i64, ptr %slot34, align 8
  %p5509 = inttoptr i64 %v5508 to ptr
  store i32 1, ptr %p5509, align 4, !alias.scope !3, !noalias !4
  %v5510 = load i64, ptr %slot712, align 8
  %v5511 = load i64, ptr %slot57, align 8
  %p5512 = inttoptr i64 %v5510 to ptr
  %p5513 = inttoptr i64 %v5511 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5513, ptr %p5512, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v5514 = load i64, ptr %slot34, align 8
  %p5515 = inttoptr i64 %v5514 to ptr
  store i32 0, ptr %p5515, align 4, !alias.scope !3, !noalias !4
  br label %bb_i72
bb_rcarmnext862:
  br label %bb_failure
bb_i72:
  %v5516 = load i64, ptr %slot46, align 8
  %p5517 = inttoptr i64 %v5516 to ptr
  %ld5518 = load i64, ptr %p5517, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5518, ptr %slot715, align 8
  %v5519 = load i64, ptr %slot715, align 8
  %v5520 = load i64, ptr %slot69, align 8
  %p5521 = inttoptr i64 %v5520 to ptr
  store i64 %v5519, ptr %p5521, align 8, !alias.scope !3, !noalias !4
  %v5522 = load i64, ptr %slot69, align 8
  %p5523 = inttoptr i64 %v5522 to ptr
  %ld5524 = load i64, ptr %p5523, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5524, ptr %slot716, align 8
  %v5525 = load i64, ptr %slot716, align 8
  %op5526 = add i64 %v5525, 32
  store i64 %op5526, ptr %slot717, align 8
  %v5527 = load i64, ptr %slot717, align 8
  %v5528 = load i64, ptr %slot69, align 8
  %p5529 = inttoptr i64 %v5528 to ptr
  store i64 %v5527, ptr %p5529, align 8, !alias.scope !3, !noalias !4
  %v5530 = load i64, ptr %slot28, align 8
  %p5531 = inttoptr i64 %v5530 to ptr
  %ld5532 = load i32, ptr %p5531, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5532, ptr %slot718, align 8
  %v5533 = load i32, ptr %slot718, align 8
  %cv5534 = zext i32 %v5533 to i64
  %cond5535 = icmp ne i64 %cv5534, 0
  br i1 %cond5535, label %bb_rcslotdrop874, label %bb_rcslotdone874
bb_rcslotdrop874:
  %v5536 = load i64, ptr %slot28, align 8
  %p5537 = inttoptr i64 %v5536 to ptr
  store i32 0, ptr %p5537, align 4, !alias.scope !3, !noalias !4
  %v5538 = load i64, ptr %slot37, align 8
  store i64 %v5538, ptr %slot719, align 8
  %v5539 = load i64, ptr %slot29, align 8
  %p5540 = inttoptr i64 %v5539 to ptr
  %ld5541 = load i32, ptr %p5540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5541, ptr %slot720, align 8
  %v5542 = load i32, ptr %slot720, align 8
  %op5543 = and i32 %v5542, 28
  store i32 %op5543, ptr %slot721, align 8
  %v5544 = load i32, ptr %slot721, align 8
  %cv5545 = zext i32 %v5544 to i64
  %cond5546 = icmp ne i64 %cv5545, 0
  br i1 %cond5546, label %bb_rcslotrole874, label %bb_rcslotowner874
bb_rcslotrole874:
  %v5547 = load i64, ptr %slot96, align 8
  store i64 %v5547, ptr %slot722, align 8
  %v5548 = load i64, ptr %slot722, align 8
  %v5549 = load i64, ptr %slot719, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v5548, i64 %v5549) nomerge, !dbg !164
  br label %bb_rcslotdone874
bb_rcslotowner874:
  %v5550 = load i64, ptr %slot96, align 8
  store i64 %v5550, ptr %slot723, align 8
  %v5551 = load i64, ptr %slot723, align 8
  %v5552 = load i64, ptr %slot719, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v5551, i64 %v5552) nomerge, !dbg !164
  br label %bb_rcslotdone874
bb_rcslotdone874:
  %v5553 = load i64, ptr %slot57, align 8
  %v5554 = load i64, ptr %slot70, align 8
  %p5555 = inttoptr i64 %v5554 to ptr
  store i64 %v5553, ptr %p5555, align 8, !alias.scope !3, !noalias !4
  %v5556 = load i64, ptr %slot70, align 8
  %p5557 = inttoptr i64 %v5556 to ptr
  %ld5558 = load i64, ptr %p5557, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5558, ptr %slot724, align 8
  %v5559 = load i64, ptr %slot1, align 8
  %v5560 = load i64, ptr %slot724, align 8
  %call5561 = call i64 @myl_f_ea97dd36e4e0ea42e46ce6a891c9a00cafb686a8c9a27c77fe327a84d70301d7(i64 %v5559, i64 %v5560) nomerge, !dbg !166
  store i64 %call5561, ptr %slot725, align 8
  %v5562 = load i64, ptr %slot725, align 8
  %v5563 = load i64, ptr %slot70, align 8
  %p5564 = inttoptr i64 %v5563 to ptr
  store i64 %v5562, ptr %p5564, align 8, !alias.scope !3, !noalias !4
  %v5565 = load i64, ptr %slot69, align 8
  %p5566 = inttoptr i64 %v5565 to ptr
  %ld5567 = load i64, ptr %p5566, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5567, ptr %slot726, align 8
  %v5568 = load i64, ptr %slot70, align 8
  %p5569 = inttoptr i64 %v5568 to ptr
  %ld5570 = load i64, ptr %p5569, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5570, ptr %slot727, align 8
  %v5571 = load i64, ptr %slot1, align 8
  %v5572 = load i64, ptr %slot726, align 8
  %v5573 = load i64, ptr %slot727, align 8
  call void @myl_f_0771312dfac681874ee229bebf205436b287de7366435531af48ff800c4cce48(ptr sret([32 x i8]) align 8 %callresult729, i64 %v5571, i64 %v5572, i64 %v5573) nomerge, !dbg !168
  %addr5574 = ptrtoint ptr %callresult729 to i64
  store i64 %addr5574, ptr %slot728, align 8
  %v5575 = load i64, ptr %slot728, align 8
  %v5576 = load i64, ptr %slot69, align 8
  %p5577 = inttoptr i64 %v5576 to ptr
  store i64 %v5575, ptr %p5577, align 8, !alias.scope !3, !noalias !4
  %v5578 = load i64, ptr %slot28, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  %ld5580 = load i32, ptr %p5579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5580, ptr %slot730, align 8
  %v5581 = load i32, ptr %slot730, align 8
  %cv5582 = zext i32 %v5581 to i64
  %cond5583 = icmp ne i64 %cv5582, 0
  br i1 %cond5583, label %bb_rcslotdrop888, label %bb_rcslotdone888
bb_rcslotdrop888:
  %v5584 = load i64, ptr %slot28, align 8
  %p5585 = inttoptr i64 %v5584 to ptr
  store i32 0, ptr %p5585, align 4, !alias.scope !3, !noalias !4
  %v5586 = load i64, ptr %slot37, align 8
  store i64 %v5586, ptr %slot731, align 8
  %v5587 = load i64, ptr %slot29, align 8
  %p5588 = inttoptr i64 %v5587 to ptr
  %ld5589 = load i32, ptr %p5588, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5589, ptr %slot732, align 8
  %v5590 = load i32, ptr %slot732, align 8
  %op5591 = and i32 %v5590, 28
  store i32 %op5591, ptr %slot733, align 8
  %v5592 = load i32, ptr %slot733, align 8
  %cv5593 = zext i32 %v5592 to i64
  %cond5594 = icmp ne i64 %cv5593, 0
  br i1 %cond5594, label %bb_rcslotrole888, label %bb_rcslotowner888
bb_rcslotrole888:
  %v5595 = load i64, ptr %slot96, align 8
  store i64 %v5595, ptr %slot734, align 8
  %v5596 = load i64, ptr %slot734, align 8
  %v5597 = load i64, ptr %slot731, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5596, i64 %v5597) nomerge, !dbg !168
  br label %bb_rcslotdone888
bb_rcslotowner888:
  %v5598 = load i64, ptr %slot96, align 8
  store i64 %v5598, ptr %slot735, align 8
  %v5599 = load i64, ptr %slot735, align 8
  %v5600 = load i64, ptr %slot731, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5599, i64 %v5600) nomerge, !dbg !168
  br label %bb_rcslotdone888
bb_rcslotdone888:
  %v5601 = load i64, ptr %slot69, align 8
  %p5602 = inttoptr i64 %v5601 to ptr
  %ld5603 = load i64, ptr %p5602, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5603, ptr %slot736, align 8
  %v5604 = load i64, ptr %slot736, align 8
  %v5605 = load i64, ptr %slot58, align 8
  %p5606 = inttoptr i64 %v5604 to ptr
  %p5607 = inttoptr i64 %v5605 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5607, ptr %p5606, i64 32, i1 false)
  %v5608 = load i64, ptr %slot46, align 8
  %p5609 = inttoptr i64 %v5608 to ptr
  %ld5610 = load i64, ptr %p5609, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5610, ptr %slot737, align 8
  %v5611 = load i64, ptr %slot737, align 8
  %v5612 = load i64, ptr %slot80, align 8
  %p5613 = inttoptr i64 %v5611 to ptr
  %p5614 = inttoptr i64 %v5612 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5614, ptr %p5613, i64 304, i1 false), !alias.scope !10000000
  %v5615 = load i64, ptr %slot80, align 8
  %v5616 = load i64, ptr %slot69, align 8
  %p5617 = inttoptr i64 %v5616 to ptr
  store i64 %v5615, ptr %p5617, align 8, !alias.scope !3, !noalias !4
  %v5618 = load i64, ptr %slot69, align 8
  %p5619 = inttoptr i64 %v5618 to ptr
  %ld5620 = load i64, ptr %p5619, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5620, ptr %slot738, align 8
  %v5621 = load i64, ptr %slot738, align 8
  %op5622 = add i64 %v5621, 32
  store i64 %op5622, ptr %slot739, align 8
  %v5623 = load i64, ptr %slot739, align 8
  %v5624 = load i64, ptr %slot69, align 8
  %p5625 = inttoptr i64 %v5624 to ptr
  store i64 %v5623, ptr %p5625, align 8, !alias.scope !3, !noalias !4
  %v5626 = load i64, ptr %slot12, align 8
  %p5627 = inttoptr i64 %v5626 to ptr
  %ld5628 = load i32, ptr %p5627, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5628, ptr %slot740, align 8
  %v5629 = load i32, ptr %slot740, align 8
  %cv5630 = zext i32 %v5629 to i64
  %cond5631 = icmp ne i64 %cv5630, 0
  br i1 %cond5631, label %bb_rcslotdrop901, label %bb_rcslotdone901
bb_rcslotdrop901:
  %v5632 = load i64, ptr %slot12, align 8
  %p5633 = inttoptr i64 %v5632 to ptr
  store i32 0, ptr %p5633, align 4, !alias.scope !3, !noalias !4
  %v5634 = load i64, ptr %slot59, align 8
  store i64 %v5634, ptr %slot741, align 8
  %v5635 = load i64, ptr %slot13, align 8
  %p5636 = inttoptr i64 %v5635 to ptr
  %ld5637 = load i32, ptr %p5636, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5637, ptr %slot742, align 8
  %v5638 = load i32, ptr %slot742, align 8
  %op5639 = and i32 %v5638, 28
  store i32 %op5639, ptr %slot743, align 8
  %v5640 = load i32, ptr %slot743, align 8
  %cv5641 = zext i32 %v5640 to i64
  %cond5642 = icmp ne i64 %cv5641, 0
  br i1 %cond5642, label %bb_rcslotrole901, label %bb_rcslotowner901
bb_rcslotrole901:
  %v5643 = load i64, ptr %slot96, align 8
  store i64 %v5643, ptr %slot744, align 8
  %v5644 = load i64, ptr %slot744, align 8
  %v5645 = load i64, ptr %slot741, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5644, i64 %v5645) nomerge, !dbg !170
  br label %bb_rcslotdone901
bb_rcslotowner901:
  %v5646 = load i64, ptr %slot96, align 8
  store i64 %v5646, ptr %slot745, align 8
  %v5647 = load i64, ptr %slot745, align 8
  %v5648 = load i64, ptr %slot741, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5647, i64 %v5648) nomerge, !dbg !170
  br label %bb_rcslotdone901
bb_rcslotdone901:
  %v5649 = load i64, ptr %slot46, align 8
  %p5650 = inttoptr i64 %v5649 to ptr
  %ld5651 = load i64, ptr %p5650, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5651, ptr %slot746, align 8
  %v5652 = load i64, ptr %slot746, align 8
  %op5653 = add i64 %v5652, 32
  store i64 %op5653, ptr %slot747, align 8
  %v5654 = load i64, ptr %slot59, align 8
  store i64 %v5654, ptr %slot748, align 8
  %v5655 = load i64, ptr %slot747, align 8
  %v5656 = load i64, ptr %slot748, align 8
  %p5657 = inttoptr i64 %v5655 to ptr
  %p5658 = inttoptr i64 %v5656 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5658, ptr %p5657, i64 208, i1 false), !alias.scope !10000000
  %v5659 = load i64, ptr %slot747, align 8
  %p5660 = inttoptr i64 %v5659 to ptr
  call void @llvm.memset.p0.i64(ptr %p5660, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !170
  %v5661 = load i64, ptr %slot12, align 8
  %p5662 = inttoptr i64 %v5661 to ptr
  store i32 1, ptr %p5662, align 4, !alias.scope !3, !noalias !4
  %v5663 = load i64, ptr %slot59, align 8
  %v5664 = load i64, ptr %slot69, align 8
  %p5665 = inttoptr i64 %v5664 to ptr
  store i64 %v5663, ptr %p5665, align 8, !alias.scope !3, !noalias !4
  %v5666 = load i64, ptr %slot58, align 8
  %v5667 = load i64, ptr %slot70, align 8
  %p5668 = inttoptr i64 %v5667 to ptr
  store i64 %v5666, ptr %p5668, align 8, !alias.scope !3, !noalias !4
  %v5669 = load i64, ptr %slot70, align 8
  %p5670 = inttoptr i64 %v5669 to ptr
  %ld5671 = load i64, ptr %p5670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5671, ptr %slot749, align 8
  %v5672 = load i64, ptr %slot749, align 8
  %op5673 = add i64 %v5672, 16
  store i64 %op5673, ptr %slot750, align 8
  %v5674 = load i64, ptr %slot750, align 8
  %p5675 = inttoptr i64 %v5674 to ptr
  %ld5676 = load i64, ptr %p5675, align 8
  store i64 %ld5676, ptr %slot751, align 8
  %v5677 = load i64, ptr %slot751, align 8
  %v5678 = load i64, ptr %slot70, align 8
  %p5679 = inttoptr i64 %v5678 to ptr
  store i64 %v5677, ptr %p5679, align 8, !alias.scope !3, !noalias !4
  %v5680 = load i64, ptr %slot71, align 8
  %p5681 = inttoptr i64 %v5680 to ptr
  store i64 1, ptr %p5681, align 8, !alias.scope !3, !noalias !4
  %v5682 = load i64, ptr %slot69, align 8
  %p5683 = inttoptr i64 %v5682 to ptr
  %ld5684 = load i64, ptr %p5683, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5684, ptr %slot752, align 8
  %v5685 = load i64, ptr %slot70, align 8
  %p5686 = inttoptr i64 %v5685 to ptr
  %ld5687 = load i64, ptr %p5686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5687, ptr %slot753, align 8
  %v5688 = load i64, ptr %slot71, align 8
  %p5689 = inttoptr i64 %v5688 to ptr
  %ld5690 = load i64, ptr %p5689, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5690, ptr %slot754, align 8
  %v5691 = load i64, ptr %slot1, align 8
  %v5692 = load i64, ptr %slot752, align 8
  %v5693 = load i64, ptr %slot753, align 8
  %v5694 = load i64, ptr %slot754, align 8
  %call5695 = call i64 @myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c(i64 %v5691, i64 %v5692, i64 %v5693, i64 %v5694) nomerge, !dbg !172
  store i64 %call5695, ptr %slot755, align 8
  %v5696 = load i64, ptr %slot755, align 8
  %v5697 = load i64, ptr %slot69, align 8
  %p5698 = inttoptr i64 %v5697 to ptr
  store i64 %v5696, ptr %p5698, align 8, !alias.scope !3, !noalias !4
  %v5699 = load i64, ptr %slot28, align 8
  %p5700 = inttoptr i64 %v5699 to ptr
  %ld5701 = load i32, ptr %p5700, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5701, ptr %slot756, align 8
  %v5702 = load i32, ptr %slot756, align 8
  %cv5703 = zext i32 %v5702 to i64
  %cond5704 = icmp ne i64 %cv5703, 0
  br i1 %cond5704, label %bb_rcslotdrop921, label %bb_rcslotdone921
bb_rcslotdrop921:
  %v5705 = load i64, ptr %slot28, align 8
  %p5706 = inttoptr i64 %v5705 to ptr
  store i32 0, ptr %p5706, align 4, !alias.scope !3, !noalias !4
  %v5707 = load i64, ptr %slot37, align 8
  store i64 %v5707, ptr %slot757, align 8
  %v5708 = load i64, ptr %slot29, align 8
  %p5709 = inttoptr i64 %v5708 to ptr
  %ld5710 = load i32, ptr %p5709, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5710, ptr %slot758, align 8
  %v5711 = load i32, ptr %slot758, align 8
  %op5712 = and i32 %v5711, 28
  store i32 %op5712, ptr %slot759, align 8
  %v5713 = load i32, ptr %slot759, align 8
  %cv5714 = zext i32 %v5713 to i64
  %cond5715 = icmp ne i64 %cv5714, 0
  br i1 %cond5715, label %bb_rcslotrole921, label %bb_rcslotowner921
bb_rcslotrole921:
  %v5716 = load i64, ptr %slot96, align 8
  store i64 %v5716, ptr %slot760, align 8
  %v5717 = load i64, ptr %slot760, align 8
  %v5718 = load i64, ptr %slot757, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5717, i64 %v5718) nomerge, !dbg !172
  br label %bb_rcslotdone921
bb_rcslotowner921:
  %v5719 = load i64, ptr %slot96, align 8
  store i64 %v5719, ptr %slot761, align 8
  %v5720 = load i64, ptr %slot761, align 8
  %v5721 = load i64, ptr %slot757, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5720, i64 %v5721) nomerge, !dbg !172
  br label %bb_rcslotdone921
bb_rcslotdone921:
  %v5722 = load i64, ptr %slot69, align 8
  %p5723 = inttoptr i64 %v5722 to ptr
  %ld5724 = load i64, ptr %p5723, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5724, ptr %slot762, align 8
  %v5725 = load i64, ptr %slot762, align 8
  %v5726 = load i64, ptr %slot60, align 8
  %p5727 = inttoptr i64 %v5726 to ptr
  store i64 %v5725, ptr %p5727, align 8, !alias.scope !3, !noalias !4
  %v5728 = load i64, ptr %slot46, align 8
  %p5729 = inttoptr i64 %v5728 to ptr
  %ld5730 = load i64, ptr %p5729, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5730, ptr %slot763, align 8
  %v5731 = load i64, ptr %slot763, align 8
  %op5732 = add i64 %v5731, 32
  store i64 %op5732, ptr %slot764, align 8
  %v5733 = load i64, ptr %slot59, align 8
  store i64 %v5733, ptr %slot765, align 8
  %v5734 = load i64, ptr %slot765, align 8
  %v5735 = load i64, ptr %slot764, align 8
  %p5736 = inttoptr i64 %v5734 to ptr
  %p5737 = inttoptr i64 %v5735 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5737, ptr %p5736, i64 208, i1 false), !alias.scope !10000000
  %v5738 = load i64, ptr %slot765, align 8
  %p5739 = inttoptr i64 %v5738 to ptr
  call void @llvm.memset.p0.i64(ptr %p5739, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !174
  %v5740 = load i64, ptr %slot12, align 8
  %p5741 = inttoptr i64 %v5740 to ptr
  store i32 0, ptr %p5741, align 4, !alias.scope !3, !noalias !4
  %v5742 = load i64, ptr %slot69, align 8
  %p5743 = inttoptr i64 %v5742 to ptr
  store i64 0, ptr %p5743, align 8, !alias.scope !3, !noalias !4
  %v5744 = load i64, ptr %slot46, align 8
  %p5745 = inttoptr i64 %v5744 to ptr
  %ld5746 = load i64, ptr %p5745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5746, ptr %slot766, align 8
  %v5747 = load i64, ptr %slot766, align 8
  %v5748 = load i64, ptr %slot81, align 8
  %p5749 = inttoptr i64 %v5747 to ptr
  %p5750 = inttoptr i64 %v5748 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5750, ptr %p5749, i64 304, i1 false), !alias.scope !10000000
  %v5751 = load i64, ptr %slot81, align 8
  %v5752 = load i64, ptr %slot69, align 8
  %p5753 = inttoptr i64 %v5752 to ptr
  store i64 %v5751, ptr %p5753, align 8, !alias.scope !3, !noalias !4
  %v5754 = load i64, ptr %slot69, align 8
  %p5755 = inttoptr i64 %v5754 to ptr
  %ld5756 = load i64, ptr %p5755, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5756, ptr %slot767, align 8
  %v5757 = load i64, ptr %slot767, align 8
  %op5758 = add i64 %v5757, 32
  store i64 %op5758, ptr %slot768, align 8
  %v5759 = load i64, ptr %slot768, align 8
  %v5760 = load i64, ptr %slot69, align 8
  %p5761 = inttoptr i64 %v5760 to ptr
  store i64 %v5759, ptr %p5761, align 8, !alias.scope !3, !noalias !4
  %v5762 = load i64, ptr %slot14, align 8
  %p5763 = inttoptr i64 %v5762 to ptr
  %ld5764 = load i32, ptr %p5763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5764, ptr %slot769, align 8
  %v5765 = load i32, ptr %slot769, align 8
  %cv5766 = zext i32 %v5765 to i64
  %cond5767 = icmp ne i64 %cv5766, 0
  br i1 %cond5767, label %bb_rcslotdrop938, label %bb_rcslotdone938
bb_rcslotdrop938:
  %v5768 = load i64, ptr %slot14, align 8
  %p5769 = inttoptr i64 %v5768 to ptr
  store i32 0, ptr %p5769, align 4, !alias.scope !3, !noalias !4
  %v5770 = load i64, ptr %slot61, align 8
  store i64 %v5770, ptr %slot770, align 8
  %v5771 = load i64, ptr %slot15, align 8
  %p5772 = inttoptr i64 %v5771 to ptr
  %ld5773 = load i32, ptr %p5772, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5773, ptr %slot771, align 8
  %v5774 = load i32, ptr %slot771, align 8
  %op5775 = and i32 %v5774, 28
  store i32 %op5775, ptr %slot772, align 8
  %v5776 = load i32, ptr %slot772, align 8
  %cv5777 = zext i32 %v5776 to i64
  %cond5778 = icmp ne i64 %cv5777, 0
  br i1 %cond5778, label %bb_rcslotrole938, label %bb_rcslotowner938
bb_rcslotrole938:
  %v5779 = load i64, ptr %slot96, align 8
  store i64 %v5779, ptr %slot773, align 8
  %v5780 = load i64, ptr %slot773, align 8
  %v5781 = load i64, ptr %slot770, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5780, i64 %v5781) nomerge, !dbg !176
  br label %bb_rcslotdone938
bb_rcslotowner938:
  %v5782 = load i64, ptr %slot96, align 8
  store i64 %v5782, ptr %slot774, align 8
  %v5783 = load i64, ptr %slot774, align 8
  %v5784 = load i64, ptr %slot770, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5783, i64 %v5784) nomerge, !dbg !176
  br label %bb_rcslotdone938
bb_rcslotdone938:
  %v5785 = load i64, ptr %slot46, align 8
  %p5786 = inttoptr i64 %v5785 to ptr
  %ld5787 = load i64, ptr %p5786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5787, ptr %slot775, align 8
  %v5788 = load i64, ptr %slot775, align 8
  %op5789 = add i64 %v5788, 32
  store i64 %op5789, ptr %slot776, align 8
  %v5790 = load i64, ptr %slot61, align 8
  store i64 %v5790, ptr %slot777, align 8
  %v5791 = load i64, ptr %slot776, align 8
  %v5792 = load i64, ptr %slot777, align 8
  %p5793 = inttoptr i64 %v5791 to ptr
  %p5794 = inttoptr i64 %v5792 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5794, ptr %p5793, i64 208, i1 false), !alias.scope !10000000
  %v5795 = load i64, ptr %slot776, align 8
  %p5796 = inttoptr i64 %v5795 to ptr
  call void @llvm.memset.p0.i64(ptr %p5796, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !176
  %v5797 = load i64, ptr %slot14, align 8
  %p5798 = inttoptr i64 %v5797 to ptr
  store i32 1, ptr %p5798, align 4, !alias.scope !3, !noalias !4
  %v5799 = load i64, ptr %slot61, align 8
  %v5800 = load i64, ptr %slot69, align 8
  %p5801 = inttoptr i64 %v5800 to ptr
  store i64 %v5799, ptr %p5801, align 8, !alias.scope !3, !noalias !4
  %v5802 = load i64, ptr %slot60, align 8
  %p5803 = inttoptr i64 %v5802 to ptr
  %ld5804 = load i64, ptr %p5803, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5804, ptr %slot778, align 8
  %v5805 = load i64, ptr %slot778, align 8
  %v5806 = load i64, ptr %slot70, align 8
  %p5807 = inttoptr i64 %v5806 to ptr
  store i64 %v5805, ptr %p5807, align 8, !alias.scope !3, !noalias !4
  %v5808 = load i64, ptr %slot71, align 8
  %p5809 = inttoptr i64 %v5808 to ptr
  store i64 0, ptr %p5809, align 8, !alias.scope !3, !noalias !4
  %v5810 = load i64, ptr %slot52, align 8
  %p5811 = inttoptr i64 %v5810 to ptr
  %ld5812 = load i64, ptr %p5811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5812, ptr %slot779, align 8
  %v5813 = load i64, ptr %slot779, align 8
  %v5814 = load i64, ptr %slot72, align 8
  %p5815 = inttoptr i64 %v5814 to ptr
  store i64 %v5813, ptr %p5815, align 8, !alias.scope !3, !noalias !4
  %v5816 = load i64, ptr %slot82, align 8
  store i64 %v5816, ptr %slot780, align 8
  %v5817 = load i64, ptr %slot780, align 8
  %p5818 = inttoptr i64 %v5817 to ptr
  store i64 0, ptr %p5818, align 8, !alias.scope !3, !noalias !4
  %v5819 = load i64, ptr %slot780, align 8
  %p5821 = inttoptr i64 %v5819 to ptr
  %gep5822 = getelementptr i8, ptr %p5821, i64 8
  %op5820 = ptrtoint ptr %gep5822 to i64
  store i64 %op5820, ptr %slot781, align 8
  %v5823 = load i64, ptr %slot781, align 8
  %p5824 = inttoptr i64 %v5823 to ptr
  store i64 0, ptr %p5824, align 8, !alias.scope !3, !noalias !4
  %v5825 = load i64, ptr %slot780, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  store i32 3, ptr %p5826, align 4, !alias.scope !3, !noalias !4
  %v5827 = load i64, ptr %slot36, align 8
  %p5828 = inttoptr i64 %v5827 to ptr
  store i32 1, ptr %p5828, align 4, !alias.scope !3, !noalias !4
  %v5829 = load i64, ptr %slot72, align 8
  store i64 %v5829, ptr %slot782, align 8
  %v5830 = load i64, ptr %slot780, align 8
  %p5832 = inttoptr i64 %v5830 to ptr
  %gep5833 = getelementptr i8, ptr %p5832, i64 8
  %op5831 = ptrtoint ptr %gep5833 to i64
  store i64 %op5831, ptr %slot783, align 8
  %v5834 = load i64, ptr %slot97, align 8
  store i64 %v5834, ptr %slot784, align 8
  %v5835 = load i64, ptr %slot782, align 8
  %p5836 = inttoptr i64 %v5835 to ptr
  %ld5837 = load i64, ptr %p5836, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5837, ptr %slot785, align 8
  %v5838 = load i64, ptr %slot785, align 8
  %v5839 = load i64, ptr %slot783, align 8
  %p5840 = inttoptr i64 %v5839 to ptr
  store i64 %v5838, ptr %p5840, align 8, !alias.scope !3, !noalias !4
  %v5841 = load i64, ptr %slot780, align 8
  %v5842 = load i64, ptr %slot72, align 8
  %p5843 = inttoptr i64 %v5842 to ptr
  store i64 %v5841, ptr %p5843, align 8, !alias.scope !3, !noalias !4
  %v5844 = load i64, ptr %slot69, align 8
  %p5845 = inttoptr i64 %v5844 to ptr
  %ld5846 = load i64, ptr %p5845, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5846, ptr %slot786, align 8
  %v5847 = load i64, ptr %slot70, align 8
  %p5848 = inttoptr i64 %v5847 to ptr
  %ld5849 = load i64, ptr %p5848, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5849, ptr %slot787, align 8
  %v5850 = load i64, ptr %slot71, align 8
  %p5851 = inttoptr i64 %v5850 to ptr
  %ld5852 = load i64, ptr %p5851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5852, ptr %slot788, align 8
  %v5853 = load i64, ptr %slot72, align 8
  %p5854 = inttoptr i64 %v5853 to ptr
  %ld5855 = load i64, ptr %p5854, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5855, ptr %slot789, align 8
  %v5856 = load i64, ptr %slot1, align 8
  %v5857 = load i64, ptr %slot786, align 8
  %v5858 = load i64, ptr %slot787, align 8
  %v5859 = load i64, ptr %slot788, align 8
  %v5860 = load i64, ptr %slot789, align 8
  %call5861 = call i64 @myl_f_a146740a06e5fa23640f1f72b70e36e5a89eb686546e75b2a5fa1ac552d2f888(i64 %v5856, i64 %v5857, i64 %v5858, i64 %v5859, i64 %v5860) nomerge, !dbg !178
  store i64 %call5861, ptr %slot790, align 8
  %v5862 = load i64, ptr %slot790, align 8
  %v5863 = load i64, ptr %slot69, align 8
  %p5864 = inttoptr i64 %v5863 to ptr
  store i64 %v5862, ptr %p5864, align 8, !alias.scope !3, !noalias !4
  %v5865 = load i64, ptr %slot28, align 8
  %p5866 = inttoptr i64 %v5865 to ptr
  %ld5867 = load i32, ptr %p5866, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5867, ptr %slot791, align 8
  %v5868 = load i32, ptr %slot791, align 8
  %cv5869 = zext i32 %v5868 to i64
  %cond5870 = icmp ne i64 %cv5869, 0
  br i1 %cond5870, label %bb_rcslotdrop966, label %bb_rcslotdone966
bb_rcslotdrop966:
  %v5871 = load i64, ptr %slot28, align 8
  %p5872 = inttoptr i64 %v5871 to ptr
  store i32 0, ptr %p5872, align 4, !alias.scope !3, !noalias !4
  %v5873 = load i64, ptr %slot37, align 8
  store i64 %v5873, ptr %slot792, align 8
  %v5874 = load i64, ptr %slot29, align 8
  %p5875 = inttoptr i64 %v5874 to ptr
  %ld5876 = load i32, ptr %p5875, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5876, ptr %slot793, align 8
  %v5877 = load i32, ptr %slot793, align 8
  %op5878 = and i32 %v5877, 28
  store i32 %op5878, ptr %slot794, align 8
  %v5879 = load i32, ptr %slot794, align 8
  %cv5880 = zext i32 %v5879 to i64
  %cond5881 = icmp ne i64 %cv5880, 0
  br i1 %cond5881, label %bb_rcslotrole966, label %bb_rcslotowner966
bb_rcslotrole966:
  %v5882 = load i64, ptr %slot96, align 8
  store i64 %v5882, ptr %slot795, align 8
  %v5883 = load i64, ptr %slot795, align 8
  %v5884 = load i64, ptr %slot792, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5883, i64 %v5884) nomerge, !dbg !178
  br label %bb_rcslotdone966
bb_rcslotowner966:
  %v5885 = load i64, ptr %slot96, align 8
  store i64 %v5885, ptr %slot796, align 8
  %v5886 = load i64, ptr %slot796, align 8
  %v5887 = load i64, ptr %slot792, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5886, i64 %v5887) nomerge, !dbg !178
  br label %bb_rcslotdone966
bb_rcslotdone966:
  %v5888 = load i64, ptr %slot46, align 8
  %p5889 = inttoptr i64 %v5888 to ptr
  %ld5890 = load i64, ptr %p5889, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5890, ptr %slot797, align 8
  %v5891 = load i64, ptr %slot797, align 8
  %op5892 = add i64 %v5891, 32
  store i64 %op5892, ptr %slot798, align 8
  %v5893 = load i64, ptr %slot61, align 8
  store i64 %v5893, ptr %slot799, align 8
  %v5894 = load i64, ptr %slot799, align 8
  %v5895 = load i64, ptr %slot798, align 8
  %p5896 = inttoptr i64 %v5894 to ptr
  %p5897 = inttoptr i64 %v5895 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5897, ptr %p5896, i64 208, i1 false), !alias.scope !10000000
  %v5898 = load i64, ptr %slot799, align 8
  %p5899 = inttoptr i64 %v5898 to ptr
  call void @llvm.memset.p0.i64(ptr %p5899, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !180
  %v5900 = load i64, ptr %slot14, align 8
  %p5901 = inttoptr i64 %v5900 to ptr
  store i32 0, ptr %p5901, align 4, !alias.scope !3, !noalias !4
  %v5902 = load i64, ptr %slot69, align 8
  %p5903 = inttoptr i64 %v5902 to ptr
  store i64 0, ptr %p5903, align 8, !alias.scope !3, !noalias !4
  %v5904 = load i64, ptr %slot46, align 8
  %p5905 = inttoptr i64 %v5904 to ptr
  %ld5906 = load i64, ptr %p5905, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5906, ptr %slot800, align 8
  %v5907 = load i64, ptr %slot800, align 8
  %v5908 = load i64, ptr %slot83, align 8
  %p5909 = inttoptr i64 %v5907 to ptr
  %p5910 = inttoptr i64 %v5908 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5910, ptr %p5909, i64 304, i1 false), !alias.scope !10000000
  %v5911 = load i64, ptr %slot83, align 8
  %v5912 = load i64, ptr %slot69, align 8
  %p5913 = inttoptr i64 %v5912 to ptr
  store i64 %v5911, ptr %p5913, align 8, !alias.scope !3, !noalias !4
  %v5914 = load i64, ptr %slot69, align 8
  %p5915 = inttoptr i64 %v5914 to ptr
  %ld5916 = load i64, ptr %p5915, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5916, ptr %slot801, align 8
  %v5917 = load i64, ptr %slot801, align 8
  %op5918 = add i64 %v5917, 32
  store i64 %op5918, ptr %slot802, align 8
  %v5919 = load i64, ptr %slot802, align 8
  %v5920 = load i64, ptr %slot69, align 8
  %p5921 = inttoptr i64 %v5920 to ptr
  store i64 %v5919, ptr %p5921, align 8, !alias.scope !3, !noalias !4
  %v5922 = load i64, ptr %slot16, align 8
  %p5923 = inttoptr i64 %v5922 to ptr
  %ld5924 = load i32, ptr %p5923, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5924, ptr %slot803, align 8
  %v5925 = load i32, ptr %slot803, align 8
  %cv5926 = zext i32 %v5925 to i64
  %cond5927 = icmp ne i64 %cv5926, 0
  br i1 %cond5927, label %bb_rcslotdrop982, label %bb_rcslotdone982
bb_rcslotdrop982:
  %v5928 = load i64, ptr %slot16, align 8
  %p5929 = inttoptr i64 %v5928 to ptr
  store i32 0, ptr %p5929, align 4, !alias.scope !3, !noalias !4
  %v5930 = load i64, ptr %slot62, align 8
  store i64 %v5930, ptr %slot804, align 8
  %v5931 = load i64, ptr %slot17, align 8
  %p5932 = inttoptr i64 %v5931 to ptr
  %ld5933 = load i32, ptr %p5932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5933, ptr %slot805, align 8
  %v5934 = load i32, ptr %slot805, align 8
  %op5935 = and i32 %v5934, 28
  store i32 %op5935, ptr %slot806, align 8
  %v5936 = load i32, ptr %slot806, align 8
  %cv5937 = zext i32 %v5936 to i64
  %cond5938 = icmp ne i64 %cv5937, 0
  br i1 %cond5938, label %bb_rcslotrole982, label %bb_rcslotowner982
bb_rcslotrole982:
  %v5939 = load i64, ptr %slot96, align 8
  store i64 %v5939, ptr %slot807, align 8
  %v5940 = load i64, ptr %slot807, align 8
  %v5941 = load i64, ptr %slot804, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v5940, i64 %v5941) nomerge, !dbg !182
  br label %bb_rcslotdone982
bb_rcslotowner982:
  %v5942 = load i64, ptr %slot96, align 8
  store i64 %v5942, ptr %slot808, align 8
  %v5943 = load i64, ptr %slot808, align 8
  %v5944 = load i64, ptr %slot804, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v5943, i64 %v5944) nomerge, !dbg !182
  br label %bb_rcslotdone982
bb_rcslotdone982:
  %v5945 = load i64, ptr %slot46, align 8
  %p5946 = inttoptr i64 %v5945 to ptr
  %ld5947 = load i64, ptr %p5946, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5947, ptr %slot809, align 8
  %v5948 = load i64, ptr %slot809, align 8
  %op5949 = add i64 %v5948, 32
  store i64 %op5949, ptr %slot810, align 8
  %v5950 = load i64, ptr %slot62, align 8
  store i64 %v5950, ptr %slot811, align 8
  %v5951 = load i64, ptr %slot810, align 8
  %v5952 = load i64, ptr %slot811, align 8
  %p5953 = inttoptr i64 %v5951 to ptr
  %p5954 = inttoptr i64 %v5952 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5954, ptr %p5953, i64 208, i1 false), !alias.scope !10000000
  %v5955 = load i64, ptr %slot810, align 8
  %p5956 = inttoptr i64 %v5955 to ptr
  call void @llvm.memset.p0.i64(ptr %p5956, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !182
  %v5957 = load i64, ptr %slot16, align 8
  %p5958 = inttoptr i64 %v5957 to ptr
  store i32 1, ptr %p5958, align 4, !alias.scope !3, !noalias !4
  %v5959 = load i64, ptr %slot62, align 8
  %v5960 = load i64, ptr %slot69, align 8
  %p5961 = inttoptr i64 %v5960 to ptr
  store i64 %v5959, ptr %p5961, align 8, !alias.scope !3, !noalias !4
  %v5962 = load i64, ptr %slot60, align 8
  %p5963 = inttoptr i64 %v5962 to ptr
  %ld5964 = load i64, ptr %p5963, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5964, ptr %slot812, align 8
  %v5965 = load i64, ptr %slot812, align 8
  %v5966 = load i64, ptr %slot70, align 8
  %p5967 = inttoptr i64 %v5966 to ptr
  store i64 %v5965, ptr %p5967, align 8, !alias.scope !3, !noalias !4
  %v5968 = load i64, ptr %slot84, align 8
  store i64 %v5968, ptr %slot813, align 8
  %v5969 = load i64, ptr %slot813, align 8
  %p5970 = inttoptr i64 %v5969 to ptr
  store i64 0, ptr %p5970, align 8, !alias.scope !3, !noalias !4
  %v5971 = load i64, ptr %slot813, align 8
  %p5973 = inttoptr i64 %v5971 to ptr
  %gep5974 = getelementptr i8, ptr %p5973, i64 8
  %op5972 = ptrtoint ptr %gep5974 to i64
  store i64 %op5972, ptr %slot814, align 8
  %v5975 = load i64, ptr %slot814, align 8
  %p5976 = inttoptr i64 %v5975 to ptr
  store i64 0, ptr %p5976, align 8, !alias.scope !3, !noalias !4
  %v5977 = load i64, ptr %slot813, align 8
  %p5978 = inttoptr i64 %v5977 to ptr
  store i32 3, ptr %p5978, align 4, !alias.scope !3, !noalias !4
  %v5979 = load i64, ptr %slot36, align 8
  %p5980 = inttoptr i64 %v5979 to ptr
  store i32 1, ptr %p5980, align 4, !alias.scope !3, !noalias !4
  %v5981 = load i64, ptr %slot70, align 8
  store i64 %v5981, ptr %slot815, align 8
  %v5982 = load i64, ptr %slot813, align 8
  %p5984 = inttoptr i64 %v5982 to ptr
  %gep5985 = getelementptr i8, ptr %p5984, i64 8
  %op5983 = ptrtoint ptr %gep5985 to i64
  store i64 %op5983, ptr %slot816, align 8
  %v5986 = load i64, ptr %slot97, align 8
  store i64 %v5986, ptr %slot817, align 8
  %v5987 = load i64, ptr %slot815, align 8
  %p5988 = inttoptr i64 %v5987 to ptr
  %ld5989 = load i64, ptr %p5988, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5989, ptr %slot818, align 8
  %v5990 = load i64, ptr %slot818, align 8
  %v5991 = load i64, ptr %slot816, align 8
  %p5992 = inttoptr i64 %v5991 to ptr
  store i64 %v5990, ptr %p5992, align 8, !alias.scope !3, !noalias !4
  %v5993 = load i64, ptr %slot813, align 8
  %v5994 = load i64, ptr %slot70, align 8
  %p5995 = inttoptr i64 %v5994 to ptr
  store i64 %v5993, ptr %p5995, align 8, !alias.scope !3, !noalias !4
  %v5996 = load i64, ptr %slot69, align 8
  %p5997 = inttoptr i64 %v5996 to ptr
  %ld5998 = load i64, ptr %p5997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5998, ptr %slot819, align 8
  %v5999 = load i64, ptr %slot70, align 8
  %p6000 = inttoptr i64 %v5999 to ptr
  %ld6001 = load i64, ptr %p6000, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6001, ptr %slot820, align 8
  %v6002 = load i64, ptr %slot1, align 8
  %v6003 = load i64, ptr %slot819, align 8
  %v6004 = load i64, ptr %slot820, align 8
  %call6005 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v6002, i64 %v6003, i64 %v6004) nomerge, !dbg !184
  store i64 %call6005, ptr %slot821, align 8
  %v6006 = load i64, ptr %slot821, align 8
  %v6007 = load i64, ptr %slot69, align 8
  %p6008 = inttoptr i64 %v6007 to ptr
  store i64 %v6006, ptr %p6008, align 8, !alias.scope !3, !noalias !4
  %v6009 = load i64, ptr %slot28, align 8
  %p6010 = inttoptr i64 %v6009 to ptr
  %ld6011 = load i32, ptr %p6010, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6011, ptr %slot822, align 8
  %v6012 = load i32, ptr %slot822, align 8
  %cv6013 = zext i32 %v6012 to i64
  %cond6014 = icmp ne i64 %cv6013, 0
  br i1 %cond6014, label %bb_rcslotdrop1007, label %bb_rcslotdone1007
bb_rcslotdrop1007:
  %v6015 = load i64, ptr %slot28, align 8
  %p6016 = inttoptr i64 %v6015 to ptr
  store i32 0, ptr %p6016, align 4, !alias.scope !3, !noalias !4
  %v6017 = load i64, ptr %slot37, align 8
  store i64 %v6017, ptr %slot823, align 8
  %v6018 = load i64, ptr %slot29, align 8
  %p6019 = inttoptr i64 %v6018 to ptr
  %ld6020 = load i32, ptr %p6019, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6020, ptr %slot824, align 8
  %v6021 = load i32, ptr %slot824, align 8
  %op6022 = and i32 %v6021, 28
  store i32 %op6022, ptr %slot825, align 8
  %v6023 = load i32, ptr %slot825, align 8
  %cv6024 = zext i32 %v6023 to i64
  %cond6025 = icmp ne i64 %cv6024, 0
  br i1 %cond6025, label %bb_rcslotrole1007, label %bb_rcslotowner1007
bb_rcslotrole1007:
  %v6026 = load i64, ptr %slot96, align 8
  store i64 %v6026, ptr %slot826, align 8
  %v6027 = load i64, ptr %slot826, align 8
  %v6028 = load i64, ptr %slot823, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6027, i64 %v6028) nomerge, !dbg !184
  br label %bb_rcslotdone1007
bb_rcslotowner1007:
  %v6029 = load i64, ptr %slot96, align 8
  store i64 %v6029, ptr %slot827, align 8
  %v6030 = load i64, ptr %slot827, align 8
  %v6031 = load i64, ptr %slot823, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6030, i64 %v6031) nomerge, !dbg !184
  br label %bb_rcslotdone1007
bb_rcslotdone1007:
  %v6032 = load i64, ptr %slot46, align 8
  %p6033 = inttoptr i64 %v6032 to ptr
  %ld6034 = load i64, ptr %p6033, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6034, ptr %slot828, align 8
  %v6035 = load i64, ptr %slot828, align 8
  %op6036 = add i64 %v6035, 32
  store i64 %op6036, ptr %slot829, align 8
  %v6037 = load i64, ptr %slot62, align 8
  store i64 %v6037, ptr %slot830, align 8
  %v6038 = load i64, ptr %slot830, align 8
  %v6039 = load i64, ptr %slot829, align 8
  %p6040 = inttoptr i64 %v6038 to ptr
  %p6041 = inttoptr i64 %v6039 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6041, ptr %p6040, i64 208, i1 false), !alias.scope !10000000
  %v6042 = load i64, ptr %slot830, align 8
  %p6043 = inttoptr i64 %v6042 to ptr
  call void @llvm.memset.p0.i64(ptr %p6043, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !186
  %v6044 = load i64, ptr %slot16, align 8
  %p6045 = inttoptr i64 %v6044 to ptr
  store i32 0, ptr %p6045, align 4, !alias.scope !3, !noalias !4
  %v6046 = load i64, ptr %slot69, align 8
  %p6047 = inttoptr i64 %v6046 to ptr
  store i64 0, ptr %p6047, align 8, !alias.scope !3, !noalias !4
  %v6048 = load i64, ptr %slot46, align 8
  %p6049 = inttoptr i64 %v6048 to ptr
  %ld6050 = load i64, ptr %p6049, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6050, ptr %slot831, align 8
  %v6051 = load i64, ptr %slot831, align 8
  %v6052 = load i64, ptr %slot69, align 8
  %p6053 = inttoptr i64 %v6052 to ptr
  store i64 %v6051, ptr %p6053, align 8, !alias.scope !3, !noalias !4
  %v6054 = load i64, ptr %slot58, align 8
  %v6055 = load i64, ptr %slot70, align 8
  %p6056 = inttoptr i64 %v6055 to ptr
  store i64 %v6054, ptr %p6056, align 8, !alias.scope !3, !noalias !4
  %v6057 = load i64, ptr %slot60, align 8
  %p6058 = inttoptr i64 %v6057 to ptr
  %ld6059 = load i64, ptr %p6058, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6059, ptr %slot832, align 8
  %v6060 = load i64, ptr %slot832, align 8
  %v6061 = load i64, ptr %slot71, align 8
  %p6062 = inttoptr i64 %v6061 to ptr
  store i64 %v6060, ptr %p6062, align 8, !alias.scope !3, !noalias !4
  %v6063 = load i64, ptr %slot48, align 8
  %p6064 = inttoptr i64 %v6063 to ptr
  %ld6065 = load i64, ptr %p6064, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6065, ptr %slot833, align 8
  %v6066 = load i64, ptr %slot833, align 8
  %v6067 = load i64, ptr %slot72, align 8
  %p6068 = inttoptr i64 %v6067 to ptr
  store i64 %v6066, ptr %p6068, align 8, !alias.scope !3, !noalias !4
  %v6069 = load i64, ptr %slot50, align 8
  %p6070 = inttoptr i64 %v6069 to ptr
  %ld6071 = load i64, ptr %p6070, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6071, ptr %slot834, align 8
  %v6072 = load i64, ptr %slot834, align 8
  %v6073 = load i64, ptr %slot73, align 8
  %p6074 = inttoptr i64 %v6073 to ptr
  store i64 %v6072, ptr %p6074, align 8, !alias.scope !3, !noalias !4
  %v6075 = load i64, ptr %slot74, align 8
  %p6076 = inttoptr i64 %v6075 to ptr
  store i64 1, ptr %p6076, align 8, !alias.scope !3, !noalias !4
  %v6077 = load i64, ptr %slot74, align 8
  %p6078 = inttoptr i64 %v6077 to ptr
  %ld6079 = load i64, ptr %p6078, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6079, ptr %slot835, align 8
  %v6080 = load i64, ptr %slot73, align 8
  %p6081 = inttoptr i64 %v6080 to ptr
  %ld6082 = load i64, ptr %p6081, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6082, ptr %slot836, align 8
  %v6083 = load i64, ptr %slot836, align 8
  %v6084 = load i64, ptr %slot835, align 8
  %ovpair6086 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v6083, i64 %v6084)
  %op6085 = extractvalue { i64, i1 } %ovpair6086, 0
  %ov6087 = extractvalue { i64, i1 } %ovpair6086, 1
  store i64 %op6085, ptr %slot837, align 8
  %cv6088 = zext i1 %ov6087 to i64
  store i64 %cv6088, ptr %slot838, align 8
  %v6089 = load i64, ptr %slot838, align 8
  %cond6090 = icmp ne i64 %v6089, 0
  br i1 %cond6090, label %bb_overflow1024, label %bb_checked1024
bb_overflow1024:
  %v6091 = load i64, ptr %slot1, align 8
  %p6092 = inttoptr i64 %v6091 to ptr
  %v6093 = load i64, ptr %slot836, align 8
  %v6094 = load i64, ptr %slot835, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p6092, i64 0, i64 %v6093, i64 %v6094, i64 64) nomerge, !dbg !188
  unreachable
bb_checked1024:
  %v6095 = load i64, ptr %slot837, align 8
  %v6096 = load i64, ptr %slot73, align 8
  %p6097 = inttoptr i64 %v6096 to ptr
  store i64 %v6095, ptr %p6097, align 8, !alias.scope !3, !noalias !4
  %v6098 = load i64, ptr %slot49, align 8
  %p6099 = inttoptr i64 %v6098 to ptr
  %ld6100 = load i64, ptr %p6099, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6100, ptr %slot839, align 8
  %v6101 = load i64, ptr %slot839, align 8
  %v6102 = load i64, ptr %slot74, align 8
  %p6103 = inttoptr i64 %v6102 to ptr
  store i64 %v6101, ptr %p6103, align 8, !alias.scope !3, !noalias !4
  %v6104 = load i64, ptr %slot69, align 8
  %p6105 = inttoptr i64 %v6104 to ptr
  %ld6106 = load i64, ptr %p6105, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6106, ptr %slot840, align 8
  %v6107 = load i64, ptr %slot70, align 8
  %p6108 = inttoptr i64 %v6107 to ptr
  %ld6109 = load i64, ptr %p6108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6109, ptr %slot841, align 8
  %v6110 = load i64, ptr %slot71, align 8
  %p6111 = inttoptr i64 %v6110 to ptr
  %ld6112 = load i64, ptr %p6111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6112, ptr %slot842, align 8
  %v6113 = load i64, ptr %slot72, align 8
  %p6114 = inttoptr i64 %v6113 to ptr
  %ld6115 = load i64, ptr %p6114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6115, ptr %slot843, align 8
  %v6116 = load i64, ptr %slot73, align 8
  %p6117 = inttoptr i64 %v6116 to ptr
  %ld6118 = load i64, ptr %p6117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6118, ptr %slot844, align 8
  %v6119 = load i64, ptr %slot74, align 8
  %p6120 = inttoptr i64 %v6119 to ptr
  %ld6121 = load i64, ptr %p6120, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6121, ptr %slot845, align 8
  %v6122 = load i64, ptr %slot1, align 8
  %v6123 = load i64, ptr %slot840, align 8
  %v6124 = load i64, ptr %slot841, align 8
  %v6125 = load i64, ptr %slot842, align 8
  %v6126 = load i64, ptr %slot843, align 8
  %v6127 = load i64, ptr %slot844, align 8
  %v6128 = load i64, ptr %slot845, align 8
  call void @myl_f_3ea6e9e7e7e3f3c99e8bd3ee87e61bb9473edc3368079bda3cc736a65b3decbc(ptr sret([24 x i8]) align 8 %callresult847, i64 %v6122, i64 %v6123, i64 %v6124, i64 %v6125, i64 %v6126, i64 %v6127, i64 %v6128) nomerge, !dbg !190
  %addr6129 = ptrtoint ptr %callresult847 to i64
  store i64 %addr6129, ptr %slot846, align 8
  %v6130 = load i64, ptr %slot846, align 8
  %v6131 = load i64, ptr %slot69, align 8
  %p6132 = inttoptr i64 %v6131 to ptr
  store i64 %v6130, ptr %p6132, align 8, !alias.scope !3, !noalias !4
  %v6133 = load i64, ptr %slot69, align 8
  %p6134 = inttoptr i64 %v6133 to ptr
  %ld6135 = load i64, ptr %p6134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6135, ptr %slot848, align 8
  %v6136 = load i64, ptr %slot41, align 8
  store i64 %v6136, ptr %slot849, align 8
  %v6137 = load i64, ptr %slot848, align 8
  %v6138 = load i64, ptr %slot849, align 8
  %p6139 = inttoptr i64 %v6137 to ptr
  %p6140 = inttoptr i64 %v6138 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6140, ptr %p6139, i64 24, i1 false)
  %v6141 = load i64, ptr %slot35, align 8
  %p6142 = inttoptr i64 %v6141 to ptr
  store i32 2, ptr %p6142, align 4, !alias.scope !3, !noalias !4
  %v6143 = load i64, ptr %slot34, align 8
  %p6144 = inttoptr i64 %v6143 to ptr
  store i32 1, ptr %p6144, align 4, !alias.scope !3, !noalias !4
  %v6145 = load i64, ptr %slot28, align 8
  %p6146 = inttoptr i64 %v6145 to ptr
  %ld6147 = load i32, ptr %p6146, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6147, ptr %slot850, align 8
  %v6148 = load i32, ptr %slot850, align 8
  %cv6149 = zext i32 %v6148 to i64
  %cond6150 = icmp ne i64 %cv6149, 0
  br i1 %cond6150, label %bb_rcslotdrop1040, label %bb_rcslotdone1040
bb_rcslotdrop1040:
  %v6151 = load i64, ptr %slot28, align 8
  %p6152 = inttoptr i64 %v6151 to ptr
  store i32 0, ptr %p6152, align 4, !alias.scope !3, !noalias !4
  %v6153 = load i64, ptr %slot37, align 8
  store i64 %v6153, ptr %slot851, align 8
  %v6154 = load i64, ptr %slot29, align 8
  %p6155 = inttoptr i64 %v6154 to ptr
  %ld6156 = load i32, ptr %p6155, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6156, ptr %slot852, align 8
  %v6157 = load i32, ptr %slot852, align 8
  %op6158 = and i32 %v6157, 28
  store i32 %op6158, ptr %slot853, align 8
  %v6159 = load i32, ptr %slot853, align 8
  %cv6160 = zext i32 %v6159 to i64
  %cond6161 = icmp ne i64 %cv6160, 0
  br i1 %cond6161, label %bb_rcslotrole1040, label %bb_rcslotowner1040
bb_rcslotrole1040:
  %v6162 = load i64, ptr %slot96, align 8
  store i64 %v6162, ptr %slot854, align 8
  %v6163 = load i64, ptr %slot854, align 8
  %v6164 = load i64, ptr %slot851, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v6163, i64 %v6164) nomerge, !dbg !190
  br label %bb_rcslotdone1040
bb_rcslotowner1040:
  %v6165 = load i64, ptr %slot96, align 8
  store i64 %v6165, ptr %slot855, align 8
  %v6166 = load i64, ptr %slot855, align 8
  %v6167 = load i64, ptr %slot851, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v6166, i64 %v6167) nomerge, !dbg !190
  br label %bb_rcslotdone1040
bb_rcslotdone1040:
  %v6168 = load i64, ptr %slot37, align 8
  store i64 %v6168, ptr %slot856, align 8
  %v6169 = load i64, ptr %slot41, align 8
  store i64 %v6169, ptr %slot857, align 8
  %v6170 = load i64, ptr %slot857, align 8
  %v6171 = load i64, ptr %slot856, align 8
  %p6172 = inttoptr i64 %v6170 to ptr
  %p6173 = inttoptr i64 %v6171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6173, ptr %p6172, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6174 = load i64, ptr %slot29, align 8
  %p6175 = inttoptr i64 %v6174 to ptr
  store i32 2, ptr %p6175, align 4, !alias.scope !3, !noalias !4
  %v6176 = load i64, ptr %slot35, align 8
  %p6177 = inttoptr i64 %v6176 to ptr
  %ld6178 = load i32, ptr %p6177, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6178, ptr %slot858, align 8
  %v6179 = load i32, ptr %slot858, align 8
  %v6180 = load i64, ptr %slot29, align 8
  %p6181 = inttoptr i64 %v6180 to ptr
  store i32 %v6179, ptr %p6181, align 4, !alias.scope !3, !noalias !4
  %v6182 = load i64, ptr %slot34, align 8
  %p6183 = inttoptr i64 %v6182 to ptr
  store i32 0, ptr %p6183, align 4, !alias.scope !3, !noalias !4
  %v6184 = load i64, ptr %slot28, align 8
  %p6185 = inttoptr i64 %v6184 to ptr
  store i32 1, ptr %p6185, align 4, !alias.scope !3, !noalias !4
  %v6186 = load i64, ptr %slot856, align 8
  %v6187 = load i64, ptr %slot69, align 8
  %p6188 = inttoptr i64 %v6187 to ptr
  store i64 %v6186, ptr %p6188, align 8, !alias.scope !3, !noalias !4
  %v6189 = load i64, ptr %slot69, align 8
  %p6190 = inttoptr i64 %v6189 to ptr
  %ld6191 = load i64, ptr %p6190, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6191, ptr %slot859, align 8
  %v6192 = load i64, ptr %slot859, align 8
  %p6193 = inttoptr i64 %v6192 to ptr
  %ld6194 = load i32, ptr %p6193, align 4
  %ext6195 = zext i32 %ld6194 to i64
  store i64 %ext6195, ptr %slot860, align 8
  %v6196 = load i64, ptr %slot860, align 8
  %cmp6197 = icmp eq i64 %v6196, 0
  %cv6198 = zext i1 %cmp6197 to i64
  store i64 %cv6198, ptr %slot861, align 8
  %v6199 = load i64, ptr %slot861, align 8
  %cond6200 = icmp ne i64 %v6199, 0
  br i1 %cond6200, label %bb_rctryok1056, label %bb_rctryerror1056
bb_rctryerror1056:
  %p6201 = inttoptr i64 ptrtoint (ptr @myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p6201, i64 12884902044) "call-inline-cost"="0", !dbg !192
  %v6202 = load i64, ptr %slot859, align 8
  %op6203 = add i64 %v6202, 8
  store i64 %op6203, ptr %slot862, align 8
  %v6204 = load i64, ptr %slot85, align 8
  store i64 %v6204, ptr %slot863, align 8
  %v6205 = load i64, ptr %slot863, align 8
  %p6206 = inttoptr i64 %v6205 to ptr
  store i64 0, ptr %p6206, align 8, !alias.scope !3, !noalias !4
  %v6207 = load i64, ptr %slot863, align 8
  %p6209 = inttoptr i64 %v6207 to ptr
  %gep6210 = getelementptr i8, ptr %p6209, i64 8
  %op6208 = ptrtoint ptr %gep6210 to i64
  store i64 %op6208, ptr %slot864, align 8
  %v6211 = load i64, ptr %slot864, align 8
  %p6212 = inttoptr i64 %v6211 to ptr
  store i64 0, ptr %p6212, align 8, !alias.scope !3, !noalias !4
  %v6213 = load i64, ptr %slot863, align 8
  %p6215 = inttoptr i64 %v6213 to ptr
  %gep6216 = getelementptr i8, ptr %p6215, i64 16
  %op6214 = ptrtoint ptr %gep6216 to i64
  store i64 %op6214, ptr %slot865, align 8
  %v6217 = load i64, ptr %slot865, align 8
  %p6218 = inttoptr i64 %v6217 to ptr
  store i64 0, ptr %p6218, align 8, !alias.scope !3, !noalias !4
  %v6219 = load i64, ptr %slot863, align 8
  %p6220 = inttoptr i64 %v6219 to ptr
  store i32 1, ptr %p6220, align 4, !alias.scope !3, !noalias !4
  %v6221 = load i64, ptr %slot863, align 8
  %p6223 = inttoptr i64 %v6221 to ptr
  %gep6224 = getelementptr i8, ptr %p6223, i64 8
  %op6222 = ptrtoint ptr %gep6224 to i64
  store i64 %op6222, ptr %slot866, align 8
  %v6225 = load i64, ptr %slot36, align 8
  %p6226 = inttoptr i64 %v6225 to ptr
  store i32 1, ptr %p6226, align 4, !alias.scope !3, !noalias !4
  %v6227 = load i64, ptr %slot97, align 8
  store i64 %v6227, ptr %slot867, align 8
  %v6228 = load i64, ptr %slot96, align 8
  %v6229 = load i64, ptr %slot866, align 8
  %v6230 = load i64, ptr %slot862, align 8
  %v6231 = load i64, ptr %slot867, align 8
  %cv6232 = trunc i64 %v6231 to i32
  %call6233 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v6228, i64 %v6229, i64 %v6230, i32 %cv6232) nomerge, !dbg !192
  store i32 %call6233, ptr %slot868, align 8
  %v6234 = load i32, ptr %slot868, align 8
  %cv6235 = zext i32 %v6234 to i64
  %cond6236 = icmp ne i64 %cv6235, 0
  br i1 %cond6236, label %bb_rcsuccess1067, label %bb_rcfailure1067
bb_rcfailure1067:
  %v6237 = load i64, ptr %slot96, align 8
  %p6238 = inttoptr i64 %v6237 to ptr
  %call6239 = call i32 @myl_rc_take_failure(ptr %p6238) nomerge, !dbg !192
  store i32 %call6239, ptr %slot869, align 8
  %v6240 = load i64, ptr %slot1, align 8
  %p6241 = inttoptr i64 %v6240 to ptr
  %v6242 = load i32, ptr %slot869, align 8
  %call6243 = call i32 @myl_qbe_rc_status(ptr %p6241, i32 %v6242) nomerge, !dbg !192
  store i32 %call6243, ptr %slot870, align 8
  br label %bb_failure
bb_rcsuccess1067:
  %v6244 = load i64, ptr %slot863, align 8
  %v6245 = load i64, ptr %slot69, align 8
  %p6246 = inttoptr i64 %v6245 to ptr
  store i64 %v6244, ptr %p6246, align 8, !alias.scope !3, !noalias !4
  %v6247 = load i64, ptr %slot69, align 8
  %p6248 = inttoptr i64 %v6247 to ptr
  %ld6249 = load i64, ptr %p6248, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6249, ptr %slot871, align 8
  %v6250 = load i64, ptr %slot41, align 8
  store i64 %v6250, ptr %slot872, align 8
  %v6251 = load i64, ptr %slot871, align 8
  %v6252 = load i64, ptr %slot872, align 8
  %p6253 = inttoptr i64 %v6251 to ptr
  %p6254 = inttoptr i64 %v6252 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6254, ptr %p6253, i64 24, i1 false)
  %v6255 = load i64, ptr %slot35, align 8
  %p6256 = inttoptr i64 %v6255 to ptr
  store i32 2, ptr %p6256, align 4, !alias.scope !3, !noalias !4
  %v6257 = load i64, ptr %slot34, align 8
  %p6258 = inttoptr i64 %v6257 to ptr
  store i32 1, ptr %p6258, align 4, !alias.scope !3, !noalias !4
  %v6259 = load i64, ptr %slot28, align 8
  %p6260 = inttoptr i64 %v6259 to ptr
  %ld6261 = load i32, ptr %p6260, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6261, ptr %slot873, align 8
  %v6262 = load i32, ptr %slot873, align 8
  %cv6263 = zext i32 %v6262 to i64
  %cond6264 = icmp ne i64 %cv6263, 0
  br i1 %cond6264, label %bb_rcslotdrop1076, label %bb_rcslotdone1076
bb_rcslotdrop1076:
  %v6265 = load i64, ptr %slot28, align 8
  %p6266 = inttoptr i64 %v6265 to ptr
  store i32 0, ptr %p6266, align 4, !alias.scope !3, !noalias !4
  %v6267 = load i64, ptr %slot37, align 8
  store i64 %v6267, ptr %slot874, align 8
  %v6268 = load i64, ptr %slot29, align 8
  %p6269 = inttoptr i64 %v6268 to ptr
  %ld6270 = load i32, ptr %p6269, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6270, ptr %slot875, align 8
  %v6271 = load i32, ptr %slot875, align 8
  %op6272 = and i32 %v6271, 28
  store i32 %op6272, ptr %slot876, align 8
  %v6273 = load i32, ptr %slot876, align 8
  %cv6274 = zext i32 %v6273 to i64
  %cond6275 = icmp ne i64 %cv6274, 0
  br i1 %cond6275, label %bb_rcslotrole1076, label %bb_rcslotowner1076
bb_rcslotrole1076:
  %v6276 = load i64, ptr %slot96, align 8
  store i64 %v6276, ptr %slot877, align 8
  %v6277 = load i64, ptr %slot877, align 8
  %v6278 = load i64, ptr %slot874, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64 %v6277, i64 %v6278) nomerge, !dbg !192
  br label %bb_rcslotdone1076
bb_rcslotowner1076:
  %v6279 = load i64, ptr %slot96, align 8
  store i64 %v6279, ptr %slot878, align 8
  %v6280 = load i64, ptr %slot878, align 8
  %v6281 = load i64, ptr %slot874, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64 %v6280, i64 %v6281) nomerge, !dbg !192
  br label %bb_rcslotdone1076
bb_rcslotdone1076:
  %v6282 = load i64, ptr %slot37, align 8
  store i64 %v6282, ptr %slot879, align 8
  %v6283 = load i64, ptr %slot41, align 8
  store i64 %v6283, ptr %slot880, align 8
  %v6284 = load i64, ptr %slot880, align 8
  %v6285 = load i64, ptr %slot879, align 8
  %p6286 = inttoptr i64 %v6284 to ptr
  %p6287 = inttoptr i64 %v6285 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p6287, ptr %p6286, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v6288 = load i64, ptr %slot29, align 8
  %p6289 = inttoptr i64 %v6288 to ptr
  store i32 2, ptr %p6289, align 4, !alias.scope !3, !noalias !4
  %v6290 = load i64, ptr %slot35, align 8
  %p6291 = inttoptr i64 %v6290 to ptr
  %ld6292 = load i32, ptr %p6291, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6292, ptr %slot881, align 8
  %v6293 = load i32, ptr %slot881, align 8
  %v6294 = load i64, ptr %slot29, align 8
  %p6295 = inttoptr i64 %v6294 to ptr
  store i32 %v6293, ptr %p6295, align 4, !alias.scope !3, !noalias !4
  %v6296 = load i64, ptr %slot34, align 8
  %p6297 = inttoptr i64 %v6296 to ptr
  store i32 0, ptr %p6297, align 4, !alias.scope !3, !noalias !4
  %v6298 = load i64, ptr %slot28, align 8
  %p6299 = inttoptr i64 %v6298 to ptr
  store i32 1, ptr %p6299, align 4, !alias.scope !3, !noalias !4
  %v6300 = load i64, ptr %slot879, align 8
  %v6301 = load i64, ptr %slot69, align 8
  %p6302 = inttoptr i64 %v6301 to ptr
  store i64 %v6300, ptr %p6302, align 8, !alias.scope !3, !noalias !4
  br label %bb_i158
bb_rctryok1056:
  %v6303 = load i64, ptr %slot85, align 8
  store i64 %v6303, ptr %slot882, align 8
  %v6304 = load i64, ptr %slot882, align 8
  %p6305 = inttoptr i64 %v6304 to ptr
  store i64 0, ptr %p6305, align 8, !alias.scope !3, !noalias !4
  %v6306 = load i64, ptr %slot36, align 8
  %p6307 = inttoptr i64 %v6306 to ptr
  store i32 1, ptr %p6307, align 4, !alias.scope !3, !noalias !4
  %v6308 = load i64, ptr %slot859, align 8
  %op6309 = add i64 %v6308, 8
  store i64 %op6309, ptr %slot883, align 8
  %v6310 = load i64, ptr %slot97, align 8
  store i64 %v6310, ptr %slot884, align 8
  %v6311 = load i64, ptr %slot883, align 8
  %p6312 = inttoptr i64 %v6311 to ptr
  %ld6313 = load i64, ptr %p6312, align 8
  store i64 %ld6313, ptr %slot885, align 8
  %v6314 = load i64, ptr %slot885, align 8
  %v6315 = load i64, ptr %slot882, align 8
  %p6316 = inttoptr i64 %v6315 to ptr
  store i64 %v6314, ptr %p6316, align 8, !alias.scope !3, !noalias !4
  %v6317 = load i64, ptr %slot882, align 8
  %p6318 = inttoptr i64 %v6317 to ptr
  %ld6319 = load i64, ptr %p6318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6319, ptr %slot886, align 8
  %v6320 = load i64, ptr %slot886, align 8
  %v6321 = load i64, ptr %slot69, align 8
  %p6322 = inttoptr i64 %v6321 to ptr
  store i64 %v6320, ptr %p6322, align 8, !alias.scope !3, !noalias !4
  %v6323 = load i64, ptr %slot28, align 8
  %p6324 = inttoptr i64 %v6323 to ptr
  %ld6325 = load i32, ptr %p6324, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6325, ptr %slot887, align 8
  %v6326 = load i32, ptr %slot887, align 8
  %cv6327 = zext i32 %v6326 to i64
  %cond6328 = icmp ne i64 %cv6327, 0
  br i1 %cond6328, label %bb_rcslotdrop1100, label %bb_rcslotdone1100
bb_rcslotdrop1100:
  %v6329 = load i64, ptr %slot28, align 8
  %p6330 = inttoptr i64 %v6329 to ptr
  store i32 0, ptr %p6330, align 4, !alias.scope !3, !noalias !4
  %v6331 = load i64, ptr %slot37, align 8
  store i64 %v6331, ptr %slot888, align 8
  %v6332 = load i64, ptr %slot29, align 8
  %p6333 = inttoptr i64 %v6332 to ptr
  %ld6334 = load i32, ptr %p6333, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6334, ptr %slot889, align 8
  %v6335 = load i32, ptr %slot889, align 8
  %op6336 = and i32 %v6335, 28
  store i32 %op6336, ptr %slot890, align 8
  %v6337 = load i32, ptr %slot890, align 8
  %cv6338 = zext i32 %v6337 to i64
  %cond6339 = icmp ne i64 %cv6338, 0
  br i1 %cond6339, label %bb_rcslotrole1100, label %bb_rcslotowner1100
bb_rcslotrole1100:
  %v6340 = load i64, ptr %slot96, align 8
  store i64 %v6340, ptr %slot891, align 8
  %v6341 = load i64, ptr %slot891, align 8
  %v6342 = load i64, ptr %slot888, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64 %v6341, i64 %v6342) nomerge, !dbg !192
  br label %bb_rcslotdone1100
bb_rcslotowner1100:
  %v6343 = load i64, ptr %slot96, align 8
  store i64 %v6343, ptr %slot892, align 8
  %v6344 = load i64, ptr %slot892, align 8
  %v6345 = load i64, ptr %slot888, align 8
  call void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64 %v6344, i64 %v6345) nomerge, !dbg !192
  br label %bb_rcslotdone1100
bb_rcslotdone1100:
  br label %bb_i159
bb_i158:
  %v6346 = load i64, ptr %slot69, align 8
  %p6347 = inttoptr i64 %v6346 to ptr
  %ld6348 = load i64, ptr %p6347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6348, ptr %slot893, align 8
  %v6349 = load i64, ptr %slot69, align 8
  %p6350 = inttoptr i64 %v6349 to ptr
  %ld6351 = load i64, ptr %p6350, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6351, ptr %slot894, align 8
  %v6352 = load i64, ptr %slot28, align 8
  %p6353 = inttoptr i64 %v6352 to ptr
  %ld6354 = load i32, ptr %p6353, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6354, ptr %slot895, align 8
  %v6355 = load i64, ptr %slot29, align 8
  %p6356 = inttoptr i64 %v6355 to ptr
  %ld6357 = load i32, ptr %p6356, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6357, ptr %slot896, align 8
  %v6358 = load i32, ptr %slot896, align 8
  %op6359 = and i32 %v6358, 24
  store i32 %op6359, ptr %slot896, align 8
  %v6360 = load i32, ptr %slot896, align 8
  %cmp6361 = icmp eq i32 %v6360, 0
  %cv6362 = zext i1 %cmp6361 to i32
  store i32 %cv6362, ptr %slot897, align 8
  %v6363 = load i32, ptr %slot895, align 8
  %v6364 = load i32, ptr %slot897, align 8
  %op6365 = and i32 %v6363, %v6364
  store i32 %op6365, ptr %slot898, align 8
  %v6366 = load i32, ptr %slot898, align 8
  %cv6367 = zext i32 %v6366 to i64
  %cond6368 = icmp ne i64 %cv6367, 0
  br i1 %cond6368, label %bb_rctake1109, label %bb_rccopy1109
bb_rctake1109:
  %v6369 = load i64, ptr %slot41, align 8
  store i64 %v6369, ptr %slot899, align 8
  %v6370 = load i64, ptr %slot97, align 8
  store i64 %v6370, ptr %slot900, align 8
  %v6371 = load i64, ptr %slot96, align 8
  %v6372 = load i64, ptr %slot899, align 8
  %v6373 = load i64, ptr %slot894, align 8
  %v6374 = load i64, ptr %slot900, align 8
  %cv6375 = trunc i64 %v6374 to i32
  %call6376 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v6371, i64 %v6372, i64 %v6373, i32 %cv6375) nomerge, !dbg !194
  store i32 %call6376, ptr %slot901, align 8
  %v6377 = load i32, ptr %slot901, align 8
  %cv6378 = zext i32 %v6377 to i64
  %cond6379 = icmp ne i64 %cv6378, 0
  br i1 %cond6379, label %bb_rcsuccess1119, label %bb_rcfailure1119
bb_rcfailure1119:
  %v6380 = load i64, ptr %slot96, align 8
  %p6381 = inttoptr i64 %v6380 to ptr
  %call6382 = call i32 @myl_rc_take_failure(ptr %p6381) nomerge, !dbg !194
  store i32 %call6382, ptr %slot902, align 8
  %v6383 = load i64, ptr %slot1, align 8
  %p6384 = inttoptr i64 %v6383 to ptr
  %v6385 = load i32, ptr %slot902, align 8
  %call6386 = call i32 @myl_qbe_rc_status(ptr %p6384, i32 %v6385) nomerge, !dbg !194
  store i32 %call6386, ptr %slot903, align 8
  br label %bb_failure
bb_rcsuccess1119:
  %v6387 = load i64, ptr %slot28, align 8
  %p6388 = inttoptr i64 %v6387 to ptr
  store i32 0, ptr %p6388, align 4, !alias.scope !3, !noalias !4
  %v6389 = load i64, ptr %slot35, align 8
  %p6390 = inttoptr i64 %v6389 to ptr
  store i32 2, ptr %p6390, align 4, !alias.scope !3, !noalias !4
  %v6391 = load i64, ptr %slot34, align 8
  %p6392 = inttoptr i64 %v6391 to ptr
  store i32 1, ptr %p6392, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1109
bb_rccopy1109:
  %v6393 = load i64, ptr %slot41, align 8
  store i64 %v6393, ptr %slot904, align 8
  %v6394 = load i64, ptr %slot97, align 8
  store i64 %v6394, ptr %slot905, align 8
  %v6395 = load i64, ptr %slot96, align 8
  %v6396 = load i64, ptr %slot904, align 8
  %v6397 = load i64, ptr %slot894, align 8
  %v6398 = load i64, ptr %slot905, align 8
  %cv6399 = trunc i64 %v6398 to i32
  %call6400 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v6395, i64 %v6396, i64 %v6397, i32 %cv6399) nomerge, !dbg !194
  store i32 %call6400, ptr %slot906, align 8
  %v6401 = load i32, ptr %slot906, align 8
  %cv6402 = zext i32 %v6401 to i64
  %cond6403 = icmp ne i64 %cv6402, 0
  br i1 %cond6403, label %bb_rcsuccess1128, label %bb_rcfailure1128
bb_rcfailure1128:
  %v6404 = load i64, ptr %slot96, align 8
  %p6405 = inttoptr i64 %v6404 to ptr
  %call6406 = call i32 @myl_rc_take_failure(ptr %p6405) nomerge, !dbg !194
  store i32 %call6406, ptr %slot907, align 8
  %v6407 = load i64, ptr %slot1, align 8
  %p6408 = inttoptr i64 %v6407 to ptr
  %v6409 = load i32, ptr %slot907, align 8
  %call6410 = call i32 @myl_qbe_rc_status(ptr %p6408, i32 %v6409) nomerge, !dbg !194
  store i32 %call6410, ptr %slot908, align 8
  br label %bb_failure
bb_rcsuccess1128:
  %v6411 = load i64, ptr %slot35, align 8
  %p6412 = inttoptr i64 %v6411 to ptr
  store i32 2, ptr %p6412, align 4, !alias.scope !3, !noalias !4
  %v6413 = load i64, ptr %slot34, align 8
  %p6414 = inttoptr i64 %v6413 to ptr
  store i32 1, ptr %p6414, align 4, !alias.scope !3, !noalias !4
  %v6415 = load i64, ptr %slot28, align 8
  %p6416 = inttoptr i64 %v6415 to ptr
  %ld6417 = load i32, ptr %p6416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6417, ptr %slot909, align 8
  %v6418 = load i32, ptr %slot909, align 8
  %cv6419 = zext i32 %v6418 to i64
  %cond6420 = icmp ne i64 %cv6419, 0
  br i1 %cond6420, label %bb_rcslotdrop1135, label %bb_rcslotdone1135
bb_rcslotdrop1135:
  %v6421 = load i64, ptr %slot28, align 8
  %p6422 = inttoptr i64 %v6421 to ptr
  store i32 0, ptr %p6422, align 4, !alias.scope !3, !noalias !4
  %v6423 = load i64, ptr %slot37, align 8
  store i64 %v6423, ptr %slot910, align 8
  %v6424 = load i64, ptr %slot29, align 8
  %p6425 = inttoptr i64 %v6424 to ptr
  %ld6426 = load i32, ptr %p6425, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6426, ptr %slot911, align 8
  %v6427 = load i32, ptr %slot911, align 8
  %op6428 = and i32 %v6427, 28
  store i32 %op6428, ptr %slot912, align 8
  %v6429 = load i32, ptr %slot912, align 8
  %cv6430 = zext i32 %v6429 to i64
  %cond6431 = icmp ne i64 %cv6430, 0
  br i1 %cond6431, label %bb_rcslotrole1135, label %bb_rcslotowner1135
bb_rcslotrole1135:
  %v6432 = load i64, ptr %slot96, align 8
  store i64 %v6432, ptr %slot913, align 8
  %v6433 = load i64, ptr %slot913, align 8
  %v6434 = load i64, ptr %slot910, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v6433, i64 %v6434) nomerge, !dbg !194
  br label %bb_rcslotdone1135
bb_rcslotowner1135:
  %v6435 = load i64, ptr %slot96, align 8
  store i64 %v6435, ptr %slot914, align 8
  %v6436 = load i64, ptr %slot914, align 8
  %v6437 = load i64, ptr %slot910, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v6436, i64 %v6437) nomerge, !dbg !194
  br label %bb_rcslotdone1135
bb_rcslotdone1135:
  br label %bb_rcprepared1109
bb_rcprepared1109:
  %v6438 = load i64, ptr %slot41, align 8
  store i64 %v6438, ptr %slot915, align 8
  %v6439 = load i64, ptr %slot34, align 8
  %p6440 = inttoptr i64 %v6439 to ptr
  store i32 0, ptr %p6440, align 4, !alias.scope !3, !noalias !4
  %v6441 = load i64, ptr %slot43, align 8
  %p6443 = inttoptr i64 %v6441 to ptr
  %gep6444 = getelementptr i8, ptr %p6443, i64 24
  %op6442 = ptrtoint ptr %gep6444 to i64
  store i64 %op6442, ptr %slot916, align 8
  %v6445 = load i64, ptr %slot916, align 8
  %p6446 = inttoptr i64 %v6445 to ptr
  %ld6447 = load i32, ptr %p6446, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6447, ptr %slot917, align 8
  %v6448 = load i32, ptr %slot917, align 8
  %cv6449 = zext i32 %v6448 to i64
  %cond6450 = icmp ne i64 %cv6449, 0
  br i1 %cond6450, label %bb_rcscopesopen1146, label %bb_rcscopesclosed1146
bb_rcscopesopen1146:
  %v6451 = load i64, ptr %slot45, align 8
  %p6453 = inttoptr i64 %v6451 to ptr
  %gep6454 = getelementptr i8, ptr %p6453, i64 0
  %op6452 = ptrtoint ptr %gep6454 to i64
  store i64 %op6452, ptr %slot918, align 8
  %v6455 = load i64, ptr %slot43, align 8
  %v6456 = load i64, ptr %slot918, align 8
  %p6457 = inttoptr i64 %v6456 to ptr
  store i64 %v6455, ptr %p6457, align 8, !alias.scope !3, !noalias !4
  %v6458 = load i64, ptr %slot1, align 8
  %p6459 = inttoptr i64 %v6458 to ptr
  %v6460 = load i64, ptr %slot45, align 8
  %p6461 = inttoptr i64 %v6460 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p6459, ptr %p6461, i64 1) nomerge, !dbg !194
  br label %bb_rcscopesclosed1146
bb_rcscopesclosed1146:
  %v6462 = load i64, ptr %slot28, align 8
  %p6463 = inttoptr i64 %v6462 to ptr
  %ld6464 = load i32, ptr %p6463, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6464, ptr %slot919, align 8
  %v6465 = load i32, ptr %slot919, align 8
  %cv6466 = zext i32 %v6465 to i64
  %cond6467 = icmp ne i64 %cv6466, 0
  br i1 %cond6467, label %bb_rcslotdrop1150, label %bb_rcslotdone1150
bb_rcslotdrop1150:
  %v6468 = load i64, ptr %slot28, align 8
  %p6469 = inttoptr i64 %v6468 to ptr
  store i32 0, ptr %p6469, align 4, !alias.scope !3, !noalias !4
  %v6470 = load i64, ptr %slot37, align 8
  store i64 %v6470, ptr %slot920, align 8
  %v6471 = load i64, ptr %slot29, align 8
  %p6472 = inttoptr i64 %v6471 to ptr
  %ld6473 = load i32, ptr %p6472, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6473, ptr %slot921, align 8
  %v6474 = load i32, ptr %slot921, align 8
  %op6475 = and i32 %v6474, 28
  store i32 %op6475, ptr %slot922, align 8
  %v6476 = load i32, ptr %slot922, align 8
  %cv6477 = zext i32 %v6476 to i64
  %cond6478 = icmp ne i64 %cv6477, 0
  br i1 %cond6478, label %bb_rcslotrole1150, label %bb_rcslotowner1150
bb_rcslotrole1150:
  %v6479 = load i64, ptr %slot96, align 8
  store i64 %v6479, ptr %slot923, align 8
  %v6480 = load i64, ptr %slot923, align 8
  %v6481 = load i64, ptr %slot920, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v6480, i64 %v6481) nomerge, !dbg !194
  br label %bb_rcslotdone1150
bb_rcslotowner1150:
  %v6482 = load i64, ptr %slot96, align 8
  store i64 %v6482, ptr %slot924, align 8
  %v6483 = load i64, ptr %slot924, align 8
  %v6484 = load i64, ptr %slot920, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v6483, i64 %v6484) nomerge, !dbg !194
  br label %bb_rcslotdone1150
bb_rcslotdone1150:
  %v6485 = load i64, ptr %slot26, align 8
  %p6486 = inttoptr i64 %v6485 to ptr
  %ld6487 = load i32, ptr %p6486, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6487, ptr %slot925, align 8
  %v6488 = load i32, ptr %slot925, align 8
  %cv6489 = zext i32 %v6488 to i64
  %cond6490 = icmp ne i64 %cv6489, 0
  br i1 %cond6490, label %bb_rcslotdrop1177, label %bb_rcslotdone1177
bb_rcslotdrop1177:
  %v6491 = load i64, ptr %slot26, align 8
  %p6492 = inttoptr i64 %v6491 to ptr
  store i32 0, ptr %p6492, align 4, !alias.scope !3, !noalias !4
  %v6493 = load i64, ptr %slot68, align 8
  store i64 %v6493, ptr %slot926, align 8
  %v6494 = load i64, ptr %slot27, align 8
  %p6495 = inttoptr i64 %v6494 to ptr
  %ld6496 = load i32, ptr %p6495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6496, ptr %slot927, align 8
  %v6497 = load i32, ptr %slot927, align 8
  %op6498 = and i32 %v6497, 28
  store i32 %op6498, ptr %slot928, align 8
  %v6499 = load i32, ptr %slot928, align 8
  %cv6500 = zext i32 %v6499 to i64
  %cond6501 = icmp ne i64 %cv6500, 0
  br i1 %cond6501, label %bb_rcslotrole1177, label %bb_rcslotowner1177
bb_rcslotrole1177:
  %v6502 = load i64, ptr %slot96, align 8
  store i64 %v6502, ptr %slot929, align 8
  %v6503 = load i64, ptr %slot929, align 8
  %v6504 = load i64, ptr %slot926, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6503, i64 %v6504) nomerge, !dbg !194
  br label %bb_rcslotdone1177
bb_rcslotowner1177:
  %v6505 = load i64, ptr %slot96, align 8
  store i64 %v6505, ptr %slot930, align 8
  %v6506 = load i64, ptr %slot930, align 8
  %v6507 = load i64, ptr %slot926, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6506, i64 %v6507) nomerge, !dbg !194
  br label %bb_rcslotdone1177
bb_rcslotdone1177:
  %v6508 = load i64, ptr %slot24, align 8
  %p6509 = inttoptr i64 %v6508 to ptr
  %ld6510 = load i32, ptr %p6509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6510, ptr %slot931, align 8
  %v6511 = load i32, ptr %slot931, align 8
  %cv6512 = zext i32 %v6511 to i64
  %cond6513 = icmp ne i64 %cv6512, 0
  br i1 %cond6513, label %bb_rcslotdrop1186, label %bb_rcslotdone1186
bb_rcslotdrop1186:
  %v6514 = load i64, ptr %slot24, align 8
  %p6515 = inttoptr i64 %v6514 to ptr
  store i32 0, ptr %p6515, align 4, !alias.scope !3, !noalias !4
  %v6516 = load i64, ptr %slot67, align 8
  store i64 %v6516, ptr %slot932, align 8
  %v6517 = load i64, ptr %slot25, align 8
  %p6518 = inttoptr i64 %v6517 to ptr
  %ld6519 = load i32, ptr %p6518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6519, ptr %slot933, align 8
  %v6520 = load i32, ptr %slot933, align 8
  %op6521 = and i32 %v6520, 28
  store i32 %op6521, ptr %slot934, align 8
  %v6522 = load i32, ptr %slot934, align 8
  %cv6523 = zext i32 %v6522 to i64
  %cond6524 = icmp ne i64 %cv6523, 0
  br i1 %cond6524, label %bb_rcslotrole1186, label %bb_rcslotowner1186
bb_rcslotrole1186:
  %v6525 = load i64, ptr %slot96, align 8
  store i64 %v6525, ptr %slot935, align 8
  %v6526 = load i64, ptr %slot932, align 8
  %p6527 = inttoptr i64 %v6526 to ptr
  %ld6528 = load i64, ptr %p6527, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6528, ptr %slot936, align 8
  %v6529 = load i64, ptr %slot936, align 8
  %cmp6530 = icmp ne i64 %v6529, 0
  %cv6531 = zext i1 %cmp6530 to i32
  store i32 %cv6531, ptr %slot937, align 8
  %v6532 = load i32, ptr %slot937, align 8
  %cv6533 = zext i32 %v6532 to i64
  %cond6534 = icmp ne i64 %cv6533, 0
  br i1 %cond6534, label %bb_rcgnn1202, label %bb_rcgdone1202
bb_rcgnn1202:
  %v6535 = load i64, ptr %slot936, align 8
  %op6536 = sub i64 %v6535, 16
  store i64 %op6536, ptr %slot938, align 8
  %v6537 = load i64, ptr %slot936, align 8
  %p6538 = inttoptr i64 %v6537 to ptr
  %rgep6539 = getelementptr i8, ptr %p6538, i64 -16
  %ld6540 = load i64, ptr %rgep6539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6540, ptr %slot939, align 8
  %v6541 = load i64, ptr %slot939, align 8
  %op6542 = and i64 %v6541, 4611686018427387906
  store i64 %op6542, ptr %slot940, align 8
  %v6543 = load i64, ptr %slot940, align 8
  %cmp6544 = icmp ne i64 %v6543, 0
  %cv6545 = zext i1 %cmp6544 to i32
  store i32 %cv6545, ptr %slot941, align 8
  %v6546 = load i32, ptr %slot941, align 8
  %cv6547 = zext i32 %v6546 to i64
  %cond6548 = icmp ne i64 %cv6547, 0
  br i1 %cond6548, label %bb_rcgclear1202, label %bb_rcgcounted1202
bb_rcgcounted1202:
  %v6549 = load i64, ptr %slot936, align 8
  %op6550 = sub i64 %v6549, 24
  store i64 %op6550, ptr %slot942, align 8
  %v6551 = load i64, ptr %slot936, align 8
  %p6552 = inttoptr i64 %v6551 to ptr
  %rgep6553 = getelementptr i8, ptr %p6552, i64 -24
  %ld6554 = load i64, ptr %rgep6553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6554, ptr %slot943, align 8
  %v6555 = load i64, ptr %slot943, align 8
  %op6556 = sub i64 %v6555, 1
  store i64 %op6556, ptr %slot944, align 8
  %v6557 = load i64, ptr %slot944, align 8
  %cmp6558 = icmp eq i64 %v6557, 0
  %cv6559 = zext i1 %cmp6558 to i32
  store i32 %cv6559, ptr %slot945, align 8
  %v6560 = load i32, ptr %slot945, align 8
  %cv6561 = zext i32 %v6560 to i64
  %cond6562 = icmp ne i64 %cv6561, 0
  br i1 %cond6562, label %bb_rcglast1202, label %bb_rcgdec1202
bb_rcglast1202:
  %v6563 = load i64, ptr %slot936, align 8
  %op6564 = sub i64 %v6563, 32
  store i64 %op6564, ptr %slot946, align 8
  %v6565 = load i64, ptr %slot936, align 8
  %p6566 = inttoptr i64 %v6565 to ptr
  %rgep6567 = getelementptr i8, ptr %p6566, i64 -32
  %ld6568 = load i64, ptr %rgep6567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6568, ptr %slot947, align 8
  %v6569 = load i64, ptr %slot947, align 8
  %cmp6570 = icmp ne i64 %v6569, 0
  %cv6571 = zext i1 %cmp6570 to i32
  store i32 %cv6571, ptr %slot948, align 8
  %v6572 = load i32, ptr %slot948, align 8
  %cv6573 = zext i32 %v6572 to i64
  %cond6574 = icmp ne i64 %cv6573, 0
  br i1 %cond6574, label %bb_rcgdec1202, label %bb_rcgslow1202
bb_rcgslow1202:
  %v6575 = load i64, ptr %slot935, align 8
  %v6576 = load i64, ptr %slot932, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v6575, i64 %v6576) nomerge, !dbg !194
  br label %bb_rcgdone1202
bb_rcgdec1202:
  %v6577 = load i64, ptr %slot944, align 8
  %v6578 = load i64, ptr %slot936, align 8
  %p6579 = inttoptr i64 %v6578 to ptr
  %rgep6580 = getelementptr i8, ptr %p6579, i64 -24
  store i64 %v6577, ptr %rgep6580, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1202
bb_rcgclear1202:
  %v6581 = load i64, ptr %slot932, align 8
  %p6582 = inttoptr i64 %v6581 to ptr
  store i64 0, ptr %p6582, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1202
bb_rcgdone1202:
  br label %bb_rcslotdone1186
bb_rcslotowner1186:
  %v6583 = load i64, ptr %slot96, align 8
  store i64 %v6583, ptr %slot949, align 8
  %v6584 = load i64, ptr %slot932, align 8
  %p6585 = inttoptr i64 %v6584 to ptr
  %ld6586 = load i64, ptr %p6585, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6586, ptr %slot950, align 8
  %v6587 = load i64, ptr %slot950, align 8
  %cmp6588 = icmp ne i64 %v6587, 0
  %cv6589 = zext i1 %cmp6588 to i32
  store i32 %cv6589, ptr %slot951, align 8
  %v6590 = load i32, ptr %slot951, align 8
  %cv6591 = zext i32 %v6590 to i64
  %cond6592 = icmp ne i64 %cv6591, 0
  br i1 %cond6592, label %bb_rcgnn1217, label %bb_rcgdone1217
bb_rcgnn1217:
  %v6593 = load i64, ptr %slot950, align 8
  %op6594 = sub i64 %v6593, 16
  store i64 %op6594, ptr %slot952, align 8
  %v6595 = load i64, ptr %slot950, align 8
  %p6596 = inttoptr i64 %v6595 to ptr
  %rgep6597 = getelementptr i8, ptr %p6596, i64 -16
  %ld6598 = load i64, ptr %rgep6597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6598, ptr %slot953, align 8
  %v6599 = load i64, ptr %slot953, align 8
  %op6600 = and i64 %v6599, 4611686018427387906
  store i64 %op6600, ptr %slot954, align 8
  %v6601 = load i64, ptr %slot954, align 8
  %cmp6602 = icmp ne i64 %v6601, 0
  %cv6603 = zext i1 %cmp6602 to i32
  store i32 %cv6603, ptr %slot955, align 8
  %v6604 = load i32, ptr %slot955, align 8
  %cv6605 = zext i32 %v6604 to i64
  %cond6606 = icmp ne i64 %cv6605, 0
  br i1 %cond6606, label %bb_rcgclear1217, label %bb_rcgcounted1217
bb_rcgcounted1217:
  %v6607 = load i64, ptr %slot950, align 8
  %op6608 = sub i64 %v6607, 32
  store i64 %op6608, ptr %slot956, align 8
  %v6609 = load i64, ptr %slot950, align 8
  %p6610 = inttoptr i64 %v6609 to ptr
  %rgep6611 = getelementptr i8, ptr %p6610, i64 -32
  %ld6612 = load i64, ptr %rgep6611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6612, ptr %slot957, align 8
  %v6613 = load i64, ptr %slot957, align 8
  %op6614 = sub i64 %v6613, 1
  store i64 %op6614, ptr %slot958, align 8
  %v6615 = load i64, ptr %slot958, align 8
  %cmp6616 = icmp eq i64 %v6615, 0
  %cv6617 = zext i1 %cmp6616 to i32
  store i32 %cv6617, ptr %slot959, align 8
  %v6618 = load i32, ptr %slot959, align 8
  %cv6619 = zext i32 %v6618 to i64
  %cond6620 = icmp ne i64 %cv6619, 0
  br i1 %cond6620, label %bb_rcglast1217, label %bb_rcgdec1217
bb_rcglast1217:
  %v6621 = load i64, ptr %slot950, align 8
  %op6622 = sub i64 %v6621, 24
  store i64 %op6622, ptr %slot960, align 8
  %v6623 = load i64, ptr %slot950, align 8
  %p6624 = inttoptr i64 %v6623 to ptr
  %rgep6625 = getelementptr i8, ptr %p6624, i64 -24
  %ld6626 = load i64, ptr %rgep6625, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6626, ptr %slot961, align 8
  %v6627 = load i64, ptr %slot961, align 8
  %cmp6628 = icmp ne i64 %v6627, 0
  %cv6629 = zext i1 %cmp6628 to i32
  store i32 %cv6629, ptr %slot962, align 8
  %v6630 = load i32, ptr %slot962, align 8
  %cv6631 = zext i32 %v6630 to i64
  %cond6632 = icmp ne i64 %cv6631, 0
  br i1 %cond6632, label %bb_rcgdec1217, label %bb_rcgslow1217
bb_rcgslow1217:
  %v6633 = load i64, ptr %slot949, align 8
  %v6634 = load i64, ptr %slot932, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v6633, i64 %v6634) nomerge, !dbg !194
  br label %bb_rcgdone1217
bb_rcgdec1217:
  %v6635 = load i64, ptr %slot958, align 8
  %v6636 = load i64, ptr %slot950, align 8
  %p6637 = inttoptr i64 %v6636 to ptr
  %rgep6638 = getelementptr i8, ptr %p6637, i64 -32
  store i64 %v6635, ptr %rgep6638, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1217
bb_rcgclear1217:
  %v6639 = load i64, ptr %slot932, align 8
  %p6640 = inttoptr i64 %v6639 to ptr
  store i64 0, ptr %p6640, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1217
bb_rcgdone1217:
  br label %bb_rcslotdone1186
bb_rcslotdone1186:
  %v6641 = load i64, ptr %slot22, align 8
  %p6642 = inttoptr i64 %v6641 to ptr
  %ld6643 = load i32, ptr %p6642, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6643, ptr %slot963, align 8
  %v6644 = load i32, ptr %slot963, align 8
  %cv6645 = zext i32 %v6644 to i64
  %cond6646 = icmp ne i64 %cv6645, 0
  br i1 %cond6646, label %bb_rcslotdrop1223, label %bb_rcslotdone1223
bb_rcslotdrop1223:
  %v6647 = load i64, ptr %slot22, align 8
  %p6648 = inttoptr i64 %v6647 to ptr
  store i32 0, ptr %p6648, align 4, !alias.scope !3, !noalias !4
  %v6649 = load i64, ptr %slot66, align 8
  store i64 %v6649, ptr %slot964, align 8
  %v6650 = load i64, ptr %slot23, align 8
  %p6651 = inttoptr i64 %v6650 to ptr
  %ld6652 = load i32, ptr %p6651, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6652, ptr %slot965, align 8
  %v6653 = load i32, ptr %slot965, align 8
  %op6654 = and i32 %v6653, 28
  store i32 %op6654, ptr %slot966, align 8
  %v6655 = load i32, ptr %slot966, align 8
  %cv6656 = zext i32 %v6655 to i64
  %cond6657 = icmp ne i64 %cv6656, 0
  br i1 %cond6657, label %bb_rcslotrole1223, label %bb_rcslotowner1223
bb_rcslotrole1223:
  %v6658 = load i64, ptr %slot96, align 8
  store i64 %v6658, ptr %slot967, align 8
  %v6659 = load i64, ptr %slot964, align 8
  %p6660 = inttoptr i64 %v6659 to ptr
  %ld6661 = load i64, ptr %p6660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6661, ptr %slot968, align 8
  %v6662 = load i64, ptr %slot968, align 8
  %cmp6663 = icmp ne i64 %v6662, 0
  %cv6664 = zext i1 %cmp6663 to i32
  store i32 %cv6664, ptr %slot969, align 8
  %v6665 = load i32, ptr %slot969, align 8
  %cv6666 = zext i32 %v6665 to i64
  %cond6667 = icmp ne i64 %cv6666, 0
  br i1 %cond6667, label %bb_rcgnn1239, label %bb_rcgdone1239
bb_rcgnn1239:
  %v6668 = load i64, ptr %slot968, align 8
  %op6669 = sub i64 %v6668, 16
  store i64 %op6669, ptr %slot970, align 8
  %v6670 = load i64, ptr %slot968, align 8
  %p6671 = inttoptr i64 %v6670 to ptr
  %rgep6672 = getelementptr i8, ptr %p6671, i64 -16
  %ld6673 = load i64, ptr %rgep6672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6673, ptr %slot971, align 8
  %v6674 = load i64, ptr %slot971, align 8
  %op6675 = and i64 %v6674, 4611686018427387906
  store i64 %op6675, ptr %slot972, align 8
  %v6676 = load i64, ptr %slot972, align 8
  %cmp6677 = icmp ne i64 %v6676, 0
  %cv6678 = zext i1 %cmp6677 to i32
  store i32 %cv6678, ptr %slot973, align 8
  %v6679 = load i32, ptr %slot973, align 8
  %cv6680 = zext i32 %v6679 to i64
  %cond6681 = icmp ne i64 %cv6680, 0
  br i1 %cond6681, label %bb_rcgclear1239, label %bb_rcgcounted1239
bb_rcgcounted1239:
  %v6682 = load i64, ptr %slot968, align 8
  %op6683 = sub i64 %v6682, 24
  store i64 %op6683, ptr %slot974, align 8
  %v6684 = load i64, ptr %slot968, align 8
  %p6685 = inttoptr i64 %v6684 to ptr
  %rgep6686 = getelementptr i8, ptr %p6685, i64 -24
  %ld6687 = load i64, ptr %rgep6686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6687, ptr %slot975, align 8
  %v6688 = load i64, ptr %slot975, align 8
  %op6689 = sub i64 %v6688, 1
  store i64 %op6689, ptr %slot976, align 8
  %v6690 = load i64, ptr %slot976, align 8
  %cmp6691 = icmp eq i64 %v6690, 0
  %cv6692 = zext i1 %cmp6691 to i32
  store i32 %cv6692, ptr %slot977, align 8
  %v6693 = load i32, ptr %slot977, align 8
  %cv6694 = zext i32 %v6693 to i64
  %cond6695 = icmp ne i64 %cv6694, 0
  br i1 %cond6695, label %bb_rcglast1239, label %bb_rcgdec1239
bb_rcglast1239:
  %v6696 = load i64, ptr %slot968, align 8
  %op6697 = sub i64 %v6696, 32
  store i64 %op6697, ptr %slot978, align 8
  %v6698 = load i64, ptr %slot968, align 8
  %p6699 = inttoptr i64 %v6698 to ptr
  %rgep6700 = getelementptr i8, ptr %p6699, i64 -32
  %ld6701 = load i64, ptr %rgep6700, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6701, ptr %slot979, align 8
  %v6702 = load i64, ptr %slot979, align 8
  %cmp6703 = icmp ne i64 %v6702, 0
  %cv6704 = zext i1 %cmp6703 to i32
  store i32 %cv6704, ptr %slot980, align 8
  %v6705 = load i32, ptr %slot980, align 8
  %cv6706 = zext i32 %v6705 to i64
  %cond6707 = icmp ne i64 %cv6706, 0
  br i1 %cond6707, label %bb_rcgdec1239, label %bb_rcgslow1239
bb_rcgslow1239:
  %v6708 = load i64, ptr %slot967, align 8
  %v6709 = load i64, ptr %slot964, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v6708, i64 %v6709) nomerge, !dbg !194
  br label %bb_rcgdone1239
bb_rcgdec1239:
  %v6710 = load i64, ptr %slot976, align 8
  %v6711 = load i64, ptr %slot968, align 8
  %p6712 = inttoptr i64 %v6711 to ptr
  %rgep6713 = getelementptr i8, ptr %p6712, i64 -24
  store i64 %v6710, ptr %rgep6713, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1239
bb_rcgclear1239:
  %v6714 = load i64, ptr %slot964, align 8
  %p6715 = inttoptr i64 %v6714 to ptr
  store i64 0, ptr %p6715, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1239
bb_rcgdone1239:
  br label %bb_rcslotdone1223
bb_rcslotowner1223:
  %v6716 = load i64, ptr %slot96, align 8
  store i64 %v6716, ptr %slot981, align 8
  %v6717 = load i64, ptr %slot964, align 8
  %p6718 = inttoptr i64 %v6717 to ptr
  %ld6719 = load i64, ptr %p6718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6719, ptr %slot982, align 8
  %v6720 = load i64, ptr %slot982, align 8
  %cmp6721 = icmp ne i64 %v6720, 0
  %cv6722 = zext i1 %cmp6721 to i32
  store i32 %cv6722, ptr %slot983, align 8
  %v6723 = load i32, ptr %slot983, align 8
  %cv6724 = zext i32 %v6723 to i64
  %cond6725 = icmp ne i64 %cv6724, 0
  br i1 %cond6725, label %bb_rcgnn1254, label %bb_rcgdone1254
bb_rcgnn1254:
  %v6726 = load i64, ptr %slot982, align 8
  %op6727 = sub i64 %v6726, 16
  store i64 %op6727, ptr %slot984, align 8
  %v6728 = load i64, ptr %slot982, align 8
  %p6729 = inttoptr i64 %v6728 to ptr
  %rgep6730 = getelementptr i8, ptr %p6729, i64 -16
  %ld6731 = load i64, ptr %rgep6730, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6731, ptr %slot985, align 8
  %v6732 = load i64, ptr %slot985, align 8
  %op6733 = and i64 %v6732, 4611686018427387906
  store i64 %op6733, ptr %slot986, align 8
  %v6734 = load i64, ptr %slot986, align 8
  %cmp6735 = icmp ne i64 %v6734, 0
  %cv6736 = zext i1 %cmp6735 to i32
  store i32 %cv6736, ptr %slot987, align 8
  %v6737 = load i32, ptr %slot987, align 8
  %cv6738 = zext i32 %v6737 to i64
  %cond6739 = icmp ne i64 %cv6738, 0
  br i1 %cond6739, label %bb_rcgclear1254, label %bb_rcgcounted1254
bb_rcgcounted1254:
  %v6740 = load i64, ptr %slot982, align 8
  %op6741 = sub i64 %v6740, 32
  store i64 %op6741, ptr %slot988, align 8
  %v6742 = load i64, ptr %slot982, align 8
  %p6743 = inttoptr i64 %v6742 to ptr
  %rgep6744 = getelementptr i8, ptr %p6743, i64 -32
  %ld6745 = load i64, ptr %rgep6744, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6745, ptr %slot989, align 8
  %v6746 = load i64, ptr %slot989, align 8
  %op6747 = sub i64 %v6746, 1
  store i64 %op6747, ptr %slot990, align 8
  %v6748 = load i64, ptr %slot990, align 8
  %cmp6749 = icmp eq i64 %v6748, 0
  %cv6750 = zext i1 %cmp6749 to i32
  store i32 %cv6750, ptr %slot991, align 8
  %v6751 = load i32, ptr %slot991, align 8
  %cv6752 = zext i32 %v6751 to i64
  %cond6753 = icmp ne i64 %cv6752, 0
  br i1 %cond6753, label %bb_rcglast1254, label %bb_rcgdec1254
bb_rcglast1254:
  %v6754 = load i64, ptr %slot982, align 8
  %op6755 = sub i64 %v6754, 24
  store i64 %op6755, ptr %slot992, align 8
  %v6756 = load i64, ptr %slot982, align 8
  %p6757 = inttoptr i64 %v6756 to ptr
  %rgep6758 = getelementptr i8, ptr %p6757, i64 -24
  %ld6759 = load i64, ptr %rgep6758, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6759, ptr %slot993, align 8
  %v6760 = load i64, ptr %slot993, align 8
  %cmp6761 = icmp ne i64 %v6760, 0
  %cv6762 = zext i1 %cmp6761 to i32
  store i32 %cv6762, ptr %slot994, align 8
  %v6763 = load i32, ptr %slot994, align 8
  %cv6764 = zext i32 %v6763 to i64
  %cond6765 = icmp ne i64 %cv6764, 0
  br i1 %cond6765, label %bb_rcgdec1254, label %bb_rcgslow1254
bb_rcgslow1254:
  %v6766 = load i64, ptr %slot981, align 8
  %v6767 = load i64, ptr %slot964, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v6766, i64 %v6767) nomerge, !dbg !194
  br label %bb_rcgdone1254
bb_rcgdec1254:
  %v6768 = load i64, ptr %slot990, align 8
  %v6769 = load i64, ptr %slot982, align 8
  %p6770 = inttoptr i64 %v6769 to ptr
  %rgep6771 = getelementptr i8, ptr %p6770, i64 -32
  store i64 %v6768, ptr %rgep6771, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1254
bb_rcgclear1254:
  %v6772 = load i64, ptr %slot964, align 8
  %p6773 = inttoptr i64 %v6772 to ptr
  store i64 0, ptr %p6773, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1254
bb_rcgdone1254:
  br label %bb_rcslotdone1223
bb_rcslotdone1223:
  %v6774 = load i64, ptr %slot20, align 8
  %p6775 = inttoptr i64 %v6774 to ptr
  %ld6776 = load i32, ptr %p6775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6776, ptr %slot995, align 8
  %v6777 = load i32, ptr %slot995, align 8
  %cv6778 = zext i32 %v6777 to i64
  %cond6779 = icmp ne i64 %cv6778, 0
  br i1 %cond6779, label %bb_rcslotdrop1260, label %bb_rcslotdone1260
bb_rcslotdrop1260:
  %v6780 = load i64, ptr %slot20, align 8
  %p6781 = inttoptr i64 %v6780 to ptr
  store i32 0, ptr %p6781, align 4, !alias.scope !3, !noalias !4
  %v6782 = load i64, ptr %slot65, align 8
  store i64 %v6782, ptr %slot996, align 8
  %v6783 = load i64, ptr %slot21, align 8
  %p6784 = inttoptr i64 %v6783 to ptr
  %ld6785 = load i32, ptr %p6784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6785, ptr %slot997, align 8
  %v6786 = load i32, ptr %slot997, align 8
  %op6787 = and i32 %v6786, 28
  store i32 %op6787, ptr %slot998, align 8
  %v6788 = load i32, ptr %slot998, align 8
  %cv6789 = zext i32 %v6788 to i64
  %cond6790 = icmp ne i64 %cv6789, 0
  br i1 %cond6790, label %bb_rcslotrole1260, label %bb_rcslotowner1260
bb_rcslotrole1260:
  %v6791 = load i64, ptr %slot96, align 8
  store i64 %v6791, ptr %slot999, align 8
  %v6792 = load i64, ptr %slot996, align 8
  %p6793 = inttoptr i64 %v6792 to ptr
  %ld6794 = load i64, ptr %p6793, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6794, ptr %slot1000, align 8
  %v6795 = load i64, ptr %slot1000, align 8
  %cmp6796 = icmp ne i64 %v6795, 0
  %cv6797 = zext i1 %cmp6796 to i32
  store i32 %cv6797, ptr %slot1001, align 8
  %v6798 = load i32, ptr %slot1001, align 8
  %cv6799 = zext i32 %v6798 to i64
  %cond6800 = icmp ne i64 %cv6799, 0
  br i1 %cond6800, label %bb_rcgnn1276, label %bb_rcgdone1276
bb_rcgnn1276:
  %v6801 = load i64, ptr %slot1000, align 8
  %op6802 = sub i64 %v6801, 16
  store i64 %op6802, ptr %slot1002, align 8
  %v6803 = load i64, ptr %slot1000, align 8
  %p6804 = inttoptr i64 %v6803 to ptr
  %rgep6805 = getelementptr i8, ptr %p6804, i64 -16
  %ld6806 = load i64, ptr %rgep6805, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6806, ptr %slot1003, align 8
  %v6807 = load i64, ptr %slot1003, align 8
  %op6808 = and i64 %v6807, 4611686018427387906
  store i64 %op6808, ptr %slot1004, align 8
  %v6809 = load i64, ptr %slot1004, align 8
  %cmp6810 = icmp ne i64 %v6809, 0
  %cv6811 = zext i1 %cmp6810 to i32
  store i32 %cv6811, ptr %slot1005, align 8
  %v6812 = load i32, ptr %slot1005, align 8
  %cv6813 = zext i32 %v6812 to i64
  %cond6814 = icmp ne i64 %cv6813, 0
  br i1 %cond6814, label %bb_rcgclear1276, label %bb_rcgcounted1276
bb_rcgcounted1276:
  %v6815 = load i64, ptr %slot1000, align 8
  %op6816 = sub i64 %v6815, 24
  store i64 %op6816, ptr %slot1006, align 8
  %v6817 = load i64, ptr %slot1000, align 8
  %p6818 = inttoptr i64 %v6817 to ptr
  %rgep6819 = getelementptr i8, ptr %p6818, i64 -24
  %ld6820 = load i64, ptr %rgep6819, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6820, ptr %slot1007, align 8
  %v6821 = load i64, ptr %slot1007, align 8
  %op6822 = sub i64 %v6821, 1
  store i64 %op6822, ptr %slot1008, align 8
  %v6823 = load i64, ptr %slot1008, align 8
  %cmp6824 = icmp eq i64 %v6823, 0
  %cv6825 = zext i1 %cmp6824 to i32
  store i32 %cv6825, ptr %slot1009, align 8
  %v6826 = load i32, ptr %slot1009, align 8
  %cv6827 = zext i32 %v6826 to i64
  %cond6828 = icmp ne i64 %cv6827, 0
  br i1 %cond6828, label %bb_rcglast1276, label %bb_rcgdec1276
bb_rcglast1276:
  %v6829 = load i64, ptr %slot1000, align 8
  %op6830 = sub i64 %v6829, 32
  store i64 %op6830, ptr %slot1010, align 8
  %v6831 = load i64, ptr %slot1000, align 8
  %p6832 = inttoptr i64 %v6831 to ptr
  %rgep6833 = getelementptr i8, ptr %p6832, i64 -32
  %ld6834 = load i64, ptr %rgep6833, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6834, ptr %slot1011, align 8
  %v6835 = load i64, ptr %slot1011, align 8
  %cmp6836 = icmp ne i64 %v6835, 0
  %cv6837 = zext i1 %cmp6836 to i32
  store i32 %cv6837, ptr %slot1012, align 8
  %v6838 = load i32, ptr %slot1012, align 8
  %cv6839 = zext i32 %v6838 to i64
  %cond6840 = icmp ne i64 %cv6839, 0
  br i1 %cond6840, label %bb_rcgdec1276, label %bb_rcgslow1276
bb_rcgslow1276:
  %v6841 = load i64, ptr %slot999, align 8
  %v6842 = load i64, ptr %slot996, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v6841, i64 %v6842) nomerge, !dbg !194
  br label %bb_rcgdone1276
bb_rcgdec1276:
  %v6843 = load i64, ptr %slot1008, align 8
  %v6844 = load i64, ptr %slot1000, align 8
  %p6845 = inttoptr i64 %v6844 to ptr
  %rgep6846 = getelementptr i8, ptr %p6845, i64 -24
  store i64 %v6843, ptr %rgep6846, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1276
bb_rcgclear1276:
  %v6847 = load i64, ptr %slot996, align 8
  %p6848 = inttoptr i64 %v6847 to ptr
  store i64 0, ptr %p6848, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1276
bb_rcgdone1276:
  br label %bb_rcslotdone1260
bb_rcslotowner1260:
  %v6849 = load i64, ptr %slot96, align 8
  store i64 %v6849, ptr %slot1013, align 8
  %v6850 = load i64, ptr %slot996, align 8
  %p6851 = inttoptr i64 %v6850 to ptr
  %ld6852 = load i64, ptr %p6851, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6852, ptr %slot1014, align 8
  %v6853 = load i64, ptr %slot1014, align 8
  %cmp6854 = icmp ne i64 %v6853, 0
  %cv6855 = zext i1 %cmp6854 to i32
  store i32 %cv6855, ptr %slot1015, align 8
  %v6856 = load i32, ptr %slot1015, align 8
  %cv6857 = zext i32 %v6856 to i64
  %cond6858 = icmp ne i64 %cv6857, 0
  br i1 %cond6858, label %bb_rcgnn1291, label %bb_rcgdone1291
bb_rcgnn1291:
  %v6859 = load i64, ptr %slot1014, align 8
  %op6860 = sub i64 %v6859, 16
  store i64 %op6860, ptr %slot1016, align 8
  %v6861 = load i64, ptr %slot1014, align 8
  %p6862 = inttoptr i64 %v6861 to ptr
  %rgep6863 = getelementptr i8, ptr %p6862, i64 -16
  %ld6864 = load i64, ptr %rgep6863, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6864, ptr %slot1017, align 8
  %v6865 = load i64, ptr %slot1017, align 8
  %op6866 = and i64 %v6865, 4611686018427387906
  store i64 %op6866, ptr %slot1018, align 8
  %v6867 = load i64, ptr %slot1018, align 8
  %cmp6868 = icmp ne i64 %v6867, 0
  %cv6869 = zext i1 %cmp6868 to i32
  store i32 %cv6869, ptr %slot1019, align 8
  %v6870 = load i32, ptr %slot1019, align 8
  %cv6871 = zext i32 %v6870 to i64
  %cond6872 = icmp ne i64 %cv6871, 0
  br i1 %cond6872, label %bb_rcgclear1291, label %bb_rcgcounted1291
bb_rcgcounted1291:
  %v6873 = load i64, ptr %slot1014, align 8
  %op6874 = sub i64 %v6873, 32
  store i64 %op6874, ptr %slot1020, align 8
  %v6875 = load i64, ptr %slot1014, align 8
  %p6876 = inttoptr i64 %v6875 to ptr
  %rgep6877 = getelementptr i8, ptr %p6876, i64 -32
  %ld6878 = load i64, ptr %rgep6877, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6878, ptr %slot1021, align 8
  %v6879 = load i64, ptr %slot1021, align 8
  %op6880 = sub i64 %v6879, 1
  store i64 %op6880, ptr %slot1022, align 8
  %v6881 = load i64, ptr %slot1022, align 8
  %cmp6882 = icmp eq i64 %v6881, 0
  %cv6883 = zext i1 %cmp6882 to i32
  store i32 %cv6883, ptr %slot1023, align 8
  %v6884 = load i32, ptr %slot1023, align 8
  %cv6885 = zext i32 %v6884 to i64
  %cond6886 = icmp ne i64 %cv6885, 0
  br i1 %cond6886, label %bb_rcglast1291, label %bb_rcgdec1291
bb_rcglast1291:
  %v6887 = load i64, ptr %slot1014, align 8
  %op6888 = sub i64 %v6887, 24
  store i64 %op6888, ptr %slot1024, align 8
  %v6889 = load i64, ptr %slot1014, align 8
  %p6890 = inttoptr i64 %v6889 to ptr
  %rgep6891 = getelementptr i8, ptr %p6890, i64 -24
  %ld6892 = load i64, ptr %rgep6891, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6892, ptr %slot1025, align 8
  %v6893 = load i64, ptr %slot1025, align 8
  %cmp6894 = icmp ne i64 %v6893, 0
  %cv6895 = zext i1 %cmp6894 to i32
  store i32 %cv6895, ptr %slot1026, align 8
  %v6896 = load i32, ptr %slot1026, align 8
  %cv6897 = zext i32 %v6896 to i64
  %cond6898 = icmp ne i64 %cv6897, 0
  br i1 %cond6898, label %bb_rcgdec1291, label %bb_rcgslow1291
bb_rcgslow1291:
  %v6899 = load i64, ptr %slot1013, align 8
  %v6900 = load i64, ptr %slot996, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v6899, i64 %v6900) nomerge, !dbg !194
  br label %bb_rcgdone1291
bb_rcgdec1291:
  %v6901 = load i64, ptr %slot1022, align 8
  %v6902 = load i64, ptr %slot1014, align 8
  %p6903 = inttoptr i64 %v6902 to ptr
  %rgep6904 = getelementptr i8, ptr %p6903, i64 -32
  store i64 %v6901, ptr %rgep6904, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1291
bb_rcgclear1291:
  %v6905 = load i64, ptr %slot996, align 8
  %p6906 = inttoptr i64 %v6905 to ptr
  store i64 0, ptr %p6906, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1291
bb_rcgdone1291:
  br label %bb_rcslotdone1260
bb_rcslotdone1260:
  %v6907 = load i64, ptr %slot18, align 8
  %p6908 = inttoptr i64 %v6907 to ptr
  %ld6909 = load i32, ptr %p6908, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6909, ptr %slot1027, align 8
  %v6910 = load i32, ptr %slot1027, align 8
  %cv6911 = zext i32 %v6910 to i64
  %cond6912 = icmp ne i64 %cv6911, 0
  br i1 %cond6912, label %bb_rcslotdrop1315, label %bb_rcslotdone1315
bb_rcslotdrop1315:
  %v6913 = load i64, ptr %slot18, align 8
  %p6914 = inttoptr i64 %v6913 to ptr
  store i32 0, ptr %p6914, align 4, !alias.scope !3, !noalias !4
  %v6915 = load i64, ptr %slot64, align 8
  store i64 %v6915, ptr %slot1028, align 8
  %v6916 = load i64, ptr %slot19, align 8
  %p6917 = inttoptr i64 %v6916 to ptr
  %ld6918 = load i32, ptr %p6917, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6918, ptr %slot1029, align 8
  %v6919 = load i32, ptr %slot1029, align 8
  %op6920 = and i32 %v6919, 28
  store i32 %op6920, ptr %slot1030, align 8
  %v6921 = load i32, ptr %slot1030, align 8
  %cv6922 = zext i32 %v6921 to i64
  %cond6923 = icmp ne i64 %cv6922, 0
  br i1 %cond6923, label %bb_rcslotrole1315, label %bb_rcslotowner1315
bb_rcslotrole1315:
  %v6924 = load i64, ptr %slot96, align 8
  store i64 %v6924, ptr %slot1031, align 8
  %v6925 = load i64, ptr %slot1031, align 8
  %v6926 = load i64, ptr %slot1028, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6925, i64 %v6926) nomerge, !dbg !194
  br label %bb_rcslotdone1315
bb_rcslotowner1315:
  %v6927 = load i64, ptr %slot96, align 8
  store i64 %v6927, ptr %slot1032, align 8
  %v6928 = load i64, ptr %slot1032, align 8
  %v6929 = load i64, ptr %slot1028, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6928, i64 %v6929) nomerge, !dbg !194
  br label %bb_rcslotdone1315
bb_rcslotdone1315:
  %v6930 = load i64, ptr %slot16, align 8
  %p6931 = inttoptr i64 %v6930 to ptr
  %ld6932 = load i32, ptr %p6931, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6932, ptr %slot1033, align 8
  %v6933 = load i32, ptr %slot1033, align 8
  %cv6934 = zext i32 %v6933 to i64
  %cond6935 = icmp ne i64 %cv6934, 0
  br i1 %cond6935, label %bb_rcslotdrop1342, label %bb_rcslotdone1342
bb_rcslotdrop1342:
  %v6936 = load i64, ptr %slot16, align 8
  %p6937 = inttoptr i64 %v6936 to ptr
  store i32 0, ptr %p6937, align 4, !alias.scope !3, !noalias !4
  %v6938 = load i64, ptr %slot62, align 8
  store i64 %v6938, ptr %slot1034, align 8
  %v6939 = load i64, ptr %slot17, align 8
  %p6940 = inttoptr i64 %v6939 to ptr
  %ld6941 = load i32, ptr %p6940, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6941, ptr %slot1035, align 8
  %v6942 = load i32, ptr %slot1035, align 8
  %op6943 = and i32 %v6942, 28
  store i32 %op6943, ptr %slot1036, align 8
  %v6944 = load i32, ptr %slot1036, align 8
  %cv6945 = zext i32 %v6944 to i64
  %cond6946 = icmp ne i64 %cv6945, 0
  br i1 %cond6946, label %bb_rcslotrole1342, label %bb_rcslotowner1342
bb_rcslotrole1342:
  %v6947 = load i64, ptr %slot96, align 8
  store i64 %v6947, ptr %slot1037, align 8
  %v6948 = load i64, ptr %slot1037, align 8
  %v6949 = load i64, ptr %slot1034, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6948, i64 %v6949) nomerge, !dbg !194
  br label %bb_rcslotdone1342
bb_rcslotowner1342:
  %v6950 = load i64, ptr %slot96, align 8
  store i64 %v6950, ptr %slot1038, align 8
  %v6951 = load i64, ptr %slot1038, align 8
  %v6952 = load i64, ptr %slot1034, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6951, i64 %v6952) nomerge, !dbg !194
  br label %bb_rcslotdone1342
bb_rcslotdone1342:
  %v6953 = load i64, ptr %slot14, align 8
  %p6954 = inttoptr i64 %v6953 to ptr
  %ld6955 = load i32, ptr %p6954, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6955, ptr %slot1039, align 8
  %v6956 = load i32, ptr %slot1039, align 8
  %cv6957 = zext i32 %v6956 to i64
  %cond6958 = icmp ne i64 %cv6957, 0
  br i1 %cond6958, label %bb_rcslotdrop1369, label %bb_rcslotdone1369
bb_rcslotdrop1369:
  %v6959 = load i64, ptr %slot14, align 8
  %p6960 = inttoptr i64 %v6959 to ptr
  store i32 0, ptr %p6960, align 4, !alias.scope !3, !noalias !4
  %v6961 = load i64, ptr %slot61, align 8
  store i64 %v6961, ptr %slot1040, align 8
  %v6962 = load i64, ptr %slot15, align 8
  %p6963 = inttoptr i64 %v6962 to ptr
  %ld6964 = load i32, ptr %p6963, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6964, ptr %slot1041, align 8
  %v6965 = load i32, ptr %slot1041, align 8
  %op6966 = and i32 %v6965, 28
  store i32 %op6966, ptr %slot1042, align 8
  %v6967 = load i32, ptr %slot1042, align 8
  %cv6968 = zext i32 %v6967 to i64
  %cond6969 = icmp ne i64 %cv6968, 0
  br i1 %cond6969, label %bb_rcslotrole1369, label %bb_rcslotowner1369
bb_rcslotrole1369:
  %v6970 = load i64, ptr %slot96, align 8
  store i64 %v6970, ptr %slot1043, align 8
  %v6971 = load i64, ptr %slot1043, align 8
  %v6972 = load i64, ptr %slot1040, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6971, i64 %v6972) nomerge, !dbg !194
  br label %bb_rcslotdone1369
bb_rcslotowner1369:
  %v6973 = load i64, ptr %slot96, align 8
  store i64 %v6973, ptr %slot1044, align 8
  %v6974 = load i64, ptr %slot1044, align 8
  %v6975 = load i64, ptr %slot1040, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6974, i64 %v6975) nomerge, !dbg !194
  br label %bb_rcslotdone1369
bb_rcslotdone1369:
  %v6976 = load i64, ptr %slot12, align 8
  %p6977 = inttoptr i64 %v6976 to ptr
  %ld6978 = load i32, ptr %p6977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6978, ptr %slot1045, align 8
  %v6979 = load i32, ptr %slot1045, align 8
  %cv6980 = zext i32 %v6979 to i64
  %cond6981 = icmp ne i64 %cv6980, 0
  br i1 %cond6981, label %bb_rcslotdrop1396, label %bb_rcslotdone1396
bb_rcslotdrop1396:
  %v6982 = load i64, ptr %slot12, align 8
  %p6983 = inttoptr i64 %v6982 to ptr
  store i32 0, ptr %p6983, align 4, !alias.scope !3, !noalias !4
  %v6984 = load i64, ptr %slot59, align 8
  store i64 %v6984, ptr %slot1046, align 8
  %v6985 = load i64, ptr %slot13, align 8
  %p6986 = inttoptr i64 %v6985 to ptr
  %ld6987 = load i32, ptr %p6986, align 4, !alias.scope !3, !noalias !4
  store i32 %ld6987, ptr %slot1047, align 8
  %v6988 = load i32, ptr %slot1047, align 8
  %op6989 = and i32 %v6988, 28
  store i32 %op6989, ptr %slot1048, align 8
  %v6990 = load i32, ptr %slot1048, align 8
  %cv6991 = zext i32 %v6990 to i64
  %cond6992 = icmp ne i64 %cv6991, 0
  br i1 %cond6992, label %bb_rcslotrole1396, label %bb_rcslotowner1396
bb_rcslotrole1396:
  %v6993 = load i64, ptr %slot96, align 8
  store i64 %v6993, ptr %slot1049, align 8
  %v6994 = load i64, ptr %slot1049, align 8
  %v6995 = load i64, ptr %slot1046, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v6994, i64 %v6995) nomerge, !dbg !194
  br label %bb_rcslotdone1396
bb_rcslotowner1396:
  %v6996 = load i64, ptr %slot96, align 8
  store i64 %v6996, ptr %slot1050, align 8
  %v6997 = load i64, ptr %slot1050, align 8
  %v6998 = load i64, ptr %slot1046, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v6997, i64 %v6998) nomerge, !dbg !194
  br label %bb_rcslotdone1396
bb_rcslotdone1396:
  %v6999 = load i64, ptr %slot10, align 8
  %p7000 = inttoptr i64 %v6999 to ptr
  %ld7001 = load i32, ptr %p7000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7001, ptr %slot1051, align 8
  %v7002 = load i32, ptr %slot1051, align 8
  %cv7003 = zext i32 %v7002 to i64
  %cond7004 = icmp ne i64 %cv7003, 0
  br i1 %cond7004, label %bb_rcslotdrop1405, label %bb_rcslotdone1405
bb_rcslotdrop1405:
  %v7005 = load i64, ptr %slot10, align 8
  %p7006 = inttoptr i64 %v7005 to ptr
  store i32 0, ptr %p7006, align 4, !alias.scope !3, !noalias !4
  %v7007 = load i64, ptr %slot56, align 8
  store i64 %v7007, ptr %slot1052, align 8
  %v7008 = load i64, ptr %slot11, align 8
  %p7009 = inttoptr i64 %v7008 to ptr
  %ld7010 = load i32, ptr %p7009, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7010, ptr %slot1053, align 8
  %v7011 = load i32, ptr %slot1053, align 8
  %op7012 = and i32 %v7011, 28
  store i32 %op7012, ptr %slot1054, align 8
  %v7013 = load i32, ptr %slot1054, align 8
  %cv7014 = zext i32 %v7013 to i64
  %cond7015 = icmp ne i64 %cv7014, 0
  br i1 %cond7015, label %bb_rcslotrole1405, label %bb_rcslotowner1405
bb_rcslotrole1405:
  %v7016 = load i64, ptr %slot96, align 8
  store i64 %v7016, ptr %slot1055, align 8
  %v7017 = load i64, ptr %slot1055, align 8
  %v7018 = load i64, ptr %slot1052, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v7017, i64 %v7018) nomerge, !dbg !194
  br label %bb_rcslotdone1405
bb_rcslotowner1405:
  %v7019 = load i64, ptr %slot96, align 8
  store i64 %v7019, ptr %slot1056, align 8
  %v7020 = load i64, ptr %slot1056, align 8
  %v7021 = load i64, ptr %slot1052, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v7020, i64 %v7021) nomerge, !dbg !194
  br label %bb_rcslotdone1405
bb_rcslotdone1405:
  %v7022 = load i64, ptr %slot8, align 8
  %p7023 = inttoptr i64 %v7022 to ptr
  %ld7024 = load i32, ptr %p7023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7024, ptr %slot1057, align 8
  %v7025 = load i32, ptr %slot1057, align 8
  %cv7026 = zext i32 %v7025 to i64
  %cond7027 = icmp ne i64 %cv7026, 0
  br i1 %cond7027, label %bb_rcslotdrop1469, label %bb_rcslotdone1469
bb_rcslotdrop1469:
  %v7028 = load i64, ptr %slot8, align 8
  %p7029 = inttoptr i64 %v7028 to ptr
  store i32 0, ptr %p7029, align 4, !alias.scope !3, !noalias !4
  %v7030 = load i64, ptr %slot51, align 8
  store i64 %v7030, ptr %slot1058, align 8
  %v7031 = load i64, ptr %slot9, align 8
  %p7032 = inttoptr i64 %v7031 to ptr
  %ld7033 = load i32, ptr %p7032, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7033, ptr %slot1059, align 8
  %v7034 = load i32, ptr %slot1059, align 8
  %op7035 = and i32 %v7034, 28
  store i32 %op7035, ptr %slot1060, align 8
  %v7036 = load i32, ptr %slot1060, align 8
  %cv7037 = zext i32 %v7036 to i64
  %cond7038 = icmp ne i64 %cv7037, 0
  br i1 %cond7038, label %bb_rcslotrole1469, label %bb_rcslotowner1469
bb_rcslotrole1469:
  %v7039 = load i64, ptr %slot96, align 8
  store i64 %v7039, ptr %slot1061, align 8
  %v7040 = load i64, ptr %slot1061, align 8
  %v7041 = load i64, ptr %slot1058, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7040, i64 %v7041) nomerge, !dbg !194
  br label %bb_rcslotdone1469
bb_rcslotowner1469:
  %v7042 = load i64, ptr %slot96, align 8
  store i64 %v7042, ptr %slot1062, align 8
  %v7043 = load i64, ptr %slot1062, align 8
  %v7044 = load i64, ptr %slot1058, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7043, i64 %v7044) nomerge, !dbg !194
  br label %bb_rcslotdone1469
bb_rcslotdone1469:
  %v7045 = load i64, ptr %slot915, align 8
  %p7046 = inttoptr i64 %v7045 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p7046, i64 24, i1 false)
  ret void
bb_i159:
  %v7047 = load i64, ptr %slot69, align 8
  %p7048 = inttoptr i64 %v7047 to ptr
  %ld7049 = load i64, ptr %p7048, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7049, ptr %slot1063, align 8
  %v7050 = load i64, ptr %slot1063, align 8
  %v7051 = load i64, ptr %slot63, align 8
  %p7052 = inttoptr i64 %v7051 to ptr
  store i64 %v7050, ptr %p7052, align 8, !alias.scope !3, !noalias !4
  %v7053 = load i64, ptr %slot46, align 8
  %p7054 = inttoptr i64 %v7053 to ptr
  %ld7055 = load i64, ptr %p7054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7055, ptr %slot1064, align 8
  %v7056 = load i64, ptr %slot1064, align 8
  %v7057 = load i64, ptr %slot86, align 8
  %p7058 = inttoptr i64 %v7056 to ptr
  %p7059 = inttoptr i64 %v7057 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7059, ptr %p7058, i64 304, i1 false), !alias.scope !10000000
  %v7060 = load i64, ptr %slot86, align 8
  %v7061 = load i64, ptr %slot69, align 8
  %p7062 = inttoptr i64 %v7061 to ptr
  store i64 %v7060, ptr %p7062, align 8, !alias.scope !3, !noalias !4
  %v7063 = load i64, ptr %slot69, align 8
  %p7064 = inttoptr i64 %v7063 to ptr
  %ld7065 = load i64, ptr %p7064, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7065, ptr %slot1065, align 8
  %v7066 = load i64, ptr %slot1065, align 8
  %op7067 = add i64 %v7066, 32
  store i64 %op7067, ptr %slot1066, align 8
  %v7068 = load i64, ptr %slot1066, align 8
  %v7069 = load i64, ptr %slot69, align 8
  %p7070 = inttoptr i64 %v7069 to ptr
  store i64 %v7068, ptr %p7070, align 8, !alias.scope !3, !noalias !4
  %v7071 = load i64, ptr %slot18, align 8
  %p7072 = inttoptr i64 %v7071 to ptr
  %ld7073 = load i32, ptr %p7072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7073, ptr %slot1067, align 8
  %v7074 = load i32, ptr %slot1067, align 8
  %cv7075 = zext i32 %v7074 to i64
  %cond7076 = icmp ne i64 %cv7075, 0
  br i1 %cond7076, label %bb_rcslotdrop1491, label %bb_rcslotdone1491
bb_rcslotdrop1491:
  %v7077 = load i64, ptr %slot18, align 8
  %p7078 = inttoptr i64 %v7077 to ptr
  store i32 0, ptr %p7078, align 4, !alias.scope !3, !noalias !4
  %v7079 = load i64, ptr %slot64, align 8
  store i64 %v7079, ptr %slot1068, align 8
  %v7080 = load i64, ptr %slot19, align 8
  %p7081 = inttoptr i64 %v7080 to ptr
  %ld7082 = load i32, ptr %p7081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7082, ptr %slot1069, align 8
  %v7083 = load i32, ptr %slot1069, align 8
  %op7084 = and i32 %v7083, 28
  store i32 %op7084, ptr %slot1070, align 8
  %v7085 = load i32, ptr %slot1070, align 8
  %cv7086 = zext i32 %v7085 to i64
  %cond7087 = icmp ne i64 %cv7086, 0
  br i1 %cond7087, label %bb_rcslotrole1491, label %bb_rcslotowner1491
bb_rcslotrole1491:
  %v7088 = load i64, ptr %slot96, align 8
  store i64 %v7088, ptr %slot1071, align 8
  %v7089 = load i64, ptr %slot1071, align 8
  %v7090 = load i64, ptr %slot1068, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7089, i64 %v7090) nomerge, !dbg !196
  br label %bb_rcslotdone1491
bb_rcslotowner1491:
  %v7091 = load i64, ptr %slot96, align 8
  store i64 %v7091, ptr %slot1072, align 8
  %v7092 = load i64, ptr %slot1072, align 8
  %v7093 = load i64, ptr %slot1068, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7092, i64 %v7093) nomerge, !dbg !196
  br label %bb_rcslotdone1491
bb_rcslotdone1491:
  %v7094 = load i64, ptr %slot46, align 8
  %p7095 = inttoptr i64 %v7094 to ptr
  %ld7096 = load i64, ptr %p7095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7096, ptr %slot1073, align 8
  %v7097 = load i64, ptr %slot1073, align 8
  %op7098 = add i64 %v7097, 32
  store i64 %op7098, ptr %slot1074, align 8
  %v7099 = load i64, ptr %slot64, align 8
  store i64 %v7099, ptr %slot1075, align 8
  %v7100 = load i64, ptr %slot1074, align 8
  %v7101 = load i64, ptr %slot1075, align 8
  %p7102 = inttoptr i64 %v7100 to ptr
  %p7103 = inttoptr i64 %v7101 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7103, ptr %p7102, i64 208, i1 false), !alias.scope !10000000
  %v7104 = load i64, ptr %slot1074, align 8
  %p7105 = inttoptr i64 %v7104 to ptr
  call void @llvm.memset.p0.i64(ptr %p7105, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !196
  %v7106 = load i64, ptr %slot18, align 8
  %p7107 = inttoptr i64 %v7106 to ptr
  store i32 1, ptr %p7107, align 4, !alias.scope !3, !noalias !4
  %v7108 = load i64, ptr %slot64, align 8
  %v7109 = load i64, ptr %slot69, align 8
  %p7110 = inttoptr i64 %v7109 to ptr
  store i64 %v7108, ptr %p7110, align 8, !alias.scope !3, !noalias !4
  %v7111 = load i64, ptr %slot69, align 8
  %p7112 = inttoptr i64 %v7111 to ptr
  %ld7113 = load i64, ptr %p7112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7113, ptr %slot1076, align 8
  %v7114 = load i64, ptr %slot1, align 8
  %v7115 = load i64, ptr %slot1076, align 8
  %call7116 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v7114, i64 %v7115) nomerge, !dbg !198
  store { i64, i64 } %call7116, ptr %callresult1078, align 8
  %addr7117 = ptrtoint ptr %callresult1078 to i64
  store i64 %addr7117, ptr %slot1077, align 8
  %v7118 = load i64, ptr %slot1077, align 8
  %v7119 = load i64, ptr %slot69, align 8
  %p7120 = inttoptr i64 %v7119 to ptr
  store i64 %v7118, ptr %p7120, align 8, !alias.scope !3, !noalias !4
  %v7121 = load i64, ptr %slot28, align 8
  %p7122 = inttoptr i64 %v7121 to ptr
  %ld7123 = load i32, ptr %p7122, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7123, ptr %slot1079, align 8
  %v7124 = load i32, ptr %slot1079, align 8
  %cv7125 = zext i32 %v7124 to i64
  %cond7126 = icmp ne i64 %cv7125, 0
  br i1 %cond7126, label %bb_rcslotdrop1506, label %bb_rcslotdone1506
bb_rcslotdrop1506:
  %v7127 = load i64, ptr %slot28, align 8
  %p7128 = inttoptr i64 %v7127 to ptr
  store i32 0, ptr %p7128, align 4, !alias.scope !3, !noalias !4
  %v7129 = load i64, ptr %slot37, align 8
  store i64 %v7129, ptr %slot1080, align 8
  %v7130 = load i64, ptr %slot29, align 8
  %p7131 = inttoptr i64 %v7130 to ptr
  %ld7132 = load i32, ptr %p7131, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7132, ptr %slot1081, align 8
  %v7133 = load i32, ptr %slot1081, align 8
  %op7134 = and i32 %v7133, 28
  store i32 %op7134, ptr %slot1082, align 8
  %v7135 = load i32, ptr %slot1082, align 8
  %cv7136 = zext i32 %v7135 to i64
  %cond7137 = icmp ne i64 %cv7136, 0
  br i1 %cond7137, label %bb_rcslotrole1506, label %bb_rcslotowner1506
bb_rcslotrole1506:
  %v7138 = load i64, ptr %slot96, align 8
  store i64 %v7138, ptr %slot1083, align 8
  %v7139 = load i64, ptr %slot1083, align 8
  %v7140 = load i64, ptr %slot1080, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7139, i64 %v7140) nomerge, !dbg !198
  br label %bb_rcslotdone1506
bb_rcslotowner1506:
  %v7141 = load i64, ptr %slot96, align 8
  store i64 %v7141, ptr %slot1084, align 8
  %v7142 = load i64, ptr %slot1084, align 8
  %v7143 = load i64, ptr %slot1080, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7142, i64 %v7143) nomerge, !dbg !198
  br label %bb_rcslotdone1506
bb_rcslotdone1506:
  %v7144 = load i64, ptr %slot46, align 8
  %p7145 = inttoptr i64 %v7144 to ptr
  %ld7146 = load i64, ptr %p7145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7146, ptr %slot1085, align 8
  %v7147 = load i64, ptr %slot1085, align 8
  %op7148 = add i64 %v7147, 32
  store i64 %op7148, ptr %slot1086, align 8
  %v7149 = load i64, ptr %slot64, align 8
  store i64 %v7149, ptr %slot1087, align 8
  %v7150 = load i64, ptr %slot1087, align 8
  %v7151 = load i64, ptr %slot1086, align 8
  %p7152 = inttoptr i64 %v7150 to ptr
  %p7153 = inttoptr i64 %v7151 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7153, ptr %p7152, i64 208, i1 false), !alias.scope !10000000
  %v7154 = load i64, ptr %slot1087, align 8
  %p7155 = inttoptr i64 %v7154 to ptr
  call void @llvm.memset.p0.i64(ptr %p7155, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !200
  %v7156 = load i64, ptr %slot18, align 8
  %p7157 = inttoptr i64 %v7156 to ptr
  store i32 0, ptr %p7157, align 4, !alias.scope !3, !noalias !4
  %v7158 = load i64, ptr %slot69, align 8
  %p7159 = inttoptr i64 %v7158 to ptr
  store i64 0, ptr %p7159, align 8, !alias.scope !3, !noalias !4
  %v7160 = load i64, ptr %slot46, align 8
  %p7161 = inttoptr i64 %v7160 to ptr
  %ld7162 = load i64, ptr %p7161, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7162, ptr %slot1088, align 8
  %v7163 = load i64, ptr %slot1088, align 8
  %v7164 = load i64, ptr %slot69, align 8
  %p7165 = inttoptr i64 %v7164 to ptr
  store i64 %v7163, ptr %p7165, align 8, !alias.scope !3, !noalias !4
  %v7166 = load i64, ptr %slot58, align 8
  %v7167 = load i64, ptr %slot70, align 8
  %p7168 = inttoptr i64 %v7167 to ptr
  store i64 %v7166, ptr %p7168, align 8, !alias.scope !3, !noalias !4
  %v7169 = load i64, ptr %slot63, align 8
  %p7170 = inttoptr i64 %v7169 to ptr
  %ld7171 = load i64, ptr %p7170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7171, ptr %slot1089, align 8
  %v7172 = load i64, ptr %slot1089, align 8
  %v7173 = load i64, ptr %slot71, align 8
  %p7174 = inttoptr i64 %v7173 to ptr
  store i64 %v7172, ptr %p7174, align 8, !alias.scope !3, !noalias !4
  %v7175 = load i64, ptr %slot69, align 8
  %p7176 = inttoptr i64 %v7175 to ptr
  %ld7177 = load i64, ptr %p7176, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7177, ptr %slot1090, align 8
  %v7178 = load i64, ptr %slot70, align 8
  %p7179 = inttoptr i64 %v7178 to ptr
  %ld7180 = load i64, ptr %p7179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7180, ptr %slot1091, align 8
  %v7181 = load i64, ptr %slot71, align 8
  %p7182 = inttoptr i64 %v7181 to ptr
  %ld7183 = load i64, ptr %p7182, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7183, ptr %slot1092, align 8
  %v7184 = load i64, ptr %slot1, align 8
  %v7185 = load i64, ptr %slot1090, align 8
  %v7186 = load i64, ptr %slot1091, align 8
  %v7187 = load i64, ptr %slot1092, align 8
  call void @myl_f_e8c749c10445dc457f5775bb824164c0e2bada77ed66473babb0974281a32427(ptr sret([24 x i8]) align 8 %callresult1094, i64 %v7184, i64 %v7185, i64 %v7186, i64 %v7187) nomerge, !dbg !202
  %addr7188 = ptrtoint ptr %callresult1094 to i64
  store i64 %addr7188, ptr %slot1093, align 8
  %v7189 = load i64, ptr %slot1093, align 8
  %v7190 = load i64, ptr %slot69, align 8
  %p7191 = inttoptr i64 %v7190 to ptr
  store i64 %v7189, ptr %p7191, align 8, !alias.scope !3, !noalias !4
  %v7192 = load i64, ptr %slot69, align 8
  %p7193 = inttoptr i64 %v7192 to ptr
  %ld7194 = load i64, ptr %p7193, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7194, ptr %slot1095, align 8
  %v7195 = load i64, ptr %slot41, align 8
  store i64 %v7195, ptr %slot1096, align 8
  %v7196 = load i64, ptr %slot1095, align 8
  %v7197 = load i64, ptr %slot1096, align 8
  %p7198 = inttoptr i64 %v7196 to ptr
  %p7199 = inttoptr i64 %v7197 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7199, ptr %p7198, i64 24, i1 false)
  %v7200 = load i64, ptr %slot35, align 8
  %p7201 = inttoptr i64 %v7200 to ptr
  store i32 2, ptr %p7201, align 4, !alias.scope !3, !noalias !4
  %v7202 = load i64, ptr %slot34, align 8
  %p7203 = inttoptr i64 %v7202 to ptr
  store i32 1, ptr %p7203, align 4, !alias.scope !3, !noalias !4
  %v7204 = load i64, ptr %slot28, align 8
  %p7205 = inttoptr i64 %v7204 to ptr
  %ld7206 = load i32, ptr %p7205, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7206, ptr %slot1097, align 8
  %v7207 = load i32, ptr %slot1097, align 8
  %cv7208 = zext i32 %v7207 to i64
  %cond7209 = icmp ne i64 %cv7208, 0
  br i1 %cond7209, label %bb_rcslotdrop1529, label %bb_rcslotdone1529
bb_rcslotdrop1529:
  %v7210 = load i64, ptr %slot28, align 8
  %p7211 = inttoptr i64 %v7210 to ptr
  store i32 0, ptr %p7211, align 4, !alias.scope !3, !noalias !4
  %v7212 = load i64, ptr %slot37, align 8
  store i64 %v7212, ptr %slot1098, align 8
  %v7213 = load i64, ptr %slot29, align 8
  %p7214 = inttoptr i64 %v7213 to ptr
  %ld7215 = load i32, ptr %p7214, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7215, ptr %slot1099, align 8
  %v7216 = load i32, ptr %slot1099, align 8
  %op7217 = and i32 %v7216, 28
  store i32 %op7217, ptr %slot1100, align 8
  %v7218 = load i32, ptr %slot1100, align 8
  %cv7219 = zext i32 %v7218 to i64
  %cond7220 = icmp ne i64 %cv7219, 0
  br i1 %cond7220, label %bb_rcslotrole1529, label %bb_rcslotowner1529
bb_rcslotrole1529:
  %v7221 = load i64, ptr %slot96, align 8
  store i64 %v7221, ptr %slot1101, align 8
  %v7222 = load i64, ptr %slot1101, align 8
  %v7223 = load i64, ptr %slot1098, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v7222, i64 %v7223) nomerge, !dbg !202
  br label %bb_rcslotdone1529
bb_rcslotowner1529:
  %v7224 = load i64, ptr %slot96, align 8
  store i64 %v7224, ptr %slot1102, align 8
  %v7225 = load i64, ptr %slot1102, align 8
  %v7226 = load i64, ptr %slot1098, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v7225, i64 %v7226) nomerge, !dbg !202
  br label %bb_rcslotdone1529
bb_rcslotdone1529:
  %v7227 = load i64, ptr %slot37, align 8
  store i64 %v7227, ptr %slot1103, align 8
  %v7228 = load i64, ptr %slot41, align 8
  store i64 %v7228, ptr %slot1104, align 8
  %v7229 = load i64, ptr %slot1104, align 8
  %v7230 = load i64, ptr %slot1103, align 8
  %p7231 = inttoptr i64 %v7229 to ptr
  %p7232 = inttoptr i64 %v7230 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7232, ptr %p7231, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7233 = load i64, ptr %slot29, align 8
  %p7234 = inttoptr i64 %v7233 to ptr
  store i32 2, ptr %p7234, align 4, !alias.scope !3, !noalias !4
  %v7235 = load i64, ptr %slot35, align 8
  %p7236 = inttoptr i64 %v7235 to ptr
  %ld7237 = load i32, ptr %p7236, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7237, ptr %slot1105, align 8
  %v7238 = load i32, ptr %slot1105, align 8
  %v7239 = load i64, ptr %slot29, align 8
  %p7240 = inttoptr i64 %v7239 to ptr
  store i32 %v7238, ptr %p7240, align 4, !alias.scope !3, !noalias !4
  %v7241 = load i64, ptr %slot34, align 8
  %p7242 = inttoptr i64 %v7241 to ptr
  store i32 0, ptr %p7242, align 4, !alias.scope !3, !noalias !4
  %v7243 = load i64, ptr %slot28, align 8
  %p7244 = inttoptr i64 %v7243 to ptr
  store i32 1, ptr %p7244, align 4, !alias.scope !3, !noalias !4
  %v7245 = load i64, ptr %slot1103, align 8
  %v7246 = load i64, ptr %slot69, align 8
  %p7247 = inttoptr i64 %v7246 to ptr
  store i64 %v7245, ptr %p7247, align 8, !alias.scope !3, !noalias !4
  %v7248 = load i64, ptr %slot69, align 8
  %p7249 = inttoptr i64 %v7248 to ptr
  %ld7250 = load i64, ptr %p7249, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7250, ptr %slot1106, align 8
  %v7251 = load i64, ptr %slot1106, align 8
  %p7252 = inttoptr i64 %v7251 to ptr
  %ld7253 = load i32, ptr %p7252, align 4
  %ext7254 = zext i32 %ld7253 to i64
  store i64 %ext7254, ptr %slot1107, align 8
  %v7255 = load i64, ptr %slot1107, align 8
  %cmp7256 = icmp eq i64 %v7255, 0
  %cv7257 = zext i1 %cmp7256 to i64
  store i64 %cv7257, ptr %slot1108, align 8
  %v7258 = load i64, ptr %slot1108, align 8
  %cond7259 = icmp ne i64 %v7258, 0
  br i1 %cond7259, label %bb_rctryok1545, label %bb_rctryerror1545
bb_rctryerror1545:
  %p7260 = inttoptr i64 ptrtoint (ptr @myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p7260, i64 12884902072) "call-inline-cost"="0", !dbg !204
  %v7261 = load i64, ptr %slot1106, align 8
  %op7262 = add i64 %v7261, 8
  store i64 %op7262, ptr %slot1109, align 8
  %v7263 = load i64, ptr %slot87, align 8
  store i64 %v7263, ptr %slot1110, align 8
  %v7264 = load i64, ptr %slot1110, align 8
  %p7265 = inttoptr i64 %v7264 to ptr
  store i64 0, ptr %p7265, align 8, !alias.scope !3, !noalias !4
  %v7266 = load i64, ptr %slot1110, align 8
  %p7268 = inttoptr i64 %v7266 to ptr
  %gep7269 = getelementptr i8, ptr %p7268, i64 8
  %op7267 = ptrtoint ptr %gep7269 to i64
  store i64 %op7267, ptr %slot1111, align 8
  %v7270 = load i64, ptr %slot1111, align 8
  %p7271 = inttoptr i64 %v7270 to ptr
  store i64 0, ptr %p7271, align 8, !alias.scope !3, !noalias !4
  %v7272 = load i64, ptr %slot1110, align 8
  %p7274 = inttoptr i64 %v7272 to ptr
  %gep7275 = getelementptr i8, ptr %p7274, i64 16
  %op7273 = ptrtoint ptr %gep7275 to i64
  store i64 %op7273, ptr %slot1112, align 8
  %v7276 = load i64, ptr %slot1112, align 8
  %p7277 = inttoptr i64 %v7276 to ptr
  store i64 0, ptr %p7277, align 8, !alias.scope !3, !noalias !4
  %v7278 = load i64, ptr %slot1110, align 8
  %p7279 = inttoptr i64 %v7278 to ptr
  store i32 1, ptr %p7279, align 4, !alias.scope !3, !noalias !4
  %v7280 = load i64, ptr %slot1110, align 8
  %p7282 = inttoptr i64 %v7280 to ptr
  %gep7283 = getelementptr i8, ptr %p7282, i64 8
  %op7281 = ptrtoint ptr %gep7283 to i64
  store i64 %op7281, ptr %slot1113, align 8
  %v7284 = load i64, ptr %slot36, align 8
  %p7285 = inttoptr i64 %v7284 to ptr
  store i32 1, ptr %p7285, align 4, !alias.scope !3, !noalias !4
  %v7286 = load i64, ptr %slot97, align 8
  store i64 %v7286, ptr %slot1114, align 8
  %v7287 = load i64, ptr %slot96, align 8
  %v7288 = load i64, ptr %slot1113, align 8
  %v7289 = load i64, ptr %slot1109, align 8
  %v7290 = load i64, ptr %slot1114, align 8
  %cv7291 = trunc i64 %v7290 to i32
  %call7292 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v7287, i64 %v7288, i64 %v7289, i32 %cv7291) nomerge, !dbg !204
  store i32 %call7292, ptr %slot1115, align 8
  %v7293 = load i32, ptr %slot1115, align 8
  %cv7294 = zext i32 %v7293 to i64
  %cond7295 = icmp ne i64 %cv7294, 0
  br i1 %cond7295, label %bb_rcsuccess1556, label %bb_rcfailure1556
bb_rcfailure1556:
  %v7296 = load i64, ptr %slot96, align 8
  %p7297 = inttoptr i64 %v7296 to ptr
  %call7298 = call i32 @myl_rc_take_failure(ptr %p7297) nomerge, !dbg !204
  store i32 %call7298, ptr %slot1116, align 8
  %v7299 = load i64, ptr %slot1, align 8
  %p7300 = inttoptr i64 %v7299 to ptr
  %v7301 = load i32, ptr %slot1116, align 8
  %call7302 = call i32 @myl_qbe_rc_status(ptr %p7300, i32 %v7301) nomerge, !dbg !204
  store i32 %call7302, ptr %slot1117, align 8
  br label %bb_failure
bb_rcsuccess1556:
  %v7303 = load i64, ptr %slot1110, align 8
  %v7304 = load i64, ptr %slot69, align 8
  %p7305 = inttoptr i64 %v7304 to ptr
  store i64 %v7303, ptr %p7305, align 8, !alias.scope !3, !noalias !4
  %v7306 = load i64, ptr %slot69, align 8
  %p7307 = inttoptr i64 %v7306 to ptr
  %ld7308 = load i64, ptr %p7307, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7308, ptr %slot1118, align 8
  %v7309 = load i64, ptr %slot41, align 8
  store i64 %v7309, ptr %slot1119, align 8
  %v7310 = load i64, ptr %slot1118, align 8
  %v7311 = load i64, ptr %slot1119, align 8
  %p7312 = inttoptr i64 %v7310 to ptr
  %p7313 = inttoptr i64 %v7311 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7313, ptr %p7312, i64 24, i1 false)
  %v7314 = load i64, ptr %slot35, align 8
  %p7315 = inttoptr i64 %v7314 to ptr
  store i32 2, ptr %p7315, align 4, !alias.scope !3, !noalias !4
  %v7316 = load i64, ptr %slot34, align 8
  %p7317 = inttoptr i64 %v7316 to ptr
  store i32 1, ptr %p7317, align 4, !alias.scope !3, !noalias !4
  %v7318 = load i64, ptr %slot28, align 8
  %p7319 = inttoptr i64 %v7318 to ptr
  %ld7320 = load i32, ptr %p7319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7320, ptr %slot1120, align 8
  %v7321 = load i32, ptr %slot1120, align 8
  %cv7322 = zext i32 %v7321 to i64
  %cond7323 = icmp ne i64 %cv7322, 0
  br i1 %cond7323, label %bb_rcslotdrop1565, label %bb_rcslotdone1565
bb_rcslotdrop1565:
  %v7324 = load i64, ptr %slot28, align 8
  %p7325 = inttoptr i64 %v7324 to ptr
  store i32 0, ptr %p7325, align 4, !alias.scope !3, !noalias !4
  %v7326 = load i64, ptr %slot37, align 8
  store i64 %v7326, ptr %slot1121, align 8
  %v7327 = load i64, ptr %slot29, align 8
  %p7328 = inttoptr i64 %v7327 to ptr
  %ld7329 = load i32, ptr %p7328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7329, ptr %slot1122, align 8
  %v7330 = load i32, ptr %slot1122, align 8
  %op7331 = and i32 %v7330, 28
  store i32 %op7331, ptr %slot1123, align 8
  %v7332 = load i32, ptr %slot1123, align 8
  %cv7333 = zext i32 %v7332 to i64
  %cond7334 = icmp ne i64 %cv7333, 0
  br i1 %cond7334, label %bb_rcslotrole1565, label %bb_rcslotowner1565
bb_rcslotrole1565:
  %v7335 = load i64, ptr %slot96, align 8
  store i64 %v7335, ptr %slot1124, align 8
  %v7336 = load i64, ptr %slot1124, align 8
  %v7337 = load i64, ptr %slot1121, align 8
  call void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_unloan(i64 %v7336, i64 %v7337) nomerge, !dbg !204
  br label %bb_rcslotdone1565
bb_rcslotowner1565:
  %v7338 = load i64, ptr %slot96, align 8
  store i64 %v7338, ptr %slot1125, align 8
  %v7339 = load i64, ptr %slot1125, align 8
  %v7340 = load i64, ptr %slot1121, align 8
  call void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_drop(i64 %v7339, i64 %v7340) nomerge, !dbg !204
  br label %bb_rcslotdone1565
bb_rcslotdone1565:
  %v7341 = load i64, ptr %slot37, align 8
  store i64 %v7341, ptr %slot1126, align 8
  %v7342 = load i64, ptr %slot41, align 8
  store i64 %v7342, ptr %slot1127, align 8
  %v7343 = load i64, ptr %slot1127, align 8
  %v7344 = load i64, ptr %slot1126, align 8
  %p7345 = inttoptr i64 %v7343 to ptr
  %p7346 = inttoptr i64 %v7344 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7346, ptr %p7345, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v7347 = load i64, ptr %slot29, align 8
  %p7348 = inttoptr i64 %v7347 to ptr
  store i32 2, ptr %p7348, align 4, !alias.scope !3, !noalias !4
  %v7349 = load i64, ptr %slot35, align 8
  %p7350 = inttoptr i64 %v7349 to ptr
  %ld7351 = load i32, ptr %p7350, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7351, ptr %slot1128, align 8
  %v7352 = load i32, ptr %slot1128, align 8
  %v7353 = load i64, ptr %slot29, align 8
  %p7354 = inttoptr i64 %v7353 to ptr
  store i32 %v7352, ptr %p7354, align 4, !alias.scope !3, !noalias !4
  %v7355 = load i64, ptr %slot34, align 8
  %p7356 = inttoptr i64 %v7355 to ptr
  store i32 0, ptr %p7356, align 4, !alias.scope !3, !noalias !4
  %v7357 = load i64, ptr %slot28, align 8
  %p7358 = inttoptr i64 %v7357 to ptr
  store i32 1, ptr %p7358, align 4, !alias.scope !3, !noalias !4
  %v7359 = load i64, ptr %slot1126, align 8
  %v7360 = load i64, ptr %slot69, align 8
  %p7361 = inttoptr i64 %v7360 to ptr
  store i64 %v7359, ptr %p7361, align 8, !alias.scope !3, !noalias !4
  br label %bb_i186
bb_rctryok1545:
  %v7362 = load i64, ptr %slot87, align 8
  store i64 %v7362, ptr %slot1129, align 8
  %v7363 = load i64, ptr %slot1129, align 8
  %p7364 = inttoptr i64 %v7363 to ptr
  store i64 0, ptr %p7364, align 8, !alias.scope !3, !noalias !4
  %v7365 = load i64, ptr %slot1129, align 8
  %p7367 = inttoptr i64 %v7365 to ptr
  %gep7368 = getelementptr i8, ptr %p7367, i64 8
  %op7366 = ptrtoint ptr %gep7368 to i64
  store i64 %op7366, ptr %slot1130, align 8
  %v7369 = load i64, ptr %slot1130, align 8
  %p7370 = inttoptr i64 %v7369 to ptr
  store i64 0, ptr %p7370, align 8, !alias.scope !3, !noalias !4
  %v7371 = load i64, ptr %slot36, align 8
  %p7372 = inttoptr i64 %v7371 to ptr
  store i32 1, ptr %p7372, align 4, !alias.scope !3, !noalias !4
  %v7373 = load i64, ptr %slot1106, align 8
  %op7374 = add i64 %v7373, 8
  store i64 %op7374, ptr %slot1131, align 8
  %v7375 = load i64, ptr %slot97, align 8
  store i64 %v7375, ptr %slot1132, align 8
  %v7376 = load i64, ptr %slot1131, align 8
  %v7377 = load i64, ptr %slot1129, align 8
  %p7378 = inttoptr i64 %v7376 to ptr
  %p7379 = inttoptr i64 %v7377 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p7379, ptr %p7378, i64 16, i1 false)
  %v7380 = load i64, ptr %slot1129, align 8
  %v7381 = load i64, ptr %slot69, align 8
  %p7382 = inttoptr i64 %v7381 to ptr
  store i64 %v7380, ptr %p7382, align 8, !alias.scope !3, !noalias !4
  %v7383 = load i64, ptr %slot28, align 8
  %p7384 = inttoptr i64 %v7383 to ptr
  %ld7385 = load i32, ptr %p7384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7385, ptr %slot1133, align 8
  %v7386 = load i32, ptr %slot1133, align 8
  %cv7387 = zext i32 %v7386 to i64
  %cond7388 = icmp ne i64 %cv7387, 0
  br i1 %cond7388, label %bb_rcslotdrop1588, label %bb_rcslotdone1588
bb_rcslotdrop1588:
  %v7389 = load i64, ptr %slot28, align 8
  %p7390 = inttoptr i64 %v7389 to ptr
  store i32 0, ptr %p7390, align 4, !alias.scope !3, !noalias !4
  %v7391 = load i64, ptr %slot37, align 8
  store i64 %v7391, ptr %slot1134, align 8
  %v7392 = load i64, ptr %slot29, align 8
  %p7393 = inttoptr i64 %v7392 to ptr
  %ld7394 = load i32, ptr %p7393, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7394, ptr %slot1135, align 8
  %v7395 = load i32, ptr %slot1135, align 8
  %op7396 = and i32 %v7395, 28
  store i32 %op7396, ptr %slot1136, align 8
  %v7397 = load i32, ptr %slot1136, align 8
  %cv7398 = zext i32 %v7397 to i64
  %cond7399 = icmp ne i64 %cv7398, 0
  br i1 %cond7399, label %bb_rcslotrole1588, label %bb_rcslotowner1588
bb_rcslotrole1588:
  %v7400 = load i64, ptr %slot96, align 8
  store i64 %v7400, ptr %slot1137, align 8
  %v7401 = load i64, ptr %slot1137, align 8
  %v7402 = load i64, ptr %slot1134, align 8
  call void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_unloan(i64 %v7401, i64 %v7402) nomerge, !dbg !204
  br label %bb_rcslotdone1588
bb_rcslotowner1588:
  %v7403 = load i64, ptr %slot96, align 8
  store i64 %v7403, ptr %slot1138, align 8
  %v7404 = load i64, ptr %slot1138, align 8
  %v7405 = load i64, ptr %slot1134, align 8
  call void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_drop(i64 %v7404, i64 %v7405) nomerge, !dbg !204
  br label %bb_rcslotdone1588
bb_rcslotdone1588:
  br label %bb_i187
bb_i186:
  %v7406 = load i64, ptr %slot69, align 8
  %p7407 = inttoptr i64 %v7406 to ptr
  %ld7408 = load i64, ptr %p7407, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7408, ptr %slot1139, align 8
  %v7409 = load i64, ptr %slot69, align 8
  %p7410 = inttoptr i64 %v7409 to ptr
  %ld7411 = load i64, ptr %p7410, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7411, ptr %slot1140, align 8
  %v7412 = load i64, ptr %slot28, align 8
  %p7413 = inttoptr i64 %v7412 to ptr
  %ld7414 = load i32, ptr %p7413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7414, ptr %slot1141, align 8
  %v7415 = load i64, ptr %slot29, align 8
  %p7416 = inttoptr i64 %v7415 to ptr
  %ld7417 = load i32, ptr %p7416, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7417, ptr %slot1142, align 8
  %v7418 = load i32, ptr %slot1142, align 8
  %op7419 = and i32 %v7418, 24
  store i32 %op7419, ptr %slot1142, align 8
  %v7420 = load i32, ptr %slot1142, align 8
  %cmp7421 = icmp eq i32 %v7420, 0
  %cv7422 = zext i1 %cmp7421 to i32
  store i32 %cv7422, ptr %slot1143, align 8
  %v7423 = load i32, ptr %slot1141, align 8
  %v7424 = load i32, ptr %slot1143, align 8
  %op7425 = and i32 %v7423, %v7424
  store i32 %op7425, ptr %slot1144, align 8
  %v7426 = load i32, ptr %slot1144, align 8
  %cv7427 = zext i32 %v7426 to i64
  %cond7428 = icmp ne i64 %cv7427, 0
  br i1 %cond7428, label %bb_rctake1597, label %bb_rccopy1597
bb_rctake1597:
  %v7429 = load i64, ptr %slot41, align 8
  store i64 %v7429, ptr %slot1145, align 8
  %v7430 = load i64, ptr %slot97, align 8
  store i64 %v7430, ptr %slot1146, align 8
  %v7431 = load i64, ptr %slot96, align 8
  %v7432 = load i64, ptr %slot1145, align 8
  %v7433 = load i64, ptr %slot1140, align 8
  %v7434 = load i64, ptr %slot1146, align 8
  %cv7435 = trunc i64 %v7434 to i32
  %call7436 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v7431, i64 %v7432, i64 %v7433, i32 %cv7435) nomerge, !dbg !206
  store i32 %call7436, ptr %slot1147, align 8
  %v7437 = load i32, ptr %slot1147, align 8
  %cv7438 = zext i32 %v7437 to i64
  %cond7439 = icmp ne i64 %cv7438, 0
  br i1 %cond7439, label %bb_rcsuccess1607, label %bb_rcfailure1607
bb_rcfailure1607:
  %v7440 = load i64, ptr %slot96, align 8
  %p7441 = inttoptr i64 %v7440 to ptr
  %call7442 = call i32 @myl_rc_take_failure(ptr %p7441) nomerge, !dbg !206
  store i32 %call7442, ptr %slot1148, align 8
  %v7443 = load i64, ptr %slot1, align 8
  %p7444 = inttoptr i64 %v7443 to ptr
  %v7445 = load i32, ptr %slot1148, align 8
  %call7446 = call i32 @myl_qbe_rc_status(ptr %p7444, i32 %v7445) nomerge, !dbg !206
  store i32 %call7446, ptr %slot1149, align 8
  br label %bb_failure
bb_rcsuccess1607:
  %v7447 = load i64, ptr %slot28, align 8
  %p7448 = inttoptr i64 %v7447 to ptr
  store i32 0, ptr %p7448, align 4, !alias.scope !3, !noalias !4
  %v7449 = load i64, ptr %slot35, align 8
  %p7450 = inttoptr i64 %v7449 to ptr
  store i32 2, ptr %p7450, align 4, !alias.scope !3, !noalias !4
  %v7451 = load i64, ptr %slot34, align 8
  %p7452 = inttoptr i64 %v7451 to ptr
  store i32 1, ptr %p7452, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1597
bb_rccopy1597:
  %v7453 = load i64, ptr %slot41, align 8
  store i64 %v7453, ptr %slot1150, align 8
  %v7454 = load i64, ptr %slot97, align 8
  store i64 %v7454, ptr %slot1151, align 8
  %v7455 = load i64, ptr %slot96, align 8
  %v7456 = load i64, ptr %slot1150, align 8
  %v7457 = load i64, ptr %slot1140, align 8
  %v7458 = load i64, ptr %slot1151, align 8
  %cv7459 = trunc i64 %v7458 to i32
  %call7460 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64 %v7455, i64 %v7456, i64 %v7457, i32 %cv7459) nomerge, !dbg !206
  store i32 %call7460, ptr %slot1152, align 8
  %v7461 = load i32, ptr %slot1152, align 8
  %cv7462 = zext i32 %v7461 to i64
  %cond7463 = icmp ne i64 %cv7462, 0
  br i1 %cond7463, label %bb_rcsuccess1616, label %bb_rcfailure1616
bb_rcfailure1616:
  %v7464 = load i64, ptr %slot96, align 8
  %p7465 = inttoptr i64 %v7464 to ptr
  %call7466 = call i32 @myl_rc_take_failure(ptr %p7465) nomerge, !dbg !206
  store i32 %call7466, ptr %slot1153, align 8
  %v7467 = load i64, ptr %slot1, align 8
  %p7468 = inttoptr i64 %v7467 to ptr
  %v7469 = load i32, ptr %slot1153, align 8
  %call7470 = call i32 @myl_qbe_rc_status(ptr %p7468, i32 %v7469) nomerge, !dbg !206
  store i32 %call7470, ptr %slot1154, align 8
  br label %bb_failure
bb_rcsuccess1616:
  %v7471 = load i64, ptr %slot35, align 8
  %p7472 = inttoptr i64 %v7471 to ptr
  store i32 2, ptr %p7472, align 4, !alias.scope !3, !noalias !4
  %v7473 = load i64, ptr %slot34, align 8
  %p7474 = inttoptr i64 %v7473 to ptr
  store i32 1, ptr %p7474, align 4, !alias.scope !3, !noalias !4
  %v7475 = load i64, ptr %slot28, align 8
  %p7476 = inttoptr i64 %v7475 to ptr
  %ld7477 = load i32, ptr %p7476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7477, ptr %slot1155, align 8
  %v7478 = load i32, ptr %slot1155, align 8
  %cv7479 = zext i32 %v7478 to i64
  %cond7480 = icmp ne i64 %cv7479, 0
  br i1 %cond7480, label %bb_rcslotdrop1623, label %bb_rcslotdone1623
bb_rcslotdrop1623:
  %v7481 = load i64, ptr %slot28, align 8
  %p7482 = inttoptr i64 %v7481 to ptr
  store i32 0, ptr %p7482, align 4, !alias.scope !3, !noalias !4
  %v7483 = load i64, ptr %slot37, align 8
  store i64 %v7483, ptr %slot1156, align 8
  %v7484 = load i64, ptr %slot29, align 8
  %p7485 = inttoptr i64 %v7484 to ptr
  %ld7486 = load i32, ptr %p7485, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7486, ptr %slot1157, align 8
  %v7487 = load i32, ptr %slot1157, align 8
  %op7488 = and i32 %v7487, 28
  store i32 %op7488, ptr %slot1158, align 8
  %v7489 = load i32, ptr %slot1158, align 8
  %cv7490 = zext i32 %v7489 to i64
  %cond7491 = icmp ne i64 %cv7490, 0
  br i1 %cond7491, label %bb_rcslotrole1623, label %bb_rcslotowner1623
bb_rcslotrole1623:
  %v7492 = load i64, ptr %slot96, align 8
  store i64 %v7492, ptr %slot1159, align 8
  %v7493 = load i64, ptr %slot1159, align 8
  %v7494 = load i64, ptr %slot1156, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v7493, i64 %v7494) nomerge, !dbg !206
  br label %bb_rcslotdone1623
bb_rcslotowner1623:
  %v7495 = load i64, ptr %slot96, align 8
  store i64 %v7495, ptr %slot1160, align 8
  %v7496 = load i64, ptr %slot1160, align 8
  %v7497 = load i64, ptr %slot1156, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v7496, i64 %v7497) nomerge, !dbg !206
  br label %bb_rcslotdone1623
bb_rcslotdone1623:
  br label %bb_rcprepared1597
bb_rcprepared1597:
  %v7498 = load i64, ptr %slot41, align 8
  store i64 %v7498, ptr %slot1161, align 8
  %v7499 = load i64, ptr %slot34, align 8
  %p7500 = inttoptr i64 %v7499 to ptr
  store i32 0, ptr %p7500, align 4, !alias.scope !3, !noalias !4
  %v7501 = load i64, ptr %slot43, align 8
  %p7503 = inttoptr i64 %v7501 to ptr
  %gep7504 = getelementptr i8, ptr %p7503, i64 24
  %op7502 = ptrtoint ptr %gep7504 to i64
  store i64 %op7502, ptr %slot1162, align 8
  %v7505 = load i64, ptr %slot1162, align 8
  %p7506 = inttoptr i64 %v7505 to ptr
  %ld7507 = load i32, ptr %p7506, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7507, ptr %slot1163, align 8
  %v7508 = load i32, ptr %slot1163, align 8
  %cv7509 = zext i32 %v7508 to i64
  %cond7510 = icmp ne i64 %cv7509, 0
  br i1 %cond7510, label %bb_rcscopesopen1634, label %bb_rcscopesclosed1634
bb_rcscopesopen1634:
  %v7511 = load i64, ptr %slot45, align 8
  %p7513 = inttoptr i64 %v7511 to ptr
  %gep7514 = getelementptr i8, ptr %p7513, i64 0
  %op7512 = ptrtoint ptr %gep7514 to i64
  store i64 %op7512, ptr %slot1164, align 8
  %v7515 = load i64, ptr %slot43, align 8
  %v7516 = load i64, ptr %slot1164, align 8
  %p7517 = inttoptr i64 %v7516 to ptr
  store i64 %v7515, ptr %p7517, align 8, !alias.scope !3, !noalias !4
  %v7518 = load i64, ptr %slot1, align 8
  %p7519 = inttoptr i64 %v7518 to ptr
  %v7520 = load i64, ptr %slot45, align 8
  %p7521 = inttoptr i64 %v7520 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p7519, ptr %p7521, i64 1) nomerge, !dbg !206
  br label %bb_rcscopesclosed1634
bb_rcscopesclosed1634:
  %v7522 = load i64, ptr %slot28, align 8
  %p7523 = inttoptr i64 %v7522 to ptr
  %ld7524 = load i32, ptr %p7523, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7524, ptr %slot1165, align 8
  %v7525 = load i32, ptr %slot1165, align 8
  %cv7526 = zext i32 %v7525 to i64
  %cond7527 = icmp ne i64 %cv7526, 0
  br i1 %cond7527, label %bb_rcslotdrop1638, label %bb_rcslotdone1638
bb_rcslotdrop1638:
  %v7528 = load i64, ptr %slot28, align 8
  %p7529 = inttoptr i64 %v7528 to ptr
  store i32 0, ptr %p7529, align 4, !alias.scope !3, !noalias !4
  %v7530 = load i64, ptr %slot37, align 8
  store i64 %v7530, ptr %slot1166, align 8
  %v7531 = load i64, ptr %slot29, align 8
  %p7532 = inttoptr i64 %v7531 to ptr
  %ld7533 = load i32, ptr %p7532, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7533, ptr %slot1167, align 8
  %v7534 = load i32, ptr %slot1167, align 8
  %op7535 = and i32 %v7534, 28
  store i32 %op7535, ptr %slot1168, align 8
  %v7536 = load i32, ptr %slot1168, align 8
  %cv7537 = zext i32 %v7536 to i64
  %cond7538 = icmp ne i64 %cv7537, 0
  br i1 %cond7538, label %bb_rcslotrole1638, label %bb_rcslotowner1638
bb_rcslotrole1638:
  %v7539 = load i64, ptr %slot96, align 8
  store i64 %v7539, ptr %slot1169, align 8
  %v7540 = load i64, ptr %slot1169, align 8
  %v7541 = load i64, ptr %slot1166, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v7540, i64 %v7541) nomerge, !dbg !206
  br label %bb_rcslotdone1638
bb_rcslotowner1638:
  %v7542 = load i64, ptr %slot96, align 8
  store i64 %v7542, ptr %slot1170, align 8
  %v7543 = load i64, ptr %slot1170, align 8
  %v7544 = load i64, ptr %slot1166, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v7543, i64 %v7544) nomerge, !dbg !206
  br label %bb_rcslotdone1638
bb_rcslotdone1638:
  %v7545 = load i64, ptr %slot26, align 8
  %p7546 = inttoptr i64 %v7545 to ptr
  %ld7547 = load i32, ptr %p7546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7547, ptr %slot1171, align 8
  %v7548 = load i32, ptr %slot1171, align 8
  %cv7549 = zext i32 %v7548 to i64
  %cond7550 = icmp ne i64 %cv7549, 0
  br i1 %cond7550, label %bb_rcslotdrop1665, label %bb_rcslotdone1665
bb_rcslotdrop1665:
  %v7551 = load i64, ptr %slot26, align 8
  %p7552 = inttoptr i64 %v7551 to ptr
  store i32 0, ptr %p7552, align 4, !alias.scope !3, !noalias !4
  %v7553 = load i64, ptr %slot68, align 8
  store i64 %v7553, ptr %slot1172, align 8
  %v7554 = load i64, ptr %slot27, align 8
  %p7555 = inttoptr i64 %v7554 to ptr
  %ld7556 = load i32, ptr %p7555, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7556, ptr %slot1173, align 8
  %v7557 = load i32, ptr %slot1173, align 8
  %op7558 = and i32 %v7557, 28
  store i32 %op7558, ptr %slot1174, align 8
  %v7559 = load i32, ptr %slot1174, align 8
  %cv7560 = zext i32 %v7559 to i64
  %cond7561 = icmp ne i64 %cv7560, 0
  br i1 %cond7561, label %bb_rcslotrole1665, label %bb_rcslotowner1665
bb_rcslotrole1665:
  %v7562 = load i64, ptr %slot96, align 8
  store i64 %v7562, ptr %slot1175, align 8
  %v7563 = load i64, ptr %slot1175, align 8
  %v7564 = load i64, ptr %slot1172, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7563, i64 %v7564) nomerge, !dbg !206
  br label %bb_rcslotdone1665
bb_rcslotowner1665:
  %v7565 = load i64, ptr %slot96, align 8
  store i64 %v7565, ptr %slot1176, align 8
  %v7566 = load i64, ptr %slot1176, align 8
  %v7567 = load i64, ptr %slot1172, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7566, i64 %v7567) nomerge, !dbg !206
  br label %bb_rcslotdone1665
bb_rcslotdone1665:
  %v7568 = load i64, ptr %slot24, align 8
  %p7569 = inttoptr i64 %v7568 to ptr
  %ld7570 = load i32, ptr %p7569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7570, ptr %slot1177, align 8
  %v7571 = load i32, ptr %slot1177, align 8
  %cv7572 = zext i32 %v7571 to i64
  %cond7573 = icmp ne i64 %cv7572, 0
  br i1 %cond7573, label %bb_rcslotdrop1674, label %bb_rcslotdone1674
bb_rcslotdrop1674:
  %v7574 = load i64, ptr %slot24, align 8
  %p7575 = inttoptr i64 %v7574 to ptr
  store i32 0, ptr %p7575, align 4, !alias.scope !3, !noalias !4
  %v7576 = load i64, ptr %slot67, align 8
  store i64 %v7576, ptr %slot1178, align 8
  %v7577 = load i64, ptr %slot25, align 8
  %p7578 = inttoptr i64 %v7577 to ptr
  %ld7579 = load i32, ptr %p7578, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7579, ptr %slot1179, align 8
  %v7580 = load i32, ptr %slot1179, align 8
  %op7581 = and i32 %v7580, 28
  store i32 %op7581, ptr %slot1180, align 8
  %v7582 = load i32, ptr %slot1180, align 8
  %cv7583 = zext i32 %v7582 to i64
  %cond7584 = icmp ne i64 %cv7583, 0
  br i1 %cond7584, label %bb_rcslotrole1674, label %bb_rcslotowner1674
bb_rcslotrole1674:
  %v7585 = load i64, ptr %slot96, align 8
  store i64 %v7585, ptr %slot1181, align 8
  %v7586 = load i64, ptr %slot1178, align 8
  %p7587 = inttoptr i64 %v7586 to ptr
  %ld7588 = load i64, ptr %p7587, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7588, ptr %slot1182, align 8
  %v7589 = load i64, ptr %slot1182, align 8
  %cmp7590 = icmp ne i64 %v7589, 0
  %cv7591 = zext i1 %cmp7590 to i32
  store i32 %cv7591, ptr %slot1183, align 8
  %v7592 = load i32, ptr %slot1183, align 8
  %cv7593 = zext i32 %v7592 to i64
  %cond7594 = icmp ne i64 %cv7593, 0
  br i1 %cond7594, label %bb_rcgnn1690, label %bb_rcgdone1690
bb_rcgnn1690:
  %v7595 = load i64, ptr %slot1182, align 8
  %op7596 = sub i64 %v7595, 16
  store i64 %op7596, ptr %slot1184, align 8
  %v7597 = load i64, ptr %slot1182, align 8
  %p7598 = inttoptr i64 %v7597 to ptr
  %rgep7599 = getelementptr i8, ptr %p7598, i64 -16
  %ld7600 = load i64, ptr %rgep7599, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7600, ptr %slot1185, align 8
  %v7601 = load i64, ptr %slot1185, align 8
  %op7602 = and i64 %v7601, 4611686018427387906
  store i64 %op7602, ptr %slot1186, align 8
  %v7603 = load i64, ptr %slot1186, align 8
  %cmp7604 = icmp ne i64 %v7603, 0
  %cv7605 = zext i1 %cmp7604 to i32
  store i32 %cv7605, ptr %slot1187, align 8
  %v7606 = load i32, ptr %slot1187, align 8
  %cv7607 = zext i32 %v7606 to i64
  %cond7608 = icmp ne i64 %cv7607, 0
  br i1 %cond7608, label %bb_rcgclear1690, label %bb_rcgcounted1690
bb_rcgcounted1690:
  %v7609 = load i64, ptr %slot1182, align 8
  %op7610 = sub i64 %v7609, 24
  store i64 %op7610, ptr %slot1188, align 8
  %v7611 = load i64, ptr %slot1182, align 8
  %p7612 = inttoptr i64 %v7611 to ptr
  %rgep7613 = getelementptr i8, ptr %p7612, i64 -24
  %ld7614 = load i64, ptr %rgep7613, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7614, ptr %slot1189, align 8
  %v7615 = load i64, ptr %slot1189, align 8
  %op7616 = sub i64 %v7615, 1
  store i64 %op7616, ptr %slot1190, align 8
  %v7617 = load i64, ptr %slot1190, align 8
  %cmp7618 = icmp eq i64 %v7617, 0
  %cv7619 = zext i1 %cmp7618 to i32
  store i32 %cv7619, ptr %slot1191, align 8
  %v7620 = load i32, ptr %slot1191, align 8
  %cv7621 = zext i32 %v7620 to i64
  %cond7622 = icmp ne i64 %cv7621, 0
  br i1 %cond7622, label %bb_rcglast1690, label %bb_rcgdec1690
bb_rcglast1690:
  %v7623 = load i64, ptr %slot1182, align 8
  %op7624 = sub i64 %v7623, 32
  store i64 %op7624, ptr %slot1192, align 8
  %v7625 = load i64, ptr %slot1182, align 8
  %p7626 = inttoptr i64 %v7625 to ptr
  %rgep7627 = getelementptr i8, ptr %p7626, i64 -32
  %ld7628 = load i64, ptr %rgep7627, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7628, ptr %slot1193, align 8
  %v7629 = load i64, ptr %slot1193, align 8
  %cmp7630 = icmp ne i64 %v7629, 0
  %cv7631 = zext i1 %cmp7630 to i32
  store i32 %cv7631, ptr %slot1194, align 8
  %v7632 = load i32, ptr %slot1194, align 8
  %cv7633 = zext i32 %v7632 to i64
  %cond7634 = icmp ne i64 %cv7633, 0
  br i1 %cond7634, label %bb_rcgdec1690, label %bb_rcgslow1690
bb_rcgslow1690:
  %v7635 = load i64, ptr %slot1181, align 8
  %v7636 = load i64, ptr %slot1178, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v7635, i64 %v7636) nomerge, !dbg !206
  br label %bb_rcgdone1690
bb_rcgdec1690:
  %v7637 = load i64, ptr %slot1190, align 8
  %v7638 = load i64, ptr %slot1182, align 8
  %p7639 = inttoptr i64 %v7638 to ptr
  %rgep7640 = getelementptr i8, ptr %p7639, i64 -24
  store i64 %v7637, ptr %rgep7640, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1690
bb_rcgclear1690:
  %v7641 = load i64, ptr %slot1178, align 8
  %p7642 = inttoptr i64 %v7641 to ptr
  store i64 0, ptr %p7642, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1690
bb_rcgdone1690:
  br label %bb_rcslotdone1674
bb_rcslotowner1674:
  %v7643 = load i64, ptr %slot96, align 8
  store i64 %v7643, ptr %slot1195, align 8
  %v7644 = load i64, ptr %slot1178, align 8
  %p7645 = inttoptr i64 %v7644 to ptr
  %ld7646 = load i64, ptr %p7645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7646, ptr %slot1196, align 8
  %v7647 = load i64, ptr %slot1196, align 8
  %cmp7648 = icmp ne i64 %v7647, 0
  %cv7649 = zext i1 %cmp7648 to i32
  store i32 %cv7649, ptr %slot1197, align 8
  %v7650 = load i32, ptr %slot1197, align 8
  %cv7651 = zext i32 %v7650 to i64
  %cond7652 = icmp ne i64 %cv7651, 0
  br i1 %cond7652, label %bb_rcgnn1705, label %bb_rcgdone1705
bb_rcgnn1705:
  %v7653 = load i64, ptr %slot1196, align 8
  %op7654 = sub i64 %v7653, 16
  store i64 %op7654, ptr %slot1198, align 8
  %v7655 = load i64, ptr %slot1196, align 8
  %p7656 = inttoptr i64 %v7655 to ptr
  %rgep7657 = getelementptr i8, ptr %p7656, i64 -16
  %ld7658 = load i64, ptr %rgep7657, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7658, ptr %slot1199, align 8
  %v7659 = load i64, ptr %slot1199, align 8
  %op7660 = and i64 %v7659, 4611686018427387906
  store i64 %op7660, ptr %slot1200, align 8
  %v7661 = load i64, ptr %slot1200, align 8
  %cmp7662 = icmp ne i64 %v7661, 0
  %cv7663 = zext i1 %cmp7662 to i32
  store i32 %cv7663, ptr %slot1201, align 8
  %v7664 = load i32, ptr %slot1201, align 8
  %cv7665 = zext i32 %v7664 to i64
  %cond7666 = icmp ne i64 %cv7665, 0
  br i1 %cond7666, label %bb_rcgclear1705, label %bb_rcgcounted1705
bb_rcgcounted1705:
  %v7667 = load i64, ptr %slot1196, align 8
  %op7668 = sub i64 %v7667, 32
  store i64 %op7668, ptr %slot1202, align 8
  %v7669 = load i64, ptr %slot1196, align 8
  %p7670 = inttoptr i64 %v7669 to ptr
  %rgep7671 = getelementptr i8, ptr %p7670, i64 -32
  %ld7672 = load i64, ptr %rgep7671, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7672, ptr %slot1203, align 8
  %v7673 = load i64, ptr %slot1203, align 8
  %op7674 = sub i64 %v7673, 1
  store i64 %op7674, ptr %slot1204, align 8
  %v7675 = load i64, ptr %slot1204, align 8
  %cmp7676 = icmp eq i64 %v7675, 0
  %cv7677 = zext i1 %cmp7676 to i32
  store i32 %cv7677, ptr %slot1205, align 8
  %v7678 = load i32, ptr %slot1205, align 8
  %cv7679 = zext i32 %v7678 to i64
  %cond7680 = icmp ne i64 %cv7679, 0
  br i1 %cond7680, label %bb_rcglast1705, label %bb_rcgdec1705
bb_rcglast1705:
  %v7681 = load i64, ptr %slot1196, align 8
  %op7682 = sub i64 %v7681, 24
  store i64 %op7682, ptr %slot1206, align 8
  %v7683 = load i64, ptr %slot1196, align 8
  %p7684 = inttoptr i64 %v7683 to ptr
  %rgep7685 = getelementptr i8, ptr %p7684, i64 -24
  %ld7686 = load i64, ptr %rgep7685, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7686, ptr %slot1207, align 8
  %v7687 = load i64, ptr %slot1207, align 8
  %cmp7688 = icmp ne i64 %v7687, 0
  %cv7689 = zext i1 %cmp7688 to i32
  store i32 %cv7689, ptr %slot1208, align 8
  %v7690 = load i32, ptr %slot1208, align 8
  %cv7691 = zext i32 %v7690 to i64
  %cond7692 = icmp ne i64 %cv7691, 0
  br i1 %cond7692, label %bb_rcgdec1705, label %bb_rcgslow1705
bb_rcgslow1705:
  %v7693 = load i64, ptr %slot1195, align 8
  %v7694 = load i64, ptr %slot1178, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v7693, i64 %v7694) nomerge, !dbg !206
  br label %bb_rcgdone1705
bb_rcgdec1705:
  %v7695 = load i64, ptr %slot1204, align 8
  %v7696 = load i64, ptr %slot1196, align 8
  %p7697 = inttoptr i64 %v7696 to ptr
  %rgep7698 = getelementptr i8, ptr %p7697, i64 -32
  store i64 %v7695, ptr %rgep7698, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1705
bb_rcgclear1705:
  %v7699 = load i64, ptr %slot1178, align 8
  %p7700 = inttoptr i64 %v7699 to ptr
  store i64 0, ptr %p7700, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1705
bb_rcgdone1705:
  br label %bb_rcslotdone1674
bb_rcslotdone1674:
  %v7701 = load i64, ptr %slot22, align 8
  %p7702 = inttoptr i64 %v7701 to ptr
  %ld7703 = load i32, ptr %p7702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7703, ptr %slot1209, align 8
  %v7704 = load i32, ptr %slot1209, align 8
  %cv7705 = zext i32 %v7704 to i64
  %cond7706 = icmp ne i64 %cv7705, 0
  br i1 %cond7706, label %bb_rcslotdrop1711, label %bb_rcslotdone1711
bb_rcslotdrop1711:
  %v7707 = load i64, ptr %slot22, align 8
  %p7708 = inttoptr i64 %v7707 to ptr
  store i32 0, ptr %p7708, align 4, !alias.scope !3, !noalias !4
  %v7709 = load i64, ptr %slot66, align 8
  store i64 %v7709, ptr %slot1210, align 8
  %v7710 = load i64, ptr %slot23, align 8
  %p7711 = inttoptr i64 %v7710 to ptr
  %ld7712 = load i32, ptr %p7711, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7712, ptr %slot1211, align 8
  %v7713 = load i32, ptr %slot1211, align 8
  %op7714 = and i32 %v7713, 28
  store i32 %op7714, ptr %slot1212, align 8
  %v7715 = load i32, ptr %slot1212, align 8
  %cv7716 = zext i32 %v7715 to i64
  %cond7717 = icmp ne i64 %cv7716, 0
  br i1 %cond7717, label %bb_rcslotrole1711, label %bb_rcslotowner1711
bb_rcslotrole1711:
  %v7718 = load i64, ptr %slot96, align 8
  store i64 %v7718, ptr %slot1213, align 8
  %v7719 = load i64, ptr %slot1210, align 8
  %p7720 = inttoptr i64 %v7719 to ptr
  %ld7721 = load i64, ptr %p7720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7721, ptr %slot1214, align 8
  %v7722 = load i64, ptr %slot1214, align 8
  %cmp7723 = icmp ne i64 %v7722, 0
  %cv7724 = zext i1 %cmp7723 to i32
  store i32 %cv7724, ptr %slot1215, align 8
  %v7725 = load i32, ptr %slot1215, align 8
  %cv7726 = zext i32 %v7725 to i64
  %cond7727 = icmp ne i64 %cv7726, 0
  br i1 %cond7727, label %bb_rcgnn1727, label %bb_rcgdone1727
bb_rcgnn1727:
  %v7728 = load i64, ptr %slot1214, align 8
  %op7729 = sub i64 %v7728, 16
  store i64 %op7729, ptr %slot1216, align 8
  %v7730 = load i64, ptr %slot1214, align 8
  %p7731 = inttoptr i64 %v7730 to ptr
  %rgep7732 = getelementptr i8, ptr %p7731, i64 -16
  %ld7733 = load i64, ptr %rgep7732, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7733, ptr %slot1217, align 8
  %v7734 = load i64, ptr %slot1217, align 8
  %op7735 = and i64 %v7734, 4611686018427387906
  store i64 %op7735, ptr %slot1218, align 8
  %v7736 = load i64, ptr %slot1218, align 8
  %cmp7737 = icmp ne i64 %v7736, 0
  %cv7738 = zext i1 %cmp7737 to i32
  store i32 %cv7738, ptr %slot1219, align 8
  %v7739 = load i32, ptr %slot1219, align 8
  %cv7740 = zext i32 %v7739 to i64
  %cond7741 = icmp ne i64 %cv7740, 0
  br i1 %cond7741, label %bb_rcgclear1727, label %bb_rcgcounted1727
bb_rcgcounted1727:
  %v7742 = load i64, ptr %slot1214, align 8
  %op7743 = sub i64 %v7742, 24
  store i64 %op7743, ptr %slot1220, align 8
  %v7744 = load i64, ptr %slot1214, align 8
  %p7745 = inttoptr i64 %v7744 to ptr
  %rgep7746 = getelementptr i8, ptr %p7745, i64 -24
  %ld7747 = load i64, ptr %rgep7746, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7747, ptr %slot1221, align 8
  %v7748 = load i64, ptr %slot1221, align 8
  %op7749 = sub i64 %v7748, 1
  store i64 %op7749, ptr %slot1222, align 8
  %v7750 = load i64, ptr %slot1222, align 8
  %cmp7751 = icmp eq i64 %v7750, 0
  %cv7752 = zext i1 %cmp7751 to i32
  store i32 %cv7752, ptr %slot1223, align 8
  %v7753 = load i32, ptr %slot1223, align 8
  %cv7754 = zext i32 %v7753 to i64
  %cond7755 = icmp ne i64 %cv7754, 0
  br i1 %cond7755, label %bb_rcglast1727, label %bb_rcgdec1727
bb_rcglast1727:
  %v7756 = load i64, ptr %slot1214, align 8
  %op7757 = sub i64 %v7756, 32
  store i64 %op7757, ptr %slot1224, align 8
  %v7758 = load i64, ptr %slot1214, align 8
  %p7759 = inttoptr i64 %v7758 to ptr
  %rgep7760 = getelementptr i8, ptr %p7759, i64 -32
  %ld7761 = load i64, ptr %rgep7760, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7761, ptr %slot1225, align 8
  %v7762 = load i64, ptr %slot1225, align 8
  %cmp7763 = icmp ne i64 %v7762, 0
  %cv7764 = zext i1 %cmp7763 to i32
  store i32 %cv7764, ptr %slot1226, align 8
  %v7765 = load i32, ptr %slot1226, align 8
  %cv7766 = zext i32 %v7765 to i64
  %cond7767 = icmp ne i64 %cv7766, 0
  br i1 %cond7767, label %bb_rcgdec1727, label %bb_rcgslow1727
bb_rcgslow1727:
  %v7768 = load i64, ptr %slot1213, align 8
  %v7769 = load i64, ptr %slot1210, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v7768, i64 %v7769) nomerge, !dbg !206
  br label %bb_rcgdone1727
bb_rcgdec1727:
  %v7770 = load i64, ptr %slot1222, align 8
  %v7771 = load i64, ptr %slot1214, align 8
  %p7772 = inttoptr i64 %v7771 to ptr
  %rgep7773 = getelementptr i8, ptr %p7772, i64 -24
  store i64 %v7770, ptr %rgep7773, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1727
bb_rcgclear1727:
  %v7774 = load i64, ptr %slot1210, align 8
  %p7775 = inttoptr i64 %v7774 to ptr
  store i64 0, ptr %p7775, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1727
bb_rcgdone1727:
  br label %bb_rcslotdone1711
bb_rcslotowner1711:
  %v7776 = load i64, ptr %slot96, align 8
  store i64 %v7776, ptr %slot1227, align 8
  %v7777 = load i64, ptr %slot1210, align 8
  %p7778 = inttoptr i64 %v7777 to ptr
  %ld7779 = load i64, ptr %p7778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7779, ptr %slot1228, align 8
  %v7780 = load i64, ptr %slot1228, align 8
  %cmp7781 = icmp ne i64 %v7780, 0
  %cv7782 = zext i1 %cmp7781 to i32
  store i32 %cv7782, ptr %slot1229, align 8
  %v7783 = load i32, ptr %slot1229, align 8
  %cv7784 = zext i32 %v7783 to i64
  %cond7785 = icmp ne i64 %cv7784, 0
  br i1 %cond7785, label %bb_rcgnn1742, label %bb_rcgdone1742
bb_rcgnn1742:
  %v7786 = load i64, ptr %slot1228, align 8
  %op7787 = sub i64 %v7786, 16
  store i64 %op7787, ptr %slot1230, align 8
  %v7788 = load i64, ptr %slot1228, align 8
  %p7789 = inttoptr i64 %v7788 to ptr
  %rgep7790 = getelementptr i8, ptr %p7789, i64 -16
  %ld7791 = load i64, ptr %rgep7790, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7791, ptr %slot1231, align 8
  %v7792 = load i64, ptr %slot1231, align 8
  %op7793 = and i64 %v7792, 4611686018427387906
  store i64 %op7793, ptr %slot1232, align 8
  %v7794 = load i64, ptr %slot1232, align 8
  %cmp7795 = icmp ne i64 %v7794, 0
  %cv7796 = zext i1 %cmp7795 to i32
  store i32 %cv7796, ptr %slot1233, align 8
  %v7797 = load i32, ptr %slot1233, align 8
  %cv7798 = zext i32 %v7797 to i64
  %cond7799 = icmp ne i64 %cv7798, 0
  br i1 %cond7799, label %bb_rcgclear1742, label %bb_rcgcounted1742
bb_rcgcounted1742:
  %v7800 = load i64, ptr %slot1228, align 8
  %op7801 = sub i64 %v7800, 32
  store i64 %op7801, ptr %slot1234, align 8
  %v7802 = load i64, ptr %slot1228, align 8
  %p7803 = inttoptr i64 %v7802 to ptr
  %rgep7804 = getelementptr i8, ptr %p7803, i64 -32
  %ld7805 = load i64, ptr %rgep7804, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7805, ptr %slot1235, align 8
  %v7806 = load i64, ptr %slot1235, align 8
  %op7807 = sub i64 %v7806, 1
  store i64 %op7807, ptr %slot1236, align 8
  %v7808 = load i64, ptr %slot1236, align 8
  %cmp7809 = icmp eq i64 %v7808, 0
  %cv7810 = zext i1 %cmp7809 to i32
  store i32 %cv7810, ptr %slot1237, align 8
  %v7811 = load i32, ptr %slot1237, align 8
  %cv7812 = zext i32 %v7811 to i64
  %cond7813 = icmp ne i64 %cv7812, 0
  br i1 %cond7813, label %bb_rcglast1742, label %bb_rcgdec1742
bb_rcglast1742:
  %v7814 = load i64, ptr %slot1228, align 8
  %op7815 = sub i64 %v7814, 24
  store i64 %op7815, ptr %slot1238, align 8
  %v7816 = load i64, ptr %slot1228, align 8
  %p7817 = inttoptr i64 %v7816 to ptr
  %rgep7818 = getelementptr i8, ptr %p7817, i64 -24
  %ld7819 = load i64, ptr %rgep7818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7819, ptr %slot1239, align 8
  %v7820 = load i64, ptr %slot1239, align 8
  %cmp7821 = icmp ne i64 %v7820, 0
  %cv7822 = zext i1 %cmp7821 to i32
  store i32 %cv7822, ptr %slot1240, align 8
  %v7823 = load i32, ptr %slot1240, align 8
  %cv7824 = zext i32 %v7823 to i64
  %cond7825 = icmp ne i64 %cv7824, 0
  br i1 %cond7825, label %bb_rcgdec1742, label %bb_rcgslow1742
bb_rcgslow1742:
  %v7826 = load i64, ptr %slot1227, align 8
  %v7827 = load i64, ptr %slot1210, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v7826, i64 %v7827) nomerge, !dbg !206
  br label %bb_rcgdone1742
bb_rcgdec1742:
  %v7828 = load i64, ptr %slot1236, align 8
  %v7829 = load i64, ptr %slot1228, align 8
  %p7830 = inttoptr i64 %v7829 to ptr
  %rgep7831 = getelementptr i8, ptr %p7830, i64 -32
  store i64 %v7828, ptr %rgep7831, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1742
bb_rcgclear1742:
  %v7832 = load i64, ptr %slot1210, align 8
  %p7833 = inttoptr i64 %v7832 to ptr
  store i64 0, ptr %p7833, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1742
bb_rcgdone1742:
  br label %bb_rcslotdone1711
bb_rcslotdone1711:
  %v7834 = load i64, ptr %slot20, align 8
  %p7835 = inttoptr i64 %v7834 to ptr
  %ld7836 = load i32, ptr %p7835, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7836, ptr %slot1241, align 8
  %v7837 = load i32, ptr %slot1241, align 8
  %cv7838 = zext i32 %v7837 to i64
  %cond7839 = icmp ne i64 %cv7838, 0
  br i1 %cond7839, label %bb_rcslotdrop1748, label %bb_rcslotdone1748
bb_rcslotdrop1748:
  %v7840 = load i64, ptr %slot20, align 8
  %p7841 = inttoptr i64 %v7840 to ptr
  store i32 0, ptr %p7841, align 4, !alias.scope !3, !noalias !4
  %v7842 = load i64, ptr %slot65, align 8
  store i64 %v7842, ptr %slot1242, align 8
  %v7843 = load i64, ptr %slot21, align 8
  %p7844 = inttoptr i64 %v7843 to ptr
  %ld7845 = load i32, ptr %p7844, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7845, ptr %slot1243, align 8
  %v7846 = load i32, ptr %slot1243, align 8
  %op7847 = and i32 %v7846, 28
  store i32 %op7847, ptr %slot1244, align 8
  %v7848 = load i32, ptr %slot1244, align 8
  %cv7849 = zext i32 %v7848 to i64
  %cond7850 = icmp ne i64 %cv7849, 0
  br i1 %cond7850, label %bb_rcslotrole1748, label %bb_rcslotowner1748
bb_rcslotrole1748:
  %v7851 = load i64, ptr %slot96, align 8
  store i64 %v7851, ptr %slot1245, align 8
  %v7852 = load i64, ptr %slot1242, align 8
  %p7853 = inttoptr i64 %v7852 to ptr
  %ld7854 = load i64, ptr %p7853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7854, ptr %slot1246, align 8
  %v7855 = load i64, ptr %slot1246, align 8
  %cmp7856 = icmp ne i64 %v7855, 0
  %cv7857 = zext i1 %cmp7856 to i32
  store i32 %cv7857, ptr %slot1247, align 8
  %v7858 = load i32, ptr %slot1247, align 8
  %cv7859 = zext i32 %v7858 to i64
  %cond7860 = icmp ne i64 %cv7859, 0
  br i1 %cond7860, label %bb_rcgnn1764, label %bb_rcgdone1764
bb_rcgnn1764:
  %v7861 = load i64, ptr %slot1246, align 8
  %op7862 = sub i64 %v7861, 16
  store i64 %op7862, ptr %slot1248, align 8
  %v7863 = load i64, ptr %slot1246, align 8
  %p7864 = inttoptr i64 %v7863 to ptr
  %rgep7865 = getelementptr i8, ptr %p7864, i64 -16
  %ld7866 = load i64, ptr %rgep7865, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7866, ptr %slot1249, align 8
  %v7867 = load i64, ptr %slot1249, align 8
  %op7868 = and i64 %v7867, 4611686018427387906
  store i64 %op7868, ptr %slot1250, align 8
  %v7869 = load i64, ptr %slot1250, align 8
  %cmp7870 = icmp ne i64 %v7869, 0
  %cv7871 = zext i1 %cmp7870 to i32
  store i32 %cv7871, ptr %slot1251, align 8
  %v7872 = load i32, ptr %slot1251, align 8
  %cv7873 = zext i32 %v7872 to i64
  %cond7874 = icmp ne i64 %cv7873, 0
  br i1 %cond7874, label %bb_rcgclear1764, label %bb_rcgcounted1764
bb_rcgcounted1764:
  %v7875 = load i64, ptr %slot1246, align 8
  %op7876 = sub i64 %v7875, 24
  store i64 %op7876, ptr %slot1252, align 8
  %v7877 = load i64, ptr %slot1246, align 8
  %p7878 = inttoptr i64 %v7877 to ptr
  %rgep7879 = getelementptr i8, ptr %p7878, i64 -24
  %ld7880 = load i64, ptr %rgep7879, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7880, ptr %slot1253, align 8
  %v7881 = load i64, ptr %slot1253, align 8
  %op7882 = sub i64 %v7881, 1
  store i64 %op7882, ptr %slot1254, align 8
  %v7883 = load i64, ptr %slot1254, align 8
  %cmp7884 = icmp eq i64 %v7883, 0
  %cv7885 = zext i1 %cmp7884 to i32
  store i32 %cv7885, ptr %slot1255, align 8
  %v7886 = load i32, ptr %slot1255, align 8
  %cv7887 = zext i32 %v7886 to i64
  %cond7888 = icmp ne i64 %cv7887, 0
  br i1 %cond7888, label %bb_rcglast1764, label %bb_rcgdec1764
bb_rcglast1764:
  %v7889 = load i64, ptr %slot1246, align 8
  %op7890 = sub i64 %v7889, 32
  store i64 %op7890, ptr %slot1256, align 8
  %v7891 = load i64, ptr %slot1246, align 8
  %p7892 = inttoptr i64 %v7891 to ptr
  %rgep7893 = getelementptr i8, ptr %p7892, i64 -32
  %ld7894 = load i64, ptr %rgep7893, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7894, ptr %slot1257, align 8
  %v7895 = load i64, ptr %slot1257, align 8
  %cmp7896 = icmp ne i64 %v7895, 0
  %cv7897 = zext i1 %cmp7896 to i32
  store i32 %cv7897, ptr %slot1258, align 8
  %v7898 = load i32, ptr %slot1258, align 8
  %cv7899 = zext i32 %v7898 to i64
  %cond7900 = icmp ne i64 %cv7899, 0
  br i1 %cond7900, label %bb_rcgdec1764, label %bb_rcgslow1764
bb_rcgslow1764:
  %v7901 = load i64, ptr %slot1245, align 8
  %v7902 = load i64, ptr %slot1242, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v7901, i64 %v7902) nomerge, !dbg !206
  br label %bb_rcgdone1764
bb_rcgdec1764:
  %v7903 = load i64, ptr %slot1254, align 8
  %v7904 = load i64, ptr %slot1246, align 8
  %p7905 = inttoptr i64 %v7904 to ptr
  %rgep7906 = getelementptr i8, ptr %p7905, i64 -24
  store i64 %v7903, ptr %rgep7906, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1764
bb_rcgclear1764:
  %v7907 = load i64, ptr %slot1242, align 8
  %p7908 = inttoptr i64 %v7907 to ptr
  store i64 0, ptr %p7908, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1764
bb_rcgdone1764:
  br label %bb_rcslotdone1748
bb_rcslotowner1748:
  %v7909 = load i64, ptr %slot96, align 8
  store i64 %v7909, ptr %slot1259, align 8
  %v7910 = load i64, ptr %slot1242, align 8
  %p7911 = inttoptr i64 %v7910 to ptr
  %ld7912 = load i64, ptr %p7911, align 8, !alias.scope !3, !noalias !4
  store i64 %ld7912, ptr %slot1260, align 8
  %v7913 = load i64, ptr %slot1260, align 8
  %cmp7914 = icmp ne i64 %v7913, 0
  %cv7915 = zext i1 %cmp7914 to i32
  store i32 %cv7915, ptr %slot1261, align 8
  %v7916 = load i32, ptr %slot1261, align 8
  %cv7917 = zext i32 %v7916 to i64
  %cond7918 = icmp ne i64 %cv7917, 0
  br i1 %cond7918, label %bb_rcgnn1779, label %bb_rcgdone1779
bb_rcgnn1779:
  %v7919 = load i64, ptr %slot1260, align 8
  %op7920 = sub i64 %v7919, 16
  store i64 %op7920, ptr %slot1262, align 8
  %v7921 = load i64, ptr %slot1260, align 8
  %p7922 = inttoptr i64 %v7921 to ptr
  %rgep7923 = getelementptr i8, ptr %p7922, i64 -16
  %ld7924 = load i64, ptr %rgep7923, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7924, ptr %slot1263, align 8
  %v7925 = load i64, ptr %slot1263, align 8
  %op7926 = and i64 %v7925, 4611686018427387906
  store i64 %op7926, ptr %slot1264, align 8
  %v7927 = load i64, ptr %slot1264, align 8
  %cmp7928 = icmp ne i64 %v7927, 0
  %cv7929 = zext i1 %cmp7928 to i32
  store i32 %cv7929, ptr %slot1265, align 8
  %v7930 = load i32, ptr %slot1265, align 8
  %cv7931 = zext i32 %v7930 to i64
  %cond7932 = icmp ne i64 %cv7931, 0
  br i1 %cond7932, label %bb_rcgclear1779, label %bb_rcgcounted1779
bb_rcgcounted1779:
  %v7933 = load i64, ptr %slot1260, align 8
  %op7934 = sub i64 %v7933, 32
  store i64 %op7934, ptr %slot1266, align 8
  %v7935 = load i64, ptr %slot1260, align 8
  %p7936 = inttoptr i64 %v7935 to ptr
  %rgep7937 = getelementptr i8, ptr %p7936, i64 -32
  %ld7938 = load i64, ptr %rgep7937, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7938, ptr %slot1267, align 8
  %v7939 = load i64, ptr %slot1267, align 8
  %op7940 = sub i64 %v7939, 1
  store i64 %op7940, ptr %slot1268, align 8
  %v7941 = load i64, ptr %slot1268, align 8
  %cmp7942 = icmp eq i64 %v7941, 0
  %cv7943 = zext i1 %cmp7942 to i32
  store i32 %cv7943, ptr %slot1269, align 8
  %v7944 = load i32, ptr %slot1269, align 8
  %cv7945 = zext i32 %v7944 to i64
  %cond7946 = icmp ne i64 %cv7945, 0
  br i1 %cond7946, label %bb_rcglast1779, label %bb_rcgdec1779
bb_rcglast1779:
  %v7947 = load i64, ptr %slot1260, align 8
  %op7948 = sub i64 %v7947, 24
  store i64 %op7948, ptr %slot1270, align 8
  %v7949 = load i64, ptr %slot1260, align 8
  %p7950 = inttoptr i64 %v7949 to ptr
  %rgep7951 = getelementptr i8, ptr %p7950, i64 -24
  %ld7952 = load i64, ptr %rgep7951, align 8, !alias.scope !9, !noalias !10
  store i64 %ld7952, ptr %slot1271, align 8
  %v7953 = load i64, ptr %slot1271, align 8
  %cmp7954 = icmp ne i64 %v7953, 0
  %cv7955 = zext i1 %cmp7954 to i32
  store i32 %cv7955, ptr %slot1272, align 8
  %v7956 = load i32, ptr %slot1272, align 8
  %cv7957 = zext i32 %v7956 to i64
  %cond7958 = icmp ne i64 %cv7957, 0
  br i1 %cond7958, label %bb_rcgdec1779, label %bb_rcgslow1779
bb_rcgslow1779:
  %v7959 = load i64, ptr %slot1259, align 8
  %v7960 = load i64, ptr %slot1242, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v7959, i64 %v7960) nomerge, !dbg !206
  br label %bb_rcgdone1779
bb_rcgdec1779:
  %v7961 = load i64, ptr %slot1268, align 8
  %v7962 = load i64, ptr %slot1260, align 8
  %p7963 = inttoptr i64 %v7962 to ptr
  %rgep7964 = getelementptr i8, ptr %p7963, i64 -32
  store i64 %v7961, ptr %rgep7964, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1779
bb_rcgclear1779:
  %v7965 = load i64, ptr %slot1242, align 8
  %p7966 = inttoptr i64 %v7965 to ptr
  store i64 0, ptr %p7966, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1779
bb_rcgdone1779:
  br label %bb_rcslotdone1748
bb_rcslotdone1748:
  %v7967 = load i64, ptr %slot18, align 8
  %p7968 = inttoptr i64 %v7967 to ptr
  %ld7969 = load i32, ptr %p7968, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7969, ptr %slot1273, align 8
  %v7970 = load i32, ptr %slot1273, align 8
  %cv7971 = zext i32 %v7970 to i64
  %cond7972 = icmp ne i64 %cv7971, 0
  br i1 %cond7972, label %bb_rcslotdrop1803, label %bb_rcslotdone1803
bb_rcslotdrop1803:
  %v7973 = load i64, ptr %slot18, align 8
  %p7974 = inttoptr i64 %v7973 to ptr
  store i32 0, ptr %p7974, align 4, !alias.scope !3, !noalias !4
  %v7975 = load i64, ptr %slot64, align 8
  store i64 %v7975, ptr %slot1274, align 8
  %v7976 = load i64, ptr %slot19, align 8
  %p7977 = inttoptr i64 %v7976 to ptr
  %ld7978 = load i32, ptr %p7977, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7978, ptr %slot1275, align 8
  %v7979 = load i32, ptr %slot1275, align 8
  %op7980 = and i32 %v7979, 28
  store i32 %op7980, ptr %slot1276, align 8
  %v7981 = load i32, ptr %slot1276, align 8
  %cv7982 = zext i32 %v7981 to i64
  %cond7983 = icmp ne i64 %cv7982, 0
  br i1 %cond7983, label %bb_rcslotrole1803, label %bb_rcslotowner1803
bb_rcslotrole1803:
  %v7984 = load i64, ptr %slot96, align 8
  store i64 %v7984, ptr %slot1277, align 8
  %v7985 = load i64, ptr %slot1277, align 8
  %v7986 = load i64, ptr %slot1274, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v7985, i64 %v7986) nomerge, !dbg !206
  br label %bb_rcslotdone1803
bb_rcslotowner1803:
  %v7987 = load i64, ptr %slot96, align 8
  store i64 %v7987, ptr %slot1278, align 8
  %v7988 = load i64, ptr %slot1278, align 8
  %v7989 = load i64, ptr %slot1274, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v7988, i64 %v7989) nomerge, !dbg !206
  br label %bb_rcslotdone1803
bb_rcslotdone1803:
  %v7990 = load i64, ptr %slot16, align 8
  %p7991 = inttoptr i64 %v7990 to ptr
  %ld7992 = load i32, ptr %p7991, align 4, !alias.scope !3, !noalias !4
  store i32 %ld7992, ptr %slot1279, align 8
  %v7993 = load i32, ptr %slot1279, align 8
  %cv7994 = zext i32 %v7993 to i64
  %cond7995 = icmp ne i64 %cv7994, 0
  br i1 %cond7995, label %bb_rcslotdrop1830, label %bb_rcslotdone1830
bb_rcslotdrop1830:
  %v7996 = load i64, ptr %slot16, align 8
  %p7997 = inttoptr i64 %v7996 to ptr
  store i32 0, ptr %p7997, align 4, !alias.scope !3, !noalias !4
  %v7998 = load i64, ptr %slot62, align 8
  store i64 %v7998, ptr %slot1280, align 8
  %v7999 = load i64, ptr %slot17, align 8
  %p8000 = inttoptr i64 %v7999 to ptr
  %ld8001 = load i32, ptr %p8000, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8001, ptr %slot1281, align 8
  %v8002 = load i32, ptr %slot1281, align 8
  %op8003 = and i32 %v8002, 28
  store i32 %op8003, ptr %slot1282, align 8
  %v8004 = load i32, ptr %slot1282, align 8
  %cv8005 = zext i32 %v8004 to i64
  %cond8006 = icmp ne i64 %cv8005, 0
  br i1 %cond8006, label %bb_rcslotrole1830, label %bb_rcslotowner1830
bb_rcslotrole1830:
  %v8007 = load i64, ptr %slot96, align 8
  store i64 %v8007, ptr %slot1283, align 8
  %v8008 = load i64, ptr %slot1283, align 8
  %v8009 = load i64, ptr %slot1280, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8008, i64 %v8009) nomerge, !dbg !206
  br label %bb_rcslotdone1830
bb_rcslotowner1830:
  %v8010 = load i64, ptr %slot96, align 8
  store i64 %v8010, ptr %slot1284, align 8
  %v8011 = load i64, ptr %slot1284, align 8
  %v8012 = load i64, ptr %slot1280, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8011, i64 %v8012) nomerge, !dbg !206
  br label %bb_rcslotdone1830
bb_rcslotdone1830:
  %v8013 = load i64, ptr %slot14, align 8
  %p8014 = inttoptr i64 %v8013 to ptr
  %ld8015 = load i32, ptr %p8014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8015, ptr %slot1285, align 8
  %v8016 = load i32, ptr %slot1285, align 8
  %cv8017 = zext i32 %v8016 to i64
  %cond8018 = icmp ne i64 %cv8017, 0
  br i1 %cond8018, label %bb_rcslotdrop1857, label %bb_rcslotdone1857
bb_rcslotdrop1857:
  %v8019 = load i64, ptr %slot14, align 8
  %p8020 = inttoptr i64 %v8019 to ptr
  store i32 0, ptr %p8020, align 4, !alias.scope !3, !noalias !4
  %v8021 = load i64, ptr %slot61, align 8
  store i64 %v8021, ptr %slot1286, align 8
  %v8022 = load i64, ptr %slot15, align 8
  %p8023 = inttoptr i64 %v8022 to ptr
  %ld8024 = load i32, ptr %p8023, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8024, ptr %slot1287, align 8
  %v8025 = load i32, ptr %slot1287, align 8
  %op8026 = and i32 %v8025, 28
  store i32 %op8026, ptr %slot1288, align 8
  %v8027 = load i32, ptr %slot1288, align 8
  %cv8028 = zext i32 %v8027 to i64
  %cond8029 = icmp ne i64 %cv8028, 0
  br i1 %cond8029, label %bb_rcslotrole1857, label %bb_rcslotowner1857
bb_rcslotrole1857:
  %v8030 = load i64, ptr %slot96, align 8
  store i64 %v8030, ptr %slot1289, align 8
  %v8031 = load i64, ptr %slot1289, align 8
  %v8032 = load i64, ptr %slot1286, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8031, i64 %v8032) nomerge, !dbg !206
  br label %bb_rcslotdone1857
bb_rcslotowner1857:
  %v8033 = load i64, ptr %slot96, align 8
  store i64 %v8033, ptr %slot1290, align 8
  %v8034 = load i64, ptr %slot1290, align 8
  %v8035 = load i64, ptr %slot1286, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8034, i64 %v8035) nomerge, !dbg !206
  br label %bb_rcslotdone1857
bb_rcslotdone1857:
  %v8036 = load i64, ptr %slot12, align 8
  %p8037 = inttoptr i64 %v8036 to ptr
  %ld8038 = load i32, ptr %p8037, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8038, ptr %slot1291, align 8
  %v8039 = load i32, ptr %slot1291, align 8
  %cv8040 = zext i32 %v8039 to i64
  %cond8041 = icmp ne i64 %cv8040, 0
  br i1 %cond8041, label %bb_rcslotdrop1884, label %bb_rcslotdone1884
bb_rcslotdrop1884:
  %v8042 = load i64, ptr %slot12, align 8
  %p8043 = inttoptr i64 %v8042 to ptr
  store i32 0, ptr %p8043, align 4, !alias.scope !3, !noalias !4
  %v8044 = load i64, ptr %slot59, align 8
  store i64 %v8044, ptr %slot1292, align 8
  %v8045 = load i64, ptr %slot13, align 8
  %p8046 = inttoptr i64 %v8045 to ptr
  %ld8047 = load i32, ptr %p8046, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8047, ptr %slot1293, align 8
  %v8048 = load i32, ptr %slot1293, align 8
  %op8049 = and i32 %v8048, 28
  store i32 %op8049, ptr %slot1294, align 8
  %v8050 = load i32, ptr %slot1294, align 8
  %cv8051 = zext i32 %v8050 to i64
  %cond8052 = icmp ne i64 %cv8051, 0
  br i1 %cond8052, label %bb_rcslotrole1884, label %bb_rcslotowner1884
bb_rcslotrole1884:
  %v8053 = load i64, ptr %slot96, align 8
  store i64 %v8053, ptr %slot1295, align 8
  %v8054 = load i64, ptr %slot1295, align 8
  %v8055 = load i64, ptr %slot1292, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8054, i64 %v8055) nomerge, !dbg !206
  br label %bb_rcslotdone1884
bb_rcslotowner1884:
  %v8056 = load i64, ptr %slot96, align 8
  store i64 %v8056, ptr %slot1296, align 8
  %v8057 = load i64, ptr %slot1296, align 8
  %v8058 = load i64, ptr %slot1292, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8057, i64 %v8058) nomerge, !dbg !206
  br label %bb_rcslotdone1884
bb_rcslotdone1884:
  %v8059 = load i64, ptr %slot10, align 8
  %p8060 = inttoptr i64 %v8059 to ptr
  %ld8061 = load i32, ptr %p8060, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8061, ptr %slot1297, align 8
  %v8062 = load i32, ptr %slot1297, align 8
  %cv8063 = zext i32 %v8062 to i64
  %cond8064 = icmp ne i64 %cv8063, 0
  br i1 %cond8064, label %bb_rcslotdrop1893, label %bb_rcslotdone1893
bb_rcslotdrop1893:
  %v8065 = load i64, ptr %slot10, align 8
  %p8066 = inttoptr i64 %v8065 to ptr
  store i32 0, ptr %p8066, align 4, !alias.scope !3, !noalias !4
  %v8067 = load i64, ptr %slot56, align 8
  store i64 %v8067, ptr %slot1298, align 8
  %v8068 = load i64, ptr %slot11, align 8
  %p8069 = inttoptr i64 %v8068 to ptr
  %ld8070 = load i32, ptr %p8069, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8070, ptr %slot1299, align 8
  %v8071 = load i32, ptr %slot1299, align 8
  %op8072 = and i32 %v8071, 28
  store i32 %op8072, ptr %slot1300, align 8
  %v8073 = load i32, ptr %slot1300, align 8
  %cv8074 = zext i32 %v8073 to i64
  %cond8075 = icmp ne i64 %cv8074, 0
  br i1 %cond8075, label %bb_rcslotrole1893, label %bb_rcslotowner1893
bb_rcslotrole1893:
  %v8076 = load i64, ptr %slot96, align 8
  store i64 %v8076, ptr %slot1301, align 8
  %v8077 = load i64, ptr %slot1301, align 8
  %v8078 = load i64, ptr %slot1298, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v8077, i64 %v8078) nomerge, !dbg !206
  br label %bb_rcslotdone1893
bb_rcslotowner1893:
  %v8079 = load i64, ptr %slot96, align 8
  store i64 %v8079, ptr %slot1302, align 8
  %v8080 = load i64, ptr %slot1302, align 8
  %v8081 = load i64, ptr %slot1298, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v8080, i64 %v8081) nomerge, !dbg !206
  br label %bb_rcslotdone1893
bb_rcslotdone1893:
  %v8082 = load i64, ptr %slot8, align 8
  %p8083 = inttoptr i64 %v8082 to ptr
  %ld8084 = load i32, ptr %p8083, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8084, ptr %slot1303, align 8
  %v8085 = load i32, ptr %slot1303, align 8
  %cv8086 = zext i32 %v8085 to i64
  %cond8087 = icmp ne i64 %cv8086, 0
  br i1 %cond8087, label %bb_rcslotdrop1957, label %bb_rcslotdone1957
bb_rcslotdrop1957:
  %v8088 = load i64, ptr %slot8, align 8
  %p8089 = inttoptr i64 %v8088 to ptr
  store i32 0, ptr %p8089, align 4, !alias.scope !3, !noalias !4
  %v8090 = load i64, ptr %slot51, align 8
  store i64 %v8090, ptr %slot1304, align 8
  %v8091 = load i64, ptr %slot9, align 8
  %p8092 = inttoptr i64 %v8091 to ptr
  %ld8093 = load i32, ptr %p8092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8093, ptr %slot1305, align 8
  %v8094 = load i32, ptr %slot1305, align 8
  %op8095 = and i32 %v8094, 28
  store i32 %op8095, ptr %slot1306, align 8
  %v8096 = load i32, ptr %slot1306, align 8
  %cv8097 = zext i32 %v8096 to i64
  %cond8098 = icmp ne i64 %cv8097, 0
  br i1 %cond8098, label %bb_rcslotrole1957, label %bb_rcslotowner1957
bb_rcslotrole1957:
  %v8099 = load i64, ptr %slot96, align 8
  store i64 %v8099, ptr %slot1307, align 8
  %v8100 = load i64, ptr %slot1307, align 8
  %v8101 = load i64, ptr %slot1304, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v8100, i64 %v8101) nomerge, !dbg !206
  br label %bb_rcslotdone1957
bb_rcslotowner1957:
  %v8102 = load i64, ptr %slot96, align 8
  store i64 %v8102, ptr %slot1308, align 8
  %v8103 = load i64, ptr %slot1308, align 8
  %v8104 = load i64, ptr %slot1304, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v8103, i64 %v8104) nomerge, !dbg !206
  br label %bb_rcslotdone1957
bb_rcslotdone1957:
  %v8105 = load i64, ptr %slot1161, align 8
  %p8106 = inttoptr i64 %v8105 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p8106, i64 24, i1 false)
  ret void
bb_i187:
  br label %bb_i217
bb_i189:
  %v8107 = load i64, ptr %slot48, align 8
  %p8108 = inttoptr i64 %v8107 to ptr
  %ld8109 = load i64, ptr %p8108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8109, ptr %slot1309, align 8
  %v8110 = load i64, ptr %slot1309, align 8
  %v8111 = load i64, ptr %slot69, align 8
  %p8112 = inttoptr i64 %v8111 to ptr
  store i64 %v8110, ptr %p8112, align 8, !alias.scope !3, !noalias !4
  %v8113 = load i64, ptr %slot70, align 8
  %p8114 = inttoptr i64 %v8113 to ptr
  store i64 0, ptr %p8114, align 8, !alias.scope !3, !noalias !4
  %v8115 = load i64, ptr %slot70, align 8
  %p8116 = inttoptr i64 %v8115 to ptr
  %ld8117 = load i64, ptr %p8116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8117, ptr %slot1310, align 8
  %v8118 = load i64, ptr %slot69, align 8
  %p8119 = inttoptr i64 %v8118 to ptr
  %ld8120 = load i64, ptr %p8119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8120, ptr %slot1311, align 8
  %v8121 = load i64, ptr %slot1311, align 8
  %v8122 = load i64, ptr %slot1310, align 8
  %cmp8123 = icmp ne i64 %v8121, %v8122
  %cv8124 = zext i1 %cmp8123 to i64
  store i64 %cv8124, ptr %slot1312, align 8
  %v8125 = load i64, ptr %slot1312, align 8
  %v8126 = load i64, ptr %slot69, align 8
  %p8127 = inttoptr i64 %v8126 to ptr
  store i64 %v8125, ptr %p8127, align 8, !alias.scope !3, !noalias !4
  %v8128 = load i64, ptr %slot69, align 8
  %p8129 = inttoptr i64 %v8128 to ptr
  %ld8130 = load i64, ptr %p8129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8130, ptr %slot1313, align 8
  %v8131 = load i64, ptr %slot1313, align 8
  %cond8132 = icmp ne i64 %v8131, 0
  br i1 %cond8132, label %bb_next1978, label %bb_i216
bb_next1978:
  %p8133 = inttoptr i64 ptrtoint (ptr @myl_lit_651dfa874c87674e57d05784fbb331bf215d6ec2b7d4c57db6383d02b47d316a to i64) to ptr
  %ld8134 = load i64, ptr %p8133, align 8, !alias.scope !4, !noalias !3
  store i64 %ld8134, ptr %slot1314, align 8
  %v8135 = load i64, ptr %slot1314, align 8
  %v8136 = load i64, ptr %slot69, align 8
  %p8137 = inttoptr i64 %v8136 to ptr
  store i64 %v8135, ptr %p8137, align 8, !alias.scope !3, !noalias !4
  %v8138 = load i64, ptr %slot69, align 8
  %p8139 = inttoptr i64 %v8138 to ptr
  %ld8140 = load i64, ptr %p8139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8140, ptr %slot1315, align 8
  %v8141 = load i64, ptr %slot1315, align 8
  %v8142 = load i64, ptr %slot40, align 8
  %p8143 = inttoptr i64 %v8142 to ptr
  store i64 %v8141, ptr %p8143, align 8, !alias.scope !3, !noalias !4
  %v8144 = load i64, ptr %slot40, align 8
  store i64 %v8144, ptr %slot1316, align 8
  %v8145 = load i64, ptr %slot41, align 8
  store i64 %v8145, ptr %slot1317, align 8
  %v8146 = load i64, ptr %slot1316, align 8
  %v8147 = load i64, ptr %slot1317, align 8
  %p8148 = inttoptr i64 %v8146 to ptr
  %p8149 = inttoptr i64 %v8147 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8149, ptr %p8148, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8150 = load i64, ptr %slot35, align 8
  %p8151 = inttoptr i64 %v8150 to ptr
  store i32 2, ptr %p8151, align 4, !alias.scope !3, !noalias !4
  %v8152 = load i64, ptr %slot34, align 8
  %p8153 = inttoptr i64 %v8152 to ptr
  store i32 1, ptr %p8153, align 4, !alias.scope !3, !noalias !4
  %v8154 = load i64, ptr %slot37, align 8
  store i64 %v8154, ptr %slot1318, align 8
  %v8155 = load i64, ptr %slot41, align 8
  store i64 %v8155, ptr %slot1319, align 8
  %v8156 = load i64, ptr %slot1319, align 8
  %v8157 = load i64, ptr %slot1318, align 8
  %p8158 = inttoptr i64 %v8156 to ptr
  %p8159 = inttoptr i64 %v8157 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8159, ptr %p8158, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8160 = load i64, ptr %slot29, align 8
  %p8161 = inttoptr i64 %v8160 to ptr
  store i32 2, ptr %p8161, align 4, !alias.scope !3, !noalias !4
  %v8162 = load i64, ptr %slot35, align 8
  %p8163 = inttoptr i64 %v8162 to ptr
  %ld8164 = load i32, ptr %p8163, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8164, ptr %slot1320, align 8
  %v8165 = load i32, ptr %slot1320, align 8
  %v8166 = load i64, ptr %slot29, align 8
  %p8167 = inttoptr i64 %v8166 to ptr
  store i32 %v8165, ptr %p8167, align 4, !alias.scope !3, !noalias !4
  %v8168 = load i64, ptr %slot34, align 8
  %p8169 = inttoptr i64 %v8168 to ptr
  store i32 0, ptr %p8169, align 4, !alias.scope !3, !noalias !4
  %v8170 = load i64, ptr %slot28, align 8
  %p8171 = inttoptr i64 %v8170 to ptr
  store i32 1, ptr %p8171, align 4, !alias.scope !3, !noalias !4
  %v8172 = load i64, ptr %slot1318, align 8
  %p8173 = inttoptr i64 %v8172 to ptr
  %ld8174 = load i64, ptr %p8173, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8174, ptr %slot1321, align 8
  %v8175 = load i64, ptr %slot1321, align 8
  %v8176 = load i64, ptr %slot69, align 8
  %p8177 = inttoptr i64 %v8176 to ptr
  store i64 %v8175, ptr %p8177, align 8, !alias.scope !3, !noalias !4
  %v8178 = load i64, ptr %slot69, align 8
  %p8179 = inttoptr i64 %v8178 to ptr
  %ld8180 = load i64, ptr %p8179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8180, ptr %slot1322, align 8
  %v8181 = load i64, ptr %slot1322, align 8
  %v8182 = load i64, ptr %slot40, align 8
  %p8183 = inttoptr i64 %v8182 to ptr
  store i64 %v8181, ptr %p8183, align 8, !alias.scope !3, !noalias !4
  %v8184 = load i64, ptr %slot40, align 8
  store i64 %v8184, ptr %slot1323, align 8
  %v8185 = load i64, ptr %slot28, align 8
  %p8186 = inttoptr i64 %v8185 to ptr
  %ld8187 = load i32, ptr %p8186, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8187, ptr %slot1324, align 8
  %v8188 = load i64, ptr %slot29, align 8
  %p8189 = inttoptr i64 %v8188 to ptr
  %ld8190 = load i32, ptr %p8189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8190, ptr %slot1325, align 8
  %v8191 = load i32, ptr %slot1325, align 8
  %op8192 = and i32 %v8191, 24
  store i32 %op8192, ptr %slot1325, align 8
  %v8193 = load i32, ptr %slot1325, align 8
  %cmp8194 = icmp eq i32 %v8193, 0
  %cv8195 = zext i1 %cmp8194 to i32
  store i32 %cv8195, ptr %slot1326, align 8
  %v8196 = load i32, ptr %slot1324, align 8
  %v8197 = load i32, ptr %slot1326, align 8
  %op8198 = and i32 %v8196, %v8197
  store i32 %op8198, ptr %slot1327, align 8
  %v8199 = load i32, ptr %slot1327, align 8
  %cv8200 = zext i32 %v8199 to i64
  %cond8201 = icmp ne i64 %cv8200, 0
  br i1 %cond8201, label %bb_rcprivateown2002, label %bb_rcprivateloan2002
bb_rcprivateown2002:
  %v8202 = load i64, ptr %slot41, align 8
  store i64 %v8202, ptr %slot1328, align 8
  %v8203 = load i64, ptr %slot97, align 8
  store i64 %v8203, ptr %slot1329, align 8
  %v8204 = load i64, ptr %slot1323, align 8
  %v8205 = load i64, ptr %slot1328, align 8
  %op8206 = sub i64 %v8204, %v8205
  store i64 %op8206, ptr %slot1330, align 8
  %v8207 = load i64, ptr %slot1328, align 8
  %v8208 = load i64, ptr %slot1323, align 8
  %op8209 = sub i64 %v8207, %v8208
  store i64 %op8209, ptr %slot1331, align 8
  %v8210 = load i64, ptr %slot1330, align 8
  %cmp8211 = icmp ult i64 %v8210, 8
  %cv8212 = zext i1 %cmp8211 to i32
  store i32 %cv8212, ptr %slot1332, align 8
  %v8213 = load i64, ptr %slot1331, align 8
  %cmp8214 = icmp ult i64 %v8213, 8
  %cv8215 = zext i1 %cmp8214 to i32
  store i32 %cv8215, ptr %slot1333, align 8
  %v8216 = load i32, ptr %slot1332, align 8
  %v8217 = load i32, ptr %slot1333, align 8
  %op8218 = or i32 %v8216, %v8217
  store i32 %op8218, ptr %slot1334, align 8
  %v8219 = load i32, ptr %slot1334, align 8
  %cv8220 = zext i32 %v8219 to i64
  %cond8221 = icmp ne i64 %cv8220, 0
  br i1 %cond8221, label %bb_rcmoveslow2005, label %bb_rcmovecheck2005
bb_rcmovecheck2005:
  %v8222 = load i64, ptr %slot1323, align 8
  %p8224 = inttoptr i64 %v8222 to ptr
  %gep8225 = getelementptr i8, ptr %p8224, i64 0
  %op8223 = ptrtoint ptr %gep8225 to i64
  store i64 %op8223, ptr %slot1335, align 8
  %v8226 = load i64, ptr %slot1335, align 8
  %p8227 = inttoptr i64 %v8226 to ptr
  %ld8228 = load i64, ptr %p8227, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8228, ptr %slot1336, align 8
  %v8229 = load i64, ptr %slot1336, align 8
  %cmp8230 = icmp ne i64 %v8229, 0
  %cv8231 = zext i1 %cmp8230 to i32
  store i32 %cv8231, ptr %slot1337, align 8
  %v8232 = load i32, ptr %slot1337, align 8
  %cv8233 = zext i32 %v8232 to i64
  %cond8234 = icmp ne i64 %cv8233, 0
  br i1 %cond8234, label %bb_rcmoveheader2013, label %bb_rcmovenext2013
bb_rcmoveheader2013:
  %v8235 = load i64, ptr %slot1336, align 8
  %op8236 = sub i64 %v8235, 16
  store i64 %op8236, ptr %slot1338, align 8
  %v8237 = load i64, ptr %slot1336, align 8
  %p8238 = inttoptr i64 %v8237 to ptr
  %rgep8239 = getelementptr i8, ptr %p8238, i64 -16
  %ld8240 = load i64, ptr %rgep8239, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8240, ptr %slot1339, align 8
  %v8241 = load i64, ptr %slot1339, align 8
  %op8242 = and i64 %v8241, 5764607523034234881
  store i64 %op8242, ptr %slot1340, align 8
  %v8243 = load i64, ptr %slot1340, align 8
  %cmp8244 = icmp ne i64 %v8243, 0
  %cv8245 = zext i1 %cmp8244 to i32
  store i32 %cv8245, ptr %slot1341, align 8
  %v8246 = load i32, ptr %slot1341, align 8
  %cv8247 = zext i32 %v8246 to i64
  %cond8248 = icmp ne i64 %cv8247, 0
  br i1 %cond8248, label %bb_rcmoveslow2005, label %bb_rcmovenext2013
bb_rcmovenext2013:
  %v8249 = load i64, ptr %slot1323, align 8
  %v8250 = load i64, ptr %slot1328, align 8
  %p8251 = inttoptr i64 %v8249 to ptr
  %p8252 = inttoptr i64 %v8250 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8252, ptr %p8251, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8253 = load i64, ptr %slot1323, align 8
  %p8254 = inttoptr i64 %v8253 to ptr
  store i64 0, ptr %p8254, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2005
bb_rcmoveslow2005:
  %v8255 = load i64, ptr %slot96, align 8
  %v8256 = load i64, ptr %slot1328, align 8
  %v8257 = load i64, ptr %slot1323, align 8
  %v8258 = load i64, ptr %slot1329, align 8
  %cv8259 = trunc i64 %v8258 to i32
  %call8260 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v8255, i64 %v8256, i64 %v8257, i32 %cv8259) nomerge, !dbg !208
  store i32 %call8260, ptr %slot1342, align 8
  %v8261 = load i32, ptr %slot1342, align 8
  %cv8262 = zext i32 %v8261 to i64
  %cond8263 = icmp ne i64 %cv8262, 0
  br i1 %cond8263, label %bb_rcsuccess2020, label %bb_rcfailure2020
bb_rcfailure2020:
  %v8264 = load i64, ptr %slot96, align 8
  %p8265 = inttoptr i64 %v8264 to ptr
  %call8266 = call i32 @myl_rc_take_failure(ptr %p8265) nomerge, !dbg !208
  store i32 %call8266, ptr %slot1343, align 8
  %v8267 = load i64, ptr %slot1, align 8
  %p8268 = inttoptr i64 %v8267 to ptr
  %v8269 = load i32, ptr %slot1343, align 8
  %call8270 = call i32 @myl_qbe_rc_status(ptr %p8268, i32 %v8269) nomerge, !dbg !208
  store i32 %call8270, ptr %slot1344, align 8
  br label %bb_failure
bb_rcsuccess2020:
  br label %bb_rcmoved2005
bb_rcmoved2005:
  %v8271 = load i64, ptr %slot28, align 8
  %p8272 = inttoptr i64 %v8271 to ptr
  store i32 0, ptr %p8272, align 4, !alias.scope !3, !noalias !4
  %v8273 = load i64, ptr %slot35, align 8
  %p8274 = inttoptr i64 %v8273 to ptr
  store i32 2, ptr %p8274, align 4, !alias.scope !3, !noalias !4
  %v8275 = load i64, ptr %slot34, align 8
  %p8276 = inttoptr i64 %v8275 to ptr
  store i32 1, ptr %p8276, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2002
bb_rcprivateloan2002:
  %v8277 = load i64, ptr %slot28, align 8
  %p8278 = inttoptr i64 %v8277 to ptr
  %ld8279 = load i32, ptr %p8278, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8279, ptr %slot1345, align 8
  %v8280 = load i64, ptr %slot29, align 8
  %p8281 = inttoptr i64 %v8280 to ptr
  %ld8282 = load i32, ptr %p8281, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8282, ptr %slot1346, align 8
  %v8283 = load i32, ptr %slot1346, align 8
  %cmp8284 = icmp eq i32 %v8283, 16
  %cv8285 = zext i1 %cmp8284 to i32
  store i32 %cv8285, ptr %slot1347, align 8
  %v8286 = load i32, ptr %slot1347, align 8
  %v8287 = load i32, ptr %slot1345, align 8
  %op8288 = and i32 %v8286, %v8287
  store i32 %op8288, ptr %slot1347, align 8
  %v8289 = load i32, ptr %slot1347, align 8
  %cv8290 = zext i32 %v8289 to i64
  %cond8291 = icmp ne i64 %cv8290, 0
  br i1 %cond8291, label %bb_rcprivatemove2002, label %bb_rcprivatenew2002
bb_rcprivatemove2002:
  %v8292 = load i64, ptr %slot41, align 8
  store i64 %v8292, ptr %slot1348, align 8
  %v8293 = load i64, ptr %slot1323, align 8
  %v8294 = load i64, ptr %slot1348, align 8
  %p8295 = inttoptr i64 %v8293 to ptr
  %p8296 = inttoptr i64 %v8294 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8296, ptr %p8295, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8297 = load i64, ptr %slot1323, align 8
  %p8298 = inttoptr i64 %v8297 to ptr
  store i64 0, ptr %p8298, align 8, !alias.scope !3, !noalias !4
  %v8299 = load i64, ptr %slot35, align 8
  %p8300 = inttoptr i64 %v8299 to ptr
  store i32 2, ptr %p8300, align 4, !alias.scope !3, !noalias !4
  %v8301 = load i64, ptr %slot35, align 8
  %p8302 = inttoptr i64 %v8301 to ptr
  store i32 16, ptr %p8302, align 4, !alias.scope !3, !noalias !4
  %v8303 = load i64, ptr %slot34, align 8
  %p8304 = inttoptr i64 %v8303 to ptr
  store i32 1, ptr %p8304, align 4, !alias.scope !3, !noalias !4
  %v8305 = load i64, ptr %slot28, align 8
  %p8306 = inttoptr i64 %v8305 to ptr
  store i32 0, ptr %p8306, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2002
bb_rcprivatenew2002:
  %v8307 = load i64, ptr %slot41, align 8
  store i64 %v8307, ptr %slot1349, align 8
  %v8308 = load i64, ptr %slot1323, align 8
  %p8309 = inttoptr i64 %v8308 to ptr
  %ld8310 = load i64, ptr %p8309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8310, ptr %slot1350, align 8
  %v8311 = load i64, ptr %slot1350, align 8
  %cmp8312 = icmp ne i64 %v8311, 0
  %cv8313 = zext i1 %cmp8312 to i32
  store i32 %cv8313, ptr %slot1351, align 8
  %v8314 = load i32, ptr %slot1351, align 8
  %cv8315 = zext i32 %v8314 to i64
  %cond8316 = icmp ne i64 %cv8315, 0
  br i1 %cond8316, label %bb_rcgnn2038, label %bb_rcgstore2038
bb_rcgnn2038:
  %v8317 = load i64, ptr %slot1350, align 8
  %op8318 = sub i64 %v8317, 16
  store i64 %op8318, ptr %slot1352, align 8
  %v8319 = load i64, ptr %slot1350, align 8
  %p8320 = inttoptr i64 %v8319 to ptr
  %rgep8321 = getelementptr i8, ptr %p8320, i64 -16
  %ld8322 = load i64, ptr %rgep8321, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8322, ptr %slot1353, align 8
  %v8323 = load i64, ptr %slot1353, align 8
  %op8324 = and i64 %v8323, 4611686018427387906
  store i64 %op8324, ptr %slot1354, align 8
  %v8325 = load i64, ptr %slot1354, align 8
  %cmp8326 = icmp ne i64 %v8325, 0
  %cv8327 = zext i1 %cmp8326 to i32
  store i32 %cv8327, ptr %slot1355, align 8
  %v8328 = load i32, ptr %slot1355, align 8
  %cv8329 = zext i32 %v8328 to i64
  %cond8330 = icmp ne i64 %cv8329, 0
  br i1 %cond8330, label %bb_rcgstore2038, label %bb_rcginc2038
bb_rcginc2038:
  %v8331 = load i64, ptr %slot1350, align 8
  %op8332 = sub i64 %v8331, 24
  store i64 %op8332, ptr %slot1356, align 8
  %v8333 = load i64, ptr %slot1350, align 8
  %p8334 = inttoptr i64 %v8333 to ptr
  %rgep8335 = getelementptr i8, ptr %p8334, i64 -24
  %ld8336 = load i64, ptr %rgep8335, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8336, ptr %slot1357, align 8
  %v8337 = load i64, ptr %slot1357, align 8
  %op8338 = add i64 %v8337, 1
  store i64 %op8338, ptr %slot1358, align 8
  %v8339 = load i64, ptr %slot1358, align 8
  %cmp8340 = icmp eq i64 %v8339, 0
  %cv8341 = zext i1 %cmp8340 to i32
  store i32 %cv8341, ptr %slot1359, align 8
  %v8342 = load i32, ptr %slot1359, align 8
  %cv8343 = zext i32 %v8342 to i64
  %cond8344 = icmp ne i64 %cv8343, 0
  br i1 %cond8344, label %bb_rcglimit2038, label %bb_rcgcapacity2038
bb_rcglimit2038:
  %v8345 = load i64, ptr %slot1, align 8
  %p8346 = inttoptr i64 %v8345 to ptr
  %call8347 = call i32 @myl_qbe_rc_status(ptr %p8346, i32 2) nomerge, !dbg !208
  store i32 %call8347, ptr %slot1360, align 8
  br label %bb_failure
bb_rcgcapacity2038:
  %v8348 = load i64, ptr %slot1358, align 8
  %v8349 = load i64, ptr %slot1350, align 8
  %p8350 = inttoptr i64 %v8349 to ptr
  %rgep8351 = getelementptr i8, ptr %p8350, i64 -24
  store i64 %v8348, ptr %rgep8351, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore2038
bb_rcgstore2038:
  %v8352 = load i64, ptr %slot1350, align 8
  %v8353 = load i64, ptr %slot1349, align 8
  %p8354 = inttoptr i64 %v8353 to ptr
  store i64 %v8352, ptr %p8354, align 8, !alias.scope !3, !noalias !4
  %v8355 = load i64, ptr %slot35, align 8
  %p8356 = inttoptr i64 %v8355 to ptr
  store i32 2, ptr %p8356, align 4, !alias.scope !3, !noalias !4
  %v8357 = load i64, ptr %slot35, align 8
  %p8358 = inttoptr i64 %v8357 to ptr
  store i32 16, ptr %p8358, align 4, !alias.scope !3, !noalias !4
  %v8359 = load i64, ptr %slot34, align 8
  %p8360 = inttoptr i64 %v8359 to ptr
  store i32 1, ptr %p8360, align 4, !alias.scope !3, !noalias !4
  %v8361 = load i64, ptr %slot28, align 8
  %p8362 = inttoptr i64 %v8361 to ptr
  %ld8363 = load i32, ptr %p8362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8363, ptr %slot1361, align 8
  %v8364 = load i32, ptr %slot1361, align 8
  %cv8365 = zext i32 %v8364 to i64
  %cond8366 = icmp ne i64 %cv8365, 0
  br i1 %cond8366, label %bb_rcslotdrop2054, label %bb_rcslotdone2054
bb_rcslotdrop2054:
  %v8367 = load i64, ptr %slot28, align 8
  %p8368 = inttoptr i64 %v8367 to ptr
  store i32 0, ptr %p8368, align 4, !alias.scope !3, !noalias !4
  %v8369 = load i64, ptr %slot37, align 8
  store i64 %v8369, ptr %slot1362, align 8
  %v8370 = load i64, ptr %slot29, align 8
  %p8371 = inttoptr i64 %v8370 to ptr
  %ld8372 = load i32, ptr %p8371, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8372, ptr %slot1363, align 8
  %v8373 = load i32, ptr %slot1363, align 8
  %op8374 = and i32 %v8373, 28
  store i32 %op8374, ptr %slot1364, align 8
  %v8375 = load i32, ptr %slot1364, align 8
  %cv8376 = zext i32 %v8375 to i64
  %cond8377 = icmp ne i64 %cv8376, 0
  br i1 %cond8377, label %bb_rcslotrole2054, label %bb_rcslotowner2054
bb_rcslotrole2054:
  %v8378 = load i64, ptr %slot96, align 8
  store i64 %v8378, ptr %slot1365, align 8
  %v8379 = load i64, ptr %slot1362, align 8
  %p8380 = inttoptr i64 %v8379 to ptr
  %ld8381 = load i64, ptr %p8380, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8381, ptr %slot1366, align 8
  %v8382 = load i64, ptr %slot1366, align 8
  %cmp8383 = icmp ne i64 %v8382, 0
  %cv8384 = zext i1 %cmp8383 to i32
  store i32 %cv8384, ptr %slot1367, align 8
  %v8385 = load i32, ptr %slot1367, align 8
  %cv8386 = zext i32 %v8385 to i64
  %cond8387 = icmp ne i64 %cv8386, 0
  br i1 %cond8387, label %bb_rcgnn2070, label %bb_rcgdone2070
bb_rcgnn2070:
  %v8388 = load i64, ptr %slot1366, align 8
  %op8389 = sub i64 %v8388, 16
  store i64 %op8389, ptr %slot1368, align 8
  %v8390 = load i64, ptr %slot1366, align 8
  %p8391 = inttoptr i64 %v8390 to ptr
  %rgep8392 = getelementptr i8, ptr %p8391, i64 -16
  %ld8393 = load i64, ptr %rgep8392, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8393, ptr %slot1369, align 8
  %v8394 = load i64, ptr %slot1369, align 8
  %op8395 = and i64 %v8394, 4611686018427387906
  store i64 %op8395, ptr %slot1370, align 8
  %v8396 = load i64, ptr %slot1370, align 8
  %cmp8397 = icmp ne i64 %v8396, 0
  %cv8398 = zext i1 %cmp8397 to i32
  store i32 %cv8398, ptr %slot1371, align 8
  %v8399 = load i32, ptr %slot1371, align 8
  %cv8400 = zext i32 %v8399 to i64
  %cond8401 = icmp ne i64 %cv8400, 0
  br i1 %cond8401, label %bb_rcgclear2070, label %bb_rcgcounted2070
bb_rcgcounted2070:
  %v8402 = load i64, ptr %slot1366, align 8
  %op8403 = sub i64 %v8402, 24
  store i64 %op8403, ptr %slot1372, align 8
  %v8404 = load i64, ptr %slot1366, align 8
  %p8405 = inttoptr i64 %v8404 to ptr
  %rgep8406 = getelementptr i8, ptr %p8405, i64 -24
  %ld8407 = load i64, ptr %rgep8406, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8407, ptr %slot1373, align 8
  %v8408 = load i64, ptr %slot1373, align 8
  %op8409 = sub i64 %v8408, 1
  store i64 %op8409, ptr %slot1374, align 8
  %v8410 = load i64, ptr %slot1374, align 8
  %cmp8411 = icmp eq i64 %v8410, 0
  %cv8412 = zext i1 %cmp8411 to i32
  store i32 %cv8412, ptr %slot1375, align 8
  %v8413 = load i32, ptr %slot1375, align 8
  %cv8414 = zext i32 %v8413 to i64
  %cond8415 = icmp ne i64 %cv8414, 0
  br i1 %cond8415, label %bb_rcglast2070, label %bb_rcgdec2070
bb_rcglast2070:
  %v8416 = load i64, ptr %slot1366, align 8
  %op8417 = sub i64 %v8416, 32
  store i64 %op8417, ptr %slot1376, align 8
  %v8418 = load i64, ptr %slot1366, align 8
  %p8419 = inttoptr i64 %v8418 to ptr
  %rgep8420 = getelementptr i8, ptr %p8419, i64 -32
  %ld8421 = load i64, ptr %rgep8420, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8421, ptr %slot1377, align 8
  %v8422 = load i64, ptr %slot1377, align 8
  %cmp8423 = icmp ne i64 %v8422, 0
  %cv8424 = zext i1 %cmp8423 to i32
  store i32 %cv8424, ptr %slot1378, align 8
  %v8425 = load i32, ptr %slot1378, align 8
  %cv8426 = zext i32 %v8425 to i64
  %cond8427 = icmp ne i64 %cv8426, 0
  br i1 %cond8427, label %bb_rcgdec2070, label %bb_rcgslow2070
bb_rcgslow2070:
  %v8428 = load i64, ptr %slot1365, align 8
  %v8429 = load i64, ptr %slot1362, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v8428, i64 %v8429) nomerge, !dbg !208
  br label %bb_rcgdone2070
bb_rcgdec2070:
  %v8430 = load i64, ptr %slot1374, align 8
  %v8431 = load i64, ptr %slot1366, align 8
  %p8432 = inttoptr i64 %v8431 to ptr
  %rgep8433 = getelementptr i8, ptr %p8432, i64 -24
  store i64 %v8430, ptr %rgep8433, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2070
bb_rcgclear2070:
  %v8434 = load i64, ptr %slot1362, align 8
  %p8435 = inttoptr i64 %v8434 to ptr
  store i64 0, ptr %p8435, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2070
bb_rcgdone2070:
  br label %bb_rcslotdone2054
bb_rcslotowner2054:
  %v8436 = load i64, ptr %slot96, align 8
  store i64 %v8436, ptr %slot1379, align 8
  %v8437 = load i64, ptr %slot1362, align 8
  %p8438 = inttoptr i64 %v8437 to ptr
  %ld8439 = load i64, ptr %p8438, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8439, ptr %slot1380, align 8
  %v8440 = load i64, ptr %slot1380, align 8
  %cmp8441 = icmp ne i64 %v8440, 0
  %cv8442 = zext i1 %cmp8441 to i32
  store i32 %cv8442, ptr %slot1381, align 8
  %v8443 = load i32, ptr %slot1381, align 8
  %cv8444 = zext i32 %v8443 to i64
  %cond8445 = icmp ne i64 %cv8444, 0
  br i1 %cond8445, label %bb_rcgnn2085, label %bb_rcgdone2085
bb_rcgnn2085:
  %v8446 = load i64, ptr %slot1380, align 8
  %op8447 = sub i64 %v8446, 16
  store i64 %op8447, ptr %slot1382, align 8
  %v8448 = load i64, ptr %slot1380, align 8
  %p8449 = inttoptr i64 %v8448 to ptr
  %rgep8450 = getelementptr i8, ptr %p8449, i64 -16
  %ld8451 = load i64, ptr %rgep8450, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8451, ptr %slot1383, align 8
  %v8452 = load i64, ptr %slot1383, align 8
  %op8453 = and i64 %v8452, 4611686018427387906
  store i64 %op8453, ptr %slot1384, align 8
  %v8454 = load i64, ptr %slot1384, align 8
  %cmp8455 = icmp ne i64 %v8454, 0
  %cv8456 = zext i1 %cmp8455 to i32
  store i32 %cv8456, ptr %slot1385, align 8
  %v8457 = load i32, ptr %slot1385, align 8
  %cv8458 = zext i32 %v8457 to i64
  %cond8459 = icmp ne i64 %cv8458, 0
  br i1 %cond8459, label %bb_rcgclear2085, label %bb_rcgcounted2085
bb_rcgcounted2085:
  %v8460 = load i64, ptr %slot1380, align 8
  %op8461 = sub i64 %v8460, 32
  store i64 %op8461, ptr %slot1386, align 8
  %v8462 = load i64, ptr %slot1380, align 8
  %p8463 = inttoptr i64 %v8462 to ptr
  %rgep8464 = getelementptr i8, ptr %p8463, i64 -32
  %ld8465 = load i64, ptr %rgep8464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8465, ptr %slot1387, align 8
  %v8466 = load i64, ptr %slot1387, align 8
  %op8467 = sub i64 %v8466, 1
  store i64 %op8467, ptr %slot1388, align 8
  %v8468 = load i64, ptr %slot1388, align 8
  %cmp8469 = icmp eq i64 %v8468, 0
  %cv8470 = zext i1 %cmp8469 to i32
  store i32 %cv8470, ptr %slot1389, align 8
  %v8471 = load i32, ptr %slot1389, align 8
  %cv8472 = zext i32 %v8471 to i64
  %cond8473 = icmp ne i64 %cv8472, 0
  br i1 %cond8473, label %bb_rcglast2085, label %bb_rcgdec2085
bb_rcglast2085:
  %v8474 = load i64, ptr %slot1380, align 8
  %op8475 = sub i64 %v8474, 24
  store i64 %op8475, ptr %slot1390, align 8
  %v8476 = load i64, ptr %slot1380, align 8
  %p8477 = inttoptr i64 %v8476 to ptr
  %rgep8478 = getelementptr i8, ptr %p8477, i64 -24
  %ld8479 = load i64, ptr %rgep8478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8479, ptr %slot1391, align 8
  %v8480 = load i64, ptr %slot1391, align 8
  %cmp8481 = icmp ne i64 %v8480, 0
  %cv8482 = zext i1 %cmp8481 to i32
  store i32 %cv8482, ptr %slot1392, align 8
  %v8483 = load i32, ptr %slot1392, align 8
  %cv8484 = zext i32 %v8483 to i64
  %cond8485 = icmp ne i64 %cv8484, 0
  br i1 %cond8485, label %bb_rcgdec2085, label %bb_rcgslow2085
bb_rcgslow2085:
  %v8486 = load i64, ptr %slot1379, align 8
  %v8487 = load i64, ptr %slot1362, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v8486, i64 %v8487) nomerge, !dbg !208
  br label %bb_rcgdone2085
bb_rcgdec2085:
  %v8488 = load i64, ptr %slot1388, align 8
  %v8489 = load i64, ptr %slot1380, align 8
  %p8490 = inttoptr i64 %v8489 to ptr
  %rgep8491 = getelementptr i8, ptr %p8490, i64 -32
  store i64 %v8488, ptr %rgep8491, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2085
bb_rcgclear2085:
  %v8492 = load i64, ptr %slot1362, align 8
  %p8493 = inttoptr i64 %v8492 to ptr
  store i64 0, ptr %p8493, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2085
bb_rcgdone2085:
  br label %bb_rcslotdone2054
bb_rcslotdone2054:
  br label %bb_rcprivateprepared2002
bb_rcprivateprepared2002:
  %v8494 = load i64, ptr %slot22, align 8
  %p8495 = inttoptr i64 %v8494 to ptr
  %ld8496 = load i32, ptr %p8495, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8496, ptr %slot1393, align 8
  %v8497 = load i32, ptr %slot1393, align 8
  %cv8498 = zext i32 %v8497 to i64
  %cond8499 = icmp ne i64 %cv8498, 0
  br i1 %cond8499, label %bb_rcslotdrop2092, label %bb_rcslotdone2092
bb_rcslotdrop2092:
  %v8500 = load i64, ptr %slot22, align 8
  %p8501 = inttoptr i64 %v8500 to ptr
  store i32 0, ptr %p8501, align 4, !alias.scope !3, !noalias !4
  %v8502 = load i64, ptr %slot66, align 8
  store i64 %v8502, ptr %slot1394, align 8
  %v8503 = load i64, ptr %slot23, align 8
  %p8504 = inttoptr i64 %v8503 to ptr
  %ld8505 = load i32, ptr %p8504, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8505, ptr %slot1395, align 8
  %v8506 = load i32, ptr %slot1395, align 8
  %op8507 = and i32 %v8506, 28
  store i32 %op8507, ptr %slot1396, align 8
  %v8508 = load i32, ptr %slot1396, align 8
  %cv8509 = zext i32 %v8508 to i64
  %cond8510 = icmp ne i64 %cv8509, 0
  br i1 %cond8510, label %bb_rcslotrole2092, label %bb_rcslotowner2092
bb_rcslotrole2092:
  %v8511 = load i64, ptr %slot96, align 8
  store i64 %v8511, ptr %slot1397, align 8
  %v8512 = load i64, ptr %slot1394, align 8
  %p8513 = inttoptr i64 %v8512 to ptr
  %ld8514 = load i64, ptr %p8513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8514, ptr %slot1398, align 8
  %v8515 = load i64, ptr %slot1398, align 8
  %cmp8516 = icmp ne i64 %v8515, 0
  %cv8517 = zext i1 %cmp8516 to i32
  store i32 %cv8517, ptr %slot1399, align 8
  %v8518 = load i32, ptr %slot1399, align 8
  %cv8519 = zext i32 %v8518 to i64
  %cond8520 = icmp ne i64 %cv8519, 0
  br i1 %cond8520, label %bb_rcgnn2108, label %bb_rcgdone2108
bb_rcgnn2108:
  %v8521 = load i64, ptr %slot1398, align 8
  %op8522 = sub i64 %v8521, 16
  store i64 %op8522, ptr %slot1400, align 8
  %v8523 = load i64, ptr %slot1398, align 8
  %p8524 = inttoptr i64 %v8523 to ptr
  %rgep8525 = getelementptr i8, ptr %p8524, i64 -16
  %ld8526 = load i64, ptr %rgep8525, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8526, ptr %slot1401, align 8
  %v8527 = load i64, ptr %slot1401, align 8
  %op8528 = and i64 %v8527, 4611686018427387906
  store i64 %op8528, ptr %slot1402, align 8
  %v8529 = load i64, ptr %slot1402, align 8
  %cmp8530 = icmp ne i64 %v8529, 0
  %cv8531 = zext i1 %cmp8530 to i32
  store i32 %cv8531, ptr %slot1403, align 8
  %v8532 = load i32, ptr %slot1403, align 8
  %cv8533 = zext i32 %v8532 to i64
  %cond8534 = icmp ne i64 %cv8533, 0
  br i1 %cond8534, label %bb_rcgclear2108, label %bb_rcgcounted2108
bb_rcgcounted2108:
  %v8535 = load i64, ptr %slot1398, align 8
  %op8536 = sub i64 %v8535, 24
  store i64 %op8536, ptr %slot1404, align 8
  %v8537 = load i64, ptr %slot1398, align 8
  %p8538 = inttoptr i64 %v8537 to ptr
  %rgep8539 = getelementptr i8, ptr %p8538, i64 -24
  %ld8540 = load i64, ptr %rgep8539, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8540, ptr %slot1405, align 8
  %v8541 = load i64, ptr %slot1405, align 8
  %op8542 = sub i64 %v8541, 1
  store i64 %op8542, ptr %slot1406, align 8
  %v8543 = load i64, ptr %slot1406, align 8
  %cmp8544 = icmp eq i64 %v8543, 0
  %cv8545 = zext i1 %cmp8544 to i32
  store i32 %cv8545, ptr %slot1407, align 8
  %v8546 = load i32, ptr %slot1407, align 8
  %cv8547 = zext i32 %v8546 to i64
  %cond8548 = icmp ne i64 %cv8547, 0
  br i1 %cond8548, label %bb_rcglast2108, label %bb_rcgdec2108
bb_rcglast2108:
  %v8549 = load i64, ptr %slot1398, align 8
  %op8550 = sub i64 %v8549, 32
  store i64 %op8550, ptr %slot1408, align 8
  %v8551 = load i64, ptr %slot1398, align 8
  %p8552 = inttoptr i64 %v8551 to ptr
  %rgep8553 = getelementptr i8, ptr %p8552, i64 -32
  %ld8554 = load i64, ptr %rgep8553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8554, ptr %slot1409, align 8
  %v8555 = load i64, ptr %slot1409, align 8
  %cmp8556 = icmp ne i64 %v8555, 0
  %cv8557 = zext i1 %cmp8556 to i32
  store i32 %cv8557, ptr %slot1410, align 8
  %v8558 = load i32, ptr %slot1410, align 8
  %cv8559 = zext i32 %v8558 to i64
  %cond8560 = icmp ne i64 %cv8559, 0
  br i1 %cond8560, label %bb_rcgdec2108, label %bb_rcgslow2108
bb_rcgslow2108:
  %v8561 = load i64, ptr %slot1397, align 8
  %v8562 = load i64, ptr %slot1394, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v8561, i64 %v8562) nomerge, !dbg !208
  br label %bb_rcgdone2108
bb_rcgdec2108:
  %v8563 = load i64, ptr %slot1406, align 8
  %v8564 = load i64, ptr %slot1398, align 8
  %p8565 = inttoptr i64 %v8564 to ptr
  %rgep8566 = getelementptr i8, ptr %p8565, i64 -24
  store i64 %v8563, ptr %rgep8566, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2108
bb_rcgclear2108:
  %v8567 = load i64, ptr %slot1394, align 8
  %p8568 = inttoptr i64 %v8567 to ptr
  store i64 0, ptr %p8568, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2108
bb_rcgdone2108:
  br label %bb_rcslotdone2092
bb_rcslotowner2092:
  %v8569 = load i64, ptr %slot96, align 8
  store i64 %v8569, ptr %slot1411, align 8
  %v8570 = load i64, ptr %slot1394, align 8
  %p8571 = inttoptr i64 %v8570 to ptr
  %ld8572 = load i64, ptr %p8571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8572, ptr %slot1412, align 8
  %v8573 = load i64, ptr %slot1412, align 8
  %cmp8574 = icmp ne i64 %v8573, 0
  %cv8575 = zext i1 %cmp8574 to i32
  store i32 %cv8575, ptr %slot1413, align 8
  %v8576 = load i32, ptr %slot1413, align 8
  %cv8577 = zext i32 %v8576 to i64
  %cond8578 = icmp ne i64 %cv8577, 0
  br i1 %cond8578, label %bb_rcgnn2123, label %bb_rcgdone2123
bb_rcgnn2123:
  %v8579 = load i64, ptr %slot1412, align 8
  %op8580 = sub i64 %v8579, 16
  store i64 %op8580, ptr %slot1414, align 8
  %v8581 = load i64, ptr %slot1412, align 8
  %p8582 = inttoptr i64 %v8581 to ptr
  %rgep8583 = getelementptr i8, ptr %p8582, i64 -16
  %ld8584 = load i64, ptr %rgep8583, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8584, ptr %slot1415, align 8
  %v8585 = load i64, ptr %slot1415, align 8
  %op8586 = and i64 %v8585, 4611686018427387906
  store i64 %op8586, ptr %slot1416, align 8
  %v8587 = load i64, ptr %slot1416, align 8
  %cmp8588 = icmp ne i64 %v8587, 0
  %cv8589 = zext i1 %cmp8588 to i32
  store i32 %cv8589, ptr %slot1417, align 8
  %v8590 = load i32, ptr %slot1417, align 8
  %cv8591 = zext i32 %v8590 to i64
  %cond8592 = icmp ne i64 %cv8591, 0
  br i1 %cond8592, label %bb_rcgclear2123, label %bb_rcgcounted2123
bb_rcgcounted2123:
  %v8593 = load i64, ptr %slot1412, align 8
  %op8594 = sub i64 %v8593, 32
  store i64 %op8594, ptr %slot1418, align 8
  %v8595 = load i64, ptr %slot1412, align 8
  %p8596 = inttoptr i64 %v8595 to ptr
  %rgep8597 = getelementptr i8, ptr %p8596, i64 -32
  %ld8598 = load i64, ptr %rgep8597, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8598, ptr %slot1419, align 8
  %v8599 = load i64, ptr %slot1419, align 8
  %op8600 = sub i64 %v8599, 1
  store i64 %op8600, ptr %slot1420, align 8
  %v8601 = load i64, ptr %slot1420, align 8
  %cmp8602 = icmp eq i64 %v8601, 0
  %cv8603 = zext i1 %cmp8602 to i32
  store i32 %cv8603, ptr %slot1421, align 8
  %v8604 = load i32, ptr %slot1421, align 8
  %cv8605 = zext i32 %v8604 to i64
  %cond8606 = icmp ne i64 %cv8605, 0
  br i1 %cond8606, label %bb_rcglast2123, label %bb_rcgdec2123
bb_rcglast2123:
  %v8607 = load i64, ptr %slot1412, align 8
  %op8608 = sub i64 %v8607, 24
  store i64 %op8608, ptr %slot1422, align 8
  %v8609 = load i64, ptr %slot1412, align 8
  %p8610 = inttoptr i64 %v8609 to ptr
  %rgep8611 = getelementptr i8, ptr %p8610, i64 -24
  %ld8612 = load i64, ptr %rgep8611, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8612, ptr %slot1423, align 8
  %v8613 = load i64, ptr %slot1423, align 8
  %cmp8614 = icmp ne i64 %v8613, 0
  %cv8615 = zext i1 %cmp8614 to i32
  store i32 %cv8615, ptr %slot1424, align 8
  %v8616 = load i32, ptr %slot1424, align 8
  %cv8617 = zext i32 %v8616 to i64
  %cond8618 = icmp ne i64 %cv8617, 0
  br i1 %cond8618, label %bb_rcgdec2123, label %bb_rcgslow2123
bb_rcgslow2123:
  %v8619 = load i64, ptr %slot1411, align 8
  %v8620 = load i64, ptr %slot1394, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v8619, i64 %v8620) nomerge, !dbg !208
  br label %bb_rcgdone2123
bb_rcgdec2123:
  %v8621 = load i64, ptr %slot1420, align 8
  %v8622 = load i64, ptr %slot1412, align 8
  %p8623 = inttoptr i64 %v8622 to ptr
  %rgep8624 = getelementptr i8, ptr %p8623, i64 -32
  store i64 %v8621, ptr %rgep8624, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2123
bb_rcgclear2123:
  %v8625 = load i64, ptr %slot1394, align 8
  %p8626 = inttoptr i64 %v8625 to ptr
  store i64 0, ptr %p8626, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2123
bb_rcgdone2123:
  br label %bb_rcslotdone2092
bb_rcslotdone2092:
  %v8627 = load i64, ptr %slot66, align 8
  store i64 %v8627, ptr %slot1425, align 8
  %v8628 = load i64, ptr %slot41, align 8
  store i64 %v8628, ptr %slot1426, align 8
  %v8629 = load i64, ptr %slot1426, align 8
  %v8630 = load i64, ptr %slot1425, align 8
  %p8631 = inttoptr i64 %v8629 to ptr
  %p8632 = inttoptr i64 %v8630 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8632, ptr %p8631, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8633 = load i64, ptr %slot34, align 8
  %p8634 = inttoptr i64 %v8633 to ptr
  store i32 0, ptr %p8634, align 4, !alias.scope !3, !noalias !4
  %v8635 = load i64, ptr %slot23, align 8
  %p8636 = inttoptr i64 %v8635 to ptr
  store i32 2, ptr %p8636, align 4, !alias.scope !3, !noalias !4
  %v8637 = load i64, ptr %slot35, align 8
  %p8638 = inttoptr i64 %v8637 to ptr
  %ld8639 = load i32, ptr %p8638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8639, ptr %slot1427, align 8
  %v8640 = load i32, ptr %slot1427, align 8
  %v8641 = load i64, ptr %slot23, align 8
  %p8642 = inttoptr i64 %v8641 to ptr
  store i32 %v8640, ptr %p8642, align 4, !alias.scope !3, !noalias !4
  %v8643 = load i64, ptr %slot22, align 8
  %p8644 = inttoptr i64 %v8643 to ptr
  store i32 1, ptr %p8644, align 4, !alias.scope !3, !noalias !4
  %v8645 = load i64, ptr %slot69, align 8
  %p8646 = inttoptr i64 %v8645 to ptr
  store i64 3, ptr %p8646, align 8, !alias.scope !3, !noalias !4
  %v8647 = load i64, ptr %slot69, align 8
  %p8648 = inttoptr i64 %v8647 to ptr
  %ld8649 = load i64, ptr %p8648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8649, ptr %slot1428, align 8
  %v8650 = load i64, ptr %slot1428, align 8
  %cmp8651 = icmp sge i64 %v8650, 0
  %cv8652 = zext i1 %cmp8651 to i64
  store i64 %cv8652, ptr %slot1429, align 8
  %v8653 = load i64, ptr %slot1429, align 8
  %cond8654 = icmp ne i64 %v8653, 0
  br i1 %cond8654, label %bb_success2136, label %bb_failed2136
bb_failed2136:
  %v8655 = load i64, ptr %slot1, align 8
  %p8656 = inttoptr i64 %v8655 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p8656) nomerge, !dbg !210
  unreachable
bb_success2136:
  %v8657 = load i64, ptr %slot96, align 8
  %p8658 = inttoptr i64 %v8657 to ptr
  %p8659 = inttoptr i64 ptrtoint (ptr @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a to i64) to ptr
  %v8660 = load i64, ptr %slot1428, align 8
  %call8661 = call ptr @myl_native_list_new(ptr %p8658, ptr %p8659, i64 %v8660) nomerge, !dbg !210
  %calladdr8662 = ptrtoint ptr %call8661 to i64
  store i64 %calladdr8662, ptr %slot1430, align 8
  %v8663 = load i64, ptr %slot1430, align 8
  %cond8664 = icmp ne i64 %v8663, 0
  br i1 %cond8664, label %bb_success2138, label %bb_failed2138
bb_failed2138:
  %v8665 = load i64, ptr %slot1, align 8
  %p8666 = inttoptr i64 %v8665 to ptr
  call void @myl_qbe_fail_allocation(ptr %p8666) nomerge, !dbg !210
  unreachable
bb_success2138:
  %v8667 = load i64, ptr %slot1430, align 8
  %v8668 = load i64, ptr %slot69, align 8
  %p8669 = inttoptr i64 %v8668 to ptr
  store i64 %v8667, ptr %p8669, align 8, !alias.scope !3, !noalias !4
  %v8670 = load i64, ptr %slot69, align 8
  %p8671 = inttoptr i64 %v8670 to ptr
  %ld8672 = load i64, ptr %p8671, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8672, ptr %slot1431, align 8
  %v8673 = load i64, ptr %slot1431, align 8
  %v8674 = load i64, ptr %slot40, align 8
  %p8675 = inttoptr i64 %v8674 to ptr
  store i64 %v8673, ptr %p8675, align 8, !alias.scope !3, !noalias !4
  %v8676 = load i64, ptr %slot40, align 8
  store i64 %v8676, ptr %slot1432, align 8
  %v8677 = load i64, ptr %slot41, align 8
  store i64 %v8677, ptr %slot1433, align 8
  %v8678 = load i64, ptr %slot1432, align 8
  %v8679 = load i64, ptr %slot1433, align 8
  %p8680 = inttoptr i64 %v8678 to ptr
  %p8681 = inttoptr i64 %v8679 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8681, ptr %p8680, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8682 = load i64, ptr %slot35, align 8
  %p8683 = inttoptr i64 %v8682 to ptr
  store i32 2, ptr %p8683, align 4, !alias.scope !3, !noalias !4
  %v8684 = load i64, ptr %slot34, align 8
  %p8685 = inttoptr i64 %v8684 to ptr
  store i32 1, ptr %p8685, align 4, !alias.scope !3, !noalias !4
  %v8686 = load i64, ptr %slot37, align 8
  store i64 %v8686, ptr %slot1434, align 8
  %v8687 = load i64, ptr %slot41, align 8
  store i64 %v8687, ptr %slot1435, align 8
  %v8688 = load i64, ptr %slot1435, align 8
  %v8689 = load i64, ptr %slot1434, align 8
  %p8690 = inttoptr i64 %v8688 to ptr
  %p8691 = inttoptr i64 %v8689 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8691, ptr %p8690, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8692 = load i64, ptr %slot29, align 8
  %p8693 = inttoptr i64 %v8692 to ptr
  store i32 2, ptr %p8693, align 4, !alias.scope !3, !noalias !4
  %v8694 = load i64, ptr %slot35, align 8
  %p8695 = inttoptr i64 %v8694 to ptr
  %ld8696 = load i32, ptr %p8695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8696, ptr %slot1436, align 8
  %v8697 = load i32, ptr %slot1436, align 8
  %v8698 = load i64, ptr %slot29, align 8
  %p8699 = inttoptr i64 %v8698 to ptr
  store i32 %v8697, ptr %p8699, align 4, !alias.scope !3, !noalias !4
  %v8700 = load i64, ptr %slot34, align 8
  %p8701 = inttoptr i64 %v8700 to ptr
  store i32 0, ptr %p8701, align 4, !alias.scope !3, !noalias !4
  %v8702 = load i64, ptr %slot28, align 8
  %p8703 = inttoptr i64 %v8702 to ptr
  store i32 1, ptr %p8703, align 4, !alias.scope !3, !noalias !4
  %v8704 = load i64, ptr %slot1434, align 8
  %p8705 = inttoptr i64 %v8704 to ptr
  %ld8706 = load i64, ptr %p8705, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8706, ptr %slot1437, align 8
  %v8707 = load i64, ptr %slot1437, align 8
  %v8708 = load i64, ptr %slot69, align 8
  %p8709 = inttoptr i64 %v8708 to ptr
  store i64 %v8707, ptr %p8709, align 8, !alias.scope !3, !noalias !4
  %v8710 = load i64, ptr %slot69, align 8
  %p8711 = inttoptr i64 %v8710 to ptr
  %ld8712 = load i64, ptr %p8711, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8712, ptr %slot1438, align 8
  %v8713 = load i64, ptr %slot1438, align 8
  %v8714 = load i64, ptr %slot40, align 8
  %p8715 = inttoptr i64 %v8714 to ptr
  store i64 %v8713, ptr %p8715, align 8, !alias.scope !3, !noalias !4
  %v8716 = load i64, ptr %slot40, align 8
  store i64 %v8716, ptr %slot1439, align 8
  %v8717 = load i64, ptr %slot28, align 8
  %p8718 = inttoptr i64 %v8717 to ptr
  %ld8719 = load i32, ptr %p8718, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8719, ptr %slot1440, align 8
  %v8720 = load i64, ptr %slot29, align 8
  %p8721 = inttoptr i64 %v8720 to ptr
  %ld8722 = load i32, ptr %p8721, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8722, ptr %slot1441, align 8
  %v8723 = load i32, ptr %slot1441, align 8
  %op8724 = and i32 %v8723, 24
  store i32 %op8724, ptr %slot1441, align 8
  %v8725 = load i32, ptr %slot1441, align 8
  %cmp8726 = icmp eq i32 %v8725, 0
  %cv8727 = zext i1 %cmp8726 to i32
  store i32 %cv8727, ptr %slot1442, align 8
  %v8728 = load i32, ptr %slot1440, align 8
  %v8729 = load i32, ptr %slot1442, align 8
  %op8730 = and i32 %v8728, %v8729
  store i32 %op8730, ptr %slot1443, align 8
  %v8731 = load i32, ptr %slot1443, align 8
  %cv8732 = zext i32 %v8731 to i64
  %cond8733 = icmp ne i64 %cv8732, 0
  br i1 %cond8733, label %bb_rcprivateown2161, label %bb_rcprivateloan2161
bb_rcprivateown2161:
  %v8734 = load i64, ptr %slot41, align 8
  store i64 %v8734, ptr %slot1444, align 8
  %v8735 = load i64, ptr %slot97, align 8
  store i64 %v8735, ptr %slot1445, align 8
  %v8736 = load i64, ptr %slot1439, align 8
  %v8737 = load i64, ptr %slot1444, align 8
  %op8738 = sub i64 %v8736, %v8737
  store i64 %op8738, ptr %slot1446, align 8
  %v8739 = load i64, ptr %slot1444, align 8
  %v8740 = load i64, ptr %slot1439, align 8
  %op8741 = sub i64 %v8739, %v8740
  store i64 %op8741, ptr %slot1447, align 8
  %v8742 = load i64, ptr %slot1446, align 8
  %cmp8743 = icmp ult i64 %v8742, 8
  %cv8744 = zext i1 %cmp8743 to i32
  store i32 %cv8744, ptr %slot1448, align 8
  %v8745 = load i64, ptr %slot1447, align 8
  %cmp8746 = icmp ult i64 %v8745, 8
  %cv8747 = zext i1 %cmp8746 to i32
  store i32 %cv8747, ptr %slot1449, align 8
  %v8748 = load i32, ptr %slot1448, align 8
  %v8749 = load i32, ptr %slot1449, align 8
  %op8750 = or i32 %v8748, %v8749
  store i32 %op8750, ptr %slot1450, align 8
  %v8751 = load i32, ptr %slot1450, align 8
  %cv8752 = zext i32 %v8751 to i64
  %cond8753 = icmp ne i64 %cv8752, 0
  br i1 %cond8753, label %bb_rcmoveslow2164, label %bb_rcmovecheck2164
bb_rcmovecheck2164:
  %v8754 = load i64, ptr %slot1439, align 8
  %p8756 = inttoptr i64 %v8754 to ptr
  %gep8757 = getelementptr i8, ptr %p8756, i64 0
  %op8755 = ptrtoint ptr %gep8757 to i64
  store i64 %op8755, ptr %slot1451, align 8
  %v8758 = load i64, ptr %slot1451, align 8
  %p8759 = inttoptr i64 %v8758 to ptr
  %ld8760 = load i64, ptr %p8759, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8760, ptr %slot1452, align 8
  %v8761 = load i64, ptr %slot1452, align 8
  %cmp8762 = icmp ne i64 %v8761, 0
  %cv8763 = zext i1 %cmp8762 to i32
  store i32 %cv8763, ptr %slot1453, align 8
  %v8764 = load i32, ptr %slot1453, align 8
  %cv8765 = zext i32 %v8764 to i64
  %cond8766 = icmp ne i64 %cv8765, 0
  br i1 %cond8766, label %bb_rcmoveheader2172, label %bb_rcmovenext2172
bb_rcmoveheader2172:
  %v8767 = load i64, ptr %slot1452, align 8
  %op8768 = sub i64 %v8767, 16
  store i64 %op8768, ptr %slot1454, align 8
  %v8769 = load i64, ptr %slot1452, align 8
  %p8770 = inttoptr i64 %v8769 to ptr
  %rgep8771 = getelementptr i8, ptr %p8770, i64 -16
  %ld8772 = load i64, ptr %rgep8771, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8772, ptr %slot1455, align 8
  %v8773 = load i64, ptr %slot1455, align 8
  %op8774 = and i64 %v8773, 5764607523034234881
  store i64 %op8774, ptr %slot1456, align 8
  %v8775 = load i64, ptr %slot1456, align 8
  %cmp8776 = icmp ne i64 %v8775, 0
  %cv8777 = zext i1 %cmp8776 to i32
  store i32 %cv8777, ptr %slot1457, align 8
  %v8778 = load i32, ptr %slot1457, align 8
  %cv8779 = zext i32 %v8778 to i64
  %cond8780 = icmp ne i64 %cv8779, 0
  br i1 %cond8780, label %bb_rcmoveslow2164, label %bb_rcmovenext2172
bb_rcmovenext2172:
  %v8781 = load i64, ptr %slot1439, align 8
  %v8782 = load i64, ptr %slot1444, align 8
  %p8783 = inttoptr i64 %v8781 to ptr
  %p8784 = inttoptr i64 %v8782 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8784, ptr %p8783, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8785 = load i64, ptr %slot1439, align 8
  %p8786 = inttoptr i64 %v8785 to ptr
  store i64 0, ptr %p8786, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2164
bb_rcmoveslow2164:
  %v8787 = load i64, ptr %slot96, align 8
  %v8788 = load i64, ptr %slot1444, align 8
  %v8789 = load i64, ptr %slot1439, align 8
  %v8790 = load i64, ptr %slot1445, align 8
  %cv8791 = trunc i64 %v8790 to i32
  %call8792 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take(i64 %v8787, i64 %v8788, i64 %v8789, i32 %cv8791) nomerge, !dbg !212
  store i32 %call8792, ptr %slot1458, align 8
  %v8793 = load i32, ptr %slot1458, align 8
  %cv8794 = zext i32 %v8793 to i64
  %cond8795 = icmp ne i64 %cv8794, 0
  br i1 %cond8795, label %bb_rcsuccess2179, label %bb_rcfailure2179
bb_rcfailure2179:
  %v8796 = load i64, ptr %slot96, align 8
  %p8797 = inttoptr i64 %v8796 to ptr
  %call8798 = call i32 @myl_rc_take_failure(ptr %p8797) nomerge, !dbg !212
  store i32 %call8798, ptr %slot1459, align 8
  %v8799 = load i64, ptr %slot1, align 8
  %p8800 = inttoptr i64 %v8799 to ptr
  %v8801 = load i32, ptr %slot1459, align 8
  %call8802 = call i32 @myl_qbe_rc_status(ptr %p8800, i32 %v8801) nomerge, !dbg !212
  store i32 %call8802, ptr %slot1460, align 8
  br label %bb_failure
bb_rcsuccess2179:
  br label %bb_rcmoved2164
bb_rcmoved2164:
  %v8803 = load i64, ptr %slot28, align 8
  %p8804 = inttoptr i64 %v8803 to ptr
  store i32 0, ptr %p8804, align 4, !alias.scope !3, !noalias !4
  %v8805 = load i64, ptr %slot35, align 8
  %p8806 = inttoptr i64 %v8805 to ptr
  store i32 2, ptr %p8806, align 4, !alias.scope !3, !noalias !4
  %v8807 = load i64, ptr %slot34, align 8
  %p8808 = inttoptr i64 %v8807 to ptr
  store i32 1, ptr %p8808, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2161
bb_rcprivateloan2161:
  %v8809 = load i64, ptr %slot28, align 8
  %p8810 = inttoptr i64 %v8809 to ptr
  %ld8811 = load i32, ptr %p8810, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8811, ptr %slot1461, align 8
  %v8812 = load i64, ptr %slot29, align 8
  %p8813 = inttoptr i64 %v8812 to ptr
  %ld8814 = load i32, ptr %p8813, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8814, ptr %slot1462, align 8
  %v8815 = load i32, ptr %slot1462, align 8
  %cmp8816 = icmp eq i32 %v8815, 16
  %cv8817 = zext i1 %cmp8816 to i32
  store i32 %cv8817, ptr %slot1463, align 8
  %v8818 = load i32, ptr %slot1463, align 8
  %v8819 = load i32, ptr %slot1461, align 8
  %op8820 = and i32 %v8818, %v8819
  store i32 %op8820, ptr %slot1463, align 8
  %v8821 = load i32, ptr %slot1463, align 8
  %cv8822 = zext i32 %v8821 to i64
  %cond8823 = icmp ne i64 %cv8822, 0
  br i1 %cond8823, label %bb_rcprivatemove2161, label %bb_rcprivatenew2161
bb_rcprivatemove2161:
  %v8824 = load i64, ptr %slot41, align 8
  store i64 %v8824, ptr %slot1464, align 8
  %v8825 = load i64, ptr %slot1439, align 8
  %v8826 = load i64, ptr %slot1464, align 8
  %p8827 = inttoptr i64 %v8825 to ptr
  %p8828 = inttoptr i64 %v8826 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p8828, ptr %p8827, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v8829 = load i64, ptr %slot1439, align 8
  %p8830 = inttoptr i64 %v8829 to ptr
  store i64 0, ptr %p8830, align 8, !alias.scope !3, !noalias !4
  %v8831 = load i64, ptr %slot35, align 8
  %p8832 = inttoptr i64 %v8831 to ptr
  store i32 2, ptr %p8832, align 4, !alias.scope !3, !noalias !4
  %v8833 = load i64, ptr %slot35, align 8
  %p8834 = inttoptr i64 %v8833 to ptr
  store i32 16, ptr %p8834, align 4, !alias.scope !3, !noalias !4
  %v8835 = load i64, ptr %slot34, align 8
  %p8836 = inttoptr i64 %v8835 to ptr
  store i32 1, ptr %p8836, align 4, !alias.scope !3, !noalias !4
  %v8837 = load i64, ptr %slot28, align 8
  %p8838 = inttoptr i64 %v8837 to ptr
  store i32 0, ptr %p8838, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2161
bb_rcprivatenew2161:
  %v8839 = load i64, ptr %slot41, align 8
  store i64 %v8839, ptr %slot1465, align 8
  %v8840 = load i64, ptr %slot1439, align 8
  %p8841 = inttoptr i64 %v8840 to ptr
  %ld8842 = load i64, ptr %p8841, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8842, ptr %slot1466, align 8
  %v8843 = load i64, ptr %slot1466, align 8
  %cmp8844 = icmp ne i64 %v8843, 0
  %cv8845 = zext i1 %cmp8844 to i32
  store i32 %cv8845, ptr %slot1467, align 8
  %v8846 = load i32, ptr %slot1467, align 8
  %cv8847 = zext i32 %v8846 to i64
  %cond8848 = icmp ne i64 %cv8847, 0
  br i1 %cond8848, label %bb_rcgnn2197, label %bb_rcgstore2197
bb_rcgnn2197:
  %v8849 = load i64, ptr %slot1466, align 8
  %op8850 = sub i64 %v8849, 16
  store i64 %op8850, ptr %slot1468, align 8
  %v8851 = load i64, ptr %slot1466, align 8
  %p8852 = inttoptr i64 %v8851 to ptr
  %rgep8853 = getelementptr i8, ptr %p8852, i64 -16
  %ld8854 = load i64, ptr %rgep8853, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8854, ptr %slot1469, align 8
  %v8855 = load i64, ptr %slot1469, align 8
  %op8856 = and i64 %v8855, 4611686018427387906
  store i64 %op8856, ptr %slot1470, align 8
  %v8857 = load i64, ptr %slot1470, align 8
  %cmp8858 = icmp ne i64 %v8857, 0
  %cv8859 = zext i1 %cmp8858 to i32
  store i32 %cv8859, ptr %slot1471, align 8
  %v8860 = load i32, ptr %slot1471, align 8
  %cv8861 = zext i32 %v8860 to i64
  %cond8862 = icmp ne i64 %cv8861, 0
  br i1 %cond8862, label %bb_rcgstore2197, label %bb_rcginc2197
bb_rcginc2197:
  %v8863 = load i64, ptr %slot1466, align 8
  %op8864 = sub i64 %v8863, 24
  store i64 %op8864, ptr %slot1472, align 8
  %v8865 = load i64, ptr %slot1466, align 8
  %p8866 = inttoptr i64 %v8865 to ptr
  %rgep8867 = getelementptr i8, ptr %p8866, i64 -24
  %ld8868 = load i64, ptr %rgep8867, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8868, ptr %slot1473, align 8
  %v8869 = load i64, ptr %slot1473, align 8
  %op8870 = add i64 %v8869, 1
  store i64 %op8870, ptr %slot1474, align 8
  %v8871 = load i64, ptr %slot1474, align 8
  %cmp8872 = icmp eq i64 %v8871, 0
  %cv8873 = zext i1 %cmp8872 to i32
  store i32 %cv8873, ptr %slot1475, align 8
  %v8874 = load i32, ptr %slot1475, align 8
  %cv8875 = zext i32 %v8874 to i64
  %cond8876 = icmp ne i64 %cv8875, 0
  br i1 %cond8876, label %bb_rcglimit2197, label %bb_rcgcapacity2197
bb_rcglimit2197:
  %v8877 = load i64, ptr %slot1, align 8
  %p8878 = inttoptr i64 %v8877 to ptr
  %call8879 = call i32 @myl_qbe_rc_status(ptr %p8878, i32 2) nomerge, !dbg !212
  store i32 %call8879, ptr %slot1476, align 8
  br label %bb_failure
bb_rcgcapacity2197:
  %v8880 = load i64, ptr %slot1474, align 8
  %v8881 = load i64, ptr %slot1466, align 8
  %p8882 = inttoptr i64 %v8881 to ptr
  %rgep8883 = getelementptr i8, ptr %p8882, i64 -24
  store i64 %v8880, ptr %rgep8883, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore2197
bb_rcgstore2197:
  %v8884 = load i64, ptr %slot1466, align 8
  %v8885 = load i64, ptr %slot1465, align 8
  %p8886 = inttoptr i64 %v8885 to ptr
  store i64 %v8884, ptr %p8886, align 8, !alias.scope !3, !noalias !4
  %v8887 = load i64, ptr %slot35, align 8
  %p8888 = inttoptr i64 %v8887 to ptr
  store i32 2, ptr %p8888, align 4, !alias.scope !3, !noalias !4
  %v8889 = load i64, ptr %slot35, align 8
  %p8890 = inttoptr i64 %v8889 to ptr
  store i32 16, ptr %p8890, align 4, !alias.scope !3, !noalias !4
  %v8891 = load i64, ptr %slot34, align 8
  %p8892 = inttoptr i64 %v8891 to ptr
  store i32 1, ptr %p8892, align 4, !alias.scope !3, !noalias !4
  %v8893 = load i64, ptr %slot28, align 8
  %p8894 = inttoptr i64 %v8893 to ptr
  %ld8895 = load i32, ptr %p8894, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8895, ptr %slot1477, align 8
  %v8896 = load i32, ptr %slot1477, align 8
  %cv8897 = zext i32 %v8896 to i64
  %cond8898 = icmp ne i64 %cv8897, 0
  br i1 %cond8898, label %bb_rcslotdrop2213, label %bb_rcslotdone2213
bb_rcslotdrop2213:
  %v8899 = load i64, ptr %slot28, align 8
  %p8900 = inttoptr i64 %v8899 to ptr
  store i32 0, ptr %p8900, align 4, !alias.scope !3, !noalias !4
  %v8901 = load i64, ptr %slot37, align 8
  store i64 %v8901, ptr %slot1478, align 8
  %v8902 = load i64, ptr %slot29, align 8
  %p8903 = inttoptr i64 %v8902 to ptr
  %ld8904 = load i32, ptr %p8903, align 4, !alias.scope !3, !noalias !4
  store i32 %ld8904, ptr %slot1479, align 8
  %v8905 = load i32, ptr %slot1479, align 8
  %op8906 = and i32 %v8905, 28
  store i32 %op8906, ptr %slot1480, align 8
  %v8907 = load i32, ptr %slot1480, align 8
  %cv8908 = zext i32 %v8907 to i64
  %cond8909 = icmp ne i64 %cv8908, 0
  br i1 %cond8909, label %bb_rcslotrole2213, label %bb_rcslotowner2213
bb_rcslotrole2213:
  %v8910 = load i64, ptr %slot96, align 8
  store i64 %v8910, ptr %slot1481, align 8
  %v8911 = load i64, ptr %slot1478, align 8
  %p8912 = inttoptr i64 %v8911 to ptr
  %ld8913 = load i64, ptr %p8912, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8913, ptr %slot1482, align 8
  %v8914 = load i64, ptr %slot1482, align 8
  %cmp8915 = icmp ne i64 %v8914, 0
  %cv8916 = zext i1 %cmp8915 to i32
  store i32 %cv8916, ptr %slot1483, align 8
  %v8917 = load i32, ptr %slot1483, align 8
  %cv8918 = zext i32 %v8917 to i64
  %cond8919 = icmp ne i64 %cv8918, 0
  br i1 %cond8919, label %bb_rcgnn2229, label %bb_rcgdone2229
bb_rcgnn2229:
  %v8920 = load i64, ptr %slot1482, align 8
  %op8921 = sub i64 %v8920, 16
  store i64 %op8921, ptr %slot1484, align 8
  %v8922 = load i64, ptr %slot1482, align 8
  %p8923 = inttoptr i64 %v8922 to ptr
  %rgep8924 = getelementptr i8, ptr %p8923, i64 -16
  %ld8925 = load i64, ptr %rgep8924, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8925, ptr %slot1485, align 8
  %v8926 = load i64, ptr %slot1485, align 8
  %op8927 = and i64 %v8926, 4611686018427387906
  store i64 %op8927, ptr %slot1486, align 8
  %v8928 = load i64, ptr %slot1486, align 8
  %cmp8929 = icmp ne i64 %v8928, 0
  %cv8930 = zext i1 %cmp8929 to i32
  store i32 %cv8930, ptr %slot1487, align 8
  %v8931 = load i32, ptr %slot1487, align 8
  %cv8932 = zext i32 %v8931 to i64
  %cond8933 = icmp ne i64 %cv8932, 0
  br i1 %cond8933, label %bb_rcgclear2229, label %bb_rcgcounted2229
bb_rcgcounted2229:
  %v8934 = load i64, ptr %slot1482, align 8
  %op8935 = sub i64 %v8934, 24
  store i64 %op8935, ptr %slot1488, align 8
  %v8936 = load i64, ptr %slot1482, align 8
  %p8937 = inttoptr i64 %v8936 to ptr
  %rgep8938 = getelementptr i8, ptr %p8937, i64 -24
  %ld8939 = load i64, ptr %rgep8938, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8939, ptr %slot1489, align 8
  %v8940 = load i64, ptr %slot1489, align 8
  %op8941 = sub i64 %v8940, 1
  store i64 %op8941, ptr %slot1490, align 8
  %v8942 = load i64, ptr %slot1490, align 8
  %cmp8943 = icmp eq i64 %v8942, 0
  %cv8944 = zext i1 %cmp8943 to i32
  store i32 %cv8944, ptr %slot1491, align 8
  %v8945 = load i32, ptr %slot1491, align 8
  %cv8946 = zext i32 %v8945 to i64
  %cond8947 = icmp ne i64 %cv8946, 0
  br i1 %cond8947, label %bb_rcglast2229, label %bb_rcgdec2229
bb_rcglast2229:
  %v8948 = load i64, ptr %slot1482, align 8
  %op8949 = sub i64 %v8948, 32
  store i64 %op8949, ptr %slot1492, align 8
  %v8950 = load i64, ptr %slot1482, align 8
  %p8951 = inttoptr i64 %v8950 to ptr
  %rgep8952 = getelementptr i8, ptr %p8951, i64 -32
  %ld8953 = load i64, ptr %rgep8952, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8953, ptr %slot1493, align 8
  %v8954 = load i64, ptr %slot1493, align 8
  %cmp8955 = icmp ne i64 %v8954, 0
  %cv8956 = zext i1 %cmp8955 to i32
  store i32 %cv8956, ptr %slot1494, align 8
  %v8957 = load i32, ptr %slot1494, align 8
  %cv8958 = zext i32 %v8957 to i64
  %cond8959 = icmp ne i64 %cv8958, 0
  br i1 %cond8959, label %bb_rcgdec2229, label %bb_rcgslow2229
bb_rcgslow2229:
  %v8960 = load i64, ptr %slot1481, align 8
  %v8961 = load i64, ptr %slot1478, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v8960, i64 %v8961) nomerge, !dbg !212
  br label %bb_rcgdone2229
bb_rcgdec2229:
  %v8962 = load i64, ptr %slot1490, align 8
  %v8963 = load i64, ptr %slot1482, align 8
  %p8964 = inttoptr i64 %v8963 to ptr
  %rgep8965 = getelementptr i8, ptr %p8964, i64 -24
  store i64 %v8962, ptr %rgep8965, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2229
bb_rcgclear2229:
  %v8966 = load i64, ptr %slot1478, align 8
  %p8967 = inttoptr i64 %v8966 to ptr
  store i64 0, ptr %p8967, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2229
bb_rcgdone2229:
  br label %bb_rcslotdone2213
bb_rcslotowner2213:
  %v8968 = load i64, ptr %slot96, align 8
  store i64 %v8968, ptr %slot1495, align 8
  %v8969 = load i64, ptr %slot1478, align 8
  %p8970 = inttoptr i64 %v8969 to ptr
  %ld8971 = load i64, ptr %p8970, align 8, !alias.scope !3, !noalias !4
  store i64 %ld8971, ptr %slot1496, align 8
  %v8972 = load i64, ptr %slot1496, align 8
  %cmp8973 = icmp ne i64 %v8972, 0
  %cv8974 = zext i1 %cmp8973 to i32
  store i32 %cv8974, ptr %slot1497, align 8
  %v8975 = load i32, ptr %slot1497, align 8
  %cv8976 = zext i32 %v8975 to i64
  %cond8977 = icmp ne i64 %cv8976, 0
  br i1 %cond8977, label %bb_rcgnn2244, label %bb_rcgdone2244
bb_rcgnn2244:
  %v8978 = load i64, ptr %slot1496, align 8
  %op8979 = sub i64 %v8978, 16
  store i64 %op8979, ptr %slot1498, align 8
  %v8980 = load i64, ptr %slot1496, align 8
  %p8981 = inttoptr i64 %v8980 to ptr
  %rgep8982 = getelementptr i8, ptr %p8981, i64 -16
  %ld8983 = load i64, ptr %rgep8982, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8983, ptr %slot1499, align 8
  %v8984 = load i64, ptr %slot1499, align 8
  %op8985 = and i64 %v8984, 4611686018427387906
  store i64 %op8985, ptr %slot1500, align 8
  %v8986 = load i64, ptr %slot1500, align 8
  %cmp8987 = icmp ne i64 %v8986, 0
  %cv8988 = zext i1 %cmp8987 to i32
  store i32 %cv8988, ptr %slot1501, align 8
  %v8989 = load i32, ptr %slot1501, align 8
  %cv8990 = zext i32 %v8989 to i64
  %cond8991 = icmp ne i64 %cv8990, 0
  br i1 %cond8991, label %bb_rcgclear2244, label %bb_rcgcounted2244
bb_rcgcounted2244:
  %v8992 = load i64, ptr %slot1496, align 8
  %op8993 = sub i64 %v8992, 32
  store i64 %op8993, ptr %slot1502, align 8
  %v8994 = load i64, ptr %slot1496, align 8
  %p8995 = inttoptr i64 %v8994 to ptr
  %rgep8996 = getelementptr i8, ptr %p8995, i64 -32
  %ld8997 = load i64, ptr %rgep8996, align 8, !alias.scope !9, !noalias !10
  store i64 %ld8997, ptr %slot1503, align 8
  %v8998 = load i64, ptr %slot1503, align 8
  %op8999 = sub i64 %v8998, 1
  store i64 %op8999, ptr %slot1504, align 8
  %v9000 = load i64, ptr %slot1504, align 8
  %cmp9001 = icmp eq i64 %v9000, 0
  %cv9002 = zext i1 %cmp9001 to i32
  store i32 %cv9002, ptr %slot1505, align 8
  %v9003 = load i32, ptr %slot1505, align 8
  %cv9004 = zext i32 %v9003 to i64
  %cond9005 = icmp ne i64 %cv9004, 0
  br i1 %cond9005, label %bb_rcglast2244, label %bb_rcgdec2244
bb_rcglast2244:
  %v9006 = load i64, ptr %slot1496, align 8
  %op9007 = sub i64 %v9006, 24
  store i64 %op9007, ptr %slot1506, align 8
  %v9008 = load i64, ptr %slot1496, align 8
  %p9009 = inttoptr i64 %v9008 to ptr
  %rgep9010 = getelementptr i8, ptr %p9009, i64 -24
  %ld9011 = load i64, ptr %rgep9010, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9011, ptr %slot1507, align 8
  %v9012 = load i64, ptr %slot1507, align 8
  %cmp9013 = icmp ne i64 %v9012, 0
  %cv9014 = zext i1 %cmp9013 to i32
  store i32 %cv9014, ptr %slot1508, align 8
  %v9015 = load i32, ptr %slot1508, align 8
  %cv9016 = zext i32 %v9015 to i64
  %cond9017 = icmp ne i64 %cv9016, 0
  br i1 %cond9017, label %bb_rcgdec2244, label %bb_rcgslow2244
bb_rcgslow2244:
  %v9018 = load i64, ptr %slot1495, align 8
  %v9019 = load i64, ptr %slot1478, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v9018, i64 %v9019) nomerge, !dbg !212
  br label %bb_rcgdone2244
bb_rcgdec2244:
  %v9020 = load i64, ptr %slot1504, align 8
  %v9021 = load i64, ptr %slot1496, align 8
  %p9022 = inttoptr i64 %v9021 to ptr
  %rgep9023 = getelementptr i8, ptr %p9022, i64 -32
  store i64 %v9020, ptr %rgep9023, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2244
bb_rcgclear2244:
  %v9024 = load i64, ptr %slot1478, align 8
  %p9025 = inttoptr i64 %v9024 to ptr
  store i64 0, ptr %p9025, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2244
bb_rcgdone2244:
  br label %bb_rcslotdone2213
bb_rcslotdone2213:
  br label %bb_rcprivateprepared2161
bb_rcprivateprepared2161:
  %v9026 = load i64, ptr %slot20, align 8
  %p9027 = inttoptr i64 %v9026 to ptr
  %ld9028 = load i32, ptr %p9027, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9028, ptr %slot1509, align 8
  %v9029 = load i32, ptr %slot1509, align 8
  %cv9030 = zext i32 %v9029 to i64
  %cond9031 = icmp ne i64 %cv9030, 0
  br i1 %cond9031, label %bb_rcslotdrop2251, label %bb_rcslotdone2251
bb_rcslotdrop2251:
  %v9032 = load i64, ptr %slot20, align 8
  %p9033 = inttoptr i64 %v9032 to ptr
  store i32 0, ptr %p9033, align 4, !alias.scope !3, !noalias !4
  %v9034 = load i64, ptr %slot65, align 8
  store i64 %v9034, ptr %slot1510, align 8
  %v9035 = load i64, ptr %slot21, align 8
  %p9036 = inttoptr i64 %v9035 to ptr
  %ld9037 = load i32, ptr %p9036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9037, ptr %slot1511, align 8
  %v9038 = load i32, ptr %slot1511, align 8
  %op9039 = and i32 %v9038, 28
  store i32 %op9039, ptr %slot1512, align 8
  %v9040 = load i32, ptr %slot1512, align 8
  %cv9041 = zext i32 %v9040 to i64
  %cond9042 = icmp ne i64 %cv9041, 0
  br i1 %cond9042, label %bb_rcslotrole2251, label %bb_rcslotowner2251
bb_rcslotrole2251:
  %v9043 = load i64, ptr %slot96, align 8
  store i64 %v9043, ptr %slot1513, align 8
  %v9044 = load i64, ptr %slot1510, align 8
  %p9045 = inttoptr i64 %v9044 to ptr
  %ld9046 = load i64, ptr %p9045, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9046, ptr %slot1514, align 8
  %v9047 = load i64, ptr %slot1514, align 8
  %cmp9048 = icmp ne i64 %v9047, 0
  %cv9049 = zext i1 %cmp9048 to i32
  store i32 %cv9049, ptr %slot1515, align 8
  %v9050 = load i32, ptr %slot1515, align 8
  %cv9051 = zext i32 %v9050 to i64
  %cond9052 = icmp ne i64 %cv9051, 0
  br i1 %cond9052, label %bb_rcgnn2267, label %bb_rcgdone2267
bb_rcgnn2267:
  %v9053 = load i64, ptr %slot1514, align 8
  %op9054 = sub i64 %v9053, 16
  store i64 %op9054, ptr %slot1516, align 8
  %v9055 = load i64, ptr %slot1514, align 8
  %p9056 = inttoptr i64 %v9055 to ptr
  %rgep9057 = getelementptr i8, ptr %p9056, i64 -16
  %ld9058 = load i64, ptr %rgep9057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9058, ptr %slot1517, align 8
  %v9059 = load i64, ptr %slot1517, align 8
  %op9060 = and i64 %v9059, 4611686018427387906
  store i64 %op9060, ptr %slot1518, align 8
  %v9061 = load i64, ptr %slot1518, align 8
  %cmp9062 = icmp ne i64 %v9061, 0
  %cv9063 = zext i1 %cmp9062 to i32
  store i32 %cv9063, ptr %slot1519, align 8
  %v9064 = load i32, ptr %slot1519, align 8
  %cv9065 = zext i32 %v9064 to i64
  %cond9066 = icmp ne i64 %cv9065, 0
  br i1 %cond9066, label %bb_rcgclear2267, label %bb_rcgcounted2267
bb_rcgcounted2267:
  %v9067 = load i64, ptr %slot1514, align 8
  %op9068 = sub i64 %v9067, 24
  store i64 %op9068, ptr %slot1520, align 8
  %v9069 = load i64, ptr %slot1514, align 8
  %p9070 = inttoptr i64 %v9069 to ptr
  %rgep9071 = getelementptr i8, ptr %p9070, i64 -24
  %ld9072 = load i64, ptr %rgep9071, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9072, ptr %slot1521, align 8
  %v9073 = load i64, ptr %slot1521, align 8
  %op9074 = sub i64 %v9073, 1
  store i64 %op9074, ptr %slot1522, align 8
  %v9075 = load i64, ptr %slot1522, align 8
  %cmp9076 = icmp eq i64 %v9075, 0
  %cv9077 = zext i1 %cmp9076 to i32
  store i32 %cv9077, ptr %slot1523, align 8
  %v9078 = load i32, ptr %slot1523, align 8
  %cv9079 = zext i32 %v9078 to i64
  %cond9080 = icmp ne i64 %cv9079, 0
  br i1 %cond9080, label %bb_rcglast2267, label %bb_rcgdec2267
bb_rcglast2267:
  %v9081 = load i64, ptr %slot1514, align 8
  %op9082 = sub i64 %v9081, 32
  store i64 %op9082, ptr %slot1524, align 8
  %v9083 = load i64, ptr %slot1514, align 8
  %p9084 = inttoptr i64 %v9083 to ptr
  %rgep9085 = getelementptr i8, ptr %p9084, i64 -32
  %ld9086 = load i64, ptr %rgep9085, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9086, ptr %slot1525, align 8
  %v9087 = load i64, ptr %slot1525, align 8
  %cmp9088 = icmp ne i64 %v9087, 0
  %cv9089 = zext i1 %cmp9088 to i32
  store i32 %cv9089, ptr %slot1526, align 8
  %v9090 = load i32, ptr %slot1526, align 8
  %cv9091 = zext i32 %v9090 to i64
  %cond9092 = icmp ne i64 %cv9091, 0
  br i1 %cond9092, label %bb_rcgdec2267, label %bb_rcgslow2267
bb_rcgslow2267:
  %v9093 = load i64, ptr %slot1513, align 8
  %v9094 = load i64, ptr %slot1510, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v9093, i64 %v9094) nomerge, !dbg !212
  br label %bb_rcgdone2267
bb_rcgdec2267:
  %v9095 = load i64, ptr %slot1522, align 8
  %v9096 = load i64, ptr %slot1514, align 8
  %p9097 = inttoptr i64 %v9096 to ptr
  %rgep9098 = getelementptr i8, ptr %p9097, i64 -24
  store i64 %v9095, ptr %rgep9098, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2267
bb_rcgclear2267:
  %v9099 = load i64, ptr %slot1510, align 8
  %p9100 = inttoptr i64 %v9099 to ptr
  store i64 0, ptr %p9100, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2267
bb_rcgdone2267:
  br label %bb_rcslotdone2251
bb_rcslotowner2251:
  %v9101 = load i64, ptr %slot96, align 8
  store i64 %v9101, ptr %slot1527, align 8
  %v9102 = load i64, ptr %slot1510, align 8
  %p9103 = inttoptr i64 %v9102 to ptr
  %ld9104 = load i64, ptr %p9103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9104, ptr %slot1528, align 8
  %v9105 = load i64, ptr %slot1528, align 8
  %cmp9106 = icmp ne i64 %v9105, 0
  %cv9107 = zext i1 %cmp9106 to i32
  store i32 %cv9107, ptr %slot1529, align 8
  %v9108 = load i32, ptr %slot1529, align 8
  %cv9109 = zext i32 %v9108 to i64
  %cond9110 = icmp ne i64 %cv9109, 0
  br i1 %cond9110, label %bb_rcgnn2282, label %bb_rcgdone2282
bb_rcgnn2282:
  %v9111 = load i64, ptr %slot1528, align 8
  %op9112 = sub i64 %v9111, 16
  store i64 %op9112, ptr %slot1530, align 8
  %v9113 = load i64, ptr %slot1528, align 8
  %p9114 = inttoptr i64 %v9113 to ptr
  %rgep9115 = getelementptr i8, ptr %p9114, i64 -16
  %ld9116 = load i64, ptr %rgep9115, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9116, ptr %slot1531, align 8
  %v9117 = load i64, ptr %slot1531, align 8
  %op9118 = and i64 %v9117, 4611686018427387906
  store i64 %op9118, ptr %slot1532, align 8
  %v9119 = load i64, ptr %slot1532, align 8
  %cmp9120 = icmp ne i64 %v9119, 0
  %cv9121 = zext i1 %cmp9120 to i32
  store i32 %cv9121, ptr %slot1533, align 8
  %v9122 = load i32, ptr %slot1533, align 8
  %cv9123 = zext i32 %v9122 to i64
  %cond9124 = icmp ne i64 %cv9123, 0
  br i1 %cond9124, label %bb_rcgclear2282, label %bb_rcgcounted2282
bb_rcgcounted2282:
  %v9125 = load i64, ptr %slot1528, align 8
  %op9126 = sub i64 %v9125, 32
  store i64 %op9126, ptr %slot1534, align 8
  %v9127 = load i64, ptr %slot1528, align 8
  %p9128 = inttoptr i64 %v9127 to ptr
  %rgep9129 = getelementptr i8, ptr %p9128, i64 -32
  %ld9130 = load i64, ptr %rgep9129, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9130, ptr %slot1535, align 8
  %v9131 = load i64, ptr %slot1535, align 8
  %op9132 = sub i64 %v9131, 1
  store i64 %op9132, ptr %slot1536, align 8
  %v9133 = load i64, ptr %slot1536, align 8
  %cmp9134 = icmp eq i64 %v9133, 0
  %cv9135 = zext i1 %cmp9134 to i32
  store i32 %cv9135, ptr %slot1537, align 8
  %v9136 = load i32, ptr %slot1537, align 8
  %cv9137 = zext i32 %v9136 to i64
  %cond9138 = icmp ne i64 %cv9137, 0
  br i1 %cond9138, label %bb_rcglast2282, label %bb_rcgdec2282
bb_rcglast2282:
  %v9139 = load i64, ptr %slot1528, align 8
  %op9140 = sub i64 %v9139, 24
  store i64 %op9140, ptr %slot1538, align 8
  %v9141 = load i64, ptr %slot1528, align 8
  %p9142 = inttoptr i64 %v9141 to ptr
  %rgep9143 = getelementptr i8, ptr %p9142, i64 -24
  %ld9144 = load i64, ptr %rgep9143, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9144, ptr %slot1539, align 8
  %v9145 = load i64, ptr %slot1539, align 8
  %cmp9146 = icmp ne i64 %v9145, 0
  %cv9147 = zext i1 %cmp9146 to i32
  store i32 %cv9147, ptr %slot1540, align 8
  %v9148 = load i32, ptr %slot1540, align 8
  %cv9149 = zext i32 %v9148 to i64
  %cond9150 = icmp ne i64 %cv9149, 0
  br i1 %cond9150, label %bb_rcgdec2282, label %bb_rcgslow2282
bb_rcgslow2282:
  %v9151 = load i64, ptr %slot1527, align 8
  %v9152 = load i64, ptr %slot1510, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v9151, i64 %v9152) nomerge, !dbg !212
  br label %bb_rcgdone2282
bb_rcgdec2282:
  %v9153 = load i64, ptr %slot1536, align 8
  %v9154 = load i64, ptr %slot1528, align 8
  %p9155 = inttoptr i64 %v9154 to ptr
  %rgep9156 = getelementptr i8, ptr %p9155, i64 -32
  store i64 %v9153, ptr %rgep9156, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2282
bb_rcgclear2282:
  %v9157 = load i64, ptr %slot1510, align 8
  %p9158 = inttoptr i64 %v9157 to ptr
  store i64 0, ptr %p9158, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2282
bb_rcgdone2282:
  br label %bb_rcslotdone2251
bb_rcslotdone2251:
  %v9159 = load i64, ptr %slot65, align 8
  store i64 %v9159, ptr %slot1541, align 8
  %v9160 = load i64, ptr %slot41, align 8
  store i64 %v9160, ptr %slot1542, align 8
  %v9161 = load i64, ptr %slot1542, align 8
  %v9162 = load i64, ptr %slot1541, align 8
  %p9163 = inttoptr i64 %v9161 to ptr
  %p9164 = inttoptr i64 %v9162 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9164, ptr %p9163, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9165 = load i64, ptr %slot34, align 8
  %p9166 = inttoptr i64 %v9165 to ptr
  store i32 0, ptr %p9166, align 4, !alias.scope !3, !noalias !4
  %v9167 = load i64, ptr %slot21, align 8
  %p9168 = inttoptr i64 %v9167 to ptr
  store i32 2, ptr %p9168, align 4, !alias.scope !3, !noalias !4
  %v9169 = load i64, ptr %slot35, align 8
  %p9170 = inttoptr i64 %v9169 to ptr
  %ld9171 = load i32, ptr %p9170, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9171, ptr %slot1543, align 8
  %v9172 = load i32, ptr %slot1543, align 8
  %v9173 = load i64, ptr %slot21, align 8
  %p9174 = inttoptr i64 %v9173 to ptr
  store i32 %v9172, ptr %p9174, align 4, !alias.scope !3, !noalias !4
  %v9175 = load i64, ptr %slot20, align 8
  %p9176 = inttoptr i64 %v9175 to ptr
  store i32 1, ptr %p9176, align 4, !alias.scope !3, !noalias !4
  %p9177 = inttoptr i64 ptrtoint (ptr @myl_lit_73f49e3ebb26fac34a9ebd5051f9be52f8082f7cb414e46e76a3cbfe34871e25 to i64) to ptr
  %ld9178 = load i64, ptr %p9177, align 8, !alias.scope !4, !noalias !3
  store i64 %ld9178, ptr %slot1544, align 8
  %v9179 = load i64, ptr %slot1544, align 8
  %v9180 = load i64, ptr %slot69, align 8
  %p9181 = inttoptr i64 %v9180 to ptr
  store i64 %v9179, ptr %p9181, align 8, !alias.scope !3, !noalias !4
  %v9182 = load i64, ptr %slot69, align 8
  %p9183 = inttoptr i64 %v9182 to ptr
  %ld9184 = load i64, ptr %p9183, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9184, ptr %slot1545, align 8
  %v9185 = load i64, ptr %slot1545, align 8
  %v9186 = load i64, ptr %slot40, align 8
  %p9187 = inttoptr i64 %v9186 to ptr
  store i64 %v9185, ptr %p9187, align 8, !alias.scope !3, !noalias !4
  %v9188 = load i64, ptr %slot40, align 8
  store i64 %v9188, ptr %slot1546, align 8
  %v9189 = load i64, ptr %slot41, align 8
  store i64 %v9189, ptr %slot1547, align 8
  %v9190 = load i64, ptr %slot1546, align 8
  %v9191 = load i64, ptr %slot1547, align 8
  %p9192 = inttoptr i64 %v9190 to ptr
  %p9193 = inttoptr i64 %v9191 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9193, ptr %p9192, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9194 = load i64, ptr %slot35, align 8
  %p9195 = inttoptr i64 %v9194 to ptr
  store i32 2, ptr %p9195, align 4, !alias.scope !3, !noalias !4
  %v9196 = load i64, ptr %slot34, align 8
  %p9197 = inttoptr i64 %v9196 to ptr
  store i32 1, ptr %p9197, align 4, !alias.scope !3, !noalias !4
  %v9198 = load i64, ptr %slot37, align 8
  store i64 %v9198, ptr %slot1548, align 8
  %v9199 = load i64, ptr %slot41, align 8
  store i64 %v9199, ptr %slot1549, align 8
  %v9200 = load i64, ptr %slot1549, align 8
  %v9201 = load i64, ptr %slot1548, align 8
  %p9202 = inttoptr i64 %v9200 to ptr
  %p9203 = inttoptr i64 %v9201 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9203, ptr %p9202, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9204 = load i64, ptr %slot29, align 8
  %p9205 = inttoptr i64 %v9204 to ptr
  store i32 2, ptr %p9205, align 4, !alias.scope !3, !noalias !4
  %v9206 = load i64, ptr %slot35, align 8
  %p9207 = inttoptr i64 %v9206 to ptr
  %ld9208 = load i32, ptr %p9207, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9208, ptr %slot1550, align 8
  %v9209 = load i32, ptr %slot1550, align 8
  %v9210 = load i64, ptr %slot29, align 8
  %p9211 = inttoptr i64 %v9210 to ptr
  store i32 %v9209, ptr %p9211, align 4, !alias.scope !3, !noalias !4
  %v9212 = load i64, ptr %slot34, align 8
  %p9213 = inttoptr i64 %v9212 to ptr
  store i32 0, ptr %p9213, align 4, !alias.scope !3, !noalias !4
  %v9214 = load i64, ptr %slot28, align 8
  %p9215 = inttoptr i64 %v9214 to ptr
  store i32 1, ptr %p9215, align 4, !alias.scope !3, !noalias !4
  %v9216 = load i64, ptr %slot1548, align 8
  %p9217 = inttoptr i64 %v9216 to ptr
  %ld9218 = load i64, ptr %p9217, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9218, ptr %slot1551, align 8
  %v9219 = load i64, ptr %slot1551, align 8
  %v9220 = load i64, ptr %slot69, align 8
  %p9221 = inttoptr i64 %v9220 to ptr
  store i64 %v9219, ptr %p9221, align 8, !alias.scope !3, !noalias !4
  %v9222 = load i64, ptr %slot65, align 8
  store i64 %v9222, ptr %slot1552, align 8
  %v9223 = load i64, ptr %slot21, align 8
  %p9224 = inttoptr i64 %v9223 to ptr
  %ld9225 = load i32, ptr %p9224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9225, ptr %slot1553, align 8
  %v9226 = load i32, ptr %slot1553, align 8
  %cmp9227 = icmp eq i32 %v9226, 16
  %cv9228 = zext i1 %cmp9227 to i32
  store i32 %cv9228, ptr %slot1554, align 8
  %v9229 = load i64, ptr %slot20, align 8
  %p9230 = inttoptr i64 %v9229 to ptr
  %ld9231 = load i32, ptr %p9230, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9231, ptr %slot1555, align 8
  %v9232 = load i32, ptr %slot1555, align 8
  %v9233 = load i32, ptr %slot1554, align 8
  %op9234 = and i32 %v9232, %v9233
  store i32 %op9234, ptr %slot1556, align 8
  %v9235 = load i32, ptr %slot1556, align 8
  %cv9236 = zext i32 %v9235 to i64
  %cond9237 = icmp ne i64 %cv9236, 0
  br i1 %cond9237, label %bb_rcownlocal2315, label %bb_rcownedlocal2315
bb_rcownlocal2315:
  %v9238 = load i64, ptr %slot65, align 8
  store i64 %v9238, ptr %slot1557, align 8
  %v9239 = load i64, ptr %slot41, align 8
  store i64 %v9239, ptr %slot1558, align 8
  %v9240 = load i64, ptr %slot97, align 8
  store i64 %v9240, ptr %slot1559, align 8
  %v9241 = load i64, ptr %slot1557, align 8
  %p9242 = inttoptr i64 %v9241 to ptr
  %ld9243 = load i64, ptr %p9242, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9243, ptr %slot1560, align 8
  %v9244 = load i64, ptr %slot1560, align 8
  %cmp9245 = icmp ne i64 %v9244, 0
  %cv9246 = zext i1 %cmp9245 to i32
  store i32 %cv9246, ptr %slot1561, align 8
  %v9247 = load i32, ptr %slot1561, align 8
  %cv9248 = zext i32 %v9247 to i64
  %cond9249 = icmp ne i64 %cv9248, 0
  br i1 %cond9249, label %bb_rcgnn2322, label %bb_rcgplain2322
bb_rcgnn2322:
  %v9250 = load i64, ptr %slot1560, align 8
  %op9251 = sub i64 %v9250, 16
  store i64 %op9251, ptr %slot1562, align 8
  %v9252 = load i64, ptr %slot1560, align 8
  %p9253 = inttoptr i64 %v9252 to ptr
  %rgep9254 = getelementptr i8, ptr %p9253, i64 -16
  %ld9255 = load i64, ptr %rgep9254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9255, ptr %slot1563, align 8
  %v9256 = load i64, ptr %slot1563, align 8
  %op9257 = and i64 %v9256, 4611686018427387906
  store i64 %op9257, ptr %slot1564, align 8
  %v9258 = load i64, ptr %slot1564, align 8
  %cmp9259 = icmp ne i64 %v9258, 0
  %cv9260 = zext i1 %cmp9259 to i32
  store i32 %cv9260, ptr %slot1565, align 8
  %v9261 = load i32, ptr %slot1565, align 8
  %cv9262 = zext i32 %v9261 to i64
  %cond9263 = icmp ne i64 %cv9262, 0
  br i1 %cond9263, label %bb_rcgspecial2322, label %bb_rcginc2322
bb_rcginc2322:
  %v9264 = load i64, ptr %slot1560, align 8
  %op9265 = sub i64 %v9264, 32
  store i64 %op9265, ptr %slot1566, align 8
  %v9266 = load i64, ptr %slot1560, align 8
  %p9267 = inttoptr i64 %v9266 to ptr
  %rgep9268 = getelementptr i8, ptr %p9267, i64 -32
  %ld9269 = load i64, ptr %rgep9268, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9269, ptr %slot1567, align 8
  %v9270 = load i64, ptr %slot1567, align 8
  %op9271 = add i64 %v9270, 1
  store i64 %op9271, ptr %slot1568, align 8
  %v9272 = load i64, ptr %slot1568, align 8
  %cmp9273 = icmp eq i64 %v9272, 0
  %cv9274 = zext i1 %cmp9273 to i32
  store i32 %cv9274, ptr %slot1569, align 8
  %v9275 = load i32, ptr %slot1569, align 8
  %cv9276 = zext i32 %v9275 to i64
  %cond9277 = icmp ne i64 %cv9276, 0
  br i1 %cond9277, label %bb_rcglimit2322, label %bb_rcgcapacity2322
bb_rcglimit2322:
  %v9278 = load i64, ptr %slot1, align 8
  %p9279 = inttoptr i64 %v9278 to ptr
  %call9280 = call i32 @myl_qbe_rc_status(ptr %p9279, i32 2) nomerge, !dbg !214
  store i32 %call9280, ptr %slot1570, align 8
  br label %bb_failure
bb_rcgcapacity2322:
  %v9281 = load i64, ptr %slot1568, align 8
  %v9282 = load i64, ptr %slot1560, align 8
  %p9283 = inttoptr i64 %v9282 to ptr
  %rgep9284 = getelementptr i8, ptr %p9283, i64 -32
  store i64 %v9281, ptr %rgep9284, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2322
bb_rcgspecial2322:
  %v9285 = load i64, ptr %slot1563, align 8
  %op9286 = and i64 %v9285, 4611686018427387904
  store i64 %op9286, ptr %slot1571, align 8
  %v9287 = load i64, ptr %slot1571, align 8
  %cmp9288 = icmp ne i64 %v9287, 0
  %cv9289 = zext i1 %cmp9288 to i32
  store i32 %cv9289, ptr %slot1572, align 8
  %v9290 = load i32, ptr %slot1572, align 8
  %cv9291 = zext i32 %v9290 to i64
  %cond9292 = icmp ne i64 %cv9291, 0
  br i1 %cond9292, label %bb_rcgslow2322, label %bb_rcgplain2322
bb_rcgslow2322:
  %v9293 = load i64, ptr %slot96, align 8
  %v9294 = load i64, ptr %slot1558, align 8
  %v9295 = load i64, ptr %slot1557, align 8
  %v9296 = load i64, ptr %slot1559, align 8
  %cv9297 = trunc i64 %v9296 to i32
  %call9298 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v9293, i64 %v9294, i64 %v9295, i32 %cv9297) nomerge, !dbg !214
  store i32 %call9298, ptr %slot1573, align 8
  %v9299 = load i32, ptr %slot1573, align 8
  %cv9300 = zext i32 %v9299 to i64
  %cond9301 = icmp ne i64 %cv9300, 0
  br i1 %cond9301, label %bb_rcsuccess2336, label %bb_rcfailure2336
bb_rcfailure2336:
  %v9302 = load i64, ptr %slot96, align 8
  %p9303 = inttoptr i64 %v9302 to ptr
  %call9304 = call i32 @myl_rc_take_failure(ptr %p9303) nomerge, !dbg !214
  store i32 %call9304, ptr %slot1574, align 8
  %v9305 = load i64, ptr %slot1, align 8
  %p9306 = inttoptr i64 %v9305 to ptr
  %v9307 = load i32, ptr %slot1574, align 8
  %call9308 = call i32 @myl_qbe_rc_status(ptr %p9306, i32 %v9307) nomerge, !dbg !214
  store i32 %call9308, ptr %slot1575, align 8
  br label %bb_failure
bb_rcsuccess2336:
  br label %bb_rcgdone2322
bb_rcgplain2322:
  %v9309 = load i64, ptr %slot1560, align 8
  %v9310 = load i64, ptr %slot1558, align 8
  %p9311 = inttoptr i64 %v9310 to ptr
  store i64 %v9309, ptr %p9311, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2322
bb_rcgdone2322:
  %v9312 = load i64, ptr %slot35, align 8
  %p9313 = inttoptr i64 %v9312 to ptr
  store i32 2, ptr %p9313, align 4, !alias.scope !3, !noalias !4
  %v9314 = load i64, ptr %slot34, align 8
  %p9315 = inttoptr i64 %v9314 to ptr
  store i32 1, ptr %p9315, align 4, !alias.scope !3, !noalias !4
  %v9316 = load i64, ptr %slot20, align 8
  %p9317 = inttoptr i64 %v9316 to ptr
  %ld9318 = load i32, ptr %p9317, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9318, ptr %slot1576, align 8
  %v9319 = load i32, ptr %slot1576, align 8
  %cv9320 = zext i32 %v9319 to i64
  %cond9321 = icmp ne i64 %cv9320, 0
  br i1 %cond9321, label %bb_rcslotdrop2343, label %bb_rcslotdone2343
bb_rcslotdrop2343:
  %v9322 = load i64, ptr %slot20, align 8
  %p9323 = inttoptr i64 %v9322 to ptr
  store i32 0, ptr %p9323, align 4, !alias.scope !3, !noalias !4
  %v9324 = load i64, ptr %slot65, align 8
  store i64 %v9324, ptr %slot1577, align 8
  %v9325 = load i64, ptr %slot21, align 8
  %p9326 = inttoptr i64 %v9325 to ptr
  %ld9327 = load i32, ptr %p9326, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9327, ptr %slot1578, align 8
  %v9328 = load i32, ptr %slot1578, align 8
  %op9329 = and i32 %v9328, 28
  store i32 %op9329, ptr %slot1579, align 8
  %v9330 = load i32, ptr %slot1579, align 8
  %cv9331 = zext i32 %v9330 to i64
  %cond9332 = icmp ne i64 %cv9331, 0
  br i1 %cond9332, label %bb_rcslotrole2343, label %bb_rcslotowner2343
bb_rcslotrole2343:
  %v9333 = load i64, ptr %slot96, align 8
  store i64 %v9333, ptr %slot1580, align 8
  %v9334 = load i64, ptr %slot1577, align 8
  %p9335 = inttoptr i64 %v9334 to ptr
  %ld9336 = load i64, ptr %p9335, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9336, ptr %slot1581, align 8
  %v9337 = load i64, ptr %slot1581, align 8
  %cmp9338 = icmp ne i64 %v9337, 0
  %cv9339 = zext i1 %cmp9338 to i32
  store i32 %cv9339, ptr %slot1582, align 8
  %v9340 = load i32, ptr %slot1582, align 8
  %cv9341 = zext i32 %v9340 to i64
  %cond9342 = icmp ne i64 %cv9341, 0
  br i1 %cond9342, label %bb_rcgnn2359, label %bb_rcgdone2359
bb_rcgnn2359:
  %v9343 = load i64, ptr %slot1581, align 8
  %op9344 = sub i64 %v9343, 16
  store i64 %op9344, ptr %slot1583, align 8
  %v9345 = load i64, ptr %slot1581, align 8
  %p9346 = inttoptr i64 %v9345 to ptr
  %rgep9347 = getelementptr i8, ptr %p9346, i64 -16
  %ld9348 = load i64, ptr %rgep9347, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9348, ptr %slot1584, align 8
  %v9349 = load i64, ptr %slot1584, align 8
  %op9350 = and i64 %v9349, 4611686018427387906
  store i64 %op9350, ptr %slot1585, align 8
  %v9351 = load i64, ptr %slot1585, align 8
  %cmp9352 = icmp ne i64 %v9351, 0
  %cv9353 = zext i1 %cmp9352 to i32
  store i32 %cv9353, ptr %slot1586, align 8
  %v9354 = load i32, ptr %slot1586, align 8
  %cv9355 = zext i32 %v9354 to i64
  %cond9356 = icmp ne i64 %cv9355, 0
  br i1 %cond9356, label %bb_rcgclear2359, label %bb_rcgcounted2359
bb_rcgcounted2359:
  %v9357 = load i64, ptr %slot1581, align 8
  %op9358 = sub i64 %v9357, 24
  store i64 %op9358, ptr %slot1587, align 8
  %v9359 = load i64, ptr %slot1581, align 8
  %p9360 = inttoptr i64 %v9359 to ptr
  %rgep9361 = getelementptr i8, ptr %p9360, i64 -24
  %ld9362 = load i64, ptr %rgep9361, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9362, ptr %slot1588, align 8
  %v9363 = load i64, ptr %slot1588, align 8
  %op9364 = sub i64 %v9363, 1
  store i64 %op9364, ptr %slot1589, align 8
  %v9365 = load i64, ptr %slot1589, align 8
  %cmp9366 = icmp eq i64 %v9365, 0
  %cv9367 = zext i1 %cmp9366 to i32
  store i32 %cv9367, ptr %slot1590, align 8
  %v9368 = load i32, ptr %slot1590, align 8
  %cv9369 = zext i32 %v9368 to i64
  %cond9370 = icmp ne i64 %cv9369, 0
  br i1 %cond9370, label %bb_rcglast2359, label %bb_rcgdec2359
bb_rcglast2359:
  %v9371 = load i64, ptr %slot1581, align 8
  %op9372 = sub i64 %v9371, 32
  store i64 %op9372, ptr %slot1591, align 8
  %v9373 = load i64, ptr %slot1581, align 8
  %p9374 = inttoptr i64 %v9373 to ptr
  %rgep9375 = getelementptr i8, ptr %p9374, i64 -32
  %ld9376 = load i64, ptr %rgep9375, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9376, ptr %slot1592, align 8
  %v9377 = load i64, ptr %slot1592, align 8
  %cmp9378 = icmp ne i64 %v9377, 0
  %cv9379 = zext i1 %cmp9378 to i32
  store i32 %cv9379, ptr %slot1593, align 8
  %v9380 = load i32, ptr %slot1593, align 8
  %cv9381 = zext i32 %v9380 to i64
  %cond9382 = icmp ne i64 %cv9381, 0
  br i1 %cond9382, label %bb_rcgdec2359, label %bb_rcgslow2359
bb_rcgslow2359:
  %v9383 = load i64, ptr %slot1580, align 8
  %v9384 = load i64, ptr %slot1577, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v9383, i64 %v9384) nomerge, !dbg !214
  br label %bb_rcgdone2359
bb_rcgdec2359:
  %v9385 = load i64, ptr %slot1589, align 8
  %v9386 = load i64, ptr %slot1581, align 8
  %p9387 = inttoptr i64 %v9386 to ptr
  %rgep9388 = getelementptr i8, ptr %p9387, i64 -24
  store i64 %v9385, ptr %rgep9388, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2359
bb_rcgclear2359:
  %v9389 = load i64, ptr %slot1577, align 8
  %p9390 = inttoptr i64 %v9389 to ptr
  store i64 0, ptr %p9390, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2359
bb_rcgdone2359:
  br label %bb_rcslotdone2343
bb_rcslotowner2343:
  %v9391 = load i64, ptr %slot96, align 8
  store i64 %v9391, ptr %slot1594, align 8
  %v9392 = load i64, ptr %slot1577, align 8
  %p9393 = inttoptr i64 %v9392 to ptr
  %ld9394 = load i64, ptr %p9393, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9394, ptr %slot1595, align 8
  %v9395 = load i64, ptr %slot1595, align 8
  %cmp9396 = icmp ne i64 %v9395, 0
  %cv9397 = zext i1 %cmp9396 to i32
  store i32 %cv9397, ptr %slot1596, align 8
  %v9398 = load i32, ptr %slot1596, align 8
  %cv9399 = zext i32 %v9398 to i64
  %cond9400 = icmp ne i64 %cv9399, 0
  br i1 %cond9400, label %bb_rcgnn2374, label %bb_rcgdone2374
bb_rcgnn2374:
  %v9401 = load i64, ptr %slot1595, align 8
  %op9402 = sub i64 %v9401, 16
  store i64 %op9402, ptr %slot1597, align 8
  %v9403 = load i64, ptr %slot1595, align 8
  %p9404 = inttoptr i64 %v9403 to ptr
  %rgep9405 = getelementptr i8, ptr %p9404, i64 -16
  %ld9406 = load i64, ptr %rgep9405, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9406, ptr %slot1598, align 8
  %v9407 = load i64, ptr %slot1598, align 8
  %op9408 = and i64 %v9407, 4611686018427387906
  store i64 %op9408, ptr %slot1599, align 8
  %v9409 = load i64, ptr %slot1599, align 8
  %cmp9410 = icmp ne i64 %v9409, 0
  %cv9411 = zext i1 %cmp9410 to i32
  store i32 %cv9411, ptr %slot1600, align 8
  %v9412 = load i32, ptr %slot1600, align 8
  %cv9413 = zext i32 %v9412 to i64
  %cond9414 = icmp ne i64 %cv9413, 0
  br i1 %cond9414, label %bb_rcgclear2374, label %bb_rcgcounted2374
bb_rcgcounted2374:
  %v9415 = load i64, ptr %slot1595, align 8
  %op9416 = sub i64 %v9415, 32
  store i64 %op9416, ptr %slot1601, align 8
  %v9417 = load i64, ptr %slot1595, align 8
  %p9418 = inttoptr i64 %v9417 to ptr
  %rgep9419 = getelementptr i8, ptr %p9418, i64 -32
  %ld9420 = load i64, ptr %rgep9419, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9420, ptr %slot1602, align 8
  %v9421 = load i64, ptr %slot1602, align 8
  %op9422 = sub i64 %v9421, 1
  store i64 %op9422, ptr %slot1603, align 8
  %v9423 = load i64, ptr %slot1603, align 8
  %cmp9424 = icmp eq i64 %v9423, 0
  %cv9425 = zext i1 %cmp9424 to i32
  store i32 %cv9425, ptr %slot1604, align 8
  %v9426 = load i32, ptr %slot1604, align 8
  %cv9427 = zext i32 %v9426 to i64
  %cond9428 = icmp ne i64 %cv9427, 0
  br i1 %cond9428, label %bb_rcglast2374, label %bb_rcgdec2374
bb_rcglast2374:
  %v9429 = load i64, ptr %slot1595, align 8
  %op9430 = sub i64 %v9429, 24
  store i64 %op9430, ptr %slot1605, align 8
  %v9431 = load i64, ptr %slot1595, align 8
  %p9432 = inttoptr i64 %v9431 to ptr
  %rgep9433 = getelementptr i8, ptr %p9432, i64 -24
  %ld9434 = load i64, ptr %rgep9433, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9434, ptr %slot1606, align 8
  %v9435 = load i64, ptr %slot1606, align 8
  %cmp9436 = icmp ne i64 %v9435, 0
  %cv9437 = zext i1 %cmp9436 to i32
  store i32 %cv9437, ptr %slot1607, align 8
  %v9438 = load i32, ptr %slot1607, align 8
  %cv9439 = zext i32 %v9438 to i64
  %cond9440 = icmp ne i64 %cv9439, 0
  br i1 %cond9440, label %bb_rcgdec2374, label %bb_rcgslow2374
bb_rcgslow2374:
  %v9441 = load i64, ptr %slot1594, align 8
  %v9442 = load i64, ptr %slot1577, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v9441, i64 %v9442) nomerge, !dbg !214
  br label %bb_rcgdone2374
bb_rcgdec2374:
  %v9443 = load i64, ptr %slot1603, align 8
  %v9444 = load i64, ptr %slot1595, align 8
  %p9445 = inttoptr i64 %v9444 to ptr
  %rgep9446 = getelementptr i8, ptr %p9445, i64 -32
  store i64 %v9443, ptr %rgep9446, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2374
bb_rcgclear2374:
  %v9447 = load i64, ptr %slot1577, align 8
  %p9448 = inttoptr i64 %v9447 to ptr
  store i64 0, ptr %p9448, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2374
bb_rcgdone2374:
  br label %bb_rcslotdone2343
bb_rcslotdone2343:
  %v9449 = load i64, ptr %slot41, align 8
  store i64 %v9449, ptr %slot1608, align 8
  %v9450 = load i64, ptr %slot1608, align 8
  %v9451 = load i64, ptr %slot1557, align 8
  %p9452 = inttoptr i64 %v9450 to ptr
  %p9453 = inttoptr i64 %v9451 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9453, ptr %p9452, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9454 = load i64, ptr %slot21, align 8
  %p9455 = inttoptr i64 %v9454 to ptr
  store i32 2, ptr %p9455, align 4, !alias.scope !3, !noalias !4
  %v9456 = load i64, ptr %slot20, align 8
  %p9457 = inttoptr i64 %v9456 to ptr
  store i32 1, ptr %p9457, align 4, !alias.scope !3, !noalias !4
  %v9458 = load i64, ptr %slot34, align 8
  %p9459 = inttoptr i64 %v9458 to ptr
  store i32 0, ptr %p9459, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal2315
bb_rcownedlocal2315:
  %v9460 = load i64, ptr %slot21, align 8
  %p9461 = inttoptr i64 %v9460 to ptr
  store i32 2, ptr %p9461, align 4, !alias.scope !3, !noalias !4
  %v9462 = load i64, ptr %slot1552, align 8
  %p9463 = inttoptr i64 %v9462 to ptr
  %ld9464 = load i64, ptr %p9463, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9464, ptr %slot1609, align 8
  %v9465 = load i64, ptr %slot1609, align 8
  %cmp9466 = icmp ne i64 %v9465, 0
  %cv9467 = zext i1 %cmp9466 to i32
  store i32 %cv9467, ptr %slot1610, align 8
  %v9468 = load i32, ptr %slot1610, align 8
  %cv9469 = zext i32 %v9468 to i64
  %cond9470 = icmp ne i64 %cv9469, 0
  br i1 %cond9470, label %bb_rcguniquenn2383, label %bb_rcgunique2383
bb_rcguniquenn2383:
  %v9471 = load i64, ptr %slot1609, align 8
  %op9472 = sub i64 %v9471, 16
  store i64 %op9472, ptr %slot1611, align 8
  %v9473 = load i64, ptr %slot1609, align 8
  %p9474 = inttoptr i64 %v9473 to ptr
  %rgep9475 = getelementptr i8, ptr %p9474, i64 -16
  %ld9476 = load i64, ptr %rgep9475, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9476, ptr %slot1612, align 8
  %v9477 = load i64, ptr %slot1612, align 8
  %op9478 = and i64 %v9477, 6917529027641081858
  store i64 %op9478, ptr %slot1613, align 8
  %v9479 = load i64, ptr %slot1613, align 8
  %cmp9480 = icmp ne i64 %v9479, 0
  %cv9481 = zext i1 %cmp9480 to i32
  store i32 %cv9481, ptr %slot1614, align 8
  %v9482 = load i32, ptr %slot1614, align 8
  %cv9483 = zext i32 %v9482 to i64
  %cond9484 = icmp ne i64 %cv9483, 0
  br i1 %cond9484, label %bb_rcguniqueslow2383, label %bb_rcguniquecount2383
bb_rcguniquecount2383:
  %v9485 = load i64, ptr %slot1609, align 8
  %op9486 = sub i64 %v9485, 32
  store i64 %op9486, ptr %slot1615, align 8
  %v9487 = load i64, ptr %slot1609, align 8
  %p9488 = inttoptr i64 %v9487 to ptr
  %rgep9489 = getelementptr i8, ptr %p9488, i64 -32
  %ld9490 = load i64, ptr %rgep9489, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9490, ptr %slot1616, align 8
  %v9491 = load i64, ptr %slot1616, align 8
  %cmp9492 = icmp ult i64 %v9491, 2
  %cv9493 = zext i1 %cmp9492 to i32
  store i32 %cv9493, ptr %slot1617, align 8
  %v9494 = load i32, ptr %slot1617, align 8
  %cv9495 = zext i32 %v9494 to i64
  %cond9496 = icmp ne i64 %cv9495, 0
  br i1 %cond9496, label %bb_rcgunique2383, label %bb_rcguniqueslow2383
bb_rcguniqueslow2383:
  %v9497 = load i64, ptr %slot1, align 8
  %p9498 = inttoptr i64 %v9497 to ptr
  %p9499 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v9500 = load i64, ptr %slot1552, align 8
  %p9501 = inttoptr i64 %v9500 to ptr
  %v9502 = load i64, ptr %slot20, align 8
  %p9503 = inttoptr i64 %v9502 to ptr
  %call9504 = call i32 @myl_qbe_rc_unique_local(ptr %p9498, ptr %p9499, ptr %p9501, ptr %p9503) nomerge, !dbg !214
  store i32 %call9504, ptr %slot1618, align 8
  %v9505 = load i32, ptr %slot1618, align 8
  %cv9506 = zext i32 %v9505 to i64
  %cond9507 = icmp ne i64 %cv9506, 0
  br i1 %cond9507, label %bb_rcunique2394, label %bb_failure
bb_rcunique2394:
  br label %bb_rcgunique2383
bb_rcgunique2383:
  %v9508 = load i64, ptr %slot65, align 8
  %p9509 = inttoptr i64 %v9508 to ptr
  %ld9510 = load i64, ptr %p9509, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9510, ptr %slot1619, align 8
  %v9511 = load i64, ptr %slot69, align 8
  store i64 %v9511, ptr %slot1620, align 8
  %v9512 = load i64, ptr %slot1620, align 8
  %p9513 = inttoptr i64 %v9512 to ptr
  %ld9514 = load i64, ptr %p9513, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9514, ptr %slot1621, align 8
  %v9515 = load i64, ptr %slot1621, align 8
  %v9516 = load i64, ptr %slot42, align 8
  %p9517 = inttoptr i64 %v9516 to ptr
  store i64 %v9515, ptr %p9517, align 8, !alias.scope !3, !noalias !4
  %v9518 = load i64, ptr %slot42, align 8
  store i64 %v9518, ptr %slot1622, align 8
  %v9519 = load i64, ptr %slot96, align 8
  %v9520 = load i64, ptr %slot1619, align 8
  %v9521 = load i64, ptr %slot1622, align 8
  %call9522 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v9519, i64 %v9520, i64 %v9521) nomerge, !dbg !214
  store i32 %call9522, ptr %slot1623, align 8
  %v9523 = load i32, ptr %slot1623, align 8
  %cv9524 = zext i32 %v9523 to i64
  %cond9525 = icmp ne i64 %cv9524, 0
  br i1 %cond9525, label %bb_success2400, label %bb_failed2400
bb_failed2400:
  %v9526 = load i64, ptr %slot1, align 8
  %p9527 = inttoptr i64 %v9526 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9527) nomerge, !dbg !214
  unreachable
bb_success2400:
  %v9528 = load i64, ptr %slot69, align 8
  %p9529 = inttoptr i64 %v9528 to ptr
  store i64 0, ptr %p9529, align 8, !alias.scope !3, !noalias !4
  %v9530 = load i64, ptr %slot28, align 8
  %p9531 = inttoptr i64 %v9530 to ptr
  %ld9532 = load i32, ptr %p9531, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9532, ptr %slot1624, align 8
  %v9533 = load i32, ptr %slot1624, align 8
  %cv9534 = zext i32 %v9533 to i64
  %cond9535 = icmp ne i64 %cv9534, 0
  br i1 %cond9535, label %bb_rcslotdrop2403, label %bb_rcslotdone2403
bb_rcslotdrop2403:
  %v9536 = load i64, ptr %slot28, align 8
  %p9537 = inttoptr i64 %v9536 to ptr
  store i32 0, ptr %p9537, align 4, !alias.scope !3, !noalias !4
  %v9538 = load i64, ptr %slot37, align 8
  store i64 %v9538, ptr %slot1625, align 8
  %v9539 = load i64, ptr %slot29, align 8
  %p9540 = inttoptr i64 %v9539 to ptr
  %ld9541 = load i32, ptr %p9540, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9541, ptr %slot1626, align 8
  %v9542 = load i32, ptr %slot1626, align 8
  %op9543 = and i32 %v9542, 28
  store i32 %op9543, ptr %slot1627, align 8
  %v9544 = load i32, ptr %slot1627, align 8
  %cv9545 = zext i32 %v9544 to i64
  %cond9546 = icmp ne i64 %cv9545, 0
  br i1 %cond9546, label %bb_rcslotrole2403, label %bb_rcslotowner2403
bb_rcslotrole2403:
  %v9547 = load i64, ptr %slot96, align 8
  store i64 %v9547, ptr %slot1628, align 8
  %v9548 = load i64, ptr %slot1625, align 8
  %p9549 = inttoptr i64 %v9548 to ptr
  %ld9550 = load i64, ptr %p9549, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9550, ptr %slot1629, align 8
  %v9551 = load i64, ptr %slot1629, align 8
  %cmp9552 = icmp ne i64 %v9551, 0
  %cv9553 = zext i1 %cmp9552 to i32
  store i32 %cv9553, ptr %slot1630, align 8
  %v9554 = load i32, ptr %slot1630, align 8
  %cv9555 = zext i32 %v9554 to i64
  %cond9556 = icmp ne i64 %cv9555, 0
  br i1 %cond9556, label %bb_rcgnn2419, label %bb_rcgdone2419
bb_rcgnn2419:
  %v9557 = load i64, ptr %slot1629, align 8
  %op9558 = sub i64 %v9557, 16
  store i64 %op9558, ptr %slot1631, align 8
  %v9559 = load i64, ptr %slot1629, align 8
  %p9560 = inttoptr i64 %v9559 to ptr
  %rgep9561 = getelementptr i8, ptr %p9560, i64 -16
  %ld9562 = load i64, ptr %rgep9561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9562, ptr %slot1632, align 8
  %v9563 = load i64, ptr %slot1632, align 8
  %op9564 = and i64 %v9563, 4611686018427387906
  store i64 %op9564, ptr %slot1633, align 8
  %v9565 = load i64, ptr %slot1633, align 8
  %cmp9566 = icmp ne i64 %v9565, 0
  %cv9567 = zext i1 %cmp9566 to i32
  store i32 %cv9567, ptr %slot1634, align 8
  %v9568 = load i32, ptr %slot1634, align 8
  %cv9569 = zext i32 %v9568 to i64
  %cond9570 = icmp ne i64 %cv9569, 0
  br i1 %cond9570, label %bb_rcgclear2419, label %bb_rcgcounted2419
bb_rcgcounted2419:
  %v9571 = load i64, ptr %slot1629, align 8
  %op9572 = sub i64 %v9571, 24
  store i64 %op9572, ptr %slot1635, align 8
  %v9573 = load i64, ptr %slot1629, align 8
  %p9574 = inttoptr i64 %v9573 to ptr
  %rgep9575 = getelementptr i8, ptr %p9574, i64 -24
  %ld9576 = load i64, ptr %rgep9575, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9576, ptr %slot1636, align 8
  %v9577 = load i64, ptr %slot1636, align 8
  %op9578 = sub i64 %v9577, 1
  store i64 %op9578, ptr %slot1637, align 8
  %v9579 = load i64, ptr %slot1637, align 8
  %cmp9580 = icmp eq i64 %v9579, 0
  %cv9581 = zext i1 %cmp9580 to i32
  store i32 %cv9581, ptr %slot1638, align 8
  %v9582 = load i32, ptr %slot1638, align 8
  %cv9583 = zext i32 %v9582 to i64
  %cond9584 = icmp ne i64 %cv9583, 0
  br i1 %cond9584, label %bb_rcglast2419, label %bb_rcgdec2419
bb_rcglast2419:
  %v9585 = load i64, ptr %slot1629, align 8
  %op9586 = sub i64 %v9585, 32
  store i64 %op9586, ptr %slot1639, align 8
  %v9587 = load i64, ptr %slot1629, align 8
  %p9588 = inttoptr i64 %v9587 to ptr
  %rgep9589 = getelementptr i8, ptr %p9588, i64 -32
  %ld9590 = load i64, ptr %rgep9589, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9590, ptr %slot1640, align 8
  %v9591 = load i64, ptr %slot1640, align 8
  %cmp9592 = icmp ne i64 %v9591, 0
  %cv9593 = zext i1 %cmp9592 to i32
  store i32 %cv9593, ptr %slot1641, align 8
  %v9594 = load i32, ptr %slot1641, align 8
  %cv9595 = zext i32 %v9594 to i64
  %cond9596 = icmp ne i64 %cv9595, 0
  br i1 %cond9596, label %bb_rcgdec2419, label %bb_rcgslow2419
bb_rcgslow2419:
  %v9597 = load i64, ptr %slot1628, align 8
  %v9598 = load i64, ptr %slot1625, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v9597, i64 %v9598) nomerge, !dbg !214
  br label %bb_rcgdone2419
bb_rcgdec2419:
  %v9599 = load i64, ptr %slot1637, align 8
  %v9600 = load i64, ptr %slot1629, align 8
  %p9601 = inttoptr i64 %v9600 to ptr
  %rgep9602 = getelementptr i8, ptr %p9601, i64 -24
  store i64 %v9599, ptr %rgep9602, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2419
bb_rcgclear2419:
  %v9603 = load i64, ptr %slot1625, align 8
  %p9604 = inttoptr i64 %v9603 to ptr
  store i64 0, ptr %p9604, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2419
bb_rcgdone2419:
  br label %bb_rcslotdone2403
bb_rcslotowner2403:
  %v9605 = load i64, ptr %slot96, align 8
  store i64 %v9605, ptr %slot1642, align 8
  %v9606 = load i64, ptr %slot1625, align 8
  %p9607 = inttoptr i64 %v9606 to ptr
  %ld9608 = load i64, ptr %p9607, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9608, ptr %slot1643, align 8
  %v9609 = load i64, ptr %slot1643, align 8
  %cmp9610 = icmp ne i64 %v9609, 0
  %cv9611 = zext i1 %cmp9610 to i32
  store i32 %cv9611, ptr %slot1644, align 8
  %v9612 = load i32, ptr %slot1644, align 8
  %cv9613 = zext i32 %v9612 to i64
  %cond9614 = icmp ne i64 %cv9613, 0
  br i1 %cond9614, label %bb_rcgnn2434, label %bb_rcgdone2434
bb_rcgnn2434:
  %v9615 = load i64, ptr %slot1643, align 8
  %op9616 = sub i64 %v9615, 16
  store i64 %op9616, ptr %slot1645, align 8
  %v9617 = load i64, ptr %slot1643, align 8
  %p9618 = inttoptr i64 %v9617 to ptr
  %rgep9619 = getelementptr i8, ptr %p9618, i64 -16
  %ld9620 = load i64, ptr %rgep9619, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9620, ptr %slot1646, align 8
  %v9621 = load i64, ptr %slot1646, align 8
  %op9622 = and i64 %v9621, 4611686018427387906
  store i64 %op9622, ptr %slot1647, align 8
  %v9623 = load i64, ptr %slot1647, align 8
  %cmp9624 = icmp ne i64 %v9623, 0
  %cv9625 = zext i1 %cmp9624 to i32
  store i32 %cv9625, ptr %slot1648, align 8
  %v9626 = load i32, ptr %slot1648, align 8
  %cv9627 = zext i32 %v9626 to i64
  %cond9628 = icmp ne i64 %cv9627, 0
  br i1 %cond9628, label %bb_rcgclear2434, label %bb_rcgcounted2434
bb_rcgcounted2434:
  %v9629 = load i64, ptr %slot1643, align 8
  %op9630 = sub i64 %v9629, 32
  store i64 %op9630, ptr %slot1649, align 8
  %v9631 = load i64, ptr %slot1643, align 8
  %p9632 = inttoptr i64 %v9631 to ptr
  %rgep9633 = getelementptr i8, ptr %p9632, i64 -32
  %ld9634 = load i64, ptr %rgep9633, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9634, ptr %slot1650, align 8
  %v9635 = load i64, ptr %slot1650, align 8
  %op9636 = sub i64 %v9635, 1
  store i64 %op9636, ptr %slot1651, align 8
  %v9637 = load i64, ptr %slot1651, align 8
  %cmp9638 = icmp eq i64 %v9637, 0
  %cv9639 = zext i1 %cmp9638 to i32
  store i32 %cv9639, ptr %slot1652, align 8
  %v9640 = load i32, ptr %slot1652, align 8
  %cv9641 = zext i32 %v9640 to i64
  %cond9642 = icmp ne i64 %cv9641, 0
  br i1 %cond9642, label %bb_rcglast2434, label %bb_rcgdec2434
bb_rcglast2434:
  %v9643 = load i64, ptr %slot1643, align 8
  %op9644 = sub i64 %v9643, 24
  store i64 %op9644, ptr %slot1653, align 8
  %v9645 = load i64, ptr %slot1643, align 8
  %p9646 = inttoptr i64 %v9645 to ptr
  %rgep9647 = getelementptr i8, ptr %p9646, i64 -24
  %ld9648 = load i64, ptr %rgep9647, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9648, ptr %slot1654, align 8
  %v9649 = load i64, ptr %slot1654, align 8
  %cmp9650 = icmp ne i64 %v9649, 0
  %cv9651 = zext i1 %cmp9650 to i32
  store i32 %cv9651, ptr %slot1655, align 8
  %v9652 = load i32, ptr %slot1655, align 8
  %cv9653 = zext i32 %v9652 to i64
  %cond9654 = icmp ne i64 %cv9653, 0
  br i1 %cond9654, label %bb_rcgdec2434, label %bb_rcgslow2434
bb_rcgslow2434:
  %v9655 = load i64, ptr %slot1642, align 8
  %v9656 = load i64, ptr %slot1625, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v9655, i64 %v9656) nomerge, !dbg !214
  br label %bb_rcgdone2434
bb_rcgdec2434:
  %v9657 = load i64, ptr %slot1651, align 8
  %v9658 = load i64, ptr %slot1643, align 8
  %p9659 = inttoptr i64 %v9658 to ptr
  %rgep9660 = getelementptr i8, ptr %p9659, i64 -32
  store i64 %v9657, ptr %rgep9660, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2434
bb_rcgclear2434:
  %v9661 = load i64, ptr %slot1625, align 8
  %p9662 = inttoptr i64 %v9661 to ptr
  store i64 0, ptr %p9662, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2434
bb_rcgdone2434:
  br label %bb_rcslotdone2403
bb_rcslotdone2403:
  %v9663 = load i64, ptr %slot48, align 8
  %p9664 = inttoptr i64 %v9663 to ptr
  %ld9665 = load i64, ptr %p9664, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9665, ptr %slot1656, align 8
  %v9666 = load i64, ptr %slot1656, align 8
  %v9667 = load i64, ptr %slot69, align 8
  %p9668 = inttoptr i64 %v9667 to ptr
  store i64 %v9666, ptr %p9668, align 8, !alias.scope !3, !noalias !4
  %v9669 = load i64, ptr %slot69, align 8
  %p9670 = inttoptr i64 %v9669 to ptr
  %ld9671 = load i64, ptr %p9670, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9671, ptr %slot1657, align 8
  %v9672 = load i64, ptr %slot96, align 8
  %p9673 = inttoptr i64 %v9672 to ptr
  %v9674 = load i64, ptr %slot1657, align 8
  %p9675 = inttoptr i64 %v9674 to ptr
  %call9676 = call ptr @myl_native_text_scalar(ptr %p9673, ptr %p9675, i32 0) nomerge, !dbg !216
  %calladdr9677 = ptrtoint ptr %call9676 to i64
  store i64 %calladdr9677, ptr %slot1658, align 8
  %v9678 = load i64, ptr %slot1658, align 8
  %cond9679 = icmp ne i64 %v9678, 0
  br i1 %cond9679, label %bb_success2441, label %bb_failed2441
bb_failed2441:
  %v9680 = load i64, ptr %slot1, align 8
  %p9681 = inttoptr i64 %v9680 to ptr
  call void @myl_qbe_fail_allocation(ptr %p9681) nomerge, !dbg !216
  unreachable
bb_success2441:
  %v9682 = load i64, ptr %slot1658, align 8
  %v9683 = load i64, ptr %slot69, align 8
  %p9684 = inttoptr i64 %v9683 to ptr
  store i64 %v9682, ptr %p9684, align 8, !alias.scope !3, !noalias !4
  %v9685 = load i64, ptr %slot69, align 8
  %p9686 = inttoptr i64 %v9685 to ptr
  %ld9687 = load i64, ptr %p9686, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9687, ptr %slot1659, align 8
  %v9688 = load i64, ptr %slot1659, align 8
  %v9689 = load i64, ptr %slot40, align 8
  %p9690 = inttoptr i64 %v9689 to ptr
  store i64 %v9688, ptr %p9690, align 8, !alias.scope !3, !noalias !4
  %v9691 = load i64, ptr %slot40, align 8
  store i64 %v9691, ptr %slot1660, align 8
  %v9692 = load i64, ptr %slot41, align 8
  store i64 %v9692, ptr %slot1661, align 8
  %v9693 = load i64, ptr %slot1660, align 8
  %v9694 = load i64, ptr %slot1661, align 8
  %p9695 = inttoptr i64 %v9693 to ptr
  %p9696 = inttoptr i64 %v9694 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9696, ptr %p9695, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9697 = load i64, ptr %slot35, align 8
  %p9698 = inttoptr i64 %v9697 to ptr
  store i32 2, ptr %p9698, align 4, !alias.scope !3, !noalias !4
  %v9699 = load i64, ptr %slot34, align 8
  %p9700 = inttoptr i64 %v9699 to ptr
  store i32 1, ptr %p9700, align 4, !alias.scope !3, !noalias !4
  %v9701 = load i64, ptr %slot37, align 8
  store i64 %v9701, ptr %slot1662, align 8
  %v9702 = load i64, ptr %slot41, align 8
  store i64 %v9702, ptr %slot1663, align 8
  %v9703 = load i64, ptr %slot1663, align 8
  %v9704 = load i64, ptr %slot1662, align 8
  %p9705 = inttoptr i64 %v9703 to ptr
  %p9706 = inttoptr i64 %v9704 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9706, ptr %p9705, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9707 = load i64, ptr %slot29, align 8
  %p9708 = inttoptr i64 %v9707 to ptr
  store i32 2, ptr %p9708, align 4, !alias.scope !3, !noalias !4
  %v9709 = load i64, ptr %slot35, align 8
  %p9710 = inttoptr i64 %v9709 to ptr
  %ld9711 = load i32, ptr %p9710, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9711, ptr %slot1664, align 8
  %v9712 = load i32, ptr %slot1664, align 8
  %v9713 = load i64, ptr %slot29, align 8
  %p9714 = inttoptr i64 %v9713 to ptr
  store i32 %v9712, ptr %p9714, align 4, !alias.scope !3, !noalias !4
  %v9715 = load i64, ptr %slot34, align 8
  %p9716 = inttoptr i64 %v9715 to ptr
  store i32 0, ptr %p9716, align 4, !alias.scope !3, !noalias !4
  %v9717 = load i64, ptr %slot28, align 8
  %p9718 = inttoptr i64 %v9717 to ptr
  store i32 1, ptr %p9718, align 4, !alias.scope !3, !noalias !4
  %v9719 = load i64, ptr %slot1662, align 8
  %p9720 = inttoptr i64 %v9719 to ptr
  %ld9721 = load i64, ptr %p9720, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9721, ptr %slot1665, align 8
  %v9722 = load i64, ptr %slot1665, align 8
  %v9723 = load i64, ptr %slot69, align 8
  %p9724 = inttoptr i64 %v9723 to ptr
  store i64 %v9722, ptr %p9724, align 8, !alias.scope !3, !noalias !4
  %v9725 = load i64, ptr %slot65, align 8
  store i64 %v9725, ptr %slot1666, align 8
  %v9726 = load i64, ptr %slot21, align 8
  %p9727 = inttoptr i64 %v9726 to ptr
  %ld9728 = load i32, ptr %p9727, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9728, ptr %slot1667, align 8
  %v9729 = load i32, ptr %slot1667, align 8
  %cmp9730 = icmp eq i32 %v9729, 16
  %cv9731 = zext i1 %cmp9730 to i32
  store i32 %cv9731, ptr %slot1668, align 8
  %v9732 = load i64, ptr %slot20, align 8
  %p9733 = inttoptr i64 %v9732 to ptr
  %ld9734 = load i32, ptr %p9733, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9734, ptr %slot1669, align 8
  %v9735 = load i32, ptr %slot1669, align 8
  %v9736 = load i32, ptr %slot1668, align 8
  %op9737 = and i32 %v9735, %v9736
  store i32 %op9737, ptr %slot1670, align 8
  %v9738 = load i32, ptr %slot1670, align 8
  %cv9739 = zext i32 %v9738 to i64
  %cond9740 = icmp ne i64 %cv9739, 0
  br i1 %cond9740, label %bb_rcownlocal2462, label %bb_rcownedlocal2462
bb_rcownlocal2462:
  %v9741 = load i64, ptr %slot65, align 8
  store i64 %v9741, ptr %slot1671, align 8
  %v9742 = load i64, ptr %slot41, align 8
  store i64 %v9742, ptr %slot1672, align 8
  %v9743 = load i64, ptr %slot97, align 8
  store i64 %v9743, ptr %slot1673, align 8
  %v9744 = load i64, ptr %slot1671, align 8
  %p9745 = inttoptr i64 %v9744 to ptr
  %ld9746 = load i64, ptr %p9745, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9746, ptr %slot1674, align 8
  %v9747 = load i64, ptr %slot1674, align 8
  %cmp9748 = icmp ne i64 %v9747, 0
  %cv9749 = zext i1 %cmp9748 to i32
  store i32 %cv9749, ptr %slot1675, align 8
  %v9750 = load i32, ptr %slot1675, align 8
  %cv9751 = zext i32 %v9750 to i64
  %cond9752 = icmp ne i64 %cv9751, 0
  br i1 %cond9752, label %bb_rcgnn2469, label %bb_rcgplain2469
bb_rcgnn2469:
  %v9753 = load i64, ptr %slot1674, align 8
  %op9754 = sub i64 %v9753, 16
  store i64 %op9754, ptr %slot1676, align 8
  %v9755 = load i64, ptr %slot1674, align 8
  %p9756 = inttoptr i64 %v9755 to ptr
  %rgep9757 = getelementptr i8, ptr %p9756, i64 -16
  %ld9758 = load i64, ptr %rgep9757, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9758, ptr %slot1677, align 8
  %v9759 = load i64, ptr %slot1677, align 8
  %op9760 = and i64 %v9759, 4611686018427387906
  store i64 %op9760, ptr %slot1678, align 8
  %v9761 = load i64, ptr %slot1678, align 8
  %cmp9762 = icmp ne i64 %v9761, 0
  %cv9763 = zext i1 %cmp9762 to i32
  store i32 %cv9763, ptr %slot1679, align 8
  %v9764 = load i32, ptr %slot1679, align 8
  %cv9765 = zext i32 %v9764 to i64
  %cond9766 = icmp ne i64 %cv9765, 0
  br i1 %cond9766, label %bb_rcgspecial2469, label %bb_rcginc2469
bb_rcginc2469:
  %v9767 = load i64, ptr %slot1674, align 8
  %op9768 = sub i64 %v9767, 32
  store i64 %op9768, ptr %slot1680, align 8
  %v9769 = load i64, ptr %slot1674, align 8
  %p9770 = inttoptr i64 %v9769 to ptr
  %rgep9771 = getelementptr i8, ptr %p9770, i64 -32
  %ld9772 = load i64, ptr %rgep9771, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9772, ptr %slot1681, align 8
  %v9773 = load i64, ptr %slot1681, align 8
  %op9774 = add i64 %v9773, 1
  store i64 %op9774, ptr %slot1682, align 8
  %v9775 = load i64, ptr %slot1682, align 8
  %cmp9776 = icmp eq i64 %v9775, 0
  %cv9777 = zext i1 %cmp9776 to i32
  store i32 %cv9777, ptr %slot1683, align 8
  %v9778 = load i32, ptr %slot1683, align 8
  %cv9779 = zext i32 %v9778 to i64
  %cond9780 = icmp ne i64 %cv9779, 0
  br i1 %cond9780, label %bb_rcglimit2469, label %bb_rcgcapacity2469
bb_rcglimit2469:
  %v9781 = load i64, ptr %slot1, align 8
  %p9782 = inttoptr i64 %v9781 to ptr
  %call9783 = call i32 @myl_qbe_rc_status(ptr %p9782, i32 2) nomerge, !dbg !218
  store i32 %call9783, ptr %slot1684, align 8
  br label %bb_failure
bb_rcgcapacity2469:
  %v9784 = load i64, ptr %slot1682, align 8
  %v9785 = load i64, ptr %slot1674, align 8
  %p9786 = inttoptr i64 %v9785 to ptr
  %rgep9787 = getelementptr i8, ptr %p9786, i64 -32
  store i64 %v9784, ptr %rgep9787, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2469
bb_rcgspecial2469:
  %v9788 = load i64, ptr %slot1677, align 8
  %op9789 = and i64 %v9788, 4611686018427387904
  store i64 %op9789, ptr %slot1685, align 8
  %v9790 = load i64, ptr %slot1685, align 8
  %cmp9791 = icmp ne i64 %v9790, 0
  %cv9792 = zext i1 %cmp9791 to i32
  store i32 %cv9792, ptr %slot1686, align 8
  %v9793 = load i32, ptr %slot1686, align 8
  %cv9794 = zext i32 %v9793 to i64
  %cond9795 = icmp ne i64 %cv9794, 0
  br i1 %cond9795, label %bb_rcgslow2469, label %bb_rcgplain2469
bb_rcgslow2469:
  %v9796 = load i64, ptr %slot96, align 8
  %v9797 = load i64, ptr %slot1672, align 8
  %v9798 = load i64, ptr %slot1671, align 8
  %v9799 = load i64, ptr %slot1673, align 8
  %cv9800 = trunc i64 %v9799 to i32
  %call9801 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v9796, i64 %v9797, i64 %v9798, i32 %cv9800) nomerge, !dbg !218
  store i32 %call9801, ptr %slot1687, align 8
  %v9802 = load i32, ptr %slot1687, align 8
  %cv9803 = zext i32 %v9802 to i64
  %cond9804 = icmp ne i64 %cv9803, 0
  br i1 %cond9804, label %bb_rcsuccess2483, label %bb_rcfailure2483
bb_rcfailure2483:
  %v9805 = load i64, ptr %slot96, align 8
  %p9806 = inttoptr i64 %v9805 to ptr
  %call9807 = call i32 @myl_rc_take_failure(ptr %p9806) nomerge, !dbg !218
  store i32 %call9807, ptr %slot1688, align 8
  %v9808 = load i64, ptr %slot1, align 8
  %p9809 = inttoptr i64 %v9808 to ptr
  %v9810 = load i32, ptr %slot1688, align 8
  %call9811 = call i32 @myl_qbe_rc_status(ptr %p9809, i32 %v9810) nomerge, !dbg !218
  store i32 %call9811, ptr %slot1689, align 8
  br label %bb_failure
bb_rcsuccess2483:
  br label %bb_rcgdone2469
bb_rcgplain2469:
  %v9812 = load i64, ptr %slot1674, align 8
  %v9813 = load i64, ptr %slot1672, align 8
  %p9814 = inttoptr i64 %v9813 to ptr
  store i64 %v9812, ptr %p9814, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2469
bb_rcgdone2469:
  %v9815 = load i64, ptr %slot35, align 8
  %p9816 = inttoptr i64 %v9815 to ptr
  store i32 2, ptr %p9816, align 4, !alias.scope !3, !noalias !4
  %v9817 = load i64, ptr %slot34, align 8
  %p9818 = inttoptr i64 %v9817 to ptr
  store i32 1, ptr %p9818, align 4, !alias.scope !3, !noalias !4
  %v9819 = load i64, ptr %slot20, align 8
  %p9820 = inttoptr i64 %v9819 to ptr
  %ld9821 = load i32, ptr %p9820, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9821, ptr %slot1690, align 8
  %v9822 = load i32, ptr %slot1690, align 8
  %cv9823 = zext i32 %v9822 to i64
  %cond9824 = icmp ne i64 %cv9823, 0
  br i1 %cond9824, label %bb_rcslotdrop2490, label %bb_rcslotdone2490
bb_rcslotdrop2490:
  %v9825 = load i64, ptr %slot20, align 8
  %p9826 = inttoptr i64 %v9825 to ptr
  store i32 0, ptr %p9826, align 4, !alias.scope !3, !noalias !4
  %v9827 = load i64, ptr %slot65, align 8
  store i64 %v9827, ptr %slot1691, align 8
  %v9828 = load i64, ptr %slot21, align 8
  %p9829 = inttoptr i64 %v9828 to ptr
  %ld9830 = load i32, ptr %p9829, align 4, !alias.scope !3, !noalias !4
  store i32 %ld9830, ptr %slot1692, align 8
  %v9831 = load i32, ptr %slot1692, align 8
  %op9832 = and i32 %v9831, 28
  store i32 %op9832, ptr %slot1693, align 8
  %v9833 = load i32, ptr %slot1693, align 8
  %cv9834 = zext i32 %v9833 to i64
  %cond9835 = icmp ne i64 %cv9834, 0
  br i1 %cond9835, label %bb_rcslotrole2490, label %bb_rcslotowner2490
bb_rcslotrole2490:
  %v9836 = load i64, ptr %slot96, align 8
  store i64 %v9836, ptr %slot1694, align 8
  %v9837 = load i64, ptr %slot1691, align 8
  %p9838 = inttoptr i64 %v9837 to ptr
  %ld9839 = load i64, ptr %p9838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9839, ptr %slot1695, align 8
  %v9840 = load i64, ptr %slot1695, align 8
  %cmp9841 = icmp ne i64 %v9840, 0
  %cv9842 = zext i1 %cmp9841 to i32
  store i32 %cv9842, ptr %slot1696, align 8
  %v9843 = load i32, ptr %slot1696, align 8
  %cv9844 = zext i32 %v9843 to i64
  %cond9845 = icmp ne i64 %cv9844, 0
  br i1 %cond9845, label %bb_rcgnn2506, label %bb_rcgdone2506
bb_rcgnn2506:
  %v9846 = load i64, ptr %slot1695, align 8
  %op9847 = sub i64 %v9846, 16
  store i64 %op9847, ptr %slot1697, align 8
  %v9848 = load i64, ptr %slot1695, align 8
  %p9849 = inttoptr i64 %v9848 to ptr
  %rgep9850 = getelementptr i8, ptr %p9849, i64 -16
  %ld9851 = load i64, ptr %rgep9850, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9851, ptr %slot1698, align 8
  %v9852 = load i64, ptr %slot1698, align 8
  %op9853 = and i64 %v9852, 4611686018427387906
  store i64 %op9853, ptr %slot1699, align 8
  %v9854 = load i64, ptr %slot1699, align 8
  %cmp9855 = icmp ne i64 %v9854, 0
  %cv9856 = zext i1 %cmp9855 to i32
  store i32 %cv9856, ptr %slot1700, align 8
  %v9857 = load i32, ptr %slot1700, align 8
  %cv9858 = zext i32 %v9857 to i64
  %cond9859 = icmp ne i64 %cv9858, 0
  br i1 %cond9859, label %bb_rcgclear2506, label %bb_rcgcounted2506
bb_rcgcounted2506:
  %v9860 = load i64, ptr %slot1695, align 8
  %op9861 = sub i64 %v9860, 24
  store i64 %op9861, ptr %slot1701, align 8
  %v9862 = load i64, ptr %slot1695, align 8
  %p9863 = inttoptr i64 %v9862 to ptr
  %rgep9864 = getelementptr i8, ptr %p9863, i64 -24
  %ld9865 = load i64, ptr %rgep9864, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9865, ptr %slot1702, align 8
  %v9866 = load i64, ptr %slot1702, align 8
  %op9867 = sub i64 %v9866, 1
  store i64 %op9867, ptr %slot1703, align 8
  %v9868 = load i64, ptr %slot1703, align 8
  %cmp9869 = icmp eq i64 %v9868, 0
  %cv9870 = zext i1 %cmp9869 to i32
  store i32 %cv9870, ptr %slot1704, align 8
  %v9871 = load i32, ptr %slot1704, align 8
  %cv9872 = zext i32 %v9871 to i64
  %cond9873 = icmp ne i64 %cv9872, 0
  br i1 %cond9873, label %bb_rcglast2506, label %bb_rcgdec2506
bb_rcglast2506:
  %v9874 = load i64, ptr %slot1695, align 8
  %op9875 = sub i64 %v9874, 32
  store i64 %op9875, ptr %slot1705, align 8
  %v9876 = load i64, ptr %slot1695, align 8
  %p9877 = inttoptr i64 %v9876 to ptr
  %rgep9878 = getelementptr i8, ptr %p9877, i64 -32
  %ld9879 = load i64, ptr %rgep9878, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9879, ptr %slot1706, align 8
  %v9880 = load i64, ptr %slot1706, align 8
  %cmp9881 = icmp ne i64 %v9880, 0
  %cv9882 = zext i1 %cmp9881 to i32
  store i32 %cv9882, ptr %slot1707, align 8
  %v9883 = load i32, ptr %slot1707, align 8
  %cv9884 = zext i32 %v9883 to i64
  %cond9885 = icmp ne i64 %cv9884, 0
  br i1 %cond9885, label %bb_rcgdec2506, label %bb_rcgslow2506
bb_rcgslow2506:
  %v9886 = load i64, ptr %slot1694, align 8
  %v9887 = load i64, ptr %slot1691, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v9886, i64 %v9887) nomerge, !dbg !218
  br label %bb_rcgdone2506
bb_rcgdec2506:
  %v9888 = load i64, ptr %slot1703, align 8
  %v9889 = load i64, ptr %slot1695, align 8
  %p9890 = inttoptr i64 %v9889 to ptr
  %rgep9891 = getelementptr i8, ptr %p9890, i64 -24
  store i64 %v9888, ptr %rgep9891, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2506
bb_rcgclear2506:
  %v9892 = load i64, ptr %slot1691, align 8
  %p9893 = inttoptr i64 %v9892 to ptr
  store i64 0, ptr %p9893, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2506
bb_rcgdone2506:
  br label %bb_rcslotdone2490
bb_rcslotowner2490:
  %v9894 = load i64, ptr %slot96, align 8
  store i64 %v9894, ptr %slot1708, align 8
  %v9895 = load i64, ptr %slot1691, align 8
  %p9896 = inttoptr i64 %v9895 to ptr
  %ld9897 = load i64, ptr %p9896, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9897, ptr %slot1709, align 8
  %v9898 = load i64, ptr %slot1709, align 8
  %cmp9899 = icmp ne i64 %v9898, 0
  %cv9900 = zext i1 %cmp9899 to i32
  store i32 %cv9900, ptr %slot1710, align 8
  %v9901 = load i32, ptr %slot1710, align 8
  %cv9902 = zext i32 %v9901 to i64
  %cond9903 = icmp ne i64 %cv9902, 0
  br i1 %cond9903, label %bb_rcgnn2521, label %bb_rcgdone2521
bb_rcgnn2521:
  %v9904 = load i64, ptr %slot1709, align 8
  %op9905 = sub i64 %v9904, 16
  store i64 %op9905, ptr %slot1711, align 8
  %v9906 = load i64, ptr %slot1709, align 8
  %p9907 = inttoptr i64 %v9906 to ptr
  %rgep9908 = getelementptr i8, ptr %p9907, i64 -16
  %ld9909 = load i64, ptr %rgep9908, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9909, ptr %slot1712, align 8
  %v9910 = load i64, ptr %slot1712, align 8
  %op9911 = and i64 %v9910, 4611686018427387906
  store i64 %op9911, ptr %slot1713, align 8
  %v9912 = load i64, ptr %slot1713, align 8
  %cmp9913 = icmp ne i64 %v9912, 0
  %cv9914 = zext i1 %cmp9913 to i32
  store i32 %cv9914, ptr %slot1714, align 8
  %v9915 = load i32, ptr %slot1714, align 8
  %cv9916 = zext i32 %v9915 to i64
  %cond9917 = icmp ne i64 %cv9916, 0
  br i1 %cond9917, label %bb_rcgclear2521, label %bb_rcgcounted2521
bb_rcgcounted2521:
  %v9918 = load i64, ptr %slot1709, align 8
  %op9919 = sub i64 %v9918, 32
  store i64 %op9919, ptr %slot1715, align 8
  %v9920 = load i64, ptr %slot1709, align 8
  %p9921 = inttoptr i64 %v9920 to ptr
  %rgep9922 = getelementptr i8, ptr %p9921, i64 -32
  %ld9923 = load i64, ptr %rgep9922, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9923, ptr %slot1716, align 8
  %v9924 = load i64, ptr %slot1716, align 8
  %op9925 = sub i64 %v9924, 1
  store i64 %op9925, ptr %slot1717, align 8
  %v9926 = load i64, ptr %slot1717, align 8
  %cmp9927 = icmp eq i64 %v9926, 0
  %cv9928 = zext i1 %cmp9927 to i32
  store i32 %cv9928, ptr %slot1718, align 8
  %v9929 = load i32, ptr %slot1718, align 8
  %cv9930 = zext i32 %v9929 to i64
  %cond9931 = icmp ne i64 %cv9930, 0
  br i1 %cond9931, label %bb_rcglast2521, label %bb_rcgdec2521
bb_rcglast2521:
  %v9932 = load i64, ptr %slot1709, align 8
  %op9933 = sub i64 %v9932, 24
  store i64 %op9933, ptr %slot1719, align 8
  %v9934 = load i64, ptr %slot1709, align 8
  %p9935 = inttoptr i64 %v9934 to ptr
  %rgep9936 = getelementptr i8, ptr %p9935, i64 -24
  %ld9937 = load i64, ptr %rgep9936, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9937, ptr %slot1720, align 8
  %v9938 = load i64, ptr %slot1720, align 8
  %cmp9939 = icmp ne i64 %v9938, 0
  %cv9940 = zext i1 %cmp9939 to i32
  store i32 %cv9940, ptr %slot1721, align 8
  %v9941 = load i32, ptr %slot1721, align 8
  %cv9942 = zext i32 %v9941 to i64
  %cond9943 = icmp ne i64 %cv9942, 0
  br i1 %cond9943, label %bb_rcgdec2521, label %bb_rcgslow2521
bb_rcgslow2521:
  %v9944 = load i64, ptr %slot1708, align 8
  %v9945 = load i64, ptr %slot1691, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v9944, i64 %v9945) nomerge, !dbg !218
  br label %bb_rcgdone2521
bb_rcgdec2521:
  %v9946 = load i64, ptr %slot1717, align 8
  %v9947 = load i64, ptr %slot1709, align 8
  %p9948 = inttoptr i64 %v9947 to ptr
  %rgep9949 = getelementptr i8, ptr %p9948, i64 -32
  store i64 %v9946, ptr %rgep9949, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2521
bb_rcgclear2521:
  %v9950 = load i64, ptr %slot1691, align 8
  %p9951 = inttoptr i64 %v9950 to ptr
  store i64 0, ptr %p9951, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2521
bb_rcgdone2521:
  br label %bb_rcslotdone2490
bb_rcslotdone2490:
  %v9952 = load i64, ptr %slot41, align 8
  store i64 %v9952, ptr %slot1722, align 8
  %v9953 = load i64, ptr %slot1722, align 8
  %v9954 = load i64, ptr %slot1671, align 8
  %p9955 = inttoptr i64 %v9953 to ptr
  %p9956 = inttoptr i64 %v9954 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p9956, ptr %p9955, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v9957 = load i64, ptr %slot21, align 8
  %p9958 = inttoptr i64 %v9957 to ptr
  store i32 2, ptr %p9958, align 4, !alias.scope !3, !noalias !4
  %v9959 = load i64, ptr %slot20, align 8
  %p9960 = inttoptr i64 %v9959 to ptr
  store i32 1, ptr %p9960, align 4, !alias.scope !3, !noalias !4
  %v9961 = load i64, ptr %slot34, align 8
  %p9962 = inttoptr i64 %v9961 to ptr
  store i32 0, ptr %p9962, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal2462
bb_rcownedlocal2462:
  %v9963 = load i64, ptr %slot21, align 8
  %p9964 = inttoptr i64 %v9963 to ptr
  store i32 2, ptr %p9964, align 4, !alias.scope !3, !noalias !4
  %v9965 = load i64, ptr %slot1666, align 8
  %p9966 = inttoptr i64 %v9965 to ptr
  %ld9967 = load i64, ptr %p9966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld9967, ptr %slot1723, align 8
  %v9968 = load i64, ptr %slot1723, align 8
  %cmp9969 = icmp ne i64 %v9968, 0
  %cv9970 = zext i1 %cmp9969 to i32
  store i32 %cv9970, ptr %slot1724, align 8
  %v9971 = load i32, ptr %slot1724, align 8
  %cv9972 = zext i32 %v9971 to i64
  %cond9973 = icmp ne i64 %cv9972, 0
  br i1 %cond9973, label %bb_rcguniquenn2530, label %bb_rcgunique2530
bb_rcguniquenn2530:
  %v9974 = load i64, ptr %slot1723, align 8
  %op9975 = sub i64 %v9974, 16
  store i64 %op9975, ptr %slot1725, align 8
  %v9976 = load i64, ptr %slot1723, align 8
  %p9977 = inttoptr i64 %v9976 to ptr
  %rgep9978 = getelementptr i8, ptr %p9977, i64 -16
  %ld9979 = load i64, ptr %rgep9978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9979, ptr %slot1726, align 8
  %v9980 = load i64, ptr %slot1726, align 8
  %op9981 = and i64 %v9980, 6917529027641081858
  store i64 %op9981, ptr %slot1727, align 8
  %v9982 = load i64, ptr %slot1727, align 8
  %cmp9983 = icmp ne i64 %v9982, 0
  %cv9984 = zext i1 %cmp9983 to i32
  store i32 %cv9984, ptr %slot1728, align 8
  %v9985 = load i32, ptr %slot1728, align 8
  %cv9986 = zext i32 %v9985 to i64
  %cond9987 = icmp ne i64 %cv9986, 0
  br i1 %cond9987, label %bb_rcguniqueslow2530, label %bb_rcguniquecount2530
bb_rcguniquecount2530:
  %v9988 = load i64, ptr %slot1723, align 8
  %op9989 = sub i64 %v9988, 32
  store i64 %op9989, ptr %slot1729, align 8
  %v9990 = load i64, ptr %slot1723, align 8
  %p9991 = inttoptr i64 %v9990 to ptr
  %rgep9992 = getelementptr i8, ptr %p9991, i64 -32
  %ld9993 = load i64, ptr %rgep9992, align 8, !alias.scope !9, !noalias !10
  store i64 %ld9993, ptr %slot1730, align 8
  %v9994 = load i64, ptr %slot1730, align 8
  %cmp9995 = icmp ult i64 %v9994, 2
  %cv9996 = zext i1 %cmp9995 to i32
  store i32 %cv9996, ptr %slot1731, align 8
  %v9997 = load i32, ptr %slot1731, align 8
  %cv9998 = zext i32 %v9997 to i64
  %cond9999 = icmp ne i64 %cv9998, 0
  br i1 %cond9999, label %bb_rcgunique2530, label %bb_rcguniqueslow2530
bb_rcguniqueslow2530:
  %v10000 = load i64, ptr %slot1, align 8
  %p10001 = inttoptr i64 %v10000 to ptr
  %p10002 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v10003 = load i64, ptr %slot1666, align 8
  %p10004 = inttoptr i64 %v10003 to ptr
  %v10005 = load i64, ptr %slot20, align 8
  %p10006 = inttoptr i64 %v10005 to ptr
  %call10007 = call i32 @myl_qbe_rc_unique_local(ptr %p10001, ptr %p10002, ptr %p10004, ptr %p10006) nomerge, !dbg !218
  store i32 %call10007, ptr %slot1732, align 8
  %v10008 = load i32, ptr %slot1732, align 8
  %cv10009 = zext i32 %v10008 to i64
  %cond10010 = icmp ne i64 %cv10009, 0
  br i1 %cond10010, label %bb_rcunique2541, label %bb_failure
bb_rcunique2541:
  br label %bb_rcgunique2530
bb_rcgunique2530:
  %v10011 = load i64, ptr %slot65, align 8
  %p10012 = inttoptr i64 %v10011 to ptr
  %ld10013 = load i64, ptr %p10012, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10013, ptr %slot1733, align 8
  %v10014 = load i64, ptr %slot69, align 8
  store i64 %v10014, ptr %slot1734, align 8
  %v10015 = load i64, ptr %slot1734, align 8
  %p10016 = inttoptr i64 %v10015 to ptr
  %ld10017 = load i64, ptr %p10016, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10017, ptr %slot1735, align 8
  %v10018 = load i64, ptr %slot1735, align 8
  %v10019 = load i64, ptr %slot42, align 8
  %p10020 = inttoptr i64 %v10019 to ptr
  store i64 %v10018, ptr %p10020, align 8, !alias.scope !3, !noalias !4
  %v10021 = load i64, ptr %slot42, align 8
  store i64 %v10021, ptr %slot1736, align 8
  %v10022 = load i64, ptr %slot96, align 8
  %v10023 = load i64, ptr %slot1733, align 8
  %v10024 = load i64, ptr %slot1736, align 8
  %call10025 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v10022, i64 %v10023, i64 %v10024) nomerge, !dbg !218
  store i32 %call10025, ptr %slot1737, align 8
  %v10026 = load i32, ptr %slot1737, align 8
  %cv10027 = zext i32 %v10026 to i64
  %cond10028 = icmp ne i64 %cv10027, 0
  br i1 %cond10028, label %bb_success2547, label %bb_failed2547
bb_failed2547:
  %v10029 = load i64, ptr %slot1, align 8
  %p10030 = inttoptr i64 %v10029 to ptr
  call void @myl_qbe_fail_allocation(ptr %p10030) nomerge, !dbg !218
  unreachable
bb_success2547:
  %v10031 = load i64, ptr %slot69, align 8
  %p10032 = inttoptr i64 %v10031 to ptr
  store i64 0, ptr %p10032, align 8, !alias.scope !3, !noalias !4
  %v10033 = load i64, ptr %slot28, align 8
  %p10034 = inttoptr i64 %v10033 to ptr
  %ld10035 = load i32, ptr %p10034, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10035, ptr %slot1738, align 8
  %v10036 = load i32, ptr %slot1738, align 8
  %cv10037 = zext i32 %v10036 to i64
  %cond10038 = icmp ne i64 %cv10037, 0
  br i1 %cond10038, label %bb_rcslotdrop2550, label %bb_rcslotdone2550
bb_rcslotdrop2550:
  %v10039 = load i64, ptr %slot28, align 8
  %p10040 = inttoptr i64 %v10039 to ptr
  store i32 0, ptr %p10040, align 4, !alias.scope !3, !noalias !4
  %v10041 = load i64, ptr %slot37, align 8
  store i64 %v10041, ptr %slot1739, align 8
  %v10042 = load i64, ptr %slot29, align 8
  %p10043 = inttoptr i64 %v10042 to ptr
  %ld10044 = load i32, ptr %p10043, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10044, ptr %slot1740, align 8
  %v10045 = load i32, ptr %slot1740, align 8
  %op10046 = and i32 %v10045, 28
  store i32 %op10046, ptr %slot1741, align 8
  %v10047 = load i32, ptr %slot1741, align 8
  %cv10048 = zext i32 %v10047 to i64
  %cond10049 = icmp ne i64 %cv10048, 0
  br i1 %cond10049, label %bb_rcslotrole2550, label %bb_rcslotowner2550
bb_rcslotrole2550:
  %v10050 = load i64, ptr %slot96, align 8
  store i64 %v10050, ptr %slot1742, align 8
  %v10051 = load i64, ptr %slot1739, align 8
  %p10052 = inttoptr i64 %v10051 to ptr
  %ld10053 = load i64, ptr %p10052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10053, ptr %slot1743, align 8
  %v10054 = load i64, ptr %slot1743, align 8
  %cmp10055 = icmp ne i64 %v10054, 0
  %cv10056 = zext i1 %cmp10055 to i32
  store i32 %cv10056, ptr %slot1744, align 8
  %v10057 = load i32, ptr %slot1744, align 8
  %cv10058 = zext i32 %v10057 to i64
  %cond10059 = icmp ne i64 %cv10058, 0
  br i1 %cond10059, label %bb_rcgnn2566, label %bb_rcgdone2566
bb_rcgnn2566:
  %v10060 = load i64, ptr %slot1743, align 8
  %op10061 = sub i64 %v10060, 16
  store i64 %op10061, ptr %slot1745, align 8
  %v10062 = load i64, ptr %slot1743, align 8
  %p10063 = inttoptr i64 %v10062 to ptr
  %rgep10064 = getelementptr i8, ptr %p10063, i64 -16
  %ld10065 = load i64, ptr %rgep10064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10065, ptr %slot1746, align 8
  %v10066 = load i64, ptr %slot1746, align 8
  %op10067 = and i64 %v10066, 4611686018427387906
  store i64 %op10067, ptr %slot1747, align 8
  %v10068 = load i64, ptr %slot1747, align 8
  %cmp10069 = icmp ne i64 %v10068, 0
  %cv10070 = zext i1 %cmp10069 to i32
  store i32 %cv10070, ptr %slot1748, align 8
  %v10071 = load i32, ptr %slot1748, align 8
  %cv10072 = zext i32 %v10071 to i64
  %cond10073 = icmp ne i64 %cv10072, 0
  br i1 %cond10073, label %bb_rcgclear2566, label %bb_rcgcounted2566
bb_rcgcounted2566:
  %v10074 = load i64, ptr %slot1743, align 8
  %op10075 = sub i64 %v10074, 24
  store i64 %op10075, ptr %slot1749, align 8
  %v10076 = load i64, ptr %slot1743, align 8
  %p10077 = inttoptr i64 %v10076 to ptr
  %rgep10078 = getelementptr i8, ptr %p10077, i64 -24
  %ld10079 = load i64, ptr %rgep10078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10079, ptr %slot1750, align 8
  %v10080 = load i64, ptr %slot1750, align 8
  %op10081 = sub i64 %v10080, 1
  store i64 %op10081, ptr %slot1751, align 8
  %v10082 = load i64, ptr %slot1751, align 8
  %cmp10083 = icmp eq i64 %v10082, 0
  %cv10084 = zext i1 %cmp10083 to i32
  store i32 %cv10084, ptr %slot1752, align 8
  %v10085 = load i32, ptr %slot1752, align 8
  %cv10086 = zext i32 %v10085 to i64
  %cond10087 = icmp ne i64 %cv10086, 0
  br i1 %cond10087, label %bb_rcglast2566, label %bb_rcgdec2566
bb_rcglast2566:
  %v10088 = load i64, ptr %slot1743, align 8
  %op10089 = sub i64 %v10088, 32
  store i64 %op10089, ptr %slot1753, align 8
  %v10090 = load i64, ptr %slot1743, align 8
  %p10091 = inttoptr i64 %v10090 to ptr
  %rgep10092 = getelementptr i8, ptr %p10091, i64 -32
  %ld10093 = load i64, ptr %rgep10092, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10093, ptr %slot1754, align 8
  %v10094 = load i64, ptr %slot1754, align 8
  %cmp10095 = icmp ne i64 %v10094, 0
  %cv10096 = zext i1 %cmp10095 to i32
  store i32 %cv10096, ptr %slot1755, align 8
  %v10097 = load i32, ptr %slot1755, align 8
  %cv10098 = zext i32 %v10097 to i64
  %cond10099 = icmp ne i64 %cv10098, 0
  br i1 %cond10099, label %bb_rcgdec2566, label %bb_rcgslow2566
bb_rcgslow2566:
  %v10100 = load i64, ptr %slot1742, align 8
  %v10101 = load i64, ptr %slot1739, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v10100, i64 %v10101) nomerge, !dbg !218
  br label %bb_rcgdone2566
bb_rcgdec2566:
  %v10102 = load i64, ptr %slot1751, align 8
  %v10103 = load i64, ptr %slot1743, align 8
  %p10104 = inttoptr i64 %v10103 to ptr
  %rgep10105 = getelementptr i8, ptr %p10104, i64 -24
  store i64 %v10102, ptr %rgep10105, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2566
bb_rcgclear2566:
  %v10106 = load i64, ptr %slot1739, align 8
  %p10107 = inttoptr i64 %v10106 to ptr
  store i64 0, ptr %p10107, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2566
bb_rcgdone2566:
  br label %bb_rcslotdone2550
bb_rcslotowner2550:
  %v10108 = load i64, ptr %slot96, align 8
  store i64 %v10108, ptr %slot1756, align 8
  %v10109 = load i64, ptr %slot1739, align 8
  %p10110 = inttoptr i64 %v10109 to ptr
  %ld10111 = load i64, ptr %p10110, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10111, ptr %slot1757, align 8
  %v10112 = load i64, ptr %slot1757, align 8
  %cmp10113 = icmp ne i64 %v10112, 0
  %cv10114 = zext i1 %cmp10113 to i32
  store i32 %cv10114, ptr %slot1758, align 8
  %v10115 = load i32, ptr %slot1758, align 8
  %cv10116 = zext i32 %v10115 to i64
  %cond10117 = icmp ne i64 %cv10116, 0
  br i1 %cond10117, label %bb_rcgnn2581, label %bb_rcgdone2581
bb_rcgnn2581:
  %v10118 = load i64, ptr %slot1757, align 8
  %op10119 = sub i64 %v10118, 16
  store i64 %op10119, ptr %slot1759, align 8
  %v10120 = load i64, ptr %slot1757, align 8
  %p10121 = inttoptr i64 %v10120 to ptr
  %rgep10122 = getelementptr i8, ptr %p10121, i64 -16
  %ld10123 = load i64, ptr %rgep10122, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10123, ptr %slot1760, align 8
  %v10124 = load i64, ptr %slot1760, align 8
  %op10125 = and i64 %v10124, 4611686018427387906
  store i64 %op10125, ptr %slot1761, align 8
  %v10126 = load i64, ptr %slot1761, align 8
  %cmp10127 = icmp ne i64 %v10126, 0
  %cv10128 = zext i1 %cmp10127 to i32
  store i32 %cv10128, ptr %slot1762, align 8
  %v10129 = load i32, ptr %slot1762, align 8
  %cv10130 = zext i32 %v10129 to i64
  %cond10131 = icmp ne i64 %cv10130, 0
  br i1 %cond10131, label %bb_rcgclear2581, label %bb_rcgcounted2581
bb_rcgcounted2581:
  %v10132 = load i64, ptr %slot1757, align 8
  %op10133 = sub i64 %v10132, 32
  store i64 %op10133, ptr %slot1763, align 8
  %v10134 = load i64, ptr %slot1757, align 8
  %p10135 = inttoptr i64 %v10134 to ptr
  %rgep10136 = getelementptr i8, ptr %p10135, i64 -32
  %ld10137 = load i64, ptr %rgep10136, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10137, ptr %slot1764, align 8
  %v10138 = load i64, ptr %slot1764, align 8
  %op10139 = sub i64 %v10138, 1
  store i64 %op10139, ptr %slot1765, align 8
  %v10140 = load i64, ptr %slot1765, align 8
  %cmp10141 = icmp eq i64 %v10140, 0
  %cv10142 = zext i1 %cmp10141 to i32
  store i32 %cv10142, ptr %slot1766, align 8
  %v10143 = load i32, ptr %slot1766, align 8
  %cv10144 = zext i32 %v10143 to i64
  %cond10145 = icmp ne i64 %cv10144, 0
  br i1 %cond10145, label %bb_rcglast2581, label %bb_rcgdec2581
bb_rcglast2581:
  %v10146 = load i64, ptr %slot1757, align 8
  %op10147 = sub i64 %v10146, 24
  store i64 %op10147, ptr %slot1767, align 8
  %v10148 = load i64, ptr %slot1757, align 8
  %p10149 = inttoptr i64 %v10148 to ptr
  %rgep10150 = getelementptr i8, ptr %p10149, i64 -24
  %ld10151 = load i64, ptr %rgep10150, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10151, ptr %slot1768, align 8
  %v10152 = load i64, ptr %slot1768, align 8
  %cmp10153 = icmp ne i64 %v10152, 0
  %cv10154 = zext i1 %cmp10153 to i32
  store i32 %cv10154, ptr %slot1769, align 8
  %v10155 = load i32, ptr %slot1769, align 8
  %cv10156 = zext i32 %v10155 to i64
  %cond10157 = icmp ne i64 %cv10156, 0
  br i1 %cond10157, label %bb_rcgdec2581, label %bb_rcgslow2581
bb_rcgslow2581:
  %v10158 = load i64, ptr %slot1756, align 8
  %v10159 = load i64, ptr %slot1739, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v10158, i64 %v10159) nomerge, !dbg !218
  br label %bb_rcgdone2581
bb_rcgdec2581:
  %v10160 = load i64, ptr %slot1765, align 8
  %v10161 = load i64, ptr %slot1757, align 8
  %p10162 = inttoptr i64 %v10161 to ptr
  %rgep10163 = getelementptr i8, ptr %p10162, i64 -32
  store i64 %v10160, ptr %rgep10163, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2581
bb_rcgclear2581:
  %v10164 = load i64, ptr %slot1739, align 8
  %p10165 = inttoptr i64 %v10164 to ptr
  store i64 0, ptr %p10165, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2581
bb_rcgdone2581:
  br label %bb_rcslotdone2550
bb_rcslotdone2550:
  %p10166 = inttoptr i64 ptrtoint (ptr @myl_lit_8d330aa2f416754a391eaf7715dfedb3b3b4f6f34dd9cc9ef16b81d95dfd3df3 to i64) to ptr
  %ld10167 = load i64, ptr %p10166, align 8, !alias.scope !4, !noalias !3
  store i64 %ld10167, ptr %slot1770, align 8
  %v10168 = load i64, ptr %slot1770, align 8
  %v10169 = load i64, ptr %slot69, align 8
  %p10170 = inttoptr i64 %v10169 to ptr
  store i64 %v10168, ptr %p10170, align 8, !alias.scope !3, !noalias !4
  %v10171 = load i64, ptr %slot69, align 8
  %p10172 = inttoptr i64 %v10171 to ptr
  %ld10173 = load i64, ptr %p10172, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10173, ptr %slot1771, align 8
  %v10174 = load i64, ptr %slot1771, align 8
  %v10175 = load i64, ptr %slot40, align 8
  %p10176 = inttoptr i64 %v10175 to ptr
  store i64 %v10174, ptr %p10176, align 8, !alias.scope !3, !noalias !4
  %v10177 = load i64, ptr %slot40, align 8
  store i64 %v10177, ptr %slot1772, align 8
  %v10178 = load i64, ptr %slot41, align 8
  store i64 %v10178, ptr %slot1773, align 8
  %v10179 = load i64, ptr %slot1772, align 8
  %v10180 = load i64, ptr %slot1773, align 8
  %p10181 = inttoptr i64 %v10179 to ptr
  %p10182 = inttoptr i64 %v10180 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10182, ptr %p10181, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10183 = load i64, ptr %slot35, align 8
  %p10184 = inttoptr i64 %v10183 to ptr
  store i32 2, ptr %p10184, align 4, !alias.scope !3, !noalias !4
  %v10185 = load i64, ptr %slot34, align 8
  %p10186 = inttoptr i64 %v10185 to ptr
  store i32 1, ptr %p10186, align 4, !alias.scope !3, !noalias !4
  %v10187 = load i64, ptr %slot37, align 8
  store i64 %v10187, ptr %slot1774, align 8
  %v10188 = load i64, ptr %slot41, align 8
  store i64 %v10188, ptr %slot1775, align 8
  %v10189 = load i64, ptr %slot1775, align 8
  %v10190 = load i64, ptr %slot1774, align 8
  %p10191 = inttoptr i64 %v10189 to ptr
  %p10192 = inttoptr i64 %v10190 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10192, ptr %p10191, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10193 = load i64, ptr %slot29, align 8
  %p10194 = inttoptr i64 %v10193 to ptr
  store i32 2, ptr %p10194, align 4, !alias.scope !3, !noalias !4
  %v10195 = load i64, ptr %slot35, align 8
  %p10196 = inttoptr i64 %v10195 to ptr
  %ld10197 = load i32, ptr %p10196, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10197, ptr %slot1776, align 8
  %v10198 = load i32, ptr %slot1776, align 8
  %v10199 = load i64, ptr %slot29, align 8
  %p10200 = inttoptr i64 %v10199 to ptr
  store i32 %v10198, ptr %p10200, align 4, !alias.scope !3, !noalias !4
  %v10201 = load i64, ptr %slot34, align 8
  %p10202 = inttoptr i64 %v10201 to ptr
  store i32 0, ptr %p10202, align 4, !alias.scope !3, !noalias !4
  %v10203 = load i64, ptr %slot28, align 8
  %p10204 = inttoptr i64 %v10203 to ptr
  store i32 1, ptr %p10204, align 4, !alias.scope !3, !noalias !4
  %v10205 = load i64, ptr %slot1774, align 8
  %p10206 = inttoptr i64 %v10205 to ptr
  %ld10207 = load i64, ptr %p10206, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10207, ptr %slot1777, align 8
  %v10208 = load i64, ptr %slot1777, align 8
  %v10209 = load i64, ptr %slot69, align 8
  %p10210 = inttoptr i64 %v10209 to ptr
  store i64 %v10208, ptr %p10210, align 8, !alias.scope !3, !noalias !4
  %v10211 = load i64, ptr %slot65, align 8
  store i64 %v10211, ptr %slot1778, align 8
  %v10212 = load i64, ptr %slot21, align 8
  %p10213 = inttoptr i64 %v10212 to ptr
  %ld10214 = load i32, ptr %p10213, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10214, ptr %slot1779, align 8
  %v10215 = load i32, ptr %slot1779, align 8
  %cmp10216 = icmp eq i32 %v10215, 16
  %cv10217 = zext i1 %cmp10216 to i32
  store i32 %cv10217, ptr %slot1780, align 8
  %v10218 = load i64, ptr %slot20, align 8
  %p10219 = inttoptr i64 %v10218 to ptr
  %ld10220 = load i32, ptr %p10219, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10220, ptr %slot1781, align 8
  %v10221 = load i32, ptr %slot1781, align 8
  %v10222 = load i32, ptr %slot1780, align 8
  %op10223 = and i32 %v10221, %v10222
  store i32 %op10223, ptr %slot1782, align 8
  %v10224 = load i32, ptr %slot1782, align 8
  %cv10225 = zext i32 %v10224 to i64
  %cond10226 = icmp ne i64 %cv10225, 0
  br i1 %cond10226, label %bb_rcownlocal2607, label %bb_rcownedlocal2607
bb_rcownlocal2607:
  %v10227 = load i64, ptr %slot65, align 8
  store i64 %v10227, ptr %slot1783, align 8
  %v10228 = load i64, ptr %slot41, align 8
  store i64 %v10228, ptr %slot1784, align 8
  %v10229 = load i64, ptr %slot97, align 8
  store i64 %v10229, ptr %slot1785, align 8
  %v10230 = load i64, ptr %slot1783, align 8
  %p10231 = inttoptr i64 %v10230 to ptr
  %ld10232 = load i64, ptr %p10231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10232, ptr %slot1786, align 8
  %v10233 = load i64, ptr %slot1786, align 8
  %cmp10234 = icmp ne i64 %v10233, 0
  %cv10235 = zext i1 %cmp10234 to i32
  store i32 %cv10235, ptr %slot1787, align 8
  %v10236 = load i32, ptr %slot1787, align 8
  %cv10237 = zext i32 %v10236 to i64
  %cond10238 = icmp ne i64 %cv10237, 0
  br i1 %cond10238, label %bb_rcgnn2614, label %bb_rcgplain2614
bb_rcgnn2614:
  %v10239 = load i64, ptr %slot1786, align 8
  %op10240 = sub i64 %v10239, 16
  store i64 %op10240, ptr %slot1788, align 8
  %v10241 = load i64, ptr %slot1786, align 8
  %p10242 = inttoptr i64 %v10241 to ptr
  %rgep10243 = getelementptr i8, ptr %p10242, i64 -16
  %ld10244 = load i64, ptr %rgep10243, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10244, ptr %slot1789, align 8
  %v10245 = load i64, ptr %slot1789, align 8
  %op10246 = and i64 %v10245, 4611686018427387906
  store i64 %op10246, ptr %slot1790, align 8
  %v10247 = load i64, ptr %slot1790, align 8
  %cmp10248 = icmp ne i64 %v10247, 0
  %cv10249 = zext i1 %cmp10248 to i32
  store i32 %cv10249, ptr %slot1791, align 8
  %v10250 = load i32, ptr %slot1791, align 8
  %cv10251 = zext i32 %v10250 to i64
  %cond10252 = icmp ne i64 %cv10251, 0
  br i1 %cond10252, label %bb_rcgspecial2614, label %bb_rcginc2614
bb_rcginc2614:
  %v10253 = load i64, ptr %slot1786, align 8
  %op10254 = sub i64 %v10253, 32
  store i64 %op10254, ptr %slot1792, align 8
  %v10255 = load i64, ptr %slot1786, align 8
  %p10256 = inttoptr i64 %v10255 to ptr
  %rgep10257 = getelementptr i8, ptr %p10256, i64 -32
  %ld10258 = load i64, ptr %rgep10257, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10258, ptr %slot1793, align 8
  %v10259 = load i64, ptr %slot1793, align 8
  %op10260 = add i64 %v10259, 1
  store i64 %op10260, ptr %slot1794, align 8
  %v10261 = load i64, ptr %slot1794, align 8
  %cmp10262 = icmp eq i64 %v10261, 0
  %cv10263 = zext i1 %cmp10262 to i32
  store i32 %cv10263, ptr %slot1795, align 8
  %v10264 = load i32, ptr %slot1795, align 8
  %cv10265 = zext i32 %v10264 to i64
  %cond10266 = icmp ne i64 %cv10265, 0
  br i1 %cond10266, label %bb_rcglimit2614, label %bb_rcgcapacity2614
bb_rcglimit2614:
  %v10267 = load i64, ptr %slot1, align 8
  %p10268 = inttoptr i64 %v10267 to ptr
  %call10269 = call i32 @myl_qbe_rc_status(ptr %p10268, i32 2) nomerge, !dbg !220
  store i32 %call10269, ptr %slot1796, align 8
  br label %bb_failure
bb_rcgcapacity2614:
  %v10270 = load i64, ptr %slot1794, align 8
  %v10271 = load i64, ptr %slot1786, align 8
  %p10272 = inttoptr i64 %v10271 to ptr
  %rgep10273 = getelementptr i8, ptr %p10272, i64 -32
  store i64 %v10270, ptr %rgep10273, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain2614
bb_rcgspecial2614:
  %v10274 = load i64, ptr %slot1789, align 8
  %op10275 = and i64 %v10274, 4611686018427387904
  store i64 %op10275, ptr %slot1797, align 8
  %v10276 = load i64, ptr %slot1797, align 8
  %cmp10277 = icmp ne i64 %v10276, 0
  %cv10278 = zext i1 %cmp10277 to i32
  store i32 %cv10278, ptr %slot1798, align 8
  %v10279 = load i32, ptr %slot1798, align 8
  %cv10280 = zext i32 %v10279 to i64
  %cond10281 = icmp ne i64 %cv10280, 0
  br i1 %cond10281, label %bb_rcgslow2614, label %bb_rcgplain2614
bb_rcgslow2614:
  %v10282 = load i64, ptr %slot96, align 8
  %v10283 = load i64, ptr %slot1784, align 8
  %v10284 = load i64, ptr %slot1783, align 8
  %v10285 = load i64, ptr %slot1785, align 8
  %cv10286 = trunc i64 %v10285 to i32
  %call10287 = call i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64 %v10282, i64 %v10283, i64 %v10284, i32 %cv10286) nomerge, !dbg !220
  store i32 %call10287, ptr %slot1799, align 8
  %v10288 = load i32, ptr %slot1799, align 8
  %cv10289 = zext i32 %v10288 to i64
  %cond10290 = icmp ne i64 %cv10289, 0
  br i1 %cond10290, label %bb_rcsuccess2628, label %bb_rcfailure2628
bb_rcfailure2628:
  %v10291 = load i64, ptr %slot96, align 8
  %p10292 = inttoptr i64 %v10291 to ptr
  %call10293 = call i32 @myl_rc_take_failure(ptr %p10292) nomerge, !dbg !220
  store i32 %call10293, ptr %slot1800, align 8
  %v10294 = load i64, ptr %slot1, align 8
  %p10295 = inttoptr i64 %v10294 to ptr
  %v10296 = load i32, ptr %slot1800, align 8
  %call10297 = call i32 @myl_qbe_rc_status(ptr %p10295, i32 %v10296) nomerge, !dbg !220
  store i32 %call10297, ptr %slot1801, align 8
  br label %bb_failure
bb_rcsuccess2628:
  br label %bb_rcgdone2614
bb_rcgplain2614:
  %v10298 = load i64, ptr %slot1786, align 8
  %v10299 = load i64, ptr %slot1784, align 8
  %p10300 = inttoptr i64 %v10299 to ptr
  store i64 %v10298, ptr %p10300, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2614
bb_rcgdone2614:
  %v10301 = load i64, ptr %slot35, align 8
  %p10302 = inttoptr i64 %v10301 to ptr
  store i32 2, ptr %p10302, align 4, !alias.scope !3, !noalias !4
  %v10303 = load i64, ptr %slot34, align 8
  %p10304 = inttoptr i64 %v10303 to ptr
  store i32 1, ptr %p10304, align 4, !alias.scope !3, !noalias !4
  %v10305 = load i64, ptr %slot20, align 8
  %p10306 = inttoptr i64 %v10305 to ptr
  %ld10307 = load i32, ptr %p10306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10307, ptr %slot1802, align 8
  %v10308 = load i32, ptr %slot1802, align 8
  %cv10309 = zext i32 %v10308 to i64
  %cond10310 = icmp ne i64 %cv10309, 0
  br i1 %cond10310, label %bb_rcslotdrop2635, label %bb_rcslotdone2635
bb_rcslotdrop2635:
  %v10311 = load i64, ptr %slot20, align 8
  %p10312 = inttoptr i64 %v10311 to ptr
  store i32 0, ptr %p10312, align 4, !alias.scope !3, !noalias !4
  %v10313 = load i64, ptr %slot65, align 8
  store i64 %v10313, ptr %slot1803, align 8
  %v10314 = load i64, ptr %slot21, align 8
  %p10315 = inttoptr i64 %v10314 to ptr
  %ld10316 = load i32, ptr %p10315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10316, ptr %slot1804, align 8
  %v10317 = load i32, ptr %slot1804, align 8
  %op10318 = and i32 %v10317, 28
  store i32 %op10318, ptr %slot1805, align 8
  %v10319 = load i32, ptr %slot1805, align 8
  %cv10320 = zext i32 %v10319 to i64
  %cond10321 = icmp ne i64 %cv10320, 0
  br i1 %cond10321, label %bb_rcslotrole2635, label %bb_rcslotowner2635
bb_rcslotrole2635:
  %v10322 = load i64, ptr %slot96, align 8
  store i64 %v10322, ptr %slot1806, align 8
  %v10323 = load i64, ptr %slot1803, align 8
  %p10324 = inttoptr i64 %v10323 to ptr
  %ld10325 = load i64, ptr %p10324, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10325, ptr %slot1807, align 8
  %v10326 = load i64, ptr %slot1807, align 8
  %cmp10327 = icmp ne i64 %v10326, 0
  %cv10328 = zext i1 %cmp10327 to i32
  store i32 %cv10328, ptr %slot1808, align 8
  %v10329 = load i32, ptr %slot1808, align 8
  %cv10330 = zext i32 %v10329 to i64
  %cond10331 = icmp ne i64 %cv10330, 0
  br i1 %cond10331, label %bb_rcgnn2651, label %bb_rcgdone2651
bb_rcgnn2651:
  %v10332 = load i64, ptr %slot1807, align 8
  %op10333 = sub i64 %v10332, 16
  store i64 %op10333, ptr %slot1809, align 8
  %v10334 = load i64, ptr %slot1807, align 8
  %p10335 = inttoptr i64 %v10334 to ptr
  %rgep10336 = getelementptr i8, ptr %p10335, i64 -16
  %ld10337 = load i64, ptr %rgep10336, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10337, ptr %slot1810, align 8
  %v10338 = load i64, ptr %slot1810, align 8
  %op10339 = and i64 %v10338, 4611686018427387906
  store i64 %op10339, ptr %slot1811, align 8
  %v10340 = load i64, ptr %slot1811, align 8
  %cmp10341 = icmp ne i64 %v10340, 0
  %cv10342 = zext i1 %cmp10341 to i32
  store i32 %cv10342, ptr %slot1812, align 8
  %v10343 = load i32, ptr %slot1812, align 8
  %cv10344 = zext i32 %v10343 to i64
  %cond10345 = icmp ne i64 %cv10344, 0
  br i1 %cond10345, label %bb_rcgclear2651, label %bb_rcgcounted2651
bb_rcgcounted2651:
  %v10346 = load i64, ptr %slot1807, align 8
  %op10347 = sub i64 %v10346, 24
  store i64 %op10347, ptr %slot1813, align 8
  %v10348 = load i64, ptr %slot1807, align 8
  %p10349 = inttoptr i64 %v10348 to ptr
  %rgep10350 = getelementptr i8, ptr %p10349, i64 -24
  %ld10351 = load i64, ptr %rgep10350, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10351, ptr %slot1814, align 8
  %v10352 = load i64, ptr %slot1814, align 8
  %op10353 = sub i64 %v10352, 1
  store i64 %op10353, ptr %slot1815, align 8
  %v10354 = load i64, ptr %slot1815, align 8
  %cmp10355 = icmp eq i64 %v10354, 0
  %cv10356 = zext i1 %cmp10355 to i32
  store i32 %cv10356, ptr %slot1816, align 8
  %v10357 = load i32, ptr %slot1816, align 8
  %cv10358 = zext i32 %v10357 to i64
  %cond10359 = icmp ne i64 %cv10358, 0
  br i1 %cond10359, label %bb_rcglast2651, label %bb_rcgdec2651
bb_rcglast2651:
  %v10360 = load i64, ptr %slot1807, align 8
  %op10361 = sub i64 %v10360, 32
  store i64 %op10361, ptr %slot1817, align 8
  %v10362 = load i64, ptr %slot1807, align 8
  %p10363 = inttoptr i64 %v10362 to ptr
  %rgep10364 = getelementptr i8, ptr %p10363, i64 -32
  %ld10365 = load i64, ptr %rgep10364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10365, ptr %slot1818, align 8
  %v10366 = load i64, ptr %slot1818, align 8
  %cmp10367 = icmp ne i64 %v10366, 0
  %cv10368 = zext i1 %cmp10367 to i32
  store i32 %cv10368, ptr %slot1819, align 8
  %v10369 = load i32, ptr %slot1819, align 8
  %cv10370 = zext i32 %v10369 to i64
  %cond10371 = icmp ne i64 %cv10370, 0
  br i1 %cond10371, label %bb_rcgdec2651, label %bb_rcgslow2651
bb_rcgslow2651:
  %v10372 = load i64, ptr %slot1806, align 8
  %v10373 = load i64, ptr %slot1803, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v10372, i64 %v10373) nomerge, !dbg !220
  br label %bb_rcgdone2651
bb_rcgdec2651:
  %v10374 = load i64, ptr %slot1815, align 8
  %v10375 = load i64, ptr %slot1807, align 8
  %p10376 = inttoptr i64 %v10375 to ptr
  %rgep10377 = getelementptr i8, ptr %p10376, i64 -24
  store i64 %v10374, ptr %rgep10377, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2651
bb_rcgclear2651:
  %v10378 = load i64, ptr %slot1803, align 8
  %p10379 = inttoptr i64 %v10378 to ptr
  store i64 0, ptr %p10379, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2651
bb_rcgdone2651:
  br label %bb_rcslotdone2635
bb_rcslotowner2635:
  %v10380 = load i64, ptr %slot96, align 8
  store i64 %v10380, ptr %slot1820, align 8
  %v10381 = load i64, ptr %slot1803, align 8
  %p10382 = inttoptr i64 %v10381 to ptr
  %ld10383 = load i64, ptr %p10382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10383, ptr %slot1821, align 8
  %v10384 = load i64, ptr %slot1821, align 8
  %cmp10385 = icmp ne i64 %v10384, 0
  %cv10386 = zext i1 %cmp10385 to i32
  store i32 %cv10386, ptr %slot1822, align 8
  %v10387 = load i32, ptr %slot1822, align 8
  %cv10388 = zext i32 %v10387 to i64
  %cond10389 = icmp ne i64 %cv10388, 0
  br i1 %cond10389, label %bb_rcgnn2666, label %bb_rcgdone2666
bb_rcgnn2666:
  %v10390 = load i64, ptr %slot1821, align 8
  %op10391 = sub i64 %v10390, 16
  store i64 %op10391, ptr %slot1823, align 8
  %v10392 = load i64, ptr %slot1821, align 8
  %p10393 = inttoptr i64 %v10392 to ptr
  %rgep10394 = getelementptr i8, ptr %p10393, i64 -16
  %ld10395 = load i64, ptr %rgep10394, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10395, ptr %slot1824, align 8
  %v10396 = load i64, ptr %slot1824, align 8
  %op10397 = and i64 %v10396, 4611686018427387906
  store i64 %op10397, ptr %slot1825, align 8
  %v10398 = load i64, ptr %slot1825, align 8
  %cmp10399 = icmp ne i64 %v10398, 0
  %cv10400 = zext i1 %cmp10399 to i32
  store i32 %cv10400, ptr %slot1826, align 8
  %v10401 = load i32, ptr %slot1826, align 8
  %cv10402 = zext i32 %v10401 to i64
  %cond10403 = icmp ne i64 %cv10402, 0
  br i1 %cond10403, label %bb_rcgclear2666, label %bb_rcgcounted2666
bb_rcgcounted2666:
  %v10404 = load i64, ptr %slot1821, align 8
  %op10405 = sub i64 %v10404, 32
  store i64 %op10405, ptr %slot1827, align 8
  %v10406 = load i64, ptr %slot1821, align 8
  %p10407 = inttoptr i64 %v10406 to ptr
  %rgep10408 = getelementptr i8, ptr %p10407, i64 -32
  %ld10409 = load i64, ptr %rgep10408, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10409, ptr %slot1828, align 8
  %v10410 = load i64, ptr %slot1828, align 8
  %op10411 = sub i64 %v10410, 1
  store i64 %op10411, ptr %slot1829, align 8
  %v10412 = load i64, ptr %slot1829, align 8
  %cmp10413 = icmp eq i64 %v10412, 0
  %cv10414 = zext i1 %cmp10413 to i32
  store i32 %cv10414, ptr %slot1830, align 8
  %v10415 = load i32, ptr %slot1830, align 8
  %cv10416 = zext i32 %v10415 to i64
  %cond10417 = icmp ne i64 %cv10416, 0
  br i1 %cond10417, label %bb_rcglast2666, label %bb_rcgdec2666
bb_rcglast2666:
  %v10418 = load i64, ptr %slot1821, align 8
  %op10419 = sub i64 %v10418, 24
  store i64 %op10419, ptr %slot1831, align 8
  %v10420 = load i64, ptr %slot1821, align 8
  %p10421 = inttoptr i64 %v10420 to ptr
  %rgep10422 = getelementptr i8, ptr %p10421, i64 -24
  %ld10423 = load i64, ptr %rgep10422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10423, ptr %slot1832, align 8
  %v10424 = load i64, ptr %slot1832, align 8
  %cmp10425 = icmp ne i64 %v10424, 0
  %cv10426 = zext i1 %cmp10425 to i32
  store i32 %cv10426, ptr %slot1833, align 8
  %v10427 = load i32, ptr %slot1833, align 8
  %cv10428 = zext i32 %v10427 to i64
  %cond10429 = icmp ne i64 %cv10428, 0
  br i1 %cond10429, label %bb_rcgdec2666, label %bb_rcgslow2666
bb_rcgslow2666:
  %v10430 = load i64, ptr %slot1820, align 8
  %v10431 = load i64, ptr %slot1803, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v10430, i64 %v10431) nomerge, !dbg !220
  br label %bb_rcgdone2666
bb_rcgdec2666:
  %v10432 = load i64, ptr %slot1829, align 8
  %v10433 = load i64, ptr %slot1821, align 8
  %p10434 = inttoptr i64 %v10433 to ptr
  %rgep10435 = getelementptr i8, ptr %p10434, i64 -32
  store i64 %v10432, ptr %rgep10435, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2666
bb_rcgclear2666:
  %v10436 = load i64, ptr %slot1803, align 8
  %p10437 = inttoptr i64 %v10436 to ptr
  store i64 0, ptr %p10437, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2666
bb_rcgdone2666:
  br label %bb_rcslotdone2635
bb_rcslotdone2635:
  %v10438 = load i64, ptr %slot41, align 8
  store i64 %v10438, ptr %slot1834, align 8
  %v10439 = load i64, ptr %slot1834, align 8
  %v10440 = load i64, ptr %slot1783, align 8
  %p10441 = inttoptr i64 %v10439 to ptr
  %p10442 = inttoptr i64 %v10440 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10442, ptr %p10441, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10443 = load i64, ptr %slot21, align 8
  %p10444 = inttoptr i64 %v10443 to ptr
  store i32 2, ptr %p10444, align 4, !alias.scope !3, !noalias !4
  %v10445 = load i64, ptr %slot20, align 8
  %p10446 = inttoptr i64 %v10445 to ptr
  store i32 1, ptr %p10446, align 4, !alias.scope !3, !noalias !4
  %v10447 = load i64, ptr %slot34, align 8
  %p10448 = inttoptr i64 %v10447 to ptr
  store i32 0, ptr %p10448, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcownedlocal2607
bb_rcownedlocal2607:
  %v10449 = load i64, ptr %slot21, align 8
  %p10450 = inttoptr i64 %v10449 to ptr
  store i32 2, ptr %p10450, align 4, !alias.scope !3, !noalias !4
  %v10451 = load i64, ptr %slot1778, align 8
  %p10452 = inttoptr i64 %v10451 to ptr
  %ld10453 = load i64, ptr %p10452, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10453, ptr %slot1835, align 8
  %v10454 = load i64, ptr %slot1835, align 8
  %cmp10455 = icmp ne i64 %v10454, 0
  %cv10456 = zext i1 %cmp10455 to i32
  store i32 %cv10456, ptr %slot1836, align 8
  %v10457 = load i32, ptr %slot1836, align 8
  %cv10458 = zext i32 %v10457 to i64
  %cond10459 = icmp ne i64 %cv10458, 0
  br i1 %cond10459, label %bb_rcguniquenn2675, label %bb_rcgunique2675
bb_rcguniquenn2675:
  %v10460 = load i64, ptr %slot1835, align 8
  %op10461 = sub i64 %v10460, 16
  store i64 %op10461, ptr %slot1837, align 8
  %v10462 = load i64, ptr %slot1835, align 8
  %p10463 = inttoptr i64 %v10462 to ptr
  %rgep10464 = getelementptr i8, ptr %p10463, i64 -16
  %ld10465 = load i64, ptr %rgep10464, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10465, ptr %slot1838, align 8
  %v10466 = load i64, ptr %slot1838, align 8
  %op10467 = and i64 %v10466, 6917529027641081858
  store i64 %op10467, ptr %slot1839, align 8
  %v10468 = load i64, ptr %slot1839, align 8
  %cmp10469 = icmp ne i64 %v10468, 0
  %cv10470 = zext i1 %cmp10469 to i32
  store i32 %cv10470, ptr %slot1840, align 8
  %v10471 = load i32, ptr %slot1840, align 8
  %cv10472 = zext i32 %v10471 to i64
  %cond10473 = icmp ne i64 %cv10472, 0
  br i1 %cond10473, label %bb_rcguniqueslow2675, label %bb_rcguniquecount2675
bb_rcguniquecount2675:
  %v10474 = load i64, ptr %slot1835, align 8
  %op10475 = sub i64 %v10474, 32
  store i64 %op10475, ptr %slot1841, align 8
  %v10476 = load i64, ptr %slot1835, align 8
  %p10477 = inttoptr i64 %v10476 to ptr
  %rgep10478 = getelementptr i8, ptr %p10477, i64 -32
  %ld10479 = load i64, ptr %rgep10478, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10479, ptr %slot1842, align 8
  %v10480 = load i64, ptr %slot1842, align 8
  %cmp10481 = icmp ult i64 %v10480, 2
  %cv10482 = zext i1 %cmp10481 to i32
  store i32 %cv10482, ptr %slot1843, align 8
  %v10483 = load i32, ptr %slot1843, align 8
  %cv10484 = zext i32 %v10483 to i64
  %cond10485 = icmp ne i64 %cv10484, 0
  br i1 %cond10485, label %bb_rcgunique2675, label %bb_rcguniqueslow2675
bb_rcguniqueslow2675:
  %v10486 = load i64, ptr %slot1, align 8
  %p10487 = inttoptr i64 %v10486 to ptr
  %p10488 = inttoptr i64 ptrtoint (ptr @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b to i64) to ptr
  %v10489 = load i64, ptr %slot1778, align 8
  %p10490 = inttoptr i64 %v10489 to ptr
  %v10491 = load i64, ptr %slot20, align 8
  %p10492 = inttoptr i64 %v10491 to ptr
  %call10493 = call i32 @myl_qbe_rc_unique_local(ptr %p10487, ptr %p10488, ptr %p10490, ptr %p10492) nomerge, !dbg !220
  store i32 %call10493, ptr %slot1844, align 8
  %v10494 = load i32, ptr %slot1844, align 8
  %cv10495 = zext i32 %v10494 to i64
  %cond10496 = icmp ne i64 %cv10495, 0
  br i1 %cond10496, label %bb_rcunique2686, label %bb_failure
bb_rcunique2686:
  br label %bb_rcgunique2675
bb_rcgunique2675:
  %v10497 = load i64, ptr %slot65, align 8
  %p10498 = inttoptr i64 %v10497 to ptr
  %ld10499 = load i64, ptr %p10498, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10499, ptr %slot1845, align 8
  %v10500 = load i64, ptr %slot69, align 8
  store i64 %v10500, ptr %slot1846, align 8
  %v10501 = load i64, ptr %slot1846, align 8
  %p10502 = inttoptr i64 %v10501 to ptr
  %ld10503 = load i64, ptr %p10502, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10503, ptr %slot1847, align 8
  %v10504 = load i64, ptr %slot1847, align 8
  %v10505 = load i64, ptr %slot42, align 8
  %p10506 = inttoptr i64 %v10505 to ptr
  store i64 %v10504, ptr %p10506, align 8, !alias.scope !3, !noalias !4
  %v10507 = load i64, ptr %slot42, align 8
  store i64 %v10507, ptr %slot1848, align 8
  %v10508 = load i64, ptr %slot96, align 8
  %v10509 = load i64, ptr %slot1845, align 8
  %v10510 = load i64, ptr %slot1848, align 8
  %call10511 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64 %v10508, i64 %v10509, i64 %v10510) nomerge, !dbg !220
  store i32 %call10511, ptr %slot1849, align 8
  %v10512 = load i32, ptr %slot1849, align 8
  %cv10513 = zext i32 %v10512 to i64
  %cond10514 = icmp ne i64 %cv10513, 0
  br i1 %cond10514, label %bb_success2692, label %bb_failed2692
bb_failed2692:
  %v10515 = load i64, ptr %slot1, align 8
  %p10516 = inttoptr i64 %v10515 to ptr
  call void @myl_qbe_fail_allocation(ptr %p10516) nomerge, !dbg !220
  unreachable
bb_success2692:
  %v10517 = load i64, ptr %slot69, align 8
  %p10518 = inttoptr i64 %v10517 to ptr
  store i64 0, ptr %p10518, align 8, !alias.scope !3, !noalias !4
  %v10519 = load i64, ptr %slot28, align 8
  %p10520 = inttoptr i64 %v10519 to ptr
  %ld10521 = load i32, ptr %p10520, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10521, ptr %slot1850, align 8
  %v10522 = load i32, ptr %slot1850, align 8
  %cv10523 = zext i32 %v10522 to i64
  %cond10524 = icmp ne i64 %cv10523, 0
  br i1 %cond10524, label %bb_rcslotdrop2695, label %bb_rcslotdone2695
bb_rcslotdrop2695:
  %v10525 = load i64, ptr %slot28, align 8
  %p10526 = inttoptr i64 %v10525 to ptr
  store i32 0, ptr %p10526, align 4, !alias.scope !3, !noalias !4
  %v10527 = load i64, ptr %slot37, align 8
  store i64 %v10527, ptr %slot1851, align 8
  %v10528 = load i64, ptr %slot29, align 8
  %p10529 = inttoptr i64 %v10528 to ptr
  %ld10530 = load i32, ptr %p10529, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10530, ptr %slot1852, align 8
  %v10531 = load i32, ptr %slot1852, align 8
  %op10532 = and i32 %v10531, 28
  store i32 %op10532, ptr %slot1853, align 8
  %v10533 = load i32, ptr %slot1853, align 8
  %cv10534 = zext i32 %v10533 to i64
  %cond10535 = icmp ne i64 %cv10534, 0
  br i1 %cond10535, label %bb_rcslotrole2695, label %bb_rcslotowner2695
bb_rcslotrole2695:
  %v10536 = load i64, ptr %slot96, align 8
  store i64 %v10536, ptr %slot1854, align 8
  %v10537 = load i64, ptr %slot1851, align 8
  %p10538 = inttoptr i64 %v10537 to ptr
  %ld10539 = load i64, ptr %p10538, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10539, ptr %slot1855, align 8
  %v10540 = load i64, ptr %slot1855, align 8
  %cmp10541 = icmp ne i64 %v10540, 0
  %cv10542 = zext i1 %cmp10541 to i32
  store i32 %cv10542, ptr %slot1856, align 8
  %v10543 = load i32, ptr %slot1856, align 8
  %cv10544 = zext i32 %v10543 to i64
  %cond10545 = icmp ne i64 %cv10544, 0
  br i1 %cond10545, label %bb_rcgnn2711, label %bb_rcgdone2711
bb_rcgnn2711:
  %v10546 = load i64, ptr %slot1855, align 8
  %op10547 = sub i64 %v10546, 16
  store i64 %op10547, ptr %slot1857, align 8
  %v10548 = load i64, ptr %slot1855, align 8
  %p10549 = inttoptr i64 %v10548 to ptr
  %rgep10550 = getelementptr i8, ptr %p10549, i64 -16
  %ld10551 = load i64, ptr %rgep10550, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10551, ptr %slot1858, align 8
  %v10552 = load i64, ptr %slot1858, align 8
  %op10553 = and i64 %v10552, 4611686018427387906
  store i64 %op10553, ptr %slot1859, align 8
  %v10554 = load i64, ptr %slot1859, align 8
  %cmp10555 = icmp ne i64 %v10554, 0
  %cv10556 = zext i1 %cmp10555 to i32
  store i32 %cv10556, ptr %slot1860, align 8
  %v10557 = load i32, ptr %slot1860, align 8
  %cv10558 = zext i32 %v10557 to i64
  %cond10559 = icmp ne i64 %cv10558, 0
  br i1 %cond10559, label %bb_rcgclear2711, label %bb_rcgcounted2711
bb_rcgcounted2711:
  %v10560 = load i64, ptr %slot1855, align 8
  %op10561 = sub i64 %v10560, 24
  store i64 %op10561, ptr %slot1861, align 8
  %v10562 = load i64, ptr %slot1855, align 8
  %p10563 = inttoptr i64 %v10562 to ptr
  %rgep10564 = getelementptr i8, ptr %p10563, i64 -24
  %ld10565 = load i64, ptr %rgep10564, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10565, ptr %slot1862, align 8
  %v10566 = load i64, ptr %slot1862, align 8
  %op10567 = sub i64 %v10566, 1
  store i64 %op10567, ptr %slot1863, align 8
  %v10568 = load i64, ptr %slot1863, align 8
  %cmp10569 = icmp eq i64 %v10568, 0
  %cv10570 = zext i1 %cmp10569 to i32
  store i32 %cv10570, ptr %slot1864, align 8
  %v10571 = load i32, ptr %slot1864, align 8
  %cv10572 = zext i32 %v10571 to i64
  %cond10573 = icmp ne i64 %cv10572, 0
  br i1 %cond10573, label %bb_rcglast2711, label %bb_rcgdec2711
bb_rcglast2711:
  %v10574 = load i64, ptr %slot1855, align 8
  %op10575 = sub i64 %v10574, 32
  store i64 %op10575, ptr %slot1865, align 8
  %v10576 = load i64, ptr %slot1855, align 8
  %p10577 = inttoptr i64 %v10576 to ptr
  %rgep10578 = getelementptr i8, ptr %p10577, i64 -32
  %ld10579 = load i64, ptr %rgep10578, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10579, ptr %slot1866, align 8
  %v10580 = load i64, ptr %slot1866, align 8
  %cmp10581 = icmp ne i64 %v10580, 0
  %cv10582 = zext i1 %cmp10581 to i32
  store i32 %cv10582, ptr %slot1867, align 8
  %v10583 = load i32, ptr %slot1867, align 8
  %cv10584 = zext i32 %v10583 to i64
  %cond10585 = icmp ne i64 %cv10584, 0
  br i1 %cond10585, label %bb_rcgdec2711, label %bb_rcgslow2711
bb_rcgslow2711:
  %v10586 = load i64, ptr %slot1854, align 8
  %v10587 = load i64, ptr %slot1851, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v10586, i64 %v10587) nomerge, !dbg !220
  br label %bb_rcgdone2711
bb_rcgdec2711:
  %v10588 = load i64, ptr %slot1863, align 8
  %v10589 = load i64, ptr %slot1855, align 8
  %p10590 = inttoptr i64 %v10589 to ptr
  %rgep10591 = getelementptr i8, ptr %p10590, i64 -24
  store i64 %v10588, ptr %rgep10591, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2711
bb_rcgclear2711:
  %v10592 = load i64, ptr %slot1851, align 8
  %p10593 = inttoptr i64 %v10592 to ptr
  store i64 0, ptr %p10593, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2711
bb_rcgdone2711:
  br label %bb_rcslotdone2695
bb_rcslotowner2695:
  %v10594 = load i64, ptr %slot96, align 8
  store i64 %v10594, ptr %slot1868, align 8
  %v10595 = load i64, ptr %slot1851, align 8
  %p10596 = inttoptr i64 %v10595 to ptr
  %ld10597 = load i64, ptr %p10596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10597, ptr %slot1869, align 8
  %v10598 = load i64, ptr %slot1869, align 8
  %cmp10599 = icmp ne i64 %v10598, 0
  %cv10600 = zext i1 %cmp10599 to i32
  store i32 %cv10600, ptr %slot1870, align 8
  %v10601 = load i32, ptr %slot1870, align 8
  %cv10602 = zext i32 %v10601 to i64
  %cond10603 = icmp ne i64 %cv10602, 0
  br i1 %cond10603, label %bb_rcgnn2726, label %bb_rcgdone2726
bb_rcgnn2726:
  %v10604 = load i64, ptr %slot1869, align 8
  %op10605 = sub i64 %v10604, 16
  store i64 %op10605, ptr %slot1871, align 8
  %v10606 = load i64, ptr %slot1869, align 8
  %p10607 = inttoptr i64 %v10606 to ptr
  %rgep10608 = getelementptr i8, ptr %p10607, i64 -16
  %ld10609 = load i64, ptr %rgep10608, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10609, ptr %slot1872, align 8
  %v10610 = load i64, ptr %slot1872, align 8
  %op10611 = and i64 %v10610, 4611686018427387906
  store i64 %op10611, ptr %slot1873, align 8
  %v10612 = load i64, ptr %slot1873, align 8
  %cmp10613 = icmp ne i64 %v10612, 0
  %cv10614 = zext i1 %cmp10613 to i32
  store i32 %cv10614, ptr %slot1874, align 8
  %v10615 = load i32, ptr %slot1874, align 8
  %cv10616 = zext i32 %v10615 to i64
  %cond10617 = icmp ne i64 %cv10616, 0
  br i1 %cond10617, label %bb_rcgclear2726, label %bb_rcgcounted2726
bb_rcgcounted2726:
  %v10618 = load i64, ptr %slot1869, align 8
  %op10619 = sub i64 %v10618, 32
  store i64 %op10619, ptr %slot1875, align 8
  %v10620 = load i64, ptr %slot1869, align 8
  %p10621 = inttoptr i64 %v10620 to ptr
  %rgep10622 = getelementptr i8, ptr %p10621, i64 -32
  %ld10623 = load i64, ptr %rgep10622, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10623, ptr %slot1876, align 8
  %v10624 = load i64, ptr %slot1876, align 8
  %op10625 = sub i64 %v10624, 1
  store i64 %op10625, ptr %slot1877, align 8
  %v10626 = load i64, ptr %slot1877, align 8
  %cmp10627 = icmp eq i64 %v10626, 0
  %cv10628 = zext i1 %cmp10627 to i32
  store i32 %cv10628, ptr %slot1878, align 8
  %v10629 = load i32, ptr %slot1878, align 8
  %cv10630 = zext i32 %v10629 to i64
  %cond10631 = icmp ne i64 %cv10630, 0
  br i1 %cond10631, label %bb_rcglast2726, label %bb_rcgdec2726
bb_rcglast2726:
  %v10632 = load i64, ptr %slot1869, align 8
  %op10633 = sub i64 %v10632, 24
  store i64 %op10633, ptr %slot1879, align 8
  %v10634 = load i64, ptr %slot1869, align 8
  %p10635 = inttoptr i64 %v10634 to ptr
  %rgep10636 = getelementptr i8, ptr %p10635, i64 -24
  %ld10637 = load i64, ptr %rgep10636, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10637, ptr %slot1880, align 8
  %v10638 = load i64, ptr %slot1880, align 8
  %cmp10639 = icmp ne i64 %v10638, 0
  %cv10640 = zext i1 %cmp10639 to i32
  store i32 %cv10640, ptr %slot1881, align 8
  %v10641 = load i32, ptr %slot1881, align 8
  %cv10642 = zext i32 %v10641 to i64
  %cond10643 = icmp ne i64 %cv10642, 0
  br i1 %cond10643, label %bb_rcgdec2726, label %bb_rcgslow2726
bb_rcgslow2726:
  %v10644 = load i64, ptr %slot1868, align 8
  %v10645 = load i64, ptr %slot1851, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v10644, i64 %v10645) nomerge, !dbg !220
  br label %bb_rcgdone2726
bb_rcgdec2726:
  %v10646 = load i64, ptr %slot1877, align 8
  %v10647 = load i64, ptr %slot1869, align 8
  %p10648 = inttoptr i64 %v10647 to ptr
  %rgep10649 = getelementptr i8, ptr %p10648, i64 -32
  store i64 %v10646, ptr %rgep10649, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2726
bb_rcgclear2726:
  %v10650 = load i64, ptr %slot1851, align 8
  %p10651 = inttoptr i64 %v10650 to ptr
  store i64 0, ptr %p10651, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2726
bb_rcgdone2726:
  br label %bb_rcslotdone2695
bb_rcslotdone2695:
  %v10652 = load i64, ptr %slot65, align 8
  %p10653 = inttoptr i64 %v10652 to ptr
  %ld10654 = load i64, ptr %p10653, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10654, ptr %slot1882, align 8
  %v10655 = load i64, ptr %slot1882, align 8
  %v10656 = load i64, ptr %slot69, align 8
  %p10657 = inttoptr i64 %v10656 to ptr
  store i64 %v10655, ptr %p10657, align 8, !alias.scope !3, !noalias !4
  %v10658 = load i64, ptr %slot66, align 8
  %p10659 = inttoptr i64 %v10658 to ptr
  %ld10660 = load i64, ptr %p10659, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10660, ptr %slot1883, align 8
  %v10661 = load i64, ptr %slot69, align 8
  %p10662 = inttoptr i64 %v10661 to ptr
  %ld10663 = load i64, ptr %p10662, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10663, ptr %slot1884, align 8
  %v10664 = load i64, ptr %slot96, align 8
  %p10665 = inttoptr i64 %v10664 to ptr
  %v10666 = load i64, ptr %slot1883, align 8
  %p10667 = inttoptr i64 %v10666 to ptr
  %v10668 = load i64, ptr %slot1884, align 8
  %p10669 = inttoptr i64 %v10668 to ptr
  %call10670 = call ptr @myl_native_text_join(ptr %p10665, ptr %p10667, ptr %p10669) nomerge, !dbg !222
  %calladdr10671 = ptrtoint ptr %call10670 to i64
  store i64 %calladdr10671, ptr %slot1885, align 8
  %v10672 = load i64, ptr %slot1885, align 8
  %cond10673 = icmp ne i64 %v10672, 0
  br i1 %cond10673, label %bb_success2734, label %bb_failed2734
bb_failed2734:
  %v10674 = load i64, ptr %slot1, align 8
  %p10675 = inttoptr i64 %v10674 to ptr
  call void @myl_qbe_fail_allocation(ptr %p10675) nomerge, !dbg !222
  unreachable
bb_success2734:
  %v10676 = load i64, ptr %slot1885, align 8
  %v10677 = load i64, ptr %slot69, align 8
  %p10678 = inttoptr i64 %v10677 to ptr
  store i64 %v10676, ptr %p10678, align 8, !alias.scope !3, !noalias !4
  %v10679 = load i64, ptr %slot69, align 8
  %p10680 = inttoptr i64 %v10679 to ptr
  %ld10681 = load i64, ptr %p10680, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10681, ptr %slot1886, align 8
  %v10682 = load i64, ptr %slot1886, align 8
  %v10683 = load i64, ptr %slot40, align 8
  %p10684 = inttoptr i64 %v10683 to ptr
  store i64 %v10682, ptr %p10684, align 8, !alias.scope !3, !noalias !4
  %v10685 = load i64, ptr %slot40, align 8
  store i64 %v10685, ptr %slot1887, align 8
  %v10686 = load i64, ptr %slot41, align 8
  store i64 %v10686, ptr %slot1888, align 8
  %v10687 = load i64, ptr %slot1887, align 8
  %v10688 = load i64, ptr %slot1888, align 8
  %p10689 = inttoptr i64 %v10687 to ptr
  %p10690 = inttoptr i64 %v10688 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10690, ptr %p10689, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10691 = load i64, ptr %slot35, align 8
  %p10692 = inttoptr i64 %v10691 to ptr
  store i32 2, ptr %p10692, align 4, !alias.scope !3, !noalias !4
  %v10693 = load i64, ptr %slot34, align 8
  %p10694 = inttoptr i64 %v10693 to ptr
  store i32 1, ptr %p10694, align 4, !alias.scope !3, !noalias !4
  %v10695 = load i64, ptr %slot28, align 8
  %p10696 = inttoptr i64 %v10695 to ptr
  %ld10697 = load i32, ptr %p10696, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10697, ptr %slot1889, align 8
  %v10698 = load i32, ptr %slot1889, align 8
  %cv10699 = zext i32 %v10698 to i64
  %cond10700 = icmp ne i64 %cv10699, 0
  br i1 %cond10700, label %bb_rcslotdrop2742, label %bb_rcslotdone2742
bb_rcslotdrop2742:
  %v10701 = load i64, ptr %slot28, align 8
  %p10702 = inttoptr i64 %v10701 to ptr
  store i32 0, ptr %p10702, align 4, !alias.scope !3, !noalias !4
  %v10703 = load i64, ptr %slot37, align 8
  store i64 %v10703, ptr %slot1890, align 8
  %v10704 = load i64, ptr %slot29, align 8
  %p10705 = inttoptr i64 %v10704 to ptr
  %ld10706 = load i32, ptr %p10705, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10706, ptr %slot1891, align 8
  %v10707 = load i32, ptr %slot1891, align 8
  %op10708 = and i32 %v10707, 28
  store i32 %op10708, ptr %slot1892, align 8
  %v10709 = load i32, ptr %slot1892, align 8
  %cv10710 = zext i32 %v10709 to i64
  %cond10711 = icmp ne i64 %cv10710, 0
  br i1 %cond10711, label %bb_rcslotrole2742, label %bb_rcslotowner2742
bb_rcslotrole2742:
  %v10712 = load i64, ptr %slot96, align 8
  store i64 %v10712, ptr %slot1893, align 8
  %v10713 = load i64, ptr %slot1890, align 8
  %p10714 = inttoptr i64 %v10713 to ptr
  %ld10715 = load i64, ptr %p10714, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10715, ptr %slot1894, align 8
  %v10716 = load i64, ptr %slot1894, align 8
  %cmp10717 = icmp ne i64 %v10716, 0
  %cv10718 = zext i1 %cmp10717 to i32
  store i32 %cv10718, ptr %slot1895, align 8
  %v10719 = load i32, ptr %slot1895, align 8
  %cv10720 = zext i32 %v10719 to i64
  %cond10721 = icmp ne i64 %cv10720, 0
  br i1 %cond10721, label %bb_rcgnn2758, label %bb_rcgdone2758
bb_rcgnn2758:
  %v10722 = load i64, ptr %slot1894, align 8
  %op10723 = sub i64 %v10722, 16
  store i64 %op10723, ptr %slot1896, align 8
  %v10724 = load i64, ptr %slot1894, align 8
  %p10725 = inttoptr i64 %v10724 to ptr
  %rgep10726 = getelementptr i8, ptr %p10725, i64 -16
  %ld10727 = load i64, ptr %rgep10726, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10727, ptr %slot1897, align 8
  %v10728 = load i64, ptr %slot1897, align 8
  %op10729 = and i64 %v10728, 4611686018427387906
  store i64 %op10729, ptr %slot1898, align 8
  %v10730 = load i64, ptr %slot1898, align 8
  %cmp10731 = icmp ne i64 %v10730, 0
  %cv10732 = zext i1 %cmp10731 to i32
  store i32 %cv10732, ptr %slot1899, align 8
  %v10733 = load i32, ptr %slot1899, align 8
  %cv10734 = zext i32 %v10733 to i64
  %cond10735 = icmp ne i64 %cv10734, 0
  br i1 %cond10735, label %bb_rcgclear2758, label %bb_rcgcounted2758
bb_rcgcounted2758:
  %v10736 = load i64, ptr %slot1894, align 8
  %op10737 = sub i64 %v10736, 24
  store i64 %op10737, ptr %slot1900, align 8
  %v10738 = load i64, ptr %slot1894, align 8
  %p10739 = inttoptr i64 %v10738 to ptr
  %rgep10740 = getelementptr i8, ptr %p10739, i64 -24
  %ld10741 = load i64, ptr %rgep10740, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10741, ptr %slot1901, align 8
  %v10742 = load i64, ptr %slot1901, align 8
  %op10743 = sub i64 %v10742, 1
  store i64 %op10743, ptr %slot1902, align 8
  %v10744 = load i64, ptr %slot1902, align 8
  %cmp10745 = icmp eq i64 %v10744, 0
  %cv10746 = zext i1 %cmp10745 to i32
  store i32 %cv10746, ptr %slot1903, align 8
  %v10747 = load i32, ptr %slot1903, align 8
  %cv10748 = zext i32 %v10747 to i64
  %cond10749 = icmp ne i64 %cv10748, 0
  br i1 %cond10749, label %bb_rcglast2758, label %bb_rcgdec2758
bb_rcglast2758:
  %v10750 = load i64, ptr %slot1894, align 8
  %op10751 = sub i64 %v10750, 32
  store i64 %op10751, ptr %slot1904, align 8
  %v10752 = load i64, ptr %slot1894, align 8
  %p10753 = inttoptr i64 %v10752 to ptr
  %rgep10754 = getelementptr i8, ptr %p10753, i64 -32
  %ld10755 = load i64, ptr %rgep10754, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10755, ptr %slot1905, align 8
  %v10756 = load i64, ptr %slot1905, align 8
  %cmp10757 = icmp ne i64 %v10756, 0
  %cv10758 = zext i1 %cmp10757 to i32
  store i32 %cv10758, ptr %slot1906, align 8
  %v10759 = load i32, ptr %slot1906, align 8
  %cv10760 = zext i32 %v10759 to i64
  %cond10761 = icmp ne i64 %cv10760, 0
  br i1 %cond10761, label %bb_rcgdec2758, label %bb_rcgslow2758
bb_rcgslow2758:
  %v10762 = load i64, ptr %slot1893, align 8
  %v10763 = load i64, ptr %slot1890, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v10762, i64 %v10763) nomerge, !dbg !222
  br label %bb_rcgdone2758
bb_rcgdec2758:
  %v10764 = load i64, ptr %slot1902, align 8
  %v10765 = load i64, ptr %slot1894, align 8
  %p10766 = inttoptr i64 %v10765 to ptr
  %rgep10767 = getelementptr i8, ptr %p10766, i64 -24
  store i64 %v10764, ptr %rgep10767, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2758
bb_rcgclear2758:
  %v10768 = load i64, ptr %slot1890, align 8
  %p10769 = inttoptr i64 %v10768 to ptr
  store i64 0, ptr %p10769, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2758
bb_rcgdone2758:
  br label %bb_rcslotdone2742
bb_rcslotowner2742:
  %v10770 = load i64, ptr %slot96, align 8
  store i64 %v10770, ptr %slot1907, align 8
  %v10771 = load i64, ptr %slot1890, align 8
  %p10772 = inttoptr i64 %v10771 to ptr
  %ld10773 = load i64, ptr %p10772, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10773, ptr %slot1908, align 8
  %v10774 = load i64, ptr %slot1908, align 8
  %cmp10775 = icmp ne i64 %v10774, 0
  %cv10776 = zext i1 %cmp10775 to i32
  store i32 %cv10776, ptr %slot1909, align 8
  %v10777 = load i32, ptr %slot1909, align 8
  %cv10778 = zext i32 %v10777 to i64
  %cond10779 = icmp ne i64 %cv10778, 0
  br i1 %cond10779, label %bb_rcgnn2773, label %bb_rcgdone2773
bb_rcgnn2773:
  %v10780 = load i64, ptr %slot1908, align 8
  %op10781 = sub i64 %v10780, 16
  store i64 %op10781, ptr %slot1910, align 8
  %v10782 = load i64, ptr %slot1908, align 8
  %p10783 = inttoptr i64 %v10782 to ptr
  %rgep10784 = getelementptr i8, ptr %p10783, i64 -16
  %ld10785 = load i64, ptr %rgep10784, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10785, ptr %slot1911, align 8
  %v10786 = load i64, ptr %slot1911, align 8
  %op10787 = and i64 %v10786, 4611686018427387906
  store i64 %op10787, ptr %slot1912, align 8
  %v10788 = load i64, ptr %slot1912, align 8
  %cmp10789 = icmp ne i64 %v10788, 0
  %cv10790 = zext i1 %cmp10789 to i32
  store i32 %cv10790, ptr %slot1913, align 8
  %v10791 = load i32, ptr %slot1913, align 8
  %cv10792 = zext i32 %v10791 to i64
  %cond10793 = icmp ne i64 %cv10792, 0
  br i1 %cond10793, label %bb_rcgclear2773, label %bb_rcgcounted2773
bb_rcgcounted2773:
  %v10794 = load i64, ptr %slot1908, align 8
  %op10795 = sub i64 %v10794, 32
  store i64 %op10795, ptr %slot1914, align 8
  %v10796 = load i64, ptr %slot1908, align 8
  %p10797 = inttoptr i64 %v10796 to ptr
  %rgep10798 = getelementptr i8, ptr %p10797, i64 -32
  %ld10799 = load i64, ptr %rgep10798, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10799, ptr %slot1915, align 8
  %v10800 = load i64, ptr %slot1915, align 8
  %op10801 = sub i64 %v10800, 1
  store i64 %op10801, ptr %slot1916, align 8
  %v10802 = load i64, ptr %slot1916, align 8
  %cmp10803 = icmp eq i64 %v10802, 0
  %cv10804 = zext i1 %cmp10803 to i32
  store i32 %cv10804, ptr %slot1917, align 8
  %v10805 = load i32, ptr %slot1917, align 8
  %cv10806 = zext i32 %v10805 to i64
  %cond10807 = icmp ne i64 %cv10806, 0
  br i1 %cond10807, label %bb_rcglast2773, label %bb_rcgdec2773
bb_rcglast2773:
  %v10808 = load i64, ptr %slot1908, align 8
  %op10809 = sub i64 %v10808, 24
  store i64 %op10809, ptr %slot1918, align 8
  %v10810 = load i64, ptr %slot1908, align 8
  %p10811 = inttoptr i64 %v10810 to ptr
  %rgep10812 = getelementptr i8, ptr %p10811, i64 -24
  %ld10813 = load i64, ptr %rgep10812, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10813, ptr %slot1919, align 8
  %v10814 = load i64, ptr %slot1919, align 8
  %cmp10815 = icmp ne i64 %v10814, 0
  %cv10816 = zext i1 %cmp10815 to i32
  store i32 %cv10816, ptr %slot1920, align 8
  %v10817 = load i32, ptr %slot1920, align 8
  %cv10818 = zext i32 %v10817 to i64
  %cond10819 = icmp ne i64 %cv10818, 0
  br i1 %cond10819, label %bb_rcgdec2773, label %bb_rcgslow2773
bb_rcgslow2773:
  %v10820 = load i64, ptr %slot1907, align 8
  %v10821 = load i64, ptr %slot1890, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v10820, i64 %v10821) nomerge, !dbg !222
  br label %bb_rcgdone2773
bb_rcgdec2773:
  %v10822 = load i64, ptr %slot1916, align 8
  %v10823 = load i64, ptr %slot1908, align 8
  %p10824 = inttoptr i64 %v10823 to ptr
  %rgep10825 = getelementptr i8, ptr %p10824, i64 -32
  store i64 %v10822, ptr %rgep10825, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2773
bb_rcgclear2773:
  %v10826 = load i64, ptr %slot1890, align 8
  %p10827 = inttoptr i64 %v10826 to ptr
  store i64 0, ptr %p10827, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2773
bb_rcgdone2773:
  br label %bb_rcslotdone2742
bb_rcslotdone2742:
  %v10828 = load i64, ptr %slot37, align 8
  store i64 %v10828, ptr %slot1921, align 8
  %v10829 = load i64, ptr %slot41, align 8
  store i64 %v10829, ptr %slot1922, align 8
  %v10830 = load i64, ptr %slot1922, align 8
  %v10831 = load i64, ptr %slot1921, align 8
  %p10832 = inttoptr i64 %v10830 to ptr
  %p10833 = inttoptr i64 %v10831 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10833, ptr %p10832, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10834 = load i64, ptr %slot29, align 8
  %p10835 = inttoptr i64 %v10834 to ptr
  store i32 2, ptr %p10835, align 4, !alias.scope !3, !noalias !4
  %v10836 = load i64, ptr %slot35, align 8
  %p10837 = inttoptr i64 %v10836 to ptr
  %ld10838 = load i32, ptr %p10837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10838, ptr %slot1923, align 8
  %v10839 = load i32, ptr %slot1923, align 8
  %v10840 = load i64, ptr %slot29, align 8
  %p10841 = inttoptr i64 %v10840 to ptr
  store i32 %v10839, ptr %p10841, align 4, !alias.scope !3, !noalias !4
  %v10842 = load i64, ptr %slot34, align 8
  %p10843 = inttoptr i64 %v10842 to ptr
  store i32 0, ptr %p10843, align 4, !alias.scope !3, !noalias !4
  %v10844 = load i64, ptr %slot28, align 8
  %p10845 = inttoptr i64 %v10844 to ptr
  store i32 1, ptr %p10845, align 4, !alias.scope !3, !noalias !4
  %v10846 = load i64, ptr %slot1921, align 8
  %p10847 = inttoptr i64 %v10846 to ptr
  %ld10848 = load i64, ptr %p10847, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10848, ptr %slot1924, align 8
  %v10849 = load i64, ptr %slot1924, align 8
  %v10850 = load i64, ptr %slot69, align 8
  %p10851 = inttoptr i64 %v10850 to ptr
  store i64 %v10849, ptr %p10851, align 8, !alias.scope !3, !noalias !4
  %v10852 = load i64, ptr %slot69, align 8
  %p10853 = inttoptr i64 %v10852 to ptr
  %ld10854 = load i64, ptr %p10853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10854, ptr %slot1925, align 8
  %v10855 = load i64, ptr %slot1925, align 8
  %v10856 = load i64, ptr %slot40, align 8
  %p10857 = inttoptr i64 %v10856 to ptr
  store i64 %v10855, ptr %p10857, align 8, !alias.scope !3, !noalias !4
  %v10858 = load i64, ptr %slot40, align 8
  store i64 %v10858, ptr %slot1926, align 8
  %v10859 = load i64, ptr %slot28, align 8
  %p10860 = inttoptr i64 %v10859 to ptr
  %ld10861 = load i32, ptr %p10860, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10861, ptr %slot1927, align 8
  %v10862 = load i64, ptr %slot29, align 8
  %p10863 = inttoptr i64 %v10862 to ptr
  %ld10864 = load i32, ptr %p10863, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10864, ptr %slot1928, align 8
  %v10865 = load i32, ptr %slot1928, align 8
  %op10866 = and i32 %v10865, 24
  store i32 %op10866, ptr %slot1928, align 8
  %v10867 = load i32, ptr %slot1928, align 8
  %cmp10868 = icmp eq i32 %v10867, 0
  %cv10869 = zext i1 %cmp10868 to i32
  store i32 %cv10869, ptr %slot1929, align 8
  %v10870 = load i32, ptr %slot1927, align 8
  %v10871 = load i32, ptr %slot1929, align 8
  %op10872 = and i32 %v10870, %v10871
  store i32 %op10872, ptr %slot1930, align 8
  %v10873 = load i32, ptr %slot1930, align 8
  %cv10874 = zext i32 %v10873 to i64
  %cond10875 = icmp ne i64 %cv10874, 0
  br i1 %cond10875, label %bb_rcprivateown2794, label %bb_rcprivateloan2794
bb_rcprivateown2794:
  %v10876 = load i64, ptr %slot41, align 8
  store i64 %v10876, ptr %slot1931, align 8
  %v10877 = load i64, ptr %slot97, align 8
  store i64 %v10877, ptr %slot1932, align 8
  %v10878 = load i64, ptr %slot1926, align 8
  %v10879 = load i64, ptr %slot1931, align 8
  %op10880 = sub i64 %v10878, %v10879
  store i64 %op10880, ptr %slot1933, align 8
  %v10881 = load i64, ptr %slot1931, align 8
  %v10882 = load i64, ptr %slot1926, align 8
  %op10883 = sub i64 %v10881, %v10882
  store i64 %op10883, ptr %slot1934, align 8
  %v10884 = load i64, ptr %slot1933, align 8
  %cmp10885 = icmp ult i64 %v10884, 8
  %cv10886 = zext i1 %cmp10885 to i32
  store i32 %cv10886, ptr %slot1935, align 8
  %v10887 = load i64, ptr %slot1934, align 8
  %cmp10888 = icmp ult i64 %v10887, 8
  %cv10889 = zext i1 %cmp10888 to i32
  store i32 %cv10889, ptr %slot1936, align 8
  %v10890 = load i32, ptr %slot1935, align 8
  %v10891 = load i32, ptr %slot1936, align 8
  %op10892 = or i32 %v10890, %v10891
  store i32 %op10892, ptr %slot1937, align 8
  %v10893 = load i32, ptr %slot1937, align 8
  %cv10894 = zext i32 %v10893 to i64
  %cond10895 = icmp ne i64 %cv10894, 0
  br i1 %cond10895, label %bb_rcmoveslow2797, label %bb_rcmovecheck2797
bb_rcmovecheck2797:
  %v10896 = load i64, ptr %slot1926, align 8
  %p10898 = inttoptr i64 %v10896 to ptr
  %gep10899 = getelementptr i8, ptr %p10898, i64 0
  %op10897 = ptrtoint ptr %gep10899 to i64
  store i64 %op10897, ptr %slot1938, align 8
  %v10900 = load i64, ptr %slot1938, align 8
  %p10901 = inttoptr i64 %v10900 to ptr
  %ld10902 = load i64, ptr %p10901, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10902, ptr %slot1939, align 8
  %v10903 = load i64, ptr %slot1939, align 8
  %cmp10904 = icmp ne i64 %v10903, 0
  %cv10905 = zext i1 %cmp10904 to i32
  store i32 %cv10905, ptr %slot1940, align 8
  %v10906 = load i32, ptr %slot1940, align 8
  %cv10907 = zext i32 %v10906 to i64
  %cond10908 = icmp ne i64 %cv10907, 0
  br i1 %cond10908, label %bb_rcmoveheader2805, label %bb_rcmovenext2805
bb_rcmoveheader2805:
  %v10909 = load i64, ptr %slot1939, align 8
  %op10910 = sub i64 %v10909, 16
  store i64 %op10910, ptr %slot1941, align 8
  %v10911 = load i64, ptr %slot1939, align 8
  %p10912 = inttoptr i64 %v10911 to ptr
  %rgep10913 = getelementptr i8, ptr %p10912, i64 -16
  %ld10914 = load i64, ptr %rgep10913, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10914, ptr %slot1942, align 8
  %v10915 = load i64, ptr %slot1942, align 8
  %op10916 = and i64 %v10915, 5764607523034234881
  store i64 %op10916, ptr %slot1943, align 8
  %v10917 = load i64, ptr %slot1943, align 8
  %cmp10918 = icmp ne i64 %v10917, 0
  %cv10919 = zext i1 %cmp10918 to i32
  store i32 %cv10919, ptr %slot1944, align 8
  %v10920 = load i32, ptr %slot1944, align 8
  %cv10921 = zext i32 %v10920 to i64
  %cond10922 = icmp ne i64 %cv10921, 0
  br i1 %cond10922, label %bb_rcmoveslow2797, label %bb_rcmovenext2805
bb_rcmovenext2805:
  %v10923 = load i64, ptr %slot1926, align 8
  %v10924 = load i64, ptr %slot1931, align 8
  %p10925 = inttoptr i64 %v10923 to ptr
  %p10926 = inttoptr i64 %v10924 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10926, ptr %p10925, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10927 = load i64, ptr %slot1926, align 8
  %p10928 = inttoptr i64 %v10927 to ptr
  store i64 0, ptr %p10928, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved2797
bb_rcmoveslow2797:
  %v10929 = load i64, ptr %slot96, align 8
  %v10930 = load i64, ptr %slot1931, align 8
  %v10931 = load i64, ptr %slot1926, align 8
  %v10932 = load i64, ptr %slot1932, align 8
  %cv10933 = trunc i64 %v10932 to i32
  %call10934 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v10929, i64 %v10930, i64 %v10931, i32 %cv10933) nomerge, !dbg !224
  store i32 %call10934, ptr %slot1945, align 8
  %v10935 = load i32, ptr %slot1945, align 8
  %cv10936 = zext i32 %v10935 to i64
  %cond10937 = icmp ne i64 %cv10936, 0
  br i1 %cond10937, label %bb_rcsuccess2812, label %bb_rcfailure2812
bb_rcfailure2812:
  %v10938 = load i64, ptr %slot96, align 8
  %p10939 = inttoptr i64 %v10938 to ptr
  %call10940 = call i32 @myl_rc_take_failure(ptr %p10939) nomerge, !dbg !224
  store i32 %call10940, ptr %slot1946, align 8
  %v10941 = load i64, ptr %slot1, align 8
  %p10942 = inttoptr i64 %v10941 to ptr
  %v10943 = load i32, ptr %slot1946, align 8
  %call10944 = call i32 @myl_qbe_rc_status(ptr %p10942, i32 %v10943) nomerge, !dbg !224
  store i32 %call10944, ptr %slot1947, align 8
  br label %bb_failure
bb_rcsuccess2812:
  br label %bb_rcmoved2797
bb_rcmoved2797:
  %v10945 = load i64, ptr %slot28, align 8
  %p10946 = inttoptr i64 %v10945 to ptr
  store i32 0, ptr %p10946, align 4, !alias.scope !3, !noalias !4
  %v10947 = load i64, ptr %slot35, align 8
  %p10948 = inttoptr i64 %v10947 to ptr
  store i32 2, ptr %p10948, align 4, !alias.scope !3, !noalias !4
  %v10949 = load i64, ptr %slot34, align 8
  %p10950 = inttoptr i64 %v10949 to ptr
  store i32 1, ptr %p10950, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2794
bb_rcprivateloan2794:
  %v10951 = load i64, ptr %slot28, align 8
  %p10952 = inttoptr i64 %v10951 to ptr
  %ld10953 = load i32, ptr %p10952, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10953, ptr %slot1948, align 8
  %v10954 = load i64, ptr %slot29, align 8
  %p10955 = inttoptr i64 %v10954 to ptr
  %ld10956 = load i32, ptr %p10955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld10956, ptr %slot1949, align 8
  %v10957 = load i32, ptr %slot1949, align 8
  %cmp10958 = icmp eq i32 %v10957, 16
  %cv10959 = zext i1 %cmp10958 to i32
  store i32 %cv10959, ptr %slot1950, align 8
  %v10960 = load i32, ptr %slot1950, align 8
  %v10961 = load i32, ptr %slot1948, align 8
  %op10962 = and i32 %v10960, %v10961
  store i32 %op10962, ptr %slot1950, align 8
  %v10963 = load i32, ptr %slot1950, align 8
  %cv10964 = zext i32 %v10963 to i64
  %cond10965 = icmp ne i64 %cv10964, 0
  br i1 %cond10965, label %bb_rcprivatemove2794, label %bb_rcprivatenew2794
bb_rcprivatemove2794:
  %v10966 = load i64, ptr %slot41, align 8
  store i64 %v10966, ptr %slot1951, align 8
  %v10967 = load i64, ptr %slot1926, align 8
  %v10968 = load i64, ptr %slot1951, align 8
  %p10969 = inttoptr i64 %v10967 to ptr
  %p10970 = inttoptr i64 %v10968 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p10970, ptr %p10969, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v10971 = load i64, ptr %slot1926, align 8
  %p10972 = inttoptr i64 %v10971 to ptr
  store i64 0, ptr %p10972, align 8, !alias.scope !3, !noalias !4
  %v10973 = load i64, ptr %slot35, align 8
  %p10974 = inttoptr i64 %v10973 to ptr
  store i32 2, ptr %p10974, align 4, !alias.scope !3, !noalias !4
  %v10975 = load i64, ptr %slot35, align 8
  %p10976 = inttoptr i64 %v10975 to ptr
  store i32 16, ptr %p10976, align 4, !alias.scope !3, !noalias !4
  %v10977 = load i64, ptr %slot34, align 8
  %p10978 = inttoptr i64 %v10977 to ptr
  store i32 1, ptr %p10978, align 4, !alias.scope !3, !noalias !4
  %v10979 = load i64, ptr %slot28, align 8
  %p10980 = inttoptr i64 %v10979 to ptr
  store i32 0, ptr %p10980, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared2794
bb_rcprivatenew2794:
  %v10981 = load i64, ptr %slot41, align 8
  store i64 %v10981, ptr %slot1952, align 8
  %v10982 = load i64, ptr %slot1926, align 8
  %p10983 = inttoptr i64 %v10982 to ptr
  %ld10984 = load i64, ptr %p10983, align 8, !alias.scope !3, !noalias !4
  store i64 %ld10984, ptr %slot1953, align 8
  %v10985 = load i64, ptr %slot1953, align 8
  %cmp10986 = icmp ne i64 %v10985, 0
  %cv10987 = zext i1 %cmp10986 to i32
  store i32 %cv10987, ptr %slot1954, align 8
  %v10988 = load i32, ptr %slot1954, align 8
  %cv10989 = zext i32 %v10988 to i64
  %cond10990 = icmp ne i64 %cv10989, 0
  br i1 %cond10990, label %bb_rcgnn2830, label %bb_rcgstore2830
bb_rcgnn2830:
  %v10991 = load i64, ptr %slot1953, align 8
  %op10992 = sub i64 %v10991, 16
  store i64 %op10992, ptr %slot1955, align 8
  %v10993 = load i64, ptr %slot1953, align 8
  %p10994 = inttoptr i64 %v10993 to ptr
  %rgep10995 = getelementptr i8, ptr %p10994, i64 -16
  %ld10996 = load i64, ptr %rgep10995, align 8, !alias.scope !9, !noalias !10
  store i64 %ld10996, ptr %slot1956, align 8
  %v10997 = load i64, ptr %slot1956, align 8
  %op10998 = and i64 %v10997, 4611686018427387906
  store i64 %op10998, ptr %slot1957, align 8
  %v10999 = load i64, ptr %slot1957, align 8
  %cmp11000 = icmp ne i64 %v10999, 0
  %cv11001 = zext i1 %cmp11000 to i32
  store i32 %cv11001, ptr %slot1958, align 8
  %v11002 = load i32, ptr %slot1958, align 8
  %cv11003 = zext i32 %v11002 to i64
  %cond11004 = icmp ne i64 %cv11003, 0
  br i1 %cond11004, label %bb_rcgstore2830, label %bb_rcginc2830
bb_rcginc2830:
  %v11005 = load i64, ptr %slot1953, align 8
  %op11006 = sub i64 %v11005, 24
  store i64 %op11006, ptr %slot1959, align 8
  %v11007 = load i64, ptr %slot1953, align 8
  %p11008 = inttoptr i64 %v11007 to ptr
  %rgep11009 = getelementptr i8, ptr %p11008, i64 -24
  %ld11010 = load i64, ptr %rgep11009, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11010, ptr %slot1960, align 8
  %v11011 = load i64, ptr %slot1960, align 8
  %op11012 = add i64 %v11011, 1
  store i64 %op11012, ptr %slot1961, align 8
  %v11013 = load i64, ptr %slot1961, align 8
  %cmp11014 = icmp eq i64 %v11013, 0
  %cv11015 = zext i1 %cmp11014 to i32
  store i32 %cv11015, ptr %slot1962, align 8
  %v11016 = load i32, ptr %slot1962, align 8
  %cv11017 = zext i32 %v11016 to i64
  %cond11018 = icmp ne i64 %cv11017, 0
  br i1 %cond11018, label %bb_rcglimit2830, label %bb_rcgcapacity2830
bb_rcglimit2830:
  %v11019 = load i64, ptr %slot1, align 8
  %p11020 = inttoptr i64 %v11019 to ptr
  %call11021 = call i32 @myl_qbe_rc_status(ptr %p11020, i32 2) nomerge, !dbg !224
  store i32 %call11021, ptr %slot1963, align 8
  br label %bb_failure
bb_rcgcapacity2830:
  %v11022 = load i64, ptr %slot1961, align 8
  %v11023 = load i64, ptr %slot1953, align 8
  %p11024 = inttoptr i64 %v11023 to ptr
  %rgep11025 = getelementptr i8, ptr %p11024, i64 -24
  store i64 %v11022, ptr %rgep11025, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore2830
bb_rcgstore2830:
  %v11026 = load i64, ptr %slot1953, align 8
  %v11027 = load i64, ptr %slot1952, align 8
  %p11028 = inttoptr i64 %v11027 to ptr
  store i64 %v11026, ptr %p11028, align 8, !alias.scope !3, !noalias !4
  %v11029 = load i64, ptr %slot35, align 8
  %p11030 = inttoptr i64 %v11029 to ptr
  store i32 2, ptr %p11030, align 4, !alias.scope !3, !noalias !4
  %v11031 = load i64, ptr %slot35, align 8
  %p11032 = inttoptr i64 %v11031 to ptr
  store i32 16, ptr %p11032, align 4, !alias.scope !3, !noalias !4
  %v11033 = load i64, ptr %slot34, align 8
  %p11034 = inttoptr i64 %v11033 to ptr
  store i32 1, ptr %p11034, align 4, !alias.scope !3, !noalias !4
  %v11035 = load i64, ptr %slot28, align 8
  %p11036 = inttoptr i64 %v11035 to ptr
  %ld11037 = load i32, ptr %p11036, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11037, ptr %slot1964, align 8
  %v11038 = load i32, ptr %slot1964, align 8
  %cv11039 = zext i32 %v11038 to i64
  %cond11040 = icmp ne i64 %cv11039, 0
  br i1 %cond11040, label %bb_rcslotdrop2846, label %bb_rcslotdone2846
bb_rcslotdrop2846:
  %v11041 = load i64, ptr %slot28, align 8
  %p11042 = inttoptr i64 %v11041 to ptr
  store i32 0, ptr %p11042, align 4, !alias.scope !3, !noalias !4
  %v11043 = load i64, ptr %slot37, align 8
  store i64 %v11043, ptr %slot1965, align 8
  %v11044 = load i64, ptr %slot29, align 8
  %p11045 = inttoptr i64 %v11044 to ptr
  %ld11046 = load i32, ptr %p11045, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11046, ptr %slot1966, align 8
  %v11047 = load i32, ptr %slot1966, align 8
  %op11048 = and i32 %v11047, 28
  store i32 %op11048, ptr %slot1967, align 8
  %v11049 = load i32, ptr %slot1967, align 8
  %cv11050 = zext i32 %v11049 to i64
  %cond11051 = icmp ne i64 %cv11050, 0
  br i1 %cond11051, label %bb_rcslotrole2846, label %bb_rcslotowner2846
bb_rcslotrole2846:
  %v11052 = load i64, ptr %slot96, align 8
  store i64 %v11052, ptr %slot1968, align 8
  %v11053 = load i64, ptr %slot1965, align 8
  %p11054 = inttoptr i64 %v11053 to ptr
  %ld11055 = load i64, ptr %p11054, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11055, ptr %slot1969, align 8
  %v11056 = load i64, ptr %slot1969, align 8
  %cmp11057 = icmp ne i64 %v11056, 0
  %cv11058 = zext i1 %cmp11057 to i32
  store i32 %cv11058, ptr %slot1970, align 8
  %v11059 = load i32, ptr %slot1970, align 8
  %cv11060 = zext i32 %v11059 to i64
  %cond11061 = icmp ne i64 %cv11060, 0
  br i1 %cond11061, label %bb_rcgnn2862, label %bb_rcgdone2862
bb_rcgnn2862:
  %v11062 = load i64, ptr %slot1969, align 8
  %op11063 = sub i64 %v11062, 16
  store i64 %op11063, ptr %slot1971, align 8
  %v11064 = load i64, ptr %slot1969, align 8
  %p11065 = inttoptr i64 %v11064 to ptr
  %rgep11066 = getelementptr i8, ptr %p11065, i64 -16
  %ld11067 = load i64, ptr %rgep11066, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11067, ptr %slot1972, align 8
  %v11068 = load i64, ptr %slot1972, align 8
  %op11069 = and i64 %v11068, 4611686018427387906
  store i64 %op11069, ptr %slot1973, align 8
  %v11070 = load i64, ptr %slot1973, align 8
  %cmp11071 = icmp ne i64 %v11070, 0
  %cv11072 = zext i1 %cmp11071 to i32
  store i32 %cv11072, ptr %slot1974, align 8
  %v11073 = load i32, ptr %slot1974, align 8
  %cv11074 = zext i32 %v11073 to i64
  %cond11075 = icmp ne i64 %cv11074, 0
  br i1 %cond11075, label %bb_rcgclear2862, label %bb_rcgcounted2862
bb_rcgcounted2862:
  %v11076 = load i64, ptr %slot1969, align 8
  %op11077 = sub i64 %v11076, 24
  store i64 %op11077, ptr %slot1975, align 8
  %v11078 = load i64, ptr %slot1969, align 8
  %p11079 = inttoptr i64 %v11078 to ptr
  %rgep11080 = getelementptr i8, ptr %p11079, i64 -24
  %ld11081 = load i64, ptr %rgep11080, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11081, ptr %slot1976, align 8
  %v11082 = load i64, ptr %slot1976, align 8
  %op11083 = sub i64 %v11082, 1
  store i64 %op11083, ptr %slot1977, align 8
  %v11084 = load i64, ptr %slot1977, align 8
  %cmp11085 = icmp eq i64 %v11084, 0
  %cv11086 = zext i1 %cmp11085 to i32
  store i32 %cv11086, ptr %slot1978, align 8
  %v11087 = load i32, ptr %slot1978, align 8
  %cv11088 = zext i32 %v11087 to i64
  %cond11089 = icmp ne i64 %cv11088, 0
  br i1 %cond11089, label %bb_rcglast2862, label %bb_rcgdec2862
bb_rcglast2862:
  %v11090 = load i64, ptr %slot1969, align 8
  %op11091 = sub i64 %v11090, 32
  store i64 %op11091, ptr %slot1979, align 8
  %v11092 = load i64, ptr %slot1969, align 8
  %p11093 = inttoptr i64 %v11092 to ptr
  %rgep11094 = getelementptr i8, ptr %p11093, i64 -32
  %ld11095 = load i64, ptr %rgep11094, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11095, ptr %slot1980, align 8
  %v11096 = load i64, ptr %slot1980, align 8
  %cmp11097 = icmp ne i64 %v11096, 0
  %cv11098 = zext i1 %cmp11097 to i32
  store i32 %cv11098, ptr %slot1981, align 8
  %v11099 = load i32, ptr %slot1981, align 8
  %cv11100 = zext i32 %v11099 to i64
  %cond11101 = icmp ne i64 %cv11100, 0
  br i1 %cond11101, label %bb_rcgdec2862, label %bb_rcgslow2862
bb_rcgslow2862:
  %v11102 = load i64, ptr %slot1968, align 8
  %v11103 = load i64, ptr %slot1965, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v11102, i64 %v11103) nomerge, !dbg !224
  br label %bb_rcgdone2862
bb_rcgdec2862:
  %v11104 = load i64, ptr %slot1977, align 8
  %v11105 = load i64, ptr %slot1969, align 8
  %p11106 = inttoptr i64 %v11105 to ptr
  %rgep11107 = getelementptr i8, ptr %p11106, i64 -24
  store i64 %v11104, ptr %rgep11107, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2862
bb_rcgclear2862:
  %v11108 = load i64, ptr %slot1965, align 8
  %p11109 = inttoptr i64 %v11108 to ptr
  store i64 0, ptr %p11109, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2862
bb_rcgdone2862:
  br label %bb_rcslotdone2846
bb_rcslotowner2846:
  %v11110 = load i64, ptr %slot96, align 8
  store i64 %v11110, ptr %slot1982, align 8
  %v11111 = load i64, ptr %slot1965, align 8
  %p11112 = inttoptr i64 %v11111 to ptr
  %ld11113 = load i64, ptr %p11112, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11113, ptr %slot1983, align 8
  %v11114 = load i64, ptr %slot1983, align 8
  %cmp11115 = icmp ne i64 %v11114, 0
  %cv11116 = zext i1 %cmp11115 to i32
  store i32 %cv11116, ptr %slot1984, align 8
  %v11117 = load i32, ptr %slot1984, align 8
  %cv11118 = zext i32 %v11117 to i64
  %cond11119 = icmp ne i64 %cv11118, 0
  br i1 %cond11119, label %bb_rcgnn2877, label %bb_rcgdone2877
bb_rcgnn2877:
  %v11120 = load i64, ptr %slot1983, align 8
  %op11121 = sub i64 %v11120, 16
  store i64 %op11121, ptr %slot1985, align 8
  %v11122 = load i64, ptr %slot1983, align 8
  %p11123 = inttoptr i64 %v11122 to ptr
  %rgep11124 = getelementptr i8, ptr %p11123, i64 -16
  %ld11125 = load i64, ptr %rgep11124, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11125, ptr %slot1986, align 8
  %v11126 = load i64, ptr %slot1986, align 8
  %op11127 = and i64 %v11126, 4611686018427387906
  store i64 %op11127, ptr %slot1987, align 8
  %v11128 = load i64, ptr %slot1987, align 8
  %cmp11129 = icmp ne i64 %v11128, 0
  %cv11130 = zext i1 %cmp11129 to i32
  store i32 %cv11130, ptr %slot1988, align 8
  %v11131 = load i32, ptr %slot1988, align 8
  %cv11132 = zext i32 %v11131 to i64
  %cond11133 = icmp ne i64 %cv11132, 0
  br i1 %cond11133, label %bb_rcgclear2877, label %bb_rcgcounted2877
bb_rcgcounted2877:
  %v11134 = load i64, ptr %slot1983, align 8
  %op11135 = sub i64 %v11134, 32
  store i64 %op11135, ptr %slot1989, align 8
  %v11136 = load i64, ptr %slot1983, align 8
  %p11137 = inttoptr i64 %v11136 to ptr
  %rgep11138 = getelementptr i8, ptr %p11137, i64 -32
  %ld11139 = load i64, ptr %rgep11138, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11139, ptr %slot1990, align 8
  %v11140 = load i64, ptr %slot1990, align 8
  %op11141 = sub i64 %v11140, 1
  store i64 %op11141, ptr %slot1991, align 8
  %v11142 = load i64, ptr %slot1991, align 8
  %cmp11143 = icmp eq i64 %v11142, 0
  %cv11144 = zext i1 %cmp11143 to i32
  store i32 %cv11144, ptr %slot1992, align 8
  %v11145 = load i32, ptr %slot1992, align 8
  %cv11146 = zext i32 %v11145 to i64
  %cond11147 = icmp ne i64 %cv11146, 0
  br i1 %cond11147, label %bb_rcglast2877, label %bb_rcgdec2877
bb_rcglast2877:
  %v11148 = load i64, ptr %slot1983, align 8
  %op11149 = sub i64 %v11148, 24
  store i64 %op11149, ptr %slot1993, align 8
  %v11150 = load i64, ptr %slot1983, align 8
  %p11151 = inttoptr i64 %v11150 to ptr
  %rgep11152 = getelementptr i8, ptr %p11151, i64 -24
  %ld11153 = load i64, ptr %rgep11152, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11153, ptr %slot1994, align 8
  %v11154 = load i64, ptr %slot1994, align 8
  %cmp11155 = icmp ne i64 %v11154, 0
  %cv11156 = zext i1 %cmp11155 to i32
  store i32 %cv11156, ptr %slot1995, align 8
  %v11157 = load i32, ptr %slot1995, align 8
  %cv11158 = zext i32 %v11157 to i64
  %cond11159 = icmp ne i64 %cv11158, 0
  br i1 %cond11159, label %bb_rcgdec2877, label %bb_rcgslow2877
bb_rcgslow2877:
  %v11160 = load i64, ptr %slot1982, align 8
  %v11161 = load i64, ptr %slot1965, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v11160, i64 %v11161) nomerge, !dbg !224
  br label %bb_rcgdone2877
bb_rcgdec2877:
  %v11162 = load i64, ptr %slot1991, align 8
  %v11163 = load i64, ptr %slot1983, align 8
  %p11164 = inttoptr i64 %v11163 to ptr
  %rgep11165 = getelementptr i8, ptr %p11164, i64 -32
  store i64 %v11162, ptr %rgep11165, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2877
bb_rcgclear2877:
  %v11166 = load i64, ptr %slot1965, align 8
  %p11167 = inttoptr i64 %v11166 to ptr
  store i64 0, ptr %p11167, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2877
bb_rcgdone2877:
  br label %bb_rcslotdone2846
bb_rcslotdone2846:
  br label %bb_rcprivateprepared2794
bb_rcprivateprepared2794:
  %v11168 = load i64, ptr %slot24, align 8
  %p11169 = inttoptr i64 %v11168 to ptr
  %ld11170 = load i32, ptr %p11169, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11170, ptr %slot1996, align 8
  %v11171 = load i32, ptr %slot1996, align 8
  %cv11172 = zext i32 %v11171 to i64
  %cond11173 = icmp ne i64 %cv11172, 0
  br i1 %cond11173, label %bb_rcslotdrop2884, label %bb_rcslotdone2884
bb_rcslotdrop2884:
  %v11174 = load i64, ptr %slot24, align 8
  %p11175 = inttoptr i64 %v11174 to ptr
  store i32 0, ptr %p11175, align 4, !alias.scope !3, !noalias !4
  %v11176 = load i64, ptr %slot67, align 8
  store i64 %v11176, ptr %slot1997, align 8
  %v11177 = load i64, ptr %slot25, align 8
  %p11178 = inttoptr i64 %v11177 to ptr
  %ld11179 = load i32, ptr %p11178, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11179, ptr %slot1998, align 8
  %v11180 = load i32, ptr %slot1998, align 8
  %op11181 = and i32 %v11180, 28
  store i32 %op11181, ptr %slot1999, align 8
  %v11182 = load i32, ptr %slot1999, align 8
  %cv11183 = zext i32 %v11182 to i64
  %cond11184 = icmp ne i64 %cv11183, 0
  br i1 %cond11184, label %bb_rcslotrole2884, label %bb_rcslotowner2884
bb_rcslotrole2884:
  %v11185 = load i64, ptr %slot96, align 8
  store i64 %v11185, ptr %slot2000, align 8
  %v11186 = load i64, ptr %slot1997, align 8
  %p11187 = inttoptr i64 %v11186 to ptr
  %ld11188 = load i64, ptr %p11187, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11188, ptr %slot2001, align 8
  %v11189 = load i64, ptr %slot2001, align 8
  %cmp11190 = icmp ne i64 %v11189, 0
  %cv11191 = zext i1 %cmp11190 to i32
  store i32 %cv11191, ptr %slot2002, align 8
  %v11192 = load i32, ptr %slot2002, align 8
  %cv11193 = zext i32 %v11192 to i64
  %cond11194 = icmp ne i64 %cv11193, 0
  br i1 %cond11194, label %bb_rcgnn2900, label %bb_rcgdone2900
bb_rcgnn2900:
  %v11195 = load i64, ptr %slot2001, align 8
  %op11196 = sub i64 %v11195, 16
  store i64 %op11196, ptr %slot2003, align 8
  %v11197 = load i64, ptr %slot2001, align 8
  %p11198 = inttoptr i64 %v11197 to ptr
  %rgep11199 = getelementptr i8, ptr %p11198, i64 -16
  %ld11200 = load i64, ptr %rgep11199, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11200, ptr %slot2004, align 8
  %v11201 = load i64, ptr %slot2004, align 8
  %op11202 = and i64 %v11201, 4611686018427387906
  store i64 %op11202, ptr %slot2005, align 8
  %v11203 = load i64, ptr %slot2005, align 8
  %cmp11204 = icmp ne i64 %v11203, 0
  %cv11205 = zext i1 %cmp11204 to i32
  store i32 %cv11205, ptr %slot2006, align 8
  %v11206 = load i32, ptr %slot2006, align 8
  %cv11207 = zext i32 %v11206 to i64
  %cond11208 = icmp ne i64 %cv11207, 0
  br i1 %cond11208, label %bb_rcgclear2900, label %bb_rcgcounted2900
bb_rcgcounted2900:
  %v11209 = load i64, ptr %slot2001, align 8
  %op11210 = sub i64 %v11209, 24
  store i64 %op11210, ptr %slot2007, align 8
  %v11211 = load i64, ptr %slot2001, align 8
  %p11212 = inttoptr i64 %v11211 to ptr
  %rgep11213 = getelementptr i8, ptr %p11212, i64 -24
  %ld11214 = load i64, ptr %rgep11213, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11214, ptr %slot2008, align 8
  %v11215 = load i64, ptr %slot2008, align 8
  %op11216 = sub i64 %v11215, 1
  store i64 %op11216, ptr %slot2009, align 8
  %v11217 = load i64, ptr %slot2009, align 8
  %cmp11218 = icmp eq i64 %v11217, 0
  %cv11219 = zext i1 %cmp11218 to i32
  store i32 %cv11219, ptr %slot2010, align 8
  %v11220 = load i32, ptr %slot2010, align 8
  %cv11221 = zext i32 %v11220 to i64
  %cond11222 = icmp ne i64 %cv11221, 0
  br i1 %cond11222, label %bb_rcglast2900, label %bb_rcgdec2900
bb_rcglast2900:
  %v11223 = load i64, ptr %slot2001, align 8
  %op11224 = sub i64 %v11223, 32
  store i64 %op11224, ptr %slot2011, align 8
  %v11225 = load i64, ptr %slot2001, align 8
  %p11226 = inttoptr i64 %v11225 to ptr
  %rgep11227 = getelementptr i8, ptr %p11226, i64 -32
  %ld11228 = load i64, ptr %rgep11227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11228, ptr %slot2012, align 8
  %v11229 = load i64, ptr %slot2012, align 8
  %cmp11230 = icmp ne i64 %v11229, 0
  %cv11231 = zext i1 %cmp11230 to i32
  store i32 %cv11231, ptr %slot2013, align 8
  %v11232 = load i32, ptr %slot2013, align 8
  %cv11233 = zext i32 %v11232 to i64
  %cond11234 = icmp ne i64 %cv11233, 0
  br i1 %cond11234, label %bb_rcgdec2900, label %bb_rcgslow2900
bb_rcgslow2900:
  %v11235 = load i64, ptr %slot2000, align 8
  %v11236 = load i64, ptr %slot1997, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v11235, i64 %v11236) nomerge, !dbg !224
  br label %bb_rcgdone2900
bb_rcgdec2900:
  %v11237 = load i64, ptr %slot2009, align 8
  %v11238 = load i64, ptr %slot2001, align 8
  %p11239 = inttoptr i64 %v11238 to ptr
  %rgep11240 = getelementptr i8, ptr %p11239, i64 -24
  store i64 %v11237, ptr %rgep11240, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2900
bb_rcgclear2900:
  %v11241 = load i64, ptr %slot1997, align 8
  %p11242 = inttoptr i64 %v11241 to ptr
  store i64 0, ptr %p11242, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2900
bb_rcgdone2900:
  br label %bb_rcslotdone2884
bb_rcslotowner2884:
  %v11243 = load i64, ptr %slot96, align 8
  store i64 %v11243, ptr %slot2014, align 8
  %v11244 = load i64, ptr %slot1997, align 8
  %p11245 = inttoptr i64 %v11244 to ptr
  %ld11246 = load i64, ptr %p11245, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11246, ptr %slot2015, align 8
  %v11247 = load i64, ptr %slot2015, align 8
  %cmp11248 = icmp ne i64 %v11247, 0
  %cv11249 = zext i1 %cmp11248 to i32
  store i32 %cv11249, ptr %slot2016, align 8
  %v11250 = load i32, ptr %slot2016, align 8
  %cv11251 = zext i32 %v11250 to i64
  %cond11252 = icmp ne i64 %cv11251, 0
  br i1 %cond11252, label %bb_rcgnn2915, label %bb_rcgdone2915
bb_rcgnn2915:
  %v11253 = load i64, ptr %slot2015, align 8
  %op11254 = sub i64 %v11253, 16
  store i64 %op11254, ptr %slot2017, align 8
  %v11255 = load i64, ptr %slot2015, align 8
  %p11256 = inttoptr i64 %v11255 to ptr
  %rgep11257 = getelementptr i8, ptr %p11256, i64 -16
  %ld11258 = load i64, ptr %rgep11257, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11258, ptr %slot2018, align 8
  %v11259 = load i64, ptr %slot2018, align 8
  %op11260 = and i64 %v11259, 4611686018427387906
  store i64 %op11260, ptr %slot2019, align 8
  %v11261 = load i64, ptr %slot2019, align 8
  %cmp11262 = icmp ne i64 %v11261, 0
  %cv11263 = zext i1 %cmp11262 to i32
  store i32 %cv11263, ptr %slot2020, align 8
  %v11264 = load i32, ptr %slot2020, align 8
  %cv11265 = zext i32 %v11264 to i64
  %cond11266 = icmp ne i64 %cv11265, 0
  br i1 %cond11266, label %bb_rcgclear2915, label %bb_rcgcounted2915
bb_rcgcounted2915:
  %v11267 = load i64, ptr %slot2015, align 8
  %op11268 = sub i64 %v11267, 32
  store i64 %op11268, ptr %slot2021, align 8
  %v11269 = load i64, ptr %slot2015, align 8
  %p11270 = inttoptr i64 %v11269 to ptr
  %rgep11271 = getelementptr i8, ptr %p11270, i64 -32
  %ld11272 = load i64, ptr %rgep11271, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11272, ptr %slot2022, align 8
  %v11273 = load i64, ptr %slot2022, align 8
  %op11274 = sub i64 %v11273, 1
  store i64 %op11274, ptr %slot2023, align 8
  %v11275 = load i64, ptr %slot2023, align 8
  %cmp11276 = icmp eq i64 %v11275, 0
  %cv11277 = zext i1 %cmp11276 to i32
  store i32 %cv11277, ptr %slot2024, align 8
  %v11278 = load i32, ptr %slot2024, align 8
  %cv11279 = zext i32 %v11278 to i64
  %cond11280 = icmp ne i64 %cv11279, 0
  br i1 %cond11280, label %bb_rcglast2915, label %bb_rcgdec2915
bb_rcglast2915:
  %v11281 = load i64, ptr %slot2015, align 8
  %op11282 = sub i64 %v11281, 24
  store i64 %op11282, ptr %slot2025, align 8
  %v11283 = load i64, ptr %slot2015, align 8
  %p11284 = inttoptr i64 %v11283 to ptr
  %rgep11285 = getelementptr i8, ptr %p11284, i64 -24
  %ld11286 = load i64, ptr %rgep11285, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11286, ptr %slot2026, align 8
  %v11287 = load i64, ptr %slot2026, align 8
  %cmp11288 = icmp ne i64 %v11287, 0
  %cv11289 = zext i1 %cmp11288 to i32
  store i32 %cv11289, ptr %slot2027, align 8
  %v11290 = load i32, ptr %slot2027, align 8
  %cv11291 = zext i32 %v11290 to i64
  %cond11292 = icmp ne i64 %cv11291, 0
  br i1 %cond11292, label %bb_rcgdec2915, label %bb_rcgslow2915
bb_rcgslow2915:
  %v11293 = load i64, ptr %slot2014, align 8
  %v11294 = load i64, ptr %slot1997, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v11293, i64 %v11294) nomerge, !dbg !224
  br label %bb_rcgdone2915
bb_rcgdec2915:
  %v11295 = load i64, ptr %slot2023, align 8
  %v11296 = load i64, ptr %slot2015, align 8
  %p11297 = inttoptr i64 %v11296 to ptr
  %rgep11298 = getelementptr i8, ptr %p11297, i64 -32
  store i64 %v11295, ptr %rgep11298, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2915
bb_rcgclear2915:
  %v11299 = load i64, ptr %slot1997, align 8
  %p11300 = inttoptr i64 %v11299 to ptr
  store i64 0, ptr %p11300, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2915
bb_rcgdone2915:
  br label %bb_rcslotdone2884
bb_rcslotdone2884:
  %v11301 = load i64, ptr %slot67, align 8
  store i64 %v11301, ptr %slot2028, align 8
  %v11302 = load i64, ptr %slot41, align 8
  store i64 %v11302, ptr %slot2029, align 8
  %v11303 = load i64, ptr %slot2029, align 8
  %v11304 = load i64, ptr %slot2028, align 8
  %p11305 = inttoptr i64 %v11303 to ptr
  %p11306 = inttoptr i64 %v11304 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11306, ptr %p11305, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11307 = load i64, ptr %slot34, align 8
  %p11308 = inttoptr i64 %v11307 to ptr
  store i32 0, ptr %p11308, align 4, !alias.scope !3, !noalias !4
  %v11309 = load i64, ptr %slot25, align 8
  %p11310 = inttoptr i64 %v11309 to ptr
  store i32 2, ptr %p11310, align 4, !alias.scope !3, !noalias !4
  %v11311 = load i64, ptr %slot35, align 8
  %p11312 = inttoptr i64 %v11311 to ptr
  %ld11313 = load i32, ptr %p11312, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11313, ptr %slot2030, align 8
  %v11314 = load i32, ptr %slot2030, align 8
  %v11315 = load i64, ptr %slot25, align 8
  %p11316 = inttoptr i64 %v11315 to ptr
  store i32 %v11314, ptr %p11316, align 4, !alias.scope !3, !noalias !4
  %v11317 = load i64, ptr %slot24, align 8
  %p11318 = inttoptr i64 %v11317 to ptr
  store i32 1, ptr %p11318, align 4, !alias.scope !3, !noalias !4
  %v11319 = load i64, ptr %slot20, align 8
  %p11320 = inttoptr i64 %v11319 to ptr
  %ld11321 = load i32, ptr %p11320, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11321, ptr %slot2031, align 8
  %v11322 = load i32, ptr %slot2031, align 8
  %cv11323 = zext i32 %v11322 to i64
  %cond11324 = icmp ne i64 %cv11323, 0
  br i1 %cond11324, label %bb_rcslotdrop2928, label %bb_rcslotdone2928
bb_rcslotdrop2928:
  %v11325 = load i64, ptr %slot20, align 8
  %p11326 = inttoptr i64 %v11325 to ptr
  store i32 0, ptr %p11326, align 4, !alias.scope !3, !noalias !4
  %v11327 = load i64, ptr %slot65, align 8
  store i64 %v11327, ptr %slot2032, align 8
  %v11328 = load i64, ptr %slot21, align 8
  %p11329 = inttoptr i64 %v11328 to ptr
  %ld11330 = load i32, ptr %p11329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11330, ptr %slot2033, align 8
  %v11331 = load i32, ptr %slot2033, align 8
  %op11332 = and i32 %v11331, 28
  store i32 %op11332, ptr %slot2034, align 8
  %v11333 = load i32, ptr %slot2034, align 8
  %cv11334 = zext i32 %v11333 to i64
  %cond11335 = icmp ne i64 %cv11334, 0
  br i1 %cond11335, label %bb_rcslotrole2928, label %bb_rcslotowner2928
bb_rcslotrole2928:
  %v11336 = load i64, ptr %slot96, align 8
  store i64 %v11336, ptr %slot2035, align 8
  %v11337 = load i64, ptr %slot2032, align 8
  %p11338 = inttoptr i64 %v11337 to ptr
  %ld11339 = load i64, ptr %p11338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11339, ptr %slot2036, align 8
  %v11340 = load i64, ptr %slot2036, align 8
  %cmp11341 = icmp ne i64 %v11340, 0
  %cv11342 = zext i1 %cmp11341 to i32
  store i32 %cv11342, ptr %slot2037, align 8
  %v11343 = load i32, ptr %slot2037, align 8
  %cv11344 = zext i32 %v11343 to i64
  %cond11345 = icmp ne i64 %cv11344, 0
  br i1 %cond11345, label %bb_rcgnn2944, label %bb_rcgdone2944
bb_rcgnn2944:
  %v11346 = load i64, ptr %slot2036, align 8
  %op11347 = sub i64 %v11346, 16
  store i64 %op11347, ptr %slot2038, align 8
  %v11348 = load i64, ptr %slot2036, align 8
  %p11349 = inttoptr i64 %v11348 to ptr
  %rgep11350 = getelementptr i8, ptr %p11349, i64 -16
  %ld11351 = load i64, ptr %rgep11350, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11351, ptr %slot2039, align 8
  %v11352 = load i64, ptr %slot2039, align 8
  %op11353 = and i64 %v11352, 4611686018427387906
  store i64 %op11353, ptr %slot2040, align 8
  %v11354 = load i64, ptr %slot2040, align 8
  %cmp11355 = icmp ne i64 %v11354, 0
  %cv11356 = zext i1 %cmp11355 to i32
  store i32 %cv11356, ptr %slot2041, align 8
  %v11357 = load i32, ptr %slot2041, align 8
  %cv11358 = zext i32 %v11357 to i64
  %cond11359 = icmp ne i64 %cv11358, 0
  br i1 %cond11359, label %bb_rcgclear2944, label %bb_rcgcounted2944
bb_rcgcounted2944:
  %v11360 = load i64, ptr %slot2036, align 8
  %op11361 = sub i64 %v11360, 24
  store i64 %op11361, ptr %slot2042, align 8
  %v11362 = load i64, ptr %slot2036, align 8
  %p11363 = inttoptr i64 %v11362 to ptr
  %rgep11364 = getelementptr i8, ptr %p11363, i64 -24
  %ld11365 = load i64, ptr %rgep11364, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11365, ptr %slot2043, align 8
  %v11366 = load i64, ptr %slot2043, align 8
  %op11367 = sub i64 %v11366, 1
  store i64 %op11367, ptr %slot2044, align 8
  %v11368 = load i64, ptr %slot2044, align 8
  %cmp11369 = icmp eq i64 %v11368, 0
  %cv11370 = zext i1 %cmp11369 to i32
  store i32 %cv11370, ptr %slot2045, align 8
  %v11371 = load i32, ptr %slot2045, align 8
  %cv11372 = zext i32 %v11371 to i64
  %cond11373 = icmp ne i64 %cv11372, 0
  br i1 %cond11373, label %bb_rcglast2944, label %bb_rcgdec2944
bb_rcglast2944:
  %v11374 = load i64, ptr %slot2036, align 8
  %op11375 = sub i64 %v11374, 32
  store i64 %op11375, ptr %slot2046, align 8
  %v11376 = load i64, ptr %slot2036, align 8
  %p11377 = inttoptr i64 %v11376 to ptr
  %rgep11378 = getelementptr i8, ptr %p11377, i64 -32
  %ld11379 = load i64, ptr %rgep11378, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11379, ptr %slot2047, align 8
  %v11380 = load i64, ptr %slot2047, align 8
  %cmp11381 = icmp ne i64 %v11380, 0
  %cv11382 = zext i1 %cmp11381 to i32
  store i32 %cv11382, ptr %slot2048, align 8
  %v11383 = load i32, ptr %slot2048, align 8
  %cv11384 = zext i32 %v11383 to i64
  %cond11385 = icmp ne i64 %cv11384, 0
  br i1 %cond11385, label %bb_rcgdec2944, label %bb_rcgslow2944
bb_rcgslow2944:
  %v11386 = load i64, ptr %slot2035, align 8
  %v11387 = load i64, ptr %slot2032, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v11386, i64 %v11387) nomerge, !dbg !224
  br label %bb_rcgdone2944
bb_rcgdec2944:
  %v11388 = load i64, ptr %slot2044, align 8
  %v11389 = load i64, ptr %slot2036, align 8
  %p11390 = inttoptr i64 %v11389 to ptr
  %rgep11391 = getelementptr i8, ptr %p11390, i64 -24
  store i64 %v11388, ptr %rgep11391, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2944
bb_rcgclear2944:
  %v11392 = load i64, ptr %slot2032, align 8
  %p11393 = inttoptr i64 %v11392 to ptr
  store i64 0, ptr %p11393, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2944
bb_rcgdone2944:
  br label %bb_rcslotdone2928
bb_rcslotowner2928:
  %v11394 = load i64, ptr %slot96, align 8
  store i64 %v11394, ptr %slot2049, align 8
  %v11395 = load i64, ptr %slot2032, align 8
  %p11396 = inttoptr i64 %v11395 to ptr
  %ld11397 = load i64, ptr %p11396, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11397, ptr %slot2050, align 8
  %v11398 = load i64, ptr %slot2050, align 8
  %cmp11399 = icmp ne i64 %v11398, 0
  %cv11400 = zext i1 %cmp11399 to i32
  store i32 %cv11400, ptr %slot2051, align 8
  %v11401 = load i32, ptr %slot2051, align 8
  %cv11402 = zext i32 %v11401 to i64
  %cond11403 = icmp ne i64 %cv11402, 0
  br i1 %cond11403, label %bb_rcgnn2959, label %bb_rcgdone2959
bb_rcgnn2959:
  %v11404 = load i64, ptr %slot2050, align 8
  %op11405 = sub i64 %v11404, 16
  store i64 %op11405, ptr %slot2052, align 8
  %v11406 = load i64, ptr %slot2050, align 8
  %p11407 = inttoptr i64 %v11406 to ptr
  %rgep11408 = getelementptr i8, ptr %p11407, i64 -16
  %ld11409 = load i64, ptr %rgep11408, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11409, ptr %slot2053, align 8
  %v11410 = load i64, ptr %slot2053, align 8
  %op11411 = and i64 %v11410, 4611686018427387906
  store i64 %op11411, ptr %slot2054, align 8
  %v11412 = load i64, ptr %slot2054, align 8
  %cmp11413 = icmp ne i64 %v11412, 0
  %cv11414 = zext i1 %cmp11413 to i32
  store i32 %cv11414, ptr %slot2055, align 8
  %v11415 = load i32, ptr %slot2055, align 8
  %cv11416 = zext i32 %v11415 to i64
  %cond11417 = icmp ne i64 %cv11416, 0
  br i1 %cond11417, label %bb_rcgclear2959, label %bb_rcgcounted2959
bb_rcgcounted2959:
  %v11418 = load i64, ptr %slot2050, align 8
  %op11419 = sub i64 %v11418, 32
  store i64 %op11419, ptr %slot2056, align 8
  %v11420 = load i64, ptr %slot2050, align 8
  %p11421 = inttoptr i64 %v11420 to ptr
  %rgep11422 = getelementptr i8, ptr %p11421, i64 -32
  %ld11423 = load i64, ptr %rgep11422, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11423, ptr %slot2057, align 8
  %v11424 = load i64, ptr %slot2057, align 8
  %op11425 = sub i64 %v11424, 1
  store i64 %op11425, ptr %slot2058, align 8
  %v11426 = load i64, ptr %slot2058, align 8
  %cmp11427 = icmp eq i64 %v11426, 0
  %cv11428 = zext i1 %cmp11427 to i32
  store i32 %cv11428, ptr %slot2059, align 8
  %v11429 = load i32, ptr %slot2059, align 8
  %cv11430 = zext i32 %v11429 to i64
  %cond11431 = icmp ne i64 %cv11430, 0
  br i1 %cond11431, label %bb_rcglast2959, label %bb_rcgdec2959
bb_rcglast2959:
  %v11432 = load i64, ptr %slot2050, align 8
  %op11433 = sub i64 %v11432, 24
  store i64 %op11433, ptr %slot2060, align 8
  %v11434 = load i64, ptr %slot2050, align 8
  %p11435 = inttoptr i64 %v11434 to ptr
  %rgep11436 = getelementptr i8, ptr %p11435, i64 -24
  %ld11437 = load i64, ptr %rgep11436, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11437, ptr %slot2061, align 8
  %v11438 = load i64, ptr %slot2061, align 8
  %cmp11439 = icmp ne i64 %v11438, 0
  %cv11440 = zext i1 %cmp11439 to i32
  store i32 %cv11440, ptr %slot2062, align 8
  %v11441 = load i32, ptr %slot2062, align 8
  %cv11442 = zext i32 %v11441 to i64
  %cond11443 = icmp ne i64 %cv11442, 0
  br i1 %cond11443, label %bb_rcgdec2959, label %bb_rcgslow2959
bb_rcgslow2959:
  %v11444 = load i64, ptr %slot2049, align 8
  %v11445 = load i64, ptr %slot2032, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v11444, i64 %v11445) nomerge, !dbg !224
  br label %bb_rcgdone2959
bb_rcgdec2959:
  %v11446 = load i64, ptr %slot2058, align 8
  %v11447 = load i64, ptr %slot2050, align 8
  %p11448 = inttoptr i64 %v11447 to ptr
  %rgep11449 = getelementptr i8, ptr %p11448, i64 -32
  store i64 %v11446, ptr %rgep11449, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2959
bb_rcgclear2959:
  %v11450 = load i64, ptr %slot2032, align 8
  %p11451 = inttoptr i64 %v11450 to ptr
  store i64 0, ptr %p11451, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2959
bb_rcgdone2959:
  br label %bb_rcslotdone2928
bb_rcslotdone2928:
  %v11452 = load i64, ptr %slot22, align 8
  %p11453 = inttoptr i64 %v11452 to ptr
  %ld11454 = load i32, ptr %p11453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11454, ptr %slot2063, align 8
  %v11455 = load i32, ptr %slot2063, align 8
  %cv11456 = zext i32 %v11455 to i64
  %cond11457 = icmp ne i64 %cv11456, 0
  br i1 %cond11457, label %bb_rcslotdrop2965, label %bb_rcslotdone2965
bb_rcslotdrop2965:
  %v11458 = load i64, ptr %slot22, align 8
  %p11459 = inttoptr i64 %v11458 to ptr
  store i32 0, ptr %p11459, align 4, !alias.scope !3, !noalias !4
  %v11460 = load i64, ptr %slot66, align 8
  store i64 %v11460, ptr %slot2064, align 8
  %v11461 = load i64, ptr %slot23, align 8
  %p11462 = inttoptr i64 %v11461 to ptr
  %ld11463 = load i32, ptr %p11462, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11463, ptr %slot2065, align 8
  %v11464 = load i32, ptr %slot2065, align 8
  %op11465 = and i32 %v11464, 28
  store i32 %op11465, ptr %slot2066, align 8
  %v11466 = load i32, ptr %slot2066, align 8
  %cv11467 = zext i32 %v11466 to i64
  %cond11468 = icmp ne i64 %cv11467, 0
  br i1 %cond11468, label %bb_rcslotrole2965, label %bb_rcslotowner2965
bb_rcslotrole2965:
  %v11469 = load i64, ptr %slot96, align 8
  store i64 %v11469, ptr %slot2067, align 8
  %v11470 = load i64, ptr %slot2064, align 8
  %p11471 = inttoptr i64 %v11470 to ptr
  %ld11472 = load i64, ptr %p11471, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11472, ptr %slot2068, align 8
  %v11473 = load i64, ptr %slot2068, align 8
  %cmp11474 = icmp ne i64 %v11473, 0
  %cv11475 = zext i1 %cmp11474 to i32
  store i32 %cv11475, ptr %slot2069, align 8
  %v11476 = load i32, ptr %slot2069, align 8
  %cv11477 = zext i32 %v11476 to i64
  %cond11478 = icmp ne i64 %cv11477, 0
  br i1 %cond11478, label %bb_rcgnn2981, label %bb_rcgdone2981
bb_rcgnn2981:
  %v11479 = load i64, ptr %slot2068, align 8
  %op11480 = sub i64 %v11479, 16
  store i64 %op11480, ptr %slot2070, align 8
  %v11481 = load i64, ptr %slot2068, align 8
  %p11482 = inttoptr i64 %v11481 to ptr
  %rgep11483 = getelementptr i8, ptr %p11482, i64 -16
  %ld11484 = load i64, ptr %rgep11483, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11484, ptr %slot2071, align 8
  %v11485 = load i64, ptr %slot2071, align 8
  %op11486 = and i64 %v11485, 4611686018427387906
  store i64 %op11486, ptr %slot2072, align 8
  %v11487 = load i64, ptr %slot2072, align 8
  %cmp11488 = icmp ne i64 %v11487, 0
  %cv11489 = zext i1 %cmp11488 to i32
  store i32 %cv11489, ptr %slot2073, align 8
  %v11490 = load i32, ptr %slot2073, align 8
  %cv11491 = zext i32 %v11490 to i64
  %cond11492 = icmp ne i64 %cv11491, 0
  br i1 %cond11492, label %bb_rcgclear2981, label %bb_rcgcounted2981
bb_rcgcounted2981:
  %v11493 = load i64, ptr %slot2068, align 8
  %op11494 = sub i64 %v11493, 24
  store i64 %op11494, ptr %slot2074, align 8
  %v11495 = load i64, ptr %slot2068, align 8
  %p11496 = inttoptr i64 %v11495 to ptr
  %rgep11497 = getelementptr i8, ptr %p11496, i64 -24
  %ld11498 = load i64, ptr %rgep11497, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11498, ptr %slot2075, align 8
  %v11499 = load i64, ptr %slot2075, align 8
  %op11500 = sub i64 %v11499, 1
  store i64 %op11500, ptr %slot2076, align 8
  %v11501 = load i64, ptr %slot2076, align 8
  %cmp11502 = icmp eq i64 %v11501, 0
  %cv11503 = zext i1 %cmp11502 to i32
  store i32 %cv11503, ptr %slot2077, align 8
  %v11504 = load i32, ptr %slot2077, align 8
  %cv11505 = zext i32 %v11504 to i64
  %cond11506 = icmp ne i64 %cv11505, 0
  br i1 %cond11506, label %bb_rcglast2981, label %bb_rcgdec2981
bb_rcglast2981:
  %v11507 = load i64, ptr %slot2068, align 8
  %op11508 = sub i64 %v11507, 32
  store i64 %op11508, ptr %slot2078, align 8
  %v11509 = load i64, ptr %slot2068, align 8
  %p11510 = inttoptr i64 %v11509 to ptr
  %rgep11511 = getelementptr i8, ptr %p11510, i64 -32
  %ld11512 = load i64, ptr %rgep11511, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11512, ptr %slot2079, align 8
  %v11513 = load i64, ptr %slot2079, align 8
  %cmp11514 = icmp ne i64 %v11513, 0
  %cv11515 = zext i1 %cmp11514 to i32
  store i32 %cv11515, ptr %slot2080, align 8
  %v11516 = load i32, ptr %slot2080, align 8
  %cv11517 = zext i32 %v11516 to i64
  %cond11518 = icmp ne i64 %cv11517, 0
  br i1 %cond11518, label %bb_rcgdec2981, label %bb_rcgslow2981
bb_rcgslow2981:
  %v11519 = load i64, ptr %slot2067, align 8
  %v11520 = load i64, ptr %slot2064, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v11519, i64 %v11520) nomerge, !dbg !224
  br label %bb_rcgdone2981
bb_rcgdec2981:
  %v11521 = load i64, ptr %slot2076, align 8
  %v11522 = load i64, ptr %slot2068, align 8
  %p11523 = inttoptr i64 %v11522 to ptr
  %rgep11524 = getelementptr i8, ptr %p11523, i64 -24
  store i64 %v11521, ptr %rgep11524, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2981
bb_rcgclear2981:
  %v11525 = load i64, ptr %slot2064, align 8
  %p11526 = inttoptr i64 %v11525 to ptr
  store i64 0, ptr %p11526, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2981
bb_rcgdone2981:
  br label %bb_rcslotdone2965
bb_rcslotowner2965:
  %v11527 = load i64, ptr %slot96, align 8
  store i64 %v11527, ptr %slot2081, align 8
  %v11528 = load i64, ptr %slot2064, align 8
  %p11529 = inttoptr i64 %v11528 to ptr
  %ld11530 = load i64, ptr %p11529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11530, ptr %slot2082, align 8
  %v11531 = load i64, ptr %slot2082, align 8
  %cmp11532 = icmp ne i64 %v11531, 0
  %cv11533 = zext i1 %cmp11532 to i32
  store i32 %cv11533, ptr %slot2083, align 8
  %v11534 = load i32, ptr %slot2083, align 8
  %cv11535 = zext i32 %v11534 to i64
  %cond11536 = icmp ne i64 %cv11535, 0
  br i1 %cond11536, label %bb_rcgnn2996, label %bb_rcgdone2996
bb_rcgnn2996:
  %v11537 = load i64, ptr %slot2082, align 8
  %op11538 = sub i64 %v11537, 16
  store i64 %op11538, ptr %slot2084, align 8
  %v11539 = load i64, ptr %slot2082, align 8
  %p11540 = inttoptr i64 %v11539 to ptr
  %rgep11541 = getelementptr i8, ptr %p11540, i64 -16
  %ld11542 = load i64, ptr %rgep11541, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11542, ptr %slot2085, align 8
  %v11543 = load i64, ptr %slot2085, align 8
  %op11544 = and i64 %v11543, 4611686018427387906
  store i64 %op11544, ptr %slot2086, align 8
  %v11545 = load i64, ptr %slot2086, align 8
  %cmp11546 = icmp ne i64 %v11545, 0
  %cv11547 = zext i1 %cmp11546 to i32
  store i32 %cv11547, ptr %slot2087, align 8
  %v11548 = load i32, ptr %slot2087, align 8
  %cv11549 = zext i32 %v11548 to i64
  %cond11550 = icmp ne i64 %cv11549, 0
  br i1 %cond11550, label %bb_rcgclear2996, label %bb_rcgcounted2996
bb_rcgcounted2996:
  %v11551 = load i64, ptr %slot2082, align 8
  %op11552 = sub i64 %v11551, 32
  store i64 %op11552, ptr %slot2088, align 8
  %v11553 = load i64, ptr %slot2082, align 8
  %p11554 = inttoptr i64 %v11553 to ptr
  %rgep11555 = getelementptr i8, ptr %p11554, i64 -32
  %ld11556 = load i64, ptr %rgep11555, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11556, ptr %slot2089, align 8
  %v11557 = load i64, ptr %slot2089, align 8
  %op11558 = sub i64 %v11557, 1
  store i64 %op11558, ptr %slot2090, align 8
  %v11559 = load i64, ptr %slot2090, align 8
  %cmp11560 = icmp eq i64 %v11559, 0
  %cv11561 = zext i1 %cmp11560 to i32
  store i32 %cv11561, ptr %slot2091, align 8
  %v11562 = load i32, ptr %slot2091, align 8
  %cv11563 = zext i32 %v11562 to i64
  %cond11564 = icmp ne i64 %cv11563, 0
  br i1 %cond11564, label %bb_rcglast2996, label %bb_rcgdec2996
bb_rcglast2996:
  %v11565 = load i64, ptr %slot2082, align 8
  %op11566 = sub i64 %v11565, 24
  store i64 %op11566, ptr %slot2092, align 8
  %v11567 = load i64, ptr %slot2082, align 8
  %p11568 = inttoptr i64 %v11567 to ptr
  %rgep11569 = getelementptr i8, ptr %p11568, i64 -24
  %ld11570 = load i64, ptr %rgep11569, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11570, ptr %slot2093, align 8
  %v11571 = load i64, ptr %slot2093, align 8
  %cmp11572 = icmp ne i64 %v11571, 0
  %cv11573 = zext i1 %cmp11572 to i32
  store i32 %cv11573, ptr %slot2094, align 8
  %v11574 = load i32, ptr %slot2094, align 8
  %cv11575 = zext i32 %v11574 to i64
  %cond11576 = icmp ne i64 %cv11575, 0
  br i1 %cond11576, label %bb_rcgdec2996, label %bb_rcgslow2996
bb_rcgslow2996:
  %v11577 = load i64, ptr %slot2081, align 8
  %v11578 = load i64, ptr %slot2064, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v11577, i64 %v11578) nomerge, !dbg !224
  br label %bb_rcgdone2996
bb_rcgdec2996:
  %v11579 = load i64, ptr %slot2090, align 8
  %v11580 = load i64, ptr %slot2082, align 8
  %p11581 = inttoptr i64 %v11580 to ptr
  %rgep11582 = getelementptr i8, ptr %p11581, i64 -32
  store i64 %v11579, ptr %rgep11582, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear2996
bb_rcgclear2996:
  %v11583 = load i64, ptr %slot2064, align 8
  %p11584 = inttoptr i64 %v11583 to ptr
  store i64 0, ptr %p11584, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone2996
bb_rcgdone2996:
  br label %bb_rcslotdone2965
bb_rcslotdone2965:
  %v11585 = load i64, ptr %slot67, align 8
  %p11586 = inttoptr i64 %v11585 to ptr
  %ld11587 = load i64, ptr %p11586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11587, ptr %slot2095, align 8
  %v11588 = load i64, ptr %slot67, align 8
  %p11589 = inttoptr i64 %v11588 to ptr
  %ld11590 = load i64, ptr %p11589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11590, ptr %slot2096, align 8
  %v11591 = load i64, ptr %slot96, align 8
  %p11592 = inttoptr i64 %v11591 to ptr
  %v11593 = load i64, ptr %slot2096, align 8
  %p11594 = inttoptr i64 %v11593 to ptr
  %call11595 = call ptr @myl_native_bytes_encode(ptr %p11592, ptr %p11594) nomerge, !dbg !226
  %calladdr11596 = ptrtoint ptr %call11595 to i64
  store i64 %calladdr11596, ptr %slot2097, align 8
  %v11597 = load i64, ptr %slot2097, align 8
  %cond11598 = icmp ne i64 %v11597, 0
  br i1 %cond11598, label %bb_success3004, label %bb_failed3004
bb_failed3004:
  %v11599 = load i64, ptr %slot1, align 8
  %p11600 = inttoptr i64 %v11599 to ptr
  call void @myl_qbe_fail_allocation(ptr %p11600) nomerge, !dbg !226
  unreachable
bb_success3004:
  %v11601 = load i64, ptr %slot2097, align 8
  %v11602 = load i64, ptr %slot69, align 8
  %p11603 = inttoptr i64 %v11602 to ptr
  store i64 %v11601, ptr %p11603, align 8, !alias.scope !3, !noalias !4
  %v11604 = load i64, ptr %slot69, align 8
  %p11605 = inttoptr i64 %v11604 to ptr
  %ld11606 = load i64, ptr %p11605, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11606, ptr %slot2098, align 8
  %v11607 = load i64, ptr %slot2098, align 8
  %v11608 = load i64, ptr %slot40, align 8
  %p11609 = inttoptr i64 %v11608 to ptr
  store i64 %v11607, ptr %p11609, align 8, !alias.scope !3, !noalias !4
  %v11610 = load i64, ptr %slot40, align 8
  store i64 %v11610, ptr %slot2099, align 8
  %v11611 = load i64, ptr %slot41, align 8
  store i64 %v11611, ptr %slot2100, align 8
  %v11612 = load i64, ptr %slot2099, align 8
  %v11613 = load i64, ptr %slot2100, align 8
  %p11614 = inttoptr i64 %v11612 to ptr
  %p11615 = inttoptr i64 %v11613 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11615, ptr %p11614, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11616 = load i64, ptr %slot35, align 8
  %p11617 = inttoptr i64 %v11616 to ptr
  store i32 2, ptr %p11617, align 4, !alias.scope !3, !noalias !4
  %v11618 = load i64, ptr %slot34, align 8
  %p11619 = inttoptr i64 %v11618 to ptr
  store i32 1, ptr %p11619, align 4, !alias.scope !3, !noalias !4
  %v11620 = load i64, ptr %slot37, align 8
  store i64 %v11620, ptr %slot2101, align 8
  %v11621 = load i64, ptr %slot41, align 8
  store i64 %v11621, ptr %slot2102, align 8
  %v11622 = load i64, ptr %slot2102, align 8
  %v11623 = load i64, ptr %slot2101, align 8
  %p11624 = inttoptr i64 %v11622 to ptr
  %p11625 = inttoptr i64 %v11623 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11625, ptr %p11624, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v11626 = load i64, ptr %slot29, align 8
  %p11627 = inttoptr i64 %v11626 to ptr
  store i32 2, ptr %p11627, align 4, !alias.scope !3, !noalias !4
  %v11628 = load i64, ptr %slot35, align 8
  %p11629 = inttoptr i64 %v11628 to ptr
  %ld11630 = load i32, ptr %p11629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11630, ptr %slot2103, align 8
  %v11631 = load i32, ptr %slot2103, align 8
  %v11632 = load i64, ptr %slot29, align 8
  %p11633 = inttoptr i64 %v11632 to ptr
  store i32 %v11631, ptr %p11633, align 4, !alias.scope !3, !noalias !4
  %v11634 = load i64, ptr %slot34, align 8
  %p11635 = inttoptr i64 %v11634 to ptr
  store i32 0, ptr %p11635, align 4, !alias.scope !3, !noalias !4
  %v11636 = load i64, ptr %slot28, align 8
  %p11637 = inttoptr i64 %v11636 to ptr
  store i32 1, ptr %p11637, align 4, !alias.scope !3, !noalias !4
  %v11638 = load i64, ptr %slot2101, align 8
  %p11639 = inttoptr i64 %v11638 to ptr
  %ld11640 = load i64, ptr %p11639, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11640, ptr %slot2104, align 8
  %v11641 = load i64, ptr %slot2104, align 8
  %v11642 = load i64, ptr %slot69, align 8
  %p11643 = inttoptr i64 %v11642 to ptr
  store i64 %v11641, ptr %p11643, align 8, !alias.scope !3, !noalias !4
  %v11644 = load i64, ptr %slot49, align 8
  %p11645 = inttoptr i64 %v11644 to ptr
  %ld11646 = load i64, ptr %p11645, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11646, ptr %slot2105, align 8
  %v11647 = load i64, ptr %slot2105, align 8
  %v11648 = load i64, ptr %slot70, align 8
  %p11649 = inttoptr i64 %v11648 to ptr
  store i64 %v11647, ptr %p11649, align 8, !alias.scope !3, !noalias !4
  %v11650 = load i64, ptr %slot69, align 8
  %p11651 = inttoptr i64 %v11650 to ptr
  %ld11652 = load i64, ptr %p11651, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11652, ptr %slot2106, align 8
  %v11653 = load i64, ptr %slot70, align 8
  %p11654 = inttoptr i64 %v11653 to ptr
  %ld11655 = load i64, ptr %p11654, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11655, ptr %slot2107, align 8
  %v11656 = load i64, ptr %slot1, align 8
  %v11657 = load i64, ptr %slot2106, align 8
  %v11658 = load i64, ptr %slot2107, align 8
  %call11659 = call { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64 %v11656, i64 %v11657, i64 %v11658) nomerge, !dbg !228
  store { i64, i64 } %call11659, ptr %callresult2109, align 8
  %addr11660 = ptrtoint ptr %callresult2109 to i64
  store i64 %addr11660, ptr %slot2108, align 8
  %v11661 = load i64, ptr %slot2108, align 8
  %v11662 = load i64, ptr %slot69, align 8
  %p11663 = inttoptr i64 %v11662 to ptr
  store i64 %v11661, ptr %p11663, align 8, !alias.scope !3, !noalias !4
  %v11664 = load i64, ptr %slot69, align 8
  %p11665 = inttoptr i64 %v11664 to ptr
  %ld11666 = load i64, ptr %p11665, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11666, ptr %slot2110, align 8
  %v11667 = load i64, ptr %slot41, align 8
  store i64 %v11667, ptr %slot2111, align 8
  %v11668 = load i64, ptr %slot96, align 8
  %v11669 = load i64, ptr %slot2111, align 8
  %v11670 = load i64, ptr %slot2110, align 8
  %call11671 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64 %v11668, i64 %v11669, i64 %v11670) nomerge, !dbg !228
  store i32 %call11671, ptr %slot2112, align 8
  %v11672 = load i32, ptr %slot2112, align 8
  %cv11673 = zext i32 %v11672 to i64
  %cond11674 = icmp ne i64 %cv11673, 0
  br i1 %cond11674, label %bb_rcsuccess3026, label %bb_rcfailure3026
bb_rcfailure3026:
  %v11675 = load i64, ptr %slot96, align 8
  %p11676 = inttoptr i64 %v11675 to ptr
  %call11677 = call i32 @myl_rc_take_failure(ptr %p11676) nomerge, !dbg !228
  store i32 %call11677, ptr %slot2113, align 8
  %v11678 = load i64, ptr %slot1, align 8
  %p11679 = inttoptr i64 %v11678 to ptr
  %v11680 = load i32, ptr %slot2113, align 8
  %call11681 = call i32 @myl_qbe_rc_status(ptr %p11679, i32 %v11680) nomerge, !dbg !228
  store i32 %call11681, ptr %slot2114, align 8
  br label %bb_failure
bb_rcsuccess3026:
  %v11682 = load i64, ptr %slot35, align 8
  %p11683 = inttoptr i64 %v11682 to ptr
  store i32 2, ptr %p11683, align 4, !alias.scope !3, !noalias !4
  %v11684 = load i64, ptr %slot35, align 8
  %p11685 = inttoptr i64 %v11684 to ptr
  store i32 16, ptr %p11685, align 4, !alias.scope !3, !noalias !4
  %v11686 = load i64, ptr %slot34, align 8
  %p11687 = inttoptr i64 %v11686 to ptr
  store i32 1, ptr %p11687, align 4, !alias.scope !3, !noalias !4
  %v11688 = load i64, ptr %slot28, align 8
  %p11689 = inttoptr i64 %v11688 to ptr
  %ld11690 = load i32, ptr %p11689, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11690, ptr %slot2115, align 8
  %v11691 = load i32, ptr %slot2115, align 8
  %cv11692 = zext i32 %v11691 to i64
  %cond11693 = icmp ne i64 %cv11692, 0
  br i1 %cond11693, label %bb_rcslotdrop3034, label %bb_rcslotdone3034
bb_rcslotdrop3034:
  %v11694 = load i64, ptr %slot28, align 8
  %p11695 = inttoptr i64 %v11694 to ptr
  store i32 0, ptr %p11695, align 4, !alias.scope !3, !noalias !4
  %v11696 = load i64, ptr %slot37, align 8
  store i64 %v11696, ptr %slot2116, align 8
  %v11697 = load i64, ptr %slot29, align 8
  %p11698 = inttoptr i64 %v11697 to ptr
  %ld11699 = load i32, ptr %p11698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11699, ptr %slot2117, align 8
  %v11700 = load i32, ptr %slot2117, align 8
  %op11701 = and i32 %v11700, 28
  store i32 %op11701, ptr %slot2118, align 8
  %v11702 = load i32, ptr %slot2118, align 8
  %cv11703 = zext i32 %v11702 to i64
  %cond11704 = icmp ne i64 %cv11703, 0
  br i1 %cond11704, label %bb_rcslotrole3034, label %bb_rcslotowner3034
bb_rcslotrole3034:
  %v11705 = load i64, ptr %slot96, align 8
  store i64 %v11705, ptr %slot2119, align 8
  %v11706 = load i64, ptr %slot2116, align 8
  %p11707 = inttoptr i64 %v11706 to ptr
  %ld11708 = load i64, ptr %p11707, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11708, ptr %slot2120, align 8
  %v11709 = load i64, ptr %slot2120, align 8
  %cmp11710 = icmp ne i64 %v11709, 0
  %cv11711 = zext i1 %cmp11710 to i32
  store i32 %cv11711, ptr %slot2121, align 8
  %v11712 = load i32, ptr %slot2121, align 8
  %cv11713 = zext i32 %v11712 to i64
  %cond11714 = icmp ne i64 %cv11713, 0
  br i1 %cond11714, label %bb_rcgnn3050, label %bb_rcgdone3050
bb_rcgnn3050:
  %v11715 = load i64, ptr %slot2120, align 8
  %op11716 = sub i64 %v11715, 16
  store i64 %op11716, ptr %slot2122, align 8
  %v11717 = load i64, ptr %slot2120, align 8
  %p11718 = inttoptr i64 %v11717 to ptr
  %rgep11719 = getelementptr i8, ptr %p11718, i64 -16
  %ld11720 = load i64, ptr %rgep11719, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11720, ptr %slot2123, align 8
  %v11721 = load i64, ptr %slot2123, align 8
  %op11722 = and i64 %v11721, 4611686018427387906
  store i64 %op11722, ptr %slot2124, align 8
  %v11723 = load i64, ptr %slot2124, align 8
  %cmp11724 = icmp ne i64 %v11723, 0
  %cv11725 = zext i1 %cmp11724 to i32
  store i32 %cv11725, ptr %slot2125, align 8
  %v11726 = load i32, ptr %slot2125, align 8
  %cv11727 = zext i32 %v11726 to i64
  %cond11728 = icmp ne i64 %cv11727, 0
  br i1 %cond11728, label %bb_rcgclear3050, label %bb_rcgcounted3050
bb_rcgcounted3050:
  %v11729 = load i64, ptr %slot2120, align 8
  %op11730 = sub i64 %v11729, 24
  store i64 %op11730, ptr %slot2126, align 8
  %v11731 = load i64, ptr %slot2120, align 8
  %p11732 = inttoptr i64 %v11731 to ptr
  %rgep11733 = getelementptr i8, ptr %p11732, i64 -24
  %ld11734 = load i64, ptr %rgep11733, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11734, ptr %slot2127, align 8
  %v11735 = load i64, ptr %slot2127, align 8
  %op11736 = sub i64 %v11735, 1
  store i64 %op11736, ptr %slot2128, align 8
  %v11737 = load i64, ptr %slot2128, align 8
  %cmp11738 = icmp eq i64 %v11737, 0
  %cv11739 = zext i1 %cmp11738 to i32
  store i32 %cv11739, ptr %slot2129, align 8
  %v11740 = load i32, ptr %slot2129, align 8
  %cv11741 = zext i32 %v11740 to i64
  %cond11742 = icmp ne i64 %cv11741, 0
  br i1 %cond11742, label %bb_rcglast3050, label %bb_rcgdec3050
bb_rcglast3050:
  %v11743 = load i64, ptr %slot2120, align 8
  %op11744 = sub i64 %v11743, 32
  store i64 %op11744, ptr %slot2130, align 8
  %v11745 = load i64, ptr %slot2120, align 8
  %p11746 = inttoptr i64 %v11745 to ptr
  %rgep11747 = getelementptr i8, ptr %p11746, i64 -32
  %ld11748 = load i64, ptr %rgep11747, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11748, ptr %slot2131, align 8
  %v11749 = load i64, ptr %slot2131, align 8
  %cmp11750 = icmp ne i64 %v11749, 0
  %cv11751 = zext i1 %cmp11750 to i32
  store i32 %cv11751, ptr %slot2132, align 8
  %v11752 = load i32, ptr %slot2132, align 8
  %cv11753 = zext i32 %v11752 to i64
  %cond11754 = icmp ne i64 %cv11753, 0
  br i1 %cond11754, label %bb_rcgdec3050, label %bb_rcgslow3050
bb_rcgslow3050:
  %v11755 = load i64, ptr %slot2119, align 8
  %v11756 = load i64, ptr %slot2116, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v11755, i64 %v11756) nomerge, !dbg !228
  br label %bb_rcgdone3050
bb_rcgdec3050:
  %v11757 = load i64, ptr %slot2128, align 8
  %v11758 = load i64, ptr %slot2120, align 8
  %p11759 = inttoptr i64 %v11758 to ptr
  %rgep11760 = getelementptr i8, ptr %p11759, i64 -24
  store i64 %v11757, ptr %rgep11760, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3050
bb_rcgclear3050:
  %v11761 = load i64, ptr %slot2116, align 8
  %p11762 = inttoptr i64 %v11761 to ptr
  store i64 0, ptr %p11762, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3050
bb_rcgdone3050:
  br label %bb_rcslotdone3034
bb_rcslotowner3034:
  %v11763 = load i64, ptr %slot96, align 8
  store i64 %v11763, ptr %slot2133, align 8
  %v11764 = load i64, ptr %slot2116, align 8
  %p11765 = inttoptr i64 %v11764 to ptr
  %ld11766 = load i64, ptr %p11765, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11766, ptr %slot2134, align 8
  %v11767 = load i64, ptr %slot2134, align 8
  %cmp11768 = icmp ne i64 %v11767, 0
  %cv11769 = zext i1 %cmp11768 to i32
  store i32 %cv11769, ptr %slot2135, align 8
  %v11770 = load i32, ptr %slot2135, align 8
  %cv11771 = zext i32 %v11770 to i64
  %cond11772 = icmp ne i64 %cv11771, 0
  br i1 %cond11772, label %bb_rcgnn3065, label %bb_rcgdone3065
bb_rcgnn3065:
  %v11773 = load i64, ptr %slot2134, align 8
  %op11774 = sub i64 %v11773, 16
  store i64 %op11774, ptr %slot2136, align 8
  %v11775 = load i64, ptr %slot2134, align 8
  %p11776 = inttoptr i64 %v11775 to ptr
  %rgep11777 = getelementptr i8, ptr %p11776, i64 -16
  %ld11778 = load i64, ptr %rgep11777, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11778, ptr %slot2137, align 8
  %v11779 = load i64, ptr %slot2137, align 8
  %op11780 = and i64 %v11779, 4611686018427387906
  store i64 %op11780, ptr %slot2138, align 8
  %v11781 = load i64, ptr %slot2138, align 8
  %cmp11782 = icmp ne i64 %v11781, 0
  %cv11783 = zext i1 %cmp11782 to i32
  store i32 %cv11783, ptr %slot2139, align 8
  %v11784 = load i32, ptr %slot2139, align 8
  %cv11785 = zext i32 %v11784 to i64
  %cond11786 = icmp ne i64 %cv11785, 0
  br i1 %cond11786, label %bb_rcgclear3065, label %bb_rcgcounted3065
bb_rcgcounted3065:
  %v11787 = load i64, ptr %slot2134, align 8
  %op11788 = sub i64 %v11787, 32
  store i64 %op11788, ptr %slot2140, align 8
  %v11789 = load i64, ptr %slot2134, align 8
  %p11790 = inttoptr i64 %v11789 to ptr
  %rgep11791 = getelementptr i8, ptr %p11790, i64 -32
  %ld11792 = load i64, ptr %rgep11791, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11792, ptr %slot2141, align 8
  %v11793 = load i64, ptr %slot2141, align 8
  %op11794 = sub i64 %v11793, 1
  store i64 %op11794, ptr %slot2142, align 8
  %v11795 = load i64, ptr %slot2142, align 8
  %cmp11796 = icmp eq i64 %v11795, 0
  %cv11797 = zext i1 %cmp11796 to i32
  store i32 %cv11797, ptr %slot2143, align 8
  %v11798 = load i32, ptr %slot2143, align 8
  %cv11799 = zext i32 %v11798 to i64
  %cond11800 = icmp ne i64 %cv11799, 0
  br i1 %cond11800, label %bb_rcglast3065, label %bb_rcgdec3065
bb_rcglast3065:
  %v11801 = load i64, ptr %slot2134, align 8
  %op11802 = sub i64 %v11801, 24
  store i64 %op11802, ptr %slot2144, align 8
  %v11803 = load i64, ptr %slot2134, align 8
  %p11804 = inttoptr i64 %v11803 to ptr
  %rgep11805 = getelementptr i8, ptr %p11804, i64 -24
  %ld11806 = load i64, ptr %rgep11805, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11806, ptr %slot2145, align 8
  %v11807 = load i64, ptr %slot2145, align 8
  %cmp11808 = icmp ne i64 %v11807, 0
  %cv11809 = zext i1 %cmp11808 to i32
  store i32 %cv11809, ptr %slot2146, align 8
  %v11810 = load i32, ptr %slot2146, align 8
  %cv11811 = zext i32 %v11810 to i64
  %cond11812 = icmp ne i64 %cv11811, 0
  br i1 %cond11812, label %bb_rcgdec3065, label %bb_rcgslow3065
bb_rcgslow3065:
  %v11813 = load i64, ptr %slot2133, align 8
  %v11814 = load i64, ptr %slot2116, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v11813, i64 %v11814) nomerge, !dbg !228
  br label %bb_rcgdone3065
bb_rcgdec3065:
  %v11815 = load i64, ptr %slot2142, align 8
  %v11816 = load i64, ptr %slot2134, align 8
  %p11817 = inttoptr i64 %v11816 to ptr
  %rgep11818 = getelementptr i8, ptr %p11817, i64 -32
  store i64 %v11815, ptr %rgep11818, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3065
bb_rcgclear3065:
  %v11819 = load i64, ptr %slot2116, align 8
  %p11820 = inttoptr i64 %v11819 to ptr
  store i64 0, ptr %p11820, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3065
bb_rcgdone3065:
  br label %bb_rcslotdone3034
bb_rcslotdone3034:
  %v11821 = load i64, ptr %slot37, align 8
  store i64 %v11821, ptr %slot2147, align 8
  %v11822 = load i64, ptr %slot41, align 8
  store i64 %v11822, ptr %slot2148, align 8
  %v11823 = load i64, ptr %slot2148, align 8
  %v11824 = load i64, ptr %slot2147, align 8
  %p11825 = inttoptr i64 %v11823 to ptr
  %p11826 = inttoptr i64 %v11824 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11826, ptr %p11825, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v11827 = load i64, ptr %slot29, align 8
  %p11828 = inttoptr i64 %v11827 to ptr
  store i32 2, ptr %p11828, align 4, !alias.scope !3, !noalias !4
  %v11829 = load i64, ptr %slot35, align 8
  %p11830 = inttoptr i64 %v11829 to ptr
  %ld11831 = load i32, ptr %p11830, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11831, ptr %slot2149, align 8
  %v11832 = load i32, ptr %slot2149, align 8
  %v11833 = load i64, ptr %slot29, align 8
  %p11834 = inttoptr i64 %v11833 to ptr
  store i32 %v11832, ptr %p11834, align 4, !alias.scope !3, !noalias !4
  %v11835 = load i64, ptr %slot34, align 8
  %p11836 = inttoptr i64 %v11835 to ptr
  store i32 0, ptr %p11836, align 4, !alias.scope !3, !noalias !4
  %v11837 = load i64, ptr %slot28, align 8
  %p11838 = inttoptr i64 %v11837 to ptr
  store i32 1, ptr %p11838, align 4, !alias.scope !3, !noalias !4
  %v11839 = load i64, ptr %slot2147, align 8
  %v11840 = load i64, ptr %slot69, align 8
  %p11841 = inttoptr i64 %v11840 to ptr
  store i64 %v11839, ptr %p11841, align 8, !alias.scope !3, !noalias !4
  %v11842 = load i64, ptr %slot88, align 8
  store i64 %v11842, ptr %slot2150, align 8
  %v11843 = load i64, ptr %slot2150, align 8
  %p11844 = inttoptr i64 %v11843 to ptr
  store i64 0, ptr %p11844, align 8, !alias.scope !3, !noalias !4
  %v11845 = load i64, ptr %slot2150, align 8
  %p11847 = inttoptr i64 %v11845 to ptr
  %gep11848 = getelementptr i8, ptr %p11847, i64 8
  %op11846 = ptrtoint ptr %gep11848 to i64
  store i64 %op11846, ptr %slot2151, align 8
  %v11849 = load i64, ptr %slot2151, align 8
  %p11850 = inttoptr i64 %v11849 to ptr
  store i64 0, ptr %p11850, align 8, !alias.scope !3, !noalias !4
  %v11851 = load i64, ptr %slot2150, align 8
  %p11853 = inttoptr i64 %v11851 to ptr
  %gep11854 = getelementptr i8, ptr %p11853, i64 16
  %op11852 = ptrtoint ptr %gep11854 to i64
  store i64 %op11852, ptr %slot2152, align 8
  %v11855 = load i64, ptr %slot2152, align 8
  %p11856 = inttoptr i64 %v11855 to ptr
  store i64 0, ptr %p11856, align 8, !alias.scope !3, !noalias !4
  %v11857 = load i64, ptr %slot2150, align 8
  %p11858 = inttoptr i64 %v11857 to ptr
  store i32 1, ptr %p11858, align 4, !alias.scope !3, !noalias !4
  %v11859 = load i64, ptr %slot36, align 8
  %p11860 = inttoptr i64 %v11859 to ptr
  store i32 1, ptr %p11860, align 4, !alias.scope !3, !noalias !4
  %v11861 = load i64, ptr %slot69, align 8
  %p11862 = inttoptr i64 %v11861 to ptr
  %ld11863 = load i64, ptr %p11862, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11863, ptr %slot2153, align 8
  %v11864 = load i64, ptr %slot2150, align 8
  %p11866 = inttoptr i64 %v11864 to ptr
  %gep11867 = getelementptr i8, ptr %p11866, i64 8
  %op11865 = ptrtoint ptr %gep11867 to i64
  store i64 %op11865, ptr %slot2154, align 8
  %v11868 = load i64, ptr %slot97, align 8
  store i64 %v11868, ptr %slot2155, align 8
  %v11869 = load i64, ptr %slot69, align 8
  %p11870 = inttoptr i64 %v11869 to ptr
  %ld11871 = load i64, ptr %p11870, align 8, !alias.scope !3, !noalias !4
  store i64 %ld11871, ptr %slot2156, align 8
  %v11872 = load i64, ptr %slot28, align 8
  %p11873 = inttoptr i64 %v11872 to ptr
  %ld11874 = load i32, ptr %p11873, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11874, ptr %slot2157, align 8
  %v11875 = load i64, ptr %slot29, align 8
  %p11876 = inttoptr i64 %v11875 to ptr
  %ld11877 = load i32, ptr %p11876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11877, ptr %slot2158, align 8
  %v11878 = load i32, ptr %slot2158, align 8
  %op11879 = and i32 %v11878, 24
  store i32 %op11879, ptr %slot2158, align 8
  %v11880 = load i32, ptr %slot2158, align 8
  %cmp11881 = icmp eq i32 %v11880, 0
  %cv11882 = zext i1 %cmp11881 to i32
  store i32 %cv11882, ptr %slot2159, align 8
  %v11883 = load i32, ptr %slot2157, align 8
  %v11884 = load i32, ptr %slot2159, align 8
  %op11885 = and i32 %v11883, %v11884
  store i32 %op11885, ptr %slot2160, align 8
  %v11886 = load i32, ptr %slot2160, align 8
  %cv11887 = zext i32 %v11886 to i64
  %cond11888 = icmp ne i64 %cv11887, 0
  br i1 %cond11888, label %bb_rctake3086, label %bb_rccopy3086
bb_rctake3086:
  %v11889 = load i64, ptr %slot41, align 8
  store i64 %v11889, ptr %slot2161, align 8
  %v11890 = load i64, ptr %slot97, align 8
  store i64 %v11890, ptr %slot2162, align 8
  %v11891 = load i64, ptr %slot2156, align 8
  %v11892 = load i64, ptr %slot2161, align 8
  %op11893 = sub i64 %v11891, %v11892
  store i64 %op11893, ptr %slot2163, align 8
  %v11894 = load i64, ptr %slot2161, align 8
  %v11895 = load i64, ptr %slot2156, align 8
  %op11896 = sub i64 %v11894, %v11895
  store i64 %op11896, ptr %slot2164, align 8
  %v11897 = load i64, ptr %slot2163, align 8
  %cmp11898 = icmp ult i64 %v11897, 16
  %cv11899 = zext i1 %cmp11898 to i32
  store i32 %cv11899, ptr %slot2165, align 8
  %v11900 = load i64, ptr %slot2164, align 8
  %cmp11901 = icmp ult i64 %v11900, 16
  %cv11902 = zext i1 %cmp11901 to i32
  store i32 %cv11902, ptr %slot2166, align 8
  %v11903 = load i32, ptr %slot2165, align 8
  %v11904 = load i32, ptr %slot2166, align 8
  %op11905 = or i32 %v11903, %v11904
  store i32 %op11905, ptr %slot2167, align 8
  %v11906 = load i32, ptr %slot2167, align 8
  %cv11907 = zext i32 %v11906 to i64
  %cond11908 = icmp ne i64 %cv11907, 0
  br i1 %cond11908, label %bb_rcmoveslow3095, label %bb_rcmovecheck3095
bb_rcmovecheck3095:
  %v11909 = load i64, ptr %slot2156, align 8
  %op11910 = add i64 %v11909, 0
  store i64 %op11910, ptr %slot2168, align 8
  %v11911 = load i64, ptr %slot2168, align 8
  %p11912 = inttoptr i64 %v11911 to ptr
  %ld11913 = load i64, ptr %p11912, align 8
  store i64 %ld11913, ptr %slot2169, align 8
  %v11914 = load i64, ptr %slot2169, align 8
  %cmp11915 = icmp ne i64 %v11914, 0
  %cv11916 = zext i1 %cmp11915 to i32
  store i32 %cv11916, ptr %slot2170, align 8
  %v11917 = load i32, ptr %slot2170, align 8
  %cv11918 = zext i32 %v11917 to i64
  %cond11919 = icmp ne i64 %cv11918, 0
  br i1 %cond11919, label %bb_rcmoveheader3103, label %bb_rcmovenext3103
bb_rcmoveheader3103:
  %v11920 = load i64, ptr %slot2169, align 8
  %op11921 = sub i64 %v11920, 16
  store i64 %op11921, ptr %slot2171, align 8
  %v11922 = load i64, ptr %slot2169, align 8
  %p11923 = inttoptr i64 %v11922 to ptr
  %rgep11924 = getelementptr i8, ptr %p11923, i64 -16
  %ld11925 = load i64, ptr %rgep11924, align 8, !alias.scope !9, !noalias !10
  store i64 %ld11925, ptr %slot2172, align 8
  %v11926 = load i64, ptr %slot2172, align 8
  %op11927 = and i64 %v11926, 5764607523034234881
  store i64 %op11927, ptr %slot2173, align 8
  %v11928 = load i64, ptr %slot2173, align 8
  %cmp11929 = icmp ne i64 %v11928, 0
  %cv11930 = zext i1 %cmp11929 to i32
  store i32 %cv11930, ptr %slot2174, align 8
  %v11931 = load i32, ptr %slot2174, align 8
  %cv11932 = zext i32 %v11931 to i64
  %cond11933 = icmp ne i64 %cv11932, 0
  br i1 %cond11933, label %bb_rcmoveslow3095, label %bb_rcmovenext3103
bb_rcmovenext3103:
  %v11934 = load i64, ptr %slot2156, align 8
  %v11935 = load i64, ptr %slot2161, align 8
  %p11936 = inttoptr i64 %v11934 to ptr
  %p11937 = inttoptr i64 %v11935 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p11937, ptr %p11936, i64 16, i1 false)
  %v11938 = load i64, ptr %slot2156, align 8
  %p11939 = inttoptr i64 %v11938 to ptr
  store i64 0, ptr %p11939, align 8
  %v11940 = load i64, ptr %slot2156, align 8
  %op11941 = add i64 %v11940, 8
  store i64 %op11941, ptr %slot2175, align 8
  %v11942 = load i64, ptr %slot2175, align 8
  %p11943 = inttoptr i64 %v11942 to ptr
  store i64 0, ptr %p11943, align 8
  br label %bb_rcmoved3095
bb_rcmoveslow3095:
  %v11944 = load i64, ptr %slot96, align 8
  %v11945 = load i64, ptr %slot2161, align 8
  %v11946 = load i64, ptr %slot2156, align 8
  %v11947 = load i64, ptr %slot2162, align 8
  %cv11948 = trunc i64 %v11947 to i32
  %call11949 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v11944, i64 %v11945, i64 %v11946, i32 %cv11948) nomerge, !dbg !230
  store i32 %call11949, ptr %slot2176, align 8
  %v11950 = load i32, ptr %slot2176, align 8
  %cv11951 = zext i32 %v11950 to i64
  %cond11952 = icmp ne i64 %cv11951, 0
  br i1 %cond11952, label %bb_rcsuccess3111, label %bb_rcfailure3111
bb_rcfailure3111:
  %v11953 = load i64, ptr %slot96, align 8
  %p11954 = inttoptr i64 %v11953 to ptr
  %call11955 = call i32 @myl_rc_take_failure(ptr %p11954) nomerge, !dbg !230
  store i32 %call11955, ptr %slot2177, align 8
  %v11956 = load i64, ptr %slot1, align 8
  %p11957 = inttoptr i64 %v11956 to ptr
  %v11958 = load i32, ptr %slot2177, align 8
  %call11959 = call i32 @myl_qbe_rc_status(ptr %p11957, i32 %v11958) nomerge, !dbg !230
  store i32 %call11959, ptr %slot2178, align 8
  br label %bb_failure
bb_rcsuccess3111:
  br label %bb_rcmoved3095
bb_rcmoved3095:
  %v11960 = load i64, ptr %slot28, align 8
  %p11961 = inttoptr i64 %v11960 to ptr
  store i32 0, ptr %p11961, align 4, !alias.scope !3, !noalias !4
  %v11962 = load i64, ptr %slot35, align 8
  %p11963 = inttoptr i64 %v11962 to ptr
  store i32 2, ptr %p11963, align 4, !alias.scope !3, !noalias !4
  %v11964 = load i64, ptr %slot34, align 8
  %p11965 = inttoptr i64 %v11964 to ptr
  store i32 1, ptr %p11965, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared3086
bb_rccopy3086:
  %v11966 = load i64, ptr %slot41, align 8
  store i64 %v11966, ptr %slot2179, align 8
  %v11967 = load i64, ptr %slot97, align 8
  store i64 %v11967, ptr %slot2180, align 8
  %v11968 = load i64, ptr %slot96, align 8
  %v11969 = load i64, ptr %slot2179, align 8
  %v11970 = load i64, ptr %slot2156, align 8
  %v11971 = load i64, ptr %slot2180, align 8
  %cv11972 = trunc i64 %v11971 to i32
  %call11973 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v11968, i64 %v11969, i64 %v11970, i32 %cv11972) nomerge, !dbg !230
  store i32 %call11973, ptr %slot2181, align 8
  %v11974 = load i32, ptr %slot2181, align 8
  %cv11975 = zext i32 %v11974 to i64
  %cond11976 = icmp ne i64 %cv11975, 0
  br i1 %cond11976, label %bb_rcsuccess3120, label %bb_rcfailure3120
bb_rcfailure3120:
  %v11977 = load i64, ptr %slot96, align 8
  %p11978 = inttoptr i64 %v11977 to ptr
  %call11979 = call i32 @myl_rc_take_failure(ptr %p11978) nomerge, !dbg !230
  store i32 %call11979, ptr %slot2182, align 8
  %v11980 = load i64, ptr %slot1, align 8
  %p11981 = inttoptr i64 %v11980 to ptr
  %v11982 = load i32, ptr %slot2182, align 8
  %call11983 = call i32 @myl_qbe_rc_status(ptr %p11981, i32 %v11982) nomerge, !dbg !230
  store i32 %call11983, ptr %slot2183, align 8
  br label %bb_failure
bb_rcsuccess3120:
  %v11984 = load i64, ptr %slot35, align 8
  %p11985 = inttoptr i64 %v11984 to ptr
  store i32 2, ptr %p11985, align 4, !alias.scope !3, !noalias !4
  %v11986 = load i64, ptr %slot34, align 8
  %p11987 = inttoptr i64 %v11986 to ptr
  store i32 1, ptr %p11987, align 4, !alias.scope !3, !noalias !4
  %v11988 = load i64, ptr %slot28, align 8
  %p11989 = inttoptr i64 %v11988 to ptr
  %ld11990 = load i32, ptr %p11989, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11990, ptr %slot2184, align 8
  %v11991 = load i32, ptr %slot2184, align 8
  %cv11992 = zext i32 %v11991 to i64
  %cond11993 = icmp ne i64 %cv11992, 0
  br i1 %cond11993, label %bb_rcslotdrop3127, label %bb_rcslotdone3127
bb_rcslotdrop3127:
  %v11994 = load i64, ptr %slot28, align 8
  %p11995 = inttoptr i64 %v11994 to ptr
  store i32 0, ptr %p11995, align 4, !alias.scope !3, !noalias !4
  %v11996 = load i64, ptr %slot37, align 8
  store i64 %v11996, ptr %slot2185, align 8
  %v11997 = load i64, ptr %slot29, align 8
  %p11998 = inttoptr i64 %v11997 to ptr
  %ld11999 = load i32, ptr %p11998, align 4, !alias.scope !3, !noalias !4
  store i32 %ld11999, ptr %slot2186, align 8
  %v12000 = load i32, ptr %slot2186, align 8
  %op12001 = and i32 %v12000, 28
  store i32 %op12001, ptr %slot2187, align 8
  %v12002 = load i32, ptr %slot2187, align 8
  %cv12003 = zext i32 %v12002 to i64
  %cond12004 = icmp ne i64 %cv12003, 0
  br i1 %cond12004, label %bb_rcslotrole3127, label %bb_rcslotowner3127
bb_rcslotrole3127:
  %v12005 = load i64, ptr %slot96, align 8
  store i64 %v12005, ptr %slot2188, align 8
  %v12006 = load i64, ptr %slot2188, align 8
  %v12007 = load i64, ptr %slot2185, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v12006, i64 %v12007) nomerge, !dbg !230
  br label %bb_rcslotdone3127
bb_rcslotowner3127:
  %v12008 = load i64, ptr %slot96, align 8
  store i64 %v12008, ptr %slot2189, align 8
  %v12009 = load i64, ptr %slot2189, align 8
  %v12010 = load i64, ptr %slot2185, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v12009, i64 %v12010) nomerge, !dbg !230
  br label %bb_rcslotdone3127
bb_rcslotdone3127:
  br label %bb_rcprepared3086
bb_rcprepared3086:
  %v12011 = load i64, ptr %slot41, align 8
  store i64 %v12011, ptr %slot2190, align 8
  %v12012 = load i64, ptr %slot2190, align 8
  %v12013 = load i64, ptr %slot2154, align 8
  %p12014 = inttoptr i64 %v12012 to ptr
  %p12015 = inttoptr i64 %v12013 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12015, ptr %p12014, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v12016 = load i64, ptr %slot34, align 8
  %p12017 = inttoptr i64 %v12016 to ptr
  store i32 0, ptr %p12017, align 4, !alias.scope !3, !noalias !4
  %v12018 = load i64, ptr %slot2150, align 8
  %v12019 = load i64, ptr %slot69, align 8
  %p12020 = inttoptr i64 %v12019 to ptr
  store i64 %v12018, ptr %p12020, align 8, !alias.scope !3, !noalias !4
  %p12021 = inttoptr i64 ptrtoint (ptr @myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p12021, i64 214) "call-inline-cost"="0", !dbg !230
  %v12022 = load i64, ptr %slot69, align 8
  %p12023 = inttoptr i64 %v12022 to ptr
  %ld12024 = load i64, ptr %p12023, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12024, ptr %slot2191, align 8
  %v12025 = load i64, ptr %slot37, align 8
  store i64 %v12025, ptr %slot2192, align 8
  %v12026 = load i64, ptr %slot2191, align 8
  %v12027 = load i64, ptr %slot2192, align 8
  %p12028 = inttoptr i64 %v12026 to ptr
  %p12029 = inttoptr i64 %v12027 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12029, ptr %p12028, i64 24, i1 false)
  %v12030 = load i64, ptr %slot29, align 8
  %p12031 = inttoptr i64 %v12030 to ptr
  store i32 2, ptr %p12031, align 4, !alias.scope !3, !noalias !4
  %v12032 = load i64, ptr %slot28, align 8
  %p12033 = inttoptr i64 %v12032 to ptr
  store i32 1, ptr %p12033, align 4, !alias.scope !3, !noalias !4
  %v12034 = load i64, ptr %slot2192, align 8
  %v12035 = load i64, ptr %slot69, align 8
  %p12036 = inttoptr i64 %v12035 to ptr
  store i64 %v12034, ptr %p12036, align 8, !alias.scope !3, !noalias !4
  %v12037 = load i64, ptr %slot69, align 8
  %p12038 = inttoptr i64 %v12037 to ptr
  %ld12039 = load i64, ptr %p12038, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12039, ptr %slot2193, align 8
  %v12040 = load i64, ptr %slot69, align 8
  %p12041 = inttoptr i64 %v12040 to ptr
  %ld12042 = load i64, ptr %p12041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12042, ptr %slot2194, align 8
  %v12043 = load i64, ptr %slot41, align 8
  store i64 %v12043, ptr %slot2195, align 8
  %v12044 = load i64, ptr %slot97, align 8
  store i64 %v12044, ptr %slot2196, align 8
  %v12045 = load i64, ptr %slot96, align 8
  %v12046 = load i64, ptr %slot2195, align 8
  %v12047 = load i64, ptr %slot2194, align 8
  %v12048 = load i64, ptr %slot2196, align 8
  %cv12049 = trunc i64 %v12048 to i32
  %call12050 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v12045, i64 %v12046, i64 %v12047, i32 %cv12049) nomerge, !dbg !232
  store i32 %call12050, ptr %slot2197, align 8
  %v12051 = load i32, ptr %slot2197, align 8
  %cv12052 = zext i32 %v12051 to i64
  %cond12053 = icmp ne i64 %cv12052, 0
  br i1 %cond12053, label %bb_rcsuccess3145, label %bb_rcfailure3145
bb_rcfailure3145:
  %v12054 = load i64, ptr %slot96, align 8
  %p12055 = inttoptr i64 %v12054 to ptr
  %call12056 = call i32 @myl_rc_take_failure(ptr %p12055) nomerge, !dbg !232
  store i32 %call12056, ptr %slot2198, align 8
  %v12057 = load i64, ptr %slot1, align 8
  %p12058 = inttoptr i64 %v12057 to ptr
  %v12059 = load i32, ptr %slot2198, align 8
  %call12060 = call i32 @myl_qbe_rc_status(ptr %p12058, i32 %v12059) nomerge, !dbg !232
  store i32 %call12060, ptr %slot2199, align 8
  br label %bb_failure
bb_rcsuccess3145:
  %v12061 = load i64, ptr %slot28, align 8
  %p12062 = inttoptr i64 %v12061 to ptr
  store i32 0, ptr %p12062, align 4, !alias.scope !3, !noalias !4
  %v12063 = load i64, ptr %slot35, align 8
  %p12064 = inttoptr i64 %v12063 to ptr
  store i32 2, ptr %p12064, align 4, !alias.scope !3, !noalias !4
  %v12065 = load i64, ptr %slot34, align 8
  %p12066 = inttoptr i64 %v12065 to ptr
  store i32 1, ptr %p12066, align 4, !alias.scope !3, !noalias !4
  %v12067 = load i64, ptr %slot41, align 8
  store i64 %v12067, ptr %slot2200, align 8
  %v12068 = load i64, ptr %slot34, align 8
  %p12069 = inttoptr i64 %v12068 to ptr
  store i32 0, ptr %p12069, align 4, !alias.scope !3, !noalias !4
  %v12070 = load i64, ptr %slot43, align 8
  %p12072 = inttoptr i64 %v12070 to ptr
  %gep12073 = getelementptr i8, ptr %p12072, i64 24
  %op12071 = ptrtoint ptr %gep12073 to i64
  store i64 %op12071, ptr %slot2201, align 8
  %v12074 = load i64, ptr %slot2201, align 8
  %p12075 = inttoptr i64 %v12074 to ptr
  %ld12076 = load i32, ptr %p12075, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12076, ptr %slot2202, align 8
  %v12077 = load i32, ptr %slot2202, align 8
  %cv12078 = zext i32 %v12077 to i64
  %cond12079 = icmp ne i64 %cv12078, 0
  br i1 %cond12079, label %bb_rcscopesopen3155, label %bb_rcscopesclosed3155
bb_rcscopesopen3155:
  %v12080 = load i64, ptr %slot45, align 8
  %p12082 = inttoptr i64 %v12080 to ptr
  %gep12083 = getelementptr i8, ptr %p12082, i64 0
  %op12081 = ptrtoint ptr %gep12083 to i64
  store i64 %op12081, ptr %slot2203, align 8
  %v12084 = load i64, ptr %slot43, align 8
  %v12085 = load i64, ptr %slot2203, align 8
  %p12086 = inttoptr i64 %v12085 to ptr
  store i64 %v12084, ptr %p12086, align 8, !alias.scope !3, !noalias !4
  %v12087 = load i64, ptr %slot1, align 8
  %p12088 = inttoptr i64 %v12087 to ptr
  %v12089 = load i64, ptr %slot45, align 8
  %p12090 = inttoptr i64 %v12089 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p12088, ptr %p12090, i64 1) nomerge, !dbg !232
  br label %bb_rcscopesclosed3155
bb_rcscopesclosed3155:
  %v12091 = load i64, ptr %slot28, align 8
  %p12092 = inttoptr i64 %v12091 to ptr
  %ld12093 = load i32, ptr %p12092, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12093, ptr %slot2204, align 8
  %v12094 = load i32, ptr %slot2204, align 8
  %cv12095 = zext i32 %v12094 to i64
  %cond12096 = icmp ne i64 %cv12095, 0
  br i1 %cond12096, label %bb_rcslotdrop3159, label %bb_rcslotdone3159
bb_rcslotdrop3159:
  %v12097 = load i64, ptr %slot28, align 8
  %p12098 = inttoptr i64 %v12097 to ptr
  store i32 0, ptr %p12098, align 4, !alias.scope !3, !noalias !4
  %v12099 = load i64, ptr %slot37, align 8
  store i64 %v12099, ptr %slot2205, align 8
  %v12100 = load i64, ptr %slot29, align 8
  %p12101 = inttoptr i64 %v12100 to ptr
  %ld12102 = load i32, ptr %p12101, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12102, ptr %slot2206, align 8
  %v12103 = load i32, ptr %slot2206, align 8
  %op12104 = and i32 %v12103, 28
  store i32 %op12104, ptr %slot2207, align 8
  %v12105 = load i32, ptr %slot2207, align 8
  %cv12106 = zext i32 %v12105 to i64
  %cond12107 = icmp ne i64 %cv12106, 0
  br i1 %cond12107, label %bb_rcslotrole3159, label %bb_rcslotowner3159
bb_rcslotrole3159:
  %v12108 = load i64, ptr %slot96, align 8
  store i64 %v12108, ptr %slot2208, align 8
  %v12109 = load i64, ptr %slot2208, align 8
  %v12110 = load i64, ptr %slot2205, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v12109, i64 %v12110) nomerge, !dbg !232
  br label %bb_rcslotdone3159
bb_rcslotowner3159:
  %v12111 = load i64, ptr %slot96, align 8
  store i64 %v12111, ptr %slot2209, align 8
  %v12112 = load i64, ptr %slot2209, align 8
  %v12113 = load i64, ptr %slot2205, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v12112, i64 %v12113) nomerge, !dbg !232
  br label %bb_rcslotdone3159
bb_rcslotdone3159:
  %v12114 = load i64, ptr %slot26, align 8
  %p12115 = inttoptr i64 %v12114 to ptr
  %ld12116 = load i32, ptr %p12115, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12116, ptr %slot2210, align 8
  %v12117 = load i32, ptr %slot2210, align 8
  %cv12118 = zext i32 %v12117 to i64
  %cond12119 = icmp ne i64 %cv12118, 0
  br i1 %cond12119, label %bb_rcslotdrop3186, label %bb_rcslotdone3186
bb_rcslotdrop3186:
  %v12120 = load i64, ptr %slot26, align 8
  %p12121 = inttoptr i64 %v12120 to ptr
  store i32 0, ptr %p12121, align 4, !alias.scope !3, !noalias !4
  %v12122 = load i64, ptr %slot68, align 8
  store i64 %v12122, ptr %slot2211, align 8
  %v12123 = load i64, ptr %slot27, align 8
  %p12124 = inttoptr i64 %v12123 to ptr
  %ld12125 = load i32, ptr %p12124, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12125, ptr %slot2212, align 8
  %v12126 = load i32, ptr %slot2212, align 8
  %op12127 = and i32 %v12126, 28
  store i32 %op12127, ptr %slot2213, align 8
  %v12128 = load i32, ptr %slot2213, align 8
  %cv12129 = zext i32 %v12128 to i64
  %cond12130 = icmp ne i64 %cv12129, 0
  br i1 %cond12130, label %bb_rcslotrole3186, label %bb_rcslotowner3186
bb_rcslotrole3186:
  %v12131 = load i64, ptr %slot96, align 8
  store i64 %v12131, ptr %slot2214, align 8
  %v12132 = load i64, ptr %slot2214, align 8
  %v12133 = load i64, ptr %slot2211, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12132, i64 %v12133) nomerge, !dbg !232
  br label %bb_rcslotdone3186
bb_rcslotowner3186:
  %v12134 = load i64, ptr %slot96, align 8
  store i64 %v12134, ptr %slot2215, align 8
  %v12135 = load i64, ptr %slot2215, align 8
  %v12136 = load i64, ptr %slot2211, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12135, i64 %v12136) nomerge, !dbg !232
  br label %bb_rcslotdone3186
bb_rcslotdone3186:
  %v12137 = load i64, ptr %slot24, align 8
  %p12138 = inttoptr i64 %v12137 to ptr
  %ld12139 = load i32, ptr %p12138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12139, ptr %slot2216, align 8
  %v12140 = load i32, ptr %slot2216, align 8
  %cv12141 = zext i32 %v12140 to i64
  %cond12142 = icmp ne i64 %cv12141, 0
  br i1 %cond12142, label %bb_rcslotdrop3195, label %bb_rcslotdone3195
bb_rcslotdrop3195:
  %v12143 = load i64, ptr %slot24, align 8
  %p12144 = inttoptr i64 %v12143 to ptr
  store i32 0, ptr %p12144, align 4, !alias.scope !3, !noalias !4
  %v12145 = load i64, ptr %slot67, align 8
  store i64 %v12145, ptr %slot2217, align 8
  %v12146 = load i64, ptr %slot25, align 8
  %p12147 = inttoptr i64 %v12146 to ptr
  %ld12148 = load i32, ptr %p12147, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12148, ptr %slot2218, align 8
  %v12149 = load i32, ptr %slot2218, align 8
  %op12150 = and i32 %v12149, 28
  store i32 %op12150, ptr %slot2219, align 8
  %v12151 = load i32, ptr %slot2219, align 8
  %cv12152 = zext i32 %v12151 to i64
  %cond12153 = icmp ne i64 %cv12152, 0
  br i1 %cond12153, label %bb_rcslotrole3195, label %bb_rcslotowner3195
bb_rcslotrole3195:
  %v12154 = load i64, ptr %slot96, align 8
  store i64 %v12154, ptr %slot2220, align 8
  %v12155 = load i64, ptr %slot2217, align 8
  %p12156 = inttoptr i64 %v12155 to ptr
  %ld12157 = load i64, ptr %p12156, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12157, ptr %slot2221, align 8
  %v12158 = load i64, ptr %slot2221, align 8
  %cmp12159 = icmp ne i64 %v12158, 0
  %cv12160 = zext i1 %cmp12159 to i32
  store i32 %cv12160, ptr %slot2222, align 8
  %v12161 = load i32, ptr %slot2222, align 8
  %cv12162 = zext i32 %v12161 to i64
  %cond12163 = icmp ne i64 %cv12162, 0
  br i1 %cond12163, label %bb_rcgnn3211, label %bb_rcgdone3211
bb_rcgnn3211:
  %v12164 = load i64, ptr %slot2221, align 8
  %op12165 = sub i64 %v12164, 16
  store i64 %op12165, ptr %slot2223, align 8
  %v12166 = load i64, ptr %slot2221, align 8
  %p12167 = inttoptr i64 %v12166 to ptr
  %rgep12168 = getelementptr i8, ptr %p12167, i64 -16
  %ld12169 = load i64, ptr %rgep12168, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12169, ptr %slot2224, align 8
  %v12170 = load i64, ptr %slot2224, align 8
  %op12171 = and i64 %v12170, 4611686018427387906
  store i64 %op12171, ptr %slot2225, align 8
  %v12172 = load i64, ptr %slot2225, align 8
  %cmp12173 = icmp ne i64 %v12172, 0
  %cv12174 = zext i1 %cmp12173 to i32
  store i32 %cv12174, ptr %slot2226, align 8
  %v12175 = load i32, ptr %slot2226, align 8
  %cv12176 = zext i32 %v12175 to i64
  %cond12177 = icmp ne i64 %cv12176, 0
  br i1 %cond12177, label %bb_rcgclear3211, label %bb_rcgcounted3211
bb_rcgcounted3211:
  %v12178 = load i64, ptr %slot2221, align 8
  %op12179 = sub i64 %v12178, 24
  store i64 %op12179, ptr %slot2227, align 8
  %v12180 = load i64, ptr %slot2221, align 8
  %p12181 = inttoptr i64 %v12180 to ptr
  %rgep12182 = getelementptr i8, ptr %p12181, i64 -24
  %ld12183 = load i64, ptr %rgep12182, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12183, ptr %slot2228, align 8
  %v12184 = load i64, ptr %slot2228, align 8
  %op12185 = sub i64 %v12184, 1
  store i64 %op12185, ptr %slot2229, align 8
  %v12186 = load i64, ptr %slot2229, align 8
  %cmp12187 = icmp eq i64 %v12186, 0
  %cv12188 = zext i1 %cmp12187 to i32
  store i32 %cv12188, ptr %slot2230, align 8
  %v12189 = load i32, ptr %slot2230, align 8
  %cv12190 = zext i32 %v12189 to i64
  %cond12191 = icmp ne i64 %cv12190, 0
  br i1 %cond12191, label %bb_rcglast3211, label %bb_rcgdec3211
bb_rcglast3211:
  %v12192 = load i64, ptr %slot2221, align 8
  %op12193 = sub i64 %v12192, 32
  store i64 %op12193, ptr %slot2231, align 8
  %v12194 = load i64, ptr %slot2221, align 8
  %p12195 = inttoptr i64 %v12194 to ptr
  %rgep12196 = getelementptr i8, ptr %p12195, i64 -32
  %ld12197 = load i64, ptr %rgep12196, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12197, ptr %slot2232, align 8
  %v12198 = load i64, ptr %slot2232, align 8
  %cmp12199 = icmp ne i64 %v12198, 0
  %cv12200 = zext i1 %cmp12199 to i32
  store i32 %cv12200, ptr %slot2233, align 8
  %v12201 = load i32, ptr %slot2233, align 8
  %cv12202 = zext i32 %v12201 to i64
  %cond12203 = icmp ne i64 %cv12202, 0
  br i1 %cond12203, label %bb_rcgdec3211, label %bb_rcgslow3211
bb_rcgslow3211:
  %v12204 = load i64, ptr %slot2220, align 8
  %v12205 = load i64, ptr %slot2217, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v12204, i64 %v12205) nomerge, !dbg !232
  br label %bb_rcgdone3211
bb_rcgdec3211:
  %v12206 = load i64, ptr %slot2229, align 8
  %v12207 = load i64, ptr %slot2221, align 8
  %p12208 = inttoptr i64 %v12207 to ptr
  %rgep12209 = getelementptr i8, ptr %p12208, i64 -24
  store i64 %v12206, ptr %rgep12209, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3211
bb_rcgclear3211:
  %v12210 = load i64, ptr %slot2217, align 8
  %p12211 = inttoptr i64 %v12210 to ptr
  store i64 0, ptr %p12211, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3211
bb_rcgdone3211:
  br label %bb_rcslotdone3195
bb_rcslotowner3195:
  %v12212 = load i64, ptr %slot96, align 8
  store i64 %v12212, ptr %slot2234, align 8
  %v12213 = load i64, ptr %slot2217, align 8
  %p12214 = inttoptr i64 %v12213 to ptr
  %ld12215 = load i64, ptr %p12214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12215, ptr %slot2235, align 8
  %v12216 = load i64, ptr %slot2235, align 8
  %cmp12217 = icmp ne i64 %v12216, 0
  %cv12218 = zext i1 %cmp12217 to i32
  store i32 %cv12218, ptr %slot2236, align 8
  %v12219 = load i32, ptr %slot2236, align 8
  %cv12220 = zext i32 %v12219 to i64
  %cond12221 = icmp ne i64 %cv12220, 0
  br i1 %cond12221, label %bb_rcgnn3226, label %bb_rcgdone3226
bb_rcgnn3226:
  %v12222 = load i64, ptr %slot2235, align 8
  %op12223 = sub i64 %v12222, 16
  store i64 %op12223, ptr %slot2237, align 8
  %v12224 = load i64, ptr %slot2235, align 8
  %p12225 = inttoptr i64 %v12224 to ptr
  %rgep12226 = getelementptr i8, ptr %p12225, i64 -16
  %ld12227 = load i64, ptr %rgep12226, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12227, ptr %slot2238, align 8
  %v12228 = load i64, ptr %slot2238, align 8
  %op12229 = and i64 %v12228, 4611686018427387906
  store i64 %op12229, ptr %slot2239, align 8
  %v12230 = load i64, ptr %slot2239, align 8
  %cmp12231 = icmp ne i64 %v12230, 0
  %cv12232 = zext i1 %cmp12231 to i32
  store i32 %cv12232, ptr %slot2240, align 8
  %v12233 = load i32, ptr %slot2240, align 8
  %cv12234 = zext i32 %v12233 to i64
  %cond12235 = icmp ne i64 %cv12234, 0
  br i1 %cond12235, label %bb_rcgclear3226, label %bb_rcgcounted3226
bb_rcgcounted3226:
  %v12236 = load i64, ptr %slot2235, align 8
  %op12237 = sub i64 %v12236, 32
  store i64 %op12237, ptr %slot2241, align 8
  %v12238 = load i64, ptr %slot2235, align 8
  %p12239 = inttoptr i64 %v12238 to ptr
  %rgep12240 = getelementptr i8, ptr %p12239, i64 -32
  %ld12241 = load i64, ptr %rgep12240, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12241, ptr %slot2242, align 8
  %v12242 = load i64, ptr %slot2242, align 8
  %op12243 = sub i64 %v12242, 1
  store i64 %op12243, ptr %slot2243, align 8
  %v12244 = load i64, ptr %slot2243, align 8
  %cmp12245 = icmp eq i64 %v12244, 0
  %cv12246 = zext i1 %cmp12245 to i32
  store i32 %cv12246, ptr %slot2244, align 8
  %v12247 = load i32, ptr %slot2244, align 8
  %cv12248 = zext i32 %v12247 to i64
  %cond12249 = icmp ne i64 %cv12248, 0
  br i1 %cond12249, label %bb_rcglast3226, label %bb_rcgdec3226
bb_rcglast3226:
  %v12250 = load i64, ptr %slot2235, align 8
  %op12251 = sub i64 %v12250, 24
  store i64 %op12251, ptr %slot2245, align 8
  %v12252 = load i64, ptr %slot2235, align 8
  %p12253 = inttoptr i64 %v12252 to ptr
  %rgep12254 = getelementptr i8, ptr %p12253, i64 -24
  %ld12255 = load i64, ptr %rgep12254, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12255, ptr %slot2246, align 8
  %v12256 = load i64, ptr %slot2246, align 8
  %cmp12257 = icmp ne i64 %v12256, 0
  %cv12258 = zext i1 %cmp12257 to i32
  store i32 %cv12258, ptr %slot2247, align 8
  %v12259 = load i32, ptr %slot2247, align 8
  %cv12260 = zext i32 %v12259 to i64
  %cond12261 = icmp ne i64 %cv12260, 0
  br i1 %cond12261, label %bb_rcgdec3226, label %bb_rcgslow3226
bb_rcgslow3226:
  %v12262 = load i64, ptr %slot2234, align 8
  %v12263 = load i64, ptr %slot2217, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v12262, i64 %v12263) nomerge, !dbg !232
  br label %bb_rcgdone3226
bb_rcgdec3226:
  %v12264 = load i64, ptr %slot2243, align 8
  %v12265 = load i64, ptr %slot2235, align 8
  %p12266 = inttoptr i64 %v12265 to ptr
  %rgep12267 = getelementptr i8, ptr %p12266, i64 -32
  store i64 %v12264, ptr %rgep12267, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3226
bb_rcgclear3226:
  %v12268 = load i64, ptr %slot2217, align 8
  %p12269 = inttoptr i64 %v12268 to ptr
  store i64 0, ptr %p12269, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3226
bb_rcgdone3226:
  br label %bb_rcslotdone3195
bb_rcslotdone3195:
  %v12270 = load i64, ptr %slot22, align 8
  %p12271 = inttoptr i64 %v12270 to ptr
  %ld12272 = load i32, ptr %p12271, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12272, ptr %slot2248, align 8
  %v12273 = load i32, ptr %slot2248, align 8
  %cv12274 = zext i32 %v12273 to i64
  %cond12275 = icmp ne i64 %cv12274, 0
  br i1 %cond12275, label %bb_rcslotdrop3232, label %bb_rcslotdone3232
bb_rcslotdrop3232:
  %v12276 = load i64, ptr %slot22, align 8
  %p12277 = inttoptr i64 %v12276 to ptr
  store i32 0, ptr %p12277, align 4, !alias.scope !3, !noalias !4
  %v12278 = load i64, ptr %slot66, align 8
  store i64 %v12278, ptr %slot2249, align 8
  %v12279 = load i64, ptr %slot23, align 8
  %p12280 = inttoptr i64 %v12279 to ptr
  %ld12281 = load i32, ptr %p12280, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12281, ptr %slot2250, align 8
  %v12282 = load i32, ptr %slot2250, align 8
  %op12283 = and i32 %v12282, 28
  store i32 %op12283, ptr %slot2251, align 8
  %v12284 = load i32, ptr %slot2251, align 8
  %cv12285 = zext i32 %v12284 to i64
  %cond12286 = icmp ne i64 %cv12285, 0
  br i1 %cond12286, label %bb_rcslotrole3232, label %bb_rcslotowner3232
bb_rcslotrole3232:
  %v12287 = load i64, ptr %slot96, align 8
  store i64 %v12287, ptr %slot2252, align 8
  %v12288 = load i64, ptr %slot2249, align 8
  %p12289 = inttoptr i64 %v12288 to ptr
  %ld12290 = load i64, ptr %p12289, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12290, ptr %slot2253, align 8
  %v12291 = load i64, ptr %slot2253, align 8
  %cmp12292 = icmp ne i64 %v12291, 0
  %cv12293 = zext i1 %cmp12292 to i32
  store i32 %cv12293, ptr %slot2254, align 8
  %v12294 = load i32, ptr %slot2254, align 8
  %cv12295 = zext i32 %v12294 to i64
  %cond12296 = icmp ne i64 %cv12295, 0
  br i1 %cond12296, label %bb_rcgnn3248, label %bb_rcgdone3248
bb_rcgnn3248:
  %v12297 = load i64, ptr %slot2253, align 8
  %op12298 = sub i64 %v12297, 16
  store i64 %op12298, ptr %slot2255, align 8
  %v12299 = load i64, ptr %slot2253, align 8
  %p12300 = inttoptr i64 %v12299 to ptr
  %rgep12301 = getelementptr i8, ptr %p12300, i64 -16
  %ld12302 = load i64, ptr %rgep12301, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12302, ptr %slot2256, align 8
  %v12303 = load i64, ptr %slot2256, align 8
  %op12304 = and i64 %v12303, 4611686018427387906
  store i64 %op12304, ptr %slot2257, align 8
  %v12305 = load i64, ptr %slot2257, align 8
  %cmp12306 = icmp ne i64 %v12305, 0
  %cv12307 = zext i1 %cmp12306 to i32
  store i32 %cv12307, ptr %slot2258, align 8
  %v12308 = load i32, ptr %slot2258, align 8
  %cv12309 = zext i32 %v12308 to i64
  %cond12310 = icmp ne i64 %cv12309, 0
  br i1 %cond12310, label %bb_rcgclear3248, label %bb_rcgcounted3248
bb_rcgcounted3248:
  %v12311 = load i64, ptr %slot2253, align 8
  %op12312 = sub i64 %v12311, 24
  store i64 %op12312, ptr %slot2259, align 8
  %v12313 = load i64, ptr %slot2253, align 8
  %p12314 = inttoptr i64 %v12313 to ptr
  %rgep12315 = getelementptr i8, ptr %p12314, i64 -24
  %ld12316 = load i64, ptr %rgep12315, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12316, ptr %slot2260, align 8
  %v12317 = load i64, ptr %slot2260, align 8
  %op12318 = sub i64 %v12317, 1
  store i64 %op12318, ptr %slot2261, align 8
  %v12319 = load i64, ptr %slot2261, align 8
  %cmp12320 = icmp eq i64 %v12319, 0
  %cv12321 = zext i1 %cmp12320 to i32
  store i32 %cv12321, ptr %slot2262, align 8
  %v12322 = load i32, ptr %slot2262, align 8
  %cv12323 = zext i32 %v12322 to i64
  %cond12324 = icmp ne i64 %cv12323, 0
  br i1 %cond12324, label %bb_rcglast3248, label %bb_rcgdec3248
bb_rcglast3248:
  %v12325 = load i64, ptr %slot2253, align 8
  %op12326 = sub i64 %v12325, 32
  store i64 %op12326, ptr %slot2263, align 8
  %v12327 = load i64, ptr %slot2253, align 8
  %p12328 = inttoptr i64 %v12327 to ptr
  %rgep12329 = getelementptr i8, ptr %p12328, i64 -32
  %ld12330 = load i64, ptr %rgep12329, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12330, ptr %slot2264, align 8
  %v12331 = load i64, ptr %slot2264, align 8
  %cmp12332 = icmp ne i64 %v12331, 0
  %cv12333 = zext i1 %cmp12332 to i32
  store i32 %cv12333, ptr %slot2265, align 8
  %v12334 = load i32, ptr %slot2265, align 8
  %cv12335 = zext i32 %v12334 to i64
  %cond12336 = icmp ne i64 %cv12335, 0
  br i1 %cond12336, label %bb_rcgdec3248, label %bb_rcgslow3248
bb_rcgslow3248:
  %v12337 = load i64, ptr %slot2252, align 8
  %v12338 = load i64, ptr %slot2249, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v12337, i64 %v12338) nomerge, !dbg !232
  br label %bb_rcgdone3248
bb_rcgdec3248:
  %v12339 = load i64, ptr %slot2261, align 8
  %v12340 = load i64, ptr %slot2253, align 8
  %p12341 = inttoptr i64 %v12340 to ptr
  %rgep12342 = getelementptr i8, ptr %p12341, i64 -24
  store i64 %v12339, ptr %rgep12342, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3248
bb_rcgclear3248:
  %v12343 = load i64, ptr %slot2249, align 8
  %p12344 = inttoptr i64 %v12343 to ptr
  store i64 0, ptr %p12344, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3248
bb_rcgdone3248:
  br label %bb_rcslotdone3232
bb_rcslotowner3232:
  %v12345 = load i64, ptr %slot96, align 8
  store i64 %v12345, ptr %slot2266, align 8
  %v12346 = load i64, ptr %slot2249, align 8
  %p12347 = inttoptr i64 %v12346 to ptr
  %ld12348 = load i64, ptr %p12347, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12348, ptr %slot2267, align 8
  %v12349 = load i64, ptr %slot2267, align 8
  %cmp12350 = icmp ne i64 %v12349, 0
  %cv12351 = zext i1 %cmp12350 to i32
  store i32 %cv12351, ptr %slot2268, align 8
  %v12352 = load i32, ptr %slot2268, align 8
  %cv12353 = zext i32 %v12352 to i64
  %cond12354 = icmp ne i64 %cv12353, 0
  br i1 %cond12354, label %bb_rcgnn3263, label %bb_rcgdone3263
bb_rcgnn3263:
  %v12355 = load i64, ptr %slot2267, align 8
  %op12356 = sub i64 %v12355, 16
  store i64 %op12356, ptr %slot2269, align 8
  %v12357 = load i64, ptr %slot2267, align 8
  %p12358 = inttoptr i64 %v12357 to ptr
  %rgep12359 = getelementptr i8, ptr %p12358, i64 -16
  %ld12360 = load i64, ptr %rgep12359, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12360, ptr %slot2270, align 8
  %v12361 = load i64, ptr %slot2270, align 8
  %op12362 = and i64 %v12361, 4611686018427387906
  store i64 %op12362, ptr %slot2271, align 8
  %v12363 = load i64, ptr %slot2271, align 8
  %cmp12364 = icmp ne i64 %v12363, 0
  %cv12365 = zext i1 %cmp12364 to i32
  store i32 %cv12365, ptr %slot2272, align 8
  %v12366 = load i32, ptr %slot2272, align 8
  %cv12367 = zext i32 %v12366 to i64
  %cond12368 = icmp ne i64 %cv12367, 0
  br i1 %cond12368, label %bb_rcgclear3263, label %bb_rcgcounted3263
bb_rcgcounted3263:
  %v12369 = load i64, ptr %slot2267, align 8
  %op12370 = sub i64 %v12369, 32
  store i64 %op12370, ptr %slot2273, align 8
  %v12371 = load i64, ptr %slot2267, align 8
  %p12372 = inttoptr i64 %v12371 to ptr
  %rgep12373 = getelementptr i8, ptr %p12372, i64 -32
  %ld12374 = load i64, ptr %rgep12373, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12374, ptr %slot2274, align 8
  %v12375 = load i64, ptr %slot2274, align 8
  %op12376 = sub i64 %v12375, 1
  store i64 %op12376, ptr %slot2275, align 8
  %v12377 = load i64, ptr %slot2275, align 8
  %cmp12378 = icmp eq i64 %v12377, 0
  %cv12379 = zext i1 %cmp12378 to i32
  store i32 %cv12379, ptr %slot2276, align 8
  %v12380 = load i32, ptr %slot2276, align 8
  %cv12381 = zext i32 %v12380 to i64
  %cond12382 = icmp ne i64 %cv12381, 0
  br i1 %cond12382, label %bb_rcglast3263, label %bb_rcgdec3263
bb_rcglast3263:
  %v12383 = load i64, ptr %slot2267, align 8
  %op12384 = sub i64 %v12383, 24
  store i64 %op12384, ptr %slot2277, align 8
  %v12385 = load i64, ptr %slot2267, align 8
  %p12386 = inttoptr i64 %v12385 to ptr
  %rgep12387 = getelementptr i8, ptr %p12386, i64 -24
  %ld12388 = load i64, ptr %rgep12387, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12388, ptr %slot2278, align 8
  %v12389 = load i64, ptr %slot2278, align 8
  %cmp12390 = icmp ne i64 %v12389, 0
  %cv12391 = zext i1 %cmp12390 to i32
  store i32 %cv12391, ptr %slot2279, align 8
  %v12392 = load i32, ptr %slot2279, align 8
  %cv12393 = zext i32 %v12392 to i64
  %cond12394 = icmp ne i64 %cv12393, 0
  br i1 %cond12394, label %bb_rcgdec3263, label %bb_rcgslow3263
bb_rcgslow3263:
  %v12395 = load i64, ptr %slot2266, align 8
  %v12396 = load i64, ptr %slot2249, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v12395, i64 %v12396) nomerge, !dbg !232
  br label %bb_rcgdone3263
bb_rcgdec3263:
  %v12397 = load i64, ptr %slot2275, align 8
  %v12398 = load i64, ptr %slot2267, align 8
  %p12399 = inttoptr i64 %v12398 to ptr
  %rgep12400 = getelementptr i8, ptr %p12399, i64 -32
  store i64 %v12397, ptr %rgep12400, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3263
bb_rcgclear3263:
  %v12401 = load i64, ptr %slot2249, align 8
  %p12402 = inttoptr i64 %v12401 to ptr
  store i64 0, ptr %p12402, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3263
bb_rcgdone3263:
  br label %bb_rcslotdone3232
bb_rcslotdone3232:
  %v12403 = load i64, ptr %slot20, align 8
  %p12404 = inttoptr i64 %v12403 to ptr
  %ld12405 = load i32, ptr %p12404, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12405, ptr %slot2280, align 8
  %v12406 = load i32, ptr %slot2280, align 8
  %cv12407 = zext i32 %v12406 to i64
  %cond12408 = icmp ne i64 %cv12407, 0
  br i1 %cond12408, label %bb_rcslotdrop3269, label %bb_rcslotdone3269
bb_rcslotdrop3269:
  %v12409 = load i64, ptr %slot20, align 8
  %p12410 = inttoptr i64 %v12409 to ptr
  store i32 0, ptr %p12410, align 4, !alias.scope !3, !noalias !4
  %v12411 = load i64, ptr %slot65, align 8
  store i64 %v12411, ptr %slot2281, align 8
  %v12412 = load i64, ptr %slot21, align 8
  %p12413 = inttoptr i64 %v12412 to ptr
  %ld12414 = load i32, ptr %p12413, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12414, ptr %slot2282, align 8
  %v12415 = load i32, ptr %slot2282, align 8
  %op12416 = and i32 %v12415, 28
  store i32 %op12416, ptr %slot2283, align 8
  %v12417 = load i32, ptr %slot2283, align 8
  %cv12418 = zext i32 %v12417 to i64
  %cond12419 = icmp ne i64 %cv12418, 0
  br i1 %cond12419, label %bb_rcslotrole3269, label %bb_rcslotowner3269
bb_rcslotrole3269:
  %v12420 = load i64, ptr %slot96, align 8
  store i64 %v12420, ptr %slot2284, align 8
  %v12421 = load i64, ptr %slot2281, align 8
  %p12422 = inttoptr i64 %v12421 to ptr
  %ld12423 = load i64, ptr %p12422, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12423, ptr %slot2285, align 8
  %v12424 = load i64, ptr %slot2285, align 8
  %cmp12425 = icmp ne i64 %v12424, 0
  %cv12426 = zext i1 %cmp12425 to i32
  store i32 %cv12426, ptr %slot2286, align 8
  %v12427 = load i32, ptr %slot2286, align 8
  %cv12428 = zext i32 %v12427 to i64
  %cond12429 = icmp ne i64 %cv12428, 0
  br i1 %cond12429, label %bb_rcgnn3285, label %bb_rcgdone3285
bb_rcgnn3285:
  %v12430 = load i64, ptr %slot2285, align 8
  %op12431 = sub i64 %v12430, 16
  store i64 %op12431, ptr %slot2287, align 8
  %v12432 = load i64, ptr %slot2285, align 8
  %p12433 = inttoptr i64 %v12432 to ptr
  %rgep12434 = getelementptr i8, ptr %p12433, i64 -16
  %ld12435 = load i64, ptr %rgep12434, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12435, ptr %slot2288, align 8
  %v12436 = load i64, ptr %slot2288, align 8
  %op12437 = and i64 %v12436, 4611686018427387906
  store i64 %op12437, ptr %slot2289, align 8
  %v12438 = load i64, ptr %slot2289, align 8
  %cmp12439 = icmp ne i64 %v12438, 0
  %cv12440 = zext i1 %cmp12439 to i32
  store i32 %cv12440, ptr %slot2290, align 8
  %v12441 = load i32, ptr %slot2290, align 8
  %cv12442 = zext i32 %v12441 to i64
  %cond12443 = icmp ne i64 %cv12442, 0
  br i1 %cond12443, label %bb_rcgclear3285, label %bb_rcgcounted3285
bb_rcgcounted3285:
  %v12444 = load i64, ptr %slot2285, align 8
  %op12445 = sub i64 %v12444, 24
  store i64 %op12445, ptr %slot2291, align 8
  %v12446 = load i64, ptr %slot2285, align 8
  %p12447 = inttoptr i64 %v12446 to ptr
  %rgep12448 = getelementptr i8, ptr %p12447, i64 -24
  %ld12449 = load i64, ptr %rgep12448, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12449, ptr %slot2292, align 8
  %v12450 = load i64, ptr %slot2292, align 8
  %op12451 = sub i64 %v12450, 1
  store i64 %op12451, ptr %slot2293, align 8
  %v12452 = load i64, ptr %slot2293, align 8
  %cmp12453 = icmp eq i64 %v12452, 0
  %cv12454 = zext i1 %cmp12453 to i32
  store i32 %cv12454, ptr %slot2294, align 8
  %v12455 = load i32, ptr %slot2294, align 8
  %cv12456 = zext i32 %v12455 to i64
  %cond12457 = icmp ne i64 %cv12456, 0
  br i1 %cond12457, label %bb_rcglast3285, label %bb_rcgdec3285
bb_rcglast3285:
  %v12458 = load i64, ptr %slot2285, align 8
  %op12459 = sub i64 %v12458, 32
  store i64 %op12459, ptr %slot2295, align 8
  %v12460 = load i64, ptr %slot2285, align 8
  %p12461 = inttoptr i64 %v12460 to ptr
  %rgep12462 = getelementptr i8, ptr %p12461, i64 -32
  %ld12463 = load i64, ptr %rgep12462, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12463, ptr %slot2296, align 8
  %v12464 = load i64, ptr %slot2296, align 8
  %cmp12465 = icmp ne i64 %v12464, 0
  %cv12466 = zext i1 %cmp12465 to i32
  store i32 %cv12466, ptr %slot2297, align 8
  %v12467 = load i32, ptr %slot2297, align 8
  %cv12468 = zext i32 %v12467 to i64
  %cond12469 = icmp ne i64 %cv12468, 0
  br i1 %cond12469, label %bb_rcgdec3285, label %bb_rcgslow3285
bb_rcgslow3285:
  %v12470 = load i64, ptr %slot2284, align 8
  %v12471 = load i64, ptr %slot2281, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v12470, i64 %v12471) nomerge, !dbg !232
  br label %bb_rcgdone3285
bb_rcgdec3285:
  %v12472 = load i64, ptr %slot2293, align 8
  %v12473 = load i64, ptr %slot2285, align 8
  %p12474 = inttoptr i64 %v12473 to ptr
  %rgep12475 = getelementptr i8, ptr %p12474, i64 -24
  store i64 %v12472, ptr %rgep12475, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3285
bb_rcgclear3285:
  %v12476 = load i64, ptr %slot2281, align 8
  %p12477 = inttoptr i64 %v12476 to ptr
  store i64 0, ptr %p12477, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3285
bb_rcgdone3285:
  br label %bb_rcslotdone3269
bb_rcslotowner3269:
  %v12478 = load i64, ptr %slot96, align 8
  store i64 %v12478, ptr %slot2298, align 8
  %v12479 = load i64, ptr %slot2281, align 8
  %p12480 = inttoptr i64 %v12479 to ptr
  %ld12481 = load i64, ptr %p12480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12481, ptr %slot2299, align 8
  %v12482 = load i64, ptr %slot2299, align 8
  %cmp12483 = icmp ne i64 %v12482, 0
  %cv12484 = zext i1 %cmp12483 to i32
  store i32 %cv12484, ptr %slot2300, align 8
  %v12485 = load i32, ptr %slot2300, align 8
  %cv12486 = zext i32 %v12485 to i64
  %cond12487 = icmp ne i64 %cv12486, 0
  br i1 %cond12487, label %bb_rcgnn3300, label %bb_rcgdone3300
bb_rcgnn3300:
  %v12488 = load i64, ptr %slot2299, align 8
  %op12489 = sub i64 %v12488, 16
  store i64 %op12489, ptr %slot2301, align 8
  %v12490 = load i64, ptr %slot2299, align 8
  %p12491 = inttoptr i64 %v12490 to ptr
  %rgep12492 = getelementptr i8, ptr %p12491, i64 -16
  %ld12493 = load i64, ptr %rgep12492, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12493, ptr %slot2302, align 8
  %v12494 = load i64, ptr %slot2302, align 8
  %op12495 = and i64 %v12494, 4611686018427387906
  store i64 %op12495, ptr %slot2303, align 8
  %v12496 = load i64, ptr %slot2303, align 8
  %cmp12497 = icmp ne i64 %v12496, 0
  %cv12498 = zext i1 %cmp12497 to i32
  store i32 %cv12498, ptr %slot2304, align 8
  %v12499 = load i32, ptr %slot2304, align 8
  %cv12500 = zext i32 %v12499 to i64
  %cond12501 = icmp ne i64 %cv12500, 0
  br i1 %cond12501, label %bb_rcgclear3300, label %bb_rcgcounted3300
bb_rcgcounted3300:
  %v12502 = load i64, ptr %slot2299, align 8
  %op12503 = sub i64 %v12502, 32
  store i64 %op12503, ptr %slot2305, align 8
  %v12504 = load i64, ptr %slot2299, align 8
  %p12505 = inttoptr i64 %v12504 to ptr
  %rgep12506 = getelementptr i8, ptr %p12505, i64 -32
  %ld12507 = load i64, ptr %rgep12506, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12507, ptr %slot2306, align 8
  %v12508 = load i64, ptr %slot2306, align 8
  %op12509 = sub i64 %v12508, 1
  store i64 %op12509, ptr %slot2307, align 8
  %v12510 = load i64, ptr %slot2307, align 8
  %cmp12511 = icmp eq i64 %v12510, 0
  %cv12512 = zext i1 %cmp12511 to i32
  store i32 %cv12512, ptr %slot2308, align 8
  %v12513 = load i32, ptr %slot2308, align 8
  %cv12514 = zext i32 %v12513 to i64
  %cond12515 = icmp ne i64 %cv12514, 0
  br i1 %cond12515, label %bb_rcglast3300, label %bb_rcgdec3300
bb_rcglast3300:
  %v12516 = load i64, ptr %slot2299, align 8
  %op12517 = sub i64 %v12516, 24
  store i64 %op12517, ptr %slot2309, align 8
  %v12518 = load i64, ptr %slot2299, align 8
  %p12519 = inttoptr i64 %v12518 to ptr
  %rgep12520 = getelementptr i8, ptr %p12519, i64 -24
  %ld12521 = load i64, ptr %rgep12520, align 8, !alias.scope !9, !noalias !10
  store i64 %ld12521, ptr %slot2310, align 8
  %v12522 = load i64, ptr %slot2310, align 8
  %cmp12523 = icmp ne i64 %v12522, 0
  %cv12524 = zext i1 %cmp12523 to i32
  store i32 %cv12524, ptr %slot2311, align 8
  %v12525 = load i32, ptr %slot2311, align 8
  %cv12526 = zext i32 %v12525 to i64
  %cond12527 = icmp ne i64 %cv12526, 0
  br i1 %cond12527, label %bb_rcgdec3300, label %bb_rcgslow3300
bb_rcgslow3300:
  %v12528 = load i64, ptr %slot2298, align 8
  %v12529 = load i64, ptr %slot2281, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v12528, i64 %v12529) nomerge, !dbg !232
  br label %bb_rcgdone3300
bb_rcgdec3300:
  %v12530 = load i64, ptr %slot2307, align 8
  %v12531 = load i64, ptr %slot2299, align 8
  %p12532 = inttoptr i64 %v12531 to ptr
  %rgep12533 = getelementptr i8, ptr %p12532, i64 -32
  store i64 %v12530, ptr %rgep12533, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3300
bb_rcgclear3300:
  %v12534 = load i64, ptr %slot2281, align 8
  %p12535 = inttoptr i64 %v12534 to ptr
  store i64 0, ptr %p12535, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3300
bb_rcgdone3300:
  br label %bb_rcslotdone3269
bb_rcslotdone3269:
  %v12536 = load i64, ptr %slot18, align 8
  %p12537 = inttoptr i64 %v12536 to ptr
  %ld12538 = load i32, ptr %p12537, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12538, ptr %slot2312, align 8
  %v12539 = load i32, ptr %slot2312, align 8
  %cv12540 = zext i32 %v12539 to i64
  %cond12541 = icmp ne i64 %cv12540, 0
  br i1 %cond12541, label %bb_rcslotdrop3324, label %bb_rcslotdone3324
bb_rcslotdrop3324:
  %v12542 = load i64, ptr %slot18, align 8
  %p12543 = inttoptr i64 %v12542 to ptr
  store i32 0, ptr %p12543, align 4, !alias.scope !3, !noalias !4
  %v12544 = load i64, ptr %slot64, align 8
  store i64 %v12544, ptr %slot2313, align 8
  %v12545 = load i64, ptr %slot19, align 8
  %p12546 = inttoptr i64 %v12545 to ptr
  %ld12547 = load i32, ptr %p12546, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12547, ptr %slot2314, align 8
  %v12548 = load i32, ptr %slot2314, align 8
  %op12549 = and i32 %v12548, 28
  store i32 %op12549, ptr %slot2315, align 8
  %v12550 = load i32, ptr %slot2315, align 8
  %cv12551 = zext i32 %v12550 to i64
  %cond12552 = icmp ne i64 %cv12551, 0
  br i1 %cond12552, label %bb_rcslotrole3324, label %bb_rcslotowner3324
bb_rcslotrole3324:
  %v12553 = load i64, ptr %slot96, align 8
  store i64 %v12553, ptr %slot2316, align 8
  %v12554 = load i64, ptr %slot2316, align 8
  %v12555 = load i64, ptr %slot2313, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12554, i64 %v12555) nomerge, !dbg !232
  br label %bb_rcslotdone3324
bb_rcslotowner3324:
  %v12556 = load i64, ptr %slot96, align 8
  store i64 %v12556, ptr %slot2317, align 8
  %v12557 = load i64, ptr %slot2317, align 8
  %v12558 = load i64, ptr %slot2313, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12557, i64 %v12558) nomerge, !dbg !232
  br label %bb_rcslotdone3324
bb_rcslotdone3324:
  %v12559 = load i64, ptr %slot16, align 8
  %p12560 = inttoptr i64 %v12559 to ptr
  %ld12561 = load i32, ptr %p12560, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12561, ptr %slot2318, align 8
  %v12562 = load i32, ptr %slot2318, align 8
  %cv12563 = zext i32 %v12562 to i64
  %cond12564 = icmp ne i64 %cv12563, 0
  br i1 %cond12564, label %bb_rcslotdrop3351, label %bb_rcslotdone3351
bb_rcslotdrop3351:
  %v12565 = load i64, ptr %slot16, align 8
  %p12566 = inttoptr i64 %v12565 to ptr
  store i32 0, ptr %p12566, align 4, !alias.scope !3, !noalias !4
  %v12567 = load i64, ptr %slot62, align 8
  store i64 %v12567, ptr %slot2319, align 8
  %v12568 = load i64, ptr %slot17, align 8
  %p12569 = inttoptr i64 %v12568 to ptr
  %ld12570 = load i32, ptr %p12569, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12570, ptr %slot2320, align 8
  %v12571 = load i32, ptr %slot2320, align 8
  %op12572 = and i32 %v12571, 28
  store i32 %op12572, ptr %slot2321, align 8
  %v12573 = load i32, ptr %slot2321, align 8
  %cv12574 = zext i32 %v12573 to i64
  %cond12575 = icmp ne i64 %cv12574, 0
  br i1 %cond12575, label %bb_rcslotrole3351, label %bb_rcslotowner3351
bb_rcslotrole3351:
  %v12576 = load i64, ptr %slot96, align 8
  store i64 %v12576, ptr %slot2322, align 8
  %v12577 = load i64, ptr %slot2322, align 8
  %v12578 = load i64, ptr %slot2319, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12577, i64 %v12578) nomerge, !dbg !232
  br label %bb_rcslotdone3351
bb_rcslotowner3351:
  %v12579 = load i64, ptr %slot96, align 8
  store i64 %v12579, ptr %slot2323, align 8
  %v12580 = load i64, ptr %slot2323, align 8
  %v12581 = load i64, ptr %slot2319, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12580, i64 %v12581) nomerge, !dbg !232
  br label %bb_rcslotdone3351
bb_rcslotdone3351:
  %v12582 = load i64, ptr %slot14, align 8
  %p12583 = inttoptr i64 %v12582 to ptr
  %ld12584 = load i32, ptr %p12583, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12584, ptr %slot2324, align 8
  %v12585 = load i32, ptr %slot2324, align 8
  %cv12586 = zext i32 %v12585 to i64
  %cond12587 = icmp ne i64 %cv12586, 0
  br i1 %cond12587, label %bb_rcslotdrop3378, label %bb_rcslotdone3378
bb_rcslotdrop3378:
  %v12588 = load i64, ptr %slot14, align 8
  %p12589 = inttoptr i64 %v12588 to ptr
  store i32 0, ptr %p12589, align 4, !alias.scope !3, !noalias !4
  %v12590 = load i64, ptr %slot61, align 8
  store i64 %v12590, ptr %slot2325, align 8
  %v12591 = load i64, ptr %slot15, align 8
  %p12592 = inttoptr i64 %v12591 to ptr
  %ld12593 = load i32, ptr %p12592, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12593, ptr %slot2326, align 8
  %v12594 = load i32, ptr %slot2326, align 8
  %op12595 = and i32 %v12594, 28
  store i32 %op12595, ptr %slot2327, align 8
  %v12596 = load i32, ptr %slot2327, align 8
  %cv12597 = zext i32 %v12596 to i64
  %cond12598 = icmp ne i64 %cv12597, 0
  br i1 %cond12598, label %bb_rcslotrole3378, label %bb_rcslotowner3378
bb_rcslotrole3378:
  %v12599 = load i64, ptr %slot96, align 8
  store i64 %v12599, ptr %slot2328, align 8
  %v12600 = load i64, ptr %slot2328, align 8
  %v12601 = load i64, ptr %slot2325, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12600, i64 %v12601) nomerge, !dbg !232
  br label %bb_rcslotdone3378
bb_rcslotowner3378:
  %v12602 = load i64, ptr %slot96, align 8
  store i64 %v12602, ptr %slot2329, align 8
  %v12603 = load i64, ptr %slot2329, align 8
  %v12604 = load i64, ptr %slot2325, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12603, i64 %v12604) nomerge, !dbg !232
  br label %bb_rcslotdone3378
bb_rcslotdone3378:
  %v12605 = load i64, ptr %slot12, align 8
  %p12606 = inttoptr i64 %v12605 to ptr
  %ld12607 = load i32, ptr %p12606, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12607, ptr %slot2330, align 8
  %v12608 = load i32, ptr %slot2330, align 8
  %cv12609 = zext i32 %v12608 to i64
  %cond12610 = icmp ne i64 %cv12609, 0
  br i1 %cond12610, label %bb_rcslotdrop3405, label %bb_rcslotdone3405
bb_rcslotdrop3405:
  %v12611 = load i64, ptr %slot12, align 8
  %p12612 = inttoptr i64 %v12611 to ptr
  store i32 0, ptr %p12612, align 4, !alias.scope !3, !noalias !4
  %v12613 = load i64, ptr %slot59, align 8
  store i64 %v12613, ptr %slot2331, align 8
  %v12614 = load i64, ptr %slot13, align 8
  %p12615 = inttoptr i64 %v12614 to ptr
  %ld12616 = load i32, ptr %p12615, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12616, ptr %slot2332, align 8
  %v12617 = load i32, ptr %slot2332, align 8
  %op12618 = and i32 %v12617, 28
  store i32 %op12618, ptr %slot2333, align 8
  %v12619 = load i32, ptr %slot2333, align 8
  %cv12620 = zext i32 %v12619 to i64
  %cond12621 = icmp ne i64 %cv12620, 0
  br i1 %cond12621, label %bb_rcslotrole3405, label %bb_rcslotowner3405
bb_rcslotrole3405:
  %v12622 = load i64, ptr %slot96, align 8
  store i64 %v12622, ptr %slot2334, align 8
  %v12623 = load i64, ptr %slot2334, align 8
  %v12624 = load i64, ptr %slot2331, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12623, i64 %v12624) nomerge, !dbg !232
  br label %bb_rcslotdone3405
bb_rcslotowner3405:
  %v12625 = load i64, ptr %slot96, align 8
  store i64 %v12625, ptr %slot2335, align 8
  %v12626 = load i64, ptr %slot2335, align 8
  %v12627 = load i64, ptr %slot2331, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12626, i64 %v12627) nomerge, !dbg !232
  br label %bb_rcslotdone3405
bb_rcslotdone3405:
  %v12628 = load i64, ptr %slot10, align 8
  %p12629 = inttoptr i64 %v12628 to ptr
  %ld12630 = load i32, ptr %p12629, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12630, ptr %slot2336, align 8
  %v12631 = load i32, ptr %slot2336, align 8
  %cv12632 = zext i32 %v12631 to i64
  %cond12633 = icmp ne i64 %cv12632, 0
  br i1 %cond12633, label %bb_rcslotdrop3414, label %bb_rcslotdone3414
bb_rcslotdrop3414:
  %v12634 = load i64, ptr %slot10, align 8
  %p12635 = inttoptr i64 %v12634 to ptr
  store i32 0, ptr %p12635, align 4, !alias.scope !3, !noalias !4
  %v12636 = load i64, ptr %slot56, align 8
  store i64 %v12636, ptr %slot2337, align 8
  %v12637 = load i64, ptr %slot11, align 8
  %p12638 = inttoptr i64 %v12637 to ptr
  %ld12639 = load i32, ptr %p12638, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12639, ptr %slot2338, align 8
  %v12640 = load i32, ptr %slot2338, align 8
  %op12641 = and i32 %v12640, 28
  store i32 %op12641, ptr %slot2339, align 8
  %v12642 = load i32, ptr %slot2339, align 8
  %cv12643 = zext i32 %v12642 to i64
  %cond12644 = icmp ne i64 %cv12643, 0
  br i1 %cond12644, label %bb_rcslotrole3414, label %bb_rcslotowner3414
bb_rcslotrole3414:
  %v12645 = load i64, ptr %slot96, align 8
  store i64 %v12645, ptr %slot2340, align 8
  %v12646 = load i64, ptr %slot2340, align 8
  %v12647 = load i64, ptr %slot2337, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v12646, i64 %v12647) nomerge, !dbg !232
  br label %bb_rcslotdone3414
bb_rcslotowner3414:
  %v12648 = load i64, ptr %slot96, align 8
  store i64 %v12648, ptr %slot2341, align 8
  %v12649 = load i64, ptr %slot2341, align 8
  %v12650 = load i64, ptr %slot2337, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v12649, i64 %v12650) nomerge, !dbg !232
  br label %bb_rcslotdone3414
bb_rcslotdone3414:
  %v12651 = load i64, ptr %slot8, align 8
  %p12652 = inttoptr i64 %v12651 to ptr
  %ld12653 = load i32, ptr %p12652, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12653, ptr %slot2342, align 8
  %v12654 = load i32, ptr %slot2342, align 8
  %cv12655 = zext i32 %v12654 to i64
  %cond12656 = icmp ne i64 %cv12655, 0
  br i1 %cond12656, label %bb_rcslotdrop3478, label %bb_rcslotdone3478
bb_rcslotdrop3478:
  %v12657 = load i64, ptr %slot8, align 8
  %p12658 = inttoptr i64 %v12657 to ptr
  store i32 0, ptr %p12658, align 4, !alias.scope !3, !noalias !4
  %v12659 = load i64, ptr %slot51, align 8
  store i64 %v12659, ptr %slot2343, align 8
  %v12660 = load i64, ptr %slot9, align 8
  %p12661 = inttoptr i64 %v12660 to ptr
  %ld12662 = load i32, ptr %p12661, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12662, ptr %slot2344, align 8
  %v12663 = load i32, ptr %slot2344, align 8
  %op12664 = and i32 %v12663, 28
  store i32 %op12664, ptr %slot2345, align 8
  %v12665 = load i32, ptr %slot2345, align 8
  %cv12666 = zext i32 %v12665 to i64
  %cond12667 = icmp ne i64 %cv12666, 0
  br i1 %cond12667, label %bb_rcslotrole3478, label %bb_rcslotowner3478
bb_rcslotrole3478:
  %v12668 = load i64, ptr %slot96, align 8
  store i64 %v12668, ptr %slot2346, align 8
  %v12669 = load i64, ptr %slot2346, align 8
  %v12670 = load i64, ptr %slot2343, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12669, i64 %v12670) nomerge, !dbg !232
  br label %bb_rcslotdone3478
bb_rcslotowner3478:
  %v12671 = load i64, ptr %slot96, align 8
  store i64 %v12671, ptr %slot2347, align 8
  %v12672 = load i64, ptr %slot2347, align 8
  %v12673 = load i64, ptr %slot2343, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12672, i64 %v12673) nomerge, !dbg !232
  br label %bb_rcslotdone3478
bb_rcslotdone3478:
  %v12674 = load i64, ptr %slot2200, align 8
  %p12675 = inttoptr i64 %v12674 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p12675, i64 24, i1 false)
  ret void
bb_i216:
  br label %bb_i217
bb_i217:
  %v12676 = load i64, ptr %slot46, align 8
  %p12677 = inttoptr i64 %v12676 to ptr
  %ld12678 = load i64, ptr %p12677, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12678, ptr %slot2348, align 8
  %v12679 = load i64, ptr %slot2348, align 8
  %v12680 = load i64, ptr %slot89, align 8
  %p12681 = inttoptr i64 %v12679 to ptr
  %p12682 = inttoptr i64 %v12680 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12682, ptr %p12681, i64 304, i1 false), !alias.scope !10000000
  %v12683 = load i64, ptr %slot89, align 8
  %v12684 = load i64, ptr %slot69, align 8
  %p12685 = inttoptr i64 %v12684 to ptr
  store i64 %v12683, ptr %p12685, align 8, !alias.scope !3, !noalias !4
  %v12686 = load i64, ptr %slot69, align 8
  %p12687 = inttoptr i64 %v12686 to ptr
  %ld12688 = load i64, ptr %p12687, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12688, ptr %slot2349, align 8
  %v12689 = load i64, ptr %slot2349, align 8
  %op12690 = add i64 %v12689, 32
  store i64 %op12690, ptr %slot2350, align 8
  %v12691 = load i64, ptr %slot2350, align 8
  %v12692 = load i64, ptr %slot69, align 8
  %p12693 = inttoptr i64 %v12692 to ptr
  store i64 %v12691, ptr %p12693, align 8, !alias.scope !3, !noalias !4
  %v12694 = load i64, ptr %slot26, align 8
  %p12695 = inttoptr i64 %v12694 to ptr
  %ld12696 = load i32, ptr %p12695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12696, ptr %slot2351, align 8
  %v12697 = load i32, ptr %slot2351, align 8
  %cv12698 = zext i32 %v12697 to i64
  %cond12699 = icmp ne i64 %cv12698, 0
  br i1 %cond12699, label %bb_rcslotdrop3499, label %bb_rcslotdone3499
bb_rcslotdrop3499:
  %v12700 = load i64, ptr %slot26, align 8
  %p12701 = inttoptr i64 %v12700 to ptr
  store i32 0, ptr %p12701, align 4, !alias.scope !3, !noalias !4
  %v12702 = load i64, ptr %slot68, align 8
  store i64 %v12702, ptr %slot2352, align 8
  %v12703 = load i64, ptr %slot27, align 8
  %p12704 = inttoptr i64 %v12703 to ptr
  %ld12705 = load i32, ptr %p12704, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12705, ptr %slot2353, align 8
  %v12706 = load i32, ptr %slot2353, align 8
  %op12707 = and i32 %v12706, 28
  store i32 %op12707, ptr %slot2354, align 8
  %v12708 = load i32, ptr %slot2354, align 8
  %cv12709 = zext i32 %v12708 to i64
  %cond12710 = icmp ne i64 %cv12709, 0
  br i1 %cond12710, label %bb_rcslotrole3499, label %bb_rcslotowner3499
bb_rcslotrole3499:
  %v12711 = load i64, ptr %slot96, align 8
  store i64 %v12711, ptr %slot2355, align 8
  %v12712 = load i64, ptr %slot2355, align 8
  %v12713 = load i64, ptr %slot2352, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12712, i64 %v12713) nomerge, !dbg !234
  br label %bb_rcslotdone3499
bb_rcslotowner3499:
  %v12714 = load i64, ptr %slot96, align 8
  store i64 %v12714, ptr %slot2356, align 8
  %v12715 = load i64, ptr %slot2356, align 8
  %v12716 = load i64, ptr %slot2352, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12715, i64 %v12716) nomerge, !dbg !234
  br label %bb_rcslotdone3499
bb_rcslotdone3499:
  %v12717 = load i64, ptr %slot46, align 8
  %p12718 = inttoptr i64 %v12717 to ptr
  %ld12719 = load i64, ptr %p12718, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12719, ptr %slot2357, align 8
  %v12720 = load i64, ptr %slot2357, align 8
  %op12721 = add i64 %v12720, 32
  store i64 %op12721, ptr %slot2358, align 8
  %v12722 = load i64, ptr %slot68, align 8
  store i64 %v12722, ptr %slot2359, align 8
  %v12723 = load i64, ptr %slot2358, align 8
  %v12724 = load i64, ptr %slot2359, align 8
  %p12725 = inttoptr i64 %v12723 to ptr
  %p12726 = inttoptr i64 %v12724 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12726, ptr %p12725, i64 208, i1 false), !alias.scope !10000000
  %v12727 = load i64, ptr %slot2358, align 8
  %p12728 = inttoptr i64 %v12727 to ptr
  call void @llvm.memset.p0.i64(ptr %p12728, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !234
  %v12729 = load i64, ptr %slot26, align 8
  %p12730 = inttoptr i64 %v12729 to ptr
  store i32 1, ptr %p12730, align 4, !alias.scope !3, !noalias !4
  %v12731 = load i64, ptr %slot68, align 8
  %v12732 = load i64, ptr %slot69, align 8
  %p12733 = inttoptr i64 %v12732 to ptr
  store i64 %v12731, ptr %p12733, align 8, !alias.scope !3, !noalias !4
  %v12734 = load i64, ptr %slot48, align 8
  %p12735 = inttoptr i64 %v12734 to ptr
  %ld12736 = load i64, ptr %p12735, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12736, ptr %slot2360, align 8
  %v12737 = load i64, ptr %slot2360, align 8
  %v12738 = load i64, ptr %slot70, align 8
  %p12739 = inttoptr i64 %v12738 to ptr
  store i64 %v12737, ptr %p12739, align 8, !alias.scope !3, !noalias !4
  %v12740 = load i64, ptr %slot52, align 8
  %p12741 = inttoptr i64 %v12740 to ptr
  %ld12742 = load i64, ptr %p12741, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12742, ptr %slot2361, align 8
  %v12743 = load i64, ptr %slot2361, align 8
  %v12744 = load i64, ptr %slot71, align 8
  %p12745 = inttoptr i64 %v12744 to ptr
  store i64 %v12743, ptr %p12745, align 8, !alias.scope !3, !noalias !4
  %v12746 = load i64, ptr %slot90, align 8
  store i64 %v12746, ptr %slot2362, align 8
  %v12747 = load i64, ptr %slot2362, align 8
  %p12748 = inttoptr i64 %v12747 to ptr
  store i64 0, ptr %p12748, align 8, !alias.scope !3, !noalias !4
  %v12749 = load i64, ptr %slot2362, align 8
  %p12751 = inttoptr i64 %v12749 to ptr
  %gep12752 = getelementptr i8, ptr %p12751, i64 8
  %op12750 = ptrtoint ptr %gep12752 to i64
  store i64 %op12750, ptr %slot2363, align 8
  %v12753 = load i64, ptr %slot2363, align 8
  %p12754 = inttoptr i64 %v12753 to ptr
  store i64 0, ptr %p12754, align 8, !alias.scope !3, !noalias !4
  %v12755 = load i64, ptr %slot2362, align 8
  %p12756 = inttoptr i64 %v12755 to ptr
  store i32 3, ptr %p12756, align 4, !alias.scope !3, !noalias !4
  %v12757 = load i64, ptr %slot36, align 8
  %p12758 = inttoptr i64 %v12757 to ptr
  store i32 1, ptr %p12758, align 4, !alias.scope !3, !noalias !4
  %v12759 = load i64, ptr %slot71, align 8
  store i64 %v12759, ptr %slot2364, align 8
  %v12760 = load i64, ptr %slot2362, align 8
  %p12762 = inttoptr i64 %v12760 to ptr
  %gep12763 = getelementptr i8, ptr %p12762, i64 8
  %op12761 = ptrtoint ptr %gep12763 to i64
  store i64 %op12761, ptr %slot2365, align 8
  %v12764 = load i64, ptr %slot97, align 8
  store i64 %v12764, ptr %slot2366, align 8
  %v12765 = load i64, ptr %slot2364, align 8
  %p12766 = inttoptr i64 %v12765 to ptr
  %ld12767 = load i64, ptr %p12766, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12767, ptr %slot2367, align 8
  %v12768 = load i64, ptr %slot2367, align 8
  %v12769 = load i64, ptr %slot2365, align 8
  %p12770 = inttoptr i64 %v12769 to ptr
  store i64 %v12768, ptr %p12770, align 8, !alias.scope !3, !noalias !4
  %v12771 = load i64, ptr %slot2362, align 8
  %v12772 = load i64, ptr %slot71, align 8
  %p12773 = inttoptr i64 %v12772 to ptr
  store i64 %v12771, ptr %p12773, align 8, !alias.scope !3, !noalias !4
  %v12774 = load i64, ptr %slot69, align 8
  %p12775 = inttoptr i64 %v12774 to ptr
  %ld12776 = load i64, ptr %p12775, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12776, ptr %slot2368, align 8
  %v12777 = load i64, ptr %slot70, align 8
  %p12778 = inttoptr i64 %v12777 to ptr
  %ld12779 = load i64, ptr %p12778, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12779, ptr %slot2369, align 8
  %v12780 = load i64, ptr %slot71, align 8
  %p12781 = inttoptr i64 %v12780 to ptr
  %ld12782 = load i64, ptr %p12781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12782, ptr %slot2370, align 8
  %v12783 = load i64, ptr %slot1, align 8
  %v12784 = load i64, ptr %slot2368, align 8
  %v12785 = load i64, ptr %slot2369, align 8
  %v12786 = load i64, ptr %slot2370, align 8
  %call12787 = call i64 @myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8(i64 %v12783, i64 %v12784, i64 %v12785, i64 %v12786) nomerge, !dbg !236
  store i64 %call12787, ptr %slot2371, align 8
  %v12788 = load i64, ptr %slot2371, align 8
  %v12789 = load i64, ptr %slot69, align 8
  %p12790 = inttoptr i64 %v12789 to ptr
  store i64 %v12788, ptr %p12790, align 8, !alias.scope !3, !noalias !4
  %v12791 = load i64, ptr %slot28, align 8
  %p12792 = inttoptr i64 %v12791 to ptr
  %ld12793 = load i32, ptr %p12792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12793, ptr %slot2372, align 8
  %v12794 = load i32, ptr %slot2372, align 8
  %cv12795 = zext i32 %v12794 to i64
  %cond12796 = icmp ne i64 %cv12795, 0
  br i1 %cond12796, label %bb_rcslotdrop3526, label %bb_rcslotdone3526
bb_rcslotdrop3526:
  %v12797 = load i64, ptr %slot28, align 8
  %p12798 = inttoptr i64 %v12797 to ptr
  store i32 0, ptr %p12798, align 4, !alias.scope !3, !noalias !4
  %v12799 = load i64, ptr %slot37, align 8
  store i64 %v12799, ptr %slot2373, align 8
  %v12800 = load i64, ptr %slot29, align 8
  %p12801 = inttoptr i64 %v12800 to ptr
  %ld12802 = load i32, ptr %p12801, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12802, ptr %slot2374, align 8
  %v12803 = load i32, ptr %slot2374, align 8
  %op12804 = and i32 %v12803, 28
  store i32 %op12804, ptr %slot2375, align 8
  %v12805 = load i32, ptr %slot2375, align 8
  %cv12806 = zext i32 %v12805 to i64
  %cond12807 = icmp ne i64 %cv12806, 0
  br i1 %cond12807, label %bb_rcslotrole3526, label %bb_rcslotowner3526
bb_rcslotrole3526:
  %v12808 = load i64, ptr %slot96, align 8
  store i64 %v12808, ptr %slot2376, align 8
  %v12809 = load i64, ptr %slot2376, align 8
  %v12810 = load i64, ptr %slot2373, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12809, i64 %v12810) nomerge, !dbg !236
  br label %bb_rcslotdone3526
bb_rcslotowner3526:
  %v12811 = load i64, ptr %slot96, align 8
  store i64 %v12811, ptr %slot2377, align 8
  %v12812 = load i64, ptr %slot2377, align 8
  %v12813 = load i64, ptr %slot2373, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12812, i64 %v12813) nomerge, !dbg !236
  br label %bb_rcslotdone3526
bb_rcslotdone3526:
  %v12814 = load i64, ptr %slot46, align 8
  %p12815 = inttoptr i64 %v12814 to ptr
  %ld12816 = load i64, ptr %p12815, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12816, ptr %slot2378, align 8
  %v12817 = load i64, ptr %slot2378, align 8
  %op12818 = add i64 %v12817, 32
  store i64 %op12818, ptr %slot2379, align 8
  %v12819 = load i64, ptr %slot68, align 8
  store i64 %v12819, ptr %slot2380, align 8
  %v12820 = load i64, ptr %slot2380, align 8
  %v12821 = load i64, ptr %slot2379, align 8
  %p12822 = inttoptr i64 %v12820 to ptr
  %p12823 = inttoptr i64 %v12821 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12823, ptr %p12822, i64 208, i1 false), !alias.scope !10000000
  %v12824 = load i64, ptr %slot2380, align 8
  %p12825 = inttoptr i64 %v12824 to ptr
  call void @llvm.memset.p0.i64(ptr %p12825, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !238
  %v12826 = load i64, ptr %slot26, align 8
  %p12827 = inttoptr i64 %v12826 to ptr
  store i32 0, ptr %p12827, align 4, !alias.scope !3, !noalias !4
  %v12828 = load i64, ptr %slot69, align 8
  %p12829 = inttoptr i64 %v12828 to ptr
  store i64 0, ptr %p12829, align 8, !alias.scope !3, !noalias !4
  %v12830 = load i64, ptr %slot69, align 8
  %p12831 = inttoptr i64 %v12830 to ptr
  store i64 0, ptr %p12831, align 8, !alias.scope !3, !noalias !4
  %v12832 = load i64, ptr %slot91, align 8
  store i64 %v12832, ptr %slot2381, align 8
  %v12833 = load i64, ptr %slot2381, align 8
  %p12834 = inttoptr i64 %v12833 to ptr
  store i64 0, ptr %p12834, align 8, !alias.scope !3, !noalias !4
  %v12835 = load i64, ptr %slot2381, align 8
  %p12837 = inttoptr i64 %v12835 to ptr
  %gep12838 = getelementptr i8, ptr %p12837, i64 8
  %op12836 = ptrtoint ptr %gep12838 to i64
  store i64 %op12836, ptr %slot2382, align 8
  %v12839 = load i64, ptr %slot2382, align 8
  %p12840 = inttoptr i64 %v12839 to ptr
  store i64 0, ptr %p12840, align 8, !alias.scope !3, !noalias !4
  %v12841 = load i64, ptr %slot2381, align 8
  %p12843 = inttoptr i64 %v12841 to ptr
  %gep12844 = getelementptr i8, ptr %p12843, i64 16
  %op12842 = ptrtoint ptr %gep12844 to i64
  store i64 %op12842, ptr %slot2383, align 8
  %v12845 = load i64, ptr %slot2383, align 8
  %p12846 = inttoptr i64 %v12845 to ptr
  store i64 0, ptr %p12846, align 8, !alias.scope !3, !noalias !4
  %v12847 = load i64, ptr %slot2381, align 8
  %p12848 = inttoptr i64 %v12847 to ptr
  store i32 0, ptr %p12848, align 4, !alias.scope !3, !noalias !4
  %v12849 = load i64, ptr %slot36, align 8
  %p12850 = inttoptr i64 %v12849 to ptr
  store i32 1, ptr %p12850, align 4, !alias.scope !3, !noalias !4
  %v12851 = load i64, ptr %slot69, align 8
  store i64 %v12851, ptr %slot2384, align 8
  %v12852 = load i64, ptr %slot2381, align 8
  %p12854 = inttoptr i64 %v12852 to ptr
  %gep12855 = getelementptr i8, ptr %p12854, i64 8
  %op12853 = ptrtoint ptr %gep12855 to i64
  store i64 %op12853, ptr %slot2385, align 8
  %v12856 = load i64, ptr %slot97, align 8
  store i64 %v12856, ptr %slot2386, align 8
  store i64 0, ptr %slot2387, align 8
  %v12857 = load i64, ptr %slot2381, align 8
  %v12858 = load i64, ptr %slot69, align 8
  %p12859 = inttoptr i64 %v12858 to ptr
  store i64 %v12857, ptr %p12859, align 8, !alias.scope !3, !noalias !4
  %v12860 = load i64, ptr %slot69, align 8
  %p12861 = inttoptr i64 %v12860 to ptr
  %ld12862 = load i64, ptr %p12861, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12862, ptr %slot2388, align 8
  %v12863 = load i64, ptr %slot37, align 8
  store i64 %v12863, ptr %slot2389, align 8
  %v12864 = load i64, ptr %slot2388, align 8
  %v12865 = load i64, ptr %slot2389, align 8
  %p12866 = inttoptr i64 %v12864 to ptr
  %p12867 = inttoptr i64 %v12865 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p12867, ptr %p12866, i64 24, i1 false)
  %v12868 = load i64, ptr %slot29, align 8
  %p12869 = inttoptr i64 %v12868 to ptr
  store i32 2, ptr %p12869, align 4, !alias.scope !3, !noalias !4
  %v12870 = load i64, ptr %slot28, align 8
  %p12871 = inttoptr i64 %v12870 to ptr
  store i32 1, ptr %p12871, align 4, !alias.scope !3, !noalias !4
  %v12872 = load i64, ptr %slot2389, align 8
  %v12873 = load i64, ptr %slot69, align 8
  %p12874 = inttoptr i64 %v12873 to ptr
  store i64 %v12872, ptr %p12874, align 8, !alias.scope !3, !noalias !4
  %v12875 = load i64, ptr %slot69, align 8
  %p12876 = inttoptr i64 %v12875 to ptr
  %ld12877 = load i64, ptr %p12876, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12877, ptr %slot2390, align 8
  %v12878 = load i64, ptr %slot69, align 8
  %p12879 = inttoptr i64 %v12878 to ptr
  %ld12880 = load i64, ptr %p12879, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12880, ptr %slot2391, align 8
  %v12881 = load i64, ptr %slot41, align 8
  store i64 %v12881, ptr %slot2392, align 8
  %v12882 = load i64, ptr %slot97, align 8
  store i64 %v12882, ptr %slot2393, align 8
  %v12883 = load i64, ptr %slot96, align 8
  %v12884 = load i64, ptr %slot2392, align 8
  %v12885 = load i64, ptr %slot2391, align 8
  %v12886 = load i64, ptr %slot2393, align 8
  %cv12887 = trunc i64 %v12886 to i32
  %call12888 = call i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64 %v12883, i64 %v12884, i64 %v12885, i32 %cv12887) nomerge, !dbg !240
  store i32 %call12888, ptr %slot2394, align 8
  %v12889 = load i32, ptr %slot2394, align 8
  %cv12890 = zext i32 %v12889 to i64
  %cond12891 = icmp ne i64 %cv12890, 0
  br i1 %cond12891, label %bb_rcsuccess3555, label %bb_rcfailure3555
bb_rcfailure3555:
  %v12892 = load i64, ptr %slot96, align 8
  %p12893 = inttoptr i64 %v12892 to ptr
  %call12894 = call i32 @myl_rc_take_failure(ptr %p12893) nomerge, !dbg !240
  store i32 %call12894, ptr %slot2395, align 8
  %v12895 = load i64, ptr %slot1, align 8
  %p12896 = inttoptr i64 %v12895 to ptr
  %v12897 = load i32, ptr %slot2395, align 8
  %call12898 = call i32 @myl_qbe_rc_status(ptr %p12896, i32 %v12897) nomerge, !dbg !240
  store i32 %call12898, ptr %slot2396, align 8
  br label %bb_failure
bb_rcsuccess3555:
  %v12899 = load i64, ptr %slot28, align 8
  %p12900 = inttoptr i64 %v12899 to ptr
  store i32 0, ptr %p12900, align 4, !alias.scope !3, !noalias !4
  %v12901 = load i64, ptr %slot35, align 8
  %p12902 = inttoptr i64 %v12901 to ptr
  store i32 2, ptr %p12902, align 4, !alias.scope !3, !noalias !4
  %v12903 = load i64, ptr %slot34, align 8
  %p12904 = inttoptr i64 %v12903 to ptr
  store i32 1, ptr %p12904, align 4, !alias.scope !3, !noalias !4
  %v12905 = load i64, ptr %slot41, align 8
  store i64 %v12905, ptr %slot2397, align 8
  %v12906 = load i64, ptr %slot34, align 8
  %p12907 = inttoptr i64 %v12906 to ptr
  store i32 0, ptr %p12907, align 4, !alias.scope !3, !noalias !4
  %v12908 = load i64, ptr %slot43, align 8
  %p12910 = inttoptr i64 %v12908 to ptr
  %gep12911 = getelementptr i8, ptr %p12910, i64 24
  %op12909 = ptrtoint ptr %gep12911 to i64
  store i64 %op12909, ptr %slot2398, align 8
  %v12912 = load i64, ptr %slot2398, align 8
  %p12913 = inttoptr i64 %v12912 to ptr
  %ld12914 = load i32, ptr %p12913, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12914, ptr %slot2399, align 8
  %v12915 = load i32, ptr %slot2399, align 8
  %cv12916 = zext i32 %v12915 to i64
  %cond12917 = icmp ne i64 %cv12916, 0
  br i1 %cond12917, label %bb_rcscopesopen3565, label %bb_rcscopesclosed3565
bb_rcscopesopen3565:
  %v12918 = load i64, ptr %slot45, align 8
  %p12920 = inttoptr i64 %v12918 to ptr
  %gep12921 = getelementptr i8, ptr %p12920, i64 0
  %op12919 = ptrtoint ptr %gep12921 to i64
  store i64 %op12919, ptr %slot2400, align 8
  %v12922 = load i64, ptr %slot43, align 8
  %v12923 = load i64, ptr %slot2400, align 8
  %p12924 = inttoptr i64 %v12923 to ptr
  store i64 %v12922, ptr %p12924, align 8, !alias.scope !3, !noalias !4
  %v12925 = load i64, ptr %slot1, align 8
  %p12926 = inttoptr i64 %v12925 to ptr
  %v12927 = load i64, ptr %slot45, align 8
  %p12928 = inttoptr i64 %v12927 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p12926, ptr %p12928, i64 1) nomerge, !dbg !240
  br label %bb_rcscopesclosed3565
bb_rcscopesclosed3565:
  %v12929 = load i64, ptr %slot28, align 8
  %p12930 = inttoptr i64 %v12929 to ptr
  %ld12931 = load i32, ptr %p12930, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12931, ptr %slot2401, align 8
  %v12932 = load i32, ptr %slot2401, align 8
  %cv12933 = zext i32 %v12932 to i64
  %cond12934 = icmp ne i64 %cv12933, 0
  br i1 %cond12934, label %bb_rcslotdrop3569, label %bb_rcslotdone3569
bb_rcslotdrop3569:
  %v12935 = load i64, ptr %slot28, align 8
  %p12936 = inttoptr i64 %v12935 to ptr
  store i32 0, ptr %p12936, align 4, !alias.scope !3, !noalias !4
  %v12937 = load i64, ptr %slot37, align 8
  store i64 %v12937, ptr %slot2402, align 8
  %v12938 = load i64, ptr %slot29, align 8
  %p12939 = inttoptr i64 %v12938 to ptr
  %ld12940 = load i32, ptr %p12939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12940, ptr %slot2403, align 8
  %v12941 = load i32, ptr %slot2403, align 8
  %op12942 = and i32 %v12941, 28
  store i32 %op12942, ptr %slot2404, align 8
  %v12943 = load i32, ptr %slot2404, align 8
  %cv12944 = zext i32 %v12943 to i64
  %cond12945 = icmp ne i64 %cv12944, 0
  br i1 %cond12945, label %bb_rcslotrole3569, label %bb_rcslotowner3569
bb_rcslotrole3569:
  %v12946 = load i64, ptr %slot96, align 8
  store i64 %v12946, ptr %slot2405, align 8
  %v12947 = load i64, ptr %slot2405, align 8
  %v12948 = load i64, ptr %slot2402, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v12947, i64 %v12948) nomerge, !dbg !240
  br label %bb_rcslotdone3569
bb_rcslotowner3569:
  %v12949 = load i64, ptr %slot96, align 8
  store i64 %v12949, ptr %slot2406, align 8
  %v12950 = load i64, ptr %slot2406, align 8
  %v12951 = load i64, ptr %slot2402, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v12950, i64 %v12951) nomerge, !dbg !240
  br label %bb_rcslotdone3569
bb_rcslotdone3569:
  %v12952 = load i64, ptr %slot26, align 8
  %p12953 = inttoptr i64 %v12952 to ptr
  %ld12954 = load i32, ptr %p12953, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12954, ptr %slot2407, align 8
  %v12955 = load i32, ptr %slot2407, align 8
  %cv12956 = zext i32 %v12955 to i64
  %cond12957 = icmp ne i64 %cv12956, 0
  br i1 %cond12957, label %bb_rcslotdrop3596, label %bb_rcslotdone3596
bb_rcslotdrop3596:
  %v12958 = load i64, ptr %slot26, align 8
  %p12959 = inttoptr i64 %v12958 to ptr
  store i32 0, ptr %p12959, align 4, !alias.scope !3, !noalias !4
  %v12960 = load i64, ptr %slot68, align 8
  store i64 %v12960, ptr %slot2408, align 8
  %v12961 = load i64, ptr %slot27, align 8
  %p12962 = inttoptr i64 %v12961 to ptr
  %ld12963 = load i32, ptr %p12962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12963, ptr %slot2409, align 8
  %v12964 = load i32, ptr %slot2409, align 8
  %op12965 = and i32 %v12964, 28
  store i32 %op12965, ptr %slot2410, align 8
  %v12966 = load i32, ptr %slot2410, align 8
  %cv12967 = zext i32 %v12966 to i64
  %cond12968 = icmp ne i64 %cv12967, 0
  br i1 %cond12968, label %bb_rcslotrole3596, label %bb_rcslotowner3596
bb_rcslotrole3596:
  %v12969 = load i64, ptr %slot96, align 8
  store i64 %v12969, ptr %slot2411, align 8
  %v12970 = load i64, ptr %slot2411, align 8
  %v12971 = load i64, ptr %slot2408, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v12970, i64 %v12971) nomerge, !dbg !240
  br label %bb_rcslotdone3596
bb_rcslotowner3596:
  %v12972 = load i64, ptr %slot96, align 8
  store i64 %v12972, ptr %slot2412, align 8
  %v12973 = load i64, ptr %slot2412, align 8
  %v12974 = load i64, ptr %slot2408, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v12973, i64 %v12974) nomerge, !dbg !240
  br label %bb_rcslotdone3596
bb_rcslotdone3596:
  %v12975 = load i64, ptr %slot24, align 8
  %p12976 = inttoptr i64 %v12975 to ptr
  %ld12977 = load i32, ptr %p12976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12977, ptr %slot2413, align 8
  %v12978 = load i32, ptr %slot2413, align 8
  %cv12979 = zext i32 %v12978 to i64
  %cond12980 = icmp ne i64 %cv12979, 0
  br i1 %cond12980, label %bb_rcslotdrop3605, label %bb_rcslotdone3605
bb_rcslotdrop3605:
  %v12981 = load i64, ptr %slot24, align 8
  %p12982 = inttoptr i64 %v12981 to ptr
  store i32 0, ptr %p12982, align 4, !alias.scope !3, !noalias !4
  %v12983 = load i64, ptr %slot67, align 8
  store i64 %v12983, ptr %slot2414, align 8
  %v12984 = load i64, ptr %slot25, align 8
  %p12985 = inttoptr i64 %v12984 to ptr
  %ld12986 = load i32, ptr %p12985, align 4, !alias.scope !3, !noalias !4
  store i32 %ld12986, ptr %slot2415, align 8
  %v12987 = load i32, ptr %slot2415, align 8
  %op12988 = and i32 %v12987, 28
  store i32 %op12988, ptr %slot2416, align 8
  %v12989 = load i32, ptr %slot2416, align 8
  %cv12990 = zext i32 %v12989 to i64
  %cond12991 = icmp ne i64 %cv12990, 0
  br i1 %cond12991, label %bb_rcslotrole3605, label %bb_rcslotowner3605
bb_rcslotrole3605:
  %v12992 = load i64, ptr %slot96, align 8
  store i64 %v12992, ptr %slot2417, align 8
  %v12993 = load i64, ptr %slot2414, align 8
  %p12994 = inttoptr i64 %v12993 to ptr
  %ld12995 = load i64, ptr %p12994, align 8, !alias.scope !3, !noalias !4
  store i64 %ld12995, ptr %slot2418, align 8
  %v12996 = load i64, ptr %slot2418, align 8
  %cmp12997 = icmp ne i64 %v12996, 0
  %cv12998 = zext i1 %cmp12997 to i32
  store i32 %cv12998, ptr %slot2419, align 8
  %v12999 = load i32, ptr %slot2419, align 8
  %cv13000 = zext i32 %v12999 to i64
  %cond13001 = icmp ne i64 %cv13000, 0
  br i1 %cond13001, label %bb_rcgnn3621, label %bb_rcgdone3621
bb_rcgnn3621:
  %v13002 = load i64, ptr %slot2418, align 8
  %op13003 = sub i64 %v13002, 16
  store i64 %op13003, ptr %slot2420, align 8
  %v13004 = load i64, ptr %slot2418, align 8
  %p13005 = inttoptr i64 %v13004 to ptr
  %rgep13006 = getelementptr i8, ptr %p13005, i64 -16
  %ld13007 = load i64, ptr %rgep13006, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13007, ptr %slot2421, align 8
  %v13008 = load i64, ptr %slot2421, align 8
  %op13009 = and i64 %v13008, 4611686018427387906
  store i64 %op13009, ptr %slot2422, align 8
  %v13010 = load i64, ptr %slot2422, align 8
  %cmp13011 = icmp ne i64 %v13010, 0
  %cv13012 = zext i1 %cmp13011 to i32
  store i32 %cv13012, ptr %slot2423, align 8
  %v13013 = load i32, ptr %slot2423, align 8
  %cv13014 = zext i32 %v13013 to i64
  %cond13015 = icmp ne i64 %cv13014, 0
  br i1 %cond13015, label %bb_rcgclear3621, label %bb_rcgcounted3621
bb_rcgcounted3621:
  %v13016 = load i64, ptr %slot2418, align 8
  %op13017 = sub i64 %v13016, 24
  store i64 %op13017, ptr %slot2424, align 8
  %v13018 = load i64, ptr %slot2418, align 8
  %p13019 = inttoptr i64 %v13018 to ptr
  %rgep13020 = getelementptr i8, ptr %p13019, i64 -24
  %ld13021 = load i64, ptr %rgep13020, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13021, ptr %slot2425, align 8
  %v13022 = load i64, ptr %slot2425, align 8
  %op13023 = sub i64 %v13022, 1
  store i64 %op13023, ptr %slot2426, align 8
  %v13024 = load i64, ptr %slot2426, align 8
  %cmp13025 = icmp eq i64 %v13024, 0
  %cv13026 = zext i1 %cmp13025 to i32
  store i32 %cv13026, ptr %slot2427, align 8
  %v13027 = load i32, ptr %slot2427, align 8
  %cv13028 = zext i32 %v13027 to i64
  %cond13029 = icmp ne i64 %cv13028, 0
  br i1 %cond13029, label %bb_rcglast3621, label %bb_rcgdec3621
bb_rcglast3621:
  %v13030 = load i64, ptr %slot2418, align 8
  %op13031 = sub i64 %v13030, 32
  store i64 %op13031, ptr %slot2428, align 8
  %v13032 = load i64, ptr %slot2418, align 8
  %p13033 = inttoptr i64 %v13032 to ptr
  %rgep13034 = getelementptr i8, ptr %p13033, i64 -32
  %ld13035 = load i64, ptr %rgep13034, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13035, ptr %slot2429, align 8
  %v13036 = load i64, ptr %slot2429, align 8
  %cmp13037 = icmp ne i64 %v13036, 0
  %cv13038 = zext i1 %cmp13037 to i32
  store i32 %cv13038, ptr %slot2430, align 8
  %v13039 = load i32, ptr %slot2430, align 8
  %cv13040 = zext i32 %v13039 to i64
  %cond13041 = icmp ne i64 %cv13040, 0
  br i1 %cond13041, label %bb_rcgdec3621, label %bb_rcgslow3621
bb_rcgslow3621:
  %v13042 = load i64, ptr %slot2417, align 8
  %v13043 = load i64, ptr %slot2414, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v13042, i64 %v13043) nomerge, !dbg !240
  br label %bb_rcgdone3621
bb_rcgdec3621:
  %v13044 = load i64, ptr %slot2426, align 8
  %v13045 = load i64, ptr %slot2418, align 8
  %p13046 = inttoptr i64 %v13045 to ptr
  %rgep13047 = getelementptr i8, ptr %p13046, i64 -24
  store i64 %v13044, ptr %rgep13047, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3621
bb_rcgclear3621:
  %v13048 = load i64, ptr %slot2414, align 8
  %p13049 = inttoptr i64 %v13048 to ptr
  store i64 0, ptr %p13049, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3621
bb_rcgdone3621:
  br label %bb_rcslotdone3605
bb_rcslotowner3605:
  %v13050 = load i64, ptr %slot96, align 8
  store i64 %v13050, ptr %slot2431, align 8
  %v13051 = load i64, ptr %slot2414, align 8
  %p13052 = inttoptr i64 %v13051 to ptr
  %ld13053 = load i64, ptr %p13052, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13053, ptr %slot2432, align 8
  %v13054 = load i64, ptr %slot2432, align 8
  %cmp13055 = icmp ne i64 %v13054, 0
  %cv13056 = zext i1 %cmp13055 to i32
  store i32 %cv13056, ptr %slot2433, align 8
  %v13057 = load i32, ptr %slot2433, align 8
  %cv13058 = zext i32 %v13057 to i64
  %cond13059 = icmp ne i64 %cv13058, 0
  br i1 %cond13059, label %bb_rcgnn3636, label %bb_rcgdone3636
bb_rcgnn3636:
  %v13060 = load i64, ptr %slot2432, align 8
  %op13061 = sub i64 %v13060, 16
  store i64 %op13061, ptr %slot2434, align 8
  %v13062 = load i64, ptr %slot2432, align 8
  %p13063 = inttoptr i64 %v13062 to ptr
  %rgep13064 = getelementptr i8, ptr %p13063, i64 -16
  %ld13065 = load i64, ptr %rgep13064, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13065, ptr %slot2435, align 8
  %v13066 = load i64, ptr %slot2435, align 8
  %op13067 = and i64 %v13066, 4611686018427387906
  store i64 %op13067, ptr %slot2436, align 8
  %v13068 = load i64, ptr %slot2436, align 8
  %cmp13069 = icmp ne i64 %v13068, 0
  %cv13070 = zext i1 %cmp13069 to i32
  store i32 %cv13070, ptr %slot2437, align 8
  %v13071 = load i32, ptr %slot2437, align 8
  %cv13072 = zext i32 %v13071 to i64
  %cond13073 = icmp ne i64 %cv13072, 0
  br i1 %cond13073, label %bb_rcgclear3636, label %bb_rcgcounted3636
bb_rcgcounted3636:
  %v13074 = load i64, ptr %slot2432, align 8
  %op13075 = sub i64 %v13074, 32
  store i64 %op13075, ptr %slot2438, align 8
  %v13076 = load i64, ptr %slot2432, align 8
  %p13077 = inttoptr i64 %v13076 to ptr
  %rgep13078 = getelementptr i8, ptr %p13077, i64 -32
  %ld13079 = load i64, ptr %rgep13078, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13079, ptr %slot2439, align 8
  %v13080 = load i64, ptr %slot2439, align 8
  %op13081 = sub i64 %v13080, 1
  store i64 %op13081, ptr %slot2440, align 8
  %v13082 = load i64, ptr %slot2440, align 8
  %cmp13083 = icmp eq i64 %v13082, 0
  %cv13084 = zext i1 %cmp13083 to i32
  store i32 %cv13084, ptr %slot2441, align 8
  %v13085 = load i32, ptr %slot2441, align 8
  %cv13086 = zext i32 %v13085 to i64
  %cond13087 = icmp ne i64 %cv13086, 0
  br i1 %cond13087, label %bb_rcglast3636, label %bb_rcgdec3636
bb_rcglast3636:
  %v13088 = load i64, ptr %slot2432, align 8
  %op13089 = sub i64 %v13088, 24
  store i64 %op13089, ptr %slot2442, align 8
  %v13090 = load i64, ptr %slot2432, align 8
  %p13091 = inttoptr i64 %v13090 to ptr
  %rgep13092 = getelementptr i8, ptr %p13091, i64 -24
  %ld13093 = load i64, ptr %rgep13092, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13093, ptr %slot2443, align 8
  %v13094 = load i64, ptr %slot2443, align 8
  %cmp13095 = icmp ne i64 %v13094, 0
  %cv13096 = zext i1 %cmp13095 to i32
  store i32 %cv13096, ptr %slot2444, align 8
  %v13097 = load i32, ptr %slot2444, align 8
  %cv13098 = zext i32 %v13097 to i64
  %cond13099 = icmp ne i64 %cv13098, 0
  br i1 %cond13099, label %bb_rcgdec3636, label %bb_rcgslow3636
bb_rcgslow3636:
  %v13100 = load i64, ptr %slot2431, align 8
  %v13101 = load i64, ptr %slot2414, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v13100, i64 %v13101) nomerge, !dbg !240
  br label %bb_rcgdone3636
bb_rcgdec3636:
  %v13102 = load i64, ptr %slot2440, align 8
  %v13103 = load i64, ptr %slot2432, align 8
  %p13104 = inttoptr i64 %v13103 to ptr
  %rgep13105 = getelementptr i8, ptr %p13104, i64 -32
  store i64 %v13102, ptr %rgep13105, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3636
bb_rcgclear3636:
  %v13106 = load i64, ptr %slot2414, align 8
  %p13107 = inttoptr i64 %v13106 to ptr
  store i64 0, ptr %p13107, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3636
bb_rcgdone3636:
  br label %bb_rcslotdone3605
bb_rcslotdone3605:
  %v13108 = load i64, ptr %slot22, align 8
  %p13109 = inttoptr i64 %v13108 to ptr
  %ld13110 = load i32, ptr %p13109, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13110, ptr %slot2445, align 8
  %v13111 = load i32, ptr %slot2445, align 8
  %cv13112 = zext i32 %v13111 to i64
  %cond13113 = icmp ne i64 %cv13112, 0
  br i1 %cond13113, label %bb_rcslotdrop3642, label %bb_rcslotdone3642
bb_rcslotdrop3642:
  %v13114 = load i64, ptr %slot22, align 8
  %p13115 = inttoptr i64 %v13114 to ptr
  store i32 0, ptr %p13115, align 4, !alias.scope !3, !noalias !4
  %v13116 = load i64, ptr %slot66, align 8
  store i64 %v13116, ptr %slot2446, align 8
  %v13117 = load i64, ptr %slot23, align 8
  %p13118 = inttoptr i64 %v13117 to ptr
  %ld13119 = load i32, ptr %p13118, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13119, ptr %slot2447, align 8
  %v13120 = load i32, ptr %slot2447, align 8
  %op13121 = and i32 %v13120, 28
  store i32 %op13121, ptr %slot2448, align 8
  %v13122 = load i32, ptr %slot2448, align 8
  %cv13123 = zext i32 %v13122 to i64
  %cond13124 = icmp ne i64 %cv13123, 0
  br i1 %cond13124, label %bb_rcslotrole3642, label %bb_rcslotowner3642
bb_rcslotrole3642:
  %v13125 = load i64, ptr %slot96, align 8
  store i64 %v13125, ptr %slot2449, align 8
  %v13126 = load i64, ptr %slot2446, align 8
  %p13127 = inttoptr i64 %v13126 to ptr
  %ld13128 = load i64, ptr %p13127, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13128, ptr %slot2450, align 8
  %v13129 = load i64, ptr %slot2450, align 8
  %cmp13130 = icmp ne i64 %v13129, 0
  %cv13131 = zext i1 %cmp13130 to i32
  store i32 %cv13131, ptr %slot2451, align 8
  %v13132 = load i32, ptr %slot2451, align 8
  %cv13133 = zext i32 %v13132 to i64
  %cond13134 = icmp ne i64 %cv13133, 0
  br i1 %cond13134, label %bb_rcgnn3658, label %bb_rcgdone3658
bb_rcgnn3658:
  %v13135 = load i64, ptr %slot2450, align 8
  %op13136 = sub i64 %v13135, 16
  store i64 %op13136, ptr %slot2452, align 8
  %v13137 = load i64, ptr %slot2450, align 8
  %p13138 = inttoptr i64 %v13137 to ptr
  %rgep13139 = getelementptr i8, ptr %p13138, i64 -16
  %ld13140 = load i64, ptr %rgep13139, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13140, ptr %slot2453, align 8
  %v13141 = load i64, ptr %slot2453, align 8
  %op13142 = and i64 %v13141, 4611686018427387906
  store i64 %op13142, ptr %slot2454, align 8
  %v13143 = load i64, ptr %slot2454, align 8
  %cmp13144 = icmp ne i64 %v13143, 0
  %cv13145 = zext i1 %cmp13144 to i32
  store i32 %cv13145, ptr %slot2455, align 8
  %v13146 = load i32, ptr %slot2455, align 8
  %cv13147 = zext i32 %v13146 to i64
  %cond13148 = icmp ne i64 %cv13147, 0
  br i1 %cond13148, label %bb_rcgclear3658, label %bb_rcgcounted3658
bb_rcgcounted3658:
  %v13149 = load i64, ptr %slot2450, align 8
  %op13150 = sub i64 %v13149, 24
  store i64 %op13150, ptr %slot2456, align 8
  %v13151 = load i64, ptr %slot2450, align 8
  %p13152 = inttoptr i64 %v13151 to ptr
  %rgep13153 = getelementptr i8, ptr %p13152, i64 -24
  %ld13154 = load i64, ptr %rgep13153, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13154, ptr %slot2457, align 8
  %v13155 = load i64, ptr %slot2457, align 8
  %op13156 = sub i64 %v13155, 1
  store i64 %op13156, ptr %slot2458, align 8
  %v13157 = load i64, ptr %slot2458, align 8
  %cmp13158 = icmp eq i64 %v13157, 0
  %cv13159 = zext i1 %cmp13158 to i32
  store i32 %cv13159, ptr %slot2459, align 8
  %v13160 = load i32, ptr %slot2459, align 8
  %cv13161 = zext i32 %v13160 to i64
  %cond13162 = icmp ne i64 %cv13161, 0
  br i1 %cond13162, label %bb_rcglast3658, label %bb_rcgdec3658
bb_rcglast3658:
  %v13163 = load i64, ptr %slot2450, align 8
  %op13164 = sub i64 %v13163, 32
  store i64 %op13164, ptr %slot2460, align 8
  %v13165 = load i64, ptr %slot2450, align 8
  %p13166 = inttoptr i64 %v13165 to ptr
  %rgep13167 = getelementptr i8, ptr %p13166, i64 -32
  %ld13168 = load i64, ptr %rgep13167, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13168, ptr %slot2461, align 8
  %v13169 = load i64, ptr %slot2461, align 8
  %cmp13170 = icmp ne i64 %v13169, 0
  %cv13171 = zext i1 %cmp13170 to i32
  store i32 %cv13171, ptr %slot2462, align 8
  %v13172 = load i32, ptr %slot2462, align 8
  %cv13173 = zext i32 %v13172 to i64
  %cond13174 = icmp ne i64 %cv13173, 0
  br i1 %cond13174, label %bb_rcgdec3658, label %bb_rcgslow3658
bb_rcgslow3658:
  %v13175 = load i64, ptr %slot2449, align 8
  %v13176 = load i64, ptr %slot2446, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64 %v13175, i64 %v13176) nomerge, !dbg !240
  br label %bb_rcgdone3658
bb_rcgdec3658:
  %v13177 = load i64, ptr %slot2458, align 8
  %v13178 = load i64, ptr %slot2450, align 8
  %p13179 = inttoptr i64 %v13178 to ptr
  %rgep13180 = getelementptr i8, ptr %p13179, i64 -24
  store i64 %v13177, ptr %rgep13180, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3658
bb_rcgclear3658:
  %v13181 = load i64, ptr %slot2446, align 8
  %p13182 = inttoptr i64 %v13181 to ptr
  store i64 0, ptr %p13182, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3658
bb_rcgdone3658:
  br label %bb_rcslotdone3642
bb_rcslotowner3642:
  %v13183 = load i64, ptr %slot96, align 8
  store i64 %v13183, ptr %slot2463, align 8
  %v13184 = load i64, ptr %slot2446, align 8
  %p13185 = inttoptr i64 %v13184 to ptr
  %ld13186 = load i64, ptr %p13185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13186, ptr %slot2464, align 8
  %v13187 = load i64, ptr %slot2464, align 8
  %cmp13188 = icmp ne i64 %v13187, 0
  %cv13189 = zext i1 %cmp13188 to i32
  store i32 %cv13189, ptr %slot2465, align 8
  %v13190 = load i32, ptr %slot2465, align 8
  %cv13191 = zext i32 %v13190 to i64
  %cond13192 = icmp ne i64 %cv13191, 0
  br i1 %cond13192, label %bb_rcgnn3673, label %bb_rcgdone3673
bb_rcgnn3673:
  %v13193 = load i64, ptr %slot2464, align 8
  %op13194 = sub i64 %v13193, 16
  store i64 %op13194, ptr %slot2466, align 8
  %v13195 = load i64, ptr %slot2464, align 8
  %p13196 = inttoptr i64 %v13195 to ptr
  %rgep13197 = getelementptr i8, ptr %p13196, i64 -16
  %ld13198 = load i64, ptr %rgep13197, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13198, ptr %slot2467, align 8
  %v13199 = load i64, ptr %slot2467, align 8
  %op13200 = and i64 %v13199, 4611686018427387906
  store i64 %op13200, ptr %slot2468, align 8
  %v13201 = load i64, ptr %slot2468, align 8
  %cmp13202 = icmp ne i64 %v13201, 0
  %cv13203 = zext i1 %cmp13202 to i32
  store i32 %cv13203, ptr %slot2469, align 8
  %v13204 = load i32, ptr %slot2469, align 8
  %cv13205 = zext i32 %v13204 to i64
  %cond13206 = icmp ne i64 %cv13205, 0
  br i1 %cond13206, label %bb_rcgclear3673, label %bb_rcgcounted3673
bb_rcgcounted3673:
  %v13207 = load i64, ptr %slot2464, align 8
  %op13208 = sub i64 %v13207, 32
  store i64 %op13208, ptr %slot2470, align 8
  %v13209 = load i64, ptr %slot2464, align 8
  %p13210 = inttoptr i64 %v13209 to ptr
  %rgep13211 = getelementptr i8, ptr %p13210, i64 -32
  %ld13212 = load i64, ptr %rgep13211, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13212, ptr %slot2471, align 8
  %v13213 = load i64, ptr %slot2471, align 8
  %op13214 = sub i64 %v13213, 1
  store i64 %op13214, ptr %slot2472, align 8
  %v13215 = load i64, ptr %slot2472, align 8
  %cmp13216 = icmp eq i64 %v13215, 0
  %cv13217 = zext i1 %cmp13216 to i32
  store i32 %cv13217, ptr %slot2473, align 8
  %v13218 = load i32, ptr %slot2473, align 8
  %cv13219 = zext i32 %v13218 to i64
  %cond13220 = icmp ne i64 %cv13219, 0
  br i1 %cond13220, label %bb_rcglast3673, label %bb_rcgdec3673
bb_rcglast3673:
  %v13221 = load i64, ptr %slot2464, align 8
  %op13222 = sub i64 %v13221, 24
  store i64 %op13222, ptr %slot2474, align 8
  %v13223 = load i64, ptr %slot2464, align 8
  %p13224 = inttoptr i64 %v13223 to ptr
  %rgep13225 = getelementptr i8, ptr %p13224, i64 -24
  %ld13226 = load i64, ptr %rgep13225, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13226, ptr %slot2475, align 8
  %v13227 = load i64, ptr %slot2475, align 8
  %cmp13228 = icmp ne i64 %v13227, 0
  %cv13229 = zext i1 %cmp13228 to i32
  store i32 %cv13229, ptr %slot2476, align 8
  %v13230 = load i32, ptr %slot2476, align 8
  %cv13231 = zext i32 %v13230 to i64
  %cond13232 = icmp ne i64 %cv13231, 0
  br i1 %cond13232, label %bb_rcgdec3673, label %bb_rcgslow3673
bb_rcgslow3673:
  %v13233 = load i64, ptr %slot2463, align 8
  %v13234 = load i64, ptr %slot2446, align 8
  call void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64 %v13233, i64 %v13234) nomerge, !dbg !240
  br label %bb_rcgdone3673
bb_rcgdec3673:
  %v13235 = load i64, ptr %slot2472, align 8
  %v13236 = load i64, ptr %slot2464, align 8
  %p13237 = inttoptr i64 %v13236 to ptr
  %rgep13238 = getelementptr i8, ptr %p13237, i64 -32
  store i64 %v13235, ptr %rgep13238, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3673
bb_rcgclear3673:
  %v13239 = load i64, ptr %slot2446, align 8
  %p13240 = inttoptr i64 %v13239 to ptr
  store i64 0, ptr %p13240, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3673
bb_rcgdone3673:
  br label %bb_rcslotdone3642
bb_rcslotdone3642:
  %v13241 = load i64, ptr %slot20, align 8
  %p13242 = inttoptr i64 %v13241 to ptr
  %ld13243 = load i32, ptr %p13242, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13243, ptr %slot2477, align 8
  %v13244 = load i32, ptr %slot2477, align 8
  %cv13245 = zext i32 %v13244 to i64
  %cond13246 = icmp ne i64 %cv13245, 0
  br i1 %cond13246, label %bb_rcslotdrop3679, label %bb_rcslotdone3679
bb_rcslotdrop3679:
  %v13247 = load i64, ptr %slot20, align 8
  %p13248 = inttoptr i64 %v13247 to ptr
  store i32 0, ptr %p13248, align 4, !alias.scope !3, !noalias !4
  %v13249 = load i64, ptr %slot65, align 8
  store i64 %v13249, ptr %slot2478, align 8
  %v13250 = load i64, ptr %slot21, align 8
  %p13251 = inttoptr i64 %v13250 to ptr
  %ld13252 = load i32, ptr %p13251, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13252, ptr %slot2479, align 8
  %v13253 = load i32, ptr %slot2479, align 8
  %op13254 = and i32 %v13253, 28
  store i32 %op13254, ptr %slot2480, align 8
  %v13255 = load i32, ptr %slot2480, align 8
  %cv13256 = zext i32 %v13255 to i64
  %cond13257 = icmp ne i64 %cv13256, 0
  br i1 %cond13257, label %bb_rcslotrole3679, label %bb_rcslotowner3679
bb_rcslotrole3679:
  %v13258 = load i64, ptr %slot96, align 8
  store i64 %v13258, ptr %slot2481, align 8
  %v13259 = load i64, ptr %slot2478, align 8
  %p13260 = inttoptr i64 %v13259 to ptr
  %ld13261 = load i64, ptr %p13260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13261, ptr %slot2482, align 8
  %v13262 = load i64, ptr %slot2482, align 8
  %cmp13263 = icmp ne i64 %v13262, 0
  %cv13264 = zext i1 %cmp13263 to i32
  store i32 %cv13264, ptr %slot2483, align 8
  %v13265 = load i32, ptr %slot2483, align 8
  %cv13266 = zext i32 %v13265 to i64
  %cond13267 = icmp ne i64 %cv13266, 0
  br i1 %cond13267, label %bb_rcgnn3695, label %bb_rcgdone3695
bb_rcgnn3695:
  %v13268 = load i64, ptr %slot2482, align 8
  %op13269 = sub i64 %v13268, 16
  store i64 %op13269, ptr %slot2484, align 8
  %v13270 = load i64, ptr %slot2482, align 8
  %p13271 = inttoptr i64 %v13270 to ptr
  %rgep13272 = getelementptr i8, ptr %p13271, i64 -16
  %ld13273 = load i64, ptr %rgep13272, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13273, ptr %slot2485, align 8
  %v13274 = load i64, ptr %slot2485, align 8
  %op13275 = and i64 %v13274, 4611686018427387906
  store i64 %op13275, ptr %slot2486, align 8
  %v13276 = load i64, ptr %slot2486, align 8
  %cmp13277 = icmp ne i64 %v13276, 0
  %cv13278 = zext i1 %cmp13277 to i32
  store i32 %cv13278, ptr %slot2487, align 8
  %v13279 = load i32, ptr %slot2487, align 8
  %cv13280 = zext i32 %v13279 to i64
  %cond13281 = icmp ne i64 %cv13280, 0
  br i1 %cond13281, label %bb_rcgclear3695, label %bb_rcgcounted3695
bb_rcgcounted3695:
  %v13282 = load i64, ptr %slot2482, align 8
  %op13283 = sub i64 %v13282, 24
  store i64 %op13283, ptr %slot2488, align 8
  %v13284 = load i64, ptr %slot2482, align 8
  %p13285 = inttoptr i64 %v13284 to ptr
  %rgep13286 = getelementptr i8, ptr %p13285, i64 -24
  %ld13287 = load i64, ptr %rgep13286, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13287, ptr %slot2489, align 8
  %v13288 = load i64, ptr %slot2489, align 8
  %op13289 = sub i64 %v13288, 1
  store i64 %op13289, ptr %slot2490, align 8
  %v13290 = load i64, ptr %slot2490, align 8
  %cmp13291 = icmp eq i64 %v13290, 0
  %cv13292 = zext i1 %cmp13291 to i32
  store i32 %cv13292, ptr %slot2491, align 8
  %v13293 = load i32, ptr %slot2491, align 8
  %cv13294 = zext i32 %v13293 to i64
  %cond13295 = icmp ne i64 %cv13294, 0
  br i1 %cond13295, label %bb_rcglast3695, label %bb_rcgdec3695
bb_rcglast3695:
  %v13296 = load i64, ptr %slot2482, align 8
  %op13297 = sub i64 %v13296, 32
  store i64 %op13297, ptr %slot2492, align 8
  %v13298 = load i64, ptr %slot2482, align 8
  %p13299 = inttoptr i64 %v13298 to ptr
  %rgep13300 = getelementptr i8, ptr %p13299, i64 -32
  %ld13301 = load i64, ptr %rgep13300, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13301, ptr %slot2493, align 8
  %v13302 = load i64, ptr %slot2493, align 8
  %cmp13303 = icmp ne i64 %v13302, 0
  %cv13304 = zext i1 %cmp13303 to i32
  store i32 %cv13304, ptr %slot2494, align 8
  %v13305 = load i32, ptr %slot2494, align 8
  %cv13306 = zext i32 %v13305 to i64
  %cond13307 = icmp ne i64 %cv13306, 0
  br i1 %cond13307, label %bb_rcgdec3695, label %bb_rcgslow3695
bb_rcgslow3695:
  %v13308 = load i64, ptr %slot2481, align 8
  %v13309 = load i64, ptr %slot2478, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64 %v13308, i64 %v13309) nomerge, !dbg !240
  br label %bb_rcgdone3695
bb_rcgdec3695:
  %v13310 = load i64, ptr %slot2490, align 8
  %v13311 = load i64, ptr %slot2482, align 8
  %p13312 = inttoptr i64 %v13311 to ptr
  %rgep13313 = getelementptr i8, ptr %p13312, i64 -24
  store i64 %v13310, ptr %rgep13313, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3695
bb_rcgclear3695:
  %v13314 = load i64, ptr %slot2478, align 8
  %p13315 = inttoptr i64 %v13314 to ptr
  store i64 0, ptr %p13315, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3695
bb_rcgdone3695:
  br label %bb_rcslotdone3679
bb_rcslotowner3679:
  %v13316 = load i64, ptr %slot96, align 8
  store i64 %v13316, ptr %slot2495, align 8
  %v13317 = load i64, ptr %slot2478, align 8
  %p13318 = inttoptr i64 %v13317 to ptr
  %ld13319 = load i64, ptr %p13318, align 8, !alias.scope !3, !noalias !4
  store i64 %ld13319, ptr %slot2496, align 8
  %v13320 = load i64, ptr %slot2496, align 8
  %cmp13321 = icmp ne i64 %v13320, 0
  %cv13322 = zext i1 %cmp13321 to i32
  store i32 %cv13322, ptr %slot2497, align 8
  %v13323 = load i32, ptr %slot2497, align 8
  %cv13324 = zext i32 %v13323 to i64
  %cond13325 = icmp ne i64 %cv13324, 0
  br i1 %cond13325, label %bb_rcgnn3710, label %bb_rcgdone3710
bb_rcgnn3710:
  %v13326 = load i64, ptr %slot2496, align 8
  %op13327 = sub i64 %v13326, 16
  store i64 %op13327, ptr %slot2498, align 8
  %v13328 = load i64, ptr %slot2496, align 8
  %p13329 = inttoptr i64 %v13328 to ptr
  %rgep13330 = getelementptr i8, ptr %p13329, i64 -16
  %ld13331 = load i64, ptr %rgep13330, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13331, ptr %slot2499, align 8
  %v13332 = load i64, ptr %slot2499, align 8
  %op13333 = and i64 %v13332, 4611686018427387906
  store i64 %op13333, ptr %slot2500, align 8
  %v13334 = load i64, ptr %slot2500, align 8
  %cmp13335 = icmp ne i64 %v13334, 0
  %cv13336 = zext i1 %cmp13335 to i32
  store i32 %cv13336, ptr %slot2501, align 8
  %v13337 = load i32, ptr %slot2501, align 8
  %cv13338 = zext i32 %v13337 to i64
  %cond13339 = icmp ne i64 %cv13338, 0
  br i1 %cond13339, label %bb_rcgclear3710, label %bb_rcgcounted3710
bb_rcgcounted3710:
  %v13340 = load i64, ptr %slot2496, align 8
  %op13341 = sub i64 %v13340, 32
  store i64 %op13341, ptr %slot2502, align 8
  %v13342 = load i64, ptr %slot2496, align 8
  %p13343 = inttoptr i64 %v13342 to ptr
  %rgep13344 = getelementptr i8, ptr %p13343, i64 -32
  %ld13345 = load i64, ptr %rgep13344, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13345, ptr %slot2503, align 8
  %v13346 = load i64, ptr %slot2503, align 8
  %op13347 = sub i64 %v13346, 1
  store i64 %op13347, ptr %slot2504, align 8
  %v13348 = load i64, ptr %slot2504, align 8
  %cmp13349 = icmp eq i64 %v13348, 0
  %cv13350 = zext i1 %cmp13349 to i32
  store i32 %cv13350, ptr %slot2505, align 8
  %v13351 = load i32, ptr %slot2505, align 8
  %cv13352 = zext i32 %v13351 to i64
  %cond13353 = icmp ne i64 %cv13352, 0
  br i1 %cond13353, label %bb_rcglast3710, label %bb_rcgdec3710
bb_rcglast3710:
  %v13354 = load i64, ptr %slot2496, align 8
  %op13355 = sub i64 %v13354, 24
  store i64 %op13355, ptr %slot2506, align 8
  %v13356 = load i64, ptr %slot2496, align 8
  %p13357 = inttoptr i64 %v13356 to ptr
  %rgep13358 = getelementptr i8, ptr %p13357, i64 -24
  %ld13359 = load i64, ptr %rgep13358, align 8, !alias.scope !9, !noalias !10
  store i64 %ld13359, ptr %slot2507, align 8
  %v13360 = load i64, ptr %slot2507, align 8
  %cmp13361 = icmp ne i64 %v13360, 0
  %cv13362 = zext i1 %cmp13361 to i32
  store i32 %cv13362, ptr %slot2508, align 8
  %v13363 = load i32, ptr %slot2508, align 8
  %cv13364 = zext i32 %v13363 to i64
  %cond13365 = icmp ne i64 %cv13364, 0
  br i1 %cond13365, label %bb_rcgdec3710, label %bb_rcgslow3710
bb_rcgslow3710:
  %v13366 = load i64, ptr %slot2495, align 8
  %v13367 = load i64, ptr %slot2478, align 8
  call void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64 %v13366, i64 %v13367) nomerge, !dbg !240
  br label %bb_rcgdone3710
bb_rcgdec3710:
  %v13368 = load i64, ptr %slot2504, align 8
  %v13369 = load i64, ptr %slot2496, align 8
  %p13370 = inttoptr i64 %v13369 to ptr
  %rgep13371 = getelementptr i8, ptr %p13370, i64 -32
  store i64 %v13368, ptr %rgep13371, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear3710
bb_rcgclear3710:
  %v13372 = load i64, ptr %slot2478, align 8
  %p13373 = inttoptr i64 %v13372 to ptr
  store i64 0, ptr %p13373, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone3710
bb_rcgdone3710:
  br label %bb_rcslotdone3679
bb_rcslotdone3679:
  %v13374 = load i64, ptr %slot18, align 8
  %p13375 = inttoptr i64 %v13374 to ptr
  %ld13376 = load i32, ptr %p13375, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13376, ptr %slot2509, align 8
  %v13377 = load i32, ptr %slot2509, align 8
  %cv13378 = zext i32 %v13377 to i64
  %cond13379 = icmp ne i64 %cv13378, 0
  br i1 %cond13379, label %bb_rcslotdrop3734, label %bb_rcslotdone3734
bb_rcslotdrop3734:
  %v13380 = load i64, ptr %slot18, align 8
  %p13381 = inttoptr i64 %v13380 to ptr
  store i32 0, ptr %p13381, align 4, !alias.scope !3, !noalias !4
  %v13382 = load i64, ptr %slot64, align 8
  store i64 %v13382, ptr %slot2510, align 8
  %v13383 = load i64, ptr %slot19, align 8
  %p13384 = inttoptr i64 %v13383 to ptr
  %ld13385 = load i32, ptr %p13384, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13385, ptr %slot2511, align 8
  %v13386 = load i32, ptr %slot2511, align 8
  %op13387 = and i32 %v13386, 28
  store i32 %op13387, ptr %slot2512, align 8
  %v13388 = load i32, ptr %slot2512, align 8
  %cv13389 = zext i32 %v13388 to i64
  %cond13390 = icmp ne i64 %cv13389, 0
  br i1 %cond13390, label %bb_rcslotrole3734, label %bb_rcslotowner3734
bb_rcslotrole3734:
  %v13391 = load i64, ptr %slot96, align 8
  store i64 %v13391, ptr %slot2513, align 8
  %v13392 = load i64, ptr %slot2513, align 8
  %v13393 = load i64, ptr %slot2510, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v13392, i64 %v13393) nomerge, !dbg !240
  br label %bb_rcslotdone3734
bb_rcslotowner3734:
  %v13394 = load i64, ptr %slot96, align 8
  store i64 %v13394, ptr %slot2514, align 8
  %v13395 = load i64, ptr %slot2514, align 8
  %v13396 = load i64, ptr %slot2510, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v13395, i64 %v13396) nomerge, !dbg !240
  br label %bb_rcslotdone3734
bb_rcslotdone3734:
  %v13397 = load i64, ptr %slot16, align 8
  %p13398 = inttoptr i64 %v13397 to ptr
  %ld13399 = load i32, ptr %p13398, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13399, ptr %slot2515, align 8
  %v13400 = load i32, ptr %slot2515, align 8
  %cv13401 = zext i32 %v13400 to i64
  %cond13402 = icmp ne i64 %cv13401, 0
  br i1 %cond13402, label %bb_rcslotdrop3761, label %bb_rcslotdone3761
bb_rcslotdrop3761:
  %v13403 = load i64, ptr %slot16, align 8
  %p13404 = inttoptr i64 %v13403 to ptr
  store i32 0, ptr %p13404, align 4, !alias.scope !3, !noalias !4
  %v13405 = load i64, ptr %slot62, align 8
  store i64 %v13405, ptr %slot2516, align 8
  %v13406 = load i64, ptr %slot17, align 8
  %p13407 = inttoptr i64 %v13406 to ptr
  %ld13408 = load i32, ptr %p13407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13408, ptr %slot2517, align 8
  %v13409 = load i32, ptr %slot2517, align 8
  %op13410 = and i32 %v13409, 28
  store i32 %op13410, ptr %slot2518, align 8
  %v13411 = load i32, ptr %slot2518, align 8
  %cv13412 = zext i32 %v13411 to i64
  %cond13413 = icmp ne i64 %cv13412, 0
  br i1 %cond13413, label %bb_rcslotrole3761, label %bb_rcslotowner3761
bb_rcslotrole3761:
  %v13414 = load i64, ptr %slot96, align 8
  store i64 %v13414, ptr %slot2519, align 8
  %v13415 = load i64, ptr %slot2519, align 8
  %v13416 = load i64, ptr %slot2516, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v13415, i64 %v13416) nomerge, !dbg !240
  br label %bb_rcslotdone3761
bb_rcslotowner3761:
  %v13417 = load i64, ptr %slot96, align 8
  store i64 %v13417, ptr %slot2520, align 8
  %v13418 = load i64, ptr %slot2520, align 8
  %v13419 = load i64, ptr %slot2516, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v13418, i64 %v13419) nomerge, !dbg !240
  br label %bb_rcslotdone3761
bb_rcslotdone3761:
  %v13420 = load i64, ptr %slot14, align 8
  %p13421 = inttoptr i64 %v13420 to ptr
  %ld13422 = load i32, ptr %p13421, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13422, ptr %slot2521, align 8
  %v13423 = load i32, ptr %slot2521, align 8
  %cv13424 = zext i32 %v13423 to i64
  %cond13425 = icmp ne i64 %cv13424, 0
  br i1 %cond13425, label %bb_rcslotdrop3788, label %bb_rcslotdone3788
bb_rcslotdrop3788:
  %v13426 = load i64, ptr %slot14, align 8
  %p13427 = inttoptr i64 %v13426 to ptr
  store i32 0, ptr %p13427, align 4, !alias.scope !3, !noalias !4
  %v13428 = load i64, ptr %slot61, align 8
  store i64 %v13428, ptr %slot2522, align 8
  %v13429 = load i64, ptr %slot15, align 8
  %p13430 = inttoptr i64 %v13429 to ptr
  %ld13431 = load i32, ptr %p13430, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13431, ptr %slot2523, align 8
  %v13432 = load i32, ptr %slot2523, align 8
  %op13433 = and i32 %v13432, 28
  store i32 %op13433, ptr %slot2524, align 8
  %v13434 = load i32, ptr %slot2524, align 8
  %cv13435 = zext i32 %v13434 to i64
  %cond13436 = icmp ne i64 %cv13435, 0
  br i1 %cond13436, label %bb_rcslotrole3788, label %bb_rcslotowner3788
bb_rcslotrole3788:
  %v13437 = load i64, ptr %slot96, align 8
  store i64 %v13437, ptr %slot2525, align 8
  %v13438 = load i64, ptr %slot2525, align 8
  %v13439 = load i64, ptr %slot2522, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v13438, i64 %v13439) nomerge, !dbg !240
  br label %bb_rcslotdone3788
bb_rcslotowner3788:
  %v13440 = load i64, ptr %slot96, align 8
  store i64 %v13440, ptr %slot2526, align 8
  %v13441 = load i64, ptr %slot2526, align 8
  %v13442 = load i64, ptr %slot2522, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v13441, i64 %v13442) nomerge, !dbg !240
  br label %bb_rcslotdone3788
bb_rcslotdone3788:
  %v13443 = load i64, ptr %slot12, align 8
  %p13444 = inttoptr i64 %v13443 to ptr
  %ld13445 = load i32, ptr %p13444, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13445, ptr %slot2527, align 8
  %v13446 = load i32, ptr %slot2527, align 8
  %cv13447 = zext i32 %v13446 to i64
  %cond13448 = icmp ne i64 %cv13447, 0
  br i1 %cond13448, label %bb_rcslotdrop3815, label %bb_rcslotdone3815
bb_rcslotdrop3815:
  %v13449 = load i64, ptr %slot12, align 8
  %p13450 = inttoptr i64 %v13449 to ptr
  store i32 0, ptr %p13450, align 4, !alias.scope !3, !noalias !4
  %v13451 = load i64, ptr %slot59, align 8
  store i64 %v13451, ptr %slot2528, align 8
  %v13452 = load i64, ptr %slot13, align 8
  %p13453 = inttoptr i64 %v13452 to ptr
  %ld13454 = load i32, ptr %p13453, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13454, ptr %slot2529, align 8
  %v13455 = load i32, ptr %slot2529, align 8
  %op13456 = and i32 %v13455, 28
  store i32 %op13456, ptr %slot2530, align 8
  %v13457 = load i32, ptr %slot2530, align 8
  %cv13458 = zext i32 %v13457 to i64
  %cond13459 = icmp ne i64 %cv13458, 0
  br i1 %cond13459, label %bb_rcslotrole3815, label %bb_rcslotowner3815
bb_rcslotrole3815:
  %v13460 = load i64, ptr %slot96, align 8
  store i64 %v13460, ptr %slot2531, align 8
  %v13461 = load i64, ptr %slot2531, align 8
  %v13462 = load i64, ptr %slot2528, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v13461, i64 %v13462) nomerge, !dbg !240
  br label %bb_rcslotdone3815
bb_rcslotowner3815:
  %v13463 = load i64, ptr %slot96, align 8
  store i64 %v13463, ptr %slot2532, align 8
  %v13464 = load i64, ptr %slot2532, align 8
  %v13465 = load i64, ptr %slot2528, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v13464, i64 %v13465) nomerge, !dbg !240
  br label %bb_rcslotdone3815
bb_rcslotdone3815:
  %v13466 = load i64, ptr %slot10, align 8
  %p13467 = inttoptr i64 %v13466 to ptr
  %ld13468 = load i32, ptr %p13467, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13468, ptr %slot2533, align 8
  %v13469 = load i32, ptr %slot2533, align 8
  %cv13470 = zext i32 %v13469 to i64
  %cond13471 = icmp ne i64 %cv13470, 0
  br i1 %cond13471, label %bb_rcslotdrop3824, label %bb_rcslotdone3824
bb_rcslotdrop3824:
  %v13472 = load i64, ptr %slot10, align 8
  %p13473 = inttoptr i64 %v13472 to ptr
  store i32 0, ptr %p13473, align 4, !alias.scope !3, !noalias !4
  %v13474 = load i64, ptr %slot56, align 8
  store i64 %v13474, ptr %slot2534, align 8
  %v13475 = load i64, ptr %slot11, align 8
  %p13476 = inttoptr i64 %v13475 to ptr
  %ld13477 = load i32, ptr %p13476, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13477, ptr %slot2535, align 8
  %v13478 = load i32, ptr %slot2535, align 8
  %op13479 = and i32 %v13478, 28
  store i32 %op13479, ptr %slot2536, align 8
  %v13480 = load i32, ptr %slot2536, align 8
  %cv13481 = zext i32 %v13480 to i64
  %cond13482 = icmp ne i64 %cv13481, 0
  br i1 %cond13482, label %bb_rcslotrole3824, label %bb_rcslotowner3824
bb_rcslotrole3824:
  %v13483 = load i64, ptr %slot96, align 8
  store i64 %v13483, ptr %slot2537, align 8
  %v13484 = load i64, ptr %slot2537, align 8
  %v13485 = load i64, ptr %slot2534, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64 %v13484, i64 %v13485) nomerge, !dbg !240
  br label %bb_rcslotdone3824
bb_rcslotowner3824:
  %v13486 = load i64, ptr %slot96, align 8
  store i64 %v13486, ptr %slot2538, align 8
  %v13487 = load i64, ptr %slot2538, align 8
  %v13488 = load i64, ptr %slot2534, align 8
  call void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64 %v13487, i64 %v13488) nomerge, !dbg !240
  br label %bb_rcslotdone3824
bb_rcslotdone3824:
  %v13489 = load i64, ptr %slot8, align 8
  %p13490 = inttoptr i64 %v13489 to ptr
  %ld13491 = load i32, ptr %p13490, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13491, ptr %slot2539, align 8
  %v13492 = load i32, ptr %slot2539, align 8
  %cv13493 = zext i32 %v13492 to i64
  %cond13494 = icmp ne i64 %cv13493, 0
  br i1 %cond13494, label %bb_rcslotdrop3888, label %bb_rcslotdone3888
bb_rcslotdrop3888:
  %v13495 = load i64, ptr %slot8, align 8
  %p13496 = inttoptr i64 %v13495 to ptr
  store i32 0, ptr %p13496, align 4, !alias.scope !3, !noalias !4
  %v13497 = load i64, ptr %slot51, align 8
  store i64 %v13497, ptr %slot2540, align 8
  %v13498 = load i64, ptr %slot9, align 8
  %p13499 = inttoptr i64 %v13498 to ptr
  %ld13500 = load i32, ptr %p13499, align 4, !alias.scope !3, !noalias !4
  store i32 %ld13500, ptr %slot2541, align 8
  %v13501 = load i32, ptr %slot2541, align 8
  %op13502 = and i32 %v13501, 28
  store i32 %op13502, ptr %slot2542, align 8
  %v13503 = load i32, ptr %slot2542, align 8
  %cv13504 = zext i32 %v13503 to i64
  %cond13505 = icmp ne i64 %cv13504, 0
  br i1 %cond13505, label %bb_rcslotrole3888, label %bb_rcslotowner3888
bb_rcslotrole3888:
  %v13506 = load i64, ptr %slot96, align 8
  store i64 %v13506, ptr %slot2543, align 8
  %v13507 = load i64, ptr %slot2543, align 8
  %v13508 = load i64, ptr %slot2540, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v13507, i64 %v13508) nomerge, !dbg !240
  br label %bb_rcslotdone3888
bb_rcslotowner3888:
  %v13509 = load i64, ptr %slot96, align 8
  store i64 %v13509, ptr %slot2544, align 8
  %v13510 = load i64, ptr %slot2544, align 8
  %v13511 = load i64, ptr %slot2540, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v13510, i64 %v13511) nomerge, !dbg !240
  br label %bb_rcslotdone3888
bb_rcslotdone3888:
  %v13512 = load i64, ptr %slot2397, align 8
  %p13513 = inttoptr i64 %v13512 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p13513, i64 24, i1 false)
  ret void
bb_failure:
  %v13514 = load i64, ptr %slot7, align 8
  %p13515 = inttoptr i64 %v13514 to ptr
  call void @llvm.memset.p0.i64(ptr %p13515, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !240
  %v13516 = load i64, ptr %slot7, align 8
  %p13517 = inttoptr i64 %v13516 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p13517, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v13518 = load i64, ptr %slot7, align 8
  %p13519 = inttoptr i64 %v13518 to ptr
  call void @llvm.memset.p0.i64(ptr %p13519, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !240
  %v13520 = load i64, ptr %slot7, align 8
  %p13521 = inttoptr i64 %v13520 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p13521, i64 24, i1 false)
  ret void
}

@myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd_meta = external global i8, align 8
@myl_lit_651dfa874c87674e57d05784fbb331bf215d6ec2b7d4c57db6383d02b47d316a = external global i8, align 8
@myl_lit_73f49e3ebb26fac34a9ebd5051f9be52f8082f7cb414e46e76a3cbfe34871e25 = external global i8, align 8
@myl_lit_8d330aa2f416754a391eaf7715dfedb3b3b4f6f34dd9cc9ef16b81d95dfd3df3 = external global i8, align 8
@myl_native_list_header_type = external global i8, align 8
@myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b = external global i8, align 8
@myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a = external global i8, align 8
@myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare void @myl_f_05c0395f99e3d95f11848a23036537b613947380b701bcd66a0fa57cf17796f3(ptr sret([24 x i8]) align 8, i64, i64, i64, i64)
declare void @myl_f_0771312dfac681874ee229bebf205436b287de7366435531af48ff800c4cce48(ptr sret([32 x i8]) align 8, i64, i64, i64)
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare i64 @myl_f_33e96fe9cb0dad36eb060c89cc0eac8c30f67b59cc2b5a47425887e8980d401c(i64, i64, i64, i64)
declare void @myl_f_3ea6e9e7e7e3f3c99e8bd3ee87e61bb9473edc3368079bda3cc736a65b3decbc(ptr sret([24 x i8]) align 8, i64, i64, i64, i64, i64, i64, i64)
declare i64 @myl_f_41c41f2d4af2b92fbce9f84fed600873f3972351a560e660f999c7dd62117af8(i64, i64, i64, i64)
declare void @myl_f_55118dea72715056d11e62240a4d5f7be4aeebfddc319f59a70a489a3a8b0e54(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare i64 @myl_f_6993cfd5bc46d9d696adcc139c626f2b677f81bea8031cc740fa79e8da2d676e(i64, i64, i64)
declare { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb_rc_borrow(i64, i64, i64)
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare i64 @myl_f_a0ff172e9e450785632a25c55eafac31e4cfca2cc56a9728097332089f64b651(i64, i64, i64)
declare i64 @myl_f_a146740a06e5fa23640f1f72b70e36e5a89eb686546e75b2a5fa1ac552d2f888(i64, i64, i64, i64, i64)
declare { i64, i64 } @myl_f_a1ee89ef02f5de3a0549ceef8b403f960b5d820e5be22eacf42a3abf03f1c216(i64)
declare void @myl_f_e8c749c10445dc457f5775bb824164c0e2bada77ed66473babb0974281a32427(ptr sret([24 x i8]) align 8, i64, i64, i64, i64)
declare i64 @myl_f_ea97dd36e4e0ea42e46ce6a891c9a00cafb686a8c9a27c77fe327a84d70301d7(i64, i64)
declare ptr @myl_native_bytes_encode(ptr, ptr)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare ptr @myl_native_text_join(ptr, ptr, ptr)
declare ptr @myl_native_text_scalar(ptr, ptr, i32)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_cast(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare void @myl_qbe_fail_normalized_index_bounds(ptr, i64, i64) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i32 @myl_qbe_rc_unique_local(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_drop(i64, i64)
declare void @myl_t_1ca39ac918178cb6d21e4d894cf1bad7f4b058d5b48f5646eb1c4f427db8f3b6_rcg_unloan(i64, i64)
declare void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_drop(i64, i64)
declare i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1fa64ff08badc7715febe33a527d577ee990f92c692f5fb9ca94bc8ae8b2241b_rcg_unloan(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_6b6297bad5aab74518ce0d5425e1487ea3b0af713c21ba4b6f4440e5c98b2a9c_rcg_drop(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_take(i64, i64, i64, i32)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_drop(i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_loan(i64, i64, i64)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_take(i64, i64, i64, i32)
declare void @myl_t_81d71c98b196ce876b8748e8f5e1c439a764a7854aeb5e4ef7865d0716f2ecef_rcg_unloan(i64, i64)
declare void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_drop(i64, i64)
declare void @myl_t_87bce22450ba1dd346902c88e84ed91c3923adff6d5e35cea4c79f65e06a12b6_rcg_unloan(i64, i64)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_drop(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_list_append(i64, i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_unloan(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_drop(i64, i64)
declare void @myl_t_a1fa53db408c85388cfd14badb361c2a89e74ce2a863fa83774cb6942b74317a_rcg_unloan(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_drop(i64, i64)
declare void @myl_t_a83873657e77deb1bf51281383ae925ccb1b4b6510284b93a36500031c0efc14_rcg_unloan(i64, i64)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_loan(i64, i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64, i64)
declare void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_drop(i64, i64)
declare void @myl_t_e222f1f965865b951d13601f59eae1d86ab238e1dcf4276a2e8a00f410a97332_rcg_unloan(i64, i64)
declare i32 @myl_t_f90b2531fe2edebbb3538bc221997b8a6ecd53794bf2c8b61b30685c25382939_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd", linkageName: "myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11990533637471774617, i64 0, !"myl_f_8a3ad538a89e847e949a93c76feecf4b941040e57a15bf658649b1bcdd82b4dd"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!116 = !DILocation(line: 3, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646575)
!118 = !DILocation(line: 5, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!120 = !DILocation(line: 7, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646615)
!122 = !DILocation(line: 10, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!124 = !DILocation(line: 15, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!126 = !DILocation(line: 16, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!130 = !DILocation(line: 18, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!132 = !DILocation(line: 30, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!134 = !DILocation(line: 37, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!136 = !DILocation(line: 38, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!138 = !DILocation(line: 39, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646911)
!140 = !DILocation(line: 47, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646927)
!142 = !DILocation(line: 49, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!144 = !DILocation(line: 53, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646983)
!146 = !DILocation(line: 56, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646999)
!148 = !DILocation(line: 58, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!150 = !DILocation(line: 59, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647015)
!152 = !DILocation(line: 60, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!154 = !DILocation(line: 63, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647047)
!156 = !DILocation(line: 64, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647063)
!158 = !DILocation(line: 66, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647095)
!160 = !DILocation(line: 70, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647103)
!162 = !DILocation(line: 71, column: 0, scope: !163)
!165 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647127)
!164 = !DILocation(line: 74, column: 0, scope: !165)
!167 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647143)
!166 = !DILocation(line: 76, column: 0, scope: !167)
!169 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647151)
!168 = !DILocation(line: 77, column: 0, scope: !169)
!171 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647175)
!170 = !DILocation(line: 80, column: 0, scope: !171)
!173 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647231)
!172 = !DILocation(line: 87, column: 0, scope: !173)
!175 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647327)
!174 = !DILocation(line: 99, column: 0, scope: !175)
!177 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647359)
!176 = !DILocation(line: 103, column: 0, scope: !177)
!179 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647423)
!178 = !DILocation(line: 111, column: 0, scope: !179)
!181 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647519)
!180 = !DILocation(line: 123, column: 0, scope: !181)
!183 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647551)
!182 = !DILocation(line: 127, column: 0, scope: !183)
!185 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647599)
!184 = !DILocation(line: 133, column: 0, scope: !185)
!187 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647695)
!186 = !DILocation(line: 145, column: 0, scope: !187)
!189 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647767)
!188 = !DILocation(line: 154, column: 0, scope: !189)
!191 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647783)
!190 = !DILocation(line: 156, column: 0, scope: !191)
!193 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647791)
!192 = !DILocation(line: 157, column: 0, scope: !193)
!195 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647807)
!194 = !DILocation(line: 159, column: 0, scope: !195)
!197 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647831)
!196 = !DILocation(line: 162, column: 0, scope: !197)
!199 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647863)
!198 = !DILocation(line: 166, column: 0, scope: !199)
!201 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647959)
!200 = !DILocation(line: 178, column: 0, scope: !201)
!203 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648007)
!202 = !DILocation(line: 184, column: 0, scope: !203)
!205 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648015)
!204 = !DILocation(line: 185, column: 0, scope: !205)
!207 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648031)
!206 = !DILocation(line: 187, column: 0, scope: !207)
!209 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648095)
!208 = !DILocation(line: 195, column: 0, scope: !209)
!211 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648111)
!210 = !DILocation(line: 197, column: 0, scope: !211)
!213 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648119)
!212 = !DILocation(line: 198, column: 0, scope: !213)
!215 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648135)
!214 = !DILocation(line: 200, column: 0, scope: !215)
!217 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648159)
!216 = !DILocation(line: 203, column: 0, scope: !217)
!219 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648167)
!218 = !DILocation(line: 204, column: 0, scope: !219)
!221 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648191)
!220 = !DILocation(line: 207, column: 0, scope: !221)
!223 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648215)
!222 = !DILocation(line: 210, column: 0, scope: !223)
!225 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648223)
!224 = !DILocation(line: 211, column: 0, scope: !225)
!227 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648231)
!226 = !DILocation(line: 212, column: 0, scope: !227)
!229 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648247)
!228 = !DILocation(line: 214, column: 0, scope: !229)
!231 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648255)
!230 = !DILocation(line: 215, column: 0, scope: !231)
!233 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648263)
!232 = !DILocation(line: 216, column: 0, scope: !233)
!235 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648287)
!234 = !DILocation(line: 219, column: 0, scope: !235)
!237 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648343)
!236 = !DILocation(line: 226, column: 0, scope: !237)
!239 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648439)
!238 = !DILocation(line: 238, column: 0, scope: !239)
!241 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186648479)
!240 = !DILocation(line: 243, column: 0, scope: !241)
