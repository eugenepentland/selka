target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd_rc_borrow(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v37 = load i64, ptr %slot1, align 8
  %op38 = add i64 %v37, 32
  store i64 %op38, ptr %slot4, align 8
  %mem39 = alloca i8, i64 40, align 8
  %ptr40 = ptrtoint ptr %mem39 to i64
  store i64 %ptr40, ptr %slot5, align 8
  %mem41 = alloca i8, i64 8, align 8
  %ptr42 = ptrtoint ptr %mem41 to i64
  store i64 %ptr42, ptr %slot6, align 8
  %mem43 = alloca i8, i64 8, align 8
  %ptr44 = ptrtoint ptr %mem43 to i64
  store i64 %ptr44, ptr %slot7, align 8
  %mem45 = alloca i8, i64 8, align 8
  %ptr46 = ptrtoint ptr %mem45 to i64
  store i64 %ptr46, ptr %slot8, align 8
  %mem47 = alloca i8, i64 8, align 8
  %ptr48 = ptrtoint ptr %mem47 to i64
  store i64 %ptr48, ptr %slot9, align 8
  %mem49 = alloca i8, i64 8, align 8
  %ptr50 = ptrtoint ptr %mem49 to i64
  store i64 %ptr50, ptr %slot10, align 8
  %mem51 = alloca i8, i64 8, align 8
  %ptr52 = ptrtoint ptr %mem51 to i64
  store i64 %ptr52, ptr %slot11, align 8
  %mem53 = alloca i8, i64 8, align 8
  %ptr54 = ptrtoint ptr %mem53 to i64
  store i64 %ptr54, ptr %slot12, align 8
  %mem55 = alloca i8, i64 8, align 8
  %ptr56 = ptrtoint ptr %mem55 to i64
  store i64 %ptr56, ptr %slot13, align 8
  %mem57 = alloca i8, i64 40, align 8
  %ptr58 = ptrtoint ptr %mem57 to i64
  store i64 %ptr58, ptr %slot14, align 8
  %v59 = load i64, ptr %slot2, align 8
  %v60 = load i64, ptr %slot6, align 8
  %p61 = inttoptr i64 %v60 to ptr
  store i64 %v59, ptr %p61, align 8, !alias.scope !3, !noalias !4
  %v62 = load i64, ptr %slot3, align 8
  %v63 = load i64, ptr %slot7, align 8
  %p64 = inttoptr i64 %v63 to ptr
  store i64 %v62, ptr %p64, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v65 = load i64, ptr %slot13, align 8
  store i64 %v65, ptr %slot15, align 8
  %v66 = load i64, ptr %slot15, align 8
  %p67 = inttoptr i64 %v66 to ptr
  store i32 38, ptr %p67, align 4, !alias.scope !3, !noalias !4
  %v68 = load i64, ptr %slot15, align 8
  %v69 = load i64, ptr %slot8, align 8
  %p70 = inttoptr i64 %v69 to ptr
  store i64 %v68, ptr %p70, align 8, !alias.scope !3, !noalias !4
  %v71 = load i64, ptr %slot6, align 8
  %p72 = inttoptr i64 %v71 to ptr
  %ld73 = load i64, ptr %p72, align 8, !alias.scope !3, !noalias !4
  store i64 %ld73, ptr %slot16, align 8
  %v74 = load i64, ptr %slot16, align 8
  %v75 = load i64, ptr %slot9, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 %v74, ptr %p76, align 8, !alias.scope !3, !noalias !4
  %v77 = load i64, ptr %slot9, align 8
  %p78 = inttoptr i64 %v77 to ptr
  %ld79 = load i64, ptr %p78, align 8, !alias.scope !3, !noalias !4
  store i64 %ld79, ptr %slot17, align 8
  %v80 = load i64, ptr %slot17, align 8
  %op81 = add i64 %v80, 8
  store i64 %op81, ptr %slot18, align 8
  %v82 = load i64, ptr %slot18, align 8
  %p83 = inttoptr i64 %v82 to ptr
  %ld84 = load i64, ptr %p83, align 8, !alias.scope !4, !noalias !3
  store i64 %ld84, ptr %slot19, align 8
  %v85 = load i64, ptr %slot19, align 8
  %v86 = load i64, ptr %slot9, align 8
  %p87 = inttoptr i64 %v86 to ptr
  store i64 %v85, ptr %p87, align 8, !alias.scope !3, !noalias !4
  %v88 = load i64, ptr %slot10, align 8
  %p89 = inttoptr i64 %v88 to ptr
  store i64 0, ptr %p89, align 8, !alias.scope !3, !noalias !4
  %v90 = load i64, ptr %slot6, align 8
  %p91 = inttoptr i64 %v90 to ptr
  %ld92 = load i64, ptr %p91, align 8, !alias.scope !3, !noalias !4
  store i64 %ld92, ptr %slot20, align 8
  %v93 = load i64, ptr %slot20, align 8
  %v94 = load i64, ptr %slot11, align 8
  %p95 = inttoptr i64 %v94 to ptr
  store i64 %v93, ptr %p95, align 8, !alias.scope !3, !noalias !4
  %v96 = load i64, ptr %slot11, align 8
  %p97 = inttoptr i64 %v96 to ptr
  %ld98 = load i64, ptr %p97, align 8, !alias.scope !3, !noalias !4
  store i64 %ld98, ptr %slot21, align 8
  %v99 = load i64, ptr %slot21, align 8
  %op100 = add i64 %v99, 24
  store i64 %op100, ptr %slot22, align 8
  %v101 = load i64, ptr %slot22, align 8
  %p102 = inttoptr i64 %v101 to ptr
  %ld103 = load i64, ptr %p102, align 8, !alias.scope !4, !noalias !3
  store i64 %ld103, ptr %slot23, align 8
  %v104 = load i64, ptr %slot23, align 8
  %v105 = load i64, ptr %slot11, align 8
  %p106 = inttoptr i64 %v105 to ptr
  store i64 %v104, ptr %p106, align 8, !alias.scope !3, !noalias !4
  %v107 = load i64, ptr %slot7, align 8
  %p108 = inttoptr i64 %v107 to ptr
  %ld109 = load i64, ptr %p108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld109, ptr %slot24, align 8
  %v110 = load i64, ptr %slot24, align 8
  %v111 = load i64, ptr %slot12, align 8
  %p112 = inttoptr i64 %v111 to ptr
  store i64 %v110, ptr %p112, align 8, !alias.scope !3, !noalias !4
  %v113 = load i64, ptr %slot14, align 8
  store i64 %v113, ptr %slot25, align 8
  %v114 = load i64, ptr %slot25, align 8
  %p116 = inttoptr i64 %v114 to ptr
  %gep117 = getelementptr i8, ptr %p116, i64 0
  %op115 = ptrtoint ptr %gep117 to i64
  store i64 %op115, ptr %slot26, align 8
  %v118 = load i64, ptr %slot8, align 8
  %p119 = inttoptr i64 %v118 to ptr
  %ld120 = load i64, ptr %p119, align 8, !alias.scope !3, !noalias !4
  store i64 %ld120, ptr %slot27, align 8
  %v121 = load i64, ptr %slot27, align 8
  %v122 = load i64, ptr %slot26, align 8
  %p123 = inttoptr i64 %v121 to ptr
  %p124 = inttoptr i64 %v122 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p124, ptr %p123, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot25, align 8
  %p127 = inttoptr i64 %v125 to ptr
  %gep128 = getelementptr i8, ptr %p127, i64 8
  %op126 = ptrtoint ptr %gep128 to i64
  store i64 %op126, ptr %slot28, align 8
  %v129 = load i64, ptr %slot9, align 8
  %p130 = inttoptr i64 %v129 to ptr
  %ld131 = load i64, ptr %p130, align 8, !alias.scope !3, !noalias !4
  store i64 %ld131, ptr %slot29, align 8
  %v132 = load i64, ptr %slot29, align 8
  %v133 = load i64, ptr %slot28, align 8
  %p134 = inttoptr i64 %v133 to ptr
  store i64 %v132, ptr %p134, align 8, !alias.scope !3, !noalias !4
  %v135 = load i64, ptr %slot25, align 8
  %p137 = inttoptr i64 %v135 to ptr
  %gep138 = getelementptr i8, ptr %p137, i64 16
  %op136 = ptrtoint ptr %gep138 to i64
  store i64 %op136, ptr %slot30, align 8
  %v139 = load i64, ptr %slot10, align 8
  %p140 = inttoptr i64 %v139 to ptr
  %ld141 = load i64, ptr %p140, align 8, !alias.scope !3, !noalias !4
  store i64 %ld141, ptr %slot31, align 8
  %v142 = load i64, ptr %slot31, align 8
  %v143 = load i64, ptr %slot30, align 8
  %p144 = inttoptr i64 %v143 to ptr
  store i64 %v142, ptr %p144, align 8, !alias.scope !3, !noalias !4
  %v145 = load i64, ptr %slot25, align 8
  %p147 = inttoptr i64 %v145 to ptr
  %gep148 = getelementptr i8, ptr %p147, i64 24
  %op146 = ptrtoint ptr %gep148 to i64
  store i64 %op146, ptr %slot32, align 8
  %v149 = load i64, ptr %slot11, align 8
  %p150 = inttoptr i64 %v149 to ptr
  %ld151 = load i64, ptr %p150, align 8, !alias.scope !3, !noalias !4
  store i64 %ld151, ptr %slot33, align 8
  %v152 = load i64, ptr %slot33, align 8
  %v153 = load i64, ptr %slot32, align 8
  %p154 = inttoptr i64 %v153 to ptr
  store i64 %v152, ptr %p154, align 8, !alias.scope !3, !noalias !4
  %v155 = load i64, ptr %slot25, align 8
  %p157 = inttoptr i64 %v155 to ptr
  %gep158 = getelementptr i8, ptr %p157, i64 32
  %op156 = ptrtoint ptr %gep158 to i64
  store i64 %op156, ptr %slot34, align 8
  %v159 = load i64, ptr %slot12, align 8
  %p160 = inttoptr i64 %v159 to ptr
  %ld161 = load i64, ptr %p160, align 8, !alias.scope !3, !noalias !4
  store i64 %ld161, ptr %slot35, align 8
  %v162 = load i64, ptr %slot35, align 8
  %v163 = load i64, ptr %slot34, align 8
  %p164 = inttoptr i64 %v163 to ptr
  store i64 %v162, ptr %p164, align 8, !alias.scope !3, !noalias !4
  %v165 = load i64, ptr %slot25, align 8
  %v166 = load i64, ptr %slot8, align 8
  %p167 = inttoptr i64 %v166 to ptr
  store i64 %v165, ptr %p167, align 8, !alias.scope !3, !noalias !4
  %v168 = load i64, ptr %slot8, align 8
  %p169 = inttoptr i64 %v168 to ptr
  %ld170 = load i64, ptr %p169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld170, ptr %slot36, align 8
  %v171 = load i64, ptr %slot36, align 8
  %p172 = inttoptr i64 %v171 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p172, i64 40, i1 false)
  ret void
bb_failure:
  %v173 = load i64, ptr %slot5, align 8
  %p174 = inttoptr i64 %v173 to ptr
  call void @llvm.memset.p0.i64(ptr %p174, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v175 = load i64, ptr %slot5, align 8
  %p176 = inttoptr i64 %v175 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p176, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v177 = load i64, ptr %slot5, align 8
  %p178 = inttoptr i64 %v177 to ptr
  call void @llvm.memset.p0.i64(ptr %p178, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v179 = load i64, ptr %slot5, align 8
  %p180 = inttoptr i64 %v179 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p180, i64 40, i1 false)
  ret void
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd_rc_borrow", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd_rc_borrow", linkageName: "myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd_rc_borrow", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 9833133883469660946, i64 0, !"myl_f_2e06e9492cd8044f9d4aae9bbfd0ce1687ff9950c1796c04349de65c0b9e34cd_rc_borrow"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!110 = !DILocation(line: 9, column: 0, scope: !111)
