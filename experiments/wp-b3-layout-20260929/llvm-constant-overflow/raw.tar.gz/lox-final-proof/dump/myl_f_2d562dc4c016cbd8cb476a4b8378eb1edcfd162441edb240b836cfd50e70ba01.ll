target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01(ptr sret([24 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i32, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %callresult65 = alloca [24 x i8], align 8
  %slot66 = alloca i64, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i32, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i64, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i32, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i32, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i32, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i32, align 8
  %slot108 = alloca i32, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i32, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i64, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  %slot133 = alloca i64, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i64, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i64, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i32, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i32, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i32, align 8
  %slot149 = alloca i32, align 8
  %slot150 = alloca i64, align 8
  %slot151 = alloca i64, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i64, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i32, align 8
  %slot162 = alloca i64, align 8
  %slot163 = alloca i32, align 8
  %slot164 = alloca i32, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i64, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i64, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i64, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i32, align 8
  %slot176 = alloca i64, align 8
  %slot177 = alloca i32, align 8
  %slot178 = alloca i32, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i64, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i64, align 8
  %slot184 = alloca i64, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i64, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i32, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i64, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %callresult198 = alloca [16 x i8], align 8
  %slot199 = alloca i32, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i32, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i64, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i64, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i32, align 8
  %slot214 = alloca i32, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i32, align 8
  %slot220 = alloca i32, align 8
  %slot221 = alloca i64, align 8
  %slot222 = alloca i32, align 8
  %slot223 = alloca i32, align 8
  %slot224 = alloca i32, align 8
  %slot225 = alloca i32, align 8
  %slot226 = alloca i64, align 8
  %slot227 = alloca i32, align 8
  %slot228 = alloca i32, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i32, align 8
  %slot232 = alloca i64, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i64, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i64, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i64, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i32, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i64, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i32, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i32, align 8
  %slot253 = alloca i32, align 8
  %slot254 = alloca i32, align 8
  %slot255 = alloca i32, align 8
  %slot256 = alloca i64, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i64, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i32, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i32, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i64, align 8
  %slot266 = alloca i64, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i32, align 8
  %slot272 = alloca i32, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i32, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i64, align 8
  %slot277 = alloca i32, align 8
  %slot278 = alloca i32, align 8
  %slot279 = alloca i32, align 8
  %slot280 = alloca i64, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i32, align 8
  %slot283 = alloca i32, align 8
  %slot284 = alloca i32, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i64, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i32, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i64, align 8
  %slot291 = alloca i64, align 8
  %slot292 = alloca i64, align 8
  %slot293 = alloca i64, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i64, align 8
  %slot296 = alloca i64, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i32, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i32, align 8
  %slot302 = alloca i32, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i64, align 8
  %slot306 = alloca i64, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i64, align 8
  %slot309 = alloca i32, align 8
  %slot310 = alloca i32, align 8
  %slot311 = alloca i32, align 8
  %slot312 = alloca i32, align 8
  %slot313 = alloca i64, align 8
  %slot314 = alloca i64, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i32, align 8
  %slot317 = alloca i32, align 8
  %slot318 = alloca i64, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i32, align 8
  %slot321 = alloca i32, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i64, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i32, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i64, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i64, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i64, align 8
  %slot338 = alloca i64, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i64, align 8
  %slot341 = alloca i64, align 8
  %slot342 = alloca i64, align 8
  %slot343 = alloca i64, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i32, align 8
  %slot346 = alloca i32, align 8
  %slot347 = alloca i32, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i32, align 8
  %slot350 = alloca i64, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i64, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i32, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i32, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i64, align 8
  %slot360 = alloca i64, align 8
  %slot361 = alloca i32, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i32, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i64, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v373 = load i64, ptr %slot1, align 8
  %op374 = add i64 %v373, 32
  store i64 %op374, ptr %slot4, align 8
  %mem375 = alloca i8, i64 24, align 8
  %ptr376 = ptrtoint ptr %mem375 to i64
  store i64 %ptr376, ptr %slot5, align 8
  %mem377 = alloca i8, i64 8, align 8
  %ptr378 = ptrtoint ptr %mem377 to i64
  store i64 %ptr378, ptr %slot6, align 8
  %mem379 = alloca i8, i64 8, align 8
  %ptr380 = ptrtoint ptr %mem379 to i64
  store i64 %ptr380, ptr %slot7, align 8
  %mem381 = alloca i8, i64 8, align 8
  %ptr382 = ptrtoint ptr %mem381 to i64
  store i64 %ptr382, ptr %slot8, align 8
  %mem383 = alloca i8, i64 8, align 8
  %ptr384 = ptrtoint ptr %mem383 to i64
  store i64 %ptr384, ptr %slot9, align 8
  %mem385 = alloca i8, i64 8, align 8
  %ptr386 = ptrtoint ptr %mem385 to i64
  store i64 %ptr386, ptr %slot10, align 8
  %mem387 = alloca i8, i64 8, align 8
  %ptr388 = ptrtoint ptr %mem387 to i64
  store i64 %ptr388, ptr %slot11, align 8
  %mem389 = alloca i8, i64 8, align 8
  %ptr390 = ptrtoint ptr %mem389 to i64
  store i64 %ptr390, ptr %slot12, align 8
  %mem391 = alloca i8, i64 8, align 8
  %ptr392 = ptrtoint ptr %mem391 to i64
  store i64 %ptr392, ptr %slot13, align 8
  %mem393 = alloca i8, i64 8, align 8
  %ptr394 = ptrtoint ptr %mem393 to i64
  store i64 %ptr394, ptr %slot14, align 8
  %mem395 = alloca i8, i64 8, align 8
  %ptr396 = ptrtoint ptr %mem395 to i64
  store i64 %ptr396, ptr %slot15, align 8
  %mem397 = alloca i8, i64 8, align 8
  %ptr398 = ptrtoint ptr %mem397 to i64
  store i64 %ptr398, ptr %slot16, align 8
  %mem399 = alloca i8, i64 304, align 8
  %ptr400 = ptrtoint ptr %mem399 to i64
  store i64 %ptr400, ptr %slot17, align 8
  %mem401 = alloca i8, i64 304, align 8
  %ptr402 = ptrtoint ptr %mem401 to i64
  store i64 %ptr402, ptr %slot18, align 8
  %mem403 = alloca i8, i64 8, align 8
  %ptr404 = ptrtoint ptr %mem403 to i64
  store i64 %ptr404, ptr %slot19, align 8
  %mem405 = alloca i8, i64 8, align 8
  %ptr406 = ptrtoint ptr %mem405 to i64
  store i64 %ptr406, ptr %slot20, align 8
  %mem407 = alloca i8, i64 8, align 8
  %ptr408 = ptrtoint ptr %mem407 to i64
  store i64 %ptr408, ptr %slot21, align 8
  %mem409 = alloca i8, i64 208, align 8
  %ptr410 = ptrtoint ptr %mem409 to i64
  store i64 %ptr410, ptr %slot22, align 8
  %mem411 = alloca i8, i64 208, align 8
  %ptr412 = ptrtoint ptr %mem411 to i64
  store i64 %ptr412, ptr %slot23, align 8
  %mem413 = alloca i8, i64 16, align 8
  %ptr414 = ptrtoint ptr %mem413 to i64
  store i64 %ptr414, ptr %slot24, align 8
  %mem415 = alloca i8, i64 304, align 8
  %ptr416 = ptrtoint ptr %mem415 to i64
  store i64 %ptr416, ptr %slot25, align 8
  %mem417 = alloca i8, i64 16, align 8
  %ptr418 = ptrtoint ptr %mem417 to i64
  store i64 %ptr418, ptr %slot26, align 8
  %mem419 = alloca i8, i64 8, align 8
  %ptr420 = ptrtoint ptr %mem419 to i64
  store i64 %ptr420, ptr %slot27, align 8
  %mem421 = alloca i8, i64 8, align 8
  %ptr422 = ptrtoint ptr %mem421 to i64
  store i64 %ptr422, ptr %slot28, align 8
  %mem423 = alloca i8, i64 24, align 8
  %ptr424 = ptrtoint ptr %mem423 to i64
  store i64 %ptr424, ptr %slot29, align 8
  %mem425 = alloca i8, i64 304, align 8
  %ptr426 = ptrtoint ptr %mem425 to i64
  store i64 %ptr426, ptr %slot30, align 8
  %mem427 = alloca i8, i64 208, align 8
  %ptr428 = ptrtoint ptr %mem427 to i64
  store i64 %ptr428, ptr %slot31, align 8
  %mem429 = alloca i8, i64 304, align 8
  %ptr430 = ptrtoint ptr %mem429 to i64
  store i64 %ptr430, ptr %slot32, align 8
  %mem431 = alloca i8, i64 304, align 8
  %ptr432 = ptrtoint ptr %mem431 to i64
  store i64 %ptr432, ptr %slot33, align 8
  %mem433 = alloca i8, i64 8, align 8
  %ptr434 = ptrtoint ptr %mem433 to i64
  store i64 %ptr434, ptr %slot34, align 8
  %mem435 = alloca i8, i64 24, align 8
  %ptr436 = ptrtoint ptr %mem435 to i64
  store i64 %ptr436, ptr %slot35, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem437 = alloca i8, i64 8, align 8
  %ptr438 = ptrtoint ptr %mem437 to i64
  store i64 %ptr438, ptr %slot36, align 8
  %v439 = load i64, ptr %slot1, align 8
  %op440 = add i64 %v439, 64
  store i64 %op440, ptr %slot37, align 8
  %v441 = load i64, ptr %slot37, align 8
  %p442 = inttoptr i64 %v441 to ptr
  %ld443 = load i64, ptr %p442, align 8, !alias.scope !4, !noalias !3
  store i64 %ld443, ptr %slot38, align 8
  %stack444 = call ptr @llvm.stacksave()
  %stackaddr445 = ptrtoint ptr %stack444 to i64
  %v446 = load i64, ptr %slot38, align 8
  %cmp447 = icmp ult i64 %stackaddr445, %v446
  %cv448 = zext i1 %cmp447 to i64
  store i64 %cv448, ptr %slot39, align 8
  %v449 = load i64, ptr %slot39, align 8
  %cond450 = icmp ne i64 %v449, 0
  br i1 %cond450, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v451 = load i64, ptr %slot1, align 8
  %p452 = inttoptr i64 %v451 to ptr
  call void @myl_qbe_fail_frame(ptr %p452) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v453 = load i64, ptr %slot2, align 8
  %v454 = load i64, ptr %slot19, align 8
  %p455 = inttoptr i64 %v454 to ptr
  store i64 %v453, ptr %p455, align 8, !alias.scope !3, !noalias !4
  %v456 = load i64, ptr %slot3, align 8
  %v457 = load i64, ptr %slot20, align 8
  %p458 = inttoptr i64 %v457 to ptr
  store i64 %v456, ptr %p458, align 8, !alias.scope !3, !noalias !4
  %v459 = load i64, ptr %slot1, align 8
  %p460 = inttoptr i64 %v459 to ptr
  %call461 = call ptr @myl_qbe_heap(ptr %p460) nomerge, !dbg !112
  %calladdr462 = ptrtoint ptr %call461 to i64
  store i64 %calladdr462, ptr %slot40, align 8
  %v463 = load i64, ptr %slot1, align 8
  %p464 = inttoptr i64 %v463 to ptr
  %call465 = call i64 @myl_qbe_region_mark(ptr %p464) nomerge, !dbg !112
  store i64 %call465, ptr %slot41, align 8
  %v466 = load i64, ptr %slot6, align 8
  %p467 = inttoptr i64 %v466 to ptr
  store i32 0, ptr %p467, align 4, !alias.scope !3, !noalias !4
  %v468 = load i64, ptr %slot7, align 8
  %p469 = inttoptr i64 %v468 to ptr
  store i32 0, ptr %p469, align 4, !alias.scope !3, !noalias !4
  %v470 = load i64, ptr %slot8, align 8
  %p471 = inttoptr i64 %v470 to ptr
  store i32 0, ptr %p471, align 4, !alias.scope !3, !noalias !4
  %v472 = load i64, ptr %slot9, align 8
  %p473 = inttoptr i64 %v472 to ptr
  store i32 0, ptr %p473, align 4, !alias.scope !3, !noalias !4
  %v474 = load i64, ptr %slot10, align 8
  %p475 = inttoptr i64 %v474 to ptr
  store i32 0, ptr %p475, align 4, !alias.scope !3, !noalias !4
  %v476 = load i64, ptr %slot11, align 8
  %p477 = inttoptr i64 %v476 to ptr
  store i32 0, ptr %p477, align 4, !alias.scope !3, !noalias !4
  %v478 = load i64, ptr %slot12, align 8
  %p479 = inttoptr i64 %v478 to ptr
  store i32 0, ptr %p479, align 4, !alias.scope !3, !noalias !4
  %v480 = load i64, ptr %slot13, align 8
  %p481 = inttoptr i64 %v480 to ptr
  store i32 0, ptr %p481, align 4, !alias.scope !3, !noalias !4
  %v482 = load i64, ptr %slot14, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 0, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot15, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 0, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot16, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 0, ptr %p487, align 4, !alias.scope !3, !noalias !4
  %v488 = load i64, ptr %slot7, align 8
  %p489 = inttoptr i64 %v488 to ptr
  store i32 2, ptr %p489, align 4, !alias.scope !3, !noalias !4
  %v490 = load i64, ptr %slot9, align 8
  %p491 = inttoptr i64 %v490 to ptr
  store i32 2, ptr %p491, align 4, !alias.scope !3, !noalias !4
  %v492 = load i64, ptr %slot11, align 8
  %p493 = inttoptr i64 %v492 to ptr
  store i32 2, ptr %p493, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v494 = load i64, ptr %slot20, align 8
  %p495 = inttoptr i64 %v494 to ptr
  %ld496 = load i64, ptr %p495, align 8, !alias.scope !3, !noalias !4
  store i64 %ld496, ptr %slot42, align 8
  %v497 = load i64, ptr %slot42, align 8
  %v498 = load i64, ptr %slot27, align 8
  %p499 = inttoptr i64 %v498 to ptr
  store i64 %v497, ptr %p499, align 8, !alias.scope !3, !noalias !4
  %v500 = load i64, ptr %slot27, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i64, ptr %p501, align 8, !alias.scope !3, !noalias !4
  store i64 %ld502, ptr %slot43, align 8
  %v503 = load i64, ptr %slot43, align 8
  %op504 = add i64 %v503, 40
  store i64 %op504, ptr %slot44, align 8
  %v505 = load i64, ptr %slot44, align 8
  %v506 = load i64, ptr %slot27, align 8
  %p507 = inttoptr i64 %v506 to ptr
  store i64 %v505, ptr %p507, align 8, !alias.scope !3, !noalias !4
  %v508 = load i64, ptr %slot12, align 8
  %p509 = inttoptr i64 %v508 to ptr
  %ld510 = load i32, ptr %p509, align 4, !alias.scope !3, !noalias !4
  store i32 %ld510, ptr %slot45, align 8
  %v511 = load i32, ptr %slot45, align 8
  %cv512 = zext i32 %v511 to i64
  %cond513 = icmp ne i64 %cv512, 0
  br i1 %cond513, label %bb_rcslotdrop21, label %bb_rcslotdone21
bb_rcslotdrop21:
  %v514 = load i64, ptr %slot12, align 8
  %p515 = inttoptr i64 %v514 to ptr
  store i32 0, ptr %p515, align 4, !alias.scope !3, !noalias !4
  %v516 = load i64, ptr %slot17, align 8
  store i64 %v516, ptr %slot46, align 8
  %v517 = load i64, ptr %slot13, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ld519 = load i32, ptr %p518, align 4, !alias.scope !3, !noalias !4
  store i32 %ld519, ptr %slot47, align 8
  %v520 = load i32, ptr %slot47, align 8
  %op521 = and i32 %v520, 28
  store i32 %op521, ptr %slot48, align 8
  %v522 = load i32, ptr %slot48, align 8
  %cv523 = zext i32 %v522 to i64
  %cond524 = icmp ne i64 %cv523, 0
  br i1 %cond524, label %bb_rcslotrole21, label %bb_rcslotowner21
bb_rcslotrole21:
  %v525 = load i64, ptr %slot40, align 8
  store i64 %v525, ptr %slot49, align 8
  %v526 = load i64, ptr %slot49, align 8
  %v527 = load i64, ptr %slot46, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64 %v526, i64 %v527) nomerge, !dbg !114
  br label %bb_rcslotdone21
bb_rcslotowner21:
  %v528 = load i64, ptr %slot40, align 8
  store i64 %v528, ptr %slot50, align 8
  %v529 = load i64, ptr %slot50, align 8
  %v530 = load i64, ptr %slot46, align 8
  call void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64 %v529, i64 %v530) nomerge, !dbg !114
  br label %bb_rcslotdone21
bb_rcslotdone21:
  %v531 = load i64, ptr %slot27, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i64, ptr %p532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld533, ptr %slot51, align 8
  %v534 = load i64, ptr %slot51, align 8
  %p535 = inttoptr i64 %v534 to ptr
  %ld536 = load i32, ptr %p535, align 4, !alias.scope !4, !noalias !3
  %ext537 = zext i32 %ld536 to i64
  store i64 %ext537, ptr %slot52, align 8
  %v538 = load i64, ptr %slot52, align 8
  %cmp539 = icmp eq i64 %v538, 0
  %cv540 = zext i1 %cmp539 to i64
  store i64 %cv540, ptr %slot53, align 8
  %v541 = load i64, ptr %slot53, align 8
  %cond542 = icmp ne i64 %v541, 0
  br i1 %cond542, label %bb_rcarm30, label %bb_rcarmnext30
bb_rcarm30:
  br label %bb_i11
bb_rcarmnext30:
  %v543 = load i64, ptr %slot52, align 8
  %cmp544 = icmp eq i64 %v543, 1
  %cv545 = zext i1 %cmp544 to i64
  store i64 %cv545, ptr %slot54, align 8
  %v546 = load i64, ptr %slot54, align 8
  %cond547 = icmp ne i64 %v546, 0
  br i1 %cond547, label %bb_rcarm31, label %bb_rcarmnext31
bb_rcarm31:
  %v548 = load i64, ptr %slot18, align 8
  store i64 %v548, ptr %slot55, align 8
  %v549 = load i64, ptr %slot51, align 8
  %op550 = add i64 %v549, 8
  store i64 %op550, ptr %slot56, align 8
  %v551 = load i64, ptr %slot41, align 8
  store i64 %v551, ptr %slot57, align 8
  %v552 = load i64, ptr %slot56, align 8
  %p553 = inttoptr i64 %v552 to ptr
  %ld554 = load i64, ptr %p553, align 8, !alias.scope !4, !noalias !3
  store i64 %ld554, ptr %slot58, align 8
  %v555 = load i64, ptr %slot58, align 8
  %v556 = load i64, ptr %slot55, align 8
  %p557 = inttoptr i64 %v556 to ptr
  store i64 %v555, ptr %p557, align 8, !alias.scope !3, !noalias !4
  %v558 = load i64, ptr %slot15, align 8
  %p559 = inttoptr i64 %v558 to ptr
  store i32 0, ptr %p559, align 4, !alias.scope !3, !noalias !4
  %v560 = load i64, ptr %slot14, align 8
  %p561 = inttoptr i64 %v560 to ptr
  store i32 1, ptr %p561, align 4, !alias.scope !3, !noalias !4
  %v562 = load i64, ptr %slot55, align 8
  %p563 = inttoptr i64 %v562 to ptr
  %ld564 = load i64, ptr %p563, align 8, !alias.scope !3, !noalias !4
  store i64 %ld564, ptr %slot59, align 8
  %v565 = load i64, ptr %slot59, align 8
  %v566 = load i64, ptr %slot21, align 8
  %p567 = inttoptr i64 %v566 to ptr
  store i64 %v565, ptr %p567, align 8, !alias.scope !3, !noalias !4
  %v568 = load i64, ptr %slot14, align 8
  %p569 = inttoptr i64 %v568 to ptr
  store i32 0, ptr %p569, align 4, !alias.scope !3, !noalias !4
  br label %bb_i3
bb_rcarmnext31:
  br label %bb_failure
bb_i3:
  %v570 = load i64, ptr %slot19, align 8
  %p571 = inttoptr i64 %v570 to ptr
  %ld572 = load i64, ptr %p571, align 8, !alias.scope !3, !noalias !4
  store i64 %ld572, ptr %slot60, align 8
  %v573 = load i64, ptr %slot60, align 8
  %v574 = load i64, ptr %slot27, align 8
  %p575 = inttoptr i64 %v574 to ptr
  store i64 %v573, ptr %p575, align 8, !alias.scope !3, !noalias !4
  %v576 = load i64, ptr %slot21, align 8
  %p577 = inttoptr i64 %v576 to ptr
  %ld578 = load i64, ptr %p577, align 8, !alias.scope !3, !noalias !4
  store i64 %ld578, ptr %slot61, align 8
  %v579 = load i64, ptr %slot61, align 8
  %v580 = load i64, ptr %slot28, align 8
  %p581 = inttoptr i64 %v580 to ptr
  store i64 %v579, ptr %p581, align 8, !alias.scope !3, !noalias !4
  %v582 = load i64, ptr %slot27, align 8
  %p583 = inttoptr i64 %v582 to ptr
  %ld584 = load i64, ptr %p583, align 8, !alias.scope !3, !noalias !4
  store i64 %ld584, ptr %slot62, align 8
  %v585 = load i64, ptr %slot28, align 8
  %p586 = inttoptr i64 %v585 to ptr
  %ld587 = load i64, ptr %p586, align 8, !alias.scope !3, !noalias !4
  store i64 %ld587, ptr %slot63, align 8
  %v588 = load i64, ptr %slot1, align 8
  %v589 = load i64, ptr %slot62, align 8
  %v590 = load i64, ptr %slot63, align 8
  call void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8 %callresult65, i64 %v588, i64 %v589, i64 %v590) nomerge, !dbg !116
  %addr591 = ptrtoint ptr %callresult65 to i64
  store i64 %addr591, ptr %slot64, align 8
  %v592 = load i64, ptr %slot64, align 8
  %v593 = load i64, ptr %slot27, align 8
  %p594 = inttoptr i64 %v593 to ptr
  store i64 %v592, ptr %p594, align 8, !alias.scope !3, !noalias !4
  %v595 = load i64, ptr %slot27, align 8
  %p596 = inttoptr i64 %v595 to ptr
  %ld597 = load i64, ptr %p596, align 8, !alias.scope !3, !noalias !4
  store i64 %ld597, ptr %slot66, align 8
  %v598 = load i64, ptr %slot18, align 8
  store i64 %v598, ptr %slot67, align 8
  %v599 = load i64, ptr %slot66, align 8
  %v600 = load i64, ptr %slot67, align 8
  %p601 = inttoptr i64 %v599 to ptr
  %p602 = inttoptr i64 %v600 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p602, ptr %p601, i64 24, i1 false)
  %v603 = load i64, ptr %slot15, align 8
  %p604 = inttoptr i64 %v603 to ptr
  store i32 2, ptr %p604, align 4, !alias.scope !3, !noalias !4
  %v605 = load i64, ptr %slot14, align 8
  %p606 = inttoptr i64 %v605 to ptr
  store i32 1, ptr %p606, align 4, !alias.scope !3, !noalias !4
  %v607 = load i64, ptr %slot12, align 8
  %p608 = inttoptr i64 %v607 to ptr
  %ld609 = load i32, ptr %p608, align 4, !alias.scope !3, !noalias !4
  store i32 %ld609, ptr %slot68, align 8
  %v610 = load i32, ptr %slot68, align 8
  %cv611 = zext i32 %v610 to i64
  %cond612 = icmp ne i64 %cv611, 0
  br i1 %cond612, label %bb_rcslotdrop51, label %bb_rcslotdone51
bb_rcslotdrop51:
  %v613 = load i64, ptr %slot12, align 8
  %p614 = inttoptr i64 %v613 to ptr
  store i32 0, ptr %p614, align 4, !alias.scope !3, !noalias !4
  %v615 = load i64, ptr %slot17, align 8
  store i64 %v615, ptr %slot69, align 8
  %v616 = load i64, ptr %slot13, align 8
  %p617 = inttoptr i64 %v616 to ptr
  %ld618 = load i32, ptr %p617, align 4, !alias.scope !3, !noalias !4
  store i32 %ld618, ptr %slot70, align 8
  %v619 = load i32, ptr %slot70, align 8
  %op620 = and i32 %v619, 28
  store i32 %op620, ptr %slot71, align 8
  %v621 = load i32, ptr %slot71, align 8
  %cv622 = zext i32 %v621 to i64
  %cond623 = icmp ne i64 %cv622, 0
  br i1 %cond623, label %bb_rcslotrole51, label %bb_rcslotowner51
bb_rcslotrole51:
  %v624 = load i64, ptr %slot40, align 8
  store i64 %v624, ptr %slot72, align 8
  %v625 = load i64, ptr %slot72, align 8
  %v626 = load i64, ptr %slot69, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v625, i64 %v626) nomerge, !dbg !116
  br label %bb_rcslotdone51
bb_rcslotowner51:
  %v627 = load i64, ptr %slot40, align 8
  store i64 %v627, ptr %slot73, align 8
  %v628 = load i64, ptr %slot73, align 8
  %v629 = load i64, ptr %slot69, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v628, i64 %v629) nomerge, !dbg !116
  br label %bb_rcslotdone51
bb_rcslotdone51:
  %v630 = load i64, ptr %slot17, align 8
  store i64 %v630, ptr %slot74, align 8
  %v631 = load i64, ptr %slot18, align 8
  store i64 %v631, ptr %slot75, align 8
  %v632 = load i64, ptr %slot75, align 8
  %v633 = load i64, ptr %slot74, align 8
  %p634 = inttoptr i64 %v632 to ptr
  %p635 = inttoptr i64 %v633 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p635, ptr %p634, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v636 = load i64, ptr %slot13, align 8
  %p637 = inttoptr i64 %v636 to ptr
  store i32 2, ptr %p637, align 4, !alias.scope !3, !noalias !4
  %v638 = load i64, ptr %slot15, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %ld640 = load i32, ptr %p639, align 4, !alias.scope !3, !noalias !4
  store i32 %ld640, ptr %slot76, align 8
  %v641 = load i32, ptr %slot76, align 8
  %v642 = load i64, ptr %slot13, align 8
  %p643 = inttoptr i64 %v642 to ptr
  store i32 %v641, ptr %p643, align 4, !alias.scope !3, !noalias !4
  %v644 = load i64, ptr %slot14, align 8
  %p645 = inttoptr i64 %v644 to ptr
  store i32 0, ptr %p645, align 4, !alias.scope !3, !noalias !4
  %v646 = load i64, ptr %slot12, align 8
  %p647 = inttoptr i64 %v646 to ptr
  store i32 1, ptr %p647, align 4, !alias.scope !3, !noalias !4
  %v648 = load i64, ptr %slot74, align 8
  %v649 = load i64, ptr %slot27, align 8
  %p650 = inttoptr i64 %v649 to ptr
  store i64 %v648, ptr %p650, align 8, !alias.scope !3, !noalias !4
  %v651 = load i64, ptr %slot27, align 8
  %p652 = inttoptr i64 %v651 to ptr
  %ld653 = load i64, ptr %p652, align 8, !alias.scope !3, !noalias !4
  store i64 %ld653, ptr %slot77, align 8
  %v654 = load i64, ptr %slot77, align 8
  %p655 = inttoptr i64 %v654 to ptr
  %ld656 = load i32, ptr %p655, align 4, !alias.scope !3, !noalias !4
  %ext657 = zext i32 %ld656 to i64
  store i64 %ext657, ptr %slot78, align 8
  %v658 = load i64, ptr %slot78, align 8
  %cmp659 = icmp eq i64 %v658, 0
  %cv660 = zext i1 %cmp659 to i64
  store i64 %cv660, ptr %slot79, align 8
  %v661 = load i64, ptr %slot79, align 8
  %cond662 = icmp ne i64 %v661, 0
  br i1 %cond662, label %bb_rctryok67, label %bb_rctryerror67
bb_rctryerror67:
  %p663 = inttoptr i64 ptrtoint (ptr @myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p663, i64 12884901894) "call-inline-cost"="0", !dbg !118
  %v664 = load i64, ptr %slot77, align 8
  %op665 = add i64 %v664, 8
  store i64 %op665, ptr %slot80, align 8
  %v666 = load i64, ptr %slot29, align 8
  store i64 %v666, ptr %slot81, align 8
  %v667 = load i64, ptr %slot81, align 8
  %p668 = inttoptr i64 %v667 to ptr
  store i64 0, ptr %p668, align 8, !alias.scope !3, !noalias !4
  %v669 = load i64, ptr %slot81, align 8
  %p671 = inttoptr i64 %v669 to ptr
  %gep672 = getelementptr i8, ptr %p671, i64 8
  %op670 = ptrtoint ptr %gep672 to i64
  store i64 %op670, ptr %slot82, align 8
  %v673 = load i64, ptr %slot82, align 8
  %p674 = inttoptr i64 %v673 to ptr
  store i64 0, ptr %p674, align 8, !alias.scope !3, !noalias !4
  %v675 = load i64, ptr %slot81, align 8
  %p677 = inttoptr i64 %v675 to ptr
  %gep678 = getelementptr i8, ptr %p677, i64 16
  %op676 = ptrtoint ptr %gep678 to i64
  store i64 %op676, ptr %slot83, align 8
  %v679 = load i64, ptr %slot83, align 8
  %p680 = inttoptr i64 %v679 to ptr
  store i64 0, ptr %p680, align 8, !alias.scope !3, !noalias !4
  %v681 = load i64, ptr %slot81, align 8
  %p682 = inttoptr i64 %v681 to ptr
  store i32 1, ptr %p682, align 4, !alias.scope !3, !noalias !4
  %v683 = load i64, ptr %slot81, align 8
  %p685 = inttoptr i64 %v683 to ptr
  %gep686 = getelementptr i8, ptr %p685, i64 8
  %op684 = ptrtoint ptr %gep686 to i64
  store i64 %op684, ptr %slot84, align 8
  %v687 = load i64, ptr %slot16, align 8
  %p688 = inttoptr i64 %v687 to ptr
  store i32 1, ptr %p688, align 4, !alias.scope !3, !noalias !4
  %v689 = load i64, ptr %slot41, align 8
  store i64 %v689, ptr %slot85, align 8
  %v690 = load i64, ptr %slot40, align 8
  %v691 = load i64, ptr %slot84, align 8
  %v692 = load i64, ptr %slot80, align 8
  %v693 = load i64, ptr %slot85, align 8
  %cv694 = trunc i64 %v693 to i32
  %call695 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64 %v690, i64 %v691, i64 %v692, i32 %cv694) nomerge, !dbg !118
  store i32 %call695, ptr %slot86, align 8
  %v696 = load i32, ptr %slot86, align 8
  %cv697 = zext i32 %v696 to i64
  %cond698 = icmp ne i64 %cv697, 0
  br i1 %cond698, label %bb_rcsuccess78, label %bb_rcfailure78
bb_rcfailure78:
  %v699 = load i64, ptr %slot40, align 8
  %p700 = inttoptr i64 %v699 to ptr
  %call701 = call i32 @myl_rc_take_failure(ptr %p700) nomerge, !dbg !118
  store i32 %call701, ptr %slot87, align 8
  %v702 = load i64, ptr %slot1, align 8
  %p703 = inttoptr i64 %v702 to ptr
  %v704 = load i32, ptr %slot87, align 8
  %call705 = call i32 @myl_qbe_rc_status(ptr %p703, i32 %v704) nomerge, !dbg !118
  store i32 %call705, ptr %slot88, align 8
  br label %bb_failure
bb_rcsuccess78:
  %v706 = load i64, ptr %slot81, align 8
  %v707 = load i64, ptr %slot27, align 8
  %p708 = inttoptr i64 %v707 to ptr
  store i64 %v706, ptr %p708, align 8, !alias.scope !3, !noalias !4
  %v709 = load i64, ptr %slot27, align 8
  %p710 = inttoptr i64 %v709 to ptr
  %ld711 = load i64, ptr %p710, align 8, !alias.scope !3, !noalias !4
  store i64 %ld711, ptr %slot89, align 8
  %v712 = load i64, ptr %slot18, align 8
  store i64 %v712, ptr %slot90, align 8
  %v713 = load i64, ptr %slot89, align 8
  %v714 = load i64, ptr %slot90, align 8
  %p715 = inttoptr i64 %v713 to ptr
  %p716 = inttoptr i64 %v714 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p716, ptr %p715, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v717 = load i64, ptr %slot15, align 8
  %p718 = inttoptr i64 %v717 to ptr
  store i32 2, ptr %p718, align 4, !alias.scope !3, !noalias !4
  %v719 = load i64, ptr %slot14, align 8
  %p720 = inttoptr i64 %v719 to ptr
  store i32 1, ptr %p720, align 4, !alias.scope !3, !noalias !4
  %v721 = load i64, ptr %slot12, align 8
  %p722 = inttoptr i64 %v721 to ptr
  %ld723 = load i32, ptr %p722, align 4, !alias.scope !3, !noalias !4
  store i32 %ld723, ptr %slot91, align 8
  %v724 = load i32, ptr %slot91, align 8
  %cv725 = zext i32 %v724 to i64
  %cond726 = icmp ne i64 %cv725, 0
  br i1 %cond726, label %bb_rcslotdrop87, label %bb_rcslotdone87
bb_rcslotdrop87:
  %v727 = load i64, ptr %slot12, align 8
  %p728 = inttoptr i64 %v727 to ptr
  store i32 0, ptr %p728, align 4, !alias.scope !3, !noalias !4
  %v729 = load i64, ptr %slot17, align 8
  store i64 %v729, ptr %slot92, align 8
  %v730 = load i64, ptr %slot13, align 8
  %p731 = inttoptr i64 %v730 to ptr
  %ld732 = load i32, ptr %p731, align 4, !alias.scope !3, !noalias !4
  store i32 %ld732, ptr %slot93, align 8
  %v733 = load i32, ptr %slot93, align 8
  %op734 = and i32 %v733, 28
  store i32 %op734, ptr %slot94, align 8
  %v735 = load i32, ptr %slot94, align 8
  %cv736 = zext i32 %v735 to i64
  %cond737 = icmp ne i64 %cv736, 0
  br i1 %cond737, label %bb_rcslotrole87, label %bb_rcslotowner87
bb_rcslotrole87:
  %v738 = load i64, ptr %slot40, align 8
  store i64 %v738, ptr %slot95, align 8
  %v739 = load i64, ptr %slot95, align 8
  %v740 = load i64, ptr %slot92, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v739, i64 %v740) nomerge, !dbg !118
  br label %bb_rcslotdone87
bb_rcslotowner87:
  %v741 = load i64, ptr %slot40, align 8
  store i64 %v741, ptr %slot96, align 8
  %v742 = load i64, ptr %slot96, align 8
  %v743 = load i64, ptr %slot92, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v742, i64 %v743) nomerge, !dbg !118
  br label %bb_rcslotdone87
bb_rcslotdone87:
  %v744 = load i64, ptr %slot17, align 8
  store i64 %v744, ptr %slot97, align 8
  %v745 = load i64, ptr %slot18, align 8
  store i64 %v745, ptr %slot98, align 8
  %v746 = load i64, ptr %slot98, align 8
  %v747 = load i64, ptr %slot97, align 8
  %p748 = inttoptr i64 %v746 to ptr
  %p749 = inttoptr i64 %v747 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p749, ptr %p748, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v750 = load i64, ptr %slot13, align 8
  %p751 = inttoptr i64 %v750 to ptr
  store i32 2, ptr %p751, align 4, !alias.scope !3, !noalias !4
  %v752 = load i64, ptr %slot15, align 8
  %p753 = inttoptr i64 %v752 to ptr
  %ld754 = load i32, ptr %p753, align 4, !alias.scope !3, !noalias !4
  store i32 %ld754, ptr %slot99, align 8
  %v755 = load i32, ptr %slot99, align 8
  %v756 = load i64, ptr %slot13, align 8
  %p757 = inttoptr i64 %v756 to ptr
  store i32 %v755, ptr %p757, align 4, !alias.scope !3, !noalias !4
  %v758 = load i64, ptr %slot14, align 8
  %p759 = inttoptr i64 %v758 to ptr
  store i32 0, ptr %p759, align 4, !alias.scope !3, !noalias !4
  %v760 = load i64, ptr %slot12, align 8
  %p761 = inttoptr i64 %v760 to ptr
  store i32 1, ptr %p761, align 4, !alias.scope !3, !noalias !4
  %v762 = load i64, ptr %slot97, align 8
  %v763 = load i64, ptr %slot27, align 8
  %p764 = inttoptr i64 %v763 to ptr
  store i64 %v762, ptr %p764, align 8, !alias.scope !3, !noalias !4
  br label %bb_i8
bb_rctryok67:
  %v765 = load i64, ptr %slot29, align 8
  store i64 %v765, ptr %slot100, align 8
  %v766 = load i64, ptr %slot16, align 8
  %p767 = inttoptr i64 %v766 to ptr
  store i32 1, ptr %p767, align 4, !alias.scope !3, !noalias !4
  %v768 = load i64, ptr %slot77, align 8
  %op769 = add i64 %v768, 8
  store i64 %op769, ptr %slot101, align 8
  %v770 = load i64, ptr %slot41, align 8
  store i64 %v770, ptr %slot102, align 8
  store i64 0, ptr %slot103, align 8
  store i64 0, ptr %slot104, align 8
  %v771 = load i64, ptr %slot104, align 8
  %v772 = load i64, ptr %slot27, align 8
  %p773 = inttoptr i64 %v772 to ptr
  store i64 %v771, ptr %p773, align 8, !alias.scope !3, !noalias !4
  %v774 = load i64, ptr %slot12, align 8
  %p775 = inttoptr i64 %v774 to ptr
  %ld776 = load i32, ptr %p775, align 4, !alias.scope !3, !noalias !4
  store i32 %ld776, ptr %slot105, align 8
  %v777 = load i32, ptr %slot105, align 8
  %cv778 = zext i32 %v777 to i64
  %cond779 = icmp ne i64 %cv778, 0
  br i1 %cond779, label %bb_rcslotdrop111, label %bb_rcslotdone111
bb_rcslotdrop111:
  %v780 = load i64, ptr %slot12, align 8
  %p781 = inttoptr i64 %v780 to ptr
  store i32 0, ptr %p781, align 4, !alias.scope !3, !noalias !4
  %v782 = load i64, ptr %slot17, align 8
  store i64 %v782, ptr %slot106, align 8
  %v783 = load i64, ptr %slot13, align 8
  %p784 = inttoptr i64 %v783 to ptr
  %ld785 = load i32, ptr %p784, align 4, !alias.scope !3, !noalias !4
  store i32 %ld785, ptr %slot107, align 8
  %v786 = load i32, ptr %slot107, align 8
  %op787 = and i32 %v786, 28
  store i32 %op787, ptr %slot108, align 8
  %v788 = load i32, ptr %slot108, align 8
  %cv789 = zext i32 %v788 to i64
  %cond790 = icmp ne i64 %cv789, 0
  br i1 %cond790, label %bb_rcslotrole111, label %bb_rcslotowner111
bb_rcslotrole111:
  %v791 = load i64, ptr %slot40, align 8
  store i64 %v791, ptr %slot109, align 8
  %v792 = load i64, ptr %slot109, align 8
  %v793 = load i64, ptr %slot106, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64 %v792, i64 %v793) nomerge, !dbg !118
  br label %bb_rcslotdone111
bb_rcslotowner111:
  %v794 = load i64, ptr %slot40, align 8
  store i64 %v794, ptr %slot110, align 8
  %v795 = load i64, ptr %slot110, align 8
  %v796 = load i64, ptr %slot106, align 8
  call void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64 %v795, i64 %v796) nomerge, !dbg !118
  br label %bb_rcslotdone111
bb_rcslotdone111:
  br label %bb_i9
bb_i8:
  %v797 = load i64, ptr %slot27, align 8
  %p798 = inttoptr i64 %v797 to ptr
  %ld799 = load i64, ptr %p798, align 8, !alias.scope !3, !noalias !4
  store i64 %ld799, ptr %slot111, align 8
  %v800 = load i64, ptr %slot27, align 8
  %p801 = inttoptr i64 %v800 to ptr
  %ld802 = load i64, ptr %p801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld802, ptr %slot112, align 8
  %v803 = load i64, ptr %slot12, align 8
  %p804 = inttoptr i64 %v803 to ptr
  %ld805 = load i32, ptr %p804, align 4, !alias.scope !3, !noalias !4
  store i32 %ld805, ptr %slot113, align 8
  %v806 = load i64, ptr %slot13, align 8
  %p807 = inttoptr i64 %v806 to ptr
  %ld808 = load i32, ptr %p807, align 4, !alias.scope !3, !noalias !4
  store i32 %ld808, ptr %slot114, align 8
  %v809 = load i32, ptr %slot114, align 8
  %op810 = and i32 %v809, 24
  store i32 %op810, ptr %slot114, align 8
  %v811 = load i32, ptr %slot114, align 8
  %cmp812 = icmp eq i32 %v811, 0
  %cv813 = zext i1 %cmp812 to i32
  store i32 %cv813, ptr %slot115, align 8
  %v814 = load i32, ptr %slot113, align 8
  %v815 = load i32, ptr %slot115, align 8
  %op816 = and i32 %v814, %v815
  store i32 %op816, ptr %slot116, align 8
  %v817 = load i32, ptr %slot116, align 8
  %cv818 = zext i32 %v817 to i64
  %cond819 = icmp ne i64 %cv818, 0
  br i1 %cond819, label %bb_rctake120, label %bb_rccopy120
bb_rctake120:
  %v820 = load i64, ptr %slot18, align 8
  store i64 %v820, ptr %slot117, align 8
  %v821 = load i64, ptr %slot41, align 8
  store i64 %v821, ptr %slot118, align 8
  %v822 = load i64, ptr %slot40, align 8
  %v823 = load i64, ptr %slot117, align 8
  %v824 = load i64, ptr %slot112, align 8
  %v825 = load i64, ptr %slot118, align 8
  %cv826 = trunc i64 %v825 to i32
  %call827 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v822, i64 %v823, i64 %v824, i32 %cv826) nomerge, !dbg !120
  store i32 %call827, ptr %slot119, align 8
  %v828 = load i32, ptr %slot119, align 8
  %cv829 = zext i32 %v828 to i64
  %cond830 = icmp ne i64 %cv829, 0
  br i1 %cond830, label %bb_rcsuccess130, label %bb_rcfailure130
bb_rcfailure130:
  %v831 = load i64, ptr %slot40, align 8
  %p832 = inttoptr i64 %v831 to ptr
  %call833 = call i32 @myl_rc_take_failure(ptr %p832) nomerge, !dbg !120
  store i32 %call833, ptr %slot120, align 8
  %v834 = load i64, ptr %slot1, align 8
  %p835 = inttoptr i64 %v834 to ptr
  %v836 = load i32, ptr %slot120, align 8
  %call837 = call i32 @myl_qbe_rc_status(ptr %p835, i32 %v836) nomerge, !dbg !120
  store i32 %call837, ptr %slot121, align 8
  br label %bb_failure
bb_rcsuccess130:
  %v838 = load i64, ptr %slot12, align 8
  %p839 = inttoptr i64 %v838 to ptr
  store i32 0, ptr %p839, align 4, !alias.scope !3, !noalias !4
  %v840 = load i64, ptr %slot15, align 8
  %p841 = inttoptr i64 %v840 to ptr
  store i32 2, ptr %p841, align 4, !alias.scope !3, !noalias !4
  %v842 = load i64, ptr %slot14, align 8
  %p843 = inttoptr i64 %v842 to ptr
  store i32 1, ptr %p843, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared120
bb_rccopy120:
  %v844 = load i64, ptr %slot18, align 8
  store i64 %v844, ptr %slot122, align 8
  %v845 = load i64, ptr %slot41, align 8
  store i64 %v845, ptr %slot123, align 8
  %v846 = load i64, ptr %slot40, align 8
  %v847 = load i64, ptr %slot122, align 8
  %v848 = load i64, ptr %slot112, align 8
  %v849 = load i64, ptr %slot123, align 8
  %cv850 = trunc i64 %v849 to i32
  %call851 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64 %v846, i64 %v847, i64 %v848, i32 %cv850) nomerge, !dbg !120
  store i32 %call851, ptr %slot124, align 8
  %v852 = load i32, ptr %slot124, align 8
  %cv853 = zext i32 %v852 to i64
  %cond854 = icmp ne i64 %cv853, 0
  br i1 %cond854, label %bb_rcsuccess139, label %bb_rcfailure139
bb_rcfailure139:
  %v855 = load i64, ptr %slot40, align 8
  %p856 = inttoptr i64 %v855 to ptr
  %call857 = call i32 @myl_rc_take_failure(ptr %p856) nomerge, !dbg !120
  store i32 %call857, ptr %slot125, align 8
  %v858 = load i64, ptr %slot1, align 8
  %p859 = inttoptr i64 %v858 to ptr
  %v860 = load i32, ptr %slot125, align 8
  %call861 = call i32 @myl_qbe_rc_status(ptr %p859, i32 %v860) nomerge, !dbg !120
  store i32 %call861, ptr %slot126, align 8
  br label %bb_failure
bb_rcsuccess139:
  %v862 = load i64, ptr %slot15, align 8
  %p863 = inttoptr i64 %v862 to ptr
  store i32 2, ptr %p863, align 4, !alias.scope !3, !noalias !4
  %v864 = load i64, ptr %slot14, align 8
  %p865 = inttoptr i64 %v864 to ptr
  store i32 1, ptr %p865, align 4, !alias.scope !3, !noalias !4
  %v866 = load i64, ptr %slot12, align 8
  %p867 = inttoptr i64 %v866 to ptr
  %ld868 = load i32, ptr %p867, align 4, !alias.scope !3, !noalias !4
  store i32 %ld868, ptr %slot127, align 8
  %v869 = load i32, ptr %slot127, align 8
  %cv870 = zext i32 %v869 to i64
  %cond871 = icmp ne i64 %cv870, 0
  br i1 %cond871, label %bb_rcslotdrop146, label %bb_rcslotdone146
bb_rcslotdrop146:
  %v872 = load i64, ptr %slot12, align 8
  %p873 = inttoptr i64 %v872 to ptr
  store i32 0, ptr %p873, align 4, !alias.scope !3, !noalias !4
  %v874 = load i64, ptr %slot17, align 8
  store i64 %v874, ptr %slot128, align 8
  %v875 = load i64, ptr %slot13, align 8
  %p876 = inttoptr i64 %v875 to ptr
  %ld877 = load i32, ptr %p876, align 4, !alias.scope !3, !noalias !4
  store i32 %ld877, ptr %slot129, align 8
  %v878 = load i32, ptr %slot129, align 8
  %op879 = and i32 %v878, 28
  store i32 %op879, ptr %slot130, align 8
  %v880 = load i32, ptr %slot130, align 8
  %cv881 = zext i32 %v880 to i64
  %cond882 = icmp ne i64 %cv881, 0
  br i1 %cond882, label %bb_rcslotrole146, label %bb_rcslotowner146
bb_rcslotrole146:
  %v883 = load i64, ptr %slot40, align 8
  store i64 %v883, ptr %slot131, align 8
  %v884 = load i64, ptr %slot131, align 8
  %v885 = load i64, ptr %slot128, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v884, i64 %v885) nomerge, !dbg !120
  br label %bb_rcslotdone146
bb_rcslotowner146:
  %v886 = load i64, ptr %slot40, align 8
  store i64 %v886, ptr %slot132, align 8
  %v887 = load i64, ptr %slot132, align 8
  %v888 = load i64, ptr %slot128, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v887, i64 %v888) nomerge, !dbg !120
  br label %bb_rcslotdone146
bb_rcslotdone146:
  br label %bb_rcprepared120
bb_rcprepared120:
  %v889 = load i64, ptr %slot18, align 8
  store i64 %v889, ptr %slot133, align 8
  %v890 = load i64, ptr %slot14, align 8
  %p891 = inttoptr i64 %v890 to ptr
  store i32 0, ptr %p891, align 4, !alias.scope !3, !noalias !4
  %v892 = load i64, ptr %slot12, align 8
  %p893 = inttoptr i64 %v892 to ptr
  %ld894 = load i32, ptr %p893, align 4, !alias.scope !3, !noalias !4
  store i32 %ld894, ptr %slot134, align 8
  %v895 = load i32, ptr %slot134, align 8
  %cv896 = zext i32 %v895 to i64
  %cond897 = icmp ne i64 %cv896, 0
  br i1 %cond897, label %bb_rcslotdrop157, label %bb_rcslotdone157
bb_rcslotdrop157:
  %v898 = load i64, ptr %slot12, align 8
  %p899 = inttoptr i64 %v898 to ptr
  store i32 0, ptr %p899, align 4, !alias.scope !3, !noalias !4
  %v900 = load i64, ptr %slot17, align 8
  store i64 %v900, ptr %slot135, align 8
  %v901 = load i64, ptr %slot13, align 8
  %p902 = inttoptr i64 %v901 to ptr
  %ld903 = load i32, ptr %p902, align 4, !alias.scope !3, !noalias !4
  store i32 %ld903, ptr %slot136, align 8
  %v904 = load i32, ptr %slot136, align 8
  %op905 = and i32 %v904, 28
  store i32 %op905, ptr %slot137, align 8
  %v906 = load i32, ptr %slot137, align 8
  %cv907 = zext i32 %v906 to i64
  %cond908 = icmp ne i64 %cv907, 0
  br i1 %cond908, label %bb_rcslotrole157, label %bb_rcslotowner157
bb_rcslotrole157:
  %v909 = load i64, ptr %slot40, align 8
  store i64 %v909, ptr %slot138, align 8
  %v910 = load i64, ptr %slot138, align 8
  %v911 = load i64, ptr %slot135, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v910, i64 %v911) nomerge, !dbg !120
  br label %bb_rcslotdone157
bb_rcslotowner157:
  %v912 = load i64, ptr %slot40, align 8
  store i64 %v912, ptr %slot139, align 8
  %v913 = load i64, ptr %slot139, align 8
  %v914 = load i64, ptr %slot135, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v913, i64 %v914) nomerge, !dbg !120
  br label %bb_rcslotdone157
bb_rcslotdone157:
  %v915 = load i64, ptr %slot10, align 8
  %p916 = inttoptr i64 %v915 to ptr
  %ld917 = load i32, ptr %p916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld917, ptr %slot140, align 8
  %v918 = load i32, ptr %slot140, align 8
  %cv919 = zext i32 %v918 to i64
  %cond920 = icmp ne i64 %cv919, 0
  br i1 %cond920, label %bb_rcslotdrop166, label %bb_rcslotdone166
bb_rcslotdrop166:
  %v921 = load i64, ptr %slot10, align 8
  %p922 = inttoptr i64 %v921 to ptr
  store i32 0, ptr %p922, align 4, !alias.scope !3, !noalias !4
  %v923 = load i64, ptr %slot25, align 8
  store i64 %v923, ptr %slot141, align 8
  %v924 = load i64, ptr %slot11, align 8
  %p925 = inttoptr i64 %v924 to ptr
  %ld926 = load i32, ptr %p925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld926, ptr %slot142, align 8
  %v927 = load i32, ptr %slot142, align 8
  %op928 = and i32 %v927, 28
  store i32 %op928, ptr %slot143, align 8
  %v929 = load i32, ptr %slot143, align 8
  %cv930 = zext i32 %v929 to i64
  %cond931 = icmp ne i64 %cv930, 0
  br i1 %cond931, label %bb_rcslotrole166, label %bb_rcslotowner166
bb_rcslotrole166:
  %v932 = load i64, ptr %slot40, align 8
  store i64 %v932, ptr %slot144, align 8
  %v933 = load i64, ptr %slot144, align 8
  %v934 = load i64, ptr %slot141, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v933, i64 %v934) nomerge, !dbg !120
  br label %bb_rcslotdone166
bb_rcslotowner166:
  %v935 = load i64, ptr %slot40, align 8
  store i64 %v935, ptr %slot145, align 8
  %v936 = load i64, ptr %slot145, align 8
  %v937 = load i64, ptr %slot141, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v936, i64 %v937) nomerge, !dbg !120
  br label %bb_rcslotdone166
bb_rcslotdone166:
  %v938 = load i64, ptr %slot8, align 8
  %p939 = inttoptr i64 %v938 to ptr
  %ld940 = load i32, ptr %p939, align 4, !alias.scope !3, !noalias !4
  store i32 %ld940, ptr %slot146, align 8
  %v941 = load i32, ptr %slot146, align 8
  %cv942 = zext i32 %v941 to i64
  %cond943 = icmp ne i64 %cv942, 0
  br i1 %cond943, label %bb_rcslotdrop193, label %bb_rcslotdone193
bb_rcslotdrop193:
  %v944 = load i64, ptr %slot8, align 8
  %p945 = inttoptr i64 %v944 to ptr
  store i32 0, ptr %p945, align 4, !alias.scope !3, !noalias !4
  %v946 = load i64, ptr %slot23, align 8
  store i64 %v946, ptr %slot147, align 8
  %v947 = load i64, ptr %slot9, align 8
  %p948 = inttoptr i64 %v947 to ptr
  %ld949 = load i32, ptr %p948, align 4, !alias.scope !3, !noalias !4
  store i32 %ld949, ptr %slot148, align 8
  %v950 = load i32, ptr %slot148, align 8
  %op951 = and i32 %v950, 28
  store i32 %op951, ptr %slot149, align 8
  %v952 = load i32, ptr %slot149, align 8
  %cv953 = zext i32 %v952 to i64
  %cond954 = icmp ne i64 %cv953, 0
  br i1 %cond954, label %bb_rcslotrole193, label %bb_rcslotowner193
bb_rcslotrole193:
  %v955 = load i64, ptr %slot40, align 8
  store i64 %v955, ptr %slot150, align 8
  %v956 = load i64, ptr %slot150, align 8
  %v957 = load i64, ptr %slot147, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v956, i64 %v957) nomerge, !dbg !120
  br label %bb_rcslotdone193
bb_rcslotowner193:
  %v958 = load i64, ptr %slot40, align 8
  store i64 %v958, ptr %slot151, align 8
  %v959 = load i64, ptr %slot151, align 8
  %v960 = load i64, ptr %slot147, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v959, i64 %v960) nomerge, !dbg !120
  br label %bb_rcslotdone193
bb_rcslotdone193:
  %v961 = load i64, ptr %slot6, align 8
  %p962 = inttoptr i64 %v961 to ptr
  %ld963 = load i32, ptr %p962, align 4, !alias.scope !3, !noalias !4
  store i32 %ld963, ptr %slot152, align 8
  %v964 = load i32, ptr %slot152, align 8
  %cv965 = zext i32 %v964 to i64
  %cond966 = icmp ne i64 %cv965, 0
  br i1 %cond966, label %bb_rcslotdrop220, label %bb_rcslotdone220
bb_rcslotdrop220:
  %v967 = load i64, ptr %slot6, align 8
  %p968 = inttoptr i64 %v967 to ptr
  store i32 0, ptr %p968, align 4, !alias.scope !3, !noalias !4
  %v969 = load i64, ptr %slot22, align 8
  store i64 %v969, ptr %slot153, align 8
  %v970 = load i64, ptr %slot7, align 8
  %p971 = inttoptr i64 %v970 to ptr
  %ld972 = load i32, ptr %p971, align 4, !alias.scope !3, !noalias !4
  store i32 %ld972, ptr %slot154, align 8
  %v973 = load i32, ptr %slot154, align 8
  %op974 = and i32 %v973, 28
  store i32 %op974, ptr %slot155, align 8
  %v975 = load i32, ptr %slot155, align 8
  %cv976 = zext i32 %v975 to i64
  %cond977 = icmp ne i64 %cv976, 0
  br i1 %cond977, label %bb_rcslotrole220, label %bb_rcslotowner220
bb_rcslotrole220:
  %v978 = load i64, ptr %slot40, align 8
  store i64 %v978, ptr %slot156, align 8
  %v979 = load i64, ptr %slot156, align 8
  %v980 = load i64, ptr %slot153, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v979, i64 %v980) nomerge, !dbg !120
  br label %bb_rcslotdone220
bb_rcslotowner220:
  %v981 = load i64, ptr %slot40, align 8
  store i64 %v981, ptr %slot157, align 8
  %v982 = load i64, ptr %slot157, align 8
  %v983 = load i64, ptr %slot153, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v982, i64 %v983) nomerge, !dbg !120
  br label %bb_rcslotdone220
bb_rcslotdone220:
  %v984 = load i64, ptr %slot133, align 8
  %p985 = inttoptr i64 %v984 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p985, i64 24, i1 false)
  ret void
bb_i9:
  br label %bb_i33
bb_i11:
  %v986 = load i64, ptr %slot19, align 8
  %p987 = inttoptr i64 %v986 to ptr
  %ld988 = load i64, ptr %p987, align 8, !alias.scope !3, !noalias !4
  store i64 %ld988, ptr %slot158, align 8
  %v989 = load i64, ptr %slot158, align 8
  %v990 = load i64, ptr %slot30, align 8
  %p991 = inttoptr i64 %v989 to ptr
  %p992 = inttoptr i64 %v990 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p992, ptr %p991, i64 304, i1 false), !alias.scope !10000000
  %v993 = load i64, ptr %slot30, align 8
  %v994 = load i64, ptr %slot27, align 8
  %p995 = inttoptr i64 %v994 to ptr
  store i64 %v993, ptr %p995, align 8, !alias.scope !3, !noalias !4
  %v996 = load i64, ptr %slot27, align 8
  %p997 = inttoptr i64 %v996 to ptr
  %ld998 = load i64, ptr %p997, align 8, !alias.scope !3, !noalias !4
  store i64 %ld998, ptr %slot159, align 8
  %v999 = load i64, ptr %slot159, align 8
  %op1000 = add i64 %v999, 32
  store i64 %op1000, ptr %slot160, align 8
  %v1001 = load i64, ptr %slot160, align 8
  %v1002 = load i64, ptr %slot27, align 8
  %p1003 = inttoptr i64 %v1002 to ptr
  store i64 %v1001, ptr %p1003, align 8, !alias.scope !3, !noalias !4
  %v1004 = load i64, ptr %slot6, align 8
  %p1005 = inttoptr i64 %v1004 to ptr
  %ld1006 = load i32, ptr %p1005, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1006, ptr %slot161, align 8
  %v1007 = load i32, ptr %slot161, align 8
  %cv1008 = zext i32 %v1007 to i64
  %cond1009 = icmp ne i64 %cv1008, 0
  br i1 %cond1009, label %bb_rcslotdrop250, label %bb_rcslotdone250
bb_rcslotdrop250:
  %v1010 = load i64, ptr %slot6, align 8
  %p1011 = inttoptr i64 %v1010 to ptr
  store i32 0, ptr %p1011, align 4, !alias.scope !3, !noalias !4
  %v1012 = load i64, ptr %slot22, align 8
  store i64 %v1012, ptr %slot162, align 8
  %v1013 = load i64, ptr %slot7, align 8
  %p1014 = inttoptr i64 %v1013 to ptr
  %ld1015 = load i32, ptr %p1014, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1015, ptr %slot163, align 8
  %v1016 = load i32, ptr %slot163, align 8
  %op1017 = and i32 %v1016, 28
  store i32 %op1017, ptr %slot164, align 8
  %v1018 = load i32, ptr %slot164, align 8
  %cv1019 = zext i32 %v1018 to i64
  %cond1020 = icmp ne i64 %cv1019, 0
  br i1 %cond1020, label %bb_rcslotrole250, label %bb_rcslotowner250
bb_rcslotrole250:
  %v1021 = load i64, ptr %slot40, align 8
  store i64 %v1021, ptr %slot165, align 8
  %v1022 = load i64, ptr %slot165, align 8
  %v1023 = load i64, ptr %slot162, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1022, i64 %v1023) nomerge, !dbg !122
  br label %bb_rcslotdone250
bb_rcslotowner250:
  %v1024 = load i64, ptr %slot40, align 8
  store i64 %v1024, ptr %slot166, align 8
  %v1025 = load i64, ptr %slot166, align 8
  %v1026 = load i64, ptr %slot162, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1025, i64 %v1026) nomerge, !dbg !122
  br label %bb_rcslotdone250
bb_rcslotdone250:
  %v1027 = load i64, ptr %slot19, align 8
  %p1028 = inttoptr i64 %v1027 to ptr
  %ld1029 = load i64, ptr %p1028, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1029, ptr %slot167, align 8
  %v1030 = load i64, ptr %slot167, align 8
  %op1031 = add i64 %v1030, 32
  store i64 %op1031, ptr %slot168, align 8
  %v1032 = load i64, ptr %slot22, align 8
  store i64 %v1032, ptr %slot169, align 8
  %v1033 = load i64, ptr %slot168, align 8
  %v1034 = load i64, ptr %slot169, align 8
  %p1035 = inttoptr i64 %v1033 to ptr
  %p1036 = inttoptr i64 %v1034 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1036, ptr %p1035, i64 208, i1 false), !alias.scope !10000000
  %v1037 = load i64, ptr %slot168, align 8
  %p1038 = inttoptr i64 %v1037 to ptr
  call void @llvm.memset.p0.i64(ptr %p1038, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !122
  %v1039 = load i64, ptr %slot6, align 8
  %p1040 = inttoptr i64 %v1039 to ptr
  store i32 1, ptr %p1040, align 4, !alias.scope !3, !noalias !4
  %v1041 = load i64, ptr %slot22, align 8
  %v1042 = load i64, ptr %slot27, align 8
  %p1043 = inttoptr i64 %v1042 to ptr
  store i64 %v1041, ptr %p1043, align 8, !alias.scope !3, !noalias !4
  %v1044 = load i64, ptr %slot31, align 8
  store i64 %v1044, ptr %slot170, align 8
  %v1045 = load i64, ptr %slot170, align 8
  %p1046 = inttoptr i64 %v1045 to ptr
  store i64 0, ptr %p1046, align 8, !alias.scope !3, !noalias !4
  %v1047 = load i64, ptr %slot170, align 8
  %p1049 = inttoptr i64 %v1047 to ptr
  %gep1050 = getelementptr i8, ptr %p1049, i64 8
  %op1048 = ptrtoint ptr %gep1050 to i64
  store i64 %op1048, ptr %slot171, align 8
  %v1051 = load i64, ptr %slot171, align 8
  %p1052 = inttoptr i64 %v1051 to ptr
  store i64 0, ptr %p1052, align 8, !alias.scope !3, !noalias !4
  %v1053 = load i64, ptr %slot170, align 8
  %p1054 = inttoptr i64 %v1053 to ptr
  store i32 0, ptr %p1054, align 4, !alias.scope !3, !noalias !4
  %v1055 = load i64, ptr %slot170, align 8
  %v1056 = load i64, ptr %slot28, align 8
  %p1057 = inttoptr i64 %v1056 to ptr
  store i64 %v1055, ptr %p1057, align 8, !alias.scope !3, !noalias !4
  %v1058 = load i64, ptr %slot27, align 8
  %p1059 = inttoptr i64 %v1058 to ptr
  %ld1060 = load i64, ptr %p1059, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1060, ptr %slot172, align 8
  %v1061 = load i64, ptr %slot28, align 8
  %p1062 = inttoptr i64 %v1061 to ptr
  %ld1063 = load i64, ptr %p1062, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1063, ptr %slot173, align 8
  %v1064 = load i64, ptr %slot1, align 8
  %v1065 = load i64, ptr %slot172, align 8
  %v1066 = load i64, ptr %slot173, align 8
  %call1067 = call i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64 %v1064, i64 %v1065, i64 %v1066) nomerge, !dbg !124
  store i64 %call1067, ptr %slot174, align 8
  %v1068 = load i64, ptr %slot174, align 8
  %v1069 = load i64, ptr %slot27, align 8
  %p1070 = inttoptr i64 %v1069 to ptr
  store i64 %v1068, ptr %p1070, align 8, !alias.scope !3, !noalias !4
  %v1071 = load i64, ptr %slot12, align 8
  %p1072 = inttoptr i64 %v1071 to ptr
  %ld1073 = load i32, ptr %p1072, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1073, ptr %slot175, align 8
  %v1074 = load i32, ptr %slot175, align 8
  %cv1075 = zext i32 %v1074 to i64
  %cond1076 = icmp ne i64 %cv1075, 0
  br i1 %cond1076, label %bb_rcslotdrop268, label %bb_rcslotdone268
bb_rcslotdrop268:
  %v1077 = load i64, ptr %slot12, align 8
  %p1078 = inttoptr i64 %v1077 to ptr
  store i32 0, ptr %p1078, align 4, !alias.scope !3, !noalias !4
  %v1079 = load i64, ptr %slot17, align 8
  store i64 %v1079, ptr %slot176, align 8
  %v1080 = load i64, ptr %slot13, align 8
  %p1081 = inttoptr i64 %v1080 to ptr
  %ld1082 = load i32, ptr %p1081, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1082, ptr %slot177, align 8
  %v1083 = load i32, ptr %slot177, align 8
  %op1084 = and i32 %v1083, 28
  store i32 %op1084, ptr %slot178, align 8
  %v1085 = load i32, ptr %slot178, align 8
  %cv1086 = zext i32 %v1085 to i64
  %cond1087 = icmp ne i64 %cv1086, 0
  br i1 %cond1087, label %bb_rcslotrole268, label %bb_rcslotowner268
bb_rcslotrole268:
  %v1088 = load i64, ptr %slot40, align 8
  store i64 %v1088, ptr %slot179, align 8
  %v1089 = load i64, ptr %slot179, align 8
  %v1090 = load i64, ptr %slot176, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1089, i64 %v1090) nomerge, !dbg !124
  br label %bb_rcslotdone268
bb_rcslotowner268:
  %v1091 = load i64, ptr %slot40, align 8
  store i64 %v1091, ptr %slot180, align 8
  %v1092 = load i64, ptr %slot180, align 8
  %v1093 = load i64, ptr %slot176, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1092, i64 %v1093) nomerge, !dbg !124
  br label %bb_rcslotdone268
bb_rcslotdone268:
  %v1094 = load i64, ptr %slot19, align 8
  %p1095 = inttoptr i64 %v1094 to ptr
  %ld1096 = load i64, ptr %p1095, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1096, ptr %slot181, align 8
  %v1097 = load i64, ptr %slot181, align 8
  %op1098 = add i64 %v1097, 32
  store i64 %op1098, ptr %slot182, align 8
  %v1099 = load i64, ptr %slot22, align 8
  store i64 %v1099, ptr %slot183, align 8
  %v1100 = load i64, ptr %slot183, align 8
  %v1101 = load i64, ptr %slot182, align 8
  %p1102 = inttoptr i64 %v1100 to ptr
  %p1103 = inttoptr i64 %v1101 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1103, ptr %p1102, i64 208, i1 false), !alias.scope !10000000
  %v1104 = load i64, ptr %slot183, align 8
  %p1105 = inttoptr i64 %v1104 to ptr
  call void @llvm.memset.p0.i64(ptr %p1105, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v1106 = load i64, ptr %slot6, align 8
  %p1107 = inttoptr i64 %v1106 to ptr
  store i32 0, ptr %p1107, align 4, !alias.scope !3, !noalias !4
  %v1108 = load i64, ptr %slot27, align 8
  %p1109 = inttoptr i64 %v1108 to ptr
  store i64 0, ptr %p1109, align 8, !alias.scope !3, !noalias !4
  br label %bb_i33
bb_i33:
  %v1110 = load i64, ptr %slot19, align 8
  %p1111 = inttoptr i64 %v1110 to ptr
  %ld1112 = load i64, ptr %p1111, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1112, ptr %slot184, align 8
  %v1113 = load i64, ptr %slot184, align 8
  %v1114 = load i64, ptr %slot32, align 8
  %p1115 = inttoptr i64 %v1113 to ptr
  %p1116 = inttoptr i64 %v1114 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1116, ptr %p1115, i64 304, i1 false), !alias.scope !10000000
  %v1117 = load i64, ptr %slot32, align 8
  %v1118 = load i64, ptr %slot27, align 8
  %p1119 = inttoptr i64 %v1118 to ptr
  store i64 %v1117, ptr %p1119, align 8, !alias.scope !3, !noalias !4
  %v1120 = load i64, ptr %slot27, align 8
  %p1121 = inttoptr i64 %v1120 to ptr
  %ld1122 = load i64, ptr %p1121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1122, ptr %slot185, align 8
  %v1123 = load i64, ptr %slot185, align 8
  %op1124 = add i64 %v1123, 32
  store i64 %op1124, ptr %slot186, align 8
  %v1125 = load i64, ptr %slot186, align 8
  %v1126 = load i64, ptr %slot27, align 8
  %p1127 = inttoptr i64 %v1126 to ptr
  store i64 %v1125, ptr %p1127, align 8, !alias.scope !3, !noalias !4
  %v1128 = load i64, ptr %slot8, align 8
  %p1129 = inttoptr i64 %v1128 to ptr
  %ld1130 = load i32, ptr %p1129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1130, ptr %slot187, align 8
  %v1131 = load i32, ptr %slot187, align 8
  %cv1132 = zext i32 %v1131 to i64
  %cond1133 = icmp ne i64 %cv1132, 0
  br i1 %cond1133, label %bb_rcslotdrop284, label %bb_rcslotdone284
bb_rcslotdrop284:
  %v1134 = load i64, ptr %slot8, align 8
  %p1135 = inttoptr i64 %v1134 to ptr
  store i32 0, ptr %p1135, align 4, !alias.scope !3, !noalias !4
  %v1136 = load i64, ptr %slot23, align 8
  store i64 %v1136, ptr %slot188, align 8
  %v1137 = load i64, ptr %slot9, align 8
  %p1138 = inttoptr i64 %v1137 to ptr
  %ld1139 = load i32, ptr %p1138, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1139, ptr %slot189, align 8
  %v1140 = load i32, ptr %slot189, align 8
  %op1141 = and i32 %v1140, 28
  store i32 %op1141, ptr %slot190, align 8
  %v1142 = load i32, ptr %slot190, align 8
  %cv1143 = zext i32 %v1142 to i64
  %cond1144 = icmp ne i64 %cv1143, 0
  br i1 %cond1144, label %bb_rcslotrole284, label %bb_rcslotowner284
bb_rcslotrole284:
  %v1145 = load i64, ptr %slot40, align 8
  store i64 %v1145, ptr %slot191, align 8
  %v1146 = load i64, ptr %slot191, align 8
  %v1147 = load i64, ptr %slot188, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1146, i64 %v1147) nomerge, !dbg !128
  br label %bb_rcslotdone284
bb_rcslotowner284:
  %v1148 = load i64, ptr %slot40, align 8
  store i64 %v1148, ptr %slot192, align 8
  %v1149 = load i64, ptr %slot192, align 8
  %v1150 = load i64, ptr %slot188, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1149, i64 %v1150) nomerge, !dbg !128
  br label %bb_rcslotdone284
bb_rcslotdone284:
  %v1151 = load i64, ptr %slot19, align 8
  %p1152 = inttoptr i64 %v1151 to ptr
  %ld1153 = load i64, ptr %p1152, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1153, ptr %slot193, align 8
  %v1154 = load i64, ptr %slot193, align 8
  %op1155 = add i64 %v1154, 32
  store i64 %op1155, ptr %slot194, align 8
  %v1156 = load i64, ptr %slot23, align 8
  store i64 %v1156, ptr %slot195, align 8
  %v1157 = load i64, ptr %slot194, align 8
  %v1158 = load i64, ptr %slot195, align 8
  %p1159 = inttoptr i64 %v1157 to ptr
  %p1160 = inttoptr i64 %v1158 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1160, ptr %p1159, i64 208, i1 false), !alias.scope !10000000
  %v1161 = load i64, ptr %slot194, align 8
  %p1162 = inttoptr i64 %v1161 to ptr
  call void @llvm.memset.p0.i64(ptr %p1162, i8 0, i64 208, i1 false), !alias.scope !4, !noalias !3, !dbg !128
  %v1163 = load i64, ptr %slot8, align 8
  %p1164 = inttoptr i64 %v1163 to ptr
  store i32 1, ptr %p1164, align 4, !alias.scope !3, !noalias !4
  %v1165 = load i64, ptr %slot23, align 8
  %v1166 = load i64, ptr %slot27, align 8
  %p1167 = inttoptr i64 %v1166 to ptr
  store i64 %v1165, ptr %p1167, align 8, !alias.scope !3, !noalias !4
  %v1168 = load i64, ptr %slot27, align 8
  %p1169 = inttoptr i64 %v1168 to ptr
  %ld1170 = load i64, ptr %p1169, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1170, ptr %slot196, align 8
  %v1171 = load i64, ptr %slot1, align 8
  %v1172 = load i64, ptr %slot196, align 8
  %call1173 = call { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64 %v1171, i64 %v1172) nomerge, !dbg !130
  store { i64, i64 } %call1173, ptr %callresult198, align 8
  %addr1174 = ptrtoint ptr %callresult198 to i64
  store i64 %addr1174, ptr %slot197, align 8
  %v1175 = load i64, ptr %slot197, align 8
  %v1176 = load i64, ptr %slot27, align 8
  %p1177 = inttoptr i64 %v1176 to ptr
  store i64 %v1175, ptr %p1177, align 8, !alias.scope !3, !noalias !4
  %v1178 = load i64, ptr %slot12, align 8
  %p1179 = inttoptr i64 %v1178 to ptr
  %ld1180 = load i32, ptr %p1179, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1180, ptr %slot199, align 8
  %v1181 = load i32, ptr %slot199, align 8
  %cv1182 = zext i32 %v1181 to i64
  %cond1183 = icmp ne i64 %cv1182, 0
  br i1 %cond1183, label %bb_rcslotdrop299, label %bb_rcslotdone299
bb_rcslotdrop299:
  %v1184 = load i64, ptr %slot12, align 8
  %p1185 = inttoptr i64 %v1184 to ptr
  store i32 0, ptr %p1185, align 4, !alias.scope !3, !noalias !4
  %v1186 = load i64, ptr %slot17, align 8
  store i64 %v1186, ptr %slot200, align 8
  %v1187 = load i64, ptr %slot13, align 8
  %p1188 = inttoptr i64 %v1187 to ptr
  %ld1189 = load i32, ptr %p1188, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1189, ptr %slot201, align 8
  %v1190 = load i32, ptr %slot201, align 8
  %op1191 = and i32 %v1190, 28
  store i32 %op1191, ptr %slot202, align 8
  %v1192 = load i32, ptr %slot202, align 8
  %cv1193 = zext i32 %v1192 to i64
  %cond1194 = icmp ne i64 %cv1193, 0
  br i1 %cond1194, label %bb_rcslotrole299, label %bb_rcslotowner299
bb_rcslotrole299:
  %v1195 = load i64, ptr %slot40, align 8
  store i64 %v1195, ptr %slot203, align 8
  %v1196 = load i64, ptr %slot203, align 8
  %v1197 = load i64, ptr %slot200, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1196, i64 %v1197) nomerge, !dbg !130
  br label %bb_rcslotdone299
bb_rcslotowner299:
  %v1198 = load i64, ptr %slot40, align 8
  store i64 %v1198, ptr %slot204, align 8
  %v1199 = load i64, ptr %slot204, align 8
  %v1200 = load i64, ptr %slot200, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1199, i64 %v1200) nomerge, !dbg !130
  br label %bb_rcslotdone299
bb_rcslotdone299:
  %v1201 = load i64, ptr %slot27, align 8
  %p1202 = inttoptr i64 %v1201 to ptr
  %ld1203 = load i64, ptr %p1202, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1203, ptr %slot205, align 8
  %v1204 = load i64, ptr %slot205, align 8
  %v1205 = load i64, ptr %slot24, align 8
  %p1206 = inttoptr i64 %v1204 to ptr
  %p1207 = inttoptr i64 %v1205 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1207, ptr %p1206, i64 16, i1 false)
  %v1208 = load i64, ptr %slot19, align 8
  %p1209 = inttoptr i64 %v1208 to ptr
  %ld1210 = load i64, ptr %p1209, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1210, ptr %slot206, align 8
  %v1211 = load i64, ptr %slot206, align 8
  %op1212 = add i64 %v1211, 32
  store i64 %op1212, ptr %slot207, align 8
  %v1213 = load i64, ptr %slot23, align 8
  store i64 %v1213, ptr %slot208, align 8
  %v1214 = load i64, ptr %slot208, align 8
  %v1215 = load i64, ptr %slot207, align 8
  %p1216 = inttoptr i64 %v1214 to ptr
  %p1217 = inttoptr i64 %v1215 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1217, ptr %p1216, i64 208, i1 false), !alias.scope !10000000
  %v1218 = load i64, ptr %slot208, align 8
  %p1219 = inttoptr i64 %v1218 to ptr
  call void @llvm.memset.p0.i64(ptr %p1219, i8 0, i64 208, i1 false), !alias.scope !3, !noalias !4, !dbg !132
  %v1220 = load i64, ptr %slot8, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  store i32 0, ptr %p1221, align 4, !alias.scope !3, !noalias !4
  %v1222 = load i64, ptr %slot27, align 8
  %p1223 = inttoptr i64 %v1222 to ptr
  store i64 0, ptr %p1223, align 8, !alias.scope !3, !noalias !4
  %v1224 = load i64, ptr %slot24, align 8
  %v1225 = load i64, ptr %slot27, align 8
  %p1226 = inttoptr i64 %v1225 to ptr
  store i64 %v1224, ptr %p1226, align 8, !alias.scope !3, !noalias !4
  %v1227 = load i64, ptr %slot27, align 8
  %p1228 = inttoptr i64 %v1227 to ptr
  %ld1229 = load i64, ptr %p1228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1229, ptr %slot209, align 8
  %v1230 = load i64, ptr %slot209, align 8
  %v1231 = load i64, ptr %slot26, align 8
  %p1232 = inttoptr i64 %v1230 to ptr
  %p1233 = inttoptr i64 %v1231 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1233, ptr %p1232, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1234 = load i64, ptr %slot19, align 8
  %p1235 = inttoptr i64 %v1234 to ptr
  %ld1236 = load i64, ptr %p1235, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1236, ptr %slot210, align 8
  %v1237 = load i64, ptr %slot210, align 8
  %v1238 = load i64, ptr %slot27, align 8
  %p1239 = inttoptr i64 %v1238 to ptr
  store i64 %v1237, ptr %p1239, align 8, !alias.scope !3, !noalias !4
  %v1240 = load i64, ptr %slot27, align 8
  %p1241 = inttoptr i64 %v1240 to ptr
  %ld1242 = load i64, ptr %p1241, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1242, ptr %slot211, align 8
  %v1243 = load i64, ptr %slot12, align 8
  %p1244 = inttoptr i64 %v1243 to ptr
  %ld1245 = load i32, ptr %p1244, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1245, ptr %slot212, align 8
  %v1246 = load i64, ptr %slot13, align 8
  %p1247 = inttoptr i64 %v1246 to ptr
  %ld1248 = load i32, ptr %p1247, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1248, ptr %slot213, align 8
  %v1249 = load i32, ptr %slot213, align 8
  %op1250 = and i32 %v1249, 24
  store i32 %op1250, ptr %slot213, align 8
  %v1251 = load i32, ptr %slot213, align 8
  %cmp1252 = icmp eq i32 %v1251, 0
  %cv1253 = zext i1 %cmp1252 to i32
  store i32 %cv1253, ptr %slot214, align 8
  %v1254 = load i32, ptr %slot212, align 8
  %v1255 = load i32, ptr %slot214, align 8
  %op1256 = and i32 %v1254, %v1255
  store i32 %op1256, ptr %slot215, align 8
  %v1257 = load i32, ptr %slot215, align 8
  %cv1258 = zext i32 %v1257 to i64
  %cond1259 = icmp ne i64 %cv1258, 0
  br i1 %cond1259, label %bb_rcprivateown320, label %bb_rcprivateloan320
bb_rcprivateown320:
  %v1260 = load i64, ptr %slot18, align 8
  store i64 %v1260, ptr %slot216, align 8
  %v1261 = load i64, ptr %slot41, align 8
  store i64 %v1261, ptr %slot217, align 8
  %v1262 = load i64, ptr %slot40, align 8
  %v1263 = load i64, ptr %slot216, align 8
  %v1264 = load i64, ptr %slot211, align 8
  %v1265 = load i64, ptr %slot217, align 8
  %cv1266 = trunc i64 %v1265 to i32
  %call1267 = call i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_take(i64 %v1262, i64 %v1263, i64 %v1264, i32 %cv1266) nomerge, !dbg !134
  store i32 %call1267, ptr %slot218, align 8
  %v1268 = load i32, ptr %slot218, align 8
  %cv1269 = zext i32 %v1268 to i64
  %cond1270 = icmp ne i64 %cv1269, 0
  br i1 %cond1270, label %bb_rcsuccess324, label %bb_rcfailure324
bb_rcfailure324:
  %v1271 = load i64, ptr %slot40, align 8
  %p1272 = inttoptr i64 %v1271 to ptr
  %call1273 = call i32 @myl_rc_take_failure(ptr %p1272) nomerge, !dbg !134
  store i32 %call1273, ptr %slot219, align 8
  %v1274 = load i64, ptr %slot1, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  %v1276 = load i32, ptr %slot219, align 8
  %call1277 = call i32 @myl_qbe_rc_status(ptr %p1275, i32 %v1276) nomerge, !dbg !134
  store i32 %call1277, ptr %slot220, align 8
  br label %bb_failure
bb_rcsuccess324:
  %v1278 = load i64, ptr %slot12, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  store i32 0, ptr %p1279, align 4, !alias.scope !3, !noalias !4
  %v1280 = load i64, ptr %slot15, align 8
  %p1281 = inttoptr i64 %v1280 to ptr
  store i32 2, ptr %p1281, align 4, !alias.scope !3, !noalias !4
  %v1282 = load i64, ptr %slot14, align 8
  %p1283 = inttoptr i64 %v1282 to ptr
  store i32 1, ptr %p1283, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared320
bb_rcprivateloan320:
  %v1284 = load i64, ptr %slot18, align 8
  store i64 %v1284, ptr %slot221, align 8
  %v1285 = load i64, ptr %slot40, align 8
  %v1286 = load i64, ptr %slot221, align 8
  %v1287 = load i64, ptr %slot211, align 8
  %call1288 = call i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_loan(i64 %v1285, i64 %v1286, i64 %v1287) nomerge, !dbg !134
  store i32 %call1288, ptr %slot222, align 8
  %v1289 = load i32, ptr %slot222, align 8
  %cv1290 = zext i32 %v1289 to i64
  %cond1291 = icmp ne i64 %cv1290, 0
  br i1 %cond1291, label %bb_rcsuccess332, label %bb_rcfailure332
bb_rcfailure332:
  %v1292 = load i64, ptr %slot40, align 8
  %p1293 = inttoptr i64 %v1292 to ptr
  %call1294 = call i32 @myl_rc_take_failure(ptr %p1293) nomerge, !dbg !134
  store i32 %call1294, ptr %slot223, align 8
  %v1295 = load i64, ptr %slot1, align 8
  %p1296 = inttoptr i64 %v1295 to ptr
  %v1297 = load i32, ptr %slot223, align 8
  %call1298 = call i32 @myl_qbe_rc_status(ptr %p1296, i32 %v1297) nomerge, !dbg !134
  store i32 %call1298, ptr %slot224, align 8
  br label %bb_failure
bb_rcsuccess332:
  %v1299 = load i64, ptr %slot15, align 8
  %p1300 = inttoptr i64 %v1299 to ptr
  store i32 2, ptr %p1300, align 4, !alias.scope !3, !noalias !4
  %v1301 = load i64, ptr %slot15, align 8
  %p1302 = inttoptr i64 %v1301 to ptr
  store i32 16, ptr %p1302, align 4, !alias.scope !3, !noalias !4
  %v1303 = load i64, ptr %slot14, align 8
  %p1304 = inttoptr i64 %v1303 to ptr
  store i32 1, ptr %p1304, align 4, !alias.scope !3, !noalias !4
  %v1305 = load i64, ptr %slot12, align 8
  %p1306 = inttoptr i64 %v1305 to ptr
  %ld1307 = load i32, ptr %p1306, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1307, ptr %slot225, align 8
  %v1308 = load i32, ptr %slot225, align 8
  %cv1309 = zext i32 %v1308 to i64
  %cond1310 = icmp ne i64 %cv1309, 0
  br i1 %cond1310, label %bb_rcslotdrop340, label %bb_rcslotdone340
bb_rcslotdrop340:
  %v1311 = load i64, ptr %slot12, align 8
  %p1312 = inttoptr i64 %v1311 to ptr
  store i32 0, ptr %p1312, align 4, !alias.scope !3, !noalias !4
  %v1313 = load i64, ptr %slot17, align 8
  store i64 %v1313, ptr %slot226, align 8
  %v1314 = load i64, ptr %slot13, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  %ld1316 = load i32, ptr %p1315, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1316, ptr %slot227, align 8
  %v1317 = load i32, ptr %slot227, align 8
  %op1318 = and i32 %v1317, 28
  store i32 %op1318, ptr %slot228, align 8
  %v1319 = load i32, ptr %slot228, align 8
  %cv1320 = zext i32 %v1319 to i64
  %cond1321 = icmp ne i64 %cv1320, 0
  br i1 %cond1321, label %bb_rcslotrole340, label %bb_rcslotowner340
bb_rcslotrole340:
  %v1322 = load i64, ptr %slot40, align 8
  store i64 %v1322, ptr %slot229, align 8
  %v1323 = load i64, ptr %slot229, align 8
  %v1324 = load i64, ptr %slot226, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1323, i64 %v1324) nomerge, !dbg !134
  br label %bb_rcslotdone340
bb_rcslotowner340:
  %v1325 = load i64, ptr %slot40, align 8
  store i64 %v1325, ptr %slot230, align 8
  %v1326 = load i64, ptr %slot230, align 8
  %v1327 = load i64, ptr %slot226, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1326, i64 %v1327) nomerge, !dbg !134
  br label %bb_rcslotdone340
bb_rcslotdone340:
  br label %bb_rcprivateprepared320
bb_rcprivateprepared320:
  %v1328 = load i64, ptr %slot10, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  %ld1330 = load i32, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1330, ptr %slot231, align 8
  %v1331 = load i32, ptr %slot231, align 8
  %cv1332 = zext i32 %v1331 to i64
  %cond1333 = icmp ne i64 %cv1332, 0
  br i1 %cond1333, label %bb_rcslotdrop350, label %bb_rcslotdone350
bb_rcslotdrop350:
  %v1334 = load i64, ptr %slot10, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i32 0, ptr %p1335, align 4, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot25, align 8
  store i64 %v1336, ptr %slot232, align 8
  %v1337 = load i64, ptr %slot11, align 8
  %p1338 = inttoptr i64 %v1337 to ptr
  %ld1339 = load i32, ptr %p1338, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1339, ptr %slot233, align 8
  %v1340 = load i32, ptr %slot233, align 8
  %op1341 = and i32 %v1340, 28
  store i32 %op1341, ptr %slot234, align 8
  %v1342 = load i32, ptr %slot234, align 8
  %cv1343 = zext i32 %v1342 to i64
  %cond1344 = icmp ne i64 %cv1343, 0
  br i1 %cond1344, label %bb_rcslotrole350, label %bb_rcslotowner350
bb_rcslotrole350:
  %v1345 = load i64, ptr %slot40, align 8
  store i64 %v1345, ptr %slot235, align 8
  %v1346 = load i64, ptr %slot235, align 8
  %v1347 = load i64, ptr %slot232, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1346, i64 %v1347) nomerge, !dbg !134
  br label %bb_rcslotdone350
bb_rcslotowner350:
  %v1348 = load i64, ptr %slot40, align 8
  store i64 %v1348, ptr %slot236, align 8
  %v1349 = load i64, ptr %slot236, align 8
  %v1350 = load i64, ptr %slot232, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1349, i64 %v1350) nomerge, !dbg !134
  br label %bb_rcslotdone350
bb_rcslotdone350:
  %v1351 = load i64, ptr %slot25, align 8
  store i64 %v1351, ptr %slot237, align 8
  %v1352 = load i64, ptr %slot18, align 8
  store i64 %v1352, ptr %slot238, align 8
  %v1353 = load i64, ptr %slot238, align 8
  %v1354 = load i64, ptr %slot237, align 8
  %p1355 = inttoptr i64 %v1353 to ptr
  %p1356 = inttoptr i64 %v1354 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1356, ptr %p1355, i64 304, i1 false), !alias.scope !3, !noalias !4
  %v1357 = load i64, ptr %slot14, align 8
  %p1358 = inttoptr i64 %v1357 to ptr
  store i32 0, ptr %p1358, align 4, !alias.scope !3, !noalias !4
  %v1359 = load i64, ptr %slot11, align 8
  %p1360 = inttoptr i64 %v1359 to ptr
  store i32 2, ptr %p1360, align 4, !alias.scope !3, !noalias !4
  %v1361 = load i64, ptr %slot15, align 8
  %p1362 = inttoptr i64 %v1361 to ptr
  %ld1363 = load i32, ptr %p1362, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1363, ptr %slot239, align 8
  %v1364 = load i32, ptr %slot239, align 8
  %v1365 = load i64, ptr %slot11, align 8
  %p1366 = inttoptr i64 %v1365 to ptr
  store i32 %v1364, ptr %p1366, align 4, !alias.scope !3, !noalias !4
  %v1367 = load i64, ptr %slot10, align 8
  %p1368 = inttoptr i64 %v1367 to ptr
  store i32 1, ptr %p1368, align 4, !alias.scope !3, !noalias !4
  %v1369 = load i64, ptr %slot19, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %ld1371 = load i64, ptr %p1370, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1371, ptr %slot240, align 8
  %v1372 = load i64, ptr %slot240, align 8
  %v1373 = load i64, ptr %slot27, align 8
  %p1374 = inttoptr i64 %v1373 to ptr
  store i64 %v1372, ptr %p1374, align 8, !alias.scope !3, !noalias !4
  %v1375 = load i64, ptr %slot27, align 8
  %p1376 = inttoptr i64 %v1375 to ptr
  %ld1377 = load i64, ptr %p1376, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1377, ptr %slot241, align 8
  %v1378 = load i64, ptr %slot12, align 8
  %p1379 = inttoptr i64 %v1378 to ptr
  %ld1380 = load i32, ptr %p1379, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1380, ptr %slot242, align 8
  %v1381 = load i64, ptr %slot13, align 8
  %p1382 = inttoptr i64 %v1381 to ptr
  %ld1383 = load i32, ptr %p1382, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1383, ptr %slot243, align 8
  %v1384 = load i32, ptr %slot243, align 8
  %op1385 = and i32 %v1384, 24
  store i32 %op1385, ptr %slot243, align 8
  %v1386 = load i32, ptr %slot243, align 8
  %cmp1387 = icmp eq i32 %v1386, 0
  %cv1388 = zext i1 %cmp1387 to i32
  store i32 %cv1388, ptr %slot244, align 8
  %v1389 = load i32, ptr %slot242, align 8
  %v1390 = load i32, ptr %slot244, align 8
  %op1391 = and i32 %v1389, %v1390
  store i32 %op1391, ptr %slot245, align 8
  %v1392 = load i32, ptr %slot245, align 8
  %cv1393 = zext i32 %v1392 to i64
  %cond1394 = icmp ne i64 %cv1393, 0
  br i1 %cond1394, label %bb_rcprivateown372, label %bb_rcprivateloan372
bb_rcprivateown372:
  %v1395 = load i64, ptr %slot18, align 8
  store i64 %v1395, ptr %slot246, align 8
  %v1396 = load i64, ptr %slot41, align 8
  store i64 %v1396, ptr %slot247, align 8
  %v1397 = load i64, ptr %slot40, align 8
  %v1398 = load i64, ptr %slot246, align 8
  %v1399 = load i64, ptr %slot241, align 8
  %v1400 = load i64, ptr %slot247, align 8
  %cv1401 = trunc i64 %v1400 to i32
  %call1402 = call i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_take(i64 %v1397, i64 %v1398, i64 %v1399, i32 %cv1401) nomerge, !dbg !136
  store i32 %call1402, ptr %slot248, align 8
  %v1403 = load i32, ptr %slot248, align 8
  %cv1404 = zext i32 %v1403 to i64
  %cond1405 = icmp ne i64 %cv1404, 0
  br i1 %cond1405, label %bb_rcsuccess376, label %bb_rcfailure376
bb_rcfailure376:
  %v1406 = load i64, ptr %slot40, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  %call1408 = call i32 @myl_rc_take_failure(ptr %p1407) nomerge, !dbg !136
  store i32 %call1408, ptr %slot249, align 8
  %v1409 = load i64, ptr %slot1, align 8
  %p1410 = inttoptr i64 %v1409 to ptr
  %v1411 = load i32, ptr %slot249, align 8
  %call1412 = call i32 @myl_qbe_rc_status(ptr %p1410, i32 %v1411) nomerge, !dbg !136
  store i32 %call1412, ptr %slot250, align 8
  br label %bb_failure
bb_rcsuccess376:
  %v1413 = load i64, ptr %slot12, align 8
  %p1414 = inttoptr i64 %v1413 to ptr
  store i32 0, ptr %p1414, align 4, !alias.scope !3, !noalias !4
  %v1415 = load i64, ptr %slot15, align 8
  %p1416 = inttoptr i64 %v1415 to ptr
  store i32 2, ptr %p1416, align 4, !alias.scope !3, !noalias !4
  %v1417 = load i64, ptr %slot14, align 8
  %p1418 = inttoptr i64 %v1417 to ptr
  store i32 1, ptr %p1418, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared372
bb_rcprivateloan372:
  %v1419 = load i64, ptr %slot18, align 8
  store i64 %v1419, ptr %slot251, align 8
  %v1420 = load i64, ptr %slot40, align 8
  %v1421 = load i64, ptr %slot251, align 8
  %v1422 = load i64, ptr %slot241, align 8
  %call1423 = call i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_loan(i64 %v1420, i64 %v1421, i64 %v1422) nomerge, !dbg !136
  store i32 %call1423, ptr %slot252, align 8
  %v1424 = load i32, ptr %slot252, align 8
  %cv1425 = zext i32 %v1424 to i64
  %cond1426 = icmp ne i64 %cv1425, 0
  br i1 %cond1426, label %bb_rcsuccess384, label %bb_rcfailure384
bb_rcfailure384:
  %v1427 = load i64, ptr %slot40, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  %call1429 = call i32 @myl_rc_take_failure(ptr %p1428) nomerge, !dbg !136
  store i32 %call1429, ptr %slot253, align 8
  %v1430 = load i64, ptr %slot1, align 8
  %p1431 = inttoptr i64 %v1430 to ptr
  %v1432 = load i32, ptr %slot253, align 8
  %call1433 = call i32 @myl_qbe_rc_status(ptr %p1431, i32 %v1432) nomerge, !dbg !136
  store i32 %call1433, ptr %slot254, align 8
  br label %bb_failure
bb_rcsuccess384:
  %v1434 = load i64, ptr %slot15, align 8
  %p1435 = inttoptr i64 %v1434 to ptr
  store i32 2, ptr %p1435, align 4, !alias.scope !3, !noalias !4
  %v1436 = load i64, ptr %slot15, align 8
  %p1437 = inttoptr i64 %v1436 to ptr
  store i32 16, ptr %p1437, align 4, !alias.scope !3, !noalias !4
  %v1438 = load i64, ptr %slot14, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  store i32 1, ptr %p1439, align 4, !alias.scope !3, !noalias !4
  %v1440 = load i64, ptr %slot12, align 8
  %p1441 = inttoptr i64 %v1440 to ptr
  %ld1442 = load i32, ptr %p1441, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1442, ptr %slot255, align 8
  %v1443 = load i32, ptr %slot255, align 8
  %cv1444 = zext i32 %v1443 to i64
  %cond1445 = icmp ne i64 %cv1444, 0
  br i1 %cond1445, label %bb_rcslotdrop392, label %bb_rcslotdone392
bb_rcslotdrop392:
  %v1446 = load i64, ptr %slot12, align 8
  %p1447 = inttoptr i64 %v1446 to ptr
  store i32 0, ptr %p1447, align 4, !alias.scope !3, !noalias !4
  %v1448 = load i64, ptr %slot17, align 8
  store i64 %v1448, ptr %slot256, align 8
  %v1449 = load i64, ptr %slot13, align 8
  %p1450 = inttoptr i64 %v1449 to ptr
  %ld1451 = load i32, ptr %p1450, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1451, ptr %slot257, align 8
  %v1452 = load i32, ptr %slot257, align 8
  %op1453 = and i32 %v1452, 28
  store i32 %op1453, ptr %slot258, align 8
  %v1454 = load i32, ptr %slot258, align 8
  %cv1455 = zext i32 %v1454 to i64
  %cond1456 = icmp ne i64 %cv1455, 0
  br i1 %cond1456, label %bb_rcslotrole392, label %bb_rcslotowner392
bb_rcslotrole392:
  %v1457 = load i64, ptr %slot40, align 8
  store i64 %v1457, ptr %slot259, align 8
  %v1458 = load i64, ptr %slot259, align 8
  %v1459 = load i64, ptr %slot256, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1458, i64 %v1459) nomerge, !dbg !136
  br label %bb_rcslotdone392
bb_rcslotowner392:
  %v1460 = load i64, ptr %slot40, align 8
  store i64 %v1460, ptr %slot260, align 8
  %v1461 = load i64, ptr %slot260, align 8
  %v1462 = load i64, ptr %slot256, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1461, i64 %v1462) nomerge, !dbg !136
  br label %bb_rcslotdone392
bb_rcslotdone392:
  br label %bb_rcprivateprepared372
bb_rcprivateprepared372:
  %v1463 = load i64, ptr %slot10, align 8
  %p1464 = inttoptr i64 %v1463 to ptr
  %ld1465 = load i32, ptr %p1464, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1465, ptr %slot261, align 8
  %v1466 = load i32, ptr %slot261, align 8
  %cv1467 = zext i32 %v1466 to i64
  %cond1468 = icmp ne i64 %cv1467, 0
  br i1 %cond1468, label %bb_rcslotdrop402, label %bb_rcslotdone402
bb_rcslotdrop402:
  %v1469 = load i64, ptr %slot10, align 8
  %p1470 = inttoptr i64 %v1469 to ptr
  store i32 0, ptr %p1470, align 4, !alias.scope !3, !noalias !4
  %v1471 = load i64, ptr %slot25, align 8
  store i64 %v1471, ptr %slot262, align 8
  %v1472 = load i64, ptr %slot11, align 8
  %p1473 = inttoptr i64 %v1472 to ptr
  %ld1474 = load i32, ptr %p1473, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1474, ptr %slot263, align 8
  %v1475 = load i32, ptr %slot263, align 8
  %op1476 = and i32 %v1475, 28
  store i32 %op1476, ptr %slot264, align 8
  %v1477 = load i32, ptr %slot264, align 8
  %cv1478 = zext i32 %v1477 to i64
  %cond1479 = icmp ne i64 %cv1478, 0
  br i1 %cond1479, label %bb_rcslotrole402, label %bb_rcslotowner402
bb_rcslotrole402:
  %v1480 = load i64, ptr %slot40, align 8
  store i64 %v1480, ptr %slot265, align 8
  %v1481 = load i64, ptr %slot265, align 8
  %v1482 = load i64, ptr %slot262, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1481, i64 %v1482) nomerge, !dbg !136
  br label %bb_rcslotdone402
bb_rcslotowner402:
  %v1483 = load i64, ptr %slot40, align 8
  store i64 %v1483, ptr %slot266, align 8
  %v1484 = load i64, ptr %slot266, align 8
  %v1485 = load i64, ptr %slot262, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1484, i64 %v1485) nomerge, !dbg !136
  br label %bb_rcslotdone402
bb_rcslotdone402:
  %v1486 = load i64, ptr %slot25, align 8
  store i64 %v1486, ptr %slot267, align 8
  %v1487 = load i64, ptr %slot18, align 8
  store i64 %v1487, ptr %slot268, align 8
  %v1488 = load i64, ptr %slot268, align 8
  %v1489 = load i64, ptr %slot267, align 8
  %p1490 = inttoptr i64 %v1488 to ptr
  %p1491 = inttoptr i64 %v1489 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1491, ptr %p1490, i64 304, i1 false), !alias.scope !3, !noalias !4
  %v1492 = load i64, ptr %slot14, align 8
  %p1493 = inttoptr i64 %v1492 to ptr
  store i32 0, ptr %p1493, align 4, !alias.scope !3, !noalias !4
  %v1494 = load i64, ptr %slot11, align 8
  %p1495 = inttoptr i64 %v1494 to ptr
  store i32 2, ptr %p1495, align 4, !alias.scope !3, !noalias !4
  %v1496 = load i64, ptr %slot15, align 8
  %p1497 = inttoptr i64 %v1496 to ptr
  %ld1498 = load i32, ptr %p1497, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1498, ptr %slot269, align 8
  %v1499 = load i32, ptr %slot269, align 8
  %v1500 = load i64, ptr %slot11, align 8
  %p1501 = inttoptr i64 %v1500 to ptr
  store i32 %v1499, ptr %p1501, align 4, !alias.scope !3, !noalias !4
  %v1502 = load i64, ptr %slot10, align 8
  %p1503 = inttoptr i64 %v1502 to ptr
  store i32 1, ptr %p1503, align 4, !alias.scope !3, !noalias !4
  %v1504 = load i64, ptr %slot25, align 8
  %v1505 = load i64, ptr %slot27, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  store i64 %v1504, ptr %p1506, align 8, !alias.scope !3, !noalias !4
  %v1507 = load i64, ptr %slot26, align 8
  %v1508 = load i64, ptr %slot28, align 8
  %p1509 = inttoptr i64 %v1508 to ptr
  store i64 %v1507, ptr %p1509, align 8, !alias.scope !3, !noalias !4
  %v1510 = load i64, ptr %slot27, align 8
  %p1511 = inttoptr i64 %v1510 to ptr
  %ld1512 = load i64, ptr %p1511, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1512, ptr %slot270, align 8
  %v1513 = load i64, ptr %slot12, align 8
  %p1514 = inttoptr i64 %v1513 to ptr
  %ld1515 = load i32, ptr %p1514, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1515, ptr %slot271, align 8
  %v1516 = load i64, ptr %slot13, align 8
  %p1517 = inttoptr i64 %v1516 to ptr
  %ld1518 = load i32, ptr %p1517, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1518, ptr %slot272, align 8
  %v1519 = load i32, ptr %slot272, align 8
  %op1520 = and i32 %v1519, 24
  store i32 %op1520, ptr %slot272, align 8
  %v1521 = load i32, ptr %slot272, align 8
  %cmp1522 = icmp eq i32 %v1521, 0
  %cv1523 = zext i1 %cmp1522 to i32
  store i32 %cv1523, ptr %slot273, align 8
  %v1524 = load i32, ptr %slot271, align 8
  %v1525 = load i32, ptr %slot273, align 8
  %op1526 = and i32 %v1524, %v1525
  store i32 %op1526, ptr %slot274, align 8
  %v1527 = load i32, ptr %slot274, align 8
  %cv1528 = zext i32 %v1527 to i64
  %cond1529 = icmp ne i64 %cv1528, 0
  br i1 %cond1529, label %bb_rctake417, label %bb_rccopy417
bb_rctake417:
  %v1530 = load i64, ptr %slot18, align 8
  store i64 %v1530, ptr %slot275, align 8
  %v1531 = load i64, ptr %slot41, align 8
  store i64 %v1531, ptr %slot276, align 8
  %v1532 = load i64, ptr %slot40, align 8
  %v1533 = load i64, ptr %slot275, align 8
  %v1534 = load i64, ptr %slot270, align 8
  %v1535 = load i64, ptr %slot276, align 8
  %cv1536 = trunc i64 %v1535 to i32
  %call1537 = call i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_take(i64 %v1532, i64 %v1533, i64 %v1534, i32 %cv1536) nomerge, !dbg !138
  store i32 %call1537, ptr %slot277, align 8
  %v1538 = load i32, ptr %slot277, align 8
  %cv1539 = zext i32 %v1538 to i64
  %cond1540 = icmp ne i64 %cv1539, 0
  br i1 %cond1540, label %bb_rcsuccess427, label %bb_rcfailure427
bb_rcfailure427:
  %v1541 = load i64, ptr %slot40, align 8
  %p1542 = inttoptr i64 %v1541 to ptr
  %call1543 = call i32 @myl_rc_take_failure(ptr %p1542) nomerge, !dbg !138
  store i32 %call1543, ptr %slot278, align 8
  %v1544 = load i64, ptr %slot1, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  %v1546 = load i32, ptr %slot278, align 8
  %call1547 = call i32 @myl_qbe_rc_status(ptr %p1545, i32 %v1546) nomerge, !dbg !138
  store i32 %call1547, ptr %slot279, align 8
  br label %bb_failure
bb_rcsuccess427:
  %v1548 = load i64, ptr %slot12, align 8
  %p1549 = inttoptr i64 %v1548 to ptr
  store i32 0, ptr %p1549, align 4, !alias.scope !3, !noalias !4
  %v1550 = load i64, ptr %slot15, align 8
  %p1551 = inttoptr i64 %v1550 to ptr
  store i32 2, ptr %p1551, align 4, !alias.scope !3, !noalias !4
  %v1552 = load i64, ptr %slot14, align 8
  %p1553 = inttoptr i64 %v1552 to ptr
  store i32 1, ptr %p1553, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared417
bb_rccopy417:
  %v1554 = load i64, ptr %slot18, align 8
  store i64 %v1554, ptr %slot280, align 8
  %v1555 = load i64, ptr %slot41, align 8
  store i64 %v1555, ptr %slot281, align 8
  %v1556 = load i64, ptr %slot40, align 8
  %v1557 = load i64, ptr %slot280, align 8
  %v1558 = load i64, ptr %slot270, align 8
  %v1559 = load i64, ptr %slot281, align 8
  %cv1560 = trunc i64 %v1559 to i32
  %call1561 = call i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_retain(i64 %v1556, i64 %v1557, i64 %v1558, i32 %cv1560) nomerge, !dbg !138
  store i32 %call1561, ptr %slot282, align 8
  %v1562 = load i32, ptr %slot282, align 8
  %cv1563 = zext i32 %v1562 to i64
  %cond1564 = icmp ne i64 %cv1563, 0
  br i1 %cond1564, label %bb_rcsuccess436, label %bb_rcfailure436
bb_rcfailure436:
  %v1565 = load i64, ptr %slot40, align 8
  %p1566 = inttoptr i64 %v1565 to ptr
  %call1567 = call i32 @myl_rc_take_failure(ptr %p1566) nomerge, !dbg !138
  store i32 %call1567, ptr %slot283, align 8
  %v1568 = load i64, ptr %slot1, align 8
  %p1569 = inttoptr i64 %v1568 to ptr
  %v1570 = load i32, ptr %slot283, align 8
  %call1571 = call i32 @myl_qbe_rc_status(ptr %p1569, i32 %v1570) nomerge, !dbg !138
  store i32 %call1571, ptr %slot284, align 8
  br label %bb_failure
bb_rcsuccess436:
  %v1572 = load i64, ptr %slot15, align 8
  %p1573 = inttoptr i64 %v1572 to ptr
  store i32 2, ptr %p1573, align 4, !alias.scope !3, !noalias !4
  %v1574 = load i64, ptr %slot14, align 8
  %p1575 = inttoptr i64 %v1574 to ptr
  store i32 1, ptr %p1575, align 4, !alias.scope !3, !noalias !4
  %v1576 = load i64, ptr %slot12, align 8
  %p1577 = inttoptr i64 %v1576 to ptr
  %ld1578 = load i32, ptr %p1577, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1578, ptr %slot285, align 8
  %v1579 = load i32, ptr %slot285, align 8
  %cv1580 = zext i32 %v1579 to i64
  %cond1581 = icmp ne i64 %cv1580, 0
  br i1 %cond1581, label %bb_rcslotdrop443, label %bb_rcslotdone443
bb_rcslotdrop443:
  %v1582 = load i64, ptr %slot12, align 8
  %p1583 = inttoptr i64 %v1582 to ptr
  store i32 0, ptr %p1583, align 4, !alias.scope !3, !noalias !4
  %v1584 = load i64, ptr %slot17, align 8
  store i64 %v1584, ptr %slot286, align 8
  %v1585 = load i64, ptr %slot13, align 8
  %p1586 = inttoptr i64 %v1585 to ptr
  %ld1587 = load i32, ptr %p1586, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1587, ptr %slot287, align 8
  %v1588 = load i32, ptr %slot287, align 8
  %op1589 = and i32 %v1588, 28
  store i32 %op1589, ptr %slot288, align 8
  %v1590 = load i32, ptr %slot288, align 8
  %cv1591 = zext i32 %v1590 to i64
  %cond1592 = icmp ne i64 %cv1591, 0
  br i1 %cond1592, label %bb_rcslotrole443, label %bb_rcslotowner443
bb_rcslotrole443:
  %v1593 = load i64, ptr %slot40, align 8
  store i64 %v1593, ptr %slot289, align 8
  %v1594 = load i64, ptr %slot289, align 8
  %v1595 = load i64, ptr %slot286, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1594, i64 %v1595) nomerge, !dbg !138
  br label %bb_rcslotdone443
bb_rcslotowner443:
  %v1596 = load i64, ptr %slot40, align 8
  store i64 %v1596, ptr %slot290, align 8
  %v1597 = load i64, ptr %slot290, align 8
  %v1598 = load i64, ptr %slot286, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1597, i64 %v1598) nomerge, !dbg !138
  br label %bb_rcslotdone443
bb_rcslotdone443:
  br label %bb_rcprepared417
bb_rcprepared417:
  %v1599 = load i64, ptr %slot18, align 8
  store i64 %v1599, ptr %slot291, align 8
  %v1600 = load i64, ptr %slot33, align 8
  store i64 %v1600, ptr %slot292, align 8
  %v1601 = load i64, ptr %slot291, align 8
  %v1602 = load i64, ptr %slot292, align 8
  %p1603 = inttoptr i64 %v1601 to ptr
  %p1604 = inttoptr i64 %v1602 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1604, ptr %p1603, i64 304, i1 false), !alias.scope !3, !noalias !4
  %v1605 = load i64, ptr %slot14, align 8
  %p1606 = inttoptr i64 %v1605 to ptr
  store i32 0, ptr %p1606, align 4, !alias.scope !3, !noalias !4
  %v1607 = load i64, ptr %slot16, align 8
  %p1608 = inttoptr i64 %v1607 to ptr
  store i32 1, ptr %p1608, align 4, !alias.scope !3, !noalias !4
  %v1609 = load i64, ptr %slot41, align 8
  store i64 %v1609, ptr %slot293, align 8
  %v1610 = load i64, ptr %slot28, align 8
  %p1611 = inttoptr i64 %v1610 to ptr
  %ld1612 = load i64, ptr %p1611, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1612, ptr %slot294, align 8
  %v1613 = load i64, ptr %slot292, align 8
  %p1615 = inttoptr i64 %v1613 to ptr
  %gep1616 = getelementptr i8, ptr %p1615, i64 288
  %op1614 = ptrtoint ptr %gep1616 to i64
  store i64 %op1614, ptr %slot295, align 8
  %v1617 = load i64, ptr %slot18, align 8
  store i64 %v1617, ptr %slot296, align 8
  %v1618 = load i64, ptr %slot294, align 8
  %v1619 = load i64, ptr %slot296, align 8
  %p1620 = inttoptr i64 %v1618 to ptr
  %p1621 = inttoptr i64 %v1619 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1621, ptr %p1620, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1622 = load i64, ptr %slot15, align 8
  %p1623 = inttoptr i64 %v1622 to ptr
  store i32 0, ptr %p1623, align 4, !alias.scope !3, !noalias !4
  %v1624 = load i64, ptr %slot14, align 8
  %p1625 = inttoptr i64 %v1624 to ptr
  store i32 1, ptr %p1625, align 4, !alias.scope !3, !noalias !4
  %v1626 = load i64, ptr %slot296, align 8
  %v1627 = load i64, ptr %slot295, align 8
  %p1628 = inttoptr i64 %v1626 to ptr
  %p1629 = inttoptr i64 %v1627 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1629, ptr %p1628, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v1630 = load i64, ptr %slot14, align 8
  %p1631 = inttoptr i64 %v1630 to ptr
  store i32 0, ptr %p1631, align 4, !alias.scope !3, !noalias !4
  %v1632 = load i64, ptr %slot292, align 8
  %v1633 = load i64, ptr %slot27, align 8
  %p1634 = inttoptr i64 %v1633 to ptr
  store i64 %v1632, ptr %p1634, align 8, !alias.scope !3, !noalias !4
  %v1635 = load i64, ptr %slot27, align 8
  %p1636 = inttoptr i64 %v1635 to ptr
  %ld1637 = load i64, ptr %p1636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1637, ptr %slot297, align 8
  %v1638 = load i64, ptr %slot18, align 8
  store i64 %v1638, ptr %slot298, align 8
  %v1639 = load i64, ptr %slot297, align 8
  %v1640 = load i64, ptr %slot298, align 8
  %p1641 = inttoptr i64 %v1639 to ptr
  %p1642 = inttoptr i64 %v1640 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1642, ptr %p1641, i64 304, i1 false), !alias.scope !3, !noalias !4
  %v1643 = load i64, ptr %slot15, align 8
  %p1644 = inttoptr i64 %v1643 to ptr
  store i32 2, ptr %p1644, align 4, !alias.scope !3, !noalias !4
  %v1645 = load i64, ptr %slot14, align 8
  %p1646 = inttoptr i64 %v1645 to ptr
  store i32 1, ptr %p1646, align 4, !alias.scope !3, !noalias !4
  %v1647 = load i64, ptr %slot12, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %ld1649 = load i32, ptr %p1648, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1649, ptr %slot299, align 8
  %v1650 = load i32, ptr %slot299, align 8
  %cv1651 = zext i32 %v1650 to i64
  %cond1652 = icmp ne i64 %cv1651, 0
  br i1 %cond1652, label %bb_rcslotdrop468, label %bb_rcslotdone468
bb_rcslotdrop468:
  %v1653 = load i64, ptr %slot12, align 8
  %p1654 = inttoptr i64 %v1653 to ptr
  store i32 0, ptr %p1654, align 4, !alias.scope !3, !noalias !4
  %v1655 = load i64, ptr %slot17, align 8
  store i64 %v1655, ptr %slot300, align 8
  %v1656 = load i64, ptr %slot13, align 8
  %p1657 = inttoptr i64 %v1656 to ptr
  %ld1658 = load i32, ptr %p1657, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1658, ptr %slot301, align 8
  %v1659 = load i32, ptr %slot301, align 8
  %op1660 = and i32 %v1659, 28
  store i32 %op1660, ptr %slot302, align 8
  %v1661 = load i32, ptr %slot302, align 8
  %cv1662 = zext i32 %v1661 to i64
  %cond1663 = icmp ne i64 %cv1662, 0
  br i1 %cond1663, label %bb_rcslotrole468, label %bb_rcslotowner468
bb_rcslotrole468:
  %v1664 = load i64, ptr %slot40, align 8
  store i64 %v1664, ptr %slot303, align 8
  %v1665 = load i64, ptr %slot303, align 8
  %v1666 = load i64, ptr %slot300, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1665, i64 %v1666) nomerge, !dbg !138
  br label %bb_rcslotdone468
bb_rcslotowner468:
  %v1667 = load i64, ptr %slot40, align 8
  store i64 %v1667, ptr %slot304, align 8
  %v1668 = load i64, ptr %slot304, align 8
  %v1669 = load i64, ptr %slot300, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1668, i64 %v1669) nomerge, !dbg !138
  br label %bb_rcslotdone468
bb_rcslotdone468:
  %v1670 = load i64, ptr %slot17, align 8
  store i64 %v1670, ptr %slot305, align 8
  %v1671 = load i64, ptr %slot18, align 8
  store i64 %v1671, ptr %slot306, align 8
  %v1672 = load i64, ptr %slot306, align 8
  %v1673 = load i64, ptr %slot305, align 8
  %p1674 = inttoptr i64 %v1672 to ptr
  %p1675 = inttoptr i64 %v1673 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1675, ptr %p1674, i64 304, i1 false), !alias.scope !3, !noalias !4
  %v1676 = load i64, ptr %slot13, align 8
  %p1677 = inttoptr i64 %v1676 to ptr
  store i32 2, ptr %p1677, align 4, !alias.scope !3, !noalias !4
  %v1678 = load i64, ptr %slot15, align 8
  %p1679 = inttoptr i64 %v1678 to ptr
  %ld1680 = load i32, ptr %p1679, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1680, ptr %slot307, align 8
  %v1681 = load i32, ptr %slot307, align 8
  %v1682 = load i64, ptr %slot13, align 8
  %p1683 = inttoptr i64 %v1682 to ptr
  store i32 %v1681, ptr %p1683, align 4, !alias.scope !3, !noalias !4
  %v1684 = load i64, ptr %slot14, align 8
  %p1685 = inttoptr i64 %v1684 to ptr
  store i32 0, ptr %p1685, align 4, !alias.scope !3, !noalias !4
  %v1686 = load i64, ptr %slot12, align 8
  %p1687 = inttoptr i64 %v1686 to ptr
  store i32 1, ptr %p1687, align 4, !alias.scope !3, !noalias !4
  %v1688 = load i64, ptr %slot305, align 8
  %v1689 = load i64, ptr %slot27, align 8
  %p1690 = inttoptr i64 %v1689 to ptr
  store i64 %v1688, ptr %p1690, align 8, !alias.scope !3, !noalias !4
  %v1691 = load i64, ptr %slot27, align 8
  %p1692 = inttoptr i64 %v1691 to ptr
  %ld1693 = load i64, ptr %p1692, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1693, ptr %slot308, align 8
  %v1694 = load i64, ptr %slot12, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  %ld1696 = load i32, ptr %p1695, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1696, ptr %slot309, align 8
  %v1697 = load i64, ptr %slot13, align 8
  %p1698 = inttoptr i64 %v1697 to ptr
  %ld1699 = load i32, ptr %p1698, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1699, ptr %slot310, align 8
  %v1700 = load i32, ptr %slot310, align 8
  %op1701 = and i32 %v1700, 24
  store i32 %op1701, ptr %slot310, align 8
  %v1702 = load i32, ptr %slot310, align 8
  %cmp1703 = icmp eq i32 %v1702, 0
  %cv1704 = zext i1 %cmp1703 to i32
  store i32 %cv1704, ptr %slot311, align 8
  %v1705 = load i32, ptr %slot309, align 8
  %v1706 = load i32, ptr %slot311, align 8
  %op1707 = and i32 %v1705, %v1706
  store i32 %op1707, ptr %slot312, align 8
  %v1708 = load i32, ptr %slot312, align 8
  %cv1709 = zext i32 %v1708 to i64
  %cond1710 = icmp ne i64 %cv1709, 0
  br i1 %cond1710, label %bb_rctake484, label %bb_rccopy484
bb_rctake484:
  %v1711 = load i64, ptr %slot18, align 8
  store i64 %v1711, ptr %slot313, align 8
  %v1712 = load i64, ptr %slot41, align 8
  store i64 %v1712, ptr %slot314, align 8
  %v1713 = load i64, ptr %slot40, align 8
  %v1714 = load i64, ptr %slot313, align 8
  %v1715 = load i64, ptr %slot308, align 8
  %v1716 = load i64, ptr %slot314, align 8
  %cv1717 = trunc i64 %v1716 to i32
  %call1718 = call i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_take(i64 %v1713, i64 %v1714, i64 %v1715, i32 %cv1717) nomerge, !dbg !140
  store i32 %call1718, ptr %slot315, align 8
  %v1719 = load i32, ptr %slot315, align 8
  %cv1720 = zext i32 %v1719 to i64
  %cond1721 = icmp ne i64 %cv1720, 0
  br i1 %cond1721, label %bb_rcsuccess494, label %bb_rcfailure494
bb_rcfailure494:
  %v1722 = load i64, ptr %slot40, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  %call1724 = call i32 @myl_rc_take_failure(ptr %p1723) nomerge, !dbg !140
  store i32 %call1724, ptr %slot316, align 8
  %v1725 = load i64, ptr %slot1, align 8
  %p1726 = inttoptr i64 %v1725 to ptr
  %v1727 = load i32, ptr %slot316, align 8
  %call1728 = call i32 @myl_qbe_rc_status(ptr %p1726, i32 %v1727) nomerge, !dbg !140
  store i32 %call1728, ptr %slot317, align 8
  br label %bb_failure
bb_rcsuccess494:
  %v1729 = load i64, ptr %slot12, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  store i32 0, ptr %p1730, align 4, !alias.scope !3, !noalias !4
  %v1731 = load i64, ptr %slot15, align 8
  %p1732 = inttoptr i64 %v1731 to ptr
  store i32 2, ptr %p1732, align 4, !alias.scope !3, !noalias !4
  %v1733 = load i64, ptr %slot14, align 8
  %p1734 = inttoptr i64 %v1733 to ptr
  store i32 1, ptr %p1734, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared484
bb_rccopy484:
  %v1735 = load i64, ptr %slot18, align 8
  store i64 %v1735, ptr %slot318, align 8
  %v1736 = load i64, ptr %slot41, align 8
  store i64 %v1736, ptr %slot319, align 8
  %v1737 = load i64, ptr %slot40, align 8
  %v1738 = load i64, ptr %slot318, align 8
  %v1739 = load i64, ptr %slot308, align 8
  %v1740 = load i64, ptr %slot319, align 8
  %cv1741 = trunc i64 %v1740 to i32
  %call1742 = call i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_retain(i64 %v1737, i64 %v1738, i64 %v1739, i32 %cv1741) nomerge, !dbg !140
  store i32 %call1742, ptr %slot320, align 8
  %v1743 = load i32, ptr %slot320, align 8
  %cv1744 = zext i32 %v1743 to i64
  %cond1745 = icmp ne i64 %cv1744, 0
  br i1 %cond1745, label %bb_rcsuccess503, label %bb_rcfailure503
bb_rcfailure503:
  %v1746 = load i64, ptr %slot40, align 8
  %p1747 = inttoptr i64 %v1746 to ptr
  %call1748 = call i32 @myl_rc_take_failure(ptr %p1747) nomerge, !dbg !140
  store i32 %call1748, ptr %slot321, align 8
  %v1749 = load i64, ptr %slot1, align 8
  %p1750 = inttoptr i64 %v1749 to ptr
  %v1751 = load i32, ptr %slot321, align 8
  %call1752 = call i32 @myl_qbe_rc_status(ptr %p1750, i32 %v1751) nomerge, !dbg !140
  store i32 %call1752, ptr %slot322, align 8
  br label %bb_failure
bb_rcsuccess503:
  %v1753 = load i64, ptr %slot15, align 8
  %p1754 = inttoptr i64 %v1753 to ptr
  store i32 2, ptr %p1754, align 4, !alias.scope !3, !noalias !4
  %v1755 = load i64, ptr %slot14, align 8
  %p1756 = inttoptr i64 %v1755 to ptr
  store i32 1, ptr %p1756, align 4, !alias.scope !3, !noalias !4
  %v1757 = load i64, ptr %slot12, align 8
  %p1758 = inttoptr i64 %v1757 to ptr
  %ld1759 = load i32, ptr %p1758, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1759, ptr %slot323, align 8
  %v1760 = load i32, ptr %slot323, align 8
  %cv1761 = zext i32 %v1760 to i64
  %cond1762 = icmp ne i64 %cv1761, 0
  br i1 %cond1762, label %bb_rcslotdrop510, label %bb_rcslotdone510
bb_rcslotdrop510:
  %v1763 = load i64, ptr %slot12, align 8
  %p1764 = inttoptr i64 %v1763 to ptr
  store i32 0, ptr %p1764, align 4, !alias.scope !3, !noalias !4
  %v1765 = load i64, ptr %slot17, align 8
  store i64 %v1765, ptr %slot324, align 8
  %v1766 = load i64, ptr %slot13, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  %ld1768 = load i32, ptr %p1767, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1768, ptr %slot325, align 8
  %v1769 = load i32, ptr %slot325, align 8
  %op1770 = and i32 %v1769, 28
  store i32 %op1770, ptr %slot326, align 8
  %v1771 = load i32, ptr %slot326, align 8
  %cv1772 = zext i32 %v1771 to i64
  %cond1773 = icmp ne i64 %cv1772, 0
  br i1 %cond1773, label %bb_rcslotrole510, label %bb_rcslotowner510
bb_rcslotrole510:
  %v1774 = load i64, ptr %slot40, align 8
  store i64 %v1774, ptr %slot327, align 8
  %v1775 = load i64, ptr %slot327, align 8
  %v1776 = load i64, ptr %slot324, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1775, i64 %v1776) nomerge, !dbg !140
  br label %bb_rcslotdone510
bb_rcslotowner510:
  %v1777 = load i64, ptr %slot40, align 8
  store i64 %v1777, ptr %slot328, align 8
  %v1778 = load i64, ptr %slot328, align 8
  %v1779 = load i64, ptr %slot324, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1778, i64 %v1779) nomerge, !dbg !140
  br label %bb_rcslotdone510
bb_rcslotdone510:
  br label %bb_rcprepared484
bb_rcprepared484:
  %v1780 = load i64, ptr %slot19, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  %ld1782 = load i64, ptr %p1781, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1782, ptr %slot329, align 8
  %v1783 = load i64, ptr %slot40, align 8
  store i64 %v1783, ptr %slot330, align 8
  %v1784 = load i64, ptr %slot330, align 8
  %v1785 = load i64, ptr %slot329, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1784, i64 %v1785) nomerge, !dbg !140
  %v1786 = load i64, ptr %slot18, align 8
  store i64 %v1786, ptr %slot331, align 8
  %v1787 = load i64, ptr %slot331, align 8
  %v1788 = load i64, ptr %slot329, align 8
  %p1789 = inttoptr i64 %v1787 to ptr
  %p1790 = inttoptr i64 %v1788 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1790, ptr %p1789, i64 304, i1 false), !alias.scope !10000000
  %v1791 = load i64, ptr %slot14, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  store i32 0, ptr %p1792, align 4, !alias.scope !3, !noalias !4
  %v1793 = load i64, ptr %slot27, align 8
  %p1794 = inttoptr i64 %v1793 to ptr
  store i64 0, ptr %p1794, align 8, !alias.scope !3, !noalias !4
  %v1795 = load i64, ptr %slot34, align 8
  store i64 %v1795, ptr %slot332, align 8
  %v1796 = load i64, ptr %slot332, align 8
  %p1797 = inttoptr i64 %v1796 to ptr
  store i32 0, ptr %p1797, align 4, !alias.scope !3, !noalias !4
  %v1798 = load i64, ptr %slot332, align 8
  %p1799 = inttoptr i64 %v1798 to ptr
  store i32 1, ptr %p1799, align 4, !alias.scope !3, !noalias !4
  %v1800 = load i64, ptr %slot332, align 8
  %v1801 = load i64, ptr %slot27, align 8
  %p1802 = inttoptr i64 %v1801 to ptr
  store i64 %v1800, ptr %p1802, align 8, !alias.scope !3, !noalias !4
  %v1803 = load i64, ptr %slot35, align 8
  store i64 %v1803, ptr %slot333, align 8
  %v1804 = load i64, ptr %slot333, align 8
  %p1805 = inttoptr i64 %v1804 to ptr
  store i64 0, ptr %p1805, align 8, !alias.scope !3, !noalias !4
  %v1806 = load i64, ptr %slot333, align 8
  %p1808 = inttoptr i64 %v1806 to ptr
  %gep1809 = getelementptr i8, ptr %p1808, i64 8
  %op1807 = ptrtoint ptr %gep1809 to i64
  store i64 %op1807, ptr %slot334, align 8
  %v1810 = load i64, ptr %slot334, align 8
  %p1811 = inttoptr i64 %v1810 to ptr
  store i64 0, ptr %p1811, align 8, !alias.scope !3, !noalias !4
  %v1812 = load i64, ptr %slot333, align 8
  %p1814 = inttoptr i64 %v1812 to ptr
  %gep1815 = getelementptr i8, ptr %p1814, i64 16
  %op1813 = ptrtoint ptr %gep1815 to i64
  store i64 %op1813, ptr %slot335, align 8
  %v1816 = load i64, ptr %slot335, align 8
  %p1817 = inttoptr i64 %v1816 to ptr
  store i64 0, ptr %p1817, align 8, !alias.scope !3, !noalias !4
  %v1818 = load i64, ptr %slot333, align 8
  %p1819 = inttoptr i64 %v1818 to ptr
  store i32 0, ptr %p1819, align 4, !alias.scope !3, !noalias !4
  %v1820 = load i64, ptr %slot16, align 8
  %p1821 = inttoptr i64 %v1820 to ptr
  store i32 1, ptr %p1821, align 4, !alias.scope !3, !noalias !4
  %v1822 = load i64, ptr %slot27, align 8
  %p1823 = inttoptr i64 %v1822 to ptr
  %ld1824 = load i64, ptr %p1823, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1824, ptr %slot336, align 8
  %v1825 = load i64, ptr %slot333, align 8
  %p1827 = inttoptr i64 %v1825 to ptr
  %gep1828 = getelementptr i8, ptr %p1827, i64 8
  %op1826 = ptrtoint ptr %gep1828 to i64
  store i64 %op1826, ptr %slot337, align 8
  %v1829 = load i64, ptr %slot41, align 8
  store i64 %v1829, ptr %slot338, align 8
  %v1830 = load i64, ptr %slot336, align 8
  %v1831 = load i64, ptr %slot337, align 8
  %p1832 = inttoptr i64 %v1830 to ptr
  %p1833 = inttoptr i64 %v1831 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1833, ptr %p1832, i64 4, i1 false), !alias.scope !3, !noalias !4
  %v1834 = load i64, ptr %slot333, align 8
  %v1835 = load i64, ptr %slot27, align 8
  %p1836 = inttoptr i64 %v1835 to ptr
  store i64 %v1834, ptr %p1836, align 8, !alias.scope !3, !noalias !4
  %v1837 = load i64, ptr %slot27, align 8
  %p1838 = inttoptr i64 %v1837 to ptr
  %ld1839 = load i64, ptr %p1838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1839, ptr %slot339, align 8
  %v1840 = load i64, ptr %slot17, align 8
  store i64 %v1840, ptr %slot340, align 8
  %v1841 = load i64, ptr %slot339, align 8
  %v1842 = load i64, ptr %slot340, align 8
  %p1843 = inttoptr i64 %v1841 to ptr
  %p1844 = inttoptr i64 %v1842 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1844, ptr %p1843, i64 24, i1 false), !alias.scope !3, !noalias !4
  %v1845 = load i64, ptr %slot13, align 8
  %p1846 = inttoptr i64 %v1845 to ptr
  store i32 2, ptr %p1846, align 4, !alias.scope !3, !noalias !4
  %v1847 = load i64, ptr %slot12, align 8
  %p1848 = inttoptr i64 %v1847 to ptr
  store i32 1, ptr %p1848, align 4, !alias.scope !3, !noalias !4
  %v1849 = load i64, ptr %slot340, align 8
  %v1850 = load i64, ptr %slot27, align 8
  %p1851 = inttoptr i64 %v1850 to ptr
  store i64 %v1849, ptr %p1851, align 8, !alias.scope !3, !noalias !4
  %v1852 = load i64, ptr %slot27, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  %ld1854 = load i64, ptr %p1853, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1854, ptr %slot341, align 8
  %v1855 = load i64, ptr %slot27, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  %ld1857 = load i64, ptr %p1856, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1857, ptr %slot342, align 8
  %v1858 = load i64, ptr %slot18, align 8
  store i64 %v1858, ptr %slot343, align 8
  %v1859 = load i64, ptr %slot41, align 8
  store i64 %v1859, ptr %slot344, align 8
  %v1860 = load i64, ptr %slot40, align 8
  %v1861 = load i64, ptr %slot343, align 8
  %v1862 = load i64, ptr %slot342, align 8
  %v1863 = load i64, ptr %slot344, align 8
  %cv1864 = trunc i64 %v1863 to i32
  %call1865 = call i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64 %v1860, i64 %v1861, i64 %v1862, i32 %cv1864) nomerge, !dbg !142
  store i32 %call1865, ptr %slot345, align 8
  %v1866 = load i32, ptr %slot345, align 8
  %cv1867 = zext i32 %v1866 to i64
  %cond1868 = icmp ne i64 %cv1867, 0
  br i1 %cond1868, label %bb_rcsuccess539, label %bb_rcfailure539
bb_rcfailure539:
  %v1869 = load i64, ptr %slot40, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  %call1871 = call i32 @myl_rc_take_failure(ptr %p1870) nomerge, !dbg !142
  store i32 %call1871, ptr %slot346, align 8
  %v1872 = load i64, ptr %slot1, align 8
  %p1873 = inttoptr i64 %v1872 to ptr
  %v1874 = load i32, ptr %slot346, align 8
  %call1875 = call i32 @myl_qbe_rc_status(ptr %p1873, i32 %v1874) nomerge, !dbg !142
  store i32 %call1875, ptr %slot347, align 8
  br label %bb_failure
bb_rcsuccess539:
  %v1876 = load i64, ptr %slot12, align 8
  %p1877 = inttoptr i64 %v1876 to ptr
  store i32 0, ptr %p1877, align 4, !alias.scope !3, !noalias !4
  %v1878 = load i64, ptr %slot15, align 8
  %p1879 = inttoptr i64 %v1878 to ptr
  store i32 2, ptr %p1879, align 4, !alias.scope !3, !noalias !4
  %v1880 = load i64, ptr %slot14, align 8
  %p1881 = inttoptr i64 %v1880 to ptr
  store i32 1, ptr %p1881, align 4, !alias.scope !3, !noalias !4
  %v1882 = load i64, ptr %slot18, align 8
  store i64 %v1882, ptr %slot348, align 8
  %v1883 = load i64, ptr %slot14, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  store i32 0, ptr %p1884, align 4, !alias.scope !3, !noalias !4
  %v1885 = load i64, ptr %slot12, align 8
  %p1886 = inttoptr i64 %v1885 to ptr
  %ld1887 = load i32, ptr %p1886, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1887, ptr %slot349, align 8
  %v1888 = load i32, ptr %slot349, align 8
  %cv1889 = zext i32 %v1888 to i64
  %cond1890 = icmp ne i64 %cv1889, 0
  br i1 %cond1890, label %bb_rcslotdrop549, label %bb_rcslotdone549
bb_rcslotdrop549:
  %v1891 = load i64, ptr %slot12, align 8
  %p1892 = inttoptr i64 %v1891 to ptr
  store i32 0, ptr %p1892, align 4, !alias.scope !3, !noalias !4
  %v1893 = load i64, ptr %slot17, align 8
  store i64 %v1893, ptr %slot350, align 8
  %v1894 = load i64, ptr %slot13, align 8
  %p1895 = inttoptr i64 %v1894 to ptr
  %ld1896 = load i32, ptr %p1895, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1896, ptr %slot351, align 8
  %v1897 = load i32, ptr %slot351, align 8
  %op1898 = and i32 %v1897, 28
  store i32 %op1898, ptr %slot352, align 8
  %v1899 = load i32, ptr %slot352, align 8
  %cv1900 = zext i32 %v1899 to i64
  %cond1901 = icmp ne i64 %cv1900, 0
  br i1 %cond1901, label %bb_rcslotrole549, label %bb_rcslotowner549
bb_rcslotrole549:
  %v1902 = load i64, ptr %slot40, align 8
  store i64 %v1902, ptr %slot353, align 8
  %v1903 = load i64, ptr %slot353, align 8
  %v1904 = load i64, ptr %slot350, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64 %v1903, i64 %v1904) nomerge, !dbg !142
  br label %bb_rcslotdone549
bb_rcslotowner549:
  %v1905 = load i64, ptr %slot40, align 8
  store i64 %v1905, ptr %slot354, align 8
  %v1906 = load i64, ptr %slot354, align 8
  %v1907 = load i64, ptr %slot350, align 8
  call void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64 %v1906, i64 %v1907) nomerge, !dbg !142
  br label %bb_rcslotdone549
bb_rcslotdone549:
  %v1908 = load i64, ptr %slot10, align 8
  %p1909 = inttoptr i64 %v1908 to ptr
  %ld1910 = load i32, ptr %p1909, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1910, ptr %slot355, align 8
  %v1911 = load i32, ptr %slot355, align 8
  %cv1912 = zext i32 %v1911 to i64
  %cond1913 = icmp ne i64 %cv1912, 0
  br i1 %cond1913, label %bb_rcslotdrop558, label %bb_rcslotdone558
bb_rcslotdrop558:
  %v1914 = load i64, ptr %slot10, align 8
  %p1915 = inttoptr i64 %v1914 to ptr
  store i32 0, ptr %p1915, align 4, !alias.scope !3, !noalias !4
  %v1916 = load i64, ptr %slot25, align 8
  store i64 %v1916, ptr %slot356, align 8
  %v1917 = load i64, ptr %slot11, align 8
  %p1918 = inttoptr i64 %v1917 to ptr
  %ld1919 = load i32, ptr %p1918, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1919, ptr %slot357, align 8
  %v1920 = load i32, ptr %slot357, align 8
  %op1921 = and i32 %v1920, 28
  store i32 %op1921, ptr %slot358, align 8
  %v1922 = load i32, ptr %slot358, align 8
  %cv1923 = zext i32 %v1922 to i64
  %cond1924 = icmp ne i64 %cv1923, 0
  br i1 %cond1924, label %bb_rcslotrole558, label %bb_rcslotowner558
bb_rcslotrole558:
  %v1925 = load i64, ptr %slot40, align 8
  store i64 %v1925, ptr %slot359, align 8
  %v1926 = load i64, ptr %slot359, align 8
  %v1927 = load i64, ptr %slot356, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64 %v1926, i64 %v1927) nomerge, !dbg !142
  br label %bb_rcslotdone558
bb_rcslotowner558:
  %v1928 = load i64, ptr %slot40, align 8
  store i64 %v1928, ptr %slot360, align 8
  %v1929 = load i64, ptr %slot360, align 8
  %v1930 = load i64, ptr %slot356, align 8
  call void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64 %v1929, i64 %v1930) nomerge, !dbg !142
  br label %bb_rcslotdone558
bb_rcslotdone558:
  %v1931 = load i64, ptr %slot8, align 8
  %p1932 = inttoptr i64 %v1931 to ptr
  %ld1933 = load i32, ptr %p1932, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1933, ptr %slot361, align 8
  %v1934 = load i32, ptr %slot361, align 8
  %cv1935 = zext i32 %v1934 to i64
  %cond1936 = icmp ne i64 %cv1935, 0
  br i1 %cond1936, label %bb_rcslotdrop585, label %bb_rcslotdone585
bb_rcslotdrop585:
  %v1937 = load i64, ptr %slot8, align 8
  %p1938 = inttoptr i64 %v1937 to ptr
  store i32 0, ptr %p1938, align 4, !alias.scope !3, !noalias !4
  %v1939 = load i64, ptr %slot23, align 8
  store i64 %v1939, ptr %slot362, align 8
  %v1940 = load i64, ptr %slot9, align 8
  %p1941 = inttoptr i64 %v1940 to ptr
  %ld1942 = load i32, ptr %p1941, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1942, ptr %slot363, align 8
  %v1943 = load i32, ptr %slot363, align 8
  %op1944 = and i32 %v1943, 28
  store i32 %op1944, ptr %slot364, align 8
  %v1945 = load i32, ptr %slot364, align 8
  %cv1946 = zext i32 %v1945 to i64
  %cond1947 = icmp ne i64 %cv1946, 0
  br i1 %cond1947, label %bb_rcslotrole585, label %bb_rcslotowner585
bb_rcslotrole585:
  %v1948 = load i64, ptr %slot40, align 8
  store i64 %v1948, ptr %slot365, align 8
  %v1949 = load i64, ptr %slot365, align 8
  %v1950 = load i64, ptr %slot362, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1949, i64 %v1950) nomerge, !dbg !142
  br label %bb_rcslotdone585
bb_rcslotowner585:
  %v1951 = load i64, ptr %slot40, align 8
  store i64 %v1951, ptr %slot366, align 8
  %v1952 = load i64, ptr %slot366, align 8
  %v1953 = load i64, ptr %slot362, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1952, i64 %v1953) nomerge, !dbg !142
  br label %bb_rcslotdone585
bb_rcslotdone585:
  %v1954 = load i64, ptr %slot6, align 8
  %p1955 = inttoptr i64 %v1954 to ptr
  %ld1956 = load i32, ptr %p1955, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1956, ptr %slot367, align 8
  %v1957 = load i32, ptr %slot367, align 8
  %cv1958 = zext i32 %v1957 to i64
  %cond1959 = icmp ne i64 %cv1958, 0
  br i1 %cond1959, label %bb_rcslotdrop612, label %bb_rcslotdone612
bb_rcslotdrop612:
  %v1960 = load i64, ptr %slot6, align 8
  %p1961 = inttoptr i64 %v1960 to ptr
  store i32 0, ptr %p1961, align 4, !alias.scope !3, !noalias !4
  %v1962 = load i64, ptr %slot22, align 8
  store i64 %v1962, ptr %slot368, align 8
  %v1963 = load i64, ptr %slot7, align 8
  %p1964 = inttoptr i64 %v1963 to ptr
  %ld1965 = load i32, ptr %p1964, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1965, ptr %slot369, align 8
  %v1966 = load i32, ptr %slot369, align 8
  %op1967 = and i32 %v1966, 28
  store i32 %op1967, ptr %slot370, align 8
  %v1968 = load i32, ptr %slot370, align 8
  %cv1969 = zext i32 %v1968 to i64
  %cond1970 = icmp ne i64 %cv1969, 0
  br i1 %cond1970, label %bb_rcslotrole612, label %bb_rcslotowner612
bb_rcslotrole612:
  %v1971 = load i64, ptr %slot40, align 8
  store i64 %v1971, ptr %slot371, align 8
  %v1972 = load i64, ptr %slot371, align 8
  %v1973 = load i64, ptr %slot368, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1972, i64 %v1973) nomerge, !dbg !142
  br label %bb_rcslotdone612
bb_rcslotowner612:
  %v1974 = load i64, ptr %slot40, align 8
  store i64 %v1974, ptr %slot372, align 8
  %v1975 = load i64, ptr %slot372, align 8
  %v1976 = load i64, ptr %slot368, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1975, i64 %v1976) nomerge, !dbg !142
  br label %bb_rcslotdone612
bb_rcslotdone612:
  %v1977 = load i64, ptr %slot348, align 8
  %p1978 = inttoptr i64 %v1977 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1978, i64 24, i1 false)
  ret void
bb_failure:
  %v1979 = load i64, ptr %slot5, align 8
  %p1980 = inttoptr i64 %v1979 to ptr
  call void @llvm.memset.p0.i64(ptr %p1980, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !142
  %v1981 = load i64, ptr %slot5, align 8
  %p1982 = inttoptr i64 %v1981 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1982, i64 24, i1 false)
  ret void
bb_entry_failure:
  %v1983 = load i64, ptr %slot5, align 8
  %p1984 = inttoptr i64 %v1983 to ptr
  call void @llvm.memset.p0.i64(ptr %p1984, i8 0, i64 24, i1 false), !alias.scope !3, !noalias !4, !dbg !142
  %v1985 = load i64, ptr %slot5, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p1986, i64 24, i1 false)
  ret void
}

@myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01_meta = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_339494ddd89a48d13094d9f5c6b4b55320c4f6128bc80d7aba97a84a17838cc1(i64, i64)
declare i64 @myl_f_9cfccc291a0516b23c50da008b59b8f2c8a2e23f61575966d1d2f1cfb2a4be4b(i64, i64, i64)
declare void @myl_f_d32d9d609bd2d498a6b2d4f34d6d36851c296533eaafa0e3b7c4c9b1eec65fca(ptr sret([24 x i8]) align 8, i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_drop(i64, i64)
declare i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_loan(i64, i64, i64)
declare i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1be100d7881e89c44e7871be90e57da7661dd229d7964a7441d6254ea7441c2b_rcg_unloan(i64, i64)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_drop(i64, i64)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_take(i64, i64, i64, i32)
declare void @myl_t_1da8f946ba246f799cfc56f183bef69d4262f662fcee79b8b62bd1d3f8d7855b_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_drop(i64, i64)
declare void @myl_t_785498c443d0a980df3d0827c91989bab92d5672b68aaea1281c9af29aa300f6_rcg_unloan(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_retain(i64, i64, i64, i32)
declare void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_drop(i64, i64)
declare void @myl_t_e660b2f5a6ded889a54cd61dbc6d031c9c843eea1e157b307c86ce01ebd3067b_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01", linkageName: "myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15638223224553495732, i64 0, !"myl_f_2d562dc4c016cbd8cb476a4b8378eb1edcfd162441edb240b836cfd50e70ba01"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!116 = !DILocation(line: 6, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646607)
!120 = !DILocation(line: 9, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!124 = !DILocation(line: 18, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646775)
!126 = !DILocation(line: 30, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646815)
!128 = !DILocation(line: 35, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!130 = !DILocation(line: 39, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646943)
!132 = !DILocation(line: 51, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646991)
!134 = !DILocation(line: 57, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647007)
!136 = !DILocation(line: 59, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647031)
!138 = !DILocation(line: 62, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647039)
!140 = !DILocation(line: 63, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186647079)
!142 = !DILocation(line: 68, column: 0, scope: !143)
