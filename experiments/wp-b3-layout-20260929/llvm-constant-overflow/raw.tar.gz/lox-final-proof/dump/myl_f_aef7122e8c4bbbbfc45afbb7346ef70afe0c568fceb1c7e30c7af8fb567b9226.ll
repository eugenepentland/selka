target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_aef7122e8c4bbbbfc45afbb7346ef70afe0c568fceb1c7e30c7af8fb567b9226(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i32, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i64, align 8
  %slot63 = alloca i64, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i64, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i64, align 8
  %slot69 = alloca i64, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i64, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i32, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i64, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %callresult111 = alloca [16 x i8], align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i64, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i32, align 8
  %slot128 = alloca i64, align 8
  %slot129 = alloca i32, align 8
  %slot130 = alloca i32, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v133 = load i64, ptr %slot1, align 8
  %op134 = add i64 %v133, 32
  store i64 %op134, ptr %slot4, align 8
  %mem135 = alloca i8, i64 16, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot5, align 8
  %mem137 = alloca i8, i64 8, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot6, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot7, align 8
  %mem141 = alloca i8, i64 8, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot8, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot9, align 8
  %mem145 = alloca i8, i64 8, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot10, align 8
  %mem147 = alloca i8, i64 16, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot11, align 8
  %mem149 = alloca i8, i64 8, align 8
  %ptr150 = ptrtoint ptr %mem149 to i64
  store i64 %ptr150, ptr %slot12, align 8
  %mem151 = alloca i8, i64 16, align 8
  %ptr152 = ptrtoint ptr %mem151 to i64
  store i64 %ptr152, ptr %slot13, align 8
  %mem153 = alloca i8, i64 8, align 8
  %ptr154 = ptrtoint ptr %mem153 to i64
  store i64 %ptr154, ptr %slot14, align 8
  %mem155 = alloca i8, i64 8, align 8
  %ptr156 = ptrtoint ptr %mem155 to i64
  store i64 %ptr156, ptr %slot15, align 8
  %mem157 = alloca i8, i64 8, align 8
  %ptr158 = ptrtoint ptr %mem157 to i64
  store i64 %ptr158, ptr %slot16, align 8
  %mem159 = alloca i8, i64 8, align 8
  %ptr160 = ptrtoint ptr %mem159 to i64
  store i64 %ptr160, ptr %slot17, align 8
  %mem161 = alloca i8, i64 8, align 8
  %ptr162 = ptrtoint ptr %mem161 to i64
  store i64 %ptr162, ptr %slot18, align 8
  %mem163 = alloca i8, i64 16, align 8
  %ptr164 = ptrtoint ptr %mem163 to i64
  store i64 %ptr164, ptr %slot19, align 8
  %mem165 = alloca i8, i64 8, align 8
  %ptr166 = ptrtoint ptr %mem165 to i64
  store i64 %ptr166, ptr %slot20, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem167 = alloca i8, i64 8, align 8
  %ptr168 = ptrtoint ptr %mem167 to i64
  store i64 %ptr168, ptr %slot21, align 8
  %v169 = load i64, ptr %slot1, align 8
  %op170 = add i64 %v169, 64
  store i64 %op170, ptr %slot22, align 8
  %v171 = load i64, ptr %slot22, align 8
  %p172 = inttoptr i64 %v171 to ptr
  %ld173 = load i64, ptr %p172, align 8, !alias.scope !4, !noalias !3
  store i64 %ld173, ptr %slot23, align 8
  %stack174 = call ptr @llvm.stacksave()
  %stackaddr175 = ptrtoint ptr %stack174 to i64
  %v176 = load i64, ptr %slot23, align 8
  %cmp177 = icmp ult i64 %stackaddr175, %v176
  %cv178 = zext i1 %cmp177 to i64
  store i64 %cv178, ptr %slot24, align 8
  %v179 = load i64, ptr %slot24, align 8
  %cond180 = icmp ne i64 %v179, 0
  br i1 %cond180, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v181 = load i64, ptr %slot1, align 8
  %p182 = inttoptr i64 %v181 to ptr
  call void @myl_qbe_fail_frame(ptr %p182) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v183 = load i64, ptr %slot2, align 8
  %v184 = load i64, ptr %slot14, align 8
  %p185 = inttoptr i64 %v184 to ptr
  store i64 %v183, ptr %p185, align 8, !alias.scope !3, !noalias !4
  %v186 = load i64, ptr %slot3, align 8
  %v187 = load i64, ptr %slot15, align 8
  %p188 = inttoptr i64 %v187 to ptr
  store i64 %v186, ptr %p188, align 8, !alias.scope !3, !noalias !4
  %v189 = load i64, ptr %slot1, align 8
  %p190 = inttoptr i64 %v189 to ptr
  %call191 = call ptr @myl_qbe_heap(ptr %p190) nomerge, !dbg !112
  %calladdr192 = ptrtoint ptr %call191 to i64
  store i64 %calladdr192, ptr %slot25, align 8
  %v193 = load i64, ptr %slot1, align 8
  %p194 = inttoptr i64 %v193 to ptr
  %call195 = call i64 @myl_qbe_region_mark(ptr %p194) nomerge, !dbg !112
  store i64 %call195, ptr %slot26, align 8
  %v196 = load i64, ptr %slot6, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i32 0, ptr %p197, align 4, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot7, align 8
  %p199 = inttoptr i64 %v198 to ptr
  store i32 0, ptr %p199, align 4, !alias.scope !3, !noalias !4
  %v200 = load i64, ptr %slot8, align 8
  %p201 = inttoptr i64 %v200 to ptr
  store i32 0, ptr %p201, align 4, !alias.scope !3, !noalias !4
  %v202 = load i64, ptr %slot9, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i32 0, ptr %p203, align 4, !alias.scope !3, !noalias !4
  %v204 = load i64, ptr %slot10, align 8
  %p205 = inttoptr i64 %v204 to ptr
  store i32 0, ptr %p205, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v206 = load i64, ptr %slot15, align 8
  %p207 = inttoptr i64 %v206 to ptr
  %ld208 = load i64, ptr %p207, align 8, !alias.scope !3, !noalias !4
  store i64 %ld208, ptr %slot27, align 8
  %v209 = load i64, ptr %slot27, align 8
  %v210 = load i64, ptr %slot16, align 8
  %p211 = inttoptr i64 %v210 to ptr
  store i64 %v209, ptr %p211, align 8, !alias.scope !3, !noalias !4
  %v212 = load i64, ptr %slot16, align 8
  %p213 = inttoptr i64 %v212 to ptr
  %ld214 = load i64, ptr %p213, align 8, !alias.scope !3, !noalias !4
  store i64 %ld214, ptr %slot28, align 8
  %v215 = load i64, ptr %slot28, align 8
  %op216 = add i64 %v215, 0
  store i64 %op216, ptr %slot29, align 8
  %v217 = load i64, ptr %slot29, align 8
  %p218 = inttoptr i64 %v217 to ptr
  %ld219 = load i64, ptr %p218, align 8, !alias.scope !4, !noalias !3
  store i64 %ld219, ptr %slot30, align 8
  %v220 = load i64, ptr %slot30, align 8
  %v221 = load i64, ptr %slot16, align 8
  %p222 = inttoptr i64 %v221 to ptr
  store i64 %v220, ptr %p222, align 8, !alias.scope !3, !noalias !4
  %v223 = load i64, ptr %slot17, align 8
  %p224 = inttoptr i64 %v223 to ptr
  store i64 0, ptr %p224, align 8, !alias.scope !3, !noalias !4
  %v225 = load i64, ptr %slot18, align 8
  %p226 = inttoptr i64 %v225 to ptr
  store i64 9223372036854775807, ptr %p226, align 8, !alias.scope !3, !noalias !4
  br label %bb_i5
bb_i5:
  %v227 = load i64, ptr %slot18, align 8
  %p228 = inttoptr i64 %v227 to ptr
  %ld229 = load i64, ptr %p228, align 8, !alias.scope !3, !noalias !4
  store i64 %ld229, ptr %slot31, align 8
  %v230 = load i64, ptr %slot17, align 8
  %p231 = inttoptr i64 %v230 to ptr
  %ld232 = load i64, ptr %p231, align 8, !alias.scope !3, !noalias !4
  store i64 %ld232, ptr %slot32, align 8
  %v233 = load i64, ptr %slot32, align 8
  %v234 = load i64, ptr %slot31, align 8
  %ovpair236 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v233, i64 %v234)
  %op235 = extractvalue { i64, i1 } %ovpair236, 0
  %ov237 = extractvalue { i64, i1 } %ovpair236, 1
  store i64 %op235, ptr %slot33, align 8
  %v238 = load i64, ptr %slot32, align 8
  %v239 = load i64, ptr %slot31, align 8
  %op240 = xor i64 %v238, %v239
  store i64 %op240, ptr %slot34, align 8
  %v241 = load i64, ptr %slot32, align 8
  %v242 = load i64, ptr %slot33, align 8
  %op243 = xor i64 %v241, %v242
  store i64 %op243, ptr %slot35, align 8
  %v244 = load i64, ptr %slot34, align 8
  %v245 = load i64, ptr %slot35, align 8
  %op246 = and i64 %v244, %v245
  store i64 %op246, ptr %slot36, align 8
  %cv247 = zext i1 %ov237 to i64
  store i64 %cv247, ptr %slot37, align 8
  %v248 = load i64, ptr %slot37, align 8
  %cond249 = icmp ne i64 %v248, 0
  br i1 %cond249, label %bb_overflow13, label %bb_checked13
bb_overflow13:
  %v250 = load i64, ptr %slot1, align 8
  %p251 = inttoptr i64 %v250 to ptr
  %v252 = load i64, ptr %slot32, align 8
  %v253 = load i64, ptr %slot31, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p251, i64 1, i64 %v252, i64 %v253, i64 64) nomerge, !dbg !114
  unreachable
bb_checked13:
  %v254 = load i64, ptr %slot33, align 8
  %v255 = load i64, ptr %slot17, align 8
  %p256 = inttoptr i64 %v255 to ptr
  store i64 %v254, ptr %p256, align 8, !alias.scope !3, !noalias !4
  %v257 = load i64, ptr %slot18, align 8
  %p258 = inttoptr i64 %v257 to ptr
  store i64 1, ptr %p258, align 8, !alias.scope !3, !noalias !4
  %v259 = load i64, ptr %slot18, align 8
  %p260 = inttoptr i64 %v259 to ptr
  %ld261 = load i64, ptr %p260, align 8, !alias.scope !3, !noalias !4
  store i64 %ld261, ptr %slot38, align 8
  %v262 = load i64, ptr %slot17, align 8
  %p263 = inttoptr i64 %v262 to ptr
  %ld264 = load i64, ptr %p263, align 8, !alias.scope !3, !noalias !4
  store i64 %ld264, ptr %slot39, align 8
  %v265 = load i64, ptr %slot39, align 8
  %v266 = load i64, ptr %slot38, align 8
  %ovpair268 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v265, i64 %v266)
  %op267 = extractvalue { i64, i1 } %ovpair268, 0
  %ov269 = extractvalue { i64, i1 } %ovpair268, 1
  store i64 %op267, ptr %slot40, align 8
  %cv270 = zext i1 %ov269 to i64
  store i64 %cv270, ptr %slot41, align 8
  %v271 = load i64, ptr %slot41, align 8
  %cond272 = icmp ne i64 %v271, 0
  br i1 %cond272, label %bb_overflow20, label %bb_checked20
bb_overflow20:
  %v273 = load i64, ptr %slot1, align 8
  %p274 = inttoptr i64 %v273 to ptr
  %v275 = load i64, ptr %slot39, align 8
  %v276 = load i64, ptr %slot38, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p274, i64 1, i64 %v275, i64 %v276, i64 64) nomerge, !dbg !116
  unreachable
bb_checked20:
  %v277 = load i64, ptr %slot40, align 8
  %v278 = load i64, ptr %slot17, align 8
  %p279 = inttoptr i64 %v278 to ptr
  store i64 %v277, ptr %p279, align 8, !alias.scope !3, !noalias !4
  %v280 = load i64, ptr %slot17, align 8
  %p281 = inttoptr i64 %v280 to ptr
  %ld282 = load i64, ptr %p281, align 8, !alias.scope !3, !noalias !4
  store i64 %ld282, ptr %slot42, align 8
  %v283 = load i64, ptr %slot16, align 8
  %p284 = inttoptr i64 %v283 to ptr
  %ld285 = load i64, ptr %p284, align 8, !alias.scope !3, !noalias !4
  store i64 %ld285, ptr %slot43, align 8
  %v286 = load i64, ptr %slot43, align 8
  %v287 = load i64, ptr %slot42, align 8
  %cmp288 = icmp eq i64 %v286, %v287
  %cv289 = zext i1 %cmp288 to i64
  store i64 %cv289, ptr %slot44, align 8
  %v290 = load i64, ptr %slot44, align 8
  %v291 = load i64, ptr %slot16, align 8
  %p292 = inttoptr i64 %v291 to ptr
  store i64 %v290, ptr %p292, align 8, !alias.scope !3, !noalias !4
  %v293 = load i64, ptr %slot16, align 8
  %p294 = inttoptr i64 %v293 to ptr
  %ld295 = load i64, ptr %p294, align 8, !alias.scope !3, !noalias !4
  store i64 %ld295, ptr %slot45, align 8
  %v296 = load i64, ptr %slot45, align 8
  %cond297 = icmp ne i64 %v296, 0
  br i1 %cond297, label %bb_next26, label %bb_i13
bb_next26:
  %p298 = inttoptr i64 ptrtoint (ptr @myl_lit_1e9db636fa001c2114200dbe3ddea0b143255a95e35f6ece8abdde9e9aeb457c to i64) to ptr
  %ld299 = load i64, ptr %p298, align 8, !alias.scope !4, !noalias !3
  store i64 %ld299, ptr %slot46, align 8
  %v300 = load i64, ptr %slot46, align 8
  %v301 = load i64, ptr %slot16, align 8
  %p302 = inttoptr i64 %v301 to ptr
  store i64 %v300, ptr %p302, align 8, !alias.scope !3, !noalias !4
  %v303 = load i64, ptr %slot16, align 8
  %p304 = inttoptr i64 %v303 to ptr
  %ld305 = load i64, ptr %p304, align 8, !alias.scope !3, !noalias !4
  store i64 %ld305, ptr %slot47, align 8
  %v306 = load i64, ptr %slot47, align 8
  %v307 = load i64, ptr %slot12, align 8
  %p308 = inttoptr i64 %v307 to ptr
  store i64 %v306, ptr %p308, align 8, !alias.scope !3, !noalias !4
  %v309 = load i64, ptr %slot12, align 8
  store i64 %v309, ptr %slot48, align 8
  %v310 = load i64, ptr %slot13, align 8
  store i64 %v310, ptr %slot49, align 8
  %v311 = load i64, ptr %slot48, align 8
  %v312 = load i64, ptr %slot49, align 8
  %p313 = inttoptr i64 %v311 to ptr
  %p314 = inttoptr i64 %v312 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p314, ptr %p313, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v315 = load i64, ptr %slot9, align 8
  %p316 = inttoptr i64 %v315 to ptr
  store i32 2, ptr %p316, align 4, !alias.scope !3, !noalias !4
  %v317 = load i64, ptr %slot8, align 8
  %p318 = inttoptr i64 %v317 to ptr
  store i32 1, ptr %p318, align 4, !alias.scope !3, !noalias !4
  %v319 = load i64, ptr %slot11, align 8
  store i64 %v319, ptr %slot50, align 8
  %v320 = load i64, ptr %slot13, align 8
  store i64 %v320, ptr %slot51, align 8
  %v321 = load i64, ptr %slot51, align 8
  %v322 = load i64, ptr %slot50, align 8
  %p323 = inttoptr i64 %v321 to ptr
  %p324 = inttoptr i64 %v322 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p324, ptr %p323, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v325 = load i64, ptr %slot7, align 8
  %p326 = inttoptr i64 %v325 to ptr
  store i32 2, ptr %p326, align 4, !alias.scope !3, !noalias !4
  %v327 = load i64, ptr %slot9, align 8
  %p328 = inttoptr i64 %v327 to ptr
  %ld329 = load i32, ptr %p328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld329, ptr %slot52, align 8
  %v330 = load i32, ptr %slot52, align 8
  %v331 = load i64, ptr %slot7, align 8
  %p332 = inttoptr i64 %v331 to ptr
  store i32 %v330, ptr %p332, align 4, !alias.scope !3, !noalias !4
  %v333 = load i64, ptr %slot8, align 8
  %p334 = inttoptr i64 %v333 to ptr
  store i32 0, ptr %p334, align 4, !alias.scope !3, !noalias !4
  %v335 = load i64, ptr %slot6, align 8
  %p336 = inttoptr i64 %v335 to ptr
  store i32 1, ptr %p336, align 4, !alias.scope !3, !noalias !4
  %v337 = load i64, ptr %slot50, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %ld339 = load i64, ptr %p338, align 8, !alias.scope !3, !noalias !4
  store i64 %ld339, ptr %slot53, align 8
  %v340 = load i64, ptr %slot53, align 8
  %v341 = load i64, ptr %slot16, align 8
  %p342 = inttoptr i64 %v341 to ptr
  store i64 %v340, ptr %p342, align 8, !alias.scope !3, !noalias !4
  %v343 = load i64, ptr %slot19, align 8
  store i64 %v343, ptr %slot54, align 8
  %v344 = load i64, ptr %slot54, align 8
  %p345 = inttoptr i64 %v344 to ptr
  store i64 0, ptr %p345, align 8, !alias.scope !3, !noalias !4
  %v346 = load i64, ptr %slot54, align 8
  %p348 = inttoptr i64 %v346 to ptr
  %gep349 = getelementptr i8, ptr %p348, i64 8
  %op347 = ptrtoint ptr %gep349 to i64
  store i64 %op347, ptr %slot55, align 8
  %v350 = load i64, ptr %slot55, align 8
  %p351 = inttoptr i64 %v350 to ptr
  store i64 0, ptr %p351, align 8, !alias.scope !3, !noalias !4
  %v352 = load i64, ptr %slot54, align 8
  %p353 = inttoptr i64 %v352 to ptr
  store i32 1, ptr %p353, align 4, !alias.scope !3, !noalias !4
  %v354 = load i64, ptr %slot10, align 8
  %p355 = inttoptr i64 %v354 to ptr
  store i32 1, ptr %p355, align 4, !alias.scope !3, !noalias !4
  %v356 = load i64, ptr %slot16, align 8
  %p357 = inttoptr i64 %v356 to ptr
  %ld358 = load i64, ptr %p357, align 8, !alias.scope !3, !noalias !4
  store i64 %ld358, ptr %slot56, align 8
  %v359 = load i64, ptr %slot56, align 8
  %v360 = load i64, ptr %slot12, align 8
  %p361 = inttoptr i64 %v360 to ptr
  store i64 %v359, ptr %p361, align 8, !alias.scope !3, !noalias !4
  %v362 = load i64, ptr %slot12, align 8
  store i64 %v362, ptr %slot57, align 8
  %v363 = load i64, ptr %slot54, align 8
  %p365 = inttoptr i64 %v363 to ptr
  %gep366 = getelementptr i8, ptr %p365, i64 8
  %op364 = ptrtoint ptr %gep366 to i64
  store i64 %op364, ptr %slot58, align 8
  %v367 = load i64, ptr %slot26, align 8
  store i64 %v367, ptr %slot59, align 8
  %v368 = load i64, ptr %slot16, align 8
  %p369 = inttoptr i64 %v368 to ptr
  %ld370 = load i64, ptr %p369, align 8, !alias.scope !3, !noalias !4
  store i64 %ld370, ptr %slot60, align 8
  %v371 = load i64, ptr %slot60, align 8
  %v372 = load i64, ptr %slot12, align 8
  %p373 = inttoptr i64 %v372 to ptr
  store i64 %v371, ptr %p373, align 8, !alias.scope !3, !noalias !4
  %v374 = load i64, ptr %slot12, align 8
  store i64 %v374, ptr %slot61, align 8
  %v375 = load i64, ptr %slot13, align 8
  store i64 %v375, ptr %slot62, align 8
  %v376 = load i64, ptr %slot26, align 8
  store i64 %v376, ptr %slot63, align 8
  %v377 = load i64, ptr %slot61, align 8
  %p379 = inttoptr i64 %v377 to ptr
  %gep380 = getelementptr i8, ptr %p379, i64 0
  %op378 = ptrtoint ptr %gep380 to i64
  store i64 %op378, ptr %slot64, align 8
  %v381 = load i64, ptr %slot64, align 8
  %p382 = inttoptr i64 %v381 to ptr
  %ld383 = load i64, ptr %p382, align 8, !alias.scope !3, !noalias !4
  store i64 %ld383, ptr %slot65, align 8
  %v384 = load i64, ptr %slot65, align 8
  %cmp385 = icmp ne i64 %v384, 0
  %cv386 = zext i1 %cmp385 to i32
  store i32 %cv386, ptr %slot66, align 8
  %v387 = load i32, ptr %slot66, align 8
  %cv388 = zext i32 %v387 to i64
  %cond389 = icmp ne i64 %cv388, 0
  br i1 %cond389, label %bb_rcmoveheader57, label %bb_rcmovenext57
bb_rcmoveheader57:
  %v390 = load i64, ptr %slot65, align 8
  %op391 = sub i64 %v390, 16
  store i64 %op391, ptr %slot67, align 8
  %v392 = load i64, ptr %slot65, align 8
  %p393 = inttoptr i64 %v392 to ptr
  %rgep394 = getelementptr i8, ptr %p393, i64 -16
  %ld395 = load i64, ptr %rgep394, align 8, !alias.scope !9, !noalias !10
  store i64 %ld395, ptr %slot68, align 8
  %v396 = load i64, ptr %slot68, align 8
  %op397 = and i64 %v396, 5764607523034234881
  store i64 %op397, ptr %slot69, align 8
  %v398 = load i64, ptr %slot69, align 8
  %cmp399 = icmp ne i64 %v398, 0
  %cv400 = zext i1 %cmp399 to i32
  store i32 %cv400, ptr %slot70, align 8
  %v401 = load i32, ptr %slot70, align 8
  %cv402 = zext i32 %v401 to i64
  %cond403 = icmp ne i64 %cv402, 0
  br i1 %cond403, label %bb_rcmoveslow54, label %bb_rcmovenext57
bb_rcmovenext57:
  %v404 = load i64, ptr %slot61, align 8
  %v405 = load i64, ptr %slot62, align 8
  %p406 = inttoptr i64 %v404 to ptr
  %p407 = inttoptr i64 %v405 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p407, ptr %p406, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v408 = load i64, ptr %slot61, align 8
  %p409 = inttoptr i64 %v408 to ptr
  store i64 0, ptr %p409, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved54
bb_rcmoveslow54:
  %v410 = load i64, ptr %slot25, align 8
  %v411 = load i64, ptr %slot62, align 8
  %v412 = load i64, ptr %slot61, align 8
  %v413 = load i64, ptr %slot63, align 8
  %cv414 = trunc i64 %v413 to i32
  %call415 = call i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64 %v410, i64 %v411, i64 %v412, i32 %cv414) nomerge, !dbg !118
  store i32 %call415, ptr %slot71, align 8
  %v416 = load i32, ptr %slot71, align 8
  %cv417 = zext i32 %v416 to i64
  %cond418 = icmp ne i64 %cv417, 0
  br i1 %cond418, label %bb_rcsuccess64, label %bb_rcfailure64
bb_rcfailure64:
  %v419 = load i64, ptr %slot25, align 8
  %p420 = inttoptr i64 %v419 to ptr
  %call421 = call i32 @myl_rc_take_failure(ptr %p420) nomerge, !dbg !118
  store i32 %call421, ptr %slot72, align 8
  %v422 = load i64, ptr %slot1, align 8
  %p423 = inttoptr i64 %v422 to ptr
  %v424 = load i32, ptr %slot72, align 8
  %call425 = call i32 @myl_qbe_rc_status(ptr %p423, i32 %v424) nomerge, !dbg !118
  store i32 %call425, ptr %slot73, align 8
  br label %bb_failure
bb_rcsuccess64:
  br label %bb_rcmoved54
bb_rcmoved54:
  %v426 = load i64, ptr %slot6, align 8
  %p427 = inttoptr i64 %v426 to ptr
  store i32 0, ptr %p427, align 4, !alias.scope !3, !noalias !4
  %v428 = load i64, ptr %slot9, align 8
  %p429 = inttoptr i64 %v428 to ptr
  store i32 2, ptr %p429, align 4, !alias.scope !3, !noalias !4
  %v430 = load i64, ptr %slot8, align 8
  %p431 = inttoptr i64 %v430 to ptr
  store i32 1, ptr %p431, align 4, !alias.scope !3, !noalias !4
  %v432 = load i64, ptr %slot13, align 8
  store i64 %v432, ptr %slot74, align 8
  %v433 = load i64, ptr %slot74, align 8
  %v434 = load i64, ptr %slot58, align 8
  %p435 = inttoptr i64 %v433 to ptr
  %p436 = inttoptr i64 %v434 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p436, ptr %p435, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v437 = load i64, ptr %slot8, align 8
  %p438 = inttoptr i64 %v437 to ptr
  store i32 0, ptr %p438, align 4, !alias.scope !3, !noalias !4
  %v439 = load i64, ptr %slot54, align 8
  %v440 = load i64, ptr %slot16, align 8
  %p441 = inttoptr i64 %v440 to ptr
  store i64 %v439, ptr %p441, align 8, !alias.scope !3, !noalias !4
  %p442 = inttoptr i64 ptrtoint (ptr @myl_f_aef7122e8c4bbbbfc45afbb7346ef70afe0c568fceb1c7e30c7af8fb567b9226_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr %p442, i64 11) "call-inline-cost"="0", !dbg !118
  %v443 = load i64, ptr %slot16, align 8
  %p444 = inttoptr i64 %v443 to ptr
  %ld445 = load i64, ptr %p444, align 8, !alias.scope !3, !noalias !4
  store i64 %ld445, ptr %slot75, align 8
  %v446 = load i64, ptr %slot11, align 8
  store i64 %v446, ptr %slot76, align 8
  %v447 = load i64, ptr %slot75, align 8
  %v448 = load i64, ptr %slot76, align 8
  %p449 = inttoptr i64 %v447 to ptr
  %p450 = inttoptr i64 %v448 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p450, ptr %p449, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v451 = load i64, ptr %slot7, align 8
  %p452 = inttoptr i64 %v451 to ptr
  store i32 2, ptr %p452, align 4, !alias.scope !3, !noalias !4
  %v453 = load i64, ptr %slot6, align 8
  %p454 = inttoptr i64 %v453 to ptr
  store i32 1, ptr %p454, align 4, !alias.scope !3, !noalias !4
  %v455 = load i64, ptr %slot76, align 8
  %v456 = load i64, ptr %slot16, align 8
  %p457 = inttoptr i64 %v456 to ptr
  store i64 %v455, ptr %p457, align 8, !alias.scope !3, !noalias !4
  %v458 = load i64, ptr %slot16, align 8
  %p459 = inttoptr i64 %v458 to ptr
  %ld460 = load i64, ptr %p459, align 8, !alias.scope !3, !noalias !4
  store i64 %ld460, ptr %slot77, align 8
  %v461 = load i64, ptr %slot16, align 8
  %p462 = inttoptr i64 %v461 to ptr
  %ld463 = load i64, ptr %p462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld463, ptr %slot78, align 8
  %v464 = load i64, ptr %slot13, align 8
  store i64 %v464, ptr %slot79, align 8
  %v465 = load i64, ptr %slot26, align 8
  store i64 %v465, ptr %slot80, align 8
  %v466 = load i64, ptr %slot25, align 8
  %v467 = load i64, ptr %slot79, align 8
  %v468 = load i64, ptr %slot78, align 8
  %v469 = load i64, ptr %slot80, align 8
  %cv470 = trunc i64 %v469 to i32
  %call471 = call i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64 %v466, i64 %v467, i64 %v468, i32 %cv470) nomerge, !dbg !120
  store i32 %call471, ptr %slot81, align 8
  %v472 = load i32, ptr %slot81, align 8
  %cv473 = zext i32 %v472 to i64
  %cond474 = icmp ne i64 %cv473, 0
  br i1 %cond474, label %bb_rcsuccess81, label %bb_rcfailure81
bb_rcfailure81:
  %v475 = load i64, ptr %slot25, align 8
  %p476 = inttoptr i64 %v475 to ptr
  %call477 = call i32 @myl_rc_take_failure(ptr %p476) nomerge, !dbg !120
  store i32 %call477, ptr %slot82, align 8
  %v478 = load i64, ptr %slot1, align 8
  %p479 = inttoptr i64 %v478 to ptr
  %v480 = load i32, ptr %slot82, align 8
  %call481 = call i32 @myl_qbe_rc_status(ptr %p479, i32 %v480) nomerge, !dbg !120
  store i32 %call481, ptr %slot83, align 8
  br label %bb_failure
bb_rcsuccess81:
  %v482 = load i64, ptr %slot6, align 8
  %p483 = inttoptr i64 %v482 to ptr
  store i32 0, ptr %p483, align 4, !alias.scope !3, !noalias !4
  %v484 = load i64, ptr %slot9, align 8
  %p485 = inttoptr i64 %v484 to ptr
  store i32 2, ptr %p485, align 4, !alias.scope !3, !noalias !4
  %v486 = load i64, ptr %slot8, align 8
  %p487 = inttoptr i64 %v486 to ptr
  store i32 1, ptr %p487, align 4, !alias.scope !3, !noalias !4
  %v488 = load i64, ptr %slot13, align 8
  store i64 %v488, ptr %slot84, align 8
  %v489 = load i64, ptr %slot8, align 8
  %p490 = inttoptr i64 %v489 to ptr
  store i32 0, ptr %p490, align 4, !alias.scope !3, !noalias !4
  %v491 = load i64, ptr %slot6, align 8
  %p492 = inttoptr i64 %v491 to ptr
  %ld493 = load i32, ptr %p492, align 4, !alias.scope !3, !noalias !4
  store i32 %ld493, ptr %slot85, align 8
  %v494 = load i32, ptr %slot85, align 8
  %cv495 = zext i32 %v494 to i64
  %cond496 = icmp ne i64 %cv495, 0
  br i1 %cond496, label %bb_rcslotdrop91, label %bb_rcslotdone91
bb_rcslotdrop91:
  %v497 = load i64, ptr %slot6, align 8
  %p498 = inttoptr i64 %v497 to ptr
  store i32 0, ptr %p498, align 4, !alias.scope !3, !noalias !4
  %v499 = load i64, ptr %slot11, align 8
  store i64 %v499, ptr %slot86, align 8
  %v500 = load i64, ptr %slot7, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %ld502 = load i32, ptr %p501, align 4, !alias.scope !3, !noalias !4
  store i32 %ld502, ptr %slot87, align 8
  %v503 = load i32, ptr %slot87, align 8
  %op504 = and i32 %v503, 28
  store i32 %op504, ptr %slot88, align 8
  %v505 = load i32, ptr %slot88, align 8
  %cv506 = zext i32 %v505 to i64
  %cond507 = icmp ne i64 %cv506, 0
  br i1 %cond507, label %bb_rcslotrole91, label %bb_rcslotowner91
bb_rcslotrole91:
  %v508 = load i64, ptr %slot25, align 8
  store i64 %v508, ptr %slot89, align 8
  %v509 = load i64, ptr %slot89, align 8
  %v510 = load i64, ptr %slot86, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64 %v509, i64 %v510) nomerge, !dbg !120
  br label %bb_rcslotdone91
bb_rcslotowner91:
  %v511 = load i64, ptr %slot25, align 8
  store i64 %v511, ptr %slot90, align 8
  %v512 = load i64, ptr %slot90, align 8
  %v513 = load i64, ptr %slot86, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64 %v512, i64 %v513) nomerge, !dbg !120
  br label %bb_rcslotdone91
bb_rcslotdone91:
  %v514 = load i64, ptr %slot84, align 8
  %p515 = inttoptr i64 %v514 to ptr
  %ret516 = load { i64, i64 }, ptr %p515, align 8
  ret { i64, i64 } %ret516
bb_i13:
  %v517 = load i64, ptr %slot14, align 8
  %p518 = inttoptr i64 %v517 to ptr
  %ld519 = load i64, ptr %p518, align 8, !alias.scope !3, !noalias !4
  store i64 %ld519, ptr %slot91, align 8
  %v520 = load i64, ptr %slot91, align 8
  %v521 = load i64, ptr %slot16, align 8
  %p522 = inttoptr i64 %v521 to ptr
  store i64 %v520, ptr %p522, align 8, !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot17, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i64 0, ptr %p524, align 8, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot15, align 8
  %p526 = inttoptr i64 %v525 to ptr
  %ld527 = load i64, ptr %p526, align 8, !alias.scope !3, !noalias !4
  store i64 %ld527, ptr %slot92, align 8
  %v528 = load i64, ptr %slot92, align 8
  %v529 = load i64, ptr %slot18, align 8
  %p530 = inttoptr i64 %v529 to ptr
  store i64 %v528, ptr %p530, align 8, !alias.scope !3, !noalias !4
  %v531 = load i64, ptr %slot18, align 8
  %p532 = inttoptr i64 %v531 to ptr
  %ld533 = load i64, ptr %p532, align 8, !alias.scope !3, !noalias !4
  store i64 %ld533, ptr %slot93, align 8
  %v534 = load i64, ptr %slot93, align 8
  %op535 = add i64 %v534, 0
  store i64 %op535, ptr %slot94, align 8
  %v536 = load i64, ptr %slot94, align 8
  %p537 = inttoptr i64 %v536 to ptr
  %ld538 = load i64, ptr %p537, align 8, !alias.scope !4, !noalias !3
  store i64 %ld538, ptr %slot95, align 8
  %v539 = load i64, ptr %slot95, align 8
  %v540 = load i64, ptr %slot18, align 8
  %p541 = inttoptr i64 %v540 to ptr
  store i64 %v539, ptr %p541, align 8, !alias.scope !3, !noalias !4
  %v542 = load i64, ptr %slot18, align 8
  %p543 = inttoptr i64 %v542 to ptr
  %ld544 = load i64, ptr %p543, align 8, !alias.scope !3, !noalias !4
  store i64 %ld544, ptr %slot96, align 8
  %v545 = load i64, ptr %slot17, align 8
  %p546 = inttoptr i64 %v545 to ptr
  %ld547 = load i64, ptr %p546, align 8, !alias.scope !3, !noalias !4
  store i64 %ld547, ptr %slot97, align 8
  %v548 = load i64, ptr %slot97, align 8
  %v549 = load i64, ptr %slot96, align 8
  %ovpair551 = call { i64, i1 } @llvm.ssub.with.overflow.i64(i64 %v548, i64 %v549)
  %op550 = extractvalue { i64, i1 } %ovpair551, 0
  %ov552 = extractvalue { i64, i1 } %ovpair551, 1
  store i64 %op550, ptr %slot98, align 8
  %v553 = load i64, ptr %slot97, align 8
  %v554 = load i64, ptr %slot96, align 8
  %op555 = xor i64 %v553, %v554
  store i64 %op555, ptr %slot99, align 8
  %v556 = load i64, ptr %slot97, align 8
  %v557 = load i64, ptr %slot98, align 8
  %op558 = xor i64 %v556, %v557
  store i64 %op558, ptr %slot100, align 8
  %v559 = load i64, ptr %slot99, align 8
  %v560 = load i64, ptr %slot100, align 8
  %op561 = and i64 %v559, %v560
  store i64 %op561, ptr %slot101, align 8
  %cv562 = zext i1 %ov552 to i64
  store i64 %cv562, ptr %slot102, align 8
  %v563 = load i64, ptr %slot102, align 8
  %cond564 = icmp ne i64 %v563, 0
  br i1 %cond564, label %bb_overflow105, label %bb_checked105
bb_overflow105:
  %v565 = load i64, ptr %slot1, align 8
  %p566 = inttoptr i64 %v565 to ptr
  %v567 = load i64, ptr %slot97, align 8
  %v568 = load i64, ptr %slot96, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p566, i64 1, i64 %v567, i64 %v568, i64 64) nomerge, !dbg !122
  unreachable
bb_checked105:
  %v569 = load i64, ptr %slot98, align 8
  %v570 = load i64, ptr %slot17, align 8
  %p571 = inttoptr i64 %v570 to ptr
  store i64 %v569, ptr %p571, align 8, !alias.scope !3, !noalias !4
  %v572 = load i64, ptr %slot20, align 8
  store i64 %v572, ptr %slot103, align 8
  %v573 = load i64, ptr %slot26, align 8
  store i64 %v573, ptr %slot104, align 8
  %v574 = load i64, ptr %slot17, align 8
  store i64 %v574, ptr %slot105, align 8
  %v575 = load i64, ptr %slot103, align 8
  %p577 = inttoptr i64 %v575 to ptr
  %gep578 = getelementptr i8, ptr %p577, i64 0
  %op576 = ptrtoint ptr %gep578 to i64
  store i64 %op576, ptr %slot106, align 8
  %v579 = load i64, ptr %slot105, align 8
  %p580 = inttoptr i64 %v579 to ptr
  %ld581 = load i64, ptr %p580, align 8, !alias.scope !3, !noalias !4
  store i64 %ld581, ptr %slot107, align 8
  %v582 = load i64, ptr %slot107, align 8
  %v583 = load i64, ptr %slot106, align 8
  %p584 = inttoptr i64 %v583 to ptr
  store i64 %v582, ptr %p584, align 8, !alias.scope !3, !noalias !4
  %v585 = load i64, ptr %slot103, align 8
  %v586 = load i64, ptr %slot17, align 8
  %p587 = inttoptr i64 %v586 to ptr
  store i64 %v585, ptr %p587, align 8, !alias.scope !3, !noalias !4
  %v588 = load i64, ptr %slot16, align 8
  %p589 = inttoptr i64 %v588 to ptr
  %ld590 = load i64, ptr %p589, align 8, !alias.scope !3, !noalias !4
  store i64 %ld590, ptr %slot108, align 8
  %v591 = load i64, ptr %slot17, align 8
  %p592 = inttoptr i64 %v591 to ptr
  %ld593 = load i64, ptr %p592, align 8, !alias.scope !3, !noalias !4
  store i64 %ld593, ptr %slot109, align 8
  %v594 = load i64, ptr %slot1, align 8
  %v595 = load i64, ptr %slot108, align 8
  %v596 = load i64, ptr %slot109, align 8
  %call597 = call { i64, i64 } @myl_f_603333d28028cf46521367f5c6149652048d2b8c47131a1531b8cd80e188135a(i64 %v594, i64 %v595, i64 %v596) nomerge, !dbg !124
  store { i64, i64 } %call597, ptr %callresult111, align 8
  %addr598 = ptrtoint ptr %callresult111 to i64
  store i64 %addr598, ptr %slot110, align 8
  %v599 = load i64, ptr %slot110, align 8
  %v600 = load i64, ptr %slot16, align 8
  %p601 = inttoptr i64 %v600 to ptr
  store i64 %v599, ptr %p601, align 8, !alias.scope !3, !noalias !4
  %v602 = load i64, ptr %slot16, align 8
  %p603 = inttoptr i64 %v602 to ptr
  %ld604 = load i64, ptr %p603, align 8, !alias.scope !3, !noalias !4
  store i64 %ld604, ptr %slot112, align 8
  %v605 = load i64, ptr %slot13, align 8
  store i64 %v605, ptr %slot113, align 8
  %v606 = load i64, ptr %slot112, align 8
  %v607 = load i64, ptr %slot113, align 8
  %p608 = inttoptr i64 %v606 to ptr
  %p609 = inttoptr i64 %v607 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p609, ptr %p608, i64 16, i1 false)
  %v610 = load i64, ptr %slot9, align 8
  %p611 = inttoptr i64 %v610 to ptr
  store i32 2, ptr %p611, align 4, !alias.scope !3, !noalias !4
  %v612 = load i64, ptr %slot8, align 8
  %p613 = inttoptr i64 %v612 to ptr
  store i32 1, ptr %p613, align 4, !alias.scope !3, !noalias !4
  %v614 = load i64, ptr %slot11, align 8
  store i64 %v614, ptr %slot114, align 8
  %v615 = load i64, ptr %slot13, align 8
  store i64 %v615, ptr %slot115, align 8
  %v616 = load i64, ptr %slot115, align 8
  %v617 = load i64, ptr %slot114, align 8
  %p618 = inttoptr i64 %v616 to ptr
  %p619 = inttoptr i64 %v617 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p619, ptr %p618, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v620 = load i64, ptr %slot7, align 8
  %p621 = inttoptr i64 %v620 to ptr
  store i32 2, ptr %p621, align 4, !alias.scope !3, !noalias !4
  %v622 = load i64, ptr %slot9, align 8
  %p623 = inttoptr i64 %v622 to ptr
  %ld624 = load i32, ptr %p623, align 4, !alias.scope !3, !noalias !4
  store i32 %ld624, ptr %slot116, align 8
  %v625 = load i32, ptr %slot116, align 8
  %v626 = load i64, ptr %slot7, align 8
  %p627 = inttoptr i64 %v626 to ptr
  store i32 %v625, ptr %p627, align 4, !alias.scope !3, !noalias !4
  %v628 = load i64, ptr %slot8, align 8
  %p629 = inttoptr i64 %v628 to ptr
  store i32 0, ptr %p629, align 4, !alias.scope !3, !noalias !4
  %v630 = load i64, ptr %slot6, align 8
  %p631 = inttoptr i64 %v630 to ptr
  store i32 1, ptr %p631, align 4, !alias.scope !3, !noalias !4
  %v632 = load i64, ptr %slot114, align 8
  %v633 = load i64, ptr %slot16, align 8
  %p634 = inttoptr i64 %v633 to ptr
  store i64 %v632, ptr %p634, align 8, !alias.scope !3, !noalias !4
  %v635 = load i64, ptr %slot16, align 8
  %p636 = inttoptr i64 %v635 to ptr
  %ld637 = load i64, ptr %p636, align 8, !alias.scope !3, !noalias !4
  store i64 %ld637, ptr %slot117, align 8
  %v638 = load i64, ptr %slot117, align 8
  %p639 = inttoptr i64 %v638 to ptr
  %ld640 = load i32, ptr %p639, align 4, !alias.scope !3, !noalias !4
  %ext641 = zext i32 %ld640 to i64
  store i64 %ext641, ptr %slot118, align 8
  %v642 = load i64, ptr %slot118, align 8
  %cmp643 = icmp eq i64 %v642, 1
  %cv644 = zext i1 %cmp643 to i64
  store i64 %cv644, ptr %slot119, align 8
  %v645 = load i64, ptr %slot119, align 8
  %cond646 = icmp ne i64 %v645, 0
  br i1 %cond646, label %bb_errtrace132, label %bb_errtraced132
bb_errtrace132:
  %p647 = inttoptr i64 ptrtoint (ptr @myl_f_aef7122e8c4bbbbfc45afbb7346ef70afe0c568fceb1c7e30c7af8fb567b9226_meta to i64) to ptr
  call preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr %p647, i64 8589934612) "call-inline-cost"="0", !dbg !126
  br label %bb_errtraced132
bb_errtraced132:
  %v648 = load i64, ptr %slot16, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ld650 = load i64, ptr %p649, align 8, !alias.scope !3, !noalias !4
  store i64 %ld650, ptr %slot120, align 8
  %v651 = load i64, ptr %slot13, align 8
  store i64 %v651, ptr %slot121, align 8
  %v652 = load i64, ptr %slot26, align 8
  store i64 %v652, ptr %slot122, align 8
  %v653 = load i64, ptr %slot25, align 8
  %v654 = load i64, ptr %slot121, align 8
  %v655 = load i64, ptr %slot120, align 8
  %v656 = load i64, ptr %slot122, align 8
  %cv657 = trunc i64 %v656 to i32
  %call658 = call i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64 %v653, i64 %v654, i64 %v655, i32 %cv657) nomerge, !dbg !126
  store i32 %call658, ptr %slot123, align 8
  %v659 = load i32, ptr %slot123, align 8
  %cv660 = zext i32 %v659 to i64
  %cond661 = icmp ne i64 %cv660, 0
  br i1 %cond661, label %bb_rcsuccess137, label %bb_rcfailure137
bb_rcfailure137:
  %v662 = load i64, ptr %slot25, align 8
  %p663 = inttoptr i64 %v662 to ptr
  %call664 = call i32 @myl_rc_take_failure(ptr %p663) nomerge, !dbg !126
  store i32 %call664, ptr %slot124, align 8
  %v665 = load i64, ptr %slot1, align 8
  %p666 = inttoptr i64 %v665 to ptr
  %v667 = load i32, ptr %slot124, align 8
  %call668 = call i32 @myl_qbe_rc_status(ptr %p666, i32 %v667) nomerge, !dbg !126
  store i32 %call668, ptr %slot125, align 8
  br label %bb_failure
bb_rcsuccess137:
  %v669 = load i64, ptr %slot6, align 8
  %p670 = inttoptr i64 %v669 to ptr
  store i32 0, ptr %p670, align 4, !alias.scope !3, !noalias !4
  %v671 = load i64, ptr %slot9, align 8
  %p672 = inttoptr i64 %v671 to ptr
  store i32 2, ptr %p672, align 4, !alias.scope !3, !noalias !4
  %v673 = load i64, ptr %slot8, align 8
  %p674 = inttoptr i64 %v673 to ptr
  store i32 1, ptr %p674, align 4, !alias.scope !3, !noalias !4
  %v675 = load i64, ptr %slot13, align 8
  store i64 %v675, ptr %slot126, align 8
  %v676 = load i64, ptr %slot8, align 8
  %p677 = inttoptr i64 %v676 to ptr
  store i32 0, ptr %p677, align 4, !alias.scope !3, !noalias !4
  %v678 = load i64, ptr %slot6, align 8
  %p679 = inttoptr i64 %v678 to ptr
  %ld680 = load i32, ptr %p679, align 4, !alias.scope !3, !noalias !4
  store i32 %ld680, ptr %slot127, align 8
  %v681 = load i32, ptr %slot127, align 8
  %cv682 = zext i32 %v681 to i64
  %cond683 = icmp ne i64 %cv682, 0
  br i1 %cond683, label %bb_rcslotdrop147, label %bb_rcslotdone147
bb_rcslotdrop147:
  %v684 = load i64, ptr %slot6, align 8
  %p685 = inttoptr i64 %v684 to ptr
  store i32 0, ptr %p685, align 4, !alias.scope !3, !noalias !4
  %v686 = load i64, ptr %slot11, align 8
  store i64 %v686, ptr %slot128, align 8
  %v687 = load i64, ptr %slot7, align 8
  %p688 = inttoptr i64 %v687 to ptr
  %ld689 = load i32, ptr %p688, align 4, !alias.scope !3, !noalias !4
  store i32 %ld689, ptr %slot129, align 8
  %v690 = load i32, ptr %slot129, align 8
  %op691 = and i32 %v690, 28
  store i32 %op691, ptr %slot130, align 8
  %v692 = load i32, ptr %slot130, align 8
  %cv693 = zext i32 %v692 to i64
  %cond694 = icmp ne i64 %cv693, 0
  br i1 %cond694, label %bb_rcslotrole147, label %bb_rcslotowner147
bb_rcslotrole147:
  %v695 = load i64, ptr %slot25, align 8
  store i64 %v695, ptr %slot131, align 8
  %v696 = load i64, ptr %slot131, align 8
  %v697 = load i64, ptr %slot128, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64 %v696, i64 %v697) nomerge, !dbg !126
  br label %bb_rcslotdone147
bb_rcslotowner147:
  %v698 = load i64, ptr %slot25, align 8
  store i64 %v698, ptr %slot132, align 8
  %v699 = load i64, ptr %slot132, align 8
  %v700 = load i64, ptr %slot128, align 8
  call void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64 %v699, i64 %v700) nomerge, !dbg !126
  br label %bb_rcslotdone147
bb_rcslotdone147:
  %v701 = load i64, ptr %slot126, align 8
  %p702 = inttoptr i64 %v701 to ptr
  %ret703 = load { i64, i64 }, ptr %p702, align 8
  ret { i64, i64 } %ret703
bb_failure:
  %v704 = load i64, ptr %slot5, align 8
  %p705 = inttoptr i64 %v704 to ptr
  call void @llvm.memset.p0.i64(ptr %p705, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v706 = load i64, ptr %slot5, align 8
  %p707 = inttoptr i64 %v706 to ptr
  %ret708 = load { i64, i64 }, ptr %p707, align 8
  ret { i64, i64 } %ret708
bb_entry_failure:
  %v709 = load i64, ptr %slot5, align 8
  %p710 = inttoptr i64 %v709 to ptr
  call void @llvm.memset.p0.i64(ptr %p710, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !126
  %v711 = load i64, ptr %slot5, align 8
  %p712 = inttoptr i64 %v711 to ptr
  %ret713 = load { i64, i64 }, ptr %p712, align 8
  ret { i64, i64 } %ret713
}

@myl_f_aef7122e8c4bbbbfc45afbb7346ef70afe0c568fceb1c7e30c7af8fb567b9226_meta = external global i8, align 8
@myl_lit_1e9db636fa001c2114200dbe3ddea0b143255a95e35f6ece8abdde9e9aeb457c = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare { i64, i1 } @llvm.ssub.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare { i64, i64 } @myl_f_603333d28028cf46521367f5c6149652048d2b8c47131a1531b8cd80e188135a(i64, i64, i64)
declare preserve_mostcc void @myl_qbe_error_trace_append_preserve_most(ptr, i64) cold nounwind
declare preserve_mostcc void @myl_qbe_error_trace_origin_preserve_most(ptr, i64) cold nounwind
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_drop(i64, i64)
declare i32 @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_take(i64, i64, i64, i32)
declare void @myl_t_79cc4568527f38a1730822acdf04c72ecfb6c0db83274fe9ac353685177fc52c_rcg_unloan(i64, i64)
declare i32 @myl_t_8c25cb3686462e9a86d2883c5688a22fe738b0bbc85f458d2d2b5f3f667c6d5a_rcg_take(i64, i64, i64, i32)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_aef7122e8c4bbbbfc45afbb7346ef70afe0c568fceb1c7e30c7af8fb567b9226", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_aef7122e8c4bbbbfc45afbb7346ef70afe0c568fceb1c7e30c7af8fb567b9226", linkageName: "myl_f_aef7122e8c4bbbbfc45afbb7346ef70afe0c568fceb1c7e30c7af8fb567b9226", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 16547418564750451953, i64 0, !"myl_f_aef7122e8c4bbbbfc45afbb7346ef70afe0c568fceb1c7e30c7af8fb567b9226"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646583)
!114 = !DILocation(line: 6, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!116 = !DILocation(line: 8, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!118 = !DILocation(line: 12, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!120 = !DILocation(line: 13, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646679)
!122 = !DILocation(line: 18, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!124 = !DILocation(line: 20, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646703)
!126 = !DILocation(line: 21, column: 0, scope: !127)
