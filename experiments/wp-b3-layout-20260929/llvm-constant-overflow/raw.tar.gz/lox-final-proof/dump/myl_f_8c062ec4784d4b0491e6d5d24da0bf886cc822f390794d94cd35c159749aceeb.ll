target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i32, align 8
  %slot31 = alloca i32, align 8
  %slot32 = alloca i32, align 8
  %slot33 = alloca i32, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i32, align 8
  %slot39 = alloca i32, align 8
  %slot40 = alloca i32, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i32, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i32, align 8
  %slot48 = alloca i32, align 8
  %slot49 = alloca i32, align 8
  %slot50 = alloca i32, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i32, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i32, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i64, align 8
  %slot61 = alloca i64, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i32, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i64, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i32, align 8
  %slot73 = alloca i64, align 8
  %slot74 = alloca i64, align 8
  %slot75 = alloca i32, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i64, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i64, align 8
  %slot85 = alloca i64, align 8
  %slot86 = alloca i32, align 8
  %slot87 = alloca i64, align 8
  %slot88 = alloca i64, align 8
  %slot89 = alloca i32, align 8
  %slot90 = alloca i64, align 8
  %slot91 = alloca i64, align 8
  %slot92 = alloca i64, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i64, align 8
  %slot96 = alloca i64, align 8
  %slot97 = alloca i32, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i32, align 8
  %slot101 = alloca i64, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i64, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i32, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i64, align 8
  %slot116 = alloca i64, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i64, align 8
  %slot119 = alloca i32, align 8
  %slot120 = alloca i32, align 8
  %slot121 = alloca i32, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i64, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i32, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v129 = load i64, ptr %slot1, align 8
  %op130 = add i64 %v129, 32
  store i64 %op130, ptr %slot4, align 8
  %mem131 = alloca i8, i64 16, align 8
  %ptr132 = ptrtoint ptr %mem131 to i64
  store i64 %ptr132, ptr %slot5, align 8
  %mem133 = alloca i8, i64 8, align 8
  %ptr134 = ptrtoint ptr %mem133 to i64
  store i64 %ptr134, ptr %slot6, align 8
  %mem135 = alloca i8, i64 8, align 8
  %ptr136 = ptrtoint ptr %mem135 to i64
  store i64 %ptr136, ptr %slot7, align 8
  %mem137 = alloca i8, i64 8, align 8
  %ptr138 = ptrtoint ptr %mem137 to i64
  store i64 %ptr138, ptr %slot8, align 8
  %mem139 = alloca i8, i64 8, align 8
  %ptr140 = ptrtoint ptr %mem139 to i64
  store i64 %ptr140, ptr %slot9, align 8
  %mem141 = alloca i8, i64 16, align 8
  %ptr142 = ptrtoint ptr %mem141 to i64
  store i64 %ptr142, ptr %slot10, align 8
  %mem143 = alloca i8, i64 8, align 8
  %ptr144 = ptrtoint ptr %mem143 to i64
  store i64 %ptr144, ptr %slot11, align 8
  %mem145 = alloca i8, i64 16, align 8
  %ptr146 = ptrtoint ptr %mem145 to i64
  store i64 %ptr146, ptr %slot12, align 8
  %mem147 = alloca i8, i64 8, align 8
  %ptr148 = ptrtoint ptr %mem147 to i64
  store i64 %ptr148, ptr %slot13, align 8
  %mem149 = alloca i8, i64 8, align 8
  %ptr150 = ptrtoint ptr %mem149 to i64
  store i64 %ptr150, ptr %slot14, align 8
  %mem151 = alloca i8, i64 8, align 8
  %ptr152 = ptrtoint ptr %mem151 to i64
  store i64 %ptr152, ptr %slot15, align 8
  %mem153 = alloca i8, i64 8, align 8
  %ptr154 = ptrtoint ptr %mem153 to i64
  store i64 %ptr154, ptr %slot16, align 8
  %mem155 = alloca i8, i64 16, align 8
  %ptr156 = ptrtoint ptr %mem155 to i64
  store i64 %ptr156, ptr %slot17, align 8
  %v157 = load i64, ptr %slot2, align 8
  %v158 = load i64, ptr %slot13, align 8
  %p159 = inttoptr i64 %v158 to ptr
  store i64 %v157, ptr %p159, align 8, !alias.scope !3, !noalias !4
  %v160 = load i64, ptr %slot3, align 8
  %v161 = load i64, ptr %slot14, align 8
  %p162 = inttoptr i64 %v161 to ptr
  store i64 %v160, ptr %p162, align 8, !alias.scope !3, !noalias !4
  %v163 = load i64, ptr %slot1, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %call165 = call ptr @myl_qbe_heap(ptr %p164) nomerge, !dbg !110
  %calladdr166 = ptrtoint ptr %call165 to i64
  store i64 %calladdr166, ptr %slot18, align 8
  %v167 = load i64, ptr %slot1, align 8
  %p168 = inttoptr i64 %v167 to ptr
  %call169 = call i64 @myl_qbe_region_mark(ptr %p168) nomerge, !dbg !110
  store i64 %call169, ptr %slot19, align 8
  %v170 = load i64, ptr %slot6, align 8
  %p171 = inttoptr i64 %v170 to ptr
  store i32 0, ptr %p171, align 4, !alias.scope !3, !noalias !4
  %v172 = load i64, ptr %slot7, align 8
  %p173 = inttoptr i64 %v172 to ptr
  store i32 0, ptr %p173, align 4, !alias.scope !3, !noalias !4
  %v174 = load i64, ptr %slot8, align 8
  %p175 = inttoptr i64 %v174 to ptr
  store i32 0, ptr %p175, align 4, !alias.scope !3, !noalias !4
  %v176 = load i64, ptr %slot9, align 8
  %p177 = inttoptr i64 %v176 to ptr
  store i32 0, ptr %p177, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v178 = load i64, ptr %slot13, align 8
  %p179 = inttoptr i64 %v178 to ptr
  %ld180 = load i64, ptr %p179, align 8, !alias.scope !3, !noalias !4
  store i64 %ld180, ptr %slot20, align 8
  %v181 = load i64, ptr %slot20, align 8
  %v182 = load i64, ptr %slot15, align 8
  %p183 = inttoptr i64 %v182 to ptr
  store i64 %v181, ptr %p183, align 8, !alias.scope !3, !noalias !4
  %v184 = load i64, ptr %slot14, align 8
  %p185 = inttoptr i64 %v184 to ptr
  %ld186 = load i64, ptr %p185, align 8, !alias.scope !3, !noalias !4
  store i64 %ld186, ptr %slot21, align 8
  %v187 = load i64, ptr %slot21, align 8
  %v188 = load i64, ptr %slot16, align 8
  %p189 = inttoptr i64 %v188 to ptr
  store i64 %v187, ptr %p189, align 8, !alias.scope !3, !noalias !4
  %v190 = load i64, ptr %slot17, align 8
  store i64 %v190, ptr %slot22, align 8
  %v191 = load i64, ptr %slot22, align 8
  %p192 = inttoptr i64 %v191 to ptr
  store i64 0, ptr %p192, align 8, !alias.scope !3, !noalias !4
  %v193 = load i64, ptr %slot22, align 8
  %p195 = inttoptr i64 %v193 to ptr
  %gep196 = getelementptr i8, ptr %p195, i64 8
  %op194 = ptrtoint ptr %gep196 to i64
  store i64 %op194, ptr %slot23, align 8
  %v197 = load i64, ptr %slot23, align 8
  %p198 = inttoptr i64 %v197 to ptr
  store i64 0, ptr %p198, align 8, !alias.scope !3, !noalias !4
  %v199 = load i64, ptr %slot9, align 8
  %p200 = inttoptr i64 %v199 to ptr
  store i32 1, ptr %p200, align 4, !alias.scope !3, !noalias !4
  %v201 = load i64, ptr %slot19, align 8
  store i64 %v201, ptr %slot24, align 8
  %v202 = load i64, ptr %slot15, align 8
  %p203 = inttoptr i64 %v202 to ptr
  %ld204 = load i64, ptr %p203, align 8, !alias.scope !3, !noalias !4
  store i64 %ld204, ptr %slot25, align 8
  %v205 = load i64, ptr %slot25, align 8
  %v206 = load i64, ptr %slot11, align 8
  %p207 = inttoptr i64 %v206 to ptr
  store i64 %v205, ptr %p207, align 8, !alias.scope !3, !noalias !4
  %v208 = load i64, ptr %slot11, align 8
  store i64 %v208, ptr %slot26, align 8
  %v209 = load i64, ptr %slot22, align 8
  %p211 = inttoptr i64 %v209 to ptr
  %gep212 = getelementptr i8, ptr %p211, i64 0
  %op210 = ptrtoint ptr %gep212 to i64
  store i64 %op210, ptr %slot27, align 8
  %v213 = load i64, ptr %slot15, align 8
  %p214 = inttoptr i64 %v213 to ptr
  %ld215 = load i64, ptr %p214, align 8, !alias.scope !3, !noalias !4
  store i64 %ld215, ptr %slot28, align 8
  %v216 = load i64, ptr %slot28, align 8
  %v217 = load i64, ptr %slot11, align 8
  %p218 = inttoptr i64 %v217 to ptr
  store i64 %v216, ptr %p218, align 8, !alias.scope !3, !noalias !4
  %v219 = load i64, ptr %slot11, align 8
  store i64 %v219, ptr %slot29, align 8
  %v220 = load i64, ptr %slot6, align 8
  %p221 = inttoptr i64 %v220 to ptr
  %ld222 = load i32, ptr %p221, align 4, !alias.scope !3, !noalias !4
  store i32 %ld222, ptr %slot30, align 8
  %v223 = load i64, ptr %slot7, align 8
  %p224 = inttoptr i64 %v223 to ptr
  %ld225 = load i32, ptr %p224, align 4, !alias.scope !3, !noalias !4
  store i32 %ld225, ptr %slot31, align 8
  %v226 = load i32, ptr %slot31, align 8
  %op227 = and i32 %v226, 24
  store i32 %op227, ptr %slot31, align 8
  %v228 = load i32, ptr %slot31, align 8
  %cmp229 = icmp eq i32 %v228, 0
  %cv230 = zext i1 %cmp229 to i32
  store i32 %cv230, ptr %slot32, align 8
  %v231 = load i32, ptr %slot30, align 8
  %v232 = load i32, ptr %slot32, align 8
  %op233 = and i32 %v231, %v232
  store i32 %op233, ptr %slot33, align 8
  %v234 = load i32, ptr %slot33, align 8
  %cv235 = zext i32 %v234 to i64
  %cond236 = icmp ne i64 %cv235, 0
  br i1 %cond236, label %bb_rctake13, label %bb_rccopy13
bb_rctake13:
  %v237 = load i64, ptr %slot12, align 8
  store i64 %v237, ptr %slot34, align 8
  %v238 = load i64, ptr %slot19, align 8
  store i64 %v238, ptr %slot35, align 8
  %v239 = load i64, ptr %slot29, align 8
  %v240 = load i64, ptr %slot34, align 8
  %op241 = sub i64 %v239, %v240
  store i64 %op241, ptr %slot36, align 8
  %v242 = load i64, ptr %slot34, align 8
  %v243 = load i64, ptr %slot29, align 8
  %op244 = sub i64 %v242, %v243
  store i64 %op244, ptr %slot37, align 8
  %v245 = load i64, ptr %slot36, align 8
  %cmp246 = icmp ult i64 %v245, 8
  %cv247 = zext i1 %cmp246 to i32
  store i32 %cv247, ptr %slot38, align 8
  %v248 = load i64, ptr %slot37, align 8
  %cmp249 = icmp ult i64 %v248, 8
  %cv250 = zext i1 %cmp249 to i32
  store i32 %cv250, ptr %slot39, align 8
  %v251 = load i32, ptr %slot38, align 8
  %v252 = load i32, ptr %slot39, align 8
  %op253 = or i32 %v251, %v252
  store i32 %op253, ptr %slot40, align 8
  %v254 = load i32, ptr %slot40, align 8
  %cv255 = zext i32 %v254 to i64
  %cond256 = icmp ne i64 %cv255, 0
  br i1 %cond256, label %bb_rcmoveslow22, label %bb_rcmovecheck22
bb_rcmovecheck22:
  %v257 = load i64, ptr %slot29, align 8
  %p259 = inttoptr i64 %v257 to ptr
  %gep260 = getelementptr i8, ptr %p259, i64 0
  %op258 = ptrtoint ptr %gep260 to i64
  store i64 %op258, ptr %slot41, align 8
  %v261 = load i64, ptr %slot41, align 8
  %p262 = inttoptr i64 %v261 to ptr
  %ld263 = load i64, ptr %p262, align 8, !alias.scope !3, !noalias !4
  store i64 %ld263, ptr %slot42, align 8
  %v264 = load i64, ptr %slot42, align 8
  %cmp265 = icmp ne i64 %v264, 0
  %cv266 = zext i1 %cmp265 to i32
  store i32 %cv266, ptr %slot43, align 8
  %v267 = load i32, ptr %slot43, align 8
  %cv268 = zext i32 %v267 to i64
  %cond269 = icmp ne i64 %cv268, 0
  br i1 %cond269, label %bb_rcmoveheader30, label %bb_rcmovenext30
bb_rcmoveheader30:
  %v270 = load i64, ptr %slot42, align 8
  %op271 = sub i64 %v270, 16
  store i64 %op271, ptr %slot44, align 8
  %v272 = load i64, ptr %slot42, align 8
  %p273 = inttoptr i64 %v272 to ptr
  %rgep274 = getelementptr i8, ptr %p273, i64 -16
  %ld275 = load i64, ptr %rgep274, align 8, !alias.scope !9, !noalias !10
  store i64 %ld275, ptr %slot45, align 8
  %v276 = load i64, ptr %slot45, align 8
  %op277 = and i64 %v276, 5764607523034234881
  store i64 %op277, ptr %slot46, align 8
  %v278 = load i64, ptr %slot46, align 8
  %cmp279 = icmp ne i64 %v278, 0
  %cv280 = zext i1 %cmp279 to i32
  store i32 %cv280, ptr %slot47, align 8
  %v281 = load i32, ptr %slot47, align 8
  %cv282 = zext i32 %v281 to i64
  %cond283 = icmp ne i64 %cv282, 0
  br i1 %cond283, label %bb_rcmoveslow22, label %bb_rcmovenext30
bb_rcmovenext30:
  %v284 = load i64, ptr %slot29, align 8
  %v285 = load i64, ptr %slot34, align 8
  %p286 = inttoptr i64 %v284 to ptr
  %p287 = inttoptr i64 %v285 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p287, ptr %p286, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v288 = load i64, ptr %slot29, align 8
  %p289 = inttoptr i64 %v288 to ptr
  store i64 0, ptr %p289, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved22
bb_rcmoveslow22:
  %v290 = load i64, ptr %slot18, align 8
  %v291 = load i64, ptr %slot34, align 8
  %v292 = load i64, ptr %slot29, align 8
  %v293 = load i64, ptr %slot35, align 8
  %cv294 = trunc i64 %v293 to i32
  %call295 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v290, i64 %v291, i64 %v292, i32 %cv294) nomerge, !dbg !112
  store i32 %call295, ptr %slot48, align 8
  %v296 = load i32, ptr %slot48, align 8
  %cv297 = zext i32 %v296 to i64
  %cond298 = icmp ne i64 %cv297, 0
  br i1 %cond298, label %bb_rcsuccess37, label %bb_rcfailure37
bb_rcfailure37:
  %v299 = load i64, ptr %slot18, align 8
  %p300 = inttoptr i64 %v299 to ptr
  %call301 = call i32 @myl_rc_take_failure(ptr %p300) nomerge, !dbg !112
  store i32 %call301, ptr %slot49, align 8
  %v302 = load i64, ptr %slot1, align 8
  %p303 = inttoptr i64 %v302 to ptr
  %v304 = load i32, ptr %slot49, align 8
  %call305 = call i32 @myl_qbe_rc_status(ptr %p303, i32 %v304) nomerge, !dbg !112
  store i32 %call305, ptr %slot50, align 8
  br label %bb_failure
bb_rcsuccess37:
  br label %bb_rcmoved22
bb_rcmoved22:
  %v306 = load i64, ptr %slot6, align 8
  %p307 = inttoptr i64 %v306 to ptr
  store i32 0, ptr %p307, align 4, !alias.scope !3, !noalias !4
  %v308 = load i64, ptr %slot8, align 8
  %p309 = inttoptr i64 %v308 to ptr
  store i32 1, ptr %p309, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared13
bb_rccopy13:
  %v310 = load i64, ptr %slot12, align 8
  store i64 %v310, ptr %slot51, align 8
  %v311 = load i64, ptr %slot19, align 8
  store i64 %v311, ptr %slot52, align 8
  %v312 = load i64, ptr %slot29, align 8
  %p313 = inttoptr i64 %v312 to ptr
  %ld314 = load i64, ptr %p313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld314, ptr %slot53, align 8
  %v315 = load i64, ptr %slot53, align 8
  %cmp316 = icmp ne i64 %v315, 0
  %cv317 = zext i1 %cmp316 to i32
  store i32 %cv317, ptr %slot54, align 8
  %v318 = load i32, ptr %slot54, align 8
  %cv319 = zext i32 %v318 to i64
  %cond320 = icmp ne i64 %cv319, 0
  br i1 %cond320, label %bb_rcgnn46, label %bb_rcgplain46
bb_rcgnn46:
  %v321 = load i64, ptr %slot53, align 8
  %op322 = sub i64 %v321, 16
  store i64 %op322, ptr %slot55, align 8
  %v323 = load i64, ptr %slot53, align 8
  %p324 = inttoptr i64 %v323 to ptr
  %rgep325 = getelementptr i8, ptr %p324, i64 -16
  %ld326 = load i64, ptr %rgep325, align 8, !alias.scope !9, !noalias !10
  store i64 %ld326, ptr %slot56, align 8
  %v327 = load i64, ptr %slot56, align 8
  %op328 = and i64 %v327, 4611686018427387906
  store i64 %op328, ptr %slot57, align 8
  %v329 = load i64, ptr %slot57, align 8
  %cmp330 = icmp ne i64 %v329, 0
  %cv331 = zext i1 %cmp330 to i32
  store i32 %cv331, ptr %slot58, align 8
  %v332 = load i32, ptr %slot58, align 8
  %cv333 = zext i32 %v332 to i64
  %cond334 = icmp ne i64 %cv333, 0
  br i1 %cond334, label %bb_rcgspecial46, label %bb_rcginc46
bb_rcginc46:
  %v335 = load i64, ptr %slot53, align 8
  %op336 = sub i64 %v335, 32
  store i64 %op336, ptr %slot59, align 8
  %v337 = load i64, ptr %slot53, align 8
  %p338 = inttoptr i64 %v337 to ptr
  %rgep339 = getelementptr i8, ptr %p338, i64 -32
  %ld340 = load i64, ptr %rgep339, align 8, !alias.scope !9, !noalias !10
  store i64 %ld340, ptr %slot60, align 8
  %v341 = load i64, ptr %slot60, align 8
  %op342 = add i64 %v341, 1
  store i64 %op342, ptr %slot61, align 8
  %v343 = load i64, ptr %slot61, align 8
  %cmp344 = icmp eq i64 %v343, 0
  %cv345 = zext i1 %cmp344 to i32
  store i32 %cv345, ptr %slot62, align 8
  %v346 = load i32, ptr %slot62, align 8
  %cv347 = zext i32 %v346 to i64
  %cond348 = icmp ne i64 %cv347, 0
  br i1 %cond348, label %bb_rcglimit46, label %bb_rcgcapacity46
bb_rcglimit46:
  %v349 = load i64, ptr %slot1, align 8
  %p350 = inttoptr i64 %v349 to ptr
  %call351 = call i32 @myl_qbe_rc_status(ptr %p350, i32 2) nomerge, !dbg !112
  store i32 %call351, ptr %slot63, align 8
  br label %bb_failure
bb_rcgcapacity46:
  %v352 = load i64, ptr %slot61, align 8
  %v353 = load i64, ptr %slot53, align 8
  %p354 = inttoptr i64 %v353 to ptr
  %rgep355 = getelementptr i8, ptr %p354, i64 -32
  store i64 %v352, ptr %rgep355, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain46
bb_rcgspecial46:
  %v356 = load i64, ptr %slot56, align 8
  %op357 = and i64 %v356, 4611686018427387904
  store i64 %op357, ptr %slot64, align 8
  %v358 = load i64, ptr %slot64, align 8
  %cmp359 = icmp ne i64 %v358, 0
  %cv360 = zext i1 %cmp359 to i32
  store i32 %cv360, ptr %slot65, align 8
  %v361 = load i32, ptr %slot65, align 8
  %cv362 = zext i32 %v361 to i64
  %cond363 = icmp ne i64 %cv362, 0
  br i1 %cond363, label %bb_rcgslow46, label %bb_rcgplain46
bb_rcgslow46:
  %v364 = load i64, ptr %slot18, align 8
  %v365 = load i64, ptr %slot51, align 8
  %v366 = load i64, ptr %slot29, align 8
  %v367 = load i64, ptr %slot52, align 8
  %cv368 = trunc i64 %v367 to i32
  %call369 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v364, i64 %v365, i64 %v366, i32 %cv368) nomerge, !dbg !112
  store i32 %call369, ptr %slot66, align 8
  %v370 = load i32, ptr %slot66, align 8
  %cv371 = zext i32 %v370 to i64
  %cond372 = icmp ne i64 %cv371, 0
  br i1 %cond372, label %bb_rcsuccess60, label %bb_rcfailure60
bb_rcfailure60:
  %v373 = load i64, ptr %slot18, align 8
  %p374 = inttoptr i64 %v373 to ptr
  %call375 = call i32 @myl_rc_take_failure(ptr %p374) nomerge, !dbg !112
  store i32 %call375, ptr %slot67, align 8
  %v376 = load i64, ptr %slot1, align 8
  %p377 = inttoptr i64 %v376 to ptr
  %v378 = load i32, ptr %slot67, align 8
  %call379 = call i32 @myl_qbe_rc_status(ptr %p377, i32 %v378) nomerge, !dbg !112
  store i32 %call379, ptr %slot68, align 8
  br label %bb_failure
bb_rcsuccess60:
  br label %bb_rcgdone46
bb_rcgplain46:
  %v380 = load i64, ptr %slot53, align 8
  %v381 = load i64, ptr %slot51, align 8
  %p382 = inttoptr i64 %v381 to ptr
  store i64 %v380, ptr %p382, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone46
bb_rcgdone46:
  %v383 = load i64, ptr %slot8, align 8
  %p384 = inttoptr i64 %v383 to ptr
  store i32 1, ptr %p384, align 4, !alias.scope !3, !noalias !4
  %v385 = load i64, ptr %slot6, align 8
  %p386 = inttoptr i64 %v385 to ptr
  %ld387 = load i32, ptr %p386, align 4, !alias.scope !3, !noalias !4
  store i32 %ld387, ptr %slot69, align 8
  %v388 = load i32, ptr %slot69, align 8
  %cv389 = zext i32 %v388 to i64
  %cond390 = icmp ne i64 %cv389, 0
  br i1 %cond390, label %bb_rcslotdrop67, label %bb_rcslotdone67
bb_rcslotdrop67:
  %v391 = load i64, ptr %slot6, align 8
  %p392 = inttoptr i64 %v391 to ptr
  store i32 0, ptr %p392, align 4, !alias.scope !3, !noalias !4
  %v393 = load i64, ptr %slot10, align 8
  store i64 %v393, ptr %slot70, align 8
  %v394 = load i64, ptr %slot7, align 8
  %p395 = inttoptr i64 %v394 to ptr
  %ld396 = load i32, ptr %p395, align 4, !alias.scope !3, !noalias !4
  store i32 %ld396, ptr %slot71, align 8
  %v397 = load i32, ptr %slot71, align 8
  %op398 = and i32 %v397, 28
  store i32 %op398, ptr %slot72, align 8
  %v399 = load i32, ptr %slot72, align 8
  %cv400 = zext i32 %v399 to i64
  %cond401 = icmp ne i64 %cv400, 0
  br i1 %cond401, label %bb_rcslotrole67, label %bb_rcslotowner67
bb_rcslotrole67:
  %v402 = load i64, ptr %slot18, align 8
  store i64 %v402, ptr %slot73, align 8
  %v403 = load i64, ptr %slot70, align 8
  %p404 = inttoptr i64 %v403 to ptr
  %ld405 = load i64, ptr %p404, align 8, !alias.scope !3, !noalias !4
  store i64 %ld405, ptr %slot74, align 8
  %v406 = load i64, ptr %slot74, align 8
  %cmp407 = icmp ne i64 %v406, 0
  %cv408 = zext i1 %cmp407 to i32
  store i32 %cv408, ptr %slot75, align 8
  %v409 = load i32, ptr %slot75, align 8
  %cv410 = zext i32 %v409 to i64
  %cond411 = icmp ne i64 %cv410, 0
  br i1 %cond411, label %bb_rcgnn83, label %bb_rcgdone83
bb_rcgnn83:
  %v412 = load i64, ptr %slot74, align 8
  %op413 = sub i64 %v412, 16
  store i64 %op413, ptr %slot76, align 8
  %v414 = load i64, ptr %slot74, align 8
  %p415 = inttoptr i64 %v414 to ptr
  %rgep416 = getelementptr i8, ptr %p415, i64 -16
  %ld417 = load i64, ptr %rgep416, align 8, !alias.scope !9, !noalias !10
  store i64 %ld417, ptr %slot77, align 8
  %v418 = load i64, ptr %slot77, align 8
  %op419 = and i64 %v418, 4611686018427387906
  store i64 %op419, ptr %slot78, align 8
  %v420 = load i64, ptr %slot78, align 8
  %cmp421 = icmp ne i64 %v420, 0
  %cv422 = zext i1 %cmp421 to i32
  store i32 %cv422, ptr %slot79, align 8
  %v423 = load i32, ptr %slot79, align 8
  %cv424 = zext i32 %v423 to i64
  %cond425 = icmp ne i64 %cv424, 0
  br i1 %cond425, label %bb_rcgclear83, label %bb_rcgcounted83
bb_rcgcounted83:
  %v426 = load i64, ptr %slot74, align 8
  %op427 = sub i64 %v426, 24
  store i64 %op427, ptr %slot80, align 8
  %v428 = load i64, ptr %slot74, align 8
  %p429 = inttoptr i64 %v428 to ptr
  %rgep430 = getelementptr i8, ptr %p429, i64 -24
  %ld431 = load i64, ptr %rgep430, align 8, !alias.scope !9, !noalias !10
  store i64 %ld431, ptr %slot81, align 8
  %v432 = load i64, ptr %slot81, align 8
  %op433 = sub i64 %v432, 1
  store i64 %op433, ptr %slot82, align 8
  %v434 = load i64, ptr %slot82, align 8
  %cmp435 = icmp eq i64 %v434, 0
  %cv436 = zext i1 %cmp435 to i32
  store i32 %cv436, ptr %slot83, align 8
  %v437 = load i32, ptr %slot83, align 8
  %cv438 = zext i32 %v437 to i64
  %cond439 = icmp ne i64 %cv438, 0
  br i1 %cond439, label %bb_rcglast83, label %bb_rcgdec83
bb_rcglast83:
  %v440 = load i64, ptr %slot74, align 8
  %op441 = sub i64 %v440, 32
  store i64 %op441, ptr %slot84, align 8
  %v442 = load i64, ptr %slot74, align 8
  %p443 = inttoptr i64 %v442 to ptr
  %rgep444 = getelementptr i8, ptr %p443, i64 -32
  %ld445 = load i64, ptr %rgep444, align 8, !alias.scope !9, !noalias !10
  store i64 %ld445, ptr %slot85, align 8
  %v446 = load i64, ptr %slot85, align 8
  %cmp447 = icmp ne i64 %v446, 0
  %cv448 = zext i1 %cmp447 to i32
  store i32 %cv448, ptr %slot86, align 8
  %v449 = load i32, ptr %slot86, align 8
  %cv450 = zext i32 %v449 to i64
  %cond451 = icmp ne i64 %cv450, 0
  br i1 %cond451, label %bb_rcgdec83, label %bb_rcgslow83
bb_rcgslow83:
  %v452 = load i64, ptr %slot73, align 8
  %v453 = load i64, ptr %slot70, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64 %v452, i64 %v453) nomerge, !dbg !112
  br label %bb_rcgdone83
bb_rcgdec83:
  %v454 = load i64, ptr %slot82, align 8
  %v455 = load i64, ptr %slot74, align 8
  %p456 = inttoptr i64 %v455 to ptr
  %rgep457 = getelementptr i8, ptr %p456, i64 -24
  store i64 %v454, ptr %rgep457, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear83
bb_rcgclear83:
  %v458 = load i64, ptr %slot70, align 8
  %p459 = inttoptr i64 %v458 to ptr
  store i64 0, ptr %p459, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone83
bb_rcgdone83:
  br label %bb_rcslotdone67
bb_rcslotowner67:
  %v460 = load i64, ptr %slot18, align 8
  store i64 %v460, ptr %slot87, align 8
  %v461 = load i64, ptr %slot70, align 8
  %p462 = inttoptr i64 %v461 to ptr
  %ld463 = load i64, ptr %p462, align 8, !alias.scope !3, !noalias !4
  store i64 %ld463, ptr %slot88, align 8
  %v464 = load i64, ptr %slot88, align 8
  %cmp465 = icmp ne i64 %v464, 0
  %cv466 = zext i1 %cmp465 to i32
  store i32 %cv466, ptr %slot89, align 8
  %v467 = load i32, ptr %slot89, align 8
  %cv468 = zext i32 %v467 to i64
  %cond469 = icmp ne i64 %cv468, 0
  br i1 %cond469, label %bb_rcgnn98, label %bb_rcgdone98
bb_rcgnn98:
  %v470 = load i64, ptr %slot88, align 8
  %op471 = sub i64 %v470, 16
  store i64 %op471, ptr %slot90, align 8
  %v472 = load i64, ptr %slot88, align 8
  %p473 = inttoptr i64 %v472 to ptr
  %rgep474 = getelementptr i8, ptr %p473, i64 -16
  %ld475 = load i64, ptr %rgep474, align 8, !alias.scope !9, !noalias !10
  store i64 %ld475, ptr %slot91, align 8
  %v476 = load i64, ptr %slot91, align 8
  %op477 = and i64 %v476, 4611686018427387906
  store i64 %op477, ptr %slot92, align 8
  %v478 = load i64, ptr %slot92, align 8
  %cmp479 = icmp ne i64 %v478, 0
  %cv480 = zext i1 %cmp479 to i32
  store i32 %cv480, ptr %slot93, align 8
  %v481 = load i32, ptr %slot93, align 8
  %cv482 = zext i32 %v481 to i64
  %cond483 = icmp ne i64 %cv482, 0
  br i1 %cond483, label %bb_rcgclear98, label %bb_rcgcounted98
bb_rcgcounted98:
  %v484 = load i64, ptr %slot88, align 8
  %op485 = sub i64 %v484, 32
  store i64 %op485, ptr %slot94, align 8
  %v486 = load i64, ptr %slot88, align 8
  %p487 = inttoptr i64 %v486 to ptr
  %rgep488 = getelementptr i8, ptr %p487, i64 -32
  %ld489 = load i64, ptr %rgep488, align 8, !alias.scope !9, !noalias !10
  store i64 %ld489, ptr %slot95, align 8
  %v490 = load i64, ptr %slot95, align 8
  %op491 = sub i64 %v490, 1
  store i64 %op491, ptr %slot96, align 8
  %v492 = load i64, ptr %slot96, align 8
  %cmp493 = icmp eq i64 %v492, 0
  %cv494 = zext i1 %cmp493 to i32
  store i32 %cv494, ptr %slot97, align 8
  %v495 = load i32, ptr %slot97, align 8
  %cv496 = zext i32 %v495 to i64
  %cond497 = icmp ne i64 %cv496, 0
  br i1 %cond497, label %bb_rcglast98, label %bb_rcgdec98
bb_rcglast98:
  %v498 = load i64, ptr %slot88, align 8
  %op499 = sub i64 %v498, 24
  store i64 %op499, ptr %slot98, align 8
  %v500 = load i64, ptr %slot88, align 8
  %p501 = inttoptr i64 %v500 to ptr
  %rgep502 = getelementptr i8, ptr %p501, i64 -24
  %ld503 = load i64, ptr %rgep502, align 8, !alias.scope !9, !noalias !10
  store i64 %ld503, ptr %slot99, align 8
  %v504 = load i64, ptr %slot99, align 8
  %cmp505 = icmp ne i64 %v504, 0
  %cv506 = zext i1 %cmp505 to i32
  store i32 %cv506, ptr %slot100, align 8
  %v507 = load i32, ptr %slot100, align 8
  %cv508 = zext i32 %v507 to i64
  %cond509 = icmp ne i64 %cv508, 0
  br i1 %cond509, label %bb_rcgdec98, label %bb_rcgslow98
bb_rcgslow98:
  %v510 = load i64, ptr %slot87, align 8
  %v511 = load i64, ptr %slot70, align 8
  call void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64 %v510, i64 %v511) nomerge, !dbg !112
  br label %bb_rcgdone98
bb_rcgdec98:
  %v512 = load i64, ptr %slot96, align 8
  %v513 = load i64, ptr %slot88, align 8
  %p514 = inttoptr i64 %v513 to ptr
  %rgep515 = getelementptr i8, ptr %p514, i64 -32
  store i64 %v512, ptr %rgep515, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear98
bb_rcgclear98:
  %v516 = load i64, ptr %slot70, align 8
  %p517 = inttoptr i64 %v516 to ptr
  store i64 0, ptr %p517, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone98
bb_rcgdone98:
  br label %bb_rcslotdone67
bb_rcslotdone67:
  br label %bb_rcprepared13
bb_rcprepared13:
  %v518 = load i64, ptr %slot12, align 8
  store i64 %v518, ptr %slot101, align 8
  %v519 = load i64, ptr %slot101, align 8
  %v520 = load i64, ptr %slot27, align 8
  %p521 = inttoptr i64 %v519 to ptr
  %p522 = inttoptr i64 %v520 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p522, ptr %p521, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v523 = load i64, ptr %slot8, align 8
  %p524 = inttoptr i64 %v523 to ptr
  store i32 0, ptr %p524, align 4, !alias.scope !3, !noalias !4
  %v525 = load i64, ptr %slot16, align 8
  store i64 %v525, ptr %slot102, align 8
  %v526 = load i64, ptr %slot22, align 8
  %p528 = inttoptr i64 %v526 to ptr
  %gep529 = getelementptr i8, ptr %p528, i64 8
  %op527 = ptrtoint ptr %gep529 to i64
  store i64 %op527, ptr %slot103, align 8
  %v530 = load i64, ptr %slot102, align 8
  %p531 = inttoptr i64 %v530 to ptr
  %ld532 = load i64, ptr %p531, align 8, !alias.scope !3, !noalias !4
  store i64 %ld532, ptr %slot104, align 8
  %v533 = load i64, ptr %slot104, align 8
  %v534 = load i64, ptr %slot103, align 8
  %p535 = inttoptr i64 %v534 to ptr
  store i64 %v533, ptr %p535, align 8, !alias.scope !3, !noalias !4
  %v536 = load i64, ptr %slot22, align 8
  %v537 = load i64, ptr %slot15, align 8
  %p538 = inttoptr i64 %v537 to ptr
  store i64 %v536, ptr %p538, align 8, !alias.scope !3, !noalias !4
  %v539 = load i64, ptr %slot15, align 8
  %p540 = inttoptr i64 %v539 to ptr
  %ld541 = load i64, ptr %p540, align 8, !alias.scope !3, !noalias !4
  store i64 %ld541, ptr %slot105, align 8
  %v542 = load i64, ptr %slot10, align 8
  store i64 %v542, ptr %slot106, align 8
  %v543 = load i64, ptr %slot105, align 8
  %v544 = load i64, ptr %slot106, align 8
  %p545 = inttoptr i64 %v543 to ptr
  %p546 = inttoptr i64 %v544 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p546, ptr %p545, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v547 = load i64, ptr %slot7, align 8
  %p548 = inttoptr i64 %v547 to ptr
  store i32 2, ptr %p548, align 4, !alias.scope !3, !noalias !4
  %v549 = load i64, ptr %slot6, align 8
  %p550 = inttoptr i64 %v549 to ptr
  store i32 1, ptr %p550, align 4, !alias.scope !3, !noalias !4
  %v551 = load i64, ptr %slot106, align 8
  %v552 = load i64, ptr %slot15, align 8
  %p553 = inttoptr i64 %v552 to ptr
  store i64 %v551, ptr %p553, align 8, !alias.scope !3, !noalias !4
  %v554 = load i64, ptr %slot15, align 8
  %p555 = inttoptr i64 %v554 to ptr
  %ld556 = load i64, ptr %p555, align 8, !alias.scope !3, !noalias !4
  store i64 %ld556, ptr %slot107, align 8
  %v557 = load i64, ptr %slot15, align 8
  %p558 = inttoptr i64 %v557 to ptr
  %ld559 = load i64, ptr %p558, align 8, !alias.scope !3, !noalias !4
  store i64 %ld559, ptr %slot108, align 8
  %v560 = load i64, ptr %slot12, align 8
  store i64 %v560, ptr %slot109, align 8
  %v561 = load i64, ptr %slot19, align 8
  store i64 %v561, ptr %slot110, align 8
  %v562 = load i64, ptr %slot108, align 8
  %op563 = add i64 %v562, 0
  store i64 %op563, ptr %slot111, align 8
  %v564 = load i64, ptr %slot111, align 8
  %p565 = inttoptr i64 %v564 to ptr
  %ld566 = load i64, ptr %p565, align 8, !alias.scope !3, !noalias !4
  store i64 %ld566, ptr %slot112, align 8
  %v567 = load i64, ptr %slot112, align 8
  %cmp568 = icmp ne i64 %v567, 0
  %cv569 = zext i1 %cmp568 to i32
  store i32 %cv569, ptr %slot113, align 8
  %v570 = load i32, ptr %slot113, align 8
  %cv571 = zext i32 %v570 to i64
  %cond572 = icmp ne i64 %cv571, 0
  br i1 %cond572, label %bb_rcmoveheader118, label %bb_rcmovenext118
bb_rcmoveheader118:
  %v573 = load i64, ptr %slot112, align 8
  %op574 = sub i64 %v573, 16
  store i64 %op574, ptr %slot114, align 8
  %v575 = load i64, ptr %slot112, align 8
  %p576 = inttoptr i64 %v575 to ptr
  %rgep577 = getelementptr i8, ptr %p576, i64 -16
  %ld578 = load i64, ptr %rgep577, align 8, !alias.scope !9, !noalias !10
  store i64 %ld578, ptr %slot115, align 8
  %v579 = load i64, ptr %slot115, align 8
  %op580 = and i64 %v579, 5764607523034234881
  store i64 %op580, ptr %slot116, align 8
  %v581 = load i64, ptr %slot116, align 8
  %cmp582 = icmp ne i64 %v581, 0
  %cv583 = zext i1 %cmp582 to i32
  store i32 %cv583, ptr %slot117, align 8
  %v584 = load i32, ptr %slot117, align 8
  %cv585 = zext i32 %v584 to i64
  %cond586 = icmp ne i64 %cv585, 0
  br i1 %cond586, label %bb_rcmoveslow115, label %bb_rcmovenext118
bb_rcmovenext118:
  %v587 = load i64, ptr %slot108, align 8
  %v588 = load i64, ptr %slot109, align 8
  %p589 = inttoptr i64 %v587 to ptr
  %p590 = inttoptr i64 %v588 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p590, ptr %p589, i64 16, i1 false), !alias.scope !3, !noalias !4
  %v591 = load i64, ptr %slot108, align 8
  %p592 = inttoptr i64 %v591 to ptr
  store i64 0, ptr %p592, align 8, !alias.scope !3, !noalias !4
  %v593 = load i64, ptr %slot108, align 8
  %op594 = add i64 %v593, 8
  store i64 %op594, ptr %slot118, align 8
  %v595 = load i64, ptr %slot118, align 8
  %p596 = inttoptr i64 %v595 to ptr
  store i64 0, ptr %p596, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved115
bb_rcmoveslow115:
  %v597 = load i64, ptr %slot18, align 8
  %v598 = load i64, ptr %slot109, align 8
  %v599 = load i64, ptr %slot108, align 8
  %v600 = load i64, ptr %slot110, align 8
  %cv601 = trunc i64 %v600 to i32
  %call602 = call i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64 %v597, i64 %v598, i64 %v599, i32 %cv601) nomerge, !dbg !114
  store i32 %call602, ptr %slot119, align 8
  %v603 = load i32, ptr %slot119, align 8
  %cv604 = zext i32 %v603 to i64
  %cond605 = icmp ne i64 %cv604, 0
  br i1 %cond605, label %bb_rcsuccess126, label %bb_rcfailure126
bb_rcfailure126:
  %v606 = load i64, ptr %slot18, align 8
  %p607 = inttoptr i64 %v606 to ptr
  %call608 = call i32 @myl_rc_take_failure(ptr %p607) nomerge, !dbg !114
  store i32 %call608, ptr %slot120, align 8
  %v609 = load i64, ptr %slot1, align 8
  %p610 = inttoptr i64 %v609 to ptr
  %v611 = load i32, ptr %slot120, align 8
  %call612 = call i32 @myl_qbe_rc_status(ptr %p610, i32 %v611) nomerge, !dbg !114
  store i32 %call612, ptr %slot121, align 8
  br label %bb_failure
bb_rcsuccess126:
  br label %bb_rcmoved115
bb_rcmoved115:
  %v613 = load i64, ptr %slot6, align 8
  %p614 = inttoptr i64 %v613 to ptr
  store i32 0, ptr %p614, align 4, !alias.scope !3, !noalias !4
  %v615 = load i64, ptr %slot8, align 8
  %p616 = inttoptr i64 %v615 to ptr
  store i32 1, ptr %p616, align 4, !alias.scope !3, !noalias !4
  %v617 = load i64, ptr %slot12, align 8
  store i64 %v617, ptr %slot122, align 8
  %v618 = load i64, ptr %slot8, align 8
  %p619 = inttoptr i64 %v618 to ptr
  store i32 0, ptr %p619, align 4, !alias.scope !3, !noalias !4
  %v620 = load i64, ptr %slot6, align 8
  %p621 = inttoptr i64 %v620 to ptr
  %ld622 = load i32, ptr %p621, align 4, !alias.scope !3, !noalias !4
  store i32 %ld622, ptr %slot123, align 8
  %v623 = load i32, ptr %slot123, align 8
  %cv624 = zext i32 %v623 to i64
  %cond625 = icmp ne i64 %cv624, 0
  br i1 %cond625, label %bb_rcslotdrop136, label %bb_rcslotdone136
bb_rcslotdrop136:
  %v626 = load i64, ptr %slot6, align 8
  %p627 = inttoptr i64 %v626 to ptr
  store i32 0, ptr %p627, align 4, !alias.scope !3, !noalias !4
  %v628 = load i64, ptr %slot10, align 8
  store i64 %v628, ptr %slot124, align 8
  %v629 = load i64, ptr %slot7, align 8
  %p630 = inttoptr i64 %v629 to ptr
  %ld631 = load i32, ptr %p630, align 4, !alias.scope !3, !noalias !4
  store i32 %ld631, ptr %slot125, align 8
  %v632 = load i32, ptr %slot125, align 8
  %op633 = and i32 %v632, 28
  store i32 %op633, ptr %slot126, align 8
  %v634 = load i32, ptr %slot126, align 8
  %cv635 = zext i32 %v634 to i64
  %cond636 = icmp ne i64 %cv635, 0
  br i1 %cond636, label %bb_rcslotrole136, label %bb_rcslotowner136
bb_rcslotrole136:
  %v637 = load i64, ptr %slot18, align 8
  store i64 %v637, ptr %slot127, align 8
  %v638 = load i64, ptr %slot127, align 8
  %v639 = load i64, ptr %slot124, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64 %v638, i64 %v639) nomerge, !dbg !114
  br label %bb_rcslotdone136
bb_rcslotowner136:
  %v640 = load i64, ptr %slot18, align 8
  store i64 %v640, ptr %slot128, align 8
  %v641 = load i64, ptr %slot128, align 8
  %v642 = load i64, ptr %slot124, align 8
  call void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64 %v641, i64 %v642) nomerge, !dbg !114
  br label %bb_rcslotdone136
bb_rcslotdone136:
  %v643 = load i64, ptr %slot122, align 8
  %p644 = inttoptr i64 %v643 to ptr
  %ret645 = load { i64, i64 }, ptr %p644, align 8
  ret { i64, i64 } %ret645
bb_failure:
  %v646 = load i64, ptr %slot5, align 8
  %p647 = inttoptr i64 %v646 to ptr
  call void @llvm.memset.p0.i64(ptr %p647, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v648 = load i64, ptr %slot5, align 8
  %p649 = inttoptr i64 %v648 to ptr
  %ret650 = load { i64, i64 }, ptr %p649, align 8
  ret { i64, i64 } %ret650
bb_entry_failure:
  %v651 = load i64, ptr %slot5, align 8
  %p652 = inttoptr i64 %v651 to ptr
  call void @llvm.memset.p0.i64(ptr %p652, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !114
  %v653 = load i64, ptr %slot5, align 8
  %p654 = inttoptr i64 %v653 to ptr
  %ret655 = load { i64, i64 }, ptr %p654, align 8
  ret { i64, i64 } %ret655
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_drop(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_unloan(i64, i64)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_drop(i64, i64)
declare i32 @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_take(i64, i64, i64, i32)
declare void @myl_t_d2b6ba0786a9e08aacf8d0a6addb6e83692a65ffe726a74bc3ded41db969c0ff_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb", linkageName: "myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11591240376405130126, i64 0, !"myl_f_8c062ec4784d4b0491e6d5d24da0bf886cc822f390794d94cd35c159749aceeb"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!110 = !DILocation(line: 1, column: 0, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646559)
!112 = !DILocation(line: 3, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!114 = !DILocation(line: 4, column: 0, scope: !115)
