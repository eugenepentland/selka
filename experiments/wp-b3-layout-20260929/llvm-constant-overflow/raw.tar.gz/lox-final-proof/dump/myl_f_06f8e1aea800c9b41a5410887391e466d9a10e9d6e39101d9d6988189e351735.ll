target triple = "x86_64-unknown-linux-gnu"

define dllexport { i64, i64 } @myl_f_06f8e1aea800c9b41a5410887391e466d9a10e9d6e39101d9d6988189e351735(i64 %p_ctx, i64 %p_a0) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  %v32 = load i64, ptr %slot1, align 8
  %op33 = add i64 %v32, 32
  store i64 %op33, ptr %slot3, align 8
  %mem34 = alloca i8, i64 16, align 8
  %ptr35 = ptrtoint ptr %mem34 to i64
  store i64 %ptr35, ptr %slot4, align 8
  %mem36 = alloca i8, i64 8, align 8
  %ptr37 = ptrtoint ptr %mem36 to i64
  store i64 %ptr37, ptr %slot5, align 8
  %mem38 = alloca i8, i64 8, align 8
  %ptr39 = ptrtoint ptr %mem38 to i64
  store i64 %ptr39, ptr %slot6, align 8
  %mem40 = alloca i8, i64 8, align 8
  %ptr41 = ptrtoint ptr %mem40 to i64
  store i64 %ptr41, ptr %slot7, align 8
  %mem42 = alloca i8, i64 16, align 8
  %ptr43 = ptrtoint ptr %mem42 to i64
  store i64 %ptr43, ptr %slot8, align 8
  %mem44 = alloca i8, i64 16, align 8
  %ptr45 = ptrtoint ptr %mem44 to i64
  store i64 %ptr45, ptr %slot9, align 8
  %mem46 = alloca i8, i64 16, align 8
  %ptr47 = ptrtoint ptr %mem46 to i64
  store i64 %ptr47, ptr %slot10, align 8
  %mem48 = alloca i8, i64 16, align 8
  %ptr49 = ptrtoint ptr %mem48 to i64
  store i64 %ptr49, ptr %slot11, align 8
  %v50 = load i64, ptr %slot2, align 8
  %v51 = load i64, ptr %slot5, align 8
  %p52 = inttoptr i64 %v51 to ptr
  store i64 %v50, ptr %p52, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v53 = load i64, ptr %slot5, align 8
  %p54 = inttoptr i64 %v53 to ptr
  %ld55 = load i64, ptr %p54, align 8, !alias.scope !3, !noalias !4
  store i64 %ld55, ptr %slot12, align 8
  %v56 = load i64, ptr %slot12, align 8
  %v57 = load i64, ptr %slot7, align 8
  %p58 = inttoptr i64 %v57 to ptr
  store i64 %v56, ptr %p58, align 8, !alias.scope !3, !noalias !4
  %v59 = load i64, ptr %slot7, align 8
  %p60 = inttoptr i64 %v59 to ptr
  %ld61 = load i64, ptr %p60, align 8, !alias.scope !3, !noalias !4
  store i64 %ld61, ptr %slot13, align 8
  %v62 = load i64, ptr %slot13, align 8
  %p63 = inttoptr i64 %v62 to ptr
  %ld64 = load i32, ptr %p63, align 4, !alias.scope !4, !noalias !3
  %ext65 = zext i32 %ld64 to i64
  store i64 %ext65, ptr %slot14, align 8
  %v66 = load i64, ptr %slot14, align 8
  %cmp67 = icmp eq i64 %v66, 0
  %cv68 = zext i1 %cmp67 to i64
  store i64 %cv68, ptr %slot15, align 8
  %v69 = load i64, ptr %slot15, align 8
  %cond70 = icmp ne i64 %v69, 0
  br i1 %cond70, label %bb_arm3, label %bb_armnext3
bb_arm3:
  br label %bb_i5
bb_armnext3:
  %v71 = load i64, ptr %slot14, align 8
  %cmp72 = icmp eq i64 %v71, 1
  %cv73 = zext i1 %cmp72 to i64
  store i64 %cv73, ptr %slot16, align 8
  %v74 = load i64, ptr %slot16, align 8
  %cond75 = icmp ne i64 %v74, 0
  br i1 %cond75, label %bb_arm4, label %bb_armnext4
bb_arm4:
  br label %bb_i7
bb_armnext4:
  %v76 = load i64, ptr %slot14, align 8
  %cmp77 = icmp eq i64 %v76, 2
  %cv78 = zext i1 %cmp77 to i64
  store i64 %cv78, ptr %slot17, align 8
  %v79 = load i64, ptr %slot17, align 8
  %cond80 = icmp ne i64 %v79, 0
  br i1 %cond80, label %bb_arm5, label %bb_armnext5
bb_arm5:
  %v81 = load i64, ptr %slot13, align 8
  %op82 = add i64 %v81, 8
  store i64 %op82, ptr %slot18, align 8
  %v83 = load i64, ptr %slot18, align 8
  %p84 = inttoptr i64 %v83 to ptr
  %ld85 = load i64, ptr %p84, align 8, !alias.scope !4, !noalias !3
  store i64 %ld85, ptr %slot19, align 8
  %v86 = load i64, ptr %slot19, align 8
  %v87 = load i64, ptr %slot6, align 8
  %p88 = inttoptr i64 %v87 to ptr
  store i64 %v86, ptr %p88, align 8, !alias.scope !3, !noalias !4
  br label %bb_i2
bb_armnext5:
  %v89 = load i64, ptr %slot14, align 8
  %cmp90 = icmp eq i64 %v89, 3
  %cv91 = zext i1 %cmp90 to i64
  store i64 %cv91, ptr %slot20, align 8
  %v92 = load i64, ptr %slot20, align 8
  %cond93 = icmp ne i64 %v92, 0
  br i1 %cond93, label %bb_arm8, label %bb_armnext8
bb_arm8:
  br label %bb_i9
bb_armnext8:
  br label %bb_failure
bb_i2:
  %v94 = load i64, ptr %slot6, align 8
  %p95 = inttoptr i64 %v94 to ptr
  %ld96 = load i64, ptr %p95, align 8, !alias.scope !3, !noalias !4
  store i64 %ld96, ptr %slot21, align 8
  %v97 = load i64, ptr %slot21, align 8
  %v98 = load i64, ptr %slot7, align 8
  %p99 = inttoptr i64 %v98 to ptr
  store i64 %v97, ptr %p99, align 8, !alias.scope !3, !noalias !4
  %v100 = load i64, ptr %slot8, align 8
  store i64 %v100, ptr %slot22, align 8
  %v101 = load i64, ptr %slot22, align 8
  %p102 = inttoptr i64 %v101 to ptr
  store i32 1, ptr %p102, align 4, !alias.scope !3, !noalias !4
  %v103 = load i64, ptr %slot22, align 8
  %p105 = inttoptr i64 %v103 to ptr
  %gep106 = getelementptr i8, ptr %p105, i64 8
  %op104 = ptrtoint ptr %gep106 to i64
  store i64 %op104, ptr %slot23, align 8
  %v107 = load i64, ptr %slot7, align 8
  %p108 = inttoptr i64 %v107 to ptr
  %ld109 = load i64, ptr %p108, align 8, !alias.scope !3, !noalias !4
  store i64 %ld109, ptr %slot24, align 8
  %v110 = load i64, ptr %slot24, align 8
  %v111 = load i64, ptr %slot23, align 8
  %p112 = inttoptr i64 %v111 to ptr
  store i64 %v110, ptr %p112, align 8, !alias.scope !3, !noalias !4
  %v113 = load i64, ptr %slot22, align 8
  %v114 = load i64, ptr %slot7, align 8
  %p115 = inttoptr i64 %v114 to ptr
  store i64 %v113, ptr %p115, align 8, !alias.scope !3, !noalias !4
  %v116 = load i64, ptr %slot7, align 8
  %p117 = inttoptr i64 %v116 to ptr
  %ld118 = load i64, ptr %p117, align 8, !alias.scope !3, !noalias !4
  store i64 %ld118, ptr %slot25, align 8
  %v119 = load i64, ptr %slot25, align 8
  %p120 = inttoptr i64 %v119 to ptr
  %ret121 = load { i64, i64 }, ptr %p120, align 8
  ret { i64, i64 } %ret121
bb_i5:
  %v122 = load i64, ptr %slot9, align 8
  store i64 %v122, ptr %slot26, align 8
  %v123 = load i64, ptr %slot26, align 8
  %p124 = inttoptr i64 %v123 to ptr
  store i32 0, ptr %p124, align 4, !alias.scope !3, !noalias !4
  %v125 = load i64, ptr %slot26, align 8
  %v126 = load i64, ptr %slot7, align 8
  %p127 = inttoptr i64 %v126 to ptr
  store i64 %v125, ptr %p127, align 8, !alias.scope !3, !noalias !4
  %v128 = load i64, ptr %slot7, align 8
  %p129 = inttoptr i64 %v128 to ptr
  %ld130 = load i64, ptr %p129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld130, ptr %slot27, align 8
  %v131 = load i64, ptr %slot27, align 8
  %p132 = inttoptr i64 %v131 to ptr
  %ret133 = load { i64, i64 }, ptr %p132, align 8
  ret { i64, i64 } %ret133
bb_i7:
  %v134 = load i64, ptr %slot10, align 8
  store i64 %v134, ptr %slot28, align 8
  %v135 = load i64, ptr %slot28, align 8
  %p136 = inttoptr i64 %v135 to ptr
  store i32 0, ptr %p136, align 4, !alias.scope !3, !noalias !4
  %v137 = load i64, ptr %slot28, align 8
  %v138 = load i64, ptr %slot7, align 8
  %p139 = inttoptr i64 %v138 to ptr
  store i64 %v137, ptr %p139, align 8, !alias.scope !3, !noalias !4
  %v140 = load i64, ptr %slot7, align 8
  %p141 = inttoptr i64 %v140 to ptr
  %ld142 = load i64, ptr %p141, align 8, !alias.scope !3, !noalias !4
  store i64 %ld142, ptr %slot29, align 8
  %v143 = load i64, ptr %slot29, align 8
  %p144 = inttoptr i64 %v143 to ptr
  %ret145 = load { i64, i64 }, ptr %p144, align 8
  ret { i64, i64 } %ret145
bb_i9:
  %v146 = load i64, ptr %slot11, align 8
  store i64 %v146, ptr %slot30, align 8
  %v147 = load i64, ptr %slot30, align 8
  %p148 = inttoptr i64 %v147 to ptr
  store i32 0, ptr %p148, align 4, !alias.scope !3, !noalias !4
  %v149 = load i64, ptr %slot30, align 8
  %v150 = load i64, ptr %slot7, align 8
  %p151 = inttoptr i64 %v150 to ptr
  store i64 %v149, ptr %p151, align 8, !alias.scope !3, !noalias !4
  %v152 = load i64, ptr %slot7, align 8
  %p153 = inttoptr i64 %v152 to ptr
  %ld154 = load i64, ptr %p153, align 8, !alias.scope !3, !noalias !4
  store i64 %ld154, ptr %slot31, align 8
  %v155 = load i64, ptr %slot31, align 8
  %p156 = inttoptr i64 %v155 to ptr
  %ret157 = load { i64, i64 }, ptr %p156, align 8
  ret { i64, i64 } %ret157
bb_failure:
  %v158 = load i64, ptr %slot4, align 8
  %p159 = inttoptr i64 %v158 to ptr
  call void @llvm.memset.p0.i64(ptr %p159, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v160 = load i64, ptr %slot4, align 8
  %p161 = inttoptr i64 %v160 to ptr
  %ret162 = load { i64, i64 }, ptr %p161, align 8
  ret { i64, i64 } %ret162
bb_entry_failure:
  %v163 = load i64, ptr %slot4, align 8
  %p164 = inttoptr i64 %v163 to ptr
  call void @llvm.memset.p0.i64(ptr %p164, i8 0, i64 16, i1 false), !alias.scope !3, !noalias !4, !dbg !110
  %v165 = load i64, ptr %slot4, align 8
  %p166 = inttoptr i64 %v165 to ptr
  %ret167 = load { i64, i64 }, ptr %p166, align 8
  ret { i64, i64 } %ret167
}

declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_06f8e1aea800c9b41a5410887391e466d9a10e9d6e39101d9d6988189e351735", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_06f8e1aea800c9b41a5410887391e466d9a10e9d6e39101d9d6988189e351735", linkageName: "myl_f_06f8e1aea800c9b41a5410887391e466d9a10e9d6e39101d9d6988189e351735", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 15179236959541742401, i64 0, !"myl_f_06f8e1aea800c9b41a5410887391e466d9a10e9d6e39101d9d6988189e351735"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646623)
!110 = !DILocation(line: 11, column: 0, scope: !111)
