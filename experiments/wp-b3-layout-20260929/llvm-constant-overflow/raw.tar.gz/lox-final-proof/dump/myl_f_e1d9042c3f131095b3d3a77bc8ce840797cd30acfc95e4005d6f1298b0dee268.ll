target triple = "x86_64-unknown-linux-gnu"

define dllexport i64 @myl_f_e1d9042c3f131095b3d3a77bc8ce840797cd30acfc95e4005d6f1298b0dee268(i64 %p_ctx, i64 %p_a0, i64 %p_a1) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  %v41 = load i64, ptr %slot1, align 8
  %op42 = add i64 %v41, 32
  store i64 %op42, ptr %slot4, align 8
  %mem43 = alloca i8, i64 8, align 8
  %ptr44 = ptrtoint ptr %mem43 to i64
  store i64 %ptr44, ptr %slot5, align 8
  %mem45 = alloca i8, i64 8, align 8
  %ptr46 = ptrtoint ptr %mem45 to i64
  store i64 %ptr46, ptr %slot6, align 8
  %mem47 = alloca i8, i64 8, align 8
  %ptr48 = ptrtoint ptr %mem47 to i64
  store i64 %ptr48, ptr %slot7, align 8
  %mem49 = alloca i8, i64 8, align 8
  %ptr50 = ptrtoint ptr %mem49 to i64
  store i64 %ptr50, ptr %slot8, align 8
  %mem51 = alloca i8, i64 8, align 8
  %ptr52 = ptrtoint ptr %mem51 to i64
  store i64 %ptr52, ptr %slot9, align 8
  %mem53 = alloca i8, i64 8, align 8
  %ptr54 = ptrtoint ptr %mem53 to i64
  store i64 %ptr54, ptr %slot10, align 8
  br label %bb_frameadmit0
bb_frameadmit0:
  %mem55 = alloca i8, i64 8, align 8
  %ptr56 = ptrtoint ptr %mem55 to i64
  store i64 %ptr56, ptr %slot11, align 8
  %v57 = load i64, ptr %slot1, align 8
  %op58 = add i64 %v57, 64
  store i64 %op58, ptr %slot12, align 8
  %v59 = load i64, ptr %slot12, align 8
  %p60 = inttoptr i64 %v59 to ptr
  %ld61 = load i64, ptr %p60, align 8, !alias.scope !4, !noalias !3
  store i64 %ld61, ptr %slot13, align 8
  %stack62 = call ptr @llvm.stacksave()
  %stackaddr63 = ptrtoint ptr %stack62 to i64
  %v64 = load i64, ptr %slot13, align 8
  %cmp65 = icmp ult i64 %stackaddr63, %v64
  %cv66 = zext i1 %cmp65 to i64
  store i64 %cv66, ptr %slot14, align 8
  %v67 = load i64, ptr %slot14, align 8
  %cond68 = icmp ne i64 %v67, 0
  br i1 %cond68, label %bb_floorfail2, label %bb_stackadmit1
bb_floorfail2:
  %v69 = load i64, ptr %slot1, align 8
  %p70 = inttoptr i64 %v69 to ptr
  call void @myl_qbe_fail_frame(ptr %p70) nomerge, !dbg !110
  unreachable
bb_stackadmit1:
  %v71 = load i64, ptr %slot2, align 8
  %v72 = load i64, ptr %slot5, align 8
  %p73 = inttoptr i64 %v72 to ptr
  store i64 %v71, ptr %p73, align 8, !alias.scope !3, !noalias !4
  %v74 = load i64, ptr %slot3, align 8
  %v75 = load i64, ptr %slot6, align 8
  %p76 = inttoptr i64 %v75 to ptr
  store i64 %v74, ptr %p76, align 8, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v77 = load i64, ptr %slot5, align 8
  %p78 = inttoptr i64 %v77 to ptr
  %ld79 = load i64, ptr %p78, align 8, !alias.scope !3, !noalias !4
  store i64 %ld79, ptr %slot15, align 8
  %v80 = load i64, ptr %slot15, align 8
  %v81 = load i64, ptr %slot9, align 8
  %p82 = inttoptr i64 %v81 to ptr
  store i64 %v80, ptr %p82, align 8, !alias.scope !3, !noalias !4
  %v83 = load i64, ptr %slot9, align 8
  %p84 = inttoptr i64 %v83 to ptr
  %ld85 = load i64, ptr %p84, align 8, !alias.scope !3, !noalias !4
  store i64 %ld85, ptr %slot16, align 8
  %v86 = load i64, ptr %slot16, align 8
  %op87 = add i64 %v86, 168
  store i64 %op87, ptr %slot17, align 8
  %v88 = load i64, ptr %slot17, align 8
  %p89 = inttoptr i64 %v88 to ptr
  %ld90 = load i64, ptr %p89, align 8, !alias.scope !4, !noalias !3
  store i64 %ld90, ptr %slot18, align 8
  %v91 = load i64, ptr %slot18, align 8
  %v92 = load i64, ptr %slot9, align 8
  %p93 = inttoptr i64 %v92 to ptr
  store i64 %v91, ptr %p93, align 8, !alias.scope !3, !noalias !4
  %v94 = load i64, ptr %slot9, align 8
  %p95 = inttoptr i64 %v94 to ptr
  %ld96 = load i64, ptr %p95, align 8, !alias.scope !3, !noalias !4
  store i64 %ld96, ptr %slot19, align 8
  %v97 = load i64, ptr %slot19, align 8
  %v98 = load i64, ptr %slot7, align 8
  %p99 = inttoptr i64 %v98 to ptr
  store i64 %v97, ptr %p99, align 8, !alias.scope !3, !noalias !4
  %v100 = load i64, ptr %slot9, align 8
  %p101 = inttoptr i64 %v100 to ptr
  store i64 0, ptr %p101, align 8, !alias.scope !3, !noalias !4
  %v102 = load i64, ptr %slot9, align 8
  %p103 = inttoptr i64 %v102 to ptr
  %ld104 = load i64, ptr %p103, align 8, !alias.scope !3, !noalias !4
  store i64 %ld104, ptr %slot20, align 8
  %v105 = load i64, ptr %slot20, align 8
  %v106 = load i64, ptr %slot8, align 8
  %p107 = inttoptr i64 %v106 to ptr
  store i64 %v105, ptr %p107, align 8, !alias.scope !3, !noalias !4
  br label %bb_i5
bb_i5:
  %v108 = load i64, ptr %slot8, align 8
  %p109 = inttoptr i64 %v108 to ptr
  %ld110 = load i64, ptr %p109, align 8, !alias.scope !3, !noalias !4
  store i64 %ld110, ptr %slot21, align 8
  %v111 = load i64, ptr %slot21, align 8
  %v112 = load i64, ptr %slot9, align 8
  %p113 = inttoptr i64 %v112 to ptr
  store i64 %v111, ptr %p113, align 8, !alias.scope !3, !noalias !4
  %v114 = load i64, ptr %slot6, align 8
  %p115 = inttoptr i64 %v114 to ptr
  %ld116 = load i64, ptr %p115, align 8, !alias.scope !3, !noalias !4
  store i64 %ld116, ptr %slot22, align 8
  %v117 = load i64, ptr %slot22, align 8
  %v118 = load i64, ptr %slot10, align 8
  %p119 = inttoptr i64 %v118 to ptr
  store i64 %v117, ptr %p119, align 8, !alias.scope !3, !noalias !4
  %v120 = load i64, ptr %slot10, align 8
  %p121 = inttoptr i64 %v120 to ptr
  %ld122 = load i64, ptr %p121, align 8, !alias.scope !3, !noalias !4
  store i64 %ld122, ptr %slot23, align 8
  %v123 = load i64, ptr %slot9, align 8
  %p124 = inttoptr i64 %v123 to ptr
  %ld125 = load i64, ptr %p124, align 8, !alias.scope !3, !noalias !4
  store i64 %ld125, ptr %slot24, align 8
  %v126 = load i64, ptr %slot24, align 8
  %v127 = load i64, ptr %slot23, align 8
  %cmp128 = icmp slt i64 %v126, %v127
  %cv129 = zext i1 %cmp128 to i64
  store i64 %cv129, ptr %slot25, align 8
  %v130 = load i64, ptr %slot25, align 8
  %v131 = load i64, ptr %slot9, align 8
  %p132 = inttoptr i64 %v131 to ptr
  store i64 %v130, ptr %p132, align 8, !alias.scope !3, !noalias !4
  %v133 = load i64, ptr %slot9, align 8
  %p134 = inttoptr i64 %v133 to ptr
  %ld135 = load i64, ptr %p134, align 8, !alias.scope !3, !noalias !4
  store i64 %ld135, ptr %slot26, align 8
  %v136 = load i64, ptr %slot26, align 8
  %cond137 = icmp ne i64 %v136, 0
  br i1 %cond137, label %bb_next29, label %bb_i18
bb_next29:
  %v138 = load i64, ptr %slot5, align 8
  %p139 = inttoptr i64 %v138 to ptr
  %ld140 = load i64, ptr %p139, align 8, !alias.scope !3, !noalias !4
  store i64 %ld140, ptr %slot27, align 8
  %v141 = load i64, ptr %slot27, align 8
  %v142 = load i64, ptr %slot9, align 8
  %p143 = inttoptr i64 %v142 to ptr
  store i64 %v141, ptr %p143, align 8, !alias.scope !3, !noalias !4
  %v144 = load i64, ptr %slot7, align 8
  %p145 = inttoptr i64 %v144 to ptr
  %ld146 = load i64, ptr %p145, align 8, !alias.scope !3, !noalias !4
  store i64 %ld146, ptr %slot28, align 8
  %v147 = load i64, ptr %slot28, align 8
  %v148 = load i64, ptr %slot10, align 8
  %p149 = inttoptr i64 %v148 to ptr
  store i64 %v147, ptr %p149, align 8, !alias.scope !3, !noalias !4
  %v150 = load i64, ptr %slot9, align 8
  %p151 = inttoptr i64 %v150 to ptr
  %ld152 = load i64, ptr %p151, align 8, !alias.scope !3, !noalias !4
  store i64 %ld152, ptr %slot29, align 8
  %v153 = load i64, ptr %slot10, align 8
  %p154 = inttoptr i64 %v153 to ptr
  %ld155 = load i64, ptr %p154, align 8, !alias.scope !3, !noalias !4
  store i64 %ld155, ptr %slot30, align 8
  %v156 = load i64, ptr %slot1, align 8
  %v157 = load i64, ptr %slot29, align 8
  %v158 = load i64, ptr %slot30, align 8
  %call159 = call i64 @myl_f_fdb523ec01e35cd778f4be0e6c347a068eabe5bde5c603156e498b663acc6468(i64 %v156, i64 %v157, i64 %v158) nomerge, !dbg !112
  store i64 %call159, ptr %slot31, align 8
  %v160 = load i64, ptr %slot31, align 8
  %v161 = load i64, ptr %slot9, align 8
  %p162 = inttoptr i64 %v161 to ptr
  store i64 %v160, ptr %p162, align 8, !alias.scope !3, !noalias !4
  %v163 = load i64, ptr %slot9, align 8
  %p164 = inttoptr i64 %v163 to ptr
  %ld165 = load i64, ptr %p164, align 8, !alias.scope !3, !noalias !4
  store i64 %ld165, ptr %slot32, align 8
  %v166 = load i64, ptr %slot32, align 8
  %v167 = load i64, ptr %slot7, align 8
  %p168 = inttoptr i64 %v167 to ptr
  store i64 %v166, ptr %p168, align 8, !alias.scope !3, !noalias !4
  %v169 = load i64, ptr %slot8, align 8
  %p170 = inttoptr i64 %v169 to ptr
  %ld171 = load i64, ptr %p170, align 8, !alias.scope !3, !noalias !4
  store i64 %ld171, ptr %slot33, align 8
  %v172 = load i64, ptr %slot33, align 8
  %v173 = load i64, ptr %slot9, align 8
  %p174 = inttoptr i64 %v173 to ptr
  store i64 %v172, ptr %p174, align 8, !alias.scope !3, !noalias !4
  %v175 = load i64, ptr %slot10, align 8
  %p176 = inttoptr i64 %v175 to ptr
  store i64 1, ptr %p176, align 8, !alias.scope !3, !noalias !4
  %v177 = load i64, ptr %slot10, align 8
  %p178 = inttoptr i64 %v177 to ptr
  %ld179 = load i64, ptr %p178, align 8, !alias.scope !3, !noalias !4
  store i64 %ld179, ptr %slot34, align 8
  %v180 = load i64, ptr %slot9, align 8
  %p181 = inttoptr i64 %v180 to ptr
  %ld182 = load i64, ptr %p181, align 8, !alias.scope !3, !noalias !4
  store i64 %ld182, ptr %slot35, align 8
  %v183 = load i64, ptr %slot35, align 8
  %v184 = load i64, ptr %slot34, align 8
  %ovpair186 = call { i64, i1 } @llvm.sadd.with.overflow.i64(i64 %v183, i64 %v184)
  %op185 = extractvalue { i64, i1 } %ovpair186, 0
  %ov187 = extractvalue { i64, i1 } %ovpair186, 1
  store i64 %op185, ptr %slot36, align 8
  %cv188 = zext i1 %ov187 to i64
  store i64 %cv188, ptr %slot37, align 8
  %v189 = load i64, ptr %slot37, align 8
  %cond190 = icmp ne i64 %v189, 0
  br i1 %cond190, label %bb_overflow47, label %bb_checked47
bb_overflow47:
  %v191 = load i64, ptr %slot1, align 8
  %p192 = inttoptr i64 %v191 to ptr
  %v193 = load i64, ptr %slot35, align 8
  %v194 = load i64, ptr %slot34, align 8
  call void @myl_qbe_fail_overflow_op(ptr %p192, i64 0, i64 %v193, i64 %v194, i64 64) nomerge, !dbg !114
  unreachable
bb_checked47:
  %v195 = load i64, ptr %slot36, align 8
  %v196 = load i64, ptr %slot9, align 8
  %p197 = inttoptr i64 %v196 to ptr
  store i64 %v195, ptr %p197, align 8, !alias.scope !3, !noalias !4
  %v198 = load i64, ptr %slot9, align 8
  %p199 = inttoptr i64 %v198 to ptr
  %ld200 = load i64, ptr %p199, align 8, !alias.scope !3, !noalias !4
  store i64 %ld200, ptr %slot38, align 8
  %v201 = load i64, ptr %slot38, align 8
  %v202 = load i64, ptr %slot8, align 8
  %p203 = inttoptr i64 %v202 to ptr
  store i64 %v201, ptr %p203, align 8, !alias.scope !3, !noalias !4
  br label %bb_i5
bb_i18:
  %v204 = load i64, ptr %slot7, align 8
  %p205 = inttoptr i64 %v204 to ptr
  %ld206 = load i64, ptr %p205, align 8, !alias.scope !3, !noalias !4
  store i64 %ld206, ptr %slot39, align 8
  %v207 = load i64, ptr %slot39, align 8
  %v208 = load i64, ptr %slot9, align 8
  %p209 = inttoptr i64 %v208 to ptr
  store i64 %v207, ptr %p209, align 8, !alias.scope !3, !noalias !4
  %v210 = load i64, ptr %slot9, align 8
  %p211 = inttoptr i64 %v210 to ptr
  %ld212 = load i64, ptr %p211, align 8, !alias.scope !3, !noalias !4
  store i64 %ld212, ptr %slot40, align 8
  %v213 = load i64, ptr %slot40, align 8
  ret i64 %v213
bb_failure:
  ret i64 0
bb_entry_failure:
  ret i64 0
}

declare { i64, i1 } @llvm.sadd.with.overflow.i64(i64, i64)
declare ptr @llvm.stacksave()
declare i64 @myl_f_fdb523ec01e35cd778f4be0e6c347a068eabe5bde5c603156e498b663acc6468(i64, i64, i64)
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_overflow_op(ptr, i64, i64, i64, i64) noreturn cold

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_e1d9042c3f131095b3d3a77bc8ce840797cd30acfc95e4005d6f1298b0dee268", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_e1d9042c3f131095b3d3a77bc8ce840797cd30acfc95e4005d6f1298b0dee268", linkageName: "myl_f_e1d9042c3f131095b3d3a77bc8ce840797cd30acfc95e4005d6f1298b0dee268", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 11817102293774628155, i64 0, !"myl_f_e1d9042c3f131095b3d3a77bc8ce840797cd30acfc95e4005d6f1298b0dee268"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646631)
!112 = !DILocation(line: 12, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646663)
!114 = !DILocation(line: 16, column: 0, scope: !115)
