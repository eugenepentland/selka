target triple = "x86_64-unknown-linux-gnu"

define dllexport void @myl_f_079424de52d5f48cd51b17cd049217cb3528df1db52f5fe4c6f03a85ac2d8020(ptr sret([40 x i8]) align 8 %p_sret, i64 %p_ctx, i64 %p_a0, i64 %p_a1, i64 %p_a2) #0 !dbg !101 {
bb_entry:
  %slot1 = alloca i64, align 8
  %slot2 = alloca i64, align 8
  %slot3 = alloca i64, align 8
  %slot4 = alloca i64, align 8
  %slot5 = alloca i64, align 8
  %slot6 = alloca i64, align 8
  %slot7 = alloca i64, align 8
  %slot8 = alloca i64, align 8
  %slot9 = alloca i64, align 8
  %slot10 = alloca i64, align 8
  %slot11 = alloca i64, align 8
  %slot12 = alloca i64, align 8
  %slot13 = alloca i64, align 8
  %slot14 = alloca i64, align 8
  %slot15 = alloca i64, align 8
  %slot16 = alloca i64, align 8
  %slot17 = alloca i64, align 8
  %slot18 = alloca i64, align 8
  %slot19 = alloca i64, align 8
  %slot20 = alloca i64, align 8
  %slot21 = alloca i64, align 8
  %slot22 = alloca i64, align 8
  %slot23 = alloca i64, align 8
  %slot24 = alloca i64, align 8
  %slot25 = alloca i64, align 8
  %slot26 = alloca i64, align 8
  %slot27 = alloca i64, align 8
  %slot28 = alloca i64, align 8
  %slot29 = alloca i64, align 8
  %slot30 = alloca i64, align 8
  %slot31 = alloca i64, align 8
  %slot32 = alloca i64, align 8
  %slot33 = alloca i64, align 8
  %slot34 = alloca i64, align 8
  %slot35 = alloca i64, align 8
  %slot36 = alloca i64, align 8
  %slot37 = alloca i64, align 8
  %slot38 = alloca i64, align 8
  %slot39 = alloca i64, align 8
  %slot40 = alloca i64, align 8
  %slot41 = alloca i64, align 8
  %slot42 = alloca i64, align 8
  %slot43 = alloca i64, align 8
  %slot44 = alloca i64, align 8
  %slot45 = alloca i64, align 8
  %slot46 = alloca i64, align 8
  %slot47 = alloca i64, align 8
  %slot48 = alloca i64, align 8
  %slot49 = alloca i64, align 8
  %slot50 = alloca i64, align 8
  %slot51 = alloca i64, align 8
  %slot52 = alloca i64, align 8
  %slot53 = alloca i64, align 8
  %slot54 = alloca i64, align 8
  %slot55 = alloca i64, align 8
  %slot56 = alloca i64, align 8
  %slot57 = alloca i64, align 8
  %slot58 = alloca i64, align 8
  %slot59 = alloca i64, align 8
  %slot60 = alloca i32, align 8
  %slot61 = alloca i32, align 8
  %slot62 = alloca i32, align 8
  %slot63 = alloca i32, align 8
  %slot64 = alloca i64, align 8
  %slot65 = alloca i32, align 8
  %slot66 = alloca i32, align 8
  %slot67 = alloca i64, align 8
  %slot68 = alloca i32, align 8
  %slot69 = alloca i32, align 8
  %slot70 = alloca i32, align 8
  %slot71 = alloca i32, align 8
  %slot72 = alloca i64, align 8
  %slot73 = alloca i32, align 8
  %slot74 = alloca i32, align 8
  %slot75 = alloca i64, align 8
  %slot76 = alloca i64, align 8
  %slot77 = alloca i64, align 8
  %slot78 = alloca i64, align 8
  %slot79 = alloca i32, align 8
  %slot80 = alloca i64, align 8
  %slot81 = alloca i64, align 8
  %slot82 = alloca i32, align 8
  %slot83 = alloca i32, align 8
  %slot84 = alloca i32, align 8
  %slot85 = alloca i32, align 8
  %slot86 = alloca i64, align 8
  %slot87 = alloca i32, align 8
  %slot88 = alloca i32, align 8
  %slot89 = alloca i64, align 8
  %slot90 = alloca i32, align 8
  %slot91 = alloca i32, align 8
  %slot92 = alloca i32, align 8
  %slot93 = alloca i32, align 8
  %slot94 = alloca i64, align 8
  %slot95 = alloca i32, align 8
  %slot96 = alloca i32, align 8
  %slot97 = alloca i64, align 8
  %slot98 = alloca i64, align 8
  %slot99 = alloca i64, align 8
  %slot100 = alloca i64, align 8
  %slot101 = alloca i32, align 8
  %slot102 = alloca i64, align 8
  %slot103 = alloca i64, align 8
  %slot104 = alloca i64, align 8
  %slot105 = alloca i64, align 8
  %slot106 = alloca i64, align 8
  %slot107 = alloca i64, align 8
  %slot108 = alloca i64, align 8
  %slot109 = alloca i64, align 8
  %slot110 = alloca i64, align 8
  %slot111 = alloca i32, align 8
  %slot112 = alloca i64, align 8
  %slot113 = alloca i64, align 8
  %slot114 = alloca i64, align 8
  %slot115 = alloca i32, align 8
  %slot116 = alloca i32, align 8
  %slot117 = alloca i32, align 8
  %slot118 = alloca i32, align 8
  %slot119 = alloca i64, align 8
  %slot120 = alloca i64, align 8
  %slot121 = alloca i64, align 8
  %slot122 = alloca i64, align 8
  %slot123 = alloca i32, align 8
  %slot124 = alloca i32, align 8
  %slot125 = alloca i32, align 8
  %slot126 = alloca i64, align 8
  %slot127 = alloca i64, align 8
  %slot128 = alloca i32, align 8
  %slot129 = alloca i64, align 8
  %slot130 = alloca i64, align 8
  %slot131 = alloca i64, align 8
  %slot132 = alloca i32, align 8
  %slot133 = alloca i32, align 8
  %slot134 = alloca i32, align 8
  %slot135 = alloca i32, align 8
  %slot136 = alloca i32, align 8
  %slot137 = alloca i32, align 8
  %slot138 = alloca i32, align 8
  %slot139 = alloca i64, align 8
  %slot140 = alloca i64, align 8
  %slot141 = alloca i64, align 8
  %slot142 = alloca i32, align 8
  %slot143 = alloca i64, align 8
  %slot144 = alloca i64, align 8
  %slot145 = alloca i64, align 8
  %slot146 = alloca i32, align 8
  %slot147 = alloca i64, align 8
  %slot148 = alloca i64, align 8
  %slot149 = alloca i64, align 8
  %slot150 = alloca i32, align 8
  %slot151 = alloca i32, align 8
  %slot152 = alloca i32, align 8
  %slot153 = alloca i64, align 8
  %slot154 = alloca i32, align 8
  %slot155 = alloca i32, align 8
  %slot156 = alloca i64, align 8
  %slot157 = alloca i64, align 8
  %slot158 = alloca i32, align 8
  %slot159 = alloca i64, align 8
  %slot160 = alloca i64, align 8
  %slot161 = alloca i64, align 8
  %slot162 = alloca i32, align 8
  %slot163 = alloca i64, align 8
  %slot164 = alloca i64, align 8
  %slot165 = alloca i64, align 8
  %slot166 = alloca i32, align 8
  %slot167 = alloca i64, align 8
  %slot168 = alloca i64, align 8
  %slot169 = alloca i32, align 8
  %slot170 = alloca i64, align 8
  %slot171 = alloca i64, align 8
  %slot172 = alloca i32, align 8
  %slot173 = alloca i64, align 8
  %slot174 = alloca i64, align 8
  %slot175 = alloca i64, align 8
  %slot176 = alloca i32, align 8
  %slot177 = alloca i64, align 8
  %slot178 = alloca i64, align 8
  %slot179 = alloca i64, align 8
  %slot180 = alloca i32, align 8
  %slot181 = alloca i64, align 8
  %slot182 = alloca i64, align 8
  %slot183 = alloca i32, align 8
  %slot184 = alloca i32, align 8
  %slot185 = alloca i64, align 8
  %slot186 = alloca i32, align 8
  %slot187 = alloca i32, align 8
  %slot188 = alloca i64, align 8
  %slot189 = alloca i64, align 8
  %slot190 = alloca i32, align 8
  %slot191 = alloca i64, align 8
  %slot192 = alloca i64, align 8
  %slot193 = alloca i64, align 8
  %slot194 = alloca i32, align 8
  %slot195 = alloca i64, align 8
  %slot196 = alloca i64, align 8
  %slot197 = alloca i64, align 8
  %slot198 = alloca i32, align 8
  %slot199 = alloca i64, align 8
  %slot200 = alloca i64, align 8
  %slot201 = alloca i32, align 8
  %slot202 = alloca i64, align 8
  %slot203 = alloca i64, align 8
  %slot204 = alloca i32, align 8
  %slot205 = alloca i64, align 8
  %slot206 = alloca i64, align 8
  %slot207 = alloca i64, align 8
  %slot208 = alloca i32, align 8
  %slot209 = alloca i64, align 8
  %slot210 = alloca i64, align 8
  %slot211 = alloca i64, align 8
  %slot212 = alloca i32, align 8
  %slot213 = alloca i64, align 8
  %slot214 = alloca i64, align 8
  %slot215 = alloca i32, align 8
  %slot216 = alloca i64, align 8
  %slot217 = alloca i64, align 8
  %slot218 = alloca i32, align 8
  %slot219 = alloca i64, align 8
  %slot220 = alloca i64, align 8
  %callresult221 = alloca [32 x i8], align 8
  %slot222 = alloca i64, align 8
  %slot223 = alloca i64, align 8
  %slot224 = alloca i64, align 8
  %slot225 = alloca i64, align 8
  %slot226 = alloca i32, align 8
  %slot227 = alloca i64, align 8
  %slot228 = alloca i64, align 8
  %slot229 = alloca i64, align 8
  %slot230 = alloca i64, align 8
  %slot231 = alloca i64, align 8
  %slot232 = alloca i32, align 8
  %slot233 = alloca i32, align 8
  %slot234 = alloca i32, align 8
  %slot235 = alloca i32, align 8
  %slot236 = alloca i64, align 8
  %slot237 = alloca i64, align 8
  %slot238 = alloca i32, align 8
  %slot239 = alloca i32, align 8
  %slot240 = alloca i32, align 8
  %slot241 = alloca i64, align 8
  %slot242 = alloca i64, align 8
  %slot243 = alloca i32, align 8
  %slot244 = alloca i32, align 8
  %slot245 = alloca i32, align 8
  %slot246 = alloca i32, align 8
  %slot247 = alloca i64, align 8
  %slot248 = alloca i32, align 8
  %slot249 = alloca i32, align 8
  %slot250 = alloca i64, align 8
  %slot251 = alloca i64, align 8
  %slot252 = alloca i64, align 8
  %slot253 = alloca i64, align 8
  %slot254 = alloca i64, align 8
  %slot255 = alloca i64, align 8
  %slot256 = alloca i32, align 8
  %slot257 = alloca i32, align 8
  %slot258 = alloca i32, align 8
  %slot259 = alloca i32, align 8
  %slot260 = alloca i64, align 8
  %slot261 = alloca i64, align 8
  %slot262 = alloca i64, align 8
  %slot263 = alloca i64, align 8
  %slot264 = alloca i32, align 8
  %slot265 = alloca i32, align 8
  %slot266 = alloca i32, align 8
  %slot267 = alloca i64, align 8
  %slot268 = alloca i64, align 8
  %slot269 = alloca i32, align 8
  %slot270 = alloca i64, align 8
  %slot271 = alloca i64, align 8
  %slot272 = alloca i64, align 8
  %slot273 = alloca i32, align 8
  %slot274 = alloca i64, align 8
  %slot275 = alloca i64, align 8
  %slot276 = alloca i32, align 8
  %slot277 = alloca i64, align 8
  %slot278 = alloca i64, align 8
  %slot279 = alloca i64, align 8
  %slot280 = alloca i32, align 8
  %slot281 = alloca i64, align 8
  %slot282 = alloca i64, align 8
  %slot283 = alloca i64, align 8
  %slot284 = alloca i64, align 8
  %slot285 = alloca i32, align 8
  %slot286 = alloca i32, align 8
  %slot287 = alloca i32, align 8
  %slot288 = alloca i64, align 8
  %slot289 = alloca i64, align 8
  %slot290 = alloca i32, align 8
  %slot291 = alloca i32, align 8
  %slot292 = alloca i32, align 8
  %slot293 = alloca i32, align 8
  %slot294 = alloca i64, align 8
  %slot295 = alloca i32, align 8
  %slot296 = alloca i32, align 8
  %slot297 = alloca i64, align 8
  %slot298 = alloca i64, align 8
  %slot299 = alloca i64, align 8
  %slot300 = alloca i64, align 8
  %slot301 = alloca i64, align 8
  %slot302 = alloca i64, align 8
  %slot303 = alloca i64, align 8
  %slot304 = alloca i64, align 8
  %slot305 = alloca i32, align 8
  %slot306 = alloca i32, align 8
  %slot307 = alloca i32, align 8
  %slot308 = alloca i32, align 8
  %slot309 = alloca i64, align 8
  %slot310 = alloca i64, align 8
  %slot311 = alloca i64, align 8
  %slot312 = alloca i64, align 8
  %slot313 = alloca i32, align 8
  %slot314 = alloca i32, align 8
  %slot315 = alloca i32, align 8
  %slot316 = alloca i64, align 8
  %slot317 = alloca i64, align 8
  %slot318 = alloca i32, align 8
  %slot319 = alloca i64, align 8
  %slot320 = alloca i64, align 8
  %slot321 = alloca i64, align 8
  %slot322 = alloca i32, align 8
  %slot323 = alloca i32, align 8
  %slot324 = alloca i32, align 8
  %slot325 = alloca i32, align 8
  %slot326 = alloca i64, align 8
  %slot327 = alloca i64, align 8
  %slot328 = alloca i64, align 8
  %slot329 = alloca i32, align 8
  %slot330 = alloca i64, align 8
  %slot331 = alloca i64, align 8
  %slot332 = alloca i64, align 8
  %slot333 = alloca i32, align 8
  %slot334 = alloca i64, align 8
  %slot335 = alloca i64, align 8
  %slot336 = alloca i64, align 8
  %slot337 = alloca i32, align 8
  %slot338 = alloca i32, align 8
  %slot339 = alloca i64, align 8
  %slot340 = alloca i32, align 8
  %slot341 = alloca i32, align 8
  %slot342 = alloca i32, align 8
  %slot343 = alloca i32, align 8
  %slot344 = alloca i64, align 8
  %slot345 = alloca i64, align 8
  %slot346 = alloca i64, align 8
  %slot347 = alloca i64, align 8
  %slot348 = alloca i64, align 8
  %slot349 = alloca i64, align 8
  %slot350 = alloca i32, align 8
  %slot351 = alloca i32, align 8
  %slot352 = alloca i32, align 8
  %slot353 = alloca i32, align 8
  %slot354 = alloca i64, align 8
  %slot355 = alloca i64, align 8
  %slot356 = alloca i64, align 8
  %slot357 = alloca i64, align 8
  %slot358 = alloca i32, align 8
  %slot359 = alloca i32, align 8
  %slot360 = alloca i32, align 8
  %slot361 = alloca i64, align 8
  %slot362 = alloca i64, align 8
  %slot363 = alloca i32, align 8
  %slot364 = alloca i64, align 8
  %slot365 = alloca i64, align 8
  %slot366 = alloca i64, align 8
  %slot367 = alloca i32, align 8
  %slot368 = alloca i32, align 8
  %slot369 = alloca i32, align 8
  %slot370 = alloca i32, align 8
  %slot371 = alloca i64, align 8
  %slot372 = alloca i64, align 8
  %slot373 = alloca i64, align 8
  %slot374 = alloca i32, align 8
  %slot375 = alloca i64, align 8
  %slot376 = alloca i64, align 8
  %slot377 = alloca i64, align 8
  %slot378 = alloca i32, align 8
  %slot379 = alloca i64, align 8
  %slot380 = alloca i64, align 8
  %slot381 = alloca i64, align 8
  %slot382 = alloca i32, align 8
  %slot383 = alloca i32, align 8
  %slot384 = alloca i64, align 8
  %slot385 = alloca i32, align 8
  %slot386 = alloca i32, align 8
  %slot387 = alloca i32, align 8
  %slot388 = alloca i32, align 8
  %slot389 = alloca i32, align 8
  %slot390 = alloca i64, align 8
  %slot391 = alloca i32, align 8
  %slot392 = alloca i32, align 8
  %slot393 = alloca i64, align 8
  %slot394 = alloca i64, align 8
  %slot395 = alloca i32, align 8
  %slot396 = alloca i64, align 8
  %slot397 = alloca i64, align 8
  %slot398 = alloca i64, align 8
  %slot399 = alloca i32, align 8
  %slot400 = alloca i64, align 8
  %slot401 = alloca i64, align 8
  %slot402 = alloca i64, align 8
  %slot403 = alloca i32, align 8
  %slot404 = alloca i64, align 8
  %slot405 = alloca i64, align 8
  %slot406 = alloca i32, align 8
  %slot407 = alloca i64, align 8
  %slot408 = alloca i64, align 8
  %slot409 = alloca i32, align 8
  %slot410 = alloca i64, align 8
  %slot411 = alloca i64, align 8
  %slot412 = alloca i64, align 8
  %slot413 = alloca i32, align 8
  %slot414 = alloca i64, align 8
  %slot415 = alloca i64, align 8
  %slot416 = alloca i64, align 8
  %slot417 = alloca i32, align 8
  %slot418 = alloca i64, align 8
  %slot419 = alloca i64, align 8
  %slot420 = alloca i32, align 8
  %slot421 = alloca i64, align 8
  %slot422 = alloca i64, align 8
  %slot423 = alloca i64, align 8
  %slot424 = alloca i64, align 8
  %slot425 = alloca i64, align 8
  %slot426 = alloca i64, align 8
  %slot427 = alloca i64, align 8
  %slot428 = alloca i64, align 8
  %slot429 = alloca i64, align 8
  %slot430 = alloca i64, align 8
  %slot431 = alloca i64, align 8
  %slot432 = alloca i64, align 8
  %slot433 = alloca i64, align 8
  %slot434 = alloca i64, align 8
  %slot435 = alloca i32, align 8
  %slot436 = alloca i64, align 8
  %slot437 = alloca i64, align 8
  %slot438 = alloca i64, align 8
  %slot439 = alloca i32, align 8
  %slot440 = alloca i64, align 8
  %slot441 = alloca i64, align 8
  %slot442 = alloca i32, align 8
  %slot443 = alloca i64, align 8
  %slot444 = alloca i64, align 8
  %slot445 = alloca i64, align 8
  %slot446 = alloca i32, align 8
  %slot447 = alloca i64, align 8
  %slot448 = alloca i64, align 8
  %slot449 = alloca i32, align 8
  %slot450 = alloca i64, align 8
  %slot451 = alloca i64, align 8
  %slot452 = alloca i64, align 8
  %slot453 = alloca i32, align 8
  %slot454 = alloca i64, align 8
  %slot455 = alloca i64, align 8
  %slot456 = alloca i32, align 8
  %slot457 = alloca i64, align 8
  %slot458 = alloca i64, align 8
  %slot459 = alloca i64, align 8
  %slot460 = alloca i32, align 8
  %slot461 = alloca i64, align 8
  %slot462 = alloca i64, align 8
  %slot463 = alloca i64, align 8
  %slot464 = alloca i32, align 8
  %slot465 = alloca i32, align 8
  %slot466 = alloca i32, align 8
  %slot467 = alloca i64, align 8
  %slot468 = alloca i64, align 8
  %slot469 = alloca i64, align 8
  %slot470 = alloca i64, align 8
  %slot471 = alloca i64, align 8
  %slot472 = alloca i64, align 8
  %slot473 = alloca i32, align 8
  %slot474 = alloca i32, align 8
  %slot475 = alloca i32, align 8
  %slot476 = alloca i32, align 8
  %slot477 = alloca i64, align 8
  %slot478 = alloca i32, align 8
  %slot479 = alloca i32, align 8
  %slot480 = alloca i64, align 8
  %slot481 = alloca i64, align 8
  %slot482 = alloca i64, align 8
  %slot483 = alloca i64, align 8
  %slot484 = alloca i32, align 8
  %slot485 = alloca i32, align 8
  %slot486 = alloca i64, align 8
  %slot487 = alloca i32, align 8
  %slot488 = alloca i32, align 8
  %slot489 = alloca i64, align 8
  %slot490 = alloca i64, align 8
  %slot491 = alloca i32, align 8
  %slot492 = alloca i64, align 8
  %slot493 = alloca i64, align 8
  %slot494 = alloca i64, align 8
  %slot495 = alloca i32, align 8
  %slot496 = alloca i64, align 8
  %slot497 = alloca i64, align 8
  %slot498 = alloca i64, align 8
  %slot499 = alloca i32, align 8
  %slot500 = alloca i64, align 8
  %slot501 = alloca i64, align 8
  %slot502 = alloca i32, align 8
  %slot503 = alloca i64, align 8
  %slot504 = alloca i64, align 8
  %slot505 = alloca i32, align 8
  %slot506 = alloca i64, align 8
  %slot507 = alloca i64, align 8
  %slot508 = alloca i64, align 8
  %slot509 = alloca i32, align 8
  %slot510 = alloca i64, align 8
  %slot511 = alloca i64, align 8
  %slot512 = alloca i64, align 8
  %slot513 = alloca i32, align 8
  %slot514 = alloca i64, align 8
  %slot515 = alloca i64, align 8
  %slot516 = alloca i32, align 8
  %slot517 = alloca i64, align 8
  %slot518 = alloca i64, align 8
  %slot519 = alloca i32, align 8
  %slot520 = alloca i64, align 8
  %slot521 = alloca i32, align 8
  %slot522 = alloca i32, align 8
  %slot523 = alloca i64, align 8
  %slot524 = alloca i64, align 8
  %slot525 = alloca i64, align 8
  %slot526 = alloca i64, align 8
  %slot527 = alloca i32, align 8
  %slot528 = alloca i64, align 8
  %slot529 = alloca i32, align 8
  %slot530 = alloca i32, align 8
  %slot531 = alloca i64, align 8
  %slot532 = alloca i64, align 8
  %slot533 = alloca i64, align 8
  %slot534 = alloca i64, align 8
  %slot535 = alloca i64, align 8
  %slot536 = alloca i64, align 8
  %slot537 = alloca i64, align 8
  %callresult538 = alloca [16 x i8], align 8
  %slot539 = alloca i32, align 8
  %slot540 = alloca i64, align 8
  %slot541 = alloca i32, align 8
  %slot542 = alloca i32, align 8
  %slot543 = alloca i64, align 8
  %slot544 = alloca i64, align 8
  %slot545 = alloca i64, align 8
  %slot546 = alloca i64, align 8
  %slot547 = alloca i64, align 8
  %slot548 = alloca i64, align 8
  %slot549 = alloca i64, align 8
  %slot550 = alloca i64, align 8
  %slot551 = alloca i64, align 8
  %slot552 = alloca i64, align 8
  %slot553 = alloca i64, align 8
  %slot554 = alloca i64, align 8
  %slot555 = alloca i64, align 8
  %slot556 = alloca i32, align 8
  %slot557 = alloca i64, align 8
  %slot558 = alloca i32, align 8
  %slot559 = alloca i32, align 8
  %slot560 = alloca i64, align 8
  %slot561 = alloca i64, align 8
  %slot562 = alloca i64, align 8
  %slot563 = alloca i64, align 8
  %slot564 = alloca i64, align 8
  %slot565 = alloca i64, align 8
  %slot566 = alloca i64, align 8
  %slot567 = alloca i64, align 8
  %slot568 = alloca i64, align 8
  %slot569 = alloca i32, align 8
  %slot570 = alloca i64, align 8
  %slot571 = alloca i64, align 8
  %slot572 = alloca i64, align 8
  %slot573 = alloca i32, align 8
  %slot574 = alloca i64, align 8
  %slot575 = alloca i64, align 8
  %slot576 = alloca i64, align 8
  %slot577 = alloca i32, align 8
  %slot578 = alloca i32, align 8
  %slot579 = alloca i32, align 8
  %slot580 = alloca i64, align 8
  %slot581 = alloca i32, align 8
  %slot582 = alloca i32, align 8
  %slot583 = alloca i64, align 8
  %slot584 = alloca i64, align 8
  %slot585 = alloca i64, align 8
  %slot586 = alloca i64, align 8
  %slot587 = alloca i32, align 8
  %slot588 = alloca i64, align 8
  %slot589 = alloca i64, align 8
  %slot590 = alloca i64, align 8
  %slot591 = alloca i32, align 8
  %slot592 = alloca i64, align 8
  %slot593 = alloca i32, align 8
  %slot594 = alloca i32, align 8
  %slot595 = alloca i64, align 8
  %slot596 = alloca i64, align 8
  %slot597 = alloca i32, align 8
  %slot598 = alloca i64, align 8
  %slot599 = alloca i64, align 8
  %slot600 = alloca i64, align 8
  %slot601 = alloca i32, align 8
  %slot602 = alloca i64, align 8
  %slot603 = alloca i64, align 8
  %slot604 = alloca i64, align 8
  %slot605 = alloca i32, align 8
  %slot606 = alloca i64, align 8
  %slot607 = alloca i64, align 8
  %slot608 = alloca i32, align 8
  %slot609 = alloca i64, align 8
  %slot610 = alloca i64, align 8
  %slot611 = alloca i32, align 8
  %slot612 = alloca i64, align 8
  %slot613 = alloca i64, align 8
  %slot614 = alloca i64, align 8
  %slot615 = alloca i32, align 8
  %slot616 = alloca i64, align 8
  %slot617 = alloca i64, align 8
  %slot618 = alloca i64, align 8
  %slot619 = alloca i32, align 8
  %slot620 = alloca i64, align 8
  %slot621 = alloca i64, align 8
  %slot622 = alloca i32, align 8
  %slot623 = alloca i64, align 8
  %slot624 = alloca i64, align 8
  %slot625 = alloca i64, align 8
  %slot626 = alloca i64, align 8
  %slot627 = alloca i32, align 8
  %slot628 = alloca i64, align 8
  %slot629 = alloca i64, align 8
  %slot630 = alloca i64, align 8
  %slot631 = alloca i32, align 8
  %slot632 = alloca i64, align 8
  %slot633 = alloca i64, align 8
  %slot634 = alloca i32, align 8
  %slot635 = alloca i32, align 8
  %slot636 = alloca i64, align 8
  %slot637 = alloca i64, align 8
  %slot638 = alloca i32, align 8
  %slot639 = alloca i64, align 8
  %slot640 = alloca i32, align 8
  %slot641 = alloca i32, align 8
  %slot642 = alloca i64, align 8
  %slot643 = alloca i64, align 8
  %slot644 = alloca i32, align 8
  %slot645 = alloca i64, align 8
  %slot646 = alloca i64, align 8
  %slot647 = alloca i64, align 8
  %slot648 = alloca i32, align 8
  %slot649 = alloca i64, align 8
  %slot650 = alloca i64, align 8
  %slot651 = alloca i64, align 8
  %slot652 = alloca i32, align 8
  %slot653 = alloca i64, align 8
  %slot654 = alloca i64, align 8
  %slot655 = alloca i32, align 8
  %slot656 = alloca i64, align 8
  %slot657 = alloca i64, align 8
  %slot658 = alloca i32, align 8
  %slot659 = alloca i64, align 8
  %slot660 = alloca i64, align 8
  %slot661 = alloca i64, align 8
  %slot662 = alloca i32, align 8
  %slot663 = alloca i64, align 8
  %slot664 = alloca i64, align 8
  %slot665 = alloca i64, align 8
  %slot666 = alloca i32, align 8
  %slot667 = alloca i64, align 8
  %slot668 = alloca i64, align 8
  %slot669 = alloca i32, align 8
  %slot670 = alloca i64, align 8
  %slot671 = alloca i64, align 8
  %slot672 = alloca i64, align 8
  %slot673 = alloca i64, align 8
  %slot674 = alloca i64, align 8
  %slot675 = alloca i64, align 8
  %slot676 = alloca i64, align 8
  %slot677 = alloca i64, align 8
  %slot678 = alloca i64, align 8
  %slot679 = alloca i64, align 8
  %slot680 = alloca i32, align 8
  %slot681 = alloca i32, align 8
  %slot682 = alloca i64, align 8
  %slot683 = alloca i64, align 8
  %slot684 = alloca i64, align 8
  %slot685 = alloca i32, align 8
  %slot686 = alloca i64, align 8
  %slot687 = alloca i32, align 8
  %slot688 = alloca i64, align 8
  %slot689 = alloca i64, align 8
  %slot690 = alloca i64, align 8
  %slot691 = alloca i32, align 8
  %slot692 = alloca i64, align 8
  %slot693 = alloca i64, align 8
  %slot694 = alloca i64, align 8
  %slot695 = alloca i64, align 8
  %slot696 = alloca i32, align 8
  %slot697 = alloca i64, align 8
  %slot698 = alloca i64, align 8
  %slot699 = alloca i64, align 8
  %slot700 = alloca i32, align 8
  %slot701 = alloca i64, align 8
  %slot702 = alloca i64, align 8
  %slot703 = alloca i32, align 8
  %slot704 = alloca i32, align 8
  %slot705 = alloca i32, align 8
  %slot706 = alloca i64, align 8
  %slot707 = alloca i64, align 8
  %slot708 = alloca i32, align 8
  %slot709 = alloca i64, align 8
  %slot710 = alloca i64, align 8
  %slot711 = alloca i32, align 8
  %slot712 = alloca i64, align 8
  %slot713 = alloca i64, align 8
  %slot714 = alloca i64, align 8
  %slot715 = alloca i32, align 8
  %slot716 = alloca i64, align 8
  %slot717 = alloca i64, align 8
  %slot718 = alloca i32, align 8
  %slot719 = alloca i64, align 8
  %slot720 = alloca i64, align 8
  %slot721 = alloca i64, align 8
  %slot722 = alloca i64, align 8
  %slot723 = alloca i64, align 8
  %slot724 = alloca i64, align 8
  %slot725 = alloca i64, align 8
  %slot726 = alloca i64, align 8
  %slot727 = alloca i64, align 8
  %slot728 = alloca i64, align 8
  %slot729 = alloca i64, align 8
  %slot730 = alloca i64, align 8
  %slot731 = alloca i64, align 8
  %slot732 = alloca i64, align 8
  %slot733 = alloca i32, align 8
  %slot734 = alloca i64, align 8
  %slot735 = alloca i64, align 8
  %slot736 = alloca i64, align 8
  %slot737 = alloca i64, align 8
  %slot738 = alloca i64, align 8
  %slot739 = alloca i64, align 8
  %slot740 = alloca i64, align 8
  %slot741 = alloca i64, align 8
  %slot742 = alloca i64, align 8
  %slot743 = alloca i64, align 8
  %slot744 = alloca i64, align 8
  %slot745 = alloca i64, align 8
  %slot746 = alloca i64, align 8
  %slot747 = alloca i64, align 8
  %slot748 = alloca i32, align 8
  %slot749 = alloca i64, align 8
  %slot750 = alloca i64, align 8
  %slot751 = alloca i64, align 8
  %slot752 = alloca i64, align 8
  %slot753 = alloca i64, align 8
  %slot754 = alloca i64, align 8
  %slot755 = alloca i64, align 8
  %slot756 = alloca i64, align 8
  %slot757 = alloca i64, align 8
  %slot758 = alloca i64, align 8
  %slot759 = alloca i32, align 8
  %slot760 = alloca i32, align 8
  %slot761 = alloca i32, align 8
  %slot762 = alloca i32, align 8
  %slot763 = alloca i64, align 8
  %slot764 = alloca i64, align 8
  %slot765 = alloca i32, align 8
  %slot766 = alloca i64, align 8
  %slot767 = alloca i64, align 8
  %slot768 = alloca i64, align 8
  %slot769 = alloca i64, align 8
  %slot770 = alloca i64, align 8
  %slot771 = alloca i64, align 8
  %slot772 = alloca i64, align 8
  %slot773 = alloca i64, align 8
  %slot774 = alloca i64, align 8
  %slot775 = alloca i64, align 8
  %slot776 = alloca i32, align 8
  %slot777 = alloca i64, align 8
  %slot778 = alloca i64, align 8
  %slot779 = alloca i64, align 8
  %slot780 = alloca i64, align 8
  %slot781 = alloca i32, align 8
  %slot782 = alloca i64, align 8
  %slot783 = alloca i64, align 8
  %slot784 = alloca i32, align 8
  %slot785 = alloca i64, align 8
  %slot786 = alloca i64, align 8
  %slot787 = alloca i32, align 8
  %slot788 = alloca i64, align 8
  %slot789 = alloca i64, align 8
  %slot790 = alloca i32, align 8
  %slot791 = alloca i64, align 8
  %slot792 = alloca i64, align 8
  %slot793 = alloca i32, align 8
  %slot794 = alloca i64, align 8
  %slot795 = alloca i64, align 8
  %slot796 = alloca i32, align 8
  %slot797 = alloca i64, align 8
  %slot798 = alloca i64, align 8
  %slot799 = alloca i64, align 8
  %slot800 = alloca i32, align 8
  %slot801 = alloca i64, align 8
  %slot802 = alloca i64, align 8
  %slot803 = alloca i32, align 8
  %slot804 = alloca i64, align 8
  %slot805 = alloca i64, align 8
  %slot806 = alloca i32, align 8
  %slot807 = alloca i32, align 8
  %slot808 = alloca i32, align 8
  %slot809 = alloca i64, align 8
  %slot810 = alloca i64, align 8
  %slot811 = alloca i32, align 8
  %slot812 = alloca i64, align 8
  %slot813 = alloca i64, align 8
  %slot814 = alloca i64, align 8
  %slot815 = alloca i32, align 8
  %slot816 = alloca i64, align 8
  %slot817 = alloca i64, align 8
  %slot818 = alloca i32, align 8
  %slot819 = alloca i64, align 8
  %slot820 = alloca i64, align 8
  %slot821 = alloca i32, align 8
  %slot822 = alloca i32, align 8
  %slot823 = alloca i32, align 8
  %slot824 = alloca i64, align 8
  %slot825 = alloca i32, align 8
  %slot826 = alloca i64, align 8
  %slot827 = alloca i64, align 8
  %slot828 = alloca i64, align 8
  %slot829 = alloca i64, align 8
  %slot830 = alloca i64, align 8
  %slot831 = alloca i64, align 8
  %slot832 = alloca i64, align 8
  %slot833 = alloca i64, align 8
  %slot834 = alloca i64, align 8
  %slot835 = alloca i64, align 8
  %slot836 = alloca i64, align 8
  %slot837 = alloca i64, align 8
  %slot838 = alloca i64, align 8
  %slot839 = alloca i64, align 8
  %slot840 = alloca i64, align 8
  %slot841 = alloca i64, align 8
  %slot842 = alloca i64, align 8
  %slot843 = alloca i64, align 8
  %slot844 = alloca i64, align 8
  %slot845 = alloca i32, align 8
  %slot846 = alloca i64, align 8
  %slot847 = alloca i64, align 8
  %slot848 = alloca i64, align 8
  %slot849 = alloca i64, align 8
  %slot850 = alloca i64, align 8
  %slot851 = alloca i64, align 8
  %slot852 = alloca i64, align 8
  %slot853 = alloca i64, align 8
  %slot854 = alloca i64, align 8
  %slot855 = alloca i64, align 8
  %slot856 = alloca i64, align 8
  %slot857 = alloca i64, align 8
  %slot858 = alloca i64, align 8
  %slot859 = alloca i32, align 8
  %slot860 = alloca i64, align 8
  %slot861 = alloca i32, align 8
  %slot862 = alloca i32, align 8
  %slot863 = alloca i64, align 8
  %slot864 = alloca i64, align 8
  %slot865 = alloca i64, align 8
  %slot866 = alloca i32, align 8
  %slot867 = alloca i32, align 8
  %slot868 = alloca i32, align 8
  %slot869 = alloca i32, align 8
  %slot870 = alloca i64, align 8
  %slot871 = alloca i32, align 8
  %slot872 = alloca i32, align 8
  %slot873 = alloca i64, align 8
  %slot874 = alloca i32, align 8
  %slot875 = alloca i32, align 8
  %slot876 = alloca i32, align 8
  %slot877 = alloca i32, align 8
  %slot878 = alloca i64, align 8
  %slot879 = alloca i32, align 8
  %slot880 = alloca i32, align 8
  %slot881 = alloca i64, align 8
  %slot882 = alloca i64, align 8
  %slot883 = alloca i64, align 8
  %slot884 = alloca i64, align 8
  %slot885 = alloca i32, align 8
  %slot886 = alloca i64, align 8
  %slot887 = alloca i64, align 8
  %slot888 = alloca i64, align 8
  %slot889 = alloca i32, align 8
  %slot890 = alloca i32, align 8
  %slot891 = alloca i32, align 8
  %slot892 = alloca i64, align 8
  %slot893 = alloca i64, align 8
  %slot894 = alloca i64, align 8
  %slot895 = alloca i64, align 8
  %slot896 = alloca i64, align 8
  %slot897 = alloca i32, align 8
  %slot898 = alloca i64, align 8
  %slot899 = alloca i32, align 8
  %slot900 = alloca i32, align 8
  %slot901 = alloca i64, align 8
  %slot902 = alloca i64, align 8
  %slot903 = alloca i64, align 8
  %slot904 = alloca i32, align 8
  %slot905 = alloca i32, align 8
  %slot906 = alloca i32, align 8
  %slot907 = alloca i32, align 8
  %slot908 = alloca i64, align 8
  %slot909 = alloca i32, align 8
  %slot910 = alloca i32, align 8
  %slot911 = alloca i64, align 8
  %slot912 = alloca i32, align 8
  %slot913 = alloca i32, align 8
  %slot914 = alloca i32, align 8
  %slot915 = alloca i32, align 8
  %slot916 = alloca i64, align 8
  %slot917 = alloca i32, align 8
  %slot918 = alloca i32, align 8
  %slot919 = alloca i64, align 8
  %slot920 = alloca i64, align 8
  %slot921 = alloca i64, align 8
  %slot922 = alloca i64, align 8
  %slot923 = alloca i32, align 8
  %slot924 = alloca i64, align 8
  %slot925 = alloca i64, align 8
  %slot926 = alloca i64, align 8
  %slot927 = alloca i64, align 8
  %slot928 = alloca i64, align 8
  %slot929 = alloca i32, align 8
  %slot930 = alloca i64, align 8
  %slot931 = alloca i64, align 8
  %slot932 = alloca i64, align 8
  %slot933 = alloca i32, align 8
  %slot934 = alloca i64, align 8
  %slot935 = alloca i64, align 8
  %slot936 = alloca i32, align 8
  %slot937 = alloca i64, align 8
  %slot938 = alloca i64, align 8
  %slot939 = alloca i64, align 8
  %slot940 = alloca i32, align 8
  %slot941 = alloca i64, align 8
  %slot942 = alloca i64, align 8
  %slot943 = alloca i64, align 8
  %slot944 = alloca i64, align 8
  %slot945 = alloca i32, align 8
  %slot946 = alloca i32, align 8
  %slot947 = alloca i32, align 8
  %slot948 = alloca i64, align 8
  %slot949 = alloca i64, align 8
  %slot950 = alloca i64, align 8
  %slot951 = alloca i64, align 8
  %slot952 = alloca i64, align 8
  %slot953 = alloca i64, align 8
  %slot954 = alloca i32, align 8
  %slot955 = alloca i64, align 8
  %slot956 = alloca i32, align 8
  %slot957 = alloca i32, align 8
  %slot958 = alloca i64, align 8
  %slot959 = alloca i64, align 8
  %slot960 = alloca i64, align 8
  %slot961 = alloca i64, align 8
  %slot962 = alloca i64, align 8
  %slot963 = alloca i64, align 8
  %slot964 = alloca i64, align 8
  %slot965 = alloca i64, align 8
  %slot966 = alloca i64, align 8
  %slot967 = alloca i64, align 8
  %slot968 = alloca i64, align 8
  %slot969 = alloca i64, align 8
  %slot970 = alloca i64, align 8
  %slot971 = alloca i64, align 8
  %slot972 = alloca i32, align 8
  %slot973 = alloca i32, align 8
  %slot974 = alloca i32, align 8
  %slot975 = alloca i64, align 8
  %slot976 = alloca i64, align 8
  %slot977 = alloca i32, align 8
  %slot978 = alloca i64, align 8
  %slot979 = alloca i32, align 8
  %slot980 = alloca i64, align 8
  %slot981 = alloca i32, align 8
  %slot982 = alloca i32, align 8
  %slot983 = alloca i64, align 8
  %slot984 = alloca i64, align 8
  %slot985 = alloca i32, align 8
  %slot986 = alloca i64, align 8
  %slot987 = alloca i32, align 8
  %slot988 = alloca i32, align 8
  %slot989 = alloca i64, align 8
  %slot990 = alloca i64, align 8
  %slot991 = alloca i32, align 8
  %slot992 = alloca i64, align 8
  %slot993 = alloca i32, align 8
  %slot994 = alloca i32, align 8
  %slot995 = alloca i64, align 8
  %slot996 = alloca i64, align 8
  %slot997 = alloca i32, align 8
  %slot998 = alloca i64, align 8
  %slot999 = alloca i64, align 8
  %slot1000 = alloca i64, align 8
  %slot1001 = alloca i32, align 8
  %slot1002 = alloca i64, align 8
  %slot1003 = alloca i64, align 8
  %slot1004 = alloca i64, align 8
  %slot1005 = alloca i32, align 8
  %slot1006 = alloca i64, align 8
  %slot1007 = alloca i64, align 8
  %slot1008 = alloca i32, align 8
  %slot1009 = alloca i64, align 8
  %slot1010 = alloca i64, align 8
  %slot1011 = alloca i32, align 8
  %slot1012 = alloca i64, align 8
  %slot1013 = alloca i64, align 8
  %slot1014 = alloca i64, align 8
  %slot1015 = alloca i32, align 8
  %slot1016 = alloca i64, align 8
  %slot1017 = alloca i64, align 8
  %slot1018 = alloca i64, align 8
  %slot1019 = alloca i32, align 8
  %slot1020 = alloca i64, align 8
  %slot1021 = alloca i64, align 8
  %slot1022 = alloca i32, align 8
  %slot1023 = alloca i64, align 8
  %slot1024 = alloca i64, align 8
  %slot1025 = alloca i64, align 8
  %slot1026 = alloca i64, align 8
  %slot1027 = alloca i32, align 8
  %slot1028 = alloca i32, align 8
  %slot1029 = alloca i32, align 8
  %slot1030 = alloca i32, align 8
  %slot1031 = alloca i64, align 8
  %slot1032 = alloca i32, align 8
  %slot1033 = alloca i32, align 8
  %slot1034 = alloca i64, align 8
  %slot1035 = alloca i64, align 8
  %slot1036 = alloca i64, align 8
  %slot1037 = alloca i64, align 8
  %slot1038 = alloca i32, align 8
  %slot1039 = alloca i64, align 8
  %slot1040 = alloca i64, align 8
  %slot1041 = alloca i64, align 8
  %slot1042 = alloca i64, align 8
  %slot1043 = alloca i64, align 8
  %slot1044 = alloca i64, align 8
  %slot1045 = alloca i64, align 8
  %slot1046 = alloca i64, align 8
  %slot1047 = alloca i64, align 8
  %slot1048 = alloca i32, align 8
  %slot1049 = alloca i32, align 8
  %slot1050 = alloca i32, align 8
  %slot1051 = alloca i32, align 8
  %slot1052 = alloca i64, align 8
  %slot1053 = alloca i64, align 8
  %slot1054 = alloca i64, align 8
  %slot1055 = alloca i64, align 8
  %slot1056 = alloca i32, align 8
  %slot1057 = alloca i32, align 8
  %slot1058 = alloca i32, align 8
  %slot1059 = alloca i64, align 8
  %slot1060 = alloca i64, align 8
  %slot1061 = alloca i32, align 8
  %slot1062 = alloca i64, align 8
  %slot1063 = alloca i64, align 8
  %slot1064 = alloca i64, align 8
  %slot1065 = alloca i32, align 8
  %slot1066 = alloca i64, align 8
  %slot1067 = alloca i64, align 8
  %slot1068 = alloca i32, align 8
  %slot1069 = alloca i64, align 8
  %slot1070 = alloca i64, align 8
  %slot1071 = alloca i64, align 8
  %slot1072 = alloca i32, align 8
  %slot1073 = alloca i64, align 8
  %slot1074 = alloca i64, align 8
  %slot1075 = alloca i32, align 8
  %slot1076 = alloca i64, align 8
  %slot1077 = alloca i64, align 8
  %slot1078 = alloca i64, align 8
  %slot1079 = alloca i32, align 8
  %slot1080 = alloca i64, align 8
  %slot1081 = alloca i64, align 8
  %slot1082 = alloca i32, align 8
  %slot1083 = alloca i64, align 8
  %slot1084 = alloca i64, align 8
  %slot1085 = alloca i64, align 8
  %slot1086 = alloca i32, align 8
  %slot1087 = alloca i64, align 8
  %slot1088 = alloca i64, align 8
  %slot1089 = alloca i64, align 8
  %slot1090 = alloca i32, align 8
  %slot1091 = alloca i32, align 8
  %slot1092 = alloca i32, align 8
  %slot1093 = alloca i64, align 8
  %slot1094 = alloca i64, align 8
  %slot1095 = alloca i32, align 8
  %slot1096 = alloca i32, align 8
  %slot1097 = alloca i32, align 8
  %slot1098 = alloca i32, align 8
  %slot1099 = alloca i64, align 8
  %slot1100 = alloca i32, align 8
  %slot1101 = alloca i32, align 8
  %slot1102 = alloca i64, align 8
  %slot1103 = alloca i64, align 8
  %slot1104 = alloca i64, align 8
  %slot1105 = alloca i64, align 8
  %slot1106 = alloca i64, align 8
  %slot1107 = alloca i64, align 8
  %slot1108 = alloca i64, align 8
  %slot1109 = alloca i64, align 8
  %slot1110 = alloca i64, align 8
  %slot1111 = alloca i32, align 8
  %slot1112 = alloca i32, align 8
  %slot1113 = alloca i32, align 8
  %slot1114 = alloca i64, align 8
  %slot1115 = alloca i64, align 8
  %slot1116 = alloca i32, align 8
  %slot1117 = alloca i64, align 8
  %slot1118 = alloca i32, align 8
  %slot1119 = alloca i64, align 8
  %slot1120 = alloca i32, align 8
  %slot1121 = alloca i32, align 8
  %slot1122 = alloca i64, align 8
  %slot1123 = alloca i64, align 8
  %slot1124 = alloca i32, align 8
  %slot1125 = alloca i64, align 8
  %slot1126 = alloca i32, align 8
  %slot1127 = alloca i32, align 8
  %slot1128 = alloca i64, align 8
  %slot1129 = alloca i64, align 8
  %slot1130 = alloca i32, align 8
  %slot1131 = alloca i64, align 8
  %slot1132 = alloca i32, align 8
  %slot1133 = alloca i32, align 8
  %slot1134 = alloca i64, align 8
  %slot1135 = alloca i64, align 8
  %slot1136 = alloca i32, align 8
  %slot1137 = alloca i64, align 8
  %slot1138 = alloca i64, align 8
  %slot1139 = alloca i64, align 8
  %slot1140 = alloca i32, align 8
  %slot1141 = alloca i64, align 8
  %slot1142 = alloca i64, align 8
  %slot1143 = alloca i64, align 8
  %slot1144 = alloca i32, align 8
  %slot1145 = alloca i64, align 8
  %slot1146 = alloca i64, align 8
  %slot1147 = alloca i32, align 8
  %slot1148 = alloca i64, align 8
  %slot1149 = alloca i64, align 8
  %slot1150 = alloca i32, align 8
  %slot1151 = alloca i64, align 8
  %slot1152 = alloca i64, align 8
  %slot1153 = alloca i64, align 8
  %slot1154 = alloca i32, align 8
  %slot1155 = alloca i64, align 8
  %slot1156 = alloca i64, align 8
  %slot1157 = alloca i64, align 8
  %slot1158 = alloca i32, align 8
  %slot1159 = alloca i64, align 8
  %slot1160 = alloca i64, align 8
  %slot1161 = alloca i32, align 8
  store i64 %p_ctx, ptr %slot1, align 8
  store i64 %p_a0, ptr %slot2, align 8
  store i64 %p_a1, ptr %slot3, align 8
  store i64 %p_a2, ptr %slot4, align 8
  %v1162 = load i64, ptr %slot1, align 8
  %op1163 = add i64 %v1162, 32
  store i64 %op1163, ptr %slot5, align 8
  %mem1164 = alloca i8, i64 40, align 8
  %ptr1165 = ptrtoint ptr %mem1164 to i64
  store i64 %ptr1165, ptr %slot6, align 8
  %mem1166 = alloca i8, i64 8, align 8
  %ptr1167 = ptrtoint ptr %mem1166 to i64
  store i64 %ptr1167, ptr %slot7, align 8
  %mem1168 = alloca i8, i64 8, align 8
  %ptr1169 = ptrtoint ptr %mem1168 to i64
  store i64 %ptr1169, ptr %slot8, align 8
  %mem1170 = alloca i8, i64 8, align 8
  %ptr1171 = ptrtoint ptr %mem1170 to i64
  store i64 %ptr1171, ptr %slot9, align 8
  %mem1172 = alloca i8, i64 8, align 8
  %ptr1173 = ptrtoint ptr %mem1172 to i64
  store i64 %ptr1173, ptr %slot10, align 8
  %mem1174 = alloca i8, i64 8, align 8
  %ptr1175 = ptrtoint ptr %mem1174 to i64
  store i64 %ptr1175, ptr %slot11, align 8
  %mem1176 = alloca i8, i64 8, align 8
  %ptr1177 = ptrtoint ptr %mem1176 to i64
  store i64 %ptr1177, ptr %slot12, align 8
  %mem1178 = alloca i8, i64 8, align 8
  %ptr1179 = ptrtoint ptr %mem1178 to i64
  store i64 %ptr1179, ptr %slot13, align 8
  %mem1180 = alloca i8, i64 8, align 8
  %ptr1181 = ptrtoint ptr %mem1180 to i64
  store i64 %ptr1181, ptr %slot14, align 8
  %mem1182 = alloca i8, i64 8, align 8
  %ptr1183 = ptrtoint ptr %mem1182 to i64
  store i64 %ptr1183, ptr %slot15, align 8
  %mem1184 = alloca i8, i64 8, align 8
  %ptr1185 = ptrtoint ptr %mem1184 to i64
  store i64 %ptr1185, ptr %slot16, align 8
  %mem1186 = alloca i8, i64 8, align 8
  %ptr1187 = ptrtoint ptr %mem1186 to i64
  store i64 %ptr1187, ptr %slot17, align 8
  %mem1188 = alloca i8, i64 8, align 8
  %ptr1189 = ptrtoint ptr %mem1188 to i64
  store i64 %ptr1189, ptr %slot18, align 8
  %mem1190 = alloca i8, i64 8, align 8
  %ptr1191 = ptrtoint ptr %mem1190 to i64
  store i64 %ptr1191, ptr %slot19, align 8
  %mem1192 = alloca i8, i64 8, align 8
  %ptr1193 = ptrtoint ptr %mem1192 to i64
  store i64 %ptr1193, ptr %slot20, align 8
  %mem1194 = alloca i8, i64 8, align 8
  %ptr1195 = ptrtoint ptr %mem1194 to i64
  store i64 %ptr1195, ptr %slot21, align 8
  %mem1196 = alloca i8, i64 312, align 8
  %ptr1197 = ptrtoint ptr %mem1196 to i64
  store i64 %ptr1197, ptr %slot22, align 8
  %mem1198 = alloca i8, i64 40, align 8
  %ptr1199 = ptrtoint ptr %mem1198 to i64
  store i64 %ptr1199, ptr %slot23, align 8
  %mem1200 = alloca i8, i64 8, align 8
  %ptr1201 = ptrtoint ptr %mem1200 to i64
  store i64 %ptr1201, ptr %slot24, align 8
  %mem1202 = alloca i8, i64 32, align 8
  %ptr1203 = ptrtoint ptr %mem1202 to i64
  store i64 %ptr1203, ptr %slot25, align 8
  %mem1204 = alloca i8, i64 8, align 8
  %ptr1205 = ptrtoint ptr %mem1204 to i64
  store i64 %ptr1205, ptr %slot26, align 8
  %mem1206 = alloca i8, i64 8, align 8
  %ptr1207 = ptrtoint ptr %mem1206 to i64
  store i64 %ptr1207, ptr %slot27, align 8
  %mem1208 = alloca i8, i64 8, align 8
  %ptr1209 = ptrtoint ptr %mem1208 to i64
  store i64 %ptr1209, ptr %slot28, align 8
  %mem1210 = alloca i8, i64 312, align 8
  %ptr1211 = ptrtoint ptr %mem1210 to i64
  store i64 %ptr1211, ptr %slot29, align 8
  %mem1212 = alloca i8, i64 8, align 8
  %ptr1213 = ptrtoint ptr %mem1212 to i64
  store i64 %ptr1213, ptr %slot30, align 8
  %mem1214 = alloca i8, i64 32, align 8
  %ptr1215 = ptrtoint ptr %mem1214 to i64
  store i64 %ptr1215, ptr %slot31, align 8
  %v1216 = load i64, ptr %slot31, align 8
  %p1218 = inttoptr i64 %v1216 to ptr
  %gep1219 = getelementptr i8, ptr %p1218, i64 24
  %op1217 = ptrtoint ptr %gep1219 to i64
  store i64 %op1217, ptr %slot32, align 8
  %v1220 = load i64, ptr %slot32, align 8
  %p1221 = inttoptr i64 %v1220 to ptr
  store i64 0, ptr %p1221, align 8, !alias.scope !3, !noalias !4
  %mem1222 = alloca i8, i64 8, align 8
  %ptr1223 = ptrtoint ptr %mem1222 to i64
  store i64 %ptr1223, ptr %slot33, align 8
  %mem1224 = alloca i8, i64 8, align 8
  %ptr1225 = ptrtoint ptr %mem1224 to i64
  store i64 %ptr1225, ptr %slot34, align 8
  %mem1226 = alloca i8, i64 8, align 8
  %ptr1227 = ptrtoint ptr %mem1226 to i64
  store i64 %ptr1227, ptr %slot35, align 8
  %mem1228 = alloca i8, i64 8, align 8
  %ptr1229 = ptrtoint ptr %mem1228 to i64
  store i64 %ptr1229, ptr %slot36, align 8
  %mem1230 = alloca i8, i64 8, align 8
  %ptr1231 = ptrtoint ptr %mem1230 to i64
  store i64 %ptr1231, ptr %slot37, align 8
  %mem1232 = alloca i8, i64 312, align 8
  %ptr1233 = ptrtoint ptr %mem1232 to i64
  store i64 %ptr1233, ptr %slot38, align 8
  %mem1234 = alloca i8, i64 8, align 8
  %ptr1235 = ptrtoint ptr %mem1234 to i64
  store i64 %ptr1235, ptr %slot39, align 8
  %mem1236 = alloca i8, i64 8, align 8
  %ptr1237 = ptrtoint ptr %mem1236 to i64
  store i64 %ptr1237, ptr %slot40, align 8
  %mem1238 = alloca i8, i64 8, align 8
  %ptr1239 = ptrtoint ptr %mem1238 to i64
  store i64 %ptr1239, ptr %slot41, align 8
  %mem1240 = alloca i8, i64 8, align 8
  %ptr1241 = ptrtoint ptr %mem1240 to i64
  store i64 %ptr1241, ptr %slot42, align 8
  %mem1242 = alloca i8, i64 8, align 8
  %ptr1243 = ptrtoint ptr %mem1242 to i64
  store i64 %ptr1243, ptr %slot43, align 8
  %mem1244 = alloca i8, i64 8, align 8
  %ptr1245 = ptrtoint ptr %mem1244 to i64
  store i64 %ptr1245, ptr %slot44, align 8
  %mem1246 = alloca i8, i64 8, align 8
  %ptr1247 = ptrtoint ptr %mem1246 to i64
  store i64 %ptr1247, ptr %slot45, align 8
  %mem1248 = alloca i8, i64 8, align 8
  %ptr1249 = ptrtoint ptr %mem1248 to i64
  store i64 %ptr1249, ptr %slot46, align 8
  %mem1250 = alloca i8, i64 8, align 8
  %ptr1251 = ptrtoint ptr %mem1250 to i64
  store i64 %ptr1251, ptr %slot47, align 8
  %mem1252 = alloca i8, i64 312, align 8
  %ptr1253 = ptrtoint ptr %mem1252 to i64
  store i64 %ptr1253, ptr %slot48, align 8
  %mem1254 = alloca i8, i64 40, align 8
  %ptr1255 = ptrtoint ptr %mem1254 to i64
  store i64 %ptr1255, ptr %slot49, align 8
  %mem1256 = alloca i8, i64 312, align 8
  %ptr1257 = ptrtoint ptr %mem1256 to i64
  store i64 %ptr1257, ptr %slot50, align 8
  %mem1258 = alloca i8, i64 40, align 8
  %ptr1259 = ptrtoint ptr %mem1258 to i64
  store i64 %ptr1259, ptr %slot51, align 8
  br label %bb_frameadmit1
bb_frameadmit1:
  %mem1260 = alloca i8, i64 8, align 8
  %ptr1261 = ptrtoint ptr %mem1260 to i64
  store i64 %ptr1261, ptr %slot52, align 8
  %v1262 = load i64, ptr %slot1, align 8
  %op1263 = add i64 %v1262, 64
  store i64 %op1263, ptr %slot53, align 8
  %v1264 = load i64, ptr %slot53, align 8
  %p1265 = inttoptr i64 %v1264 to ptr
  %ld1266 = load i64, ptr %p1265, align 8, !alias.scope !4, !noalias !3
  store i64 %ld1266, ptr %slot54, align 8
  %stack1267 = call ptr @llvm.stacksave()
  %stackaddr1268 = ptrtoint ptr %stack1267 to i64
  %v1269 = load i64, ptr %slot54, align 8
  %cmp1270 = icmp ult i64 %stackaddr1268, %v1269
  %cv1271 = zext i1 %cmp1270 to i64
  store i64 %cv1271, ptr %slot55, align 8
  %v1272 = load i64, ptr %slot55, align 8
  %cond1273 = icmp ne i64 %v1272, 0
  br i1 %cond1273, label %bb_floorfail3, label %bb_stackadmit2
bb_floorfail3:
  %v1274 = load i64, ptr %slot1, align 8
  %p1275 = inttoptr i64 %v1274 to ptr
  call void @myl_qbe_fail_frame(ptr %p1275) nomerge, !dbg !110
  unreachable
bb_stackadmit2:
  %v1276 = load i64, ptr %slot37, align 8
  %p1277 = inttoptr i64 %v1276 to ptr
  store i64 0, ptr %p1277, align 8, !alias.scope !3, !noalias !4
  %v1278 = load i64, ptr %slot40, align 8
  %p1279 = inttoptr i64 %v1278 to ptr
  store i64 0, ptr %p1279, align 8, !alias.scope !3, !noalias !4
  %v1280 = load i64, ptr %slot2, align 8
  %v1281 = load i64, ptr %slot34, align 8
  %p1282 = inttoptr i64 %v1281 to ptr
  store i64 %v1280, ptr %p1282, align 8, !alias.scope !3, !noalias !4
  %v1283 = load i64, ptr %slot3, align 8
  %v1284 = load i64, ptr %slot35, align 8
  %p1285 = inttoptr i64 %v1284 to ptr
  store i64 %v1283, ptr %p1285, align 8, !alias.scope !3, !noalias !4
  %v1286 = load i64, ptr %slot4, align 8
  %v1287 = load i64, ptr %slot36, align 8
  %p1288 = inttoptr i64 %v1287 to ptr
  store i64 %v1286, ptr %p1288, align 8, !alias.scope !3, !noalias !4
  %v1289 = load i64, ptr %slot1, align 8
  %p1290 = inttoptr i64 %v1289 to ptr
  %call1291 = call ptr @myl_qbe_heap(ptr %p1290) nomerge, !dbg !112
  %calladdr1292 = ptrtoint ptr %call1291 to i64
  store i64 %calladdr1292, ptr %slot56, align 8
  %v1293 = load i64, ptr %slot1, align 8
  %p1294 = inttoptr i64 %v1293 to ptr
  %call1295 = call i64 @myl_qbe_region_mark(ptr %p1294) nomerge, !dbg !112
  store i64 %call1295, ptr %slot57, align 8
  %v1296 = load i64, ptr %slot7, align 8
  %p1297 = inttoptr i64 %v1296 to ptr
  store i32 0, ptr %p1297, align 4, !alias.scope !3, !noalias !4
  %v1298 = load i64, ptr %slot8, align 8
  %p1299 = inttoptr i64 %v1298 to ptr
  store i32 0, ptr %p1299, align 4, !alias.scope !3, !noalias !4
  %v1300 = load i64, ptr %slot9, align 8
  %p1301 = inttoptr i64 %v1300 to ptr
  store i32 0, ptr %p1301, align 4, !alias.scope !3, !noalias !4
  %v1302 = load i64, ptr %slot10, align 8
  %p1303 = inttoptr i64 %v1302 to ptr
  store i32 0, ptr %p1303, align 4, !alias.scope !3, !noalias !4
  %v1304 = load i64, ptr %slot11, align 8
  %p1305 = inttoptr i64 %v1304 to ptr
  store i32 0, ptr %p1305, align 4, !alias.scope !3, !noalias !4
  %v1306 = load i64, ptr %slot12, align 8
  %p1307 = inttoptr i64 %v1306 to ptr
  store i32 0, ptr %p1307, align 4, !alias.scope !3, !noalias !4
  %v1308 = load i64, ptr %slot13, align 8
  %p1309 = inttoptr i64 %v1308 to ptr
  store i32 0, ptr %p1309, align 4, !alias.scope !3, !noalias !4
  %v1310 = load i64, ptr %slot14, align 8
  %p1311 = inttoptr i64 %v1310 to ptr
  store i32 0, ptr %p1311, align 4, !alias.scope !3, !noalias !4
  %v1312 = load i64, ptr %slot15, align 8
  %p1313 = inttoptr i64 %v1312 to ptr
  store i32 0, ptr %p1313, align 4, !alias.scope !3, !noalias !4
  %v1314 = load i64, ptr %slot16, align 8
  %p1315 = inttoptr i64 %v1314 to ptr
  store i32 0, ptr %p1315, align 4, !alias.scope !3, !noalias !4
  %v1316 = load i64, ptr %slot17, align 8
  %p1317 = inttoptr i64 %v1316 to ptr
  store i32 0, ptr %p1317, align 4, !alias.scope !3, !noalias !4
  %v1318 = load i64, ptr %slot18, align 8
  %p1319 = inttoptr i64 %v1318 to ptr
  store i32 0, ptr %p1319, align 4, !alias.scope !3, !noalias !4
  %v1320 = load i64, ptr %slot19, align 8
  %p1321 = inttoptr i64 %v1320 to ptr
  store i32 0, ptr %p1321, align 4, !alias.scope !3, !noalias !4
  %v1322 = load i64, ptr %slot20, align 8
  %p1323 = inttoptr i64 %v1322 to ptr
  store i32 0, ptr %p1323, align 4, !alias.scope !3, !noalias !4
  %v1324 = load i64, ptr %slot21, align 8
  %p1325 = inttoptr i64 %v1324 to ptr
  store i32 0, ptr %p1325, align 4, !alias.scope !3, !noalias !4
  %v1326 = load i64, ptr %slot8, align 8
  %p1327 = inttoptr i64 %v1326 to ptr
  store i32 2, ptr %p1327, align 4, !alias.scope !3, !noalias !4
  %v1328 = load i64, ptr %slot10, align 8
  %p1329 = inttoptr i64 %v1328 to ptr
  store i32 2, ptr %p1329, align 4, !alias.scope !3, !noalias !4
  br label %bb_i0
bb_i0:
  %v1330 = load i64, ptr %slot34, align 8
  %p1331 = inttoptr i64 %v1330 to ptr
  %ld1332 = load i64, ptr %p1331, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1332, ptr %slot58, align 8
  %v1333 = load i64, ptr %slot58, align 8
  %v1334 = load i64, ptr %slot41, align 8
  %p1335 = inttoptr i64 %v1334 to ptr
  store i64 %v1333, ptr %p1335, align 8, !alias.scope !3, !noalias !4
  %v1336 = load i64, ptr %slot41, align 8
  %p1337 = inttoptr i64 %v1336 to ptr
  %ld1338 = load i64, ptr %p1337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1338, ptr %slot59, align 8
  %v1339 = load i64, ptr %slot11, align 8
  %p1340 = inttoptr i64 %v1339 to ptr
  %ld1341 = load i32, ptr %p1340, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1341, ptr %slot60, align 8
  %v1342 = load i64, ptr %slot12, align 8
  %p1343 = inttoptr i64 %v1342 to ptr
  %ld1344 = load i32, ptr %p1343, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1344, ptr %slot61, align 8
  %v1345 = load i32, ptr %slot61, align 8
  %op1346 = and i32 %v1345, 24
  store i32 %op1346, ptr %slot61, align 8
  %v1347 = load i32, ptr %slot61, align 8
  %cmp1348 = icmp eq i32 %v1347, 0
  %cv1349 = zext i1 %cmp1348 to i32
  store i32 %cv1349, ptr %slot62, align 8
  %v1350 = load i32, ptr %slot60, align 8
  %v1351 = load i32, ptr %slot62, align 8
  %op1352 = and i32 %v1350, %v1351
  store i32 %op1352, ptr %slot63, align 8
  %v1353 = load i64, ptr %slot57, align 8
  store i64 %v1353, ptr %slot64, align 8
  %v1354 = load i32, ptr %slot63, align 8
  %op1355 = mul i32 %v1354, 4
  store i32 %op1355, ptr %slot65, align 8
  %v1356 = load i32, ptr %slot65, align 8
  %op1357 = or i32 %v1356, 0
  store i32 %op1357, ptr %slot66, align 8
  %v1358 = load i64, ptr %slot29, align 8
  store i64 %v1358, ptr %slot67, align 8
  %v1359 = load i64, ptr %slot56, align 8
  %v1360 = load i64, ptr %slot67, align 8
  %v1361 = load i64, ptr %slot59, align 8
  %v1362 = load i64, ptr %slot64, align 8
  %cv1363 = trunc i64 %v1362 to i32
  %v1364 = load i32, ptr %slot66, align 8
  %call1365 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_publish(i64 %v1359, i64 %v1360, i64 %v1361, i32 %cv1363, i32 %v1364) nomerge, !dbg !114
  store i32 %call1365, ptr %slot68, align 8
  %v1366 = load i32, ptr %slot68, align 8
  %cv1367 = zext i32 %v1366 to i64
  %cond1368 = icmp ne i64 %cv1367, 0
  br i1 %cond1368, label %bb_rcsuccess29, label %bb_rcfailure29
bb_rcfailure29:
  %v1369 = load i64, ptr %slot56, align 8
  %p1370 = inttoptr i64 %v1369 to ptr
  %call1371 = call i32 @myl_rc_take_failure(ptr %p1370) nomerge, !dbg !114
  store i32 %call1371, ptr %slot69, align 8
  %v1372 = load i64, ptr %slot1, align 8
  %p1373 = inttoptr i64 %v1372 to ptr
  %v1374 = load i32, ptr %slot69, align 8
  %call1375 = call i32 @myl_qbe_rc_status(ptr %p1373, i32 %v1374) nomerge, !dbg !114
  store i32 %call1375, ptr %slot70, align 8
  br label %bb_failure
bb_rcsuccess29:
  %v1376 = load i32, ptr %slot63, align 8
  %cv1377 = zext i32 %v1376 to i64
  %cond1378 = icmp ne i64 %cv1377, 0
  br i1 %cond1378, label %bb_rchtaken32, label %bb_rchcopied32
bb_rchcopied32:
  %v1379 = load i64, ptr %slot11, align 8
  %p1380 = inttoptr i64 %v1379 to ptr
  %ld1381 = load i32, ptr %p1380, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1381, ptr %slot71, align 8
  %v1382 = load i32, ptr %slot71, align 8
  %cv1383 = zext i32 %v1382 to i64
  %cond1384 = icmp ne i64 %cv1383, 0
  br i1 %cond1384, label %bb_rcslotdrop35, label %bb_rcslotdone35
bb_rcslotdrop35:
  %v1385 = load i64, ptr %slot11, align 8
  %p1386 = inttoptr i64 %v1385 to ptr
  store i32 0, ptr %p1386, align 4, !alias.scope !3, !noalias !4
  %v1387 = load i64, ptr %slot22, align 8
  store i64 %v1387, ptr %slot72, align 8
  %v1388 = load i64, ptr %slot12, align 8
  %p1389 = inttoptr i64 %v1388 to ptr
  %ld1390 = load i32, ptr %p1389, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1390, ptr %slot73, align 8
  %v1391 = load i32, ptr %slot73, align 8
  %op1392 = and i32 %v1391, 28
  store i32 %op1392, ptr %slot74, align 8
  %v1393 = load i32, ptr %slot74, align 8
  %cv1394 = zext i32 %v1393 to i64
  %cond1395 = icmp ne i64 %cv1394, 0
  br i1 %cond1395, label %bb_rcslotrole35, label %bb_rcslotowner35
bb_rcslotrole35:
  %v1396 = load i64, ptr %slot56, align 8
  store i64 %v1396, ptr %slot75, align 8
  %v1397 = load i64, ptr %slot75, align 8
  %v1398 = load i64, ptr %slot72, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v1397, i64 %v1398) nomerge, !dbg !114
  br label %bb_rcslotdone35
bb_rcslotowner35:
  %v1399 = load i64, ptr %slot56, align 8
  store i64 %v1399, ptr %slot76, align 8
  %v1400 = load i64, ptr %slot76, align 8
  %v1401 = load i64, ptr %slot72, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v1400, i64 %v1401) nomerge, !dbg !114
  br label %bb_rcslotdone35
bb_rcslotdone35:
  br label %bb_rchprepared32
bb_rchtaken32:
  %v1402 = load i64, ptr %slot11, align 8
  %p1403 = inttoptr i64 %v1402 to ptr
  store i32 0, ptr %p1403, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared32
bb_rchprepared32:
  %v1404 = load i64, ptr %slot20, align 8
  %p1405 = inttoptr i64 %v1404 to ptr
  store i32 2, ptr %p1405, align 4, !alias.scope !3, !noalias !4
  %v1406 = load i64, ptr %slot19, align 8
  %p1407 = inttoptr i64 %v1406 to ptr
  store i32 1, ptr %p1407, align 4, !alias.scope !3, !noalias !4
  %v1408 = load i64, ptr %slot22, align 8
  store i64 %v1408, ptr %slot77, align 8
  %v1409 = load i64, ptr %slot29, align 8
  store i64 %v1409, ptr %slot78, align 8
  %v1410 = load i64, ptr %slot78, align 8
  %v1411 = load i64, ptr %slot77, align 8
  %p1412 = inttoptr i64 %v1410 to ptr
  %p1413 = inttoptr i64 %v1411 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1413, ptr %p1412, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v1414 = load i64, ptr %slot12, align 8
  %p1415 = inttoptr i64 %v1414 to ptr
  store i32 2, ptr %p1415, align 4, !alias.scope !3, !noalias !4
  %v1416 = load i64, ptr %slot20, align 8
  %p1417 = inttoptr i64 %v1416 to ptr
  %ld1418 = load i32, ptr %p1417, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1418, ptr %slot79, align 8
  %v1419 = load i32, ptr %slot79, align 8
  %v1420 = load i64, ptr %slot12, align 8
  %p1421 = inttoptr i64 %v1420 to ptr
  store i32 %v1419, ptr %p1421, align 4, !alias.scope !3, !noalias !4
  %v1422 = load i64, ptr %slot19, align 8
  %p1423 = inttoptr i64 %v1422 to ptr
  store i32 0, ptr %p1423, align 4, !alias.scope !3, !noalias !4
  %v1424 = load i64, ptr %slot11, align 8
  %p1425 = inttoptr i64 %v1424 to ptr
  store i32 1, ptr %p1425, align 4, !alias.scope !3, !noalias !4
  %v1426 = load i64, ptr %slot77, align 8
  %v1427 = load i64, ptr %slot41, align 8
  %p1428 = inttoptr i64 %v1427 to ptr
  store i64 %v1426, ptr %p1428, align 8, !alias.scope !3, !noalias !4
  %v1429 = load i64, ptr %slot35, align 8
  %p1430 = inttoptr i64 %v1429 to ptr
  %ld1431 = load i64, ptr %p1430, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1431, ptr %slot80, align 8
  %v1432 = load i64, ptr %slot80, align 8
  %v1433 = load i64, ptr %slot42, align 8
  %p1434 = inttoptr i64 %v1433 to ptr
  store i64 %v1432, ptr %p1434, align 8, !alias.scope !3, !noalias !4
  %v1435 = load i64, ptr %slot42, align 8
  %p1436 = inttoptr i64 %v1435 to ptr
  %ld1437 = load i64, ptr %p1436, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1437, ptr %slot81, align 8
  %v1438 = load i64, ptr %slot13, align 8
  %p1439 = inttoptr i64 %v1438 to ptr
  %ld1440 = load i32, ptr %p1439, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1440, ptr %slot82, align 8
  %v1441 = load i64, ptr %slot14, align 8
  %p1442 = inttoptr i64 %v1441 to ptr
  %ld1443 = load i32, ptr %p1442, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1443, ptr %slot83, align 8
  %v1444 = load i32, ptr %slot83, align 8
  %op1445 = and i32 %v1444, 24
  store i32 %op1445, ptr %slot83, align 8
  %v1446 = load i32, ptr %slot83, align 8
  %cmp1447 = icmp eq i32 %v1446, 0
  %cv1448 = zext i1 %cmp1447 to i32
  store i32 %cv1448, ptr %slot84, align 8
  %v1449 = load i32, ptr %slot82, align 8
  %v1450 = load i32, ptr %slot84, align 8
  %op1451 = and i32 %v1449, %v1450
  store i32 %op1451, ptr %slot85, align 8
  %v1452 = load i64, ptr %slot57, align 8
  store i64 %v1452, ptr %slot86, align 8
  %v1453 = load i32, ptr %slot85, align 8
  %op1454 = mul i32 %v1453, 4
  store i32 %op1454, ptr %slot87, align 8
  %v1455 = load i32, ptr %slot87, align 8
  %op1456 = or i32 %v1455, 0
  store i32 %op1456, ptr %slot88, align 8
  %v1457 = load i64, ptr %slot29, align 8
  store i64 %v1457, ptr %slot89, align 8
  %v1458 = load i64, ptr %slot56, align 8
  %v1459 = load i64, ptr %slot89, align 8
  %v1460 = load i64, ptr %slot81, align 8
  %v1461 = load i64, ptr %slot86, align 8
  %cv1462 = trunc i64 %v1461 to i32
  %v1463 = load i32, ptr %slot88, align 8
  %call1464 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64 %v1458, i64 %v1459, i64 %v1460, i32 %cv1462, i32 %v1463) nomerge, !dbg !116
  store i32 %call1464, ptr %slot90, align 8
  %v1465 = load i32, ptr %slot90, align 8
  %cv1466 = zext i32 %v1465 to i64
  %cond1467 = icmp ne i64 %cv1466, 0
  br i1 %cond1467, label %bb_rcsuccess68, label %bb_rcfailure68
bb_rcfailure68:
  %v1468 = load i64, ptr %slot56, align 8
  %p1469 = inttoptr i64 %v1468 to ptr
  %call1470 = call i32 @myl_rc_take_failure(ptr %p1469) nomerge, !dbg !116
  store i32 %call1470, ptr %slot91, align 8
  %v1471 = load i64, ptr %slot1, align 8
  %p1472 = inttoptr i64 %v1471 to ptr
  %v1473 = load i32, ptr %slot91, align 8
  %call1474 = call i32 @myl_qbe_rc_status(ptr %p1472, i32 %v1473) nomerge, !dbg !116
  store i32 %call1474, ptr %slot92, align 8
  br label %bb_failure
bb_rcsuccess68:
  %v1475 = load i32, ptr %slot85, align 8
  %cv1476 = zext i32 %v1475 to i64
  %cond1477 = icmp ne i64 %cv1476, 0
  br i1 %cond1477, label %bb_rchtaken71, label %bb_rchcopied71
bb_rchcopied71:
  %v1478 = load i64, ptr %slot13, align 8
  %p1479 = inttoptr i64 %v1478 to ptr
  %ld1480 = load i32, ptr %p1479, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1480, ptr %slot93, align 8
  %v1481 = load i32, ptr %slot93, align 8
  %cv1482 = zext i32 %v1481 to i64
  %cond1483 = icmp ne i64 %cv1482, 0
  br i1 %cond1483, label %bb_rcslotdrop74, label %bb_rcslotdone74
bb_rcslotdrop74:
  %v1484 = load i64, ptr %slot13, align 8
  %p1485 = inttoptr i64 %v1484 to ptr
  store i32 0, ptr %p1485, align 4, !alias.scope !3, !noalias !4
  %v1486 = load i64, ptr %slot23, align 8
  store i64 %v1486, ptr %slot94, align 8
  %v1487 = load i64, ptr %slot14, align 8
  %p1488 = inttoptr i64 %v1487 to ptr
  %ld1489 = load i32, ptr %p1488, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1489, ptr %slot95, align 8
  %v1490 = load i32, ptr %slot95, align 8
  %op1491 = and i32 %v1490, 28
  store i32 %op1491, ptr %slot96, align 8
  %v1492 = load i32, ptr %slot96, align 8
  %cv1493 = zext i32 %v1492 to i64
  %cond1494 = icmp ne i64 %cv1493, 0
  br i1 %cond1494, label %bb_rcslotrole74, label %bb_rcslotowner74
bb_rcslotrole74:
  %v1495 = load i64, ptr %slot56, align 8
  store i64 %v1495, ptr %slot97, align 8
  %v1496 = load i64, ptr %slot97, align 8
  %v1497 = load i64, ptr %slot94, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v1496, i64 %v1497) nomerge, !dbg !116
  br label %bb_rcslotdone74
bb_rcslotowner74:
  %v1498 = load i64, ptr %slot56, align 8
  store i64 %v1498, ptr %slot98, align 8
  %v1499 = load i64, ptr %slot98, align 8
  %v1500 = load i64, ptr %slot94, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v1499, i64 %v1500) nomerge, !dbg !116
  br label %bb_rcslotdone74
bb_rcslotdone74:
  br label %bb_rchprepared71
bb_rchtaken71:
  %v1501 = load i64, ptr %slot13, align 8
  %p1502 = inttoptr i64 %v1501 to ptr
  store i32 0, ptr %p1502, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared71
bb_rchprepared71:
  %v1503 = load i64, ptr %slot20, align 8
  %p1504 = inttoptr i64 %v1503 to ptr
  store i32 2, ptr %p1504, align 4, !alias.scope !3, !noalias !4
  %v1505 = load i64, ptr %slot19, align 8
  %p1506 = inttoptr i64 %v1505 to ptr
  store i32 1, ptr %p1506, align 4, !alias.scope !3, !noalias !4
  %v1507 = load i64, ptr %slot23, align 8
  store i64 %v1507, ptr %slot99, align 8
  %v1508 = load i64, ptr %slot29, align 8
  store i64 %v1508, ptr %slot100, align 8
  %v1509 = load i64, ptr %slot100, align 8
  %v1510 = load i64, ptr %slot99, align 8
  %p1511 = inttoptr i64 %v1509 to ptr
  %p1512 = inttoptr i64 %v1510 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1512, ptr %p1511, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v1513 = load i64, ptr %slot14, align 8
  %p1514 = inttoptr i64 %v1513 to ptr
  store i32 2, ptr %p1514, align 4, !alias.scope !3, !noalias !4
  %v1515 = load i64, ptr %slot20, align 8
  %p1516 = inttoptr i64 %v1515 to ptr
  %ld1517 = load i32, ptr %p1516, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1517, ptr %slot101, align 8
  %v1518 = load i32, ptr %slot101, align 8
  %v1519 = load i64, ptr %slot14, align 8
  %p1520 = inttoptr i64 %v1519 to ptr
  store i32 %v1518, ptr %p1520, align 4, !alias.scope !3, !noalias !4
  %v1521 = load i64, ptr %slot19, align 8
  %p1522 = inttoptr i64 %v1521 to ptr
  store i32 0, ptr %p1522, align 4, !alias.scope !3, !noalias !4
  %v1523 = load i64, ptr %slot13, align 8
  %p1524 = inttoptr i64 %v1523 to ptr
  store i32 1, ptr %p1524, align 4, !alias.scope !3, !noalias !4
  %v1525 = load i64, ptr %slot99, align 8
  %v1526 = load i64, ptr %slot42, align 8
  %p1527 = inttoptr i64 %v1526 to ptr
  store i64 %v1525, ptr %p1527, align 8, !alias.scope !3, !noalias !4
  %v1528 = load i64, ptr %slot36, align 8
  %p1529 = inttoptr i64 %v1528 to ptr
  %ld1530 = load i64, ptr %p1529, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1530, ptr %slot102, align 8
  %v1531 = load i64, ptr %slot102, align 8
  %v1532 = load i64, ptr %slot43, align 8
  %p1533 = inttoptr i64 %v1532 to ptr
  store i64 %v1531, ptr %p1533, align 8, !alias.scope !3, !noalias !4
  %v1534 = load i64, ptr %slot44, align 8
  %p1535 = inttoptr i64 %v1534 to ptr
  store i64 0, ptr %p1535, align 8, !alias.scope !3, !noalias !4
  %v1536 = load i64, ptr %slot44, align 8
  %p1537 = inttoptr i64 %v1536 to ptr
  %ld1538 = load i64, ptr %p1537, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1538, ptr %slot103, align 8
  %v1539 = load i64, ptr %slot103, align 8
  %cmp1540 = icmp sge i64 %v1539, 0
  %cv1541 = zext i1 %cmp1540 to i64
  store i64 %cv1541, ptr %slot104, align 8
  %v1542 = load i64, ptr %slot104, align 8
  %cond1543 = icmp ne i64 %v1542, 0
  br i1 %cond1543, label %bb_success95, label %bb_failed95
bb_failed95:
  %v1544 = load i64, ptr %slot1, align 8
  %p1545 = inttoptr i64 %v1544 to ptr
  call void @myl_qbe_fail_list_capacity(ptr %p1545) nomerge, !dbg !118
  unreachable
bb_success95:
  %v1546 = load i64, ptr %slot56, align 8
  %p1547 = inttoptr i64 %v1546 to ptr
  %p1548 = inttoptr i64 ptrtoint (ptr @myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4 to i64) to ptr
  %v1549 = load i64, ptr %slot103, align 8
  %call1550 = call ptr @myl_native_list_new(ptr %p1547, ptr %p1548, i64 %v1549) nomerge, !dbg !118
  %calladdr1551 = ptrtoint ptr %call1550 to i64
  store i64 %calladdr1551, ptr %slot105, align 8
  %v1552 = load i64, ptr %slot105, align 8
  %cond1553 = icmp ne i64 %v1552, 0
  br i1 %cond1553, label %bb_success97, label %bb_failed97
bb_failed97:
  %v1554 = load i64, ptr %slot1, align 8
  %p1555 = inttoptr i64 %v1554 to ptr
  call void @myl_qbe_fail_allocation(ptr %p1555) nomerge, !dbg !118
  unreachable
bb_success97:
  %v1556 = load i64, ptr %slot105, align 8
  %v1557 = load i64, ptr %slot44, align 8
  %p1558 = inttoptr i64 %v1557 to ptr
  store i64 %v1556, ptr %p1558, align 8, !alias.scope !3, !noalias !4
  %v1559 = load i64, ptr %slot44, align 8
  %p1560 = inttoptr i64 %v1559 to ptr
  %ld1561 = load i64, ptr %p1560, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1561, ptr %slot106, align 8
  %v1562 = load i64, ptr %slot106, align 8
  %v1563 = load i64, ptr %slot28, align 8
  %p1564 = inttoptr i64 %v1563 to ptr
  store i64 %v1562, ptr %p1564, align 8, !alias.scope !3, !noalias !4
  %v1565 = load i64, ptr %slot28, align 8
  store i64 %v1565, ptr %slot107, align 8
  %v1566 = load i64, ptr %slot29, align 8
  store i64 %v1566, ptr %slot108, align 8
  %v1567 = load i64, ptr %slot107, align 8
  %v1568 = load i64, ptr %slot108, align 8
  %p1569 = inttoptr i64 %v1567 to ptr
  %p1570 = inttoptr i64 %v1568 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1570, ptr %p1569, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1571 = load i64, ptr %slot20, align 8
  %p1572 = inttoptr i64 %v1571 to ptr
  store i32 2, ptr %p1572, align 4, !alias.scope !3, !noalias !4
  %v1573 = load i64, ptr %slot19, align 8
  %p1574 = inttoptr i64 %v1573 to ptr
  store i32 1, ptr %p1574, align 4, !alias.scope !3, !noalias !4
  %v1575 = load i64, ptr %slot24, align 8
  store i64 %v1575, ptr %slot109, align 8
  %v1576 = load i64, ptr %slot29, align 8
  store i64 %v1576, ptr %slot110, align 8
  %v1577 = load i64, ptr %slot110, align 8
  %v1578 = load i64, ptr %slot109, align 8
  %p1579 = inttoptr i64 %v1577 to ptr
  %p1580 = inttoptr i64 %v1578 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1580, ptr %p1579, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1581 = load i64, ptr %slot17, align 8
  %p1582 = inttoptr i64 %v1581 to ptr
  store i32 2, ptr %p1582, align 4, !alias.scope !3, !noalias !4
  %v1583 = load i64, ptr %slot20, align 8
  %p1584 = inttoptr i64 %v1583 to ptr
  %ld1585 = load i32, ptr %p1584, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1585, ptr %slot111, align 8
  %v1586 = load i32, ptr %slot111, align 8
  %v1587 = load i64, ptr %slot17, align 8
  %p1588 = inttoptr i64 %v1587 to ptr
  store i32 %v1586, ptr %p1588, align 4, !alias.scope !3, !noalias !4
  %v1589 = load i64, ptr %slot19, align 8
  %p1590 = inttoptr i64 %v1589 to ptr
  store i32 0, ptr %p1590, align 4, !alias.scope !3, !noalias !4
  %v1591 = load i64, ptr %slot16, align 8
  %p1592 = inttoptr i64 %v1591 to ptr
  store i32 1, ptr %p1592, align 4, !alias.scope !3, !noalias !4
  %v1593 = load i64, ptr %slot109, align 8
  %p1594 = inttoptr i64 %v1593 to ptr
  %ld1595 = load i64, ptr %p1594, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1595, ptr %slot112, align 8
  %v1596 = load i64, ptr %slot112, align 8
  %v1597 = load i64, ptr %slot44, align 8
  %p1598 = inttoptr i64 %v1597 to ptr
  store i64 %v1596, ptr %p1598, align 8, !alias.scope !3, !noalias !4
  %v1599 = load i64, ptr %slot44, align 8
  %p1600 = inttoptr i64 %v1599 to ptr
  %ld1601 = load i64, ptr %p1600, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1601, ptr %slot113, align 8
  %v1602 = load i64, ptr %slot113, align 8
  %v1603 = load i64, ptr %slot28, align 8
  %p1604 = inttoptr i64 %v1603 to ptr
  store i64 %v1602, ptr %p1604, align 8, !alias.scope !3, !noalias !4
  %v1605 = load i64, ptr %slot28, align 8
  store i64 %v1605, ptr %slot114, align 8
  %v1606 = load i64, ptr %slot16, align 8
  %p1607 = inttoptr i64 %v1606 to ptr
  %ld1608 = load i32, ptr %p1607, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1608, ptr %slot115, align 8
  %v1609 = load i64, ptr %slot17, align 8
  %p1610 = inttoptr i64 %v1609 to ptr
  %ld1611 = load i32, ptr %p1610, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1611, ptr %slot116, align 8
  %v1612 = load i32, ptr %slot116, align 8
  %op1613 = and i32 %v1612, 24
  store i32 %op1613, ptr %slot116, align 8
  %v1614 = load i32, ptr %slot116, align 8
  %cmp1615 = icmp eq i32 %v1614, 0
  %cv1616 = zext i1 %cmp1615 to i32
  store i32 %cv1616, ptr %slot117, align 8
  %v1617 = load i32, ptr %slot115, align 8
  %v1618 = load i32, ptr %slot117, align 8
  %op1619 = and i32 %v1617, %v1618
  store i32 %op1619, ptr %slot118, align 8
  %v1620 = load i32, ptr %slot118, align 8
  %cv1621 = zext i32 %v1620 to i64
  %cond1622 = icmp ne i64 %cv1621, 0
  br i1 %cond1622, label %bb_rcprivateown120, label %bb_rcprivateloan120
bb_rcprivateown120:
  %v1623 = load i64, ptr %slot29, align 8
  store i64 %v1623, ptr %slot119, align 8
  %v1624 = load i64, ptr %slot57, align 8
  store i64 %v1624, ptr %slot120, align 8
  %v1625 = load i64, ptr %slot114, align 8
  %v1626 = load i64, ptr %slot119, align 8
  %op1627 = sub i64 %v1625, %v1626
  store i64 %op1627, ptr %slot121, align 8
  %v1628 = load i64, ptr %slot119, align 8
  %v1629 = load i64, ptr %slot114, align 8
  %op1630 = sub i64 %v1628, %v1629
  store i64 %op1630, ptr %slot122, align 8
  %v1631 = load i64, ptr %slot121, align 8
  %cmp1632 = icmp ult i64 %v1631, 8
  %cv1633 = zext i1 %cmp1632 to i32
  store i32 %cv1633, ptr %slot123, align 8
  %v1634 = load i64, ptr %slot122, align 8
  %cmp1635 = icmp ult i64 %v1634, 8
  %cv1636 = zext i1 %cmp1635 to i32
  store i32 %cv1636, ptr %slot124, align 8
  %v1637 = load i32, ptr %slot123, align 8
  %v1638 = load i32, ptr %slot124, align 8
  %op1639 = or i32 %v1637, %v1638
  store i32 %op1639, ptr %slot125, align 8
  %v1640 = load i32, ptr %slot125, align 8
  %cv1641 = zext i32 %v1640 to i64
  %cond1642 = icmp ne i64 %cv1641, 0
  br i1 %cond1642, label %bb_rcmoveslow123, label %bb_rcmovecheck123
bb_rcmovecheck123:
  %v1643 = load i64, ptr %slot114, align 8
  %p1645 = inttoptr i64 %v1643 to ptr
  %gep1646 = getelementptr i8, ptr %p1645, i64 0
  %op1644 = ptrtoint ptr %gep1646 to i64
  store i64 %op1644, ptr %slot126, align 8
  %v1647 = load i64, ptr %slot126, align 8
  %p1648 = inttoptr i64 %v1647 to ptr
  %ld1649 = load i64, ptr %p1648, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1649, ptr %slot127, align 8
  %v1650 = load i64, ptr %slot127, align 8
  %cmp1651 = icmp ne i64 %v1650, 0
  %cv1652 = zext i1 %cmp1651 to i32
  store i32 %cv1652, ptr %slot128, align 8
  %v1653 = load i32, ptr %slot128, align 8
  %cv1654 = zext i32 %v1653 to i64
  %cond1655 = icmp ne i64 %cv1654, 0
  br i1 %cond1655, label %bb_rcmoveheader131, label %bb_rcmovenext131
bb_rcmoveheader131:
  %v1656 = load i64, ptr %slot127, align 8
  %op1657 = sub i64 %v1656, 16
  store i64 %op1657, ptr %slot129, align 8
  %v1658 = load i64, ptr %slot127, align 8
  %p1659 = inttoptr i64 %v1658 to ptr
  %rgep1660 = getelementptr i8, ptr %p1659, i64 -16
  %ld1661 = load i64, ptr %rgep1660, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1661, ptr %slot130, align 8
  %v1662 = load i64, ptr %slot130, align 8
  %op1663 = and i64 %v1662, 5764607523034234881
  store i64 %op1663, ptr %slot131, align 8
  %v1664 = load i64, ptr %slot131, align 8
  %cmp1665 = icmp ne i64 %v1664, 0
  %cv1666 = zext i1 %cmp1665 to i32
  store i32 %cv1666, ptr %slot132, align 8
  %v1667 = load i32, ptr %slot132, align 8
  %cv1668 = zext i32 %v1667 to i64
  %cond1669 = icmp ne i64 %cv1668, 0
  br i1 %cond1669, label %bb_rcmoveslow123, label %bb_rcmovenext131
bb_rcmovenext131:
  %v1670 = load i64, ptr %slot114, align 8
  %v1671 = load i64, ptr %slot119, align 8
  %p1672 = inttoptr i64 %v1670 to ptr
  %p1673 = inttoptr i64 %v1671 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1673, ptr %p1672, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1674 = load i64, ptr %slot114, align 8
  %p1675 = inttoptr i64 %v1674 to ptr
  store i64 0, ptr %p1675, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved123
bb_rcmoveslow123:
  %v1676 = load i64, ptr %slot56, align 8
  %v1677 = load i64, ptr %slot119, align 8
  %v1678 = load i64, ptr %slot114, align 8
  %v1679 = load i64, ptr %slot120, align 8
  %cv1680 = trunc i64 %v1679 to i32
  %call1681 = call i32 @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_take(i64 %v1676, i64 %v1677, i64 %v1678, i32 %cv1680) nomerge, !dbg !120
  store i32 %call1681, ptr %slot133, align 8
  %v1682 = load i32, ptr %slot133, align 8
  %cv1683 = zext i32 %v1682 to i64
  %cond1684 = icmp ne i64 %cv1683, 0
  br i1 %cond1684, label %bb_rcsuccess138, label %bb_rcfailure138
bb_rcfailure138:
  %v1685 = load i64, ptr %slot56, align 8
  %p1686 = inttoptr i64 %v1685 to ptr
  %call1687 = call i32 @myl_rc_take_failure(ptr %p1686) nomerge, !dbg !120
  store i32 %call1687, ptr %slot134, align 8
  %v1688 = load i64, ptr %slot1, align 8
  %p1689 = inttoptr i64 %v1688 to ptr
  %v1690 = load i32, ptr %slot134, align 8
  %call1691 = call i32 @myl_qbe_rc_status(ptr %p1689, i32 %v1690) nomerge, !dbg !120
  store i32 %call1691, ptr %slot135, align 8
  br label %bb_failure
bb_rcsuccess138:
  br label %bb_rcmoved123
bb_rcmoved123:
  %v1692 = load i64, ptr %slot16, align 8
  %p1693 = inttoptr i64 %v1692 to ptr
  store i32 0, ptr %p1693, align 4, !alias.scope !3, !noalias !4
  %v1694 = load i64, ptr %slot20, align 8
  %p1695 = inttoptr i64 %v1694 to ptr
  store i32 2, ptr %p1695, align 4, !alias.scope !3, !noalias !4
  %v1696 = load i64, ptr %slot19, align 8
  %p1697 = inttoptr i64 %v1696 to ptr
  store i32 1, ptr %p1697, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared120
bb_rcprivateloan120:
  %v1698 = load i64, ptr %slot16, align 8
  %p1699 = inttoptr i64 %v1698 to ptr
  %ld1700 = load i32, ptr %p1699, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1700, ptr %slot136, align 8
  %v1701 = load i64, ptr %slot17, align 8
  %p1702 = inttoptr i64 %v1701 to ptr
  %ld1703 = load i32, ptr %p1702, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1703, ptr %slot137, align 8
  %v1704 = load i32, ptr %slot137, align 8
  %cmp1705 = icmp eq i32 %v1704, 16
  %cv1706 = zext i1 %cmp1705 to i32
  store i32 %cv1706, ptr %slot138, align 8
  %v1707 = load i32, ptr %slot138, align 8
  %v1708 = load i32, ptr %slot136, align 8
  %op1709 = and i32 %v1707, %v1708
  store i32 %op1709, ptr %slot138, align 8
  %v1710 = load i32, ptr %slot138, align 8
  %cv1711 = zext i32 %v1710 to i64
  %cond1712 = icmp ne i64 %cv1711, 0
  br i1 %cond1712, label %bb_rcprivatemove120, label %bb_rcprivatenew120
bb_rcprivatemove120:
  %v1713 = load i64, ptr %slot29, align 8
  store i64 %v1713, ptr %slot139, align 8
  %v1714 = load i64, ptr %slot114, align 8
  %v1715 = load i64, ptr %slot139, align 8
  %p1716 = inttoptr i64 %v1714 to ptr
  %p1717 = inttoptr i64 %v1715 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p1717, ptr %p1716, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v1718 = load i64, ptr %slot114, align 8
  %p1719 = inttoptr i64 %v1718 to ptr
  store i64 0, ptr %p1719, align 8, !alias.scope !3, !noalias !4
  %v1720 = load i64, ptr %slot20, align 8
  %p1721 = inttoptr i64 %v1720 to ptr
  store i32 2, ptr %p1721, align 4, !alias.scope !3, !noalias !4
  %v1722 = load i64, ptr %slot20, align 8
  %p1723 = inttoptr i64 %v1722 to ptr
  store i32 16, ptr %p1723, align 4, !alias.scope !3, !noalias !4
  %v1724 = load i64, ptr %slot19, align 8
  %p1725 = inttoptr i64 %v1724 to ptr
  store i32 1, ptr %p1725, align 4, !alias.scope !3, !noalias !4
  %v1726 = load i64, ptr %slot16, align 8
  %p1727 = inttoptr i64 %v1726 to ptr
  store i32 0, ptr %p1727, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprivateprepared120
bb_rcprivatenew120:
  %v1728 = load i64, ptr %slot29, align 8
  store i64 %v1728, ptr %slot140, align 8
  %v1729 = load i64, ptr %slot114, align 8
  %p1730 = inttoptr i64 %v1729 to ptr
  %ld1731 = load i64, ptr %p1730, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1731, ptr %slot141, align 8
  %v1732 = load i64, ptr %slot141, align 8
  %cmp1733 = icmp ne i64 %v1732, 0
  %cv1734 = zext i1 %cmp1733 to i32
  store i32 %cv1734, ptr %slot142, align 8
  %v1735 = load i32, ptr %slot142, align 8
  %cv1736 = zext i32 %v1735 to i64
  %cond1737 = icmp ne i64 %cv1736, 0
  br i1 %cond1737, label %bb_rcgnn156, label %bb_rcgstore156
bb_rcgnn156:
  %v1738 = load i64, ptr %slot141, align 8
  %op1739 = sub i64 %v1738, 16
  store i64 %op1739, ptr %slot143, align 8
  %v1740 = load i64, ptr %slot141, align 8
  %p1741 = inttoptr i64 %v1740 to ptr
  %rgep1742 = getelementptr i8, ptr %p1741, i64 -16
  %ld1743 = load i64, ptr %rgep1742, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1743, ptr %slot144, align 8
  %v1744 = load i64, ptr %slot144, align 8
  %op1745 = and i64 %v1744, 4611686018427387906
  store i64 %op1745, ptr %slot145, align 8
  %v1746 = load i64, ptr %slot145, align 8
  %cmp1747 = icmp ne i64 %v1746, 0
  %cv1748 = zext i1 %cmp1747 to i32
  store i32 %cv1748, ptr %slot146, align 8
  %v1749 = load i32, ptr %slot146, align 8
  %cv1750 = zext i32 %v1749 to i64
  %cond1751 = icmp ne i64 %cv1750, 0
  br i1 %cond1751, label %bb_rcgstore156, label %bb_rcginc156
bb_rcginc156:
  %v1752 = load i64, ptr %slot141, align 8
  %op1753 = sub i64 %v1752, 24
  store i64 %op1753, ptr %slot147, align 8
  %v1754 = load i64, ptr %slot141, align 8
  %p1755 = inttoptr i64 %v1754 to ptr
  %rgep1756 = getelementptr i8, ptr %p1755, i64 -24
  %ld1757 = load i64, ptr %rgep1756, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1757, ptr %slot148, align 8
  %v1758 = load i64, ptr %slot148, align 8
  %op1759 = add i64 %v1758, 1
  store i64 %op1759, ptr %slot149, align 8
  %v1760 = load i64, ptr %slot149, align 8
  %cmp1761 = icmp eq i64 %v1760, 0
  %cv1762 = zext i1 %cmp1761 to i32
  store i32 %cv1762, ptr %slot150, align 8
  %v1763 = load i32, ptr %slot150, align 8
  %cv1764 = zext i32 %v1763 to i64
  %cond1765 = icmp ne i64 %cv1764, 0
  br i1 %cond1765, label %bb_rcglimit156, label %bb_rcgcapacity156
bb_rcglimit156:
  %v1766 = load i64, ptr %slot1, align 8
  %p1767 = inttoptr i64 %v1766 to ptr
  %call1768 = call i32 @myl_qbe_rc_status(ptr %p1767, i32 2) nomerge, !dbg !120
  store i32 %call1768, ptr %slot151, align 8
  br label %bb_failure
bb_rcgcapacity156:
  %v1769 = load i64, ptr %slot149, align 8
  %v1770 = load i64, ptr %slot141, align 8
  %p1771 = inttoptr i64 %v1770 to ptr
  %rgep1772 = getelementptr i8, ptr %p1771, i64 -24
  store i64 %v1769, ptr %rgep1772, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore156
bb_rcgstore156:
  %v1773 = load i64, ptr %slot141, align 8
  %v1774 = load i64, ptr %slot140, align 8
  %p1775 = inttoptr i64 %v1774 to ptr
  store i64 %v1773, ptr %p1775, align 8, !alias.scope !3, !noalias !4
  %v1776 = load i64, ptr %slot20, align 8
  %p1777 = inttoptr i64 %v1776 to ptr
  store i32 2, ptr %p1777, align 4, !alias.scope !3, !noalias !4
  %v1778 = load i64, ptr %slot20, align 8
  %p1779 = inttoptr i64 %v1778 to ptr
  store i32 16, ptr %p1779, align 4, !alias.scope !3, !noalias !4
  %v1780 = load i64, ptr %slot19, align 8
  %p1781 = inttoptr i64 %v1780 to ptr
  store i32 1, ptr %p1781, align 4, !alias.scope !3, !noalias !4
  %v1782 = load i64, ptr %slot16, align 8
  %p1783 = inttoptr i64 %v1782 to ptr
  %ld1784 = load i32, ptr %p1783, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1784, ptr %slot152, align 8
  %v1785 = load i32, ptr %slot152, align 8
  %cv1786 = zext i32 %v1785 to i64
  %cond1787 = icmp ne i64 %cv1786, 0
  br i1 %cond1787, label %bb_rcslotdrop172, label %bb_rcslotdone172
bb_rcslotdrop172:
  %v1788 = load i64, ptr %slot16, align 8
  %p1789 = inttoptr i64 %v1788 to ptr
  store i32 0, ptr %p1789, align 4, !alias.scope !3, !noalias !4
  %v1790 = load i64, ptr %slot24, align 8
  store i64 %v1790, ptr %slot153, align 8
  %v1791 = load i64, ptr %slot17, align 8
  %p1792 = inttoptr i64 %v1791 to ptr
  %ld1793 = load i32, ptr %p1792, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1793, ptr %slot154, align 8
  %v1794 = load i32, ptr %slot154, align 8
  %op1795 = and i32 %v1794, 28
  store i32 %op1795, ptr %slot155, align 8
  %v1796 = load i32, ptr %slot155, align 8
  %cv1797 = zext i32 %v1796 to i64
  %cond1798 = icmp ne i64 %cv1797, 0
  br i1 %cond1798, label %bb_rcslotrole172, label %bb_rcslotowner172
bb_rcslotrole172:
  %v1799 = load i64, ptr %slot56, align 8
  store i64 %v1799, ptr %slot156, align 8
  %v1800 = load i64, ptr %slot153, align 8
  %p1801 = inttoptr i64 %v1800 to ptr
  %ld1802 = load i64, ptr %p1801, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1802, ptr %slot157, align 8
  %v1803 = load i64, ptr %slot157, align 8
  %cmp1804 = icmp ne i64 %v1803, 0
  %cv1805 = zext i1 %cmp1804 to i32
  store i32 %cv1805, ptr %slot158, align 8
  %v1806 = load i32, ptr %slot158, align 8
  %cv1807 = zext i32 %v1806 to i64
  %cond1808 = icmp ne i64 %cv1807, 0
  br i1 %cond1808, label %bb_rcgnn188, label %bb_rcgdone188
bb_rcgnn188:
  %v1809 = load i64, ptr %slot157, align 8
  %op1810 = sub i64 %v1809, 16
  store i64 %op1810, ptr %slot159, align 8
  %v1811 = load i64, ptr %slot157, align 8
  %p1812 = inttoptr i64 %v1811 to ptr
  %rgep1813 = getelementptr i8, ptr %p1812, i64 -16
  %ld1814 = load i64, ptr %rgep1813, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1814, ptr %slot160, align 8
  %v1815 = load i64, ptr %slot160, align 8
  %op1816 = and i64 %v1815, 4611686018427387906
  store i64 %op1816, ptr %slot161, align 8
  %v1817 = load i64, ptr %slot161, align 8
  %cmp1818 = icmp ne i64 %v1817, 0
  %cv1819 = zext i1 %cmp1818 to i32
  store i32 %cv1819, ptr %slot162, align 8
  %v1820 = load i32, ptr %slot162, align 8
  %cv1821 = zext i32 %v1820 to i64
  %cond1822 = icmp ne i64 %cv1821, 0
  br i1 %cond1822, label %bb_rcgclear188, label %bb_rcgcounted188
bb_rcgcounted188:
  %v1823 = load i64, ptr %slot157, align 8
  %op1824 = sub i64 %v1823, 24
  store i64 %op1824, ptr %slot163, align 8
  %v1825 = load i64, ptr %slot157, align 8
  %p1826 = inttoptr i64 %v1825 to ptr
  %rgep1827 = getelementptr i8, ptr %p1826, i64 -24
  %ld1828 = load i64, ptr %rgep1827, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1828, ptr %slot164, align 8
  %v1829 = load i64, ptr %slot164, align 8
  %op1830 = sub i64 %v1829, 1
  store i64 %op1830, ptr %slot165, align 8
  %v1831 = load i64, ptr %slot165, align 8
  %cmp1832 = icmp eq i64 %v1831, 0
  %cv1833 = zext i1 %cmp1832 to i32
  store i32 %cv1833, ptr %slot166, align 8
  %v1834 = load i32, ptr %slot166, align 8
  %cv1835 = zext i32 %v1834 to i64
  %cond1836 = icmp ne i64 %cv1835, 0
  br i1 %cond1836, label %bb_rcglast188, label %bb_rcgdec188
bb_rcglast188:
  %v1837 = load i64, ptr %slot157, align 8
  %op1838 = sub i64 %v1837, 32
  store i64 %op1838, ptr %slot167, align 8
  %v1839 = load i64, ptr %slot157, align 8
  %p1840 = inttoptr i64 %v1839 to ptr
  %rgep1841 = getelementptr i8, ptr %p1840, i64 -32
  %ld1842 = load i64, ptr %rgep1841, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1842, ptr %slot168, align 8
  %v1843 = load i64, ptr %slot168, align 8
  %cmp1844 = icmp ne i64 %v1843, 0
  %cv1845 = zext i1 %cmp1844 to i32
  store i32 %cv1845, ptr %slot169, align 8
  %v1846 = load i32, ptr %slot169, align 8
  %cv1847 = zext i32 %v1846 to i64
  %cond1848 = icmp ne i64 %cv1847, 0
  br i1 %cond1848, label %bb_rcgdec188, label %bb_rcgslow188
bb_rcgslow188:
  %v1849 = load i64, ptr %slot156, align 8
  %v1850 = load i64, ptr %slot153, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64 %v1849, i64 %v1850) nomerge, !dbg !120
  br label %bb_rcgdone188
bb_rcgdec188:
  %v1851 = load i64, ptr %slot165, align 8
  %v1852 = load i64, ptr %slot157, align 8
  %p1853 = inttoptr i64 %v1852 to ptr
  %rgep1854 = getelementptr i8, ptr %p1853, i64 -24
  store i64 %v1851, ptr %rgep1854, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear188
bb_rcgclear188:
  %v1855 = load i64, ptr %slot153, align 8
  %p1856 = inttoptr i64 %v1855 to ptr
  store i64 0, ptr %p1856, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone188
bb_rcgdone188:
  br label %bb_rcslotdone172
bb_rcslotowner172:
  %v1857 = load i64, ptr %slot56, align 8
  store i64 %v1857, ptr %slot170, align 8
  %v1858 = load i64, ptr %slot153, align 8
  %p1859 = inttoptr i64 %v1858 to ptr
  %ld1860 = load i64, ptr %p1859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1860, ptr %slot171, align 8
  %v1861 = load i64, ptr %slot171, align 8
  %cmp1862 = icmp ne i64 %v1861, 0
  %cv1863 = zext i1 %cmp1862 to i32
  store i32 %cv1863, ptr %slot172, align 8
  %v1864 = load i32, ptr %slot172, align 8
  %cv1865 = zext i32 %v1864 to i64
  %cond1866 = icmp ne i64 %cv1865, 0
  br i1 %cond1866, label %bb_rcgnn203, label %bb_rcgdone203
bb_rcgnn203:
  %v1867 = load i64, ptr %slot171, align 8
  %op1868 = sub i64 %v1867, 16
  store i64 %op1868, ptr %slot173, align 8
  %v1869 = load i64, ptr %slot171, align 8
  %p1870 = inttoptr i64 %v1869 to ptr
  %rgep1871 = getelementptr i8, ptr %p1870, i64 -16
  %ld1872 = load i64, ptr %rgep1871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1872, ptr %slot174, align 8
  %v1873 = load i64, ptr %slot174, align 8
  %op1874 = and i64 %v1873, 4611686018427387906
  store i64 %op1874, ptr %slot175, align 8
  %v1875 = load i64, ptr %slot175, align 8
  %cmp1876 = icmp ne i64 %v1875, 0
  %cv1877 = zext i1 %cmp1876 to i32
  store i32 %cv1877, ptr %slot176, align 8
  %v1878 = load i32, ptr %slot176, align 8
  %cv1879 = zext i32 %v1878 to i64
  %cond1880 = icmp ne i64 %cv1879, 0
  br i1 %cond1880, label %bb_rcgclear203, label %bb_rcgcounted203
bb_rcgcounted203:
  %v1881 = load i64, ptr %slot171, align 8
  %op1882 = sub i64 %v1881, 32
  store i64 %op1882, ptr %slot177, align 8
  %v1883 = load i64, ptr %slot171, align 8
  %p1884 = inttoptr i64 %v1883 to ptr
  %rgep1885 = getelementptr i8, ptr %p1884, i64 -32
  %ld1886 = load i64, ptr %rgep1885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1886, ptr %slot178, align 8
  %v1887 = load i64, ptr %slot178, align 8
  %op1888 = sub i64 %v1887, 1
  store i64 %op1888, ptr %slot179, align 8
  %v1889 = load i64, ptr %slot179, align 8
  %cmp1890 = icmp eq i64 %v1889, 0
  %cv1891 = zext i1 %cmp1890 to i32
  store i32 %cv1891, ptr %slot180, align 8
  %v1892 = load i32, ptr %slot180, align 8
  %cv1893 = zext i32 %v1892 to i64
  %cond1894 = icmp ne i64 %cv1893, 0
  br i1 %cond1894, label %bb_rcglast203, label %bb_rcgdec203
bb_rcglast203:
  %v1895 = load i64, ptr %slot171, align 8
  %op1896 = sub i64 %v1895, 24
  store i64 %op1896, ptr %slot181, align 8
  %v1897 = load i64, ptr %slot171, align 8
  %p1898 = inttoptr i64 %v1897 to ptr
  %rgep1899 = getelementptr i8, ptr %p1898, i64 -24
  %ld1900 = load i64, ptr %rgep1899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1900, ptr %slot182, align 8
  %v1901 = load i64, ptr %slot182, align 8
  %cmp1902 = icmp ne i64 %v1901, 0
  %cv1903 = zext i1 %cmp1902 to i32
  store i32 %cv1903, ptr %slot183, align 8
  %v1904 = load i32, ptr %slot183, align 8
  %cv1905 = zext i32 %v1904 to i64
  %cond1906 = icmp ne i64 %cv1905, 0
  br i1 %cond1906, label %bb_rcgdec203, label %bb_rcgslow203
bb_rcgslow203:
  %v1907 = load i64, ptr %slot170, align 8
  %v1908 = load i64, ptr %slot153, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64 %v1907, i64 %v1908) nomerge, !dbg !120
  br label %bb_rcgdone203
bb_rcgdec203:
  %v1909 = load i64, ptr %slot179, align 8
  %v1910 = load i64, ptr %slot171, align 8
  %p1911 = inttoptr i64 %v1910 to ptr
  %rgep1912 = getelementptr i8, ptr %p1911, i64 -32
  store i64 %v1909, ptr %rgep1912, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear203
bb_rcgclear203:
  %v1913 = load i64, ptr %slot153, align 8
  %p1914 = inttoptr i64 %v1913 to ptr
  store i64 0, ptr %p1914, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone203
bb_rcgdone203:
  br label %bb_rcslotdone172
bb_rcslotdone172:
  br label %bb_rcprivateprepared120
bb_rcprivateprepared120:
  %v1915 = load i64, ptr %slot7, align 8
  %p1916 = inttoptr i64 %v1915 to ptr
  %ld1917 = load i32, ptr %p1916, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1917, ptr %slot184, align 8
  %v1918 = load i32, ptr %slot184, align 8
  %cv1919 = zext i32 %v1918 to i64
  %cond1920 = icmp ne i64 %cv1919, 0
  br i1 %cond1920, label %bb_rcslotdrop210, label %bb_rcslotdone210
bb_rcslotdrop210:
  %v1921 = load i64, ptr %slot7, align 8
  %p1922 = inttoptr i64 %v1921 to ptr
  store i32 0, ptr %p1922, align 4, !alias.scope !3, !noalias !4
  %v1923 = load i64, ptr %slot37, align 8
  store i64 %v1923, ptr %slot185, align 8
  %v1924 = load i64, ptr %slot8, align 8
  %p1925 = inttoptr i64 %v1924 to ptr
  %ld1926 = load i32, ptr %p1925, align 4, !alias.scope !3, !noalias !4
  store i32 %ld1926, ptr %slot186, align 8
  %v1927 = load i32, ptr %slot186, align 8
  %op1928 = and i32 %v1927, 28
  store i32 %op1928, ptr %slot187, align 8
  %v1929 = load i32, ptr %slot187, align 8
  %cv1930 = zext i32 %v1929 to i64
  %cond1931 = icmp ne i64 %cv1930, 0
  br i1 %cond1931, label %bb_rcslotrole210, label %bb_rcslotowner210
bb_rcslotrole210:
  %v1932 = load i64, ptr %slot56, align 8
  store i64 %v1932, ptr %slot188, align 8
  %v1933 = load i64, ptr %slot185, align 8
  %p1934 = inttoptr i64 %v1933 to ptr
  %ld1935 = load i64, ptr %p1934, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1935, ptr %slot189, align 8
  %v1936 = load i64, ptr %slot189, align 8
  %cmp1937 = icmp ne i64 %v1936, 0
  %cv1938 = zext i1 %cmp1937 to i32
  store i32 %cv1938, ptr %slot190, align 8
  %v1939 = load i32, ptr %slot190, align 8
  %cv1940 = zext i32 %v1939 to i64
  %cond1941 = icmp ne i64 %cv1940, 0
  br i1 %cond1941, label %bb_rcgnn226, label %bb_rcgdone226
bb_rcgnn226:
  %v1942 = load i64, ptr %slot189, align 8
  %op1943 = sub i64 %v1942, 16
  store i64 %op1943, ptr %slot191, align 8
  %v1944 = load i64, ptr %slot189, align 8
  %p1945 = inttoptr i64 %v1944 to ptr
  %rgep1946 = getelementptr i8, ptr %p1945, i64 -16
  %ld1947 = load i64, ptr %rgep1946, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1947, ptr %slot192, align 8
  %v1948 = load i64, ptr %slot192, align 8
  %op1949 = and i64 %v1948, 4611686018427387906
  store i64 %op1949, ptr %slot193, align 8
  %v1950 = load i64, ptr %slot193, align 8
  %cmp1951 = icmp ne i64 %v1950, 0
  %cv1952 = zext i1 %cmp1951 to i32
  store i32 %cv1952, ptr %slot194, align 8
  %v1953 = load i32, ptr %slot194, align 8
  %cv1954 = zext i32 %v1953 to i64
  %cond1955 = icmp ne i64 %cv1954, 0
  br i1 %cond1955, label %bb_rcgclear226, label %bb_rcgcounted226
bb_rcgcounted226:
  %v1956 = load i64, ptr %slot189, align 8
  %op1957 = sub i64 %v1956, 24
  store i64 %op1957, ptr %slot195, align 8
  %v1958 = load i64, ptr %slot189, align 8
  %p1959 = inttoptr i64 %v1958 to ptr
  %rgep1960 = getelementptr i8, ptr %p1959, i64 -24
  %ld1961 = load i64, ptr %rgep1960, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1961, ptr %slot196, align 8
  %v1962 = load i64, ptr %slot196, align 8
  %op1963 = sub i64 %v1962, 1
  store i64 %op1963, ptr %slot197, align 8
  %v1964 = load i64, ptr %slot197, align 8
  %cmp1965 = icmp eq i64 %v1964, 0
  %cv1966 = zext i1 %cmp1965 to i32
  store i32 %cv1966, ptr %slot198, align 8
  %v1967 = load i32, ptr %slot198, align 8
  %cv1968 = zext i32 %v1967 to i64
  %cond1969 = icmp ne i64 %cv1968, 0
  br i1 %cond1969, label %bb_rcglast226, label %bb_rcgdec226
bb_rcglast226:
  %v1970 = load i64, ptr %slot189, align 8
  %op1971 = sub i64 %v1970, 32
  store i64 %op1971, ptr %slot199, align 8
  %v1972 = load i64, ptr %slot189, align 8
  %p1973 = inttoptr i64 %v1972 to ptr
  %rgep1974 = getelementptr i8, ptr %p1973, i64 -32
  %ld1975 = load i64, ptr %rgep1974, align 8, !alias.scope !9, !noalias !10
  store i64 %ld1975, ptr %slot200, align 8
  %v1976 = load i64, ptr %slot200, align 8
  %cmp1977 = icmp ne i64 %v1976, 0
  %cv1978 = zext i1 %cmp1977 to i32
  store i32 %cv1978, ptr %slot201, align 8
  %v1979 = load i32, ptr %slot201, align 8
  %cv1980 = zext i32 %v1979 to i64
  %cond1981 = icmp ne i64 %cv1980, 0
  br i1 %cond1981, label %bb_rcgdec226, label %bb_rcgslow226
bb_rcgslow226:
  %v1982 = load i64, ptr %slot188, align 8
  %v1983 = load i64, ptr %slot185, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64 %v1982, i64 %v1983) nomerge, !dbg !120
  br label %bb_rcgdone226
bb_rcgdec226:
  %v1984 = load i64, ptr %slot197, align 8
  %v1985 = load i64, ptr %slot189, align 8
  %p1986 = inttoptr i64 %v1985 to ptr
  %rgep1987 = getelementptr i8, ptr %p1986, i64 -24
  store i64 %v1984, ptr %rgep1987, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear226
bb_rcgclear226:
  %v1988 = load i64, ptr %slot185, align 8
  %p1989 = inttoptr i64 %v1988 to ptr
  store i64 0, ptr %p1989, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone226
bb_rcgdone226:
  br label %bb_rcslotdone210
bb_rcslotowner210:
  %v1990 = load i64, ptr %slot56, align 8
  store i64 %v1990, ptr %slot202, align 8
  %v1991 = load i64, ptr %slot185, align 8
  %p1992 = inttoptr i64 %v1991 to ptr
  %ld1993 = load i64, ptr %p1992, align 8, !alias.scope !3, !noalias !4
  store i64 %ld1993, ptr %slot203, align 8
  %v1994 = load i64, ptr %slot203, align 8
  %cmp1995 = icmp ne i64 %v1994, 0
  %cv1996 = zext i1 %cmp1995 to i32
  store i32 %cv1996, ptr %slot204, align 8
  %v1997 = load i32, ptr %slot204, align 8
  %cv1998 = zext i32 %v1997 to i64
  %cond1999 = icmp ne i64 %cv1998, 0
  br i1 %cond1999, label %bb_rcgnn241, label %bb_rcgdone241
bb_rcgnn241:
  %v2000 = load i64, ptr %slot203, align 8
  %op2001 = sub i64 %v2000, 16
  store i64 %op2001, ptr %slot205, align 8
  %v2002 = load i64, ptr %slot203, align 8
  %p2003 = inttoptr i64 %v2002 to ptr
  %rgep2004 = getelementptr i8, ptr %p2003, i64 -16
  %ld2005 = load i64, ptr %rgep2004, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2005, ptr %slot206, align 8
  %v2006 = load i64, ptr %slot206, align 8
  %op2007 = and i64 %v2006, 4611686018427387906
  store i64 %op2007, ptr %slot207, align 8
  %v2008 = load i64, ptr %slot207, align 8
  %cmp2009 = icmp ne i64 %v2008, 0
  %cv2010 = zext i1 %cmp2009 to i32
  store i32 %cv2010, ptr %slot208, align 8
  %v2011 = load i32, ptr %slot208, align 8
  %cv2012 = zext i32 %v2011 to i64
  %cond2013 = icmp ne i64 %cv2012, 0
  br i1 %cond2013, label %bb_rcgclear241, label %bb_rcgcounted241
bb_rcgcounted241:
  %v2014 = load i64, ptr %slot203, align 8
  %op2015 = sub i64 %v2014, 32
  store i64 %op2015, ptr %slot209, align 8
  %v2016 = load i64, ptr %slot203, align 8
  %p2017 = inttoptr i64 %v2016 to ptr
  %rgep2018 = getelementptr i8, ptr %p2017, i64 -32
  %ld2019 = load i64, ptr %rgep2018, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2019, ptr %slot210, align 8
  %v2020 = load i64, ptr %slot210, align 8
  %op2021 = sub i64 %v2020, 1
  store i64 %op2021, ptr %slot211, align 8
  %v2022 = load i64, ptr %slot211, align 8
  %cmp2023 = icmp eq i64 %v2022, 0
  %cv2024 = zext i1 %cmp2023 to i32
  store i32 %cv2024, ptr %slot212, align 8
  %v2025 = load i32, ptr %slot212, align 8
  %cv2026 = zext i32 %v2025 to i64
  %cond2027 = icmp ne i64 %cv2026, 0
  br i1 %cond2027, label %bb_rcglast241, label %bb_rcgdec241
bb_rcglast241:
  %v2028 = load i64, ptr %slot203, align 8
  %op2029 = sub i64 %v2028, 24
  store i64 %op2029, ptr %slot213, align 8
  %v2030 = load i64, ptr %slot203, align 8
  %p2031 = inttoptr i64 %v2030 to ptr
  %rgep2032 = getelementptr i8, ptr %p2031, i64 -24
  %ld2033 = load i64, ptr %rgep2032, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2033, ptr %slot214, align 8
  %v2034 = load i64, ptr %slot214, align 8
  %cmp2035 = icmp ne i64 %v2034, 0
  %cv2036 = zext i1 %cmp2035 to i32
  store i32 %cv2036, ptr %slot215, align 8
  %v2037 = load i32, ptr %slot215, align 8
  %cv2038 = zext i32 %v2037 to i64
  %cond2039 = icmp ne i64 %cv2038, 0
  br i1 %cond2039, label %bb_rcgdec241, label %bb_rcgslow241
bb_rcgslow241:
  %v2040 = load i64, ptr %slot202, align 8
  %v2041 = load i64, ptr %slot185, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64 %v2040, i64 %v2041) nomerge, !dbg !120
  br label %bb_rcgdone241
bb_rcgdec241:
  %v2042 = load i64, ptr %slot211, align 8
  %v2043 = load i64, ptr %slot203, align 8
  %p2044 = inttoptr i64 %v2043 to ptr
  %rgep2045 = getelementptr i8, ptr %p2044, i64 -32
  store i64 %v2042, ptr %rgep2045, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear241
bb_rcgclear241:
  %v2046 = load i64, ptr %slot185, align 8
  %p2047 = inttoptr i64 %v2046 to ptr
  store i64 0, ptr %p2047, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone241
bb_rcgdone241:
  br label %bb_rcslotdone210
bb_rcslotdone210:
  %v2048 = load i64, ptr %slot37, align 8
  store i64 %v2048, ptr %slot216, align 8
  %v2049 = load i64, ptr %slot29, align 8
  store i64 %v2049, ptr %slot217, align 8
  %v2050 = load i64, ptr %slot217, align 8
  %v2051 = load i64, ptr %slot216, align 8
  %p2052 = inttoptr i64 %v2050 to ptr
  %p2053 = inttoptr i64 %v2051 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2053, ptr %p2052, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2054 = load i64, ptr %slot19, align 8
  %p2055 = inttoptr i64 %v2054 to ptr
  store i32 0, ptr %p2055, align 4, !alias.scope !3, !noalias !4
  %v2056 = load i64, ptr %slot8, align 8
  %p2057 = inttoptr i64 %v2056 to ptr
  store i32 2, ptr %p2057, align 4, !alias.scope !3, !noalias !4
  %v2058 = load i64, ptr %slot20, align 8
  %p2059 = inttoptr i64 %v2058 to ptr
  %ld2060 = load i32, ptr %p2059, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2060, ptr %slot218, align 8
  %v2061 = load i32, ptr %slot218, align 8
  %v2062 = load i64, ptr %slot8, align 8
  %p2063 = inttoptr i64 %v2062 to ptr
  store i32 %v2061, ptr %p2063, align 4, !alias.scope !3, !noalias !4
  %v2064 = load i64, ptr %slot7, align 8
  %p2065 = inttoptr i64 %v2064 to ptr
  store i32 1, ptr %p2065, align 4, !alias.scope !3, !noalias !4
  %v2066 = load i64, ptr %slot37, align 8
  %p2067 = inttoptr i64 %v2066 to ptr
  %ld2068 = load i64, ptr %p2067, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2068, ptr %slot219, align 8
  %v2069 = load i64, ptr %slot219, align 8
  %v2070 = load i64, ptr %slot44, align 8
  %p2071 = inttoptr i64 %v2070 to ptr
  store i64 %v2069, ptr %p2071, align 8, !alias.scope !3, !noalias !4
  %v2072 = load i64, ptr %slot45, align 8
  %p2073 = inttoptr i64 %v2072 to ptr
  store i64 0, ptr %p2073, align 8, !alias.scope !3, !noalias !4
  %v2074 = load i64, ptr %slot46, align 8
  %p2075 = inttoptr i64 %v2074 to ptr
  store i64 0, ptr %p2075, align 8, !alias.scope !3, !noalias !4
  %v2076 = load i64, ptr %slot1, align 8
  call void @myl_f_9fc06d0290f8b50ff4ff3bc73e7d23268320ac28e17087c68ac3835de3f54fdc(ptr sret([32 x i8]) align 8 %callresult221, i64 %v2076) nomerge, !dbg !122
  %addr2077 = ptrtoint ptr %callresult221 to i64
  store i64 %addr2077, ptr %slot220, align 8
  %v2078 = load i64, ptr %slot220, align 8
  %v2079 = load i64, ptr %slot47, align 8
  %p2080 = inttoptr i64 %v2079 to ptr
  store i64 %v2078, ptr %p2080, align 8, !alias.scope !3, !noalias !4
  %v2081 = load i64, ptr %slot47, align 8
  %p2082 = inttoptr i64 %v2081 to ptr
  %ld2083 = load i64, ptr %p2082, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2083, ptr %slot222, align 8
  %v2084 = load i64, ptr %slot29, align 8
  store i64 %v2084, ptr %slot223, align 8
  %v2085 = load i64, ptr %slot222, align 8
  %v2086 = load i64, ptr %slot223, align 8
  %p2087 = inttoptr i64 %v2085 to ptr
  %p2088 = inttoptr i64 %v2086 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2088, ptr %p2087, i64 32, i1 false)
  %v2089 = load i64, ptr %slot20, align 8
  %p2090 = inttoptr i64 %v2089 to ptr
  store i32 2, ptr %p2090, align 4, !alias.scope !3, !noalias !4
  %v2091 = load i64, ptr %slot19, align 8
  %p2092 = inttoptr i64 %v2091 to ptr
  store i32 1, ptr %p2092, align 4, !alias.scope !3, !noalias !4
  %v2093 = load i64, ptr %slot25, align 8
  store i64 %v2093, ptr %slot224, align 8
  %v2094 = load i64, ptr %slot29, align 8
  store i64 %v2094, ptr %slot225, align 8
  %v2095 = load i64, ptr %slot225, align 8
  %v2096 = load i64, ptr %slot224, align 8
  %p2097 = inttoptr i64 %v2095 to ptr
  %p2098 = inttoptr i64 %v2096 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2098, ptr %p2097, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v2099 = load i64, ptr %slot20, align 8
  %p2100 = inttoptr i64 %v2099 to ptr
  %ld2101 = load i32, ptr %p2100, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2101, ptr %slot226, align 8
  %v2102 = load i64, ptr %slot19, align 8
  %p2103 = inttoptr i64 %v2102 to ptr
  store i32 0, ptr %p2103, align 4, !alias.scope !3, !noalias !4
  %v2104 = load i64, ptr %slot18, align 8
  %p2105 = inttoptr i64 %v2104 to ptr
  store i32 1, ptr %p2105, align 4, !alias.scope !3, !noalias !4
  %v2106 = load i64, ptr %slot224, align 8
  %v2107 = load i64, ptr %slot47, align 8
  %p2108 = inttoptr i64 %v2107 to ptr
  store i64 %v2106, ptr %p2108, align 8, !alias.scope !3, !noalias !4
  %v2109 = load i64, ptr %slot48, align 8
  store i64 %v2109, ptr %slot227, align 8
  %v2110 = load i64, ptr %slot227, align 8
  %p2111 = inttoptr i64 %v2110 to ptr
  call void @llvm.memset.p0.i64(ptr %p2111, i8 0, i64 312, i1 false), !alias.scope !3, !noalias !4, !dbg !124
  %v2112 = load i64, ptr %slot21, align 8
  %p2113 = inttoptr i64 %v2112 to ptr
  store i32 1, ptr %p2113, align 4, !alias.scope !3, !noalias !4
  %v2114 = load i64, ptr %slot57, align 8
  store i64 %v2114, ptr %slot228, align 8
  %v2115 = load i64, ptr %slot41, align 8
  %p2116 = inttoptr i64 %v2115 to ptr
  %ld2117 = load i64, ptr %p2116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2117, ptr %slot229, align 8
  %v2118 = load i64, ptr %slot227, align 8
  %p2120 = inttoptr i64 %v2118 to ptr
  %gep2121 = getelementptr i8, ptr %p2120, i64 0
  %op2119 = ptrtoint ptr %gep2121 to i64
  store i64 %op2119, ptr %slot230, align 8
  %v2122 = load i64, ptr %slot41, align 8
  %p2123 = inttoptr i64 %v2122 to ptr
  %ld2124 = load i64, ptr %p2123, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2124, ptr %slot231, align 8
  %v2125 = load i64, ptr %slot11, align 8
  %p2126 = inttoptr i64 %v2125 to ptr
  %ld2127 = load i32, ptr %p2126, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2127, ptr %slot232, align 8
  %v2128 = load i64, ptr %slot12, align 8
  %p2129 = inttoptr i64 %v2128 to ptr
  %ld2130 = load i32, ptr %p2129, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2130, ptr %slot233, align 8
  %v2131 = load i32, ptr %slot233, align 8
  %op2132 = and i32 %v2131, 24
  store i32 %op2132, ptr %slot233, align 8
  %v2133 = load i32, ptr %slot233, align 8
  %cmp2134 = icmp eq i32 %v2133, 0
  %cv2135 = zext i1 %cmp2134 to i32
  store i32 %cv2135, ptr %slot234, align 8
  %v2136 = load i32, ptr %slot232, align 8
  %v2137 = load i32, ptr %slot234, align 8
  %op2138 = and i32 %v2136, %v2137
  store i32 %op2138, ptr %slot235, align 8
  %v2139 = load i32, ptr %slot235, align 8
  %cv2140 = zext i32 %v2139 to i64
  %cond2141 = icmp ne i64 %cv2140, 0
  br i1 %cond2141, label %bb_rctake273, label %bb_rccopy273
bb_rctake273:
  %v2142 = load i64, ptr %slot29, align 8
  store i64 %v2142, ptr %slot236, align 8
  %v2143 = load i64, ptr %slot57, align 8
  store i64 %v2143, ptr %slot237, align 8
  %v2144 = load i64, ptr %slot56, align 8
  %v2145 = load i64, ptr %slot236, align 8
  %v2146 = load i64, ptr %slot231, align 8
  %v2147 = load i64, ptr %slot237, align 8
  %cv2148 = trunc i64 %v2147 to i32
  %call2149 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64 %v2144, i64 %v2145, i64 %v2146, i32 %cv2148) nomerge, !dbg !124
  store i32 %call2149, ptr %slot238, align 8
  %v2150 = load i32, ptr %slot238, align 8
  %cv2151 = zext i32 %v2150 to i64
  %cond2152 = icmp ne i64 %cv2151, 0
  br i1 %cond2152, label %bb_rcsuccess283, label %bb_rcfailure283
bb_rcfailure283:
  %v2153 = load i64, ptr %slot56, align 8
  %p2154 = inttoptr i64 %v2153 to ptr
  %call2155 = call i32 @myl_rc_take_failure(ptr %p2154) nomerge, !dbg !124
  store i32 %call2155, ptr %slot239, align 8
  %v2156 = load i64, ptr %slot1, align 8
  %p2157 = inttoptr i64 %v2156 to ptr
  %v2158 = load i32, ptr %slot239, align 8
  %call2159 = call i32 @myl_qbe_rc_status(ptr %p2157, i32 %v2158) nomerge, !dbg !124
  store i32 %call2159, ptr %slot240, align 8
  br label %bb_failure
bb_rcsuccess283:
  %v2160 = load i64, ptr %slot11, align 8
  %p2161 = inttoptr i64 %v2160 to ptr
  store i32 0, ptr %p2161, align 4, !alias.scope !3, !noalias !4
  %v2162 = load i64, ptr %slot20, align 8
  %p2163 = inttoptr i64 %v2162 to ptr
  store i32 2, ptr %p2163, align 4, !alias.scope !3, !noalias !4
  %v2164 = load i64, ptr %slot19, align 8
  %p2165 = inttoptr i64 %v2164 to ptr
  store i32 1, ptr %p2165, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared273
bb_rccopy273:
  %v2166 = load i64, ptr %slot29, align 8
  store i64 %v2166, ptr %slot241, align 8
  %v2167 = load i64, ptr %slot57, align 8
  store i64 %v2167, ptr %slot242, align 8
  %v2168 = load i64, ptr %slot56, align 8
  %v2169 = load i64, ptr %slot241, align 8
  %v2170 = load i64, ptr %slot231, align 8
  %v2171 = load i64, ptr %slot242, align 8
  %cv2172 = trunc i64 %v2171 to i32
  %call2173 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_retain(i64 %v2168, i64 %v2169, i64 %v2170, i32 %cv2172) nomerge, !dbg !124
  store i32 %call2173, ptr %slot243, align 8
  %v2174 = load i32, ptr %slot243, align 8
  %cv2175 = zext i32 %v2174 to i64
  %cond2176 = icmp ne i64 %cv2175, 0
  br i1 %cond2176, label %bb_rcsuccess292, label %bb_rcfailure292
bb_rcfailure292:
  %v2177 = load i64, ptr %slot56, align 8
  %p2178 = inttoptr i64 %v2177 to ptr
  %call2179 = call i32 @myl_rc_take_failure(ptr %p2178) nomerge, !dbg !124
  store i32 %call2179, ptr %slot244, align 8
  %v2180 = load i64, ptr %slot1, align 8
  %p2181 = inttoptr i64 %v2180 to ptr
  %v2182 = load i32, ptr %slot244, align 8
  %call2183 = call i32 @myl_qbe_rc_status(ptr %p2181, i32 %v2182) nomerge, !dbg !124
  store i32 %call2183, ptr %slot245, align 8
  br label %bb_failure
bb_rcsuccess292:
  %v2184 = load i64, ptr %slot20, align 8
  %p2185 = inttoptr i64 %v2184 to ptr
  store i32 2, ptr %p2185, align 4, !alias.scope !3, !noalias !4
  %v2186 = load i64, ptr %slot19, align 8
  %p2187 = inttoptr i64 %v2186 to ptr
  store i32 1, ptr %p2187, align 4, !alias.scope !3, !noalias !4
  %v2188 = load i64, ptr %slot11, align 8
  %p2189 = inttoptr i64 %v2188 to ptr
  %ld2190 = load i32, ptr %p2189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2190, ptr %slot246, align 8
  %v2191 = load i32, ptr %slot246, align 8
  %cv2192 = zext i32 %v2191 to i64
  %cond2193 = icmp ne i64 %cv2192, 0
  br i1 %cond2193, label %bb_rcslotdrop299, label %bb_rcslotdone299
bb_rcslotdrop299:
  %v2194 = load i64, ptr %slot11, align 8
  %p2195 = inttoptr i64 %v2194 to ptr
  store i32 0, ptr %p2195, align 4, !alias.scope !3, !noalias !4
  %v2196 = load i64, ptr %slot22, align 8
  store i64 %v2196, ptr %slot247, align 8
  %v2197 = load i64, ptr %slot12, align 8
  %p2198 = inttoptr i64 %v2197 to ptr
  %ld2199 = load i32, ptr %p2198, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2199, ptr %slot248, align 8
  %v2200 = load i32, ptr %slot248, align 8
  %op2201 = and i32 %v2200, 28
  store i32 %op2201, ptr %slot249, align 8
  %v2202 = load i32, ptr %slot249, align 8
  %cv2203 = zext i32 %v2202 to i64
  %cond2204 = icmp ne i64 %cv2203, 0
  br i1 %cond2204, label %bb_rcslotrole299, label %bb_rcslotowner299
bb_rcslotrole299:
  %v2205 = load i64, ptr %slot56, align 8
  store i64 %v2205, ptr %slot250, align 8
  %v2206 = load i64, ptr %slot250, align 8
  %v2207 = load i64, ptr %slot247, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v2206, i64 %v2207) nomerge, !dbg !124
  br label %bb_rcslotdone299
bb_rcslotowner299:
  %v2208 = load i64, ptr %slot56, align 8
  store i64 %v2208, ptr %slot251, align 8
  %v2209 = load i64, ptr %slot251, align 8
  %v2210 = load i64, ptr %slot247, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v2209, i64 %v2210) nomerge, !dbg !124
  br label %bb_rcslotdone299
bb_rcslotdone299:
  br label %bb_rcprepared273
bb_rcprepared273:
  %v2211 = load i64, ptr %slot29, align 8
  store i64 %v2211, ptr %slot252, align 8
  %v2212 = load i64, ptr %slot252, align 8
  %v2213 = load i64, ptr %slot230, align 8
  %p2214 = inttoptr i64 %v2212 to ptr
  %p2215 = inttoptr i64 %v2213 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2215, ptr %p2214, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v2216 = load i64, ptr %slot19, align 8
  %p2217 = inttoptr i64 %v2216 to ptr
  store i32 0, ptr %p2217, align 4, !alias.scope !3, !noalias !4
  %v2218 = load i64, ptr %slot42, align 8
  %p2219 = inttoptr i64 %v2218 to ptr
  %ld2220 = load i64, ptr %p2219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2220, ptr %slot253, align 8
  %v2221 = load i64, ptr %slot227, align 8
  %p2223 = inttoptr i64 %v2221 to ptr
  %gep2224 = getelementptr i8, ptr %p2223, i64 208
  %op2222 = ptrtoint ptr %gep2224 to i64
  store i64 %op2222, ptr %slot254, align 8
  %v2225 = load i64, ptr %slot42, align 8
  %p2226 = inttoptr i64 %v2225 to ptr
  %ld2227 = load i64, ptr %p2226, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2227, ptr %slot255, align 8
  %v2228 = load i64, ptr %slot13, align 8
  %p2229 = inttoptr i64 %v2228 to ptr
  %ld2230 = load i32, ptr %p2229, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2230, ptr %slot256, align 8
  %v2231 = load i64, ptr %slot14, align 8
  %p2232 = inttoptr i64 %v2231 to ptr
  %ld2233 = load i32, ptr %p2232, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2233, ptr %slot257, align 8
  %v2234 = load i32, ptr %slot257, align 8
  %op2235 = and i32 %v2234, 24
  store i32 %op2235, ptr %slot257, align 8
  %v2236 = load i32, ptr %slot257, align 8
  %cmp2237 = icmp eq i32 %v2236, 0
  %cv2238 = zext i1 %cmp2237 to i32
  store i32 %cv2238, ptr %slot258, align 8
  %v2239 = load i32, ptr %slot256, align 8
  %v2240 = load i32, ptr %slot258, align 8
  %op2241 = and i32 %v2239, %v2240
  store i32 %op2241, ptr %slot259, align 8
  %v2242 = load i32, ptr %slot259, align 8
  %cv2243 = zext i32 %v2242 to i64
  %cond2244 = icmp ne i64 %cv2243, 0
  br i1 %cond2244, label %bb_rctake311, label %bb_rccopy311
bb_rctake311:
  %v2245 = load i64, ptr %slot29, align 8
  store i64 %v2245, ptr %slot260, align 8
  %v2246 = load i64, ptr %slot57, align 8
  store i64 %v2246, ptr %slot261, align 8
  %v2247 = load i64, ptr %slot255, align 8
  %v2248 = load i64, ptr %slot260, align 8
  %op2249 = sub i64 %v2247, %v2248
  store i64 %op2249, ptr %slot262, align 8
  %v2250 = load i64, ptr %slot260, align 8
  %v2251 = load i64, ptr %slot255, align 8
  %op2252 = sub i64 %v2250, %v2251
  store i64 %op2252, ptr %slot263, align 8
  %v2253 = load i64, ptr %slot262, align 8
  %cmp2254 = icmp ult i64 %v2253, 40
  %cv2255 = zext i1 %cmp2254 to i32
  store i32 %cv2255, ptr %slot264, align 8
  %v2256 = load i64, ptr %slot263, align 8
  %cmp2257 = icmp ult i64 %v2256, 40
  %cv2258 = zext i1 %cmp2257 to i32
  store i32 %cv2258, ptr %slot265, align 8
  %v2259 = load i32, ptr %slot264, align 8
  %v2260 = load i32, ptr %slot265, align 8
  %op2261 = or i32 %v2259, %v2260
  store i32 %op2261, ptr %slot266, align 8
  %v2262 = load i32, ptr %slot266, align 8
  %cv2263 = zext i32 %v2262 to i64
  %cond2264 = icmp ne i64 %cv2263, 0
  br i1 %cond2264, label %bb_rcmoveslow320, label %bb_rcmovecheck320
bb_rcmovecheck320:
  %v2265 = load i64, ptr %slot255, align 8
  %op2266 = add i64 %v2265, 0
  store i64 %op2266, ptr %slot267, align 8
  %v2267 = load i64, ptr %slot267, align 8
  %p2268 = inttoptr i64 %v2267 to ptr
  %ld2269 = load i64, ptr %p2268, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2269, ptr %slot268, align 8
  %v2270 = load i64, ptr %slot268, align 8
  %cmp2271 = icmp ne i64 %v2270, 0
  %cv2272 = zext i1 %cmp2271 to i32
  store i32 %cv2272, ptr %slot269, align 8
  %v2273 = load i32, ptr %slot269, align 8
  %cv2274 = zext i32 %v2273 to i64
  %cond2275 = icmp ne i64 %cv2274, 0
  br i1 %cond2275, label %bb_rcmoveheader328, label %bb_rcmovenext328
bb_rcmoveheader328:
  %v2276 = load i64, ptr %slot268, align 8
  %op2277 = sub i64 %v2276, 16
  store i64 %op2277, ptr %slot270, align 8
  %v2278 = load i64, ptr %slot268, align 8
  %p2279 = inttoptr i64 %v2278 to ptr
  %rgep2280 = getelementptr i8, ptr %p2279, i64 -16
  %ld2281 = load i64, ptr %rgep2280, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2281, ptr %slot271, align 8
  %v2282 = load i64, ptr %slot271, align 8
  %op2283 = and i64 %v2282, 5764607523034234881
  store i64 %op2283, ptr %slot272, align 8
  %v2284 = load i64, ptr %slot272, align 8
  %cmp2285 = icmp ne i64 %v2284, 0
  %cv2286 = zext i1 %cmp2285 to i32
  store i32 %cv2286, ptr %slot273, align 8
  %v2287 = load i32, ptr %slot273, align 8
  %cv2288 = zext i32 %v2287 to i64
  %cond2289 = icmp ne i64 %cv2288, 0
  br i1 %cond2289, label %bb_rcmoveslow320, label %bb_rcmovenext328
bb_rcmovenext328:
  %v2290 = load i64, ptr %slot255, align 8
  %op2291 = add i64 %v2290, 8
  store i64 %op2291, ptr %slot274, align 8
  %v2292 = load i64, ptr %slot274, align 8
  %p2293 = inttoptr i64 %v2292 to ptr
  %ld2294 = load i64, ptr %p2293, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2294, ptr %slot275, align 8
  %v2295 = load i64, ptr %slot275, align 8
  %cmp2296 = icmp ne i64 %v2295, 0
  %cv2297 = zext i1 %cmp2296 to i32
  store i32 %cv2297, ptr %slot276, align 8
  %v2298 = load i32, ptr %slot276, align 8
  %cv2299 = zext i32 %v2298 to i64
  %cond2300 = icmp ne i64 %cv2299, 0
  br i1 %cond2300, label %bb_rcmoveheader336, label %bb_rcmovenext336
bb_rcmoveheader336:
  %v2301 = load i64, ptr %slot275, align 8
  %op2302 = sub i64 %v2301, 16
  store i64 %op2302, ptr %slot277, align 8
  %v2303 = load i64, ptr %slot275, align 8
  %p2304 = inttoptr i64 %v2303 to ptr
  %rgep2305 = getelementptr i8, ptr %p2304, i64 -16
  %ld2306 = load i64, ptr %rgep2305, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2306, ptr %slot278, align 8
  %v2307 = load i64, ptr %slot278, align 8
  %op2308 = and i64 %v2307, 5764607523034234881
  store i64 %op2308, ptr %slot279, align 8
  %v2309 = load i64, ptr %slot279, align 8
  %cmp2310 = icmp ne i64 %v2309, 0
  %cv2311 = zext i1 %cmp2310 to i32
  store i32 %cv2311, ptr %slot280, align 8
  %v2312 = load i32, ptr %slot280, align 8
  %cv2313 = zext i32 %v2312 to i64
  %cond2314 = icmp ne i64 %cv2313, 0
  br i1 %cond2314, label %bb_rcmoveslow320, label %bb_rcmovenext336
bb_rcmovenext336:
  %v2315 = load i64, ptr %slot255, align 8
  %v2316 = load i64, ptr %slot260, align 8
  %p2317 = inttoptr i64 %v2315 to ptr
  %p2318 = inttoptr i64 %v2316 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2318, ptr %p2317, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2319 = load i64, ptr %slot255, align 8
  %p2320 = inttoptr i64 %v2319 to ptr
  store i64 0, ptr %p2320, align 8, !alias.scope !3, !noalias !4
  %v2321 = load i64, ptr %slot255, align 8
  %op2322 = add i64 %v2321, 8
  store i64 %op2322, ptr %slot281, align 8
  %v2323 = load i64, ptr %slot281, align 8
  %p2324 = inttoptr i64 %v2323 to ptr
  store i64 0, ptr %p2324, align 8, !alias.scope !3, !noalias !4
  %v2325 = load i64, ptr %slot255, align 8
  %op2326 = add i64 %v2325, 16
  store i64 %op2326, ptr %slot282, align 8
  %v2327 = load i64, ptr %slot282, align 8
  %p2328 = inttoptr i64 %v2327 to ptr
  store i64 0, ptr %p2328, align 8, !alias.scope !3, !noalias !4
  %v2329 = load i64, ptr %slot255, align 8
  %op2330 = add i64 %v2329, 24
  store i64 %op2330, ptr %slot283, align 8
  %v2331 = load i64, ptr %slot283, align 8
  %p2332 = inttoptr i64 %v2331 to ptr
  store i64 0, ptr %p2332, align 8, !alias.scope !3, !noalias !4
  %v2333 = load i64, ptr %slot255, align 8
  %op2334 = add i64 %v2333, 32
  store i64 %op2334, ptr %slot284, align 8
  %v2335 = load i64, ptr %slot284, align 8
  %p2336 = inttoptr i64 %v2335 to ptr
  store i64 0, ptr %p2336, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved320
bb_rcmoveslow320:
  %v2337 = load i64, ptr %slot56, align 8
  %v2338 = load i64, ptr %slot260, align 8
  %v2339 = load i64, ptr %slot255, align 8
  %v2340 = load i64, ptr %slot261, align 8
  %cv2341 = trunc i64 %v2340 to i32
  %call2342 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v2337, i64 %v2338, i64 %v2339, i32 %cv2341) nomerge, !dbg !124
  store i32 %call2342, ptr %slot285, align 8
  %v2343 = load i32, ptr %slot285, align 8
  %cv2344 = zext i32 %v2343 to i64
  %cond2345 = icmp ne i64 %cv2344, 0
  br i1 %cond2345, label %bb_rcsuccess347, label %bb_rcfailure347
bb_rcfailure347:
  %v2346 = load i64, ptr %slot56, align 8
  %p2347 = inttoptr i64 %v2346 to ptr
  %call2348 = call i32 @myl_rc_take_failure(ptr %p2347) nomerge, !dbg !124
  store i32 %call2348, ptr %slot286, align 8
  %v2349 = load i64, ptr %slot1, align 8
  %p2350 = inttoptr i64 %v2349 to ptr
  %v2351 = load i32, ptr %slot286, align 8
  %call2352 = call i32 @myl_qbe_rc_status(ptr %p2350, i32 %v2351) nomerge, !dbg !124
  store i32 %call2352, ptr %slot287, align 8
  br label %bb_failure
bb_rcsuccess347:
  br label %bb_rcmoved320
bb_rcmoved320:
  %v2353 = load i64, ptr %slot13, align 8
  %p2354 = inttoptr i64 %v2353 to ptr
  store i32 0, ptr %p2354, align 4, !alias.scope !3, !noalias !4
  %v2355 = load i64, ptr %slot20, align 8
  %p2356 = inttoptr i64 %v2355 to ptr
  store i32 2, ptr %p2356, align 4, !alias.scope !3, !noalias !4
  %v2357 = load i64, ptr %slot19, align 8
  %p2358 = inttoptr i64 %v2357 to ptr
  store i32 1, ptr %p2358, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared311
bb_rccopy311:
  %v2359 = load i64, ptr %slot29, align 8
  store i64 %v2359, ptr %slot288, align 8
  %v2360 = load i64, ptr %slot57, align 8
  store i64 %v2360, ptr %slot289, align 8
  %v2361 = load i64, ptr %slot56, align 8
  %v2362 = load i64, ptr %slot288, align 8
  %v2363 = load i64, ptr %slot255, align 8
  %v2364 = load i64, ptr %slot289, align 8
  %cv2365 = trunc i64 %v2364 to i32
  %call2366 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64 %v2361, i64 %v2362, i64 %v2363, i32 %cv2365) nomerge, !dbg !124
  store i32 %call2366, ptr %slot290, align 8
  %v2367 = load i32, ptr %slot290, align 8
  %cv2368 = zext i32 %v2367 to i64
  %cond2369 = icmp ne i64 %cv2368, 0
  br i1 %cond2369, label %bb_rcsuccess356, label %bb_rcfailure356
bb_rcfailure356:
  %v2370 = load i64, ptr %slot56, align 8
  %p2371 = inttoptr i64 %v2370 to ptr
  %call2372 = call i32 @myl_rc_take_failure(ptr %p2371) nomerge, !dbg !124
  store i32 %call2372, ptr %slot291, align 8
  %v2373 = load i64, ptr %slot1, align 8
  %p2374 = inttoptr i64 %v2373 to ptr
  %v2375 = load i32, ptr %slot291, align 8
  %call2376 = call i32 @myl_qbe_rc_status(ptr %p2374, i32 %v2375) nomerge, !dbg !124
  store i32 %call2376, ptr %slot292, align 8
  br label %bb_failure
bb_rcsuccess356:
  %v2377 = load i64, ptr %slot20, align 8
  %p2378 = inttoptr i64 %v2377 to ptr
  store i32 2, ptr %p2378, align 4, !alias.scope !3, !noalias !4
  %v2379 = load i64, ptr %slot19, align 8
  %p2380 = inttoptr i64 %v2379 to ptr
  store i32 1, ptr %p2380, align 4, !alias.scope !3, !noalias !4
  %v2381 = load i64, ptr %slot13, align 8
  %p2382 = inttoptr i64 %v2381 to ptr
  %ld2383 = load i32, ptr %p2382, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2383, ptr %slot293, align 8
  %v2384 = load i32, ptr %slot293, align 8
  %cv2385 = zext i32 %v2384 to i64
  %cond2386 = icmp ne i64 %cv2385, 0
  br i1 %cond2386, label %bb_rcslotdrop363, label %bb_rcslotdone363
bb_rcslotdrop363:
  %v2387 = load i64, ptr %slot13, align 8
  %p2388 = inttoptr i64 %v2387 to ptr
  store i32 0, ptr %p2388, align 4, !alias.scope !3, !noalias !4
  %v2389 = load i64, ptr %slot23, align 8
  store i64 %v2389, ptr %slot294, align 8
  %v2390 = load i64, ptr %slot14, align 8
  %p2391 = inttoptr i64 %v2390 to ptr
  %ld2392 = load i32, ptr %p2391, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2392, ptr %slot295, align 8
  %v2393 = load i32, ptr %slot295, align 8
  %op2394 = and i32 %v2393, 28
  store i32 %op2394, ptr %slot296, align 8
  %v2395 = load i32, ptr %slot296, align 8
  %cv2396 = zext i32 %v2395 to i64
  %cond2397 = icmp ne i64 %cv2396, 0
  br i1 %cond2397, label %bb_rcslotrole363, label %bb_rcslotowner363
bb_rcslotrole363:
  %v2398 = load i64, ptr %slot56, align 8
  store i64 %v2398, ptr %slot297, align 8
  %v2399 = load i64, ptr %slot297, align 8
  %v2400 = load i64, ptr %slot294, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v2399, i64 %v2400) nomerge, !dbg !124
  br label %bb_rcslotdone363
bb_rcslotowner363:
  %v2401 = load i64, ptr %slot56, align 8
  store i64 %v2401, ptr %slot298, align 8
  %v2402 = load i64, ptr %slot298, align 8
  %v2403 = load i64, ptr %slot294, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v2402, i64 %v2403) nomerge, !dbg !124
  br label %bb_rcslotdone363
bb_rcslotdone363:
  br label %bb_rcprepared311
bb_rcprepared311:
  %v2404 = load i64, ptr %slot29, align 8
  store i64 %v2404, ptr %slot299, align 8
  %v2405 = load i64, ptr %slot299, align 8
  %v2406 = load i64, ptr %slot254, align 8
  %p2407 = inttoptr i64 %v2405 to ptr
  %p2408 = inttoptr i64 %v2406 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2408, ptr %p2407, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v2409 = load i64, ptr %slot19, align 8
  %p2410 = inttoptr i64 %v2409 to ptr
  store i32 0, ptr %p2410, align 4, !alias.scope !3, !noalias !4
  %v2411 = load i64, ptr %slot43, align 8
  %p2412 = inttoptr i64 %v2411 to ptr
  %ld2413 = load i64, ptr %p2412, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2413, ptr %slot300, align 8
  %v2414 = load i64, ptr %slot300, align 8
  %v2415 = load i64, ptr %slot27, align 8
  %p2416 = inttoptr i64 %v2415 to ptr
  store i64 %v2414, ptr %p2416, align 8, !alias.scope !3, !noalias !4
  %v2417 = load i64, ptr %slot27, align 8
  store i64 %v2417, ptr %slot301, align 8
  %v2418 = load i64, ptr %slot227, align 8
  %p2420 = inttoptr i64 %v2418 to ptr
  %gep2421 = getelementptr i8, ptr %p2420, i64 248
  %op2419 = ptrtoint ptr %gep2421 to i64
  store i64 %op2419, ptr %slot302, align 8
  %v2422 = load i64, ptr %slot43, align 8
  %p2423 = inttoptr i64 %v2422 to ptr
  %ld2424 = load i64, ptr %p2423, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2424, ptr %slot303, align 8
  %v2425 = load i64, ptr %slot303, align 8
  %v2426 = load i64, ptr %slot27, align 8
  %p2427 = inttoptr i64 %v2426 to ptr
  store i64 %v2425, ptr %p2427, align 8, !alias.scope !3, !noalias !4
  %v2428 = load i64, ptr %slot27, align 8
  store i64 %v2428, ptr %slot304, align 8
  store i32 0, ptr %slot305, align 8
  %v2429 = load i64, ptr %slot15, align 8
  %p2430 = inttoptr i64 %v2429 to ptr
  %ld2431 = load i32, ptr %p2430, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2431, ptr %slot306, align 8
  %v2432 = load i32, ptr %slot306, align 8
  %op2433 = and i32 %v2432, 24
  store i32 %op2433, ptr %slot306, align 8
  %v2434 = load i32, ptr %slot306, align 8
  %cmp2435 = icmp eq i32 %v2434, 0
  %cv2436 = zext i1 %cmp2435 to i32
  store i32 %cv2436, ptr %slot307, align 8
  %v2437 = load i32, ptr %slot305, align 8
  %v2438 = load i32, ptr %slot307, align 8
  %op2439 = and i32 %v2437, %v2438
  store i32 %op2439, ptr %slot308, align 8
  %v2440 = load i32, ptr %slot308, align 8
  %cv2441 = zext i32 %v2440 to i64
  %cond2442 = icmp ne i64 %cv2441, 0
  br i1 %cond2442, label %bb_rctake377, label %bb_rccopy377
bb_rctake377:
  %v2443 = load i64, ptr %slot29, align 8
  store i64 %v2443, ptr %slot309, align 8
  %v2444 = load i64, ptr %slot57, align 8
  store i64 %v2444, ptr %slot310, align 8
  %v2445 = load i64, ptr %slot304, align 8
  %v2446 = load i64, ptr %slot309, align 8
  %op2447 = sub i64 %v2445, %v2446
  store i64 %op2447, ptr %slot311, align 8
  %v2448 = load i64, ptr %slot309, align 8
  %v2449 = load i64, ptr %slot304, align 8
  %op2450 = sub i64 %v2448, %v2449
  store i64 %op2450, ptr %slot312, align 8
  %v2451 = load i64, ptr %slot311, align 8
  %cmp2452 = icmp ult i64 %v2451, 8
  %cv2453 = zext i1 %cmp2452 to i32
  store i32 %cv2453, ptr %slot313, align 8
  %v2454 = load i64, ptr %slot312, align 8
  %cmp2455 = icmp ult i64 %v2454, 8
  %cv2456 = zext i1 %cmp2455 to i32
  store i32 %cv2456, ptr %slot314, align 8
  %v2457 = load i32, ptr %slot313, align 8
  %v2458 = load i32, ptr %slot314, align 8
  %op2459 = or i32 %v2457, %v2458
  store i32 %op2459, ptr %slot315, align 8
  %v2460 = load i32, ptr %slot315, align 8
  %cv2461 = zext i32 %v2460 to i64
  %cond2462 = icmp ne i64 %cv2461, 0
  br i1 %cond2462, label %bb_rcmoveslow386, label %bb_rcmovecheck386
bb_rcmovecheck386:
  %v2463 = load i64, ptr %slot304, align 8
  %p2465 = inttoptr i64 %v2463 to ptr
  %gep2466 = getelementptr i8, ptr %p2465, i64 0
  %op2464 = ptrtoint ptr %gep2466 to i64
  store i64 %op2464, ptr %slot316, align 8
  %v2467 = load i64, ptr %slot316, align 8
  %p2468 = inttoptr i64 %v2467 to ptr
  %ld2469 = load i64, ptr %p2468, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2469, ptr %slot317, align 8
  %v2470 = load i64, ptr %slot317, align 8
  %cmp2471 = icmp ne i64 %v2470, 0
  %cv2472 = zext i1 %cmp2471 to i32
  store i32 %cv2472, ptr %slot318, align 8
  %v2473 = load i32, ptr %slot318, align 8
  %cv2474 = zext i32 %v2473 to i64
  %cond2475 = icmp ne i64 %cv2474, 0
  br i1 %cond2475, label %bb_rcmoveheader394, label %bb_rcmovenext394
bb_rcmoveheader394:
  %v2476 = load i64, ptr %slot317, align 8
  %op2477 = sub i64 %v2476, 16
  store i64 %op2477, ptr %slot319, align 8
  %v2478 = load i64, ptr %slot317, align 8
  %p2479 = inttoptr i64 %v2478 to ptr
  %rgep2480 = getelementptr i8, ptr %p2479, i64 -16
  %ld2481 = load i64, ptr %rgep2480, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2481, ptr %slot320, align 8
  %v2482 = load i64, ptr %slot320, align 8
  %op2483 = and i64 %v2482, 5764607523034234881
  store i64 %op2483, ptr %slot321, align 8
  %v2484 = load i64, ptr %slot321, align 8
  %cmp2485 = icmp ne i64 %v2484, 0
  %cv2486 = zext i1 %cmp2485 to i32
  store i32 %cv2486, ptr %slot322, align 8
  %v2487 = load i32, ptr %slot322, align 8
  %cv2488 = zext i32 %v2487 to i64
  %cond2489 = icmp ne i64 %cv2488, 0
  br i1 %cond2489, label %bb_rcmoveslow386, label %bb_rcmovenext394
bb_rcmovenext394:
  %v2490 = load i64, ptr %slot304, align 8
  %v2491 = load i64, ptr %slot309, align 8
  %p2492 = inttoptr i64 %v2490 to ptr
  %p2493 = inttoptr i64 %v2491 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2493, ptr %p2492, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2494 = load i64, ptr %slot304, align 8
  %p2495 = inttoptr i64 %v2494 to ptr
  store i64 0, ptr %p2495, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved386
bb_rcmoveslow386:
  %v2496 = load i64, ptr %slot56, align 8
  %v2497 = load i64, ptr %slot309, align 8
  %v2498 = load i64, ptr %slot304, align 8
  %v2499 = load i64, ptr %slot310, align 8
  %cv2500 = trunc i64 %v2499 to i32
  %call2501 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64 %v2496, i64 %v2497, i64 %v2498, i32 %cv2500) nomerge, !dbg !124
  store i32 %call2501, ptr %slot323, align 8
  %v2502 = load i32, ptr %slot323, align 8
  %cv2503 = zext i32 %v2502 to i64
  %cond2504 = icmp ne i64 %cv2503, 0
  br i1 %cond2504, label %bb_rcsuccess401, label %bb_rcfailure401
bb_rcfailure401:
  %v2505 = load i64, ptr %slot56, align 8
  %p2506 = inttoptr i64 %v2505 to ptr
  %call2507 = call i32 @myl_rc_take_failure(ptr %p2506) nomerge, !dbg !124
  store i32 %call2507, ptr %slot324, align 8
  %v2508 = load i64, ptr %slot1, align 8
  %p2509 = inttoptr i64 %v2508 to ptr
  %v2510 = load i32, ptr %slot324, align 8
  %call2511 = call i32 @myl_qbe_rc_status(ptr %p2509, i32 %v2510) nomerge, !dbg !124
  store i32 %call2511, ptr %slot325, align 8
  br label %bb_failure
bb_rcsuccess401:
  br label %bb_rcmoved386
bb_rcmoved386:
  %v2512 = load i64, ptr %slot20, align 8
  %p2513 = inttoptr i64 %v2512 to ptr
  store i32 2, ptr %p2513, align 4, !alias.scope !3, !noalias !4
  %v2514 = load i64, ptr %slot19, align 8
  %p2515 = inttoptr i64 %v2514 to ptr
  store i32 1, ptr %p2515, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared377
bb_rccopy377:
  %v2516 = load i64, ptr %slot29, align 8
  store i64 %v2516, ptr %slot326, align 8
  %v2517 = load i64, ptr %slot57, align 8
  store i64 %v2517, ptr %slot327, align 8
  %v2518 = load i64, ptr %slot304, align 8
  %p2519 = inttoptr i64 %v2518 to ptr
  %ld2520 = load i64, ptr %p2519, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2520, ptr %slot328, align 8
  %v2521 = load i64, ptr %slot328, align 8
  %cmp2522 = icmp ne i64 %v2521, 0
  %cv2523 = zext i1 %cmp2522 to i32
  store i32 %cv2523, ptr %slot329, align 8
  %v2524 = load i32, ptr %slot329, align 8
  %cv2525 = zext i32 %v2524 to i64
  %cond2526 = icmp ne i64 %cv2525, 0
  br i1 %cond2526, label %bb_rcgnn410, label %bb_rcgplain410
bb_rcgnn410:
  %v2527 = load i64, ptr %slot328, align 8
  %op2528 = sub i64 %v2527, 16
  store i64 %op2528, ptr %slot330, align 8
  %v2529 = load i64, ptr %slot328, align 8
  %p2530 = inttoptr i64 %v2529 to ptr
  %rgep2531 = getelementptr i8, ptr %p2530, i64 -16
  %ld2532 = load i64, ptr %rgep2531, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2532, ptr %slot331, align 8
  %v2533 = load i64, ptr %slot331, align 8
  %op2534 = and i64 %v2533, 4611686018427387906
  store i64 %op2534, ptr %slot332, align 8
  %v2535 = load i64, ptr %slot332, align 8
  %cmp2536 = icmp ne i64 %v2535, 0
  %cv2537 = zext i1 %cmp2536 to i32
  store i32 %cv2537, ptr %slot333, align 8
  %v2538 = load i32, ptr %slot333, align 8
  %cv2539 = zext i32 %v2538 to i64
  %cond2540 = icmp ne i64 %cv2539, 0
  br i1 %cond2540, label %bb_rcgspecial410, label %bb_rcginc410
bb_rcginc410:
  %v2541 = load i64, ptr %slot328, align 8
  %op2542 = sub i64 %v2541, 32
  store i64 %op2542, ptr %slot334, align 8
  %v2543 = load i64, ptr %slot328, align 8
  %p2544 = inttoptr i64 %v2543 to ptr
  %rgep2545 = getelementptr i8, ptr %p2544, i64 -32
  %ld2546 = load i64, ptr %rgep2545, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2546, ptr %slot335, align 8
  %v2547 = load i64, ptr %slot335, align 8
  %op2548 = add i64 %v2547, 1
  store i64 %op2548, ptr %slot336, align 8
  %v2549 = load i64, ptr %slot336, align 8
  %cmp2550 = icmp eq i64 %v2549, 0
  %cv2551 = zext i1 %cmp2550 to i32
  store i32 %cv2551, ptr %slot337, align 8
  %v2552 = load i32, ptr %slot337, align 8
  %cv2553 = zext i32 %v2552 to i64
  %cond2554 = icmp ne i64 %cv2553, 0
  br i1 %cond2554, label %bb_rcglimit410, label %bb_rcgcapacity410
bb_rcglimit410:
  %v2555 = load i64, ptr %slot1, align 8
  %p2556 = inttoptr i64 %v2555 to ptr
  %call2557 = call i32 @myl_qbe_rc_status(ptr %p2556, i32 2) nomerge, !dbg !124
  store i32 %call2557, ptr %slot338, align 8
  br label %bb_failure
bb_rcgcapacity410:
  %v2558 = load i64, ptr %slot336, align 8
  %v2559 = load i64, ptr %slot328, align 8
  %p2560 = inttoptr i64 %v2559 to ptr
  %rgep2561 = getelementptr i8, ptr %p2560, i64 -32
  store i64 %v2558, ptr %rgep2561, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain410
bb_rcgspecial410:
  %v2562 = load i64, ptr %slot331, align 8
  %op2563 = and i64 %v2562, 4611686018427387904
  store i64 %op2563, ptr %slot339, align 8
  %v2564 = load i64, ptr %slot339, align 8
  %cmp2565 = icmp ne i64 %v2564, 0
  %cv2566 = zext i1 %cmp2565 to i32
  store i32 %cv2566, ptr %slot340, align 8
  %v2567 = load i32, ptr %slot340, align 8
  %cv2568 = zext i32 %v2567 to i64
  %cond2569 = icmp ne i64 %cv2568, 0
  br i1 %cond2569, label %bb_rcgslow410, label %bb_rcgplain410
bb_rcgslow410:
  %v2570 = load i64, ptr %slot56, align 8
  %v2571 = load i64, ptr %slot326, align 8
  %v2572 = load i64, ptr %slot304, align 8
  %v2573 = load i64, ptr %slot327, align 8
  %cv2574 = trunc i64 %v2573 to i32
  %call2575 = call i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64 %v2570, i64 %v2571, i64 %v2572, i32 %cv2574) nomerge, !dbg !124
  store i32 %call2575, ptr %slot341, align 8
  %v2576 = load i32, ptr %slot341, align 8
  %cv2577 = zext i32 %v2576 to i64
  %cond2578 = icmp ne i64 %cv2577, 0
  br i1 %cond2578, label %bb_rcsuccess424, label %bb_rcfailure424
bb_rcfailure424:
  %v2579 = load i64, ptr %slot56, align 8
  %p2580 = inttoptr i64 %v2579 to ptr
  %call2581 = call i32 @myl_rc_take_failure(ptr %p2580) nomerge, !dbg !124
  store i32 %call2581, ptr %slot342, align 8
  %v2582 = load i64, ptr %slot1, align 8
  %p2583 = inttoptr i64 %v2582 to ptr
  %v2584 = load i32, ptr %slot342, align 8
  %call2585 = call i32 @myl_qbe_rc_status(ptr %p2583, i32 %v2584) nomerge, !dbg !124
  store i32 %call2585, ptr %slot343, align 8
  br label %bb_failure
bb_rcsuccess424:
  br label %bb_rcgdone410
bb_rcgplain410:
  %v2586 = load i64, ptr %slot328, align 8
  %v2587 = load i64, ptr %slot326, align 8
  %p2588 = inttoptr i64 %v2587 to ptr
  store i64 %v2586, ptr %p2588, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone410
bb_rcgdone410:
  %v2589 = load i64, ptr %slot20, align 8
  %p2590 = inttoptr i64 %v2589 to ptr
  store i32 2, ptr %p2590, align 4, !alias.scope !3, !noalias !4
  %v2591 = load i64, ptr %slot19, align 8
  %p2592 = inttoptr i64 %v2591 to ptr
  store i32 1, ptr %p2592, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared377
bb_rcprepared377:
  %v2593 = load i64, ptr %slot29, align 8
  store i64 %v2593, ptr %slot344, align 8
  %v2594 = load i64, ptr %slot344, align 8
  %v2595 = load i64, ptr %slot302, align 8
  %p2596 = inttoptr i64 %v2594 to ptr
  %p2597 = inttoptr i64 %v2595 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2597, ptr %p2596, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2598 = load i64, ptr %slot19, align 8
  %p2599 = inttoptr i64 %v2598 to ptr
  store i32 0, ptr %p2599, align 4, !alias.scope !3, !noalias !4
  %v2600 = load i64, ptr %slot44, align 8
  %p2601 = inttoptr i64 %v2600 to ptr
  %ld2602 = load i64, ptr %p2601, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2602, ptr %slot345, align 8
  %v2603 = load i64, ptr %slot345, align 8
  %v2604 = load i64, ptr %slot28, align 8
  %p2605 = inttoptr i64 %v2604 to ptr
  store i64 %v2603, ptr %p2605, align 8, !alias.scope !3, !noalias !4
  %v2606 = load i64, ptr %slot28, align 8
  store i64 %v2606, ptr %slot346, align 8
  %v2607 = load i64, ptr %slot227, align 8
  %p2609 = inttoptr i64 %v2607 to ptr
  %gep2610 = getelementptr i8, ptr %p2609, i64 256
  %op2608 = ptrtoint ptr %gep2610 to i64
  store i64 %op2608, ptr %slot347, align 8
  %v2611 = load i64, ptr %slot44, align 8
  %p2612 = inttoptr i64 %v2611 to ptr
  %ld2613 = load i64, ptr %p2612, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2613, ptr %slot348, align 8
  %v2614 = load i64, ptr %slot348, align 8
  %v2615 = load i64, ptr %slot28, align 8
  %p2616 = inttoptr i64 %v2615 to ptr
  store i64 %v2614, ptr %p2616, align 8, !alias.scope !3, !noalias !4
  %v2617 = load i64, ptr %slot28, align 8
  store i64 %v2617, ptr %slot349, align 8
  %v2618 = load i64, ptr %slot16, align 8
  %p2619 = inttoptr i64 %v2618 to ptr
  %ld2620 = load i32, ptr %p2619, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2620, ptr %slot350, align 8
  %v2621 = load i64, ptr %slot17, align 8
  %p2622 = inttoptr i64 %v2621 to ptr
  %ld2623 = load i32, ptr %p2622, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2623, ptr %slot351, align 8
  %v2624 = load i32, ptr %slot351, align 8
  %op2625 = and i32 %v2624, 24
  store i32 %op2625, ptr %slot351, align 8
  %v2626 = load i32, ptr %slot351, align 8
  %cmp2627 = icmp eq i32 %v2626, 0
  %cv2628 = zext i1 %cmp2627 to i32
  store i32 %cv2628, ptr %slot352, align 8
  %v2629 = load i32, ptr %slot350, align 8
  %v2630 = load i32, ptr %slot352, align 8
  %op2631 = and i32 %v2629, %v2630
  store i32 %op2631, ptr %slot353, align 8
  %v2632 = load i32, ptr %slot353, align 8
  %cv2633 = zext i32 %v2632 to i64
  %cond2634 = icmp ne i64 %cv2633, 0
  br i1 %cond2634, label %bb_rctake473, label %bb_rccopy473
bb_rctake473:
  %v2635 = load i64, ptr %slot29, align 8
  store i64 %v2635, ptr %slot354, align 8
  %v2636 = load i64, ptr %slot57, align 8
  store i64 %v2636, ptr %slot355, align 8
  %v2637 = load i64, ptr %slot349, align 8
  %v2638 = load i64, ptr %slot354, align 8
  %op2639 = sub i64 %v2637, %v2638
  store i64 %op2639, ptr %slot356, align 8
  %v2640 = load i64, ptr %slot354, align 8
  %v2641 = load i64, ptr %slot349, align 8
  %op2642 = sub i64 %v2640, %v2641
  store i64 %op2642, ptr %slot357, align 8
  %v2643 = load i64, ptr %slot356, align 8
  %cmp2644 = icmp ult i64 %v2643, 8
  %cv2645 = zext i1 %cmp2644 to i32
  store i32 %cv2645, ptr %slot358, align 8
  %v2646 = load i64, ptr %slot357, align 8
  %cmp2647 = icmp ult i64 %v2646, 8
  %cv2648 = zext i1 %cmp2647 to i32
  store i32 %cv2648, ptr %slot359, align 8
  %v2649 = load i32, ptr %slot358, align 8
  %v2650 = load i32, ptr %slot359, align 8
  %op2651 = or i32 %v2649, %v2650
  store i32 %op2651, ptr %slot360, align 8
  %v2652 = load i32, ptr %slot360, align 8
  %cv2653 = zext i32 %v2652 to i64
  %cond2654 = icmp ne i64 %cv2653, 0
  br i1 %cond2654, label %bb_rcmoveslow482, label %bb_rcmovecheck482
bb_rcmovecheck482:
  %v2655 = load i64, ptr %slot349, align 8
  %p2657 = inttoptr i64 %v2655 to ptr
  %gep2658 = getelementptr i8, ptr %p2657, i64 0
  %op2656 = ptrtoint ptr %gep2658 to i64
  store i64 %op2656, ptr %slot361, align 8
  %v2659 = load i64, ptr %slot361, align 8
  %p2660 = inttoptr i64 %v2659 to ptr
  %ld2661 = load i64, ptr %p2660, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2661, ptr %slot362, align 8
  %v2662 = load i64, ptr %slot362, align 8
  %cmp2663 = icmp ne i64 %v2662, 0
  %cv2664 = zext i1 %cmp2663 to i32
  store i32 %cv2664, ptr %slot363, align 8
  %v2665 = load i32, ptr %slot363, align 8
  %cv2666 = zext i32 %v2665 to i64
  %cond2667 = icmp ne i64 %cv2666, 0
  br i1 %cond2667, label %bb_rcmoveheader490, label %bb_rcmovenext490
bb_rcmoveheader490:
  %v2668 = load i64, ptr %slot362, align 8
  %op2669 = sub i64 %v2668, 16
  store i64 %op2669, ptr %slot364, align 8
  %v2670 = load i64, ptr %slot362, align 8
  %p2671 = inttoptr i64 %v2670 to ptr
  %rgep2672 = getelementptr i8, ptr %p2671, i64 -16
  %ld2673 = load i64, ptr %rgep2672, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2673, ptr %slot365, align 8
  %v2674 = load i64, ptr %slot365, align 8
  %op2675 = and i64 %v2674, 5764607523034234881
  store i64 %op2675, ptr %slot366, align 8
  %v2676 = load i64, ptr %slot366, align 8
  %cmp2677 = icmp ne i64 %v2676, 0
  %cv2678 = zext i1 %cmp2677 to i32
  store i32 %cv2678, ptr %slot367, align 8
  %v2679 = load i32, ptr %slot367, align 8
  %cv2680 = zext i32 %v2679 to i64
  %cond2681 = icmp ne i64 %cv2680, 0
  br i1 %cond2681, label %bb_rcmoveslow482, label %bb_rcmovenext490
bb_rcmovenext490:
  %v2682 = load i64, ptr %slot349, align 8
  %v2683 = load i64, ptr %slot354, align 8
  %p2684 = inttoptr i64 %v2682 to ptr
  %p2685 = inttoptr i64 %v2683 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2685, ptr %p2684, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2686 = load i64, ptr %slot349, align 8
  %p2687 = inttoptr i64 %v2686 to ptr
  store i64 0, ptr %p2687, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved482
bb_rcmoveslow482:
  %v2688 = load i64, ptr %slot56, align 8
  %v2689 = load i64, ptr %slot354, align 8
  %v2690 = load i64, ptr %slot349, align 8
  %v2691 = load i64, ptr %slot355, align 8
  %cv2692 = trunc i64 %v2691 to i32
  %call2693 = call i32 @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_take(i64 %v2688, i64 %v2689, i64 %v2690, i32 %cv2692) nomerge, !dbg !124
  store i32 %call2693, ptr %slot368, align 8
  %v2694 = load i32, ptr %slot368, align 8
  %cv2695 = zext i32 %v2694 to i64
  %cond2696 = icmp ne i64 %cv2695, 0
  br i1 %cond2696, label %bb_rcsuccess497, label %bb_rcfailure497
bb_rcfailure497:
  %v2697 = load i64, ptr %slot56, align 8
  %p2698 = inttoptr i64 %v2697 to ptr
  %call2699 = call i32 @myl_rc_take_failure(ptr %p2698) nomerge, !dbg !124
  store i32 %call2699, ptr %slot369, align 8
  %v2700 = load i64, ptr %slot1, align 8
  %p2701 = inttoptr i64 %v2700 to ptr
  %v2702 = load i32, ptr %slot369, align 8
  %call2703 = call i32 @myl_qbe_rc_status(ptr %p2701, i32 %v2702) nomerge, !dbg !124
  store i32 %call2703, ptr %slot370, align 8
  br label %bb_failure
bb_rcsuccess497:
  br label %bb_rcmoved482
bb_rcmoved482:
  %v2704 = load i64, ptr %slot16, align 8
  %p2705 = inttoptr i64 %v2704 to ptr
  store i32 0, ptr %p2705, align 4, !alias.scope !3, !noalias !4
  %v2706 = load i64, ptr %slot20, align 8
  %p2707 = inttoptr i64 %v2706 to ptr
  store i32 2, ptr %p2707, align 4, !alias.scope !3, !noalias !4
  %v2708 = load i64, ptr %slot19, align 8
  %p2709 = inttoptr i64 %v2708 to ptr
  store i32 1, ptr %p2709, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared473
bb_rccopy473:
  %v2710 = load i64, ptr %slot29, align 8
  store i64 %v2710, ptr %slot371, align 8
  %v2711 = load i64, ptr %slot57, align 8
  store i64 %v2711, ptr %slot372, align 8
  %v2712 = load i64, ptr %slot349, align 8
  %p2713 = inttoptr i64 %v2712 to ptr
  %ld2714 = load i64, ptr %p2713, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2714, ptr %slot373, align 8
  %v2715 = load i64, ptr %slot373, align 8
  %cmp2716 = icmp ne i64 %v2715, 0
  %cv2717 = zext i1 %cmp2716 to i32
  store i32 %cv2717, ptr %slot374, align 8
  %v2718 = load i32, ptr %slot374, align 8
  %cv2719 = zext i32 %v2718 to i64
  %cond2720 = icmp ne i64 %cv2719, 0
  br i1 %cond2720, label %bb_rcgnn506, label %bb_rcgplain506
bb_rcgnn506:
  %v2721 = load i64, ptr %slot373, align 8
  %op2722 = sub i64 %v2721, 16
  store i64 %op2722, ptr %slot375, align 8
  %v2723 = load i64, ptr %slot373, align 8
  %p2724 = inttoptr i64 %v2723 to ptr
  %rgep2725 = getelementptr i8, ptr %p2724, i64 -16
  %ld2726 = load i64, ptr %rgep2725, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2726, ptr %slot376, align 8
  %v2727 = load i64, ptr %slot376, align 8
  %op2728 = and i64 %v2727, 4611686018427387906
  store i64 %op2728, ptr %slot377, align 8
  %v2729 = load i64, ptr %slot377, align 8
  %cmp2730 = icmp ne i64 %v2729, 0
  %cv2731 = zext i1 %cmp2730 to i32
  store i32 %cv2731, ptr %slot378, align 8
  %v2732 = load i32, ptr %slot378, align 8
  %cv2733 = zext i32 %v2732 to i64
  %cond2734 = icmp ne i64 %cv2733, 0
  br i1 %cond2734, label %bb_rcgspecial506, label %bb_rcginc506
bb_rcginc506:
  %v2735 = load i64, ptr %slot373, align 8
  %op2736 = sub i64 %v2735, 32
  store i64 %op2736, ptr %slot379, align 8
  %v2737 = load i64, ptr %slot373, align 8
  %p2738 = inttoptr i64 %v2737 to ptr
  %rgep2739 = getelementptr i8, ptr %p2738, i64 -32
  %ld2740 = load i64, ptr %rgep2739, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2740, ptr %slot380, align 8
  %v2741 = load i64, ptr %slot380, align 8
  %op2742 = add i64 %v2741, 1
  store i64 %op2742, ptr %slot381, align 8
  %v2743 = load i64, ptr %slot381, align 8
  %cmp2744 = icmp eq i64 %v2743, 0
  %cv2745 = zext i1 %cmp2744 to i32
  store i32 %cv2745, ptr %slot382, align 8
  %v2746 = load i32, ptr %slot382, align 8
  %cv2747 = zext i32 %v2746 to i64
  %cond2748 = icmp ne i64 %cv2747, 0
  br i1 %cond2748, label %bb_rcglimit506, label %bb_rcgcapacity506
bb_rcglimit506:
  %v2749 = load i64, ptr %slot1, align 8
  %p2750 = inttoptr i64 %v2749 to ptr
  %call2751 = call i32 @myl_qbe_rc_status(ptr %p2750, i32 2) nomerge, !dbg !124
  store i32 %call2751, ptr %slot383, align 8
  br label %bb_failure
bb_rcgcapacity506:
  %v2752 = load i64, ptr %slot381, align 8
  %v2753 = load i64, ptr %slot373, align 8
  %p2754 = inttoptr i64 %v2753 to ptr
  %rgep2755 = getelementptr i8, ptr %p2754, i64 -32
  store i64 %v2752, ptr %rgep2755, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgplain506
bb_rcgspecial506:
  %v2756 = load i64, ptr %slot376, align 8
  %op2757 = and i64 %v2756, 4611686018427387904
  store i64 %op2757, ptr %slot384, align 8
  %v2758 = load i64, ptr %slot384, align 8
  %cmp2759 = icmp ne i64 %v2758, 0
  %cv2760 = zext i1 %cmp2759 to i32
  store i32 %cv2760, ptr %slot385, align 8
  %v2761 = load i32, ptr %slot385, align 8
  %cv2762 = zext i32 %v2761 to i64
  %cond2763 = icmp ne i64 %cv2762, 0
  br i1 %cond2763, label %bb_rcgslow506, label %bb_rcgplain506
bb_rcgslow506:
  %v2764 = load i64, ptr %slot56, align 8
  %v2765 = load i64, ptr %slot371, align 8
  %v2766 = load i64, ptr %slot349, align 8
  %v2767 = load i64, ptr %slot372, align 8
  %cv2768 = trunc i64 %v2767 to i32
  %call2769 = call i32 @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_retain(i64 %v2764, i64 %v2765, i64 %v2766, i32 %cv2768) nomerge, !dbg !124
  store i32 %call2769, ptr %slot386, align 8
  %v2770 = load i32, ptr %slot386, align 8
  %cv2771 = zext i32 %v2770 to i64
  %cond2772 = icmp ne i64 %cv2771, 0
  br i1 %cond2772, label %bb_rcsuccess520, label %bb_rcfailure520
bb_rcfailure520:
  %v2773 = load i64, ptr %slot56, align 8
  %p2774 = inttoptr i64 %v2773 to ptr
  %call2775 = call i32 @myl_rc_take_failure(ptr %p2774) nomerge, !dbg !124
  store i32 %call2775, ptr %slot387, align 8
  %v2776 = load i64, ptr %slot1, align 8
  %p2777 = inttoptr i64 %v2776 to ptr
  %v2778 = load i32, ptr %slot387, align 8
  %call2779 = call i32 @myl_qbe_rc_status(ptr %p2777, i32 %v2778) nomerge, !dbg !124
  store i32 %call2779, ptr %slot388, align 8
  br label %bb_failure
bb_rcsuccess520:
  br label %bb_rcgdone506
bb_rcgplain506:
  %v2780 = load i64, ptr %slot373, align 8
  %v2781 = load i64, ptr %slot371, align 8
  %p2782 = inttoptr i64 %v2781 to ptr
  store i64 %v2780, ptr %p2782, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone506
bb_rcgdone506:
  %v2783 = load i64, ptr %slot20, align 8
  %p2784 = inttoptr i64 %v2783 to ptr
  store i32 2, ptr %p2784, align 4, !alias.scope !3, !noalias !4
  %v2785 = load i64, ptr %slot19, align 8
  %p2786 = inttoptr i64 %v2785 to ptr
  store i32 1, ptr %p2786, align 4, !alias.scope !3, !noalias !4
  %v2787 = load i64, ptr %slot16, align 8
  %p2788 = inttoptr i64 %v2787 to ptr
  %ld2789 = load i32, ptr %p2788, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2789, ptr %slot389, align 8
  %v2790 = load i32, ptr %slot389, align 8
  %cv2791 = zext i32 %v2790 to i64
  %cond2792 = icmp ne i64 %cv2791, 0
  br i1 %cond2792, label %bb_rcslotdrop527, label %bb_rcslotdone527
bb_rcslotdrop527:
  %v2793 = load i64, ptr %slot16, align 8
  %p2794 = inttoptr i64 %v2793 to ptr
  store i32 0, ptr %p2794, align 4, !alias.scope !3, !noalias !4
  %v2795 = load i64, ptr %slot24, align 8
  store i64 %v2795, ptr %slot390, align 8
  %v2796 = load i64, ptr %slot17, align 8
  %p2797 = inttoptr i64 %v2796 to ptr
  %ld2798 = load i32, ptr %p2797, align 4, !alias.scope !3, !noalias !4
  store i32 %ld2798, ptr %slot391, align 8
  %v2799 = load i32, ptr %slot391, align 8
  %op2800 = and i32 %v2799, 28
  store i32 %op2800, ptr %slot392, align 8
  %v2801 = load i32, ptr %slot392, align 8
  %cv2802 = zext i32 %v2801 to i64
  %cond2803 = icmp ne i64 %cv2802, 0
  br i1 %cond2803, label %bb_rcslotrole527, label %bb_rcslotowner527
bb_rcslotrole527:
  %v2804 = load i64, ptr %slot56, align 8
  store i64 %v2804, ptr %slot393, align 8
  %v2805 = load i64, ptr %slot390, align 8
  %p2806 = inttoptr i64 %v2805 to ptr
  %ld2807 = load i64, ptr %p2806, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2807, ptr %slot394, align 8
  %v2808 = load i64, ptr %slot394, align 8
  %cmp2809 = icmp ne i64 %v2808, 0
  %cv2810 = zext i1 %cmp2809 to i32
  store i32 %cv2810, ptr %slot395, align 8
  %v2811 = load i32, ptr %slot395, align 8
  %cv2812 = zext i32 %v2811 to i64
  %cond2813 = icmp ne i64 %cv2812, 0
  br i1 %cond2813, label %bb_rcgnn543, label %bb_rcgdone543
bb_rcgnn543:
  %v2814 = load i64, ptr %slot394, align 8
  %op2815 = sub i64 %v2814, 16
  store i64 %op2815, ptr %slot396, align 8
  %v2816 = load i64, ptr %slot394, align 8
  %p2817 = inttoptr i64 %v2816 to ptr
  %rgep2818 = getelementptr i8, ptr %p2817, i64 -16
  %ld2819 = load i64, ptr %rgep2818, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2819, ptr %slot397, align 8
  %v2820 = load i64, ptr %slot397, align 8
  %op2821 = and i64 %v2820, 4611686018427387906
  store i64 %op2821, ptr %slot398, align 8
  %v2822 = load i64, ptr %slot398, align 8
  %cmp2823 = icmp ne i64 %v2822, 0
  %cv2824 = zext i1 %cmp2823 to i32
  store i32 %cv2824, ptr %slot399, align 8
  %v2825 = load i32, ptr %slot399, align 8
  %cv2826 = zext i32 %v2825 to i64
  %cond2827 = icmp ne i64 %cv2826, 0
  br i1 %cond2827, label %bb_rcgclear543, label %bb_rcgcounted543
bb_rcgcounted543:
  %v2828 = load i64, ptr %slot394, align 8
  %op2829 = sub i64 %v2828, 24
  store i64 %op2829, ptr %slot400, align 8
  %v2830 = load i64, ptr %slot394, align 8
  %p2831 = inttoptr i64 %v2830 to ptr
  %rgep2832 = getelementptr i8, ptr %p2831, i64 -24
  %ld2833 = load i64, ptr %rgep2832, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2833, ptr %slot401, align 8
  %v2834 = load i64, ptr %slot401, align 8
  %op2835 = sub i64 %v2834, 1
  store i64 %op2835, ptr %slot402, align 8
  %v2836 = load i64, ptr %slot402, align 8
  %cmp2837 = icmp eq i64 %v2836, 0
  %cv2838 = zext i1 %cmp2837 to i32
  store i32 %cv2838, ptr %slot403, align 8
  %v2839 = load i32, ptr %slot403, align 8
  %cv2840 = zext i32 %v2839 to i64
  %cond2841 = icmp ne i64 %cv2840, 0
  br i1 %cond2841, label %bb_rcglast543, label %bb_rcgdec543
bb_rcglast543:
  %v2842 = load i64, ptr %slot394, align 8
  %op2843 = sub i64 %v2842, 32
  store i64 %op2843, ptr %slot404, align 8
  %v2844 = load i64, ptr %slot394, align 8
  %p2845 = inttoptr i64 %v2844 to ptr
  %rgep2846 = getelementptr i8, ptr %p2845, i64 -32
  %ld2847 = load i64, ptr %rgep2846, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2847, ptr %slot405, align 8
  %v2848 = load i64, ptr %slot405, align 8
  %cmp2849 = icmp ne i64 %v2848, 0
  %cv2850 = zext i1 %cmp2849 to i32
  store i32 %cv2850, ptr %slot406, align 8
  %v2851 = load i32, ptr %slot406, align 8
  %cv2852 = zext i32 %v2851 to i64
  %cond2853 = icmp ne i64 %cv2852, 0
  br i1 %cond2853, label %bb_rcgdec543, label %bb_rcgslow543
bb_rcgslow543:
  %v2854 = load i64, ptr %slot393, align 8
  %v2855 = load i64, ptr %slot390, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64 %v2854, i64 %v2855) nomerge, !dbg !124
  br label %bb_rcgdone543
bb_rcgdec543:
  %v2856 = load i64, ptr %slot402, align 8
  %v2857 = load i64, ptr %slot394, align 8
  %p2858 = inttoptr i64 %v2857 to ptr
  %rgep2859 = getelementptr i8, ptr %p2858, i64 -24
  store i64 %v2856, ptr %rgep2859, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear543
bb_rcgclear543:
  %v2860 = load i64, ptr %slot390, align 8
  %p2861 = inttoptr i64 %v2860 to ptr
  store i64 0, ptr %p2861, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone543
bb_rcgdone543:
  br label %bb_rcslotdone527
bb_rcslotowner527:
  %v2862 = load i64, ptr %slot56, align 8
  store i64 %v2862, ptr %slot407, align 8
  %v2863 = load i64, ptr %slot390, align 8
  %p2864 = inttoptr i64 %v2863 to ptr
  %ld2865 = load i64, ptr %p2864, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2865, ptr %slot408, align 8
  %v2866 = load i64, ptr %slot408, align 8
  %cmp2867 = icmp ne i64 %v2866, 0
  %cv2868 = zext i1 %cmp2867 to i32
  store i32 %cv2868, ptr %slot409, align 8
  %v2869 = load i32, ptr %slot409, align 8
  %cv2870 = zext i32 %v2869 to i64
  %cond2871 = icmp ne i64 %cv2870, 0
  br i1 %cond2871, label %bb_rcgnn558, label %bb_rcgdone558
bb_rcgnn558:
  %v2872 = load i64, ptr %slot408, align 8
  %op2873 = sub i64 %v2872, 16
  store i64 %op2873, ptr %slot410, align 8
  %v2874 = load i64, ptr %slot408, align 8
  %p2875 = inttoptr i64 %v2874 to ptr
  %rgep2876 = getelementptr i8, ptr %p2875, i64 -16
  %ld2877 = load i64, ptr %rgep2876, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2877, ptr %slot411, align 8
  %v2878 = load i64, ptr %slot411, align 8
  %op2879 = and i64 %v2878, 4611686018427387906
  store i64 %op2879, ptr %slot412, align 8
  %v2880 = load i64, ptr %slot412, align 8
  %cmp2881 = icmp ne i64 %v2880, 0
  %cv2882 = zext i1 %cmp2881 to i32
  store i32 %cv2882, ptr %slot413, align 8
  %v2883 = load i32, ptr %slot413, align 8
  %cv2884 = zext i32 %v2883 to i64
  %cond2885 = icmp ne i64 %cv2884, 0
  br i1 %cond2885, label %bb_rcgclear558, label %bb_rcgcounted558
bb_rcgcounted558:
  %v2886 = load i64, ptr %slot408, align 8
  %op2887 = sub i64 %v2886, 32
  store i64 %op2887, ptr %slot414, align 8
  %v2888 = load i64, ptr %slot408, align 8
  %p2889 = inttoptr i64 %v2888 to ptr
  %rgep2890 = getelementptr i8, ptr %p2889, i64 -32
  %ld2891 = load i64, ptr %rgep2890, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2891, ptr %slot415, align 8
  %v2892 = load i64, ptr %slot415, align 8
  %op2893 = sub i64 %v2892, 1
  store i64 %op2893, ptr %slot416, align 8
  %v2894 = load i64, ptr %slot416, align 8
  %cmp2895 = icmp eq i64 %v2894, 0
  %cv2896 = zext i1 %cmp2895 to i32
  store i32 %cv2896, ptr %slot417, align 8
  %v2897 = load i32, ptr %slot417, align 8
  %cv2898 = zext i32 %v2897 to i64
  %cond2899 = icmp ne i64 %cv2898, 0
  br i1 %cond2899, label %bb_rcglast558, label %bb_rcgdec558
bb_rcglast558:
  %v2900 = load i64, ptr %slot408, align 8
  %op2901 = sub i64 %v2900, 24
  store i64 %op2901, ptr %slot418, align 8
  %v2902 = load i64, ptr %slot408, align 8
  %p2903 = inttoptr i64 %v2902 to ptr
  %rgep2904 = getelementptr i8, ptr %p2903, i64 -24
  %ld2905 = load i64, ptr %rgep2904, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2905, ptr %slot419, align 8
  %v2906 = load i64, ptr %slot419, align 8
  %cmp2907 = icmp ne i64 %v2906, 0
  %cv2908 = zext i1 %cmp2907 to i32
  store i32 %cv2908, ptr %slot420, align 8
  %v2909 = load i32, ptr %slot420, align 8
  %cv2910 = zext i32 %v2909 to i64
  %cond2911 = icmp ne i64 %cv2910, 0
  br i1 %cond2911, label %bb_rcgdec558, label %bb_rcgslow558
bb_rcgslow558:
  %v2912 = load i64, ptr %slot407, align 8
  %v2913 = load i64, ptr %slot390, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64 %v2912, i64 %v2913) nomerge, !dbg !124
  br label %bb_rcgdone558
bb_rcgdec558:
  %v2914 = load i64, ptr %slot416, align 8
  %v2915 = load i64, ptr %slot408, align 8
  %p2916 = inttoptr i64 %v2915 to ptr
  %rgep2917 = getelementptr i8, ptr %p2916, i64 -32
  store i64 %v2914, ptr %rgep2917, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear558
bb_rcgclear558:
  %v2918 = load i64, ptr %slot390, align 8
  %p2919 = inttoptr i64 %v2918 to ptr
  store i64 0, ptr %p2919, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone558
bb_rcgdone558:
  br label %bb_rcslotdone527
bb_rcslotdone527:
  br label %bb_rcprepared473
bb_rcprepared473:
  %v2920 = load i64, ptr %slot29, align 8
  store i64 %v2920, ptr %slot421, align 8
  %v2921 = load i64, ptr %slot421, align 8
  %v2922 = load i64, ptr %slot347, align 8
  %p2923 = inttoptr i64 %v2921 to ptr
  %p2924 = inttoptr i64 %v2922 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p2924, ptr %p2923, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v2925 = load i64, ptr %slot19, align 8
  %p2926 = inttoptr i64 %v2925 to ptr
  store i32 0, ptr %p2926, align 4, !alias.scope !3, !noalias !4
  %v2927 = load i64, ptr %slot45, align 8
  store i64 %v2927, ptr %slot422, align 8
  %v2928 = load i64, ptr %slot227, align 8
  %p2930 = inttoptr i64 %v2928 to ptr
  %gep2931 = getelementptr i8, ptr %p2930, i64 264
  %op2929 = ptrtoint ptr %gep2931 to i64
  store i64 %op2929, ptr %slot423, align 8
  %v2932 = load i64, ptr %slot422, align 8
  %p2933 = inttoptr i64 %v2932 to ptr
  %ld2934 = load i64, ptr %p2933, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2934, ptr %slot424, align 8
  %v2935 = load i64, ptr %slot424, align 8
  %v2936 = load i64, ptr %slot423, align 8
  %p2937 = inttoptr i64 %v2936 to ptr
  store i64 %v2935, ptr %p2937, align 8, !alias.scope !3, !noalias !4
  %v2938 = load i64, ptr %slot46, align 8
  store i64 %v2938, ptr %slot425, align 8
  %v2939 = load i64, ptr %slot227, align 8
  %p2941 = inttoptr i64 %v2939 to ptr
  %gep2942 = getelementptr i8, ptr %p2941, i64 272
  %op2940 = ptrtoint ptr %gep2942 to i64
  store i64 %op2940, ptr %slot426, align 8
  %v2943 = load i64, ptr %slot425, align 8
  %p2944 = inttoptr i64 %v2943 to ptr
  %ld2945 = load i8, ptr %p2944, align 1, !alias.scope !3, !noalias !4
  %ext2946 = zext i8 %ld2945 to i64
  store i64 %ext2946, ptr %slot427, align 8
  %v2947 = load i64, ptr %slot427, align 8
  %cv2948 = trunc i64 %v2947 to i8
  %v2949 = load i64, ptr %slot426, align 8
  %p2950 = inttoptr i64 %v2949 to ptr
  store i8 %cv2948, ptr %p2950, align 1, !alias.scope !3, !noalias !4
  %v2951 = load i64, ptr %slot47, align 8
  %p2952 = inttoptr i64 %v2951 to ptr
  %ld2953 = load i64, ptr %p2952, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2953, ptr %slot428, align 8
  %v2954 = load i64, ptr %slot227, align 8
  %p2956 = inttoptr i64 %v2954 to ptr
  %gep2957 = getelementptr i8, ptr %p2956, i64 280
  %op2955 = ptrtoint ptr %gep2957 to i64
  store i64 %op2955, ptr %slot429, align 8
  %v2958 = load i64, ptr %slot47, align 8
  %p2959 = inttoptr i64 %v2958 to ptr
  %ld2960 = load i64, ptr %p2959, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2960, ptr %slot430, align 8
  %v2961 = load i64, ptr %slot29, align 8
  store i64 %v2961, ptr %slot431, align 8
  %v2962 = load i64, ptr %slot57, align 8
  store i64 %v2962, ptr %slot432, align 8
  %v2963 = load i64, ptr %slot430, align 8
  %op2964 = add i64 %v2963, 0
  store i64 %op2964, ptr %slot433, align 8
  %v2965 = load i64, ptr %slot433, align 8
  %p2966 = inttoptr i64 %v2965 to ptr
  %ld2967 = load i64, ptr %p2966, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2967, ptr %slot434, align 8
  %v2968 = load i64, ptr %slot434, align 8
  %cmp2969 = icmp ne i64 %v2968, 0
  %cv2970 = zext i1 %cmp2969 to i32
  store i32 %cv2970, ptr %slot435, align 8
  %v2971 = load i32, ptr %slot435, align 8
  %cv2972 = zext i32 %v2971 to i64
  %cond2973 = icmp ne i64 %cv2972, 0
  br i1 %cond2973, label %bb_rcmoveheader578, label %bb_rcmovenext578
bb_rcmoveheader578:
  %v2974 = load i64, ptr %slot434, align 8
  %op2975 = sub i64 %v2974, 16
  store i64 %op2975, ptr %slot436, align 8
  %v2976 = load i64, ptr %slot434, align 8
  %p2977 = inttoptr i64 %v2976 to ptr
  %rgep2978 = getelementptr i8, ptr %p2977, i64 -16
  %ld2979 = load i64, ptr %rgep2978, align 8, !alias.scope !9, !noalias !10
  store i64 %ld2979, ptr %slot437, align 8
  %v2980 = load i64, ptr %slot437, align 8
  %op2981 = and i64 %v2980, 5764607523034234881
  store i64 %op2981, ptr %slot438, align 8
  %v2982 = load i64, ptr %slot438, align 8
  %cmp2983 = icmp ne i64 %v2982, 0
  %cv2984 = zext i1 %cmp2983 to i32
  store i32 %cv2984, ptr %slot439, align 8
  %v2985 = load i32, ptr %slot439, align 8
  %cv2986 = zext i32 %v2985 to i64
  %cond2987 = icmp ne i64 %cv2986, 0
  br i1 %cond2987, label %bb_rcmoveslow575, label %bb_rcmovenext578
bb_rcmovenext578:
  %v2988 = load i64, ptr %slot430, align 8
  %op2989 = add i64 %v2988, 8
  store i64 %op2989, ptr %slot440, align 8
  %v2990 = load i64, ptr %slot440, align 8
  %p2991 = inttoptr i64 %v2990 to ptr
  %ld2992 = load i64, ptr %p2991, align 8, !alias.scope !3, !noalias !4
  store i64 %ld2992, ptr %slot441, align 8
  %v2993 = load i64, ptr %slot441, align 8
  %cmp2994 = icmp ne i64 %v2993, 0
  %cv2995 = zext i1 %cmp2994 to i32
  store i32 %cv2995, ptr %slot442, align 8
  %v2996 = load i32, ptr %slot442, align 8
  %cv2997 = zext i32 %v2996 to i64
  %cond2998 = icmp ne i64 %cv2997, 0
  br i1 %cond2998, label %bb_rcmoveheader586, label %bb_rcmovenext586
bb_rcmoveheader586:
  %v2999 = load i64, ptr %slot441, align 8
  %op3000 = sub i64 %v2999, 16
  store i64 %op3000, ptr %slot443, align 8
  %v3001 = load i64, ptr %slot441, align 8
  %p3002 = inttoptr i64 %v3001 to ptr
  %rgep3003 = getelementptr i8, ptr %p3002, i64 -16
  %ld3004 = load i64, ptr %rgep3003, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3004, ptr %slot444, align 8
  %v3005 = load i64, ptr %slot444, align 8
  %op3006 = and i64 %v3005, 5764607523034234881
  store i64 %op3006, ptr %slot445, align 8
  %v3007 = load i64, ptr %slot445, align 8
  %cmp3008 = icmp ne i64 %v3007, 0
  %cv3009 = zext i1 %cmp3008 to i32
  store i32 %cv3009, ptr %slot446, align 8
  %v3010 = load i32, ptr %slot446, align 8
  %cv3011 = zext i32 %v3010 to i64
  %cond3012 = icmp ne i64 %cv3011, 0
  br i1 %cond3012, label %bb_rcmoveslow575, label %bb_rcmovenext586
bb_rcmovenext586:
  %v3013 = load i64, ptr %slot430, align 8
  %op3014 = add i64 %v3013, 16
  store i64 %op3014, ptr %slot447, align 8
  %v3015 = load i64, ptr %slot447, align 8
  %p3016 = inttoptr i64 %v3015 to ptr
  %ld3017 = load i64, ptr %p3016, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3017, ptr %slot448, align 8
  %v3018 = load i64, ptr %slot448, align 8
  %cmp3019 = icmp ne i64 %v3018, 0
  %cv3020 = zext i1 %cmp3019 to i32
  store i32 %cv3020, ptr %slot449, align 8
  %v3021 = load i32, ptr %slot449, align 8
  %cv3022 = zext i32 %v3021 to i64
  %cond3023 = icmp ne i64 %cv3022, 0
  br i1 %cond3023, label %bb_rcmoveheader594, label %bb_rcmovenext594
bb_rcmoveheader594:
  %v3024 = load i64, ptr %slot448, align 8
  %op3025 = sub i64 %v3024, 16
  store i64 %op3025, ptr %slot450, align 8
  %v3026 = load i64, ptr %slot448, align 8
  %p3027 = inttoptr i64 %v3026 to ptr
  %rgep3028 = getelementptr i8, ptr %p3027, i64 -16
  %ld3029 = load i64, ptr %rgep3028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3029, ptr %slot451, align 8
  %v3030 = load i64, ptr %slot451, align 8
  %op3031 = and i64 %v3030, 5764607523034234881
  store i64 %op3031, ptr %slot452, align 8
  %v3032 = load i64, ptr %slot452, align 8
  %cmp3033 = icmp ne i64 %v3032, 0
  %cv3034 = zext i1 %cmp3033 to i32
  store i32 %cv3034, ptr %slot453, align 8
  %v3035 = load i32, ptr %slot453, align 8
  %cv3036 = zext i32 %v3035 to i64
  %cond3037 = icmp ne i64 %cv3036, 0
  br i1 %cond3037, label %bb_rcmoveslow575, label %bb_rcmovenext594
bb_rcmovenext594:
  %v3038 = load i64, ptr %slot430, align 8
  %op3039 = add i64 %v3038, 24
  store i64 %op3039, ptr %slot454, align 8
  %v3040 = load i64, ptr %slot454, align 8
  %p3041 = inttoptr i64 %v3040 to ptr
  %ld3042 = load i64, ptr %p3041, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3042, ptr %slot455, align 8
  %v3043 = load i64, ptr %slot455, align 8
  %cmp3044 = icmp ne i64 %v3043, 0
  %cv3045 = zext i1 %cmp3044 to i32
  store i32 %cv3045, ptr %slot456, align 8
  %v3046 = load i32, ptr %slot456, align 8
  %cv3047 = zext i32 %v3046 to i64
  %cond3048 = icmp ne i64 %cv3047, 0
  br i1 %cond3048, label %bb_rcmoveheader602, label %bb_rcmovenext602
bb_rcmoveheader602:
  %v3049 = load i64, ptr %slot455, align 8
  %op3050 = sub i64 %v3049, 16
  store i64 %op3050, ptr %slot457, align 8
  %v3051 = load i64, ptr %slot455, align 8
  %p3052 = inttoptr i64 %v3051 to ptr
  %rgep3053 = getelementptr i8, ptr %p3052, i64 -16
  %ld3054 = load i64, ptr %rgep3053, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3054, ptr %slot458, align 8
  %v3055 = load i64, ptr %slot458, align 8
  %op3056 = and i64 %v3055, 5764607523034234881
  store i64 %op3056, ptr %slot459, align 8
  %v3057 = load i64, ptr %slot459, align 8
  %cmp3058 = icmp ne i64 %v3057, 0
  %cv3059 = zext i1 %cmp3058 to i32
  store i32 %cv3059, ptr %slot460, align 8
  %v3060 = load i32, ptr %slot460, align 8
  %cv3061 = zext i32 %v3060 to i64
  %cond3062 = icmp ne i64 %cv3061, 0
  br i1 %cond3062, label %bb_rcmoveslow575, label %bb_rcmovenext602
bb_rcmovenext602:
  %v3063 = load i64, ptr %slot430, align 8
  %v3064 = load i64, ptr %slot431, align 8
  %p3065 = inttoptr i64 %v3063 to ptr
  %p3066 = inttoptr i64 %v3064 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3066, ptr %p3065, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3067 = load i64, ptr %slot430, align 8
  %p3068 = inttoptr i64 %v3067 to ptr
  store i64 0, ptr %p3068, align 8, !alias.scope !3, !noalias !4
  %v3069 = load i64, ptr %slot430, align 8
  %op3070 = add i64 %v3069, 8
  store i64 %op3070, ptr %slot461, align 8
  %v3071 = load i64, ptr %slot461, align 8
  %p3072 = inttoptr i64 %v3071 to ptr
  store i64 0, ptr %p3072, align 8, !alias.scope !3, !noalias !4
  %v3073 = load i64, ptr %slot430, align 8
  %op3074 = add i64 %v3073, 16
  store i64 %op3074, ptr %slot462, align 8
  %v3075 = load i64, ptr %slot462, align 8
  %p3076 = inttoptr i64 %v3075 to ptr
  store i64 0, ptr %p3076, align 8, !alias.scope !3, !noalias !4
  %v3077 = load i64, ptr %slot430, align 8
  %op3078 = add i64 %v3077, 24
  store i64 %op3078, ptr %slot463, align 8
  %v3079 = load i64, ptr %slot463, align 8
  %p3080 = inttoptr i64 %v3079 to ptr
  store i64 0, ptr %p3080, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcmoved575
bb_rcmoveslow575:
  %v3081 = load i64, ptr %slot56, align 8
  %v3082 = load i64, ptr %slot431, align 8
  %v3083 = load i64, ptr %slot430, align 8
  %v3084 = load i64, ptr %slot432, align 8
  %cv3085 = trunc i64 %v3084 to i32
  %call3086 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_take(i64 %v3081, i64 %v3082, i64 %v3083, i32 %cv3085) nomerge, !dbg !124
  store i32 %call3086, ptr %slot464, align 8
  %v3087 = load i32, ptr %slot464, align 8
  %cv3088 = zext i32 %v3087 to i64
  %cond3089 = icmp ne i64 %cv3088, 0
  br i1 %cond3089, label %bb_rcsuccess612, label %bb_rcfailure612
bb_rcfailure612:
  %v3090 = load i64, ptr %slot56, align 8
  %p3091 = inttoptr i64 %v3090 to ptr
  %call3092 = call i32 @myl_rc_take_failure(ptr %p3091) nomerge, !dbg !124
  store i32 %call3092, ptr %slot465, align 8
  %v3093 = load i64, ptr %slot1, align 8
  %p3094 = inttoptr i64 %v3093 to ptr
  %v3095 = load i32, ptr %slot465, align 8
  %call3096 = call i32 @myl_qbe_rc_status(ptr %p3094, i32 %v3095) nomerge, !dbg !124
  store i32 %call3096, ptr %slot466, align 8
  br label %bb_failure
bb_rcsuccess612:
  br label %bb_rcmoved575
bb_rcmoved575:
  %v3097 = load i64, ptr %slot18, align 8
  %p3098 = inttoptr i64 %v3097 to ptr
  store i32 0, ptr %p3098, align 4, !alias.scope !3, !noalias !4
  %v3099 = load i64, ptr %slot20, align 8
  %p3100 = inttoptr i64 %v3099 to ptr
  store i32 2, ptr %p3100, align 4, !alias.scope !3, !noalias !4
  %v3101 = load i64, ptr %slot19, align 8
  %p3102 = inttoptr i64 %v3101 to ptr
  store i32 1, ptr %p3102, align 4, !alias.scope !3, !noalias !4
  %v3103 = load i64, ptr %slot29, align 8
  store i64 %v3103, ptr %slot467, align 8
  %v3104 = load i64, ptr %slot467, align 8
  %v3105 = load i64, ptr %slot429, align 8
  %p3106 = inttoptr i64 %v3104 to ptr
  %p3107 = inttoptr i64 %v3105 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3107, ptr %p3106, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v3108 = load i64, ptr %slot19, align 8
  %p3109 = inttoptr i64 %v3108 to ptr
  store i32 0, ptr %p3109, align 4, !alias.scope !3, !noalias !4
  %v3110 = load i64, ptr %slot227, align 8
  %v3111 = load i64, ptr %slot41, align 8
  %p3112 = inttoptr i64 %v3111 to ptr
  store i64 %v3110, ptr %p3112, align 8, !alias.scope !3, !noalias !4
  %v3113 = load i64, ptr %slot41, align 8
  %p3114 = inttoptr i64 %v3113 to ptr
  %ld3115 = load i64, ptr %p3114, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3115, ptr %slot468, align 8
  %v3116 = load i64, ptr %slot22, align 8
  store i64 %v3116, ptr %slot469, align 8
  %v3117 = load i64, ptr %slot468, align 8
  %v3118 = load i64, ptr %slot469, align 8
  %p3119 = inttoptr i64 %v3117 to ptr
  %p3120 = inttoptr i64 %v3118 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3120, ptr %p3119, i64 312, i1 false)
  %v3121 = load i64, ptr %slot12, align 8
  %p3122 = inttoptr i64 %v3121 to ptr
  store i32 2, ptr %p3122, align 4, !alias.scope !3, !noalias !4
  %v3123 = load i64, ptr %slot11, align 8
  %p3124 = inttoptr i64 %v3123 to ptr
  store i32 1, ptr %p3124, align 4, !alias.scope !3, !noalias !4
  %v3125 = load i64, ptr %slot469, align 8
  %v3126 = load i64, ptr %slot41, align 8
  %p3127 = inttoptr i64 %v3126 to ptr
  store i64 %v3125, ptr %p3127, align 8, !alias.scope !3, !noalias !4
  %v3128 = load i64, ptr %slot41, align 8
  %p3129 = inttoptr i64 %v3128 to ptr
  %ld3130 = load i64, ptr %p3129, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3130, ptr %slot470, align 8
  %v3131 = load i64, ptr %slot29, align 8
  store i64 %v3131, ptr %slot471, align 8
  %v3132 = load i64, ptr %slot57, align 8
  store i64 %v3132, ptr %slot472, align 8
  %v3133 = load i64, ptr %slot56, align 8
  %v3134 = load i64, ptr %slot471, align 8
  %v3135 = load i64, ptr %slot470, align 8
  %v3136 = load i64, ptr %slot472, align 8
  %cv3137 = trunc i64 %v3136 to i32
  %call3138 = call i32 @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_take(i64 %v3133, i64 %v3134, i64 %v3135, i32 %cv3137) nomerge, !dbg !126
  store i32 %call3138, ptr %slot473, align 8
  %v3139 = load i32, ptr %slot473, align 8
  %cv3140 = zext i32 %v3139 to i64
  %cond3141 = icmp ne i64 %cv3140, 0
  br i1 %cond3141, label %bb_rcsuccess628, label %bb_rcfailure628
bb_rcfailure628:
  %v3142 = load i64, ptr %slot56, align 8
  %p3143 = inttoptr i64 %v3142 to ptr
  %call3144 = call i32 @myl_rc_take_failure(ptr %p3143) nomerge, !dbg !126
  store i32 %call3144, ptr %slot474, align 8
  %v3145 = load i64, ptr %slot1, align 8
  %p3146 = inttoptr i64 %v3145 to ptr
  %v3147 = load i32, ptr %slot474, align 8
  %call3148 = call i32 @myl_qbe_rc_status(ptr %p3146, i32 %v3147) nomerge, !dbg !126
  store i32 %call3148, ptr %slot475, align 8
  br label %bb_failure
bb_rcsuccess628:
  %v3149 = load i64, ptr %slot11, align 8
  %p3150 = inttoptr i64 %v3149 to ptr
  store i32 0, ptr %p3150, align 4, !alias.scope !3, !noalias !4
  %v3151 = load i64, ptr %slot20, align 8
  %p3152 = inttoptr i64 %v3151 to ptr
  store i32 2, ptr %p3152, align 4, !alias.scope !3, !noalias !4
  %v3153 = load i64, ptr %slot19, align 8
  %p3154 = inttoptr i64 %v3153 to ptr
  store i32 1, ptr %p3154, align 4, !alias.scope !3, !noalias !4
  %v3155 = load i64, ptr %slot9, align 8
  %p3156 = inttoptr i64 %v3155 to ptr
  %ld3157 = load i32, ptr %p3156, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3157, ptr %slot476, align 8
  %v3158 = load i32, ptr %slot476, align 8
  %cv3159 = zext i32 %v3158 to i64
  %cond3160 = icmp ne i64 %cv3159, 0
  br i1 %cond3160, label %bb_rcslotdrop637, label %bb_rcslotdone637
bb_rcslotdrop637:
  %v3161 = load i64, ptr %slot9, align 8
  %p3162 = inttoptr i64 %v3161 to ptr
  store i32 0, ptr %p3162, align 4, !alias.scope !3, !noalias !4
  %v3163 = load i64, ptr %slot38, align 8
  store i64 %v3163, ptr %slot477, align 8
  %v3164 = load i64, ptr %slot10, align 8
  %p3165 = inttoptr i64 %v3164 to ptr
  %ld3166 = load i32, ptr %p3165, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3166, ptr %slot478, align 8
  %v3167 = load i32, ptr %slot478, align 8
  %op3168 = and i32 %v3167, 28
  store i32 %op3168, ptr %slot479, align 8
  %v3169 = load i32, ptr %slot479, align 8
  %cv3170 = zext i32 %v3169 to i64
  %cond3171 = icmp ne i64 %cv3170, 0
  br i1 %cond3171, label %bb_rcslotrole637, label %bb_rcslotowner637
bb_rcslotrole637:
  %v3172 = load i64, ptr %slot56, align 8
  store i64 %v3172, ptr %slot480, align 8
  %v3173 = load i64, ptr %slot480, align 8
  %v3174 = load i64, ptr %slot477, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3173, i64 %v3174) nomerge, !dbg !126
  br label %bb_rcslotdone637
bb_rcslotowner637:
  %v3175 = load i64, ptr %slot56, align 8
  store i64 %v3175, ptr %slot481, align 8
  %v3176 = load i64, ptr %slot481, align 8
  %v3177 = load i64, ptr %slot477, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3176, i64 %v3177) nomerge, !dbg !126
  br label %bb_rcslotdone637
bb_rcslotdone637:
  %v3178 = load i64, ptr %slot38, align 8
  store i64 %v3178, ptr %slot482, align 8
  %v3179 = load i64, ptr %slot29, align 8
  store i64 %v3179, ptr %slot483, align 8
  %v3180 = load i64, ptr %slot483, align 8
  %v3181 = load i64, ptr %slot482, align 8
  %p3182 = inttoptr i64 %v3180 to ptr
  %p3183 = inttoptr i64 %v3181 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3183, ptr %p3182, i64 312, i1 false), !alias.scope !3, !noalias !4
  %v3184 = load i64, ptr %slot19, align 8
  %p3185 = inttoptr i64 %v3184 to ptr
  store i32 0, ptr %p3185, align 4, !alias.scope !3, !noalias !4
  %v3186 = load i64, ptr %slot10, align 8
  %p3187 = inttoptr i64 %v3186 to ptr
  store i32 2, ptr %p3187, align 4, !alias.scope !3, !noalias !4
  %v3188 = load i64, ptr %slot20, align 8
  %p3189 = inttoptr i64 %v3188 to ptr
  %ld3190 = load i32, ptr %p3189, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3190, ptr %slot484, align 8
  %v3191 = load i32, ptr %slot484, align 8
  %v3192 = load i64, ptr %slot10, align 8
  %p3193 = inttoptr i64 %v3192 to ptr
  store i32 %v3191, ptr %p3193, align 4, !alias.scope !3, !noalias !4
  %v3194 = load i64, ptr %slot9, align 8
  %p3195 = inttoptr i64 %v3194 to ptr
  store i32 1, ptr %p3195, align 4, !alias.scope !3, !noalias !4
  %v3196 = load i64, ptr %slot7, align 8
  %p3197 = inttoptr i64 %v3196 to ptr
  %ld3198 = load i32, ptr %p3197, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3198, ptr %slot485, align 8
  %v3199 = load i32, ptr %slot485, align 8
  %cv3200 = zext i32 %v3199 to i64
  %cond3201 = icmp ne i64 %cv3200, 0
  br i1 %cond3201, label %bb_rcslotdrop653, label %bb_rcslotdone653
bb_rcslotdrop653:
  %v3202 = load i64, ptr %slot7, align 8
  %p3203 = inttoptr i64 %v3202 to ptr
  store i32 0, ptr %p3203, align 4, !alias.scope !3, !noalias !4
  %v3204 = load i64, ptr %slot37, align 8
  store i64 %v3204, ptr %slot486, align 8
  %v3205 = load i64, ptr %slot8, align 8
  %p3206 = inttoptr i64 %v3205 to ptr
  %ld3207 = load i32, ptr %p3206, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3207, ptr %slot487, align 8
  %v3208 = load i32, ptr %slot487, align 8
  %op3209 = and i32 %v3208, 28
  store i32 %op3209, ptr %slot488, align 8
  %v3210 = load i32, ptr %slot488, align 8
  %cv3211 = zext i32 %v3210 to i64
  %cond3212 = icmp ne i64 %cv3211, 0
  br i1 %cond3212, label %bb_rcslotrole653, label %bb_rcslotowner653
bb_rcslotrole653:
  %v3213 = load i64, ptr %slot56, align 8
  store i64 %v3213, ptr %slot489, align 8
  %v3214 = load i64, ptr %slot486, align 8
  %p3215 = inttoptr i64 %v3214 to ptr
  %ld3216 = load i64, ptr %p3215, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3216, ptr %slot490, align 8
  %v3217 = load i64, ptr %slot490, align 8
  %cmp3218 = icmp ne i64 %v3217, 0
  %cv3219 = zext i1 %cmp3218 to i32
  store i32 %cv3219, ptr %slot491, align 8
  %v3220 = load i32, ptr %slot491, align 8
  %cv3221 = zext i32 %v3220 to i64
  %cond3222 = icmp ne i64 %cv3221, 0
  br i1 %cond3222, label %bb_rcgnn669, label %bb_rcgdone669
bb_rcgnn669:
  %v3223 = load i64, ptr %slot490, align 8
  %op3224 = sub i64 %v3223, 16
  store i64 %op3224, ptr %slot492, align 8
  %v3225 = load i64, ptr %slot490, align 8
  %p3226 = inttoptr i64 %v3225 to ptr
  %rgep3227 = getelementptr i8, ptr %p3226, i64 -16
  %ld3228 = load i64, ptr %rgep3227, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3228, ptr %slot493, align 8
  %v3229 = load i64, ptr %slot493, align 8
  %op3230 = and i64 %v3229, 4611686018427387906
  store i64 %op3230, ptr %slot494, align 8
  %v3231 = load i64, ptr %slot494, align 8
  %cmp3232 = icmp ne i64 %v3231, 0
  %cv3233 = zext i1 %cmp3232 to i32
  store i32 %cv3233, ptr %slot495, align 8
  %v3234 = load i32, ptr %slot495, align 8
  %cv3235 = zext i32 %v3234 to i64
  %cond3236 = icmp ne i64 %cv3235, 0
  br i1 %cond3236, label %bb_rcgclear669, label %bb_rcgcounted669
bb_rcgcounted669:
  %v3237 = load i64, ptr %slot490, align 8
  %op3238 = sub i64 %v3237, 24
  store i64 %op3238, ptr %slot496, align 8
  %v3239 = load i64, ptr %slot490, align 8
  %p3240 = inttoptr i64 %v3239 to ptr
  %rgep3241 = getelementptr i8, ptr %p3240, i64 -24
  %ld3242 = load i64, ptr %rgep3241, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3242, ptr %slot497, align 8
  %v3243 = load i64, ptr %slot497, align 8
  %op3244 = sub i64 %v3243, 1
  store i64 %op3244, ptr %slot498, align 8
  %v3245 = load i64, ptr %slot498, align 8
  %cmp3246 = icmp eq i64 %v3245, 0
  %cv3247 = zext i1 %cmp3246 to i32
  store i32 %cv3247, ptr %slot499, align 8
  %v3248 = load i32, ptr %slot499, align 8
  %cv3249 = zext i32 %v3248 to i64
  %cond3250 = icmp ne i64 %cv3249, 0
  br i1 %cond3250, label %bb_rcglast669, label %bb_rcgdec669
bb_rcglast669:
  %v3251 = load i64, ptr %slot490, align 8
  %op3252 = sub i64 %v3251, 32
  store i64 %op3252, ptr %slot500, align 8
  %v3253 = load i64, ptr %slot490, align 8
  %p3254 = inttoptr i64 %v3253 to ptr
  %rgep3255 = getelementptr i8, ptr %p3254, i64 -32
  %ld3256 = load i64, ptr %rgep3255, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3256, ptr %slot501, align 8
  %v3257 = load i64, ptr %slot501, align 8
  %cmp3258 = icmp ne i64 %v3257, 0
  %cv3259 = zext i1 %cmp3258 to i32
  store i32 %cv3259, ptr %slot502, align 8
  %v3260 = load i32, ptr %slot502, align 8
  %cv3261 = zext i32 %v3260 to i64
  %cond3262 = icmp ne i64 %cv3261, 0
  br i1 %cond3262, label %bb_rcgdec669, label %bb_rcgslow669
bb_rcgslow669:
  %v3263 = load i64, ptr %slot489, align 8
  %v3264 = load i64, ptr %slot486, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64 %v3263, i64 %v3264) nomerge, !dbg !126
  br label %bb_rcgdone669
bb_rcgdec669:
  %v3265 = load i64, ptr %slot498, align 8
  %v3266 = load i64, ptr %slot490, align 8
  %p3267 = inttoptr i64 %v3266 to ptr
  %rgep3268 = getelementptr i8, ptr %p3267, i64 -24
  store i64 %v3265, ptr %rgep3268, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear669
bb_rcgclear669:
  %v3269 = load i64, ptr %slot486, align 8
  %p3270 = inttoptr i64 %v3269 to ptr
  store i64 0, ptr %p3270, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone669
bb_rcgdone669:
  br label %bb_rcslotdone653
bb_rcslotowner653:
  %v3271 = load i64, ptr %slot56, align 8
  store i64 %v3271, ptr %slot503, align 8
  %v3272 = load i64, ptr %slot486, align 8
  %p3273 = inttoptr i64 %v3272 to ptr
  %ld3274 = load i64, ptr %p3273, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3274, ptr %slot504, align 8
  %v3275 = load i64, ptr %slot504, align 8
  %cmp3276 = icmp ne i64 %v3275, 0
  %cv3277 = zext i1 %cmp3276 to i32
  store i32 %cv3277, ptr %slot505, align 8
  %v3278 = load i32, ptr %slot505, align 8
  %cv3279 = zext i32 %v3278 to i64
  %cond3280 = icmp ne i64 %cv3279, 0
  br i1 %cond3280, label %bb_rcgnn684, label %bb_rcgdone684
bb_rcgnn684:
  %v3281 = load i64, ptr %slot504, align 8
  %op3282 = sub i64 %v3281, 16
  store i64 %op3282, ptr %slot506, align 8
  %v3283 = load i64, ptr %slot504, align 8
  %p3284 = inttoptr i64 %v3283 to ptr
  %rgep3285 = getelementptr i8, ptr %p3284, i64 -16
  %ld3286 = load i64, ptr %rgep3285, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3286, ptr %slot507, align 8
  %v3287 = load i64, ptr %slot507, align 8
  %op3288 = and i64 %v3287, 4611686018427387906
  store i64 %op3288, ptr %slot508, align 8
  %v3289 = load i64, ptr %slot508, align 8
  %cmp3290 = icmp ne i64 %v3289, 0
  %cv3291 = zext i1 %cmp3290 to i32
  store i32 %cv3291, ptr %slot509, align 8
  %v3292 = load i32, ptr %slot509, align 8
  %cv3293 = zext i32 %v3292 to i64
  %cond3294 = icmp ne i64 %cv3293, 0
  br i1 %cond3294, label %bb_rcgclear684, label %bb_rcgcounted684
bb_rcgcounted684:
  %v3295 = load i64, ptr %slot504, align 8
  %op3296 = sub i64 %v3295, 32
  store i64 %op3296, ptr %slot510, align 8
  %v3297 = load i64, ptr %slot504, align 8
  %p3298 = inttoptr i64 %v3297 to ptr
  %rgep3299 = getelementptr i8, ptr %p3298, i64 -32
  %ld3300 = load i64, ptr %rgep3299, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3300, ptr %slot511, align 8
  %v3301 = load i64, ptr %slot511, align 8
  %op3302 = sub i64 %v3301, 1
  store i64 %op3302, ptr %slot512, align 8
  %v3303 = load i64, ptr %slot512, align 8
  %cmp3304 = icmp eq i64 %v3303, 0
  %cv3305 = zext i1 %cmp3304 to i32
  store i32 %cv3305, ptr %slot513, align 8
  %v3306 = load i32, ptr %slot513, align 8
  %cv3307 = zext i32 %v3306 to i64
  %cond3308 = icmp ne i64 %cv3307, 0
  br i1 %cond3308, label %bb_rcglast684, label %bb_rcgdec684
bb_rcglast684:
  %v3309 = load i64, ptr %slot504, align 8
  %op3310 = sub i64 %v3309, 24
  store i64 %op3310, ptr %slot514, align 8
  %v3311 = load i64, ptr %slot504, align 8
  %p3312 = inttoptr i64 %v3311 to ptr
  %rgep3313 = getelementptr i8, ptr %p3312, i64 -24
  %ld3314 = load i64, ptr %rgep3313, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3314, ptr %slot515, align 8
  %v3315 = load i64, ptr %slot515, align 8
  %cmp3316 = icmp ne i64 %v3315, 0
  %cv3317 = zext i1 %cmp3316 to i32
  store i32 %cv3317, ptr %slot516, align 8
  %v3318 = load i32, ptr %slot516, align 8
  %cv3319 = zext i32 %v3318 to i64
  %cond3320 = icmp ne i64 %cv3319, 0
  br i1 %cond3320, label %bb_rcgdec684, label %bb_rcgslow684
bb_rcgslow684:
  %v3321 = load i64, ptr %slot503, align 8
  %v3322 = load i64, ptr %slot486, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64 %v3321, i64 %v3322) nomerge, !dbg !126
  br label %bb_rcgdone684
bb_rcgdec684:
  %v3323 = load i64, ptr %slot512, align 8
  %v3324 = load i64, ptr %slot504, align 8
  %p3325 = inttoptr i64 %v3324 to ptr
  %rgep3326 = getelementptr i8, ptr %p3325, i64 -32
  store i64 %v3323, ptr %rgep3326, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear684
bb_rcgclear684:
  %v3327 = load i64, ptr %slot486, align 8
  %p3328 = inttoptr i64 %v3327 to ptr
  store i64 0, ptr %p3328, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone684
bb_rcgdone684:
  br label %bb_rcslotdone653
bb_rcslotdone653:
  %v3329 = load i64, ptr %slot38, align 8
  %v3330 = load i64, ptr %slot41, align 8
  %p3331 = inttoptr i64 %v3330 to ptr
  store i64 %v3329, ptr %p3331, align 8, !alias.scope !3, !noalias !4
  %v3332 = load i64, ptr %slot41, align 8
  %p3333 = inttoptr i64 %v3332 to ptr
  %ld3334 = load i64, ptr %p3333, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3334, ptr %slot517, align 8
  %v3335 = load i64, ptr %slot1, align 8
  %v3336 = load i64, ptr %slot517, align 8
  %call3337 = call i64 @myl_f_5827380cbf6916206876356b2fb07f0a7833a21ff547d974596f9c567fea634d(i64 %v3335, i64 %v3336) nomerge, !dbg !128
  store i64 %call3337, ptr %slot518, align 8
  %v3338 = load i64, ptr %slot518, align 8
  %v3339 = load i64, ptr %slot41, align 8
  %p3340 = inttoptr i64 %v3339 to ptr
  store i64 %v3338, ptr %p3340, align 8, !alias.scope !3, !noalias !4
  %v3341 = load i64, ptr %slot11, align 8
  %p3342 = inttoptr i64 %v3341 to ptr
  %ld3343 = load i32, ptr %p3342, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3343, ptr %slot519, align 8
  %v3344 = load i32, ptr %slot519, align 8
  %cv3345 = zext i32 %v3344 to i64
  %cond3346 = icmp ne i64 %cv3345, 0
  br i1 %cond3346, label %bb_rcslotdrop692, label %bb_rcslotdone692
bb_rcslotdrop692:
  %v3347 = load i64, ptr %slot11, align 8
  %p3348 = inttoptr i64 %v3347 to ptr
  store i32 0, ptr %p3348, align 4, !alias.scope !3, !noalias !4
  %v3349 = load i64, ptr %slot22, align 8
  store i64 %v3349, ptr %slot520, align 8
  %v3350 = load i64, ptr %slot12, align 8
  %p3351 = inttoptr i64 %v3350 to ptr
  %ld3352 = load i32, ptr %p3351, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3352, ptr %slot521, align 8
  %v3353 = load i32, ptr %slot521, align 8
  %op3354 = and i32 %v3353, 28
  store i32 %op3354, ptr %slot522, align 8
  %v3355 = load i32, ptr %slot522, align 8
  %cv3356 = zext i32 %v3355 to i64
  %cond3357 = icmp ne i64 %cv3356, 0
  br i1 %cond3357, label %bb_rcslotrole692, label %bb_rcslotowner692
bb_rcslotrole692:
  %v3358 = load i64, ptr %slot56, align 8
  store i64 %v3358, ptr %slot523, align 8
  %v3359 = load i64, ptr %slot523, align 8
  %v3360 = load i64, ptr %slot520, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3359, i64 %v3360) nomerge, !dbg !128
  br label %bb_rcslotdone692
bb_rcslotowner692:
  %v3361 = load i64, ptr %slot56, align 8
  store i64 %v3361, ptr %slot524, align 8
  %v3362 = load i64, ptr %slot524, align 8
  %v3363 = load i64, ptr %slot520, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3362, i64 %v3363) nomerge, !dbg !128
  br label %bb_rcslotdone692
bb_rcslotdone692:
  br label %bb_i18
bb_i18:
  %v3364 = load i64, ptr %slot38, align 8
  %v3365 = load i64, ptr %slot41, align 8
  %p3366 = inttoptr i64 %v3365 to ptr
  store i64 %v3364, ptr %p3366, align 8, !alias.scope !3, !noalias !4
  %v3367 = load i64, ptr %slot41, align 8
  %p3368 = inttoptr i64 %v3367 to ptr
  %ld3369 = load i64, ptr %p3368, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3369, ptr %slot525, align 8
  %v3370 = load i64, ptr %slot1, align 8
  %v3371 = load i64, ptr %slot525, align 8
  %call3372 = call i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64 %v3370, i64 %v3371) nomerge, !dbg !130
  store i64 %call3372, ptr %slot526, align 8
  %v3373 = load i64, ptr %slot526, align 8
  %v3374 = load i64, ptr %slot41, align 8
  %p3375 = inttoptr i64 %v3374 to ptr
  store i64 %v3373, ptr %p3375, align 8, !alias.scope !3, !noalias !4
  %v3376 = load i64, ptr %slot11, align 8
  %p3377 = inttoptr i64 %v3376 to ptr
  %ld3378 = load i32, ptr %p3377, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3378, ptr %slot527, align 8
  %v3379 = load i32, ptr %slot527, align 8
  %cv3380 = zext i32 %v3379 to i64
  %cond3381 = icmp ne i64 %cv3380, 0
  br i1 %cond3381, label %bb_rcslotdrop703, label %bb_rcslotdone703
bb_rcslotdrop703:
  %v3382 = load i64, ptr %slot11, align 8
  %p3383 = inttoptr i64 %v3382 to ptr
  store i32 0, ptr %p3383, align 4, !alias.scope !3, !noalias !4
  %v3384 = load i64, ptr %slot22, align 8
  store i64 %v3384, ptr %slot528, align 8
  %v3385 = load i64, ptr %slot12, align 8
  %p3386 = inttoptr i64 %v3385 to ptr
  %ld3387 = load i32, ptr %p3386, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3387, ptr %slot529, align 8
  %v3388 = load i32, ptr %slot529, align 8
  %op3389 = and i32 %v3388, 28
  store i32 %op3389, ptr %slot530, align 8
  %v3390 = load i32, ptr %slot530, align 8
  %cv3391 = zext i32 %v3390 to i64
  %cond3392 = icmp ne i64 %cv3391, 0
  br i1 %cond3392, label %bb_rcslotrole703, label %bb_rcslotowner703
bb_rcslotrole703:
  %v3393 = load i64, ptr %slot56, align 8
  store i64 %v3393, ptr %slot531, align 8
  %v3394 = load i64, ptr %slot531, align 8
  %v3395 = load i64, ptr %slot528, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3394, i64 %v3395) nomerge, !dbg !130
  br label %bb_rcslotdone703
bb_rcslotowner703:
  %v3396 = load i64, ptr %slot56, align 8
  store i64 %v3396, ptr %slot532, align 8
  %v3397 = load i64, ptr %slot532, align 8
  %v3398 = load i64, ptr %slot528, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3397, i64 %v3398) nomerge, !dbg !130
  br label %bb_rcslotdone703
bb_rcslotdone703:
  %v3399 = load i64, ptr %slot41, align 8
  %p3400 = inttoptr i64 %v3399 to ptr
  %ld3401 = load i64, ptr %p3400, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3401, ptr %slot533, align 8
  %v3402 = load i64, ptr %slot533, align 8
  %op3403 = xor i64 %v3402, 1
  store i64 %op3403, ptr %slot534, align 8
  %v3404 = load i64, ptr %slot534, align 8
  %v3405 = load i64, ptr %slot41, align 8
  %p3406 = inttoptr i64 %v3405 to ptr
  store i64 %v3404, ptr %p3406, align 8, !alias.scope !3, !noalias !4
  %v3407 = load i64, ptr %slot41, align 8
  %p3408 = inttoptr i64 %v3407 to ptr
  %ld3409 = load i64, ptr %p3408, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3409, ptr %slot535, align 8
  %v3410 = load i64, ptr %slot535, align 8
  %cond3411 = icmp ne i64 %v3410, 0
  br i1 %cond3411, label %bb_next713, label %bb_i35
bb_next713:
  %v3412 = load i64, ptr %slot38, align 8
  %v3413 = load i64, ptr %slot41, align 8
  %p3414 = inttoptr i64 %v3413 to ptr
  store i64 %v3412, ptr %p3414, align 8, !alias.scope !3, !noalias !4
  %v3415 = load i64, ptr %slot41, align 8
  %p3416 = inttoptr i64 %v3415 to ptr
  %ld3417 = load i64, ptr %p3416, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3417, ptr %slot536, align 8
  %v3418 = load i64, ptr %slot1, align 8
  %v3419 = load i64, ptr %slot536, align 8
  %call3420 = call { i64, i64 } @myl_f_b3086250724b37e1530ea18afd53a87106fe0a2ce8bf702de675deca9c1a6925(i64 %v3418, i64 %v3419) nomerge, !dbg !132
  store { i64, i64 } %call3420, ptr %callresult538, align 8
  %addr3421 = ptrtoint ptr %callresult538 to i64
  store i64 %addr3421, ptr %slot537, align 8
  %v3422 = load i64, ptr %slot537, align 8
  %v3423 = load i64, ptr %slot41, align 8
  %p3424 = inttoptr i64 %v3423 to ptr
  store i64 %v3422, ptr %p3424, align 8, !alias.scope !3, !noalias !4
  %v3425 = load i64, ptr %slot11, align 8
  %p3426 = inttoptr i64 %v3425 to ptr
  %ld3427 = load i32, ptr %p3426, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3427, ptr %slot539, align 8
  %v3428 = load i32, ptr %slot539, align 8
  %cv3429 = zext i32 %v3428 to i64
  %cond3430 = icmp ne i64 %cv3429, 0
  br i1 %cond3430, label %bb_rcslotdrop717, label %bb_rcslotdone717
bb_rcslotdrop717:
  %v3431 = load i64, ptr %slot11, align 8
  %p3432 = inttoptr i64 %v3431 to ptr
  store i32 0, ptr %p3432, align 4, !alias.scope !3, !noalias !4
  %v3433 = load i64, ptr %slot22, align 8
  store i64 %v3433, ptr %slot540, align 8
  %v3434 = load i64, ptr %slot12, align 8
  %p3435 = inttoptr i64 %v3434 to ptr
  %ld3436 = load i32, ptr %p3435, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3436, ptr %slot541, align 8
  %v3437 = load i32, ptr %slot541, align 8
  %op3438 = and i32 %v3437, 28
  store i32 %op3438, ptr %slot542, align 8
  %v3439 = load i32, ptr %slot542, align 8
  %cv3440 = zext i32 %v3439 to i64
  %cond3441 = icmp ne i64 %cv3440, 0
  br i1 %cond3441, label %bb_rcslotrole717, label %bb_rcslotowner717
bb_rcslotrole717:
  %v3442 = load i64, ptr %slot56, align 8
  store i64 %v3442, ptr %slot543, align 8
  %v3443 = load i64, ptr %slot543, align 8
  %v3444 = load i64, ptr %slot540, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3443, i64 %v3444) nomerge, !dbg !132
  br label %bb_rcslotdone717
bb_rcslotowner717:
  %v3445 = load i64, ptr %slot56, align 8
  store i64 %v3445, ptr %slot544, align 8
  %v3446 = load i64, ptr %slot544, align 8
  %v3447 = load i64, ptr %slot540, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3446, i64 %v3447) nomerge, !dbg !132
  br label %bb_rcslotdone717
bb_rcslotdone717:
  %v3448 = load i64, ptr %slot41, align 8
  %p3449 = inttoptr i64 %v3448 to ptr
  %ld3450 = load i64, ptr %p3449, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3450, ptr %slot545, align 8
  %v3451 = load i64, ptr %slot545, align 8
  %p3452 = inttoptr i64 %v3451 to ptr
  %ld3453 = load i32, ptr %p3452, align 4
  %ext3454 = zext i32 %ld3453 to i64
  store i64 %ext3454, ptr %slot546, align 8
  %v3455 = load i64, ptr %slot546, align 8
  %cmp3456 = icmp eq i64 %v3455, 0
  %cv3457 = zext i1 %cmp3456 to i64
  store i64 %cv3457, ptr %slot547, align 8
  %v3458 = load i64, ptr %slot547, align 8
  %cond3459 = icmp ne i64 %v3458, 0
  br i1 %cond3459, label %bb_rcarm726, label %bb_rcarmnext726
bb_rcarm726:
  br label %bb_i33
bb_rcarmnext726:
  %v3460 = load i64, ptr %slot546, align 8
  %cmp3461 = icmp eq i64 %v3460, 1
  %cv3462 = zext i1 %cmp3461 to i64
  store i64 %cv3462, ptr %slot548, align 8
  %v3463 = load i64, ptr %slot548, align 8
  %cond3464 = icmp ne i64 %v3463, 0
  br i1 %cond3464, label %bb_rcarm727, label %bb_rcarmnext727
bb_rcarm727:
  %v3465 = load i64, ptr %slot29, align 8
  store i64 %v3465, ptr %slot549, align 8
  %v3466 = load i64, ptr %slot545, align 8
  %op3467 = add i64 %v3466, 8
  store i64 %op3467, ptr %slot550, align 8
  %v3468 = load i64, ptr %slot57, align 8
  store i64 %v3468, ptr %slot551, align 8
  %v3469 = load i64, ptr %slot550, align 8
  %p3470 = inttoptr i64 %v3469 to ptr
  %ld3471 = load i64, ptr %p3470, align 8
  store i64 %ld3471, ptr %slot552, align 8
  %v3472 = load i64, ptr %slot552, align 8
  %v3473 = load i64, ptr %slot549, align 8
  %p3474 = inttoptr i64 %v3473 to ptr
  store i64 %v3472, ptr %p3474, align 8, !alias.scope !3, !noalias !4
  %v3475 = load i64, ptr %slot20, align 8
  %p3476 = inttoptr i64 %v3475 to ptr
  store i32 0, ptr %p3476, align 4, !alias.scope !3, !noalias !4
  %v3477 = load i64, ptr %slot19, align 8
  %p3478 = inttoptr i64 %v3477 to ptr
  store i32 1, ptr %p3478, align 4, !alias.scope !3, !noalias !4
  %v3479 = load i64, ptr %slot549, align 8
  %p3480 = inttoptr i64 %v3479 to ptr
  %ld3481 = load i64, ptr %p3480, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3481, ptr %slot553, align 8
  %v3482 = load i64, ptr %slot553, align 8
  %v3483 = load i64, ptr %slot39, align 8
  %p3484 = inttoptr i64 %v3483 to ptr
  store i64 %v3482, ptr %p3484, align 8, !alias.scope !3, !noalias !4
  %v3485 = load i64, ptr %slot19, align 8
  %p3486 = inttoptr i64 %v3485 to ptr
  store i32 0, ptr %p3486, align 4, !alias.scope !3, !noalias !4
  br label %bb_i25
bb_rcarmnext727:
  br label %bb_failure
bb_i25:
  %v3487 = load i64, ptr %slot38, align 8
  %v3488 = load i64, ptr %slot41, align 8
  %p3489 = inttoptr i64 %v3488 to ptr
  store i64 %v3487, ptr %p3489, align 8, !alias.scope !3, !noalias !4
  %v3490 = load i64, ptr %slot41, align 8
  %p3491 = inttoptr i64 %v3490 to ptr
  %ld3492 = load i64, ptr %p3491, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3492, ptr %slot554, align 8
  %v3493 = load i64, ptr %slot554, align 8
  %op3494 = add i64 %v3493, 280
  store i64 %op3494, ptr %slot555, align 8
  %v3495 = load i64, ptr %slot555, align 8
  %v3496 = load i64, ptr %slot41, align 8
  %p3497 = inttoptr i64 %v3496 to ptr
  store i64 %v3495, ptr %p3497, align 8, !alias.scope !3, !noalias !4
  %v3498 = load i64, ptr %slot11, align 8
  %p3499 = inttoptr i64 %v3498 to ptr
  %ld3500 = load i32, ptr %p3499, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3500, ptr %slot556, align 8
  %v3501 = load i32, ptr %slot556, align 8
  %cv3502 = zext i32 %v3501 to i64
  %cond3503 = icmp ne i64 %cv3502, 0
  br i1 %cond3503, label %bb_rcslotdrop740, label %bb_rcslotdone740
bb_rcslotdrop740:
  %v3504 = load i64, ptr %slot11, align 8
  %p3505 = inttoptr i64 %v3504 to ptr
  store i32 0, ptr %p3505, align 4, !alias.scope !3, !noalias !4
  %v3506 = load i64, ptr %slot22, align 8
  store i64 %v3506, ptr %slot557, align 8
  %v3507 = load i64, ptr %slot12, align 8
  %p3508 = inttoptr i64 %v3507 to ptr
  %ld3509 = load i32, ptr %p3508, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3509, ptr %slot558, align 8
  %v3510 = load i32, ptr %slot558, align 8
  %op3511 = and i32 %v3510, 28
  store i32 %op3511, ptr %slot559, align 8
  %v3512 = load i32, ptr %slot559, align 8
  %cv3513 = zext i32 %v3512 to i64
  %cond3514 = icmp ne i64 %cv3513, 0
  br i1 %cond3514, label %bb_rcslotrole740, label %bb_rcslotowner740
bb_rcslotrole740:
  %v3515 = load i64, ptr %slot56, align 8
  store i64 %v3515, ptr %slot560, align 8
  %v3516 = load i64, ptr %slot560, align 8
  %v3517 = load i64, ptr %slot557, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v3516, i64 %v3517) nomerge, !dbg !134
  br label %bb_rcslotdone740
bb_rcslotowner740:
  %v3518 = load i64, ptr %slot56, align 8
  store i64 %v3518, ptr %slot561, align 8
  %v3519 = load i64, ptr %slot561, align 8
  %v3520 = load i64, ptr %slot557, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v3519, i64 %v3520) nomerge, !dbg !134
  br label %bb_rcslotdone740
bb_rcslotdone740:
  %v3521 = load i64, ptr %slot41, align 8
  %p3522 = inttoptr i64 %v3521 to ptr
  %ld3523 = load i64, ptr %p3522, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3523, ptr %slot562, align 8
  %v3524 = load i64, ptr %slot562, align 8
  %op3525 = add i64 %v3524, 24
  store i64 %op3525, ptr %slot563, align 8
  %v3526 = load i64, ptr %slot563, align 8
  %p3527 = inttoptr i64 %v3526 to ptr
  %ld3528 = load i64, ptr %p3527, align 8
  store i64 %ld3528, ptr %slot564, align 8
  %v3529 = load i64, ptr %slot564, align 8
  %v3530 = load i64, ptr %slot41, align 8
  %p3531 = inttoptr i64 %v3530 to ptr
  store i64 %v3529, ptr %p3531, align 8, !alias.scope !3, !noalias !4
  %v3532 = load i64, ptr %slot41, align 8
  %p3533 = inttoptr i64 %v3532 to ptr
  %ld3534 = load i64, ptr %p3533, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3534, ptr %slot565, align 8
  %v3535 = load i64, ptr %slot565, align 8
  %v3536 = load i64, ptr %slot26, align 8
  %p3537 = inttoptr i64 %v3536 to ptr
  store i64 %v3535, ptr %p3537, align 8, !alias.scope !3, !noalias !4
  %v3538 = load i64, ptr %slot26, align 8
  store i64 %v3538, ptr %slot566, align 8
  %v3539 = load i64, ptr %slot29, align 8
  store i64 %v3539, ptr %slot567, align 8
  %v3540 = load i64, ptr %slot566, align 8
  %p3541 = inttoptr i64 %v3540 to ptr
  %ld3542 = load i64, ptr %p3541, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3542, ptr %slot568, align 8
  %v3543 = load i64, ptr %slot568, align 8
  %cmp3544 = icmp ne i64 %v3543, 0
  %cv3545 = zext i1 %cmp3544 to i32
  store i32 %cv3545, ptr %slot569, align 8
  %v3546 = load i32, ptr %slot569, align 8
  %cv3547 = zext i32 %v3546 to i64
  %cond3548 = icmp ne i64 %cv3547, 0
  br i1 %cond3548, label %bb_rcgnn754, label %bb_rcgstore754
bb_rcgnn754:
  %v3549 = load i64, ptr %slot568, align 8
  %op3550 = sub i64 %v3549, 16
  store i64 %op3550, ptr %slot570, align 8
  %v3551 = load i64, ptr %slot568, align 8
  %p3552 = inttoptr i64 %v3551 to ptr
  %rgep3553 = getelementptr i8, ptr %p3552, i64 -16
  %ld3554 = load i64, ptr %rgep3553, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3554, ptr %slot571, align 8
  %v3555 = load i64, ptr %slot571, align 8
  %op3556 = and i64 %v3555, 4611686018427387906
  store i64 %op3556, ptr %slot572, align 8
  %v3557 = load i64, ptr %slot572, align 8
  %cmp3558 = icmp ne i64 %v3557, 0
  %cv3559 = zext i1 %cmp3558 to i32
  store i32 %cv3559, ptr %slot573, align 8
  %v3560 = load i32, ptr %slot573, align 8
  %cv3561 = zext i32 %v3560 to i64
  %cond3562 = icmp ne i64 %cv3561, 0
  br i1 %cond3562, label %bb_rcgstore754, label %bb_rcginc754
bb_rcginc754:
  %v3563 = load i64, ptr %slot568, align 8
  %op3564 = sub i64 %v3563, 24
  store i64 %op3564, ptr %slot574, align 8
  %v3565 = load i64, ptr %slot568, align 8
  %p3566 = inttoptr i64 %v3565 to ptr
  %rgep3567 = getelementptr i8, ptr %p3566, i64 -24
  %ld3568 = load i64, ptr %rgep3567, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3568, ptr %slot575, align 8
  %v3569 = load i64, ptr %slot575, align 8
  %op3570 = add i64 %v3569, 1
  store i64 %op3570, ptr %slot576, align 8
  %v3571 = load i64, ptr %slot576, align 8
  %cmp3572 = icmp eq i64 %v3571, 0
  %cv3573 = zext i1 %cmp3572 to i32
  store i32 %cv3573, ptr %slot577, align 8
  %v3574 = load i32, ptr %slot577, align 8
  %cv3575 = zext i32 %v3574 to i64
  %cond3576 = icmp ne i64 %cv3575, 0
  br i1 %cond3576, label %bb_rcglimit754, label %bb_rcgcapacity754
bb_rcglimit754:
  %v3577 = load i64, ptr %slot1, align 8
  %p3578 = inttoptr i64 %v3577 to ptr
  %call3579 = call i32 @myl_qbe_rc_status(ptr %p3578, i32 2) nomerge, !dbg !136
  store i32 %call3579, ptr %slot578, align 8
  br label %bb_failure
bb_rcgcapacity754:
  %v3580 = load i64, ptr %slot576, align 8
  %v3581 = load i64, ptr %slot568, align 8
  %p3582 = inttoptr i64 %v3581 to ptr
  %rgep3583 = getelementptr i8, ptr %p3582, i64 -24
  store i64 %v3580, ptr %rgep3583, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgstore754
bb_rcgstore754:
  %v3584 = load i64, ptr %slot568, align 8
  %v3585 = load i64, ptr %slot567, align 8
  %p3586 = inttoptr i64 %v3585 to ptr
  store i64 %v3584, ptr %p3586, align 8, !alias.scope !3, !noalias !4
  %v3587 = load i64, ptr %slot20, align 8
  %p3588 = inttoptr i64 %v3587 to ptr
  store i32 2, ptr %p3588, align 4, !alias.scope !3, !noalias !4
  %v3589 = load i64, ptr %slot20, align 8
  %p3590 = inttoptr i64 %v3589 to ptr
  store i32 16, ptr %p3590, align 4, !alias.scope !3, !noalias !4
  %v3591 = load i64, ptr %slot19, align 8
  %p3592 = inttoptr i64 %v3591 to ptr
  store i32 1, ptr %p3592, align 4, !alias.scope !3, !noalias !4
  %v3593 = load i64, ptr %slot11, align 8
  %p3594 = inttoptr i64 %v3593 to ptr
  %ld3595 = load i32, ptr %p3594, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3595, ptr %slot579, align 8
  %v3596 = load i32, ptr %slot579, align 8
  %cv3597 = zext i32 %v3596 to i64
  %cond3598 = icmp ne i64 %cv3597, 0
  br i1 %cond3598, label %bb_rcslotdrop770, label %bb_rcslotdone770
bb_rcslotdrop770:
  %v3599 = load i64, ptr %slot11, align 8
  %p3600 = inttoptr i64 %v3599 to ptr
  store i32 0, ptr %p3600, align 4, !alias.scope !3, !noalias !4
  %v3601 = load i64, ptr %slot22, align 8
  store i64 %v3601, ptr %slot580, align 8
  %v3602 = load i64, ptr %slot12, align 8
  %p3603 = inttoptr i64 %v3602 to ptr
  %ld3604 = load i32, ptr %p3603, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3604, ptr %slot581, align 8
  %v3605 = load i32, ptr %slot581, align 8
  %op3606 = and i32 %v3605, 28
  store i32 %op3606, ptr %slot582, align 8
  %v3607 = load i32, ptr %slot582, align 8
  %cv3608 = zext i32 %v3607 to i64
  %cond3609 = icmp ne i64 %cv3608, 0
  br i1 %cond3609, label %bb_rcslotrole770, label %bb_rcslotowner770
bb_rcslotrole770:
  %v3610 = load i64, ptr %slot56, align 8
  store i64 %v3610, ptr %slot583, align 8
  %v3611 = load i64, ptr %slot583, align 8
  %v3612 = load i64, ptr %slot580, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v3611, i64 %v3612) nomerge, !dbg !136
  br label %bb_rcslotdone770
bb_rcslotowner770:
  %v3613 = load i64, ptr %slot56, align 8
  store i64 %v3613, ptr %slot584, align 8
  %v3614 = load i64, ptr %slot584, align 8
  %v3615 = load i64, ptr %slot580, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v3614, i64 %v3615) nomerge, !dbg !136
  br label %bb_rcslotdone770
bb_rcslotdone770:
  %v3616 = load i64, ptr %slot22, align 8
  store i64 %v3616, ptr %slot585, align 8
  %v3617 = load i64, ptr %slot29, align 8
  store i64 %v3617, ptr %slot586, align 8
  %v3618 = load i64, ptr %slot586, align 8
  %v3619 = load i64, ptr %slot585, align 8
  %p3620 = inttoptr i64 %v3618 to ptr
  %p3621 = inttoptr i64 %v3619 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p3621, ptr %p3620, i64 8, i1 false), !alias.scope !3, !noalias !4
  %v3622 = load i64, ptr %slot12, align 8
  %p3623 = inttoptr i64 %v3622 to ptr
  store i32 2, ptr %p3623, align 4, !alias.scope !3, !noalias !4
  %v3624 = load i64, ptr %slot20, align 8
  %p3625 = inttoptr i64 %v3624 to ptr
  %ld3626 = load i32, ptr %p3625, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3626, ptr %slot587, align 8
  %v3627 = load i32, ptr %slot587, align 8
  %v3628 = load i64, ptr %slot12, align 8
  %p3629 = inttoptr i64 %v3628 to ptr
  store i32 %v3627, ptr %p3629, align 4, !alias.scope !3, !noalias !4
  %v3630 = load i64, ptr %slot19, align 8
  %p3631 = inttoptr i64 %v3630 to ptr
  store i32 0, ptr %p3631, align 4, !alias.scope !3, !noalias !4
  %v3632 = load i64, ptr %slot11, align 8
  %p3633 = inttoptr i64 %v3632 to ptr
  store i32 1, ptr %p3633, align 4, !alias.scope !3, !noalias !4
  %v3634 = load i64, ptr %slot585, align 8
  %p3635 = inttoptr i64 %v3634 to ptr
  %ld3636 = load i64, ptr %p3635, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3636, ptr %slot588, align 8
  %v3637 = load i64, ptr %slot588, align 8
  %v3638 = load i64, ptr %slot41, align 8
  %p3639 = inttoptr i64 %v3638 to ptr
  store i64 %v3637, ptr %p3639, align 8, !alias.scope !3, !noalias !4
  %v3640 = load i64, ptr %slot41, align 8
  %p3641 = inttoptr i64 %v3640 to ptr
  %ld3642 = load i64, ptr %p3641, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3642, ptr %slot589, align 8
  %v3643 = load i64, ptr %slot38, align 8
  store i64 %v3643, ptr %slot590, align 8
  %v3644 = load i64, ptr %slot11, align 8
  %p3645 = inttoptr i64 %v3644 to ptr
  %ld3646 = load i32, ptr %p3645, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3646, ptr %slot591, align 8
  %v3647 = load i32, ptr %slot591, align 8
  %cv3648 = zext i32 %v3647 to i64
  %cond3649 = icmp ne i64 %cv3648, 0
  br i1 %cond3649, label %bb_rcslotdrop791, label %bb_rcslotdone791
bb_rcslotdrop791:
  %v3650 = load i64, ptr %slot11, align 8
  %p3651 = inttoptr i64 %v3650 to ptr
  store i32 0, ptr %p3651, align 4, !alias.scope !3, !noalias !4
  %v3652 = load i64, ptr %slot22, align 8
  store i64 %v3652, ptr %slot592, align 8
  %v3653 = load i64, ptr %slot12, align 8
  %p3654 = inttoptr i64 %v3653 to ptr
  %ld3655 = load i32, ptr %p3654, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3655, ptr %slot593, align 8
  %v3656 = load i32, ptr %slot593, align 8
  %op3657 = and i32 %v3656, 28
  store i32 %op3657, ptr %slot594, align 8
  %v3658 = load i32, ptr %slot594, align 8
  %cv3659 = zext i32 %v3658 to i64
  %cond3660 = icmp ne i64 %cv3659, 0
  br i1 %cond3660, label %bb_rcslotrole791, label %bb_rcslotowner791
bb_rcslotrole791:
  %v3661 = load i64, ptr %slot56, align 8
  store i64 %v3661, ptr %slot595, align 8
  %v3662 = load i64, ptr %slot592, align 8
  %p3663 = inttoptr i64 %v3662 to ptr
  %ld3664 = load i64, ptr %p3663, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3664, ptr %slot596, align 8
  %v3665 = load i64, ptr %slot596, align 8
  %cmp3666 = icmp ne i64 %v3665, 0
  %cv3667 = zext i1 %cmp3666 to i32
  store i32 %cv3667, ptr %slot597, align 8
  %v3668 = load i32, ptr %slot597, align 8
  %cv3669 = zext i32 %v3668 to i64
  %cond3670 = icmp ne i64 %cv3669, 0
  br i1 %cond3670, label %bb_rcgnn807, label %bb_rcgdone807
bb_rcgnn807:
  %v3671 = load i64, ptr %slot596, align 8
  %op3672 = sub i64 %v3671, 16
  store i64 %op3672, ptr %slot598, align 8
  %v3673 = load i64, ptr %slot596, align 8
  %p3674 = inttoptr i64 %v3673 to ptr
  %rgep3675 = getelementptr i8, ptr %p3674, i64 -16
  %ld3676 = load i64, ptr %rgep3675, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3676, ptr %slot599, align 8
  %v3677 = load i64, ptr %slot599, align 8
  %op3678 = and i64 %v3677, 4611686018427387906
  store i64 %op3678, ptr %slot600, align 8
  %v3679 = load i64, ptr %slot600, align 8
  %cmp3680 = icmp ne i64 %v3679, 0
  %cv3681 = zext i1 %cmp3680 to i32
  store i32 %cv3681, ptr %slot601, align 8
  %v3682 = load i32, ptr %slot601, align 8
  %cv3683 = zext i32 %v3682 to i64
  %cond3684 = icmp ne i64 %cv3683, 0
  br i1 %cond3684, label %bb_rcgclear807, label %bb_rcgcounted807
bb_rcgcounted807:
  %v3685 = load i64, ptr %slot596, align 8
  %op3686 = sub i64 %v3685, 24
  store i64 %op3686, ptr %slot602, align 8
  %v3687 = load i64, ptr %slot596, align 8
  %p3688 = inttoptr i64 %v3687 to ptr
  %rgep3689 = getelementptr i8, ptr %p3688, i64 -24
  %ld3690 = load i64, ptr %rgep3689, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3690, ptr %slot603, align 8
  %v3691 = load i64, ptr %slot603, align 8
  %op3692 = sub i64 %v3691, 1
  store i64 %op3692, ptr %slot604, align 8
  %v3693 = load i64, ptr %slot604, align 8
  %cmp3694 = icmp eq i64 %v3693, 0
  %cv3695 = zext i1 %cmp3694 to i32
  store i32 %cv3695, ptr %slot605, align 8
  %v3696 = load i32, ptr %slot605, align 8
  %cv3697 = zext i32 %v3696 to i64
  %cond3698 = icmp ne i64 %cv3697, 0
  br i1 %cond3698, label %bb_rcglast807, label %bb_rcgdec807
bb_rcglast807:
  %v3699 = load i64, ptr %slot596, align 8
  %op3700 = sub i64 %v3699, 32
  store i64 %op3700, ptr %slot606, align 8
  %v3701 = load i64, ptr %slot596, align 8
  %p3702 = inttoptr i64 %v3701 to ptr
  %rgep3703 = getelementptr i8, ptr %p3702, i64 -32
  %ld3704 = load i64, ptr %rgep3703, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3704, ptr %slot607, align 8
  %v3705 = load i64, ptr %slot607, align 8
  %cmp3706 = icmp ne i64 %v3705, 0
  %cv3707 = zext i1 %cmp3706 to i32
  store i32 %cv3707, ptr %slot608, align 8
  %v3708 = load i32, ptr %slot608, align 8
  %cv3709 = zext i32 %v3708 to i64
  %cond3710 = icmp ne i64 %cv3709, 0
  br i1 %cond3710, label %bb_rcgdec807, label %bb_rcgslow807
bb_rcgslow807:
  %v3711 = load i64, ptr %slot595, align 8
  %v3712 = load i64, ptr %slot592, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3711, i64 %v3712) nomerge, !dbg !138
  br label %bb_rcgdone807
bb_rcgdec807:
  %v3713 = load i64, ptr %slot604, align 8
  %v3714 = load i64, ptr %slot596, align 8
  %p3715 = inttoptr i64 %v3714 to ptr
  %rgep3716 = getelementptr i8, ptr %p3715, i64 -24
  store i64 %v3713, ptr %rgep3716, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear807
bb_rcgclear807:
  %v3717 = load i64, ptr %slot592, align 8
  %p3718 = inttoptr i64 %v3717 to ptr
  store i64 0, ptr %p3718, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone807
bb_rcgdone807:
  br label %bb_rcslotdone791
bb_rcslotowner791:
  %v3719 = load i64, ptr %slot56, align 8
  store i64 %v3719, ptr %slot609, align 8
  %v3720 = load i64, ptr %slot592, align 8
  %p3721 = inttoptr i64 %v3720 to ptr
  %ld3722 = load i64, ptr %p3721, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3722, ptr %slot610, align 8
  %v3723 = load i64, ptr %slot610, align 8
  %cmp3724 = icmp ne i64 %v3723, 0
  %cv3725 = zext i1 %cmp3724 to i32
  store i32 %cv3725, ptr %slot611, align 8
  %v3726 = load i32, ptr %slot611, align 8
  %cv3727 = zext i32 %v3726 to i64
  %cond3728 = icmp ne i64 %cv3727, 0
  br i1 %cond3728, label %bb_rcgnn822, label %bb_rcgdone822
bb_rcgnn822:
  %v3729 = load i64, ptr %slot610, align 8
  %op3730 = sub i64 %v3729, 16
  store i64 %op3730, ptr %slot612, align 8
  %v3731 = load i64, ptr %slot610, align 8
  %p3732 = inttoptr i64 %v3731 to ptr
  %rgep3733 = getelementptr i8, ptr %p3732, i64 -16
  %ld3734 = load i64, ptr %rgep3733, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3734, ptr %slot613, align 8
  %v3735 = load i64, ptr %slot613, align 8
  %op3736 = and i64 %v3735, 4611686018427387906
  store i64 %op3736, ptr %slot614, align 8
  %v3737 = load i64, ptr %slot614, align 8
  %cmp3738 = icmp ne i64 %v3737, 0
  %cv3739 = zext i1 %cmp3738 to i32
  store i32 %cv3739, ptr %slot615, align 8
  %v3740 = load i32, ptr %slot615, align 8
  %cv3741 = zext i32 %v3740 to i64
  %cond3742 = icmp ne i64 %cv3741, 0
  br i1 %cond3742, label %bb_rcgclear822, label %bb_rcgcounted822
bb_rcgcounted822:
  %v3743 = load i64, ptr %slot610, align 8
  %op3744 = sub i64 %v3743, 32
  store i64 %op3744, ptr %slot616, align 8
  %v3745 = load i64, ptr %slot610, align 8
  %p3746 = inttoptr i64 %v3745 to ptr
  %rgep3747 = getelementptr i8, ptr %p3746, i64 -32
  %ld3748 = load i64, ptr %rgep3747, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3748, ptr %slot617, align 8
  %v3749 = load i64, ptr %slot617, align 8
  %op3750 = sub i64 %v3749, 1
  store i64 %op3750, ptr %slot618, align 8
  %v3751 = load i64, ptr %slot618, align 8
  %cmp3752 = icmp eq i64 %v3751, 0
  %cv3753 = zext i1 %cmp3752 to i32
  store i32 %cv3753, ptr %slot619, align 8
  %v3754 = load i32, ptr %slot619, align 8
  %cv3755 = zext i32 %v3754 to i64
  %cond3756 = icmp ne i64 %cv3755, 0
  br i1 %cond3756, label %bb_rcglast822, label %bb_rcgdec822
bb_rcglast822:
  %v3757 = load i64, ptr %slot610, align 8
  %op3758 = sub i64 %v3757, 24
  store i64 %op3758, ptr %slot620, align 8
  %v3759 = load i64, ptr %slot610, align 8
  %p3760 = inttoptr i64 %v3759 to ptr
  %rgep3761 = getelementptr i8, ptr %p3760, i64 -24
  %ld3762 = load i64, ptr %rgep3761, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3762, ptr %slot621, align 8
  %v3763 = load i64, ptr %slot621, align 8
  %cmp3764 = icmp ne i64 %v3763, 0
  %cv3765 = zext i1 %cmp3764 to i32
  store i32 %cv3765, ptr %slot622, align 8
  %v3766 = load i32, ptr %slot622, align 8
  %cv3767 = zext i32 %v3766 to i64
  %cond3768 = icmp ne i64 %cv3767, 0
  br i1 %cond3768, label %bb_rcgdec822, label %bb_rcgslow822
bb_rcgslow822:
  %v3769 = load i64, ptr %slot609, align 8
  %v3770 = load i64, ptr %slot592, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3769, i64 %v3770) nomerge, !dbg !138
  br label %bb_rcgdone822
bb_rcgdec822:
  %v3771 = load i64, ptr %slot618, align 8
  %v3772 = load i64, ptr %slot610, align 8
  %p3773 = inttoptr i64 %v3772 to ptr
  %rgep3774 = getelementptr i8, ptr %p3773, i64 -32
  store i64 %v3771, ptr %rgep3774, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear822
bb_rcgclear822:
  %v3775 = load i64, ptr %slot592, align 8
  %p3776 = inttoptr i64 %v3775 to ptr
  store i64 0, ptr %p3776, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone822
bb_rcgdone822:
  br label %bb_rcslotdone791
bb_rcslotdone791:
  %v3777 = load i64, ptr %slot590, align 8
  %p3779 = inttoptr i64 %v3777 to ptr
  %gep3780 = getelementptr i8, ptr %p3779, i64 280
  %op3778 = ptrtoint ptr %gep3780 to i64
  store i64 %op3778, ptr %slot623, align 8
  %v3781 = load i64, ptr %slot623, align 8
  %p3783 = inttoptr i64 %v3781 to ptr
  %gep3784 = getelementptr i8, ptr %p3783, i64 24
  %op3782 = ptrtoint ptr %gep3784 to i64
  store i64 %op3782, ptr %slot624, align 8
  store i64 0, ptr %slot625, align 8
  %v3785 = load i64, ptr %slot624, align 8
  %p3786 = inttoptr i64 %v3785 to ptr
  %ld3787 = load i64, ptr %p3786, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3787, ptr %slot626, align 8
  %v3788 = load i64, ptr %slot626, align 8
  %cmp3789 = icmp ne i64 %v3788, 0
  %cv3790 = zext i1 %cmp3789 to i32
  store i32 %cv3790, ptr %slot627, align 8
  %v3791 = load i32, ptr %slot627, align 8
  %cv3792 = zext i32 %v3791 to i64
  %cond3793 = icmp ne i64 %cv3792, 0
  br i1 %cond3793, label %bb_rcguniquenn829, label %bb_rcgunique829
bb_rcguniquenn829:
  %v3794 = load i64, ptr %slot626, align 8
  %op3795 = sub i64 %v3794, 16
  store i64 %op3795, ptr %slot628, align 8
  %v3796 = load i64, ptr %slot626, align 8
  %p3797 = inttoptr i64 %v3796 to ptr
  %rgep3798 = getelementptr i8, ptr %p3797, i64 -16
  %ld3799 = load i64, ptr %rgep3798, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3799, ptr %slot629, align 8
  %v3800 = load i64, ptr %slot629, align 8
  %op3801 = and i64 %v3800, 6917529027641081858
  store i64 %op3801, ptr %slot630, align 8
  %v3802 = load i64, ptr %slot630, align 8
  %cmp3803 = icmp ne i64 %v3802, 0
  %cv3804 = zext i1 %cmp3803 to i32
  store i32 %cv3804, ptr %slot631, align 8
  %v3805 = load i32, ptr %slot631, align 8
  %cv3806 = zext i32 %v3805 to i64
  %cond3807 = icmp ne i64 %cv3806, 0
  br i1 %cond3807, label %bb_rcguniqueslow829, label %bb_rcguniquecount829
bb_rcguniquecount829:
  %v3808 = load i64, ptr %slot626, align 8
  %op3809 = sub i64 %v3808, 32
  store i64 %op3809, ptr %slot632, align 8
  %v3810 = load i64, ptr %slot626, align 8
  %p3811 = inttoptr i64 %v3810 to ptr
  %rgep3812 = getelementptr i8, ptr %p3811, i64 -32
  %ld3813 = load i64, ptr %rgep3812, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3813, ptr %slot633, align 8
  %v3814 = load i64, ptr %slot633, align 8
  %cmp3815 = icmp ult i64 %v3814, 2
  %cv3816 = zext i1 %cmp3815 to i32
  store i32 %cv3816, ptr %slot634, align 8
  %v3817 = load i32, ptr %slot634, align 8
  %cv3818 = zext i32 %v3817 to i64
  %cond3819 = icmp ne i64 %cv3818, 0
  br i1 %cond3819, label %bb_rcgunique829, label %bb_rcguniqueslow829
bb_rcguniqueslow829:
  %v3820 = load i64, ptr %slot1, align 8
  %p3821 = inttoptr i64 %v3820 to ptr
  %p3822 = inttoptr i64 ptrtoint (ptr @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 to i64) to ptr
  %v3823 = load i64, ptr %slot624, align 8
  %p3824 = inttoptr i64 %v3823 to ptr
  %v3825 = load i64, ptr %slot625, align 8
  %p3826 = inttoptr i64 %v3825 to ptr
  %call3827 = call i32 @myl_qbe_rc_unique_field(ptr %p3821, ptr %p3822, ptr %p3824, ptr %p3826) nomerge, !dbg !138
  store i32 %call3827, ptr %slot635, align 8
  %v3828 = load i32, ptr %slot635, align 8
  %cv3829 = zext i32 %v3828 to i64
  %cond3830 = icmp ne i64 %cv3829, 0
  br i1 %cond3830, label %bb_rcunique839, label %bb_failure
bb_rcunique839:
  br label %bb_rcgunique829
bb_rcgunique829:
  %v3831 = load i64, ptr %slot624, align 8
  %p3832 = inttoptr i64 %v3831 to ptr
  %ld3833 = load i64, ptr %p3832, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3833, ptr %slot636, align 8
  %v3834 = load i64, ptr %slot636, align 8
  %v3835 = load i64, ptr %slot41, align 8
  %p3836 = inttoptr i64 %v3835 to ptr
  store i64 %v3834, ptr %p3836, align 8, !alias.scope !3, !noalias !4
  %v3837 = load i64, ptr %slot41, align 8
  %p3838 = inttoptr i64 %v3837 to ptr
  %ld3839 = load i64, ptr %p3838, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3839, ptr %slot637, align 8
  %v3840 = load i64, ptr %slot11, align 8
  %p3841 = inttoptr i64 %v3840 to ptr
  %ld3842 = load i32, ptr %p3841, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3842, ptr %slot638, align 8
  %v3843 = load i32, ptr %slot638, align 8
  %cv3844 = zext i32 %v3843 to i64
  %cond3845 = icmp ne i64 %cv3844, 0
  br i1 %cond3845, label %bb_rcslotdrop844, label %bb_rcslotdone844
bb_rcslotdrop844:
  %v3846 = load i64, ptr %slot11, align 8
  %p3847 = inttoptr i64 %v3846 to ptr
  store i32 0, ptr %p3847, align 4, !alias.scope !3, !noalias !4
  %v3848 = load i64, ptr %slot22, align 8
  store i64 %v3848, ptr %slot639, align 8
  %v3849 = load i64, ptr %slot12, align 8
  %p3850 = inttoptr i64 %v3849 to ptr
  %ld3851 = load i32, ptr %p3850, align 4, !alias.scope !3, !noalias !4
  store i32 %ld3851, ptr %slot640, align 8
  %v3852 = load i32, ptr %slot640, align 8
  %op3853 = and i32 %v3852, 28
  store i32 %op3853, ptr %slot641, align 8
  %v3854 = load i32, ptr %slot641, align 8
  %cv3855 = zext i32 %v3854 to i64
  %cond3856 = icmp ne i64 %cv3855, 0
  br i1 %cond3856, label %bb_rcslotrole844, label %bb_rcslotowner844
bb_rcslotrole844:
  %v3857 = load i64, ptr %slot56, align 8
  store i64 %v3857, ptr %slot642, align 8
  %v3858 = load i64, ptr %slot639, align 8
  %p3859 = inttoptr i64 %v3858 to ptr
  %ld3860 = load i64, ptr %p3859, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3860, ptr %slot643, align 8
  %v3861 = load i64, ptr %slot643, align 8
  %cmp3862 = icmp ne i64 %v3861, 0
  %cv3863 = zext i1 %cmp3862 to i32
  store i32 %cv3863, ptr %slot644, align 8
  %v3864 = load i32, ptr %slot644, align 8
  %cv3865 = zext i32 %v3864 to i64
  %cond3866 = icmp ne i64 %cv3865, 0
  br i1 %cond3866, label %bb_rcgnn860, label %bb_rcgdone860
bb_rcgnn860:
  %v3867 = load i64, ptr %slot643, align 8
  %op3868 = sub i64 %v3867, 16
  store i64 %op3868, ptr %slot645, align 8
  %v3869 = load i64, ptr %slot643, align 8
  %p3870 = inttoptr i64 %v3869 to ptr
  %rgep3871 = getelementptr i8, ptr %p3870, i64 -16
  %ld3872 = load i64, ptr %rgep3871, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3872, ptr %slot646, align 8
  %v3873 = load i64, ptr %slot646, align 8
  %op3874 = and i64 %v3873, 4611686018427387906
  store i64 %op3874, ptr %slot647, align 8
  %v3875 = load i64, ptr %slot647, align 8
  %cmp3876 = icmp ne i64 %v3875, 0
  %cv3877 = zext i1 %cmp3876 to i32
  store i32 %cv3877, ptr %slot648, align 8
  %v3878 = load i32, ptr %slot648, align 8
  %cv3879 = zext i32 %v3878 to i64
  %cond3880 = icmp ne i64 %cv3879, 0
  br i1 %cond3880, label %bb_rcgclear860, label %bb_rcgcounted860
bb_rcgcounted860:
  %v3881 = load i64, ptr %slot643, align 8
  %op3882 = sub i64 %v3881, 24
  store i64 %op3882, ptr %slot649, align 8
  %v3883 = load i64, ptr %slot643, align 8
  %p3884 = inttoptr i64 %v3883 to ptr
  %rgep3885 = getelementptr i8, ptr %p3884, i64 -24
  %ld3886 = load i64, ptr %rgep3885, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3886, ptr %slot650, align 8
  %v3887 = load i64, ptr %slot650, align 8
  %op3888 = sub i64 %v3887, 1
  store i64 %op3888, ptr %slot651, align 8
  %v3889 = load i64, ptr %slot651, align 8
  %cmp3890 = icmp eq i64 %v3889, 0
  %cv3891 = zext i1 %cmp3890 to i32
  store i32 %cv3891, ptr %slot652, align 8
  %v3892 = load i32, ptr %slot652, align 8
  %cv3893 = zext i32 %v3892 to i64
  %cond3894 = icmp ne i64 %cv3893, 0
  br i1 %cond3894, label %bb_rcglast860, label %bb_rcgdec860
bb_rcglast860:
  %v3895 = load i64, ptr %slot643, align 8
  %op3896 = sub i64 %v3895, 32
  store i64 %op3896, ptr %slot653, align 8
  %v3897 = load i64, ptr %slot643, align 8
  %p3898 = inttoptr i64 %v3897 to ptr
  %rgep3899 = getelementptr i8, ptr %p3898, i64 -32
  %ld3900 = load i64, ptr %rgep3899, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3900, ptr %slot654, align 8
  %v3901 = load i64, ptr %slot654, align 8
  %cmp3902 = icmp ne i64 %v3901, 0
  %cv3903 = zext i1 %cmp3902 to i32
  store i32 %cv3903, ptr %slot655, align 8
  %v3904 = load i32, ptr %slot655, align 8
  %cv3905 = zext i32 %v3904 to i64
  %cond3906 = icmp ne i64 %cv3905, 0
  br i1 %cond3906, label %bb_rcgdec860, label %bb_rcgslow860
bb_rcgslow860:
  %v3907 = load i64, ptr %slot642, align 8
  %v3908 = load i64, ptr %slot639, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64 %v3907, i64 %v3908) nomerge, !dbg !138
  br label %bb_rcgdone860
bb_rcgdec860:
  %v3909 = load i64, ptr %slot651, align 8
  %v3910 = load i64, ptr %slot643, align 8
  %p3911 = inttoptr i64 %v3910 to ptr
  %rgep3912 = getelementptr i8, ptr %p3911, i64 -24
  store i64 %v3909, ptr %rgep3912, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear860
bb_rcgclear860:
  %v3913 = load i64, ptr %slot639, align 8
  %p3914 = inttoptr i64 %v3913 to ptr
  store i64 0, ptr %p3914, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone860
bb_rcgdone860:
  br label %bb_rcslotdone844
bb_rcslotowner844:
  %v3915 = load i64, ptr %slot56, align 8
  store i64 %v3915, ptr %slot656, align 8
  %v3916 = load i64, ptr %slot639, align 8
  %p3917 = inttoptr i64 %v3916 to ptr
  %ld3918 = load i64, ptr %p3917, align 8, !alias.scope !3, !noalias !4
  store i64 %ld3918, ptr %slot657, align 8
  %v3919 = load i64, ptr %slot657, align 8
  %cmp3920 = icmp ne i64 %v3919, 0
  %cv3921 = zext i1 %cmp3920 to i32
  store i32 %cv3921, ptr %slot658, align 8
  %v3922 = load i32, ptr %slot658, align 8
  %cv3923 = zext i32 %v3922 to i64
  %cond3924 = icmp ne i64 %cv3923, 0
  br i1 %cond3924, label %bb_rcgnn875, label %bb_rcgdone875
bb_rcgnn875:
  %v3925 = load i64, ptr %slot657, align 8
  %op3926 = sub i64 %v3925, 16
  store i64 %op3926, ptr %slot659, align 8
  %v3927 = load i64, ptr %slot657, align 8
  %p3928 = inttoptr i64 %v3927 to ptr
  %rgep3929 = getelementptr i8, ptr %p3928, i64 -16
  %ld3930 = load i64, ptr %rgep3929, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3930, ptr %slot660, align 8
  %v3931 = load i64, ptr %slot660, align 8
  %op3932 = and i64 %v3931, 4611686018427387906
  store i64 %op3932, ptr %slot661, align 8
  %v3933 = load i64, ptr %slot661, align 8
  %cmp3934 = icmp ne i64 %v3933, 0
  %cv3935 = zext i1 %cmp3934 to i32
  store i32 %cv3935, ptr %slot662, align 8
  %v3936 = load i32, ptr %slot662, align 8
  %cv3937 = zext i32 %v3936 to i64
  %cond3938 = icmp ne i64 %cv3937, 0
  br i1 %cond3938, label %bb_rcgclear875, label %bb_rcgcounted875
bb_rcgcounted875:
  %v3939 = load i64, ptr %slot657, align 8
  %op3940 = sub i64 %v3939, 32
  store i64 %op3940, ptr %slot663, align 8
  %v3941 = load i64, ptr %slot657, align 8
  %p3942 = inttoptr i64 %v3941 to ptr
  %rgep3943 = getelementptr i8, ptr %p3942, i64 -32
  %ld3944 = load i64, ptr %rgep3943, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3944, ptr %slot664, align 8
  %v3945 = load i64, ptr %slot664, align 8
  %op3946 = sub i64 %v3945, 1
  store i64 %op3946, ptr %slot665, align 8
  %v3947 = load i64, ptr %slot665, align 8
  %cmp3948 = icmp eq i64 %v3947, 0
  %cv3949 = zext i1 %cmp3948 to i32
  store i32 %cv3949, ptr %slot666, align 8
  %v3950 = load i32, ptr %slot666, align 8
  %cv3951 = zext i32 %v3950 to i64
  %cond3952 = icmp ne i64 %cv3951, 0
  br i1 %cond3952, label %bb_rcglast875, label %bb_rcgdec875
bb_rcglast875:
  %v3953 = load i64, ptr %slot657, align 8
  %op3954 = sub i64 %v3953, 24
  store i64 %op3954, ptr %slot667, align 8
  %v3955 = load i64, ptr %slot657, align 8
  %p3956 = inttoptr i64 %v3955 to ptr
  %rgep3957 = getelementptr i8, ptr %p3956, i64 -24
  %ld3958 = load i64, ptr %rgep3957, align 8, !alias.scope !9, !noalias !10
  store i64 %ld3958, ptr %slot668, align 8
  %v3959 = load i64, ptr %slot668, align 8
  %cmp3960 = icmp ne i64 %v3959, 0
  %cv3961 = zext i1 %cmp3960 to i32
  store i32 %cv3961, ptr %slot669, align 8
  %v3962 = load i32, ptr %slot669, align 8
  %cv3963 = zext i32 %v3962 to i64
  %cond3964 = icmp ne i64 %cv3963, 0
  br i1 %cond3964, label %bb_rcgdec875, label %bb_rcgslow875
bb_rcgslow875:
  %v3965 = load i64, ptr %slot656, align 8
  %v3966 = load i64, ptr %slot639, align 8
  call void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64 %v3965, i64 %v3966) nomerge, !dbg !138
  br label %bb_rcgdone875
bb_rcgdec875:
  %v3967 = load i64, ptr %slot665, align 8
  %v3968 = load i64, ptr %slot657, align 8
  %p3969 = inttoptr i64 %v3968 to ptr
  %rgep3970 = getelementptr i8, ptr %p3969, i64 -32
  store i64 %v3967, ptr %rgep3970, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear875
bb_rcgclear875:
  %v3971 = load i64, ptr %slot639, align 8
  %p3972 = inttoptr i64 %v3971 to ptr
  store i64 0, ptr %p3972, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone875
bb_rcgdone875:
  br label %bb_rcslotdone844
bb_rcslotdone844:
  %v3973 = load i64, ptr %slot31, align 8
  store i64 %v3973, ptr %slot670, align 8
  %v3974 = load i64, ptr %slot56, align 8
  %v3975 = load i64, ptr %slot670, align 8
  %p3976 = inttoptr i64 %v3975 to ptr
  store i64 %v3974, ptr %p3976, align 8, !alias.scope !3, !noalias !4
  %v3977 = load i64, ptr %slot56, align 8
  %p3979 = inttoptr i64 %v3977 to ptr
  %gep3980 = getelementptr i8, ptr %p3979, i64 5640
  %op3978 = ptrtoint ptr %gep3980 to i64
  store i64 %op3978, ptr %slot671, align 8
  %v3981 = load i64, ptr %slot671, align 8
  %p3982 = inttoptr i64 %v3981 to ptr
  %ld3983 = load i64, ptr %p3982, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3983, ptr %slot672, align 8
  %v3984 = load i64, ptr %slot672, align 8
  %op3985 = add i64 %v3984, 248
  store i64 %op3985, ptr %slot673, align 8
  %v3986 = load i64, ptr %slot673, align 8
  %p3987 = inttoptr i64 %v3986 to ptr
  %ld3988 = load i64, ptr %p3987, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld3988, ptr %slot674, align 8
  %v3989 = load i64, ptr %slot670, align 8
  %p3991 = inttoptr i64 %v3989 to ptr
  %gep3992 = getelementptr i8, ptr %p3991, i64 8
  %op3990 = ptrtoint ptr %gep3992 to i64
  store i64 %op3990, ptr %slot675, align 8
  %v3993 = load i64, ptr %slot674, align 8
  %v3994 = load i64, ptr %slot675, align 8
  %p3995 = inttoptr i64 %v3994 to ptr
  store i64 %v3993, ptr %p3995, align 8, !alias.scope !3, !noalias !4
  %v3996 = load i64, ptr %slot670, align 8
  %p3998 = inttoptr i64 %v3996 to ptr
  %gep3999 = getelementptr i8, ptr %p3998, i64 16
  %op3997 = ptrtoint ptr %gep3999 to i64
  store i64 %op3997, ptr %slot676, align 8
  %v4000 = load i64, ptr %slot676, align 8
  %p4001 = inttoptr i64 %v4000 to ptr
  store i64 0, ptr %p4001, align 8, !alias.scope !3, !noalias !4
  %v4002 = load i64, ptr %slot56, align 8
  %p4004 = inttoptr i64 %v4002 to ptr
  %gep4005 = getelementptr i8, ptr %p4004, i64 112
  %op4003 = ptrtoint ptr %gep4005 to i64
  store i64 %op4003, ptr %slot677, align 8
  %v4006 = load i64, ptr %slot670, align 8
  %p4008 = inttoptr i64 %v4006 to ptr
  %gep4009 = getelementptr i8, ptr %p4008, i64 24
  %op4007 = ptrtoint ptr %gep4009 to i64
  store i64 %op4007, ptr %slot678, align 8
  %v4010 = load i64, ptr %slot670, align 8
  %p4012 = inttoptr i64 %v4010 to ptr
  %gep4013 = getelementptr i8, ptr %p4012, i64 28
  %op4011 = ptrtoint ptr %gep4013 to i64
  store i64 %op4011, ptr %slot679, align 8
  %v4014 = load i64, ptr %slot677, align 8
  %p4015 = inttoptr i64 %v4014 to ptr
  %ld4016 = load i32, ptr %p4015, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld4016, ptr %slot680, align 8
  %v4017 = load i64, ptr %slot678, align 8
  %p4018 = inttoptr i64 %v4017 to ptr
  store i32 1, ptr %p4018, align 4, !alias.scope !3, !noalias !4
  %v4019 = load i32, ptr %slot680, align 8
  %v4020 = load i64, ptr %slot679, align 8
  %p4021 = inttoptr i64 %v4020 to ptr
  store i32 %v4019, ptr %p4021, align 4, !alias.scope !3, !noalias !4
  %v4022 = load i64, ptr %slot670, align 8
  %v4023 = load i64, ptr %slot673, align 8
  %p4024 = inttoptr i64 %v4023 to ptr
  store i64 %v4022, ptr %p4024, align 8, !alias.scope !9999998, !noalias !9999999
  %v4025 = load i64, ptr %slot637, align 8
  %cmp4026 = icmp ne i64 %v4025, 0
  %cv4027 = zext i1 %cmp4026 to i32
  store i32 %cv4027, ptr %slot681, align 8
  %v4028 = load i32, ptr %slot681, align 8
  %cv4029 = zext i32 %v4028 to i64
  %cond4030 = icmp ne i64 %cv4029, 0
  br i1 %cond4030, label %bb_rcspinmark927, label %bb_rcspindone927
bb_rcspinmark927:
  %v4031 = load i64, ptr %slot637, align 8
  %op4032 = sub i64 %v4031, 16
  store i64 %op4032, ptr %slot682, align 8
  %v4033 = load i64, ptr %slot637, align 8
  %p4034 = inttoptr i64 %v4033 to ptr
  %rgep4035 = getelementptr i8, ptr %p4034, i64 -16
  %ld4036 = load i64, ptr %rgep4035, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4036, ptr %slot683, align 8
  %v4037 = load i64, ptr %slot683, align 8
  %op4038 = and i64 %v4037, 2
  store i64 %op4038, ptr %slot684, align 8
  %v4039 = load i64, ptr %slot684, align 8
  %cmp4040 = icmp ne i64 %v4039, 0
  %cv4041 = zext i1 %cmp4040 to i32
  store i32 %cv4041, ptr %slot685, align 8
  %v4042 = load i32, ptr %slot685, align 8
  %cv4043 = zext i32 %v4042 to i64
  %cond4044 = icmp ne i64 %cv4043, 0
  br i1 %cond4044, label %bb_rcspindone927, label %bb_rcspintype927
bb_rcspintype927:
  %v4045 = load i64, ptr %slot683, align 8
  %op4046 = and i64 %v4045, 4611686018427387907
  store i64 %op4046, ptr %slot686, align 8
  %v4047 = load i64, ptr %slot686, align 8
  %cmp4048 = icmp eq i64 %v4047, 0
  %cv4049 = zext i1 %cmp4048 to i32
  store i32 %cv4049, ptr %slot687, align 8
  %v4050 = load i32, ptr %slot687, align 8
  %cv4051 = zext i32 %v4050 to i64
  %cond4052 = icmp ne i64 %cv4051, 0
  br i1 %cond4052, label %bb_rcs935, label %bb_rcspinslow927
bb_rcs935:
  %v4053 = load i64, ptr %slot637, align 8
  %op4054 = sub i64 %v4053, 8
  store i64 %op4054, ptr %slot688, align 8
  %v4055 = load i64, ptr %slot637, align 8
  %p4056 = inttoptr i64 %v4055 to ptr
  %rgep4057 = getelementptr i8, ptr %p4056, i64 -8
  %ld4058 = load i64, ptr %rgep4057, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4058, ptr %slot689, align 8
  %p4059 = inttoptr i64 ptrtoint (ptr @myl_native_list_header_type to i64) to ptr
  %ld4060 = load i64, ptr %p4059, align 8, !alias.scope !4, !noalias !3
  store i64 %ld4060, ptr %slot690, align 8
  %v4061 = load i64, ptr %slot689, align 8
  %v4062 = load i64, ptr %slot690, align 8
  %cmp4063 = icmp eq i64 %v4061, %v4062
  %cv4064 = zext i1 %cmp4063 to i32
  store i32 %cv4064, ptr %slot691, align 8
  %v4065 = load i32, ptr %slot691, align 8
  %cv4066 = zext i32 %v4065 to i64
  %cond4067 = icmp ne i64 %cv4066, 0
  br i1 %cond4067, label %bb_rcs940, label %bb_rcspinslow927
bb_rcs940:
  %v4068 = load i64, ptr %slot56, align 8
  %p4070 = inttoptr i64 %v4068 to ptr
  %gep4071 = getelementptr i8, ptr %p4070, i64 5640
  %op4069 = ptrtoint ptr %gep4071 to i64
  store i64 %op4069, ptr %slot692, align 8
  %v4072 = load i64, ptr %slot692, align 8
  %p4073 = inttoptr i64 %v4072 to ptr
  %ld4074 = load i64, ptr %p4073, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4074, ptr %slot693, align 8
  %v4075 = load i64, ptr %slot693, align 8
  %op4076 = add i64 %v4075, 256
  store i64 %op4076, ptr %slot694, align 8
  %v4077 = load i64, ptr %slot694, align 8
  %p4078 = inttoptr i64 %v4077 to ptr
  %ld4079 = load i64, ptr %p4078, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4079, ptr %slot695, align 8
  %v4080 = load i64, ptr %slot695, align 8
  %cmp4081 = icmp ne i64 %v4080, 0
  %cv4082 = zext i1 %cmp4081 to i32
  store i32 %cv4082, ptr %slot696, align 8
  %v4083 = load i32, ptr %slot696, align 8
  %cv4084 = zext i32 %v4083 to i64
  %cond4085 = icmp ne i64 %cv4084, 0
  br i1 %cond4085, label %bb_rcs946, label %bb_rcspinslow927
bb_rcs946:
  %v4086 = load i64, ptr %slot56, align 8
  %p4088 = inttoptr i64 %v4086 to ptr
  %gep4089 = getelementptr i8, ptr %p4088, i64 24
  %op4087 = ptrtoint ptr %gep4089 to i64
  store i64 %op4087, ptr %slot697, align 8
  %v4090 = load i64, ptr %slot697, align 8
  %p4091 = inttoptr i64 %v4090 to ptr
  %ld4092 = load i64, ptr %p4091, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4092, ptr %slot698, align 8
  %v4093 = load i64, ptr %slot698, align 8
  %op4094 = add i64 %v4093, 40
  store i64 %op4094, ptr %slot699, align 8
  %v4095 = load i64, ptr %slot699, align 8
  %v4096 = load i64, ptr %slot698, align 8
  %cmp4097 = icmp uge i64 %v4095, %v4096
  %cv4098 = zext i1 %cmp4097 to i32
  store i32 %cv4098, ptr %slot700, align 8
  %v4099 = load i32, ptr %slot700, align 8
  %cv4100 = zext i32 %v4099 to i64
  %cond4101 = icmp ne i64 %cv4100, 0
  br i1 %cond4101, label %bb_rcs951, label %bb_rcspinslow927
bb_rcs951:
  %v4102 = load i64, ptr %slot56, align 8
  %p4104 = inttoptr i64 %v4102 to ptr
  %gep4105 = getelementptr i8, ptr %p4104, i64 88
  %op4103 = ptrtoint ptr %gep4105 to i64
  store i64 %op4103, ptr %slot701, align 8
  %v4106 = load i64, ptr %slot701, align 8
  %p4107 = inttoptr i64 %v4106 to ptr
  %ld4108 = load i64, ptr %p4107, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4108, ptr %slot702, align 8
  %v4109 = load i64, ptr %slot702, align 8
  %cmp4110 = icmp eq i64 %v4109, 0
  %cv4111 = zext i1 %cmp4110 to i32
  store i32 %cv4111, ptr %slot703, align 8
  %v4112 = load i64, ptr %slot699, align 8
  %v4113 = load i64, ptr %slot702, align 8
  %cmp4114 = icmp ule i64 %v4112, %v4113
  %cv4115 = zext i1 %cmp4114 to i32
  store i32 %cv4115, ptr %slot704, align 8
  %v4116 = load i32, ptr %slot703, align 8
  %v4117 = load i32, ptr %slot704, align 8
  %op4118 = or i32 %v4116, %v4117
  store i32 %op4118, ptr %slot705, align 8
  %v4119 = load i32, ptr %slot705, align 8
  %cv4120 = zext i32 %v4119 to i64
  %cond4121 = icmp ne i64 %cv4120, 0
  br i1 %cond4121, label %bb_rcs957, label %bb_rcspinslow927
bb_rcs957:
  %v4122 = load i64, ptr %slot637, align 8
  %op4123 = sub i64 %v4122, 24
  store i64 %op4123, ptr %slot706, align 8
  %v4124 = load i64, ptr %slot637, align 8
  %p4125 = inttoptr i64 %v4124 to ptr
  %rgep4126 = getelementptr i8, ptr %p4125, i64 -24
  %ld4127 = load i64, ptr %rgep4126, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4127, ptr %slot707, align 8
  %v4128 = load i64, ptr %slot707, align 8
  %cmp4129 = icmp ne i64 %v4128, 18446744073709551615
  %cv4130 = zext i1 %cmp4129 to i32
  store i32 %cv4130, ptr %slot708, align 8
  %v4131 = load i32, ptr %slot708, align 8
  %cv4132 = zext i32 %v4131 to i64
  %cond4133 = icmp ne i64 %cv4132, 0
  br i1 %cond4133, label %bb_rcs961, label %bb_rcspinslow927
bb_rcs961:
  %v4134 = load i64, ptr %slot637, align 8
  %op4135 = add i64 %v4134, 32
  store i64 %op4135, ptr %slot709, align 8
  %v4136 = load i64, ptr %slot709, align 8
  %p4137 = inttoptr i64 %v4136 to ptr
  %ld4138 = load i64, ptr %p4137, align 8
  store i64 %ld4138, ptr %slot710, align 8
  %v4139 = load i64, ptr %slot710, align 8
  %cmp4140 = icmp ne i64 %v4139, 0
  %cv4141 = zext i1 %cmp4140 to i32
  store i32 %cv4141, ptr %slot711, align 8
  %v4142 = load i32, ptr %slot711, align 8
  %cv4143 = zext i32 %v4142 to i64
  %cond4144 = icmp ne i64 %cv4143, 0
  br i1 %cond4144, label %bb_rcspinbacking927, label %bb_rcspincommit927
bb_rcspinbacking927:
  %v4145 = load i64, ptr %slot710, align 8
  %op4146 = sub i64 %v4145, 16
  store i64 %op4146, ptr %slot712, align 8
  %v4147 = load i64, ptr %slot710, align 8
  %p4148 = inttoptr i64 %v4147 to ptr
  %rgep4149 = getelementptr i8, ptr %p4148, i64 -16
  %ld4150 = load i64, ptr %rgep4149, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4150, ptr %slot713, align 8
  %v4151 = load i64, ptr %slot713, align 8
  %op4152 = and i64 %v4151, 4611686018427387907
  store i64 %op4152, ptr %slot714, align 8
  %v4153 = load i64, ptr %slot714, align 8
  %cmp4154 = icmp eq i64 %v4153, 0
  %cv4155 = zext i1 %cmp4154 to i32
  store i32 %cv4155, ptr %slot715, align 8
  %v4156 = load i32, ptr %slot715, align 8
  %cv4157 = zext i32 %v4156 to i64
  %cond4158 = icmp ne i64 %cv4157, 0
  br i1 %cond4158, label %bb_rcs969, label %bb_rcspinslow927
bb_rcs969:
  %v4159 = load i64, ptr %slot710, align 8
  %op4160 = sub i64 %v4159, 24
  store i64 %op4160, ptr %slot716, align 8
  %v4161 = load i64, ptr %slot710, align 8
  %p4162 = inttoptr i64 %v4161 to ptr
  %rgep4163 = getelementptr i8, ptr %p4162, i64 -24
  %ld4164 = load i64, ptr %rgep4163, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4164, ptr %slot717, align 8
  %v4165 = load i64, ptr %slot717, align 8
  %cmp4166 = icmp ne i64 %v4165, 18446744073709551615
  %cv4167 = zext i1 %cmp4166 to i32
  store i32 %cv4167, ptr %slot718, align 8
  %v4168 = load i32, ptr %slot718, align 8
  %cv4169 = zext i32 %v4168 to i64
  %cond4170 = icmp ne i64 %cv4169, 0
  br i1 %cond4170, label %bb_rcs973, label %bb_rcspinslow927
bb_rcs973:
  br label %bb_rcspincommit927
bb_rcspincommit927:
  %v4171 = load i64, ptr %slot695, align 8
  %p4172 = inttoptr i64 %v4171 to ptr
  %ld4173 = load i64, ptr %p4172, align 8
  store i64 %ld4173, ptr %slot719, align 8
  %v4174 = load i64, ptr %slot693, align 8
  %op4175 = add i64 %v4174, 256
  store i64 %op4175, ptr %slot720, align 8
  %v4176 = load i64, ptr %slot719, align 8
  %v4177 = load i64, ptr %slot720, align 8
  %p4178 = inttoptr i64 %v4177 to ptr
  store i64 %v4176, ptr %p4178, align 8, !alias.scope !9999998, !noalias !9999999
  %v4179 = load i64, ptr %slot693, align 8
  %op4180 = add i64 %v4179, 264
  store i64 %op4180, ptr %slot721, align 8
  %v4181 = load i64, ptr %slot721, align 8
  %p4182 = inttoptr i64 %v4181 to ptr
  %ld4183 = load i64, ptr %p4182, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4183, ptr %slot722, align 8
  %v4184 = load i64, ptr %slot722, align 8
  %op4185 = add i64 %v4184, 18446744073709551615
  store i64 %op4185, ptr %slot723, align 8
  %v4186 = load i64, ptr %slot723, align 8
  %v4187 = load i64, ptr %slot721, align 8
  %p4188 = inttoptr i64 %v4187 to ptr
  store i64 %v4186, ptr %p4188, align 8, !alias.scope !9999998, !noalias !9999999
  %v4189 = load i64, ptr %slot56, align 8
  %p4191 = inttoptr i64 %v4189 to ptr
  %gep4192 = getelementptr i8, ptr %p4191, i64 24
  %op4190 = ptrtoint ptr %gep4192 to i64
  store i64 %op4190, ptr %slot724, align 8
  %v4193 = load i64, ptr %slot724, align 8
  %p4194 = inttoptr i64 %v4193 to ptr
  %ld4195 = load i64, ptr %p4194, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4195, ptr %slot725, align 8
  %v4196 = load i64, ptr %slot725, align 8
  %op4197 = add i64 %v4196, 40
  store i64 %op4197, ptr %slot726, align 8
  %v4198 = load i64, ptr %slot726, align 8
  %v4199 = load i64, ptr %slot724, align 8
  %p4200 = inttoptr i64 %v4199 to ptr
  store i64 %v4198, ptr %p4200, align 8, !alias.scope !9999998, !noalias !9999999
  %v4201 = load i64, ptr %slot693, align 8
  %op4202 = add i64 %v4201, 48
  store i64 %op4202, ptr %slot727, align 8
  %v4203 = load i64, ptr %slot727, align 8
  %p4204 = inttoptr i64 %v4203 to ptr
  %ld4205 = load i64, ptr %p4204, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4205, ptr %slot728, align 8
  %v4206 = load i64, ptr %slot728, align 8
  %op4207 = add i64 %v4206, 40
  store i64 %op4207, ptr %slot729, align 8
  %v4208 = load i64, ptr %slot729, align 8
  %v4209 = load i64, ptr %slot727, align 8
  %p4210 = inttoptr i64 %v4209 to ptr
  store i64 %v4208, ptr %p4210, align 8, !alias.scope !9999998, !noalias !9999999
  %v4211 = load i64, ptr %slot637, align 8
  %op4212 = sub i64 %v4211, 24
  store i64 %op4212, ptr %slot730, align 8
  %v4213 = load i64, ptr %slot637, align 8
  %p4214 = inttoptr i64 %v4213 to ptr
  %rgep4215 = getelementptr i8, ptr %p4214, i64 -24
  %ld4216 = load i64, ptr %rgep4215, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4216, ptr %slot731, align 8
  %v4217 = load i64, ptr %slot731, align 8
  %op4218 = add i64 %v4217, 1
  store i64 %op4218, ptr %slot732, align 8
  %v4219 = load i64, ptr %slot732, align 8
  %v4220 = load i64, ptr %slot637, align 8
  %p4221 = inttoptr i64 %v4220 to ptr
  %rgep4222 = getelementptr i8, ptr %p4221, i64 -24
  store i64 %v4219, ptr %rgep4222, align 8, !alias.scope !9, !noalias !10
  %v4223 = load i64, ptr %slot710, align 8
  %cmp4224 = icmp ne i64 %v4223, 0
  %cv4225 = zext i1 %cmp4224 to i32
  store i32 %cv4225, ptr %slot733, align 8
  %v4226 = load i32, ptr %slot733, align 8
  %cv4227 = zext i32 %v4226 to i64
  %cond4228 = icmp ne i64 %cv4227, 0
  br i1 %cond4228, label %bb_rcspinhold927, label %bb_rcspinjournal927
bb_rcspinhold927:
  %v4229 = load i64, ptr %slot710, align 8
  %op4230 = sub i64 %v4229, 24
  store i64 %op4230, ptr %slot734, align 8
  %v4231 = load i64, ptr %slot710, align 8
  %p4232 = inttoptr i64 %v4231 to ptr
  %rgep4233 = getelementptr i8, ptr %p4232, i64 -24
  %ld4234 = load i64, ptr %rgep4233, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4234, ptr %slot735, align 8
  %v4235 = load i64, ptr %slot735, align 8
  %op4236 = add i64 %v4235, 1
  store i64 %op4236, ptr %slot736, align 8
  %v4237 = load i64, ptr %slot736, align 8
  %v4238 = load i64, ptr %slot710, align 8
  %p4239 = inttoptr i64 %v4238 to ptr
  %rgep4240 = getelementptr i8, ptr %p4239, i64 -24
  store i64 %v4237, ptr %rgep4240, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcspinjournal927
bb_rcspinjournal927:
  %v4241 = load i64, ptr %slot683, align 8
  %op4242 = and i64 %v4241, 1152921504606846976
  store i64 %op4242, ptr %slot737, align 8
  %v4243 = load i64, ptr %slot683, align 8
  %op4244 = or i64 %v4243, 1152921504606846976
  store i64 %op4244, ptr %slot738, align 8
  %v4245 = load i64, ptr %slot637, align 8
  %op4246 = sub i64 %v4245, 16
  store i64 %op4246, ptr %slot739, align 8
  %v4247 = load i64, ptr %slot738, align 8
  %v4248 = load i64, ptr %slot637, align 8
  %p4249 = inttoptr i64 %v4248 to ptr
  %rgep4250 = getelementptr i8, ptr %p4249, i64 -16
  store i64 %v4247, ptr %rgep4250, align 8, !alias.scope !9, !noalias !10
  %v4251 = load i64, ptr %slot670, align 8
  %p4253 = inttoptr i64 %v4251 to ptr
  %gep4254 = getelementptr i8, ptr %p4253, i64 16
  %op4252 = ptrtoint ptr %gep4254 to i64
  store i64 %op4252, ptr %slot740, align 8
  %v4255 = load i64, ptr %slot740, align 8
  %p4256 = inttoptr i64 %v4255 to ptr
  %ld4257 = load i64, ptr %p4256, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4257, ptr %slot741, align 8
  %v4258 = load i64, ptr %slot695, align 8
  %op4259 = add i64 %v4258, 0
  store i64 %op4259, ptr %slot742, align 8
  %v4260 = load i64, ptr %slot741, align 8
  %v4261 = load i64, ptr %slot742, align 8
  %p4262 = inttoptr i64 %v4261 to ptr
  store i64 %v4260, ptr %p4262, align 8, !alias.scope !9999998, !noalias !9999999
  %v4263 = load i64, ptr %slot695, align 8
  %op4264 = add i64 %v4263, 8
  store i64 %op4264, ptr %slot743, align 8
  %v4265 = load i64, ptr %slot637, align 8
  %v4266 = load i64, ptr %slot743, align 8
  %p4267 = inttoptr i64 %v4266 to ptr
  store i64 %v4265, ptr %p4267, align 8, !alias.scope !9999998, !noalias !9999999
  %v4268 = load i64, ptr %slot695, align 8
  %op4269 = add i64 %v4268, 16
  store i64 %op4269, ptr %slot744, align 8
  %v4270 = load i64, ptr %slot737, align 8
  %v4271 = load i64, ptr %slot744, align 8
  %p4272 = inttoptr i64 %v4271 to ptr
  store i64 %v4270, ptr %p4272, align 8, !alias.scope !9999998, !noalias !9999999
  %v4273 = load i64, ptr %slot695, align 8
  %op4274 = add i64 %v4273, 24
  store i64 %op4274, ptr %slot745, align 8
  %v4275 = load i64, ptr %slot745, align 8
  %p4276 = inttoptr i64 %v4275 to ptr
  store i32 1, ptr %p4276, align 4, !alias.scope !9999998, !noalias !9999999
  %v4277 = load i64, ptr %slot695, align 8
  %op4278 = add i64 %v4277, 32
  store i64 %op4278, ptr %slot746, align 8
  %v4279 = load i64, ptr %slot710, align 8
  %v4280 = load i64, ptr %slot746, align 8
  %p4281 = inttoptr i64 %v4280 to ptr
  store i64 %v4279, ptr %p4281, align 8, !alias.scope !9999998, !noalias !9999999
  %v4282 = load i64, ptr %slot670, align 8
  %p4284 = inttoptr i64 %v4282 to ptr
  %gep4285 = getelementptr i8, ptr %p4284, i64 16
  %op4283 = ptrtoint ptr %gep4285 to i64
  store i64 %op4283, ptr %slot747, align 8
  %v4286 = load i64, ptr %slot695, align 8
  %v4287 = load i64, ptr %slot747, align 8
  %p4288 = inttoptr i64 %v4287 to ptr
  store i64 %v4286, ptr %p4288, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcspindone927
bb_rcspinslow927:
  %v4289 = load i64, ptr %slot1, align 8
  %p4290 = inttoptr i64 %v4289 to ptr
  %v4291 = load i64, ptr %slot670, align 8
  %p4292 = inttoptr i64 %v4291 to ptr
  %v4293 = load i64, ptr %slot637, align 8
  %p4294 = inttoptr i64 %v4293 to ptr
  %call4295 = call i32 @myl_qbe_rc_scope_pin(ptr %p4290, ptr %p4292, ptr %p4294) nomerge, !dbg !138
  store i32 %call4295, ptr %slot748, align 8
  %v4296 = load i32, ptr %slot748, align 8
  %cv4297 = zext i32 %v4296 to i64
  %cond4298 = icmp ne i64 %cv4297, 0
  br i1 %cond4298, label %bb_rcunique1004, label %bb_failure
bb_rcunique1004:
  br label %bb_rcspindone927
bb_rcspindone927:
  %v4299 = load i64, ptr %slot637, align 8
  %v4300 = load i64, ptr %slot40, align 8
  %p4301 = inttoptr i64 %v4300 to ptr
  store i64 %v4299, ptr %p4301, align 8, !alias.scope !3, !noalias !4
  %v4302 = load i64, ptr %slot39, align 8
  %p4303 = inttoptr i64 %v4302 to ptr
  %ld4304 = load i64, ptr %p4303, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4304, ptr %slot749, align 8
  %v4305 = load i64, ptr %slot749, align 8
  %v4306 = load i64, ptr %slot41, align 8
  %p4307 = inttoptr i64 %v4306 to ptr
  store i64 %v4305, ptr %p4307, align 8, !alias.scope !3, !noalias !4
  %v4308 = load i64, ptr %slot40, align 8
  %p4309 = inttoptr i64 %v4308 to ptr
  %ld4310 = load i64, ptr %p4309, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4310, ptr %slot750, align 8
  %v4311 = load i64, ptr %slot41, align 8
  store i64 %v4311, ptr %slot751, align 8
  %v4312 = load i64, ptr %slot751, align 8
  %p4313 = inttoptr i64 %v4312 to ptr
  %ld4314 = load i64, ptr %p4313, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4314, ptr %slot752, align 8
  %v4315 = load i64, ptr %slot750, align 8
  %op4316 = add i64 %v4315, 0
  store i64 %op4316, ptr %slot753, align 8
  %v4317 = load i64, ptr %slot753, align 8
  %p4318 = inttoptr i64 %v4317 to ptr
  %ld4319 = load i64, ptr %p4318, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4319, ptr %slot754, align 8
  %v4320 = load i64, ptr %slot750, align 8
  %op4321 = add i64 %v4320, 8
  store i64 %op4321, ptr %slot755, align 8
  %v4322 = load i64, ptr %slot755, align 8
  %p4323 = inttoptr i64 %v4322 to ptr
  %ld4324 = load i64, ptr %p4323, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4324, ptr %slot756, align 8
  %v4325 = load i64, ptr %slot750, align 8
  %op4326 = add i64 %v4325, 16
  store i64 %op4326, ptr %slot757, align 8
  %v4327 = load i64, ptr %slot757, align 8
  %p4328 = inttoptr i64 %v4327 to ptr
  %ld4329 = load i64, ptr %p4328, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4329, ptr %slot758, align 8
  %v4330 = load i64, ptr %slot754, align 8
  %v4331 = load i64, ptr %slot756, align 8
  %cmp4332 = icmp ult i64 %v4330, %v4331
  %cv4333 = zext i1 %cmp4332 to i32
  store i32 %cv4333, ptr %slot759, align 8
  %v4334 = load i64, ptr %slot758, align 8
  %cmp4335 = icmp ne i64 %v4334, 18446744073709551615
  %cv4336 = zext i1 %cmp4335 to i32
  store i32 %cv4336, ptr %slot760, align 8
  %v4337 = load i32, ptr %slot759, align 8
  %v4338 = load i32, ptr %slot760, align 8
  %op4339 = and i32 %v4337, %v4338
  store i32 %op4339, ptr %slot761, align 8
  %v4340 = load i32, ptr %slot761, align 8
  %cv4341 = zext i32 %v4340 to i64
  %cond4342 = icmp ne i64 %cv4341, 0
  br i1 %cond4342, label %bb_rcappend_check1010, label %bb_rcappend_slow1010
bb_rcappend_check1010:
  %v4343 = load i64, ptr %slot56, align 8
  %p4344 = inttoptr i64 %v4343 to ptr
  %v4345 = load i64, ptr %slot750, align 8
  %p4346 = inttoptr i64 %v4345 to ptr
  %call4347 = call i32 @myl_rc_list_plain_ready(ptr %p4344, ptr %p4346) nomerge, !dbg !140
  store i32 %call4347, ptr %slot762, align 8
  %v4348 = load i32, ptr %slot762, align 8
  %cv4349 = zext i32 %v4348 to i64
  %cond4350 = icmp ne i64 %cv4349, 0
  br i1 %cond4350, label %bb_rcappend_fast1010, label %bb_rcappend_slow1010
bb_rcappend_slow1010:
  %v4351 = load i64, ptr %slot751, align 8
  %p4352 = inttoptr i64 %v4351 to ptr
  %ld4353 = load i64, ptr %p4352, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4353, ptr %slot763, align 8
  %v4354 = load i64, ptr %slot763, align 8
  %v4355 = load i64, ptr %slot30, align 8
  %p4356 = inttoptr i64 %v4355 to ptr
  store i64 %v4354, ptr %p4356, align 8, !alias.scope !3, !noalias !4
  %v4357 = load i64, ptr %slot30, align 8
  store i64 %v4357, ptr %slot764, align 8
  %v4358 = load i64, ptr %slot56, align 8
  %p4359 = inttoptr i64 %v4358 to ptr
  %v4360 = load i64, ptr %slot750, align 8
  %p4361 = inttoptr i64 %v4360 to ptr
  %v4362 = load i64, ptr %slot764, align 8
  %p4363 = inttoptr i64 %v4362 to ptr
  %call4364 = call i32 @myl_rc_list_append(ptr %p4359, ptr %p4361, ptr %p4363) nomerge, !dbg !140
  store i32 %call4364, ptr %slot765, align 8
  %v4365 = load i32, ptr %slot765, align 8
  %cv4366 = zext i32 %v4365 to i64
  %cond4367 = icmp ne i64 %cv4366, 0
  br i1 %cond4367, label %bb_success1023, label %bb_failed1023
bb_failed1023:
  %v4368 = load i64, ptr %slot1, align 8
  %p4369 = inttoptr i64 %v4368 to ptr
  call void @myl_qbe_fail_allocation(ptr %p4369) nomerge, !dbg !140
  unreachable
bb_success1023:
  br label %bb_rcappend_done1010
bb_rcappend_fast1010:
  %v4370 = load i64, ptr %slot750, align 8
  %op4371 = add i64 %v4370, 32
  store i64 %op4371, ptr %slot766, align 8
  %v4372 = load i64, ptr %slot766, align 8
  %p4373 = inttoptr i64 %v4372 to ptr
  %ld4374 = load i64, ptr %p4373, align 8, !alias.scope !6, !noalias !7
  store i64 %ld4374, ptr %slot767, align 8
  %v4375 = load i64, ptr %slot754, align 8
  %op4376 = mul i64 %v4375, 8
  store i64 %op4376, ptr %slot768, align 8
  %v4377 = load i64, ptr %slot767, align 8
  %v4378 = load i64, ptr %slot768, align 8
  %op4379 = add i64 %v4377, %v4378
  store i64 %op4379, ptr %slot769, align 8
  %v4380 = load i64, ptr %slot752, align 8
  %v4381 = load i64, ptr %slot767, align 8
  %p4382 = inttoptr i64 %v4381 to ptr
  %v4383 = load i64, ptr %slot768, align 8
  %egep4384 = getelementptr i8, ptr %p4382, i64 %v4383
  store i64 %v4380, ptr %egep4384, align 8, !alias.scope !12, !noalias !13
  %v4385 = load i64, ptr %slot750, align 8
  %op4386 = add i64 %v4385, 0
  store i64 %op4386, ptr %slot770, align 8
  %v4387 = load i64, ptr %slot754, align 8
  %op4388 = add i64 %v4387, 1
  store i64 %op4388, ptr %slot771, align 8
  %v4389 = load i64, ptr %slot771, align 8
  %v4390 = load i64, ptr %slot770, align 8
  %p4391 = inttoptr i64 %v4390 to ptr
  store i64 %v4389, ptr %p4391, align 8, !alias.scope !6, !noalias !7
  %v4392 = load i64, ptr %slot750, align 8
  %op4393 = add i64 %v4392, 16
  store i64 %op4393, ptr %slot772, align 8
  %v4394 = load i64, ptr %slot758, align 8
  %op4395 = add i64 %v4394, 1
  store i64 %op4395, ptr %slot773, align 8
  %v4396 = load i64, ptr %slot773, align 8
  %v4397 = load i64, ptr %slot772, align 8
  %p4398 = inttoptr i64 %v4397 to ptr
  store i64 %v4396, ptr %p4398, align 8, !alias.scope !6, !noalias !7
  br label %bb_rcappend_done1010
bb_rcappend_done1010:
  %v4399 = load i64, ptr %slot41, align 8
  %p4400 = inttoptr i64 %v4399 to ptr
  store i64 0, ptr %p4400, align 8, !alias.scope !3, !noalias !4
  %v4401 = load i64, ptr %slot31, align 8
  store i64 %v4401, ptr %slot774, align 8
  %v4402 = load i64, ptr %slot774, align 8
  %p4404 = inttoptr i64 %v4402 to ptr
  %gep4405 = getelementptr i8, ptr %p4404, i64 24
  %op4403 = ptrtoint ptr %gep4405 to i64
  store i64 %op4403, ptr %slot775, align 8
  %v4406 = load i64, ptr %slot775, align 8
  %p4407 = inttoptr i64 %v4406 to ptr
  %ld4408 = load i32, ptr %p4407, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4408, ptr %slot776, align 8
  %v4409 = load i32, ptr %slot776, align 8
  %cv4410 = zext i32 %v4409 to i64
  %cond4411 = icmp ne i64 %cv4410, 0
  br i1 %cond4411, label %bb_rcsendactive1033, label %bb_rcsenddone1033
bb_rcsendactive1033:
  %v4412 = load i64, ptr %slot56, align 8
  %p4414 = inttoptr i64 %v4412 to ptr
  %gep4415 = getelementptr i8, ptr %p4414, i64 5640
  %op4413 = ptrtoint ptr %gep4415 to i64
  store i64 %op4413, ptr %slot777, align 8
  %v4416 = load i64, ptr %slot777, align 8
  %p4417 = inttoptr i64 %v4416 to ptr
  %ld4418 = load i64, ptr %p4417, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4418, ptr %slot778, align 8
  %v4419 = load i64, ptr %slot778, align 8
  %op4420 = add i64 %v4419, 248
  store i64 %op4420, ptr %slot779, align 8
  %v4421 = load i64, ptr %slot779, align 8
  %p4422 = inttoptr i64 %v4421 to ptr
  %ld4423 = load i64, ptr %p4422, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4423, ptr %slot780, align 8
  %v4424 = load i64, ptr %slot780, align 8
  %v4425 = load i64, ptr %slot774, align 8
  %cmp4426 = icmp eq i64 %v4424, %v4425
  %cv4427 = zext i1 %cmp4426 to i32
  store i32 %cv4427, ptr %slot781, align 8
  %v4428 = load i32, ptr %slot781, align 8
  %cv4429 = zext i32 %v4428 to i64
  %cond4430 = icmp ne i64 %cv4429, 0
  br i1 %cond4430, label %bb_rcs1041, label %bb_rcsendslow1033
bb_rcs1041:
  %v4431 = load i64, ptr %slot778, align 8
  %op4432 = add i64 %v4431, 200
  store i64 %op4432, ptr %slot782, align 8
  %v4433 = load i64, ptr %slot782, align 8
  %p4434 = inttoptr i64 %v4433 to ptr
  %ld4435 = load i64, ptr %p4434, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4435, ptr %slot783, align 8
  %v4436 = load i64, ptr %slot783, align 8
  %cmp4437 = icmp eq i64 %v4436, 0
  %cv4438 = zext i1 %cmp4437 to i32
  store i32 %cv4438, ptr %slot784, align 8
  %v4439 = load i32, ptr %slot784, align 8
  %cv4440 = zext i32 %v4439 to i64
  %cond4441 = icmp ne i64 %cv4440, 0
  br i1 %cond4441, label %bb_rcs1045, label %bb_rcsendslow1033
bb_rcs1045:
  %v4442 = load i64, ptr %slot774, align 8
  %p4444 = inttoptr i64 %v4442 to ptr
  %gep4445 = getelementptr i8, ptr %p4444, i64 16
  %op4443 = ptrtoint ptr %gep4445 to i64
  store i64 %op4443, ptr %slot785, align 8
  %v4446 = load i64, ptr %slot785, align 8
  %p4447 = inttoptr i64 %v4446 to ptr
  %ld4448 = load i64, ptr %p4447, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4448, ptr %slot786, align 8
  %v4449 = load i64, ptr %slot786, align 8
  %cmp4450 = icmp ne i64 %v4449, 0
  %cv4451 = zext i1 %cmp4450 to i32
  store i32 %cv4451, ptr %slot787, align 8
  %v4452 = load i32, ptr %slot787, align 8
  %cv4453 = zext i32 %v4452 to i64
  %cond4454 = icmp ne i64 %cv4453, 0
  br i1 %cond4454, label %bb_rcsendnode1033, label %bb_rcsendunlink1033
bb_rcsendnode1033:
  %v4455 = load i64, ptr %slot786, align 8
  %op4456 = add i64 %v4455, 0
  store i64 %op4456, ptr %slot788, align 8
  %v4457 = load i64, ptr %slot788, align 8
  %p4458 = inttoptr i64 %v4457 to ptr
  %ld4459 = load i64, ptr %p4458, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4459, ptr %slot789, align 8
  %v4460 = load i64, ptr %slot789, align 8
  %cmp4461 = icmp eq i64 %v4460, 0
  %cv4462 = zext i1 %cmp4461 to i32
  store i32 %cv4462, ptr %slot790, align 8
  %v4463 = load i32, ptr %slot790, align 8
  %cv4464 = zext i32 %v4463 to i64
  %cond4465 = icmp ne i64 %cv4464, 0
  br i1 %cond4465, label %bb_rcs1052, label %bb_rcsendslow1033
bb_rcs1052:
  %v4466 = load i64, ptr %slot778, align 8
  %op4467 = add i64 %v4466, 264
  store i64 %op4467, ptr %slot791, align 8
  %v4468 = load i64, ptr %slot791, align 8
  %p4469 = inttoptr i64 %v4468 to ptr
  %ld4470 = load i64, ptr %p4469, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4470, ptr %slot792, align 8
  %v4471 = load i64, ptr %slot792, align 8
  %cmp4472 = icmp ult i64 %v4471, 32
  %cv4473 = zext i1 %cmp4472 to i32
  store i32 %cv4473, ptr %slot793, align 8
  %v4474 = load i32, ptr %slot793, align 8
  %cv4475 = zext i32 %v4474 to i64
  %cond4476 = icmp ne i64 %cv4475, 0
  br i1 %cond4476, label %bb_rcs1056, label %bb_rcsendslow1033
bb_rcs1056:
  %v4477 = load i64, ptr %slot786, align 8
  %op4478 = add i64 %v4477, 8
  store i64 %op4478, ptr %slot794, align 8
  %v4479 = load i64, ptr %slot794, align 8
  %p4480 = inttoptr i64 %v4479 to ptr
  %ld4481 = load i64, ptr %p4480, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4481, ptr %slot795, align 8
  %v4482 = load i64, ptr %slot795, align 8
  %cmp4483 = icmp ne i64 %v4482, 0
  %cv4484 = zext i1 %cmp4483 to i32
  store i32 %cv4484, ptr %slot796, align 8
  %v4485 = load i32, ptr %slot796, align 8
  %cv4486 = zext i32 %v4485 to i64
  %cond4487 = icmp ne i64 %cv4486, 0
  br i1 %cond4487, label %bb_rcs1060, label %bb_rcsendslow1033
bb_rcs1060:
  %v4488 = load i64, ptr %slot795, align 8
  %op4489 = sub i64 %v4488, 16
  store i64 %op4489, ptr %slot797, align 8
  %v4490 = load i64, ptr %slot795, align 8
  %p4491 = inttoptr i64 %v4490 to ptr
  %rgep4492 = getelementptr i8, ptr %p4491, i64 -16
  %ld4493 = load i64, ptr %rgep4492, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4493, ptr %slot798, align 8
  %v4494 = load i64, ptr %slot798, align 8
  %op4495 = and i64 %v4494, 4611686018427387907
  store i64 %op4495, ptr %slot799, align 8
  %v4496 = load i64, ptr %slot799, align 8
  %cmp4497 = icmp eq i64 %v4496, 0
  %cv4498 = zext i1 %cmp4497 to i32
  store i32 %cv4498, ptr %slot800, align 8
  %v4499 = load i32, ptr %slot800, align 8
  %cv4500 = zext i32 %v4499 to i64
  %cond4501 = icmp ne i64 %cv4500, 0
  br i1 %cond4501, label %bb_rcs1065, label %bb_rcsendslow1033
bb_rcs1065:
  %v4502 = load i64, ptr %slot795, align 8
  %op4503 = sub i64 %v4502, 24
  store i64 %op4503, ptr %slot801, align 8
  %v4504 = load i64, ptr %slot795, align 8
  %p4505 = inttoptr i64 %v4504 to ptr
  %rgep4506 = getelementptr i8, ptr %p4505, i64 -24
  %ld4507 = load i64, ptr %rgep4506, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4507, ptr %slot802, align 8
  %v4508 = load i64, ptr %slot802, align 8
  %cmp4509 = icmp ne i64 %v4508, 0
  %cv4510 = zext i1 %cmp4509 to i32
  store i32 %cv4510, ptr %slot803, align 8
  %v4511 = load i32, ptr %slot803, align 8
  %cv4512 = zext i32 %v4511 to i64
  %cond4513 = icmp ne i64 %cv4512, 0
  br i1 %cond4513, label %bb_rcs1069, label %bb_rcsendslow1033
bb_rcs1069:
  %v4514 = load i64, ptr %slot795, align 8
  %op4515 = sub i64 %v4514, 32
  store i64 %op4515, ptr %slot804, align 8
  %v4516 = load i64, ptr %slot795, align 8
  %p4517 = inttoptr i64 %v4516 to ptr
  %rgep4518 = getelementptr i8, ptr %p4517, i64 -32
  %ld4519 = load i64, ptr %rgep4518, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4519, ptr %slot805, align 8
  %v4520 = load i64, ptr %slot802, align 8
  %cmp4521 = icmp ugt i64 %v4520, 1
  %cv4522 = zext i1 %cmp4521 to i32
  store i32 %cv4522, ptr %slot806, align 8
  %v4523 = load i64, ptr %slot805, align 8
  %cmp4524 = icmp ne i64 %v4523, 0
  %cv4525 = zext i1 %cmp4524 to i32
  store i32 %cv4525, ptr %slot807, align 8
  %v4526 = load i32, ptr %slot806, align 8
  %v4527 = load i32, ptr %slot807, align 8
  %op4528 = or i32 %v4526, %v4527
  store i32 %op4528, ptr %slot808, align 8
  %v4529 = load i32, ptr %slot808, align 8
  %cv4530 = zext i32 %v4529 to i64
  %cond4531 = icmp ne i64 %cv4530, 0
  br i1 %cond4531, label %bb_rcs1075, label %bb_rcsendslow1033
bb_rcs1075:
  %v4532 = load i64, ptr %slot786, align 8
  %op4533 = add i64 %v4532, 32
  store i64 %op4533, ptr %slot809, align 8
  %v4534 = load i64, ptr %slot809, align 8
  %p4535 = inttoptr i64 %v4534 to ptr
  %ld4536 = load i64, ptr %p4535, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4536, ptr %slot810, align 8
  %v4537 = load i64, ptr %slot810, align 8
  %cmp4538 = icmp ne i64 %v4537, 0
  %cv4539 = zext i1 %cmp4538 to i32
  store i32 %cv4539, ptr %slot811, align 8
  %v4540 = load i32, ptr %slot811, align 8
  %cv4541 = zext i32 %v4540 to i64
  %cond4542 = icmp ne i64 %cv4541, 0
  br i1 %cond4542, label %bb_rcsendbacking1033, label %bb_rcsendcommit1033
bb_rcsendbacking1033:
  %v4543 = load i64, ptr %slot810, align 8
  %op4544 = sub i64 %v4543, 16
  store i64 %op4544, ptr %slot812, align 8
  %v4545 = load i64, ptr %slot810, align 8
  %p4546 = inttoptr i64 %v4545 to ptr
  %rgep4547 = getelementptr i8, ptr %p4546, i64 -16
  %ld4548 = load i64, ptr %rgep4547, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4548, ptr %slot813, align 8
  %v4549 = load i64, ptr %slot813, align 8
  %op4550 = and i64 %v4549, 4611686018427387907
  store i64 %op4550, ptr %slot814, align 8
  %v4551 = load i64, ptr %slot814, align 8
  %cmp4552 = icmp eq i64 %v4551, 0
  %cv4553 = zext i1 %cmp4552 to i32
  store i32 %cv4553, ptr %slot815, align 8
  %v4554 = load i32, ptr %slot815, align 8
  %cv4555 = zext i32 %v4554 to i64
  %cond4556 = icmp ne i64 %cv4555, 0
  br i1 %cond4556, label %bb_rcs1083, label %bb_rcsendslow1033
bb_rcs1083:
  %v4557 = load i64, ptr %slot810, align 8
  %op4558 = sub i64 %v4557, 24
  store i64 %op4558, ptr %slot816, align 8
  %v4559 = load i64, ptr %slot810, align 8
  %p4560 = inttoptr i64 %v4559 to ptr
  %rgep4561 = getelementptr i8, ptr %p4560, i64 -24
  %ld4562 = load i64, ptr %rgep4561, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4562, ptr %slot817, align 8
  %v4563 = load i64, ptr %slot817, align 8
  %cmp4564 = icmp ne i64 %v4563, 0
  %cv4565 = zext i1 %cmp4564 to i32
  store i32 %cv4565, ptr %slot818, align 8
  %v4566 = load i32, ptr %slot818, align 8
  %cv4567 = zext i32 %v4566 to i64
  %cond4568 = icmp ne i64 %cv4567, 0
  br i1 %cond4568, label %bb_rcs1087, label %bb_rcsendslow1033
bb_rcs1087:
  %v4569 = load i64, ptr %slot810, align 8
  %op4570 = sub i64 %v4569, 32
  store i64 %op4570, ptr %slot819, align 8
  %v4571 = load i64, ptr %slot810, align 8
  %p4572 = inttoptr i64 %v4571 to ptr
  %rgep4573 = getelementptr i8, ptr %p4572, i64 -32
  %ld4574 = load i64, ptr %rgep4573, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4574, ptr %slot820, align 8
  %v4575 = load i64, ptr %slot817, align 8
  %cmp4576 = icmp ugt i64 %v4575, 1
  %cv4577 = zext i1 %cmp4576 to i32
  store i32 %cv4577, ptr %slot821, align 8
  %v4578 = load i64, ptr %slot820, align 8
  %cmp4579 = icmp ne i64 %v4578, 0
  %cv4580 = zext i1 %cmp4579 to i32
  store i32 %cv4580, ptr %slot822, align 8
  %v4581 = load i32, ptr %slot821, align 8
  %v4582 = load i32, ptr %slot822, align 8
  %op4583 = or i32 %v4581, %v4582
  store i32 %op4583, ptr %slot823, align 8
  %v4584 = load i32, ptr %slot823, align 8
  %cv4585 = zext i32 %v4584 to i64
  %cond4586 = icmp ne i64 %cv4585, 0
  br i1 %cond4586, label %bb_rcs1093, label %bb_rcsendslow1033
bb_rcs1093:
  br label %bb_rcsendcommit1033
bb_rcsendcommit1033:
  %v4587 = load i64, ptr %slot786, align 8
  %op4588 = add i64 %v4587, 24
  store i64 %op4588, ptr %slot824, align 8
  %v4589 = load i64, ptr %slot824, align 8
  %p4590 = inttoptr i64 %v4589 to ptr
  %ld4591 = load i32, ptr %p4590, align 4, !alias.scope !9999998, !noalias !9999999
  store i32 %ld4591, ptr %slot825, align 8
  %v4592 = load i32, ptr %slot825, align 8
  %cv4593 = zext i32 %v4592 to i64
  %cond4594 = icmp ne i64 %cv4593, 0
  br i1 %cond4594, label %bb_rcsendrestore1033, label %bb_rcsendreturned1033
bb_rcsendrestore1033:
  %v4595 = load i64, ptr %slot786, align 8
  %op4596 = add i64 %v4595, 16
  store i64 %op4596, ptr %slot826, align 8
  %v4597 = load i64, ptr %slot826, align 8
  %p4598 = inttoptr i64 %v4597 to ptr
  %ld4599 = load i64, ptr %p4598, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4599, ptr %slot827, align 8
  %v4600 = load i64, ptr %slot798, align 8
  %op4601 = and i64 %v4600, 17293822569102704639
  store i64 %op4601, ptr %slot828, align 8
  %v4602 = load i64, ptr %slot828, align 8
  %v4603 = load i64, ptr %slot827, align 8
  %op4604 = or i64 %v4602, %v4603
  store i64 %op4604, ptr %slot829, align 8
  %v4605 = load i64, ptr %slot795, align 8
  %op4606 = sub i64 %v4605, 16
  store i64 %op4606, ptr %slot830, align 8
  %v4607 = load i64, ptr %slot829, align 8
  %v4608 = load i64, ptr %slot795, align 8
  %p4609 = inttoptr i64 %v4608 to ptr
  %rgep4610 = getelementptr i8, ptr %p4609, i64 -16
  store i64 %v4607, ptr %rgep4610, align 8, !alias.scope !9, !noalias !10
  %v4611 = load i64, ptr %slot774, align 8
  %p4613 = inttoptr i64 %v4611 to ptr
  %gep4614 = getelementptr i8, ptr %p4613, i64 16
  %op4612 = ptrtoint ptr %gep4614 to i64
  store i64 %op4612, ptr %slot831, align 8
  br label %bb_rcsendreturned1033
bb_rcsendreturned1033:
  %v4615 = load i64, ptr %slot831, align 8
  %p4616 = inttoptr i64 %v4615 to ptr
  store i64 0, ptr %p4616, align 8, !alias.scope !3, !noalias !4
  %v4617 = load i64, ptr %slot778, align 8
  %op4618 = add i64 %v4617, 256
  store i64 %op4618, ptr %slot832, align 8
  %v4619 = load i64, ptr %slot832, align 8
  %p4620 = inttoptr i64 %v4619 to ptr
  %ld4621 = load i64, ptr %p4620, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4621, ptr %slot833, align 8
  %v4622 = load i64, ptr %slot786, align 8
  %op4623 = add i64 %v4622, 0
  store i64 %op4623, ptr %slot834, align 8
  %v4624 = load i64, ptr %slot833, align 8
  %v4625 = load i64, ptr %slot834, align 8
  %p4626 = inttoptr i64 %v4625 to ptr
  store i64 %v4624, ptr %p4626, align 8, !alias.scope !9999998, !noalias !9999999
  %v4627 = load i64, ptr %slot778, align 8
  %op4628 = add i64 %v4627, 256
  store i64 %op4628, ptr %slot835, align 8
  %v4629 = load i64, ptr %slot786, align 8
  %v4630 = load i64, ptr %slot835, align 8
  %p4631 = inttoptr i64 %v4630 to ptr
  store i64 %v4629, ptr %p4631, align 8, !alias.scope !9999998, !noalias !9999999
  %v4632 = load i64, ptr %slot778, align 8
  %op4633 = add i64 %v4632, 264
  store i64 %op4633, ptr %slot836, align 8
  %v4634 = load i64, ptr %slot836, align 8
  %p4635 = inttoptr i64 %v4634 to ptr
  %ld4636 = load i64, ptr %p4635, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4636, ptr %slot837, align 8
  %v4637 = load i64, ptr %slot837, align 8
  %op4638 = add i64 %v4637, 1
  store i64 %op4638, ptr %slot838, align 8
  %v4639 = load i64, ptr %slot838, align 8
  %v4640 = load i64, ptr %slot836, align 8
  %p4641 = inttoptr i64 %v4640 to ptr
  store i64 %v4639, ptr %p4641, align 8, !alias.scope !9999998, !noalias !9999999
  %v4642 = load i64, ptr %slot56, align 8
  %p4644 = inttoptr i64 %v4642 to ptr
  %gep4645 = getelementptr i8, ptr %p4644, i64 24
  %op4643 = ptrtoint ptr %gep4645 to i64
  store i64 %op4643, ptr %slot839, align 8
  %v4646 = load i64, ptr %slot839, align 8
  %p4647 = inttoptr i64 %v4646 to ptr
  %ld4648 = load i64, ptr %p4647, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4648, ptr %slot840, align 8
  %v4649 = load i64, ptr %slot840, align 8
  %op4650 = add i64 %v4649, 18446744073709551576
  store i64 %op4650, ptr %slot841, align 8
  %v4651 = load i64, ptr %slot841, align 8
  %v4652 = load i64, ptr %slot839, align 8
  %p4653 = inttoptr i64 %v4652 to ptr
  store i64 %v4651, ptr %p4653, align 8, !alias.scope !9999998, !noalias !9999999
  %v4654 = load i64, ptr %slot778, align 8
  %op4655 = add i64 %v4654, 48
  store i64 %op4655, ptr %slot842, align 8
  %v4656 = load i64, ptr %slot842, align 8
  %p4657 = inttoptr i64 %v4656 to ptr
  %ld4658 = load i64, ptr %p4657, align 8, !alias.scope !9999998, !noalias !9999999
  store i64 %ld4658, ptr %slot843, align 8
  %v4659 = load i64, ptr %slot843, align 8
  %op4660 = add i64 %v4659, 18446744073709551576
  store i64 %op4660, ptr %slot844, align 8
  %v4661 = load i64, ptr %slot844, align 8
  %v4662 = load i64, ptr %slot842, align 8
  %p4663 = inttoptr i64 %v4662 to ptr
  store i64 %v4661, ptr %p4663, align 8, !alias.scope !9999998, !noalias !9999999
  %v4664 = load i64, ptr %slot810, align 8
  %cmp4665 = icmp ne i64 %v4664, 0
  %cv4666 = zext i1 %cmp4665 to i32
  store i32 %cv4666, ptr %slot845, align 8
  %v4667 = load i32, ptr %slot845, align 8
  %cv4668 = zext i32 %v4667 to i64
  %cond4669 = icmp ne i64 %cv4668, 0
  br i1 %cond4669, label %bb_rcsenddropbacking1033, label %bb_rcsenddroppayload1033
bb_rcsenddropbacking1033:
  %v4670 = load i64, ptr %slot810, align 8
  %op4671 = sub i64 %v4670, 24
  store i64 %op4671, ptr %slot846, align 8
  %v4672 = load i64, ptr %slot810, align 8
  %p4673 = inttoptr i64 %v4672 to ptr
  %rgep4674 = getelementptr i8, ptr %p4673, i64 -24
  %ld4675 = load i64, ptr %rgep4674, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4675, ptr %slot847, align 8
  %v4676 = load i64, ptr %slot847, align 8
  %op4677 = add i64 %v4676, 18446744073709551615
  store i64 %op4677, ptr %slot848, align 8
  %v4678 = load i64, ptr %slot848, align 8
  %v4679 = load i64, ptr %slot810, align 8
  %p4680 = inttoptr i64 %v4679 to ptr
  %rgep4681 = getelementptr i8, ptr %p4680, i64 -24
  store i64 %v4678, ptr %rgep4681, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsenddroppayload1033
bb_rcsenddroppayload1033:
  %v4682 = load i64, ptr %slot795, align 8
  %op4683 = sub i64 %v4682, 24
  store i64 %op4683, ptr %slot849, align 8
  %v4684 = load i64, ptr %slot795, align 8
  %p4685 = inttoptr i64 %v4684 to ptr
  %rgep4686 = getelementptr i8, ptr %p4685, i64 -24
  %ld4687 = load i64, ptr %rgep4686, align 8, !alias.scope !9, !noalias !10
  store i64 %ld4687, ptr %slot850, align 8
  %v4688 = load i64, ptr %slot850, align 8
  %op4689 = add i64 %v4688, 18446744073709551615
  store i64 %op4689, ptr %slot851, align 8
  %v4690 = load i64, ptr %slot851, align 8
  %v4691 = load i64, ptr %slot795, align 8
  %p4692 = inttoptr i64 %v4691 to ptr
  %rgep4693 = getelementptr i8, ptr %p4692, i64 -24
  store i64 %v4690, ptr %rgep4693, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcsendunlink1033
bb_rcsendunlink1033:
  %v4694 = load i64, ptr %slot774, align 8
  %p4696 = inttoptr i64 %v4694 to ptr
  %gep4697 = getelementptr i8, ptr %p4696, i64 8
  %op4695 = ptrtoint ptr %gep4697 to i64
  store i64 %op4695, ptr %slot852, align 8
  %v4698 = load i64, ptr %slot852, align 8
  %p4699 = inttoptr i64 %v4698 to ptr
  %ld4700 = load i64, ptr %p4699, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4700, ptr %slot853, align 8
  %v4701 = load i64, ptr %slot778, align 8
  %op4702 = add i64 %v4701, 248
  store i64 %op4702, ptr %slot854, align 8
  %v4703 = load i64, ptr %slot853, align 8
  %v4704 = load i64, ptr %slot854, align 8
  %p4705 = inttoptr i64 %v4704 to ptr
  store i64 %v4703, ptr %p4705, align 8, !alias.scope !9999998, !noalias !9999999
  %v4706 = load i64, ptr %slot774, align 8
  %p4708 = inttoptr i64 %v4706 to ptr
  %gep4709 = getelementptr i8, ptr %p4708, i64 24
  %op4707 = ptrtoint ptr %gep4709 to i64
  store i64 %op4707, ptr %slot855, align 8
  %v4710 = load i64, ptr %slot774, align 8
  %p4712 = inttoptr i64 %v4710 to ptr
  %gep4713 = getelementptr i8, ptr %p4712, i64 8
  %op4711 = ptrtoint ptr %gep4713 to i64
  store i64 %op4711, ptr %slot856, align 8
  %v4714 = load i64, ptr %slot855, align 8
  %p4715 = inttoptr i64 %v4714 to ptr
  store i32 0, ptr %p4715, align 4, !alias.scope !3, !noalias !4
  %v4716 = load i64, ptr %slot856, align 8
  %p4717 = inttoptr i64 %v4716 to ptr
  store i64 0, ptr %p4717, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcsenddone1033
bb_rcsendslow1033:
  %v4718 = load i64, ptr %slot1, align 8
  %p4719 = inttoptr i64 %v4718 to ptr
  %v4720 = load i64, ptr %slot774, align 8
  %p4721 = inttoptr i64 %v4720 to ptr
  call void @myl_qbe_rc_scope_end(ptr %p4719, ptr %p4721) nomerge, !dbg !140
  br label %bb_rcsenddone1033
bb_rcsenddone1033:
  br label %bb_i34
bb_i33:
  br label %bb_i34
bb_i34:
  br label %bb_i18
bb_i35:
  %v4722 = load i64, ptr %slot38, align 8
  %v4723 = load i64, ptr %slot41, align 8
  %p4724 = inttoptr i64 %v4723 to ptr
  store i64 %v4722, ptr %p4724, align 8, !alias.scope !3, !noalias !4
  %v4725 = load i64, ptr %slot41, align 8
  %p4726 = inttoptr i64 %v4725 to ptr
  %ld4727 = load i64, ptr %p4726, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4727, ptr %slot857, align 8
  %v4728 = load i64, ptr %slot857, align 8
  %op4729 = add i64 %v4728, 0
  store i64 %op4729, ptr %slot858, align 8
  %v4730 = load i64, ptr %slot858, align 8
  %v4731 = load i64, ptr %slot41, align 8
  %p4732 = inttoptr i64 %v4731 to ptr
  store i64 %v4730, ptr %p4732, align 8, !alias.scope !3, !noalias !4
  %v4733 = load i64, ptr %slot11, align 8
  %p4734 = inttoptr i64 %v4733 to ptr
  %ld4735 = load i32, ptr %p4734, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4735, ptr %slot859, align 8
  %v4736 = load i32, ptr %slot859, align 8
  %cv4737 = zext i32 %v4736 to i64
  %cond4738 = icmp ne i64 %cv4737, 0
  br i1 %cond4738, label %bb_rcslotdrop1131, label %bb_rcslotdone1131
bb_rcslotdrop1131:
  %v4739 = load i64, ptr %slot11, align 8
  %p4740 = inttoptr i64 %v4739 to ptr
  store i32 0, ptr %p4740, align 4, !alias.scope !3, !noalias !4
  %v4741 = load i64, ptr %slot22, align 8
  store i64 %v4741, ptr %slot860, align 8
  %v4742 = load i64, ptr %slot12, align 8
  %p4743 = inttoptr i64 %v4742 to ptr
  %ld4744 = load i32, ptr %p4743, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4744, ptr %slot861, align 8
  %v4745 = load i32, ptr %slot861, align 8
  %op4746 = and i32 %v4745, 28
  store i32 %op4746, ptr %slot862, align 8
  %v4747 = load i32, ptr %slot862, align 8
  %cv4748 = zext i32 %v4747 to i64
  %cond4749 = icmp ne i64 %cv4748, 0
  br i1 %cond4749, label %bb_rcslotrole1131, label %bb_rcslotowner1131
bb_rcslotrole1131:
  %v4750 = load i64, ptr %slot56, align 8
  store i64 %v4750, ptr %slot863, align 8
  %v4751 = load i64, ptr %slot863, align 8
  %v4752 = load i64, ptr %slot860, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v4751, i64 %v4752) nomerge, !dbg !142
  br label %bb_rcslotdone1131
bb_rcslotowner1131:
  %v4753 = load i64, ptr %slot56, align 8
  store i64 %v4753, ptr %slot864, align 8
  %v4754 = load i64, ptr %slot864, align 8
  %v4755 = load i64, ptr %slot860, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v4754, i64 %v4755) nomerge, !dbg !142
  br label %bb_rcslotdone1131
bb_rcslotdone1131:
  %v4756 = load i64, ptr %slot41, align 8
  %p4757 = inttoptr i64 %v4756 to ptr
  %ld4758 = load i64, ptr %p4757, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4758, ptr %slot865, align 8
  %v4759 = load i64, ptr %slot11, align 8
  %p4760 = inttoptr i64 %v4759 to ptr
  %ld4761 = load i32, ptr %p4760, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4761, ptr %slot866, align 8
  %v4762 = load i64, ptr %slot12, align 8
  %p4763 = inttoptr i64 %v4762 to ptr
  %ld4764 = load i32, ptr %p4763, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4764, ptr %slot867, align 8
  %v4765 = load i32, ptr %slot867, align 8
  %op4766 = and i32 %v4765, 24
  store i32 %op4766, ptr %slot867, align 8
  %v4767 = load i32, ptr %slot867, align 8
  %cmp4768 = icmp eq i32 %v4767, 0
  %cv4769 = zext i1 %cmp4768 to i32
  store i32 %cv4769, ptr %slot868, align 8
  %v4770 = load i32, ptr %slot866, align 8
  %v4771 = load i32, ptr %slot868, align 8
  %op4772 = and i32 %v4770, %v4771
  store i32 %op4772, ptr %slot869, align 8
  %v4773 = load i64, ptr %slot57, align 8
  store i64 %v4773, ptr %slot870, align 8
  %v4774 = load i32, ptr %slot869, align 8
  %op4775 = mul i32 %v4774, 4
  store i32 %op4775, ptr %slot871, align 8
  %v4776 = load i32, ptr %slot871, align 8
  %op4777 = or i32 %v4776, 0
  store i32 %op4777, ptr %slot872, align 8
  %v4778 = load i64, ptr %slot29, align 8
  store i64 %v4778, ptr %slot873, align 8
  %v4779 = load i64, ptr %slot56, align 8
  %v4780 = load i64, ptr %slot873, align 8
  %v4781 = load i64, ptr %slot865, align 8
  %v4782 = load i64, ptr %slot870, align 8
  %cv4783 = trunc i64 %v4782 to i32
  %v4784 = load i32, ptr %slot872, align 8
  %call4785 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_publish(i64 %v4779, i64 %v4780, i64 %v4781, i32 %cv4783, i32 %v4784) nomerge, !dbg !144
  store i32 %call4785, ptr %slot874, align 8
  %v4786 = load i32, ptr %slot874, align 8
  %cv4787 = zext i32 %v4786 to i64
  %cond4788 = icmp ne i64 %cv4787, 0
  br i1 %cond4788, label %bb_rcsuccess1152, label %bb_rcfailure1152
bb_rcfailure1152:
  %v4789 = load i64, ptr %slot56, align 8
  %p4790 = inttoptr i64 %v4789 to ptr
  %call4791 = call i32 @myl_rc_take_failure(ptr %p4790) nomerge, !dbg !144
  store i32 %call4791, ptr %slot875, align 8
  %v4792 = load i64, ptr %slot1, align 8
  %p4793 = inttoptr i64 %v4792 to ptr
  %v4794 = load i32, ptr %slot875, align 8
  %call4795 = call i32 @myl_qbe_rc_status(ptr %p4793, i32 %v4794) nomerge, !dbg !144
  store i32 %call4795, ptr %slot876, align 8
  br label %bb_failure
bb_rcsuccess1152:
  %v4796 = load i32, ptr %slot869, align 8
  %cv4797 = zext i32 %v4796 to i64
  %cond4798 = icmp ne i64 %cv4797, 0
  br i1 %cond4798, label %bb_rchtaken1155, label %bb_rchcopied1155
bb_rchcopied1155:
  %v4799 = load i64, ptr %slot11, align 8
  %p4800 = inttoptr i64 %v4799 to ptr
  %ld4801 = load i32, ptr %p4800, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4801, ptr %slot877, align 8
  %v4802 = load i32, ptr %slot877, align 8
  %cv4803 = zext i32 %v4802 to i64
  %cond4804 = icmp ne i64 %cv4803, 0
  br i1 %cond4804, label %bb_rcslotdrop1158, label %bb_rcslotdone1158
bb_rcslotdrop1158:
  %v4805 = load i64, ptr %slot11, align 8
  %p4806 = inttoptr i64 %v4805 to ptr
  store i32 0, ptr %p4806, align 4, !alias.scope !3, !noalias !4
  %v4807 = load i64, ptr %slot22, align 8
  store i64 %v4807, ptr %slot878, align 8
  %v4808 = load i64, ptr %slot12, align 8
  %p4809 = inttoptr i64 %v4808 to ptr
  %ld4810 = load i32, ptr %p4809, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4810, ptr %slot879, align 8
  %v4811 = load i32, ptr %slot879, align 8
  %op4812 = and i32 %v4811, 28
  store i32 %op4812, ptr %slot880, align 8
  %v4813 = load i32, ptr %slot880, align 8
  %cv4814 = zext i32 %v4813 to i64
  %cond4815 = icmp ne i64 %cv4814, 0
  br i1 %cond4815, label %bb_rcslotrole1158, label %bb_rcslotowner1158
bb_rcslotrole1158:
  %v4816 = load i64, ptr %slot56, align 8
  store i64 %v4816, ptr %slot881, align 8
  %v4817 = load i64, ptr %slot881, align 8
  %v4818 = load i64, ptr %slot878, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64 %v4817, i64 %v4818) nomerge, !dbg !144
  br label %bb_rcslotdone1158
bb_rcslotowner1158:
  %v4819 = load i64, ptr %slot56, align 8
  store i64 %v4819, ptr %slot882, align 8
  %v4820 = load i64, ptr %slot882, align 8
  %v4821 = load i64, ptr %slot878, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4820, i64 %v4821) nomerge, !dbg !144
  br label %bb_rcslotdone1158
bb_rcslotdone1158:
  br label %bb_rchprepared1155
bb_rchtaken1155:
  %v4822 = load i64, ptr %slot11, align 8
  %p4823 = inttoptr i64 %v4822 to ptr
  store i32 0, ptr %p4823, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1155
bb_rchprepared1155:
  %v4824 = load i64, ptr %slot20, align 8
  %p4825 = inttoptr i64 %v4824 to ptr
  store i32 2, ptr %p4825, align 4, !alias.scope !3, !noalias !4
  %v4826 = load i64, ptr %slot19, align 8
  %p4827 = inttoptr i64 %v4826 to ptr
  store i32 1, ptr %p4827, align 4, !alias.scope !3, !noalias !4
  %v4828 = load i64, ptr %slot22, align 8
  store i64 %v4828, ptr %slot883, align 8
  %v4829 = load i64, ptr %slot29, align 8
  store i64 %v4829, ptr %slot884, align 8
  %v4830 = load i64, ptr %slot884, align 8
  %v4831 = load i64, ptr %slot883, align 8
  %p4832 = inttoptr i64 %v4830 to ptr
  %p4833 = inttoptr i64 %v4831 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4833, ptr %p4832, i64 208, i1 false), !alias.scope !3, !noalias !4
  %v4834 = load i64, ptr %slot12, align 8
  %p4835 = inttoptr i64 %v4834 to ptr
  store i32 2, ptr %p4835, align 4, !alias.scope !3, !noalias !4
  %v4836 = load i64, ptr %slot20, align 8
  %p4837 = inttoptr i64 %v4836 to ptr
  %ld4838 = load i32, ptr %p4837, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4838, ptr %slot885, align 8
  %v4839 = load i32, ptr %slot885, align 8
  %v4840 = load i64, ptr %slot12, align 8
  %p4841 = inttoptr i64 %v4840 to ptr
  store i32 %v4839, ptr %p4841, align 4, !alias.scope !3, !noalias !4
  %v4842 = load i64, ptr %slot19, align 8
  %p4843 = inttoptr i64 %v4842 to ptr
  store i32 0, ptr %p4843, align 4, !alias.scope !3, !noalias !4
  %v4844 = load i64, ptr %slot11, align 8
  %p4845 = inttoptr i64 %v4844 to ptr
  store i32 1, ptr %p4845, align 4, !alias.scope !3, !noalias !4
  %v4846 = load i64, ptr %slot883, align 8
  %v4847 = load i64, ptr %slot41, align 8
  %p4848 = inttoptr i64 %v4847 to ptr
  store i64 %v4846, ptr %p4848, align 8, !alias.scope !3, !noalias !4
  %v4849 = load i64, ptr %slot41, align 8
  %p4850 = inttoptr i64 %v4849 to ptr
  %ld4851 = load i64, ptr %p4850, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4851, ptr %slot886, align 8
  %v4852 = load i64, ptr %slot29, align 8
  store i64 %v4852, ptr %slot887, align 8
  %v4853 = load i64, ptr %slot57, align 8
  store i64 %v4853, ptr %slot888, align 8
  %v4854 = load i64, ptr %slot56, align 8
  %v4855 = load i64, ptr %slot887, align 8
  %v4856 = load i64, ptr %slot886, align 8
  %v4857 = load i64, ptr %slot888, align 8
  %cv4858 = trunc i64 %v4857 to i32
  %call4859 = call i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64 %v4854, i64 %v4855, i64 %v4856, i32 %cv4858) nomerge, !dbg !146
  store i32 %call4859, ptr %slot889, align 8
  %v4860 = load i32, ptr %slot889, align 8
  %cv4861 = zext i32 %v4860 to i64
  %cond4862 = icmp ne i64 %cv4861, 0
  br i1 %cond4862, label %bb_rcsuccess1180, label %bb_rcfailure1180
bb_rcfailure1180:
  %v4863 = load i64, ptr %slot56, align 8
  %p4864 = inttoptr i64 %v4863 to ptr
  %call4865 = call i32 @myl_rc_take_failure(ptr %p4864) nomerge, !dbg !146
  store i32 %call4865, ptr %slot890, align 8
  %v4866 = load i64, ptr %slot1, align 8
  %p4867 = inttoptr i64 %v4866 to ptr
  %v4868 = load i32, ptr %slot890, align 8
  %call4869 = call i32 @myl_qbe_rc_status(ptr %p4867, i32 %v4868) nomerge, !dbg !146
  store i32 %call4869, ptr %slot891, align 8
  br label %bb_failure
bb_rcsuccess1180:
  %v4870 = load i64, ptr %slot11, align 8
  %p4871 = inttoptr i64 %v4870 to ptr
  store i32 0, ptr %p4871, align 4, !alias.scope !3, !noalias !4
  %v4872 = load i64, ptr %slot20, align 8
  %p4873 = inttoptr i64 %v4872 to ptr
  store i32 2, ptr %p4873, align 4, !alias.scope !3, !noalias !4
  %v4874 = load i64, ptr %slot19, align 8
  %p4875 = inttoptr i64 %v4874 to ptr
  store i32 1, ptr %p4875, align 4, !alias.scope !3, !noalias !4
  %v4876 = load i64, ptr %slot34, align 8
  %p4877 = inttoptr i64 %v4876 to ptr
  %ld4878 = load i64, ptr %p4877, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4878, ptr %slot892, align 8
  %v4879 = load i64, ptr %slot56, align 8
  store i64 %v4879, ptr %slot893, align 8
  %v4880 = load i64, ptr %slot893, align 8
  %v4881 = load i64, ptr %slot892, align 8
  call void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64 %v4880, i64 %v4881) nomerge, !dbg !146
  %v4882 = load i64, ptr %slot29, align 8
  store i64 %v4882, ptr %slot894, align 8
  %v4883 = load i64, ptr %slot894, align 8
  %v4884 = load i64, ptr %slot892, align 8
  %p4885 = inttoptr i64 %v4883 to ptr
  %p4886 = inttoptr i64 %v4884 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p4886, ptr %p4885, i64 208, i1 false), !alias.scope !10000000
  %v4887 = load i64, ptr %slot19, align 8
  %p4888 = inttoptr i64 %v4887 to ptr
  store i32 0, ptr %p4888, align 4, !alias.scope !3, !noalias !4
  %v4889 = load i64, ptr %slot38, align 8
  %v4890 = load i64, ptr %slot41, align 8
  %p4891 = inttoptr i64 %v4890 to ptr
  store i64 %v4889, ptr %p4891, align 8, !alias.scope !3, !noalias !4
  %v4892 = load i64, ptr %slot41, align 8
  %p4893 = inttoptr i64 %v4892 to ptr
  %ld4894 = load i64, ptr %p4893, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4894, ptr %slot895, align 8
  %v4895 = load i64, ptr %slot895, align 8
  %op4896 = add i64 %v4895, 208
  store i64 %op4896, ptr %slot896, align 8
  %v4897 = load i64, ptr %slot896, align 8
  %v4898 = load i64, ptr %slot41, align 8
  %p4899 = inttoptr i64 %v4898 to ptr
  store i64 %v4897, ptr %p4899, align 8, !alias.scope !3, !noalias !4
  %v4900 = load i64, ptr %slot11, align 8
  %p4901 = inttoptr i64 %v4900 to ptr
  %ld4902 = load i32, ptr %p4901, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4902, ptr %slot897, align 8
  %v4903 = load i32, ptr %slot897, align 8
  %cv4904 = zext i32 %v4903 to i64
  %cond4905 = icmp ne i64 %cv4904, 0
  br i1 %cond4905, label %bb_rcslotdrop1194, label %bb_rcslotdone1194
bb_rcslotdrop1194:
  %v4906 = load i64, ptr %slot11, align 8
  %p4907 = inttoptr i64 %v4906 to ptr
  store i32 0, ptr %p4907, align 4, !alias.scope !3, !noalias !4
  %v4908 = load i64, ptr %slot22, align 8
  store i64 %v4908, ptr %slot898, align 8
  %v4909 = load i64, ptr %slot12, align 8
  %p4910 = inttoptr i64 %v4909 to ptr
  %ld4911 = load i32, ptr %p4910, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4911, ptr %slot899, align 8
  %v4912 = load i32, ptr %slot899, align 8
  %op4913 = and i32 %v4912, 28
  store i32 %op4913, ptr %slot900, align 8
  %v4914 = load i32, ptr %slot900, align 8
  %cv4915 = zext i32 %v4914 to i64
  %cond4916 = icmp ne i64 %cv4915, 0
  br i1 %cond4916, label %bb_rcslotrole1194, label %bb_rcslotowner1194
bb_rcslotrole1194:
  %v4917 = load i64, ptr %slot56, align 8
  store i64 %v4917, ptr %slot901, align 8
  %v4918 = load i64, ptr %slot901, align 8
  %v4919 = load i64, ptr %slot898, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v4918, i64 %v4919) nomerge, !dbg !148
  br label %bb_rcslotdone1194
bb_rcslotowner1194:
  %v4920 = load i64, ptr %slot56, align 8
  store i64 %v4920, ptr %slot902, align 8
  %v4921 = load i64, ptr %slot902, align 8
  %v4922 = load i64, ptr %slot898, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v4921, i64 %v4922) nomerge, !dbg !148
  br label %bb_rcslotdone1194
bb_rcslotdone1194:
  %v4923 = load i64, ptr %slot41, align 8
  %p4924 = inttoptr i64 %v4923 to ptr
  %ld4925 = load i64, ptr %p4924, align 8, !alias.scope !3, !noalias !4
  store i64 %ld4925, ptr %slot903, align 8
  %v4926 = load i64, ptr %slot11, align 8
  %p4927 = inttoptr i64 %v4926 to ptr
  %ld4928 = load i32, ptr %p4927, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4928, ptr %slot904, align 8
  %v4929 = load i64, ptr %slot12, align 8
  %p4930 = inttoptr i64 %v4929 to ptr
  %ld4931 = load i32, ptr %p4930, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4931, ptr %slot905, align 8
  %v4932 = load i32, ptr %slot905, align 8
  %op4933 = and i32 %v4932, 24
  store i32 %op4933, ptr %slot905, align 8
  %v4934 = load i32, ptr %slot905, align 8
  %cmp4935 = icmp eq i32 %v4934, 0
  %cv4936 = zext i1 %cmp4935 to i32
  store i32 %cv4936, ptr %slot906, align 8
  %v4937 = load i32, ptr %slot904, align 8
  %v4938 = load i32, ptr %slot906, align 8
  %op4939 = and i32 %v4937, %v4938
  store i32 %op4939, ptr %slot907, align 8
  %v4940 = load i64, ptr %slot57, align 8
  store i64 %v4940, ptr %slot908, align 8
  %v4941 = load i32, ptr %slot907, align 8
  %op4942 = mul i32 %v4941, 4
  store i32 %op4942, ptr %slot909, align 8
  %v4943 = load i32, ptr %slot909, align 8
  %op4944 = or i32 %v4943, 0
  store i32 %op4944, ptr %slot910, align 8
  %v4945 = load i64, ptr %slot29, align 8
  store i64 %v4945, ptr %slot911, align 8
  %v4946 = load i64, ptr %slot56, align 8
  %v4947 = load i64, ptr %slot911, align 8
  %v4948 = load i64, ptr %slot903, align 8
  %v4949 = load i64, ptr %slot908, align 8
  %cv4950 = trunc i64 %v4949 to i32
  %v4951 = load i32, ptr %slot910, align 8
  %call4952 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64 %v4946, i64 %v4947, i64 %v4948, i32 %cv4950, i32 %v4951) nomerge, !dbg !150
  store i32 %call4952, ptr %slot912, align 8
  %v4953 = load i32, ptr %slot912, align 8
  %cv4954 = zext i32 %v4953 to i64
  %cond4955 = icmp ne i64 %cv4954, 0
  br i1 %cond4955, label %bb_rcsuccess1215, label %bb_rcfailure1215
bb_rcfailure1215:
  %v4956 = load i64, ptr %slot56, align 8
  %p4957 = inttoptr i64 %v4956 to ptr
  %call4958 = call i32 @myl_rc_take_failure(ptr %p4957) nomerge, !dbg !150
  store i32 %call4958, ptr %slot913, align 8
  %v4959 = load i64, ptr %slot1, align 8
  %p4960 = inttoptr i64 %v4959 to ptr
  %v4961 = load i32, ptr %slot913, align 8
  %call4962 = call i32 @myl_qbe_rc_status(ptr %p4960, i32 %v4961) nomerge, !dbg !150
  store i32 %call4962, ptr %slot914, align 8
  br label %bb_failure
bb_rcsuccess1215:
  %v4963 = load i32, ptr %slot907, align 8
  %cv4964 = zext i32 %v4963 to i64
  %cond4965 = icmp ne i64 %cv4964, 0
  br i1 %cond4965, label %bb_rchtaken1218, label %bb_rchcopied1218
bb_rchcopied1218:
  %v4966 = load i64, ptr %slot11, align 8
  %p4967 = inttoptr i64 %v4966 to ptr
  %ld4968 = load i32, ptr %p4967, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4968, ptr %slot915, align 8
  %v4969 = load i32, ptr %slot915, align 8
  %cv4970 = zext i32 %v4969 to i64
  %cond4971 = icmp ne i64 %cv4970, 0
  br i1 %cond4971, label %bb_rcslotdrop1221, label %bb_rcslotdone1221
bb_rcslotdrop1221:
  %v4972 = load i64, ptr %slot11, align 8
  %p4973 = inttoptr i64 %v4972 to ptr
  store i32 0, ptr %p4973, align 4, !alias.scope !3, !noalias !4
  %v4974 = load i64, ptr %slot22, align 8
  store i64 %v4974, ptr %slot916, align 8
  %v4975 = load i64, ptr %slot12, align 8
  %p4976 = inttoptr i64 %v4975 to ptr
  %ld4977 = load i32, ptr %p4976, align 4, !alias.scope !3, !noalias !4
  store i32 %ld4977, ptr %slot917, align 8
  %v4978 = load i32, ptr %slot917, align 8
  %op4979 = and i32 %v4978, 28
  store i32 %op4979, ptr %slot918, align 8
  %v4980 = load i32, ptr %slot918, align 8
  %cv4981 = zext i32 %v4980 to i64
  %cond4982 = icmp ne i64 %cv4981, 0
  br i1 %cond4982, label %bb_rcslotrole1221, label %bb_rcslotowner1221
bb_rcslotrole1221:
  %v4983 = load i64, ptr %slot56, align 8
  store i64 %v4983, ptr %slot919, align 8
  %v4984 = load i64, ptr %slot919, align 8
  %v4985 = load i64, ptr %slot916, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64 %v4984, i64 %v4985) nomerge, !dbg !150
  br label %bb_rcslotdone1221
bb_rcslotowner1221:
  %v4986 = load i64, ptr %slot56, align 8
  store i64 %v4986, ptr %slot920, align 8
  %v4987 = load i64, ptr %slot920, align 8
  %v4988 = load i64, ptr %slot916, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v4987, i64 %v4988) nomerge, !dbg !150
  br label %bb_rcslotdone1221
bb_rcslotdone1221:
  br label %bb_rchprepared1218
bb_rchtaken1218:
  %v4989 = load i64, ptr %slot11, align 8
  %p4990 = inttoptr i64 %v4989 to ptr
  store i32 0, ptr %p4990, align 4, !alias.scope !3, !noalias !4
  br label %bb_rchprepared1218
bb_rchprepared1218:
  %v4991 = load i64, ptr %slot20, align 8
  %p4992 = inttoptr i64 %v4991 to ptr
  store i32 2, ptr %p4992, align 4, !alias.scope !3, !noalias !4
  %v4993 = load i64, ptr %slot19, align 8
  %p4994 = inttoptr i64 %v4993 to ptr
  store i32 1, ptr %p4994, align 4, !alias.scope !3, !noalias !4
  %v4995 = load i64, ptr %slot22, align 8
  store i64 %v4995, ptr %slot921, align 8
  %v4996 = load i64, ptr %slot29, align 8
  store i64 %v4996, ptr %slot922, align 8
  %v4997 = load i64, ptr %slot922, align 8
  %v4998 = load i64, ptr %slot921, align 8
  %p4999 = inttoptr i64 %v4997 to ptr
  %p5000 = inttoptr i64 %v4998 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5000, ptr %p4999, i64 40, i1 false), !alias.scope !3, !noalias !4
  %v5001 = load i64, ptr %slot12, align 8
  %p5002 = inttoptr i64 %v5001 to ptr
  store i32 2, ptr %p5002, align 4, !alias.scope !3, !noalias !4
  %v5003 = load i64, ptr %slot20, align 8
  %p5004 = inttoptr i64 %v5003 to ptr
  %ld5005 = load i32, ptr %p5004, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5005, ptr %slot923, align 8
  %v5006 = load i32, ptr %slot923, align 8
  %v5007 = load i64, ptr %slot12, align 8
  %p5008 = inttoptr i64 %v5007 to ptr
  store i32 %v5006, ptr %p5008, align 4, !alias.scope !3, !noalias !4
  %v5009 = load i64, ptr %slot19, align 8
  %p5010 = inttoptr i64 %v5009 to ptr
  store i32 0, ptr %p5010, align 4, !alias.scope !3, !noalias !4
  %v5011 = load i64, ptr %slot11, align 8
  %p5012 = inttoptr i64 %v5011 to ptr
  store i32 1, ptr %p5012, align 4, !alias.scope !3, !noalias !4
  %v5013 = load i64, ptr %slot921, align 8
  %v5014 = load i64, ptr %slot41, align 8
  %p5015 = inttoptr i64 %v5014 to ptr
  store i64 %v5013, ptr %p5015, align 8, !alias.scope !3, !noalias !4
  %v5016 = load i64, ptr %slot41, align 8
  %p5017 = inttoptr i64 %v5016 to ptr
  %ld5018 = load i64, ptr %p5017, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5018, ptr %slot924, align 8
  %v5019 = load i64, ptr %slot29, align 8
  store i64 %v5019, ptr %slot925, align 8
  %v5020 = load i64, ptr %slot57, align 8
  store i64 %v5020, ptr %slot926, align 8
  %v5021 = load i64, ptr %slot924, align 8
  %op5022 = add i64 %v5021, 0
  store i64 %op5022, ptr %slot927, align 8
  %v5023 = load i64, ptr %slot927, align 8
  %p5024 = inttoptr i64 %v5023 to ptr
  %ld5025 = load i64, ptr %p5024, align 8
  store i64 %ld5025, ptr %slot928, align 8
  %v5026 = load i64, ptr %slot928, align 8
  %cmp5027 = icmp ne i64 %v5026, 0
  %cv5028 = zext i1 %cmp5027 to i32
  store i32 %cv5028, ptr %slot929, align 8
  %v5029 = load i32, ptr %slot929, align 8
  %cv5030 = zext i32 %v5029 to i64
  %cond5031 = icmp ne i64 %cv5030, 0
  br i1 %cond5031, label %bb_rcmoveheader1245, label %bb_rcmovenext1245
bb_rcmoveheader1245:
  %v5032 = load i64, ptr %slot928, align 8
  %op5033 = sub i64 %v5032, 16
  store i64 %op5033, ptr %slot930, align 8
  %v5034 = load i64, ptr %slot928, align 8
  %p5035 = inttoptr i64 %v5034 to ptr
  %rgep5036 = getelementptr i8, ptr %p5035, i64 -16
  %ld5037 = load i64, ptr %rgep5036, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5037, ptr %slot931, align 8
  %v5038 = load i64, ptr %slot931, align 8
  %op5039 = and i64 %v5038, 5764607523034234881
  store i64 %op5039, ptr %slot932, align 8
  %v5040 = load i64, ptr %slot932, align 8
  %cmp5041 = icmp ne i64 %v5040, 0
  %cv5042 = zext i1 %cmp5041 to i32
  store i32 %cv5042, ptr %slot933, align 8
  %v5043 = load i32, ptr %slot933, align 8
  %cv5044 = zext i32 %v5043 to i64
  %cond5045 = icmp ne i64 %cv5044, 0
  br i1 %cond5045, label %bb_rcmoveslow1242, label %bb_rcmovenext1245
bb_rcmovenext1245:
  %v5046 = load i64, ptr %slot924, align 8
  %op5047 = add i64 %v5046, 8
  store i64 %op5047, ptr %slot934, align 8
  %v5048 = load i64, ptr %slot934, align 8
  %p5049 = inttoptr i64 %v5048 to ptr
  %ld5050 = load i64, ptr %p5049, align 8
  store i64 %ld5050, ptr %slot935, align 8
  %v5051 = load i64, ptr %slot935, align 8
  %cmp5052 = icmp ne i64 %v5051, 0
  %cv5053 = zext i1 %cmp5052 to i32
  store i32 %cv5053, ptr %slot936, align 8
  %v5054 = load i32, ptr %slot936, align 8
  %cv5055 = zext i32 %v5054 to i64
  %cond5056 = icmp ne i64 %cv5055, 0
  br i1 %cond5056, label %bb_rcmoveheader1253, label %bb_rcmovenext1253
bb_rcmoveheader1253:
  %v5057 = load i64, ptr %slot935, align 8
  %op5058 = sub i64 %v5057, 16
  store i64 %op5058, ptr %slot937, align 8
  %v5059 = load i64, ptr %slot935, align 8
  %p5060 = inttoptr i64 %v5059 to ptr
  %rgep5061 = getelementptr i8, ptr %p5060, i64 -16
  %ld5062 = load i64, ptr %rgep5061, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5062, ptr %slot938, align 8
  %v5063 = load i64, ptr %slot938, align 8
  %op5064 = and i64 %v5063, 5764607523034234881
  store i64 %op5064, ptr %slot939, align 8
  %v5065 = load i64, ptr %slot939, align 8
  %cmp5066 = icmp ne i64 %v5065, 0
  %cv5067 = zext i1 %cmp5066 to i32
  store i32 %cv5067, ptr %slot940, align 8
  %v5068 = load i32, ptr %slot940, align 8
  %cv5069 = zext i32 %v5068 to i64
  %cond5070 = icmp ne i64 %cv5069, 0
  br i1 %cond5070, label %bb_rcmoveslow1242, label %bb_rcmovenext1253
bb_rcmovenext1253:
  %v5071 = load i64, ptr %slot924, align 8
  %v5072 = load i64, ptr %slot925, align 8
  %p5073 = inttoptr i64 %v5071 to ptr
  %p5074 = inttoptr i64 %v5072 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5074, ptr %p5073, i64 40, i1 false)
  %v5075 = load i64, ptr %slot924, align 8
  %p5076 = inttoptr i64 %v5075 to ptr
  store i64 0, ptr %p5076, align 8
  %v5077 = load i64, ptr %slot924, align 8
  %op5078 = add i64 %v5077, 8
  store i64 %op5078, ptr %slot941, align 8
  %v5079 = load i64, ptr %slot941, align 8
  %p5080 = inttoptr i64 %v5079 to ptr
  store i64 0, ptr %p5080, align 8
  %v5081 = load i64, ptr %slot924, align 8
  %op5082 = add i64 %v5081, 16
  store i64 %op5082, ptr %slot942, align 8
  %v5083 = load i64, ptr %slot942, align 8
  %p5084 = inttoptr i64 %v5083 to ptr
  store i64 0, ptr %p5084, align 8
  %v5085 = load i64, ptr %slot924, align 8
  %op5086 = add i64 %v5085, 24
  store i64 %op5086, ptr %slot943, align 8
  %v5087 = load i64, ptr %slot943, align 8
  %p5088 = inttoptr i64 %v5087 to ptr
  store i64 0, ptr %p5088, align 8
  %v5089 = load i64, ptr %slot924, align 8
  %op5090 = add i64 %v5089, 32
  store i64 %op5090, ptr %slot944, align 8
  %v5091 = load i64, ptr %slot944, align 8
  %p5092 = inttoptr i64 %v5091 to ptr
  store i64 0, ptr %p5092, align 8
  br label %bb_rcmoved1242
bb_rcmoveslow1242:
  %v5093 = load i64, ptr %slot56, align 8
  %v5094 = load i64, ptr %slot925, align 8
  %v5095 = load i64, ptr %slot924, align 8
  %v5096 = load i64, ptr %slot926, align 8
  %cv5097 = trunc i64 %v5096 to i32
  %call5098 = call i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64 %v5093, i64 %v5094, i64 %v5095, i32 %cv5097) nomerge, !dbg !152
  store i32 %call5098, ptr %slot945, align 8
  %v5099 = load i32, ptr %slot945, align 8
  %cv5100 = zext i32 %v5099 to i64
  %cond5101 = icmp ne i64 %cv5100, 0
  br i1 %cond5101, label %bb_rcsuccess1264, label %bb_rcfailure1264
bb_rcfailure1264:
  %v5102 = load i64, ptr %slot56, align 8
  %p5103 = inttoptr i64 %v5102 to ptr
  %call5104 = call i32 @myl_rc_take_failure(ptr %p5103) nomerge, !dbg !152
  store i32 %call5104, ptr %slot946, align 8
  %v5105 = load i64, ptr %slot1, align 8
  %p5106 = inttoptr i64 %v5105 to ptr
  %v5107 = load i32, ptr %slot946, align 8
  %call5108 = call i32 @myl_qbe_rc_status(ptr %p5106, i32 %v5107) nomerge, !dbg !152
  store i32 %call5108, ptr %slot947, align 8
  br label %bb_failure
bb_rcsuccess1264:
  br label %bb_rcmoved1242
bb_rcmoved1242:
  %v5109 = load i64, ptr %slot11, align 8
  %p5110 = inttoptr i64 %v5109 to ptr
  store i32 0, ptr %p5110, align 4, !alias.scope !3, !noalias !4
  %v5111 = load i64, ptr %slot20, align 8
  %p5112 = inttoptr i64 %v5111 to ptr
  store i32 2, ptr %p5112, align 4, !alias.scope !3, !noalias !4
  %v5113 = load i64, ptr %slot19, align 8
  %p5114 = inttoptr i64 %v5113 to ptr
  store i32 1, ptr %p5114, align 4, !alias.scope !3, !noalias !4
  %v5115 = load i64, ptr %slot35, align 8
  %p5116 = inttoptr i64 %v5115 to ptr
  %ld5117 = load i64, ptr %p5116, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5117, ptr %slot948, align 8
  %v5118 = load i64, ptr %slot56, align 8
  store i64 %v5118, ptr %slot949, align 8
  %v5119 = load i64, ptr %slot949, align 8
  %v5120 = load i64, ptr %slot948, align 8
  call void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64 %v5119, i64 %v5120) nomerge, !dbg !152
  %v5121 = load i64, ptr %slot29, align 8
  store i64 %v5121, ptr %slot950, align 8
  %v5122 = load i64, ptr %slot950, align 8
  %v5123 = load i64, ptr %slot948, align 8
  %p5124 = inttoptr i64 %v5122 to ptr
  %p5125 = inttoptr i64 %v5123 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5125, ptr %p5124, i64 40, i1 false), !alias.scope !10000000
  %v5126 = load i64, ptr %slot19, align 8
  %p5127 = inttoptr i64 %v5126 to ptr
  store i32 0, ptr %p5127, align 4, !alias.scope !3, !noalias !4
  %v5128 = load i64, ptr %slot38, align 8
  %v5129 = load i64, ptr %slot41, align 8
  %p5130 = inttoptr i64 %v5129 to ptr
  store i64 %v5128, ptr %p5130, align 8, !alias.scope !3, !noalias !4
  %v5131 = load i64, ptr %slot41, align 8
  %p5132 = inttoptr i64 %v5131 to ptr
  %ld5133 = load i64, ptr %p5132, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5133, ptr %slot951, align 8
  %v5134 = load i64, ptr %slot951, align 8
  %op5135 = add i64 %v5134, 272
  store i64 %op5135, ptr %slot952, align 8
  %v5136 = load i64, ptr %slot952, align 8
  %p5137 = inttoptr i64 %v5136 to ptr
  %ld5138 = load i8, ptr %p5137, align 1
  %ext5139 = zext i8 %ld5138 to i64
  store i64 %ext5139, ptr %slot953, align 8
  %v5140 = load i64, ptr %slot953, align 8
  %v5141 = load i64, ptr %slot41, align 8
  %p5142 = inttoptr i64 %v5141 to ptr
  store i64 %v5140, ptr %p5142, align 8, !alias.scope !3, !noalias !4
  %v5143 = load i64, ptr %slot11, align 8
  %p5144 = inttoptr i64 %v5143 to ptr
  %ld5145 = load i32, ptr %p5144, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5145, ptr %slot954, align 8
  %v5146 = load i32, ptr %slot954, align 8
  %cv5147 = zext i32 %v5146 to i64
  %cond5148 = icmp ne i64 %cv5147, 0
  br i1 %cond5148, label %bb_rcslotdrop1279, label %bb_rcslotdone1279
bb_rcslotdrop1279:
  %v5149 = load i64, ptr %slot11, align 8
  %p5150 = inttoptr i64 %v5149 to ptr
  store i32 0, ptr %p5150, align 4, !alias.scope !3, !noalias !4
  %v5151 = load i64, ptr %slot22, align 8
  store i64 %v5151, ptr %slot955, align 8
  %v5152 = load i64, ptr %slot12, align 8
  %p5153 = inttoptr i64 %v5152 to ptr
  %ld5154 = load i32, ptr %p5153, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5154, ptr %slot956, align 8
  %v5155 = load i32, ptr %slot956, align 8
  %op5156 = and i32 %v5155, 28
  store i32 %op5156, ptr %slot957, align 8
  %v5157 = load i32, ptr %slot957, align 8
  %cv5158 = zext i32 %v5157 to i64
  %cond5159 = icmp ne i64 %cv5158, 0
  br i1 %cond5159, label %bb_rcslotrole1279, label %bb_rcslotowner1279
bb_rcslotrole1279:
  %v5160 = load i64, ptr %slot56, align 8
  store i64 %v5160, ptr %slot958, align 8
  %v5161 = load i64, ptr %slot958, align 8
  %v5162 = load i64, ptr %slot955, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v5161, i64 %v5162) nomerge, !dbg !154
  br label %bb_rcslotdone1279
bb_rcslotowner1279:
  %v5163 = load i64, ptr %slot56, align 8
  store i64 %v5163, ptr %slot959, align 8
  %v5164 = load i64, ptr %slot959, align 8
  %v5165 = load i64, ptr %slot955, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v5164, i64 %v5165) nomerge, !dbg !154
  br label %bb_rcslotdone1279
bb_rcslotdone1279:
  %v5166 = load i64, ptr %slot41, align 8
  %p5167 = inttoptr i64 %v5166 to ptr
  %ld5168 = load i64, ptr %p5167, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5168, ptr %slot960, align 8
  %v5169 = load i64, ptr %slot960, align 8
  %cond5170 = icmp ne i64 %v5169, 0
  br i1 %cond5170, label %bb_next1287, label %bb_i48
bb_next1287:
  %v5171 = load i64, ptr %slot49, align 8
  store i64 %v5171, ptr %slot961, align 8
  %v5172 = load i64, ptr %slot961, align 8
  %p5173 = inttoptr i64 %v5172 to ptr
  store i64 0, ptr %p5173, align 8, !alias.scope !3, !noalias !4
  %v5174 = load i64, ptr %slot961, align 8
  %p5176 = inttoptr i64 %v5174 to ptr
  %gep5177 = getelementptr i8, ptr %p5176, i64 8
  %op5175 = ptrtoint ptr %gep5177 to i64
  store i64 %op5175, ptr %slot962, align 8
  %v5178 = load i64, ptr %slot962, align 8
  %p5179 = inttoptr i64 %v5178 to ptr
  store i64 0, ptr %p5179, align 8, !alias.scope !3, !noalias !4
  %v5180 = load i64, ptr %slot961, align 8
  %p5182 = inttoptr i64 %v5180 to ptr
  %gep5183 = getelementptr i8, ptr %p5182, i64 16
  %op5181 = ptrtoint ptr %gep5183 to i64
  store i64 %op5181, ptr %slot963, align 8
  %v5184 = load i64, ptr %slot963, align 8
  %p5185 = inttoptr i64 %v5184 to ptr
  store i64 0, ptr %p5185, align 8, !alias.scope !3, !noalias !4
  %v5186 = load i64, ptr %slot961, align 8
  %p5188 = inttoptr i64 %v5186 to ptr
  %gep5189 = getelementptr i8, ptr %p5188, i64 24
  %op5187 = ptrtoint ptr %gep5189 to i64
  store i64 %op5187, ptr %slot964, align 8
  %v5190 = load i64, ptr %slot964, align 8
  %p5191 = inttoptr i64 %v5190 to ptr
  store i64 0, ptr %p5191, align 8, !alias.scope !3, !noalias !4
  %v5192 = load i64, ptr %slot961, align 8
  %p5194 = inttoptr i64 %v5192 to ptr
  %gep5195 = getelementptr i8, ptr %p5194, i64 32
  %op5193 = ptrtoint ptr %gep5195 to i64
  store i64 %op5193, ptr %slot965, align 8
  %v5196 = load i64, ptr %slot965, align 8
  %p5197 = inttoptr i64 %v5196 to ptr
  store i64 0, ptr %p5197, align 8, !alias.scope !3, !noalias !4
  %v5198 = load i64, ptr %slot961, align 8
  %p5199 = inttoptr i64 %v5198 to ptr
  store i32 0, ptr %p5199, align 4, !alias.scope !3, !noalias !4
  %v5200 = load i64, ptr %slot961, align 8
  %v5201 = load i64, ptr %slot41, align 8
  %p5202 = inttoptr i64 %v5201 to ptr
  store i64 %v5200, ptr %p5202, align 8, !alias.scope !3, !noalias !4
  %v5203 = load i64, ptr %slot41, align 8
  %p5204 = inttoptr i64 %v5203 to ptr
  %ld5205 = load i64, ptr %p5204, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5205, ptr %slot966, align 8
  %v5206 = load i64, ptr %slot22, align 8
  store i64 %v5206, ptr %slot967, align 8
  %v5207 = load i64, ptr %slot966, align 8
  %v5208 = load i64, ptr %slot967, align 8
  %p5209 = inttoptr i64 %v5207 to ptr
  %p5210 = inttoptr i64 %v5208 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5210, ptr %p5209, i64 40, i1 false)
  %v5211 = load i64, ptr %slot12, align 8
  %p5212 = inttoptr i64 %v5211 to ptr
  store i32 2, ptr %p5212, align 4, !alias.scope !3, !noalias !4
  %v5213 = load i64, ptr %slot11, align 8
  %p5214 = inttoptr i64 %v5213 to ptr
  store i32 1, ptr %p5214, align 4, !alias.scope !3, !noalias !4
  %v5215 = load i64, ptr %slot967, align 8
  %v5216 = load i64, ptr %slot41, align 8
  %p5217 = inttoptr i64 %v5216 to ptr
  store i64 %v5215, ptr %p5217, align 8, !alias.scope !3, !noalias !4
  %v5218 = load i64, ptr %slot41, align 8
  %p5219 = inttoptr i64 %v5218 to ptr
  %ld5220 = load i64, ptr %p5219, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5220, ptr %slot968, align 8
  %v5221 = load i64, ptr %slot41, align 8
  %p5222 = inttoptr i64 %v5221 to ptr
  %ld5223 = load i64, ptr %p5222, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5223, ptr %slot969, align 8
  %v5224 = load i64, ptr %slot29, align 8
  store i64 %v5224, ptr %slot970, align 8
  %v5225 = load i64, ptr %slot57, align 8
  store i64 %v5225, ptr %slot971, align 8
  %v5226 = load i64, ptr %slot56, align 8
  %v5227 = load i64, ptr %slot970, align 8
  %v5228 = load i64, ptr %slot969, align 8
  %v5229 = load i64, ptr %slot971, align 8
  %cv5230 = trunc i64 %v5229 to i32
  %call5231 = call i32 @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_take(i64 %v5226, i64 %v5227, i64 %v5228, i32 %cv5230) nomerge, !dbg !156
  store i32 %call5231, ptr %slot972, align 8
  %v5232 = load i32, ptr %slot972, align 8
  %cv5233 = zext i32 %v5232 to i64
  %cond5234 = icmp ne i64 %cv5233, 0
  br i1 %cond5234, label %bb_rcsuccess1301, label %bb_rcfailure1301
bb_rcfailure1301:
  %v5235 = load i64, ptr %slot56, align 8
  %p5236 = inttoptr i64 %v5235 to ptr
  %call5237 = call i32 @myl_rc_take_failure(ptr %p5236) nomerge, !dbg !156
  store i32 %call5237, ptr %slot973, align 8
  %v5238 = load i64, ptr %slot1, align 8
  %p5239 = inttoptr i64 %v5238 to ptr
  %v5240 = load i32, ptr %slot973, align 8
  %call5241 = call i32 @myl_qbe_rc_status(ptr %p5239, i32 %v5240) nomerge, !dbg !156
  store i32 %call5241, ptr %slot974, align 8
  br label %bb_failure
bb_rcsuccess1301:
  %v5242 = load i64, ptr %slot11, align 8
  %p5243 = inttoptr i64 %v5242 to ptr
  store i32 0, ptr %p5243, align 4, !alias.scope !3, !noalias !4
  %v5244 = load i64, ptr %slot20, align 8
  %p5245 = inttoptr i64 %v5244 to ptr
  store i32 2, ptr %p5245, align 4, !alias.scope !3, !noalias !4
  %v5246 = load i64, ptr %slot19, align 8
  %p5247 = inttoptr i64 %v5246 to ptr
  store i32 1, ptr %p5247, align 4, !alias.scope !3, !noalias !4
  %v5248 = load i64, ptr %slot29, align 8
  store i64 %v5248, ptr %slot975, align 8
  %v5249 = load i64, ptr %slot19, align 8
  %p5250 = inttoptr i64 %v5249 to ptr
  store i32 0, ptr %p5250, align 4, !alias.scope !3, !noalias !4
  %v5251 = load i64, ptr %slot31, align 8
  %p5253 = inttoptr i64 %v5251 to ptr
  %gep5254 = getelementptr i8, ptr %p5253, i64 24
  %op5252 = ptrtoint ptr %gep5254 to i64
  store i64 %op5252, ptr %slot976, align 8
  %v5255 = load i64, ptr %slot976, align 8
  %p5256 = inttoptr i64 %v5255 to ptr
  %ld5257 = load i32, ptr %p5256, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5257, ptr %slot977, align 8
  %v5258 = load i32, ptr %slot977, align 8
  %cv5259 = zext i32 %v5258 to i64
  %cond5260 = icmp ne i64 %cv5259, 0
  br i1 %cond5260, label %bb_rcscopesopen1311, label %bb_rcscopesclosed1311
bb_rcscopesopen1311:
  %v5261 = load i64, ptr %slot33, align 8
  %p5263 = inttoptr i64 %v5261 to ptr
  %gep5264 = getelementptr i8, ptr %p5263, i64 0
  %op5262 = ptrtoint ptr %gep5264 to i64
  store i64 %op5262, ptr %slot978, align 8
  %v5265 = load i64, ptr %slot31, align 8
  %v5266 = load i64, ptr %slot978, align 8
  %p5267 = inttoptr i64 %v5266 to ptr
  store i64 %v5265, ptr %p5267, align 8, !alias.scope !3, !noalias !4
  %v5268 = load i64, ptr %slot1, align 8
  %p5269 = inttoptr i64 %v5268 to ptr
  %v5270 = load i64, ptr %slot33, align 8
  %p5271 = inttoptr i64 %v5270 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p5269, ptr %p5271, i64 1) nomerge, !dbg !156
  br label %bb_rcscopesclosed1311
bb_rcscopesclosed1311:
  %v5272 = load i64, ptr %slot11, align 8
  %p5273 = inttoptr i64 %v5272 to ptr
  %ld5274 = load i32, ptr %p5273, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5274, ptr %slot979, align 8
  %v5275 = load i32, ptr %slot979, align 8
  %cv5276 = zext i32 %v5275 to i64
  %cond5277 = icmp ne i64 %cv5276, 0
  br i1 %cond5277, label %bb_rcslotdrop1315, label %bb_rcslotdone1315
bb_rcslotdrop1315:
  %v5278 = load i64, ptr %slot11, align 8
  %p5279 = inttoptr i64 %v5278 to ptr
  store i32 0, ptr %p5279, align 4, !alias.scope !3, !noalias !4
  %v5280 = load i64, ptr %slot22, align 8
  store i64 %v5280, ptr %slot980, align 8
  %v5281 = load i64, ptr %slot12, align 8
  %p5282 = inttoptr i64 %v5281 to ptr
  %ld5283 = load i32, ptr %p5282, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5283, ptr %slot981, align 8
  %v5284 = load i32, ptr %slot981, align 8
  %op5285 = and i32 %v5284, 28
  store i32 %op5285, ptr %slot982, align 8
  %v5286 = load i32, ptr %slot982, align 8
  %cv5287 = zext i32 %v5286 to i64
  %cond5288 = icmp ne i64 %cv5287, 0
  br i1 %cond5288, label %bb_rcslotrole1315, label %bb_rcslotowner1315
bb_rcslotrole1315:
  %v5289 = load i64, ptr %slot56, align 8
  store i64 %v5289, ptr %slot983, align 8
  %v5290 = load i64, ptr %slot983, align 8
  %v5291 = load i64, ptr %slot980, align 8
  call void @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_unloan(i64 %v5290, i64 %v5291) nomerge, !dbg !156
  br label %bb_rcslotdone1315
bb_rcslotowner1315:
  %v5292 = load i64, ptr %slot56, align 8
  store i64 %v5292, ptr %slot984, align 8
  %v5293 = load i64, ptr %slot984, align 8
  %v5294 = load i64, ptr %slot980, align 8
  call void @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_drop(i64 %v5293, i64 %v5294) nomerge, !dbg !156
  br label %bb_rcslotdone1315
bb_rcslotdone1315:
  %v5295 = load i64, ptr %slot9, align 8
  %p5296 = inttoptr i64 %v5295 to ptr
  %ld5297 = load i32, ptr %p5296, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5297, ptr %slot985, align 8
  %v5298 = load i32, ptr %slot985, align 8
  %cv5299 = zext i32 %v5298 to i64
  %cond5300 = icmp ne i64 %cv5299, 0
  br i1 %cond5300, label %bb_rcslotdrop1361, label %bb_rcslotdone1361
bb_rcslotdrop1361:
  %v5301 = load i64, ptr %slot9, align 8
  %p5302 = inttoptr i64 %v5301 to ptr
  store i32 0, ptr %p5302, align 4, !alias.scope !3, !noalias !4
  %v5303 = load i64, ptr %slot38, align 8
  store i64 %v5303, ptr %slot986, align 8
  %v5304 = load i64, ptr %slot10, align 8
  %p5305 = inttoptr i64 %v5304 to ptr
  %ld5306 = load i32, ptr %p5305, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5306, ptr %slot987, align 8
  %v5307 = load i32, ptr %slot987, align 8
  %op5308 = and i32 %v5307, 28
  store i32 %op5308, ptr %slot988, align 8
  %v5309 = load i32, ptr %slot988, align 8
  %cv5310 = zext i32 %v5309 to i64
  %cond5311 = icmp ne i64 %cv5310, 0
  br i1 %cond5311, label %bb_rcslotrole1361, label %bb_rcslotowner1361
bb_rcslotrole1361:
  %v5312 = load i64, ptr %slot56, align 8
  store i64 %v5312, ptr %slot989, align 8
  %v5313 = load i64, ptr %slot989, align 8
  %v5314 = load i64, ptr %slot986, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v5313, i64 %v5314) nomerge, !dbg !156
  br label %bb_rcslotdone1361
bb_rcslotowner1361:
  %v5315 = load i64, ptr %slot56, align 8
  store i64 %v5315, ptr %slot990, align 8
  %v5316 = load i64, ptr %slot990, align 8
  %v5317 = load i64, ptr %slot986, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v5316, i64 %v5317) nomerge, !dbg !156
  br label %bb_rcslotdone1361
bb_rcslotdone1361:
  %v5318 = load i64, ptr %slot7, align 8
  %p5319 = inttoptr i64 %v5318 to ptr
  %ld5320 = load i32, ptr %p5319, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5320, ptr %slot991, align 8
  %v5321 = load i32, ptr %slot991, align 8
  %cv5322 = zext i32 %v5321 to i64
  %cond5323 = icmp ne i64 %cv5322, 0
  br i1 %cond5323, label %bb_rcslotdrop1370, label %bb_rcslotdone1370
bb_rcslotdrop1370:
  %v5324 = load i64, ptr %slot7, align 8
  %p5325 = inttoptr i64 %v5324 to ptr
  store i32 0, ptr %p5325, align 4, !alias.scope !3, !noalias !4
  %v5326 = load i64, ptr %slot37, align 8
  store i64 %v5326, ptr %slot992, align 8
  %v5327 = load i64, ptr %slot8, align 8
  %p5328 = inttoptr i64 %v5327 to ptr
  %ld5329 = load i32, ptr %p5328, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5329, ptr %slot993, align 8
  %v5330 = load i32, ptr %slot993, align 8
  %op5331 = and i32 %v5330, 28
  store i32 %op5331, ptr %slot994, align 8
  %v5332 = load i32, ptr %slot994, align 8
  %cv5333 = zext i32 %v5332 to i64
  %cond5334 = icmp ne i64 %cv5333, 0
  br i1 %cond5334, label %bb_rcslotrole1370, label %bb_rcslotowner1370
bb_rcslotrole1370:
  %v5335 = load i64, ptr %slot56, align 8
  store i64 %v5335, ptr %slot995, align 8
  %v5336 = load i64, ptr %slot992, align 8
  %p5337 = inttoptr i64 %v5336 to ptr
  %ld5338 = load i64, ptr %p5337, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5338, ptr %slot996, align 8
  %v5339 = load i64, ptr %slot996, align 8
  %cmp5340 = icmp ne i64 %v5339, 0
  %cv5341 = zext i1 %cmp5340 to i32
  store i32 %cv5341, ptr %slot997, align 8
  %v5342 = load i32, ptr %slot997, align 8
  %cv5343 = zext i32 %v5342 to i64
  %cond5344 = icmp ne i64 %cv5343, 0
  br i1 %cond5344, label %bb_rcgnn1386, label %bb_rcgdone1386
bb_rcgnn1386:
  %v5345 = load i64, ptr %slot996, align 8
  %op5346 = sub i64 %v5345, 16
  store i64 %op5346, ptr %slot998, align 8
  %v5347 = load i64, ptr %slot996, align 8
  %p5348 = inttoptr i64 %v5347 to ptr
  %rgep5349 = getelementptr i8, ptr %p5348, i64 -16
  %ld5350 = load i64, ptr %rgep5349, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5350, ptr %slot999, align 8
  %v5351 = load i64, ptr %slot999, align 8
  %op5352 = and i64 %v5351, 4611686018427387906
  store i64 %op5352, ptr %slot1000, align 8
  %v5353 = load i64, ptr %slot1000, align 8
  %cmp5354 = icmp ne i64 %v5353, 0
  %cv5355 = zext i1 %cmp5354 to i32
  store i32 %cv5355, ptr %slot1001, align 8
  %v5356 = load i32, ptr %slot1001, align 8
  %cv5357 = zext i32 %v5356 to i64
  %cond5358 = icmp ne i64 %cv5357, 0
  br i1 %cond5358, label %bb_rcgclear1386, label %bb_rcgcounted1386
bb_rcgcounted1386:
  %v5359 = load i64, ptr %slot996, align 8
  %op5360 = sub i64 %v5359, 24
  store i64 %op5360, ptr %slot1002, align 8
  %v5361 = load i64, ptr %slot996, align 8
  %p5362 = inttoptr i64 %v5361 to ptr
  %rgep5363 = getelementptr i8, ptr %p5362, i64 -24
  %ld5364 = load i64, ptr %rgep5363, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5364, ptr %slot1003, align 8
  %v5365 = load i64, ptr %slot1003, align 8
  %op5366 = sub i64 %v5365, 1
  store i64 %op5366, ptr %slot1004, align 8
  %v5367 = load i64, ptr %slot1004, align 8
  %cmp5368 = icmp eq i64 %v5367, 0
  %cv5369 = zext i1 %cmp5368 to i32
  store i32 %cv5369, ptr %slot1005, align 8
  %v5370 = load i32, ptr %slot1005, align 8
  %cv5371 = zext i32 %v5370 to i64
  %cond5372 = icmp ne i64 %cv5371, 0
  br i1 %cond5372, label %bb_rcglast1386, label %bb_rcgdec1386
bb_rcglast1386:
  %v5373 = load i64, ptr %slot996, align 8
  %op5374 = sub i64 %v5373, 32
  store i64 %op5374, ptr %slot1006, align 8
  %v5375 = load i64, ptr %slot996, align 8
  %p5376 = inttoptr i64 %v5375 to ptr
  %rgep5377 = getelementptr i8, ptr %p5376, i64 -32
  %ld5378 = load i64, ptr %rgep5377, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5378, ptr %slot1007, align 8
  %v5379 = load i64, ptr %slot1007, align 8
  %cmp5380 = icmp ne i64 %v5379, 0
  %cv5381 = zext i1 %cmp5380 to i32
  store i32 %cv5381, ptr %slot1008, align 8
  %v5382 = load i32, ptr %slot1008, align 8
  %cv5383 = zext i32 %v5382 to i64
  %cond5384 = icmp ne i64 %cv5383, 0
  br i1 %cond5384, label %bb_rcgdec1386, label %bb_rcgslow1386
bb_rcgslow1386:
  %v5385 = load i64, ptr %slot995, align 8
  %v5386 = load i64, ptr %slot992, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64 %v5385, i64 %v5386) nomerge, !dbg !156
  br label %bb_rcgdone1386
bb_rcgdec1386:
  %v5387 = load i64, ptr %slot1004, align 8
  %v5388 = load i64, ptr %slot996, align 8
  %p5389 = inttoptr i64 %v5388 to ptr
  %rgep5390 = getelementptr i8, ptr %p5389, i64 -24
  store i64 %v5387, ptr %rgep5390, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1386
bb_rcgclear1386:
  %v5391 = load i64, ptr %slot992, align 8
  %p5392 = inttoptr i64 %v5391 to ptr
  store i64 0, ptr %p5392, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1386
bb_rcgdone1386:
  br label %bb_rcslotdone1370
bb_rcslotowner1370:
  %v5393 = load i64, ptr %slot56, align 8
  store i64 %v5393, ptr %slot1009, align 8
  %v5394 = load i64, ptr %slot992, align 8
  %p5395 = inttoptr i64 %v5394 to ptr
  %ld5396 = load i64, ptr %p5395, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5396, ptr %slot1010, align 8
  %v5397 = load i64, ptr %slot1010, align 8
  %cmp5398 = icmp ne i64 %v5397, 0
  %cv5399 = zext i1 %cmp5398 to i32
  store i32 %cv5399, ptr %slot1011, align 8
  %v5400 = load i32, ptr %slot1011, align 8
  %cv5401 = zext i32 %v5400 to i64
  %cond5402 = icmp ne i64 %cv5401, 0
  br i1 %cond5402, label %bb_rcgnn1401, label %bb_rcgdone1401
bb_rcgnn1401:
  %v5403 = load i64, ptr %slot1010, align 8
  %op5404 = sub i64 %v5403, 16
  store i64 %op5404, ptr %slot1012, align 8
  %v5405 = load i64, ptr %slot1010, align 8
  %p5406 = inttoptr i64 %v5405 to ptr
  %rgep5407 = getelementptr i8, ptr %p5406, i64 -16
  %ld5408 = load i64, ptr %rgep5407, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5408, ptr %slot1013, align 8
  %v5409 = load i64, ptr %slot1013, align 8
  %op5410 = and i64 %v5409, 4611686018427387906
  store i64 %op5410, ptr %slot1014, align 8
  %v5411 = load i64, ptr %slot1014, align 8
  %cmp5412 = icmp ne i64 %v5411, 0
  %cv5413 = zext i1 %cmp5412 to i32
  store i32 %cv5413, ptr %slot1015, align 8
  %v5414 = load i32, ptr %slot1015, align 8
  %cv5415 = zext i32 %v5414 to i64
  %cond5416 = icmp ne i64 %cv5415, 0
  br i1 %cond5416, label %bb_rcgclear1401, label %bb_rcgcounted1401
bb_rcgcounted1401:
  %v5417 = load i64, ptr %slot1010, align 8
  %op5418 = sub i64 %v5417, 32
  store i64 %op5418, ptr %slot1016, align 8
  %v5419 = load i64, ptr %slot1010, align 8
  %p5420 = inttoptr i64 %v5419 to ptr
  %rgep5421 = getelementptr i8, ptr %p5420, i64 -32
  %ld5422 = load i64, ptr %rgep5421, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5422, ptr %slot1017, align 8
  %v5423 = load i64, ptr %slot1017, align 8
  %op5424 = sub i64 %v5423, 1
  store i64 %op5424, ptr %slot1018, align 8
  %v5425 = load i64, ptr %slot1018, align 8
  %cmp5426 = icmp eq i64 %v5425, 0
  %cv5427 = zext i1 %cmp5426 to i32
  store i32 %cv5427, ptr %slot1019, align 8
  %v5428 = load i32, ptr %slot1019, align 8
  %cv5429 = zext i32 %v5428 to i64
  %cond5430 = icmp ne i64 %cv5429, 0
  br i1 %cond5430, label %bb_rcglast1401, label %bb_rcgdec1401
bb_rcglast1401:
  %v5431 = load i64, ptr %slot1010, align 8
  %op5432 = sub i64 %v5431, 24
  store i64 %op5432, ptr %slot1020, align 8
  %v5433 = load i64, ptr %slot1010, align 8
  %p5434 = inttoptr i64 %v5433 to ptr
  %rgep5435 = getelementptr i8, ptr %p5434, i64 -24
  %ld5436 = load i64, ptr %rgep5435, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5436, ptr %slot1021, align 8
  %v5437 = load i64, ptr %slot1021, align 8
  %cmp5438 = icmp ne i64 %v5437, 0
  %cv5439 = zext i1 %cmp5438 to i32
  store i32 %cv5439, ptr %slot1022, align 8
  %v5440 = load i32, ptr %slot1022, align 8
  %cv5441 = zext i32 %v5440 to i64
  %cond5442 = icmp ne i64 %cv5441, 0
  br i1 %cond5442, label %bb_rcgdec1401, label %bb_rcgslow1401
bb_rcgslow1401:
  %v5443 = load i64, ptr %slot1009, align 8
  %v5444 = load i64, ptr %slot992, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64 %v5443, i64 %v5444) nomerge, !dbg !156
  br label %bb_rcgdone1401
bb_rcgdec1401:
  %v5445 = load i64, ptr %slot1018, align 8
  %v5446 = load i64, ptr %slot1010, align 8
  %p5447 = inttoptr i64 %v5446 to ptr
  %rgep5448 = getelementptr i8, ptr %p5447, i64 -32
  store i64 %v5445, ptr %rgep5448, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1401
bb_rcgclear1401:
  %v5449 = load i64, ptr %slot992, align 8
  %p5450 = inttoptr i64 %v5449 to ptr
  store i64 0, ptr %p5450, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1401
bb_rcgdone1401:
  br label %bb_rcslotdone1370
bb_rcslotdone1370:
  %v5451 = load i64, ptr %slot975, align 8
  %p5452 = inttoptr i64 %v5451 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p5452, i64 40, i1 false)
  ret void
bb_i48:
  %v5453 = load i64, ptr %slot38, align 8
  %v5454 = load i64, ptr %slot50, align 8
  %p5455 = inttoptr i64 %v5453 to ptr
  %p5456 = inttoptr i64 %v5454 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5456, ptr %p5455, i64 312, i1 false), !alias.scope !3, !noalias !4
  %v5457 = load i64, ptr %slot50, align 8
  %v5458 = load i64, ptr %slot41, align 8
  %p5459 = inttoptr i64 %v5458 to ptr
  store i64 %v5457, ptr %p5459, align 8, !alias.scope !3, !noalias !4
  %v5460 = load i64, ptr %slot41, align 8
  %p5461 = inttoptr i64 %v5460 to ptr
  %ld5462 = load i64, ptr %p5461, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5462, ptr %slot1023, align 8
  %v5463 = load i64, ptr %slot1023, align 8
  %op5464 = add i64 %v5463, 280
  store i64 %op5464, ptr %slot1024, align 8
  %v5465 = load i64, ptr %slot1024, align 8
  %v5466 = load i64, ptr %slot41, align 8
  %p5467 = inttoptr i64 %v5466 to ptr
  store i64 %v5465, ptr %p5467, align 8, !alias.scope !3, !noalias !4
  %v5468 = load i64, ptr %slot41, align 8
  %p5469 = inttoptr i64 %v5468 to ptr
  %ld5470 = load i64, ptr %p5469, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5470, ptr %slot1025, align 8
  %v5471 = load i64, ptr %slot29, align 8
  store i64 %v5471, ptr %slot1026, align 8
  %v5472 = load i64, ptr %slot56, align 8
  %v5473 = load i64, ptr %slot1026, align 8
  %v5474 = load i64, ptr %slot1025, align 8
  %call5475 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_loan(i64 %v5472, i64 %v5473, i64 %v5474) nomerge, !dbg !158
  store i32 %call5475, ptr %slot1027, align 8
  %v5476 = load i32, ptr %slot1027, align 8
  %cv5477 = zext i32 %v5476 to i64
  %cond5478 = icmp ne i64 %cv5477, 0
  br i1 %cond5478, label %bb_rcsuccess1465, label %bb_rcfailure1465
bb_rcfailure1465:
  %v5479 = load i64, ptr %slot56, align 8
  %p5480 = inttoptr i64 %v5479 to ptr
  %call5481 = call i32 @myl_rc_take_failure(ptr %p5480) nomerge, !dbg !158
  store i32 %call5481, ptr %slot1028, align 8
  %v5482 = load i64, ptr %slot1, align 8
  %p5483 = inttoptr i64 %v5482 to ptr
  %v5484 = load i32, ptr %slot1028, align 8
  %call5485 = call i32 @myl_qbe_rc_status(ptr %p5483, i32 %v5484) nomerge, !dbg !158
  store i32 %call5485, ptr %slot1029, align 8
  br label %bb_failure
bb_rcsuccess1465:
  %v5486 = load i64, ptr %slot20, align 8
  %p5487 = inttoptr i64 %v5486 to ptr
  store i32 2, ptr %p5487, align 4, !alias.scope !3, !noalias !4
  %v5488 = load i64, ptr %slot20, align 8
  %p5489 = inttoptr i64 %v5488 to ptr
  store i32 16, ptr %p5489, align 4, !alias.scope !3, !noalias !4
  %v5490 = load i64, ptr %slot19, align 8
  %p5491 = inttoptr i64 %v5490 to ptr
  store i32 1, ptr %p5491, align 4, !alias.scope !3, !noalias !4
  %v5492 = load i64, ptr %slot11, align 8
  %p5493 = inttoptr i64 %v5492 to ptr
  %ld5494 = load i32, ptr %p5493, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5494, ptr %slot1030, align 8
  %v5495 = load i32, ptr %slot1030, align 8
  %cv5496 = zext i32 %v5495 to i64
  %cond5497 = icmp ne i64 %cv5496, 0
  br i1 %cond5497, label %bb_rcslotdrop1473, label %bb_rcslotdone1473
bb_rcslotdrop1473:
  %v5498 = load i64, ptr %slot11, align 8
  %p5499 = inttoptr i64 %v5498 to ptr
  store i32 0, ptr %p5499, align 4, !alias.scope !3, !noalias !4
  %v5500 = load i64, ptr %slot22, align 8
  store i64 %v5500, ptr %slot1031, align 8
  %v5501 = load i64, ptr %slot12, align 8
  %p5502 = inttoptr i64 %v5501 to ptr
  %ld5503 = load i32, ptr %p5502, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5503, ptr %slot1032, align 8
  %v5504 = load i32, ptr %slot1032, align 8
  %op5505 = and i32 %v5504, 28
  store i32 %op5505, ptr %slot1033, align 8
  %v5506 = load i32, ptr %slot1033, align 8
  %cv5507 = zext i32 %v5506 to i64
  %cond5508 = icmp ne i64 %cv5507, 0
  br i1 %cond5508, label %bb_rcslotrole1473, label %bb_rcslotowner1473
bb_rcslotrole1473:
  %v5509 = load i64, ptr %slot56, align 8
  store i64 %v5509, ptr %slot1034, align 8
  %v5510 = load i64, ptr %slot1034, align 8
  %v5511 = load i64, ptr %slot1031, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v5510, i64 %v5511) nomerge, !dbg !158
  br label %bb_rcslotdone1473
bb_rcslotowner1473:
  %v5512 = load i64, ptr %slot56, align 8
  store i64 %v5512, ptr %slot1035, align 8
  %v5513 = load i64, ptr %slot1035, align 8
  %v5514 = load i64, ptr %slot1031, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v5513, i64 %v5514) nomerge, !dbg !158
  br label %bb_rcslotdone1473
bb_rcslotdone1473:
  %v5515 = load i64, ptr %slot22, align 8
  store i64 %v5515, ptr %slot1036, align 8
  %v5516 = load i64, ptr %slot29, align 8
  store i64 %v5516, ptr %slot1037, align 8
  %v5517 = load i64, ptr %slot1037, align 8
  %v5518 = load i64, ptr %slot1036, align 8
  %p5519 = inttoptr i64 %v5517 to ptr
  %p5520 = inttoptr i64 %v5518 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5520, ptr %p5519, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v5521 = load i64, ptr %slot12, align 8
  %p5522 = inttoptr i64 %v5521 to ptr
  store i32 2, ptr %p5522, align 4, !alias.scope !3, !noalias !4
  %v5523 = load i64, ptr %slot20, align 8
  %p5524 = inttoptr i64 %v5523 to ptr
  %ld5525 = load i32, ptr %p5524, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5525, ptr %slot1038, align 8
  %v5526 = load i32, ptr %slot1038, align 8
  %v5527 = load i64, ptr %slot12, align 8
  %p5528 = inttoptr i64 %v5527 to ptr
  store i32 %v5526, ptr %p5528, align 4, !alias.scope !3, !noalias !4
  %v5529 = load i64, ptr %slot19, align 8
  %p5530 = inttoptr i64 %v5529 to ptr
  store i32 0, ptr %p5530, align 4, !alias.scope !3, !noalias !4
  %v5531 = load i64, ptr %slot11, align 8
  %p5532 = inttoptr i64 %v5531 to ptr
  store i32 1, ptr %p5532, align 4, !alias.scope !3, !noalias !4
  %v5533 = load i64, ptr %slot1036, align 8
  %v5534 = load i64, ptr %slot41, align 8
  %p5535 = inttoptr i64 %v5534 to ptr
  store i64 %v5533, ptr %p5535, align 8, !alias.scope !3, !noalias !4
  %v5536 = load i64, ptr %slot51, align 8
  store i64 %v5536, ptr %slot1039, align 8
  %v5537 = load i64, ptr %slot1039, align 8
  %p5538 = inttoptr i64 %v5537 to ptr
  store i64 0, ptr %p5538, align 8, !alias.scope !3, !noalias !4
  %v5539 = load i64, ptr %slot1039, align 8
  %p5541 = inttoptr i64 %v5539 to ptr
  %gep5542 = getelementptr i8, ptr %p5541, i64 8
  %op5540 = ptrtoint ptr %gep5542 to i64
  store i64 %op5540, ptr %slot1040, align 8
  %v5543 = load i64, ptr %slot1040, align 8
  %p5544 = inttoptr i64 %v5543 to ptr
  store i64 0, ptr %p5544, align 8, !alias.scope !3, !noalias !4
  %v5545 = load i64, ptr %slot1039, align 8
  %p5547 = inttoptr i64 %v5545 to ptr
  %gep5548 = getelementptr i8, ptr %p5547, i64 16
  %op5546 = ptrtoint ptr %gep5548 to i64
  store i64 %op5546, ptr %slot1041, align 8
  %v5549 = load i64, ptr %slot1041, align 8
  %p5550 = inttoptr i64 %v5549 to ptr
  store i64 0, ptr %p5550, align 8, !alias.scope !3, !noalias !4
  %v5551 = load i64, ptr %slot1039, align 8
  %p5553 = inttoptr i64 %v5551 to ptr
  %gep5554 = getelementptr i8, ptr %p5553, i64 24
  %op5552 = ptrtoint ptr %gep5554 to i64
  store i64 %op5552, ptr %slot1042, align 8
  %v5555 = load i64, ptr %slot1042, align 8
  %p5556 = inttoptr i64 %v5555 to ptr
  store i64 0, ptr %p5556, align 8, !alias.scope !3, !noalias !4
  %v5557 = load i64, ptr %slot1039, align 8
  %p5559 = inttoptr i64 %v5557 to ptr
  %gep5560 = getelementptr i8, ptr %p5559, i64 32
  %op5558 = ptrtoint ptr %gep5560 to i64
  store i64 %op5558, ptr %slot1043, align 8
  %v5561 = load i64, ptr %slot1043, align 8
  %p5562 = inttoptr i64 %v5561 to ptr
  store i64 0, ptr %p5562, align 8, !alias.scope !3, !noalias !4
  %v5563 = load i64, ptr %slot1039, align 8
  %p5564 = inttoptr i64 %v5563 to ptr
  store i32 1, ptr %p5564, align 4, !alias.scope !3, !noalias !4
  %v5565 = load i64, ptr %slot21, align 8
  %p5566 = inttoptr i64 %v5565 to ptr
  store i32 1, ptr %p5566, align 4, !alias.scope !3, !noalias !4
  %v5567 = load i64, ptr %slot41, align 8
  %p5568 = inttoptr i64 %v5567 to ptr
  %ld5569 = load i64, ptr %p5568, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5569, ptr %slot1044, align 8
  %v5570 = load i64, ptr %slot1039, align 8
  %p5572 = inttoptr i64 %v5570 to ptr
  %gep5573 = getelementptr i8, ptr %p5572, i64 8
  %op5571 = ptrtoint ptr %gep5573 to i64
  store i64 %op5571, ptr %slot1045, align 8
  %v5574 = load i64, ptr %slot57, align 8
  store i64 %v5574, ptr %slot1046, align 8
  %v5575 = load i64, ptr %slot41, align 8
  %p5576 = inttoptr i64 %v5575 to ptr
  %ld5577 = load i64, ptr %p5576, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5577, ptr %slot1047, align 8
  %v5578 = load i64, ptr %slot11, align 8
  %p5579 = inttoptr i64 %v5578 to ptr
  %ld5580 = load i32, ptr %p5579, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5580, ptr %slot1048, align 8
  %v5581 = load i64, ptr %slot12, align 8
  %p5582 = inttoptr i64 %v5581 to ptr
  %ld5583 = load i32, ptr %p5582, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5583, ptr %slot1049, align 8
  %v5584 = load i32, ptr %slot1049, align 8
  %op5585 = and i32 %v5584, 24
  store i32 %op5585, ptr %slot1049, align 8
  %v5586 = load i32, ptr %slot1049, align 8
  %cmp5587 = icmp eq i32 %v5586, 0
  %cv5588 = zext i1 %cmp5587 to i32
  store i32 %cv5588, ptr %slot1050, align 8
  %v5589 = load i32, ptr %slot1048, align 8
  %v5590 = load i32, ptr %slot1050, align 8
  %op5591 = and i32 %v5589, %v5590
  store i32 %op5591, ptr %slot1051, align 8
  %v5592 = load i32, ptr %slot1051, align 8
  %cv5593 = zext i32 %v5592 to i64
  %cond5594 = icmp ne i64 %cv5593, 0
  br i1 %cond5594, label %bb_rctake1499, label %bb_rccopy1499
bb_rctake1499:
  %v5595 = load i64, ptr %slot29, align 8
  store i64 %v5595, ptr %slot1052, align 8
  %v5596 = load i64, ptr %slot57, align 8
  store i64 %v5596, ptr %slot1053, align 8
  %v5597 = load i64, ptr %slot1047, align 8
  %v5598 = load i64, ptr %slot1052, align 8
  %op5599 = sub i64 %v5597, %v5598
  store i64 %op5599, ptr %slot1054, align 8
  %v5600 = load i64, ptr %slot1052, align 8
  %v5601 = load i64, ptr %slot1047, align 8
  %op5602 = sub i64 %v5600, %v5601
  store i64 %op5602, ptr %slot1055, align 8
  %v5603 = load i64, ptr %slot1054, align 8
  %cmp5604 = icmp ult i64 %v5603, 32
  %cv5605 = zext i1 %cmp5604 to i32
  store i32 %cv5605, ptr %slot1056, align 8
  %v5606 = load i64, ptr %slot1055, align 8
  %cmp5607 = icmp ult i64 %v5606, 32
  %cv5608 = zext i1 %cmp5607 to i32
  store i32 %cv5608, ptr %slot1057, align 8
  %v5609 = load i32, ptr %slot1056, align 8
  %v5610 = load i32, ptr %slot1057, align 8
  %op5611 = or i32 %v5609, %v5610
  store i32 %op5611, ptr %slot1058, align 8
  %v5612 = load i32, ptr %slot1058, align 8
  %cv5613 = zext i32 %v5612 to i64
  %cond5614 = icmp ne i64 %cv5613, 0
  br i1 %cond5614, label %bb_rcmoveslow1508, label %bb_rcmovecheck1508
bb_rcmovecheck1508:
  %v5615 = load i64, ptr %slot1047, align 8
  %op5616 = add i64 %v5615, 0
  store i64 %op5616, ptr %slot1059, align 8
  %v5617 = load i64, ptr %slot1059, align 8
  %p5618 = inttoptr i64 %v5617 to ptr
  %ld5619 = load i64, ptr %p5618, align 8
  store i64 %ld5619, ptr %slot1060, align 8
  %v5620 = load i64, ptr %slot1060, align 8
  %cmp5621 = icmp ne i64 %v5620, 0
  %cv5622 = zext i1 %cmp5621 to i32
  store i32 %cv5622, ptr %slot1061, align 8
  %v5623 = load i32, ptr %slot1061, align 8
  %cv5624 = zext i32 %v5623 to i64
  %cond5625 = icmp ne i64 %cv5624, 0
  br i1 %cond5625, label %bb_rcmoveheader1516, label %bb_rcmovenext1516
bb_rcmoveheader1516:
  %v5626 = load i64, ptr %slot1060, align 8
  %op5627 = sub i64 %v5626, 16
  store i64 %op5627, ptr %slot1062, align 8
  %v5628 = load i64, ptr %slot1060, align 8
  %p5629 = inttoptr i64 %v5628 to ptr
  %rgep5630 = getelementptr i8, ptr %p5629, i64 -16
  %ld5631 = load i64, ptr %rgep5630, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5631, ptr %slot1063, align 8
  %v5632 = load i64, ptr %slot1063, align 8
  %op5633 = and i64 %v5632, 5764607523034234881
  store i64 %op5633, ptr %slot1064, align 8
  %v5634 = load i64, ptr %slot1064, align 8
  %cmp5635 = icmp ne i64 %v5634, 0
  %cv5636 = zext i1 %cmp5635 to i32
  store i32 %cv5636, ptr %slot1065, align 8
  %v5637 = load i32, ptr %slot1065, align 8
  %cv5638 = zext i32 %v5637 to i64
  %cond5639 = icmp ne i64 %cv5638, 0
  br i1 %cond5639, label %bb_rcmoveslow1508, label %bb_rcmovenext1516
bb_rcmovenext1516:
  %v5640 = load i64, ptr %slot1047, align 8
  %op5641 = add i64 %v5640, 8
  store i64 %op5641, ptr %slot1066, align 8
  %v5642 = load i64, ptr %slot1066, align 8
  %p5643 = inttoptr i64 %v5642 to ptr
  %ld5644 = load i64, ptr %p5643, align 8
  store i64 %ld5644, ptr %slot1067, align 8
  %v5645 = load i64, ptr %slot1067, align 8
  %cmp5646 = icmp ne i64 %v5645, 0
  %cv5647 = zext i1 %cmp5646 to i32
  store i32 %cv5647, ptr %slot1068, align 8
  %v5648 = load i32, ptr %slot1068, align 8
  %cv5649 = zext i32 %v5648 to i64
  %cond5650 = icmp ne i64 %cv5649, 0
  br i1 %cond5650, label %bb_rcmoveheader1524, label %bb_rcmovenext1524
bb_rcmoveheader1524:
  %v5651 = load i64, ptr %slot1067, align 8
  %op5652 = sub i64 %v5651, 16
  store i64 %op5652, ptr %slot1069, align 8
  %v5653 = load i64, ptr %slot1067, align 8
  %p5654 = inttoptr i64 %v5653 to ptr
  %rgep5655 = getelementptr i8, ptr %p5654, i64 -16
  %ld5656 = load i64, ptr %rgep5655, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5656, ptr %slot1070, align 8
  %v5657 = load i64, ptr %slot1070, align 8
  %op5658 = and i64 %v5657, 5764607523034234881
  store i64 %op5658, ptr %slot1071, align 8
  %v5659 = load i64, ptr %slot1071, align 8
  %cmp5660 = icmp ne i64 %v5659, 0
  %cv5661 = zext i1 %cmp5660 to i32
  store i32 %cv5661, ptr %slot1072, align 8
  %v5662 = load i32, ptr %slot1072, align 8
  %cv5663 = zext i32 %v5662 to i64
  %cond5664 = icmp ne i64 %cv5663, 0
  br i1 %cond5664, label %bb_rcmoveslow1508, label %bb_rcmovenext1524
bb_rcmovenext1524:
  %v5665 = load i64, ptr %slot1047, align 8
  %op5666 = add i64 %v5665, 16
  store i64 %op5666, ptr %slot1073, align 8
  %v5667 = load i64, ptr %slot1073, align 8
  %p5668 = inttoptr i64 %v5667 to ptr
  %ld5669 = load i64, ptr %p5668, align 8
  store i64 %ld5669, ptr %slot1074, align 8
  %v5670 = load i64, ptr %slot1074, align 8
  %cmp5671 = icmp ne i64 %v5670, 0
  %cv5672 = zext i1 %cmp5671 to i32
  store i32 %cv5672, ptr %slot1075, align 8
  %v5673 = load i32, ptr %slot1075, align 8
  %cv5674 = zext i32 %v5673 to i64
  %cond5675 = icmp ne i64 %cv5674, 0
  br i1 %cond5675, label %bb_rcmoveheader1532, label %bb_rcmovenext1532
bb_rcmoveheader1532:
  %v5676 = load i64, ptr %slot1074, align 8
  %op5677 = sub i64 %v5676, 16
  store i64 %op5677, ptr %slot1076, align 8
  %v5678 = load i64, ptr %slot1074, align 8
  %p5679 = inttoptr i64 %v5678 to ptr
  %rgep5680 = getelementptr i8, ptr %p5679, i64 -16
  %ld5681 = load i64, ptr %rgep5680, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5681, ptr %slot1077, align 8
  %v5682 = load i64, ptr %slot1077, align 8
  %op5683 = and i64 %v5682, 5764607523034234881
  store i64 %op5683, ptr %slot1078, align 8
  %v5684 = load i64, ptr %slot1078, align 8
  %cmp5685 = icmp ne i64 %v5684, 0
  %cv5686 = zext i1 %cmp5685 to i32
  store i32 %cv5686, ptr %slot1079, align 8
  %v5687 = load i32, ptr %slot1079, align 8
  %cv5688 = zext i32 %v5687 to i64
  %cond5689 = icmp ne i64 %cv5688, 0
  br i1 %cond5689, label %bb_rcmoveslow1508, label %bb_rcmovenext1532
bb_rcmovenext1532:
  %v5690 = load i64, ptr %slot1047, align 8
  %op5691 = add i64 %v5690, 24
  store i64 %op5691, ptr %slot1080, align 8
  %v5692 = load i64, ptr %slot1080, align 8
  %p5693 = inttoptr i64 %v5692 to ptr
  %ld5694 = load i64, ptr %p5693, align 8
  store i64 %ld5694, ptr %slot1081, align 8
  %v5695 = load i64, ptr %slot1081, align 8
  %cmp5696 = icmp ne i64 %v5695, 0
  %cv5697 = zext i1 %cmp5696 to i32
  store i32 %cv5697, ptr %slot1082, align 8
  %v5698 = load i32, ptr %slot1082, align 8
  %cv5699 = zext i32 %v5698 to i64
  %cond5700 = icmp ne i64 %cv5699, 0
  br i1 %cond5700, label %bb_rcmoveheader1540, label %bb_rcmovenext1540
bb_rcmoveheader1540:
  %v5701 = load i64, ptr %slot1081, align 8
  %op5702 = sub i64 %v5701, 16
  store i64 %op5702, ptr %slot1083, align 8
  %v5703 = load i64, ptr %slot1081, align 8
  %p5704 = inttoptr i64 %v5703 to ptr
  %rgep5705 = getelementptr i8, ptr %p5704, i64 -16
  %ld5706 = load i64, ptr %rgep5705, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5706, ptr %slot1084, align 8
  %v5707 = load i64, ptr %slot1084, align 8
  %op5708 = and i64 %v5707, 5764607523034234881
  store i64 %op5708, ptr %slot1085, align 8
  %v5709 = load i64, ptr %slot1085, align 8
  %cmp5710 = icmp ne i64 %v5709, 0
  %cv5711 = zext i1 %cmp5710 to i32
  store i32 %cv5711, ptr %slot1086, align 8
  %v5712 = load i32, ptr %slot1086, align 8
  %cv5713 = zext i32 %v5712 to i64
  %cond5714 = icmp ne i64 %cv5713, 0
  br i1 %cond5714, label %bb_rcmoveslow1508, label %bb_rcmovenext1540
bb_rcmovenext1540:
  %v5715 = load i64, ptr %slot1047, align 8
  %v5716 = load i64, ptr %slot1052, align 8
  %p5717 = inttoptr i64 %v5715 to ptr
  %p5718 = inttoptr i64 %v5716 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5718, ptr %p5717, i64 32, i1 false)
  %v5719 = load i64, ptr %slot1047, align 8
  %p5720 = inttoptr i64 %v5719 to ptr
  store i64 0, ptr %p5720, align 8
  %v5721 = load i64, ptr %slot1047, align 8
  %op5722 = add i64 %v5721, 8
  store i64 %op5722, ptr %slot1087, align 8
  %v5723 = load i64, ptr %slot1087, align 8
  %p5724 = inttoptr i64 %v5723 to ptr
  store i64 0, ptr %p5724, align 8
  %v5725 = load i64, ptr %slot1047, align 8
  %op5726 = add i64 %v5725, 16
  store i64 %op5726, ptr %slot1088, align 8
  %v5727 = load i64, ptr %slot1088, align 8
  %p5728 = inttoptr i64 %v5727 to ptr
  store i64 0, ptr %p5728, align 8
  %v5729 = load i64, ptr %slot1047, align 8
  %op5730 = add i64 %v5729, 24
  store i64 %op5730, ptr %slot1089, align 8
  %v5731 = load i64, ptr %slot1089, align 8
  %p5732 = inttoptr i64 %v5731 to ptr
  store i64 0, ptr %p5732, align 8
  br label %bb_rcmoved1508
bb_rcmoveslow1508:
  %v5733 = load i64, ptr %slot56, align 8
  %v5734 = load i64, ptr %slot1052, align 8
  %v5735 = load i64, ptr %slot1047, align 8
  %v5736 = load i64, ptr %slot1053, align 8
  %cv5737 = trunc i64 %v5736 to i32
  %call5738 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_take(i64 %v5733, i64 %v5734, i64 %v5735, i32 %cv5737) nomerge, !dbg !160
  store i32 %call5738, ptr %slot1090, align 8
  %v5739 = load i32, ptr %slot1090, align 8
  %cv5740 = zext i32 %v5739 to i64
  %cond5741 = icmp ne i64 %cv5740, 0
  br i1 %cond5741, label %bb_rcsuccess1550, label %bb_rcfailure1550
bb_rcfailure1550:
  %v5742 = load i64, ptr %slot56, align 8
  %p5743 = inttoptr i64 %v5742 to ptr
  %call5744 = call i32 @myl_rc_take_failure(ptr %p5743) nomerge, !dbg !160
  store i32 %call5744, ptr %slot1091, align 8
  %v5745 = load i64, ptr %slot1, align 8
  %p5746 = inttoptr i64 %v5745 to ptr
  %v5747 = load i32, ptr %slot1091, align 8
  %call5748 = call i32 @myl_qbe_rc_status(ptr %p5746, i32 %v5747) nomerge, !dbg !160
  store i32 %call5748, ptr %slot1092, align 8
  br label %bb_failure
bb_rcsuccess1550:
  br label %bb_rcmoved1508
bb_rcmoved1508:
  %v5749 = load i64, ptr %slot11, align 8
  %p5750 = inttoptr i64 %v5749 to ptr
  store i32 0, ptr %p5750, align 4, !alias.scope !3, !noalias !4
  %v5751 = load i64, ptr %slot20, align 8
  %p5752 = inttoptr i64 %v5751 to ptr
  store i32 2, ptr %p5752, align 4, !alias.scope !3, !noalias !4
  %v5753 = load i64, ptr %slot19, align 8
  %p5754 = inttoptr i64 %v5753 to ptr
  store i32 1, ptr %p5754, align 4, !alias.scope !3, !noalias !4
  br label %bb_rcprepared1499
bb_rccopy1499:
  %v5755 = load i64, ptr %slot29, align 8
  store i64 %v5755, ptr %slot1093, align 8
  %v5756 = load i64, ptr %slot57, align 8
  store i64 %v5756, ptr %slot1094, align 8
  %v5757 = load i64, ptr %slot56, align 8
  %v5758 = load i64, ptr %slot1093, align 8
  %v5759 = load i64, ptr %slot1047, align 8
  %v5760 = load i64, ptr %slot1094, align 8
  %cv5761 = trunc i64 %v5760 to i32
  %call5762 = call i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_retain(i64 %v5757, i64 %v5758, i64 %v5759, i32 %cv5761) nomerge, !dbg !160
  store i32 %call5762, ptr %slot1095, align 8
  %v5763 = load i32, ptr %slot1095, align 8
  %cv5764 = zext i32 %v5763 to i64
  %cond5765 = icmp ne i64 %cv5764, 0
  br i1 %cond5765, label %bb_rcsuccess1559, label %bb_rcfailure1559
bb_rcfailure1559:
  %v5766 = load i64, ptr %slot56, align 8
  %p5767 = inttoptr i64 %v5766 to ptr
  %call5768 = call i32 @myl_rc_take_failure(ptr %p5767) nomerge, !dbg !160
  store i32 %call5768, ptr %slot1096, align 8
  %v5769 = load i64, ptr %slot1, align 8
  %p5770 = inttoptr i64 %v5769 to ptr
  %v5771 = load i32, ptr %slot1096, align 8
  %call5772 = call i32 @myl_qbe_rc_status(ptr %p5770, i32 %v5771) nomerge, !dbg !160
  store i32 %call5772, ptr %slot1097, align 8
  br label %bb_failure
bb_rcsuccess1559:
  %v5773 = load i64, ptr %slot20, align 8
  %p5774 = inttoptr i64 %v5773 to ptr
  store i32 2, ptr %p5774, align 4, !alias.scope !3, !noalias !4
  %v5775 = load i64, ptr %slot19, align 8
  %p5776 = inttoptr i64 %v5775 to ptr
  store i32 1, ptr %p5776, align 4, !alias.scope !3, !noalias !4
  %v5777 = load i64, ptr %slot11, align 8
  %p5778 = inttoptr i64 %v5777 to ptr
  %ld5779 = load i32, ptr %p5778, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5779, ptr %slot1098, align 8
  %v5780 = load i32, ptr %slot1098, align 8
  %cv5781 = zext i32 %v5780 to i64
  %cond5782 = icmp ne i64 %cv5781, 0
  br i1 %cond5782, label %bb_rcslotdrop1566, label %bb_rcslotdone1566
bb_rcslotdrop1566:
  %v5783 = load i64, ptr %slot11, align 8
  %p5784 = inttoptr i64 %v5783 to ptr
  store i32 0, ptr %p5784, align 4, !alias.scope !3, !noalias !4
  %v5785 = load i64, ptr %slot22, align 8
  store i64 %v5785, ptr %slot1099, align 8
  %v5786 = load i64, ptr %slot12, align 8
  %p5787 = inttoptr i64 %v5786 to ptr
  %ld5788 = load i32, ptr %p5787, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5788, ptr %slot1100, align 8
  %v5789 = load i32, ptr %slot1100, align 8
  %op5790 = and i32 %v5789, 28
  store i32 %op5790, ptr %slot1101, align 8
  %v5791 = load i32, ptr %slot1101, align 8
  %cv5792 = zext i32 %v5791 to i64
  %cond5793 = icmp ne i64 %cv5792, 0
  br i1 %cond5793, label %bb_rcslotrole1566, label %bb_rcslotowner1566
bb_rcslotrole1566:
  %v5794 = load i64, ptr %slot56, align 8
  store i64 %v5794, ptr %slot1102, align 8
  %v5795 = load i64, ptr %slot1102, align 8
  %v5796 = load i64, ptr %slot1099, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64 %v5795, i64 %v5796) nomerge, !dbg !160
  br label %bb_rcslotdone1566
bb_rcslotowner1566:
  %v5797 = load i64, ptr %slot56, align 8
  store i64 %v5797, ptr %slot1103, align 8
  %v5798 = load i64, ptr %slot1103, align 8
  %v5799 = load i64, ptr %slot1099, align 8
  call void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64 %v5798, i64 %v5799) nomerge, !dbg !160
  br label %bb_rcslotdone1566
bb_rcslotdone1566:
  br label %bb_rcprepared1499
bb_rcprepared1499:
  %v5800 = load i64, ptr %slot29, align 8
  store i64 %v5800, ptr %slot1104, align 8
  %v5801 = load i64, ptr %slot1104, align 8
  %v5802 = load i64, ptr %slot1045, align 8
  %p5803 = inttoptr i64 %v5801 to ptr
  %p5804 = inttoptr i64 %v5802 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5804, ptr %p5803, i64 32, i1 false), !alias.scope !3, !noalias !4
  %v5805 = load i64, ptr %slot19, align 8
  %p5806 = inttoptr i64 %v5805 to ptr
  store i32 0, ptr %p5806, align 4, !alias.scope !3, !noalias !4
  %v5807 = load i64, ptr %slot1039, align 8
  %v5808 = load i64, ptr %slot41, align 8
  %p5809 = inttoptr i64 %v5808 to ptr
  store i64 %v5807, ptr %p5809, align 8, !alias.scope !3, !noalias !4
  %v5810 = load i64, ptr %slot41, align 8
  %p5811 = inttoptr i64 %v5810 to ptr
  %ld5812 = load i64, ptr %p5811, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5812, ptr %slot1105, align 8
  %v5813 = load i64, ptr %slot22, align 8
  store i64 %v5813, ptr %slot1106, align 8
  %v5814 = load i64, ptr %slot1105, align 8
  %v5815 = load i64, ptr %slot1106, align 8
  %p5816 = inttoptr i64 %v5814 to ptr
  %p5817 = inttoptr i64 %v5815 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p5817, ptr %p5816, i64 40, i1 false)
  %v5818 = load i64, ptr %slot12, align 8
  %p5819 = inttoptr i64 %v5818 to ptr
  store i32 2, ptr %p5819, align 4, !alias.scope !3, !noalias !4
  %v5820 = load i64, ptr %slot11, align 8
  %p5821 = inttoptr i64 %v5820 to ptr
  store i32 1, ptr %p5821, align 4, !alias.scope !3, !noalias !4
  %v5822 = load i64, ptr %slot1106, align 8
  %v5823 = load i64, ptr %slot41, align 8
  %p5824 = inttoptr i64 %v5823 to ptr
  store i64 %v5822, ptr %p5824, align 8, !alias.scope !3, !noalias !4
  %v5825 = load i64, ptr %slot41, align 8
  %p5826 = inttoptr i64 %v5825 to ptr
  %ld5827 = load i64, ptr %p5826, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5827, ptr %slot1107, align 8
  %v5828 = load i64, ptr %slot41, align 8
  %p5829 = inttoptr i64 %v5828 to ptr
  %ld5830 = load i64, ptr %p5829, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5830, ptr %slot1108, align 8
  %v5831 = load i64, ptr %slot29, align 8
  store i64 %v5831, ptr %slot1109, align 8
  %v5832 = load i64, ptr %slot57, align 8
  store i64 %v5832, ptr %slot1110, align 8
  %v5833 = load i64, ptr %slot56, align 8
  %v5834 = load i64, ptr %slot1109, align 8
  %v5835 = load i64, ptr %slot1108, align 8
  %v5836 = load i64, ptr %slot1110, align 8
  %cv5837 = trunc i64 %v5836 to i32
  %call5838 = call i32 @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_take(i64 %v5833, i64 %v5834, i64 %v5835, i32 %cv5837) nomerge, !dbg !162
  store i32 %call5838, ptr %slot1111, align 8
  %v5839 = load i32, ptr %slot1111, align 8
  %cv5840 = zext i32 %v5839 to i64
  %cond5841 = icmp ne i64 %cv5840, 0
  br i1 %cond5841, label %bb_rcsuccess1584, label %bb_rcfailure1584
bb_rcfailure1584:
  %v5842 = load i64, ptr %slot56, align 8
  %p5843 = inttoptr i64 %v5842 to ptr
  %call5844 = call i32 @myl_rc_take_failure(ptr %p5843) nomerge, !dbg !162
  store i32 %call5844, ptr %slot1112, align 8
  %v5845 = load i64, ptr %slot1, align 8
  %p5846 = inttoptr i64 %v5845 to ptr
  %v5847 = load i32, ptr %slot1112, align 8
  %call5848 = call i32 @myl_qbe_rc_status(ptr %p5846, i32 %v5847) nomerge, !dbg !162
  store i32 %call5848, ptr %slot1113, align 8
  br label %bb_failure
bb_rcsuccess1584:
  %v5849 = load i64, ptr %slot11, align 8
  %p5850 = inttoptr i64 %v5849 to ptr
  store i32 0, ptr %p5850, align 4, !alias.scope !3, !noalias !4
  %v5851 = load i64, ptr %slot20, align 8
  %p5852 = inttoptr i64 %v5851 to ptr
  store i32 2, ptr %p5852, align 4, !alias.scope !3, !noalias !4
  %v5853 = load i64, ptr %slot19, align 8
  %p5854 = inttoptr i64 %v5853 to ptr
  store i32 1, ptr %p5854, align 4, !alias.scope !3, !noalias !4
  %v5855 = load i64, ptr %slot29, align 8
  store i64 %v5855, ptr %slot1114, align 8
  %v5856 = load i64, ptr %slot19, align 8
  %p5857 = inttoptr i64 %v5856 to ptr
  store i32 0, ptr %p5857, align 4, !alias.scope !3, !noalias !4
  %v5858 = load i64, ptr %slot31, align 8
  %p5860 = inttoptr i64 %v5858 to ptr
  %gep5861 = getelementptr i8, ptr %p5860, i64 24
  %op5859 = ptrtoint ptr %gep5861 to i64
  store i64 %op5859, ptr %slot1115, align 8
  %v5862 = load i64, ptr %slot1115, align 8
  %p5863 = inttoptr i64 %v5862 to ptr
  %ld5864 = load i32, ptr %p5863, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5864, ptr %slot1116, align 8
  %v5865 = load i32, ptr %slot1116, align 8
  %cv5866 = zext i32 %v5865 to i64
  %cond5867 = icmp ne i64 %cv5866, 0
  br i1 %cond5867, label %bb_rcscopesopen1594, label %bb_rcscopesclosed1594
bb_rcscopesopen1594:
  %v5868 = load i64, ptr %slot33, align 8
  %p5870 = inttoptr i64 %v5868 to ptr
  %gep5871 = getelementptr i8, ptr %p5870, i64 0
  %op5869 = ptrtoint ptr %gep5871 to i64
  store i64 %op5869, ptr %slot1117, align 8
  %v5872 = load i64, ptr %slot31, align 8
  %v5873 = load i64, ptr %slot1117, align 8
  %p5874 = inttoptr i64 %v5873 to ptr
  store i64 %v5872, ptr %p5874, align 8, !alias.scope !3, !noalias !4
  %v5875 = load i64, ptr %slot1, align 8
  %p5876 = inttoptr i64 %v5875 to ptr
  %v5877 = load i64, ptr %slot33, align 8
  %p5878 = inttoptr i64 %v5877 to ptr
  call void @myl_qbe_rc_scopes_close(ptr %p5876, ptr %p5878, i64 1) nomerge, !dbg !162
  br label %bb_rcscopesclosed1594
bb_rcscopesclosed1594:
  %v5879 = load i64, ptr %slot11, align 8
  %p5880 = inttoptr i64 %v5879 to ptr
  %ld5881 = load i32, ptr %p5880, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5881, ptr %slot1118, align 8
  %v5882 = load i32, ptr %slot1118, align 8
  %cv5883 = zext i32 %v5882 to i64
  %cond5884 = icmp ne i64 %cv5883, 0
  br i1 %cond5884, label %bb_rcslotdrop1598, label %bb_rcslotdone1598
bb_rcslotdrop1598:
  %v5885 = load i64, ptr %slot11, align 8
  %p5886 = inttoptr i64 %v5885 to ptr
  store i32 0, ptr %p5886, align 4, !alias.scope !3, !noalias !4
  %v5887 = load i64, ptr %slot22, align 8
  store i64 %v5887, ptr %slot1119, align 8
  %v5888 = load i64, ptr %slot12, align 8
  %p5889 = inttoptr i64 %v5888 to ptr
  %ld5890 = load i32, ptr %p5889, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5890, ptr %slot1120, align 8
  %v5891 = load i32, ptr %slot1120, align 8
  %op5892 = and i32 %v5891, 28
  store i32 %op5892, ptr %slot1121, align 8
  %v5893 = load i32, ptr %slot1121, align 8
  %cv5894 = zext i32 %v5893 to i64
  %cond5895 = icmp ne i64 %cv5894, 0
  br i1 %cond5895, label %bb_rcslotrole1598, label %bb_rcslotowner1598
bb_rcslotrole1598:
  %v5896 = load i64, ptr %slot56, align 8
  store i64 %v5896, ptr %slot1122, align 8
  %v5897 = load i64, ptr %slot1122, align 8
  %v5898 = load i64, ptr %slot1119, align 8
  call void @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_unloan(i64 %v5897, i64 %v5898) nomerge, !dbg !162
  br label %bb_rcslotdone1598
bb_rcslotowner1598:
  %v5899 = load i64, ptr %slot56, align 8
  store i64 %v5899, ptr %slot1123, align 8
  %v5900 = load i64, ptr %slot1123, align 8
  %v5901 = load i64, ptr %slot1119, align 8
  call void @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_drop(i64 %v5900, i64 %v5901) nomerge, !dbg !162
  br label %bb_rcslotdone1598
bb_rcslotdone1598:
  %v5902 = load i64, ptr %slot9, align 8
  %p5903 = inttoptr i64 %v5902 to ptr
  %ld5904 = load i32, ptr %p5903, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5904, ptr %slot1124, align 8
  %v5905 = load i32, ptr %slot1124, align 8
  %cv5906 = zext i32 %v5905 to i64
  %cond5907 = icmp ne i64 %cv5906, 0
  br i1 %cond5907, label %bb_rcslotdrop1644, label %bb_rcslotdone1644
bb_rcslotdrop1644:
  %v5908 = load i64, ptr %slot9, align 8
  %p5909 = inttoptr i64 %v5908 to ptr
  store i32 0, ptr %p5909, align 4, !alias.scope !3, !noalias !4
  %v5910 = load i64, ptr %slot38, align 8
  store i64 %v5910, ptr %slot1125, align 8
  %v5911 = load i64, ptr %slot10, align 8
  %p5912 = inttoptr i64 %v5911 to ptr
  %ld5913 = load i32, ptr %p5912, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5913, ptr %slot1126, align 8
  %v5914 = load i32, ptr %slot1126, align 8
  %op5915 = and i32 %v5914, 28
  store i32 %op5915, ptr %slot1127, align 8
  %v5916 = load i32, ptr %slot1127, align 8
  %cv5917 = zext i32 %v5916 to i64
  %cond5918 = icmp ne i64 %cv5917, 0
  br i1 %cond5918, label %bb_rcslotrole1644, label %bb_rcslotowner1644
bb_rcslotrole1644:
  %v5919 = load i64, ptr %slot56, align 8
  store i64 %v5919, ptr %slot1128, align 8
  %v5920 = load i64, ptr %slot1128, align 8
  %v5921 = load i64, ptr %slot1125, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64 %v5920, i64 %v5921) nomerge, !dbg !162
  br label %bb_rcslotdone1644
bb_rcslotowner1644:
  %v5922 = load i64, ptr %slot56, align 8
  store i64 %v5922, ptr %slot1129, align 8
  %v5923 = load i64, ptr %slot1129, align 8
  %v5924 = load i64, ptr %slot1125, align 8
  call void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64 %v5923, i64 %v5924) nomerge, !dbg !162
  br label %bb_rcslotdone1644
bb_rcslotdone1644:
  %v5925 = load i64, ptr %slot7, align 8
  %p5926 = inttoptr i64 %v5925 to ptr
  %ld5927 = load i32, ptr %p5926, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5927, ptr %slot1130, align 8
  %v5928 = load i32, ptr %slot1130, align 8
  %cv5929 = zext i32 %v5928 to i64
  %cond5930 = icmp ne i64 %cv5929, 0
  br i1 %cond5930, label %bb_rcslotdrop1653, label %bb_rcslotdone1653
bb_rcslotdrop1653:
  %v5931 = load i64, ptr %slot7, align 8
  %p5932 = inttoptr i64 %v5931 to ptr
  store i32 0, ptr %p5932, align 4, !alias.scope !3, !noalias !4
  %v5933 = load i64, ptr %slot37, align 8
  store i64 %v5933, ptr %slot1131, align 8
  %v5934 = load i64, ptr %slot8, align 8
  %p5935 = inttoptr i64 %v5934 to ptr
  %ld5936 = load i32, ptr %p5935, align 4, !alias.scope !3, !noalias !4
  store i32 %ld5936, ptr %slot1132, align 8
  %v5937 = load i32, ptr %slot1132, align 8
  %op5938 = and i32 %v5937, 28
  store i32 %op5938, ptr %slot1133, align 8
  %v5939 = load i32, ptr %slot1133, align 8
  %cv5940 = zext i32 %v5939 to i64
  %cond5941 = icmp ne i64 %cv5940, 0
  br i1 %cond5941, label %bb_rcslotrole1653, label %bb_rcslotowner1653
bb_rcslotrole1653:
  %v5942 = load i64, ptr %slot56, align 8
  store i64 %v5942, ptr %slot1134, align 8
  %v5943 = load i64, ptr %slot1131, align 8
  %p5944 = inttoptr i64 %v5943 to ptr
  %ld5945 = load i64, ptr %p5944, align 8, !alias.scope !3, !noalias !4
  store i64 %ld5945, ptr %slot1135, align 8
  %v5946 = load i64, ptr %slot1135, align 8
  %cmp5947 = icmp ne i64 %v5946, 0
  %cv5948 = zext i1 %cmp5947 to i32
  store i32 %cv5948, ptr %slot1136, align 8
  %v5949 = load i32, ptr %slot1136, align 8
  %cv5950 = zext i32 %v5949 to i64
  %cond5951 = icmp ne i64 %cv5950, 0
  br i1 %cond5951, label %bb_rcgnn1669, label %bb_rcgdone1669
bb_rcgnn1669:
  %v5952 = load i64, ptr %slot1135, align 8
  %op5953 = sub i64 %v5952, 16
  store i64 %op5953, ptr %slot1137, align 8
  %v5954 = load i64, ptr %slot1135, align 8
  %p5955 = inttoptr i64 %v5954 to ptr
  %rgep5956 = getelementptr i8, ptr %p5955, i64 -16
  %ld5957 = load i64, ptr %rgep5956, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5957, ptr %slot1138, align 8
  %v5958 = load i64, ptr %slot1138, align 8
  %op5959 = and i64 %v5958, 4611686018427387906
  store i64 %op5959, ptr %slot1139, align 8
  %v5960 = load i64, ptr %slot1139, align 8
  %cmp5961 = icmp ne i64 %v5960, 0
  %cv5962 = zext i1 %cmp5961 to i32
  store i32 %cv5962, ptr %slot1140, align 8
  %v5963 = load i32, ptr %slot1140, align 8
  %cv5964 = zext i32 %v5963 to i64
  %cond5965 = icmp ne i64 %cv5964, 0
  br i1 %cond5965, label %bb_rcgclear1669, label %bb_rcgcounted1669
bb_rcgcounted1669:
  %v5966 = load i64, ptr %slot1135, align 8
  %op5967 = sub i64 %v5966, 24
  store i64 %op5967, ptr %slot1141, align 8
  %v5968 = load i64, ptr %slot1135, align 8
  %p5969 = inttoptr i64 %v5968 to ptr
  %rgep5970 = getelementptr i8, ptr %p5969, i64 -24
  %ld5971 = load i64, ptr %rgep5970, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5971, ptr %slot1142, align 8
  %v5972 = load i64, ptr %slot1142, align 8
  %op5973 = sub i64 %v5972, 1
  store i64 %op5973, ptr %slot1143, align 8
  %v5974 = load i64, ptr %slot1143, align 8
  %cmp5975 = icmp eq i64 %v5974, 0
  %cv5976 = zext i1 %cmp5975 to i32
  store i32 %cv5976, ptr %slot1144, align 8
  %v5977 = load i32, ptr %slot1144, align 8
  %cv5978 = zext i32 %v5977 to i64
  %cond5979 = icmp ne i64 %cv5978, 0
  br i1 %cond5979, label %bb_rcglast1669, label %bb_rcgdec1669
bb_rcglast1669:
  %v5980 = load i64, ptr %slot1135, align 8
  %op5981 = sub i64 %v5980, 32
  store i64 %op5981, ptr %slot1145, align 8
  %v5982 = load i64, ptr %slot1135, align 8
  %p5983 = inttoptr i64 %v5982 to ptr
  %rgep5984 = getelementptr i8, ptr %p5983, i64 -32
  %ld5985 = load i64, ptr %rgep5984, align 8, !alias.scope !9, !noalias !10
  store i64 %ld5985, ptr %slot1146, align 8
  %v5986 = load i64, ptr %slot1146, align 8
  %cmp5987 = icmp ne i64 %v5986, 0
  %cv5988 = zext i1 %cmp5987 to i32
  store i32 %cv5988, ptr %slot1147, align 8
  %v5989 = load i32, ptr %slot1147, align 8
  %cv5990 = zext i32 %v5989 to i64
  %cond5991 = icmp ne i64 %cv5990, 0
  br i1 %cond5991, label %bb_rcgdec1669, label %bb_rcgslow1669
bb_rcgslow1669:
  %v5992 = load i64, ptr %slot1134, align 8
  %v5993 = load i64, ptr %slot1131, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64 %v5992, i64 %v5993) nomerge, !dbg !162
  br label %bb_rcgdone1669
bb_rcgdec1669:
  %v5994 = load i64, ptr %slot1143, align 8
  %v5995 = load i64, ptr %slot1135, align 8
  %p5996 = inttoptr i64 %v5995 to ptr
  %rgep5997 = getelementptr i8, ptr %p5996, i64 -24
  store i64 %v5994, ptr %rgep5997, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1669
bb_rcgclear1669:
  %v5998 = load i64, ptr %slot1131, align 8
  %p5999 = inttoptr i64 %v5998 to ptr
  store i64 0, ptr %p5999, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1669
bb_rcgdone1669:
  br label %bb_rcslotdone1653
bb_rcslotowner1653:
  %v6000 = load i64, ptr %slot56, align 8
  store i64 %v6000, ptr %slot1148, align 8
  %v6001 = load i64, ptr %slot1131, align 8
  %p6002 = inttoptr i64 %v6001 to ptr
  %ld6003 = load i64, ptr %p6002, align 8, !alias.scope !3, !noalias !4
  store i64 %ld6003, ptr %slot1149, align 8
  %v6004 = load i64, ptr %slot1149, align 8
  %cmp6005 = icmp ne i64 %v6004, 0
  %cv6006 = zext i1 %cmp6005 to i32
  store i32 %cv6006, ptr %slot1150, align 8
  %v6007 = load i32, ptr %slot1150, align 8
  %cv6008 = zext i32 %v6007 to i64
  %cond6009 = icmp ne i64 %cv6008, 0
  br i1 %cond6009, label %bb_rcgnn1684, label %bb_rcgdone1684
bb_rcgnn1684:
  %v6010 = load i64, ptr %slot1149, align 8
  %op6011 = sub i64 %v6010, 16
  store i64 %op6011, ptr %slot1151, align 8
  %v6012 = load i64, ptr %slot1149, align 8
  %p6013 = inttoptr i64 %v6012 to ptr
  %rgep6014 = getelementptr i8, ptr %p6013, i64 -16
  %ld6015 = load i64, ptr %rgep6014, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6015, ptr %slot1152, align 8
  %v6016 = load i64, ptr %slot1152, align 8
  %op6017 = and i64 %v6016, 4611686018427387906
  store i64 %op6017, ptr %slot1153, align 8
  %v6018 = load i64, ptr %slot1153, align 8
  %cmp6019 = icmp ne i64 %v6018, 0
  %cv6020 = zext i1 %cmp6019 to i32
  store i32 %cv6020, ptr %slot1154, align 8
  %v6021 = load i32, ptr %slot1154, align 8
  %cv6022 = zext i32 %v6021 to i64
  %cond6023 = icmp ne i64 %cv6022, 0
  br i1 %cond6023, label %bb_rcgclear1684, label %bb_rcgcounted1684
bb_rcgcounted1684:
  %v6024 = load i64, ptr %slot1149, align 8
  %op6025 = sub i64 %v6024, 32
  store i64 %op6025, ptr %slot1155, align 8
  %v6026 = load i64, ptr %slot1149, align 8
  %p6027 = inttoptr i64 %v6026 to ptr
  %rgep6028 = getelementptr i8, ptr %p6027, i64 -32
  %ld6029 = load i64, ptr %rgep6028, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6029, ptr %slot1156, align 8
  %v6030 = load i64, ptr %slot1156, align 8
  %op6031 = sub i64 %v6030, 1
  store i64 %op6031, ptr %slot1157, align 8
  %v6032 = load i64, ptr %slot1157, align 8
  %cmp6033 = icmp eq i64 %v6032, 0
  %cv6034 = zext i1 %cmp6033 to i32
  store i32 %cv6034, ptr %slot1158, align 8
  %v6035 = load i32, ptr %slot1158, align 8
  %cv6036 = zext i32 %v6035 to i64
  %cond6037 = icmp ne i64 %cv6036, 0
  br i1 %cond6037, label %bb_rcglast1684, label %bb_rcgdec1684
bb_rcglast1684:
  %v6038 = load i64, ptr %slot1149, align 8
  %op6039 = sub i64 %v6038, 24
  store i64 %op6039, ptr %slot1159, align 8
  %v6040 = load i64, ptr %slot1149, align 8
  %p6041 = inttoptr i64 %v6040 to ptr
  %rgep6042 = getelementptr i8, ptr %p6041, i64 -24
  %ld6043 = load i64, ptr %rgep6042, align 8, !alias.scope !9, !noalias !10
  store i64 %ld6043, ptr %slot1160, align 8
  %v6044 = load i64, ptr %slot1160, align 8
  %cmp6045 = icmp ne i64 %v6044, 0
  %cv6046 = zext i1 %cmp6045 to i32
  store i32 %cv6046, ptr %slot1161, align 8
  %v6047 = load i32, ptr %slot1161, align 8
  %cv6048 = zext i32 %v6047 to i64
  %cond6049 = icmp ne i64 %cv6048, 0
  br i1 %cond6049, label %bb_rcgdec1684, label %bb_rcgslow1684
bb_rcgslow1684:
  %v6050 = load i64, ptr %slot1148, align 8
  %v6051 = load i64, ptr %slot1131, align 8
  call void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64 %v6050, i64 %v6051) nomerge, !dbg !162
  br label %bb_rcgdone1684
bb_rcgdec1684:
  %v6052 = load i64, ptr %slot1157, align 8
  %v6053 = load i64, ptr %slot1149, align 8
  %p6054 = inttoptr i64 %v6053 to ptr
  %rgep6055 = getelementptr i8, ptr %p6054, i64 -32
  store i64 %v6052, ptr %rgep6055, align 8, !alias.scope !9, !noalias !10
  br label %bb_rcgclear1684
bb_rcgclear1684:
  %v6056 = load i64, ptr %slot1131, align 8
  %p6057 = inttoptr i64 %v6056 to ptr
  store i64 0, ptr %p6057, align 8, !alias.scope !3, !noalias !4
  br label %bb_rcgdone1684
bb_rcgdone1684:
  br label %bb_rcslotdone1653
bb_rcslotdone1653:
  %v6058 = load i64, ptr %slot1114, align 8
  %p6059 = inttoptr i64 %v6058 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6059, i64 40, i1 false)
  ret void
bb_failure:
  %v6060 = load i64, ptr %slot6, align 8
  %p6061 = inttoptr i64 %v6060 to ptr
  call void @llvm.memset.p0.i64(ptr %p6061, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !162
  %v6062 = load i64, ptr %slot6, align 8
  %p6063 = inttoptr i64 %v6062 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6063, i64 40, i1 false)
  ret void
bb_entry_failure:
  %v6064 = load i64, ptr %slot6, align 8
  %p6065 = inttoptr i64 %v6064 to ptr
  call void @llvm.memset.p0.i64(ptr %p6065, i8 0, i64 40, i1 false), !alias.scope !3, !noalias !4, !dbg !162
  %v6066 = load i64, ptr %slot6, align 8
  %p6067 = inttoptr i64 %v6066 to ptr
  call void @llvm.memmove.p0.p0.i64(ptr %p_sret, ptr %p6067, i64 40, i1 false)
  ret void
}

@myl_native_list_header_type = external global i8, align 8
@myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527 = external global i8, align 8
@myl_t_2f2e02ad41a02f945c6bab09db3fd878f9568ab08155ec990187fbebdc2903d4 = external global i8, align 8

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
declare ptr @llvm.stacksave()
declare i64 @myl_f_5827380cbf6916206876356b2fb07f0a7833a21ff547d974596f9c567fea634d(i64, i64)
declare i64 @myl_f_5a38b8d0be76381d6576297707d3fe06cb475787091980a4a43f54924b2d4c29(i64, i64)
declare void @myl_f_9fc06d0290f8b50ff4ff3bc73e7d23268320ac28e17087c68ac3835de3f54fdc(ptr sret([32 x i8]) align 8, i64)
declare { i64, i64 } @myl_f_b3086250724b37e1530ea18afd53a87106fe0a2ce8bf702de675deca9c1a6925(i64, i64)
declare ptr @myl_native_list_new(ptr, ptr, i64)
declare void @myl_qbe_fail_allocation(ptr) noreturn cold
declare void @myl_qbe_fail_frame(ptr) noreturn cold
declare void @myl_qbe_fail_list_capacity(ptr) noreturn cold
declare ptr @myl_qbe_heap(ptr) memory(none) nounwind willreturn
declare void @myl_qbe_rc_scope_end(ptr, ptr)
declare i32 @myl_qbe_rc_scope_pin(ptr, ptr, ptr)
declare void @myl_qbe_rc_scopes_close(ptr, ptr, i64)
declare i32 @myl_qbe_rc_status(ptr, i32)
declare i32 @myl_qbe_rc_unique_field(ptr, ptr, ptr, ptr)
declare i64 @myl_qbe_region_mark(ptr)
declare i32 @myl_rc_list_append(ptr, ptr, ptr)
declare i32 @myl_rc_list_plain_ready(ptr, ptr)
declare i32 @myl_rc_take_failure(ptr)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_drop(i64, i64)
declare void @myl_t_1535267fc5a418ed8053a9a6290354ebfcee0a92538bece7aa6b84967f8fb527_rcg_unloan(i64, i64)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_277089d91c0bdf4f2e6862ba7e4a07605119431f5d13f726dd352b06f1b206a9_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_drop(i64, i64)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_take(i64, i64, i64, i32)
declare void @myl_t_3ece1c6f770ecd2a506fa806688c97e383087567b3626d4a9ce4529758a6df1f_rcg_unloan(i64, i64)
declare void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_drop(i64, i64)
declare i32 @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_take(i64, i64, i64, i32)
declare void @myl_t_47900e4654488d0cd4bb786015bd4c25604346ebe548c027edb9c02aa204184e_rcg_unloan(i64, i64)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_drop(i64, i64)
declare i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_publish(i64, i64, i64, i32, i32)
declare i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_take(i64, i64, i64, i32)
declare void @myl_t_4e6c1584b61f68a69271c693e65be720323e6bcb8d28e2f694592eed5c4c3f28_rcg_unloan(i64, i64)
declare void @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_drop(i64, i64)
declare i32 @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_take(i64, i64, i64, i32)
declare void @myl_t_50e3220d3c7cc8dc987e1f72744478b3112c8e1ff0b259c96b110425289e0fd1_rcg_unloan(i64, i64)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_drop(i64, i64)
declare i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_loan(i64, i64, i64)
declare i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_retain(i64, i64, i64, i32)
declare i32 @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_take(i64, i64, i64, i32)
declare void @myl_t_87b3a699846cba24453cba0c476cfc282ad163c22e08be1c713a98bd1480fb29_rcg_unloan(i64, i64)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_drop(i64, i64)
declare i32 @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_take(i64, i64, i64, i32)
declare void @myl_t_8c9388548d4a39470c40f7e87af464fd09b9aa0ce04c463371b4e870b86a60fd_rcg_unloan(i64, i64)

attributes #0 = { "disable-tail-calls"="true" "target-cpu"="x86-64" "target-features"="-16bit-mode,-32bit-mode,+64bit,+adx,+aes,+allow-light-256-bit,-amx-avx512,-amx-bf16,-amx-complex,-amx-fp16,-amx-fp8,-amx-int8,-amx-movrs,-amx-tf32,-amx-tile,+avx,-avx10.1,-avx10.2,+avx2,-avx512bf16,-avx512bitalg,-avx512bw,-avx512cd,-avx512dq,-avx512f,-avx512fp16,-avx512ifma,-avx512vbmi,-avx512vbmi2,-avx512vl,-avx512vnni,-avx512vp2intersect,-avx512vpopcntdq,-avxifma,-avxneconvert,+avxvnni,-avxvnniint16,-avxvnniint8,+bmi,+bmi2,-branch-hint,-branchfusion,-ccmp,-cf,-cldemote,+clflushopt,+clwb,-clzero,+cmov,-cmpccxadd,+crc32,+cx16,+cx8,-egpr,-enqcmd,-ermsb,+f16c,-false-deps-getmant,-false-deps-lzcnt-tzcnt,-false-deps-mulc,-false-deps-mullq,+false-deps-perm,-false-deps-popcnt,-false-deps-range,-fast-11bytenop,+fast-15bytenop,-fast-7bytenop,-fast-bextr,-fast-dpwssd,+fast-gather,-fast-hops,-fast-imm16,-fast-lzcnt,-fast-movbe,+fast-scalar-fsqrt,-fast-scalar-shift-masks,+fast-shld-rotate,+fast-variable-crosslane-shuffle,+fast-variable-perlane-shuffle,+fast-vector-fsqrt,-fast-vector-shift-masks,-faster-shift-than-shuffle,+fma,-fma4,+fsgsbase,-fsrm,+fxsr,+gfni,-harden-sls-ijmp,-harden-sls-ret,+hreset,-idivl-to-divb,+idivq-to-divl,-inline-asm-use-gpr32,+invpcid,+kl,-lea-sp,-lea-uses-ag,-lvi-cfi,-lvi-load-hardening,-lwp,+lzcnt,+macrofusion,+mmx,+movbe,+movdir64b,+movdiri,-movrs,-mwaitx,-ndd,-nf,-no-bypass-delay,+no-bypass-delay-blend,+no-bypass-delay-mov,+no-bypass-delay-shuffle,+nopl,-pad-short-functions,+pclmul,-pconfig,+pku,+popcnt,-ppx,-prefer-128-bit,-prefer-256-bit,-prefer-legacy-setcc,-prefer-mask-registers,+prefer-movmsk-over-vtest,-prefer-no-gather,-prefer-no-scatter,-prefetchi,+prfchw,+ptwrite,-push2pop2,-raoint,+rdpid,-rdpru,+rdrnd,+rdseed,-retpoline,-retpoline-external-thunk,-retpoline-indirect-branches,-retpoline-indirect-calls,-rtm,+sahf,-sbb-dep-breaking,+serialize,-seses,-sgx,+sha,-sha512,+shstk,+slow-3ops-lea,-slow-incdec,-slow-lea,-slow-pmaddwd,-slow-pmulld,+slow-pmullq,-slow-shld,-slow-two-mem-ops,-slow-unaligned-mem-16,-slow-unaligned-mem-32,-sm3,-sm4,+sse,+sse2,+sse3,+sse4.1,+sse4.2,-sse4a,-sse-unaligned-mem,+ssse3,-tagged-globals,-tbm,-tsxldtrk,+tuning-fast-imm-vector-shift,-uintr,-use-glm-div-sqrt-costs,-use-slm-arith-costs,-usermsr,+vaes,+vpclmulqdq,+vzeroupper,+waitpkg,-wbnoinvd,+widekl,+x87,-xop,+xsave,+xsavec,+xsaveopt,+xsaves,-zu" uwtable }

!0 = distinct !{!0, !"mylang memory classes"}
!1 = distinct !{!1, !0, !"frame"}
!2 = distinct !{!2, !0, !"foreign"}
!3 = !{!1}
!4 = !{!2}
!5 = distinct !{!5, !0, !"object"}
!6 = !{!5}
!7 = !{!1, !11}
!8 = distinct !{!8, !0, !"rc prefix"}
!9 = !{!8}
!10 = !{!1, !5, !11}
!9999997 = distinct !{!9999997, !0, !"rc state"}
!9999998 = !{!9999997}
!9999999 = !{!1, !5, !8, !11}
!11 = distinct !{!11, !0, !"element 8v"}
!12 = !{!11}
!13 = !{!1, !5}
!10000000 = !{!1, !2}
!llvm.dbg.cu = !{!100}
!llvm.module.flags = !{!102, !103}
!llvm.pseudo_probe_desc = !{!107}
!100 = distinct !DICompileUnit(language: DW_LANG_C99, file: !104, producer: "mylang", isOptimized: true, runtimeVersion: 0, emissionKind: DebugDirectivesOnly)
!104 = !DIFile(filename: "myl_f_079424de52d5f48cd51b17cd049217cb3528df1db52f5fe4c6f03a85ac2d8020", directory: "")
!101 = distinct !DISubprogram(name: "myl_f_079424de52d5f48cd51b17cd049217cb3528df1db52f5fe4c6f03a85ac2d8020", linkageName: "myl_f_079424de52d5f48cd51b17cd049217cb3528df1db52f5fe4c6f03a85ac2d8020", scope: !104, file: !104, line: 1, type: !105, spFlags: DISPFlagDefinition | DISPFlagOptimized, unit: !100)
!105 = !DISubroutineType(types: !106)
!106 = !{}
!102 = !{i32 7, !"Dwarf Version", i32 4}
!103 = !{i32 2, !"Debug Info Version", i32 3}
!107 = !{i64 6785583314190681823, i64 0, !"myl_f_079424de52d5f48cd51b17cd049217cb3528df1db52f5fe4c6f03a85ac2d8020"}
!111 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646535)
!110 = !DILocation(line: 1, column: 1, scope: !111)
!113 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646543)
!112 = !DILocation(line: 1, column: 0, scope: !113)
!115 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646551)
!114 = !DILocation(line: 2, column: 0, scope: !115)
!117 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646567)
!116 = !DILocation(line: 4, column: 0, scope: !117)
!119 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646591)
!118 = !DILocation(line: 7, column: 0, scope: !119)
!121 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646599)
!120 = !DILocation(line: 8, column: 0, scope: !121)
!123 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646639)
!122 = !DILocation(line: 13, column: 0, scope: !123)
!125 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646647)
!124 = !DILocation(line: 14, column: 0, scope: !125)
!127 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646655)
!126 = !DILocation(line: 15, column: 0, scope: !127)
!129 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646671)
!128 = !DILocation(line: 17, column: 0, scope: !129)
!131 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646695)
!130 = !DILocation(line: 20, column: 0, scope: !131)
!133 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646727)
!132 = !DILocation(line: 24, column: 0, scope: !133)
!135 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646751)
!134 = !DILocation(line: 27, column: 0, scope: !135)
!137 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646759)
!136 = !DILocation(line: 28, column: 0, scope: !137)
!139 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646767)
!138 = !DILocation(line: 29, column: 0, scope: !139)
!141 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646783)
!140 = !DILocation(line: 31, column: 0, scope: !141)
!143 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646831)
!142 = !DILocation(line: 37, column: 0, scope: !143)
!145 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646839)
!144 = !DILocation(line: 38, column: 0, scope: !145)
!147 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646847)
!146 = !DILocation(line: 39, column: 0, scope: !147)
!149 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646863)
!148 = !DILocation(line: 41, column: 0, scope: !149)
!151 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646871)
!150 = !DILocation(line: 42, column: 0, scope: !151)
!153 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646879)
!152 = !DILocation(line: 43, column: 0, scope: !153)
!155 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646895)
!154 = !DILocation(line: 45, column: 0, scope: !155)
!157 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646919)
!156 = !DILocation(line: 48, column: 0, scope: !157)
!159 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646935)
!158 = !DILocation(line: 50, column: 0, scope: !159)
!161 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646951)
!160 = !DILocation(line: 52, column: 0, scope: !161)
!163 = !DILexicalBlockFile(scope: !101, file: !104, discriminator: 186646959)
!162 = !DILocation(line: 53, column: 0, scope: !163)
